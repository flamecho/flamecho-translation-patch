﻿*start

;--------------------------------------------------------------------------------------------
;▼フルボイス初期設定▼
;ドロップ
[voconfig sebuf=1 name=drop vostorage="drop/full/{number}.ogg" number=141]
;クォードリリオン
[voconfig sebuf=1 name=riri vostorage="riri/full/{number}.ogg" number=218]
;カイト
[voconfig sebuf=1 name=kite vostorage="kite/full/{number}.ogg" number=254]
;ハートシェイプ
[voconfig sebuf=1 name=hati vostorage="hati/full/{number}.ogg" number=130]
;ジェット
[voconfig sebuf=1 name=jet vostorage="jet/full/{number}.ogg" number=133]
;サウス
[voconfig sebuf=1 name=sausu vostorage="sausu/full/{number}.ogg" number=303]
;糠星の夜
[voconfig sebuf=1 name=yoru vostorage="yoru/full/{number}.ogg" number=236]
;ダークネブラ
[voconfig sebuf=1 name=hakase vostorage="hakase/full/{number}.ogg" number=70]
;ヴルペクラ
[voconfig sebuf=1 name=peku vostorage="peku/full/{number}.ogg" number=204]
;ヤブ医者
[voconfig sebuf=1 name=yabu vostorage="yabu/full/{number}.ogg" number=121]
;タケル
[voconfig sebuf=1 name=take vostorage="take/full/{number}.ogg" number=83]
;ミカちん
[voconfig sebuf=1 name=tiaki vostorage="mika/full/{number}.ogg" number=224]

; ソラはややこしいので途中で記述

;--------------------------------------------------------------------------------------------

[::]
没错！！不必隐瞒、终于轮到我从[rhr]
出题一方转为被考问的一方了！[rhp]

为了能应对任何考题，每天都必须刻苦学习。[rhr]
我连感受无聊的空闲，连一秒都不被允许啊……！！[rhp]

[:princess:][puri_w kao=1 ]
「《濒危物种图鉴》的题目已经连续出现三次了。[rhr]
_　差不多该考其他图鉴的内容了吧……」[rhp]
[:princess:]
「不过任何图鉴我都了如指掌！」[rhp]

[:heartshape:][hati kao=5 ]
「说得好，公主！！」[rhp]

[:princess:][puri_w kao=4 as=on ]
「哈蒂君！！你什么时候来的！？话说这是我的房间……」[rhp]

[:heartshape:][hati kao=5 ]
「这般勤学苦练的姿态，我很欣赏！[rhr]
_　出题者也会感到无比畅快啊！！」[rhp]
[:heartshape:]
「但是！今天依然是濒危物种问答！！」[rhp]

[:princess:][puri_w kao=2 as=on ]
「呜、被摆了一道！」[rhp]

[off_all]

;****************************************
;カットイン
[se storage="se8_11.ogg"]
[s_image layer="2" page="back" storage="ct/d_h_1.png" width="1260" left="10" top="40" name="nov"]
[s_trans layer="2" method="bounceInDown" time=1000]
[wt]
;****************************************

[:heartshape:]
「提问！彩岩河蚬是以下哪一项！？」[rhp]

[:princess:]
「！？」[rhp]

[::]
这题太难了……不都长得像蛤蜊吗！[rhp]

;****************************************
[s_freeimage layer="2" ]
;****************************************

[:jet:][jet kao=7 ]
「最右边那个」[rhp]

[:heartshape:][hati kao=2 ]
「正确！不愧是杰……喂，谁让你抢答的！」[rhp]

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
[vostart]
;--------------------------------------------------------------------------------------------

;しじみチャンス

[:jet:][jet kao=5 ]
「蛤蜊机会！」[rhp]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

[:princess:][puri_w kao=2 as=on ]
「！？」[rhp]

[:heartshape:][hati kao=2 ]
「原来如此……！你是想说不放过任何机会全部掌握，[rhr]
_　是这个意思吧杰特！？」[rhp]

[:jet:][jet kao=12 ]
「差不多就是这个意思」[rhp]

[:heartshape:][hati kao=14 ]
「不愧是你～！　果然杰特的层次就是不一样！」[rhp]
[:heartshape:][hati kao=5 ]
「公主！！[rhr]
_　我们也要向杰特学习，互相切磋琢磨啊！」[rhp]

[:princess:][puri_w kao=1 ]
「嗯，嗯」[rhp]

[off_all]

[:heartshape:][hati kao=2 ]
「可恶、这样下去可不行！[rhr]
_　必须找出连杰特都无法立刻回答的难题才行！」[rhp]
[:heartshape:][hati kao=13 ]
「那就先这样啦公主！　回头见！！」[rhp]

[off_all]

[::]
说完哈蒂君便带着杰特君，[rhr]
转眼间消失得无影无踪。[rhp]
像这样荒诞无稽的对话[rhr]
最近几天持续上演着，倒也算不上无聊。[rhp]

[:princess:]
[font color=0x4682b4]
（虽然偶尔会跟不上节奏……）[rhp]
[resetfont]

;****************************************
[set_time_d]
;****************************************

那天夜里，我在房间里读着从博士那儿借来的书。[rhp]
今天哈蒂君提出的问题相当棘手，让我大吃一惊。[rhr]
没想到居然会问这种吹毛求疵的内容！[rhp]
既然对方准备得这么充分，我也得好好学习才行……！[rhp]

[:yoru:][yoru kao=0 ]
「干劲十足呢」[rhp]

[:princess:][puri_w kao=2 as=on ]
「哇啊！」[rhp]

[off_all]

[::]
背后突然传来夜的声音，吓得我几乎跳了起来。[rhr]
转头看见他的脸上，正挂着对我这副模样的无奈神情。[rhp]

[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="293" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=1 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:][puri_w kao=6 ]
「真是的！　干嘛非要用魔法现身啊。[rhr]
_　明明说过要从门口敲门进来的！」[rhp]

[:yoru:][yoru kao=7 ]
「我觉得不该打扰你学习」[rhp]

[:princess:][puri_w kao=2 as=on ]
「横竖都是在打扰啊！差点把我心脏吓停」[rhp]

[:yoru:][yoru kao=0 ]
「你的心脏本来就已经停止跳动了吧」[rhp]

[:princess:]
「这种黑色幽默…在别处会招人嫌的……」[rhp]

[:yoru:][yoru kao=12 ]
「因为是事实所以没关系」[rhp]

[:princess:][puri_w kao=6 as=on ]
「所以这种地方就……、……算了当我没说」[rhp]

;****************************************
[jump storage="ev_d.ks" target="*tutti"]
;****************************************

*start2

[off_all]

[:heartshape:][hati kao=5 ]
「呼呼呼……啊哈哈哈……！」[rhp]

[:jet:][jet kao=12 ]
「喂喂哈托谢普。[rhr]
_　你怎么学矢部那样笑？」[rhp]

[:heartshape:][hati kao=5 ]
「杰特。我为了这次大扫除[rhr]
_　做了个超～～～厉害的发明……！」[rhp]

[off_all]

[chara_part name="drop" body=base kao=6 as=on ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=1 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:][puri_w kao=1 ]
「发明？」[rhp]

[:drop:][drop kao=1 ]
「有种不祥的预感……」[rhp]

[off_all]

[chara_part name="jet" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:]
「我现在要用魔法在所有车厢放出和我等高的章鱼！！[rhr]
_　让它们爬行时用吸盘自然吸附车内垃圾！」[rhp]

[:jet:][jet kao=6 as=on ]
「这不就是吸尘器……」[rhp]

[:heartshape:][hati kao=4 ]
[font size=30]
「吸尘器！？」[rhp]
[resetfont]

[:jet:][jet kao=14 as=on ]
「……是章鱼！如假包换的章鱼！」[rhp]

[off_all]

[chara_part name="drop" body=base kao=8 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=13 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:drop:]
「真是的。别废话了赶紧干活」[rhp]

[:princess:]
「我用拖把和扫帚清理地板，[rhr]
_　你们俩能负责擦窗户吗？」[rhp]

[off_drop]

[chara_part name="drop" body=base kao=5 as=off ss=off hh=on hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="421" top="0" wait="true" time=150]

[:heartshape:]
「用章鱼吸盘……！？」[rhp]

[:princess:][puri_w kao=5 as=on ]
「不，用抹布」[rhp]

[off_all]

[chara_part name="jet" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:]
「本以为是个绝妙主意 反应却这么平淡。[rhr]
_　到底哪里出问题了……！？」[rhp]

[:jet:]
「哎呀算啦。还有下次嘛」[rhp]

[off_all]

[:princess:][puri_w kao=14 as=on ]
「好啦好啦！就算不借助章鱼的力量我们也完全够用！[rhr]
_　在落合君来之前大家一起加油吧！」[rhp]

[chara_part name="jet" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:hutago:]
「噢！！」[rhr]
「真麻烦啊……」[rhp]

[off_all]

[:jet:][jet kao=6 ]
「…………说到底落合到底是谁啊」[rhp]

[:drop:][drop kao=0 ]
「？您说什么了吗，杰特先生」[rhp]

[:jet:][jet kao=13 ]
「没有？什么都没说。[rhr]
_　想到落合要来，现在就开始期待了呢」[rhp]

[:drop:][drop kao=13 ]
「是啊。真想早点去迎接他」[rhp]

[:jet:][jet kao=14 ]
「没错」[rhp]

[off_all]

;****************************************
[fbgm]
[set_time storage="train_02.jpg"]
[bgm storage="bgm_07.ogg"]
;****************************************

[::]
完成大致打扫后，我们稍作休息。[rhp]
坐在包厢座位里，用手轻轻揉着疲惫的肩膀和腰时，[rhr]
多洛普端着放有四个杯子的托盘走了过来。[rhp]

[:drop:][drop kao=1 ]
「二位辛苦了。泡了可可，要喝吗？」[rhp]

[:princess:][puri_w kao=1 ]
「谢谢！正好想喝点什么」[rhp]

[:drop:][drop kao=11 ]
「那太好了」[rhp]

[off_all]

[::]
接过多洛普递来的马克杯。[rhp]

[chara_part name="drop" body=base kao=1 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="jet" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="760" top="0" wait="true" time=150]

[:drop:]
「来，两位也请用」[rhp]

[:hutago:]
「谢啦！！」[rhr]
「三克油」[rhp]

[off_all]

[::]
给我们分发完杯子后，多洛普在我身旁坐下。[rhr]
由于哈蒂君他们坐在对面，包厢座位就这样坐满了。[rhp]
……总觉得、这场景还挺少见的啊。[rhr]
多洛普正坐在座位上休息。[rhp]

[chara_part name="drop" body=base kao=0 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=8 as=on ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「多洛普，该不会其实很累吧？」[rhp]

[:drop:][drop kao=4 as=on ]
「咦？为什么这么问？」[rhp]

[:princess:]
「因为你平时都不会在显眼的地方休息啊。[rhr]
_　搞不好这还是第一次看到你休息呢」[rhp]

[:drop:][drop kao=13 as=on ]
「啊……确、确实呢。被你这么一说……真不好意思」[rhp]

[:princess:][puri_w kao=1 ]
「不不、我反而很开心啊。[rhr]
_　感觉像是你对我放下心防了呢」[rhp]
[:princess:]
「啊、不过虽然累了可可还是亲手做了呢。[rhr]
_　明明用魔法会轻松很多吧」[rhp]

[:drop:][drop kao=1 ]
「不、那样不行。[rhr]
_　总觉得这种东西不用魔法会更好吃」[rhp]

[off_all]

[chara_part name="drop" body=base kao=1 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="jet" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="760" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=1 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:heartshape:]
「多洛普就是会在这种地方较真呢。[rhr]
_　这种细腻感我觉得很棒哦！」[rhp]

[:princess:]
「嗯嗯！很有多洛普的风格呢」[rhp]

[:drop:][drop kao=13 as=on hh=on ]
「啊、哈哈哈……谢谢夸奖」[rhp]

[:jet:][jet kao=7 ]
「不过多洛普。虽说落合要来，[rhr]
_　也没必要准备到这种程度吧？」[rhp]

[:drop:][drop kao=1 ]
「这可不行。毕竟是重要的客人」[rhp]

[:jet:][jet kao=0 ]
「客人啊……」[rhp]

[:heartshape:][hati kao=5 ]
「对了！落合来的时候肯定要办欢迎会吧。[rhr]
_　为了那时候，我们现在就来练习问答大赛吧！」[rhp]

[:drop:][drop kao=7 ]
「问答大赛？就是你们常玩的那个吗？」[rhp]

[:heartshape:][hati kao=14 ]
「对了！那就开始吧。第一题！！」[rhp]

[off_all]

;****************************************
;カットイン
[s_image layer="2" page="back" storage="ct/d_h_2.png" width="1260" left="10" top="40" name="nov"]
[s_trans layer="2" method="bounceInDown" time=1000]
[wt]
;****************************************

[:heartshape:]
「这张图片是某种动物身体的局部特写。[rhr]
_　那么，这究竟是什么动物呢──！？」[rhp]

;-----------------------------------------------

*quiz

#
;【①アメリカグンカンドリの喉袋】
[glink clickse="btn_01.ogg" x="290" y="100" width="610" high="72" text="アメリカグンカンドリの喉袋" target="*quiz_b" graphic="glink_a.png" enterimg="glink_b.png"]
;【②アンデスイワドリの頭】
[glink clickse="btn_01.ogg" x="290" y="220" width="610" high="72" text="アンデスイワドリの頭" target="*quiz_b" graphic="glink_c.png" enterimg="glink_d.png"]
;【③ジェットの頭】
[glink clickse="btn_01.ogg" x="290" y="340" width="610" high="72" text="ジェットの頭" target="*quiz_a" graphic="glink_a.png" enterimg="glink_b.png"]
[s]

;-----------------------------------------------
;不正解
*quiz_a

;****************************************
[s_freeimage layer="2" ]
;****************************************

[chara_part name="jet" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=8 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:heartshape:][hati kao=2 ]
「答对了！！居然没被我骗到呢！」[rhp]

[:princess:][puri_w kao=1 ]
「太好啦！」[rhp]

[:jet:][jet kao=2 ]
「别把我排进那种名单里啊……」[rhp]

[off_all]

[jump target="*start2a"]

;-----------------------------------------------
;不正解
*quiz_b

;****************************************
[s_freeimage layer="2" ]
;****************************************

[chara_part name="hati" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="drop" body=base kao=8 as=on ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="645" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=8 as=on ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:heartshape:][hati kao=2 ]
「哔哔──！！」[rhp]

[:princess:][puri_w kao=1 ]
「呜～！好不甘心！」[rhp]

[:drop:]
[font color=0x4682b4]
（倒不如说为什么会答错呢……）[rhp]
[resetfont]

[off_all]

[jump target="*quiz"]

;-----------------------------------------------

*start2a

[chara_part name="hati" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=1 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:heartshape:][hati kao=2 ]
「答对的公主小姐将获得[rhr]
_　可以任意命令某人一次的特别券！」[rhp]

[:princess:][puri_w kao=4 hh=on ]
「诶！！真的吗？」[rhp]

[:heartshape:][hati kao=5 ]
「放马过来！尽管提要求──！」[rhp]

[off_hati]

[:princess:][puri_w kao=7 ]
「嗯……这个嘛，我想想啊……」[rhp]

[off_all]

[::]
说着，我悄悄瞥了多洛普一眼。[rhp]
他似乎很在意我会说什么，[rhr]
立刻注意到了我的视线。[rhp]

[:drop:][drop kao=0 ]
「……？怎么了？」[rhp]

[:princess:][puri_w kao=1 ]
「既然可以选任何人，就这么办吧。[rhr]
_　我要用这张券，让多洛普满足我一个任性要求！」[rhp]

[:drop:][drop kao=2 as=on ]
「哎！？这样对您没有好处啊」[rhp]

[:princess:]
「我的命令就是让你休息。[rhr]
_　有我们在的时候偶尔休息下也没关系喔」[rhp]

[:drop:][drop kao=8 as=on ]
「可、可是……」[rhp]

[off_drop]

[chara_part name="jet" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:]
「只要公主觉得没问题我就完全OK！」[rhp]

[:jet:]
「拐弯抹角的...既然要这样做直接让票不就行了」[rhp]

[:princess:][puri_w kao=13 ]
「没关系的。既然是哈蒂君特地给我的，[rhr]
_　我当然也想用用看嘛」[rhp]

[:heartshape:][hati kao=14 ]
「公主……！嘿嘿」[rhp]

[:jet:][jet kao=2 as=on ]
「这算什么打情骂俏。嘛哈蒂觉得行就行吧」[rhp]

[off_hati]

[chara_part name="drop" body=base kao=0 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:jet:][jet kao=14 ]
「这不就结了。客套话听多了人生会吃亏的」[rhp]

[:drop:][drop kao=1 ]
「说得也是......既然您这么说，我就不客气了」[rhp]
[:drop:]
「…………对了。现在能立刻听我许一个愿望吗？」[rhp]

[off_all]

[chara_part name="hati" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=1 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:heartshape:]
「好啊！包在我身上！」[rhp]

[:princess:]
「尽管说！」[rhp]

[off_all]

[:drop:][drop kao=1 ]
「非常感谢。[rhr]
_　……那个，突然提这种任性的要求实在抱歉……」[rhp]

[off_all]

[:drop:]
「…………能否请你们，稍微分给我一点时间？」[rhp]

;****************************************
[set_xx graphic="rule/krke_h.png" storage="train_10.jpg"]
; 夜フィルター
[filter layer="1" brightness="60"]
;****************************************

[::]
被多洛普带来的地点，竟是银河铁道的车顶之上。[rhp]
透过窗户仰望的银河正中央，无视重力与真空昂然伫立的景象[rhr]
让这个特殊情境更添奇幻，毫无阻隔的绝景令我心潮澎湃。[rhp]

[:princess:][puri_w kao=4 hh=on ]
「好厉害……！原来这里能爬上来啊！」[rhp]

[:drop:][drop kao=1 ]
「是的。平时因危险不对外开放，[rhr]
_　请注意别摔下去」[rhp]

[:princess:][puri_w kao=13 ]
「呵呵，知道啦！」[rhp]

[off_all]

[chara_part name="jet" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=0 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:]
「超厉害……！！　我还是第一次登上这里！」[rhp]
「对吧，杰特！」[rhp]

[:jet:]
「啊……太棒了」[rhp]

[off_all]

[::]
哈蒂君坦率地表露心中的感动，[rhr]
杰特君则在心中默默消化着自己的情绪。[rhr]
两人确实都享受着当下的状态。[rhp]
明明长着相同的脸，反应却如此不同真是奇妙。[rhr]
我……或许更接近杰特君那边。[rhp]
―――我微微仰望着天空，深深地吸了一口气。[rhr]
想要将这景象与感动牢牢铭刻在脑海里。[rhp]

[:princess:]
[font color=0x4682b4]
（绝佳的景色……！　无论望向哪里都是整片星空）[rhp]
[resetfont]

[::]
舒爽的晚风拂过。虽然不确定是否能称之为夜风，[rhr]
轻抚脸颊的凉爽微风仿佛在治愈疲惫的身躯[rhp]

[:princess:][puri_w kao=1 ]
「……所以？要在这里说的烦恼是？」[rhp]

[:drop:][drop kao=1 ]
「其实……那个……我并没有烦恼」[rhp]
[:drop:]
「今天我是想向你们三位道谢的」[rhp]

[:princess:][puri_w kao=0 ]
「？道谢……？」[rhp]

[:drop:][drop kao=1 ]
「公主。自从失去记忆的你出现后，[rhr]
_  日子变得比以往更加忙碌充实」[rhp]
[:drop:][drop kao=12 ]
「这一定是迄今为止最热闹欢快的旅途。[rhr]
_　谢谢你，公主。让我看见了和你相同的风景」[rhp]

[off_all]

[::]
多洛普平静微笑的脸上，[rhr]
似乎渗出了一丝寂寞。[rhp]
我心里猛然一惊。这简直就像是离别的话语。[rhp]

;****************************************
[fbgm]
[bg storage="black.jpg" time=500]
;****************************************

――――――就在这时。[rhp]

[se storage="se2_08.ogg"]

唯独在这个地方，无法预料的异常水温打断了我的思考。[rhp]

;****************************************
[still storage="cg/d_d1_1.png" width="1280" height="720" time=1000]
;****************************************

[bgm storage="bgm_10.ogg"]

[:drop:]
「……………………诶」[rhp]

[:princess:]
「……！？」[rhp]

[:heartshape:]
「什……！多洛普！？」[rhp]

[::]
多洛普的身体，正在变得透明。[rhp]
不，…………正被抹去存在。[rhp]
仿佛与夜空同化般，透过他的身躯，[rhr]
能望见对面的银河。[rhp]

[:drop:]
「………………原来如此。是这样啊」[rhp]

[:princess:]
「多洛普！你、你没事吧！？到底发生了什么―――」[rhp]

[:drop:]
「没、没事的公主。请冷静」[rhp]

[:princess:]
「这怎么冷静啊！到底发生什么事了？」[rhp]

;****************************************
[still_end frame="win.png" storage="train_10.jpg" time=1000]
;****************************************

[:heartshape:][hati kao=2 as=on ]
「……这种消失方式……难道，那家伙……」[rhp]

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
;ドロップと共通のボイス使います

;ソラ unknownで
[voconfig sebuf=1 name=unknown vostorage="sora/full/{number}.ogg" number=38]

[vostart]
;--------------------------------------------------------------------------------------------

[off_all]

[:unknown:]
「吵死了」[rhp]

[:princess:][puri_w kao=2 as=on ]
「……！？」[rhp]

[off_all]

[::]
突然响起的低沉声音。[rhp]

[:unknown:]
「……哇靠，什么情况」[rhp]
[:unknown:]
「虽说状态不佳，这也太离谱了。工作太敷衍……[rhr]
_　差点就要消失了」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:princess:][puri_w kao=4 as=on ]
「诶……」[rhp]

[off_all]

[:heartshape:][hati kao=2 as=on ]
「呃……！果然……！」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:unknown:]
「…………算了，无所谓」[rhp]

[off_all]

[se storage="hand_03.ogg"]

[::]
他这么说着打了个响指，[rhr]
即将变得透明的多洛普的身影便完全消失了。[rhp]
面对过于突然的事件，我瞪大眼睛哑然失声。[rhp]

[:unknown:][sora kao=12 ]
「哼，也就这种程度吧。[rhr]
_　不愧是我，做什么都能完美驾驭」[rhp]
[:unknown:]
「那个只会死认真的『前任』多洛普，可做不到这种程度啊」[rhp]

[:princess:][puri_w kao=2 as=on ]
「你、是谁……！？」[rhp]

[:unknown:][sora kao=2 ]
「……哈？」[rhp]

;-------------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;-------------------------------------------------------------------------------------------------

[off_all]

[::]
带着疑惑的脸转向这边。[rhr]
多洛普绝不会露出那种表情。[rhp]

[chara_part name="sora" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=1 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:][puri_w kao=2 as=on ]
「你对多洛普的身体做了什么？你到底是……！」[rhp]

[:sora:][p_so_09][sora kao=2 ]
「是宙」[rhp]

[off_all]

[::]
青年像切断话题般干脆地纠正道。[rhr]
锐利冰冷的眼睛直盯着这里。[rhp]
……好可怕。明明和洛普长着同样的脸，却像完全不同的另一个人。[rhp]

[:sora:][sora kao=2 ]
「『落合』这个名字已经作废。[rhr]
_　那种叫法，一直让我恶心透顶」[rhp]

[:princess:][puri_w kao=2 as=on ]
「宙……那个……」[rhp]

[:sora:][p_so_12][sora kao=7 ]
「不记得了？是落合宙啦」[rhp]
[:sora:]
「……前些日子承蒙关照」[rhp]

;****************************************
[set_kk storage="train_01.jpg" time=500]
;****************************************

[:kite:]
『――――――宙！！为什么你在这里！？』[rhp]

;****************************************
[set_ff storage="train_10.jpg" time=500]
; 夜フィルター
[filter layer="1" brightness="60"]
;****************************************

[chara_part name="sora" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=8 as=on ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「难、难道……落合君……！？」[rhp]

[:sora:][sora kao=6 ]
「干嘛这么惊讶？你不是向夜打听过了吗。[rhr]
_　他说我马上就会回来。嘛算了，」[rhp]

[:princess:][puri_w kao=2 as=on ]
「多洛普在哪！？」[rhp]

[:sora:][p_so_19][sora kao=2 ]
「…………！」[rhp]

[:princess:][puri_w kao=3 as=on ]
「从刚才开始就完全消失了，到底跑哪去了？[rhr]
_　先解释这个！」[rhp]

[:sora:][sora kao=8 ]
「………………」[rhp]

[:princess:][puri_w kao=2 as=on ]
「你知道些什么吧？这身打扮是怎么回事？[rhr]
_　啊啊真是的，该从哪问起……！」[rhp]

[:sora:][p_so_28][sora kao=6 ]
「已经不在了」[rhp]

[:princess:][puri_w kao=3 as=on ]
「嗯？」[rhp]

[:sora:][sora kao=0 ]
「那家伙是我的冒牌货。所以消失了」[rhp]

[:princess:][puri_w kao=1 ]
「冒、冒牌货……？消失了是，什么意思？」[rhp]

[:sora:][p_so_11][sora kao=2 ]
「那家伙从我这里夺走了一切。[rhr]
_　朋友也好，渴望的现实也好，全都在那家伙手里」[rhp]
[:sora:]
「所以我把一切都夺回来了。仅此而已」[rhp]
[:sora:]
「因为这条铁道的乘务员应该是我」[rhp]

[:princess:][puri_w kao=6 as=on ]
「你……你在说什么……？」[rhp]

[off_all]

[::]
多洛普是冒牌货？落合君才是真的……？[rhp]
冒牌货是什么？多洛普就是多洛普啊。[rhr]
他和落合君明明是完全相反的人。[rhp]
无法理解。多洛普究竟去了―――[rhp]

;倒れる音
[se storage="body_08.ogg"]

[:sora:][p_so_09][sora kao=2 as=on ]
「……！？喂、喂！」[rhp]

[off_all]

[::]
仿佛全身力气都被抽走，我当场倒下了。[rhr]
混乱与冲击让思维无法跟上，甚至感到恶心。[rhp]
头痛。心苦。[rhr]
甚至觉得干脆睡着更轻松。[rhp]
……就这么办吧。醒来后一切肯定都会化为梦境――――――……[rhp]

[:jet:][jet kao=2 ]
「哈蒂！」[rhp]

[off_all]

[:heartshape:][hati kao=2 as=on ]
「……」[rhp]

[:jet:][jet kao=2 as=on ]
「哈蒂发什么呆！别愣着。快躲起来！」[rhp]
[:jet:]
「那家伙既然来了，夜肯定也……！[rhr]
_　那个死脑筋的家伙会怎么训话，用脚趾头都想得出来」[rhp]

[:heartshape:][hati kao=3 as=on ]
「可、可是多洛普他」[rhp]

[:jet:]
「现在是担心别人的时候吗？[rhr]
_　我们可能要大难临头了！」[rhp]

[:heartshape:][hati kao=6 as=on ]
「…………啊、啊啊……」[rhp]

[off_all]

;****************************************

[jump storage="ev_d.ks" target="*tutti5"]

;****************************************

;-----------------------------------------------------------
;-----------------------------------------------------------
*start3
;-----------------------------------------------------------
;-----------------------------------------------------------

[off_puri]

[:yoru:][yoru kao=0 ]
「能对你那行为不发火的人可不多见」[rhp]

[:sora:][sora kao=2 ]
「哈？……你几个意思？」[rhp]

[:yoru:][yoru kao=0 ]
「用我给的钥匙，提前恢复她的记忆这事」[rhp]

[off_all]

[::]
……空气凝固了。[rhr]
夜的杀气正刺痛皮肤。[rhp]

[chara_part name="sora" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:yoru:]
「看来你如今无论实现什么都不会满足。[rhr]
_　上次旅程就是明证。……欺骗我很有趣吗？宙」[rhp]

[:sora:]
「上当受骗只能怪你自己吧」[rhp]

[:yoru:]
「…………。啊确实……这话倒也没错……」[rhp]
[:yoru:]
「那么我也必须告诉你一件事。[rhr]
_　现在不说的话，怕是要惹得你当场暴跳如雷」[rhp]

[:sora:]
「哈……？胡扯些什么――――――」[rhp]

[off_all]

[::]
自己刚说出口，中途似乎就领悟了夜的话中之意。[rhr]
落合君脸上的从容迅速消退，双眼猛然睁大。[rhp]

[:sora:][sora kao=2 as=on ]
「…………你没杀过人？」[rhp]

[off_all]

[:princess:][puri_w kao=4 as=on ]
「咦？杀人是说……」[rhp]

[off_all]

[chara_part name="sora" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sora:][sora kao=2 ]
「到底怎么回事夜……！？[rhr]
_　我是听你说醒来就能到达这个世界才……」[rhp]
[:sora:][sora kao=4 as=on ]
「――――――！！」[rhp]

[:yoru:][yoru kao=2 ]
「没说会杀死你。……倒也不是这么讲[rhr]
_　确实我对你说过『既然那么想死就成全你」[rhp]
[:yoru:]
「但那是谎言。我并没有杀你。不过这无所谓吧？」[rhp]
[:yoru:]
「借用你的话来说——被骗的人活该……就这么回事」[rhp]

[:sora:][sora kao=2 as=on ]
「呿！夜，你这家伙！！」[rhp]

[off_all]

[::]
背对着因愤怒而颤抖的落合君，夜转头看向我。[rhr]
背后有个随时可能爆发的落合君，实在让人坐立难安。[rhp]
夜略显疲惫地轻叹一声。[rhp]

[chara_part name="yoru" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="293" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=8 as=on ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:yoru:]
「要找回滞留此地的多洛普倒是有办法。[rhr]
_　还不至于焦躁不安，你大可放心」[rhp]

[:princess:]
「那真是太好了……不过」[rhp]

[:yoru:][yoru kao=3 ]
「虽然没打算这么快穿帮的[rhr]
_　可能我也老了吧，脑子转不……」[rhp]

[off_all]

[:yoru:][yoru kao=4 as=on ]
「………………！」[rhp]

[off_all]

[:princess:]
「？怎么了，突然……」[rhp]

[off_all]

[:yoru:][yoru kao=6 ]
「……啧……」[rhp]

[off_all]

[:yoru:]
「…………门后藏着两个人」[rhp]

;*****************************************
[bg_rule storage="train_04.jpg" rule="002.png" time=500]
;*****************************************

[:heartshape:][hati kao=2 as=on ]
「――――――！」[rhp]

[off_all]

[:jet:][jet kao=2 as=on ]
「糟了……！」[rhp]

[off_all]

;*****************************************
[bg_rule storage="train_08.jpg" rule="001.png" time=500]
;*****************************************

[chara_part name="yoru" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="293" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=2 as=on ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「这声音是哈蒂君他们！」[rhp]

[:yoru:]
「是来看望你的状况，还是来试探我的情绪……[rhr]
_　无论哪种都出现在最糟糕的时机」[rhp]

[off_all]

[chara_part name="sora" body=base kao=5 as=on ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sora:]
「对我来说倒是雪中送炭」[rhp]

[:yoru:][yoru kao=2 ]
「…………宙」[rhp]

[:sora:][sora kao=2 ]
「夜。你明白我想说什么吧」[rhp]

[off_all]

[::]
不知是因愤怒还是自身缘故，落合君用粗暴的动作[rhr]
沉默地从我们身旁穿过，朝房间的门走去。[rhp]

[se storage="door_09.ogg"]

然后毫不客气地猛地拉开门。[rhp]

[chara_part name="jet" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:]
「啊……」[rhp]

[::]
站在那里的果然是哈蒂君和杰特君。[rhp]
两人看着眼前余怒未消的落合君[rhr]
和室内的我们，表情尴尬地僵在原地。[rhp]
……简直像是害怕会因某事挨骂的表情。[rhr]
若只是来看望我，本不该露出那种神情的。[rhp]

[off_all]

看着这样的两人，落合君从鼻子里发出冷笑。[rhp]
然后再次转头望向夜。[rhr]
……带着从未见过的，充满怨恨的表情。[rhp]

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
;ソラ
[voconfig sebuf=1 name=sora vostorage="sora/full/{number}.ogg" number=89]
[vostart]
;--------------------------------------------------------------------------------------------

[:sora:][sora kao=2 ]
「既然我要被责难到这种地步，那边那两个人又该怎么说」[rhp]
[:sora:]
「……是逃过来的吧。因为害怕听到对我不利的发言」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:princess:][puri_w kao=0 ]
「……？　形势不利的事……？」[rhp]

[off_all]

[:yoru:][yoru kao=6 ]
「换个地方吧。要是被察觉到骚动就麻烦了」[rhp]

[off_all]

[:sora:][sora kao=7 ]
「明白了」[rhp]

[off_all]

;****************************************
[bg_magic_b storage="train_10.jpg"]
; 夜フィルター
[filter layer="1" brightness="60"]
;****************************************

[se storage="hand_03.ogg"]

[::]
落合君打响指的同时，视野骤然转暗景色骤变。[rhp]
多洛普消失而落合君现身，被带回到那节车厢上的景象。[rhp]

;--------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;--------------------------------------------------------------------------------------------

[:princess:][puri_w kao=0 ]
「这里不是只有多洛普的权限才能来……」[rhp]

[:sora:][sora kao=7 ]
「拥有那家伙身体的我也能来。还有……」[rhp]

[off_all]

[::]
落合君依旧没有放松严峻的表情。[rhr]
他嗒嗒地走到哈蒂君他们面前，睥睨着脚下的两人。[rhp]

[chara_part name="sora" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=off ss=on hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sora:]
「……哈蒂。你也一样对吧？」[rhp]

[off_all]

[::]
哈蒂君猛地露出惊惶神色后，随即别开了视线。[rhp]
看到这般情状，落合君发出奚落般的短促笑声。[rhr]
他再度背向他们，稍稍拉开距离重新站定。[rhp]
简直像是接下来要开始推理小说里指认犯人环节的氛围。[rhp]

[:sora:][sora kao=2 ]
「那家伙姑且也算列车员。不过被允许这么做的只有哈蒂……」[rhp]
[:sora:]
「这层意思，懂么」[rhp]

[:princess:][puri_w kao=3 as=on ]
「……，不明白」[rhp]

[off_all]

[::]
有个令人在意的点。[rhp]
当多洛普带我来到这个地方时，[rhr]
哈蒂君他们似乎也是初次来到这里的感受。[rhp]
他们莫非也具备来此的能力？若真如此、[rhr]
以他们旺盛的好奇心，怎可能不来这处惊险之地？[rhp]

[:princess:][puri_w kao=8 as=on ]
「喂，哈蒂……」[rhp]

[off_all]

[:jet:][jet kao=2 ]
「…………」[rhp]

[off_all]

[:princess:][puri_w kao=0 as=on ]
「！」[rhp]

[off_all]

[::]
杰特君意料之外的表情令我震惊。[rhr]
为何要生气？纵使生气，又为何偏偏是杰特君？[rhp]
被落合君挑衅的明明是哈蒂君啊。[rhp]

[:princess:]
[font color=0x4682b4]
（说起来……）[rhp]
[resetfont]

[::]
为何落合君只点名了哈蒂君？[rhr]
刚思考这个问题，我突然意识到。[rhp]
至今为止，杰特君可曾使用过一次魔法？[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:heartshape:][hati kao=3 as=on ]
「…………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[::]
反观哈蒂君的面容，因不安与焦躁而僵硬。[rhp]
虽像是极不愿被点破之事……[rhr]
但为何要狼狈到如此地步？[rhp]

[off_all]

落合君睨视着两人嗤笑道「瞧吧」。[rhr]
他的态度透着绝对自信与深不可测的不满。[rhp]

[chara_part name="sora" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sora:]
「若我消灭多洛普的事令你们如此不快、[rhr]
_　大可以送你们回去」[rhp]
[:sora:][sora kao=2 ]
「不过啊。既然说到这份上，你们也该遵守规则」[rhp]

[off_all]

[:princess:][puri_w kao=1 ]
「规则？我们明明什么都没做错……！」[rhp]

[:sora:][sora kao=2 ]
「不 不对。这里有一个人没遵守规则」[rhp]

[fbgm]

[:sora:]
「对吧？――――――杰特！」[rhp]

[off_all]

[:jet:][jet kao=2 as=on ]
「……」[rhp]

[off_all]

[::]
被严厉的语调点名时，杰特君猛地颤抖了一下身体。[rhp]
完全无法理解。[rhr]
无论是关于规则的事，还是为什么杰特君会被指名，全都。[rhp]

[bgm storage="bgm_19.ogg"]

[chara_part name="sora" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="jet" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sora:]
「你最清楚自己在被指责什么吧」[rhp]
[:sora:]
「过来。你和我是同类，都是『那边』的人吧」[rhp]

[:jet:]
「才、才不是。我」[rhp]

[:sora:]
「你还打算装傻到什么时候？」[rhp]
[:sora:]
「……你，是主楼的人吧」[rhp]

[off_all]

[:jet:][jet kao=2 as=on ]
[font size=26]
「住手！！！！」[rhp]
[resetfont]

[off_all]

[chara_part name="sora" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:yoru:]
「为什么总要闹出动静。不能和平解决吗」[rhp]

[:sora:]
「我始终很冷静。这话该对杰特说」[rhp]

[off_all]

[:jet:][jet kao=2 as=on ]
「…………！那又怎样……知道了又能怎样」[rhp]

[off_all]

[chara_part name="sora" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="jet" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:jet:]
「就算明白了这个，你又能做什么」[rhp]

[:sora:]
「我可不想再单方面吃亏了」[rhp]
[:sora:]
「我可以退出。但条件是杰特，你也要一起走」[rhp]

[:jet:]
「呃……！」[rhp]

[off_all]

[::]
仿佛在说只有我还没理清头绪似的，[rhr]
连哈蒂君和落合君，甚至夜都露出了紧张的神色。[rhp]
落合君得意洋洋地，又回头望向哈蒂君。[rhr]
然后从心底流露出嘲弄般的短促笑声。[rhp]

[chara_part name="sora" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sora:]
「办不到的吧哈蒂。把这家伙送回原来世界什么的」[rhp]
[:sora:]
「你是杰特的『替代品』」[rhp]

[:heartshape:]
「呃……」[rhp]

[:sora:]
「你无法违抗杰特。不仅是你扮演的角色，[rhr]
_　你自身的感情应该也早就发展到了那个阶段。在之前的旅程里你就该明白了」[rhp]
[:sora:]
「看不惯只有你一个人得到幸福。[rhr]
_　所以杰特不回去的话，我也绝不回去」[rhp]
[:sora:]
「……哈蒂会让杰特回去么？」[rhp]

[off_all]

[::]
――――――『你们不是形影不离的好搭档么』。[rhp]
说出这话的落合君，语调里充满了恶意。[rhr]
面对落合君连珠炮般的攻势，两人连反驳的余地都没有。[rhp]
从刚才起陌生的词汇就快让脑袋爆炸了。[rhr]
无论怎么拼命思考，都只是在原地打转理不出头绪。[rhp]

[:heartshape:][hati kao=8 as=on ]
「……呃、杰特……」[rhp]

[off_all]

[::]
打破静默的，是哈蒂君挤出来的声音。[rhr]
那带着哭腔的软弱语调，一点也不像他。[rhp]

[chara_part name="jet" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:]
「………………我，已经不行了」[rhp]

[:jet:]
「！　哈蒂……」[rhp]

[:heartshape:]
「再也护不住你了。老实下车吧」[rhp]

[:jet:]
「嗯……」[rhp]

[:heartshape:]
「说到底我不是一直这么说的吗」[rhp]
[:heartshape:]
「你不该留在这里。快点回到原来的世界比较好」[rhp]
[:heartshape:]
「……对落合也最先这么说过」[rhp]

[:jet:]
「……你要背叛吗」[rhp]

[:heartshape:]
「！！才、才不是！不是背叛之类的问题啊」[rhp]

[:jet:]
「怎么可能做到」[rhp]

[off_all]

[:jet:][jet kao=2 ]
「落合，你什么都不明白。[rhr]
_　别以为能和我站在同样的立场」[rhp]

[off_all]

[:sora:][sora kao=2 ]
「……啊？」[rhp]

[off_all]

[:jet:][jet kao=2 ]
「————是啊。南」[rhp]

[off_all]

[::]
说着，杰特君转向空无一物的方向，在他视线尽头[rhr]
闪烁着如烟雾般升腾的光芒。[rhp]

[:sausu:][sausu kao=3 as=on ]
「……杰特」[rhp]

[::]
光芒中心出现的，是显得惴惴不安的南的身影。[rhp]
那个神出鬼没的南，居然随叫随到……[rhp]

[off_all]

[chara_part name="jet" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=3 as=on ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="645" top="0" wait="true" time=150]

[:princess:][puri_w kao=2 as=on ]
「南！为什么在这里。难道刚才的一直在看……」[rhp]

[:jet:][jet kao=2 ]
「因为被呼唤了啊。我和南是挚友」[rhp]

[:princess:][puri_w kao=6 as=on ]
「挚、挚友？南和杰特君？」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------
[off_all]

[:yoru:][p_y_28][yoru kao=2 ]
「荒唐……」[rhp]

[off_all]
;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[chara_part name="jet" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="645" top="0" wait="true" time=150]

[:sausu:]
「杰特……既然提到了我的事，」[rhp]

[:jet:]
「落合叫我回去」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[off_all]

[:sora:][sora kao=2 as=on ]
「！」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:jet:][jet kao=2 ]
「啊好吧。既然说到这份上就回去好了……」[rhp]
[:jet:]
「但过去那边之后，我会杀了南和夜」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:yoru:]
「什……！」[rhp]

[:sausu:]
「杰特！？　你在说什么啊」[rhp]

[off_all]

[:jet:][jet kao=2 ]
「要么找人帮忙扔掉，要么点把火烧到只剩灰烬。[rhr]
_　那样的话这个世界和这里的家伙们会怎样？连想都不愿想吧」[rhp]

[off_all]

[chara_part name="jet" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sora" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:jet:]
「把你一直渴望的东西，由我来亲手粉碎。[rhr]
_　毕竟你也打算毁掉我的一切啊」[rhp]

[:sora:]
「你这家伙……！」[rhp]

[:jet:]
「少开玩笑了，别在那装模作样。[rhr]
_　凭什么老子非得听你的不可啊」[rhp]

[off_all]

[:jet:][jet kao=2 ]
「……南！」[rhp]

[:sausu:][sausu kao=2 ]
「呃！」[rhp]

[:jet:]
「你，要怎么办？」[rhp]
[:jet:]
「…………当然是，会保护我吧？」[rhp]

[:sausu:][sausu kao=3 as=on ]
「…………」[rhp]

[off_all]

[:yoru:][yoru kao=6 ]
「南！你清楚的。就算中了他的挑衅也―――」[rhp]

[off_all]

[:sausu:][sausu kao=3 as=on ]
「抱歉，约尔大人」[rhp]
[:sausu:]
「……我必须实现愿望」[rhp]

[:yoru:][yoru kao=6 as=on ]
「你……！！　事到如今还在说这种话！」[rhp]

[off_all]

[:princess:][puri_w kao=8 as=on ]
「等……等一下。这到底是怎么回事？[rhr]
_　杰特君是南的好友，却说要杀了他们两个……？」[rhp]

[:heartshape:][hati kao=3 as=on ]
「没关系的，公主」[rhp]

[:princess:]
「！　哈蒂君……！　我已经完全搞不清状况了」[rhp]]

[off_all]

[chara_part name="jet" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=3 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:jet:]
「哈蒂」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:heartshape:][hati kao=2 as=on ]
「……！」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
;ハートシェイプ
[voconfig sebuf=1 name=hati vostorage="hati/full/{number}.ogg" number=140]
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[::]
叫住哈蒂君的杰特君，眼神冰冷得前所未见。[rhp]
……从哈蒂君能来到这个地方的事实被指出时起，[rhr]
一贯保持著那副不为所动的表情。[rhp]
用锐利的眼神瞪视著我。[rhr]
被气势压倒的我，不禁向后退了一步。[rhp]

[chara_part name="jet" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:jet:]
「我总算明白你为什么这么急著要我回去了」[rhp]
[:jet:]
「因为你是我的替身啊。[rhr]
_　只要有我在，你这辈子都当不了『正牌货』」[rhp]
[:jet:]
「…………没人会抢那种女人的」[rhp]

[:heartshape:]
「呃！！你这家伙！」[rhp]

[:jet:]
「乖乖赞同我不就得了。[rhr]
_　虽然不知道夜燃烧殆尽后，这个世界和你们会变成怎样」[rhp]
[:jet:]
「不过那样一来，你就永远不用担心我会抢走你的容身之处了」[rhp]
[:jet:]
「你是为了让自己继续活下去，才拼命想把我赶回那边」[rhp]

[:heartshape:]
「――――――！」[rhp]

[off_all]

[::]
哈蒂君的表情骤然僵硬，再也说不出反驳的话。[rhr]
杰特君满意地看著这一切，最后轻蔑地啐了一声。[rhp]
…………「果然」。[rhp]
杰特君无视我们，转身面向身后的南。[rhp]

[:jet:][jet kao=6 ]
「我们走吧南」[rhp]

[off_all]

[:sausu:][sausu kao=3 as=on ]
「……啊、啊啊……」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:sausu:][p_s_34]
「…………对不起」[rhp]

[bg_magic_d]

[::]
当满脸愧疚的南说完这句话，[rhr]
他和杰特君便消失在包围他们的魔法烟雾中。[rhp]

[:heartshape:][hati kao=3 as=on ]
「杰特……！为什么……！」[rhp]

[off_all]

[chara_part name="sora" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sora:]
「……夜。杰特说过要杀了你和南」[rhp]

[:yoru:]
「就是字面意思。[rhr]
_　那家伙如果回到现实世界，很可能真的会动手」[rhp]
[:yoru:]
「嘛……以他现在的状况，前提是能做到的话」[rhp]

[:sora:]
「话是这么说……[rhr]
_　如果利用老师他们来实施，这个世界会怎样？」[rhp]

[:yoru:][yoru kao=2 ]
「当然会消失。连同你们的灵魂一起，烧得干干净净彻底终结」[rhp]

[off_all]

[:princess:][puri_w kao=3 as=on ]
「那、那个……从刚才起就完全听不懂你们在说什么」[rhp]

[:yoru:][yoru kao=0 ]
「……说起来还没告诉你最关键的事」[rhp]
[:yoru:][yoru kao=12 ]
「现实世界的我只是一幅绘画。南是千纸鹤。[rhr]
_　两者都极度怕火」[rhp]

[:princess:][puri_w kao=0 as=on ]
「？？」[rhp]

[:sora:][sora kao=3 ]
「说是寄宿在物品上的神明。[rhr]
_　你们现在是被囚禁在名为夜的画中世界的灵魂状态」[rhp]
[:sora:]
「如果那幅画被烧毁，不仅是夜，连困在里面的我们也会死」[rhp]

[:princess:][puri_w kao=2 as=on ]
「诶、在画里面……原来『夜所在之处』是这个意思」[rhp]
[:princess:][puri_w kao=0 as=on ]
「……等等？杰特君说的是要烧现实世界的夜对吧。[rhr]
_　该不会，杰特君还……」[rhp]

[:sora:][sora kao=2 ]
「啊。我初次从这边世界[rhr]
_　苏醒后也问过夜」[rhp]
[:sora:]
「……杰特他还活着」[rhp]

[:princess:][puri_w kao=4 as=on ]
「―――！」[rhp]

[:sora:]
「那家伙和南联手，像我这样活着来到这里的。[rhr]
_　和我的区别，大概就在于是否消灭了哈蒂……另一个自己吧」[rhp]

[:princess:][puri_w kao=1 ]
「另一个……自己……？」[rhp]

[off_all]

[:heartshape:][hati kao=2 as=on ]
「简而言之，我是以杰特意识为基础制造的克隆人」[rhp]
[:heartshape:]
「说那家伙和我是一体两面并非夸张。[rhr]
_　我就是生活在这个世界的另一个杰特」[rhp]

[off_all]

[::]
如此说着发笑的哈蒂君显得有些生硬。[rhp]
也难怪。他正在讲述极其可怕的事。[rhr]
因为这番话意味着，名为哈蒂君的个体本就不存在……[rhp]

[:princess:]
[font color=0x4682b4]
（…………唔、不对。不是这样的）[rhp]
[resetfont]

[::]
哈蒂君就是哈蒂君。[rhr]
我喜欢的终究是名为哈蒂君的这一个体呀。[rhp]

[:sora:][sora kao=2 ]
「但很不可思议啊。为什么杰特会被召唤到这个世界？[rhr]
_　他本不该存在于八云君的时代。为何南就……」[rhp]

[:heartshape:][hati kao=2 ]
「喂落合。抱歉，从这里开始暂时休战如何」[rhp]
[:heartshape:]
「不说服杰特就没办法让你回去，多洛普也回不来。[rhr]
_　再这样下去，你也会什么都没实现就死掉的」[rhp]

[:sora:][sora kao=6 ]
「……、确实如此，但这不能成为联手理由」[rhp]
[:sora:]
「我有我的做法，为打破现状请允许我自由行动。[rhr]
_　不想和你们这些替身无谓地熟络起来产生感情」[rhp]

[:heartshape:][hati kao=0 ]
「………………」[rhp]
[:heartshape:][hati kao=2 ]
「…………明白了！」[rhp]

[:sora:][sora kao=2 as=on ]
「等等。你是不是在盘算着什么？快说！」[rhp]

[:heartshape:]
「没关系。不联手也行！[rhr]
_　只要在旁边守护就好！这对你也有好处！」[rhp]

[:sora:]
「你压根就打算拖我下水吧！」[rhp]

[off_all]

[::]
冲着哈蒂君吼叫的落合君身上，[rhr]
方才那股戾气似乎已消散殆尽。[rhp]
虽说是因共同面对紧急事态使然，[rhr]
但哈蒂君特有的氛围感也不无影响。[rhp]
在稍显缓和的氛围中，夜发出沉重的叹息。[rhp]

[chara_part name="sora" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:yoru:]
「这就是你期望的世界吗……真扭曲。而且麻烦透顶」[rhp]

[:sora:]
「我也完全没料到会这样……！[rhr]
_　都是你给的王牌害得现在我更不利了吧」[rhp]

[:yoru:]
「确实如此」[rhp]

[:sora:][sora kao=2 ]
「……！难道你早知会这样才把情报告诉我？」[rhp]

[:yoru:][yoru kao=6 ]
「是又如何。心甘情愿跳进我剧本的可是你自己」[rhp]
[:yoru:][yoru kao=3 ]
「……不过，杀人预告的确是意料之外。[rhr]
_　本想着赌气的你会带着杰特一起回来」[rhp]

[:sora:]
「天真啊。首先从盯上我开始」[rhp]

[:yoru:]
「确实。屡屡不成事，说是辜负期待都算客气」[rhp]

[:sora:][sora kao=8 as=on ]
「啧……！竟敢小瞧人……」[rhp]

[off_all]

[:princess:][puri_w kao=2 ]
「啊、那个啊。打架前先集合大家，[rhr]
_　从头理清杰特君的事如何？」[rhp]
[:princess:]
「比如为什么哈蒂君突然发怒啦，[rhr]
_　为什么那么不想回去啦，或许能看出些端倪」[rhp]

[off_all]

[:yoru:][yoru kao=0 ]
「……赞同公主的意见」[rhp]
[:yoru:]
「要说明情况我最合适。我已在那栋建筑里布设好力量。[rhr]
_　包括他为何会牵起南的手的经过也尽在掌握」[rhp]

[off_all]

[chara_part name="sora" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=3 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:]
「………………」[rhp]

[:sora:]
「莫非有什么不方便说的？」[rhp]

[:heartshape:][hati kao=2 as=on ]
「……！没、没那回事啦……」[rhp]

[off_all]

[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="293" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=2 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「拜托了夜。请告诉我杰特君的事」[rhp]

[:yoru:][yoru kao=3 ]
「……我本想着迟早要说的………」[rhp]

[off_all]

[:yoru:]
「…………………是个愚蠢的孩子。真的」[rhp]

;****************************************
[fbgm]
[set_b storage="train_05.jpg"]
[free_filter ]
[bgm storage="bgm_34.ogg"]
;****************************************

[::]
那时候[rhp]

[:sausu:][sausu kao=3 ]
「…………以上就是宙来这里的理由」[rhp]
[:sausu:]
「他的目的终究是居住在这个世界。[rhr]
_　说要带你回去，应该视作威胁才对」[rhp]

[:jet:][jet kao=7 ]
「落合的情况我大致了解了。……公主还真是被宠爱着呢。[rhr]
_　虽然我完全不明白她哪里好」[rhp]
[:jet:][jet kao=5 ]
「不过真可怜呢。和南不同，夜是个死板的人。就算一直待在这里，[rhr]
_　肯定每次见面都会被那家伙絮絮叨叨地催着回去吧。太糟糕了」[rhp]

[:sausu:]
「……………………」[rhp]

[:jet:][jet kao=2 ]
「……南。你这家伙还在摆那种表情啊。[rhr]
_　早就说过不用再挂心我的事了」[rhp]
[:jet:]
「不如说挺起胸膛更好吧。[rhr]
_　说到底你根本就没能杀掉我啊」[rhp]

[:sausu:]
「我明白的。你是想说我很天真吧……[rhr]
_　但我认为没让你死去是正确的决定哦」[rhp]
[:sausu:]
「你也是这么想的吧。[rhr]
_　否则的话，你就无法和哈托谢普共度相同的时光―――」[rhp]

[:jet:]
「那家伙的事现在不想提」[rhp]

[:sausu:]
「刚才的打架可不像杰特的作风。[rhr]
_　为什么突然主动找他打架？」[rhp]

[:jet:][jet kao=6 ]
「……那家伙，在我不知道的时候。[rhr]
_　已经能使用和多洛普相同的魔法了」[rhp]
[:jet:]
「明明以前都只会些恶作剧的魔法。[rhr]
_　像车上逃生这种魔法，以前总是第一个教给我的」[rhp]
[:jet:]
「但那家伙却将其隐藏。甚至装得像是初次来到屋顶一般。[rhr]
_　知道为什么吗？因为他根本不想告诉我啊」[rhp]
[:jet:][jet kao=2 ]
「要让我知道自己能使用如此厉害的魔法的话，[rhr]
_　我绝对会愈发向往、更想留在这里。肯定是这样！」[rhp]

[:sausu:][sausu kao=2 as=on ]
「这、这种事情我怎么会知道。[rhr]
_　何必自卑到这种地步」[rhp]

[:jet:]
「闭嘴！总之我无法接受那家伙现在的态度。[rhr]
_　只要他道歉我就原谅他，该低头的是那边才对」[rhp]

[:sausu:]
「可是……就这样不断逃避真的好吗」[rhp]
[:sausu:]
[:sausu:]
「虽然对这个地方施加了禁止进入的魔法，[rhr]
_　但这也并非万无一失」[rhp]
「那边可是有约尔大人坐镇。[rhr]
_　面对逐渐恢复力量的他，我究竟能否抗衡」[rhp]

[:jet:]
「真靠不住。你不是神明吗？」[rhp]

[:sausu:]
「正因为并非全能，才会如此烦恼困扰啊」[rhp]

[:jet:][jet kao=6 ]
「哈……真没用」[rhp]

[:sausu:][sausu kao=3 ]
「杰特。你来此的初衷[rhr]
_　本该是与哈蒂共赴自由人生」[rhp]
「可现在的你形单影只愁眉不展……[rhr]
_　简直背道而驰」[rhp]

[:jet:][jet kao=2 ]
「…………。啊确实如此。[rhr]
_　你是想说这样和现实中不幸的我没有区别吗？」[rhp]

[:sausu:]
「我没那么说。[rhr]
_　只是我，真的很在意你是否真的满意现状」[rhp]
[:sausu:]
「我的愿望是你们的幸福。请不要忘记这点」[rhp]

[:jet:]
「那还真是多谢……但要是回到那群人身边，[rhr]
_　最后肯定又要来说服我。所以我不回去」[rhp]
[:jet:]
「我啊，早就受够了满嘴漂亮话。[rhr]
_　那些抛向我的『肯定』啊『总有一天』啊，从来就没实现过」[rhp]
[:jet:]
「但这个世界不同。[rhr]
_　无论我做什么，都逃离不了这个世界」[rhp]

[:sausu:]
「杰特……」[rhp]

[:jet:]
「这样就挺好。继续这种处境感到困扰的不是我而是对方。[rhr]
_　等时机到了，他们肯定也会熬不住妥协吧」[rhp]
[:jet:]
「就像那时候的南一样」[rhp]

[:sausu:][sausu kao=6 as=on ]
「别说这么讨厌的话啊」[rhp]

[:jet:][jet kao=3 ]
「……为什么他们就是不明白呢。[rhp]
[:jet:]
「与其痛苦地活着，不如死了轻松得多。[rhr]
_　来到这个世界后，我虽未死去却获得了相同的结果」[rhp]
[:jet:]
「仔细想想，这不比普通地死去更好吗？」[rhp]

[:sausu:][sausu kao=3 ]
「……谁知道呢。我无法判断」[rhp]

[:jet:]
「……呐南。成了俺的同伴这件事，后悔过吗？」[rhp]

[:sausu:][sausu kao=13 as=on ]
「…………那倒没有哟」[rhp]
[:sausu:]
「我无论何时都是孩子们的同伴。[rhr]
_　干嘛突然问这个？」[rhp]

[:jet:][jet kao=2 ]
「…………、骗人。看脸就明白了」[rhp]
[:jet:]
「其实后悔着吧。把俺带来这儿的事，一直」[rhp]

[:sausu:][sausu kao=3 as=on ]
「才、才没这种事」[rhp]

[:jet:]
「不过无所谓啦。是朋友也罢，外人终究是外人。[rhr]
_　与俺的人生不相干。能利用的东西统统都会利用」[rhp]
[:jet:]
「因为俺啊，绝对要获得幸福」[rhp]

[:sausu:][sausu kao=6 as=on ]
「…………杰特」[rhp]

[:jet:][jet kao=5 ]
「嘛，怎么说呢。主动搭话就是倒霉的开始啦。[rhr]
_　就当被麻烦家伙缠上了认命吧」[rhp]

[:sausu:][sausu kao=3 as=on ]
「……知道啦知道啦。明白了……」[rhp]

[off_all]

[:sausu:][sausu kao=0]
「…………咦」[rhp]

[off_all]

[:jet:][jet kao=0 ]
「怎么了？」[rhp]

[off_all]

[:sausu:]
「这铁道……好像设定了某个目的地呢。[rhr]
_　乘务员多洛普不在的话，本来应该没法降落才对啊……」[rhp]

[chara_part name="jet" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:jet:]
「严格来说俺和哈蒂也算乘务员」[rhp]

[:sausu:][sausu kao=5 as=on ]
「………………啊。说起来」[rhp]

[:jet:][jet kao=8 as=on ]
「彻底忘了啊。真失礼」[rhp]

[:sausu:][sausu kao=1 ]
「原、原来如此。那就是现在由哈托谢普在驾驶啰。[rhr]
_　话说他竟然会驾驶啊」[rhp]

[:jet:][jet kao=3 ]
「……完全不知道」[rhp]

[:sausu:][sausu kao=0 ]
「不是两个人一起练习的吗？」[rhp]

[:jet:][jet kao=2 ]
「没有……至少，我没有」[rhp]

[:sausu:][sausu kao=11 as=on ]
「……啊……原来是这样[rhr]
_　刚才说的，背着你偷偷练习……」[rhp]

[:jet:][jet kao=2 ]
「又来了。那家伙早就预料到总有一天，这里会只剩下他一个人……」[rhp]
[:jet:]
「…………气死我了！」[rhp]

[:sausu:][sausu kao=6 as=on ]
「杰特……不该说这种话，」[rhp]

[:jet:]
「果然哈蒂觉得我碍事。就像克林那样，[rhr]
_　他怕我会抢走他的位置。我懂」[rhp]
[:jet:]
「好啊。那我偏要跟他斗到底。[rhr]
_　我绝对不要从这里消失……！」[rhp]

[:sausu:][sausu kao=3 ]
「是吗……虽然我只能旁观……但加油吧」[rhp]
[:sausu:][sausu kao=1 ]
「那我先告辞了」[rhp]

[:jet:][jet kao=0 ]
「？要去哪里？」[rhp]

[:sausu:]
「差不多该找个地方着陆了。[rhr]
_　要是被追问放不放你走的人是我而不是杰特，那就麻烦了」[rhp]
[:sausu:]
「说到底，你的去向取决于我。[rhr]
_　毕竟我本来就不是立场很坚定的人……」[rhp]

[:jet:]
「确实。要是逼得太紧，你这种人肯定会马上叛变吧」[rhp]

[:sausu:][sausu kao=6 as=on ]
「不会啦。再也不会了」[rhp]

[:jet:][jet kao=3 ]
「……哎。要一个人待在这儿吗……好无聊啊」[rhp]

[:sausu:][sausu kao=3 ]
「我在那边也是一个人」[rhp]

[:jet:][jet kao=0 ]
「……！」[rhp]

[:sausu:]
「你[player2]也不在了呢。[rhr]
_　加上合并计划在即，已经在稳步推进向主楼搬迁的准备工作」[rhp]
[:sausu:]
「那地方不会再新增孩子了。[rhr]
_　所以大概，我也快要完成使命了吧」[rhp]

[:jet:][jet kao=2 ]
「…………哼嗯」[rhp]

[:sausu:][sausu kao=1 ]
「嘛，这对现在的你来说已经无所谓了」[rhp]

[off_all]

[:sausu:][sausu kao=13 ]
「……那么再见。愿你旅途顺利」[rhp]

[off_all]

;****************************************
#
[fbgm]
[bg storage="train_01.jpg" time=2000]
[bgm storage="bgm_08.ogg"]
;****************************************

[::]
我们将所有人召集到食堂，重新听夜讲述了全部经过。[rhp]
关于杰特君的事、南的事、以及名为临终关怀院的地方。[rhp]
还有……这条铁道与世界的概况。[rhp]

[:princess:]
[font color=0x4682b4]
（我曾在临终关怀院生活过，至少这点弄明白了……）[rhp]
[:princess:]
（…………另外还包括在这里的快斗和杰特君）[rhp]
[resetfont]

[:yoru:][yoru kao=0 ]
「…………好了。你们当前的目标是说服杰特、[rhr]
_　以及让杰特与宙两人下车」[rhp]
[:yoru:]
「但遗憾的是，这恐怕很困难」[rhp]

[off_all]

[chara_part name="hati" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:heartshape:]
「！　为什么啊！？」[rhp]

[:yoru:]
「将杰特的精神从这个世界驱逐出去很简单。但精神体非常脆弱。[rhr]
_　很可能在获得解放到返回肉体的途中就消散了」[rhp]
[:yoru:]
「如果和宙一样，肉体在临终关怀院就没事。[rhr]
_　但杰特的肉体现在偏偏在主楼。距离实在太远了」[rhp]

[off_hati]

[chara_part name="riri" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="true" time=150]

[:quadrillion:]
「真蠢呢。为什么要特意把人家转移走啊」[rhp]

[:yoru:]
「是我向武建议的。……杰特的身体已经到了末期状态。[rhr]
_　不能指望植物人状态能一直支撑下去」[rhp]

[:quadrillion:][riri kao=0 ]
「哎呀。意外的温柔呢」[rhp]

[:yoru:][yoru kao=2 ]
「他现在的状况完全是南的罪孽。[rhr]
_　我只是不想让他通过死亡逃避，减少南赎罪的机会」[rhp]

[off_riri]
[chara_part name="peku" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="152" top="0" wait="true" time=150]

[:vulpecula:]
「我说啊，要是变成那个什么精魂无散的状态会怎样？」[rhp]

[:yoru:][yoru kao=12 ]
「维持现状。但苏醒的可能性会永远消失。[rhr]
_　只会留下肉体与灵魂在现世，慢慢等待寿命终结吧」[rhp]
[:yoru:]
「因为是第一次做这种蠢事，所以没法断言……」[rhp]

[off_peku]
[chara_part name="hakase" body=base kao=0 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="true" time=150]

[:darknebula:]
「只要肉体和精神移动距离短就没问题对吧[rhp]
[:darknebula:]
「说到这个，杰特的精神回归之处[rhr]
_　只要有你在旁边陪着，其实不一定要在临终关怀院对吧？」[rhp]

[:yoru:][yoru kao=2 ]
「确实如此……但你该不会是想…」[rhp]

[:darknebula:][hakase kao=1 ]
「嗯　很简单。如果距离太远导致杰特难以转移的话[rhr]
_　让夜去主楼不就行啦」[rhp]

[off_all]
[chara_part name="peku" body=base kao=4 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="355" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=4 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:2nin:]
「原来如此！」[rhr]
「原来如此！」[rhp]

[off_all]

[chara_part name="sora" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:yoru:]
「徒劳。只要那幅绘画还挂着，我就无法离开临终关怀院」[rhp]

[:sora:]
「那把画搬到主楼不就好了嘛」[rhp]

[:yoru:]
「『糠星夜』是幅宽2米、高1.5米的巨作。[rhr]
_　像我这样庞大的身躯，谁能搬得动……」[rhp]
[:yoru:][yoru kao=6 as=on ]
「…………啊」[rhp]

[off_sora]

[chara_part name="kite" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]

[:kite:]
「这里可有两位壮年男性呢」[rhp]

[:yoru:]
「那是……不，但是」[rhp]

[off_all]

[chara_part name="riri" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="30" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="293" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="720" top="0" wait="true" time=150]

[:quadrillion:]
「现在不是磨蹭的时候。是男人就给我下定决心」[rhp]

[:vulpecula:]
「就是啊夜夜！要是那么在意体重的话，[rhr]
_　之后减肥雪耻不就好了嘛！」[rhp]

[:yoru:]
「绘画要怎么减肥。削掉吗？」[rhp]

[off_all]

[chara_part name="sora" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sora:][sora kao=2 ]
「在这种地方害羞也没用吧。[rhr]
_　再这样下去大家都会完蛋。你让大家全部下车的目的也达不成了」[rhp]

[:yoru:][yoru kao=0 ]
「才没有害羞。[rhr]
_　……够了明白了。做就行了吧，我做！」[rhp]

[off_sora]
[chara_part name="hakase" body=base kao=1 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="true" time=150]

[:darknebula:][hakase kao=1 as=on ]
「强人所难真是抱歉。[rhr]
_　但大概，也只有这个方法可行了……」[rhp]

[:yoru:][yoru kao=6 as=on ]
「脑海里已经浮现出千秋他们不情愿的脸了……」[rhp]

[off_all]

[:princess:][puri_w kao=0 ]
「啊……可那样的话，杰特君醒之前还好说，[rhr]
_　要怎么避免夜和南被烧死呢？」[rhp]

[:heartshape:][hati kao=6 ]
「确实。暴怒的杰特绝对会动真格的。[rhr]
_　要想说服那家伙，比现在的夜还要费劲得多」[rhp]

[off_puri]

[:yoru:][yoru kao=12 ]
「…………、说到底就算被他烧死我也无所谓」[rhp]

[:heartshape:][hati kao=2 as=on ]
「哈……！？你是认真的吗？」[rhp]

[:yoru:][yoru kao=2 ]
「比起那个，该回归的生命滞留在此才是问题。[rhr]
_　只要你们能乖乖离开这个世界就够了」[rhp]
[:yoru:]
「虽为方便起见被称为『死亡』，[rhr]
_　但将像我这样的存在称作『活着』本就是谬误」[rhp]
[:yoru:]
「作为超自然存在的我，本质上可说是某种概念。[rhr]
_　所以你们无需担忧我和南的生死」[rhp]

[off_all]

[chara_part name="hakase" body=base kao=2 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="riri" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:quadrillion:]
「你这人，别摆着副冷静脸说这么离谱的话」[rhp]

[:darknebula:]
「即便是概念，也是有意志的存在。岂能轻易忽视」[rhp]

[off_all]

[:yoru:][yoru kao=0 ]
「……夸德里利昂、达克内布拉、哈托谢普。[rhr]
_　把作为替补的你们牵连进来，我深感歉疚」[rhp]
[:yoru:]
「但我还是要说。最坏的情况下，我会舍弃这个世界。[rhr]
_　届时就请你们连同这个世界，与我一同消失吧」[rhp]

[off_all]

[chara_part name="hakase" body=base kao=0 as=on ss=off hh=off hr=on msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:]
「博士，会死吗……？」[rhp]

[:darknebula:][hakase kao=1 ]
「这个嘛……」[rhp]

[off_all]

[chara_part name="riri" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:quadrillion:]
「…………唉。不过这种事[rhr]
_　我早料到迟早会发生，倒也不算特别震惊」[rhp]

[:heartshape:]
「……………………」[rhp]

[:quadrillion:][riri kao=7 ]
「你也真是够倒霉的，哈托谢普。[rhr]
_　和我不同，你明明好不容易和杰特相处得很好」[rhp]

[:heartshape:]
「……………………」[rhp]
[:heartshape:][hati kao=2 ]
「…………、你们都在说什么啊」[rhp]

[off_all]

[:princess:][puri_w kao=1 ]
「哈蒂君？」[rhp]

[off_all]

[:heartshape:][hati kao=2 ]
「为什么大家都对他这么纵容。[rhr]
_　他复活这件事和夜还有南会死根本没关系吧！」[rhp]
[:heartshape:]
「好好沟通说服他不就行了。[rhr]
_　对照顾我们到现在的南和夜做这种事，太不像话了吧！」[rhp]

[off_all]

[chara_part name="yoru" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:yoru:]
「能做到的话就不用这么辛苦了。也不会变成现在这样」[rhp]

[:heartshape:]
「求你了夜。这里交给我吧。我会说服那家伙的。[rhr]
_　所以夜你也别轻易说什么死了也无所谓的话」[rhp]
[:heartshape:]
「……这种错误的事，那家伙应该也察觉到了」[rhp]

[:yoru:]
「………会很棘手啊」[rhp]

[:heartshape:][hati kao=1 ]
「看我把他揍得粉身碎骨！不过我是绝对不会输的！[rhr]
_　顺便把落合也赶下车！」[rhp]

[off_all]

[:sora:][sora kao=3 ]
「……没想到会变成这样。[rhr]
_　早知道就不该对杰特说那种话」[rhp]

[:kite:][kite kao=1 ]
「俗话说后悔莫及嘛」[rhp]

[:sora:][sora kao=6 as=on ]
「烦死了！」[rhp]

[:kite:][kite kao=13 ]
「嘛，下车前我们还是好好相处吧挚友」[rhp]
[:kite:]
「等到离开这里的时候，我们一定也会一起走的」[rhp]

[:sora:][sora kao=0 as=on ]
「……！」[rhp]

[:kite:][kite kao=1 ]
「[player3]大概会说从这里下去吧。……你不这么认为吗？」[rhp]

[:sora:][sora kao=3 ]
「…………如果真是那样就糟糕了」[rhp]
[:sora:]
「要是从这个画中世界出去的话，大家就全都无处可寻了。[rhr]
_　到时候就会体会到另一种绝望」[rhp]

[off_all]

[chara_part name="kite" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="riri" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:kite:]
「啊——没救了这个。正处于丧到极点的时期」[rhp]

[:quadrillion:]
「我说你啊。别管那些家伙就行了。[rhr]
_　我们只需要顺其自然就好」[rhp]
[:quadrillion:][riri kao=1 ]
「哈托谢普肯定会想办法的。[rhr]
_　在涉及杰特的事情上，那家伙还是值得信任的」[rhp]

[:kite:][kite kao=1 ]
「是啊……反正平时也没少给他添麻烦？」[rhp]
[:kite:][kite kao=13 ]
「最后能轰轰烈烈大闹一场就好了」[rhp]

;****************************************
[set_b storage="train_01.jpg"]
;****************************************

[::]
谈话暂且告一段落后，我们暂时解散了。[rhp]

下一个目的地按照哈蒂君的意愿定了下来。[rhp]
这本该是我们日常旅行计划中要造访的地方，[rhr]
为什么会变成现在这样呢。[rhp]
我正坐在客舱里出神地思考着这些事时……[rhp]

[:heartshape:][hati kao=1 ]
「哟！公主！」[rhp]

[:princess:][puri_w kao=0 ]
「哈蒂君……」[rhp]

[off_all]

[::]
带着爽朗笑容向我搭话的哈蒂君，在我对面的座位坐了下来。[rhr]
突然露出担忧的表情盯着我看。[rhp]

[:heartshape:][hati kao=1 ]
「表情很阴沉啊。怎么了？」[rhp]

[:princess:][puri_w kao=3 ]
「无所谓怎样不怎样啦。只是对将来的事感到不安……」[rhp]

[:heartshape:][hati kao=5 as=on ]
「是啊。刚才还说什么要去说服杰特！[rhr]
_　虽然说了这种大话。其实我也一样」[rhp]
[:heartshape:]
「我……其实有点害怕啊」[rhp]

[off_all]

[::]
这么说着，哈蒂君微微低下了头。[rhp]

[:heartshape:][hati kao=3 ]
「…………我，喜欢公主。[rhr]
_　以前只要考虑杰特的事就行了，但现在不一样了」[rhp]
[:heartshape:]
「本来除了最重要的东西其他都可以舍弃，[rhr]
_　现在却有了你这个第二顺位。而且还是微小差距」[rhp]
[:heartshape:]
「两个都很重要，两个都难以割舍」[rhp]

[:princess:][puri_w kao=2 as=on ]
「为什么？明明没必要舍弃啊。[rhr]
_　第一位的杰特君和第二位的我，两个都好好珍惜不就行啦」[rhp]
[:princess:][puri_w kao=6 as=on ]
「啊、说着说着有点害羞了呢……」[rhp]

[:heartshape:]
「不是的。要舍弃哪边之类的，我害怕的不是这种事」[rhp]
[:heartshape:]
「……我想过了。可能真如杰特所说，[rhr]
_　想让杰特回去其实是出于我自己的私心」[rhp][rhp

[:princess:][puri_w kao=0 ]
「！」[rhp]

[:heartshape:]
「我知道杰特的肉体与精神所在存在距离。[rhr]
_　那家伙下车后会怎样，我从一开始就知道了」[rhp]
[:heartshape:]
「尽管如此我还是没多想，仅仅因为『希望他这么做』[rhr]
_　就让杰特回去什么的……要是我点头了，他说不定已经死了」[rhp]
[:heartshape:]
「如果没有博士的方案，我可能已经把杰特杀掉了……[rhr]
_　所以说不定，其实真如杰特所说的那样」[rhp]
[:heartshape:]
「因为有公主在所以不想消失。为此[rhr]
_　潜意识里我想把不安因素的杰特从这个世界上抹消……」[rhp]

[:princess:][puri_w kao=3 ]
「哈蒂君……」[rhp]

[:heartshape:]
「再这样下去最坏的结局是肯定的。[rhr]
_　所以我要阻止杰特。但不确定这是不是最佳方案」[rhp]

[:princess:][puri_w kao=1 ]
「…………，哈蒂君是希望杰特君活着的吗？」[rhp]

[:heartshape:][hati kao=2 as=on ]
「呃！那还用说！杰特就是我的命啊！」[rhp]

[:princess:][puri_w kao=14 ]
「呵呵……！秒答呢！那一定就是答案了」[rhp]
[:princess:]
「刚才那句话，一定就是你的答案。[rhr]
_　只要怀着这份强烈的心意，肯定也能传达给哈蒂君的」[rhp]
[:princess:][puri_w kao=1 ]
「好好沟通吧。绝对没问题的。[rhr]
_　杰特君和南和夜和落合君，大家都能获得幸福的」[rhp]
[:princess:]
「然后当然，哈蒂君也是」[rhp]

[:heartshape:][hati kao=0 ]
「公主……」[rhp]
[:heartshape:][hati kao=1 ]
「…………、……你有点变了呢」[rhp]

[:princess:][puri_w kao=0 as=on ]
「诶……这、这样吗？」[rhp]

[:heartshape:]
「该怎么说，比起以前说话更有分量了……[rhr]
_　感觉更有说服力了！」[rhp]

[:princess:][puri_w kao=1 ]
「我、我也不太清楚……与其说是我变了，[rhr]
_　倒不如说是哈蒂君你变了吧」[rhp]

[:heartshape:][hati kao=0 ]
「我吗？」[rhp]

[:princess:][puri_w kao=1 ]
「以前你总是最先考虑『杰特君会怎么想』。[rhr]
_　但现在极端来说，哈蒂君你是处在和杰特君对立的立场上啊」[rhp]
[:princess:]
「因为不需要顾虑杰特君，哈蒂君你自己认可了我的话，[rhr]
_　所以听起来才会觉得比以往更有说服力吧」[rhp]

[:heartshape:][hati kao=0 ]
「这样啊……」[rhp]

[:princess:][puri_w kao=13 as=on hh=on ]
「我、我也不确定啦！说了些自以为是的话」[rhp]

[:heartshape:][hati kao=3 ]
「…………、不，谢了。确实如你所说」[rhp]
[:heartshape:]
「我一直只想着让杰特在这里过得开心，[rhr]
_　几乎没认真考虑过自己真正想要什么」[rhp]
[:heartshape:]
「所以才会害怕这种处境，公主的话才格外扎心」[rhp]

[:princess:][puri_w kao=1 ]
「哈蒂君……」[rhp]

[:heartshape:]
「……呐公主。……这样可以吧？我没有错吧？[rhr]
_　我就算……对杰特，也应该可以坚持自己意见的吧」[rhp]

[:princess:][puri_w kao=1 ]
「当然！谁都不能阻拦你」[rhp]
[:princess:]
「哈蒂君不是杰特君的影子，而是并肩而立的搭档哦」[rhp]

[:heartshape:][hati kao=14 ]
「嘿嘿……是啊！」[rhp]
[:heartshape:][hati kao=1 ]
「……！　啊、对了」[rhp]
[:heartshape:]
「虽然说过从没为自己考虑过，但那个啊。[rhr]
_　喜欢公主的心情，毫无疑问是我的本意！」[rhp]

[:princess:][puri_w kao=4 ]
「！！」[rhp]

[:heartshape:][hati kao=11 ]
「虽然曾经顾虑过杰特，[rhr]
_　但那家伙推了我一把才能坦然面对这份感情……」[rhp]
[:heartshape:][hati kao=14 ]
「……嗯！果然杰特最棒了，也最喜欢公主了！[rhr]
_　我一定会开辟出让所有人都幸福的道路！」[rhp]

[:princess:][puri_w kao=14 hh=on ]
「嗯、嗯……！　哎嘿嘿」[rhp]

[:heartshape:][hati kao=5 ]
「好！事情就这么定了，差不多该做登陆准备了！」[rhp]

[:princess:][puri_w kao=0 ]
「话说回来，我们接下来计划去哪里？」[rhp]

[off_all]

[:heartshape:]
「呵呵呵。那是――――――」[rhp]

;****************************************
[fbgm]
[bg_b storage="train_05.jpg"]
[bgm storage="bgm_13.ogg"]
;****************************************

[::]
由于南回归现实世界，观景车厢里只剩我一人。[rhp]
倒也说不上寂寞。[rhr]
本来我就是更习惯独处的人。[rhp]

[:jet:]
「…………」[rhp]

[::]
――――――『我在那边也是一个人哦』[rhp]

[:jet:][jet kao=2 ]
「……啧…………」[rhp]
[:jet:]
「………………那又算什么啊……」[rhp]

[off_all]

[::]
明明连人类都不是，却会觉得寂寞吗？[rhr]
难不成还要怪我吗……[rhp]
我像要避开南消失的地方似的，转身就走。[rhr]
虽然并无明确目的，但实在无法静静待着……[rhp]

[:jet:][jet kao=0 ]
「…………！」[rhp]

[off_all]

[::]
当视线不经意扫向门扉的瞬间，我猛地抖了下肩膀。[rhr]
看见哈蒂站在连接观景车厢与特等车厢的通道里。[rhp]
这铁道只要完成初始操作就会转为自动驾驶。[rhr]
明明几乎没实践机会却手法娴熟，真叫人来气。[rhp]
是来看我的状况，还是来告知这铁道的终点呢。[rhr]
这边有南的结界他才进不来吧。[rhp]

;****************************************
[bg storage="sky_11.jpg" time=1000]
;****************************************

―――必须在下次着陆时分个胜负。[rhp]

再拖下去南肯定也不会给好脸色，[rhr]
到那时就不知道还会站在我这边多久了。[rhp]
最重要的是，我不开心。明明是为逍遥快活才来这里的，[rhr]
要是困在这儿岂不本末倒置。[rhp]

;****************************************
[bg storage="train_05.jpg" time=1000]
;****************************************

故意无视频频看向这边的哈蒂，[rhr]
我粗鲁地瘫在观景室的座椅上。[rhp]

;****************************************
[bg storage="black.jpg" time=1000]
;****************************************

闭上眼睛。......毫无睡意。[rhp]
这种前所未有的焦躁感究竟算什么。[rhp]
对哈蒂的恼火。[rhr]
以及......对未来的不安。[rhp]
…………不安？[rhp]
难道你觉得我会被哈蒂说得哑口无言吗。[rhr]
绝无可能，真是愚蠢的杞人忧天。[rhp]

[:jet:]
「…………我是正确的」[rhp]

[::]
为获得幸福而活着是天经地义的权利。[rhr]
照顾他人这种事，让那些已经幸福到有余力的人去做就好。[rhp]
我很不幸。[rhp]
唯独这一点绝对不会有错。[rhp]

;****************************************
[fbgm]
[set_b storage="real_01.jpg"]
; 夜フィルター
[filter layer="1" brightness="60"]
[bgm storage="bgm_15.ogg"]
;****************************************

铁道缓缓减速，抵达了那个地方。[rhp]
刚踏出一步，就被从未感受过的凛冽空气惊得浑身一颤。[rhp]
这究竟是什么景象。虽然满是积雪但……[rhp]

[:princess:][puri_w kao=0 ]
「这里是……」[rhp]

[:heartshape:][hati kao=0 ]
「北海道」[rhp]

[:princess:]
「居然这么具体呢。平时你总是只有模糊的概念」[rhp]

[:heartshape:][hati kao=3 ]
「中学修学旅行。那家伙没能去成。」[rhp]

[off_all]

[::]
哈蒂君简短回答后，凝望着银装素裹的世界。[rhr]
他紧紧抿着嘴唇，神情既似寂寞又像感动。[rhp]
……事到如今，哈蒂君究竟打算做什么呢？[rhp]
忽然听见背后传来夸张的叹息声。[rhp]

[chara_part name="riri" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:quadrillion:]
「唉——为什么又是这种鬼地方……本小姐就在这儿等着」[rhp]

[:kite:]
「我也弃权。留在车里。」[rhp]

[off_kite]

[chara_part name="peku" body=hood kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:]
「那佩奇和博士就堆雪人咯——！」[rhp]

[:quadrillion:]
「不行」[rhp]

[:vulpecula:][peku body=hood kao=6 ]
「为什么嘛～！明明好不容易有雪的说～！」[rhp]

[:quadrillion:][riri kao=13 ]
「能在这种地方胡闹的只有红白了。[rhr]
_　被炉里吃的冰淇淋可美味啦～？要一起吃吗？」[rhp]

[:vulpecula:][peku body=hood kao=14 hh=on ]
「要吃～！」[rhp]

[off_all]

[:darknebula:][hakase kao=1 msk=hat ]
「对我来说，在这全新雪原上留下足迹的体验更......」[rhp]

[:kite:][kite kao=12 ]
「不行哦博士。今天的我们是看家的」[rhp]

[off_all]

[chara_part name="riri" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="30" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="760" top="0" wait="true" time=150]

[:quadrillion:]
「早就受够那种空气了。给我好好做个了断回来」[rhp]
[:quadrillion:][riri kao=12 ]
「对我来说结果怎样都无所谓。[rhr]
_　红队赢也好白队赢也好，接受现实就是了」[rhp]

[:kite:]
「同上。和往常一样，哈蒂想怎么闹都行」[rhp]

[:heartshape:]
「其实也不是什么胜负之争啦......」[rhp]

[off_all]

[chara_part name="hati" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=0 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「话说回来，关键的杰特君呢？[rhr]
_　不用去叫他吗？」[rhp]

[:heartshape:]
「杰特已经察觉了。......而且绝对会来。[rhr]
_　那家伙看着那样其实很好胜啊」[rhp]

[off_puri]

[:sora:][sora kao=2 ]
「......哈托谢普。别做出半吊子的举动」[rhp]
[:sora:]
「我和杰特都不是抱着半吊子的心情来这里的。[rhr]
_　字面意思，我和杰特都是抱着必死的决心来的」[rhp]

[:heartshape:][hati kao=2 ]
「......我知道。即便如此我也会贯彻自己的心意。[rhr]
_ 我希望那家伙能活下去。……你也是。落合」[rhp]
[:heartshape:]
「你和杰特君都还有可能性」[rhp]

[:sora:][sora kao=2 ]
「虽然我不确定自己怎样，但你能对杰特君说同样的话吗。[rhr]
_　因为那家伙已经……」[rhp]

[:heartshape:][hati kao=14 ]
「能说！那小子有我这个确切的希望啊！」[rhp]

[:sora:][sora kao=6 ]
「说什么胡话……好吧，我等着看。你能做到什么程度」[rhp]

[:heartshape:][hati kao=13 ]
「噢！给我擦亮眼睛看着吧！」[rhp]

[off_all]

[:heartshape:][hati kao=1 ]
「……那我出发了！」[rhp]

[off_all]

[::]
这样宣告后，哈蒂君转身离去。[rhp]
只听得见他踩雪声的世界。片刻后他停下脚步，[rhr]
雪原中央的哈蒂君沉默着，肩膀剧烈起伏呼吸。[rhp]
众人在电车中，而我站在下车处，注视着他的前行。[rhp]

;****************************************
[se storage="mag_06.ogg"]
[bg storage="white.jpg" time=500]
;****************************************

[::]
稍顷，哈蒂君眼前开始聚集光之粒子。[rhr]
就像南和多洛普常使用的魔法。[rhp]
光芒从虚空中诞生，眩目地笼罩四周。[rhp]
当再次睁开眼睛时。[rhr]
空无一物的地方，杰特君的身影显现了。[rhp]

;****************************************
[still storage="cg/d_h_1.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/d_h_1.png"]
;****************************************

;--------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;--------------------------------------------------------------------------------------------

[:heartshape:]
「……我料到你会来」[rhp]

[:jet:]
「看你想说话的样子，勉强奉陪」[rhp]
[:jet:]
「……听说你有话要对我说」[rhp]

[:heartshape:]
「…………，我想再说一次」[rhp]
[:heartshape:]
「杰特。快从火车上下来」[rhp]

[:jet:]
「烦死了。要说多少遍才够，真缠人」[rhp]

[:heartshape:]
「……、你的心情我明白」[rhp]

[:jet:]
「你不明白」[rhp]
[:jet:]
「就算你是我又怎样。……你懂什么啊」[rhp]
[:jet:]
「你从出生到现在，从来都没有被任何事打败过吧」[rhp]

;****************************************
#
[bg storage="cg/d_h_1b.png" width="1280" height="720" time=500]
[cg storage="cg/d_h_1b.png"]
;****************************************

[:heartshape:]
「………呃！」[rhp]

[:jet:]
「……『多么可怜的杰特』」[rhp]

[:heartshape:]
「诶……」[rhp]

[:jet:]
「因为疾病一直被困在房间里，什么都做不成。[rhr]
_　在这里过得有多幸福更是不用说」[rhp]
[:jet:]
「即使这样我还是希望你能活下去。[rhr]
_　不要放弃人生。相信奇迹回来吧！」[rhp]
[:jet:]
「……话说」[rhp]

[:heartshape:]
「为、为什么……」[rhp]

[:jet:]
「想说教的话很遗憾。我完全知道你在想什么」[rhp]
[:jet:]
「但是啊，哪有听了这种肉麻台词就回去的蠢货。[rhr]
_　别把我和你混为一谈」[rhp]
[:jet:]
「我虽然是你，不过是劣化版。[rhr]
_　可不是会被这种漂亮话打动心灵的家伙―――」[rhp]

;****************************************
#
[fbgm]
[bg storage="cg/d_h_1c.png" width="1280" height="720" time=500]
[cg storage="cg/d_h_1c.png"]
;****************************************

[:heartshape:]
「………………」[rhp]

[:jet:]
「……诶」[rhp]

;****************************************
[still storage="cg/d_h_2.png" width="1280" height="720" time=500]
[cg storage="cg/d_h_2.png"]
[bgm storage="bgm_13.ogg"]
;****************************************

[:jet:]
「哎、哈、哈蒂？为、为什么……」[rhp]

[:heartshape:]
「…………因为你说得对」[rhp]
[:heartshape:]
「让你说出那些话，我很难受」[rhp]

[:jet:]
「……！」[rhp]

[:heartshape:]
「……因为生病一直出不了房间」[rhp]
[:heartshape:]
「无论是朋友还是曾经喜欢的人，都产生了距离。[rhr]
_　但无论如何努力都无法由自己填补」[rhp]
[:heartshape:]
「明明认真接受治疗，病症却依然没有好转」[rhp]
[:heartshape:]
「好不容易考上的高中，开学典礼前就被列为休学处理」[rhp]
[:heartshape:]
「………………现在有多么幸福，自不必说」[rhp]

[:jet:]
「…………烦人的家伙。别深挖啊」[rhp]

[:heartshape:]
「因为我是你的影子。[rhr]
_　其实根本没有资格对你说三道四」[rhp]
[:heartshape:]
「即便如此我还是希望你能活着」[rhp]
[:heartshape:]
「因为你是搭档，是挚友……是你啊」[rhp]

[:jet:]
「……无、无论你说什么这根本就做不到！」[rhp]
[:jet:]
「听见了吧？就算我现在回去，原本的身体也……」[rhp]

[:heartshape:]
「多亏宙为我想了各种办法，才能免于一死」[rhp]

;****************************************
#
[bg storage="cg/d_h_2b.png" width="1280" height="720" time=500]
[cg storage="cg/d_h_2b.png"]
;****************************************

[:jet:]
「…………可是」[rhp]

[:heartshape:]
「虽然这么说可能又会被你嘲笑……」[rhp]
[:heartshape:]
「杰特。相信奇迹，再努力一次吧」[rhp]

[:jet:]
「…………不要」[rhp]

[:heartshape:]
「没关系。已经什么都不用放弃了」[rhp]
[:heartshape:]
「我也会陪你一起去的」[rhp]

[:jet:]
「………………啥？」[rhp]

;****************************************
#
[bg storage="real_01.jpg" time=500]
;****************************************

[:princess:][puri_w kao=4 as=on ]
「哎……！？」[rhp]

[off_all]

;****************************************
[still storage="cg/d_h_3.png" width="1280" height="720" time=500]
[cg storage="cg/d_h_3.png"]
;****************************************

[:jet:]
「一……一起、是说……」[rhp]

[:heartshape:]
「和公主还有快斗一样。把本尊和替身融为一体」[rhp]
[:heartshape:]
「这样的话 肯定连活下去都不会害怕了」[rhp]
[:heartshape:]
「已经不用再独自硬撑了。[rhr]
_　我会替你承担这份痛苦」[rhp]

[:jet:]
「你……你在胡说什么！！这种事情怎么可能办得到！？」[rhp]
[:jet:]
「我不要你消失！绝对不要你死！」[rhp]

[:heartshape:]
「杰特……」[rhp]

[:jet:]
「呃……！啊……不、不要……」[rhp]

[:heartshape:]
「……哈哈。被发现了吗。确实我不想死啊」[rhp]
[:heartshape:]
「所以 我要和你一起活下去」[rhp]

[:jet:]
「不是这个意思……！」[rhp]

[:heartshape:]
「不用担心啦。[rhr]
_　你不是说过 想成为我这样的人吗」[rhp]
[:heartshape:]
「绝对能实现的。有我陪着你」[rhp]
[:heartshape:]
「我一定会引导你 成为你想成为的模样」[rhp]


;****************************************
[still_end frame="win.png" storage="real_01.jpg" time=1000]
;****************************************

[:heartshape:]
「…………」[rhp]

[::]
他边说边擦掉眼泪，杰特君转头望向我们。[rhp]

[:heartshape:][hati kao=14 ]
「―――就是这么回事！」[rhp]
[:heartshape:]
「我要在这里和杰特一起下车啦！」[rhp]

[off_all]

[:jet:][jet kao=2 as=on ]
「！？等……！话还没说――」[rhp]

[off_all]

[:heartshape:][hati kao=5 ]
「就算这家伙反对我也决定了！」[rhp]
[:heartshape:]
「无论如何我都要让杰特活下去！[rhr]
_　作为奇迹之男登上全球新闻啊！」[rhp]
[:heartshape:][hati kao=14 ]
「所以大家！尽管放心吧！」[rhp]

[off_all]

[:princess:][puri_w kao=8 as=on ]
「…………哈蒂君说要一起的话。[rhr]
_　那不就意味着要和杰特君合为一体了吗……？」[rhp]

[off_all]

[::]
那样的话，用魔法创造的哈蒂君想必就会消失吧。[rhp]
…………真想挽留他。[rhr]
哈蒂君要消失这种事，怎么能……[rhp]

[:princess:]
[font color=0x4682b4]
（……不过，肯定行不通的吧）[rhp]
[resetfont]

[::]
哈蒂君一旦说出口的事，就绝不会停下。[rhp]
我就是喜欢这样的哈蒂君。[rhp]
…………曾经是那么喜欢。[rhp]

[:heartshape:][hati kao=1 ]
「公主！」[rhp]

[off_all]

[::]
呼唤着我的名字，哈蒂君深深吸了一口气。[rhp]

[:heartshape:][hati kao=13 ]
「对不起！！擅自做了这么多决定！」[rhp]
[:heartshape:]
「虽然要让你独自留下但没问题的吧！[rhr]
_　公主可是我迷上的、比任何人都强大帅气的女人！」[rhp]

[off_all]

[:princess:][puri_w kao=8 as=on ]
「呜……！说什么呢！别擅自决定啊！」[rhp]
[:princess:]
「我还……唔、想更多和你……！」[rhp]

[off_all]

[fbgm]

;魔法
[bg_magic storage="white.jpg"]

[:princess:]
「呀……！？」[rhp]

[::]
一阵格外强烈的风吹过，细雪簌簌地飞扬起来。[rhp]
因寒意和惊吓不由自主闭上眼睛的我，再度睁开眼时―――[rhp]

;****************************************
[set_w storage="real_02.jpg" time=1000]
[bgm storage="bgm_39.ogg"]
;****************************************

[:vulpecula:]
「哇……！好厉害！」[rhp]

[:darknebula:]
「真美……！」[rhp]

[::]
方才还银装素裹的世界如梦似幻般消散，[rhr]
眼前铺展开春日绚烂的花田。[rhp]
哈蒂君竟能使用这么厉害的魔法。[rhr]
还是说，他一直瞒着我们偷偷练习呢。[rhp]
舞台也好，演出也好，全都考虑周全了。[rhr]
……就是预想着总有一天会迎来这样的日子。[rhp]

;****************************************
[still storage="cg/d_h_4.png" width="1280" height="720" time=1000]
[cg storage="cg/d_h_4.png"]
;****************************************

[:heartshape:]
「提问！」[rhp]

[:princess:]
「…………！」[rhp]

[:heartshape:]
「这顶王冠的花语，是什么？」[rhp]

[:princess:]
「呃……不知道啦，那种事情」[rhp]

[:heartshape:]
「那就算我赢了！」[rhp]

[:heartshape:]
「为我祝福吧！祝福我的胜利。祝福我的启程！」[rhp]
[:heartshape:]
「我绝对会幸福的。拯救杰特，实现愿望……！」[rhp]
[:heartshape:]
「并且一定，还会在这个世界的某处[rhr]
_　与你重逢！我如此坚信着！」[rhp]
[:heartshape:]
「所以这并非离别！」[rhp]
[:heartshape:]
「反而是邂逅！！与诸多希望的邂逅！与所有未来的邂逅！」[rhp]

[:princess:]
「什么嘛……！根本听不懂啊！」[rhp]

[:heartshape:]
「哈哈哈！就是要这样的意境啦！」[rhp]

[:princess:]
「……不能说别走这种话……吗？」[rhp]

[:heartshape:]
「抱歉！不能说！」[rhp]

[:princess:]
「笨蛋……！不说得这么直白也可以啊！」[rhp]

[:heartshape:]
「才不直白！我这可是肝肠寸断的决定……！」[rhp]

[:princess:]
「骗人！」[rhp]

[:heartshape:]
「没骗你！因为我真的曾经很喜欢你！」[rhp]

[:princess:]
「……！」[rhp]

[:heartshape:]
「你是最棒的。比任何人都温柔，比任何人都温暖，还那么帅气！」[rhp]
[:heartshape:]
「能遇见你是我的骄傲！谢谢你，公主！」[rhp]
[:heartshape:]
「……一直一直，最喜欢你了！」[rhp]

[:princess:]
「……」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------
;スチル終了
;****************************************
[still_end frame="win.png" storage="real_02.jpg" time=1000]
;****************************************

[chara_part name="riri" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=11 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:quadrillion:][riri kao=1 ]
「唉呀呀。这是要秀给我看呢……」[rhp]

[:kite:][kite kao=1 ]
「连雪都要被融化了」[rhp]

[off_all]

[:sora:][sora kao=2 ]
「…………唉」[rhp]
[:sora:][sora kao=3 ]
「……虽然早就知道了……还是不甘心啊」[rhp]

[off_all]

[chara_part name="riri" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="sora" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:quadrillion:]
「你，打算怎么办？这种情况」[rhp]

[:sora:][sora kao=12 ]
「我知道的……彻底败北了」[rhp]
[:sora:][sora kao=1 ]
「…………看起来幸福不是挺好的嘛」[rhp]

[off_all]

;--------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;--------------------------------------------------------------------------------------------

[:heartshape:][hati kao=2 ]
「！落合……！说起来还没告诉你呢！」[rhp]

[off_all]

[chara_part name="sora" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:]
「超～级的好处，想听吗！？」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:sora:][p_so_28]
「不必了」[rhp]

;--------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;--------------------------------------------------------------------------------------------

[:heartshape:][hati kao=14 ]
「因为我消失公主就恢复自由之身了！！」[rhp]

[off_all]

[chara_part name="hati" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=2 as=on ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「哈蒂君！！你竟然打着这种算盘！？」[rhp]

[:heartshape:][hati kao=2 as=on ]
「说实话后来有稍微后悔过……！」[rhp]

[:princess:]
「诶！？那为什么，」[rhp]

[:heartshape:][hati kao=2 as=on ]
「就算天各一方我也绝对会继续喜欢你啊……！？」[rhp]

[:princess:][puri_w kao=8 as=on ]
「！！呜、呜呜……！……这种话太狡猾了！」[rhp]

[:heartshape:][hati kao=14 ]
「嘿嘿……！因为我的爱永不灭亡啊！」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:sora:][sora kao=3 ]
「………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:kite:][kite kao=1 ]
「节哀顺变」[rhp]

[:sora:][sora kao=6 ]
「吵死了」[rhp]
[:sora:][sora kao=12 ]
「……不过，被明确拒绝反而清爽了。或许反倒是好事」[rhp]

[off_all]

[chara_part name="hakase" body=base kao=1 as=off ss=off hh=off hr=on msk=hat ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="sora" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:darknebula:]
「人的心意始终都在不断变化」[rhp]

[:sora:][sora kao=0 as=on ]
「……！八云君……、……博士」[rhp]

[:darknebula:][hakase kao=1 msk=hat ]
「从始至终保持相同心意这种事，[rhr]
_　其实可能是非常困难的事呢」[rhp]

[:sora:][sora kao=1 ]
「…………由你来说，还真有说服力」[rhp]

[:darknebula:][hakase kao=0 msk=hat ]
「？　什么意思？」[rhp]

[:sora:][sora kao=11 ]
「没什么」[rhp]
[:sora:][sora kao=5 ]
「……难得给我建议。我会老实听的」[rhp]

[off_all]

[:sora:][sora kao=0 ]
「公主」[rhp]

[:princess:][puri_w kao=0 as=on ]
「落合君……」[rhp]

[:sora:][sora kao=12 ]
「……打扰你们旅行真是抱歉」[rhp]

[:princess:][puri_w kao=8 as=on ]
「没在意啦。……比起这个，接下来要怎么办？[rhr]
_　还想继续留在这里的……」[rhp]

[off_all]

[::]
中途的话语，被他单手举到面前的手截断。[rhr]
不必再多说了——就是这样的意思。[rhp]
落合君的心意，似乎早已决定了。[rhp]

[:sora:][sora kao=12 ]
「我也要和杰特他们一起回去」[rhp]

[:princess:][puri_w kao=0 as=on ]
「――――――！　真的吗？」[rhp]

[:sora:][sora kao=1 ]
「啊。已经没有留恋了」[rhp]

[:princess:][puri_w kao=13 ]
「太好了……！　你能回心转意真的太好了！」[rhp]

[:sora:]
「啊……」[rhp]
[:sora:][sora kao=11 ]
「……那么，该出发了吧」[rhp]

[:princess:][puri_w kao=4 as=on ]
「诶、现在就走？」[rhp]

[:sora:][sora kao=6 ]
「不是。只有我先走」[rhp]
[:sora:][sora kao=0 ]
「……多洛普。受他照顾了吧？[rhr]
_　不是最该和他道别的家伙吗」[rhp]

[off_all]

[::]
据落合君说，他要先与现实世界的多洛普再次交换身体，[rhr]
似乎是要给我时间与他道别。[rhp]
落合君还是那样干脆利落的说话方式，[rhr]
让我想起上次分别时的场景。......这次应该能好好道别了。[rhp]

[:sora:][sora kao=3 ]
「夜」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:yoru:][yoru kao=12 ]
「………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[chara_part name="sora" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sora:]
「就是这么回事。拜托了出租车」[rhp]

[:yoru:]
「......对于被你的任性耍得团团转，两次都深受其害的我，[rhr]
_　连句道歉都没有 还要被叫做出租车？」[rhp]

[:sora:][sora kao=11 ]
「对不起啦」[rhp]

[:yoru:]
「也太敷衍......！　都怪你浪费了多余的灵力，[rhp]

[:sora:][sora kao=3 ]
「还真是抱歉啊」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:yoru:][yoru kao=6 as=on ]
「！」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sora:]
「......结果还是要回去了」[rhp]

[:yoru:][yoru kao=12 ]
「............，......这样啊」[rhp]

[:sora:]
「很老土吗？」[rhp]

[:yoru:]
「超级老土」[rhp]
[:yoru:][yoru kao=1 ]
「......不过，表情还不错」[rhp]

[:sora:][sora kao=13 ]
「是吗。那就好......」[rhp]

[off_all]

;****************************************
#
[se storage="mag_08.ogg"]
[bg storage="white.jpg" time=1500]
;****************************************

[::]
落合君似乎终于释怀了。[rhr]
随着他的回应，他与夜的周身开始发光。[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:sora:]
「――――――[player3b]！」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[::]
光芒中传来落合君失真的喊声。[rhp]

[:sora:]
「我啊......！　可是合格了的！」[rhp]

[off_all]

[::]
不明就里的我望向落合君的脸。[rhr]
他挂着马上就要哭出来的表情，拼命想向我传达什么。[rhp]
仿佛下一秒就会消失在彼岸世界的落合君的话语[rhr]
我拼命侧耳倾听，生怕漏掉只言片语。[rhp]

[:sora:]
「[player2]的『梦想』，我一直都知道哦！[rhr]
_　就算现在告诉你，你大概也不明白吧……」[rhp]
[:sora:]
「你的那份梦想，就由我来替你实现！我一定会成为出色的医生！」[rhp]


[:princess:]
「………………！」[rhp]

[::]
属于我的那份。[rhp]
我的梦想。[rhp]
我留在人世间的执念。[rhp]
――――――仿佛听到钥匙咔嗒转动的声响。[rhp]

;****************************************
[s_mask color="0xffffff" time=250]
@layopt layer=message0 visible=false
[s_mask_off time=250]
;****************************************

;これまでのスチルとか通常シーンのスクショを走馬灯的に連続再生
;最後だけ回想シーンとして

[bg storage="hsps_02.jpg" time=100]
[bg storage="cg/b2_1.png" time=100]
[bg storage="hsps_03.jpg" time=100]
[bg storage="cg/c_1.png" time=100]
[bg storage="hsps_05.jpg" time=100]
[bg storage="cg/c_2.png" time=100]
[bg storage="hsps_06e.jpg" time=100]
[bg storage="cg/c_4.png" time=100]
[bg storage="hsps_07.jpg" time=100]
[bg storage="cg/d_r_1.png" time=100]
[bg storage="hsps_08e.jpg" time=100]
[bg storage="cg/d_d4_1.png" time=100]
[bg storage="hsps_09n.jpg" time=100]
[bg storage="white.jpg" time=100]

@layopt layer=message0 visible=true

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:sausu:]
『被曾经最珍视的伙伴们环绕着，你一定会[rhr]
_　成为迄今为止最幸福的自己』[rhp]
[:sausu:]
『到那时，就把记忆还给你』[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

;****************************************
#
[s_mask color="0xffffff" time=1000]
[still storage="cg/d_h_5.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/d_h_5.png"]
[s_mask_off time=1000]
;****************************************

[:princess:]
「――――――……」[rhp]

[::]
一滴泪珠滚落下来。[rhp]
我想起来了。[rhp]
我的梦想。落合君的……[rhp]
……还有宙君的梦想。[rhp]

[:princess:]
「恭、恭喜……！」[rhp]

;****************************************
#
[bg storage="cg/d_h_6.png" width="1280" height="720" time=500]
[cg storage="cg/d_h_6.png"]
;****************************************

[:sora:]
「诶……」[rhp]

[::]
这句话率先脱口而出。[rhp]
自此便再也停不下来。[rhp]

;****************************************
[bg storage="cg/d_h_5b.png" width="1280" height="720" time=500]
[cg storage="cg/d_h_5b.png"]
;****************************************

[:princess:]
「大学……！考上真是太好了！」[rhp]
[:princess:]
「我……！现在真的超级幸福！因为最重要的朋友实现了梦想啊！」[rhp]
[:princess:]
「一直等着呢！等着你亲口告诉我这个消息！[rhr]
_　结果我却……！擅自消失真是对不起！」[rhp]
[:princess:]
「要成为超厉害的医生啊！一定！」[rhp]
[:princess:]
「……如果是宙君的话！不管发生什么都能做到的！」[rhp]

;****************************************
#
[bg storage="cg/d_h_6b.png" width="1280" height="720" time=500]
[cg storage="cg/d_h_6b.png"]
;****************************************

[:sora:]
「…………」[rhp]

;****************************************
#
[bg storage="cg/d_h_6c.png" width="1280" height="720" time=500]
[cg storage="cg/d_h_6c.png"]
;****************************************

[:sora:]
「……啊啊……！包在我身上！」[rhp]

[::]
最后看见的宙君的笑容，比迄今为止见过的他任何表情都更加耀眼。[rhp]
我居然有愿意追到这种地方来的朋友。[rhr]
那样的朋友，将会继承我的梦想。[rhp]
世上还有比这更幸福、更值得骄傲的事吗？[rhp]

;****************************************
[still_end frame="win.png" storage="sky_07p.jpg" time=1000]
;****************************************

[::]
谢谢你陪在我身边。[rhr]
谢谢你来看我。[rhp]

已经拖得太久了。[rhr]
这样终于能传达给你了。[rhp]
让你等了这么久真是对不起。[rhp]

[:princess:]
「……再见。下次见！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
#
[fbgm]
[s_mask color=0xffffff time=3000]
; 背景表示
[bg storage="black.jpg" time=100]
; ウィンドゥの設定
[position layer="message0" frame="win2.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[s_mask_off time=3000]

;****************************************

那时候――――――[rhp]

;****************************************
[bg storage="hsps_08n.jpg" time=1000]
[bgm storage="bgm_15.ogg"]
;****************************************

[::]
我还以为是被夜空吞噬了。[rhp]

回过神来时，我正躺在陌生的床铺上。[rhp]
尝试慢慢撑起身体。[rhr]
身体……能够正常活动。[rhp]
环顾四周，不时掠过视线的未曾见过的衣物。[rhr]
这难以名状的陌生空气感。[rhp]
倒也没有特别不适，我便从床铺下来站起身，[rhr]
重新仔细环视整个房间。[rhp]

[:drop:]
[font color=0x4682b4]
（......真是奇妙的地方......）[rhp]
[resetfont]

[::]
由于出身特殊，仅作为知识知晓的这间临终关怀院。[rhr]
实际目睹时却感到一切都很新鲜，实在不可思议。[rhp]
室内家具虽然情趣相异，功能上倒觉得没太大差别。[rhr]
与『那边』最显著的不同，终究还是外界吧。[rhp]
过于黯淡的月光。[rhr]
遥不可及的仰望星空。[rhp]
我闭上眼睛，以肃穆的心情确认这份现实。[rhr]
这片宇宙深处，正是他们曾经生活过的世界。[rhp]

[:sausu:][sausu kao=1 ]
「呀」[rhp]

[off_all]

[chara_part name="sora" body=prain kao=4 as=on ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:drop:]
「哇！」[rhp]

[:sausu:][sausu kao=11 ]
「欢迎来到银河站。心情如何呀」[rhp]

[:drop:][sora body=prain kao=1 ]
「啊哈哈……还算马马虎虎吧」[rhp]

[:sausu:][sausu kao=1 ]
「黑头发总感觉怪怪的。完全没在和多洛普说话的实感啊」[rhp]

[:drop:][sora body=prain kao=1 ]
「啊哈哈……我倒是完全没觉得不舒服呢。[rhr]
_　不如说和之前相比根本毫无变化」[rhp]

[:sausu:][sausu kao=1 ]
「那当然。这个身体本来就是以多洛普为原型制作的」[rhp]

[:drop:][sora body=prain kao=13 ]
「…………是啊」[rhp]

[:sausu:][sausu kao=1 ]
「刚醒来吗？」[rhp]

[:drop:][sora body=prain kao=1 ]
「嗯，刚刚才醒」[rhp]
[:drop:][sora body=prain kao=0 ]
「……那个」[rhp]

[:sausu:][sausu kao=1 ]
「嗯？怎么了」[rhp]

[:drop:][sora body=prain kao=3 ]
「……为什么我还活着呢」[rhp]
[:drop:]
「本以为宙先生的目的就是抹消我、夺取我的立场。[rhr]
_　似乎没必要绕这么大圈子才对啊……」[rhp]

[:sausu:][sausu kao=12 ]
「虽然宙确实这么打算，但决定保留替换的是约尔大人」[rhp]
[:sausu:][sausu kao=3 ]
「无论有什么理由，约尔大人都不会让生者前往那边。[rhr]
_　…………和我不一样呢」[rhp]

[:drop:][sora body=prain kao=0 ]
「南……」[rhp]

[:sausu:][sausu kao=13 ]
「和我较劲反而救了你的命。[rhr]
_　从这层意义上来说我算是你的恩人呢。开玩笑的啦」[rhp]

[:drop:][sora body=prain kao=2 ]
「现在那条铁道和临终关怀院里究竟发生了什么？[rhr]
_　……大家都平安无事吗」[rhp]

[:sausu:][sausu kao=12 ]
「嗯……这个嘛，要详细说明的话……」[rhp]

;****************************************
; 時間経過
[set_time_c]
;****************************************

[chara_part name="sora" body=prain kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:drop:]
「杰特先生竟然……做出这种事……」[rhp]

[:sausu:][sausu kao=5 as=on ]
「哈哈，没想到他会拿我和约尔大人当人质。[rhr]
_　要是不小心触怒他，不仅是我连你也有危险」[rhp]
[:sausu:][sausu kao=11 ]
「…………不过你已经是彼岸世界的人，倒也无关紧要了」[rhp]

[:drop:][sora body=prain kao=2 ]
「南。请转告宙先生：[rhr]
_　作为新任车掌长，请彻底解决问题」[rhp]

[:sausu:][sausu kao=0 ]
「…………」[rhp]

[:drop:]
「南？你在听吗？」[rhp]

[:sausu:][sausu kao=8 ]
「……你为什么能说出这种话？」[rhp]

[:drop:][sora body=prain kao=0 ]
「诶……？」[rhp]

[:sausu:][sausu kao=2 ]
「你原本不必遭受威胁的容身之处被夺走了啊。[rhr]
_　为什么还能鼓励罪魁祸首宙呢」[rhp]

[:drop:]
「因为这就是我的职责」[rhp]

[:sausu:][sausu kao=3 ]
「仅凭这点就能接受任何对待吗？」[rhp]

[:drop:][sora body=prain kao=11 ]
「嗯。我本就是为此而存在的」[rhp]

[:sausu:]
「……、……。……你是个好人啊」[rhp]
[:sausu:]
「而我……是个讨厌的家伙」[rhp]

[:drop:][sora body=prain kao=2 as=on ]
「嗯？」[rhp]

[:sausu:]
「趁这机会让我发发牢骚吧，多洛普。[rhr]
_　把他们送去那个世界，本可以凭我独断自由决定的」[rhp]
[:sausu:]
「可我却每次都特意向孩子们征求许可，[rhr]
_　稍微让他们瞥见又故意吊胃口……你觉得是为什么？」[rhp]

[:drop:][sora body=prain kao=7 as=on ]
「这个嘛，姑且还是确认下本人意愿比较妥当……」[rhp]

[:sausu:]
「不，其实根本没必要询问意志。[rhr]
_　如果真能去的话，任谁都会想去梦之世界的」[rhp]
[:sausu:]
「一切不过是为了满足我自己。证明我并非无用的纸片堆……」[rhp]
[:sausu:]
「……是对唯一挚友的，执念」[rhp]

[:drop:][sora body=prain kao=2 as=on ]
「……！南……你果然还在懊悔浩先生的死……」[rhp]

[:sausu:]
「是啊。……唯独博士没能坐上那趟铁道，[rhr]
_　都怪我考虑得太不周全。这让我一直后悔」[rhp]
[:sausu:]
「虽然后来做出了达克内布拉……但那不是博士的理想。[rhr]
_　那是我理想中的博士。无所不知，有问必答……」[rhp]
[:sausu:]
「…………是比死去更早消失的，那天的他」[rhp]
[:sausu:]
「所以我决定不再重蹈覆辙。[rhr]
_　只要是这里渴望夜空之旅的孩子，我绝对会帮他们实现愿望」[rhp]
[:sausu:]
「因为希望博士也能体验这段旅程。[rhr]
_　我想这样的话，在天国的博士一定会原谅我吧」[rhp]
[:sausu:]
「我不后悔。无论约尔大人说什么，我都……」[rhp]

[:drop:][sora body=prain kao=0 ]
「……连杰特先生的事也？」[rhp]

[:sausu:][sausu kao=6 as=on ]
「……那是……」[rhp]

[:drop:][sora body=prain kao=3 ]
「从未见过如此苦恼的您。[rhr]
_　您是在后悔让杰特先生变成现在这样吧？」[rhp]
[:drop:]
「他现在去那个地方还为时过早。[rhr]
_　是您在背后推了他一把。所以……」[rhp]

[:sausu:][sausu kao=3 ]
「……是啊。确实如此。正是我这个家伙，扭曲了杰特的心……」[rhp]

[:drop:][sora body=prain kao=2 ]
「现在还不迟。回到那边去把他―――」[rhp]

[:sausu:]
「这该由杰特自己决定。我不能独断专行」[rhp]

[:drop:][sora body=prain kao=2 as=on ]
「南！　这样什么都改变不了啊」[rhp]

[:sausu:]
「你明白的吧多洛普。我已走到无法回头的地步了」[rhp]
[:sausu:]
「公主也说过。说什么不想乘坐银河铁道……[rhr]
_　我从未想过会有孩子说出这种话」[rhp]
[:sausu:]
「……难以置信的是 她居然解开了我施放的魔法」[rhp]

[:drop:][sora body=prain kao=4 as=on ]
「……！ 那么 记忆就……！？」[rhp]

[:sausu:]
「啊啊。似乎全都恢复原状了」[rhp]
[:sausu:]
「……所以这就是 我最后的固执了。[rhr]
_　我想证明这个世界理应被渴望」[rhp]
[:sausu:]
「在那个世界生存的意义 那份价值……[rhr]
_　就交给康贝瑞拉和乔班尼来决定吧」[rhp]

[:drop:][sora body=prain kao=3 as=on ]
「……南……」[rhp]

;****************************************
; 魔法の反応
[bg_magic_d]
;****************************************

[:drop:][sora body=prain kao=0 as=on ]
「―――！ 现在 好像有什么气息……」[rhp]

[off_all]

[:sausu:][sausu kao=2 as=on ]
「这是 约尔大人的魔法……？ 宙要回来了吗？[rhr]
_　舍弃那个世界？　怎么可能……」[rhp]

[off_all]

[chara_part name="sora" body=prain kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:drop:][:drop:]
「并不奇怪。因为是宙先生啊」[rhp]
[:drop:][sora body=prain kao=1 ]
「他是能够承认错误并改正的人。[rhr]
_　即便那是多么痛苦的选择」[rhp]
[:drop:]
「他是我所知最认真 最固执 最耿直的人」[rhp]

[:sausu:][sausu kao=1 ]
「…………和你一样呢」[rhp]

[:drop:][sora body=prain kao=13 ]
「诶诶。嘿嘿……他以我为理想这件事 是我的小骄傲」[rhp]

[:sausu:]
「……这样啊……」[rhp]

[:drop:][sora body=prain kao=1 ]
「…………我也必须改变才行」[rhp]

[:sausu:][sausu kao=0 ]
「？」[rhp]

[:drop:][sora body=prain kao=1 ]
「我一直都是 为了终有一天宙先生来到这里的日子而准备的替身。[rhr]
_　他想来到这边的这份心情 我始终都明白」[rhp]
[:drop:]
「但如今 这也不再需要了。[rhr]
_　我能明白。或许因为是分身……能真切感受到他内心的变化」[rhp]
[:drop:][sora body=prain kao=5 ]
「所以我也。虽然可能无法立即做到，但我会努力尝试。[rhr]
_　不是以宙先生为前提……而是为了找到属于我自己的生存方式」[rhp]

[:sausu:][sausu kao=13 ]
「……我认为这是个很棒的想法」[rhp]

[:drop:][sora body=prain kao=1 ]
「非常感谢。[rhr]
_　……虽然很短暂，现实世界的空气令人感到清新」[rhp]
[:drop:]
「我会代替他在那边努力。……南你有什么打算？」[rhp]

[:sausu:][sausu kao=3 ]
「我？……突然这么问也」[rhp]

[:drop:][sora body=prain kao=1 ]
「即将发生的事，最终引导局势的人是你啊。[rhr]
_　如果打算托付给杰特先生他们，就必须亲自去听取答案」[rhp]
[:drop:]
「我不会插嘴。因为我相信你。[rhr]
_　请做出你认为最佳的选择」[rhp]

[:sausu:]
「…………说的、也是」[rhp]

[off_all]

[:sausu:]
「……我……」[rhp]

;****************************************
#
[fbgm]
[s_mask color=0x000000 time=4000]
; 背景表示
[bg storage="hsps_08n.jpg" time=100]
; ウィンドゥの設定
[position layer="message0" frame="win2.png" left=0 top=520 width=1280 height=200 page=fore visible=true ]
[s_mask_off time=3000]
;****************************************

[:sora:]
「――――――！」[rhp]

[::]
从漫长的梦境中醒来。[rhp]
……不，或许其实非常短暂。[rhp]
时间感知变得模糊不清。[rhp]
我……[rhp]

[:sora:]
「…………」[rhp]

[::]
醒来了。……在那个现实里。[rhp]

;****************************************
[bg storage="sky_07.jpg" time=1000]
[bgm storage="bgm_13.ogg"]
;****************************************

[::]
回忆起来甜蜜又苦涩。[rhr]
现在仍隐隐感到胸口作痛。[rhp]
―――即便如此心情却格外明朗。[rhp]


[font color=0x4682b4]
（…………真是个美梦）[rhp]
[resetfont]

谢谢你们，支撑着我的人们。[rhp]
曾经深爱过的人。[rhp]
谢谢你。[rhp]
……就这样，我那漫长漫长的恋情落幕了。[rhp]

;****************************************
[fbgm]
[set_b storage="hsps_08n.jpg"]
[bgm storage="bgm_35.ogg"]
;****************************************

[::]
宙苏醒过来踏上归途，不过是方才的事。[rhp]
在我和多洛普交谈途中，多洛普突然倒下，[rhr]
约莫十分钟后醒来……之后的一切，都宛如瞬息。[rhp]
宙立即起身，径直离开了病房。[rhr]
那副神情依稀透着几分释然。[rhp]
我隐去身形，静静注视着这一幕全程。[rhp]

如此渴望留在那个世界的宙，[rhr]
竟这般迅速地返回此处，着实令我讶异。[rhp]
公主与哈托谢普起初便对我的构想持疑，[rhr]
不曾想当真能说服那样的宙。[rhp]

[:sausu:]
[font color=0x4682b4]
（既然宙已被打动……杰特的任性也该到此为止了吧）[rhp]
[:sausu:]
（……剩下的，只需询问他今后作何打算）[rhp]
[resetfont]

[::]
如生命般，如思念般，祈愿亦随时间流转。[rhp]
世间从无永恒不变之物。[rhr]
银河铁道并非永恒的梦境。[rhp]
人类的『幸福』不该由我来裁定，那日[player2]我曾这般说过。[rhp]

最初不过是为友人创造的世界。[rhp]
然而不知何时起，那条本该实现众人愿望的铁道，[rhr]
却成了证明自身存在意义的工具。[rhp]
无法实现愿望的千纸鹤，在这世上诞生的意义便不复存在。[rhp]

[:sausu:]
「『在银河铁道的世界里，大家都幸福地生活着』」[rhp]
[:sausu:]
「『无论何时，无论何处，直至永远』……」[rhp]

[::]
……博士。你现在就身处那样的世界吗。[rhp]
[player2]、和近。[rhr]
我的银河铁道，能否成为你们的最佳归宿呢。[rhp]
…………这问题或许不需要问。[rhr]
载着博士的真正银河铁道，才是真正的幸福。[rhp]
你们坚持到最后的殷切期盼，[rhr]
_　神明怎可能不去实现。[rhp]

就算我不多此一举地插手，你们也定能获得幸福。[rhp]
……归根结底，就是这么回事。[rhp]

;--------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;--------------------------------------------------------------------------------------------

[:sausu:]
「………………已经不需要千纸鹤了吗」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
#
[s_mask color=0x000000 time=3000]
; 背景表示
[bg storage="real_02.jpg" time=100]
; ウィンドゥの設定
[position layer="message0" frame="win.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[s_mask_off time=3000]
;****************************************

[::]
光芒逐渐收束，在宙君消失的地方[rhr]
本以为会空无一人……[rhp]

[:drop:][drop kao=12 ]
「…………」[rhp]

[off_all]

[::]
发色恢复如常的他正闭眼伫立原处。[rhp]

[se storage="hand_05.ogg"]

还未等惊呼出声，他的身体便如断线般猛然摇晃。[rhp]

[:princess:][puri_w kao=2 as=on ]
「―――！　多洛普！」[rhp]

[off_all]

[::]
我和哈蒂君他们，还有在铁道旁守望着事态发展的那些人，[rhr]
都慌忙跑向突然倒下的多洛普。[rhp]
脸色并不差。看来只是失去了意识。[rhp]

[:jet:][jet kao=2 as=on ]
「多洛普！喂，振作点！」[rhp]

[off_all]

[:drop:]
「呜……」[rhp]

[off_all]

[::]
被摇醒恢复意识后，多洛普的眼睛微微睁开。[rhp]
在场的我们和后方守候的众人，都如释重负地松了口气。[rhp]

[chara_part name="drop" body=base kao=0 as=on ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=14 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「多洛普！你没事真是太好了！」[rhp]

[:drop:][drop kao=13 ]
「谢谢关心。…………我……这是回来了吗……」[rhp]
[:drop:][drop kao=3 as=on ]
「比起我的事，宙先生在这边的情况怎么样？[rhr]
_　能让他真心接受并回去固然最好……但我很担心」[rhp]

[:princess:][puri_w kao=13 ]
「放心。他现在肯定已经没问题了」[rhp]
[:princess:]
「毕竟连我的那份梦想都由他背负着呢！[rhr]
_　肯定忙得没空来这边啦」[rhp]

[:drop:][drop kao=1 ]
「…………听说你恢复记忆了呢。[rhr]
_　是那边的南君感知到时告诉我的」[rhp]

[:princess:][puri_w kao=1 ]
「嗯。给你们添了这么多麻烦真对不起」[rhp]

[:drop:][drop kao=13 ]
「我们才是」[rhp]

[off_all]

[:drop:][drop kao=11 ]
「咳，那么请允许我正式地再说一次……」[rhp]
[:drop:][drop kao=14 ]
「…………各位。我回来了！」[rhp]

[off_all]

[chara_part name="riri" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:kite:]
「真是漫长的旅程啊」[rhp]

[:quadrillion:][riri kao=5 ]
「真是的，列车长不在的铁道像什么话嘛？」[rhp]

[off_all]

[chara_part name="jet" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:]
「有段时间还以为要出大事。平安比什么都好！」[rhp]

[:jet:]
「宙是归来，多洛普是回归，公主是回忆，我是归途。[rhr]
_　这般完美的大团圆结局可真是绝无仅有了」[rhp]

[:princess:][puri_w kao=3 as=on ]
「……！啊……」[rhp]

[off_all]

[chara_part name="jet" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="drop" body=base kao=1 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:drop:]
「杰特先生，终于下定决心了呢」[rhp]

[:jet:]
「啊。经过超级烦人的说教轰炸才成的」[rhp]
[:jet:]
「我的搭档真是疯了。明明没必要特地跟来的」[rhp]

[off_all]

[:heartshape:][hati kao=2 ]
「来各位看官！这可是大团圆结局！[rhr]
_　请尽情释放感伤的氛围吧！预备——！」[rhp]

[off_all]

[chara_part name="riri" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:quadrillion:]
「好歹是今生永别了。气氛本该更沉重些的……」[rhp]

[:kite:]
「哎呀呀，这样不挺好嘛。这才像他们的作风。[rhr]
_　我也受不了苦大仇深，现在这样正好」[rhp]

[:quadrillion:][riri kao=1 ]
「……也罢。这种形式倒也未尝不可」[rhp]

[off_all]

[:yoru:][yoru kao=2 ]
「稍等」[rhp]

[:princess:][puri_w kao=0 ]
「怎么了，夜？」[rhp]

[:yoru:][yoru kao=6 ]
「若你们安静听着……现在还不能算真正的大团圆吧」[rhp]
[:yoru:]
「让杰特回心转意做得不错。[rhr]
_　但事情尚未完结，我的诉求原本就是全员下车」[rhp]
[:yoru:][yoru kao=2 ]
「……此外，那家伙的事也没解决」[rhp]

;****************************************
[bg_magic_d]
;****************************************

[:sausu:][sausu kao=1 ]
「呃……！」[rhp]

[:princess:][puri_w kao=1 ]
「南！　你之前到底在……」[rhp]

[off_puri]

[off_all]

[:yoru:][yoru kao=2 ]
「不给这小子刻骨铭心的教训，他迟早会重蹈覆辙」[rhp]
[:yoru:]
「不是仅仅让你们所有人离开这个世界。还要把那家伙顽固又爱做梦的性子[rhr]
_　给纠正过来，这才算得上圆满结局。否则我可没法接受」[rhp]

[off_all]

[:sausu:][sausu kao=11 as=on ]
「真不可信啊……」[rhp]
[:sausu:][sausu kao=3 ]

[off_all]

[chara_part name="jet" body=base kao=3 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="true" time=150]
[chara_part name="sausu" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:jet:][jet kao=3 ]
「…………南」[rhp]

[:sausu:][sausu kao=1 ]
「杰特……没事吧。你看起来心事重重的」[rhp]

[:jet:]
「那个……我，其实……」[rhp]

[:sausu:][sausu kao=13 ]
「我明白的」[rhp]
[:sausu:][sausu kao=1 ]
「……是要回去吧，去那边」[rhp]

[:jet:]
「…………、…………嗯。已经决定了」[rhp]

[:sausu:][sausu kao=0]
「不后悔吗？」[rhp]

[:jet:][jet kao=12 ]
「………………、…………」[rhp]
[:jet:][jet kao=0 ]
「…………啊。已经不后悔了」[rhp]

[:sausu:][sausu kao=13 ]
「……这样啊」[rhp]

[off_jet]

[chara_part name="hati" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="208" top="0" wait="true" time=150]

[:heartshape:]
「可别阻止啊。这是我和杰特共同的决定」[rhp]

[:sausu:][sausu kao=12 ]
「我知道的。既然是他决定的事我不会多言。[rhr]
_　他的生命属于他自己。如何度过是他自己的选择」[rhp]

[off_hati]

[chara_part name="jet" body=base kao=3 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="true" time=150]

[:jet:]
「抱歉。我之前说了那么任性的话，结果却……」[rhp]

[:sausu:][sausu kao=1 ]
「没关系的。没能拒绝是我的软弱。[rhr]
_　你完全不必放在心上」[rhp]
[:sausu:][sausu kao=5 ]
「要活下去啊。不管愿望能否实现，心存期盼并不是罪过」[rhp]

[:jet:][jet kao=8 ]
「…………嗯」[rhp]

[off_all]

[:sausu:][sausu kao=13 ]
「哈托谢普也是。虽然以后没法再搞什么电气装置[rhr]
_　有点寂寞……我的朋友就拜托你了」[rhp]

[off_all]

[:heartshape:][hati kao=2 ]
「啊 嗯……」[rhp]

[off_all]

[chara_part name="yoru" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:yoru:]
「…………居然这么通情达理。这是吹的什么风？」[rhp]

[:sausu:]
「你们在这边和睦相处的期间，给了我思考的时间」[rhp]
[:sausu:][sausu kao=11 ]
「关于过去的事，未来的事……种种种种」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="293" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=1 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:sausu:]
「公主也很厉害，居然说服了那个宙。[rhr]
_　回来的宙露出了非常安稳的睡颜哦」[rhp]
[:sausu:]
「…………记忆似乎也恢复了呢」[rhp]

[:princess:][puri_w kao=0 ]
「嗯。全都想起来了，我。[rhr]
_　为何会失去记忆，和你打的赌也……全部」[rhp]

[:sausu:][sausu kao=1 ]
「………那么，你的答案是？」[rhp]

[:princess:][puri_w kao=12 ]
「离开这里」[rhp]

[off_all]

[chara_part name="riri" body=base kao=0 as=on ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:quadrillion:]
「！」[rhp]

[:kite:]
「果然啊……」[rhp]

[off_all]

[:heartshape:][hati kao=0 as=on ]
「公主……」[rhp]

[off_all]

[:princess:][puri_w kao=1 ]
「快斗怎么办？」[rhp]

[:kite:][kite kao=7 ]
「哎呀呀……好不容易过了段还算快乐的人生」[rhp]
[:kite:][kite kao=5 ]
「不过嘛，也是因为有你在才能这样」[rhp]

[:princess:][puri_w kao=1 ]
「如果转世重生能再见到就好了」[rhp]

[:kite:][kite kao=11 ]
「心急的家伙……真是……」[rhp]

[off_all]

[:princess:][puri_w kao=13 ]
「就是这么回事，南。[rhr]
_　我们要离开这个世界，开始新的人生了」[rhp]

[:sausu:][sausu kao=3 ]
「……………………」[rhp]

[:princess:][puri_w kao=0 ]
「？南……？」[rhp]

[:sausu:]
「……我呢，是这么想的」[rhp]
[:sausu:]
「人死后多数魂魄会轮回转世到相同的世界。[rhr]
_　我觉得这很美好，是充满希望的事」[rhp]
[:sausu:]
「…………但我对未知的前路感到不安」[rhp]
[:sausu:]
「重要的朋友转世后，若再次经历这般痛苦该怎么办？[rhr]
_　又或者遭遇更可怕的事？……连想象都不愿想象」[rhp]
[:sausu:]
「我只是想让你们幸福。想实现心愿。[rhr]
_　所以，绝对要为此准备好那个世界」[rhp]
[:sausu:]
「…………但如果你们说不需要的话」[rhp]

[off_all]

[::]
总觉得从刚才开始，南就和平时有些不同。[rhr]
异常干脆，或者说缺乏斗志……[rhp]
在我询问缘由前，南仿佛下定决心般深吸了一口气。[rhp]

;****************************************
[fbgm]
[still storage="cg/d_h_7.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/d_h_7.png"]
;****************************************

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
[vostart]
;--------------------------------------------------------------------------------------------

[:sausu:]
「各位。我决定了」[rhp]
[:sausu:]
「让这个世界在今天终结吧」[rhp]

[bgm storage="bgm_12.ogg"]

[:kite:]
「啊……？」[rhp]

[:sausu:]
「我不会再禁锢你们。虽然不清楚你们在筹划什么，[rhr]
_　但我会全力协助杰特回到现实世界」[rhp]
[:sausu:]
「……这样可以吧？」[rhp]

[::]
过于突然的决断让所有人陷入僵硬。[rhp]
这完全不像那个坚信此世至臻完美的南[rhr]
会说出的话。[rhp]

[:yoru:]
「你……认真的吗？明明曾经那么执着」[rhp]

[:sausu:]
「又是阻止又是怀疑，约尔大人真是繁忙呢」[rhp]
[:sausu:]
「放心，我是认真的」[rhp]

[:yoru:]
「…………这样啊」[rhp]

[:sausu:]
「不过有个条件」[rhp]

[:princess:]
「条件？」[rhp]

[:sausu:]
「希望你们解除我的职责」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:yoru:]
「！」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:princess:]
「解除职责……这是要，」[rhp]

[:sausu:]
「很简单啦。随便找个寺庙带过去就行」[rhp]

[:darknebula:]
「……是要搞那个焚化仪式吗」[rhp]

[:sausu:]
「垃圾回收日也行啦。不过那样终究太凄凉了」[rhp]
[:sausu:]
「所以才要拜托你。提这种奢侈的要求真抱歉」[rhp]

[:vulpecula:]
「带到寺庙的话，南会变成怎样……？」[rhp]

[:sausu:]
「会死的。但肯定能上天堂」[rhp]

[:vulpecula:]
「！不要那样！南会死掉的啊！」[rhp]

[:sausu:]
「……我呢，已经没信心实现你们的愿望了」[rhp]

[:sausu:]
「既然明白这个世界已无必要，你们究竟在期盼什么[rhr]
_　我已经完全搞不懂了」[rhp]
[:sausu:]
「试图拯救朋友的结果，竟是这般惨状……[rhr]
_　我再也无法忍受无用的自己了」[rhp]
[:sausu:]
「……似乎有点理解杰特的心情了」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:jet:]
「…………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sausu:]
「……没关系。最后会好好送你们走的」[rhp]
[:sausu:]
「公主和快斗、沃尔佩克拉会迎来新生。[rhr]
_　为了让你们绝对能获得幸福，我会施下最后的祝福」[rhp]
[:sausu:]
「替补演员们……就沉睡在约尔大人体内吧。[rhr]
_　这样总可以吧？」[rhp]

[:yoru:]
「…………也罢」[rhp]

[:sausu:]
「谢谢。你终于理解我了」[rhp]
[:sausu:]
「……那么，就让这一切在此终结吧」[rhp]

;****************************************
[still_end frame="win.png" storage="real_02.jpg" time=1000]
;****************************************

[:princess:][puri_w kao=2 ]
「……不要，这样」[rhp]

[:sausu:][sausu kao=3 ]
「公主。突然怎么了？　你想起来了对吧？[rhr]
_　你不是希望来到这个世界的不是吗」[rhp]

[:princess:]
「确实我在死前，比起一直待在这里[rhr]
_　更想重新开始新的人生」[rhp]
[:princess:]
「但是……这和南死掉没关系吧。[rhr]
_　为什么不愿意一起在原世界生活呢？」[rhp]

[:sausu:][sausu kao=0 as=on ]
「…………！」[rhp]

[:princess:][puri_w kao=8 ]
「我啊，在这个世界的生活很快乐。[rhr]
_　虽然夜说是徒劳的，但完全不是那么回事」[rhp]
[:princess:]
「我明白了世界原来有这么多不同的景色。[rhr]
_　对于哪里都去不了的我，是你让我看到了世界」[rhp]
[:princess:]
「这个世界并非不需要。你绝对不是无益的」[rhp]

[:sausu:]
「公主……」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=8 as=n ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="peku" body=hood kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:]
「……、博库也和公主酱一样！[rhr]
_　如果南会消失，那就不需要咒语了」[rhp]

[:sausu:]
「如果这个世界终结了，就再也见不到博士了哦……？[rhr]
_　用我的力量，说不定能和真正的他……」[rhp]

[:vulpecula:]
「没问题！　因为佩奇姐姐可以自己做到！[rhr]
_　要是能见到真正的博士，也要介绍给这边的博士哦！」[rhp]
[:vulpecula:][peku body=hood kao=14 ]
「这位是博库的好朋友博士。[rhr]
_　这边也是博库的好朋友博士，这样介绍！」[rhp]

[:sausu:][sausu kao=1 ]
「沃尔佩克拉……」[rhp]

[off_all]

[:kite:][kite kao=1 ]
「……我也算是，基本上满意了」[rhp]
[:kite:]
「真的很感谢南。所以我不再奢求更多了」[rhp]
[:kite:][kite kao=5 ]
「……活着就好啦。明明你最执着于生存了」[rhp]

[off_all]

[:sausu:][sausu kao=3 as=on ]
「…………」[rhp]

[off_all]

[:jet:][jet kao=6 ]
「………南」[rhp]

[off_all]

;****************************************
[still storage="cg/d_h_7b.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/d_h_7b.png"]
;****************************************

[:jet:]
「谢谢你，真的」[rhp]

[:sausu:]
「……杰特」[rhp]

[:jet:]
「在那个病房里，我以为今后要独自一人了。[rhr]
_　有南在，能成为朋友真的很开心」[rhp]
[:jet:]
「……真的，每一天都快乐得令人惊讶」[rhp]
[:jet:]
「不过从今以后，有哈蒂在就没问题了」[rhp]
[:jet:]
「你已不需要再为他人着想、考虑大家的幸福，[rhr]
_　随性地活下去就好」[rhp]
[:jet:]
「没人会责怪你。大家都真心感谢着你。[rhr]
_　希望你从此能慢慢休息」[rhp]
[:jet:]
「……谢谢你把我们带到这里。[rhr]
_　谢谢让我们遇见哈蒂和大家」[rhp]
[:jet:]
「…………谢谢你实现了心愿」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:sausu:]
「………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:princess:]
「看啊。大家都很感激你。你从来不是多余的存在」[rhp]
[:princess:]
「如果没有你，我们的人生将永远沉浸在悲伤中。[rhr]
_　但是呢，听到大家说的话了吧？」[rhp]
[:princess:]
「最后能笑着向前迈进，全是托南的福啊」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:sausu:]
「………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:princess:]
「……南？」[rhp]

[off_puri]

[:sausu:]
「……一直……」[rhp]

;****************************************
#
[bg storage="cg/d_h_7c.png" width="1280" height="720" time=500]
[cg storage="cg/d_h_7c.png"]
;****************************************

[:sausu:]
「一直以来，都渴望听到这句话……」[rhp]

[off_all]

[::]
微阖的双眸中，泪水潸然滑落。[rhp]
南的立场很复杂。[rhr]
为他实现愿望的痛苦有多深，我们无从知晓。[rhp]
即便如此我也真切地感受到了。[rhp]
为他人幸福而活的神明，自身获得的幸福。[rhp]
此刻终于得到了回报。[rhp]

;****************************************
[still_end frame="win.png" storage="real_02.jpg" time=1000]
;****************************************

在他身旁，始终静观事态发展的夜轻声开口。[rhp]

[:yoru:][yoru kao=12 ]
「…………所以，你要怎么做」[rhp]
[:yoru:][yoru kao=0 ]
「想死的话可以连同我迁移的事，找千秋他们商量」[rhp]

[:princess:][puri_w kao=2 as=on ]
「夜……！南不会死的。对吧，南你也……」[rhp]

[:yoru:][yoru kao=2 ]
「别插嘴」[rhp]
[:yoru:]
「这是他的觉悟问题」[rhp]

[off_all]

[::]
夜制止了我的发言，定定凝视着南。[rhp]
南低垂泪眼朦胧的双目，沉默了半晌。[rhp]
在众人静候南的回答时，他终于开口。[rhp]

[:sausu:]
「…………我――――――」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
[fbgm]

#
[s_mask color=0x000000 time=3000]
; 背景表示
[bg storage="hsps_02a.jpg" time=100]
[free_filter ]
; ウィンドゥの設定
[position layer="message0" frame="win2.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[s_mask_off time=3000]

[bgm storage="bgm_27.ogg"]
;****************************************

[:yoru:][yoru kao=12 ]
「――――――……以上就是事情经过」[rhp]

[off_all]

[chara_part name="take" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:]
「……杰特君他……」[rhp]

[:takeru:]
「…………是吗。终于愿意醒来了啊。[rhp]
[:takeru:][take kao=3 ]
「真的……太好了」[rhp]

[:tiaki:][tiaki kao=1 ]
「其、其他人呢？　[player2]和近君他们？」[rhp]

[off_take]

[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="60" top="0" wait="true" time=150]

[:yoru:]
「都没事。……[player2]也顺利恢复了记忆。[rhr]
_　现在的她定能做出正确选择」[rhp]

[:tiaki:][tiaki kao=3 ]
「………………不会回来、了呢」[rhp]

[off_yoru]

[chara_part name="take" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="true" time=150]

[:takeru:][take kao=6 as=on ]
「大美贺小姐……那个」[rhp]

[:tiaki:]
「嗯、我明白的……没关系的。[rhr]
_　她们和杰特君情况不同」[rhp]
[:tiaki:]
「但是……果然、还是会忍不住祈求呢。[rhr]
_　如果神明存在的话，哪怕是这种像梦一样的事」[rhp]
[:tiaki:][tiaki kao=13 ]
「总之太好了！继刚刚回来的宙君之后，[rhr]
_　杰特君也愿意回来了」[rhp]

[off_all]

[:yoru:][yoru kao=0 ]
「高兴还太早。他实际上还在那边」[rhp]

[:takeru:][take kao=0 ]
「不是马上就会回来吗？」[rhp]

[:yoru:][yoru kao=0 ]
「为了正确地将已经离体的灵魂回归肉体，[rhr]
_　我必须带着依附体前往杰特所在的主楼」[rhp]
[:yoru:][yoru kao=0 ]
「若在这个没有他肉体的地方解放灵魂，[rhr]
_　会因为无处可归而有直接消散的危险」[rhp]

[off_all]

[chara_part name="tiaki" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="293" top="0" wait="false" time=150]
[chara_part name="take" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="760" top="0" wait="true" time=150]

[:tiaki:]
「有什么我们能做的？[rhr]
_　需要的话我们随时可以去那个世界」[rhp]

[:takeru:][take kao=6 ]
「……我也是。光畏惧是不会有进展的。[rhr]
_　不……想着这就是开端、再去一次那边吧」[rhp]

[:yoru:][yoru kao=12 as=on ]
「……………………」[rhp]

[:tiaki:][tiaki kao=0 ]
「？」[rhp]

[:takeru:][take kao=0 ]
「怎么了？一脸严肃……」[rhp]

[:yoru:][yoru kao=6 as=on ]
「有件只有你们才能做到的事……确实存在」[rhp]
[:yoru:][yoru kao=3 as=on ]
「但可能会让你们遭受异样的眼光。[rhr]
_　「那些家伙算什么啊。净做些古怪的事不是蠢货吗……」[rhp]

[:tiaki:][tiaki kao=4 ]
「难道是在担心我们？」[rhp]

[:yoru:]
「当然。你们在这里有人际关系。[rhr]
_　若因我的缘故，导致你们今后在这家医院处境艰难的话……」[rhp]

[:takeru:][take kao=1 ]
「现在才担心未免太迟了。[rhr]
_　早已被所有派系排挤的我，没什么可畏惧的」[rhp]

[:tiaki:][tiaki kao=14 ]
「我也是。米卡亲在这家医院可是最强存在！」[rhp]
[:tiaki:]
「不必客气，尽管多给我们添麻烦吧。[rhr]
_　我们会一直站在你和你心爱的孩子们这边，直到最后」[rhp]

[:yoru:][yoru kao=1 ]
「……感激不尽。最后那句话倒是多余」[rhp]

[:tiaki:][tiaki kao=8 ]
「真是的～！这种时候还这么不坦率！」[rhp]

[:yoru:][yoru kao=0 ]
「对了千秋。你体力如何？」[rhp]

[:tiaki:][tiaki kao=13 ]
「每天都有练瑜伽！　[font size=12]虽然经常偷懒[resetfont]」[rhp]

[:yoru:][yoru kao=7 ]
「武呢」[rhp]

[:takeru:][take kao=6 ]
「以前是游泳部的还算可以……」[rhp]

[off_all]

[:yoru:][yoru kao=12 ]
「那就这么定了」[rhp]

[off_all]

[chara_part name="tiaki" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="take" body=base kao0 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:2nin:]
「……？」[rhr]
「……？」[rhp]

;****************************************
[fbgm]
[set_b storage="hspt_05.jpg"]
[bgm storage="bgm_17.ogg"]
;****************************************

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
[vostart]
;--------------------------------------------------------------------------------------------

[:takeru:][take kao=2 as=on ]
「……呜呜……！」[rhp]

[off_all]

;****************************************
[still storage="cg/d_h_8.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/d_h_8.png"]
;****************************************

[:yoru:]
「加油武。就差一点了」[rhp]

[:takeru:]
「呃……！你真重啊……！」[rhp]

[se storage="hand_05.ogg"]

[:takeru:]
「痛！」[rhp]

[:yoru:]
「闭嘴干活」[rhp]

[:tiaki:]
「来吧医生！！马上就到主楼了！」[rhp]
[:tiaki:]
「虽然吝啬的主楼不愿派卡车，但那无所谓。[rhr]
_　以前就连摩艾石像都是用人力搬运的，这种程度根本不算什么！」[rhp]
[:tiaki:]
「好，一二！一二！」[rhp]

[:takeru:]
「哈、哈……！这、这点小事……呃」[rhp]

[:yoru:]
「你喘得很厉害啊，冲的武君」[rhp]

[:takeru:]
「！？为、为什么知道我小学时代的绰号……！」[rhp]

[:yoru:]
「矢部在四处宣扬」[rhp]

[:takeru:]
「什……！？我的替身演员！居然做出这种事……！[rhr]
_　太羞耻了别再这么叫我！」[rhp]

[:tiaki:]
「呜呼呼！米卡亲、夜君、小武……！[rhr]
_　简直像好朋友小组呢」[rhp]

[:takeru:]
「哈哈……再说这种话又要挨骂了哦」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:yoru:]
「…………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:yoru:]
「……嘛，听着倒是挺顺耳」[rhp]

;****************************************
#
[bg storage="cg/d_h_8b.png" width="1280" height="720" time=500]
[cg storage="cg/d_h_8b.png"]
;****************************************

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:2nin:]
「……！！」[rhr]
「……！！」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:yoru:]
「闭嘴干活」[rhp]

[se storage="hand_05.ogg"]

[:takeru:]
「好痛！我明明现在什么都没说啊！」[rhp]

[:yoru:]
「表情很吵」[rhp]

[:takeru:]
「哈！？」[rhp]

[:tiaki:]
「……呵呵！大家都在看着我们呢」[rhp]
[:tiaki:]
「老师，一个人自言自语会太显眼哦」[rhp]

[:takeru:]
「！说、说得对……」[rhp]

;****************************************
#
[bg storage="cg/d_h_8c.png" width="1280" height="720" time=500]
[cg storage="cg/d_h_8c.png"]
;****************************************

[:yoru:]
「…………呵」[rhp]

[:tiaki:]
「……！夜君笑了……真罕见」[rhp]

[:yoru:]
「我是真心觉得你们很有趣。最初还担心会变成怎样……」[rhp]
[:yoru:]
「意外地感觉很舒适，真是不可思议」[rhp]

[:takeru:]
「……！哈哈哈……」[rhp]

[:tiaki:]
「呼呼呼……！」[rhp]

[:yoru:]
「这次又是怎么了……」[rhp]

[:takeru:]
「不……我也是这么想的」[rhp]

[:tiaki:]
「我也是！」[rhp]

[:yoru:]
「哼。真是物以类聚啊」[rhp]
[:yoru:]
「…………不赖」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
[fbgm]

#
[s_mask color=0x000000 time=3000]
; 背景表示
[bg storage="real_02.jpg" time=100]
; 夜フィルター
[filter layer="1" brightness="60"]
; ウィンドゥの設定
[position layer="message0" frame="win.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[s_mask_off time=3000]

[bgm storage="bgm_34.ogg"]
;****************************************

[chara_part name="sausu" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="peku" body=hood kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:sausu:]
「这样真的好吗？不和大家一起告别」[rhp]

[:vulpecula:]
「嗯。因为已经和大家说过再见了」[rhp]
[:vulpecula:]
「而且博库觉得……[rhr]
_　果然最后，还是这三个人最好了！」[rhp]

[:sausu:][sausu kao=11 ]
「呵呵，真开心呢。让人想起从前」[rhp]

[off_all]

[:sausu:][sausu kao=13 as=on ]
「…………，我说？墓、……达克内布拉博士？」[rhp]

[off_all]

[:darknebula:][hakase kao=3 ss=on msk=hat ]
「…………」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="peku" body=hood kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:sausu:]
「比即将消失的人还沮丧呢……」[rhp]

[:vulpecula:]
「博士～～～。难得三个人聚齐了嘛？来比耶！」[rhp]

[:sausu:][sausu kao=13 as=on ]
[font color=0x4682b4]
（这个我实在做不到啊）[rhp]
[resetfont]

[off_sausu]
[chara_part name="hakase" body=base kao=3 as=on ss=off hh=off hr=on msk=hat ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="true" time=150]

[:darknebula:]
「因为……一想到要和佩奇分别就很难过……」[rhp]

[:vulpecula:]
「真是的～～，真拿你没办法。[rhr]
_　明明想最后开开心心地道别的」[rhp]

[:darknebula:]
「但是……可是重要的妹妹……呜……」[rhp]

[off_peku]

[chara_part name="sausu" body=base kao=13 as=on ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sausu:]
「啊，那个……呃，振作点。好吗？」[rhp]

[:darknebula:]
「南你不会懂的……！[rhr]
_　我和佩奇度过了多少快乐的时光啊啊啊……！」[rhp]

[:sausu:][sausu kao=0 as=on ]
「啊……嗯、嗯……」[rhp]
[:sausu:][sausu kao=3 as=on ]
「………………是啊。确实……」[rhp]

[off_all]

[:vulpecula:][peku body=hood kao=0 ]
「………、………………」[rhp]

[off_all]

[chara_part name="hakase" body=base kao=3 as=off ss=off hh=off hr=on msk=hat ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="peku" body=hood kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:]
「………，喂博士！」[rhp]

[:darknebula:]
「呜咽……好的……」[rhp]

[:vulpecula:][peku body=hood kao=13 ]
「谢谢你叫我妹妹。我超级开心！」[rhp]
[:vulpecula:][peku body=hood kao=2 ]
「但是博库……最近想到。[rhr]
_　我和博士的关系，可能不太对吧」[rhp]

[:darknebula:][hakase kao=2 as=on ss=on msk=hat ]
「哎！？」[rhp]

[:vulpecula:][peku body=hood kao=6 ]
「说不定……博士其实是弟弟！？」[rhp]

[:darknebula:][hakase kao=2 as=on msk=hat ]
「？　……？？」[rhp]

[:vulpecula:][peku body=hood kao=1 ]
「毕竟博士是比我晚诞生的嘛」[rhp]

[:darknebula:]
「啊、啊……这么说的确有可能……」[rhp]

[:vulpecula:][peku body=hood kao=8 hh=on ]
「那果然是这样！博库因为博士是博士的理想形象，[rhr]
_　就把博士当成和博士一样的哥哥了！」[rhp]
[:vulpecula:]
「可恶～！好不甘心～！明明想照顾人的说！」[rhp]

[:darknebula:][hakase kao=0 as=on msk=hat ]
「嗯、嗯嗯……？」[rhp]

[off_peku]

[chara_part name="sausu" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sausu:]
「呵呵……」[rhp]

[:darknebula:][hakase kao=2 as=on msk=hat ]
「喂！别笑了行不行啊」[rhp]

[:sausu:][sausu kao=5 as=on ]
「对、对不起。就是觉得有点好笑……」[rhp]

[off_hakase]

[chara_part name="peku" body=hood kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="152" top="0" wait="true" time=150]

[:vulpecula:]
「南可能是爸爸吧～。毕竟这个博士是南制作的。[rhr]
_　更重要的是，青春期儿子和父亲容易闹别扭呢」[rhp]

[:sausu:][sausu kao=0 as=on ]
「！」[rhp]

[:vulpecula:][peku body=hood kao=14 ]
「嗯嗯。爸爸的角色，超合适的！」[rhp]

[:sausu:][sausu kao=13 as=on ]
「那个……真的可以吗……」[rhp]

[off_all]

[:vulpecula:][peku body=hood kao=1 ]
「就这样！现在宣布佩奇的提议——」[rhp]
[:vulpecula:]
「从今天开始！[rhr]
_　青春期闹别扭剧场正式落幕！！」[rhp]

[off_all]

[chara_part name="hakase" body=base kao=0 as=on ss=off hh=off hr=on msk=hat ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=0 as=on ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:2nin:]
「……！」[rhr]
「……！」[rhp]

[off_all]

[:vulpecula:][peku body=hood kao=13 ]
「因为我们是一家人呀。家人就该其乐融融！」[rhp]
[:vulpecula:]
「天国的博士爷爷也、[rhr]
_　佩奇们笑着在一起肯定会更开心啦！」[rhp]

[:sausu:][sausu kao=1 ]
「……、博士是爷爷吗？」[rhp]

[:vulpecula:][peku body=hood kao=14 ]
「是呀。博士的爸爸是南的话、[rhr]
_　制造南的博士就是爸爸，也就是说博士是爷爷啦！」[rhp]

[:sausu:][sausu kao=14 as=on ]
「呵呵，哪有这么随便的」[rhp]

[:vulpecula:][peku body=hood kao=6 ]
「随便不随便都无所谓啦！！」[rhp]

[off_all]

[chara_part name="hakase" body=base kao=0 as=on ss=off hh=off hr=on ]
[chara_show name="hakase" layer="1" width="571" height="720" left="40" top="0" wait="true" time=150]
[chara_part name="peku" body=hood kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="355" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=0 as=on ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="650" top="0" wait="false" time=150]

[:vulpecula:]
「总之来握手！今天开始青春期就结束啦～～～～！」[rhp]

[off_all]

[chara_part name="hakase" body=base kao=4 as=on ss=off hh=off hr=on msk=hat ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=4 as=on ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:darknebula:][hakase kao=1 msk=hat ]
「哇哇……！」[rhp]

[:sausu:][sausu kao=1 ]
「稍……」[rhp]

[off_all]

[:vulpecula:][peku body=hood kao=6 ]
「嗯嗯。握过手啦！这样就好！」[rhp]

[off_all]

[chara_part name="hakase" body=base kao=0 as=on ss=off hh=off hr=on msk=hat ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:darknebula:]
「…………」[rhp]

[:sausu:]
[font color=0x4682b4]
（好尴尬……）[rhp]
[resetfont]

[off_all]

[chara_part name="hakase" body=base kao=1 as=off ss=off hh=off hr=on msk=hat ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=0 as=on ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:darknebula:][hakase kao=1 msk=hat ]
「…………、……南」[rhp]

[:sausu:]
「！」[rhp]

[:darknebula:]
「我并非不明白你的困惑。[rhr]
_　有的伤痛需要时间愈合，而有的伤痛或许永远无法痊愈」[rhp]
[:darknebula:]
「当某天你战胜悲伤时，我想和你更多地交谈。[rhr]
_　毕竟我对你的存在抱有极大兴趣」[rhp]

[:sausu:][sausu kao=13 as=on ]
「……哈哈……这、这样啊。太好了……」[rhp]

[:darknebula:]
「生于这个充满未知的世界，我感到非常幸福」[rhp]
[:darknebula:]
「南。谢谢你创造了我」[rhp]

[:sausu:][sausu kao=0 as=on ]
「…………！」[rhp]

[:darknebula:][hakase kao=1 msk=hat ]
「这话、或许有点肉麻……但其实我一直想告诉你」[rhp]
[:darknebula:]
「要感谢佩奇给了我这个机会呢」[rhp]

[off_all]

[:vulpecula:][peku body=hood kao=14 hh=on ]
「诶嘿嘿！不客气啦！」[rhp]

[off_all]

[:sausu:][sausu kao=0 as=on ]
「…………、……」[rhp]
[:sausu:][sausu kao=13 hh=on ]
「…………呵呵。被人这么说，果然很开心呢」[rhp]

[:darknebula:][hakase kao=0 msk=hat ]
「？」[rhp]

[:sausu:][sausu kao=1 ]
「不，没什么」[rhp]
[:sausu:]
「……达克内布拉博士。我至今为止，都在某些地方刻意避开你……[rhr]
_　你就是你，他就是他。……这么简单的道理我现在才明白」[rhp]
[:sausu:]
「…………能否请你，把我当作你的朋友呢」[rhp]

[:darknebula:][hakase kao=5 msk=hat ]
「荣幸之至。我才是啊，南！」[rhp]

[off_all]

[:vulpecula:][peku body=hood kao=1 ]
「嗯嗯！和好真是太好了呢。[rhr]
_　这样我终于也能毫无牵挂地告别了！」[rhp]

[off_all]

[chara_part name="hakase" body=base kao=3 as=off ss=off hh=off hr=on msk=hat ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="peku" body=hood kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:darknebula:]
「啊……」[rhp]

[:vulpecula:][peku body=hood kao=6 ]
「真是的！好不容易气氛变融洽了，[rhr]
_　马上又搞得这么伤感」[rhp]
[:vulpecula:][peku body=hood kao=13 ]
「我只是要重新转世，这次一定要去见到爸爸妈妈而已。[rhr]
_　不是悲伤的事，笑着告别吧」[rhp]

[:darknebula:]
「可是……」[rhp]

[:vulpecula:][peku body=hood kao=1 ]
「……，那博士！告诉你个好事」[rhp]
[:vulpecula:][peku body=hood kao=13 ]
「当悲伤得无法自已时，就抬头看看天空吧。[rhr]
_　浩那边的博士说过，天空有佩奇的星座哦」[rhp]

[:darknebula:][hakase kao=0 msk=hat ]
「佩奇的星座……」[rhp]

[off_all]

[:sausu:][sausu kao=1 ]
「沃尔佩克拉。差不多该……」[rhp]

[:vulpecula:][peku body=hood kao=13 ]
「好嘞！这就来！」[rhp]

[off_all]

;****************************************
#
[se storage="mag_08.ogg"]
[bg storage="white.jpg" time=500]
;****************************************

[:darknebula:]
「啊……！等等。还――――――」[rhp]

;****************************************
[still storage="cg/d_h_9.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/d_h_9.png"]
;****************************************

[:vulpecula:]
「博士。一直陪在我身边真是谢谢你」[rhp]
[:vulpecula:]
「……明明一直在一起，却要分开真是痛苦呢」[rhp]
[:vulpecula:]
「我懂的。博库也曾经历过……告别这种事，真的太难受了」[rhp]
[:vulpecula:]
「博库曾经很消沉，也很生气[rhr]
_　……但更多的是，后悔」[rhp]
[:vulpecula:]
「所以博库想和博士笑着告别。[rhr]
_　因为最珍贵之人的回忆，想让它直到最后都闪闪发光」[rhp]

[:darknebula:]
「沃尔佩克拉………」[rhp]

[:vulpecula:]
「谢谢你博士！[rhr]
_　能和你一起经历这么多旅途，真的真的非常开心」[rhp]
[:vulpecula:]
「博库现在要去见浩了。[rhr]
_　想告诉那个最喜欢的女孩，关于最喜欢的你的事情」[rhp]
[:vulpecula:]
「所以必须得走了」[rhp]

[:darknebula:]
「会记得……关于我的事吗……？」[rhp]

[:vulpecula:]
「当然啦！就算忘了也绝对绝对会想起来的」[rhp]
[:vulpecula:]
「……再也不想当健忘鬼了！」[rhp]

[:darknebula:]
「……、…………」[rhp]

[:vulpecula:]
「博库会永远在这片星空中。[rhr]
_　只要还在这个宇宙里，我们就永远在一起！」[rhp]
[:vulpecula:]
「所以肯定不会寂寞的。[rhr]
_　就算寂寞了，你也一定没问题的」[rhp]
[:vulpecula:]
「因为……呐博士。还记得那句话吗？」[rhp]

[:darknebula:]
「那句话？」[rhp]

[:vulpecula:]
「连博士都解不开的，银河铁道最大的谜题哦！」[rhp]

[:darknebula:]
「……！」[rhp]

[:vulpecula:]
「地球上的调查就交给博库和博士吧。[rhr]
_　所以博士就和南一起，去探索这浩瀚的宇宙吧！」[rhp]
[:vulpecula:]
「我们的冒险，就算天各一方也不会结束！」[rhp]

[:darknebula:]
「唔……啊……啊，是啊……」[rhp]
[:darknebula:]
「…………身为我，居然完全忘记了」[rhp]

[:vulpecula:]
「我们的暗号，要一起喊出来哦！」[rhp]
[:vulpecula:]
「因为那样就会成为新冒险的起点！」[rhp]

[:darknebula:]
「……明白了」[rhp]

[:vulpecula:]
「好嘞！　要开始喊啦！」[rhp]

;****************************************
#
[bg storage="white.jpg" time=1000]
;****************************************

[:vulpecula:]
「预备――――――！」[rhp]

;****************************************
#
[s_mask color=0xffffff time=2000]
; 背景表示
[bg storage="real_02.jpg" time=100]
; ウィンドゥの設定
[position layer="message0" frame="win.png" left=0 top=520 width=1280 height=200 page=fore visible=true ]
[s_mask_off time=2000]

;****************************************

光之粒子闪烁着将沃尔佩克拉包裹，吞噬了那道身影。[rhp]
因强光闭眼，再次微微睁眼时，[rhr]
她的身影已无处可寻。[rhp]

[:sausu:][sausu kao=13 ]
「…………一路顺风。[rhr]
_　愿她的未来充满幸福」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="hakase" body=base kao=1 as=off ss=off hh=off hr=on msk=hat ]
[chara_show name="hakase" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:sausu:]
「那么……我也是时候回到公主他们身边了。[rhr]
_　他们在那边岬角等着呢」[rhp]
[:sausu:]
「……姑且问一句，你今后有何打算？[rhr]
_　其实你也可以和他们一起离开这个世界……」[rhp]

[:darknebula:]
「我要留在现世。因为和沃尔佩克拉约好了」[rhp]

[:sausu:]
「……也是。多此一问了」[rhp]

[:darknebula:]
「请代我向公主他们问好。[rhr]
_　我要回夸德里利昂那边了，你待会儿也过来吧」[rhp]
[:darknebula:]
「堆积如山的话要聊呢。[rhr]
_　迄今为止的故事，也想听你讲讲」[rhp]

[:sausu:][sausu kao=13 ]
「……嗯、啊。乐意之至！」[rhp]

;****************************************
[bg_magic_d]
;****************************************

[::]
再次握手后，南的身影消失在光芒中。[rhp]
那个总显疏离、令人感到距离感的南。[rhr]
但从今往后，我们一定能好好相处吧。[rhp]
毕竟我们之间，已经有了共同的旅途目标。[rhp]

[:darknebula:]
[font color=0x4682b4]
（必须前进了。我们的冒险不会终结在这种地方）[rhp]
[resetfont]

;****************************************
[bg storage="sky_12.jpg" time=1000]
;****************************************

渺小的我们面前，宇宙辽阔得过分。[rhp]
正因如此才会心潮澎湃。[rhr]
这个世界充满未知之事。[rhp]
哪有悲伤的空闲。[rhr]
快些向前。哪怕只多一步。[rhp]
素未谋面的另一个我。[rhr]
将继承的那份意志，切实怀抱着。[rhp]

『肯陶尔，降下露水』。[rhp]
令人心跳加速的发现，未知的世界，正等待着我。[rhp]

;*****************************************
[bg_rule storage="real_02.jpg" rule="002.png" time=1000]
;*****************************************

[:unknown:]
「啊」[rhp]

[off_all]

[:darknebula:][hakase kao=0 msk=hat ]
「嗯？……哎呀！」[rhp]

[off_all]

[chara_part name="hakase" body=base kao=1 as=off ss=off hh=off hr=on msk=hat ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="yabu" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="yabu" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:darknebula:]
「这不是矢部医生吗。在这里遇见真是巧合」[rhp]

[:yabu:]
「不，夸德里利昂刚用魔法传讯要我立刻过来」[rhp]
[:yabu:]
「这里似乎只有你一个人。本尊在哪？」[rhp]

[:darknebula:]
「他的话在铁道里面哦」[rhp]

[:yabu:][yabu kao=2 ]
「什么？那个该死的肌肉人妖。[rhr]
_　有事就该主动登门拜访才合乎礼节―――」[rhp]

[:darknebula:][hakase kao=5 msk=hat ]
「啊！原来如此，是说那件事吧」[rhp]

[:yabu:]
「那件事……难道你也是同伙吗！？」[rhp]

[:darknebula:][hakase kao=1 msk=hat ]
「不不，可不是那么危险的事。[rhr]
_　总之能先跟我来趟铁道吗老师。不会亏待你的」[rhp]

[:yabu:][yabu kao=6 as=on ]
「完全不可信……！」[rhp]

[:darknebula:][hakase kao=5 msk=hat ]
「哈哈哈，真过分啊」[rhp]

[:yabu:][yabu kao=6 ]
「…………，心真大啊」[rhp]

[:darknebula:][hakase kao=0 msk=hat ]
「嗯？」[rhp]

[:yabu:]
「关于我们这类存在的未来去向，已经从夜那里听说了。[rhr]
_　……沃尔佩克拉已经走了吗？」[rhp]

[:darknebula:][hakase kao=1 msk=hat ]
「啊。刚刚才走」[rhp]

[:yabu:]
「不会寂寞吗」[rhp]

[:darknebula:]
「虽然寂寞，但也不寂寞。因为我们有共同的目标」[rhp]

[:yabu:][yabu kao=0 ]
「………………是吗」[rhp]

[:darknebula:]
「你呢？最后见到米卡亲了吗？」[rhp]

[:yabu:][yabu kao=3 ]
「没那个时间。……她现在正在现实世界处理夜的请求。[rhr]
_　等事情办完，她和这个世界就再无瓜葛了」[rhp]

[:darknebula:][hakase kao=0 msk=hat ]
「哎呀……」[rhp]

[off_all]

[:yabu:][yabu kao=2 ]
「……喂！发什么呆。[rhr]
_　不是该由你带路吗？还不快走」[rhp]

[off_all]

[:darknebula:][hakase kao=5 msk=hat ]
「啊。抱歉抱歉。那就请跟我来吧」[rhp]

[off_all]

;****************************************
[fbgm]
[set_xx graphic="rule/krke_h.png" storage="train_03b.jpg"]
[free_filter ]
[bgm storage="bgm_17.ogg"]
;****************************************

[chara_part name="hakase" body=base kao=14 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="riri" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:2nin:]
「欢迎光临～！」[rhr]
「欢迎光临～！」[rhp]

[off_all]

[:yabu:][yabu kao=6 as=on ]
「………………什么情况？」[rhp]

[off_all]

[chara_part name="hakase" body=base kao=5 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720" left="40" top="0" wait="false" time=150]
[chara_part name="yabu" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="yabu" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="riri" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="736" top="0" wait="true" time=150]

[:darknebula:]
「来来来快坐！　随便用不用拘束哦」[rhp]

[:quadrillion:]
「喝点什么？葡萄酒清酒都能变出来。用魔法！」[rhp]

[:yabu:][yabu kao=2 as=on ]
「水就行。酒精对身体不好」[rhp]

[:quadrillion:][riri kao=14 ]
「胡~说什么呢。在这个世界根本不可能损害健康啦！[rhr]
_　来，尝尝香槟呗！」[rhp]

[:yabu:]
「等、擅自就……！　把人叫过来到底是几个意思。[rhr]
_　如果只是宴会的邀约那我可要回……」[rhp]

[:quadrillion:][riri kao=2 ]
「这是誓师大会！！」[rhp]

[:yabu:]
「无法理解。这群人能搞什么……」[rhp]

[:darknebula:][hakase kao=1 ]
「新・银河铁道团队哟。[rhr]
_　成员有我们和多洛普、矢部医生。偶尔还有南」[rhp]

[:yabu:][yabu kao=6 ]
「哈啊？」[rhp]

[:darknebula:][hakase kao=1 ]
「幸好南和夜同意在那幅画里留下我们的存在」[rhp]
[:darknebula:]
「留下的只有我们俩和多洛普、再加上你共四人。[rhr]
_　要旅行的话人多才热闹嘛」[rhp]

[:quadrillion:][riri kao=1 ]
「你反正很快也没理由与我们敌对了[rhr]
_　米卡亲也不会再来这个世界了吧」[rhp]
[:quadrillion:]
「孤零零一个人多寂寞呀。[rhr]
_　难得机会，不如和我们一起出发呗」[rhp]

[:yabu:][yabu kao=8 as=on ]
「开、开什么玩……」[rhp]

[off_all]

[chara_part name="hakase" body=base kao=1 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="riri" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:quadrillion:][riri kao=1 ]
「博士想喝什么？葡萄酒还是别的都用魔法变出来哦」[rhp]

[:darknebula:][hakase kao=1 ]
「呵呵，那就交给夸德里利昂吧」[rhp]

[off_all]

[:yabu:][yabu kao=6 ]
「………………」[rhp]

[off_all]

[::]
――――――『米卡亲也不会再来这个世界了吧』[rhp]

[:yabu:][yabu kao=3 ]
「…………是啊，果然」[rhp]

[:quadrillion:][riri kao=2 ]
「你在干嘛呀，矢部亲！」[rhp]

[:yabu:][yabu kao=0 as=on ]
「！」[rhp]

[:quadrillion:][riri kao=1 ]
「马上开喝吧……咳咳、现在开始誓师大会！[rhr]
_　别发呆了快过来坐着！」[rhp]

[off_all]

[:yabu:][yabu kao=1 ]
「………………、好啦好啦！[rhr]
_　知道了别催。名医可是时刻保持谨慎的！」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

;****************************************
[set_time_b]
;****************************************

[chara_part name="riri" body=base kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="yabu" body=base kao=0 as=off ss=off hh=on hr=on ]
[chara_show name="yabu" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:quadrillion:]
「――――――这会儿夜应该在赶路吧」[rhp]

[:yabu:]
「应该是」[rhp]

[:quadrillion:][riri kao=5 ]
「矢部亲，被独自留下的感觉如何？」[rhp]

[:yabu:][yabu kao=2 hh=on ]
「问这种戳心事的死娘娘腔……！[rhr]
_　我才没觉得寂寞。名医永远保持冷静！」[rhp]

[:quadrillion:][riri kao=13 ]
「真心话呢？」[rhp]
 
[:yabu:][yabu kao=3 ss=on ]
「寂寞得要死……」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[off_all]

[:darknebula:][hakase kao=1 as=on ]
[font color=0x4682b4]
（彻底暴露了呢矢部医生……）[rhp]
[resetfont]

[off_all]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[chara_part name="riri" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="yabu" body=base kao=3 as=off ss=off hh=on hr=on]
[chara_show name="yabu" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:quadrillion:][riri kao=1 ]
「要是你也能去那边世界就好了呢。[rhr]
_　啊不过不可能啦」[rhp]

[:yabu:]
「……、算了无所谓！这样我们的夙愿总算实现了」[rhp]
[:yabu:][yabu kao=5 as=on hh=on ]
「铁道被拆除，他们纷纷下车！[rhr]
_　这场较量终究是我们赢了！」[rhp]

[:quadrillion:][riri kao=5 as=on ]
「是是。真是太好了」[rhp]

[off_yabu]
[chara_part name="hakase" body=base kao=1 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:darknebula:]
「话说那个夸德里利昂，你不用去给他们送行吗？」[rhp]

[:quadrillion:][riri kao=7 ]
「不必。刚才已经道别过了……而且，我不喜欢感伤场面」[rhp]
[:quadrillion:][riri kao=0 ]
「要说这个的话博士也是。[rhr]
_　小不点们不留在这里都要走了呢。不会寂寞吗？」[rhp]

[:darknebula:][hakase kao=1 ]
「虽然寂寞……但是没关系哦」[rhp]
[:darknebula:]
「即使不在身边，回忆里也永远会有她在」[rhp]

[:quadrillion:][riri kao=6 ]
「真是浪漫主义者呢……」[rhp]
[:quadrillion:][riri kao=1 ]
「……不过这种感觉，莫名地很美妙」[rhp]

[off_all]

[chara_part name="hakase" body=base kao=1 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720" left="40" top="0" wait="false" time=150]
[chara_part name="yabu" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="yabu" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="riri" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="736" top="0" wait="true" time=150]

[:darknebula:]
「希望他们的下一段人生能过得美好」[rhp]

[:yabu:]
「嗯」[rhp]

[:quadrillion:]
「是啊」[rhp]

[off_all]

[:quadrillion:][riri kao=14 ]
「―――好啦！留守组要继续开派对吗！」[rhp]

[off_all]

;****************************************
#
[bg storage="sky_12.jpg" time=500]
;****************************************

[:quadrillion:]
「为他们的启程和我们的未来干杯！」[rhp]

[off_all]

[:3nin:]

[s_playse storage="riri/full/230.ogg" buf=1]
[s_playse storage="yabu/full/127.ogg" buf=2]
[s_playse storage="hakase/full/79.ogg" buf=3]

「干杯―――！」[rhr]
「干杯―――！」[rhr]
「干杯―――！」[rhp]

;****************************************
[set_w storage="real_03.jpg"]
; 夜フィルター
[filter layer="1" brightness="60"]
;****************************************

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:princess:][puri_w kao=0 ]
「――――――……嗯」[rhp]

[:heartshape:][hati kao=0 ]
「怎么了？公主」[rhp]

[:princess:][puri_w kao=1 ]
「不，总觉得铁道那边传来特别热闹的声音。[rhr]
_　看起来很开心呢」[rhp]

[:heartshape:][hati kao=6 ]
「那群家伙，不来送行在搞什么啊。明明最后一面了！」[rhp]

[:princess:][puri_w kao=11 ]
「没关系啦。感伤告别也不像我们的风格，[rhr]
_　也不想看克林哭得稀里哗啦对吧？」[rhp]

[:heartshape:][hati kao=5 ]
「倒也是。[rhr]
_　确实希望他们到最后都保持本色啊！」[rhp]

[:princess:][puri_w kao=13 ]
「对吧。这样就好」[rhp]

[off_all]

[chara_part name="jet" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:jet:]
「天快亮了。这也是演出效果吗？」[rhp]

[:sausu:]
「算是吧。……待会儿随着日出，你们的灵魂就会从这个世界消失」[rhp]

[:jet:][jet kao=5 as=on ]
「搞什么啊。吸血鬼吗……」[rhp]

[off_all]

[chara_part name="drop" body=base kao=1 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:kite:]
「多洛普没问题吗？不和克林他们一起。[rhr]
_　你原本是属于留在这个世界的组别吧」[rhp]

[:drop:]
「请别担心。之后我计划去那边会合。[rhr]
_　因为我是列车长啊。会送行到最后一刻的」[rhp]

[:kite:][kite kao=1 ]
「……这样啊。那就麻烦你了」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[::]
在气氛恰当的时候，多洛普轻咳了一声。[rhp]
他环视我们的表情，透露出内心深处的感慨。[rhp]

[:drop:][drop kao=1 ]
「…………再次致意。各位。真的给你们添了诸多麻烦。[rhr]
_　直到最后都是个靠不住的列车长，实在抱歉」[rhp]

[:princess:][puri_w kao=1 ]
「不会啦，完全没有这回事哦。对吧快斗？」[rhp]

[:kite:][kite kao=11 ][drop kao=13 as=on ]
「老实说宙替换过来的时候，[rhr]
_　我还在想这家伙的防御到底有多薄弱呢」[rhp]

[:princess:][puri_w kao=6 as=on ]
「喂！！为什么到最后还要说这种……！话说防御薄弱什么的，[rhr]
_　才不想被浑身排骨肌肉的快斗说呢」[rhp]

[off_all]

[:princess:][puri_w kao=6 as=on ]
「对吧？哈蒂君！」[rhp]

[off_all]

[:heartshape:][hati kao=5 ]
[font size=30]
「中门大开！！」[rhp]
[resetfont]

[se storage="hand_05.ogg"]

[yurasu]

[:kite:][kite kao=2 as=on ss=on ]
「呃啊！！」[rhp]

[off_all]

[chara_part name="kite" body=base kao=2 as=on ss=on hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="jet" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:jet:]
「没事吧快斗……」[rhp]

[:kite:]
「居然对前病人做这种事…！」[rhp]

[off_jet]

[chara_part name="hati" body=base kao=11 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:]
「我不搞这种歧视！！」[rhp]

[:kite:]
「不是，话是这么说…但不是这个问题……」[rhp]

[off_all]

[:drop:][drop kao=14 as=on ]
「哈哈……！看到你们还是老样子，真是让人放心」[rhp]
[:drop:][drop kao=1]
「……那么，该出发了」[rhp]

[off_all]

[::]
听到多洛普的话，所有人的表情都稍稍改变。[rhr]
话语减少，周围被沉默包围。[rhp]
必须说点什么。特别是……对哈蒂君。[rhp]
有太多想传达的事。[rhr]
从哪说起呢？没有犹豫的时间了。[rhp]

[:princess:][puri_w kao=3 as=on ]
「那个……」[rhp]

[off_all]

[fbgm]

[:heartshape:][hati kao=5 ]
「杰特！」[rhp]

[off_all]

[:princess:][puri_w kao=0 as=on ]
「……！」[rhp]

[bgm storage="bgm_40.ogg"]

[off_all]

[::]
在我开口前，哈蒂君突然高声喊道。[rhr]
突然被叫到名字的杰特君露出一脸茫然的表情。[rhp]
哈蒂君大步走向这样的杰特君，豪爽地搂住了他的肩膀。[rhr]
他似乎完全没注意到我的惊讶和杰特君的困惑。[rhp]

[chara_part name="jet" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:]
「那座山丘！风景看起来超棒！[rhr]
_　比比谁先跑到那里吧！」[rhp]

[:jet:]
「啊？你这家伙，最后好歹该和公主说说话」[rhp]

[:heartshape:][hati kao=14 ]
「已经说过了！」[rhp]

[off_all]

[chara_part name="hati" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=1 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:][puri_w kao=2 as=on ]
「胡说！明明没有！」[rhp]

[:heartshape:][hati kao=2 ]
「刚才说过啦！都拥抱过了，礼物也给过了！」[rhp]

[:princess:][puri_w kao=6 as=on ]
「那样就完了！？作为告别也太——[rhr]
_　从那时到现在已经过了好一会儿......！」[rhp]

[:heartshape:][hati kao=2 ]
「大概只能做到那种程度了！！」[rhp]
[:heartshape:][hati kao=3 as=on ]
「......因为再继续下去，我可能会哭！」[rhp]

[:princess:][puri_w kao=0 as=on ]
「……！」[rhp]

[off_all]

[chara_part name="jet" body=base kao=3 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=3 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:]
「......可恶，哭哭啼啼的太不像男人了......」[rhp]

[:jet:]
「哈蒂......」[rhp]

[:heartshape:][hati kao=14 as=on ]
「―――不过那个啊。毕竟是最后了，还是该说点什么吧！」[rhp]

[off_all]

[:princess:][puri_w kao=5 as=on ]
「……呵呵，什么嘛，真是的。结果到底是怎样啦？」[rhp]
[:princess:][puri_w kao=1 ]
「不过谢谢你。我也……因为能好好地道别而感到开心」[rhp]

[:heartshape:][hati kao=1 ]
「公主！」[rhp]

[:princess:][puri_w kao=13 ]
「哈蒂君……我、能遇见你真是太好――――――」[rhp]

[off_all]

;****************************************
[still storage="cg/d_h_10.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/d_h_10.png"]
;****************************************

[:princess:]
「…………！」[rhp]

[:heartshape:]
「…………嘿嘿！」[rhp]

;****************************************
[still_end frame="win.png" storage="real_03.jpg" time=1000]
;****************************************

[chara_part name="jet" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=11 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="645" top="0" wait="true" time=150]

[:kite:]
「咻」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:jet:]
[p_j_08]
「干得漂亮」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

;****************************************
[still storage="cg/d_h_11.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/d_h_11.png"]
;****************************************

[:heartshape:]
「我爱你啊，公主！」[rhp]

[:princess:]
「呃……！」[rhp]

[::]
哈蒂君露出太阳般灿烂的笑容。[rhp]
简短而单纯的话语。[rhr]
但却是最令人开心的话语。[rhp]
这简直犯规啊。[rhp]
这样一来，不就没办法说些伤感的话了吗。[rhp]
……任性的话，更是说不出口了。[rhp]

;*****************************************
[still_end frame="win.png" storage="real_03.jpg" rule="002.png" time=1000]
;*****************************************

[:heartshape:][hati kao=1 ]
「好啦！那么杰特，开始吧！」[rhp]

[:jet:][jet kao=2 as=on ]
「这样真的好吗……」[rhp]

[:heartshape:]
「当然好啦！我已经全力以赴了！」[rhp]
[:heartshape:]
「接下来就和你两个人一起上了！给我打起精神来！」[rhp]

[:jet:][jet kao=11 as=on ]
「…………，好好好」[rhp]

[off_all]

[:jet:][jet kao=5 ]
「……别输啊，哈蒂」[rhp]

[off_all]

[:heartshape:][hati kao=14 ]
「你也是，杰特！」[rhp]

[off_all]

[::]
两人的表情无比明朗。[rhr]
至少将这称为分别实在不太合适。[rhp]
这是……没错。[rhp]
这是启程。[rhp]

[off_all]

;*****************************************
[bg_rule storage="real_05.jpg" rule="002.png" time=1000]
;*****************************************

[::]
―――两人朝着山丘的方向奔跑起来。[rhp]

[:princess:]
「等、等等！　话还没说完……」[rhp]

[::]
即便出声呼唤也没有停下脚步。[rhr]
试图追赶却终究追不上。[rhp]
太快了。为什么？[rhr]
无法抵达。[rhp]

;*****************************************
[bg storage="real_06.jpg" time=1000]
;*****************************************

终于登顶的山丘之上。[rhr]
眼前是辽阔的汪洋大海。[rhp]
…………两人的身影，已无处可寻。[rhp]

;*****************************************
[bg storage="sky_02.jpg" time=1000]
;*****************************************

是吗。……已经离开了吗。[rhp]

[:princess:]
「…………」[rhp]

[::]
……好寂寞。这是从未体会过的孤独。[rhp]
还能再见面吗。[rhr]
刚才还莫名充满信心，但现在……[rhp]

[:sausu:]
「…………会再见的」[rhp]

;*****************************************
#
[bg storage="real_06.jpg" time=1000]
;*****************************************

[:sausu:][sausu kao=1 ]
「只要活着可能性就不是零」[rhp]
[:sausu:][sausu kao=13 ]
「因为我们都在同一片天空下」[rhp]

[off_all]

[::]
………或许确实如他所说。[rhr]
正因为是这个时代，此刻犹豫又有何用。[rhp]
『选择未来』的人是我。[rhr]
对于这个选择，我无悔。[rhp]

;*****************************************
[bg storage="real_07.jpg" time=1000]
;*****************************************

[:princess:]
「天亮了……」[rhp]
[:princess:]
「……快斗已经在下面了？」[rhp]

[::]
南微微点了点头。[rhp]

[:princess:]
「这样啊……、……真像是和君呢」[rhp]

[::]
他是个不愿向人示弱的人。[rhr]
发现这点在这个世界也未曾改变，我不禁露出一丝笑意。[rhp]
这般无趣是他的性格使然吧。[rhr]
亦或是……他早已心知肚明呢。[rhp]

[:princess:]
[font color=0x4682b4]
（这并非终点）[rhp]
[:princess:]
（……总有一天定能再度相逢）[rhp]
[resetfont]

[::]
没有丝毫悲伤。[rhp]
此刻的我正如此心潮澎湃。[rhp]

;*****************************************
[bg storage="real_06.jpg" time=1000]
;*****************************************

[:princess:][puri_w kao=1 ]
「那我出发了」[rhp]

[off_all]

[:sausu:][sausu kao=13 ]
「嗯」[rhp]
[:sausu:][sausu kao=1]
「……祝旅途愉快」[rhp]

[off_all]

;*****************************************
#
[bg storage="real_07.jpg" time=1000]
;*****************************************

[::]
眼前是波光粼粼的大海。[rhr]
背向南的微笑，我迈出了脚步。[rhp]

回首望去，尽是连续奇迹般的日子。[rhp]
本应无法实现的与挚友的重逢。[rhr]
在我即将终结的人生里，出现了不可能的邂逅。[rhp]
未曾想象的风景。[rhr]
一直渴望目睹的风景。[rhp]
这般旅程即将迎来终结。[rhp]

我由衷感到。[rhr]
至此已毫无遗憾。[rhp]
能诞生于世，真是太好了。[rhp]

[:princess:]
[font color=0x4682b4]
（总觉得这份心情，格外耀眼）[rhp]
[resetfont]

;*****************************************
#
[bg storage="white.jpg" time=1000]
;*****************************************

[::]
意识逐渐融化在光芒中。[rhp]
受到七色的祝福。[rhp]
用自己的手，打开门―――[rhp]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
[fbgm]

[s_mask color=0xffffff time=3000]
; 背景表示
[bg storage="white.jpg" time=100]
; ウィンドゥの設定
[position layer="message0" frame="win2.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[s_mask_off time=3000]

;****************************************

;集中治療室
;心電図の音だけが響く

[se storage="se5_11.ogg" loop=true]

……………。[r][l]
…………………………………………。[rhp]

;****************************************
[bg storage="hspt_06.jpg" time=1000]
;****************************************

……………。[r][l]
…………………………………………。[rhp]

;****************************************
;寝ているジェットのスチル
[still storage="cg/d_h_12.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/d_h_12.png"]
;****************************************

……………。[r][l]
…………………………………………。[rhp]
……………。[r][l]
…………………………………………。[rhp]
…………………[l]……………………[l]……………………、…………………[rhp]

;****************************************
[bg storage="cg/d_h_12b.png" width="1280" height="720" time=1500]
[cg storage="cg/d_h_12b.png"]
;****************************************

「……………――――――」[rhp]

[fse]

[eval exp="sf.clear_h = 1"]

[cm]

[s_mask color=0xffffff time=3000]

[jump storage="ev_f.ks" target="*start"]


