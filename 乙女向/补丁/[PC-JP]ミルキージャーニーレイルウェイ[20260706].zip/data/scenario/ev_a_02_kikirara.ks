﻿*start

;--------------------------------------------------------------------------------------------
;▼フルボイスセット▼

;カイト
[voconfig sebuf=1 name=kite vostorage="kite/full/{number}.ogg" number=33]
;クォードリリオン
[voconfig sebuf=1 name=riri vostorage="riri/full/{number}.ogg" number=16]
;魔太郎子
[voconfig sebuf=1 name=mata vostorage="mata/full/{number}.ogg" number=17]

;--------------------------------------------------------------------------------------------

;****************************************
[fbgm]
[set_00 storage="park_02.jpg"]
;****************************************

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
[vostart]
;--------------------------------------------------------------------------------------------

[bgm storage="bgm_21.ogg"]

[:kite:][kite kao=6 ]
「…………不觉得奇怪吗？」[rhp]

[:quadrillion:][riri kao=7 ]
「什么呀。完全没什么奇怪的事呀」[rhp]

[:kite:][kite kao=2 ]
「为什么我必须和克林一起[rhr]
_　逛什么游乐园啊……」[rhp]

[:quadrillion:][riri kao=6 ]
「又不是只有我，布兹和魔太郎子不也在嘛」[rhp]

[:kite:][kite kao=8 as=on ]
「不……就算你说他们也在……」[rhp]

[off_all]

[chara_part name="mata" body=base kao=14 as=off ss=off hh=on hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="421" top="0" wait="false" time="150"]
[chara_part name="puri_w" body=base kao=1 as=on ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:mataroko:]
「姐姐大人～～！魔太郎子从前可是姐姐大人的妹妹哟」[rhp]
[:mataroko:]
「啊、不过并没有血缘关系啦。[rhr]
_　就是所谓的义妹啦。以前可疼爱人家了呢」[rhp]
[:mataroko:]
「您不记得了吗？」[rhp]

[:princess:][puri_w kao=3 as=on ]
「唔、不记得了呢……抱歉啊」[rhp]

[:mataroko:][mata kao=3 hh=on ]
「没关系！没关系的姐姐大人。[rhr]
_　魔太郎子只要能和您相见就幸福极了！」[rhp]

[off_all]

[chara_part name="riri" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time="150"]
[chara_part name="kite" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time="150"]

[:kite:]
「看看魔太郎子。从一开场就火力全开」[rhp]

[:quadrillion:]
「感觉她完全没注意到我们呢……」[rhp]

[off_all]

[chara_part name="mata" body=base kao=5 as=off ss=off hh=on hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="421" top="0" wait="false" time="150"]
[chara_part name="puri_w" body=base kao=0 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:mataroko:]
「各位，我们说过会在旅途中现身对吧？[rhr]
_　不过我们也有适合与不适合的造访场所呢」[rhp]

[:princess:]
「适合不适合？」[rhp]

[:mataroko:][mata kao=6 ]
「是呀。该说是TPO吗？[rhr]
_　上次努西大人在歌剧院就被禁止入场了呢」[rhp]

[:princess:][puri_w kao=5 as=on ]
「啊…………」[rhp]

[:mataroko:][mata kao=11 ]
「你看，魔太郎子是没问题啦，但另外两位总爱违背公序良俗对吧？[rhr]
_　魔太郎子她啊，呃，真的完全没问题啦」[rhp]
[:mataroko:][mata kao=3 ]
「所以呢，有时候可能好几个月都见不到面的。[rhr]
_　魔太郎子，寂寞得不得了呢」[rhp]

[:princess:][puri_w kao=8 ]
「这样啊……地方巡演真是辛苦呢」[rhp]

[off_all]

[chara_part name="riri" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time="150"]
[chara_part name="kite" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time="150"]

[:kite:]
「那家伙完全在耍宝吧」[rhp]

[:quadrillion:]
「该不会误以为自己是搞笑艺人什么的？」[rhp]

[off_all]

[chara_part name="mata" body=base kao=5 as=off ss=off hh=on hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="421" top="0" wait="false" time="150"]
[chara_part name="puri_w" body=base kao=0 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:mataroko:]
「所以每次见面日人家都会超级认真准备的呢！[rhr]
_　特别是今天真的隔了好久！」[rhp]
[:mataroko:]
「怎么样姐姐大人，想起来了吗？」[rhp]

[:princess:][puri_w kao=6 as=on ]
「对、对不起……」[rhp]

[:mataroko:][mata kao=13 as=on hh=on ]
「！！　……没、没事的没事的！请别在意！」[rhp]
[:mataroko:]
「魔太郎子的胡言乱语就到此为止，[rhr]
_　今天请尽情享受这座游乐园吧！」[rhp]

[off_all]

[chara_part name="mata" body=base kao=5 as=off ss=off hh=on hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="80" top="0" wait="false" time="150"]
[chara_part name="riri" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="383" top="0" wait="false" time="150"]
[chara_part name="kite" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="760" top="0" wait="true" time="150"]

[:mataroko:]
「各位也是！[rhr]
_　请给魔太郎子和姐姐大人最棒的招待哦！」[rhp]

[:quadrillion:]
「不要啦～」[rhp]

[:kite:]
「老毛病犯困了」[rhp]

[:princess:][puri_w kao=6 as=on ]
「真是的～～～～……！[rhr]
_　这两个人完全提不起劲呢」[rhp]
[:princess:]
[font color=0x4682b4]
（因为从刚才开始就兴致缺缺的样子，[rhr]
_　才特意邀请这两人想活跃气氛的说）[rhp]
[:princess:]
（没想到这两个家伙比预想的更难对付……！[rhr]
_　多亏魔太郎子酱才能勉强维持住场面啊……）[rhp]
[resetfont]

[off_all]

[:mataroko:][mata kao=11 ]
「呼，真是够了……」[rhp]
[:mataroko:][mata kao=5 ]
「……………让我也来助一臂之力吧」[rhp]

[:princess:][puri_w kao=4 as=on ]
「你有办法动员这群懒鬼吗？」[rhp]

[:mataroko:][mata kao=5 ]
「嗯。别看魔太郎子这样，其实是个谋士呢……！」[rhp]

[off_all]

[chara_part name="mata" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="kite" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time="150"]

[:mataroko:]
「……啊、对了～！　快斗先生之前不是说过[rhr]
_　想挑战巨型迷宫什么的吗？」[rhp]

[:kite:]
「哈？」[rhp]

[off_all]

[chara_part name="riri" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time="150"]
[chara_part name="mata" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:mataroko:]
「哎呀～！？　夸德里利昂不是说过[rhr]
_　想戴动物耳朵发箍拍照留念吗！」[rhp]

[:quadrillion:]
「我说你啊。就算我们[rhr]
_　兴致不高 也不能擅自——」[rhp]

[off_all]

;****************************************
[se storage="se4_06.ogg"]
[s_mask color=0xffffff time=500]

; ウィンドゥの非表示
[layopt layer="message0" visible="false"]

[s_mask_off time=500]

[bg_rule storage="cg/a_02_r_1.png" rule="021.png" width="1280" height="720" time=1000]
[cg storage="cg/a_02_r_1.png"]

; ウィンドゥの設定
[position layer="message0" frame="win3.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
; ウィンドゥの表示
[layopt layer="message0" visible="true"]
;****************************************

[:mataroko:]
「太棒了～！　姐姐大人实在太可爱了！[rhr]
_　和魔太郎子戴同款呢！」[rhp]

[:princess:]
「玛塔也很适合哦！超可爱！」[rhp]
[:princess:]
[font color=0x4682b4]
（虽然手段太过强硬了……！）[rhp]
[resetfont]

[:2nin:]
「……………………」[rhr]
「……………………」[rhp]

[:princess:]
「魔太郎子真厉害。居然真能让这两人戴上耳朵[rhr]
_　还带进迷宫游乐设施。魔法真是无敌啊」[rhp]
[:princess:]
[font color=0x4682b4]
（嘛，要是这样他们发火的话 矛头应该会指向我吧……）[rhp]
[resetfont]

[:quadrillion:]
「讨厌啦～ 意外地很适合嘛。不愧是本小姐」[rhp]

[:kite:]
「哎呀呀……不管做什么，都……」[rhp]

[:mataroko:]
「看起来玩得挺开心呢」[rhp]

[:princess:]
「虽然开头很糟糕，但进入状态后还不错嘛」[rhp]

****************************************
;スチル終了
[still_end frame="win.png" storage="park_07.jpg" rule="021.png" time=300]
;****************************************

[:kite:][kite kao=13 ]
「给公主。我的份也请戴上吧」[rhp]

[:princess:][puri_w kao=2 as=on ]
「哎、等、等等。不需要啦？[rhr]
_　戴2个果然还是太奇怪了吧」[rhp]

[:kite:][kite kao=5 ]
「很可爱啊，超级可爱」[rhp]

[:princess:][puri_w kao=2 as=on ss=on ]
「骗人！！」[rhp]

[:kite:][kite kao=5 ]
「六只耳朵……简直像刻耳柏洛斯。可爱的小东西……」[rhp]

[:princess:][puri_w kao=6 as=on ]
「……！？　虽、虽然不太明白，谢谢……」[rhr]
[font color=0x4682b4]
（刻耳柏洛斯是什么啊……）[rhp]
[resetfont]

[off_all]

[chara_part name="riri" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time="150"]
[chara_part name="mata" body=base kao=14 as=off ss=off hh=on hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:mataroko:]
「呀啊啊！快看啊夸德里利昂！？[rhr]
_　那两个人简直像画一样呢……！」[rhp]

[:quadrillion:]
「诶？不、……嗯？唔——嗯……」[rhp]

[:mataroko:][mata kao=5 hh=on ]
「快斗先生×姐姐大人……多么尊贵……爱了爱了……」[rhp]

[:quadrillion:][riri kao=13 ]
「～～～～～～……我呢？」[rhp]

[:mataroko:][mata kao=0 ]
「嗯？」[rhp]

[:quadrillion:]
「我×布兹。怎么样？」[rhp]

[:mataroko:][mata kao=13 ]
「唔—嗯，魔太郎子的话就有点」[rhp]

[:quadrillion:][riri kao=2 as=on ]
[font size=28]
「这样啊！！！！！！[rhr]
[resetfont]
_　才～～不稀罕呢，那种布兹！！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[off_all]

[:princess:][puri_w kao=6 ]
「喂克林！别在暗处鬼鬼祟祟的」[rhp]

[:quadrillion:][p_r_29][riri kao=13 ]
「啊啦抱歉—。不愧是刻耳柏洛斯，[rhr]
_　六只耳朵听得清清楚楚呢！」[rhp]

[:princess:][puri_w kao=2 hh=on ]
「别以为夸两句就能糊弄过去！！」[rhp]

[:quadrillion:][p_r_10][riri kao=2 as=on ]
「都说了没在夸！所以笨蛋才讨厌。根本没法沟通！」[rhp]

[off_all]

[chara_part name="riri" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time="150"]
[chara_part name="kite" body=base kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time="150"]

[:quadrillion:]
「真是的——！说到底都是快斗的错。[rhr]
_　这种情况你要怎么负责，嗯？」[rhp]

[:kite:]
「我？怎么看都是不知道刻耳柏洛斯的公主不好吧」[rhp]

[:quadrillion:]
「那种事怎样都无所谓啦。[rhr]
_　我说的当然是这个巨大迷宫的事啊」[rhp]
[:quadrillion:][riri kao=6 as=on ]
「……我们在这里，已经迷路差不多20分钟了哦！？」[rhp]

[:kite:][p_k_02][kite kao=6 ]
「那是魔太郎子的错。我又没说过想玩迷宫」[rhp]

[off_all]

[:mataroko:][p_mt_11][mata kao=8 as=on ]
「可、可是！　要说小瞧了游乐园什么的……[rhr]
_　没想到会这么难嘛！」[rhp]

[:princess:][puri_w kao=3 as=on ]
「破罐子破摔拍照的时候就没救了。不快点找出口的话」[rhp]

[:mataroko:][p_mt_18][mata kao=3 as=on ]
「对不起，姐姐大人……[rhr]
_　都怪魔太郎子高估了大家的头脑……」[rhp]

[off_all]

[chara_part name="riri" body=base kao=2 as=on ss=on hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time="150"]
[chara_part name="kite" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time="150"]

[:quadrillion:][p_r_03]
「挺毒舌的啊，你……」[rhp]

[off_all]

[:mataroko:][p_mt_33][mata kao=13 as=on ]
「啊！　骗人的骗人的！[rhr]
_　硬拉着大家进迷宫的全都是魔太郎子的错啦！」[rhp]

[:princess:][puri_w kao=5 as=on ]
「没关系啦魔太郎子。[rhr]
_　谁都不会预料到这种事。别放在心上」[rhp]

[:mataroko:][mata kao=8 as=on hh=on ]
「姐、姐姐大人……！」[rhp]

[off_all]

[chara_part name="riri" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time="150"]
[chara_part name="kite" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time="150"]

[:quadrillion:][p_r_18]
「不过该怎么办呢。这样干耗着也不是办法」[rhp]

[:kite:][p_k_17]
「哈～啊……困……」[rhp]

[:quadrillion:][riri kao=8 as=on ]
「这种状况居然还犯困啊……[rhr]
_　别发呆了，你也该认真想想了」[rhp]

[:kite:][kite kao=7 ]
「正因为想着才犯困啊……」[rhp]
[:kite:]
「……呃——……这种情况下是不是该分头行动？」[rhp]

[:princess:][puri_w kao=4 ]
「一般都是这样吗？」[rhp]

[:kite:][kite kao=12 ]
[font color=0x4682b4]
（虽然我也不确定）[rhp]
[resetfont]
[:kite:][kite kao=6 ]
「……呃——……从两侧分别探索，[rhr]
_　无论有无出口都先返回原处」[rhp]
[:kite:]
「然后选中正确路线的小队，[rhr]
_　最后大家再一起前进不就好了？漫画里好像这么画过」[rhp]

[:princess:][puri_w kao=8 as=on ]
「原来如此……但真的可行吗？[rhr]
_　说是返回原处，真能准确记住方位吗」[rhp]

[:kite:][p_k_01][kite kao=13 ]
「我倒无所谓，但克林肯定没问题。[rhr]
_　你那么聪明，最擅长这种事吧」[rhp]

[:quadrillion:][p_r_19][riri kao=6 ]
「太阳打西边出来了？你居然会夸我」[rhp]

[:kite:][kite kao=13 ]
「猪仔捧上天也会飘」[rhp]

[:quadrillion:][p_r_21][riri kao=2 ss=on ]
[font size=28]
「你这混账！！！给我滚出来！！！」[rhp]
[resetfont]

[:kite:][kite kao=7 ]
「已经滚出来了啦～」[rhp]

[off_all]

[:kite:][kite kao=11 ]
「那我先往右边探索。[rhr]
_　克林左边就交给你了」[rhp]

[off_kite]

[:quadrillion:][riri kao=2 ]
「切……！算了，吵架也没用。[rhr]
_　这群小鬼真是的，早该依靠本小姐了」[rhp]

[off_riri]

[chara_part name="mata" body=base kao=5 as=off ss=off hh=on hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="421" top="0" wait="false" time="150"]
[chara_part name="puri_w" body=base kao=0 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:][puri_w kao=13 ]
「总算看到点希望了。[rhr]
_　大伙加油逃出去吧！」[rhp]

[:mataroko:][p_mt_02][mata kao=14 hh=on ]
「哦！」[rhp]

;****************************************
[fbgm]
[set_00 storage="park_07b.jpg"]
;****************************************

[bgm storage="bgm_20.ogg"]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[::]
随后我们用猜拳决定分成两人一组。[rhr]
结果，我和快斗被分到右侧的迷宫。[rhp]

[:princess:][puri_w kao=8 ]
「没问题吧，克林和玛塔」[rhp]

[:kite:][kite kao=12 ]
「克林可是当中最壮实的」[rhp]

[:princess:][puri_w kao=6 ]
「壮实也不见得擅长走迷宫啊」[rhp]

[:kite:][kite kao=7 ]
「也许吧～」[rhp]

[:princess:][puri_w kao=3 as=on ]
「真是的，动不动就自暴自弃」[rhp]
[:princess:]
「……也是，和我两人同行话题也热闹不起来[rhr]
_　觉得无聊我能理解啦」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:kite:][kite kao=0 ]
「……！」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:princess:][puri_w kao=2 ]
「但随便应付可不行！　遇到麻烦可是两个人的事。[rhr]
_　别轻易放弃坚持到最后一刻啊」[rhp]

[:kite:][kite kao=2 ]
「……………」[rhp]
[:kite:]
「……………………根本没说过嘛」[rhp]

[:princess:][puri_w kao=0 ]
「咦？　什么？」[rhp]

[:kite:][kite kao=3 ]
「…………我根本没说过'觉得无聊'这种话」[rhp]

[:princess:][puri_w kao=4 as=on ]
「啊……！　对、对不起……」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:kite:][kite kao=3 ]
「…………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:princess:][puri_w kao=6 as=on ]
「…………」[rhp]

[off_all]

[::]
……不过沉默果然还是令人尴尬啊……[rhp]

[:kite:]
「………………那个啊，公主」[rhp]

[::]
片刻后，快斗轻声开口。[rhp]

[:kite:][kite kao=3 ]
「你的记忆果然还是……」[rhp]

[:princess:][puri_w kao=0 ]
「？　记忆确实……还没恢复。怎么了吗？」[rhp]

[:kite:][kite kao=3 ]
「………………不。还是算了」[rhp]

[:princess:][puri_w kao=0 ]
「原来快斗也在担心我失忆的事。有点意外」[rhp]

[:kite:][kite kao=7 ]
「………………嘛，多少有点吧？」[rhp]
[:kite:]
「希望能早点恢复。……虽然也不是说恢复不恢复怎样都好」[rhp]

[:princess:][puri_w kao=1 hh=on ]
「………………」[rhp]

[:kite:][kite kao=6 as=on ]
「……什么？你笑得那么诡异」[rhp]

[:princess:][puri_w kao=13 ]
「……我好像有点明白了」[rhp]
[:princess:][puri_w kao=5 ]
「快斗那家伙啊。是青春期别扭症候群吧」[rhp]

[:kite:][kite kao=2 as=on ]
「哈……？说什么呢？」[rhp]

[:princess:][puri_w kao=5 ]
「和女生说话会觉得害羞对吧」[rhp]

[:kite:][kite kao=8 as=on ]
「………………。您没病吧」[rhp]

[:princess:][puri_w kao=11 ]
「说起来克林也算女生那边的吧。[rhr]
_　呵呵呵，你对人家那么冷淡」[rhp]

[:kite:][kite kao=2 as=on ss=on ]
[font size=27]
「唯独这点绝对是大误判！！！！！！」[rhp]
[resetfont]

[:princess:][puri_w kao=5 hh=on ]
「否认得太拼命了！反而很可疑！」[rhp]

[:kite:][kite kao=6 as=on ss=on ]
「啊、那个啊……！真的别再说这种话了！」[rhp]

[off_kite]

[:princess:][puri_w kao=13 hh=on ]
[font color=0x4682b4]
（呵呵！什么嘛。这么想的话快斗也有可爱之处啊！[rhr]
_　还以为被讨厌了，这样的话……）[rhp]
[resetfont]

[off_puri]

[fbgm]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:unknown:]
「哎呀！公主殿下！？」[rhp]

[::]
正和快斗争执时，左手边突然有人叫了我的名字。[rhp]
我们两人几乎同时转向声源处。[rhp]

;****************************************
[bg_rule storage="park_07c.jpg" rule="002.png" time=500]
;****************************************

[bgm storage="bgm_17.ogg"]

[:princess:][puri_w kao=5 hh=on ]
「啊……啊啊啊！！？」[rhp]

[off_puri]

[::]
方才只顾说话没注意到，砖砌小道不知何时已到尽头[rhr]
前方赫然站着单独行动的哈蒂君一行人。[rhp]

[chara_part name="jet" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="80" top="0" wait="false" time="150"]
[chara_part name="hati" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="421" top="0" wait="false" time="150"]
[chara_part name="gon" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="720" top="0" wait="true" time="150"]

[:heartshape:]
「你们这群小鬼头在玩迷宫吗！？真幼稚～」[rhp]

[:gonzalez:][gon kao=11 ]
「哼……！倒挺风雅……」[rhp]

[:jet:][jet kao=6 ]
「什么风雅？」[rhp]

[off_all]

[chara_part name="kite" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="383" top="0" wait="false" time="150"]
[chara_part name="puri_w" body=base kao=4 as=on ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「大、大家都在……也就是说……」[rhp]

[:kite:][p_k_01][kite kao=11 ]
「找到了呢。出口」[rhp]

[:princess:][puri_w kao=14 hh=on ]
「――――！　找到了出口！[rhr]
_　还以为永远都走不出去了呢！」[rhp]

[off_all]

[::]
我如释重负般，正准备跑向三人身边。[rhp]

;ガシッ
[yurasu]
[se storage="hand_01.ogg"]
…………但。[rhp]


[:princess:][puri_w kao=5 as=on ]
「……诶」[rhp]

[off_puri]

[::]
…………后颈突然被皱起眉头的快斗一把抓住。[rhp]

[chara_part name="kite" body=base kao=5 as=on ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="383" top="0" wait="false" time="150"]
[chara_part name="puri_w" body=base kao=4 as=on ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:kite:][p_k_04]
「刚才的话题还没说完呢。[rhr]
_　说我青春期啥的……！」[rhp]

[:princess:][puri_w kao=14 as=on ]
「嘛、嘛嘛嘛！那种事无所谓啦」[rhp]


[off_all]

「比起这个，击掌！」[rhp]

[::]
我制止快斗的话头，将一只手举到他面前。[rhp]


或许是察觉到了我的意图，[rhr]
快斗露出微妙的表情移开视线。[rhp]
倒也不是想蒙混过关……虽然也不是完全不这么想。[rhr]
不过暂且当做告一段落吧。[rhp]

[chara_part name="kite" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="383" top="0" wait="false" time="150"]
[chara_part name="puri_w" body=base kao=13 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「来嘛！击掌庆祝！」[rhp]

[:kite:][p_k_30]
「这也太老土了吧……」[rhp]

[:princess:]
「有什么关系有什么关系。[rhr]
_　跨过青春期的大人都会做这种事啦」[rhp]

[:kite:][p_k_27][kite kao=6 as=on ]
「……啧、给我记着……」[rhp]

[off_all]

[::]
虽然还在嘟嘟囔囔，但或许是我的话起了效果，[rhr]
快斗还是不情不愿地伸出了手。[rhp]

;****************************************
[se storage="hand_10.ogg"]
[bg storage="sky_04.jpg" time=300]
;****************************************

――――啪！当掌心相叠的瞬间。[rhr]
心中涌起难以言喻的成就感。[rhp]
虽然很辛苦，但或许意外地还挺开心……！[rhp]

;****************************************
[bg storage="park_07c.jpg" time=1000]
;****************************************

[chara_part name="jet" body=base kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="hati" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:jet:][p_j_09]
「不过就是走出个迷宫。小鬼就是小鬼」[rhp]

[:heartshape:][p_h_15]
「不、说不定是个超级难的迷宫呢……！[rhr]
_　明天就要挑战这家伙了！杰特！」[rhp]

[:jet:][p_j_13][jet kao=6 as=on ]
「诶？啊——……好吧，既然是哈蒂说的就陪你吧」[rhp]

[off_all]

[:gonzalez:][p_gn_04][gon kao=0 ]
「好了。今天差不多该回去了。园区很大，[rhr]
_　别搞得太晚。你们今晚住这里的旅馆对吧」[rhp]

[:princess:][puri_w kao=1 ]
「对哦！是该赶紧回去了」[rhp]

[off_all]

[chara_part name="kite" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="160" top="0" wait="false" time="150"]
[chara_part name="hati" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:kite:][p_k_05]
「啊——累死了……回房间就要立刻睡觉……」[rhp]

[:heartshape:][p_h_02][hati kao=2 ]
「笨蛋！快斗！别开玩笑了！[rhr]
_　今晚是UNO大会！　早上不是约好了吗！」[rhp]

[:kite:][kite kao=6 as=on ]
「……………………」[rhp]

[:heartshape:][hati kao=4 as=on ]
「啊，有吗！？」[rhp]

[:kite:][kite kao=11 as=on ]
「没有吧」[rhp]

[off_all]

[:princess:][puri_w kao=5 ]
「嘴上这么说，其实心里很想玩UNO吧。[rhr]
_　快斗正值青春期所以不坦率呢」[rhp]

[:kite:][p_k_10][kite kao=2 as=on ]
「哈？等等」[rhp]

[off_all]

[:heartshape:][hati kao=13 ]
「靠，谢了啊……！！青春期！？」[rhp]

[off_all]

[chara_part name="jet" body=base kao=11 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="hati" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:hutago:]
[font size=23]
「感激不尽！！」[rhr]
「感激不尽！！」[rhp]
[resetfont]

[off_all]

[chara_part name="kite" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="383" top="0" wait="false" time="150"]
[chara_part name="puri_w" body=base kao=13 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「呼呼。今天可够忙的，快斗！」[rhp]

[:kite:]
「～～～～！　……你给我记住，绝对是认真的！」[rhp]

[off_all]

[chara_part name="gon" body=base kao=11 as=off ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="152" top="0" wait="false" time="150"]
[chara_part name="jet" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:gonzalez:]
「呵……挺有骨气嘛……！」[rhp]

[:jet:][p_j_10]
「所以呢？」[rhp]

[off_all]

;****************************************
#
[fbgm]
[bg storage="black.jpg" time=2000]
;****************************************

你可曾注意到……[rhp]

;****************************************
[bg storage="park_07.jpg" method="fadeInRightBig" time=2000]
;****************************************

[:quadrillion:][riri kao=2 as=on ]
「…………………………」[rhp]

[off_all]

[:mataroko:][mata kao=2 as=on ]
「…………………………」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[chara_part name="riri" body=base kao=6 as=on ss=on hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="mata" body=base kao=6 as=on ss=on hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:quadrillion:]
「我们该不会被遗忘了吧？」[rhp]

[:mataroko:]
「很有可能呢……」[rhp]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
[set_00 storage="sky_06.jpg" time=1000]
;****************************************

[bgm storage="bgm_18.ogg"]

这时才想起夸德里利昂他们的存在，[rhr]
等到全员汇合后我们开始游览游乐园。[rhp]
在魔太郎子的主导下顺利带动了两个男生，[rhr]
算是度过了相当充实的一天！太好了太好了。[rhp]

;****************************************
[fbgm]
[bg storage="park_01e.jpg"]
;****************************************

[bgm storage="bgm_18.ogg"]

焕然一新的游乐园让人兴奋不已，[rhr]
转眼间时间流逝，回过神来已是傍晚。[rhp]

[:nusi:][p_ns_02][nusi ]
「好嘞、人都到齐了吧。[rhr]
_　时候也不早了，咱们今天就到这儿吧」[rhp]

[:princess:][puri_w kao=13 ]
「今天谢谢你们！托大家的福玩得超开心」[rhp]

[off_all]

[chara_part name="mata" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="80" top="0" wait="false" time="150"]
[chara_part name="riri" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="383" top="0" wait="false" time="150"]
[chara_part name="kite" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="760" top="0" wait="true" time="150"]

[:kite:][p_k_31]
「确实挺有意思。主要归功于那边穿粉红的两位」[rhp]

[:mataroko:][p_mt_09]
「真是的！说什么有意思，这算什么意思嘛！[rhr]
_　我们这边可是手忙脚乱呢！」[rhp]

[:quadrillion:][p_r_29]
「就是就是。要不是我打穿砖墙带大家脱困，[rhr]
_　你们怕是要永远遗忘我们了！」[rhp]

[:kite:][kite kao=2 ss=on ]
「这个嘛…………」[rhp]

[off_all]

[chara_part name="mata" body=base kao=11 as=off ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="421" top="0" wait="false" time="150"]
[chara_part name="puri_w" body=base kao=1 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:mataroko:][p_mt_31]
「虽然遭遇了惨况……[rhr]
_　不过姐姐大人满意的话就好」[rhp]
[:mataroko:][mata kao=13 ]
「觉得如何姐姐大人？游乐园开心吗？」[rhp]

[:princess:][puri_w kao=13 ]
「嗯！超级开心！」[rhp]

[off_all]

[jump storage="ev_a_02.ks" target="*return"]

