﻿
*start

;--------------------------------------------------------------------------------------------
;▼フルボイスセット▼
;ソラ
[voconfig sebuf=1 name=sora vostorage="sora/full/{number}.ogg" number=54]
;ドロップ
[voconfig sebuf=1 name=drop vostorage="drop/full/{number}.ogg" number=133]
;--------------------------------------------------------------------------------------------

[:drop:][p_d_04][drop kao=13 hat=on ]
「……公主。宙先生就拜托您了」[rhp]

[:princess:][puri_w kao=3 as=on ]
「……！」[rhp]

[:drop:][p_d_33][drop kao=8 hat=on ]
「我比任何人都了解宙先生的心情」[rhp]
[:drop:]
「比这世上任何人都更清楚他对您深切的爱意、悔恨与留恋。[rhr]
_　正因如此才唯独想实现他的愿望」[rhp]
[:drop:]
「希望作为另一个我的他能获得幸福。[rhr]
_　只要这个愿望能实现，我变成怎样都无所谓」[rhp]

[:princess:][puri_w kao=6 ]
「但即便如此，你要消失这种事」[rhp]

[:drop:][p_d_34][drop kao=1 hat=on ]
「并非消失。[rhr]
_　我永远都会活在他的心中」[rhp]
[:drop:]
「就当是请了个稍长的假期。[rhr]
_　虽然很抱歉……但看在我至今努力的份上，请原谅我吧」[rhp]

[:princess:][puri_w kao=3 as=on ]
「……呜、太狡猾了……被你这么一说」[rhp]

[off_all]

[:sora:][p_so_01][sora kao=0 ]
「说得好」[rhp]

[off_all]

[:princess:][puri_w kao=8 ]
「……！」[rhp]

[off_all]

[::]
不知何时，落合君已站在身后。[rhp]
那对分不清是愤怒还是毫无情绪的冰冷眼眸，[rhr]
正直直盯着多洛普的方向。[rhp]

[chara_part name="drop" body=base kao=12 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sora" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:drop:][p_d_04]
「宙先生，为什么在这里」[rhp]

[:sora:][sora kao=7 ]
「来帮忙的。因为你太温柔，[rhr]
_　我担心你会无法明确向公主道别」[rhp]
[:sora:]
「躲开那些家伙的耳目过来可真不容易」[rhp]

[:drop:][drop kao=14 hat=on ]
「没这个必要。我意外地是个固执的人呢」[rhp]

[:sora:][p_so_22][sora kao=6 ]
「我知道。从各种意义上来说」[rhp]

[:drop:][drop kao=12 as=on hat=on ]
「哈哈……确实如此」[rhp]

[:princess:][puri_w kao=3 as=on ]
「等一下，别擅自推进话题啊。[rhr]
_　我还不能接受」[rhp]

[:drop:][drop kao=3 hat=on ]
「对不起，公主。……这是已经决定的事」[rhp]

[off_all]

[::]
那充满坚定意志的话语让人无从反驳。[rhr]
就在犹豫下一句话时，两人的对话已不断向前推进。[rhp]

[chara_part name="drop" body=base kao=1 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sora" body=base kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:drop:]
「宙先生。这条铁道拜托您了。[rhr]
_　若是宙先生的话应该能托付这条鐡道」[rhp]

[:sora:][p_so_28][sora kao=6 ]
「…………。还以为你会更固执些」[rhp]

[:drop:][drop kao=13 hat=on ]
「自从你作为落合初次来到这条铁道那天起，[rhr]
_　我就认定总有一天会变成这样」[rhp]

[:sora:][p_so_01][sora kao=1 ]
「…………这样啊」[rhp]
[:sora:]
「这边的事就交给我吧。绝对不会让你后悔的」[rhp]

[:drop:][p_d_01][drop kao=1 hat=on ]
「嗯，很可靠呢」[rhp]

[off_all]

[:princess:][puri_w kao=6 ]
「……………………」[rhp]

[:sora:][sora kao=0 ]
「…………，……我说公主。换我就真的不行吗」[rhp]

[:princess:][puri_w kao=8 as=on ]
「不是行不行的问题，这种事……实在太突然了」[rhp]

[:sora:][p_so_10][sora kao=2 ]
「……………………是吗」[rhp]
[:sora:]
「那用你的记忆交换如何」[rhp]

[:princess:][puri_w kao=2 ]
「―――哎」[rhp]

[off_all]

[chara_part name="drop" body=base kao=4 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sora" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:drop:]
「记忆？这是什么意思？」[rhp]

[:sora:][p_so_02][sora kao=5 ]
「解除南的魔法有两种方法。[rhr]
_　其中一种，我刚好知晓」[rhp]

[:drop:][p_d_12][drop kao=3 hat=on ]
「为什么……你究竟从哪里得知这种方法」[rhp]

[off_all]

[::]
这话题如同多洛普的决心般唐突。[rhr]
连心理准备都还没做好。该接受吗……[rhp]

[:sora:][sora kao=0 ]
「…………可能会伤害你。但如果是你应该没问题」[rhp]

[fbgm]

[:sora:]
「记忆的钥匙，就是你的梦」[rhp]

[:princess:][puri_w kao=3 ]
「梦……？」[rhp]

[:sora:]
「虽然你一直固执地隐瞒，但我……其实早就知道了」[rhp]
[:sora:]
「你的梦是――――――」[rhp]

[off_all]
[free_filter ]

;****************************************
;****************************************
;****************************************
;****************************************

;回避フラグ

[if exp="sf.d_d_end == 1"]
要跳过公主的往事篇章吗？[rhr]　【[link target="*start2"]是[endlink]/[link storage="ev_d_drop4.ks" target="*start"]否[endlink]】
[s]
[endif] 

; →【ev_d_drop4】へ
[jump storage="ev_d_drop4.ks" target="*start"]

;****************************************
;****************************************
;****************************************
;****************************************

*start2

[cm]

;****************************************
[set_w storage="park_03n.jpg"]
; 夜フィルター
[filter layer="1" brightness="60"]
[bgm storage="bgm_19.ogg"]
;****************************************

[:princess:][puri_w kao=4 ]
「………………」[rhp]

[off_all]

[::]
……这就是我的过去……[rhp]
…………全部、全部都想起来了。[rhp]

[:princess:][puri_w kao=3 ]
「……没错……我是……」[rhp]
[:princess:][puri_w kao=2 ]
「…………我的名字是，星名媛子」[rhp]

[:sora:][p_so_01][sora kao=0 ]
「没错」[rhp]

[:princess:][puri_w kao=3 as=on hh=on ]
「呃！　宙、宙君……」[rhp]

[:sora:][p_so_07][sora kao=1 ]
「…………终于肯用名字称呼我了」[rhp]

[off_all]

[:drop:][drop kao=1 hat=on ]
「太厉害了……真的、公主的记忆……」[rhp]

[off_all]

[chara_part name="sora" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=8 as=off ss=off hh=on hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「宙君对不起，我……完全没能想起来」[rhp]

[:sora:][p_so_28][sora kao=13 ]
「没关系啦。……我也让你等了这么久」[rhp]
[:sora:]
「明明夸下海口说要治好你的病，[rhr]
_　结果还是没赶上……该道歉的是我才对」[rhp]

[:princess:][puri_w kao=1 ]
「没有的事。我只要听到宙君这么说就……！」[rhp]

[off_all]

[:sausu:][p_s_20][sausu kao=2 ]
「――――――哎呀呀。来晚一步呢」[rhp]

[off_all]

[chara_part name="drop" body=base kao=3 as=off ss=nf hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sora" body=base kao=2 as=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:drop:][p_d_11]
「！　南……」[rhp]

[off_all]

[:sausu:][sausu kao=13 ]
「哟各位。日安……看来不太合适呢」[rhp]

[:princess:][puri_w kao=0 ]
「……南。好久不见」[rhp]

[:sausu:][sausu kao=14 ]
「你好，公主。……你的眼神真不错呢」[rhp]
[:sausu:]
「和那天一样，充满意志的眼神」[rhp]

[:princess:][puri_w kao=2 ]
「………………」[rhp]

[:sausu:][p_s_30][sausu kao=0 as=on ]
「被摆了一道啊。没想到宙居然知道记忆恢复的条件……」[rhp]

[off_all]

[chara_part name="drop" body=base kao=1 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sora" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sora:]
「是听夜说的。说是要作为对付南的王牌」[rhp]
[:sora:]
「……不过最终，因为不想输给你就用掉了」[rhp]

[:drop:][drop kao=13 as=on hat=on ]
「总、总之能恢复记忆真是太好了。我放心了」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="293" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=1 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:sausu:][p_s_27]
「…………也就是说，你也想起和我的赌约了吧」[rhp]

[:princess:][puri_w kao=11 ]
「嗯。在毫不知情的情况下走到这里，如今想起一切后……[rhr]
_　……是要留在这个世界，还是」[rhp]

[:sausu:][p_s_16][sausu kao=13 ]
「回到那个充满悲伤的现实」[rhp]
[:sausu:]
「那么听听看吧。……你的答案是？」[rhp]

[off_all]

[::]
平静却充满压迫感，渗透着自信的声音。[rhr]
仿佛在说答案早已不言自明。[rhp]
我闭上眼睛，深深吸气，然后呼出。[rhr]
心已决断。[rhp]

[:princess:][puri_w kao=12 ]
「…………不变。我不会留在这里」[rhp]

[:sausu:][sausu kao=2 as=on ]
「…………诶」[rhp]

[:princess:][puri_w kao=1 ]
「在全部回忆起来之后，接着……[rhr]
_　经历过至今的旅程后，我要再说一次」[rhp]
[:princess:]
「银河铁道我已经充分享受过了。[rhr]
_　所以现在，我要回到现实世界了」[rhp]

[:sausu:][sausu kao=4 as=on ]
「什……！说什么傻话。你知道——[rhr]
_　就算回到现实世界也没有你的容身之处！」[rhp]
[:sausu:]
「那时光景已不可能重现。[rhr]
_　你获得重生后，这次要成为真正完全不同的―――」[rhp]

[:princess:][puri_w kao=13 ]
「即便如此也无妨。正因如此我才想要重来。[rhr]
_　这次定要靠自己的力量实现梦想」[rhp]

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
;ソラ
[voconfig sebuf=1 name=sora vostorage="sora/full/{number}.ogg" number=54]
;ドロップ
[voconfig sebuf=1 name=drop vostorage="drop/full/{number}.ogg" number=133]
[vostart]
;--------------------------------------------------------------------------------------------

[off_all]

[:sora:][sora kao=2 ]
「等等！这和说好的不一样！我留在这里是为了和你——」[rhp]

[:princess:][puri_w kao=14 hh=on ]
「回去吧宙君。你也一起」[rhp]

[:sora:][sora kao=8 as=on ]
「哈……！？」[rhp]

[:princess:][puri_w kao=1 ]
「我很清楚。已经无法再和你相伴了。[rhr]
_　即便如此，依然希望你活下去」[rhp]
[:princess:]
「…………我啊，一直都喜欢着宙君」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:sora:][sora kao=8 hh=on ]
「――――――！」[rhp]

[:princess:][puri_w kao=13 hh=on ]
「能直言不讳的宙君特别帅气。[rhr]
_　我也梦想成为那样，能坦然表达心意的人」[rhp]
[:princess:]
「所以明知希望渺茫还是……[rhr]
_　忠于内心报考了护理学校」[rhp]
[:princess:]
「不论结果如何，这份梦想都因你而生。[rhr]
_　……谢谢。能遇见你真是太好了」[rhp]
[:princess:]
「很感谢你追到这里来。[rhr]
_　无论我变成怎样都陪伴左右的心意，唯有感激」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sora:][sora kao=3 as=on ]
「为、为什么用过去式啊。完全听不懂……！[rhr]
_　今后也要在一起。终于能永远留在你身边了！」[rhp]

[:princess:][puri_w kao=5 ]
「这不是理所当然嘛。因为我最喜欢你了，会永远住在你心里。[rhr]
_　只要闭上眼睛，你就会出现在比任何人都近的地方哦」[rhp]

[:sora:][sora kao=8 as=on ]
「……、说什么呢这是……」[rhp]

[:princess:][puri_w kao=13 ]
「我啊，一直被宙君支撑着。[rhr]
_　但今后你会迎来被更多人需要的日子哦」[rhp]
[:princess:]
「这样的宙君是我最大的骄傲。[rhr]
_　能爱上这么优秀的人，我真是世界上最幸福的家伙呢」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:sora:][sora kao=3 hh=on as=on ]
「………………」[rhp]

[:princess:][puri_w kao=13 hh=on ]
「……才怪啦！说实在的也有后悔过。想着要是活着的时候能传达给你就好了。[rhr]
_　写信也好其他方式也好，明明有无数种方法的」[rhp]
[:princess:]
「所以现在能说出来真好。终于把心意全部传递出去了。[rhr]
_　已经没有任何遗憾了」[rhp]
[:princess:]
「这样我就能以纯净的姿态重新开始了」[rhp]

[off_all]

[::]
宙君没有应答。[rhr]
只是沉默地咬着嘴唇凝视地面。[rhp]
我向前迈出一步，轻轻包裹住他因紧握而颤抖的拳头。[rhr]
他猛然抬头。泛着泪光的眼睛望了过来。[rhp]

[chara_part name="sora" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=13 as=off ss=off hh=on hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「敬请期待吧。我一定会、一定会变成很棒的女孩子」[rhp]
[:princess:]
「到时候就换我去找你」[rhp]

[fbgm]

[:princess:]
「…………所以回去吧，宙君」[rhp]

[:sora:]
「………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[bgm storage="bgm_13.ogg"]

[:sora:][sora kao=6 as=on ]
「…………、真是自私……」[rhp]

[off_all]

[chara_part name="drop" body=base kao=3 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=0 as=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:drop:]
「……宙先生……」[rhp]

[off_all]

[chara_part name="sora" body=base kao=2 as=off ss=off hh=on hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=1 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:sora:]
「……你太狡猾了。[rhr]
_　让人怀着这么麻烦的梦想……」[rhp]
[:sora:]
「………………别随便就死了啊」[rhp]

[:princess:][puri_w kao=14 hh=on ]
「对病人这么乱来。啊哈哈」[rhp]

[:sora:][sora kao=2 ]
「这可不是好笑的事！」[rhp]

[:princess:][puri_w kao=4 as=on ]
「对、对不起」[rhp]

[:sora:][sora kao=6 ]
「………………真的，一点都没变呢。你……」[rhp]
[:sora:]
「……看样子说什么都白费了」[rhp]

[:princess:][puri_w kao=5 hh=on ]
「不愧是宙君。不是挺明白的嘛」[rhp]
[:princess:]
「明明一开始那样无视我，却还记得一直主动搭话的我吗？[rhr]
_　我就是一直保持那种态度的」[rhp]
[:princess:]
「我不会退让心意。[rhr]
_　我现在绝对要带宙君回去」[rhp]

[:sora:][sora kao=1 ]
「…………这样啊」[rhp]

[off_all]

[::]
这么说着的宙君的脸，虽然还是一副快要哭出来的样子，[rhr]
但多少能看到些安心的神色。[rhp]
虽然还不至于全都……但像是接受了。[rhr]
就像曾经和我在病房交谈时那样，是平静的。[rhp]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

[:drop:][p_d_31][drop kao=11 hat=on ]
「………………」[rhp]

[:sora:][p_so_29][sora kao=5 hh=on ]
「……嘛，和听说的一样」[rhp]
[:sora:]
「我要和这家伙回那边去了。[rhr]
_　真货和假货之间，就放弃[player2]和睦相处的念头吧」[rhp]

[:drop:][drop kao=1 hh=on hat=on ]
「放弃什么的简直荒唐。[rhr]
_　虽然我没有胜负的意思，但硬要说的话是你赢了」[rhp]
[:drop:]
「只要生活在同一个世界，总有一天一定会再见面的」[rhp]

[:sora:][sora kao=7 ]
「谁知道呢……」[rhp]

[off_all]

[chara_part name="sora" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=1 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:][puri_w kao=5 hh=on ]
「才不是谁知道！我绝对会去见你的所以给我等着！」[rhp]

[:sora:][p_so_31][sora kao=12 hh=on ]
「是哦……」[rhp]
[:sora:]
「………………那我就稍微期待一下吧」[rhp]

[:princess:][puri_w kao=13 ]
「嗯！」[rhp]

[off_all]

[chara_part name="sora" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=4 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sausu:][p_s_04]
「这样真的好吗。宙……」[rhp]

[:sora:][sora kao=5 ]
「啊。已经无所谓了……虽然不是说完全不在乎，但很多事都想开了」[rhp]
[:sora:]
「而且……我还得在那边等你们来接我呢」[rhp]

[:princess:][puri_w kao=5 hh=on ]
「呵呵呵。我会骑着白马来接你的哦」[rhp]

[:sora:][p_so_22][sora kao=8 ]
「明明不会骑马还敢说大话」[rhp]

[off_all]

[:drop:][p_d_21][drop kao=4 as=on hat=on ]
「通常情况不是应该反过来吗？」[rhp]

[:princess:][puri_w kao=13 ]
「没关系啦。因为宙君就是女生话题里所谓的『少女』嘛」[rhp]

[:sora:][sora kao=2 ]
「喂！那种黑历史不用桩桩件件都想起来啊！」[rhp]

[:princess:][puri_w kao=5 hh=on ]
「还有好多呢！　[rhr]
_　其实宙君啊，虽然长着这么帅气的脸却对间接接吻特别抗拒……」[rhp]

[:sora:][p_so_09][sora kao=2 hh=on as=on ]
「住手！！！！」[rhp]

[off_all]

[:sausu:][p_s_18][sausu kao=0 ]
「………………看来我说什么都是白费功夫呢……」[rhp]

[:princess:][puri_w kao=1 ]
「我能感受到南是在为我们着想。但是我……」[rhp]

[:sausu:][sausu kao=11 ]
「没关系。约定就是约定」[rhp]
[:sausu:]
「而且……说来奇怪呢。明明要舍弃这么美好的世界，[rhr]
_　现在的你却看起来比任何时候都要幸福」[rhp]
[:sausu:]
「……不会后悔吧？真的」[rhp]

[:princess:][puri_w kao=14 ]
「嗯」[rhp]

[:sausu:][sausu kao=1 ]
「是啊。……我永远只期盼幸福」[rhp]
[:sausu:]
「现在只要有那个笑容就足够了」[rhp]

[off_all]

[::]
南带着寂寞的笑容平静地如此宣告。[rhr]
这么一想南似乎总是在谈论关于幸福的话题。[rhp]
――――――那么，南自身的幸福又是什么呢？[rhp]
像是告一段落般，南说着『好了』并拍了拍手，[rhr]
我对这个问题的思考也到此为止。[rhp]

[chara_part name="sora" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sausu:][p_s_20]
「公主会用我的魔法离开这个世界，那你呢？[rhr]
_　要我送你一程吗？」[rhp]

[:sora:][p_s_19][sora kao=5 ]
「不必。我有专属出租车」[rhp]

[:sausu:][sausu kao=4 as=on ]
「出租车？到底在说什……」[rhp]

[off_all]

[:yoru:][p_y_09][yoru kao=2 ]
「谁说我是出租车」[rhp]

[::]
夜仿佛等候多时般，从空无一物之处突然现身。[rhr]
从他那略带忧郁的表情来看，似乎早就在暗中观察我们的对话。[rhp]

[off_all]

[chara_part name="sausu" body=base kao=8 as=on ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sausu:][p_s_30]
「明明没被指名道姓，却一副理所当然的样子……」[rhp]

[:yoru:][p_y_12][yoru kao=6 ]
「闭嘴。晚点再好好跟你算账」[rhp]

[:sausu:][sausu kao=7 as=on ]
「呜……」[rhp]

[off_all]

[::]
南毫不掩饰地露出嫌恶表情。说起来这可能是第一次[rhr]
亲眼见到他和夜直接交谈。[rhp]
……看起来关系比想象中更差。[rhr]
南刻意避开正面冲突，将在此处的停留时间压缩到最低也是情理之中。[rhp]

[chara_part name="sora" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:yoru:]
「……宙。气消了吗」[rhp]

[:sora:][p_so_01][sora kao=1 ]
「嗯」[rhp]
[:sora:]
「…………、碾压式胜利」[rhp]

[:yoru:][yoru kao=0 ]
「再好不过。我本就没精力继续纵容你的任性」[rhp]

[:sora:][sora kao=8 ]
「什么意思？」[rhp]

[:yoru:][p_y_18][yoru kao=12 ]
「为了满足你的种种任性要求，积攒的力量即将耗尽」[rhp]
[:yoru:]
「无论是武还是宙，都让我受够了给你们收拾烂摊子。[rhr]
_　下次必须存比现在更多的钱才行」[rhp]
[:yoru:]
「今后就由我一个人，来想办法把你们从这个世界解决掉」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sausu:][p_s_07][sausu kao=13 ]
「真温柔啊。意思是暂时放我一马？」[rhp]

[:yoru:][p_y_29][yoru kao=0 ]
「监视不会停止。毕竟还有最优先要解决的案子」[rhp]

[:sausu:][p_s_24][sausu kao=8 ]
「………………是啊」[rhp]

[:princess:][puri_w kao=1 ]
「……？那个我可能想不起来」[rhp]

[:sausu:][sausu kao=7 as=on ]
「没、没什么。公主别在意」[rhp]

[:yoru:][p_y_20][yoru kao=0 ]
「就算告诉你，你也什么都……」[rhp]
[:yoru:]
「…………不，或许不该断言」[rhp]

[:princess:][puri_w kao=0 as=on ]
「…………？」[rhp]

[off_all]

[:drop:][p_d_16][drop kao=13 hat=on ]
「若要就此离去，不如先唤大家来——[rhr]
_　作最后告别——」[rhp]

[:sora:][sora kao=0 ]
「不必」[rhp]

[:drop:][drop kao=3 as=on hat=on ]
「哎，可是」[rhp]

[off_all]

[:sora:][p_so_25][sora kao=12 ]
「我也觉得不必。讨厌黏糊的场面」[rhp]
[:sora:]
「况且……会舍不得啊」[rhp]

[:princess:][puri_w kao=3 ]
「确实。在这里的生活，那段时光真的非常快乐」[rhp]
[:princess:]
「不想因为自己的离别而哭泣、也不想看别人为我哭泣。[rhr]
_　所以，这样就好」[rhp]

[off_all]

[:drop:][drop kao=13 hat=on ]
「这样啊……不过我或许能理解这种心情」[rhp]
[:drop:]
「我会转告大家的。关于公主的事，还有宙先生的事」[rhp]

[:princess:][puri_w kao=1 ]
「嗯。一直以来谢谢你们。多洛普、和君、大家……[rhr]
_　正因为遇见了这里的人们，我的人生才变得如此精彩」[rhp]
[:princess:]
「就算分开了，我们依然是好朋友啊」[rhp]

[:drop:][p_d_02][drop kao=1 hat=on ]
「好。我一定会传达的」[rhp]

[:princess:][puri_w kao=1 hh=on ]
「拜托你啦。虽然有点不好意思」[rhp]

[off_all]

;****************************************
;スチル・真面目・シリアス
[still storage="cg/d_d3_1.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/d_d3_1.png"]
;****************************************

;--------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;--------------------------------------------------------------------------------------------

[:princess:]
「……那么……，我该走了」[rhp]

[:drop:]
「嗯……保重。宙先生也是」[rhp]

[:sora:]
「我算附带品吗？虽然确实就是你自己」[rhp]

[:drop:]
「呵呵……！正因为如此。[rhr]
_　我在模仿你那种带点坏心眼的感觉哦」[rhp]

[:sora:]
「一点都不像」[rhp]

[:drop:]
「随你便」[rhp]

[:sora:]
「――――――！　什」[rhp]

[:princess:]
「明明超像的！」[rhp]

[:sora:]
「这不是当然的吗……！我就是你啊」[rhp]

[:drop:]
「我会努力的。替你……不对。[rhr]
_　要替你们所有人，把这场旅程变成最棒的回忆」[rhp]
[:drop:]
「愿你们的人生，也能成为幸福的旅途」[rhp]

[:sora:]
「…………嗯」[rhp]

[:princess:]
「谢谢你。多洛普」[rhp]

[:drop:]
「那么各位。请多保重」[rhp]
[:drop:]
「――――――――一路顺风」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
[fbgm]

#
[s_mask color=0xffffff time=3000]
; 背景表示
[bg storage="sky_04.jpg" time=100]
[free_filter ]
; ウィンドゥの設定
[position layer="message0" frame="win2.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[s_mask_off time=3000]

[bgm storage="bgm_07.ogg"]
;****************************************

17年后。[rhp]

;****************************************
[bg storage="hspt_01.jpg" time=1500]
;****************************************

[:nurse:]
「落合先生。这是您要的资料」[rhp]

[:sora:][sora2 kao=0 ]
「啊。多谢」[rhp]

[off_all]

[::]
6年前，结束实习医生阶段的我，[rhr]
作为主楼儿科医生工作着。[rhp]
那座临终关怀院与主楼儿科病房合并后，我被分配至此，[rhr]
逐渐坐上了当年矢部老师那样的位置。[rhp]
他本人三年前挖走大美贺小姐跳槽后，[rhr]
如今在稍远的地方经营着私人医院。[rhp]
本以为是夫妻店模式，[rhr]
可前些天约酒时，他竟异常激烈地否认了这点。[rhp]
那两人的关系至今仍让人捉摸不透。[rhr]
但确实存在着深厚的羁绊。[rhp]
至于我呢……[rhp]

[:sora:][sora2 kao=2 as=on ]
「…………真麻烦啊」[rhp]

[:nurse:]
「什么很麻烦呢？」[rhp]

[:sora:][sora2 kao=8 ]
「啊，没什么」[rhp]

[:nurse:]
「明明是被嘱咐才送资料过来的。[rhr]
_　请好好过目啊」[rhp]
[:nurse:]
「今天的学生志愿者活动，应该由您负责安排吧」[rhp]

[:sora:][sora2 kao=0 ]
「…………好的」[rhp]

[off_all]

[::]
与大美贺小姐截然相反，那个过分认真的女孩是我的部下。[rhr]
她既不开玩笑也听不懂玩笑，是个对工作过分热忱的女性，好坏参半。[rhp]
我并非讨厌这点，反倒觉得这才是护士应有的模样。[rhr]
但因为心里总浮现那个人的形象，总觉得哪里微妙地不协调。[rhp]
还有就是有些长舌妇气质……特别爱唠叨。[rhr]
其实偶尔抱怨几句也没什么吧……[rhp]

[:sora:][sora2 kao=7 ]
「……学生志愿者啊」[rhp]

[:nurse:]
「据说是护理学校升学志愿团里的高中生」[rhp]

[:sora:][sora2 kao=6 ]
「这样啊……」[rhp]

[off_all]

[::]
完全无所谓呢……[rhr]
有这闲工夫的话，我更想慢慢捣鼓公告栏的装饰。[rhp]

[:sora:]
[font color=0x4682b4]
（光靠零碎时间根本做不成那家临终关怀院的样子。[rhr]
_　……矢部老师和大美贺小姐当时居然这么闲吗？）[rhp]
[:sora:]
（啊不过，[player2]或许让她们帮忙做了……）[rhp]
[resetfont]

[::]
………………。[rhp]
高中生吗。如果那个孩子[player2]在『那之后』获得了重生的话，[rhr]
现在应该差不多是这个年纪吧……[rhp]

[:sora:]
[font color=0x4682b4]
（………………不不）[rhp]
[resetfont]

[::]
怎么可能。绝无可能。[rhr]
世界怎么会如此称心如意，连我都不抱这种妄想。[rhp]
害得我至今单身。[rhr]
虽然本来就没结婚意愿就是了……[rhp]
时而，那个约定会在脑海中闪现。[rhp]

[:sora:]
「…………明明说过会来接我的」[rhp]

;****************************************
[set_b storage="hspt_02.jpg"]
;****************************************

那之后过了半天。[rhp]
在黄昏的走廊上，志愿者学生们带著充满成就感的笑容，[rhr]
大致依照负责人顺序在我面前排成了3～4列。[rhp]
疑似代表的学生深深低下头，其他人也跟著开始鞠躬。[rhr]
……其他人究竟是怀著什么心情面对这场面的？[rhp]
若有范本还请让我看看。[rhr]
我实在很不擅长这种正式场合。[rhp]

[:student:]
「落合老师，今天非常感谢您！」[rhp]

[::]
学生代表用极具学生特色的洪亮声音说道。[rhr]
虽然内心感到烦躁，但并排站著的护士们却笑容满面显得很满足。[rhp]

[:student:]
「今天的经验将会运用到往后的实践中！[rhr]
_　若有机会还请务必让我们再次拜访！」[rhp]

[::]
啊你看，不是有几个无关的路人朝这边回头了吗。[rhr]
我难堪地不断用「啊——」「嗯」之类的话敷衍应答。[rhp]

在稿纸般的送别会结束前，[rhr]
我决定发呆望著学生们身后的那扇窗外。[rhp]
外面的银杏被风吹落。[rhr]
秋日已近暮色，再过一个多月便到飘雪的时节了。[rhp]
我向来讨厌冬天。[player2]以...之死为开端，净是些糟糕的回忆。[rhr]
若说喜欢之物，唯有八云君曾教我的冬季星座……[rhp]

[:sora:]
[font color=0x4682b4]
（……年岁至此，浮现心头的竟全是儿时往事）[rhp]
[resetfont]

[::]
目睹眼前这些闪耀着未来光芒的学生令人难以忍受，[rhr]
或许正是因我这年纪时尽尝苦楚之故吧。[rhp]
坦白说就是嫉妒。[rhr]
明明是个大叔还这般作态，连自己也觉得荒唐可笑。[rhp]
哈啊，能不能快点结束啊……[rhp]

;****************************************
[set_b storage="hspt_01.jpg"]
;****************************************

[::]
将顺利完成志愿服务的高中生们送走后，[rhr]
我回到诊室瘫坐在办公椅上，重重叹了口气。[rhp]
我本就不擅长应付孩子，与儿科那些孩童不同的是[rhr]
初中生、高中生这类年纪的孩子，根本猜不透他们在想什么更费心神。[rhp]
模糊地回忆着今日来访的少年们，我轻轻摇了摇头。[rhr]
明知不可能存在，却仍忍不住寻找。[rhp]
说不定会有[player2]长得酷似...的孩子。[rhr]
说不定那孩子……[rhp]

[:sora:]
[font color=0x4682b4]
（…………连自己都觉得这样真够呛）[rhp]
[resetfont]

[::]
即便重生第一世也无法保证容貌相同，[rhr]
根本不可能找到的吧。[rhp]
说到底就算真有那种奇迹般的重逢，[rhr]
对方也未必保有对我的记忆。[rhp]

[:sora:][sora2 kao=8 as=on ]
「哈啊⋯⋯」[rhp]

[off_all]

[:nurse:]
「您累了吗，老师」[rhp]

[:sora:][sora2 kao=12 ]
「嗯—算是吧。陪小孩很累人呢」[rhp]

[:nurse:]
「嗯……落合先生，您为什么当了儿科医生呢？」[rhp]

[:sora:][sora2 kao=7 ]
「…………谁知道呢。忘记了」[rhp]

[off_all]

[::]
其实记得，只是假装不知。[rhr]
但我还没能坦然谈笑到可以轻松道出那段过往的地步。[rhp]
……时至今日，偶尔仍会为离开那条铁道而感到后悔。[rhp]

[:sora:][sora2 kao=0 ]
「那个……今天应该会早点回去。[rhr]
_　我计划19点出发，也请大家多加小心」[rhp]

[off_all]

[:nurse:]
「明白了。请您慢慢来」[rhp]

[::]
虽然是个缺乏趣味的护士，但我喜欢她不爱多管闲事的性格。[rhr]
倒不如说从我的性格来看，可能比起米卡小姐那样的人更合得来。[rhp]
…………。[rhp]
………………骗人的。刚才不过是逞强罢了。[rhp]
其实我很清楚。无论我是谁想必都，[rhr]
或许只是为了一点微不足道的小事就在抱怨吧。[rhp]
我的理想，自十几年前起就已再不可能实现了。[rhp]

;****************************************
[set_n storage="hspt_03.jpg"]
;****************************************

[::]
不再使用巴士，是在父母为庆祝我就职买车之后的事。[rhp]
嘴上说是为薰存下的学费浪费了太可惜，[rhr]
其实我知道那些钱都被捐给了儿童福利机构。[rhp]
哪怕是为我这种态度恶劣的混蛋小鬼，[rhr]
他们也认真存下了学费等各种开销。[rhp]
对父亲和母亲，我真的抬不起头来。[rhr]
就算我当了父母，也做不到像他们那样出色吧。[rhp]

[:sora:]
[font color=0x4682b4]
（不过嘛，看来也不会有那种机会就是了……）[rhp]
[resetfont]

[::]
但迈向停车场的脚步却异常沉重。[rhr]
不仅那位护士，就连其他工作人员也十分担忧。[rhp]
许久未有的期待落空的伤害，似乎比想象的还要大。[rhr]
我自然而然地停下脚步，仰望星空，茫然回顾过往。[rhp]

;****************************************
[bg storage="sky_07.jpg" time=1000]
;****************************************

―――这就是我重复了17年的人生。[rhp]
在希望中陷入低谷，在低谷中重燃希望。[rhr]
好不容易实现了当医生的梦想，却……。[rhp]

[:sora:]
[font color=0x4682b4]
（…………我、到底在做什么啊）[rhp]
[resetfont]

[::]
每当仰望星空，就不可避免地想起那个世界。[rhp]
[player2]在劝说下，最终还是放开了本应已掌握的世界。[rhp]
如今在那画中世界里，他们的旅程是否仍在继续呢。[rhp]

[:sora:]
「…………」[rhp]

[::]
…………并非全是后悔。[rhp]
并非讨厌照顾的孩子们。[rhp]

只是，一切都空虚得令人窒息。[rhr]
连产生疑问都痛苦万分。[rhp]
……我的选择，真的正确吗。[rhp]
如果当初[player2]能说服她一起留下，[rhr]
肯定就不会陷入这种日复一日的单调循环了吧。[rhp]
……那个世界是虹色的，充满憧憬与理想的宝石箱。[rhp]
这个世界，只有灰暗。[rhp]

[:sora:]
「呃……已经搞不懂了……真是……」[rhp]

;****************************************
[fbgm]
#
[bg storage="hspt_03.jpg" time=0]
;****************************************

[::]
――――――就在这时。[rhp]

[bgm storage="bgm_40.ogg"]

[se storage="hand_01.ogg"]
[yurasu]

[:sora:]
[font size=30]
「――――――呃啊啊啊！！！？？」[rhp]
[resetfont]

[::]
突然间围巾被施加了恐怖的重力。[rhp]
事发突然，完全无法理解状况。[rhr]
只感觉脖颈越勒越紧，越是挣扎肺部空气流失得越快。[rhp]

[:sora:][sora2 kao=2 as=on ]
[font size=27]
「唔―――啊啊啊！！」[rhp]
[resetfont]

[off_all]

[se storage="hand_01.ogg"]
[yurasu]

[::]
惊慌中猛力挣脱，反作用力使袭击者重重摔倒在地。[rhp]
这倒是省事了。[rhr]
立刻转身想看清这个无礼混蛋的尊容。[rhp]

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
[vostart]
;--------------------------------------------------------------------------------------------

[:sora:][sora2 kao=6 ]
「喂！！突然搞什么――――――」[rhp]

[off_all]

;****************************************
[still storage="cg/d_d3_2.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/d_d3_2.png"]
;****************************************

[::]
站在那里的是个快要哭出来的女孩。[rhr]
穿着和今天来当志愿者的女高中生同样的制服。[rhp]
她，并不在刚才那群人之中。[rhp]
…………、明明就不在啊。[rhp]

[:sora:]
「………………」[rhp]

#
震惊到失语。[rhp]
虽然样貌完全不同，却能明白。[rhp]
这个连名字都不知道的少女，究竟是谁这件事。[rhp]

[:girl:]
「那个，大叔」[rhp]

[:sora:]
「……！」[rhp]

[:girl:]
「突然抱歉。因为刚才打招呼被无视了」[rhp]

[:sora:]
「咦？啊……」[rhp]

[off_all]

[::]
没注意到。原来是在向我搭话吗。[rhr]
即便如此现在这行为也够离谱的……[rhp]

;****************************************
;スチル終了
[still_end frame="win2.png" storage="hspt_03.jpg" time=1000]
;****************************************

[chara_part name="hime" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hime" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sora2" body=base kao=8 as=off ss=off hh=off ]
[chara_show name="sora2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:girl:]
「那个。志愿活动，偷懒真对不起」[rhp]

[:sora:][sora2 kao=2 ]
「啊……？」[rhp]

[:girl:]
「果然参加人数之类的会被核对吗？[rhr]
_　向学校告密什么的还请高抬贵手……本来就被重点盯着了」[rhp]
[:girl:]
「但我真的超想去游戏中心！！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:sora:][sora2 kao=6 as=on ]
「………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:girl:][hime kao=3 as=on ]
「可要是被后来参加的人举报就糟了。[rhr]
_　躲着想最后露个脸就溜，结果不知不觉睡着了」[rhp]

[:sora:][sora2 kao=0 ]
「……所以一直在这儿？」[rhp]

[:girl:][hime kao=6 as=on ]
「嗯……正不知怎么办时，看到志愿活动海报上[rhr]
_　有过一面之缘的大叔在停车场晃悠」[rhp]
[:girl:]
「想总之先道歉，就下意识勒脖子了可以说」[rhp]

[:sora:][sora2 kao=2 as=on ]
「不觉得离谱吗……？你可是立志当护士的志愿者」[rhp]

[:girl:][hime kao=2 ]
「因为实在不知道该怎么搭话……[rhr]
_　因为我从没谈过男朋友，所以不太懂距离感这种东西」[rhp]
[:girl:][hime kao=6 ]
「啊！！　才不是对大叔一见钟情什么的呢？[rhr]
_　可别误会了。我可是女高中生哦！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:sora:][sora2 kao=6 as=on ]
[font color=0x4682b4]
（明明我什么都没说）[rhp]
[resetfont]

[:girl:][hime kao=3 as=on ]
「不，抱歉……我知道自己说得有点奇怪。[rhr]
_　但是，这种……冲动？　或者该说本能？　虽然我也说不清楚」[rhp]
[:girl:]
「就是觉得必须追逐着你才行」[rhp]

[:sora:][sora2 kao=0 as=on ]
「…………！」[rhp]

[:girl:][hime kao=7 ]
「说实话当护士根本没意思啦。[rhr]
_　因为我志向是当医生而不是护士嘛」[rhp]
[:girl:]
「但哥哥姐姐总唠叨说对将来有帮助非要我来。[rhr]
_　马上就要正式备考了，明明现在只想好好玩呢」[rhp]
[:girl:]
「大叔是医生吧？　年轻时怎么过的？」[rhp]

[off_all]

――――――我真的可以认为『就是那样』吗。[rhp]
这就是我长年等待的，全部的结果。[rhp]
这个少女竟是……[rhp]

[:girl:][hime kao=8 as=on ]
「…………？　大叔？」[rhp]

[off_all]

[::]
…………算了吧。[rhp]
如果我的存在会与这孩子的人生产生交集，[rhr]
那也只能是在她主动寻求的时候。[rhp]
这孩子[player2]或许曾是[rhr]
但绝非[player2]因此。[rhp]
此刻我能对她说的，唯有一句话。[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sora:][sora2 kao=12 ]
「……宙」[rhp]

[:girl:][hime kao=2 ]
「空？……啊、什么？」[rhp]

[:sora:][sora2 kao=1 ]
「不是叔叔。是落合宙」[rhp]

[:girl:][hime kao=13 hh=on ]
「啊、名字啊。……嗯—、落合宙……[rhr]
_　………总感觉有点像宇航员」[rhp]

[:sora:][sora2 kao=1 ]
「只是『宙』这个字而已吧」[rhp]

[:girl:][hime kao=5 hh=on ]
「感觉会转生到异世界呢」[rhp]

[:sora:][sora2 kao=7 as=on ]
「现在的你最没资格说这种话……」[rhp]

[:girl:][hime kao=4 as=on ]
「什么意思？」[rhp]

[:sora:][sora2 kao=5 ]
「…………没什么！」[rhp]

[off_all]

[::]
我不奢望能回想起前世之类的奇迹。[rhp]
按自己喜欢的方式活着就好。[rhr]
我不会否定这点。[rhp]
……即便如此还是禁不住想。[rhp]

;****************************************
[bg storage="sky_07.jpg" time=1000]
;****************************************

若说就算外貌改变，仍有不变之物存在的话。[rhp]
那一定就是灵魂了吧。[rhp]
倘若转世重生后仍有铭刻于彼处的记忆。[rhp]
若那记忆中的就是我的话，再没有比这更幸福的事了。[rhp]

[:sora:]
「…………能遇见你真是太好了」[rhp]

[::]
这个宇宙中最深爱的人。[rhp]
能看到你幸福的模样，比什么都重要。[rhp]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

[free_filter ]
[jump storage="ev_d.ks" target="*ending2"]

