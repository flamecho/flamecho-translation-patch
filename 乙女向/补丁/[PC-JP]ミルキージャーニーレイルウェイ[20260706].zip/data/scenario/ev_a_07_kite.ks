﻿
*start

;--------------------------------------------------------------------------------------------
;▼フルボイスセット▼
;カイト
[voconfig sebuf=1 name=kite vostorage="kite/full/{number}.ogg" number=147]
;ヌシ
[voconfig sebuf=1 name=nusi vostorage="nusi/full/{number}.ogg" number=78]
;魔太郎子
[voconfig sebuf=1 name=mata vostorage="mata/full/{number}.ogg" number=80]
;ゴンザレス一億世
[voconfig sebuf=1 name=gon vostorage="gon/full/{number}.ogg" number=62]

;--------------------------------------------------------------------------------------------

[:princess:][puri_w kao=12 ]
「…………。快斗……是吗」[rhp]

[off_puri]

[::]
要说在意什么……最近确实一直在意快斗的事。[rhp]
自从听说他曾是我最好的朋友后，[rhr]
不知为何就特别在意起他来。[rhp]
如果能回想起和他共度的记忆就好了，[rhr]
这样他或许也会对我敞开心扉吧。[rhp]
为此，这次祭典正是绝佳机会。[rhp]

[:princess:]
[font color=0x4682b4]
（哪怕只是一点点也好，希望能成为找回与他回忆的线索）[rhp]
[resetfont]

[::]
于是我立刻决定前往快斗所在的车厢。[rhp]

;****************************************
[set_xx graphic="rule/krke_k.png" storage="train_02.jpg"]
;****************************************

[:princess:][puri_w kao=1 ]
「…………就是这样的」[rhp]

[kite kao=0 ]
「如果快斗愿意的话，想和你一起逛祭典呢」[rhp]

[:kite:][kite kao=12 ]
「………………」[rhp]

[:princess:][puri_w kao=2 as=on ]
[font color=0x4682b4]
（啊，看来没希望了……也没办法。[rhr]
_　他看起来就不喜欢那种热闹地方吧……）[rhp]
[resetfont]

[:kite:][p_k_35][kite kao=7 ]
「好啊」[rhp]

[:princess:][puri_w kao=11 as=on ]
「这样啊明白了。那我就和佩奇他们随便……」[rhp]
[:princess:][puri_w kao=4 as=on ]
「………………诶？」[rhp]

[:kite:][kite kao=6 ]
「所以说可以」[rhp]

[:princess:][puri_w kao=2 as=on ]
「为什么！？」[rhp]

[:kite:][p_k_19][kite kao=2 as=on ]
「不是你邀请的吗……」[rhp]
[:kite:][kite kao=12]
「……那我去为晚上做准备[rhr]
_　趁现在睡会儿。到地方再会」[rhp]

[off_all]

[::]
说完这句话，快斗头也不回地离开了车厢。[rhp]
被独自留下的我反复咀嚼着快斗的话语，[rhr]
对这突如其来的事实震惊得说不出话来。[rhp]

[:princess:][puri_w kao=2 as=on ]
「啊、那个快斗居然答应了……」[rhp]
[:princess:][puri_w kao=14 ]
「…………！！　太好！　太好了太好了太好了！[rhr]
_　比预想的还要顺利大成功不是吗！」[rhp]

[off_puri]

[::]
逐渐体会着惊讶转为喜悦的过程。[rhp]
既然定下来了我也得准备才行！[rhr]
返回房间的脚步比来时轻快了许多。[rhp]
第一次的祭典……！[rhr]
为了不辜负难得提起兴趣的快斗的期待，要加油啊！[rhp]

;****************************************
[fbgm]
[set_xx graphic="rule/krke_k.png" storage="sky_07.jpg"]
;*****************************************

[::]
银河铁道在数小时后抵达了目标星球。[rhp]
我们换上了夸德里利昂为我们准备的浴衣，[rhr]
终于踏上了那片土地。[rhp]

;****************************************
[bg storage="fes_01.jpg" time=1000]
[filter_n]
[bgm storage="bgm_26.ogg"]
;****************************************

列车停靠在一处稍高的位置，[rhr]
面对着通往宽阔神社的漫长石阶。[rhp]

「夏日祭之星」永远沉浸在傍晚时分的氛围中，[rhr]
慵懒的闷热感令人联想到初夏。[rhp]
鲜红的灯笼将微暗的夜色明亮地映照，[rhr]
台阶上方传来太鼓和笛子的乐声，空气中飘荡着独特的甜香。[rhp]

尚未目睹的景象让心跳加速，[rhr]
迫不及待想快点跑上这段台阶。[rhp]

[chara_part name="jet" body=yukata kao=5 as=off ss=off hh=on hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=yukata kao=5 as=off ss=off hh=on hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:][p_h_14]
「这、这就是……！夏日祭典！太厉害了！」[rhp]

[:jet:][p_j_14]
「明明只看见灯笼和台阶就已经兴奋起来了！」[rhp]

[off_all]

[chara_part name="riri" body=yukata kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="kite" body=yukata kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:quadrillion:][p_r_14]
「哎呀哎呀，所以小鬼头就是这样的嘛。[rhr]
_　外面稍微热闹点就高兴成这样」[rhp]

[:kite:][p_k_14]
「说这话的克林不是也新买了相机？干劲十足啊」[rhp]

[:quadrillion:][p_r_27][[riri body=yukata kao=14 ]
「讨厌～～～被发现啦！？没错！这是专门针对夜间拍摄的，」[rhp]

[:kite:][kite body=yukata kao=6 ]
「啊，没关系的」[rhp]

[off_all]

[:drop:][p_d_04][drop kao=1 ]
「那么各位，烟花大会预定在18点半左右开始，[rhr]
_　请大家在那之前稍微提早些到广场集合哦」[rhp]

[:vulpecula:][peku body=yukata kao=13 ]
「好呀！看烟花的时候要一起喊『玉屋～～』才开心呢！」[rhp]

[:drop:][drop kao=13 ]
「嗯。这段时间各位可以自由活动，请好好享受。[rhr]
_　我会留在车里进行检修」[rhp]

[off_all]

[:princess:][puri_w body=yukata kao=6 as=on ]
「诶……！多洛普你不去玩吗？[rhr]
_　检修什么的很无聊吧」[rhp]

[:drop:][p_d_02][drop kao=13 ]
「这些事总得有人来做。[rhr]
_　而且对我来说车内检修也是非常快乐的事，请放心」[rhp]
[:drop:]
「虽算不上补偿，但很期待你们的旅行见闻！[rhr]
_　每次听大家讲述经历，我都非常开心」[rhp]

[:princess:][puri_w body=yukata kao=6 as=on ]
「但是……」[rhp]

[:quadrillion:][p_r_34][riri body=yukata kao=6 ]
「那家伙一直都是那样啦。别管他」[rhp]
[:quadrillion:]
「我们向来主张随心所欲。[rhr]
_　玩不玩都是个人自由。我们可不会指手画脚」[rhp]

[:drop:]
「就是这个道理」[rhp]

[:princess:][puri_w body=yukata kao=3 as=on ]
「……明、明白了……」[rhp]

[off_all]

[::]
以多洛普的话语为开端，众人各自散开行动。[rhp]

[chara_part name="otiai" body=yukata kao=4 as=on ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=yukata kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:][p_h_06]
「听说夏日祭典上有个连小孩都能打的射击摊啊！！[rhr]
_　走吧落合！！！」[rhp]

[:otiai:][p_so_10][otiai body=yukata kao=2 as=on ]
「啊？　诶、等……！[rhr]
_　别、别擅自决定！　话说那是套圈游戏吧，」[rhp]

[:heartshape:][hati body=yukata kao=14 ]
「三个人来锦标赛吧！[rhr]
_　输的人要打扫一星期厕所！」[rhp]

[off_all]

[:jet:][p_j_16][jet body=yukata kao=5 ]
「那可真不能输啊……[rhr]
_　落合要是弃权的话，不战而胜我也无所谓？」[rhp]

[:otiai:][otiai body=yukata kao=2 as=on ]
「～～～～我奉陪。比就比啊！」[rhp]

[off_all]

[:princess:][puri_w body=yukata kao=13 ]
[font color=0x4682b4]
（嘿嘿，看来落合君也能玩得开心真是太好了）[rhp]
[resetfont]

[off_puri]

[:heartshape:][hati body=yukata kao=14 ]
「好嘞，干劲十足！　走着伙计们！[rhr]
_　可别跟丢我了……」[rhp]
[:heartshape:][hati body=yukata kao=2 as=on ][p_h_10]
「咦等等！？　杰特人呢！？」[rhp]

[off_all]

[chara_part name="jet" body=yukata kao=5 as=o as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="otiai" body=yukata kao=6 as=o as=on ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:jet:][p_j_02]
「这边哈蒂。那边只有临时厕所」[rhp]

[:otiai:]
「在这种细节上意外真实啊……」[rhp]

[off_all]

[chara_part name="peku" body=yukata kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="riri" body=yukata kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:vulpecula:][p_vl_04]
「呐呐克林～！」[rhp]

[:quadrillion:]
「怎么啦，小不点」[rhp]

[:vulpecula:][peku body=yukata kao=13 ]
「因为不想让身边出罪犯，今天就和佩奇他们一起行动吧！」[rhp]

[:quadrillion:][p_r_19][riri body=yukata kao=5 as=on ]
「犯罪？　难道你说的是巨乳观赏？！[rhr]
_　那可是与自然融为一体享受的正经户外休闲活动，」[rhp]

[off_all]

[:darknebula:][p_da_26][hakase body=yukata kao=3 ]
「如果真心关爱巨乳的话，[rhr]
_　我们是不是该彻底避开关联呢……从巨乳的生态系统中」[rhp]

[off_all]

[:quadrillion:][riri body=yukata kao=8 as=on ss=on ]
「―――！！！！」[rhp]
[riri body=yukata kao=3 as=on ]

[off_all]

[chara_part name="peku" body=yukata kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="40" top="0" wait="false" time="150"]
[chara_part name="riri" body=yukata kao=3 as=off ss=off hh=on hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="hakase" body=yukata kao=1 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720" left="720" top="0" wait="true" time=150]

[:quadrillion:]
「真不愧是博士……！[rhr]
_　刚才的发言，我完全无法反驳呢……」[rhp]

[:vulpecula:][peku body=yukata kao=13 ]
「okk！那就带上克林一起吧！[rhr]
_　我会好好招待你的，就放心交给佩奇吧！」[rhp]

[:quadrillion:][riri body=yukata kao=13 ]
「请多关照哦，姐姐」[rhp]

[:vulpecula:][p_vl_22][peku body=yukata kao=4 as=on hh=on ]
「――――！！！！哦哦哦姐姐姐……」[rhp]
[:vulpecula:][peku body=yukata kao=2 as=on hh=on ]
[font size=28][p_vl_27]
「被发现了！？」[rhp]
[resetfont]

[:quadrillion:][p_r_12][riri body=yukata kao=6 as=on ]
[font color=0x4682b4]
（什么被发现了？）[rhp]
[resetfont]

[off_all]

[:vulpecula:][peku body=yukata kao=6 hh=on ]
「真是的～别管佩奇啦 博士 克林 我们快走吧！[rhr]
_　再不抓紧店铺就逛不完啦！」[rhp]

[off_peku]

[:darknebula:][p_da_09][hakase body=yukata kao=5 ]
「喂喂、乱跑很危险的佩奇」[rhp]
[:darknebula:]
「…………哎」[rhp]

[off_hakase]

[::]
博士将视线转向这边。[rhr]
啪嗒地对上目光后，他轻快地眨了眨眼。[rhp]
虽然没有发出声音，[rhr]
但能从唇形看出他在说『加油！』[rhp]

[:princess:][puri_w body=yukata kao=0 as=on hh=on ]
「…………」[rhp]

[off_puri]

[::]
并非因为受到鼓舞 但下意识瞥了眼身旁的快斗。[rhp]

[chara_part name="kite" body=yukata kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="puri_w" body=yukata kao=1 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" wait=false layer="message0" left="1" top="1" zindex="1005" time=150]

[:kite:][p_k_19]
「怎么了。用看珍禽异兽般的眼神」[rhp]

[:princess:]
「没有啦……就是再次感叹 你居然真的同意了呢」[rhp]

[:kite:][p_k_02]
「比起被克林偷拍 或是陪精力过剩的佩奇折腾[rhr]
_　这样轻松多了」[rhp]
[:kite:][kite body=yukata kao=7 ]
「……浴衣、很合适呢」[rhp]

[:princess:][puri_w body=yukata kao=4 as=on hh=on ]
「是、是吗？谢谢」[rhp]
[:princess:]
[font color=0x4682b4]
（居然能这么自然地说出这种话……有点意外……）[rhp]
[resetfont]

[:kite:][kite body=yukata kao=11 ]
「我怎么样？」[rhp]

[:princess:][puri_w body=yukata kao=13 ]
「快斗也很合适！有种未亡人的感觉？」[rhp]

[:kite:][kite body=yukata kao=6 as=on ]
「这算什么评价啊……嘛，算了」[rhp]
[:kite:]
「那我们也该出发了吧。[rhr]
_　……先玩什么？」[rhp]

[:princess:][puri_w body=yukata kao=1 ]
「嗯——记得民俗学者博士说过。[rhr]
_　祭典是由摊贩、神轿和盂兰盆舞组成的！」[rhp]

[:kite:][p_k_17][kite body=yukata kao=6 ]
「…………………。只要摊贩就好」[rhp]

[:princess:][puri_w body=yukata kao=14 ]
「诶——！难得来都来了[rhr]
_　快斗也试试抬神轿吧？我来拍照」[rhp]

[:kite:][kite body=yukata kao=2 ]
「只要，摊贩，就好吧？」[rhp]

[:princess:][puri_w body=yukata kao=5 as=on ]
「……好的……」[rhp]

[:kite:][p_k_07][kite body=yukata kao=12 ]
「很好」[rhp]

[off_all]

[::]
快斗独自满足地点头，率先迈步走去。[rhp]
我也慌忙追赶他的背影……[rhp]

;****************************************
[set_xx graphic="rule/krke_k.png" storage="fes_03.jpg"]
;****************************************

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
[vostart]
;--------------------------------------------------------------------------------------------

[:gonzalez:][gon body=yukata kao=5 ]
[yurasu]
[font size=28]
「嘿呀，拉—夏—伊！！！！！」[rhp]

[off_all]

[chara_part name="mata" body=yukata kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="gon" body=yukata kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="355" top="0" wait="false" time=150]
[chara_part name="kite" body=yukata kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left=760 top=0 wait="false" time=150]
[chara_part name="puri_w" body=yukata kao=1 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:kite:]
「这群人今天是看店的啊……」[rhp]

[:mataroko:]
「是的。是新章鱼烧店的人呢！」[rhp]

[:princess:]
「大家这身装扮都很合适！」[rhp]

[:gonzalez:]
「对吧？我最喜欢祭典了。[rhr]
_　日本的『粹』！全都浓缩在这里啊！」[rhp]

[:princess:][puri_w body=yukata kao=13 as=on ]
「？？　嗯。虽然不太明白……」[rhp]

[:kite:][kite body=yukata kao=7 ]
「魔太郎子也穿着号衣呢。居然不是连衣裙，真少见」[rhp]

[:mataroko:][mata body=yukata kao=5 ]
「呵呵呵～。这正说明妾身也是认真的呢」[rhp]

[off_all]

[mata body=yukata kao=14 ]
「努西大人、小刚！我们的联合摊位[rhr]
_　绝不允许输给其他店铺哦！打起精神来！」[rhp]

[off_mata]

[:gonzalez:][gon body=yukata kao=14 ]
「噢！！」[rhp]

[off_gon]

[::]
正疑惑什么是联合摊位时仔细瞧了瞧他们的摊位，[rhr]
发现异常宽敞之处竟是两个摊位拼接成的简易店铺。[rhp]

「新式章鱼烧」的「新式」字样其实是后来贴上去的，[rhr]
下面还能隐约看到「棉花糖」的文字。[rhp]
不知为何飘来些许甜腻气味，[rhr]
看来原先经营棉花糖店的应该是小努西那边。[rhp]

[chara_part name="mata" body=yukata kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="nusi" body=yukata kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="606" top="0" wait="false" time=150]
[chara_part name="puri_w" body=yukata kao=0 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「小努西，你不开棉花糖店了吗？」[rhp]

[:nusi:][nusi body=yukata kao=3 ]
「是啊。因为手上总是黏糊糊的[rhp]

[:mataroko:][mata body=yukata kao=6 ]
会粘到偷懒看的自行车赛报纸嘛」[rhp]

[:princess:][puri_w body=yukata kao=5 as=on ]
[font color=0x4682b4]
（充满怨念……）[rhp]
[resetfont]

[off_all]

[chara_part name="gon" body=yukata kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="kite" body=yukata kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:gonzalez:]
「总之！我们和大哥的店铺联名推出了新品。[rhr]
_　不来尝尝吗？」[rhp]

[:kite:]
「不必了」[rhp]

[:gonzalez:][gon body=yukata kao=2 as=on ]
「好快！！」[rhp]

[:kite:]
「棉花糖和章鱼烧的联名什么的...可能有点不敢吃呢……」[rhp]

[:nusi:][nusi body=yukata kao=5 ]
「哈啊，喂快斗。[rhr]
_　什么都没问就擅自下结论可不太好啊」[rhp]
[:nusi:]
「这可是我家小刚的自信之作。……嘛你看着吧！」[rhp]

[off_all]

[:gonzalez:]
「请看，章鱼烧上面顶着棉花糖。然后在这上面……」[rhp]

[se storage="se2_08.ogg"]

[:gonzalez:][gon body=yukata kao=5 ]
「淋上！酱汁！！」[rhp]

[chara_part name="mata" body=yukata kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="nusi" body=yukata kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:mataroko:]
「哎呀！棉花糖渐渐融化了！太美妙了～！」[rhp]

[:nusi:]
「『超级上镜』啊！！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
;カットイン終了
[s_freeimage layer="2" ]
;****************************************

[:gonzalez:][p_gn_02][gon body=yukata kao=13 ]
「所以快斗，这个就送给你了」[rhp]

[:kite:][kite body=yukata kao=2 as=on ]
「哎。我、我……！？」[rhp]

[off_all]

[chara_part name="nusi" body=yukata kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="puri_w" body=yukata kao=2 as=on ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:nusi:][p_ns_09]
「是想让公主试毒吧。是男人就给我吃」[rhp]

[:princess:]
「轻飘飘地说着可怕的话……」[rhp]

[off_all]

[:kite:][p_k_27][kite body=yukata kao=2 as=on ]
「～～～～……知道了。要是吃坏肚子我会告诉多洛普的」[rhp]

[off_all]

[chara_part name="mata" body=yukata kao=5 as=on ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="nusi" body=yukata kao=11 as=on ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="gon" body=yukata kao=7 as=on ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="720" top="0" wait="true" time=150]

[:3nin:]
「……………………」[rhr]
「……………………」[rhr]
「……………………」[rhp]

[off_all]

[:kite:][kite body=yukata kao=2 as=on ]
「喂。别默默无言」[rhp]

[:princess:][puri_w body=yukata kao=13 ]
「快斗！不用顾虑我尽管多吃点哦」[rhp]

[:kite:]
「说得事不关己似的……」[rhp]

[off_puri]

[:kite:]
「…………，算了。那我开动了」[rhp]

[off_kite]

[::]
快斗板着极其苦涩的脸，[rhr]
战战兢兢地将沾着未化棉花糖丝的章鱼烧送入口中。[rhp]
我们三人紧张地注视着他。[rhr]
和往常一样咀嚼许久后缓缓咽下的快斗……[rhp]

[:kite:][p_k_08][kite body=yukata kao=6 as=on ]
「………………意外地好吃」[rhp]

[off_all]

[chara_part name="mata" body=yukata kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="nusi" body=yukata kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="gon" body=yukata kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="720" top="0" wait="true" time=150]

[:3nin:]
「欸！？」[rhr]
「欸！？」[rhr]
「欸！？」[rhp]

[off_all]

[:kite:][p_k_12][kite body=yukata kao=6 ]
「所以说为啥你那边要吃惊啊」[rhp]

[:princess:][puri_w body=yukata kao=5 as=on ]
「哦、好、好吃吗！？难吃……不对、不甜吗？」[rhp]

[:kite:][kite body=yukata kao=7 ]
「嘛……比较接近御手洗团子、这种感觉」[rhp]

[off_all]

[chara_part name="nusi" body=yukata kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="gon" body=yukata kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:gonzalez:][p_gn_08]
「御手洗团子……！原来是这样……！」[rhp]

[:nusi:]
「小刚、你自己没尝过味道吗」[rhp]

[:gonzalez:][gon body=yukata kao=5 ]
「你不懂啊大哥。根本不需要尝什么味道……[rhr]
_　好吃的东西和好吃的东西加在一起、那绝对超级好吃啊！」[rhp]

[:nusi:][p_ns_24][nusi body=yukata kao=11 as=on ]
「是呀～」[rhp]

[off_all]

[:kite:][kite body=yukata kao=0 ]
「………………」[rhp]

[:princess:][puri_w body=yukata kao=0 ]
「？怎么了？我脸上沾东西了吗？」[rhp]

[:kite:][p_k_04][kite body=yukata kao=11 ]
「啊——」[rhp]

[:princess:][puri_w body=yukata kao=4 as=on ]
「诶……」[rhp]

[:kite:][kite body=yukata kao=13 ]
「请用」[rhp]

[:princess:][puri_w body=yukata kao=2 as=on hh=on ]
「哎、哎哎！？」[rhp]

[off_all]

[chara_part name="mata" body=yukata kao=5 as=off ss=off hh=on hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="nusi" body=yukata kao=4 as=off ss=off hh=on hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="gon" body=yukata kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="720" top="0" wait="true" time=150]

[:2nin:]
「噢！」[rhr]
「哎呀！」[rhp]

[:nusi:][p_ns_14]
「可以啊快斗！」[rhp]

[off_all]

小努西「咻——」地撅起嘴。[rhr]
这三个家伙从头到尾都像是在看别人的热闹……！[rhp]
话虽如此、突如其来的「啊——」让我既羞耻、[rhr]
又因为不想吃那个章鱼烧而陷入混乱。[rhp]

[:princess:][puri_w body=yukata kao=14 as=on ]
「不、不不不！我、我就不用了啦。哈哈哈……」[rhp]

[chara_part name="mata" body=yukata kao=2 as=off ss=off hh=on hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="gon" body=yukata kao=3 as=on ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:gonzalez:][p_gn_11]
「！！！你、你该不会不想吃吧……！？」[rhp]

[:mataroko:][p_mt_14]
「姐姐大人！就算为了小刚！快说『啊——』啦！」[rhp]

[:princess:][puri_w body=yukata kao=2 as=on ]
「呜咕……被、被你这么一说……」[rhp]
[:princess:]
「…………、……明白了啦！就一口哦！」[rhp]

[off_all]

[::]
下定决心重新面对快斗。[rhp]
只见被竹签扎着递到嘴边的章鱼烧后方，[rhr]
浮现出快斗恶魔般的笑容。这分明是明知难吃还故意使坏！[rhp]

[:princess:][puri_w body=yukata kao=2 as=on ss=on ]
「美食家的怨恨很可怕的……！给我记着快斗……！」[rhp]

[off_puri]

[:princess:]
「―――！！我开动了！！」[rhp]

[::]
抱着种种觉悟，将递来的甜味章鱼烧一口塞进腮帮。[rhr]
羞耻感和实实在在的灼热感让脸蛋几乎要喷火。[rhp]

[:princess:][puri_w body=yukata kao=6 as=on ]
「………………」[rhp]

[off_puri]

[::]
嘛，先不说烫不烫……嗯……[rhr]
倒没有想象中难吃，不过总觉得……呃……[rhp]

[:princess:][puri_w body=yukata kao=6 as=on ]
[font color=0x4682b4]
（是种难以评价的味道呢……）[rhp]
[resetfont]

[off_puri]

[::]
属于别人请客会吃，但自己不会花钱买的那种感觉……[rhp]

[:kite:][p_k_15][kite body=yukata kao=6 ]
「好吃到说不出话？真稀奇」[rhp]

[:princess:][puri_w body=yukata kao=6 as=on ]
[font color=0x4682b4]
（这、这家伙……居然在小刚主厨面前面不改色说这种……）[rhp]
[resetfont]

[:kite:][kite body=yukata kao=13 ]
「哈哈哈。脸鼓得像阿多福似的」[rhp]

[:princess:][puri_w body=yukata kao=2 as=on ]
[font color=0x4682b4]
（你以为是谁害的啊！？让我一口吞下去的罪魁祸首是———）[rhp]
[:princess:]
（啊不……主动一口吞的确实是我……可恶的快斗(?)！）[rhp]
[resetfont]

[off_all]

[::]
我将无处发泄的愤恨连同章鱼烧一起咽下，深深叹了口气。[rhp]
突然，观望着这场苦战的快斗，[rhr]
似乎想到什么似地小声咕哝着。[rhp]

[chara_part name="kite" body=yukata kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="puri_w" body=yukata kao=6 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「什么？想吃的话请便？」[rhp]

[:kite:][p_k_02]
「…………。刨冰之类的？」[rhp]

[:princess:][puri_w body=yukata kao=2 ss=on ]
「哈……？加热的刨冰会变成什么样你明白吧……？[rhr]
_　可以别拿食物玩了吗……？」[rhp]

[:kite:][p_k_25][kite body=yukata kao=2 as=on ]
「不是啦。……就是想着你可能想吃」[rhp]
[:kite:]
「刨冰、弹珠汽水、菠萝……[rhr]
_　……卖很多冰的东西，有偏好吗？」[rhp]

[:princess:][puri_w body=yukata kao=0 as=on ]
「…………那个」[rhp]

[off_all]

[::]
……莫非，因为我在发烧所以想买冰的东西？[rhp]

[:kite:][kite body=yukata kao=2 as=on ]
「……干嘛？一直盯着我看」[rhp]

[:princess:][puri_w body=yukata kao=0 as=on hh=on ]
「啊……谢谢。这么为我着想」[rhp]

[:kite:][kite body=yukata kao=11 ]
「没事没事。毕竟是男生嘛」[rhp]

[:princess:][puri_w body=yukata kao=1 hh=on ]
[font color=0x4682b4]
（虽说是男生，但之前总像小学男生那样让人担心……[rhr]
_　偶尔也会展现符合年龄的帅气嘛）[rhp]
[resetfont]

[off_all]

[::]
而且，突然被这样对待，总觉得……[rhr]
快斗不像快斗了，有种奇怪的感觉。[rhp]
…………心跳加速什么的，是错觉吧？[rhp]

[off_all]

[chara_part name="mata" body=yukata kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="nusi" body=yukata kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="gon" body=yukata kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="720" top="0" wait="true" time=150]

[:mataroko:][p_mt_15]
[font color=0x4682b4]
（哎呀哎呀～？气氛是不是有点微妙？）[rhp]

[:nusi:][p_ns_23]
（成长为不错的男人了呢……叔叔我有点感慨）[rhp]

[:gonzalez:][p_gn_24]
（公主看起来也不太讨厌的样子）[rhp]
[resetfont]

[off_all]

[:kite:][kite body=yukata kao=0 ]
「你们三个」[rhp]

[off_kite]

[chara_part name="mata" body=yukata kao=14 as=on ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="nusi" body=yukata kao=5 as=on ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="gon" body=yukata kao=5 as=on ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="720" top="0" wait="true" time=150]

[:nusi:]
「！！ 怎、怎么了？我们可没在开玩笑啊？」[rhp]

[:mataroko:]
「正是如此！我们正钦佩您出色的关怀呢」[rhp]

[:gonzalez:]
「完全没在想『一点也不像』之类的事哦？真的！」[rhp]

[off_all]

[:kite:][p_k_20][kite body=yukata kao=6 ]
「是吗……好吧这事总有一天要问清楚」[rhp]
[:kite:][kite body=yukata kao=12 ]
「我们差不多该走了。谢谢款待」[rhp]

[:princess:][puri_w body=yukata kao=13 ]
「绵球小丸子！还算好吃啦！」[rhp]

[off_all]

[chara_part name="mata" body=yukata kao=4 as=on ss=off hh=on hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="nusi" body=yukata kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="gon" body=yukata kao=5 as=off ss=off hh=on hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="720" top="0" wait="true" time=150]

[:mataroko:]
「绵、绵球小丸子……！？刚才说！？」[rhp]

[:gonzalez:][p_gn_03]
「把『棉球』和『章鱼烧』结合了吗……！真有品位！」[rhp]

[:nusi:]
「这群人真喜欢冷笑话啊」[rhp]

[off_all]

[::]
背对着因意外发言而愈发兴高采烈的三人，[rhr]
我们再度迈步踏入喧嚣的人潮……[rhp]

;****************************************
[fbgm]
[set_xx graphic="rule/krke_k.png" storage="fes_06.jpg"]
[bgm storage="bgm_29.ogg"]
;****************************************

[::]
普通地享受祭典，快乐度过时光的我们。[rhr]
逛完一圈后，前往了约定观赏烟花的广场。[rhp]

虽未到正式开始时间，但人影稀疏，也无其他成员集合的迹象。[rhp]
干站着也不是办法，[rhr]
我们便坐在附近一张生锈的铁制长椅上等待他们到来。[rhp]

[chara_part name="kite" body=yukata kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="puri_w" body=yukata kao=1 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「祭典真好玩呢！[rhr]
_　多亏没有记忆反而更开心了」[rhp]

[:kite:][p_k_07][kite body=yukata kao=12 ]
「是啊。太好了呢」[rhp]
[:kite:]
「我也玩得很开心。吃了各种美食，还得到了宠物」[rhp]

[:princess:]
「宠物……啊！是说那条金鱼吗？」[rhp]

[:kite:][kite body=yukata kao=7 ]
「对。捞金鱼……就是拿到金鱼的那个」[rhp]

[:princess:][puri_w body=yukata kao=13 as=on ]
[font color=0x4682b4]
（因为一条都没捞到，作为赠品得到的那条吧……）[rhp]
[resetfont]

[:kite:][p_k_31][kite body=yukata kao=11 ]
「一直想着要养点什么，[rhr]
_　其实还挺开心的」[rhp]

[:princess:][puri_w body=yukata kao=1 ]
「这样啊。已经取好名字了吗？」[rhp]

[:kite:][kite body=yukata kao=7 ]
「嗯……还没。公主你来取吧」[rhp]

[:princess:][puri_w body=yukata kao=0 as=on ]
「诶？我、我就不用了！难得的机会快斗你来取吧」[rhp]

[:kite:][p_k_02]
「我取名的品味差是公认的。[rhr]
_　拜托公主了」[rhp]

[:princess:][puri_w body=yukata kao= ]
「这、这样啊……那就叫小鱼太郎怎么样？」[rhp]

[:kite:][p_k_17][kite body=yukata kao=5 as=on ]
「………………。……抱歉还是我来想吧」[rhp]

[:princess:][puri_w body=yukata kao=3 ]
「诶——不行吗？我觉得挺帅气的」[rhp]

[:kite:]
「金鱼不需要帅气」[rhp]

[off_all]

[::]
快斗举起装着金鱼的袋子挡在脸前，轻轻笑了笑。[rhp]
金鱼慌乱地游来游去[rhr]
和主人快斗完全相反，有点有趣。[rhp]

[:kite:][p_k_06]
「从今天起我就是主人了。小穆尔奇」[rhp]

[:princess:]
「穆尔奇是什么？」[rhp]

[:kite:]
「希望它能成长为又大又强的孩子。[rhr]
_　详情请咨询博士」[rhp]

[chara_part name="kite" body=yukata kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="puri_w" body=yukata kao=13 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:kite:][p_k_19]
「…………。搞什么啊」[rhp]

[:princess:]
「呵呵呵！没什么特别的」[rhp]
[:princess:]
「总觉得快斗、今天心情挺好的呢！」[rhp]

[:kite:]
「是吗？　和平常没什么两样啊」[rhp]

[:princess:]
「平时不是总说好累啊好困啊之类的。[rhr]
_　就连野营的时候，基本上也是发着呆不去找克林」[rhp]

[:kite:][p_k_02][kite body=yukata kao=7 ]
「嗯——…………」[rhp]
[:kite:]
「……………………」[rhp]
[:kite:]
「……是有好事发生哦」[rhp]

[:princess:][puri_w body=yukata kao=13 ]
「原来是这样啊。[rhr]
_　那能赶上你干劲十足的时候约你真是走运呢，我」[rhp]

[:kite:]
「那个」[rhp]

[:princess:][puri_w body=yukata kao=0 ]
「诶？　哪个？」[rhp]

[:kite:][p_k_06]
「就是你约我这件事的缘故」[rhp]
[:kite:]
「这约的不就是那种约会嘛。[rhr]
_　我超级亢奋的啊」[rhp]

[:princess:][puri_w body=yukata kao=2 as=on ]
「完全没看出来好吗！？」[rhp]

[off_all]

[:princess:]
[font color=0x4682b4]
（……话说回来！）[rhp]
[resetfont]

[off_all]

[::]
约……约会什么的。[rhr]
根本没往那方面想，太冲击了。[rhp]
明明只是单纯觉得和快斗在一起应该很开心而已。[rhp]
而且……快斗居然因为这是「约会」而感到高兴。[rhp]
…………稍微有点意外。[rhr]
我还以为快斗对那种事根本不感兴趣呢。[rhp]

[:kite:][p_k_04][kite body=yukata kao=2 ]
「…………。我说啊」[rhp]

[:princess:][puri_w body=yukata kao=2 as=on hh=on ]
「啊、在！」[rhp]

[:kite:][kite body=yukata kao=3 ]
「………………」[rhp]

[:princess:][puri_w body=yukata kao=0 ]
「……快斗？」[rhp]

[:kite:][p_k_28][kite body=yukata kao=12 ]
「…………不、抱歉」[rhp]
[:kite:]
「刚才稍微下了点决心」[rhp]

[:princess:]
「决心？什么决心？」[rhp]

[:kite:][kite body=yukata kao=6 ]
「…………这也要我说出来吗」[rhp]

[:princess:][puri_w body=yukata kao=2 as=on ]
「？」[rhp]

[:kite:][kite body=yukata kao=3 ]
「哈……算了。你从小就这样」[rhp]
[:kite:]
「…………但我决定了。这次一定要说出来」[rhp]
[:kite:]
「既然约我出来，就说明有戏对吧」[rhp]

[:princess:][puri_w body=yukata kao=0 as=on ]
「诶……」[rhp]

[off_all]

[:kite:][p_k_04]
「…………公主」[rhp]

;****************************************
;スチル
[still storage="cg/a_07_k_1.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/a_07_k_1.png"]
;****************************************

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:kite:]
「我、我喜欢你」[rhp]

[:princess:]
「――――诶」[rhp]

突如其来的话语，让我瞬间僵住。[rhp]
等理解其中含义后，反而更加混乱了。[rhp]
喜欢、我？[rhp]

[:kite:]
「有这么吃惊吗……」[rhp]
[:kite:]
「……我觉得自己表现得很明显了啊？」[rhp]

[:princess:]
「完、完全没看出来……」[rhp]

[:kite:]
「是你太迟钝了吧」[rhp]
[:kite:]
「…………从一开始，我就喜欢你了」[rhp]

[:princess:]
「快、快斗……」[rhp]

[::]
震惊过度，不知该如何回应。[rhp]
顾不上手忙脚乱的我，快斗平静地继续说道。[rhp]

[:kite:]
「…………我们活着的时候就是挚友了」[rhp]
[:kite:]
「从那时候就喜欢你了。还没来得及告诉你，[rhr]
_　虽然我已从你面前消失……」[rhp]
[:kite:]
「所以当在这里再次相遇时，我有多开心。[rhr]
_　说实话，因为我确信再也不会见面了，所以更加……」[rhp]
[:kite:]
「……可你不仅忘了迄今为止的旅程，[rhr]
_　连与我的过去也全部遗忘了」[rhp]
[:kite:]
「不……旅程的事无所谓。重点不在于那里。[rhr]
_　对我来说问题在于，你对我们过去的点点滴滴毫无记忆」[rhp]
[:kite:]
「……今天和我相处这么久，还是没想起来吧」[rhp]

[:princess:]
「对、对不起……」[rhp]

[::]
该如何打破这沉默才好。[rhr]
不知怎样回答才算正确，我只能低头不语。[rhp]
片刻后，听见快斗轻轻的叹息。[rhp]


[:kite:]
「……自从完全失忆的你醒来，[rhr]
_　询问记忆的事之后，我就不知该如何面对你」[rhp]
[:kite:]
「虽然如此……为这种事烦恼的窝囊自己，[rhr]
_　也没法向任何人倾诉」[rhp]
[:kite:]
「……明明可能比谁都更喜欢你。[rhr]
_　装作毫不在意的样子，其实很辛苦」[rhp]

[:princess:]
「快斗……」[rhp]

;****************************************
#
[bg storage="cg/a_07_k_1b.png" width="1280" height="720" time=500]
[cg storage="cg/a_07_k_1b.png"]
;****************************************

[:kite:]
「……不回答吗？」[rhp]

[:princess:]
「诶？回、回答？」[rhp]

[:kite:]
「刚刚告白了。你的答复」[rhp]
[:kite:]
「……愿意喜欢上我吗」[rhp]

[::]
平静却因此更具压迫感的话语。[rhr]
那或许是我所不曾知晓的岁月积淀带来的感受吧。[rhp]

[:princess:]
[font color=0x4682b4]
（可是……）[rhp]
[resetfont]

[::]
你所喜欢的关于我的一切，我却一无所知。[rhp]

[fbgm]

[:princess:]
「……抱歉」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;----------------------------------------------------------------------------------------

;****************************************
#
[bg storage="cg/a_07_k_1c.png" width="1280" height="720" time=500]
[cg storage="cg/a_07_k_1c.png"]
;****************************************

[:kite:][p_k_13]
「―――――诶」[rhp]

[bgm storage="bgm_15.ogg"]

[:princess:]
「我确实喜欢快斗。想和你变得更亲密，[rhr]
_　如果曾是挚友的话也想找回那些记忆」[rhp]
[:princess:]
「但这意味着现在的我除了失忆后认识的快斗外什么都不了解对吧」[rhp]
[:princess:]
「虽然不清楚我和快斗过去有怎样的交集，[rhr]
_　那个……对我而言现在的快斗，只是刚认识一个月朋友而已」[rhp]

[:kite:]
「…………」[rhp]

[:princess:]
「所、所以……对不起……」[rhp]
[:princess:]
「………这个答案，现在可能没法立刻给你……」[rhp]

;****************************************
;スチル終了
[still_end frame="win.png" storage="fes_06.jpg" time=1000]
;****************************************

[::]
用逐渐微弱的声音说着，我不自觉地低下了头。[rhp]
既未被表白过，也从未拒绝过别人。[rhr]
这种场合该如何应对，对我而言实在太过沉重。[rhp]

[:kite:]
「…………………………」[rhp]

[::]
……沉默令人煎熬。[rhp]
为逃离这令人窒息的空气，我抬起头来……[rhp]

;****************************************
;スチル
[still storage="cg/a_07_k_2.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/a_07_k_2.png"]
;****************************************

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:princess:]
「―――！哎……！？」[rhp]

[:kite:]
「………………」[rhp]

[::]
快斗的视线垂向地面，只是安静地流着泪。[rhp]
这突发状况让我手足无措，眼前的他令我全然困惑。[rhp]

[:kite:]
「…………呜～……」[rhp]

[:princess:]
「啊等、那个那个！不是这样的！[rhr]
_　仅仅因为答不上来，并不是讨厌……！」[rhp]

[:kite:]
「我……」[rhp]
[:kite:]
「……都怪我、……都是……这种样子……」[rhp]

[:princess:]
「……诶……」[rhp]

[:kite:]
「都到这一步了……还这么……丢人……」[rhp]
[:kite:]
「……如果没记住的话……就更不可能被喜欢了……」[rhp]

[:princess:]
「……？」[rhp]

[:kite:]
「……呜、唔……要是能……早点说出来……」[rhp]
[:kite:]
「……全搞砸、了……呜、嗯……」[rhp]
[:kite:]
「——呜啊啊啊……！」[rhp]

[::]
……面对孩子般哭泣的快斗，我找不到合适的话语。[rhp]

;****************************************
[still_end frame="win.png" storage="black.jpg" time=1000]
;****************************************

随后一切转瞬即逝。[rhp]
最终既没能等到大家集合，[rhr]
也没能仰望庆典烟花，我们的夏日祭便这样落幕了。[rhp]
我硬拉着哭泣的他返回铁道。[rhp]

;****************************************
;回想
[set_kk storage="cg/a_07_k_2.png"]
;****************************************

―――都怪我这副模样。[rhp]
―――事到如今这种家伙，怎么可能被不记得的人喜欢。[rhp]
―――要是能早点说出口。[rhp]

这些话语必定是我记忆的碎片。[rhr]
但其中浸染的情绪，只有快斗本人才懂。[rhp]

;****************************************
[set_ff storage="sky_07.jpg"]
;****************************************

他流泪的理由，我可以问吗。[rhp]
不知道。比起好奇心，更惧怕会伤害到他。[rhp]
仍在抽泣的快斗，在我身旁重复着同样的话。[rhp]

;****************************************
[bg storage="black.jpg" time=1000]
;****************************************

[:kite:]
「受不了了……想死掉算了……」[rhp]

[::]
明明应该完全不记得过去的事情才对。[rhp]
……不知为何，总觉得对这句话很是熟悉。[rhp]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
[s_mask color=0xffffff time=2000]
[set_xx graphic="rule/krke_k.png" storage="train_08.jpg"]
;****************************************

; イベント分岐の解除
[iscript]
delete f.ev_a_07;
[endscript]

[jump storage="ev_a_08_kite.ks" ]

[s]
