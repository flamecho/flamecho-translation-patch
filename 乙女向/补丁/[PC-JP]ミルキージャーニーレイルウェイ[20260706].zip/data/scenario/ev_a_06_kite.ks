﻿
*start
;--------------------------------------------------------------------------------------------
;▼フルボイスセット▼
;カイト
[voconfig sebuf=1 name=kite vostorage="kite/full/{number}.ogg" number=98]
;--------------------------------------------------------------------------------------------

[chara_part name="drop" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=1 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「那就这样吧！　多洛普在这里搭帐篷等克林。[rhr]
_　而我们履行各自职责的同时，公平地全员一起寻找克林」[rhp]
[:princess:]
「这样就不用全员一起行动，还能搜索更广的范围呢！」[rhp]

[:drop:]
「只能这样了。说不定夸德里利昂[rhr]
_　会自己回来呢」[rhp]

[off_all]

[:kite:][kite kao=3 ][p_k_05]
「哈啊……都怪克林搞得这么麻烦。[rhr]
_　公主也处在爆发边缘了。我能完好无损回去吗」[rhp]

[:princess:][puri_w kao=2 as=on ]
「不会发飙也不会闹的！」[rhp]

[off_all]

[chara_part name="hakase" body=base kao=7 as=off ss=off hh=off hr=on msk=hat ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="otiai" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:otiai:]
「我赞成。海边和山脚方向大致也能分组行动」[rhp]

[:darknebula:]
「那我们负责东侧区域，[rhr]
_　哈托谢普君你们能负责西侧吗」[rhp]

[off_all]

[chara_part name="jet" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" ait="false" time=150]
[chara_part name="hati" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:]
「哦！　包在我身上！」[rhp]

[:jet:]
「～～～～～～～……」[rhp]

[:princess:][puri_w kao=6 ]
「喂。别因为被冷静对待就板着脸」[rhp]

[:jet:]
「真没劲。早知道就该把公主[rhr]
_　而不是克林吹飞算了」[rhp]

[:princess:][puri_w kao=2 as=on ss=on ]
「！？」[rhp]

[:heartshape:][hati kao=5 ]
「安心吧杰特！　今后克林的反应绝对[rhr]
_　会超有趣的好吗！！」[rhp]

[:jet:][jet kao=5 ]
「那倒也是。真希望他快点发火～」[rhp]

[:princess:][puri_w kao=2 as=on ]
「……………………」[rhp]

[off_all]

[:princess:][puri_w kao=13 as=on ]
「……算了不管了！」[rhp]

[off_all]

[chara_part name="hakase" body=base kao=1 as=on ss=off hh=off hr=on msk=hat ]
[chara_show name="hakase" layer="1" width="571" height="720" left="40" top="0"  wait="false" time=150]
[chara_part name="kite" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="drop" body=base kao=13 as=on ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="760" top="0" wait="true" time=150]

[:3nin:]
[font color=0x4682b4]
（这样真的好吗……）[rhr]
（这样真的好吗……）[rhr]
（这样真的好吗……）[rhp]
[resetfont]

;****************************************
[fbgm]
[set_00 storage="jungle_06.jpg"]
[bgm storage="bgm_29.ogg"]
;****************************************

[::]
就这样我们，[rhr]
从根据地稍微走了一段路，来到靠近河口的地方。[rhp]
虽然之前也去过海边，但比起上次那种开放的度假胜地[rhr]
这里几乎是原生态的海边，总觉得有种新鲜感。[rhp]
嘛，这确实是值得高兴的事啦……[rhp]

;****************************************
;スチル
[still storage="cg/a_06_k_1.png" rule="021.png" width="1280" height="720" time=1000]
[cg storage="cg/a_06_k_1.png"]
;****************************************

[:princess:]
「喂快斗。不找克林了吗？」[rhp]

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
[vostart]
;--------------------------------------------------------------------------------------------

[:kite:]
「嗯——？嗯——……啊——」[rhp]

[off_all]

[::]
快斗将用魔法变出的钓竿固定在身旁，仰面躺下闭上眼睛。[rhp]
面对他悠闲的态度，我内心其实非常着急。[rhp]

[:princess:]
「虽说夸德里利昂是个受气包的角色，[rhr]
_　但这样总觉得有点可怜……」[rhp]

[:kite:]
「无所谓吧。那家伙意外地很能干，[rhr]
_　就算我们什么都不做也能搞定啦」[rhp]
[:kite:]
「你平时不是常说吗。就是那个……」[rhp]

[:princess:]
「？」[rhp]

;****************************************
#
[bg storage="cg/a_06_k_1b.png" width="1280" height="720" time=300]
[cg storage="cg/a_06_k_1b.png"]
;****************************************

[:kite:]
「…………。哈哈哈」[rhp]

[:princess:]
「别用笑蒙混过关！又不是无话可说！！」[rhp]
[:princess:]
「真是的。虽然确实有点坏心眼，但他不是坏人吧。[rhr]
_　快斗讨厌夸德里利昂吗？」[rhp]

[off_all]

;****************************************
#
[bg storage="cg/a_06_k_1c.png" width=1280 height=720 time=300]
[cg storage="cg/a_06_k_1c.png"]
;****************************************

[:kite:]
「讨厌啊」[rhp]

[::]
意料之外的回答让我语塞。[rhp]
虽然那么问了，但我原本预期他会说「不是那样的」。[rhr]
虽然大家也会吵架，但我原本以为他们终究是关系要好的。[rhp]

[:kite:]
「宙……不、落合也是这样」[rhp]
[:kite:]
「…………那样的家伙，不是我认识的那个他。[rhr]
_　我活着的时候认识的他，根本不是那副模样」[rhp]
[:kite:]
「所以才令人火大。[rhr]
_　从很久以前开始，我就最讨厌那家伙了」[rhp]

[::]
快斗一直以来就有许多令人费解的言行，[rhr]
其中多有难以理解其真意的情况。[rhp]
但这次这番言论，不能以『算了就这样吧』搪塞过去。[rhp]
夸德里利昂是重要的伙伴。[rhr]
被恶语相向，没有能接受的正当理由便不会退让。[rhp]

[:princess:]
「……快斗所认识的夸德里利昂，是什么样的人？」[rhp]

[:kite:]
「与现在完全相反的家伙」[rhp]

[:princess:]
「那是快斗的主观看法吧。他说不定是想要改变才改变的」[rhp]
[:princess:]
「现在在这里的夸德里利昂，[rhr]
_　说不定正是夸德里利昂想要成为的模样吧」[rhp]
[:princess:]
「因为这里，可是能实现任何愿望的魔法世界啊」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:kite:]
「……………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:princess:]
「无论是哪个夸德里利昂，都是夸德里利昂。[rhr]
_　既然是想成为理想的自己而实现愿望，根本不是什么坏事吧」[rhp]
[:princess:]
「还是说……快斗不愿意接受这种事？」[rhp]

[:kite:]
「………………搞什么啊、那个」[rhp]

[:princess:]
[font color=0x4682b4]
（！　糟了……可能有点说教味太重了）」[rhp]
[resetfont]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:kite:]
「……………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:princess:]
「啊、呃。我、我并没有在生气哦？[rhr]
_　只是我个人这么觉得或者说、所以那个～」[rhp]

[:kite:]
「公主你也变了不少呢」[rhp]

[:princess:]
「！」[rhp]

[:kite:]
「虽然像这样一本正经地搬出大道理的地方倒是一点没变」[rhp]
[:kite:]
「……不像以前那样有自信了」[rhp]

[:princess:]
「自信……」[rhp]

[:kite:]
「不久之前的你、明明还摆出一副我说的全都正确、[rhr]
_　我即是王道、我才是主角的态度」[rhp]

[:princess:]
「我、我原来是那么讨厌的家伙吗！？　有点受打击了……」[rhp]

[:kite:]
「……、倒也不是说讨厌」[rhp]
[:kite:]
「只是太完美了。公主你」[rhp]

[:princess:]
「……完美？　我？」[rhp]

;****************************************
#
[bg storage="cg/a_06_k_1b.png" width="1280" height="720" time=300]
;****************************************

[:kite:]
「我其实不在意的。[rhr]
_　只是稍微说教两句、不用每次都战战兢兢的」[rhp]
[:kite:]
「任性的是我啦。……这种程度的事、我还是明白的」[rhp]

[:princess:]
「快斗……」[rhp]

[:kite:]
「嘛、不管是以前的克林还是现在的克林都照样烦人就是了」[rhp]
[:kite:]
「我只是觉得、以前那家伙更容易亲近而已」[rhp]

[:princess:]
「……你们两人的关系……不用在意对吧？」[rhp]

[:kite:]
「爱管闲事这点倒是和从前一模一样。[rhr]
_　这方面要是能改改就好了、毕竟真的很烦人」[rhp]

[:princess:]
「……！　不要啦！　快斗的任性我可不会纵容哦。[rhr]
_　以后还会不断管着你，做好心理准备吧！」[rhp]

[:kite:]
「呜哇～～～～，烦死了」[rhp]

[:princess:]
「呼呼呼……！」[rhp]

[::]
虽然一度担心事情会变得不可收拾，但总算恢复了平日的氛围。[rhp]
……通过方才的对话和先前的言行，我隐约察觉到了一件事。[rhp]

[:princess:]
[font color=0x4682b4]
（大概我们活着的时候是朋友吧）[rhp]
[:princess:]
（快斗和，克林和，我……[rhr]
_　虽然不太确定，但其他人应该也是）[rhp]
[:princess:]
（……这样一来，就更想找回记忆了呢）[rhp]
[resetfont]

;****************************************
;スチル終了
[still_end frame="win.png" storage="jungle_06.jpg" rule="021.png" time=1000]
;****************************************


[:princess:][puri_w ]
「呐快斗」[rhp]

[:kite:][kite kao=7 ]
「怎么？钓到了？我这边还一条都没……」[rhp]

[:princess:][puri_w ]
「要是能像从前那样，三个人好好相处就好了」[rhp]

[:kite:][kite kao=4 ]
「…………啊」[rhp]

[:princess:][puri_w kao=11 ]
「为了这个，我也会更加努力寻找记忆的线索――――」[rhp]

[:kite:][kite kao=2 as=on ]
「你想起来了？」[rhp]

[:princess:][puri_w kao=4 as=on ]
「咦」[rhp]

[:kite:]
「关于我的事，大家的事……！真的吗？」[rhp]

[:princess:][puri_w kao=0 as=on ]
「啊，不是……不是这个意思。[rhr]
_　我是说如果能想起来的话，相处起来会更开心吧」[rhp]

[:kite:][kite kao=4 as=on ]
「…………！　啊……」[rhp]
[:kite:][kite kao=3 as=on ]
「……………………这样啊。说得也是」[rhp]

[:princess:][puri_w kao=8 as=on ]
「对、对不起……」[rhp]

[:kite:][kite kao=6 ]
「……没事。我才是突然说这些抱歉」[rhp]

[:princess:][puri_w as=on ]
「可、可是你们是朋友对吧？在活着的时候」[rhp]

[:kite:][kite kao=12 ]
「……是啊。和公主可是挚友呢」[rhp]
[:kite:][kite kao=7 ]
「每天都被你吵死人的声音叫醒……」[rhp]

[:princess:][puri_w kao=5 as=on hh=on ]
「虽然听着有点难为情……不过可能成为恢复记忆的线索。[rhr]
_　还有呢？知道的事全都告诉我嘛！」[rhp]

[:kite:][kite kao=6 ]
「诶？不要啦」[rhp]

[:princess:][puri_w kao=2 as=on ]
「为什么啊！？刚才不是稍微讲了一点嘛！」[rhp]

[:kite:][kite kao=7 ]
「为什么觉得只有我会告诉你别人都死活不肯说的事啊」[rhp]

[:princess:]
「因为是挚友」[rhp]

[:kite:][kite kao=6 ]
「真是现实的家伙……总之，更多的我不会说了」[rhp]

[:princess:][puri_w kao=3 ]
「啊啊真是的……反正又不会少块肉，稍微讲点嘛。[rhr]
_　要是我能想起过去的事，大家不也会开心吗」[rhp]
[:princess:]
「我们是朋友对吧？[rhr]
_　还是说，我和你们其实没那么要好呢……」[rhp]

[:kite:][kite kao=12 ]
「没这回事。你永远都是众人的中心。这点现在也没变」[rhp]
[:kite:]
「所以其实，不想起来也没关系吧」[rhp]

[:princess:][puri_w kao=6 ]
「这是两码事啦」[rhp]

[:kite:][kite kao=7 ]
「有些事想起来比较好，也有些事别想起来比较好。[rhr]
_　要我选的话，我觉得『后者』更重要吧」[rhp]
[:kite:]
「要是只有『在这里的时光』该多好。[rhr]
_　临死前的记忆什么的，可不是那么美好的东西」[rhp]

[:princess:][puri_w kao=3 as=on ]
「……嘛，或许是这样吧……」[rhp]

[off_all]

[::]
即便如此，我还是想要取回记忆。[rhr]
虽然也有和夜的约定这个原因，但不仅如此。[rhp]

[:princess:][puri_w kao=3 ]
「如果能想起过去的事，应该能和快斗变得更要好」[rhp]

[:kite:][kite kao=6 as=on ]
「…………！」[rhp]

[:princess:]
「讲述着我所不知道的事情的快斗，看起来比平时温柔得多。[rhr]
_　一定是因为，他最喜欢那段时光了吧」[rhp]
[:princess:]
「我也想一起，聊那样的话题」[rhp]

[:kite:][kite kao=0 as=on ]
「公主……」[rhp]

[off_all]

[::]
对于快斗的话，我并非无法赞同。[rhp]
虽然不知道我的结局会是什么样子，[rhr]
但正如他所说，我也不太想要痛苦的回忆。[rhr]
但即便是那样的记忆，我也想要全部接纳，去了解真正的自己。[rhp]
如果不了解真正的自己，[rhr]
就肯定无法明白，什么才是真正的心之所向。[rhp]

[:kite:][kite kao=3 ]
「…………哦……那随你便吧」[rhp]

[:princess:][puri_w ]
「就算不告诉我也没关系，但要协助我哦。[rhr]
_　克林可能会刁难人，快斗你比较靠谱嘛」[rhp]

[:kite:][kite kao=3 ]
「擅自依赖我也……本来我就没打算拒绝」[rhp]

[off_all]

;着信音
[se storage="se5_08.ogg"]

[:kite:]
「…………啊」[rhp]

[::]
突然，从快斗围裙下藏着的对讲机里[rhr]
传出了平时听不惯的噪音。[rhp]

[se storage="se5_08.ogg"]
;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:vulpecula:]
[font color=0x696969]
『这里是佩奇！捕获到克林了哇！』[rhp]

[yurasu]

[:quadrillion:]
[font size=30]
『该死的红白！！等我回去你们就完蛋了！！』[rhp]
[resetfont]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[::]
对方不出所料，是来报告发现夸德里利昂的消息。[rhp]
不知为何那三个人组突然到场，[rhr]
似乎和博士他们在途中会合展开搜索后，便有了这个发现。[rhp]

[:kite:][kite kao=6 ]
「总算来了啊。那群家伙在搞什么」[rhp]

[:princess:][puri_w kao=2 as=on ]
「你没资格说这话」[rhp]

[:kite:][kite kao=12 ]
「……那，我们回去吧」[rhp]

[off_all]

[::]
快斗慢吞吞地站了起来说道。[rhp]
………………。总感觉忘了什么……[rhp]

[:princess:][puri_w kao=2 as=on ]
「啊！！鱼还一条都没钓到呢！」[rhp]

[:kite:][kite kao=6 ]
「啊——……，…………」[rhp]

[:princess:][puri_w kao=8 as=on ]
「这样不就暴露我们在偷懒了吗。[rhr]
_　说不定会被多洛普骂的……！」[rhp]

[:kite:][kite kao=5 ]
「所以要用这个嘛」[rhp]

[off_all]

[::]
快斗说着轻轻打了个响指，[rhr]
随着细微的烟雾，桶里凭空出现了与人数等量的鱼。[rhp]

[chara_part name="kite" body=base kao=11 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=2 as=on ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「这、这算作弊吧……！[rhr]
_　大家明明都说好要自己钓鱼的！」[rhp]

[:kite:]
「好啦好啦，有什么关系嘛。吃进肚子都一样」[rhp]
[:kite:]
「就我们俩的……小秘密？」[rhp]

[:princess:]
「又在耍帅强行蒙混过关了吧……」[rhp]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

[off_all]

[::]
真是的，这人活得也太随心所欲了。[rhp]
不过和快斗在一起倒是挺轻松的。[rhr]
虽然不知道你在想什么，但不用太顾虑。[rhp]
曾经是挚友这件事，我也能理解。[rhp]

[:princess:]
[font color=0x4682b4]
（……记忆。要是能早点想起来就好了）[rhp]
[resetfont]

[::]
为了我，也为了快斗。[rhp]
我再次这样期许着，与他离开了海岸……[rhp]

;****************************************
[jump storage="ev_a_06.ks" target="*start2"]
;****************************************


[s]
