
*start_end

[cm]

; プレイヤー操作禁止
[stop_keyconfig]

; メニューアイコン非表示
[hidemenubutton]

;メッセージボックス非表示
[layopt layer="message" visible=false]

*start 

[cm]

@clearstack
[layopt layer="message0" visible="false"]

; ev_fタイトル
[if exp="sf.f_end == 1"]
[bgm storage="bgm_47.ogg"]
[bg storage ="title/menu8.png" time=100 width="1280" height="720" ]

; ev_dハティ追加タイトル
[elsif exp="sf.e_end == 1 "]
[bgm storage="bgm_46.ogg"]
[bg storage ="title/menu7.png" time=100 width="1280" height="720" ]

; ev_eタイトル
[elsif exp="sf.d_d_end == 1 && sf.d_k_end ==1 && sf.d_r_end ==1 && sf.d_s_end ==1 "]
[bgm storage="bgm_46.ogg"]
[bg storage ="title/menu6.png" time=100 width="1280" height="720" ]

; ev_dタイトル
[elsif exp="sf.c_end == 1 "]
[bgm storage="bgm_45.ogg"]
[bg storage ="title/menu5.png" time=100 width="1280" height="720" ]

; ev_cタイトル
[elsif exp="sf.b2_end == 1 "]
[bgm storage="bgm_44.ogg"]
[bg storage ="title/menu4.png" time=100 width="1280" height="720" ]

; ev_b2タイトル
[elsif exp="sf.b1_end == 1 "]
[bgm storage="bgm_44.ogg"]
[bg storage ="title/menu3.png" time=100 width="1280" height="720" ]

; ev_b1タイトル
[elsif exp="sf.a_d_end == 1 && sf.a_k_end == 1 && sf.a_r_end == 1 && sf.a_h_end == 1"]
[bgm storage="bgm_44.ogg"]
[bg storage ="title/menu2.png" time=100 width="1280" height="720" ]

; 初期タイトル
[else]
[bgm storage="bgm_43.ogg"]
[bg storage ="title/menu.png" time=100 width="1280" height="720" ]

[endif] 

; ------------------------------------------------
; 最終タイトル
; ------------------------------------------------
[if exp="sf.f_end == 1 "]

;７章
[button x="360" y="160" storage="ev_f.ks" target="*start" graphic="button/2nd_story7.png" enterimg="button/2nd_story7b.png" enterse=btn_03.ogg clickse=btn_02.ogg ]

;６章
[button x="408" y="160" storage="ev_e.ks" target="*start" graphic="button/2nd_story6.png" enterimg="button/2nd_story6b.png" enterse=btn_03.ogg clickse=btn_02.ogg ]

;５章
[button x="454" y="160" storage="ev_d.ks" target="*start" graphic="button/2nd_story5.png" enterimg="button/2nd_story5b.png" enterse=btn_03.ogg clickse=btn_02.ogg ]

;４章
[button x="500" y="160" storage="ev_c.ks" target="*start" graphic="button/2nd_story4.png" enterimg="button/2nd_story4b.png" enterse=btn_03.ogg clickse=btn_02.ogg ]

;３章
[button x="546" y="160" storage="ev_b2.ks" target="*start" graphic="button/2nd_story3.png" enterimg="button/2nd_story3b.png" enterse=btn_03.ogg clickse=btn_02.ogg ]

;２章
[button x="592" y="160" storage="ev_b1.ks" target="*start" graphic="button/2nd_story2.png" enterimg="button/2nd_story2b.png" enterse=btn_03.ogg clickse=btn_02.ogg ]

;１章
[button x="639" y="160" target="*gamestart" graphic="button/2nd_story1.png" enterimg="button/2nd_story1b.png" enterse=btn_03.ogg clickse=btn_02.ogg ]

; 読込
[button x="30" y="337" graphic="button/button_load.png" enterimg="button/button_load2.png" enterse=btn_03.ogg clickse=btn_03.ogg role="load" ]
; 記録
[button x="30" y="393" graphic="button/button_save.png" enterimg="button/button_save2.png" enterse=btn_03.ogg clickse=btn_03.ogg role="save" ]
; 名前変更
[button x="30" y="449" graphic="button/button_name.png" enterimg="button/button_name2.png" enterse=btn_03.ogg clickse=btn_03.ogg storage="name.ks"  ]
; 回想
[button x="30" y="505" graphic="button/button_cg.png" enterimg="button/button_cg2.png" enterse=btn_03.ogg clickse=btn_03.ogg storage="cg.ks" ]
; 設定
[button x="30" y="561" graphic="button/button_config.png" enterimg="button/button_config2.png" enterse=btn_03.ogg clickse=btn_03.ogg role="sleepgame" storage="config.ks" ]
; 終了
[button x="30" y="617" graphic="button/button_gameend.png" enterimg="button/button_gameend2.png" enterse=btn_03.ogg clickse=btn_03.ogg target="*gameend" ]
[mask_off time=500]
[s]
[endif]

; ------------------------------------------------
; b1以降のタイトルボタン
; ------------------------------------------------
[if exp="sf.a_d_end == 1 && sf.a_k_end == 1 && sf.a_r_end == 1 && sf.a_h_end == 1"]

;１章
[button x="838" y="155" target="*gamestart" graphic="button/2nd_story1.png" enterimg="button/2nd_story1b.png" enterse=btn_03.ogg clickse=btn_02.ogg ]

;２章
[button x="786" y="155" storage="ev_b1.ks" target="*start" graphic="button/2nd_story2.png" enterimg="button/2nd_story2b.png" enterse=btn_03.ogg clickse=btn_02.ogg ]

;３章
[if exp="sf.b1_end == 1 "]
[button x="735" y="155" storage="ev_b2.ks" target="*start" graphic="button/2nd_story3.png" enterimg="button/2nd_story3b.png" enterse=btn_03.ogg clickse=btn_02.ogg ]
[endif] 

;４章
[if exp="sf.b2_end == 1 "]
[button x="686" y="155" storage="ev_c.ks" target="*start" graphic="button/2nd_story4.png" enterimg="button/2nd_story4b.png" enterse=btn_03.ogg clickse=btn_02.ogg ]
[endif] 

;５章
[if exp="sf.c_end == 1 "]
[button x="634" y="155" storage="ev_d.ks" target="*start" graphic="button/2nd_story5.png" enterimg="button/2nd_story5b.png" enterse=btn_03.ogg clickse=btn_02.ogg ]
[endif] 

;６章
[if exp="sf.d_d_end == 1 && sf.d_k_end ==1 && sf.d_r_end ==1 && sf.d_s_end ==1 "]
[button x="581" y="155" storage="ev_e.ks" target="*start" graphic="button/2nd_story6.png" enterimg="button/2nd_story6b.png" enterse=btn_03.ogg clickse=btn_02.ogg ]
[endif] 

; 読込
[button x="30" y="542" graphic="button/button_load.png" enterimg="button/button_load2.png" enterse=btn_03.ogg clickse=btn_03.ogg role="load" ]
; 記録
[button x="113" y="542" graphic="button/button_save.png" enterimg="button/button_save2.png" enterse=btn_03.ogg clickse=btn_03.ogg role="save" ]
; 回想
[button x="196" y="542" graphic="button/button_cg.png" enterimg="button/button_cg2.png" enterse=btn_03.ogg clickse=btn_03.ogg storage="cg.ks" ]
; 設定
[button x="279" y="542" graphic="button/button_config.png" enterimg="button/button_config2.png" enterse=btn_03.ogg clickse=btn_03.ogg role="sleepgame" storage="config.ks" ]
; 名前変更
[button x="362" y="542" graphic="button/button_name.png" enterimg="button/button_name2.png" enterse=btn_03.ogg clickse=btn_03.ogg storage="name.ks"  ]
; 終了
[button x="445" y="542" graphic="button/button_gameend.png" enterimg="button/button_gameend2.png" enterse=btn_03.ogg clickse=btn_03.ogg target="*gameend" ]

[mask_off time=500]
[s]

[endif]

; ------------------------------------------------
; 初期タイトルボタン
; ------------------------------------------------
;１章
[button x="284" y="155" target="gamestart" graphic="button/story1.png" enterimg="button/story1b.png" enterse=btn_03.ogg clickse=btn_02.ogg ]

; 読込
[button x="40" y="609" graphic="button/button_load.png" enterimg="button/button_load2.png" enterse=btn_03.ogg clickse=btn_03.ogg role="load" ]
; 記録
[button x="148" y="609" graphic="button/button_save.png" enterimg="button/button_save2.png" enterse=btn_03.ogg clickse=btn_03.ogg role="save" ]
; 回想
[button x="256" y="609" graphic="button/button_cg.png" enterimg="button/button_cg2.png" enterse=btn_03.ogg clickse=btn_03.ogg storage="cg.ks" ]
; 設定
[button x="364" y="609" graphic="button/button_config.png" enterimg="button/button_config2.png" enterse=btn_03.ogg clickse=btn_03.ogg role="sleepgame" storage="config.ks" ]
; 終了
[button x="472" y="609" graphic="button/button_gameend.png" enterimg="button/button_gameend2.png" enterse=btn_03.ogg clickse=btn_03.ogg target="*gameend" ]

[mask_off time=500]
[s]

*gamestart
[mask time=2000]
[fadeoutbgm time=2000]
[jump storage="ev_a_01.ks"]

*gameend
[close ask=true]
