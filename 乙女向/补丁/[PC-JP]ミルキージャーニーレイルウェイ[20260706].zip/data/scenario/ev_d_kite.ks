﻿*start

;--------------------------------------------------------------------------------------------
;▼フルボイス初期設定▼

; ややこしいので該当箇所で記述

;--------------------------------------------------------------------------------------------
;****************************************
[set_b storage="train_08.jpg"]
;****************************************

[::]

[:princess:][puri_w kao=7 ]
[font color=0x4682b4]
（好了。时间快到了……）[rhp]
[resetfont]

[off_all]

[::]
早餐后，经常会被快斗指定时间叫出来。[rhr]
内容倒也没什么特别的，只是陪他聊天而已……[rhp]

;****************************************
[bg_rule storage="train_09.jpg" rule="002.png" time=1000]
;****************************************

[:princess:][puri_w kao=1 ]
「快斗，我来啦！」[rhp]

[off_all]
[:kite:][p_k_35][kite kao=11 ]
「欢迎。先坐下吧」[rhp]

[off_all]

[::]
我依言走向快斗所在的包厢座位，[rhr]
在他正对面坐下的我。[rhp]
我们定期……不如说几乎每天，[rhr]
都会按照快斗的提议举行所谓的「谈话会」。[rhp]
说是只要随口聊些什么，[rhr]
或许就能成为恢复记忆的契机。[rhp]
这个想法确实有道理，我也立即赞成快斗的提议。[rhp]
但最近总觉得气氛有些不对劲……[rhp]

[:princess:][puri_w kao=13 ]
「所以，今天谈话会的内容是……」[rhp]

[off_all]

[::]
还没等我说完，快斗就默不作声地站了起来。[rhr]
然后他又默不作声地，这次坐到了我旁边。[rhp]

;****************************************
;スチル
[still storage="cg/d_k_1.png" rule="021.png" width="1280" height="720" time=1000]
[cg storage="cg/d_k_1.png"]
;****************************************

好挤。不对，是好近。[rhp]

[:kite:]
「…………公主」[rhp]
[:kite:]
「想起来了吗？」[rhp]

[:princess:]
「嗯？」[rhp]

[:kite:]
「我在问你是不是想起来了」[rhp]

[:princess:]
[font color=0x4682b4]
（啊。是说记忆的事啊）[rhp]
[resetfont]
[:princess:]
「嗯……完全没。话说这就是开谈话会的目的吧」[rhp]

[:kite:]
「这样啊。真遗憾……明明只想让你记起我的事，却总是不顺利啊」[rhp]

[:princess:]
「那个……先不说那个，好像有点太近了」[rhp]

[:kite:]
「……………………」[rhp]

[:princess:]
「喂——。快斗——？有在听吗——？」[rhp]

[:kite:][p_k_01]
「听着」[rhp]
[:kite:]
「…………[player3b]」[rhp]

[:princess:]
「咦？杂音太大没听清」[rhp]

[:kite:]
「我知道你的名字。虽然杂音是南搞的鬼，[rhr]
_　但继续这样下去总担心会不小心被听到」[rhp]

[:princess:]
「哪有这种事啦……」[rhp]

[:kite:]
「[player3b]。喜欢」[rhp]

[:princess:]
「呜……啊、那个呢，说这种话太羞人了[rhr]
_　不要这么轻率地说出来啦，」[rhp]

[:kite:]
「请和我交往」[rhp]

[:princess:]
「所以说——！」[rhp]

[:kite:]
「好了。我稍微去趟多洛普那里」[rhp]

[:princess:]
「诶？为啥？」[rhp]

[:kite:][p_k_15]
「去报告目的地。我下一个志愿地点是，婚礼殿堂―――」[rhp]

[:princess:]
「肯定不行啊！！」[rhp]

[:kite:]
「开玩笑的」[rhp]

[:princess:]
「真是的～～～……！总觉得你性格变了呢快斗。[rhr]
_　自从那次大哭之后好像变得孩子气了！」[rhp]

[:kite:]
「…………。才没变呢」[rhp]
[:kite:]
「我的心意，从那时候起就一直」[rhp]

[:princess:]
「呜……」[rhp]

[:kite:]
「能活在精神年龄会成长的世界真是太好了。不然的话，[rhr]
_　我绝对会在青春期最懵懂的时候就死掉，根本不敢告白的」[rhp]

[:princess:]
「………………」[rhp]

[:kite:]
「啊、现在『那刚才的大哭是怎么回事』的表情。[rhr]
_　这种话很伤人的说」[rhp]

[:princess:]
「不是不是。没那回事啦。你太在意了」[rhp]

[:kite:]
「作为惩罚来陪我――――……」[rhp]
[:kite:]
「…………不、惩罚的话还是算了吧。如果不是两情相悦」[rhp]

[:princess:]
「～～～～……哦这样啊」[rhp]

[:kite:]
「就是啊。我可是会纠结这种细节的类型」[rhp]

[::]
最近的快斗、该怎么说呢……和他在一起实在招架不住。[rhp]
一找到机会就要告白，真是让人困扰。[rhr]
像呼吸般自然地说喜欢我，问我是否想起来了。[rhp]

[:princess:]
[font color=0x4682b4]
（要是能这么简单想起来就不用这么辛苦了……）[rhp]
[resetfont]

;****************************************
[still_end frame="win.png" storage="train_08.jpg" time=1000]
;****************************************

[::]
最近对于仍旧什么都没想起来这件事，甚至产生了些许罪恶感。[rhr]
为了快斗也好，想快点找回过去的记忆。[rhp]
想知晓他如此喜欢我的理由。[rhp]

;****************************************
[fbgm]
[set_xx graphic="rule/krke_k.png" storage="train_08.jpg"]
[bgm storage="bgm_05.ogg"]
;****************************************

那天夜里，我在房间里读着从博士那儿借来的书。[rhp]
倒不是为了寻找记忆的线索，[rhr]
纯粹是个人兴趣或者说最近着迷的事。[rhp]
从前的我似乎是个非常无知的女孩，[rhr]
别说回忆了，连基本常识都有所欠缺。[rhp]
比如在游乐园感到异常感动也是这样，[rhr]
面对大海和丛林时也获得了非凡的震撼。[rhp]
接触未知事物总是令人愉快。[rhr]
若能预先储备知识，定能让这段旅程更加尽兴。[rhp]
因此我向博士借阅了图鉴、游记等各类书籍，[rhr]
在房间里默默埋头研读。[rhp]

[:princess:][puri_w kao=13 hh=on ]
「过去的日本原来是这样的啊……真厉害。服装和发型都完全不同。[rhr]
_　这种时代的星球也能去吗？……咳咳」[rhp]
[:princess:]
「『敌在本能寺』！开玩笑的啦」[rhp]

[off_all]

[:yoru:][p_y_15][yoru kao=8 as=on ]
「摆着蠢脸的明智呢」[rhp]

[:princess:][puri_w kao=4 as=on ]
「哇！夜！？」[rhp]

[off_all]

[::]
背后突然传来夜的声音，吓得我几乎跳了起来。[rhr]
转头看见他正对着我露出无奈的表情。[rhp]

[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="293" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=2 as=off ss=off hh=on hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width="330" height="720" wait="true" zindex="1005" time=150]

[:princess:]
「真是的！　干嘛非要用魔法现身啊。[rhr]
_　都说过多少次要从门口敲门进来了！」[rhp]

[:yoru:][yoru kao=7 ]
「这样不好吗？我可是在体贴你们」[rhp]

[:princess:][puri_w kao=6 ]
「哈？哪里体贴了？」[rhp]

[:yoru:][p_y_20][yoru kao=5 ]
「我是担心撞见尴尬的场景啊」[rhp]
[:yoru:]
「魔太郎子告诉我，你和快斗关系变得很亲密」[rhp]

[:princess:][puri_w kao=8 hh=on ]
「魔太郎子！？胡乱说什……不对！[rhr]
_　虽然是说关系好但又不是在交往，」[rhp]

[:yoru:][yoru kao=7 ]
「我不在意这种程度的差异。[rhr]
_　只是始终觉得不太愉快」[rhp]

[:princess:][puri_w kao=13 as=on ]
「哼……哼～？　夜你也会嫉妒啊」[rhp]

[:yoru:][yoru kao=6 ]
「与其说是嫉妒，不如说是恶心。极端来说这条铁道就是我的体内。[rhr]
_　对我来说简直像寄生虫擅自开始交配」[rhp]

[:princess:][puri_w kao=2 ]
「过分！！　哪有这种说法的！」[rhp]

[:yoru:][yoru kao=0 ]
「不想被说就赶快滚蛋。[rhr]
_　你们那个故事会的效果也该被质疑了吧」[rhp]

[:princess:][puri_w kao=7 ]
「原来你知道故事会的事……[rhr]
_　我当然也想早点找回记忆啊」[rhp]
[:princess:]
「但根本找不到线索嘛。可以说完全无计可施」[rhp]

[:yoru:][p_y_26][yoru kao=6 ]
「今天不是来谈这个的」[rhp]

[:princess:][puri_w kao=8 ]
「真是的。都没在听……」[rhp]

;****************************************
;****************************************
;****************************************
;****************************************

;→【共通ルートへ】
[jump storage="ev_d.ks" target="*tutti"]

;****************************************
;****************************************
;****************************************
;****************************************

*start2

[off_all]

[:kite:][kite kao=6 ]
「…………………………」[rhp]

[off_all]

[::]
…………背后传来恐怖的沉默压力。[rhr]
包厢座位里的快斗正朝这边投来湿漉漉的视线。[rhp]

[chara_part name="drop" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=3 as=on ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:kite:]
「真好啊～。看来关系很融洽呢」[rhp]

[:princess:][puri_w kao=8 ]
「喂胡说什么呢。来，快斗也一起打扫」[rhp]

[:kite:][kite kao=2 ]
「不要。麻烦死了」[rhp]

[:drop:][drop kao=0 as=on ]
「那、那个……在生气吗？」[rhp]

[:kite:][p_k_11][kite kao=12 ]
「不必了」[rhp]

[off_all]

[::]
不，这绝对是在生气。因为继哈蒂君他们之后又要帮多洛普打扫[rhr]
自己的优先级被降低了。[rhp]

[:princess:][puri_w kao=6 ]
「小孩子吗……」[rhp]

[:kite:][kite kao=5 ]
「喂、刚才说坏话了吧」[rhp]

[:princess:][puri_w kao=3 ]
「顺风耳！」[rhp]

[off_all]

[:drop:][drop kao=4 ]
[font color=0x4682b4]
（糟了～～……！　快斗先生对公主有意思的！[rhr]
_　然而我却完全没注意到这点，还和公主聊得热火朝天……！！）[rhp]
[resetfont]

[off_all]

[chara_part name="drop" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:drop:][p_d_04]
「啊、那个！快斗先生！」[rhp]

[:kite:][p_k_36][kite kao=0 ]
「干嘛」[rhp]

[:drop:][drop kao=13 hh=on ]
「要、要不要你也一起来打扫？[rhr]
_　公主够不着的地方，如果是你的话应该能搞定吧？」[rhp]
「而且公主也是，和你聊天会更开心吧！[rhr]
_　对吧，公主你说是不是？」[rhp]

[:princess:][puri_w kao=1 ]
「嗯、嗯，算是吧。比起两个人，人多效率更高」[rhp]

[off_all]

[chara_part name="kite" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=14 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width="330" height="720" wait="true" zindex="1005" time=150]

[:princess:]
「你看你看，这不挺好的嘛快斗。一起加油吧」[rhp]

[:kite:][kite kao=5 ]
「～～～……真拿你没办法。给我分轻松点的活」[rhp]

[off_all]

[chara_part name="drop" body=base kao=13 as=off ss=off hh=on hr=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=1 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width="330" height="720" wait="true" zindex="1005" time=150]

[:drop:]
「那当然！[rhr]
_　会根据快斗先生的工作能力来分配任务的！」[rhp]

[:kite:][p_k_06][kite kao=13 ]
「拜托了～～」[rhp]

[:princess:][puri_w kao=6 as=on ]
「你就不想在喜欢的人面前耍个帅什么的吗……」[rhp]

[:kite:][kite kao=5 ]
「一码归一码。努力干活不符合我的性格」[rhp]

[:princess:][puri_w kao=3 ]
「真是的。不过你向来都这样啦」[rhp]

[:drop:][p_d_02][drop kao=13 ]
「那么各位，为了落合一起努力吧！」[rhp]

[:2nin:]
「哦！」[rhr]
「哦——」[rhp]

;****************************************
[set_xx graphic="rule/krke_k.png" storage="train_02.jpg"]
;****************************************

[::]
完成基本清扫工作后，我们决定稍作休息。[rhp]
我和快斗坐在包厢座位里，时而舒展身体时而互相轻捶肩膀，[rhr]
多洛普端着放有3个杯子的托盘走了过来。[rhp]

[chara_part name="drop" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=1 as=off ss=off hh=on hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width="330" height="720" wait="true" zindex="1005" time=150]

[:drop:][p_d_16]
「辛苦了，两位。我泡了可可，要喝吗？」[rhp]

[:princess:][puri_w kao=13 hh=on ]
「谢谢！正好想喝点什么」[rhp]

[:drop:[p_d_02][drop kao=5 ]
「那太好了。来，快斗也请用」[rhp]

[:kite:][p_k_07][kite kao=1 ]
「3Q」[rhp]

[off_all]

[::]
将杯子递给我们后，多洛普在我斜对面坐了下来。[rhp]
那个多洛普，正好好地坐在座位上休息。[rhr]
一边小口小口地抿着饮料，一边深切地想着：这还真是罕见的景象啊。[rhp]

[chara_part name="drop" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=4 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width="330" height="720" wait="true" zindex="1005" time=150]

[:princess:]
「多洛普，该不会其实很累吧？」[rhp]

[:drop:][p_d_19][drop kao=13 ]
「咦……为什么这么说？」[rhp]

[:princess:][puri_w kao=3 ]
「因为你平时都不会在显眼的地方休息啊。[rhr]
_　不如说这还是我第一次看到你休息的样子」[rhp]

[:drop:][p_d_30][drop kao=1 hh=on as=on ]
「啊……啊─。被你这么一说……真是难为情」[rhp]

[:princess:][puri_w kao=13 hh=on ]
「反而很开心呢。感觉像是被你信任着」[rhp]
[:princess:]
「可可你也特意亲手制作真是感谢呢。[rhr]
_　嫌麻烦的话明明用魔法也可以的」[rhp]

[:drop:][drop kao=14 ]
「这种程度就用魔法的话，会忘记魔法的可贵之处。[rhr]
_　力所能及的事应该尽量亲手完成」[rhp]

[:princess:][puri_w kao=1 ]
「呵呵，不愧是多洛普啊」[rhp]

[off_all]

[:kite:][kite kao=6 ]
「……………………」[rhp]

[:drop:][drop kao=4 as=on ]
「！！」[rhr]
[font color=0x4682b4]
（糟了……！我居然又在快斗先生面前……！）[rhp]
[resetfont]

[:kite:][p_k_23][kite kao=7 ]
「………………多洛普会累的原因，我明白了」[rhp]
[:kite:]
「是在为落合的事担心吧」[rhp]

[:drop:][drop kao=4 ]
「…………！」[rhp]

[:princess:][puri_w kao=3 ]
「是这样吗？打扫时我可是相当认真的，[rhr]
_　还有其他什么值得在意的事吗……？」[rhp]

[:drop:][p_d_22][drop kao=8 as=on ]
「没……没有。并不是那样的事。[rhr]
_　只是久违的大扫除让人感到疲惫。仅此而已」[rhp]

[:kite:][kite kao=0 ]
「不用顾虑那么多。[rhr]
_　有些事只要说出来就会轻松很多吧」[rhp]

[:princess:][puri_w kao=13 ]
「是啊多洛普。我也可以当倾诉对象。[rhr]
_　光是看到多洛普在人前勉强自己休息的样子，就让人觉得担心呢」[rhp]

[:drop:][drop kao=1 ]
「两个人……谢谢你们」[rhp]
[:drop:]
「…………那么，可以稍微占用你们一点时间吗」[rhp]

[:princess:][puri_w kao=5 ]
「当然！」[rhp]

[:kite:][p_k_15][kite kao=1 ]
「别说稍微这种见外的话」[rhp]

[:drop:][p_d_16][drop kao=7 ]
「那么……这样吧。难得有机会我们换个地方」[rhp]

[off_all]

[::]
说着"这边请"，多洛普站起身来，[rhr]
径直沿着通道向门的方向走去。[rhp]
我和快斗对视一眼，虽对他的行为心存疑惑，[rhr]
还是决定起身跟随他的背影。[rhp]

;****************************************
[set_xx graphic="rule/krke_k.png" storage="train_10.jpg"]
; 夜フィルター
[filter layer="1" brightness="60"]
;****************************************

;車体の上

被多洛普带来的地点，竟是银河铁道的车顶之上。[rhp]
无视无重力与真空的物理法则，伫立于平日里隔窗眺望的银河之中——[rhr]
这堪称迄今为止最超乎寻常的特别情境。[rhp]
毫无阻隔的美丽景色，让我的心比任何时候都雀跃不已。[rhp]

[:princess:][puri_w kao=14 hh=on ]
「好厉害……！原来这里能爬上来啊！」[rhp]

[:drop:][p_d_02][drop kao=5 ]
「是的。平时因危险不对外开放，[rhr]
_　请注意别摔下去」[rhp]

[:princess:][puri_w kao=1 hh=on ]
「嘿嘿，没关系的！」[rhp]

[off_all]

[:kite:][p_k_27][kite kao=5 ]
「就算掉下去也没事。[rhr]
_　不管多重……我都会支撑住你的全部」[rhp]

[:princess:][puri_w kao=6 as=on ]
「你以为最后耍帅说什么都可以是吧……」[rhp]

[off_all]

[::]
快斗在这种场合下还是老样子爱开玩笑。[rhr]
再说下去他更要得意忘形了，就此打住吧。[rhp]
―――我微微仰望着天空，深深地吸了一口气。[rhr]
想要将这景象与感动牢牢铭刻在脑海里。[rhp]

[:princess:][puri_w kao=4 hh=on ]
[font color=0x4682b4]
「好壮观的景色……！目光所及全是星空」[rhp]
[resetfont]

[::]
舒爽的晚风拂过。虽然不确定是否能称之为夜风，[rhr]
轻抚脸颊的凉爽微风仿佛在治愈疲惫的身躯[rhp]

[:princess:][puri_w kao=3 ]
「所以？在这种地方要说的烦恼是？」[rhp]

[:drop:][p_d_17][drop kao=13 ]
「那个……、……其实，我并没有烦恼」[rhp]

[:princess:][puri_w kao=6 as=on ]
「哎，可是」[rhp]

[:kite:][kite kao=8 ]
「多洛普。事到如今还有隐瞒的必要吗」[rhp]

[:drop:][drop kao=7 as=on ]
「不是隐瞒，是真的没有什么烦恼[rhp]
[:drop:]
「只是……迟迟下不了决心」[rhp]

[:kite:][kite kao=3 ]
「决心？」[rhp]

[:drop:][drop kao=12 ]
「是的。关于落合要来的事。[rhr]
_　下次他来的时候，肯定会―――……」[rhp]

[:kite:][kite kao=6 ]
「急死人了。那为啥带我到这种地方啊」[rhp]

[:drop:][drop kao=13 ]
「我是想向关照我的两位表达谢意，才带你们看这个景色的。[rhr]
_　因为我没有任何能祝福你们的方法」[rhp]

[:princess:][puri_w kao=4 hh=on ]
「祝、祝福什么的。我们还没到那种关系啦」[rhp]

[:kite:][p_k_07][kite kao=5 hh=on ]
「万分感谢」[rhp]

[:princess:][puri_w kao=2 hh=on ]
「喂！」[rhp]

[:drop:][p_d_07][drop kao=13 ]
「呵呵……看着快斗先生和公主交谈的样子，[rhr]
_　连我这里都觉得开心起来了呢」[rhp]
[:drop:]
「…………是啊。那真是段非常快乐的时光」[rhp]

[:princess:][puri_w kao=3 ]
「……多洛普？」[rhp]

[off_all]

[:drop:][drop kao=8 ]
「迄今为止的旅程，我也非常愉快。[rhr]
_　为了让大家度过幸福日常的协助工作非常充实」[rhp]
[:drop:]
「但是公主……自从你失去记忆来到这里后的日子，[rhr]
_  日子变得比以往更加忙碌充实」[rhp]
[:drop:]
「这一定是迄今为止最热闹欢快的旅途。[rhr]
_　谢谢你，公主。让我看见了和你相同的风景」[rhp]

[off_all]

[::]
多洛普平静微笑的脸上，似乎渗出了一丝寂寞。[rhr]
我内心猛然一惊。这简直就像离别的话语。[rhp]

;****************************************
[fbgm]
[bg storage="black.jpg" time=500]
;****************************************

――――就在这时。[rhp]

[se storage="se2_08.ogg"]

唯独在这个地方，无法预料的异常水温打断了我的思考。[rhp]

;****************************************
[still storage="cg/d_d1_1.png" rule="007.png" width="1280" height="720" time=1000]
;****************************************

[bgm storage="bgm_10.ogg"]

[:drop:]
「……………………诶」[rhp]

[:princess:]
「……！？」[rhp]

[:kite:]
「嗯……」[rhp]

[::]
多洛普的身体，正在变得透明。[rhp]
不，…………正被抹去存在。[rhp]
仿佛与夜空同化般，透过他的身躯，[rhr]
能望见对面的银河。[rhp]

[:drop:][p_d_14]
「………………原来如此。是这样啊」[rhp]

[:princess:]
「多洛普！你、你没事吧！？到底发生了什么―――」[rhp]

[:drop:]
「没、没事的公主。请冷静」[rhp]

[:princess:]
「这让人怎么冷静啊！你这种情况，」[rhp]

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
;ソラ ※後半でsoraに変わる
[voconfig sebuf=1 name=unknown vostorage="sora/full/{number}.ogg" number=38]
[vostart]
;--------------------------------------------------------------------------------------------

[:unknown:]
「吵死了」[rhp]

;****************************************
[still_end frame="win.png" storage="black.jpg" time=500]
;****************************************

[::]
突然响起的低沉声音。[rhp]

[:unknown:]
「……哇靠，什么情况」[rhp]
[:unknown:]
「虽说状态不佳，这也太离谱了。工作太敷衍……[rhr]
_　差点就要消失了」[rhp]

;****************************************
[bg storage="train_10.jpg" time=1000]
;****************************************

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:princess:][puri_w kao=4 ]
「诶……」[rhp]

[off_all]

[:kite:][kite kao=2 ]
「呃……！你这家伙……」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:unknown:][sora kao=1 ]
「…………算了，无所谓」[rhp]

[off_all]

;魔法
[bg_magic_c]

[::]
他话音未落打了个响指，瞬时黑暗吞噬了他的周身。[rhr]
就在这刹那，几近透明的多洛普完全消失了踪影。[rhp]
面对过于突然的事件，我瞪大眼睛哑然失声。[rhp]

[:unknown:][sora kao=5 ]
「哼，也就这种程度吧。不愧是老子，干什么都手到擒来。[rhr]
_　只有认真这个优点的『前』多洛普可做不到这种程度呢」[rhp]

[:princess:][puri_w kao=3 ]
「你、是谁……！？」[rhp]

[:unknown:][sora kao=6 ]
「哈？」[rhp]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

[off_all]

[::]
带着疑惑的脸转向这边。[rhr]
多洛普绝不会露出那种表情。[rhp]

[chara_part name="sora" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=3 as=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width="330" height="720" wait="true" zindex="1005" time=150]

[:princess:]
「你对多洛普做了什么？　你到底是——」[rhp]

[off_all]

[:kite:][p_k_35][kite kao=0 ]
「好久不见。宙」[rhp]

[off_all]

[:princess:][puri_w kao=4 ]
「…………诶？」[rhp]

[:unknown:][sora kao=0 ]
「不记得了吗。快斗最初确实是这样叫我的」[rhp]
[:unknown:]
「『你这家伙，是宙吧』这样」[rhp]

[:princess:][puri_w kao=2 ]
「难、难道说你是……」[rhp]

[:unknown:][sora kao=5 ]
「落合啊。……按照约定回来了」[rhp]

[:princess:][puri_w kao=3 ]
「―――！」[rhp]

[off_all]

[chara_part name="kite" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="sora" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:kite:]
「个头蹿得真夸张。呃……现在18岁左右？」[rhp]

[:sora:][sora kao=1 ]
「明年春天就是大学生了」[rhp]
[:sora:]
「…………这种情况下还能游刃有余啊」[rhp]

[:kite:][kite kao=2 as=on ]
「其实我也挺慌的。不玩过家家游戏了？」[rhp]

[:sora:][sora kao=6 ]
「又不是自愿的打扮。那是夜擅自把我——」[rhp]

[off_all]

[:princess:][puri_w kao=2 ]
「多洛普呢！？」[rhp]

[:sora:][p_so_19][sora kao=2 ]
「！」[rhp]

[:princess:][puri_w kao=2 ]
「先解释多洛普消失的事！[rhr]
_　身体突然变得透明，然后你就突然——」[rhp]

[:sora:][sora kao=6 ]
「那家伙已经不在了」[rhp]

[:princess:][puri_w kao=0 as=on ]
「啊……？不在了是说……」[rhp]

[:sora:][p_so_31][sora kao=5 ]
「作为我留在这里的代价，让他消失了。[rhr]
_　从现在起这条铁道的乘务长不是多洛普而是本大爷」[rhp]

[:princess:][puri_w kao=8 ]
「…………」[rhp]

[:kite:][kite kao=3 as=on ]
「……公主？」[rhp]

[off_all]

[::]
以胜者姿态自居的落合君……如此自报家门的男声。[rhr]
一反常态地显得焦躁的快斗的声音。[rhp]
所有事物都从脑海中剥离而去。[rhp]
――――多洛普，消失了？[rhp]

[:princess:]
「…………」[rhp]

;倒れる音
[se storage="body_08.ogg"]

[:kite:][p_k_13][kite kao=3 ]
「等……！喂、[player3b]！？」[rhp]

[off_all]

[::]
仿佛全身力气都被抽走，我当场倒下了。[rhr]
混乱与冲击让思维无法跟上，甚至感到恶心。[rhp]
头痛。心苦。[rhr]
甚至觉得干脆睡着更轻松。[rhp]

;****************************************
[bg storage="black.jpg" time=1000]
;****************************************

……就这么办吧。[rhr]
醒来之后肯定，一切都会化为梦境――――……[rhp]

;****************************************
;****************************************
;****************************************

[jump storage="ev_d.ks" target="*tutti4"]

;****************************************
;****************************************
;****************************************

*start3

;****************************************
[fbgm]
[set_b storage="train_08.jpg"]
[bgm storage="bgm_07.ogg"]
;****************************************

自那之后夜就失去了踪影，落合君说要去和大家[rhr]
打声招呼，于是房间里只剩我一人。[rhp]
仅仅今天一天就发生了太多事情，而其中大半[rhr]
都是令人难以轻易接受的状况，脑子简直快要崩溃了。[rhp]
…………快斗，他应该很担心吧。[rhr]
虽然想主动去告诉他我没事，但总觉得心情沉重。[rhp]
说起来快斗对于落合君那时的姿态，[rhr]
_　似乎知道些什么。[rhp]
等稍微恢复些精神，就去向快斗问问现在到底是什么状况吧……[rhp]

[se storage="door_13.ogg"]

[:kite:][p_k_35]
「[player3b]，醒着吗？」[rhp]

[:princess:][puri_w kao=0 ]
「……！嗯」[rhp]

[off_all]

[::]
确认我的应答后房门被轻轻推开。[rhr]
现身的快斗担心地皱起眉头，来到坐在床铺边的我身旁。[rhp]

[:kite:][kite kao=1 ]
「早啊。……身体还好吗？」[rhp]

[:princess:][puri_w kao=3 as=on ]
「已经没事了。对不起让你担心了……[rhr]
_　只是稍微有点惊慌失措而已」[rhp]

[:kite:][p_k_34][kite kao=8 ]
「………………抱歉。你睡着的时候，我没能陪在身边」[rhp]

[:princess:][puri_w kao=14 ]
「不会啦。夜说他把人都支开了」[rhp]

[:kite:][kite kao=3 ]
「话是这么说……但有落合在场。[rhr]
_　总觉得有点束手束脚」[rhp]

[:princess:][puri_w kao=3 ]
「……快斗君知道落合君那个状态的原因吧。[rhr]
_　难道你和他关系很好吗？就是……在他生前的时候」[rhp]

[:kite:][p_k_22][kite kao=7 ]
「………………。算是吧。关系还算不错。[rhr]
_　可能因为都是别扭鬼所以比较合得来」[rhp]
[:kite:]
「不过这段关系是[player3b]为我缔结的哦」[rhp]

[:princess:][puri_w kao=8 as=on ]
「我……缔结的……」[rhp]

[:kite:][p_k_28][kite kao=6 ]
「不用勉强自己去回忆啦。……比起这个」[rhp]
[:kite:]
「第一次来的时候那家伙说过‘我是活着来到这里的』。[rhr]
_　但这次却说多洛普的职责转移给了自己……之类的话对吧」[rhp]

[:princess:][puri_w kao=8 ]
「嗯。这怎么了？[rhp]

[:kite:][kite kao=3 as=on ]
「没什么。……只是有点受打击」[rhp]
[:kite:]
「因为这意味着，宙真的已经死了」[rhp]

[:princess:][puri_w kao=4 as=on ]
「……！？为、为什么这么说？」[rhp]

[:kite:][kite kao=0 ]
「啊——那个……关于其中的机理？大概[rhr]
_　我倒是没什么可教你的。不过那个就先放一边吧」[rhp]
[:kite:]
「……我挺在意的啊」[rhp]

[:princess:][puri_w kao=3 ]
「什么风雅？」[rhp]

[:kite:][kite kao=8 as=on ]
「以宙那谨慎的性格来看，那家伙应该不太可能[rhr]
_　死于意外事故之类。更何况还是个天生的健康优等生」[rhp]
[:kite:]
「也就是说……我觉得那家伙的死因是自杀」[rhp]
[:kite:]
「但这样不太奇怪吗？　[player3b]如果打算追随（她的脚步），[rhr]
_　为什么第一次不直接那么做呢」[rhp]

[:princess:][puri_w kao=6 ]
「呜、嗯……虽然不太明白……」[rhp]

[:kite:][kite kao=3 ]
「但无论如何最糟的情况是确定的。[rhr]
_　好友去世确实挺悲伤的……但更让人头疼」[rhp]
[:kite:]
「……偏偏还得打倒那个宙」[rhp]

[:princess:][puri_w kao=17 as=on ]
「什么意思？」[rhp]

[:kite:][kite kao=2 ]
「什么什么意思，你啊……清楚自己的立场吗？[rhr]
_　我是因为喜欢你才告白的，但并没在交往」[rhp]
[:kite:]
「总之我和宙是争夺公主的情敌关系。[rhr]
_　对手太强会让人泄气啊……唉」[rhp]

[:princess:][puri_w kao=6 as=on ]
「别、别又说傻话！」[rhp]

[:kite:][p_k_24][kite kao=7 ]
「不，相当认真。我也好……那家伙也好」[rhp]
[:kite:]
「你因为多洛普消失而生气，但宙那家伙也是会胡闹的[rhr]
_　我不认为他是出于恶意才选择了这个结果」[rhp]
[:kite:]
「即使牺牲多洛普也要选择在这里活下去。[rhr]
_　因为宙[player3b]曾如此喜爱。字面意义上，爱到愿意赴死」[rhp]
[:kite:]
「我也曾是世上最[player3b]的爱好者……但还不至于赌上性命。[rhr]
_　毕竟我的命没那么值钱，也没那么多时间可浪费」[rhp]
[:kite:]
「…………唉呀唉呀。这下真不知道会变成怎样」[rhp]

[:princess:][puri_w kao=2 ]
「可、可就算你这么说。我也不能原谅多洛普啊」[rhp]
[:princess:]
「我们接下来该怎么办？[rhr]
_　要我认定落合君就是多洛普这种事，我实在……」[rhp]

[off_all]

[:sora:][sora kao=5 ]
「我会让你信的，所以别担心」[rhp]

[:princess:][puri_w kao=6 ]
「！！落合君……！」[rhp]

[:sora:][sora kao=1 ]
「当然。反正那家伙现在已经消气了。[rhr]
_　更何况我也不能放任有人抢先偷跑」[rhp]

[off_all]

[chara_part name="kite" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="sora" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:kite:][p_k_26][kite kao=6 ]
「干劲十足嘛。啊~好可怕」[rhp]

[:sora:]
「你比以前还要迟钝啊……这种状况下真是了不起」[rhp]
[:sora:][sora kao=13 ]
「公主应该不记得了，[rhr]
_　这家伙生前可是相当难对付的―――」[rhp]

[off_all]

[:princess:][puri_w kao=3 ]
「………………」[rhp]

[:sora:][sora kao=6 ]
「倒是听人说话啊……你究竟要闹别扭到什么时候」[rhp]
[:sora:]
「公主。我的事你应该已经从快斗那里听说了吧？[rhr]
_　差不多该放弃对多洛普的执念了」[rhp]
[:sora:]
「从今天起住在这里的是我。列车长也是我。其他人都已经同意了，」[rhp]

[:princess:][puri_w kao=6 ]
「我不同意。……夜说过会把多洛普恢复原样的。[rhr]
_　要负责任的话，落合君你去拜托夜不行吗？」[rhp]

[:sora:][p_so_09][sora kao=0 ]
「说什么胡话。开什么玩笑！凭什么我要……」[rhp]

[:princess:][puri_w kao=2 ]
「那我不管了！」[rhp]

[:sora:][p_so_19][sora kao=2 ]
「哈！？我说啊……！」[rhp]

[off_all]

[chara_part name="kite" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="sora" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:kite:]
「宙，你下跪谢罪过吗？」[rhp]

[:sora:][p_so_25][sora kao=6 ]
「怎么可能！凭什么我要向夜低头认错」[rhp]
[:sora:]
「本来我就有权待在这里。[rhr]
_　无论公主说什么，我都不会离开也不会道歉！」[rhp]

[off_all]

[:princess:][puri_w kao=13 ]
「快斗！我们去博士那里借书吧。已经看完手头的了」[rhp]

[:kite:][p_k_27][kite kao=1 ]
「是是」[rhp]

[off_all]

[:sora:][sora kao=3 as=on ]
「喂等等！话还没说……」[rhp]

[:princess:][puri_w kao=6 ]
「咻——」[rhp]

[:sora:][sora kao=2 ]
「啊啊啊……！！」[rhp]

[off_all]

[chara_part name="kite" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="sora" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sora:]
「快斗！这家伙又在犯倔。[rhr]
_　你也来说他几……」[rhp]

[:kite:][kite kao=13 ]
「噗嗤」[rhp]

[:sora:][sora kao=2 as=on ]
「！！！！！　你笑什么！？[rhr]
_　看我被这么轻贱就这么好，」[rhp]

[off_all]

[:kite:][kite kao=0 ]
「那再见咯」[rhp]

[off_all]

[se storage="door_10.ogg"]

[:sora:][p_so_21]
「等……」[rhp]

[:sora:][sora kao=6 as=on ss=on ]
「……好啊。既然用这种态度，那我可要……」[rhp]

[off_all]

;****************************************
[fbgm]
[set_b storage="train_01.jpg"]
[bgm storage="bgm_01.ogg"]
;****************************************

[::]
自从多洛普的内芯变成落合君已经过去数日。[rhp]
他对我们的劝说依然置若罔闻，[rhr]
似乎正悠然自得地享受着旅途。[rhp]
若是完全放下多洛普的工作倒还能找到破绽，[rhr]
但他却以和多洛普完全相同的方式，出色地完成了所有工作。[rhp]
而且看起来...比多洛普还要乐在其中。[rhp]
大家也渐渐适应了这种状况，[rhr]
看起来正在逐步接纳他的存在。[rhp]
现在的落合君和多洛普，[rhr]
即便面部构造相同，内在却完全是不同的人。[rhp]
即便如此，这样的事……[rhp]

[:sora:][sora kao=0 ]
「哈啊～～……」[rhp]

[:kite:][p_k_30][kite kao=5 ]
「真顽固呢。宙这家伙意外地不轻易放弃啊」[rhp]

[:sora:][p_so_29][sora kao=8 ]
「吵死了。……一半是想继续留在这里的心情，[rhr]
_　另一半是死也不愿向你们屈服的心情」[rhp]

[off_all]

[chara_part name="sora" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=2 as=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width="330" height="720" wait="true" zindex="1005" time=150]

[:princess:]
「如果你没有消除多洛普的话，原本我们会更欢迎你的」[rhp]

[:sora:][p_so_19][sora kao=0 ]
「多洛普就是我。既然有真货存在，伪物就没有必要了吧」[rhp]

[:princess:][puri_w kao=13 ]
「只要不把多洛普恢复原状，我们就无法欢迎落合君」[rhp]

[:sora:][p_so_25][sora kao=3 ]
「关于多洛普的事先放一边 那根本不可能吧。[rhr]
_　我已经是个死人了。你们不得不把我当同伴啊」[rhp]

[off_all]

[:kite:][kite kao=8 ]
「……………………」[rhp]

[off_all]

[chara_part name="kite" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="sora" body=base kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sora:][p_so_30]
「真是讨厌的眼神。有意见就用嘴巴说出来」[rhp]

[:kite:][p_k_12][kite kao=6 ]
「没有人会不为朋友的死感到难受。[rhr]
_　……这种事，我以为宙最清楚了」[rhp]

[:sora:][sora kao=5 ]
「…………啊啊。讨厌到极点。但现在已经不用担心了」[rhp]
[:sora:]
「我再也不会[player2]和你们分开了」[rhp]

[:kite:][p_k_32][kite kao=5]
「这不是挺帅气的嘛……」[rhp]

[off_all]

[chara_part name="kite" body=base kao=4 as=on ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=2 as=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width="330" height="720" wait="true" zindex="1005" time=150]

[:princess:]
「喂！现在佩服有什么用」[rhp]

[:kite:][p_k_18][kite kao=6 as=on ]
「开玩笑的。这个固执鬼到底怎么回事嘛」[rhp]

[off_all]

[chara_part name="kite" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="sora" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sora:][p_so_36]
「既然这么说要不要玩个游戏？[rhr]
_　你以前很擅长的吧。我也从你那儿学了不少」[rhp]

[:kite:][kite kao=2 ]
「游戏？」[rhp]

[off_all]

[chara_part name="sora" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=6 as=on ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width="330" height="720" wait="true" zindex="1005" time=150]

[:princess:]
「别犯傻了。那种事根本毫无意义……」[rhp]

[:sora:][p_so_01][sora kao=13 ]
「如果我输了就去说服夜[rhr]
_　想办法帮你复原多洛普」[rhp]

[:princess:][puri_w kao=4 as=on ]
「……！」[rhp]

[off_all]

[chara_part name="kite" body=base kao=6 as=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="sora" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:kite:][p_k_21]
「当真？」[rhp]

[:sora:][sora kao=6 ]
「啊啊。反正多洛普增加了对我又没坏处。[rhr]
_　只要忍忍我自己心里那点不适就行了」[rhp]

[:kite:][kite kao=7 ]
「……条件不赖。不，简直好过头了。[rhr]
_　可玩这个游戏对宙有什么好处？」[rhp]

[:sora:][p_so_16][sora kao=5 ]
「不是为了好处。[rhr]
_　我们是为了承受坏处才比试的」[rhp]
[:sora:]
「输的人离开这条铁道。如何？」[rhp]

[:kite:][kite kao=2 ]
「――――！」[rhp]

[:sora:][sora kao=1 ]
「坦白说，我……不。我『也』喜欢公主。[rhr]
_　……我觉得光这个理由就足够了」[rhp]

[:kite:][p_k_12][kite kao=3 as=on ]
「不打算靠自己的力量让她回心转意吗……[rhr]
_　长得挺帅却意外地不受欢迎呢」[rhp]
[:kite:]
「嘛不过无所谓，这场比试我接下了」[rhp]

[off_all]

[:princess:][puri_w kao=2 ]
「！！　等、等等！　别擅自决定——」[rhp]

[off_all]

[chara_part name="kite" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="sora" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sora:]
「可惜啊。其实我也想和你继续旅行。[rhr]
_　无论谁胜谁负，这个愿望都无法实现了」[rhp]

[:kite:][p_k_29][kite kao=0 ]
「要是我赢了就用特赦权把你留在这里。[rhr]
_　不过，[player3b]的事情你必须放弃」[rhp]

[:sora:][p_so_24][sora kao=13 ]
「那我也这么做吧」[rhp]

[:princess:][puri_w kao=3 as=on ]
「够了！　你们两个都适可而止。[rhr]
_ 我绝不同意用游戏来决定这么重要的事！」[rhp]

[:kite:][kite kao=1 ]
「我会赢的所以没问题。[rhr]
_ 多洛普的事我绝对会亲手解决」[rhp]

[:princess:][puri_w kao=8 ]
「可、可是……！」[rhp]

[off_all]

[:kite:][kite kao=5 ]
「不会输的。绝对」[rhp]

[off_all]

[::]
为什么快斗能如此自信呢。[rhp]
来到这个世界后，我几乎都是和快斗共同度过的。[rhr]
虽然有时会被他弄得团团转，但快乐的时光终究更多。[rhp]
『不会用赦免权消灭对手』这种口头约定谁都能说。[rhr]
……快斗就没有丝毫留恋吗？[rhp]

[chara_part name="kite" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="sora" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]


[:sora:]
「你可别因为输了就在事后找茬」[rhp]

[:kite:][kite kao=5 ]
「你才该注意。快输的时候就强制切断[rhr]
_　宙那边更常干这种事吧」[rhp]

[:sora:][p_so_26][sora kao=2 ]
「那还不是因为你老是犯规啊！」[rhp]

[off_all]

[::]
两人进行着令人摸不着头脑的对话。[rhr]
若没有先前的争吵，怎么看都像对要好的朋友。[rhp]
回过神时，我的目光已落在快斗的侧脸上。[rhp]
根本无法想象他会消失。[rhr]
若是没有快斗，我连在这里的生活恐怕也……[rhp]

[:princess:]
「………………」[rhp]

[::]
当思考着「如果」时，终于看清了自己的心意。[rhr]
这份觉悟来得太迟。对他的答案，其实一直都在这里。[rhp]
我或许仍未成为快斗眼中看到的那个『　　　』。[rhr]
即便如此，我也无法想象没有快斗的日子。[rhp]

;****************************************
[fbgm]
[set_xx graphic="rule/krke_k.png" storage="train_11.jpg"]
; 夜フィルター
[filter layer="1" brightness="60"]
[bgm storage="bgm_37.ogg"]
;****************************************
;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼

;カイト
[voconfig sebuf=1 name=kite vostorage="kite/full/{number}.ogg" number=217]
;ダークネブラ
[voconfig sebuf=1 name=hakase vostorage="hakase/full/{number}.ogg" number=59]
;ヌシ
[voconfig sebuf=1 name=nusi vostorage="nusi/full/{number}.ogg" number=82]
;魔太郎子
[voconfig sebuf=1 name=mata vostorage="mata/full/{number}.ogg" number=85]
;ゴンザレス一億世
[voconfig sebuf=1 name=gon vostorage="gon/full/{number}.ogg" number=69]
;一近
[voconfig sebuf=1 name=kazu vostorage="kazu/full/{number}.ogg" number=4]
;ソラ再設定
[voconfig sebuf=1 name=sora vostorage="sora/full/{number}.ogg" number=83]

[vostart]
;--------------------------------------------------------------------------------------------

[:darknebula:]
「于是我们隆重开场[rhr]
『第一届・公主的男友是谁！？居住权争夺大赛』！！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[chara_part name="sausu" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sausu:]
「我是实况解说南」[rhp]

[:yoru:]
「糠星夜」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:darknebula:][hakase kao=1]
「将由以上两位解说为您全程呈现」[rhp]
[:darknebula:]
「对了糠星夜先生。上次担任解说的米卡小姐[rhr]
_　今天似乎没有出席？」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[chara_part name="sausu" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:yoru:]
「似乎很不愿意坐在南旁边呢。那也没办法」[rhp]

[:sausu:]
「为什么这么讨厌他啊……」[rhp]

[:yoru:]
「扪心自问吧。考虑到你的所作所为 就该明白」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:darknebula:]
「看来会拖很久 就在这里转播吧。佩奇小姐~」[rhp]

[::]
用熟练的话术制服了两人，从我们所在的最前车厢[rhr]
将对话接力棒递给排在最后的佩奇的博士。[rhp]
虽同属首节车厢一侧，但我所在的位子与广播席(?)之间仍有相当距离，[rhr]
无论从哪个距离都能清晰可见的巨大显示屏悬浮在空中。[rhp]
少许杂音过后，从那台魔法显示器中，传来了对面的景象和声音。[rhp]

;****************************************
[set_xx graphic="rule/krke_k.png" storage="train_10.jpg" time=300]
; 夜フィルター
[filter layer="1" brightness="60"]
;****************************************

[:gonzalez:][gon kao=6 as=on ]
「…………………………」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:vulpecula:][peku kao=3 as=on ]
「小刚你没事吧～？　害怕的话要回车里去吗？」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:gonzalez:][gon kao=12 as=on ]
「没、没问题的……这种程度！[rhr]
_　和刚才的后空翻一样，和后空翻一样……！」[rhp]

[:darknebula:]
[font color=0x0000ff]
『佩奇小姐？冈萨雷斯先生怎么了』[rhp]
[resetfont]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:vulpecula:][peku kao=5 ]
「那个啊—、人家说会害怕啦、高的地方」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:darknebula:]
[font color=0x0000ff]
『这样啊～。真是令人同情』[rhp]

[off_all]

[:darknebula:]
『本次比赛内容是海滩旗帜・铁道屋顶篇』[rhp]
[:darknebula:]
『快斗选手、落合选手、冈萨雷斯选手将从最末端冲过屋顶，[rhr]
_　先头车厢上的公主所持旗帜被夺取者即为胜利』[rhp]
[resetfont]

[off_all]

[chara_part name="kite" body=base kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="sora" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sora:]
「真无聊。小孩子吗」[rhp]

[:kite:][kite kao=12 ]
「嘴上这么说却轻敌的家伙才会输呢」[rhp]

[:sora:][sora kao=2 ]
「哈……？你说谁会输？」[rhp]

[:kite:][kite kao=5 ]
「因为获胜的是我，难道不是你吗？」[rhp]

[:sora:][sora kao=2 ]
「……哼，口气不小。竟敢小瞧人……！」[rhp]

[off_all]

[chara_part name="peku" body=base kao=13 as=off ss=off hh=off hr=on msk=hat ]
[chara_show name="peku" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="gon" body=base kao=2 as=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:gonzalez:]
「真是的～～～……！你们到底在想什么……！[rhr]
_　在这种地方跑动，要是脚滑的话……！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:vulpecula:][peku kao=5 ]
「南说过不会死的啦～」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:gonzalez:][gon kao=2 as=on ]
「那种吊儿郎当的话怎么能信！！」[rhp]

[off_all]

;****************************************
[set_xx graphic="rule/krke_k.png" storage="train_11.jpg" time=300]
; 夜フィルター
[filter layer="1" brightness="60"]
;****************************************

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[chara_part name="sausu" body=base kao=3 as=on ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sausu:]
「好、好过分……！明明是真的！」[rhp]

[:yoru:][yoru kao=12 ]
「这就是平日品行的问题了」[rhp]

[off_all]

;****************************************
[set_kk storage="train_01.jpg" time=500]
;****************************************

[chara_part name="hakase" body=base kao=1 as=off ss=off hh=off hr=on msk=hat ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[::]
据说达克内布拉博士最初本想和上次一样[rhr]
邀请从某处突然被召唤来的南担任解说，仍打算委托米卡亲负责。[rhp]

[off_all]

[yoru kao=0 ]

但夜当时突然出现，以『她现在很忙』为由[rhr]
主动提议由自己代替米卡亲担任解说。[rhp]

[off_all]

[chara_part name="sausu" body=base kao=3 as=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

佩奇捉住了因夜出现而试图逃跑的南，[rhr]
不知为何连他也被安排担任了解说。[rhp]

;****************************************
[set_ff storage="train_10.jpg" time=500]
; 夜フィルター
[filter layer="1" brightness="60"]
;****************************************

[:princess:]
[font color=0x4682b4]
（话说回来，只要博士和佩奇呼唤，南就会立刻赶来。[rhr]
_　果然很厉害呢，不禁让人肃然起敬）[rhp]
[:princess:]
（…………不过，总觉得南的态度有些生硬）[rhp]
[resetfont]

[::]
不知为何显得特别坐立不安，[rhr]
又或是比平时沉默寡言许多。[rhp]
好奇怪……难道是被叫到大家集合的地方所以紧张吗？[rhr]
夜也是，对南的态度过于冷淡了……[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:mataroko:][mata kao=5 hh=on ]
「我都听说了哦姐姐大人！」[rhp]

[:princess:][puri_w kao=4 ]
「！！　玛塔，你什么时候跑到后面的！」[rhp]

[:mataroko:][mata kao=13 ]
「前几天去海边旅行时，[rhr]
_　听说玩了～～超级有趣的游戏对吧」[rhp]

[:princess:][puri_w kao=7 ]
「啊，在度假胜地呢。那时候是米卡亲来着，」[rhp]

[:mataroko:][mata kao=3 ]
「太狡猾了！！！　魔太郎子们也想玩的！！」[rhp]
[:mataroko:]
「所以我偷偷打听到详情后就擅自举办啦！」[rhp]

[:princess:][puri_w kao=1 ]
「啊。说起来你们三个当时都不在呢」[rhp]

[:mataroko:][mata kao=7 as=on ]
「因为人家不擅长海嘛。会变得湿漉漉的」[rhp]

[:princess:][puri_w kao=4 ]
「变湿？」[rhp]

[off_all]

[:nusi:][nusi kao=5 ]
「我们啊……最怕海了！是男人就该沉默着选庆次！」[rhp]

[:mataroko:][mata kao=2 ]
「请不要再提CR真・花之庆次2～漆黑的冲击～的事了！」[rhp]

[:princess:][puri_w kao=6 as=on ]
「虽然不太懂你们在说什么。[rhr]
_　但比赛这种事，我本来就不太感兴趣」[rhp]
[:princess:]
「在这种比赛中必须有人消失什么的。[rhr]
_　擅自消除了多洛普就是你不对，只要把他恢复原状不就好了吗」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:2nin:][nusi kao=3 ][mata kao=3 ]

[s_playse storage="nusi/full/83.ogg" buf=1]
[s_playse storage="mata/full/91.ogg" buf=2]

「公主……」[rhp]
「姐姐大人……」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
;ヌシ
[voconfig sebuf=1 name=nusi vostorage="nusi/full/{number}.ogg" number=84]
;魔太郎子
[voconfig sebuf=1 name=mata vostorage="mata/full/{number}.ogg" number=92]
[vostart]
;------------------------------------------------------------------------------------------

[:princess:][puri_w kao=8 ]
「是我太任性了吗……」[rhp]

[off_all]

[:mataroko:][mata kao=5 hh=on ]
「任性的人明明是那边那位。[rhr]
_　完全不顾姐姐大人的感受，男人真是太自私了」[rhp]
[:mataroko:]
「所以我才让小刚参加比赛的！」[rhp]

[:princess:][puri_w kao=6 ]
「什么意思？」[rhp]

[:mataroko:][mata kao=13 ]
「如果那孩子赢了，不就可以不用听任何一方的话了吗？[rhr]
_　到时候再重新让姐姐大人提出谈判就好了」[rhp]
[:mataroko:]
「而且我知道的。[rhr]
_　那两个人其实根本不喜欢吵架」[rhp]
[:mataroko:]
「宙和哥哥大人，其实都是非常温柔的人」[rhp]

[:princess:][puri_w kao=4 ]
「哥哥大人……难道说」[rhp]

[:mataroko:][mata kao=13 ]
「没错！和近就是我的哥哥大人。[rhr]
_　被他禁止这样称呼了，请保密哦」[rhp]

[:princess:][puri_w kao=13 ]
「这、这样啊」[rhp]

[off_puri]

[:mataroko:][mata kao=1 hh=on ]
「……姐姐大人，哥哥大人。[rhr]
_　谢谢你们陪我玩了这么久」[rhp]
[:mataroko:]
「我永远不会忘记的」[rhp]

[off_mata]

[:princess:][puri_w kao=3 ]
「玛塔……？」[rhp]

;****************************************
[set_xx graphic="rule/krke_k.png" storage="train_11.jpg" time=300]
; 夜フィルター
[filter layer="1" brightness="60"]
;****************************************

[off_all]

[:mataroko:]
[font color=0x0000ff]
『各位观众！差不多该开始比赛了好吗！』[rhp]
[resetfont]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[chara_part name="sausu" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:yoru:]
「你以为是谁在说废话拖延时间」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:mataroko:]
[font color=0x0000ff]
『哎呀！你、你都听见了？』[rhp]
[resetfont]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:sausu:][sausu kao=1 hh=on ]
「呵呵呵，是忘记关麦克风了吗？全被听光光喽」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:mataroko:]
[font color=0x0000ff]
『啊……哎呀～～～～！？真的吗！？』[rhp]
[resetfont]

;****************************************
[set_xx graphic="rule/krke_k.png" storage="train_10.jpg" time=300]
; 夜フィルター
[filter layer="1" brightness="60"]
;****************************************

[:mataroko:][mata kao=5 as=on ]
「哥哥大人……啊不对！和……也不是！」[rhp]
[:mataroko:]
「快、快斗～～～先生！请忘记刚才的事！[rhr]
_　魔太郎子什么都没说～～～！！」[rhp]

[off_all]

[chara_part name="peku" body=base kao=13 as=off ss=off hh=on hr=on msk=hat ]
[chara_show name="peku" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=8 as=on ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:kite:]
「是啊……」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:vulpecula:][peku kao=5 hh=on ]
「噗！玛塔真是个傻丫头」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[:gonzalez:][gon kao=11 as=on ]
「这就是姐姐可爱的地方啊。[rhr]
_　就算被卷进完全无关的竞赛，也会让人忍不住原谅……」[rhp]

[:princess:][puri_w kao=5 ]
「腿在发抖哦……」[rhp]

[:gonzalez:][gon kao=2 as=on ]
「这是斗志昂扬的颤抖啊！！」[rhp]

[off_all]

[chara_part name="sora" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:sora:]
「……你原来有妹妹吗？」[rhp]

[:kite:][kite kao=7 as=on ]
「……啊——……」[rhp]

[off_all]

[:kite:]
「………………、我还以为是『女儿』来着」[rhp]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
[set_b storage="train_11.jpg"]
;****************************************

[:sausu:][p_s_15][sausu kao=13 hh=on ]
「呵呵呵……听到了吗？约尔大人」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sausu:]
「魔太郎子的真面目，快斗似乎早就知道了呢。[rhr]
_　……不，或许是来到这个世界后才察觉的？」[rhp]
[:sausu:]
「在现实世界时，她从未在孩子们面前现身。[rhr]
_　说是怕吓到他们」[rhp]

[:yoru:][p_y_19][yoru kao=6 ]
「那又如何」[rhp]

[:sausu:][sausu kao=14 ]
「当然也有能重新靠双腿走路这种理由。[rhr]
_　但如果不在这个世界，快斗就永远无法听见魔太郎子的话语」[rhp]
[:sausu:]
「反过来问问魔太郎子怎么样？[rhr]
_　从他们那里夺走这个世界，这真的正确吗？」[rhp]

[:yoru:][p_y_24][yoru kao=5 ]
「当然是正确的。[rhr]
_　魔太郎子他们不过是受我指示监视你罢了」[rhp]
[:yoru:]
「别把那些家伙当成同伴。虽然态度有所不同，[rhr]
_　我们所有人都认为你很危险这一点是不会变的」[rhp]

[:sausu:][p_s_20][sausu kao=7 ]
「话虽这么说，他们对我还挺友善的呢？[rhr]
_　……我是从风声里听说的，约尔大人」[rhp]
[:sausu:]
「你，把宙――……」[rhp]

[:yoru:][yoru kao=2 ]
「闭嘴。万一被听见就麻烦了」[rhp]

[:sausu:][p_s_28][sausu kao=12 as=on ]
「你以为我们离那边有多远距离啊……算了无所谓」[rhp]
[:sausu:]
「……但话说回来，你那个谎言，真的对宙有好处吗」[rhp]

[:yoru:][p_y_28][yoru kao=6 ]
「像你这样的理想主义者就该乖乖旁观。[rhr]
_　明明毫无经验却妄想成就什么，才会深陷泥潭」[rhp]
[:yoru:]
「若想要互相舔舐伤口的同伴就去找别人。我没法胜任」[rhp]

[:sausu:][p_s_26][sausu kao=3 ]
「～～～～……我不是这个意思……我只是……」[rhp]

[off_all]

[:princess:][puri_w kao=2 ]
「喂你们两个。从刚才起鬼鬼祟祟聊什么呢？」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=4 as=on ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sausu:]
「！」[rhp]

[:yoru:][yoru kao=0 ]
「没什么大不了的。正在教训这个男人而已」[rhp]

[off_all]

[:darknebula:][p_hr_20][hakase kao=5 msk=hat ]
「别一直坐在座位上，你们也过来这边如何？」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=13 as=on ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sausu:][p_s_30]
「啊……、……嗯，嗯。……也好吧……哈哈」[rhp]

[:yoru:][yoru kao=6 ]
「真是见外啊」[rhp]

[:sausu:][sausu kao=3 as=on ]
「……平时我尽量不和大家交谈。[rhr]
_　因为总会让人想起往事……」[rhp]

[:yoru:][p_y_19][yoru kao=12 ]
「只能说自作自受」[rhp]

[:sausu:][sausu kao=13 ]
「………………」[rhp]

[off_all]

[:darknebula:][hakase kao=5 msk=hat ]
「好——了，差不多该正式开始比赛了。[rhr]
_　从现在起禁止斗殴，严禁交头接耳！」[rhp]

;****************************************
[set_xx graphic="rule/krke_k.png" storage="train_10.jpg" time=300]
; 夜フィルター
[filter layer="1" brightness="60"]
;****************************************

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
[vostart]
;--------------------------------------------------------------------------------------------

[chara_part name="kite" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="sora" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:kite:]
「[player3b]要说谁和她相处时间最长 那绝对是我。[rhr]
_　比起她父母 我待在的她身边的时间要多得多」[rhp]
[:kite:]
「我可没有退让的意思」[rhp]

[:sora:][sora kao=6 ]
「哦。……我才要说这话」[rhp]

[off_all]

[:gonzalez:][gon kao=3 ]
[font color=0x4682b4]
（我连1%的胜算都看不到……[rhr]
_　这就是所谓的内定比赛吧……）[rhp]
[resetfont]

;****************************************
[fbgm]
[set_xx graphic="rule/krke_k.png" storage="train_11.jpg" time=300]
; 夜フィルター
[filter layer="1" brightness="60"]
[bgm storage="bgm_22.ogg"]
;****************************************

[chara_part name="gon" body=base kao=8 as=on ss=off hh=off hr=on msk=hat ]
[chara_show name="gon" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="hakase" body=base kao=5 as=off ss=off hh=on hr=on msk=hat ]
[chara_show name="hakase" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:darknebula:][hakase kao=5 msk=hat ]
「冠军，冈萨雷斯！」[rhp]

[:gonzalez:][gon kao=4 as=on ]
「搞什么啊」[rhp]

[:darknebula:][hakase kao=1 msk=hat ]
「基础体力果然有差距呢。毕竟要贯穿八节车厢，[rhr]
_　想必需要相当惊人的体力」[rhp]

[off_all]
;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[chara_part name="sausu" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sausu:]
「真不愧是冈萨雷斯！」[rhp]

[:yoru:][yoru kao=1 ]
「干得漂亮嘛」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:gonzalez:][gon kao=14 hh=on as=on ]
「哪、哪里哪里……」[rhp]
[:gonzalez:][gon kao=6 as=on ]
「………………偷瞄」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[chara_part name="kite" body=base kao=3 as=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="sora" body=base kao=2 as=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:2nin:]
「………………」[rhr]
「………………」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[:gonzalez:][gon kao=2 ss=on as=on ]
[font color=0x4682b4]
「实在高兴不起来……」[rhp]
[resetfont]

[off_all]

[:darknebula:]
「接下来公布第二名落合、第三名快斗的赛果。[rhr]
_　争夺战就此结束！」[rhp]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
[set_xx graphic="rule/krke_k.png" storage="train_10.jpg"]
; 夜フィルター
[filter layer="1" brightness="60"]
;****************************************

[::]
似乎玩够尽兴的博士和佩奇，[rhr]
早早回到了车厢里。[rhp]
被留下的我们跪坐着，[rhr]
用温吞的视线注视着气喘吁吁的快斗。[rhp]

[:kite:][kite kao=2 ]
「可……！杀了我吧！」[rhp]

[:sora:][p_so_26][sora kao=3 as=on ]
「虽然由我来说有点那个……[rhr]
_　你都放出那种狠话了不赢不行吧……」[rhp]

[:kite:][p_k_32][kite kao=6 ]
「可恶……你小子，哪个学校的？」[rhp]

[:sora:][sora kao=12 ]
「大学生哦」[rhp]

[:kite:][kite kao=7 as=on ]
「看吧，怎么可能赢嘛。别小看享年15岁的含金量啊」[rhp]

[off_all]


[chara_part name="sausu" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="-60" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="355" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="650" top="0" wait="true" time=150]
[chara_part name="puri_w" body=base kao=2 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width="330" height="720" wait="true" zindex="1005" time=150]

[:princess:]
「快斗！这种玩笑不能开！」[rhp]

[:yoru:][p_y_04][yoru kao=8 as=on ]
「最恶劣的自嘲」[rhp]

[:sausu:][p_s_02][sausu kao=3 ]
「让人笑不出来可不太好呢」[rhp]

[:kite:]
「行了行了好烦。围观群众给我闭嘴」[rhp]

[off_all]

[chara_part name="kite" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="sora" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sora:]
「那就按约定，我在这里接替多洛普继续当列车长。[rhr]
_　你乖乖下车放弃公主。没问题吧」[rhp]

[:kite:][kite kao=8 ]
「………明白。败者无话可说」[rhp]

[off_all]

[:princess:][puri_w kao=3 ]
「等、等一下啦……！这种事我……」[rhp]

[:kite:][p_k_28][kite kao=12 ]
「输了就是输了。宙可不是会死缠烂打的人」[rhp]

[fbgm]

[:princess:][puri_w kao=2 as=on ]
「…………」[rhp]

[off_all]

[::]
……完全看不懂快斗的想法。[rhr]
明明直到不久前，整天腻歪到烦人的不正是你吗。[rhp]
但在最为关键的这个时刻，[rhr]
为何能如此轻易地退身而去？[rhp]
快斗的心情 是能在这场胜负中轻易放弃的吗？[rhp]

[bgm storage="bgm_05.ogg"]

[:princess:]
[font color=0x4682b4]
（我……我无法放弃啊）[rhp]
[resetfont]

[::]
过去也好 记忆也罢 这些都毫无关系。[rhr]
不管别人怎么说 这才是我的心意。[rhp]
『此刻』 我就是喜欢快斗。[rhp]

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
[vostart]
;--------------------------------------------------------------------------------------------

[:kite:]
「啊——」[rhp]
[:kite:][kite kao=3 as=on ]
「要是摆出那种表情 早点和我交往不就好了」[rhp]

[:princess:][puri_w kao=4 as=on ]
「什……！」[rhp]

[:kite:][kite kao=7 ]
「吊胃口可真亏啊 你我都。[rhr]
_　虽然遗憾 但这里还是放弃让宙来……」[rhp]

[:princess:][puri_w kao=2 ]
「～～～！　真的可以吗！？」[rhp]

[off_puri]

[:kite:][kite kao=4 ]
「……诶」[rhp]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

[off_all]

[::]
因为突然大声喊出来 众人都吃惊地看过来。[rhp]
但哪还顾得上体面。继多洛普之后[rhr]
连快斗都要消失绝对不行。无论如何都要留住他！[rhp]

[chara_part name="kite" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=2 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width="330" height="720" wait="true" zindex="1005" time=150]

[:princess:]
「干脆利落地输 干脆利落地放弃 我问你到底算什么……！[rhr]
_　至今都是这样！　我的心意总被无视不是吗！」[rhp]
[:princess:]
「别擅自一个人决胜 擅自一个人放弃啊！[rhr]
_　我明明才刚意识到……！」[rhp]
[:princess:]
「…………我说 我喜欢快斗这件事！」[rhp]

[:kite:][kite kao=0 ]
「――――！」[rhp]

[:princess:][puri_w kao=3 hh=on ]
「说什么『快点』。[rhr]
_　把那个期限提早的人不就是快斗嘛……！」[rhp]
[:princess:]
「……为什么不肯等等我。[rhr]
_　每一次每一次都是这样！」[rhp]

[off_all]

[:sausu:][p_s_19][sausu kao=4 ]
「……诶……」[rhp]

[off_all]

[:yoru:][yoru kao=4 ]
「那家伙……难道……」[rhp]
[:yoru:]
「…………你想起来了？」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=2 as=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width="330" height="720" wait="true" zindex="1005" time=150]

[:princess:]
「才没想起来呢！！这是我现在的真实想法啦！！」[rhp]

[:yoru:][p_y_09][yoru kao=2 ]
「就算你冲我发火」[rhp]

[:sausu:][p_s_32][sausu kao=13 ]
「吓我一跳……也是呢。[rhr]
_　怎么可能这么简单就……」[rhp]

[off_all]

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
[vostart]
;--------------------------------------------------------------------------------------------

[:kite:][kite kao=0 ]
「…………你说过，喜欢我？」[rhp]

[:princess:][puri_w kao=2 hh=on ]
「说过的！我最喜欢快斗了！」[rhp]

[:kite:][kite kao=7 ]
「呃！那为什么至今为止，」[rhp]

[:princess:][puri_w kao=3 ]
「因为快斗喜欢的，是我不认识的那个过去的我啊……！」[rhp]

[:kite:][kite kao=4 as=on ]
「……！」[rhp]

[:princess:][puri_w kao=7 ]
「现在的我喜欢快斗。[rhr]
_　但我不是那个『被快斗喜欢上的我』嘛」[rhp]
[:princess:]
「我不能抛弃那个我不认识的自己，随便给出回应。[rhr]
_　所以……本来打算等恢复记忆后，再好好答复你的……」[rhp]
[:princess:]
「本以为……还会有时间的……！」[rhp]

[off_puri]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:kite:][kite kao=6 ]
「………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[chara_part name="nusi" body=base kao=6 as=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="gon" body=base kao=4 as=off ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:gonzalez:]
「虽然搞得像生离死别似的，其实不是吧？[rhr]
_　我总不会在那场重要比赛里不识相地拿了冠军吧？」[rhp]

[:nusi:][nusi kao=0 as=on ]
「应、应该没问题的……」[rhp]

[off_all]

[:mataroko:][mata kao=3 hh=on ]
「………………哥哥大人……」[rhp]

[off_all]

[chara_part name="kite" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=2 as=off ss=off hh=on hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width="330" height="720" wait="true" zindex="1005" time=150]

[:princess:]
「笨蛋！笨蛋快斗！[rhr]
_　为什么这么没干劲啊！」[rhp]
[:princess:]
「是男人的话……！如果真的喜欢，[rhr]
_　就算下跪也要提出再战啊！」[rhp]

[:kite:][kite kao=6 as=on ]
「不、那样有点……太逊了……」[rhp]

[:princess:][puri_w kao=2 ]
「就是这种地方不行啊！？笨蛋～～～～！！」[rhp]

[:kite:][kite kao=7 ]
「………反正也……」[rhp]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

[off_all]

[:sora:][sora kao=12 as=on ]
「……………………唉」[rhp]

[off_all]

[chara_part name="kite" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="sora" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sora:]
「…………你从以前就这样呢。」[rhp]

[:kite:][kite kao=8 ]
「！」[rhp]

[:sora:][sora kao=2 ]
「总是说『反正』『可是』之类的话，把一切都放弃。[rhr]
_　如果我是你，现在就算把我推开也要去争取胜利」[rhp]
[:sora:]
「顽强地活着，就那么不光彩吗？」[rhp]

[off_all]

[::]
听着落合君的话，快斗苦恼地沉默着。[rhp]
短暂的沉默后，最先开口的是……[rhp]

[:mataroko:][mata kao=13 ]
「……那个！快斗先生！」[rhp]

[off_all]

[:kite:][kite kao=6 ]
「魔太郎子……？」[rhp]

[off_all]

[::]
快斗惊讶地看着魔太郎子。[rhr]
众人屏息注视着她那下定决心的眼神。[rhp]
魔太郎子像是在呐喊般继续说道。[rhp]

[chara_part name="mata" body=base kao=5 as=off ss=off hh=on hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:mataroko:]
「那个……经过反复思考……」[rhp]
[:mataroko:]
「只有我知道的你的秘密……！[rhr]
_　现在在这里说出来也没关系吗！？」[rhp]

[:kite:][p_k_21][kite kao=8 ]
「哈？」[rhp]

[off_all]

[:princess:][puri_w kao=4 ]
「秘密？」[rhp]

[:mataroko:][mata kao=3 hh=on ]
「是的。我实在看不下去了！[rhr]
_　作为唯一知晓他内心的人，怎能保持沉默」[rhp]
[:mataroko:]
「请允许我在此化身为鬼！」[rhp]

[off_all]

[:kite:][kite kao=6 as=on ]
「等、等等。怎么会变成这样！？[rhr]
_　我并没有被魔太郎子掌控的................」[rhp]
[:kite:]
「…………………」[rhp]

[off_all]

[chara_part name="kite" body=base kao=6 as=on hh=on hr=off ]
[chara_show name="kite" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="sora" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sora:]
「有吗」[rhp]

[:kite:]
「…………――――――。也、也不是没有」[rhp]

[off_all]

[:mataroko:][mata kao=3 hh=on ]
「姐姐大人。落合先生。[rhr]
_　恳请体谅快斗先生的心情……！」[rhp]

[:kite:][kite kao=2 as=on ]
「魔太郎子！住手！唯独那个不行」[rhp]

[:mataroko:][mata kao=5 hh=on ]
「请不要阻止！[rhr]
_　魔太郎子心意已决！」[rhp]

[off_all]

[:mataroko:][mata kao=2 as=on ]
「快斗先生虽然逞强，但其实……！」[rhp]

[off_all]

;****************************************
[fbgm]

#
[s_mask color=0x000000 time=3000]
; 背景表示
[bg storage="hsps_08.jpg" time=100]
[free_filter ]
; ウィンドゥの設定
[position layer="message0" frame="win2.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[s_mask_off time=3000]

[bgm storage="bgm_16.ogg"]
;****************************************
[::]
6年前―――[rhp]

[:himeko:][hime2 kao=3 as=on ]
「和君，真的可以吗？」[rhp]

[off_all]

[:kazutika:][kazu kao=1 chair=off ]
「没关系。散步的话就和米卡亲一起去吧」[rhp]

[off_all]

[chara_part name="kazu" body=base kao=12 as=off ss=off hh=off hr=on chair=off ]
[chara_show name="kazu" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:himeko:]
「诶～难得的机会不一起吗？[rhr]
_　和君的轮椅我来推就好啦」[rhp]

[:kazutika:][kazu kao=5 chair=off ]
「[player3]「就凭你也想操控我的罗德姆吗」[rhp]

[:himeko:][hime2 kao=12 as=on ]
「又起这种怪名字……」[rhp]

[:kazutika:][kazu kao=1 chair=off ]
「轮椅只会累人，我要睡觉」[rhp]

[:himeko:][hime2 kao=2 ]
「真～是的，和君真是宅爆了。米卡亲和矢部老师都说[rhr]
_　偶尔该去呼吸户外空气啦」[rhp]

[:kazutika:][kazu kao=2 chair=off ]
「开窗就有室外空气进来」[rhp]

[:himeko:][hime2 kao=6 ]
「那不算！房间空气只混了一半啦！」[rhp]

[off_all]

[se storage="door_07.ogg"]

[:takeru:][take kao=0 ]
「喂你们几个。在吵什么」[rhp]

[:himeko:][hime2 kao=3 as=on ]
「矢部医生听我说！和君说他不想去散步！[rhr]
_　我说我来推罗德姆他也拒绝，真是顽固！」[rhp]

[:takeru:][take kao=6 ]
「罗德姆？又是哪个动画里的吗？」[rhp]

[off_all]

[chara_part name="kazu" body=base kao=12 as=off ss=off hh=off hr=on  chair=off ]
[chara_show name="kazu" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="take" body=base kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:kazutika:]
「对。是前几天爸爸带回来的东西」[rhp]

[:takeru:][take kao=1 ]
「这样啊。这些对我来说有点难懂……[rhr]
_　如果有工作人员陪同的话，中庭的外出应该是允许你去的吧？」[rhp]

[:kazutika:][kazu kao=6 chair=off]
「我知道啦」[rhp]

[off_kazu]

[chara_part name="hime2" body=base kao=3 as=on ss=off hh=off hr=on msk=hat ]
[chara_show name="hime2" layer="1" width="437" height="720" left="208" top="0" wait="true" time=150]

[:himeko:]
「他说因为会累所以不想去！真是让人头疼。[rhr]
_　矢部医生你也帮忙说说他嘛！」[rhp]

[:takeru:][take kao=12 ]
「嗯……倒不必勉强自己，[rhr]
_　不过适度的外出对refresh来说刚好合适哦」[rhp]
[:takeru:]
「如果还没有那么累的话，[rhr]
_　哪怕是短时间出去呼吸下新鲜空气也不错」[rhp]

[off_all]

[:kazutika:][kazu kao=5 chair=off]
「不随波逐流，这才是我憧憬的大人模样」[rhp]
[:kazutika:]
「就算被人说完全不合适也固执地[rhr]
_　继续戴着这个领带针，就像矢部那样呢」[rhp]

[off_all]

[:takeru:][take kao=3 as=on ]
「诶！难、难道这个不适合我吗？[rhr]
_　大美贺小姐说小孩子最喜欢这种了」[rhp]

[off_all]

[chara_part name="kazu" body=base kao=13 as=off ss=off hh=off hr=on chair=off ]
[chara_show name="kazu" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:kazutika:]
「所以我尊重自己的意愿，决定在房间里睡觉」[rhp]

[:himeko:]
「真是的～～～～！和君最近总在睡觉。[rhr]
_　好无聊啊……明明还想和和君多玩会儿的……」[rhp]

[:kazutika:][kazu kao=0 chair=off ]
「…………。……明明」[rhp]

[:himeko:][hime2 kao=4 ]
「咦？什么？」[rhp]

[:kazutika:][kazu kao=12 chair=off ]
「……没什么」[rhp]
[:kazutika:][kazu kao=5 hh=on chair=off ]
「嘛、我是想说我不是那么廉价的男人。[rhr]
_　受欢迎的男人真是辛苦呢」[rhp]

[off_all]

[:kazutika:]
「那、晚安啦～～」[rhp]

[chara_part name="take" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=3 as=off hh=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:himeko:]
「欸～～……！」[rhp]

[:takeru:][take kao=1 ]
「星名小姐、适可而止吧。[rhr]
_　外出虽然重要、但量力而行也同样重要」[rhp]

[:himeko:][hime2 kao=7 ]
「呜……知道啦……」[rhp]

[off_all]

[:kazutika:]
「………………」[rhp]

;****************************************
[set_b storage="hsps_08.jpg"]
;****************************************

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
[vostart]
;--------------------------------------------------------------------------------------------

[:kazutika:]
「………………、已经走了吧」[rhp]

[::]
[player3]的脚步声消失后、我从蜷缩的被窝里微微探出脸。[rhp]

;****************************************
[bg storage="hsps_11.jpg" time=500]
;****************************************

稍稍探出身、望向窗外。[rhp]
[player3]和值班护士一起玩球的身影映入眼帘。[rhr]
确认那个身影后、我撑起上半身重新坐在床铺上。[rhp]

;****************************************
[bg storage="hsps_08.jpg" time=500]
;****************************************

[:kazutika:][kazu kao=12 chair=off]
「……嘿咻……」[rhp]

[off_all]

[::]
随后、拿起放在床头柜上装饰着的『那家伙』。[rhr]
[player3]经常忘在我房间的『妹妹』。[rhp]

[off_all]

[:kazutika:][kazu kao=3 as=on chair=off]
「哈啊。……刚才的都听见了吗？」[rhp]
[:kazutika:]
「所以我才讨厌能走路的人。[rhr]
_　根本不懂卧床者的心情」[rhp]

[off_all]

[:kazutika:]
「…………对吧？魔太郎子」[rhp]

[::]
―――兄长大人总是喜欢这样对我说话。[rhp]
这是仅属于我与他之间的、[rhr]
在这间病房里唯有他独自一人时才举办的茶会。[rhp]

;****************************************
;スチル
[still storage="cg/d_k_2.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/d_k_2.png"]
;****************************************

[:kazutika:]
「光是去大厅就已经够吃力了、[rhr]
_　为什么非得去中庭不可啊」[rhp]
[:kazutika:]
「轮椅什么的...绝对不要啦……」[rhp]

[::]
兄长大人对轮椅可谓厌恶至极。[rhp]
每当要从床铺转移到轮椅时、[rhr]
据说他最不愿被姐姐大人看见那副模样。[rhp]
说是既难堪又丢人。[rhr]
被人推轮椅这种事也嫌太凄惨而抗拒。[rhp]
兄长大人常在无人的病房里这样喃喃自语。[rhp]
…………但是。[rhp]

[:kazutika:]
「……就在房间里不好吗」[rhp]
[:kazutika:]
「从房间里不是也能看见外面嘛。[rhr]
_　打开窗户就有风吹进来，阳光也能照到」[rhp]
[:kazutika:]
「……………就算没有我其实也无所谓吧」[rhp]

[::]
…………我与兄长大人，还有姐姐大人。[rhr]
更早以前，还有『母亲大人』和『父亲大人』呢。[rhp]
若能再度迎来像当年一起玩过家家的那些日子、[rhr]
该有多好啊。[rhp]
若能三人再度共同嬉戏，将是何等的幸福。[rhp]

;****************************************
[still_end frame="win2.png" storage="hsps_11.jpg" time=1000]
;****************************************

他们年岁渐长，如今连兴趣和游戏都已与幼时不同。[rhr]
想必您不难想象，我的愿望是多么难以实现。[rhp]
对于正值青春期的兄长大人来说，既要陪我玩耍，[rhr]
又要受同龄的女性姐姐照顾，想必会觉得难为情吧。[rhp]
即便如此我仍不禁许下这个愿望。[rhr]
毕竟我是你们最小的妹妹，也是唯一的女儿呀。[rhp]

;****************************************
[bg storage="white.jpg" time=500]
;****************************************

现实世界的我们，终究是无可奈何地无力。[rhr]
作为唯一知晓他真心话的人，至少想在这个世界履行这份责任。[rhp]
所以无论现在你对我说什么――――――[rhp]

;****************************************

[s_mask color=0x000000 time=3000]
; 背景表示
[bg storage="train_10.jpg" time=100]
; 夜フィルター
[filter layer="1" brightness="60"]
; ウィンドゥの設定
[position layer="message0" frame="win.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[s_mask_off time=3000]

;****************************************

……无、无论说什么……[rhp]


[:mataroko:]
「唔咕咕……！咕……」[rhp]
[:mataroko:]
「…………嘎咚」[rhp]

[:kite:]
「呼……」[rhp]
[:kite:][kite kao=5 ]
「安全上垒！」[rhp]

[:princess:][puri_w kao=3 as=on ]
「才不是啦！！」[rhp]

[off_all]

[::]
她似乎想说出关于快斗的某些事情，[rhr]
但刚开口就被快斗锁喉制止，最终什么也没听见。[rhp]
看她当时神情严肃，该不会是什么重要的事情吧？[rhr]
重获自由的真澄酱涨红着脸含泪呜咽。[rhp]

[chara_part name="mata" body=base kao=6 as=on hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:mataroko:]
「咳嗬、咳嗬！干、干什么呀呜……」[rhp]

[:kite:][kite kao=2 as=on ]
「我说你……！下次再敢多嘴的话饶不了——」[rhp]

[:mataroko:][mata kao=3 ]
「还没完呢！！快斗先生对我——」[rhp]

[se storage="hand_05.ogg"]

[off_all]

[:mataroko:][mata kao=8 as=on ]
「咿呀！！」[rhp]

[off_all]

[:kite:][kite kao=6 ]
「所以说～……！！」[rhp]

[:nusi:][nusi kao=2 ]
「喂、喂喂！就算玛塔子是负责背黑锅的，[rhr]
_　对女孩子动手可不行！」[rhp]

[:princess:][puri_w kao=2 ]
「就是啊！怎么能敲幼女的头！」[rhp]

[:kite:][kite kao=2 ]
「可、可明明是这家伙不好嘛」[rhp]

[off_all]

[chara_part name="mata" body=base kao=12 as=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="gon" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:gonzalez:][gon kao=6 ]
「姐姐振作点！！嘿嘿呼！」[rhp]

[:mataroko:][mata kao=8 ss=n ]
「这、这里是……三途川……？」[rhp]

[:princess:][puri_w kao=2 as=on ]
「是天河啦」[rhp]

[:mataroko:][mata kao=4 ]
「天河……」[rhp]

[off_all]

[:mataroko:][mata kao=5 hh=on ]
「……没错！是天河！[rhr]
_　现在可不是瘫着的时候」[rhp]

[off_all]

[:kite:][kite kao=3 ]
「等……那个！真的可以了别再，」[rhp]

[off_all]

;****************************************
[still storage="cg/d_k_3.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/d_k_3.png"]
;****************************************

[:mataroko:]
「快斗先生！您最帅了！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:kite:][p_k_10]
「哈……？」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:mataroko:]
「不管是睡着时，坐着时。……还是输了比赛时！[rhr]
_　每个您都绝对帅气的！」[rhp]
[:mataroko:]
「您比您想象的，要帅气得多呢！」[rhp]

[:kite:]
「魔太郎子……」[rhp]

[:mataroko:]
「正因为后悔过过去，这次才要向姐姐表明心意的不是吗？[rhr]
_　为什么现在要放弃！」[rhp]
[:mataroko:]
「难道是因为落合先生太酷才较劲的！？」[rhp]

[:kite:]
「那、那个」[rhp]

[:mataroko:]
「先说清楚，落合先生可一点都不潇洒哦！[rhr]
_　为了见姐姐不知道耍了多少小手段呢」[rhp]
[:mataroko:]
「……但是！完全不会让人觉得难看不是吗！」[rhp]

[:kite:]
「…………！」[rhp]

[:mataroko:]
「你误会了……！[rhr]
_　即使获得成人的身体，你依然还只是个孩子呢」[rhp]
[:mataroko:]
「不甘心的心情并不丢人。[rhr]
_　无法彻底放弃而挣扎的样子，也一点都不丢人哦」[rhp]
[:mataroko:]
「努力的人远没有你想象得那么难堪！」[rhp]
[:mataroko:]
「在原先的世界里你能拥有多少自由？[rhr]
_　在这个梦寐以求的世界里，还有什么需要顾虑的呢？」[rhp]
[:mataroko:]
「若是在这里都无法与姐姐结合，究竟还能在哪里实现呢」[rhp]

[:kite:]
「……魔太郎子……」[rhp]

[:mataroko:]
「……已经没人愿意和魔太郎子玩耍了。[rhr]
_　也没人和我说话了」[rhp]
[:mataroko:]
「所以至少在这个世界里，我想要履行自己的职责。[rhr]
_　痛苦的时候，随时都可以找我倾诉」[rhp]
[:mataroko:]
「只要看到两位在一起，我就很幸福了。[rhr]
_　因为……我是你们的妹妹啊……！」[rhp]
[:mataroko:]
「这个魔太郎子，绝对不愿意放弃……[rhr]
_　你们二人的幸福，还有我自己的幸福！」[rhp]
[:mataroko:]
「我、我是不是说了什么羞耻的话！？」[rhp]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

[:kite:]
「………………」[rhp]

;****************************************
;スチル終了
[still_end frame="win.png" storage="train_10.jpg" time=1000]
;***************************************

[:mataroko:][mata kao=3 hh=on ]
「呜呜……抽泣……！」[rhp]

[off_all]

[chara_part name="nusi" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="30" top="0" wait="false" time=150]
[chara_part name="mata" body=base kao=4 as=on ss=off hh=on hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="gon" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="720" top="0" wait="true" time=150]

[:mataroko:][p_mt_26]
「……！啊！不、不行。[rhr]
_　淑女可不该随便流泪呢」[rhp]

[:nusi:][nusi kao=5 hh=on ]
「超帅气的啊，玛塔子」[rhp]

[:gonzalez:][gon kao=13 hh=on ]
「没错！真不愧是姐姐」[rhp]

[:mataroko:][mata kao=14 ]
「！　哼……哼哼！　果然如此。果然如此呢」[rhp]

[off_all]

[chara_part name="mata" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:mataroko:]
「来！　哥哥大人……不、快斗先生！[rhr]
_　殴打这位柔弱幼女并让她哭泣的代价可是沉重的哟」[rhp]
[:mataroko:]
「直到您将现在的想法[rhr]
_　好好传达给姐姐大人之前 我都不会回去的」[rhp]

[:kite:][kite kao=6 ]
「哭是你自己爱哭吧」[rhp]

[:mataroko:][mata kao=2 hh=on ]
「烦死了！　间接来说都是你的错！」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sausu:]
「什么意思？」[rhp]

[:yoru:][yoru kao=12 ]
「来吧」[rhp]

[off_all]

[:kite:][kite kao=8 as=on ]
「………………。明白了……」[rhp]

[:mataroko:][mata kao=13 hh=on ]
「！　当真吗？　那么……」[rhp]

[:kite:][kite kao=8 ]
「作为交换 过去的事要全部忘掉。[rhr]
_　在这里的我是『快斗』。没必要回顾过去」[rhp]

[:mataroko:][mata kao=1 ]
「是。谨记于心」[rhp]
[:mataroko:]
「……虽然有点寂寞呢」[rhp]

[off_all]

[:sora:][sora kao=6 ]
「这什么状况……对我越来越不利了啊」[rhp]
[:sora:]
「…………果然会变成这样吗」[rhp]

[:kite:][kite kao=0 ]
「宙」[rhp]

[:sora:][sora kao=2 ]
「干嘛。混蛋」[rhp]

[:kite:][kite kao=3 ]
「那个……虽然这种请求非常抱歉……[rhr]
_　但魔太郎子无论如何都要说 能答应一个请求吗？」[rhp]

[off_all]

[:mataroko:][p_mt_03][mata kao=13 ]
[font color=0x4682b4]
（现在把责任推给我也没关系……！[rhr]
_　恋爱是要靠气势的呀 哥哥大人！）[rhp]
[resetfont]

[off_all]

[chara_part name="kite" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="sora" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:kite:]
「宙。……求你了……！　刚才的比赛……」[rhp]
[:kite:]
[font size=27]
「请让出7节车厢的差距重新对决！！」[rhp]
[resetfont]

[:sora:][sora kao=2 ]
「不要」[rhp]

[off_sora]

[chara_part name="mata" body=base kao=6 as=on hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:mataroko:]
「等一下！！　不管怎么说7节车厢也太过分了吧！？」[rhp]

[:kite:][kite kao=2 as=on ]
「诶……我、刚才说了什么丢脸的话吗？」[rhp]

[:mataroko:][mata kao=2 as=on ss=on ]
「居然敢戏弄本小姐的名场面～～～！！」[rhp]

[off_all]

[:yoru:][yoru kao=3 ]
「…………真是群让人无语的家伙。刚才的认真劲都去哪了」[rhp]

[:princess:][puri_w kao=13 hh=on ]
「也是呢……不过很有快斗的风格」[rhp]

[:yoru:][yoru kao=6 as=on ]
「别用风格来搪塞。这应该是重要的对决吧」[rhp]

[:princess:][puri_w kao=1 ]
「话是这么说……呵呵。果然还是这样才对味啊」[rhp]
[:princess:]
「如果快斗从这铁道上消失的话，我肯定会方寸大乱吧」[rhp]

[off_all]

[:sora:][sora kao=0 ]
「………………」[rhp]
[:sora:][sora kao=3 ]
「…………、……哈哈……」[rhp]

[off_all]

[:yoru:][yoru kao=0 ]
「……宙？」[rhp]

[off_all]

[chara_part name="kite" body=base kao=6 as=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="sora" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:kite:]
「怎么了。胜利者的余裕吗？」[rhp]

[:sora:][sora kao=2 ]
「才不是。……正是连你这种地方都算在内，[rhr]
_  突然觉得认真竞争变得好蠢啊」[rhp]

[:kite:][p_k_01][kite kao=13 ]
「确实。对于人生中从来没正经跑过步的我来说，这种比赛太乱来了」[rhp]

[:sora:][p_so_21][sora kao=3 ]
「那打从一开始就别说什么要比啊」[rhp]

[:kite:][kite kao=11 ]
「我说过的吧。我绝不[player3b]把身边的位置让给任何人。[rhr]
_  无论多么不利的比赛，我都绝对会赢给你看」[rhp]
「我可是[player3b]的、独一无二的王子大人啊……之类的」[rhp]

[:sora:][sora kao=2 as=on ]
「………快斗………」[rhp]
[:sora:]
「…………我说过那种话吗？」[rhp]

[:kite:][kite kao=7 ]
「没说过吗？」[rhp]

[:sora:][sora kao=6 as=on ]
「现在是我在问你」[rhp]

[off_all]

[:kite:][kite kao=1 ]
「好、已经没问题了。我的眼泪超大作戦见效了 现在这家伙[rhr]
_　7.5节车厢程度的劣势都想让给我。这局赢定了」[rhp]

[:princess:][puri_w kao=12 as=on ]
「呜、嗯——？　嗯——……」[rhp]

[:kite:][kite kao=13 ]
「不用那么怀疑真的没关系的啦。......毕竟吵吵闹闹的妹妹在看着啊。[rhr]
_　这种时候多少得摆个正经架势才行」[rhp]

[off_all]

[:mataroko:][p_mt_14][mata kao=14 hh=on ]
「！　哎呀」[rhp]

[off_all]

[chara_part name="kite" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="sora" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:kite:]
「那么 怎么样啊宙君。准备好再战了吗」[rhp]

[:sora:][sora kao=12 ]
「…………没有必要」[rhp]

[:kite:][kite kao=4 as=on ]
「当真？看在牢不可破友情的份上 准备让我不战而胜吗？」[rhp]

[:sora:][p_so_28][sora kao=0 ]
「没错」[rhp]

[:kite:][kite kao=2 ]
「诶」[rhp]

[off_all]

[chara_part name="sora" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=4 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width="330" height="720" wait="true" zindex="1005" time=150]

[:princess:]
「突然怎么了这是……」[rhp]

[:sora:][sora kao=7 ]
「其实早就隐约察觉到了。[rhr]
_　无论我多喜欢她 都赢不过你」[rhp]
[:sora:]
「那当然了。共同度过的时间 能够分担的痛苦。[rhr]
_　所有方面 快斗都更占优势啊」[rhp]
[:sora:]
「…………最重要的是 你和快斗在一起时笑得最开心」[rhp]

[off_all]

[chara_part name="kite" body=base kao=5 as=off ss=off hh=on hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="sora" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:kite:]
「确实」[rhp]

[:sora:][sora kao=2 ]
「每句话都要多补一刀的性格啊」[rhp]

[:kite:][kite kao=5 ]
「抱歉啦 赢了就逃」[rhp]
[:kite:]
「不过对我来说 就像同学会一样开心啊。[rhr]
_　本以为自己的人生里不会有这种东西 反而更珍贵了」[rhp]

[:sora:][sora kao=11 ]
「哈哈......这说法真有意思」[rhp]

[off_all]

[::]
因着这无谓的争执，两人间略显险恶的氛围稍有缓和。[rhp]
虽无法完全理解谈话内容，但他们怀念往昔的心情，[rhr]
不知为何在我内心深处隐约能够体会。[rhp]

[:sora:][p_so_02][sora kao=13 ]
「…………、好了」[rhp]
[:sora:]
「那么，趁着圆满结束的时机，该去转世投胎了吧。[rhr]
_　虽然不知道能不能做到这种事」[rhp]

[:princess:][puri_w kao=3 as=on ]
「那落合君，真的……」[rhp]

[:sora:][p_so_01][sora kao=1 ]
「啊，我要在这铁道下车了。[rhr]
_　只要知道你还好好地活着，对我来说就足够了……」[rhp]
[:sora:]
「……就当是这样吧。看在那家伙快斗的土气份上」[rhp]

[:princess:][puri_w kao=3 ]
「落合君……那个……其实本想欢迎你的，但我……」[rhp]

[:sora:][p_so_34][sora kao=5 ]
「没关系啦。我知道自己登场方式惹人厌恶。[rhr]
_　怕被快斗抢先，才稍微有些心急」[rhp]
[:sora:]
「我才该道歉。对不起。多洛普的事我会想办法」[rhp]

[:princess:][puri_w kao=1 ]
「……谢谢……」[rhp]

[:sora:][sora kao=1 ]
「你啊，被夜说过的吧。[rhr]
_　在找回记忆前可以继续旅行这件事」[rhp]
[:sora:]
「既然如此，我的愿望就是尽量不让你回想起记忆。[rhr]
_　为了快斗，也为了你」[rhp]
[:sora:]
「希望你们获得幸福的心情，至今仍未改变」[rhp]

[:princess:][puri_w kao=8 as=On ]
「落合君。我啊，突然想到——[rhr]
_　你已经在那个……现实世界里死掉了吧？」[rhp]
[:princess:]
「多洛普和落合君还有快斗，难道所有人都不能留在这个世界吗？[rhr]
_　反正胜负也已经变得无所谓了嘛！」[rhp]

[:sora:][p_so_22][sora kao=3 ]
「那是……不过，真的可以吗」[rhp]

[:princess:][puri_w kao=0 ]
「没问题的！对吧――――――」[rhp]

[off_all]

[::]
为寻求认同而环视四周时，[rhr]
视线捕捉到眉头紧锁的夜。「唰」地四目相对。[rhp]
夜深深叹息，烦躁地咂了咂舌。[rhp]

[:yoru:][p_y_16][yoru kao=6 ]
「……别看我。你该依赖的是南才对吧」[rhp]

[off_all]

[:sausu:][sausu kao=3 ]
「啊、不是……那个……」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:yoru:]
「做不到吗？明明之前那么盛赞这个世界的美好」[rhp]

[:sausu:][p_s_12][sausu kao=8 as=on ]
「……呜、你好过分……明明心知肚明」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="293" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=1 as=on ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width="330" height="720" wait="true" zindex="1005" time=150]

[:princess:]
「南，你觉得呢？[rhr]
_　让多洛普和落合君两个人都留在……」[rhp]

[:sausu:][p_s_34][sausu kao=12 ]
「……………抱歉。那是不可能的」[rhp]

[off_all]

[chara_part name="sora" body=base kao=4 as=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sora:]
「为什么。我已经死了。按条件来说——[rhp]

[:sausu:][p_s_30][sausu kao=8 ]
「你还活着。……尚未迎来死亡」[rhp]

[:sora:][p_so_19][sora kao=2 ]
「……哈？你……说什么胡话？不可能。因为夜明明……」[rhp]

[off_sausu]

[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:yoru:][p_y_15][yoru kao=0 ]
「那个男人说得对。你还未死去。[rhr]
_　和上次一样，仍处于假死状态」[rhp]

[:sora:][sora kao=6 ]
「怎……怎么会」[rhp]

[:yoru:][p_y_01][yoru kao=12 ]
「因为我不想成为杀人犯」[rhp]

[off_all]

[:sausu:][sausu kao=7 as=on ]
「………………」[rhp]

[off_all]

[chara_part name="kite" body=base kao=7 as=on ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=4 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width="330" height="720" wait="true" zindex="1005" time=150]

[:kite:][p_k_12]
「什么意思？」[rhp]

[:princess:][puri_w kao=3 ]
「来吧……」[rhp]

[off_all]

[chara_part name="sora" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sora:][p_so_11]
「…………原来你骗了我啊，夜」[rhp]

[:yoru:][yoru kao=6 ]
「谎言亦是权宜之计。但若不那么说，恐怕你真的会自尽」[rhp]
[:yoru:]
「不必担忧多洛普。[rhr]
_　我将多洛普的精神留存在你曾寄居的肉体中」[rhp]
[:yoru:]
「若将此刻在此的你精神归返肉体，[rhr]
_　多洛普也会被弹回此处」[rhp]

[:sora:][sora kao=6 ]
「多洛普怎样都无所谓！[rhr]
_　我说过自己的心意吧……！？明明刚以为终于得救了！」[rhp]

[:yoru:][yoru kao=12 ]
「这是私人恩怨」[rhp]

[:sora:][sora kao=0 ]
「……！」[rhp]

[:yoru:][p_y_27][yoru kao=0 ]
「我厌恶你企图利用我的本性。[rhr]
_　若被命令杀人就照办，我还没善良到那种程度」[rhp]
[:yoru:]
「所以我决定了。这次要由我来出其不意」[rhp]

[:sora:][p_so_19][sora kao=3 ]
「……这算什么啊……」[rhp]

[:yoru:][p_y_34][yoru kao=3 ]
「要恨就恨自己吧。这是对企图背叛我的惩罚，[rhr]
_　也是对遗忘被遗弃者心情的惩罚」[rhp]
[:yoru:]
「理央、武、千秋……还有你的双亲。[rhr]
_　会有许多人因你的死亡而悲伤」[rhp]
[:yoru:]
「他们的痛苦，你应该能深切体会到吧」[rhp]

[:sora:][sora kao=7 as=on ]
「…………」[rhp]

[off_all]

[:yoru:][p_y_17][yoru kao=8 ]
「哈啊……都怪我把你两次带进这个世界，[rhr]
_　好不容易恢复的灵力又白费了」[rhp]
[:yoru:]
「所以我讨厌小孩。任性又自私……」[rhp]

[off_all]

[chara_part name="mata" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="-10" top="0" wait="false" time=150]
[chara_part name="nusi" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="250" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="510" top="0" wait="false" time=150]
[chara_part name="gon" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="820" top="0" wait="true" time=150]

[:mataroko:]
「所以才不能放着不管呀！」[rhp]

[:gonzalez:]
「老实说不想杀同伴不就好了嘛」[rhp]

[:nusi:]
「真是的～夜先生太爱害羞啦～」[rhp]

[off_all]

[yurasu]
[se storage="hand_06.ogg"]

[chara_part name="nusi" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="168" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:nusi:][nusi kao=3 ]
「好痛！！！！！！」[rhp]

[:yoru:]
「难得开口说话，[rhr]
_　你们说的尽是些不像样的话」[rhp]

[off_all]

[:sora:][sora kao=3 ]
「……………………」[rhp]

[:princess:][puri_w kao=4 as=on ]
「落合君……原来你还活着……」[rhp]

[:sora:][p_so_01][sora kao=8 as=on ]
「……，啊啊。我……所以已经，不该在这里……」[rhp]

[:princess:][puri_w kao=13 hh=on ]
[font size=25]
「太好了啊啊！！」[rhp]
[resetfont]

[:sora:][sora kao=4 ]
「诶？」[rhp]

[:princess:][puri_w kao=5 ]
「落合君，原来你还活着……！[rhr]
_　真的太好了！我放心了」[rhp]

[:sora:][p_so_12][sora kao=2 ]
「为、为什么？明明要回那个世界了。[rhr]
_　刚才还说可以一起旅行，」[rhp]

[:princess:][puri_w kao=3 ]
「那是死了之后的情况吧。活着就另当别论！」[rhp]
[:princess:]
「因为是朋友啊。活着当然更让人开心啦！」[rhp]

[off_all]

[chara_part name="kite" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="sora" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:kite:]
「……我也。从一开始就不希望宙来这边」[rhp]
[:kite:]
「…………我放心了。真的」[rhp]

[:sora:][p_so_21][sora kao=6 as=on ]
「……，你们不会因为我要回去而感到寂寞的吗？」[rhp]

[:kite:][kite kao=3 ]
「虽说那样很寂寞。[rhr]
_　不过嘛，请允许我用句老套的话来说……」[rhp]
[:kite:]
「希望你能替我们那份也活下去」[rhp]

[:sora:][sora kao=2 hh=on ]
「…………」[rhp]

[off_all]

[chara_part name="kite" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=13 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width="330" height="720" wait="true" zindex="1005" time=150]

[:kite:]
「刚才的台词帅吗？」[rhp]

[:princess:][puri_w kao=14 ]
「如果不这么说的话呢」[rhp]
[:princess:]
「……但我也怀着同样的心情」[rhp]

[off_all]

[:sora:][sora kao=8 ]
「…………」[rhp]

[:yoru:][yoru kao=0 ]
「…………你怎么想，宙。即便这样还是想死吗」[rhp]

[:sora:][sora kao=6 as=on ]
「………，………哈……」[rhp]
[:sora:]
「…………话都说到这份上，再闹别扭就太孩子气了」[rhp]

[off_all]

[chara_part name="kite" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=14 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width="330" height="720" wait="true" zindex="1005" time=150]

[:kite:]
「可喜可贺可喜可贺」[rhp]

[:princess:][puri_w kao=1 hh=on ]
「太好了……！」[rhp]

[off_all]

[:sausu:][sausu kao=3 ]
「……………」[rhp]

[:yoru:][p_y_16][yoru kao=5 ]
「……有个人我帮你抢回来了。接下来有好戏看了」[rhp]

[:sausu:][p_s_28][sausu kao=2 ]
「宙可是你召唤来的。[rhr]
_　对我来说是正负抵消呢」[rhp]
[:sausu:]
「况且至少现在，他们完全没有离开这里的意识。[rhr]
_　想必是真心渴望在这里继续旅程吧」[rhp]

[:yoru:][yoru kao=12 ]
「但终究会醒悟的。[rhr]
_　死亡的世界里怎么可能存在真正的幸福」[rhp]

[:sausu:][p_s_17][sausu kao=0 ]
「哈……也罢……[rhr]
_　就算只有你一个人不能理解也……」[rhp]

[off_all]

[:yoru:][p_y_04][yoru kao=1 ]
「――――――宙。差不多该走了」[rhp]

[off_all]

[:sora:][p_so_01][sora kao=3 ]
「啊。再拖下去只会更舍不得……」[rhp]

[off_all]

[chara_part name="kite" body=base kao=1 as=off ss=off hh=on hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="sora" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sora:]
「…………快斗」[rhp]
[:sora:]
「一定要幸福啊。绝对要」[rhp]

[:kite:][kite kao=5 ]
「不用你说也本来就会这样」[rhp]
[:kite:]
「啊……对了。还有一件事」[rhp]

[:sora:][sora kao=7 ]
「嗯？」[rhp]

[:kite:][p_k_07][kite kao=13 hh=on ]
「就算是这种形式也好。那个『约定』，能实现真是太好了呢」[rhp]

[:sora:][sora kao=2  ]
「哈……？约定？」[rhp]

[:kite:][kite kao=3 as=on ]
「连宙都忘了？你们可真过分啊」[rhp]
[:kite:]
「……毕业旅行」[rhp]

[:sora:][sora kao=4 hh=on ]
「…………？　…………」[rhp]
[:sora:]
「…………――――――！！啊」[rhp]

[off_all]

[:princess:][puri_w kao=13 hh=on ]
「说到毕业旅行难道说我们、是同一所学校的学生！？[rhr]
_　这可能是超重要的线索……！」[rhp]

[:kite:][kite kao=6 ]
「不不是的」[rhp]

[:princess:][puri_w kao=3 ]
「啊、这、这样啊……什么嘛」[rhp]

[off_kite]

[:sora:][sora kao=1 hh=on ]
「…………这样啊」[rhp]

[::]
落合君的声音沙哑了，湿润的眼瞳微微眯起。[rhp]
他稍稍垂下视线凝视地面，如同自问般继续说道。[rhp]

[:sora:][sora kao=3 hh=on as=on ]
「……我……没有错呢」[rhp]
[:sora:]
「走到这一步，并非什么都没得到是吧……？」[rhp]

[off_all]

[::]
快斗轻轻拍了拍他垂落的肩膀。[rhp]

[:kite:][p_k_08][kite kao=12 ]
「不过嘛，那个啊。旅行要直到回家才算结束啦」[rhp]
[:kite:]
「……没落下东西吧？」[rhp]

[off_all]

[::]
快斗沉默地伸出右手。[rhr]
落合君略带惊讶地接过，片刻后回握住眼前的手。[rhp]
那表情像是在笑，又仿佛透着些许寂寞。[rhp]

[:sora:][p_so_02][sora kao=3 hh=on ]
「……没有啊。已经什么都不剩了」[rhp]
[:sora:]
「你可要幸福啊。……这次绝对要」[rhp]

[:kite:][kite kao=13 ]
「说什么呢挚友。托你们的福，我已经很幸福了」[rhp]

[:sora:][sora kao=1 ]
「这样啊…」[rhp]
[:sora:]
「…………那就已经，放心了」[rhp]

[off_all]

[::]
平静却直击心底的坚定话语。[rhr]
他的眼中已不再有迷茫。[rhp]
当我正凝视着他时，他突然转头看向这边。[rhr]
仿佛要制止欲言又止的我，他轻轻笑了笑转过身去。[rhp]
就像是表明，并不打算听取告别的话语。[rhp]

自南手中溢出的光芒逐渐增强，[rhr]
落合君的身影渐渐被那片白色闪光吞没。[rhp]
我眯起眼睛注视着那个身影，[rhr]
但始终不愿完全闭上般地烙印在眼底。[rhp]

……想要铭记此刻。[rhp]
所以这次，绝不会再遗忘。[rhp]

;****************************************
[fbgm]
[set_w storage="train_03.jpg"]
[free_filter ]
[bgm storage="bgm_19.ogg"]
;****************************************

同一时刻[rhp]

[:quadrillion:][p_r_18][riri kao=6 ]
「哈～～～～～……」[rhp]
[:quadrillion:]
「……上面现在大概正在上演某些[rhr]
_　感人戏码吧……」[rhp]

[off_all]

[chara_part name="jet" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:][p_h_09]
「啊啊！要是赛跑我也能参加就好了！」[rhp]

[:jet:][p_j_04][jet kao=2 ]
「绝对是哈蒂会赢啦」[rhp]

[off_all]

[chara_part name="riri" body=base kao=3 as=off ss=off hh=on hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="yabu" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="yabu" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:quadrillion:]
「我们为什么非得看家啊？」[rhp]

[:yabu:][p_yb_02][yabu kao=8 ]
「太吵了。有你们在根本没法谈正事」[rhp]

[:quadrillion:][riri kao=13 ]
「哈～～？唯独不想被矢部亲这么说啦！[rhr]
_　明明刚才还在嚷嚷着该名医出场了ー就你吵得最大声」[rhp]
[:quadrillion:]
「突然变得这么安静，该不会是吃了什么奇怪的东西吧？」[rhp]

[:yabu:][yabu kao=2 ]
「胡说什么，名医怎么会闹肚子。[rhr]
_　……对了！就是那个～……我讨厌被人提起过去的事！」[rhp]
[:yabu:]
「你也一样吧，夸德里利昂。[rhr]
_　我特别是像这样，感觉肚子里刺刺的……」[rhp]

[:quadrillion:]
「不是吃坏肚子」[rhp]

[:yabu:][yabu kao=6 ]
「才不是！！」[rhp]

[off_all]

[:jet:][p_j_24][jet kao=8 as=on ]
「我好像隐约明白我们没被上面传召的理由了……」[rhp]
[:jet:]
「不过无所谓啦。正如矢部所说，我们对过去之类的事本来就没兴趣」[rhp]

[off_all]

[:mika:][mika kao=2 ]
「～～～～～…………」[rhp]

[off_all]

[chara_part name="hati" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="mika" body=base kao=0 as=off hh=off hr=on ]
[chara_show name="mika" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:]
「米卡亲？你明显摆着张臭脸怎么了！？」[rhp]

[:mika:][mika kao=2 ]
「没什么啦……」[rhp]

[off_hati]

[chara_part name="jet" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="true" time=150]

[:jet:]
「是因为南在才不高兴吧。[rhr]
_　明明他不是那么招人讨厌的家伙，真奇怪啊」[rhp]

[:mika:][p_mk_09][mika kao=12 ]
「………………哼。杰特君才不会懂啦！」[rhp]

[off_all]

[:mika:][mika kao=2 ]
「―――ー啊啊！为什么事情就不顺利呢。[rhr]
_　难得刚给宙君处理完伤势，急急忙忙赶过来的说」[rhp]
[:mika:][mika kao=2 ]
「说到底夜君太心软了。这种机会可不多见。[rhr]
_　孩子们全部不由分说赶出去就行啦」[rhp]

[off_all]

[chara_part name="jet" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:][p_h_30]
「别这么轻描淡写地说可怕的事啊」[rhp]

[:jet:][p_j_18][jet kao=7 ]
「随便反抗的话会很危险吧……」[rhp]

[off_all]

[chara_part name="yabu" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="yabu" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="mika" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="mika" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:mika:][p_mk_12]
「哈——啊！要是早点看开南的事，让我出面处理的话。[rhr]
_　那样夜君说不定也会顺势进展顺利呢」[rhp]
[:mika:]
「呐老师！你不这么想吗？」[rhp]

[:yabu:][p_yb_20][yabu kao=5 as=on ]
「！啊、啊啊……算是吧。[rhr]
_　无需多言……嗯！那也是好主意！」[rhp]

[:mika:][mika kao=12 ]
「～～～～啊啊这样啊。老师也太过天真了呢」[rhp]

[:yabu:][p_yb_30][yabu kao=3 as=on ]
「咦、不是所以我」[rhp]

[off_all]

[:mika:][p_mk_09][mika kao=2 ]
「我可不会像老师和夜君那样天真……！」[rhp]
[:mika:]
「事到如今干脆现在就夺取这辆电车，[rhr]
_　让这种世界立刻解散吧」[rhp]

[off_all]

[:quadrillion:][riri kao=2 as=on ]
「等、米卡亲！那样的话……」[rhp]

[off_all]

;****************************************
#
[se storage="mag_08.ogg"]
[bg storage="white.jpg" time=1000]
;****************************************

[:quadrillion:]
「……！？突然怎么了？！」[rhp]

[:unknown:]
「请稍等一下！」[rhp]

[:quadrillion:]
「！这个声音是……」[rhp]

;****************************************
[bg storage="train_03.jpg" time=1000]
;****************************************

[:drop:]
「让各位久等了非常抱歉……」[rhp]

[:drop:][drop kao=14 ]
「……谢谢你们给的长期休假！」[rhp]

;****************************************
[set_w storage="train_10.jpg"]
; 夜フィルター
[filter layer="1" brightness="60"]
;****************************************

[::]
沐浴在光芒中，落合君和南回到了现实世界。[rhr]
因为不想和他们同行，最终没有一起离开的夜。[rhp]
他最后回头望了我一眼，轻轻叹了口气。[rhp]

[:yoru:][p_y_24][yoru kao=12 ]
「……给你添麻烦了」[rhp]

[:princess:][puri_w kao=1 hh=on ]
「落合君还活着啊。多亏了夜……」[rhp]

[:yoru:][yoru kao=7 ]
「幸亏他是个纯粹的孩子，无论好坏……如果骗不了他，[rhr]
_　我原本打算就算绑也要阻止那个愚蠢的提议」[rhp]

[off_all]

[::]
夜一边说着，一边将视线投向我。[rhp]
这是对主张多洛普和落合君两人都留在这里的[rhr]
我的一种叮嘱吧。[rhp]
……如今知道落合君还活着，对他的话我并无异议。[rhp]

[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="293" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=13 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width="330" height="720" wait="true" zindex="1005" time=150]

[:princess:]
「……我也觉得，活着绝对更好」[rhp]

[:yoru:][p_y_06][yoru kao=6 ]
「真不像是会留在这个地方的人该说的话」[rhp]

[:princess:][puri_w kao=3 ]
「……！不、那个」[rhp]

[off_all]

[::]
对了。我曾向他承诺过迟早要离开这个世界。[rhp]
不仅说要下这趟铁道，还说出鼓励滞留的言论，[rhr]
夜当然会感到不愉快吧。[rhp]

[chara_part name="kite" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:yoru:][p_y_08]
「话虽如此，在这个世界里我的话根本传不到宙耳中。[rhr]
_　若醒不过来便与死亡无异。这部分也算是场赌博……」[rhp]
[:yoru:]
「……唤醒他眼睛的是和近。该道声谢」[rhp]

[:kite:][kite kao=7 ]
「希望能叫我快斗。我已经……」[rhp]

[:yoru:][yoru kao=12 ]
「不，和近。……那就交给你吧」[rhp]
[:yoru:]
「她的记忆由你来恢复」[rhp]

[:kite:][p_k_13][kite kao=4 ]
「…………！」[rhp]

[:yoru:][yoru kao=3 ]
「在回忆起一切之后，由你们两人自行决定自己的存在方式吧」[rhp]
[:yoru:]
「…………在那之前，我也会尽量不加以干涉」[rhp]

[:kite:][kite kao=3 as=on ]
「夜……」[rhp]

[off_all]

[chara_part name="nusi" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="gon" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:nusi:][p_ns_31]
「虽然可能难以理解，但这算是夜先生独特的贺礼啦」[rhp]

[:gonzalez:][p_gn_24][gon kao=1 hh=on ]
「因为他是一路守护着你们俩走过来的人啊」[rhp]

[off_all]

[:yoru:][yoru kao=2 ]
「吵死了。……迟早会让你们下车的。[rhr]
_　或早或晚，那个未来绝对会到来」[rhp]

[off_all]

[::]
他再次将目光投向我。[rhr]
那眼神比方才平静了几分。[rhp]

[:yoru:][p_y_01][yoru kao=11 ]
「终究是有限的梦。既然留在这里，就别让自己后悔。[rhr]
_　别忘了还有人会为你的死亡哀叹」[rhp]

[off_all]

[:princess:][puri_w kao=14 hh=on ]
「嗯。……谢谢」[rhp]

[off_all]

[::]
纵使无法唤回记忆，这个事实我仍然能够理解。[rhr]
我必定在现实世界留下了诸多牵挂。[rhp]
虽说过要消除未了心愿再离开这个世界，[rhr]
但那些牵绊应该不在眼前这个世界，而在那边的世界吧。[rhp]
即便如此，在终结时刻来临之前，[rhr]
我还是选择了和快斗一起留在这里。[rhp]
对这个选择，我绝不后悔。[rhp]

[:yoru:][yoru kao=0 ]
「那就这样，我也该走了」[rhp]

[off_all]

[chara_part name="mata" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="-10" top="0" wait="false" time=150]
[chara_part name="nusi" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="250" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="510" top="0" wait="false" time=150]
[chara_part name="gon" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="820" top="0" wait="true" time=150]

[:nusi:][p_ns_02]
「多保重啊，夜先生」[rhp]

[:gonzalez:][p_gn_31][gon kao=13 hh=on ]
「我会写信的！」[rhp]

[:yoru:][p_y_09][yoru kao=2 as=on ]
「你们……在南分配的本轮魔力耗尽之前[rhr]
_　打算留在这里吧，其实你们来这里我也是反对的……」[rhp]

[:mataroko:][p_mt_26][mata kao=5 hh=on ]
「我们很清楚哦。等本轮魔力用完就会回去的」[rhp]
[:mataroko:]
「我们可不兴攒隔夜钱。魔力也是一个道理呀！」[rhp]

[:yoru:][yoru kao=12 ]
「真是……令人无语的家伙们」[rhp]

[off_all]

[:yoru:][p_y_34][yoru kao=0 ]
「……替我跟多洛普带个好。[rhr]
『没能好好招待真是抱歉』这样说」[rhp]

[:princess:][puri_w kao=4 hh=on ]
「多洛普？他已经回来了吗！？」[rhp]

[:yoru:][yoru kao=11 ]
「和宙做了轮换。你去车厢里看看就知道了」[rhp]

[:princess:][puri_w kao=14 hh=on ]
「嗯！明白啦！」[rhp]

[off_all]

[::]
夜好像若有似无地轻笑了一声？或许是错觉吧。[rhr]
就算直直盯着看，他也早已恢复成那张万年臭脸。[rhp]

;****************************************
[se storage="mag_08.ogg"]
[bg storage="white.jpg" time=500]
;****************************************

他打了个响指，夜就被与方才相似的光芒笼罩。[rhp]
……随后那光芒逐渐消散殆尽。[rhp]

;****************************************
[fbgm]
[set_w storage="train_10.jpg" time=1500]
;****************************************

我睁开因强光而紧闭的双眼。[rhp]
…………那里已经不见宙君他们的身影。[rhp]

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
[vostart]
;--------------------------------------------------------------------------------------------

[:princess:][puri_w kao=4 ]
「……走了呢」[rhp]

[:kite:][kite kao=3 ]
「真是群来去如风的家伙……」[rhp]

[off_all]

[bgm storage="bgm_29.ogg"]

[::]
简直像暴风雨过境后的场景。[rhr]
明明松了口气，但这骤雨初歇的静谧却莫名令人感到怅然。[rhp]

[chara_part name="mata" body=base kao=13 as=off ss=off hh=on hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="nusi" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="gon" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="720" top="0" wait="true" time=150]

[:mataroko:]
「太好了呢，兄长大人，姐姐大人！[rhr]
_　这样就能安心继续旅程了！」[rhp]

[:nusi:][nusi kao=5 hh=on ]
「多亏了我家玛塔子和拼命的小刚啊。要好好感谢哦」[rhp]

[:gonzalez:][gon kao=12 as=on ]
「其实我现在腋下还在狂冒汗」[rhp]

[off_all]

[:princess:][puri_w kao=1 hh=on ]
「也谢谢你们三位。[rhr]
_　大家努力的心意，我绝不会辜负」[rhp]

[:mataroko:][mata kao=13 hh=on ]
「是……！是，是的！绝对会的，姐姐大人！」[rhp]
[:mataroko:]
「请一定要收获满满的幸福！[rhr]
_　光是那样魔太郎子就是全世界最幸福的人了！」[rhp]

[:princess:][puri_w kao=4 hh=on ]
「话说那个‘兄长大人’的称呼到底怎么回事？[rhr]
_　刚才你想说的时候被快斗打断没听到呢」[rhp]

[:mataroko:][mata kao=5 ]
「这是因为呀。快斗先生年幼时，曾和姐姐大人一起……」[rhp]

[off_all]

[se storage="hand_05.ogg"]
[yurasu]

[chara_part name="mata" body=base kao= as=off ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:mataroko:][mata kao=3 ]
「咿呀！！」[rhp]

[:kite:][kite kao=6 ]
「魔太郎子～～～～～。[rhr]
_　这侵犯隐私了啦」[rhp]

[:mataroko:][mata kao=8 as=on ]
「对、对不起……是我冒失了……」[rhp]

[:princess:][puri_w kao=6 ]
「居然要打到阻止为止……总觉得很可疑！」[rhp]

[:kite:][kite kao=5 ]
「在意的话就自己查出来看看啊」[rhp]

[off_all]

;****************************************
[still storage="cg/d_k_4.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/d_k_4.png"]
;****************************************

[:kite:]
「……幸运的是，我们好像有很多时间」[rhp]

[:princess:]
「！」[rhp]

[:kite:]
「宙真是个大人呢。……不，是变成大人了吗。[rhr]
_　在那家伙游刃有余的样子面前，我可能确实还是个孩子吧」[rhp]
[:kite:]
「可是我啊，不管多么难看……[rhr]
_　都确实赢过那家伙了」[rhp]
[:kite:]
「…………快点想起我来吧。[rhr]
_　不论是土气的地方，还是帅气的地方，全部」[rhp]
[:kite:]
「从今以后可要只看着我一个人啊」[rhp]
[:kite:]
「…………我也绝对不会再放弃这份感情了」[rhp]

[:princess:]
「…………！……当然了」[rhp]
[:princess:]
「总有一天一定能找回记忆。[rhr]
_　无论现在还是过去，都能挺起胸膛说喜欢你」[rhp]
[:princess:]
「我想回应你的心意，因为想变回『真正的我』。[rhr]
_　虽然可能要花些时间……」[rhp]
[:princess:]
「…………在那之前，会一直喜欢我吗？」[rhp]

[:kite:]
「这不是当然的吗。[rhr]
_　连同过去和现在一起，[player3b]都是我的最爱」[rhp]
[:kite:]
「谢谢你能再度来到我身边」[rhp]

[:princess:]
「……嗯！」[rhp]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------
[::]
我活在这广阔的世界里。[rhp]
想去到尽可能远的地方，直到足迹的尽头。[rhp]
在心爱之人身旁，只余欢喜的泪水。[rhr]
不愿在终将来临的那一刻徒留悔恨。[rhp]
纵使飘摇于黑暗银河，也想永远保持晴空般的心情。[rhp]
无论将来忆起过往时的我会作何感想，变回何等模样，[rhr]
都要让『此刻在此的公主』能挺起胸膛说曾经幸福过。[rhp]
面朝前方，一次次如此宣告。[rhr]
我的最爱，也正是此刻当下。[rhp]

;****************************************
[fbgm]
[still_end frame="win.png" storage="white.jpg" time=1000]
;****************************************

为了不让满溢的思念洒落，我正静静闭目之时。[rhp]
无意识间点亮眼睑内侧的光景。[rhr]
泼撒颜料般的青蓝中，一缕浮云。[rhp]
浮现那刻，脑海掠过闪光。[rhp]

[bgm storage="bgm_40.ogg"]

啊啊。[rhp]
…………啊啊。[rhp]
没错――――――[rhp]

……我、承诺过的。[rhp]

;****************************************

[s_mask color=0xffffff time=3000]
; 背景表示
[bg storage="hsps_08.jpg" time=100]
[free_filter ]
; ウィンドゥの設定
[position layer="message0" frame="win2.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[s_mask_off time=3000]

;****************************************


[:himeko:]
「――――――我回来了！！」[rhp]

[:kazutika:][kazu kao=4 as=on chair=off]
「！　诶……[player3]？」[rhp]

[off_all]

[chara_part name="kazu" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="kazu" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:kazutika:]
「为什么？明明应该去了中庭的……」[rhp]

[:himeko:][hime2 kao=6 ]
「果然又回来了。[rhr]
_　从窗户看到和君寂寞地和魔太郎子玩着呢」[rhp]

[:kazutika:][kazu kao=2 hh=on as=on chair=off]
「！！！！！　什什什、什么啊那个！看看、看错了吧！」[rhp]

[off_hime2]

[chara_part name="otiai" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sora:]
「不 不是的」[rhp]

[:kazutika:][kazu kao=8 chair=off]
「！？　宙……！？什、什么时候」[rhp]

[:sora:][otiai kao=5 ]
「那个确实玩过。绝对是一个人玩过家家」[rhp]

[:kazutika:][kazu kao=3 as=on chair=off]
「所以说没玩过啦！　那么老土的事……！[rhr]
_　话说你为啥在这儿啊。我可没听说你要来」[rhp]

[:sora:][otiai kao=0 ]
「我向来不提前打招呼啊……我刚到不久。[rhr]
_　今天是薰的月忌日，扫墓顺便过来看看」[rhp]

[:kazutika:][kazu kao=6 chair=off]
「时机真糟糕……」[rhp]

[:sora:][otiai kao=1 ]
「对了和近。[rhr]
_　[player2]听说了哦。说你不愿意出门」[rhp]

[:kazutika:]
「那又怎样……跟我没关系吧。[rhr]
_　矢部也说过别勉强自己啊！」[rhp]

[off_otiai]

[chara_part name="hime2" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:himeko:]
「如果和君也一起参加的话，[rhr]
_　宙君也说过要一起打排球哦」[rhp]

[:kazutika:][kazu kao=8 as=on chair=off]
「这根本不是对轮椅人士的要求啊！」[rhp]

[off_hime2]

[chara_part name="otiai" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sora:]
「坐着也能接球。[rhr]
_　把球打回去就是排球了」[rhp]

[:kazutika:][kazu kao=2 as=on ]
「你、你们是认真的吗……！？」[rhp]

[off_all]

[:kazutika:][kazu kao=3 chair=off]
「总之不用管我。要玩你们两个……」[rhp]

[chara_part name="otiai" body=base kao=5 as=off ss=off hh=on hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=13 as=off ss=off hh=on hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:2nin:]
「无需多言」[rhr]
「抗议无效！！！」[rhp]

[:kazutika:][kazu kao=2 as=on ss=on chair=off]
「诶……――――――哇啊！？」[rhp]

[off_all]

[se storage="body_07.ogg"]

[::]
在我来得及抵抗之前，宙和[player3]已[rhr]
经用熟练的动作把我按进轮椅里。[rhp]
虽然试图强行挣脱，[rhr]
但轮椅已经启动，完全无计可施。[rhp]
无可奈何之下，只好扭动上半身做最后挣扎。[rhp]

[:kazutika:][kazu kao=2 as=on ss=on ]
「等等！你们干什么！？快停下！！」[rhp]

[:himeko:][hime2 kao=13 ]
「才不要呢！人家就想和和君一起出去玩嘛！」[rhp]

[:kazutika:][kazu kao=6 as=on ]
「我要告诉矢部！」[rhp]

[:himeko:][hime2 kao=5 hh=on ]
「才不怕呢ー！」[rhp]

[off_all]

[:sora:][otiai kao=13 ]
「放弃吧。[player2]说服他们是没用的」[rhp]

[off_all]

[:kazutika:][kazu kao=2 as=on ]
「呜、呜哇啊……！」[rhp]

[off_all]

;*****************************************
#
[bg_rule storage="hsps_10.jpg" rule="002.png" time=1000]
;*****************************************
[::]
在这般问答重复之间，[rhr]
载着我的轮椅被两人推着来到了中庭。[rhp]

[:kazutika:][kazu kao=12 as=on hh=on ]
「你们……！　这可真不是什么开玩笑的事。[rhr]
_　对病人做这种事，我家的怪兽家长可不会默不作声」[rhp]

[:himeko:][hime2 kao=6 ]
「说什么呢？和君妈妈明明超级温柔的」[rhp]

[:kazutika:][kazu kao=6 as=on hh=on ]
「唔呃……」[rhp]

[:himeko:][hime2 kao=13 ]
「而且你看，果然还是外面更舒服吧？」[rhp]

[:kazutika:][kazu kao=6 ]
「没什么区别……已经够了啦。在矢部发现前快回、」[rhp]

[off_all]

[:himeko:][hime2 kao=4 ]
「哇！快看那边！」[rhp]

[off_all]

[:kazutika:][kazu kao=7 ]
「……？什么……」[rhp]

[off_all]

;*****************************************
#
[bg storage="sky_04b.jpg" time=1000]
;*****************************************

[:kazutika:]
「……………！」[rhp]

[:himeko:]
「好厉害！是飞机云！」[rhp]

[:sora:]
「有那么稀奇吗？」[rhp]

[:himeko:]
「稀奇！待在房间里很少有机会看到嘛」[rhp]

[:sora:]
「这样啊……不过确实挺漂亮的」[rhp]

[:kazutika:]
「………………」[rhp]

;*****************************************
#
[bg storage="hsps_10.jpg" time=1000]
;*****************************************

[chara_part name="otiai" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="kazu" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="kazu" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="760" top="0" wait="true" time=150]

[:sora:]
「……和近你喜欢飞机之类的吗？」[rhp]

[:kazutika:]
「……！　不，无所谓」[rhp]

[:himeko:]
「喜欢啊！但最近已经毕业啦～因为显得太孩子气」[rhp]

[:kazutika:][kazu kao=6 as=on ]
「为什么[player3]要你代答啦」[rhp]

[:sora:][otiai kao=13 hh=on ]
「我也挺喜欢。还想早点试试开车呢」[rhp]

[:kazutika:][kazu kao=12 ]
「…………，嘛宙倒是没问题吧。[rhr]
_　反正我也坐不了，那种东西」[rhp]

[:sora:][otiai kao=0 ]
「为什么？」[rhp]

[:kazutika:][kazu kao=6 as=on ]
「为什么……那个……」[rhp]

[:sora:][otiai kao=5 ]
「病我会治好的，车很快就能开的」[rhp]

[:kazutika:][kazu kao=0 as=on ]
「…………！」[rhp]

[:sora:]
「[player2]打算怎么办？长大以后要开车吗？」[rhp]

[:himeko:][hime2 kao=13 hh=on ]
「比起汽车我更喜欢飞机！」[rhp]

[:sora:][otiai kao=2 as=on ]
「是啊……」[rhp]

[:kazutika:][kazu kao=6 as=on ]
「想当飞行员啊。就算病好了也够呛吧」[rhp]

[:himeko:][hime2 kao=2 hh=on ]
「真是的～～老是挑刺。当然是当乘客啦！」[rhp]
[:himeko:]
「宙君坐过飞机吗？」[rhp]

[:sora:][otiai kao=12 ]
「坐过」[rhp]

[yurasu]

[:himeko:][hime2 kao=13 hh=on ]
[font size=30]
「好～～羡慕啊！！」[rhp]
[resetfont]

[:sora:][otiai kao=2 ]
「吵死了」[rhp]

[:kazutika:][kazu kao=3 ]
「………………」[rhp]

[off_all]

[:kazutika:]
「………………、真好啊」[rhp]

[:himeko:][hime2 kao=5 ]
「……！　和君也这么想吗？」[rhp]

[:kazutika:][kazu kao=7 as=on ]
「！　什、什么嘛……不行吗」[rhp]

[:himeko:][hime2 kao=14 ]
「没有不行啦～。[rhr]
_　……对了！我突然想到个好主意！」[rhp]
[:himeko:]
「总有一天，我们三个一起去旅行吧！[rhr]
_　难得是同班同学，好想试试毕业旅行什么的！」[rhp]
[:himeko:]
「坐着飞机去很多国家。你们不觉得很棒吗！？」[rhp]

[off_all]

[:kazutika:]
[font color=0x4682b4]
（真是傻瓜。这种事怎么可能―――）[rhp]
[resetfont]

[chara_part name="otiai" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kazu" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="kazu" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sora:]
「[player2]不过倒是个不错的主意」[rhp]

[:kazutika:][kazu kao=6 as=on ]
「喂……连宙都说什么呢」[rhp]

[:sora:][otiai kao=13 hh=on ]
「我是会去啦快斗呢？不想去的话留下来看家也行哦」[rhp]

[:kazutika:][kazu kao=2 hh=on ]
「～～～～……」[rhp]

[off_all]

[chara_part name="otiai" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="kazu" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="kazu" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="760" top="0" wait="true" time=150]

[:kazutika:]
「…………、真拿你没办法」[rhp]

[:himeko:][hime2 kao=14 hh=on ]
「太好啦！」[rhp]

[:kazutika:][kazu kao=13 ]
「[player2]和宙一起的话会让人担心。[rhr]
_　没有我这个气氛担当在场的话，对话估计都进行不下去」[rhp]

[:sora:][otiai kao=6 ]
「真麻烦的家伙」[rhp]

[:kazutika:][kazu kao=2 as=on ]
「吵死了！」[rhp]

[:himeko:][hime2 kao=1 hh=on ]
「大家有什么想去的地方吗？」[rhp]

[:kazutika:][kazu kao=7 ]
「没什么特别的。近处还行，要坐飞机去的地方就……」[rhp]

[:kazutika:][kazu kao=6 ]
「我也是。但既然[player3]啊？[rhr]
_　是你提出来的总该有点想法吧」[rhp]

[:himeko:][hime2 kao=5 ]
「我的话呀，要环游世界！！」[rhp]

[off_all]

[chara_part name="otiai" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kazu" body=base kao=3 as=on ss=off hh=off hr=on ]
[chara_show name="kazu" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sora:]
「…………还好有快斗在」[rhp]

[:kazutika:]
「我也是。光靠我一个人可应付不来[player3]这个笨蛋」[rhp]

[off_all]

[:himeko:][hime2 kao=2 hh=on ]
「真是的，梦想当然要远大点才好啊！」[rhp]

[off_all]

[chara_part name="otiai" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kazu" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="kazu" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:kazutika:][kazu kao=7 ]
「就是太大过头了啊」[rhp]

[:sora:][otiai kao=6 ]
「这规模完全不像毕业旅行啊……」[rhp]
[:sora:][otiai kao=11 ]
「……倒也不坏」[rhp]

[off_all]

[:himeko:][hime2 kao=14 hh=on ]
「呵呵……！真令人期待啊。[rhr]
_　大家可要好好记住哦？」[rhp]

[off_all]

[chara_part name="otiai" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kazu" body=base kao=11 as=off ss=off hh=on hr=on ]
[chara_show name="kazu" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:kazutika:]
「是是」[rhp]

[:sora:]
「这是『约定』呢」[rhp]

[off_all]


;*****************************************
#
[bg storage="sky_04b.jpg" time=1000]
;*****************************************

[:himeko:]
「就算长大了也不要忘记。我们一定要去哦！」[rhp]
[:himeko:]
「不管世界哪个角落，我们三个人一起！」[rhp]

#

[jump storage="ev_d.ks" target="*ending"]