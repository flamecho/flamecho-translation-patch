﻿
*start

;--------------------------------------------------------------------------------------------
;▼フルボイスセット▼
;オチアイ
[voconfig sebuf=1 name=otiai vostorage="otiai/full/{number}.ogg" number=55]
;糠星の夜
[voconfig sebuf=1 name=yoru vostorage="yoru/full/{number}.ogg" number=77]
;--------------------------------------------------------------------------------------------

[:princess:][puri_w kao=12 ]
「……………………嗯～」[rhp]

[off_all]

[::]
……用『在意的人』这种说法，简直像是在恋爱一样。[rhp]
如果真有这样的人存在，邀请对方就行了吧，[rhr]
但我并没有特别在意的人，该怎么办呢。[rhp]

[:princess:]
[font color=0x4682b4]
（…………啊）[rhp]
[resetfont]

[::]
虽然不是恋爱，但在意的人确实有一个。[rhp]

[:princess:]
[font color=0x4682b4]
（落合君……）[rhp]
[resetfont]

[::]
对于那个依旧态度生硬、不愿与人亲近的落合君，[rhr]
我一直都放心不下。[rhp]

[:princess:][puri_w kao=5 ]
「……嗯！说得对。这样就好」[rhp]

[off_all]

[::]
决定了。试着邀请落合君吧。[rhr]
难得成为同伴，希望他能尽情享受这次旅行。[rhp]

[:princess:][puri_w kao=5 ]
「好……！既然这么决定了！」[rhp]

;****************************************
[set_00 storage="train_01.jpg"]
;****************************************

[:otiai:][otiai kao=4 as=on ]
「……我？」[rhp]

[:princess:][puri_w ]
「对！要不要一起逛祭典？」[rhp]

[:otiai:][otiai kao=1 as=on ]
「………………、…………」[rhp]

[:princess:][puri_w kao=6 as=on ]
「那个……不行吗？」[rhp]

[:otiai:][p_ot_21]
「不、不是不行……」[rhp]
[:otiai:][otiai kao=6 as=on ]
「……比起我，应该还有其他更适合邀请的人吧」[rhp]

[:princess:][puri_w kao=0 ]
「？你说谁？」[rhp]

[:otiai:]
「我哪知道。问我这种问题我也很困扰啊」[rhp]

[:princess:][puri_w kao=13 ]
「那就没问题啦。我想和落合君一起逛嘛。[rhr]
_　把祭典变成开心的回忆吧！」[rhp]

[:otiai:][otiai kao=2 as=on ]
「………………、…………」[rhp]

[:princess:][puri_w kao=6 ]
「好不好？」[rhp]

[:otiai:][otiai kao=8 as=on ]
「知、知道了啦。简直像小孩子一样」[rhp]

[:princess:][puri_w kao=14 ]
「嘿嘿！　在落合君面前说不定会变成这样呢」[rhp]

[:otiai:][p_ot_14][otiai kao=6 ]
「根本分不清谁才是大人了，这样子……」[rhp]
[:otiai:]
「……真拿你没办法，带队照顾你也不是不行」[rhp]

[:princess:][puri_w kao=2 as=on hh=on ]
「带队！？」[rhp]

[:otiai:][otiai kao=7 ]
「人肯定会特别挤，可别擅自乱跑啊」[rhp]

[off_all]

[:otiai:]
「那。待会儿见」[rhp]

[::]
说完恰到好处的失礼台词后，[rhr]
落合君干脆地转身离去。[rhp]
被独自留下的我。[rhr]
……砰，无机质般紧闭的门声更显凄凉。[rhp]

[:princess:][puri_w kao=11 as=on ]
「呜……！　呵、呵呵……这种程度可不会让公主殿下生气哦……[rhr]
_　　反正到了祭典时肯定会像小孩子一样闹腾吧！ 我都看透你了！」[rhp]
[:princess:][puri_w kao=5 as=on hh=on ]
「落合君！　我绝对要让你变回童心模样！」[rhp]

;****************************************
[fbgm]
[set_n storage="sky_07.jpg"]
;****************************************

[::]
银河铁道在数小时后抵达了目标星球。[rhp]
我们换上夸德里利昂挑选准备的浴衣，[rhr]
终于踏上了那片土地。[rhp]

;****************************************
[bg storage="fes_01.jpg" time=1000]
[bgm storage="bgm_26.ogg"]
;****************************************

列车停靠在一处稍高的位置，[rhr]
面对着通往宽阔神社的漫长石阶。[rhp]

「夏日祭之星」永远沉浸在傍晚时分的氛围中，[rhr]
慵懒的闷热感令人联想到初夏。[rhp]
鲜红的灯笼将微暗的夜色明亮地映照，[rhr]
台阶上方传来太鼓和笛子的乐声，空气中飘荡着独特的甜香。[rhp]

尚未目睹的景象让心跳加速，[rhr]
迫不及待想快点跑上这段台阶。[rhp]

[chara_part name="jet" body=yukata kao=5 as=off ss=off hh=on hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=yukata kao=5 as=off ss=off hh=on hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:][p_h_14]
「这、这就是……！夏日祭典！太厉害了！」[rhp]

[:jet:][p_j_14]
「明明只看见灯笼和台阶就已经兴奋起来了！」[rhp]

[off_all]

[chara_part name="riri" body=yukata kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="kite" body=yukata kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:quadrillion:][p_r_14]
「哎呀哎呀，所以小鬼头就是这样的嘛。[rhr]
_　外面稍微热闹点就高兴成这样」[rhp]

[:kite:][p_k_14]
「说这话的克林不是也新买了相机？干劲十足啊」[rhp]

[:quadrillion:][p_r_27][riri body=yukata kao=14 ]
「讨厌～～～被发现啦！？没错！这是专门针对夜间拍摄的，」[rhp]

[:kite:][kite body=yukata kao=6 ]
「啊，没关系的」[rhp]

[off_all]

[:drop:][p_d_04][drop body=base kao=1 ]
「那么各位，烟花大会预定在18点半左右开始，[rhr]
_　请大家在那之前稍微提早些到广场集合哦」[rhp]

[:vulpecula:][peku body=yukata kao=13 ]
「好呀！看烟花的时候要一起喊『玉屋～～』才开心呢！」[rhp]

[:drop:][drop body=base kao=13 ]
「嗯。这段时间各位可以自由活动，请好好享受。[rhr]
_　我会留在车里进行检修」[rhp]

[off_all]

[:princess:][puri_w body=yukata kao=6 as=on ]
「诶……！多洛普你不去玩吗？[rhr]
_　检修什么的很无聊吧」[rhp]

[:drop:][p_d_02][drop body=base kao=13 ]
「这些事总得有人来做。[rhr]
_　而且对我来说车内检修也是非常快乐的事，请放心」[rhp]
[:drop:]
「虽算不上补偿，但很期待你们的旅行见闻！[rhr]
_　每次听大家讲述经历，我都非常开心」[rhp]

[:princess:][puri_w body=yukata kao=6 as=on ]
「但是……」[rhp]

[:quadrillion:][riri body=yukata kao=6 ]
「那家伙一直都是那样啦。别管他」[rhp]
[:quadrillion:]
「我们的人生信条就是随心所欲做喜欢的事。[rhr]
_　玩不玩全看本人意愿。我们可没资格指手画脚」[rhp]

[:drop:]
「就是这个道理」[rhp]

[:princess:][puri_w body=yukata kao=3 as=on ]
「……明、明白了……」[rhp]

[off_all]

[::]
以多洛普的话语为开端，众人各自散开行动。[rhp]

[chara_part name="otiai" body=yukata kao=4 as=on ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=yukata kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:][p_h_06]
「听说夏日祭典上有个连小孩都能打的射击摊啊！！[rhr]
_　走吧落合！！！」[rhp]

[:otiai:][p_so_10][otiai body=yukata kao=2 as=on ]
「啊？　啊喂、等等……！　别、别擅自！　而且那是打靶游戏，」[rhp]

[:heartshape:][hati body=yukata kao=14 ]
「三个人来锦标赛吧！[rhr]
_　输的人要打扫一星期厕所！」[rhp]

[off_all]

[:jet:][p_j_16][jet body=yukata kao=5 ]
「那可真不能输啊……[rhr]
_　落合要是弃权的话，不战而胜我也无所谓？」[rhp]

[off_all]

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
[vostart]
;--------------------------------------------------------------------------------------------

[chara_part name="hati" body=yukata kao=4 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="otiai" body=yukata kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="jet" body=yukata kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="760" top="0" wait="true" time=150]

[:otiai:]
「～～～～～啊、抱歉不行！我今天有约在先！」[rhp]

[off_all]

[:otiai:][otiai body=yukata kao=2 as=on ]
「出发吧，公主！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[off_all]

[:princess:][puri_w body=yukata kao=4 as=on ]
「啊、等……！慢、慢着！」[rhp]

[off_all]

[::]
被落合君强硬地抓住手腕，[rhr]
像是要逃离现场般，飞奔上石阶。[rhp]

[:drop:]
「烟花大会～～～！别忘了约定～～！？」[rhp]

[::]
从背后传来多洛普的声音，我空着的那只手往后挥了挥……[rhp]

;****************************************
[set_00 storage="fes_02.jpg"]
;****************************************

[:princess:][puri_w body=yukata kao=6 as=on ]
「哈……呼……哈……」[rhp]

[off_all]

[::]
一口气跑上有着相当级数的石阶后，[rhr]
我当场像垮掉似的跪了下来。[rhp]

[:otiai:][p_ot_30][otiai body=yukata kao=6 ]
「唉呀呀。你体力真差」[rhp]

[:princess:][puri_w body=yukata kao=3 as=on ]
「别、别把我跟小不点混为一谈啊……！[rhr]
_　楼梯超级累人的好吗……」[rhp]

[:otiai:][p_ot_34][otiai body=yukata kao=7 ]
「抱歉」[rhp]

[:princess:][puri_w body=yukata kao=2 as=on ]
「明明完全没这么想吧！」[rhp]

[off_all]

[::]
我怨念地抬头望向落合君，[rhr]
他正东张西望着环视四周。[rhp]

[chara_part name="otiai" body=yukata kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=yukata kao=0 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「……？在干嘛呢？」[rhp]

[:otiai:][otiai body=yukata kao=12 ]
「…………确认有没有熟人」[rhp]

[:princess:][puri_w body=yukata kao=0 ]
「熟人？」[rhp]

[:otiai:][otiai body=yukata kao=12 ]
「没啥。……这个话题先打住吧」[rhp]
[:otiai:][otiai body=yukata kao=7 ]
「再不快点的话，那些家伙就要追上来……」[rhp]

[off_all]

[:otiai:]
「…………啊」[rhp]

[:princess:][puri_w body=yukata kao=4 as=on ]
「嗯？咦，该不会真找到了？」[rhp]

[:otiai:][p_ot_30][otiai body=yukata kao=0 ]
「………………。矢部医生在那儿」[rhp]

[:princess:]
「诶」[rhp]

;****************************************
[bg_rule storage="fes_03.jpg" rule="002.png" time=500]
*;****************************************

[off_all]

[:yabu:][p_yb_31][yabu body=yukata kao=5 hh=on ]
「哈―――哈哈哈哈哈！厉害，老子太牛了！」[rhp]
[:yabu:]
「何等华丽的锅铲技法……！[rhr]
_　御好烧简直像芭蕾舞者般起舞！」[rhp]
[:yabu:]
「如何啊米卡亲！？名医的终极・铁板烧！」[rhp]

[:mika:][p_mk_14][mika body=yukata kao=14 hh=on ]
「好好吃呀！试吃员最棒了♪」[rhp]

[:yabu:][yabu body=yukata kao=6 as=on ]
「！？　说起来米卡亲……你的碳水化合物减肥计划怎样了？[rhr]
_　虽然是我让你吃的，但面粉类食物可全是碳水化合物啊」[rhp]

[:mika:][mika body=yukata kao=13 hh=on ]
「今天是奖励日♡」[rhp]

[:yabu:][p_yb_06][yabu body=yukata kao=5 ]
「那就好！！作为医疗从业者，应当合理摄取各类营养素！」[rhp]

[:mika:]
「好～的，老师♡」[rhp]

[off_all]

[:princess:][puri_w body=yukata ]
「喂——！矢部医生——！」[rhp]

[:yabu:][p_yb_36][yabu body=yukata kao=2 ]
「嗯……？唔啊！我还以为是谁，原来是公主啊」[rhp]

[:princess:][puri_w body=yukata ]
「矢部医生也来参加夏日祭啦。是在经营御好烧店吗？」[rhp]

[:yabu:][yabu body=yukata kao=5 ]
「算是吧！也给你烤一份好了。选个喜欢的都道府县吧」[rhp]

[:princess:][puri_w body=yukata kao=0 ]
「喜欢的都道府县？」[rhp]

[:yabu:][yabu body=yukata kao=1 ]
「比如大阪啦广岛啦」[rhp]

[:princess:][puri_w body=yukata kao=13 ]
「那就青森！」[rhp]

[:yabu:][p_yb_13][yabu body=yukata kao=2 as=on ]
「！？　哎哎……青森！？」[rhp]

[off_all]

[chara_part name="yabu" body=yukata kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="yabu" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="mika" body=yukata kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="mika" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:yabu:]
「米、米卡亲！糟了。[rhr]
_　这家伙好像以为全日本各地都有御好烧啊」[rhp]

[:mika:][mika body=yukata kao=3 ]
「……………………」[rhp]

[:yabu:][yabu body=yukata kao=2 as=on ]
「听见了吗米卡亲！我可不能辜负孩子的期待！[rhr]
_　必须想办法创作出青森风味御好烧……！」[rhp]

[fbgm]

[:mika:][mika body=yukata kao=3 ]
「………………宙君」[rhp]

[:yabu:][yabu body=yukata kao=0 as=on ]
「……！」[rhp]

[off_all]

[:princess:][puri_w body=yukata kao=0 as=on ]
[font color=0x4682b4]
（怎么回事？感觉气氛有点微妙……）[rhp]
[resetfont]

[off_puri]

[bgm storage="bgm_08.ogg"]

[chara_part name="otiai" body=yukata kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="mika" body=yukata kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="mika" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:mika:][p_mk_35]
「…………好久不见呢宙君。真没想到会在这里遇见！」[rhp]

[:otiai:]
「……、你好」[rhp]

[:mika:][p_mk_04]
「银河铁道的旅行，享受吗？」[rhp]

[:otiai:][p_ot_02]
「嘛，还算可以吧」[rhp]

[:mika:][mika body=yukata kao=13 ]
「是吗……要早点回来哦」[rhp]

[:otiai:]
「………………」[rhp]

[:princess:][puri_w body=yukata kao=0 as=on ]
「米卡亲，和落合君是怎么认识的？」[rhp]

[:mika:][p_mk_31][mika body=yukata kao=13 hh=on ]
「诶～？……呵呵♡ 秘密！」[rhp]

[:princess:][puri_w body=yukata kao=6 as=on ]
「啊，可疑……！被这么说的话反而更在意了」[rhp]

[off_all]

[chara_part name="yabu" body=yukata kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yabu" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=yukata kao=2 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「呐！矢部医生也是这么想的吧？」[rhp]

[:yabu:][p_yb_27][yabu body=yukata kao=12 ]
「～～～～～……嗯！虽然不太明白，但大概懂了」[rhp]

[:princess:][puri_w body=yukata kao=8 as=on ]
「诶！？骗人！这就放弃了吗！？」[rhp]

[:yabu:][yabu body=yukata kao=1 ]
「夏日祭典可不适合沉重的气氛啊！[rhr]
_　你们几个不如先去逛逛祭典如何」[rhp]

[:princess:][puri_w body=yukata kao=6 as=on ]
「～～～……算了也罢……[rhr]
_　就算追问下去，反正也不会透露什么吧」[rhp]

[off_all]

[:mika:][p_mk_15][mika body=yukata kao=13 ]
「真乖呢♡」[rhp]

[:yabu:][yabu body=yukata kao=2 ]
「那么米卡亲！现在要研发青森风味御好烧。[rhr]
_　等公主她们回来时，当作伴手礼送出去……」[rhp]

;****************************************
;カットイン
[s_image layer="2" page="back" storage="ct/a_07_n_1.png" width="1260" left="10" top="40" name="nov"]
[s_trans layer="2" method="bounceInDown" time=200]
[cg storage="ct/a_07_n_1.png"]
[wt]
;****************************************

[yurasu]
[se storage="se7_16.ogg"]

[:yabu:]
[font size=30]
「诶―――――！？」[rhp]
[resetfont]

[:mika:]
「完成啦☆」[rhp]

[:yabu:]
[font size=28]
「破罐子摔也该有个限度吧！！」[rhp]
[resetfont]

;****************************************
;カットイン終了
[s_freeimage layer="2" ]
;****************************************

[:mika:][mika body=yukata kao=14 ]
「好啦好啦！大家快去祭典吧。[rhr]
_　矢部医生由我来稳住他♡」[rhp]

[:yabu:][p_yb_29][yabu body=yukata kao=2 as=on ss=on ]
「你觉得是谁害他生气的啊！」[rhp]

[off_all]

[chara_part name="otiai" body=yukata kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="mika" body=yukata kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="mika" layer="1" width="437" height="720" left="645" top="0" wait="false" time=150]
[chara_part name="puri_w" body=yukata kao=1 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:mika:][p_mk_31]
「公主，宙君。今天要玩得尽兴哦！」[rhp]

[:otiai:][p_ot_27][otiai body=yukata kao=12 ]
「………………明白了」[rhp]

[:princess:][puri_w body=yukata kao=13 ]
「回家路上我会买礼物的！」[rhp]

[:mika:][mika body=yukata kao=14 ]
「哇！好期待呢♡」[rhp]

[off_all]

[:mika:]
「那你们两个，路上小心～！」[rhp]

;****************************************
[bg_rule storage="fes_02.jpg" rule="002.png" time=500]
;****************************************

[::]
在米卡亲轻快的送别声中，[rhr]
我们终于开始了夜市探索。[rhp]
……用余光不经意地瞥向落合君。[rhp]

[:otiai:][otiai body=yukata kao=3 ]
「………………」[rhp]

[::]
一副尴尬微妙的复杂表情。[rhr]
果然是因为突然遇到米卡亲的缘故吗？[rhp]

[:princess:][puri_w body=yukata ]
「……落合君！」[rhp]

[:otiai:][otiai body=yukata kao=4 as=on ]
「嗯？」[rhp]

[:princess:][puri_w body=yukata kao=13 ]
「先从哪里逛起？想吃什么？我来给你当向导吧！」[rhp]

[:otiai:][p_ot_19][otiai body=yukata kao=2 as=on ]
「向导……你对这里也没熟到能当向导吧」[rhp]

[:princess:][puri_w body=yukata kao=14 as=on ]
「哪、哪有啦。我才没那么不中用……」[rhp]

[:otiai:][p_ot_27][otiai body=yukata kao=6 ]
「……谢你好意，不过我没事的」[rhp]

[:princess:][puri_w body=yukata kao=6 as=on ]
「这、这样……？真的吗？」[rhp]

[:otiai:][otiai body=yukata kao=7 ]
「要向导也该我来。总比你熟悉点」[rhp]

[:princess:][puri_w body=yukata kao=14 hh=on ]
「落合君……！嘿嘿……嗯！那就拜托你啦」[rhp]

[:otiai:][otiai body=yukata kao=6 as=on ]
「啧，到底谁才是小孩子啊……」[rhp]

;****************************************
[set_time storage="fes_06.jpg"]
;****************************************

[::]
之后的落合君可谓专业至极。[rhp]
他能瞬间理解我想吃的食物和想玩的项目，[rhr]
并准确引导到相应的摊位。[rhp]

[chara_part name="otiai" body=yukata kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=yukata kao=5 as=off ss=off hh=on hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「祭典万事通……！」[rhp]

[:otiai:][p_ot_05][otiai body=yukata kao=2 as=on ]
「别起这种土爆的称号……敢这么叫我绝对翻脸」[rhp]

[:princess:][puri_w body=yukata kao=13 ]
「呵呵呵，好～的」[rhp]

[off_all]

[::]
即使被絮絮叨叨地抱怨，也依然觉得开心。[rhr]
总觉得和落合君在一起时，有种重返童年的心情。[rhp]
不用考虑多余的事，单纯享受眼前的一切那种感觉。[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:otiai:][otiai body=yukata kao=7 ]
「……快到集合时间了，先去寺院里等着吧」[rhp]

[:princess:][puri_w body=yukata kao=0 ]
「刑警？」[rhp]

[:otiai:][otiai body=yukata kao=12 ]
「香火钱。我想认真对待这些规矩」[rhp]

[:princess:][puri_w body=yukata kao=6 ]
「…………？？」[rhp]

[:otiai:][otiai body=yukata kao=6 as=on ]
「……连这种事都不知道吗……」[rhp]

[:princess:][puri_w body=yukata kao=2 as=on hh=on ]
「才、才不是呢。不是不知道，是忘记了啦」[rhp]

[:otiai:]
「反正都一样吧。结果不就是不知道吗」[rhp]

[:princess:][puri_w body=yukata kao=6 as=on hh=on ]
「虽然是那样！」[rhp]

[:otiai:][otiai body=yukata kao=12 ]
「……境内就是神社的建筑，香火钱是向神明祈祷时投入的钱」[rhp]
[:otiai:]
「祭典原本就是献给神明的仪式。[rhr]
_　在那种夜市里吵吵嚷嚷的，其实说到底只是附加环节罢了」[rhp]

[:princess:][puri_w body=yukata kao=4 ]
「嘿欸……」[rhp]

[:otiai:][otiai body=yukata kao=5 ]
「哼哼。稍微变聪明了点嘛」[rhp]

[:princess:][puri_w body=yukata kao=13 as=on hh=on ]
「总、总觉得好害羞。[rhr]
_　至少能想起些常识也好啊……」[rhp]

[:otiai:][otiai body=yukata kao=3 ]
「…………。没必要那么在意吧」[rhp]
[:otiai:]
「实在不行，我陪在你身边就好。……一直这样」[rhp]

[:princess:][puri_w body=yukata kao=0 ]
「咦……？　难道说……」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
[::]
[set_kk storage="cg/c_4.png" time=500]
[set_ff storage="fes_06.jpg" time=500]
;****************************************

[:princess:][puri_w body=yukata kao=4 as=on ]
「――――！」[rhp]

[:otiai:][p_ot_09][otiai body=yukata kao=0 ]
「公主？」[rhp]

[off_all]

[:princess:][puri_w body=yukata kao=2 as=on ]
「……刚才的……」[rhp]

[off_all]

[::]
转瞬即逝的、过去的影像。[rhr]
那还不足以唤醒我的记忆。[rhp]
……不过……[rhp]

[:princess:]
[font color=0x4682b4]
（…………只有感觉，稍微有一些）[rhp]
[resetfont]

[::]
……我好像认识落合君。[rhr]
在哪儿认识的、为什么认识、是什么关系这些完全想不起来。[rhp]
只是模模糊糊地，对他感到怀念。[rhp]

[:princess:]
[font color=0x4682b4]
（但是，为什么……？为什么会有这种感觉？）[rhp]
[resetfont]

[::]
明明想要回忆起来，本能却在抗拒着。[rhr]
回忆起与他的过往，似乎会是件极其糟糕的事。[rhp]
如果回忆起来，现在的生活就会全部崩溃似的。[rhp]
可是，为什么……[rhp]

[fbgm]

[:yoru:][s_playse storage="yoru/full/76.ogg" buf=1]
「―――――都是南的错」[rhp]

[:princess:]
「……！」[rhp]

;****************************************
#
[bg storage="black.jpg" time=500]
;****************************************

[se storage="leg_06.ogg"]

[::]
突然从背后传来声音，我回头望去。[rhp]

――――足以卷起地面落叶的强风呼啸而过。[rhp]
仿佛被那阵风吹散般……[rhp]

;****************************************
[bg storage="fes_02b.jpg" time=1000]
;****************************************

[:princess:]
「―――！？」[rhp]

[::]
祭典的灯火、装饰、人群全都消失不见，[rhr]
我们所在之处不知何时变成了无人问津的破旧神社。[rhp]

[:princess:][puri_w kao=2 as=on ]
「呃……！？」[rhp]

[off_all]

[::]
连衣服都从浴衣变回了便服。[rhr]
看来笼罩这个空间的魔法已经解除了。[rhp]
正因这骤变难掩惊讶时，[rhr]
黑暗中传来轻微的脚步声。[rhp]

;****************************************
;スチル
[still storage="cg/a_07_n_1.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/a_07_n_1.png"]
;****************************************

[bgm storage="bgm_36.ogg"]

[::]
……夜？[rhp]


[:yoru:]
「………………」[rhp]


[:princess:]
[font color=0x4682b4]
（…………好像，在生气？）[rhp]
[resetfont]

[::]
夜表情险恶地，从稍远处瞪视着我们。[rhp]
为什么他会在这里呢？[rhr]
为什么在生气呢？[rhp]
对事态完全无法理解，我只能愕然呆立。[rhr]
四周笼罩着异常的寂静，唯有寒风呼啸作响。[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:yoru:]
「这是南招致的结果」[rhp]

[::]
毫不掩饰怒意的低沉声音，震动着我的鼓膜。[rhp]

[:yoru:]
「很焦躁吧。明明近在咫尺却无法取出。[rhr]
_　简直就像弹珠汽水的玻璃珠」[rhp]
[:yoru:]
「…………若是砸碎它，倒是轻而易举」[rhp]

[:otiai:]
「住手！！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[off_all]

[::]
随着一声大喝，落合君推开我挡在夜面前。[rhp]

[:otiai:][p_ot_11]
「夜……！你这家伙……一直都在看着吗」[rhp]

[:yoru:]
「………………」[rhp]

[::]
夜没有回答。[rhp]
只是持续沉默着……但这沉默本身已是答案。[rhp]
落合君短叹一声后，垂眼低声道。[rhp]

[:otiai:]
「是来找我的吗……？」[rhp]

[:yoru:]
「……………………」[rhp]

[:otiai:]
「违背约定和说谎的事我道歉。但我―――」[rhp]

;****************************************
#
;スチル
[bg storage="cg/a_07_n_1b.png" width="1280" height="720" time=500]
[cg storage="cg/a_07_n_1b.png"]
;****************************************

[:yoru:]
「够了」[rhp]

;****************************************
;スチル終了

#
[s_mask color=0x000000 time=2000]
; 背景表示
[bg storage="fes_02b.jpg" time=100]
; 夜フィルター
[filter layer="1" brightness="60"]
; ウィンドゥの設定
[position layer="message0" frame="win.png" left=0 top=520 width=1280 height=200 page=fore visible=true ]
[s_mask_off time=2000]

;****************************************

[:yoru:][yoru kao=2 ]
「……没能读懂你的想法，做出草率选择是我的错」[rhp]

[off_all]
[chara_part name="otiai" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:yoru:]
「回去了宙。这里不是你的归处」[rhp]

[:princess:][puri_w  kao=2 as=on ]
「！回、回去？」[rhp]

[:yoru:][yoru kao=2 ]
「他和我有过约定。……然而。[rhr]
_　来到这个世界后立刻背叛我，还厚颜无耻地享受旅行的家伙」[rhp]
[:yoru:]
「既然事已至此，我的愿望实现概率已经是0。[rhr]
_　那么尽快回收你这家伙才是上策吧」[rhp]

[:otiai:]
「…………」[rhp]

[off_puri]

[:yoru:][p_y_28]
「完全是浪费时间。真想避免再发生这种事」[rhp]
[:yoru:]
「…………宙。还有什么遗言就随你说吧」[rhp]

[off_all]

[::]
被这么说的落合君，不知为何慌张地游移着视线。[rhp]
不明所以的我，完全跟不上这个状况。[rhp]

[:otiai:][otiai  kao=3 as=on ss=on ]
「啊…………公、公主。我」[rhp]
[:otiai:]
「……、我……」[rhp]

[off_all]

[:yoru:][yoru kao=12 ]
「……如果没有特别要说的，就此结束」[rhp]

[off_all]

[:otiai:][p_ot_11][otiai  kao=2 as=on ]
「等、等一下夜！　我还没——」[rhp]

[off_all]

[:yoru:][p_y_32][yoru kao=6 ]
「你对我的言辞毫无必要」[rhp]
[:yoru:]
「……明明像麻雀般聒噪，重要的事却只字不提。[rhr]
_　不巧现在的我，没有闲工夫听你辩解」[rhp]
[:yoru:][yoru kao=3 ]
「…………对你本是有所期待的」[rhp]

[off_all]

[:otiai:][otiai  kao=8 as=on ss=on ]
「呃……！」[rhp]

[off_all]

[::]
落合君快要哭出来的扭曲表情，刺痛了胸口。[rhp]
我曾擅自想象，与他的离别会是大家围坐在一起，[rhr]
在笑容与些许泪水中到来的场景。[rhp]
难道就没什么办法能阻止夜吗。[rhp]

[chara_part name="yoru"  kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694"" height="720" left="293" top="0" wait="false" time=150]
[chara_part name="puri_w"  kao=2 as=on ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「等、等等夜！　落合君说过满足后就会乖乖回去的[rhr]
_　他承诺过的。所以再给我们一点时间好吗？」[rhp]

[:yoru:][p_y_34][yoru kao=0 ]
「宙的时间并非归我所有。[rhr]
_　因而即便你请求我，也无法将其转交予你」[rhp]

[:princess:][puri_w  kao=8 as=on ]
「那、那是……」[rhp]

[:yoru:][yoru kao=6 ]
「生命是有限的。与你我的存在截然不同」[rhp]
[:yoru:]
「……正因如此他才应该离开这里。[rhr]
_　他还有许多未完成之事」[rhp]

[:princess:][puri_w  kao=2 as=on ]
「！　夜……难道你知道落合君来到此地的理由……」[rhp]

[off_puri]

[:yoru:][p_y_02][yoru kao=12 ]
「无需多言」[rhp]
[:yoru:]
「…………回去吧，宙」[rhp]

[off_all]

[se storage="body_07.ogg"]

[::]
夜掀动大衣，强行拽着落合君的手臂。[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[yurasu]

[:otiai:][otiai  kao=2 as=on ]
「混、混蛋！放开我！我要留在这里！」[rhp]
[:otiai:]
「已经受够了……！就算继续活在那个世界，我——」[rhp]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

[off_all]

;***************************************
[se storage="mag_06.ogg"]
[bg_rule storage="black.jpg" rule="012.png" time=1500]
;****************************************

[::]
夜的魔法打断了落合君的话语，四周被黑暗吞噬。[rhr]
两人身影如被吞没般消失不见。[rhp]
黑暗逐渐开始褪去但……[rhp]

;***************************************
[bg_rule storage="fes_02b.jpg" rule="013.png" time=1500]
[fse]
;****************************************


[:princess:][puri_w  kao=4 as=on ]
「………………欸」[rhp]

[off_all]

[::]
本该站在我面前的他们，此刻已无影无踪。[rhp]

[:princess:][puri_w  kao=2 as=on ]
「！？　落合君？　夜！？」[rhp]

[off_all]

[::]
慌忙环顾四周呼喊着两人名字，却得不到任何回应。[rhp]
祭典的乐声早已消散。[rhr]
唯独一人被遗弃在这仿佛会吞噬一切的夜之森林。[rhp]

[:princess:]
[font color=0x4682b4]
（…………胸口好闷）[rhp]
[resetfont]

[::]
朦胧而烦躁的情绪，令胸中躁动不安。[rhp]
并非因孤身一人而感到恐惧。[rhr]
也非因不知落合君去向而不安。[rhp]
……可为何还是如此难以抑制地悲伤。[rhp]

[:princess:]
[font color=0x4682b4]
（……在这个世界也……行不通吗……）[rhp]
[:princess:]
（我又一次……什么都……）[rhp]
[resetfont]

[off_all]

[::]
………………。[rhp]

[:princess:][puri_w  kao=2 as=on ]
「……………………？」[rhp]

[off_all]

[::]
对突然脱口而出的话语感到违和。[rhr]
…………『又一次』是什么意思？[rhp]
简直像在说从前也发生过类似的事。[rhr]
虽然不记得，但或许该称之为『残留』吧。[rhp]
……第一次对自己的状态感到些许恐惧。[rhr]
现状恐怕比自己想象的更为严峻。[rhp]
正因不明所以而困惑时，冰凉的液体划过脸颊。[rhp]

[:princess:]
「…………！为什么……？」[rhp]

[::]
怀着难以名状的心情，我拭去这不自然流下的泪水。[rhp]
也并非在惋惜这突如其来的离别。[rhr]
将之理所当然地认知为『离别』的自己同样令人生厌。[rhp]
想要狠狠抛弃的违和感。[rhr]
想要放声尖叫，将其倾吐而出。[rhp]
若要将此刻的心情付诸言语……。[rhp]

………………我现在，不知为何感到无比后悔。[rhp]

;****************************************

[s_mask color=0x000000 time=2000]
; 背景表示
[bg storage="hsps_08xn.jpg" time=100]
; 夜フィルター
[filter layer="1" brightness="60"]
; ウィンドゥの設定
[position layer="message0" frame="win2.png" left=0 top=520 width=1280 height=200 page=fore visible=true ]
[s_mask_off time=2000]

;****************************************

[:otiai:][otiai  kao=12 ]
「…………、……」[rhp]

[off_all]

[:yoru:][yoru kao=3 ]
「…………是昏过去了吗」[rhp]
[:yoru:]
「多么胆大包天的孩子啊。[rhr]
竟敢让我做到这种地步……到头来……」[rhp]

[off_all]

[:otiai:]
「………………」[rhp]

[off_all]

[:yoru:][yoru kao=3 ]
「…………不」[rhp]
[:yoru:]
「还是别迁怒于人了……说到底，是贪心不足的我不好」[rhp]
[:yoru:]
「……已经足够了。我的棋子，只要有那两人就―――」[rhp]

[off_all]

[:unknown:]
「看你活着就放心了」[rhp]

[:yoru:][yoru kao=4 ]
「――――！」[rhp]

[off_all]

[:sausu:][sausu kao=2 ]
「毕竟是你的作风，我还担心你会不择手段呢……」[rhp]

[:yoru:][yoru kao=2 ]
「…………啧」[rhp]

[:sausu:][sausu kao=2 ]
「哟约尔大人。……好久不见」[rhp]

[:yoru:]
「南……你还有脸出现在这里？」[rhp]
[:yoru:]
「我和你无话可说。快从我眼前消失」[rhp]

[:sausu:][p_s_18]
「还是这么不留情面啊……」[rhp]
[:sausu:]
「但今天……我也相当，生气呢」[rhp]

[:yoru:]
「你以为是在对谁说话」[rhp]

[:sausu:]
「对着糠星夜大人，说的哦」[rhp]
[:sausu:]
「公主很沮丧。都是因为你强行把宙带回来的缘故」[rhp]
[:sausu:]
「纵然是你……也不要在我的银河铁道上为所欲为啊」[rhp]

[:yoru:]
「『我的』？　梦话留到梦里说。[rhr]
那个世界全数归我所有，即我本身。你不过是个非法入侵者」[rhp]

[:sausu:]
「即便如此，建造那条铁道的是我」[rhp]

[:yoru:]
「厚颜无耻也该有个限度」[rhp]

[:sausu:][sausu kao=3 as=on ]
「～～～……」[rhp]

[:yoru:][yoru kao=12 ]
「你似乎因为不想被我掐住脖子而四处逃窜，不过时机已到。[rhr]
_　……正好借此机会由我亲口告诉你吧」[rhp]
[:yoru:][yoru kao=2 ]
「这是命令。立刻将他们从那个世界抹除。[rhr]
_　甚至于我现在就能让他们化为银河的尘埃」[rhp]

[:sausu:][sausu kao=6 ]
「就算能做到你也不会下手吧。……如果是你的话」[rhp]

[:yoru:][yoru kao=12 ]
「那就试试看吧。首先……对了」[rhp]
[:yoru:][yoru kao=0 ]
「……从你的父亲开始」[rhp]

[:sausu:][sausu kao=2 as=on ]
「！」[rhp]

[:yoru:][yoru kao=7 ]
「啊。不对。那个男人已经得到救赎了」[rhp]
[:yoru:]
「唯有那个男人，不存在于银河的任何角落」[rhp]

[:sausu:][sausu kao=5 ]
「…………你以为这种程度能激怒我吗」[rhp]

[:yoru:][yoru kao=12 ]
「当然。事实上此刻，你那懊恼的表情让我相当满足」[rhp]

[:sausu:][sausu kao=2 ]
「……啧、我最讨厌你这种地方！[rhr]
_　无可救药的机械感，充满暴力……太过冷酷」[rhp]
[:sausu:]
「你就从未期盼过他们的幸福吗」[rhp]

[:yoru:][p_y_19][yoru kao=6 ]
「幸福？」[rhp]

[:sausu:]
「现在的我，已经不只是为了那孩子而行动。[rhr]
_　我想实现所有被那铁道召唤的孩子们的愿望」[rhp]
[:sausu:]
「而且！只要存在于那里，他们的愿望就已实现了一个。[rhr]
_　强行夺走好不容易获得的幸福，实在太残忍了」[rhp]

[:yoru:][yoru kao=2 ]
「太磨蹭了。……说到底怎样。简洁说明你希望我做什么」[rhp]

[:sausu:][p_s_04][sausu kao=3 as=on ]
「……、希望让大家留在那个世界」[rhp]

[off_all]

[:yoru:][p_y_28][yoru kao=7 ]
「驳回。解散」[rhp]

[off_all]

[:sausu:][sausu kao=2 as=on ]
「啧！约尔大人！你明明不需要那个世界的吧。[rhr]
_　凭什么要像恶意刁难般夺走它啊！」[rhp]
[:sausu:]
「无论是悲伤、喜悦、甚或是愿望。[rhr]
_　关于他们的事，你应该比我清楚得多吧？」[rhp]
[:sausu:]
「不是说让你交出来。只是不用的话借给我就好。[rhr]
_ 这点要求都不行吗……！求你了！」[rhp]

[:yoru:][yoru kao=6 ]
「…………、把头抬起来」[rhp]

[:sausu:][p_s_19][sausu kao=8 as=on ]
「…………！你愿意理解我吗……？」[rhp]

[:yoru:][p_y_24][yoru kao=3 ]
「刚才说过，我随时都能将他们赶出铁道。[rhr]
_　尽管如此仍忍着苦涩不这么做，原因是……」[rhp]
[:yoru:]
「因为我想让、你来做这件事」[rhp]

[:sausu:][sausu kao=4 as=on ]
「啊……？」[rhp]

[:yoru:][yoru kao=12 ]
「只有完成赎罪，过错才能升华为教训」[rhp]

[:sausu:][p_s_11][sausu kao=2 as=on ]
「开什么玩笑……让我来？怎么可能做到！」[rhp]

[:yoru:][yoru kao=2 ]
「你没有否决权。现在该重新认清地位差距了」[rhp]

[:sausu:][sausu kao=3 as=on ]
「……为什么你能如此冷酷。[rhr]
_　我只是……单纯期盼着大家的幸福啊……」[rhp]

[:yoru:][p_y_02]
「你想拯救的，不是别人正是你自己吧」[rhp]

[:sausu:][sausu kao=2 as=on ]
「这种事……！！」[rhp]

[off_all]

[:yoru:]
「本不想轮到我出场。[rhr]
_　事已至此别无选择……看来只能由我来终结一切」[rhp]

[off_all]

;****************************************
#
[bg storage="black.jpg" time=1000]
;****************************************

[:yoru:]
「对你父亲表示敬意，就用这句话作结吧」[rhp]
[:yoru:]
「…………可喜可贺，可喜可贺」[rhp]

[mask time=2000]
[cancelskip]
[fbgm]

;フラグ初期設定
[iscript]
f.love_d = 0
f.love_k = 0
f.love_r = 0
f.love_h = 0
[endscript]

[jump storage="title.ks" target="*start_end"]

[s]

