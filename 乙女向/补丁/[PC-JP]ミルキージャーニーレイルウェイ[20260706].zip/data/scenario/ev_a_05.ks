﻿*start

;--------------------------------------------------------------------------------------------
;▼フルボイスセット▼
[voconfig sebuf=1 name=yoru vostorage="yoru/full/{number}.ogg" number=32]
;--------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_08.jpg" time=100]
[s_mask_off time=2000]
;****************************************

[bgm storage="bgm_07.ogg"]

[::]
那一天，我怀着无比充实的心情迎来了夜晚。[rhp]
虽然紧张，但还是带着落合君参观了车厢的各个角落，[rhr]
总觉得比起昨天的自己稍微成熟了些，心情格外舒畅。[rhp]
在这般惬意的疲倦中。[rhr]
我倒进床铺，闭上了眼睛。[rhp]

[:princess:]
[font color=0x4682b4]
（落合君……能和大家好好相处吗）[rhp]
[resetfont]

[::]
虽然明白这是多管闲事，但果然还是——[rhr]
能大家一起开开心心旅行最好了。[rhp]
抛开活着啊死了啊这些不谈。[rhp]
至少存在于这辆铁道上的事实，[rhr]
是我们共同拥有的羁绊啊。[rhp]

[:princess:]
[font color=0x4682b4]
（话说下次的旅行目的地，是可以由我来提议的吧）[rhp]
[resetfont]

[::]
记得之前从海边回来的路上，多洛普曾随口这么提过。[rhp]

[:princess:]
[font color=0x4682b4]
（正因为没有记忆，反而没什么特别的执念，[rhr]
_　难得的机会不如问问落合君的愿望吧）[rhp]
[resetfont]

[::]
不禁有些摆起姐姐的架子。[rhr]
照顾人的感觉真不错啊。[rhp]
对了！下次也可以像佩奇那样自称姐姐试试看……[rhp]

[:princess:][puri_w kao=14 as=on ]
「啊、啊哈哈！开玩笑的！真要那么说实在太羞人了！[rhr]
_　落合君肯定也会脸红的啦！」[rhp]

[off_puri]

;布擦れる
[se storage="body_07.ogg"]

[::]
自己的思考回路此刻突然显得如此可笑，[rhr]
为了转换心情，我从床铺上猛然起身。[rhp]
去餐车泡杯可可吧。[rhr]
如果落合君醒着的话，也给他准备一份……[rhp]

[fbgm]

[:unknown:]
[s_playse storage="yoru/full/31.ogg" buf=1]
「这种时间要去哪里」[rhp]

[:princess:][puri_w kao=4 as=on ]
「……！？」[rhp]

[off_puri]

[::]
毫无预兆地，背后响起陌生声音。[rhr]
震惊回首，愈发惊愕。[rhp]

[bgm storage="bgm_36.ogg"]

[yoru ]

[::]
房间里站着陌生男人。[rhp]

[off_yoru]

面对如此状况僵直原地的我，[rhr]
被他用捉摸不透的漠然眼神死死凝视。[rhp]

[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="293" top="0" wait="false" time="150"]
[chara_part name="puri_w" body=base kao=2 as=on ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「你、是谁……！？」[rhp]

[off_all]

[::]

;****************************************
;スチル
[still storage="cg/a_05_1.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/a_05_1.png"]
;****************************************

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
[vostart]
;--------------------------------------------------------------------------------------------

[:yoru:]
「……糠星夜」[rhp]

[::]
平静自报家门的男人，突然向呆立当场的我逼近。[rhp]

[:princess:]
「呜哇……！」[rhp]

[::]
那张陡然凑近的脸庞令我几乎想别开视线，[rhr]
不由后退了半步。[rhp]
睫毛很长啊，似乎带着炭火气味啊，[rhr]
尽是些无关紧要的念头在脑中盘旋。[rhp]
灰蓝色的瞳孔怀疑般眯起。[rhr]
仿佛正透过我的眼睛，窥视内心深处。[rhp]

[:yoru:]
「………没有记忆吗」[rhp]

[:princess:]
「……！」[rhp]

[:yoru:]
「真是过分啊。可怜」[rhp]

;****************************************
[still_end frame="win.png" storage="train_08.jpg" time=1000]
;****************************************

[::]
叹息着的他突然抽身离去，[rhr]
再次坐回先前独坐的沙发椅上。[rhp]
虽然翘着腿大咧咧地仰靠着，[rhr]
却莫名显得协调，奇妙地构成一幅画。[rhp]

[:yoru:][yoru kao=6 ]
「刚才打算去哪」[rhp]

[:princess:]
「要、要去餐车……准备煮可可」[rhp]

[:yoru:][yoru kao=7 ]
「………………哼」[rhp]

[::]
他无趣地轻哼一声，[rhr]
夜先生瞥了眼面前的桌子。[rhp]
我也顺着他的视线望去。[rhp]
只见方才还空无一物的桌面上，[rhr]
此刻竟放着一只冒热气的马克杯。[rhp]

[:princess:][puri_w kao=4 as=on ]
「啊！？怎么回事！？」[rhp]

[off_all]

[::]
战战兢兢靠近，朝杯内窥视。[rhr]
可可与砂糖的甜香。……莫非他泡了可可？[rhp]

[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="293" top="0" wait="false" time="150"]
[chara_part name="puri_w" body=base kao=0 as=on ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「谢、谢谢……特意用魔法？」[rhp]

[:yoru:][yoru kao=6 ]
「难道让吾等看着你煮沸米尔克？」[rhp]

[:princess:][puri_w kao=6 as=on ]
「倒不是这个意思……」[rhp]

[:yoru:][yoru kao=7 ]
「………………好喝么，这泥浆」[rhp]

[:princess:][puri_w kao=8 as=on ]
「不是泥浆是可可啦」[rhp]

[:yoru:]
「哦」[rhp]

[:princess:][puri_w kao=0 ]
「……想喝吗？」[rhp]

[:yoru:][yoru kao=12 ]
「不必。仅是满足求知欲罢了」[rhp]

[off_all]

[::]
嘴上这么说，糠星夜先生却直勾勾盯着马克杯。[rhp]
…………被这样死死盯着，实在难以下咽。[rhp]
大概绝对会想尝尝看吧，[rhr]
但感觉又会像之前一样被否定，所以决定什么都不说。[rhp]

[chara_part name="yoru" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="293" top="0" wait="false" time="150"]
[chara_part name="puri_w" body=base kao=0 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「那个……夜先生是什么人？[rhr]
_　难道是南的熟人？　总觉得有点可疑呢……」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------


[:yoru:][yoru kao=6 ]
「………………」[rhp]

[off_all]

[::]
糠星夜沉默不语，直直地瞪视着这边。[rhr]
难道是听到了什么不该听的事吗？[rhp]

[:yoru:][p_y_05][yoru kao=2 ]
「………………呼」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[::]
不知道的话就会说不知道，看样子似乎是认识的人。[rhr]
虽说如此，只是提到名字就这种态度，关系应该不太好吧……[rhp]

[:yoru:][yoru kao=7 ]
「……公主。在这里的生活开心吗」[rhp]

[:princess:][puri_w kao=0 ]
「？嗯。开心不过……」[rhp]
[:princess:]
[font color=0x4682b4]
（那个问题，在海边时矢部医生也问过来着……、……嗯？）[rhp]
[resetfont]

[off_all]

[::]
说起来，糠星夜……夜这个人，好像在哪里……[rhp]

;****************************************
[set_kk storage="sea_01n.jpg" time=1000]
;****************************************

[:yabu:][yabu body=mizugi kao=3 pnt=on ]
「夜并不乐见你们的旅程。[rhr]
_　因此我们奉命强夺铁道以强制终止」[rhp]

;****************************************
[set_ff storage="train_08.jpg" time=1000]
;****************************************

[:princess:][puri_w kao=4 as=on ]
「啊……！！！」[rhp]

[off_all]

[::]
矢部医生提到的「夜」，难道就是这个人……！？[rhp]

[chara_part name="yoru" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="293" top="0" wait="false" time="150"]
[chara_part name="puri_w" body=base kao=1 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「真吃惊！原来你就是夜。[rhr]
_　我从矢部医生那里听过一点关于你的事」[rhp]

[:yoru:][yoru kao=6 ]
「是吗」[rhp]

[off_all]

[::]
夜先生只说了这句，又深深叹了口气。[rhr]
总觉得像被矢部医生小瞧了似的，有点来火。[rhp]

[:princess:][puri_w kao=2 ]
「从刚才开始怎么回事？先说好，这种登场方式、[rhr]
_　可是和你最讨厌的南一模一样哦」[rhp]
[:princess:]
「再说了，你究竟有什么事情非要来我房间―――」[rhp]

[:yoru:][yoru kao=2 ]
「我是你们的敌人」[rhp]

[:princess:]
「敌人？」[rhp]

[:yoru:]
「恢复部分力量后，我终于也能亲自来到这个世界。[rhr]
_　虽然本不该由我出面，但不知该信任『他』到什么程度」[rhp]
[:yoru:]
「所以才像这样，直接来见你」[rhp]

[:princess:][puri_w kao=6 as=on ]
「哈……？」[rhp]

[off_all]

[::]
完全听不懂。他的话语简洁却充满疏离感。[rhp]
正因这种自我中心的说话方式感到烦躁时，[rhr]
夜先生再次开口了。[rhp]

[:yoru:][yoru kao=2 ]
「直白地说很困扰」[rhp]

[:princess:][puri_w kao=4 as=on ]
「啊……？」[rhp]

[:yoru:]
「这条铁道也好，这个银河也罢，全都是我的所有物。[rhr]
_　被你们摆出一副主人架势霸占着可让人不爽」[rhp]
[:yoru:]
「……公主。请你离开这条铁道」[rhp]

[:princess:][puri_w kao=2 as=on ]
「…………是因为我们抢走了你的东西？」[rhp]

[:yoru:][yoru kao=12 ]
「从那些庸医那里听说的吗。[rhr]
_　还是老样子自作主张让人头疼……也罢，能省去废话倒是好事」[rhp]
[:yoru:][yoru kao=6 ]
「正是如此。为了把你们从这里驱逐出去，[rhr]
_　最终我不惜采取任何手段」[rhp]
[:yoru:]
「希望你们自觉退场，别逼我弄脏双手」[rhp]

[:princess:][puri_w kao=2 ]
「……！」[rhp]

[:yoru:][yoru kao=2 ]
「在这里获得的经验，真的算是真正的幸福吗」[rhp]
[:yoru:]
「你的幸福，难道可以是他人描绘的模样吗」[rhp]

[off_all]

[::]
「好好想想吧」。[rhr]
夜先生就这样用严肃的目光注视着我。[rhp]
……为什么这个人要对我说这些话。[rhp]

他人描绘的幸福？[rhr]
那、到底是谁描绘的啊？[rhp]

不知道。[rhr]
来到这里的并非我的本意，但我……[rhp]
…………我至少打从心底享受着这段旅程。[rhp]
如果死后世界是这么美妙的地方，[rhr]
我觉得这本身就是件很幸福的事。[rhp]

[:princess:][puri_w kao=6 ]
「～～～……夜先生说的话我完全听不懂啦」[rhp]
[:princess:]
「这里是阴间对吧？[rhr]
_　就算要我离开，我们根本也没其他地方可去啊」[rhp]
[:princess:]
「毕竟我们已经死了嘛」[rhp]

[off_all]

[::]
听我这么说，夜先生惊讶地睁大了眼睛。[rhr]
但随即又垂下眼帘，像看透什么似地轻叹一声。[rhp]

[chara_part name="yoru" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="293" top="0" wait="false" time="150"]
[chara_part name="puri_w" body=base kao=2 as=on ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:yoru:]
「……你又被南给骗了吧」[rhp]

[:princess:]
「『又』？」[rhp]

[:yoru:]
「这个世界由我主宰。我所说的才是真理。[rhr]
_　南的话语能有多少分量」[rhp]

[:princess:]
「可、可是……」[rhp]

[:yoru:]
「我和南都可以算是某种神明。所以才能创造这个异空间，[rhr]
_　把像你们这样的存在带到这里来的」[rhp]
[:yoru:]
「但那不是好事。……是绝对无法被原谅的事」[rhp]

[:princess:]
「等一下。……异空间？　不是彼岸吗？」[rhp]
[:princess:]
「那难道说…………还有活着的可能？」[rhp]

[:yoru:][yoru kao=12 ]
「没有那种事」[rhp]
[:yoru:][yoru kao=2 ]
「你们已经死了，只有这点南说的话绝不会有错」[rhp]
[:yoru:]
「虽然说了是从这里去往某处，但我也不清楚具体去向。[rhr]
_　或许根本不存在彼岸，而是作为另一个人转世重生」[rhp]
[:yoru:]
「我并不在意是哪一种，也不想了解。[rhr]
_　我的兴趣只集中在当下的你们身上，之后的事都无所谓」[rhp]
[:yoru:]
「快点离开这里，好好地死去吧。我的愿望仅此而已」[rhp]

[off_all]

[::]
虽然被告知了相当残酷的话，但由于他独特的氛围，[rhr]
反而难以产生深刻的悲伤或愤怒。[rhp]

[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="293" top="0" wait="false" time="150"]
[chara_part name="puri_w" body=base kao=2 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「―――……因为我没有生前的记忆，[rhr]
_　所以对前世的梦想或是执念什么的倒也没有」[rhp]
[:princess:]
「但我认为我被带到这里，肯定有什么意义」[rhp]

[:yoru:][yoru kao=2 ]
「没有那种东西。这段旅程不过是徒劳地浪费时间」[rhp]

[:princess:][puri_w kao=6 ]
「～～～～呜，顽固不化！」[rhp]

[off_all]

[::]
面对我竭尽全力的反抗，夜先生却面不改色。[rhr]
看来他真的完全没打算听我说话。[rhp]
但正因如此，我心中反而确立了一个坚定的决心。[rhp]

[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="293" top="0" wait="false" time="150"]
[chara_part name="puri_w" body=base kao=2 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「…………够了，我明白了」[rhp]
[:princess:]
「既然你说来这里毫无意义，那我就创造意义好了」[rhp]

[:yoru:][yoru kao=6 ]
「……哈？」[rhp]

[:princess:]
「从今以后，我要踏上寻找遗失记忆的旅程。[rhr]
_　把那些遗忘的梦想啊执念啊，全部重新找回来」[rhp]
[:princess:]
「然后，将它们全部实现就结束」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:yoru:][yoru kao=0 ]
「………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:princess:][puri_w kao=2 ]
「虽然夜先生的话确实很专横，但既然我已经听到了，[rhr]
_　也不能无视你的困扰」[rhp]
[:princess:]
「所以我想……找到让我、我们和你都能接受的方式」[rhp]

[:yoru:][yoru kao=12 ]
「…………。真是绕弯子的说法」[rhp]

[:princess:][puri_w kao=2 ]
「先说好，其他人会怎么做我可不知道。[rhr]
_　他们看起来根本不会听我说话」[rhp]
[:princess:]
「想下车的只有我。要说服大家的话，[rhr]
_　就得像现在这样挨个对他们说难听话才行」[rhp]

[:yoru:][yoru kao=6 ]
「……………、……暂且不论该不该恢复记忆」[rhp]
[:yoru:]
「就算这样，也无法原谅你们待在这里」[rhp]

[:princess:][puri_w kao=2 ]
「突然要人立刻下车也太过分了吧！[rhr]
_　至少给我时间来说服你啊」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:yoru:][yoru kao=3 ]
「………………」[rhp]

[:princess:][puri_w kao=3 ]
「夜先生……求你了。再稍微给我一点时间」[rhp]

[:yoru:][yoru kao=12 ]
「……………………」[rhp]

[off_all]

[::]
反复斟酌着。[rhr]
是盘算着要让我死心吗？还是说……[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:yoru:][yoru kao=2 ]
「……我现在就能立刻把你们赶出去。[rhr]
_　没这么做，只是因为那样对你们太残酷了」[rhp]
[:yoru:]
「被命运不断捉弄，连死后都无法如愿的人生。[rhr]
_　明明生而为人，没有比这更凄惨的事了吧」[rhp]

[off_all]

[::]
是在同情我吗？[rhr]
依然不明白缘由。[rhp]
……不过……[rhp]

[:yoru:][yoru kao=3 ]
「…………所以我想尊重。你们的意愿。[rhr]
_　尊重你们凭自己意志离开这列铁道的决定」[rhp]

[off_all]

[::]
感觉夜先生的表情似乎稍稍缓和了些。[rhr]
…………虽说争取到时间，是因为承诺了下车吗？[rhp]

[:yoru:][yoru kao=6 ]
「会让矢部那群庸医继续协助我。[rhr]
_　……要是没问题就随你们便吧」[rhp]

[:princess:][puri_w kao=5 ]
「夜先生……！」[rhp]

[:yoru:][yoru kao=3 ]
「叫夜就行。对我用敬称，会让人觉得脑袋不正常」[rhp]

[:princess:][puri_w kao=13 ]
「那、那个……夜，对吧！谢谢你理解我」[rhp]
[:princess:]
「我一定会找回记忆的方法。[rhr]
_　为了夜，也为了我自己。所以……再宽容我一阵子吧」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:yoru:][yoru kao=2 ]
「……………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:princess:][puri_w kao=3 as=on ]
「……还在生气吗？」[rhp]

[:yoru:][yoru kao=3 ]
「……对于这种稍加调整便能随意改变的存在[rhr]
_　我并不打算吹毛求疵」[rhp]

[off_all]

[::]
说完这话夜先生便站起身来，[rhr]
缓缓抬指移向我的前额。[rhp]
…………视线相交。[rhr]
那双仿佛要将被吸入的、寂寥月夜般的眼眸注视着我。[rhp]


[:yoru:]
「欢迎来到我的星空。……至少做个好梦吧」[rhp]

[::]
隐约感觉他笑了。[rhr]
那神情极为安详，却透着孤寂。[rhp]
为何要露出这样的表情？[rhr]
这疑问刚浮现在心头[rhp]

;****************************************
[bg storage="black.jpg" rule="020.png" time=1000]
;****************************************

[:yoru:]
「晚安，公主」[rhp]

[::]
――――――此后直至清晨，我的记忆便中断了。[rhp]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
[fbgm]
[s_mask storage="black.jpg" time=2000]
;****************************************

[jump storage="ss_main.ks" target="*start"]



[s]
