﻿
*start

[if exp="f.ev_a_04 == 1 "]
[jump target="*ss_2nd" cond="f.nigmode == 1 && ss_2nd_otiai == 1"]
[jump target="*ss_16" cond="f.ss_otiai >= 15"]
[jump target="*ss_15" cond="f.ss_otiai >= 14"]
[jump target="*ss_14" cond="f.ss_otiai >= 13"]
[jump target="*ss_13" cond="f.ss_otiai >= 12"]
[jump target="*ss_12" cond="f.ss_otiai >= 11"]
[jump target="*ss_11" cond="f.ss_otiai >= 10"]
[jump target="*ss_10" cond="f.ss_otiai >= 9"]
[jump target="*ss_09"]
[endif] 

[jump target="*ss_02" cond="f.ss_mujin >= 1"]
[jump target="*ss_01"]


;---------------------------------------------------------------------------------------------
*ss_01
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_05.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_02.ogg"]

[:princess:][puri_w ]
「嘿。这里就是展望室……」[rhp]

[::]
真安静好舒服啊。[rhr]
在这里一个人慢慢待着也不错！[rhp]

#
[off_all]

[eval exp="f.ss_mujin = 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_02
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_05.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_02.ogg"]

[:princess:][puri_w ]
「没有人……今天就在这里悠闲地度过吧」[rhp]

#
[off_all]


[jump target="*next"]

;---------------------------------------------------------------------------------------------
; ここからオッチー加入
;---------------------------------------------------------------------------------------------
*ss_09
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_07.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_02.ogg"]

[:princess:][puri_w kao=1 ]
「你……你好！　落合君」[rhp]

[:otiai:][otiai kao=12 ]
「………………」[rhp]
[:otiai:][otiai kao=0 ]
「…………啊。抱歉睡着了。什么事？」[rhp]

[:princess:][puri_w kao=13 ]
「没、没什么。你看起来很累呢」[rhp]

[:otiai:][otiai kao=7 ]
「是啊……最近睡得不太好」[rhp]

[:princess:][puri_w kao=1 ]
「这样啊。那今天就好好休息吧！」[rhp]

[:otiai:][otiai kao=12 ]
「嗯……」[rhp]

#
[off_all]

[eval exp="f.ss_otiai = 9"]
[eval exp="f.ss_2nd_otiai= 1"]

[jump target="*next"]
;---------------------------------------------------------------------------------------------
*ss_10
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_07.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_02.ogg"]

[:princess:][puri_w kao=1 ]
「落合君～～～」[rhp]

[:otiai:][otiai kao=2 ]
「干嘛啊……」[rhp]

[:princess:][puri_w kao=13 ]
「你看起来很闲呢。要和我一起玩吗？我带你在车内参观，」[rhp]

[:otiai:][otiai kao=12 ]
「不用了」[rhp]

[:princess:][puri_w kao=2 as=on ]
「！！为、为什么……」[rhp]

[:otiai:][otiai kao=2 ]
「你这种像对待小孩子的态度很烦人。要是能改掉的话陪你玩玩也行」[rhp]

[:princess:][puri_w kao=4 as=on ]
「………………」[rhp]

[:otiai:][otiai kao=6 as=on ]
[font color=0x4682b4]
（别僵住啊……！气死我了！）[rhp]
[resetfont]

#
[off_all]


[eval exp="f.ss_otiai = 10"]
[eval exp="f.ss_2nd_otiai= 1"]

[jump target="*next"]
;---------------------------------------------------------------------------------------------
*ss_11
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_07.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_02.ogg"]

[:princess:][puri_w kao=1 ]
「你好落合君。我们聊聊天吧！」[rhp]

[:otiai:][otiai kao=2 ]
「突然说这个。这种事不该说得这么直白吧」[rhp]

[:princess:][puri_w kao=6 ]
「因为不这样的话你好像就不会开口嘛」[rhp]

[:otiai:][otiai kao=2 as=on ]
「哈……好吧」[rhp]
[:otiai:][otiai kao=2 as=on ]
「那给我个话题吧。该聊些什么好？」[rhp]

[:princess:][puri_w kao=8 as=on ]
「诶？诶～～～！？那个……」[rhp]

[:otiai:][otiai kao=6 as=on ]
「这种事想好了再来啊……真是的」[rhp]

#
[off_all]



[eval exp="f.ss_otiai = 11"]
[eval exp="f.ss_2nd_otiai= 1"]

[jump target="*next"]
;---------------------------------------------------------------------------------------------
*ss_12
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_07.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_02.ogg"]


[:princess:][puri_w kao=5 ]
「议题！！　我考虑过了！」[rhp]

[:otiai:][otiai kao=2 as=on ]
「…………这、这样啊」[rhp]
[:otiai:][otiai kao=2 as=on ]
「那请讲。今天要讨论什么？」[rhp]

[:princess:][puri_w kao=13 ]
「『要和落合君搞好关系该怎么做？』就是这个」[rhp]

[:otiai:]
「你小子莫非是笨蛋？这不该是当着本人讨论的议题吧！」[rhp]

[:princess:][puri_w kao=5 ]
「吐槽得漂亮……！你很有天赋呢」[rhp]

[:otiai:]
「这家伙怎么回事……」[rhp]

#
[off_all]


[eval exp="f.ss_otiai = 12"]
[eval exp="f.ss_2nd_otiai= 1"]

[jump target="*next"]
;---------------------------------------------------------------------------------------------
*ss_013
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_07.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_02.ogg"]

[:princess:][puri_w kao=13 ]
「小猪崽！」[rhp]

[:otiai:][otiai kao=0 ]
「小猪崽？」[rhp]

[:princess:][puri_w kao=13 ]
「貉—子！」[rhp]

[:otiai:][otiai kao=2 as=on ]
「……貉、貉子……」[rhp]

[:princess:][puri_w kao=13 ]
「狐狸！」[rhp]

[:otiai:][otiai kao=6 as=on ]
「………………」[rhp]

[:princess:][puri_w kao=2 ]
「狐——狸！」[rhp]

[:otiai:]
「……我说啊。能不能别把我当小孩对待？[rhr]
_　我早过了会因为童谣高兴的年纪了」[rhp]

[:princess:][puri_w kao=8 ]
「诶～～。我特意挑了首能拉近关系的歌耶」[rhp]

[:otiai:][otiai kao=12 as=on ]
「首先希望你停止唱歌……」[rhp]

#
[off_all]

[eval exp="f.ss_otiai = 13"]
[eval exp="f.ss_2nd_otiai= 1"]

[jump target="*next"]
;---------------------------------------------------------------------------------------------
*ss_14
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_07.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_02.ogg"]

[:princess:][puri_w kao=1 ]
「落合君你啊，在那边世界时是怎样的孩子？」[rhp]

[:otiai:][otiai kao=6 ]
「只是个普通学生罢了」[rhp]

[:princess:][puri_w kao=1 ]
「这样根本不明白嘛。[rhr]
_　比如做过什么事啊，喜欢什么之类的啦」[rhp]

[:otiai:][otiai kao=0 ]
「………………」[rhp]

[:princess:][puri_w kao=1 ]
「？」[rhp]

[:otiai:][otiai kao=12 ]
「…………秘密」[rhp]

[:princess:][puri_w kao=8 ]
「诶—！真没劲」[rhp]

[:otiai:][otiai kao=3 ]
「………………」[rhp]

#
[off_all]

[eval exp="f.ss_otiai = 14"]
[eval exp="f.ss_2nd_otiai= 1"]

[jump target="*next"]
;---------------------------------------------------------------------------------------------
*ss_15
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_07.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_02.ogg"]

[:princess:][puri_w kao=14 ]
「好啦，落合君看这边～」[rhp]

[:otiai:][otiai kao=2 ]
「这次又是什么啊……每次都这样」[rhp]

[:princess:][puri_w kao=1 ]
「来玩歌曲竞猜吧。落合君能猜中吗？」[rhp]

[:otiai:][otiai kao=2 ]
「哈啊……又把我当小孩子……」[rhp]

[:princess:][puri_w kao=13 ]
「嘟噜」[rhp]

[:otiai:][otiai kao=6 ]
「嗯？」[rhp]

[:princess:][puri_w kao=13 ]
「好的，刚才这段是什么曲子呢？」[rhp]

[:otiai:][otiai kao=2 as=on ]
「谁会出这种口述题目啊！这种事怎么可能知道！」[rhp]

[:princess:][puri_w kao=5 ]
「好啦好啦就算答错也别沮丧。来，下一题」[rhp]
[:princess:][puri_w kao=11 ]
「唰咚」[rhp]

[:otiai:][otiai kao=2 as=on ]
[font color=0x4682b4]
（不、不行了这家伙……根本听不进人说话……）[rhp]
[resetfont]

#
[off_all]


[eval exp="f.ss_otiai = 15"]
[eval exp="f.ss_2nd_otiai= 1"]

[jump target="*next"]
;---------------------------------------------------------------------------------------------
*ss_16
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_07.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_02.ogg"]

[:princess:][puri_w kao=3 ]
「落合君。我好像发现了呢」[rhp]

[:otiai:][otiai kao=0 ]
「什么风雅？」[rhp]

[:princess:][puri_w kao=3 ]
「我觉得自己动不动就会唱歌这件事啊……[rhr]
_　这倒不是特意把落合君当小孩看待」[rhp]
[:princess:][puri_w kao=3 ]
「可能只是我的心理年龄比较幼稚罢了……」[rhp]

[:otiai:][otiai kao=2 as=on ]
「……………………」[rhp]

[:princess:]
「猜对了，呢……」[rhp]

[:otiai:][otiai kao=6 as=on ]
「别、别消沉啊。我什么都没说啊」[rhp]

[:princess:][puri_w kao=2 as=on ]
「没关系！我早就知道了。[rhr]
_　对话陷入困境就用唱歌逃避……是有这种倾向呢」[rhp]
「但是！你也玩得挺开心对吧！？」[rhp]

[:otiai:][otiai kao=2 as=on ]
「嗯～～……」[rhp]
「还算凑合」[rhr]
[font color=0x4682b4]
（作为旁观者来说）[rhp]
[resetfont]

[:princess:][puri_w kao=14 ]
「果然！太好了～。我找回自信了。[rhr]
_　谢谢你呢，落合君！」[rhp]

[:otiai:]
「还是一如既往地单纯呢……」[rhp]


#
[off_all]

[eval exp="f.ss_otiai = 16"]
[eval exp="f.ss_2nd_otiai= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_2nd
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_07.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_02.ogg"]

[:princess:][puri_w kao=1 ]
「你好！　落合君」[rhp]

[off_all]

[:otiai:][otiai kao=12 ]
「………………」[rhp]

[off_all]

[:princess:][puri_w kao=13 ]
「熟睡！　真可爱呀。现在就先让他这样睡吧……」[rhp]

#
[off_all]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
;---------------------------------------------------------------------------------------------


*next

#

[if exp="f.ev_a_07 ==1 && f.nigmode == 1"]
[jump storage="ev_a_07.ks" target="*start"]

;ev_6への分岐
[elsif exp="f.ev_a_06 ==1 && f.nigmode == 1"]
[jump storage="ev_a_06.ks" target="*start"]

;ev_3への分岐
[elsif exp="f.ev_a_03 ==1 && f.nigmode == 1"]
[jump storage="ev_a_03.ks" target="*start"]

;ev_2への分岐
[elsif exp="f.ev_a_02 ==1 && f.nigmode == 1"]
[jump storage="ev_a_02.ks" target="*start"]

;夜モードの場合
[elsif exp="f.nigmode == 1"]
[jump storage="ss_main.ks" target="*start"]

;昼モード
[else]
[jump storage="ss_select.ks" target="*select_scene_nig"]
[endif]


