﻿*start

;--------------------------------------------------------------------------------------------
;▼フルボイスセット▼
; サウス
[voconfig sebuf=1 name=sausu vostorage="sausu/full/{number}.ogg" number=269]
;--------------------------------------------------------------------------------------------

;****************************************

[s_mask color=0xffffff time=3000]
; 背景表示
[bg storage="sky_08.jpg" time=100]
[free_filter ]
; ウィンドゥの設定
[position layer="message0" frame="win2.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[s_mask_off time=3000]

[bgm storage="bgm_07.ogg"]
;****************************************

2019年　3月[rhp]
那则消息，是由来探病的宙君告知的。[rhp]

;****************************************
[bg storage="hsps_09.jpg" time=1000]
;****************************************

[:sora:][sora body=prain kao=5 ]
「―――我啊，今年开始要去上补习班了」[rhp]

[:himeko:]
「诶」[rhp]

[:sora:][sora body=prain kao=13 ]
「既然目标是应届考上医科大学，[rhr]
_　现在开始不加把劲可不行啊」[rhp]
[:sora:]
「以后可能没法经常来这里了……」[rhp]

[:himeko:]
「………………」[rhp]

[:sora:][sora body=prain kao=3 ]
「突然说这个很抱歉。但是，」[rhp]

[:himeko:]
「啊……这、这样啊。补习班啊！虽然会很辛苦但你要加油哦！」[rhp]

[:sora:][p_so_34][sora body=prain kao=8 ]
「……、对不起。你会觉得寂寞吧……」[rhp]

[:himeko:]
「别在意啦。虽然确实会寂寞，[rhr]
_　但只要宙君和大家都在努力，我也不能认输啊」[rhp]

[:sora:][sora body=prain kao=1 ]
「很快就不用这么拼命了。[rhr]
_　无论是我的考试，还是你的病」[rhp]
[:sora:]
「只要我能[player2]治好你的病，之后就能轻松过日子了」[rhp]

[:himeko:]
「嗯！说的对呢」[rhp]

[:sora:]
「等着我吧。录取通知书，我会第一个拿来给你看」[rhp]

[:himeko:]
「嘿嘿嘿！那真是令人期待呀」[rhp]

[:sora:][p_so_09][sora body=prain kao=2 as=on ]
「你是在小瞧我吧……！」[rhp]

[:himeko:]
「………………」[rhp]

[:sora:]
「干嘛突然不说话啊！」[rhp]

[:himeko:]
「…………那、那个啊宙君」[rhp]

[:sora:][sora body=prain kao=0 ]
「……？怎么了？」[rhp]

[:himeko:]
「其实我呢……」[rhp]
「………………」[rhp]

[:sora:]
「…………？」[rhp]

[:himeko:]
「――――――唔嗯！　果然还是算了。忘掉吧！」[rhp]

[:sora:][p_so_19][sora body=prain kao=5 ]
「别别别，别说到一半停下来啊。我很在意啊」[rhp]
[:sora:]
「……难道说，你也要参加考试吗？」[rhp]

[:himeko:]
「切、才不是啦！怎么可能嘛！[rhr]
_　别说高中了连初中都没正经上过耶」[rhp]
[:himeko:]
「好了好了，就到这里吧！[rhr]
_　想挖女孩子秘密的话，米卡亲警察要来咯」[rhp]

[:sora:][sora body=prain kao=2 ]
「米卡亲警察？」[rhp]

[:tiaki:][p_mk_35][tiaki kao=13 hh=on ]
[font size=27]
「米卡亲警察驾―――到！」[rhp]

[:sora:][sora body=prain kao=4 as=on ]
「呀！！」[rhp]
[resetfont]

[:himeko:]
「时机正好！」[rhp]

[:sora:][sora body=prain kao=7 as=on ]
「为什么总能刚好出现啊！刚才都听见了吗！？」[rhp]

[:tiaki:][tiaki kao=5 ]
「米卡亲警察……那是少女的110报警电话」[rhp]

[:sora:][sora body=prain kao=6 ]
「？？？」[rhp]

[:tiaki:][p_mk_15][tiaki kao=1 hh=on ]
「开玩笑的♡　到测体温时间啦」[rhp]

[:sora:][sora body=prain kao=6 ]
「哦这样啊……那我先走了」[rhp]

[:tiaki:][tiaki kao=13 ]
「哎呀？不用这么客气嘛」[rhp]

[:sora:]
「巴士快到点了」[rhp]

[:tiaki:][tiaki kao=3 hh=on ]
「真遗憾呢。本来想三个人开女子会的」[rhp]

[:sora:][sora body=prain kao=6 as=on ]
「女子？」[rhp]

[:tiaki:][tiaki kao=2 ]
「没礼貌！人家明明还是少女好吗！？」[rhp]

[:sora:]
「不是，我是说我……」[rhp]

[off_all]

[:himeko:]
「再见啦宙君。要加油学习哦」[rhp]

[:sora:][sora body=prain kao=0 ]
「…………、哦」[rhp]

[off_all]

;****************************************
#
[bg_b storage="hsps_09.jpg" rule="002.png" time=1000]
;****************************************

[:tiaki:][p_mk_14][tiaki kao=13 ]
「――――――嘿～。宙君居然上补习班啊」[rhp]

[:himeko:]
「是啊。很努力了呢」[rhp]
[:himeko:]
「……虽然说了不寂寞，但其实有点寂寞呢」[rhp]

[:tiaki:][tiaki kao=1 ]
「那是当然的啦。明明关系那么好，不寂寞才奇怪呢」[rhp]
[:tiaki:]
「一年后啊……等到明年三月感觉好漫长呢」[rhp]

[:himeko:]
「嗯……真希望春天快点来啊」[rhp]

[:tiaki:][p_mk_04][tiaki kao=3 ]
「……啊，对了。[player2]酱」[rhp]
[:tiaki:]
「之前拜托你的事……」[rhp]

[:himeko:]
「…………啊」[rhp]

[:tiaki:][p_mk_34][tiaki kao=8 as=on ]
「……抱歉。果然按照[player2]亲的条件的话……」[rhp]

[:himeko:]
「那个，还是算了吧」[rhp]

[:tiaki:][tiaki kao=4 ]
「嗯？」[rhp]

[:himeko:]
「只是试着问问看而已！[rhr]
_　真的别放在心上。麻烦你了真不好意思」[rhp]

[:tiaki:][p_mk_22][tiaki kao=3 ]
「可、可是……」[rhp]

[:himeko:]
「话说回来，仔细想想也是理所当然的吧。[rhr]
_　明明连初中都没上过……升学什么的」[rhp]
[:himeko:]
「不过嘛！在这里悠闲度日也挺开心的吧。啊哈哈」[rhp]

[:tiaki:][tiaki kao=8 as=on ]
「……[player2]酱」[rhp]

[:himeko:]
「米卡亲！再不快点量体温就要迟到了，会被矢部医生骂的哦」[rhp]

[:tiaki:][tiaki kao=1 ]
「…………嗯」[rhp]

[:himeko:]
「真是的！别这么消沉啦。话说为什么会变成我在安慰人啊」[rhp]
[:himeko:]
「明明想被安慰的，是我才对吧！啊哈哈……」[rhp]

[off_all]

[:tiaki:][p_mk_33]
「…………对不起……」[rhp]

[:himeko:]
「别、别哭啊……这种、这种事情不值得哭……」[rhp]
[:himeko:]
「…………」[rhp]

[::]
唉——[rhp]
虽然早有预料，但还是很难受。[rhp]
……又有一个梦想，就这样破灭了。[rhp]

;****************************************
[set_n storage="hsps_09n.jpg"]
;****************************************

[::]
2019年12月[rhp]
与宙君疏远后，半年多的时光已然流逝。[rhp]
理央君在那之前就几乎不再露面，[rhr]
医院里也已不见和君、博士和薰君的踪影。[rhp]
虽然曾经很喜欢与人相伴，[rhr]
如今却也完全习惯了独自度日的方式。[rhp]
今天也同样无所事事，只是在床铺上茫然望着窗外。[rhp]
虽然讨厌空闲，但真要做什么却又觉得麻烦。[rhp]
倒也不是在意这件事。[rhr]
因为这里为终日卧床的人也配备了舒适设施。[rhp]
101号室本就是为只能这样生活的人准备的房间，[rhr]
虽然说是理所当然……[rhp]

[:takeru:][take kao=1 ]
「晚上好，星名小姐」[rhp]

[off_all]

病房门突然被推开。[rhp]
如今会推开101号室房门的，除了代替忙碌工作的父母，[rhr]
也就只剩矢部医生和米卡亲了。[rhp]

[chara_part name="take" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:takeru:][p_tk_02]
「到诊察时间了。……今天气色不错」[rhp]

[:tiaki:][p_mk_01][tiaki kao=13 ]
「最近状态一直不太好嘛。[rhr]
_　有没有发生什么变化？比如困扰的事，或是变得棘手的事」[rhp]

[:himeko:]
「没事。只是更容易疲倦，其他倒没什么变化」[rhp]

[:tiaki:][p_tk_29][tiaki kao=1 ]
「这样啊。……容易疲倦也是没办法的。[rhr]
_　毕竟已经是冬天了，我们多少也会感到不适」[rhp]

[:tiaki:][tiaki kao=13 ]
「我这次感冒是从鼻子开始的呢。[player2]小星名也要当心哦！」[rhp]

[:himeko:]
「嗯。医生和米卡亲也不要太勉强自己」[rhp]

[:takeru:][take kao=6 ]
「我可没勉强」[rhp]

[:himeko:]
「是吗。总觉得比从前少了点朝气。[rhr]
_　有时还会挂着黑眼圈」[rhp]
[:himeko:]
「其他孩子姑且不论，我的事不必这么拼命的。[rhr]
_　我维持现状就好。毕竟这里是临终关怀——」[rhp]

[off_all]

[:takeru:][p_tk_04][take kao=2 ]
「星名小姐」[rhp]

[:himeko:]
「！」[rhp]

[:takeru:][p_tk_26][take kao=0 ]
「要是把话说完我可要生气了」[rhp]

[:himeko:]
「…………。……对不起」[rhp]

[:takeru:][p_tk_27][take kao=1 ]
「你的关心让我很开心。但我真的没有勉强自己。[rhr]
_　医生为患者拼命，就像人需要呼吸般理所当然」[rhp]

[off_all]

[:tiaki:][p_mk_15][tiaki kao=14 ]
「对我们来说，能看到你的笑容才是最开心的事。[rhr]
_　为此我们什么都愿意拼上全力」[rhp]
[:tiaki:]
「明天也要精神满满地见面哦！　[player2]酱」[rhp]

[:himeko:]
「……这样啊。说得对，嗯」[rhp]

[off_all]

[chara_part name="take" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:himeko:]
「害你们担心了。晚安两位」[rhp]

[:takeru:][take kao=1 ]
「晚安」[rhp]

[:tiaki:][tiaki kao=13 ]
「晚安」[rhp]

[off_all]

;****************************************
#
[bg_b storage="hsps_06n.jpg" rule="002.png"]
;****************************************

[chara_part name="take" body=base kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]


[:tiaki:][p_mk_17]
「――――――先生您怎么看？」[rhp]

[:takeru:][p_tk_19][take kao=6 ]
「…………什么怎么看？」[rhp]

[:tiaki:][tiaki kao=3 ]
「[player2]关于小酱的事。[rhr]
_　她现在已经……能看见了吗」[rhp]

[:takeru:][take kao=0 ]
「是在说夜他们吗」[rhp]

[:tiaki:][tiaki kao=8 as=on ]
「是的。据说与夜君他们的意志无关，将死之人[rhr]
_　会逐渐看清他们的模样……」[rhp]

[:takeru:][take kao=12 ]
「我认为并非如此。倘若真能看见，她的态度也该[rhr]
_　有所变化才是。那孩子藏不住心事的」[rhp]

[:tiaki:][p_mk_01][tiaki kao=1 ]
「说得对。是我多虑了……」[rhp]
[:tiaki:]
「……老师您觉得[player2]你觉得小酱还能撑多久」[rhp]

[:takeru:][p_tk_25][take kao=3 as=on ]
「…………不会太长了」[rhp]

[:tiaki:][p_mk_11][tiaki kao=3 ]
「……！」[rhp]

[:takeru:][take kao=8 as=on ]
「能坚持到现在已经非常了不起。[rhr]
_　……最初根本没料到能维持到这个阶段」[rhp]
「…………正因如此，才更不甘心」[rhp]

[:tiaki:][tiaki kao=0 as=on ]
「老师……」[rhp]

[:takeru:][p_tk_25][take kao=2 ]
「长久以来都感到焦虑万分。[rhr]
_　明明那孩子就在那幅画中世界里，却什么都做不到」[rhp]
[:takeru:]
「一个月后就是和夜约定之日满两周年。[rhr]
_　我们终于能获得接触那个世界的途径」[rhp]
[:takeru:]
「但别忘了那是最坏情况下的手段。[rhr]
_　我是医生。人死后再施救就太迟了」[rhp]
[:takeru:]
「我们所见到的绝非希望。」[rhr]
_　今后也请为星名小姐的治疗全力以赴吧」[rhp]

[:tiaki:][p_mk_24][tiaki kao=3 hh=on ]
「―――……好的！当然」[rhp]

;****************************************
#
[set_b storage="hsps_09n.jpg" time=1500]
;人外の透明フィルター
[filter layer="1" name="sausu" opacity=50]
;****************************************

[:himeko:]
「……真不擅长撒谎啊，你们两个」[rhp]

[::]
我最了解我自己。[rhr]
……我大概已经，时日无多了吧。[rhp]
身体一天比一天沉重。[rhr]
明明曾经那么爱吃，如今却食欲全无。[rhp]
就连头发……也曾最爱长发飘飘的模样。[rhp]
一切都在与过去的自己渐行渐远。[rhp]

[:himeko:]
[font color=0x4682b4]
（…………话虽如此。但这是我自己的问题）[rhp]
[:himeko:]
（医生们已经那般拼命为我治疗了）[rhr]
_　至少不该让他们再为我的事操心）[rhp]
[resetfont]

[::]
若有可能，我想以平常的模样走到最后。[rhp]
正因比谁都目睹过同伴们的泪水才这般想。[rhr]
因为有人离去，是件非常非常痛苦的事。[rhp]
轮到我时，不愿让待我亲善的大家承受那种感受。[rhp]

[:himeko:]
「……………………」[rhp]

[::]
怔怔地望着窗外。[rhp]
最近总是这样度日如年，[rhr]
回过神来已沉入梦乡，周而复始迎来又一个黎明。[rhp]
这般荒芜的生存还能称之为活着吗。[rhr]
死亡究竟是什么感觉呢。[rhp]
如果比现在痛苦百倍的话，那还是想活下去的。[rhr]
我的求生欲，也就仅此而已。[rhp]
因为一直相伴在侧，所以不畏惧生命的终结。[rhp]
只是，单纯地感到不安。[rhp]
当灵魂消散，肉体焚毁，我彻底不复存在时。[rhp]
仅知晓六叠大小的世界的我，[rhr]
能断言自己确实存在过这个世界吗。[rhp]
光是想象就令人恐惧。[rhp]
我降生于世这件事，究竟是否有意义。[rhp]
我能在这个世界留下的痕迹――――――[rhp]

[:unknown:][sausu kao=1 ]
「在苦恼呢」[rhp]

[off_all]

[:himeko:]
「――――――！」[rhp]

[::]
本该无人的房间里，正侧面突然传来男声。[rhp]

[sausu kao=13 ]

条件反射转身时，发现床铺旁的圆椅上，[rhr]
坐着个装束奇异的男人，正朝我微笑。[rhp]
正震惊得发不出声，他却噗嗤轻笑出声说道：[rhp]

[:unknown:][p_s_06][sausu kao=5 hh=on ]
「终于能听见我说话了呢。[rhr]
_　明明就在身旁却未被察觉，一直很寂寞啊」[rhp]

[:himeko:]
「你、是谁……！？为什么会在——」[rhp]

[:sausu:][sausu kao=1 ]
「我是南。住在这个房间的千纸鹤之神哦」[rhp]

[:himeko:]
「千纸鹤……」[rhp]

[off_all]

[::]
我看向装饰在床铺旁那串七彩的千纸鹤。[rhr]
那是搬进这个房间前就摆放着的、[rhr]
我们也曾帮忙制作的博士的千纸鹤。[rhp]
自博士去世后，就一直传承在这个房间里。[rhp]
这纸鹤不仅寄托着博士的心愿，[rhr]
还承载着临终关怀院所有人的祈愿。[rhp]

[sausu kao=13 ]

[:himeko:]
「神明……？真的吗？」[rhp]

[:sausu:][sausu kao=5 ]
「正是。啊、先说好我可不是死神。[rhr]
_　只是时机到了才能被看见，我可是善良的神明大人」[rhp]

[:himeko:]
「时机……」[rhp]

[:sausu:][p_s_16][sausu kao=14 ]
「我是来迎接你的」[rhp]

[:himeko:]
「这不就是死神嘛！」[rhp]

[:sausu:][sausu kao=3 as=on ]
「不不、不是这样的」[rhp]
[:sausu:]
「我是来迎接康贝瑞拉的」[rhp]

[:himeko:]
「康贝瑞拉……银河铁道？」[rhp]

[:sausu:][sausu kao=1 ]
「很了解嘛。是听博士说的？」[rhp]

[:himeko:]
「你认识博士？」[rhp]

[:sausu:][p_s_01][sausu kao=8 ]
「嗯……是我无可替代的挚友」[rhp]

[:himeko:]
「原来是这样啊……」[rhp]

[off_all]

[:himeko:]
[font color=0x4682b4]
（那博士也一直能看见这个人吗）[rhp]
[:himeko:]
（……博士。原来你并不孤单啊）[rhp]
[resetfont]

[::]
晚年的博士忘却了我们所有人的事，终日沉迷书本。[rhp]
说不定连他的事也忘记了……[rhr]
但比起后来无法再相见的我们，想必是他陪伴博士更久。[rhp]
既然居住在这个房间，那么博士临终的时刻[rhr]
他必定也一直在旁守护。[rhp]

[:sausu:][sausu kao=1 ]
「[player2]你对银河铁道很了解吗？[rhp]

[:himeko:]
「哎、呃……倒也算不上特别了解，[rhr]
_　因为这是博士喜欢的故事，所以让他给我讲了好多次哦」[rhp]

[:sausu:][p_s_31][sausu kao=5 hh=on ]
「我要带你们去乘坐的就是那辆银河铁道」[rhp]

[:himeko:]
「哈……？你在说什么啊。那只是书本里的故事，」[rhp]

[:sausu:][sausu kao=13 ]
「我创造出来了。为了你们」[rhp]
[:sausu:]
「大家都在[player2]等着你。要和我一起来吗」[rhp]

[:himeko:]
「…………那样的话，就意味着会死对吧」[rhp]

[:sausu:][sausu kao=1 ]
「……没错。怎么了？」[rhp]

[:himeko:]
「你说和你一起走，就是要杀死我然后带走我的意思？」[rhp]

[:sausu:][sausu kao=8 as=on ]
「不不不。只是说结束这边的人生之后的事」[rhp]
[:sausu:]
「这样吧。要不要先稍微去看一眼？你一定会喜欢[rhr]
_　我想让你知道我创造的宝石箱是多么美妙的地方」[rhp]

[:himeko:]
「诶！？可、可是我还在活着啊」[rhp]

[:sausu:][p_s_14][sausu kao=1 hh=on ]
「放心。这仅仅是个体验版，[rhr]
_　过完一夜就能让你回到这边的世界」[rhp]
[:sausu:]
「那个世界是怎样的地方，究竟有多么美好[rhr]
_　比起听别人说，不如亲自确认」[rhp]
[:sausu:]
「亲眼见证之后，再重新决定今后的事也不迟」[rhp]
[:sausu:]
「虽然我觉得答案已经很明显了呢」[rhp]

[off_all]

[::]
听到银河铁道，首先浮现的是入口处那幅绘画。[rhp]
我曾经多次和博士、和君他们谈起，总有一天想去那幅画中的世界。[rhr]
在这千纸鹤中的一只上，我似乎也确实寄托了这样的愿望。[rhp]
……仅仅一个晚上的话，应该没关系吧。[rhp]

;****************************************

[s_mask color=0x000000 time=3000]
; 背景表示
[bg storage="train_05.jpg" time=100]
; 全部のフィルターを打ち消す
[free_filter ]
; ウィンドゥの設定
[position layer="message0" frame="win.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[s_mask_off time=3000]

;****************************************

[:himeko:]
「…………！」[rhp]

[::]
睁开眼时，我正身处电车之中。[rhp]
这究竟是怎样的车厢？[rhr]
直达天花板的车窗，与我在书中读到的描述截然不同。[rhp]
最令人震惊的莫过于车窗外的景色。[rhr]
四周尽是星之海。这般景象简直像是……[rhp]

[:himeko:]
「真的是银河铁道……！」[rhp]

[:sausu:][p_s_16][sausu kao=1 ]
「很美吧？……再看看你自己的模样」[rhp]

[:himeko:]
「……！」[rhp]

[::]
因周遭景色的冲击而失神的我，[rhr]
重新凝视起车窗上倒映出的身影。[rhp]

[puri_w kao=4 as=on ]

…………这是我？[rhr]
竟然能用自己的双腿站立。[rhr]
头发也变回了长发时的样子，还穿着从未穿过的可爱连衣裙。[rhp]
简直如同我曾在画纸上描绘过的公主画像。[rhp]

[:sausu:][sausu kao=13 ]
「可以从床铺上起身。能正常走路。[rhr]
_　甚至能奔跑。当然也拥有常人的体力」[rhp]
[:sausu:]
「不必再吃乏味的病号餐，可以尽情享用喜爱的食物。[rhr]
_　就连衣服，也能穿上更漂亮可爱的」[rhp]
[:sausu:]
「这个世界里的你接近无限自由且完美。[rhr]
_　可以去任何地方。能够实现任何事。一切都将如你所愿」[rhp]

[:himeko:][puri_w kao=3 ]
「………………」[rhp]

[off_all]

[::]
…………这就是银河铁道吗。[rhr]
无论如何努力都无法获得的东西，在这里都能得到。[rhp]
宛如梦境。这果然是梦吗？[rhr]
倘若这是梦，但愿永不醒来。[rhp]

[:sausu:][p_s_04][sausu kao=5 ]
「对了。让你去见见公主吧」[rhp]

[:himeko:][puri_w kao=4 hh=on ]
「公主……？这个世界还有公主殿下吗？」[rhp]

[:sausu:][sausu kao=7 as=on ]
「诶？……啊！不对不对。公主是昵称，[rhr]
_　准确来说是'你的分身'」[rhp]

[:himeko:][puri_w kao=6 ]
「分、分身？」[rhp]

[:sausu:][sausu kao=1 ]
「在你正式来到这个世界之前，[rhr]
_　代替你[player2]担任『替身』的孩子」[rhp]
[:sausu:]
「即使在临终关怀院里，你也是最受欢迎的人。[rhr]
_　为了让先来到这里的孩子不寂寞，我才创造了这个分身」[rhp]
[:sausu:]
「她可是窥探过你的内心，饱含着你理想中所有要素的女孩。[rhr]
_　相信你很快也会喜欢上她」[rhp]

[off_all]

[se storage="hand_05.ogg"]

[::]
南得意洋洋地说着，打了个响指。[rhp]

;****************************************
[se storage="mag_08.ogg"]
[bg storage="white.jpg" time=500]
;****************************************

霎时间眼前涌现出光的漩涡，[rhr]
周围顿时闪闪发亮起来。[rhp]
在逐渐趋于平静的光芒中，浮现出一个宛如人影的存在。[rhp]

;****************************************
[fse]
[bg storage="train_05.jpg" time=500]
;****************************************

[:princess:][puri kao=12 ]
「――――――……」[rhp]

[::]
洁白的连衣裙、长长的金发、小小的王冠。[rhr]
出现在眼前的，是如同将此刻的我映在镜中的少女。[rhp]

[off_all]

她缓缓睁开双眼，滴溜溜地环顾四周之后，[rhr]
立刻将视线转向我，展现出一个灿烂的笑容。[rhp]

[:princess:][puri kao=1 ]
「你好！」[rhp]

[:himeko:][puri_w kao=3 as=on ]
「！！」[rhp]

[off_all]

[::]
开朗明快的声音。虽说印象不同，但我想这和我的嗓音……是相同的。[rhr]
太过震撼，我只能呆呆地张合着嘴巴。[rhp]

[:sausu:][p_s_31][sausu kao=14 hh=on ]
「呵呵呵！被吓到了呢！总觉得好开心―――」[rhp]

[:princess:][puri kao=2 as=on ]
「南！」[rhp]

[se storage="hand_05.ogg"]
[yurasu]

[:sausu:][p_s_27][sausu kao=8 as=on ]
「好痛……干、干嘛打我？太过分啦」[rhp]

[:princess:][puri kao=5 ]
「还好我是个乖孩子！这要放在现实世界可是犯罪啊。[rhr]
_　二话不说就把人带来不是很可怜吗！」[rhp]

[:sausu:][sausu kao=3 as=on ]
「不对不对。我有好好拒绝过的」[rhp]

[:princess:][puri kao=2 ]
「真的吗？可看她一副受惊过度的样子，很可疑呢……」[rhp]
[:princess:]
「他那个老幺性子太根深蒂固了，有时候真的会很任性。[rhr]
_　不愿意的话必须明确说出来才行哦，『我』！」[rhp]

[off_all]

[:himeko:][puri_w kao=4 as=on ]
「呃。好、好的……！」[rhp]

[off_all]

[chara_part name="puri" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="puri" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=3 as=on ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sausu:][p_s_18]
「这么说我也太伤人啦……」[rhp]

[:princess:][puri kao=6 as=on ]
「正如别人所说 我就是这样的性格呢。[rhr]
_　就算摆出彬彬有礼的态度 也不保证不会被讨厌」[rhp]

[:sausu:][sausu kao=7 ]
「这样啊。那我可得注意了」[rhp]

[:princess:][puri kao=5 ]
「对对 这样就好」[rhp]

[off_all]

[:princess:][puri kao=1 ]
「话说回来 『我』。来到这个世界感觉如何？」[rhp]

[:himeko:][puri_w kao=8 as=on ]
「觉、觉得挺开心的……。[rhr]
_　毕竟第一次坐电车……而且还是真正的银河铁道」[rhp]

[:princess:][puri kao=13 hh=on ]
「对吧！你能喜欢真是太好了。毕竟将来要住在这里呢」[rhp]
[:princess:]
「虽然这样的生活即将结束有点寂寞，[rhr]
_　但我会履行好为你而存在的职责直到最后」[rhp]
[:princess:]
「随时都可以哦。尽管扑进这副身体里来吧！」[rhp]

[:himeko:][puri_w kao=3 ]
「……、……」[rhp]

[off_all]

[::]
虽然南说这是我理想的投射，[rhr]
但这种既视感我很清楚。[rhp]
遣词造句都是只在书上见过的腔调，[rhr]
虽说外貌确实符合我心目中『完美的女孩子』形象。[rhp]
这孩子肯定就是 当年还健康时的我。[rhp]
充满毫无根据的自信 每天都过得很快乐，[rhr]
还以为生病是什么玩笑话那时的我。[rhp]
她那份活泼与明朗 甚至让我感到几分怀念。[rhp]
……几乎不忍直视。[rhp]

[off_all]

[chara_part name="puri" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="puri" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sausu:]
「好了……今天姑且先回去吧。[rhr]
_　以后的事，等回去再慢慢考虑就好」[rhp]

[:princess:][puri kao=4 hh=on ]
「咦、这就要走了吗？才刚来不是！[rhr]
_　再多待一会儿也可以的」[rhp]

[:sausu:][p_s_15][sausu kao=1 ]
「说到底我只是想证明这个世界真实存在这件事。[rhr]
_　原本就没打算久留」[rhp]

[:princess:][puri kao=3 ]
「这样啊……真遗憾。[rhr]
_　那至少去见见快斗他们也好啊」[rhp]

[off_all]

[:himeko:][puri_w kao=7 as=on ]
[font color=0x4682b4]
（快斗？有这个人吗……）[rhp]
[resetfont]

[off_all]

[chara_part name="puri" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="puri" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sausu:][p_s_30]
「他们不必了。还太早」[rhp]
[:sausu:]
「…………毕竟刚发生过那种事」[rhp]

[:princess:][puri kao=12 ]
「…………明智的决定」[rhp]

[:sausu:][sausu kao=5 hh=on ]
「况且啊，把快乐留到后面比较好吧？[rhr]
_　在那之前，[player2]就拜托你代为照管了。公主」[rhp]

[:princess:][puri kao=13 ]
「好的，交给我吧」[rhp]

[off_all]


[:princess:][puri kao=1 ]
「那么下次见，[player2]。[rhr]
_　我会代替你，把大家好好凝聚起来的！」[rhp]

[::]
被那毫无阴霾的笑容所震慑，我只能勉强点了点头。[rhr]
耀眼到令人眩目的少女，公主。这正是我想成为的模样。[rhp]

[off_all]

[:sausu:][sausu kao=1 ]
「[player2]。准备好回去了吗？还有其他想问的事吗？」[rhp]

[:himeko:][puri_w kao=3 ]
「………………」[rhp]

[:sausu:][p_s_04][sausu kao=4 ]
「[player2]？」[rhp]

[:himeko:][puri_w kao=7 ]
「……！啊、嗯」[rhp]

[off_all]

[chara_part name="puri" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="puri" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=1 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:himeko:]
「谢谢，那个……公主。能和你交谈真是太好了」[rhp]

[:princess:][puri kao=13 hh=on ]
「我才是，虽然短暂但很开心呢」[rhp]

[off_all]

[:princess:]
「那我们就改天再见了」[rhp]

[:himeko:]
「嗯……」[rhp]

;****************************************

#
[s_mask color=0x000000 time=3000]
; 背景表示
[bg storage="hsps_09n.jpg" time=100]
; 夜フィルター
[filter layer="1" brightness="60"]
; ウィンドゥの設定
[position layer="message0" frame="win2.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[s_mask_off time=3000]

;****************************************

[:himeko:]
「――――――……嗯」[rhp]

[::]
刚意识到被光芒包裹时，我已然回到了病房的床铺上。[rhp]
低头看向自己的身体，仍是平常的病号服。[rhr]
那件华丽礼服自然早已消失无踪。[rhp]
抚摸头顶，触到的不是王冠，而是戴惯了的针织帽。[rhp]

[:himeko:]
[font color=0x4682b4]
（……梦……）[rhp]
[resetfont]

[:sausu:][p_s_16][sausu kao=13 ]
「感觉如何？」[rhp]

[:himeko:]
「…………！」[rhp]

[off_all]

[::]
与最初完全相同的情境里响起了声音。[rhr]
转头望去，南的身影就在那里。[rhp]
他非人的存在证明着，一切并非梦境。[rhp]

[:sausu:][sausu kao=1 ]
「这就是等着你的世界。[rhr]
_　比这个无机质方块美妙千百倍，属于我的宝石箱啊」[rhp]

[:himeko:]
「……宝石箱……」[rhp]

[off_all]

[::]
确实如此。那个地方配得上这个称呼。[rhr]
无论内外，连我自身，万物都在闪耀。[rhp]
只要闭上眼睛，那个世界的景色仍会鲜明浮现。[rhp]
……银河铁道。公主。[rhr]
虽然如同幻梦，却没有半分虚假。[rhp]
倘若某天我死去，我就会成为那个孩子―――……[rhp]

[:himeko:]
「………………」[rhp]

[:sausu:][p_s_22][sausu kao=3 as=on ]
「……[player2]，你从刚才就有点不对劲。[rhr]
_　总觉得你闷闷不乐，是我想多了吧」[rhp]
[:sausu:]
「…………莫非，玩得不开心？」[rhp]

[:himeko:]
「不是那样的……在我死去之前，[rhr]
_　那孩子会代替我留存在那个地方对吧」[rhp]
[:himeko:]
「那如果我去了那边，就会变成那个孩子对吗？」[rhp]

[:sausu:][p_s_31][sausu kao=5 ]
「没错。她将与合你为一体，把一切都留给你」[rhp]
[:sausu:]
「你将继承她所培育的『公主』地位，[rhr]
_　终于能成为憧憬中的自己」[rhp]

[:himeko:]
「……………………」[rhp]
[font size=13]
「………………好讨厌」[rhp]
[resetfont]

[:sausu:][p_s_13][sausu kao=4 ]
「嗯？」[rhp]

[:himeko:]
「！―――唔、没什么」[rhp]

[:sausu:][sausu kao=7 ]
「这样啊……？……也罢」[rhp]
[:sausu:]
「那么觉得如何？那边的世界。[rhr]
_　当此世的生命终结后，你就能乘坐银河铁道」[rhp]
[:sausu:]
「当然会来吧？我现在就开始期待了。[rhr]
_　你若能加入我们，该有多么愉快」[rhp]

[:himeko:]
「嗯………我会考虑」[rhp]

[:sausu:][sausu kao=8 ]
「…………。没有立刻答复呢」[rhp]

[:himeko:]
「不行吗？」[rhp]

[:sausu:][sausu kao=1 ]
「不，倒也不是那个意思」[rhp]
[:sausu:]
「[好吧。暂且就等待你的心意决定」[rhp] 
[:himeko:]
「嗯。谢谢」[rhp]

[:sausu:][sausu kao=13 ]
「临终时刻我会再问今天的答案。[rhr]
_　那时才能听到真实的心声吧」[rhp]
[:sausu:]
「那么[player2]。今天已经很晚了，明天见」[rhp]

[:himeko:]
「还能？明天也能见到吗？」[rhp]

[:sausu:][sausu kao=5 ]
「当然啦。我们可是室友。[rhr]
_　即使你看不见我的时候，我也一直在你身边」[rhp]
[:sausu:]
「我知道你总是闲着没事就往外看。[rhr]
_　如果愿意的话，要不要和我聊聊？」[rhp]

[:himeko:]
「……呵呵。对哦！原来是这么回事」[rhp]
[:himeko:]
「要找人说说话的话，我很乐意奉陪。[rhr]
_　虽然时间短暂，请多指教啦，南」[rhp]

[:sausu:][sausu kao=1 hh=on ]
「彼此彼此」[rhp]

[off_all]

;****************************************
#
[bg storage="sky_05.jpg" time=1500]
;****************************************

就这样开始了我和南奇妙的生活。[rhp]
就连自己也觉得，这是最近过得最开心的一段时光。[rhp]
南特别健谈，让我听了很多事情。[rhr]
虽然讲得最多的是博士的事，但还有其他很多很多。[rhp]
比如薰君这样，博士之后来到101号室的孩子们的故事。[rhr]
在我搬到那个房间之前，南经常给我讲他和他们的故事。[rhp]
总之听南说话，对于如今卧床不起的我来说，[rhr]
是非常新鲜、能让难得露出笑容的珍贵时刻。[rhp]

;****************************************
[bg storage="black.jpg" time=1000]
;****************************************

这样日子还能有几次呢。[rhp]
银河铁道还在等着我。[rhr]
是否要接受车票，由我决定。[rhp]
…………剩下的时间，已经不多。[rhp]

;****************************************
[set_b storage="sky_07.jpg"]
; 夜フィルター
[filter layer="1" brightness="60"]
;****************************************

2020年　3月[rhp]

[:himeko:]
「……………………」[rhp]

[::]
深呼吸变得困难。[rhp]
浅浅地吸气，长长地吸入，又长长地呼出。[rhp]
慵懒的时间持续着。[rhp]
视野似乎变得稍微狭窄了些……是错觉吗？[rhp]
不明白。虽不明白，却隐约有所感知。[rhp]
……啊……[rhp]

[:himeko:]
[font color=0x4682b4]
（………………我、要死了）[rhp]
[resetfont]

[:sausu:][p_s_04]
「[player2]」[rhp]

;****************************************
#
[bg storage="hsps_09n.jpg" time=1000]
; 夜フィルター
[filter layer="1" brightness="60"]
;****************************************

[:himeko:]
「……！」[rhp]

[:sausu:][sausu kao=1 ]
「早啊」[rhp]

[:himeko:]
「……南……」[rhp]

[:sausu:][p_s_34][sausu kao=3 ]
「看起来很痛苦呢……真可怜」[rhp]

[off_all]

[::]
他那夸张的悲伤表情，我也明白是他的真心。[rhr]
他明明已经这么成熟了，却偶尔会有比我更孩子气的地方。[rhp]
想到也要和南分别了，胸口就一阵绞痛。[rhr]
他对我而言，早已是能称之为朋友的关系。[rhp]
这几日的我多半时间都在沉睡，没能好好交谈。[rhr]
至少最后时刻，想聊聊往事之类的……[rhp]

[:sausu:][p_s_04][sausu kao=8 as=on ]
「……连说话都很痛苦呢。我明白的」[rhp]
[:sausu:]
「大家当时都是这样。薰也好，和近也好，……博士也是。[rhr]
_　正因如此才希望前往那条铁道啊」[rhp]
[:sausu:]
「…………那么，你最终的决定已经做好了吗」[rhp]

[off_all]

[::]
………………银河鉄道。[rhp]
与我交谈时，他经常热情洋溢地讲述那个世界有多么美好。[rhr]
他说只要去了那里，我就不必再孤身一人。[rhp]
不用只是这样呆在床铺上动弹不得，[rhr]
穿上漂亮的礼服，梳着美丽的头发，就像公主一样……[rhp]
……说是能像公主一样，获得新生。[rhp]

[:sausu:]
「这张脸很合适呢」[rhp]

;****************************************
#
[bg storage="sky_07.jpg" time=1000]
;****************************************

[:sausu:]
「走吧。前往银河铁道―――」[rhp]

;****************************************

#
[s_mask color=0xffffff time=3000]
[free_filter ]
[se storage="mag_08.ogg"]
; 背景表示
[bg storage="train_10.jpg" time=100]
; ウィンドゥの設定
[position layer="message0" frame="win.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[s_mask_off time=3000]

;****************************************

[::]
又来到了这个空间。[rhr]
但和上次不同的是，这次抵达的是屋顶上。[rhp]
不可思议的是，即使在并非室内的宇宙空间也能呼吸。[rhp]
歪着头看了看自己的身体。[rhr]
穿着和那时相同的礼服站在那里。[rhp]

[:sausu:][p_s_08][sausu kao=1 ]
「觉得这银河怎么样？非常棒吧。[rhr]
_　不觉得这景象简直就像那幅画一模一样吗」[rhp]
[:sausu:]
「来到这的孩子，我都会先带他们看这个地方。[rhr]
_　因为想告诉你们啊」[rhp]
[:sausu:]
「你们可以前往这个广阔世界的任何地方！」[rhp]

[:himeko:][puri_w kao=3 ]
「公主是？」[rhp]

[:sausu:][p_s_02][sausu kao=13 hh=on ]
「还在车厢里。你还没有真正死亡。[rhr]
_　若不是在临终前带到这里，我的魔法就无法生效」[rhp]
[:sausu:]
「但马上就要分别了。要不要去告个别？」[rhp]

[:himeko:][puri_w kao=6 ]
「………………、不用了。没关系」[rhp]

[:sausu:][p_s_20][sausu kao=0 as=on ]
「是吗？　嘛，和近当初也这样……」[rhp]

[:himeko:][puri_w kao=3 ]
「南。……我可没说过还想再来这里」[rhp]

[:sausu:][sausu kao=3 ]
「[player2]……难道你……」[rhp]

[:himeko:][puri_w kao=12 as=on ]
「………………」[rhp]

[:sausu:][p_s_11][sausu kao=0 ]
「开、开玩笑的吧？　你已经受过很多苦了。差不多够了吧」[rhp]
[:sausu:]
「你已经很努力了。有资格获得幸福。所以……」[rhp]

[:himeko:][puri_w kao=7 ]
「你是要让我，当公主吗」[rhp]

[:sausu:][sausu kao=13 as=on ]
「不是'要当'，而是'能当'啊。成为你期望中的自己！[rhr]
_　成为理想的自己，在这个世界自由生活就好了……！」[rhp]

[:himeko:][puri_w kao=3 as=on ]
「不当也可以」[rhp]

[:sausu:][p_s_19][sausu kao=4 ]
「……哈……？」[rhp]

[:himeko:][puri_w kao=8 as=on ]
「我呀，其实并不想当什么公主」[rhp]
[:himeko:]
「…………不如说想重来一次，[player2]以的身份重新开始」[rhp]

[:sausu:][sausu kao=3 as=on ]
「[player2]……！为什么！」[rhp]

[:himeko:][puri_w kao=2 ]
「因为很不甘心啊，这种事……[rhr]
_　被人把自己缺失的东西全部施舍过来」[rhp]
[:himeko:]
「不需要别人用过的人生。我什么都想自己争取。[rhr]
_　……这才是我渴求的自由」[rhp]

[:sausu:][p_s_26][sausu kao=1 ]
「还要我说多少次？这个世界才是自由的具象化。[rhr]
_　至今你未能达成的一切，在这里都能实现！」[rhp]

[:himeko:][puri_w kao=3 ]
「实现一切的，不是我的力量而是魔法力量吧？」[rhp]

[:sausu:][sausu kao=4 ]
「……！」[rhp]

[:himeko:][puri_w kao=13 as=on ]
「并不是不感谢南。反而真的非常开心。[rhr]
_　多亏有你做朋友，痛苦的治病生活也过得很快乐」[rhp]
[:himeko:]
「因为你讲述了大家后来的故事，[rhr]
_　我已经完全不害怕死亡了。真心觉得自己得到了救赎」[rhp]
[:himeko:]
「…………可我还是想努力试试」[rhp]

[:sausu:][p_s_21][sausu kao=2 as=on ]
「哈……？努力是指……」[rhp]

[:himeko:][puri_w kao=12 ]
「让我痛苦的并不是愿望没有实现。[rhr]
_　是后悔自己为梦想什么努力都没能做」[rhp]
[:himeko:]
「明明是自己的梦想，却连申请书都要别人代写，这样的自己太可悲了。[rhr]
_　明明不是米卡亲的错，却害你为我哭泣……真的很抱歉……」[rhp]

[:sausu:][sausu kao=8 as=on ]
「这不是没办法嘛。毕竟是生病了，」[rhp]

[:himeko:][puri_w kao=1 ]
「南。请送我回原来的世界。我要在那里好好迎接死亡。[rhr]
_　然后……如果真有转世这回事的话，我想赌一把」[rhp]
[:himeko:]
「因为这碌碌无为的人生，我一秒都不想耽搁了」[rhp]

[:sausu:][sausu kao=2 ]
「…………」[rhp]
[:sausu:]
「………………我拒绝」[rhp]

[:himeko:][puri_w kao=3 as=on ]
「唔……！？为什么？[rhr]
_　明明是你说的会让我自己选择！」[rhp]

[:sausu:][sausu kao=7 ]
「我没说过……」[rhp]

[:himeko:][puri_w kao=2 as=on ]
「南！你要毁约吗！？」[rhp]

[:sausu:][p_s_04][sausu kao=8 ]
「你才是吧，忘了曾经告诉过我的那个愿望吗」[rhp]

[:himeko:][puri_w kao=0 ason ]
「哎、愿望……？我什么时候对你……」[rhp]

[:sausu:][sausu kao=3 ]
「『愿这纸鹤能带我们到达彼岸』，[rhr]
_　你确实这样对我祈祷过吧」[rhp]
[:sausu:]
「你折的那只金色千纸鹤。……我可没忘记哦？」[rhp]

[:himeko:][puri_w kao=3 ]
「…………！」[rhp]

[:sausu:][p_s_31][sausu kao=2 ]
「实现愿望是千纸鹤的使命」[rhp]
[:sausu:]
「我的行为是正确的。[rhr]
_　将你们引导至这个世界，这绝对没有错……！」[rhp]

[:himeko:][puri_w kao=2 ]
「……为什么你会被逼到这种地步？」[rhp]

[:sausu:][sausu kao=0 ]
「！」[rhp]

[:himeko:][puri_w kao=8 as=on ]
「简直像是，被胁迫着不得不这样想一样……」[rhp]

[:sausu:][p_s_11][sausu kao=1 ]
「…………、怎么可能。这正是我发自真心的想法。[rhr]
_　无法实现愿望、不被期望实现愿望的我，根本没有存在价值」[rhp]

[:himeko:][puri_w kao=3 ]
「但是，」[rhp]

[:sausu:][p_s_26][sausu kao=12 ]
「够了，我明白了。请停止这个话题」[rhp]
[:sausu:]
「……既然说到这个份上，不如来打个赌吧。[rhr]
_　看你是否能够永远认为这个世界毫无必要」[rhp]

[:himeko:][puri_w kao=0 ]
「打赌？」[rhp]

[:sausu:][sausu kao=13 ]
「抛弃迄今为止『[player2]』和『公主』的记忆[rhr]
_　以空白的状态，在这个世界生活试试看吧」[rhp]
[:sausu:]
「忘记那些崇高漂亮话的你，[rhr]
_　一定会立刻喜欢上这场旅行」[rhp]
[:sausu:]
「我确信你在这个世界，能获得最美好的人生」[rhp]

[:himeko:][puri_w kao=3 ]
「南。即使这么做，我的心意也……」[rhp]

[:sausu:][p_s_16][sausu kao=5 ]
「我会准备两个恢复记忆的触发条件」[rhp]
[:sausu:]
「其一，是你回想起自己梦想的时候」[rhp]
[:sausu:]
「……是想当护士对吧？[rhr]
_　但现实中，甚至连那个立足点都未能抓住」[rhp]
[:sausu:]
「不过考试失败这样的场景，就算没有生病也是可能发生的现实。[rhr]
_　即便你再次追逐那个梦想，重蹈覆辙的可能性也很大」[rhp]

[:himeko:][puri_w kao=2 ]
「…………、……真会说讨厌的话呢。[rhr]
_　说不定是第一次对南感到厌烦了」[rhp]

[:sausu:][sausu kao=1 ]
「梦想的道路上本就伴随着挫折。[rhr]
_　等你重新想起自己梦想时，我会再问一次」[rhp]
[:sausu:]
「是否真的愿意舍弃这个心想事成的世界去转世投胎」[rhp]

[:himeko:][puri_w kao=0 ]
「…………、第二个是」[rhp]

[:sausu:][p_s_15][sausu kao=14 ]
「当你在这个世界感受到最大幸福的时刻」[rhp]

[:himeko:][puri_w kao=3 ]
「……！」[rhp]

[off_all]

;****************************************
[still storage="cg/d_d4_1.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/d_d4_1.png"]
;****************************************

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
[vostart]
;--------------------------------------------------------------------------------------------

[:sausu:]
「我会把你生前的记忆，以及应该继承的代演者记忆，全部交付给你」[rhp]
[:sausu:]
「倘若即便如此你仍坚持转世，我便再无异议。[rhr]
_　这次定会真心祝福你的启程」[rhp]
[:sausu:]
「否则就证明你的决心不过如此。[rhr]
_　就这样在这里生活也能获得幸福，结局皆大欢喜」[rhp]

[:himeko:]
「………………」[rhp]

[:sausu:]
「这个空间的支配者是我。没有我的许可你无法回去」[rhp]
[:sausu:]
「你会接受吧。这些条件」[rhp]

[:himeko:]
「…………明白了。我接受你的条件」[rhp]
[:himeko:]
「作为交换，我这边也有条件……不对，是请求」[rhp]

[:sausu:]
「请求？……好啊。说来听听」[rhp]

[:himeko:]
「我想今天之后，我就会死掉」[rhp]
[:himeko:]
「但是，希望谁都不要叫来。更准确地说……」[rhp]
[:himeko:]
「…………希望你能破坏那个应急装置」[rhp]

[off_all]

;****************************************
#
[bg storage="cg/d_d4_1b.png" width="1280" height="720" time=500]
[cg storage="cg/d_d4_1b.png"]
;****************************************

[:sausu:]
「…………啊」[rhp]

[:himeko:]
「矢部医生和米卡亲，今天两人都是夜班。[rhr]
_　其他工作人员都不在」[rhp]
[:himeko:]
「说是为了反正都要死掉的我勉强他们实在过意不去。[rhr]
_　而且看起来非常疲惫，希望他们能好好补觉什么的」[rhp]
[:himeko:]
「……求你了」[rhp]

[:sausu:]
「……，……说什么蠢话……」[rhp]

[:himeko:]
「是吗？我觉得这样就好。[rhr]
_　睡着可是很舒服的事呢」[rhp]

[:sausu:]
「…………你真的觉得这样就好吗」[rhp]

[:himeko:]
「你在等被拒绝吗？打赌的话，我可是会赢的哦」[rhp]

[:sausu:]
「被遗忘的和近，说不定会讨厌你哦」[rhp]

[:himeko:]
「没关系的。当博士忘记我们的时候，[rhr]
_　我们也没有讨厌博士啊」[rhp]
[:himeko:]
「可别小看我和和君的友情力量。[rhr]
_　就凭这点程度的事，和君怎么可能讨厌我嘛」[rhp]

;****************************************

#
[bg storage="cg/d_d4_1c.png" width="1280" height="720" time=500]
[cg storage="cg/d_d4_1c.png"]
;****************************************

[:sausu:]
「…………。……说得对。确实是那样的……」[rhp]
[:sausu:]
「……那就让我见识下吧。你的觉悟」[rhp]

[:himeko:]
「正合我意。我期盼的幸福，和你认为的幸福。[rhr]
_　到底哪边才是真正的幸福，就来好好确认吧」[rhp]

[:sausu:]
「……真是双好眼睛呢」[rhp]

[:himeko:]
「我是认真的。因为南是朋友，所以会全力以赴」[rhp]

[:sausu:]
「……、暂时见不到面真遗憾……」[rhp]
[:sausu:]
「…………再见。[player2]」[rhp]

[::]
我没有避开南那张带着悲伤的笑脸，回以微笑。[rhp]
他的邀请极具魅力，任谁听了都会觉得内容很棒吧。[rhr]
即便如此，我也不认为自己有错。[rhp]

;****************************************
[still_end frame="win.png" storage="white.jpg"]
;****************************************

由南的魔法诞生的光芒，正逐渐将我吞没。[rhr]
又要回到那张床铺之上了。[rhp]
最后的时刻肯定会比以往更加痛苦吧。[rhr]
那份疼痛与煎熬，至今仍未习惯。[rhp]
不过死亡本身一点都不可怕，甚至令人期待。[rhp]
只要想着前方有新的人生，就能跨越疼痛与恐惧。[rhp]

;****************************************
[set_b storage="black.jpg" time=2000]
;****************************************

――――――我就这样沉入了睡梦。[rhp]
无比安详的、仿佛再也不会醒来的深沉睡眠。[rhp]
临到头却发现意外地普通。[rhp]
太好了。安心了。[rhp]
毫无牵挂。[rhp]

;****************************************

[s_mask color=0x000000 time=1000]
; 背景表示
[bg storage="hsps_09n.jpg" time=100]
; 夜フィルター
[filter layer="1" brightness="60"]
; ウィンドゥの設定
[position layer="message0" frame="win2.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[s_mask_off time=1000]

;****************************************

; b1ではスチルありますがこっちでは使いません！

[se storage="door_09.ogg"]

[:takeru:]
[font size=28]
「星名小姐！！」[rhp]
[resetfont]

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
;タケル
[voconfig sebuf=1 name=take vostorage="take/full/{number}.ogg" number=58]
;ミカちん
[voconfig sebuf=1 name=tiaki vostorage="mika/full/{number}.ogg" number=169]

[vostart]
;--------------------------------------------------------------------------------------------

[:takeru:][take kao=2 as=on ]
「…………！」[rhp]

[off_all]

[:tiaki:][tiaki kao=3 ]
「………………！」[rhp]

[off_all]

[chara_part name="take" body=base kao=0 as=on hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=3 as=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:]
「老师……」[rhp]

[:takeru:][take kao=2 as=on ]
「……大美贺、小姐……？」[rhp]

[:tiaki:][tiaki kao=8 ]
「……夜君说……要陪在、你身边……」[rhp]
[:tiaki:]
「然后就……！」[rhp]

[:takeru:][take kao=4 ]
「………………星名小姐呢」[rhp]

[off_all]

[:tiaki:][tiaki kao=3 as=on ]
「……呼、……呜、……」[rhp]

[off_all]

[:takeru:][take kao=6 as=on ]
「………………为什么」[rhp]
[:takeru:]
「警报……？[rhr]
_　侧边监测器的紧急警报，为什么没有启动？」[rhp]

[off_all]

[:tiaki:][tiaki kao=7 as=on ]
「不知道……」[rhp]

[:takeru:]
「护、护士呼叫按过吗……？」[rhp]

[:tiaki:][tiaki kao=8 ]
「……没、没有按过」[rhp]

[off_all]

[:takeru:][take kao=2 as=on ]
「那！为什么……！」[rhp]
[:takeru:]
「……为什么星名小姐会去世……？」[rhp]


;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************

#
[s_mask color=0xffffff time=2000]
[off_all]
; 背景表示
[bg storage="train_01.jpg" time=100]
; 全部のフィルターを打ち消す
[free_filter ]
; ウィンドゥの設定
[position layer="message0" frame="win.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[s_mask_off time=3000]

;****************************************

――――――胸口的疼痛让我醒了过来。[rhp]
感觉自己做了个漫长而珍贵的梦。[rhp]
是因为那是梦吗？如今已然回忆不起。[rhp]
混沌的思绪中，唯独残留着莫名的失落感。[rhp]

[:princess:][puri_w kao=8 ]
「…………咦」[rhp]

[off_all]

[:princess:][puri_w kao=0 ]
[font color=0x4682b4]
（电车……？我，难道是睡着了吗。[rhr]
_　除此之外一个人也没有，这到底是怎么回事……）[rhp]
[resetfont]

[:princess:][puri_w kao=4 as=on ]
「…………啊」[rhp]

[off_all]

;****************************************
#
[bg storage="sky_11.jpg" time=500]
;****************************************

[:princess:]
「什……！！？这、这是浮在空中的……」[rhp]

;****************************************
#
[bg storage="sky_11.jpg" time=500]
;****************************************

[:unknown:][s_playse storage="drop/full/1.ogg" buf=1] 
「早上好！」[rhp]

[fbgm]

[::]
身后传来声音，我下意识转身。[rhp]
那里站着一名穿着类似制服的男子―――[rhp]


; ソラルートへ回帰
[jump storage="ev_d_drop3.ks" target="*start2" cond="f.root_s == 1"]

; ドロップルートへ回帰
[jump storage="ev_d_drop2.ks" target="*start2" cond="f.root_d == 1"]

