﻿
*start

[fbgm]
[mask color=0x000000 time=2000]
[cm]

[if exp="sf.name_change"]
[jump  target="*start2"]
[endif] 

[jump storage="name.ks"]

*start2

[cm]

[clearfix]
[start_keyconfig]
[loadjs storage="myscript.js"]

;初期設定---------------------------------------------------------------------

;メッセージウィンドウの設定
[position layer="message0" frame="win2.png" left=0 top=520 width=1280 height=200 page=fore visible=true]

; 文字表示領域
[position layer=message0 page=fore margint="65" marginl="420" marginr="60"]

;キャラ名表示領域
[ptext name="chara_name_area" layer="message0" color="0x000000" size=22 align=center bold=true x=420 y=550]

; 立ち絵の設定
[chara_config anim=false memory=true ptext="chara_name_area"]

[call storage="character.ks"]
[call storage="voice.ks"]

;--------------------------------------------------------------------------------

;--------------------------------------------------------------------------------------------
;▼フルボイスセット▼

;八雲博士
[voconfig sebuf=1 name=hiro vostorage="hiro/full/{number}.ogg" number=1]
;ダークネブラ
[voconfig sebuf=1 name=hakase vostorage="hakase/full/{number}.ogg" number=38]
;ヴルペクラ
[voconfig sebuf=1 name=peku vostorage="peku/full/{number}.ogg" number=37]
;ミカちん
[voconfig sebuf=1 name=tiaki vostorage="mika/full/{number}.ogg" number=102]

;--------------------------------------------------------------------------------------------

;****************************************
;タイトル表示

[bg storage="title/title_2a.png" time=100]
[bgm storage="bgm_07.ogg"]

[s_mask_off time=2000]

[bg storage="title/title_2b.png" time=2000]

[s_wait time=3000]

[bg storage="title/title_2a.png" time=2000]

[s_mask color="0x000000" time=3000]

[bg storage="hsps_01.jpg" time=100]
[layopt layer=message0 visible=true]
[showmenubutton]
[plugin name="menu_plugin"]
[s_mask_off time=2000]

;****************************************

儿童临终关怀医院「银河站」。[rhp]
他来到这片土地，已是相隔48天的事。[rhp]
隶属于郊区大学医院的麾下，从被称为「主楼」的那栋建筑[rhr]
稍微偏离一些的这个地方，对他而言是特别的场所。[rhp]

;****************************************
;スタッフステーション
[bg_rule storage="hsps_03.jpg" rule="002.png" time=1000]
;****************************************

穿过入口，稀稀落落看见几个孩子[rhr]
正要通过大厅时，有人向他搭话。[rhp]

[:tiaki:][tiaki kao=4 ]
「哎呀，理央君！」[rhp]

[off_all]

[:rio:][rio body=unif kao=1 ]
「米卡小姐……！好久不见」[rhp]

[off_all]

[::]
看见他――――神崎凛生的身影，[rhr]
这所临终关怀院的护士・大美贺千秋小跑着凑近。[rhp]
她用从未改变的无忧无虑的笑容迎接凛生。[rhp]

[chara_part name="rio" body=unif kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="rio" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:]
「好久不见！过得还好吗？」[rhp]

[:rio:]
「嗯。托您的福」[rhp]

[off_all]

[::]
神崎凛生，原本是在主楼儿科就诊的患者。[rhp]
由于前往医院途中的临终关怀院里，同龄孩子很多的缘故，[rhr]
至今仍清晰记得他总在诊疗结束后过来玩耍的身影。[rhp]

[chara_part name="rio" body=unif kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="rio" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:]
「放学顺路来的？理央君的高中离这里不是很远吗」[rhp]

[:rio:]
「啊，是的。今天是……那个」[rhp]
[:rio:]
「…………[player2]的」[rhp]

[:tiaki:][tiaki kao=4 as=on ]
「……！啊……」[rhp]

[:rio:][rio body=unif kao=3 ]
「因为今天是第49天。原本也想向家属们问候的……[rhr]
_　看到入殓结束后，就让我独自一人来扫墓了」[rhp]
[:rio:]
「不知道该对两位父母说什么才好……」[rhp]

[:tiaki:][tiaki kao=1 ]
「……没关系的，慢慢来。[rhr]
_　你和家人们都需要时间好好面对呢」[rhp]

[:rio:][rio body=unif kao=1 ]
「……[player2]的坟墓非常热闹。[rhr]
_　摆放着她喜欢的点心和毛绒玩具之类的东西」[rhp]

[:tiaki:][p_mk_13 ][tiaki kao=14 ]
「呵呵，果然很受欢迎呢。她一定很开心吧」[rhp]

[:rio:][rio body=unif kao=13 ]
「能这样就太好了……。……啊！对了」[rhp]
[:rio:]
「[player2]给烤了曲奇饼干，但做得有点多了。[rhr]
_　不介意的话请大家一起尝尝吧」[rhp]

[:tiaki:]
「可以吗？我最喜欢理央君的饼干啦，好开心」[rhp]

[:rio:]
「嘿嘿……能让你高兴真是太好了」[rhp]

[:tiaki:][tiaki kao=13 ]
「理央君做菜真的很拿手呢。[rhr]
_　米卡亲要是跟理央君学的话说不定也能进步哦」[rhp]

[:rio:][rio body=unif kao=1 as=on hh=on ]
「没、没什么大不了的。只是个人兴趣而已」[rhp]
[:rio:][rio body=unif kao=3 ]
「话说回来真是不好意思。明明您这么忙还来打扰。[rhr]
_　坐巴士过来挺近的，想着机会难得就来打声招呼」[rhp]

[:tiaki:][tiaki kao=13 ]
「没事的，别在意！能久违地见到你我很开心」[rhp]

[:rio:][rio body=unif kao=1 ]
「老师是在问诊中吗？」[rhp]

[:tiaki:][p_mk_22 ][tiaki kao=1 ]
「不是，在小憩。最近发生了不少事呢」[rhp]

[:rio:][rio body=unif kao=0 ]
「不少事……？」[rhp]

[:tiaki:][tiaki kao=3 as=on ]
「刚才还……应该说一直到昨天都挺忙的。[rhr]
_　老师最近一直在值班。趁现在清静的时候补个觉」[rhp]

[:rio:][rio body=unif kao=3 as=on ]
「原来是这样啊。[rhr]
_　抱歉，我不知道您正忙……」[rhp]

[:tiaki:][tiaki kao=1 ]
「没关系没关系。那我这就去叫醒老师！」[rhp]

[off_all]

[:tiaki:][tiaki kao=13 ]
「随便坐坐！我马上回来」[rhp]

[off_all]

[:rio:][rio body=unif kao=1 ]
「好的。那我就稍等……」[rhp]

[off_all]

;****************************************
[set_b storage="hsps_03.jpg" ]
;****************************************

[::]
约五分钟后，由远及近响起两重脚步声。[rhp]
察觉动静的凛生连忙端正坐姿，略显紧张地望向声源处。[rhp]

[:rio:][rio body=unif kao=1 ]
「矢部老师！久疏问候」[rhp]

[off_all]

[:takeru:][take kao=1 ]
「神崎君。好久不见」[rhp]

[::]
眼前这位正是统筹临终关怀院的医师矢部尊。[rhr]
虽年纪尚轻却医术精湛，在主楼众医师中也备受瞩目。[rhp]
然而……其固执严谨的作风令不少人敬而远之，[rhr]
在这所以主楼任职为荣的大型医院里，这恰是他被分配至此的缘由。[rhp]

[off_all]

[chara_part name="take" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="rio" body=unif kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="rio" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:takeru:]
「抱歉，让你久等了吧」[rhp]

[:rio:]
「我才该为占用您繁忙时间致歉。不会耽搁太久」[rhp]

[:takeru:]
「这样最好。高中生的本分是学习。[rhr]
_　我学生时代也是从早到晚翻参考书的」[rhp]

[:rio:]
「很有矢部老师的风格呢……我会向您学习」[rhp]

[:takeru:][take kao=0 ]
「…………」[rhp]

[:rio:][rio body=unif kao=0 ]
「老师？」[rhp]

[:takeru:][take kao=3 ]
「……不……」[rhp]
[:takeru:][take kao=3 ]
「…………这样啊。今天是星名小姐的四十九日祭呢」[rhp]

[:rio:][rio body=unif kao=3 as=on ]
「……是的。我是在返程途中顺道来的」[rhp]

[:takeru:]
「谢谢你。……我本也该去那边的[rhr]
_　但实在无法从那种状态的他身边离开……」[rhp]

[:rio:][rio body=unif kao=0 ]
「那种状态的……他？」[rhp]

[:takeru:][p_tk_34][take kao=2 as=on ]
「！啊……不是」[rhp]

[off_all]

[:tiaki:][tiaki kao=3 ]
「告诉他也无妨吧。[rhr]
_　毕竟是朋友，过后可能也会从本人那里听说」[rhp]

[off_all]

[:takeru:][take kao=3 ]
「说、得也是……既然神崎君的话应该没关系」[rhp]

[off_all]

[chara_part name="take" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="rio" body=unif kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="rio" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:takeru:]
「其实直到昨天，落合君都住在这里」[rhp]

[:rio:][rio body=unif kao=4 as=on ]
「诶……！宙君？」[rhp]

[:takeru:][take kao=0 ]
「贫血。几天前昏倒了，特别安排在这里的病房静养。[rhr]
_　要送去主楼那边稍微……那个……有些困难」[rhp]

[:rio:][rio body=unif kao=0 as=on ]
「困难……？」[rhp]

[:takeru:][take kao=12 ]
「不过身体方面倒不必太担心。[rhr]
_　今早醒来了，在你来之前不久刚回去」[rhp]

[:rio:][rio body=unif kao=3 ]
「这样……啊。……要是早点来就好了。[rhr]
_　因为那个贫血症状，肯定[player2]是因为那孩子的事吧」[rhp]
[:rio:]
「我和宙君有LINE联系。[rhr]
_　……早就听说他再也不去临终关怀院了」[rhp]
[:rio:]
「[player2]关于那孩子的事……我到底该对他说[rhr]
_　什么才好……所以一直，没能说出口……」[rhp]

[off_all]

[:tiaki:][p_mk_17][tiaki kao=3 ]
「没办法呀……因为是朋友。更何况呢」[rhp]

[off_all]

[:rio:][rio body=unif kao=3 ]
「……不过……」[rhp]

[off_all]

[chara_part name="take" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="rio" body=unif kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="rio" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:takeru:]
「……暂时最好不要见他。[rhr]
_　加上考试的压力，他精神上似乎已经相当吃不消了」[rhp]

[:rio:]
「我会照做的……虽然很久没见很想见他，但也没办法」[rhp]
[:rio:]
「……而且我也，[player2]的死至今还无法接受。[rhr]
_　本想着扫墓能让心情平复些……但完全没这回事」[rhp]
[:rio:]
「见了面大概也不知道该说什么好。[rhr]
_　所以……不见面肯定是正确的。就算是朋友」[rhp]

[:takeru:][take kao=3 ]
「神崎君……」[rhp]

[:rio:][rio body=unif kao=1 ]
「……要是能像从前那样轻松聊天就好了。如果笑着怀念过往的话，[rhr]
_　那样[player2]也会开心的吧」[rhp]
[:rio:]
「不能永远沉浸在悲伤里。[rhr]
_　我们也得向前看……[player2]就是这样的人啊」[rhp]
[:rio:][rio body=unif kao=3 ]
「…………我这样很薄情吧」[rhp]

[:takeru:][take kao=5 ]
「没这回事。是很成熟的想法」[rhp]

[off_take]

[chara_part name="tiaki" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="208" top="0" wait="true" time=150]

[:tiaki:][tiaki kao=13 ]
「真坚强呢，理央君」[rhp]

[:rio:][rio body=unif kao=1 ]
「才没有。像我这种人，完全算不上……」[rhp]
[:rio:][rio body=unif kao=3 as=on ]
「……啊，抱歉。把气氛搞得这么沉重」[rhp]

[:tiaki:][tiaki kao=1 ]
「不用勉强自己哦，理央君。[rhr]
_　悲伤的时候，就该哭到泪水流干才好」[rhp]

[:rio:][rio body=unif kao=1 ]
「……、好的。谢谢您……」[rhp]

[off_tiaki]

[chara_part name="take" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="true" time=150]

[:takeru:]
「……希望你将来能让他听到刚才你说的那些话」[rhp]

[:rio:][rio body=unif kao=0 ]
「让宙君听吗？」[rhp]

[:takeru:][take kao=3 ]
「他很孤独。正因如此，才需要能共享伤痕的同伴。[rhr]
_　……我对死亡太过麻木，无法承担这个职责」[rhp]

[:rio:][rio body=unif kao=0 ]
「…………老师……」[rhp]
[:rio:][rio body=unif kao=1 ]
「……我明白了。作为宙君的朋友，我会履行这个职责」[rhp]

[:takeru:][take kao=1 ]
「嗯。交给你了」[rhp]

[off_all]

[::]
凛生原本并不是这样有责任感的孩子。[rhr]
他是个性格怯懦、畏缩不前、被父母压力压垮的少年。[rhp]
能让他成长到敢于说出这种话的原因，[rhr]
果然还是……[player2]交流的成果吧。[rhp]
不仅是我，老师和米卡小姐也都这么认为。[rhr]
这几年他们注视凛生的眼神，已明显有别于他孩童时期。[rhp]
如今造访此处的凛生早已不是孩子，而是独当一面的大人。[rhp]
凛生自己也明白这点吧。[rhr]
从他的举止中，已完全感受不到从前那副怯弱的模样。[rhp]

[chara_part name="rio" body=unif kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="rio" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:rio:]
「那我差不多该告辞了」[rhp]

[:tiaki:][p_mk_19]
「哎呀，真的吗？再多坐会儿也没关系的」[rhp]

[:rio:][rio body=unif kao=1 ]
「打扰二位工作就不好了，[rhr]
_　我只是过来看望一下两位」[rhp]

[:tiaki:][tiaki kao=1 ]
「这样啊……明白了。随时欢迎再来玩哦」[rhp]
[:tiaki:][p_mk_17][tiaki kao=3 ]
「真的会很寂寞呢。这里要是拆了的话，[rhr]
_　像这样悠闲聊天的机会也会变少……」[rhp]

[:rio:][rio body=unif kao=4 as=on ]
「咦……拆掉？」[rhp]

[off_all]

[:takeru:][take kao=12 ]
「这所临终关怀院，四月就要和主楼的小儿科病房合并了。[rhr]
_　之后这里预定要改建成培训中心」[rhp]

[off_all]

[chara_part name="rio" body=unif kao=3 as=on ss=off hh=off hr=on ]
[chara_show name="rio" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:rio:][rio body=unif kao=3 as=on ]
「完、完全不知道……居然……」[rhp]

[:tiaki:][tiaki kao=3 ]
「这也是没办法的事。这短短几年医疗技术突飞猛进，[rhr]
_　选择积极治疗而非舒缓疗护的家属越来越多了」[rhp]
[:tiaki:]
「这固然是好事，[rhr]
_　可如果没有使用者，临终关怀院就维持不下去了」[rhp]

[:rio:]
「…………………………」[rhp]

[off_tiaki]

[chara_part name="take" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:takeru:]
「别这么沮丧。[rhr]
_　不过是换个场地，该做的事不会改变」[rhp]

[:rio:]
「……好的……」[rhp]

[:takeru:][take kao=12 ]
「那我也该告辞了。明天会议的资料还没整理完」[rhp]

[:rio:][rio body=unif kao=0 as=on ]
「啊……对、对不起。拉着您说了这么久」[rhp]

[:takeru:][take kao=1 ]
「不，没关系。……今天谢谢你啊神崎君。[rhr]
_　能见到久违的面孔我很开心」[rhp]

[off_rio]

[chara_part name="tiaki" body=base kao=5 as=on ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="208" top="0" wait="true" time=150]

[:tiaki:]
「搬过去后一定要来玩啊。约定好了？[rhr]
_　米卡亲可不会输给主楼那些拽拽的护士哦！」[rhp]

[:takeru:][take kao=6 as=on ]
「是是……」[rhp]

[off_all]

[:rio:][rio body=unif kao=13 as=on ]
「哈哈……非常感谢……」[rhp]

[off_all]

[::]
告别之后，矢部老师和米卡小姐，[rhr]
再次消失在员工站中。[rhp]
自从宙住院以来，事务性工作似乎几乎没有任何进展。[rhr]
明明还有其他工作人员在，他们的责任感令人肃然起敬。[rhp]
……如今我仍对曾经小看那两人感到些许后悔。[rhp]

[:rio:][rio body=unif kao=3 ]
「……………………」[rhp]

[off_all]

[::]
而后，被独自留在原地的理央。[rhp]
直至方才还努力保持着坚强谈话的模样，[rhr]
但在两人离开后的此刻，露出了令人不忍直视的沮丧表情。[rhp]
仿佛只要一丝契机就会哭出来的他，[rhr]
从员工站到患者玄关，拖着沉重的脚步缓缓走着。[rhp]

;****************************************
[bg_rule storage="hsps_06e.jpg" rule="002.png" time=1000]
;****************************************

从员工站返回的途中，[rhr]
理央在某间病房前停下脚步。[rhp]

;****************************************
[bg storage="hsps_07e.jpg" time=500]
;****************************************

房号101。[rhr]
别名『特别静养室』。[rhp]
他凝望着现在无人入住的房间门扉。[rhp]
在那紧闭的门扉彼端看见了什么呢。[rhr]
翻涌的情感无法化为言语，唯有叹息轻声溢出。[rhp]

[:rio:]
「……………唔」[rhp]

;****************************************
#
[bg storage="hsps_06e.jpg" time=500]
;****************************************

[::]
理央终于像是崩溃般蹲坐下来，将脸埋进膝盖。[rhr]
细微的呜咽漏出，渐渐化作啜泣。[rhp]

[:rio:]
「……………、[player2]呜啊…………」[rhp]

[::]
这里是她晚年[player2]曾居住过的病房。[rhr]
而在她之前，是我的挚友生活过的地方。[rhp]

;****************************************
; スチル
[still storage="cg/b1_1.png" rule="003.png" width="1280" height="720" time=2000]
[cg storage="cg/b1_1.png"]
;****************************************

[::]
――――――我是南。[rhp]
实现愿望的希望之神。[rhp]
披覆彩虹的幸福之翼。[rhp]

[:sausu:]
[font color=0x4682b4]
（要是能带你也去那个世界就好了）[rhp]
（………………对不起啊）[rhp]
[resetfont]

[::]
据『他』所说，我似乎是个所谓的恶人。[rhp]
……这无所谓。[rhr]
我，并不在意自己的处境。[rhp]
只有一件事，希望你能明白。[rhp]
我的朋友，绝不是什么可怜的孩子。[rhr]
我绝对没有做错。[rhp]
…………那么，从头开始讲吧。[rhp]

;****************************************

;抜粋表示

[s_mask graphic="rule/title_2c.png" time=3000]
[layopt layer="message0" visible="false"]
[hidemenubutton]

[bg storage="title/title_2c.png" time=100]

[s_mask_off time=3000]

[bg storage="title/title_2d.png" time=3000]

[s_wait time=3000]

[bg storage="title/title_2c.png" time=3000]

[s_mask color="0xffffff" time=3000]


[fbgm]
[bg storage="white.jpg" time=100]
[layopt layer="message0" visible="true"]
[position layer="message0" frame="win2.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[showmenubutton]
[s_mask_off time=2000]
[bgm storage="bgm_34.ogg"]
;****************************************

6年前[rhp]

;****************************************
[set_w storage="hsps_09x.jpg"]
;****************************************


;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
[vostart]
;--------------------------------------------------------------------------------------------

[:tiaki:][tiaki kao=1 ]
「博士君，最近状态不错呢」[rhp]

[off_tiaki]

[:hirosi:][hiro kao=1 ]
「真的吗？」[rhp]

[off_hiro]

[chara_part name="hiro" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:]
「嗯。血压正常，气色也好多了。[rhr]
_　之前还满脸阴郁的样子，现在总算放心了」[rhp]
[:tiaki:]
「遇到什么好事了吗？」[rhp]

[:hirosi:][hiro kao=1 ]
「哈哈……说是好事……可能多亏了那些孩子们」[rhp]
[:hirosi:]
「那个，您说的是谁来着……」[rhp]

[:tiaki:][tiaki kao=1 ]
「[player2]酱来着」[rhp]

[:hirosi:][hiro kao=1 ]
「……！　对了。[player2]酱」[rhp]

[:tiaki:][tiaki kao=13 ]
「和近君和她搭档起来真是厉害呢，真的。[rhr]
_　因为和主楼是同间病房，所以特别合得来吗」[rhp]

[:hirosi:][hiro kao=1 as=on ]
「完全不像临终关怀院的人呢，那孩子真有活力」[rhp]

[:tiaki:][tiaki kao=1 ]
「是啊！因为总在到处跑来跑去，反倒把我们累得够呛」[rhp]
[:tiaki:]
「请好好照顾他哦，哥哥」[rhp]

[:hirosi:][hiro kao=1 ]
「好的」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:tiaki:][p_mk_04][tiaki kao=1 ]
「说起来浩君，老师的课题进展到哪一步了？」[rhp]

[:hirosi:][p_hr_22][hiro kao=1 ]
「那个……虽然进度很慢，但已经快要完成了」[rhp]
[:hirosi:]
「折纸其实挺有意思的。[rhr]
_　听着电视广播也能折」[rhp]

[:tiaki:][tiaki kao=1 ]
「那就好！要是带着被迫做事的感觉就糟了呢」[rhp]
[:tiaki:]
「本来觉得千纸鹤根本不可能折完，[rhr]
_　但认真又努力的浩君说不定转眼就能完成」[rhp]

[:hirosi:][hiro kao=1 hh=on ]
「呵呵。其实不是我一个人折的」[rhp]
[:tiaki:]
「其他病房的孩子们知道我挑战千纸鹤后。[rhr]
_　从那之后大家时常会帮忙，把折好的纸鹤送给我」[rhp]

[:tiaki:][p_hr_15][tiaki kao=4 ]
「哎呀！那该不会是……」[rhp]

[:hirosi:][hiro kao=11 ]
「被她发现了。……呃，好像是，…………」[rhp]

[:tiaki:][p_mk_27][tiaki kao=13 ]
「[player2]酱。她确实会喜欢这种事呢」[rhp]

[:hirosi:][p_hr_33][hiro kao=3 ]
「对不起。虽然是特意为我准备的任务……这样不行吗？」[rhp]

[:tiaki:][tiaki kao=1 ]
「唔。对你来说折纸似乎本身就带着目的性，[rhr]
_　千纸鹤本身不必成为你一个人的作品呀」[rhp]
[:tiaki:][tiaki kao=1 ][p_mk_08]
「不是很美妙吗？　这所临终关怀院全员心愿凝聚的千纸鹤。[rhr]
_　让我也放一只承载自己心愿的纸鹤进去吧」[rhp]

[:hirosi:][p_hr_15][hiro kao=1 ]
「当然好！　米卡小姐要许什么愿呢？」[rhp]

[:tiaki:][p_mk_31][tiaki kao=13 ]
「那还用说！！　当然是嫁入豪门啦！！」[rhp]
[:tiaki:]
「同期的姑娘们全——都嫁人了！[rhr]
_　我也到这个年纪了，再不着急可不行」[rhp]
[:tiaki:]
「但根本遇不到合适的人嘛～～～～～～！！」[rhp]

[:hirosi:][p_hr_22][hiro kao=4 ]
「那个……啊、对了。比如矢部老师什么的」[rhp]

[:tiaki:][tiaki kao=13 hh=on ]
「诶？ 啊哈哈～！不行不行！老师绝对不行～。[rhr]
_　性格再好也架不住那个性子―――」[rhp]

[off_all]

[:takeru:][take kao=1 ]
「那个性子，是指？」[rhp]

[off_all]

[chara_part name="hiro" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=5 as=on ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:]
「！！！！！」[rhp]

[:hirosi:][hiro kao=1 ]
「啊…………」[rhp]

[off_all]

[chara_part name="take" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=13 as=on ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:takeru:]
「我知道自己性格不讨喜。[rhr]
_　不过呢，我也有选择的权利哦。大美贺小姐」[rhp]

[:tiaki:][p_mk_22][tiaki kao=1 as=on ]
「说、说得是呢～。[rhr]
_　我和老师太不般配啦！毕竟老师长得帅嘛」[rhp]
[:tiaki:]
「长得帅，嘛」[rhp]

[:takeru:][take kao=7 ]
「为什么要重复两遍……够了」[rhp]

[off_all]

[chara_part name="take" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hiro" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:takeru:]
「你好啊八云君。[rhr]
_　刚才太吵闹真是抱歉……身体感觉如何？」[rhp]

[:hirosi:][p_hr_32][hiro kao=1 ]
「请不必在意。今天心情倒是相当不错」[rhp]

[:takeru:][p_tk_08][take kao=1 ]
「那就好。……纸鹤这边看来也挺顺利的。[rhr]
_　刚才在隔壁看到其他孩子也在折，那是你委托的吗？」[rhp]

[:hirosi:][hiro kao=1 hh=on ]
「不，是大家主动说要折的，我想着机会难得就」[rhp]
[:hirosi:]
「我记得名字是，呃——」[rhp]

[:takeru:][take kao=13 ]
「星名[player2]小姐吧」[rhp]

[:hirosi:][hiro kao=1 ]
「啊，……是、是的。[player2]ちゃんに」[rhp]

[:takeru:][take kao=11 ]
「这样啊。毕竟她喜欢跟随别人嘛」[rhp]

[:hirosi:][p_hr_02][hiro kao=5 ]
「呵呵……！确实大家都干劲十足呢。[rhr]
_　我说可以把心愿寄托在纸鹤上折，所以她们才这么投入吧」[rhp]

[off_all]

[:tiaki:][p_mk_04][tiaki kao=1 ]
「我也要折一只哦。老师要一起吗？」[rhp]

[off_all]

[:takeru:][p_tk_19][take kao=8 ]
「不，我就……」[rhp]

[off_all]

[:hirosi:][hiro kao=1 ]
「我也拜托您了。如果能和住在这里的所有人一起完成就太棒了」[rhp]

[off_all]

[:takeru:][take kao=3 ]
「不……我和大美贺小姐都算不上这里的住客……」[rhp]

[off_all]

[chara_part name="tiaki" body=base kao=3 as=off ss=off hh=on hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hiro" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:2nin:]
「老师！」[rhr]
「老师……」[rhp]

[off_all]

[:takeru:][take kao=8 ]
「………………知道了！就折一只」[rhp]

[off_all]

[:hirosi:][p_hr_07][hiro kao=1 hh=on ]
「谢谢您！」[rhp]

[off_all]

[chara_part name="take" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:]
「老师要许什么愿呢？」[rhp]

[:takeru:][p_tk_19][take kao=6 ]
「希望能避开被大美贺小姐这样的女性抓住的命运吧」[rhp]

[:tiaki:][p_mk_09][tiaki kao=13 ]
「咦～～～～！这样啊。那我就决定许愿[rhr]
_　希望周围别再出现像老师这样的老古板了」[rhp]

[:takeru:][take kao=6 ]
「好啦好啦。随便你」[rhp]

[off_all]

[:takeru:][take kao=1 ]
「那么……我接下来还要查房就先走了。千纸鹤明天再叠吧」[rhp]

[off_all]

[:hirosi:][hiro kao=1 hh=on ]
「好的！我等您哦」[rhp]

[off_all]

[chara_part name="take" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:takeru:][p_tk_02]
「来，该走了大美贺小姐」[rhp]

[:tiaki:][p_mk_02][tiaki kao=8 as=on ]
「知道啦知道啦，医生您可真性急呢」[rhp]

[:takeru:][take kao=6 ]
「是你太优哉游哉了……」[rhp]

[off_all]

[:hirosi:][p_hr_31][hiro kao=1 ]
「谢谢您。明天也请多关照」[rhp]

[off_all]

[:takeru:][take kao=1 ]
「嗯。多保重」[rhp]

[off_all]

;****************************************
;廊下
[se storage="door_08.ogg"]
[set_b storage="hsps_06.jpg" time=2000]
;****************************************

[chara_part name="take" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:]
「浩君，情况看来不错呢」[rhp]

[:takeru:][take kao=1 ]
「是的。身体状况稳定，病情恶化速度也减缓了许多」[rhp]
[:takeru:]
「是手工疗法的效果呢，还是活泼的星名小姐带来的影响呢……」[rhp]

[:tiaki:][tiaki kao=13 ]
「肯定是两者共同作用的结果」[rhp]
[:tiaki:]
「[player2]「星名小姐的明朗与活力，连我都感到惊讶，[rhr]
_　老师布置的叠千纸鹤作业确实产生了良好影响」[rhp]

[:takeru:][p_tk_25][take kao=3 ]
「……我什么都没能做」[rhp]
[:takeru:]
「虽说恶化速度减缓，但病情仍在稳步推进」[rhp]

[:tiaki:][tiaki kao=4 ]
「……！」[rhp]

[:takeru:][take kao=3 ]
「星名小姐的名字，我之前从未忘记过」[rhp]

[:tiaki:][tiaki kao=3 as=on ]
「……那是……」[rhp]

[:takeru:][p_tk_20][take kao=0 ]
「他的脑损伤很严重。[rhr]
_　就在我们说话时，时间也在一分一秒地流逝」[rhp]
[:takeru:]
「…………距离从那个孩子记忆里消失的日子，也不远了」[rhp]

[:tiaki:][tiaki kao=3 ]
「………………嗯」[rhp]

[:takeru:][take kao=1 ]
「不过也该庆幸只是记忆障碍。[rhr]
_　那个年纪就遭遇两次脑出血……」[rhr]
_　就算失去性命也不奇怪」[rhp]
[:takeru:]
「直到某天他忘记一切之前，我们会竭尽所能」[rhp]
[:takeru:][take kao=3 ]
「……哪怕求神拜佛也好，我准备尝试所有可能的方法」[rhp]

[:tiaki:][tiaki kao=0 ]
「老师……」[rhp]

[:takeru:][take kao=1 ]
「大美贺小姐在工作方面是很可靠的」[rhp]
[:takeru:]
「在工作方面」[rhp]

[:tiaki:][p_mk_15][tiaki kao=13 hh=on]
「呵呵！这是对刚才的报复吗？」[rhp]
[:tiaki:]
「彼此彼此。我也很依赖您呢，博士」[rhp]

[:takeru:][take kao=11 ]
「…………多谢」[rhp]

;****************************************
;ヒロシの病室
[set_b storage="hsps_09x.jpg"]
;人外の透明フィルター
;****************************************


[:hirosi:]
[font color=0x4682b4]
（…………今天开的药比往常少）[rhp]
[:hirosi:]
（是不是意味着已经没希望康复了……[rhr]
[:hirosi:]
_　既然如此，直接告诉我也没关系）[rhp]
[:hirosi:]
（……真羡慕那孩子的活力。那孩子叫……什么来着）[rhp]
[resetfont]

[off_all]

[:hirosi:][hiro kao=7 ]
「…………？　…………」[rhp]
[:hirosi:]
「………………………………啊、算了」[rhp]

[off_all]

[:hirosi:]
[font color=0x4682b4]
（没关系。虽然现在这样，每次见面时都能回想起来）[rhp]
[:hirosi:]
（我没事的。没事的，没事的……）[rhp]
[:hirosi:]
（…………、…………没事的……）[rhp]
[resetfont]

;--------------------------------------------------------------------------------------------
;▼再開▼
;ヴルペクラの名前が出るまでボイスがunknownに反応するように
[voconfig sebuf=1 name=unknown vostorage="peku/full/{number}.ogg" number=37]
[vostart]
;--------------------------------------------------------------------------------------------

[yurasu]

[:unknown:]
[font size=30]
「喂――――！！！！」[rhp]
[resetfont]

[:hirosi:][hiro kao=1 ]
「！」[rhp]

[off_all]

[:unknown:][peku2 ]
「喂喂喂！博士！」[rhp]
[:unknown:]
「浩是谁啊！？」[rhp]

[off_all]

[:hirosi:][hiro kao=1 ]
「啊、哈哈哈……就是我啦」[rhp]
[:hirosi:]
[font color=0x4682b4]
（今天也来了呢。比我还健忘的孩子……）[rhp]
[resetfont]

[:unknown:][peku2 ]
「博士就是博士吧？大家都这么叫的！[rhr]
_　浩是绰号吗？」[rhp]

[:hirosi:][hiro kao=1 ]
「浩是本名，博士是绰号」[rhp]

[:unknown:][peku2 ]
「？？？？」[rhp]

[:hirosi:][hiro kao=11 ]
「……嘛算了。你好啊，沃尔佩克拉」[rhp]

;--------------------------------------------------------------------------------------------
;ヴルペクラ再設定
[voconfig sebuf=1 name=peku vostorage="peku/full/{number}.ogg" number=42]
[vostart]
;--------------------------------------------------------------------------------------------

[:vulpecula:][peku2 ]
「你好呀——！」[rhp]

[:hirosi:][hiro kao=7 ]
「今天也是从主楼过来玩的吗？」[rhp]

[:vulpecula:][peku2  ]
「就～是！那边太无聊了，人家更喜欢有博士在的这边啦」[rhp]
[:vulpecula:]
「就算在那边待着，也根本没人愿意搭理我！[rhr]
_　博库我可是拼命地搭话了啊！」[rhp]

[:hirosi:][hiro kao=1 ]
「没办法啦。因为你是幽灵嘛」[rhp]
[:hirosi:]
「我也只能模模糊糊看到你的身影。[rhr]
_　所以，聊天对象就勉强和我凑合吧」[rhp]

[:vulpecula:][peku2  ]
「勉强？才没有呢？博库最喜欢和博士在一起了！」[rhp]

[:hirosi:][hiro kao=1 as=on hh=on ]
「啊、谢谢……」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:hirosi:]
[font color=0x4682b4]
（能看见幽灵这种事可开不得玩笑。[rhr]
_　我也快变得和她一样了吧……）[rhp]
[:hirosi:]
（…………嘛，死了的话说不定死了也好。[rhr]
_　看着她的样子，意外地还挺轻松）[rhp]
[resetfont]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:vulpecula:][peku2 ]
「啊！又在搞这个ー！」[rhp]

[off_all]

[:hirosi:][hiro kao=4 ]
「嗯？」[rhp]

[off_all]

[chara_part name="hiro" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="peku2" body=base kao=1 as=off ss=off hh=off hr=on mimi=off ]
[chara_show name="peku2" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:]
「真是的～博士你啊，又～在折纸了吗？」[rhp]

[:hirosi:][hiro kao=1 ]
「啊，是千纸鹤啊」[rhp]

[:vulpecula:][peku2 ]
「之前一直都是～～学习或看书呢。最近却总是搞这个呀」[rhp]

[:hirosi:][hiro kao=5 ]
「那两件事也同时在做的啦。[rhr]
_　千纸鹤是中间转换心情用的。不过还挺有趣哦」[rhp]

[:vulpecula:][peku2 ]
「真亏你不觉得腻呢。都是同样的东西吧？那个啦」[rhp]

[:hirosi:][hiro kao=1 ]
「马上就千只了。因为是最后冲刺，不知不觉就认真起来了」[rhp]

[:vulpecula:][peku2 ]
「达到千只的话，愿望就会实现对吧！」[rhp]

[:hirosi:][hiro kao=1 ]
「嗯，是的」[rhp]

[:vulpecula:][peku2  ]
「希望能实现呢！博士的愿望！」[rhp]
[:vulpecula:]
「博库我无法触碰物体，也不能一起制作。[rhr]
_　所以我的愿望就寄托在博士的一起啦」[rhp]

[:hirosi:][hiro kao=3 ]
「………………、是什么来着？」[rhp]

[:vulpecula:][peku2 ]
「真是的！又『健忘』？等病好了之后，[rhr]
_　要和我一起玩单板滑雪夜钓抬神轿的对吧～！？」[rhp]

[:hirosi:][hiro kao=1 as=on ]
「不不！那不可能。绝对不可能」[rhp]

[:vulpecula:][peku2  ]
「嘛虽然是假话」[rhp]

[:hirosi:][hiro kao=1 ]
「这样啊……」[rhp]

[:vulpecula:][peku2 ]
「博士。其实你记得许愿的事对吧」[rhp]


;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:hirosi:][hiro kao=4 ]
「！」[rhp]


;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:vulpecula:][peku2 ]
「『我从没告诉过博库』的事，你其实记得对吧～？[rhr]
_　所以故意装作忘记想要蒙混过关！」[rhp]
[:vulpecula:]
「这种谎言，在佩奇侦探面前可不管用。饶不了你！」[rhp]

[:hirosi:][hiro kao=12 ]
「要我饶恕什么啊……」[rhp]

[:vulpecula:][peku2 ]
「所以呢！今天一定要告诉我博士的愿望！」[rhp]

[:hirosi:][hiro kao=7 ]
「不行」[rhp]

[:vulpecula:][peku2 ]
「咣当！！连这么可爱的佩奇请求都……！？」[rhp]

[:hirosi:][hiro kao=1 ]
「只是团迷雾而已。不可爱哦」[rhp]

[:vulpecula:][peku2 ]
「明明很可爱！[rhr]
_　比刚才在路上看到的猫咪还可爱呢！看着吧？」[rhp]

[off_all]

[:vulpecula:][peku2 ]
「喵啊啊啊～！喵喵！喵啊啊啊！！」[rhp]

[off_all]

[chara_part name="hiro" body=base kao=1 as=on ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="peku2" body=base kao=1 as=off ss=off hh=off hr=on mimi=off ]
[chara_show name="peku2" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:][peku2 ]
「怎么样！？」[rhp]

[:hirosi:][hiro kao=8 ]
「不对，所以才会觉得模糊不清啊……」[rhp]

[:vulpecula:][peku2 ]
「咣！！」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:hirosi:]
[font color=0x4682b4]
（…………许愿、吗）[rhp]
[:hirosi:]
（我的愿望是……）[rhp]
[resetfont]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[yurasu]

[:girl:]
「博士―――――！！！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:hirosi:][hiro kao=4 ]
「！」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[:vulpecula:][peku2 ]
「哇哇！　有、有人来了！」[rhp]

[off_all]

;扉開ける
[se storage="door_07.ogg"]

[:girl:][hime2 kao=13 hh=on ]
「博士！　你好！」[rhp]

[:hirosi:][hiro kao=7 as=on ]
「诶……那个」[rhp]

[:himeko:][hime2 kao=1 ]
「[player2]的啦！　你好！」[rhp]
[:himeko:][hime2 kao=13 ]
「这边还记得吗？　那孩子是理央君，那边一张臭脸的是」[rhp]

[off_all]

[:kazutika:][kazu kao=0 ]
「都说了别这样。名字我还是能自己说――――」[rhp]

[:himeko:][hime2 kao=1 ]
「这孩子是和近。是和君！！」[rhp]

[:kazutika:][kazu kao=0 as=on ]
「～～～！　真是多管闲事烦死了……！」[rhp]

[off_all]

[:rio:][rio2 kao=8 ]
「打、打扰了……」[rhp]

[off_all]

[chara_part name="hiro" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="rio2" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="rio2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:hirosi:]
「理央君。你是来玩的呢」[rhp]

[:rio:][rio2 kao=4 as=on ]
「！！　啊那个，是、是的！[rhr]
_　这、你好。博……浩、浩先生」[rhp]

[off_all]

[chara_part name="hime2" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="rio2" body=base kao=3 as=on ss=off hh=off hr=on ]
[chara_show name="rio2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:himeko:]
「理央君真是的，博士就叫博士好啦！[rhr]
_　不用那么紧张，博士明明一点都不可怕」[rhp]

[:rio:][rio2 kao=12 as=on ]
「可、可是……毕竟是年长的人……」[rhp]

[off_all]

[:kazutika:][kazu kao=7 ]
「赶紧进入正题吧？　我想早点回去睡觉」[rhp]

[:himeko:][hime2 kao=4 ]
「知道啦。不如说和君你睡太多了！」[rhp]

[:kazutika:][kazu kao=6 ]
「睡觉的孩子长得快哟」[rhp]

[:himeko:][hime2 kao=12 ]
「马上就开始强词夺理了……」[rhp]

[off_all]

[:himeko:][hime2 kao=13 hh=on ]
「……那个啊博士！今天要给博士一个惊～～喜哦」[rhp]

[off_all]

她这样说着递过来的，是装满箱子的无数千纸鹤。[rhp]

[:hirosi:][hiro kao=4 as=on ]
「咦……！数量真惊人。送我这么多可以吗？」[rhp]

[off_all]

[:himeko:][hime2 kao=13 hh=on ]
「嗯！是大家一起折的。[rhr]
_　因为有很多愿望要实现才做了这么多啦！」[rhp]

[off_all]

[chara_part name="hime2" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hiro" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:himeko:]
「哼哼。而且呢」[rhp]

[:hirosi:][hiro kao=0 ]
「？」[rhp]

[:himeko:]
「病房里的漫画都看腻了，帮你折也不是不行哦」[rhp]

[:hirosi:][hiro kao=2 as=on ]
「……？？」[rhp]

[off_all]

[chara_part name="kazu" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="kazu" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="rio2" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="rio2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:kazutika:]
「喂！！这不是在学我说话吗！？」[rhp]

[:rio:][rio2 kao=13 ]
「噗……！可能确实有点像」[rhp]

[:kazutika:][kazu kao=6 ]
「才不像！理央这家伙真让人火大」[rhp]

[off_all]

[chara_part name="hime2" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hiro" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:himeko:]
「嘿嘿，怎么样博士？收到千纸鹤开心吗？」[rhp]

[:hirosi:][hiro kao=1 ]
「呵呵呵……！谢谢大家。托你们的福进度快了很多」[rhp]
[:hirosi:][hiro kao=1 ]
「离千只就差一点了。我也不能输啊」[rhp]

[:himeko:][hime2 kao=1 ]
「嗯！啊对了。[rhr]
_　现在能去博士房间继续折吗？」[rhp]

[:hirosi:][hiro kao=1 ]
「当然。边聊天边折会更开心呢」[rhp]

[:himeko:][hime2 kao=13 ]
「太好啦！那我先去房间拿彩纸——」[rhp]

[off_all]

[yurasu]

[:takeru:]
[font size=30 olor=0x696969]
『星名————！！？？』[rhp]
[resetfont]

[chara_part name="kazu" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="kazu" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="rio2" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="rio2" layer="1" width="437" height="720" left="421" top="0" wait="true" time=150]
[chara_part name="hime2" body=base kao=5 as=on ss=off hh=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="760" top="0" wait="true" time=150]

[:3nin:]
「！！！！！」[rhr]
「！！！！！」[rhp]

[:himeko:]
「啊——暴露了！其实接下来要去体检啦～」[rhp]

[off_all]

[:himeko:][hime2 kao=14 as=on ]
「那、那待会见了博士！我还会来的！」[rhp]

[off_all]

[:hirosi:][hiro kao=5 as=on ]
「嗯、嗯。尽量别给大家添麻烦哦……」[rhp]

[off_all]

; ピシャッとドア閉める
[se storage="door_10.ogg"]

;****************************************
#
[bg storage="hsps_06.jpg" method="fadeInRightBig" time=1000]
;****************************************

[chara_part name="kazu" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="kazu" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:himeko:][hime2 kao=13 ]
「快点儿快点儿ー！」[rhp]

[:kazutika:][kazu kao=4 ]
「喂、[player3]！　别这么粗暴地推啊，会摔倒的吧」[rhp]

[off_all]

[:takeru:][take kao=2 as=on ]
「你们这群家伙……！　总算找到你们了……！！」[rhp]

[off_all]

;****************************************
#
[bg storage="hsps_09x.jpg" method="fadeInRightBig" time=500]
;****************************************

[yurasu]

[:2nin:]
[font size=30 color=0x696969]
『呀―――――――！！！』[rhr]
『呀―――――――！！！』[rhp]
[resetfont]

[:rio:]
[font color=0x696969]
『对、对不起啦！』[rhp]
[resetfont]

[:vulpecula:][peku2 ]
「大家都好精神啊！　和庸医玩捉鬼游戏，看起来超级开心！」[rhp]

[:hirosi:][hiro kao=6 ]
「是矢部医生哦。太失礼了」[rhp]
[:hirosi:]
「……好了。在大家的自由活动时间开始前，我先继续干活吧」[rhp]

[:vulpecula:][peku2 ]
「快要完成了吗？」[rhp]

[:hirosi:][hiro kao=1 ]
「嗯。快了。再有个几天吧」[rhp]

[:vulpecula:][peku2 ]
「超级厉害！加油啊博士！」[rhp]

[:hirosi:][hiro kao=1 hh=on ]
「多谢」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

[:hirosi:]
[font color=0x4682b4]
（…………不过，稍微有点不安）[rhp]

;****************************************
#
[bg storage="black.jpg" time=1000]
;****************************************

[:hirosi:]
（这只鹤完成时，我的愿望真的能实现吗）[rhp]
[:hirosi:]
（……害怕去确认。[rhr]
_　但现在的我，除了仰仗这样的奇迹别无选择……）[rhp]
[resetfont]

;****************************************
[set_b storage="hsps_09x.jpg"]
;****************************************

[::]
――――――数日后[rhp]

;ドアを開ける
[se storage="door_07.ogg"]

[:takeru:][take kao=0 ]
「早啊八云君。抱歉我来晚了……」[rhp]
[:takeru:][take kao=4 ]
「…………啊！」[rhp]

[off_all]

[chara_part name="tiaki" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hiro" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:hirosi:]
「老师，早上好」[rhp]

[:tiaki:][p_mk_09][tiaki kao=1 ]
「真是的～老师您太慢了啦！」[rhp]

[off_all]

[chara_part name="hiro" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:takeru:]
「大美贺小姐。要先去的话至少说一声呀。[rhr]
_　我在员工站等了很久呢」[rhp]

[:tiaki:][tiaki kao=13 hh=on ]
「哎呀哎呀别这么说嘛。是有急事啊！」[rhp]

[:takeru:][p_tk_03][take kao=2 ]
「急事……？」[rhp]

[off_all]

[:tiaki:][p_mk_16][tiaki kao=14 hh=on ]
「锵——！请看这个！」[rhp]

[off_all]

[::]
说着，米卡小姐向矢部医生[rhr]
举起并展示了身后架子上摆放的某件物品。[rhp]

[chara_part name="take" body=base kao=4 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:takeru:][p_tk_08]
「！千纸鹤……已经完成了吗」[rhp]

[:tiaki:]
「早餐时被浩君拜托帮忙连接[rhr]
_　所以才赶时间的啦」[rhp]

[:takeru:][p_tk_14]
「急事原来是指这个……那就没办法了呢」[rhp]
[:takeru:]
「不过今后请好好提前告知哦」[rhp]

[:tiaki:][p_mk_02]
「我会注意的♡」[rhp]

[off_tiaki]

[chara_part name="hiro" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:takeru:][p_tk_15]
「不过，这样啊……终于完成了呢」[rhp]

[:hirosi:][p_hr_02][hiro kao=5 ]
「多亏大家帮忙才能这么快完成」[rhp]
[:hirosi:]
「如果只有我的话制作周期会拖得更久吧。[rhr]
_　有种集体创作的感觉真开心」[rhp]

[:takeru:][take kao=14 ]
「是吗。那太好了」[rhp]

[off_all]

[:tiaki:][tiaki kao=7 ]
「要装饰在哪里呢？窗边的话会被晒褪色吧」[rhp]

[off_all]

[:hirosi:][p_hr_18][hiro kao=1 ]
「这不止是我个人的作品，放在入口大厅之类的……」[rhp]
[:hirosi:]
「………………」[rhp]

[off_all]

[chara_part name="hiro" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:]
「浩君？」[rhp]

[:hirosi:][p_hr_22][hiro kao=12 ]
「……那、那个。也许这个要求很任性……[rhr]
_　如果可以的话，能装饰在我的枕边吗？」[rhp]

[:tiaki:][p_mk_19][tiaki kao=4 ]
「当然可以不过……」[rhp]

[off_tiaki]

[chara_part name="take" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:takeru:][p_tk_04]
「入口大厅没关系吗？你刚才不还提到那里」[rhp]

[:hirosi:][p_hr_20][hiro kao=1 ]
「那个……我，是不是得了这种病啊」[rhp]
[:hirosi:]
「大家和老师们帮助我的事，还有我自己努力的事，[rhr]
_　……以及向这些千纸鹤许愿的心意，我都不想忘记」[rhp]
[:hirosi:]
「只要每天看着，就不会忘记」[rhp]

[:takeru:][p_tk_14][take kao=11 ]
「…………这样啊。说得也是」[rhp]

[off_all]

[chara_part name="hiro" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=1 as=on ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:]
「那我也每天来这个房间祈祷吧！[rhr]
_　希望能被超级帅哥天才医师（外科）看上」[rhp]

[:hirosi:][p_hr_17][hiro kao=8 ]
「千纸鹤好像不是用来许这种愿望的……」[rhp]

[:tiaki:][tiaki kao=13 hh=on ]
「没关系！许愿就是要随心所欲啊！」[rhp]

[off_all]

[chara_part name="take" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:takeru:][p_tk_20]
「你这人真是……那我也来祈祷好了。[rhr]
_　希望大美贺小姐能结婚离职，让我能安心工作的日子早日到来」[rhp]

[:tiaki:][p_mk_27][tiaki kao=13 ]
「根本不用祈祷～～！米卡亲看着就很受欢迎，」[rhp]

[off_all]

[:takeru:][p_tk_01][take kao=1 ]
「那八云君。虽然迟了些，我们开始看诊吧」[rhp]

[off_all]

[:hirosi:][hiro kao=1 as=on ]
「请、请多指教」[rhp]

[off_all]

[:tiaki:][p_mk_09][tiaki kao=2 ]
「真是的！对女孩子不温柔的男人是不会受欢迎的！」[rhp]

[off_all]

;****************************************
;夜の病室
[set_n storage="hsps_09n.jpg"]
;****************************************

[chara_part name="hiro" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="peku2" body=base kao=1 as=off ss=off hh=off hr=on mimi=off ]
[chara_show name="peku2" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:][p_vl_36][peku2 ]
「博士——今天也辛苦啦」[rhp]

[:hirosi:][p_hr_15][hiro kao=1 ]
「晚上好，沃尔佩克拉。[rhr]
_　今天白天没来玩，发生什么事了吗？」[rhp]

[:vulpecula:][p_vl_16][peku2 ]
「嗯——因为爸爸妈妈来医院了嘛！我就跟踪他们。[rhr]
_　结果就迷路了！　回到这里可费了好大劲呢～」[rhp]

[:hirosi:][hiro kao=4 ]
「这样啊……希望没被谁看到身影。[rhr]
_　你既然是幽灵，那场景可够恐怖的」[rhp]

[:vulpecula:][peku2 ]
「这方面完全没问题！根本没人注意到我！[rhr]
_　不过嘛，这样反而有点寂寞呢～」[rhp]

[:hirosi:][hiro kao=1 as=on ]
「毕竟是个相当复杂的存在呢……」[rhp]

[:vulpecula:][p_vl_31][peku2 ]
「对了对了！听说爸爸妈妈要有新宝宝了！[rhr]
_　医生的阿姨说'一切正常真是太好了'呢」[rhp]

[:hirosi:][hiro kao=0 ]
「这样……啊……」[rhp]

[:vulpecula:][peku2 ]
「真好啊，新家人。博库也好想见见。[rhr]
_　不过会吓到人家所以不行吧」[rhp]

[:hirosi:][hiro kao=0 ]
「……，寂寞吗？」[rhp]

[:vulpecula:][peku2 ]
「哎？为什么这么问？」[rhp]

[:hirosi:][p_hr_17][hiro kao=4 ]
「为、为什么……这个」[rhp]

[:vulpecula:][p_vl_24][peku2 ]
「不如说超级开心！这不就意味着，[rhr]
_　博库要当姐姐了吗？」[rhp]
[:vulpecula:]
「啊，但可能有点遗憾呢……！毕竟这副模样[rhr]
_　就算见面也不会被当成姐姐吧……」[rhp]

[:hirosi:][hiro kao=8 as=on ]
「最、最好不要现形……」[rhp]

[:vulpecula:][peku2 ]
「知道啦～这方面我可是很成熟的！」[rhp]

[:hirosi:][hiro kao=3 ]
「沃尔佩克拉……」[rhp]
[:hirosi:]
「…………，对了」[rhp]

[:vulpecula:][p_vl_04][peku2 ]
「？在干嘛呢～？又在折纸？」[rhp]

[:hirosi:][p_hr_17][hiro kao=5 ]
「千纸鹤并不一定要折满一千只以上才行」[rhp]
[:hirosi:]
「『希望能让沃尔佩克拉叫我姐姐』……嗯」[rhp]

[:vulpecula:][p_vl_14][peku2 ]
「……！　你把我的份也许愿了吗！？」[rhp]

[:hirosi:][hiro kao=5 ]
「心思乱了就折不好了」[rhp]

[:vulpecula:][peku2 ]
「那个……啊、那——！　再、再来一个行吗？　不行吗？」[rhp]

[:hirosi:][hiro kao=1 ]
「呵呵呵，多少个都可以哦」[rhp]

[:vulpecula:][peku2 ]
「我想想啊！　『希望能变成小猫』这个不错！」[rhp]

[:hirosi:][hiro kao=4 ]
「诶……猫、猫吗？」[rhp]

[:vulpecula:][p_vl_32][peku2 ]
「还有还有，『希望能聊很多很多天！'[rhr]
_　另外啊，『希望博士能陪我玩好多好多次！'」[rhp]

[:hirosi:][p_hr_20][hiro kao=8 hh=on ]
「这个愿望其实已经算实现了……」[rhp]

[:vulpecula:][p_vl_16][peku2 ]
「最后还有！[rhr]
『希望博士的病能治好，可以一起散步'！」[rhp]

[:hirosi:][hiro kao=4 ]
「…………！」[rhp]

[:vulpecula:][peku2 ]
「这些够了吧。太贪心会挤占别人的份额呢」[rhp]

[:hirosi:][p_hr_31][hiro kao=1 ]
「哈哈哈。这不是消耗品所以没关系啦」[rhp]
[:hirosi:]
「…………谢谢你沃尔佩克拉。真希望能实现呢」[rhp]

[:vulpecula:][peku2 ]
「绝对会的！　全——部，一定！」[rhp]

[:hirosi:][hiro kao=1 hh=on ]
「…………嗯」[rhp]
[:hirosi:]
「……好啦。今天就把这只鹤也添上去吧」[rhp]

[:vulpecula:][p_vl_08]
「连起来看真的好漂亮～。全都是纸鹤吗？」[rhp]

[:hirosi:]
「对呀。想到每只都承载着心愿就觉得厉害呢」[rhp]

[:vulpecula:]
「真的！　神明大人也会很为难吧。[rhr]
_　只有这个愿望必须实现」[rhp]
[:vulpecula:]
「啊啊！要是佩奇是猫咪的话就能帮忙了呢」[rhp]

[:hirosi:][p_hr_01][hiro kao=1 ]
「呵呵，确实。或许连猫的手都想借呢」[rhp]

[off_all]

[fbgm]

;立ち絵がモヤモヤに猫耳だけ浮いてる感じになる
[:vulpecula:][peku2 mimi=on ]
「就是这个意思！不过比起猫咪还是保持幽灵状态更方便吧？」[rhp]

[off_all]

[:hirosi:][hiro kao=4 ]
「……………………」[rhp]

[off_all]

[bgm storage="bgm_35.ogg"]

[chara_part name="hiro" body=base kao=4 as=on ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="peku2" body=base kao=1 as=off ss=off hh=off hr=on mimi=on ]
[chara_show name="peku2" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:][peku2 mimi=on ]
「睡着了吗？博士！」[rhp]

[:hirosi:][hiro kao=4 as=on ]
「沃、沃尔佩克拉……！？那个……！耳、耳朵！」[rhp]

[:vulpecula:][p_vl_13][peku2 mimi=on ]
「诶？什么什么？耳朵？」[rhp]

[off_all]

[:hirosi:][hiro kao=7 ]
「这、这是什么……幻觉？不对，可是……」[rhp]

[off_all]

;--------------------------------------------------------------------------------------------
;▼再開▼
;サウス（最初？？？）
[voconfig sebuf=1 name=unknown vostorage="sausu/full/{number}.ogg" number=109]
[vostart]
;--------------------------------------------------------------------------------------------

[:unknown:]
「根据他的知识所示」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:hirosi:]
「…………！」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

;****************************************
;スチル
[free_filter]
[still storage="cg/b1_2.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/b1_2.png"]
;****************************************

[:unknown:]
「沃尔佩克拉乃小狐之图。[rhr]
_　在大三角的摇篮里轻轻摇曳的，微小星座……」[rhp]
[:unknown:]
「……就是这么回事。当狐狸可以吗？大小姐」[rhp]

[:hirosi:]
「……！？」[rhp]

[:vulpecula:]
「狐狸？猫咪呢？」[rhp]

[:unknown:]
「捕鸟的不是猫而是狐狸。对吧？」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:hirosi:]
「………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:unknown:]
「哎呀？」[rhp]

[:hirosi:]
「护、护士呼叫……」[rhp]

[:unknown:]
「等等等等等等！你冷静点！」[rhp]

[:hirosi:]
「您从哪里进来的？我要叫人了啊！」[rhp]

[:unknown:]
「哪里……我从一开始就在」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:hirosi:]
「………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:unknown:]
「哎呀呀……好像产生了奇怪的误会……」[rhp]

[:vulpecula:]
「我明白了～？是跟踪狂吧！」[rhp]

[:unknown:]
「不、不是的……看来我没解释清楚」[rhp]
[:unknown:]
「我是从你身上诞生的。所以从一开始就在这里啊」[rhp]

[:hirosi:]
「您说什么呢。果然还是很可疑……」[rhp]

[:unknown:]
「谢谢您创造了我」[rhp]
[:unknown:]
「那个愿望，我一定会实现的」[rhp]

[:hirosi:]
「……，哈……？」[rhp]

;****************************************
;スチル終了

#
[s_mask color=0x000000 time=2000]
[bg storage="hsps_09n.jpg" time=100]
[filter layer="1" brightness="60"]
; ウィンドゥの設定
[position layer="message0" frame="win2.png" left=0 top=520 width=1280 height=200 page=fore visible=true]
[s_mask_off time=2000]

;****************************************

[chara_part name="sausu" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="peku2" body=base mimi=on ]
[chara_show name="peku2" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:]
「叔叔的头发闪闪发亮真漂亮呀」[rhp]

[:unknown:][sausu kao=2 as=on ]
「叔叔……」[rhp]

[:vulpecula:]
「像千纸鹤一样！」[rhp]

[off_all]

[:hirosi:][hiro kao=4 ]
「……！　诶……」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="hiro" body=base kao=0 as=on ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:unknown:]
「呵呵呵，没错哦小姐。正如您所说，我就是那边的千纸鹤」[rhp]

;--------------------------------------------------------------------------------------------
;▼フルボイス再設定▼
;サウス
[voconfig sebuf=1 name=turu vostorage="sausu/full/{number}.ogg" number=123]
;--------------------------------------------------------------------------------------------

[:turu:]
「……寄宿在其中的神明。按你的知识来说应该叫付丧神」[rhp]

[:hirosi:]
「神、神明什么的……太荒谬了」[rhp]

[off_all]

[:vulpecula:][peku2 mimi=on ]
「神明大人！！请把我变成小猫咪吧！」[rhp]

[off_all]

[:turu:][sausu kao=13 ]
「好啊」[rhp]

;****************************************
;魔法
[bg_magic_c color=%ffffff ]
;****************************************

[:vulpecula:][peku kao=5 ]
「哇啊……！」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=5 as=off ss=off hh=on hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:]
「这是小猫咪！？」[rhp]

[:turu:][sausu kao=13 ]
「或许是小狐狸呢。这个形态更适合你」[rhp]

[:vulpecula:][peku kao=14 hh=on ]
「谢谢啦！虽然没见过，但狐狸好像也不错！」[rhp]

[off_all]

[:hirosi:][hiro kao=0 ]
「……变成人类的样子了」[rhp]

[:turu:][sausu kao=1 ]
「‘希望能说很多很多话』。[rhr]
『希望博士能陪我玩’……这个愿望更容易实现吧」[rhp]

[:hirosi:][hiro kao=6 ]
「您真的是神明大人吗……？」[rhp]

[:turu:][sausu kao=14 ]
「不用敬语也可以的兄弟。倒是我应该敬重你才对」[rhp]
[:turu:]
「刚才也说过，创造我的人是你。[rhr]
_　你和仰慕你的孩子们强烈的思念，才造就了现在的我」[rhp]

[:hirosi:][hiro kao=4 hh=on ]
「……这种事情，居然真的存在」[rhp]

[:turu:][sausu kao=13 ]
「有意思呢。和幽灵是朋友的你会说出这种话啊」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:][peku kao=1 ]
「大叔，谢谢你！愿望立刻就实现了！[rhr]
_　千纸鹤真的好厉害啊！」[rhp]

[:turu:][sausu kao=13 as=on ]
「……我看上去有那么像大叔吗？[rhr]
_　为了增加亲近感，我特意模仿了这个地方最受爱戴之人的年龄」[rhp]
[:turu:]
「好像是叫矢部老师来着。[rhr]
_　他也对我许愿了呢。真开心」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="-60" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="355" top="0" wait="false" time=150]
[chara_part name="hiro" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="760" top="0" wait="true" time=150]

[:vulpecula:]
「噗噗噗！听说老师被仰慕着呢，博士～[rhr]
_　总觉得难以置信呢！」[rhp]

[:hirosi:][hiro kao=5 ]
「矢部老师就是那种性格所以没问题啦。[rhr]
_　其实大家都超喜欢的」[rhp]

[:turu:][sausu kao=1 ]
「嗯嗯。那份心情，确实传达到了哦」[rhp]

[:hirosi:][hiro kao=4 ]
「…………！　那个……难道说，[rhr]
_　能理解我和孩子们的想法吗？」[rhp]

[:turu:][sausu kao=14 ]
「折叠鹤时的感情和知识是共享的。[rhr]
_　从主楼的秘密藏身处到医疗知识都包含在内」[rhp]
[:turu:]
「不过占比最大的果然还是你的知识吧」[rhp]

[:vulpecula:][peku kao=5 ]
「博士可～是读了好多书拼命学习呢！[rhr]
_　脑子都快爆炸啦」[rhp]

[:turu:][sausu kao=14 ]
「呵呵呵，确实是庞大的知识量呢。不愧是被称为博士的人」[rhp]

[:hirosi:][hiro kao=2 as=on hh=on ]
「这、这种话能不能别说了。[rhr]
_　感觉脑内想法都被看透了很羞耻啊……」[rhp]

[:turu:]
「啊，说得也是。抱歉」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:hirosi:][hiro kao=7 ]
「………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:turu:][sausu kao=0 as=on ]
「啊，咦？你居然这么在意吗？」[rhp]

[:hirosi:][hiro kao=3 as=on ]
「……那些知识里，或许也包含着我已遗忘的事吧」[rhp]

[:turu:][sausu kao=4 ]
「诶……」[rhp]

[:hirosi:][hiro kao=8 as=on ]
「……！不、抱歉。明明问这种事也没意义」[rhp]

[:turu:][sausu kao=12 ]
「――――包含的哦」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:hirosi:][hiro kao=2 as=on ]
「――――！」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------


[:turu:][sausu kao=1 ]
「拥有你知识的我，也理解你的处境。[rhr]
_　……不过就算是神明，也并非万能……那个」[rhp]

[:hirosi:][hiro kao=3 ]
「没关系的」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:turu:][sausu kao=3 as=on ]
「！」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:hirosi:][hiro kao=12 ]
「我早就不奢望能改变什么了。[rhr]
_　我已经坦然接受自己的命运」[rhp]
[:hirosi:]
「说了奇怪的话抱歉。希望你能忘记刚才的对话」[rhp]

[:turu:][sausu kao=3 ]
「博士……」[rhp]

[off_all]

[:vulpecula:][peku kao=2 ]
「叔叔，你把博士弄哭啦」[rhp]

[:hirosi:][hiro kao=8 as=on ]
「才、才没哭！」[rhp]

[:hirosi:][hiro kao=1 ]
「叔叔真的别在意。我完全――」[rhp]

[off_all]

[:turu:][sausu kao=2 as=on ]
[font size=28]
「叔叔！！！！」[rhp]
[resetfont]

[off_all]

[chara_part name="sausu" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="hiro" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:turu:]
「――――快、快住手……！连浩也开始了！」[rhp]

[:hirosi:][hiro kao=1 as=on ]
「啊对不起，不知道名字所以……」[rhp]

[:turu:][sausu kao=14 ]
「因为是千纸鹤，叫阿千怎么样？」[rhp]

[off_all]

[:vulpecula:][peku kao=4 as=on ]
「老土～！」[rhp]

[:turu:][sausu kao=13 ]
「诶～？　才不土呢。又好叫又可爱吧？」[rhp]

[:vulpecula:][peku kao=6 ]
「叔叔才不可爱呢！」[rhp]

[:turu:][sausu kao=6 as=on ]
「好吧……」[rhp]

[:hirosi:][hiro kao=1 ]
「……那个……那、南怎么样？」[rhp]

[:vulpecula:][peku kao=4 ]
「桑拿？」[rhp]

[:turu:][sausu kao=8 as=on ss=on ]
「我有那么让人透不过气吗……！？」[rhp]

[:hirosi:][hiro kao=12 as=on ]
[font color=0x4682b4]
（笨蛋增加真让人头疼啊……）[rhp]
[resetfont]
[:hirosi:]
「……你左胸那个十字架，该不会是南十字星吧？」[rhp]

[:turu:][sausu kao=7 ]
「？　这个嘛……服装我没特别考虑过，全凭自然形成的。[rhr]
_　你的知识多少会反映出来，或许真是那样吧」[rhp]

[:hirosi:][hiro kao=1]
「那肯定没错。是《银河铁道之夜》呢」[rhp]

[:vulpecula:][peku kao=0 ]
「啥东西？　银嘎？」[rhp]

[:hirosi:][hiro kao=1]
「那是我读过的书里，最喜欢的故事。[rhr]
_　沃尔佩克拉的名字也是从那里获得的灵感哦」[rhp]

[:vulpecula:][peku kao=13 ]
「嘿！　我还以为是斗牛犬呢！」[rhp]

[:hirosi:][hiro kao=1]
「……而且，对身为千纸鹤的你来说叫南也很合适吧」[rhp]

[:turu:][sausu kao=0 ]
「怎么说？」[rhp]

[:hirosi:][hiro kao=1]
「千纸鹤、简称南」[rhp]

[:turu:][sausu kao=14 ]
「噢！」[rhp]

[:vulpecula:][peku kao=6 as=on ]
「？？　原、原来如此～」[rhp]

;--------------------------------------------------------------------------------------------
;▼フルボイス再設定▼
;サウス
[voconfig sebuf=1 name=sausu vostorage="sausu/full/{number}.ogg" number=151]
;--------------------------------------------------------------------------------------------

[:sausu:][sausu kao=14 ]
「不错。我很喜欢！　谢谢你浩」[rhp]

[:hirosi:][hiro kao=1 ]
「叫博士就好。太肉麻了」[rhp]

[off_all]

[:sausu:][sausu kao=1 ]
「那博士。我多么幸运啊。[rhr]
_　竟能遇见你这样出色的创造者」[rhp]
[:sausu:][sausu kao=1 ]
「你们托付给我的这份心意，我一定会让它实现的」[rhp]

[off_all]

[:hirosi:][hiro kao=1 hh=on ]
「…………、嗯。谢谢你」[rhp]

[off_all]

;ノック
[se storage="door_13.ogg"]

[:tiaki:]
「浩君？」[rhp]

[:hirosi:][hiro kao=4 ]
「！　好的……啊！」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="hiro" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sausu:]
「这声音是大美贺千秋吧。她也向我许下了美好的愿望――――」[rhp]

[:hirosi:][hiro kao=4 as=on ]
「快、躲起来躲起来！要是被发现在这种地方就糟了」[rhp]

[:sausu:][sausu kao=5]
「没关系的。你先看着吧」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:hirosi:][p_hr_13][hiro kao=6 ]
「……！？」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

;開ける
[se storage="door_07.ogg"]

[:tiaki:][tiaki kao=13 ]
「真是的，[player2]对吧？又擅自溜出来……」[rhp]

[off_all]

[chara_part name="hiro" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:]
「……话说，哎呀？不在……好奇怪。[rhr]
_　这个时间听到声音，还以为一定是[player2]呢」[rhp]

[:hirosi:][hiro kao=1 as=on ]
「啊、那个……呃……」[rhp]

[:tiaki:][tiaki kao=7 ]
「只有浩君……对吧？」[rhp]

[:hirosi:][hiro kao=7 as=on ]
「好、好的……」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sausu:]
「呀大美贺小姐。晚上好！」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:hirosi:][p_hr_22][hiro kao=4 as=on ]
「等！！！！！！！」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[chara_part name="sausu" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=4 as=on ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sausu:][sausu kao=13 ]
「这次谢谢你向我许愿」[rhp]

[:tiaki:][tiaki kao=14 hh=on ]
「我明白了。该不会是之前老师推荐的书在朗读吧？[rhr]
_　做是可以，但别弄得太晚哦」[rhp]

[:sausu:][sausu kao=1 ]
「知道了。不能勉强自己。我会代替你好好看着的」[rhp]

[:tiaki:][tiaki kao=14 ]
「熬夜是肌肤大敌！男孩子也要注意美容才行呢」[rhp]

[off_all]

[:tiaki:][tiaki kao=1 ]
「那么，晚安」[rhp]

[off_all]

[:hirosi:][hiro kao=8 as=on ]
「好、好的……晚安」[rhp]

[off_all]

;ドア閉める
[se storage="door_08.ogg"]

;------------------------------------------------------------------------------------------
;▼再開▼
;サウス
[voconfig sebuf=1 name=sausu vostorage="sausu/full/{number}.ogg" number=160]
[vostart]
;------------------------------------------------------------------------------------------

[chara_part name="sausu" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="-60" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="355" top="0" wait="false" time=150]
[chara_part name="hiro" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="760" top="0" wait="true" time=150]

[:hirosi:]
「………………看不见吗？」[rhp]

[:sausu:]
「是啊。看不见呢」[rhp]

[:vulpecula:]
「博库我也一直都没能看见哦？」[rhp]

[:hirosi:]
「那是因为沃尔佩克拉是幽灵所以会挑人。[rhr]
_　但南是付丧神……属于神明，或许性质不同吧」[rhp]

[:sausu:][sausu kao=3 ]
「…………、以你的聪慧。[rhr]
_　迟早会察觉到的，不如现在就告诉你吧」[rhp]
[:sausu:][sausu kao=3 ]
「我的身影，只有寿命将尽之人才能看见」[rhp]

[:hirosi:][hiro kao=3 ]
「……诶……」[rhp]

[off_all]

[chara_part name="peku" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="355" top="0" wait="false" time=150]
[chara_part name="hiro" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="760" top="0" wait="true" time=150]

[:vulpecula:]
「那意思是……会死掉吗？」[rhp]

[:sausu:]
「可以这么理解」[rhp]

[:vulpecula:]
「博士，会死吗？」[rhp]

[:sausu:]
「……不是现在」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:hirosi:][hiro kao=3 ]
「……………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[chara_part name="sausu" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="hiro" body=base kao=0 as=on ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sausu:]
「……但是博士。我会加油的」[rhp]
[:sausu:]
「现阶段还不可能。不过存在试错的空间。[rhr]
_　我会想尽办法，一定要救你……救你们所有人」[rhp]
[:sausu:]
「交给我吧。我正是为实现你们的心愿而诞生的啊」[rhp]

[:hirosi:][hiro kao=12 ]
「南……」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=14 as=on ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="-60" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="355" top="0" wait="false" time=150]
[chara_part name="hiro" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="760" top="0" wait="true" time=150]

[:vulpecula:][peku kao=5 ]
「太好了呢博士！能和南成为朋友，真的太走运啦！」[rhp]

[:sausu:][sausu kao=1 ]
「朋、朋友？不敢当，我不过是只千纸鹤……」[rhp]

[:hirosi:][hiro kao=8 hh=on ]
「是朋友哦」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:sausu:][sausu kao=1 hh=on ]
「！」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:hirosi:][hiro kao=7 hh=on ]
「单人病房很寂寞的。我未经许可是不能坐轮椅的，[rhr]
_　也没法去其他房间玩」[rhp]
[:hirosi:]
「所以，你是我第一个室友。[rhr]
_　在我的愿望实现之前，能有人陪我聊天的话我会很高兴的」[rhp]

[:sausu:][sausu kao=13 hh=on ]
「……嗯、嗯……」[rhp]

[off_all]

[chara_part name="hiro" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=14 as=off ss=off hh=on hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:hirosi:]
「请多指教，南」[rhp]

[:vulpecula:]
「请多指教哟！南！」[rhp]

[off_all]

[:sausu:][sausu kao=14 hh=on ]
「…………！请多指教！你们两个！」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
;夜空
[free_filter ]
[bg_rule storage="sky_07.jpg" rule="004.png" time=1500]
;****************************************

[::]
――――这就是我们的相遇。[rhp]
每当想到我竟被如此温柔的人创造出来时，[rhr]
至今胸口仍会涌起难以言喻的暖意，充盈着无可名状的满足感[rhp]
能降生于世真好。[rhr]
能与你们相遇真好。[rhp]
为报答他的恩情，我也一定要实现他们的愿望。[rhp]
那才是我真正的幸福。[rhp]

;****************************************
[fbgm]
[set_b storage="hsps_11.jpg"]
[bgm storage="bgm_18.ogg"]
;****************************************

―――与博士相遇后，时间过去了一个月。[rhp]
不知是因他天性宽厚，还是因我特别主动，[rhr]
我已完全被两人当作朋友接纳。[rhp]
帮博士缓解病情的手工活、和沃尔佩克拉玩捉鬼游戏、三人闲聊的时光。[rhr]
总之一切都令人欢欣，所有事物都如此新鲜。[rhp]

博士似乎也产生了变化，曾经因疾病恐惧而终日阴郁的[rhr]
他，内心逐渐焕发出明亮积极的光彩。[rhp]

「我能视物」这件事，究竟意味着什么。[rhr]
充实得连思考那种事情的闲暇都没有，这就是我们的日常。[rhp]

;****************************************
[bg storage="hsps_04.jpg" time=500]
;人外の透明フィルター
[filter layer="1" name="peku" opacity=50]
[filter layer="1" name="sausu" opacity=50]
;****************************************

[off_all]

[chara_part name="take" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:][p_mk_04]
「浩君，最近几乎都没有出现症状了呢」[rhp]

[:takeru:][p_tk_02][take kao=1 ]
「是的。虽然观察到些许记忆力减退现象，[rhr]
_　即便如此仍感觉比从前要好得多」[rhp]
[:takeru:]
「大美贺小姐、您有什么新的手工提案吗？」[rhp]

[:tiaki:][tiaki kao=0 ]
「不，我只是做个倾听者，那些事项都只遵照医生的指示哦」[rhp]

[:takeru:][p_tk_10][take kao=11 ]
「这样啊……那么，果然还是前些天」[rhp]

[:tiaki:][p_mk_13][tiaki kao=13 ]
「嗯。自从折完千纸鹤后，感觉他一直保持着开朗的状态。[rhr]
_　聊天时也发现，该说是表情变得丰富了吧」[rhp]
[:tiaki:]
「说明千纸鹤实现了他的心愿呢，一定是这样」[rhp]

[:takeru:][take kao=1 ]
「真是浪漫主义呢……无论如何，现在的八云君状态非常稳定。[rhr]
_　千纸鹤的功劳　这样说也并不为过」[rhp]

[:tiaki:][p_mk_31][tiaki kao=14 ]
「能继续保持这个进度就好了。[rhr]
_　说不定会出现奇迹完全康复什么的……」[rhp]

[:takeru:][take kao=0 ]
「最好不要抱有过高期待」[rhp]

[:tiaki:][tiaki kao=4 as=on ]
「……！」[rhp]

[:takeru:][p_tk_04][take kao=3 ]
「完全康复恐怕难以实现。我们应当以稳妥的方案为目标。[rhr]
_　阻止病情恶化。仅能做到这点已算成效显著了」[rhp]
[:takeru:][p_tk_04][take kao=2 ]
「而且这件事不该靠千纸鹤，而是我们应当完成的工作」[rhp]

[:tiaki:][tiaki kao=5 hh=on ]
「……没错！靠求神拜佛会有损护士的名声！」[rhp]

[:takeru:][p_tk_15][take kao=5 ]
「正是如此」[rhp]

[off_all]

「那么，差不多该进行下一次诊察了。走吧」[rhp]

[:tiaki:]
「好！」[rhp]

;****************************************
[bg_rule storage="hsps_06.jpg" rule="002.png" time=1500]
;****************************************

[chara_part name="sausu" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=14 as=off ss=off hh=on hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:sausu:][p_s_27]
「……呵呵！毕竟嘛」[rhp]

[:vulpecula:][p_vl_23][peku kao=4 ]
「博士，我的病是不是快治好了？」[rhp]

[:sausu:][sausu kao=14 ]
「这我无法断言……[rhr]
_　但比我更伟大的神明，似乎愿意再多给些时间呢」[rhp]

[:vulpecula:][peku kao=4 hh=on ]
「就是说我可以和博士玩更——久啦！？」[rhp]

[:sausu:][sausu kao=1 ]
「呵呵，没错哟」[rhp]

[off_all]

[:sausu:][sausu kao=13 ]
「博士是了不起的人。不仅内心强大，[rhr]
_　将我创造到这个世上，还让我感受到如此美好的情感」[rhp]
[:sausu:][sausu kao=11 ]
「必须趁着被赐予的时间，好好报恩才行。[rhr]
_　这才是真正的，仙鹤报恩……开玩笑啦」[rhp]

[off_all]

[:sausu:]
「——咦、哎呀？不、不见了！？」[rhp]

;****************************************
[bg_rule storage="hsps_09.jpg" rule="002.png" time=1500]
;****************************************

[:vulpecula:][peku kao=5 ]
[font size=28]
「博士～～～～～！！」[rhp]
[resetfont]

[off_all]

[chara_part name="hiro" body=base kao=4 as=on ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=14 as=off ss=off hh=on hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:hirosi:][p_hr_09]
「呜哇！是沃尔佩克拉啊。吓我一跳」[rhp]

[:vulpecula:][p_vl_06][peku kao=5 hh=on ]
「我跟你说哦！有个超级大新闻！」[rhp]
[:vulpecula:]
「博士的病啊，听说状态超级——好呢！」[rhp]

[:hirosi:][hiro kao=4 ]
「！」[rhp]

[:vulpecula:][peku kao=14 ]
「因为不是南的其他神明们赐予了很多时间，[rhr]
_　博库可以和博士玩个痛快啦！太好啦！」[rhp]

[:hirosi:][hiro kao=4 hh=on ]
「………………」[rhp]

[off_all]

[:sausu:][sausu kao=1 as=on ]
「啊！果然在这儿吗，沃尔佩克拉」[rhp]

[:vulpecula:][p_vl_09][peku kao=14 ]
「南！太——慢啦」[rhp]

[:sausu:][sausu kao=2 hh=on ]
「是你擅自一个人先回来的吧。[rhr]
_　一个人说那么羞人的台词不觉得害臊吗……」[rhp]

[off_all]

[:hirosi:][p_hr_06][hiro kao=1 hh=on ]
「这样啊……原来老师们，竟然会做那种事……」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=4 as=on ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:sausu:][p_s_03]
「……！　你说出来了？」[rhp]

[:vulpecula:][p_vl_24][peku kao=5  hh=on]
「嗯！因为人家超开心嘛！」[rhp]

[off_all]

[:hirosi:][hiro kao=1 hh=on ]
「……太好了。也许是折千纸鹤带来的福气吧」[rhp]

[:sausu:][sausu kao=13 ]
「谢谢。不过这不是我的功劳，都是博士的努力啊。[rhr]
_　正在和病魔抗争的不是我，是你才对」[rhp]
[:sausu:]
「我也非常高兴。而且能为交到这么优秀的朋友感到自豪」[rhp]

[:hirosi:][p_hr_31][hiro kao=1 ]
「有、有点难为情呢……不过，谢谢」[rhp]

[:sausu:][sausu kao=1 ]
「嗯嗯，笑容很棒呢。病魔肯定会望风而逃的」[rhp]

[off_all]

[:vulpecula:][p_vl_10][peku kao=2 hh=on ]
「那个ー，打扰ー。可以占用一点时间吗ー？」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=13 as=on ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:sausu:][p_s_20]
「好好，什么事呢」[rhr]
[font color=0x4682b4]
（是想说"失礼了"之类的话吧……）[rhp]
[resetfont]

[:vulpecula:][peku kao=5 ]
「博库觉得呀。既然博士这么精神的话？[rhr]
_　上次提的那件事，今天总该能答应我了吧ー！」[rhp]

[:sausu:][sausu kao=7 ]
「那件事？」[rhp]

[:vulpecula:][peku kao=13 ]
「啊对哦。南还不知道来着」[rhp]
[:vulpecula:]
「其实ー，这所临终关怀院最近要举办七夕会哦！」[rhp]

[:sausu:][p_s_17][sausu kao=0 ]
「七夕会……？　那是什么玩意儿？」[rhp]

[:vulpecula:][p_vl_16][peku kao=13 ]
「世界上有个叫七夕的节日ー，[rhr]
_　就是大家聚在一起庆祝的ー活动啦」[rhp]

[:sausu:][sausu kao=1 ]
「真不错！听着就很有意思呢」[rhp]

[:vulpecula:][peku kao=3 ]
「但是呢但是呢。因为博士是安生第一，[rhr]
_　米卡亲说过可能不能参加呢」[rhp]

[:sausu:][p_s_29][sausu kao=3 ]
「啊……是这样吗。那真是太遗憾了……」[rhp]

[:vulpecula:][p_vl_16][peku kao=13 hh=on ]
「可是啊！既然博士现在这么精神，[rhr]
_　说不定可能会有转机呢？」[rhp]

[off_all]

[:hirosi:][p_hr_30][hiro kao=3 as=on ]
「安静听着都觉得太乱来了……不可能的，绝对不行。[rhr]
_　就算状态再好，谨慎的矢部老师也不会允许的」[rhp]

[:vulpecula:][peku kao=7 ]
「诶——！真的吗？但博士现在状态不是很好嘛？」[rhp]
[:vulpecula:][peku kao=13 ]
「再去拜托一次试试看嘛！[rhr]
_　就算矢部老师不同意，说不定米卡亲会OK哦！」[rhp]
[:vulpecula:][peku kao=14 ]
「反对派和赞成派可能会展开激烈对决！！」[rhp]

[:hirosi:][p_hr_32][hiro kao=2 as=on ]
「你其实只是想看这个吧绝对！」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:][p_vl_04]
「对了！让南用魔法控制矢部老师[rhr]
_　让他答应不就好了嘛！」[rhp]

[:sausu:]
「我来？」[rhp]

[:vulpecula:][peku kao=5 ]
「用魔法呀！稍微操控下大脑什么的！怎么样？」[rhp]

[:sausu:][sausu kao=13 as=on ]
「这、这个可能有点做不到呢。rhr] _　或者说不想做……」[rhp]

[off_all]

[chara_part name="hiro" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:hirosi:][p_hr_33]
「我也反对！突然说这么可怕的事情禁止哦」[rhp]

[:vulpecula:][p_vl_10][peku kao=2 ]
「呜～～～！死脑筋！」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="hiro" body=base kao=3 as=on ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sausu:][p_s_04]
「……不过嘛，只是去拜托的话应该不算白费功夫吧」[rhp]

[:hirosi:][hiro kao=12 as=on ]
「没关系啦……只会给你添麻烦。[rhr]
_　光是101号室的孩子就已经够让人操心了……」[rhp]

[:sausu:][sausu kao=1 ]
「你很喜欢星星吧」[rhp]

[:hirosi:][p_hr_12][hiro kao=4 ]
「诶……」[rhp]

[:sausu:][sausu kao=13 ]
「晚上经常仰头看天空呢」[rhp]

[:hirosi:][p_hr_02][hiro kao=8 as=on ]
「…………那个」[rhp]

[:sausu:][p_s_15][sausu kao=13 ]
「七夕是跟天河有关的传说呢。[rhr]
_　一年一次的愿望，应该会被允许实现的吧」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=4 as=off ss=off hh=on hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:][p_vl_14]
「织女与牛郎也是这样啊！[rhr]
_　一年只能见一次面呢～博库很聪明吧」[rhp]

[:sausu:][sausu kao=5 ]
「没错没错。所以博士也试试看嘛」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="-60" top="0" wait="false" time=150]
[chara_part name="hiro" body=base kao=3 as=on ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="720" top="0" wait="true" time=150]

[:hirosi:]
「………………」[rhp]

[:sausu:][sausu kao=14 ]
「没问题的。拿出勇气来」[rhp]

[:vulpecula:][peku kao=14 ]
「幽灵和神明都站在你这边！用某种神奇力量绝对能实现愿望！」[rhp]

[:hirosi:][hiro kao=8 as=on ]
「…………唉，知道了。我就说说看……[rhr]
_　就算被拒绝也不会死心的哦？」[rhp]

[:vulpecula:][p_vl_15][peku kao=5 hh=on ]
「加油加油！嘿咻嘿咻！」[rhp]

[:sausu:][sausu kao=14 ]
「哦！」[rhp]

#
[off_all]

;ノック
[se storage="door_13.ogg"]
――――――。[rhp]


[:vulpecula:][peku kao=4 ]
「！！有人来了！快躲起来南！」[rhp]

[off_all]

[:sausu:][sausu kao=13 as=on ]
「呵呵，除了博士别人都看不见我们啦」[rhr]
[font color=0x4682b4]
（这对话都重复多少次了……）[rhp]
[resetfont]

[off_all]

[:tiaki:][p_mk_35][tiaki kao=13 ]
「下午好浩君。问诊时间到——」[rhp]

[:hirosi:][hiro kao=1 ]
「好的，麻烦了」[rhp]

[:takeru:][take kao=1 ]
「身体感觉如何？和昨天相比有什么变化吗？」[rhp]

[:hirosi:][p_hr_22][hiro kao=1 ]
「没什么特别。另外这个是昨天您布置的找错题作业」[rhp]

[:takeru:][take kao=11 ]
「我来确认」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:]
「找不同？」[rhp]

[:sausu:][p_s_15][sausu kao=1 ]
「说是为了锻炼大脑。就是昨天白天我们三个人一起玩的那个」[rhp]

[:vulpecula:][p_vl_24][peku kao=13 ]
「啊～那个啊！因为超级有趣，都没觉得是在治疗呢」[rhp]

[off_all]

[chara_part name="hiro" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:][p_mk_08]
「觉得怎么样？医生很坏心眼，应该很难吧？」[rhp]

[:hirosi:][p_hr_24][hiro kao=7 hh=on ]
「有一点。但很有成就感」[rhp]
[:hirosi:]
「而且，还有朋友一起……」[rhp]

[off_all]

[:takeru:][take kao=4 ]
「朋友？」[rhp]

[off_all]

[chara_part name="hiro" body=base kao=4 as=on ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="take" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:hirosi:][p_hr_22]
「啊……！那个」[rhp]

[:takeru:][take kao=7 ]
「昨天应该没有访客才对」[rhp]

[:hirosi:][hiro kao=1 as=on ]
「就、就是想着朋友会先找哪里 结果自然而然就完成了」[rhp]

[:takeru:][p_tk_06][take kao=0 ]
「……？这样啊……嘛，这种思考方式或许也不错」[rhp]
[:takeru:][p_tk_06][take kao=1 ]
「那么 这是今天的课题」[rhp]

[:hirosi:][hiro kao=4 ]
「这是……稿纸？」[rhp]

[:takeru:][take kao=11 ]
「想请你写篇读书感想」[rhp]
[:takeru:]
「绘本也好，小说也好，漫画也好什么都可以。[rhr]
_　随便读点什么书，把感想写在这张稿纸上」[rhp]

[:hirosi:][hiro kao=0 ]
「读书感想文……」[rhp]

[off_all]

[:tiaki:][tiaki kao=14 hh=on ]
「说什么都行哦！《女性SEVEN》的话随时可以借你」[rhp]

[:takeru:][take kao=6 ]
「不行」[rhp]

[:tiaki:][tiaki kao=6 as=on ]
「明明说什么都可以的！」[rhp]

[off_all]

[:hirosi:][hiro kao=13 as=on ]
「还、还是选正常的书好了……」[rhp]

[off_all]

[chara_part name="hiro" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="take" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:takeru:]
「不过玩笑归玩笑，最近的你状态非常稳定。[rhr]
_　就保持这个节奏 慢慢把课题难度提上去吧」[rhp]

[:hirosi:][hiro kao=1 ]
「好的！我会加油」[rhp]
[:hirosi:]
「那个、可能的话我想至少恢复到能复学的程度……[rhr]
_　所以越困难的任务我越欢迎」[rhp]

[:takeru:][take kao=14 ]
「啊。说得好」[rhp]

[off_all]

[chara_part name="hiro" body=base kao=5 as=off ss=off hh=on hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:][p_mk_02]
「我们也会全力支持你的！」[rhp]

[:hirosi:][hiro kao=5 hh=on ]
「非常感谢……！」[rhp]

[off_all]

[:sausu:][sausu kao=1 ]
[font color=0x4682b4]
（这样啊……博士是想要上学呢。原来喜欢学习啊）[rhp]
[:sausu:][sausu kao=13 ]
（……呵呵。说起来在千纸鹤里[rhr]
好像也有『想成为老师』的愿望来着）[rhp]
[resetfont]

[off_all]

[:vulpecula:][p_vl_26][peku kao=1 ]
「博士、博士！」[rhp]

[:hirosi:][hiro kao=4 ]
「！」[rhp]

[:vulpecula:][peku kao=14 ]
「七夕会！」[rhp]

[:hirosi:][p_hr_22][hiro kao=3 as=on ]
「……啊……」[rhp]

[off_all]

[:takeru:][take kao=0 ]
「八云君？怎么了」[rhp]

[off_all]

[:hirosi:][hiro kao=7 ]
「！没、没什么，那个……」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:2nin:]
「加油！」[rhr]
「加油！」[rhp]

[off_all]

[:hirosi:][hiro kao=0 as=on hh=on ]
「………………」[rhp]

[off_all]

[chara_part name="hiro" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="take" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:takeru:]
「……？八云君？」[rhp]

[:hirosi:][hiro kao=2 as=on hh=on ]
「呃……！那个！七、七夕会！」[rhp]

[:takeru:][p_tk_13][take kao=4 as=on ]
「诶……」[rhp]

[:hirosi:][hiro kao=3 as=on hh=on ]
「虽、虽然之前说过不能参加，但我果然还是不想放弃」[rhp]
[:hirosi:]
「想和大家一起看星星。[rhr]
_　那、那个我也能参加吗……？」[rhp]

[:takeru:][take kao=0 as=on ]
「………………」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=13 as=on ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=6 as=off ss=off hh=on hr=on f ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:][p_vl_17]
「实现吧～～实现吧～～……！南无阿弥陀佛～～～……！」[rhp]

[:sausu:]
「向佛祖祈祷有什么用啦……」[rhp]

[off_all]

[chara_part name="hiro" body=base kao=3 as=on ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="take" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:takeru:]
「…………这样啊。八云君原本就喜欢星星呢」[rhp]

[:hirosi:][hiro kao=1 ]
「好吧……」[rhp]

[:takeru:][take kao=12 ]
「………………」[rhp]

[:hirosi:][p_hr_22][hiro kao=12 as=on ]
「啊、那个。如果不行的话也没关系的，」[rhp]

[:takeru:][take kao=1 ]
「嗯。允许你参加」[rhp]

[:hirosi:][hiro kao=4 as=on ]
「――――诶」[rhp]

[:takeru:][take kao=13 ]
「进展很顺利。照这个状态，短时间内应该没问题」[rhp]

[:hirosi:][hiro kao=1 hh=on ]
「真、真的可以吗？　真的……？」[rhp]

[:takeru:][p_tk_29][take kao=1 ]
「仅限于短时间。切记不可长时间吹外风。[rhr]
_　必须乘坐轮椅，不得勉强行动。这是绝对条件」[rhp]

[:hirosi:][hiro kao=7 hh=on ]
「……！！　太感谢您了！！」[rhp]

[off_take]

[chara_part name="tiaki" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:]
「太好了呢，浩君」[rhp]

[:hirosi:][hiro kao=1 hh=on ]
「嗯……！　我、一直都好羡慕大家！」[rhp]

[:tiaki:][tiaki kao=13 ]
「我知道的。书架上全塞满了星星图鉴呢」[rhp]

[off_all]

[:takeru:][p_tk_01][take kao=14 ]
「当天好好享受吧。为此现在必须绝对静养。切莫大意」[rhp]

[off_all]

[:hirosi:][hiro kao=1 hh=on ]
「好！」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:][p_vl_37]
「呵呵……！　博士看起来很开心呢」[rhp]

[:sausu:][p_s_27][sausu kao=13 hh=on ]
「总觉得我们也跟着高兴起来了」[rhp]

[off_all]

[:hirosi:]
[font color=0x4682b4]
（啊，能鼓起勇气请求真是太好了……！[rhr]
_　虽然装作放弃的样子，其实一直都很羡慕大家）[rhp]
[:hirosi:]
（这都多亏了沃尔佩克拉和南。[rhr]
_　能和两人成为朋友实在太好了……！）[rhp]
[:hirosi:]
（七夕会，从现在就开始期待了……！）[rhp]
[resetfont]

;****************************************
[set_b storage="hsps_09.jpg"]
;****************************************

[chara_part name="hiro" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=14 as=off ss=off hh=on hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:][p_vl_06]
「太好了呢博士～。能参加七夕会啦！」[rhp]

[:hirosi:][p_hr_15][hiro kao=1 hh=on ]
「嗯！　谢谢你们沃尔佩克拉，南。[rhr]
_　多亏你们在背后推了我一把」[rhp]

[:vulpecula:][p_vl_31][peku kao=5 ]
「还有佛祖大人也帮忙了哦！」[rhp]

[:hirosi:][hiro kao=6 as=on ]
「佛祖大人？」[rhp]

[off_all]

[:sausu:][sausu kao=13 as=on ]
「哈哈……这是另外的典故……」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="-60" top="0" wait="false" time=150]
[chara_part name="hiro" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="720" top="0" wait="true" time=150]

[:sausu:]
「不过真的太好了。我还是第一次见到你那么开心的样子」[rhp]

[:hirosi:][p_hr_15]
「嘿嘿！是吗。[rhr]
_　不过真的，从刚才开始你就一直笑个不停呢」[rhp]

[:vulpecula:][peku kao=13 ]
「哼哼！都被你传染啦」[rhp]

[:sausu:][sausu kao=14 ]
「嘿嘿！我也是」[rhp]

[:hirosi:][hiro kao=1 hh=on ]
「但可不能太得意忘形……！[rhr]
_　精神松懈是疾病的天敌，适可而止地高兴就好」[rhp]

[:vulpecula:][peku kao=5 ]
「真成熟啊。换成博库的话估计能高兴一整年呢」[rhp]

[:sausu:][sausu kao=5 as=on ]
「那样的话七夕会都结束了吧……」[rhp]

[off_all]

[:hirosi:][hiro kao=1 ]
「对了。趁着有干劲，不如先把读后感写了吧」[rhp]

[off_all]

[chara_part name="hiro" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:]
「读后感……？那是什么呀？」[rhp]

[:hirosi:][p_hr_32][hiro kao=1 ]
「就是写下读完那本书的感受、获得的印象，以及对自己产生的影响。[rhr]
_　这种文章就叫读后感哦」[rhp]

[:vulpecula:][p_vl_24][peku kao=1 ]
「呵呵！博士看起来特别开心呢！[rhr]
_　虽然喜欢星星，但原来也喜欢读后感呀！」[rhp]

[:hirosi:][hiro kao=7 as=on ]
「不、不是这个意思……不过读书确实喜欢」[rhp]

[off_all]

[chara_part name="hiro" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="645" top="0" wait="true" time=150]

[:sausu:]
「已经决定要写哪本书了吗？」[rhp]

[:hirosi:][p_hr_02][hiro kao=1 ]
「嗯。是《银河铁道之夜》哦」[rhp]

[:sausu:][sausu kao=1 ]
「银河铁道……」[rhp]

[:hirosi:][hiro kao=1 ]
「这是我最喜欢的故事。听到课题要求时，脑海里最先浮现的就是它」[rhp]

[:sausu:][sausu kao=1 ]
「这样啊。那一定能写出好文章呢」[rhp]

[:hirosi:][hiro kao=1 ]
「嗯！　为此必须再重读三遍才行……！」[rhp]

[off_all]

[chara_part name="hiro" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:][p_vl_14]
「银河铁道……！　那个之前也问过博士！[rhr]
_　但就是完全搞不明白的部分！」[rhp]

[:hirosi:][hiro kao=1 ]
「说起来确实是这样呢。那下次再教你吧」[rhp]

[:vulpecula:][peku kao=6 ]
「诶～为什么下次嘛～现在教就好啦～」[rhp]

[:hirosi:][hiro kao=1 ]
「唔～现在你看，那个……」[rhp]

[off_all]

[:sausu:][p_s_03][sausu kao=1 ]
「沃尔佩克拉。博士很忙的，先和我聊天吧」[rhp]

[off_all]

[:vulpecula:][peku kao=4 as=on ]
「嗯？」[rhp]

[:sausu:][sausu kao=13 ]
「来来！　快点快点！」[rhp]

[yurasu]

[:vulpecula:][p_vl_10][peku kao=6 ]
「啊、等等啦～别拽我嘛～」[rhp]

[off_all]

;****************************************
[set_b storage="hsps_06.jpg"]
;****************************************

[:vulpecula:][p_vl_09][peku kao=2 ]
「～～～～～～～好无聊啊～」[rhp]

[:sausu:][p_s_32][sausu kao=5 ]
「哈哈……也没关系吧。暂时和我说说话嘛」[rhp]

[:vulpecula:][peku kao=3 ]
「为什么不能进房间嘛～[rhr]
_　博库明明想问博士银河铁道的事呢！」[rhp]

[:sausu:][sausu kao=13 ]
「他肯定想集中精神，我们在会打扰到他吧。[rhr]
_　毕竟临近七夕会了，他可是干劲十足呢～」[rhp]

[:vulpecula:][peku kao=6 as=on ]
「但是嘛～……还是好无聊啦～」[rhp]

[:sausu:][sausu kao=11 ]
「刚才不是一起从门缝偷偷看过房间里面吗？」[rhp]

[:vulpecula:][peku kao=13 ]
「嗯。博士在看书」[rhp]

[:sausu:][sausu kao=1 ]
「对吧。那位博士当时表情特别认真呢？」[rhp]

[:vulpecula:][peku kao=4 ]
「嗯……还是第一次看到博士露出那么认真的表情」[rhp]
[:vulpecula:][peku kao=1 ]
「他虽然偶尔会摆出那种严肃的表情，但平时总是显得更加寂寞。[rhr]
_　但今天不知怎的，他似乎在开开心心地摆着严肃脸」[rhp]

[:sausu:][sausu kao=13 ]
「说得对。或许他是享受思考难题的过程」[rhp]

[:vulpecula:][p_vl_19][peku kao=5 ]
「？虽然不太明白，但只要他开心就好啦！」[rhp]

[:sausu:][sausu kao=12 ]
「嗯嗯。这样最好了。[rhr]
_　只要博士看起来幸福，光是这点就足够让我们也感到幸福了」[rhp]

[:vulpecula:][peku kao=5 ]
「说得对！」[rhp]
「……啊！说到不明白的事，《银河铁道之夜》那本书」[rhp]

[:sausu:][sausu kao=0 ]
「那本书怎么了？」[rhp]

[:vulpecula:][peku kao=6 ]
「你看～南出现后不久，博士不是给我们讲解过吗？[rhr]
_　关于康贝瑞拉怎样怎样的」[rhp]
[:vulpecula:]
「南倒是听得津津有味，但博库我啊完全没搞懂。[rhr]
_　感觉好复杂呀！」[rhp]

[:sausu:][sausu kao=12 ]
「确实，对小小的你来说可能太难懂了呢」[rhp]

[:vulpecula:][p_vl_12][peku kao=2 as=on ]
「唉呀呀，好沮丧啊……[rhr]
_　要是我也能像博士那样享受他喜欢的事物就好了」[rhp]
[:vulpecula:]
「唉唉。作为博士最好的朋友，我真是没出息啊……」[rhp]

[:sausu:][sausu kao=4 ]
「沃尔佩克拉……」[rhp]

[:vulpecula:][peku kao=7 ]
「那个……是什么来着，那句话……」[rhp]

[:sausu:][sausu kao=0 ]
「那句话？」[rhp]

[:vulpecula:][peku kao=5 ]
「……啊！对了想起来了，是从博士那里听来的」[rhp]
[:vulpecula:]
「『让肯陶尔降下露水』这句话，南你知道吗？」[rhp]

[:sausu:][sausu kao=0 as=on ]
「嗯……那是什么啊」[rhp]

[:vulpecula:][p_vl_24][peku kao=6 ]
「完全搞不懂。听说连博士也完全不明白。[rhr]
_　不过他说这是《银河铁道之夜》里出现的词」[rhp]

[:sausu:][sausu kao=8 ]
「这样啊。……所以呢？」[rhp]

[:vulpecula:][peku kao=13 ]
「博士说啊，他为了弄清楚这句话的意思，读了好多研究书籍。[rhr]
_　但听说那些研究者们也完全不明白」[rhp]
[:vulpecula:]
「所以呢！我也在偷偷调查哦。关于肯陶尔究竟是什么。[rhr]
_　现在正全力在主楼巡逻呢！」[rhp]

[:sausu:][sausu kao=7 ]
「唔…可能肯陶尔是指半人马座……」[rhp]

[:vulpecula:][p_vl_19][peku kao=4 ]
「？」[rhp]

[:sausu:][sausu kao=11 ]
「――――不，没什么。是我多嘴了」[rhp]

[:vulpecula:][peku kao=2 ]
「多嘴？我是沃尔佩克拉呀！」[rhp]

[:sausu:][sausu kao=13 ]
「嗯嗯。是沃尔佩克拉呢」[rhp]
[:sausu:]
「『让肯陶尔降下露水』……真希望有一天能明白它的含义」[rhp]

[:vulpecula:][peku kao=13 ]
「嗯！不过在那之前得先把故事内容记清楚才行」[rhp]

[:sausu:][sausu kao=14 ]
「呵呵，确实是这样呢」[rhp]

[:vulpecula:][peku kao=7 ]
「唔～～～……可是好难嘛」[rhp]

[:sausu:][sausu kao=13 ]
「……对了！」[rhp]我有个好办法哦！」[rhp]

[:vulpecula:][peku kao=1 ]
「！什么什么！？」[rhp]

[:sausu:][p_s_16][sausu kao=5 ]
「其实我为了完成博士托付给身为千纸鹤的我的那个『心愿』，[rhr]
_　想了很多方法呢」[rhp]
[:sausu:]
「要是那个方法的话 一定能让沃尔佩克拉[rhr]
不是用头脑而是用身体来理解『银河铁道之夜』的内容」[rhp]

[:vulpecula:][p_vl_08][peku kao=14 ]
「真的！？　南好厉害ー！」[rhp]

[:sausu:][sausu kao=5 hh=on ]
「呵呵呵。也没那么夸张啦～」[rhp]

[:vulpecula:][peku kao=1 ]
「快告诉我告诉我！要做什么！？」[rhp]

[:sausu:][sausu kao=11 ]
「这个嘛……」[rhp]

[off_all]

[::]
……………………。[rhp]

[:vulpecula:][p_vl_08][peku kao=4 hh=on ]
「――――！！　要去银河铁道吗！？」[rhp]

[:sausu:][sausu kao=5 ]
「没错！　很浪漫吧？」[rhp]

[:vulpecula:][peku kao=4 ]
「可、可是！　博士说过那只是书里的故事啊！[rhr]
_　去书里的世界这种事……！？」[rhp]

[:sausu:][sausu kao=13 ]
「呵呵，不对不对。详细情况是秘密哦」[rhp]
[:sausu:]
「但确实能去。去银河铁道。我有这个能力」[rhp]

[:vulpecula:][peku kao=1 ]
「因为你是神明……！？」[rhp]

[:sausu:][sausu kao=11 ]
「就是这么回事」[rhp]

[:vulpecula:][peku kao=13 hh=on ]
「超级厉害！！　那那快点出发吧！[rhr]
_　比读书感想文重要多啦！！」[rhp]

[:sausu:][sausu kao=13 ]
「现在还不行。等夜幕降临再开始吧」[rhp]

[:vulpecula:][peku kao=6 ]
「诶ー！　会犯困的啦」[rhp]

[:sausu:][sausu kao=1 ]
「没办法呀。别任性。[rhr]
_　把期待留到后面 现在先想想过去后要做什么吧」[rhp]

[:vulpecula:][peku kao=14 ]
「这样啊……说得对！ 嗯呵呵 现在就开始激动了呢！」[rhp]

[:sausu:][sausu kao=13 hh=on ]
「所以呢，今天就我们三个人一起熬夜吧。[rhr]
_　沃尔佩克拉，就算困了也能好好醒着等我吗？」[rhp]

[:vulpecula:][p_vl_16][peku kao=5 hh=on ]
「当然啦！我会努力的！」[rhp]

[:sausu:][sausu kao=14 ]
「回答得真棒。那在博士写完读后感之前，[rhr]
_　就我们几个先玩吧」[rhp]

[:vulpecula:][peku kao=13 ]
「OK！那来玩探险队游戏吧！[rhr]
_　由我这个新手给南君当向导，带你参观这座临终关怀院」[rhp]

[:sausu:][sausu kao=1 ]
「那就拜托你了，队长先生」[rhp]

[:vulpecula:][p_vl_09][peku kao=5 hh=on ]
「队长……！？真是的！你可真会哄人呀！」[rhp]

[off_all]

[:vulpecula:][peku kao=5 ]
「好嘞，南队员！跟着佩奇队长出发咯！」[rhp]

[off_all]

[:sausu:][p_s_01][sausu kao=13 ]
「好——的，队长！」[rhp]

[off_all]

;****************************************
[set_b storage="hsps_09.jpg"]
;****************************************

[:hirosi:][hiro kao=1 ]
「…………噗嗤」[rhp]

[off_all]

[:hirosi:][p_hr_15]
[font color=0x4682b4]
（他们聊什么呢？好像很开心啊）[rhp]
[resetfont]

[:hirosi:][hiro kao=7 ]
「待会儿我也要加入他们。[rhr]
_　……那个，…………」[rhp]
[:hirosi:]
「………………、……呃」[rhp]

[off_all]

[::]
………那两个人刚才说什么来着。[rhp]
没错，那两个人是……[rhp]
……………………。[rhp]

[:hirosi:]
「………………沃尔佩克拉。还有，……南」[rhp]
[:hirosi:]
「……嗯、……当然，我记得……」[rhp]

[:hirosi:]
[font color=0x4682b4]
（只是脑子有点乱。[rhr]
_　因为正在读《银河铁道之夜》，所以才格外混乱。仅此而已）[rhp]
[:hirosi:]
（老师也说过。病情在恶化）」[rhp]
[:hirosi:]
（…………所以，没问题的）[rhp]
[resetfont]

;****************************************
[fbgm]
[set_n storage="hsps_09n.jpg"]
[bgm storage="bgm_07.ogg"]
;****************************************

[:vulpecula:][peku kao=12 ]
「…………、……唔……」[rhp]

[:sausu:][sausu kao=1 ]
「喂——，沃尔佩克拉」[rhp]

[:vulpecula:][peku kao=4 ]
「啊！！」[rhp]
[:vulpecula:][p_vl_30][peku kao=5 as=on ]
「怎、怎么啦？　博库我——点都不困哦？」[rhp]

[:sausu:][sausu kao=13 ]
「23点果然还是会困吧。再坚持一会儿就好」[rhp]

[:vulpecula:][peku kao=2 hh=on ]
「真是的！都说了不困啦！」[rhp]

[off_all]

[:hirosi:][p_hr_12][hiro kao=1 ]
「你们两个，今天怎么回事？　这个时间还在实验室真少见呢。[rhr]
_　南暂且不论，沃尔佩克拉平时都是跟着熄灯铃回去的……」[rhp]

[:vulpecula:][peku kao=13]
「嘿嘿嘿！我们在等人啦！」[rhp]

[:hirosi:][hiro kao=6 ]
「等人……？等谁？」[rhp]

[:vulpecula:][peku kao=5 ]
「时刻！！」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="hiro" body=base kao=1 as=on ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:hirosi:]
「……也就是说？」[rhp]

[:sausu:][sausu kao=14 ]
「就是等那个可怕的人睡着嘛」[rhp]

[:hirosi:][hiro kao=6 as=on ]
「不，完全听不懂你在说什么啊……」[rhp]
[:hirosi:][hiro kao=6 as=on ]
「……但你们明显在策划什么吧」[rhp]

[:sausu:][p_s_17][sausu kao=1 ]
「诶～？说得人家像坏人似的」[rhp]

[:hirosi:][hiro kao=0 ]
「今天中午我做博士课题的时候，[rhr]
_　你们俩不是特别吵闹吗。那时候就在谋划什么吧？」[rhp]
[:hirosi:][hiro kao=0 ]
「别搞太出格的事啊。[rhr]
_　不能给值夜班的同事添麻烦」[rhp]

[off_all]

[chara_part name="hiro" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:][p_vl_11]
「哈、博士……彻底当我们是捣蛋鬼了呢」[rhp]

[:hirosi:][hiro kao=6 as=on ]
「事实如此吧。每次看不见你们人影时，肯定都在搞事情」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=11 as=on ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="-60" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="355" top="0" wait="false" time=150]
[chara_part name="hiro" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="760" top="0" wait="true" time=150]

[:vulpecula:]
「～～～南！　我觉得差不多该坦白了吧！」[rhp]

[:sausu:][sausu kao=13 as=on ]
「是啊……我也不想我们的股价继续下跌」[rhp]

[:hirosi:][hiro kao=6 ]
「到底怎么回事？[rhr]
_　先说好，我可不赞成从病房偷溜出来这种事……」[rhp]

[:vulpecula:][p_vl_16][peku kao=5 hh=on ]
「听我说博士！　现在南要[rhr]
_　带我们乘坐银河铁道啦！」[rhp]

[:hirosi:][hiro kao=4 ]
「啊……？」[rhp]

[:vulpecula:][peku kao=5 ]
「对吧！」[rhp]

[:sausu:][p_s_02][sausu kao=5 ]
「嗯」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="hiro" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:hirosi:][p_hr_10]
「银、银河铁道？　你在说什么……？　那只是虚构的，」[rhp]

[:sausu:][p_s_16][sausu kao=5 hh=on ]
「只要使用魔法，虚构之物也能化为现实。[rhr]
_　我一直在思考这个问题，终于找到了绝妙的方法」[rhp]

[:hirosi:][hiro kao=1 as=on ]
「……啊，这样啊。是用魔法让我们做美梦对吧，」[rhp]

[:sausu:][sausu kao=1 ]
「不对」[rhp]

[:hirosi:][hiro kao=3 ]
「可、可是…………」[rhp]
[:hirosi:]
「………………正因为不可能实现，才会心驰神往」[rhp]

[:sausu:][sausu kao=11 ]
「我明白。无论如何，你始终向往着银河铁道。[rhr]
_　所以我也为了实现这个愿望拼尽全力」[rhp]

[:hirosi:][hiro kao=0 ]
「南……」[rhp]

[off_all]

[:vulpecula:][peku kao=13 ]
「嘿嘿……！　好期待啊。银河铁道！」[rhp]
[:vulpecula:]
「博库啊，是真心想了解银河铁道的事情。[rhr]
_　因为我想和博士喜欢同样的东西」[rhp]
[:vulpecula:]
「这样就算博士忘记了，[rhr]
_　博库也能马上告诉你哦！」[rhp]

[off_all]

[:hirosi:][hiro kao=6 ]
「……沃尔佩克拉……」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="-60" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="355" top="0" wait="false" time=150]
[chara_part name="hiro" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="760" top="0" wait="true" time=150]

[:hirosi:][p_hr_07]
「…………、你们两个。谢谢」[rhp]

[:vulpecula:][p_vl_29][peku kao=5 ]
「诶嘿嘿！是挚友的话这种程度很普通啦！」[rhp]
[:vulpecula:]
「对吧，南！」[rhp]

[:sausu:][p_s_24][sausu kao=13 ]
「没错。对我来说不仅是挚友，还是父亲呢」[rhp]

[:hirosi:][hiro kao=8 as=on ]
「呜……！我、我还没结婚呢！」[rhp]

[:sausu:][sausu kao=5 ]
「啊哈哈！说成生身父母会比较好吗」[rhp]

[:hirosi:][hiro kao=4 as=on ]
「不是一样吗！？」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="hiro" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sausu:]
「呵呵呵。总之就是想对你表达深深的感谢」[rhp]
[:sausu:]
「因为你是我降生于世的恩人。[rhr]
_　一直想好好道谢」[rhp]
[:sausu:]
「所以……博士。今天要尽兴哦」[rhp]

[:hirosi:][hiro kao=1 ]
「………………以挚友的身份啦！才不要当什么父母」[rhp]
[:hirosi:]
「我和你和沃尔佩克拉，想要保持平等关系。[rhr]
_　那个……因、因为是挚友嘛！」[rhp]

[:sausu:][sausu kao=11 ]
「谢谢。真是温柔的孩子」[rhp]

[off_all]

[:sausu:][sausu kao=1 ]
「………………好了，时机差不多成熟了」[rhp]

[off_all]

[chara_part name="peku" body=base kao=4 as=off ss=off hh=on hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="hiro" body=base kao=2 as=on ss=off hh=on hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:vulpecula:][p_vl_06]
「！！真的吗！？要出发了！？」[rhp]

[:hirosi:][hiro kao=1 kao=2 as=on hh=on ]
「呃……！」[rhp]

[off_all]

[:sausu:][p_s_32][sausu kao=13 ]
「哈哈哈……不用这么紧张啦」[rhp]

[off_all]

[:sausu:]
「那大家现在，闭上眼睛」[rhp]

[fbgm]

[:sausu:]
「要开始了。3、2、……」[rhp]

;****************************************
;魔法

#
[s_mask color=0x000000 time=2000]
; 背景表示
[bg storage="hikari.jpg" time=100]
; 全部のフィルターを打ち消す
[free_filter ]
; ウィンドゥの設定
[position layer="message0" frame="win.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[s_mask_off time=2000]
[bgm storage="bgm_19.ogg"]
;****************************************

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
[vostart]
;--------------------------------------------------------------------------------------------

[:hirosi:]
「………！？」[rhp]

[:vulpecula:]
「哇啊！感觉身体突然轻飘飘的！」[rhp]
[:vulpecula:]
「喂——现在还不能睁开眼睛吗——？」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:sausu:][p_s_29]
「真拿你没办法」[rhp]

;--------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;--------------------------------------------------------------------------------------------

;****************************************
[se storage="body_08.ogg"]
[bg_magic_b storage="black.jpg" rule="027.png" time=500]
;****************************************

[:hirosi:]
「………………」[rhp]
[:hirosi:]
[font color=0x4682b4]
（虽然脚踩在地面上，也感觉不到风吹……）[rhp]
[:hirosi:]
（……、咦？　……脚踩在地面……？）[rhp]
[resetfont]

[:vulpecula:]
「哇啊……！博士博士！快点睁开眼睛！」[rhp]

[:hirosi:]
「…………」[rhp]

;****************************************
[bg_rule storage="train_01.jpg" rule="009.png" time=1000]
;****************************************

[:hirosi:][hiro kao=4 hh=on ]
「――――！」[rhp]

[off_all]

[:vulpecula:][peku kao=4 as=on hh=on ]
「太厉害了太厉害了！这房间是什么？又细又长！！」[rhp]
[:vulpecula:][peku kao=14 hh=on ]
「南！为什么我们会在这种地方！？[rhr]
_　刚才还在博士的房间里啊！」[rhp]

[off_all]

[:hirosi:][hiro kao=1 hh=on ]
「……银、银河铁道……！」[rhp]

[:vulpecula:][peku kao=4 hh=on ]
「啊――――！！！！哈、哈哈哈博士！！」[rhp]

[:hirosi:][hiro kao=4 ]
「呃？什、什么？」[rhp]

[:vulpecula:][peku kao=13 hh=on ]
「啊，脚……！」[rhp]

[:hirosi:][hiro kao=1 hh=on ]
「……！？啊……」[rhp]

[:vulpecula:][peku kao=5 ]
「博士站起来了～～～～！！」[rhp]

[:hirosi:][hiro kao=1 hh=on ]
「…………」[rhp]

[:vulpecula:][peku kao=13 ]
「太好了呢，博士！这样就能和我一起散步啦！」[rhp]

[:hirosi:][hiro kao=4 hh=on ]
「嗯、嗯……！没想到还能再有站起来的一天」[rhp]

[off_all]

[:sausu:][sausu kao=13 ]
「虽然现在只在这个世界里可以……[rhr]
_　为了让现实世界也终有一天能实现，我会更加努力学习的」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:]
「在现实里？真的能实现吗？」[rhp]

[:sausu:][sausu kao=5 ]
「当然啦。我可是实现愿望的神明哦」[rhp]

[:vulpecula:][peku kao=4 hh=on ]
「南，好厉害！真的越来越像神明大人了！」[rhp]

[:sausu:][sausu kao=2 ]
「我本来就是真正的神明。之前你把我当成什么了」[rhp]

[:vulpecula:][peku kao=13 ]
「挚友！从今天开始就是神明大人的挚友啦！」[rhp]

[:sausu:][sausu kao=5 ]
「！　……呵呵，升级了吗。真光荣呢！」[rhp]

[off_all]

[:sausu:]
「那作为升级纪念，这个怎么样？」[rhp]

;****************************************
[se storage="mag_10.ogg"]
[bg_magic_c color="0xffffff" rule="009.png"]
;****************************************

[:hirosi:][hiro kao=4 ]
「……！？」[rhp]

;カイトとプリンセス登場

[off_all]

[:girl:][puri kao=1 ]
「你好！」[rhp]

[off_all]

[:man:][kite kao=0 ]
「………………你—好—」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;ヴルペクラ
[voconfig sebuf=1 name=peku vostorage="peku/full/{number}.ogg" number=104]
;------------------------------------------------------------------------------------------

[chara_part name="sausu" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=2 as=on ss=off hh=on hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:]
「谁！？」[rhp]

[:sausu:][sausu kao=5 ]
「电车上不是有车长和乘务员吗？[rhr]
_　这可是我为了这天特意准备的」[rhp]
[:sausu:]
「是以临终关怀院的孩子为原型哦。猜得出是谁吗？」[rhp]

[:vulpecula:][peku kao=5 ]
「猜不出！！」[rhp]

[:sausu:][sausu kao=7 as=on ]
「好、好快……！　本来还想让你多纠结一会儿的」[rhp]

[:vulpecula:][peku kao=7 ]
「因为你们两个都是大人了啊！！」[rhp]

[:sausu:][sausu kao=8 ]
「呵呵。小孩子毕竟有点靠不住呢」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="-60" top="0" wait="false" time=150]
[chara_part name="hiro" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="720" top="0" wait="true" time=150]

[:sausu:]
「对了。不如给他们起个昵称吧」[rhp]

[:hirosi:][hiro kao=8 ]
「昵称？」[rhp]

[:sausu:][sausu kao=5 ]
「在这世界的名字哦。像秘密暗号一样很帅吧」[rhp]

[:vulpecula:][peku kao=13 ]
「确实！」[rhp]

[off_all]

[:man:][kite kao=0 ]
「不不……这种事儿没必要吧。[rhr]
_　直接用本名不就行了。我叫和――――」[rhp]

[:girl:][puri kao=13 ]
「不行！绝对要用代号。[rhr]
_　[player2]毕竟和近始终是他们本人啊」[rhp]
[:girl:][puri kao=13 ]
「只要那两人还活着，我们对他们就是陌生人吧？」[rhp]

[:man:][kite kao=7 ]
「是这么回事吗」[rhp]

[:girl:][puri kao=1 ]
「就是这么回事。博士可能会搞混也说不定」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:hirosi:][hiro kao=7 ]
[font color=0x4682b4]
（已经搞混了 though……）[rhp]
[resetfont]


[off_all]

[:hirosi:]
（…………根据刚才的对话，[rhr]
_　2个人[player2]确实是以和近君为模特吗？）[rhp]
[resetfont]

[chara_part name="puri" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="puri" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:man:]
「哈啊……好困。我可以先回去了吗」[rhp]

[:girl:][puri kao=6 as=on ]
「不行啦！这可是初次见面，必须要好好招待才行」[rhp]

[:man:][kite kao=0 ]
「麻烦死了……」[rhp]

[off_all]

[:hirosi:][hiro kao=1 hh=on ]
[font color=0x4682b4]
（呵呵……有点能理解呢）[rhp]
[resetfont]

[off_all]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[chara_part name="sausu" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="-60" top="0" wait="false" time=150]
[chara_part name="hiro" body=base kao=0 as=on ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="720" top="0" wait="true" time=150]

[:sausu:]
「博士不是见多识广嘛，应该很擅长这种事吧？」[rhp]

[:vulpecula:][peku kao=5 ]
「因为博士什么都知道嘛！」[rhp]

[:hirosi:][hiro kao=6 ]
「诶……啊、那个……那就」[rhp]

[off_all]

[::]
博士分别为他们赐予了快斗、公主的名字。[rhp]
似乎是从我服装的纽扣得到的灵感。[rhr]
还是一如既往无所不知呢。令人再次肃然起敬。[rhp]

[chara_part name="peku" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="hiro" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:vulpecula:]
「好厉害啊博士！[rhr]
_　大家都像大人一样，让人有点心跳加速呢……！」[rhp]

[:hirosi:][hiro kao=4 hh=on]
「嗯、嗯……」[rhp]

[off_all]

[:sausu:][sausu kao=13 ]
「…………呵呵！」[rhp]

[off_all]

[::]
两人能开心真是太好了。[rhp]
希望看到更多笑容。[rhr]
希望看到更多喜悦。[rhp]
我真的很喜欢他们幸福的表情。[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:sausu:]
[font color=0x4682b4]
（……对了！）[rhp]
[resetfont]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[::]
那么接下来试试这样的如何？[rhr]
我怀着期待轻轻挥动手杖。[rhp]

;****************************************
;魔法
[se storage="mag_10.ogg"]
[bg_rule color="0xffffff" rule="020.png"]
;****************************************

[:vulpecula:]
「！？什么呀？突然这么刺眼……」[rhp]

;****************************************
[bg_rule storage="train_01.jpg" rule="020.png" time=500]
;****************************************

[yurasu]

[chara_part name="hakase" body=base kao=0 as=on ss=off hh=off hr=on msk=hat ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=2 as=on ss=off hh=on hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:]
[font size=30]
「呀！！？？」[rhp]
[resetfont]

[:hirosi:]
「？你说什么？」[rhp]

[yurasu]

[:vulpecula:]
[font size=30]
「谁――――！？」[rhp]
[resetfont]

[off_all]

[:sausu:][sausu kao=5 ]
「是博士啦！」[rhp]

[off_all]

[chara_part name="hakase" body=base kao=4 as=on ss=off hh=off hr=on msk=hat ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:hirosi:]
「……？　什、什么这套装扮……、！？[rhr]
_　总觉得声音好像变低沉了……」[rhp]

[:sausu:][sausu kao=13 ]
「为了配合你们两个，让你也变身成大人了」[rhp]

[:hirosi:][hakase kao=4 as=on  msk=hat ]
「大、大人……我居然……」[rhp]

[off_all]

[chara_part name="puri" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="puri" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=14 as=off ss=off hh=on hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:]
「好厉害好厉害！　个子好高！　帽子超大！」[rhp]

[:princess:][puri kao=13 ]
「很合适哦，博士！」[rhp]

[off_all]

[:hirosi:][hakase kao=3 msk=hat ]
「…………呜……」[rhp]

;カット
;[:hirosi:]
;「…………、[player2]ちゃんなんだ、本当に」[rhp]

[off_all]

[chara_part name="puri" body=base kao=4 as=on ss=off hh=off hr=on ]
[chara_show name="puri" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:princess:]
「！　诶、怎么了？」[rhp]

[:vulpecula:][peku kao=3 ]
「博士！　你在哭吗？　怎么了？　不想当大人了吗？」[rhp]

[off_all]

[:hirosi:][hakase kao=1 hh=on  msk=hat  ]
「不是……是太高兴了……能看到大家精神饱满的样子。[rhr]
_　和近已经能靠自己的双腿站立了……」[rhp]

[off_all]

[chara_part name="puri" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="puri" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:kite:]
「博士不也是这样吗」[rhp]

[:princess:][puri kao=14 ]
「太夸张啦，博士真是的」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[:hirosi:][hakase kao=3 hh=on  msk=hat ]
「而、而且……把我变成这副模样的事也是」[rhp]
[:hirosi:]
「…………我肯定活不到这个年纪的」[rhp]

[off_all]

[chara_part name="hakase" body=base kao=1 as=off ss=off hh=off hr=on msk=hat ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:hirosi:]
「谢谢你南。即使是梦也很开心。[rhr]
_　……不只是因为这副身体哦」[rhp]
[:hirosi:]
「千纸鹤真厉害啊。居然实现了我最大的心愿」[rhp]

[:sausu:][sausu kao=5 hh=on ]
「『希望能被邀请乘坐银河铁道』对吧。[rhr]
_　这是你众多愿望中的一个」[rhp]
[:sausu:]
「……不过抱歉，那个愿望只能实现一半哦」[rhp]

[:hirosi:][hakase kao=3 as=on  msk=hat ]
「诶……？」[rhp]

[:sausu:][sausu kao=2 ]
「因为那个愿望的前半部分，我实在不喜欢呢」[rhp]

[:hirosi:][hakase kao=4  msk=hat ]
「……！啊……」[rhp]

[:sausu:][sausu kao=3 ]
「银河铁道的旅途是通往冥府的诀别之路。[rhr]
_　但遗憾的是你还未曾死去」[rhp]
[:sausu:]
「『死后至少要去银河铁道』……这类愿望，我可不会用自己的权限批准哦」[rhp]

[off_all]

[chara_part name="hakase" body=base kao=3 as=on ss=off hh=off hr=on msk=hat ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:]
「博士，你竟然这么想的！？」[rhp]

[:hirosi:][hakase kao=8 as=on  msk=hat ]
「那、那是……」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[chara_part name="puri" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="puri" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:kite:]
「你爱怎样随你便，但悲观主义太逊啦」[rhp]

[:princess:][puri kao=14 ]
「没错。活着的时候，就该只想活着的事」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[chara_part name="sausu" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=2 as=off ss=off hh=on hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:]
「顶多只能选择忘记！[rhr]
_　寻死什么的绝―――――对禁止！」[rhp]

[:sausu:][sausu kao=11 ]
「……有人这么说呢。我也完全赞同」[rhp]

[off_all]

[:hirosi:][hakase kao=4 hh=on  msk=hat  ]
「南……大家……」[rhp]

[:sausu:][sausu kao=3 ]
「你就是那个故事里的乔班尼」[rhp]
[:sausu:]
「痛苦或悲伤时，随时向我许愿吧。[rhr]
_　无论多少次都会带你来到这片银河」[rhp]
[:sausu:][sausu kao=14 ]
「等醒来的时候，所有不开心的事都会烟消云散！」[rhp]

[:vulpecula:][peku kao=5 ]
「之后就要去拿牛奶了对吧！」[rhp]

[:sausu:][sausu kao=11 ]
「呵呵，正是如此」[rhp]

[:vulpecula:][peku kao=14 ]
「现在可不是寻死的时候，博士！[rhr]
_　要是拿到牛奶的话，必须得给妈妈送过去才行啊！」[rhp]
[:vulpecula:][peku kao=14 ]
「啊！那说不定博库也想请你给我妈妈送一下。[rhr]
_　真是的～到底什么时候才能死掉啊博士～！真遗憾呢～」[rhp]

[:hirosi:][hakase kao=14 hh=on  msk=hat ]
「哈哈哈……！什么啊。真是的，净说些胡话」[rhp]
[:hirosi:][hakase kao=1 hh=on  msk=hat ]
「…………不过，我会尽可能努力的」[rhp]

[:vulpecula:][peku kao=5 ]
「……！！嗯嗯！加油吧！不管是送牛奶还是活下去！」[rhp]

[off_all]

[:vulpecula:][peku kao=14 hh=on ]
「好——那么首先就来探索这个细长的房间吧！[rhr]
_　南队员！博士队员！其他各位！务必紧跟着队长哦！」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[chara_part name="puri" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="puri" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:kite:]
「我放弃」[rhp]

[:princess:][puri kao=2 as=on ]
「别抱怨啦。看起来很开心的样子不是挺好嘛」[rhp]
[:princess:]
「我们生来就是为了让他们开心。[rhr]
_　不管是探险还是什么，只要有人提出要求就应当全力挑战！」[rhp]

[:kite:][kite kao=6 ]
「你也太认真了吧。……嘛，不过也行啦」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[:sausu:][sausu kao=13 ]
「呵呵呵……」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=11 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:sausu:]
「啊。话说队长」[rhp]

[:vulpecula:][peku kao=1 ]
「什么事？南队员」[rhp]

[:sausu:][sausu kao=5 ]
「关于这个神奇房间的事，博士队员不是更了解吗？」[rhp]

[off_all]

[:hirosi:][hakase kao=8 as=on msk=hat ]
「诶……」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="-60" top="0" wait="false" time=150]
[chara_part name="hakase" body=base kao=0 as=on ss=off hh=off hr=on ]
[chara_show name="hakase" layer="1" width="571" height="720" left="355" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="720" top="0" wait="true" time=150]

[:vulpecula:]
「！！对哦！博士毕竟是博士嘛！」[rhp]
[:vulpecula:]
「那队长就交给博士啦！[rhr]
_　我就当副队长这样。尽管依赖我吧！队长！」[rhp]

[:sausu:][sausu kao=13 ]
「据说如此。博士队长」[rhp]

[:vulpecula:][peku kao=13 ]
「博士队长！」[rhp]

[:hirosi:][hakase kao=0 hh=on as=on msk=hat ]
「呜……！那、那种称呼太让人害羞了……[rhr]
_　真拿你没办法啊……」[rhp]
[:hirosi:]
「………………咳咳。[rhr]
_　诸位，请务必紧跟这位达克内布拉博士！」[rhp]

[:sausu:][sausu kao=12 as=on ]
「达克……？」[rhp]

[:vulpecula:][peku kao=13  hh=on ]
「内布拉？」[rhp]

[:hirosi:][hakase kao=2 hh=on as=on ]
「！！！！但但、但是。[rhr]
_　大家都有代号，只有浩没有……」[rhp]

[off_all]
;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[chara_part name="puri" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="puri" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:princess:]
「初中生好像都喜欢这种呢」[rhp]

[:kite:][kite kao=6 as=on ]
「外表那样内心却意外成熟真够呛啊」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[:hirosi:][hakase kao=7 hh=on as=on msk=hat ]
「不不不。是严格参照银河铁道之夜设定的，」[rhp]

[off_all]

[:vulpecula:]
「探险开始——！」[rhp]

[:hirosi:]
「等等！听我说完啊！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
#
[bg storage="sky_13.jpg" time=1500]
;****************************************

[::]
银河铁道的世界，远远超出了我的想象。[rhp]
与从博士知识中借来的情报完全不同。[rhr]
谁会想到这是承载逝者灵魂的悲伤电车呢。[rhp]
……不坏。倒不如说棒极了。[rhp]
虽然这个世界终究是借来的，构筑者并非我，[rhr]
但比起自己从零打造的理想国，这里要闪耀幸福得多。[rhp]
伙伴的笑容就是证明。[rhp]

;****************************************
[bg storage="train_12.jpg" time=1500]
;****************************************

能来此真好。定要再度造访。[rhp]
对了，下次多带些人来也不错。[rhr]
既然有列车员，既然有餐车，自然也需要厨师。[rhp]
对无机质的白墙已经腻烦了吧，比任何梦都要绚丽多彩。[rhr]
我们三人的回忆，就尽情地塞进去吧。[rhp]
塞进这闪闪发光的宝石箱里。[rhp]

;****************************************
[s_mask color=0x000000 time=2000]
; 背景表示
[bg storage="hsps_09n.jpg" time=100]
; 夜フィルター
[filter layer="1" brightness="60"]
; ウィンドゥの設定
[position layer="message0" frame="win2.png" left=0 top=520 width=1280 height=200 page=fore visible=true ]
[s_mask_off time=2000]
;****************************************

[::]
在天亮前，我们再次回到了病房。[rhp]
虽然非常舍不得，但若在那个世界迎来早晨就有点不妙了。[rhp]

[:vulpecula:][peku kao=12 ]
「哈啊……」[rhp]

[:sausu:][sausu kao=1 ]
「辛苦了，沃尔佩克拉。银河铁道怎么样？」[rhp]

[:vulpecula:][p_vl_08][peku kao=13 ]
「嗯——！超级开心！[rhr]
《银河铁道之夜》的事，博士也都全部告诉我了！」[rhp]

[:sausu:][p_s_18][sausu kao=11 ]
「博士的解说太精彩了，我都没派上用场呢」[rhp]

[:vulpecula:][peku kao=14 ]
「呐！接下来就只剩下肯陶尔的谜题了！那个连博士[rhr]
_　说实际乘坐银河铁道也搞不明白呢」[rhp]
[:vulpecula:]
「呐博士。下次就去解开那个谜题——」[rhp]

[off_all]

[:hirosi:][hiro kao=0 ]
「…………、…………」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:]
「……睡着了！」[rhp]

[:sausu:][sausu kao=13 ]
「睡得很熟呢」[rhp]

[:vulpecula:][p_vl_13][peku kao=7 ]
「还在银河铁道上吗？」[rhp]

[:sausu:][sausu kao=14 ]
「不。这种黎明时分叫醒也太可怜了，[rhr]
_　就让他继续睡吧」[rhp]

[:vulpecula:][p_vl_19][peku kao=7 ]
「？那刚才看到的，是梦吗？」[rhp]

[:sausu:][sausu kao=3 as=on ]
「倒也不是那样……」[rhr]
_　……嗯—，因为这是稍微有点复杂的结构话题呢」[rhp]
[:sausu:][sausu kao=13 ]
「等博士醒来时再解释吧，[rhr]
_　之后让他详细地掰碎说明就好啦」[rhp]

[:vulpecula:][peku kao=13 as=on ]
「明白啦！南看起来就不擅长解释呢」[rhp]
[:vulpecula:]
「……嗯—！总觉得博库也有点累了呢」[rhp]

[:sausu:][sausu kao=11 ]
「毕竟经历了这么多冒险。你也该休息了」[rhp]

[:vulpecula:][p_vl_24][peku kao=14 ]
「南也快睡吧。毕竟是大叔了嘛」[rhp]

[:sausu:][sausu kao=2 ]
「我说啊。按年龄我可比你小哦？」[rhp]

[off_all]

[:vulpecula:][peku kao=11 hh=on ]
「晚安—！明天见……不对、今天见～！」[rhp]

[off_all]

[:sausu:][sausu kao=11 ]
「根本没在听呢……好好、晚安」[rhp]

[off_all]

[:sausu:]
「…………好了」[rhp]

[:hirosi:][hiro kao=1 ]
「……………………」[rhp]

[off_all]

[:sausu:][sausu kao=13 ]
「呵呵……真是安详的睡颜啊」[rhp]
[:sausu:]
「…………借用那片星空，实在是值得」[rhp]

[off_all]

;****************************************
#
[bg storage="sky_13.jpg" time=1500]
;****************************************

[::]
你的愿望，共有三个。[rhp]
『希望永远能当大家的哥哥』。[rhr]
『希望病情不要再恶化』。[rhp]
其中两个不需要我插手，你已凭自己力量实现。[rhp]
然后是有问题的，最后一个。[rhp]
『至少死后，能被邀请乘坐银河铁道』……[rhp]

[:sausu:]
「…………尽管交给我」[rhp]

[::]
老实说，目前还没有头绪。[rhr]
虽然我是千纸鹤的神明，但并非全知全能。[rhp]
况且……预设死亡而筹划的魔法什么的。[rhp]

[:sausu:]
[font color=0x4682b4]
（……我会努力的）[rhp]
[resetfont]

[::]
若这便是你的幸福。[rhp]

;****************************************
[fbgm]
[set_ff storage="sky_02.jpg"]
;****************************************

翌日清晨。[rhp]

;****************************************
[bg storage="hsps_09.jpg" time=1500]
[bgm storage="bgm_15.ogg"]
;****************************************


[se storage="door_13.ogg"]
[rhp]

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
[vostart]
;--------------------------------------------------------------------------------------------

[:hirosi:][hiro kao=1 ]
「好的」[rhp]

;扉が開く
[se storage="door_07.ogg"]

[:tiaki:][tiaki kao=13 ]
「早上好，浩君。该测体温了」[rhp]

[off_all]

[:hirosi:][hiro kao=1 ]
「米卡小姐，早上好」[rhp]

[off_all]

[chara_part name="hiro" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:]
「哎呀？今天看起来心情不错呢」[rhp]

[:hirosi:][hiro kao=7 as=on ]
「是吗？……话说我平时看起来总那么不高兴吗？」[rhp]

[:tiaki:][tiaki kao=5 hh=on ]
「不，不是那样的。[rhr]
_　总觉得嗓音比平时稍稍明朗了些」[rhp]

[:hirosi:][hiro kao=1 hh=on ]
「嘿嘿……可能是吧」[rhp]

[off_all]

;****************************************
;スチル
[still storage="cg/b1_3.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/b1_3.png"]
;****************************************

[:hirosi:]
「……因为做了个特别棒的梦」[rhp]

[:tiaki:]
「嘿。什么样的梦？」[rhp]

[:hirosi:]
「我误入了《银河铁道之夜》的舞台。[rhr]
_　和朋友们一起冒险了」[rhp]
[:hirosi:]
「啊、那个……关于是谁之类的……不太好说出口……」[rhp]

[:tiaki:]
「真是太美妙了。你一直最喜欢这个故事呢，浩君」[rhp]

[:hirosi:]
「嗯！所以特别开心」[rhp]

[:tiaki:]
「说不定是千纸鹤替你实现的愿望哦」[rhp]

;****************************************
#
[bg storage="cg/b1_3b.png" width="1280" height="720" time=500]
[cg storage="cg/b1_3b.png"]
;****************************************

[:hirosi:]
「诶……」[rhp]
[:hirosi:]
「您在说什么？」[rhp]

[:tiaki:]
「……诶……」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:hirosi:]
「………？」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:hirosi:]
「……！啊……是指这个吗，床头边的」[rhp]

;****************************************
#
[bg storage="cg/b1_3c.png" width="1280" height="720" time=500]
[cg storage="cg/b1_3c.png"]
;****************************************

[:hirosi:]
「多亏它我才能做这么美的梦。[rhr]
_　得好好道谢才行」[rhp]

[:tiaki:]
「浩君……难道你……」[rhp]

[:hirosi:]
「那个，不好意思……」[rhp]
[:hirosi:]
「…………这个，是谁送的礼物来着？」[rhp]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
#
[s_mask color=0x000000 time=2000]
[bg storage="hsps_09n.jpg" time=100]
; ウィンドゥの設定
[position layer="message0" frame="win2.png" left=0 top=520 width=1280 height=200 page=fore visible=true ]
[s_mask_off time=2000]
;****************************************

[::]
――――他的病情不断恶化。[rhp]

关于千纸鹤的事，以及身为付丧神的我的事。[rhp]
矢部医生，米卡小姐。[rhr]
临终关怀院的孩子们。[rhp]
…………以及，沃尔佩克拉的事。[rhp]

;****************************************
[bg storage="hsps_09.jpg" time=1000]
[filter layer="1" name="peku" opacity=50]
[filter layer="1" name="sausu" opacity=50]
;****************************************

[:vulpecula:][peku kao=4 as=on ]
「………………诶？」[rhp]

[off_all]

[:hirosi:][p_hr_31][hiro kao=1 ]
「初次见面。是新来的孩子吗？」[rhp]
[:hirosi:]
「我是浩。大家都叫我博士，所以你也可以……」[rhp]

[off_all]

[:vulpecula:][peku kao=3 as=on ]
「………………」[rhp]

[:hirosi:][hiro kao=1  as=on ]
「……？咦……奇怪，」[rhp]

[:vulpecula:][peku kao=3 as=on ]
「………………不认得」[rhp]

[:hirosi:][hiro kao=3 ]
「？啊……」[rhp]

[off_all]

[yurasu]

[:vulpecula:][peku kao=2 as=on ]
[font size=30]
「不认得！！」[rhp]
[resetfont]

[off_all]
[:hirosi:][hiro kao=4 ]
「！」[rhp]

[off_all]

[:vulpecula:][peku kao=3 as=on ]
「不认得、不认得！把博库忘掉的博士什么的……！」[rhp]
[:vulpecula:]
「……那样的才不是博士！！」[rhp]

[:hirosi:][hiro kao=4 as=on ]
「呜……！」[rhp]
[:hirosi:][hiro kao=0 as=on ]
「………………？」[rhp]

[off_all]

[se storage="door_07.ogg"]

[:tiaki:][p_mk_35][tiaki kao=1 ]
「浩君？走廊好像有声音……」[rhp]

[:hirosi:][p_hr_12][hiro kao=7 as=on ]
「啊，没有……」[rhp]
[:hirosi:]
「…………？刚才在说什么来着」[rhp]

[off_all]

[:sausu:][sausu kao=0 ]
「………………」[rhp]

[off_all]

[:hirosi:][hiro kao=1 as=on ]
「啊！不好意思，是您来着吧。那个……」[rhp]

[off_all]

[chara_part name="hiro" body=base kao=4 as=on ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=0 as=on ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:][p_mk_04]
「浩、浩君。那里没有人哦。米卡亲在这边啦」[rhp]

[:hirosi:][p_hr_11][hiro kao=4 as=on ]
「咦，不对。这里有团蓬松头发的……」[rhp]

[off_all]

[:hirosi:]
「…………咦？　不在了」[rhp]

;****************************************
#
[bg_rule storage="hsps_07.jpg" rule="007.png" time=1000]
;****************************************

[:sausu:]
「…………理所当然啊」[rhp]
[:sausu:]
[font color=0x4682b4]
（既然已经忘了我，那我被视作陌生人也是……）[rhp]
[resetfont]

[off_all]

;****************************************
[bg_rule storage="hsps_07.jpg" rule="002.png" time=500]
;****************************************

[:vulpecula:][peku kao=3 ]
「…………」[rhp]

[:sausu:][sausu kao=4 as=on ]
「！　沃尔佩克拉……」[rhp]

[:vulpecula:][peku kao=3 ]
「………………干嘛啦」[rhp]

[:sausu:][sausu kao=1 ]
「……唔嗯。……，……好久不见了呢」[rhp]
[:sausu:]
「虽然不进房间……但你每天都会来吧」[rhp]

[:vulpecula:]
「……………………」[rhp]

[:sausu:][sausu kao=3 ]
「……还在为被忘记的事生气吗」[rhp]

[:vulpecula:]
「……才没有呢……」[rhp]

[:sausu:][sausu kao=13 ]
「―――……啊哈哈！说起来啊。[rhr]
_　前不久，连我也终于被忘记了呢。真过分啊」[rhp]
[:sausu:]
「这下我们成同伴啦，沃尔佩克拉。悲伤的不只你一个哦」[rhp]

[:vulpecula:]
「……………………」[rhp]

[:sausu:][sausu kao=3 as=on ]
「……、不行吗……」[rhp]
[:sausu:][sausu kao=8 as=on ]
「…………没关系的。总会因为某个契机想起来，」[rhp]

[:vulpecula:]
「不知道」[rhp]

[:sausu:][sausu kao=4 ]
「……！」[rhp]

[:vulpecula:]
「…………我明明是博士最要好的朋友。[rhr]
_　明明说过无论发生什么，都绝对不会忘记我的」[rhp]
[:vulpecula:]
「骗子……！我也早就、不认识什么博士了……！」[rhp]

[:sausu:][sausu kao=2 as=on ]
「沃尔佩克拉……别说这种话」[rhp]
[:sausu:]
「就算博士忘了，你不是说要让他想起来吗？[rhr]
_　以前不是这么说过吗……」[rhp]

[:vulpecula:][peku kao=2 ]
「不要」[rhp]

[:sausu:][sausu kao=8 as=on ]
「沃尔佩克拉……」[rhp]

[:vulpecula:][peku kao=2 as=on ]
「已经不想再见到什么博士了……！[rhr]
_　就算教再多东西，反正最后都会全部忘掉吧？」[rhp]
[:vulpecula:]
「快乐的事也好，开心的事也好，珍宝也好，约定也好……！[rhr]
_　全部全部都要被弄到不知哪里去了对吧！？[rhp]
[:vulpecula:]
「为什么那种心情非得经历两次不可啊！[rhr]
_　既然如此还不如干脆讨厌博士算了，这样反而更好啦！」[rhp]

[off_all]

[:vulpecula:][peku kao=3 ]
「博士这个大骗子……！　明明说过要一起散步的！[rhr]
_　明明说过想见见博库的爸爸和妈妈的……！」[rhp]
[:vulpecula:]
「已经……已经全都，做不到了啊……！」[rhp]

[off_all]

[:sausu:][sausu kao=0 ]
「………………」[rhp]

[off_all]

[:vulpecula:]
「……呜……抽泣……」[rhp]

;****************************************
#
[bg storage="sky_06b.jpg" ime=1000]
;****************************************

[::]
…………根本不了解我们的心意，[rhr]
回忆正从博士的脑海中平静地流逝。[rhp]
真是薄情啊。曾经那般愤怒的沃尔佩克拉，[rhr]
理应和她同样深受打击的我，没过几天就连眼泪都流不出来了。[rhp]

或许我们早已停止了思考。[rhr]
既然阻止不了病症，烦恼只是徒劳，徒增痛苦而已。[rhp]
那绝非朋友之间的相处之道，[rhr]
但我既没有责备沃尔佩克拉，她也没有反过来责备我。[rhp]

彼此都明白对方的创伤有多深。[rhr]
那个天真又残酷的『初次见面』，光是回想就让人渗出血来。[rhp]

;****************************************
[set_kk storage="hsps_09.jpg" time=1000]
;****************************************

或许连对死亡的不安都已忘却，博士变得比从前开朗许多。[rhp]
如同填补残缺知识般对万物充满好奇的他，最爱将图鉴作为枕边读物。[rhr]
比起以往钟爱的文字书籍，似乎照片和图解更容易印入脑海。[rhp]
就像初次触摸世界那般，他的眼眸每次翻页时都闪耀着光芒。[rhp]
但到了次日，这份感动便消逝无踪。[rhr]
如同日升日落周而复始，不过是一场无尽的轮回。[rhp]
他的眼睛，始终燃烧着对未知的好奇光芒。[rhp]

;****************************************
[set_ff color=0xffffff storage="white.jpg" time=1000]
;****************************************

直到那一天。[rhp]
距那段银河之旅过去将近一月之时。[rhp]
他连如何跳动心脏都忘却了。[rhp]

;****************************************
[fbgm]
[set_n storage="hsps_09n.jpg"]
[bgm storage="bgm_09.ogg"]
;****************************************

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
[vostart]
;--------------------------------------------------------------------------------------------

[:vulpecula:][peku kao=1 ]
「……房间好像变宽敞了呢」[rhp]
[:vulpecula:][peku kao=13 ]
「嘿嘿，没想到博士还挺高大的。[rhr]
_　明明瘦得像竹竿来着」[rhp]

[off_all]
;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:sausu:][sausu kao=3 ]
「…………………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[chara_part name="sausu" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=3 as=on ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:]
「……南～打起精神嘛。[rhr]
_　虽然博士不在确实很寂寞啦」[rhp]
[:vulpecula:]
「可就算我们消沉下去，博士也——」[rhp]

[:sausu:][sausu kao=3 ]
「………………什么都做不了」[rhp]

[:vulpecula:]
「诶……」[rhp]

[:sausu:]
「我是千纸鹤。实现制作者的愿望就是使命」[rhp]
[:sausu:]
「………………可我，什么都没能」[rhp]

[:vulpecula:][peku kao=2 ]
「才、才没有这回事！你不是带我们坐了银河铁道吗」[rhp]

[:sausu:][sausu kao=3 ]
「只是带路而已。他期盼的并非如此」[rhp]
[:sausu:]
「『至少死后能被邀请乘坐银河铁道』。[rhr]
_　他曾这样祈愿。可我却没能实现它……！」[rhp]

[:vulpecula:][peku kao=3 ]
「……？　既、既然都死了……这次总该能实现了吧……」[rhp]

[:sausu:][sausu kao=7 ]
「实现不了。……死后的世界不过是童话」[rhp]
[:sausu:]
「死后哪里都去不了。[rhr]
_　要么像你一样漫无目的地漂泊，要么彻底转生成另一个人」[rhp]
[:sausu:]
「一旦迷失，我就再没有辨别的方法了」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:vulpecula:][peku kao=8 as=on ]
「………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sausu:][sausu kao=3 ]
「……其实不是没有实现。[rhr]
_　只是不知道该怎样才能实现」[rhp]
[:sausu:]
「蒙混过去了。因为不想让他失望。[rhr]
_　明明是承载祈愿的千纸鹤，却不愿被看作什么都做不到」[rhp]

[:vulpecula:][peku kao=3 ]
「南……」[rhp]

[:sausu:][sausu kao=8 ]
「……到底该怎么办才好。[rhr]
_　怎样才能实现他的愿望呢……」[rhp]

[:vulpecula:]
「……呜、那、那个」[rhp]
[:vulpecula:]
「要不，造个博士出来？」[rhp]

[:sausu:][sausu kao=4 ]
「……哈？」[rhp]

[:vulpecula:][peku kao=5 ]
「就像用这里孩子们为原型创造公主们那样，[rhr]
_　模仿博士的样子，造个博士出来呀」[rhp]
[:vulpecula:]
「记忆里的博士，总是精神饱满地笑着。[rhr]
_　……所以博士还没有真正死去」[rhp]
[:vulpecula:]
「用博库和南的记忆来创造，[rhr]
_　把笑容最灿烂的博士邀请到那个世界吧」[rhp]

[:sausu:][sausu kao=3 ]
「……这样你就满足了吗」[rhp]

[:vulpecula:][peku kao=13 ]
「嗯。就算不是真正的博士也没关系，[rhr]
_　想和博士继续玩耍。还有……」[rhp]

[off_all]

;****************************************
;スチル
[still storage="cg/b1_4.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/b1_4.png"]
;****************************************

[:vulpecula:]
「……想向博士道歉」[rhp]

[:sausu:]
「道歉……？」[rhp]

[:vulpecula:]
「……博库对博士太冷淡了。[rhr]
_　被问『你是谁？』的时候，又伤心又懊悔……」[rhp]
[:vulpecula:]
「因为害怕再次听到同样的话，一直不敢去见他……[rhr]
_　连朋友的事、最爱的银河铁道故事都忘记了，明明他可能很寂寞」[rhp]
[:vulpecula:]
「……明明约定过的。如果博士忘记最喜欢的东西，[rhr]
_　博库会帮他回忆起来的……」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:sausu:]
「………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:vulpecula:]
「本该无数次地告诉他。[rhr]
_　博库的名字是沃尔佩克拉……是博士命名的小狐狸哦」[rhp]
[:vulpecula:]
「就算是多少次重新相识，我们也一定能成为好朋友的」[rhp]
[:vulpecula:]
「…………想好好为这些事道歉」[rhp]

[:sausu:]
「……沃尔佩克拉……」[rhp]

[:vulpecula:]
「这次会和不认识的博士好好相处」[rhp]
[:vulpecula:]
「所以……再也不要一个人了……」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:sausu:]
「………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

;****************************************
;スチル終了
[still_end frame="win2.png" storage="hsps_09n.jpg" time=1000]
;****************************************

[:sausu:][sausu kao=1 ]
「……………………明白了」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=0 as=on ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:sausu:]
「就采用你的方案吧。[rhr]
_　……这至少是对未能实现他愿望的补偿」[rhp]

[:vulpecula:][peku kao=1 ]
「南……！嗯，嗯！这样最好了！」[rhp]

[:sausu:][sausu kao=1 ]
「你也住在那里吗」[rhp]

[:vulpecula:][peku kao=4 ]
「！　那里指的是……银河铁道是梦境世界吧？」[rhp]

[:sausu:][sausu kao=8 ]
「严格来说并非如此。……即便详细说明[rhr]
_　你大概也无法理解吧」[rhp]
[:sausu:]
「因为是幽灵所以不受肉体束缚[rhr]
_　你肯定能在『那里』活下去的」[rhp]

[:vulpecula:][peku kao=4 ]
「……？不、不太明白……」[rhp]

[:sausu:][sausu kao=1 ]
「不必想得太复杂。……简而言之」[rhp]
[:sausu:]
「要和新博士一起乘银河铁道旅行[rhr]
_　还是留在这里徘徊于没有博士的世界」[rhp]
[:sausu:]
「希望你能选择。选能让你幸福的选项」[rhp]

[:vulpecula:][peku kao=7 ]
「……博库的……幸福……？」[rhp]

[:sausu:][sausu kao=11 ]
「我会好好实现的。……虽说你并未折过纸鹤」[rhp]
[:sausu:]
「但你是我的挚友」[rhp]

[:vulpecula:][peku kao=3 ]
「…………银河铁道会有南来吗？」[rhp]

[:sausu:][sausu kao=0 ]
「我不去」[rhp]

[:vulpecula:][peku kao=2 ]
「为、为什么？没有南一起的话我不要[rhr]
_　我们三人不是挚友吗」[rhp]

[:sausu:][sausu kao=11 ]
「真令人欣慰啊。……但有些事无可奈何」[rhp]
[:sausu:]
「我还有必须完成的事」[rhp]

[:vulpecula:][peku kao=3 ]
「但是……」[rhp]

[:sausu:][sausu kao=13 ]
「看你露出这种表情我很开心[rhr]
_　博库也会因为没有沃尔佩克拉而感到寂寞」[rhp]
[:sausu:]
「但不要因顾虑我而放弃博士的事」[rhp]
[:sausu:]
「我也希望你和博士能和好。[rhr]
_　为了我，你也请坐上银河铁道吧」[rhp]

[:vulpecula:][peku kao=3 ]
「…………、呜……」[rhp]

[:sausu:][sausu kao=1 ]
「又不是永远分离。我也会偶尔去找你们玩的」[rhp]

[:vulpecula:][peku kao=6 ]
「真的吗？　我们三个人还能一起去探险？」[rhp]

[:sausu:][sausu kao=13 ]
「当然可以。这是约定」[rhp]

[off_all]

[:sausu:][sausu kao=5 ]
「你尽管期待吧。[rhr]
_　你们的旅程，一定会成为最棒的体验。我敢保证」[rhp]
[:sausu:]
「……一路顺风。沃尔佩克拉」[rhp]

;****************************************

#
[fbgm]
[s_mask color=0xffffff time=2000]
[off_all]
[se storage="mag_03.ogg"]
; 背景表示
[bg storage="train_01.jpg" time=100]
; フィルター解除
[free_filter ]
; ウィンドゥの設定
[position layer="message0" frame="win.png" left=0 top=520 width=1280 height=200 page=fore visible=true ]
[s_mask_off time=2000]

[bgm storage="bgm_13.ogg"]
;****************************************

;------------------------------------------------------------------------------------------
;▼再開▼
[voconfig sebuf=1 name=peku vostorage="peku/full/{number}.ogg" number=166]
[vostart]
;------------------------------------------------------------------------------------------

[:vulpecula:][peku kao=6 ]
「呃……！」[rhp]

[:vulpecula:][peku kao=7 as=on ]
「……、……到了……？」[rhp]

[off_all]

[:vulpecula:]
「和以前一样。许多椅子和窗户，狭长的房间……」[rhp]
[:vulpecula:]
「…………但是，博士在哪里……？」[rhp]

[:princess:][puri kao=1 ]
「佩库拉酱」[rhp]

[:vulpecula:][peku kao=4 ]
「！　公主……」[rhp]

[:princess:][puri kao=11 ]
「南已经告诉我了。……你要来了呢。来到这个世界」[rhp]

[:vulpecula:][peku kao=3 ]
「嗯，嗯」[rhp]

[:princess:][puri kao=1 ]
「非常欢迎。欢迎来到银河铁道」[rhp]

[:vulpecula:][peku kao=7 ]
「…………博士，在吗？」[rhp]

[:princess:][puri kao=13 ]
「嗯，在的」[rhp]

[:vulpecula:][peku kao=4 ]
「――――！」[rhp]

[:princess:][puri kao=14 ]
「刚才还出现了。现在应该在观景车厢看星星吧」[rhp]
[:princess:]
「他也在等着你，快去――――」[rhp]

[off_all]

[:princess:][puri kao=1 as=on ]
「啊哈哈……、这话好像多余了呢」[rhp]

[off_all]

;****************************************
[bg_rule storage="train_05.jpg" rule="002.png" time=1500]
;****************************************

[:vulpecula:][peku kao=3 as=on ]
「博士！！」[rhp]

[off_all]

[:darknebula:][hakase kao=4 msk=hat ]
「哎呀？」[rhp]

[off_all]

[:vulpecula:][peku kao=3 ]
「……！　博……」[rhp]

[off_all]

[chara_part name="hakase" body=base kao=1 as=off ss=off hh=off hr=on msk=hat ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=4 as=on ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:darknebula:]
「沃尔佩克拉！」[rhp]

[:vulpecula:][peku kao=4 hh=on ]
「―――……！　啊……」[rhp]

[:darknebula:][hakase kao=8 msk=hat ]
「你去哪里了？我一直在找你」[rhp]

[:vulpecula:][peku kao=3 hh=on ]
「………………啊」[rhp]

[:darknebula:][hakase kao=4 as=on msk=hat ]
「？　这副表情是怎么……」[rhp]

[off_all]

;****************************************
;スチル
[still storage="cg/b1_5.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/b1_5.png"]
;****************************************

[:vulpecula:]
「博士！！！！」[rhp]

[:darknebula:]
「哇！　等等……！　突、突然怎么了？」[rhp]

[:vulpecula:]
「哇啊――――嗯！！博士～～～啊！」[rhp]

[:darknebula:]
「？？　我就是博士啊……？」[rhp]

[:vulpecula:]
「呜哇啊啊啊……！　博士、对不起……！」[rhp]

[:darknebula:]
「咦？　咦？」[rhp]

[:vulpecula:]
「博库、是个讨厌鬼对吧？[rhr]
_　任性妄为对不起……！　全都是博库的错啦」[rhp]
[:vulpecula:]
「明明不管怎样的博士都可以的。就算博士忘了博库，[rhr]
_　只要博库最喜欢博士就够了的……！」[rhp]
[:vulpecula:]
「博士是博库最重要、最喜欢的朋友，也是哥哥啊……！」[rhp]
[:vulpecula:]
「以后再也不使坏了，可以永远在一起吗？[rhr]
_　这次绝对、绝对不让博士孤零零一个人了！」[rhp]

[:darknebula:]
「……？　可以是可以，但我没被使过坏啊」[rhp]

[:vulpecula:]
「太过分啦！！真的太过分啦！居然无视人家！」[rhp]
[:vulpecula:]
「抽泣……！」[rhp]

[:darknebula:]
「那个……这、这可难办了」[rhp]
[:darknebula:]
「本来以为只是像往常一样在旅行，[rhr]
_　结果突然说些奇怪的话」[rhp]

;****************************************
#
[bg storage="cg/b1_5b.png" width="1280" height="720" time=500]
[cg storage="cg/b1_5b.png"]
;****************************************

[:vulpecula:]
「……？　……和往常一样……？」[rhp]

[:darknebula:]
「我们该不会已经在这银河中旅行了非常非常漫长的时光吧」[rhp]
[:darknebula:]
「为了解开『让肯陶尔降下露水』这个暗号啊」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:vulpecula:]
「…………！」[rhp]
[:vulpecula:]
[font color=0x4682b4]
（…………是南）[rhp]
[resetfont]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:vulpecula:]
「……肯定是的。是南，把故事变成这样的……[rhr]
_　把痛苦的事，全部消除掉……」[rhp]
[:vulpecula:]
「………………。让博士成为了最想成为的博士」[rhp]

[:darknebula:]
「南？」[rhp]
[:darknebula:]
「……南是你的朋友吗？」[rhp]

;****************************************
#
[bg storage="cg/b1_5c.png" width="1280" height="720" time=500]
[cg storage="cg/b1_5c.png"]
;****************************************

[:vulpecula:]
「……！　……但连自己的事都让人忘记也太过分了吧」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:darknebula:]
「？」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:vulpecula:]
「――――不，没什么」[rhp]

;****************************************
#
[bg storage="cg/b1_5d.png" width="1280" height="720" time=500]
[cg storage="cg/b1_5d.png"]
;****************************************

[:vulpecula:]
「南啊。是博库的朋友。……总有一天会介绍给博士认识的！」[rhp]

[:darknebula:]
「知道了。我会期待着的」[rhp]

[:vulpecula:]
「听我说博士。现在的博士是超级幸福的博士哦！」[rhp]
[:vulpecula:]
「博库一直一直，都想要见到这样的博士！[rhr]
_　所以现在，博库也和博士一样幸福呢！」[rhp]

[:darknebula:]
「虽然听不懂在说什么……不过幸福是好事」[rhp]

[:vulpecula:]
「博库是沃尔佩克拉……不对，是佩奇！[rhr]
_　这次可一定要记住哦」[rhp]

[:darknebula:]
「小狐狸座？」[rhp]

[:vulpecula:]
「叫我佩奇就好！这样更容易记住吧」[rhp]
[:vulpecula:]
「这次绝对不会再让你忘记啦！」[rhp]

[:darknebula:]
「知、知道啦。……佩奇？」[rhp]

[:vulpecula:]
「真乖！真是让人操心的哥哥呢……」[rhp]
[:vulpecula:]
「……对不起啊博士。最喜欢博士了！[rhr]
_　从今往后，我们要永远永远在一起哦！」[rhp]

[:darknebula:]
「呵呵，这不是理所当然的吗。[rhr]
_　哪有研究者会丢下助手独自离开的」[rhp]

[:vulpecula:]
「嘿嘿……！没有呢！哪里都不会去啦！」[rhp]

;****************************************
;スチル終了
[still_end frame="win.png" storage="sky_11.jpg" time=1000]
;****************************************

[:vulpecula:]
「来吧！今天开始银河大冒险咯！[rhr]
_　要让南后悔没和我们一起来！」[rhp]
[:vulpecula:]
「无论多远都要一起走下去。[rhr]
直到解开『肯陶尔』之谜为止！」[rhp]
[:vulpecula:]
「对吧，博士！」[rhp]

[:darknebula:]
「啊啊！」[rhp]

;****************************************
[fbgm]

#
[s_mask color=0xffffff time=3000]
; 背景表示
[bg storage="sky_02.jpg" time=100]
; ウィンドゥの設定
[position layer="message0" frame="win2.png" left=0 top=520 width=1280 height=200 page=fore visible=true ]
[s_mask_off time=3000]

[bgm storage="bgm_35.ogg"]
;****************************************

―――沃尔佩克拉现在应该已经和博士和好了吧。[rhp]
虽然把原本的他稍微调整得接近他心中的理想形象，[rhr]
但如果是她的话一定能相处得很好。[rhp]
这正是她的过人之处。[rhr]
即使在博士临终时，那份开朗也深深拯救了我。[rhp]
……虽说惭愧得没脸再站在他身旁了。[rhp]

;****************************************
[bg storage="black.jpg" time=1000]
;****************************************

这个世界对努力者很残酷。[rhp]
永远的幸福并不存在。[rhr]
不幸的人会不幸到底。[rhp]
无法使用魔法。[rhr]
奇迹不会发生。[rhp]
无论如何挣扎，命运都是绝对的。[rhp]

……所以我才思考。[rhp]
把你们带往真正幸福世界的方法。[rhp]

;****************************************
;スチル
[still storage="cg/b1_6.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/b1_6.png"]
;****************************************

[:sausu:]
「……没能赶上真是抱歉」[rhp]

[::]
博士。你的愿望我一个都没能实现。[rhp]
所以至少从今往后，包括以你为原型创造的『他』在内，[rhr]
我打算全力以赴实现『他们』的愿望。[rhp]
因为我的存在不仅源于你，[rhr]
更是由这里孩子们的愿望构筑而成。[rhp]

『希望疾病痊愈。』[rhp]
『希望能自由行走。』[rhp]
『希望药能变好吃。』[rhp]
『希望永远快乐生活。』[rhp]

这些全由我来实现。[rhr]
为此我构想出了魔法。[rhp]

[:sausu:]
「要做的事堆积如山……」[rhp]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

[::]
但现在，我为此感到欣喜。[rhp]
真的太好了。[rhr]
总算得到了救赎。[rhp]
存在的意义就在于此。[rhp]
必须确保不再迷失方向。[rhp]

;****************************************
;スチル終了
[still_end frame="win2.png" storage="black.jpg" time=2000]
;****************************************

听起来像借口吗？[rhp]
确实如此。[rhr]
因为我在拼命啊。[rhp]
……无法实现愿望的千纸鹤，不过是一堆废纸罢了。[rhp]

;****************************************
[s_mask time=4000]

;エンドフラグ
[eval exp="sf.b1_end = 1"]

[cancelskip]
[fbgm]

[jump storage="title.ks" target="*start_end"]

[s]