﻿*start
;--------------------------------------------------------------------------------------------
;▼フルボイスセット▼
;ドロップ
[voconfig sebuf=1 name=drop vostorage="drop/full/{number}.ogg" number=48]
;カイト
[voconfig sebuf=1 name=kite vostorage="kite/full/{number}.ogg" number=59]
;クォードリリオン
[voconfig sebuf=1 name=riri vostorage="riri/full/{number}.ogg" number=28]
;ハートシェイプ
[voconfig sebuf=1 name=hati vostorage="hati/full/{number}.ogg" number=49]
;ジェット
[voconfig sebuf=1 name=jet vostorage="jet/full/{number}.ogg" number=39]
;ダークネブラ
[voconfig sebuf=1 name=hakase vostorage="hakase/full/{number}.ogg" number=15]
;ヴルペクラ
[voconfig sebuf=1 name=peku vostorage="peku/full/{number}.ogg" number=27]
;ヤブ医者
[voconfig sebuf=1 name=yabu vostorage="yabu/full/{number}.ogg" number=45]
;ミカちん
[voconfig sebuf=1 name=mika vostorage="mika/full/{number}.ogg" number=42]
;サウス
[voconfig sebuf=1 name=sausu vostorage="sausu/full/{number}.ogg" number=84]

;--------------------------------------------------------------------------------------------


;****************************************
[fbgm]
[set_b storage="sky_15.jpg" time=3000]
;****************************************

[bgm storage="bgm_24.ogg"]

[::]
到达下一个旅行目的地的我们。[rhr]
这次是应夸德里利昂的要求来到海边。[rhp]

;****************************************
[set_b color=0xffffff storage="sea_01.jpg"]
;****************************************

白色的沙滩，平静的海浪。[rhr]
这就是所谓的度假胜地……！[rhp]

[:quadrillion:][p_r_31][riri body=mizugi kao=14 ]
「太棒了～！果然大人度假就该来海边呢」[rhp]

[:jet:][p_j_29][jet body=mizugi kao=6 ]
「没想到克林还挺喜欢老套的地方啊。[rhr]
_　上次的乌尤尼也是那样」[rhp]

[:quadrillion:][p_r_09][riri body=mizugi kao=5 ]
「吵死了啦。有什么关系嘛真是的」[rhp]
[:quadrillion:]
「谢谢你多洛普。虽然只是模糊地说了想度假看海，[rhr]
_　你却带我们来到这么棒的地方」[rhp]

[off_all]

[:drop:][p_d_02][drop kao=13 ]
「您能满意是我的荣幸。请尽情享受吧！」[rhp]

;-------------------------------------------------------------
[if exp="f.ev02_drop == 1 "]

[:princess:][puri_w body=mizugi kao=6 ]
「真是的～……！难道多洛普这次又要留在车里？」[rhp]

[:drop:][p_d_01][drop kao=11 ]
「是的。每日的保养绝不能懈怠」[rhp]

[:princess:][puri_w body=mizugi kao=2 as=on ]
「又来！？这样可不好！」[rhp]

[jump target="*tutti0"]
[endif] 
;-------------------------------------------------------------

[:princess:][puri_w body=mizugi kao=4 as=on ]
「咦。不是说要玩得开心吗……」[rhp]

[:drop:][p_d_02][drop kao=11 ]
「我会留在车内。每日的保养绝不能懈怠」[rhp]
[:drop:]
「上次去游乐园时也是这样。[rhr]
_　或者说，我基本上每次都在这里留守……」[rhp]

[:princess:][puri_w body=mizugi kao=2 as=on ]
「哈、哈啊！？什么啊这！太奇怪了吧！？」[rhp]

*tutti0

[off_all]

[chara_part name="drop" body=base kao=0 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="kite" body=mizugi kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time="150"]

[:kite:][p_k_30]
「这种天气下熄火的车厢，光想象就觉得像地狱……」[rhp]

[:drop:][drop kao=2 as=on ]
「呜……那、那个」[rhp]

[off_all]

[chara_part name="hakase" body=mizugi kao=0 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time="150"]
[chara_part name="jet" body=mizugi kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:darknebula:][p_da_09][hakase body=mizugi msk=off kao=0 ]
「不要勉强自己。[rhr]
_　你要是中暑倒下了谁来开那辆铁道啊？」[rhp]

[:jet:][p_j_04][jet body=mizugi kao=8 ]
「虽然我们也算是列车员啦」[rhp]

[yurasu]
[:darknebula:][hakase body=mizugi msk=off kao=2 as=on ]
[font size=28]
「到底谁来开车啊！」[rhp]
[resetfont]

[off_all]

[:drop:][p_d_17][drop kao=2 as=on ]
「……博士说得对，我的确不能倒下」[rhp]
[:drop:]
「没办法。[rhr]
_　今天就破例和大家一起去吧……！」[rhp]

[:princess:][puri_w body=mizugi kao=6 ]
「这就对啦！不如说本该如此！」[rhp]

[off_all]

[chara_part name="jet" body=mizugi kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="peku" body=mizugi kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time="150"]

[:vulpecula:][p_vl_06]
「太好啦！那今天大家就一起行动咯！」[rhp]

[:jet:][p_j_31]
「带泳装了吗？[rhr]
_　我看到克林连多洛普那份都准备了」[rhp]

[off_all]

[:drop:][drop ]
「不，毕竟不能太放纵。[rhr]
_　幸好穿着短袖，我就这样也没问题」[rhp]

[off_drop]

[chara_part name="riri" body=mizugi kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time="150"]
[chara_part name="kite" body=mizugi kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time="150"]

[:quadrillion:][p_r_17]
「真可惜呀。人家特意精心挑选的说」[rhp]

[:kite:][kite body=mizugi kao=2 as=on ss=on ]
「……………………」[rhp]

[:quadrillion:][riri kao=2 body=mizugi ]
「……你丫别老用看人妖的眼神看我」[rhp]
[:quadrillion:]
「再说一遍，老子可是正经男人。[rhr]
_　对男人的身体一丁点兴趣都没有。今天也——」[rhp]

[:kite:][kite body=mizugi kao=6 ]
「今天也？」[rhp]

[:quadrillion:][riri body=mizugi kao=14 as=on ]
「！！啊不是……没、没什么啦。呵呵呵！」[rhp]

[off_all]

[:quadrillion:][riri body=mizugi kao=14 as=on ]
「来！除了多洛普都换好衣服了吧？[rhr]
_　出发咯，去往魅惑的白沙滩！」[rhp]


[off_riri]

[:princess:][puri_w body=mizugi ]
「克林今天异常兴奋呢。[rhr]
_　原来你这么喜欢海吗？」[rhp]

[:heartshape:][p_h_05][hati body=mizugi kao=6 ]
「不对啊公主。那家伙真正喜欢的根本不是大海。[rhr]
_　但那是与你完全无缘的东西！！」[rhp]
[:heartshape:][hati body=mizugi kao=3 as=on ]
「咕！别再让我……！继续说下去了啊啊！！」[rhp]

[:princess:][puri_w body=mizugi kao=2 as=on ]
「！？原来如此……！我没有的东西，就是记忆！」[rhp]
[:princess:]
「克林生前出于某种深～刻理由对大海抱有强烈执念。[rhr]
_　他追寻的是留存于大海的追忆……！就是这么回事吧！？」[rhp]

[:heartshape:][hati body=mizugi kao=2 ss=on ]
[font size=30]
「是奶子啊啊！！！！」[rhp]
[[resetfont]

[:princess:][puri_w body=mizugi kao=4 as=on ss=on ]
「父亲！？」[rhp]

[yurasu]

[:heartshape:][hati body=mizugi kao=2 ]
[font size=36]
「别从现实逃避――啊啊！！」[rhp]

[yurasu]

[:heartshape:]
[font size=27]
「是奶子！你没有奶子啊啊！连痕迹都没有！！」[rhp]
[resetfont]

[:princess:][puri_w body=mizugi kao=2 as=on ]
「有痕迹的！！」[rhp]

[:jet:][p_j_05][jet body=mizugi kao=11 ]
「克林为了合法观赏穿内衣的巨乳美女，[rhr]
_　定期就会搞这种角色扮演把戏」[rhp]
[:jet:]
「上上次要求去温泉度假村。特意插入乌尤尼行程[rhr]
_　就为了强调『说到底只是喜欢水边啦？』」[rhp]

[:princess:][puri_w body=mizugi kao=6 as=on ss=on ]
「呸，下流……！大胸有什么了不起！」[rhp]

[puri_w body=mizugi kao=2 ]
「大伙快离开这里！！[rhr]
_　别跟着这种大人混！！」[rhp]

[:heartshape:][p_h_31][hati body=mizugi kao=5 ]
「没错！来到新星球首先要探索！铁律！」[rhp]

[off_all]

[chara_part name="jet" body=mizugi kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="drop" body=base kao=13 as=off ss=off hh=off hr=on hat=on]
[chara_show name="drop" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:jet:]
「抱歉啊多洛普。克林的看管就交给你了」[rhp]

[:drop:]
「知道啦。小心点」[rhp]

[off_all]

[::]
我对克林的好色彻底失望，[rhr]
于是决定带着大家开始探索海滩。[rhp]

[:princess:]
[font color=0x4682b4]
（海里的巨乳算什么啦！[rhr]
_　我绝对不要再和克林玩了！）[rhp]
[resetfont]

;****************************************
[set_time_d]
;****************************************

[:quadrillion:][p_r_09][riri body=mizugi kao=6 ]
「哎呀呀……一个个都是小鬼头呢」[rhp]

[off_riri]

[chara_part name="riri" body=mizugi kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time="150"]
[chara_part name="drop" body=base kao=0 as=off ss=off hh=off hr=on hat=sea]
[chara_show name="drop" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:quadrillion:]
「听好了多洛普？说什么胸部会发育都是骗人的。[rhr]
_　我的主张是这一切都由遗传决定」[rhp]

[:drop:][p_d_19][drop hat=sea kao=2 as=on ]
「突然在说什么啊……」[rhp]

[:quadrillion:][p_r_31][riri body=mizugi kao=13 ]
「真没劲～来聊天嘛！一个人多寂寞呀。[rhr]
_　草帽，很适合你呢。你戴上啦」[rhp]

[:drop:][p_d_05][drop hat=sea kao=6 as=on ]
「帽子是很感谢啦但胸…胸的话题我不懂！[rhr]
_　我在海滩等着，你也快点和大家一起……」[rhp]

[:quadrillion:][p_r_25][riri body=mizugi kao=2 ]
「吵死人了。所以才说你是豆芽菜！[rhr]
_　你那没出息的性格，就让姐姐来矫正吧」[rhp]

[:drop:][p_d_21][drop hat=sea kao=2 as=on ]
「不用了！！」[rhp]

[off_all]

[:unknown:]
「哎呀？在那里的是……」[rhp]

[:quadrillion:][p_r_13][riri body=mizugi kao=0 ]
「这声音……」[rhp]

[off_riri]

[:mika:][p_mk_31][mika body=mizugi kao=5 hh=on ]
「果然是你们！多洛普君和莉莉对吧～！」[rhp]

[:drop:][p_d_13][drop hat=sea kao=4]
「米、米卡亲学姐！」[rhp]

[:mika:][p_mk_35][mika body=mizugi kao=14 ]
「太巧～～～了！……虽然也不是偶然，太好啦！[rhr]
_　这么快就找到你们了！」[rhp]

[:drop:][p_d_02][drop hat=sea ]
「好久不见。[rhr]
_　在游乐园没有见到您呢，您还好吗？」[rhp]

[:mika:][p_mk_01][mika body=mizugi ]
「超级好哦♡　虽然没见到大家有点遗憾，[rhr]
_　不过老师替我把工作都完成了，所以意外获得了休假呢」[rhp]

[:drop:][p_d_31][drop hat=sea kao=11 as=on ]
「那真是太好了……啊，对了！」[rhp]
[:drop:]
「矢部医生，关于游乐园那件事后来怎么样了。[rhr]
_　我们员工在游乐园动粗实在很抱歉……」[rhp]

[:mika:][p_mk_28][mika body=mizugi kao=13 ]
「没关系！那家伙活蹦乱跳得很。[rhr]
_　他基本睡一觉就忘事的类型啦」[rhp]

[:drop:][p_d_31][drop hat=sea kao=5 as=on ]
「那我就放心了。听说他被踹得相当狠呢」[rhp]

[off_all]

[drop hat=sea kao=6 ]
「我说，夸德里利昂。[rhr]
_　虽说没事，姑且还是道个歉吧」[rhp]

[off_all]

[:quadrillion:][riri body=mizugi kao=2 ss=on ]
「……………………」[rhp]

[off_riri]

[chara_part name="riri" body=mizugi kao=2 as=on ss=off hh=on hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="80" top="0" wait="false" time="150"]
[chara_part name="drop" body=base kao=2 as=off ss=off hh=off hr=on hat=sea]
[chara_show name="drop" layer="1" width="437" height="720" left="421" top="0" wait="false" time="150"]
[chara_part name="mika" body=mizugi kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="mika" layer="1" width="437" height="720" left="760" top="0" wait="true" time="150"]

[:drop:][p_d_19]
「发什么呆呢。傻站着」[rhp]

[:mika:][mika body=mizugi ]
「哎呀♡　该不会，看入迷了吧？」[rhp]

[:quadrillion:][p_r_36][riri body=mizugi kao=1 hh=on ]
「今、今天也好美啊米卡亲……！[rhr]
_　说不定我就是为了看这个，才选择这趟海上之旅的」[rhp]

[:mika:][p_mk_31][mika body=mizugi ]
「呵呵♡　能被这么说真开心呢♡」[rhp]

[:quadrillion:][riri body=mizugi kao=11 hh=on ]
「哇啊！果然泳装还是比基尼最棒～！居然还是红色的！？[rhr]
_　太赞了……！尤其跟在布兹那件土气连衣裙后面看更美了」[rhp]

[:mika:][p_mk_13][mika body=mizugi kao=0 ]
「布兹的土气……？」[rhp]

[:drop:][p_d_30][drop hat=sea kao=6 as=on ]
「请别在意。是最下流的坏话」[rhp]

[off_all]

[chara_part name="riri" body=mizugi kao=2 as=off ss=off hh=on hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time="150"]
[chara_part name="mika" body=mizugi kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="mika" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:quadrillion:][p_r_04]
「啊、对不起。能不能让我盯着看10秒钟？[rhr]
_　我想把那个曲线深深印在眼里」[rhp]

[:mika:][p_mk_09][mika body=mizugi kao=5 ]
「真是的～莉莉好色♡」[rhp]
[mika body=mizugi kao=13 ]
「……这样的姿势怎么样？」[rhp]

[:quadrillion:][riri body=mizugi kao=2 as=on hh=on ]
「噫呀！住手！太刺眼了！」[rhp]

[yurasu]
[off_all]

[:mika:][p_mk_15]
「这个呢？」[rhp]

[:quadrillion:]
[font size=27]
「不要―――！！那个角度！那个角度不行！！」[rhp]
[resetfont]

[:drop:][drop hat=sea kao=6 as=on ss=on ]
[font color=0x4682b4]
（我到底被迫在看什么啊……果然还是回车上去吧……）[rhp]
[resetfont]
[:drop:][drop hat=sea kao=0 as=on ]
「……嗯？」[rhp]

[off_drop]

[:yabu:][p_yb_18][yabu pnt=on body=mizugi kao=3 as=on ]
「可恶、米卡亲跑哪儿去了！[rhr]
_　特意买的刨冰都要化掉了……！」[rhp]

[off_yabu]

[:drop:][p_d_04][drop hat=sea kao=4 ]
「喂——！矢部医生！」[rhp]

[off_drop]

[:yabu:][p_yb_13][yabu pnt=on body=mizugi kao=2 as=on ]
「嗯？……啊啊！？」[rhp]

[:drop:][p_d_35][drop hat=sea kao=14 ]
「果然矢部医生也来了呢。您好」[rhp]

[:yabu:][p_yb_09][yabu pnt=on body=mizugi kao=6 as=on ]
「你们这帮混蛋、上次居然敢把本名医丢下自顾自回家！[rhr]
_　至少该打个招呼或者摇醒我吧」[rhp]
[:yabu:]
「老子可是整整在地上睡了一天，浑身骨头都僵了！」[rhp]

[:drop:][p_d_34][drop hat=sea kao=13 as=on ]
「当时真是抱歉。您没有受伤吧？」[rhp]

[:yabu:][p_yb_15][yabu pnt=on body=mizugi kao=5 ]
「哼、少瞧不起人！毕竟是名医。淤青什么的第二天就好了！」[rhp]

[:drop:][p_d_08][drop hat=sea kao=14 ]
「这样啊！太好了」[rhp]

[:yabu:][p_yb_04][yabu pnt=on body=mizugi kao=6 ]
「对了多洛普。看到米卡亲了吗？[rhr]
_　她说要买刨冰我才去准备的，结果到处都找不到……」[rhp]

[:drop:][p_d_01][drop hat=sea ]
「啊。她正在和我们家的夸德里利昂进行拍摄会哦」[rhp]

[:yabu:][p_yb_19][yabu pnt=on body=mizugi kao=0 ]
「哈？　拍摄会？」[rhp]

[off_all]

[se storage="se4_06.ogg" loop=true]

[chara_part name="riri" body=mizugi kao=2 as=on ss=off hh=on hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time="150"]
[chara_part name="mika" body=mizugi kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="mika" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:mika:][p_mk_02]
「是的，还有5秒哦～♡」[rhp]

[se storage="se4_06.ogg"]

[:quadrillion:]
「哈啊……！　哈啊……！　5、4、3、2」[rhp]
[:quadrillion:]
「一……」[rhp]

[off_all]

[stopse]

[:yabu:][p_yb_09][yabu pnt=on body=mizugi kao=2 ]
「喂——米卡亲！你在干什么啊！」[rhp]

[off_all]

[:quadrillion:][p_r_13][riri body=mizugi kao=2 as=on ss=on ]
[font size=25]
「啊啊啊！？」[rhp]
[resetfont]

[off_all]

[chara_part name="yabu" body=mizugi kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="yabu" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="mika" body=mizugi kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="mika" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:mika:][p_mk_19]
「哎呀，老师！买到彩虹味的刨冰了吗？」[rhp]

[:yabu:]
「买是买到了但几乎都化了，变成像老鼠一样的灰色了！[rhr]
_　就是因为你没在规定的地方好好等着！」[rhp]
[:yabu:]
「上次刚被夜训过，今天必须好好执行作战计划才行！[rhr]
_　虽然是自由时间，但希望你能自觉别擅自行动……」[rhp]

[off_all]

[yurasu]

;ガシッ
[se storage="hand_01.ogg"]

[:yabu:][p_yb_19][yabu pnt=on body=mizugi kao=6 ]
「…………嗯？　这手是怎么回事」[rhp]

[:quadrillion:][riri body=mizugi kao=2 ss=on ]
「你这混蛋……」[rhp]

[:yabu:][p_yb_29][yabu pnt=on body=mizugi kao=12 ]
「夸德里利昂。抱歉现在正在拍摄中……」[rhp]

[:quadrillion:][p_r_26][riri body=mizugi kao=2 ss=on ]
「道歉」[rhp]

[:yabu:][p_yb_10][yabu pnt=on body=mizugi kao=2 as=on ]
「诶？」[rhp]

[:quadrillion:][p_r_21][riri body=mizugi kao=2 ss=on ]
「明明只剩最后5秒了……！　竟敢来碍事！？」[rhp]

[:yabu:][p_yb_14][yabu pnt=on body=mizugi kao=2 as=on ]
「你怎么了。感觉和平时形象不太一样……」[rhp]

[:quadrillion:][p_r_19][riri body=mizugi kao=6 ]
「啊对了！说起来你这家伙，[rhr]
_　之前还在我的餐车上装了奇怪的陷阱对吧！？」[rhp]

[:yabu:][p_yb_06][yabu pnt=on body=mizugi kao=5 ]
「啊！那个啊！太好啦，看来确实成功了呢！[rhr]
_　怎么样，是不是羞耻得恨不得马上跳车！？」[rhp]

[:quadrillion:][p_r_12][riri body=mizugi kao=2 ss=on ]
「太朴素了！！　之前发发牢骚还能忍，但现在实在忍到极限了。[rhr]
_　今天一定要把你们沉进加勒比的海里――――」[rhp]

[off_all]

[yurasu]
[:heartshape:][p_h_04][hati body=mizugi kao=5 ]
[font size=28]
「克林――！！　欧派好暖和ー！？」[rhp]
[resetfont]

[off_all]

[:jet:][p_j_17][jet body=mizugi kao=6 ]
「不，欧派这东西男女平等吧」[rhp]

[:princess:][puri_w body=mizugi kao=2 as=on ]
「喂哈蒂君！　不可以大声说这种话。[rhr]
_　会变成像克林那样糟糕的大人哦！」[rhp]

[off_all]

[:quadrillion:][riri body=mizugi kao=2 as=on ]
「！！！！！　啧……！　已经回来了」[rhp]

[off_riri]

[chara_part name="yabu" body=mizugi kao=2 as=on ss=off hh=off hr=on pnt=on ]
[chara_show name="yabu" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="mika" body=mizugi kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="mika" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:yabu:][p_yb_13]
「……！公主……」[rhp]

[:mika:][p_mk_05][mika body=mizugi kao=13 ]
「………………、还是老样子精神过头呢」[rhp]

[off_all]

[chara_part name="kite" body=mizugi kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="160" top="0" wait="false" time="150"]
[chara_part name="hati" body=mizugi kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:kite:][p_k_19]
「………？　怎么感觉气氛有点僵？」[rhp]

[:heartshape:][p_h_18]
「原来没有巨乳啊！？」[rhp]

[:princess:][puri_w body=mizugi kao=2 ss=on ]
「说什么呢。明明有啊，你看那里满满当当的……」[rhp]

[off_all]

[:mika:][p_mk_35][mika body=mizugi kao=13 ]
「初次见面公主。我是米卡亲♡」[rhp]

[:princess:][puri_w body=mizugi kao=2 as=on ]
「初、初次见面……」[rhr]
[font color=0x4682b4]
（可恶！　这压迫感……！）[rhp]
[resetfont]

[off_all]

[chara_part name="riri" body=mizugi kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time="150"]
[chara_part name="jet" body=mizugi kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:jet:][p_j_08]
「干得漂亮克林。能抓到米卡亲，这次算是丰收了」[rhp]

[:quadrillion:]
「虽然被某个庸医搅局了～～～～～～」[rhp]

[:jet:][p_j_15][jet body=mizugi kao=5 ]
「矢部亲出现就意味着，要开始了……祭典！」[rhp]

[off_all]

[:princess:][puri_w body=mizugi kao=6 ]
「祭典……？」[rhp]

[off_all]

[:yabu:][p_yb_35][yabu pnt=on body=mizugi kao=14 ]
「哈哈哈……！　啊ー哈哈哈！　说的没错。[rhr]
_　我们的登场……即是终焉之宴。祭典开幕的信号！」[rhp]
[:yabu:][yabu pnt=on body=mizugi kao=5 ]
「看着吧小鬼们。[rhr]
_　今天就让本名医送你们去医院！」[rhp]

[off_all]

[chara_part name="yabu" body=mizugi kao=5 as=off ss=off hh=off hr=on pnt=on ]
[chara_show name="yabu" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="mika" body=mizugi kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="mika" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:yabu:]
「那么米卡亲，开始说明吧！」[rhp]

[:mika:][p_mk_02][mika body=mizugi kao=13 ]
「好～的，老师♡」[rhp]

[off_all]

[:princess:][puri_w body=mizugi kao=2 as=on ]
「究、究竟要开始什么……！？」[rhp]

;****************************************
[fbgm]
[set_00 storage="sea_02.jpg"]
;****************************************

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
[vostart]
;--------------------------------------------------------------------------------------------

[se storage="jin_02.ogg"]

[:darknebula:]
[font color=0x0000ff]
『接下来即将举行第数十届、[rhr]
_　铁道争夺战第一回合・沙滩夺旗对决！』[rhp]

[bgm storage="bgm_48.ogg"]

[:darknebula:]
『主持由本人──海洋生物学者达克内布拉博士担任』[rhp]

[:mika:]
『解说是米卡亲♡　请多指教啦』[rhp]

[:darknebula:]
『今天的矢部医生似乎干劲十足呢。[rhr]
_　是心境发生了什么变化吗？』[rhp]

[:mika:]
『嗯──可能是因为前几天被上司骂了吧。[rhr]
_　他夹在中间很难做呢』[rhp]

[:darknebula:]
『原来如此。今天请务必展现中层管理人的骨气、[rhr]
_　好好发泄平日的郁愤吧』[rhp]

[:mika:]
『老师～加油♡』[rhp]
[resetfont]

;****************************************
[bg_rule storage="sea_02.jpg" rule="002.png" time=500]
;****************************************

[:yabu:][yabu pnt=on body=mizugi kao=6 as=on ]
「不对劲吧……！？[rhr]
_　我们明明是两人团队，为什么她跑去解说席了！？」[rhp]

[:quadrillion:][riri body=mizugi kao=5 ]
「哎呀～不靠女人帮忙就没自信吗？矢部亲」[rhp]

[:yabu:][yabu pnt=on body=mizugi kao=2 ]
「！　你说什么……？」[rhp]

[:quadrillion:][riri body=mizugi ]
「我会赢的。绝不会把那条铁道让给你们。而且──」[rhp]
[:quadrillion:][riri body=mizugi kao=2 ]
「必须把失去的巨乳时光原原本本还给我！！」[rhp]

[:yabu:][yabu pnt=on body=mizugi kao=6 as=on ]
「啧……！那种东西之后偷偷偷看不就得了……」[rhp]

[off_all]

;****************************************
;応援席
[bg_rule storage="sea_08.jpg" rule="002.png" time=500]
;****************************************

[chara_part name="drop" body=base kao=2 as=off ss=off hh=off hr=on hat=sea ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="peku" body=mizugi kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="false" time="150"]
[chara_part name="puri_w" body=mizugi kao=2 as=off ss=off hh=off hr=on hat=okan]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:vulpecula:]
「加油啊库林！不要输给老师啊！」[rhp]

[:princess:]
「巨乳是邪恶！巨乳是邪恶！」[rhp]

[:drop:]
「请务必获胜！要是被赶出铁道我们就无家可归了！」[rhp]

[off_all]

;****************************************
;ビーチ
[bg_rule storage="sea_02.jpg" rule="002.png" time=500]
;****************************************

[chara_part name="riri" body=mizugi kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time="150"]
[chara_part name="yabu" body=mizugi kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="yabu" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:quadrillion:]
「好啦小鬼们～要好好加油哦ー♡」[rhp]

[:yabu:][yabu pnt=on body=mizugi kao=5 ]
「哼……！趁现在尽管闹腾吧」[rhp]
[:yabu:]
「你们这群人的旅途，就由名医在此终结。[rhr]
_　铁道将由我们接管，而你们全都要被送进医院！」[rhp]

[off_all]

[:darknebula:]
[font color=0x0000ff]
『那么，各就各位。预备……』[rhp]
[resetfont]

;ピストル
[se storage="se4_15.ogg"]

[::]
―――就这样，白热化的夺旗帜对决开始了！！[rhp]

;****************************************
[fbgm]
[set_time_d]
;****************************************

[bgm storage="bgm_21.ogg"]

[chara_part name="drop" body=base kao=6 as=off ss=off hh=off hr=on hat=sea ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="kite" body=mizugi kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time="150"]

[:drop:]
「哈啊……」[rhp]

[:kite:][kite body=mizugi kao=2 ]
「废物……」[rhp]

[:princess:][puri_w body=mizugi kao=2 ]
「奶子混蛋……」[rhp]

[off_all]

[chara_part name="jet" body=mizugi kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="peku" body=mizugi kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time="150"]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:vulpecula:][p_vl_09]
「真是的！」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:jet:]
「无能」[rhp]

[:princess:][puri_w body=mizugi kao=2 ]
「奶子混蛋！」[rhp]

[off_all]

[:quadrillion:][riri body=mizugi kao=6 as=on ]
「也、也不用指责到这种程度吧！[rhr]
_　谁都会有失利的时候不是吗」[rhp]

[:drop:][drop hat=sea kao=2 ]
「当然要指责！明明之前那么信心十足结果就这？[rhr]
_　要是惜败也就算了，可为什么连普通赛跑都会输啊ー！？」[rhp]

[:quadrillion:][riri body=mizugi kao=3 ]
「那家伙意外地跑得很快。真是出乎预料」[rhp]

[off_all]

[chara_part name="yabu" body=mizugi kao=11 as=off ss=off hh=off hr=on pnt=on ]
[chara_show name="yabu" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="hati" body=mizugi kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:yabu:]
「名医奔跑亦是迅捷」[rhp]

[:heartshape:]
「名医太厉害了！」[rhp]

[off_all]

[::]
就这样，铁道争夺战首日以矢部医生方的胜利落下帷幕。[rhp]
虽然内心想着"该不会还有续集吧"，[rhr]
大家干劲十足，所以我已经决定什么都不说了……[rhp]

;****************************************
[fbgm]
[set_00 storage="sea_02.jpg"]
;****************************************
[bgm storage="bgm_24.ogg"]

翌日[rhp]

[:darknebula:]
[font color=0x0000ff]
『那么，今天第二回合！铁道争夺战是远泳对决』[rhp]
[:darknebula:]
『参赛者与昨日相同，依旧是矢部医生！』[rhp]
[resetfont]

[off_hakase]

[:yabu:][yabu body=mizugi kao=5 pnt=off ]
「异端名医必胜。众多医疗剧都证实了这点」[rhp]

[:princess:][puri_w body=mizugi kao=2 ]
「好厉害的泳裤……！斗志满满呢！」[rhp]

[off_all]

[:darknebula:]
[font color=0x0000ff]
『而他的对手是这位！』[rhp]
[resetfont]

[:kite:][kite body=mizugi kao=11 ]
「大家好～」[rhp]

[off_kite]

[chara_part name="mika" body=mizugi kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="mika" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="hakase" body=mizugi kao=5 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720" left="600" top="0" wait="true" time="150"]

[:mika:]
「哎呀呀，该不会已经放弃胜利了吧？[rhr]
_　快斗君是不可能赢过我们家矢部医生的哦」[rhp]

[:darknebula:]
「因为快斗无论如何都要参加，所以破例录用。[rhr]
_　说不定藏着什么秘密策略。让我们拭目以待吧」[rhp]

[off_all]

[:kite:][kite body=mizugi kao=5 ]
「放心交给我就是」[rhp]

[:darknebula:]
[font color=0x0000ff]
『连角色气质都变了，这下值得期待呢！』[rhp]

[:mika:]
『结果真令人期待～♡』[rhp]
[resetfont]

[off_kite]

[chara_part name="hati" body=mizugi kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="421" top="0" wait="false" time="150"]
[chara_part name="puri_w" body=mizugi kao=6 as=on ss=off hh=off hr=on hat=okan]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「真的没问题吗？比体力的话哈蒂君更合适吧……」[rhp]

[:heartshape:]
「我也这么想。[rhr]
_　那家伙连跑步的样子都没见过，远泳绝对不行！」[rhp]

[off_all]

[chara_part name="yabu" body=mizugi kao=5 as=off ss=off hh=off hr=on pnt=off ]
[chara_show name="yabu" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="kite" body=mizugi kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time="150"]

[:kite:]
「请多指教，医生。我不会输的」[rhp]

[:yabu:]
「别看这样我可是乡下长大的！[rhr]
_　不管是河还是海，在水里我绝不可能输！」[rhp]

[:kite:][kite body=mizugi kao=11 ]
「哦是么……。嘛，不试试看怎么知道呢」[rhp]

[off_all]

;****************************************
;沖
[bg_rule storage="sea_03.jpg" rule="002.png" time=500]
;****************************************

[:darknebula:]
[font color=0x0000ff]
『在此1公里处等候的多洛普的游艇处折返，[rhr]
_　先到者即为胜者』[rhp]

[:mika:]
『若被水母蜇伤请立即退赛，迅速前往米卡亲处♡』[rhp]
[resetfont]

;****************************************
;ビーチ
[bg_rule storage="sea_02.jpg" rule="002.png" time=500]
;****************************************

[:darknebula:]
[font color=0x0000ff]
『现在开始。各就各位，预备……』[rhp]
[resetfont]

[off_hakase]
[yurasu]

;ピストル
[se storage="se4_15.ogg"]

[:darknebula:]
『砰！』[rhp]
[resetfont]

;****************************************
;海に飛び込む
[se storage="se2_10.ogg"]
;沖
[bg_rule storage="sea_06.jpg" rule="014.png" time=500]
;****************************************

[:princess:]
「矢部医生，好快！」[rhp]

[:yabu:]
「呜哇—哈哈哈！咕哇咕哇咕噜咕噜！」[rhp]

[:quadrillion:]
「在说什么啊！这根本看不懂会怎样呢！」[rhp]

[off_riri]

;****************************************
[bg_rule storage="sea_02.jpg" rule="002.png" time=500]
;****************************************

[:quadrillion:][riri body=mizugi kao=6 as=on ]
「…………真是的」[rhp]

[off_riri]

[:kite:][kite body=mizugi kao=12 ]
「哈啊——……」[rhp]

[off_kite]

[chara_part name="riri" body=mizugi kao=8 as=on ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time="150"]
[chara_part name="kite" body=mizugi kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time="150"]

[:quadrillion:]
「喂你在干嘛！？[rhr]
_　老早就该出发了哦！」[rhp]

[:kite:][kite body=mizugi kao=7 ]
「嘿咻……好嘞」[rhp]

[off_all]

;****************************************
#
[bg storage="sea_05.jpg" time=500]
;****************************************

[::]
全程懒洋洋的快斗无视了夸德里利昂，[rhr]
不知为何将身子陷在游泳圈里，开始漂在浅滩上噗嗒噗嗒晃悠。[rhp]

[:kite:][kite body=mizugi kao=12 ]
「等医生还剩100米左右时告诉我」[rhp]

[off_kite]

;****************************************
#
[fbgm]
[bg storage="sea_02.jpg" time=500]
;****************************************

[:quadrillion:][riri body=mizugi kao=6 as=on ss=on ]
「啊、你……难道……」[rhp]

[off_riri]

;****************************************
#
[bg_rule storage="sea_06.jpg" rule="002.png" time=500]
;****************************************

[bgm storage="bgm_25.ogg"]

[:yabu:]
[font color=0x4682b4]
（不对劲……！这到底怎么回事……！？）[rhp]
[:yabu:]
（从起步就已和快斗拉开很大差距。[rhr]
_　即便如此，明明早已过了折返点，[rhr]
_　却完全感受不到和快斗擦身而过的迹象……！？）[rhp]
[:yabu:]
（难道被水母蜇伤退赛了？但这里可是魔法世界。[rhr]
_　姑且不论夜，在南构筑的世界里他们怎么可能遭遇危险）[rhp]
[:yabu:]
（……！必须先停下来确认……）[rhp]
[resetfont]

[:yabu:]
「――――！！！什、么！？」[rhp]

[:kite:]
「哈啊……！可……！」[rhp]

[:yabu:]
「什、什么！？你说在我前面游泳！？」[rhp]

[:kite:]
「在差距被彻底拉开的现在，我只能被迫使用这招了……！」[rhp]
[:kite:]
「其名为『消失魔泳』！[rhr]
_　通过隐身游泳让老师误以为我还游刃有余，[rhr]
_　趁着这个破绽我实现了惊天逆转！」[rhp]

[:yabu:]
「魔泳！？开什么玩笑……！」[rhp]

;****************************************
#
[bg storage="white.jpg" time=500]
[bg storage="sea_02.jpg" time=500]
;****************************************

[:darknebula:]
[font color=0x0000ff]
『第一名，快斗选手！』[rhp]
[resetfont]

[:kite:][kite body=mizugi kao=2 as=on ]
「……！哈啊，哈啊……！」[rhp]

[off_kite]

[:yabu:][yabu body=mizugi kao=4 as=on pnt=off ]
「荒唐至极……！[rhr]
_　冲的武君竟然……输了……！？」[rhp]

[:darknebula:]
[font color=0x0000ff]
『刚才的发言有什么特殊含义吗？』[rhp]

[:mika:]
『因为老师的名字是武君，可能是童年绰号吧～』[rhp]
[resetfont]

[fbgm]

[:yabu:][yabu body=mizugi kao=3 as=on pnt=off ]
「……可……过去荣光，吗……」[rhp]

[:kite:][kite body=mizugi kao=5 ]
「矢部亲」[rhp]
[:kite:][kite body=mizugi kao=5 ]
「三克油。……真是场好比赛啊」[rhp]

[bgm storage="bgm_17.ogg"]

[:yabu:][yabu body=mizugi kao=8 as=on pnt=off ]
「快斗……你这家伙，竟对败者伸手……」[rhp]
[:yabu:][yabu body=mizugi kao=5 as=on pnt=off ]
「…………彻底败北！快斗……不，冲的快仔」[rhp]
[:yabu:]
「挺起胸膛！从今天起你就是大海的霸主！」[rhp]

[off_all]

[chara_part name="jet" body=mizugi kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="hati" body=mizugi kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:jet:]
「快斗那小子，终究在矢部亲靠近之后[rhr]
_　只游了10米左右吧」[rhp]

[:heartshape:]
「但那喘息可不是演技啊……！[rhr]
_　那种体力透支的样子，真让人担心」[rhp]

[off_all]

[chara_part name="mika" body=mizugi kao=11 as=off ss=off hh=off hr=on ]
[chara_show name="mika" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="hakase" body=mizugi kao=0 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720" left="600" top="0" wait="true" time="150"]

[:darknebula:][hakase body=mizugi msk=off kao=0 ]
「我姑且确认下，算快斗赢可以吧？」[rhp]

[:mika:][mika body=mizugi kao=13 ]
「嗯哼。反正都是闹剧，随便啦」[rhp]

[off_all]

[:mika:][mika body=mizugi kao=11 ]
「好～啦！今天的比赛到此结束。[rhr]
_　我要回酒店做芳香SPA去咯～」[rhp]

[off_mika]

[:princess:][puri_w body=mizugi kao=0 ]
「芳香SPA……」[rhp]

[off_puri]

[::]
面对碧海白沙滩，居然选择回酒店……！[rhr]
不愧是成年人。丰润的女人连余裕都如此充沛吗……[rhp]

[:mika:][mika body=mizugi kao=5 ]
「……呵呵♡　公主也一起来吗？」[rhp]

[:princess:][puri_w body=mizugi kao=0 as=on ]
「！！」[rhp]

[off_all]

[::]
糟、看得太露骨了吗。[rhr]
没想到会被搭话，我不自觉移开了视线。[rhp]

[chara_part name="mika" body=mizugi kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="mika" layer="1" width="437" height="720" left="421" top="0" wait="false" time="150"]
[chara_part name="puri_w" body=mizugi kao=8 as=on ss=off hh=on hr=on hat=okan]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「不、不用了。并肩走会被比较的……」[rhp]

[:mika:][mika body=mizugi kao=13 ]
「哎呀呀，呵呵♡　青春期呢」[rhp]
[:mika:]
「没关系的公主。你现在的模样，非常迷人哦」[rhp]

[:princess:][puri_w body=mizugi kao=3 as=on ]
「因为大家都笑话我……」[rhp]

[:mika:][mika body=mizugi kao=11 ]
「只是世人把理所当然的事都忘了」[rhp]
[:mika:]
「就像没有太阳月亮就不会发光，[rhr]
_　没有凹面凸面也无从谈起……对吧♡」[rhp]

[:princess:][puri_w body=mizugi kao=2 ss=on ]
「我才没有凹进去啊？？？？」[rhp]

[:mika:][mika body=mizugi kao=14 ]
「细节什么的不用在意啦～！走吧走吧！[rhr]
_　美容院，米卡亲会给你安排最好的套餐哦！」[rhp]

[off_mika]

[chara_part name="riri" body=mizugi kao=2 as=on ss=off hh=on hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="383" top="0" wait="false" time="150"]
[chara_part name="puri_w" body=mizugi kao=4 as=off ss=off hh=on hr=on hat=okan]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:2nin:]
[playse storage="riri/part/13.ogg" buf=1]
「欸！？」[rhr]
「欸！？」[rhp]

[off_all]

[:mika:][mika body=mizugi kao=4 ]
「哎呀」[rhp]

[off_mika]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[chara_part name="riri" body=mizugi kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="383" top="0" wait="false" time="150"]
[chara_part name="puri_w" body=mizugi kao=2 as=off ss=on hh=on hr=off hat=okan]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「喂克林！你在想什么啊！？[rhr]
_　克林是男的，肯定不行啦！」[rhp]

[:quadrillion:][p_r_10][riri body=mizugi kao=5 ]
「现在男性也会做美容护理的啦～～～。[rhr]
_　在充满异域风情的芳香中，和米卡亲共度优雅时光……」[rhp]

[off_all]

[chara_part name="riri" body=mizugi kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time="150"]
[chara_part name="hati" body=mizugi kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:heartshape:][p_h_10]
[font size=28]
「你搞什么啊克林！！[rhr]
_　你不是要和我们来场灼热沙滩排球对决吗！」[rhp]
[resetfont]

[yurasu]

[:quadrillion:][riri body=mizugi kao=2 as=on ]
「呀！别碰我你们这群野蛮人！」[rhp]
[:quadrillion:]
「说到底什么灼热沙滩排球啊！[rhr]
_ 光是听着皮肤就火辣辣的……啊不行！我绝对不要！」[rhp]

[:heartshape:][p_h_16][hati body=mizugi kao=5 ]
「对战组合是＜我＆杰特＞vs＜博士＆矢部＞！[rhr]
_ 无视身高差距的我们组合……！超燃的对吧！？」[rhp]

[:quadrillion:][p_r_21]
「别在不需要我的比赛里叫我啊！」[rhp]

[:heartshape:][p_h_31][hati body=mizugi kao=5 ]
「克林你太碍事了当裁判去！！」[rhp]

[:quadrillion:][p_r_10]
「有必要！？那种事！」[rhp]

[off_all]

[:princess:][puri_w body=mizugi kao=7 ]
「………………我们走吧。米卡小姐」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:mika:][mika body=mizugi kao=0 ]
「可以吗？放着他们不管」[rhp]

[:princess:][puri_w body=mizugi kao=6 ]
「没关系。男生真是笨蛋呢……」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
[fbgm]
[set_00 storage="sea_01.jpg"]
;****************************************

[bgm storage="bgm_16.ogg"]

我落后米卡小姐半步跟在她身后，[rhr]
为了前往酒店内的美容院，我们正沿着海边行走。[rhp]

[:mika:][mika body=mizugi kao=14 ]
「公主的泳衣好可爱呀～♡」[rhp]

[:princess:][puri_w body=mizugi kao=6 as=on ]
「哪、哪里……」[rhp]

[:mika:][mika body=mizugi kao=1 ]
「是自己选的吗？」[rhp]

[:princess:][puri_w body=mizugi kao=3 as=on ]
「不是。是克里利……夸德里利昂」[rhp]

[:mika:][mika body=mizugi kao=13 ]
「这样啊！莉莉的眼光肯定不会错呢。[rhr]
_　不愧是公主，真的很适合你」[rhp]

[:princess:][puri_w body=mizugi kao=6 as=on ss=on ]
[font color=0x4682b4]
（这拐弯抹角说我像搓衣板身材……）[rhp]
[resetfont]

[:mika:][mika body=mizugi kao=1 ]
「芙蕾雅的泳衣就是适合你这种体型呢。[rhr]
_　莉莉肯定也是考虑到这点才选的吧」[rhp]

[:princess:][puri_w body=mizugi kao=0 as=on ]
「……！这……这样吗」[rhp]

[:mika:][mika body=mizugi kao=11 ]
「真好啊。要是米卡亲也能[rhr]
_　再苗条年轻些就能穿这种……」[rhp]
[:mika:][mika body=mizugi kao=5 as=on ]
「啊！！不不不。我有在减肥的。[rhr]
_　而且我觉得自己还很年轻呢……！」[rhp]

[:princess:][puri_w body=mizugi kao=1 ]
「……呵呵」[rhp]

[:mika:][mika body=mizugi kao=8 as=on hh=on ]
「啊！你笑了对吧！？真是的！[rhr]
_　再过十年你也会变成我这样的！」[rhp]
[:mika:]
「该高兴才对！？」[rhp]

[:princess:][puri_w body=mizugi kao=13 as=on ]
「高、高兴的」[rhp]

[:mika:][mika body=mizugi kao=11 hh=on ]
「嗯嗯！这样才对嘛♡」[rhp]

[off_mika]

[:princess:][puri_w body=mizugi kao=1 ]
[font color=0x4682b4]
（……真是个好人呢，米卡亲。[rhr]
_　温柔又有趣，还这么漂亮……）[rhp]
[:princess:][puri_w body=mizugi kao=12 as=on ]
（……………过去的我真是个讨厌鬼啊）[rhp]
[resetfont]

[off_all]

[::]
仅仅因为巨乳就对她态度太过严厉了。[rhr]
明明可能是至今为止遇到的人中最温柔成熟的。[rhp]

[:princess:][puri_w body=mizugi kao=8 ]
「―――那个。米卡小姐」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:mika:][mika body=mizugi ]
「叫米卡亲就好啦。怎么了？公主」[rhp]

[:princess:][puri_w body=mizugi kao=3 as=on ]
「那个……我想道歉……为之前的态度的事。[rhr]
_　可能我有点带刺吧」[rhp]

[:mika:][mika body=mizugi kao=14 ]
「……！　啊哈哈！　我完全没在意那种事哦」[rhp]
[:mika:][mika body=mizugi kao=13 ]
「我呢，因为总是和老师在一起，所以和女孩子在一起感觉很新鲜。[rhr]
_　光是这点就全都值得原谅♡」[rhp]

[:princess:][puri_w body=mizugi kao=4 hh=on as=on ]
「米卡亲……」[rhp]

[:mika:]
「今天就尽情享受吧！　公主♡」[rhp]

[:princess:][puri_w body=mizugi kao=14 hh=on ]
「―――！　嗯！　欸嘿嘿……」[rhp]

[off_all]

[::]
米卡亲不仅胸大，心胸也很宽广呢。[rhp]
简直浪费了之前那么多时间。[rhr]
要是早知道是这么优秀的人，就该早点多聊聊啊……[rhp]

[chara_part name="mika" body=mizugi kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="mika" layer="1" width="437" height="720" left="421" top="0" wait="false" time="150"]
[chara_part name="puri_w" body=mizugi kao=1 as=off ss=off hh=off hr=on hat=okan]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「对了，有件事我有点在意」[rhp]

[:mika:][mika body=mizugi ]
「嗯？什么事呀」[rhp]

[:princess:][puri_w body=mizugi ]
「矢部医生是和米卡亲一起行动的吧」[rhp]
[:princess:]
「难道说你们俩在交往吗？」[rhp]

[:mika:][mika body=mizugi kao=5 ]
「……！　哎呀讨厌。看起来像吗？」[rhp]

[:princess:][puri_w body=mizugi kao=4 hh=on ]
「！　果然是这样！大人……！！」[rhp]

[:mika:][mika body=mizugi kao=5 ]
「嘛~谁知道呢。[rhr]
_　我和老师也总是只顾着工作呢~」[rhp]
[:mika:][mika body=mizugi kao=13 ]
「那就请各位自行想象吧♡」[rhp]

[:princess:][puri_w body=mizugi kao=5 ]
「诶～，告诉我嘛～」[rhp]

[:mika:][mika body=mizugi kao=13 ]
「唔呼呼！这种女生间的私房话真开心呢！」[rhp]

[:princess:][puri_w body=mizugi kao=6 as=on ]
[font color=0x4682b4]
（被糊弄过去了……）[rhp]
[resetfont]

[:mika:][mika body=mizugi kao=14 ]
「那么接下来轮到公主了。[rhr]
_　公主有在意的人吗？」[rhp]

[:princess:][puri_w body=mizugi kao4 as=on hh=on= ]
「…………！呃……」[rhp]

[:mika:][mika body=mizugi kao=5 ]
「那边的女孩子只有沃尔佩克拉酱吧？[rhr]
_　莉莉虽然那样但其实是个男孩子哦」[rhp]
[:mika:]
「我嘴巴很严的♡　来嘛。快告诉我！」[rhp]

[:princess:][puri_w body=mizugi kao=8 as=on hh=on ]
「在、在意的人……！？」[rhp]

;----------------------------------------------------------------------------
;選択肢--------------------------------------------------------------------

;【い、いるわけないでしょそんな人！】
[glink clickse="btn_01.ogg" x="290" y="160" width="610" high="72" text="い、いるわけないでしょそんな人！" target="*sntk_a" graphic="glink_c.png" enterimg="glink_d.png"]
;【強いて言うなら……】
[glink clickse="btn_01.ogg" x="290" y="290" width="610" high="72" text="強いて言うなら……" target="*sntk_b" graphic="glink_a.png" enterimg="glink_b.png"]

[s]
;----------------------------------------------------------------------------
;----------------------------------------------------------------------------

;----------------------------------------------------------------------------
; い、いるわけないでしょそんな人！
;----------------------------------------------------------------------------
*sntk_a

[:princess:][puri_w body=mizugi kao=2 as=on hh=on ]
「怎、怎么可能有这种人！[rhr]
_　才认识两周左右而已啊」[rhp]

[jump target="*tutti2"]

;----------------------------------------------------------------------------
; 強いて言うなら……
;----------------------------------------------------------------------------
*sntk_b

[:princess:][puri_w body=mizugi kao=6 as=on ]
「……非要说的话……」[rhp]

;【ドロップ】
[glink clickse="btn_01.ogg" x="290" y="40" width="610" high="72" text="ドロップ" target="*sntk1_drop" graphic="glink_a.png" enterimg="glink_b.png"]
;【カイト】
[glink clickse="btn_01.ogg" x="290" y="160" width="610" high="72" text="カイト" target="*sntk1_kite" graphic="glink_c.png" enterimg="glink_d.png"]
;【クォードリリオン】
[glink clickse="btn_01.ogg" x="290" y="290" width="610" high="72" text="クォードリリオン" target="*sntk1_riri" graphic="glink_a.png" enterimg="glink_b.png"]
;【ハティ＆ジェット】
[glink clickse="btn_01.ogg" x="290" y="400" width="610" high="72" text="ハティ＆ジェット" target="*sntk1_hati" graphic="glink_c.png" enterimg="glink_d.png"]
[s]

;----------------------------------------------------------------------------
; ドロップ
;----------------------------------------------------------------------------

*sntk1_drop

[:princess:]
「多洛普又温柔又可靠，会觉得他很帅吧」[rhp]

; 海フラグ
[eval exp="f.a03_d = 1"]

[jump target="*tutti"]

;----------------------------------------------------------------------------
; カイト
;----------------------------------------------------------------------------

*sntk1_kite

[:princess:]
「和快斗在一起时很安心。[rhr]
_　虽然经常搞不懂他在想什么……」[rhp]

; 海フラグ
[eval exp="f.a03_k = 1"]

[jump target="*tutti"]

;----------------------------------------------------------------------------
; クォードリリオン
;----------------------------------------------------------------------------

*sntk1_riri

[:princess:]
「和夸德里利昂相处不用顾虑所以很轻松。[rhr]
_　虽然超级毒舌又变态」[rhp]

; 海フラグ
[eval exp="f.a03_r = 1"]

[jump target="*tutti"]

;----------------------------------------------------------------------------
; ハティ＆ジェット
;----------------------------------------------------------------------------

*sntk1_hati
「和哈蒂君他们在一起总是很开心，大概是那两个人吧！」[rhp]

; 海フラグ
[eval exp="f.a03_h = 1"]

[jump target="*tutti"]

;----------------------------------------------------------------------------
;----------------------------------------------------------------------------
;----------------------------------------------------------------------------

*tutti

[:mika:][mika body=mizugi kao=0 ]
「诶～。好普通呀。没有更让人心动的那种吗？」[rhp]

[:princess:][puri_w body=mizugi kao=6 as=on hh=on ]
「没有啦。才认识两周左右而已啊」[rhp]

;----------------------------------------------------------------------------


*tutti2

;------------------------------------------------------------------------------------------
; １回目選択肢でtutti2に飛んだ場合上の台詞読まないのでナンバーリセット
[voconfig sebuf=1 name=mika vostorage="mika/full/{number}.ogg" number=72]
[vostart]
;------------------------------------------------------------------------------------------

[:mika:][mika body=mizugi kao=6 ]
「真是的，好没劲」[rhp]

[:princess:][puri_w body=mizugi kao=6 as=on hh=on ]
「这和无聊不无聊的话题无关啦！」[rhp]

[:mika:][mika body=mizugi kao=13 ]
「嘛，算了！既然如此，[rhr]
_　和朋友热热闹闹地玩也挺开心的呢」[rhp]
[:mika:]
「希望米卡亲有天也能加入我们呢♡」[rhp]

[:princess:][puri_w body=mizugi ]
「当然可以呀！随时来玩吧！」[rhp]

[:mika:][mika body=mizugi kao=14 ]
「真开心♡　好嘞，顺便把那条铁道也拿走吧！」[rhp]

[:princess:][puri_w body=mizugi kao=0 ]
「啊……对哦。米卡亲是想抢走我们的铁道来着。[rhr]
_　因为你完全不像敌人，我都忘了这事」[rhp]

[:mika:][mika body=mizugi kao=5 ]
「呵呵♡　这方面你已经被老师喂饱了吧？」[rhp]
[:mika:]
「而且我们也并不是非要得到那条铁道不可」[rhp]

[:princess:][puri_w body=mizugi kao=4 as=on ]
「诶……是这样吗？」[rhp]

[:mika:][mika body=mizugi ]
「没错。夺取铁道终究只是手段，目的另有所在」[rhp]
[:mika:]
「我们呢，是希望你们从那条铁道下车哦」[rhp]

[:princess:][puri_w body=mizugi kao=0 ]
「…………？现在不就在下面吗」[rhp]

[:mika:][mika body=mizugi kao=2 ]
「可怜的孩子。你是被他骗了呢」[rhp]

[:princess:][puri_w body=mizugi kao=2 as=on ]
「米卡亲……？」[rhp]

[fbgm]
[off_all]

[::]
说出这话的米卡亲，表情看起来似乎在生气。[rhp]
虽完全不明白是针对谁、又为何生气，[rhr]
但看到米卡亲这样的表情实在意外，我困惑得说不出话来。[rhp]
然而只有米卡亲继续说着。[rhr]
带着比方才更添几分哀伤的表情。[rhp]

[:mika:][mika body=mizugi kao=3 ]
「…………已经够了吧。停下来吧、公主。[rhr]
_　在这里呆着、什么都没有哦」[rhp]
[:mika:]
「我明白的。不被信任这件事……[rhr]
_　但是、即便如此也请相信我们……」[rhp]


[off_all]

[:unknown:][s_playse storage="sausu/full/83.ogg" buf=1]
「能请你别说多余的话吗」[rhp]

[:princess:][puri_w body=mizugi kao=4 ]
「――――！　这个声音……」[rhp]

[off_puri]

[:mika:][mika body=mizugi kao=5 ]
「……哎呀！是奉行大人登场呢」[rhp]

[off_all]
[bgm storage="bgm_15.ogg"]

[:sausu:][sausu kao=2 ]
「米卡小姐……」[rhp]

[off_all]

[:mika:][mika body=mizugi kao=13 ]
「呵呵……♡」[rhp]

[off_all]

[::]
转身看到的是表情严峻的南。[rhp]
明明久别重逢、却似乎心情很差。[rhr]
从米卡亲的态度中感受到敌意是我的错觉吗？[rhp]

[chara_part name="sausu" body=mizugi kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="293" top="0" wait="false" time="150"]
[chara_part name="puri_w" body=mizugi kao=4 as=on ss=off hh=off hr=on hat=okan]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「南。为什么在这里？你不是说过不干涉我们的旅程、」[rhp]

[:sausu:][sausu kao=6 ]
「因为看你快要被蛊惑了才不得已来的」[rhp]

[:princess:][puri_w body=mizugi kao=8 as=on ]
「被蛊……！？哈、哈啊？」[rhp]

[off_all]

[chara_part name="sausu" body=mizugi kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time="150"]
[chara_part name="mika" body=mizugi kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="mika" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:sausu:]
「…………是约尔大人指使的吧」[rhp]

[:mika:][mika body=mizugi kao=11 ]
「呜呼呼♡　说指使太过分啦」[rhp]

[:sausu:][sausu kao=2 ]
「他的思想太过极端。盲目信奉很危险」[rhp]

[:mika:][mika body=mizugi kao=2 ]
「你不也是这么极端的」[rhp]

[:sausu:][sausu kao=4 as=on ]
「…………！」[rhp]

[:mika:]
「说是指使太失礼了」[rhp]
[:mika:]
「这是我自己的意愿。[rhr]
_　因为我想毁灭自己、所以才要阻挠这些孩子的旅程」[rhp]

[:sausu:][sausu kao=2 ]
「……真可怜。你根本不知道真正的幸福呢」[rhp]

[:mika:][mika body=mizugi kao=2 ]
「这个世界可没有你自以为的那么美好哦」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:sausu:][sausu kao=2 as=on ]
「………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[::]
一触即发的氛围令人窒息。[rhr]
他们之间究竟发生了什么……？[rhp]

[:princess:][puri_w body=mizugi kao=6 as=on ]
「那、那个」[rhp]

[:sausu:][sausu kao=2 ]
「别问。……与你旅途无关」[rhp]

[off_all]

[:mika:][mika body=mizugi kao=2 ]
「真任性。总是用对自己有利的方式引导一切」[rhp]
[:mika:]
「你所谓的幸福，只是你一个人的幸福」[rhp]

[off_mika]

[::]
……面对他们剑拔弩张的气氛，多余的发言令人踌躇。[rhp]
虽然不知缘由，[rhr]
但两人关系恶劣这点已然明了。[rhp]
意外存在交集的两人。[rhr]
他们究竟在谈论什么……？[rhp]

[off_sausu]

[:mika:][mika body=mizugi kao=13 ]
「……对不起公主」[rhp]
[:mika:]
「那家伙来了，今天就到此为止。[rhr]
_  美容院下次再去♡」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[off_mika]

[:princess:][puri_w body=mizugi kao=6 as=on ]
「诶、等等米卡亲……」[rhp]

[off_all]

;踵を返す
[se storage="leg_06.ogg"]

[::]
「再见」单方面告别后，[rhr]
米卡亲独自朝着来时的方向离去。[rhp]
被留在原地目瞪口呆的我，[rhr]
向身旁的南投去求解的目光。[rhp]

[sausu kao=6 ]

————他，似乎在生气。[rhp]

总是挂着浅笑的嘴角，[rhr]
今日也紧紧抿着。[rhp]
那双眼睛死死盯着米卡亲远去的背影。[rhp]

[:princess:][puri_w body=mizugi kao=8 as=on ]
「南……？」[rhp]

[:sausu:][p_s_19][sausu kao=0 as=on ]
「――――！　啊……」[rhp]

[off_all]

[::]

他注意到我的视线后猛然一惊，[rhr]
这才重新挂上往常的笑容。[rhp]
明显能看出是在强颜欢笑……[rhp]

[chara_part name="sausu" body=mizugi kao=14 as=on ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="293" top="0" wait="false" time="150"]
[chara_part name="puri_w" body=mizugi kao=3 as=on ss=off hh=off hr=on hat=okan]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:sausu:][p_s_31]
「……啊哈哈！现在做美容护理对公主来说还太早吧？[rhr]
_　你现在的样子已经足够漂亮可爱啦」[rhp]

[:princess:]
「…………你和米卡亲关系不好吗？」[rhp]

[:sausu:][p_s_30][sausu kao=13 ]
「没啊。不算差啦。就是有点小争执」[rhp]

[off_all]

[::]
明明刚才气氛那么剑拔弩张，怎么可能只是这样。[rhp]
他有不想说……不对，是说不出口的事情。[rhp]
……但就算我再怎么追问，[rhr]
这个人肯定什么都不会告诉我了吧。[rhp]

[:princess:][puri_w body=mizugi kao=13 ]
「……希望能早日和好哦。惹女孩子生气会记恨很久的」[rhp]

[:sausu:][p_s_02][sausu kao=13 ]
「那可真可怕。我会注意的」[rhp]
[sausu ]
「……那我就先告辞了。[rhr]
_　公主也去找大家玩吧」[rhp]

[:princess:][puri_w body=mizugi　kao=4 ]
「这么快就走？难得的机会南也一起来嘛」[rhp]

[:sausu:][p_s_27][sausu kao=13 ]
「我听听往事就满足了。只要你们玩得开心就好」[rhp]
[sausu ]
「那么再见……祝旅途愉快，公主」[rhp]

;****************************************
[bg_magic_d color=0xffffff]
;****************************************

[::]
继米卡亲之后南也离开了，回过神来只剩我独自一人。[rhp]

[:princess:][puri_w body=mizugi kao=3 ]
「…………好想和大家好好相处啊」[rhp]

[off_puri]

[::]
我曾以为这是个万事如意、绝不会发生讨厌之事的世界。[rhp]
既然是梦中的世界，只要不吵架就好了。[rhr]
如果发生冲突，用魔法解决掉不就好了。[rhp]
……这样想是不对的事情吗……[rhp]

;****************************************
[fbgm]
[s_mask time=2000]
[set_n storage="sea_11.jpg"]
;****************************************

[bgm storage="bgm_07.ogg"]

[:princess:]
「呜……」[rhp]

[::]
这是个月色明亮的夜晚。[rhp]
身体传来吱嘎作响的疼痛，让我在深夜里醒了过来。[rhp]

[:princess:][puri_w kao=6 as=on ]
「呜……肌肉酸痛……？」[rhp]

[off_puri]

[::]
后来和南分开后，我也参加了沙滩排球，[rhr]
或许是太久没运动的缘故，立刻就肌肉酸痛了……[rhp]

[:princess:]
[font color=0x4682b4]
（虽说很久没运动，但完全不记得了）[rhp]
[resetfont]

[::]
不过正因为是自己的身体，才能明白某些事。[rhr]
有大量初次使用的肌肉的感觉，简直糟糕透了……[rhp]
我从前肯定是个超级宅女吧……[rhp]

[:princess:]
[font color=0x4682b4]
（不知怎的完全清醒了……）[rhp]
[resetfont]

[::]
怎么办。要是能找人消磨时间就好了，[rhr]
但这个时间大家肯定都睡了……[rhp]

[:princess:][puri_w kao=0 ]
「……！」[rhp]

[off_puri]

;****************************************
#
[bg_rule storage="sky_07.jpg" rule="007.png" time=1500]
;****************************************

突然有光从窗户照进来，我望向外边。[rhp]
满月从云间露出脸，照亮了夜晚的海面。[rhp]
总觉得一时半会儿睡不着了，[rhr]
去海滩散步似乎也不错。[rhp]

;****************************************
[bg storage="sea_11.jpg" time=1000]
;****************************************
[filter layer="1" brightness="60"]

[:vulpecula:][p_vl_17][peku kao=11 hh=on ]
「呼……呼……、……嗯～……博士……」[rhp]

[:princess:][puri_w kao=13 ]
[font color=0x4682b4]
（呵呵。梦里也在玩耍吗）[rhp]
[resetfont]

[off_all]

;ドア閉める
[se storage="door_02.ogg"]

[::]
为隔壁床铺上幸福安睡的沃尔佩克拉[rhr]
重新盖好滑落的毛巾被后，我轻轻走出房间……[rhp]

;****************************************
[set_b storage="sea_02n.jpg"]
;****************************************

[:princess:][puri_w kao=1 hh=on ]
[font color=0x4682b4]
（白昼的海很美，但夜晚的海同样动人……！）[rhp]
[resetfont]

[off_puri]

[::]
与白天截然不同的寂静海滩上，[rhr]
只能听见我踩踏沙粒的声响。[rhp]
凝视着月光照耀的海面，[rhr]
怀揣着些许成熟的心绪缓步前行。[rhp]

;騒がしい水音
[se storage="se2_11.ogg"]

[:princess:][puri_w kao=0 ]
「…………嗯？」[rhp]

[fse]
[off_puri]

[::]
什么？这个声音。[rhr]
从海的方向传来……是有人在游泳的动静？[rhp]

[:princess:][puri_w kao=8 as=on ]
「……为、为什么这种深夜……？」[rhp]

[::]
[off_puri]

;****************************************
;沖
[bg_rule storage="sea_03n.jpg" rule="002.png" time=1000]
;****************************************

不巧外面一片漆黑，月光下分辨不出对方身份。[rhp]
虽、虽然不可能是幽灵……[rhr]
但莫名有些害怕起来了……[rhp]

;****************************************
;全景
[bg_rule storage="sea_02n.jpg" rule="002.png" time=1000]
;****************************************

[:princess:][puri_w kao=14 as=on ss=on ]
「啊，啊哈哈！说起来我也是已死之人。[rhr]
_　同为幽灵有什么好怕的―――」[rhp]

[off_puri]

[:unknown:]
[font size=27]
「！？什么人！」[rhp]
[resetfont]

[:princess:][puri_w kao=8 as=on ss=on ]
[font color=0x4682b4]
（呀！！居、居然搭话了……）[rhp]
[resetfont]
[:princess:][puri_w kao=4 as=on ]
「…………真是的」[rhp]

[off_puri]

[::]
循声望去，那里站着……[rhp]


[:yabu:][p_yb_19][yabu body=mizugi kao=4 as=on pnt=off ]
「―――！公主？」[rhp]

[:princess:][puri_w kao=4 as=on ]
「矢部医生！？」[rhp]

[off_all]

[::]
那道被误认作幽灵的声音主人，[rhr]
从海里上来的矢部医生浑身湿透了。[rhp]

;****************************************
[set_yy storage="sea_01n.jpg"]
;****************************************

[chara_part name="yabu" body=mizugi kao=1 as=off ss=off hh=off hr=on pnt=on ]
[chara_show name="yabu" layer="1" width="437" height="720" left="421" top="0" wait="false" time="150"]
[chara_part name="puri_w" body=base kao=5 as=on ss=off hh=off hr=on hat=okan]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「―――不过真的吓了一跳。[rhr]
_　矢部医生，你游泳到这么晚吗？」[rhp]

[:yabu:][p_yb_02][yabu pnt=on body=mizugi kao=5  ]
「算是吧！为了下次一定要赢过近海的海伊的魔性自由泳，[rhr]
_　正在进行秘密特训」[rhp]
[:yabu:][yabu pnt=on body=mizugi kao=6  ]
「你才是，为什么一个人在这种地方？夜间的海边很危险哦」[rhp]

[:princess:][puri_w kao=12 as=on ]
「因为肌肉酸痛太严重。睡不着所以出来散步」[rhp]

[:yabu:][p_yb_30][yabu pnt=on body=mizugi kao=2  ]
「那就更不应该四处走动了吧……」[rhp]

[:princess:][puri_w kao=13 as=on ]
「哎呀——老老实实待着也很痛苦不由自主就……」[rhp]

[:yabu:][p_yb_03][yabu pnt=on body=mizugi kao=6  ]
「年轻人这么没用可不行啊。运动不足啊，公主」[rhp]

[:princess:][puri_w kao=5 as=on ]
「那个…对不起……」[rhp]
[:princess:]
「啊！对、对了，米卡亲不在吗？[rhr]
_　听说你们总是形影不离的」[rhp]

[:yabu:][p_yb_01][yabu pnt=on body=mizugi kao=7  ]
「她回去了。还要赶末班电车」[rhp]
[:yabu:][yabu pnt=on body=mizugi kao=11  ]
「我们工作和私生活都分得很清楚！[rhr]
_　工作时间外禁止加班的话，夜间分开行动也是理所当然」[rhp]

[:princess:][puri_w kao=0 ]
[font color=0x4682b4]
（本以为是个笨蛋角色，没想到这种地方意外认真）[rhp]
[resetfont]

[:yabu:][yabu pnt=on body=mizugi kao=6  ]
「……………………」[rhp]

[:princess:][puri_w kao=6 ]
「……？怎么了？一直盯着我看」[rhp]

[:yabu:][p_yb_34][yabu pnt=on body=mizugi kao=3 ]
「…………没什么。抱歉」[rhp]
[:yabu:]
「我在犹豫该不该问你，白天没去美容院就回来的米卡亲[rhr]
_　哭泣的原因」[rhp]

[:princess:][puri_w kao=4 as=on ]
「咦……你说我哭了？」[rhp]

[off_all]

[::]
…………白天与南的那件事在脑海中闪过。[rhp]
我哭了……？[rhr]
明明像什么都没发生似的潇洒离开了啊？[rhp]

[chara_part name="yabu" body=mizugi kao=0 as=off ss=off hh=off hr=on pnt=on ]
[chara_show name="yabu" layer="1" width="437" height="720" left="421" top="0" wait="false" time="150"]
[chara_part name="puri_w" body=base kao=2 as=on ss=off hh=off hr=on hat=okan]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:yabu:][yabu pnt=on body=mizugi kao=3  ]
「害得沙滩排球惨败。为了让她停止哭泣，[rhr]
_　不得不弃权去买各种刨冰」[rhp]
[:yabu:]
「……她说南受到的洗脑比想象中更严重」[rhp]

[:princess:][puri_w kao=6 as=on ]
「洗、洗脑？南？才没有被做那种事啦」[rhp]

[:yabu:][p_yb_23][yabu pnt=on body=mizugi kao=6  ]
「别担心。这我自然明白。[rhr]
_　只是她似乎对夜的思想有些过度倾慕……」[rhp]

[:princess:][puri_w kao=0 as=on ]
「夜？」[rhp]

[off_all]

[::]
……这是在说什么？[rhr]
应该不是在说时间段吧…不至于。[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------
　
[:yabu:][yabu pnt=on body=mizugi kao=0  ]
「……说起来公主。[rhr]
_　我原本就有很多事想问你」[rhp]

[:princess:][puri_w kao=4 as=on ]
「啊？突、突然怎么了」[rhp]

[:yabu:]
「这个世界快乐吗」[rhp]

[:princess:][puri_w kao=0 ]
「…………？很快乐呀。超级快乐」[rhp]

[:yabu:][yabu pnt=on body=mizugi kao=12  ]
「是吗。看你气色也确实不错。[rhr]
_　完全不像知道自己已经死了的人类该有的精神劲」[rhp]

[:princess:][puri_w kao=7 ]
「嗯哼。反正死时的事完全记不得，[rhr]
_　也没什么悲伤的感觉啦」[rhp]

[:yabu:]
「再好不过。再好的医生，也最盼着没有病人可医」[rhp]

[:princess:][puri_w ]
「……矢部医生你一个人的时候性格完全不一样呢」[rhp]

[:yabu:][yabu pnt=on body=mizugi kao=6  ]
「嗯？」[rhp]

[:princess:][puri_w kao=11 ]
「该怎么说呢，感觉很酷很成熟」[rhp]

[:yabu:][yabu pnt=on body=mizugi kao=2 as=on  ]
「那都是被你们害的！没常识的家伙实在太多了」[rhp]
[:yabu:]
「如果你们能稍微懂点道理就没必要敌对。[rhr]
_　你们这群人真的完全不动脑子愚不可及」[rhp]

[:princess:][puri_w kao=6 ]
「又来了？说什么要夺取铁道之类的」[rhp]
[:princess:]
「为什么要做那种事呢。我们明明没有给任何人添麻烦……」[rhp]

[:yabu:][yabu pnt=on body=mizugi kao=6  ]
「确实给你添麻烦了。[rhr]
_　擅自被霸占后，夜似乎非常困扰」[rhp]

[:princess:][puri_w kao=6 ]
「又出现了……刚才也说过吧。[rhr]
_　那个『夜』究竟是什么？是人名吗？」[rhp]

[:yabu:][yabu pnt=on body=mizugi  ]
「算是这个世界的神明般的存在」[rhp]

[:princess:][puri_w kao=0 ]
[font color=0x4682b4]
（神明……和南一样）[rhp]
[resetfont]

[:yabu:][yabu pnt=on body=mizugi kao=3  ]
「夜并不乐见你们的旅程。[rhr]
_　因此我们奉命强夺铁道以强制终止」[rhp]

[:princess:][puri_w kao=2 as=on ]
「怎么可以……！」[rhp]

[off_all]

[::]
正当要反驳时。[rhr]
矢部医生立刻插话道「但是」。[rhp]

[:yabu:][yabu pnt=on body=mizugi kao=6  ]
「说这种话可能不太合适，但我觉得彼此彼此」[rhp]
[:yabu:]
「擅自闯入他人庭院还肆意破坏的行为[rhr]
_　和不由分说放火驱逐的行为，两者都野蛮至极」[rhp]
[:yabu:]
「可惜我这个名医天生心软，对弱者总是慈悲为怀。[rhr]
_　有时候追赶你们也会让我心痛」[rhp]
[:yabu:][yabu pnt=on body=mizugi kao=3  ]
「……前任就是因为精神崩溃，才把这个职责推给了我」[rhp]

[:princess:][puri_w kao=0 ]
「那是谁？那人也是矢部医生的同伴吗？」[rhp]

[off_all]

[::]
面对这个问题，矢部医生只是低垂眼帘不予回应。[rhr]
或许这是不该问的事？[rhp]
说到底……连同事都选择辞职，矢部医生他们的工作竟如此艰难吗。[rhr]
还是说，多洛普他们的决心过于坚定呢。[rhp]
……看来他们之间那看似随意的关系，实际上比预想的更为盘根错节。[rhp]

[:princess:][puri_w kao=3 as=on ]
「…………矢部医生也想过要辞职吗？」[rhp]

[:yabu:][yabu pnt=on body=mizugi kao=2  ]
「这做不到。[rhr]
_　虽说确实会给你们添麻烦，但我也理解夜的愤怒」[rhp]
[:yabu:]
「权衡利弊后，我决定站在夜这边。仅此而已」[rhp]

[:princess:][puri_w kao=0 ]
「～～～～～哼嗯……」[rhp]

[:yabu:][yabu pnt=on body=mizugi kao=3  ]
「如果你们主动退出，就无需在你们和夜的愿望间权衡取舍了。[rhr]
_　所以偏帮一方尽早结束这场争执」[rhp]
[:yabu:]
「……也不必再看米卡亲流泪了吧」[rhp]

[:princess:][puri_w ]
「矢部医生喜欢米卡亲吗？」[rhp]

[:yabu:][yabu pnt=on body=mizugi kao=5  ]
「……哈！唯独这件事绝对不可能。[rhr]
_　我和她都是为工作而活的同志」[rhp]

[:princess:][puri_w kao=5 ]
「这话，米卡亲也说过哦」[rhp]

[:yabu:][yabu pnt=on body=mizugi kao=2 as=on  ]
「哈！！我、我才没抄袭！？是我的原创啊！」[rhp]

[:princess:][puri_w ]
「我知道啦……其实矢部医生你挺温柔的呢」[rhp]
[:princess:]
「但对不起。我暂时不会从银河铁道下车。[rhr]
_　还想和大家去更多地方旅行呢」[rhp]

[:yabu:][yabu pnt=on body=mizugi kao=3  ]
「是么……不过单凭你一人也决定不了吧」[rhp]

[:princess:][puri_w kao=14 ]
「而且旅行途中还能遇见更多有趣的医生吧！[rhr]
_　酷酷的医生虽然帅，但我更喜欢那样的呢」[rhp]

[:yabu:][yabu pnt=on body=mizugi kao=2 as=on  ]
「~~~~~！笨、笨蛋才要………」[rhp]

[off_all]

[::]
矢部医生这么说，可我真没戏弄他。[rhr]
反而因为刚才的对话，我对矢部医生稍稍改观了。[rhp]
矢部医生虽然很爱自己，[rhr]
但更热爱他人。[rhp]
是否名医暂且不论……[rhr]
说他是医生，或许并非完全错误。[rhp]


[:yabu:][yabu pnt=on body=mizugi kao=12 as=on  ]
「……算了。今天的话就当牢骚忘了吧」[rhp]

[:princess:][puri_w ]
「虽然我觉得忘不掉……[rhr]
_　不过我也会对大家保密矢部医生的事」[rhp]
[:princess:]
「要是被医生的话感动到，旅行结束就太可惜了。[rhr]
_　暂且不论大家，我的铁道之旅才刚刚开始呢！」[rhp]
[:princess:][puri_w kao=13]
「想去的地方和想做的事，还有好多好多呢！」[rhp]

[:yabu:][yabu pnt=on body=mizugi kao=1  ]
「…………哈哈。死后的你还真是狡猾啊」[rhp]

[:princess:][puri_w kao=4 ]
「……！　医生也认识生前的我吗？」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:yabu:][yabu pnt=on body=mizugi kao=3 as=on  ]
「………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:princess:][puri_w kao=5 ]
「…………、果然矢部医生也无法说出来啊。[rhr]
_　这方面和多洛普他们是一样的」[rhp]

[:yabu:][yabu pnt=on body=mizugi kao=11  ]
「………………、就当是这样吧」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[off_all]

[::]
微微苦笑的矢部医生，不知为何看起来有些寂寞。[rhp]
…………短暂的沉默。[rhp]
气氛莫名变得尴尬起来，[rhr]
正当我准备随意找个话题时―――[rhp]

[:yabu:][p_yb_06][yabu pnt=on body=mizugi kao=1  ]
「好了。我这就离开此地。[rhr]
_　暂时要分别了，公主」[rhp]

[:princess:][puri_w kao=7 ]
「不再来对战了吗？」[rhp]

[:yabu:][p_yb_01][yabu pnt=on body=mizugi kao=12  ]
「啊。米卡亲也要休假一阵子，我一个人也撑不起来吧」[rhp]

[:princess:][puri_w kao=13 ]
「因为是废柴？」[rhp]

[:yabu:][p_yb_18][yabu pnt=on body=mizugi kao=2 as=on  ]
「不是的！！是因为人手不足！！」[rhp]

[off_all]

[:princess:]
「晚安～」[rhp]

[:yabu:][p_yb_09]
「给我听完别人说话啊！！」[rhp]

[yabu pnt=on body=mizugi kao=2 as=on  ]
「…………真是的……」[rhp]

[off_all]

[:princess:]
「好痛……！因为散步的缘故，肌肉酸痛更严重了……」[rhp]

[:yabu:]
「走路姿势像螃蟹一样歪歪扭扭的……」[rhp]
[:yabu:][yabu pnt=on body=mizugi kao=1 as=on ]
「…………哎呀呀。名医的代价可不菲呢」[rhp]


;****************************************
[free_filter ]
[fbgm]
[set_00 storage="sea_01.jpg"]
;****************************************
[bgm storage="bgm_01.ogg"]

[::]
转眼间时间流逝，终于到了第3天。[rhr]
在这片海上度过的最后一日已然来临。[rhp]

[:vulpecula:][p_vl_04][peku body=mizugi kao=8 ]
「希梅缇努丝～。昨天晚上啊，[rhr]
_　在床铺上痛得死去活来的但没～事吧？」[rhp]

[off_all]

[::]
面露担忧的佩克缇努丝，不安地窥探着我的神情。[rhp]
由于与她共用一个心室，[rhr]
说不定呻吟声给她添麻烦了。[rhp]
――――但是！[rhp]

[:princess:][puri_w body=mizugi kao=5 hh=on ]
「完全没事啦，这个！」[rhp]

[:vulpecula:][p_vl_08][peku body=mizugi kao=4 as=on ]
「噢！？　精神十足嘛！　为什么为什么呀！？」[rhp]

[:princess:][puri_w body=mizugi kao=11 hh=on ]
「这个啊，虽然完全搞不懂为什么，[rhr]
_　睡一觉就彻底恢复活力啦。年轻真可～怕」[rhp]

[:vulpecula:][p_vl_14][peku body=mizugi kao=14 hh=on ]
「可～怕！」[rhp]

[:princess:][puri_w body=mizugi kao=13 hh=on ]
「总之太好了！　这样最后一天也能好好玩耍了！」[rhp]

[:vulpecula:][p_vl_01][peku body=mizugi kao=14 hh=on ]
「嗯！　太好了呢，小希～！」[rhp]

[off_all]

[:quadrillion:][p_r_03][riri body=mizugi kao=6 as=on ]
「干嘛啦，兴奋过头。[rhr]
_　人家可是在烈日下站到虚脱了耶」[rhp]

[off_riri]

[chara_part name="hakase" body=mizugi kao=3 as=on ss=on hh=off hr=on msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time="150"]
[chara_part name="hati" body=mizugi kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:darknebula:][p_da_11]
「…………………………」[rhp]

[:heartshape:][p_h_02]
「全力较量的代价就是连吵闹的力气都没了呢，博士……！[rhr]
_　虽这么说但其实排球也没打那么久啊！」[rhp]
[:heartshape:][hati body=mizugi kao=5 ]
「这种从不反省平日缺乏运动的莽撞体育精神！[rhr]
_　老子觉得这玩意儿超重要的啊！」[rhp]

[:darknebula:][p_da_32]
「啊，谢谢……」[rhp]

[off_all]

[chara_part name="hakase" body=mizugi kao=8 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time="150"]
[chara_part name="peku" body=mizugi kao=2 as=on ss=on hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time="150"]

[:vulpecula:][p_vl_21]
「博士～～！　你怎么躺平了啦！[rhr]
_　今天不是说好要Shopping的吗！？」[rhp]
[:vulpecula:]
「佩奇可是很期待的！一定要去哦！？」[rhp]

[:darknebula:][p_da_18][hakase body=mizugi msk=off kao=11 as=on ss=on ]
「知、知道了……！[rhr]
_　这点肌肉酸痛，我会想办法的……」[rhp]

[off_all]

[:princess:][puri_w body=mizugi ]
「博士和佩奇要去浮潜啊。其他人有什么安排？」[rhp]

[chara_part name="riri" body=mizugi kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" wait="tfalse" left="208" top="0" time="150"]
[chara_part name="kite" body=mizugi kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time="150"]

[:quadrillion:][p_r_17][riri body=mizugi kao=7 ]
「这个嘛。自由活动不就好了？[rhr]
_　到昨天为止大家已经集体行动很久了，最后就随个人喜好吧」[rhp]

[:kite:][p_k_01]
「赞成～」[rhp]

[:princess:][puri_w body=mizugi kao=6 as=on ]
[font color=0x4682b4]
（果然都是个人主义呢。[rhr]
_　我其实更喜欢热闹些的……）[rhp]
[resetfont]

[off_all]

[:drop:][p_d_02][drop hat=sea kao=1]
「那么从此刻到晚上就定为自由活动时间吧。[rhr]
_　今晚晚餐很特别，请各位19点前返回旅馆集合哦」[rhp]

[off_all]

[::]
在多洛普的宣布声中，我们各自展开了行动。[rhp]
经历诸多波折后，我们的度假胜地最终日拉开了序幕……！[rhp]

;****************************************
[fbgm]
[bgm storage="bgm_24.ogg"]
[set_time_d]
;****************************************

[::]
――――那么。[rhp]
虽说最终日开始了是好事啦……[rhp]

[:princess:]
[font color=0x4682b4]
（独自呆着好寂寞，不如去找谁作伴吧……）[rhp]
[resetfont]

[::]
如此想着，我前往的目的地是―――[rhp]


[if exp="f.a03_d == 1 "]
[jump target="*ev_03_drop"]

[elsif exp="f.a03_k == 1"]
[jump target="*ev_03_kite"]

[elsif exp="f.a03_r == 1"]
[jump target="*ev_03_riri"]

[elsif exp="f.a03_h == 1"]
[jump target="*ev_03_hati"]

[else]
[jump target="*ev_03_hkpk"]
[endif] 

;----------------------------------------------------------------------------------------
;ドロップ
;----------------------------------------------------------------------------------------

*ev_03_drop

;****************************************
[set_00 storage="sea_07.jpg"]
;****************************************

[::]
犹豫过后，我决定去拜访多洛普。[rhp]
他正在摆放着沙滩床的休息区里，似乎正在看书。[rhr]
我尽量不惊动他，小心翼翼地试着搭话。[rhp]

[:princess:][puri_w body=mizugi ]
「嗨，多洛普」[rhp]

[:drop:][p_d_36][drop hat=sea kao=0 ]
「啊咧，公主。您怎么了？」[rhp]

[off_all]

[::]
稍微挺直脊背，合上书本将脸转向这边的多洛普。[rhr]
莫非打扰到你了？真是有点抱歉。[rhp]

[:princess:][puri_w body=mizugi ]
「不知道该做什么好，来看看多洛普的情况。[rhr]
_　我还在想该不会又不知悔改地工作了吧」[rhp]

[:drop:][p_d_01][drop hat=sea ]
「请不用担心。承蒙关心，现在正读着书稍作休息。[rhr]
_　毕竟还有博士和杰特先生的忠告……身体是革命的本钱嘛」[rhp]

[:princess:][puri_w body=mizugi kao=5 as=on ]
「难得来到海边，去游游泳或在沙滩玩玩多好」[rhp]

[:drop:][p_d_17][drop hat=sea kao=13 as=on ]
「唔……那种娱乐方式我不太懂……[rhr]
_　果然还是按老样子读书更让人安心」[rhp]

[:princess:][puri_w body=mizugi kao=5 as=on ]
「……该不会在铁道工作时也除了工作就整天看书吧？」[rhp]

[:drop:][p_d_23][drop hat=sea ]
「基本如此。因为南总会送来书籍」[rhp]

[:princess:][puri_w body=mizugi kao=0 ]
「嘿～原来南他……」[rhp]

[:drop:][p_d_31][drop hat=sea kao=13 ]
「能学到各个世界的知识非常有趣。[rhr]
_　这对提议旅行地点也很有参考价值呢」[rhp]

[:princess:][puri_w body=mizugi kao=13 ]
「呵呵！这么听来，简直连读书都像工作似的」[rhp]
[:princess:]
「而且若喜欢读书，和博士应该很谈得来。[rhr]
_　机会难得的话，不如试着和他一起玩呢」　[rhp]

[:drop:][p_d_13][drop hat=sea kao=8 as=on ]
「怎么会！您太谦虚了。博士可是特别的存在啊」[rhp]

[:princess:][puri_w body=mizugi kao=0 ]
「是吗？虽然我不是很明白」[rhp]

[:drop:]
「呼……不过还真是热呢！不愧是南方岛屿」[rhp]

[:princess:][puri_w body=mizugi kao=5 as=on ]
「谁让你不穿泳衣这副打扮。[rhr]
_  要我去买点什么饮料吗？」[rhp]

[:drop:][p_d_11][drop hat=sea kao=8 as=on ]
「啊……不、不用！对不起，我不是这个意思」[rhp]

[:princess:][puri_w body=mizugi ]
「我也想喝所以没关系啦。顺带而已别在意」[rhp]

[:drop:][p_d_26][drop hat=sea kao=6 as=on ]
「不不，也不是这个意思。作为接待方的我本该」[rhp]

[:princess:][puri_w body=mizugi kao=14 ]
「对了。那，一起走吧！」[rhp]

[:drop:][p_d_19][drop hat=sea kao=4 as=on ]
「―――！哎……」[rhp]

[:princess:][puri_w body=mizugi ]
「这样就没意见了吧？既能帮你拿饮料的多洛普，[rhr]
_  又能让我跟着去对吧！」[rhp]

[:drop:][p_d_22][drop hat=sea kao=0 as=on ]
「确、确实是这样……」[rhp]

[:princess:][puri_w body=mizugi kao=14 ]
「好！来，把鞋脱了卷起裤脚！[rhr]
_  这样更凉快也方便走路」[rhp]

[:drop:][p_d_05][drop hat=sea kao=6 as=on ]
「……照这架势，就算拒绝也会被强行带走吧」[rhp]

[:princess:][puri_w body=mizugi kao=13 ]
「哼哼，这不是很懂嘛」[rhp]

[:drop:][p_d_09][drop hat=sea kao=6 as=on ]
「真是的～～～！请不要得寸进尺！[rhr]
_  我说过很多次了，只要能完成工作就……」[rhp]

[:princess:][puri_w body=mizugi ]
「啊对了！等回到这里后，也借我一本书吧」[rhp]

[:drop:][p_d_19][drop hat=sea kao=8 as=on ]
「咦？海边也没关系吗？」[rhp]

[:princess:]
[puri_w body=mizugi kao=13 ]
「沐浴着海风聆听浪涛声，优雅地阅读书籍……[rhr]
_　这不也是享受大海的方式之一吗」[rhp]

[:drop:][drop hat=sea kao=0 as=on ]
「…………！」[rhp]

[:princess:][puri_w body=mizugi ]
「如果多洛普不愿意陪我的话，[rhr]
_　那就由我来陪多洛普好了」[rhp]
[:princess:][puri_w body=mizugi kao=5 ]
「既然是多洛普奉行顾客至上，那应该阻止不了我的行动吧！」[rhp]

[:drop:][drop hat=sea kao=4 as=on ]
「…………」[rhp]
[:drop:][p_d_31][drop hat=sea kao=14 hh=on ]
「…………噗、哈哈哈！」[rhp]

[:princess:][puri_w body=mizugi kao=4 as=on ]
「！　什、什么？」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:drop:][drop hat=sea kao=5 ]
「你真是……个有趣的人呢」[rhp]

[:princess:][puri_w body=mizugi kao=11 as=on hh=on ]
「……！　哼、哼哼。那当然。你总算明白了吗」[rhp]

[:drop:][drop hat=sea kao=11 ]
「请脱鞋，把脚…………，这样可以了吗？」[rhp]

[:princess:][puri_w body=mizugi kao=13 ]
「嗯！完美！」[rhp]

[:drop:][drop hat=sea kao=13 ]
「那么我带您去售货亭。请跟我来，公主！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[off_all]

[::]
此时多洛普的表情，看起来比先前明朗了许多。[rhr]
果然他心底里也是渴望有人陪伴的吧。[rhp]

[:princess:]
[font color=0x4682b4]
（嘿嘿……！主动邀请他真是太好了！）[rhp]
[resetfont]

;****************************************
#
[bg storage="sky_04.jpg" time=1000]
;****************************************

今后也要时不时地，[rhr]
在多洛普固执时主动搭话。[rhp]
既然是共赴旅程，希望能和大家一起开怀欢笑。[rhp]
今后不管被怎样推辞，我都绝不会退让！[rhp]

[jump target="*tutti3"]

;-------------------------------------------------------------------------------------------
;カイト
;-------------------------------------------------------------------------------------------

*ev_03_kite

;****************************************
[set_00 storage="sea_08.jpg"]
;****************************************

[:princess:][puri_w body=mizugi ]
「快斗！」[rhp]

[:kite:][p_k_02][kite body=mizugi ]
「嗯……啊，是公主啊」[rhp]

[:princess:][puri_w body=mizugi ]
「你坐在这里干什么呢？」[rhp]

[:kite:][p_k_17][kite body=mizugi kao=12 ]
「啊…………」[rhp]
[:kite:]
「…………在冥想？」[rhp]

[:princess:][puri_w body=mizugi kao=11 as=on ]
「来海边干什么啊……」[rhp]
[:princess:][puri_w body=mizugi ]
「嘛算了。我一个人也挺无聊的，要一起行动吗？」[rhp]

[:kite:][kite body=mizugi kao=7 ]
「只会让你更无聊哦，不介意的话请便」[rhp]

[:princess:][puri_w body=mizugi kao=13 ]
「快斗你不去海里玩吗？[rhr]
_　像哈蒂君他们那样去游泳多好」[rhp]

[:kite:][kite body=mizugi kao=6 ]
「不要。会晒黑的」[rhp]

[:princess:][puri_w body=mizugi kao=6 as=on]
「真是个御宅族……」[rhp]

[:kite:][p_k_02][kite body=mizugi kao=3 ]
「……其实佩库拉和博士他们[rhr]
_　之前约我去浮潜的」[rhp]

[:princess:][puri_w body=mizugi kao=5 ]
「咦！那不是挺好嘛。听起来很有趣！」[rhp]

[:kite:][p_k_01][kite body=mizugi kao=6 ]
「但我拒绝了。那种连体泳衣配神秘面具的打扮实在太土了」[rhp]

[:princess:][puri_w body=mizugi kao=6 ]
「诶～～。去嘛去嘛，我也陪你一起呀」[rhp]

[:kite:][p_k_27]
「不要。想去你就自己去。我要在这里睡觉」[rhp]

[:princess:][puri_w body=mizugi kao=5 ]
「………………。哼哼，我懂了」[rhp]
[:princess:]
「「说泳衣什么的都是借口，其实快斗你呀"[rhr]
_　临到要下海的时候害怕了对吧！」[rhp]

[:kite:][p_k_10][kite body=mizugi kao=2 ]
「哈？」[rhp]

[:princess:]
「表情僵硬了！果然是这样」[rhp]

[:kite:][p_k_09][kite body=mizugi kao=6 ]
「才不是。忘了我昨天和矢部经历了一场激战吗」[rhp]

[:princess:][puri_w body=mizugi kao=6++ ]
「啊对哦。激战姑且不论，你游过泳来着」[rhp]

[:kite:][kite body=mizugi kao=11 ]
「这叫战术胜利。我可是银河诸葛亮」[rhp]

[:princess:][puri_w body=mizugi kao=11 as=on ]
「是是。您说得对」[rhp]
[:princess:][puri_w body=mizugi kao=7 ]
「………………嘛、既然那么讨厌的话也没办法呢」[rhp]

[:kite:][p_k_13][kite body=mizugi ]
「嗯？」[rhp]

[:princess:][puri_w body=mizugi ]
「浮潜、其实我有点兴趣的。[rhr]
_　快斗不去的话就我一个人去……」[rhp]

[:kite:][p_k_17][kite body=mizugi kao=6 ]
「啊—」[rhp]

[off_all]

[::]
快斗打断我的话提高音量说道。[rhr]
他的眼睛斜睨向下方，看起来像是在闹别扭。[rhp]

[chara_part name="kite" body=mizugi kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="383" top="0" wait="false" time="150"]
[chara_part name="puri_w" body=mizugi kao=13 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「怎么了？不想去的话我不会强迫你……」[rhp]

[:kite:][kite body=mizugi kao=3 ]
「……嗯……只要不必穿那种装扮的话，[rhr]
_　去海边浅滩走走倒是可以？」[rhp]

[:princess:][puri_w body=mizugi kao=7 ]
「真的可以？不用冥想了吗？」[rhp]

[:kite:][kite body=mizugi kao=6 ]
「没关系。闭眼的时候被哈蒂他们恶作剧就糟透了」[rhp]

[off_kite]

[:princess:][puri_w body=mizugi kao=11 ]
[font color=0x4682b4]
（呵呵呵。我就知道会这样……这个口是心非的寂寞鬼）[rhp]
[resetfont]

[off_all]

[:kite:][kite body=mizugi kao=7 ]
「快走啦。发什么呆」[rhp]

[:princess:][puri_w body=mizugi kao=13 ]
「啊、嗯！这就来！」[rhp]

;****************************************
[set_00 storage="sea_05.jpg"]
;****************************************

[::]
于是快斗慢吞吞地站起来，[rhr]
跟着我来到海浪拍岸的地方。[rhp]
站在海水没过脚踝的位置，我大大地伸了个懒腰。[rhp]

[:princess:][puri_w body=mizugi kao=14 hh=on ]
「好舒服～～～！海水又干净真是太棒了」[rhp]
[:princess:]
「呐，快斗。要不要再往海里走一点？」[rhp]

[:kite:][kite body=mizugi kao=2 as=on ss=on ]
「……………………」[rhp]

[:princess:][puri_w body=mizugi kao=0 ]
「快斗？」[rhp]

[:kite:]
「…………………………」[rhp]

[off_kite]

[:princess:][puri_w body=mizugi kao=7 ]
[font color=0x4682b4]
（？一直低头看什么呢……嗯？）[rhp]
[resetfont]

[off_all]

[::]
顺着快斗的视线望去，我明白了原因。[rhp]
脚边有只小螃蟹。[rhr]
快斗像避开螃蟹的行进路线般，一点一点地拉开距离。[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:kite:][kite body=mizugi kao=2 as=on ss=on ]
「恶……这家伙是什么……」[rhp]

[:princess:][puri_w body=mizugi kao=0 ]
「是螃蟹吧？」[rhp]

[:kite:]
「不不不……没听说会出现在这种地方啊。[rhr]
_　像海参啦、海胆啦……博士说过那些东西应该住在更深的地方才对」[rhp]

[:princess:][puri_w body=mizugi kao=6 as=on ]
[font color=0x4682b4]
（该不会就因为害怕这个才放弃浮潜的吧？）[rhp]
[resetfont]

[:kite:][kite body=mizugi kao=3 as=on ss=on ]
「那、那个，公主……果然还是算了吧？[rhr]
_　随便用岸边的沙子堆个城堡什么的就……」[rhp]

[off_all]

;ひょいっ
[se storage="se7_30.ogg"]

[::]
我从他脚边捡起那只小小的泽蟹。[rhp]

[:kite:][kite body=mizugi kao=2 as=on ss=on ]
「呀啊！！等等等等！[rhr]
_　别碰比较好吧，那种恶心的东西」[rhp]

[:princess:][puri_w body=mizugi kao=7 ]
「真不可思议呢。明明这么可爱」[rhp]

[:kite:][kite body=mizugi kao=8 as=on ss=on ]
「快住手！万一得病了怎么办」[rhp]

[:princess:][puri_w body=mizugi kao=5 as=on ]
「不不，只是普通的螃蟹哦？」[rhp]

[:kite:][kite body=mizugi kao=6 as=on ss=on ]
「～～～～～……总之把那东西扔掉啦」[rhp]

[:princess:][puri_w body=mizugi kao=11 ]
「真是的，真任性啊……那就再见啦，小螃蟹」[rhp]

[off_all]

;地面に落とす
[se storage="se2_08.ogg"]

[::]
当我把它放到被海水浸湿的沙滩上时，[rhr]
螃蟹像受了惊吓似的匆匆逃走了。[rhp]

[:kite:][kite body=mizugi kao=6 as=on ]
「果然还是放弃海水浴吧。照这情况附近肯定爬满了那玩意儿」[rhp]

[:princess:][puri_w body=mizugi kao=6 ]
「诶～？好无聊哦」[rhp]

[:kite:][kite body=mizugi kao=12 ]
「就算没螃蟹，光我们俩也够开心了吧」[rhp]

[:princess:][puri_w body=mizugi kao=4 as=on ]
「……………………」[rhp]

[:kite:][kite body=mizugi kao=6 ]
「什么？」[rhp]

[:princess:][puri_w body=mizugi kao=5 ]
「哦……！刚才那下让我有点心跳加速了！[rhr]
_　快斗也会说这种体贴的话呢」[rhp]

[:kite:][kite body=mizugi kao=2 as=on ]
「……，是哦。那很好啊」[rhp]

[off_all]

[::]
或许是害羞了，快斗将脸别开，[rhr]
独自朝着海滩方向先走一步。[rhp]
为了不被落下，我也慌忙跟了上去。[rhp]

[:princess:][puri_w body=mizugi kao=13 hh=on ]
「……呵呵！」[rhp]

[off_puri]

[::]
和快斗在一起时，为何会如此开心呢。[rhr]
总觉得莫名合拍是我的错觉吗。[rhp]

[chara_part name="kite" body=mizugi kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="383" top="0" wait="false" time="150"]
[chara_part name="puri_w" body=mizugi kao=0 as=off ss=off hh=off hr=on hat=okan]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「我说快斗。我突然想到啊」[rhp]
[:princess:]
「我们生前会不会也是朋友呢？之类的」[rhp]

[:kite:][kite body=mizugi kao=3 ]
「………………谁知道呢。或许吧」[rhp]

[:princess:][puri_w body=mizugi kao=13 ]
「嘻嘻。要真是那样就好啦」[rhp]

[off_puri]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:kite:][kite body=mizugi kao=3 ]
「……………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_kite]

[:kite:]
「………………搞什么，现在才说这个……」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[jump target="*tutti3"]

;------------------------------------------------------------------------------------------------
;クリリン
;------------------------------------------------------------------------------------------------

*ev_03_riri

;****************************************
[set_00 storage="sea_02.jpg"]
;****************************************

[:princess:][puri_w body=mizugi ]
「呀吼——克林！在干什么呢？」[rhp]

[:quadrillion:][p_r_36][riri body=mizugi kao=0 ]
「什么啊，你来了。平板女」[rhp]

[:princess:][puri_w body=mizugi kao=13 ]
「一个人太无聊了。平板女要不要一起行动？」[rhp]

[:quadrillion:][riri body=mizugi kao=0 ]
「………………」[rhp]
[:quadrillion:][p_r_01][riri body=mizugi kao=13 ]
「……嗯！可以哦」[rhp]

[:princess:][puri_w body=mizugi kao=4 as=on ]
「诶」[rhp]

[:quadrillion:][p_r_19][riri body=mizugi kao=6 ]
「为什么惊讶啊。不是你主动邀请的吗」[rhp]

[:princess:][puri_w body=mizugi kao=6 as=on ]
「不、不是。本以为会被拒绝所以有些意外」[rhp]

[:quadrillion:][p_r_24][riri body=mizugi kao=13 ]
「让妙龄女子在度假胜地形单影只，[rhr]
_　就算是我也会于心不忍～。这不是当然的吗！」[rhp]

[:princess:][puri_w body=mizugi kao=8 as=on hh=on ]
[font color=0x4682b4]
（原来克林也会有人情味的关怀……令人感慨）[rhp]
[resetfont]

[:quadrillion:][p_r_15][riri body=mizugi kao=11 ]
「既、既然决定了那就好办了！[rhr]
_　跟上来。我们马上去那边的岩石后面」[rhp]

[:princess:][puri_w body=mizugi kao=6 ]
「为什么？那种地方全是石头无聊死了。[rhr]
_　不和哈蒂君他们会合，一起去那边玩吗？」[rhp]

[:quadrillion:][p_r_25][riri body=mizugi kao=2 ]
「绝对不要。已经能猜到结局了」[rhp]

[:princess:][puri_w body=mizugi kao=2 ]
「小气鬼！」[rhp]

[:quadrillion:][p_r_29][riri body=mizugi kao=13 ]
「别管那么多快过来。你马上就知道要做什么了」[rhp]

[:princess:][puri_w body=mizugi kao=6 as=on ]
「诶～～～……？嘛好吧……」[rhp]

;****************************************
[set_00 storage="sea_04.jpg"]
;****************************************

[::]
―――于是，我乖乖跟着他来到岩石后方。[rhp]

[:quadrillion:][p_r_31][riri body=mizugi kao=5 hh=on ]
「呵呵呵……！和预想的一样，最佳观测点！！」[rhp]

[:princess:][puri_w body=mizugi kao=2 as=on ]
「……………………」[rhp]

[off_all]

[::]
……当我意识到他的目的时，立刻为自己竟然[rhr]
没有怀疑这个总爱使坏的家伙突如其来的温柔而感到无比后悔。[rhp]

[:quadrillion:][riri body=mizugi kao=5 hh=on ]
「啊！那个不错呢！[rhr]
_　白色布料和小麦色肌肤的对比度简直绝妙……！」[rhp]
[:quadrillion:]
「但布料面积未免太小了。[rhr]
_　可不是只要够色情就行。那个女人根本不懂呢」[rhp]

[:princess:][puri_w body=mizugi kao=2 ss=on ]
「克林你这家伙……难道就为了这个才选择海边……？」[rhp]

[:quadrillion:][p_r_11][riri body=mizugi kao=11 hh=on ]
「是男人就必须来海边进行泳装鉴赏啊！」[rhp]
[:quadrillion:]
「可别让红白的人知道哦？[rhr]
_　那些小鬼头看到这种场面肯定会闹腾起来」[rhp]

[:princess:][puri_w body=mizugi kao=6 as=on ]
「还泳装鉴赏呢。再说我又不是男……」[rhp]

[:quadrillion:][p_r_10][riri body=mizugi kao=2 ]
「喂，你在这偷什么懒」[rhp]
[:quadrillion:]
「不是说发现好巨乳就要立刻报告吗。[rhr]
_　你发呆的时候巨乳可是一个个从眼前溜走了哦」[rhp]
[:quadrillion:]
「喏，你是负责左边区域的吧。可别错过啊！」[rhp]

[:princess:]
「是是……」[rhp]
[:princess:]
「…………我说，我还是回去吧？[rhr]
_　感觉有种前所未见的漆黑感情在咕嘟咕嘟冒出来」[rhp]

[:quadrillion:][p_r_18][riri body=mizugi kao=6 ]
「真受不了，这不就是平胸族的嫉妒全写在脸上了吗。[rhr]
_　既然上了这条船，就给我奉陪到底啊」[rhp]

[:princess:][puri_w body=mizugi kao=6 ]
「要我说，随便找个男的来不就好了！[rhr]
_　为什么偏偏拉我这个女生啊？明明对巨乳最没兴趣了！」[rhp]

[:quadrillion:][riri body=mizugi kao=6 ]
「快斗跟着博士他们去浮潜了。[rhr]
_　之前装作不经意邀请多洛普时，他那张嫌弃脸简直绝了」[rhp]

[:princess:][puri_w body=mizugi kao=2 as=on ]
「我现在可完全理解多洛普的心情！！」[rhp]

[:quadrillion:][riri body=mizugi kao=12 ]
「毕竟多洛普认真到令人无语嘛。[rhr]
_　就算看到你的泳装也绝对会无视吧？根本不配当男人」[rhp]

[:princess:][puri_w body=mizugi kao=5 as=on ]
「对于这个让泳装美女作陪却盯着其他泳装的家伙[rhr]
_　多洛普也不想被你说教吧～～」[rhp]

[:quadrillion:][p_r_15][riri body=mizugi kao=5 ]
「…………！呵～？你什么意思啊。[rhr]
_　莫非你是想引起我的兴趣？」[rhp]

[yurasu]

[:princess:][puri_w body=mizugi kao=2 ss=on ]
[font size=32]
「就是啊ッッ！！！！」[rhp]
[resetfont]

[:quadrillion:][riri body=mizugi kao=6 as=on ]
「诶」[rhp]

[:princess:]
「这种时候是谁都无所谓啦！为什么谁都不对我说点什么？[rhr]
_　女孩子都把大腿露到这种程度了诶？？」[rhp]
[:princess:]
「女童佩奇暂且不论，[rhr]
_　妙龄女孩穿着泳装的话按理说客套也该夸两句吧！！」[rhp]

[:quadrillion:][p_r_03][riri body=mizugi kao=13]
「大概是不敢碰你吧。出于体贴」[rhp]

[:princess:][puri_w body=mizugi kao=2 ss=on ]
「反正我就是用荷叶边掩饰贫瘠的滑稽洗衣板啦。[rhr]
_　巨乳有罪！巨乳有罪！！」[rhp]

[:quadrillion:][riri body=mizugi kao=0 ]
「……………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:quadrillion:][riri body=mizugi kao=5 ]
「……说什么呢。你明明很可爱啊」[rhp]

[:princess:][puri_w body=mizugi kao=6 ss=on ]
「！！　哎……」[rhp]

[:quadrillion:][riri body=mizugi kao=11 ]
「有点自信不好吗。你这身打扮不差哦」[rhp]

[:princess:][puri_w body=mizugi kao=5 ]
「真、真的？可能？嘿嘿……[rhr]
_　夸德里利昂里还是第一次有人夸我」[rhp]

[:quadrillion:][riri body=mizugi kao=13 ]
「呵呵呵。那群小鬼不懂啦。[rhr]
_　我觉得挺适合你的」[rhp]
[:quadrillion:]
「用立体蕾丝制造胸围错觉这点，[rhr]
_　很有青春期初中生的可爱劲儿呢」[rhp]

[:princess:][puri_w body=mizugi kao=8 ss=on ]
「什……！！！」[rhp]

[:quadrillion:][riri body=mizugi kao=14 ]
「平胸也很有魅力啦。只不过不是我的喜好」[rhp]
[:quadrillion:]
「好啦！满意了就继续泳装巡礼吧！[rhr]
_　在我满足之前今天不会放你回去的」[rhp]

[:princess:][puri_w body=mizugi kao=2 as=on ss=on ]
「笨、笨蛋～……！　现在虽然是这样，[rhr]
_　我可是预定要从这里急速成长到X罩杯的！！」[rhp]

[:quadrillion:][riri body=mizugi kao=6 as=on ]
「这孩子说什么呢。那根本就是怪物吧」[rhp]

[:princess:][puri_w body=mizugi kao=6 ]
「你给我等着瞧克林！[rhr]
_　等我变成爆乳美女，绝对要让你刮目相看！」[rhp]

[:quadrillion:][riri body=mizugi kao=6 ]
「哈啊……就算丑女的胸变大了，[rhr]
_　唯独你我绝对不会承认的」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[off_riri]

[:princess:][puri_w body=mizugi kao=2 as=on ]
「真是的！为什么夸德里利昂总是这样对我」[rhp]

[off_puri]

[::]
倒也不是想要被温柔对待，[rhr]
只是希望作为同伴能正常友好相处。[rhp]
如果有了胸部就能实现这个愿望吗……[rhr]
那样的话动机也太不纯了……[rhp]

[:princess:][puri_w body=mizugi kao=6 ]
「…………下次见到米卡亲的时候，问问秘诀好了」[rhp]

[off_puri]

[::]
为了能早日和他也成为朋友。[rhp]
………………不对不对。[rhp]

[:princess:][puri_w body=mizugi kao=2 as=on ss=on ]
[font size=26]
「要让他为小瞧我的事道歉！！！！」[rhp]
[resetfont]

[off_puri]

[jump target="*tutti3"]

;-----------------------------------------------------------------------------------------------
;双子
;-----------------------------------------------------------------------------------------------

*ev_03_hati

;****************************************
[set_00 storage="sea_02.jpg"]
;****************************************

[:princess:][puri_w body=mizugi kao=13]
「哈蒂君，杰特君！」[rhp]

[:jet:][p_j_36][jet body=mizugi kao=0]
「啊，是公主啊。有什么事吗」[rhp]

[:princess:][puri_w body=mizugi ]
「找你们好久了。老是一下子就跑没影」[rhp]
[:princess:]
「我一个人很无聊。可以和你们一起玩吗？」[rhp]

[:jet:][p_j_02][jet body=mizugi kao=12 ]
「倒是没问题，不过现在有点挤啊」[rhp]

[:princess:][puri_w body=mizugi kao=0 ]
「？　什么意思？」[rhp]

[off_all]

[yurasu]

[:heartshape:][hati body=mizugi kao=2 ]
[font size=28]
「出问题了，公主！！」[rhp]
[resetfont]

[:princess:][puri_w body=mizugi kao=0 ]
「嗯？」[rhp]

[:heartshape:][hati body=mizugi kao=2 ]
「说到海……什么来着！？」[rhp]

[:princess:][puri_w body=mizugi kao=2 ]
「！？　呃……海水浴！」[rhp]

[yurasu]

[:heartshape:][hati body=mizugi kao=5 ]
[font size=32]
「劈西瓜大会！！」[rhp]

[off_all]

[yurasu]

[:heartshape:]
「而这就是今天的西瓜！！！」[rhp]
[resetfont]

[off_all]

[:quadrillion:][s_playse storage="riri/full/46.ogg" buf=1]
「杀了我吧……」[rhp]

[::]
地面里埋着克林。[rhr]
在那双脚下展开的骇人景象，令我不由自主向后退去。[rhp]

[:jet:][jet body=mizugi kao=5 ]
「我和哈蒂逮到你用望远镜猥琐偷窥比基尼女郎了」[rhp]

[:quadrillion:][p_r_10][riri body=mizugi kao=2 as=on ]
「在不破坏生态系统的程度下观赏巨乳有什么错！[rhr]
_　既然有观鸟会，那成立巨乳鉴赏会也很合理吧！？」[rhp]

[off_all]

[:heartshape:][hati body=mizugi kao=2 ]
[font size=28]
「鸟类根本没有乳房！！」[rhp]
[resetfont]

[off_all]

[:jet:][jet body=mizugi kao=5 ]
「接着，公主。用这根木棍」[rhp]

[off_all]

[::]
哈蒂君递来的是一根尺寸可观的方木。[rhr]
难道要用这个来对付西瓜（隐喻）……？开玩笑的吧？[rhp]

[:heartshape:][hati body=mizugi kao=5 ]
「被狠狠羞辱过的你有这个权利！[rhr]
_　毕竟俗话说女人最大的敌人就是女人！」[rhp]

[off_all]

[:quadrillion:][p_r_10][riri body=mizugi kao=2 as=on ]
「所以老子是男的啊！！」[rhp]

[off_all]

[:princess:][puri_w body=mizugi kao=8 as=on ]
「～～～！　不行还是做不到！[rhr]
_　对人挥下这种东西什么的」[rhp]

[chara_part name="jet" body=mizugi kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="hati" body=mizugi kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:jet:][p_j_17]
「但要是哈蒂动手真的会敲碎脑袋吧」[rhp]

[:heartshape:][p_h_17]
「杰特出手又怕演变成阴险的欺凌」[rhp]

[chara_part name="jet" body=mizugi kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="hati" body=mizugi kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:hutago:]
「交给你了，公主」[rhr]
「交给你了，公主！！」[rhp]

[:princess:][puri_w body=mizugi kao=8 as=on ]
「诶～～～～～～！？　真是的……」[rhp]

[off_all]

[puri_w body=mizugi kao=8 as=on ]
[font color=0x4682b4]
（算了……随便挥一下，轻轻戳一下就结束吧。[rhr]
_　用这种东西打的话，搞不好会受重伤的）[rhp]
[resetfont]
[puri_w body=mizugi kao=6 as=on ]
「对不起啊克林。我会尽快结束的所以忍……」[rhp]

[:quadrillion:][p_r_11][riri body=mizugi kao=6 ]
「谁要感激你这丑八怪的仰拍角度啊。[rhr]
_　快给我换成米卡亲啦……」[rhp]

[off_all]

;ドスッ
[se storage="hand_06.ogg"]
[yurasu]

[:quadrillion:][p_r_13][riri body=mizugi kao=2 as=on ss=on ]
「！！　呃―――……」[rhp]

[:princess:][puri_w body=mizugi kao=2 ss=on ]
「咦……？　奇怪啊……打不中呢……」[rhp]

[:quadrillion:][p_r_21][riri body=mizugi kao=2 as=on ss=on ]
「现在没蒙眼吧！？　这个恶毒女！！」[rhp]

[off_all]

[chara_part name="jet" body=mizugi kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="hati" body=mizugi kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:heartshape:][p_h_02]
「上啊！　公主！」[rhp]

[:jet:][p_j_06]
「干掉她公主！」[rhp]

[off_all]

[:princess:][puri_w body=mizugi kao=2 ss=on ]
「野鸟之会……」[rhp]

[off_all]

;ドスッ
[se storage="hand_07.ogg"]
[yurasu]

[font size=30]
「给我下跪――――！！」[rhp]
[resetfont]

;****************************************
[bg_rule storage="sea_07.jpg" rule="002.png" time=500]
;****************************************

[:drop:][p_d_19][drop hat=sea kao=0 ]
「…………嗯？」[rhp]

[:kite:][kite body=mizugi kao=0 ]
「怎么了，多洛普」[rhp]

[:drop:][p_d_17][drop hat=sea kao=7 ]
「刚才好像听到了夸德里利昂的惨叫声」[rhp]

[:kite:][p_k_01][kite body=mizugi kao=12 ]
「有巨乳在就会叫吧。老样子了」[rhp]

[:drop:][p_d_02][drop hat=sea kao=13 ]
「说的也是呢」[rhp]

[off_all]

「好了，继续看书吧……」[rhp]

[:kite:]
「哈啊……困……」[rhp]

[jump target="*tutti3"]

;-----------------------------------------------------------------------------------------------
;博士
;-----------------------------------------------------------------------------------------------

*ev_03_hkpk

;****************************************
[set_00 storage="sea_05.jpg"]
;****************************************

[:princess:][puri_w body=mizugi kao=13 ]
「博士、佩奇！　一起玩……」[rhp]

[:vulpecula:][peku body=syuno kao=15 ]
「咻啵」[rhp]

[off_peku]

[:darknebula:][hakase body=syuno kao=15 ]
「咻啵咯咯咯」[rhp]

[off_all]

[chara_part name="hakase" body=syuno kao=15 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time="150"]
[chara_part name="peku" body=syuno kao=15 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="false" time="150"]
[chara_part name="puri_w" body=mizugi kao=2 as=off ss=off hh=off hr=on hat=okan]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「……………………」[rhp]

[off_all]

;****************************************
[se storage="se2_09.ogg"]
[set_00 storage="sea_06.jpg"]
;****************************************

[:vulpecula:]
「咻啵咯咯咯！　咻啵！」[rhp]

[:darknebula:]
「咻啵咻啵咻咻咻」[rhp]

[:vulpecula:]
「嘘！？」[rhp]

[:2nin:]
「嘘可可可可(笑)！」[rhr]
「嘘可可可可(笑)！」[rhp]

[off_all]

[:princess:][puri_w body=mizugi kao=2 ]
「……………………」[rhp]

#
[off_all]

;****************************************
[se storage="se2_10.ogg"]

[s_mask graphic="rule/krke_w.png" effect="fadeInLeftBig" time=1500]

; スチル指定
[bg storage="cg/a_03_1.png" time=200]
[cg storage="cg/a_03_1.png"]
; ウィンドゥの設定
[position layer="message0" frame="win3.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
; ウィンドゥの表示
[layopt layer="message0" visible="true"]

[s_mask_off effect="fadeOutRightBig" time=1500 ]

;****************************************

[:darknebula:]
「嘘——……！　嘘！」[rhp]

[:vulpecula:]
「嘘可？　嘘可可可！」[rhp]

[:darknebula:]
「嘘可嘘可，嘘可可」[rhp]

[:vulpecula:]
「嘘——……嘘可可可！」[rhp]

[:princess:]
「……………………」[rhp]

;****************************************

[s_mask graphic="rule/krke_w.png" effect="fadeInLeftBig" time=1500]

; 背景指定
[bg storage="sea_05.jpg" time=200]
; ウィンドゥの設定
[position layer="message0" frame="win.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
; ウィンドゥの表示
[layopt layer="message0" visible="true"]

[s_mask_off effect="fadeOutRightBig" time=1500 ]

;****************************************

[::]
1小时后―――[rhp]

[se storage="se2_08.ogg"]

[chara_part name="hakase" body=syuno kao=14 as=off ss=off hh=off hr=on msk=syuno ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time="150"]
[chara_part name="peku" body=syuno kao=14 as=off ss=off hh=off hr=on msk=on]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="false" time="150"]
[chara_part name="puri_w" body=mizugi kao=2 as=off ss=off hh=off hr=on hat=okan]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:darknebula:]
「―――噗哈！　哎呀！真是绝妙的海底冒险呢」[rhp]

[:vulpecula:]
「超级开心呀！小姬～！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:princess:]
「………………」[rhp]

[off_all]

[:princess:]
[font color=0x4682b4]
（―――――嘛，算了！）[rhp]
[resetfont]

[::]
虽然完全听不懂在说什么，但很开心！[rhp]

;-------------------------------------------------------------------------------------------------
;-------------------------------------------------------------------------------------------------

*tutti3

;****************************************
[set_yy storage="sky_07.jpg"]
;****************************************

#
漫长的海上之旅迎来最后一个夜晚。[rhp]

;****************************************
[bg storage="sea_09.jpg"]
;****************************************

分散行动的我们聚集在旅馆的露天阳台，[rhr]
准备享用度假胜地的最后一顿晚餐。[rhp]

;****************************************
;スチル
[still storage="cg/a_03_2.png" rule="021.png" width="1280" height="720" time=1000]
[cg storage="cg/a_03_2.png"]
;****************************************

[:princess:]
「哇！今晚的晚餐超级丰盛啊！」[rhp]

[:quadrillion:][p_r_01]
「因为是最后一天嘛。当然要轰轰烈烈收尾啦」[rhp]

[:jet:][p_j_04]
「快斗，这只鲍鱼给你？」[rhp]

[:heartshape:][p_h_02]
「我的海胆也送给你！」[rhp]

[:kite:][p_k_09]
「不要……！别净给我这些瘆人的东西行吗？」[rhp]

[:quadrillion:][p_r_31]
「虽然这三天发生了各种事，但大家玩得开心就太好了」[rhp]

[:princess:]
「是啊。能和米卡亲还有矢部医生聊天，这趟来得真值」[rhp]

[:quadrillion:][p_r_24]
「没错！米卡亲的比基尼真是令人大饱眼福呀～」[rhp]
[:quadrillion:]
「你也要努力变成那样哦。[rhr]
_　虽然花一辈子也办不到吧」[rhp]

[:princess:]
「到底是怎样！真是太失礼了……」[rhp]

[:vulpecula:][p_vl_04]
「克林！那果汁你不喝的话就给我吧——？」[rhp]

[:quadrillion:][p_r_10]
「啊喂笨蛋丫头！那可是葡萄酒啊！」[rhp]

[:vulpecula:][p_vl_17]
「哈啊……感觉整个人变得暖烘烘的……」[rhp]

[:quadrillion:][p_r_18]
「呀——！水、拿水来！」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
;ドロップ
[voconfig sebuf=1 name=drop vostorage="drop/full/{number}.ogg" number=54]
;ダークネブラ
[voconfig sebuf=1 name=hakase vostorage="hakase/full/{number}.ogg" number=32]

[vostart]
;------------------------------------------------------------------------------------------

[:drop:]
「呵呵……！果然大家聚在一起[rhr]
_　难免会变得闹哄哄呢」[rhp]

[:darknebula:]
「讨厌这样吗？」[rhp]

[:drop:]
「不！我很开心。这才是我所追寻的旅程模样」[rhp]

[:darknebula:]
「……哈哈哈！也就是说多洛普君喜欢平时的大家」[rhp]

[:drop:]
「！啊……是、是这样吗。原、原来如此」[rhp]

[:darknebula:]
「我觉得这是很棒的事。不过能让你这么想，[rhr]
_　全拜多洛普君平日的奉献所赐」[rhp]
[:darknebula:]
「今后也请多关照。[rhr]
_　为了让我们……更重要的是你自己能享受银河之旅」[rhp]

[:drop:]
「――――！好！」[rhp]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
[fbgm]

[s_mask color=0x000000 time=2000]
; 背景表示
[bg storage="black.jpg" time=100]
; ウィンドゥの設定
[position layer="message0" frame="win.png" left=0 top=520 width=1280 height=200 page=fore visible=true ]
;****************************************

; イベント分岐の解除
[iscript]
delete f.ev_a_03;
[endscript]

[jump storage="ev_a_04.ks" target=*start]

[s]