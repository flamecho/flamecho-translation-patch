﻿
*start

[iscript]
delete f.daymode;
[endscript]

[eval exp="f.nigmode = 1"]

;---------------------------------------------------------------------------------------------
*ss_puri
;---------------------------------------------------------------------------------------------

[cm]

;****************************************
[bg storage="train_08.jpg" time=500]
;****************************************

[winset][bgm storage="bgm_30.ogg"]

[:princess:][puri_w kao=11]
「今天就在房间里放松一下吧……」[p]


[jump target="*next"]

;---------------------------------------------------------------------------------------------
;---------------------------------------------------------------------------------------------

*next

[off_all]

;ev_7への分岐
[if exp="f.ev_a_07 ==1 && f.nigmode == 1"]
[jump storage="ev_a_07.ks" target="*start"]

;ev_6への分岐
[elsif exp="f.ev_a_06 ==1 && f.nigmode == 1"]
[jump storage="ev_a_06.ks" target="*start"]

;ev_3への分岐
[elsif exp="f.ev_a_03 ==1 && f.nigmode == 1"]
[jump storage="ev_a_03.ks" target="*start"]

;ev_2への分岐
[elsif exp="f.ev_a_02 ==1 && f.nigmode == 1"]
[jump storage="ev_a_02.ks" target="*start"]

;夜モードの場合
[elsif exp="f.nigmode == 1"]
[jump storage="ss_main.ks" target="*start"]

;昼モード
[else]
[jump storage="ss_select.ks" target="*select_scene_nig"]
[endif]


