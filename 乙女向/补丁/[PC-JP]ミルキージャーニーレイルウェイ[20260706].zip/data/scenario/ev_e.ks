﻿
*start

[fbgm]
[mask color=0x000000 time=2000]

[cm]

[clearfix]
[start_keyconfig]
[loadjs storage="myscript.js"]

;初期設定---------------------------------------------------------------------

;メッセージウィンドウの設定
[position layer="message0" frame="win2.png" left=0 top=520 width=1280 height=200 page=fore visible=true]

; 文字表示領域
[position layer=message0 page=fore margint="65" marginl="420" marginr="60"]

;キャラ名表示領域
[ptext name="chara_name_area" layer="message0" color="0x000000" size=22 align=center bold=true x=420 y=550]

; 立ち絵の設定
[chara_config anim=false ptext="chara_name_area"]

[call storage="character.ks"]
[call storage="voice.ks"]

;--------------------------------------------------------------------------------

;▼フルボイスセット▼

;ジェット
[voconfig sebuf=1 name=jet vostorage="jet/full/{number}.ogg" number=92]
;ミカちん
[voconfig sebuf=1 name=tiaki vostorage="mika/full/{number}.ogg" number=211]
;サウス
[voconfig sebuf=1 name=sausu vostorage="sausu/full/{number}.ogg" number=284]
;糠星の夜
[voconfig sebuf=1 name=yoru vostorage="yoru/full/{number}.ogg" number=226]

;--------------------------------------------------------------------------------------------


[layopt layer=message0 visible=true]
[plugin name="menu_plugin"]

; --------------------------------------------------------------------------
; --------------------------------------------------------------------------
; ev_eクリアしてる場合、d_epilogueを冒頭で流す
[if exp="sf.e_end == 1"]
[jump storage="ev_d.ks" target="*d_epilogue"]
[endif]
; --------------------------------------------------------------------------
; --------------------------------------------------------------------------

*start2

;****************************************
;各種設定

[bg storage="hsps_09.jpg" time=100]
[layopt layer=message0 visible=true]
[plugin name="menu_plugin"]
[showmenubutton]
[s_mask_off time=2000]

;****************************************
[bgm storage="bgm_08.ogg"]
;****************************************

[:tiaki:]
「――――――就是这里，杰特君」[rhp]

[chara_part name="jet" body=unif kao=0 as=off ss=off hh=off hr=on2 ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:][tiaki kao=1 ]
「这里就是今天开始你的房间！[rhr]
_　看起来超级舒适对吧？」[rhp]

[:jet2:][jet body=unif hr=on2 kao=0 ]
「一般」[rhp]

[:tiaki:][tiaki kao=7 ]
「哎呀～评价真严格呢～明明人家很用心布置了说」[rhp]

[off_all]

[::]
一边心不在焉地听着大美贺小姐说话，我忽然瞥见墙边的千纸鹤。[rhp]

[chara_part name="jet" body=unif kao=0 as=off ss=off hh=off hr=on2 ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:jet2:]
「……那个是？」[rhp]

[:tiaki:]
「啊，那是之前住这个房间的孩子折的千纸鹤」[rhp]
[:tiaki:]
「收拾掉总觉得有点不忍心。[rhr]
_　现在就像是这家临终关怀院的守护神呢」[rhp]

[:jet2:][jet body=unif hr=on2 kao=6 ]
[font color=0x4682b4]
（死人留下的千纸鹤什么的...有点恶心啊……）[rhp]
[resetfont]

[:tiaki:][tiaki kao=13 ]
「那么杰特君，今天先去床铺休息好吗？[rhr]
_　轮椅长途旅行很累了吧？」[rhp]
[:tiaki:]
「从今天开始就把我们当家人，好好放松吧」[rhp]

[:jet2:][jet body=unif hr=on2 kao=12 ]
「谢谢您……」[rhp]

[off_all]

[:sausu:][sausu kao=11 ]
「呼……呼……」[rhp]

[off_all]

[yurasu]

[:jet2:][jet body=unif hr=on2 kao=2 as=on ss=on ]
[font size=30]
「呜哇！？」[rhp]
[resetfont]

[off_all]

[chara_part name="jet" body=unif kao=2 as=on ss=off hh=off hr=on2 ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=4 as=on ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:]
「怎、怎么了杰特君！发生什么事了！？」[rhp]

[:jet2:]
「那那那个！床床床上有人！！有人在睡觉啊！！」[rhp]

[:tiaki:][tiaki kao=4 as=on ]
「诶？什、什么意思？」[rhp]

[:jet2:]
「……！？」[rhr]
[font color=0x4682b4]
（难、难道她看不见那个可疑人物……？）[rhp]
[resetfont]

[:tiaki:][tiaki kao=0 as=on ]
「杰特君……？你、你还好吗？」[rhp]

[:jet2:][jet body=unif hr=on2 kao=0 ]
「！……没、没什么……」[rhp]

[off_all]

[:tiaki:][tiaki kao=2 as=on ]
[font color=0x4682b4]
（夜君怎么可能擅自睡在床铺上……难道是南？[rhr]
_　除了夜君以外都看不见所以不清楚）[rhp]
[:tiaki:]
（……但还是要装作不知情。要是被南察觉到的话[rhr]
_　恐怕夜君和我们联手的事就会暴露了）[rhp]
[:tiaki:][tiaki kao=3 as=on ]
（……但是……杰特君[rhr]
_　居然已经能看见他们的存在了……）[rhp]
[resetfont]

[:jet2:][jet body=unif hr=on2 kao=6 as=on ]
「大美贺小姐？」[rhp]

[:tiaki:][tiaki kao=1 as=on ]
「！啊……呃、抱歉。怎么了？」[rhp]

[:jet2:]
「没事，看你有点发呆……」[rhp]

[off_all]

[:sausu:][sausu kao=12 ]
「嗯……、……好吵啊……」[rhp]
[:sausu:][sausu kao=1 ]
「……嗯？」[rhp]

[off_all]

[:jet2:][jet body=unif hr=on2 kao=2 as=on ]
[font color=0x4682b4]
（醒来了！）[rhp]
[resetfont]

[off_all]

[:sausu:][sausu kao=14 ]
「…………啊！对不起对不起。不小心睡着了」[rhp]

[off_all]

[:sausu:]
「来请用，现在就让开～」[rhp]

[:jet2:][jet body=unif hr=on2 kao=2 as=on ]
[font color=0x4682b4]
（这、这、这家伙怎么回事……！？）[rhp]
[resetfont]

[off_all]

[chara_part name="jet" body=unif kao=6 as=on ss=off hh=off hr=on2 ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:]
「杰特君，我差不多该走了。[rhr]
_　有什么事就按护士呼叫。米卡亲10秒就会过来哦♡」[rhp]

[:jet2:]
「谢谢……」[rhp]

[off_all]

[:tiaki:][tiaki kao=1 ]
「那再见啦～」[rhp]

[off_all]

[se storage="door_08.ogg"]

[rhp]

[:sausu:][sausu kao=1 ]
「你，是新来的小子吧？」[rhp]

[:jet2:][jet body=unif hr=on2 kao=2 as=on ss=on ]
[font color=0x4682b4]
（……！被、被搭话了）[rhp]
[resetfont]

[:sausu:][sausu kao=11 ]
「哎呀抱歉。好像吓到你了。[rhr]
_　暂时没有住户入住，所以擅自借用了床铺」[rhp]
[:sausu:]
「虽然不需要睡觉，但实际尝试后发现这意外地舒适呢。[rhr]
_　最近午睡成了我的新爱好。毕竟实在闲得慌」[rhp]

[:jet2:]
「哈、哈啊……这样啊……」[rhp]

[:sausu:][sausu kao=1 ]
「我是南！是神明哦。请多指教」[rhp]

[:jet2:]
「……神明？」[rhp]

[:sausu:]
「看到那边那个漂亮的千纸鹤了吧。[rhr]
_　我就是寄宿在那千纸鹤里的付丧神」[rhp]
[:sausu:]
「因为被装饰在这个房间里，我基本就以这里为据点。[rhr]
_　平时都会谨慎选择交谈对象……这次大意了」[rhp]

[:jet2:]
「………………」[rhp]

[:sausu:][sausu kao=13 ]
「想知道什么都可以问。能回答的事我都会回答」[rhp]

[:jet2:][jet body=unif hr=on2 kao=0 ]
「……你似乎，别人都看不见呢。[rhr]
_　大美贺小姐好像完全听不懂我在说什么」[rhp]

[:sausu:][sausu kao=1 ]
「没错。我并没有让她看见我的身影……[rhr]
_　大概因为她是受约尔大人庇护的人吧」[rhp]

[:jet2:][jet body=unif hr=on2 kao=0 ]
「约尔大人是？」[rhp]

[:sausu:][sausu kao=1 ]
「是经常训斥我的前辈。很可怕的」[rhp]

[:jet2:][jet body=unif hr=on2 kao=2 ]
「……………………」[rhp]

[:sausu:][sausu kao=0 ]
「怎么了？表情这么严肃」[rhp]

[:jet2:][jet body=unif hr=on2 kao=2 ]
「……能看见神明这种事怎么想都不正常。[rhr]
_　如果我有灵视能力，就无法解释为什么至今都看不见」[rhp]
[:jet2:]
「那么答案就只有一个」[rhp]
[:jet2:][jet body=unif hr=on2 kao=3 ]
「…………我马上就要死了啊」[rhp]

[:sausu:][sausu kao=4 as=on ]
「――――！」[rhp]

[:jet2:][jet body=unif hr=on2 kao=3 ]
「因为我接近那个世界了，[rhr]
_　所以才能看见你们这样的『看不见的东西』。怎么样？」[rhp]

[:sausu:][sausu kao=0 ]
「…………就算是这样，你难道不觉得惊讶吗？」[rhp]

[:jet2:][jet body=unif hr=on2 kao=2 ]
「当然会惊讶啊。[rhr]
_　突然有个不认识的人躺在别人的床铺上」[rhp]

[:sausu:][sausu kao=3 ]
「不是这个意思。我是说……你马上就要……」[rhp]

[:jet2:][jet body=unif hr=on2 kao=3 ]
「医生说我最多还能活5年。嘛，虽然肯定是骗人的」[rhp]

[:sausu:][sausu kao=2 ]
「……为什么这么想呢？」[rhp]

[:jet2:][jet body=unif hr=on2 kao=2 ]
「5年诶？要真能活那么久谁会来临终关怀院。[rhr]
_　无非是为了不让我不安才这样说的吧」[rhp]
[:jet2:]
「……真烦人啊。我最讨厌这种事了」[rhp]

[:sausu:][sausu kao=1 ]
「……、……你很聪明呢」[rhp]

[:jet2:][jet body=unif hr=on2 kao=12 ]
「还行吧」[rhp]

[:sausu:][sausu kao=0 ]
「……正如你所说，只有寿命将尽的人才能看见我的模样。[rhr]
_　大多数人两三个月后就会消失」[rhp]

[:jet2:]
「看来我也就这点时间了」[rhp]

[:sausu:][sausu kao=1 ]
「直白地说就是呢。……不过不用担心。[rhr]
_　这里有个住了五年以上的女孩」[rhp]

[:jet2:][jet body=unif hr=on2 kao=2 as=on ]
「真的？真厉害啊，各种意义上」[rhp]

[:sausu:]
「这家临终关怀院里，还有本该住在主楼儿科病房的孩子。[rhr]
_　这里的房间和装潢都很豪华，所以才会有这样的需求者吧」[rhp]
[:sausu:]
「那样的孩子多半是父母工作忙碌的类型。[rhr]
_　在这里即使探病的人不多，也能像家人般和大家一起生活」[rhp]

[:jet2:][jet body=unif hr=on2 kao=0 ]
「所以医生和护士才会常驻在这里啊」[rhp]

[:sausu:]
「没错。他们的工作就是负责治疗原・主楼患者呢」[rhp]
[:sausu:]
「不过两人都是很好的人。[rhr]
_　就连普通住客生病时，也会悉心帮忙治疗到康复哦」[rhp]

[:jet2:][jet body=unif hr=on2 kao=0 ]
「你知道得真详细啊」[rhp]

[:sausu:]
「毕竟我在这里也住了相当长时间了嘛～」[rhp]

[:jet2:][jet body=unif hr=on2 kao=0 ]
「哼嗯……」[rhp]

[:sausu:]
「那个女孩……[player2]能活到现在，都是多亏了矢部医生。[rhr]
_　所以你说不定也能活过五年哦」[rhp]

[:jet2:][jet body=unif hr=on2 kao=0 ]
「那家伙在你眼里是什么模样」[rhp]

[:sausu:][sausu kao=2 as=on ]
「？虽然还看不清……，――――啊」[rhp]

[:jet2:][jet body=unif hr=on2 kao=12 ]
「在我眼里已经清晰可见了。希望渺茫啊」[rhp]

[:sausu:][sausu kao=3 as=on ]
「…………、抱歉……是我说话欠考虑了」[rhp]

[:jet2:]
「没关系。至少确实听到了吉利话」[rhp]
[:jet2:][jet body=unif hr=on2 kao=1 ]
「那个……是叫南吗？[rhr]
_　你和其他大人不一样，说话耿直挺好的」[rhp]

[:sausu:][sausu kao=1 as=on ]
「当夸奖收下就行了吧……算了」[rhp]
[:sausu:][sausu kao=5 ]
「……你叫什么名字？」[rhp]

[:jet2:][jet body=unif hr=on2 kao=5 ]
「羽田杰特。很搞笑吧」[rhp]

[:sausu:][sausu kao=0 ]
「好笑吗？为什么啊？」[rhp]

[:jet2:]
「因为，姓羽田却叫杰特啊？[rhr]
_　就算你是混血这也太扯了吧」[rhp]

[:sausu:][sausu kao=7 ]
「啊……是喷气机那个杰特啊。[rhr]
_　我还以为是宝石那个呢。因为你的瞳孔是非常漂亮的黑色」[rhp]

[:jet2:][jet body=unif hr=on2 kao=0 ]
「宝石？我不懂这些所以不知道啦」[rhp]

[:sausu:][sausu kao=1 ]
「呵呵，我支持现在的说法……不过也可能是飞机呢？[rhr]
_　很帅气不是吗，很有男孩子气概」[rhp]

[:jet2:][jet body=unif hr=on2 kao=0 ]
「所以我才讨厌。又不是不入流的搞笑艺人。[rhr]
_　而且我比较起来更喜欢电车胜过飞机」[rhp]

[:sausu:][sausu kao=14 ]
「咦！！真的吗！？」[rhp]

[:jet2:][jet body=unif hr=on2 kao=2 as=on ]
「哈？突然怎么了。吓死人」[rhp]

[:sausu:][sausu kao=13 ]
「原来你喜欢铁道啊！我也超喜欢的，银河铁道！」[rhp]

[:jet2:][jet body=unif hr=on2 kao=2 as=on ]
「我不是在说奇幻故事。我是说普通的电车，」[rhp]

[:sausu:][sausu kao=13 ]
「嗯嗯！我懂啦」[rhp]

[:jet2:][jet body=unif hr=on2 kao=6 as=on ]
「你压根没懂吧……」[rhp]

[:sausu:][sausu kao=13 ]
「感觉和你很合得来呢。[rhr]
_　以后就请多关照了室友」[rhp]

[:jet2:][jet body=unif hr=on2 kao=0 ]
「……行吧。反正也能打发时间……」[rhp]

[off_all]

[:jet2:]
[font color=0x4682b4]
（…………暂且不论所剩的时间）[rhp]
[resetfont]

;****************************************
[set_b storage="hsps_09n.jpg"]
; 夜フィルター
[filter layer="1" brightness="60"]
;****************************************

2019年　7月[rhp]

我从主楼转到这家临终关怀院已过去三个月。[rhp]
我和南相处得还算融洽，[rhr]
在没有其他人的时候，每天要么闲聊，要么就得陪着南滔滔不绝地长谈。[rhp]
南性格开朗随和，和我完全相反，[rhr]
但他的话还挺有趣，托他的福我才不至于无聊。[rhp]
今天南也坐在床铺边上，[rhr]
和我聊些没营养的话打发时间。[rhp]

[chara_part name="jet" body=unif kao=7 as=on ss=off hh=off hr=on2 ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=11 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sausu:]
「已经完全是夏天了呢」[rhp]

[:jet2:]
「是啊」[rhp]

[:sausu:][sausu kao=1 ]
「听说七夕会今年也要举办呢。杰特你怎么打算？」[rhp]

[:jet2:][jet body=unif hr=on2 kao=0 ]
「七夕会……？」[rhp]

[:sausu:][sausu kao=1 ]
「啊，说起来杰特今年是第一次参加吧。[rhr]
_　七夕会就是当天在中庭观测天体的活动哦」[rhp]

[:jet2:][jet body=unif hr=on2 kao=0 ]
「我们这种半死不活的家伙搞这种活动合适吗？」[rhp]

[:sausu:][sausu kao=8 ]
「真是的，杰特你别老是这种说法啦。[rhr]
_　当然只有获得矢部老师许可的孩子才能参加啦」[rhp]

[:jet2:][jet body=unif hr=on2 kao=7 ]
「哼嗯……」[rhp]

[:sausu:][sausu kao=1 ]
「如果矢部医生同意的话，杰特你会参加吗？」[rhp]

[:jet2:][jet body=unif hr=on2 kao=12 ]
「不去。太麻烦了」[rhp]

[:sausu:][sausu kao=0 ]
「真可惜啊。明明是这么棒的活动」[rhp]

[:jet2:][jet body=unif hr=on2 kao=7 ]
「我这种快死的人去了只会扫兴吧」[rhp]
[:jet2:][jet body=unif hr=on2 kao=5 ]
「既然你这么推荐，那我死了变成幽灵去参加好了。[rhr]
_　你看，像南那样变成半透明哦」[rhp]

[:sausu:][sausu kao=6 as=on ]
「杰特！说这种话可不好」[rhp]

[:jet2:][jet body=unif hr=on2 kao=12 ]
「好啦好啦。对不起嘛」[rhp]

[off_all]

[::]
每当我说出自嘲的话时，南都会立刻责备我。[rhp]
虽然一半是真心话，但另一半是觉得有趣，[rhr]
我总忍不住说出些不吉利的话来。[rhp]

[chara_part name="jet" body=unif kao=0 as=on ss=off hh=off hr=on2 ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sausu:]
「…………杰特不怕死吗？」[rhp]

[:jet2:][jet body=unif hr=on2 kao=12 ]
「无所谓。我对活着也没那么执着」[rhp]

[:sausu:][sausu kao=6 ]
「哪有孩子不怕死的。[rhr]
_　就算不是死亡瞬间的恐惧，也会有对死后世界的不安，或是现世的留恋啊」[rhp]

[:jet2:]
「这～样啊～」[rhp]

[:sausu:][sausu kao=3 ]
「杰特……为什么这么自暴自弃？」[rhp]
[:sausu:]
「连矢部医生都很关心你，[rhr]
_　不是尝试了各种治疗方案吗」[rhp]
[:sausu:]
「米卡小姐也很认真地听你倾诉。[rhr]
_　如果她不行的话我也可以。有什么不安的话，就直接说出来……」[rhp]

[:jet2:][jet body=unif hr=on2 kao=2 ]
「说出来就能多活一天吗」[rhp]

[:sausu:][sausu kao=0 as=on ]
「！」[rhp]

[:jet2:]
「要是真有能保证这种事的人，就带他来见我。那样的话，[rhr]
_　我绝对会把对健康人的嫉妒从1数到100说个遍」[rhp]

[:sausu:][sausu kao=3 as=on ]
「那个……」[rhp]

[:jet2:]
「不可能的吧。我明白的。因为这种事本来就不存在」[rhp]
[:jet2:]
「『肯定』和『万一』我都不信。[rhr]
_　我只相信眼前看得见的现实」[rhp]

[:sausu:]
「………………、因为我是个爱唱反调的人」[rhp]

[:jet2:][jet body=unif hr=on2 kao=6 ]
「不如说我逻辑性强。……不过对于神明来说[rhr]
_　那些整天念叨银河铁道的家伙是不会懂的吧」[rhp]

[:sausu:][sausu kao=2 ]
「！银河铁道是真实存在的　不是幻想」[rhp]

[:jet2:][jet body=unif hr=on2 kao=12 ]
「刚才的话已经忘记了吗？[rhr]
_　看不见的东西就不相信 这就是我的原则」[rhp]
[:jet2:][jet body=unif hr=on2 kao=2 ]
「不甘心的话 直接带我去见识不就好了 如果你做得到的话」[rhp]

[:sausu:][sausu kao=2 ]
「明白了」[rhp]

[:jet2:][jet body=unif hr=on2 kao=6 as=on ]
「哈？你说明白是什么意思……」[rhp]

[:sausu:]
「既然说到这个份上 就让你亲眼看看银河铁道吧」[rhp]
[:sausu:]
「作为交换要答应我。不要再粗暴对待自己。[rhr]
_　直到终有一日渡往彼岸之前 请珍惜自己……认真活在当下」[rhp]

[:jet2:]
「在胡说什么啊……」[rhp]

[:sausu:]
「可以吗？」[rhp]

[:jet2:]
「…………好了好了 我答应就是」[rhp]

[:sausu:][sausu kao=5 ]
「很好」[rhp]

[fbgm]

[off_all]

[:sausu:][sausu kao=5 ]
「那么 我们现在就出发吧」[rhp]

;****************************************
;魔法で鉄道世界に
"
#
[s_mask color=0x000000 time=2000]
[off_all]
; 魔法
[se storage="mag_08.ogg"]
; 背景表示
[bg storage="train_05.jpg" time=100]
; 全部のフィルターを打ち消す
[free_filter ]
; ウィンドゥの設定
[position layer="message0" frame="win.png" left=0 top=520 width=1280 height=200 page=fore visible=true ]
[s_mask_off time=2000]

[bgm storage="bgm_19.ogg"]
;****************************************

[:jet2:]
「――――……！」[rhp]
[:jet2:][jet body=unif hr=on2 kao=2 as=on ]
「！？这、这里是？我刚才明明还在病房……！！」[rhp]

[off_all]

[:jet2:]
「喂南！　你躲在哪里―――」[rhp]

[:sausu:][sausu kao=1 ]
「在这里哦」[rhp]

[:jet2:][jet body=unif hr=on2 kao=2 as=on ]
「南！」[rhp]

[:sausu:]
「感觉如何。时隔许久再次自主活动的感想」[rhp]

[:jet2:]
「哎……啊 奇怪。为什么我能自己走路……」[rhp]

[:sausu:]
「这个世界有魔法存在 只要许愿几乎都能实现」[rhp]
[:sausu:]
「怎么样？这就是银河铁道哦」[rhp]

[:jet2:]
「开什么玩笑……这种东西……」[rhp]

[:sausu:]
「用这双脚站立着，用这双眼看见的风景，你会如何诠释？」[rhp]
[:sausu:]
「……眼前的事你总该相信吧」[rhp]

[:jet2:]
「………………那是」[rhp]

[:sausu:]
「我呢，在那个世界死去的孩子们[rhr]
_　已经邀请了好多人来到这个世界」[rhp]
[:sausu:]
「没折过我的纸鹤的孩子也无所谓。当然事先[rhr]
_　会确认这点，但大家都会立刻眼睛发亮地点头同意」[rhp]
[:sausu:]
「因为这里有真正的幸福啊」[rhp]

[:jet2:][jet body=unif hr=on2 kao=0 ]
「真正的……幸福……」[rhp]

[:sausu:][sausu kao=13 ]
「不用害怕。但也不可以自暴自弃哦。[rhr]
_　迄今为止努力至今的你，这个世界会比任何人都更祝福你」[rhp]
[:sausu:]
「愿这个世界能成为你活着的希望」[rhp]

[:jet2:][jet body=unif hr=on2 kao=6 as=on ]
「………………」[rhp]

[:sausu:][sausu kao=1 ]
「对了。也给你做个替身吧」[rhp]

[:jet2:][jet body=unif hr=on2 kao=0 ]
「替身？……那是什么？」[rhp]

[:sausu:][sausu kao=1 ]
「简单来说，就是你来这个世界之前，[rhr]
_　代替你在这里生活的孩子」[rhp]
[:sausu:]
「替身会以原型孩子理想中的姿态存在。[rhr]
_　当你来到这里时，就能直接继承那个理想姿态」[rhp]
[:sausu:]
「记忆会保留，而且替身获得的知识也会变成自己的」[rhp]
[:sausu:][sausu kao=5 ]
「本来这个替身角色，是留给我朋友亲近的孩子用的……[rhr]
_　但你性格有点别扭呢。就额外再给你一个奖励吧」[rhp]

[:jet2:][jet body=unif hr=on2 kao=8 as=on ]
「你、你突然这么说……是认真的吗？」[rhp]

[:sausu:][sausu kao=0 ]
「千真万确。等着瞧吧」[rhp]

[off_all]

;****************************************
[bg_magic_c]
;****************************************

[:unknown:][hati kao=5 ]
「嘿！」[rhp]

[off_all]

[:jet2:][jet body=unif hr=on2 kao=2 as=on ss=on ]
「什……！？我、我的！？……这张脸……？」[rhp]

[off_all]

[chara_part name="hati" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sausu:]
「初次见面。另一个杰特」[rhp]

[:unknown:]
「哟！初次见面！」[rhp]

[:sausu:]
「这里的基本情况应该都输入你脑中了，怎么样？[rhr]
_　有什么想问我的吗？」[rhp]

[:unknown:]
[font size=30]
「没有！！」[rhp]
[resetfont]

[:sausu:][sausu kao=14 as=on ]
「哈哈哈！真是个爽快的家伙」[rhp]

[:unknown:][hati kao=11 ]
「原来如此……这就是银河铁道啊！」[rhp]

[off_all]

[:unknown:][hati kao=5 ]
「然后、你就是我！！」[rhp]

[off_all]

[:jet2:][jet body=unif hr=on2 kao=2 as=on ]
「诶？啊不是，」[rhp]

[off_all]

[chara_part name="jet" body=unif kao=2 as=on ss=off hh=off hr=on2 ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:unknown:]
「噢！感觉不错嘛！话少这点特别酷！」[rhp]
[:unknown:]
「你觉得呢？据说这是按你理想形象打造的，像吗？」[rhp]

[:jet2:]
「恶、恶心死了……」[rhp]

[:unknown:][hati kao=2 as=on ]
「为什么啊！？」[rhp]

[:jet2:]
「顶着同样的脸说话。而且还是这种蠢样……」[rhp]

[:unknown:]
「蠢！？哪里蠢了？[rhr]
_　我改！快告诉我！是穿搭问题吗！？」[rhp]

[:jet2:]
「全部都很蠢！你看起来完全没动脑子……[rhr]
_　这也能叫我的理想形象？简直难以置信」[rhp]

[off_hati]

[chara_part name="sausu" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sausu:][sausu kao=1 ]
「我能理解。他的活力和开朗是你所不具备的部分」[rhp]

[:jet2:][jet body=unif hr=on2 kao=3 as=on ]
「……………」[rhp]

[off_sausu]

[chara_part name="hati" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:unknown:][hati kao=1 ]
「怎么了杰特？肚子疼吗？_ 要我去问问厕所在哪吗！？」[rhp]

[off_all]

[:unknown:][hati kao=1 ]
「不好意思！厕所在哪里！？」[rhp]

[:sausu:][sausu kao=0 ]
「诶？那、那个暂时没有准备啊……[rhr]
_　不过，现做一个给你也行……」[rhp]

[:unknown:][hati kao=14 ]
「瞧啊杰特！幸好是个温柔大叔呢！」[rhp]

[:sausu:][sausu kao=2 as=on ]
「大叔……」[rhp]

[off_all]

[chara_part name="jet" body=unif kao=6 as=on ss=off hh=off hr=on2 ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:jet2:]
「……你压根儿就没动脑子吧」[rhp]

[:unknown:][hati kao=2 ]
「在思考啊！没有厕所意味着，[rhr]
_ 这个世界不需要排泄……！？之类的！」[rhp]
[:unknown:][hati kao=4 as=on ]
「！！所以你刚才说想上厕所是装的！？」[rhp]

[:jet2:]
「我从头到尾都没说过那种话」[rhp]

[:unknown:][hati kao=6 as=on ]
「！？咦？」[rhp]

[:jet2:]
「哈……算了」[rhp]

[off_all]

[:sausu:][sausu kao=1 ]
「对、对了。也得给你起个名字呢。[rhr]
_　我习惯用宝石相关的名字，你有什么想法？」[rhp]

[off_all]

[chara_part name="jet" body=unif kao=0 as=off ss=off hh=off hr=on2 ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:unknown:]
「没有！杰特你呢？」[rhp]

[:jet2:][jet body=unif hr=on2 kao=12 ]
「羽田螺旋桨」[rhp]

[:unknown:][hati kao=5 hh=on ]
[font size=30]
「超帅！！」[rhp]
[resetfont]

[:jet2:][jet body=unif hr=on2 kao=2 as=on ]
[font color=0x4682b4]
（果然这家伙完全不经大脑……！）[rhp]
[resetfont]

[off_jet]

[chara_part name="sausu" body=base kao=13 as=on ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="true" time=150]

[:sausu:]
「那个……叫哈托谢普怎么样？」[rhp]

[:heartshape:][hati kao=6 ]
「太长了吧……！？最好和杰特字数相同！」[rhp]

[:sausu:][sausu kao=1 ]
「那取个方便叫的简称就行」[rhp]

[:heartshape:][hati kao=5 ]
「那就哈噗！！」[rhp]

[:sausu:][sausu kao=13 ]
「呵呵、我觉得像蓝靛果就挺好的！」[rhp]

[off_all]

[:jet2:][jet body=unif hr=on2 kao=2 as=on ]
[font color=0x4682b4]
（这群家伙怎么回事……？[rhr]
_　跟不上节奏的我才不正常吗？）[rhp]
[resetfont]

[:heartshape:][hati kao=13 ]
「不错嘛！我可是很喜欢水果的！」[rhp]
[:heartshape:][hati kao=5 ]
「呐杰特！你以前也挺喜欢水果的对吧！[rhr]
_　班上同学和班主任老师经常―――」[rhp]

[:jet2:][jet body=unif hr=on2 kao=2 ]
「刚转去临终关怀院后，[rhr]
_　那群薄情的家伙就全都不来了。没兴趣」[rhp]

[:heartshape:][hati kao=3 as=on ]
「啊……、……抱歉！明明这只蓝靛果，[rhr]
_　是作为你的替身我却连这种事都没察觉…！」[rhp]

[:jet2:][jet body=unif hr=on2 kao=6 as=on ]
「～～～……叫哈托谢普不就好了。[rhr]
_　蓝靛果什么的土爆了……要简称就叫哈蒂吧」[rhp]

[:heartshape:][hati kao=14 hh=on ]
「哈蒂……！？ 哇哦，好帅！不愧是杰特！[rhr]
_　又聪明说话又好懂，还特别酷！」[rhp]

[:jet2:][jet body=unif hr=on2 kao=5 as=on ]
「这种程度谁都想得到……是你话说太多了。[rhr]
_　这种蠢货居然是理想型，简直离谱」[rhp]

[:heartshape:][hati kao=3 as=on ]
「唔……是、是这样吗……」[rhp]

[:jet2:][jet body=unif hr=on2 kao=11 ]
「…………不过嘛，那种乐天派确实让人向往」[rhp]

[:heartshape:][hati kao=3 hh=on ]
「――――！　杰特啊啊……！」[rhp]
[:heartshape:]
「谢谢你！！　听你这么说多少有点……[rhr]
_　不对，现在信心爆棚啦！！」[rhp]
[:heartshape:][hati kao=13 hh=on ]
「在你来到这里之前，[rhr]
_　你的位置我会好好守住！」[rhp]

[:jet2:][jet body=unif hr=on2 kao=2 as=on ]
「……！　啊、这样啊……我、死了的话你就能……」[rhp]

[:heartshape:][hati kao=11 ]
「别担心，杰特！　我会为你建立圆满的人际关系，[rhr]
_　头发和肌肤的护理也每天都不落下！」[rhp]

[:jet2:][jet body=unif hr=on2 kao=2 ]
「……、为什么你能这么开朗地说出这种事。[rhr]
_　这不就等于说、是因为我你才会消失啊」[rhp]

[:heartshape:][hati kao=1 ]
「说什么呢。我就是为此而生的！[rhr]
_　今后我在这里构筑的生活、会成为你光明未来的基石！」[rhp]

[:jet2:]
「……………………」[rhp]

[off_all]

[chara_part name="hati" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:heartshape:]
「……！　反应好冷淡……南、我做错什么了吗？」[rhp]

[:sausu:][sausu kao=13 ]
「不不、没做错。[rhr]
_　杰特他啊、你也知道是个孤僻的孩子嘛」[rhp]

[:heartshape:]
「鸭子！？」[rhp]

[:sausu:][sausu kao=6 as=on ]
「呃…………」[rhp]
[:sausu:][sausu kao=14 as=on ]
「……好、好啦！　我们差不多该回去了」[rhp]

[:heartshape:][hati kao=5 ]
「怎么这样、再待会儿不好吗。[rhr]
_　来辩论吧！　关于你想成为怎样的杰特！」[rhp]

[:sausu:][sausu kao=1 ]
「很遗憾、既没有那个时间也没有灵力了。[rhr]
_　今天只是为了向杰特证明银河铁道的存在才来的呀」[rhp]

[:heartshape:][hati kao=3 ]
「切——」[rhp]

[off_all]


[:sausu:][sausu kao=1]
「杰特。准备好了吗？」[rhp]

[off_all]

[:jet2:]
「………………」[rhp]

[:sausu:][sausu kao=0 ]
「……杰特？」[rhp]

[off_all]

[:jet2:][jet body=unif hr=on2 kao=14 as=on hh=on ]
「………噗、哈哈哈！」[rhp]

[off_all]

[chara_part name="hati" body=base kao=4 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=4 as=on ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:2nin:]
「！」[rhr]
「！」[rhp]

[off_sausu]

[chara_part name="jet" body=unif kao=5 as=on ss=off hh=off hr=on2 ]
[chara_show name="jet" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:jet2:]
「你真是个奇怪的家伙。[rhr]
_　辩论什么的……哈哈哈！我的理想不该是你才对吗」[rhp]

[:heartshape:][hati kao=2 as=on hh=on ]
「才、才不是！我是说今后该以什么风格[rhr]
_　作为目标比较好啦！」[rhp]

[:jet2:]
「保持现状就好。按你喜欢的方式去做吧。[rhr]
_　这份自由确实是我所追求的东西」[rhp]
[:jet2:][jet body=unif hr=on2 kao=1 ]
「……你或许真的完全符合我的理想呢」[rhp]

[:heartshape:][hati kao=14 hh=on ]
「杰特……！嘿嘿，果然是这样！？」[rhp]
[:heartshape:]
「明白了！那我就为回应你的期待，[rhr]
_　活得超级自由给你看！」[rhp]

[:jet2:]
「我很期待哦」[rhp]

[:heartshape:]
「包在我身上！」[rhp]

[off_all]

[:jet2:][jet body=unif hr=on2 kao=12 ]
「……不过说实话……」[rhp]

[off_all]

[:heartshape:][hati kao=1 ]
「？抱歉杰特，没听清。再说一遍！」[rhp]

[off_all]

[:jet2:][jet body=unif hr=on2 kao=13 ]
「…………、算了。当我没说」[rhp]

[off_all]

[chara_part name="jet" body=unif kao=0 as=off ss=off hh=off hr=on2 ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sausu:]
「很舍不得吧。我懂这种心情」[rhp]
[:sausu:]
「但只要想着终有一天能回到这里，[rhr]
_　今后的每一天都会变得快乐吧」[rhp]

[:jet2:]
「…………、今后的每一天……」[rhp]

[off_all]

[:sausu:][sausu kao=13 ]
「再见哈托谢普。之后就交给你了」[rhp]

[off_all]

[:heartshape:][hati kao=14 ]
「放马过来吧！！」[rhp]

;****************************************

#
[s_mask color=0x000000 time=2000]
[off_all]
; 背景表示
[bg storage="hsps_09n.jpg" time=100]
; 夜フィルター
[filter layer="1" brightness="60"]
; ウィンドゥの設定
[position layer="message0" frame="win2.png" left=0 top=520 width=1280 height=200 page=fore visible=true ]
[s_mask_off time=2000]

;****************************************

[:jet2:]
「―――――……唔」[rhp]
[:jet2:][jet body=unif hr=on2 kao=0 as=on ]
「……！回来了……」[rhp]

[:sausu:][sausu kao=1 ]
「辛苦了。银河之旅感觉如何」[rhp]

[:jet2:][jet body=unif hr=on2 kao=7 ]
「……嘛、虽说是旅行但也没那么夸张啦」[rhp]

[:sausu:]
「想慢慢逛逛吗？」[rhp]

[:jet2:][jet body=unif hr=on2 kao=3 as=on ]
「那当然。明明不是宇航员却能去银河系。[rhr]
_　这种事居然真的存在啊……」[rhp]
[:jet2:][jet body=unif hr=on2 kao=6 as=on ]
「……怀疑你真抱歉」[rhp]

[:sausu:][sausu kao=1 ]
「没关系。你愿意相信我很开心」[rhp]
[:sausu:]
「现在不留在那边有各种原因[rhr]
_　主要是怕你说舍不得回来就麻烦了」[rhp]
[:sausu:]
「不过你看样子没问题。或许该多待会儿的」[rhp]

[:jet2:][jet body=unif hr=on2 kao=7 ]
「…………哈托谢普吗」[rhp]

[:sausu:]
「挺有趣的孩子呢。感觉窥见了你的内心……开玩笑的」[rhp]

[:jet2:]
「…………或许吧」[rhp]

[:sausu:][sausu kao=0 ]
「咦。以为你会否认来着」[rhp]

[:jet2:][jet body=unif hr=on2 kao=12 ]
「但那么肌肉脑子我可受不了。[rhr]
_　你稍微夸大其词了吧」[rhp]

[:sausu:][sausu kao=13 as=on ]
「才、才没有啦～。不过俗话说……大能兼小嘛」[rhp]
[:sausu:][sausu kao=8 as=on ]
「……该不会，惹你厌了？」[rhp]

[:jet2:]
「我没那么说」[rhp]

[:sausu:][sausu kao=13 ]
「……呵呵！就知道你会这么说。[rhr]
_　你和哈托谢普说话时的表情，我还是第一次见」[rhp]

[:jet2:][jet body=unif hr=on2 kao=0 ]
「南。……你觉得我能变成他那样吗？」[rhp]

[:sausu:][sausu kao=1 ]
「说不准。……但当他的心与你合二为一时，[rhr]
_　肯定会给你带来好的影响」[rhp]
[:sausu:]
「你的未来充满了梦想与期待。[rhr]
_　所以希望你不要舍弃当下，无惧地活下去」[rhp]
[:sausu:]
「虽然不必畏惧死亡，但也没有理由拒绝生存」[rhp]

[fbgm]

[:jet2:][jet body=unif hr=on2 kao=3 ]
「………………」[rhp]

[off_all]

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
[vostart]
;--------------------------------------------------------------------------------------------

[:jet2:][jet body=unif hr=on2 kao=3 ]
「…………呐 南」[rhp]

[:sausu:]
「嗯？怎么了？」[rhp]

[bgm storage="bgm_15.ogg"]

[:jet2:]
「杀了我吧」[rhp]

[off_all]

[:sausu:][sausu kao=2 as=on ]
「…………哈？」[rhp]

[off_all]

[:jet2:][jet body=unif hr=on2 kao=3 ]
「我想立刻去那个世界。所以杀了我吧」[rhp]

[:sausu:][sausu kao=2 as=on ]
「你……你在说什么。这种事不行！」[rhp]

[:jet2:]
「这样啊…」[rhp]
[:jet2:]
「……那能把水果刀拿过来吗。[rhr]
_　应该就在那边的抽屉里」[rhp]

[:sausu:]
「虽然我不想问你要用它做什么……[rhr]
_　但别做傻事」[rhp]
[:sausu:]
「你误会了吗？[rhr]
_　我并不是在劝你早点去死啊！」[rhp]

[:jet2:]
「我知道。毕竟这完全是为了胆小如鼠的我」[rhp]
[:jet2:]
「所以这是我得出的结论。[rhr]
_　想早点死掉，去那个世界」[rhp]

[:sausu:]
「为、为什么这样……」[rhp]

[:jet2:]
「…………回到这边后，感到非常失望」[rhp]
[:jet2:]
「忘不了刚才还能行走的感觉。[rhr]
_　……已经完全忘记身体变得如此沉重这件事了」[rhp]
[:jet2:]
「都是因为你，让我想起来了」[rhp]

[:sausu:]
「……啧、总之办不到。[rhr]
_　我非常喜欢你们。杀人什么的，绝对……」[rhp]

[off_all]

;****************************************
[still storage="cg/e_1.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/e_1.png"]
;****************************************

[:jet2:]
「那就别让我做这种梦啊混账！！」[rhp]

[:sausu:]
「呃……！？」[rhp]

[:jet2:]
「搞什么，连那种蠢货都造出来。是想故意恶心我吗！？」[rhp]
[:jet2:]
「就因为我每天每天[rhr]
_　想着这些窝囊又无聊的事，你就来挖苦我吗！？」[rhp]

[:sausu:]
「不、不是的。我……！」[rhp]

[:jet2:]
「说什么别害怕，开什么玩笑。[rhr]
_　总有一天能来这里？那为什么现在就把我带过去！」[rhp]

[:sausu:]
「啊……」[rhp]

[:jet2:]
「让我看到那种地方……！[rhr]
_　当然会更不想活了啊！？」[rhp]

[:sausu:]
「……呜、对、对不起……[rhr]
_　我完全没那个意思……只是想消除你的不安……」[rhp]

[:jet2:]
「谁让你多管闲事了！[rhr]
_　走不了路的话死在原地也无所谓！」[rhp]
[:jet2:]
「半吊子地让我看这些，剩下的日子要我怀着什么心情……」[rhp]

;****************************************
[still_end frame="win2.png" storage="hsps_09n.jpg" time=500]
;****************************************

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:takeru:][take kao=2 ]
「羽田君！！」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[:jet2:][jet body=unif hr=on2 kao=2 as=on ]
「……！！老师」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[chara_part name="take" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=3 as=on ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:takeru:]
「怎么了？突然一个人叫起来……！」[rhp]

[:tiaki:]
「哪里痛吗？要是有不对劲的地方―――」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

;****************************************
[still storage="cg/e_1b.png" rule="007.png" width="1280" height="720" time=500]
[cg storage="cg/e_1b.png"]
;****************************************

[:jet2:]
「南那家伙！南在愚弄我！！」[rhp]

[:tiaki:]
「诶……」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:takeru:]
「南、南他……」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:jet2:]
「―――！！　老师你们也知道那家伙吗！？」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:takeru:]
「！　啊、啊不……那个……」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:jet2:]
「喂老师，那家伙是死神对吧！？[rhr]
_　千纸鹤不是能治病的东西吗？」[rhp]
[:jet2:]
「不会对我说'不如去死'之类的话吧！？」[rhp]

[:sausu:]
「不对！　我从来没说过那种话！」[rhp]

[:jet2:]
「绝对说过！　是南告诉我的！」[rhp]
[:jet2:]
「比起这种狗屎一样的现实，死了反而更痛快！」[rhp]


;****************************************
[still_end frame="win2.png" storage="hsps_09n.jpg" time=500]
;****************************************

[:tiaki:]
「…………！！」[rhp]

;病室を飛び出していくミカ
[se storage="door_09.ogg"]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:takeru:][take kao=2 as=on ]
「！　大美贺小姐！？　你要去哪……！」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[:jet2:][jet body=unif hr=on2 kao=2 as=on ]
「终于来接我了啊……！[rhr]
_　明明以为终于能解脱了……！」[rhp]

[off_all]

[:jet2:]
「骗子！　快杀了我啊！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:takeru:]
「羽、羽田君！　冷静点……！」[rhp]

;****************************************
[still storage="cg/e_2.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/e_2.png"]
;****************************************

[:sausu:]
「………………」[rhp]

[::]
…………说不出话来。[rhp]
我从未有过那样的意图。[rhp]
只是想告诉你们终结并非恐怖之事。[rhr]
只希望你们能安稳度过最后时光。[rhp]
毕竟我是你们的朋友啊。[rhp]

[:sausu:]
[font color=0x4682b4]
（……但是……）[rhp]
[:sausu:]
（………………我是为了实现愿望而降生的）[rhp]
[resetfont]

[::]
再也不愿辜负任何人的期待。[rhr]
不想像对博士那样，为未能实现的心愿后悔。[rhp]

[:sausu:]
「………………」[rhp]

[::]
这么做是错的。[rhp]
但已经走到无法回头的地步了。[rhr]
教会他死后安宁的，不是别人正是我。[rhp]
我扼杀了朋友的心。[rhr]
必须为此承担责任。[rhp]

;****************************************
[still_end frame="win2.png" storage="black.jpg" time=500]
;****************************************

…………我就实现你的愿望吧。[rhp]

;****************************************
;エントランス
[set_n storage="hsps_02m.jpg"]
;****************************************

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
[vostart]
;--------------------------------------------------------------------------------------------

[:tiaki:][tiaki kao=2 as=on ]
「夜君！夜君！！你在的吧！？」[rhp]

;****************************************
[bg_magic_d]
;****************************************

[:yoru:][yoru kao=6 as=on ]
「―――怎么了，吵吵嚷嚷的」[rhp]

[off_all]

[:tiaki:][tiaki kao=2 as=on ]
「杀了那个男人啊！」[rhp]

[off_all]

[:yoru:][yoru kao=2 as=on ]
「！？……等等，冷静点。究竟怎么回事」[rhp]

[off_all]

;****************************************
[still storage="cg/e_3.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/e_3.png"]
;****************************************

[:tiaki:]
「南他！！说要『去死』啊！！」[rhp]

[:yoru:]
「……！」[rhp]

[:tiaki:]
「明明绝对就在现场的！却不敢现身的懦夫……！！[rhr]
_　大家就是被那种男人带走的吗！？」[rhp]
[:tiaki:]
「别开玩笑了！要死也是你去死！替大家去死啊！」[rhp]
[:tiaki:]
「凭什么要为那种家伙―――」[rhp]

[:yoru:]
「孩子们要醒了。适可而止吧」[rhp]

[:tiaki:]
「呜……！可是我咽不下这口气啊！」[rhp]

[:yoru:]
「…………是南亲口说的吗」[rhp]

[:tiaki:]
「说了……！是杰特君亲口告诉我的！」[rhp]
[:tiaki:]
「那孩子明明能看见未来吧？[rhr]
_　应该早就知道自己时日无多了啊！」[rhp]
[:tiaki:]
「就像你说的，那家伙是最差劲的神明……！」[rhp]

[:yoru:]
「………………」[rhp]

[:tiaki:]
「夜君……！我会坚持下去的！」[rhp]
[:tiaki:]
「绝不会让南为所欲为。我一定……」[rhp]
[:tiaki:]
「我要把大家从那个男人的自我满足中解放出来！」[rhp]

[:yoru:]
「…………啊。我期待着」[rhp]

;****************************************
[still_end frame="win2.png" storage="hsps_02m.jpg" time=500]
;****************************************

[:yoru:][yoru kao=6 as=on ]
「………………？」[rhp]
[:yoru:]
[font color=0x4682b4]
（……至少，他应该是凭自己的良心在行动）[rhp]
[:yoru:]
（那个幸福傻瓜，不像是会说这种话的人……）[rhp]
[resetfont]

[off_all]

[::]
但也不认为千秋这番气势汹汹的样子是装出来的。[rhp]
……就在我们三人终于要开始行动的时候，听到了令人在意的话。[rhr]
稍微调查一下那家伙的周边吧……[rhp]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
[set_b storage="hsps_09n.jpg"]
;****************************************

[:jet2:][jet body=unif hr=on2 kao=3 ]
「………………」[rhp]

[off_all]

[:sausu:][sausu kao=3 as=on ]
「…………杰特」[rhp]

[off_all]

[:jet2:][jet body=unif hr=on2 kao=3 ]
「………………」[rhp]

[off_all]

[chara_part name="jet" body=unif kao=3 as=off ss=off hh=off hr=on2 ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=3 as=on ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sausu:]
「…………抱歉」[rhp]

[:jet2:]
「………………」[rhp]

[:sausu:]
「喂，杰……」[rhp]

[:jet2:]
「够了」[rhp]

[:sausu:][sausu kao=8 as=on ]
「！」[rhp]

[:jet2:]
「……反正无论我说多少，你都什么都不肯做」[rhp]
[:jet2:]
「明明是你告诉我那个世界的事。这样太过分了……」[rhp]

[:sausu:]
「…………、不。不是这样的」[rhp]
[:sausu:][sausu kao=3 ]
「好吧。…………我会实现你的愿望」[rhp]

[:jet2:][jet body=unif hr=on2 kao=0 as=on ]
「诶……」[rhp]

[:sausu:][sausu kao=3 ]
「在那之前，可以先听我说几句吗」[rhp]

[:jet2:][jet body=unif hr=on2 kao=2 as=on ]
「啊，我听！　什么！？　快说！」[rhp]

[:sausu:][sausu kao=1 ]
「……谢谢。真是个好孩子呢」[rhp]

[off_all]

;****************************************
#
[bg storage="hikari.jpg" time=1000]
;****************************************

[:sausu:]
「……世间万物皆由『灵魂』『精神』『肉体』构成」[rhp]
[:sausu:]
「三者通过『灵魂』维系。若用机器人来比喻[rhr]
_　肉体是机械，精神是计算机，灵魂则是连接二者的线路」[rhp]
[:sausu:]
「所谓死亡，就是这三者中灵魂要素的消逝。[rhr]
_　一旦断线，机械就无法执行计算机的指令」[rhp]

[:jet2:]
「……？　啊……」[rhp]

;****************************************
#
[bg storage="cg/b2_1.png" time=500]
;****************************************

[:sausu:]
「那个世界存在于入口处的绘画《糠星夜》之中。[rhr]
_　那幅画是入口，连接着那边空间的通道」[rhp]
[:sausu:]
「我将至今为止被解放的孩子们的灵魂与精神，趁着仍残留在这栋建筑物内时[rhr]
_　吸纳进画中世界，迎接他们前往彼方」[rhp]

[:jet2:]
「精神与灵魂……也就是说，相当于幽灵状态对吧」[rhp]

[:sausu:]
「比如同样是灵体，既有无法认知自己死亡的灵，也有具备明确意志的灵，[rhr]
_　前者属于仅存灵魂的状态，后者则是精神与灵魂仍保持联系的存在」[rhp]

[:jet2:]
「嘿……还真有道理啊」[rhp]

[:sausu:]
「其实若想进入那个世界，活人也能办到。[rhr]
_　就像我刚才对你做的那样」[rhp]
[:sausu:]
「原理很简单，只需暂时将精神『单独』从肉体抽离，[rhr]
_　转移到对面。缺失的两个部分由我的魔法来补全」[rhp]
[:sausu:]
「但要维持现世生命的同时实现这点，需要耗费庞大魔力。[rhr]
_　所以只能在短时间内去那边世界」[rhp]

;****************************************
#
[bg storage="hsps_09n.jpg" time=1000]
;****************************************

[:sausu:][sausu kao=6 ]
「那要怎样才能在那边世界永久活下去」[rhp]

[:jet2:][jet body=unif hr=on2 kao=6 as=on ]
「哈？等等。活着的意思是……」[rhp]

[:sausu:]
「没有肉体的付丧神的魔力[rhr]
_　与生物的生命能量几乎是同义」[rhp]
[:sausu:]
「如果将维持你生命活动所需的能量最大限度分配到那边[rhr]
_　即使没有我的魔力也能在那边比较自由地活动」[rhp]

[:jet2:][jet body=unif hr=on2 kao=2 as=on ]
「那我这边的肉体就会……」[rhp]

[:sausu:]
「不得不依赖生命维持装置吧。由于精神不存在[rhr]
_　不仅会陷入昏迷，呼吸和营养补给都需要全面辅助」[rhp]
[:sausu:]
「能自主运转的只有最低限度的内脏功能……」[rhp]
[:sausu:]
「…………就是所谓的植物人状态」[rhp]

[:jet2:][jet body=unif hr=on2 kao=3 as=on ]
「…………」[rhp]

[:sausu:]
「…………因为是第一次尝试，不能保证成功」[rhp]
[:sausu:]
「但我无论如何都不能杀死你[rhr]
_　所以只想实现你这个愿望」[rhp]
[:sausu:]
「……请接受这个方案吧。杰特」[rhp]

[:jet2:][jet body=unif hr=on2 kao=2 ]
「…………哈托谢普会怎样？」[rhp]
[:jet2:]
「如果我去了那边[rhr]
_　会像死后那样变成哈托谢普吗？」[rhp]

[:sausu:][sausu kao=2 ]
「很遗憾，并不会」[rhp]
[:sausu:]
「所谓代役与原创的融合，是指将代役的精神与自信的精神二者，[rhr]
_　用同一个灵魂紧密连结在一起」[rhp]
[:sausu:]
「这次你的灵魂，必须留在现实世界以勉强维持肉体运转。[rhr]
_　正因如此你不会死去，但也因此无法与代役融合」[rhp]
[:sausu:]
「这种情况通常不可能发生。你们两人会成为共存关系」[rhp]

[:jet2:][jet body=unif hr=on2 kao=0 as=on ]
「这样啊……」[rhp]

[:sausu:][sausu kao=3 ]
「……坦白说，你的身体已经没有太多余裕了。[rhr]
_　万一你想再度回到这边时，我无法保证你的生命」[rhp]
[:sausu:]
「本就衰弱的身体机能，会进一步恶化。[rhr]
_　恐怕连与你脱离机械连接状态时的对话，也快要……」[rhp]

[off_all]

[:jet2:]
「………………」[rhp]

[:sausu:][sausu kao=8 ]
「…………谢谢你耐心听到现在」[rhp]
[:sausu:]
「我不会强迫你。[rhr]
_　希望你能认真考虑清楚这是否真是你想要的」[rhp]
[:sausu:]
「……若这是你的愿望我会实现。但请不要忘记，[rhr]
_　就算现在不急于一时，你迟早也会――――」[rhp]

[off_all]

;****************************************
[still storage="cg/e_4.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/e_4.png"]
;****************************************
;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
[vostart]
;--------------------------------------------------------------------------------------------

[:jet2:]
「我决定了」[rhp]

[:sausu:]
「――――！你认真的吗！？[rhr]
_　只要等待就能永远居住在那里，」[rhp]

[:jet2:]
「等待，要等到什么时候？」[rhp]

[:sausu:]
「……！」[rhp]

[:jet2:]
「虽说只是预估，但医生说我只剩五年」[rhp]
[:jet2:]
「这是事实还是父母的谎言，[rhr]
_　只是我在怀疑，并没有得到明确说明」[rhp]
[:jet2:]
「…………如果真的是五年后的话，该怎么办」[rhp]

[:sausu:]
「杰特……」[rhp]

[:jet2:]
「我知道矢部医生为了我，在拼命做各种努力。[rhr]
_　还说服我父母说还有治疗的机会」[rhp]
[:jet2:]
「但是……究竟要忍耐到什么时候？」[rhp]
[:jet2:]
「难道我还要这么痛苦地，再活五年吗……？」[rhp]

[:sausu:]
「呃……」[rhp]

[:jet2:]
「……在那边身体不会疼痛，也不会动弹不得呢」[rhp]

[:sausu:]
「嗯……」[rhp]

[:jet2:]
「不用吃苦药、难吃的饭，也不用打针输液呢」[rhp]

[:sausu:]
「嗯……」[rhp]

[:jet2:]
「消失的时候，也不会害怕呢」[rhp]

[:sausu:]
「…………我会在你期望的、最美的景色里送你离开」[rhp]

[:jet2:]
「这样啊…」[rhp]

;****************************************
#
[bg storage="cg/e_4b.png" width="1280" height="720" time=500]
[cg storage="cg/e_4b.png"]
;****************************************

[:jet2:]
「――――那可是最棒的事啊」[rhp]

[::]
他的侧脸显得格外明朗。[rhp]
充满希望、毫无忧愁的眼眸。[rhp]
…………真是讽刺啊。[rhp]
我虽期望这样的形式，却并未打算带你同行。[rhp]

[:jet2:]
「南」[rhp]
[:jet2:]
「让我搭乘银河铁道吧」[rhp]

;****************************************
[still_end frame="win2.png" storage="black.jpg" time=1000]
;****************************************

我垂下眼帘，轻轻呼出一口气。[rhp]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
[fbgm]

#
[s_mask color=0x000000 time=2000]
; 背景表示
[bg storage="train_05.jpg" time=100]
; 全部のフィルターを打ち消す
[free_filter ]
; ウィンドゥの設定
[position layer="message0" frame="win.png" left=0 top=520 width=1280 height=200 page=fore visible=true ]
[s_mask_off time=2000]

[bgm storage="bgm_13.ogg"]
;****************************************

[:jet2:][jet kao=2 ]
「…………你回来了啊」[rhp]

[off_all]

[:sausu:][sausu kao=3 ]
「………………」[rhp]

[off_all]

[chara_part name="jet" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:jet2:]
「别摆出那种表情啊南。[rhr]
_　你没有错。这个结果是我所期望的」[rhp]

[:sausu:
「……但是……」[rhp]

[:jet2:][jet kao=1 ]
「这件衣服，和哈托谢普是成套的吧。[rhr]
_　我从来没穿过这么正式的服装，合适吗？」[rhp]

[:sausu:]
「………………」[rhp]

[:jet2:][jet kao=6 ]
「～～～～……明明平时更吵闹的……真不习惯啊」[rhp]

[off_all]

[:drop:][drop kao=0 ]
「哈托谢普？」[rhp]

[:jet2:][jet kao=0 ]
「！！……你是谁？」[rhp]

[:drop:][drop kao=1 ]
「我是多洛普呀。刚才不是做过自我介绍了吗」[rhp]
[:drop:][drop kao=0 ]
「……咦，你头发颜色是不是和刚才不一样了？[rhr]
_　而且总觉得氛围也……」[rhp]

[:jet2:][jet kao=1 ]
「我是杰特。不是哈托谢普」[rhp]

[:drop:][drop kao=4 as=on ]
「诶？但是杰特先生不是哈托谢普的……」[rhp]

[:jet2:][jet kao=11 ]
「那家伙是我的『替身』对吧？我记住了。[rhr]
_　这就是所谓的本尊登场环节吧」[rhp]

[:drop:][drop kao=2 as=on ]
「这怎么可能！南，这到底是……」[rhp]

[off_all]

[:sausu:][sausu kao=0 ]
「我会说明的。其实……」[rhp]

;****************************************
[set_time_c]
;****************************************

[chara_part name="drop" body=base kao=2 as=on ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:drop:]
「…………竟然有这种事」[rhp]

[:sausu:]
「抱歉。虽然很突然……」[rhp]

[off_all]

[:jet2:][jet kao=7 ]
「南太夸张了。这明明是我的夙愿」[rhp]

[off_all]

[chara_part name="drop" body=base kao=2 as=on ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="jet" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:jet2:]
「你叫多洛普对吧。你是这个世界的居民吧」[rhp]

[:drop:]
「是、是的……我是这辆列车的乘务长」[rhp]

[:jet2:]
「我是杰特。从今天起要在这个世界受你们照顾了。请多指教」[rhp]

[:drop:][drop kao=1 as=on ]
「请、请多指教……」[rhp]

[off_all]
[yurasu]
[se storage="door_09.ogg"]

[:heartshape:][hati kao=2 as=on ]
[font size=25]
「杰特！？」[rhp]
[resetfont]

[off_all]

[:jet2:][jet kao=5 hh=on ]
「――――！　哈托谢普！」[rhp]

[off_all]

[chara_part name="jet" body=base kao=13 as=off ss=off hh=on hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=on ss=off hh=on hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:]
「…………呜、你……为什么……」[rhp]

[:jet2:]
「哈托谢普，好久不见！」[rhp]
[:jet2:]
「怎么样这个。吓到了吗？[rhr]
_　我拜托南，也决定住在这里了！」[rhp]

[:heartshape:]
「………………啊」[rhp]

[:jet2:][jet kao=5 hh=on ]
「我其实挺喜欢你的。[rhr]
_　我并不是想成为你本人什么的……那个，是作为朋友」[rhp]

[:heartshape:]
「为什么来了？」[rhp]

[:jet2:][jet kao=0 as=on ]
「诶？　你说为什么」[rhp]

[:heartshape:]
「该死……我感觉到你的气息所以来看看……！」[rhp]
[:heartshape:]
「哈啊——……呜！　你、竟然做这种事！！　是笨蛋吗！？」[rhp]

[:jet2:][jet kao=8 as=on ]
「……！！　为、为什么要生气。不开心吗？[rhr]
_　刚才不是你说要再见的吗」[rhp]

[:heartshape:]
[font size=26]
「我不是这个意思！！」[rhp]
[resetfont]

[:jet2:][jet kao=2 as=on ]
「……！？」[rhp]

[off_all]

[chara_part name="drop" body=base kao=2 as=on ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:drop:]
「他了解情况吗？」[rhp]

[:sausu:]
「大概吧。作为替身多少能理解一些……[rhr]
_　毕竟那是杰特的分身。头脑应该相当灵活」[rhp]

[off_all]

[chara_part name="jet" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=8 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:jet2:]
「哈、哈托谢普……」[rhp]

[:heartshape:]
「我说要再见不是这个意思……！[rhr]
_　这里可是死后世界啊？」[rhp]
[:heartshape:]
「谁会自愿来这种地方[rhr]
_　这点常识连笨蛋都懂吧！？」[rhp]

[off_all]

;****************************************
[still storage="cg/e_5.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/e_5.png"]
;****************************************

[:jet2:]
[font size=26]
「对不起呜！！」[rhp]
[resetfont]

[off_all]

[:heartshape:]
「！」[rhp]

[:jet2:]
「不过，没关系的！」[rhp]

[:heartshape:]
「哈……！？」[rhp]

[:jet2:]
「让你担心了很抱歉。当然会不安吧。[rhr]
_　通常来说这可是自己会被杀的话题啊……！」[rhp]
[:jet2:]
「但南不是说过吗？我们是能共存的！」[rhp]
[:jet2:]
「你不会死！也不会消失！」[rhp]

[:heartshape:]
「你、你在说什么啊……！[rhr]
_　不是这个意思。我想说的是……！」[rhp]

[:jet2:]
「？那到底在气什么……！？」[rhp]

[:heartshape:]
「气你抛弃自己的性命逃跑这件事啊！[rhr]
_　这不是明摆着吗！？」[rhp]

[:jet2:]
「逃跑……？我？不不不……！」[rhp]
[:jet2:]
「我现在可是活得好好的？」[rhp]

[:heartshape:]
「……！」[rhp]

[:jet2:]
「在那边世界姑且也算活着，但不是这个意思」[rhp]
[:jet2:]
「我来到这里，才终于能真正活出自己的生命」[rhp]

[:heartshape:]
「……啧、你啊……活着才不是你说的那样！」[rhp]

[:jet2:]
「那你说怎样才算？一辈子躺在床铺和轮椅上，吃着黏糊糊的病号饭吗？」[rhp]
[:jet2:]
「在那个狭窄的房间里听着熊孩子跑来跑去的噪音，[rhr]
_　整天盯着窗外健康人度日，这就是你说的活着？」[rhp]

[:heartshape:]
「那、那是……」[rhp]

;****************************************
[still storage="cg/e_5b.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/e_5b.png"]
;****************************************

[:jet2:]
「既然是我的分身，应该知道我过去的人生是什么样的吧？」[rhp]
[:jet2:]
「我中学之前也是个健康的人啊。如果没有癌症就能过普通人生了！[rhr]
_　但正因如此，你现在应该明白那种现状有多么悲惨痛苦吧？」[rhp]
[:jet2:]
「那你凭什么阻止我？都到这一步了还让我活下去、[rhr]
_　继续努力……我非得做到这种程度的理由到底是什么？」[rhp]

[:heartshape:]
「呃…………」[rhp]

[:jet2:]
「放心吧。不会抢走你的容身之处。[rhr]
_　妄想取代你这种奢侈的念头，我从来都没有过！」[rhp]
[:jet2:]
「我只是想重新回到那个时候罢了。[rhr]
_　只是想夺回原本属于我的自由……！」[rhp]

[:heartshape:]
「杰特……」[rhp]

[:jet2:]
「其实早就想死了，但我一直都在妥协。[rhr]
_　这次也是，连治疗都是因为父母要求才接受的」[rhp]
[:jet2:]
「可最后不还是白费功夫吗。受尽了折磨……已经够了吧。[rhr]
_　这次也该轮到你们听听我的请求了。好不好？」[rhp]
[:jet2:]
「求你了……就放过我吧……」[rhp]

[:heartshape:]
「………………啊」[rhp]

;****************************************
[still_end frame="win.png" storage="train_05.jpg" time=1000]
;****************************************

[:heartshape:][hati kao=3 as=on ]
「…………南、南」[rhp]

[off_all]

[::]
他像是逃避般移开与我对视的目光，转向南投去求助的视线。[rhp]
南露出苦涩的表情，像是放弃般摇了摇头。[rhp]

[chara_part name="hati" body=base kao=3 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sausu:][sausu kao=0 ]
「……那家临终关怀院的设备，无法照料植物人状态的孩子。[rhr]
_　所以今天杰特被转到了主楼的加护病房」[rhp]
[:sausu:]
「我的魔法无法覆盖到主楼。要让滞留在这里的杰特精神，[rhr]
_　正确回归远在彼处的肉体几乎不可能」[rhp]

[:heartshape:][hati kao=1 ]
「真的无计可施吗？　没有其他方法了……」[rhp]

[:sausu:][sausu kao=3 ]
「方法倒是存在，但我做不到」[rhp]
[:sausu:]
「……要我拒绝杰特那样恳切的诉求，我实在做不到啊」[rhp]

[:heartshape:][hati kao=1 ]
「…………」[rhp]

[off_all]

[::]
我与哈蒂之间持续着令人窒息的沉默。[rhr]
……其实我和哈蒂一样，都无法真正理解杰特。[rhp]
哈蒂肯定以为，不论从哪个角度来说——无论是自己能幸存这件事，还是我来到这里这件事——[rhr]
杰特都会由衷感到高兴吧。[rhp]
…………而让他产生这种想法的，不是别人正是我自己。[rhp]

[:heartshape:][hati kao=2 ]
「―――好，我明白了！」[rhp]

[off_all]

[:jet2:][jet kao=8 as=on ]
「！」[rhp]

[off_all]

[chara_part name="jet" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:]
「你可真是个彻头彻尾的废柴这点我已经充分领教了！[rhr]
_ 没想到我崇拜的楷模居然会说出这么没出息的台词！」[rhp]

[:jet2:][jet kao=5 as=on ]
「咕……哈哈……虽然火大但说得好……[rhr]
_　不愧是曾被我视为理想形象的男人呢……」[rhp]
[:jet2:]
「那我要以你为目标继续努――――」[rhp]

[:heartshape:]
[font size=30][yurasu]
「混账东西！！！！」[rhp]
[resetfont]

[:jet2:][jet kao=0 as=on ]
「诶」[rhp]

[:heartshape:][hati kao=61 ]
「你是笨蛋吗杰特！好不容易才实现共存，变成我之后要怎么办？[rhr]
_　哪有这么浪费的事啊！」[rhp]
[:heartshape:][hati kao=5 ]
「从今天起你就是搭档了！！」[rhp]

[:jet2:]
「啊、搭档……？」[rhp]

[:heartshape:]
「既然都到这份上了干脆就尽情享受这个世界吧！[rhr]
_　为了让你能全力自由地活在这世界，我会全力支援你的！」[rhp]
[:heartshape:]
「对自己抛下的事物，至少别留下后悔！」[rhp]

[:jet2:]
「哈托谢普……」[rhp]

[:heartshape:][hati kao=14 ]
「该叫哈蒂吧？别再客套了！[rhr]
_　我和你可是互补的三足鼎立……不对，是两足并立啊！」[rhp]

[:jet2:][jet kao=14 hh=on ]
「……嗯、好啊！」[rhp]

[off_all]

[:drop:][drop kao=0 as=on ]
「那个……事情算是、……解决了？」[rhp]

[off_all]

[:sausu:][sausu kao=3 ]
「………………」[rhp]

[off_all]

[::]
――――并非完全没有后悔。[rhp]
即使辜负了他的期待，或许也不该做这种事。[rhp]
以这样的形式带他来，完全无法预料今后会怎样。[rhp]

[:sausu:]
[font color=0x4682b4]
（但看见了吗？杰特那个表情。[rhr]
_　可比以往任何时候都要闪耀啊）[rhp]
[:sausu:]
（…………这样就好）[rhp]
[resetfont]

[::]
至少现在，我选择相信你的话语。[rhp]
想必会有许多人谴责我们的行为。[rhr]
不管被谁声讨都无所谓。[rhp]
即便如此，我也绝不辜负挚友的期待。[rhp]
永远、不再。[rhp]

;****************************************
[fbgm]
[s_mask color=0x000000 time=2000]
; 背景表示
[bg storage="black.jpg" time=100]
; ウィンドゥの設定
[position layer="message0" frame="win2.png" left=0 top=520 width=1280 height=200 page=fore visible=true ]
[s_mask_off time=2000]

;****************************************

6个月后[rhp]

;****************************************
[bg storage="hsps_09.jpg" time=1000]
[bgm storage="bgm_07.ogg"]
;****************************************

[:nusi:][nusi kao=2 ]
「求求您了！南老师……！」[rhp]

[off_all]

[chara_part name="nusi" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:nusi:]
[font size=26]
「请借钱给我！！」[rhp]
[resetfont]

[:sausu:]
「我拒绝」[rhp]

[:nusi:][nusi kao=3 as=on ]
「拜托通融一下！南社长！」[rhp]

[:sausu:][sausu kao=8 as=on ]
「那个～。这个房间对我而言是充满回忆的地方。[rhr]
_　我不想在这里进行如此卑劣的对话……」[rhp]

[off_sausu]

[chara_part name="mata" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="760" top="0" wait="true" time=150]

[:mataroko:][mata kao=1 ]
「努西小姐。您若再不改正那些肮脏的用钱方式、嗜赌成性的毛病、[rhr]
_　以及某种莫名散发的臭味，很快就会被孩子们抛弃哦」[rhp]

[:nusi:][nusi kao=2 as=on ]
「莫名发臭！？我居然有臭味吗？」[rhp]

[off_all]

[:gonzalez:][gon kao=2 as=on ]
「大概像是穿了十年的鞋垫散发的气味吧」[rhp]

[off_all]

[:nusi:][nusi kao=6 as=on ss=on ]
「！！！」[rhp]

[off_all]

[chara_part name="nusi" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="mata" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="760" top="0" wait="true" time=150]

[:mataroko:]
「有些污垢是清洗也无法去除的。[rhr]
_　作为鞋子能穿十年也算是寿终正寝了」[rhp]

[:nusi:][nusi kao=2 as=on ]
「谁允许你擅自安排丢弃计划了……我明白了。[rhr]
_　我保证再也不赌博了！」[rhp]

[:mataroko:][mata kao=2 ]
「前几天您也是这么说的！！[rhr]
_　这次我一定要把您当大型垃圾处理掉！」[rhp]

[off_all]

[chara_part name="gon" body=base kao=11 as=on ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=13 as=on ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:gonzalez:]
「抱歉南。兄姐的事你就别管了」[rhp]

[:sausu:]
「但放任不管的话努西小姐恐怕会有危险……」[rhp]
[:sausu:][sausu kao=0 ]
「……不过真罕见啊，你们居然被送到101号室。[rhr]
_　聚集在此的，恐怕是……」[rhp]

[:gonzalez:][gon kao=1 ]
「没错。这是资深玩具大集结[player2]的欢迎仪式哟。[rhr]
_　如今那家伙可是这所临终关怀院的最年长者。VIP待遇呢」[rhp]
[:gonzalez:][gon kao=3 ]
「……不过……那家伙也终于搬进101号室了吗」[rhp]

[:sausu:][sausu kao=1 ]
「米卡小姐，每次有人入住这个房间时[rhr]
_　你都会精心装饰，但这次特别起劲呢」[rhp]
[:sausu:][sausu kao=13]
「呵呵。今天三人齐聚床头。[rhr]
_　[player2]应该能做个好梦吧。对吧努西……」[rhp]

[off_all]

;スプレーの音
[se storage="se4_08.ogg"]

[chara_part name="nusi" body=base kao=2 as=on ss=on hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="mata" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:mataroko:]
「利瑟修！！　利瑟修！！」[rhp]

[:nusi:]
「哇！别这样！别用花束的香气裹住我！」[rhp]

[off_all]

[chara_part name="gon" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=13 as=on ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sausu:]
「…………」[rhp]

[:nusi:]
「哈哈……真开心呢……」[rhp]

[:gonzalez:][gon kao=8 as=on ]
「那两人无论在铁道那边还是这边，总是这幅德性啊。[rhr]
_　不过大家倒是很享受他们这样的表现」[rhp]

[:sausu:][sausu kao=1 ]
「一直很感谢你们活跃气氛。[rhr]
_　那边的世界快乐吗？」[rhp]

[:gonzalez:][gon kao=1 ]
「啊。当然是！而且……果然很美好啊。[rhr]
_　隔这么久再看到孩子们的笑脸，真令人高兴」[rhp]
[:gonzalez:]
「话虽如此，孩子们也几乎都下车离开了。[rhr]
_　要说寂寞也确实寂寞呢……」[rhp]

[:sausu:]
「现在留下来的除了杰特，就只有和近了」[rhp]

[:gonzalez:]
「是啊。和近正在[player2]等待」[rhp]

[:sausu:]
「这样啊……」[rhp]

[:gonzalez:][gon kao=11 ]
「嘛！不管人数减少了多少，[rhr]
_　我们只要像平时那样做就行啦！」[rhp]

[:sausu:][sausu kao=13 ]
「真让人安心。也请代我向约尔大人问好」[rhp]

[:gonzalez:][gon kao=0 as=on ]
「诶？」[rhp]

[:sausu:][sausu kao=13 ]
「……呵呵。没什么啦！」[rhp]

[:gonzalez:][gon kao=2 as=on ss=on ]
[font color=0x4682b4]
（你、你刚才说了约尔大人吗南……？[rhr]
_　不不可能的，听错了吧）[rhp]
[:gonzalez:]
（我们监视南的同时还在那个世界扮演加耶的事，[rhr]
_　可是只有我和东家才知道的秘密……！必须慎重发言！）[rhp]

[:sausu:][sausu kao=13 as=on ]
（反应真明显啊……）[rhp]
[resetfont]

[off_all]

[se storage="door_09.ogg"]

[:tiaki:]
「锵锵——！请看这个～～♪」[rhp]

[off_all]

[chara_part name="mata" body=base kao=4 as=on ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="nusi" body=base kao=4 as=on ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="gon" body=base kao=4 as=on ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="720" top="0" wait="true" time=150]

[:3nin:]
「！！」[rhr]
「！！」[rhr]
「！！」[rhp]

[off_all]

[:sausu:][sausu kao=5 ]
「哎呀……主角登场了呢」[rhp]

[off_all]

[tiaki kao=1 ]

[:tiaki:][tiaki kao=14 ]
「觉得怎么样～，[player2]的新城堡！」[rhp]

[:himeko:]
「哇！好厉害……！变得超豪华了！」[rhp]
「这些全是米卡亲一个人做的吗？」[rhp]

[:tiaki:][tiaki kao=13 ]
「本来想拜托老师帮忙，但他实在太笨手笨脚就赶走他啦♡」[rhp]
[:tiaki:]
「喜欢吗？」[rhp]

[:himeko:]
「超级喜欢！」[rhp]

[off_all]

[chara_part name="mata" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="gon" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:gonzalez:][gon kao=1 ]
「已经来了啊。比预想的要早呢」[rhp]

[:mataroko:][mata kao=1 ]
「姐姐大人……您瘦了好多……」[rhp]

[off_all]

[:tiaki:][tiaki kao=3 ]
「………………」[rhp]

[:himeko:]
「怎么了米卡亲，一直盯着千纸鹤看」[rhp]

[:tiaki:]
「…………，没、没什么大不了的」[rhp]

[:himeko:]
「……待在这个房间，就会忍不住想起博士呢」[rhp]

[:tiaki:]
「……………………」[rhp]
[:tiaki:]
「……我说，媛子」[rhp]

[:himeko:]
「什么？」[rhp]

[:tiaki:]
「这些千纸鹤，还要继续放在这个房间吗？」[rhp]

[off_all]

[:sausu:][sausu kao=2 as=on ]
「！」[rhp]

[off_all]

[tiaki kao=3 ]

[:himeko:]
「咦……为什么？可是这个……」[rhp]

[:tiaki:]
「当然明白。[rhr]
_　这是浩君和大家齐心合力完成的大作呀」[rhp]
[:tiaki:]
「…………但我会难过。每次看到它」[rhp]
[:tiaki:]
「就会觉得向他许愿什么的，终究毫无意义」[rhp]

[:himeko:]
「米、米卡亲……？」[rhp]

[:tiaki:]
「[player2]你来决定就好。[rhr]
_　放在诊疗室或入口大厅都可以」[rhp]
[:tiaki:]
「…………你希望怎么处置这个？」[rhp]

[off_all]

[:himeko:]
「？呃，那个…………」[rhp]
「……我希望它能在这个房间，再留一会儿」[rhp]

[:tiaki:][tiaki kao=2 ]
「……真的吗？真的没关系吗？」[rhp]

[:himeko:]
「虽然博士想活下去的愿望或许没能实现……[rhr]
_　但只要它还在这里，就感觉博士仍在守护着我们，令人安心」[rhp]

[:tiaki:][tiaki kao=3 ]
「…………这样啊……」[rhp]

[:himeko:]
「不行吗……继续放在这里」[rhp]

[:tiaki:][tiaki kao=13 ]
「……没、当然没问题！抱歉问了奇怪的话」[rhp]
[:tiaki:][tiaki kao=1 ]
「――――好啦，搬迁工作总算完成！[rhr]
_　新床铺睡得舒服吗？」[rhp]

[:himeko:]
「很舒服。房间又漂亮又温馨！」[rhp]

[:tiaki:][tiaki kao=14 ]
「是吧～？而且离工作人员休息室比之前近多了，[rhr]
_　有什么困扰的事尽管说出来哦」[rhp]

[:himeko:]
「明白。谢谢」[rhp]

[:tiaki:][tiaki kao=13 ]
「那下次量体温时再见啦♡」[rhp]

[off_all]

[se storage="door_08.ogg"]

[chara_part name="nusi" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:nusi:][nusi kao=1 ]
「……米卡亲，正在气头上啊」[rhp]
[:nusi:]
「果然是因为杰特的事吧。看来她对你的误解还没消除」[rhp]

[:sausu:]
「………………是啊」[rhp]

[off_all]

[:sausu:]
「…………真头疼啊……」[rhp]

;****************************************
[set_b storage="hsps_09n.jpg"]
; 夜フィルター
[filter layer="1" brightness="60"]
;****************************************

那一夜――――[rhp]

[:himeko:]
「呼……」[rhp]

[:sausu:][sausu kao=3 ]
「………………」[rhp]

[:nusi:][nusi kao=5 ]
「想偷袭熟睡的人吗？开玩笑啦」[rhp]

[:sausu:][sausu kao=0 as=on ]
「！努西小姐……」[rhp]
[:sausu:][sausu kao=3 ]
「…………不是那样的。只是……」[rhp]

[:nusi:][nusi kao=0 ]
「还在介意米卡亲说过的话吗」[rhp]

[:sausu:]
「也有这个原因。不过……这孩子最近格外安静。[rhr]
_　一想到这就不由得感到难过，总会联想到过去的回忆……」[rhp]

[:nusi:][nusi kao=1 ]
「这也是没办法的事。我们能活到现在，[rhr]
_　都是多亏矢部医生牺牲个人时间拼命救治」[rhp]

[:sausu:]
「……但是努西小姐。我时常会思考」[rhp]
[:sausu:]
「在痛苦中延续生命与安详的长眠……[rhr]
_　……究竟哪种才是真正的幸福」[rhp]

[:nusi:][nusi kao=2 as=on ]
「南……」[rhp]

[:sausu:]
「活着当然更好。[rhr]
_　但这会不会只是我……我们的自我满足」[rhp]
[:sausu:]
「什么是幸福，只有当事人才能判断。[rhr]
_　我们将生存强加于人，实则使他们陷入不幸――――」[rhp]

[:nusi:][nusi kao=6 ]
「别说了」[rhp]

[:sausu:][sausu kao=0 ]
「！」[rhp]

[:nusi:]
「若纠结此事将永无止境。[rhr]
_　这个问题本来就没有答案」[rhp]
[:nusi:][nusi kao=2 ]
「……所以绝对别让这孩子重蹈杰特的覆辙」[rhp]

[:sausu:][sausu kao=6 ]
「……原来如此。你是为这个担心才来看我的吧」[rhp]

[:nusi:][nusi kao=12 ]
「见过米卡亲发飙的样子吧。[rhr]
_　平时笑眯眯的人发起火来才可怕」[rhp]

[:sausu:][sausu kao=12 ]
「放心。那种手段我不会再用第二次。[rhr]
_　从杰特事件只学到一个教训。那就是……」[rhp]
[:sausu:][sausu kao=1 ]
「银河铁道确实能带来幸福」[rhp]

[:nusi:][nusi kao=0 ]
「…………哼嗯？」[rhp]

[:sausu:][sausu kao=5 ]
「虽然约尔大人极力反对，但杰特的笑容让我确信」[rhp]
[:sausu:]
「我没有错。那个世界是必要的存在。[rhr]
_　纵使约尔大人批判，这点也是无可否认的事实」[rhp]

[off_all]

;****************************************
#
[bg storage="sky_12.jpg" time=1000]
;****************************************

[:sausu:]
「不久之后，[player2]便能见证我的愿景。[rhr]
_　届时定会第一个告诉你」[rhp]
[:sausu:]
「无须畏惧任何事物。[rhr]
_　绚烂未来与无垠宇宙正等待着你」[rhp]
[:sausu:]
「……银河铁道终会前来迎接你」[rhp]

;****************************************
[set_b storage="black.jpg"]
;****************************************

[font color=0x4682b4]
新增第五章　哈托谢普篇。[rhp]
[resetfont]

*go_title

;****************************************
[s_mask time=4000]
;****************************************

;エンドフラグ
[eval exp="sf.e_end = 1"]

[cancelskip]
[fbgm]

[jump storage="title.ks" target="*start_end"]

[s]