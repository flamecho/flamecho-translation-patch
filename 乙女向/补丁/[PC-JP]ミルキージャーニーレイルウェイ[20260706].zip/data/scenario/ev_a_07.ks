﻿
*start

;****************************************
[set_b storage="train_03.jpg"]
[bgm storage="bgm_01.ogg"]
;****************************************

[::]
今日是到达下一个旅行目的地的日子。[rhr]
决定目的地的人，是继我之后首次提出请求的落合君。[rhp]
他选择的前往之处，对他而言是个极为意外的地方。[rhp]

[:princess:][puri_w kao=4 as=on ]
「嘿～！　想去夏日祭啊，落合君」[rhp]

[:otiai:][p_ot_36][otiai kao=3 ]
「駄目？」[rhp]

[:princess:][puri_w kao=13 as=on ]
「唔唔，完全不是。只是觉得落合君也有像小孩子的地方呢～」[rhp]

[:otiai:][otiai kao=2 ]
「吵死了。不是你想的那样啦」[rhp]

[:princess:][puri_w kao=6 as=on ]
[font color=0x4682b4]
（被训斥了。小孩子真难应付……）[rhp]
[resetfont]

[off_otiai]

[:kite:][p_k_08][kite kao=1 ]
「夏日祭吗……还不坏呢。之前尽是被带去※那种※旅行之类的地方，[rhr]
_　这种平民化的场所从来没被选中过」[rhp]

[:princess:][puri_w kao=14 ]
「嗯嗯！感觉挺新鲜的不错嘛！」[rhp]

[off_all]

[chara_part name="drop" body=base kao=5 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:][p_vl_14]
「祭典上会有很多摊位对吧！？[rhr]
_　比如琥珀糖啦、棉花糖之类的！」[rhp]

[:drop:][p_d_31]
「没错。为了满足大家全部的愿望，[rhr]
_　我们将设计囊括所有摊位的夏日祭之星，敬请期待！」[rhp]

[off_all]

[chara_part name="riri" body=base kao=5 as=on ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="hakase" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="hakase" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:quadrillion:][p_r_03]
「夏日祭之星啊……还是一如既往随便的设定呢」[rhp]

[:darknebula:][p_da_06]
「有什么关系嘛。挺有意思的」[rhp]

[off_all]

[:otiai:][otiai kao=4 as=on ]
「……………………」[rhp]

[:kite:][p_k_31][kite kao=5 ]
「意外地受欢迎呢。不是挺好的嘛」[rhp]

[:otiai:][otiai kao=3 ]
「都是一帮老好人。[rhr]
_　我还以为会被嘲笑说幼稚呢」[rhp]

[:kite:][kite kao=11 ]
「那不是当然的吗。在这里的也基本都是小孩子」[rhp]

[:otiai:][p_ot_29][otiai kao=6 as=on ]
「…………这样可以吗。这么轻易就决定了」[rhp]

[:kite:][kite kao=0 ]
「你是因为想被反对才那么说的吗？」[rhp]

[:otiai:][otiai kao=6 as=on ]
「不是那样的……不过总感觉有点扫兴」[rhp]

[off_all]

[:quadrillion:][p_r_29][riri kao=5 ]
「真是笨死了。小孩子不用想那么多，坦率地享受就好。[rhr]
_　这可是你的要求，你自己必须玩得最开心才行哦？」[rhp]

[off_riri]

[:otiai:][otiai kao=7 ]
「……我知道啦」[rhp]

[off_otiai]

[:princess:][puri_w kao=13 ]
[font color=0x4682b4]
（呵呵……！为了让落合君能尽兴，[rhr]
_　我也要全力以赴地享受！）[rhp]
[:princess:][puri_w kao=1 ]
（对了。说到庙会果然得穿浴衣！[rhr]
_　去和克林商量下，给大家选适合的浴衣……）[rhp]
[resetfont]

[off_puri]

[:darknebula:][p_da_04][hakase kao=1 ]
「公主！」[rhp]

[off_hakase]

[:princess:][puri_w kao=0 ]
「！博士？」[rhp]

[off_puri]

[::]
循声望去，在与众人稍有些距离的地方，[rhr]
博士正朝我招手。[rhp]

[:darknebula:][hakase kao=1 ]
「过来过来」[rhp]

[off_all]

[::]
我顺从地朝他跑去。[rhp]
沃尔佩克拉正滔滔不绝地向多洛普列举想去的店铺列表，[rhr]
眼下顾不得那些，我与博士的密谈已然开始。[rhp]

[:princess:][puri_w kao=0 ]
「怎么了？博士」[rhp]

[:darknebula:][hakase kao=1 ]
「正是好时机啊公主。[rhr]
_　趁着这次祭典，推进些计划如何？」[rhp]

[:princess:][puri_w kao=0 ]
「推进……？」[rhp]

[off_all]

[::]
我仍不太明白话中含义，[rhr]
视线随博士的手指转向远处谈笑风生的众人。[rhp]

[:darknebula:][p_da_20]
「那里面，有你在意的人吧」[rhp]

[:princess:][puri_w kao=2 as=on hh=on ]
「――――――啊」[rhp]

[off_all]

[::]
正想纠正说「你在胡说什么！！」，[rhr]
博士慌忙用手捂住了我的嘴。[rhp]

[chara_part name="hakase" body=base kao=5 as=on ss=off hh=off hr=on ]
[chara_show name="hakase" layer="1" width="571" height="720" wait="false" left="355" top="0" time=150]
[chara_part name="puri_w" body=base kao=2 as=on ss=off hh=on hr=on hat=okan ]
[chara_show name="puri_w" wait="true" layer="message0" left="1" top="1" zindex="1005" time=150]

[:darknebula:][p_da_27]
「声、声音太大了。要是暴露了怎么办」[rhp]

[:princess:]
「暴、暴露什么呀！呜哇，我根本没有那种……」[rhp]

[:darknebula:][hakase kao=1 ]
「在意一个人，未必就非得是恋爱感情」[rhp]

[:princess:][puri_w kao=0 as=on ]
「……！」[rhp]

[:darknebula:][hakase kao=5 ]
「比如想更了解这个人，或者想比现在更亲近些，[rhr]
_　伙伴或朋友之间也会有这种情感吧」[rhp]
[:darknebula:]
「不妨试着深究这种对他人的关注。[rhr]
_　……我原想表达的是这个意思，你觉得呢？」[rhp]

[:princess:][puri_w kao=6 as=on ]
「原、原来如此……这确实……」[rhp]

[:darknebula:][hakase kao=5 ]
「你说过想找回过去的记忆吧。[rhr]
_　为获得线索，我觉得加深与他们的羁绊是上策」[rhp]
[:darknebula:]
「夏日祭人这么多不方便集体行动。[rhr]
_　肯定会分成几人小组，你也不必太害羞」[rhp]

[:princess:][puri_w kao=7 ]
「…………明白了。我会考虑看看」[rhp]

[:darknebula:][p_da_31][hakase kao=1 ]
「这就对了。愿你求知欲得到满足……」[rhp]

[off_all]

[:darknebula:]
[font color=0x4682b4]
（公主……对于渴望了解浴火重生的你的我而言，[rhr]
_　一直观察着的我当然明白）[rhp]
[:darknebula:]
（…………这孩子一定是在恋爱）[rhp]
[resetfont]

[:princess:][puri_w kao=0 ]
「博士，怎么了？一直盯着我看」[rhp]

[:darknebula:][hakase ]
「没什么啦。加油吧」[rhp]

[:princess:][puri_w ]
「……？嗯！」[rhp]

[off_all]

;****************************************
[fbgm]
[set_00 storage="train_08.jpg"]
[bgm storage="bgm_06.ogg"]
;****************************************

[::]
之后过了片刻我们暂时解散。[rhp]
我回到自己房间，坐在沙发上稍作休息，[rhr]
反复回味着方才博士的话语。[rhp]

[:princess:][puri_w kao=7 ]
「…………在意的人」[rhp]

[off_all]

[::]
听到这句话，最先浮现在脑海的是……[rhp]

;-----------------------------------------------------------------------------
;-----------------------------------------------------------------------------
;好感度分岐。後ほど設定しまーす
;-----------------------------------------------------------------------------
;-----------------------------------------------------------------------------

;ドロップ
[if exp="200 <= f.love_d && f.a03_d == 1 "]
[jump storage="ev_a_07_drop.ks"]

; カイト
[elsif exp="200 <= f.love_k && f.a03_k == 1 "]
[jump storage="ev_a_07_kite.ks"]

; クリリン
[elsif exp="200 <= f.love_r && f.a03_r == 1 "]
[jump storage="ev_a_07_riri.ks"]

; 双子
[elsif exp="200 <= f.love_h && f.a03_h == 1 "]
[jump storage="ev_a_07_hati.ks"]

; どれでもない
[else]
[jump storage="ev_a_07_nomal.ks"]

[endif] 

;-----------------------------------------------------------------------------