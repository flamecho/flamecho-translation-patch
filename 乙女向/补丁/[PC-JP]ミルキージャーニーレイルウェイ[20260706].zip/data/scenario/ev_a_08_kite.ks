﻿
*start

;--------------------------------------------------------------------------------------------
;▼フルボイスセット▼
;カイト
[voconfig sebuf=1 name=kite vostorage="kite/full/{number}.ogg" number=178]
;-------------------------------------------------------------------------------------------
;****************************************
[bgm storage="bgm_08.ogg"]
;****************************************
[::]
从那个夏日祭典归来后已过去三日。[rhr]
自那之后，我便陷入了新的困境。[rhp]
此前只为失忆之事苦恼不已，[rhr]
如今却不止于此……[rhp]

[:princess:][puri_w kao=8 as=on ]
「快、快斗～～。出来嘛～。[rhr]
_　整天关在房间里对身体不好哦～」[rhp]

[off_puri]

[:tobira:]
[font color=0x696969]
『呜咽………呜咽………』[rhp]
[resetfont]

[:princess:][puri_w kao=3 ]
「…………今天也不行吗」[rhp]

[off_puri]

[::]
今日依旧伫立于快斗房前的走廊，[rhr]
与门那边的爱哭鬼持续着胶着状态。[rhp]
无论我如何搭话，只能听见啜泣声全然无法交谈。[rhr]
快斗变成这样，都要从夏日祭那场对话说起……[rhp]

;****************************************
[set_kk storage="cg/a_07_k_1b.png" time=300]
;****************************************

[:princess:]
[font color=0x696969]
「―――我啊，是喜欢快斗的。想和你变得更亲密，[rhr]
_　如果曾是挚友的话也想找回那些记忆」[rhp]
[:princess:]
「但这也就是说[rhr]
_　现在的我只认识失忆后的快斗」[rhp]
[:princess:]
「虽然不清楚我和快斗过去有怎样的交集，[rhr]
_　那个……对我而言现在的快斗，只是刚认识一个月朋友而已」[rhp]
[:princess:]
「所、所以……抱歉……[rhr]
_　这个答案现在可能无法立刻……给出」[rhp]

;****************************************
[set_ff storage="train_04.jpg" time=300]
;****************************************

[:princess:]
[font color=0x4682b4]
（唔……果然还是当时告白回应方式的问题吧……）[rhp]
[resetfont]

[::]
从那天起，快斗就一直在哭个不停。[rhr]
不是比喻什么的，是真的连一小会儿都没停下哭泣。[rhp]
他整日闭门不出，连饭都不出来吃，[rhr]
不管和他说什么，他都只会重复同样的话。[rhp]
『已经受够了。要是不出生就好了』。始终就这一句。[rhr]
……听着这些话，连我都感到痛苦。[rhp]
虽然我用身体不舒服搪塞过去了，但也不知能瞒到几时。[rhp]

[:princess:]
[font color=0x4682b4]
（…………要是我当时接受他的告白就好了吗？）[rhp]
[resetfont]

[::]
但我觉得告白这种事，不能怀着这样暧昧的心情回答。[rhr]
那样随便又简单的答复，肯定无法让快斗和我都获得幸福。[rhp]

[:princess:][puri_w kao=3 ]
「唉——要是能找谁商量一下就好了」[rhp]
[:princess:]
「最好是嘴严实、有常识、[rhr]
_　对这种事比较了解的人……」[rhp]
[:princess:][puri_w kao=2 as=on ]
「…………」[rhp]

[off_puri]

[::]
…………倒是有这么个人。就一个。[rhp]


;****************************************
[set_xx graphic="rule/krke_k.png" storage="train_07.jpg"]
;****************************************

[:darknebula:][hakase msk=off kao=1 ]
「哟公主。欢迎光临」[rhp]

[:princess:][puri_w kao=1 ]
「你好博士。突然来打扰真不好意思」[rhp]

[off_all]

[::]
虽然多洛普应该也有常识，但他对这种事不太懂的样子，[rhr]
其他人就更不必说了，出于各种原因都信不过。[rhp]
所以我才来到兼具知识与常识的博士这里。[rhp]

[:vulpecula:][peku kao=1 ]
「公主酱～！怎么啦～！？是来玩的吗～！？」[rhp]

[:princess:][puri_w kao=1 ]
「唔唔，今天是来商量事情的」[rhp]

[:vulpecula:][peku kao=4 ]
「商量！？晚饭之类的吗？」[rhp]

[off_all]

[::]
小麦色的耳朵扑棱扑棱抖动着，眼睛闪闪发亮地仰望着我。[rhp]
但今天没空陪她玩耍。[rhr]
现在有个比她更需要关注的对象，得先处理那家伙的事。[rhp]
就这样，我坦白了快斗把自己关在房间里的真正原因……[rhp]

;****************************************
[set_time_b]
;****************************************

[chara_part name="hakase" body=base kao=0 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720"  left="208" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720"  left="645" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=3 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:darknebula:]
「……原来如此。公主也很不容易呢」[rhp]

[:princess:]
「倒也不算不容易，[rhr]
_　只是看到快斗变成那样就觉得难过……」[rhp]

[:vulpecula:]
「如果不讨厌快斗的话～干脆交往试试看～？」[rhp]

[:princess:][puri_w kao=2 ]
「哪有这么简单就决定的！[rhr]
_　所谓恋人，必须是彼此互相喜欢才行」[rhp]
[:princess:][puri_w kao=3 ]
「可是我……又不是因为讨厌他才拒绝的。[rhr]
_　明明只是因为搞不懂自己的心情……没想到他会消沉到这个地步」[rhp]

[:darknebula:]
「嗯……」[rhp]

[off_all]

[::]
听完我的叙述后，博士沉吟着陷入思考。[rhp]
果然找他商量是正确的。[rhr]
我期待着博士能给出精准的解答，静候他组织语言。[rhp]

[:darknebula:][hakase msk=off kao=0 ]
「很抱歉，这个我也不太明白啊」[rhp]

[off_all]

[::]
听到完全出乎意料的回答，我瞪大了眼睛。[rhr]
没想到会从那位博士口中听到『不明白』这种话。[rhp]

[:darknebula:][hakase msk=off kao=1 ]
「公主。人类是从错误中学习的生物哦」[rhp]

[:princess:][puri_w kao=0 ]
「……！」[rhp]

[:darknebula:]
「不需要从一开始就选择正确答案。[rhr]
_　太过着急的话，会遗漏重要的东西」[rhp]
[:darknebula:]
「在众多选项中，即便要经历无数次错误[rhr]
_　最终也一定会留下正确答案。我觉得等待那个时刻也是种方法」[rhp]
[:darknebula:]
「琐碎的事也好。不妨多聊聊各种话题。[rhr]
_　说不定会突然就撞上大奖呢」[rhp]

[:vulpecula:][peku kao=1 ]
「也就是说，撞破南墙不回头！？是这意思吗！？」[rhp]

[:darknebula:][hakase msk=off kao=14 as=on]
「唔——撞破可能不太好吧」[rhp]

[off_all]

[::]
和博士他们商量后，感觉心情似乎稍微轻松了些。[rhr]
虽然我当然希望快斗能尽快停止哭泣……[rhp]

[:princess:][puri_w kao=0 ]
「……一步一个脚印，脚踏实地……么……」[rhp]

[:darknebula:][hakase msk=off kao=1 ]
「因为快斗是个很有自己节奏的孩子。不如索性[rhr]
_　陪着他绕最远的弯路直到他停止哭泣好了」[rhp]
[:darknebula:]
「这里的时间是无限的，完全没必要着急。[rhr]
_　仅仅是陪伴在侧，或许就能改变未来的结果」[rhp]

[:princess:]
「陪伴在侧……也就是维持现状的意思？」[rhp]

[:darknebula:]
「也可以这么说」[rhp]

[off_all]

[::]
可是既然是博士说的，这个判断想必不会错。[rhp]
没有人能永远哭泣下去。[rhr]
无论需要花费多少时间，这都是确定无疑的。[rhp]
……再试着多靠近一些吧。[rhr]
直到快斗那颗不透明又脆弱的心，能够敞开为止。[rhp]


[chara_part name="hakase" body=base kao=1 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720"  left="208" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720"  left="645" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=1 as=off ss=off hh=off hr=on hat=okan]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「……谢谢你们俩。[rhr]
_　总觉得心情稍微轻松了些」[rhp]

[:darknebula:]
「那就好。虽然会有各种困难，但请加油」[rhp]

[:vulpecula:]
「小姬的话一定能行！你可以的！」[rhp]

[off_all]

[::]
在两人笑容的目送下，我离开了观景车厢。[rhp]

[:princess:]
[font color=0x4682b4]
（仅仅只是靠近吗……）[rhp]
[resetfont]

[::]
我一直认为做点什么总比什么都不做好。[rhr]
不过，看来也未必如此。[rhp]
…………。[rhp]

;****************************************
[fbgm]
[set_xx graphic="rule/krke_k.png" storage="train_04.jpg"]
;****************************************

[bgm storage="bgm_22.ogg"]

[::]
3天后。[rhp]


[:princess:][puri_w kao=14 ]
「快斗！！早上好——！！」[rhp]

[off_puri]

[:kite:]
[font color=0x696969]
『…………』[rhp]
[resetfont]

[:princess:][puri_w kao=1 ]
「今天多洛普说要给快斗做你喜欢的点心！[rhr]
_　说是蜜桃挞哦。一起吃吧！好不好？」[rhp]

[off_puri]

[:kite:]
[font color=0x696969]
『…………』[rhp]
[resetfont]

[::]
正如各位所见。[rhr]
『仅仅靠近』这个建议，坚持三天就无疾而终。[rhp]

[:princess:][puri_w kao=6 as=on ]
[font color=0x4682b4]
（根本没办法什么都不做……！不过没关系吧？[rhr]
_　毕竟只是我单方面搭话获得满足。[rhr]
_　我对快斗没有任何要求！）[rhp]
[:princess:]
（虽然最近连哭声都听不到了……[rhr]
_　但绝对不是在无视我吧！）[rhp]
[resetfont]

[off_puri]

[::]
如果假设、万一、退一万步说这也是被无视的情况。[rhr]
因为我有一个珍藏的『秘策』所以没关系。[rhp]

[:princess:]
[font color=0x4682b4]
（虽然并不想用这招……[rhr]
_　但为解燃眉之急。来吧！！！）[rhp]
[resetfont]


[:princess:][puri_w kao=2 as=on ]
「啊～～！！快斗房门前有桃切草履虫在！！」[rhp]

[off_all]

[::]
所谓桃切草履虫，乃是虫类。[rhp]

[:princess:]
[font color=0x4682b4]
（男生全都超爱虫！而且还是平日难得一见的品种。[rhr]
_　肯定会忍不住出来查看吧！来吧！快斗！）[rhp]
[resetfont]

[:princess:][puri_w kao=2 as=on ]
「好厉害，眨眼间就把桃子切开了！[rhr]
_　这样下去会变成虫蛀桃馅饼的！要一起消灭它吗？」[rhp]

[off_puri]

[:kite:]
[font color=0x696969]
『……………………』[rhp]
[resetfont]

[::]
本以为会像往常一样毫无反应……[rhp]

[:princess:][puri_w kao=0 as=on ]
「……！？这是什么？」[rhp]

[off_puri]

[::]
门缝底下倏地递出一张纸条。[rhp]

[:princess:][puri_w kao=14 hh=on ]
「快斗……！呃，呃～嗯。写的啥？」[rhp]

[::]
[font color=0x696969]
『桃切虫并非盲目切割桃子』[rhp]
[resetfont]

[:princess:][puri_w kao=2 as=on ]
「居、居然这么专业……」[rhp]

[off_puri]

[::]
但是终于得到快斗的回应了……！[rhr]
莫非就差临门一脚了？[rhp]

[:princess:][puri_w kao=1 ]
「呐！方便的话要不要听听桃切草履虫的[rhr]
_　能不能再多告诉我一点？　面对面！」[rhp]
[:princess:]
「其实真品就在这里哦。要不要两人边欣赏边喝茶！？」[rhp]

[off_puri]

[:kite:]
[font color=0x696969]
『……………………』[rhp]
[resetfont]

[::]
唰地，这次递出两张便签。[rhp]

[font color=0x696969]
[font color=0x696969]
『明明根本不在』[rhp]
『骗子』[rhp]
[resetfont]

[:princess:][puri_w kao=2 as=on ]
[font color=0x4682b4]
（被看穿了……）[rhp]
[resetfont]

[:kite:]
[font color=0x696969]
『呜……呜……』[rhp]
[resetfont]

[:princess:][puri_w kao=8 as=on ]
「啊，啊～～～！　别哭啊快斗！[rhr]
_　呃～那个，呃～那个……」[rhp]
[font color=0x4682b4]
（没辙了！既然如此只能祭出最终兵器……！）[rhp]
[resetfont]


[off_puri]

[yurasu]

[:princess:]
[font size=27]
「哎呀！？　那边居然有高腰蛙！？」[rhp]
[resetfont]

;****************************************
[set_xx graphic="rule/krke_k.png" storage="train_09.jpg"]
;****************************************

[:princess:]
[font color=0x696969]
『――――――那边居然有高腰蛙！？』[rhp]
[resetfont]

[:kite:][kite kao=2 as=on ]
「…………」[rhp]

[off_kite]

[::]
高腰蛙是什么鬼……？[rhr]
话说回来，就算想用东西引诱，选择也太奇怪了吧？[rhp]

[:kite:][kite kao=3 ]
「………………」[rhp]
[:kite:]
[font color=0x4682b4]
（想吃多洛普的蛋挞。[rhr]
_　桃切象鼻虫和高腰蛙其实都想看……）[rhp]
[resetfont]
[:kite:]
（………………但不想见到公主）[rhp]

[off_kite]

[::]
――――――我把自己关在房间里，究竟过去多久了呢。[rhp]
我知道是我不对。[rhr]
实在太孩子气，又任性，丢脸至极。[rhp]
她为了我，每天都来探望。[rhr]
对我如此牵挂，我却这样对待她。[rhp]
…………我真是个差劲的家伙。[rhp]
因为自己不想做，就粗暴地践踏别人的好意。[rhr]
会被拒绝也是理所当然的。[rhp]
就算我是女人，也绝对不想和我这种人交往。[rhp]

[:kite:]
[font color=0x4682b4]
（…………简直像个傻瓜一样……）[rhp]
[resetfont]

[::]
反正她也不过是，触碰了我这个脓包而已。[rhr]
不过是因为我是个无可救药的家伙，才勉强应付着不惹我生气罢了。[rhp]
会错意的我才是混蛋。[rhp]
真的，像我这种人……[rhp]

[:kite:][kite kao=3 ]
「………、………不如死了算了……」[rhp]

[off_kite]

[:princess:]
[font size=30 color=0x696969]
『哈啊"！？』』[rhp]
[resetfont]

[:kite:][kite kao=2 as=on ]
「…………！」[rhp]

[off_kite]

[::]
糟、糟糕。好像被她听到了……[rhr]
但不是对她说的啊。[rhp]
话说连这么小的声音都能捕捉到，简直像是给墙装上耳朵……[rhp]

[:princess:]
[font color=0x696969]
『……………………』[rhp]
[resetfont]

[:kite:][kite kao=6 as=on ]
「…………？」[rhp]

[off_kite]

[::]
没有反应。怎么回事……？[rhp]

[fbgm]

[:princess:]
[font color=0x696969]
『说的对呢……』[rhp]
[resetfont]

[:kite:][kite kao=0 as=on ]
「…………？」[rhp]

[off_kite]

[:princess:]
[font color=0x696969]
『被这么吵闹的话，确实会想让人去死吧』[rhp]
[:princess:]
『…………我明白了』[rhp]
[resetfont]

[:kite:][kite kao=2 as=on ]
「诶……」[rhp]

[off_kite]

[:princess:]
[font color=0x696969]
『不会再这样了，这些事。[rhr]
_　请把我也好，桃噬象纤毛虫的事也好都忘掉吧……』[rhp]
[:princess:]
『…………对不起。永别了……』[rhp]
[resetfont]

[:kite:][kite kao=2 as=on ]
「……！」[rhp]

[off_kite]

;****************************************
[se storage="door_07.ogg"]
;****************************************
;スチル
[still storage="cg/a_08_k_1.png" rule="007.png" width="1280" height="720" time=500]
[cg storage="cg/a_08_k_1.png"]
;****************************************

[yurasu]

[:kite:]
[font size=26]
「不是这样的！！」[rhp]
[resetfont]
[:kite:]
「那话不是对你说的！该死的人是我啊！」[rhp]
[:kite:]
「我这种人……、……呃……」[rhp]

;****************************************
;スチル
#
[bg storage="cg/a_08_k_1b.png" width="1280" height="720" time=500]
[cg storage="cg/a_08_k_1b.png"]
[bgm storage="bgm_01.ogg"]
;****************************************

[:princess:]
「大成功～～～～～」[rhp]

[:kite:]
「……………………诶」[rhp]

[:princess:]
「命名为『虫子不行就拉出来作战』」[rhp]
[:princess:]
「你终于肯出来了呢。快斗！」[rhp]

[:kite:]
「怎、怎么……你该不会在生气……」[rhp]

[:princess:]
「啊哈哈。我可没想到快斗会对我说去死这种话呢」[rhp]

[:kite:]
「……！！你、你手里拿的那个该不会是」[rhp]

[:princess:]
「啊，这个呀……呵呵呵！高腰蛙！！[rhr]
_　是多洛普用魔法变出来的，我一直好好待在现场哦」[rhp]
[:princess:]
「本来还想带桃蛀螟象鼻虫来的，[rhr]
_　但要是被讨厌虫子的克林发现可能会被杀掉，所以放弃啦」[rhp]

[:kite:]
「……………………」[rhp]

[:princess:]
「幸好我是个能接受虫子的女生。[rhr]
_　不然快斗你现在恐怕还……」[rhp]

;****************************************
; スチル終了
[still_end frame="win.png" storage="train_04.jpg" method="fadeInRightBig" time=500]
;****************************************

[:kite:][kite kao=14 ]
「…………噗！啊哈哈哈哈哈哈！！」[rhp]

[:princess:][puri_w kao=0 ]
「！！什、什么情况？」[rhp]

[:kite:][kite kao=5 ]
「哈哈哈……！我说啊……那个，搞错啦」[rhp]

[:princess:][puri_w kao=2 ]
「哈？」[rhp]

[:kite:]
「那个不是桃切草履虫，是桃切象鼻虫啦」[rhp]
[:kite:]

[:princess:][puri_w kao=6 as=on ]
[font color=0x4682b4]
（在说什么啊……？）[rhp]
[resetfont]

[:kite:]
「微生物怎么可能把桃子咬断啊。[rhr]
_　我还以为真有这种东西存在，果然是听错了，」[rhp]

[:princess:][puri_w kao=14 as=on]
「……！！　那你能不能详细说说它们的区别！？」[rhp]

[:kite:][kite kao=2 as=on ]
「嗯？」[rhp]

[:princess:][puri_w kao=5 as=on]
「不要隔着门！慢慢说！看着我的眼睛！！」[rhr]
[font color=0x4682b4]
（就差最后一步了！[rhr]
_　要是现在退缩的话，感觉再也不会有机会了……！）[rhp]
[resetfont]

[off_all]

[:princess:]
「那我就进来打扰啦——！」[rhp]

[:kite:]
「等、等一下……！」[rhp]

[off_all]

[::]
我抓住这个气势一举让快斗闭嘴，终于瓦解了他的闭门不出。[rhp]
这就是博士说过的，在无数次试错后，最后剩下的正确答案吧。[rhr]
虽然和预想的有点不一样，不过算了。[rhp]

[:princess:]
[font color=0x4682b4]
（真正的问题从现在开始……）[rhp]
[resetfont]

[::]
我隐约感觉，让他停止哭泣并不是终点。[rhp]
快斗如此消沉与其说是告白结果导致的[rhr]
倒不如说，我看到了某种更深切的悔恨。[rhp]
然后那大概，也与我的过去有所关联。[rhp]

;****************************************
[bg storage="black.jpg" time=1000]
;****************************************

『已经受够了。好想死』。[rhr]
……快斗在那天，这样说了。[rhp]

我想知道对那句话既视感的原因。[rhp]
……为了快斗，也为了我自己。[rhp]

;****************************************
[fbgm]
[set_xx graphic="rule/krke_k.png" storage="train_09.jpg"]
[bgm storage="bgm_07.ogg"]
;****************************************

[:princess:][puri_w kao=6 as=on ]
「……………………」[rhp]

[off_puri]

[:kite:][kite kao=3 ]
「……………………」[rhp]


[off_kite]

[::]
房间里，我们并排坐在沙发上。[rhp]

[:princess:][puri_w kao=6 as=on ]
[font color=0x4682b4]
（怎么办。该从何说起呢……）[rhp]
[resetfont]

[:kite:][kite kao=3 ]
「……………………」[rhp]

[:princess:][puri_w kao=6 as=on ]
[font color=0x4682b4]
（呜呜……正因为提出要谈的是我，反而更加难堪……）[rhp]
[resetfont]

[off_all]

[::]
虽然有很多想问的事，但不知道该如何开口。[rhr]
说什么都像会踩到地雷，要是又哭出来的话也很讨厌……[rhp]

[:princess:][puri_w kao=2 as=on ]
「……………………」[rhp]

[off_puri]

[::]
……用眼角余光偷偷观察快斗的表情。[rhp]
他盘腿坐著，手肘撑在膝盖上托腮，[rhr]
发呆望著远处，一脸昏昏欲睡的样子。[rhp]
眼角微微泛红，还有些许浮肿。[rhp]

[:princess:][puri_w kao=6 as=on ]
「……已经没事了吗？」[rhp]

[:kite:][kite kao=3 ]
「…………什么没事了」[rhp]

[:princess:]
「因为你哭了好多，我在想是不是稍微畅快些了。[rhr]
_　差不多可以跟我谈谈了吧，这样想」[rhp]

[:kite:]
「…………怎么可能没事啊。我这可是刚被甩耶」[rhp]

[:princess:][puri_w kao=3 as=on ]
「对、对不起……」[rhp]

[:kite:]
「……不用道歉啦。反正错的全都我」[rhp]

[:princess:][puri_w kao=2 as=on ]
「本来就没有谁是坏人啊。[rhr]
_　不准再这样说了」[rhp]

[:kite:][kite kao=3 ]
「………………」[rhp]
[:kite:]
「………………那个啊」[rhp]

[:princess:][puri_w kao=3 as=on ]
「嗯？[rhp]

[:kite:]
「为什么现在又来找我。你不是没有记忆吗。[rhr]
_　明明才刚认识，又谈不上喜欢，就算对方哭了也无需在意吧」[rhp]

[:princess:]
「怎么能……我们可是朋友」[rhp]

[:kite:]
「这种暧昧的态度最让人火大」[rhp]
[:kite:]
「……别给了希望又推开人。[rhr]
_　被温柔对待的话，任谁都会得寸进尺的」[rhp]

[:princess:]
「快斗……」[rhp]

[:kite:]
「明明不喜欢我。那就别跟我搭话啊」[rhp]
[:kite:]
「为什么要跟来啊。看海也好，露营也好。[rhr]
_　如果没那个意思，就别邀请人去夏日祭啊」[rhp]
[:kite:]
「…………这种言行，真的超级烦人」[rhp]

[off_all]

[::]
第一次从快斗的话语里，感受到明显的尖刺。[rhr]
这与针对夸德里利昂的挖苦完全不同，是真心实意的抱怨。[rhp]
…………心里好痛。因为这是第一次被他用这种感情对待。[rhp]
但是……不知为何，我稍稍松了一口气。[rhp]

[:princess:][puri_w kao=1]
「第一次呢。像这样交谈」[rhp]

[:kite:][kite kao=2 ]
「啊……？」[rhp]

[:princess:]
「快斗从来不说自己的事嘛。所以我有点开心」[rhp]

[:kite:][kite kao=3 ]
「………………」[rhp]

[:princess:][puri_w kao=3 ]
「根本不够呢。能好好交谈的时间」[rhp]
[:princess:]
「是我太依赖快斗了。因为快斗话少的关系，[rhr]
_　或许我也没能好好传达自己的心意吧」[rhp]
[:princess:]
「所以……我们之间，才会产生那么多误会。[rhr]
_　以为就算不说话你也能懂」[rhp]
[:princess:]
「……为什么呢。面对快斗时，总觉得这是理所当然的事」[rhp]

[:kite:]
「………………」[rhp]

[:princess:]
「……我一直以为，快斗其实不太喜欢我」[rhp]
[:princess:]
「我们的对话也谈不上热烈。[rhr]
_　总是板着脸，完全猜不透在想什么」[rhp]
[:princess:]
「所以当听说我们曾是挚友时[rhr]
_　被告白时，都真的吓了一大跳」[rhp]
[:princess:]
「我找不到快斗喜欢上我的理由。[rhr]
_　但那正是我思维停滞的证明……只是我从未试图去了解」[rhp]
[:princess:]
「快斗心中，确实有着喜欢我的理由对吧」[rhp]
[:princess:]
「…………明明只是我自己忘记了。[rhr]
_　却用自己的一厢情愿，武断定义了和快斗的关系」[rhp]

[:kite:][kite kao=3 ]
「………………」[rhp]

[:princess:][puri_w kao=13 ]
「――――――啊！虽然有点自以为是。[rhr]
_　但这次我真的想更深入了解快斗」[rhp]
[:princess:][puri_w kao=1 ]
「无论是作为挚友共同生活的过往，还是这段旅程的点滴，全部都要。」[rhr]
_　为了能真正回应快斗的心意」[rhp]

[:kite:]
「………………不能说」[rhp]
[:kite:]
「公主的过去不可透露。这无关我的个人感情。[rhr]
_　是南定下的规矩，不是不愿说而是不能说」[rhp]

[:princess:][puri_w kao=0 ]
「南下了封口令……？[rhr]
_　我的过去被我知道了会很不妙吗？明明是属于我的东西？」[rhp]

[:kite:]
「………………」[rhp]

[:princess:][puri_w kao=12 ]
「…………明白了。我会放弃关于我的事」[rhp]
[:princess:][puri_w kao=2 ]
「但如果是那样，我只想听快斗的事」[rhp]

[:kite:]
「我？」[rhp]

[:princess:][puri_w kao=1 ]
「对呀。......快斗的事，无论是好事还是坏事，我全都想知道」[rhp]
[:princess:]
「还有为什么快斗会说出想死这种话」[rhp]

[:kite:][kite kao=0 as=on ]
「……！」[rhp]

[:princess:][puri_w kao=1 ]
「已经不想再让你说第二次那样的话了。[rhr]
_　只讲能说的事就好。一点点慢慢告诉我就行」[rhp]
[:princess:]
「我对快斗的感情是不是恋爱，现在还没有答案...[rhr]
_　即便如此，从今往后也永远希望快斗陪在我身边」[rhp]
[:princess:]
「别说要死的话。没有快斗的世界太无聊了」[rhp]

[:kite:][kite kao=3 ]
「…………」[rhp]

[:kite:]
「…………你真残忍啊」[rhp]

[:princess:][puri_w kao=0 as=on ]
「诶……」[rhp]

[off_all]

;****************************************
;スチル
[still storage="cg/a_08_k_2.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/a_08_k_2.png"]
;****************************************

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
[vostart]
;--------------------------------------------------------------------------------------------

[:kite:]
「……我们一直在一起。根本不是铁道共度时光能比的」[rhp]
[:kite:]
「从相遇那刻起就一直如此。[rhr]
_　自活着的时候起，我和你就从未分离」[rhp]
[:kite:]
「一直喜欢着你。......但那时候没能说出口」[rhp]
[:kite:]
「没能传达的心意，无法坦率的自己，[rhr]
_　我却匆匆离开了人世」[rhp]

[:princess:]
「……！」[rhp]

[:kite:]
「……在你眼里，我很冷漠吧？」[rhp]

[:princess:]
「嗯、嗯……我以为你对我没兴趣」[rhp]

[:kite:]
「有的啊，超级有」[rhp]
[:kite:]
「……终于能在这个地方相遇，我高兴得快死掉了。[rhr]
_　可是我觉得展现那种地方很逊，就装作不知道」[rhp]
[:kite:]
「就算听说失忆了，我也觉得如果是你的话一定能注意到」[rhp]

[:princess:]
「笨蛋！这种事怎么可能注意到啊！」[rhp]

[:kite:]
「我知道。中途我也觉得这样不妙……[rhr]
_　所以那天，我试着告白了」[rhp]
[:kite:]
「坦白说，我以为绝对没问题的。[rhr]
_　毕竟是你先主动邀约的，完全是稳赢的局面」[rhp]
[:kite:]
「……然后，如你所知彻底失败」[rhp]
[:kite:]
「后悔了啊。这个结果，就是平日自己累积的报应。[rhr]
_　我安于现状不断妥协的结果，就是变成这样」[rhp]
[:kite:]
「虽然知道是自己不好……但也会想哭啊，这样的人生」[rhp]

[:princess:]
「……快斗……」[rhp]

;****************************************
#
[bg storage="cg/a_08_k_2b.png" width="1280" height="720" time=500]
[cg storage="cg/a_08_k_2b.png"]
;****************************************

[:kite:]
「就算在这里能成为理想中的自己。骨子里的本性还是改不掉啊」[rhp]
[:kite:]
「这里的我只是靠魔法接近理想，虚假的自己。[rhr]
_　真实的我就只是个混账小鬼，又窝囊，又逊，又没出息」[rhp]
[:kite:]
「这样的我，怎么可能会被人喜欢啊……」[rhp]

[::]
哽咽之间，快斗的眼眶又开始扑簌簌地落下泪来。[rhp]
……是吗。快斗并不是因为被我拒绝而受伤……[rhr]
陷入过度的自我厌恶之中，才导致了这样的结果。[rhp]

[:kite:]
「早知如此，就该趁着活着的时候多聊些话的。[rhr]
_　我本应停止欺负和逞强，直接对你说喜欢就好了」[rhp]
[:kite:]
「一想到这点……泪水就止不住地涌出」[rhp]
[:kite:]
「……明明知道这种恶心的家伙会更加招人讨厌……」[rhp]

[:princess:]
「………………」[rhp]
[:princess:]
[font color=0x4682b4]
（在我看来，你没那么糟糕啦）[rhp]
[resetfont]

[::]
而且能像这样重新审视自我，是件相当难得的事。[rhp]
……虽然想这么对你说，但以现在的我，[rhr]
失忆的我终究还是太肤浅了。[rhp]

[:princess:]
「………………」[rhp]

[::]
…………即便如此，这句话也非说不可。[rhp]
我下定决心，开口说道。[rhp]

[:princess:]
「快斗喜欢的恐怕，[rhr]
不是现在的『公主』而是『过去的我』吧」[rhp]
[:princess:]
「…………这样的话暂时还无法回应快斗的感情。[rhr]
_　因为现在的我并不是你所喜欢的那个女孩」[rhp]
[:princess:]
「……啊ー啊……要是能问出我以前的名字就好了。[rhr]
_　但好像是因为南的影响才做不到的吧」[rhp]

[:kite:]
「你就是你。称呼方式无关紧要」[rhp]

[:princess:]
「关系可大了。被反复提及的话，说不定会突然回想起记忆呢」[rhp]
[:princess:]
「…………所以。快斗。[rhr]
_　等记忆恢复后，到时候再重新回答你」[rhp]
[:princess:]
「先前的表白暂且作废。[rhr]
_　所以别再哭哭啼啼垂头丧气啦」[rhp]
[:princess:]
「现在的我，还有从前的我，都最喜欢你的笑脸了」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:kite:]
「……………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[::]
……说完自己都吓一跳。[rhr]
明明是自己的事，却像在张罗别人的恋情似的。[rhp]

[:princess:]
[font color=0x4682b4]
（…………、咦）[rhp]
[resetfont]

[::]
为什么现在心里隐隐作痛呢……[rhp]

;****************************************
;スチル終了
[still_end frame="win.png" storage="train_09.jpg" time=1000]
;****************************************

[:kite:][kite kao=3 ]
「……抱歉。让你看到这么多难为情的模样……[rhr]
_　成年人还哭鼻子什么的太不像话了」[rhp]
[:kite:]
「忘了吧。……我不会再这样了」[rhp]

[:princess:][puri_w kao=13 ]
「――――――！　诶嘿嘿……当然！[rhr]
_　就是为了这个才和你商量的呀！」[rhp]

[:kite:][kite kao=1 ]
「…………、你还是一点没变。和当年一模一样」[rhp]

[:princess:][puri_w kao=4 ]
「是这样吗？」[rhp]

[:kite:][kite kao=13 ]
「变回我喜欢的那个你了」[rhp]

[:princess:][puri_w kao=1 hh=on ]
「快斗……」[rhp]

[off_all]

;****************************************
;スチル
[still storage="cg/a_08_k_3.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/a_08_k_3.png"]
;****************************************

[:kite:]
「…………最喜欢你了」[rhp]

[:princess:]
「！诶……！？」[rhp]

[:kite:]
「中间发生了很多事，虽然不能直接告诉你……[rhr]
_　但我会帮忙让你快点独自回想起来」[rhp]
[:kite:]
「……希望在这期间，你能重新喜欢上我」[rhp]

[:princess:]
「……！」[rhp]

[::]
掠耳而过的低语让吐息不由自主地颤抖。[rhp]

[:kite:]
「……一定要想起来啊。优先想起关于我的事就好」[rhp]
[:kite:]
「可不想被那群偷腥猫抢先……」[rhp]

[::]
这家伙、刚才还像小孩一样哭哭啼啼的，转眼间[rhr]
就恬不知耻地滔滔不绝说着羞耻的话……！[rhp]

[:princess:]
「那个……我、我会加油的」[rhp]

[:kite:]
「嗯。好好努力吧」[rhp]

[:princess:]
「搞什么啊……节奏全乱套了」[rhp]

[:kite:]
「…………呵呵呵」[rhp]

[:princess:]
「？怎么了？」[rhp]

[:kite:]
「以前我的身高还够不到这里呢，真开心」[rhp]

[:princess:]
「我觉得有点痒……」[rhp]

[::]
而且还超级羞耻。[rhr]
试图不着痕迹地从快斗的手臂中挣脱出来，拼命扭动身体。[rhp]
但正处于觉醒状态般的快斗没有放过这个动作。[rhp]

;****************************************
;スチル終了
[still_end frame="win.png" storage="train_09.jpg" time=1000]
;****************************************

[:kite:][kite kao=0 ]
「…………这就要走了吗？」[rhp]

[:princess:][puri_w kao=0 as=on hh=on ]
「哎。……为什么这么问？」[rhp]

[:kite:][kite kao=6 ]
「你刚才想逃走吧……我还以为你要回自己房间」[rhp]

[:princess:][puri_w kao=2 as=on hh=on ]
[font color=0x4682b4]
（诶……该怎么回答才好。如果说要回去感觉太冷漠了，[rhr]
_　但说不回去的话，又莫名觉得难为情……）[rhp]
[resetfont]

[:kite:][kite kao=1 ]
「啊……对了。说起来还有件事没告诉你」[rhp]

[:princess:][[puri_w kao=0 as=on hh=on ]
「？什么事？」[rhp]

[:kite:]
「关于桃子象鼻虫的事」[rhp]

[:princess:][puri_w kao=5 as=on hh=on ]
「啊呀……就是在房间里详细说明那个吧。[rhr]
_　说起来确实有过这样的约定呢……哈哈……」[rhp]

[:kite:][kite kao=13 ]
「而且，我对高腰蛙也很在意」[rhp]
[:kite:]
「……和我聊的话题，还多着呢对吧？」[rhp]

[:princess:][puri_w kao=6 as=on hh=on ]
「～～～～……」[rhp]

[:kite:][kite kao=5 ]
「那就再保持这样一会儿吧」[rhp]


;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:princess:][puri_w kao=2 as=on hh=on ]
「不……不行不行不行！停下停下」[rhp]

[off_all]

[::]
就在险些被气氛带着走的关头，我硬是把快斗拽开了。[rhr]
对面的快斗不满地撅起嘴。[rhp]

[chara_part name="kite" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=2 as=on  ss=off hh=on hr=on hat=okan]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:kite:]
「为什么？」[rhp]

[:princess:][puri_w kao=2 as=on hh=on ]
「这、这种事情还太早了啦！」[rhp]

[:kite:][kite kao=0 ]
「……………………」[rhp]

[:princess:]
「……！？」[rhp]

[:kite:][kite kao=5 ]
「……哈哈」[rhp]

[:princess:][puri_w kao=6 as=on hh=on ]
「怎、怎么了？」[rhp]

[:kite:]
「原来如此，确实……还太早了吗？」[rhp]

[:princess:][puri_w kao=2 as=on hh=on ]
「诶！？不是，那是修辞手法……！」[rhp]

[off_all]

[::]
……总感觉，和刚才性格不一样了吧？[rhr]
那个爱哭鼻子的快斗去哪儿了……！[rhp]

[:kite:][kite kao=5 ]
「我可是认真的，不会放弃哦」[rhp]
[:kite:]
「[player3b]因为无论是从前还是现在，我都最喜欢你了」[rhp]
[:kite:][kite kao=11 ]
「…………想起来吧。我会一直等着」[rhp]

[off_all]

[::]
快斗的每字每句，都让心里缓缓涌起暖意。[rhr]
开心得发痒，莫名想哭。[rhp]
这是为什么呢。[rhr]
仿佛一直想和他这样相处，又仿佛只是错觉。[rhp]
……等到笼罩脑海的薄雾终将散去之时，[rhr]
是否就能明确说出这份心情的名字了呢。[rhp]

[:princess:]
[font color=0x4682b4]
（………即便，现在还不是时候……）[rhp]
[resetfont]

[::]
感觉距离说出那句话，似乎已不需要太久。[rhp]

;****************************************
[fbgm]
[set_b storage="train_01.jpg"]
[bgm storage="bgm_17.ogg"]
;****************************************

那是当天夜里的事。[rhp]

[:drop:][drop kao=14 ]
「哎呀－，不过话说回来！真的是让人松了一口气呢！」[rhp]

[off_drop]

[chara_part name="drop" body=base kao=13 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:drop:]
「快斗先生，终于肯从房间里出来真是太好了！[rhr]
_　有一阵子还在担心会变成什么样呢」[rhp]

[:kite:]
「哪里哪里。给你们添麻烦了」[rhp]

[off_all]

[::]
快斗表面敷衍地道着歉，轻轻低头致意。[rhp]
不仅是我，大家也都在担心他的举动，[rhr]
看到他平安无事走出房间，似乎都松了口气。[rhp]

[chara_part name="jet" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:jet:]
「快斗开始闭门不出时还挺感慨的啊」[rhp]

[:heartshape:]
「偷懒能坚持到那种地步反倒让人感受到了钢铁般的意志！！震撼到我了」[rhp]

[off_all]

[chara_part name="riri" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:quadrillion:]
「虽然看到布兹从早到晚黏在门外的样子让人倒胃口，[rhr]
_　不过意外地好像挺有效果呢」[rhp]

[:kite:][kite kao=1 ]
「是啊。真是多亏了公主」[rhp]

[:quadrillion:][riri kao=6 ]
「干嘛啦……突然这么坦率」[rhp]

[:kite:][kite kao=13 ]
「哼哼。克林是不会懂的啦」[rhp]
[:kite:][kite kao=13 ]
「对吧？公主。我们之间可是结下了深厚的羁绊啊」[rhp]

[off_all]

[:princess:][puri_w kao=5 as=on ]
「哈、哈哈……是啊～……」[rhp]

[off_puri]

[::]
快斗这家伙稍微有点进展就开始得意忘形了。[rhr]
可别因为多嘴又成了大家捉弄的对象啊……[rhp]

[:darknebula:][hakase msk=off kao=1 ]
「公主」[rhp]

[:princess:][puri_w kao=1 ]
「啊，博士……！」[rhp]

[off_all]

[::]
一直微笑着守候众人谈话的博士这时走到了身边。[rhr]
由于博士像说悄悄话般将一只手掩在嘴边，我也将脸凑近过去。他在我耳畔轻声低语。[rhp]

[:darknebula:][hakase msk=off kao=1 ]
「虽是迂回却也算捷径呢。我放心了」[rhp]

[:princess:][puri_w kao=13 ]
「嘿嘿……！嗯！多亏了博士」[rhp]

[:darknebula:]
「此言差矣。这终究是你取得的成果。[rhr]
_　我只是给可爱的义妹提了些建议罢了。你要有自信」[rhp]

[:princess:]
「呵呵……！说什么义妹，怪难为情―――」[rhp]

[:kite:][kite kao=6 ][hakase msk=off kao=0 as=on ]
「两人鬼鬼祟祟聊什么呢？真腻歪」[rhp]

[:princess:][puri_w kao=6 ]
「才不腻歪呢。我可是找博士商量了很多事情。[rhr]
_　比如说该怎么处理爱哭鬼快斗的家里蹲问题啦！」[rhp]

[:kite:][kite kao=2 ]
「哼……」[rhp]

[:princess:][puri_w kao=2 as=on ]
[font color=0x4682b4]
（眼神好可怕……是不是在生气？）[rhp]
[resetfont]

[:kite:][kite kao=12 ]
「…………谢谢你担心我 博士」[rhp]

[:darknebula:][hakase msk=off kao=1 ]
「哪里哪里」[rhp]

[:kite:][kite kao=6 ]
「不过光天化日之下，[rhr]
_　和女孩子当众黏黏糊糊的像什么话」[rhp]

[:princess:][puri_w kao=2 as=on hh=on ]
「什！黏、黏糊！？才没有！」[rhp]

[:kite:]
「更何况对象是博士。这对佩奇的教育不太好吧」[rhp]

[off_all]

[chara_part name="riri" body=base kao=5 as=on ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720"  left="600" top="0" wait="true" time=150]

[:vulpecula:]
「不必担忧。佩奇可是早熟的孩子」[rhp]

[:quadrillion:]
「倒会自夸」[rhp]

[off_all]

[chara_part name="kite" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=2 as=on ss=off hh=on hr=on hat=okan]
[chara_show name="puri_w" layer="message0" left="1" top="1" width="=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「快斗！不许用奇怪的说法。[rhr]
_ 博士他……对了！就像是我的兄长系那个啦！」[rhp]

[:kite:]
「啊是哦。那这样不就已经可以了嘛ー。[rhr]
_　虽然不知道社会上一般怎么样」[rhp]

[:princess:]
「啊、啊这么说的话就那样～～～……！！」[rhp]

[off_all]

[:otiai:][otiai kao=0 ]
「…………」[rhp]

[off_otiai]

[:drop:][drop kao=0 ]
「落合？从刚才开始沉默到底怎……」[rhp]

[off_drop]

[:otiai:][otiai kao=11 ]
「…………没什么」[rhp]

[off_otiai]

[:drop:]
「啊、等等！落合！？去哪―――」[rhp]

[:princess:]
[font color=0x4682b4]
（奇怪……）[rhp]
[resetfont]

[::]
在关注博士和快斗的对话时，[rhr]
回过神来落合君正要离开普通车厢。[rhp]

[:princess:]
[font color=0x4682b4]
（是要回房间吗？是不是有点闹过头了。[rhr]
_　落合君、好像很怕吵的样子……）[rhp]
[resetfont]

[:kite:][kite kao=0 ]
「喂」[rhp]

[:princess:][puri_w kao=6 as=on ]
「！这次又怎么了？」[rhp]

[:kite:][kite kao=13 ]
「耳朵借我」[rhp]

[:princess:][puri_w kao=0 as=on ]
「啊？……请便」[rhp]

[off_all]

[:kite:]
[font size=13]
「喜欢你」[rhp]
[resetfont]

[yurasu]

[:princess:][puri_w kao=2 as=on hh=on ]
「哈啊！？」[rhp]

[:kite:][kite kao=13 ]
「把博士的数据覆盖掉了」[rhp]

[:princess:][puri_w kao=6 as=on hh=on ]
「真是的！所以不是那种意思啦。[rhr]
_　你到底记什么仇……！！」[rhp]

[off_all]

[chara_part name="jet" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:]
「杰特……我比较迟钝搞不懂这种事的。[rhr]
_　不过那两个人该不会……」[rhp]

[:jet:]
「越界了吧」[rhp]

[:heartshape:]
「一防线！？」[rhp]

[:princess:][puri_w kao=2 as=on hh=on ]
「不是这样的！！」[rhp]

[off_all]

[chara_part name="riri" body=base kao=5 as=on ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:kite:][kite kao=6 as=on ]
「不不，就像疾驰一样」[rhp]

[:quadrillion:][riri kao=2 as=on ]
「差不多该适可而止了……」[rhp]

[off_all]

;-----------------------------------------------------------
;-----------------------------------------------------------

[jump storage="ev_a_08.ks" target="*start"]

;-----------------------------------------------------------
;-----------------------------------------------------------

*start2

;-----------------------------------------------------------
;-----------------------------------------------------------

;****************************************
[set_b storage="train_01.jpg"]
[bgm storage="bgm_13.ogg"]
;****************************************

[::]
―――围着从房间里出来的快斗展开的久违谈笑，[rhr]
意外地热闹了很长时间。[rhp]

[:princess:][puri_w kao=6 ]
「然后呢！快斗那家伙居然说要养那只高腰蛙」[rhp]

[off_puri]

[chara_part name="drop" body=base kao=13 as=off ss=off hh=off hr=on  hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720"  left="600" top="0" wait="true" time=150]

[:drop:]
「这样啊。会变得热闹呢」[rhp]

[:vulpecula:]
「真好啊宠物～。喂～也让我看看嘛佩奇～！」[rhp]

[off_all]

[:kite:][kite kao=13 ]
「就是这个」[rhp]

[off_kite]

[::]
快斗手里捧着装有高腰蛙的透明玻璃箱。[rhr]
似乎还铺了专用草料，准备了相当专业的饲养环境。[rhp]

[chara_part name="riri" body=base kao=2 as=on ss=on hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=on ss=on hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:2nin:]
「………………」[rhr]
「………………」[rhp]

[off_all]

[chara_part name="riri" body=base kao=2 as=on ss=on hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="30" top="0" wait="false" time=150]
[chara_part name="jet" body=base kao=2 as=on ss=on hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="736" top="0" wait="true" time=150]

[:kite:]
「你们这是什么眼神啊」[rhp]

[:jet:]
「我虽然不怕虫子但青蛙不行……」[rhp]

[:kite:]
「听说克林倒是没关系？」[rhp]

[:quadrillion:]
「颜色这么花哨的青蛙是例外啦！」[rhp]

[off_all]

[::]
就在这时候。[rhp]
大家聚集的餐车入口被打开，落合君回来了。[rhp]

[chara_part name="otiai" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=1 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width="=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「落合君！你回来了啊」[rhp]

[:otiai:]
「………………」[rhp]

[off_all]

[::]
落合君无视了我的话语，[rhr]
径直面无表情地走到我面前。[rhp]
这个距离不可能没听见我的声音……[rhp]

[chara_part name="otiai" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=0 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width="=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「落、落合君？你怎么……」[rhp]

[:otiai:][otiai kao=12 ]
「突然这么说很抱歉……」[rhp]
[:otiai:]
「……我，差不多该离开这个世界了」[rhp]

[:princess:][puri_w kao=4 as=on ]
「……诶？」[rhp]

[off_all]

[:kite:][kite kao=2 as=on]
「……宙……？」[rhp]

[off_kite]

[chara_part name="riri" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="otiai" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:quadrillion:]
「这是什么心态转变？你明明是自愿来这个世界的。[rhr]
_　回去这种选项，正常情况下根本不可能考虑吧」[rhp]

[:otiai:]
「是反复思考后的结果」[rhp]

[off_all]

[chara_part name="drop" body=base kao=1 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="otiai" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:otiai:]
「因此，一直以来承蒙关照了」[rhp]

[:drop:][drop kao=1 ]
「最后有什么请求吗？[rhr]
_　只要是我能实现的都会帮忙」[rhp]

[:otiai:][otiai kao=0 ]
「没有。……我本就是异常者。[rhr]
_　与我的意志无关，离开这个世界才是正确的」[rhp]

[off_all]

[::]
落合君过于固执的话语，让四周陷入沉寂。[rhp]

[chara_part name="hakase" body=base kao=1 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720"  left="152" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=3 as=on ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720"  left="600" top="0" wait="true" time=150]

[:vulpecula:]
「小落要走了……好寂寞啊……」[rhp]

[:jet:]
「没办法。既然他这么决定，我们就该支持他」[rhp]

[:vulpecula:][peku kao=1]
「……嗯！博士说得对」[rhp]

[off_all]

[chara_part name="otiai" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720"  left="600" top="0" wait="true" time=150]

[:vulpecula:]
「再见啦小落。在那个世界也要幸福哦」[rhp]

[:otiai:]
「嗯。……佩奇也是」[rhp]

[:vulpecula:][peku kao=4 hh=on ]
「！！！第一次被叫佩奇……！」[rhp]

[off_all]

[chara_part name="jet" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=3 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:jet:]
「……………………」[rhp]

[:heartshape:]
「…………杰特」[rhp]

[:jet:][jet kao=2 ]
「干嘛」[rhp]

[:heartshape:][hati kao=6 as=on]
「没、没什么……」[rhp]

[:jet:][jet kao=6 ]
「落合的事，我根本没放在心上。[rhr]
_　想回去就回去呗。随他高兴不就得了」[rhp]
[:jet:]
「落合的人生是属于落合自己的。[rhr]
_　既然与我们无关，就不该多嘴。对吧？」[rhp]

[:heartshape:][jet kao=3 as=on ]
「……、啊……杰特说得对……、……是啊」[rhp]

[off_all]

[chara_part name="otiai" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=3 as=on ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:kite:]
「……落合」[rhp]

[:otiai:]
「再见啦快斗。和公主好好相处吧」[rhp]

[:kite:][kite kao=2 as=on ]
「……我说啊。你来这里的理由，我大概能猜到……」[rhp]

[:otiai:]
「再会了。和近」[rhp]

[:kite:][kite kao=4 as=on ]
「！」[rhp]

[:otiai:][otiai kao=5 ]
「我这次也会认真的，[rhr]
_　你也别总摆出那副没干劲的样子。这毛病从小就不好」[rhp]

[:kite:]
「……宙……」[rhp]

[:otiai:][otiai kao=13 ]
「下次再见。我不会再输了」[rhp]

[off_all]

[::]
向快斗说完简短的告别后，[rhr]
落合君转身背对我们，朝餐车后方迈开步子。[rhp]

[:princess:][puri_w kao=4 as=on ]
「落合君要去哪里？[rhr]
_　要下车必须先靠岸呢。在那之前我们一起聊天吧」[rhp]

[:otiai:][otiai kao=12 ]
「没这个必要」[rhp]

[:princess:][puri_w kao=0 as=on ]
「诶……」[rhp]

[off_all]

[::]
这里是银河正中央，连上方都是无尽的天空。[rhr]
没必要……那你打算怎么离开这趟铁道？[rhp]

[:princess:]
[font color=0x4682b4]
（难道……）[rhp]
[resetfont]

[::]
就这样走到外面，坠入银河吗？[rhr]
不可能吧。毕竟这个世界可是存在魔法的。」[rhp]
即便如此，不祥的预感仍挥之不去。[rhr]
落合君应该……无法使用魔法才对。[rhp]

[:kite:][kite kao=2 as=on ]
「啊、喂！　公主……！？」[rhp]

[off_kite]

[::]
就在我愣神之际，落合君早已快步走出了车厢。[rhr]
我慌忙追赶着落合君的背影。[rhp]

;****************************************
[bg_rule storage="black.jpg" rule="002.png" time=300]
;****************************************

即便穿过普通车厢与餐车，仍无法追上落合君。[rhr]
这速度未免太快了吧？[rhp]
暂且继续前行，来到卧铺车厢的走廊。[rhr]
但……果然哪儿都不见踪迹。[rhp]

[:princess:]
「诶……？」[rhp]

[::]
难以名状的不安在胸口蔓延。[rhp]
再往前便是观景车厢……这辆铁道的末节。[rhp]
我战战兢兢地，打开了门[rhp]

;****************************************
[bg_rule storage="train_05.jpg" rule="002.png" time=1000]
;****************************************

[:princess:][puri_w kao=2 as=on ]
「…………！？」[rhp]

[off_puri]

[::]
他，已经无处可寻。[rhp]
心想这不可能，便继续向卧铺车厢走去。[rhp]

[:princess:][puri_w kao=2 as=on ]
「落、落合君……！？」[rhp]

[off_puri]

[::]
落合君宛如烟雾般，从这列电车中消失了踪影。[rhp]

[:kite:][kite kao=2 as=on ]
「咳、哈……！突然就跑起来真是的……」[rhp]

[off_all]

[::]
后来追赶过来的快斗，从背后向我搭话。[rhp]
也许是对沉默的我产生了怀疑，他也环顾观景车厢，[rhr]
终于察觉到了异样。[rhp]

[:kite:][kite kao=2 as=on ]
「那家伙呢？」[rhp]

[off_all]

" 我缓缓摇头。徒然呆立原地的我，[rhr]
站在一旁的快斗也同样，露出无法相信这状况的表情。[rhp]

[:princess:][puri_w kao=3 ]
「……太突然了。明明最后想好好道别的」[rhp]

[:kite:][kite kao=3 as=on ]
「……………………」[rhp]
[:kite:][kite kao=12 as=on ]
「…………不，没办法」[rhp]

[:princess:][puri_w kao=2 as=on ]
「！　什么叫没办法？[rhr]
_　哪怕只是短暂相处，落合君也是同伴啊……！」[rhp]

[:kite:][kite kao=2 ]
「这话要是被他本人听到就糟了呢」[rhp]

[:princess:]
「……？什么意思？」[rhp]

[:kite:][kite kao=3 ]
「……没什么」[rhp]
[:kite:]
「不用担心，落合还活着。这点我可以保证」[rhp]
[:kite:]
「……这样就好。对我们彼此来说」[rhp]

[off_all]

[::]
无法理解快斗话语的意图，脑海中浮现问号。[rhp]
但快斗本人毫不在意这些，[rhr]
没有给出更多提示。[rhp]

[:kite:][kite kao=0 ]
「回去吧。突然消失会让大伙担心的」[rhp]

[:princess:][puri_w kao=3 ]
「………………」[rhp]

[:kite:][kite kao=7 ]
「什么啊原来在睡觉。那做那些事也不会被发现呢」[rhp]

[:princess:][puri_w kao=6 as=on ]
「……知道啦！回去总行了吧，这就回去」[rhp]

[:kite:][kite kao=2 ]
「切」[rhp]

[:princess:][puri_w kao=2 as=on ]
「真是滴水不漏啊……」[rhp]

[off_all]

[::]
和落合君分别，快斗难道不难过吗？[rhr]
至少他曾和落合君似乎有过什么过往……[rhp]

[:kite:][kite kao=3 ]
「…………，我说」[rhp]

[:princess:][puri_w kao=6 ]
「这次又怎样」[rhp]

[:kite:]
「这里有我在」[rhp]
[:kite:]
「…………别说你也不想干了啊」[rhp]

[:princess:][puri_w kao=0 as=on ]
「………！」[rhp]

[off_all]

[::]
心头猛然一震。[rhr]
我与夜早已约定，终有一日会离开这条铁道。[rhp]
虽明知不可能知晓他与他人交谈的内容，[rhr]
但那直指要害的话语，仍令我霎时语塞。[rhp]

[:kite:][kite kao=5 ]
「―――嘛，反正也做不到啦」[rhp]
[:kite:]
「我和你早就死透了。[rhr]
_　身体早化成灰，躺在坟墓底下了」[rhp]
[:kite:]
「和落合不一样。我们根本没有归处」[rhp]

[off_kite]

[::]
快斗的语调平淡得近乎自嘲。[rhr]
那奇特的腔调，仿佛他对这个事实感到释然。[rhp]

[:princess:]
[font color=0x4682b4]
（…………好想快点想起来）[rhp]
[resetfont]

[::]
正如与夜所约定的，终有一日我会走下这趟铁道。[rhp]
…………在那之前必须查明真相。[rhp]
曾经相识的我们。落合君[rhr]
会来到这个世界，大概就是为了追寻我们吧。[rhp]
明明年龄性别都截然不同。[rhr]
我们之间究竟，曾是怎样的关系呢。[rhp]
还有……我为何会死去。[rhr]
为何连朋友们都接连丧命。[rhp]
为何只有落合君活着，唯独我们遭遇不测？[rhp]
这其中定然也包含着快斗对我抱持特殊感情的原因。[rhp]

[:princess:]
[font color=0x4682b4]
（……若说还有执念，那就是对真相的无知）[rhp]
[resetfont]

[::]
我忘却一切的这件事，必定践踏了许多人的心意。[rhr]
这样的事，我无法忍受。[rhp]
前方等待的，恐怕是离别的结局吧。[rhp]
即便如此，为了回应这份思念，我想知晓一切。[rhp]
……不。我必须知道。[rhp]

;-----------------------------------------------------------
;-----------------------------------------------------------
[jump storage="ev_a_08.ks" target="*start3"]
;-----------------------------------------------------------
;-----------------------------------------------------------

*start3

;カイト前半エンドフラグ
[eval exp="sf.a_k_end = 1"]

[mask time=2000]
[cancelskip]
[fbgm]

[iscript]
delete f.ev_a_02;
delete f.ev_a_03;
delete f.ev_a_04;
delete f.ev_a_05;
delete f.ev_a_06;
delete f.ev_a_07;
[endscript]

;フラグ初期設定
[iscript]
f.love_d = 0
f.love_k = 0
f.love_r = 0
f.love_h = 0
[endscript]

[jump storage="title.ks" target="*start_end"]

[s]