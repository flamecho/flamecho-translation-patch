﻿*start

;--------------------------------------------------------------------------------------------
;▼フルボイスセット▼
;ヌシ
[voconfig sebuf=1 name=nusi vostorage="nusi/full/{number}.ogg" number=26]
;ドロップ
[voconfig sebuf=1 name=drop vostorage="drop/full/{number}.ogg" number=33]

;--------------------------------------------------------------------------------------------
[fbgm]

[:princess:][puri_w kao=13 ]
「喂喂，多洛普！」[rhp]

[:drop:][p_d_02][drop ]
「！　啊？」[rhp]

[bgm storage="bgm_01.ogg"]

[:princess:][puri_w ]
「多洛普在游乐园有决定好和谁一起逛吗？」[rhp]

[:drop:][p_d_01][drop ]
「不，我会留在车里」[rhp]

[:princess:][puri_w kao=13 ]
「这样啊！那一起逛……」[rhp]
[:princess:][puri_w kao=2 as=on ]
「…………诶？」[rhp]

[off_all]

[::]
刚才说……要留在车里？[rhp]

[:drop:][p_d_02][drop kao=14 ]
「我会守护大家的行李，请放心吧！」[rhp]

[:princess:][puri_w kao=6 as=on ]
「等等等等一下！[rhr]
_　大家是一起来旅行的对吧？没错吧！」[rhp]
[:princess:]
「那样的话多洛普也非得去不可啊！[rhr]
_　一个人留下什么的，那样不是太奇怪了吗？」[rhp]

[:drop:][p_d_07][drop kao=13 ]
「没关系的，住宿设施我也会冒昧打扰的。[rhr]
_　因为要是哈托谢普君他们趁大家睡觉时恶作剧就不好了……」[rhp]

[:princess:][puri_w kao=8 as=on ss=on ]
「如果哈蒂君他们是乖孩子的话，。[rhr]
_　就说明连酒店都没来过……！？」[rhp]

[:quadrillion:][riri kao=6 ]
「没用的。多洛普只会跟着去那些显然需要人手的、[rhr]
_　比如山里或者河边之类的旅行地点」[rhp]

[:drop:][p_d_02][drop kao=5 ]
「因为我很擅长生火！」[rhp]

[:quadrillion:][riri kao=2 as=on ]
「并不是在夸奖你啦……[rhr]
_　嘛，就是因为这样所以多洛普放弃吧」[rhp]

[:princess:][puri_w kao=8 as=on ]
「诶～……！怎么这样。难得的机会……」[rhp]

[:drop:][p_d_32][drop kao=14 as=on ]
「啊，哈哈……请别在意我」[rhp]
[:drop:][drop kao=13 ]
「路上小心公主，今天要玩得开心！」[rhp]

;****************************************
[set_time storage="park_06.jpg"]
;****************************************

[se storage="body_07.ogg"]

[:princess:][puri_w kao=6 ]
「……………………」[rhp]

[off_all]

;****************************************
[bg_rule storage="park_01.jpg" rule="002.png" time=500]
;****************************************

[:drop:][p_d_15][drop kao=11 ]
「哼哼哼～♪」[rhp]

[off_drop]

;****************************************
[bg_rule storage="park_06.jpg" rule="002.png" time=500]
;****************************************

[::]
随后几十分钟。与解散的其他成员分开后[rhr]
我留在入口处，从稍远的地方观察多洛普的动向。[rhp]
来这种地方到底在干嘛呢……一半是这般空虚感。[rhp]
另一半则是果然无法放着多洛普不管的心情。[rhr]
明明是难得的游乐园，这样我可无法接受。[rhp]
…………然而多洛普似乎完全没察觉我的担忧。[rhp]

[:drop:][p_d_02]
「哼哼。呵呵呵～♪」[rhp]

[:drop:][drop kao=1]
「果然洗车让人心情舒畅呢。感觉连心灵都被洗涤了」[rhp]

[off_all]

[:princess:][puri_w kao=2 as=on ]
[font color=0x4682b4]
（自言自语也太多了吧……！[rhr]
_　其实是因为没人说话很寂寞吧！？）[rhp]
[:princess:]
（既然如此等多洛普孤零零叹气的时候，[rhr]
_　我就强行带他去玩！）[rhp]
[resetfont]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:nusi:][nusi ]
「偷窥癖？兴趣不错嘛」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[yurasu]

[:princess:][puri_w kao=2 as=on ]
[font size=26]
「哇！！」[rhp]
[resetfont]

[off_all]

;****************************************
[bg_rule storage="park_01.jpg" rule="002.png" time=500]
;****************************************

[:drop:][p_d_19][drop kao=7 ]
「嗯？刚才好像听到公主的声音……」[rhp]
[:drop:][drop kao=13 ]
「……啊呀，怎么可能呢！哼哼哼～♪」[rhp]

[off_all]

;****************************************
[bg_rule storage="park_06.jpg" rule="001.png" time=500]
;****************************************

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:princess:][puri_w kao=5 as=on ]
[font color=0x4682b4]
（还、还好。似乎没被发现……）[rhp]
[resetfont]

[:nusi:][nusi kao=6 as=on ]
「吓死我了～。[rhr]
_　还以为突然开始演B级功夫片了呢」[rhp]

[:princess:][puri_w kao=8 as=on ]
「努、努西小姐！别突然出声啊。[rhr]
_　我以为心脏要停了！」[rhp]

[:nusi:][nusi kao=7 ]
「喂，声音太大会被多洛普发现的」[rhp]

[:princess:][puri_w kao=6 ]
「没关系的。现在水管水压很强应该听不见」[rhp]
[:princess:]
「所以，有事吗？我现在正忙，如果是来打扰的话……」[rhp]

[:nusi:][nusi ]
「说什么打扰啊！[rhr]
_　我是来帮公主的忙的」[rhp]

[:princess:][puri_w kao=0 ]
「帮我？」[rhp]

[:nusi:][nusi kao=1 ]
「你想带多洛普去游乐园对吧？让我也帮忙」[rhp]

[:princess:][puri_w kao=4 hh=on ]
「真……真的？可以吗？」[rhp]

[:nusi:][nusi kao=14 ]
「当然！[rhr]
_　　不让你们所有人都开心的话，还算什么可爱的小努西」[rhp]

[:princess:][puri_w kao=8 as=on hh=on ]
「小、小努西大人……！」[rhp]

[:nusi:][nusi kao=11 ]
「而且多洛普在我做好事时，偶尔会给小费呢」[rhp]

[:princess:][puri_w kao=0 ]
「嗯？」[rhp]

[:nusi:][nusi kao=3 ]
「不，我每次都拒绝的？但他坚持要给」[rhr]
_　那样的话也不好再推辞了」[rhp]
[:nusi:]
「还有明天要换新机器啦……[rhr]
_　需要瞒着魔太郎子和冈萨雷斯准备资金呢……」[rhp]

[:princess:][puri_w kao=6 as=on ]
「………………」[rhp]

[:nusi:][nusi kao=14 ]
「啊抱歉。对公主说这些太难懂了吧」[rhp]

[:princess:][puri_w kao=7 ]
「……不太明白。[rhr]
_　但你总是做些让人感谢的事对吧？」[rhp]

[:nusi:][nusi kao=5 as=on ]
「咦？嗯——大概吧」[rhp]

[:princess:][puri_w kao=13 ]
「那就放心了！[rhr]
_　请多关照啦，小努西！」[rhp]
[:princess:][puri_w kao=1 ]
「话说替换新机台是啥意思？」[rhp]

[:nusi:][nusi kao=14 as=on ]
「啊、就是换成新机台。_ 意思是把老旧的桌子给换掉吧」[rhr]
_　就是要更换老旧的桌子的意思吧」[rhp]

[:princess:][puri_w kao=13 ]
「原来如此。小努西真机灵啊」[rhp]

[:nusi:][nusi kao=14 as=on ]
「哈哈……是、是吧～？」[rhp]
[:nusi:][nusi kao=6 as=on ]
[font color=0x4682b4]
（没想到她这么不谙世事。_ 总感觉像在骗她，有点良心不安……）[rhr]
_　总觉得像是在骗她，心里过意不去啊……）[rhp]
[resetfont]

[:princess:][puri_w kao=2 ]
「那么具体要怎样才能把多洛普带出去玩[rhr]
_　你觉得有什么方法？」[rhp]

[:nusi:][nusi kao=0 ]
「这个嘛。俺脑子不太好使，耍花招可不擅长。_ 要干就直接来硬的吧」[rhr]
_　要做就得轰轰烈烈用强制手段呗」[rhp]
[:nusi:][nusi kao=1 ]
「但公主毕竟是女孩子，不想让她动粗。时间还有的是，[rhr]
_　一起想办法吧。找个巧妙引诱多洛普出来的法子……」[rhp]

[:princess:][puri_w kao=3 ]
「强制手段吗。果然只剩这招了呢」[rhp]

[:nusi:][nusi kao=1 as=on ]
「别急，别冲动嘛？这纯粹是俺的个人想法啦」[rhp]

[:princess:][puri_w kao=2 ]
「直接带走！用强！！」[rhp]

[:nusi:][nusi kao=6 as=on ]
「咦，大叔你听不见我说话吗？喂喂——」[rhp]

[:princess:][puri_w kao=2 ]
「有志者事竟成，无志者万事休。这就是我！」[rhp]

[:nusi:][nusi kao=8 as=on ]
「哎、哎哎……这样真的好吗……不过开弓没有回头箭了」[rhp]
[:nusi:][nusi kao=5 as=on ]
「干吧公主！既然这样就让多洛普彻底玩个痛快，[rhr]
_　获得大把小费了！！」[rhp]

[:princess:][puri_w kao=5 hh=on ]
「获得了！！」[rhp]

[off_all]

[:drop:][drop kao=2 as=on ]
「不做那种事也会出来的哦……」[rhp]

[off_drop]

;****************************************
;スチル
[se storage="body_07.ogg"]
[still storage="cg/a_02_d_1.png" rule="021.png" width="1280" height="720" rule="021.png" time=300]
[cg storage="cg/a_02_d_1.png"]
;****************************************


;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:2nin:]
[s_playse storage="nusi/full/46.ogg" buf=1]
[font size=26]
「哇！！」[rhr]
「哇！！」[rhp]
[resetfont]

;------------------------------------------------------------------------------------------
;▼再開▼
;ヌシ
[voconfig sebuf=1 name=nusi vostorage="nusi/full/{number}.ogg" number=47]
[vostart]
;------------------------------------------------------------------------------------------

[:drop:]
「是功夫吗？[rhr]
_　……话说回来，中途开始全被听见了啊！」[rhp]

[:princess:]
「哎呀——……水管的水停住了……」[rhp]

[:nusi:]
「聊得太投入没注意到呢」[rhp]

[:drop:]
「那么，努西小姐」[rhp]

[:nusi:]
「啊！　是」[rhp]

[:drop:]
「你这人真是～……！　净教公主些奇怪的事！[rhr]
_　坏大人绝不会再给第二次小费了！」[rhp]

[:nusi:][font size=28]
「！！！！！！！！！！！！！！！！！」[rhp]
[resetfont]

;****************************************
;スチル終了
[still_end frame="win.png" storage="park_06.jpg" rule="021.png" time=1000]
;****************************************

[:drop:][drop kao=6 ]
「什么更换操作台。是柏青哥吧！」[rhp]

[:princess:][puri_w kao=2 ]
「真的吗！？　过分！　你骗了我呢小努西！」[rhp]

[:nusi:][nusi kao=14 as=on ]
「对、对不起……总感觉这样下去能行得通来着……」[rhp]
[:nusi:][nusi kao=1 as=on ]
「………………比想象中更蠢呢」[rhp]

[:princess:][puri_w kao=6 as=on ]
「抱歉啊我就是蠢！！」[rhp]

[:drop:][drop kao=3 ]
「真是的……听好了两位」[rhp]
[:drop:]
「你们关心我让我很高兴，[rhr]
_　但我是自愿留在这里做车身维修的」[rhp]

[:princess:][puri_w kao=3 as=on ]
「呜……可是……」[rhp]

[:drop:][drop kao=3 ]
「公主为我分心，像这样浪费时间，[rhr]
_　我才感到非常难过」[rhp]
[:drop:]
「你听到游乐园时很期待吧？」[rhp]

[:princess:][puri_w kao=6 as=on ]
「那、那是……」[rhp]

[:drop:][drop kao=13 ]
「我的事情请不要在意，您玩得开心就好。这样我就很满足了」[rhp]
[:drop:]
「努西小姐，公主就拜托您了」[rhp]

[:nusi:][nusi kao=6 as=on ]
「哦、哦……、……总觉得心里不舒坦呢……」[rhp]

[off_drop]

[:nusi:][nusi kao=13 as=on ]
「……总之就是这么回事公主。乖乖跟我……」[rhp]

[:princess:][puri_w kao=3 ]
「………………」[rhp]

[:nusi:][nusi kao=0 ]
「公主？」[rhp]

[off_nusi]

[:princess:][puri_w kao=6 ]
「我要向赞助人告状……」[rhp]

[:drop:][drop kao=2 as=on ]
「嗯？」[rhp]

[:princess:][puri_w kao=6 ]
「我要向总公司投诉。[rhr]
_　你们车长那傲慢的态度……」[rhp]

[:drop:][drop kao=8 as=on ]
「什……！？　哪、哪里傲慢了。[rhr]
_　我完全没有那个意思」[rhp]
[:drop:]
「再、再说我根本不害怕南什么的。[rhr]
_　要是再这样纠缠不休的话……」[rhp]

[off_all]

;指パッチン
[se storage="hand_03.ogg"]

[:drop:]
「嘿！」[rhp]

;****************************************
;魔法
[se storage="mag_10.ogg"]
;敷地内
[bg_rule storage="park_02.jpg" rule="027.png" time=1500]
;****************************************

[::]
随着多洛普的喝声与响指，景色骤然转变，[rhr]
我和努西小姐不知何时已置身于游乐园正中央。[rhp]

[:princess:][puri_w kao=2 as=on ]
「啊—！　被用了魔法！？」[rhp]

[:nusi:][nusi kao=7 ]
「哎呀呀。那家伙似乎更高明些呢」[rhp]

[fbgm]

[:princess:][puri_w kao=8 as=on ]
「～～～～～～……可恶」[rhp]

[bgm storage="bgm_15.ogg"]

[:nusi:][nusi kao=0 ]
「游戏结束。放弃那个顽固分子吧」[rhp]

[:princess:][puri_w kao=3 ]
「哈啊……为什么多洛普会固执到那种程度呢」[rhp]
[:princess:]
「明明平时工作那么拼命，[rhr]
_　这种时候不是更应该放松一下吗……」[rhp]

[:nusi:][nusi kao=1 ]
「……，公主真是温柔啊」[rhp]
[:nusi:]
「不过那份温柔，未必对所有人都会产生积极影响啊」[rhp]

[:princess:][puri_w kao=6 ]
「诶……？」[rhp]

[:nusi:][nusi kao=1 ]
「价值观因人而异嘛」[rhp]
[:nusi:]
「那家伙可比你以为的更要热爱自己的工作。[rhr]
_　甚至到了连玩耍时间都舍不得浪费的程度」[rhp]

[:princess:][puri_w kao=0 as=on ]
「………………」[rhp]

[:nusi:][nusi kao=11 ]
「咱们就等着吧。等到他心中自由的价值胜过关责的价值」[rhp]
[:nusi:]
「到时候尽情玩就行了！即便多花点时间也无所谓，[rhr]
_　现在的公主殿下不是有大把时光嘛」[rhp]

[:princess:][puri_w kao=3 ]
「…………、……明白了」[rhp]
[:princess:][puri_w kao=13 ]
「谢谢你啦，小努西。不知怎的稍微舒畅些了」[rhp]

[:nusi:][nusi kao=14 ]
「哼哼，不客气！偶尔我也得说点漂亮话，[rhr]
_　毕竟不知道柏青哥之神会在何时何地注视着嘛」[rhp]

[:princess:][puri_w kao=14 ]
「要是能触发确定变异就好啦！」[rhp]

[:nusi:][nusi ]
「谢啦！赢了就用点心开庆功会吧！」[rhp]

[:princess:][puri_w kao=5 ]
「呵呵……！那今天就和努西一起[rhr]
_　尽情享受游乐园吧。愿意陪我吗？」[rhp]

[:nusi:][nusi kao=14 ]
「当然。陪伴你们才是我们真正的工作啊？」[rhp]
[:nusi:]
「今天非得玩到尽兴不可，[rhr]
_　连多洛普都别想打扰的程度！」[rhp]

[:princess:][puri_w kao=14 ]
「啊哈哈！那我就满怀期待啦」[rhp]

[:nusi:][nusi kao=14 ]
「好嘞！那先从室内的奖章游戏开始―――」[rhp]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
[fbgm]
[set_00 storage="park_01e.jpg"]
;****************************************

[bgm storage="bgm_18.ogg"]

和小努西玩了很多游戏，时间转眼间就过去了。[rhp]
到了傍晚，广场上除了多洛普之外的所有人都聚集在一起的时候。[rhp]

[:princess:][puri_w kao=13 ]
「今天谢谢你啦小努西。多亏了你我玩得非常开心」[rhp]

[:nusi:][p_ns_36][nusi kao=14 ]
「哪里哪里～虽说只是简单的投币游戏，[rhr]
_　偶尔和别人玩点赌博也挺有意思的」[rhp]

[:princess:][puri_w kao=13 ]
「嗯！我也玩得很开心呢！」[rhp]

[off_all]

[chara_part name="mata" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="152" top="0" wait="false" time="150"]
[chara_part name="gon" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="645" top="0" wait="true" time="150"]

[:mataroko:][p_mt_09]
「沉迷的话可不行哦姐姐大人！」[rhp]

[:gonzalez:][p_gn_24]
「老哥就是因为这样才深陷泥潭的」[rhp]

[off_all]


[:nusi:][p_ns_31][nusi kao=14 ]
「没错没错。公主可不能变成这样糟糕的大人啊」[rhp]

[off_all]

[chara_part name="mata" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="80" top="0" wait="false" time="150"]
[chara_part name="nusi" body=base kao=11 as=off ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="383" top="0" wait="false" time="150"]
[chara_part name="gon" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="720" top="0" wait="true" time="150"]

[:2nin:]
[font size=26]
「就你没资格说这话！」[rhr]
「就你没资格说这话！」[rhp]
[resetfont]

[:princess:][puri_w kao=5 as=on ]
「哈哈……我、我会注意的」[rhp]

[off_all]

[eval exp="f.ev02_drop = 1"]
[jump storage="ev_a_02.ks" target=*return]


