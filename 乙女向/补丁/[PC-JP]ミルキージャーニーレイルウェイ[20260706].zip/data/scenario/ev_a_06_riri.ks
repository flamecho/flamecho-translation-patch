﻿ *start
;--------------------------------------------------------------------------------------------
;▼フルボイスセット▼
;クォードリリオン
[voconfig sebuf=1 name=riri vostorage="riri/full/{number}.ogg" number=49]
;--------------------------------------------------------------------------------------------

;****************************************
[bg_rule storage="jungle_01.jpg" rule="011.png" time=500]
;****************************************

[off_all]

[chara_part name="hakase" body=base kao=4 as=on ss=off hh=off hr=on msk=hat ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="peku" body=hood kao=4 as=on ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:darknebula:][p_da_13]
「……咦？刚、刚才那道光是什么」[rhp]

[:vulpecula:][p_vl_19]
「啊咧？克林和小公主去哪了？」[rhp]

[off_all]

[chara_part name="otiai" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:otiai:][p_ot_26]
「…………，哈托谢普。是你搞的鬼吧」[rhp]

[:heartshape:][hati kao=5 ][p_h_24]
「哦！落合直觉真准！完全正确！[rhr]
_　犯人―――不对，怪盗鲁邦四世正是在下！！」[rhp]
[:heartshape:]
[font size=26]
「老子把克林偷走啦！！」[rhp]
[resetfont]

[:otiai:][otiai kao=2 as=on ]
「嗯？」[rhp]

[off_all]

[chara_part name="jet" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="drop" body=base kao=2 as=on ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:jet:][p_j_15]
「克林就在这片森林的某个地方。[rhr]
_　哈蒂用魔法把他轰飞到不知哪里去了」[rhp]

[:drop:][p_d_13]
「为什么要这么做！？」[rhp]

[:jet:][jet kao=14 ]
「哎呀——光是重复露营也太无聊了吧。[rhr]
_　我觉得第二次来点小意外也不错」[rhp]

[:drop:]
「遇、遇难算是『小』意外……！？」[rhp]

[off_all]

[chara_part name="otiai" body=base kao=5 as=on as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="peku" body=hood kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:][p_vl_31]
「啊哈哈哈！这不是寻宝，是寻人游戏啊！！」[rhp]

[:otiai:]
「真无聊……不过倒不讨厌」[rhp]


;****************************************
[set_00 storage="jungle_05.jpg"]
;****************************************

[:quadrillion:][riri kao=2 as=on ss=on ][p_r_21 ]
「怎、怎……！搞什么呀这个！？这是哪儿啊～～～！！？？」[rhp]

[:princess:][puri_w kao=2 as=on ]
「被克林害得卷进这种事！怎么办啦～！？」[rhp]

[:quadrillion:]
「还能怎么办嘛……！」[rhp]
[:quadrillion:]
[font size=28]
「回去杀了他们！！把那群混蛋！！」[rhp]
[resetfont]

[:princess:]
「他们早就死了啊！？」[rhp]

;****************************************
[set_time_b ]
;****************************************

[::]
被抛飞至丛林深处已有几十分钟。[rhp]
四处走动试图感知同伴的气息，[rhr]
却完全察觉不到任何迹象。[rhp]
非但如此，稍走几步连原本的位置都开始模糊不清。[rhp]

[::]
再继续走也无济于事，[rhr]
想必过会儿大家总会来救援吧。[rhp]
我们在附近发现了一处略微开阔的场地，[rhr]
便决定坐在那里稍作休息。[rhp]

[:princess:][puri_w kao=3 as=on ]
「哈啊～感觉比平时还要累上一倍……[rhr]
_　明明去海边或游乐园时走这点路根本不会累的呀」[rhp]

[:quadrillion:][riri kao=6 ][p_r_17]
「毫无成果的话就更觉得累人呢。[rhr]
_　再加上对那些小鬼头的怒火」[rhp]

[:princess:][puri_w kao=3 ]
「虽然他们肯定只是想像平时那样恶作剧。[rhr]
_　但真希望别把我也卷进来啊」[rhp]

[:quadrillion:][riri kao=11 ][p_r_15]
「真是太好了。我下意识抓住了你的裙摆呢」[rhp]

[:princess:][puri_w kao=2 ]
「哈？」[rhp]

[off_all]

[::]
……！！难道……！！[rhr]
因为不想自己一个人倒霉，就故意拉我下水！？[rhp]

[:quadrillion:][riri kao=5 ][p_r_04]
「比起那个，生气和走来走去已经浪费了不少卡路里。[rhr]
_　这附近会不会正好掉着美味的蛋糕呢」[rhp]

[:princess:][puri_w kao=2 ]
「『抓住裙摆』那件事呢？还没说完呢！」」[rhp]

[:quadrillion:][riri kao=6 ][p_r_10]
「啊？……哦。[rhr]
_　多亏瞬间抓住你，能有个伴真是太好了呀」[rhp]

[:princess:][puri_w kao=2 as=on ]
[font color=0x4682b4]
（居、居然毫无愧意……！！）[rhp]
[resetfont]

[:quadrillion:][riri kao=5 ]
「比起一个人闲着，和别人在一起反而能分散注意力」[rhp]
[:quadrillion:][p_r_15]
「哼哼，谢谢你被我卷进来啦」[rhp]

[:princess:][puri_w kao=4 as=on ]
「这家伙……！」[rhp]

[:quadrillion:][riri kao=13 ]
「所以？你怎么样？肚子饿了吗？」[rhp]

[:princess:][puri_w kao=4 as=on hh=on ]
「其实有点饿了……[rhr]
_　难道说克林要给我做点什么？」[rhp]

[:quadrillion:][riri kao=6 ]
「哈？别说傻话了」[rhp]

[:princess:][puri_w kao=2 as=on ]
「那为什么要问啊！」[rhp]

[:quadrillion:][riri kao=14 ][p_r_31]
「等汇合之后，就让他们按我们喜欢的口味[rhr]
_　随便做点什么吧～。现在就来商量要点什么菜」[rhp]

[:princess:][puri_w kao=6 as=on ]
「这种斤斤计较的地方，真是女人……！」[rhp]

[off_all]

[::]
就这样，无所事事的我们，[rhr]
就这样，无所事事的我们开始了毫无营养的徒劳游戏……[rhp]

;****************************************
[fbgm]
[set_time_b]
[bgm storage="bgm_30.ogg"]
;****************************************

[:quadrillion:][riri kao=5 ][p_r_31]
「――――好！暂时就这些吧」[rhp]
[:quadrillion:]
「先列20道菜应该够满足啦。[rhr]
_  已经能想象他们后悔的表情了呢～～」[rhp]
[:quadrillion:]
「红白对多洛普也是抬不起头来，[rhr]
_  就让我代替多洛普给他点颜色瞧瞧！」[rhp]

[:princess:][puri_w kao=1 ]
「原来如此。这样就连克林也能理直气壮地制裁他」[rhp]

[:quadrillion:][riri kao=6 ]
「这话什么意思啊……」[rhp]
[:quadrillion:][riri kao=3 ][p_r_17]
「……不过现在想想对多洛普确实有点过意不去呢。[rhr]
_　现在他正独自搭帐篷呢。把那种重活全推给他真过意不去」[rhp]

[:princess:][puri_w kao=6 ]
「……克林对多洛普或快斗时就挺温柔的嘛」[rhp]

[:quadrillion:][riri kao=0 ][p_r_19]
「是吗？我觉得很正常啊」[rhp]

[:princess:]
「对我和哈蒂君他们就特别严厉！」[rhp]
[:princess:]
「该怎么说呢，就像是敞开心扉的感觉？[rhr]
_　总觉得我们和多洛普他们之间，隔着一道看不见的薄～～薄墙壁」[rhp]

[:quadrillion:][riri kao=7 ]
「啊——……或许确实如此吧。毕竟交往时间更长。[rhr]
_　像多洛普从这辆电车完工时就一直在一起了」[rhp]

[:princess:][puri_w kao=2 as=on ]
[font color=0x4682b4]
（完工时就！？……难怪一副老资格做派……）[rhp]
[resetfont]

[:quadrillion:][riri kao=12 ]
「多洛普来了不久后快斗加入，你和那些小鬼都是很久之后的事了。[rhr]
_　态度有差别也是没办法的吧」[rhp]

[:princess:][puri_w kao=0 ]
「哼嗯……这样啊……」[rhp]

[off_all]

[::]
听着对话，我心想这或许能成为记忆的线索。[rhr]
假装不经意地试图深入往事话题，清了清嗓子后继续道。[rhp]

[chara_part name="riri" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=13 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「……我说！以前的多洛普他们是什么样？」[rhp]

[:quadrillion:][riri kao=8 ][p_r_10]
「哈？突然问这个。和现在没区别啦」[rhp]

[:princess:][puri_w kao=14 as=on ]
「没、没有啦，你看那个……」[rhr]
[font color=0x4682b4]
（一上来就有搅局的家伙吗！　看看气氛好不好！）[rhp]
[resetfont]

[:quadrillion:][riri kao=12 ]
「正如你所知，这辆电车是死人聚集的异次元空间。[rhr]
_　所以不存在变老啊这类概念。这个座位不会带来成长」[rhp]
[:quadrillion:]
「你应该也没考虑过要成长吧」[rhp]

[:princess:][puri_w kao=0 ]
「……？　为什么？」[rhp]

[:quadrillion:][riri kao=0 ]
「在这里可以成为自己想成为的模样―――[rhr]
_　……被允许以理想形象存在」[rhp]

[:princess:][puri_w kao=0 ]
「理想形象……」[rhp]

[:quadrillion:][riri kao=1 ]
「比如年龄啦，性别啦」[rhp]

[:princess:][puri_w kao=2 as=on ]
[font color=0x4682b4]
（性别方面没实现吧？）[rhp]
[resetfont]

[:quadrillion:][riri kao=13 ][p_r_09]
「你刚才心想性别没实现对吧」[rhp]

[:princess:][puri_w kao=8 as=on ]
「！！　对、对不起。这是个敏感问题，」[rhp]

[yurasu]
[se storage="hand_05.ogg"]

[:princess:][puri_w kao=2 as=on ss=on ]
「好痛！！」[rhp]

[:quadrillion:][riri kao=5 as=on ss=on ]
「人家才不是想变成女生啦～～～。[rhr]
_　只是不可抗力变成这样而已啦～～～」[rhp]

[:princess:][puri_w kao=6 as=on ]
「明明没必要打人的……！」[rhp]

[:quadrillion:][riri kao=12 ][p_r_29]
「……嘛！　总之因为这个缘故，我们这些年[rhr]
_　始终和容貌性格不变的旅伴同行。自然会建立信任」[rhp]

[:princess:][puri_w kao=11 as=on ]
「原来如此。我理解了。[rhr]
_　那拿你们和多洛普他们比较待遇差别也没意义了……」[rhp]

[:quadrillion:][riri kao=5 ]
「就算不这样，小丫头你想获得我的信任还早一百年呢」[rhp]

[:princess:][puri_w kao=7 ]
「但之前的我和克林关系挺不错的吧？」[rhp]
[:princess:]
「在我失去记忆的那天去打招呼时，[rhr]
_　你很亲切地和我搭话了呢。虽然立刻就被背叛了」[rhp]

[:quadrillion:][riri kao=6 ]
「………………啊。好像是有这么回事」[rhp]

[:princess:][puri_w kao=0 ]
「呐，我是多久前来这辆电车的？[rhr]
_　过了多久，才失去记忆的呢？」[rhp]

[:quadrillion:][riri kao=2 ][p_r_10]
「凭什么非要告诉你这些啊」[rhp]

[:princess:][puri_w kao=3 ]
「因为决定要找回遗忘的记忆。和某人约定好的」[rhp]
[:princess:]
「所以，任何细微的线索都想要。[rhr]
_　大家从一开始就不肯直接告诉我答案，这事我倒隐约察觉到了呢」[rhp]

[fbgm]

[:quadrillion:][riri kao=3 ]
「………………」[rhp]

[:princess:]
「果然不行吗？」[rhp]

[:quadrillion:]
「…………也罢，可以哦。只要不被责难的程度就行」[rhp]

[:princess:][puri_w kao=4 as=on ]
「诶……！真的？」[rhp]

[off_puri]

[bgm storage="bgm_07.ogg"]

[:quadrillion:][riri kao=3 ]
「失去记忆前的……，……曾经的你是个好女人。[rhr]
_　从不会像现在这样，露出半点怯弱的样子」[rhp]
[:quadrillion:]
「对谁都很温柔，没有讨厌的东西，永远只讲正确的道理。[rhr]
_　用比任何人都要坚强的心，绝不向他人展示软弱之处……」[rhp]
[:quadrillion:]
「…………那就是，以前的你」[rhp]

[off_all]

[::]
确实和现在的我完全不同……。[rhr]
……话说根本像是两个人吧？[rhp]

[:quadrillion:][riri kao=3 ]
「现在的你既愚蠢，又莽撞，还是个糊涂蛋。[rhr]
_　要说相同之处，也就只有性别和长相了吧」[rhp]
[:quadrillion:]
「究竟在哪一步出了差错才会导致记忆消失呢。[rhr]
_　真的觉得『前任公主』很可怜啊」[rhp]

[:princess:][puri_w ]
「………………」[rhp]

[off_all]

[::]
…………该怎样回答才好呢。[rhr]
道歉似乎不对，反驳又显得奇怪。[rhp]
究竟『从前的我』遭遇了什么，才有了现在的我呢……[rhr]
非但没能解开谜团，反而有种愈发深陷泥沼的感觉。[rhp]

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
[vostart]
;--------------------------------------------------------------------------------------------

[:quadrillion:][riri kao=3 ]
「我知道你并不是坏人」[rhp]

[::]
听到这句意想不到的夸德里利昂的话语，我猛地抬起脸来。[rhp]
他脸上浮现出某种寂寥的、我从未见过的表情。[rhp]

[:quadrillion:][riri ]
「实际同行至此，我们也算相处愉快。[rhr]
_　和以前的你不同，现在开你玩笑也无妨的氛围，这方面我倒觉得不错」[rhp]
[:quadrillion:]
「所以这是我的问题。你并没有错」[rhp]
[:quadrillion:]
「……只是无法接受改变后的你」[rhp]
[:quadrillion:]
「我的挚友不是你，而是失去记忆前的那个你」[rhp]

[off_all]

[::]
夸德里利昂悲伤地垂下眼帘。[rhp]
――――失去记忆前的我。[rhr]
即便是作为本人的我听起来也感到惊讶，这简直是完美无瑕的女性形象。[rhp]
差异实在太过巨大，让人感觉毫无现实感。[rhr]
但看着讲述着我不了解的自己的夸德里利昂，我似乎隐约明白了什么。[rhp]

[:princess:][puri_w kao=3 ]
「克林，你是喜欢以前的我吗？」[rhp]

[:quadrillion:][riri kao=4 ]
「哈啊？」[rhp]

[off_all]

[::]
夸德里利昂惊讶地瞪圆了双眼。[rhr]
随即立刻捧腹大笑起来。[rhp]

[:quadrillion:][riri kao=14 ]
「噗……啊哈哈哈！[rhr]
_　你这人真是，无可救药的笨蛋呢！」[rhp]

[:princess:][puri_w kao=6 as=on hh=on ]
「怎、怎么啦！？你露出那种遥望远方的神情说着话，[rhr]
_　正常人都会误会你是恋爱了吧！」[rhp]

[:quadrillion:]
「很遗憾并不是哦。[rhr]
_　刚才也说过了，我们只是好朋友」[rhp]
[:quadrillion:][riri kao=11 ]
「有很多事情只有和那孩子才能倾诉。但现在做不到了。[rhr]
_　因为感到寂寞，才会出现你说的『遥望远方的眼神』吧」[rhp]

[:princess:][puri_w kao=8 ]
「真的吗～……？总觉得有点假惺惺的……」[rhp]

[:quadrillion:][riri kao=6 ]
「真是的，蠢女人动不动就把男女关系往爱情上扯。[rhr]
_　请便，想怀疑就尽管怀疑好了」[rhp]

[:princess:][puri_w kao=6 ]
「………………。再说这种话的话，[rhr]
_　等我记忆恢复时，绝对不会告诉克林的哦！」[rhp]

[:quadrillion:][riri kao=5 ]
「无所谓啦。反正你从今往后绝对、绝对、[rhr]
_　不会再想起和我们一起的旅行了」[rhp]

[:princess:][puri_w kao=0 ]
「凭什么说得这么肯定啊」[rhp]

[:quadrillion:][riri kao=11 ]
「谁知道呢～现在的我才不告诉你原因呢～」[rhp]

[:princess:][puri_w kao=88 as=on ]
「喂！我可是很认真在问你的啊！」[rhp]

[:quadrillion:][riri kao=77 ]
「唉～救援来得真慢。该不会是因为你在场、[rhr]
_　才这么倒霉的吧～？」[rhp]

[:princess:][puri_w kao=2 as=on ss=on ]
「……………………」[rhp]

[:quadrillion:][riri kao=13 ]
「布兹要变得更丑八怪咯～」[rhp]

[:princess:][puri_w kao=3 ]
「…～～～够了。反正克林就是这种人、[rhr]
_　事到如今也不会为这点刻薄话生气了」[rhp]
[:princess:]
「但我想和克林变得要好」[rhp]

[:quadrillion:][riri kao=4 ]
「……！」[rhp]

[:princess:]
「即使达不到从前的关系、只要不再说刻薄话、[rhr]
_　能正常聊天、帮我出主意就够了」[rhp]
[:princess:]
「……就算克林不这么想、我还是觉得、[rhr]
_　和克林说话很轻松很可靠」[rhp]

[:quadrillion:][riri kao=0 ]
「………你这人………」[rhp]

[:princess:][puri_w kao=2 as=on ]
「可恶、明明是个好色鬼～……！[rhr]
_　这世道果然巨乳才是王道可恶！」[rhp]

[:quadrillion:][riri kao=5 ]
「…………、女孩子不该说什么可恶的」[rhp]

[:princess:]
「你以为是谁害的啊～！？色狼！下流胚！[rhr]
_　粉毛都是变态！粉毛都是淫魔！！」[rhp]

[:quadrillion:][riri kao=6 as=on ]
「胡说什么呢，真是的……」[rhp]
[:quadrillion:][riri kao=12 ]
「…………这头发，不是你选的颜色」[rhp]

[:princess:][puri_w kao=6 ]
「哦。那是以前的我吧」[rhp]

[:quadrillion:][riri kao=3 ]
「…………我倒是要谢谢你」[rhp]
[:quadrillion:]
「这头发。现在依然是独一无二属于我的」[rhp]

[:princess:][puri_w kao=2 ]
「啊这样啊，你们感情和睦真是再好不过了。[rhr]
_　真是太棒了呢～～～～」[rhp]

[off_all]

[yurasu]

[se storage="hand_06.ogg"]

[:princess:]
[font size=27]
「啊"啊―――――！！」[rhp]
[resetfont]

[:princess:]
「痛痛痛痛！！锁头技太要命了！！」[rhp]

[:quadrillion:]
「换作以前的你啊！[rhr]
肯定会轻飘飘说句『太好了呢』就完事了对吧！！！！」[rhp]
[:quadrillion:]
「快说啊！！！说太好了啊！！！！！」[rhp]

[:princess:]
「好、太好了……！？太好了啊！！」[rhp]

[:quadrillion:]
「谢谢你啊！！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:princess:][puri_w kao=8 as=on ss=on ]
「哈啊……哈啊……到、到底搞什么啊……！」[rhp]

[:quadrillion:][riri kao=2 ][p_r_09]
「啧！少给我摆脸色。[rhr]
_　把自己搞这么丑是准备参加什么选丑大会吗」[rhp]
[:quadrillion:]
「听着？不许再提过去的你了。[rhr]
_　对着既定事实絮絮叨叨可不符合我的作风」[rhp]

[:princess:][puri_w kao=6 as=on ]
「明、明白了……」[rhp]

[:quadrillion:][riri kao=13 ][p_r_31]
「这才对」[rhp]

[off_all]

[::]
虽然早知道夸德里利昂对我不抱好感，[rhr]
但没想到会到这种程度。[rhp]
况且看这架势，[rhr]
看样子不太可能因为仰慕什么而接纳我了……[rhp]

[:quadrillion:][riri kao=7 ]
「……、你啊」[rhp]

[::]
对长久沉默的我，夸德里利昂突然开口搭话，[rhr]
不知为何带着试探的意味，神情略显迟疑。[rhp]
……又想搞什么鬼？这次是窒息睡眠者之类的吗？[rhp]
总之先将双臂在脸前交叉，摆出防御姿势。[rhp]

[:quadrillion:][riri kao=2 as=on ]
「这姿势什么意思……才没打算对你做什么呢」[rhp]

[::]
声音听着倒是相当认真。[rhr]
姑且相信对方，我放下了手臂。[rhp]
夸德里利昂略显无奈地叹了口气，静静开口道：[rhp]

[:quadrillion:][riri kao=2 ][p_r_04]
「你啊，是想和我做朋友吧」[rhp]
[:quadrillion:]
「…………你口中的那个『我』，真的是我吗？」[rhp]

[:princess:][puri_w ]
「……？什么意思？」[rhp]

[:quadrillion:][riri kao=3 ]
「虽然自己这么说有点怪，但这个世界的我已经改变太多了。[rhr]
_　大概和你生前认识的我完全相反。为此也付出了努力」[rhp]
[:quadrillion:]
「你想交朋友的对象，[rhr]
_　真的是『夸德里利昂』这个存在吗？」[rhp]

[off_all]

[::]
我想成为朋友的究竟是……？[rhp]

[:princess:][puri_w kao=2 ]
「……没错」[rhp]

[:quadrillion:][riri kao=2 ]
「回答得真爽快。反而可疑起来了」[rhp]

[:princess:][puri_w kao=6 ]
「因为我真的什么都不记得了。[rhr]
_　不仅是这段旅程，还包括生前的一切记忆」[rhp]
[:princess:]
「我只知道自我苏醒后认识的大家。[rhr]
_　所以我想结交的朋友，就是现在眼前的克林啊」[rhp]

[:quadrillion:][riri kao=0 as=on ]
「………、………」[rhp]

[:princess:][puri_w ]
「对了！刚才那话是真的吗？[rhr]
_　我活着的时候，曾是你的朋友？」[rhp]

[:quadrillion:][riri kao=2 as=on ]
「！　啊……不，这个」[rhp]

[:princess:][puri_w ]
「要是真的就太开心了。我更想找回记忆了。[rhr]
_　因为唤醒记忆的话，就能知道关于克林的事―――」[rhp]

[:quadrillion:][riri kao=3 ]
「别这样」[rhp]

[:princess:][puri_w kao=4 as=on ]
「……诶」[rhp]

[:quadrillion:]
「不必想起来」[rhp]
[:quadrillion:]
「…………求你了」[rhp]

[:princess:][puri_w kao=0 as=on ]
「克、克林……？」[rhp]

[:quadrillion:][riri kao=2 as=on ]
「――――！　……那个……」[rhp]
[:quadrillion:][riri kao=11 as=on ]
「……想、想起来的话会绝望的啊。[rhr]
_　你会发现自己堕落成了多么愚蠢的女人！」[rhp]

[:princess:][puri_w kao=2 as=on ]
「～～～～！　够了！[rhr]
_　我再也不和克林说正经话了！」[rhp]

[:quadrillion:][riri kao=5 ][p_r_24]
「这样最好。听说机灵的布兹更受欢迎。[rhr]
_　弥补你的缺陷，祝你早日从砧板进化成人」[rhp]

[:princess:][puri_w kao=6 as=on ]
「这、这家伙……！！」[rhp]

[off_all]

[:unknown:]
[font size=28]
「啊！！！！！」[rhp]
[resetfont]

[:princess:][puri_w kao=4 as=on ]
「！　刚才，好像有人声……」[rhp]

[off_all]

[::]
我们循着突然响起的声音四处张望。[rhp]
因四周皆是森林根本看不见身影，[rhr]
片刻后正面的灌木丛传来沙沙的拨开声……[rhp]

[:nusi:][nusi kao=2 as=on ][p_ns_09 ]
「夸德里利昂！　公主！　终于找到了！！」[rhp]

[:princess:][puri_w kao=4 as=on ]
「小努西！？」[rhp]

[off_all]

[:gonzalez:][gon kao=5 ][p_gn_02 ]
「喂——哥哥！　姐姐！　在这里，他们两个人在这边啊——！！」[rhp]

[off_all]

[:mataroko:][mata kao=6 as=on ][p_mt_09 ]
「请等一下下啦！　穿礼服跑不快的呀～」[rhp]

[off_all]

[chara_part name="riri" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="gon" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]
[chara_part name="puri_w" body=base kao=4 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:quadrillion:][p_r_35]
「你们来了啊。好久不见呢～」[rhp]

[:princess:]
「难不成，是专程来找我们的吗？」[rhp]

[:gonzalez:][p_gn_32 ]
「啊。到达后发现只有多洛普一个人在场真是吓了我一跳。[rhr]
_　听说你们迷路的消息后，连问缘由的时间都没有就被拉去参加搜索了」[rhp]

[:quadrillion:][riri kao=13 ][p_r_27 ]
「对迷路这个说法我表示异议，[rhr]
_　不过很感谢你们赶来救援」[rhp]

[:gonzalez:][gon kao=3 ]
「毕竟实在不习惯在丛林里活动，[rhr]
_　找起来可费劲了。来晚了真对不住啊」[rhp]

[:quadrillion:][p_r_24]
「没事没事，已经算快的了。要是交给其他小鬼和那群天然呆，[rhr]
_　说不定在你找到我之前就先变成骨头了」[rhp]

[off_all]

[:mataroko:][mata kao=8 as=on ][p_mt_01 ]
「姐姐大人！夸德里利昂！您平安无事真是太好了。[rhr]
_　从多洛普那里听说时我可真是吓了一跳呢！」[rhp]

[:princess:][puri_w ]
「对不起啦玛塔。让你担心了」[rhp]

[off_all]

[chara_part name="riri" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="nusi" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:nusi:][p_ns_31 ]
「哈哈哈！真是飞来横祸啊夸德里利昂！[rhr]
_　被双子组看上就是你的末日啦」[rhp]

[:quadrillion:][p_r_11]
「才不是好笑的事。为什么我要遭这种罪……[rhr]
_　还要和布兹这家伙独处！简直糟透了」[rhp]

[:princess:][puri_w kao=6 ]
「骗子！刚才不是说幸好有说话对象帮了大忙吗！」[rhp]

[:quadrillion:][riri kao=6 ]
「才没有～呢。好啦快点回去吧」[rhp]

[off_all]

[:quadrillion:][riri kao=2 ss=on ]
「我们还有事情要做呢……[rhr]
_　就让那群混账小鬼们瑟瑟发抖等着吧！」[rhp]

[off_all]

[::]
说完这话，夸德里利昂就咚咚地走在了最前面。[rhr]
见状我们面面相觑露出苦笑，随后也跟了上去。[rhp]
在难走的丛林里前进时，[rhr]
我想起了夸德里利昂说过的话。[rhp]

[:princess:]
[font color=0x4682b4]
（他说『不要想起来』究竟是为什么呢。[rhr]
_　如果是朋友的话，不是会希望对方记起自己吗？）[rhp]
[resetfont]

[::]
揣测不出话语的真意，心里搅动着浑浊的迷雾。[rhr]
虽然想问清缘由，但估计又会被像刚才那样搪塞过去。[rhp]
话说您那么认真……不对，[rhr]
因为是初次听到他那疲惫的声音，所以更加犹豫不决。[rhp]

[:princess:]
[font color=0x4682b4]
「（该怎么办呢。要是能装作若无其事地打听到就好了……）」[rhp]
[resetfont]

[:mataroko:][mata kao=4 as=on ]
「姐姐，危险！」[rhp]

[off_all]

[:princess:][puri_w kao=4 as=on ]
「咦？……哇！！」[rhp]

[off_all]

[::]
突然抬起头，原来是因为一直低着头走路[rhr]
没注意到一根粗壮的树枝已经近在眼前。[rhp]
赶紧闭上眼睛准备承受冲击。[rhp]
………………然而。[rhp]

;****************************************
[se storage="body_07.ogg"]
;スチル
[still storage="cg/a_06_r_1.png" rule="021.png" width="1280" height="720" time=1000]
[cg storage="cg/a_06_r_1.png"]
;****************************************
;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:quadrillion:]
「哎呀……你在干什么啦。摇摇晃晃的不是很危险吗」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[::]
他从前面伸手环抱住差点摔倒的我，[rhr]
（虽然略带困扰）但表情担忧地俯视着我的夸德里利昂。[rhp]
被支撑的身体传来暖意，那双与发色相同的粉红眼眸异常温柔。[rhr]
不知为何我无法长久直视那双眼眸，突然别过了脸。[rhp]
……总感觉脸颊发烫，是我的错觉吗。[rhp]

[:nusi:]
「接得好！」[rhp]

[:gonzalez:]
「没事吧？虽然差一点就砸到眼睛了」[rhp]

[:princess:]
「没、没事。谢谢大家」[rhp]
[:princess:]
「克林也谢谢你……[rhr]
_　我稍微有点心跳加速了呢！　嘿嘿」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

;****************************************
#
[bg storage="cg/a_06_r_1b.png" width="1280" height="720" time=500]
[cg storage="cg/a_06_r_1b.png"]
;****************************************

[:quadrillion:]
「对洗衣板情有独钟的我，照顾你也是理所当然的吧」[rhp]

[:princess:]
「………………」[rhp]

;****************************************
#
;スチル終了
[still_end frame="win.png" storage="jungle_03.jpg" rule="021.png" time=1000]
;****************************************

[se storage="hand_06.ogg"]

[:quadrillion:]
「好痛痛痛痛！！！！！　头部固定太危险了！！」[rhp]

[:princess:]
「我刚刚还以为你总算有点温柔的地方了！[rhr]
_　结果你这人妖～～！！」[rhp]

[:quadrillion:]
「这是事实吧！　无论是平板身材的事，还是我温柔的事！」[rhp]

[:princess:]
「话是这么说啦！」[rhp]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

[:nusi:][nusi kao=6 ]
「你们俩——别打情骂俏了快点——」[rhp]

[off_all]

[chara_part name="riri" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=2 as=on ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[yurasu]

[:2nin:]
「才没有打情骂俏！！」[rhr]
「才没有打情骂俏！！」[rhp]

[off_all]

[chara_part name="nusi" body=base kao=5 as=on ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width=514" height="720" left="168" top="0" wait="false" time=150]
[chara_part name="gon" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:nusi:]
「真是默契呢」[rhp]

[:gonzalez:][p_gn_31 ]
「嘴上说着不要不要……还挺有风情嘛……！」[rhp]

[:nusi:][nusi kao=13 ][p_ns_02 ]
「真够风骚的」[rhp]

[off_all]

[:princess:][puri_w kao=6 as=on ]
[font color=0x4682b4]
（～～～！　真是的，克林你到底怎么回事！[rhr]
_　还以为你变温柔了，结果还不是老样子！）[rhp]
[:princess:]
（居然为那种家伙心动，我真是没出息……！[rhr]
_　再也不会为你心跳加速了！）[rhp]
[resetfont]

[yurasu]

[:princess:][puri_w kao=2 ss=on ]
[font size=28]
「好嘞！！！」[rhp]
[resetfont]

[off_all]

[chara_part name="riri" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="mata" body=base kao=5 as=on ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:mataroko:][p_mt_24 ]
「干劲十足呢，姐姐大人……[rhr]
_　您待会儿该不会被杀吧？」[rhp]

[:quadrillion:][p_r_09]
「哼，那种细胳膊能成什么事。[rhr]
_　看我怎么反杀她」[rhp]

[:mataroko:][mata kao=11 ]
「哎呀真可怕。不过看你们感情升温比什么都好」[rhp]

[:quadrillion:][riri kao=6 ][p_r_17]
「才……才没有那种事呢」[rhp]
[:quadrillion:]
「………………嘛，确实是说了多余的话」[rhp]

[:mataroko:][mata kao=0 ][p_mt_19 ]
「？　这话怎么说……」[rhp]

[off_all]

[:princess:][puri_w kao=6 ]
「喂——克林，玛塔！　你们在干嘛～？[rhr]
_　不好好跟着的话，会走散的哦！」[rhp]

[:mataroko:][mata kao=14 hh=on ]
「啊！　请等一下～！！[rhr]
_　魔太郎子这就来您身边～！」[rhp]


[off_all]

[:quadrillion:][riri kao=6 ][p_r_11]
「哈啊……还是这么啰嗦的小不点呢」[rhp]
[:quadrillion:][riri kao=3 ]
「………………、今天的事就当没发生过吧。[rhr]
_　总之现在先快点重新振作起来……」[rhp]


;****************************************
[jump storage="ev_a_06.ks" target="*start2"]
;****************************************


[s]

