﻿
*start

[fbgm]
[mask color=0x000000 time=2000]

[cm]

[clearfix]
[start_keyconfig]
[loadjs storage="myscript.js"]

;初期設定---------------------------------------------------------------------

;メッセージウィンドウの設定
[position layer="message0" frame="win2.png" left=0 top=520 width=1280 height=200 page=fore visible=true]

; 文字表示領域
[position layer=message0 page=fore margint="65" marginl="420" marginr="60"]

;キャラ名表示領域
[ptext name="chara_name_area" layer="message0" color="0x000000" size=22 align=center bold=true x=420 y=550]

; 立ち絵の設定
[chara_config anim=false memory=true ptext="chara_name_area"]

[call storage="character.ks"]
[call storage="voice.ks"]

;--------------------------------------------------------------------------------


;--------------------------------------------------------------------------------------------
;▼フルボイスセット▼

;伊東一近（幼少）
[voconfig sebuf=1 name=kazu vostorage="kazu/full/{number}.ogg" number=1]
;神崎凛生（幼少）
[voconfig sebuf=1 name=rio vostorage="rio2/full/{number}.ogg" number=1]
;八雲博士
[voconfig sebuf=1 name=hiro vostorage="hiro/full/{number}.ogg" number=134]
;タケル
[voconfig sebuf=1 name=take vostorage="take/full/{number}.ogg" number=1]
;ヤブ
[voconfig sebuf=1 name=yabu vostorage="yabu/full/{number}.ogg" number=109]
;ミカちん
[voconfig sebuf=1 name=tiaki vostorage="mika/full/{number}.ogg" number=124]
;サウス
[voconfig sebuf=1 name=sausu vostorage="sausu/full/{number}.ogg" number=238]
;糠星の夜
[voconfig sebuf=1 name=yoru vostorage="yoru/full/{number}.ogg" number=80]

;--------------------------------------------------------------------------------------------

;****************************************
;タイトル表示

[bg storage="title/title_3a.png" time=100]
[bgm storage="bgm_07.ogg"]

[s_mask_off time=2000]

[bg storage="title/title_3b.png" time=2000]

[s_wait time=3000]

[bg storage="title/title_3a.png" time=2000]

[s_mask color="0x000000" time=3000]

[bg storage="hsps_02.jpg" time=100]
[layopt layer=message0 visible=true]
[showmenubutton]
[plugin name="menu_plugin"]
[s_mask_off time=2000]

;****************************************

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
[vostart]
;--------------------------------------------------------------------------------------------

[:himeko:][hime2 kao=4 ]
「―――这就是银河铁道？」[rhp]

[off_all]

[chara_part name="hiro" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="kazu" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="kazu" layer="1" width="437" height="720" left="760" top="0" wait="true" time=150]

[:hirosi:]
「没错。这幅画是将天河当作铁轨，[rhr]
_　然后在上面画了电车呢」[rhp]
[:hirosi:]
「天河上漂浮的黑色朦胧是煤袋，[rhr]
_　也就是被称为暗黑星云的星际气体团块」[rhp]
[:hirosi:]
「这个用肉眼也能看到，如果矢部老师能批准的话，[rhr]
_　在中庭进行天体观测就太棒了」[rhp]

[:himeko:][hime2 kao=13 ]
「天体观测……！就像往年的七夕会呢！希望今年也能得到许可」[rhp]
[:himeko:]
「和君，你真的能熬夜晚睡吗？」[rhp]

[:kazutika:][kazu kao=7 ]
「该担心的理央才对吧。[rhr]
_　他怕鬼怕到根本没法专心观测天体啦」[rhp]

[off_all]

[:rio:][rio2 kao=3 as=on ]
「呜……要是有鬼的话，博库还是算了啦……」[rhp]

[:hirosi:][hiro kao=5 ]
「没问题的。真正的幽灵一点儿都不可怕哦」[rhp]
[:hirosi:]
「我有幽灵朋友所以很清楚」[rhp]

[off_all]

[:himeko:][hime2 kao=4 as=on ]
「幽灵朋友！？」[rhp]

[off_all]

[:kazutika:][kazu kao=0 ]
「就算是博士这话也太扯了……」[rhp]

[:hirosi:][hiro kao=7 ]
「那我证明给你看。和近今天的内裤颜色是―――」[rhp]

[:kazutika:][kazu kao=2 as=on ]
「哇、知道啦！！有的！幽灵是存在的！！」[rhp]

[off_all]

[chara_part name="rio2" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="rio2" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:himeko:]
「如果是好幽灵就没问题啦。理央君！[rhr]
_　一定要拜托爸爸妈妈让你参加哦！」[rhp]

[:rio:][rio2 kao=13 ]
「嗯……！　只要说是经常一起玩的朋友，应该就没问题的。[rhr]
_　而且这是我第一次说这种话……或许能得到宽容吧」[rhp]

[:himeko:][hime2 kao=1 ]
「不愧是理央君。真是优等生呢！」[rhp]

[off_all]

[:hirosi:][hiro kao=1 ]
「要是能成立七夕会就好了」[rhp]

[off_all]

[:himeko:][hime2 kao=1 ]
「嗯！」[rhp]

[off_all]

;****************************************
[still storage="cg/b2_1.png" width="1280" height="720" time=1000]
[cg storage="cg/b2_1.png"]
;****************************************

[:himeko:]
「真希望能被看到呢。这样的天空！」[rhp]
[:himeko:]
「那个……」[rhp]

[:hirosi:]
「因为是难写的汉字所以忘记了吧。这幅画的标题是……」[rhp]
[:hirosi:]
「《糠星夜》哦」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************

;抜粋表示

[layopt layer="message0" visible="false"]
[s_mask graphic="rule/title_3c.png" time=2000]
[hidemenubutton]

[bg storage="title/title_3c.png" time=100]

[s_mask_off time=2000]

[bg storage="title/title_3d.png" time=2000]

[s_wait time=2000]

[bg storage="title/title_3c.png" time=3000]

[s_mask color="0x000000" time=3000]
#

[fbgm]
[bg storage="black.jpg" time=100]
[layopt layer="message0" visible="true"]
[position layer="message0" frame="win2.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[showmenubutton]
[s_mask_off time=2000]
[bgm storage="bgm_34.ogg"]
;****************************************

―――濒死之人偶尔会以双目捕捉到"不可视之物"。[rhp]

;****************************************
[filter layer="base" sepia="70" ]
[bg storage="hsps_12.jpg" time=1000]
;****************************************


那是我在此地首次与人类对话时的往事。[rhp]
那个孩子捕捉到我的身姿，在坚信我是"神明"的情况下，[rhr]
提出了"总有一天要乘坐银河铁道"的要求。[rhp]
对此我是这样回应的：[rhp]

『面对现实吧。你所能做到的事很有限』[rhp]
『你们需要的不是痴人说梦或妄想，[rhr]
_　而是如何安稳度过余生的完善临终医疗』[rhp]

…………他当时凝视我的表情，至今难忘。[rhr]
他突然抽泣起来，此后便再未出现在入口处。[rhp]
一个月后，他死了。[rhr]
至死都梦想着前往银河铁道。[rhp]
……真是让人不快的话题。所以我早就说过了。[rhr]
若怀抱无法实现的梦想，那注定会变成执念。[rhp]

;****************************************
[set_ff storage="sky_07.jpg" time=1000]
;****************************************

孩子们啊。[rhr]
明明知晓自己的宿命，为何还要如此仓促地活着？[rhp]
哪怕安分些，尽量保持安静的话，[rhr]
应该也能多活一天吧。[rhp]

「说得太过分了」这种话，哪有立场说。[rhr]
正是因为你们日复一日地依赖，才会回应你们的期待吧。[rhp]

「银河铁道」还是什么玩意儿终究是痴人说梦。[rhr]
与其做不切实际的梦，不如切实充实当下更有意义。[rhp]
我祈求的是现世的幸福。[rhr]
结果却像成了坏人似的。[rhp]
…………啊，实在令人不快。[rhp]

;****************************************
[set_b storage="hsps_02.jpg" time=1500]
;****************************************

―――不过，那都是往事了。[rhp]
虽顶着煞有介事的头衔，但作为基本无事可做的我，[rhr]
白天多在设施里漫无目的地游荡。[rhp]
一个理由是为了寻找能看见我的人，[rhr]
并刻意对那人隐匿我的存在。[rhp]
另一个理由嘛……算是兴趣吧。[rhp]
这里的职员们手很巧，[rhr]
经常能看到告示板之类装饰的变化，很有意思。[rhp]
凝望窗外流转的景色亦别有韵味。[rhp]
只要作为凭依物的这幅画还在这设施里，我便无法离开此处。[rhr]
所以或许算是某种类似憧憬的感情吧……[rhp]

[:nusi:][nusi kao=5 ]
「哦哟，夜先生～」[rhp]

[off_all]

[:yoru:][yoru kao=0 ]
「呀。是你们啊」[rhp]

[off_all]

[chara_part name="mata" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" wait="false" left="-10" top="0" time=150]
[chara_part name="nusi" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" wait="false" left="250" top="0" time=150]
[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" wait="false" left="510" top="0" time=150]
[chara_part name="gon" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" wait="true" left="820" top="0" time=150]


[:nusi:][nusi kao=13 ]
「在这种地方碰面真是巧呢」[rhp]

[:mataroko:][mata kao=13 ]
「是每日例行的散步吗？」[rhp]

[:yoru:][p_y_02][yoru kao=12 ]
「别说得像老头子似的。不是散步是视察」[rhp]
[:yoru:][yoru kao=0 ]
「那你们在这儿干嘛？平时都在大厅挺稀奇的」[rhp]

[:gonzalez:][p_gn_15][gon kao=5 ]
「哼哼哼……！我们可是要去侦察的！」[rhp]

[:yoru:][yoru kao=0 ]
「这样啊。辛苦了」[rhp]

[:gonzalez:][gon kao=4 as=on ]
「嗯？」[rhp]

[off_all]

[:yoru:][yoru kao=7 ]
「那我先走了」[rhp]

[:gonzalez:][p_gn_21][gon kao=3 as=on ]
「等等等等！老爷啊！你好歹表现出点兴趣嘛！？」[rhp]

[:yoru:][yoru kao=2 ]
「新住客的事吧。已知情报就不值得驻足」[rhp]

[off_all]

[:nusi:][p_ns_16][nusi kao=5 ]
「说是新住客，可不是普通的新人哦？」[rhp]
[:nusi:]
「是『这边』的新家伙」[rhp]

[off_all]

[:yoru:][p_y_19][yoru kao=4 ]
「…………！」[rhp]

[off_all]

[::]
这边。即指像我们这样的存在。[rhr]
长久以来都未再诞生过，坦白说令人吃惊。[rhp]

[chara_part name="mata" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" wait="false" left="-10" top="0" time=150]
[chara_part name="nusi" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" wait="false" left="250" top="0" time=150]
[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" wait="false" left="510" top="0" time=150]
[chara_part name="gon" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" wait="true" left="820" top="0" time=150]

[:mataroko:][p_mt_31]
「像我们这样的存在，可是极其罕见的呢。[rhr]
_　是小刚之后的新人呢，让人心跳加速」[rhp]

[:gonzalez:][gon kao=5 ]
「终于我也要告别后辈角色了……我要成为大人了」[rhp]

[:yoru:][yoru kao=7 ]
「是吗。那，现在它在哪里？」[rhp]

[:nusi:][p_ns_36][nusi kao=5 ]
「101号室哦」[rhp]

[:yoru:][yoru kao=7 ]
「…………１０１」[rhp]

[off_all]

[::]
那是离员工站最近的特别房间。[rhr]
由于是这类设施，几乎不会出现空房，总是有人在使用的。[rhp]
新人出现在这种地方，着实让人有些在意。[rhp]

[chara_part name="nusi" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:yoru:]
「……那样的话就另当别论了。我也去吧」[rhp]

[:nusi:][nusi kao=13 ]
「这才对嘛！」[rhp]

 [off_all]

;****************************************
#
[bg_rule storage="hsps_09.jpg" rule="002.png"]
;****************************************

[chara_part name="peku" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="hiro" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:vulpecula:][p_vl_11]
「嗯～～～？　那，康贝瑞拉是死掉了吗？」[rhp]

[:hirosi:]
「不，他原本就是已死之身。历经银河之旅，[rhr]
_  找到了自己应当下车的地方。所以才下了银河铁道啊」[rhp]

[:vulpecula:][peku kao=7 ]
「煤袋？……那里？」[rhp]

[:hirosi:][p_hr_23]
「没错。煤袋……暗黑星云有种说法是，[rhr]
_  显现着冥府的入口」[rhp]
[:hirosi:]
「银河铁道被认为连接着那个世界和这个世界啊」[rhp]

[:vulpecula:][peku kao=3 ]
「啊～真是的！搞不懂啦～～！[rhr]
_  死掉的话既不能买票，我觉得也坐不上电车啦！」[rhp]

[:hirosi:][hiro kao=4 ]
「之前也说过了，那是……」[rhp]

[off_all]

;****************************************
#
[bg_rule storage="hsps_07.jpg" rule="002.png"]
;****************************************

[:yoru:][yoru kao=6 ]
「………………」[rhp]

[off_all]

[chara_part name="mata" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="nusi" body=base kao=8 as=on ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="gon" body=base kao=4 as=off ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="720" top="0" wait="true" time=150]

[:nusi:]
「沃尔佩克拉还是这么蠢呢。博士都要头疼了吧」[rhp]

[:gonzalez:][gon kao=6 ]
「但那家伙说的极其在理。[rhr]
_　　死了的话要怎么买票……？伪造吗？」[rhp]

[:nusi:][nusi kao=6 as=on ]
「伪造什么的。既然是幻想作品就别在意细节啦，」[rhp]

[:mataroko:][p_mt_08][mata kao=14 ]
「获得形体的沃尔佩克拉酱……！超级可爱呢！」[rhp]
[:mataroko:][p_mt_15][mata kao=11 ]
「好想 someday 成为朋友。一起开茶会交换红茶和曲奇，[rhr]
_　夜里悄悄集合举办秘密睡衣派对之类的」[rhp]
[:mataroko:][p_mt_15][mata kao=3 as=on ]
「要怎样才能和沃尔佩克拉酱变得亲近呢……[rhr]
_　魔太郎子的朋友只有赌棍和小混混，完全想不到好话题！」[rhp]

[off_all]

[chara_part name="nusi" body=base kao=1 as=on ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:yoru:]
「……那个水子，是在这附近游荡的幽灵吧」[rhp]

[:nusi:][p_ns_01]
「是啊。经常看见他和浩在一起」[rhp]
[:nusi:][nusi kao=5 ]
「这次的新人在那边」[rhp]

[off_all]

[::]
顺着视线看去，是个有着彩虹色头发的陌生男子。[rhp]

;****************************************
#
[bg_rule storage="hsps_09.jpg" rule="002.png"]
;****************************************

[chara_part name="sausu" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="-60" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="355" top="0" wait="false" time=150]
[chara_part name="hiro" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="760" top="0" wait="true" time=150]

[:sausu:][p_s_08]
「博士真的很喜欢《银河铁道之夜》呢」[rhp]

[:hirosi:][hiro kao=1 ]
「嗯。是我最喜欢的小说」[rhp]

[:vulpecula:][p_vl_11][peku kao=3 as=on ]
「诶～～南原来也是能理解这一派的人啊？…………」[rhp]
「……博、博库其实也懂的哦？完全没在怕的！」[rhp]

[:sausu:][sausu kao=5 ]
「哦？那来场讨论会如何」[rhp]

[:vulpecula:][peku kao=7 as=on ]
「！等、等有兴趣再说吧……博库现在很忙的啦……」[rhp]

[:hirosi:][p_hr_26][hiro kao=4 ]
「南，别太欺负人了」[rhp]

[:sausu:][sausu kao=1 ]
「呵呵，抱歉抱歉。沃尔佩克拉真是个有趣的孩子呢」[rhp]

[off_all]

;****************************************
#
[bg_rule storage="hsps_06.jpg" rule="002.png"]
;****************************************

那个男人……是叫南吗。[rhr]
乍看之下氛围温和……却感受到强大的力量。[rhp]
与我相比也毫不逊色的力量。[rhr]
看来是有灌注了相当强烈愿望的依附之物。[rhp]
瞥了一眼室内，立刻察觉到了。[rhp]

[chara_part name="nusi" body=base kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:yoru:]
「……千纸鹤吗。原来如此」[rhp]

[:nusi:][nusi kao=5 ]
「听说是鹤还以为会是更文静的家伙，[rhr]
_　没想到是这么开朗热闹的家伙啊」[rhp]
[:nusi:]
「而且看来还拥有相匹配的力量。[rhr]
_　这样粗心大意的话，最强之位可要被夺走了哦。约尔先生～」[rhp]

[:yoru:][p_y_17][yoru kao=6 ]
「………………」[rhp]

[:nusi:][p_ns_33][nusi kao=8 ]
「喂……别瞪我啊。开玩笑的」[rhp]

[:yoru:][p_y_02][yoru kao=7 ]
「……无所谓。我认为这是极其合理的意见」[rhp]
[:yoru:]
「我对力量没有兴趣，但力量的紊乱会导致纪律的混乱。[rhr]
_　若是太过搅乱局势，我也不会保持沉默」[rhp]

[off_all]

[chara_part name="mata" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="gon" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]


[:mataroko:][p_mt_15]
「宣誓！我绝不会对约尔大人谋反！」[rhp]

[:gonzalez:][p_gn_06][gon kao=13 ]
「我也是！老大最强！日本第一！」[rhp]

[off_all]

[:yoru:][p_y_26][yoru kao=7 ]
「不记得有把你们视为威胁」[rhp]

[off_all]

[yurasu]

[chara_part name="mata" body=base kao=4 as=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="gon" body=base kao=12 as=on hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:2nin:]
「咣！！」[rhr]
「咣！！」[rhp]

[:mataroko:][mata kao=8 hh=on ]
「…………但稍微有点心动」[rhp]

[:gonzalez:][gon kao=14 hh=on ]
「寡言少语的信任关系……！很有格调！」[rhp]

[off_all]

[chara_part name="nusi" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:yoru:]
「真是讽刺啊。这与等待死亡之人聚集的场所实在不相称。[rhr]
_　现实地看，能真正实现的愿望恐怕屈指可数吧」[rhp]

[:nusi:][p_ns_17][nusi kao=3 as=on ]
「别这么说嘛。大家都是拼尽全力制作的」[rhp]

[:yoru:][p_y_02][yoru kao=0 ]
「我并未否定他们的努力。[rhr]
_　只是指出他存在的意义与这场所的矛盾之处」[rhp]

[:nusi:][nusi kao=7 ]
「嘿嘿，是是」[rhp]

[off_all]

[chara_part name="mata" body=base kao=4 as=off ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="gon" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="355" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="650" top="0" wait="true" time=150]

[:gonzalez:][p_gn_22]
「老爷啊，您到底对南那小子哪里不满意啊？」[rhp]

[:mataroko:][mata kao=8 ]
「莫非打算教训不来问候的后辈吗！？」[rhp]

[:yoru:][yoru kao=12 ]
「胡说什么。那种程度还不值得教训」[rhp]
[:yoru:][yoru kao=7 ]
「…………我总觉得那个男人相当扭曲」[rhp]

[:gonzalez:][gon kao=2 ]
「扭曲？」[rhp]

[:yoru:][yoru kao=8 ]
「虽具备相当的魔力与格调，内在却不相称。[rhr]
_　大概因为精神食粮多半来自年幼稚嫩的孩子吧」[rhp]
[:yoru:]
「而且太过偏心。他只对浩和幽灵感兴趣。[rhr]
_　虽摆出学者派头，对此地本身的理解却远远不够」[rhp]
[:yoru:]
「沉溺在转瞬即逝的友情里能成什么事。浩很快就要死了」[rhp]

[off_all]

[:nusi:][p_ns_20][nusi kao=6 ]
「喂、喂。何必说得这么难听」[rhp]

[:yoru:][yoru kao=7 ]
「事实如此。……不过是短暂的交情罢了。[rhr]
_　你应该明白拙劣的假装友好只会徒劳无功」[rhp]

[:nusi:][nusi kao=3 ]
「诶……不，那个……」[rhp]

[off_all]

[chara_part name="gon" body=base kao=12 as=on ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:gonzalez:][p_gn_09]
「真严厉啊糠星的老爷子」[rhp]

[:yoru:][yoru kao=8 ]
「是你们太天真了。[rhr]
_　如果继续这样袖手旁观，受苦的会是那只鹤」[rhp]

[:gonzalez:][gon kao=6 ]
「话是这么说啦。但毕竟是新人，难免有不懂的——」[rhp]

[:yoru:][p_y_24][yoru kao=2 ]
「无关紧要。我们可不是以婴儿状态诞生的」[rhp]
[:yoru:]
「地位伴随着责任。需要相应的行为举止。他并不明白这点」[rhp]

[:gonzalez:][gon kao=12 as=on ]
[font color=0x4682b4]
（简直油盐不进啊……）[rhp]
[resetfont]

[off_all]

[:yoru:][yoru kao=7 ]
「……没兴致了。我先行告辞」[rhp]

[off_all]

[:mataroko:][p_mt_30][mata kao=4 as=on ]
「连告辞都免了吗？」[rhp]

[off_all]

[:yoru:][p_y_02][yoru kao=12 ]
「主动问候是后辈的职责。这可是你说的」[rhp]

[off_all]

[::]
要说完全没兴趣……那是谎话。[rhp]
千纸鹤，本是为实现愿望而折的物件。[rhr]
倘若那家伙真具备与之相当的力量……[rhp]

―――『认清现实吧。你能做的事很有限』[rhp]

[:yoru:]
「………………」[rhp]

[::]
……这话说别人可不合适。[rhr]
必须对自己的发言负责。[rhp]
什么「倘若」……连自己都觉得是荒唐的妄想。[rhp]

;****************************************
[bg_rule storage="hsps_09.jpg" rule="002.png" time=1500]
;****************************************

[:sausu:][sausu kao=0 ]
「………………」[rhp]

[:hirosi:][hiro kao=4 ]
「怎么了，南」[rhp]

[:sausu:][sausu kao=13 ]
「……抱歉。我暂时离席」[rhp]
[:sausu:]
「毕竟是后辈嘛」[rhp]

[:hirosi:][hiro kao=6 ]
「哈？」[rhp]

[:sausu:][sausu kao=1 ]
「是我这边的事。很快就回来」[rhp]

[off_all]

;****************************************
#
[bg_rule storage="hsps_06.jpg" rule="002.png" time=1500]
;****************************************

[:sausu:]
「喂——！等等我！」[rhp]

[:yoru:][yoru kao=2 ]
「……你是」[rhp]

[:sausu:][p_s_04][sausu kao=13 ]
「呀！你就是传闻中的约尔大人吧！」[rhp]

[:yoru:][p_y_36][yoru kao=0 ]
「………………。是又怎样，有事吗」[rhp]

[:sausu:][sausu kao=14 ]
「刚才真是吓一跳呢。没想到约尔大人会主动跟我打招呼」[rhp]

[:yoru:][yoru kao=6 ]
「没打过」[rhp]

[:sausu:][sausu kao=11 ]
「你刚才是想打招呼的吧。我懂的」[rhp]
[:sausu:][p_s_34]
「对不起啊。本来想去问候你的，[rhr]
_　但那三个人说你很可怕，我就不由自主拖延到现在」[rhp]
[:sausu:]
「其实我一直想和约尔大人聊一次啊。[rhr]
_　你的凭依体真是太棒了。博士爱看的那本书和那幅画肯定有些关联——」[rhp]

[:yoru:][p_y_04][yoru kao=2  ]
「喂」[rhp]

[:sausu:][sausu kao=3 ]
「嗯？」[rhp]

[:yoru:][yoru kao=2 ]
「一开口就喋喋不休……有话快说」[rhp]

[:sausu:][p_s_20][sausu kao=14 ]
「就是打招呼呀。仅此而已啦」[rhp]
[:sausu:]
「我是南！刚诞生不久的新人。[rhr]
_　今后请多关照」[rhp]

[:yoru:][yoru kao=2 ]
「～～～～…………这样啊。知道了。再见」[rhp]

[:sausu:][sausu kao=4 as=on ]
「！要去哪儿？难得有机会去博士房间喝杯茶吧」[rhp]

[:yoru:][yoru kao=0 ]
「不去。我和你合不来」[rhp]

[:sausu:][sausu kao=3 ]
「你和比我吵闹的三人组不是相处得挺好嘛」[rhp]

[:yoru:][p_y_24][yoru kao=12 ]
「那是老交情。你和他们不一样」[rhp]

[:sausu:][sausu kao=13 ]
「那今后还请多和我―――」[rhp]

[off_all]

[:yoru:][yoru kao=0 ]
「总之。今后请尽量避开有我所在的入口活动」[rhp]

[off_all]

[:sausu:][p_s_12][sausu kao=8 as=on ]
「刚见面就被讨厌了……」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:yoru:][p_y_04]
「…………既然如此，我就直说了」[rhp]

[:sausu:][sausu kao=8 ]
「？什么事？」[rhp]

[:yoru:][yoru kao=2 ]
「制作你依附体的，是浩吧」[rhp]

[:sausu:][p_s_15][sausu kao=13 ]
「！　啊，没错。[rhr]
_　虽然得到很多人帮助，但大半都是他的功劳」[rhp]
[:sausu:]
「博士很厉害的！什么都懂，还特别温柔……」[rhp]

[:yoru:][yoru kao=7 ]
「别再享受特殊待遇了」[rhp]

[:sausu:][sausu kao=8 as=on ]
「……？特殊待遇……」[rhp]

[:yoru:][yoru kao=6 ]
「若死亡平等降临，救赎也应平等。[rhr]
_　你将与浩的羁绊过于神化，已经看不清自身立场」[rhp]

[:sausu:][p_s_18][sausu kao=8 ]
「我不明白。对将自己带到这个世界的人，[rhr]
_　心怀感激并道谢有什么错？」[rhp]

[:yoru:][yoru kao=2 ]
「没错。你不是挺明白吗」[rhp]
[:yoru:]
「我在这箱庭中，平等见证过所有终结。[rhr]
_　不存在任何偏袒或歧视。这是扎根于此地者的本分」[rhp]
[:yoru:]
「你正在破坏我建立的平等」[rhp]

[:sausu:][sausu kao=3 ]
「……………………」[rhp]

[:yoru:][yoru kao=12 ]
「无需平等参与他们的生，但应平等接纳他们的死」[rhp]
[:yoru:]
「你的话语只会徒增无谓的希望。[rhr]
_　等到明白那有多残酷时，就已经太迟了」[rhp]
[:yoru:]
「他们的死亡，并非是为了让你学习才降临的」[rhp]

[:sausu:][p_s_10][sausu kao=13 ]
「………………原来如此」[rhp]
[:sausu:]
「约尔大人也曾没能救下谁吗」[rhp]

[:yoru:][yoru kao=4 ]
「啊……？」[rhp]

[:sausu:][p_s_15][sausu kao=1 ]
「那一定是因为想要拯救的意志还不够强烈」[rhp]
[:sausu:][sausu kao=13 ]
「我可是千纸鹤啊。被赋予的愿望都会实现。[rhr]
_　为此付出的努力在所不惜。这就是我的生存之道」[rhp]
[:sausu:]
「嘛简单来说……希望你别把我和你相提并论」[rhp]

[:yoru:][yoru kao=2 ]
「……无可救药的蠢货。真是难缠！」[rhp]

[off_all]

[:sausu:][sausu kao=13 ]
「好啦好啦！说教已经够多了。[rhr]
_　招呼也打过了，我这就告辞啦」[rhp]

[off_all]

[:yoru:][yoru kao=2 as=on ]
「喂……！」[rhp]

[off_all]

[::]
那家伙头也不回地沿着来路离去。[rhp]
估计是要回八云博士的房间吧。[rhr]
反正本体就在那里，也是理所当然。[rhp]

[:yoru:]
「…………愚蠢至极」[rhp]

[::]
什么『想要拯救的意志』。[rhr]
如果靠这种虚无缥缈的东西就能救人，当初那个孩子不就得救了吗？[rhp]
…………诡辩罢了。不值一驳。[rhr]
既然宁可沉溺于天真，那随你便好了」[rhp]
为此受苦的只会是你自己，与我毫无关系。[rhp]

;****************************************
[fbgm]
[set_b storage="black.jpg"]
;****************************************

2个月后[rhp]

;****************************************
[bg storage="sky_03.jpg" time=1000]
[bgm storage="bgm_15.ogg"]
;****************************************

死讯本应是司空见惯之事。[rhp]
那天的临终关怀院仿佛整栋建筑都被雨云笼罩着，[rhr]
uniformly dark atmosphere blanketed the place.[rhp]
最年长的浩今天停止了呼吸。[rhp]
据说他临终前连自己是谁都辨认不清，[rhr]
that heart-wrenching state was unbearable to witness.[rhp]
resident children displayed unprecedented grief,[rhr]
entrances remained static as weeping reached even my stationary position.[rhp]

;****************************************
[bg storage="hsps_07a.jpg" time=1000]
;****************************************

vacated hospital room revealed 南 slumped in powerless dejection.[rhp]
like us, exists only perceptible to those with numbered days.[rhr]
his eyes reflected his own visage, he must have known time was short.[rhp]
see? That's why I warned against getting involved.[rhp]

;****************************************
[bg storage="cg/b1_6.png" time=1000]
;****************************************

…………Yet, something's amiss.[rhr]
man's lamentation carries unfathomable depths.[rhp]
impossible to believe he merely mourns a parting.[rhp]

『Pending tasks pile mountain-high』[rhp]
oblivious to my gaze, he distinctly uttered those words.[rhp]

……Those eyes. Concealing something.[rhr]
current display of grief clearly exceeds normal bounds.[rhp]
说浑浊也好。[rhr]
说沉淀也罢。[rhp]

;****************************************
[bg storage="black.jpg" time=1000]
;****************************************

…………但愿别演变成麻烦事。[rhp]

;****************************************
[set_b storage="sky_06b.jpg" time=3000]
;****************************************

―――再过两个月后。[rhp]
时光流逝，八云博士的死亡正逐渐成为往事。[rhp]

这里每年都有许多孩子结束他们的生命。[rhp]
是的。并非什么特别的事。[rhp]
无论是谁，时候到了都会轮到的。[rhp]

;****************************************
[bg storage="hsps_06e.jpg" time=1000]
;****************************************

[:himeko:]
「呜哇啊啊啊……！」[rhp]

[:rio:]
「抽泣……呜呜呜……！」[rhp]

[:kazumama:]
「你们两个，谢谢你们……」[rhp]
[:kazumama:]
「……谢谢你们一直和和近友好相处」[rhp]

[::]
最吵闹的孩子团体中有一人今晨死去了。[rhp]
本就喧闹的孩子们用更大的声音哭号，在居室里哭肿了眼睛。[rhp]
白发少年……是叫凛生吧。[rhr]
在他父母来接他之前，那哭声持续了一整天。[rhp]

[:yoru:]
[font color=0x4682b4]
（…………没什么大不了的）[rhp]
[resetfont]

[::]
这是看过无数次的景象。[rhp]
再过几天就会恢复平静了吧。[rhr]
尽管年幼，他们也会认清现实。[rhp]
无论怎么哭喊，朋友都不会回来。[rhp]

[:yoru:]
[font color=0x4682b4]
（说实话真腻烦。他们每次有人死去都这样）[rhp]
[:yoru:]
（…………星名[player2]、是叫这个名字吧）[rhp]
[resetfont]

;****************************************
#
[bg storage="sky_06b.jpg" time=1000]
;****************************************

[::]
与今日死去的少年同病房的少女。[rhp]
病情较为稳定但痊愈希望渺茫，[rhr]
虽在接受治疗,却几乎等同于过着等待死亡的生活。[rhp]

只要还有可能性我就赞成继续治疗。反正不行也不过是恢复原状罢了。[rhr]
然而这位少女充沛的活力，简直让人无法联想到病患。[rhp]
……坦白说，这样的家伙我还是头一回见。[rhp]

至今为止接触了这么多人的死亡，[rhr]
一旦轮到自己时又会如何呢。[rhp]
是否会同样地嚎啕大哭呢。[rhr]
或者会萌生出另一种感情。[rhp]
……难以置信的是，我不知不觉间，[rhr]
这个星名[player2]似乎对那位少女产生了兴趣。[rhp]

;****************************************
[bg storage="black.jpg" time=200]
;****************************************

多亏如此才得以察觉。[rhp]
一直对那个千纸鹤的图谋感到违和。[rhp]
……对那污浊的真面目。[rhp]

;****************************************
[set_n storage="hsps_02m.jpg"]
;****************************************

[::]
…………深更半夜。[rhp]
哭累的孩子们早已安静入睡。[rhp]


[:sausu:][sausu kao=3 ]
「……………………」[rhp]

[off_all]

[::]
……果然来了么。[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:yoru:][yoru kao=2 ]
「千羽鹤」[rhp]

[off_all]

[:sausu:][sausu kao=4 as=on ]
「…………！　约尔大人」[rhp]

[off_all]

[::]
在沉寂无声的夜晚玄关处，浮现出微微发光的那个身影。[rhp]
千纸鹤像受到惊吓般转向这边，[rhr]
然后尴尬地扭曲了嘴角。[rhp]

[chara_part name="sausu" body=base kao=13 as=on ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sausu:]
「啊、啊咧……这个时间不是该在散步吗？」[rhp]

[:yoru:][yoru kao=0 ]
「今天我一直在等你」[rhp]

[:sausu:][sausu kao=13 ]
「……！　……真稀奇。平时连话都不好好说，」[rhp]

[:yoru:][yoru kao=2 ]
「你在人类身体上做了有趣的手脚呢」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:sausu:][sausu kao=0 ]
「…………！」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:yoru:][yoru kao=6 ]
「……真是没用。居然会输给这种新人」[rhp]
[:yoru:]
「那么？这到底是谁允许的」[rhp]

[:sausu:][sausu kao=1 ]
「……、当然是你的默许。我以为你早就察觉到了，[rhr]
_　一直没作声就是这个意思吧」[rhp]
[:sausu:]
「因为经过深思熟虑才实施应该不会失败，难道是状态不好吗。[rhr]
_　抱歉啊，没注意到」[rhp]

[:yoru:][yoru kao=6 ]
「没关系。你平常到连[rhr]
_　你的恶行都没被发现的程度」[rhp]


;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:sausu:][sausu kao=0 ]
「…………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:yoru:][yoru kao=2 ]
「……要装傻是吧。好啊」[rhp]
[:yoru:]
「从诞生所耗费的时间、资材、执念这些因素来看[rhr]
_　我拥有你和小团体三人无法比拟的强大力量」[rhp]
[:yoru:]
「而我将这份力量封存在作为本体的这幅绘画而非灵体中。[rhr]
_　通过不携带灵力，让那些能可视化我的小鬼无从察觉存在」[rhp]
[:yoru:]
「对于爱戏弄人的你来说本应无法理解这种行为……我原是这样想的。[rhr]
_　没想到反被你利用了」[rhp]
[:yoru:]
「本以为你是个草包，没想到还挺有两下子」[rhp]

[:sausu:][sausu kao=13 ]
「……啊……啊哈哈。谢谢……」[rhp]

[:yoru:][yoru kao=0 ]
「我的力量可还合您心意」[rhp]

[:sausu:][sausu kao=4 ]
「……你不生气吗？」[rhp]

[:yoru:][yoru kao=7 ]
「就算生气事实也无法改变。……所以？用起来顺手吗」[rhp]

[:sausu:][sausu kao=11 ]
「那个……非、非常棒！[rhr]
_　我出生时也算获得了不错的神格，但你的力量完全不同层级」[rhp]
[:sausu:]
「真不愧是约尔大人。你的力量可以随心所欲[rhr]
_　创造出任何东西呢」[rhp]

[:yoru:][yoru kao=8 ]
「比如银河铁道什么的」[rhp]

[:sausu:][sausu kao=7 ]
「……！……呃」[rhp]

[:yoru:][yoru kao=0 ]
「你以我为媒介创造了平行世界」[rhp]
[:yoru:]
「……还把死者的灵魂囚禁其中」[rhp]

[off_all]

[::]
话音刚落，他的表情显示出被说中要害。[rhp]
真是个可悲的蠢货。[rhr]
做事完全不经大脑。[rhp]
…………不过我也没资格说别人。[rhp]

[chara_part name="sausu" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:yoru:]
「这个异空间我一个人无法撬开。[rhr]
_　因为所有力量都用在创造平行世界了」[rhp]
[:yoru:]
「假以时日自会恢复，但干等着实在太蠢」[rhp]
[:yoru:]
「更重要的是，实在令人不快。[rhr]
_　岂能继续被你这傲慢混蛋小瞧」[rhp]

[:sausu:][sausu kao=8 as=on ]
「……请放过我」[rhp]

[:yoru:][yoru kao=2 ]
「拒绝。我只想要回力量和解救孩子们」[rhp]

[:sausu:][sausu kao=13 ]
「在绘画中，大家都过得还好吗？」[rhp]

[:yoru:][yoru kao=4 as=on ]
「啊……？」[rhp]

[:sausu:][sausu kao=11 ]
「你就是那幅画……就是那个世界本身，里面的情况应该能传达给你」[rhp]
[:sausu:]
「怎么样。他们看起来过得很快乐吗」[rhp]

[:yoru:][yoru kao=2 ]
「……那又怎样」[rhp]
[:yoru:][yoru kao=12 ]
「等我恢复力量，也要去那铁道露个脸。[rhr]
_　为了第一个告诉他们你那毫无伦理可言的行径」[rhp]
[:yoru:]
「在被讨厌之前，赶紧……」[rhp]

[:sausu:][sausu kao=6 ]
「谁敢保证下一辈子能过得幸福？」[rhp]

[:yoru:][yoru kao=2 as=on ]
「什么……？」[rhp]

[:sausu:][sausu kao=8 ason ]
「这间临终关怀院里的人，都憧憬着你的世界。[rhr]
_　孩子们都希望死后能像这幅画一样去旅行」[rhp]
[:sausu:]
「而现在，这个愿望实现了。[rhr]
_　无论对我还是对他们而言，没有比这更幸福的事了」[rhp]
[:sausu:]
「………………谁要讨厌谁？」[rhp]

[:yoru:][yoru kao=2 as=on ]
「……你，知道自己到底在说什么吗……？」[rhp]

[:sausu:][sausu kao=3 ]
「……约尔大人真是冷酷。而且永远都是正确的」[rhp]
[:sausu:]
「但正确的事是否就是最好的选择，我倒觉得另当别论」[rhp]

[:yoru:][yoru kao=2 as=on ]
「………………」[rhp]

[off_all]

[::]
…………无言以对。[rhp]
这家伙疯了。[rhp]
这种可怕的事不该被允许。[rhp]

但他确实实现了。[rhr]
把我耍得团团转，再利用殆尽。[rhp]

被无力化的现在的我无计可施。[rhp]
…………需要下一步对策。[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
[fbgm]
[free_filter ]
[set_b storage="black.jpg" time=1500]
;****************************************

……………………。[rhp]
………………………………………………。[rhp]

[bgm storage="bgm_27.ogg"]

―――――……来说个往事吧。[rhp]
成绩优秀、前途无量、备受期待的名医。[rhp]
讲讲这样的我，关于后悔与重振的故事。[rhp]

;****************************************
[set_w storage="hsps_03.jpg"]
;****************************************

[::]
那大概是我刚赴任这家临终关怀院，正好一年前的事。[rhp]


[:tiaki:][tiaki kao=13 ]
「那么大家，要开始喽～？预备——！」[rhp]

[off_all]

;クラッカー
[se storage="se4_02.ogg"]

[:xnin:]
「矢部老师！欢迎来到银河站～～！」[rhp]

[off_all]

[:takeru:][take kao=4 as=on ]
「…………………………」[rhp]

[off_all]

[chara_part name="tiaki" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:][p_mk_14][tiaki kao=5 ]
「呵呵！听说有新老师要来，[rhr]
_　没想到是这么一位出色的老师呢！」[rhp]
[:tiaki:]
「[player2]多少分？能打几分？」[rhp]

[:himeko:][hime2 kao=13 ]
「嗯～30分！」[rhp]

[:tiaki:][tiaki kao=13 ]
「哎呀，还挺低的呢」[rhp]

[:himeko:]
「脸这么可怕肯定不受欢迎～」[rhp]

[:tiaki:]
「确实！面无表情虽然神秘感不错，但那仅限于二次元。[rhr]
_　现实中的男人第一第二都得看亲和力啦！」[rhp]

[off_all]

[chara_part name="take" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=13 as=off ss=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:]
「总之老师。今后请多关照！」[rhp]

[:takeru:][p_tk_04][take kao=8 ]
「…………完全不明白这是什么状况」[rhp]

[:tiaki:][p_mk_11][tiaki kao=7 ]
「哎呀呀。怎么有点不高兴。是拉炮不够热闹吗」[rhp]

[off_all]

[:tiaki:][tiaki kao=13 ]
「好啦孩子们！再来一发怎么样～！？」[rhp]

[::]kids 「耶——！！」[rhp]

[off_all]

[:takeru:][p_tk_21][take kao=6 ]
「真的不用了！」[rhp]

[off_all]

;****************************************
#
[bg storage="hsps_01.jpg" time=500]
;****************************************

这家临终关怀院里，住着来自主楼儿科病房的[rhr]
有人会因喜欢这边的设备和建筑而选择搬来。[rhp]
作为临终医疗场所，居住空间的投入资金比主楼更多，[rhr]
据说主要是那些能准备相当一笔钱财的阶层人士的孩子。[rhp]
一楼基本都被这些住户的病室所占据，[rhr]
从一开始就希望接受缓和医疗的患者则住在二、三楼。[rhp]
缓和医疗由传统的工作人员负责业务，[rhr]
而一楼致力于治疗疾病的孩子们必须接受与主楼相同的诊疗。[rhp]
前任医生大约一年后就辞职了。[rhr]
当然不是强制，是自愿的。[rhp]
……而接替他的人，就是我。[rhp]

;****************************************
[bg storage="hsps_03.jpg" time=500]
;****************************************

[:takeru:]
[font color=0x4682b4]
（可恶……！为什么会变成这样……！？）[rhp]
[resetfont]

[::]
我是医科大学的首席毕业生，实习成绩也位居榜首，是优等生中的优等生。[rhp]
从实习医生直接在主楼工作并顺利积累资历，将来要么就任教授，[rhr]
要么开设个人医院，本该一帆风顺地度过医生生涯！[rhp]

[yurasu]
[se storage="hand_11.ogg"]

[chara_part name="take" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:takeru:][take kao=4 ]
「痛！」[rhp]

[:tiaki:][p_mk_09]
「真是的医生！您的表情太僵硬啦」[rhp]

[off_all]

[::]
这个莫名亢奋的护士也让人厌烦。[rhr]
就算是接任者，普通人会给上司肘击吗？难以置信。[rhp]

[chara_part name="take" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:takeru:]
「～～～～，……呃」[rhp]

[:tiaki:][p_mk_15][tiaki kao=1 ]
「初次见面。我是这里的主任护士大美贺千秋！」[rhp]

[:takeru:][p_tk_01][take kao=6 ]
「…………。您就是传闻中的」[rhp]

[off_all]

[::]
态度先不论，这么年轻就当上主任真是了不起。[rhr]
她在主楼时的存在感我多少有所耳闻。[rhp]
会跟随她而来的理由，说到底还是关于那个传闻……[rhp]

[:takeru:]
[font color=0x4682b4]
（……罢了，现在没必要特意打听）[rhp]
[resetfont]

[chara_part name="take" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:][p_mk_31]
「唔呼呼♡　叫我米卡亲就可以啦医生」[rhp]

[:takeru:][take kao=0 ]
「大美贺小姐。……不必办欢迎会了，尽快办理交接手续吧……」[rhp]

[:tiaki:][tiaki kao=2 as=on ]
「诶～～！怎么这样。[rhr]
_　我们可是从一个月前就开始一点点准备了哦？」[rhp]

[off_all]

[:tiaki:][tiaki kao=14 ]
「对吧，大家？」[rhp]

[:himeko:][hime2 kao=2 ]
「就是就是。难得和君这么起劲」[rhp]

[:tiaki:][tiaki kao=13 ]
「对吧！那个和近君居然破天荒地」[rhp]

[off_all]

[:takeru:][take kao=6 as=on ]
[font color=0x4682b4]
（到底哪个和近君啊……）[rhp]
[resetfont]

[off_all]

[:kazutika:][kazu kao=0 ]
「………………」[rhp]

[off_all]

[:takeru:][take kao=0 ]
[font color=0x4682b4]
（……是这个和近君吗？）[rhp]
[resetfont]

[off_all]

[:kazutika:][p_kz_30][kazu kao=4 ]
「啊」[rhp]

[:himeko:][hime2 kao=13 ]
「怎么了和君？」[rhp]

[:kazutika:][kazu kao=0 ]
「我刚发现，矢部这个姓的'部'字能读成'部门'的部？[rhr]
_　感觉超级不吉利啊」[rhp]

[off_all]

[:takeru:][p_tk_10][take kao=2 ]
「哈？」[rhp]

[off_all]

[chara_part name="take" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kazu" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="kazu" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:kazutika:]
「你肯定一直被人笑话吧，庸医老师」[rhp]

[:takeru:][take kao=2 ]
「什……！？」[rhp]

[:kazutika:][kazu kao=13 ]
「绝对是这样没错。好，庸医确诊～～」[rhp]

[off_all]

[:takeru:]
[font color=0x4682b4]
（到底怎么回事！？这群嚣张的小鬼……！？[rhr]
_　和主楼的小儿病房完全不一样！）[rhp]
[:takeru:]
（那边明明更安静守规矩。[rhr]
_　为什么症状更严重的这边反而更吵闹啊！）[rhp]
[resetfont]

[off_all]

[:tiaki:][p_mk_26][tiaki kao=11 ]
「真是的，大家都不行啦。别再捉弄老师了」[rhp]
[:tiaki:]
「老是这种态度的话，可不会被老师好好诊治哦？[rhr]
_　听说在主楼可是以极度认真优秀闻名的呢」[rhp]

[off_all]

[chara_part name="take" body=base kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:]
「是吧？老师！」[rhp]

[:takeru:][p_tk_09][take kao=5 ]
「…………。过奖了。不过是同届生太差劲而已」[rhp]
[:takeru:]
「平日里持续钻研的我，和那些在大学虚度光阴、[rhr]
_　只求及格就好的家伙们有差距是理所当然的」[rhp]

[:tiaki:][tiaki kao=12 as=on ]
「好、好可怕……，[rhp]

[off_all]

[:kazutika:][kazu kao=7 as=on ]
「人际关系要完蛋的样子」[rhp]

[off_all]

[:takeru:][take kao=4 ]
「唔！呜……才、才没有……」[rhp]
[:takeru:]
[font color=0x4682b4]
（这回事……）[rhp]
[resetfont]

[off_all]

[chara_part name="tiaki" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:][p_mk_19]
「……对、对了！来大家！[rhr]
_　今天要给老师送礼物对吧～？」[rhp]

[:himeko:][hime2 kao=4 ]
「对！差点忘了」[rhp]

[off_all]

[chara_part name="take" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:takeru:][p_tk_13][take kao=0 ]
「礼物……？」[rhp]

[:tiaki:][tiaki kao=1 ]
「听说是大家凑零花钱买的哟」[rhp]

[:takeru:][take kao=8 ]
「嘿欸……」[rhp]

[off_all]

[:himeko:][hime2 kao=13 ]
「给您～」[rhp]

[off_all]

[::]
递过来的是一件模仿绿色怪兽形状的存钱罐。[rhr]
身体上缠绕着缎带，大概是想表达这是份礼物的意思吧。[rhp]

[:himeko:][hime2 kao=13 ]
「今后请多指教！矢部医生！」[rhp]

[::]
格外明亮的少女说完后，其他孩子们也跟着说出同样的话。[rhp]
面对不知所措的我，她闪耀着笑容似乎期待着我接下来的回应。[rhp]

[:takeru:][p_tk_30]
「……这个，给我的？」[rhp]

[:himeko:]
「嗯！送给您！它叫冈萨雷斯哦」[rhp]

[:kazutika:][p_kz_15]
「不对啦~是冈萨雷斯亿世啦~」[rhp]

;****************************************
;カットイン終了
[s_freeimage layer="2" ]
;****************************************

[off_all]

[chara_part name="tiaki" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=11 as=off ss=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:himeko:]
「我和和君不能出门，所以就拜托妈妈去店里，」[rhr]
_　一边开着视频电话一起选的哟」[rhp]

[:tiaki:][tiaki kao=5 ]
「原来如此~所以前几天才来找我借手机啊」[rhp]

[:himeko:][hime2 kao=5 ]
「那可是存钱罐呢。存满五百日元硬币的话，就能变成一亿日元哟！」[rhp]

[off_all]

[:takeru:][take kao=0 as=on ]
[font color=0x4682b4]
（不，再怎么说也装不下那么多吧。顶多十万左右……）[rhp]
[resetfont]

[off_all]

[chara_part name="kazu" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="kazu" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:kazutika:][p_kz_06]
「真期待啊，夏威夷旅行」[rhp]

[:himeko:][hime2 kao=13 ]
「对吧～！」[rhp]

[off_all]

[chara_part name="take" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:takeru:]
「夏威夷？」[rhp]

[:himeko:][hime2 kao=1 ]
「对呀！米卡亲说过有一亿日元就能去夏威夷呢」[rhp]

[off_all]

[chara_part name="take" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:takeru:][p_tk_09]
「………您这人做事还真是各种随便呢」[rhp]

[:tiaki:][p_mk_22][tiaki kao=1 as=on ]
「因、因为梦想还是要远大点比较好嘛。十万日元太寒酸了…」[rhp]

[:takeru:][take kao=7 ]
「……，哎……算了……」[rhp]

[off_all]

[:takeru:]
「……………………」[rhp]

[off_all]

[:tiaki:][p_mk_17][tiaki kao=5 as=on ]
「或者说,大家该不会是因为想去夏威夷才选的吧？」[rhp]

[off_all]

[chara_part name="kazu" body=base kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="kazu" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=4 as=on hh=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:2nin:]
「……………………」[rhr]
「……………………」[rhp]

[off_all]
[chara_part name="take" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:][p_mk_27][tiaki kao=13 ]
「哎呀呀,果然是这样～。[rhr]
_　难怪最近总是听到度假胜地啊海水浴之类的话题呢」[rhp]
[:tiaki:][tiaki kao=14 ]
「真是一份美妙的礼物呢医生。[rhr]
_　这下只能用医生的私人存款带我们去夏威夷了呢……」[rhp]

[:takeru:][take kao=6 ]
「………………」[rhp]

[:tiaki:][tiaki kao=1 ]
「……医生？」[rhp]

[:takeru:][p_tk_27][take kao=3 ]
「……啊,不是……那个。[rhr]
_　这还是第一次收到患者送的礼物……,该怎么说呢」[rhp]
[:takeru:]
「………………真是令人开心啊」[rhp]

[:tiaki:][p_mk_13][tiaki kao=4 ]
「你是在哭吗？」[rhp]

[:takeru:][take kao=2 ]
「才、才没哭。你看错了」[rhp]

[off_all]

[chara_part name="take" body=base kao=3 as=off ss=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=4 as=off ss=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="kazu" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="kazu" layer="1" width="437" height="720" left="760" top="0" wait="true" time=150]

[:himeko:]
「泪腺意外地脆弱呢,矢部医生」[rhp]

[:takeru:][p_tk_04]
「是矢部……」[rhp]

[:kazutika:][p_kz_30][kazu kao=13 ]
「居然开心到像孩子一样哭出来,矢部医生」[rhp]

[:takeru:]
「所以说不是矢部是矢部……！」[rhp]

[off_all]

[chara_part name="take" body=base kao=2 as=os ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:][p_mk_31]
「能相处融洽真是太好了。[rhr]
_　今后还请多关照,矢部医生」[rhp]

[:takeru:][p_tk_21][take kao=2 ]
[font size=26]
「是矢部啊！！！」[rhp]
[resetfont]
[:takeru:][take kao=6 as=on ]
「…………咦？」[rhp]

[off_all]

[chara_part name="take" body=base kao=6 as=on hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="kazu" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="kazu" layer="1" width="437" height="720" left="760" top="0" wait="true" time=150]

[:himeko:][hime2 kao=14 ]
「你刚才说矢部了吧」[rhp]

[:takeru:][p_tk_11][take kao=0 as=on ]
「不、不是的。刚才那是，」[rhp]

[:kazutika:][kazu kao=14 ]
「请多指教矢部」[rhp]

[:takeru:][take kao=2 as=on ]
「喂！都说了不是啊！」[rhp]

[off_all]

[chara_part name="take" body=base kao=2 as=os ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:][p_mk_14]
「哎呀呀,医生真是大受欢迎呢」[rhp]

[:takeru:][take kao=8 ]
「呜……！　大美贺小姐也请帮我说点什么吧。[rhr]
_　我的话他根本不肯听」[rhp]

[:tiaki:][tiaki kao=11 ]
「这说明您深受爱戴。是好事」[rhp]
[:tiaki:]
「大家都看起来很开心。[rhr]
_　老师能来银河站真是太好了」[rhp]

[:takeru:][take kao=2 ]
「…………」[rhp]

[off_all]

[::]
如果留在主楼的话，或许能积累资历。[rhp]
在那种只靠数据诊断患者、优先记住上司名字的职场里，[rhr]
只要默默服从规则自然能获得相应地位，将来也能高枕无忧。[rhp]

[:takeru:]
[font color=0x4682b4]
（……但是……）[rhp]
[resetfont]

[::]
若是像那样抛弃医生理想随波逐流，[rhr]
就不会像今天这样被人举办欢迎会了。[rhp]

[:takeru:]
[font color=0x4682b4]
（………………这不挺好的吗）[rhp]
[resetfont]

[::]
晋升算个屁。派系算什么。[rhr]
全都是无聊透顶的东西。[rhp]
不治病救人还算什么医生。[rhr]
那些抛弃我和这些孩子的家伙，总有一天要让他们刮目相看。[rhp]
我要贯彻自己的理想。[rhp]

[chara_part name="take" body=base kao=2 as=os ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:takeru:][p_tk_04]
「……话说回来，大美贺小姐」[rhp]

[:tiaki:]
「嗯？」[rhp]

[:takeru:]
「闹得这么欢，对身体不太好吧。[rhr]
_　这里的准备工作应该也费了不少功夫」[rhp]

[:tiaki:][tiaki kao=5 as=on ]
「对、对不起……因为是庆祝活动，今天算是特殊情况」[rhp]

[:takeru:][take kao=12 ]
「从明天开始请严格遵循我的指示，遵守规定的自由活动时间。[rhr]
_　今后不仅要玩耍，还要请你们完成面向康复的训练和作业」[rhp]

[off_tiaki]

[chara_part name="hime2" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:himeko:][hime2 kao=6 ]
「诶！？之前的医生可是让我们玩个够的」[rhp]

[:takeru:][p_tk_09][take kao=2 ]
「现在哪有工夫沉迷于这种敷衍了事的快乐？[rhr]
_　想活命就忍着完成任务」[rhp]
[:takeru:]
「我来这儿可不是陪你们玩的。[rhr]
_　是为了让你们活下去才来的」[rhp]

[:himeko:][hime2 kao=1 ]
「……！」[rhp]

[:takeru:][take kao=0 ]
「我会把你们送回主楼……不，是送回家。[rhr]
_　在那之前就忍耐着吧」[rhp]

[off_all]

[:kazutika:][p_kz_04][kazu kao=8 ]
「………………。真的能回家吗？」[rhp]

[off_all]

[:takeru:][p_tk_15][take kao=5 ]
「交给我吧。我可是要成为名医的男人」[rhp]

[off_all]

[chara_part name="take" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=4 as=off ss=off hh=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:himeko:]
「矢部医生……」[rhp]

[:takeru:]
「这个称呼也给我改过来！」[rhp]
[:takeru:]
「…………今天破例就不追究了」[rhp]

[:himeko:][hime2 kao=1 ]
「……！！那可以继续开派对了吗？」[rhp]

[:takeru:][take kao=12 ]
「最多再玩一小时。结束后都回房休息」[rhp]

[:himeko:][hime2 kao=13 ]
「好～！」[rhp]

[off_all]

[:kazutika:][kazu kao=5 ]
「……噗！矢部大叔，年纪一大把还害羞啊」[rhp]

[:takeru:][take kao=1 ]
「谁先学会尊敬长辈就带谁去夏威夷」[rhp]

[:kazutika:][kazu kao=4 as=on ]
「啥！？」[rhp]

[off_all]

[:takeru:][take kao=5 ]
「………………，哼」[rhp]

[off_all]

;****************************************
#
[bg storage="sky_06.jpg" time=1000]
;****************************************


[::]
真是的……刚上任就责任重大啊。[rhp]
不过，有意思。[rhp]

[:takeru:]
[font color=0x4682b4]
（就大干一场吧）[rhp]
[resetfont]

[::]
哪怕前路险阻。[rhp]
我所追求的理想姿态，一定就在前方某处。[rhp]

;****************************************
[fbgm]
[set_b storage="hsps_04.jpg"]
[bgm storage="bgm_07.ogg"]
;****************************************

[::]
帮忙收拾完大厅后，我来到员工站。[rhp]
例行值班的护士们简单打招呼并说明房间用途后，[rhr]
我走向医务室，坐在屋内摆放的简易沙发上。[rhp]

[:takeru:]
「哈…………」[rhp]

[::]
充满成就感的疲惫，与些许后悔。[rhp]
……我头一次在别人面前如此夸下海口。[rhr]
虽然是真心话，但说什么『要成为名医』……实在是相当羞耻的家伙啊。[rhp]

[:takeru:][p_tk_31][take kao=3 as=on ]
「……虽说是因为礼物太感动才失态，但自己也觉得太轻率了！[rhr]
_  必须更加振作才行……！」[rhp]

[off_all]

[:tiaki:][p_mk_20][tiaki kao=13 ]
「哎呀。我本来觉得您很坦率呢」[rhp]

[off_all]

[chara_part name="take" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:takeru:]
「哇！大、大美贺小姐您在这儿啊」[rhp]

[:tiaki:][p_mk_31][tiaki kao=14 ]
「当然在呀。还没到下班时间呢」[rhp]
[:tiaki:]
「医生。今天您能陪我，真的非常感谢」[rhp]

[:takeru:][p_tk_04][take kao=3 ]
「不，我才是要谢谢您举办这样的活动。[rhr]
_  我第一次经历这种场面，有点吃惊呢」[rhp]

[:tiaki:][tiaki kao=4 ]
「在主楼没有过这种活动吗？[rhr]
_  您实习期是在儿科吧」[rhp]

[:takeru:]
「和孩子们接触的只有护士。[rhr]
_  我们医生除了看诊几乎不露面」[rhp]
[:takeru:][take kao=5 ]
「……所以今天，我很开心」[rhp]

[:tiaki:][tiaki kao=13 ]
「那就好。其实那个啊，是孩子们说想办的」[rhp]

[:takeru:][take kao=4 ]
「孩子们……？」[rhp]

[:tiaki:][p_mk_17][tiaki kao=8 ]
「您可能已经知道了……这家临终关怀院只有1名常驻医生，[rhr]
_　休息日都是从主楼借调人手的吧？」[rhp]

[:takeru:][take kao=7 ]
「嗯，确实有所耳闻。这有什么问题吗」[rhp]

[:tiaki:][tiaki kao=5 ]
「我说医生啊。您知道前任为什么辞职吗？」[rhp]

[:takeru:][take kao=0 ]
「不。详细情况」[rhp]

[:tiaki:][tiaki kao=3 ]
「……听说是因为害怕孩子们」[rhp]
[:tiaki:]
「和普通临终关怀院不同，这里是专门收治孩子的。[rhr]
_　不是所有孩子都能察觉自己大限将至，做好心理准备的」[rhp]
[:tiaki:]
「他说死亡明明近在咫尺，孩子们却还能若无其事地笑着，实在令人害怕」[rhp]

[:takeru:][take kao=3 ]
「……考虑到这家机构的特殊性，这倒也无可厚非」[rhp]

[:tiaki:][p_mk_01]
「是啊。这点他也心知肚明。[rhr]
_　所以最后反反复复说了好多次对不起」[rhp]
[:tiaki:]
「正因为是这样的人，临终时没让我们办告别会。[rhr]
_　说自己这种人不配」[rhp]
[:tiaki:]
「孩子们似乎非常失落。所以这次的迎新会，[rhr]
_　他们干劲十足地说要连前任医生那份一起热闹庆祝呢」[rhp]

[:takeru:][take kao=1 ]
「原来如此。难怪这么卖力」[rhp]

[:tiaki:][tiaki kao=13 ]
「哎呀，不过也不仅是这样啦」[rhp]
[:tiaki:
「医生，听说您在主楼可是个名人呢。[rhr]
『无法出人头地的优等生大人』对吧？」[rhp]

[:takeru:][p_tk_02][take kao=5 as=on ]
「…………您知道得真清楚。虽然确实如此」[rhp]
[:takeru:][p_tk_02][take kao=7 ]
「似乎因为您提出了削减『接待费』这类浪费开支的提案，惹得上面不太高兴。[rhr]
_　回过神来时，调令就从研修地的主楼儿科病房下来了」[rhp]
[:takeru:]
「真是抱歉啊。继任者竟是像我这样讨人厌的怪脾气……」[rhp]

[:tiaki:][p_mk_31][tiaki kao=13 ]
「哪儿的话。我很高兴，真的」[rhp]

[:takeru:][take kao=3 ]
「……诶」[rhp]

[:tiaki:][tiaki kao=1 ]
「听说您是这样的人，我反而放心了。[rhr]
_　孩子们需要的，是能真诚对待他们的医生」[rhp]

[:takeru:][take kao=4 ]
「大美贺小姐……」[rhp]

[:tiaki:][tiaki kao=13 ]
「再说医生您现在处境很艰难吧！[rhr]
_　像您这样的人肯定会拼命工作的！」[rhp]

[:takeru:][take kao=5 as=on ]
「哈哈……是、是啊……虽然心情有点复杂……」[rhp]

[:tiaki:][tiaki kao=11 ]
「啊。顺便问下，不用确认我的『传闻』吗？」[rhp]

[:takeru:][take kao=7 ]
「不必了。……和医疗现场无关的事」[rhp]

[:tiaki:][tiaki kao=4 ]
「哎呀……」[rhp]
[:tiaki:][tiaki kao=14 ]
「……呵呵！感觉和医生您一定能相处得很好呢」[rhp]

[:takeru:][p_tk_15][take kao=1 ]
「那就好」[rhp]
[:takeru:]
「……虽有不周之处，今后还请多多指教」[rhp]

[:tiaki:][tiaki kao=13 ]
「彼此彼此。让我们同心协力吧」[rhp]

[off_all]

;****************************************
#
[bg storage="sky_07.jpg" time=1500]
;****************************************

……那时真美好。[rhp]
充满希望的日子。[rhr]
曾经充满自信。[rhp]
所以对自己的能力深信不疑。[rhp]

;****************************************
[fbgm]
[bg storage="black.jpg" time=1500]
;****************************************

……真想痛揍当时的自己。[rhp]
不知道有些事仅靠自信是无法实现的。[rhr]
当时实在太过年轻。若能更早明白，或许会有所不同吧。[rhp]
…………我真是太天真了。[rhp]

;****************************************
[set_n storage="hsps_05n.jpg"]
[bgm storage="bgm_09.ogg"]
;****************************************

赴任一年后。[rhp]
担任孩子领袖的八云君去世了。[rhp]
自八云君死后，接连有人离世。[rhp]
在八云君去世又过一年后。[rhr]
曾为我举办欢迎会的伊东君也离世了。[rhp]

……伊东君的死对我而言是重大打击。[rhp]

[:takeru:]
「……………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:tiaki:][tiaki kao=3 ]
「…………老师。差不多该回去了」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:takeru:][take kao=3 as=on ]
「……………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[:tiaki:][tiaki kao=8 as=on ]
「……老师」[rhp]

[off_all]

;****************************************
;スチル
[still storage="cg/b2_2.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/b2_2.png"]
;****************************************

[:takeru:]
「…………伊东君他……」[rhp]
[:takeru:]
「伊东君临终前这样说道……」[rhp]
[:takeru:]
「…………『终于结束了』」[rhp]

[:tiaki:]
「…………！」[rhp]

[:takeru:]
「他明明和朋友们相处得那么融洽。[rhr]
_　病情稳定到还能和我开玩笑的程度」[rhp]
[:takeru:]
「明明为了让他多活一天，已经竭尽所能了……」[rhp]

[:tiaki:]
「……我知道」[rhp]

[:takeru:]
「虽不指望能在这种地方笑着迎接终末……」[rhp]
[:takeru:]
「可…………渴望终结什么的，太过分了……」[rhp]

[:tiaki:]
「那个孩子最后在想什么……那个孩子的痛苦[rhr]
_　能理解的只有背负着相同重担的孩子」[rhp]
[:tiaki:]
「让我们也为他做点其他孩子能受益的事吧。[rhr]
_　……根本没空钻牛角尖呢」[rhp]
[:tiaki:]
「医生的护理无可挑剔。所以……」[rhp]

[:takeru:]
「难道要归咎于神明吗？」[rhp]

[:tiaki:]
「……！」[rhp]

[:takeru:]
「…………愚蠢至极」[rhp]
[:takeru:]
「让无罪的孩子受苦至此的世界怎么可能存在神明」[rhp]
[:takeru:]
「倘若真有那种东西存在的话[rhr]
_　他们早该得到救赎了不是吗」[rhp]

[:tiaki:]
「……可是……」[rhp]

[:takeru:]
「…………难道是我错了吗」[rhp]
[:takeru:]
「说什么治愈需要送进临终关怀院的病人……[rhr]
_　……我是不是太自以为是了」[rhp]

[:tiaki:]
「医生的热忱千真万确。既非错误也非自负」[rhp]

[:takeru:]
「但迄今为止我什么都没能为他们做到。[rhr]
_　止痛治标却遏制不了病情恶化」[rhp]
[:takeru:]
「每当目送一个个生命离去时 我就……[rhr]
_　……因自己的无能而想寻死」[rhp]

[:tiaki:]
「医生……！　请不要这么想更别说出来」[rhp]

;****************************************
#
[bg storage="cg/b2_2b.png" width="1280" height="720" time=500]
[cg storage="cg/b2_2b.png"]
;****************************************

[:takeru:]
「那你告诉我该怎么办？[rhr]
_　对那些因我而燃起希望的孩子们 现在还能说什么？」[rhp]
[:takeru:]
「他们应该早就察觉到了。[rhr]
_　我终究只是嘴上逞强，什么都做不到啊！」[rhp]
[:takeru:]
「我……呃……根本就是，名副其实的庸医……！」[rhp]

[:tiaki:]
「怎么会……」[rhp]

[:takeru:]
「……每当有孩子离去时，就会想起那时候的事」[rhp]
[:takeru:]
「已经不想干了。受够了」[rhp]
[:takeru:]
「………………为何我要承受这种痛苦……」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
;スチル終了

#
[s_mask color=0x000000 time=3000]
; 背景表示
[bg storage="hsps_07n.jpg" time=100]
; ウィンドゥの設定
[position layer="message0" frame="win2.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[s_mask_off time=3000]

;****************************************

[:yoru:][yoru kao=0 ]
「……………………」[rhp]

[off_yoru]

[::]
在医务室门前，听到了他们的全部对话。[rhp]
……矢部尊。[rhr]
是个严于律己也严于律人，有着崇高理想的新人儿科医生。[rhp]
一年前他刚来时，还以为来了个优秀的人才……[rhp]

[:yoru:]
[font color=0x4682b4]
（……就这么定了）[rhp]
[resetfont]

[::]
如果要找人帮忙，只能是他了。[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

;****************************************
;スチル
[still storage="cg/b2_2.png" rule="007.png" width="1280" height="720" time=1000]
;****************************************

[:takeru:]
「…………抱歉。大美贺小姐」[rhp]
[:takeru:]
「我决定要离开这家医院了」[rhp]

[:tiaki:]
「哎……！？」[rhp]

[:takeru:]
「……星名小姐的哭声一直在脑海里挥之不去」[rhp]
[:takeru:]
「那么活泼开朗的孩子，今天连一顿饭都没吃。[rhr]
_　营养点滴也没有反应。……平时明明最讨厌打针的」[rhp]
[:takeru:]
「伊东君也是那样。自从八云君去世后就像变了个人似的消沉下去，[rhr]
_　身体越来越差……最后那年，伊东君连轮椅都坐不了了」[rhp]
[:takeru:]
「……只会加速剥夺他人生命，算什么医生……」[rhp]

[:tiaki:]
「等等！那绝不是你的责任，」[rhp]

;****************************************
#
[bg storage="cg/b2_2b.png" width="1280" height="720" time=500]
;****************************************

[:takeru:]
「如果不是我的错那该是谁的责任！？」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:tiaki:]
「―――！」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:takeru:]
「……！　对不起……」[rhp]

[:takeru:]
「可是……我……是我的能力不足。终究还是我的责任」[rhp]
[:takeru:]
「就算我留在这里，也救不了任何人……[rhr]
_　既然如此，不如换成其他什么人……」[rhp]

[fbgm]

;****************************************@
#
[bg storage="black.jpg" time=500]
;****************************************@

[:yoru:]
「―――你太小看自己了」[rhp]

;****************************************@
[still_end frame="win2.png" storage="hsps_05n.jpg" time=1000]
;****************************************

[chara_part name="take" body=base kao=4 as=on ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=7 as=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:takeru:]
「………？　大美贺小姐？」[rhp]

[:tiaki:][tiaki kao=4 as=on ]
「不、不是我。这个声音究竟是……」[rhp]

[off_all]
[:yoru:][yoru kao=0 ]
「晚上好」[rhp]

[off_all]

[bgm storage="bgm_36.ogg"]

[chara_part name="take" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=4 as=on ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:takeru:]
「――――！！」[rhp]

[:tiaki:][tiaki kao=3 4 as=on ]
「谁、谁在那里！？」[rhp]

[off_all]

[:yoru:][yoru kao=7 ]
「是《糠星夜》」[rhp]

[off_all]

[:tiaki:][tiaki kao=7 ]
「……糠星的、那个……那幅画的标题……」[rhp]

[off_all]

[:yoru:][yoru kao=0 ]
「没错。我寄宿在那幅画里，按照你们的说法就是付丧神」[rhp]

[off_all]

[:tiaki:][tiaki kao=3 as=on ]
「…………难以置信。神明什么的，怎么可能……」[rhp]

[off_all]

[:yoru:][yoru kao=12 ]
「……虽然我没有你们期待的那种力量……」[rhp]

[off_all]

;****************************************
;魔法
[se storage="mag_03.ogg"]
#
[bg_rule storage="white.jpg" rule="027.png" time=1500]
;****************************************

[:tiaki:]
「……！？　什么……！？」[rhp]

;****************************************
#
[bg storage="sky_07p.jpg" time=1500]
;****************************************

[:takeru:][take kao=2 as=on ]
「……诶……」[rhp]

[off_all]

[chara_part name="take" body=base kao=0 as=on hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:takeru:]
「怎、怎么回事！？　这到底……！」[rhp]

[:yoru:]
「空间并未改变。只是调整了你的视觉范围」[rhp]
[:yoru:][yoru kao=0 ]
「……以我现在的力量只能做到这种程度，[rhr]
_　现在愿意相信我说的话了吗」[rhp]

[off_all]

[chara_part name="tiaki" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:tiaki:]
「……你真的是神明大人……？」[rhp]

[:yoru:][yoru kao=12 ]
「正是。我长久以来一直注视着你们。[rhr]
_　……你们的理想与遗憾，所有一切」[rhp]

[:tiaki:][tiaki kao=3 as=on ]
「…………呃」[rhp]

[off_all]

[:takeru:][take kao=3 as=on ]
「那、那就拜托了。那个叫糠星夜的东西！」[rhp]
[:takeru:]
「希望你能让孩子们复活！[rhr]
_　不要求全部人，至少―――」[rhp]

[off_all]

[chara_part name="take" body=base kao=3 as=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:yoru:]
「从两方面来说那都办不到」[rhp]

[:takeru:][take kao=8 ]
「……！为什么啊。你不是神明吗？」[rhp]

[:yoru:][yoru kao=7 ]
「其一。我并没有让死者复活的力量。[rhr]
_　……或者说，这个世界所有的付丧神应该都不具备这种力量」[rhp]
[:yoru:]
「灵魂是循环之物。强留逝去的魂魄毫无益处」[rhp]

[off_all]

[chara_part name="tiaki" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:tiaki:][tiaki kao=1 ]
「第二个理由呢？」[rhp]

[:yoru:][yoru kao=6 ]
「因为他们的魂魄，至今仍滞留此处」[rhp]

[off_all]

[chara_part name="take" body=base kao=0 as=on ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:takeru:]
「什么意思？你是说他们的灵魂……还留在这里？」[rhp]

[:yoru:][yoru kao=8 ]
「正是」[rhp]
[:yoru:]
「……像我这般非人之物，通常唯有濒死之人才能感知。[rhr]
_　那是由于灵魂开始脱离肉体准备，从而更接近灵体存在的缘故」[rhp]
[:yoru:]
「而今刻意现形于你们面前，不为别的……」[rhp]
[:yoru:]
「…………我有件要事想请你们帮忙」[rhp]

[:takeru:][take kao=3 ]
「帮忙……？」[rhp]

[:yoru:][yoru kao=6 ]
「希望你们能……将他们从那里解放出来」[rhp]

[:takeru:][take kao=4 as=on ]
「…………啊」[rhp]

[:yoru:][yoru kao=6 ]
「由于被主谋者戒备，[rhr]
_　几乎失去力量的我已无法涉足那个领域」[rhp]
[:yoru:]
「但要我善良到等待他们做好前往彼世的准备，[rhr]
_　我可没那么慈悲」[rhp]
[:yoru:]
「就在那家伙犯蠢的时候，[rhr]
_　会把这些孩子的灵魂随意玩弄于股掌之间吧」[rhp]
[:yoru:]
「简直就像玩娃娃一样。[rhr]
_　……实在不能容忍」[rhp]

[off_all]

[:tiaki:][tiaki kao=2 ]
「等、等一下。我完全听不懂。[rhr]
_　你说孩子们的灵魂在这里……」[rhp]

[off_all]

[:yoru:][yoru kao=12 ]
「现在详细说明。[rhr]
_　虽然荒唐无稽但请听到最后」[rhp]
[:yoru:]
「……说实话，我也懒得解释」[rhp]

[off_all]

[::]
我向两人讲述了八云博士和他朋友的浮游灵的事、[rhr]
在矢部尊指示下制作的千纸鹤像我一样寄宿着付丧神的事、[rhr]
以及身为作者的他们死后，千纸鹤采取的全部行动。[rhp]
起初他们面露狐疑，但因大美贺千秋曾目睹八云博士在无人房间自言自语的情形，[rhr]
最终勉强获得了他们的信任。[rhp]

[:yoru:][yoru kao=12 ]
「八云博士的灵魂不在我体内。不如说正是为了阻止灵魂逃逸，[rhr]
_　才给整个医院施加了大型诅咒」[rhp]
[:yoru:]
「让所有在此死去之人的[rhr]
_　灵魂都被吸入我体内的，最恶劣的魔法」[rhp]

[off_all]

[:tiaki:][tiaki kao=6 ]
「难、我们也会变成那样？」[rhp]

[off_all]

[:yoru:][yoru kao=0 ]
「给那家伙提供过哪怕一只千纸鹤的人……[rhr]
_　若是托付了愿望的话，或许」[rhp]

[off_all]

[chara_part name="take" body=base kao=12 as=on hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=0 as=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:]
「………………一口气做了好多呢」[rhp]

[:takeru:][take kao=7 ]
「我也是……」[rhp]

[off_all]

[:yoru:][yoru kao=1 ]
「没关系。倒不如说，你们做了真是帮大忙了」[rhp]
[:yoru:]
「希望你们能用那个前往银河铁道的世界」[rhp]

[off_all]

[:takeru:][take kao=8 ]
「诶」[rhp]

[off_all]

[:yoru:][yoru kao=0 ]
「希望你们代替我去银河铁道，解救被困在里面的孩子们」[rhp]
[:yoru:]
「方法很简单。只要说服他们，让他们放弃旅程就好。[rhr]
_　因为那里是为了实现他们的愿望而创造的世界」[rhp]

[:tiaki:][tiaki kao=3 ]
「即便如此……那里不是人死后才会去的地方吗。[rhr]
_　你是要我们去死吗？」[rhp]

[:yoru:][yoru kao=5 ]
「我会让你们进入假死状态。[rhr]
_　这点程度的话，靠我这残余的灵力也能轻松办到」[rhp]

[:tiaki:][tiaki kao=4 ]
「蛤……！？怎、怎么做到这种」[rhp]

[:yoru:][yoru kao=7 ]
「是魔法。更多的就无法解释了」[rhp]

[off_all]

[chara_part name="take" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:takeru:]
「…………结束旅程，从画中世界出来后会发生什么」[rhp]

[:yoru:][yoru kao=12 ]
「我说过了，灵魂是循环的。[rhr]
_　只会作为完全不同的人获得新生罢了」[rhp]

[:takeru:][take kao=8 ]
「也就是说轮回转世吗」[rhp]

[:yoru:][yoru kao=2 ]
「做还是不做。我只想知道这个」[rhp]

[:takeru:][take kao=3 ]
「……可、可是……总觉得太不真实了……」[rhp]

[off_all]

[:tiaki:][tiaki kao=13 ]
「我来做」[rhp]

[off_all]

[:takeru:][take kao=8 ]
「大美贺小姐？」[rhp]

[off_all]

[chara_part name="tiaki" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:tiaki:]
「呵呵。画中世界究竟有多么有趣呢？真令人期待呀」[rhp]
[:tiaki:]
「在那般狭小的空间持续停留是否值得，[rhr]
_　我打算亲眼去确认」[rhp]

[:yoru:][yoru kao=12 ]
「……好吧」[rhp]

[:tiaki:][tiaki kao=13 ]
「谈判成立呢。请多指教」[rhp]

[:yoru:]
「啊啊。我很期待」[rhp]

[off_all]

[chara_part name="take" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=4 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:yoru:][yoru kao=0 ]
「…………武。你呢？」[rhp]

[:takeru:][take kao=3 as=on ]
「…………、……我也去」[rhp]

[:yoru:][yoru kao=6 ]
「若有犹豫不妨退出。千秋意外地看起来能独当一面」[rhp]

[:takeru:][take kao=2 ]
「怎么可能犹豫」[rhp]
[:takeru:]
「让患者活下去就是我的工作」[rhp]

[off_all]

[:tiaki:][tiaki kao=4 ]
「老师……」[rhp]

[off_all]

[:yoru:][yoru kao=1 ]
「………………是吗」[rhp]

[off_all]

[chara_part name="tiaki" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="take" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="650" top="0" wait="true" time=150]

[:takeru:]
「但出发请稍等。[rhr]
_　这将是漫长旅途，还有堆积如山的工作需要处理」[rhp]

[:tiaki:][tiaki kao=2 ]
「我也是呢。得做好各种安排，期间还要物色能托付的工作人员……」[rhp]

[:yoru:]
「没问题。作战启动是在三年后」[rhp]

[:takeru:][take kao=2 ]
「哈？三……三年后！？」[rhp]

[:tiaki:][tiaki kao=3 as=on ]
「那么久远吗？」[rhp]

[:yoru:][yoru kao=3 ]
「将临终关怀院创立以来十年间积蓄未用的灵力[rhr]
_　尽数注入千纸鹤，才形成了那条银河铁道」[rhp]
[:yoru:]
「如今我以这副姿态现身已是极限。[rhr]
_　根本没有带你们前往彼界的力量」[rhp]

[:takeru:][take kao=6 ]
「完全恢复至能实现此事的状态需要三年」[rhp]

[:yoru:][yoru kao=2 ]
「没错。……而且，我也没打算进行长途旅行。[rhr]
_　这里要是没有你们在会很困扰吧」[rhp]
[:yoru:]
「载着他们的银河铁道，每周会进行一次大规模旅行。[rhr]
_　届时他们会下铁道，我们要抓住那个空隙」[rhp]
[:yoru:]
「每次旅行只需盯住一晚。届时集中发动攻势」[rhp]

[:tiaki:][tiaki kao=1 ]
「情况我了解了。但等待的时间实在太过……」[rhp]

[:yoru:][yoru kao=8 ]
「焦躁我懂，但操之过急导致失败必须避免。[rhr]
_　说到底现在进行这段对话时，就已经是种失败」[rhp]
[:yoru:]
「反正要等，不如等三年后准备万全时再行动。[rhr]
_　……我也一样在焦躁」[rhp]

[:tiaki:][tiaki kao=12 ]
「糠星先生……」[rhp]

[:yoru:][yoru kao=1 ]
「叫夜就好」[rhp]
[:yoru:]
「……总之。希望你们趁这段时间让孩子们牢记，[rhr]
_　不要被千纸鹤的甜言蜜语迷惑心智」[rhp]
[:yoru:]
「梦想不是用来空想的，更不该指望他人来实现」[rhp]
[:yoru:]
「要凭自己的双手去夺取」[rhp]

[:tiaki:][tiaki kao=13 ]
「………。没想到是个热血系呢」[rhp]

[:yoru:][yoru kao=12 ]
「只是陈述事实。……拜托你们了」[rhp]

[:tiaki:][tiaki kao=14 ]
「明白了」[rhp]

[:takeru:][take kao=1 ]
「交给我们吧」[rhp]

[:yoru:][yoru kao=1 ]
「呵……真可靠」[rhp]

[off_all]

[:yoru:]
「………………那么，三年后见」[rhp]

;****************************************
;消えるヨル
[bg_magic storage="hsps_02m.jpg"]
;****************************************

刚感觉视野再次暗下来，[rhr]
下一秒就已经回到原来的入口处。[rhp]
面对眼前难以置信却又不得不信的境况，[rhr]
我和大美贺小姐久久僵立无言。[rhp]

[chara_part name="take" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:takeru:]
「……………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:tiaki:][tiaki kao=0 ]
「……这不是梦对吧」[rhp]
[:tiaki:]
「夜君也……关于大家都说在这幅画里的传闻……」[rhp]

[:takeru:][take kao=8 ]
「……他看起来不像在说谎」[rhp]

[:tiaki:][tiaki kao=13 ]
「是啊。……这样啊……」[rhp]

[off_all]

;****************************************
#
[bg storage="cg/b2_1n.png" time=1000]
;****************************************

[:tiaki:]
「……大家。原来一直都在我们身边啊……」[rhp]

[:takeru:]
「不管那里是什么地方，我都会把他们带出来的」[rhp]

[:tiaki:]
「没关系的。说舍不得什么的……[rhr]
_　我并不是那个意思」[rhp]

[off_all]

;****************************************
#
[bg storage="hsps_02m.jpg" time=1000]
;****************************************


[chara_part name="take" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:]
「…………三年后。一起加油吧老师」[rhp]

[:takeru:][take kao=5 ]
「嗯。在那之前就尽力而为吧。[rhr]
_　毕竟孩子们所在的地方，不只有画中世界啊」[rhp]

[:tiaki:]
「是。老师！」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
[fbgm]
[set_ff storage="hsps_02m.jpg"]
;****************************************

深夜―――[rhp]

[bgm storage="bgm_35.ogg"]

[font color=0x696969]
『在那之前就尽力而为吧。[rhr]
_　毕竟孩子们所在的地方，不只有画中世界啊』[rhp]
『是。老师』[rhp]
[resetfont]

[::]
忽然想起方才他们在医院里的对话。[rhp]

;****************************************
[s_mask color=0x000000 time=3000]
[se storage="mag_03.ogg"]
; 背景表示
[bg storage="train_05.jpg" time=100]
; ウィンドゥの設定
[position layer="message0" frame="win.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[s_mask_off time=3000]
;****************************************

[:sausu:][sausu kao=3 ]
「真奇怪……实在太奇怪了。完全无法理解」[rhp]
[:sausu:]
「明明我只是在实现大家的愿望而已。[rhr]
_　可是为什么约尔大人要这样把我当成坏人呢」[rhp]

[off_all]

[:sausu:][p_s_04]
「…………呐？你怎么想？[rhp]

[:drop:][p_d_17][drop kao=8 ]
「南……又要说那个话题吗？」[rhp]

[off_all]

[chara_part name="drop" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sausu:]
「呀多洛普。进展如何」[rhp]

[:drop:][p_d_36][drop kao=1 ]
「很顺利哦。现在正让他在周边打招呼」[rhp]

[:sausu:][p_s_27][sausu kao=14 ]
「这样啊。不愧是多洛普。继续拜托了」[rhp]

[:drop:][drop kao=5 ]
「嗯，请交给我吧」[rhp]
[:drop:]
「……话说回来，那个……刚才似乎提到了夜的事情」[rhp]

[:sausu:][p_s_30][sausu kao=8 ]
「啊……其实呢。[rhr]
_　看样子约尔大人似乎非常生气」[rhp]

[:drop:][drop kao=0 ]
「是因为你的计划吗？」[rhp]

[:sausu:][p_s_22][sausu kao=7 as=on ]
「没错。就像我把你们拉为同伴那样，他也开始组建自己的伙伴」[rhp]
[:sausu:]
「三年后……当他们正式准备毁灭这个世界时。[rhr]
_　那时候或许真的不得不与约尔大人对抗了」[rhp]

[:drop:][p_d_22][drop kao=3 ]
「要是双方能互相理解，友好相处就好了呢……」[rhp]

[:sausu:][sausu kao=8 as=on ]
「是啊。这种状况实在太荒唐了……」[rhp]

[off_all]

;****************************************
#
[bg storage="sky_11.jpg" time=500]
;****************************************

[:sausu:]
「为什么他要拒绝这个能让所有人都幸福的世界。[rhr]
_　明明大家都带着笑容，说很高兴能待在这里」[rhp]
[:sausu:]
「虽说旅途中也有孩子心满意足地中途下车。[rhr]
_　但那并不是因为他们认为这个世界是错误的」[rhp]
[:sausu:]
「因为这趟银河铁道的旅程，让我找到了真正的幸福」[rhp]
[:sausu:]
「…………不了解他们的人，恐怕是约尔大人您吧」[rhp]

;****************************************
#
[bg storage="train_05.jpg" time=500]
;****************************************


[chara_part name="drop" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:drop:]
「………………」[rhp]

[:sausu:][p_s_34][sausu kao=1 ]
「哎呀呀，好像有点抱怨的味道了呢。[rhr]
_　毕竟有些事不吐不快啊」[rhp]

[:drop:][drop kao=5 ]
「没关系的。偶尔这样」[rhp]

[:sausu:][sausu kao=13 ]
「多洛普真温柔呢。到底像谁呀」[rhp]

[:drop:][drop kao=11 ]
「不可能像任何人。我只是……」[rhp]

[:sausu:][p_s_32][sausu kao=0 ]
「不过是个玩偶罢了」[rhp]

[:drop:][drop kao=3 as=on ]
「…………！」[rhp]

[:sausu:][sausu kao=7 as=on ]
「……抱歉。今天我真是反常。[rhr]
_　本不想说这些带刺的话」[rhp]

[:drop:][p_d_17][drop kao=3 ]
「若是对夜有所不满，不如干脆避免碰面[rhr]
_　和我们一起旅行如何？」[rhp]
[:drop:]
「这样既不用听唠叨，也能平静度日……」[rhp]

[:sausu:][p_s_33][sausu kao=8 ]
「那可不行。那边还有每日功课」[rhp]
[:sausu:]
「例行巡视所有车厢。闲暇时待在人来人往的休息室。[rhr]
_　这是博士去世后我一直坚持的事」[rhp]

[:drop:][drop kao=3 as=on ]
「为何要做到这种程度……？[rhr]
_　普通人不是看不见你吗？」[rhp]

[:sausu:][p_s_31][sausu kao=14 ]
「没错。正因如此，才能在命数将近时[rhr]
_　尽早注意到那些突然能看见我的孩子」[rhp]
[:sausu:]
「早点成为朋友的话 就能帮忙实现更多愿望啦」[rhp]

[:drop:][p_d_10][drop kao=1 ]
「？　但不是说只有折千纸鹤时的愿望才有效吗……」[rhp]

[:sausu:][sausu kao=13  ]
「啊哈哈！你觉得我是那种心胸狭隘的神明吗？」[rhp]
[:sausu:]
「没折过鹤的孩子也好 后来愿望变多的孩子也好 全都热烈欢迎。[rhr]
_　总之我想尽全力实现每个人的愿望」[rhp]
[:sausu:]
「要是在那时帮他实现就好了......因为不想留下遗憾啊」[rhp]

[:drop:][drop kao=13 ]
「…………这样啊。我觉得很了不起」[rhp]

[:sausu:][p_s_16][sausu kao=5 ]
「对吧？这些心意也都是博士教会我的」[rhp]
[:sausu:]
「......博士让我变得强大 无论这份强大是好是坏。[rhr]
_　多亏如此 现在的我才能成为实现大家愿望的人」[rhp]
[:sausu:]
「要是博士也能来到这里 肯定早就是值得信赖的兄长了。[rhr]
_　正因那个愿望没能实现 我才要替大家实现所有愿望」[rhp]

[:drop:][drop kao=1 ]
「原来如此......达克内布拉博士的声望[rhr]
_　或许很大程度上是受到南强烈情感的影响呢」[rhp]

[:sausu:][sausu kao=3 ]
「......这主要归功于沃尔佩克拉陪在他身边。[rhr]
_　我几乎没有干涉过『达克内布拉博士』的事」[rhp]
[:sausu:]
「光是看见他的模样就令我痛苦......最初虽然交谈过几次[rhr]
_　后悔与怀念之情，总让胸口隐隐作痛……之后几乎再未相见」[rhp]
[:sausu:]
「……很过分吧。明明是我因自私而创造的孩子」[rhp]

[:drop:][drop kao=3 ]
「不会。……但总有一天，希望你能与他[rhr]
_　笑着交谈的日子会到来」[rhp]
[:drop:]
「以八云博士为原型创造的他，[rhr]
_　不可能不想见你」[rhp]

[:sausu:][sausu kao=8 ]
「………………。嘛，总有一天吧……」[rhp]

[off_all]

[:sausu:][sausu kao=5 ]
「……那么！我差不多该回去了。[rhr]
_　再放任那个世界不管的话，会给约尔大人可乘之机」[rhp]
[:sausu:]
「这条铁道就继续拜托你了，多洛普」[rhp]

[off_all]

[:drop:][p_d_07][drop kao=5 ]
「好的。荣幸之至」[rhp]

[off_all]

;****************************************
#
[bg_magic_c]
;****************************************

[:drop:][drop kao=8 ]
「………………呼」[rhp]

[off_all]

[:drop:]
[font color=0x4682b4]
（……三年后……似乎会发生不得了的事）[rhp]
[:drop:]
（虽未直接见过夜，但南表现得相当戒备。[rhr]
_　面对已被无力化的对象还如此防备，可见事态严峻）[rhp]
[:drop:]
（若那位获得力量，这个世界会变成怎样呢……）[rhp]
[:drop:]
（…………无论发生什么，我都只会坚守此地）[rhp]
[resetfont]

[se storage="door_09.ogg"]

[yurasu]

[:kitex:][p_k_04][kite kao=14 ]
[font size=30]
「多洛普！！！！」[rhp]
[resetfont]

[off_all]

[:drop:][drop kao=4 ]
「哇……！！」[rhp]

[off_all]

[chara_part name="drop" body=base kao=13 as=on ss=off hh=off hr=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:drop:]
「吓、吓死我了！我还以为怎么了……」[rhp]

[:kitex:][kite kao=14 ]
「多洛普！按你说的去打招呼了！」[rhp]

[:drop:][drop kao=1 ]
「辛苦了。感觉如何？都转了一遍吗」[rhp]

[:kitex:][kite kao=4 ]
「太棒了！棒到不行！[rhr]
_　因为这简直就像是身处在『糠星夜』之中啊！」[rhp]
[:kitex:]
「我以前听大家说『死后会坐上像这幅画里的电车』，[rhr]
_　还觉得这种话真是愚蠢！没想到竟然真的存在……！」[rhp]

[:drop:][p_d_24][drop kao=13 ]
「太好了呢，和近先生！」[rhp]

[:kazutika:][kite kao=14 ]
「嗯……！虽然死的时候超级痛，但努力没有白费真好」[rhp]
[:kazutika:]
「从今以后我们可以在这里生活下去了吧？」[rhp]

[:drop:][drop kao=5 ]
「是的！这就是银河之旅的起点。[rhr]
_　我会带你们去任何你和大家向往的地方哦」[rhp]

[:kazutika:][kite kao=13 ]
「……！太好了……！」[rhp]
[:kazutika:]
「今天可能是我人生中最开心的一天！梦想实现了，也成长为大人了。[rhr]
_　明明早就放弃了用自己的双腿走路的想法！」[rhp]
[:kazutika:]
「临死前出现的那个叫南的家伙，原来真的是神明啊！」[rhp]

[:drop:][drop kao=1 ]
[font color=0x4682b4]
「（呵呵，要是本人听见应该会很高兴吧……）"[rhp]
[resetfont]

[:kazutika:][kite kao=4 ]
「啊……多洛普。我只有一个问题想问」[rhp]
[:kazutika:]
「为什么这里会有[player3]理央存在呢？」[rhp]

[:drop:][drop kao=3 as=on ]
「……！」[rhp]

[:kazutika:][kite kao=3 ]
「刚才听说在这里能变成理想的姿态。[rhr]
_　但那是死在那个地方的孩子才有的权利，对吧？」[rhp]
[:kazutika:][kite kao=3 ]
「……理央[player3]明明都还没死吧？」[rhp]

[:drop:][drop kao=1 ]
「…………没错。[rhr]
_　看来你也告一段落了，我要告诉你」[rhp]
[:drop:]
「关于这辆电车……南的计划全貌」[rhp]

[:kazutika:][kite kao=2 ]
「计划……？」[rhp]

[:drop:]
「在说明之前，有条口信要传达给你」[rhp]
[:drop:]
「『我那份也要玩得开心哦』……说是这么说的」」[rhp]

[:kazutika:][kite kao=7 ]
「？　谁的口信？」[rhp]

[:drop:][p_d_22][drop kao=5 ]
「是快斗的」[rhp]

[:kazutika:][kite kao=2 ]
「不是、所以说到底是谁啊」[rhp]

[:drop:][p_d_02][drop kao=13 ]
「是今天的你」[rhp]

[:kazutika:][kite kao=3 ]
「……？　说什么呢？　我是和近啊」[rhp]

[:drop:][drop kao=13 ]
「嗯。那么请允许我慢慢说明。和近先生……不对」[rhp]
[:drop:]
「……今后的快斗先生」[rhp]

;****************************************

#
[s_mask color=0x000000 time=2000]
[off_all]
; 背景表示
[bg storage="black.jpg" time=100]
; 夜フィルター
[filter layer="1" brightness="60"]
; ウィンドゥの設定
[position layer="message0" frame="win2.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[s_mask_off time=2000]

;****************************************
三年后[rhp]
;****************************************
[bg storage="sky_07.jpg"]
[bgm storage="bgm_19.ogg"]
;****************************************

[::]
――――这一天终于来临了。[rhp]
今天是个特别的日子。[rhr]
究竟怀着多少焦躁等待此刻到来。[rhp]

;****************************************
[bg storage="hsps_02m.jpg" time=1500]
;****************************************

三年间失去了太多。[rhp]
和那个只能给病痛孩子做安慰治疗的自己也要在今天告别了。[rhr]
我终于要获得身为医生的意义。[rhp]
不会让一切止步于曾狂妄自大的事实。[rhr]
不能让它结束。[rhp]
……我必定会让他们……[rhp]

[:yoru:][p_y_04][yoru kao=0 ]
「武」[rhp]

[:takeru:][p_tk_01][take kao=3 as=on ]
「……！　啊、啊啊。什么事」[rhp]

[:yoru:][yoru kao=12 ]
「太紧张了。肩膀再放松些」[rhp]

[:takeru:][p_tk_10][take kao=2 as=on ]
「哪、哪里紧张了，我……本、本小姐才没有」[rhp]

[off_all]

[chara_part name="tiaki" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="take" body=base kao=12 as=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="650" top="0" wait="true" time=150]

[:tiaki:][p_mk_09]
「老师也真是的，到底在怕什么呀？[rhr]
_　三年前不是已经模拟体验过那个世界了吗」[rhp]

[:takeru:][take kao=8 as=on ]
「那只是看了影像而已！[rhr]
_　现在和那时候的处境原因根本不一样……！」[rhp]

[:yoru:][yoru kao=12 ]
「假死状态没什么可怕的。用魔法就是一瞬的事」[rhp]

[:tiaki:][tiaki kao=14 ]
「就像打针一样。咻地刺一下，就结束啦♡」[rhp]

[:yoru:][p_y_31][yoru kao=11 ]
「形容得倒是巧妙」[rhp]

[:takeru:][p_tk_11][take kao=6 as=on ]
[font color=0x4682b4]
（可恶……夜这家伙，明明既没给人打过针也没被打过……！[rhr]
_　初次操作的医生当然会紧张啊！）[rhp]
[resetfont]

[off_all]

[:yoru:][yoru kao=12 ]
「…………哈啊。好了好了，我知道了」[rhp]

[off_all]

[chara_part name="take" body=base kao=0 as=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:yoru:][yoru kao=0 ]
「喂喂武。你眼皮上沾了脏东西呢」[rhp]

[:takeru:][take kao=2 ]
「嗯？」[rhp]

[:yoru:][yoru kao=7 ]
「自己看不到吧。千秋，你来帮他弄掉」[rhp]

[off_all]

[:tiaki:][tiaki kao=14 ]
「好嘞好嘞。来，老师～闭上眼睛～」[rhp]

[off_all]

[:takeru:][take kao=6 as=on ]
「啊，不好意思」[rhp]

[off_all]

;****************************************
[s_mask color=0x000000 time=2000]
; 背景表示
[bg storage="black.jpg" time=100]
; ウィンドゥの設定
[position layer="message0" frame="win.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[s_mask_off time=2000]
;****************************************

[:tiaki:][p_mk_14]
「……哇！」[rhp]

[:takeru:]
「弄掉了吗？」[rhp]

[:tiaki:]
「好了。可以睁开眼睛啦♡」[rhp]

;****************************************
#
[bg storage="sky_13.jpg" time=200]
;****************************************

[:takeru:][take kao=2 as=on ]
「哇啊！？」[rhp]

[:yoru:][p_y_16][yoru kao=7 ]
「看吧。就一瞬对吧」[rhp]

[:takeru:][take kao=2 ]
「说是一瞬，其实只是闭了几秒钟眼睛！[rhr]
_　根本感觉不到移动过啊！？」[rhp]

[:yoru:][yoru kao=12 ]
「以我的水平，稍加集中就能轻松办到」[rhp]

[off_all]

[chara_part name="tiaki" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on 
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:tiaki:][p_mk_34]
「让你勉强了？对不起啊。[rhr]
_　像之前那样随便应付下其实就行了的」[rhp]

[:yoru:][yoru kao=6 ]
「现在舒适度优先于节制。……想到今后每次都要等武小题大做的决心[rhr]
_　就觉得烦人」[rhp]

[off_all]

[chara_part name="take" body=base kao=2 as=on hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:takeru:][p_tk_13]
「诶！你、你能读心吗」[rhp]

[:yoru:]
「………………。啊对。能读能读」[rhp]

[off_all]

[:tiaki:][tiaki kao=6 ]
[font color=0x4682b4]
（终于开始嫌麻烦了呢……）[rhp]
[resetfont]

[off_all]

[chara_part name="take" body=base kao=2 as=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:yoru:][p_y_04]
「武……这种状态很快就会耗尽心力的」[rhp]

[:takeru:][take kao=3 as=on ]
「……！」[rhp]

[:yoru:]
「你的拼命精神很了不起值得表扬，[rhr]
_　但并非所有事都必须全力以赴」[rhp]
[:yoru:]
「保持从容。你的信念不会输给南的自以为是」[rhp]
[:yoru:]
「我们的信念才是绝对的正义」[rhp]

[:takeru:][take kao=1 as=on ]
「……夜……」[rhp]
[:takeru:]
「…………嗯。你说的对」[rhp]

[off_all]

[chara_part name="tiaki" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:tiaki:]
「真温柔呢」[rhp]

[:yoru:]
「没有……只是想让你顺利完成任务。有必要也会鼓舞你」[rhp]
[:yoru:][yoru kao=6 ]
「……你的觉悟如何？现在还能回头」[rhp]

[:tiaki:][tiaki kao=13 ]
「不需要。我从一开始就很从容」[rhp]
[:tiaki:]
「无法原谅把他们关在这么狭小的世界里。[rhr]
_　无论多伟大的人 都不该扼杀孩子们的可能性」[rhp]
[:tiaki:]
「我们一定会摧毁这个世界。然后，夺回大家的未来」[rhp]

[:yoru:][p_y_15][yoru kao=1 ]
「呵……有这份志气就好」[rhp]

[off_all]

[:takeru:][take kao=3 ]
「………………」[rhp]

[off_all]

[::]
她是个坚强的人。我这种人根本没法比。[rhr]
平时虽然吊儿郎当，关键时刻却比身为男人的我更加可靠。[rhp]
虽然心情有些复杂，但这是我由衷的想法。[rhr]
能让她成为我的部下，真是太好了。[rhp]

[:yoru:][p_y_04][yoru kao=0 ]
「武，你也做好觉悟了吗」[rhp]

[off_all]

[:takeru:][p_tk_01][take kao=5 ]
「……当然！」[rhp]

[off_all]

[::]
夜似乎对我的回答很满意，朝我微微点头回应。[rhp]
然后，再次将视线投向正前方。[rhp]
以夜的力量，似乎还无法进入铁道内部。[rhr]
所以我们的方针是，在他们作为旅行目的地登陆的星球上实施截击。[rhp]
……这道光芒的彼端，有我未能拯救的孩子们。[rhp]

[:takeru:]
[font color=0x4682b4]
（…………如果六道轮回真的存在）[rhp]
[:takeru:]
（我想再次见到你们）[rhp]
[resetfont]

[::]
而且最好不要是在这样的童话世界里。[rhp]
更不要是在这片黑暗之中。[rhp]
……一定要在，阳光之下重逢。[rhp]

;****************************************
[fbgm]

#
[s_mask color=0x000000 time=2000]
; 背景表示
[bg storage="hsps_08n.jpg" time=100]

[filter layer="1" brightness="60"]

; ウィンドゥの設定
[position layer="message0" frame="win2.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[s_mask_off time=2000]

[bgm storage="bgm_08.ogg"]
;****************************************

……自那日前往银河世界起，十个月即将过去。[rhp]
至于我，在那边世界奋斗的同时，依旧在临终关怀院[rhr]
过着说好也好、说糟也糟的平淡日常。[rhp]

[:takeru:][take kao=1 ]
「――――……好。今天也没问题呢」[rhp]

[:himeko:]
「好～的。谢谢您啦ー」[rhp]

[:takeru:][take kao=3 ]
「…………………………」[rhp]

[:himeko:]
「…………老师？」[rhp]

[:takeru:]
「………………、…………」[rhp]

[off_all]

[:tiaki:][tiaki kao=0 ]

[:himeko:]
「……米卡亲。你不觉得今天的老师有点奇怪吗？」[rhp]

[:tiaki:][tiaki kao=13 ]
「哎呀，老师不是一直都古里古怪的嘛」[rhp]

[:himeko:]
「不是说那种事啦……算了当我没说」[rhp]
[:himeko:]
「给，昨天的日志。我放这里喽」[rhp]

[:tiaki:][tiaki kao=0 ]
「好的收到。明天也请期待米卡亲的一言小剧场～」[rhp]

[:himeko:]
「别再拿红笔画奇怪生物了啦」[rhp]

[:tiaki:][p_mk_22][tiaki kao=8 as=on ]
「好过分！那是玄凤鹦鹉啦！」[rhp]

[:himeko:]
「根本看不出来啊！」[rhp]

[off_all]

[:himeko:]
「老师也看到了吗？米卡亲的画真是超级烂耶！」[rhp]

[:takeru:][take kao=3 ]
「………、………」[rhp]

[:tiaki:][tiaki kao=11 ]
「…………。老师该走啦～」[rhp]

[:takeru:][p_tk_30][take kao=2 as=on ]
「……诶？啊、啊…好的」[rhp]
[:takeru:]
「那…晚安了，星名小姐。请多保重」[rhp]

[:himeko:]
「现在最不想被老师这么说呢……」[rhp]

[off_all]

;****************************************
[set_b storage="hsps_04n.jpg"]
;****************************************

[::]

[:tiaki:][tiaki kao=13 ]
「―――交接事项就这些。我先下班了」[rhp]
[:tiaki:]
「辛苦您了……」[rhp]

[off_all]

[:takeru:][take kao=3 ]
「……………………」[rhp]

[off_all]

[chara_part name="take" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=3 as=on ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:][p_mk_04]
「……，老师。您没事吧？」[rhp]

[:takeru:][take kao=2 as=on ]
「……！……啊、嗯。那个……」[rhp]
[:takeru:]
「……抱歉，刚才说到哪了」[rhp]

[:tiaki:][tiaki kao=6 ]
「骗您的。交接早就结束了」[rhp]

[:takeru:][take kao=3 as=on ]
「诶……！非、非常抱歉。我完全心不在焉……」[rhp]

[:tiaki:][tiaki kao=3 as=on ]
「……老师。最近是不是太勉强自己了」[rhp]
[:tiaki:]
「终于能够去银河铁道了，[rhr]
_　你只顾着那边的事都没好好睡觉吧」[rhp]

[:takeru:][take kao=2 as=on ]
「…………」[rhp]

[off_all]

[::]
……确实如此。[rhp]
在苦等三年后，我和大美贺小姐终于[rhr]
得以前往传说中的「银河铁道」。[rhp]
那里有从这儿启程的孩子们正以各种形态享受着银河之旅。[rhr]
……说服他们放弃铁道之旅，无论从哪个角度看都是艰巨的任务。[rhp]

但这是必要的。哪怕乱来也必须推进。[rhp]
……在那里或许很快乐，[rhr]
但他们期盼的自由未来永远不会到来。」[rhp]

[chara_part name="take" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:]
「明明不是夜班，下班后还留在临终关怀院吧。[rhr]
_　连休假的夜晚都来这里消耗在那边的世界」[rhp]
「而且我从其他工作人员那里也听说了。[rhr]
_　矢部老师最近总在休息日加班，深夜独自写论文」[rhp]
[:tiaki:]
「那份论文要是有的话，请务必让我看看」[rhp]

[:takeru:][p_tk_22][take kao=3 as=on ]
「那个……」[rhp]

[:tiaki:][tiaki kao=3 ]
「老师……不能总这么乱来。[rhr]
_　要是老师倒下了，困扰的不是我。是孩子们」[rhp]

[:takeru:][take kao=4 ]
「我知道的……没关系。我还没那么脆……」[rhp]

[:tiaki:][tiaki kao=12 ]
「是在为杰特君的事着急吗」[rhp]

[:takeru:][take kao=2 ]
「……！」[rhp]

[:tiaki:][tiaki kao=3 ]
「因为前几天才刚刚搬进来嘛。[rhr]
_　……你中了南的圈套去了那边的事，我理解你懊悔的心情」[rhp]

[:takeru:][p_tk_12][take kao=3 ]
「那为什么要责备我？　我只是想救孩子们―――」[rhp]

[:tiaki:][tiaki kao=2 ]
「因为你只顾着那边，把本职工作都怠慢了！[rhr]
_　不是想救孩子们吗？　这样岂不是本末倒置了吗」[rhp]

[:takeru:][take kao=8 as=on ]
「那、那是……」[rhp]

[:tiaki:][p_mk_09][tiaki kao=8 ]
「夜君会配合老师乱来的行动，[rhr]
_　是为了让你吃次苦头好好反省。但我是反对这种做法的」[rhp]
[:tiaki:]
「因为对夜君来说这或许是个管束你的好机会，[rhr]
_　但与我们护士和孩子们毫无关系」[rhp]
[:tiaki:]
「要是没有老师，这个银河站就―――」[rhp]

[:takeru:][take kao=2 ]
「这种事我当然知道！」[rhp]

[:tiaki:][tiaki kao=1 ]
「……！」[rhp]

[:takeru:][take kao=3 ]
「我知道的……！　知道我是在胡来」[rhp]
[:takeru:]
「但是……！　能行动总比束手无策强。[rhr]
_　这三年来，你知道我在这里送走了多少孩子吗」[rhp]

[:tiaki:][tiaki kao=8 as=on ]
「…那……那个……」[rhp]

[:takeru:][take kao=2 ]
「好不容易才有了拯救他们的手段。[rhr]
_　正因至今为止什么都做不到，现在拼命才是应该的吧？」[rhp]
[:takeru:]
「我根本没有休息的余裕。所以……！」[rhp]

[off_all]

[:yoru:]
「适可而止吧」[rhp]

[bg_magic_c]

[chara_part name="tiaki" body=base kao=4 as=on ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:tiaki:]
「夜、夜君……」[rhp]

[:yoru:][yoru kao=12 ]
「晚上好，两位」[rhp]

[off_all]

[:takeru:][take kao=0 as=on ]
「真稀奇呢，这种时间出现」[rhp]

[off_all]

[:yoru:][yoru kao=7 ]
「………………」[rhp]

[off_all]

[chara_part name="take" body=base kao=4 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=12 as=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:takeru:][take kao=3 as=on ]
「……怎么了？脸色很差啊」[rhp]

[:yoru:][yoru kao=8 ]
「…………这样啊。或许是吧」[rhp]

[:takeru:][take kao=0 ]
「夜……？」[rhp]

[:yoru:][yoru kao=3 ]
「…………，武」[rhp]

[off_all]

[:yoru:]
「……抱歉……能稍微，拜托你吗」[rhp]

;****************************************
[fbgm]

#
[s_mask color=0x000000 time=2000]
; 背景表示
[bg storage="train_05.jpg" time=100]
;全部のフィルターを打ち消す
[free_filter ]
; ウィンドゥの設定
[position layer="message0" frame="win.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[s_mask_off time=2000]

[bgm storage="bgm_15.ogg"]
;****************************************

[::]
依言而行，我首次踏入了银河铁道的『车内』。[rhp]

[:takeru:]
「……………这里就是，银河铁道」[rhp]

[::]
颇具气氛的内装，连不太了解的我都能联想到那个故事的世界观。[rhp]
若是在这列车里生活，说服孩子们要费大力气也是理所当然。[rhr]
就连我也觉得，若能在这种地方持续旅行简直再好不过。[rhp]

[:takeru:]
[font color=0x4682b4]
（但是，为什么……）[rhp]
[resetfont]

[::]
直到突破南的结界为止夜的力量应该已经恢复了，[rhr]
但为了通知这件事神色未免过于凝重。[rhp]

[:takeru:]
[font color=0x4682b4]
（…………和大美贺小姐留在那边的事有关系吗）[rhp]
[resetfont]

;****************************************

#
[s_mask color=0x000000 time=1000]
; 背景表示
[bg storage="hsps_04n.jpg" time=100]
; フィルター
[filter layer="base" sepia="70" ]
[filter layer="1" sepia="70" ]
; ウィンドゥの設定
[position layer="message0" frame="win2.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[s_mask_off time=1000]

;****************************************


[chara_part name="tiaki" body=base  kao=4 as=on hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:tiaki:]
「我留下？」[rhp]

[:yoru:]
「正是」[rhp]

[:tiaki:]
「为、为什么啊！老师已经很累了。要是发生什么意外的话……！」[rhp]

[:yoru:][yoru kao=6 ]
「没问题。你有其他任务」[rhp]

[off_all]

[:yoru:][yoru kao=2 ]
「……武。今天想拜托你的不是说服孩子们」[rhp]
[:yoru:]
「希望你能去确认一下――――」[rhp]

;****************************************

#
[s_mask color=0x000000 time=2000]
[off_all]
; 背景表示
[bg storage="train_05.jpg" time=100]
; 全部のフィルターを打ち消す
[free_filter ]
; ウィンドゥの設定
[position layer="message0" frame="win.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[s_mask_off time=2000]

;****************************************

[:takeru:]
[font color=0x4682b4]
（…………为何大美贺小姐被留下了？[rhr]
_　夜应该很清楚她的认真态度）[rhp]
[:takeru:]
（不，比起那个，这是夜的请求。[rhr]
_　为什么现在还需要确认『那种事』……）[rhp]
[resetfont]

[:unknown:]
「咦。你居然在那里……」[rhp]

[:takeru:][take kao=4 ]
「！」[rhp]

[off_all]

[chara_part name="take" body=base kao=4 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:kite:]
「果然是矢部。真少见啊，为什么在这儿？」[rhp]

[:takeru:][p_tk_01][take kao=2 as=on ]
「啊、啊啊。是伊东君啊……」[rhp]

[:kite:][kite kao=5 ]
「所以现在我叫快斗啦」[rhp]

[off_all]

[::]
快斗抬起单手，轻快地打了个招呼。[rhr]
……这似乎就是伊东君所描绘的未来模样。[rhp]
在这个世界进行说服的过程中，和他变得相当亲近。[rhr]
本该是招人憎恨角色的我，或许因为我们是老相识吧。[rhp]

[chara_part name="take" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:takeru:]
「吓到你了吧。不知为何今天被传送到这个地方了」[rhp]

[:kite:][p_k_03][kite kao=11 ]
「嘿—。话说这是第一次吧？欢迎～」[rhp]
[:kite:][kite kao=0 ]
「………………」[rhp]

[:takeru:][take kao=6 ]
「……怎么了？」[rhp]

[:kite:][kite kao=12 ]
「……没？我在想是不是和今天的事有关系」[rhp]

[:takeru:][take kao=2 ]
「今天的事……？」[rhp]

[:kite:][kite kao=3 ]
「对。……嘛，不过我已经不插手那边的事了」[rhp]
[:kite:]
「总之辛苦了。矢部」[rhp]

[:takeru:][take kao=8 ]
「………………？」[rhp]

[off_all]

[::]
这孩子到底在说什么……？[rhr]
我辛苦了？对什么？」[rhp]

[:takeru:]
[font color=0x4682b4]
（难道说，我已经死了所以……之类的……）[rhp]
[:takeru:]
（…………哈哈！怎么可能有这种事）」[rhp]
[resetfont]

[::]
确实在过劳死边缘积累了相当的疲劳，[rhr]
听说来这条铁道的基本上只有居住于此的孩子们。[rhp]
恐怕夜另有其他意图。[rhr]
那个稍后再问，总之先着手做现在能做的事吧。[rhp]

[chara_part name="take" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:takeru:]
「……不错的车厢。这里是你的房间吗？」[rhp]

[:kite:][kite kao=8 as=on ]
「这里是观景车厢。我不太常来……[rhr]
_　……只不过现在正值黄昏时分」[rhp]

[:takeru:][take kao=6 as=on ]
「怎么了。是有什么烦恼吗？」[rhp]

[:kite:][kite kao=3 ]
「……………………」[rhp]
[:kite:]
「…………老师」[rhp]
[:kite:]
「我到昨天之前还觉得死了比较幸运」[rhp]

[:takeru:][take kao=2 as=on ]
「……！」[rhp]

[:kite:][kite kao=3 ]
「在这样一个能实现所有愿望——[rhr]
_　想做的事、想成为的人，什么都能如愿的世界里[player3]我曾希望理央也来这里」[rhp]
[:kite:]
「……虽然这么想过……」[rhp]

[:takeru:][take kao=5 as=on ]
「伊东君……！你终于明白了。[rhr]
_　也就是说你愿意离开这个世界了？」[rhp]

[:kite:]
「………………」[rhp]

[:takeru:][take kao=0 ]
「……伊东君？」[rhp]

[:kite:][kite kao=3 ]
「…………那家伙，听说失忆了」[rhp]

[:takeru:][take kao=3 ]
「那家伙？而且失忆是说……」[rhp]

[:kite:][kite kao=3 ]
「没错。很莫名其妙吧」[rhp]

[off_all]

[:kite:]
「………………为什么只有[player3]他」[rhp]

[::]
微弱得几乎无法传达的喃喃自语。[rhp]
但确实听到了失忆这个词。[rhp]
怎么回事。这条铁道上发生了什么？[rhr]
无论是公主的事，还是伊东君的态度―――……[rhp]

[fbgm]

[:takeru:]
「…………………………啊咧」[rhp]

[::]
……话说回来。[rhp]
记得伊东君对这里假冒的星名小姐，[rhr]
只称呼她为『公主』才对。[rhp]

;****************************************

#
[s_mask color=0x000000 time=1000]
; 背景表示
[bg storage="hsps_05n.jpg" time=100]
; フィルター
[filter layer="base" sepia="70" ]
; ウィンドゥの設定
[position layer="message0" frame="win2.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[s_mask_off time=1000]

;****************************************

[:yoru:]
[font color=0x696969]
「……武。今天想拜托你的不是说服孩子们」[rhp]
[:yoru:]
「希望你能去确认一下。[rhr]
_　那个世界的公主，是否是你认识的那个她」[rhp]
[resetfont]

;****************************************

#
[s_mask color=0x000000 time=1000]
; 背景表示
[bg storage="train_05.jpg" time=100]
; フィルター解除
[free_filter ]
; ウィンドゥの設定
[position layer="message0" frame="win.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[s_mask_off time=1000]
;****************************************

[bgm storage="bgm_14.ogg"]

[:takeru:][take kao=4 as=on ss=on ]
「………………」[rhp]

[off_all]

[::]
公主的失忆，与夜的力量大幅恢复这两件事。[rhr]
这两者是否存在某种关联。[rhp]
若要列举夜力量恢复的诱因，会想到什么呢。[rhp]
他平日里就对南抱有强烈的反抗意识。[rhr]
如果这种情绪突然加剧的话……[rhp]

[:takeru:]
「…………愤怒？」[rhp]

[::]
为什么？夜在为何事愤怒？[rhr]
是因为公主失忆吗？[rhp]
那么，造成失忆的原因是……[rhp]

[:takeru:]
「……………………」[rhp]
[:takeru:]
「……………………―――――难道」[rhp]

;****************************************
#
[bg storage="black.jpg" time=1000]
;****************************************

[::]
有个困惑已久的疑问。[rhp]
听说孩子们被迎入这个世界后，[rhr]
会与南事先准备的人偶合为一体。[rhp]
融合之后呢？[rhr]
之后的人生，究竟从何种状态开始？[rhp]

…………此刻在此的，真是『公主』吗？[rhp]

;****************************************

[s_mask color=0x000000 time=3000]
; 背景表示
[bg storage="hsps_06n.jpg" time=100]
; ウィンドゥの設定
[position layer="message0" frame="win2.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[s_mask_off time=3000]

;****************************************

回到现实世界后，我奔跑在走廊上赶往星名小姐的房间。[rhp]
……不祥的预感挥之不去。[rhp]

;****************************************
;引き戸開く
[se storage="door_09.ogg"]
[bg storage="hsps_09n.jpg" rule="002.png" time=500]
;****************************************

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------


;****************************************
;スチル
[still storage="cg/b2_3.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/b2_3.png"]
;****************************************

[:takeru:]
「…………！」[rhp]

[:tiaki:]
「………………！」[rhp]
[:tiaki:]
「老师……」[rhp]

[:takeru:]
「……大美贺、小姐……？」[rhp]

[:tiaki:]
「……夜君说……要陪在、你身边……」[rhp]
[:tiaki:]
「然后就……！」[rhp]

[:takeru:]
「………………星名小姐呢」[rhp]

[:tiaki:]
「……呼、……呜、……」[rhp]

[::]
在她枕边，大美贺小姐哭着摇头。[rhr]
……那意味着什么，我再清楚不过。[rhp]
但我完全无法接受。[rhp]

[:takeru:]
「………………为什么」[rhp]

[::]
那时夜的异常态度，[rhr]
是因为夜来叫我时已经处于「紧急状态」了。[rhp]
也就是说，星名小姐在那时就已经……[rhp]
……………………。[rhp]
……这不可能。[rhp]

[:takeru:]
「警报呢……？侧边监测器的紧急警报为什么没响？」[rhp]

[:tiaki:]
「不知道……」[rhp]

[:takeru:]
「护、护士呼叫按过吗……？」[rhp]

[:tiaki:]
「……没、没有按过」[rhp]

[:takeru:]
「那！为什么……！」[rhp]
[:takeru:]
「……为什么星名小姐会去世……？」[rhp]

[::]
……确实这几个月她状态不佳。[rhp]
但也不至于危及生命，[rhr]
就在几小时前，她的病情还很稳定。[rhp]
还和大美贺小姐谈笑风生，和往常毫无二致。[rhp]
…………我没能意识到吗？[rhp]

[:takeru:]
「啊……啊啊……啊……」[rhp]

;****************************************
[still_end frame="win2.png" storage="black.jpg" time=2000]
;****************************************

[::]
清醒过来了。[rhp]
对自己的愚蠢和浅薄。[rhp]
…………不知何时，曾被说过的话掠过脑海。[rhp]

[font color=0x696969]
『因为您疏忽了这边的工作』[rhr]
『这样不是本末倒置了吗』[rhp]
[resetfont]

[::]
庸医这个词真是恰如其分。[rhp]
即便花费了这么多时间。[rhr]
即便怀揣多么崇高的意志。[rhp]

结果我，从未成功拯救过任何人。[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************

[s_mask color=0x000000 time=2000]
; 背景表示
[bg storage="hsps_02m.jpg" time=100]
; 夜フィルター
[filter layer="1" brightness="60"]
; ウィンドゥの設定
[position layer="message0" frame="win2.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[s_mask_off time=2000]

;****************************************

察觉到武的归来，我轻轻叹了口气。[rhp]

[:yoru:][yoru kao=12 ]
「…………比预想的要早啊」[rhp]

[off_all]

[::]
今晚的宁静比往常更为显著。[rhr]
这也理所当然。[rhp]

[:yoru:][yoru kao=3 ]
「……[player2]。终于你也成为那边的人了吗」[rhp]

[off_all]

;****************************************
#
[bg storage="black.jpg" time=1000]
;****************************************

[::]
―――我甘愿承认自己的残暴。[rhp]
我[player2]在告知武和千秋之前，就察觉到了她的死讯。[rhp]
设备故障虽需追查，但如今已无济于事。[rhr]
即便在此喧哗，也无法挽回她的死亡。[rhp]

;****************************************
[set_kk storage="sky_11.jpg" time=1000]
;****************************************

这次的案例与以往情况不同。[rhp]
[player2]她在那个世界里，[rhr]
『[player2]』的事实被彻底隐瞒了。[rhp]
被召唤到那个世界的她，既没有真实的记忆，[rhr]
也不曾拥有虚假的记忆。[rhp]
通常本应通过吸收虚假记忆的形式，仅保留外貌的真实存在会留存下来。[rhp]

;****************************************
[bg storage="black.jpg" time=1000]
;****************************************

造成这种状况的原因，早已了然于心。[rhp]
……会做出这种事的混账东西，世上只有一个。[rhp]

;****************************************
[set_ff storage="hsps_02m.jpg" time=1000]
[filter_n]
;****************************************

[:yoru:][yoru kao=2 ]
「这下满意了吗」[rhp]

[off_all]

[:sausu:][sausu kao=0 ]
「……约尔大人……」[rhp]

[off_all]

[::]
故意让武前往另一侧的目的，[rhr]
是为了让他避开即将发生的这场纷争。[rhp]
迄今为止失去众多患者的武，似乎将全部赌注都押在[rhr]
这个从他就职之初便存在的孩子[player2]——最后一位患者的治疗上。[rhp]
不仅这番努力尽数化为泡影。[rhr]
前几日，新来的病人刚被送往另一侧。[rhp]
这种时候若让那男人见到他，连傻子都猜得到后果。[rhp]
…………更何况今日，连我自己都没有保持冷静的把握。[rhp]

[chara_part name="sausu" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:yoru:][yoru kao=2 ]
「我有无数问题想问你」[rhp]

[:sausu:][sausu kao=13 ]
「真巧呢……我也有话想对约尔大人说」[rhp]
[:sausu:][p_s_18][sausu kao=1 ]
「以约尔大人的敏锐，想必早已察觉……[rhr]
_　关于她今后的事，希望你不要多管闲事」[rhp]
[:sausu:]
「我正与她进行着一场赌局」[rhp]

[:yoru:][yoru kao=6 ]
「你想说的就这些吗」[rhp]

[:sausu:][sausu kao=5 ]
「嗯」[rhp]

[off_all]

[:sausu:]
「…………所以呢？」[rhp]

;****************************************
[free_filter ]
;スチル
[still storage="cg/b2_4.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/b2_4.png"]
;****************************************

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sausu:]
「有什么事吗。请长话短说」[rhp]

[:yoru:]
「都是你干的吧」[rhp]

[:sausu:]
「………………」[rhp]

[:yoru:]
「星名[player2]的侧边监测器明明没有故障，[rhr]
_　紧急时刻却毫无反应」[rhp]
[:yoru:]
「那个时间她本不该就寝，[rhr]
_　却既没有响应护士呼叫。说到底连警报都没响过」[rhp]
[:yoru:]
「…………都怪你啊」[rhp]

[:sausu:]
「没错」[rhp]

[:yoru:]
「哈。毫无意外可言」[rhp]

[:sausu:]
「和你不同，我与许多垂死的孩子们交谈过。[rhr]
_　在完全理解他们心情的前提下，我还是要说」[rhp]
[:sausu:]
「活着要比死亡更加痛苦啊」[rhp]
[:sausu:]
「……所以这样就好。我并不后悔」[rhp]
[:sausu:]
「我，和她都是」[rhp]

[:yoru:]
「……就算退一亿步，对死者的考量尚能理解」[rhp]
[:yoru:]
「生前未能获得的幸福，死后理当补偿的观点，[rhr]
_　确实有其合理之处」[rhp]
[:yoru:]
「但最近的你又如何。[rhr]
_　故意将生者魂魄卷入其中，实在过分」[rhp]
[:yoru:]
「你这邪魔。光是存在就令人作呕」[rhp]

;****************************************
#
[bg storage="cg/b2_4b.png" width="1280" height="720" time=500]
[cg storage="cg/b2_4b.png"]
;****************************************

[:sausu:]
「……我立过誓约」[rhp]

[:yoru:]
「住口。谁要听你狡辩」[rhp]

[:sausu:]
「即便从现在开始努力维持友好关系……也是不可能了吧」[rhp]
[:sausu:]
「……真是遗憾啊。非常」[rhp]

[:yoru:]
「别忘了导致这种结果的罪魁祸首是你」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:sausu:]
「………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:yoru:]
「什么叫『幸运』。别开玩笑了」[rhp]
[:yoru:]
「擅自决定别人的价值观。[rhr]
_　肆意践踏他人的人生。你哪有资格说这些话」[rhp]
[:yoru:]
「你所谓的『幸运』，不过是你一个人的『幸运』罢了……！」[rhp]

[:sausu:]
「…………呃」[rhp]

[:yoru:]
「别再让我见到你……」[rhp]
[:yoru:]
「……这个瘟神」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
[fbgm]
;スチル終了

#
[s_mask color=0x000000 time=3000]
; 背景表示
[bg storage="sky_07.jpg" time=100]
; 全部のフィルターを打ち消す
[free_filter ]
; ウィンドゥの設定
[position layer="message0" frame="win2.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[s_mask_off time=3000]

;****************************************

1周后[rhp]

;****************************************
[set_w  storage="hsps_02m.jpg"]
;****************************************

[still_end frame="win.png" storage="sky_13.jpg" time=1000]

[bgm storage="bgm_01.ogg"]
;****************************************


[:tiaki:][mika kao=0 ]
「……………………」[rhp]

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
[vostart]
;--------------------------------------------------------------------------------------------

[off_all]

[:unknown:][yabu kao=13 ][s_playse storage="yabu/full/107.ogg" buf=1]
「原来如此！你就是米卡亲对吧！？」[rhp]

[off_all]

[chara_part name="yabu" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="yabu" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="mika" body=base kao=13 as=on ss=off hh=off hr=on ]
[chara_show name="mika" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:]
「嗯。……那个……」[rhp]

[:unknown:][yabu kao=13 ][s_playse storage="yabu/full/108.ogg" buf=1]
「哼哼。叫我名医大人就好」[rhp]

[off_all]

[:yoru:][yoru kao=6 ]
「叫庸医就行了」[rhp]

[:yabu:][yabu kao=2 as=on ]
「哈！？喂等等！谁说我是庸医了！」[rhp]

[off_all]

[:tiaki:][mika kao=13 ]
「请多指教啦。矢部老师♡」[rhp]

[off_all]

[:yabu:][yabu kao=8 as=on ]
「连、连米卡亲也……！」[rhp]

[off_all]

[::]
焕然一新的我，再次将两人召唤到这个世界。[rhp]
我绝不屈服。[rhr]
重新出发后，我打算让他们负责妨碍铁道旅行的任务。[rhp]
不过被刷新的可不止是服装。[rhp]

[chara_part name="mika" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="mika" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="yabu" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="yabu" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="650" top="0" wait="true" time=150]

[:yabu:]
「哼、哼。算了无所谓。[rhr]
_　真正的名医，往往都会被周围人当成废物呢」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[s_playse storage="mika/full/178.ogg" buf=1]
[s_playse storage="yoru/full/178.ogg" buf=2]

[:2nin:]
「？」[rhr]
「？」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
;糠星の夜
[voconfig sebuf=1 name=yoru vostorage="yoru/full/{number}.ogg" number=179]
;ミカちん
[voconfig sebuf=1 name=tiaki vostorage="mika/full/{number}.ogg" number=179]
[vostart]
;------------------------------------------------------------------------------------------

[:yabu:][yabu kao=13 as=on ]
「但是米卡亲该怎么说呢……[rhr]
_　你这身打扮对小孩子来说刺激太强了吧？！[rhp]
[:yabu:]
「啊、我也觉得眼睛不知道该往哪看呢……哈哈哈！　开、开玩笑的，」[rhp]

;ヨルにぶったたかれるヤブ

[yoru kao=5 ]
[yurasu]
[se storage="hand_06.ogg"]

[:yabu:][yabu kao=2 as=on ]
「痛啊！！　你、你干什么！？[rhr]
_　名医的脑袋要是变成凡人的水准你负得起责吗！？」[rhp]

[off_all]

[chara_part name="mika" body=base kao=6 as=on hh=off hr=on ]
[chara_show name="mika" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=7 as=on ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:tiaki:]
「夜君……真的必须和这个人组队吗？」[rhp]

[:yoru:]
「仅凭你独自完成我的委托，未免稍显不足吧」[rhp]

[:tiaki:]
「某种意义上我觉得独自行动反而更好……」[rhp]

[off_all]

[:yabu:][yabu kao=13 ]
「哼哼！　我可是由当地地位最高的『糠星夜』亲手打造、全领地最[rhr]
_　优秀的人类矢部武的替代品啊？　怎么可能有失败以外的选项！」[rhp]
[:yabu:]
「成品质量根本不能比啊！　和那种花哨男做的软弱人偶们[rhr]
_　就用我华丽的工作表现，让那些铁道宅震撼到发抖吧！」[rhp]

[off_all]

[chara_part name="mika" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="mika" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:tiaki:]
「他在说什么话题？」[rhp]

[:yoru:]
「那家伙是我从头开始制作的灵体。[rhr]
_　因为是人工制造的非人之物，所以称作人偶」[rhp]

[off_all]

[::]
现在才说可能有点晚……但这里的武并不是武本人。[rhr]
这个聒噪又自信过剩的男人，是我模仿南制作出来的人偶。[rhp]

就像反映了孩子们憧憬那样，我也如此效仿他的话。[rhr]
不知为何他心中存有这般理想，故而演变成如此局面。[rhp]

并非对武的工作能力有所不安。[rhr]
只因如今他精神状态过于脆弱，判断将计划托付于他过于残酷。[rhp]
武也理解这点。[rhr]
……但关于替代者变成了怎样的男人，尚未告知于他。[rhp]

[chara_part name="mika" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="mika" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:yoru:]
「……话说。状态如何」[rhp]

[:tiaki:][mika kao=8 as=on ]
「虽然感觉他差点就要辞职了，[rhr]
_　好歹说服他继续工作了」[rhp]
[:tiaki:]
「可是……完全变样了呢。无论何时交谈都萎靡不振，毫无干劲……」[rhp]

[:yoru:][yoru kao=12 ]
「…………这样啊」[rhp]

[:tiaki:][mika kao=3 ]
「当先生说『再也不去银河铁道了』的时候，我真不知该如何是好。[rhr]
_　……看那情形，比起『不去』更像是『不能去』呢」[rhp]
[:tiaki:]
「……他一直在自责，说自己过于专注银河铁道，[rhr]
_　[player2]导致没能救出小千」[rhp]
[:tiaki:]
「明明都说过无数次不是你的错了」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:yoru:][yoru kao=12 ]
「…………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:tiaki:][mika kao=3 ]
「……呐，夜君」[rhp]
[:tiaki:]
「我们是正确的吧？」[rhp]

[:yoru:][yoru kao=11 ]
「当然」[rhp]

[:tiaki:]
「…………。但愿如此呢……」[rhp]

[off_all]

[:yabu:][yabu kao=14 ]
「哼，无须忧虑，你们俩」[rhp]

[:tiaki:]
「……！」[rhp]

[:yabu:][yabu kao=5 ]
「交给我就不会有问题。我一定会把孩子们救出来给你看」[rhp]
[:yabu:]
「因为老子！可是银河第一的名医啊！」[rhp]

[off_all]

[:tiaki:][mika kao=13 hh=on ]
「…………唔、说得对。医生……真可靠呢！」[rhp]

[off_all]

[chara_part name="yabu" body=base kao=13 as=off ss=off hr=on ]
[chara_show name="yabu" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="mika" body=base kao=5 as=off ss=off hh=on hr=on ]
[chara_show name="mika" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:]
「一定要救出那些孩子。绝不会让南为所欲为！」[rhp]

[:yabu:][yabu kao=14 ]
「那当然！名医没有做不到的事！哈―――哈哈哈！」[rhp]

[off_all]

[:yoru:]
[font color=0x4682b4]
（……这就是理想中的形象吗……）[rhp]
[resetfont]

[::]
……本该是救死扶伤的职业，却成了只能送人临终的窝囊废。[rhp]
……这种感受我似乎能隐约明白……。[rhp]

;****************************************
[fbgm]

[s_mask color=0x000000 time=2000]
; 背景表示
[bg storage="hsps_05n.jpg" time=100]
; 夜フィルター
[filter layer="1" brightness="60"]
; ウィンドゥの設定
[position layer="message0" frame="win2.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[s_mask_off time=2000]

[bgm storage="bgm_15.ogg"]
;****************************************

空无一人的医务室。[rhr]
坐在诊疗床上，我独自耷拉着脑袋。[rhp]
……大美贺小姐今后要面对的，恐怕是我的冒牌货吧。[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:takeru:]
「………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[::]
自从星名小姐死后，我就再也无法前往那个世界了。[rhp]
即便被夜安慰过，我依然感到恐惧。[rhr]
害怕再次引发那样的悲剧。[rhp]

所以我才任性地拜托夜制作了我的替代品。[rhr]
那一定是个与我相像又睿智理性的男人，大美贺小姐也能放心吧。[rhp]

[:takeru:]
「………………对不起」[rhp]

[::]
都怪我这个废物不争气。[rhr]
这副德性还敢自称医生，真是可笑。[rhp]
…………可即便如此，我也没有勇气离开这里。[rhp]
一旦移开视线，可怕的想象就会不受控制地涌现。[rhr]
在我不在的时候，星名小姐在病房里怀着怎样的心情。[rhp]
关于夜，我听说在我去那边的时候就已经死亡了。[rhp]

即便如此如果我注意到了设备的异常，[rhr]
或许能察觉到装置的不对劲。[rhp]
都是因为我不在的缘故。[rhr]
都是因为我……。[rhp]

;****************************************
[bg storage="black.jpg" time=1000]
;****************************************

[:takeru:]
「…………」[rhp]

[::]
…………必须挽回。[rhr]
不在那个银河，而是在这个现实中。[rhp]
即便那只是自我满足，现在的我也只有这个……[rhp]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
[s_mask time=4000]
;****************************************

;エンドフラグ
[eval exp="sf.b2_end = 1"]

[cancelskip]
[fbgm]

[jump storage="title.ks" target="*start_end"]

[s]