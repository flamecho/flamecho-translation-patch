﻿*start
;--------------------------------------------------------------------------------------------
;▼フルボイスセット▼

;ヌシ
[voconfig sebuf=1 name=nusi vostorage="nusi/full/{number}.ogg" number=68]
;魔太郎子
[voconfig sebuf=1 name=mata vostorage="mata/full/{number}.ogg" number=42]
;ゴンザレス一億世
[voconfig sebuf=1 name=gon vostorage="gon/full/{number}.ogg" number=35]
;サウス
[voconfig sebuf=1 name=sausu vostorage="sausu/full/{number}.ogg" number=92]

;--------------------------------------------------------------------------------------------

;****************************************
[set_00 storage="train_03.jpg"]
[bgm storage="bgm_04.ogg"]
;****************************************

[::]
那么，下个周末来临了。[rhp]
今天是抵达下一颗星球的日子。[rhr]
为了听取目的地的公布，众人齐聚在食堂。[rhp]

而现在，我正一次性吸引着所有人的视线。[rhr]
因为下个旅行地的提议者，不是别人正是我！[rhp]

[:princess:][puri_w kao=5 ]
「诸位——！想听下个目的地吗——！？」[rhp]

[off_all]

[chara_part name="peku" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:2nin:]
「耶——！！」[rhr]
「耶——！！」[rhp]

[off_all]

[chara_part name="hakase" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:kite:][p_k_05]
「这什么角色扮演啊……」[rhp]

[:darknebula:][p_da_17]
「这是她第一次提出请求。[rhr]
_　大概是太兴奋了吧？」[rhp]

[off_all]

[chara_part name="riri" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="30" top="0" wait="false" time=150]
[chara_part name="otiai" body=base kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="drop" body=base kao=1 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="760" top="0" wait="true" time=150]

[:otiai:][p_ot_04]
「目的地……？在说什么？」[rhp]

[:quadrillion:][p_r_15]
「每周末都会按各自意愿去旅行地。[rhr]
_　上次是我的提议去了南国度假村」[rhp]

[:otiai:]
「哼嗯……」[rhp]

[:drop:][drop kao=13 ]
「落合的提议会留到下次听取。[rhr]
_　这样正好完成全员轮流提议的循环」[rhp]

[:otiai:][otiai kao=12 ]
「……明白了。我会考虑的」[rhp]

[off_all]

[chara_part name="kite" body=base kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=1 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:kite:][p_k_04]
「所以？这辆电车到底开往哪里」[rhp]

[:princess:][puri_w kao=11 ]
「哼哼！问得好。[rhr]
_　这次令人期待的目的地是……！」[rhp]
[:princess:][puri_w kao=5 ]
[font size=30]
「是山！」[rhp]
[resetfont]

[:kite:][kite kao=8 ss=on ]
「…………」[rhp]

[:princess:]
「而且不是普通的山。是去露营！！」[rhp]

[off_kite]

[:darknebula:][hakase kao=0 ][p_da_19]
「诶？但那个，」[rhp]

[:princess:][puri_w kao=13 ]
「我懂博士想说。这不是大上次才去过吗？」[rhp]
[:princess:]
「是这样的啊。[rhr]
_　虽然是我失去记忆前的事，但大家确实去露营过对吧」[rhp]

[:darknebula:][hakase kao=0 ]
「对啊。虽然我完全不介意，但大家却……」[rhp]

[off_all]

[chara_part name="riri" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:quadrillion:][p_r_25]
「不要！山什么的绝～～～～～～对不要！[rhr]
_ 会有超大的蚂蚁啊蚊子啊水蛭啊什么的！啊啊太恶心了……！」[rhp]

[:kite:][p_k_25]
「请不要给身心都如此纤细的我施加试炼了」[rhp]

[:princess:][puri_w kao=6 ]
「哼哼，随你怎么说都好。[rhr]
_　今天可是我的国王之日，概不接受反驳哦—」[rhp]

[off_all]

[:drop:][drop kao=13 as=on ]
「虽然并没有什么国王制度就是了……」[rhp]

[:princess:][puri_w kao=6 ]
「嘛该怎么说呢，认真讲的话……我啊[rhr]
_　今后想为了找回记忆而努力呢」[rhp]

[off_drop]

[chara_part name="otiai" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:otiai:][p_ot_10]
「这是吹的哪阵风？」[rhp]

[:vulpecula:][p_vl_04]
「不用勉强自己也行哦～？[rhr]
_　想不起事情的轻飘飘小公主我也超喜欢的！」[rhp]

[:princess:][puri_w kao=1 ]
「你能这么说我很开心[rhr]
_　但也不能永远这样下去啊」[rhp]

[off_all]

[:princess:]
[font color=0x4682b4]
（……而且，也和夜约定好了。[rhr]
_　要好好整理自己的事情，以能够接受的形式离开这个地方……）[rhp]
[resetfont]

[:drop:][drop kao=0 ][p_d_04]
「怎么了？」[rhp]

[:princess:][puri_w kao=13 as=on ]
「！没、没什么啦」[rhp]

[off_drop]

[:princess:][puri_w kao=3 as=on ]
[font color=0x4682b4]
(啊，好险好险。我表情也太容易暴露内心了。居然没注意到）[rhp]
[:princess:]
（不要在大家面前想关于夜的事吧。[rhr]
_　在这么愉快的氛围里，想着旅途的结束……难免会寂寞）[rhp]
[resetfont]

[off_puri]

[::]
―――有个自己总想着，要是不存在所谓的『满意结果』就好了。[rhp]
或者说，那才是真正的心声。[rhr]
如果恢复记忆的话，或许能找到说服夜的论据。[rhp]
当着夜的面说了那些话……[rhr]
但其实我心里并非没有不想结束这趟旅程的想法。[rhp]

[:princess:][puri_w kao=13 as=on ]
「总、总之我是认真的！[rhr]
_　所以我打算先尝试和失忆前做相同的事」[rhp]

[:heartshape:][hati kao=5 ][p_h_02]
「再微小的可能性也该尝试！这总没错吧！」[rhp]

[:princess:][puri_w kao=13 ]
「是吧是吧？」[rhp]

[:jet:][jet kao=6 ][p_j_17]
「只要别变成无休止回溯就行。追溯过去也该有个限度」[rhp]

[:princess:][puri_w kao=6 as=on ]
「应、应该没问题……大概……」[rhp]

[off_all]

[puri_w kao=14 ]
「总之！现在你们明白理由了吧？[rhr]
_　从今天开始要过山居生活，所以要做好万全准备哦！」[rhp]

[off_all]

[chara_part name="riri" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:2nin:]
「好～～～～吧……」[rhr]
「好～～～～吧……」[rhp]

[:princess:][puri_w kao=2 ]
「明显干劲不足啊……！」[rhp]

[off_all]

[chara_part name="otiai" body=base kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:]
「佩奇也最喜欢山了！[rhr]
_　今天打算征服躺椅！」[rhp]

[:otiai:]
「是说攀岩吧……嘛，我也不讨厌就是了」[rhp]

[:princess:][puri_w kao=5 hh=on ]
「谢谢你们俩……！好嘞，既然决定了[rhr]
_　现在距离目的地还有时间，三人一起预习露营生活吧！」[rhp]

[:2nin:]
「遵命！！」[rhr]
「是是……」[rhp]

[off_all]

[::]
将那些面露不满或微妙神色的成年人们抛在一边，[rhr]
我带着为数不多的支持者，决定从餐车前往客车车厢。[rhp]

[:quadrillion:][riri kao=7 ][p_r_18]
「――――――真是可悲呢。某种程度来说」[rhp]

[:kite:][kite kao=12 ][p_k_28]
「不也挺好的。随她喜欢吧」[rhp]
[:kite:]
「只要南还牵扯其中，记忆就绝对无法恢复……[rhr]
_　不管做什么都是白费力气，总有一天会明白的」[rhp]

[off_all]

[chara_part name="jet" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:]
「你们真冷淡啊！我和杰特可是会声援的！[rhr]
_　为公主的奋斗喝彩！对吧，杰特！？」[rhp]

[:jet:][hati kao=11 ]
「我选择追随哈蒂」[rhp]

[off_all]

[:drop:][drop kao=8 as=on ][p_d_29]
「不过各位。即便再怎么提不起兴致，[rhr]
_　表现得太露骨不是会让那姑娘显得很可怜吗」[rhp]

[:quadrillion:][riri kao=2 ][p_r_26]
「我说你啊，别小看山里的虫子！[rhr]
_　城里人……不，银河住民肯定不会明白的，」[rhp]

[:drop:][drop kao=14 as=on ]
「完全没问题的夸德里利昂。[rhr]
_　这次要爬的山和之前那座根本是两回事！」[rhp]

[:quadrillion:][riri kao=0 ]
「哈？什么意思」[rhp]

[off_all]

[chara_part name="jet" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="736" top="0" wait="true" time=150]

[:jet:][p_j_23]
「该不会又要说什么雪山之类的话吧」[rhp]

[:heartshape:][p_h_31]
「那个好啊！得赶紧提交喜马拉雅登山计划书了！」[rhp]

[:kite:][kite kao=13 ]
「不不，就算是多洛普[rhr]
_　也不会搞这么老套的展开吧。遇难结局太显而易见了」[rhp]

[off_all]

[:drop:][drop kao=5 ][p_d_31]
「哼哼哼……！快斗先生。[rhr]
_　我在旅行目的地的选择上也很注重『关联性』。」[rhp]
[:drop:]
「上次的目的地是加勒比的度假胜地对吧？[rhr]
_　说到海就是夏天。说到夏天就是炎热。说到炎热呢？」[rhp]

[:darknebula:][hakase kao=5 ]
「热带雨林！」[rhp]

[:drop:][drop kao=14 ]
「完全正确～！！　这次的旅行目的地虽是山，但可是亚马逊的热带雨林哦！」[rhp]

[off_all]

[chara_part name="hati" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=2 as=on ss=on hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time="150"]

[:heartshape:][p_h_18]
「亚马逊！？」[rhp]

[:kite:]
「疯了吗？丛林这种地方根本就是明摆着会……」[rhp]

[off_all]

[chara_part name="hakase" body=base kao=5 as=off ss=off hh=on hr=on msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="drop" body=base kao=5 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:darknebula:][p_da_08]
「反而更让人期待了！[rhr]
_　因为丛林充满了未知与发现！」[rhp]

[:drop:]
「您能喜欢是我的荣幸！[rhr]
_　我想应该能体验到与上次不同的乐趣！」[rhp]

[off_all]

[:drop:][drop kao=13 ]
「那么各位也请好好准备吧！」[rhp]

[off_all]

[chara_part name="riri" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="jet" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:quadrillion:][p_r_30]
「别说虫子了，这根本是能不能活着回来的问题。[rhr]
_　不过在这里的时候还没有死亡的概念就是了……」[rhp]

[:jet:]
「话说总觉得搞错了什么重要的地方……」[rhp]

[off_all]

;****************************************
[fbgm]
;謎の空間
[set_b storage="hsps_03x.jpg"]
[bgm storage="bgm_01.ogg"]
;****************************************

[::]
那时，某个异空间中……[rhp]

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
[vostart]
;--------------------------------------------------------------------------------------------

[:mataroko:][mata kao=6 as=on ]
「真是的～～～～～！！请您适可而止，努西大人！！」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:nusi:][nusi kao=3 ss=on ]
「……………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[chara_part name="mata" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="nusi" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:mataroko:]
「每次大输特输后都这样消沉很让人困扰啊！[rhr]
_　今天可是工作日，要工作了！」[rhp]
[:mataroko:]
「我们因为上次去了海边已经休息过一次了吧！[rhr]
_　但这次目的地是山区！　现在不努力要等到什么时候！」[rhp]

[:nusi:]
「可恶……我再也不要坐什么海了」[rhp]

[:mataroko:]
「CR大●物语的话题请就此打住！」[rhp]

[off_all]

[:gonzalez:][gon kao=2 as=on ]
「！！　原来如此。我们只是单纯不擅长水边行动，[rhr]
_　但大哥是因为心理创伤才讨厌海啊……真是深奥……」[rhp]

[:mataroko:][mata kao=2 ]
「连小刚也不要开玩笑了！」[rhp]

[:gonzalez:][gon kao=5 ]
「可是大姐头。照这个状态大哥今天怕是派不上用场。[rhr]
_　就咱们俩去现场也是个办法」[rhp]

[:mataroko:][mata kao=6 ]
「那不成。铁道诸位正期盼着我们三人同往。[rhr]
_　若辜负期待，可是表演者之耻」[rhp]
[:mataroko:][mata kao=5 ]
「再说……没问题。这种时候正是南登场的机会」[rhp]

[:gonzalez:][gon kao=6 ]
「就算叫南来也挽回不了大哥的败局啊……」[rhp]

[off_all]

[:sausu:][sausu ]
「有人叫我？」[rhp]

[off_all]

[chara_part name="gon" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time="150"]

[:gonzalez:]
「哇！吓我一跳」[rhp]

[:sausu:]
「呵呵呵。我可是对传言很敏感的」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:nusi:][nusi kao=3 ss=on ]
「……………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[chara_part name="mata" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sausu:]
「哎呀呀。努西小姐怎么了，这么伤心」[rhp]

[:mataroko:]
「自从水晶连线没中就一直那样」[rhp]

[:sausu:][sausu kao=13 ]
「这样啊。水晶的话，我更喜欢紫水晶呢」[rhp]

[:mataroko:][mata kao=2 ]
「不是的。所谓水晶连线是指……[rhr]
_　啊算了现在说这个毫无意义」[rhp]
[:mataroko:][mata kao=8 as=on ]
「拜托了南。用你万能的力量，[rhr]
_　希望您能让那边没出息的兔子重新振作起来」[rhp]
[:mataroko:]
[font size=30]
「简而言之，请借我钱！」[rhp]
[resetfont]

[:sausu:][sausu kao=14 as=on ]
「钱、钱～？宝石的话倒是有……」[rhp]

[off_all]
[yurasu]

[:nusi:][nusi kao=2 ss=on ]
[font size=27]
「小石子能当弹珠用吗！！！」[rhp]
[resetfont]

[off_all]

[:sausu:][sausu kao=6 as=on ]
「哇哦……」[rhp]

[off_all]

[chara_part name="nusi" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left=645 top=0 wait="true" time=150]

[:nusi:]
「你这混蛋别瞧不起人……没有演出费连新机器都排不上号……[rhr]
_　老子这身体早就不是中个小奖就能满足的了！」[rhp]

[:sausu:]
「没、没有瞧不起你。而且我们的关系又不是工资制对吧」[rhp]

[off_all]

[chara_part name="mata" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="293" top="0" wait="false" time="150"]
[chara_part name="gon" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="720" top="0" wait="true" time=150]

[:mataroko:]
「说到底！原本就是南不好」[rhp]

[:sausu:][sausu kao=8 as=on ]
「嗯？」[rhp]

[:mataroko:]
「努西大人会沉迷弹珠机，不正是因为你给等待中的我们准备了[rhr]
_　满是本地老爷爷的热闹商店街当消遣嘛！」[rhp]

[:gonzalez:][gon kao=12 ]
「那种地方当然会有虽然老旧却氛围绝佳的老字号弹珠店，[rhr]
_　目标用户的大哥们会着迷也是理所当然」[rhp]

[:sausu:][sausu kao=11 ]
「呵呵呵！那是因为民俗学者博士告诉我，[rhr]
_　那里是个能永远消磨时间的好地方才准备的哟」[rhp]

[:gonzalez:][gon kao=14 ]
「啊～这个我懂！俺也在那个拱廊底下边走边吃可乐饼的日子里，[rhr]
_　真希望那个拱廊能永远延伸下去啊」[rhp]

[:mataroko:][mata kao=14 hh=on ]
「小刚也常去吗？超好吃的对吧～！[rhr]
_　店里的阿姨也超级温柔的！」[rhp]

[:sausu:][sausu kao=14 ]
「诶～、这样啊！[rhr]
_　其实俺也挺感兴趣的～。方便的话下次带俺去呗，」[rhp]

[yurasu]

[:mataroko:][mata kao=2 as=on ss=on ]
「喂！那种事怎样都好快想办法处理约尔大人啊～～～！！」[rhp]

[:gonzalez:][gon kao=2 as=on ]
「那群家伙马上就要到营地会场了！[rhr]
_　咱们不去迎接还有谁去迎接啊！」[rhp]
[:gonzalez:]
「听说上次矢部亲老师表现相当活跃。[rhr]
_　咱们怎么能输啊！」[rhp]

[:sausu:][sausu kao=0 ]
「？听说，听谁说的？」[rhp]

[:mataroko:][mata kao=6 as=on ]
「是约尔大人呀！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:sausu:][sausu kao=2 ]
「……！」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:mataroko:][mata kao=6 ]
「她时不时会像间谍一样来打探我们的近况呢」[rhp]
[:mataroko:]
「那时候听说的。[rhr]
_　上次矢部亲老师和米卡小姐差点就追上姐姐们了」[rhp]

[:gonzalez:][gon kao=5 as=on ]
「不过听说结果惨不忍睹就是了」[rhp]

[:sausu:][sausu kao=3 ]
「……哼嗯……约尔大人她……」[rhp]

[:gonzalez:][gon kao=11 ]
「真是勤快啊，糠星的那位当家的」[rhp]

[:mataroko:][mata kao=5 ]
「和整天晃悠散步的您可不一样呢」[rhp]

[:sausu:][sausu kao=6 ]
「～～～……。[rhr]
_　对说这种坏话的孩子，钱和可乐饼都不会给的」[rhp]

[off_all]

[yurasu]

[chara_part name="mata" body=base kao=4 as=on ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="gon" body=base kao=4 as=on ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]


[:2nin:]
[font size=27]
「！！！！！」[rhr]
「！！！！！」[rhp]
[resetfont]

[off_all]

[:sausu:][sausu kao=3 ]
「但是，这样……约尔大人……是在探查我的举动吗」[rhp]
[:sausu:]
「………………有点不爽啊，那个……」[rhp]

[off_all]

[chara_part name="mata" body=base kao=14 as=off ss=off hh=on hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="293" top="0" wait="false" time="150"]
[chara_part name="gon" body=base kao=14 as=off ss=off hh=on hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="720" top="0" wait="true" time=150]

[:mataroko:]
「南！刚才的相当不错呢～！」[rhp]

[:sausu:]
「咦？　什么？」[rhp]

[:gonzalez:]
「把钱『不给』和可乐饼『不炸』双关了吧？[rhr]
_　这不是挺会玩梗的嘛！」[rhp]

[:mataroko:]
「不禁让人佩服呢！」[rhp]

[:sausu:][sausu kao=5 as=on hh=on ]
「哎～！？那、那是？巧合啦，巧合！」[rhp]

[off_all]

[:nusi:][nusi as=on ss=on ]
[font color=0x4682b4]
（没救了这群人……我不认真点的话……）[rhp]
[resetfont]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
[fbgm]
[set_00 storage="sky_04.jpg"]
;****************************************

之后电车又行驶了几个小时，我们抵达了目的地的星球。[rhp]

;****************************************
[bgm storage="bgm_25.ogg"]
[bg storage="jungle_01.jpg" time=1500]
;****************************************

[:princess:][puri_w kao=5 hh=on ]
「呵呵……！终于来了！前往伟大的丛林！」[rhp]

[:otiai:][otiai kao=13 as=on ss=on ][p_ot_17]
「我们预习的，好像是日本的露营场地来着……」[rhp]

[:princess:][puri_w kao=13]
「好啦好啦，这样也挺正宗不错的嘛！」[rhp]

[:otiai:][otiai kao=2 as=on ss=on  ]
「太正宗了吧！绝对不是外行人去的地方！」[rhp]

[off_all]

[chara_part name="riri" body=base kao=3 as=off ss=on hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=6 as=off ss=on hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:kite:][p_k_05]
[font size=14]
「好热……要化了～～……」[rhp]
[resetfont]

[yurasu]

[:quadrillion:][riri kao=8 as=on ]
[font size=25]
「呀"啊"！虫子爬衣服上了啦！[rhr]
_　搞什么嘛真是的～～！快斗快弄掉～～！」[rhp]
[resetfont]

[:kite:][kite kao=11 ]
「来，茄子」[rhp]

[:quadrillion:][riri kao=2 as=on ][p_r_21]
「不是让你拍那边啦！[rhr]
_　可恶……为什么无辜的我要遭这种罪……！」[rhp]

[off_all]

[chara_part name="hakase" body=base kao=1 as=off ss=off hh=off hr=on msk=hat ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="peku" body=hood kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:][p_vl_04]
「喂～博士～！那些在到处嘎嘎叫的鸟叫什么名字呀～？」[rhp]

[:darknebula:][p_da_02]
「是笑翠鸟呢。生活在亚马逊的种族哦。[rhr]
_　你看，就是停在那棵树上的小家伙们。能看见吗？」[rhp]

[:vulpecula:][peku body=hood kao=14 hh=on ][p_vl_31]
「嗯～～～～？……啊看见了！好可爱～！」[rhp]

[off_all]

[chara_part name="jet" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="drop" body=base kao=5 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:jet:][p_j_17]
「话说回来，这地方还真是相当深入啊……」[rhp]

[:drop:][p_d_15]
「我豁出去了！」[rhp]

[:jet:][p_j_04]
「我说啊。之前在铁道里听到时我就想问了，[rhr]
_　你们换个地方扎营的话，不就没法成为记忆线索了吗？」[rhp]

[:drop:][drop kao=4 as=on][p_d_19]
「诶……？」[rhp]

[off_all]

[:princess:][puri_w kao=1 ]
「对了，上次露营是去的哪座山来着？」[rhp]

[chara_part name="jet" body=base kao=11 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:jet:]
「北阿尔卑斯」[rhp]

[:heartshape:][p_h_02]
「长野县啊喂！」[rhp]

[:princess:][puri_w kao5 as=on ]
「原、原来是这样……」[rhr]
[font color=0x4682b4]
（既然都特意来了，直接去真正的阿尔卑斯不是更好……）[rhp]
[resetfont]

[off_all]

[:drop:][drop kao=14 as=on ][p_d_28]
「没、没关系啦！！重要的不是地点，[rhr]
_　而是露营这项活动本身，您不觉得吗？」[rhp]

[:princess:][puri_w kao=13 as=on ]
「是这样吗？」[rhp]

[:drop:][drop kao=14 as=on ]
「当、当然是这样啦！[rhr]
_　比起这个你看，还是快点分配任务吧」[rhp]

[:princess:][puri_w ]
「哦，好像越来越专业了嘛。具体有些什么分工？」[rhp]

[:drop:][drop ][p_d_02]
「首先分成搭建帐篷的小组和采集食物的小组。[rhr]
_　这样各项任务都能更有效率地进行」[rhp]

[:princess:][puri_w ]
「那是？用木棍摩擦另一根木头生火的工作？」[rhp]

[off_all]

[:otiai:][otiai kao=2 as=on ]
[font color=0x4682b4]
（这家伙，该不会把露营和遇难搞混了吧？）[rhp]
[resetfont]

[:darknebula:][hakase msk=hat ][p_da_06]
「那么现在立刻开始分组吧。[rhr]
_　考虑到熟练度，有经验者和上次负责相同工作如何？」[rhp]

[off_all]

[chara_part name="peku" body=hood kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:vulpecula:][p_vl_16]
「那佩奇和博士去打猎吧！？OK，包在我身上！」[rhp]

[:kite:]
「只钓鱼的话倒是挺轻松的」[rhp]

[off_all]

[chara_part name="jet" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=11 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:][p_h_04]
「我们是采水果组！不错吧杰特！？」[rhp]

[:jet:]
「哈蒂没意见的话我也无所谓」[rhp]

[off_all]

[chara_part name="riri" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="drop" body=base kao=1 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:drop:]
「我和夸德里利昂负责搭帐篷。[rhr]
_　加油吧，夸德里利昂！」[rhp]

[:quadrillion:][p_r_29]
「好好好。真拿你没办法呢……」[rhp]

[:drop:]
「公主和落合要怎么办？[rhr]
_　　我觉得加入喜欢的组别就好」[rhp]

[:princess:][puri_w kao=1 ]
「嗯——我想想」[rhp]

[off_all]

[:otiai:][otiai kao=7 ]
「我跟博士他们走」[rhp]

[off_all]

[chara_part name="hakase" body=base kao=1 as=off ss=off hh=off hr=on msk=hat ]
[chara_show name="hakase" layer="1" width="571" height="720" left="40" top="0" wait="false" time=150]
[chara_part name="peku" body=hood kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="355" top="0" wait="false" time="150"]
[chara_part name="otiai" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="760" top="0" wait="true" time=150]

[:darknebula:][p_da_03]
「哦？和我们吗？虽然欢迎，但有点意外呢」[rhp]

[:otiai:]
「因为看起来最安全」[rhp]

[:vulpecula:][p_vl_15]
「小落合太像菜鸟啦！[rhr]
_　让姐姐来教你打猎的诀窍吧！」[rhp]

[:otiai:][otiai kao=7 ]
「是是。多谢……」[rhp]

[off_all]

[:princess:][puri_w kao=7 ]
（落合君居然选博士他们。那么……)[rhp]

;--------------------------------------------------------------------------
;--------------------------------------------------------------------------
;--------------------------------------------------------------------------
;好感度分岐。130点以上で分岐

;ドロップ
[if exp="130 <= f.love_d "]
[jump target="*drop"]

; カイト
[elsif exp="130 <= f.love_k "]
[jump target="*kite"]

; クリリン
[elsif exp="130 <= f.love_r "]
[jump target="*riri"]

; 双子
[elsif exp="130 <= f.love_h "]
[jump target="*hati"]

; どれでもない
[else]
[jump target="*drop2"]

[endif] 
;--------------------------------------------------------------------------
;--------------------------------------------------------------------------
;--------------------------------------------------------------------------

;--------------------------------------------------------------------------
*drop
;--------------------------------------------------------------------------

; 好感度+50
[eval exp="f.d_love = f.d_love + 50"]
; 後半の分岐フラグ
[eval exp="f.a06_d = 1"]
[jump target="*drop3"]

*drop2
; 後半の分岐フラグ
[eval exp="f.a06_d2 = 1"]

*drop3

[:princess:][puri_w ]
「……我想去帮忙多洛普和克林他们！」[rhp]

[:drop:][drop kao=13 ][p_d_07]
「可以吗？帮大忙了。[rhr]
_　上次的搭建工作，即便是两个人一起干也很费力呢」[rhp]

[:quadrillion:][riri kao=11 ][p_r_15]
「哼。就凭你那细胳膊细腿的能干什么啊」[rhp]

[:princess:][puri_w kao=5 ]
「可别小看我。虽然看起来这样，我对体力还是很有自信的！」[rhp]

[:drop:][drop kao=14 ][p_d_31]
「真可靠！那就拜托你啦，公主」[rhp]

[:princess:][puri_w kao=13 ]
「OK！包在我身上！」[rhp]

[jump target="*tutti"]

;--------------------------------------------------------------------------
*kite
;--------------------------------------------------------------------------

; 好感度+50
[eval exp="f.k_love = f.k_love + 50"]
; 後半の分岐フラグ
[eval exp="f.a06_k = 1"]

[:princess:][puri_w ]
「……我，想去帮快斗钓鱼」[rhp]

[:kite:][kite kao=0 ][p_k_17]
「嗯。毕竟上次也是这样」[rhp]

[:princess:][puri_w kao=4 hh=on ]
「真的吗！？」[rhr]
[font color=0x4682b4]
（该、该不会是记忆复苏的征兆吧！？）[rhp]
[resetfont]

[:kite:][kite kao=1 ][p_k_31]
「因为我中途睡着了，[rhr]
_　全靠公主钓了很多鱼帮了大忙呢」[rhp]
[:kite:][kite kao=13 ]
「这次也拜托你了，公主」[rhp]

[:princess:][puri_w kao=6 as=on ]
「诶……好、好的……」[rhr]
[font color=0x4682b4]
（没问题吗……对钓鱼新手来说负担太重了吧……）[rhp]
[resetfont]

[jump target="*tutti"]

;--------------------------------------------------------------------------
*riri
;--------------------------------------------------------------------------

; 好感度+50
[eval exp="f.r_love = f.r_love + 50"]
; 後半の分岐フラグ
[eval exp="f.a06_r = 1"]

[:princess:][puri_w ]
「……我，想去和夸德里利昂一起帮多洛普」[rhp]

[:drop:][drop ][p_d_07]
「可以吗？帮大忙了。[rhr]
_　上次的搭建工作，即便是两个人一起干也很费力呢」[rhp]

[:quadrillion:][riri kao=11 ][p_r_31]
「哼。就凭你那细胳膊细腿的能干什么啊」[rhp]

[:princess:][puri_w kao=5 ]
「可别小看我。虽然看起来这样，我对体力还是很有自信的！」[rhp]

[:quadrillion:][riri kao=5 ]
「哦。那你就好好努力吧」[rhp]

[:princess:][puri_w kao=11 ]
「哼哼！不用你说我也会的！」[rhp]


[jump target="*tutti"]

;--------------------------------------------------------------------------
*hati
;--------------------------------------------------------------------------

; 好感度+50
[eval exp="f.h_love = f.h_love + 50"]
; 後半の分岐フラグ
[eval exp="f.a06_h = 1"]

[:princess:][puri_w ]
「……我，想和哈蒂君他们一起去摘水果」[rhp]

[chara_part name="jet" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:][p_h_04]
「噢，好啊！[rhr]
_　三个人的话齐心协力，说不定能爬到更高的树上！」[rhp]

[:jet:][p_j_03]
「你，会爬树吗？」[rhp]

[:princess:][puri_w kao=2 as=on ]
「能…………」[rhp]
[:princess:][puri_w kao=6 as=on ]
[font size=13]
「……………………的，吧」[rhp]
[resetfont]

[:heartshape:][hati kao=13 ][p_h_31]
「不要紧！把掉下去的东西回收也是重要的工作！」[rhp]

[:princess:][puri_w kao=8 hh=on ]
「哈蒂君……！好温柔～！」[rhp]

[:jet:][jet kao=6 ][p_j_17]
「这种工作连猴子都能做……」[rhp]


;--------------------------------------------------------------------------
;--------------------------------------------------------------------------
*tutti

[off_all]

[:jet:][jet kao=12 ]
「……………………」[rhp]

[off_all]

[chara_part name="jet" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:][p_h_19]
「嗯？怎么了杰特？」[rhp]

[:jet:][jet kao=5 ][p_j_15]
「呐哈蒂。我现在想到个超棒的主意」[rhp]

[off_all]

[:jet:]
「我说啊……」[rhp]
[:jet:]
「………………、………………」[rhp]

[chara_part name="jet" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=4 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:jet:][p_j_16]
「…………这样如何？」[rhp]

[:heartshape:][hati kao=5 as=on hh=on ][p_h_08]
「什么啊这个！超有趣！！」[rhp]

[:jet:][jet kao=14 ]
「对吧？」[rhp]

[off_all]

[:quadrillion:][riri kao=6 ][p_r_19]
「那边的红白。鬼鬼祟祟干什么呢？[rhr]
_　该不会又在打什么坏主意吧」[rhp]

[:heartshape:][hati kao=5 ][p_h_06]
「克林！！谢谢你立下FLAG！！」[rhp]

[:quadrillion:][riri kao=0 ][p_r_10]
「哈？」[rhp]

[off_all]

;****************************************
;閃光
[se storage="mag_10.ogg"]
[bg_rule storage="white.jpg" rule="027.png" time=200]
;****************************************

[:quadrillion:]
「呀啊！等、好刺眼……！什么！？怎么回事！？」[rhp]

;---------------------------------------------------------------------------------------------
;---------------------------------------------------------------------------------------------

;クリリン√ならここでジャンプ

[if exp="f.a06_r == 1 "]
[jump storage="ev_a_06_riri.ks" target="*start"]
[endif] 

;---------------------------------------------------------------------------------------------
;---------------------------------------------------------------------------------------------

;****************************************
#
[bg storage="jungle_05.jpg" time=1500]
;****************************************

[:quadrillion:][riri kao=2 as=on ss=on ]
「………………………………」[rhp]
[:quadrillion:]
「……怎、怎么……！」[rhp]

[off_all]

[yurasu]

[:quadrillion:][font size=28]
「这是什么啦！？这里是哪里～～～！！？？」[rhp]
[resetfont]

;****************************************
[bg_rule storage="jungle_01.jpg" rule="011.png" time=500]
;****************************************

[:princess:][puri_w kao=2 as=on ]
「………？刚、刚才什么情况？闪了超强的光」[rhp]

[:vulpecula:][peku body=hood kao=7 ][p_vl_19]
「咦—，克林去哪了—？」[rhp]

[:princess:][puri_w kao=4 as=on ]
「啊？……诶！？刚才还在这里的！」[rhp]

[off_all]

[chara_part name="otiai" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:otiai:][p_ot_26]
「…………，哈托谢普。是你搞的鬼吧」[rhp]

[:heartshape:][hati kao=5 ][p_h_24]
「哦！落合直觉真准！完全正确！[rhr]
_　犯人―――不对，怪盗鲁邦四世正是在下！！」[rhp]
[:heartshape:]
[font size=26]
「老子把克林偷走啦！！」[rhp]
[resetfont]

[:otiai:][otiai kao=2 as=on ]
「嗯？」[rhp]

[off_all]

[chara_part name="jet" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="drop" body=base kao=2 as=on ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:jet:][p_j_15]
「克林就在这片森林的某个地方。[rhr]
_　哈蒂用魔法把他轰飞到不知哪里去了」[rhp]

[:drop:][p_d_13]
「为什么要这么做！？」[rhp]

[:jet:][jet kao=14 ]
「哎呀——光是重复露营也太无聊了吧。[rhr]
_　我觉得第二次来点小意外也不错」[rhp]

[:drop:]
「遇、遇难算是『小』意外……！？」[rhp]

[off_all]

[chara_part name="otiai" body=base kao=5 as=on as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="peku" body=hood kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:][p_vl_31]
「啊哈哈哈！这不是寻宝，是寻人游戏啊！！」[rhp]

[:otiai:]
「真无聊……不过倒不讨厌」[rhp]

[off_all]

[chara_part name="drop" body=base kao=6 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=11 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:drop:][p_d_17]
「虽然很想立刻去搜寻，但所有人盲目移动效率太低。[rhr]
_　我认为派代表去探索比较妥当……」[rhp]

[:kite:][kite kao=7 ]
「弃权。大海在召唤我」[rhp]

[off_all]

[chara_part name="peku" body=hood kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720"  left="40" top="0" wait="false" time=150]
[chara_part name="jet" body=base kao=11 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720"  left="421" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="760" top="0" wait="true" time=150]

[:vulpecula:][p_vl_10]
「太阳下山动物就要归巢！我们可不行！」[rhp]

[:jet:]
「太阳下山水果就要归巢。我们也不行」[rhp]

[:heartshape:]
[font color=0x4682b4]
（水果是活的……！？不愧是杰特！见多识广！）[rhp]
[resetfont]

[off_all]

[chara_part name="hakase" body=base kao=0 as=off ss=off hh=off hr=on msk=hat ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="otiai" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:otiai:][p_ot_29]
「你们还有闲心开玩笑。[rhr]
_　那个娘娘腔现在正一个人在丛林里吧。太危险了」[rhp]

[:darknebula:][hakase kao=3 as=on msk=hat ][p_da_18]
「落合说得对。夜晚的丛林很危险。[rhr]
_　就算以他那身肌肉，独自过夜也够呛」[rhp]

[:otiai:]
「话说也够可怜的……」[rhp]

[off_all]

[:jet:][jet kao=6 ][p_j_29]
「切……好啦好啦，知道了。虽然无聊但也没办法」[rhp]

[off_all]

;--------------------------------------------------------------------------
;--------------------------------------------------------------------------
;各ルートへ

[if exp="f.a06_d == 1 "]
[jump storage="ev_a_06_drop.ks" ]

[elsif exp="f.a06_k == 1 "]
[jump storage="ev_a_06_kite.ks" ]

[elsif exp="f.a06_h == 1 "]
[jump storage="ev_a_06_hati.ks" ]

[else]
[jump storage="ev_a_06_drop.ks" ]
[endif] 

;-------------------------------------------------------------------------
;--------------------------------------------------------------------------

*start2

;--------------------------------------------------------------------------------------------
;▼フルボイスセット▼
;ドロップ
[voconfig sebuf=1 name=drop vostorage="drop/full/{number}.ogg" number=58]
;カイト
[voconfig sebuf=1 name=kite vostorage="kite/full/{number}.ogg" number=97]
;クォードリリオン
[voconfig sebuf=1 name=riri vostorage="riri/full/{number}.ogg" number=47]
;ジェット
[voconfig sebuf=1 name=jet vostorage="jet/full/{number}.ogg" number=45]
;ダークネブラ
[voconfig sebuf=1 name=hakase vostorage="hakase/full/{number}.ogg" number=36]
;ヴルペクラ
[voconfig sebuf=1 name=peku vostorage="peku/full/{number}.ogg" number=29]
;オチアイ
[voconfig sebuf=1 name=otiai vostorage="otiai/full/{number}.ogg" number=47]

;--------------------------------------------------------------------------------------------

;****************************************
[fbgm]
[set_yy storage="jungle_02b.jpg"]
[bgm storage="bgm_25.ogg"]
;****************************************

[if exp="f.a06_d == 1 "]
等待着众人到来的我们，[rhr]
迎接了疲态尽显的他们，引导他们围坐在篝火旁。[rhp]

[elsif exp="f.a06_d == 0 "]
三小时后。[rhr]
当克林搜索队终于全员集合时，四周已完全入夜。[rhp]

[elseif]
好不容易重新集结到最初地点时，天色早已全黑。[rhp]

[endif] 


因为寻找克林这个意外插曲，[rhr]
我们疲惫不堪——虽然与原本的意义截然不同。[rhp]
不过围着多洛普用魔法点燃的篝火时，[rhr]
这份疲倦竟莫名令人惬意，涌起些微满足感。[rhp]

——暂且按下这类似美谈的桥段。[rhp]

;ゲンコツ
[yurasu]
[se storage="hand_06.ogg"]

[chara_part name="jet" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720"  left="650" top="0" wait="true" time="150"]

[:hutago:]
「呀！！」[rhr]
「呀！！」[rhp]

[off_all]

[:quadrillion:][riri kao=2 ss=on ][p_r_21]
「你们这群~~~~……！适可而止啊！」[rhp]

[off_all]

[::]
甫见到哈蒂君的瞬间，夸德里利昂的铁拳制裁即刻爆发。[rhp]
被痛斥的两人抱头蹲防，[rhr]
在原地蜷缩着瑟瑟发抖。[rhp]

[chara_part name="jet" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720"  left="650" top="0" wait="false" time="150"]
[chara_part name="puri_w" body=base kao=5 as=on ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「没事吧？看着好疼呢」[rhp]

[:jet:][p_j_11]
「低估了女装壮汉的臂力啊……」[rhp]

[:heartshape:][p_h_11]
「脑袋嗡嗡直响……呃！」[rhp]

[off_all]

[chara_part name="riri" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:quadrillion:]
「幸亏受害者是我才没闹大！[rhr]
_　如果这是脆弱的快斗的话，你们就要变成杀人犯了吧？」[rhp]

[:kite:][p_k_27]
「失礼了。我可是相当顽强地活下来的」[rhp]

[off_all]

[chara_part name="jet" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=11 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:jet:][p_j_28]
「说到底根本不会对快斗出手啊」[rhp]

[:heartshape:]
「克林有克林的角色定位吧！？[rhr]
_　大家各不相同才精彩！　就是这么回事！」[rhp]

[off_all]

;ゲンコツ
[yurasu]
[se storage="hand_06.ogg"]

由于这句天真多余的话，[rhr]
两人的头上再次被夸德里利昂的铁拳制裁。[rhp]

[chara_part name="hakase" body=base kao=5 as=off ss=off hh=off hr=on msk=hat ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="peku" body=hood kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:][p_vl_31]
「再差一点就能长出漫画那种大包了呢～」[rhp]

[:darknebula:][p_da_08]
「真的能形成那种包吗……好想知道！[rhr]
_　能不能再说错一次话看看」[rhp]

[off_all]

[chara_part name="jet" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:jet:][p_j_11]
「克林你这混蛋，得意忘形打得砰砰响……！[rhr]
_　下次再敢这样绝对把你揍飞……！」[rhp]

[:heartshape:][p_h_09]
「我家的杰特说到做到！！」[rhp]

[off_all]

[:gonzalez:][gon kao=6 ][p_gn_26]
「好了，吵架到此为止。难得旅行大家开心点吧！[rhr]
_　夸德里利昂也平安回来了，先把这事翻篇」[rhp]

[:quadrillion:][riri kao=2 ][p_r_10]
「我说你啊！　等被揍飞到丛林深处后[rhr]
_　再说这种话试试！？别事不关己的样子！」[rhp]

[off_all]

[:mataroko:][mata kao=14 ][p_mt_15]
「好了好了各位！总之先吃晚饭吧」[rhp]
「这可是我每周去商店街烹饪教室学习掌握的[rhr]
_　特制咖喱，请用吧！」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:vulpecula:][peku body=hood kao=3 ]
「嗯～……」[rhp]

[:mataroko:][mata kao=4 ]
「哎呀……怎么了？沃尔佩克拉」[rhp]

[:vulpecula:][peku body=hood kao=6 ]
「玛塔的咖喱看起来很好吃……[rhr]
_　看起来很好吃呢。但总觉得哪里不对啊～」[rhp]
[:vulpecula:]
「我啊，露营的话更想要这种……该怎么说呢、[rhr]
_　丛林餐！这种感觉的食物啦」[rhp]
[:vulpecula:]
「咖喱的话连克林都能做吧」[rhp]
 
[:mataroko:][mata kao=2 as=on ]
「怎、怎么可能！？这可是商业街传承四代的便当店秘传配方！！[rhr]
_　不要和克林那种普通咖喱混为一谈！！」[rhp]

[off_all]

[chara_part name="riri" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:quadrillion:]
「真失礼。我可从来没做过咖喱呢」[rhp]

[:kite:]
「为什么还有点得意……」[rhp]

[off_all]

[:mataroko:][mata kao=12 ]
「说到底丛林餐是什么啊？如果只是烤猎到的肉那就是烤肉、[rhr]
_　鱼的话就是普通烤鱼。丛林要素根本可有可无不是吗」[rhp]

[off_all]

[chara_part name="mata" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="gon" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:mataroko:]
「对吧？小刚！」[rhp]

[:gonzalez:][gon kao=12 ]
「嗯确实如大姐所说、[rhr]
_　不过沃尔佩克拉的话也有道理」[rhp]
[:gonzalez:][gon kao=6 ]
「大姐的咖喱好坏不论，确实花费了功夫」[rhp]
[:gonzalez:]
「但从真正生存的意义上来说、[rhr]
_　总觉得欠缺了点现实感啊……」[rhp]

[:mataroko:][mata kao=2 as=on ]
「什、什么意思……？」[rhp]

[:gonzalez:][gon kao=2 ]
「该怎么说呢。大姐的咖喱缺少野性……[rhr]
_　不，直白地说就是缺乏男子气概」[rhp]

[:mataroko:][mata kao=6 as=on ]
「要我这个女孩子怎么做嘛！」[rhp]

[:gonzalez:][gon kao=11 ]
「呵！别担心大姐。这里就交给我吧」[rhp]

[:mataroko:][mata kao=14 ]
「真可靠呢！只要小刚稍加调整，[rhr]
_　就能做出兼顾精致与野性的绝妙咖喱，」[rhp]

[off_all]


;****************************************

[se storage="se2_08.ogg"]
[yurasu]
;カットイン
[s_image layer="2" page="back" storage="ct/a_06_1.png" width="1260" left="10" top="40" name="nov"]
[s_trans layer="2" method="bounceInDown" time=1000]
[wt]
;****************************************

[:gonzalez:]
「看招」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:mataroko:][s_playse storage="mata/part/13.ogg" buf=1]
[font size=28]
「诶诶诶诶――！！！！」[rhp]
[resetfont]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

;****************************************
;カットイン終了
[s_freeimage layer="2" ]
;****************************************

[off_all]

[chara_part name="gon" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="peku" body=hood kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:]
「呀啊～！」[rhp]

[:gonzalez:]
「怎么样小鬼，我把丛林食材全倒进去了。[rhr]
_　这样立刻就变成丛林餐了吧！」[rhp]

[:vulpecula:]
「变啦！超级狂野！」[rhp]

[off_all]

[chara_part name="jet" body=base kao=8 as=on ss=on hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="mata" body=base kao=2 as=on ss=on hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:mataroko:]
[font size=25]
「你在干什么呀！！你在干什么呀！！[rhr]
_　好好的魔太郎子咖喱都！！」[rhp]
[resetfont]

[:jet:][jet kao=6 ]
「这不是商店街咖喱吗？」[rhp]

[:mataroko:][mata kao=2 as=on ss=on ]
[font size=25]
「人家稍微改良了一下啦！[rhr]
_　加了原创的秘制调料什么的！」[rhp]
[resetfont]

[off_all]

[chara_part name="hakase" body=base kao=13 as=off ss=off hh=off hr=on msk=hat ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="peku" body=hood kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:]
「充满丛林风情看起来超好吃～[rhr]
_　大家不吃的话就让博库来吃咯～」[rhp]

[:darknebula:]
「我也尝一口。想知道男子汉丛林咖喱的滋味」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------


[:2nin:]
[s_playse storage="hakase/full/37.ogg" buf=1]
[s_playse storage="peku/full/36.ogg" buf=2]
「我要开动啦！」[rhr]
「我开动了」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[se storage="body_01.ogg"]
―――――。[rhp]

;****************************************
;カットイン
[s_image layer="2" page="back" storage="ct/a_06_2.png" width="1260" left="10" top="40" name="nov"]
[s_trans layer="2" method="bounceInDown" time=1000]
[cg storage="ct/a_06_3.png"]
[wt]
;****************************************

[:otiai:][otiai kao=2 as=on ]
「行云流水般地……」[rhp]

[:princess:][puri_w kao=13 as=on ]
「他俩总是这样哦」[rhp]

[:otiai:]
「这样啊……」[rhp]

;****************************************
;カットイン終了
[s_freeimage layer="2" ]
;****************************************

[off_puri]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:mataroko:]
[:otiai:][otiai kao=7 ]
「……………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:princess:][puri_w ]
「？　落合君，你怎么了？」[rhp]

[:otiai:]
「这就是露营啊……」[rhp]

[off_all]

[chara_part name="riri" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="drop" body=base kao=13 as=on ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:quadrillion:]
「先说好，不是所有露营都这样的。[rhr]
_　这是相当特殊且离谱的情况哦」[rhp]

[:drop:]
「虽然是我带你来的，[rhr]
_　但要说在亚马逊搞露营本身就很那个啊」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:otiai:][otiai kao=7 ]
「………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[:princess:][puri_w kao=0 as=on ]
[font color=0x4682b4]
（落合君，果然觉得很无聊吧……[rhr]
_　第一次旅行就搞成这样，真是做了件错事）[rhp]
[resetfont]

[:princess:][puri_w kao=11 as=on ]
「那、那个…落合君。下次我们去超级豪华的地方——」[rhp]

[:otiai:][otiai kao=12 ]
「很开心哦」[rhp]
[:otiai:]
「……不过，要是你还活着的时候来可能更好」[rhp]

[:princess:][puri_w kao=0 as=on ]
「……诶……」[rhp]

[:otiai:][otiai kao=3 ]
「开玩笑的。……逗你玩的」[rhp]

[:princess:][puri_w kao=6 as=on ]
「啊、嗯……？」[rhp]

[off_puri]

[:otiai:][otiai kao=5 ]
「…………我说。那份咖喱啊」[rhp]
[:otiai:]
「要是我好好吃完的话，大家也会吃的吧」[rhp]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

[off_all]

[chara_part name="riri" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720"  left="80" top="0" wait="false" time=150]
[chara_part name="drop" body=base kao=2 as=on ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720"  left="421" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=6 as=on ss=on hh=on hr=on ]
[chara_show name="kite" layer="1" width="514" height="720"  left="760" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=8 as=on ss=off hh=on hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[playse storage="drop/part/13.ogg" buf=1] 
[playse storage="riri/part/13.ogg" buf=2]
[playse storage="kite/part/13.ogg" buf=3]

[:xnin:]
「欸！？」[rhr]
「欸！？」[rhr]
「欸！？」[rhp]

[off_all]

[:otiai:][otiai kao=11 ]
「里面的肉，是我们小队抓来的鸡肉。[rhr]
_　费了好大劲的，要是敢浪费绝不饶你」[rhp]
[:otiai:]
「奇怪的就只有那些怪草和虫一样的玩意儿，[rhr]
_　肉可是博士仔细鉴定过品种的」[rhp]

[off_all]

[:drop:][drop kao=2 as=on ss=on ]
「怪草和虫一样的玩意儿？到底是谁收集的那些东西啊」[rhp]

[off_all]

[chara_part name="jet" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720"  left="80" top="0" wait="false" time=150]
[chara_part name="nusi" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720"  left="383" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720"  left="760" top="0" wait="true" time=150]

[:nusi:]
「我可是出于好意」[rhp]

[:kite:]
「这、这只兔子……」[rhp]

[:jet:]
「兔子也不会吃虫子吧？」[rhp]

[off_all]

[:otiai:][otiai kao=12 ]
「我开动了」[rhp]

[off_all]

[:princess:][puri_w kao=2 as=on ]
「啊！！」[rhp]

[off_all]

[::]
无视众人的视线，将咖喱送入口中的落合君。[rhp]
每咀嚼一次，他的脸色就愈发阴沉，苍白的脸逐渐变得铁青。[rhr]
真的没问题吗……？[rhp]

[:otiai:][otiai kao=2 as=on ss=on ]
「……………………………………唔」[rhp]

[:princess:][puri_w kao=8 as=on ]
「落、落合君。别勉强了还是吐出来比较好……」[rhp]

[:otiai:][otiai kao=12 as=on ss=on ]
「……………………唔……嗯"……噗哈……」[rhp]
[:otiai:]
「……………………………」[rhp]
[:otiai:]
「……，………………太·美·味·了……」[rhp]

[:princess:]
[font color=0x4682b4]
（骗人……）[rhp]
[resetfont]

[:otiai:][otiai kao=5 as=on ss=on ]
「哈啊……哈啊……身为新人的我都拼上性命了。[rhr]
_　……加油啊，乘务员们」[rhp]

[off_all]

[::]
大概是为了给机舱换气而挺身而出、[rhr]
牺牲了肠胃的落合君。[rhp]
众人被这股跨越修罗场的气势所震慑，[rhr]
再也无人提出异议。[rhp]

[chara_part name="kite" body=base kao=3 as=off ss=on hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720"  left="80" top="0" wait="false" time=150]
[chara_part name="jet" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720"  left="421" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720"  left="760" top="0" wait="true" time=150]

[:kite:]
「请期待快斗老师的来世……」[rhp]

[:heartshape:]
「杰特，我数到三？一定要吃啊！？」[rhp]

[:jet:]
「你才别背叛啊！这可不是开玩笑的」[rhp]

[off_all]

[:quadrillion:][riri kao=2 as=on ][p_r_04]
「那边的三人组。你们是罪魁祸首所以要奉陪到底哦」[rhp]

[off_all]

[chara_part name="mata" body=base kao=3 as=on ss=on hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720"  left="80" top="0" wait="false" time=150]
[chara_part name="nusi" body=base kao=2 as=on ss=on hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720"  left="383" top="0" wait="false" time=150]
[chara_part name="gon" body=base kao=2 as=on ss=on hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720"  left="720" top="0" wait="true" time=150]

[:3nin:]
「啥！？」[rhr]
「啥！？」[rhr]
[font size=13]
「魔太郎子咖喱……从前天就开始熬制的魔太郎子咖喱啊啊啊……」[rhp]
[resetfont]

[off_all]

[:drop:][drop kao=6 as=on ][p_d_09]
「……诸位。做好觉悟吧」[rhp]

[off_all]

[:drop:]
「………………我开动了！！」[rhp]

;****************************************
[set_time_d]
;****************************************

[:yabu:][yabu kao=5 ]
[font size=25]
「名医・参上！！」[rhp]
[resetfont]

[off_all]

[:mika:][mika kao=14 ]
「米卡亲参上♡」[rhp]

[off_all]

[:yabu:][yabu kao=11 ]
「听说你们这群家伙。这次的生存露营对吧！[rhr]
_　宴会正酣，差不多该是身体渴望糖分的时候了吧？」[rhp]
[:yabu:][yabu kao=5 ]
「啊啊正好，把这棉花糖赏给你们！！[rhr]
_　作为交换，把铁道让给我们――――」[rhp]

[off_all]

;****************************************
;カットイン
[s_image layer="2" page="back" storage="ct/a_06_2b.png" width="1260" left="10" top="40" name="nov"]
[s_trans layer="2" method="bounceInDown" time=500]
[cg storage="ct/a_06_3b.png"]
[wt]
;****************************************

[:mika:]
「尸横遍野呢」[rhp]

[:yabu:]
「明明已经死过了却还要在这里再死一次，[rhr]
_　这帮家伙到底有多受虐啊……」[rhp]

;****************************************
;カットイン終了
[s_freeimage layer="2" ]
;****************************************

[yabu kao=2 ]
「不过，怎么可能！肯定是察觉到我们袭击，[rhr]
_　装死蒙混过关的诡计吧」[rhp]

[:mika:][mika kao=5 ]
「噢～！老师今天好聪明！」[rhp]

[:yabu:][yabu kao=14 ]
「哈哈哈！蠢货们。才不会中这种计！」[rhp]
[:yabu:]
「哎～真的好吗～？你们拼命做的咖喱酱，[rhr]
_　全部都要进我的胃袋了哦～」[rhp]
[:yabu:]
「啊呜」[rhp]

[off_all]


;****************************************
;カットイン
[se storage="body_01.ogg"]

[s_image layer="2" page="back" storage="ct/a_06_2c.png" width="1260" left="10" top="40" name="nov"]
[s_trans layer="2" method="bounceInDown" time=500]
[cg storage="ct/a_06_3c.png"]
[wt]
;****************************************

[:mika:]
「哎呀呀。老师真是吃太多了」[rhp]

;****************************************
;カットイン終了
[s_freeimage layer="2" ]
;****************************************

[mika kao=11 ]
「米卡亲正在碳水减肥，[rhr]
_　就用棉花糖将就下吧。我要开动了」[rhp]

[off_all]

[:mika:]
「好好吃～～～♡　果然BBQ还是简约即王道！」[rhp]

;****************************************
[set_time_d]
;****************************************

[:sausu:][sausu kao=6 as=on ]
「…………。本想来看看努西小姐振作些没有……」[rhp]

[off_all]

;****************************************
;カットイン
[s_image layer="2" page="back" storage="ct/a_06_2d.png" width="1260" left="10" top="40" name="nov"]
[s_trans layer="2" method="bounceInDown" time=1000]
[cg storage="ct/a_06_3d.png"]
[wt]
;****************************************

[:sausu:]
「这、这样子真的没问题吗……」[rhp]

;****************************************
[s_mask time=2000]
[::]
[fbgm]
[s_freeimage  layer="2"]
;****************************************

; イベント分岐の解除
[iscript]
delete f.ev_a_06;
delete f.a06_d;
delete f.a06_d2;
delete f.a06_k;
delete f.a06_r;
delete f.a06_h;
[endscript]

[free_filter ]
[jump storage="ss_main.ks" target=*start]

[s]
