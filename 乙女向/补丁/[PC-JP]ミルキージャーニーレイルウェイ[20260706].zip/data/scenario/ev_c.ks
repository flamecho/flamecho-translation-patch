﻿
*start

[fbgm]
[mask color=0x000000 time=2000]

[cm]

[clearfix]
[start_keyconfig]
[loadjs storage="myscript.js"]

;初期設定---------------------------------------------------------------------

;メッセージウィンドウの設定
[position layer="message0" frame="win2.png" left=0 top=520 width=1280 height=200 page=fore visible=true]

; 文字表示領域
[position layer=message0 page=fore margint="65" marginl="420" marginr="60"]

;キャラ名表示領域
[ptext name="chara_name_area" layer="message0" color="0x000000" size=22 align=center bold=true x=420 y=550]

; 立ち絵の設定
[chara_config anim=false ptext="chara_name_area"]

[call storage="character.ks"]
[call storage="voice.ks"]

;--------------------------------------------------------------------------------


;--------------------------------------------------------------------------------------------
;▼フルボイスセット▼
;オチアイ※途中までsora=otiaiで反応。大人になったら変更
[voconfig sebuf=1 name=sora vostorage="otiai/full/{number}.ogg" number=69]
;糠星の夜
[voconfig sebuf=1 name=yoru vostorage="yoru/full/{number}.ogg" number=186]
;八雲博士
[voconfig sebuf=1 name=hiro vostorage="hiro/full/{number}.ogg" number=143]

; 以下試験的にやってみる


;--------------------------------------------------------------------------------------------

;****************************************
;タイトル表示

[bg storage="title/title_4a.png" time=100]
[bgm storage="bgm_36.ogg"]
[s_mask_off time=2000]

[bg storage="title/title_4b.png" time=2000]

[s_wait time=5000]

[bg storage="title/title_4a.png" time=2000]

[s_mask color=0x000000 time=2000]
[bg storage="black.jpg" time=100]
[layopt layer=message0 visible=true]
[plugin name="menu_plugin"]
[free_filter ]
[showmenubutton]
[s_mask_off time=2000]

;****************************************

弟弟患上了不治之症。[rhp]

;****************************************
[bg storage="hsps_06.jpg" time=1000]
;****************************************

[se storage="door_13.ogg"]

我轻轻敲了敲病房的门，没等回应就推开了门。[rhp]

;****************************************
[se storage="door_07.ogg"]
[bg_rule storage="hsps_08.jpg" rule="002.png" time=1500]
;****************************************

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
[vostart]
;--------------------------------------------------------------------------------------------

[:sora:][otiai body=unif kao=14 ]
「薰」[rhp]

[off_all]

[:kaoru:][kaoru kao=1 ]
「……！哥哥！」[rhp]

[off_all]

[chara_part name="otiai" body=unif kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kaoru" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="kaoru" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sora:]
「还好吗？」[rhp]

[:kaoru:][kaoru kao=13 ]
「嗯。还行吧！」[rhp]

[off_all]

[::]
弟弟……薰的病，是在小学入学典礼上突然晕倒时发现的。[rhp]
他再也没能体验那期待已久的小学生活，[rhr]
今年薰将在这家临终关怀院迎来十岁生日。[rhp]
为了见他，我坚持每周探望两次从未间断。[rhp]

;袋がさがさ
[se storage="se7_06.ogg"]

[chara_part name="otiai" body=unif kao=11 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kaoru" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="kaoru" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sora:]
「这个，伴手礼」[rhp]

[:kaoru:][kaoru kao=14 ]
「苹果？」[rhp]

[:sora:][otiai body=unif kao=7 ]
「奶奶寄来太多了。[rhr]
_　妈妈说让你拿去。你以前很喜欢吧」[rhp]

[:kaoru:][kaoru kao=13 ]
「嗯！前两天矢部老师[rhr]
_　说我已经不用再磨成泥了！」[rhp]

[:sora:][otiai body=unif kao=1 ]
「这样啊。那今天切成兔子造型吧」[rhp]

[:kaoru:][kaoru kao=4 ]
「哎？哥哥会切吗？不会削到手？」[rhp]

[:sora:][otiai body=unif kao=5 ]
「小菜一碟」[rhp]

[off_all]

[::]
昨天就从母亲那里听说他已经不用再把食物弄碎了。[rhr]
所以我练习过。这段时间就算自己不吃苹果也没关系。[rhp]
将叠放在床铺边的折叠椅展开坐下，[rhr]
用收在抽屉里的水果刀灵巧地削着果皮。[rhp]
……、好。我觉得练习有成效。[rhp]


[:sora:][otiai body=unif kao=6 ]
「………………」[rhp]


[off_all]

[:kaoru:][kaoru kao=1 ]
「………………」[rhp]

[off_all]

[chara_part name="otiai" body=unif kao=4 as=on ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kaoru" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="kaoru" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sora:]
「……什么啊……因为怕失败就都盯着我看」[rhp]

[:kaoru:][kaoru kao=5 ]
「失败品也行啦。吃进肚子都一样的」[rhp]


[:sora:][otiai body=unif kao=6 ]
「～～～～……」[rhp]
[:sora:]
[font color=0x4682b4]
（轻轻否定别人的努力……）[rhp]
[resetfont]

[:kaoru:][kaoru kao=7 ]
「…………哥哥啊。[rhr]
_　自从我来这里后，你经常来探望我吧？」[rhp]

[:sora:][otiai body=unif kao=6 ]
「也没那么频繁吧。只是闲着过来看看而已，再说了……」[rhp]

[:kaoru:][kaoru kao=3 ]
「足球不踢了吗？」[rhp]

[off_all]

[se storage="se2_04.ogg"]

[::]
―――――咔嚓。[rhp]
因为刀子滑向了奇怪的方向，[rhr]
果皮边缘被削掉了一半。[rhp]

[chara_part name="otiai" body=unif kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kaoru" body=base kao=4 as=on ss=off hh=off hr=on ]
[chara_show name="kaoru" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:kaoru:]
「对、对不起。都怪我突然搭话」[rhp]

[:sora:][otiai body=unif kao=7 as=on ]
「没事……无所谓啦。这种小事故经常发生的」[rhp]

[off_all]

[::]
他如此搪塞着，从已切成八块的苹果上又拿起一瓣。[rhr]
这次必须小心切了，可不能再分心……。[rhp]
……………………。[rhp]

[chara_part name="otiai" body=unif kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kaoru" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="kaoru" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sora:]
「…………足球已经不踢了」[rhp]

[:kaoru:][kaoru kao=8 as=on ]
「诶！？为什么？」[rhp]

[:sora:][otiai body=unif kao=6 ]
「太累人」[rhp]

[:kaoru:][kaoru kao=8 ]
「诶～……小学时在俱乐部明明那么拼命的……」[rhp]

[:sora:][otiai body=unif kao=6 ]
「打发时间罢了。犯不着为此加入社团」[rhp]

[:kaoru:][kaoru kao=13 ]
「社团活动……这样啊。哥哥今年开始就是初中生了呢」[rhp]

[:sora:][otiai body=unif kao=1 ]
「不过学习之类会变忙，说到底也不会参加社团啦」[rhp]

[:kaoru:][kaoru kao=6 ]
「这样啊……原来如此……」[rhp]
[:kaoru:]
「……………………」[rhp]

[:sora:][otiai body=unif kao=2 ]
「…………所以说！别老是盯着我看了」[rhp]

[:kaoru:][kaoru kao=1 ]
「诶～？　真是的，太任性了啦」[rhp]

[off_all]

[::]
在床铺上摇晃着上半身大笑的薰，[rhr]
看起来精神好到让人怀疑他是不是真的有哪里不舒服。[rhp]
……明明这样只剩几个月的生命了。[rhp]

[:sora:]
[font color=0x4682b4]
（……难以置信）[rhp]
[resetfont]

[::]
直到前年我们还一起参加足球社。[rhr]
可如今却连好好地从床铺下来都做不到。[rhp]

弟弟原本在大学医院住院接受治疗，[rhr]
去年转到了这家儿童临终关怀医院。[rhp]
临终关怀院是什么地方、和普通医院的住院生活有何不同，[rhr]
就算是小孩子也能轻易查得到。[rhp]
当初知道这件事时，我愤怒得近乎发狂。[rhr]
四口之家里只有我反对住进这里。[rhp]
我咒骂父亲是人渣。[rhp]
把母亲惹哭的吵架，那之后之前都再未有过。[rhp]

[chara_part name="otiai" body=unif kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kaoru" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="kaoru" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sora:]
「…………薰」[rhp]

[:kaoru:][kaoru kao=1 ]
「嗯－？」[rhp]

[:sora:][otiai body=unif kao=3 ]
「在这里生活，开心吗？」[rhp]

[:kaoru:][kaoru kao=13 ]
「啊？……嗯！超级开心哦」[rhp]
[:kaoru:]
「我啊，来这里之后交了很多朋友。[rhr]
_　隔壁房间的[player2]和近君。和哥哥同岁呢」[rhp]

[:sora:][otiai body=unif kao=6 ]
「哼嗯……」[rhp]

[off_all]

[::]
不感兴趣。[rhp]

[chara_part name="otiai" body=unif kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kaoru" body=base kao=11 as=off ss=off hh=off hr=on ]
[chara_show name="kaoru" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sora:]
「薰的同龄人没有吗？」[rhp]

[:kaoru:][kaoru kao=5 ]
「嗯～、大一点的就有一个。在主楼上学的理央君。[rhr]
_　前几天还来这里玩过」[rhp]
[:kaoru:]
「头发纯白哦！超级漂亮呢。[rhr]
_　之前啊，还一起拍了照片呢！」[rhp]

[:sora:][otiai body=unif kao=12 ]
「嘿。那不是挺好嘛」[rhp]

[off_all]

[::]
不感兴趣。[rhr]
不过，薰那骄傲的样子看着真让人开心。[rhp]
…………仅此而已。[rhp]

[chara_part name="otiai" body=unif kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kaoru" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="kaoru" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sora:]
「薰。吃完苹果要做什么？」[rhp]

[:kaoru:][kaoru kao=1 ]
「嗯～、随便啦。哥哥决定吧」[rhp]

[:sora:][otiai body=unif kao=5 ]
「百人一首」[rhp]

[:kaoru:][kaoru kao=8 as=on ]
「呜哇……知、知道啦……我来决定就是」[rhp]
[:kaoru:]
「………………、该怎么办呢……」[rhp]

[off_all]

[::]
薰目光涣散地陷入思考。比刚才更没精神了。[rhr]
光是这点对话和吃饭，就已经非常消耗体力了。[rhp]

[chara_part name="otiai" body=unif kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kaoru" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="kaoru" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sora:]
「…………、还是照常看绘本吧」[rhp]

[:kaoru:][kaoru kao=13 ]
「……！　对啊。这样最好啦」[rhp]

[:sora:][otiai body=unif kao=1 ]
「那我去向八云君借绘本」[rhp]

[:kaoru:][kaoru kao=1 ]
「OK。等你哦」[rhp]

[off_all]

[::]
一份切成兔子形状的苹果，和一份小小的方块苹果。[rhr]
递过盛着这些的盘子，我离开了折叠椅。[rhp]

;****************************************
;ドア閉める
[se storage="door_08.ogg"]
[bg_rule storage="hsps_06.jpg" rule="002.png" time=1500]
;****************************************

轻轻关上拉开的推拉门，我朝101号室走去。[rhp]
走在走廊上时，与坐在轮椅上的少年和推着轮椅的孩子们擦肩而过。[rhp]


;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:unknown:][hime2 kao=13 ]
「啊……你好！」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[::]
其中的女孩朝我这边打了招呼。[rhr]
大约和我同龄吧？乍看之下很精神的样子……[rhp]

[off_all]

[:sora:][otiai body=unif kao=7 ]
「……你好」[rhp]

[off_all]

[::]
………思考只是浪费时间。[rhp]

;****************************************

;抜粋表示

[layopt layer="message0" visible="false"]
[s_mask graphic="rule/title_4c.png" time=2000]
[hidemenubutton]

[bg storage="title/title_4c.png" time=100]

[s_mask_off time=2000]

[bg storage="title/title_4d.png" time=2000]

[s_wait time=2000]

[bg storage="title/title_4c.png" time=3000]

[s_mask color="0x000000" time=3000]

[fbgm]
[bg storage="black.jpg" time=100]
[layopt layer="message0" visible="true"]
[position layer="message0" frame="win2.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[showmenubutton]
[s_mask_off time=2000]
[bgm storage="bgm_34.ogg"]
;****************************************

住在101号室的八云君，[rhr]
是薰在主楼时认识的年长少年。[rhp]

;ノック
[se storage="door_13.ogg"]

敲了几次门后，里面传来「请进」的声音。[rhr]
我推开门，轻轻点头致意后走了进去。[rhp]

;****************************************
;扉開ける
[se storage="door_07.ogg"]
[bg_rule storage="hsps_09.jpg" rule="002.png" time=1500]
;****************************************

[:sora:][otiai body=unif kao=1 ]
「你好」[rhp]

[off_all]

[:hirosi:][hiro kao=3 as=on ]
「！那个……」[rhp]

[off_all]

[::]
八云君看到我后，露出尴尬的表情支吾着说不出话。[rhr]
……我知道他的病情。[rhp]
我装作没注意到，像往常一样做起自我介绍。[rhp]

[chara_part name="otiai" body=unif kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hiro" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sora:][otiai body=unif kao=11 ]
「我是落合宙哦」[rhp]

[:hirosi:][hiro kao=4 ]
「……！啊……啊、对喔。是这样是这样」[rhp]
[:hirosi:]
「你好。今天也是来探望薰君吗？」[rhp]

[:sora:][otiai body=unif kao=0 ]
「嗯。想来借绘本的，可以吗？」[rhp]

[:hirosi:][hiro kao=13 ]
「当然。一直都这么懂事呢」[rhp]

[off_all]

[::]
他是薰在主楼住院时认识的住院前辈，[rhr]
因为当时病房也离得近，经常带着弟弟陪我一起玩。[rhp]
大两岁的他性格沉稳又聪明，[rhr]
尽管如此，交谈也很愉快，而且内容相当有益。[rhp]
这样的他来到临终关怀院，是在弟弟搬走后一年的事。[rhr]
虽然临终关怀院和医院我都不喜欢，但八云君的存在对我而言是种救赎。[rhp]

[chara_part name="otiai" body=unif kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hiro" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:hirosi:]
「话说回来，绘本的话大厅里应该有很多吧。[rhr]
_　我的书对薰君来说会不会太难了？」[rhp]

[:sora:][otiai body=unif kao=8 ]
「不必。不想去大厅」[rhp]

[off_all]

[::]
他极力避免接近人群聚集的场所。[rhp]
看到那些明明生病却活蹦乱跳的家伙，就会莫名火大。[rhr]
……薰连正常走路都办不到，那种悠闲态度实在难以容忍。[rhp]
即便是八云君，也无法接受他的提议。[rhp]

[chara_part name="otiai" body=unif kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hiro" body=base kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sora:]
「书本方面，有什么推荐的吗？」[rhp]

[:hirosi:][hiro kao=11 ]
「有的。比如这本怎么样」[rhp]

[off_all]

[::]
递过来的是一本名为《魔法衣柜》的绘本。[rhp]
翻开一看，画着小女孩更换各种连衣裙的插图[rhr]
连续占据了好几页篇幅。[rhp]

[chara_part name="otiai" body=unif kao=4 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hiro" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sora:]
「……这个，是八云君在读的？有点女孩子气呢」[rhp]

[:hirosi:][hiro kao=1 ]
「才、才不是我的兴趣。这是沃尔佩克拉的，」[rhp]

[:sora:][otiai body=unif kao=6 ]
「咦？你说谁？」[rhp]

[:hirosi:][hiro kao=7 ]
「啊……啊啊不是，该怎么说呢……[rhr]
_　网、网上有名的书评人推荐的……」[rhp]

[:sora:][otiai body=unif kao=1 ]
「哼——。这样啊……那好吧，这样就行了吧」[rhp]

[:hirosi:][hiro kao=3 ]
「要是被薰君骂了可别怪我哦」[rhp]

[:sora:][otiai body=unif kao=13 ]
「没事。那家伙干什么都乐在其中的样子」[rhp]

[:hirosi:][hiro kao=1 ]
「……这样啊。真是个好孩子呢」[rhp]

[:sora:][otiai body=unif kao=5 ]
「还行吧。毕竟是我弟弟」[rhp]

[off_all]

[:sora:]
[font color=0x4682b4]
（…………不愧是八云君）[rhp]
[resetfont]

[::]
和八云君聊天果然很愉快。[rhp]
不仅能发现弟弟的优点，还能理解弟弟的心情的人，[rhr]
这世上肯定只有八云君了。[rhp]
所以我最喜欢八云君了。[rhp]

收到绘本后正想去床铺边聊会儿天，[rhr]
忽然发现桌上有件陌生物品。[rhp]

[chara_part name="otiai" body=unif kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hiro" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sora:]
「？……这是什么？千纸鹤……？」[rhp]

[:hirosi:][hiro kao=1 ]
「嗯？啊，这个啊。[rhr]
_　其实是矢部老师要求的，我在慢慢叠呢」[rhp]

[:sora:][otiai body=unif kao=6 ]
「嘿——……好玩吗？」[rhp]

[:hirosi:][hiro kao=11 as=on ]
「哈哈…说好玩可能不太准确，[rhr]
_　不过因为有明确目标所以还挺有干劲的」[rhp]
[:hirosi:]
「隔离病房的孩子们也叠了好多送过来，[rhr]
_　说不定能超过千只。说是光靠我一个人凑不够这个数呢」[rhp]

[:sora:][otiai body=unif kao=0 ]
「魔鬼啊。矢部老师」[rhp]

[:hirosi:][hiro kao=13 ]
「也没那么夸张啦。他说花多少时间都可以」[rhp]
[:hirosi:]
「你要不要也来叠？」[rhp]

[:sora:][otiai body=unif kao=7 ]
「呃，不了。我就算了吧」[rhp]

[:hirosi:][hiro kao=1 ]
「折1只就能实现愿望哦」[rhp]

[:sora:][otiai body=unif kao=0 ]
「千纸鹤是这种说法来着……？」[rhp]

[off_all]

[::]
『折满千只』才能实现愿望吧，我记得。[rhp]
这样的话，神明到底要满足多少个愿望才够啊。[rhr]
那未免也太贪心了。[rhp]

[chara_part name="otiai" body=unif kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hiro" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:hirosi:]
「无所谓啦，心诚则灵。老师是这么说的」[rhp]

[:sora:][otiai body=unif kao=7 ]
「真随便……不愧是『庸医』」[rhp]

[:hirosi:][hiro kao=13 ]
「哈哈哈！不过听着挺浪漫的不是吗。[rhr]
_　我也受这说法启发，对纸鹤许了好多愿望呢」[rhp]

[:sora:][otiai body=unif kao=7 ]
「诶。比如什么？祈祷病愈之类的？」[rhp]

[:hirosi:][hiro kao=11 ]
「那个嘛也有少许啦……[rhr]
_　许得最多的是『想乘银河铁道』吧！」[rhp]

[:sora:][otiai body=unif kao=1 ]
「啊……超级孩子气嘛」[rhp]

[:hirosi:][hiro kao=3 ]
「才、才没那回事。我可是非常认真的」[rhp]

[:sora:][otiai body=unif kao=8 ]
「哦……随你便吧」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;-----------------------------------------------------------------------------------------

[:sora:]
「……………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[::]
梦想实现……么。[rhp]

[:sora:][otiai body=unif kao=6 ]
「………………果然我也折一只吧」[rhp]

[off_all]

[:hirosi:][hiro kao=13 ]
「当真？太开心了！」[rhp]

[off_all]

[::]
反正，又不会少块肉。[rhr]
就算只是心理安慰，博士高兴的话倒也无妨。[rhp]
就这样，我从博士桌上堆着的彩纸中借了一张。[rhp]

[chara_part name="otiai" body=unif kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hiro" body=base kao=4 as=off ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:hirosi:]
「黄绿色可以吗？还有金色银色哦」[rhp]

[:sora:][otiai body=unif kao=12 ]
「什么都行」[rhp]

[:hirosi:][hiro kao=3 as=on ]
「呵呵，这可是热门颜色很快会卖完的。真谦虚呢」[rhp]

[:sora:][otiai body=unif kao=8 as=on ]
「又不是小孩子了」[rhp]

[::]
用余光瞥着哧哧笑的八云君，[rhr]
想到弟弟还等着便麻利地开始折千纸鹤。[rhp]

[chara_part name="otiai" body=unif kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hiro" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:hirosi:]
「宙君要许什么愿？」[rhp]

[:sora:][otiai body=unif kao=7 ]
「愿八云君恢复健康」[rhp]

[:hirosi:][hiro kao=2 as=on ]
「诶……不是为薰君吗？」[rhp]

[:sora:][otiai body=unif kao=1 ]
「这是八云君的千纸鹤。[rhr]
_　蹭别人的许愿机会，概率很渺茫吧」[rhp]
[:sora:]
「而且！　既然八云君在做不切实际的梦，[rhr]
_　我就连他那份祈祷也承包了」[rhp]

[:hirosi:][hiro kao=13 ]
「这、这样啊……」[rhp]
[:hirosi:][hiro kao=13 ]
「…………谢谢」[rhp]

[off_all]

[::]
当然薰的病，若有神明定要祈求治愈。[rhr]
但这点，八云君本人肯定也是一样的。[rhp]
八云君和薰一样身患重病。[rhr]
其实就算所有纸鹤都用来许自己的愿也无可厚非。[rhp]
……他温柔得近乎过分。[rhp]

[chara_part name="otiai" body=unif kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hiro" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sora:]
「给。像这样？」[rhp]

[:hirosi:][hiro kao=5 ]
「谢谢。待会儿一起串起来，敬请期待」[rhp]

[:sora:][otiai body=unif kao=1 ]
「知道了。完成后来参观」[rhp]
[:sora:]
「绘本谢啦。回头还你」[rhp]

[:hirosi:][hiro kao=13 ]
「嗯。慢慢看」[rhp]

[off_all]

;****************************************
[se storage="door_08.ogg"]
[bg_rule storage="hsps_06.jpg" rule="002.png" time=1500]
;****************************************

[:sora:][otiai body=unif kao=0 ]
「千纸鹤呢……」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[off_all]

[::]
说是折纸鹤就能实现愿望什么的……[rhr]
不过八云君那么聪明，应该不会相信这种事吧。[rhp]
要是八云君真的康复了，到时候我也要为了薰去相信纸鹤…[rhp]

[:sora:]
[font color=0x4682b4]
（……………………）[rhp]
[resetfont]

[::]
…………。还是算了。[rhp]
虽然没对八云君说出口，但神明终归是妄想罢了。[rhr]
光是祈祷根本没用，如果愿望没能实现的话……[rhp]
………………我不想体会那种凄惨的心情。[rhp]

[:unknown:][hime2 kao=4 ]
「………………」[rhp]

[off_all]

[:sora:][otiai body=unif kao=2 ]
「！」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
;オチアイ
[voconfig sebuf=1 name=sora vostorage="otiai/full/{number}.ogg" number=129]
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[::]
忽然感到视线而回头时，有个陌生女人站在那里。[rhp]
……不对，倒也不是完全陌生。[rhr]
这家伙，应该就是去八云君房间前擦肩而过的……[rhp]

[chara_part name="otiai" body=unif kao=13 as=on ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:unknown:]
「……！啊、对、对不起。一直盯着你看」[rhp]

[:sora:][otiai body=unif kao=12 ]
「………………，没事」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:unknown:][hime2 kao=1 ]
「你、你是薰君的朋友？[rhr]
_　刚才从薰君房间里出来的对吧」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sora:][otiai body=unif kao=7 ]
「我是他哥哥」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:unknown:][hime2 kao=13 ]
「！原来你就是哥哥啊！我听薰君提起过。[rhr]
_　你和我们还有和君是同岁对吧」[rhp]
[:himeko:]
「我是星名[player]！请多关照」[rhp]


[:sora:][otiai body=unif kao=0 ]
「………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:himeko:][hime2 kao=1 as=on ]
「那个……啊！你现在是从博士房间里出来的吧！[rhr]
_　我都不知道，博士居然在外面有朋友――――」[rhp]

[:sora:][otiai body=unif kao=6 ]
「失礼了」[rhp]

[:himeko:][hime2 kao=4 as=on ]
「！」[rhp]

[:sora:][otiai body=unif kao=7 ]
「……我还要等弟弟」[rhp]

[:himeko:][hime2 kao=3 ]
「啊……对、对不起！因为偶尔会看到你，所以有点在意」[rhp]
[:himeko:]
「薰君啊，哥哥经常提起你呢！然后啊——」[rhp]

[off_all]

[:sora:][otiai body=unif kao=0 ]
「失礼了」[rhp]

[off_all]

[:himeko:][hime2 kao=3 as=on ]
「啊……！等、等一下！」[rhp]

[off_all]

[::]
等什么等。薰比你更需要等待。[rhr]
我一次都没有回头，离开了那里。[rhp]
…………但不知为何那家伙也开始在后面跟着走起来。[rhp]

[:himeko:]
「那个啊！同龄人在这里很少见的。这里只有和君和我呢」[rhp]

[::]
身后传来套近乎的搭话声，全部无视。[rhp]
喂喂，看看气氛啊……。[rhr]
快察觉我不想搭话的气场啊……。[rhp]

[:himeko:]
「如果可以的话想问问你很多事情呢。比如学校的事！[rhr]
_　我们还没上过中学所以很感兴趣的啦」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:sora:][otiai body=unif kao=2 ]
「…………」[rhp]

[off_all]

[:himeko:]
「知道休息室吗？是大家可以聚在一起聊天的地方！[rhr]
_　我去跟矢部医生申请，就在那里聊吧！」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sora:][otiai body=unif kao=6 ]
「～～～～……」[rhp]
[:sora:]
[font color=0x4682b4]
（搞什么啊。初次见面就这么自来熟……）[rhp]
[resetfont]

[off_all]

[::]
无视吵闹的家伙，加快脚步继续前进。[rhp]

[:himeko:]
「然后呢，那个……，…………，就是……」[rhp]

[:sora:][otiai body=unif kao=0 ]
「………………？」[rhp]

[off_all]

[::]
那个一直不停搭话的声音，[rhr]
没过多久就渐渐失去干劲，最终安静了下来。[rhp]
倒也不是特别在意，只是觉得有点奇怪所以回头看了一眼。[rhp]

[:himeko:][hime2 kao=12 as=on ]
「哈……哈，……呼……」[rhp]
[:himeko:][hime2 kao=1 ]
「！　啊……！　对、对不起……我有点喘不上气」[rhp]

[off_all]

[::]
……体力差这点倒是和薰一模一样。[rhr]
明明看起来挺健康的，果然这家伙也是这里的住民啊。[rhp]
……不过嘛，能走路就算不错了。[rhp]

[:himeko:][hime2 kao=1 as=on ]
「……下次再见啦！嘿嘿……」[rhp]

[off_all]

[:sora:][otiai body=unif kao=7 as=on ]
[font color=0x4682b4]
（～～～～下次什么的，根本不会有啊……）[rhp]
[resetfont]

[off_all]

;****************************************
[fbgm]
[set_b storage="hsps_08e.jpg"]
[bgm storage="bgm_07.ogg"]
;****************************************

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
[vostart]
;--------------------------------------------------------------------------------------------

[::]
1小时后。[rhp]
和那个古怪女人分开回到薰的房间后，我度过了念绘本故事[rhr]
和闲聊的时光，正准备结束今天的会面。[rhp]

[chara_part name="otiai" body=unif kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kaoru" body=base kao=1 as=off ss=off hr=on ]
[chara_show name="kaoru" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:kaoru:]
「谢谢哥哥。绘本故事好有趣！」[rhp]

[:sora:][otiai body=unif kao=1 ]
「这样啊。那就好」[rhp]

[:kaoru:][kaoru kao=7 as=on ]
「不过哥哥，你兴趣挺女孩子气的呢。[rhr]
_　中学交到女朋友了吗？」[rhp]

[:sora:][otiai body=unif kao=4 ]
「哈！？才、才没有！[rhr]
_　这是八云君推荐的，我只是按他说的借来看看而已！」[rhp]

[:kaoru:][kaoru kao=2 as=on ]
「什么嘛，这样啊。真没劲」[rhp]

[off_all]

[:sora:][otiai body=unif kao=1 ]
「～～～～……，那我差不多该走了。巴士还有班次」[rhp]

[off_all]

[:kaoru:][kaoru kao=13 ]
「下次还要来哦，哥哥。下次和妈妈他们一起来！」[rhp]

[off_all]

[:sora:][otiai body=unif kao=1 ]
「…………看心情吧」[rhp]

[off_all]

[::]
临走时，薰总会提起母亲的事。[rhp]
倒也不是那个人不去见薰。[rhr]
倒不如说我被放在第二位，他更多是在为薰腾出时间。[rhp]
我对此完全没有意见。[rhr]
甚至觉得本该如此。[rhp]

…………只是我和父母的关系不太好。[rhp]
虽然对放任不管的状态没有不满，但也不算叛逆期，[rhr]
之前因为薰的事大吵一架后，几乎再没说过话。[rhp]
薰知道这件事，[rhr]
所以每次有事都想让我和母亲碰面。[rhp]

那家伙脸上明晃晃写着「希望你们和好」。[rhr]
但我完全没有这个打算。[rhp]

这里不是什么弃老山，而是弃子山。[rhp]
我绝对无法原谅他们把薰送进这种地方。[rhp]

;****************************************
[set_b storage="hsps_07e.jpg"]
;****************************************

[::]
临终关怀院的时间转瞬即逝。[rhr]
怀着依依不舍的心情，我加快脚步穿过走廊以免错过巴士。[rhp]
;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:sora:][otiai body=unif kao=0 ]
「…………！」[rhp]

[off_all]

[::]
突然抬头看见对面有人走来。[rhr]
是在这家临终关怀院当医生的矢部尊……老师。[rhp]
我……实在不太喜欢这个人……[rhr]
尽可能不想被他搭话，便低头沿着走廊边缘走。[rhp]

[:takeru:][take kao=1 ]
「哎呀」[rhp]

[off_all]

[::]
………………。眼神倒挺尖……。[rhp]

[chara_part name="otiai" body=unif kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="take" body=base kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:takeru:]
「你是落合君的哥哥对吧。你好」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sora:][otiai body=unif kao=6 ]
「……你好」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:takeru:][take kao=1 ]
「一直以来承蒙关照。现在是要回去了吗」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sora:][otiai body=unif kao=2 ]
「好的」[rhp]
[:sora:]
[font color=0x4682b4]
（还不是因为你医术不精，我才不得不一直来。庸医）[rhp]
[resetfont]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------


[:takeru:][take kao=13 ]
「薰君身体状况比从前好多了。[rhr]
_　照这样看来应该能参加七夕会呢」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sora:][otiai body=unif kao=0 ]
「……七夕会？」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------


[:takeru:][take kao=1 ]
「七月七日在中庭举办的观星聚会。[rhr]
_　当然前提是身体状况允许参与的人」[rhp]
[:takeru:]
「方便的话你也来如何？落合君、……薰君。[rhr]
_　听说他很期待如果能参加就邀请哥哥呢」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sora:][otiai body=unif kao=3 ]
「薰他……？」[rhp]

[off_all]

[::]
完全不知情。包括今天在内，之前他从未提起过。[rhr]
……该不会，是顾虑我和其他住客疏远才特意不提的吧。[rhp]
要是这样的话对薰实在过意不去……可是……[rhp]

[chara_part name="otiai" body=unif kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="take" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sora:]
「…………我会考虑的」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------


[:takeru:][take kao=13 ]
「啊务必来。人多才热闹」[rhp]
[:takeru:]
「其实这次八云君也确定能参加了。[rhr]
_　你和八云君关系也不错吧？」[rhp]
[:takeru:]
「这种机会并不常有。希望你能认真考虑」[rhp]

[off_all]

[::]
……"这种机会并不常有"么。[rhr]
话是没错……但从医生嘴里说出来就有些微妙。[rhp]
忍不住想你们医生倒是努力别让这种机会常有啊。[rhr]
……我知道很难所以不说。[rhp]

[chara_part name="otiai" body=unif kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="take" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:takeru:]
「哎呀，耽误你时间真不好意思」[rhp]
[:takeru:]
「外面快天黑了。你是坐巴士回去吧？路上小心」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sora:][otiai body=unif kao=6 ]
「谢谢……」[rhp]

[off_all]

[::]
……话说这家伙，暗地里还挺爱管闲事。[rhr]
要是像长相那样冷漠的话，我反而知道该怎么应付。[rhp]
刚才那个花哨活动，根据薰之前说过的话[rhr]
多半是这家伙提议的。外表和行动完全不搭啊……[rhp]
…………算了，薰开心就好。[rhp]

[:sora:]
[font color=0x4682b4]
（七夕会吗……）[rhp]
[resetfont]

[::]
听说八云君也参加……既然是薰的邀请，去去也行吧。[rhp]

;****************************************
[fbgm]
[set_b storage="sky_07.jpg"]
[bgm storage="bgm_08.ogg"]
;****************************************

从矢部老师那里听说七夕会的一周后，[rhr]
正如他所言，我收到了薰关于七夕会的邀请。[rhp]
她似乎本来担心我兴趣不大而有所顾虑，[rhr]
但在矢部老师和大美贺小姐的鼓励下，终于下了决心。[rhp]
让她产生这种误会让我有些过意不去，其实我原本就[rhr]
打算参加，所以爽快答应后她显得非常高兴。[rhp]

;****************************************
[set_n storage="hsps_10n.jpg" time=1500]
;****************************************

接着，到了七夕会当天。[rhp]

我比预定时间稍晚地踏入了事先听闻的举办地——中庭，[rhr]
数名孩童和看似他们监护人的大人已经聚集在此。[rhp]
人数并不算多，但孩子们看起来气色都相对较好。[rhp]
这也难怪。这里毕竟是给即将离世之人准备的设施，[rhr]
能否参与的标准想必不会那么简单吧。[rhp]
我暂且先寻找着薰的身影―――[rhp]

[:kaoru:][kaoru kao=13 ]
「啊！哥哥！」[rhp]

[off_all]

[::]
明明还没靠得多近，薰就比我先发现了我。[rhr]
他正试图在难以移动的草坪上推着轮椅过来，于是我慌忙跑上前去。[rhp]

[chara_part name="otiai" body=base kao=1 as=off ss=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kaoru" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="kaoru" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sora:]
「……抱歉，来晚了」[rhp]

[:kaoru:][kaoru kao=1 ]
「没事。完全没关系！巴士很挤吗？」[rhp]

[:sora:][otiai kao=7 ]
「…………，嘛差不多吧」[rhp]

[off_all]

[::]
是谎言。真正原因另有其他。[rhp]
我望向从中庭能看见的一楼某间病房。[rhp]
……101号室。八云君的房间。[rhp]

[:sora:][otiai kao=3 ]
「………………不参加吗」[rhp]

[off_all]

[::]
从与这里护士交好的母亲那里听说，[rhr]
八云君的病情恶化，似乎已经记不起大部分事情了。[rhp]
甚至连薰的事都不记得。[rhr]
我的事就更不可能记得了。[rhp]
想到要和那样的八云君打照面，不知怎的就有些踌躇，[rhr]
回过神来，已在巴士站错过了两班前往医院的巴士。[rhp]
……仔细想想，他那种状态本就不可能来参加这个会的啊。[rhp]

[:himeko:][hime2 kao=13 ]
「啊！是薰君的哥哥！」[rhp]

[off_all]

[:sora:][otiai kao=6 ]
「……！　啊……呜哇」[rhp]

[off_all]

[::]
虽然忘记了名字，但那个气喘吁吁的女人。[rhr]
完全忘记了这家伙也在场……[rhp]

[chara_part name="otiai" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:himeko:]
「哇这是什么！？真是的ー！」[rhp]
[:himeko:]
「还记得我吗？　[player2]！　这个之前稍微聊过对吧」[rhp]

[:sora:][otiai kao=6 ]
「…………没有。对不起」[rhp]

[:himeko:][hime2 kao=1 ]
「我就知道会这样！嘛不过算了……」[rhp]

[off_all]

[chara_part name="kaoru" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="kaoru" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:himeko:]
「但你还是好好来了呢。太好了呢，薰君！」[rhp]

[:kaoru:]
「嗯！妈妈他们因为工作来不了，不过哥哥来了！」[rhp]

[:himeko:]
「嗯嗯，这样就很满足了呀！」[rhp]

[off_all]

[:sora:][otiai kao=8 ]
[font color=0x4682b4]
（真是自来熟啊……对别人的弟弟……）[rhp]
[resetfont]

[:himeko:][hime2 kao=13 ]
「对了。说起来我还不知道你的名字呢？[rhr]
_　这样下去会和薰君搞混的。拜托了，告诉我吧！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:sora:][otiai kao=8 ]
「……宙」[rhp]

[:himeko:][hime2 kao=13 ]
「是宙君啊！　这名字真像宇航员。[rhr]
_　感觉会出现在和君看的漫画里！」[rhp]

[off_all]

[::]
这家伙在说什么？真无聊。[rhr]
明明就只写了个『宙』字。蠢女人。[rhp]

[:kazutika:][kazu kao=6 ]
「…………………………」[rhp]

[off_all]

[:sora:][otiai kao=2 ]
「…………、……」[rhp]

[off_all]

[::]
然后从刚才开始，就有人[rhr]
在背后用超刺人的眼神盯着我。[rhp]

[chara_part name="otiai" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kazu" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="kazu" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sora:]
「那个。有事吗」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:kazutika:][kazu kao=1 ]
「………………哼」[rhp]
[:kazutika:]
「我赢了」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sora:][otiai kao=2 ]
「哈？赢什么？」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:kazutika:][kazu kao=5 ]
「没什么～。当我没说」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sora:][otiai kao=6 ]
「有话就直说啊。很让人火大诶」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:kazutika:][kazu kao=4 ]
「哇、被健全者给盯上了」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sora:][otiai kao=8 ]
「哈！？谁会说那种话啊！」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:rio:][rio2 kao=3 ]
「嘛、嘛嘛嘛嘛～！吵、吵架就到此为止吧」[rhp]

[off_all]

[::]
接二连三地到底搞什么……！？[rhr]
我毫不掩饰烦躁地转过身。[rhp]

[chara_part name="otiai" body=base kao=4 as=on ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="rio2" body=base kao=3 as=on ss=off hh=off hr=on ]
[chara_show name="rio2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sora:][otiai kao=8 ]
「……！」[rhp]

[::]
首先注意到的是那头发的颜色和瞳色。[rhp]
这家伙我有印象。薰曾说过他的特征。[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:rio:][rio2 kao=13 hh=on ]
「薰、薰君的哥哥……对吧。那个，我叫神崎凛生。[rhr]
_　一直和薰君相处得很好」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sora:][otiai kao=7 ]
「哈……你好」[rhp]

[off_all]

[::]
在主楼的时候，好像和一个头发纯白的门诊患者很熟……[rhr]
仔细一看发现不仅是头发白，连眼睛也是红的。[rhp]
白化病……是这么叫来着？虽然我也不太清楚。[rhp]

[chara_part name="otiai" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kaoru" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="kaoru" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:kaoru:][kaoru kao=1 ]
「理央君很帅对吧？头发像雪一样！」[rhr]
_　而且他学习超级厉害」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:rio:][rio2 kao=13 hh=on ]
「嘿嘿……」[rhp]

[off_all]

[chara_part name="kazu" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="kazu" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="rio2" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="rio2" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="760" top="0" wait="true" time=150]

[:kazutika:]
「住手吧理央。向健全人炫耀什么也只会被当成傻瓜」[rhp]

[:himeko:][hime2 kao=2 ]
「和君！　这种挑衅的态度快收起来！[rhr]
_　难得他们俩过来玩，太失礼了吧」[rhp]

[:kazutika:][kazu kao=7 ]
「对不起啦ー」[rhp]

[:himeko:][hime2 kao=2 ]
「给我好好道歉！」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▼再開▼
;オチアイ
[voconfig sebuf=1 name=sora vostorage="otiai/full/{number}.ogg" number=163]
[vostart]
;------------------------------------------------------------------------------------------

[:sora:][otiai kao=7 ]
「………………呼」[rhp]
[:sora:]
[font color=0x4682b4]
（……虽然是薰的请求，或许不该来这一趟。[rhr]
_　这群人压根没在看星星啊……）[rhp]
[:sora:]
（健全不健全的谁在乎啊……真无聊）[rhp]
[resetfont]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:tiaki:][tiaki kao=13 ]
「各位ー！久等啦～！」[rhp]

[:sora:][otiai kao=0 ]
「！」[rhp]

从中庭出入口处，护士大美贺小姐推着大型推车走了过来。[rhr]
推车上摆放着点心和看似饮料的纸杯。[rhp]

[:tiaki:][tiaki kao=5 ]
「锵锵～！米卡亲特调・可尔必思隆重登场！[rhr]
_　今天特别准备了比平时浓ー一点点的口味哦！」[rhp]

[:xnin:]
「哇哦！！」[rhr]
「哇哦！！」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sora:][otiai kao=6 as=on ]
[font color=0x4682b4]
（这欢呼什么鬼）[rhp]
[resetfont]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[off_all]

[chara_part name="tiaki" body=base kao=14 as=off ss=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=1 as=off ss=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:]
「来来大家自己选喜欢的口味！[rhr]
_　不仅有普通款，还有各种水果味的可尔必思呢～」[rhp]

[:himeko:][hime2 kao=13 ]
「太厉害！好豪华！」[rhp]

[:tiaki:][tiaki kao=5 ]
「不过随便摆着摆着就分不清[rhr]
_　哪个位置是什么口味了……看起来颜色都差不多嘛」[rhp]

[:himeko:][hime2 kao=2 as=on ]
「那、那这样不是不能选择自己喜欢的吗？」[rhp]

[:tiaki:][tiaki kao=13 ]
「嘛这方面呢！会抽到什么呢？Surprise！就是这样！」[rhp]

[:himeko:][hime2 kao=8 as=on ]
「诶诶～～！？」[rhp]

[off_all]

[::]
虽然觉得是相当令人失望的失误，但或许是因人气王的大美贺小姐的威望，[rhr]
全场的大家都笑着包容了她的疏忽。[rhp]
大美贺小姐和其他护士们正将纸杯从推车移到托盘上，[rhr]
开始分发给参与者们。[rhp]
在无事可做的间隙，稍微观察了下四周。[rhp]
……完全不像医院的，明亮氛围。[rhr]
薰也笑着，看起来很开心的样子。[rhp]
但果然，我还是没法打心底感到快乐。[rhr]
这间设施是什么地方这念头，总是在脑中挥之不去……[rhp]

[:tiaki:][tiaki kao=1 ]
「哎呀？终于来了呢哥哥！」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sora:][otiai kao=7 ]
「！你好……」[rhp]

[off_all]

[::]
沉思之际，大美贺小姐已来到我所在的位置。[rhr]
猛然回神，随便点头致意了一下。[rhp]

[chara_part name="otiai" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sora:]
「抱歉，我来晚了」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:tiaki:][tiaki kao=13 ]
「不用道歉啦。不过薰君从早上开始就一直[rhr]
_　坐立不安的，连米卡亲都跟着坐立不安了呢」[rhp]

[off_all]

[:kaoru:][kaoru kao=2 ]
「等、等一下米卡亲！才不是这样。[rhr]
_　坐立不安是因为今天没点心啦真是的」[rhp]

[off_all]

[:tiaki:][tiaki kao=14 ]
「呜呼呼♡　对不起对不起」[rhp]

[off_all]

[chara_part name="otiai" body=base kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:]
「来，那么久等了！[rhr]
_　薰君和宙君也请选一杯♡」[rhp]

[off_all]

[::]
接过递来的托盘，对比着装有可尔必思的几杯饮料。[rhr]
虽说味道不同……但看起来全都是纯白的啊。[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sora:]
[font color=0x4682b4]
（……哎随便吧）[rhp]
[resetfont]

[::]
随意拿了杯喝下一口。[rhp]
味道是……桃子？……大概。[rhp]

[:sora:]
[font color=0x4682b4]
（…………。说很浓，这不普通嘛）[rhp]
[resetfont]

[::]
――――刚这么想没一会儿。[rhr]
看到周围其他孩子们的热烈反响，才意识到自己错了。[rhp]

平时必须兑得更稀才行。[rhp]
哪怕是细微的营养差异，[rhr]
对他们而言都可能引发严重后果。[rhp]
所以今天『没有点心』……。[rhp]

[:sora:][otiai kao=6 ]
「～～～～……」[rhp]

[off_all]

[::]
本以为来参加开心活动，结果从刚才起就净是不愉快。[rhr]
虽然是薰的请求，真不该来的……[rhp]

[:himeko:][hime2 kao=4 ]
「啊！」[rhp]

[off_all]

[::]
背后传来气喘吁吁的女声。[rhp]

[:himeko:][hime2 kao=8 ]
「这是葡萄味。好喝，但桃子味更好啊……」[rhp]

[off_all]

[:sora:][otiai kao=7 ]
「………………」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[::]
…………桃子。[rhr]
对比着自己和她的杯子。[rhp]

[chara_part name="kazu" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="kazu" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:himeko:]
「和君是什么口味？」[rhp]

[:kazutika:][kazu kao=5 ]
「章鱼烧味」[rhp]

[:himeko:][hime2 kao=3 ]
「哦这样。那太好了呢」[rhp]

[off_all]

[:himeko:][hime2 kao=4 ]
「…………！」[rhp]

[:sora:][otiai kao=6 ]
「！」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[::]
糟……眼神对上了。[rhp]
不妙，会被缠上。这么想着慌忙移开视线但……[rhp]

[chara_part name="otiai" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:himeko:]
「宙君！　宙君的是什么口味？」[rhp]

[:sora:][otiai kao=0 ]
「…………鲷鱼烧味」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:kazutika:][kazu kao=2 as=on ]
「真假那家伙……居然敢耍我」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[chara_part name="otiai" body=base kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:himeko:]
「真是的，认真回答啦！」[rhp]

[:sora:][otiai kao=12 ]
「……是桃子」[rhp]

[:himeko:][hime2 kao=13 ]
「真的！？　好棒～！　我也想要桃子来着」[rhp]

[:sora:][otiai kao=7 ]
「这样啊……」[rhp]

[:himeko:][hime2 kao=1 ]
「呐呐！　方便的话和我交换好不好？」[rhp]

[off_all]

[chara_part name="rio2" body=base kao=4 as=on hh=h hr=on ]
[chara_show name="rio2" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kazu" body=base kao=2 as=off hh=off ss=on hr=on ]
[chara_show name="kazu" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:2nin:]
「诶」[rhr]
「诶」[rhp]

[off_all]

[chara_part name="otiai" body=base kao=0 as=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=1 as=off ss=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:himeko:]
「不行吗？求你了！ 我最喜欢桃子了」[rhp]

[:sora:][otiai kao=0 ]
「我、我喝过了。这样你会介意吧……」[rhp]

[:himeko:][hime2 kao=13 ]
「没关系的没关系。我也喝过一口所以扯平啦」[rhp]

[off_all]

[:sora:]
「啊、等等……！」[rhp]

[se storage="hand_01.ogg"]

[::]
喝没喝过根本不是重点，问题在于别的……！[rhp]
―――根本没机会说完 那个气喘吁吁的女人[rhr]
就从我手中夺过玻璃杯对着喝了下去。[rhp]

[:himeko:][hime2 kao=1 ]
「――――，嗯！　果然是桃子呢」[rhp]

[off_all]

[chara_part name="otiai" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:himeko:]
「来给你交换。放心葡萄味也很好喝的！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:sora:][otiai kao=6 ]
「………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:himeko:][hime2 kao=4 as=on ]
「……！！　啊……！　对、对不起。[rhr]
_　难道你不喜欢葡萄味！？」[rhp]

[:sora:][otiai kao=7 ]
「不、不是那样的……」[rhp]

[off_all]

[:sora:][otiai kao=8 ]
「…………、已经够了」[rhp]

[off_all]

[::]
……大概说什么都没用，看起来你也不会明白。[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:kazutika:][kazu kao=2 ]
「～～～～～……」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sora:][otiai kao=12 ]
[font color=0x4682b4]
（这家伙倒是好像明白……）[rhp]
[resetfont]

[off_all]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[chara_part name="kazu" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="kazu" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:kazutika:]
「[player3]。这样可不好哦。[rhr]
_　你这是在违背公序良俗哦」[rhp]

[:himeko:][hime2 kao=2 ]
「公序？」[rhp]

[:kazutika:][kazu kao=5 ]
「把我的章鱼烧口味换回来！」[rhp]

[:himeko:][hime2 kao=8 ]
「诶～～～！？才不要！！」[rhp]

[off_all]

[:sora:][otiai kao=12 ]
「………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:kaoru:][kaoru kao=13 ]
「呵呵呵」[rhp]

[:sora:][otiai kao=2 ]
「！什、什么啊薰」[rhp]

[:kaoru:][kaoru kao=5 ]
「老哥，[player2]喜欢上了吗？」[rhp]

[:sora:][otiai kao=2 as=on ]
「哈！？为什么是我！谁会因为间接接吻就那种反应啊！」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[chara_part name="rio2" body=base kao=14 as=off ss=off hh=on hr=on ]
[chara_show name="rio2" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kaoru" body=base kao=3 as=off ss=off hr=on ]
[chara_show name="kaoru" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:rio:][rio2 kao=1 ]
「！！原、原来如此。间接接吻……！呜、呜哇」[rhp]

[:kaoru:]
「嘘、理央君！老哥生起气来超可怕的快住手」[rhp]


;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[:sora:]
「～～～～～……呜！」[rhp]

;****************************************
;スチル
[still storage="cg/c_1.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/c_1.png"]
;****************************************

[:sora:]
「你们俩，给我适可而止啊！」[rhp]

[:xnin:]
「！！」[rhr]
「！！」[rhp]

[::]
我突如其来的大吼让四周骤然安静。[rhp]

[:kaoru:]
「哥、哥哥……？真、真的生气了？」[rhp]

[::]
薰一脸担忧地望过来。[rhr]
平时的话我会安抚说『没那回事』，但今天不行。[rhp]
不跟这帮家伙说清楚我绝不罢休……！[rhp]

[:sora:]
「从刚才起就净在说些多余的话絮絮叨叨～……！[rhr]
_　到底为什么要叫我来啊。不是说七夕会吗！」[rhp]

[:himeko:]
「确、确实是那样……」[rhp]

[:sora:]
「既然是七夕！！　看天空啊，看天空！！」[rhp]
[:sora:]
「明明夜空这么晴朗，为什么没有一个人感兴趣啊！[rhr]
_　八云君知道的话会生气的这种状况！」[rhp]
[:sora:]
「放着那么喜欢星空的人不管，你们在想什么！[rhr]
_　开口就是可尔必思味道怎么样的……蠢货！！」[rhp]
[:sora:]
「可尔必思什么时候都能喝，[rhr]
_　织女与牛郎只有今天能见面啊！！」[rhp]

[:himeko:]
「！！」[rhp]

[:sora:]
「真是的……！」[rhp]

[:himeko:]
「………………」[rhp]

[:kaoru:]
「哥、哥哥……！」[rhp]

;****************************************
;スチル
#
[bg storage="cg/c_1b.png" width="1280" height="720" time=500]
[cg storage="cg/c_1b.png"]
;****************************************

[:sora:]
「…………啊」[rhp]

[::]
…………可能说得有点过分了。[rhp]

[:sora:]
「…………那个……」[rhp]

;****************************************
[still_end frame="win2.png" storage="hsps_10n.jpg" time=1500]
;****************************************

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[chara_part name="otiai" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kazu" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="kazu" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:kazutika:]
「…………意外地是个浪漫主义者嘛」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sora:][otiai kao=6 as=on ]
「诶，不……并、并不是那样」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:kazutika:][kazu kao=1 ]
「说得对。薰大哥说得没错……[rhr]
_　织女大人和牛郎大人的爱情罗曼史，这可不能错过啊！」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sora:][otiai kao=2 ]
「你有点小瞧人了吧！？」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:kazutika:][kazu kao=5 ]
「不觉得只是一点呢」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sora:][otiai kao=6 ]
「！！喂、喂……！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[off_all]

[chara_part name="kaoru" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="kaoru" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:]
「宙君好帅！不愧是哥哥呀！」[rhp]

[:kaoru:][kaoru kao=13 ]
「哥哥……！还以为你对七夕没兴趣！[rhr]
_　果然是有女朋友了吧……！」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------


[:sora:][otiai kao=3 ]
「才不是！」[rhp]

[off_all]

[chara_part name="otiai" body=base kao=2 as=off ss=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sora:]
「……～～～～可恶！[rhr]
_　说到底，还不是因为你在到处闹腾！」[rhp]
[:sora:]
「什么来着！？　[player2]……来着！？　都是因为你害我变成这样，」[rhp]

[:himeko:][hime2 kao=0 hh=on ]
「………………」[rhp]

[:sora:][otiai kao=6 ]
「……？　怎、怎么了……？」[rhp]

[:himeko:][hime2 kao=14 as=on hh=on ]
「――――！　没、没事。没什么啦」[rhp]
[:himeko:][hime2 kao=13 as=on hh=on ]
「宙君其实超级温柔呢。嘿嘿……」[rhp]

[:sora:][otiai kao=0 ]
「哈……？」[rhp]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

[off_all]

[::]
看到刚才那样，为什么会这么想……？[rhp]

[:himeko:][hime2 kao=13 ]
「大家快看，按照宙君说的仰望天空吧！」[rhp]

[off_all]

[chara_part name="tiaki" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:himeko:][hime2 kao=1 ]
「米卡亲！　望远镜借我！」[rhp]

[:tiaki:][p_mk_27][tiaki kao=14 ]
「哎呀呀……来给你」[rhp]

[:himeko:][hime2 kao=1 ]
「谢啦！」[rhp]

[off_all]

;****************************************
#
[bg storage="sky_07.jpg" time=500]
;****************************************

[:tiaki:][p_mk_04]
「呵呵。呐[player2]酱」[rhp]
[:tiaki:]
「……刚才的宙君，好帅气呢♡」[rhp]

[:himeko:]
「！　……嗯。只有一点点啦……」[rhp]

[:tiaki:]
「呜呼呼♡」[rhp]

;****************************************
#
[bg_rule storage="hsps_10n.jpg" rule="002.png" time=500]
;****************************************

[chara_part name="otiai" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kazu" body=base kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="kazu" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:kazutika:]
「薰的哥哥……」[rhp]

[:sora:][otiai kao=2 ]
「……叫我宙就行」[rhp]

[:kazutika:][p_kz_08][kazu kao=5 ]
「你这家伙，挺有两下子嘛」[rhp]

[:sora:][otiai kao=4 ]
「嗯？」[rhp]

[:kazutika:][kazu kao=0 ]
「听人提到博士就会受不了啊……[rhr]
_　现在博士正处于艰难时期，我可能有点得意忘形了」[rhp]
[:kazutika:]
「……能认真考虑这些事，我觉得还挺了不起的」[rhp]

[:sora:][otiai kao=8 ]
「……………………」[rhp]

[:kazutika:][kazu kao=5 ]
「所以说呢，让你当我小弟也不是不行」[rhp]

[:sora:][otiai kao=2 as=on ]
「谁要当你小弟啊！开什么玩笑！」[rhp]

[:kazutika:][kazu kao=1 ]
「开玩笑的。咱们先从朋友做起嘛」[rhp]

[:sora:][p_ot_21][otiai kao=6 as=on ]
「…………！　不、我对这种事没什么兴趣……」[rhp]

[off_all]

[:kaoru:][kaoru kao=1 ]
「和近君，没关系的！」[rhp]

[off_all]

[:sora:][otiai kao=2 as=on ]
「！　薰。你别多管闲事」[rhp]

[off_all]

[chara_part name="otiai" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="kaoru" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="kaoru" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="kazu" body=base kao=4 as=off ss=off hh=off hr=on ]
[chara_show name="kazu" layer="1" width="437" height="720" left="760" top="0" wait="true" time=150]

[:kazutika:]
「什么叫没关系的？」[rhp]

[:kaoru:][kaoru kao=3 ]
「我小学踢足球那会儿啊，[rhr]
_　大哥对着融入不了球队的我这么说过」[rhp]
[:kaoru:]
「大哥的朋友就是我的朋友。所以挺起胸膛来也没关系。[rhr]
_　也就是说，我的朋友也是大哥的朋友对吧？」[rhp]

[:sora:][p_ot_22][otiai kao=2 as=on ]
「这、这完全是两码事，」[rhp]

[:kazutika:][kazu kao=13 ]
「喂喂，所以说咱俩在见面之前就是朋友咯？」[rhp]

[:kaoru:][kaoru kao=1 ]
「就是这个意思！」[rhp]

[:sora:][otiai kao=3 as=on ]
「薰，你这家伙真是～……！」[rhp]

[off_all]

[::]
拜薰所赐，我似乎多了些傻里傻气的临时朋友。[rhp]
要是和临终关怀院那些家伙扯上关系，[rhr]
说不定会让薰的运势下降……[rhp]

[chara_part name="rio2" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="rio2" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kaoru" body=base kao=5 as=off ss=off hr=on ]
[chara_show name="kaoru" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:kaoru:]
「理央君、和近君！咱们也去借望远镜吧！[rhr]
_　用望远镜看天河能有多清楚呢？」[rhp]

[:rio:][p_ri2_31][rio2 kao=14 ]
「肯定超级大啦！光是普通看起来，就已经这么广阔了」[rhp]

[off_kaoru]

[chara_part name="kazu" body=base kao=5 as=off ss=off hr=on ]
[chara_show name="kazu" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:kazutika:][kazu kao=13 ]
「说不定比理央的尿床地图还大呢」[rhp]

[:rio:][rio2 kao=3 as=on hh=on ]
「才、才没有尿过床啦！和近君好过分……！」[rhp]

[off_all]

[:sora:][otiai kao=0 ]
「………………」[rhp]

[off_all]

[::]
……真是群让人无语的家伙。[rhp]
薰的房间和八云君这般敞亮，都是因为顾虑着我的感受，[rhr]
我一直以为临终关怀院会是更加阴森昏暗的地方。[rhp]
明明都生病了，这么悠闲真的好吗。[rhp]
……………………。[rhp]

[:sora:]
[font color=0x4682b4]
（…………若还活着的话，这样就好吗）[rhp]
[resetfont]

[::]
倘若这就是本该痛苦的薰能始终保持笑容的原因。[rhp]
倘若这就是能活得稍微长久些的秘诀。[rhp]

[:sora:]
[font color=0x4682b4]
（……朋友吗……）[rhp]
[resetfont]

[::]
……倒也不是完全没考虑过。[rhp]

;****************************************
[bg_rule storage="hsps_09n.jpg" rule="002.png" time=1500]
;****************************************

;------------------------------------------------------------------------------------------
;▼再開▼
;タケル
[voconfig sebuf=1 name=take vostorage="take/full/{number}.ogg" number=69]
[vostart]
;------------------------------------------------------------------------------------------

[:hirosi:]
「……………………」[rhp]

[se storage="door_13.ogg"]

[::]
[rhp]

[se storage="door_07.ogg"]

[:takeru:][take kao=1 ]
「八云君」[rhp]

[:hirosi:][hiro kao=3 ]
「！请问哪位？」[rhp]

[:takeru:]
「我是矢部。晚上好」[rhp]

[:hirosi:][hiro kao=1 ]
「初次见面，矢部先生。您是这户人家的人吗？」[rhp]

[:takeru:]
「算是吧」[rhp]

[:hirosi:][hiro kao=7 ]
「矢部先生，今晚的星星特别美呢」[rhp]

[:takeru:][take kao=11 ]
「因为是七夕啊。[rhr]
_　我和你一样在守家，不过外面倒是办了些小活动」[rhp]

[:hirosi:][hiro kao=1 ]
「原来如此。我睡着时听见孩子们的声音就醒了。[rhr]
_　往外一看……没想到星空竟如此璀璨！」[rhp]

[:takeru:][take kao=5 ]
「那当然。这天可是天河最清晰的日子啊」[rhp]

[:hirosi:][hiro kao=13 ]
「原来如此。[rhr]
_　虽然不知道是哪位，但还是谢谢您告诉我」[rhp]

[:takeru:][take kao=11 ]
「哪里哪里」[rhp]

[:hirosi:][hiro kao=5 ]
「……话说哥哥，我刚才在想」[rhp]

[off_all]

;****************************************
#
[bg storage="sky_12.jpg"  time=500]
;****************************************

[:hirosi:]
「总觉得那个叫天河的东西，看起来很像列车呢」[rhp]

[:takeru:]
「……！」[rhp]

[:hirosi:]
「从南向北延伸，简直就像一列长长的列车」[rhp]
[:hirosi:]
「真好啊。我也好想有天能坐上列车，周游世界」[rhp]

[:takeru:]
「…………是啊……会实现的。总有一天一定」[rhp]

[:hirosi:]
「好！」[rhp]
[:hirosi:]
「……不过，真是美得不可思议啊……[rhr]
_　那个列车状的星群，究竟是什么？」[rhp]

[:takeru:]
「…………是『银河铁道』哦」[rhp]

[:hirosi:]
「银河铁道？」[rhp]

[:takeru:]
「没错。在天空飞驰的魔法列车」[rhp]
[:takeru:]
「你也一定能坐上的。那时候就能周游世界了」[rhp]
[:takeru:]
「天空列车没有轨道。终有一天你[rhr]
_　能去往任何地方，知晓所有事情」[rhp]
[:takeru:]
「……再稍作忍耐就好」[rhp]

[:hirosi:]
「―――！　好期待啊！」[rhp]

[:takeru:]
「是啊……真是……太好了……」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
[fbgm]
[free_filter ]
[set_b storage="sky_08.jpg"]
[bgm storage="bgm_09.ogg"]
;****************************************

七夕会结束后，真的度过了手忙脚乱的日子。[rhp]
虽然和那些人的距离拉近了些，[rhr]
但也没到特别亲密的程度。[rhp]
……或者说我和他们，都没那个心情。」[rhp]

;****************************************
[bg storage="black.jpg" time=500]
;****************************************

转瞬间时光流逝，12月。[rhp]
这段日子里，连一件开心的事都没有。[rhp]

;****************************************
[set_kk storage="sky_13.jpg" time=1000]
;****************************************

七夕会次月，八云君死了。[rhr]
那是8月中旬，天鹅座清晰可见的夜晚。[rhp]

;****************************************
[set_kk storage="hsps_08.jpg" time=1000]
;****************************************

2个月前，10月。[rhr]
薰变得无法吃苹果了。[rhp]
随着日子一天天过去，他逐渐丧失食欲，连医院餐食都会剩下。[rhp]

;****************************************
[set_kk storage="hsps_09.jpg" time=1000]
;****************************************

11月。被转移到101号室的薰，大多数时间都在沉睡。[rhr]
自那以后便持续着无法正常对话的日子。[rhp]

;****************************************
[set_ff storage="black.jpg" time=1500]
;****************************************

……然后，到了今天。[rhp]

;****************************************
[set_n storage="hsps_06n.jpg" time=1500]
;****************************************

[:soramama:]
「……老师。真的太感谢您了」[rhp]

[::]
妈妈正在和矢部老师说话。[rhr]
从稍远的地方听着那番动静。[rhp]
简直像在听别人的事一样。[rhr]
丝毫没有真实感。[rhp]
………今天、薰去世了。[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sora:]
「………………」[rhp]

[::]
他最喜欢足球、总是一刻不停地摆弄着球。[rhr]
说是要回到少年队，等上了中学就加入足球社。[rhp]
曾约定过总有一天要两人一起去看J联赛。[rhr]
我说服了妈妈他们，就我们俩去旅行。[rhp]
这世上明明还有数不清的其他孩子。[rhr]
……为什么非得是薰。薰做了什么吗？[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:takeru:][take kao=3 ]
「……真的很抱歉。如果我再强大一点的话……」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[::]
既然明白就不该从一开始接收来这种地方。[rhr]
要是在主楼继续治疗的话，薰也许早就痊愈了。[rhp]
所以我从一开始就讨厌临终关怀院这种地方。[rhp]

;走る
[se storage="leg_04.ogg"]

[:sora:]
「―――！！」[rhp]

[off_all]

[:soramama:]
「宙，你要去哪！？」[rhp]

[:sora:]
「烦死了！！」[rhp]

[::]
不想和任何人说话，也不想看见任何人的脸。[rhr]
我发疯似地冲向了走廊……[rhp]

;****************************************
[set_b storage="hsps_10n.jpg"]
;****************************************

漫无目的奔跑的我，回过神来已置身于中庭。[rhp]
……也许是因为这里残留着与薰最后的特别回忆。[rhp]

;****************************************
[bg storage="sky_07.jpg" time=1000]
;****************************************

抬头望向夜空，仙后座在头顶闪闪发光。[rhr]
这是和八云君与薰一起仰望时未曾见过的星座。[rhp]

……薰是受了八云君影响才喜欢上观星的。[rhr]
托他们的福，我也变得对此了如指掌。[rhp]
本以为今年冬天，一定能三人一起仰望这片星空的。[rhp]

[:sora:]
「…………」[rhp]

[::]
…………当初应该许愿的。[rhp]
像八云君那样，我也该折千纸鹤的。[rhp]

虽然我系在那串千纸鹤上的愿望没有实现，[rhr]
但八云君的愿望，一定是那个最重要的心愿成真了。[rhp]
因为那晚的天河上，确实横亘着绝美的天鹅座。[rhp]
那分明是为八云君绽放的星空。[rhr]
接我的来了。期盼已久的、银河铁道。[rhp]

……折一千只纸鹤的话 薰的命运是否就会改变呢。[rhr]
因为什么都没做 所以只剩下后悔。[rhp]

[:sora:]
「…………呜、呜……」[rhp]

[::]
对不起啊 薰。[rhr]
哥哥没能保护你。[rhp]
哥哥没能替你承担。[rhp]
……、……明明身为哥哥……。[rhp]

;****************************************
[bg storage="hsps_10n.jpg" time=1000]
;****************************************

[:himeko:][hime2 kao=3 ]
「宙君？」[rhp]

[off_all]
;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:sora:][otiai kao=3 ]
「…………！」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[::]
……、星名[player2]……[rhp]

[chara_part name="otiai" body=base kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:himeko:]
「吓死我了……！因为从窗户看到人影　还以为是有人就过来了」[rhp]
[:himeko:]
「怎么了　在这种地方？会感冒的哦」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sora:][otiai kao=6 ]
「……没什么」[rhp]

[off_all]

[::]
薰死了的事 你不可能不知道。讨厌的家伙……[rhp]

[chara_part name="otiai" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:himeko:]
「……薰君、……的事、对吧……」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:sora:][otiai kao=8 ]
「………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:himeko:][hime2 kao=7 as=on ]
「啊、阿姨来过了呢。哭得特别厉害……[rhr]
_　………、其实我刚才、也哭了」[rhp]

[:sora:][otiai kao=2 ]
「…………什么事啊。如果是废话就别来搭话」[rhp]

[:himeko:][hime2 kao=4 ]
「啊、那个。不是的……呃」[rhp]
[:himeko:]
「宙君、能稍微跟我来一下吗？」[rhp]

[:sora:][otiai kao=0 ]
「不要……」[rhp]

[:himeko:][hime2 kao=3 as=on ]
「薰君他啊、之前有件事拜托过我哦」[rhp]

[:sora:][otiai kao=8 ]
「……诶……薰？」[rhp]

[:himeko:][hime2 kao=0 as=on ]
「你马上要离开了吧。所以在走之前」[rhp]
[:himeko:]
「如果再也不来了的话，[rhr]
_　就无法实现薰君的愿望了」[rhp]

[off_all]

;****************************************
[set_b storage="hsps_03n.jpg"]
;****************************************

[:sora:][otiai kao=6 ]
「………………」[rhp]

[:himeko:][hime2 kao=13 ]
「这里呢，本来是大家一起进行娱乐活动的场所」[rhp]

[:sora:][otiai kao=3 ]
「知道」[rhp]
[:sora:]
「……这里是干嘛的？完全搞不懂」[rhp]

[:himeko:][hime2 kao=1 ]
「矢部医生偶尔会组织'大家一起画画'的活动。[rhr]
_　当时画的画就装饰在这里哦」[rhp]
[:himeko:]
「就算我亲自去请 他也只肯待在走廊不肯进来[rhr]
_　所以也想拜托你帮忙说情」[rhp]
[:himeko:]
「自从七夕会之后 就很少能见到宙君了……[rhr]
_　拖到现在才告诉你 对不起呢」[rhp]

[:sora:][otiai kao=2 ]
「什么啊这种话。要是我在场的话 肯定会好好......」[rhp]

[off_all]

;****************************************
;スチル
[still storage="cg/c_2n.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/c_2n.png"]
;****************************************

[:himeko:]
「快看。那幅画是薰君画的哦」[rhp]

[::]
在众多装饰画中 发现了写有「薰」字的一幅。[rhp]
画上戴着奇怪帽子的三人组。[rhp]

[:sora:]
「…………？谁啊？」[rhp]

[:himeko:]
「不不 怎么看都是宙君和博士跟薰君嘛」[rhp]
[:himeko:]
「博士和薰君那幅 主题是银河铁道来着。[rhr]
_　他们精神还好的时候 最后一起画的 所以是两个人共绘一幅」[rhp]
[:himeko:]
「博士是冒险家，宙君是列车员呢」[rhp]

[:sora:]
「……为什么我是」[rhp]

[:himeko:]
「说是因为你一本正经又很了不起的样子」[rhp]

[:sora:]
「什……！？」[rhp]

[:himeko:]
「呵呵！很有趣吧，薰君」[rhp]

[:sora:]
「完全听不懂……！我明明很普通啊……」[rhp]

[:himeko:]
「但是薰君的衣服为什么全黑呢，[rhr]
_　害羞到最后都没告诉我呢」[rhp]
[:himeko:]
「还有旁边那个圆形的东西是什么……宙君知道吗？」[rhp]

[:sora:]
「…………」[rhp]

[::]
……当然知道。[rhr]
那是……[rhp]

[:sora:]
「………………足球」[rhp]

[:himeko:]
「诶。薰君原来喜欢足球吗？」[rhp]

[:sora:]
「他说上了中学后想加入足球部」[rhp]
[:sora:]
「那是中学的校服」[rhp]

[:himeko:]
「这样啊。所以才黑色的呢」[rhp]
[:himeko:]
「一定是憧憬着哥哥吧。[rhr]
_　每次来这里时，宙君都穿着校服呢」[rhp]

[:sora:]
「……笨蛋啊。先考虑小学的事吧」[rhp]

[:himeko:]
「没什么不好呀。而且不只是薰君。[rhr]
_　在我们看来宙君也闪闪发光哦」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------
[:sora:]
「…………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

;****************************************
#
[bg storage="black.jpg"]
;****************************************

[::]
――――『哥哥，踢足球开心吗？』[rhp]

;****************************************
[bg storage="hsps_03n.jpg"]
;****************************************

[:sora:]
「………………」[rhp]

[::]
…………真是笨蛋，我。[rhr]
事到如今居然想起那种约定。[rhp]
为了探望而退出的社团活动，到头来也只是徒增悲伤吧……[rhp]

[chara_part name="otiai" body=base kao=8 as=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:himeko:]
「没关系的，宙君」[rhp]

[:sora:][otiai kao=3 ]
「什么叫没关系。你根本不懂我的心情……」[rhp]

[:himeko:][hime2 kao=13 ]
「现在啊，薰君一定在踢足球哦」[rhp]

[:sora:][otiai kao=2 ]
「……这种安慰就免了」[rhp]

[:himeko:][hime2 kao=1 ]
「不是的。这不是安慰」[rhp]

[fbgm]

[:himeko:]
「听我说呀，住在这里的孩子呢。[rhr]
_　死后真的能乘坐银河铁道哦？」[rhp]

[:sora:][otiai kao=4 as=on ]
「……哈……？」[rhp]

[off_all]

[bgm storage="bgm_12.ogg"]

[:himeko:][hime2 kao=13 ]
「快来！」[rhp]

[off_all]

[:sora:][otiai kao=2 ]
「……！　喂……！」[rhp]

[off_all]

;****************************************
[set_b storage="hsps_02n.jpg"]
;****************************************

[:himeko:][hime2 kao=14 ]
「快点快点。这边！！」[rhp]

[off_all]

[::]
被拉着来到的地方，是临终关怀院的入口大厅。[rhr]
那家伙站在悬挂于此处的大型绘画前，朝我招手。[rhp]

;****************************************
[bg storage="cg/b2_1.png" time=1500]
;****************************************

[:sora:]
「……这幅画怎么了。[rhr]
_ 每次来都看到 早就知道了」[rhp]

[:himeko:]
「这个呀，可不是普通的话哦。[rhr]
_ 博士在忘记太多事情之前 告诉我的……」[rhp]

;****************************************
;スチル
[still storage="cg/c_3.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/c_3.png"]
;****************************************

[:himeko:]
「……听说这个银河站里，住着神明大人哦！」[rhp]

[:sora:]
「哈啊？」[rhp]

[:himeko:]
「然后呢，博士好像和那位神明大人约好了。[rhr]
_　总有一天要带他去和这幅画里相同的世界」[rhp]
;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:sora:]
「――――！」[rhp]

[:himeko:]
「博士不可能说谎的。神明大人绝对存在哦。[rhr]
_　只要我们像博士那样一直做好孩子，就一定能去那个世界」[rhp]
[:himeko:]
「薰君现在一定也在那个世界。[rhr]
_　因为薰君是比谁都在意哥哥、比谁都温柔的孩子啊」[rhp]

[:sora:]
「…………」[rhp]

[:himeko:]
「每当痛苦时我就看着这幅画，想象崭新的自己。[rhr]
_　银河铁道上的我，比任何人都耀眼，比任何人都温柔，是完美的女孩子」[rhp]
[:himeko:]
「我想薰君一定也怀着同样的想象」[rhp]
[:himeko:]
「薰君现在一定正在这个美好的世界里，[rhr]
_　尽情踢着足球呢」[rhp]

;****************************************
[bg storage="cg/c_3b.png" width="1280" height="720" time=500]
[cg storage="cg/c_3b.png"]
;****************************************

[:himeko:]
「所以啊，宙君」[rhp]
[:himeko:]
「我们已经没有什么可悲伤的事了」[rhp]

;****************************************
;スチル
[bg storage="cg/c_4.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/c_4.png"]
;****************************************

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sora:]
「…………、……」[rhp]

[::]
…………你懂薰的什么。[rhr]
薰究竟在想什么，谁都无从知晓。[rhp]
……我当然也想相信啊。[rhp]
但是…………[rhp]

;****************************************
#
[bg storage="cg/c_4b.png" width="1280" height="720" time=500]
[cg storage="cg/c_4b.png"]
;****************************************

[:sora:]
「…………他没生气吧」[rhp]

[:himeko:]
「生气？为什么？」[rhp]

[:sora:]
「比如没能说出对那幅画的感想。[rhr]
_　…………比如擅自放弃足球的事」[rhp]
[:sora:]
「……那家伙，一定很失望吧……」[rhp]

[:himeko:]
「……或许是这样……」[rhp]
[:himeko:]
「…………但现在开始也完全来得及！」[rhp]

;****************************************
#
[bg storage="cg/c_4.png" width="1280" height="720" time=500]
;****************************************

[:sora:]
「诶……」[rhp]

;****************************************
#
[bg storage="cg/c_3b.png" width="1280" height="720" time=500]
;****************************************

[:himeko:]
「感想随时都能说，足球重新开始踢就好啦。[rhr]
_　从天空俯瞰的薰君也会因此满足的！」[rhp]

[:sora:]
「…………啊」[rhp]

[:himeko:]
「薰君本是个开朗的孩子。[rhr]
_　潮湿阴暗可不好呢，今天哭着哭着突然明白了」[rhp]
[:himeko:]
「但只要稍不留意果然还是想哭。[rhr]
_　现在靠着回忆薰君的事，勉强维持着现状……」[rhp]

[:sora:]
「…………、你……」[rhp]

[:himeko:]
「也告诉宙君吧。他刚搬来的时候啊？[rhr]
_　起夜去厕所的薰君，在黑暗中看到摆着的魔太郎子就……」[rhp]

;****************************************
#
[bg storage="cg/c_4b.png" width="1280" height="720" time=1000]
;****************************************

[:sora:]
「你啊……真是够笨的欸……」[rhp]

[:himeko:]
「！？笨、笨蛋！？」[rhp]

[:sora:]
「该怎么说……从刚才开始就真的，该说是直线思考呢……[rhr]
_　还是该说天真烂漫呢……」[rhp]

;****************************************
#
[bg storage="cg/c_4b.png" width="1280" height="720" time=500]
;****************************************

[:sora:]
「…………不过心里稍微轻松些了」[rhp]

[:himeko:]
「……！欸嘿嘿……那就算了吧」[rhp]

;****************************************
#
[bg storage="cg/c_4b.png" width="1280" height="720" time=500]
;****************************************

[:sora:]
「…………、…………我说啊」[rhp]
[:sora:]
「…………之前对你冷淡抱歉了」[rhp]

[:himeko:]
「！」[rhp]

[:sora:]
「我……以前除了薰以外，觉得谁都无所谓」[rhp]
[:sora:]
「但我弟弟是被你和这里大家支撑着的啊。[rhr]
_　所以明明总是很痛苦，在我面前却还保持着笑容」[rhp]

;****************************************
#
[bg storage="cg/c_4c.png" width="1280" height="720" time=500]
;****************************************

[:sora:]
「…………从来都不是无所谓啊」[rhp]

[:himeko:]
「宙君……」[rhp]

[:sora:]
「……、虽然薰已经不在了。[rhr]
_　还能再来这里吗？不是以探病的名义…」[rhp]
[:sora:]
「……作为朋友」[rhp]

;****************************************
#
[bg storage="cg/c_5.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/c_5.png"]
;****************************************

[:himeko:]
「当然可以！」[rhp]

[:sora:]
「哇……！　等、等一下」[rhp]

[:himeko:]
「谢谢你！我好开心，宙君！[rhr]
_　我们刚才还在讨论。要怎么才能和宙君一起玩！」[rhp]
[:himeko:]
「刚才的话是真的吧？没有骗我吧？」[rhp]

[:sora:]
「…………不是谎言」[rhp]

[:himeko:]
「事后可不准反悔说『还是算了』哦！」[rhp]

[:sora:]
「才不会说」[rhp]

[:himeko:]
「嘿嘿…！我会等你的！」[rhp]

[:sora:]
「………………」[rhp]
[:sora:]
「………………嗯」[rhp]

;****************************************
;スチル終了
[s_mask color=0x000000 time=3000]
#
[bg storage="hsps_02n.jpg" time=100]
; ウィンドゥの設定
[position layer="message0" frame="win2.png" left=0 top=520 width=1280 height=200 page=fore visible=true]
[s_mask_off time=3000]

;****************************************

[:soramama:]
「宙。原来你在这里」[rhp]

[:sora:][otiai kao=7 ]
「！妈妈……」[rhp]

[:soramama:]
「抱歉让你久等了。手续办完了，我们先回家…」[rhp]

[off_all]

[:himeko:][hime2 kao=1 ]
「阿姨好」[rhp]

[:soramama:]
「哎呀，[player2]。好久不见」[rhp]

[off_all]

[:sora:][otiai kao=3 ]
[font color=0x4682b4]
（妈妈居然认识这家伙…）[rhp]
[resetfont]

[off_all]

[:himeko:][hime2 kao=3 ]
「…………薰君已经走了吗？」[rhp]

[:soramama:]
「嗯…刚刚才往家那边去了」[rhp]

[:himeko:][hime2 kao=12 ]
「这样啊…」[rhp]

[:soramama:]
「[player2]谢谢你一直和薰那么要好。[rhr]
_　薰一定也很感激你」[rhp]

[:himeko:][hime2 kao=13 ]
「嗯。我们也玩得超级开心！」[rhp]

[off_all]

[chara_part name="otiai" body=base kao=0 as=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:himeko:][hime2 kao=14 ]
「……阿姨、宙君。下次再来玩啊。[rhr]
_　关于你们不认识的薰君的事，我觉得能告诉你们很多」[rhp]
[:himeko:]
「记忆里的薰君永远都是精神满满的。[rhr]
_　所以，随时都可以来看他哦」[rhp]

[:soramama:]
「呜、嗯……谢谢……」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:sora:][otiai kao=3 ]
「……………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[::]
…………奇怪的家伙。[rhr]
是笨蛋呢，还是确实经过深思熟虑呢。[rhp]
但要是没有这家伙在的话，我肯定[rhr]
至今都无法接受这个地方吧。[rhp]

[chara_part name="otiai" body=base kao=0 as=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sora:][otiai kao=1 ]
「………………谢谢」[rhp]

[:himeko:][hime2 kao=4 ]
「！」[rhp]

[chara_part name="otiai" body=base kao=11 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sora:]
「那……再见」[rhp]

[:himeko:][hime2 kao=1 ]
「……嗯！再见……！」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
[set_n storage="car.jpg"]
;****************************************

[::]

薰的葬礼决定在家举行，遗体已于不久前运送过去。[rhr]
我们也踏上归途，坐上车随着母亲的驾驶摇晃着。[rhp]
时隔许久乘坐的后排座位。[rhr]
曾经薰坐在身旁的日子，如今想来已恍如隔世。[rhp]
路灯稀疏的道路，今天显得格外昏暗。[rhp]

[:sora:]
「……………………」[rhp]

[:soramama:]
「……………………」[rhp]

[::]
…………没有对话。[rhp]
不过，向来如此。[rhr]
并非因为今天是特殊的日子。[rhp]
我和父母的关系，本就算不上融洽。[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sora:]
「…………快到了吧。薰」[rhp]

[:soramama:]
「！啊……嗯。……刚才爸爸发邮件来了」[rhp]

[:sora:]
「哼嗯……」[rhp]

[::]
………………真意外。[rhr]
妈妈居然会主动和我搭话。[rhp]
平时我们仅仅交换最低限度的必要信息，[rhr]
她总是像对待脓肿般小心翼翼地与我对接。[rhp]
像这样正常对话的情景已经多少年没有过了。[rhp]
妈妈像是整理情绪般短促而沉重地叹了口气。[rhr]
她那强撑笑容的脸庞，透过后视镜与我四目相对。[rhp]

[:soramama:]
「……呵呵。[player2]小酱，刚才很沉着呢。[rhr]
_　看起来比我稳重得多……真让人惊讶」[rhp]

[:sora:]
「嗯……」[rhp]

[:soramama:]
「宙和[player2]你们关系真的很好吗？」[rhp]

[:sora:]
「………………」[rhp]
[:sora:]
「……………………友达」[rhp]

[:soramama:]
「！　是的。宙的……」[rhp]
[:soramama:]
「…………，这样啊」[rhp]

[:sora:]
「什么？」[rhp]

[:soramama:]
「唔嗯……真是松了一口气呢。[rhr]
_　今天，有好好待在宙身边的人了呢」[rhp]
[:soramama:]
「…………但那原本应该是妈妈的职责才对啊」[rhp]

[:sora:]
「……！」[rhp]

;****************************************
#
[bg storage="sky_07.jpg"]
;****************************************
;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:soramama:]
「对不起……宙。妈妈真的是个不称职的妈妈呢。[rhr]
_　把你的置之不理，只顾着自己哭」[rhp]
[:soramama:]
「……宙你，其实从一开始就一直想哭的吧……」[rhp]

[:sora:]
「………………」[rhp]

[::]
母亲并非完美的人。[rhp]
我并没有在追求那样的母亲。[rhp]
或许正因为如此。薰消失后，[rhr]
肩上的担子卸下了……这种说法虽然听起来不太顺耳。[rhp]
这个人一直对我抱有愧疚。[rhr]
这样的母亲现在再次试图转向我这边。……我如此感觉到。[rhp]

[:sora:]
「………………」[rhp]

;****************************************
#
[bg storage="black.jpg" time=1000]
;****************************************

『难道要不尽全力就放弃到最后吗！[rhr]
_　太差劲了。你们是最差劲最烂的混蛋父母！』[rhp]
『我为流着这种父母血液的自己感到羞耻。[rhr]
_　被你们这样的人渣生下来的我们真可怜！』[rhp]
『所以薰才会得那种病！』[rhp]

年幼时的我真心这么认为，斩钉截铁地说出了这些话。[rhp]
但现在已经明白了。[rhr]
母亲和父亲是怀着多大的勇气做出那个选择的。[rhp]
独自去探病，亲眼目睹薰病情的变化，[rhr]
才真正体会到现实有多残酷。[rhp]
……不。或许其实从一开始就明白。[rhp]
是我不愿正视现实。[rhr]
不愿承认希望和最优解是不同的。[rhp]
我对这个人展现过太多无法用年少无知搪塞的态度。[rhp]

;****************************************
[bg storage="sky_07.jpg" time=1000]
;****************************************

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sora:]
「…………妈妈」[rhp]
[:sora:]
「抱歉」[rhp]

[:soramama:]
「…………啊」[rhp]

[::]
因意外而惊慌的声音。……这也难怪。[rhr]
迄今为止的我，是个无论被说什么都用轻蔑态度回应的混账小鬼。[rhp]
老土又窝囊。我知道这样子的自己很丢脸。[rhp]
……但是，我必须道歉。[rhp]
要改变的话就只有现在了。[rhp]

[:sora:]
「…………对不起。一直以来的事」[rhp]

[:soramama:]
「………………」[rhp]

[::]
…………母亲始终没有给出回应。[rhp]
取而代之的，是微微漏出一声呜咽。[rhp]


[:sora:]
「别哭啦。我还在开车呢」[rhp]

[:soramama:]
「…嗯……是啊……对不起……对不起……」[rhp]
[:soramama:]
「其实妈妈和爸爸啊……都是胆小鬼……没有勇气……」[rhp]
[:soramama:]
「让一直痛苦的薰[rhr]
_　为了满足我们希望你活下去的任性 而继续陪伴我们的勇气…」[rhp]

[:sora:]
「………………」[rhp]

[:soramama:]
「……妈妈啊……到底该怎么做才好 到现在也搞不明白」[rhp]
[:soramama:]
「活着与死去……究竟哪一边才是薰的幸福呢……」[rhp]

[:sora:]
「……无论哪一边，薰现在都还在某处精神十足地生活着」[rhp]
[:sora:]
「说是和八云君一起在银河铁道上……星名[player2]这么说的」[rhp]

[:soramama:]
「……银河鉄道……」[rhp]
[:soramama:]
「…………嗯、这样啊……。[rhr]
_　那他现在一定正和浩君一起在各种地方旅行吧」[rhp]
[:soramama:]
「那样的话绝对会幸福……太好了太好了……」[rhp]
[:soramama:]
「…………呜……」[rhp]

;****************************************
#
[bg storage="sky_12.jpg" time=1000]
;****************************************

[::]
――――这是个无比漫长的夜晚。[rhp]
虽然薰的离去让我悲痛欲绝，[rhr]
但那个教会我许多事情的家伙，他的死绝非毫无意义。[rhp]

我大概再也不会踢足球了吧。[rhr]
毕竟没有了薰的球场，肯定再也找不回那份快乐。[rhp]
他知道了肯定会生气吧。不过没关系。[rhr]
这次的选择是有意义的。[rhp]

[:sora:]
[font color=0x4682b4]
（…………看着吧，薰）[rhp]
[resetfont]

[::]
我已经下定决心了。[rhp]
将来要成为一名医生。[rhp]
……但不是普通的医生。[rhp]

等我当上医生时，临终关怀院就该从世界上消失了。[rhp]
因为我会找到根治所有疾病的方法，[rhr]
再没人需要住进去，那些机构自然就经营不下去了。[rhp]

……连我自己都觉得这妄想可笑。[rhr]
但人总该有做梦的权利。[rhp]
任何荒诞的梦想都存在着实现的可能性，[rhr]
八云君和薰已经向我证明了这点。[rhp]
所以我会继续努力的。[rhp]

[:sora:]
「『再也不会，有悲伤的事了』……」[rhp]

[::]
忽然想起当年八云君让我读过的那篇小说。[rhp]
当然刚才只是自我安慰。[rhr]
此刻正经历着出生以来最撕心裂肺的痛苦。[rhp]
正因如此才会忍不住祈愿。[rhr]
希望终有一日能在真正的意义上说出这句话。[rhp]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
[fbgm]

[s_mask color=0x000000 time=2000]
; 背景表示
[bg storage="train_01.jpg" time=100]
; 全部のフィルターを打ち消す
[free_filter ]
; ウィンドゥの設定
[position layer="message0" frame="win.png" left=0 top=520 width=1280 height=200 page=fore visible=true]
[s_mask_off time=2000]

[bgm storage="bgm_15.ogg"]
;****************************************

那时―――[rhp]

[chara_part name="sausu" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="kaoru" body=unif kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="kaoru" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sausu:]
「―――那就这样啦，薰」[rhp]
[:sausu:]
「我差不多该回去了，暂时先说再见咯」[rhp]

[:kaoru:][kaoru body=unif kao=3 ]
「这样啊～南要走了吗」[rhp]

[:sausu:]
「要是我能带路就好了……不过交给多洛普吧」[rhp]

[:kaoru:][kaoru body=unif kao=1 ]
「多洛普？」[rhp]

[:sausu:][sausu kao=5 ]
「这里的员工啦。肯定会好好照顾你的」[rhp]

[:kaoru:][kaoru body=unif kao=13 ]
「难得能这样正经聊天呢。[rhr]
_　你在医院一直昏迷不醒，我可是很期待见面的。真遗憾啊……」[rhp]

[:sausu:][sausu kao=14 ]
「呵呵，谢谢。和沉睡中的你对话也很开心哦。[rhr]
_　那种情况，是叫心灵感应来着？」[rhp]

[:kaoru:][kaoru body=unif kao=1 ]
「没错！超级厉害的！」[rhp]

[:sausu:][sausu kao=1 ]
「呵呵……！我还会再来的。[rhr]
_　到时候可要跟我讲讲旅途见闻啊」[rhp]

[:kaoru:][kaoru body=unif kao=13 ]
「嘿嘿……！知道啦！」[rhp]

[off_all]

[:sausu:][sausu kao=5 ]
「那么，回见。旅途愉快」[rhp]

[off_all]

;****************************************

[s_mask color=0xffffff time=2000]
; 背景表示
[bg storage="hsps_02m.jpg" time=100]
; 夜フィルター
[filter layer="1" brightness="60"]
; ウィンドゥの設定
[position layer="message0" frame="win2.png" left=0 top=520 width=1280 height=200 page=fore visible=true]
[s_mask_off time=2000]

;****************************************

[:sausu:][sausu kao=7 ]
「………呼………我回来啦……」[rhp]
[:sausu:]
「…………话说从今天起又没人了呢」[rhp]

[off_all]

[:yoru:][yoru kao=6 ]
「欢迎回来」[rhp]

[off_all]

[:sausu:][sausu kao=4 as=on ]
「哇！！」[rhp]

[:yoru:][yoru kao=7 ]
「工作辛苦了……姑且这么说说吧」[rhp]

[:sausu:][sausu kao=3 ]
「约、约尔大人……！？真稀奇啊，居然会来101号室」[rhp]

[:yoru:][yoru kao=0 ]
「薰平安送到了吗？」[rhp]

[:sausu:][sausu kao=13 as=on ]
「―――！　啊！　他可是非常高兴呢！」[rhp]
[:sausu:]
「当他被移送到101号室时，已经说不出话了。[rhr]
_　那还是我第一次实际听到他的声音，真是令人欣慰……！」[rhp]

[:yoru:][yoru kao=6 ]
「这样啊……」[rhp]
[:yoru:]
「……又增加了被你害的人」[rhp]

[:sausu:][sausu kao=3 ]
「…………，约尔大人依然不愿理解我的所作所为呢」[rhp]

[:yoru:][yoru kao=0 ]
「『依然』？别用这种还留有余地的说法」[rhp]
[:yoru:]
「我永远不会认可你愚蠢的行为，[rhr]
_　也不会对你那荒唐的理想点头」[rhp]

[:sausu:][sausu kao=13 ]
「……是吗。我倒无所谓。[rhr]
_　我的愿望是孩子们的笑容，并不需要你的微笑」[rhp]

[:yoru:][yoru kao=8 ]
「主从关系颠倒了。[rhr]
_　不得不对那群被小鸟戏耍、关在鸟笼里的家伙表示同情」[rhp]

[:sausu:][sausu kao=0 as=on ]
「这种说法。我只是，」[rhp]

[:yoru:][yoru kao=2 ]
「尽管享受你们的自由吧。[rhr]
_　等我取回力量，折断那双翅膀只是时间问题」[rhp]

[:sausu:][sausu kao=1 ]
「…………，真令人期待。那么？具体是什么时候呢？」[rhp]

[:yoru:][yoru kao=0 ]
「…………」[rhp]

[:sausu:][sausu kao=13 ]
「我会继续警惕你。[rhr]
_　建议别太小看对手比较好……」[rhp]
[:sausu:]
「……彼此彼此吧」[rhp]

[:yoru:][yoru kao=2 ]
「啧……！　嘴还是这么硬」[rhp]

[:sausu:][sausu kao=1 ]
「哈哈哈！　刚说完就惹你生气了」[rhp]
[:sausu:]
「那今天就先到这里。再见，约尔大人」[rhp]

[bg_magic_d]

[::]
以一如既往的作风，南的身影消失了。[rhp]
气息仍残留于此。毕竟他的凭依物就在这个房间里。[rhr]
或许只是无法显形，他应该还待在房间里。[rhp]
『无法显形』这种事，本不该发生在我身上。[rhr]
竟被那男人削弱到这般地步……真令人火大。[rhp]

[:yoru:]
「……你该不会以为自己是青鸟吧……」[rhp]

[::]
…………实在令人不快。[rhp]

;****************************************
[fbgm]
[set_ff storage="sky_05.jpg"]
[bgm storage="bgm_27.ogg"]
;****************************************

从那以后，我开始频繁出入临终关怀院。[rhp]
薰离去留下的伤痕或许永远无法痊愈。[rhr]
但是[player2]和理央他们在一起时，就觉得自己能背负着这份伤痛，连那家伙的份一起活下去。[rhp]
定要实现成为医生的梦想，绝不让这些孩子重蹈薰和八云君他们的[rhr]
覆辙——这样的念头愈发强烈。[rhp]

;****************************************
[bg storage="hsps_13.jpg" time=1000]
;****************************************

[chara_part name="otiai" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="rio2" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="rio2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:rio:][p_ri2_04]
「和宙君同乘巴士还是第一次呢！」[rhp]

[:sora:][p_ot_27][otiai kao=1 ]
「你平时都这个时间乘车吗？」[rhp]

[:rio:][rio2 kao=13 as=on ]
「不、不是的……！　今天我试着预判了。[rhr]
_　想着宙君可能会这个时间坐车……」[rhp]

[off_all]

[::]
理央虽然年幼却十分懂事，[rhr]
低调的性格和我很合得来，相处起来很舒服。[rhp]
偶尔我们俩也会约好时间，一起去临终关怀院。[rhp]

;****************************************
[bg storage="hsps_08.jpg" time=1500]
;****************************************

[:kazutika:][kazu kao=5 ]
「这烟花真寒酸……」[rhp]

[off_all]

[chara_part name="otiai" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kazu" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="kazu" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sora:][p_ot_03][otiai kao=1 ]
「噗……！是有点像」[rhp]

[:kazutika:][p_kz_31][kazu kao=1 ]
「对吧？谁让你上次把我的作品贬得一文不值，[rhr]
_　我一气之下就和矢部练习了好久」[rhp]

[off_all]

[::]
和近虽然是个嘴硬的家伙，[rhr]
但似乎很喜欢漫画和动画，我们经常聊这些聊得很嗨。[rhp]
有时候也会互相借阅彼此的收藏，[rhr]
最初那种尖酸刻薄的感觉几乎消失不见了。[rhp]

;****************************************
;エントランス
[bg storage="hsps_02e.jpg" time=1500]
;****************************************

;------------------------------------------------------------------------------------------
;▼フルボイススタート▼
[vostart]
;------------------------------------------------------------------------------------------

[chara_part name="otiai" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=13 as=off ss=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:himeko:]
「唉～宙君你们来的日子总是过得特别快呢」[rhp]
[:himeko:]
「下周也一定要来哦？约好了！」[rhp]

[:sora:][otiai kao=5 ]
「知道啦。[player2]真是任性呢你」[rhp]

[:himeko:][hime2 kao=2 ]
「只要宙君肯来，任性就任性呗」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:sora:][otiai kao=6 as=on hh=on ]
「………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------


[off_all]

[:tiaki:][tiaki kao=13 ]
「害羞啦♡」[rhp]

[off_all]

[:sora:][otiai kao=2 ]
「喂！别偷懒快去干活！」[rhp]

[::]
……每次离开时，她必定会来送行[player2]。[rhp]
她的病情也绝不轻松。[rhr]
明明那么难受，会不会是在硬撑呢。[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:sora:][otiai kao=0 ]
「…………、[player2]」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[:himeko:][hime2 kao=1 ]
「嗯？」[rhp]

[off_all]

[:sora:][otiai kao=7 ]
「……不，没事」[rhp]

[off_all]

[::]
要是表现出担心，这家伙绝对会勉强自己。[rhr]
那样一来我就不得不说『乖乖在房间里睡觉』。[rhp]
……抗拒这种走向的我，果然还是个小孩子。[rhp]
到了下周，我们还能这样见面。[rhr]
[player2]考虑到你的身体状况，明明绝对是那样更好的。[rhp]

―――正因如此，我做这个梦是再自然不过的事。[rhp]

[:sora:]
[font color=0x4682b4]
（……我来治好他们）[rhp]
[resetfont]

[::]
总有一天一定要成为医生，[player2]把薰和和近都治好给你们看。[rhp]
那样就能和和近一起去书店，[rhr]
在谁家留宿通宵打游戏也会很开心吧。[rhp]
[player2]至于理央，为了报复至今被他折腾够呛的事，[rhr]
这次换我带他去外面各种地方转转。[rhp]
什么都行，去哪里都好。[rhr]
当了医生收入也会变好，这些全都能实现吧。[rhp]
交给我。你们就等着瞧好吧。[rhr]
我会走在前头，牵着你们的手往前走的。[rhp]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
[set_b storage="black.jpg"]
;****************************************

……可是，现实并没有那么顺利。[rhp]

薰死后不到一年，和近也死了。[rhr]
听说感冒引发肺炎之后，病情就急转直下了。[rhp]

我和理央都哭了，但最严重的是[player2]薰的情况。[rhr]
每次来每次都在哭，完全无计可施。[rhp]
……虽然我下决心要治好他们……[rhp]

[:sora:]
[font color=0x4682b4]
（…………和近也是没办法的事。毕竟事发突然）[rhp]
[resetfont]

[::]
要成为医生需要很多年。[rhr]
听矢部医生说完后，觉得简直遥不可及。[rhp]
我还只是个初中生。[rhr]
赶不上也是没办法的事……[rhp]
……和近。你会原谅我的吧……？[rhp]

[:sora:]
[font color=0x4682b4]
（…………对不起）[rhp]
[resetfont]

;****************************************
[set_b storage="sky_03.jpg"]
;****************************************

和近死后，第一个春天。[rhp]
我上了公立高中，理央则进了私立初中。[rhp]
……[player2]是特别什么都没变。[rhp]
就是从那时开始的。[rhr]
我们的相聚逐渐变少的。[rhp]

;****************************************
[bg storage="hsps_13.jpg" time=1000]
;****************************************

和我家相反，理央家里似乎非常重视教育，[rhr]
刚上初中就开始去补习班准备高中考试。[rhp]
因此，去临终关怀院的次数明显减少了。[rhp]
理央苦笑着说因为父母要求所以没办法，[rhr]
但我似乎能明白理央真正的想法。[rhp]
大概，[player2]是不想见面吧。[rhr]
……因为理央至今还无法释怀和近的死。[rhp]
想起和近的事感到痛苦啊，[rhr]
悲伤[player2]因为心理阴影而觉得尴尬之类的也有吧。[rhp]
但不是这样的。[rhr]
那可能也是原因之一，但不仅如此。[rhp]
那家伙大概是把和近[player2]给重叠在一起了。[rhr]
他担心总有一天[player2]也会变成那样，这让他感到恐惧。[rhp]
相比和近能说更多话，能走出房间活动的[rhr]
共同游玩的时间也更长[player2]的死亡才令他愈发畏惧。[rhp]
光是和近的死就让他那么悲伤，[rhr]
[player2]轮到自己时，真不知道内心会变成什么样。[rhp]
…………我完全理解这种心情。[rhp]

;****************************************
[bg storage="home_02.jpg" time=1000]
;****************************************

为了不输给理央，我拼了命地学习。[rhp]
[player2]当然也是为了能拯救理央的心。[rhr]
无论如何我都必须成为医生。[rhp]

虽然难为情，但当我向父母坦白梦想时，他们高兴得落泪。[rhp]
他们说要以医生身份连同薰与和近的份，[rhr]
拯救更多人才行，说着拍了拍我的后背。[rhp]

;****************************************
[bg storage="hsps_01.jpg" time=1000]
;****************************************

为报考医科大学，自觉实力不足的我决定去补习班。[rhr]
但和理央一样，去临终关怀院的机会因此锐减。[rhp]
高二时每周2次的探望变成每月1次，[rhr]
高三整年就只有七夕会和生日时才去得成了。[rhp]
[player2]他们嘴上抱怨，却仍笑着支持我的梦想。[rhr]
每当看到那笑容，所有的辛苦疲惫都会转化为动力。[rhp]

选择的道路本就漫长而险峻。[rhr]
不能懈怠努力，更不能浪费时间。[rhp]
因为我绝对必须成为医生。[rhp]

;****************************************
[set_b storage="black.jpg"]
;****************************************

2018年　3月[rhp]
那天，命运的通知送达了。[rhp]

;****************************************
[bg storage="home_01.jpg" time=1000]
;****************************************

[:sora:]
「………………」[rhp]

[off_all]

[::]
――――太好了。[rhp]

[:sora:]
「…………唔、合格……」[rhp]

[:soramama:]
「恭喜你宙！努力真的得到了回报呢……！」[rhp]

[:sora:][p_so_04]
「啊！妈妈！车！」[rhp]
[:sora:]
「快开出来！去银河站！」[rhp]

[:soramama:]
「嗯是啊！得赶紧告诉最该知道这个消息的人呢」[rhp]

[::]
努力没有白费，我顺利应届考上了第一志愿的医科大学。[rhp]
[player2]正是设有临终关怀院主楼的大学附属医院。[rhr]
甚至比高一时更能经常去看他。[rhp]
毕竟儿童临终关怀医院只收治到18岁，[rhr]
那家伙今后肯定会转移到主楼。[rhp]

;****************************************
[bg storage="sky_06.jpg" time=1500]
;****************************************

怎么办。脸上的傻笑根本停不下来。[rhp]
见面该说什么？说『好久不见』会不会太生疏？[rhr]
不不，总之得先给他看合格通知书。[rhp]

[:sora:]
[font color=0x4682b4]
（……这样一来……！）[rhp]
[resetfont]

[::]
这样总算才迈出了一小步。[rhr]
但这是不容小觑的一大步。[rhp]
梦想实现的日子近在眼前。[rhp]

;****************************************
[fbgm]
[bg storage="black.jpg" time=2000]
;****************************************

…………明明应该就在那里的。[rhp]

;****************************************
[bg storage="hsps_07e.jpg" time=2000]
[bgm storage="bgm_15.ogg"]
;****************************************

――――冰冷的空气。[rhp]
大美贺小姐用寂寞的笑容迎接我的事。[rhp]
矢部老师什么都没说的事。[rhp]
那一天终将到来。它必定正在临近的事。[rhr]
一直都隐约预感着。[rhp]
…………但是，我不想承认。[rhp]

;****************************************
[still storage="cg/c_6.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/c_6.png"]
;****************************************


得意忘形又怎样。[rhr]
像我这样一无是处的人，竟能实现这样的奇迹。[rhp]
这种事，根本不可能想象得到。[rhp]

……薰。[rhp]
八云君。和近。[rhp]
…………[player2]。[rhp]
在没有想要拯救之人的世界里，当医生又有什么意义？[rhp]
这个梦想还有继续的价值吗？[rhp]
忍耐至此，却依然如此遥远。[rhr]
理想也好，银河铁道也罢，全部都是。[rhp]

头晕目眩。[rhp]
………………已经，累了。[rhp]

;****************************************
[s_mask color=0x000000 time=3000]
; 背景表示
[bg storage="hsps_09n.jpg" time=100]
; 夜フィルター
[filter layer="1" brightness="60"]
; ウィンドゥの設定
[position layer="message0" frame="win2.png" left=0 top=520 width=1280 height=200 page=fore visible=true ]
[s_mask_off time=3000]
;****************************************

…………母亲早就回去了。[rhp]
至于我，从那时起已在这家临终关怀院停留了半日有余。[rhp]
幸好矢部老师他们都是通情达理的人。[rhr]
……大概今天已经，无法从这里挪动半步了。[rhp]

;****************************************
[bg storage="sky_07.jpg" time=1000]
;****************************************

明明该深刻领悟到厌恶的程度，还真是可笑。[rhp]
这里就是『那种』地方。[rhr]
薰也好，八云君也好，和近也好，都没有等我。[rhp]
对于被留下的人来说，时间之类的东西是不会被给予的。[rhp]
早知道这样，不学习多来玩玩就好了。[rhp]
最后她说了什么呢。[rhr]
是什么样的表情呢。[rhp]
会觉得我薄情吗。[rhp]
…………现在只剩下后悔了。[rhp]

;****************************************
[bg storage="hsps_02m.jpg" time=2000]
;****************************************

走出101号室，摇摇晃晃地来到了大厅。[rhp]
……我想起来了。那幅画的轶事。[rhr]
那些家伙……[player2]还宁愿相信他们……仍然存在于这个世界。[rhp]
………虽然很荒谬，但现在我只想抓住些什么。 
;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
;ここからソラが五十嵐さんverになります。
[voconfig sebuf=1 name=sora vostorage="sora/full/{number}.ogg" number=1]
;名前判明までヨルはunknownです。
[voconfig sebuf=1 name=unknown vostorage="yoru/full/{number}.ogg" number=186]
[vostart]
;--------------------------------------------------------------------------------------------

[:unknown:]
「不回去吗」[rhp]

[:sora:]
「……矢、矢部前辈，」[rhp]

[:unknown:]
「不对」[rhp]

[::]
这句否定的话语，终于让我感到了违和。[rhr]
我反射性地回头望去。[rhp]

[:sora:][sora body=prain kao=4 as=on ]
「――――！？」[rhp]

[off_all]

[yoru kao=0 ]

[::]
看到转身后站在那里的人影，我瞪大了眼睛。[rhp]
那里站着一个从未见过的男人。[rhr]
而且那个男人若无其事地搭话了。[rhp]

[off_all]

[:sora:][sora body=prain kao=2 as=on ]
「啊……」[rhp]

;------------------------------------------------------------------------------------------
;ここからヨルの記述がunknownからyoruになります
[voconfig sebuf=1 name=yoru vostorage="yoru/full/{number}.ogg" number=188]
[vostart]
;------------------------------------------------------------------------------------------

[:yoru:][yoru kao=12 ]
「别吵。就这点小事」[rhp]
[:yoru:]
「……我叫糠星夜」[rhp]

[off_all]

[::]
这个名字似曾相识。[rhr]
我猛然一惊，抬头望向眼前那幅巨大的绘画。[rhp]

[:sora:][sora body=prain kao=4 ]
「糠星就是，这幅画的……」[rhp]

[off_all]

[:yoru:][yoru kao=7 ]
「我是寄宿在这幅画里的灵体存在」[rhp]

[off_all]

[::]
虽然难以置信，但内心深处又有某种释然的感觉。[rhr]
在纯白的脑海角落，忽然想起[player2]曾经说过的话。[rhp]
确实那家伙也说过。[rhr]
……这个地方存在着『神明大人』。[rhp]

[chara_part name="sora" body=prain kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sora:][sora body=prain kao=0 ]
「…………神明大人。真的存在吗」[rhp]

[:yoru:][yoru kao=2 ]
「……虽然你说的那个可能并不是指我」[rhp]
[:yoru:]
「不过从广义上说算是同类。你这么认为也无妨」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:sora:][sora body=prain kao=3 ]
「………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:yoru:][yoru kao=6 ]
「什么啊」[rhp]

[:sora:][sora body=prain kao=3 ]
「我会死吗」[rhp]

[:yoru:][yoru kao=2 ]
「……？你在说什么？」[rhp]

[:sora:]
「我很清楚。[rhr]
_　……[player2]听到的、八云君所说的那个神明大人的真面目」[rhp]
[:sora:]
「……是死神」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:yoru:][p_y_10][yoru kao=6 as=on ]
「哈啊？」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sora:][sora body=prain kao=2 ]
「待在这种地方的神明，不是死神还能是什么……」[rhp]
[:sora:]
「如果是普通的神明，根本不会谈论死后的事。[rhr]
_　应该会创造奇迹，拯救大家才对」[rhp]
[:sora:]
「但那怎么可能。根本不会有什么奇迹。[rhr]
_　所以世上才会有医生，只能用现实的方法勉强应付」[rhp]
[:sora:]
「……为了让人们不必依赖神明，我本该成为那样的存在」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:yoru:][yoru kao=3 ]
「………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sora:][sora body=prain kao=3 ]
「不过抱歉。明天开始可以吗」[rhp]

[:yoru:][yoru kao=6 ]
「啊……？」[rhp]

[:sora:]
「不想在这里添麻烦，所以选个远点的树林吧」[rhp]

[:yoru:][yoru kao=2 as=on ]
「……你该不会，是想找死吧」[rhp]

[:sora:][sora body=prain kao=13 ]
「对。不知怎么的，就觉得一切都无所谓了」[rhp]
[:sora:]
「说实话累了。毕竟都三年了？[rhr]
_　为了今天的报告，你知道我有多拼命吗」[rhp]
[:sora:]
「所有的忍耐，从未换来好结果。……真是受够了」[rhp]
[:sora:][sora body=prain kao=3 ]
「……带我走吧。银河铁道也好，哪儿都行」[rhp]

[:yoru:][yoru kao=12 ]
「…………虽然我并非死神」[rhp]
[:yoru:][yoru kao=0 ]
「这个愿望，倒也不是不能实现」[rhp]

[:sora:][sora body=prain kao=0 ]
「……哈……？」[rhp]

[off_all]

[::]
没想到会听到肯定的答复。[rhr]
明明只是预设会被拒绝的牢骚……[rhp]

[:yoru:][yoru kao=6 ]
「不过我也有条件」[rhp]

[::]
糠星夜用冰冷的眼神盯着无法掩饰困惑的我。[rhp]
看起来不像在开玩笑。[rhr]
至少不像会在这种场合说这种话的性格。[rhp]

[off_all]

…………不知道该不该相信这个可疑分子的话。[rhp]
即便如此，哪怕只有一丁点可能性——[rhp]

[:sora:]
「…………说来听听」[rhp]

;****************************************
[fbgm]
[set_b  storage="cg/b2_1n.png"]
[bgm storage="bgm_13.ogg"]
;****************************************

[:sora:]
「―――这幅画里，有那些家伙」[rhp]

[:yoru:]
「没错。由于某个蠢货的缘故，[rhr]
_　至今仍有许多灵魂被困在这里」[rhp]
[:yoru:]
「作为带你来此的交换条件，[rhr]
_　希望你能让他们从那辆铁道下车」[rhp]

[::]
突然听到如此荒诞无稽的事情，一时语塞。[rhp]
又是付丧神又是魔法的……[rhr]
画中存在另一个世界？这可不是童话故事。[rhp]
…………但现在，超越人类认知的现象正在眼前发生。[rhp]

;****************************************
[bg storage="hsps_02m.jpg"]
;****************************************

[chara_part name="sora" body=prain kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:yoru:]
「武和千秋赞同了我的提议」[rhp]

[:sora:]
「！老师他们也？」[rhp]

[:yoru:]
「他们开始这项活动大约是一年半前。[rhr]
_　而这个提案最早要追溯到两年半前」[rhp]
[:yoru:]
「多亏两人的努力，铁道上几乎看不到孩子们的身影了。[rhr]
_　他们已从那条铁道出发，前往本该属于自己的世界。我们称之为『下车』」[rhp]
[:yoru:][yoru kao=2 ]
「为了让他们的灵魂能在这个世界重获新生，[rhr]
_　他们必须完成下车」[rhp]
[:yoru:]
「……那里存在的不过是虚假的幸福。[rhr]
_　真正的幸福，不该在梦中轻易获得」[rhp]
[:yoru:][yoru kao=3 ]
「只要想象醒来时的绝望，任谁都懂这个道理」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------
[:sora:]
「………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:yoru:][yoru kao=3 ]
「但作为解放他们的功臣，矢部老师暂时……不恐怕再也无法回到那个世界了。[rhr]
_　由于未能挽救其中一人，他心灵受到了严重创伤」[player2]因未能拯救，心灵遭受了严重创伤」[rhp]
[:yoru:]
「原因是南。就是在这个医院里，八云博士见过的那个『神明』」[rhp]

[:sora:][sora body=prain kao=2 ]
「……！　是那家伙[player2]带走的吗」[rhp]

[:yoru:][yoru kao=2 ]
「没错。……用这次最无情的手段」[rhp]

[:sora:]
「无情……？」[rhp]

[:yoru:]
「我早就知道仅靠武他们负担太重了。[rhr]
_　所以在这所临终关怀院观察了许多人，寻找能理解我愿望的对象」[rhp]
[:yoru:]
「在知晓你全部苦恼后……能托付的只有你了」[rhp]

[:sora:][sora body=prain kao=3 ]
「…………薰呢？」[rhp]

[:yoru:]
「当然，也曾在这里」[rhp]

[:sora:]
「他有提到过我吗？」[rhp]

[:yoru:][yoru kao=3 ]
「啊。被武说服下车的时候」[rhp]
[:yoru:]
「说银河铁道很有趣……但下次还想作为兄长的弟弟转世」[rhp]

[:sora:][sora body=prain kao=8 as=on ]
「…………呜……」[rhp]

[:yoru:]
「人生百味俱全。虽不鼓吹吃苦……」[rhp]
[:yoru:]
「……只希望你能活下去。这是我唯一的执念。[rhr]
_　所以我想终结他们的旅程」[rhp]
[:yoru:][yoru kao=2 ]
「……宙。愿意接受吗」[rhp]

[:sora:][sora body=prain kao=3 ]
「明白了」[rhp]

[:yoru:][yoru kao=0 ]
「！……答应得真干脆啊」[rhp]

[:sora:]
「已经厌倦了。得不到回报的努力受够了。[rhr]
_　如果你的方法可靠，我就跟从」[rhp]

[:yoru:][yoru kao=3 ]
「…………这样啊」[rhp]

[off_all]

[:yoru:]
「―――……谈判成立」[rhp]

[::]
简短回答后，夜向这边伸出手来。[rhr]
应该是要握手吧。[rhp]
……反正也没有其他可做的事，或是希望了。[rhp]
我无力地握住那只伸过来的冰凉手掌。[rhp]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
[fbgm]
[se storage="mag_06.ogg"]

[s_mask color=0x000000 time=2000]
; 背景表示
[bg storage="sky_13.jpg" time=100]
; ウィンドゥの設定
[position layer="message0" frame="win.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[s_mask_off time=2000]

[bgm storage="bgm_15.ogg"]
;****************************************

[:sora:][p_ot_30]
「――――！？」[rhp]

[::]
在握手的瞬间。只觉得周围突然闪过一道强光，[rhr]
回过神来时，我已漂浮在银河正中央。[rhp]
眼前的景象令人难以置信，我环顾四周。[rhp]
在没有立足点的地方站立着，这种怪异感觉还未消散，[rhr]
自己的身体也传来强烈的不协调感。[rhp]
…………可视范围内的身体部位，看起来异常年幼。[rhp]

[:sora:][otiai kao=2 ]
[font color=0x4682b4]
（难、难道身体变回小时候的我了……！？为什么）[rhp]
[resetfont]

[off_all]

[:yoru:][yoru kao=12 ]
「这个世界会实现其人的憧憬」[rhp]
[:yoru:]
「你的愿望，似乎是回到幼年时期呢」[rhp]

[off_all]

[::]
幼年时期……所以身体才变回小鬼时期么。[rhp]
总觉得怪怪的。方才还与我平视的糠星夜，[rhr]
现在已高大到需要仰视了。[rhp]

[:yoru:][yoru kao=5 ]
「现在的你，处于仅有精神被抽离的状态。[rhr]
_　生物乃是灵魂、精神、肉体的――――」[rhp]

[:sora:][otiai kao=4 ]
「等、等一下！」[rhp]
[:sora:]
「虽然说了要接受，但该怎么和妈妈解释？[rhr]
_　必须说明我即将消失这件事―――」[rhp]

[:yoru:][yoru kao=0 ]
「听我解释完」[rhp]
[:yoru:][yoru kao=5 ]
「在梦境世界中可以任意扰乱与那边世界的时间感知。[rhr]
_　两个晚上就足够了。会将其调整为现实世界大约3周左右的时间」[rhp]
[:yoru:]
「你会因神经衰弱和星名[player2]的死亡打击陷入昏迷状态。[rhr]
_　安排武发现这个情况，并让你母亲进行刚才报告的情节」[rhp]
[:yoru:]
「这是在不受南干涉的情况下，以我尚不完善的力量将你的精神[rhr]
_　留在这里的极限。同时虽然有些粗糙，但也是最自然的借口」[rhp]

[:sora:][otiai kao=3 ]
「如果遇到南的干涉呢？」[rhp]

[:yoru:][yoru kao=0 ]
「我就无法带你回去了」[rhp]

[:sora:][otiai kao=7 as=on ]
「要在这个世界……永远待下去吗？仅此而已？」[rhp]

[:yoru:][p_y_34][yoru kao=8 ]
「仅此而已，但唯独这点我想避免。因为你还活着」[rhp]

[:sora:][otiai kao=0 ]
「………………」[rhp]

[:yoru:][p_y_04][yoru kao=6 ]
「…………你这家伙，别想蠢事。[rhr]
_　南的所作所为，是对人类生命……灵魂不可饶恕的亵渎」[rhp]
[:yoru:]
「你的任务是说服留在这里的人们。[rhr]
_　可不是在邀请他们观光啊」[rhp]

[:sora:][otiai kao=13 ]
「我知道」[rhp]

[:yoru:][yoru kao=2 ]
「………………」[rhp]

[:sora:][otiai kao=1 ]
「别用那种眼神看我。我算是所谓的你的同伴啊」[rhp]

[off_all]

[:sora:]
「……没问题。我会好好完成的」[rhp]

;****************************************

#
[free_filter ]
[set_b storage="train_01.jpg" time=100]
;****************************************

[::]
电车内部正是八云君告诉我的那辆「银河铁道」。[rhp]
复古的内装，却配有华丽的装饰。[rhr]
窗外是辽阔的星之海。[rhp]

;****************************************
#
[bg storage="train_13.jpg" time=1000]
;****************************************

[:sora:]
[font color=0x4682b4]
（…………啊）[rhp]
[resetfont]

[off_all]

[::]
那是天鹅座吗。……没想到能看得这么近。[rhr]
薰是不是也曾经看过这样的景色呢。[rhp]
[player2]而和近……现在也在这里，看着这片风景……。[rhp]

[:sora:]
[font color=0x4682b4]
（……现在可不是做这种事的时候）[rhp]
[resetfont]

[off_all]

[::]
得先找到那群家伙。[rhr]
虽然也打算履行和夜的约定，但至少要先见一面……[rhp]

;****************************************
#
[bg storage="train_01.jpg" time=1000]
;****************************************

[:unknown:]
「诶……」[rhp]

[::]
正当我出神地望着窗外时，身后传来了声音。[rhr]
本以为四下无人，吓得心脏差点跳出来。[rhp]
回头望去，站在那里的――――[rhp]

[:kazutika:][kite kao=4 as=on ]
「…………是宙吗？」[rhp]

[off_all]

[::]
虽然样貌不同，但我立刻认出来了。[rhr]
这人绝对就是和近。[rhp]

[:sora:]
[font color=0x4682b4]
（……梦……？）[rhp]
[resetfont]

[::]
不知道。[rhr]
被逼到这种地方后，现实与虚幻的界限已经模糊了。[rhp]
我想要这不是梦的证据。因为已经不想再空欢喜一场了。[rhp]

[:sora:]
「……！」[rhp]

[::]
突然注意到男人身旁的大型手推车。[rhr]
上面堆满了点心和各式各样的东西。[rhp]
我像冲刺般朝那里跑去。[rhr]
然后推开男人，猛地掀翻了手推车。[rhp]

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
;参加キャラはev_a_04と同じですが、ソラ視点に変わっているので
;モノローグを差し込む代わりに前回に出てきた台詞などを省略している部分があります。
[voconfig sebuf=1 name=kazu vostorage="kite/full/{number}.ogg" number=85]
[vostart]
;--------------------------------------------------------------------------------------------
[yurasu]

[:kazutika:]
[font size=30]
「啊―――――！？」[rhp]
[resetfont]

[off_all]

[::]
真是吵死了。[rhr]
这家伙也是，手推车轰然倒塌的声音也是。[rhp]
我更是从散落物中胡乱抓起一个袋子使劲撕开。[rhr]
毫不犹豫地吃了一口。[rhp]
有味道。我在梦里，明明从未感受过味觉。[rhp]
又打开其他袋子。继续吃。[rhr]
打开。吃。[rhp]
…………确实好吃。[rhp]

[se storage="door_09.ogg"]


;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:unknown:][puri body=prain kao=2 as=on hat=okan ]
「快斗！你怎么……」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_puri2]

[:kazutika:][kite kao=2 as=on ]
「别开玩笑了你这家伙！　真是的～～～～……！[rhr]
_　从刚才开始你到底想干什么！」[rhp]

[off_all]


;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:unknown:][puri body=prain kao=4 as=on hat=okan ]
「呃…………谁、谁！？」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[:kazutika:][kite kao=2 as=on ]
「能不能给我适可而止！[rhr]
_　就算这样也是谋生工具啊！？虽然从来没靠它赚过钱！！」[rhp]

[off_all]

[::]
无视快斗的话语，我忘我地疯狂拆着点心包装袋。[rhp]
每一个都确实能尝到味道。[rhr]
廉价却莫名令人怀念的味道。[rhp]

[:kazutika:][kite kao=2 as=on ]
「喂……快住手！别拆了！[rhr]
_　就算要拆也等吃完手里的再开下一个啊！」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:sora:]
[font color=0x4682b4]
（究竟是什么……总觉得这个在哪里吃过……）[rhp]
[:sora:]
（…………啊）[rhp]
[resetfont]

[::]
说起来这个……印象中以前和大家一起吃过。[rhp]
生日会、圣诞节、万圣节派对。[rhr]
是在那种活动上出现的东西。[rhp]
是到处都有卖的普通点心。[rhr]
对于身体虚弱的他们而言，这曾是特别的时刻。[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:kazutika:][kite kao=6 as=on ]
「～～～！　宙！！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[::]
被呼喊名字后，终于回过神来。[rhp]

[off_all]

[chara_part name="jet" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

突然环顾四周，发现除了和近之外的人都已聚集在此。[rhp]
…………这些人是谁？完全没有印象的面孔。[rhr]
或许是在我无法来临终关怀院期间入住的群体吧。[rhp]
听夜说过，八云君之后的入住者[rhr]
都会被无条件传送到这个世界。[rhp]

[off_all]

[::]
不过这些都无所谓了。[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:unknown:][puri body=prain kao=4 as=on hat=okan ]
「宙……？」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[::]
……重点在于眼前。[rhp]
只需一眼就明白了。……不可能不明白。[rhp]

[:sora:]
[font color=0x4682b4]
（……[player2]）[rhp]
[resetfont]

[::]
你真的，就在这里啊。[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:kazutika:][kite kao=2 as=on ]
「为什么你会在这里！？」[rhp]
[:kazutika:]
「完全搞不懂……！那些谜之操作也好，这身打扮也好……！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[off_all]

[:sora:]
[font color=0x4682b4]
（……一点都没变呢）[rhp]
[resetfont]

[::]
似乎不需逐一确认了。[rhp]
那个表面装酷实则渴望关注的家伙，[rhr]
被这般无视的话肯定会发飙吧。[rhp]
……此刻在这里的他们，[rhr]
确实就是曾在那个地方的人们以另一种姿态存在着。[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[voconfig sebuf=1 name=sora vostorage="otiai/full/{number}.ogg" number=1]
[vostart]
;------------------------------------------------------------------------------------------

[:sora:][otiai kao=2 ]
「…………呼――……」[rhp]

[off_all]

[::]
把点心弄得一片狼藉后，我终于站了起来。[rhp]
与他们重逢的喜悦几乎要满溢而出，[rhr]
首先有件事我必须事先说明。[rhp]

;****************************************
[bg storage="sky_11.jpg" time=1500]
;****************************************

我冲到车窗旁，将车门完全推开并探出身去。[rhp]
夜。你正在某个地方听着吧？[rhp]
怀疑你是我的不对。[rhp]

[:sora:]
[font size=28]
「不是梦――――――啊啊！！」[rhp]
[resetfont]

[::]
画中世界的银河铁道真实存在着。[rhr]
和近也，[player2]也，确实存在过。[rhp]

[:sora:]
[font size=28]
「我……！　我会努力的――――！！」[rhp]
[:sora:]
「谢谢你们――――！！」[rhp]
[resetfont]

;****************************************
#
[bg storage="train_01.jpg" time=1500]
;****************************************

[chara_part name="jet" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:jet:][s_playse storage="jet/40d.ogg" buf=2]
「那家伙怎么回事？　简直疯了吧……」[rhp]

[:heartshape:][s_playse storage="hati/51c.ogg" buf=1]
「超他妈酷的小鬼啊……！！」[rhp]

[off_all]

[:sora:][otiai kao=3 as=on]
「…………！银河铁道……真的……真的存在啊……」[rhp]

[off_all]

[:himeko:]
「那、那个！」[rhp]

[:sora:][otiai kao=0 ]
「！」[rhp]

[off_all]

[:himeko:][puri body=prain kao=2 as=on hat=okan ]
「那样探出身太危险了！快回这边来」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[::]
不知何时已站在身后的[player2]，[rhr]
望着探出车窗的我，面带担忧地开口说道。[rhp]
明明不该紧张才对，身体却不自觉地绷紧了。[rhp]
这也难怪……毕竟和现实世界不同，他看上去很健康，[rhr]
最让我震惊的是竟变成了金发。除开五官几乎判若两人。[rhp]
仔细想想和近也好，后面那群古怪家伙也罢，着装都莫名其妙……[rhp]

[off_all]

[chara_part name="otiai" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="puri" body=base kao=1 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:himeko:]
「那个……我、我叫公主。你呢？」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sora:][otiai kao=2 as=on ]
「……！啊……？」[rhp]

[off_all]

[::]
你居然……不记得我了吗？[rhr]
和你不同，你应该更熟悉我这副模样才对。[rhp]
而且刚才，你还准确地叫我宙君……[rhp]

[:kazutika:][kite kao=2 as=on ]
「切……」[rhp]

[:himeko:][puri body=prain kao=2 as=on hat=okan ]
「喂、喂快斗！别用那种眼神看人！」[rhp]

[:kazutika:]
「会露出这种眼神也是理所当然吧。为什么那家伙会在这里……」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:sora:]
[font color=0x4682b4]
（原来如此……和近和[player2]在这个世界关系也很要好啊[rhr]
_　刚才说出我名字，只是重复了和近的话……）[rhp]
[:sora:]
（……怎么回事？和近明明也死在了同一场事故中。[rhr]
_　难道是能带到这边的信息量存在个体差异……？）[rhp]
[resetfont]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[chara_part name="puri" body=prain kao=1 as=off ss=off hh=off hr=on hat=okan]
[chara_show name="puri" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:himeko:]
「话说你们俩认识……对吧？」[rhp]

[:kazutika:][kite kao=2 ]
「不对。我才不认识这种家伙。[rhr]
_　如果你是真的宙，那这幅模样根本不可能存在」[rhp]
[:kazutika:]
「那家伙是宙的冒牌货」[rhp]

[off_puri2]

[chara_part name="otiai" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="true" time=150]

[:sora:]
「……冒牌货？我？」[rhp]

[:kazutika:]
「肯定是南干的好事吧？那家伙绝对做得出来。[rhr]
_　说什么为了我们，净是多管闲事」[rhp]

[off_all]

[::]
这番完全搞错状况的发言让人彻底无语。[rhr]
外表虽是大人，内里却还是个小鬼啊。[rhp]

不过或许有点开心。[rhp]
和近以为我已经死了吗。[rhr]
而且，还试图否定这个事实吗。[rhp]
……总觉得有点难为情啊。[rhr]
即便模样改变，我们果然还是朋友呢。[rhp]
但是。[rhp]

[:sora:][otiai kao=2 ]
「―――……不管谁说什么，我都是真正的落合宙」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
;カイト一時停止
[voconfig sebuf=1 name=kite vostorage="kite/full/{number}.ogg" number=0]
[vostop]
;------------------------------------------------------------------------------------------

[off_all]

[chara_part name="jet" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:]
「落合宙？杰特你认识吗」[rhp]

[:jet:][p_j_17]
「不，从没听说过……」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]
[chara_part name="jet" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="otiai" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="760" top="0" wait="true" time=150]

[:sora:]
「……所以？你们俩又是谁？」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:heartshape:][p_h_35][hati kao=5 as=on ]
「！！我、我是哈托谢普！」[rhp]

[:jet:][p_j_35][jet kao=12 ]
「……，我是杰特」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sora:][otiai kao=12 ]
「白发的是哈托谢普，红发的是杰特呢。[rhr]
_　明白了，请多指教」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:heartshape:][p_h_02][hati kao=14 ]
「噢！请多指教！」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sora:][otiai kao=8 as=on ]
「真是活力过头了……不过倒也无所谓」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[off_all]

[::]
这种状态居然是前病人吗。反而有点想见见了。[rhr]
……不过，或许只是来到这个世界太兴奋而已。[rhp]

[chara_part name="otiai" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="puri" body=prain kao=1 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:himeko:]
「那个……请问！落合君是今天来这里的吗？[rhr]
_　完全没注意到你也上车了」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:sora:][otiai kao=3 ]
「………………」[rhp]

[off_all]

[::]
……『落合君』、吗。[rhr]
倒也无所谓……罢了。[rhp]

[chara_part name="otiai" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="puri" body=prain kao=3 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:himeko:]
「既然来到这里……说明你已经死了吧」[rhp]
[:himeko:][puri body=prain kao=1 hat=okan ]
「死亡虽然令人悲伤，但在这里就不用担心了。[rhr]
_　因为这里可是梦境与魔法的银河铁道啊！」[rhp]

[off_otiai]

[chara_part name="kite" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="168" top="0" wait="true" time=150]

[:kazutika:][p_k_05][kite kao=2 ]
「究竟要捅多大娄子才会来到这种地方。[rhr]
_　震惊到都说不出话来」[rhp]

[:himeko:][puri body=prain kao=2 as=on hat=okan ]
「快、快斗你怎么这样说！太失礼了！」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sora:][otiai kao=7 ]
「无所谓啦。和，」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:kazutika:][p_k_04][kite kao=2 ]
「是快斗。别叫错了」[rhp]

[:sora:][otiai kao=4 as=on ]
「…………！」[rhp]

[off_all]

[::]
想起来了……听说他在这里用的是另一个名字。[rhr]
不小心用了习惯的称呼……还是入乡随俗比较明智。[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[chara_part name="kite" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="otiai" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sora:]
「……也不是不能理解『快斗』的困惑」[rhp]
[:sora:]
「不过既然来了也没办法吧。[rhr]
_　暂时要受你照顾了。请多指教」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:kite:]
「………………切」[rhp]


[off_all]

[::]
多洛普和快斗、哈托谢普这些名字……莫非源自宝石切割方式？[rhr]
或许因为身处银河的缘故，我脑海里浮现出『宝石箱』的画面。[rhp]
八云君的书多以宇宙为主题。[rhr]
我也常向他借阅，其中某本书曾这样记载：[rhp]
南十字座的疏散星团被称为『珠宝盒（Jewel Box）』。[rhp]
南十字座……千星十字。[rhr]
虽不知那家伙名字的由来，但未必全无关联。[rhp]
难道这里是那家伙的收藏室不成？[rhr]
…………一点都不好笑。[rhp]

[:drop:][p_d_21][drop kao=2 as=on ]
「快斗先生！刚才的大喊是怎么回事？发生紧急状况了吗―――」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sora:][otiai kao=4 as=on ]
「……！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:drop:][p_d_19][drop kao=4 as=on ]
「诶……你是」[rhp]

[:sora:][otiai kao=2 as=on ]
[font color=0x4682b4]
（…………终于要见面了吗）[rhp]
[resetfont]

[off_all]

[drop kao=2 as=on ]

[::]
南以我为原型创造的另一个我。[rhp]
……多洛普。这家伙……[rhp]

[off_all]

;****************************************
#
[bg storage="train_12.jpg" time=1000]
;****************************************

[::]
单靠临终关怀院的人手无法维持运营，[rhr]
据说这里存在着掌管铁道的人偶。[rhp]
它们是以临终关怀院的孩子们为原型形成的，[rhr]
当孩子们死后抵达此处时，对应的人偶会通过替换形式消失。[rhp]
听说其他所有孩子都[rhr]
在矢部老师的劝说下离开了铁道。[rhp]
留在这里的，是南创建银河铁道时，[rhr]
以与八云君特别亲近的当时相关人员为原型制作的。[rhp]
……虽然我不是住院者，但也算其中之一。[rhp]

[:sora:]
[font color=0x4682b4]
（……车长吗。真是崇高的职位啊）[rhp]
[resetfont]

;****************************************
#
[bg storage="train_01.jpg" time=1000]
;****************************************

[::]
由于我并非临终关怀院的住院者，死后本不该来到这个世界。[rhr]
想必他们是觉得能放心让我担任这条铁道的负责人吧。[rhp]
……但我偏离了他们的预期，最终来到了这里。[rhr]
在假死这种不完整的死亡状态下，似乎不会导致人偶消失。[rhp]
因此才会出现我和多洛普这两个『落合宙』[rhr]
同时存在于这个地方的结果吧。[rhp]

[:drop:][drop kao=8 as=on ]
「………………」[rhp]

[::]
这什么表情。嘛当然会惊讶吧。[rhr]
毕竟对方是永远都不可能见到的存在。[rhp]
而且由于我的到来 甚至可能导致其消失。[rhp]

[off_all]

[chara_part name="otiai" body=base kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="drop" body=base kao=4 as=on ss=off hh=off hr=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sora:]
「…………初次见面」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:drop:][drop kao=1 as=on ]
「……！啊、啊啊！初次见面！我是车长多洛普」[rhp]
[:drop:][drop kao=13 as=on ]
「……能与您相会真是荣幸」[rhp]

[off_all]

[chara_part name="puri" body=prain kao=0 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="drop" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:princess:]
「多洛普，难道你认识落合君吗？」[rhp]

[:drop:][p_d_02][drop kao=14 ]
「当然。车长就该掌握乘客的一切情报！[rhr]
_　电影喜好、漫画喜好、音乐喜好，全都了如指掌！」[rhp]

[off_all]

[:sora:][otiai kao=2 ]
[font color=0x4682b4]
（这哪里是知道 根本就是本人吧）[rhp]
[resetfont]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[chara_part name="otiai" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="drop" body=base kao=13 as=on ss=off hh=off hr=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sora:]
「……你，被称作多洛普啊」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:drop:][p_d_02][drop kao=13 ]
「是的！请多关照」[rhp]

[:sora:][otiai kao=2 ]
「……………………」[rhp]

[off_all]

[chara_part name="kite" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="otiai" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:kite:][p_k_04][kite kao=2 ]
「所以？差不多该说实话了吧。[rhr]
_　如果你是真货宙，为什么要来到这里」[rhp]
[:kite:]
「……不，应该说为什么已经死了」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sora:][otiai kao=12 ]
「没死」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:kite:][p_k_10]
「……哈？」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sora:]
「我没死。是活着来到这个世界的」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[off_all]

[:heartshape:][hati kao=2 as=on ]
「呃……！！」[rhp]
[:heartshape:][hati kao=6 as=on ]
「…………这家伙 认真的吗」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sora:][otiai kao=3 ]
「………听说这里有银河铁道，就让人带我过来了」[rhp]
[:sora:]
「■■■的缘、故……」[rhp]
[:sora:][otiai kao=2 as=on ]
「…………啊？」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[off_all]

[::]
话语中途仿佛被噪音吞噬般消失 令人震惊。[rhr]
试图重复同样台词时……又在相同的地方卡住了。[rhp]
名字说不出口。「[player2]」唯独这个，无论如何也。[rhp]


[:sora:]
[font color=0x4682b4]
（切……是南干的吗）[rhp]
[resetfont]

[::]
在听取这个世界说明时，夜曾经提到过。[rhp]
南尤其对[player2]异常执着。[rhr]
不知发生过什么，能感觉到近乎执念的情绪。[rhp]
虽然不明白缘由 但那家伙不仅夺走了本该继承的记忆，[rhr]
连她生前的记忆也全部剥夺了。[rhp]
说不定我身上也被施加了某种限制。[rhr]
因此要想说服她下车，恐怕没那么容易……吧。[rhp]

[:sora:]
[font color=0x4682b4]
（原来是这样……真麻烦）[rhp]
[resetfont]

[::]
凡是会刺激她记忆的发言，哪怕是名字也一律禁止吗。[rhr]
这位赞助人大人可真为所欲为啊。[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sora:]
「…………，倒也无所谓」[rhp]

[:princess:][puri body=prain kao=2 as=on hat=okan ]
「等等落合君。刚才那话什么意思？活着什么的……」[rhp]

[off_all]

[:sora:][otiai kao=2 ]
「字面意思。我现在——」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
;双子追加
[voconfig sebuf=1 name=hati vostorage="hati/full/{number}.ogg" number=52]
[voconfig sebuf=1 name=jet vostorage="jet/full/{number}.ogg" number=41]
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[:heartshape:]
[font size=30]
「滚回去！！」[rhp]
[resetfont]

[::]
………………哈？[rhp]

[chara_part name="otiai" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sora:]
「…………什么啊？你」[rhp]

[:heartshape:]
「滚回落合。这不是你该待的地方」[rhp]

[:sora:][otiai kao=2 ]
「听不懂。虽然不认识你，但这与你无关吧」[rhp]

[:heartshape:]
「有关！你根本不明白！你现在做的——」[rhp]

[off_all]

[:jet:][jet kao=12 ]
「也没什么不好吧」[rhp]

[::]
杰特打断了哈托谢普的话语，反驳道。[rhp]
总觉得空气中弥漫着一触即发的氛围，但暂时还看不出来[rhr]
这个红发青年为何突然对看似亲密的同伴反目相向。[rhp]

[off_all]

由于对他们了解不多，为了能更顺利地共同生活[rhr]
我决定暂时保持沉默，继续观察两人的关系。[rhp]

[off_all]
;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:drop:][drop kao=6 as=on ]
「好啦好啦好啦好啦！」[rhp]

[off_all]

就在紧张气氛逐渐升级之时[rhr]
多洛普终于出面介入两人之间。[rhp]
这家伙是这里的领导人物吧。[rhr]
被多洛普劝导后，那两位看似强势的人都沉默了下来。[rhp]

[chara_part name="otiai" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="drop" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:drop:]
「―――――我觉得。怎么样？落合」[rhp]

[:sora:]
[font color=0x4682b4]
（……奇怪的感觉。被自己搭话是……）[rhp]
[resetfont]

[:drop:][p_d_32][drop kao=5 as=on ]
「哎呀呀……我这是被讨厌了吗」[rhp]

[:sora:][otiai kao=2 as=on ]
「！」[rhp]

[off_all]

[::]
因为过于专注于观察他们，结果忘记了回应。[rhr]
或许是因为自己的身影被无视了，多洛普露出了略带寂寞的苦笑。[rhp]
……如果我也是这种老好人的性格，大概也会这样苦笑吧。[rhr]
感觉有点恶心啊……各方面都是。[rhp]

[:quadrillion:][p_r_18][riri kao=7 ]
「啊——麻烦的家伙又增加了呢」[rhp]

[off_all]

[chara_part name="riri" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="drop" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:drop:]
「夸德里利昂！太慢了。[rhr]
_　都闹成这样了，你跑去哪里做什么了啊」[rhp]

[:quadrillion:][riri kao=13 ]
「化妆～」[rhp]

[off_all]

[:sora:]
[font color=0x4682b4]
（又出现个不认识的人。该怎么说呢，真强烈啊……[rhr]
_　那副身材还是个娘娘腔，再加上白发粉毛配红眼……）[rhp]
[:sora:]
（…………红眼？）[rhp]
[resetfont]

[off_all]

[::]
诶？难道这家伙……[rhp]

[chara_part name="otiai" body=base kao=2 as=on ss=on hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="riri" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:quadrillion:]
「嘛，虽然听到不少传言。不过无所谓吧？[rhr]
_　现阶段我觉得多洛普的提议最合理」[rhp]
[:quadrillion:]
「可别给旁人添太多麻烦。还有要尊敬长辈」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sora:][otiai kao=6 as=on ]
「…………明白了」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------
[:quadrillion:][p_r_19][riri kao=5 ]
「哎呀，没想到是个挺懂事的臭小鬼嘛」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sora:][otiai kao=3 as=on ]
「……没什么。可能我也有点钻牛角尖了」[rhp]
[resetfont]

[off_all]

[chara_part name="otiai" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:sora:]
「抱歉……快斗。话说重了」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:kite:][p_k_05]
「………………」[rhp]

[off_all]

[::]
快斗似乎对我没什么好感。[rhr]
大概是气我来到这个所谓的『死后世界』吧。[rhp]
……这个事实该感到高兴，还是该为无法友好相处难过，心情很复杂。[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sora:][otiai kao=2 ]
「倒也无所谓。反正我也没指望被所有人喜欢」[rhp]
[:sora:][otiai kao=12 ]
「……总之……今后请多指教」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
#
[bg storage="train_12.jpg" time=1500]
;****************************************

[::]
――――就这样，我的银河铁道之旅开始了。[rhp]
坦白说最初很困惑。[rhr]
性格也好外貌也罢，全都乱七八糟的不是吗。[rhp]
……但是，我能真切感受到。[rhr]
在这里的，确实是我一直想见到的那些家伙啊。[rhp]

能回到过去似乎让我很开心。真是怀念。[rhr]
我觉得来到这里真是太好了。[rhp]
…………正因如此，才有了让我害怕的事。[rhp]

[:sora:]
[font color=0x4682b4]
（如果[player2]恢复了记忆……[rhr]
_　按照夜的计划，想要离开这条铁道的话……）[rhp]
[:sora:]
（[player2]和大家就……已经……）[rhp]
[:sora:]
（………………）[rhp]
[resetfont]

[::]
我，[player2]喜欢你。[rhp]
无论身处何方，即便你已忘记了我，这份心意都不会改变。[rhp]
我想再次看到活力满满的[player2]和大家一起欢笑的样子。[rhr]
这本该是我的梦想。[rhp]

;****************************************
[bg storage="black.jpg" time=1000]
;****************************************

―――――――这不是已经实现了吗。[rhp]
此刻。就在这里。[rhp]

[:sora:]
[font color=0x4682b4]
（………………对不起。夜）[rhp]
[resetfont]

[::]
我本想好好遵守约定。[rhp]
但我做不到。[rhr]
既然来到了这种地方。[rhp]
我就想留在这里。[rhp]
………………哪怕从此再也无法从梦中醒来。[rhp]

;****************************************
[s_mask time=4000]
;****************************************

;エンドフラグ
[eval exp="sf.c_end = 1"]

[cancelskip]
[fbgm]

[jump storage="title.ks" target="*start_end"]

[s]