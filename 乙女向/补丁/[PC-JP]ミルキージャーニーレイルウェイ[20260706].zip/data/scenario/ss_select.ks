
;---------------------------------------------------------------------------------------------
; 昼の選択
;---------------------------------------------------------------------------------------------

*select_scene_day

[bgm storage="bgm_42.ogg"]

;****************************************
[s_mask graphic="rule/krke_day.png" effect="fadeInLeft" time=1000]

;メッセージレイヤー0を非表示に。
[layopt layer="message0" visible="false"]
;ロールボタンを解放
[clearfix]
; キャラクターをすべて消す。
[chara_hide_all]

[if exp="f.ev_a_04 == 1"]
; 展望車（前半）
[bg storage="select_map2.png" time=100]
[s_mask_off time=1000 ]
[jump target="*Set_Clickable_Map_day"]

[endif]

; オチアイ（後半）
[bg storage="select_map.png" time=100]

[s_mask_off time=1000 ]
;****************************************

;-----------------------------------------------------------
*Set_Clickable_Map_day
;-----------------------------------------------------------
 
[layopt layer="message0" visible="false"]

; ドロップ
[clickable  x="62" y="100" width="127" height="498" storage="ss_drop.ks" target="*start" opacity="0" mouseopacity="50" border="1px:dashed:white" color="0x7fffd4"]

; カイト
[clickable x="235" y="100" width="127" height="498" storage="ss_kite.ks" target="*start" opacity="0" mouseopacity="50" border="1px:dashed:white" color="0x00ffff"]

; クリリン
[clickable x="408" y="100" width="127" height="498" storage="ss_riri.ks" target="*start" opacity="0" mouseopacity="50" border="1px:dashed:white" color="0xff1493"]

; 双子
[clickable x="581" y="100" width="127" height="498" storage="ss_hati.ks" target="*start" opacity="0" mouseopacity="50" border="1px:dashed:white" color="0xdc143c"]

; はかぺく
[clickable x="754" y="100" width="127" height="498" storage="ss_hkpk.ks" target="*start" opacity="0" mouseopacity="50" border="1px:dashed:white" color="0x483d8b"]

; プリンセス
[clickable x="927" y="100" width="127" height="498" storage="ss_puri.ks" target="*start" opacity="0" mouseopacity="50" border="1px:dashed:white" color="0xf0e68c"]

[if exp="f.ev_a_04 == 1"]
; 展望車（前半）
[clickable x="1100" y="100" width="127" height="498" storage="ss_otiai.ks" target="*start" opacity="0" mouseopacity="50" border="1px:dashed:white" color="0xffffff"]
[s]
[endif]

; オチアイ（後半）
[clickable x="1100" y="100" width="127" height="498" storage="ss_otiai.ks" target="*start" opacity="0" mouseopacity="50" border="1px:dashed:white" color="0x008b8b"]

[s]


;---------------------------------------------------------------------------------------------
;---------------------------------------------------------------------------------------------
;---------------------------------------------------------------------------------------------
;---------------------------------------------------------------------------------------------
;---------------------------------------------------------------------------------------------
; ２回目の選択
;---------------------------------------------------------------------------------------------
;---------------------------------------------------------------------------------------------
;---------------------------------------------------------------------------------------------
;---------------------------------------------------------------------------------------------
;---------------------------------------------------------------------------------------------

*select_scene_nig

;昼モードを解除
[iscript]
delete f.daymode;
[endscript]

;夜モードを取得
[eval exp="f.nigmode = 1"]

[bgm storage="bgm_42.ogg"]

;****************************************
[s_mask graphic="rule/krke_nig.png" effect="fadeInLeft" time=1000]

; メッセージレイヤー0を非表示に。
[layopt layer="message0" visible="false"]
; ロールボタンを解放
[clearfix]
; キャラクターをすべて消す。
[chara_hide_all]


[if exp="f.ev_a_04 == 1"]
; 展望車（前半）
[bg storage="select_map2.png" time=100]
[s_mask_off time=1000 ]
[jump target="*Set_Clickable_Map_nig"]
[endif]

; オチアイ（後半）
[bg storage="select_map.png" time=100]
[s_mask_off time=1000 ]
;****************************************

;-----------------------------------------------------------
*Set_Clickable_Map_nig
;-----------------------------------------------------------
 
[layopt layer="message0" visible="false"]

; ドロップ
[clickable  x="62" y="100" width="127" height="498" storage="ss_drop.ks" target="*start" opacity="0" mouseopacity="50" border="1px:dashed:white" color="0x7fffd4"]

; カイト
[clickable x="235" y="100" width="127" height="498" storage="ss_kite.ks" target="*start" opacity="0" mouseopacity="50" border="1px:dashed:white" color="0x00ffff"]

; クリリン
[clickable x="408" y="100" width="127" height="498" storage="ss_riri.ks" target="*start" opacity="0" mouseopacity="50" border="1px:dashed:white" color="0xff1493"]

; 双子
[clickable x="581" y="100" width="127" height="498" storage="ss_hati.ks" target="*start" opacity="0" mouseopacity="50" border="1px:dashed:white" color="0xdc143c"]

; はかぺく
[clickable x="754" y="100" width="127" height="498" storage="ss_hkpk.ks" target="*start" opacity="0" mouseopacity="50" border="1px:dashed:white" color="0x483d8b"]

; プリンセス
[clickable x="927" y="100" width="127" height="498" storage="ss_puri.ks" target="*start" opacity="0" mouseopacity="50" border="1px:dashed:white" color="0xf0e68c"]

[if exp="f.ev_a_04 == 1"]
; 展望車（前半）
[clickable x="1100" y="100" width="127" height="498" storage="ss_otiai.ks" target="*start" opacity="0" mouseopacity="50" border="1px:dashed:white" color="0xffffff"]
[s]
[endif]

; オチアイ（後半）
[clickable x="1100" y="100" width="127" height="498" storage="ss_otiai.ks" target="*start" opacity="0" mouseopacity="50" border="1px:dashed:white" color="0x008b8b"]

[s]
