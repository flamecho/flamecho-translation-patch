﻿f
*start

;--------------------------------------------------------------------------------------------
;▼フルボイスセット▼
;ドロップ
[voconfig sebuf=1 name=drop vostorage="drop/full/{number}.ogg" number=80]
;--------------------------------------------------------------------------------------------

;****************************************
[free_filter ]
[bgm storage="bgm_19.ogg"]
;****************************************

[::]
夏日祭典过后，已经过去三天。[rhp]
自那之后银河铁道便照常恢复运行，[rhr]
平淡无奇的日子持续着。[rhp]
我在自己房间的床铺上沉思的时间变多了。[rhp]
……脑海中浮现的仍是夏日祭那天，多洛普说过的话。[rhp]

;****************************************
[set_kk storage="cg/a_07_d_1.png" time=300]
;****************************************

[:drop:]
『就算被人觉得吃亏，这也是我的工作』[rhp]

;****************************************
[set_ff storage="train_08.jpg" time=300 ]
;****************************************

[:princess:][puri_w kao=0 ]
「……工作啊」[rhp]

[off_puri]

[::]
按常理来说，指的是『车掌这份工作』……但[rhr]
总觉得他的话语里还蕴含着其他更深层的含义。[rhp]

[:princess:][puri_w kao=2 ]
「…………好！」[rhp]

[off_all]

[::]
今天也要大干一场。[rhr]
我从床铺一跃而起，飒爽地离开了房间。[rhp]

;****************************************
[set_time storage="train_06.jpg"]
;****************************************

[:princess:][puri_w kao=13 ]
「你好啊—多洛普！在吗—？」[rhp]

[:drop:][drop kao=13 as=on ]
「……公、公主。您今天又来玩了……」[rhp]

[:princess:][puri_w kao=13 ]
「何止今天明天也会来哦」[rhp]

[:drop:][drop kao=6 as=on ]
「这样啊……」[rhp]

[:princess:][puri_w kao=5 ]
「话说！今天应该是休息日吧？[rhr]
_　为什么还在这里？快休息啦！来来赶紧的！」[rhp]

[:drop:]
「啊、明天肯定会休息的。请饶了我吧」[rhp]

[:princess:][puri_w kao=2 ]
「昨天也是这么说的，结果把休假拖到今天了吧！[rhr]
_　你打算永远用这个借口搪塞下去对吧！」[rhp]

[:princess:][puri_w kao=2 as=on ]
「没、没这回事。而且您看，睡觉的时候其实……」[rhp]

[:princess:]
「总之！在多洛普好好休假之前，[rhr]
_　我打算每天都来机房突击检查哦」[rhp]
[:princess:]
「在精神崩溃前，建议您早点放弃比较好」[rhp]

[:drop:][drop kao=6 as=on ]
「绝无这种可能所以请放心」[rhp]

[:princess:][puri_w kao=13 ]
「好吧！今天也在旁边施加无言的压力吧」[rhp]

[:drop:][drop kao=2 as=on ]
「请别这样！真的很吓人，还浪费你的时间。[rhr]
_　害得我没法专心工作―――，…………」[rhp]

[:princess:][puri_w kao=0 ]
「多洛普？」[rhp]

[:drop:][drop kao=13 ]
「……明白了！既然这么不想让我工作，[rhr]
_　要不要和我一起体验下这份工作？」[rhp]

[:princess:][puri_w kao=4 ]
「诶……！意思是像失忆前那样，[rhr]
_　不是作为普通乘客，而是可以当列车长！？」[rhp]

[:drop:]
「没错！想让您了解这份工作多么有趣，[rhr]
_　多么充满意义」[rhp]
[:drop:]
「说不定能借此回忆起过去，[rhr]
_　我的工作也能进展顺利一举两得。先试一周如何？」[rhp]

[:princess:][puri_w kao=14 hh=on ]
「当然想！！交给我吧多洛普！」[rhp]

[:drop:]
「非常感谢！那么立刻―――」[rhp]

[off_all]

[bg_magic_c color=0xffffff]

[:princess:][puri_w kao=0 hat=hat ]
「――――――！」[rhp]

[off_all]

[::]
光芒刚从多洛普指尖溢出，[rhr]
便在我头顶汇聚成型，化作与他同款的列车长帽。[rhp]

[:drop:]
「非常合适您呢！」[rhp]

[:princess:]
「谢谢……！[rhr]
_　嘿嘿，感觉真的当上列车长啦」[rhp]

[chara_part name="drop" body=base kao=13 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=13 as=off ss=off hh=off hr=on hat=hat ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「为了让多洛普能好好放松，我会加油的！[rhr]
_　请多指教！」[rhp]

[:drop:]
「彼此彼此，也请你多关照呢」[rhp]

[off_all]

[::]
就这样开始了为期一周的职业体验。[rhr]
无论如何都要展现出能让多洛普认可的工作态度！[rhp]
若能以这个因无所事事而感到寂寞的身份获得认可，[rhr]
今后或许就能得到『乘务员』这份稳定的工作了。[rhp]
不，虽然也有这个原因……但不仅如此！[rhp]

[:princess:]
[font color=0x4682b4]
（多洛普……！我一定要让你遵守劳动基准法！！）[rhp]
[resetfont]

;****************************************
[fbgm]
[set_xx graphic="rule/krke_d.png" storage="train_01.jpg"]
[bgm storage="bgm_01.ogg"]
;****************************************

[::]
――――――时光飞逝，转眼一周后。[rhp]
随着那天的夜幕降临，我的乘务员生涯终于迎来了终点。[rhp]
这七天里发生的事，请允许我省略不谈。[rhp]

[:princess:][puri_w kao=0 ]
「………………………………」[rhp]

[off_all]

[::]
…………希望你能理解。[rhr]
乘务员的……不，是多洛普的工作究竟有多么繁重。[rhp]

[:drop:][drop kao=1 ]
「看起来您很疲惫呢，公主」[rhp]

[:princess:][puri_w kao=6 as=on ]
「多洛普……」[rhp]

[:drop:][drop kao=1 ]
「非常感谢这一周的协助。体验下来感觉如何？」[rhp]

[:princess:][puri_w kao=2 as=on ss=on ]
「累死了……！比想象的还要累！」[rhp]

[off_all]

[::]
『乘务员』的本职工作倒没那么繁重，[rhr]
问题在于其他所有的杂务。[rhp]
不知为何，除了车厢检查外，饮食准备、[rhr]
补充手推车的商品库存，以及其他所有杂活都成了他的工作。[rhp]

[:princess:][puri_w kao=6 as=on ]
「多洛普没法休息 是因为其他杂务太多的缘故。[rhr]
_　难怪我从没见过其他人干活的样子」[rhp]

[:drop:][drop kao=1 ]
「哎呀呀……虽然玩忽职守确实不好[rhr]
_　但我并不介意分担他们的工作」[rhp]

[:princess:][puri_w kao=6 ]
「真是的～～～你也太宠他们了。[rhr]
_　这种情况就该严厉训斥才对！」[rhp]

[:drop:][drop kao=13 as=on ]
「中尉确实这么做了。但我不想强人所难[rhr]
_　或者说更希望尊重他们的自主性……我这样算是姑息吗」[rhp]

[:princess:][puri_w kao=2 ]
「宠过头了！！」[rhp]

[:drop:][drop kao=3 as=on ]
「不过想到死后还会被束缚的人生也很可悲……」[rhp]

[:princess:]
「多洛普自己不也是那样」[rhp]
[:princess:]
「根本没必要连死后都工作。[rhr]
_　只有对自己就苛刻得要命」[rhp]

[:drop:][drop kao=0 as=on ]
「啊——」[rhp]
[:drop:][drop kao=13 as=on ]
「…………哈哈。说、得也是呢……」[rhp]

[:princess:]
「没错。像这次就应该多依靠别人。比如说我」[rhp]

[:drop:][drop kao=1 ]
「非常感谢……但真的不用。[rhr]
_　忙碌的状态反而更适合我的性子」[rhp]

[:princess:][puri_w kao=6 as=on ]
「你这社畜病已经没救了啊……！」[rhp]

[off_all]

[::]
这一周里我明白了 多洛普对别人纵容得要命。[rhp]
虽然会唠叨偷懒的家伙 结果总是自己代劳 还把这事当成人生活着的意义。[rhr]
这种糅合了母亲、后辈和菩萨特质的人性，让人哑然。[rhp]

[:princess:]
[font color=0x4682b4]
（继续这种生活的话迟早会崩溃的吧……[rhr]
_　平时越温厚的人，爆发起来就越可怕呢……）[rhp]
[:princess:]
（…………好！）[rhp]
[resetfont]

[::]
为了将社畜王多洛普拽下王座，[rhr]
我决定前往某个人的住所寻求建议……[rhp]

;****************************************
[fbgm]
[set_xx graphic="rule/krke_d.png" storage="train_07.jpg"]
[bgm storage="bgm_01.ogg"]
;****************************************

此刻，我来到了最后的希望——博士的住处。[rhp]
由于倾诉了近一周的行动和心路历程，[rhr]
莫名觉得胸口轻松了些许。[rhp]

[chara_part name="hakase" body=base kao=0 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720" left="355" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=6 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「就是这样。总得想办法让多洛普休息啊」[rhp]

[:darknebula:][hakase kao=1 ]
「很棒的想法呢。休息能让工作张弛有度」[rhp]

[:princess:]
「对吧？首先得让大家都好好完成分内工作！[rhr]
_　但不确定他们是否会老实听我的话……」[rhp]

[:darknebula:][hakase kao=1 ]
「嗯……快斗用物质诱惑应该容易搞定，[rhr]
_　夸德里利昂和哈托谢普就……相当棘手了」[rhp]

[:princess:][puri_w kao=1 ]
「所以才来找博士你啊。[rhr]
_　如果是博士发话，他们应该会行动吧！」[rhp]

[:darknebula:][hakase kao=1 ]
「那可是责任重大啊……我真的能做到这种程度吗」[rhp]

[:princess:][puri_w kao=6 ]
「能做到的！至少比我说的更有信服力啦」[rhp]

[:darknebula:][hakase kao=1 ]
「……为什么公主您，[rhr]
_　如此希望多洛普休息呢？」[rhp]

[:princess:][puri_w kao=0 ]
「哎？为什么这么问……这不是明摆着嘛。[rhr]
_　照这样下去多洛普可能会过劳死的呀」[rhp]

[:darknebula:][hakase kao=1 ]
「这个世界的人类都不算活着呢。除了落合以外」[rhp]

[:princess:][puri_w kao=3 ]
「话是这么说。但不完全是这样。该怎么说呢……」[rhp]
[:princess:]
「就算因为有生存价值而不觉得痛苦，疲劳也肯定会累积的。[rhr]
_　工作固然重要，但休息同样重要吧」[rhp]
[:princess:]
「在不知不觉间积攒疲惫、却无法察觉的人生，[rhr]
_　你不觉得这样根本算不上幸福吗？」[rhp]

[:darknebula:][hakase kao=1 ]
「说得对……这个嘛，确实如此」[rhp]
[:darknebula:]
「那么假设现状就是多洛普的幸福，你又怎么看？」[rhp]

[:princess:][puri_w kao=0 ]
「多洛普的幸福……？」[rhp]

[:darknebula:][hakase kao=1 ]
「认为休息对他更好，只是你单方面认定的『多洛普需要改进之处』。[rhr]
_　可当事人非但不想改变现状，反而为忙碌感到欣喜呢」[rhp]
[:darknebula:]
「对没打算改变的人说再多也是白费力气吧」[rhp]

[:princess:][puri_w kao=3 ]
「……博士对我说过的话，小努西也对我说过哦」[rhp]

;****************************************
[set_kk storage="park_02.jpg" time=300]
;****************************************

[:nusi:]
「价值观因人而异嘛」[rhp]
「那家伙可比你以为的更要热爱自己的工作。[rhr]
_　甚至到了连玩耍时间都舍不得浪费的程度」[rhp]

;****************************************
[set_ff storage="train_07.jpg" time=300]
;****************************************

[:princess:][puri_w kao=3 ]
「―――话说」[rhp]

[:darknebula:][hakase kao=1 ]
「原来如此……那个人真是不可小觑呢」[rhp]

[:princess:][puri_w kao=0 ]
「博士果然也这么认为吗？」[rhp]

[:darknebula:][hakase kao=1 ]
「是啊。但别在意。[rhr]
_　意见分歧并不代表任何一方有错」[rhp]
[:darknebula:]
「人的感受千差万别。[rhr]
_　我认为重要的不是统一意见，而是学会包容」[rhp]

[:princess:]
「……也就是说？」[rhp]

[:darknebula:][hakase kao=1 ]
「回到多洛普的话题……或许最好还是等待他[rhr]
_　自己产生休假的念头比较合适」[rhp]
[:darknebula:]
「以他的性格。虽然你强硬要求的话他应该会勉强答应，[rhr]
_　但这样终究解决不了根本问题……公主应该明白吧？」[rhp]

[:princess:][puri_w kao=3 ]
「嗯……」[rhp]

[:darknebula:][hakase kao=1 ]
「抱歉。可能没给出什么有建设性的回答」[rhp]

[:princess:][puri_w kao=1 ]
「没、没关系啦。我才要道歉突然跑过来打――――――」[rhp]

[off_all]

[yurasu]

[:vulpecula:][peku kao=14 ]
[font size=27]
「喂喂喂喂喂―――喂！！」[rhp]
[resetfont]

[:darknebula:][hakase kao=0 ]
「哎呀佩奇。你在偷听吗？[rhr]
_　明明说了在普通车厢和哈托谢普一起玩的」[rhp]

[:vulpecula:][peku kao=61 ]
「不要嘛！不和博士一起的话就太无聊了啦」」[rhp]

[:princess:][puri_w kao=13 ]
「好啦好啦。所以，突然怎么了？」[rhp]

[:vulpecula:][peku kao=5 ]
「呼呼呼。你们的话我可～～～仔细听完了……！」[rhp]
[:vulpecula:]
「其实呢！佩奇有个超～～～特别的好主意！[rhr]
_　小公主想听吗？」[rhp]

[:princess:][puri_w kao=1 ]
「想听，」[rhp]

[yurasu]

[:vulpecula:][peku kao=14 ]
[font size=27]
「我们开庆功宴吧！！」[rhp]
[resetfont]

[:princess:][puri_w kao=4 ]
「慰劳会？」[rhp]

[:vulpecula:][peku kao=13 ]
「对！！让多洛普当派对国王！」[rhp]
[:vulpecula:]
「国王的工作就是不干活光命令别人对吧？[rhr]
_　多洛普要是成了国王，就能不干活一直坐着啦！」[rhp]

[:princess:][puri_w kao=4 as=on ]
「比想象中正经多了……」[rhp]

[:vulpecula:][peku kao=11 ]
「哼哼！因为我是姐姐嘛～」[rhp]

[:darknebula:][hakase kao=1 ]
「原来如此。这就是所谓的劳动感谢吧？」[rhp]

[:vulpecula:][peku kao=14 ]
「！！金劳感谢啊！[rhr]
_　确实一直受他照顾很值得感激呢！」[rhp]

[:darknebula:][hakase kao=1 ]
「只要搞一整天派对，身为主角的他就得强制待在那里，[rhr]
_　自然就能顺便休息了吧」[rhp]

[:princess:][puri_w kao=1 ]
「原来如此……！这主意超棒！」[rhp]
[:princess:][puri_w kao=13 ]
「那我现在马上就去找大家一起来准备咯！」[rhp]

[:darknebula:][hakase kao=1 ]
「有什么我能帮忙的事尽管说哦」[rhp]

[:vulpecula:][peku kao=11 ]
「从没拍过电影所以好紧张啊～！」[rhp]

[chara_part name="hakase" body=base kao=0 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720" left="355" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=6 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:2nin:]
「电影……？」[rhr]
「电影……？」[rhp]

[:vulpecula:][peku kao=1 ]
「咦？」[rhp]

;****************************************
[fbgm]
[set_xx graphic="rule/krke_d.png" storage="train_06.jpg"]
[bgm storage="bgm_15.ogg"]
;****************************************

[::]
公主干劲十足地走出机房后。[rhp]
虽有不祥的预感，我还是回到了车内维护作业中。[rhp]
为能久违地进行彻底检查感到欣喜，[rhr]
边作业边回顾这一周。[rhp]

[:drop:]
[font color=0x4682b4]
（虽有关键处的疏忽，但真是帮大忙了）[rhp]
[:drop:]
（……两人一起工作，真是久违了）[rhp]
[resetfont]

[::]
明明是不久前的事，却莫名觉得十分怀念。[rhr]
在我心里，『以前的公主』正逐渐淡去吗？[rhp]

[:drop:]
[font color=0x4682b4]
（……并不寂寞。这是很自然的事）[rhp]
[resetfont]

[::]
如同说服自己般，在心中低语。[rhp]
以前的公主从未迷失『本来目的』，始终坚守到最后。[rhr]
……虽说对现在的公主有把关不严之嫌，但真正松懈的是我。[rhp]
我总是这样摇摆不定。[rhp]

[:drop:][drop kao=3 ]
「……都怪公主太温柔了」[rhp]

[off_all]

[::]
现在的公主并非「列车长」而是「乘客」。[rhr]
如果是同事倒也罢了，但现在的她无法要求与我同等的立场。[rhp]
公主只需考虑自己的事情就好。[rhr]
至少以前的她就是如此。完美地履行着自己的职责。[rhp]
『你那边的工作请自行负责。[rhr]
_　相应地也不必顾及我的事』。[rhp]
完美的她，认为他人完美也是理所当然的事。[rhr]
所以无论何时，她都保持着那种姿态。[rhp]

……如今的公主却截然相反。[rhp]
将自己的事搁置一旁，总是只顾着我的事。[rhr]
正因为作为领袖的你那么说了，我才认真工作的啊。[rhp]
无论发生什么都会坚持到底。[rhr]
明明一直保持着这份觉悟。[rhp]

事到如今，你却说这样的我不行。[rhr]
真是任性。明明是效仿你才变成这样的。[rhp]
……快要被这份任性拯救的自己，想想真是可笑。[rhr]
这种地方，正是我的天真之处。[rhp]

[:drop:][drop kao=3 ]
「我到底在想什么……真不像我……」[rhp]

[off_all]

[::]
越是思考，就越害怕自己的天真会暴露无遗。[rhr]
或许自从落合来到之后，就不自觉地变得神经质了。[rhp]
没问题的。他还活着。[rhr]
虽然不知道外面的世界发生了什么，但只要活着回来就没问题。[rhp]
不，即便在那边死去了……[rhp]

[:drop:][drop kao=3 ]
「…………这似乎不需要我出场」[rhp]


;****************************************
[fbgm]
[set_b storage="train_01.jpg"]
[bgm storage="bgm_01.ogg"]
;****************************************

[::]
3天后。[rhp]
我决定为多洛普举办劳动感谢派对。[rhp]
趁着多洛普只顾埋头工作的空档，悄悄准备着食物和装饰品[rhr]
确保绝对不被发现的同时，稳步推进着准备工作。[rhp]
而今天……终于迎来了这个日子！[rhp]

[:princess:][puri_w kao=12 as=on ]
「好了……！不必担心我……来吧……」[rhp]
[:princess:][puri_w kao=2 as=on ]
[yurasu]
[font size=30]
「我上了！！！」[rhp]
[resetfont]

[off_puri]

[se storage="door_13.ogg"]

[::]
我干劲十足地敲响了机房的铁门。[rhr]
片刻后，铁门另一侧传来『来了』的应答声。[rhp]

[:princess:][puri_w kao=2 ]
「多洛普！能占用点时间吗？」[rhp]

[off_puri]

[:drop:]
『……是公主对吧？总觉得人设有点……算了』[rhp]

[se storage="door_07.ogg"]

[::]
多洛普从门内探出身子。那满脸狐疑的表情[rhr]
想必是源自哈蒂君传授的劝诱技巧。[rhp]

[:princess:][puri_w kao=5 ]
「呵呵……来得正好」[rhp]

[:drop:][drop kao=0 ]
「哈啊……有什么事吗？[rhr]
_　这个时间段我还以为您在和其他人玩桌游……」[rhp]
[:drop:][drop kao=6 as=on ]
「……咦？等等，说起来最近都没见到您身影。[rhr]
_　之前明明像跟踪狂似的非要我休息不可」[rhp]

[:princess:][puri_w kao=11 ]
「且住。无须多言」[rhp]

[:drop:]
「嗯？」[rhp]

[:princess:][puri_w kao=5 ]
「因有迫不得已之事。莫要多言，随我来便是」[rhp]

[:drop:]
「啊……算了算了。就一会儿哦？[rhr]
_　我还有工作没做完，没空玩」[rhp]

[:princess:][puri_w kao=12 ]
「嗯」[rhp]

[:drop:]
「你从刚才起怎么回事？这语气……」[rhp]

[off_drop]

[:princess:][puri_w kao=5 ss=on ]
[font color=0x4682b4]
（呵呵……！果然顺利上钩了。[rhr]
_　哈蒂君策划的『反常人对危险更敏感反而容易服从』战术，成功！！）[rhp]
[resetfont]

[off_all]

[::]
忍辱负重终有回报。[rhr]
愿派对就这样顺利成功吧！[rhp]

;****************************************
[fbgm]
[set_xx graphic="rule/krke_d.png" storage="black.jpg" time=200]
;****************************************

[:princess:]
「好了到了多洛普。先别摘眼罩哦」[rhp]

[:drop:]
「您倒是恢复正常语气了……究竟在盘算什么？」[rhp]

[:princess:]
「马上就知道啦！快来开门。[rhr]
_　炫目世界正等待着你！来吧！」[rhp]

[:drop:]
「虽然只有不祥的预感……算了算了」[rhp]

[off_puri]

[:drop:]
[font color=0x4682b4]
（随便应付下，赶紧回机房吧）[rhp]
[resetfont]

[::]
终于迎来这一刻……！多洛普将手搭上门把。[rhp]

[se storage="door_07.ogg"]

[:drop:]
「打扰了——」[rhp]

;****************************************
;スチル
[still storage="cg/a_08_d_1.png" rule="021.png" width="1280" height="720" time=1000]
[cg storage="cg/a_08_d_1.png"]
[bgm storage="bgm_17.ogg"]
;****************************************

[:heartshape:]
「啊！主角到场啦！」[rhp]

[:jet:]
「太慢了啊主角」[rhp]

[:drop:]
「这……这是什么？『多洛普☆黄金档感谢』……？」[rhp]

[:princess:]
「大家预备！三——」[rhp]

[:xnin:]
「「「多洛普～～～～！一直感谢你～～～～！」」」[rhp]

[:drop:]
「诶……」[rhp]

[:princess:]
「嘿嘿嘿！怎么样？吓一跳吧？」[rhp]
[:princess:]
「因为你总是为我们拼命工作，[rhr]
_　所以今天大家怀着感谢的心情，一起为你准备了派对哦」[rhp]

[:vulpecula:]
「上黄金档了对吧！辛苦啦多洛普～！」[rhp]

[:drop:]
「并没有上节目……」[rhp]

[:heartshape:]
「！？！？　呃？」[rhp]

[:kite:]
「你也来这套」[rhp]

[:quadrillion:]
「就不该让小鬼头们做弹幕设计」[rhp]

[:drop:]
「大、大家为什么这样。难道都参与了这事？」[rhp]

[:quadrillion:]
「就是那个难道哦。因为布兹死缠烂打，[rhr]
_　没办法才帮忙的」[rhp]
[:quadrillion:]
「不过确实很感谢你呢。偶尔这样也不错吧」[rhp]

[:kite:]
「我也是。采购管理销售零钱准备全丢给你，对不起啦」[rhp]

[:quadrillion:]
「这不就是所有工作了吗？」[rhp]

[:kite:]
「没啦，看店是我负责的」[rhp]

[:quadrillion:]
「明明只是在附近睡觉还好意思说……」[rhp]

;****************************************
; スチル終了
[still_end frame="win.png" storage="train_03o.jpg" method="fadeInRightBig" time=200]
;**************************************

[:drop:][drop kao=4 as=on ]
「……………………」[rhp]

[:princess:][puri_w kao=13 hh=on ]
「嘿嘿嘿……！是博士教我的。[rhr]
_　要是怎么都拦不住你休息，不如试着用这种方法」[rhp]
[:princess:]
「大家这么费心思准备，[rhr]
_　身为主角可不能现在溜去工作哦？」[rhp]

[:drop:]
「好、好的……」[rhp]

[:princess:][puri_w kao=1 ]
「听好咯。这是感谢的证明！谢谢你每天为我们操劳。[rhr]
_　从今往后要定期举办这个『多洛普慰劳会』啦！」[rhp]

[:drop:][drop kao=8 as=on ]
「咦！？不、那样也太夸张了。[rhr]
_　派对可以办，但至少让我帮忙做点什……」[rhp]

[:princess:][puri_w kao=2 ]
「不行！今天的主角可是多洛普呀」[rhp]
[:princess:]
「再说多洛普自己的工作都忙不过来吧。[rhr]
_　难道你想马虎应付工作吗？」[rhp]

[:drop:]
「那、那是……」[rhp]

[:princess:][puri_w kao=5 ]
「对吧！所以交给我们来筹备就好。[rhr]
_　托多洛普的福我们有充足的时间呢」[rhp]
[:princess:]
「如果实在想帮忙，不如把多洛普的工作分些给我们做」[rhp]

[:drop:]
「……不，可是……」[rhp]

[off_drop]

[chara_part name="riri" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:princess:][puri_w kao=2 ]
「说到底只要大家做好分内工作就行啦」[rhp]

[:quadrillion:][riri kao=13 ]
「剥夺多洛普的人生意义这么残忍的事，人家可做不来呢……」[rhp]

[:kite:][kite kao=13 ]
「挥洒汗水努力工作的多洛普最棒了」[rhp]

[:princess:][puri_w kao=6 as=on ]
「人渣聚集地……」[rhp]

[:kite:][kite kao=11 ]
「嘛，反正摆弄无人问津的手推车内容物，[rhr]
_　还不如布置派对会场更能帮到多洛普呢」[rhp]

[:quadrillion:][riri kao=14 ]
「当天不用打扫餐车卫生，也算是为多洛普着想对吧」[rhp]

[off_all]

[chara_part name="jet" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:]
「哦、那我们好歹有点用处吧……！？[rhr]
_　感觉总是给多洛普添麻烦似的……」[rhp]

[:jet:][jet kao=13 ]
「因为要准备派对，所以没时间破坏吊环了」[rhp]

[:heartshape:][hati kao=5 ]
「就是这个！！！」[rhp]

[off_all]

[:otiai:][otiai kao=6 as=on ]
「别把破坏当成前提啊……」[rhp]

[off_otiai]

[chara_part name="drop" body=base kao=0 as=on ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=1 as=off ss=off hh=off hr=on]
[chara_show name="puri_w" layer="message0" left="1" top="1" width="330" height="720" wait="true" zindex="1005" time=150]

[:princess:]
「……就是这么回事！虽然很抱歉，[rhr]
_　大家的工作暂时只能由多洛普来承担了」[rhp]
[:princess:]
「所以相对的，派对的事你完全不用操心。[rhr]
_　多洛普只要尽情享受就好」[rhp]
[:princess:]
「说到底，就像托你的福什么都不用干的我们一样呢！」[rhp]

[:drop:]
「这很难做到……不过……」[rhp]
[:drop:][drop kao=3 as=on ]
「………………，真的非常感谢」[rhp]

[:princess:][puri_w kao=4 as=on ]
「――――――！你、你哭了？」[rhp]

[:drop:]
「对、对不起……一时没忍住。这还是第一次……」[rhp]

[off_all]

[chara_part name="riri" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:kite:]
「对了。趁这个机会，开个把积压的郁闷伴着眼泪一起倾倒出来的发泄会吧」[rhp]

[:quadrillion:]
「那是什么啊？」[rhp]

[:kite:][kite kao=11 ]
「要不是这种机会，优等生多洛普连一句抱怨都不会说吧」[rhp]
[:kite:]
「比如克林的恶心之处啦，哈蒂超级烦人的地方啦，[rhr]
_　这类积怨每月一次让大家发表出来」[rhp]

[:quadrillion:][riri kao=5 as=on ]
「看来您很有自信不会成为被抱怨的对象呢」[rhp]

[off_all]

[chara_part name="jet" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width=437 height=720 left="80" top="0" wait="false" time=150]
[chara_part name="otiai" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width=437 height=720 left="421" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width=437 height=720 left="760" top="0" wait="true" time=150]

[:heartshape:]
「我超级烦人！？难道我……很烦人吗！？」[rhp]

[:jet:][jet kao=5 ]
「一点都不烦人啊。是其他人嘀嘀咕咕说得太多了。[rhr]
_　你要是像哈蒂那样大声说出来我会更舒服」[rhp]
[:jet:]
「你倒是凑近点听啊落合。[rhr]
_　哈蒂的冷冽嗓音不是特别好懂吗？」[rhp]

[off_all]

[:otiai:][otiai kao=2 as=on ]
「呜哇！快住手别凑我耳朵……」[rhp]

[off_otiai]

[:heartshape:][hati kao=14 ]
[font size=30]
「你好――――――！！！！！」[rhp]
[resetfont]

[off_hati]

[chara_part name="hakase" body=base kao=2 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="hakase" layer="1" width=571 height=720 left="40" top="0" wait="false" time=150]
[chara_part name="otiai" body=base kao=12 as=on ss=on hh=off hr=on ]
[chara_show name="otiai" layer="1" width=437 height=720 left="421" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=8 as=on ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width=571 height=720 left="720" top="0" wait="true" time=150]

[:vulpecula:]
「呜哇啊啊～～～！人家不要死掉啦小落～[rhr]
_　我们UNO还没决出胜负呢～～！！」[rhp]

[:darknebula:]
「这种情况下死因应该是……？鼓膜破裂引发的某种……」[rhp]

[off_all]

[chara_part name="drop" body=base kao=0 as=on ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=2 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「等等……真是的！大家太吵了！多洛普很困扰吧！」[rhp]

[off_all]

[chara_part name="riri" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width=514 height=720 left="168" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width=514 height=720 left="606" top="0" wait="true" time=150]

[:kite:]
「来抱怨啊多洛普。[rhr]
_　这群家伙真的吵死了对吧？来跟我分担怨气吧」[rhp]

[:quadrillion:]
「胡说什么呢，起因不就是你吗。[rhr]
_　能理解多洛普辛苦的只有同为劳碌命的我吧」[rhp]

[off_all]

[chara_part name="jet" body=base kao=11 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width=437 height=720 left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width=437 height=720 left="645" top="0" wait="true" time=150]

[:heartshape:]
「不。是同为乘务员的我们！」[rhp]

[:jet:]
「完全同意」[rhp]

[off_all]

[chara_part name="hakase" body=base kao=0 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="hakase" layer="1" width=571 height=720 left="40" top="0" wait="false" time=150]
[chara_part name="otiai" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width=437 height=720 left="421" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width=571 height=720 left="720" top="0" wait="true" time=150]

[:vulpecula:]
「呜啊～～小落～～～！不可以死掉～～！」[rhp]

[:darknebula:]
「不对佩奇，这世界的人类已经―――[rhr]
_　啊不过他的情况特殊？这该怎么算呢。真令人感兴趣……」[rhp]

[off_all]

[:princess:][puri_w kao=6 as=on ]
「够啦！不要到处吵吵闹闹的！[rhr]
_　好啦快点继续派对啦……」[rhp]

[:drop:][drop kao=2 ]
「…………可以的吧」[rhp]

[:princess:]
「嗯？」[rhp]

[:drop:][drop kao=6 ]
「就今天……让我发发牢骚……可以的吧……」[rhp]

[:princess:]
「呃？嗯、嗯。今天的主角是多洛普所以，」[rhp]

[off_all]

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
[vostart]
;--------------------------------------------------------------------------------------------

[yurasu]

[:drop:]
[font size=25]
「呜哇啊啊啊啊啊啊啊啊――――――！！！！！！」[rhp]
[resetfont]

[:princess:][puri_w kao=4 as=on ]
「！？」[rhp]

[off_puri]

[::]
突如其来的完全不符合多洛普性格的怒吼声，[rhr]
让嘈杂的众人瞬间静止，齐刷刷看向他。[rhp]
多洛普眼眶含泪面红耳赤，死死瞪着所有人。[rhp]

[off_all]

[:drop:][drop kao=2 as=on hh=on ]
「为什么大家就不能更友好相处呢～！[rhr]
_　每次回过神来都在吵架！你们知道我善后有多辛苦吗！？」[rhp]

[off_all]

[chara_part name="riri" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="30" top="0" wait="false" time=150]
[chara_part name="drop" body=base kao=2 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="736" top="0" wait="true" time=150]

[:drop:]
「夸德里利昂！！快斗先生！！说的就是你们！！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:kite:]
「对、对不起」[rhp]

[:quadrillion:]
「我倒是无所谓啦……」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:drop:]
「是在狡辩吗！？还打算继续这样吗！？[rhr]
_　你们还要我怎么当和事佬！」[rhp]
[:drop:]
「结果工作时又集体偷懒，太过分了！[rhr]
_　到底哪里看得出关系好啦！」[rhp]

[:2nin:]
「………………」[rhr]
「………………」[rhp]

[yurasu]

[:drop:]
[font size=25]
「握手！！」[rhp]
[resetfont]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[off_all]

[chara_part name="riri" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:kite:]
「好、好的」[rhp]

[:quadrillion:]
「对不起……」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[:drop:][drop kao=6 hh=on ]
「这样就对了！要好好相处！[rhr]
_　要是不想让我为难，就请从最基本做起！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[off_drop]

[chara_part name="riri" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:quadrillion:]
「…………你这是清醒着吧？」[rhp]

[:kite:]
「姑且」[rhp]

[off_all]

[chara_part name="hakase" body=base kao=1 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720" left="40" top="0" wait="false" time=150]
[chara_part name="drop" body=base kao=2 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="720" top="0" wait="true" time=150]

[:vulpecula:]
「多洛普ー！佩奇你没什么要说的吗！？」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:drop:]
「对好孩子可没有怨言哟」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:vulpecula:][peku kao=8 ]
「诶～～～！？怎么这样！」[rhp]

[:darknebula:]
[font color=0x4682b4]
（为什么非要别人骂你啊……）[rhp]
[resetfont]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:drop:][drop kao=2 ]
「博士平时也该多出门运动！！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:darknebula:][hakase kao=5 as=on ]
「咦？！好、好的」[rhp]

[:vulpecula:][peku kao=2 ]
「只有博士被说太狡猾～啦！佩奇也想被说点什么啦！」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:drop:][drop kao=13 ]
; みんな……！が冒頭に入るのをカット
「今后请继续保持友好，还有举止得体！请跟随我的指引」[rhp]
[:drop:][drop kao=14 ]
「这样的话，我必定会带领大家开启精彩的旅程！」[rhp]

[off_all]

[::]
在连珠炮般的说教后恢复成往常模样的多洛普面前，[rhr]
众人愣怔之余又带着些许安心笑意。[rhp]
细想来，这还是他第一次如此直率地展现真实情感。[rhr]
而最令人欣喜的是，多洛普此刻的神情格外明朗。[rhp]

[:princess:]
[font color=0x4682b4]
（虽说多洛普看起来像在生气，[rhr]
_　但总感觉整个人都焕发着活力。莫非其实很开心……）[rhp]
[resetfont]

[::]
最初还担心会搞砸，如今看来举办这场派对真是太好了。[rhr]
真希望能再有多些机会带多洛普体验快乐的事！[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_12.jpg" time=1000]
;****************************************

随后我们沉浸在满溢的满足感中，难得地没有发生任何争执，[rhr]
共同度过了无比美妙的一天―――[rhp]

;****************************************
[fbgm]
[set_xx graphic="rule/krke_d.png" storage="train_03.jpg"]
[bgm storage="bgm_07.ogg"]
;****************************************

派对的时间转眼即逝，[rhr]
当大家闹腾累了纷纷睡去之后。[rhp]
我和多洛普正在努力收拾作为派对会场的餐车。[rhp]

[:princess:][puri_w kao=6 as=on ]
「真的对不起。明明是今天的主角还让你帮忙收拾」[rhp]

[:drop:][drop kao=1 ]
「没事没事。因为我喜欢打扫，请别在意」[rhp]

[:princess:]
「真是的，为什么大家都比主角先睡着了啊？」[rhp]

[:drop:]
「我听说这次派对准备期间，最后一天是通宵的。[rhr]
_　那样的话累了也是没办法的事哦」[rhp]
[:drop:]
「不如这里交给我，你也先回房间……」[rhp]

[:princess:][puri_w kao=2 ]
「那不行。不坚持到最后就没有意义了」[rhp]
[:princess:]
「……不过谢谢你来帮忙。[rhr]
_　果然没多洛普还是不行呢，我们」[rhp]

[:drop:][drop kao=13 ]
「听你这么说我很高兴。每天努力都值得了」[rhp]
[:drop:]
「所以请别客气让我继续帮忙收拾吧。[rhr]
_　高处的装饰你够不着吧」[rhp]

[:princess:][puri_w kao=1 ]
「这么说也是。那就拜托你负责那部分吧」[rhp]

[off_all]

[::]
此后我们一边闲聊着，一边收拾墙上和天花板的装饰、[rhr]
散落在地板的拉炮碎屑、没吃完的点心等等。[rhp]
多洛普没有直接用魔法一口气收拾完，[rhr]
大概是为了配合不会使用魔法的我吧。[rhp]
……真是的，连这种细节都这么温柔。[rhp]

[set_time_b]

又过了几十分钟，我们总算大体完成了整理。[rhp]
我们并排站着，心满意足地环顾恢复原状的房间。[rhp]

[chara_part name="drop" body=base kao=1 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=1 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「怎么说呢还是这样更自在呢。虽然有点寂寞」[rhp]

[:drop:]
「今后就算不是慰劳会，也可以多办些派对。[rhr]
_　比如万圣节啦，圣诞节啦」[rhp]

[:princess:][puri_w kao=13 ]
「这主意不错！听起来就开心！」[rhp]

[:drop:][drop kao=6 ]
「到时候请务必让我帮忙准备。[rhr]
_　察觉到你们自己热闹的样子，我总有点落寞呢？」[rhp]

[:princess:]
「嗯。有多洛普加入的话派对肯定会更精彩！」[rhp]

[:drop:][drop kao=13 ]
「非常感谢。我会努力的」[rhp]

[off_all]

[::]
光是想象未来的事，现在就开心得不得了。[rhr]
首先要过万圣节啊。秋天怎么还不快点到来……[rhp]

[:drop:][drop kao=1 ]
「公主」[rhp]

[:princess:][puri_w kao=1 ]
「什么？」[rhp]

[:drop:]
「请允许我再次说声，今天真的非常感谢。[rhr]
_　我还是第一次这样彻底展现自我……可能有点得意忘形了」[rhp]

[:princess:]
「这样不挺好嘛！大家都很高兴哦」[rhp]
[:princess:]
「今天的经历我一辈子都不会忘记。[rhr]
_　光是这一点，我就觉得办这场派对很值得了」[rhp]

[:drop:][drop kao=13 ]
「真高兴。这意味著您会永远记得我吧」[rhp]

[:princess:][puri_w kao=13 ]
「就是这样。我绝对不会忘记的，多洛普」[rhp]
[:princess:][puri_w kao=1 ]
「……希望别再发生失忆就好了」[rhp]

[:drop:][drop kao=13 ]
「没问题的」[rhp]

[:princess:]
「但愿如此。我得当心点」[rhp]

[:drop:][drop kao=1 ]
「不是『但愿如此』，而是绝对。[rhr]
_　这种事再也不会发生第二次了」[rhp]

[:princess:][puri_w kao=0 ]
「多洛普……？」[rhp]

[:drop:][drop kao=13 ]
「……说得也是。作为今天的谢礼，给您一个提示吧。[rhr]
_　毕竟我永远是顾客的伙伴」[rhp]

[fbgm]

[:drop:]
「不被南发现、勉强及格的答案」[rhp]

[:princess:][puri_w kao=4 as=on ]
「……！　咦……」[rhp]

[bgm storage="bgm_09.ogg"]

[:drop:][drop kao=0 ]
「失忆前的您，曾和南进行过『赌局』。[rhr]
_　您的失忆正是那场赌局的一环」[rhp]

[:princess:][puri_w kao=0 ]
「赌局……？」[rhp]

[:drop:]
「但像这样的赌局，您是第一个也是最后一个。[rhr]
_　无论谁胜出，都不会再出现记忆丧失者了」[rhp]

[:princess:][puri_w kao=2 as=on ]
「我不明白。所谓赌局是什么？[rhr]
_　我和南究竟约定了什么？」[rhp]

[:drop:][drop kao=3 ]
「这点恕难奉告……非常抱歉」[rhp]
[:drop:]
「但这条铁道，正是因您存在才得以完成的场所。[rhr]
_　南绝不能激怒您让您离开」[rhp]
[:drop:]
「这次旅行的总结者，其实并不是我。[rhr]
_　公主殿下。恰恰是你本人啊」[rhp]

[:princess:]
「啊……我……？」[rhp]

[:drop:]
「我们参与你们的赌局。[rhr]
_　但无论结果如何，希望你能抵达真相的心意不会改变」[rhp]
[:drop:]
「希望你能够回想起来。事情的真相。[rhr]
_　因为无论哪方获胜，这里都是死后世界的事实不会改变」[rhp]

[:princess:]
「………………」[rhp]

[:drop:]
「其实这些话本不该由我说出口。[rhr]
_　连我自己都惊讶于心态的变化」[rhp]
「……我似乎能理解落合爱上你的心情了」[rhp]

[:princess:][puri_w kao=4 as=on ]
「――――――哈？」[rhp]

[:drop:][drop kao=2 as=on ]
「！　啊、不……没、没什么。请忘记刚才的话」[rhp]

[:princess:][puri_w kao=2 as=on ]
「怎么可能忘记啊！什么意思？落合君他」[rhp]

[:drop:][drop kao=13 as=on ]
「不不不……这、这个话题到此为止吧」[rhp]
[:drop:]
「落合只是重要的乘客之一。仅此而已」[rhp]

[:princess:]
「别打岔！那些话明明——」[rhp]

[:drop:][drop kao=2 as=on ]
「唯独不想让你知道。只有你」[rhp]

[:princess:]
「只有我……？这也和南的赌局有关吗？」[rhp]

[:drop:][drop kao=3 ]
「………………」[rhp]

[:princess:]
「什么啊……到底……」[rhp]

[:drop:]
「…………失策了。不该说多余的话」[rhp]
[:drop:]
「早该料到你是这么执拗的性格，[rhr]
_　明明这几天已经深刻体会到了才对」[rhp]

[:princess:]
「没错哦。无论被拒绝多少次，我都会继续倾听的」[rhp]

[:drop:][drop kao=2 ]
「……那么，就由我来结束这场对话吧」[rhp]

[:princess:]
「！」[rhp]

[:drop:]
「为了你和我，从明天开始迎来崭新的一天」[rhp]

[off_all]

[::]
这番难以理解的话语，不知为何听起来格外明朗。[rhr]
对方露出与之相称的温和笑容，我不由后退了半步。[rhp]
……不知为何。有种不祥的预感。[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:drop:][drop kao=13 ]
「……还记得你在夏日祭典上说过的话吗？」[rhp]

[:princess:][puri_w kao=6 as=on ]
「诶？那、那个……好像说过不少事来着」[rhp]

[:drop:]
「想尽情享受这趟旅程。[rhr]
_　反正都是将死之人了 干脆放纵做尽想做的事」[rhp]
[:drop:]
「但唯独不愿接受 那里面没有我」[rhp]
[:drop:]
「……你当时 是这么说的」[rhp]
[:drop:]
「我开心得几乎颤抖。[rhr]
_　因为我原以为 自己只被这条铁道所需要」[rhp]

[off_all]

[:drop:]
「……能遇见你 真是太好了」[rhp]

[::]
―――就在此时，煤烟的清香忽然掠过鼻尖。[rhp]

;****************************************
;スチル
[still storage="cg/a_08_d_2.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/a_08_d_2.png"]
;****************************************

[:princess:]
「――――――！」[rhp]

[::]
淡绿色的刘海在眼前轻轻摇曳。[rhp]
纤长的睫毛。[rhr]
略带凉意的嘴唇。[rhp]
当我终于意识到这个状况时，[rhr]
他缓缓离开我的唇瓣，再次露出浅笑。[rhp]

;****************************************
;スチル
[bg storage="cg/a_08_d_2b.png" width="1280" height="720" time=500]
[cg storage="cg/a_08_d_2b.png"]
;****************************************

[:drop:]
「你的人生里 根本没有我的戏份」[rhp]
[:drop:]
「我就此退场」[rhp]

[::]
初次见到，那悲伤的笑容。[rhp]
完全听不懂多洛普在说什么。[rhr]
即便如此，他也不会等待我的理解。[rhp]

[:drop:]
「一直以来谢谢你，公主」[rhp]
[:drop:]
「…………愿你，幸福」[rhp]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

;-----------------------------------------------------------
;-----------------------------------------------------------

[jump storage="ev_a_08.ks" target="*start"]

;-----------------------------------------------------------
;-----------------------------------------------------------

*start2

;-----------------------------------------------------------
;-----------------------------------------------------------

;****************************************
[set_b storage="train_12.jpg"]
;****************************************

翌日[rhp]

;****************************************
[bg_rule storage="train_04.jpg" rule="002.png" time=500]
[bgm storage="bgm_01.ogg"]
;****************************************

[yurasu]
[:princess:]
[font size=30]
『啊啊啊――――――！！！！！』[rhp]
[resetfont]

[chara_part name="jet" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width=437 height=720 left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width=437 height=720 left="645" top="0" wait="true" time=150]

[:heartshape:]
「怎么回事！？矢部的偷袭吗！？」[rhp]

[:jet:]
「名医可没那么聪明。这是公主发现睡过头时的惨叫」[rhp]
[:jet:][jet kao=5 ]
「……要偷看吗？表情应该很有趣」[rhp]

[:heartshape:][hati kao=14 ]
[font size=28]
「有趣！！立刻出发！！」[rhp]
[resetfont]

;****************************************
[set_xx graphic="rule/krke_d.png" storage="train_06.jpg" time=200]
;****************************************
[yurasu]
[se storage="door_07.ogg"]

[:princess:][puri_w kao=2 as=on ]
[font size=27]
「真是～～～～的！多洛普！！」[rhp]
[resetfont]

[off_puri]

[:drop:][drop kao=13 ]
「公主。早上好」[rhp]

[off_drop]

[::]
在机房的他一如既往用清爽笑容迎接我。[rhp]
我噔噔噔地走上前，直勾勾地瞪着他。[rhp]

[chara_part name="drop" body=base kao=13 as=on ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=2 as=on ss=off hh=off hr=on  hat=okan]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「真是的，又没按时叫醒我对吧！[rhr]
_明明说过要是迟迟不起床就来叫我！」[rhp]

[:drop:]
「对、对不起。准备早餐太忙了……」[rhp]

[:princess:
「所以说了要叫你起来帮忙啊ー！」[rhp]

[:drop:]
「非常抱歉……」[rhp]

[:princess:][puri_w kao=6 as=on ]
「呜……说到底原本就是我睡过头不对啦……！[rhr]
_突然吼你对不起哦」[rhp]

[:drop:][drop kao=14 ]
「没关系。我不介意的」[rhp]

[:princess:][puri_w kao=1 ]
「准备工作还有哪些没完成？我来帮你稍微做一点」[rhp]

[:drop:][drop kao=1 ]
「桌子只要摆好刀叉就完成了」[rhp]

[:princess:][puri_w kao=2 as=on ]
「完全没我出场机会呢……你做事真是快得过分」[rhp]

[:drop:][drop kao=13 ]
「………………那个、公主」[rhp]

[:princess:][puri_w kao=0 ]
「嗯？怎么了？难道是忘了什么事……」[rhp]

[:drop:][drop kao=0 ]
「……………………」[rhp]

[:princess:][puri_w kao=1 ]
「……多洛普？」[rhp]

[:drop:][drop kao=13 ]
「…………昨晚睡得好吗？」[rhp]

[:princess:][puri_w kao=1 ]
「嗯！和多洛普一起收拾完后，累得直接睡着啦」[rhp]

[:drop:][drop kao=1 ]
「这样啊。太好了……」[rhp]

[:princess:][puri_w kao=7 ]
「啊，不过」[rhp]

[:drop:][drop kao=4 as=on ]
「！怎、怎么了？」[rhp]

[:princess:]
「从快收拾完那会儿开始的记忆有点模糊呢……怎么回事呢」[rhp]

[:drop:][drop kao=0 as=on]
「……！」[rhp]

[:princess:][puri_w kao=2 as=on hh=on ]
「虽然觉得不太可能……我该不会是迷迷糊糊在做收尾工作吧？」[rhp]

[:drop:][drop kao=13 ]
「……呵呵！是呢。说不定是半梦半醒的状态哦」[rhp]

[:princess:][puri_w kao=6 as=on hh=on ]
「呜……！好、好羞耻。应该没做什么奇怪的事吧……！」[rhp]

[:drop:]
「没问题的。[rhr]
_　您顺利完成收拾工作，平安无事地回到房间了」[rhp]

[:princess:][puri_w kao=13 as=on ]
「这样啊。那就好」[rhp]

[off_all]

;****************************************
#
[bg storage="train_01.jpg" method="fadeInRightBig"]
;****************************************

[chara_part name="jet" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:jet:]
「真奇怪……明明觉得会发生什么，特意躲在暗处偷看」[rhp]

[:heartshape:]
「这根本就是普通到不需要这么做的日常对话啊……不觉得奇怪吗？」[rhp]

[:hutago:]
「那俩家伙为啥还不交往啊！」[rhr]
「那俩家伙为什么没有交往？」[rhp]

[off_all]

[:quadrillion:][riri kao=13 ]
「一大早偷窥可真是好兴致啊，你们……让我也加入嘛」[rhp]

[off_all]

[chara_part name="jet" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="riri" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="760" top="0" wait="true" time=150]

[:heartshape:]
「快看啊克林！本来说好等收拾完大家就集体装睡[rhr]
_　让他们俩独处的计划！」[rhp]

[:jet:][jet kao=1 ]
「明明应该顺利进行的……！」[rhp]

[:hutago:]
「怎么变回日常状态了啊！」[rhr]
「怎么感觉又回到平时的日常了？」[rhp]

[:quadrillion:][riri kao=8 ]
「好像是呢。真是的，多洛普也太没出息了……」[rhp]

[:heartshape:][hati kao=3 as=on ]
「可恶，我们简直是彻头彻尾的蠢货……！」[rhr]
_　本想装睡，没想到真的睡死过去了！」[rhp]

[:quadrillion:][riri kao=3 ]
「明明觉得绝对没问题，结果突然就困得要命呢」[rhp]

[:jet:][jet kao=11 as=on ]
[font color=0x4682b4]
（不过哈蒂演技很差，睡着了反而省心……）[rhp]
[resetfont]

[:heartshape:][hati kao=2 ]
「好嘞！！下次慰劳会一定要动真格！[rhr]
_　必须掌握绝对不会睡着的方法！！」[rhp]

[:jet:][jet kao=1 ]
「呃、这个嘛……」[rhr]
[font color=0x4682b4]
（首先得让他学会装睡才行……）[rhp]
[resetfont]

[off_all]

;****************************************
#
[bg storage="train_06.jpg" method="fadeInRightBig" time=200]
;****************************************

[::]
――――――！　――――――！[rhp]

[:princess:][puri_w kao=0 ]
「……嗯？」[rhp]

[off_puri]

[::]
总觉得机房外面异常吵闹。[rhr]
这个声音……是哈蒂君他们吧。[rhp]

[:princess:][puri_w kao=0 ]
「真是的，一大早吵什么呢？」[rhp]

[:drop:][drop kao=0 ]
「确实精力充沛呢……明明之前睡得那么沉」[rhp]

[:princess:][puri_w kao=6 ]
「对啊。想叫他们回房间休息，却怎么都叫不醒。[rhr]
_　简直就像被施了魔法一样」[rhp]

[:drop:][drop kao=13 ]
「…………哈哈，怎么可能。[rhr]
_　用魔法让人睡着对谁都没有好处不是吗」[rhp]

[:princess:][puri_w kao=1 ]
「嘛，那倒也是」[rhp]

[:drop:]
「正是如此。想必是太累了吧」[rhp]

[:princess:]
「毕竟熬了一整夜。[rhr]
_　我自己也恍惚到记忆都断片了呢」[rhp]

[:drop:][drop kao=1 ]
「嗯。今后请别太勉强自己了」[rhp]
[:drop:][drop kao=7 ]
「……啊，话说有件事。[rhr]
_　公主，能帮我个忙吗？」[rhp]

[:princess:][puri_w kao=4 hh=on ]
[font color=0x4682b4]
（……！居然依赖我……！）[rhp]
[resetfont]
[:princess:][puri_w kao=14 hh=on ]
「嗯，当然可以！真稀奇啊，多洛普会说这种话」[rhp]

[:drop:][drop kao=1 ]
「想麻烦你去叫落合起床。[rhr]
_　另外还没吃早餐的，就只剩你和落合了」[rhp]
[:drop:]
「你看，他好像不太待见我……[rhr]
_　还是交给你比较合适吧」[rhp]

[:princess:][puri_w kao=5 ]
「原来如此。这种情况就包在我身上啦！」[rhp]

[:drop:][drop kao=13 ]
「拜托你了」[rhp]

[off_all]

太好了。虽然遗憾到最后都没能完全记住，[rhr]
但我的心意似乎多少传达到了多洛普那里。[rhp]

[:princess:][puri_w kao=13 hh=on ]
[font color=0x4682b4]
（呵呵……！从今以后你会更依赖我了吧）[rhp]
[resetfont]
[:princess:][puri_w kao=5 hh=on ] 
「那！我先走啦。今天也要加油哦！」[rhp]

[:drop:][drop kao=13 ]
「嗯。一起加油吧！」[rhp]

[off_all]

[se storage="door_08.ogg"]
确认过多洛普的笑容后，我精神十足地奔向普通车厢。[rhp]

[:drop:][drop kao=1 ]
「………………嗯」[rhp]
[:drop:]
「太好了。看来能平安无事地度过。[rhr]
_　我不能给她增添负担啊」[rhp]

[off_all]

[:drop:]
「这样……就好了吧……」[rhp]

;****************************************
[set_b storage="train_04.jpg"]
;****************************************

[::]
被多洛普目送后，我前往了比客车和餐车更后方的卧铺车厢。[rhp]
[se storage="door_13.ogg"]
来到落合君房门前，敲了两下。[rhp]

[:princess:][puri_w kao=0 ]
「…………？」[rhp]

[off_puri]

[::]
没有回应。落合君也在睡觉吗？[rhp]
门锁……是开着的。[rhp]

[:princess:][puri_w kao=6 as=on ]
「……反正敲过门了。而且担心他是不是晕倒了……没关系吧」[rhp]

[off_puri]

[se storage="door_07.ogg"]

[::]
在心底默默道歉的同时，我轻轻推开了门。[rhp]

;****************************************
[bg_rule storage="train_09.jpg" rule="002.png" time=1500]
;****************************************

[fbgm]
　
[:princess:][puri_w kao=4 as=on ]
「………………诶？」[rhp]

[off_puri]

[::]
那里并没有落合君的身影。[rhp]
取而代之的是房间中央的桌上，放着一封信。[rhp]
走进房间拿起信，逐字阅读。[rhp]

[font color=0x696969]
『总有一天，我会再来』[rhp]
[resetfont]

[::]
只有事务性内容的简短信件。[rhr]
没有前言寒暄，索然无味的信。[rhp]
太过惊讶，心情难以平复。[rhp]

[:princess:][puri_w kao=3 as=on ]
「为什么……突然就……」[rhp]

[off_puri]

[:princess:]
「…………哎？」[rhp]

[::]
啪嗒一声，有水滴落在了地面上。[rhr]
仿佛不明白缘由般，竟像旁观者似的惊讶起来。[rhp]

;****************************************
[bg storage="black.jpg" time=1500]
;****************************************

………………为什么，我在哭呢。[rhp]

;-----------------------------------------------------------
;-----------------------------------------------------------
[jump storage="ev_a_08.ks" target="*start3"]
;-----------------------------------------------------------
;-----------------------------------------------------------

*start3

;ドロップ前半エンドフラグ
[eval exp="sf.a_d_end = 1"]

[mask time=2000]
[cancelskip]
[fbgm]

[iscript]
delete f.ev_a_02;
delete f.ev_a_03;
delete f.ev_a_04;
delete f.ev_a_05;
delete f.ev_a_06;
delete f.ev_a_07;
[endscript]

;フラグ初期設定
[iscript]
f.love_d = 0
f.love_k = 0
f.love_r = 0
f.love_h = 0
[endscript]

[jump storage="title.ks" target="*start_end"]

[s]