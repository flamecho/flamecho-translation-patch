﻿*start

;--------------------------------------------------------------------------------------------
;▼フルボイスセット▼
;はunknown=soraで反応
[voconfig sebuf=1 name=unknown vostorage="sora/full/{number}.ogg" number=38]
;--------------------------------------------------------------------------------------------

[set_b storage="train_08.jpg"]


没错，其实最近我开始在车长工作之外稍微帮点忙了。[rhp]
因为三位车长中有两位根本派不上用场，[rhr]
看不下去的我向多洛普毛遂自荐了自己的工作能力。[rhp]

[:princess:][puri_w kao=13 ]
[font color=0x4682b4]
（呵呵呵……！毕竟只当乘客的话也太说不过去了嘛）[rhp]
[:princess:]
（而且虽然刚开始不久，其实我还挺有自信的！）[rhp]
[resetfont]

[off_all]

[::]
昨天帮忙确认了快斗手推车的库存，前天检查了厨房食材，[rhr]
大前天整理了博士乱扔的书本……[rhp]

[:princess:][puri_w kao=8 as=on ]
「…………该不会是在处理麻烦精吧？」[rhp]

[off_all]

[::]
……不。不不不。怎么可能！[rhr]
他是看重我的能力才委托我的。[rhp]
绝对不是因为我在场会妨碍工作、让人分心，[rhr]
没有那种负面含义……应该。[rhp]

;-----------------------------------------------------------
;-----------------------------------------------------------

[if exp="sf.d_d_end == 1"]

[:princess:]
[font color=0x4682b4]
（不过要说贪心点的话……）[rhp]
[resetfont]

;-----------------------------------------------------------
#
;【ドロップ】
[glink clickse="btn_01.ogg" x="290" y="160" width="610" high="72" text="ドロップと一緒に仕事をしたい" target="*root_drop" graphic="glink_c.png" enterimg="glink_d.png"]
;【ソラ】
[glink clickse="btn_01.ogg" x="290" y="290" width="610" high="72" text="一人でも仕事出来るようになりたい" target="*root_sora" graphic="glink_a.png" enterimg="glink_b.png"]

[s]
;-----------------------------------------------------------

*root_sora

[eval exp="f.root_s = 1 "]

[:princess:]
[font color=0x4682b4]
（要是能独当一面地完成工作，[rhr]
_　多洛普的负担也能减轻些）[rhp]
[resetfont]

*root_drop

[:princess:]
[font color=0x4682b4]
（既想成为多洛普的助力，又渴望能和他共事）[rhp]
[resetfont]

[jump target="*root_tutti"]

[endif] 
;-----------------------------------------------------------
;-----------------------------------------------------------

[:princess:]
[font color=0x4682b4]
（不过要说贪心点的话……还是想和多洛普一起工作呢）[rhp]
[resetfont]

*root_tutti

[::]
虽说如此，我觉得多洛普不会把重要工作交给别人。[rhp]
总之现在先好好完成交给我的任务吧。[rhr]
正是这些细微的积累，才能逐渐赢得多洛普的信任！[rhp]

[:princess:][puri_w kao=13 ]
「好嘞！　一定要把哈蒂君制服上的开线缝好！！」[rhp]

[off_all]

[:yoru:][p_y_02][yoru kao=0 ]
「干劲十足呢」[rhp]

[:princess:][puri_w kao=4 ]
[font size=28]
「呀！！！！」[rhp]
[resetfont]

[:yoru:][yoru kao=12 ]
「在这非日常的世界里故意选择裁缝作为消遣。[rhr]
_　简直像是真正意义上在讴歌自由一般」[rhp]

[:princess:][puri_w kao=2 ]
「难得现身还是老样子阴阳怪气……[rhr]
_　我觉得最好不要突然站在别人背后哦？」[rhp]

[:yoru:][yoru kao=8 ]
「嘛，做什么都随心所欲便好。[rhr]
_　你并非随行人员而是乘客，就算游手好闲也无妨」[rhp]

[:princess:][puri_w kao=12 ]
「才不是游手好闲呢。这可是堂堂正正的列车长工作」[rhp]

[:yoru:][yoru kao=6 ]
「此言差矣。列车长的工作是铁道运营。[rhr]
_　你只是被当成麻烦推过来——」[rhp]

[:princess:][puri_w kao=2 as=on ss=on ]
「无所谓啦―！！！　就像店里手工拍打的汉堡肉一样！[rhr]
_　刻意用人力完成机械化作业才更有意义啦！！」[rhp]

[:yoru:][yoru kao=6 ]
「手工汉堡肉……」[rhp]

[:princess:][puri_w kao=13 ]
「要吃吗？」[rhp]

[:yoru:][yoru kao=0 ]
「不必」[rhp]

[:princess:][puri_w kao=1 ]
「哦是吗……所以？　来干嘛的？」[rhp]

; ev_dでの選択肢フラグ
[eval exp="f.branch_d_d = 1"]

[jump storage="ev_d.ks" target="*tutti"]

;****************************************

*start2

[:drop:][p_d_04][drop kao=1 ]
「……公主」[rhp]

[:princess:][puri_w kao=13 ]
「什么？」[rhp]

[:drop:][drop kao=13 ]
「最近承蒙你经常相助，实在感激不尽」[rhp]
[:drop:]
「作为列车长让乘客帮忙总觉得不太合适[rhr]
_　不过和人一起工作确实很开心呢」[rhp]

[:princess:][puri_w kao=4 ]
「………………」[rhp]

[:drop:][drop kao=1 ]
「那个？发生什么事了吗？」[rhp]

[:princess:][puri_w kao=1 ]
「就是……你看，我之前不是总缠着你嘛？[rhr]
_　还以为是被当成麻烦避开了，所以有点吃惊」[rhp]

[:drop:][p_d_22][drop kao=13 as=on ]
「咦、啊——……」[rhp]
[:drop:]
「…………不、哈哈哈」[rhp]

[:princess:][puri_w kao=2 as=on ]
[font color=0x4682b4]
（虽然确实有那么回事！！）[rhp]
[resetfont]

[:drop:][drop kao=1 ]
「……抱歉。并不是把你当麻烦的意思」[rhp]
[:drop:]
「没让你参与和我搭档的工作，[rhr]
_　是出于对你的考虑。并不是你的错」[rhp]

[:princess:][puri_w kao=3 ]
「为我考虑……？」[rhp]

[:drop:][p_d_31][drop kao=11 ]
「如你所见，我是个无趣的人。[rhr]
_　不想让你感到乏味」[rhp]

[:princess:][puri_w kao=4 as=on ]
「才没有！怎么可能觉得乏味啊。[rhr]
_　我想了解更多关于多洛普的事，想和你变得更要好」[rhp]
[:princess:]
「和讨厌的人相处另当别论，我可是喜欢多洛普的」[rhp]

[:drop:][p_d_19][drop kao=4 ]
「诶……」[rhp]

[:princess:][puri_w kao=2 as=on hh=on ]
「……！啊……不、不是。喜欢不是那个意思啦？[rhr]
_　作为朋友，作为同伴的……那种喜欢……」[rhp]
[:princess:]
「……？奇怪……」[rhp]

[:drop:][drop kao=3 ]
「公主……」[rhp]

[:princess:][puri_w kao=1 ]
「……、没。……没什么……」[rhp]

[off_all]

[::]
……好奇怪。为什么胸口有点疼。[rhr]
感觉就像在说谎时的心情一样。[rhp]
……谎言？刚才我说的话，是在说谎吗？[rhr]
不，不会吧。因为我并不是作为男孩子喜欢多洛普的。[rhp]
…………明明应该一次都没有这样想过。[rhp]

[chara_part name="drop" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=13 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「…………抱歉！好像让气氛变得有点奇怪了」[rhp]

[:drop:][drop kao=1 ]
「没……没关系」[rhp]

[:princess:][puri_w kao=14 ]
「好啦好啦，赶紧开始打扫吧！[rhr]
_  想把落合君以最好的状态迎进来！」[rhp]
[:princess:]
「好，该从哪里开始？擦窗户之类的？我什么都愿意做！」[rhp]

[:drop:][p_d_17][drop kao=7 ]
「…………呃…………」[rhp]
[:drop:][drop kao=12 ]
「…………好的。那就拜托你了」[rhp]

;****************************************
[set_xx graphic="rule/krke_d.png" storage="train_02.jpg"]
;****************************************

[::]
完成大致打扫后，我们稍作休息。[rhp]
坐在包厢座位里，用手轻轻揉着疲惫的肩膀和腰时，[rhr]
多洛普端着放有两个杯子的托盘走了过来。[rhp]

[:drop:][drop kao=1 ]
「辛苦了公主。[rhr]
_  泡了可可，要喝吗？」[rhp]

[:princess:][puri_w kao=13 ]
「谢谢！正好想喝点什么」[rhp]

[:drop:][drop kao=14 ]
「那太好了。请用」[rhp]

[off_all]

[::]
接过多洛普递来的马克杯后，[rhr]
他也在我斜对面坐了下来。[rhp]
仔细想想还真是罕见的场景啊。[rhr]
多洛普正坐在座位上休息。[rhp]
一边想着这些事，一边啜饮多洛普给我的可可。[rhp]

[chara_part name="drop" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=11 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「好好喝！」[rhp]

[:drop:][p_d_07][drop kao=5 ]
「呵呵，谢谢夸奖」[rhp]

[:princess:][puri_w kao=12 ]
「每次我都在想，为什么别人做的东西[rhr]
_　比自己做的感觉更美味呢？」[rhp]

[:drop:][drop kao=11 ]
「唔……可能是因为饱含心意吧」[rhp]

[:princess:][puri_w kao=1 ]
「原来如此。所以多洛普做的饭菜总是特别好吃。[rhr]
_　没谁能像多洛普这样处处为大家着想了」[rhp]

[:drop:][p_d_06][drop kao=13 as=on ]
「啊、哈哈……虽然是自己说的话，还是有点不好意思呢」[rhp]

[off_all]

[::]
多洛普腼腆地笑了笑。[rhr]
……总觉得他比平时少了些精气神，是错觉吗？[rhp]

[chara_part name="drop" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=6 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「多洛普，该不会其实很累吧？」[rhp]

[:drop:][drop kao=4 ]
「咦？为什么这么问？」[rhp]

[:princess:]
「嗯，就是觉得你好像没什么精神」[rhp]

[:drop:][drop kao=1 ]
「没这回事哦。我随时都活力满满的！」[rhp]

[:princess:][puri_w kao=6 ]
「……真的？」[rhp]

[:drop:][drop kao=13 ]
「当然。只是稍微有点紧张而已」[rhp]

[:princess:][puri_w kao=4 ]
「咦？紧张？」[rhp]

[:drop:][drop kao=3 as=on ]
「……啊，那个」[rhp]

[off_all]

[::]
……今天的多洛普总觉得有点不对劲。[rhr]
罕见地心不在焉，仿佛魂魄不在此处。[rhp]
连现在的反应也令人捉摸不透。[rhr]
他究竟在为什么事紧张呢？[rhp]
要说接下来预定的事，也就只有落合君的事了。[rhp]

[:princess:]
[font color=0x4682b4]
（要去见落合君所以紧张？怎么可能……）[rhp]
[resetfont]

[:drop:][p_d_04][drop kao=2 ]
「您是在想落合的事对吧」[rhp]

[:princess:][puri_w kao=8 as=on ]
「！！　啊、不是」[rhp]

[:drop:][drop kao=0 ]
「不用隐瞒。因为除此之外别无他事」[rhp]

[:princess:]
「嘛、虽然是这么回事……但也不至于吧？又没什么理由」[rhp]
[:princess:]
「毕竟和落合君在之前的旅途中[rhr]
_　已经说过很多话了，没有紧张的理由……」[rhp]

[:drop:][p_d_32][drop kao=3 ]
「……是我唐突了。[rhr]
_　这种事本不该在各位面前说出来的」[rhp]

[:princess:][puri_w kao=0 ]
「多洛普……？」[rhp]

[off_puri]

[:drop:][drop kao=3 ]
「公主。……那个，冒昧恳求实在抱歉……」[rhp]
[:drop:]
「……能否稍微给我一点时间？」[rhp]

;****************************************
;車体の上
[set_n storage="train_10.jpg"]
;****************************************

[::]
被多洛普带来的是铁道屋顶上。[rhp]

[:princess:][puri_w kao=4 ]
「好厉害……！原来这里能爬上来啊！」[rhp]

[:drop:][p_d_02][drop kao=5 ]
「是的。因危险平日不开放，但今天破例。[rhr]
_　请注意别摔下去」[rhp]

[:princess:][puri_w kao=13 ]
「明白。谢谢」[rhp]

[off_all]

[::]
不过这样的景色在这趟旅途中也是头一次见。[rhr]
虽想欢呼雀跃，还是忍住冲动小心行走吧。[rhp]
――――――闭上眼。舒爽的微风拂过。[rhp]
虽不确定能否称之为夜风，[rhr]
轻抚脸颊的凉爽微风仿佛在治愈疲惫的身躯[rhp]

[:princess:][puri_w kao=1 ]
「所以？这种场合要谈什么？」[rhp]

[:drop:][p_d_04][drop kao=13 ]
「那个……想向公主重新道谢」[rhp]

[:princess:]
「道谢？」[rhp]

[off_all]

[::]
在说什么呢？是指帮忙打扫的事吗？[rhr]
但那种事本就不值得特地选在这种地方致谢[rhp]
正当我歪头思索时 多洛普轻声笑了[rhp]

[:drop:][drop kao=1 ]
「公主。这趟旅程愉快吗？」[rhp]

[:princess:][puri_w kao=13 ]
「？嗯　超级开心哦！」[rhp]
[:princess:]
「不仅每次的目的地 沿途的风景也是[rhr]
_　全都让人开心得不得了呢」[rhp]

[:drop:][drop kao=13 ]
「是吗。那就好」[rhp]

[:princess:][puri_w kao=1 ]
「多洛普呢？享受旅途吗？」[rhp]

[:drop:][p_d_07]
「嗯。托你的福」[rhp]

[:princess:][puri_w kao=14 ]
「……！呵呵　这样啊！」[rhp]

[off_all]

[::]
多洛普始终没舍弃列车员的身份[rhr]
看起来并未像我们这样以平等视角享受旅程[rhp]
但如今能听到他这么说[rhr]
或许意味着他也多少有所改变了吧[rhp]

[chara_part name="drop" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=13 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「多洛普。以后也继续旅行吧[rhr]
_　不是作为列车员 而是作为多洛普去更多地方」[rhp]
[:princess:]
「列车员多洛普固然优秀又帅气[rhr]
_　但我更喜欢祭典时 陪我并肩同行的那个多洛普哦」[rhp]

[:drop:][p_d_32][drop kao=11 as=on ]
「啊、啊哈哈……那时候有点[rhr]
_　玩过头了。好难为情」[rhp]

[:princess:][puri_w kao=13 ]
「才没有那回事！[rhr]
_　大家肯定也都想一起开心的啦」[rhp]

[:drop:][drop kao=1 ]
「是这样吗……。[rhr]
_　……不过真的、那个祭典很开心呢」[rhp]

[:princess:][puri_w kao=13 ]
「都是多亏了落合君」[rhp]

[:drop:][drop kao=5 ]
「也有你强硬邀约的缘故哦」[rhp]

[:princess:][puri_w kao=5 as=on ]
「诶」[rhp]

[:drop:][p_d_31][drop kao=13 ]
「是表达开心的意思啦」[rhp]
[:drop:][drop kao=1 ]
「…………、所以今天想为那件事道谢」[rhp]

[:princess:][puri_w kao=6 ]
「不用道谢啦。[rhr]
_　想和伙伴一起开心是理所当然的事嘛」[rhp]

[:drop:][drop kao=1 ]
「不。……那时候的事、对我来说是重大转折点」[rhp]
[:drop:]
「当然至今为止的旅程、我也非常愉快。[rhr]
_　为了让大家度过幸福日常的协助工作非常充实」[rhp]
[:drop:]
「但偶尔忘记立场也没关系。[rhr]
_　要是能更早点、体验那种快乐方式就好了」[rhp]
[:drop:][drop kao=13 ]
「并非对过去的自己感到后悔……[rhr]
_　多亏有你、我才能成为会这样思考的自己」[rhp]

[:princess:][puri_w kao=1 ]
「多洛普……」[rhp]

[:drop:][p_d_07]
「若非你当时牵着我的手、[rhr]
_　我可能永远都不会知晓那份心动吧」[rhp]
[:drop:]
「谢谢你、公主。[rhr]
_　让我看到了与你相同的景色」[rhp]

[:princess:][puri_w kao=1]
「…………嗯、嗯」[rhp]

[off_all]

[::]
―――不知为何。[rhp]
明明是被感谢着，本该坦然回句不客气的。[rhp]

[:princess:]
[font color=0x4682b4]
（为什么啊……）[rhp]
[resetfont]

[::]
这是……心慌？[rhr]
始终萦绕着不寻常的预感。[rhp]
多洛普郑重的道谢，听起来简直像离别赠言。[rhp]

[fbgm]

[:drop:][drop kao=0 ]
「…………公主」[rhp]

[bgm storage="bgm_15.ogg"]

[:drop:][drop kao=12 ]
「事到如今，有句话想告诉你。[rhr]
_　……因为害怕意识到，一直没能说出口」[rhp]
[:drop:][drop kao=13 ]
「…………可能是最后一次了，所以想说给你听」[rhp]

[off_all]

[::]
最后一次是什么意思？明明旅程还要继续的。[rhp]
不要。我不想听。[rhp]
当我用双手捂住耳朵，不自觉地闭上眼睛时。[rhp]

[se storage="se2_08.ogg"]

;****************************************
[fbgm]
[bg storage="black.jpg" time=500]
;****************************************

―――一阵剧烈到能穿透掌心的、不自然的声响骤然回荡。[rhp]

;****************************************
;スチル
[still storage="cg/d_d1_1.png" rule="007.png" width="1280" height="720" time=500]
[cg storage="cg/d_d1_1.png"]
;****************************************

[bgm storage="bgm_10.ogg"]

[:drop:]
「……………………哎」[rhp]

[::]
多洛普的身体，正在变得透明。[rhp]
不，…………正被抹去存在。[rhp]
仿佛与夜空同化般，透过他的身躯，[rhr]
能望见对面的银河。[rhp]

[:princess:]
「多、多洛普……！？你的身体怎么了！？为什么透明了―――」[rhp]

[:drop:][p_d_14]
「原来如此……」[rhp]
[:drop:]
「…………真是毫不留情啊。那位大人」[rhp]

[:princess:]
「！　难道你知道些什么！？[rhr]
_　要怎样才能恢复原状？　求你了！」[rhp]

[:drop:]
「请放心公主。请保持冷静」[rhp]
[:drop:]
「比起这个，能否继续刚才的话题……」[rhp]

;****************************************
[still_end frame="win.png" storage="train_10.jpg" time=100]
;****************************************
;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
[vostart]
;--------------------------------------------------------------------------------------------

[:unknown:]
「吵死了」[rhp]

[::]
从背后突然响起的低沉声音。[rhr]
给人的感觉不同，但总觉得在哪里听过……[rhp]

;****************************************
;スチル
[still storage="cg/d_d1_2.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/d_d1_2.png"]
;****************************************

…………说不出话来。[rhp]

[:princess:]
「为、为什么……」[rhp]

[::]
……有两个多洛普？[rhp]

[:unknown:]
「……哇靠，什么情况」[rhp]
[:unknown:]
「虽说状态不佳，这也太离谱了。工作太敷衍……[rhr]
_　差点就要消失了」[rhp]
[:unknown:]
「…………算了，无所谓」[rhp]

;****************************************
[still_end frame="win.png" storage="black.jpg"]
;****************************************

[::]
他说完打了个响指，刹那间四周被黑暗笼罩。[rhp]

;****************************************
[bg storage="train_10.jpg" time=500]
;****************************************

当视野再次恢复时，[rhr]
正想转身确认安危，却受到更大冲击。[rhp]

[:princess:]
「咦……多洛普！？　你去哪了！？」[rhp]

[off_all]

[::]
环顾四周，哪里都找不到他的身影。[rhr]
刚才身体变透明就是这个预兆吗？[rhp]

;****************************************
;スチル
[still storage="cg/d_d1_2b.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/d_d1_2b.png"]
;****************************************

那么，眼前这个像多洛普的人是……[rhp]

[:unknown:]
「哼，也就这种程度吧。[rhr]
_　不愧是我，做什么都能完美驾驭」[rhp]
[:unknown:]
「那个只会死认真的『前任』多洛普，可做不到这种程度啊」[rhp]

[:princess:]
「你、是谁……！？」[rhp]

[:unknown:]
「…………哈？」[rhp]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

[::]
带着疑惑的脸转向这边。[rhr]
多洛普绝不会露出那种表情。[rhp]

[:princess:]
「你对多洛普的身体做了什么？你到底是……！」[rhp]

;****************************************
;スチル終了
[still_end frame="win.png" storage="train_10.jpg" time=1000]
;****************************************

[:sora:][sora kao=6 ]
「是宙」[rhp]

[::]
青年像切断话题般干脆地纠正道。[rhr]
锐利冰冷的眼睛直盯着这里。[rhp]
……好可怕。明明和多洛普有着同样的脸，却像完全另一个人。[rhp]

[:princess:][puri_w kao=2 as=on ]
「宙……那个……」[rhp]

[:sora:]
「不记得了？是落合宙啦」[rhp]
[:sora:]
「前阵子承蒙关照」[rhp]

[:princess:]
「啊……？」[rhp]

[:sora:][sora kao=12 ]
「『落合』这个姓已经废了。一直觉得怪恶心的」[rhp]

;****************************************
[set_kk storage="train_01.jpg" time=500]
;****************************************

[:kite:]
[font color=0x696969]
『――――――宙！！为什么你在这里！？』[rhp]
[resetfont]

;****************************************
[set_ff storage="train_10.jpg" time=500]
[filter_n]
;****************************************

[chara_part name="sora" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=8 as=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「难、难道……落合君……！？」[rhp]

[:sora:][sora kao=6 ]
「干嘛这么惊讶？　[rhr]
_　夜应该早告诉过你我快回来的事，」[rhp]

[:princess:][puri_w kao=7 ]
「多洛普在哪！？」[rhp]

[:sora:][sora kao=4 ]
「…………！」[rhp]

[:princess:][puri_w kao=3 as=on ]
「从刚才开始就完全消失了，到底跑哪去了？[rhr]
_　先解释这个！」[rhp]

[:sora:][sora kao=2 ]
「………………」[rhp]

[:princess:]
「你知道些什么吧？这身打扮是怎么回事？[rhr]
_　啊啊真是的，该从哪问起……！」[rhp]

[:sora:][sora kao=12 ]
「已经不在了」[rhp]

[:princess:][puri_w kao=2 as=on ]
「嗯？」[rhp]

[:sora:]
「那家伙是我的冒牌货。所以消失了」[rhp]

[:princess:]
「冒、冒牌货……？消失了是，什么意思？」[rhp]

[:sora:][sora kao=2 ]
「那家伙从我这里夺走了一切。[rhr]
_　朋友也好，渴望的现实也好，全都在那家伙手里」[rhp]
[:sora:]
「所以我把一切都夺回来了。仅此而已」[rhp]
[:sora:]
「这条铁道的列车长，我更适合当」[rhp]

[:princess:][puri_w kao=6 as=on ]
「什……什么，胡说……八……」[rhp]

[off_all]

[yurasu]

;倒れる音
[se storage="hand_05.ogg"]

;****************************************
#
[bg storage="black.jpg" time=1000]
;****************************************

[:sora:]
「……！？喂、喂！」[rhp]

[off_all]

[::]
仿佛全身力气都被抽走，我当场倒下了。[rhr]
混乱与冲击让思维无法跟上，甚至感到恶心。[rhp]
头痛。心苦。[rhr]
甚至觉得干脆睡着更轻松。[rhp]

……就这么办吧。[rhr]
醒来之后，一切肯定都会化为梦境――――――……[rhp]

[fbgm]

;-----------------------------------------------------------
;-----------------------------------------------------------

[jump storage="ev_d.ks" target="*tutti4"]

;-----------------------------------------------------------
;-----------------------------------------------------------
*start3
;-----------------------------------------------------------
;-----------------------------------------------------------

;****************************************
[fbgm]
[set_b storage="train_01.jpg"]
[bgm storage="bgm_01.ogg"]
[free_filter ]
;****************************************

[chara_part name="sora" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:sora:][p_so_04]
「哟和近。有空吗？」[rhp]

[:kite:][p_k_05]
「哈啊。算是……有空的但怎么了」[rhp]

[:sora:][sora kao=13 ]
「要不要让魔太郎子继承草薙流古武术？」[rhp]

[:kite:][kite kao=2 as=on ]
「…………。这提议有点意思啊」[rhp]

[off_all]

[:mataroko:][p_mt_21][mata kao=2 as=on ]
「才没意思呢！！[rhr]
_　宙先生真是的，居然让人家学习不符少女形象的格斗技……」[rhp]

[off_all]

[:sora:][sora kao=13 ]
「一刹背负投」[rhp]

[off_all]

;****************************************
#
[se storage="hand_06.ogg"]
;スチル
[bg storage="cg/d_d1_3.png" rule="021.png" width="1280" height="720" time=300]
[cg storage="cg/d_d1_3.png"]
;****************************************

[:mataroko:]
「啊啊啊啊！！！！」[rhp]

;****************************************
#
[bg storage="train_01.jpg" time=300]
;****************************************

[:mataroko:][mata kao=3 as=on hh=on ]
「身体……身体自己动起来了……」[rhp]

[off_all]

[chara_part name="sora" body=base kao=11 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="gon" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:sora:]
「魔太郎子是已经完成了呢。接下来是努西吗」[rhp]

[:gonzalez:]
「我！？　难得叫我来一次也让我...」[rhp]

[:sora:][sora kao=13 ]
「那我去找一下」[rhp]

[off_all]

[:gonzalez:][gon kao=6 as=on ]
「喂——！我呢！？ 我可不甘心再做挨揍的角色了！」[rhp]

[off_all]

[:kite:][kite kao=2 as=on ]
「那家伙...自从再次来到这边后突然变得调皮了呢...[rhr]
_　连召唤三人组到铁道这种绝技都学会了......是夜的力量吗？」[rhp]

[:mataroko:][mata kao=3 as=on ]
「呜...呜...！　救救我啊快斗先生...！[rhr]
_　再这样下去魔太郎子会变成没有意志的杀人傀儡......」[rhp]

[:kite:][kite kao=0 ]
「………………」[rhp]
[:kite:][kite kao=7 ]
「…………一刹背负投」[rhp]

[off_all]

;****************************************
#
[se storage="hand_06.ogg"]
;スチル
[bg storage="cg/d_d1_3b.png" rule="021.png" width="1280" height="720" time=300]
[cg storage="cg/d_d1_3b.png"]
;****************************************

[:mataroko:]
「啊啊啊啊！！！！」[rhp]

;****************************************
#
[bg storage="train_01.jpg" time=300]
;****************************************

[chara_part name="mata" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:kite:]
「糟。这也太好笑了」[rhp]

[:mataroko:]
「真是的！我才不是为了这种事而来的呀～！？」[rhp]

[off_all]

[:princess:][puri_w kao=3 ]
「………………呼」[rhp]

[off_all]

[::]
自从多洛普的内芯变成落合君已经过去数日。[rhp]
他对我们的劝说依然置若罔闻，[rhr]
似乎正悠然自得地享受着旅途。[rhp]
若是完全不做多洛普的工作倒还有破绽可寻，[rhr]
但他却以和多洛普完全相同的方式，出色地完成了所有工作。[rhp]
而且看起来...比多洛普还要乐在其中。[rhp]
大家也渐渐适应了这种状况，[rhr]
看起来正在逐步接纳他的存在。[rhp]
现在的落合君和多洛普，[rhr]
即便面部构造相同，内在却完全是不同的人。[rhp]
即便如此，这样的事……[rhp]

[:mataroko:][p_mt_19][mata kao=13 ]
「哎呀，姐姐大人？您要去哪里呢？」[rhp]

[:princess:][puri_w kao=3 ]
「去博士那里。[rhr]
_　再去询问解除小努西古武术催眠的方法哦」[rhp]

[:mataroko:][mata kao=6 as=on ]
「务必请您帮忙了呜！[rhr]
_　否则她会变成可爱过头的杀戮兵器的！」[rhp]

[off_all]

[:gonzalez:][gon kao=2 as=on ]
[font color=0x4682b4]
（稍微提升了下等级……）[rhp]
[resetfont]

[off_all]

[:sora:][sora kao=0 ]
「…………………啧」[rhp]

[:kite:][kite kao=0 ]
「咦，你还在这儿啊。不去找小努西了吗？」[rhp]

[:sora:][sora kao=2 ]
「……突然没兴致了。现在比起那个，」[rhp]

[:kite:][kite kao=12 ]
「或许不追上去比较好」[rhp]

[:sora:][sora kao=2 ]
「哈？」[rhp]

[:kite:]
「公主不高兴的原因，可正是因为你呀」[rhp]

[off_all]

[:sora:][sora kao=2 ]
「多谢多余的忠告。那我先走一步了」[rhp]

[off_all]

[chara_part name="mata" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="gon" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:mataroko:][p_mt_30]
「唉呀……还是走了呢」[rhp]

[:gonzalez:][gon kao=0 as=on]
「那家伙也是够呛啊」[rhp]

[off_all]

[:kite:][kite kao=2 as=on ]
「哈……这算什么事啊。感觉全都乱成一团了」[rhp]
[:kite:]
「……我觉得我们之间，应该没这么复杂的关系才对」[rhp]

[off_all]

;****************************************
[set_b storage="train_04.jpg"]
;****************************************
[fbgm]

[::]
…………只有我会这样想吗。[rhr]
多洛普不在身边，竟会如此寂寞。[rhp]
明明顶着相同的脸，却完全看不出是多洛普，是不是我太奇怪了。[rhp]
与发色无关。[rhr]
并非服装的缘故。[rhp]
我啊，如果不是那个多洛普的话就讨厌。[rhp]

[:princess:]
[font color=0x4682b4]
（要习惯什么的……绝对不要啊……）[rhp]
[resetfont]

[off_all]

[bgm storage="bgm_12.ogg"]

[:sora:][p_so_09][sora kao=2 ]
「……喂！公主」[rhp]

[:princess:][puri_w kao=3 ]
「落合君……」[rhp]

[:sora:][sora kao=0 ]
「都说了是宙了吧」[rhp]

[:princess:][puri_w kao=2 ]
「……找我有什么事？落合君」[rhp]

[:sora:][sora kao=2 ]
「……哼、啊啊是啊。说到底还是要划清界限啊」[rhp]
[:sora:]
「那就告诉我吧。[rhr]
_　你究竟看不惯我哪一点？」[rhp]

[:princess:][puri_w kao=8 ]
「……哪一点……这种事，不说就不明白吗？」[rhp]
[:princess:]
「因为你毫无理由地把多洛普弄丢了啊。[rhr]
_　多洛普可是我重要的――――――」[rhp]

[off_all]

[::]
话到嘴边，突然语塞。害怕继续说下去。[rhp]
……不知为何，对宙君说出口会感到犹豫。为什么……[rhp]

[:sora:][p_so_11][sora kao=6 ]
「我是来见你的。[rhr]
_　可你总是这副表情，简直就像……」[rhp]

[:princess:][puri_w kao=0 ]
「……唔、落合君能再来见我，我很开心。[rhr]
_　但那不能成为消除多洛普的理由啊」[rhp]
[:princess:]
「多洛普也一定很想见到你……！[rhr]
_　我早知道你会来，所以拼命打扫了呢！」[rhp]

[:sora:][sora kao=3 ]
「……！　多洛普他……怎么可能。[rhr]
_　倒不如说那家伙根本不愿见到我来」[rhp]

[:princess:][puri_w kao=2 ]
「为什么要说这种话！[rhr]
_　你根本不懂多洛普的……」[rhp]

[:sora:][sora kao=0 ]
「这话该我说。你又懂多洛普什么？」[rhp]
[:sora:][p_so_16][sora kao=12 ]
「我知晓多洛普的一切。[rhr]
_　这世上没人比我更了解。正因如此才能断言」[rhp]
[:sora:]
「若我是多洛普，绝不会欢迎现在的我」[rhp]

[:princess:][puri_w kao=2 ]
「呜……！　那又怎样！？[rhr]
_　可你现在是落合君，又不是多洛普啊！」[rhp]

[:sora:][sora kao=8 ]
「…………！」[rhp]

[:princess:][puri_w kao=3 ]
「要怎样才能让多洛普回来？[rhr]
_　这太奇怪了。没有多洛普在，就算继续旅行也……」[rhp]

[:sora:][p_so_12][sora kao=3 ]
「…………可恶」[rhp]

[:princess:][puri_w kao=0 as=on ]
「！」[rhp]

[:sora:][p_so_10][sora kao=7 ]
「一个两个都满口多洛普多洛普的……真搞不懂。[rhr]
_　为什么比起真正的我，你们都要选择那个冒牌货」[rhp]
[:sora:]
「……你以为我怀着怎样的心情才走到今天！」[rhp]

[off_sora]

[:princess:][puri_w kao=4 as=on ]
「落合君！」[rhp]

[off_all]

[::]
未能及阻止，落合君已施展魔法随光芒消失了。[rhp]
……倘若他没有使用魔法而是转身逃离，[rhr]
我是否会追上去呢。[rhp]
不知道。……无法断言。[rhr]
无论如何都无法原谅把多洛普消除掉这件事。[rhp]

[:princess:][puri_w kao=3 ]
「…………搞什么啊，真是的……」[rhp]

[off_all]

;****************************************
#
[bg_b storage="train_06.jpg"]
;****************************************

与公主的争吵让我难以忍受，[rhr]
我匆忙用魔法离开现场，垂头丧气地坐在乘务员室的椅子上。[rhp]
会变成这样全都是因为[player2]失去了记忆。[rhp]

[:sora:]
[font color=0x4682b4]
（到底怎么回事啊。多洛普多洛普的……明明现在已经不在了。[rhr]
_　这里的乘务长现在应该是我而不是多洛普吧）[rhp]
[:sora:]
（其他家伙们都知道多洛普是人偶，或许是察觉到了现状[rhr]
_　现在甚至已经习惯了……肯定早就放弃了吧）[rhp]
[:sora:]
（……果然还是应该先想办法[rhr]
_　哪怕强行也要让公主恢复记忆？）[rhp]
[:sora:]
（但是该怎么做。连夜的魔法都无法抗衡南的……）[rhp]
[resetfont]

[:sausu:][sausu kao=13 ]
「气消了吗？」[rhp]

[:sora:][p_so_30][sora kao=2 ]
「……！是你……南吗」[rhp]

[:sausu:][p_s_35][sausu kao=1 ]
「初次见面吧。宙。欢迎来到我的宝石箱」[rhp]

[:sora:][p_so_19][sora kao=6 ]
「少说欢迎。反正你也不是真心想招待我」[rhp]

[:sausu:][sausu kao=13 ]
「没这回事。我对谁都欢迎哦」[rhp]

[:sora:][sora kao=6 ]
「真欢迎的话上次来访时就会打招呼了。[rhr]
_　我可是听说你是个特别自来熟的男人」[rhp]
[:sora:]
「你不满意约尔的指使吗？」[rhp]

[:sausu:][p_s_32][sausu kao=12 as=on ]
「哈哈……这话可真严厉啊。[rhr]
_　毕竟贸然插手，被约尔大人的计策牵连就麻烦了呢」[rhp]

[:sora:][sora kao=7 ]
「真是谨慎得令人恶心」[rhp]

[:sausu:][sausu kao=1 ]
「现在的孩子说话可真刻薄啊……算了」[rhp]
[:sausu:]
「……问候来迟了。上次旅途愉快吗？」[rhp]

[:sora:][p_so_09][sora kao=2 ]
「废话少说。只要告诉我为何出现在我面前就行」[rhp]
[:sora:]
「事先声明，关于多洛普的投诉我一概不受理」[rhp]

[:sausu:][sausu kao=7 ]
「嗯…………确实多洛普的事让我震惊」[rhp]
[:sausu:]
「不过他似乎早有觉悟」[rhp]

[:sora:][sora kao=2 ]
「啊……？」[rhp]

[:sausu:][p_s_01][sausu kao=3 ]
「连我也不禁问了多洛普这样真的好吗。[rhr]
_　他完全不怨恨你。所以我也不会对你发火」[rhp]

[:sora:][p_so_21][sora kao=2 as=on ]
「等、等等！」[rhp]

[:sausu:][sausu kao=5 ]
「嗯？」[rhp]

[:sora:][sora kao=3 as=on ]
「说什么问过多洛普……根本没那个机会吧。[rhr]
_　我连约尔都骗过了。你不可能事先察觉……」[rhp]
[:sora:]
「…………！」[rhp]

[:sausu:][sausu kao=0 ]
「看到了哦，你的血字涂鸦。[rhr]
_　真是够胆大妄为的……不过，不是挺好的吗」[rhp]
[:sausu:]
「多洛普＝宙。如你所愿了呢」[rhp]

[off_all]

;****************************************
#
[bg storage="black.jpg" time=500]
;****************************************
[fbgm]

[:sausu:]
「……就是这么回事」[rhp]
[:sausu:]
「就在刚才那边的世界里，『多洛普』变成了『宙』」[rhp]

;****************************************
[s_mask color=0xffffff time=3000]
; 背景表示
[bg storage="hsps_08u.jpg" time=100]
; 夜フィルター
[filter layer="1" brightness="60"]
; ウィンドゥの設定
[position layer="message0" frame="win2.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[s_mask_off time=3000]

[bgm storage="bgm_27.ogg"]
;****************************************

;現代病室
;体がソラなので立ち絵は[sora]を使ってます。

[::]
――――――我还以为是被夜幕吞噬了呢。[rhp]

回过神来时，我正躺在陌生的床铺上。[rhp]
试着缓缓撑起身体。四肢......活动起来毫无障碍。[rhr]
环顾四周，不时掠过视线的未曾见过的衣物。[rhr]
这难以名状的陌生空气感。[rhp]
倒也没有特别不适，我便从床铺下来站起身，[rhr]
重新仔细环视整个房间。[rhp]

[:drop:]
[font color=0x4682b4]
（......真是奇妙的地方......）[rhp]
[resetfont]

[::]
由于出身特殊，仅作为知识知晓的这间临终关怀院。[rhr]
实际目睹时却感到一切都很新鲜，实在不可思议。[rhp]
室内家具虽然情趣相异，功能上倒觉得没太大差别。[rhr]
与『那边』最显著的不同，终究还是外界吧。[rhp]
从窗户倾泻而入的光。[rhr]
由此望见的，遥远苍穹。[rhp]
在旅途的星球上从未有过这般感受，[rhr]
一想到是再也无法抵达之处，就莫名觉得格外特别。[rhp]

[:yoru:][p_y_04][yoru kao=0 ]
「看来你醒了」[rhp]

[::]
突然听见背后传来声音，我转头回望。[rhr]
站在那里的是那个世界原本的主人——糠星夜。[rhp]
我在那边世界时，从某个时期开始就一直能感受到他的气息，[rhr]
不知何时已经回到这边来了吗？[rhp]

[off_all]

疑问暂且搁置，我向他轻轻点头致意。[rhp]
虽然交情不深，但关于这个人的唠叨与一丝不苟，[rhr]
已从创造者南先生那里有所耳闻。[rhp]

[chara_part name="sora" body=prain kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:drop:][p_d_35]
「好久不见，夜。看来你一切如常」[rhp]
[:drop:]
「……那个，我在这里躺了多久？」[rhp]

[:yoru:][p_y_15][yoru kao=12 ]
「沉睡了一周。[rhr]
_　果然不同的精神要适应不同的肉体需要时间」[rhp]

[:drop:][p_d_34][sora body=prain kao=8 as=on ]
「这样啊……让您担心实在抱歉」[rhp]

[:yoru:][yoru kao=8 ]
「……倒是镇定。看来你已经清楚自己的处境了」[rhp]

[:drop:][sora body=prain kao=1 ]
「嗯这个……虽然很吃惊，不过该说很有他的风格吧。[rhr]
_　宙先生想取代我这件事，也是可以想象的」[rhp]

[:yoru:][p_y_11][yoru kao=0 ]
「如此任性的行径，你能原谅吗？[rhr]
_　你明明在那个世界找到了生存的意义和喜悦」[rhp]

[:drop:][p_d_22][sora body=prain kao=13 ]
「是啊……但这是无可奈何的事。我的存在意义，[rhr]
_　本就是填补来到那条铁道的各位内心的空洞」[rhp]
[:drop:]
「如果是本尊来了的话，他肯定比您更适合当队友」[rhp]

[:yoru:][yoru kao=7 ]
「你能原谅宙的自私行为吗」[rhp]

[:drop:][sora body=prain kao=8 ]
「这是使命所在」[rhp]

[:yoru:][p_y_04][yoru kao=2 ]
「至今和他们一起旅行的不是宙，而是你」[rhp]

[:drop:][p_d_02][sora body=prain kao=13 ]
「我心知肚明」[rhp]
[:drop:]
「……前几日将宙先生送去那个世界的人，是您吧」[rhp]

[:yoru:][p_y_01][yoru kao=2 ]
「是啊。……我还试着替不能行动的武做了人偶，[rhr]
_　但总是徒劳无功，本想着能补充战力」[rhp]
[:yoru:]
「一切都是我思虑不周。[rhr]
_　……被背叛也是理所当然」[rhp]

[:drop:][sora body=prain kao=8 ]
「那这次为何要重蹈覆辙？」[rhp]

[:yoru:][p_y_31][yoru kao=0 ]
「我把那家伙弄成假死状态，谎称实现了他的求死愿望。[rhr]
_　若不这样做，不知他会干出什么事来」[rhp]
[:yoru:]
「若他在我无法触及的地方……比如家里死了就糟透了。[rhr]
_　要保住他性命只能如此」[rhp]
[:yoru:]
「这就是让做梦者哪怕片刻沉浸幻象必须承担的责任」[rhp]

[:drop:][sora body=prain kao=7 ]
「原来如此……」[rhp]

[:yoru:][yoru kao=3 ]
「剥夺你的容身之处我很抱歉。[rhr]
_　等那家伙气消了，我会揭穿这个谎言让他回来」[rhp]
[:yoru:]
「在那之前若能请你代为维持宙的身体就帮大忙了」[rhp]

[:drop:][p_d_01][sora body=prain kao=13 ]
「……嗯、当然。只要是我能胜任的、很乐意提供协助」[rhp]
[:drop:]
「我从诞生之日起就明白宙先生对我的羡慕。[rhr]
_　早已做好某天会变成这样的觉悟。请不必担心」[rhp]
[:drop:]
「大家的笑容与感谢话语。那就是我的……」[rhp]
[:drop:][sora body=prain kao=3 ]
「………………、我的……」[rhp]

[:yoru:][yoru kao=0 ]
「多洛普？」[rhp]

[off_all]

[::]
不知为何。话语哽在喉间。[rhr]
…………难不成现在的我、正在感到寂寞吗？[rhp]
难道这个结局、并非我的本意？[rhp]

[:yoru:][yoru kao=6 ]
「……会尽快解决。暂且忍耐」[rhp]

[:drop:][p_d_04][sora body=prain kao=7 as=on ]
「！没、没有。倒不是说需要忍耐什么的……[rhr]
_　……那个、能先问个问题吗？」[rhp]

[:yoru:][p_y_36][yoru kao=0 ]
「说吧」[rhp]

[:drop:][sora body=prain kao=3 ]
「夜你为何对宙如此执着？[rhr]
_　听闻你厌恶孩童与人际往来」[rhp]

[:yoru:][p_y_31][yoru kao=3 ]
「…………、…………我在下注」[rhp]
[:yoru:]
「坦白说、不仅脱离战线的武……[rhr]
_　光靠矢部和千秋终究无法实现我的夙愿」[rhp]
[:yoru:]
「恐怕他们也早已醒悟。[rhr]
_　在孩童的梦想与友情里、没有大人插足的余地」[rhp]
[:yoru:]
「……就是这样的我们面前，出现了和我们一样[rhr]
『想把死者带回来』而祈愿的人……宙」[rhp]
[:yoru:]
「结果来说我的判断是错误的。[rhr]
_　他最终还是没能抵挡那边生活方式的诱惑」[rhp]
[:yoru:]
「不过他拥有我们不具备的东西。[rhr]
_　……再说一次吧。在孩子梦想和友情面前，没有大人插足的余地」[rhp]
[:yoru:]
「所以我们才把一切都押在那个小鬼身上」[rhp]

[:drop:][p_d_14][sora body=prain kao=3 ]
「………………」[rhp]

[:yoru:][yoru kao=8 ]
「抱歉。说了些无聊的话」[rhp]
[:yoru:]
「总之就是希望你们留在这边直到我说可以。[rhr]
_　武他们那边我会去说明情况―――」[rhp]

[:drop:][sora body=prain kao=1 ]
「………………情况我明白了」[rhp]
[:drop:]
「不过夜。在那之前能问一件事吗」[rhp]

[:yoru:][p_y_36][yoru kao=0 ]
「什么？」[rhp]

[:drop:][sora body=prain kao=1 ]
「只要很短时间就好，能让我回到那边的世界吗」[rhp]

[:yoru:][yoru kao=4 ]
「……！说什么傻话？那样做的话，你的身体会」[rhp]

[:drop:][p_d_31][sora body=prain kao=13 ]
「我知道有平安无事的先例」[rhp]

[:yoru:][p_y_22][yoru kao=4 as=on ]
「…………！」[rhp]

[:drop:][sora body=prain kao=13 ]
「我想支持宙。他获得幸福是让人高兴的事。[rhr]
_　不如说如果这是宙期望的，我就算永远保持这样也无所谓」[rhp]
[:drop:]
「但在这之前，有件必须告诉公主的事。[rhr]
_　在那边的时候总是在最关键时没能说出口」[rhp]
[:drop:]
「你所说的『宙气消之日』，[rhr]
_　是指公主等人离开银河铁道之日吧」[rhp]
[:drop:]
「也就是说如果我错过这次，就再也见不到那个人了」[rhp]

[:yoru:][yoru kao=0 ]
「………………」[rhp]

[:drop:][sora body=prain kao=13 ]
「……拜托了。我的愿望，真的仅此而已」[rhp]

[:yoru:][p_y_17][yoru kao=1 ]
「…………、…………明白了。就一晚的话还能想办法」[rhp]

[:drop:][p_d_07][sora body=prain kao=13 ]
「足够了。非常感谢」[rhp]

[:yoru:][yoru kao=12 ]
「真是的……净让我为你们操劳」[rhp]

[:drop:][sora body=prain kao=8 as=on ]
「两个人一起任性实在抱歉」[rhp]

[:yoru:][p_y_31][yoru kao=0 ]
「确实。第一次在你身上看到宙的影子……」[rhp]
[:yoru:]
「…………别留下遗憾」[rhp]

;****************************************

#
[s_mask color=0xffffff time=3000]
[off_all]
; 背景表示
[bg storage="train_06.jpg" time=100]
; 全部のフィルターを打ち消す
[free_filter ]
; ウィンドゥの設定
[position layer="message0" frame="win.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[s_mask_off time=3000]

;****************************************

[::]
终于双脚着地，在光芒中紧闭双眼的我[rhr]
缓缓睁开眼睑，环顾四周。[rhp]
是熟悉的微缩庭院。[rhr]
明明没过多久，却已涌起怀念之情。[rhp]

[:sausu:][p_s_13][sausu kao=4 as=on ]
「咦？多洛普？」[rhp]

[:drop:][p_d_27][drop kao=1 ]
「！南。好久不见」[rhp]

[:sausu:][p_s_26][sausu kao=6 as=on ]
「好久不见……才怪，你怎么会在这里？[rhr]
_　听说约尔大人把你和宙调换了」[rhp]

[:drop:][drop kao=13 ]
「发生很多事，只是短暂停留」[rhp]

[off_all]

[::]
即便如此，也有必须传达心意的人。[rhr]

[chara_part name="drop" body=base kao=1 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:drop:]
「南。宙先生在哪里？」[rhp]

[:sausu:][sausu kao=4 ]
「刚刚离开这个房间」[rhp]

[:drop:][drop kao=13 ]
「这样啊……谢谢」[rhp]

[:sausu:][p_s_04][sausu kao=3 as=on ]
「……你究竟想干什么？」[rhp]

[:drop:][p_d_17][drop kao=1 ]
「唔嗯……」[rhp]
[:drop:]
「…………告白、是吧」[rhp]

[:sausu:][p_s_13][sausu kao=4 as=on ]
「诶？　这……」[rhp]

[off_all]

[:drop:][drop kao=13 ]
「那么赶时间，我先告辞了」[rhp]

[off_all]

[::]
无视似乎还想提问的南，我转身离开乘务员室。[rhp]
…………这种事还是头一回。[rhr]
不过，稍微任性点也无妨吧。[rhp]
毕竟我已经不是乘务员了。[rhp]

;****************************************
[set_w storage="train_01.jpg"]
;****************************************

被骗了。[rhp]
被骗了……[rhp]
……被骗了！！[rhp]
我压抑不住烦躁在车厢里咚咚疾行。[rhp]

[:sora:][p_so_12][sora kao=2 ]
「夜……！　你说过要杀了我的！」[rhp]

[off_all]

[::]
可这算什么？只是和多洛普调换了身体？开什么玩笑！[rhr]
那不就意味着，我的肉体还活着吗。[rhp]
我和夜很像。那家伙的行动模式我立刻就能明白。[rhp]
他打算先让我逍遥一阵子，等我放松警惕时再调换回来，[rhr]
最终肯定是要把我送回现实世界。[rhp]

[:sora:][sora kao=2 ]
「休想得逞……！　我要在这里活下去！」[rhp]

[off_all]

[:drop:]
「我赞成」[rhp]

[off_all]

[:sora:][sora kao=4 ]
「――――――！」[rhp]

[:drop:][p_d_35][drop kao=5 ]
「你好。落合……不对，宙先生」[rhp]

[:sora:][sora kao=2 ]
「多洛普……！？」[rhp]

[:drop:][drop kao=13 ]
「总觉得很不可思议呢。[rhr]
_　实在太像了，简直就像在和镜子说话，」[rhp]

[:sora:][sora kao=2 ]
「为什么你会在这里！？」[rhp]

[:drop:][drop kao=7 ]
「！　对不起。这件事是有原因的……」[rhp]

[:sora:][sora kao=0 ]
「我明白没消灭你！但你们互换了身体对吧！？[rhr]
_　既然我在这里，你现在应该在我的身体里！」[rhp]

[:drop:][drop kao=13 ]
「我、我只是抱着试试看的心态拜托了夜。[rhr]
_　问他能不能让我短暂地回来一会儿」[rhp]

[:sora:][sora kao=6 ]
「呃……！夜那家伙……」[rhp]
[:sora:]
「你来这里干什么！？如果是来带我回去就白费功夫了！」[rhp]

[:drop:][drop kao=1 ]
「请放心。我只是来谈话的」[rhp]

[:sora:][sora kao=8 ]
「谈话？」[rhp]

[:drop:][drop kao=11 ]
「嗯。和公主」[rhp]
[:drop:]
「……有些没能说出口的事」[rhp]

[:sora:][sora kao=0 ]
「……！！」[rhp]

;殴る
[se storage="hand_06.ogg"]

[::]
冲动之下殴打了多洛普。[rhr]
那家伙向后倒去，猛烈撞上背后客舱的门，跌倒在地板上。[rhp]
喷涌而出的怒意无法平息。[rhr]
那张若无其事的脸、平静的言辞，全都令人恼火。[rhp]

[chara_part name="sora" body=base kao=2 as=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="drop" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="421" top="0" wait="true" time=150]

[:sora:][p_so_09]
「休想得逞。你回来的理由[rhr]
_　其实不用问我也知道……所以更要告诉你」[rhp]
[:sora:]
「……你喜欢那家伙，不过是因为我喜欢她！」[rhp]

[:drop:][drop kao=4 ]
「――――――！」[rhp]

[:sora:][sora kao=5 ]
「我的愿望只是和大家去往同一个地方！[rhr]
_　我的梦想就是治好他们的病，再和大家一起胡闹！」[rhp]
[:sora:]
「这样就能全部实现了……！我的愿望就在这里！」[rhp]
[:sora:]
「在这里根本不需要什么理想！！」[rhp]

[:drop:][drop kao=3 ]
「呃……」[rhp]

[off_all]

;****************************************
#
[bg_rule storage="train_03.jpg" rule="002.png" time=1000]
;****************************************

[::]
――――――现在，好像从普通车厢那边传来声音。[rhp]

[:princess:][puri_w kao=7 ]
「？刚才那是什么……？」[rhp]

[chara_part name="jet" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=4 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:][p_h_19]
「去看看吧！要是打架的话我来阻止！！」[rhp]

[:jet:][jet kao=3 as=on ]
「感觉会变得更吵呢」[rhp]

[off_all]

[:princess:]
[font color=0x4682b4]
（怎么回事……有种莫名的忐忑……）[rhp]
[resetfont]

;****************************************
#
[bg_rule storage="train_01.jpg" rule="002.png" time=1000]
;****************************************

[:heartshape:][hati kao=2 ]
「喂！发生什么骚乱了！？」[rhp]

[:princess:][puri_w kao=4 ]
「刚刚听到了好大的声响……！」[rhp]

[off_all]

[:drop:][drop kao=4 ]
「！公主！」[rhp]

[:princess:][puri_w kao=4 ]
「……诶……」[rhp]

[off_all]

[chara_part name="jet" body=base kao=4 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:jet:]
「……！！」[rhp]

[:heartshape:][p_h_12][hati kao=6 ]
「为、为什么连那家伙也……」[rhp]

[off_all]

[:sora:][sora kao=2 ]
「切……！」[rhp]

[off_all]

[chara_part name="drop" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=4 as=on ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「多洛普……！多洛普，你回来了！？什么时候！？」[rhp]

[:drop:][drop kao=13 as=on ]
「那个，就是刚刚……」[rhp]

[:princess:][puri_w kao=13 ]
「我好担心！[rhr]
_　我还以为再也见不到多洛普了―――」[rhp]

[:drop:][p_d_22][drop kao=7 ]
「那个……」[rhp]

[off_all]

[yurasu]

[:sora:][p_so_11]
[font size=30]
「啊啊啊可恶！！」[rhp]
[resetfont]

[off_all]

[:princess:][puri_w kao=3 ]
「！！」[rhp]

[off_all]

[:sora:][sora kao=2 as=on ]
[font size=24]
「为什么变成这样……！！为什么总是不顺利！？」[rhp]
[:sora:]
「永远只有我不幸福！永远只有我失去一切！[rhr]
_　千辛万苦得到的机会，全都消失了……！」[rhp]
[resetfont]

[off_all]

[:princess:][puri_w kao=8 as=on ]
「落、落合君。冷静、」[rhp]

[:sora:][p_so_10][sora kao=8 ]
「……！！　宙不是也说过了吗。你也要躲着我吗」[rhp]
[:sora:]
「[font color=0x#00008b][player3b][resetfont]明明都说了……！[rhr]
_　说想和我在一起的！」[rhp]

[:princess:][puri_w kao=8 ]
「诶……？」[rhp]

[off_all]

;****************************************
[still storage="cg/d_d1_4.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/d_d1_4.png"]
;****************************************

[:princess:]
「呀啊！」[rhp]

[:drop:][p_d_11]
「公主！」[rhp]
[:drop:]
「……宙、干什么……！」[rhp]

[:sora:][p_so_09]
「回来啊多洛普！！」[rhp]

[:drop:]
「……！」[rhp]

[:sora:]
「这里是我的地盘！　不需要你这种家伙！！」[rhp]
[:sora:]
「在这里我才是多洛普！　我已经成为多洛普了……！」[rhp]

[:princess:]
「呃……疼……」[rhp]

[:drop:][p_d_12]
「宙先生！　您的愤怒与公主无关吧？[rhr]
_　如果您是因为我的到来而生气，我向您道歉……！」[rhp]

[:sora:][p_so_25]
「不需要道歉。只想让你赶紧滚回去！」[rhp]
[:sora:]
「知道我为什么拼命努力努力再努力，[rhr]
_　却还是得不到幸福吗！？」[rhp]
[:sora:]
「就是因为你！　只要你还[font color=0x#00008b][player3b][resetfont]独占着大家，[rhr]
_　我永远都只能孤身一人」[rhp]
[:sora:]
「还给我！　把我的容身之处……！　赶紧滚出去！」[rhp]

[:drop:]
「宙……」[rhp]

[:sora:]
「不是宙！　我是多洛普！」[rhp]

;****************************************
#
[bg storage="cg/d_d1_5.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/d_d1_5.png"]
;****************************************

[:drop:][p_d_26]
「…………、不宙。请您听我说」[rhp]
[:drop:]
「我回到这里并非仅是为了[rhr]
_　向公主传达某些事情」[rhp]
[:drop:]
「而是为了与你进行交接才回来的」[rhp]

[:sora:]
「交接……！？」[rhp]

[:drop:][p_d_02]
「因为这是重要的工作。理所应当的」[rhp]
[:drop:]
「……宙。最后还有个请求，能听我说吗」[rhp]

[:sora:]
「…………说吧」[rhp]

[:drop:]
「请给我道别的时间」[rhp]
[:drop:]
「等结束后，我会听从你的安排。[rhr]
_　带大家去想去的地方本就是我的职责」[rhp]

[:sora:]
「………………」[rhp]

[:drop:]
「你所期望的幸福模样，其实我一直都明白。[rhr]
_　正如你所说，你就是我啊」[rhp]
[:drop:]
「……太好了。终于能给予回应了」[rhp]

[:sora:]
「………………」[rhp]

[:drop:][p_d_17]
「我知道这很任性。即便如此……能否请您原谅？」[rhp]

[:sora:]
「……………………明白了」[rhp]

;****************************************
#
[bg storage="cg/d_d1_5b.png" width="1280" height="720" time=500]
[cg storage="cg/d_d1_5b.png"]
;****************************************

[:drop:][p_d_07]
「万分感谢」[rhp]

[:sora:][p_so_28]
「没什么……那种难以释怀的心情，我比你更清楚」[rhp]

[:drop:]
「确实呢。和你相比，我还差得远」[rhp]

;****************************************
;スチル終了
[still_end frame="win.png" storage="train_01.jpg" time=1000]
;****************************************

[::]
当谈话暂告段落时，[rhr]
宙君轻轻松开了钳制我的手臂，稍微拉开些距离。[rhp]
再次端详他的面容，能看到明显的憔悴痕迹。[rhr]
完全无法想象这就是那个始终保持桀骜态度的他。[rhp]

[:drop:][drop kao=13 ]
「诸位听好。现在要去的是我想去的地方。[rhr]
_　呵呵，这可是首次提出的请求呢」[rhp]
[:drop:]
「领队还是拜托哈托谢普和杰特先生吧。[rhr]
_　等我不在了，你们就要作为乘务员当前辈了」[rhp]

[off_all]

[chara_part name="jet" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:][p_h_13]
「……多洛普……可是」[rhp]

[:jet:][p_j_12][jet kao=8 as=on ]
「………………」[rhp]

[off_all]

[:drop:][p_d_28][drop kao=1 ]
「我去向其他人解释。[rhr]
_　大家大概会吃惊吧，但也没办法」[rhp]
[:drop:]
「……公主。抵达目的地后，请给我些时间交谈」[rhp]

[:princess:][puri_w kao=8 as=on ]
「我、我也有一堆话想说啊。突然消失又突然出现算什么？[rhr]
_　为什么宙君会和你长得一模一样……！」[rhp]

[off_drop]

[:sora:][p_so_22][sora kao=6 ]
「说反了哦。不是我像他。[rhr]
_　是多洛普像我。毕竟那家伙就是我」[rhp]

[:princess:][puri_w kao=4 ]
「啊……？」[rhp]

[off_all]

[:drop:][drop kao=13 ]
「哈哈……这些细节容后再慢慢说明」[rhp]

[off_all]

[:drop:]
「那么，稍后再见」[rhp]

;****************************************
#
[bg storage="sky_13.jpg" time=1500]
;****************************************

[::]
列车对混乱的我视若无睹，无机质地沿着银河前行。[rhp]
虽然多洛普归来令人欣喜，但仍有难以抹去的不安。[rhr]
是因为宙君当时那么生气的缘故吗。还是说……[rhp]
……抵达目的地后，多洛普真的会说出真相吗。[rhp]

;****************************************
[fbgm]
[set_n storage="park_01n.jpg"]
[bgm storage="bgm_08.ogg"]
;****************************************

据多洛普所说，我们来到的地方是游乐园。[rhp]
正是他初次带我造访的那个场所。[rhp]
没想到这里会成为多洛普心仪之地。着实令人意外。[rhr]
想到他最初那副态度，不禁感慨万千……[rhp]

[:drop:][p_d_06][drop kao=14 ]
「大家、谢谢你们陪我任性。[rhr]
_　最后能来这个游乐园真是太好了」[rhp]

[:sora:][p_so_10][sora kao=7 ]
「最后是啥意思。现实世界里想去多少次都行吧」[rhp]

[:drop:][drop kao=1 ]
「不。是这个游乐园最好」[rhp]

[:sora:][sora kao=3 ]
「…………哦」[rhp]

[off_all]

[chara_part name="jet" body=base kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="drop" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:jet:][p_j_04]
「大半夜的没问题吗？商店和游乐设施都没开哦。[rhr]
_　这方面倒是很写实呢」[rhp]

[:drop:][p_d_31][drop kao=5 ]
「嗯。因为太开心的话可能会不想回去。[rhr]
_　对我而言这种程度刚刚好」[rhp]

[:heartshape:][p_h_31][hati kao=13 ]
「哼嗯……嘛！像是那种啦！[rhr]
_　有点像鬼屋这样也挺有趣的该怎么说！」[rhp]
[:heartshape:]
「好嘞多洛普！既然是最后一次就痛快玩，」[rhp]

[off_all]

[chara_part name="jet" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="riri" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="736" top="0" wait="true" time=150]

[:jet:]
「别闹了哈蒂」[rhp]

[:heartshape:][hati kao=4 ]
「嗯？」[rhp]

[:quadrillion:][riri kao=5 ]
「今天的我们要看家哦」[rhp]

[off_all]

[chara_part name="drop" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:kite:]
「路上小心。早点回来啊」[rhp]
[:kite:]
「……我们也有想对多洛普说的话」[rhp]

[:drop:][drop kao=11 ]
「…………好的」[rhp]

[off_all]

[:drop:][drop kao=1 ]
「那么公主。我们出发吧」[rhp]

[:princess:][puri_w kao=3 ]
「嗯……」[rhp]

[off_all]

[:sora:][sora kao=2 ]
「～～～～……」[rhp]

[off_all]

[chara_part name="hakase" body=base kao=1 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720" left="40" top="0" wait="false" time=150]
[chara_part name="sora" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="peku" body=hood kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="720" top="0" wait="true" time=150]

[:vulpecula:][p_vl_09 ]
「哔哔！偶系警察叔叔！」[rhp]

[:sora:][p_so_19]
「嗯？」[rhp]

[:darknebula:][p_da_18]
「虽然会很在意，但就算是你也不能过去哦」[rhp]

[:sora:][sora kao=3 ]
「……我知道啦！」[rhp]

[off_all]

;****************************************
#
[bg storage="park_03n.jpg" time=1500]
;****************************************

[::]
我和多洛普离开入口处，在园内稍微走了走。[rhp]
内部空荡冷清，简直无法想象和上次来时是同一个地方。[rhr]
或许是灯光太过昏暗，总让人觉得有点儿害怕。[rhp]
正沉默地环顾四周时，并肩同行的多洛普[rhr]
带着歉疚开口道：「那个」[rhp]

[:drop:][p_d_34][drop kao=1 ]
「抱歉。让您在这种地方单独陪我」[rhp]

[:princess:][puri_w kao=13 ]
「不会啊。多洛普的愿望终于实现了，我很开心」[rhp]
[:princess:][puri_w kao=3 ]
「…………。……不，可能并不开心」[rhp]

[:drop:][p_d_19][drop kao=0 as=on ]
「到底是哪种啦！？」[rhp]

[:princess:][puri_w kao=3 ]
「不开心。……因为这是告别的时刻吧」[rhp]

[:drop:][drop kao=13 ]
「………………是的」[rhp]

[:princess:][puri_w kao=3 ]
「为什么……！　为什么不能就这样留在这里？[rhr]
_　为什么非要去那边的世界不可？」[rhp]
[:princess:]
「多洛普是这里的居民吧。既然如此为什么——」[rhp]

[:drop:][p_d_34][drop kao=11 ]
「抱歉。这已是既定之事」[rhp]

[off_all]

[::]
还以为他终于能稍微表达自己的愿望了。[rhp]
多洛普太过认真。真是拿他没办法……[rhp]

[:drop:][p_d_04][drop kao=1 ]
「公主。[rhr]
_　您或许已经知道，我原本并非人类」[rhp]
[:drop:]
「是为了填补来访者们内心空隙而制作的替代人偶。[rhr]
_　极端地说，我是个假冒的宙」[rhp]
[:drop:]
「您和快斗也有对应的替代者。[rhr]
_　但是他们随你们死去的同时，从这个世界上消失了」[rhp]
[:drop:]
「因为你们的到来，他们已完成了使命。[rhr]
_　他们与本人同化合而为一了」[rhp]
[:drop:]
「生前的『灵魂』与替身的『精神』、[rhr]
_　两者交融才能在此确立存在」[rhp]

[:princess:][puri_w kao=8 as=on ]
「……你想说什么？」[rhp]

[:drop:][p_d_32][drop kao=13 as=on ]
「我不该继续存在的」[rhp]
[:drop:]
「……我们替身共享着原型人类的记忆。[rhr]
_　所以我清楚知道宙先生多么珍惜与大家共度的时光」[rhp]
[:drop:]
「当宙最初来到此地时，我就该融入他的体内。[rhr]
_　我却利用他莫名不提此事的空隙，苟活至今」[rhp]
[:drop:]
「本应实现他理想的存在，结果正走向相反的道路」[rhp]
[:drop:]
「…………我深感懊悔」[rhp]

[:princess:][puri_w kao=2 ]
「没必要后悔。替身又怎样？」[rhp]
[:princess:]
「分开就好。保持独立才好！无论有再多艰涩的理论，[rhr]
_　站在这里的不是落合君。是多洛普啊……！」[rhp]

[:drop:][p_d_22][drop kao=8 ]
「………………」[rhp]

[off_all]

[::]
多洛普绷紧苦涩的脸沉默不语，眯着眼睛将视线投向地面。[rhr]
这段无言的时光漫长得恍若永恒。[rhp]
不知道多洛普在想什么。[rhr]
但是，我已经好好传达了心意。[rhp]
接下来只剩下等待多洛普的回应了。[rhp]

; ソラルート
[jump storage="ev_d_drop3.ks" target="*start" cond="f.root_s == 1"]

; ドロップルート
[jump storage="ev_d_drop2.ks" target="*start" cond="f.root_d == 1"]

