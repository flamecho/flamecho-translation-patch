﻿
*start

;ぶっとばし

;--------------------------------------------------------------------------------------------
;▼フルボイスセット▼
;３人組は複雑なんで後半で出す

;ヤブ医者
[voconfig sebuf=1 name=yabu vostorage="yabu/full/{number}.ogg" number=2]
;ミカちん
[voconfig sebuf=1 name=mika vostorage="mika/full/{number}.ogg" number=1]
;糠星の夜
[voconfig sebuf=1 name=yoru vostorage="yoru/full/{number}.ogg" number=1]

;--------------------------------------------------------------------------------------------

;****************************************
[set_b storage="train_08.jpg" time=3000]
;****************************************

[bgm storage="bgm_01.ogg"]

[::]
在这条鉄道上醒来已过数日。[rhp]
对这里的生活也已完全习惯。[rhr]
感觉和大家也渐渐熟络起来了，每天都挺顺利的。[rhp]

[se storage="door_07.ogg"]
[bg storage="train_04.jpg" method="fadeInRightBig" time=500]

从卧铺车厢走向清晨大家聚集的餐车。[rhr]
就在那时，偶然遇见了哈蒂君和杰特君两人。[rhp]

[chara_part name="jet" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="hati" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:jet:][p_j_35]
「早安 公主」[rhp]

[:heartshape:][p_h_35]
「今天也是这么棒呢！　公主！」[rhp]

[:princess:][puri_w ]
「早安两位。一大早就这么有精神呢」[rhp]

[:jet:][p_j_02][jet kao=5 ]
「啊。哈蒂尤其精神」[rhp]

[:princess:][puri_w ]
「？有什么状况吗？」[rhp]

[:heartshape:][p_h_15][hati kao=13 ]
「哼哼哼。满满当当满到溢出来啦！」[rhp]
[:heartshape:][hati kao=5 ]
「你小子~早饭好好吃了吗～？[rhr]
_　今天不把肚子填得实实在在的话，可是会死人的啊！」[rhp]

[:princess:][puri_w kao=6 as=on ]
「…………为什么？」[rhp]

[:heartshape:][p_h_16][hati kao=5 ]
「咯咯咯……！因为今天要去的地方会让人震惊到[rhr]
_　消耗的卡路里可能会突破极限啊！」[rhp]

[:princess:][puri_w kao=2 as=on ]
「你、你要去哪！？听起来是个超级危险地带啊！」[rhp]

[:heartshape:][p_h_31][hati kao=14 ]
「谁知道呢！那可是听完之后的惊喜――――」[rhp]

[:jet:][p_j_15][jet kao=11 ]
「是游乐园哦」[rhp]

[:princess:][puri_w kao=4 hh=on ]
「诶……游乐园？」[rhp]

[:heartshape:][p_h_10][hati kao=2 as=on ]
「喂、等等等等杰特！怎么就说出来了！？」[rhp]

[:jet:][p_j_15][jet kao=5 ]
「没问题吧。公主的话应该在知道全部内容的情况下，[rhr]
_　等会儿在食堂公布时她肯定会有超棒的反应的」[rhp]

[:princess:][puri_w kao=2 as=on ]
「！？　什、擅自干什么」[rhp]

[:heartshape:][p_h_06][hati kao=5 ]
「原来如此！那样要有趣1兆倍啊！！不愧是杰特！」[rhp]
[:heartshape:]
「呜哇！！　我很期待啊！[rhr]
_　Big Performer・公主！」[rhp]

[:jet:][p_j_04][jet kao=11 ]
「来试试身手吧。即兴艺人，公主！」[rhp]

[:hutago:]
[s_playse storage="hati/part/6.ogg" buf=1] 
[s_playse storage="jet/part/6.ogg" buf=2] 
「那就待会儿见啦！」[rhr]
「那就待会儿见」[rhp]

[:princess:][puri_w kao=6 as=on ]
「喂，就算你这么说！」[rhp]

[off_all]

[::]
说话间，两人已经快步离去。[rhr]
反正都是要去同一辆餐车，明明可以一起走的。[rhp]

[:princess:][puri_w kao=2 as=on ]
「大清早就提出这么离谱的要求！　难以置信！」[rhp]

[off_puri]

[::]
好嘞，既然如此……！[rhp]

;****************************************
;食堂車
[set_00 storage=train_03.jpg]
;****************************************

[:drop:][p_d_15][drop ]
「那么。既然大家都到齐了，我要宣布重要消息」[rhp]

[off_drop]

[:princess:][puri_w kao=2 as=on ]
[font color=0x4682b4]
（来了……！）[rhp]
[resetfont]

[off_puri]

[:drop:][drop kao=14 ]
「下次旅行的目的地已经决定！　目的地是游乐园之星！」[rhp]

;-----------------------------------------------------------------------------
;-----------------------------------------------------------------------------

[::]

*sentaku_1

;【想定内です】
[glink clickse="btn_01.ogg" x="290" y="100" width="610" high="72" text="想定内です" target="*sntk1_a" graphic="glink_a.png" enterimg="glink_b.png"]
;【やったあ】
[glink clickse="btn_01.ogg" x="290" y="220" width="610" high="72" text="あああああやったああああああああああああ" target="*sntk1_b" graphic="glink_c.png" enterimg="glink_d.png"]
;【………………】
[glink clickse="btn_01.ogg" x="290" y="340" width="610" high="72" text="ここはあえての……" target="*sntk1_c" graphic="glink_a.png" enterimg="glink_b.png"]

[s]
;-----------------------------------------------------------------------------
;-----------------------------------------------------------------------------
;【想定内です】

*sntk1_a

[:princess:][puri_w kao=12 ]
「意料之中」[rhp]

[off_all]

[:heartshape:][p_h_13][hati kao=8 as=on ]
「！？」[rhp]

[off_all]

[chara_part name="drop" body=base kao=4 as=off ss=off hh=off hr=on hat=on  ]
[chara_show name="drop" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=12 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:drop:][p_d_19]
「咦，你早就知道了吗？　可是为什么……」[rhp]

[:princess:][puri_w kao=12 ]
「意料之中」[rhp]

[:drop:][p_d_10]
「？　这是什么意思？」[rhp]

[:princess:]
「多洛普的发言在预料之内。所以并不惊讶」[rhp]

[off_all]

[font size=28 color=0x4682b4]
（骗人！！！　其实开心得不得了啊！！）[rhp]
[resetfont]

[chara_part name="riri" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="180" top="0" wait="false" time="150"]
[chara_part name="hati" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:heartshape:][p_h_21]
「什……！　怎、怎么……！？」[rhp]

[:quadrillion:][p_r_10]
「你原来是这种人设吗？」[rhp]

[:princess:][puri_w kao=12 ]
「没错，这个反应也在预料之中哦」[rhp]

[off_all]

[:heartshape:][p_h_10][hati kao=2 as=on ]
「公主！！　搞什么啊，这种无聊的回应！？」[rhp]

[off_hati]

[:princess:][puri_w kao=11 ]
[font color=0x4682b4]
（对对。这才是最意料之中的……！！[rhr]
_　就该让你彻底明白不是所有事都能如你所愿！）[rhp]
[resetfont]

[jump target="*tutti1"]

;-----------------------------------------------------------------------------
;【やったぁ】

*sntk1_b


[:princess:][puri_w kao=2 ]
[font size=28]
「啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊[rhr]
_　成功啊啊啊啊啊啊啊啊啊啊啊啊啊！！！」[rhp]
[resetfont]

[:drop:][p_d_06][drop kao=14 ]
「你比我想象的更开心真是太好了」[rhp]

[font size=28]
「呜哇啊啊啊啊啊啊啊啊啊啊啊啊啊啊[rhr]
_　啊啊啊啊啊啊啊啊啊啊啊啊啊！！！！！」[rhp]
[resetfont]

[:drop:][p_d_13][drop kao=2 as=on ]
「稍……」[rhp]

[off_drop]

[font size=28]
「办到了啊啊啊啊啊啊啊啊啊啊啊啊啊！！！！[rhr]
_　啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊！！！！」[rhp]
[resetfont]

[off_puri]

[chara_part name="peku" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="152" top="0" wait="false" time="150"]
[chara_part name="kite" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time="150"]

[:kite:][p_k_14]
「不妙这家伙w」[rhp]

[:vulpecula:][p_vl_13]
「这是怎么了啊！？游乐园让你这么高兴吗！？」[rhp]

[off_all]

[:princess:][puri_w kao=5 ss=on ]
[font size=28]
「呼啊啊啊啊啊啊啊啊"啊[resetfont]咳咳咳咳」[rhp]
[:princess:]
[font color=0x4682b4]
（呵……呵呵呵……！见识到我的认真了吧！）[rhp]
[resetfont]

[off_puri]

[:heartshape:][p_h_18][hati kao=2 as=on ]
「太、太夸张了……！简直像是[rhr]
_　以为只要大声喊叫就能逗笑观众的新人艺人！」[rhp]

[jump target="*tutti1"]

;-----------------------------------------------------------------------------
;【…………】

*sntk1_c

[:princess:][puri_w kao=6 ]
[font color=0x4682b4]
（有反应就中计了。这里要刻意保持沉默……！）[rhp]
[resetfont]
[:princess:]
「…………………………」[rhp]

[:drop:][p_d_19][drop kao=4 as=on ]
「啊、啊咧？公主？您不高兴吗？」[rhp]

[:princess:][puri_w kao=6 ]
「…………………………」[rhp]

[:drop:][p_d_04][drop kao=8 as=on ]
「公主？喂——！」[rhp]

[:princess:][puri_w kao=6 ]
「…………………………」[rhp]

[off_all]

[:darknebula:][p_da_01][hakase kao=0 ]
「此后，公主再也没有开口说过话――――」[rhp]

[fbgm]

[off_all]

[::]
银河之旅铁路　～完～[rhp]

[bgm storage="ed_01.ogg"]

[s_anim name="message_outer" time="500" opacity=" 0"]
[bg storage="black.jpg" time=1000]
[s_wait time="1000"]


@layopt layer=0 visible=true

[ptext layer=0 text="　　　　　　　　　ＣＡＳＴ　　　　　　　　　" size=18 x=622 y=190 color=snow name="text"]

[ptext layer=0 text="　　　　　　　ドロップ　五十嵐優樹　　　　　" size=18 x=576 y=290 color=snow name="text"]
[ptext layer=0 text="　　　　　　　　カイト　坂上晶　　　　　　　" size=18 x=594 y=320 color=snow name="text"]
[ptext layer=0 text="　　　クォードリリオン　酒味たろう　　　　　" size=18 x=504 y=350 color=snow name="text"]
[ptext layer=0 text="　　　　ハートシェイプ　折原幸平　　　　　　" size=18 x=522 y=380 color=snow name="text"]
[ptext layer=0 text="　　　　　　　ジェット　折原幸平　　　　　　" size=18 x=576 y=410 color=snow name="text"]
[ptext layer=0 text="　　　ダークネブラ博士　ＫＡＺＵＭＡ　　　　" size=18 x=504 y=440 color=snow name="text"]
[ptext layer=0 text="　　　　　　ヴルペクラ　殊座　　　　　　　　" size=18 x=558 y=470 color=snow name="text"]

[ptext layer=0 text="　　　　　　　　　ヌシ　ましろな　　　　　　" size=18 x=612 y=520 color=snow name="text"]
[ptext layer=0 text="　　　　　　　魔太郎子　だも子。　　　　　　" size=18 x=576 y=550 color=snow name="text"]
[ptext layer=0 text="　　　ゴンザレス１億世　松永みとせ　　　　　" size=18 x=504 y=580 color=snow name="text"]
[ptext layer=0 text="　　　　　　　ヤブ医者　戌ヶ森ロク　　　　　" size=18 x=576 y=610 color=snow name="text"]
[ptext layer=0 text="　　　　　　　ミカちん　武田恵瑠々　　　　　" size=18 x=576 y=640 color=snow name="text"]
[ptext layer=0 text="　　　　　　　　サウス　浅沼諒空　　　　　　" size=18 x=594 y=670 color=snow name="text"]
[ptext layer=0 text="　　　　　　　糠星の夜　ラム　　　　　　　　" size=18 x=576 y=700 color=snow name="text"]


[ptext layer=0 text="　　　　　　　　　企画　いさら座　　　　　　" size=18 x=612 y=3100 color=snow name="text"]

[s_wait time=1]

[keyframe name="animation1"]
;[frame p=0% y="300"]
[frame p=100% y="-3500"]
[endkeyframe]
;実行する！
[kanim name="text" keyframe="animation1" time="49000" ]
@layopt layer=message0 visible=true

[rhp]
[s_freeimage layer="0" time="100"]


[s_anim name="message_outer" time="100" opacity="255"]
[cm]

[stopbgm]

[bg storage="train_03.jpg" time=100]

[yurasu]

[:princess:][puri_w kao=2 ]
[font size=28]
「游乐园其实超期待的！！！！」[rhp]
[resetfont]

[bgm storage="bgm_01.ogg"]

[:drop:][p_d_06][drop kao=14 ]
「是吗！那就太好了」[rhp]

[off_all]

[:heartshape:][p_h_30][hati kao=6 ]
「切、什么嘛那种反应。明明超级普通啊……」[rhp]

[jump target="*tutti1"]

;-----------------------------------------------------------------------------

*tutti1

[:jet:][p_j_01][jet kao=11 ]
「反倒是可以理解」[rhp]

[:princess:][puri_w kao=2 as=on ]
「！！！！」[rhp]

[:heartshape:][p_h_18][hati kao=5 ]
「咦、反倒？这样啊，原来如此……！[rhr]
_　反而觉得可能在这附近呢！　不愧是杰特！」[rhp]

[:princess:][puri_w kao=2 as=on ]
[font color=0x4682b4]
（可恶、最后反而让他开心了……！但也没办法啊。[rhr]
_　游乐园本来就是很期待嘛！！根本没法演戏！）[rhp]
[resetfont]

[off_all]

[chara_part name="kite" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="160" top="0" wait="false" time="150"]
[chara_part name="riri" body=base kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="606" top="0" wait="true" time="150"]

[:quadrillion:]
「说什么游乐园真是相当孩子气呢。提不起兴致」[rhp]

[:kite:][p_k_24]
「我也是。讨厌吵闹的地方」[rhp]

[off_all]

[chara_part name="hakase" body=base kao=5 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time="150"]
[chara_part name="hati" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:heartshape:][p_h_05]
「真是的、你们俩简直是年度傲娇之王！」[rhp]

[:darknebula:][p_da_31]
「恭喜双人获奖！」[rhp]

[:heartshape:][p_h_24][hati kao=14]
「你们暗藏的期待 我可是清清楚楚地感受到了啊！！」[rhp]

[off_all]

[chara_part name="kite" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="160" top="0" wait="false" time="150"]
[chara_part name="riri" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="606" top="0" wait="true" time="150"]

[:kite:][p_k_30]
「这家伙无敌了啊……」[rhp]

[:princess:][puri_w kao=13 ]
「两个人都冷冰冰呢。我可是超级期待的哦」[rhp]

[:quadrillion:][p_r_29][riri kao=5 ]
「小朋友们尽管去玩吧。[rhr]
_　我要和快斗在车里玩UNO」[rhp]

[:kite:][p_k_04][kite kao=13 ]
「公主、旋转木马是哪派？我是观战派」[rhp]

[:quadrillion:][p_r_21][riri kao=2 as=on ]
「马上倒戈可不算数！！」[rhp]

[off_all]

[riri kao=3 ]
「……啧！麻烦死了。就算去游乐园、也找不到什么……」[rhp]

[:heartshape:][p_h_09][hati kao=2 ]
「克林！！ 就你小子来说 肯定是冲着和巨乳相遇的几率[rhr]
_　虽然你正在判断旅行地的好坏吧……！」[rhp]
[:heartshape:]
「我可真伤心啊！你根本就什么都不懂！[rhr]
_　反正你肯定觉得巨乳只会在海里栖息吧……！？」[rhp]
[yurasu]
[:heartshape:][hati kao=5 ]
[font size=28]
「巨乳是！水陆两栖的啊！！」[rhp]

[:quadrillion:][riri kao=2 as=on ss=on ]
「！！！」[rhp]
[resetfont]

[off_all]

[:kite:][p_k_26][kite kao=6 ]
「说什么呢？」[rhp]

[off_kite ]

[chara_part name="hati" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="riri" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="606" top="0" wait="true" time="150"]

[:heartshape:][p_h_04]
「克林！去把所有巨乳都收进那台相机里吧！[rhr]
_　是你的话一定能做到！别还没开始就放弃啊！」[rhp]

[:quadrillion:][p_r_33][riri kao=3 hh=on ]
「可、可恶……但你的话，确实触动了我……！[rhr]
_　身为爱好者不该有的妥协想法，看来必须改正了呢……」[rhp]
[riri kao=5 ]
[:quadrillion:][p_r_15]
「启程吧，前往游乐园！！」[rhp]
[resetfont]

[:heartshape:][p_h_31][hati kao=14 ]
「好耶！！！这才像话！！」[rhp]

[off_all]

[chara_part name="jet" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="kite" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time="150"]

[:jet:][p_j_04]
「快斗没有吗？像克林那样的巨乳爱好」[rhp]

[:kite:][p_k_28]
「没有啦……」[rhp]

[off_all]

[:princess:][puri_w kao=7 ]
[font color=0x4682b4]
（游乐园之星吗。究竟是个什么样的地方？[rhr]
_　多亏失忆反而更期待了……！！）[rhp]
[resetfont]

[off_all]

[::]
既然如此就不能坐以待毙！！[rhp]

[:princess:][puri_w kao=5 hh=on ]
「马上借博士的书，[rhr]
_　研究出100%享受游乐园的方法吧！」[rhp]

[:heartshape:][p_h_02][hati ]
「公主！那个计划加我一个！」[rhp]

[off_all]

[:kite:][p_k_05][kite ]
「…………」[rhp]

[:drop:][p_d_04][drop ]
「不邀请他吗？」[rhp]

[:kite:][p_k_13][kite kao=2 as=on ]
「！为、为什么」[rhp]

[:drop:][p_d_02][drop ]
「因为快斗先生也露出很想加入的表情」[rhp]

[:kite:][p_k_28][kite kao=6 ]
「开玩笑吧……别说这些了。我会正常跟着走的」[rhp]

[:drop:][p_d_31][drop kao=5 ]
「呵呵呵。不是不感兴趣吗？」[rhp]

[:kite:][p_k_25][kite kao=3 as=on ]
「烦死了。只是讨厌被排除在外罢了。又不是说很期待……」[rhp]

[:quadrillion:][p_r_36][riri kao=11 ]
「真是不坦率呢。[rhr]
_　双料获奖就让我一个人拒绝如何？」[rhp]

[:kite:][p_k_10][kite ]
「哈？死人妖真恶心」[rhp]

[:quadrillion:][p_r_21][riri kao=2 as=on ]
「你、你这家伙……！！」[rhp]

*karidome

;****************************************
;銀河
[set_00 storage="sky_13.jpg"]
;****************************************

[bgm storage="bgm_23.ogg"]

[::]
数小时后，火车接近了那个「有游乐园的星球」。[rhp]

[:drop:]
「快要到站了！停车前请不要起身」[rhp]

[::]
眼前铺展开绽放着不可思议光芒的大地景象，令人不禁屏息。[rhp]

[:princess:]
「哇……！这是什么！」[rhp]

[::]
魔法光芒如同被星光吞噬般逐渐包裹住车厢。[rhr]
因太过耀眼而闭上眼睛的遗憾感与震撼让身体微微颤抖。[rhp]

;****************************************
[bg storage="white.jpg" time=1000]
;****************************************

片刻后，车厢的晃动逐渐平缓，[rhr]
终于完全刹停。[rhp]
战战兢兢地睁开眼，窗外是……[rhp]

;****************************************
[bg storage="park_01.jpg" time=2000]
;****************************************


[:princess:][puri_w kao=4 hh=on ]
「―――！哇啊！」[rhp]

[off_puri]

[::]
窗外矗立着前所未见的巨型城堡与摩天轮。[rhr]
如巨龙般蜿蜒向天空的滑行道。[rhp]

;****************************************
[bg storage="sky_09.jpg" time=1000]
;****************************************

晴朗天空中飞舞着七彩纸屑与气球。[rhp]
不知从何处飘来若有若无的甜香。[rhr]
普通在外面会有这种气味吗？　不可能！[rhp]
如同魔法般 整个空间都仿佛在熠熠生辉―――[rhp]

[:princess:]
[font color=0x4682b4]
（这就是游乐园吗！？　好厉害……太厉害了！）[rhp]
[resetfont]

;****************************************
#
[bg storage="park_01.jpg" time=500]
;****************************************

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
; アンノウン服数なので名前判明までボイスは個別指定します。
;--------------------------------------------------------------------------------------------

[fbgm]

[:unknown:][s_playse storage="nusi/full/1.ogg" buf=1]
「要是这就让你们吃惊的话我可就头疼了……」[rhp]

[:princess:][puri_w kao=0 as=on ]
「！？　谁？」[rhp]

[off_puri]

[::]
转向发出声音的方向，那里是……[rhp]

;ジャジャーン
[bgm storage="bgm_37.ogg"]

[chara_part name="mata" body=base kao=5 as=off ss=off hh=off hr=on ]

[chara_show name="mata" layer="1" width="437" height="720" left="80" top="0" wait="false" time="150"]
[chara_part name="nusi" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="383" top="0" wait="false" time="150"]
[chara_part name="gon" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="720" top="0" wait="true" time="150"]

[:3nin:]
[s_playse storage="nusi/full/2.ogg" buf=1]
[s_playse storage="mata/full/1.ogg" buf=2]
[s_playse storage="gon/full/1.ogg" buf=3]
「让您久等了！！」[rhr]
「让您久等了！！」[rhr]
「让您久等了！！」[rhp]

[:princess:][puri_w kao=2 as=on ]
「……！？　什……」[rhp]

[off_puri]

[::]
出现在那里的，是三个穿着诡异的人。[rhr]
这也是某种表演之类的吗？[rhp]

[off_all]

摆好决胜姿势的他们，迈着轻快的步伐向我这边走来。[rhp]

[:unknown:][nusi kao=3 ][s_playse storage="nusi/full/3.ogg" buf=1]
「公主真是温柔啊。对我们这种逐渐套路化的登场，[rhr]
_　自己扮成小丑来营造新鲜感吗……真让人想哭」[rhp]

[:unknown:][mata kao=6 ][s_playse storage="mata/full/2.ogg" buf=1]
「但是姐姐大人，刚才的『谁啊？』[rhr]
_　着实有点伤到我了！」[rhp]

[:unknown:][gon kao=11 ][s_playse storage="gon/full/2.ogg" buf=1]
「不知就让我来告诉你吧！　海滩的细沙与―――」[rhp]

[off_all]

[:drop:][p_d_33][drop kao=5 as=on ]
「啊，各位对不起！　其实是有原因的……」[rhp]

;****************************************
[set_time_d]
;****************************************

[:unknown:][nusi kao=3 ][s_playse storage="nusi/full/4.ogg" buf=1]
「失忆吗。那可真是倒了大霉啊」[rhp]

[:princess:][puri_w kao=13 as=on ]
「哎呀～，也没那么厉害啦」[rhp]

[off_all]

[chara_part name="drop" body=base kao=1 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="gon" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="600" top="0" wait="true" time="150"]

[:unknown:][s_playse storage="gon/full/3.ogg" buf=1]
「要是那样你一开始就该说出来。[rhr]
_　那样的话我们也能设计些更巧妙的演出桥段」[rhp]

[:drop:][p_d_34][drop kao=13 as=on ]
「抱歉。听南说你们也都知道了就以为...」[rhp]

[:princess:][puri_w kao=0 ]
「各位是什么人？南先生的朋友？」[rhp]

[off_drop]

;------------------------------------------------------------------------------------------
;▼再開▼
;ヌシ
[voconfig sebuf=1 name=nusi vostorage="nusi/full/{number}.ogg" number=5]
;魔太郎子
[voconfig sebuf=1 name=mata vostorage="mata/full/{number}.ogg" number=3]
;ゴンザレス一億世
[voconfig sebuf=1 name=gon vostorage="gon/full/{number}.ogg" number=4]
[vostart]
;------------------------------------------------------------------------------------------

[chara_part name="nusi" body=base kao=1 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="160" top="0" wait="true" time="150"]

[:nusi:][nusi ]
「我叫努西！是只可爱的兔子，专业玩柏青哥的」[rhp]

[:princess:][puri_w kao=5 as=on ]
「最后那句话让可爱度打折扣了啦……」[rhp]

[:nusi:][nusi kao=11 ]
「偶尔也玩老虎机！」[rhp]

[off_all]

[:gonzalez:][gon kao=11 ]
「不知其名且听我道来。滨之真砂与五右卫门……」[rhp]

[off_all]

[chara_part name="nusi" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="mata" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:nusi:]
「那边吊眼角的是小刚本名冈萨雷斯，[rhr]
_　这边是我们队唯一的红花魔太郎子」[rhp]

[:mataroko:]
「我是魔太郎子。[rhr]
_　请多关照，姐姐大人」[rhp]

[:princess:][puri_w kao=4 as=on hh=on ]
「咦？姐姐大人？」[rhp]

[:mataroko:][mata kao=4 as=on ]
「啊！对、对不起。您还失去着记忆呢。[rhr]
_　不愿意的话我就不这么叫了……」[rhp]

[:princess:][puri_w kao=13 as=on hh=on ]
「不、不是不愿意！只是有点惊讶」[rhp]
[:princess:]
「虽然不太明白，但以前应该就是这么称呼的吧？[rhr]
_　那就按以前的习惯来，随你喜欢就好」[rhp]

[:mataroko:][mata kao=14 hh=on ]
「姐姐大人……！非常感谢！」[rhp]

[off_all]

[::]
魔太郎子眼里泛着泪光，楚楚可怜地抬眼望着我。[rhr]
这孩子妹妹属性点满了，被陌生人叫「姐姐大人」也毫无违和感。[rhp]
不过说来，这个应该没有血缘关系的孩子居然叫我「姐姐大人」。[rhr]
以前的我究竟和这么小的孩子是什么关系……[rhp]
话说回来，这三个家伙到底是什么来头？」[rhp]

[:princess:][puri_w kao=0 ]
「呃、你们三人是这个游乐园的人……对吧？」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:drop:][drop ]
「不，他们是辗转于星际之间的……，[rhr]
_　呃——……算是表演者吧」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:princess:][puri_w ]
「就是所谓的流浪艺人啦！」[rhp]

[off_drop]

[:nusi:][nusi kao=11 ]
「嘛、差不多。[rhr]
_　不过我们只会去往你们前往之处」[rhp]

[:princess:][puri_w kao=0 ]
「为什么？」[rhp]

[:nusi:][nusi kao=13 ]
「没啥意义呗」[rhp]

[:princess:][puri_w kao=0 ]
「……？意义？」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[off_all]
[chara_part name="jet" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="hati" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:heartshape:][p_h_09]
「啊～～～～！够了，你们！自我介绍该结束了吧？」[rhp]
[:heartshape:]
「兔子！怪兽！女人！完毕！快去玩吧！」[rhp]

[:jet:][p_j_09]
「要让哈蒂等多久啊」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[chara_part name="nusi" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="gon" body=base kao=14 as=on ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:gonzalez:]
「哎呀，抱歉抱歉」[rhp]

[off_all]

[chara_part name="mata" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="421" top="0" wait="false" time="150"]
[chara_part name="puri_w" body=base kao=1 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:mataroko:]
「那、那个！姐姐大人」[rhp]
[:mataroko:]
「姐姐大人今天要和哪位一起行动呢？」[rhp]

[:princess:][puri_w kao=4 ]
「诶、难道接下来要分开行动？[rhr]
_　我还以为大家要一起呢」[rhp]

[off_mata]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[chara_part name="drop" body=base kao=1 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="riri" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="606" top="0" wait="true" time="150"]

[:quadrillion:][p_r_36]
「又不是小学生郊游，当然需要分组行动。[rhr]
_　按老规矩，18点在住宿地集合就行了吧」[rhp]

[:drop:][p_d_15][drop kao=5 hh=on ]
「是啊。这样应该没问题。[rhr]
_　今天订了酒店的套房哦！」[rhp]

[:quadrillion:][riri kao=14 hh=on ]
「不错嘛！不愧是领队！」[rhp]

[off_all]

[:princess:][puri_w kao=4 as=on ]
「酒店的……甜（套）……」[rhp]

[off_puri]

[::]
难道是甜的吗？用点心做的意思？[rhp]

[:kite:][p_k_17][kite kao=7 ]
「那就傍晚前自由活动吧。该怎么办呢……」[rhp]

[:vulpecula:][p_vl_04][peku body=hood kao=1 ]
「快斗～，一个人逛游乐园门槛太高了吧。[rhr]
_　佩奇和博士陪你一起玩怎样？」[rhp]

[:kite:][kite kao=13 ]
「不必了ー」[rhp]

[:darknebula:][hakase kao=13 msk=hat ]
「真是青春期呢」[rhp]

[:vulpecula:][peku body=hood kao=14 ]
「是呢～」[rhp]

[:kite:][p_k_27][kite kao=2 as=on]
「才不是啦～～～。能别闲着没事就来招惹我吗？」[rhp]

[off_all]

[:princess:][puri_w kao=7 ]
[font color=0x4682b4]
（嗯……要和谁一起呢……。[rhr]
_　沃尔佩克拉说得对，一个人行动确实需要勇气呢）[rhp]
[:princess:]
（嗯……）[rhp]
[resetfont]

[off_puri]

;----------------------------------------------------------------------------------
; 各ファイルへ
;----------------------------------------------------------------------------------

[::]
该怎么办？ 
;【ドロップ】
[glink clickse="btn_01.ogg" x="290" y="80" width="610" high="72" text="ドロップに声を掛ける" target="*sntk_a" graphic="glink_a.png" enterimg="glink_b.png"]
;【キキララ】
[glink clickse="btn_01.ogg" x="290" y="200" width="610" high="72" text="魔太郎子ちゃんの期待の眼差しが気になる" target="*sntk_b" graphic="glink_c.png" enterimg="glink_d.png"]
;【双子】
[glink clickse="btn_01.ogg" x="290" y="320" width="610" high="72" text="ゴンザレスくんの様子を見る" target="*sntk_c" graphic="glink_a.png" enterimg="glink_b.png"]
;【博士&ペク】
[glink clickse="btn_01.ogg" x="290" y="440" width="610" high="72" text="博士たちに相談する" target="*sntk_d" graphic="glink_c.png" enterimg="glink_d.png"]

[s]

;ジャンプ先-------------------------------------------------------------------------

*sntk_a
; 好感度+50
[eval exp="f.love_d = f.love_d + 50"]
[jump storage="ev_a_02_drop.ks" target="*start"]

*sntk_b
; 好感度+50
[eval exp="f.love_k = f.love_k + 50"]
[eval exp="f.love_r = f.love_r + 50"]
[jump storage="ev_a_02_kikirara.ks" target="*start"]

*sntk_c
; 好感度+50
[eval exp="f.love_h = f.love_h + 50"]
[jump storage="ev_a_02_hati.ks" target="*start"]

*sntk_d
[jump storage="ev_a_02_senpai.ks" target="*start"]

;----------------------------------------------------------------------------------
;----------------------------------------------------------------------------------

*return

[:drop:][drop kao=14 ]
「喂——！各位——」[rhp]

[:princess:][puri_w ]
「多洛普！」[rhp]

[:drop:][p_d_34][drop kao=13 ]
「哎呀，久等了真抱歉」[rhp]

[off_all]

[chara_part name="drop" body=base kao=13 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="riri" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="606" top="0" wait="true" time="150"]

[:quadrillion:][p_r_35]
「辛苦了。洗车顺利吗？」[rhp]

[:drop:][p_d_02]
「托您的福！那么这就前往今天的住处吧」[rhp]

[off_all]

[chara_part name="kite" body=base kao=7 as=off ss=off hh=on hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="160" top="0" wait="false" time="150"]
[chara_part name="hati" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:heartshape:][p_h_06]
「是套房啊！超期待的！」[rhp]

[:kite:][p_k_02]
「我能睡觉就行无所谓」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
;ヌシ
[voconfig sebuf=1 name=nusi vostorage="nusi/full/{number}.ogg" number=10]
;魔太郎子
[voconfig sebuf=1 name=mata vostorage="mata/full/{number}.ogg" number=8]
;ゴンザレス一億世
[voconfig sebuf=1 name=gon vostorage="gon/full/{number}.ogg" number=6]
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[chara_part name="mata" body=base kao=14 as=off ss=off hh=on hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="80" top="0" wait="false" time="150"]
[chara_part name="nusi" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="383" top="0" wait="false" time="150"]
[chara_part name="gon" body=base kao=14 as=off ss=off hh=on hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="720" top="0" wait="true" time="150"]

[:nusi:]
「嗯嗯，大家都太好了！」[rhp]
[:nusi:]
「那么今晚也尽情享受吧。[rhr]
_　明天见啦！」[rhp]

[:princess:][puri_w kao=0 ]
「咦？你们不去酒店吗？」[rhp]

[:nusi:][nusi kao=1 ]
「我们要回去啦。在此分别了」[rhp]

[:mataroko:][mata kao=6 ]
「明天一大早还要去排新机台呢」[rhp]

[:nusi:][nusi kao=6 as=on ]
「『明天见』不是刚说过吗！？[rhr]
_　到底想让我动摇到什么时候啊」[rhp]

[:princess:][puri_w kao=8 ]
「难得有机会一起住下就好了。真遗憾呢」[rhp]

[:mataroko:][mata kao=13 ]
「姐姐大人……真温柔呢。不过这样就可以了哦」[rhp]

[:gonzalez:][gon kao=5 ]
「啊啊。因为这就是我们的工作啊」[rhp]

[:princess:][puri_w kao=0 ]
「工作？」[rhp]

[:nusi:][nusi kao=5 ]
「没错！报酬就是你的笑容☆」[rhp]

[:mataroko:][mata kao=14 hh=on ]
「简直太完美了，努西大人！」[rhp]

[:gonzalez:][gon kao=14 ]
「来嘞！银河第一」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[off_all]

[:kite:][kite kao=5 ]
「说什么工作之类的漂亮话，[rhr]
_　其实不过是一群想闹腾的家伙罢了」[rhp]

[off_kite]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[chara_part name="mata" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="80" top="0" wait="false" time="150"]
[chara_part name="nusi" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="383" top="0" wait="false" time="150"]
[chara_part name="kite" body=base kao=8 as=on ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="760" top="0" wait="true" time="150"]

[:nusi:]
「还这么说～，明明其实最喜欢我们了吧？」[rhp]

[:mataroko:]
「真让人害羞呢！[rhr]
_　明天也要充满干劲地炒热气氛哦！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:kite:][p_k_27][kite kao=6 as=on ]
「是是。请各位自便」[rhp]

[off_all]

[:princess:][puri_w kao=13 hh=on ]
[font color=0x4682b4]
（呵呵呵……！真是热闹的一群人啊。[rhr]
_　光是待在一起就觉得很开心，感觉整个人都充满活力了）[rhp]
[resetfont]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:gonzalez:][gon ]
「听说今晚还要放例行的庆祝烟花呢。[rhr]
_　等天黑了务必抬头看看天空哦」[rhp]

[:princess:][puri_w ]
「真的吗？好厉害。真期待啊！」[rhp]

[off_gon]

[:princess:][puri_w kao=0 ]
[font color=0x4682b4]
（……话说，等等？『听说』是指谁说的呢。[rhr]
_　是这个游乐园的老板什么的……？）[rhp]
[resetfont]

[off_all]

[chara_part name="mata" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="80" top="0" wait="false" time="150"]
[chara_part name="nusi" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="383" top="0" wait="false" time="150"]
[chara_part name="gon" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="720" top="0" wait="true" time="150"]

[:nusi:]
「好啦，那我们差不多也该走了」[rhp]

[:gonzalez:]
「说的也是。可不能搞得阴沉沉的」[rhp]

[:mataroko:]
「各位。姐姐大人。日安！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[off_all]

[:princess:][puri_w hh=on ]
[font color=0x4682b4]
（真是群奇妙的人啊，这三位。[rhr]
_　明明性别年龄各不相同却如此亲密）[rhp]
[:princess:][puri_w kao=13 hh=on ]
（但是为什么呢。光是待在一起就让人心情愉快！）[rhp]
[resetfont]

[off_all]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:nusi:][nusi ]
「好啦好啦。那今天也按惯例来吧」[rhp]
[:nusi:][nusi kao=14]
「嘿咻！」[rhp]

[off_nusi]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
[se storage="mag_10.ogg"]
[bg_rule storage="white.jpg" rule="021.png" time=1000]
;****************************************

[::]
努西小姐轻轻摆动手指，他们的身影便消失在烟雾中。[rhp]

;****************************************
[bg_rule storage="park_09.jpg" rule="021.png" time=1000]
;****************************************

[:princess:][puri_w kao=4 hh=on ]
「――――！」[rhp]

[off_all]

[::]
不、不对！消失的其实是我们。[rhp]
不知不觉间，我们已置身于异常豪华的房间。[rhp]

;****************************************
[bg storage="park_10.jpg" time=1000]
;****************************************

[:vulpecula:][p_vl_27][peku kao=14 hh=on ]
「呀――――！这边软乎乎的好舒服！超级厉害！」[rhp]

[:heartshape:][p_h_14][hati kao=6 hh=on ]
「太狡猾了佩奇！我也想第一个飞扑进被窝啊！」[rhp]

[off_all]

[:darknebula:][p_da_31][hakase kao=14 hh=on ]
「我也要！」[rhp]

[off_hakase]

[chara_part name="jet" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="80" top="0" wait="false" time="150"]
[chara_part name="hakase" body=base kao=2 as=on ss=off hh=off hr=on msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720" left="355" top="0" wait="false" time="150"]
[chara_part name="hati" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="760" top="0" wait="true" time="150"]

[yurasu]

[:hutago:]
[font size=28]
「博士不行！」[rhr]
「博士不行！」[rhp]
[resetfont]

[:darknebula:][p_da_12][hakase kao=2 as=on ]
「为、为什么……！？[rhr]
_　我也想体验套房的飞扑感受啊」[rhp]

[:jet:][p_j_26][jet kao=6 ]
「博士体型太大，弹簧会坏掉的」[rhp]

[:darknebula:][p_da_11][hakase kao=3 as=on ]
「！！　呜……！　嘛、倒也是。[rhr]
_　再怎么想，也不该弄坏设备就为了……」[rhp]

[off_all]

[:drop:][p_d_31][drop kao=5 hh=on ]
「请放心！这是慢回弹材质！」[rhp]

[off_all]

;****************************************
;カットイン
;[s_image layer="2" page="back" storage="ct/a_02_1.png" width="1260" left="10" top="40" name="nov"]
;[s_trans layer="2" method="bounceInDown" time=500]
;[cg storage="ct/a_02_1.png"]
;[wt]
;****************************************

[yurasu]
[se storage="body_07.ogg"]

[:darknebula:]
[font size=33]
「哇―――――！！」[rhp]
[resetfont]

[off_all]

;****************************************
;[s_freeimage layer="2" ]
;****************************************

#
[bg storage="park_09.jpg" time=1000]

[::]
在惊叹房间宽敞的同时，我手足无措地四下张望着，[rhr]
我们从卧室直接来到相连的客厅。[rhp]
这个房间的装潢也同样过分豪华绚丽，[rhr]
简直让我感觉自己成了某个国王！[rhp]

[:princess:][puri_w kao=4 as=on hh=on ]
「这、这就是套房……！[rhr]
_　比点心还要厉害100倍呢！」[rhp]

[:kite:][p_k_19][kite kao=0 ]
「点心？」[rhp]

[:princess:][puri_w kao=14 as=on hh=on ]
「诶嘿嘿。其实我以为套房的sweet是甜的意思……」[rhp]

[:kite:][p_k_17][kite kao=7 ]
「……嘛我以前也这么想过……」[rhp]

[:princess:][puri_w kao=5 as=on hh=on ]
「对、对吧！？听到sweet就会这么想吧？」[rhp]

[:kite:][p_k_21][kite kao=2 as=on hh=on ]
「等……这种事不适合大声说出来。[rhr]
_　太羞耻了能别说吗？」[rhp]

[off_all]

[:quadrillion:][p_r_31][riri kao=5 ]
「虽然很抱歉打断你感动，[rhr]
_　但只有你要住十楼下的平民房间哦～」[rhp]

[:princess:][puri_w kao=2 as=on ]
「嗯？」[rhp]

[:quadrillion:][p_r_02]
「这里就作为男生宿舍交给我们使用啦」[rhp]

[:princess:][puri_w kao=6 as=on ]
「诶！？什么意思！？那佩奇呢！？」[rhp]

[:quadrillion:][p_r_15][riri kao=7 ]
「当然是和监护人的博士一起住咯」[rhp]
[:quadrillion:][riri kao14 ]
「哼哼，这不是挺好的嘛！[rhr]
_　就算是商务酒店的单人间，一个人住也有国王的感觉呢。呵呵呵」[rhp]

[:princess:][puri_w kao=2 ss=on as=on ]
「这、这种明目张胆的阴湿刁难～～～……！」[rhp]

[:drop:][p_d_31][drop kao=13 ]
「没问题的公主。请别担心！[rhr]
_　男女同住存在伦理问题，不过用魔法可以无限增加寝室啦！」[rhp]

[:princess:][puri_w kao=5 ]
「不愧是多洛普！和某些人妖的器量就是不同呢」[rhp]

[:quadrillion:][p_r_18][riri kao=6 as=on ]
「啧……！明明就差一点了」[rhp]

[off_all]

[chara_part name="hakase" body=base kao=5 as=off ss=off hh=on hr=on msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time="150"]
[chara_part name="peku" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time="150"]

[:vulpecula:][p_vl_04]
「博士博士！我们一起去房间探险吧！[rhr]
_　你看这里金光闪闪的，说不定能找到宝藏哦」[rhp]

[:darknebula:][p_da_10][hakase kao=5 hh=on ]
「明明是酒店顶层却说"埋藏"金……！？[rhr]
_　太浪漫了！让我们彻底解开这个矛盾吧！」[rhp]

[off_all]

[chara_part name="jet" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="hati" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:heartshape:][p_h_06]
「好啊好啊！我也要去！」[rhp]

[:jet:][p_j_24]
「哈蒂去的话我也去」[rhp]
[:jet:][jet kao=7 ]
「公主你呢？要一起来吗？」[rhp]

[:princess:][puri_w kao=4 hh=on ]
「！真的可以吗？那我去！」[rhp]

[off_all]

[:quadrillion:][riri kao=6 as=on ]
「哎呀呀。那些家伙真是孩子气到极点」[rhp]
[:quadrillion:]
「我们去那边吧快斗。[rhr]
_　要是配合那群家伙的节奏会传染傻气的」[rhp]

[off_all]

[chara_part name="jet" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="kite" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time="150"]

[:kite:][p_k_04][kite kao=13 ]
「喂杰特。我现在要把嚼着的口香糖藏起来，[rhr]
_　要顺便玩寻宝游戏吗？」[rhp]

[:jet:][p_j_10][jet kao=2 as=on ]
「别突然想出这种黑暗游戏啊……」[rhp]

[off_all]

[:quadrillion:][p_r_09][riri kao=2 as=on ]
「真是的～～～～！这群家伙！」[rhr]
_　就没有能好好享受奢华时光的大人吗！？」[rhp]

[off_all]

[chara_part name="drop" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="riri" body=base kao=2 as=on ss=off hh=off hr=on hat=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="606" top="0" wait="true" time="150"]
[p_r_21]
「多洛普！现在只能靠你了！[rhr]
_　你不会掺和到小鬼们的游戏里对吧！？」[rhp]

[:drop:][p_d_01]
「嗯。因为想确认今后的流程」[rhp]

[:quadrillion:][p_r_06][riri kao=14 hh=on ]
「不愧是社畜～！我唯一的同伴！[rhr]
_　今天咱们喝个通宵吧！」[rhp]

[:drop:][p_d_04][drop kao=8 as=on ]
「你们有在听吗！？我还有工作要……」[rhp]

;****************************************
;敷地内カフェ
[set_yy storage="park_05n.jpg"]
[filter layer="1" brightness="60"]
;****************************************

…………那时。[rhp]
夜晚的游乐园咖啡馆里，三人各自手持酒杯的身影。[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[s_playse storage="nusi/full/19.ogg" buf=1]
[s_playse storage="mata/full/13.ogg" buf=1]
[s_playse storage="gon/full/10.ogg" buf=1]
[vostart]
;------------------------------------------------------------------------------------------

[:nusi:]
「好～～～～了……」[rhp]

[chara_part name="mata" body=base kao=14 as=off ss=off hh=on hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="80" top="0" wait="false" time="150"]
[chara_part name="nusi" body=base kao=14 as=off ss=off hh=on hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="383" top="0" wait="false" time="150"]
[chara_part name="gon" body=base kao=14 as=off ss=off hh=on hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="720" top="0" wait="true" time="150"]

[:nusi:]
「今天也辛苦啦～～！」[rhp]

[:mataroko:]
「辛苦您了！」[rhp]

[:gonzalez:]
「今天可真是够累人的啊」[rhp]

[:nusi:][nusi kao=5 ]
「虽然公主记忆的事让人吃惊，[rhr]
_　但只要她像平常一样开心就再好不过了」[rhp]

[:gonzalez:][gon ]
「是啊。能和往常一样就是最好的」[rhp]

[:mataroko:][mata kao=3 as=on ]
「倒是那份天真更变本加厉了呢」[rhp]
[:mataroko:][mata kao=13 ]
「不过，总觉得也很让人高兴。[rhr]
_　那样的姐姐大人，我们最喜欢了」[rhp]

[:nusi:][nusi kao=11 ]
「确实啊。......我也不知为何怀念起来了」[rhp]
「那才正是我们认识的公主」[rhp]

[:gonzalez:][gon kao=5 ]
「别感伤啊大哥。[rhr]
_　摆这种表情会走霉运的」[rhp]

[:nusi:][nusi ]
「哎呀说得对。我这是怎么了」[rhp]

[off_all]

;****************************************
#
[bg storage="sky_07.jpg" time=300]
;****************************************

[:nusi:]
「......好嘞！明天也要彻底嗨起来啊！」[rhp]

[:2nin:]
[s_playse storage="mata/full/16.ogg" buf=1] 
[s_playse storage="gon/full/13.ogg" buf=2] 
「哦！」[rhr]
「喔！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
[set_b storage="park_03p.jpg"]
;****************************************

另一方面，在别处―――[rhp]

[:sausu:][p_s_31][sausu kao=13]
「…………呵呵！」[rhp]
[:sausu:]
「能听见哦，大家的心声。[rhr]
_　看来这次旅行也让大家尽兴了呢！」[rhp]
[:sausu:][[sausu kao=11]
「多洛普的魔法真是厉害。就算我不在身边也能放心。[rhr]
_　那条铁道果然只能交给他呢」[rhp]

[off_sausu]

[:sausu:]
「…………不过，最终轮到我出场了！」[rhp]

;****************************************
#
[bg_rule storage="sky_10.jpg" rule="003.png" time=500]
[se storage="se3_09.ogg"]
;****************************************

[:sausu:]
「瞧！」[rhp]

;****************************************
#
[free_filter ]
[bg storage="park_09.jpg" time=1000]
;****************************************

[:princess:][puri_w kao=4 hh=on ]
「啊……！　这个声音，难道是！」[rhp]

[:drop:][p_d_23][drop kao=14 ]
「是烟花呢。机会难得，大家一起去阳台观赏吧」[rhp]

[:princess:][puri_w kao=5 hh=on ]
「嗯！」[rhp]

[off_all]

;****************************************
#
[bg storage="sky_10.jpg" time=1500]
[filter layer="1" brightness="60"]
;****************************************

[se storage="se3_09.ogg"]

[:sausu:]
「……嗯！　连我自己都觉得今天安排得太完美了」[rhp]
[:sausu:]
「果然烟花是好东西。[rhr]
_　五彩缤纷，喧嚣热烈，连寂寞的心情都会变得绚烂哦」[rhp]

;****************************************
#
[bg storage="park_03h.jpg" time=1000]
;****************************************

[:sausu:][sausu kao=13]
「游乐园就该这样。不知道大家是否开心呢」[rhp]
[:sausu:][sausu kao=11]
「呵呵……要是这样就太好了。对我来说这就……」[rhp]

[off_sausu]

;****************************************
[fse]
[fbgm]
[set_b storage="park_04n.jpg"]
;****************************************

――――而在更远的另一处。[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[bgm storage="bgm_19.ogg"]

[:unknown:][s_playse storage="yabu/full/1.ogg" buf=1]
「哼！　低俗的烟花……」[rhp]

;****************************************
;スチル
[still storage="cg/a_02_1.png" rule="021.png" width="1280" height="720" time=1000]
[cg storage="cg/a_02_1.png"]
;****************************************

[:yabu:]
「―――米卡亲也这么觉得吧？」[rhp]

[:mika:]
「诶～？我觉得很美呀」[rhp]

[:yabu:]
「当年那个男人对还是懦夫的我这样说……[rhr]
_　粉红色的烟花，是最下等的烟花！」[rhp]

[:mika:]
「这是从别人那里听来的台词吧？」[rhp]

[:yabu:]
「谁知道呢。如今的我已不明白，为何要将这美丽的烟花刻意称作污秽……[rhr]
_　那真正的意图唯有那个男人才知晓。虽然早已没有确认的方法了……」[rhp]

[:mika:]
「那就、看场漂亮的烟花不也挺好吗」[rhp]

[:yabu:]
「嘛，这样也不错！哈哈哈！」[rhp]

[:mika:]
「唔呵呵呵呵♡」[rhp]

;****************************************
[still_end frame="win.png" storage="park_04n.jpg" rule="004.png" time=200]
;****************************************

[stopbgm]

[chara_part name="yabu" body=base kao=2 as=on ss=on hh=off hr=on ]
[chara_show name="yabu" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="mika" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="mika" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[bgm storage="bgm_38.ogg"]

[:yabu:]
[font size=25]
「才不是――――这样！！[rhr]
[resetfont]
_　我们在悠闲地观赏什么烟花啊，我们可是要——！」[rhp]


[:mika:][mika kao=7 ]
「是老师您说的啦～说要不要稍微停下来一下」[rhp]

[:yabu:][yabu kao=6 as=on ]
「我可没说停下来观赏烟花这种话！[rhr]
_　那是指为了制定后续作战计划而提议暂时休整的意思啊！」[rhp]
[:yabu:]
「我们、从白天就已经来到这里了吧？[rhr]
_　然后像这样一直待到深夜，我们究竟做了什么？」[rhp]
[:yabu:]
「什么都没做啊！我们在这里普通地吃着软冰淇淋，[rhr]
_　普通地逛着商店享受……！」[rhp]
[:yabu:]
「到底怎么回事！你手里那些大量的纸袋是什么！？」[rhp]

[:mika:][mika kao=14 ]
「这个世界真开心呀♡购买欲都得到满足啦～」[rhp]

[:yabu:][yabu kao=2 as=on ]
「别沉浸其中！我们可不是来玩的！[rhr]
_　首先，为什么我必须来指出这种事啊」[rhp]
[:yabu:]
「本来这应该是你的职责才对……」[rhp]

[:mika:][mika kao=4 ]
「啊！老师，脸颊沾上抹茶奶油了」[rhp]

[:yabu:][yabu kao=6 as=on ]
「咦？真的吗？大概在什么位置？」[rhp]

;****************************************

[se storage="se7_31.ogg"]

;カットイン
[s_image layer="2" page="back" storage="ct/a_02_2.png" width="1260" left="10" top="40" name="nov"]
[s_trans layer="2" method="bounceInDown" time=1000]
[cg storage="ct/a_02_2.png"]
[wt]
;****************************************

[:mika:]
「『对不起啦♡　噗♡』」[rhp]

[:yabu:]
「…………」[rhp]

;****************************************
;カットイン終了
[s_freeimage layer="2" ]
;****************************************

[:mika:][mika kao=14 hh=on ]
「好可爱～！老师看这边♡[rhr]
_可以拍照吗？」[rhp]

[off_all]

[:yabu:][yabu kao=6 as=on ss=on ]
「当然不行啊……！？别太过分了，」[rhp]

;シャッター音
[se storage="se4_06.ogg"]

[chara_part name="yabu" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="yabu" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="mika" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="mika" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:mika:]
「来～看这里♡　一起说，噗♡」[rhp]

[:yabu:]
「不许擅自拍双人照！立刻删除！」[rhp]

[:mika:][mika kao=11 ]
「不要～我要把这张设成米卡亲的手机壁纸～」[rhp]

[off_all]

;走る
[se storage="leg_04.ogg"]

[:yabu:][yabu kao=8 as=on ]
「啊……！喂，米卡亲快停下！」[rhp]

[off_yabu]

[:mika:][mika kao=4 as=on ]
「诶？……呀！」[rhp]

[fbgm]

;誰かにぶつかる
[yurasu]
[se storage="body_01.ogg"]
[off_all]

[:mika:][mika kao=8 as=on ]
「好痛……对不起。撞到你了……」[rhp]

[off_mika]


;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:yoru:][p_y_05][yoru kao=6 ]
「…………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_yoru]

[:mika:][mika kao=5 as=on ss=on ]
「――――！！噫……」[rhp]

[off_mika]

[:yabu:][yabu kao=6 as=on ]
「来晚了吗……」[rhp]

[off_yabu]

[bgm storage="bgm_19.ogg"]

[chara_part name="mika" body=base kao=5 as=on as=on ss=off hh=off hr=on ]
[chara_show name="mika" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="yoru" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time="150"]

[:yoru:]
「……哈」[rhp]

[:mika:]
「夜、夜、夜君……原来你在啊……」[rhp]

[:yoru:]
「嗯」[rhp]
[:yoru:]
「……玩得真开心啊。成年人还玩追逐游戏」[rhp]

[:mika:][mika kao=13 as=on ]
「只是单方面被追着跑啦～」[rhp]

[off_all]

[:yabu:][yabu kao=2 as=on ]
「胡说！根本就是你惹的祸」[rhp]

[off_yabu]

[:yoru:][yoru kao=6 ]
「怎样都无所谓。……所以？」[rhp]

[off_yoru]

[chara_part name="yabu" body=base kao=0 as=on as=on ss=off hh=off hr=on ]
[chara_show name="yabu" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="yoru" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time="150"]

[:yoru:]
「你会在这种地方消磨时间，[rhr]
_说明今天总算有收获了吧」[rhp]

[:yabu:][yabu kao=5 as=on ]
「啊，这个………」[rhp]

[:yoru:][yoru kao=2 ]
「……不必多问了」[rhp]

[off_all]

[:mika:][mika kao=2 as=on ]
「没、没有啦！我成功选到了最适合夜君的礼物哦」[rhp]

[off_mika]

[:yabu:][yabu kao=2 as=on ss=on ]
「诶！？啥！？」[rhp]

[off_yabu]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:yoru:][p_y_02][yoru kao=6 ]
「…………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_yoru]

[chara_part name="yabu" body=base kao=2 as=on ss=on hh=off hr=on ]
[chara_show name="yabu" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="mika" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="mika" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:yabu:][font size=13 color=0x4682b4]
（笨蛋！干嘛这么老实说出来啊！[rhr]
_　这种报告稍微润色一下也没关系啦）[rhp]

[:mika:]
（因为夜君很敏锐所以那种做法没用的！[rhr]
_　不如用礼物讨好他更划算呢）[rhp]
[resetfont]

[off_all]

[:yoru:][yoru kao=3 ]
「……哈啊……」[rhp]

[off_all]

[chara_part name="mika" body=base kao=5 as=on as=on ss=off hh=off hr=on ]
[chara_show name="mika" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="yoru" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time="150"]

[:yoru:]
「…………让我看看。那个所谓的礼物」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:mika:][mika kao=14 as=on ][p_mk_02]
「好～的♡」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

;****************************************
;カットイン
[s_image layer="2" page="back" storage="ct/a_02_3.png" width="1260" left="10" top="40" name="nov"]
[s_trans layer="2" method="bounceInDown" time=1000]
[cg storage="ct/a_02_3.png"]
[wt]
;****************************************

[:mika:]
「这个、这个、还有这个和这个呢」[rhp]

[off_all]

[:yabu:]
[font color=0x4682b4]
（为什么都不是点心类……她是想自杀吗……）[rhp]
[resetfont]

[:yoru:]
「这是什么？……有张猫脸」[rhp]

[:mika:]
「啊！那个发圈很可爱吧？[rhr]
_　夜君头发长，吃饭时能快速扎起来很方便哦」[rhp]

[:yoru:]
「你要我戴这个」[rhp]

[:mika:]
「还有那个头巾也很棒吧！」[rhp]
[:mika:]
「正面缝着和发圈同款小猫脸的啦。[rhr]
_　用这个的话每天的洗脸时间肯定会变得超开心！」[rhp]
[:mika:]
「这边是猫耳发箍哦！[rhr]
_　虽然只有可爱这个优点，但可爱就够了吧！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:yoru:]
「…………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

;****************************************
[s_freeimage layer="2" ]
;****************************************


[:yabu:][yabu kao=2 as=on ss=on ]
[font color=0x4682b4]
（挑战者米卡亲……！我不会让你的勇气白费……）[rhp]
[resetfont]

[off_yabu]

[chara_part name="mika" body=base kao=0 as=on as=on ss=off hh=off hr=on ]
[chara_show name="mika" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="yoru" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time="150"]

[:yoru:]
「……谢谢」[rhp]

[off_all]

[:yabu:][yabu kao=4 as=on ]
「哎！？」[rhp]

[off_yabu]

[chara_part name="mika" body=base kao=0 as=on as=on ss=off hh=off hr=on ]
[chara_show name="mika" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="yoru" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time="150"]

[:yoru:]
「有兴趣时再用。除了那对耳朵」[rhp]

[:mika:][mika kao=13 ]
「呜、好开心～！全都是和米卡亲同款的哟♡ 我们一起用吧♡」[rhp]
[:mika:]
[font color=0x4682b4]
（反正之后补买就能凑成一对。我可没说谎。只是不需要耳朵而已）[rhp]
[resetfont]

[off_all]
[fbgm]

[:yoru:][yoru kao=12]
「…………好了」[rhp]

[off_yoru]

[bgm storage="bgm_15.ogg"]

[chara_part name="yoru" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="60" top="0" wait="false" time="150"]
[chara_part name="yabu" body=base kao=4 as=on ss=off hh=off hr=on ]
[chara_show name="yabu" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:yoru:]
「……矢部」[rhp]

[:yabu:][yabu kao=5 as=on ]
「啊、啊啊！名医大人，怎么了」[rhp]

[:yoru:]
「她轻率的行动是你的监督不力」[rhp]

[:yabu:][yabu kao=6 as=on ]
「诶"！？怎么变成我的责任了！？」[rhp]

[:yoru:]
「你能使用的魔法力量，不过是借用了我的部分力量。[rhr]
_　……我好不容易才恢复些力量，特意分给了你」[rhp]
[:yoru:]
「无用的棋子没有存在价值。[rhr]
_　若不想被判定为废物，就采取冷静合理的行动」[rhp]

[:yabu:][yabu kao=8 as=on ]
「对、对不起……」[rhp]

[off_all]

[chara_part name="mika" body=base kao=11 as=off ss=off hh=off hr=on ]
[chara_show name="mika" layer="1" width="437" height="720" left="80" top="0" wait="false" time="150"]
[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="293" top="0" wait="false" time="150"]
[chara_part name="yabu" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yabu" layer="1" width="437" height="720" left="760" top="0" wait="true" time="150"]

[:mika:]
「没关系的夜君」[rhp]

[:yoru:][yoru kao=6 ]
「什么叫没关系？具体能保证今后哪些方面不出问题」[rhp]

[:mika:][mika kao=5 ]
「因为我和老师都还没动真格！"[rhr]
_　还能进一步提升力量呢！」[rhp]
[:mika:]
「对吧老师！？」[rhp]

[:yabu:][yabu kao=5 as=on ]
「……！啊、啊啊！当然。今天确实有点得意忘形了」[rhp]

[:yoru:][yoru kao=2 ]
「你哪天不是得意忘形」[rhp]

[:yabu:][yabu kao=8 as=on ]
「唔咕……！」[rhp]

[off_all]

[:yoru:][yoru kao=7 ]
「…………今天恐怕没指望了」[rhp]
[:yoru:][yoru kao=6 ]
「下次给我认真点。我受够这种敷衍了」[rhp]

[off_yoru]

[:yabu:][yabu kao=5 as=on ]
「我、我知道了。下次一定会回应期待的！」[rhp]

[off_yabu]

[chara_part name="mika" body=base kao=1 as=on as=off ss=off hh=off hr=on ]
[chara_show name="mika" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time="150"]

[:mika:]
「呐夜君。难得的机会要不一起看烟花？」[rhp]

[:yoru:][yoru kao=3 ]
「不必。……不堪入目」[rhp]

[off_all]

[:yabu:][yabu kao=5 ]
「呵，嫌烟花肮脏？」[rhp]

[:yoru:][yoru kao=2 ]
「正是」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:yabu:][yabu kao=0 as=on ]
「！」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:yoru:]
「……每次都令人作呕。[rhr]
_　夜空怎会有彩虹……那碍眼又令人不快的颜色」[rhp]

[:yabu:][yabu kao=6 as=on ]
[font color=0x4682b4]
（这会儿倒不好说他只是嘴硬逞帅……）[rhp]
[resetfont]

[off_all]

[:yoru:][yoru kao=2 ]
「重申一遍，不必对我有任何顾虑。[rhr]
_　我只要夺取那条铁道就够了」[rhp]
[:yoru:]
「无论事态如何发展，我都不会认可南。仅此而已」[rhp]

[off_all]

[:yoru:]
「……期待你今后的表现。告辞」[rhp]

;消える
[s_mask color="0x000000" rule="009.png"]
[::]
[s_wait time=1000]
[s_mask_off rule="009.png"]

[:mika:][mika kao=3 ]
「走掉了。今天也好冷淡呢，夜君」[rhp]

[:yabu:][yabu kao=2 as=on ]
「哈……！米卡亲，你怎么能这么天不怕地不怕。[rhr]
_　我心脏都快停跳了！」[rhp]
[:yabu:]
「看到那冰锥般的眼神了吗？根本不敢直视！」[rhp]

[:mika:][mika kao=6 ]
「那不就是没看嘛」[rhp]

[:yabu:][yabu kao=6 ]
「瞥了一眼啦。[rhr]
_　就像，你看。用余光懂吗？就这样，突然瞥到！」[rhp]

[:mika:][mika kao=13 ]
「是是。厉害厉害」[rhp]
[:mika:][mika kao=7 ]
「所以，怎么办？[rhr]
_　都被夜君严肃警告过了」[rhp]
[:mika:]
「那些孩子、明天似乎也会在这个游乐园游玩哦。[rhr]
_　我们要不要也准备些机关呢？」[rhp]

[:yabu:][yabu kao=5 ]
「呵呵呵……！[rhr]
_　其实关于这点、我已经拟定好作战计划了」[rhp]

[:mika:][mika kao=5 hh=on ]
「哎呀！老师好厉害～！」[rhp]

[:yabu:][yabu kao=5 ]
「没错吧？真不愧是名医呢」[rhp]
[:yabu:]
「听说今晚那群人会住在游乐园园区内的酒店！[rhr]
_　趁此机会在车内设置陷阱、制造让他们不得不放弃铁道的局面！」[rhp]

[:mika:][mika kao=13 ]
「嘿、总觉得比往常更带真实感了呢。[rhr]
_　那我们现在就开始值夜班吧」[rhp]

[:yabu:][yabu kao=6 ]
「唔！这可不行。米卡亲你给我乖乖回去」[rhp]
[:yabu:]
「你今天上的白班吧。连续接着值夜班简直岂有此理！[rhr]
_　不能让女性承担如此繁重的劳动。医疗现场必须保持洁净才行」[rhp]

[:mika:][mika kao=0 ]
「老师不留下吗？」[rhp]

[:yabu:][yabu kao=11 ]
「我可是男人、还从夜那里获得了魔法之力。[rhr]
_　这种程度的疲劳根本不值一提！」[rhp]
[:yabu:][yabu kao=1 ]
「快去、米卡亲！错过末班车可就糟了！」[rhp]

[:mika:][mika kao=0 ]
「啊、谢谢您…………」[rhp]

[:yabu:][yabu kao=11 hh=on ]
[font color=0x4682b4]
（呼哈哈……！是被我精妙的安排折服了吗？[rhr]
_　像我这样的男人，真是罪孽深重啊……！）[rhp]

[:mika:][mika kao=6 as=on ]
（……不要紧吧。把冒失的矢部亲一个人丢在那里……）[rhp]
[:mika:][mika kao=13 ]
（……、……算了算了。他干劲十足，就当试试看吧！）[rhp]
[resetfont]


;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
#
[fbgm]
[set_yy storage="sky_07.jpg"]

游乐园之星　滞留第2天[rhp]

[bg storage="park_01n.jpg" rulu="002" time=1000]
;****************************************

[bgm storage="bgm_01.ogg"]

[filter layer="1" brightness="70"]

我们从早上开始就尽情玩耍了一整天。[rhr]
入夜时分，到了该回去的时间，大家在入口处集合。[rhp]

[:drop:][drop ]
「各位都到齐了吗？」[rhp]

[off_all]

[chara_part name="jet" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="hati" body=base kao=11 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:hutago:]
「好啊——！」[rhr]
「到——」[rhp]

[off_all]

[:drop:][p_d_17][drop ]
「杰特先生一行，快斗先生和夸德里利昂……[rhr]
_　博士和沃尔佩克拉小姐、公主……好，全员到齐了呢」[rhp]

[off_all]

[chara_part name="riri" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time="150"]
[chara_part name="jet" body=base kao=8 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:jet:][p_j_18]
「哇啊。克林你拿的什么行李啊？[rhr]
_　拎着超多袋子嘛」[rhp]

[:quadrillion:][p_r_15][riri kao=14 ]
「说到游乐园，成年人比起游乐设施更应该购物逛店啦～。[rhr]
_　被气氛感染，不小心就买了好多呢」[rhp]
[:quadrillion:]
「难得快斗也主动帮忙搬行李了。[rhr]
_　明明有布兹这个劳动力就够了的说」[rhp]

[off_all]

[:kite:][p_k_02][kite kao=3]
「实在看不下去新人女孩被性格恶劣的人妖欺负……」[rhp]

[off_kite]

[:quadrillion:][riri kao=6 ]
「什、什么呀。不过稍微让你帮了点忙而已……」[rhp]

[:princess:][puri_w kao=3 as=on ]
「哈啊～～……！肩膀好痛……绝对会肌肉酸痛的」[rhp]

[:quadrillion:][p_r_09][riri kao=2 as=on ]
「真是的，都道歉了啦……」[rhp]
[:quadrillion:]
「啊等一下。这里面有一半是你的行李吧？[rhr]
_　我、才绝对不会买那么蓬松的猫咪玩偶啦」[rhp]

[:princess:][puri_w kao=5 hh=on ]
「说的对！这是我的。[rhr]
_　被使唤的期间偷偷购物，结果就变成这样了」[rhp]

[:quadrillion:][p_r_29][riri kao=6 as=on ]
「真会钻空子呢。气死人了」[rhp]

[off_all]

[:drop:][p_d_06][drop kao=13 ]
「呵呵……！大家玩得开心比什么都好」[rhp]

[:vulpecula:][p_vl_31][peku body=hood kao=14 hh=on ]
「嗯嗯！这次的旅行超棒！[rhr]
_　现在要说再见，总觉得有点寂寞呢」[rhp]

[:princess:][puri_w kao=13 ]
「是啊。好想再来游乐园呢」[rhp]

[:vulpecula:][p_vl_24][peku body=hood kao=5 hh=on ]
「小姬也这么想？[rhr]
_　我也是啊，甚至恨不得明天就再来！」[rhp]

[:drop:][p_d_22][drop kao=13 as=on ]
「明天实在不行呢……下次要去的是夸德里利昂的候选地，[rhr]
_　不如期待那边如何？」[rhp]

[if exp="f.senpai == 1 "]
[jump target="*nomal2"]
[endif] 

;先輩選択以外------------------

[:princess:][puri_w kao=4 as=on hh=on ]
「小姬？」[rhp]

[:vulpecula:][p_vl_01][peku body=hood kao=14 ]
「哎嘿嘿！告诉你哦、这是我想出来的昵称！[rhr]
_　因为是公主殿下（Princess），所以就叫小姬啦！」[rhp]
[:vulpecula:]
「小姬和小佩是配套的哟。[rhr]
_　我可是小姬的前辈客人啦。想着要多关照你哟！」[rhp]

[:princess:][puri_w kao=14 hh=on ]
「啊、谢谢……！莫名有点害羞了」[rhp]

[:vulpecula:][p_vl_16][peku body=hood kao=13 ]
「叫我姐姐也可以哟？小姬！」[rhp]

[:princess:][puri_w kao=5 as=on hh=on ]
「那、那样实在太羞人了啦！」[rhp]

[:vulpecula:][p_vl_31][peku body=hood kao=14 hh=on ]
「和公主大人一起～♪ 坐摩天轮～♪ 每天！每分！」[rhp]

[:drop:][p_d_17][drop kao=13 as=on ]
「每天确实有点勉强……不过下次是夸德里利昂的希望地点，[rhr]
_　不如期待那边如何？」[rhp]

; ------------------------------

*nomal2

[:princess:][puri_w kao=1 ]
「诶。下次轮到克林决定啊。原来是轮流制呢」[rhp]

[off_all]

[:quadrillion:][p_r_15][riri kao=5 ]
「敬请期待。这次本小姐会带你们去真正的度假胜地哦」[rhp]

[off_riri]

[chara_part name="jet" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="hati" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:heartshape:][p_h_02]
「上次去的是乌尤尼盐湖对吧！[rhr]
_　就是经常用在动漫主视觉图的那个地方！」[rhp]

[:jet:][p_j_02]
「大人挑选的真正度假胜地(笑)，我好好期待着呢！」[rhp]

[off_all]

[:quadrillion:][p_r_21][riri kao=2 as=on ]
「叽～～～～！下次可是超级认真的度假哦！」[rhp]

[off_riri]

[:drop:][p_d_32]
「各位～！差不多要出发了！请尽快登上列车」[rhp]

[::]
被先上车厢的多洛普先生催促着，我们赶忙走向乘车口。[rhp]
好咧，回房间后要把玩偶放进卧室里……[rhp]

[:yabu:][yabu kao=11 ]
「…………」[rhp]

[yurasu]

[:princess:][puri_w kao=2 as=on ss=on ]
「哇啊啊啊啊啊啊！有人死了！！！」[rhp]

[:darknebula:][p_da_13][hakase kao=7 msk=hat ]
「哎呀。是矢部医生」[rhp]

[:princess:][puri_w kao=4 as=on ]
「！？认、认识的人？」[rhp]

[off_all]

[chara_part name="jet" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="hati" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:heartshape:][p_h_02]
「没错！这可是名医庸医啊！」[rhp]

[:princess:][puri_w kao=6 as=on ]
「嗯？」[rhp]

[:jet:][p_j_02]
「虽然有点笨手笨脚又自大，[rhr]
_　但还算是个靠谱的医生啦」[rhp]

[:princess:][puri_w kao=2 as=on ]
「听起来前后有点矛盾啊……」[rhp]

[off_all]

[chara_part name="riri" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time="150"]
[chara_part name="hakase" body=base kao=5 as=off ss=off hh=off hr=on msk=hat ]
[chara_show name="hakase" layer="1" width="571" height="720" left="600" top="0" wait="true" time="150"]

[:darknebula:][p_da_14]
「又跟踪我们然后像往常一样搞砸了吧」[rhp]

[:quadrillion:]
「叫醒他的话应付起来很麻烦，先丢外面放着吧」[rhp]

[off_all]

;蹴る
[se storage="hand_05.ogg"]
[yurasu]

[:quadrillion:]
[font size=29]
「嘿——！」[rhp]
[resetfont]

[::]
夸德里利昂的脚毫不留情地将矢部医生的身躯从车厢踹落。[rhr]
矢部医生砸向地面扬起沙尘……[rhp]

[yurasu]

[:yabu:][p_yb_17]
「呜呃！！」[rhp]

[:princess:][puri_w kao=2 as=on ss=on ]
「！！　快醒……」[rhp]

[off_puri]

[:yabu:][yabu kao=12 as=on ]
「嗯唔……？呜嗯～～～……」[rhp]

[off_yabu]

[:princess:][puri_w kao=6 as=on ]
「……居、居然没醒。明明摔得挺狠的」[rhp]

[:darknebula:][p_da_23][hakase msk=hat ]
「肯定是熬夜累坏了。让他睡会儿吧」[rhp]

[:princess:][puri_w kao=2 as=on ]
「熬、熬夜？为什么？做什么？」[rhp]

[:darknebula:][p_da_20][hakase kao=5 msk=hat ]
「谁知道？说不定设了什么陷阱」[rhp]

[off_all]

[chara_part name="jet" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="hati" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:heartshape:][p_h_06]
「开始检修车厢喽，杰特！[rhr]
_　看谁先找出矢部亲的陷阱！！」[rhp]

[:jet:][p_j_06]
「不会输给你的，哈蒂！」[rhp]

[off_all]

[::]
这对搭档全然不顾脚下伸展的人体，利落地登上了车厢。[rhr]
受他们影响，其他人也窸窸窣窣地消失在车厢内。[rhp]
我正想跟上队伍，最后一个踏进车厢时……[rhp]
……又回头望了一眼。[rhp]

[:princess:][puri_w kao=6 as=on ]
「……那个人，真的可以那样放着不管吗」[rhp]

[chara_part name="riri" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time="150"]
[chara_part name="kite" body=base kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time="150"]

[:kite:][p_k_01]
「如果是米卡亲的话肯定会搞更过火的事。[rhr]
_　今天矢部亲是单独作案吧」[rhp]

[:quadrillion:][p_r_03]
「这种程度对我们根本不痛不痒呢」[rhp]

[:princess:][puri_w kao=2 as=on ]
「这里的人，认识的净是些怪人呢……」[rhp]

[off_all]

[chara_part name="hakase" body=base kao=1 as=off ss=off hh=off hr=on msk=hat ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time="150"]
[chara_part name="peku" body=hood kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="645" top="0" wait="true" time="150"]

[:darknebula:][p_da_09]
「公主、大家。快上车！」[rhp]

[:vulpecula:][p_vl_10]
「不快点的话就要被丢下啦！」[rhp]

[off_all]

[:princess:][puri_w ]
「啊……！抱歉。马上就来！」[rhp]

[off_puri]

[::]
再次被催促着，我这回总算登上了车。[rhr]
嘛，既然大家都说没问题应该就没事吧。[rhp]

……不过这个世界里，正常人似乎只有我和多洛普……[rhp]

;****************************************
[free_filter ]
[set_yy storage="train_03.jpg"]
;****************************************

[::]
当铁道腾空而起时，我们漫不经心地聚集到了餐车。[rhp]
将车身设为自动驾驶的多洛普也在，[rhr]
他往每张桌上摆放着马克杯。[rhp]

[:drop:][p_d_31][drop kao=13 ]
「各位今天都累了吧。[rhr]
_　我泡了可可，稍作休息吧」[rhp]

[:princess:][puri_w ]
「谢谢！真是体贴呢多洛普」[rhp]

[:drop:][p_d_28][drop kao=14 ]
「哪里的话。来，请坐请坐」[rhp]

[off_all]

[::]
在多洛普的催促下，我们纷纷入座。[rhp]

[chara_part name="riri" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time="150"]
[chara_part name="kite" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time="150"]

[:quadrillion:]
「哈啊，累死了」[rhp]

[:kite:][p_k_02]
「喝完这个，今天干脆直接睡……」[rhp]

[off_all]

[yurasu]
[se storage="se4_01.ogg" buf=1]
[wait time=300]
[se storage="se4_01.ogg" buf=2]

[rhp]

[chara_part name="riri" body=base kao=2 as=on ss=on hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time="150"]
[chara_part name="kite" body=base kao=4 as=on ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time="150"]

[:kite:][p_k_19]
「……………………………………好像踩到什么东西了」[rhp]

[:quadrillion:][p_r_19]
「确实踩到了呢……屁股上……」[rhp]
[:quadrillion:]
「难道说……」[rhp]

[off_all]

[chara_part name="hakase" body=base kao=5 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time="150"]
[chara_part name="peku" body=base kao=14 as=off ss=off hh=on hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time="150"]

[:vulpecula:][p_vl_27]
「啊哈哈哈哈哈哈哈！[rhr]
_　双重放屁啊！！肚子好疼――疼！」[rhp]

[:darknebula:][p_da_13]
「不是啦佩奇。这叫放屁坐垫所以说……」[rhp]

[off_all]

[chara_part name="riri" body=base kao=2 as=on ss=off hh=on hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time="150"]
[chara_part name="kite" body=base kao=2 as=on ss=off hh=on hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time="150"]

[:2nin:]
[font size=28 color=0x4682b4]
（现在立刻就想下车……！！）[rhr]
（现在立刻就想下车……！！）[rhp]
[resetfont]

;****************************************
[set_b storage="park_01n.jpg" rule="002.png" time=300]
;****************************************

[:yabu:][p_yb_32][yabu kao=11 hh=on ]
「呼……呼呼呼、呼……！」[rhp]
[:yabu:]
「怎么样………！　这下子、想认输了吧……！　呜呣……」[rhp]


;****************************************
[s_mask time=2000]
[::]
[off_yabu]
;****************************************

; イベント分岐の解除
[iscript]
delete f.ev_a_02;
delete f.senpai;
[endscript]

[jump storage="ss_main.ks" target=*start]

[s]
