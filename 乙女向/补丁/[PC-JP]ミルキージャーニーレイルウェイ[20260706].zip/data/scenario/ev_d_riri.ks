﻿*start

;--------------------------------------------------------------------------------------------
;▼フルボイス初期設定▼

; 途中で記載

;--------------------------------------------------------------------------------------------

[::]
因为成为莉莉恋人的我，有了新的使命。[rhr]
那就是设法让那个男人下厨房。[rhp]
至今为止都是轮流代替他担任料理值班，[rhr]
但明明有专属主厨还搞这套，我一直觉得名不副实。[rhp]
正因如此，这次总算获得了能平等提意见的立场，[rhr]
今后必须让莉莉好好履行自己的职责才行。[rhp]

[:princess:][puri_w kao=5 hh=on ]
「最近明显感觉冷嘲热讽和唠叨变少了！[rhr]
_　这显然是恋人效应的功劳吧」[rhp]
[:princess:]
「呵呵呵。如今的我可是无敌的……！」[rhp]

[off_all]

[::]
所以今天也要即刻动身，[rhr]
去餐车说服此刻肯定在化妆的莉莉！[rhp]

;****************************************
[set_b storage="train_03.jpg"]
;****************************************

[:quadrillion:][riri kao=6 ]
「哈？才不要」[rhp]

[:princess:][puri_w kao=6 ]
「为什么！！有空做美甲的话明明就能做菜啊！」[rhp]

[:quadrillion:][p_r_32][riri kao=5 ]
「哼……听好了公主。[rhr]
_　我也不是故意想偷懒的」[rhp]
[:quadrillion:]
「你看，我好歹也算是你的夫君大人吧？」[rhp]

[:princess:][puri_w kao=2 ]
「哇啊！！大清早胡说什么…！」[rhp]

[:quadrillion:][riri kao=13 hh=on ]
「男人啊。就是想从背后静静欣赏[rhr]
_　心爱女人穿围裙的样子再慢慢化妆啦……」[rhp]

[:princess:][puri_w kao=8 as=on ]
「化妆那段纯属多余吧……？」[rhp]

[:quadrillion:][riri kao=6 ]
「太过分了。我、我每天都想着必须为你保持美丽、[rhr]
_　化妆什么的都特别努力了……」[rhp]
[:quadrillion:]
「你是说结婚后就不把我当男人看了，是这个意思？」[rhp]

[:princess:][puri_w kao=4 hh=on ]
「…………………………」[rhp]

[:quadrillion:][riri kao=8 as=on ]
「开玩笑的啦别真的脸红啊……」[rhp]

[:princess:][puri_w kao=7 as=on ]
「对、对不起」[rhp]

[:quadrillion:][riri kao=11 ]
「真是的……不过嘛，好吧。[rhr]
_　既然说到这份上，做饭的事也不是不能考虑」[rhp]

[:princess:][puri_w kao=14 ]
「真的！？」[rhp]

[:quadrillion:][p_r_17][riri kao=5 ]
「但作为交换，我这边也有一个条件」[rhp]

[:princess:][puri_w kao=1 ]
「条件？」[rhp]

[off_puri]

[:quadrillion:][p_r_04][riri kao=13 ]
「过来」[rhp]

[off_all]

[::]
夸德里利昂心情似乎不错地招着手。[rhr]
不祥的预感与美好的预感各占一半……。[rhp]
……带着稍多些的期待，靠了过去。[rhp]

[:princess:][puri_w kao=4 as=on ]
「怎、怎么了？」[rhp]

[:quadrillion:][p_r_02][riri kao=5 ]
「来，张开手」[rhp]

[off_all]

[::]
依言朝夸德里利昂张开双臂成"大"字形。[rhp]
总觉得有点害羞。[rhr]
但不能在意。平常心平常心……！[rhp]

[:quadrillion:][riri kao=14 ]
「那我不客气了」[rhp]

[:princess:][puri_w kao=1 hh=on ]
「呜……！」[rhp]

[off_all]

[::]
随即被巨大的身躯抱住，身体不由自主地僵硬了。[rhr]
桃色发丝掠过鼻尖，飘来清甜的香水味。[rhp]
这就是条件？嘛、不过，好歹也是恋人嘛。[rhr]
这种事情根本不用作为条件，我……[rhp]

[:quadrillion:][riri kao=5 ]
「Ａ７２」[rhp]

[:princess:][puri_w kao=2 ]
「嗯？」[rhp]

[:quadrillion:][p_r_35][riri kao=5 hh=on ]
「再加两杯分量。这是本小姐下厨的最低条件」[rhp]

[:princess:][puri_w kao=6 as=on ]
「哈……哈啊啊！？！？　这算什么啊！？」[rhp]

[:quadrillion:][riri kao=3 as=on ]
「话说你那对玩意儿，该不会连本小姐的胸肌都比不过？[rhr]
_　虽说不用巨乳，但这也太贫瘠了吧～」[rhp]

[:princess:][puri_w kao=2 ]
「才没输呢！！　要摸摸看吗！？　来啊！！」[rhp]

[:quadrillion:][riri kao=7 ]
「不要。会传染」[rhp]

[:princess:][puri_w kao=5 ]
「会传染！？」[rhp]

[:quadrillion:][riri kao=14 ]
「我说你啊，在对本小姐提料理要求之前，[rhr]
_　先给自己挂上女人最起码的装备再来吧」[rhp]

[off_puri]

[:quadrillion:]
「明白了吗？那，解散～～」[rhp]

[off_all]

[:princess:][puri_w kao=3 ]
「太、太过分了……！！！」[rhp]

[off_all]

[::]
大放厥词之后，夸德里利昂又继续化妆去了。[rhr]
感觉接下来无论我说什么，都会被她百倍奉还。[rhp]
今天已经……不，今天也放弃说服，我决定离开食堂……[rhp]

;****************************************
[fbgm]
[set_time_b]
;****************************************

[:quadrillion:][p_r_18][riri kao=2 ]
「哈啊……那家伙怎么回事。最近老是催着做饭做饭的」[rhp]
[:quadrillion:]
「就是有这种人呢～。自己完全不做家务却一本正经地指手画脚的男人」[rhp]

[off_all]

[:yoru:][yoru kao=6 as=on ]
「男人才是你吧」[rhp]

[off_all]

[:quadrillion:][riri kao=6 ]
「呀！！」[rhp]

[off_all]

[chara_part name="riri" body=base kao=2 as=on hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:quadrillion:][p_r_21]
「夜、夜！？　真是的，要来就提前打声招呼啊！」[rhp]

[:yoru:][yoru kao=7 ]
「打过了。刚才在忙没听见吧」[rhp]

[:quadrillion:][riri kao=6 ]
「那也不能突然站在人家背后啊……算了」[rhp]
[:quadrillion:]
「……话说你刚才听见没有？[rhr]
_　那家伙胸围比我的胸肌还贫瘠的事」[rhp]

[:yoru:][yoru kao=12 ]
「不是在聊做饭吗」[rhp]

[:quadrillion:][riri kao=2 ]
「两个都在说！你听见了就懂的吧？[rhr]
_　那家伙什么神经啊。居然随口就说"要摸摸看？"！」[rhp]
[:quadrillion:]
「那个婊子简直不可理喻！[rhr]
_　幸好她挑逗的对象是我！」[rhp]

[:yoru:][p_y_14][yoru kao=0 ]
「喜欢胸部的话该高兴才对吧？」[rhp]

[:quadrillion:][riri kao=2 ]
「别混为一谈！！我只喜欢『巨乳』啊！！」[rhp]

[:yoru:][yoru kao=8 as=on ]
「………………」[rhp]

[:quadrillion:][riri kao=5 ]
「且慢。可别把我和普通爱好者混为一谈。[rhr]
_　就算那孩子真是巨乳，我也会郑重拒绝的」[rhp]
[:quadrillion:]
「未经人工干预自然发育的天然巨乳。[rhr]
_　那才是巨乳应有的本来面目哦？」[rhp]

[:yoru:][yoru kao=12 ]
「宙不会再回来了」[rhp]

[:quadrillion:][p_r_10][riri kao=6 as=on ]
「听我说！其实你也对那曲线美―――」[rhp]
[:quadrillion:]
「…………等等 你刚才是不是强行转移了话题？[rhr]
_　宙这个称呼 好像是落合的名字来着」[rhp]
[:quadrillion:]
「不回来是什么意思？我根本没听说有要回来的计划啊」[rhp]

[:yoru:][yoru kao=6 ]
「……………………」[rhp]

[:quadrillion:][riri kao=5 ]
「……在听吗？喂——」[rhp]

[:yoru:][p_y_17][yoru kao=6 ]
「…………、算了。也没必要特地提这件事」[rhp]
[:yoru:]
「总之我之所以能消除一个杞忧，[rhr]
_　是专程来告诉你多亏有理央」[rhp]

[:quadrillion:][riri kao=2 ]
「……哈……？」[rhp]

[:yoru:][yoru kao=12 ]
「我没打算特意让看不见我的理央目睹身姿。[rhr]
_　要是连他都像宙那样说想来这边就麻烦了」[rhp]
[:yoru:]
「所以作为替代，就来向你道谢——」[rhp]

[:quadrillion:][riri kao=6 ]
「……这种事告诉我也没用啊。[rhr]
_　我既没有传达途径，就算有也和我没关系」[rhp]
[:quadrillion:]
「无论是外貌、性格、还是全部的一切！[rhr]
_　我的人生和理央早就没有瓜葛了！」[rhp]

[:yoru:][p_y_34][yoru kao=0 ]
「………是吗。那是我失礼了」[rhp]
[:yoru:][yoru kao=12 ]
「但你越是这般固执，就越会在意识里强调理央的存在。[rhr]
_　若不想成为替代品，不提那个名字才更明智」[rhp]

[:quadrillion:][riri kao=3 as=on ]
「切，烦死了……」[rhp]

[:yoru:][yoru kao=6 ]
「不及你烦人」[rhp]

[:quadrillion:][riri kao=2 ]
「句句带刺的家伙！」[rhp]

[off_all]

[:yoru:][yoru kao=5 ]
「好了。我该回去了。暂时能清静会儿了吧」[rhp]

;****************************************
[bg_magic_d]
;****************************************

[:quadrillion:][riri kao=2 as=on ]
「…………真是的，搞什么啊……」[rhp]

[fbgm]

[:quadrillion:]
「………………」[rhp]

[off_all]

[::]
―――我的一个杞人忧天能够消散，多亏了理央。[rhp]

[:quadrillion:]
「…………切。那家伙在搞什么啊……」[rhp]

[::]
我再重复一遍，我讨厌理央。[rhr]
即使和公主发生过冲突后，这一点依然不会改变。[rhp]
……别给我得意忘形了。[rhr]
你就永远当个卑鄙的垃圾好了。[rhp]
………我绝不允许你试图追赶上这个我。[rhp]

;****************************************

[s_mask color=0x000000 time=3000]
; 背景表示
[bg storage="hspt_04.jpg" time=100]
; ウィンドゥの設定
[position layer="message0" frame="win2.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[s_mask_off time=3000]

[bgm storage="bgm_16.ogg"]
;****************************************

6年前[rhp]

[:riomama:]
「再见啦，理央。路上小心」[rhp]

[:rio:][p_ri2_07][rio2 kao=1 hh=on ]
「妈妈。谢谢您送我」[rhp]

[:riomama:]
「回来坐巴士。别耽误补习班时间。[rhr]
_　如果检查要很久的话记得打电话」[rhp]

[:rio:][rio2 kao=1 ]
「好的」[rhp]

[off_all]

[:riomama:]
「那回头见」[rhp]

[::]
驾驶座车窗关上的同时，母亲的车转眼就驶离了。[rhr]
在冷清的医院门前，独自目送着车影。这是常有的事。[rhp]
母亲工作间隙有空时，会这样开车送我到医院，[rhr]
但基本上更多是乘巴士来这里。或者说几乎都是那种模式。[rhp]
『理央是能独自去看病的孩子』。[rhr]
为了回应这份期待，我决不能表现出不安。[rhp]

[:rio:][rio2 kao=3 as=on ]
「………………」[rhp]

[off_all]

[::]
我的病不需要注射治疗。[rhr]
但检查总是令人紧张，会担心是否被告知可怕的消息。[rhp]
医院里弥漫的那种无机质的氛围，我始终无法习惯。[rhp]
那些和我年纪相仿，或者更小的孩子们，[rhr]
他们面无生气地坐在轮椅上的样子令人害怕。[rhp]
所以我不擅长去医院。[rhp]

[:rio:]
[font color=0x4682b4]
（……今天也没能说出口，希望你能陪我来……）[rhp]
[:rio:]
（………………但是）[rhp]
[resetfont]

[::]
在母亲和父亲面前抬不起头。[rhr]
因为我的病让他们花了更多钱。[rhp]
还让我上了补习班，几年后还要考初中。[rhr]
因为病被欺负的事，死也不能让他们知道。[rhp]
不能允许自己再添麻烦了。[rhp]
因为有病这个不利条件，我必须比任何人都要乖。[rhp]

;****************************************
[set_b storage="hspt_05.jpg"]
;****************************************

[::]
1小时后，结束了一如既往的检查，[rhr]
领完药的我，正走向巴士站。[rhp]
毕竟是乡下地方，大多数人似乎都选择私家车或出租车，[rhr]
巴士站只设在离医院稍远的位置。[rhp]

[:rio:][rio2 kao=6 as=on ]
「……好热……」[rhp]

[off_all]

;****************************************
#
[bg storage="sky_04.jpg" time=1000]
;****************************************

[:rio:]
「啊，遮阳伞……忘在候诊室了……」[rhp]

[::]
六月的天空，正朝着夏天正式地开始准备。[rhp]
我比常人皮肤更敏感，晴天总离不开遮阳伞。[rhp]

[:rio:]
「来取……，…………」[rhp]

[::]
……自从打伞走路的模样被同学看见后，[rhr]
除非万不得已，否则我决不再用。[rhp]
即便难受，也强过遭人嘲笑。[rhr]
医院医生骂我这样会早死，可死了倒也罢了。[rhp]

[:rio:]
[font color=0x4682b4]
（嗯……不要紧。这种程度应该没事。[rhr]
_　况且现在折返，会赶不上巴士耽误补习班）[rhp]
[resetfont]

;****************************************
[::]
[bg storage="hspt_05.jpg" time=1000]
;****************************************

―――蹒跚着向巴士站走去。[rhp]
回首想来，我始终形单影只。[rhp]
格格不入的学校，补习班弥漫着应试的焦灼。[rhr]
公事公办的医生，医院总笼罩着阴郁。[rhp]
无人倾诉苦闷的，归途。[rhp]
父母终日忙碌，三餐皆是冷食。[rhp]
从早到晚不发一言的日子，早已司空见惯。[rhp]
每天都如此煎熬。[rhr]
药总是苦不堪言。[rhp]
没有欢喜，亦无乐趣。[rhp]
究竟为何而活。[rhp]
………………。[rhp]
……不过今天真是热啊。[rhp]

[:rio:][rio2 kao=8 as=on ]
「……………………呜……」[rhp]

[off_all]

[::]
说起来今早云似乎少了些………[rhr]
脑袋开始昏昏沉沉了。[rhp]
………早知道带伞就好了………[rhp]

;倒れる
[se storage="body_01.ogg"]

;****************************************
[set_b storage="black.jpg"]
;***************************************

[:rio:]
「……………………」[rhp]

[::]
头很痛，整个人晕乎乎的。[rhp]
啊对了，我记得……好像在路边晕倒了……[rhp]
随着意识逐渐清晰，我慢慢睁开眼睛。[rhp]

;****************************************
[bg storage="hsps_05.jpg" time=1000]
;****************************************

[:rio:]
「………………？」[rhp]

[::]
咦……这里是……？[rhp]

[:tiaki:][tiaki kao=0 ]
「……嗯，嗯。好的……明白了。[rhr]
_　等患者醒了会立刻汇报情况」[rhp]

[off_all]
「…………那么」[rhp]

;電話を切る音
[se storage="se5_02.ogg"]
[rhp]

[chara_part name="take" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:]
「医生，已经和主楼确认过了。[rhr]
_　果然是儿科的患者呢」[rhp]

[:takeru:][take kao=0 ]
「果然是这样。十分感谢」[rhp]

[off_all]

[::]
……？　完全不认识的医生和护士。[rhp]
这里……虽然应该是医院，但从没见过的诊疗室……[rhp]

[:rio:]
「…………唔」[rhp]

[::]
咚，脑袋传来钝痛。[rhr]
因为不小心发出声音，两人转头看了过来。[rhp]

[:tiaki:][tiaki kao=4 ]
「！　小朋友你醒啦」[rhp]

[off_all]

[:rio:][rio2 kao=8 ]
「啊……是、是的……」[rhp]

[off_all]

[chara_part name="take" body=base kao=0 as=on ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="rio2" body=base kao=3 as=on ss=off hh=off hr=on ]
[chara_show name="rio2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:takeru:]
「身体呢？有没有哪里痛或不舒服？」[rhp]

[:rio:][p_ri2_18][rio2 kao=8 ]
「那个……头有点、痛……」[rhp]

[:takeru:][take kao=5 ]
「简单检查一下吧。躺好别动」[rhp]

[:rio:][rio2 kao=2 ]
「呜哎，又要打针……！」[rhp]

[:takeru:][p_tk_09][take kao=6 ]
「男孩子可不能被这点事吓到哦」[rhp]

[:rio:][rio2 kao=8 ]
「呜……」[rhp]

[off_all]

;****************************************
[set_time_c]
;****************************************

[chara_part name="take" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="rio2" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="rio2" layer="1" width="437" height="720" left="645" top="0" wait="true"  time=150]

[:takeru:]
「……轻度中暑呢。暂时可以放心了」[rhp]
[:takeru:]
「因为这病所以才没带伞吧」[rhp]

[:rio:][p_ri2_33][rio2 kao=8 as=on ]
「对、对不起……」[rhp]
[:rio:]
「…………那个、打针呢」[rhp]

[:takeru:][take kao=0 ]
「暂且先不打了」[rhp]

[:rio:][rio2 kao=0 ]
「呼……」[rhp]

[off_take]

[chara_part name="tiaki" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="208" top="0" wait="true" time=150]

[:tiaki:][p_mk_04]
「你呀，在主楼附近的小路上晕倒了。[rhr]
_　休息期间，我从主楼小卖部回来时发现的」[rhp]

[:rio:][rio2 kao=4 ]
「原来是这样……麻烦您特意跑一趟真抱歉……」[rhp]

[:tiaki:][tiaki kao=5 ]
「不需要道歉啦！今天超热的对吧？很难受吧？」[rhp]
[:tiaki:]
「来，这个给你！放冰箱冷藏过很凉哦」[rhp]

[off_all]

[::]
递过来的是自动贩卖机里卖的可乐罐。[rhr]
虽说她自称从小卖部回来，但这是在那里买的吗？[rhp]
我被动地接过罐子，护士小姐嫣然一笑。[rhr]
冰凉的罐子贴着皮肤，渗入般的舒爽。[rhp]
…………不过，这样可以吗。[rhr]
大家都说可乐含糖量高伤身体，不准我喝。[rhp]

[chara_part name="take" body=base kao=6 as=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:takeru:][p_tk_21]
「大美贺小姐，之前听说您在减肥」[rhp]

[:tiaki:][tiaki kao=6 hh=on ]
「没关系的。这是零卡路里款」[rhp]

[:takeru:][take kao=0 ]
「购物袋里的点心面包。那个也是零卡？」[rhp]

[:tiaki:][tiaki kao=2 ]
「老、老师好像小姑妈呀……凡事都必须要有休息日！」[rhp]
[:tiaki:]
「对吧～？理央君也是这么想的吧？」[rhp]

[off_take]

[chara_part name="rio2" body=base kao=0 as=on ss=off hh=off hr=on ]
[chara_show name="rio2" layer="1" width="437" height="720" left="208" top="0" wait="true" time=150]

[:rio:]
「诶……为什么突然叫我的名字」[rhp]

[:tiaki:][tiaki kao=8 as=on ]
「对不起。因为不知道你是谁，就擅自打开了你的包。[rhr]
_　补习班的课本上不是写着你的名字嘛。所以就」[rhp]

[:rio:][p_ri2_01][rio2 kao=0 ]
「这样啊……」[rhp]

[off_all]

[::]
就这样联系了主楼，才了解到我的情况。[rhp]
但是该怎么办。要是这件事被通知给妈妈的话，[rhr]
没打遮阳伞的事情可能会暴露……[rhp]

[chara_part name="take" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="rio2" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="rio2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:takeru:]
「…………你的遮阳伞呢？」[rhp]

[:rio:][rio2 kao=4 ]
「！！」[rhp]

[off_all]

[::]
犹如被说中了心事般，我不由得肩膀一颤。[rhp]
我急忙脱口说出忘在主楼没拿、待会儿还要去补习班的事。[rhr]
虽然没打算找借口，但想证明自己确实有带的。[rhp]
说完后，因不敢对视而低垂的脸，战战兢兢地抬了起来。[rhr]
男老师用锐利的眼神瞪视着这边。好可怕……！[rhp]

[chara_part name="take" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="rio2" body=base kao=8 as=on hh=off hr=on ]
[chara_show name="rio2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:takeru:]
「真是的，明明都快到夏天了还这么粗心。[rhr]
_　不管有什么理由，你都该立刻回去拿的」[rhp]
[:takeru:]
「要是解释清楚的话肯定会原谅你的。[rhr]
_　补习班随便就能找到替代，但你的命只有一条啊」[rhp]

[:rio:][rio2 kao=3 as=on ]
「是、是的……对不起……」[rhp]

[:takeru:][take kao=0 ]
「那么，颜色呢？」[rhp]

[:rio:][rio2 kao=4 as=on ]
「…………啊？」[rhp]

[:takeru:][take kao=2 ]
「地点在儿科就可以了吧。……不对，是皮肤科？」[rhp]

[off_rio2]
[chara_part name="tiaki" body=base kao=5 as=off ss=off hh=on hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:]
「顺便再追加一份可乐拜托啦♡」[rhp]

[:takeru:][take kao=6 as=on ]
「不是去跑腿的。请您待会儿自己去」[rhp]

[:tiaki:][tiaki kao=2 ]
「小气鬼！」[rhp]

[off_all]

[:rio:][rio2 kao=8 ]
「………………」[rhp]

[off_all]

[::]
难道说，要特意帮我去主楼拿吗？[rhr]
明明是我忘记的该由我负责，这人本来不必参与的。[rhp]

[:takeru:][take kao=5 ]
「听好了。今后要在发现遗忘的当下就采取行动。[rhr]
_　嫌麻烦也不行，偷懒可没好处」[rhp]
[:takeru:]
「别小看阳光。这关系到你的性命」[rhp]

[off_all]

[:rio:][rio2 kao=0 ]
「……………………」[rhp]

[off_all]

[chara_part name="take" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="rio2" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="rio2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:takeru:]
「回答我！」[rhp]

[:rio:][rio2 kao=3 as=on ]
「！　对、对不起！」[rhp]

[:takeru:][take kao=1 ]
「嗯。下次注意」[rhp]

[off_all]

[:takeru:][take kao=0 ]
「那我出发了。有事请打我手机」[rhp]

[off_all]

;*****************************************
;ドア開ける
[se storage="door_07.ogg"]
;****************************************
[bg_rule storage="hsps_06.jpg" rule="002.png" time=1000]
;****************************************

[:takeru:][p_tk_30][take kao=2 as=on ]
「主楼啊……去是可以，但估计又会被麻烦的上司纠缠……[l] 
[off_all]

[chara_part name="take" body=base kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="kazu" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="kazu" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="760" top="0" wait="true" time=150]

………嗯？」[rhp]

[off_all]

[:himeko:][hime2 kao=4 hh=on ]
「！！！　暴露了！！　撤退―――！」[rhp]

[off_all]

[:kids:]
「哇―――！！」[rhp]

[:takeru:][p_tk_13][take kao=0 as=on ]
「你们！！　又擅自溜出房间了吧！？」[rhp]
[:takeru:]
「要去外面玩必须先找我批准！　说过多少遍了！」[rhp]

[off_all]

;****************************************
[bg_rule storage="hsps_05.jpg" rule="002.png" time=1000]
;****************************************

[::]
方才还温柔的人突然发着怒，[rhr]
老师匆匆忙忙地从房间走了出去。[rhp]
正当我愣住时，身旁的护士哧哧地笑了起来。[rhp]

[chara_part name="rio2" body=base kao=4 as=off ss=off hh=off hr=on ]
[chara_show name="rio2" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:][p_mk_18]
「呵呵！老师他啊，总是那样子的」[rhp]

[:rio:][rio2 kao=7 as=on ]
「吓、吓了一跳……」[rhp]

[:tiaki:][tiaki kao=1 hh=on ]
「但不可怕对吧？倒不如说有点可爱呢」[rhp]

[:rio:][rio2 kao=0 ]
「刚才那些孩子们是？」[rhp]

[:tiaki:][p_mk_31][tiaki kao=5 ]
「啊，那孩子是[player2]酱。其他都是仰慕她的小不点们。[rhr]
_　肯定看到你被送进来的样子啦」[rhp]
[:tiaki:]
「对陌生孩子产生了兴趣吧。[rhr]
_　那孩子啊，好奇心比常人旺盛得多呢」[rhp]

[:rio:][rio2 kao=8 ]
「……那个，有件事在意很久了。[rhr]
_　这个病房...该怎么说...看起来不像儿科啊」[rhp]

[:tiaki:][tiaki kao=7 ]
「哎呀，你不知道吗？在主楼稍远的地方啊，有给孩子们用的……，……」[rhp]

[:rio:][rio2 kao=0 as=on ]
「……？」[rhp]

[:tiaki:][p_mk_31][tiaki kao=5 hh=on ]
「…………是给孩子们的，秘密基地哦！」[rhp]

[:rio:][rio2 kao=4 hh=on ]
「秘密基地？」[rhp]

[:tiaki:][tiaki kao=13 hh=on ]
「没错。专属于患者们的特别秘密基地」[rhp]

[off_all]

[::]
确实这间诊室与我印象中的截然不同，[rhr]
到处都是华丽可爱的装饰。毛绒玩具啊，玩具什么的……[rhp]

[:rio:][rio2 kao=1 hh=on ]
「――――――！啊！！」[rhp]

[off_all]

[:tiaki:][p_mk_19][tiaki kao=13 ]
「嗯？怎么了？」[rhp]

[off_all]

[:rio:][rio2 kao=3 as=on ]
「……！没、没事……」[rhp]

[off_all]

[::]
老师桌上装饰着的恐龙存钱罐。[rhr]
虽然我向圣诞老人许愿了，但最终还是没能得到的那个东西。[rhp]
我记得投币进去后，就会发出声音……[rhp]

[chara_part name="rio2" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="rio2" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:]
「……啊！难道是说小刚的事？」[rhp]

[:rio:]
「小刚？」[rhp]

[::]
印象中商品名应该是另一个完全不同的名字。[rhp]

[:tiaki:][tiaki kao=13 ]
「因为那个玩具很受欢迎嘛！我最近也经常在广告上看到呢」[rhp]

[:rio:]
「那个……这是老师的东西吗？」[rhp]

[:tiaki:]
「嗯，是老师来这里赴任时大家送的礼物。[rhr]
_　有个叫和近君的孩子，这个名字是他取的」[rhp]
[:tiaki:]
「那孩子可有意思了！总给玩具起些怪名字」[rhp]

[:rio:]
「诶……原来是这样啊……」[rhp]

[off_all]

[:unknown:]
「和君！有人在议论你哦……！」[rhp]

[:rio:][p_ri2_13][rio2 kao=7 as=on ]
「！」[rhp]

[off_all]

[::]
窃窃私语声传来，我转向门的方向。[rhp]
刚才逃走的女孩和先前不在场的轮椅少年，[rhr]
正从狭窄的门缝里偷看着这边。[rhp]

[chara_part name="tiaki" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="kazu" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="kazu" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=14 as=off ss=off hh=on hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="760" top="0" wait="true" time=150]

[:tiaki:][p_mk_27]
「哎呀哎呀，[player2]酱和和近君都在呢。[rhr]
_　今天成功躲开老师了吗？」[rhp]

[:himeko:][hime2 kao=5 hh=on ]
「那当然！捉迷藏可是我的强项」[rhp]

[:kazutika:][kazu kao=7 ]
「其实是被训了才正经获得许可来玩的啦」[rhp]

[:tiaki:][tiaki kao=5 hh=on ]
「哎呀」[rhp]

[off_all]

[chara_part name="rio2" body=base kao=7 as=on ss=off hh=off hr=on ]
[chara_show name="rio2" layer="1" width="437" height="720"left="208" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:himeko:]
「喂！你是谁呀？」[rhp]

[:rio:][p_ri2_04][rio2 kao=8 as=on ]
「！呃……那、那个……」[rhp]

[:himeko:][hime2 kao=1 hh=on ]
「几岁了？叫什么名字？是从主楼来的吗？」[rhp]

[off_all]

[::]
因为突然被搭话，导致不知道该说什么好。[rhr]
不过[player2]被称为的女孩子，连珠炮似地搭起话来。[rhp]

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼

;凛生
[voconfig sebuf=1 name=rio vostorage="rio2/full/{number}.ogg" number=3]
;一近
[voconfig sebuf=1 name=kazu vostorage="kazu/full/{number}.ogg" number=14]
;ミカちん
[voconfig sebuf=1 name=tiaki vostorage="mika/full/{number}.ogg" number=193]

[vostart]
;--------------------------------------------------------------------------------------------

[chara_part name="rio2" body=base kao=3 as=on ss=off hh=off hr=on ]
[chara_show name="rio2" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=5 as=off ss=off hh=on hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:himeko:]
「你的头发和眼睛，超级漂亮呢！」[rhp]

[:rio:][rio2 kao=4 as=on ]
「…………啊」[rhp]

[:himeko:][hime2 kao=1 ]
「像小兔子一样可爱！」[rhp]

[:rio:][rio2 kao=8 hh=on ]
「可……可爱？」[rhp]

[off_rio2]
[chara_part name="kazu" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="kazu" layer="1" width="437" height="720" left="208" top="0" wait="true" time=150]

[:himeko:][hime2 kao=13 ]
「呐和君，你觉得怎么做才能像那孩子一样让头发变白呢？」[rhp]

[:kazutika:][kazu kao=5 ]
「变成老太婆」[rhp]

[off_hime2]
[chara_part name="tiaki" body=base kao=6 as=on hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:kazutika:][kazu kao=4 as=on ]
「…………啊！　米、米卡亲对不起」[rhp]

[:tiaki:][tiaki kao=2 ]
「欸～～～？　这话是什么意思～～～？」[rhp]

[off_all]

[chara_part name="rio2" body=base kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="rio2" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:himeko:]
「不过这孩子比我们年纪小哦。[rhr]
_　而且就算变成老奶奶眼睛也不会变红吧」[rhp]

[off_all]

[::]
写满诧异的脸庞直勾勾地看了过来。[rhr]
虽然早已习惯这种视线，却还是不自觉垂下了眼眸。[rhp]
……之所以抗拒和他们接触，[rhr]
是因为总觉得这次会比平时更加受伤。[rhp]

[chara_part name="rio2" body=base kao=12 as=on ss=off hh=off hr=on ]
[chara_show name="rio2" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=13 as=off ss=off hh=on hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:himeko:]
「呐为什么呀？　要怎样才能拥有那样的眼睛呢？」[rhp]

[:rio:][rio2 kao=12 as=on ]
「这、这是……那个。因为病，」[rhp]

[off_all]

[:tiaki:][tiaki kao=5 hh=on ]
「很遗憾——这是理央君独有的特质哦」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:rio:][rio2 kao=3 as=on ]
「……！」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[::]
护士小姐截断了我的话语。[rhr]
我惊讶地抬头望去，她却摆出若无其事的神色。[rhp]

[chara_part name="tiaki" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:]
「可不是那么简单就能实现的哦？[rhr]
_　就像米卡亲这完美的身材一样呢！」[rhp]

[:himeko:][hime2 kao=13 ]
「原来是这样……！路还很长呢」[rhp]

[off_tiaki]
[chara_part name="rio2" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="rio2" layer="1" width="437" height="720" left="208" top="0" wait="true" time=150]

[:himeko:]
「那我要是不选白色的话就选粉色好了！」[rhp]
[:himeko:]
「呐，粉色会不会很难弄啊？」[rhp]

[:rio:][rio2 kao=6 as=on ]
「不、不知道……」[rhp]

[:himeko:][hime2 kao=1 ]
「这样啊。不过男孩子不适合粉色，还是算了吧～」[rhp]
[:himeko:]
「那个，是理央君对吧？」[rhp]

[:rio:][rio2 kao=0 ]
「……！嗯、嗯」[rhp]

[:himeko:][hime2 kao=5 ]
「那个，如果你愿意的话，能一起拍张照吗？」[rhp]

[:rio:][rio2 kao=3 ]
「咦……为、为什么……？」[rhp]

[:himeko:][hime2 kao=13 ]
「要向爸爸和妈妈炫耀！　说我交到了一个超级漂亮的朋友！」[rhp]

[:rio:][rio2 kao=4 hh=on ]
「！　朋、朋友……！？」[rhp]

[:himeko:][hime2 kao=5 ]
「将来我要像理央君那样[rhr]
_　告诉别人自己也能长出超漂亮的发色ー」[rhp]
[:himeko:]
「呐，可以吧？和我做朋友嘛！和君也想成为朋友对吧？」[rhp]

[off_all]

[:kazutika:][kazu kao=8 as=on ]
「真是太抱歉了，我家的[player3]……」[rhp]

[:himeko:][hime2 kao=2 hh=on ]
「什么意思？！？」[rhp]

[:kazutika:][kazu kao=8 ]
「自来熟很抱歉。不喜欢的话敷衍过去就行」[rhp]

[off_all]

[:rio:][rio2 kao=0 hh=on ]
「……………………」[rhp]

[off_all]

[:kazutika:][kazu kao=6 ]
「…………？　喂——」[rhp]

[off_all]

;****************************************
; スチル
[still storage="cg/d_r_1.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/d_r_1.png"]
;****************************************

[:rio:]
「…………呜、呜……」[rhp]

[:kazutika:]
「！？　呃」[rhp]

[:himeko:]
「和君……！　不可以弄哭小孩子啦……」[rhp]

[:kazutika:]
「我、我？」[rhp]

[:rio:]
「不对……不是这样的……」[rhp]
[:rio:]
「……呜、好开心……第一次……被人这样夸……」[rhp]

[:tiaki:]
「理央君……」[rhp]

[:rio:]
「但是，和我这种人做朋友的话……可能会被大家疏远……」[rhp]
[:rio:]
「头发像老头子一样……[rhr]
_　眼睛又像血……大家都会说恶心……」[rhp]
[:rio:]
「……还、还会说……会被传染……」[rhp]

[:himeko:]
「……没关系的？不会传染的」[rhp]

[:rio:]
「……呜……这种事情，谁说得准嘛……」[rhp]

[:himeko:]
「因为你的头发和眼睛，和米卡亲是一样的吧？」[rhp]
[:himeko:]
「我和米卡亲一直―――直在一起，[rhr]
_　也完全没变成魔鬼身材呀！」[rhp]

[:rio:]
「……！这、这算什么啊」[rhp]

[:tiaki:]
「呵呵呵！正是如此呢[player2]亲。[rhr]
_　难道以为交个朋友就能获得这种肉体吗」[rhp]
[:tiaki:]
「巨乳可不是一天炼成的！」[rhp]

[:himeko:]
「…………？」[rhp]

[:tiaki:]
「哎呀？没听懂吗？」[rhp]

[:kazutika:]
「别给小孩子不良影响啊」[rhp]

[off_all]

;****************************************
[still_end frame="win2.png" storage="hsps_05.jpg" time=1000]
;****************************************

[:rio:][rio2 kao=6 as=on ]
「……，……巨乳可不是一天炼成的……」[rhp]

[off_all]

[chara_part name="rio2" body=base kao=0 as=off ss=off hh=on hr=on ]
[chara_show name="rio2" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=2 as=off ss=off hh=on hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:]
「！！！啊、那个。但是呢？虽然说得没错，[rhr]
_　可不能对妈妈说哦。米卡亲会掉脑袋的」[rhp]

[off_rio2]
[chara_part name="kazu" body=base kao=6 as=off hh=off hr=on ]
[chara_show name="kazu" layer="1" width="437" height="720" left="208" top="0" wait="true" time=150]

[:kazutika:]
「不如说这样居然能工作到现在才神奇」[rhp]

[:tiaki:][tiaki kao=5 hh=on ]
「哼哼！这就是人望吧？」[rhp]

[off_all]

[:rio:][rio2 kao=3 hh=on ]
「………………」[rhp]

[:himeko:][hime2 kao=5 hh=on ]
「你看吧理央君。这样的人怎么可能欺负理央君呢！」[rhp]

[:rio:][rio2 kao=1 hh=on ]
「………………嗯」[rhp]

[:himeko:][hime2 kao=13 ]
「而且我觉得，就算白发会传染也没关系哦」[rhp]

[:rio:][rio2 kao=2 ]
「诶……」[rhp]

[:himeko:][hime2 kao=1 hh=on ]
「因为我超级喜欢理央君的头发和眼睛嘛！」[rhp]

[:rio:][rio2 kao=8 hh=on ]
「……………………」[rhp]

[off_all]

[chara_part name="kazu" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="kazu" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=13 as=off ss=off hh=on hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:]
「哎呀哎呀。有人吃醋了呢♡」[rhp]

[:kazutika:][kazu kao=6 ss=on]
「～～～～～……」[rhp]

[off_tiaki]
[chara_part name="hime2" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:himeko:]
「？怎么了？和君」[rhp]

[:kazutika:][kazu kao=2 ]
「……才没有！」[rhp]

[:himeko:][hime2 kao=4 as=on ]
「怎、怎么突然生气了？」[rhp]

[chara_part name="kazu" body=base kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="kazu" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="rio2" body=base kao=13 as=off ss=off hh=on hr=on ]
[chara_show name="rio2" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="hime2" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720"  left="760" top="0" wait="true" time=150]

[:rio:]
「………………大家……」[rhp]
[:rio:]
「……谢、谢谢你们…[rhr]
_　……为我这样说话……」[rhp]

[:kazutika:][kazu kao=12 hh=on ]
「我们只是陈述事实呀？」[rhp]

[:himeko:][hime2 kao=13 ]
「就是！不过是觉得羡慕而已啦」[rhp]

[:rio:][rio2 kao=13 hh=on ]
「……嘿嘿……原来如此。说得对呢……」[rhp]
[:rio:]
「………………所以果然还是，谢谢你们」[rhp]

[:kazutika:][kazu kao=6 as=on ]
「完全搞不懂你……」[rhp]

[:rio:][rio2 kao=1 ]
「那、那个！如果……大家愿意的话……」[rhp]
[:rio:]
「…………这、这个秘密基地，以后还能再来吗……？」[rhp]

[:himeko:][hime2 kao=5 hh=on ]
「嗯！当然可以！」[rhp]

[:rio:][rio2 kao=4 hh=on ]
「……！真的吗！？」[rhp]

[:himeko:][hime2 kao=13 ]
「当然啦。能交到新朋友超开心的！[rhr]
_　以后随时都可以来哦，理央君」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
#
[bg storage="hsps_01.jpg" time=1000]
;****************************************

[::]
―――这就是，我与[player2]酱她们的相遇。[rhp]
意识到那个地方绝非什么秘密基地，而是临终时日不多的孩子们[rhr]
的临终关怀院，并没有花费太多时间。[rhp]
即便如此，我还是将返程巴士的时间推迟了一班，[rhr]
每次诊疗结束后[player2]都会去酱她们那里。[rhp]
过了一阵子，连没有诊疗预约的日子也会主动前往。[rhp]
交到人生中第一批朋友这件事，真的真的让我无比欣喜。[rhp]

;****************************************
[bg storage="sky_05.jpg" time=500]
;****************************************

多亏了大家，我甚至找到了未来的梦想。[rhp]
有朝一日我想成为甜品师。[rhr]
因为探病时自制的点心得到大家称赞时，我开心得不得了。[rhp]
还有……虽然这个梦想靠努力能否实现还很难说。[rhp]

[player2]和酱在一起时会感觉燥热刺眼，晕晕乎乎的。[rhp]
但这种感觉令人无比惬意。[rhr]
[player2]酱就像是温暖的太阳般的存在。[rhr]
被所有人爱戴的[player2]酱，是我最向往的模样。[rhp]
…………终有一日我也能[player2]成为酱那样的人吗。[rhp]

;****************************************
[set_b storage="hspt_04.jpg"]
;****************************************

――――――三年后。[rhp]
时光流转，我升入了私立初中。[rhr]
首次达成了父母对我的期待，我自己也心满意足。[rhp]
然后……我的生活中还有另一个变化。[rhp]
由于随着成长身体状况逐渐稳定，[rhr]
主治医生告知我可以减少复诊次数。[rhp]
这是非常值得高兴的事。[rhr]
因为医院的气氛，无论长到多少岁果然还是无法习惯。[rhp]
……不过……[rhp]

[:riomama:]
「理央，今天要坐巴士回去吗？」[rhp]

[:rio:][p_ri2_01][rio2 kao=0 ]
「诶……是有这个打算，怎么了？」[rhp]

[:riomama:]
「你看，医生不是说可以减少就诊次数了吗。[rhr]
_ 我在想今后是不是可以不坐巴士改乘出租车」[rhp]

[:rio:][rio2 kao=0 ]
「啊……」[rhp]

[:riomama:]
「那样理央也会更方便吧。时间上也能更宽裕。[rhr]
_　车费不用在意……」[rhp]

[off_all]

[::]
乘坐巴士往返，曾是我隐秘的快乐。[rhr]
偶尔会与宙君约好，一边聊天一边乘车过来。[rhp]
……从家到医院，有相当长的距离。正因如此才会使用与每月一次出租车费[rhr]
几乎同价的月票来搭乘巴士。[rhp]
我并没有收到那么多零花钱。[rhr]
如果没有月票，今后我还能去那所临终关怀院多少次呢。[rhp]

[:riomama:]
「……理央？怎么了？」[rhp]

[:rio:][rio2 kao=0 ]
「……！……没、没事。没什么」[rhp]
[:rio:]
「知道了妈妈。今天谢谢你送我」[rhp]

[:riomama:]
「嗯。那你要小心哦」[rhp]

[off_all]

[::]
母亲微微笑着，发动了车子。[rhp]
她绝不是冷漠的人。[rhr]
我喜欢努力工作着的母亲，喜欢我的父母。[rhp]
小时候独自吃饭的辛酸寂寞，[rhr]
升上初中后也就不那么苦涩了。[rhp]
自从发现晚餐旁母亲留的便条上——[rhr]
那些对话框和红眼睛兔子图案里永远饱含着对我的爱。[rhp]

―――要是说了临终关怀院的事，母亲会让我继续坐巴士往返吗？[rhp]
有这个可能。但我……[rhp]

;****************************************
[bg storage="sky_08.jpg" time=1000]
;****************************************

……从去年和近君去世后。[rhp]
那是与他们初次相遇后约两年发生的事。[rhp]
虽然我也相当消沉伤心到流泪，[rhr]
[player2]的样貌惨烈到令人不忍直视。[rhp]
这也难怪。听说和近君在入住临终关怀院前，[rhr]
早在主楼住院期就是她的室友了。[rhp]

……我只能不知所措地陪在一旁。[rhr]
对于只有她们这些朋友的我，不知该如何安慰才好。[rhp]
眼看着她们状况越来越糟，[rhr]
治疗效果顺利显现的我，该怎么说才不会显得阴阳怪气？[rhp]
……要是说错话，被讨厌就不好了。[rhp]

[:rio:]
[font color=0x4682b4]
（要是月票丢了，就没法正常来这里了吧……[rhr]
_　但这种事终究无可奈何。……真的无可奈何对吧？）[rhp]
[:rio:]
（补习班接下来会更忙，社团活动也……）[rhp]
[resetfont]

[::]
不知不觉间，我开始在临终关怀院的大家面前畏缩起来。[rhp]

;****************************************
[set_b storage="hsps_08.jpg"]
;****************************************

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
[vostart]
;--------------------------------------------------------------------------------------------

[:rio:][rio2 kao=3 as=on ]
「………………对不起、[player2]酱」[rhp] 
[:rio:]
「情况就是这样……可能暂时没法来这里了……」[rhp]

[:himeko:][hime2 kao=13 ]
「没事的。这也是没办法的事……」[rhp]
[:himeko:]
「……你病情好转真是太好了！我也很开心哦」[rhp]

[:rio:][rio2 kao=8 as=on ]
「…………嗯」[rhp]
[:rio:]
「[player2]小真也……要加油」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

[::]
没有具体内容的、空洞的话语。[rhp]
根本不具备任何意义。[rhr]
这只是我为了逃避而找的借口。[rhp]

;****************************************
[bg storage="black.jpg" time=1000]
;****************************************

后来整个初中生涯里，[rhr]
我再也没有去过临终关怀院。[rhp]

;****************************************
[set_b storage="sky_06.jpg"]
;****************************************

两年后。[rhp]

升上初三时，原本每月一次的定期体检[rhr]
改为每两月一次，后来检查次数继续减少。[rhp]
或许因为小学同学都不在的缘故，初中时虽然朋友不多但总算交到了几个。[rhp]
努力有了回报，我已经获得了升学高中的保送资格。[rhr]
虽然自己这么说有点怪，但我觉得现在算是过上了充实的学生生活。[rhp]

取而代之的是，西点师的梦想渐渐远去。[rhp]
父母最大的心愿就是让我考上好大学，[rhr]
然后进入好公司。[rhp]
其实我一直心知肚明，[rhr]
却只是飘飘然地追逐着梦想。[rhp]
但在高中升学考试这个大舞台面前，[rhr]
终于不得不面对现实了。[rhp]

『将来想去专科学校学习制作点心』[rhp]

……这种话，实在说不出口。[rhr]
因为会被质问'上什么升学高中'‘要什么推荐入学’。[rhp]

我这种消极态度反而获得很高评价。[rhr]
虽然热血班主任说过'你自己的人生要自己做主'。[rhp]

;****************************************
[bg storage="black.jpg" time=1000]
;****************************************

……那是去父亲父母家玩时的事。[rhr]
偶然听到祖母房间传来声音，我便偷偷从纸门缝隙张望。[rhp]
『都怪父母'、'血脉不好'、'那孩子真是儿子的种吗'。[rhr]
祖母的恶毒话语。母亲正坐的身影深深烙在脑海挥之不去。[rhp]
我根本无法违抗父母。[rhr]
因为被病痛折磨的不止我一个。[rhp]
我不能辜负他们的期望。[rhr]
本该成为一个比他人更努力、令父母骄傲的儿子。[rhp]

;****************************************
[bg storage="sky_06.jpg" time=1000]
;****************************************

制作点心也可以作为兴趣爱好。[rhr]
如今[player2]不仅在孩子们中间，连父母辈中也广受好评。[rhp]
那样不也挺好的吗。[rhp]
我可以放弃梦想……[rhp]

;****************************************
[bg storage="hsps_01e.jpg" time=1000]
;****************************************

[:rio:][rio body=prain kao=8 as=on ]
[font color=0x4682b4]
（…………我本来是这么想的）[rhp]
[resetfont]

[off_all]

[::]
已有多年未造访的『银河站』。[rhr]
不知为何，我时隔许久再次来到这个地方。[rhp]

[::]
我想，一定是渴望获得勇气吧。[rhp]
就差一步，放弃梦想的勇气。[rhp]

[:rio:]
[font color=0x4682b4]
（……现在才觉悟，可笑却也笑不出来）[rhp]
[resetfont]

[::]
即便如此，[player2]她是个温柔的好女孩。[rhr]
[player2]我想她一定会笑着肯定我的决定。[rhp]

;****************************************
[bg storage="hsps_06e.jpg" time=1000]
;****************************************

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼

; しゅみたろリオ
[voconfig sebuf=1 name=rio vostorage="rio/full/{number}.ogg" number=1]

[vostart]
;--------------------------------------------------------------------------------------------

[:rio:][rio body=prain kao=3 as=on ]
「……………………诶」[rhp]

[off_all]

[::]
―――手中拎着的纸袋滑落在地。[rhp]

[:tiaki:][tiaki kao=3 ]
「正好一周前……」[rhp]
[:tiaki:]
「…………像睡美人般沉睡着」[rhp]

[off_all]

[:rio:][rio body=prain kao=8 as=on ]
「…………」[rhp]

[off_all]

[::]
纸袋里装着[player2]第一次为她制作的饼干。[rhp]
虽然不会成为糕点师，但还会继续做点心哦[rhr]
本打算笑着重逢时分享这份喜悦。[rhp]

[:tiaki:]
「……谢谢你能来，理央君。[rhr]
_　点心，[player2]小一定也会很高兴的」[rhp]
[:tiaki:]
「[player2]小之前还说好多次想再吃呢……」[rhp]
[:tiaki:]
「…………虽然无法实现，但能实现真是太好了」[rhp]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

[::]
……从刚才开始就心跳剧烈。[rhp]
是因为悲伤，还是因为懊悔，[rhp]
或是庆幸没看到她凄惨的模样而松了口气。[rhp]
心情乱糟糟的，已经搞不清楚了。[rhr]

;****************************************
[still storage="cg/d_r_2.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/d_r_2.png"]
;****************************************

没出息得直掉眼泪。[rhp]
我是因为不想让自己受伤，[player2]才从小身边逃开的。[rhr]
却只在方便的时候[player2]企图利用小的温柔。[rhp]
明明从那一天起我的梦想就决定了。[rhp]
既不是考上好学校。[rhr]
当甜品师也不太对。[rhp]
是想成为那个拯救了我的人。[rhp]
………一直、[player2]都想要成为小那样的人。[rhp]

;****************************************
;鉄道世界

[s_mask color=0x000000 time=3000]
; 背景表示
[bg storage="train_03.jpg" time=100]
; 全部のフィルターを打ち消す
[free_filter ]
; ウィンドゥの設定
[position layer="message0" frame="win.png" left=0 top=520 width=1280 height=200 page=fore visible=true ]
[s_mask_off time=3000]

;****************************************

……我是南为带来那群小鬼而被创造的，[rhr]
可说是『理央的替身人偶』。[rhp]
在首位乘客达克内布拉博士生前，为填补围绕他的好友四人组中[rhr]
理央的位置而诞生了我。[rhp]
理央所期望的、成为最理想的自己的模样。[rhp]

[:quadrillion:][riri kao=2 as=on ]
「～～～～～……所以说，不是这样的吧」[rhp]

[off_all]

[::]
或许因为是以他的理想为蓝本创造的，我拥有理央的全部记忆。[rhp]
并非作为自己的记忆，而始终只是作为『信息』[rhr]
甚至连现在那家伙的记忆也链接共享着。[rhp]
正因如此，对南那种粗糙的……或者说机械式的菜谱实在是受够了。[rhr]
[player2]说什么想成为，怎么看都是比喻的说法吧。[rhp]

[:quadrillion:][riri kao=3 ]
「………即便如此………理央对宙，啊」[rhp]

[off_all]

[::]
虽然难以立刻相信，但既然是夜说的，大概是真的吧。[rhp]
……真不愉快。[rhr]
理央就该保持理央的样子，永远优柔寡断下去就好了。[rhp]
啊真让人反胃。这种异常的焦虑是怎么回事……[rhp]

;****************************************
[bg storage="black.jpg" time=1000]
;****************************************

[::]
…………，其实心知肚明。[rhp]
如果那家伙……如果理央努力改变自己的话，[rhr]
他之后的理想会产生怎样的变迁呢。[rhp]
若我不再是他的憧憬对象，[rhr]
作为"我"的存在又会变成怎样呢。[rhp]
……这种事去问南马上就能明白。[rhp]
但我害怕。万一被告知和我想的『最糟结果』一样……[rhp]

;****************************************
[bg storage="train_03.jpg" time=1000]
;****************************************

[:quadrillion:]
「…………呜、最讨厌了。理央什么的……」[rhp]

[::]
若理央是太阳，我就是月亮。[rhr]
唯有理央存在才会发光，若无理央便无人问津。[rhp]
再这样下去，理央会把一切都夺走。[rhr]
我讨厌那样。唯独这点绝不能容忍。[rhp]
因为本小姐才是存在于此处、独一无二的夸德里利昂。[rhp]

[:quadrillion:][p_r_18][riri kao=2 ]
「～～～……啊可恶！都是那家伙害得我心烦意乱」[rhp]
[:quadrillion:]
「没辙了。不如出去散散心吧……」[rhp]

[off_all]

;****************************************
[fbgm]
[set_xx graphic="rule/krke_r.png" storage="train_01.jpg"]
[bgm storage="bgm_30.ogg"]
;****************************************

[:quadrillion:][riri kao=5 hh=on ]
「哈喽~在忙吗？」[rhp]

[off_all]

[::]
正当我用普通车辆和多洛普闲聊时，[rhr]
莉莉以掀开居酒屋门帘般的气势突然冒出来。[rhp]
鉴于先前失礼的对话内容，我决定以略带冷淡的态度应对。[rhp]

[chara_part name="riri" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=2 as=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width="330" height="720" wait="true" zindex="1005" time=150]

[:princess:]
「巨乳售罄。今天已经打烊了哦」[rhp]

[:quadrillion:][riri kao=6 ]
「你这儿进过货吗？」[rhp]

[off_all]

;お尻を蹴る
[yurasu]
[se storage="hand_05.ogg"]

[:quadrillion:]
[font size=28]
「好痛！！！！！】[rhp]
[resetfont]

[off_all]

[chara_part name="riri" body=base kao=2 as=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=6 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width="330" height="720" wait="true" zindex="1005" time=150]

[:quadrillion:]
「喂你！！屁股会摔裂的！」[rhp]

[:princess:][puri_w kao=8 ]
「无聊」[rhp]

[off_all]

[chara_part name="drop" body=base kao=1 as=on ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="riri" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="606" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=7 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width="330" height="720" wait="true" zindex="1005" time=150]

[:drop:]
「听说两位发展成恋人关系了。[rhr]
_　现在还持续着那种氛围吗？」[rhp]

[:quadrillion:][p_r_12][riri kao=7 ]
「哼，和这种臭小鬼怎么可能会有甜蜜气氛。[rhr]
_　全靠本小姐成熟从容的气度才勉强维持着关系罢了」[rhp]

[:princess:][puri_w kao=6 ]
「莉莉明明是个大人却[rhr]
_　就是因为总是这种态度才会这样吧！」[rhp]

[:quadrillion:][riri kao=2 ]
「给我闭嘴。这个万年运动胸罩女」[rhp]

[off_all]

;お尻を蹴る
[yurasu]
[se storage="hand_06.ogg"]

[:quadrillion:][riri kao=12 as=on ]
「呀！！！」[rhp]

[off_all]

[:drop:][drop kao=4 ]
「喂、回旋踢……！　穿着裙子就收敛点啊！」[rhp]

[off_all]

[chara_part name="riri" body=base kao=0 as=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=6 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width="330" height="720" wait="true" zindex="1005" time=150]

[:quadrillion:]
「这个该死的家暴女！　该凸的地方凸出来就好了！[rhr]
_　你的胸这辈子都别想凸起来！」[rhp]

[:princess:][puri_w kao=5 ]
「人家才不是运动胸罩呢～。要看吗？」[rhp]

[:quadrillion:][riri kao=2 ]
「才不看！变态！！」[rhp]

[:princess:][puri_w kao=2 ]
「唯独不想被莉莉这么说啊！！」[rhp]

[off_all]

[chara_part name="drop" body=base kao=14 as=on ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="riri" body=base kao=0 as=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="606" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=12 as=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width="330" height="720" wait="true" zindex="1005" time=150]

[:drop:]
「好、好了好了。来，我泡了热牛奶。[rhr]
_　喝了这个先冷静下吧」[rhp]

[:princess:][puri_w kao=13 hh=on ]
「谢谢你多洛普……真是治愈呢……」[rhp]

[:drop:][drop kao=5 ]
「不客气」[rhp]

[:quadrillion:][riri kao=1 hh=on ]
「真贴心啊～你做的什么东西都好吃呢」[rhp]

[:princess:][puri_w kao=6 as=on ]
[font color=0x4682b4]
（笑容真温和……这个主厨难道没有自尊心的吗）[rhp]
[resetfont]

[:quadrillion:][riri kao=6 ]
「好～嘞。这种心态属于厨师骚扰哦～」[rhp]

[:princess:][puri_w kao=8 ]
「嗯？」[rhp]

[:quadrillion:][riri kao=5 ]
「就是那种『你既然是主厨』的找茬[rhr]
_　强迫主厨做饭的职场骚扰」[rhp]

[:princess:][puri_w kao=2 ]
[font color=0x4682b4]
（感觉好麻烦还是别管了）[rhp]
[resetfont]

[:drop:][drop kao=1 ]
「呵呵，差不多就到这儿吧」[rhp]

[off_all]

[:drop:][drop kao=11 ]
「……嘿咻」[rhp]

[off_all]

[::]
向我们递出马克杯后，[rhr]
多洛普也再次在我斜对面坐了下来。[rhp]
总觉得这景象不怎么常见呢。[rhr]
那个多洛普居然坐在座位上休息什么的。[rhp]

[chara_part name="drop" body=base kao=0 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="riri" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:quadrillion:]
「累了吧多洛普。发生什么了吗？」[rhp]

[:drop:][p_d_19][drop kao=4 ]
「咦？为什么这么问？」[rhp]

[:princess:][puri_w kao=0 as=on ]
「其实我也这么想。平时从不在显眼地方休息的。[rhr]
_　……倒不如说，还是第一次见到你休息的样子」[rhp]

[:drop:][drop kao=13 as=on ]
「啊……啊—。确实呢。被你这么一说……」[rhp]
[:drop:]
「……真是惭愧」[rhp]

[:quadrillion:][p_r_16][riri kao=2 ]
「看吧看吧。都是因为你太压榨车长了。[rhr]
动不动就说『你可是车长啊’这种歪理来逼车长干活」[rhp]

[:princess:][puri_w kao=7 ]
「好啦好啦知道了知道了」[rhp]

[:drop:][drop kao=13 ]
「没关系的。这方面请不必担心……」[rhp]

[off_all]

[:drop:][drop kao=8 ]
「………………」[rhp]

[off_all]

[chara_part name="riri" body=base kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=0 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width="330" height="720" wait="true" zindex="1005" time=150]

[:quadrillion:][p_r_04]
「……那家伙到底怎么了？」[rhp]

[:princess:][puri_w kao=8 ]
「来吧……」[rhp]

[off_all]

[::]
今天多洛普的样子实在奇怪。[rhr]
罕见地心不在焉，仿佛魂魄不在此处。[rhp]

[chara_part name="drop" body=base kao=0 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="riri" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="606" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=1 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width="330" height="720" wait="true" zindex="1005" time=150]

[:drop:]
「……两位，打扰了。[rhr]
_　冒昧提出请求实在抱歉……可以听我说吗」[rhp]

[:princess:][puri_w kao=13 ]
「！　什、什么？」[rhp]

[:quadrillion:][riri kao=5 hh=on ]
「尽管说？我可不会让这家伙拒绝的哦」[rhp]

[:princess:][puri_w kao=3 as=on ]
「为什么是我啊！」[rhp]

[:drop:][drop kao=7 as=on ]
「不不！不是什么大不了的事……」[rhp]

;****************************************
;車体の上
[set_xx graphic="rule/krke_r.png" storage="train_10.jpg"]
; 夜フィルター
[filter layer="1" brightness="60"]
;****************************************


[::]
被多洛普带来的地点，竟是银河铁道的车顶之上。[rhp]
无视无重力与真空的物理法则，伫立于平日里隔窗眺望的银河之中——[rhr]
这堪称迄今为止最超乎寻常的特别情境。[rhp]
毫无阻隔的美丽景色，让我的心比任何时候都雀跃不已。[rhp]

[:princess:][puri_w kao=13 hh=on ]
「好厉害……！原来这里能爬上来啊！」[rhp]

[:drop:][drop kao=5 ]
「是的。平时因危险不对外开放，[rhr]
_　请注意别摔下去」[rhp]

[:princess:][puri_w kao=1 ]
「没问题。交给我吧」[rhp]

[off_all]
[yurasu]

[:quadrillion:][riri kao=2 ]
[font size=35]
「哇！！！！」[rhp]
[resetfont]

[:princess:][puri_w kao=3 as=on ]
「呀啊！！」[rhp]

[:quadrillion:][p_r_31][riri kao=13 hh=on ]
「啊哈哈哈！吓成这样～[rhr]
_　就算真的掉下去也不管哦……」[rhp]

[off_all]

[yurasu]
[se storage="hand_01.ogg"]

[chara_part name="drop" body=base kao=4 as=on hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="riri" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:quadrillion:]
「呜哇！！好、好险！没想到这里还挺滑……！」[rhp]

[:drop:][drop kao=7 as=on ]
「漂亮地回收了flag呢……」[rhp]

[off_all]

[::]
不过这些暂且不提。[rhr]
仰望着苍穹，我深深吸了一口气。[rhp]

[:princess:][puri_w kao=4 hh=on ]
「好壮观的景色……！目光所及全是星空」[rhp]

#
舒爽的晚风拂过。虽然不确定是否能称之为夜风，[rhr]
轻抚脸颊的凉爽微风仿佛在治愈疲惫的身躯[rhp]

[:princess:][puri_w kao=1 ]
「……啊！对了，比起这个多洛普的事更重要。[rhr]
_　特意叫到这种地方来有什么事吗？」[rhp]

[:drop:][drop kao=13 hh=on ]
「那个……实在没想到两位会成为恋人关系，[rhr]
_　就像自己的事情一样高兴。所以想着趁现在先庆祝一下」[rhp]
[:drop:]
「虽说如此也准备不了什么隆重的庆祝，至少想用这般光景作为心意。[rhr]
_　这里没有南先生或我的许可是进不来的，要说稀有确实也算稀有呢」[rhp]

[off_all]

[chara_part name="riri" body=base kao=6 as=off ss=off hh=on hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=4 as=off ss=off hh=on hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width="330" height="720" wait="true" zindex="1005" time=150]

[:2nin:]
「……………………」[rhr]
「……………………」[rhp]

[off_all]

[chara_part name="drop" body=base kao=8 as=on ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="riri" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="606" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=6 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width="330" height="720" wait="true" zindex="1005" time=150]

[:drop:]
「咦？啊、难道打扰到你们了吗！？非常抱歉！」[rhp]

[:quadrillion:][riri kao=8 as=on ]
「倒不会打扰，只是被这么一说反而没什么实感」[rhp]

[:drop:][drop kao=13 hh=on ]
「您在说什么呀。明明非常相衬哦！[rhr]
_　[font size=13]虽然要说像不像恋人可能还算不上……[resetfont]」[rhp]

[:princess:][puri_w kao=3 as=On ]
「听到了吗莉莉？多洛普也这么说了，[rhr]
_　你们可以表现得更像恋人一点也没关系吧？」[rhp]

[:quadrillion:][riri kao=7 ]
「更像恋人的表现啊……嗯——」[rhp]

[off_all]

[:quadrillion:][riri kao=5 hh=on ]
「……我爱你。公主♡」[rhp]

[:princess:][puri_w kao=4 hh=on ]
「！！！！」[rhp]

[off_all]

[chara_part name="drop" body=base kao=1 as=off ss=off hh=on hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="riri" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:drop:]
「呜哇！好、好热情啊……！！」[rhp]

[:quadrillion:][riri kao=6 ]
[font color=0x4682b4]
（这群人简直中学生……）[rhp]
[resetfont]

[:drop:][drop kao=11 as=on hh=on ]
「……！咳、咳咳。总之呢。[rhr]
_　公主您能享受旅途就再好不过了」[rhp]

[:princess:][puri_w kao=5 hh=on ]
「嗯！每次的目的地固然有趣，但沿途的风景也让我很开心。[rhr]
_　该怎么说呢，现在觉得所有一切都令人开心得不得了呢」[rhp]

[:drop:][drop kao=13 ]
「这样啊。都是夸德里利昂的功劳呢」[rhp]

[:quadrillion:][riri kao=5 ]
「正是如此」[rhp]

[:drop:][drop kao=1 hh=on ]
「呵呵……！总之大家看起来幸福就是最好的了」[rhp]

[off_puri]

[:quadrillion:][riri kao=3 ]
「…………、……话说多洛普」[rhp]

[:drop:][drop kao=13 ]
「嗯？怎么了」[rhp]

[:quadrillion:][riri kao=6 ]
「刚才你说『趁现在先庆祝吧』对吧」[rhp]

[:drop:][drop kao=4 as=on ]
「！啊……那个，这个」[rhp]

[:quadrillion:][riri kao=7 ]
「…………如果我的杞人忧天真成了现实的话」[rhp]
[:quadrillion:]
「没关系的。宙不会来的」[rhp]

[:drop:][drop kao=2 ]
「…………啊」[rhp]

[:quadrillion:][riri kao=0 ]
「夜是这么说的。…………，说是理央拦住了他」[rhp]
[:quadrillion:]
「所以你担心的事情[rhr]
_　今后一件都不会发生哦。太好了呢」[rhp]

[:drop:][drop kao=0 ]
「………………」[rhp]

[:quadrillion:][riri kao=13 ]
「是啊！这个话题到此为止。我不想再提那家伙的事了」[rhp]

[:drop:][drop kao=3 as=on ]
「……明……明白了」[rhp]

[off_all]

[:princess:][puri_w kao=6 ]
「呐，你们从刚才在聊什么？」[rhp]

[:quadrillion:][riri kao=2 ]
「跟你没关系。我说过了吧？[rhr]
_　这个话题不会再继续了」[rhp]

[:princess:][puri_w kao=12 ]
「为什么啊。宙不是落合君的名字吗？[rhr]
_　为什么现在这里会提到宙君――――――」[rhp]

[se storage="body_12.ogg"]
[rhp]

[:princess:][puri_w kao=2 as=on ]
「！！！！！」[rhp]

[off_all]

[:drop:][drop kao=6 as=on hh=on ]
「什……！！」[rhp]

[off_all]

[:quadrillion:][riri kao=13 hh=on ]
「以牙还牙以眼还眼♡　所以这个话题真的到此为止」[rhp]

[yurasu]
[:princess:][puri_w kao=8 as=on hh=on ]
[font size=25]
「哇啊啊啊啊啊！！！！！」[rhp]
[resetfont]

[off_all]

[yurasu]
[se storage="hand_05.ogg"]

[:quadrillion:]
「咳噗！！！！」[rhp]
[resetfont]

[:quadrillion:][riri kao=2 ]
「喂你够了！！扇巴掌太过分了吧！？[rhr]
_　我们可是恋人啊！！！」[rhp]

[off_all]

[:princess:][puri_w kao=13 hh=on as=on ]
「哇哇哇，我先回房间了！！[rhr]
_　那再见啦两位！多洛普谢谢你给的牛奶！」[rhp]

[off_all]

[:drop:][drop kao=14 as=on ]
「好、好的……！路上小心」[rhp]

[off_all]

;ドア閉める
[se storage="door_10.ogg"]

[chara_part name="drop" body=base kao=7 as=on ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="riri" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:drop:]
「走掉了呢」[rhp]

[:quadrillion:][riri kao=6 ]
「库索布斯啊～～～……！！把嘴唇还给我……！！」[rhp]

[:drop:][drop kao=8 as=on ]
「谁让您那样强行制止。连我也被吓到了」[rhp]
[:drop:][drop kao=3 as=on ]
「……理央先生的事，您就如此不愿提及吗？」[rhp]

[:quadrillion:][p_r_10][riri kao=5 ]
「当然。连名字都不想从嘴里说出来」[rhp]

[:drop:][drop kao=3 ]
「但您之前不是还玩着'扮演理央先生'的游戏吗」[rhp]

[:quadrillion:][riri kao=2 ]
「那时候的情况完全不同。[rhr]
_　……那孩子选择的不是理央，而是如今这个我」[rhp]
[:quadrillion:]
「但那也可能只是因为那孩子忘记了理央的事。[rhr]
_　理央不过是自说自话，根本不知道她如何看待理央」[rhp]
[:quadrillion:]
「……所以老实说，我对那孩子什么都不……不」[rhp]
[:quadrillion:]
「唯独不希望她想起理央的事」[rhp]

[:drop:][drop kao=1 ]
「我觉得您不必如此在意。因为在宙先生的记忆里[rhr]
_　存在着理央先生的过往，所以我也知晓他这个人……」[rhp]
[:drop:]
「她作为女性对男性抱有好意的对象，[rhr]
_　毫无疑问就是您」[rhp]

[:quadrillion:][riri kao=5 ]
「即便如此还是难受。无论如何都无法忍受被拿来和那家伙比较」[rhp]
[:quadrillion:]
「只要想到可能会被评价'理央当时是这样做的'，[rhr]
_　我的存在必须以理央为前提啊」[rhp]
[:quadrillion:]
「…………我就是我。不是理央的冒牌货。[rhr]
_　就算没有理央，我也要自己决定生存方式」[rhp]
[:quadrillion:]
「对公主的感情也是一样。[rhr]
_　这不是因为理央，而是我自己……！」[rhp]

[:drop:][drop kao=8 as=on ]
「夸德里利昂……」[rhp]

[:quadrillion:][riri kao=5 hh=on ]
「…………！……开玩笑的。刚才的请忘掉」[rhp]

[off_all]

[:quadrillion:][riri kao=13 ]
「我也该回去了。[rhr]
_　景色真是太棒了。下次还要邀请我哟」[rhp]

[off_all]

[:drop:][drop kao=1 ]
「……、嗯。一定！」[rhp]

[off_all]

;****************************************
[fbgm]
[set_ff storage="train_08.jpg"]
[bgm storage="bgm_01.ogg"]
;****************************************

像是逃跑般回到房间的我。[rhr]
抱着膝盖和靠垫坐在床铺上，回想着方才的事。[rhp]

;****************************************
;回想
[set_kk storage="train_10.jpg" time=500]
;****************************************

[:quadrillion:][riri kao=13 hh=on ]
「以眼还眼，以吻还吻♡」[rhp]

;****************************************
;回想終了
[set_ff storage="train_08.jpg" time=500]
;****************************************

[:princess:][puri_w kao=8 hh=on ]
[font size=28]
「～～～～～啊！！！哇啊～～～～～！！！！」[rhp]
[resetfont]

[off_all]

;****************************************
[bg_rule storage="train_04.jpg" rule="002.png" time=1000]
;****************************************

[chara_part name="jet" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:][p_h_30]
「在房间搞什么鬼？那家伙」[rhp]

[:jet:][p_j_30][jet kao=2 as=on ]
「觉得不对劲过来看看结果这副德行」[rhp]

[off_all]

[:vulpecula:[p_vl_15][peku kao=5 ]
「要突击吗！？」[rhp]

[off_all]

[chara_part name="jet" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="355" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="760" top="0" wait="true" time=150]

[:heartshape:]
「不错嘛！就该这么干！」[rhp]

[:jet:]
「不要。麻烦死了」[rhp]

[chara_part name="peku" body=base kao=3 as=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="40" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="421" top="0" wait="true" time=150]

[:2nin:]
「诶ー！？」[rhr]
「诶ー！？」[rhp]

[:jet:]
「公主那副样子，肯定和克林有关吧。[rhr]
_　我们掺和进去也是白搭。该说是徒劳还是无所谓来着」[rhp]

[:heartshape:][hati kao=8 as=on ]
「杰特真冷漠啊。要是有烦恼明明可以商量的」[rhp]

[:vulpecula:][peku kao=3 hh=on ]
「就是啊ー！想和小公主一起玩嘛！」[rhp]

[:jet:][jet kao=13 ]
「不行不行！快走吧走吧。[rhr]
_　沃尔佩克拉也快回博士那儿去啦」[rhp]

[:vulpecula:][p_vl_16][peku kao=5 as=on ]
「博士现在正做研究呢～所以要保持安静～[rhr]
_　所以才来找哈蒂玩捉迷藏的嘛」[rhp]

[:heartshape:][hati kao=5 hh=on ]
「哦，真的吗！那来吧。爆裂捉迷藏！」[rhp]

[off_all]

[chara_part name="peku" body=base kao=13 as=off ss=off hh=on hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="40" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:vulpecula:]
「杰～蒂当鬼哦！那么开始～！」[rhp]

[off_all]

[:jet:][jet kao=4 as=on ]
「喂喂！怎么擅自就―――」[rhp]

[off_all]

;****************************************
[bg_rule storage="train_04.jpg" rule="002.png" time=1000]
;*****************************************

[:princess:]
「嘛果然啊……觉得麻烦也是理所当然的吧」[rhp]

[::]
从刚才起就听得一清二楚的哈蒂君他们的声音逐渐远去，[rhr]
我深深地叹了口气。[rhp]
我和夸德里利昂的关系，[rhr]
说到底只是与我们两个之外任何人都无关的事。[rhp]
明明如此，一个人这样闹腾的话，肯定会又吵又惹人厌。[rhp]
但是…………[rhp]

;****************************************
;回想
[set_kk storage="train_10.jpg" time=500]
;****************************************

[:quadrillion:][riri kao=13 hh=on ]
「以眼还眼，以吻还吻♡」[rhp]

;****************************************
;回想終了
[set_ff storage="train_08.jpg" time=500]
;****************************************

[:princess:][puri_w kao=2 hh=on as=on ]
[font size=28]
「啊――――――！！！！！！」[rhp]
[resetfont]
[:princess:]
「太突然！！实在太突然了啦！而且完全没有氛围！[rhr]
_　用试吃区那种随便的态度接吻的话，任、任、任何人都会……」[rhp]

[off_all]

[:quadrillion:][riri kao=2 as=on ]
「试吃区是什么比喻啊」[rhp]

[off_all]

[:princess:][puri_w kao=8 as=on hh=on ]
「本来就是嘛！第一次谈恋爱就那样轻率地接吻……」[rhp]

[off_all]

[chara_part name="riri" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=8 as=on hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width="330" height="720" wait="true" zindex="1005" time=150]

[yurasu]

[:princess:]
[font size=28]
「哇――――――――！！！」[rhp]
[resetfont]

[:quadrillion:][p_r_10][riri kao=8 ]
「吵死了！别突然尖叫啊」[rhp]

[:princess:][puri_w kao=6 as=on ]
「莉、莉莉！？你什么时候在那里的……！」[rhp]

[:quadrillion:][riri kao=8 ]
「刚刚哦。来看看情况，[rhr]
_　我以为至少能听到你对刚才那一击的解释呢」[rhp]

[:princess:][puri_w kao=2 ]
「先敲门啊！」[rhp]

[:quadrillion:][riri kao=2 as=on ]
「敲了门你也不会让我进来的样子啊」[rhp]

[off_riri]

[:princess:][puri_w kao=12 ]
「呜……好、好吧先坐下。既然这样我们就彻底谈谈吧」[rhp]

[off_all]

[:quadrillion:][riri kao=6 as=on ]
「谈什……算了。打扰啦——」[rhp]

[off_all]

[::]
莉莉用悠哉的声音说着，走到我身旁。[rhp]

[fbgm]

………………。[rhp]

[bgm storage="bgm_22.ogg"]

[chara_part name="riri" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=6 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width="330" height="720" wait="true" zindex="1005" time=150]

[:princess:]
「……停、停下！」[rhp]

[:quadrillion:][riri kao=2 ]
「干嘛」[rhp]

[:princess:][puri_w kao=12 as=on hh=on ]
「太近了！」[rhp]

[:quadrillion:][riri kao=5 ]
「有吗？很正常吧」[rhp]

[:princess:][puri_w kao=2 ]
「请保持至少50厘米距离……！」[rhp]

[:quadrillion:][p_r_12][riri kao=6 as=on ]
「我说你啊，就算恋爱经验匮乏，[rhr]
_　也不该这样粗暴对待名义上的恋人吧」[rhp]

[:princess:][puri_w kao=7 as=on ]
「可、可是……」[rhp]

[off_puri]

[se storage="body_07.ogg"]

[:quadrillion:][riri kao=13 hh=on ]
「啾♡」[rhp]

[yurasu]
[se storage="hand_05.ogg"]
――――――！！！[rhp]

[:princess:][puri_w kao=0 as=on hh=on ]
「下流！！」[rhp]

[:quadrillion:][p_r_04][riri kao=2 as=on ]
「等等……你是喜欢我的对吧」[rhp]

[:princess:][puri_w kao=8 hh=on ]
「当！？当然……喜欢！？」[rhp]

[:quadrillion:][riri kao=3 as=on ]
「你见过哪个女生会对自己名义上的恋人左右开弓扇耳光的？」[rhp]

[:princess:][puri_w kao=3 as=on hh=on ]
「但、但是～～～……！」[rhp]

[:quadrillion:][riri kao=6 ]
「我一直想问，你难道从没想过[rhr]
_　要和我更进一步发展什么的吗？」[rhp]

[:princess:][puri_w kao=0 ]
「发展？」[rhp]

[:quadrillion:][riri kao=2 ]
「对呀。就是更像恋人之间的氛围那种。」[rhr]
_　这样和之前完全没有区别嘛」[rhp]

[:princess:][puri_w kao=13 ]
「嗯……我倒是觉得保持现状也很快乐啦。[rhr]
_　我并没有想要和莉莉的关系更进一步什么的」[rhp]

[:quadrillion:][riri kao=3 as=on ]
「真没劲呢……」[rhp]

[:princess:][puri_w kao=0 hh=on  ]
「那莉莉呢？有没有想过要和我发生些什么」[rhp]

[:quadrillion:][riri kao=2 hh=on ]
「发生什么啊……嗯，或许有吧」[rhp]

[:princess:][puri_w kao=4 ]
「比如说？」[rhp]

[:quadrillion:][riri kao=13 ]
「我想成为某个人的唯一。[rhr]
_　如果你能这么想我会很高兴的」[rhp]

[:princess:][puri_w kao=6 ]
「……………………」[rhp]

[:quadrillion:][p_r_09][riri kao=8 as=on ]
「干嘛」[rhp]

[:princess:][puri_w kao=13 ]
「莉莉，你变了呢」[rhp]

[:quadrillion:][riri kao=5 hh=on ]
「是吗？变得更漂亮了？」[rhp]

[:princess:][puri_w kao=7 as=on ]
「不，不是这个意思」[rhp]

[:quadrillion:][p_r_21][riri kao=2 as=on ]
「就算是客套话也该点头吧……！」[rhp]

[:princess:][puri_w kao=13 ]
「该说是自然而然会说些像理央先生那样的话了吗」[rhp]

[fbgm]

[:quadrillion:][riri kao=6 as=on ]
「――――――诶」[rhp]

[:princess:][puri_w kao=13 hh=on ]
「之前你会刻意模仿理央，说些不符合性格的话对吧？[rhr]
_　那时候总觉得违和感很强，感觉不像是真正的莉莉」[rhp]
[:princess:]
「但如果是最近的莉莉，说那些肉麻的话[rhr]
_　不知为何就觉得挺适合的。为什么呢……因为是相恋的关系吗？」[rhp]

[:quadrillion:][riri kao=6 ]
「………………」[rhp]

[off_all]

;****************************************
[still storage="cg/d_r_3.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/d_r_3.png"]
[bgm storage="bgm_19.ogg"]
;****************************************

[:princess:]
「―――！」[rhp]

[::]
他将我的身体完全搂入臂弯之中。[rhr]
正因震惊而不知所措时，耳边传来夸德里利昂的低语。[rhp]

[:quadrillion:][p_r_25]
「………………笨蛋」[rhp]

[:princess:]
「莉、莉莉？　怎么了？」[rhp]

[:quadrillion:]
「…………像吗？」[rhp]

[:princess:]
「嗯？」[rhp]

[:quadrillion:][p_r_20]
「我看起来像理央……？」[rhp]

[:princess:]
「不，不是那么深刻的含义……[rhr]
_　只是想起之前也这样被开玩笑过，所以」[rhp]
[:princess:]
「不是说看起来像理央先生啦。没事的」[rhp]

[:quadrillion:]
「……这样啊……太好了」[rhp]
[:quadrillion:]
「…………我太在意了呢」[rhp]

[:princess:]
「发生什么了吗……？」[rhp]  

[:quadrillion:]
「…………没什么。只是从夜那里听到些不愉快的事」[rhp]

[:princess:]
「该不会是关于现实世界的……」[rhp]

[:quadrillion:][p_r_26]
「先说好，插手也是白费力气哦。我绝对不会说的」[rhp]

[:princess:]
「这样啊。有点遗憾呢」[rhp]

[:quadrillion:]
「……是想不起理央的事吗？」[rhp]

[:princess:]
「不是。那个……其实」[rhp]
[:princess:]
「…毕、毕竟是恋人。希望你能什么都和我说」[rhp]

[:quadrillion:]
「………………。亲密无间也要有分寸呢」[rhp]

[:princess:]
「是啊。反正莉莉也不像会袒露弱点的类型，我不会在意的」[rhp]

[:quadrillion:]
「要是被看到弱点会被嘲笑一辈子哦……」[rhp]

[:princess:]
「不会啦」[rhp]

[:quadrillion:][p_r_32]
「………………」[rhp]

[:princess:]
「………………？　那个」[rhp]

[:quadrillion:]
「……没什么。只是有点…累了……」[rhp]

[:princess:]
「这、这样啊……」[rhp]

[::]
被这样沉默地拥抱着，心跳有些加快。[rhr]
夸德里利昂只要不说话就超级帅气。这点现在绝对是致命伤。[rhp]

[:princess:]
[font color=0x4682b4]
（可、害羞就输了啊……！）[rhp]
[resetfont]

[:quadrillion:][p_r_04]
「…………我说你啊」[rhp]

[:princess:]
「！啊、是！？」[rhp]

[:quadrillion:]
「你不想了解理央的事吗？[rhr]
_　现实世界里，理央可是你的朋友哦」[rhp]

[:princess:]
「…………」[rhp]

[:quadrillion:]
「……你怎么想」[rhp]

[::]
……真意外。没想到会这么直截了当地问。[rhr]
因为一直以为这是刻意回避的话题，所以稍显语塞。[rhp]

[:princess:]
「……我不想强迫自己了解。[rhr]
_　每次牵扯到理央先生的事，莉莉你总是很痛苦的样子」[rhp]

[:quadrillion:][p_r_33]
「…………嘛嗯。我自己也有意识到」[rhp]

[:princess:]
「对不起呢。刚刚是我太迟钝了」[rhp]

[:quadrillion:]
「确实呢……」[rhp]

[:princess:]
「当回忆的时刻来临时，那才是该回忆的时机。[rhr]
_　所以我不会主动去探寻」[rhp]
[:princess:]
[font color=0x4682b4]
（虽然对夜有点过意不去呢……）[rhp]
[resetfont]

[:quadrillion:]
「…………哼嗯」[rhp]

[:princess:]
「话说回来，理央君明明是个温柔又稳重的人对吧？[rhr]
_　那莉莉就算倒立也绝对当不成公主啦！」[rhp]

[:quadrillion:][p_r_10]
「你啊……真是个失礼的女人呢」[rhp]

[:princess:]
「但事实就是如此吧？对着这么旁若无人的人、[rhr]
_　突然说要当王子殿下也太乱来了嘛」[rhp]
[:princess:]
「要说的话，可能理央先生模仿莉莉还更容易些」[rhp]

;****************************************
#
[bg storage="cg/d_r_3b.png" width="1280" height="720" time=500]
[cg storage="cg/d_r_3b.png"]
;****************************************

[:quadrillion:][p_r_13]
「――――――……哎」[rhp]

[:princess:]
「毕竟性格鲜明的人更容易模仿嘛。[rhr]
_　从这点来看莉莉就……」[rhp]

[:quadrillion:]
「………………」[rhp]

;****************************************
[::]
[still_end frame="win.png" storage="black.jpg" time=1000]
;****************************************

―――如果理央有天改变，不再是那个懦弱胆怯的家伙了，[rhr]
他的理想又会如何变迁呢。[rhp]
若我不再是他的憧憬，我这个存在―――[rhp]

[yurasu]

;****************************************
[bg  storage="train_08.jpg" time=100]
;*****************************************

[:princess:][puri_w kao=2 as=on ]
「呀！」[rhp]

[off_all]

[::]
话未说完身体突受冲击，上半身重重摔在地板上。[rhr]
理解到自己是被甩开的刹那，几乎没花什么时间。[rhp]
我惊愕地望向夸德里利昂。[rhp]

[:quadrillion:][riri kao=3 as=on ]
「…………」[rhp]

[off_all]

[::]
那表情究竟是恐惧，还是愤怒？[rhr]
夸德里利昂正用极度慌乱的眼神凝视着我。[rhp]
但随即就像无法忍受般别开了脸。[rhp]

[:quadrillion:][riri kao=8 ]
「…………对不起」[rhp]

[off_all]

[::]
夸德里利昂摇晃着站起身，径直朝门口走去。[rhr]
正当我要起身追赶时他忽然回头，使我猛然止步。[rhp]
那双平日盛气凌人的眼睛此刻脆弱得判若两人。[rhp]
随后他显出片刻踌躇，[rhr]
终于像下定决心般开口道。[rhp]

[off_all]

[:quadrillion:][riri kao=3 as=on ]
「公主……」[rhp]
[:quadrillion:]
「…………抱歉，暂时让我保持距离」[rhp]

[:princess:][puri_w kao=4 ]
「诶……？」[rhp]

[:quadrillion:][p_r_04][riri kao=2  as=on ]
「我为自己感到羞耻。没想到会被逼到[rhr]
_　要对你做出这种事的地步」[rhp]
[:quadrillion:]
「…………我对自己很失望。你没有任何错」[rhp]

[:princess:][puri_w kao=8 as=on ]
「怎、怎么会。是我的错。我又多管闲事了……」[rhp]

[off_all]

[::]
无论说什么，夸德里利昂都不看向这边。[rhp]
心跳越来越快。[rhp]
各种担忧接二连三地浮现又消失，一时语塞，[rhr]
我只能望着夸德里利昂紧绷的侧脸。[rhp]

[:quadrillion:][p_r_33][riri kao=2 ]
「……我需要冷静一下。想独自重新审视自己」[rhp]
[:quadrillion:]
「我很喜欢你。你也一直注视着我。[rhr]
_　这些我都明白……但只要事关理央，我就会失控」[rhp]
[:quadrillion:]
「…………所以对不起，请给我时间」[rhp]

[off_all]

[:princess:][puri_w kao=4 as=on ]
「！等等——」[rhp]

[off_all]

[se storage="door_08.ogg"]

[::]
话音未落，夸德里利昂已走出房间。[rhr]
一次都没有回头看我。[rhp]
…………不让我去找她，究竟是什么意思。[rhp]
我这是……被甩了吗？[rhp]

[:princess:][puri_w kao=3 ]
「不要……莉莉」[rhp]

[off_all]

[::]
失言是毋庸置疑的。而且那是与理央先生有关的事。[rhp]
话虽如此，却不知道哪里出了问题。[rhr]
如果我恢复记忆，就能知道原因了吧？[rhp]
……该怎么才能想起来？不知道。[rhr]
因为至今为止，连一件小事都没能回忆起来。[rhp]
和莉莉就这样结束了吗？[rhp]

[:princess:][puri_w kao=8 ]
「………………不」[rhp]

[off_all]

[::]
……不至于。莉莉说过『请给我时间』。[rhr]
所以还不算完全结束。[rhp]
而且和夸德里利昂不是争吵过很多次嘛。[rhr]
我的脑袋里装满和好的诀窍。......我觉得！[rhp]

虽然交往时会紧张，但喜欢是真的。[rhr]
虽然会打闹但不是讨厌。其实比谁都更喜欢。[rhp]
最重要的是，如果伤害了对方就想要道歉。[rhp]

[:princess:][puri_w kao=1 ]
「在这里退缩就不是我了……！」[rhp]

[off_all]

[::]
既然决定，就只需行动！[rhp]

;****************************************
[set_xx graphic="rule/krke_r.png" storage="train_01.jpg"]
;****************************************

之后过了一周。[rhp]
我用尽各种手段，为了改变莉莉的心情[rhr]
尝试了各种方法。[rhp]
比如把晚餐里莉莉喜欢的菜让给她，[rhr]
故意用和平常一样的态度搭话……[rhp]
……然而不仅毫无成效，[rhr]
反倒开始被更加躲着。[rhp]

[:princess:][puri_w kao=2 ]
「奇怪……[rhr]
_　明明已经做到每小时主动搭话3次了……」[rhp]

[off_all]

[chara_part name="jet" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:hutago:]
[font color=0x4682b4]
（该不会是因为这个吧……）[rhr]
（该不会是因为这个吧……）[rhp]
[resetfont]

[off_all]

[chara_part name="hakase" body=base kao=1 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:]
「真是的～别管他啦？克林就是这种德行。[rhr]
_　毕竟是成年女性嘛。很情绪化的」[rhp]

[:darknebula:]
「逼得太紧反而会让好转的事态恶化吧」[rhp]

[:princess:][puri_w kao=6 as=on ]
「是这样吗……但还是好不安啊」[rhp]

[off_all]

[:princess:][puri_w kao=3 ]
「为什么突然就被讨厌了呢。[rhr]
_　至少能知道原因也好啊……」[rhp]

[off_puri]

[::]
莉莉此刻的心境我无从知晓。[rhr]
那一定与他的出身有关。[rhp]
失去记忆的我，根本找不出合适的话语来安慰。[rhp]
彻底沮丧的我，今天只好无奈选择退让……[rhp]

;****************************************
[fbgm]
[set_xx graphic="rule/krke_r.png" storage="train_03.jpg"]
[bgm storage="bgm_15.ogg"]
;****************************************

[:quadrillion:][p_r_09][riri kao=2 as=on ]
「切……」[rhp]

[off_all]

[:kite:][p_k_35][kite kao=0 ]
「辛苦啦」[rhp]

[:quadrillion:][riri kao=8 as=on ]
「快斗……」[rhp]

[:kite:][kite kao=5 ]
「老板，咖啡。多糖」[rhp]

[:quadrillion:][p_r_27][riri kao=3 ]
「………………」

[off_all]

[se storage="se7_28.ogg"]
[rhp]

[chara_part name="riri" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:kite:]
「哪有把咖啡豆和热水分开给的店啊」[rhp]

[:quadrillion:][riri kao=5 hh=on ]
「这儿就是。我们店自助的」[rhp]

[:kite:][p_k_10][kite kao=3 as=on ]
「自助也不是这种……算了。糖呢？」[rhp]

[:quadrillion:][riri kao=8 ]
「没进货。公主不肯批货给我们」[rhp]

[:kite:][kite kao=1 ]
「你们吵架方式真是别致」[rhp]

[:quadrillion:][p_r_21][riri kao=6 ]
「才不是吵架！是那家伙单方面找茬。[rhr]
_　我都彻底无视他了，结果那混蛋居然……」[rhp]

[:kite:][kite kao=13 ]
「那？公主大人后来怎样了」[rhp]

[:quadrillion:][riri kao=2 ]
「后来个屁。在跟理央达成共识之前，[rhr]
_　我绝不会靠近那孩子」[rhp]

[:kite:][kite kao=0 as=on ]
「理央啊……虽然我搞不懂克林为啥会怂」[rhp]

[:quadrillion:][riri kao=2 as=on ]
「不用懂。也不想让你懂……[rhr]
_　老实说，我巴不得连你都忘了理央」[rhp]
[:quadrillion:]
「……因为不想在这个世界听到理央的事」[rhp]

[:kite:][p_k_30][kite kao=7 ]
「这可不像是理央朋友该说的话」[rhp]

[:quadrillion:][riri kao=5 ]
「无所谓。现在站在这里的是我，[rhr]
_　你只管说我的事就行」[rhp]

[:kite:][kite kao=12 as=on ]
「什么歪理……」[rhp]
[:kite:]
「……………………」[rhp]

[:quadrillion:][riri kao=2 ]
「干嘛」[rhp]

[:kite:][kite kao=2 ]
「没没没？」[rhp]

[:quadrillion:][p_r_12][riri kao=0 as=on ]
「搞什么恶心死了。[rhr]
_　有屁就放啊」[rhp]

[:kite:][kite kao=2 ]
「哼……那我直说了」[rhp]
[:kite:]
「我觉得克林那货超恶心的」[rhp]

[:quadrillion:][riri kao=3 as=on ]
「后悔听你说话了……」[rhp]

[:kite:][p_k_25][kite kao=02 ss=on]
「废话。毕竟将来理央可能会顶着[rhr]
_　娘娘腔暴力狂的脸」[rhp]
[:kite:]
「那种随便就能捏死理央的家伙，[rhr]
_　居然怕个小矮子太恶心了」[rhp]

[:quadrillion:][riri kao=12 ]
「…………」[rhp]

[:kite:][kite kao=5 ]
「一个人憋着才会这么扭曲吧。[rhr]
_　如果是我的话 听你倾诉倒也不是不行」[rhp]
[:kite:]
「虽然不算朋友 但好歹是同事」[rhp]

[:quadrillion:][p_r_29][riri kao=3 ]
「你这个人就非得用这种说法吗……」[rhp]
[:quadrillion:]
「…………不过也行吧。如果是快斗的话可以说」[rhp]

[:kite:][kite kao=5 hh=on ]
「注：似乎会计时收费」[rhp]

[:quadrillion:][p_r_24][riri kao=8 ]
「知道啦。……其实我也不太清楚详情」[rhp]
[:quadrillion:][riri kao=2 ]
「好像是理央阻止了宙再来这边」[rhp]

[:kite:][p_k_03][kite kao=0 as=on ]
「……，哼……」[rhp]

[:quadrillion:][p_r_32]
「…………我、害怕啊」[rhp]
[:quadrillion:]
「如果理央今后实现了理想 变成我这样的话[rhr]
_　现在在这里的我会变成怎样？会直接变成理央本人吗？」[rhp]
[:quadrillion:]
「我讨厌那样。我才不是理央[rhr]
_　也绝对不要变成理央……！」[rhp]

[:kite:][kite kao=2 ]
「首先请别再说『理央变成我这样』之类的话[rhr]
_　别玷污我记忆里那个可爱的理央」[rhp]

[:quadrillion:][riri kao=3 as=on ]
「你啊。人家这么认真在说[rhr]
_　你却在插科打诨！」[rhp]

[:kite:][kite kao=0 ]
「大概明白了。克林是害怕理央的改变吧」[rhp]

[:quadrillion:][p_r_12][riri kao=8 ]
「被这么轻描淡写总结反而火大……」[rhp]

[:kite:][kite kao=1 ]
「作为倾听者 我也有权发表意见」[rhp]
[:kite:]
「理央大概不会变成你这样吧」[rhp]

[:quadrillion:][riri kao=12 as=on ]
「我不是不明白。那家伙只是胆小但其实很努力」[rhp]
[:quadrillion:]
「虽然由我自己来说有点那个，但我是理央的理想形象。[rhr]
_　如果那家伙真心想改变的话，到时候就……」[rhp]

[:kite:][p_k_12][kite kao=2 ]
「理央是想背着我们变成人妖吗？」[rhp]

[:quadrillion:][riri kao=0 as=on ]
「………………不、不是的。那是南你的曲解」[rhp]

[:kite:][p_k_29][kite kao=5 ]
「那不就没问题了吗」[rhp]

[:quadrillion:][p_r_12][riri kao=12 as=on ]
「不、虽然是这样……但不是这种问题啦」[rhp]
[:quadrillion:]
「……我一直以来[rhr]
_　都活得不让自己成为理央的翻版」[rhp]
[:quadrillion:]
「因为那家伙身体孱弱，所以我从不间断训练。[rhr]
_　因为他有当厨师的梦想，所以我绝对不做料理」[rhp]
[:quadrillion:]
「即便如此我也是以自己的方式努力着。[rhr]
_　就算是感兴趣的事情，为了这个目标也都舍弃了」[rhp]
[:quadrillion:]
「……但是，如果是理央主动靠近的话就没办法拒绝了」[rhp]
[:quadrillion:]
「不是衣着或谈吐的问题。[rhr]
_　而是我能不能认可他达到了理想」[rhp]
[:quadrillion:]
「当那家伙成为想成为的自己时，留在这里的会是我？[rhr]
_　还是……」[rhp]

[:kite:][kite kao=2 ]
「说到这个份上我终于彻底明白你还在纠结什么了。[rhr]
_　既然如此，我能说的只剩这一句」[rhp]
[:kite:]
「到时就到时再说」[rhp]

[:quadrillion:][riri kao=2 ]
「哈？」[rhp]

[:kite:][p_k_18][kite kao=0 as=on ]
「为可能根本不会发生的现象吓得发抖有什么意义。[rhr]
_　作为我来说 更希望你能认真面对现在面临的问题」[rhp]
[:kite:]
「只不过是被暴力迟钝系姐姐甩了而已，[rhr]
_　难以置信的是公主竟然真的相当受伤」[rhp]

[:quadrillion:][riri kao=2 ]
「这算什么说法啊……」[rhp]

[:kite:][kite kao=1 ]
「我可不是因为担心你才陪你做恋爱咨询的。[rhr]
_　只是不想让挚友继续哭泣 希望你们能重修旧好而已」[rhp]

[:quadrillion:][p_r_21][riri kao=8 as=on ]
「……别自作主张。[rhr]
_　我也有考虑的权利啊」[rhp]

[:kite:][kite kao=13 ]
「公主 和你在一起的时候他最朝气蓬勃了。[rhr]
_　全情投入地生气 全情投入地大笑……总之就是活得特别尽兴」[rhp]
[:kite:]
「让我看到这样的他 我其实很感激克林。[rhr]
_　你其实也在后悔推开公主吧」[rhp]
[:kite:]
「一样的。你和公主都是。[rhr]
_　比起独自一人 两个人在一起时明显更加闪耀」[rhp]

[:quadrillion:][riri kao=3 hh=on ]
「…………！」[rhp]

[:kite:][kite kao=2 ]
「再说了 万一你这杞人忧天真说中了，[rhr]
_　当克林不再是克林时 我们一定会告诉南的」[rhp]
[:kite:]
「我的拳击沙袋对理央的角色来说负担太重……开玩笑的」[rhp]

[:quadrillion:][riri kao=4 as=on ]
「才不是什么开玩笑呢……」[rhp]
[:quadrillion:]
「………………不过，确实呢」[rhp]

[:kite:][p_k_27][kite kao=1 ]
「嗯嗯。正因为是克林的角色设定我们才能维持这种关系」[rhp]

[:quadrillion:][riri kao=5 ]
「不，你对理央也设了不少局吧」[rhp]

[:kite:][kite kao=3 ]
「咦？」[rhp]

[:quadrillion:][riri kao=13 hh=on ]
「我想说的不是这个。[rhr]
_　或许快斗说得对，就是……那个」[rhp]
[:quadrillion:]
「最坏情况下向南撒个娇就行了吧」[rhp]

[:kite:][p_k_06][kite kao=5 ]
「克林……！　状态上来了啊！」[rhp]

[:quadrillion:][p_r_07][riri kao=5 hh=on ]
「托你的福，感觉纠结这些事好蠢。[rhr]
_　……谢谢。心里轻松多了」[rhp]

[:kite:][kite kao=1 ]
「哦。……那接下来有什么安排？」[rhp]

[:quadrillion:][riri kao=0 ]
「去见公主」[rhp]

[:kite:][kite kao=12 ]
「哼……挺好的」[rhp]

[:quadrillion:][riri kao=1 ]
「快斗」[rhp]

[:kite:][kite kao=7 ]
「嗯？」[rhp]

[:quadrillion:][p_r_31][riri kao=13 hh=on ]
「我和理央不同。我不会伪装自己。[rhr]
_　不想做的事就不做 不想成为的人就不当」[rhp]
[:quadrillion:]
「而且我绝对 不会逃避那孩子的心意」[rhp]

[:kite:][kite kao=5 hh=on ]
「……这样啊。挺好的 很有克林风格」[rhp]

[:quadrillion:][riri kao=1 hh=on ]
「嘿嘿，对吧？」[rhp]

[off_all]

[:quadrillion:][riri kao=5 ]
「……好嘞！　那我这就出发啦」[rhp]

;****************************************
[set_xx graphic="rule/krke_r.png" storage="train_01.jpg"]
;****************************************

[:princess:][puri_w kao=8 as=on ]
「哈…………」[rhp]

[:drop:][p_d_04][drop kao=3 ]
「公主。最近真的经常叹气呢」[rhp]

[:princess:][puri_w kao=1 ]
「嗯——……总觉得，有点扫兴呢」[rhp]

[:drop:][drop kao=1 ]
「扫兴？」[rhp]

[:princess:][puri_w kao=12 ]
「你看，我不是被莉莉甩了吗？」[rhp]
[:princess:][puri_w kao=6 ]
「所以我觉得，已经没办法回到从前那样了。[rhr]
_　啊啊，再也回不去那段互相打闹的两人时光了……」[rhp]

[:drop:][p_d_22][drop kao=2 as=on ]
「那种关系还是别恢复比较好吧……」[rhp]

[:princess:][puri_w kao=2 ]
「但是啊。前几天莉莉呢，居然这么对我说。[rhr]
『运动胸罩女我才不要』……」[rhp]

[:drop:][drop kao=8 ]
「………………」[rhp]

[:princess:][puri_w kao=6 ]
[font size=28]
「你不觉得火大吗！？」[rhp]
[resetfont]

[:drop:][drop kao=8 as=on ]
「呜诶！」[rhp]

[:princess:][puri_w kao=5 ]
「明明说什么『不是你的错，都是我不好』这种话！！[rhr]
_　那我的胸罩也没什么问题吧～～～！？」[rhp]

[:drop:][p_d_17][drop kao=13 as=on ]
「这、这个～～～……我实在无法评判……」[rhp]

[:princess:][puri_w kao=2 as=on ]
「啊、不是啦！？不是运动胸罩哦。[rhr]
_　是成熟女性用的正经款式啦！要看……」[rhp]
[:princess:]
「…………不、不能看啦」[rhp]

[:drop:][drop kao=2 ]
「才不会看！！您在说什么啊！？」[rhp]

[off_all]

[::]
好险好险。差点就说漏嘴了。[rhr]
能说这种话的，只有夸德里利昂啊……。[rhp]

[:drop:][drop kao=13 ]
「……呵呵！」[rhp]

[:princess:][puri_w kao=0 ]
「嗯？怎么？」[rhp]

[:drop:][p_d_34][drop kao=1 hh=on ]
「啊、抱歉……[rhr]
_　公主你啊，学夸德里利昂说话还真像」[rhp]

[:princess:][puri_w kao=3 ]
「诶。是、是这样吗？」[rhp]

[:drop:][drop kao=13 ]
「超级像的！还想再看一次」[rhp]

[:princess:][puri_w kao=2 ]
「好啊？嗯嗯……咳咳」[rhp]
[:princess:]
「『布兹你个丑八怪！你又在别人衣服上画大胸肌了对吧！？[rhr]
_　这才不是什么乳头啦！」[rhp]

[:drop:][p_d_31][drop kao=14 hh=on ]
「啊哈哈哈！」[rhp]

[:princess:][puri_w kao=3 as=on ]
「那颗纽扣的位置怎么看都是乳头嘛」[rhp]

[:drop:][drop kao=1 ]
「那、那个先不管……真的好像啊！」[rhp]

[:princess:][puri_w kao=5 ]
「像乳头？」[rhp]

[:drop:][drop kao=13 ]
「不，是夸德里利昂」[rhp]

[:princess:][puri_w kao=3  ]
「有吗……？　不过反正都被甩了是事实。[rhr]
_　我要把这次失恋变成愉快的糗事讲出来……」[rhp]

[:drop:][drop kao=13 ]
「都不知道该不该笑……咦？」[rhp]

[fbgm]

[off_puri]
[yurasu]

[:drop:][drop kao=2 as=on ]
「――――――！！！」[rhp]

[:princess:][puri_w kao=13 ]
「啊？怎么了？发生什么？」[rhp]

[:drop:][p_d_04][drop kao=7 as=on ]
「没、没有，那个……」[rhp]

[off_puri]

[:drop:][drop kao=13 as=on ]
「……那！我、我先走了！！」[rhp]

[off_all]

[:princess:][puri_w kao=3 ]
「诶？等等多洛普！突然要去哪——」[rhp]

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼

;クォードリリオン
[voconfig sebuf=1 name=riri vostorage="riri/full/{number}.ogg" number=151]

[vostart]
;--------------------------------------------------------------------------------------------

[off_all]

[:quadrillion:]
「嘿～～～～……」[rhp]

[:princess:][puri_w kao=2 ]
「！！」[rhp]

[bgm storage="bgm_18.ogg"]

[:quadrillion:][riri kao=13 ]
「……原来你是这么看我的啊……」[rhp]

[:princess:][puri_w kao=7 as=on ]
「啊…………那个」[rhp]

[:quadrillion:][riri kao=2 ]
「听说你消沉才来看你……！[rhr]
_　这不是挺开心的嘛……！」[rhp]

[:princess:][puri_w kao=6 as=on ]
「不、不是的。不是你想的那样。[rhr]
_　那个————……黄金乳头，超帅的对吧」[rhp]

[:quadrillion:][riri kao=6 ]
「闭嘴！！」[rhp]

[yurasu]
[se storage="hand_05.ogg"]

[::]
瞬间，莉莉的一记猛烈弹指袭向我的额头。[rhr]
我按住额头蹲下，因疼痛而哆哆嗦嗦地颤抖。[rhp]

[:princess:][puri_w kao=3 as=on ]
「好疼啊啊啊……！额头要被弹指弹裂开了……！」[rhp]

[:quadrillion:][riri kao=2 ]
「今天我绝不原谅你！！[rhr]
_　明明我好不容易才想过来和好的！」[rhp]

[:princess:][puri_w kao=3 ]
「……！哎……和、和好？」[rhp]

[:quadrillion:][riri kao=8 ]
「～～～～，没错！[rhr]
_　因为没办法才想着重新和你和好」[rhp]

[:princess:][puri_w kao=12 as=on ]
「真、真的……？」[rhp]

[:quadrillion:][riri kao=5 ]
「我又不是你，才不会撒那种无聊的谎呢」[rhp]

[:princess:][puri_w kao=3 ]
「你会原谅我吗？把你和理央比较的事……」[rhp]
[:princess:]
「…………你还会，再次喜欢上我吗？」[rhp]

[:quadrillion:][riri kao=2 ]
「哼！该怎么办呢。都被模仿得那么烂了……」[rhp]

[yurasu]

[:princess:][puri_w kao=13 hh=on ]
「太好了～～～～～！！」[rhp]

[:quadrillion:][riri kao=2 hh=on ]
「呜！等……！？喂！笨、笨蛋。快放开我！」[rhp]

[:princess:][puri_w kao=2 ]
「才不会放开！这次绝对不会再放开！」[rhp]
[:princess:]
「其实我一直都很寂寞……！[rhr]
_　我一直在等你主动和我说话啊！」[rhp]

[:quadrillion:][riri kao=4 ]
「……！……你……」[rhp]

[:princess:][puri_w kao=3 hh=on ]
「莉莉真是个笨蛋！[rhr]
_　明明是男生，却像女生一样东想西想！」[rhp]
[:princess:]
「我不是说过过去的你怎样都无所谓吗。[rhr]
_　无论是现在还是将来，我喜欢的人都只有莉莉」[rhp]
[:princess:]
「……呜、莉莉！？」[rhp]

[:quadrillion:][riri kao=6 ]
「诶」[rhp]

[:princess:][puri_w kao=2 ]
「说起来还没好好问过……！[rhr]
_　趁现在干脆问清楚！」[rhp]
[:princess:]
「莉莉、你喜欢我吗！？」[rhp]

[:quadrillion:][riri kao=3 as=on ]
「…………！　嗯……」[rhp]

[:princess:][puri_w kao=3 ]
「不说吗？」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:quadrillion:][riri kao=6 ]
「……………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:princess:][puri_w kao=5 ]
「…………。『有点布兹哦！你这家伙我的衣服上，」[rhp]

[:quadrillion:][riri kao=2 ]
「快住手啦！想说就说啊！」[rhp]
[:quadrillion:]
「……呜、…………公主」[rhp]

[:princess:][puri_w kao=13 ]
「嗯……！」[rhp]

[:quadrillion:][riri kao=2 hh=on ]
「啊……你这家伙、我……」[rhp]

[:princess:][puri_w kao=14 ]
「好！」[rhp]

[:quadrillion:][riri kao=8 ]
「……真、真要说了反而……总觉得、好害羞啊……」[rhp]

[:princess:][puri_w kao=2 hh=on ]
「哎！？等等！这样逃跑可不行哦」[rhp]

[:quadrillion:][riri kao=12 ]
「这副软绵绵的样子、简直就像理央一样……！」[rhp]

[:princess:][puri_w kao=5 ]
「不是理央先生。[rhr]
_　我就是喜欢现在这样软绵绵烦恼着的莉莉啦」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:quadrillion:][riri kao=8 hh=on ]
「………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:princess:][puri_w kao=6 ]
「这……」[rhp]

[:quadrillion:][riri kao=4 hh=on ]
「……啊啊～～～但是不行！[rhr]
_　这种郑重其事的氛围、和理央没关系就是觉得羞人！！」[rhp]

[:princess:][puri_w kao=2 ]
「真是的……！说什么呢……明明希望你用言语说出来啊」[rhp]
[:princess:]
「不然我会不安的。[rhr]
_　又像之前那样、突然就被推开……」[rhp]

[:quadrillion:][riri kao=7 hh=on ]
「！！　啊、呃……那个……」[rhp]
[:quadrillion:]
「…………………………并不讨厌你呢，你的事」[rhp]

[:princess:][puri_w kao=5 ]
「『这又不是乳头！』」[rhp]

[:quadrillion:][riri kao=2 hh=on ]
[font size=28]
「喜欢你啊―――！！！」[rhp]
[resetfont]

[:princess:][puri_w kao=2 ]
「！！　吵、吵死了」[rhp]

[:quadrillion:][riri kao=2 hh=on ]
「我对你的心意绝不会输给理央和落合！[rhr]
_　就是这么喜欢公主！　深爱着你！」[rhp]
[:quadrillion:]
「无论发生什么都不会让给任何人！！！！」[rhp]

[:princess:][puri_w kao=4 hh=on ]
「…………！」[rhp]

[:quadrillion:][riri kao=6 ]
「哈啊……哈啊……！　你、你这家伙……！[rhr]
_　用威胁别人换来的爱的告白谁会开心……！？」[rhp]

[:princess:][puri_w kao=13 hh=on ]
「很开心……」[rhp]

[:quadrillion:][riri kao=2 hh=on ]
「是嘛！　那可真是太好了……！　切！！」[rhp]

[:princess:][puri_w kao=5 hh=on ]
「因为，我知道这是真心话呀」[rhp]

[:quadrillion:][riri kao=3 ]
「……！　什、什么意思啊那个……」[rhp]

[:princess:][puri_w kao=13 ]
「……我呢，被甩的时候。[rhr]
_　总觉得自己在哪儿体会过这种心情」[rhp]
[:princess:]
「就像唯独我被抛弃，大家都去了别处的感觉」[rhp]

[:quadrillion:][riri kao=6 ]
「……诶」[rhp]

[:princess:][puri_w kao=3 as=on ]
「真奇怪呢。明明没有这样的记忆」[rhp]
[:princess:]
「…………但反正，再也不要那种心情了」[rhp]

[:quadrillion:][riri kao=12 ]
「……公主……」[rhp]

[:princess:][puri_w kao=13 hh=on ]
「莉莉。无论发生什么，都不要再让出你的心意了」[rhp]
[:princess:]
「我早就是只属于莉莉的女孩子了。[rhr]
_　根本不需要顾虑什么的」[rhp]
[:princess:]
「……从今往后要永远、待在我身边哦」[rhp]

[:quadrillion:][riri kao=1 ]
「…………、…………」[rhp]
[:quadrillion:]
「………………遵命」[rhp]

[off_all]

[::]
…………或许都是我杞人忧天了。[rhr]
只有我在这里东想西想，简直像个笨蛋一样。[rhp]
这个什么都没考虑的家伙却能如此直率地说出喜欢。[rhp]
……这样的我，肯定比理央还胆小吧。[rhp]

;****************************************
[still storage="cg/d_r_4.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/d_r_4.png"]
;****************************************

[:quadrillion:]
「…………公主」[rhp]

[:princess:]
「――――――！」[rhp]

[:quadrillion:]
「……哼哼。吓了一跳吗？」[rhp]

[:princess:]
「当、当然吓到了……！突突、突然就亲上来什么的！」[rhp]

[:quadrillion:]
「呵呵呵！总不能老是被你威胁呀」[rhp]
[:quadrillion:]
「你之前为所欲为了那么久，稍微报复一下也没关系吧」[rhp]

[:princess:]
「……！」[rhp]

[:quadrillion:]
「……我爱你，公主」[rhp]
[:quadrillion:]
「要只看着我一个人哦」[rhp]
[:quadrillion:]
「…………要是敢看别人，我可不饶你」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
[fbgm]

#
[s_mask color=0x000000 time=3000]
[bg storage="black.jpg" time=100]
; 夜フィルター
[filter layer="1" brightness="60"]
; ウィンドゥの設定
[position layer="message0" frame="win2.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[s_mask_off time=3000]

;****************************************

数日前[rhp]

;****************************************
[bg storage="sky_07.jpg" time=2000]
;****************************************

[bgm storage="bgm_09.ogg"]

我把醒来的事向矢部老师他们报告后、[rhr]
稍微检查了身体状况、决定就这样直接无事回家了。[rhp]
…………本该是这样。[rhp]
是因为发生了那种事后吧、[rhr]
心情怎么也高涨不起来。[rhp]
我也提不起劲直接回家、在附近走了走、[rhr]
在长椅上反复发呆，回过神来已是夜晚。[rhp]

;****************************************
[bg storage="hsps_02m.jpg" time=1000]
;****************************************

…………然后，我又不知悔改地回到了这里。[rhp]
虽然老师们很惊讶，但当我表示落了东西时他们似乎接受了这个理由，[rhr]
没有多问就让我顺利进入了医院内部。[rhp]

;****************************************
[bg storage="hsps_06n.jpg" time=1000]
;****************************************

穿过入口大厅，漫无目的地在院内随意巡视了一会儿。[rhp]
记得从前这里还有不少人，[rhr]
如今亮着灯的房间屈指可数。[rhp]
听说几年后就要和主楼的儿科合并了。[rhr]
希望延长治疗的父母能多些倒也不是坏事。[rhp]
我也赞成这个方案，那正是矢部老师期望的医疗形态。[rhr]
虽然会感到寂寞，但对于尚且留在世间的孩子们来说，我的回忆根本无关紧要。[rhp]
……这样就好。[rhp]

;****************************************
[bg storage="hsps_02m.jpg" time=1000]
;****************************************

想着这些的时候，或许终究是因为现在无处可去，[rhr]
很快便无物可看，又折返回到了入口处。[rhp]

;****************************************
[bg storage="hsps_12n.jpg" time=1000]
;****************************************

「糠星夜」。难以置信，这幅画里寄宿着神明。[rhp]
它曾以孩童之姿引领我前往银河世界。[rhr]
而这幅画正是连接现实与异界的入口。[rhp]
我始终向往着这片银河―――[rhp]

;****************************************
[bg storage="hsps_02m.jpg" time=1000]
;****************************************

[:yoru:]
「晚上好」[rhp]

[::]
突然从背后传来声音。[rhr]
声音的主人无需思考。[rhp]

[chara_part name="sora" body=prain kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sora:]
「…………夜」[rhp]

[:yoru:][yoru kao=0 ]
「招呼也不打就离开吗。是羞于自己的无礼而回来的吗」[rhp]

[:sora:][p_so_22]
「不对。……已经回不去了。总觉得，心里乱糟糟的」[rhp]

[:yoru:][yoru kao=2 ]
「那也是理所当然的吧。[rhr]
_　我并不想承认那样的蠢材构造能让人满足[rhp]
[:yoru:]
「就在见到他们的那一瞬间，和我的约定似乎就被抛到九霄云外了呢」[rhp]

[:sora:][sora body=prain kao=2 as=on ]
「真是个句句带刺的家伙……我也没说那样就很好」[rhp]

[:yoru:][p_y_28]
「辩解就免了。……我并没有责怪你的意思。[rhr]
_　即便拥有同样的热情，武和你的立场与他们不同」[rhp]
[:yoru:]
「对你来说，这想必是个残酷的任务吧」[rhp]

[:sora:][sora body=prain kao=3 ]
「……你不生气吗」[rhp]

[:yoru:][yoru kao=6 ]
「当然生气。但我也有需要反省的地方」[rhp]
[:yoru:][yoru kao=3 ]
「……对你来说是个残酷的梦吧。抱歉」[rhp]

[:sora:][sora body=prain kao=3 ]
「……倒也谈不上残酷。很久没这么犯傻反而挺开心的」[rhp]
[:sora:]
「不过确实让我明白了许多事」[rhp]
[:sora:]
「……人终究敌不过流逝的岁月啊」[rhp]

[:yoru:][yoru kao=2 ]
「……宙……」[rhp]

[:sora:]
「喂夜。有件事想拜托你」[rhp]

[:yoru:][yoru kao=0 ]
「……，……姑且听听看吧」[rhp]

[off_all]

[fbgm]

[:sora:][sora body=prain kao=6 ]
「………………」[rhp]

[off_all]

[:yoru:][yoru kao=0 as=on ]
「……宙？」[rhp]

[off_all]

[:sora:][sora body=prain kao=7 ]
「没事……」[rhp]

[off_all]

[chara_part name="sora" body=prain kao=0 as=on ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sora:]
「…………抱歉，稍微等我一下」[rhp]

[:yoru:][yoru kao=0 ss=on]
「啊？你在说什……」[rhp]

[off_all]

[bgm storage="bgm_40.ogg"]

[:rio:][rio body=prain kao=3 as=on ]
「宙君！」[rhp]

[off_all]

[:yoru:][yoru kao=4 ]
「！」[rhp]

[off_all]

[:sora:][sora body=prain kao=2 ]
「理央……！你为什么会，」[rhp]

[:rio:][rio body=prain kao=8 hh=on ]
「矢部老师来过电话了。说宙君在这里。[rhr]
_　听说你想不开，我很担心……！」[rhp]

[:sora:][sora body=prain kao=0 ]
「笨蛋。既然听说了就该明白吧？我只是贫血而已……」[rhp]

[se storage="hand_05.ogg"]

[:sora:]
「―――！」[rhp]

[::]
突然，脸颊传来一阵冲击。[rhp]
火辣辣的痛感让我用手捂住脸，这才意识到自己被打了。[rhp]

[:rio:][rio body=prain kao=3 hh=on ]
「呜……呜呜……！」[rhp]

[off_all]

[::]
理央流着泪，无力地放下了扇巴掌的手。[rhp]

[chara_part name="rio" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="rio" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sora" body=prain kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:rio:]
「宙君这个大笨蛋！为什么非要逞强到晕倒？[rhr]
_　为什么不找我商量啊？」[rhp]

[:sora:][sora body=prain kao=3 as=on ]
「……、理央……」[rhp]

[:rio:][rio body=prain kao=8 as=on ]
「宙君你总是太不坦率了。[rhr]
_　一直固执地活着，这我都知道的……！」[rhp]
[:rio:]
「因为我……！我也是，宙君的―――」[rhp]

[:sora:][sora body=prain kao=6 ]
「……？」[rhp]

[:rio:][rio body=prain kao=4 ]
「……没、没什么」[rhp]
[:rio:]
「总之……我很担心。仅此而已……」[rhp]

[:sora:][sora body=prain kao=12 ]
「抱歉。乱来是我的错。[rhr]
_　……因为理央进了私立学校看起来很忙」[rhp]
[:sora:]
「我也觉得总打扰你可能不太好。[rhr]
_　所以来这里也变少了」[rhp]

[:rio:][rio body=prain kao=3 as=on ]
「那是……、…………」[rhp]
[:rio:]
「…………抱歉，说的对。[rhr]
_　明明是个抛弃朋友的家伙，还摆出高高在上的样子」[rhp]

[:sora:][sora body=prain kao=2 ]
「啊？丢掉了？你在说什……」[rhp]

[:rio:][rio body=prain kao=7 as=on ]
「因为就是这样吧。宙君你也该注意到了」[rhp]
[:rio:]
「我是从临终关怀院故意——」[rhp]

[:sora:][sora body=prain kao=2 ]
「……、现在说这些太迟了」[rhp]
[:sora:]
「理央不再来这里的理由，大家其实都心里有数。[rhr]
_　但谁都没有对此多说些什么」[rhp]

[:rio:][rio body=prain kao=8 ]
「…………！」[rhp]

[:sora:][sora body=prain kao=0 ]
「不必在意。这都是无可奈何的事」[rhp]

[:rio:][rio body=prain kao=8 ]
「………………、真是个怪人呢 宙君」[rhp]
[:rio:]
「对他人温柔得过分 对自己却苛刻得惊人……[rhr]
_　明明通常都是反过来的啊」[rhp]
[:rio:]
「和近君那时候也是 薰君那时候也是。[rhr]
_　你总是露出困扰的表情 最后变成放弃的眼神……从没让人见过哭泣的样子」[rhp]

[:sora:][sora body=prain kao=6 ]
「…………、本来就不是该展示给别人看的东西」[rhp]

[:rio:][rio body=prain kao=0 as=on ]
「我觉得啊 身体的伤终会痊愈。[rhr]
_　但心灵的伤痕 即使时间流逝也不会消失。根本无法视而不见」[rhp]
[:rio:]
「这道伤疤矢部医生有，米卡小姐有，我也有，大家都有。[rhr]
_　可以和你一起为同样的疼痛哭泣。所以啊，宙君」[rhp]
[:rio:]
「只有你没必要隐藏这道伤痕」[rhp]

[off_all]

[::]
……理央的话语，让我感觉有什么东西崩塌了。[rhp]
紧绷的东西雪崩般溃散，心脏在震颤。[rhp]
长久压抑的过往喷涌而出。[rhp]

[:sora:]
「…………理央」[rhp]

;****************************************
;スチル
[still storage="cg/d_r_5.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/d_r_5.png"]
;****************************************

[:sora:]
「――――――我以前，是个怎样的家伙……？」[rhp]
[:sora:]
「很烦人吧？是个刻薄又讨人厌的小鬼吗？」[rhp]
[:sora:]
「明明说着谎……还说要做医生治好大家什么的」[rhp]
[:sora:]
「……你对我失望了吗？」[rhp]

[:rio:]
「这种事……怎么可能啊」[rhp]
[:rio:]
「宙君比谁都努力。大家都知道的」[rhp]

[:sora:]
「…………可、可我已经没有梦想了」[rhp]
[:sora:]
「没有想治愈的人。也没有想拯救的人……」[rhp]
[:sora:]
「……毕竟大家早就获得幸福了啊」[rhp]
[:sora:]
「从一开始就没我出场的份……」[rhp]

[:rio:]
「宙君……」[rhp]
[:rio:]
「…………所以才有我在啊」[rhp]

[:sora:]
「…………？」[rhp]

[:rio:]
「这头发和眼睛，现在虽然能接受了，[rhr]
_　但还是有好多不方便的地方」[rhp]
[:rio:]
「出门必须带遮阳伞，去游乐园也马上会累，[rhr]
_　光是提大海当候选就会惹人生气」[rhp]
[:rio:]
「我觉得自己还挺有治愈价值的……[rhr]
_　不能成为你的目标吗」[rhp]

[:sora:]
「……目标……」[rhp]

[:rio:]
「呃、还有……对了。治疗懦弱性格的药之类的？[rhr]
_　因为这性格我吃了不少亏，也后悔了很多次……」[rhp]
[:rio:]
「所以我想变得更坚强。[rhr]
_　不想再胆小，要成为能明确表达意见的人……」[rhp]
[:rio:]
「……[player2]想变得像小町那样。这就是我的目标」[rhp]

[:sora:]
「…………」[rhp]

;****************************************
#
[bg storage="cg/d_r_5b.png" width="1280" height="720" time=500]
[cg storage="cg/d_r_5b.png"]
;****************************************

[:sora:]
「…………噗」[rhp]

[:rio:]
「为、为什么笑啦！？」[rhp]

[:sora:]
「原来如此……这样啊……」[rhp]
[:sora:]
「…………夸德里利昂，原来是这么回事」[rhp]

[:rio:]
「哈……？夸、……什么？」[rhp]

[:sora:]
「不，没什么。[rhr]
_　只是突然想起个熟人妖罢了」[rhp]

[:rio:]
「人妖……？―――！！！」[rhp]
[:rio:]
「等等等会儿！　[player2]想变得像小町不是那个意思啦！？[rhr]
_　该怎么说呢就是、人格层面的意义～～……！」[rhp]

[:sora:]
「我知道的」[rhp]

[:rio:]
「当真！？敢乱说我就生气哦……！[rhr]
_　我明明很在意被人说像女孩子的说」[rhp]
[:rio:]
「为了更有男子气概，最近都开始健身了！」[rhp]

[:sora:]
「噗！！」[rhp]

[:rio:]
「所以你到底在笑什么！！」[rhp]

[:sora:]
「对、对不起……不过我觉得我还是别练肌肉比较好……」[rhp]

[:rio:]
「是吗……可我想着总有一天要练得壮壮的。[rhr]
_　让谁都没法再说我是娘娘腔」[rhp]

[:sora:]
「估计还是会被说」[rhp]

[:rio:]
「为什么！？」[rhp]

[:sora:]
「抱歉抱歉，开玩笑的」[rhp]

;****************************************
[still_end frame="win2.png" storage="hsps_02m.jpg" time=1000]
;****************************************

[chara_part name="rio" body=base kao=6 as=off ss=off hh=on hr=on ]
[chara_show name="rio" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sora" body=prain kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]


[:sora:][p_so_07]
「……谢谢了，理央」[rhp]

[:rio:][rio body=prain kao=3 ]
「没事。我也正处于低谷期呢……有宙君在身边真好」[rhp]
[:rio:]
「人生在世最需要的就是……朋友对吧？」[rhp]

[:sora:][sora body=prain kao=12 ]
「…………朋友啊」[rhp]

[off_all]

[::]
是啊。在这个世界也有很多重要的人。[rhp]
在追梦路上推了我一把的母亲。[rhr]
对薰和[player2]倾尽全力的矢部老师与大美贺小姐他们。[rhp]
还有……[rhp]

[:rio:][rio body=prain kao=13 hh=on ]
「那回去吧，宙君」[rhp]

[off_all]

[chara_part name="rio" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="rio" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sora" body=prain kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sora:]
「诶」[rhp]

[:rio:][rio body=prain kao=5 ]
「你也要坐巴士吧？末班车应该快发了」[rhp]

[:sora:][sora body=prain kao=7 ]
「啊……，……」[rhp]

[:rio:][rio body=prain kao=8 as=on ]
「宙君？」[rhp]

[:sora:][p_so_22][sora body=prain kao=6 as=on ]
「……………………」[rhp]

[off_all]

[::]
『这伤痕矢部医生有，米卡小姐有，我也有，大家都有。[rhr]
_  我们能用和你相同的伤痛陪你哭泣。所以说啊，宙君』[rhp]
『只有你没必要隐藏那份伤痕』[rhp]

[:sora:][sora body=prain kao=12 ]
「…………、夜」[rhp]

[off_all]

[:yoru:][yoru kao=0 ]
「…………」[rhp]

[off_all]

[:rio:][rio body=prain kao=4 as=on ]
「夜……？」[rhp]

[off_all]

[:sora:][p_so_04][sora body=prain kao=8 ]
「刚才的话，就当没说过吧」[rhp]
[:sora:]
「我……」[rhp]
[:sora:]
「…………我还要，在这里坚持下去」[rhp]

[off_all]

[:yoru:][p_y_01][yoru kao=1 ]
「是吗」[rhp]
[:yoru:]
「…………太好了」[rhp]

[off_all]

[chara_part name="rio" body=base kao=3 as=on ss=off hh=off hr=on ]
[chara_show name="rio" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sora" body=prain kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:rio:]
「怎、怎么了？……你刚才说的『夜』是什么意思？」[rhp]

[:sora:][sora body=prain kao=5 ]
「…………昏倒的时候，做了个短暂的梦」[rhp]
[:sora:]
「梦见和大家一起乘坐银河铁道。[rhr]
_　……美好得让人舍不得醒来的，最棒的梦」[rhp]

[:rio:][rio body=prain kao=8 ]
「银河铁道……」[rhp]

[off_all]

;****************************************
#
[bg storage="hsps_12n.jpg" time=1000]
;****************************************

[:sora:]
「理央。……虽然现在只剩下我们两个人了」[rhp]
[:sora:]
「那群家伙，肯定不希望我们一辈子以泪洗面。[rhr]
_　为了他们，我们这些留下来的人一定能做些什么」[rhp]

;****************************************
#
[bg storage="sky_07.jpg" time=1000]
;****************************************

[:sora:]
「前进吧理央。从这份悲伤中，哪怕只迈出一步」[rhp]
[:sora:]
「……可不能输给[player2]那些实现了梦想的家伙啊！」[rhp]

;****************************************
[fbgm]
#
[s_mask color=0xffffff time=3000]
; 背景表示
[bg storage="sea_01.jpg" time=100]
; 全部のフィルターを打ち消す
[free_filter ]
; ウィンドゥの設定
[position layer="message0" frame="win.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[s_mask_off time=3000]

[bgm storage="bgm_39.ogg"]
;****************************************

在我的强烈要求下，银河铁道再次来到那个度假胜地的海洋之星。[rhp]
虽然有人（主要是快斗）抱怨怎么又来这里，[rhr]
但在我看来这次的确有所不同。[rhp]
举个最明显的不同之处——[rhp]

;****************************************
[bg storage="sea_02.jpg" time=500]
;****************************************

[:princess:][puri_w body=mizugi kao=4 hh=on ]
「烧烤架！？」[rhp]

[:drop:][drop kao=5 hh=on hat=sea ]
「好的！　这次听说您特别希望我们准备这些！」[rhp]
[:drop:]
「请看这些肉、鱼、还有棉花糖！[rhr]
_　这可是难得的和好纪念旅行，所以我干劲十足呢！」[rhp]

[:princess:][puri_w body=mizug kao=7 ]
「该、该不会是要……用这些来做料理吧……」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:quadrillion:][riri body=mizugi kao=13 hh=on ]
「……呵呵呵！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[off_all]

[chara_part name="hakase" body=mizugi kao=4 as=on ss=off hh=off hr=on msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="peku" body=mizugi kao=3 as=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:][p_vl_17]
「啊、啊哇哇……啊哇哇哇哇……！」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[chara_part name="hakase" body=mizugi kao=2 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720" left="40" top="0" wait="false" time=150]
[chara_part name="riri" body=mizugi kao=5 as=off ss=off hh=on hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="peku" body=mizugi kao=4 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="720" top="0" ait="true" time=150]

[:quadrillion:]
「怎么样！？　这闪耀的乳白色！！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:vulpecula:][p_vl_04][peku body=mizugi kao=3 as=on ]
「克林你在干什么啊！？　拿着打蛋器和碗！」[rhp]

[:darknebula:][p_da_17][hakase body=mizugi kao=6 as=on ]
「是撞到头了吗？　还是中暑了！？」[rhp]

[:vulpecula:][peku body=mizugiu kao=13 hh=on ]
「隐约还能闻到美味的香气……」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:quadrillion:][riri body=mizugi kao=5 hh=on ]
「哼嗯……你连这个都不知道吗？」[rhp]
[:quadrillion:]
「这叫水果冻，是非常～科学的甜～品哦！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[off_all]

[chara_part name="drop" body=base kao=1 as=off ss=off hh=off hr=on hat=sea ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kite" body=mizugi kao=6 as=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:kite:][p_k_13]
「这么热的天气就别把乳制品带出来了吧」[rhp]

[:drop:][drop kao=5 hh=on hat=sea ]
「没问题的！　因为有施魔法！」[rhp]

[:kite:][kite kao=13 body=mizugi ]
「那第一口就让多洛普吃吧」[rhp]

[:drop:][p_d_25][drop kao=7 as=on hat=sea ]
「！？　没、没问题啦……！？　肚子应该不会坏掉……大概」[rhp]

[off_all]

[chara_part name="riri" body=mizugi kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="peku" body=mizugi kao=5 as=off ss=off hh=on hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:]
「原来如此，加入牛奶就会凝固呢。[rhr]
_　不过用这种魔法做点心是不是作弊啊～？」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:quadrillion:][riri body=mizugi kao=5 hh=on ]
「听好了，这不是魔法。[rhr]
_　哼，对你来说还太早了呢……」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:vulpecula:][p_vl_09][peku body=mizugi kao=6 ]
「过分！！　虽然是佩奇姐姐我啦！！」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:quadrillion:][riri body=mizugi kao=13 ]
「哦呵呵呵呵！小不点在说什么呢～！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[off_all]

[:princess:][puri_w body=mizugi kao=3 as=on ]
「……烧烤呢？」[rhp]

[:drop:][p_d_02][drop kao=13 hat=sea ]
「啊、那个由我来负责！[rhr]
_　据本人所说，现在烧烤还为时尚早」[rhp]

[:princess:][puri_w body=mizugi kao=2 ]
「只是烤一下有什么早不早的……算了也罢」[rhp]

[:drop:][drop kao=11 hat=sea ]
「不过说起来，他提出要烧烤时真是吓了我一跳。[rhr]
_　那个夸德里利昂居然开始下厨什么的」[rhp]

[off_all]

[chara_part name="jet" body=mizugi kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=mizugi kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:jet:][p_j_09]
「该不会是脑袋被门夹了吧？」[rhp]

[:heartshape:][p_h_18][hati body=mizugi kao=13 ]
「和公主吵架越吵越激烈……！？　真是火热的发展啊！」[rhp]

[off_all]

[:drop:][p_d_32][drop kao=3 as=on hat=sea ]
「没、没那回事。他神志清醒得很。[rhr]
_　也没有巨乳不足之类的问题」[rhp]

[:princess:][puri_w body=mizugi kao=2 ]
[font color=0x4682b4]
（虽然根本没人提这个）[rhp]
[resetfont]

[:drop:][drop kao=13 hat=sea ]
「听说他意外觉得很有趣，每天变着花样做料理，[rhr]
_　然后端给公主和沃尔佩克拉女士品尝呢」[rhp]

[:princess:][puri_w body=mizugi kao=14 hh=on ]
「是啊。昨天还在做猫饭来着」[rhp]

[off_all]

[chara_part name="jet" body=mizugi kao=3 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=mizugi kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:jet:][p_j_19]
「那能算料理吗？」[rhp]

[:heartshape:][hati body=mizugi kao=1 as=on ]
「这可是从婴儿阶段入门的快手料理啊！！」[rhp]

[off_hati]
[chara_part name="drop" body=mizugi kao=13 as=off ss=off hh=on hr=on hat=sea ]
[chara_show name="drop" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:drop:][p_d_02]
「不管怎么说都是进步吧。[rhr]
_　以前那个会把化妆品乱扔在水槽里的夸德里利昂哦？」[rhp]

[:jet:][jet body=mizugi kao=13 ]
「说得对。现在的他感觉整个人都放松了。[rhr]
_　以前总像在对抗什么似的浑身带刺」[rhp]

[:princess:][puri_w body=mizugi kao=1 hh=on ]
「呵呵……！　就是啊。我也这么觉得」[rhp]

[off_all]

[chara_part name="hakase" body=mizugi kao=0 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="peku" body=mizugi kao=5 as=off ss=off hh=on hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:][p_vl_16]
「喂——！　公主酱～水果冻很好吃哦～。一起来吃吧！」[rhp]

[:darknebula:][p_da_08][hakase body=mizugi kao=13 hh=on ]
「不可思议……！　既不是酸奶，也不是巴伐露，这种口感……！」[rhp]

[:princess:][puri_w body=mizugi kao=2 hh=on ]
「水果冻……好像有点让人在意呢……」[rhp]

[off_all]

[:princess:][puri_w body=mizugi kao=6 as=on hh=on ]
「……Hey老板！　来份水果冻！」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:quadrillion:][riri body=mizugi kao=13 hh=on ]
「不好意思啦～今天的巨乳卖完了哟」[rhp]

[:princess:][puri_w body=mizugi kao=2 as=on ]
「不、所以说我不是要巨乳而是水果冻啊」[rhp]

[:quadrillion:][riri body=mizugi kao=3 ]
「哎呀糟糕。真抱歉……要是多备点货就好了」[rhp]

[:princess:][puri_w body=mizugi kao=13 ]
「…………～～～那我就按你开价买下你的私人储备」[rhp]

[yurasu]
[se storage="hand_05.ogg"]

[:princess:]
「好痛！！！　又弹我脑门……！」[rhp]

[:quadrillion:][riri body=mizugi kao=2 ]
「你这家伙！　把巨乳当成什么了！？[rhr]
_　私、私私私私人储备……！？　这个浪货！！！」[rhp]

[:princess:][puri_w body=mizugi kao=6 ]
「闭嘴变态！　超级变态！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[off_all]

[chara_part name="jet" body=mizugi kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=mizugi kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:jet:][p_j_21]
「你们俩不是已经和好了吗」[rhp]

[:heartshape:][hati body=mizugi kao=4 as=on ]
「说起来提到巨乳，我好像在哪听说过要是公主没达到C杯[rhr]
_　克林就不做饭来着」[rhp]

[:princess:][puri_w body=mizugi kao=7 as=on ]
「啊、虽然被糊弄过去了但确实说过这种话呢……[rhr]
_　那现在要汇报进度吗？　关于我的胸部成长了多少呀」[rhp]

[:heartshape:][hati body=mizugi kao=2 hh=on as=on ]
「不知羞耻也要有个限度啊公主！！」[rhp]

[:jet:][jet body=mizugi kao=6 as=on ]
[font color=0x4682b4]
（恋爱真的会让人性格大变啊……）[rhp]
[resetfont]

[:princess:][puri_w body=mizugi kao=5 hh=on ]
「哼～！　其实……增加了0.5厘米呢～～」[rhp]

[:hutago:]
「哦！！」[rhr]
「这样啊……」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[:quadrillion:][riri body=mizugi kao=2 ]
「肚子和屁股都＋1厘米」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[off_all]

[:princess:][puri_w body=mizugi kao=13 ]
「……………………」[rhp]

[off_all]

[chara_part name="jet" body=mizugi kao=3 as=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=mizugi kao=8 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:hutago:]
「………………」[rhr]
「………………」[rhp]

[off_all]

[:drop:][drop kao=2 as=on hat=sea ]
[font color=0x4682b4]
（这气氛该怎么化解……）[rhp]
[resetfont]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[chara_part name="riri" body=mizugi kao=5 as=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="puri_w" body=mizugi kao=2 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width="330" height="720" wait="true" zindex="1005" time=150]

[:quadrillion:]
「一看就知道啦～。腰围部分，布料完全没有余量了吧」[rhp]

[:princess:][puri_w body=mizugi kao=6 ]
「啰、啰嗦……！[rhr]
_　还不是因为你净做些高热量的东西！」[rhp]

[:quadrillion:][riri body=mizugi kao=13 ]
「无所谓啦。事到如今还说这些」[rhp]

[:princess:][puri_w body=mizugi kao=1 hh=on ]
「！　莉莉……」[rhp]

[:quadrillion:][riri body=mizugi kao=12 ]
「我不在意哦。不管是运动胸罩还是AA罩杯……」[rhp]

[:princess:][puri_w body=mizugi kao=6 ]
「人家至少有A罩杯！！」[rhp]

[:quadrillion:][riri body=mizugi kao=14 ]
「那件事不必再提了。当初只是逞强罢了」[rhp]
[:quadrillion:]
「我已决定不再顾虑他人，只做自己想做的事」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[off_all]

[chara_part name="riri" body=mizugi kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="168" top="0" wait="false" time=150]
[chara_part name="hakase" body=mizugi kao=4 as=off ss=off hh=on hr=on  msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720" left="600" top="0"wait="true"  time=150]

[:darknebula:][hakase body=mizugi kao=1 ]
「夸德里利昂，你……其实真正想做的是料理吧？」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:quadrillion:][riri body=mizugi kao=5 hh=on ]
「……一点点啦。倒也没有那么执着……」[rhp]

[off_all]

[::]
……其实早已心知肚明。[rhp]
为何不断逃避那个日渐虚弱的她的理央，[rhr]
始终无法放弃成为甜品师的梦想。[rhp]

[:quadrillion:]
[font color=0x4682b4]
（…………你吃着点心露出的笑容，倒也不算太难看呢）[rhp]
[resetfont]

[:princess:][puri_w body=mizugi kao=6 as=on ]
「？　干嘛盯着我看……」[rhp]

[:quadrillion:][riri body=mizugi kao=13 hh==on ]
「……很可爱哦♡　小猪崽」[rhp]

[:princess:][puri_w body=mizugi kao=2 ]
「哈！？」[rhp]

[:quadrillion:][riri body=mizugi kao=5 ]
「好——啦！水果冻已经完全掌握啦，接下来该挑战什么呢！」[rhp]
[:quadrillion:]
「公主，这次由你来决定吧」[rhp]

[:princess:][puri_w body=mizugi kao=13 hh=on ]
「呃～……那就……」[rhp]
[:princess:]
「………………饼干之类的」[rhp]

[:quadrillion:][riri body=mizugi kao=3 ]
「……！」[rhp]

[:princess:][puri_w body=mizugi kao=1 hh=on ]
「总觉得你很擅长的样子。饼干！」[rhp]

[:quadrillion:][riri body=mizugi kao=7 ]
「…………这样吗」[rhp]

[:princess:][puri_w body=mizugi kao=5 ]
「我可是她女朋友哦？关于莉莉的事全都了如指掌」[rhp]

[:quadrillion:][riri body=mizugi kao=2 as=on ]
「……啊哈哈！说什么呢，肉麻死啦」[rhp]

[:princess:][puri_w body=mizugi kao=8 ]
「是、是吗……」[rhp]

[:quadrillion:][riri body=mizugi kao=13 ]
「…………算了」[rhp]

[off_all]

[:quadrillion:][riri body=mizugi kao=5 hh=on ]
「那么小不点和多洛普还有杰特，都来乖乖当试吃员」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[chara_part name="jet" body=mizugi kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="peku" body=mizugi kao=1 as=off ss=off hh=on hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="355" top="0" wait="false" time=150]
[chara_part name="hati" body=mizugi kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="760" top="0" wait="true" time=150]

[:3nin:]
「太好啦！」[rhr]
「好耶！」[rhr]
「诶——！？」[rhp]

[off_all]

[chara_part name="drop" body=base kao=7 as=off ss=off hh=off hr=on hat=sea ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kite" body=mizugi kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:kite:][p_k_14]
「我……居然要为这种事死两次……」[rhp]

[:drop:][p_d_26][drop kao=13 hat=sea ]
「没、没问题的。公主也那么说了」[rhp]

[:kite:][kite body=mizugi kao=7 ]
「那家伙当然擅长啊。但就算这样[rhr]
_　也保不准会在我们的份里搞些屎一样的机关……至少别做太多啊」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[chara_part name="riri" body=mizugi kao=2 as=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="puri_w" body=mizugi kao=0 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width="330" height="720" wait="true" zindex="1005" time=150]

[:quadrillion:]
「这不是废话？要是我的女孩子变成母猪可怎么办」[rhp]

[:princess:][puri_w body=mizugi kao=6 as=on ]
「本来就不是猪啦……！」[rhp]

[off_all]

[::]
竟然是饼干，真笑不出来。[rhr]
这大概就是所谓的命运吧。[rhp]
或者说……孽缘？[rhp]

[:quadrillion:]
[font color=0x4682b4]
（……不过，比之前要好些）」[rhp]
[resetfont]

[::]
那一定是因为，有着确实的自信。[rhp]
就算这是与那个孩子记忆相连的线索，[rhr]
你也一定会选择我的吧。[rhp]

[:quadrillion:]
[font color=0x4682b4]
（……虽然我是因为有理央才存在的）[rhp]
[:quadrillion:]
（我是我。理央是理央）[rhp]
[resetfont]

;****************************************
#
[bg storage="sky_04.jpg" time=1000]
;****************************************

[::]
若理央是太阳，我就是月亮。[rhr]
唯有理央存在才会发光，若无理央便无人问津。[rhp]
不过那种事，已经怎样都无所谓了。[rhp]
影子也好什么也罢，此刻活着的我才是正义。[rhp]

不想过着违背他人的人生，而要选择遵从自己的人生活下去。[rhp]
不做任何人的替代，作为『夸德里利昂』而存在。[rhp]
总觉得，那样真的非常……[rhp]

[:quadrillion:]
「……令人热血沸腾呢！」[rhp]

[::]
阳光已经，不再可怕。[rhp]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

[jump storage="ev_d.ks" target="*ending"]

[off_all]

