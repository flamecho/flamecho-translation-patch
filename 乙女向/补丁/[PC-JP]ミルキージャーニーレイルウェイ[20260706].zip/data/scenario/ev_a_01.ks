﻿
*start
;--------------------------------------------------------------------------------------------

;ゲーム変数一括削除
[iscript]
delete f.ev_a_02;
delete f.ev_a_03;
delete f.ev_a_04;
delete f.ev_a_05;
delete f.ev_a_06;
delete f.ev_a_07;
[endscript]

;フラグ初期設定
[iscript]
f.love_d = 0
f.love_k = 0
f.love_r = 0
f.love_h = 0
f.ssmain = 0
f.ss_drop = 0
f.ss_kite = 0
f.ss_riri = 0
f.ss_hati = 0
f.ss_hkpk = 0
f.ss_otiai = 0
[endscript]

[cm]

[clearfix]
[start_keyconfig]
[loadjs storage="myscript.js]

;初期設定---------------------------------------------------------------------

; メッセージウィンドウの設定
[position layer="message0" frame="win.png" left=0 top=520 width=1280 height=200 page=fore visible=true]

; 文字表示領域
[position layer=message0 page=fore margint="65" marginl="420" marginr="60"]

; キャラ名表示領域
[ptext name="chara_name_area" layer="message0" color="0x000000" size=22 align=center bold=true x=420 y=550]

; 立ち絵の設定
[chara_config anim=false memory=true ptext="chara_name_area"]

[call storage="character.ks"]
[call storage="voice.ks"]

;--------------------------------------------------------------------------------------------
;▼フルボイスセット▼
;ドロップ
[voconfig sebuf=1 name=drop vostorage="drop/full/{number}.ogg" number=1]
;カイト
[voconfig sebuf=1 name=kite vostorage="kite/full/{number}.ogg" number=1]
;クォードリリオン
[voconfig sebuf=1 name=riri vostorage="riri/full/{number}.ogg" number=1]
;ハートシェイプ
[voconfig sebuf=1 name=hati vostorage="hati/full/{number}.ogg" number=2]
;ジェット
[voconfig sebuf=1 name=jet vostorage="jet/full/{number}.ogg" number=2]
;--------------------------------------------------------------------------------------------

;****************************************
;タイトル表示

[chara_hide_all layer="message0" time=150 wait=false]

[bgm storage="bgm_19.ogg"]
[bg storage="title/title_1a.png" time=100]

;簡易化タグ
;[jump  target="*buttobi"]

[s_mask_off time=2000]

[bg storage="title/title_1c.png" time=2000]

[s_wait time=5000]

[bg storage="title/title_1b.png" time=2000]
[s_wait time=500]
[bg storage="title/title_1d.png" time=2000]

[s_wait time=3000]

[s_mask color="0x000000 time=2000]

;簡易化タグ
; *buttobi

[bg storage="sky_07.jpg" time=100]
[layopt layer=message0 visible=true]
[showmenubutton]
[plugin name="menu_plugin"]

;簡易化タグ
;[jump target="*butobi2"]

[s_mask_off time=2000]
;****************************************

―――――就这样我沉入了梦乡。[rhp]

无比安详的、仿佛再也不会醒来的深沉睡眠。[rhp]
临到头却发现意外地普通。[rhp]
太好了。安心了。[rhp]
毫无牵挂。[rhp]

;****************************************
[bg storage="black.jpg" time=1500]
;****************************************

…………沉入了梦乡。[rhr]
这本该是确凿无疑的事。[rhp]

;****************************************
[bg storage="hikari.jpg" time=1500]
;****************************************

却在眼皮的彼端看见了光。[rhp]
若说是错觉，意识却逐渐清晰起来。[rhp]
如同浮上水面般的漂浮感。[rhp]

;****************************************
[bg_rule storage="white.jpg" rule="020.png" time=1500]
;****************************************

光源正逐渐靠近。[rhp]
从永恒的黑暗中。[rhp]
从无底的深渊里――――[rhp]

[fbgm]

;****************************************
[s_mask color=0xffffff time=2000]
; 背景表示
[bg storage="train_01.jpg" time=100]
; ウィンドゥの設定
[position layer="message0" frame="win.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[s_mask_off time=2000]
;****************************************

[::]
――――胸口的疼痛让我骤然睁眼。[rhp]
感觉自己做了个漫长而珍贵的梦。[rhp]
是因为那是梦吗？如今已然回忆不起。[rhp]
混沌的思绪中，唯独残留着莫名的失落感。[rhp]

[:princess:][puri_w kao=4 as=on ]
「…………咦」[rhp]

[off_puri ]

[::]
与其说是忘了梦境……[rhp]
话说回来……这里是哪儿？[rhp]

[:princess:][puri_w kao=3 as=on ]
[font color=0x4682b4]
（电车……？我难道是睡着了吗）[rhp]
[:princess:]
（而且周围空无一人，这到底是怎么回事……）[rhp]
[resetfont]
[:princess:]
「…………啊」[rhp]

[bgm storage="bgm_28.ogg"]

[::]
本只是想确认此处是何地，[rhr]
被从未设想过的外界所震撼。[rhp]

[:princess:][puri_w kao=2 as=on ]
「什……！！？这、这是浮在空中的……」[rhp]


[off_all]

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
[vostart]
;--------------------------------------------------------------------------------------------

[:drop:][drop kao=14 ]
「早上好！」[rhp]

[off_all]

[:princess:][puri_w kao=2 as=on ]
「！！」[rhp]

[off_all]

[::]
身后传来声音，我下意识转身。[rhp]
那里站着一名身穿制服般装束的男子。[rhp]
他不知为何，正用非常灿烂的笑容注视着我。[rhp]

[:drop:][drop ]
「怎么了公主。睡懒觉可不像您作风呢！[rhr]
_　因为担心才过来看看哦」[rhp]

[:princess:][puri_w kao=0 as=on ]
「公、公主……？」[rhp]

[off_all]

[::]
是说我是公主吗？[rhp]

[:drop:][drop kao=14 ]
「来来，整理下仪容。工作时间到了！」[rhp]

[off_all]

[::]
神秘青年向困惑的我递出手镜。[rhp]
不明就里地，我顺从地接过镜子。[rhp]
……无意间瞥见镜中模样，顿时惊骇万分。[rhp]

[:princess:][puri_w kao=2 as=on ]
「呜哇！？这这、这是啥！」[rhp]

[off_all]

[::]
镜中的我竟是个比想象中更华丽张扬的公主。[rhr]
甚至戴着王冠什么的。[rhp]
而最令人震惊的是……这张脸完全陌生。[rhp]

[:princess:][puri_w kao=2 as=on ]
[font color=0x4682b4]
（这是我？开玩笑吧？平常的我应该是更―――）[rhp]
[:princess:][puri_w kao=0 as=on ]
（………………？）[rhp]
[resetfont]

[off_all]

[::]
应该更……什么样？[rhp]

[:princess:][puri_w kao=2 as=on ]
[font color=0x4682b4]
（咦……？我……不仅是忘记这里是哪里，[rhr]
_　连自己都忘记了……？）[rhp]
[resetfont]

[:drop:][drop ]
「怎么了？啊，如果是化妆的话请别担心！[rhr]
_　来的路上我用魔法稍微弄了下……」[rhp]

[:princess:][puri_w kao=2 as=on ]
「啊、那个、那个、哥哥」[rhp]

[:drop:][drop kao=4 as=on ]
「诶」[rhp]
[:drop:]
「……哥哥是在叫我吗？」[rhp]

[:princess:][puri_w kao=3 as=on ]
「是、是的。抱歉。我不知道该怎么称呼您才好」[rhp]
[:princess:]
「那个……我、我好像完全失去了至今为止的记忆。[rhr]
_　如果以前认识的话实在对不起……」[rhp]

[:drop:][drop kao=2 as=on ]
「………………你说、失去了记忆」[rhp]

[:princess:][puri_w kao=8 as=on ]
「非、非常抱歉！我连自己的名字都忘记了」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:drop:][drop kao=3 as=on ]
「………………」[rhp]

[:princess:][puri_w kao=6 as=on ]
「…………啊、那个」[rhp]

[off_all]

[::]
他纹丝不动，保持着惊讶的表情僵在原地。[rhp]
怎么办……难道我说错什么了吗。[rhr]
不，但除此之外我也没别的解释方式了。[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:drop:]
「…………他究竟在想什么呢」[rhp]

[:princess:][puri_w kao=0 ]
「嗯？」[rhp]

[:drop:][drop kao=5 as=on ]
「！　啊、啊不是……对不起」[rhp]
[:drop:][drop kao=13 ]
「………………、多洛普」[rhp]

[:princess:]
「多洛普？」[rhp]

[:drop:]
「我的名字叫多洛普。[rhr]
_　是这辆银河铁道的列车长」[rhp]
[:drop:]
「初次见面，公主。欢迎来到银河铁道『千星十字』！」[rhp]

[:princess:][puri_w kao=4 as=on ]
「！　公主是说我的名字吗？」[rhp]

[:drop:][drop kao=14 ]
「没错！大家肯定都会这么称呼你的」[rhp]

[:princess:]
「大家……」[rhp]

[:drop:][drop kao=13 ]
「这是这辆列车上的同伴们。我会为你介绍，请跟我来」[rhp]

[off_all]

[::]
说完这句，自称多洛普的他便快步走了出去。[rhr]
慌忙追赶的我对着他的背影发问。[rhp]

[:princess:][puri_w kao=0 as=on ]
「那个！」[rhp]

[:drop:][drop ]
「嗯？」[rhp]

[:princess:][puri_w kao=6 as=on ]
「为什么你知道我的事？明明我们才初次见面」[rhp]

[off_all]

[::]
面对我的疑问，多洛普先生回以微笑。[rhp]

;****************************************
;スチル
[still storage="cg/a_01_1.png" rule="021.png" width="1280" height="720" time=1000]
[cg storage="cg/a_01_1.png"]
;****************************************

[:drop:]
「和你是初次见面没错哦」[rhp]
[:drop:]
「但你在来到这儿之前，早就是一公主殿下了」[rhp]

[:princess:]
「？？？　呃、那个……？」[rhp]

[:drop:]
「呵呵！详细情况等你想记忆起来自然就会明白。[rhr]
_　不必着急，那些记忆迟早会回来的」[rhp]

[:princess:]
「是这样吗……」[rhp]

[:drop:]
「敬语！这样不好」[rhp]

[:princess:]
「诶」[rhp]

[:drop:]
「能不能别这么拘谨？[rhr]
_　说到底我是列车长，而你从今天起就是乘客了」[rhp]

[:drop:]
「况且我们年龄也没差多少。[rhr]
_　用敬语反而会觉得有点不自在呢」[rhp]

[:princess:]
「………………随你便吧」[rhp]

[:drop:]
「非常感谢！嗯嗯，这样相处起来舒服多了」[rhp]

[:princess:]
[font color=0x4682b4]
（明明他自己还在用敬语啊……算了无所谓）[rhp]
[resetfont]

[off_all]

[::]
不过考虑到也有人习惯用敬语，我就不特意指出这点。[rhr]
……该怎么说呢，真是个不可思议的人啊。多洛普先生。[rhp]

[:princess:]
「名字也能直接称呼吗？」[rhp]

[:drop:]
「当然可以啦。大家都叫我多洛普哦」[rhp]

[:princess:]
「这样啊。那我也这么叫吧」[rhp]

[:drop:]
「当然，我很乐意！」[rhp]

;****************************************
[still_end frame="win.png" storage="train_01.jpg" time=1000]
;****************************************

[:drop:][drop kao=14 ]
「那么这次真的要带您参观车厢了！请跟我来！」[rhp]

[:princess:][puri_w kao=0 as=on ]
「啊，等等！等一下，……等、等等我啊！」[rhp]

[off_all]

[::]
正想去追赶强势的多洛普先生时，[rhr]
突然映入眼帘的车窗外那片广阔的银河，让思绪不经意间飘远了。[rhp]

;****************************************
[bg storage="sky_11.jpg" time=1000]
;****************************************

[:princess:]
[font color=0x4682b4]
（果然……怎么看都是宇宙啊……）[rhp]
[resetfont]

[::]
但与此相反的是，现在却能正常感受到重力行走。[rhr]
说到底列车能在空中行驶就很奇怪啊！[rhp]

[:princess:]
[font color=0x4682b4]
（嗯………[l]………是梦吗？）[rhp]
[resetfont]

[::]
原来如此。是梦啊！那就说得通了。[rhr]
之前也偶尔会在梦里意识到这是梦境呢。[rhp]

[:princess:]
「―――――……」[rhp]

[::]
…………似乎确实存在过的『之前』。[rhp]
明明感觉确实存在于我的记忆中。[rhr]
可现在那里却像空洞般，突兀地只剩下……[rhp]

;****************************************
[bg storage="train_01.jpg" time=1000]
;****************************************

[:drop:][drop kao=12 ]
「不可以哦，公主。您是不是在思考复杂的事情呢」[rhp]

[off_all]

[::]
突然被多洛普搭话，吓得肩膀猛地一颤。[rhp]

[:princess:][puri_w kao=13 as=on ]
「没……才、才没有呢」[rhp]

[:drop:][drop kao=11 ]
「您请看。窗外这片蔓延的景色」[rhp]

[off_all]

;****************************************
#
[bg storage="sky_11.jpg" time=500]
;****************************************

[:drop:]
「在这世上能俯瞰星辰的，唯有宇航员和我们了」[rhp]
[:drop:]
「在这么美妙的地方抱头苦恼，不觉得太可惜了吗？」[rhp]

[:princess:]
「……或许是如此」[rhp]

[:drop:]
「这份非日常用常理可讲不通。[rhr]
_　弄不明白的时候就先享受当下吧」[rhp]
[:drop:]
「毕竟这里可是魔法铁道啊！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

多洛普的话语中，不知为何带着奇妙的说服力。[rhp]
可以相信他。[rhr]
即便对这莫名其妙的状况一头雾水，只要跟着他就不会错吧。[rhp]
虽无根据，却莫名这么认为。[rhp]

我终于对他的话点了点头，[rhr]
决定让他带我参观这个奇异的空间――――[rhp]


;****************************************
[fbgm]
[set_00 storage="train_01.jpg"]
;****************************************

[bgm storage="bgm_01.ogg"]

[::]
最先被多洛普先生带到的[rhr]
是隔壁相连的另一节客车车厢。[rhp]
除了窗外景色外与普通电车并无二致，[rhr]
虽然看不出什么特别之处……[rhp]

[:drop:][p_d_09][drop kao=6 ]
「啊，在那边在那边！」[rhp]

[off_drop ]

[::]
扫视座位的多洛普先生虽这么说，[rhr]
这节车厢里却不见人影。[rhp]

[:princess:][puri_w kao=0 ]
「？看起来没人啊……」[rhp]

[:drop:][p_d_29][drop kao=6 ]
「那儿不是有辆贩卖手推车嘛」[rhp]

[off_all]

[::]
他说着指向通道正中央――那辆理直气壮挡着路的[rhr]
_　指着塞满点心屋商品等物的手推车。[rhp]

[:drop:][p_d_30][drop kao=8 ]
「是我们乘务员干的。[rhr]
_　既然那东西摆在那里，反正就在附近座位……」[rhp]

[off_drop ]

[::]
跟着走向手推车的多洛普先生，我也紧随其后。[rhp]

[:drop:][p_d_09][drop kao=2 as=on ]
「看吧，果然！」[rhp]

[off_drop ]

[::]
他视线所及之处，确实有人。[rhp]
……有人倒不要紧……[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:kite:][kite kao=12 ]
「……‥………呼」[rhp]

[::]
只见有人大剌剌地横躺在包厢座位，[rhr]
正发出安稳的鼾声。[rhp]

[:princess:][puri_w kao=6 as=on ]
「刚才说是乘务员？这人可是在睡觉啊」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:drop:][p_d_29][drop kao=6 ]
「是乘务员，不过是问题乘务员」[rhp]
[:drop:][p_d_09]
「快斗先生！请起床！[rhr]
_　说过多少遍在客车厢不能睡觉了」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:kite:][kite kao=12 ]
「……‥……，……嗯」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:drop:][p_d_17][drop kao=2 ]
「知道您因为前些天的野营太开心。[rhr]
_　熬夜情有可原，但影响到工作可不行！」[rhp]

[:princess:][puri_w kao=6 as=on ]
[font color=0x4682b4]
（咦？野营？）[rhp]
[resetfont]

[off_all]

[::]
乘务员之间会结伴旅行呢。[rhp]
看来两人关系很好。[rhr]
……虽从这两人氛围里不太能想象到。[rhp]

[chara_part name="drop" body=base kao=2 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:drop:][p_d_21]
「真～是的！快斗先生！请适可而止！[rhr]
_　要是您的工作态度暴露被扣薪水，我可不管哦！」[rhp]

[:kite:]
「………………」[rhp]

[:drop:][p_d_09][drop kao=8 as=on ]
「快斗先～生！」[rhp]

[:princess:][puri_w kao=5 as=on ]
[font color=0x4682b4]
（完全叫不醒这个人啊……）[rhp]
[resetfont]

[off_all]

[:drop:][p_d_34][drop kao=3 as=on ]
「抱歉，公主。[rhr]
_　如您所见，快斗先生一旦闭上眼睛就很难醒过来」[rhp]

[:princess:][puri_w ]
「真是个随性的人呢。我并不介意」[rhp]

[fbgm]
[off_all]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:kite:]
「在模仿什么？」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:princess:][puri_w kao=2 as=on ]
「噫！！」[rhp]

[off_all]

[::]
背后突然传来声音，吓得我跳了起来。[rhp]
回头看去，方才还在沉睡的快斗先生撑起上半身，[rhr]
直勾勾地盯着这边。......有点可怕。[rhp]

[bgm storage="bgm_29.ogg"]

[chara_part name="drop" body=base kao=6 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=11 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:drop:][p_d_05]
「快斗先生。早......上......好」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:kite:]
「早」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:drop:][p_d_09][drop kao=2 ]
「一点都不好！早上好！」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:kite:][kite ]
「……………………」[rhp]

[::]
无视多洛普刺刺不休的攻击，[rhr]
_　快斗先生依然死死凝视着这边。[rhp]
…………总觉得很可怕。[rhr]
面无表情的样子，感觉很难接近……[rhp]

[:princess:][puri_w kao=6 as=on ]
「有、有什么事吗？」[rhp]

[:kite:][kite kao=6 ]
「………………公主？」[rhp]

[:princess:][puri_w kao=0 ]
「……？是、是的」[rhp]

[:kite:]
「……………………感觉气质不太一样」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[off_all]

[chara_part name="drop" body=base kao=3 as=on ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:drop:]
「那个……她好像失去记忆了。[rhr]
_　昨天确实登上列车是事实」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:kite:][kite kao=2 as=on ]
「……！记忆？为什么」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:drop:][p_d_05][drop kao=3 as=on ]
「原因尚不清楚。[rhr]
_　但是，连自己的名字都不记得了」[rhp]
[:drop:]
「这样下去会很不方便，所以正在带您参观车厢内部」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:kite:][kite kao=2 ]
「…………这样啊……」[rhp]
[:kite:][kite kao=3 ]
「………………想不起来了」[rhp]

[off_all]

[:princess:][puri_w ]
「那个，快斗先生……对吧？请多指教」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:kite:][kite kao=3 ]
「……………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:princess:][puri_w kao=6 as=on ]
「……那个」[rhp]

[:kite:][kite kao=11 ]
「噗」[rhp]

[:princess:][puri_w kao=2 ]
「嗯？」[rhp]

[:kite:][kite kao=5 ]
「‘那个～’」[rhp]

[:princess:][puri_w kao=6 as=on ]
「…………该不会是在学我吧？」[rhp]

[:kite:]
「‘该不会是在学我吧～’？」[rhp]

[:princess:][puri_w kao=2 as=on ]
「喂！别这样！」[rhp]

[:kite:][kite kao=3 ]
「………………哈，无聊」[rhp]

[:princess:][puri_w kao=8 as=on ]
[font color=0x4682b4]
（擅、擅自搞这出算什么……！？）[rhp]
[resetfont]

[:kite:][kite kao=6 ]
「"公主"吗……才没有啦～」[rhp]

[:princess:][puri_w kao=2 ]
「我也不喜欢自称什么公主啊！」[rhp]

[:kite:][kite kao=7 ]
「名不副实真是抱歉喽～」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[off_all]

[chara_part name="drop" body=base kao=6 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" wait="true" left="645" top="0" time=150]

[:drop:][p_d_09]
「真是的，快斗先生到底在挑什么刺！[rhr]
_　请停止。我们好好相处吧！」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:kite:]
「对不起嘛～」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------


[:drop:][p_d_05][drop kao=8 as=on ]
「～～～～！……真是的，太随便了」[rhp]
[:drop:][drop kao=1 as=on ]
「总之就是这么回事。失忆的公主小姐会作为乘客[rhr]
_　与我们同行一段时间」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:kite:][kite kao=7 ]
「嗯。挺好的吧。反正也只能这样了」[rhp]
[:kite:]
「……话说，是‘乘客’吗？」[rhp]

[:princess:][puri_w kao=6 ]
「什、什么嘛……」[rhp]

[:kite:][kite kao=11 ]
「没什么啦。就是羡慕你闲着没工作啦——」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:drop:][p_d_15][drop kao=5 ]
「请多小心啊快斗先生。[rhr]
_　偷懒太多的话，可能会被取代职务哦」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:kite:][kite kao=11 ]
「热烈欢迎呀——」[rhp]
[:kite:][kite kao=2 ]
「…………！　啊、不过果然还是不行」[rhp]

[:princess:][puri_w kao=2 ]
「为啥」[rhp]

[:kite:][kite kao=6 ]
「这家伙感觉只会卖过期食品给我……」[rhp]

[:princess:][puri_w kao=6 as=on ]
[font size=25"]
「才不会做那种事呢！」[rhp]
[resetfont]

[:kite:][kite kao=5 ]
「不不，混这行多年的我光看脸就能明白」[rhp]
[:kite:]
「你长着张过期食品的脸」[rhp]

[:princess:]
「这根本是别的意思了啊！」[rhp]

[:kite:][kite kao=11 ]
「别吠别吠。让我想起老家养的哈巴狗」[rhp]

[:princess:]
「哈……哈啊！？　谁的脸皱巴巴的啊！？」[rhp]

[off_all]

[::]
接二连三的冒犯发言，让人惊得合不拢嘴。[rhr]
初次见面好歹该有点基本礼貌吧！？[rhp]

[:kite:][kite kao=5 ]
「…………嘛，不过啊」[rhp]

[:princess:][puri_w kao=2 as=on ]
「！」[rhp]

[:kite:]
「有不懂的事尽管问我。好歹也算你前辈」[rhp]

[:princess:][puri_w kao=6 as=on ]
「嗯、嗯……」[rhp]
[:princess:]
[font color=0x4682b4]
（就是啊。要是刚开始就这态度我也不会抱怨……）[rhp]
[resetfont]

[off_all]

[chara_part name="drop" body=base kao=0 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=11 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" wait="true" left="645" top="0" time=150]

[:kite:]
「拜托你了，多洛普前辈」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:drop:][p_d_02][drop kao=5 as=on ]
「哎？啊、好的！乐意效劳！」[rhp]

[:princess:][puri_w kao=6 as=on ]
「原来不是在说你啊……」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:kite:][kite kao=11 ]
「我才不要。困死了」[rhp]

[off_all]

[kite kao=11 ]
「那，晚安～」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:drop:][p_d_09][drop kao=2 as]
「快斗先生！　您不是刚起床吗！？　手推车检查了吗！？」[rhp]

;------------------------------------------------------------------------------------------
;▼再開※リピート▼
[voconfig sebuf=1 name=kite vostorage="kite/full/{number}.ogg" number=1]
[vostart]
;------------------------------------------------------------------------------------------
[:kite:]
「………………呼」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:drop:][p_d_21]
「等等！快斗先生！！？快醒醒啦～～！」[rhp]

[off_all]

[::]
这就是要介绍的第一位员工吗……[rhr]
这辆电车真的没问题吗。[rhp]
之后快斗又睡了过去,[rhr]
我们只好无奈地离开了这节车厢……[rhp]

;****************************************
[fbgm]

[set_00 storage="train_03.jpg"]
;****************************************

[bgm storage="bgm_22.ogg"]

[::]
我们前往第三节车厢。[rhr]
这里整个车厢就像餐厅一样，氛围与之前截然不同。[rhp]

[:drop:][p_d_15][drop ]
「这里是餐车。大家讨论事情[rhr]
_　或是用餐时都会使用这里。厨房也可以随意使用！」[rhp]

[:princess:][puri_w ]
「乘务员们也一起用餐呢。[rhr]
_　反正看起来也没有乘客，他们大概不在意吧」[rhp]

[:drop:][p_d_32][drop ]
「哈哈……以前可是有很多乘客的。[rhr]
_　现在全都下车了，算上您只剩三个人」[rhp]

[:princess:][puri_w ]
[font color=0x4682b4]
（诶……即便如此还是有其他人在啊）[rhp]
[resetfont]

[::]
前面几节车厢都没见到，或许是在其他地方？[rhp]

[:drop:][p_d_16][drop ]
「要来点吃的吗？难得来餐车一趟[rhr]
_　不过只能做些简单料理」[rhp]

[:princess:][puri_w kao=7 ]
「多洛普下厨吗？明明是个车长还兼任厨师呢」[rhp]

[:drop:][p_d_04][drop ]
「不，我们家是轮流做饭的。[rhr]
_　不只是我，也能吃到别人做的菜哦」[rhp]

[:princess:][puri_w kao=0 ]
「那可真是辛苦呢。不雇个专属主厨什么的吗」[rhp]

[:drop:][p_d_25][drop kao=6 as=on ]
「啊——……有是有啦……但、那个人讨厌做饭」[rhp]

[:princess:][puri_w kao=2 as=on ]
「不是主厨吗？」[rhp]

[:drop:][p_d_17][drop kao=3 ]
「快斗先生每天会推几下车厢什么的当工作。[rhr]
_　主厨那位已经不属于那种层面了」[rhp]
[:drop:]
「我上次说『既然是工作至少拿个菜刀吧』。[rhr]
_　结果呢？他边喊着『开什么玩笑！！』边……」[rhp]
[:drop:]
「把菜刀摔断了」[rhp]

[:princess:][puri_w kao=2 as=on ss=on ]
「把菜刀……摔断……」[rhp]

[:drop:][p_d_02][drop kao=13 ]
「俗话说百闻不如一见。先打个招呼吧」[rhp]

[:princess:][puri_w kao=8 as=on ss=on ]
「诶！？在、在吗？就在这里？」[rhp]

[:drop:][p_d_01][drop ]
「当然在啊。毕竟是主厨嘛」[rhp]

[off_all]

[:drop:]
「那么有请登场！食堂才是我的乐园，[rhr]
_　银河铁道「千星十字」专属主厨，夸德里利昂在此，请多指教！」[rhp]

[:princess:]
「稍稍稍等一下！这么突然太勉强了！！[rhr]
_　要是冒犯了会被折断脖子之类的…………」[rhp]

[fbgm]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:quadrillion:][riri kao=6 ]
「都说不会啦」[rhp]

[off_riri]

[yurasu]

[:princess:][puri_w kao=2 as=on ss=on ]
[font size=28]
「呀――――！！」[rhp]
[resetfont]

[off_all]

[bgm storage="bgm_30.ogg"]


[::]
背后传来低沉的男声，吓得我惊跳起来。[rhr]
回头一看，站在那里的是……[rhp]

[chara_part name="riri" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=2 as=on ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
[font size=27 color=0x4682b4]
（好大！！！！）[rhp]
[resetfont]

[off_all]

[::]
眼前站着个粉红色肌肉男。[rhp]

[chara_part name="drop" body=base kao=1 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="riri" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" wait="true" left="645" top="0" time=150]

[:quadrillion:]
「喂多洛普，刚才那段漂亮的台词算什么？[rhr]
_　你不是举起胳膊了吗」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:drop:][p_d_31][drop kao=14 hh=on ]
「嘿嘿嘿。多谢夸奖」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:quadrillion:][riri kao=14 ]
「别这样啦～～。[rhr]
_　差点就要不小心唱起往年的流行歌了」[rhp]

[off_all]

[:princess:][puri_w kao=2 as=on ]
[font color=0x4682b4]
（糟糕了……！这种情况菜刀都会咔嚓折断……[rhr]
_　根本不需要武器……他是徒手格斗型啊……）[rhp]
[resetfont]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:quadrillion:][riri kao=0 ]
「…………」[rhp]

[off_all]

;ぷにっ

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:quadrillion:]
「…………唉」[rhp]

[se storage="se7_31.ogg"]

[:princess:]
「呜哎！？」[rhp]

[::]
当我直勾勾盯着夸德里利昂先生的脸时，[rhr]
他突然伸手轻轻捏了我的脸颊。[rhp]

[chara_part name="riri" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=2 as=on ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:quadrillion:]
「怎么啦～，一副没精打采的样子。是不是没精神？[rhr]
_　上次露营的疲劳还没消除吧？」[rhp]
[:quadrillion:]
「谁让你陪着双胞胎闹过头了呢。真拿你没办法」[rhp]

[:princess:]
「呜、呜咕？」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:drop:][p_d_25][drop kao=3 as=on ]
「啊……那个，夸德里利昂。[rhr]
_　其实她情况有点特殊……」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:quadrillion:][riri kao=0 ]
「……情况？」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[off_all]

[::]
看到我头顶冒出问号，多洛普先生从旁边帮忙解围。[rhr]
夸德里利昂先生似乎没领会话中含义，露出困惑的表情。[rhp]


[:drop:][p_d_17][drop kao=6 as=on ]
「…………、好像失去了昨天的记忆。[rhr]
_　在这里的她，不知道前几天的露营」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:quadrillion:][riri kao=4 ]
「……诶……」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[off_all]

[::]
惊讶到僵住的夸德里利昂小姐。[rhr]
掐着脸颊的指尖，微微加重了力道。[rhp]
与方才轻浮的态度截然不同，眼神变得认真起来。[rhp]

[:quadrillion:][riri kao=2 ]
「……………………」[rhp]

[:princess:][puri_w kao=0 as=on ]
「那、那个……」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:quadrillion:][riri kao=6 ss=on ]
「…………啧！」[rhp]

[off_all]

[yurasu]
;つねる（強）
[se storage="hand_01.ogg"]

[:princess:]
「好痛痛痛痛痛痛痛痛痛！！！！！！」[rhp]

[::]
沉默着的夸德里利昂小姐，突然在指尖灌注了全力。[rhp]
我不由得甩开他的手，躲到了多洛普先生背后。[rhr]
脸颊火辣辣地疼得难以置信……！[rhp]

[:quadrillion:][riri kao=2 ]
[font size=27]
「这个布兹！！竟敢骗我！！」[rhp]
[resetfont]

[:princess:][puri_w kao=2 as=on ]
「哈……哈啊！？」[rhp]

[:quadrillion:][riri kao=6 as=on ]
「明明上车后……！以为你还记得我，[rhr]
_　才用这种态度对你好的……！」[rhp]

[:princess:]
[font color=0x4682b4]
（上车后？）[rhp]
[resetfont]

[off_all]

[::]
…………在说什么呢？[rhp]

[:quadrillion:][riri kao=2 as=on ]
「你这种人，你这种人……！！」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
#
;扉閉める（強）
[se storage="mag_03.ogg"]
;結合部
[bg storage="train_04.jpg" method="fadeInRightBig" time=500]
;****************************************

[:princess:][puri_w kao=2 as=on ]
「咦！？什么时候！？」[rhp]

[:drop:][p_d_32][drop kao=5 as=on ]
「被用魔法赶出来了呢……」[rhp]
[:drop:][drop kao=13 ]
「啊、顺带一提这条走廊是配备包间的特等车厢。[rhr]
_　和刚才通过的客车隔着餐车在相反侧，应该能继续前进了」[rhp]
[:drop:][drop kao=1 as=on ]
「真是万幸。看那情况短时间内[rhr]
_　餐车似乎无法通过」[rhp]

[:princess:][puri_w kao=6 as=on ]
「为什么突然生气了呢。是我失礼了吗？」[rhp]

[:drop:][p_d_17][drop ]
「…………可能是因为被曾经亲密的你彻底遗忘，[rhr]
_　在迁怒吧。……大概」[rhp]

[off_all]

[::]
与冷静发言的多洛普先生形成鲜明对比，[rhr]
门对面的夸德里利昂小姐蛮不讲理的怒火仍未平息。[rhp]

[yurasu]
;扉を叩く
[se storage="se7_28.ogg"]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:quadrillion:][font size=25]
『那边的烂人布兹！！[rhr]
_　不准再随便和我搭话！！』[rhp]
[resetfont]

[:princess:][puri_w kao=2 as=on ]
「布、布兹什么的！[rhr]
_　没必要说得这么过分吧！」[rhp]

[off_puri ]

[:quadrillion:][font size=25]
『滚·开！滚·开！』[rhp]
[resetfont]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:princess:][puri_w kao=8 as=on ]
「可、可恶～……！之前明明那么温柔的！」[rhp]

[:drop:][p_d_32][drop ]
「公主。差不多该走了。[rhr]
_　夸德里利昂一旦发怒短时间内不会平息的」[rhp]
[:drop:][drop kao=13 ]
「来，接下来去特等室。重整心情出发吧」[rhp]

[:princess:][puri_w kao=6 as=on ]
「完、完全不能接受………」[rhp]

[off_all]

[::]
…………确实，被遗忘是件失礼的事。[rhr]
但也不至于气成那样吧。[rhp]
我自己也完全不明白为什么会变成这样……[rhp]

;****************************************
[set_b storage="train_03.jpg" time=500]
;****************************************

[:quadrillion:][p_r_09][riri kao=2 ]
「呜――――啊！气死了气死了气死啦！[rhr]
_　明明是公主却不算公主！？这算什么嘛！」[rhp]
[:quadrillion:]
「把我百万克拉的微笑还给我！[rhr]
_　布兹！　丑八怪！　塑料货！」[rhp]

[:kite:][p_k_04][kite kao=6 ]
「塑料不关这事吧」[rhp]

[:quadrillion:][p_r_25][riri kao=2 ]
「吵死了！无关的人别插嘴……」[rhp]
[:quadrillion:][riri kao=4 ]
「……话说」[rhp]

[:kite:][p_k_35][kite kao=12 ]
「哎呀哎呀」[rhp]

[:quadrillion:][p_r_14][riri kao=0 ]
「……哎呀糟糕。你这种时候醒着还真罕见呢」[rhp]

[:kite:][p_k_02][kite kao=6 ]
「被吵醒的啊。被那个歇斯底里的人妖」[rhp]

[:quadrillion:][p_r_09][riri kao=2 ]
「给老娘闭嘴。老娘可是深爱着歇斯底里的乳房几十年的主」[rhp]

[:kite:][p_k_10]
「说什么呢？」[rhp]

[:quadrillion:][p_r_04][riri kao=3 ]
「我说，比起这个你见过没？就是那个……布兹呀」[rhp]

[:kite:][p_k_02][kite kao=2 ]
「布兹？」[rhp]

[:quadrillion:][riri kao=6 ]
「是公主啦」[rhp]

[:kite:][p_k_17][kite kao=7 ]
「啊——」[rhp]
[:kite:]
「………………脸和以前不是完全一样嘛」[rhp]

[:quadrillion:][p_r_14][riri kao=6 ]
「哎呀，护着她呢。不过呐，重要的内涵可不一样了吧」[rhp]
[:quadrillion:]
「……听说那孩子全部都不记得了」[rhp]

[:kite:][p_k_05][kite kao=7 ]
「……………………」[rhp]

[:quadrillion:][p_r_12][riri kao=3 ]
「无法接受。这太奇怪了。[rhr]
_　之前的『乘车』从没发生过这种事」[rhp]

[:kite:][p_k_02][kite ]
「去问南吧。也许知道些什么」[rhp]

[:quadrillion:][riri kao=6 ]
「那确实最省事……但他很少来这儿不是么。[rhr]
_　就算偶尔来了，办完事也立刻回去」[rhp]

[:kite:][p_k_02][kite kao=7 ]
「搞不懂啊。唯独这次。[rhr]
_　我甚至怀疑是不是南动了什么手脚」[rhp]
[:kite:]
「因为，那家伙当时在生气嘛」[rhp]

[:quadrillion:][riri kao=0 ]
「…………对什么？」[rhp]

[:kite:][kite kao=6 ]
「对公主」[rhp]

[:quadrillion:][p_r_10][riri kao=2 ]
「哈？为什么………，……啊，想了也是白费」[rhp]
[:quadrillion:]
「暂时先观望吧。[rhr]
_　看来我们的话也受到内容限制了」[rhp]

[:kite:][p_k_05][kite kao=6 ]
「靠我们的嘴是没法说出公主过往经历的……[rhr]
_　就算说了也毫无意义吧」[rhp]
[:kite:]
「…………南那混蛋在打什么主意？」[rhp]

;****************************************
[fbgm]
[set_b storage="train_04.jpg"]
;****************************************

[bgm storage="bgm_01.ogg"]

[:princess:][puri_w kao=6 ]
「啊啊。都怪那个人害我们饭都没吃成」[rhp]

[:drop:][p_d_34][drop ]
「没关系的。我们本来就不会觉得饿」[rhp]

[:princess:][puri_w kao=0 ]
「诶，真的吗？」[rhp]

[:drop:][p_d_02][drop ]
「是的。在这个世界里不吃东西也没关系」[rhp]
[:drop:]
「吃饭嘛，算是种消遣吧。[rhr]
_　姑且当作划分一天的象征而已」[rhp]

[:princess:][puri_w ]
「说起来确实。晚饭时间到了也没觉得饿……」[rhp]
[:princess:][puri_w kao=0 ]
「……？现在真的是晚饭时间吗？[rhr]
_　看外面黑着就自然这么想了」[rhp]

[:drop:][p_d_31][drop kao=13 ]
「这个世界随时都是晚餐时间哦。[rhr]
_　因为是宇宙所以永远都是夜晚」[rhp]

[:princess:][puri_w kao=11 as=on ]
「这种随便的设定，看来只能习惯了……」[rhp]

[:drop:][drop kao=14 ]
「不愧是公主。这份适应力太出色了！」[rhp]
[:drop:][drop kao=7 ]
「…………啊」[rhp]

[:princess:][puri_w kao=0 ]
「怎么了？」[rhp]

[:drop:][p_d_04][drop ]
「这么说来还没介绍他们。[rhr]
_　差不多该可以了吧」[rhp]

[:princess:][puri_w kao=6 as=on ]
「从刚才起就完全听不懂你们在说什么……」[rhp]

[:drop:][p_d_31][drop ]
「请看看后面」[rhp]

[off_all]

[fbgm]

[::]
被多洛普这么一说，便漫不经心地回过头去。[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[chara_part name="jet" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" left="50" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" left="420" top="0" wait="true" time=150]

[:hutago:]
[s_playse storage="hati/full/1.ogg" buf=1] 
[s_playse storage="jet/full/1.ogg" buf=2]
「哟！」[rhr]
「呀」[rhp]

[off_all]

[:princess:][puri_w kao=2 as=on ]
「哇！谁、是谁！？」[rhp]

[bgm storage="bgm_31.ogg"]

[chara_part name="drop" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="jet" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="760" top="0" wait="true" time=150]

[:heartshape:][hati kao=6 ]
「喂喂多洛普！别说出来啊。[rhr]
_　差一点本哈蒂大人就能帅气地吓唬人了！」[rhp]

[:jet:][jet kao=2 ]
「就是啊多洛普。同上」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:drop:][p_d_32][drop kao=13 as=on ]
「抱歉。我在想你们究竟要跟到什么时候」[rhp]

[:princess:][puri_w ]
「跟着？难道说一直尾随在后面？」[rhp]

[:drop:][p_d_23][drop ]
「虽然不是最开始，但从餐车开始就一路跟着了」[rhp]

[chara_part name="jet" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]

[:hutago:]
[s_playse storage="hati/full/3.ogg" buf=1] 
[s_playse storage="jet/full/3.ogg" buf=2]
「啥！」[rhr]
「啊」[rhp]

[:princess:][puri_w ]
「完、完全没注意到……！　」[rhp]
;--------------------------------------------------------------------------------------------
;▼再開▼
;ハートシェイプ
[voconfig sebuf=1 name=hati vostorage="hati/full/{number}.ogg" number=4]
;ジェット
[voconfig sebuf=1 name=jet vostorage="jet/full/{number}.ogg" number=4]
[vostart]
;--------------------------------------------------------------------------------------------

[off_all]

[chara_part name="jet" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:][hati kao=2 ]
「听说你的事了公主！[rhr]
_　你失忆了是吧……！？」[rhp]
[:heartshape:]
[font size=26]
「提问！我是谁！？」[rhp]
[resetfont]

[:princess:][puri_w kao=2 as=on ]
「那个……哈蒂大人？」[rhp]

[:heartshape:][hati kao=4 as=on ]
「！！这不是记得嘛！而且还带点敬意！」[rhp]
[:heartshape:]
「失忆是假消息吗！？」[rhp]

[:jet:][jet kao=6 as=on ]
「刚刚不是你自己报过名号了吗」[rhp]

[:princess:]
[font color=0x4682b4]
（这个人不要紧吧……）[rhp]
[resetfont]

[:jet:][jet kao=12 ]
「不过公主，你真是遭遇不幸了呢」[rhp]
[:jet:]
「虽然不知道发生了什么，[rhr]
_　但迟早会想起来的。别太在意」[rhp]

[:princess:][puri_w kao=13 as=on ]
「嗯、嗯。谢谢……？」[rhp]
[:princess:][puri_w kao=13 as=on ]
「话说回来，你们俩长得真像啊。是双胞胎吗？」[rhp]

[:heartshape:][hati kao=5 ]
[font size=28]
「这是商业机密！」[rhp]

[:princess:][puri_w kao=6 as=on ]
「嗯？」[rhp]

[:heartshape:][resetfont]
「我和杰特是同心一体！两人合一的二人三脚！[rhr]
_　用双胞胎这种轻飘飘的词来形容我可不能接受……！」[rhp]
[:heartshape:][font size=25]
「对吧杰特！？」[rhp]
[resetfont]

[:jet:][jet kao=11 ]
「毫无疑问」[rhp]

[:princess:]
[font color=0x4682b4]
（虽然不太明白，但真是有趣的人啊！）[rhp]
[resetfont]

[off_all]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[chara_part name="drop" body=base kao=6 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="424" top="0" wait="false" time=150]
[chara_part name="jet" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="760" top="0" wait="true" time=150]

[:drop:][p_d_09][drop kao=6 ]
「既然已经介绍完你们了，我们该继续前进了。[rhr]
_　二位也别光顾着胡闹，记得完成工作」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:heartshape:][hati kao=2 ]
「诶——！？这就走了？」[rhp]

[:jet:][jet kao=6 ]
「真冷淡啊。明明和克林聊得更久吧」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:drop:][p_d_22][drop ]
「不过确实该出发了。想去特等车厢打个招呼」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:jet:][jet ]
「咦……去博士那里？」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:drop:][p_d_02][drop ]
「是的。他可能知道她失忆的原因」[rhp]

[:princess:][puri_w kao=0 ]
「是这样吗？」[rhp]

[:drop:][p_d_01][drop kao=13 ]
「没错！达克内布拉博士是无所不知的著名哲学家哦」[rhp]

[:princess:][puri_w ]
「哲学家啊！看来能得到不错的答案呢」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:jet:][jet kao=5 ]
「难说呢。搞不好对方根本不愿搭理」[rhp]
[:jet:]
「毕竟博士是发明家。[rhr]
_　听说今早浮现了个超棒的点子」[rhp]

[:heartshape:][hati kao=5 ]
「而且博士可是科学家啊！[rhr]
_　他说最近忙着写论文呢！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:drop:][p_d_30][drop kao=3 ]
「这样啊……还以为心理学家会更了解她的症状」[rhp]

[:princess:][puri_w kao=2 as=on ]
「…………哲学家呢？」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:heartshape:][hati kao=14 ]
「嘛，也确实算是哲学家吧？」[rhp]

[:jet:][jet kao=11 ]
「毋庸置疑」[rhp]

[:princess:][puri_w kao=6 as=on ]
[font color=0x4682b4]
（总觉得不该太深究这个话题……）[rhp]
[resetfont]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[off_all]

[:drop:][p_d_04][drop ]
「不能打扰博士的研究，[rhr]
_　请教建议还是另找机会吧」[rhp]
[:drop:]
「他和他的助手两人与公主同样属于乘客。[rhr]
_　虽然都有些怪癖，但我觉得能成为好朋友哦」[rhp]

[:princess:][puri_w kao=13 ]
「这样啊。有点期待呢」[rhp]
[:princess:][puri_w kao=14 ]
「哈托谢普君和杰特君也是，[rhr]
_　今后请多关照」[rhp]

[off_drop ]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[chara_part name="jet" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:]
「叫哈蒂就行，公主！」[rhp]

[:jet:]
「失忆后变得文静了吧？」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[chara_part name="jet" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:hutago:]

[s_playse storage="hati/full/15.ogg" buf=1]
[s_playse storage="jet/full/14.ogg" buf=2]

「今后也要痛快玩个够啊！」[rhr]
「今后也要痛快玩个够」[rhp]

[:princess:][puri_w kao=14 hh=on ]
「呵呵……！嗯！请多指教！[rhr]
_　哈蒂君、杰特君！」[rhp]

[off_all]

[:drop:][p_d_02][drop kao=6 ]
「游玩可以，但请别忘了工作！[rhr]
_　今天务必打扫客舱――――」[rhp]

[off_drop ]

;------------------------------------------------------------------------------------------
;▼再開▼
;ハートシェイプ
[voconfig sebuf=1 name=hati vostorage="hati/full/{number}.ogg" number=16]
;ジェット
[voconfig sebuf=1 name=jet vostorage="jet/full/{number}.ogg" number=15]
[vostart]
;------------------------------------------------------------------------------------------

[se storage="door_07.ogg"]

[:heartshape:]
[font size=28]
「叮铃铃～～～～！要去Gaybar吗喂！？」[rhp]

[resetfont]

[:jet:]
「还是那么冷清啊！打扰啦～」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[fbgm]

[:princess:][puri_w kao=13 as=on ]
「啊哈哈。被逃掉了呢」[rhp]

[:drop:][p_d_09][drop kao=3 as=on ]
「真是的～～～……！每次都这样。[rhr]
_　作为同行车长真让人难为情」[rhp]

[bgm storage="bgm_01.ogg"]

[:princess:][puri_w ]
「不过，总觉得那两人很开心呢。又开朗又有趣！[rhr]
_　感觉终于遇到能成为真正朋友的人了」[rhp]

[:drop:][p_d_31][drop kao=14 hh=on ]
「嗯。撇开爱偷懒的毛病不谈，我也非常喜欢那样的他们」[rhp]

[:princess:][puri_w kao=13 ]
[font color=0x4682b4]
（多洛普高兴得像自己的事一样。[rhr]
_　似乎也很受其他人爱戴，是个重视伙伴的人呢）[rhp]
[resetfont]

[:drop:][p_d_07][drop ]
「好了，这下伙伴们的介绍就全部结束了」[rhp]
[:drop:]
「快斗先生、夸德里利昂、杰特先生、哈托谢普、[rhr]
_　还有尚未介绍的达克内布拉博士及其助手沃尔佩克拉女士」[rhp]
[:drop:]
「再加上我和公主。总共8人的旅行」[rhp]

[:princess:][puri_w kao=7 ]
「一直说旅行，可这条铁道有目的地吗？」[rhp]

[:drop:][p_d_25][drop ]
「没有。我们只是按顺序去往各自想去的地方。[rhr]
_　想去看海就去度假胜地行星，想露营就去群山行星这样」[rhp]

[:princess:][puri_w kao=4 as=on ]
「居、居然是行星级别的！？」[rhp]

[:drop:][p_d_01][drop kao=13 ]
「没错！用魔法就能轻松创造出来」[rhp]

[:princess:][puri_w kao=13 as=on ]
「魔法还真是为所欲为啊……不过话说回来，[rhr]
_　明明是电车却能在天空飞翔，没有轨道这点到现在才吐槽吗」[rhp]

[:drop:][drop kao=14 ]
「硬要说的话，我们的轨道就是外界的群星。[rhr]
_　因为这是横渡天河的电车，正是银河铁道「千星十字」啊！」[rhp]

[:princess:][puri_w kao=4 ]
「银河铁道……」[rhp]

[:drop:][p_d_04][drop kao=5 ]
「下次也请告诉我公主想去的地方吧。[rhr]
_　暂时已有许多乘客的目的地需要优先安排」[rhp]
[:drop:][drop kao=13 ]
「你的梦想也一定会实现的」[rhp]

[:princess:][puri_w kao=4 as=on ]
「…………！」[rhp]

[off_puri]

[:drop:][p_d_31]
「那么我带您去卧铺车厢吧。[rhr]
_　我们每人都准备了独立房间……」[rhp]

[off_drop]

[:princess:][puri_w kao=0 ]
[font color=0x4682b4]
（……梦想，会实现……）[rhp]
[resetfont]

[off_all]

[::]
与其说是梦想，不如说是想去的地方。[rhp]
想去的地方……，………………。[rhp]

[:princess:]
[font color=0x4682b4]
（……慢慢来就好）[rhp]
[resetfont]

[::]
反正似乎还有很多时间。[rhr]
要是能在抵达前稍微想起些关于自己的事就好了。[rhp]
至少能想到想去的地方、想看的事物这种程度。[rhp]

;****************************************

;寝台車廊下
[set_00 storage="train_04.jpg"]
;****************************************

[::]
告别那两人后，我重新听取了卧铺车厢的说明。[rhp]
这里排列着所有人的独立房间，[rhr]
每扇门上都挂着乘客的姓名牌。[rhp]
至于为什么员工也……这种事还是别深究为妙。[rhp]

[:drop:]
「你的房间在这里」[rhp]

;****************************************
#
;扉開ける
[se storage="door_07.ogg"]
;寝台車個室
[bg storage="train_08.jpg" time=200]
;****************************************

[:princess:][puri_w kao=5 hh=on ]
「哇，好漂亮的房间！」[rhp]

[:drop:][drop kao=13 ]
「对吧？可比那些普通旅馆强多了！」[rhp]
[:drop:][p_d_31][drop kao=13 ]
「好了！那么，我要回去工作了。[rhr]
_　第一次经历这么多事应该累了吧，今天请在房间里好好休息」[rhp]
[:drop:]
「啊！从现在起您就是客人了。[rhr]
_　今后您可以随时在车厢里自由走动」[rhp]

[:princess:][puri_w kao=1 ]
「知道了。还得跟博士打个招呼呢」[rhp]

[:drop:][p_d_01][drop kao=1 ]
「嗯。有不明白的事问博士就好。[rhr]
_　毕竟他是知晓这世间绝大部分事情的杰出人物」[rhp]

[:princess:][puri_w kao=5 ]
「哦～把门槛抬得真高呢」[rhp]

[:drop:][p_d_16][drop kao=11 ]
「这是有依据的抬高」[rhp]

[:princess:][puri_w kao=13 ]
「这样啊！虽然见面有点紧张……[rhr]
_　但反而更期待了呢」[rhp]

[:drop:][p_d_01][drop kao=13 ]
「那就好。博士也是我们大家都很敬爱的人」[rhp]

[:princess:][puri_w ]
「真的吗！越来越期待了！」[rhp]
[:princess:]
「今天谢谢你，多洛普。[rhr]
_　虽然还有很多不明白的事，但多亏你帮了大忙」[rhp]

[:drop:][p_d_07]
「帮助客人是我的本职工作」[rhp]
「那么公主，请好好休息」[rhp]

[se storage="door_08.ogg"]

[off_all]

[::]
多洛普关上客舱的门离开了。[rhp]
想必是回机房了吧。[rhr]
路上他总说平时都待在那里。[rhp]

[fbgm]

[bg_rule storage="train_08.jpg" rule="002.png" time=2000]

……久违的独处时光。[rhr]
回想至今发生的事，感觉周围格外宁静。[rhp]

;布擦れる
[se storage="body_08.ogg"]

[:princess:][puri_w kao=12 ]
「………………呼！」[rhp]

[off_all]

[::]
我纵身躺倒在早已准备好的床铺上，[rhr]
仰面朝天呆呆地望着天花板。[rhp]

……时光飞逝，我竟忘了思考重要的事。[rhp]

为何我身在铁道之中？[rhp]
为何铁道会在宇宙中奔驰？[rhp]
这实在太荒诞不经了。[rhr]
种种思绪在脑海中飞快穿梭，我闭目试图平静下来。[rhp]

;****************************************
;個室_プリ
[bg storage="train_12.jpg" time=1000]
;****************************************
[bgm storage="bgm_08.ogg"]

[:princess:]
[font color=0x4682b4]
（……银河铁道……）[rhp]
[resetfont]

[::]
回想起多洛普说过的话。[rhp]
正如多洛普所言，能在宇宙中遨游的只有宇航员。[rhr]
至少我不是，他们也绝对不可能是。[rhp]
无需掐脸验证，被夸德里利昂殴打的疼痛，[rhr]
以及躺卧被褥的触感都真实无比。[rhp]
为何我会身处此等境地？[rhp]

[:princess:]
[font color=0x4682b4]
（试图回忆时，脑中就像笼罩着迷雾……）[rhp]
[resetfont]

[::]
不禁叹息。……许是因回忆不起而焦躁吧。[rhr]
明明醒来才不久，却已疲惫不堪。[rhp]

我究竟遭遇了什么？[rhr]
今后该如何是好？[rhp]
是否该继续与他们同行？[rhr]
这样做我的记忆就能恢复吗？[rhp]
……虽说是这么说，但现在的我根本没有选择的余地。[rhp]


[:princess:]
[font color=0x4682b4]
（…………。嘛，就是那样）[rhp]
[:princess:]
（忘记了的事情也没办法。[rhr]
_　现在在这里烦恼，似乎现在的我也做不了什么）[rhp]
[:princess:]
（既然如此干脆转换心情，[rhr]
_　不如好好享受这份非现实感也不错）[rhp]
[:princess:]
（…………，嗯，那样就好。[rhr]
_　难得来到天上，一直盯着天空看也太……）[rhp]
[resetfont]

;****************************************
#
[bg storage="train_08.jpg" time=100]
;****************************************

;布擦れる
[se storage="body_07.ogg"]

[:princess:][puri_w kao=2 ]
「――――好！！！」[rhp]

[off_all]

[::]
重新振作精神，我猛地从床铺上弹起身。[rhp]

;****************************************
;頭をぶつける
[anten color="0xffffff" time=100]
[fbgm]
[yurasu]
[se storage="hand_06.ogg"]
;****************************************
;--------------------------------------------------------------------------------------------
;▼再開▼
;サウスボイスは途中までunknownタグに反応します
[voconfig sebuf=1 name=unknown vostorage="sausu/full/{number}.ogg" number=1]
[vostart]
;--------------------------------------------------------------------------------------------

[:unknown:]
「疼……！！！！！」[rhp]

[:princess:][puri_w kao=3 as=on ]
「呜……痛啊～～……！」[rhp]

[off_puri ]

[::]
脑袋遭到猛烈冲击，刚起身我就蜷缩在床铺上。[rhp]
好像有谁在房间里，但现在不是在意那个的时候……[rhp]

[:princess:][puri_w kao=2 as=on ]
「说不是时候才怪啊！什么时候房间里―――」[rhp]

[:unknown:][sausu kao=3 as=on ss=on ]
「好痛……痛死了……要死了……」[rhp]

[:princess:][puri_w kao=2 as=on ]
「……！？」[rhp]

[::]
眼前，一个穿着花哨的陌生男人正抱着头蜷缩着。[rhp]

[bgm storage="bgm_35.ogg"]

[:unknown:][sausu kao=8 as=on ]
「为什么突然起身啊……！一般人都会以为还在睡觉吧」[rhp]

[:princess:][puri_w kao=6 as=on ]
[font color=0x4682b4]
（诶？这、这人怎么回事？谁啊？什么时候进房间的……！）[rhp]
[resetfont]
[:princess:]
「那个……」[rhp]

[:unknown:][sausu kao=13 as=on ]
「啊，抱歉抱歉……稍微等一下。我现在缓一缓」[rhp]
[:unknown:][sausu kao=12 as=on ]
[font size=13]
「呼～～～～～～～……哈～～～～～～……」[rhp]
[resetfont]
[:unknown:][sausu kao=3 as=on ]
「……还痛……」[rhp]

[off_all]

[::]
正试图通过深呼吸让自己冷静下来的神秘男子。[rhr]
居然有这样的人，多洛普可没介绍过……[rhp]

[:princess:][puri_w kao=0 as=on ]
[font color=0x4682b4]
（啊，莫非这个人就是博士？）[rhp]
[resetfont]

[off_puri ]

[::]
那个既是哲学家又是发明家，既是科学家又是心理学者的博士？[rhr]
确实看起来怪怪的，应该没错了。[rhp]

[:princess:][puri_w ]
「那个，初次见……」[rhp]

[:unknown:][sausu ]
「早上好，公主！」[rhp]

[:princess:][puri_w ]
「！　早、早上好」[rhp]

[:unknown:][sausu kao=13 ]
「夜晚真美好呢。旅程还愉快吗？」[rhp]

[:princess:][puri_w kao=0 ]
「呃，是的。马马虎虎……」[rhp]

[:unknown:][sausu ]
「马马虎虎是什么？」[rhp]

[:princess:][puri_w kao=6 as=on ]
「嗯？」[rhp]

[:unknown:][sausu kao=7 ]
「是小狗的名字吗？不对，那应该是小波……[rhr]
_　嗯——抱歉，我不太确定。能再说一次吗？」[rhp]

[:princess:]
「对、对不起……」[rhp]

[:unknown:][sausu kao=4 as=on ]
「！ 为、为什么要道歉？你莫非是猫派？」[rhp]

[:princess:][puri_w kao=3 as=on ]
「不是。我以为您会对这种含糊的评价生气」[rhp]

[:unknown:][sausu kao=13 ]
「含糊！　原来如此，马马虎虎就是含糊的意思啊。[rhr]
_　语言真是有趣呢」[rhp]
[:unknown:]
「等下要向博士炫耀。[rhr]
_　就说公主现在非常马马虎虎哦」[rhp]

[:princess:][puri_w kao=4 ]
「诶……」[rhp]

[::]
…………这么说来，这人不是博士？[rhp]

[:princess:][puri_w kao=2 as=on ]
「请、请问……！　您是谁？」[rhp]

[:unknown:][sausu ]
「嗯？　找我吗？」[rhp]

[:princess:][puri_w kao=6 as=on ]
「听说乘车人数是8人。[rhr]
_　如果你不是那位博士先生的话，可就是第9个人了呢」[rhp]

[:unknown:][sausu kao=5 ]
「……啊！　原来如此。是这么回事啊」[rhp]
[:unknown:]
「因为我是赞助人啦。平时可不能一直待在这儿。[rhr]
_　所以不把我算在人数里」[rhp]

[:princess:][puri_w kao=0 ]
「赞助人……？」[rhp]

[:unknown:][sausu ]
「好久不见啊，公主。最近怎么样」[rhp]

[:princess:][puri_w kao=6 as=on ]
「好久不见……？」[rhp]

[:unknown:][sausu kao=14 ]
「啊对了！　你失去记忆了来着。哈哈哈！」[rhp]

[off_all]

[::]
不知有什么可笑的，男人独自笑了起来。[rhr]
与他愉悦的神情成正比，我心中的疑虑正不断膨胀……[rhp]

[:unknown:][sausu ]
「突然吓到你了吧。抱歉抱歉，我可不是什么可疑人物哦」[rhp]

[:princess:][puri_w kao=6 as=on ]
「超级可疑的好吗……」[rhp]

;--------------------------------------------------------------------------------------------
;▼再開▼
;サウス（ここからサウスの名前に反応
[voconfig sebuf=1 name=sausu vostorage="sausu/full/{number}.ogg" number=20]
;--------------------------------------------------------------------------------------------

[:sausu:]
「我是南。硬要说的话算是神明大人吧」[rhp]

[:princess:][puri_w kao=2 as=on ]
「哈？　神、神明？」[rhp]

[:sausu:][sausu kao=5 ]
「……顺便说下，我就是把你们召唤来这个世界的罪魁祸首」[rhp]

[:princess:][puri_w kao=4 as=on ]
「―――――！」[rhp]

[:sausu:][sausu kao=11 ]
「虽然也考虑过采取强硬手段啦。[rhr]
_　但看你当时实在太耍赖了。我不知不觉也较上劲了呢」[rhp]

[:princess:][puri_w kao=0 as=on ]
「……？　您在说什么？」[rhp]

[:sausu:][sausu ]
「昨天的事哟」[rhp]
[:sausu:][sausu kao=13 ]
「……怎么样？　在这个世界玩得开心吗？」[rhp]

[:princess:][puri_w kao=0 ]
「还、还算凑合吧」[rhp]

[:sausu:][sausu kao=11 ]
「嗯嗯，就是这样的」[rhp]
[:sausu:][sausu kao=5 ]
「……你看。没有成佛不是正确的选择吗」[rhp]

[:princess:][puri_w kao=4 as=on ]
「………………欸」[rhp]

[off_all]

[::]
………………成佛？[rhp]

[:sausu:][sausu kao=13 ]
「这个世界很有趣哦！[rhr]
_　活着时做不到的事，在这里什么都能实现」[rhp]

[:princess:][puri_w kao=2 as=on ]
「等等等等！稍微暂停一下！」[rhp]

[:sausu:][sausu ]
「怎么啦？」[rhp]

[:princess:]
「成、成佛！？……你是说……什么……！」[rhp]

[:sausu:][sausu kao=0 ]
「……………………」[rhp]
[:sausu:][sausu kao=6 as=on ]
「……啊，对了！连那种事都忘了吗……[rhr]
_　抱歉。我好像有点做过头了」[rhp]

[:princess:][puri_w kao=8 as=on ]
「难、难道我已经……」[rhp]

[:sausu:][sausu kao=3 ]
「想知道吗？关于那些事」[rhp]

[:princess:]
「当然！只要能弄清楚，怎样都好！」[rhp]

[:sausu:]
「你今天死掉了」[rhp]

[:princess:][puri_w kao=4 as=on ]
「………………！」[rhp]

[:sausu:][sausu kao=3 ]
「年纪轻轻就死了，真可怜呐……[rhr]
_　不过已经什么都不用担心了」[rhp]
[:sausu:][sausu kao=13 ]
「我的银河铁道会载着你永永远远，去往任何地方。[rhr]
_　带你去往美妙的地方哦」[rhp]

[:princess:][puri_w kao=3 ]
「……死了的话，这里就是那个世界？」[rhp]

[:sausu:][sausu kao=7 ]
「严格来说不算……不过住在这里的孩子，应该都不算人类了吧」[rhp]

[::]
「至少，」南用轻快的语气补充道。[rhr]
完全搞不懂状况。死了？……我？[rhp]

[:princess:][puri_w kao=2 as=on ]
「…………完全没印象」[rhp]

[off_all]

[::]
莫非是因为死后失去了生前的记忆吗。[rhr]
但这种事情……[rhp]

[:princess:][puri_w kao=2 as=on ]
「！！　等等。你说我是今天死的对吧？[rhr]
_　可大家都说在这次旅程中和我一起去野营过」[rhp]
[:princess:]
「我今天才死，今天刚来到这里，[r]
_　却和这里的大家在这个世界共同旅行过不是很奇怪吗？」[rhp]

[off_puri]

[::]
面对我的追问，南稍显迟疑后回答道。[rhp]

[:sausu:][sausu kao=13 ]
「以前的你，确实去过吧」[rhp]

[:princess:][puri_w kao=8 as=on ]
「以前的我？」[rhp]

[::]
……究竟是什么意思？[rhp]

[:sausu:][sausu kao=7 ]
「旅行目的地都是交给多洛普决定的，我并没有感知那部分。[rhr]
_　所以具体怎么去的野营营地之类的细节我也不太清楚……」[rhp]

[:princess:][puri_w kao=2 as=on ]
「…………」[rhp]

[off_all]

[::]
这根本不是回答。[rhr]
他所说的内容，我完全无法理解。[rhp]
…………不是故意的吧？[rhp]

[:sausu:][sausu kao=14 ]
「对了对了！喜欢这个名字吗？」[rhp]
[:sausu:]
「公主这个称呼，是我的朋友给你起的。[rhr]
_　他叫达克内布拉博士」[rhp]
[:sausu:]
「你能喜欢就太好了。博士非常睿智……」[rhp]

[:princess:][puri_w kao=3 ]
「――――够了，明白了」[rhp]

[:sausu:][sausu kao=0 ]
「……嗯？」[rhp]

[off_all]

[::]
南始终不给我确切的答案。[rhr]
这一定意味着，他有不想让我知晓的秘密。[rhp]

[:princess:]
[font color=0x4682b4]
（现在就算追问这个，也不可能坦白……）[rhp]
[resetfont]

[::]
那再问什么都是白费力气。[rhr]
倒不如说能问到这种程度已经不错了吧？[rhp]

这里是哪里。死后的世界。[rhr]
我是谁。死去的人类。[rhp]

这样一切就都说得通了。[rhp]

[:princess:][puri_w kao=11 as=on ]
「原来如此。难怪会这么离谱地充满幻想色彩。[rhr]
_　用《银河铁道》来解释所有事，多洛普这家伙意外地草率呢」[rhp]

[:sausu:][sausu kao=4 ]
「！真惊讶！你也知道《银河铁道之夜》吗？」[rhp]

[:princess:][puri_w kao=6 as=on ]
「怎、怎么突然问这个？」[rhp]

[:sausu:][sausu kao=14 ]
「我也超喜欢这部作品！[rhr]
_　达克内布拉博士一直在研究它……」[rhp]

[:princess:][puri_w kao=5 as=on ]
「啊哈哈……抱歉，其实我知道的不多。[rhr]
_　只是照搬多洛普的说法而已……」[rhp]

[:sausu:][sausu kao=14 as=on ]
「咦？啊……啊哈哈！[rhr]
_　抱歉抱歉，我不小心太兴奋了」[rhp]
[:sausu:][sausu kao=3 as=on ]
「说得也是呢……毕竟你的记忆是我（动手脚）」[rhp]

[:princess:][puri_w kao=0 ]
「那个故事很有名吗？」[rhp]

[off_all]

[::]
听到这个问题，南露出非常开心的表情，[rhr]
向我简要讲述了《银河铁道之夜》的故事。[rhp]
贫穷少年乔班尼与友人康贝瑞拉乘铁道在夜空旅行……[rhr]
概括来说大致是这样的故事。确实和现状很相似。[rhp]

[:princess:][puri_w kao=11 ]
「不过话说回来，总感觉有点扫兴呢。死亡原来是这种感觉」[rhp]
[:princess:]
「意外地还挺轻松的。[rhr]
_　既不会痛也不会难受真是太好了」[rhp]

[:sausu:][sausu kao=6 ]
「那或许是因为你没有记忆的缘故吧？」[rhp]

[:princess:][puri_w kao=6 as=on ]
「啊……对哦。说不定本来也是经历过那些痛苦的，[rhr]
_　只是因为失忆才不记得了……」[rhp]
[:princess:][puri_w kao=14 ]
「不过嘛，那样的话反而算幸运！[rhr]
_　能让人忘记不愉快的事，我可得感谢这失忆呢。嘛——虽说」[rhp]

[:sausu:][sausu kao=6 ]
「……不难过吗？　你已经死了哦？」[rhp]

[:princess:][puri_w kao=7 ]
「完全不会。因为什么都不记得，连悲伤都无从谈起」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:sausu:][sausu kao=4 as=on ]
「！」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:princess:][puri_w kao=14 ]
「什么嘛。这样的话就不必烦恼什么必须恢复原状啦[rhr]
_　今后该怎么办啦之类的问题。白白纠结这么久真是亏大了」[rhp]
[:princess:]
「那你早点说清楚不就好了嘛，死神先生」[rhp]

[:sausu:][sausu kao=2 as=on ]
「才、才不是死神呢。太失礼了！[rhr]
_　居然把如此美丽的我错认成那种东西」[rhp]

[:princess:][puri_w ]
「我一直以为死神都是穿着黑袍的骷髅模样」[rhp]

[:sausu:][sausu kao=6 as=on ]
「所以说啊！　我不是死神。[rhr]
_　请好好叫我南」[rhp]

[:princess:][puri_w ]
「那么，南。[rhr]
_　……谢谢你带我来这里」[rhp]

[:sausu:][sausu kao=4 ]
「……！　公主……」[rhp]

[:princess:][puri_w ]
「死亡这件事 意外地不坏呢。 [rhr]
_　没想到竟有如此美妙的世界！」[rhp]

[:sausu:][sausu kao=5 hh=on ]
「――――……！　对。就是这样啊！[rhr]
_　果然你也这么想对吧？　真厉害！　太高兴了」[rhp]
[:sausu:]
「我也觉得这条铁道是最棒的。[rhr]
_　可以去任何地方，也能成为任何模样！」[rhp]
[sausu kao=14 hh=on ]
[:sausu:]
「这世上尽是好事情呀！」[rhp]

[:princess:][puri_w ]
「而且，好像还会使用魔法呢！」[rhp]

[:sausu:][sausu kao=13 ]
「没错没错。在这里可以随心所欲哦」[rhp]

[:princess:][puri_w kao=5 hh=on ]
「那，失礼了……」[rhp]

[yurasu]
[font size=26]
「噼里啪啦砰砰！！」[rhp]
[resetfont]

[:sausu:][sausu ]
「…………？你在干什么？」[rhp]

[:princess:][puri_w kao=6 as=on ]
「说到魔法我以为就是这个……但什么都没发生啊」[rhp]

[:sausu:][sausu kao=13 ]
「啊，只有公主不能使用魔法。抱歉啦」[rhp]

[:princess:][puri_w kao=8 as=on ]
「哈！？为什么！？」[rhp]

[:sausu:][sausu kao=5 ]
「呃、嗯……啊哈哈。[rhr]
_　嘛，详细情况不太能说就是了……」[rhp]

[off_all]

;****************************************
;スチル
[still storage="cg/a_01_2.png" width="1280" height="720" rule="007.png" time=500]
[cg storage="cg/a_01_2.png"]
;****************************************

[:sausu:]
「……毕竟我和你是做过那种约定的」[rhp]

[:princess:]
「约束？」[rhp]

[:sausu:]
「是你还不懂事的时候，强加给我的约定啊」[rhp]
[:sausu:]
「所以没法使用魔法这件事，说到底都是你的责任呢。[rhr]
_　真遗憾。呵呵呵！」[rhp]

[:princess:]
「什、什么啊……那是生前的事了吧。我不记得了所以不算！」[rhp]

[:sausu:]
「抱歉，那是不行的哦」[rhp]
[:sausu:]
「……我也有，绝不能退让的东西」[rhp]

[:princess:]
「南……？」[rhp]

;****************************************
#
[bg storage="cg/a_01_2b.png" width="1280" height="720" time=500]
[cg storage="cg/a_01_2b.png"]
;****************************************

[:sausu:]
「……开玩笑的啦！」[rhp]
[:sausu:]
「即使没有魔法，这个世界也处处充满美好。[rhr]
_　现在若能尽情享受我赠送的礼物，我将深感荣幸」[rhp]
[:sausu:]
「欢迎来到我的宝石箱。愿你尽情享受这段美妙旅程！」[rhp]

[:princess:]
「……嘛算了。光是存在于这个世界就已经像魔法一样了。[rhr]
_　这次就姑且原谅你吧」[rhp]
[:princess:]
「谢谢你呢，南。带我来这里！[rhr]
_　能遇见南真是太好了」[rhp]

[:sausu:]
「呵呵呵。变得相当坦率了呢」[rhp]

[:princess:]
「……南好像知道我过去的经历，[rhr]
_　但我们是能够如此轻易相识的关系吗？你明明是神明吧？」[rhp]

;****************************************
#
[bg storage="cg/a_01_2c.png" width="1280" height="720" time=500]
[cg storage="cg/a_01_2c.png"]
;****************************************

[:sausu:]
「并非谁都能见到我。[rhr]
_　只有即将逝去的孩子，才能看见我的身姿」[rhp]

[:princess:]
「果然是死神嘛……」[rhp]

;****************************************
#
[bg storage="cg/a_01_2d.png" width="1280" height="720" time=500]
[cg storage="cg/a_01_2d.png"]
;****************************************

[:sausu:]
「不是死神！名为我的存在，是由梦想与希望构成的」[rhp]

[:princess:]
「是是……」[rhp]

;****************************************
;個室_プリ
[still_end frame="win.png" storage="train_08.jpg" time=100]
;****************************************

[:princess:]
「……话说」[rhp]

[:sausu:][sausu kao=1 ]
「什么？」[rhp]

[:princess:][puri_w kao=6 ]
「为什么刚才要把脸凑近睡着的我？这是性骚扰哦」[rhp]

[:sausu:][sausu kao=13 ]
「啊那个。那是博士教我的」[rhp]

[:princess:][puri_w kao=0 as=on ]
[font color=0x4682b4]
（出现了，那位传说中的博士！）[rhp]
[resetfont]

[:sausu:][sausu kao=14 ]
「他教我关于星座的神话传说。[rhr]
_　因为那实在太浪漫了，让我也忍不住想试试看呢」[rhp]
[:sausu:]
「我心跳得好厉害啊！[rhr]
_　谢谢你让我有这么棒的体验，公主」[rhp]

[:princess:][puri_w kao=8 as=on ss=on ]
「………………你、你对我做了什么？」[rhp]

[:sausu:][sausu kao=13 ]
「本来是想亲你的，[rhr]
_　发现你醒着就假装要亲然后停住了」[rhp]

[:princess:][puri_w kao=2 as=on ss=on ]
「哈……！？这、这算什么啊！？」[rhp]

[:sausu:][sausu kao=14 ]
「别这么生气嘛。博士说在美国接吻只是问候方式」[rhp]

[off_all]

;****************************************
#
;扉閉める
[se storage="door_08.ogg"]
;寝台車廊下
[bg storage="train_04.jpg" method="fadeInRightBig" time=500]
;****************************************

[:sausu:][sausu kao=2 as=on ]
「等、等一下～～！？为什么赶我出去啊！？让我进去啦公主！[rhr]
_　我还有好多话想跟你说～！」[rhp]

[off_all]

;****************************************
#
;扉を叩く（複数）
[se storage="door_15.ogg"]
;個室_プリ
[bg storage="train_08.jpg" time=500]
;****************************************

[::]
身后传来南咚咚咚的砸门声，[rhr]
我抵着门用后背和他较劲。[rhp]

[:princess:][puri_w kao=2 as=on ss=on ]
「那、那家伙怎么回事……！恶心！可怕！」[rhp]

[off_all]

[:sausu:]
『恶心可怕是什么意思？告诉我……』[rhp]

[yurasu]

[:heartshape:]
『啊―――――！！南！！』[rhp]
[resetfont]

;****************************************
#
;寝台車廊下
[bg storage="train_04.jpg" time=500]
;****************************************

[:sausu:]
「呕……！」[rhp]

[:heartshape:][hati kao=2 ][s_playse storage="hati/full/18.ogg" buf=1]
「喂南！怎么最近都不来找我！？[rhr]
_　不是说好要试试我的新必杀技吗！？」[rhp]

[:sausu:][sausu kao=6 as=on ss=on ]
「才、才没这种约定～～！住手……」[rhp]

[off_all]

;****************************************
#
[bg storage="train_12.jpg" time=200]
;****************************************

[::]
话未说完，南的惨叫声便响彻四周。[rhp]
紧接着传来『极限雷电审判』这句谜之宣言与，[rhr]
杰特君的笑声从门对面传来。[rhp]
不久后，夸德里利昂匆忙赶来的声响、[rhr]
以及多洛普愕然的怒斥声也朝这边接近。[rhp]
虽然听不见声音，但快斗肯定也在吧。[rhr]
颇有全员大集合的感觉。大家关系真好啊……[rhp]
虽然是死神又变态，但南似乎挺受人爱戴的。[rhp]
……这般喧闹，总觉得看起来非常快乐。[rhr]
我也想加入大家，但现在的我会不会扫兴呢……[rhp]

;****************************************
#
[bg storage="train_08.jpg" time=500]
;****************************************

[:princess:][puri_w kao=6 ]
「……稍微有点被排斥的感觉……」[rhp]

[off_puri ]

[::]
………………话虽如此。[rhp]
这里可是死后世界，而我直到昨日都还活着啊。[rhr]
他们对待昨日之前的我，简直像是旧识一般。[rhp]
『以前的我』该不会是指[rhr]
我和他们还活着时的事吧？[rhp]

[:princess:]
[font color=0x4682b4]
（…………若是这样的话，或许不错）[rhp]
[resetfont]

[::]
即使我也融入大家的圈子，[rhp]
对一无所知的我，他们也会欢迎吗。[rhp]
……………………。[rhp]

[fbgm]

[:princess:][puri_w kao=12 ]
「…………算了算了。别想得太复杂」[rhp]
[:princess:][puri_w kao=1 ]
「毕竟我已经死了嘛」[rhp]

[off_all]

[::]
被讨厌也无所谓。[rhr]
既不会因此活得艰难，也不必再为生存挣扎。[rhp]
归根结底，我是自由的。[rhp]

[:princess:][puri_w kao=5 ]
「……为之则成！　不为则败！」[rhp]

[off_all]

;****************************************
#
;扉開ける（強）
[se storage="door_07.ogg"]
;寝台車廊下
[bg storage="train_04.jpg" method="fadeInRightBig" time=500]
;****************************************

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
;--------------------------------------------------------------------------------------------

[bgm storage="bgm_01.ogg"]

[:princess:][puri_w kao=2 as=on hh=on ]
「那个！！」[rhp]

[off_puri ]

[:sausu:][sausu kao=4 as=on ]
「！　公主？」[rhp]

[off_sausu ]

[:princess:][puri_w kao=2 as=on hh=on ]
「哇……我也……！」[rhp]
[yurasu]
[font size=27]
「我也要裁决，可以吗！？」[rhp]
[resetfont]

[off_puri ]

[:sausu:][sausu kao=2 as=on ss=on ]
「！？」[rhp]

[off_sausu ]

[chara_part name="jet" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:]
「啊哈哈哈！　太棒了公主！」[rhp]

[:jet:]
「酷毙了，公主！」[rhp]

[off_all]

[:sausu:][sausu kao=2 as=on ss=on ]
「过、过分……！　我们不是朋友吗……」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▼再開▼
[voconfig sebuf=1 name=kite vostorage="kite/full/{number}.ogg" number=32]
[vostart]
;------------------------------------------------------------------------------------------

[chara_part name="riri" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="kite" body=tange kao=15 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:kite:]
「站起来……！　站起来啊，南——！」[rhp]

[:quadrillion:]
「把他揍扁！　那个丑八怪！」[rhp]

[off_all]

[chara_part name="drop" body=base kao=2 as=on ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=8 as=on ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="600" top="0" wait="true" time=150]

[:sausu:]
「！！？？　哎哎哎……！　暴、暴力不太好吧」[rhp]

[:drop:]
「喂，你们两个！　为什么要煽动对立！」[rhp]

[off_all]

[chara_part name="jet" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:]
「来吧，公主！[rhr]
_　本大爷们来教你裁决的奥义！」[rhp]

[:jet:]
「从今天起你就是我们的小弟了！」[rhp]

[off_all]

[:princess:][puri_w kao=5 hh=on ]
「欸嘿嘿……！　请多指教！」[rhp]

[off_puri ]

[::]
最初多洛普也说过。[rhp]
琐碎之事可以暂且搁置。[rhr]
在这种地方抱头烦恼实属浪费。[rhp]
该享受时就该尽情享受。[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
[bg storage="sky_12.jpg" time=1000]
;****************************************

星之海。天空地面。漆黑却闪耀的银河。[rhp]
银河轨道。[rhr]
魔法铁道。[rhp]

与其纠结苦涩过去，不如把握此刻悸动。[rhr]
遵从本能吧！[rhp]

;****************************************
[bg storage="white.jpg" time=1000]
;****************************************

美妙旅程即将开始的预感！[rhp]

;****************************************
[s_mask color=0xffffff time=3000]
[fbgm]
[bg storage="black.jpg" time=100]
; メッセージウィンドゥ非表示
[anim name="message_outer" time="500" opacity=" 0"]
; メニューアイコン非表示
[hidemenubutton]
[s_mask_off time=3000]
;-----------------------------------------------------------

[movie storage="op.webm" skip="true" volume="30"]

;****************************************

[jump storage="ss_main.ks" target="*start"]

[s]
