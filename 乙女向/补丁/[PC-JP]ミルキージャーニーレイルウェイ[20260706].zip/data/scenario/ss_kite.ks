﻿
*start

[bgm storage="bgm_30.ogg"]

[jump target="*ss_2nd" cond="f.nigmode == 1 && f.ss_2nd_kite == 1"]
[jump target="*ss_16" cond="f.ss_kite >= 15"]
[jump target="*ss_15" cond="f.ss_kite >= 14"]
[jump target="*ss_14" cond="f.ss_kite >= 13"]
[jump target="*ss_13" cond="f.ss_kite >= 12"]
[jump target="*ss_12" cond="f.ss_kite >= 11"]
[jump target="*ss_11" cond="f.ss_kite >= 10"]
[jump target="*ss_10" cond="f.ss_kite >= 9"]
[jump target="*ss_09" cond="f.ss_kite >= 8"]
[jump target="*ss_08" cond="f.ss_kite >= 7"]
[jump target="*ss_07" cond="f.ss_kite >= 6"]
[jump target="*ss_06" cond="f.ss_kite >= 5"]
[jump target="*ss_05" cond="f.ss_kite >= 4"]
[jump target="*ss_04" cond="f.ss_kite >= 3"]
[jump target="*ss_03" cond="f.ss_kite >= 2"]
[jump target="*ss_02" cond="f.ss_kite >= 1"]
[jump target="*ss_01"]

;---------------------------------------------------------------------------------------------
*ss_01
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_01.jpg" time=1000 ]
;****************************************

[winset]

[:princess:][puri_w kao=1 ]
「快斗、你好。方便的话要不要聊聊天打发时间……」[rhp]

[off_all]

[:kite:][kite kao=12 ]
「……………………」[rhp]

[:princess:][puri_w kao=0 ]
「啊、睡着了……」[rhp]

[:kite:][kite kao=12 ]
「……………………」[rhp]

[:princess:][puri_w kao=13 ]
[font color=0x4682b4]
（吵醒他不太好、还是安静离开吧……）[rhp]
[resetfont]

; 好感度+10
[eval exp="f.love_k  = f.love_k + 10"]

[eval exp="f.ss_kite = 1"]
[eval exp="f.ss_2nd_kite= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_02
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_01.jpg" time=1000 ]
;****************************************

[winset]

[:princess:][puri_w kao=1 ]
「快斗！闲着也是闲着说说话嘛……」[rhp]

[:kite:][kite kao=12 ]
「……………………」[rhp]

[:princess:][puri_w kao=0 ]
「又睡着了。真是贪睡呢」[rhp]

[:kite:][kite kao=12 ]
「……………………」[rhp]

[:princess:][puri_w kao=12 ]
「嗯——下次再来吧。晚安」[rhp]

; 好感度+10
[eval exp="f.love_k  = f.love_k + 10"]

[eval exp="f.ss_kite = 2"]
[eval exp="f.ss_2nd_kite= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_03
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_01.jpg" time=1000 ]
;****************************************

[winset]

[:princess:][puri_w kao=1 ]
「……………………」[rhp]

[:kite:][kite kao=12 ]
「……………………」[rhp]

[:princess:][puri_w kao=6 ]
「不管怎么说也睡过头了吧……？[rhr]
_　每次我来都在睡觉！」[rhp]

[:kite:][kite kao=12 ]
「……………………」[rhp]

[:princess:][puri_w kao=2 ]
「！说不定生前过着连睡眠时间都挤不出来的生活、[rhr]
_　所以在这里才会像要补足积压的睡眠欲望般贪婪地沉眠……？」[rhp]

[:kite:][kite kao=12 ]
「……………………」[rhp]

[:princess:][puri_w kao=3 as=on ]
「呜……对不起、快斗。我会注意不再打扰你……」[rhp]

[off_kite]

[:princess:][puri_w kao=1 ]
「先走啦！」[rhp]

[off_puri]

[:kite:][kite kao=12 ]
「……………………」[rhp]
[:kite:][kite kao=2 as=on ]
「…………那家伙在胡说什么啊？」[rhp]

; 好感度+10
[eval exp="f.love_k  = f.love_k + 10"]

[eval exp="f.ss_kite = 3"]
[eval exp="f.ss_2nd_kite= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_04
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_01.jpg" time=1000 ]
;****************************************

[winset]

[:kite:][kite kao=12 ]
「……………………」[rhp]

[:princess:][puri_w kao=0 ]
「快斗今天也在睡着……」[rhp]

[:kite:][kite kao=12 as=on ]
「……………………」[rhp]

[:princess:][puri_w kao=12 ]
「但想到快斗生前的境遇、我不该多嘴……」[rhp]

[:kite:]
「……………………」[rhp]

[:princess:][puri_w kao=1 ]
「所以呢、我带了这个。[rhr]
_　让多洛普用魔法变出来的香薰瓶」[rhp]

[off_all]

[:princess:]
「把这个放在枕边……好了」[rhp]

[:kite:]
「……………………」[rhp]

[off_all]

[:princess:][puri_w kao=13 ]
「明天就换竹炭的香味吧」[rhp]
[:princess:]
「先走啦！」[rhp]

[off_puri]

[:kite:][kite kao=12 as=on ]
「……………………」[rhp]

[yurasu]

[:kite:][kite kao=2 as=on ]
「…………咳呃！！」[rhp]
[:kite:]
「呜……！薰衣草味道直冲脑门……！[r]
_　说什么枕边根本就是贴鼻孔了吧。这哪是芳香剂该放的距离」[rhp]

[:kite:][kite kao=6 as=on ]
「这下糟糕……装睡要遭报应了……」[rhp]

; 好感度+10
[eval exp="f.love_k  = f.love_k + 10"]

[eval exp="f.ss_kite = 4"]
[eval exp="f.ss_2nd_kite= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_05
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_01.jpg" time=1000 ]
;****************************************

[winset]

[:princess:][puri_w kao=1 ]
「快斗。按约定今天换成竹炭啦」[rhp]

[off_all]

[:kite:][kite kao=12 as=on ]
[font color=0x4682b4]
（有一股焦炭味……）[rhp]
[resetfont]

[:princess:][puri_w kao=1 ]
「嘘……」[rhp]

[:kite:][kite kao=12 as=on ]
「嗯～～～……」[rhp]

[:princess:][puri_w kao=4 ]
「！」[rhp]

[:kite:][kite kao=12 as=on ]
「竹子……唯独竹子……唔嗯……」[rhr]
[font color=0x4682b4]
（快察觉……快察觉……！）[rhp]
[resetfont]

[:princess:][puri_w kao=2 as=on ]
「快、快斗……说梦话还在讲冷笑话」[rhp]

[:kite:][kite kao=12 as=on ]
[font color=0x4682b4]
（不对！！）[rhp]
[resetfont]

[:princess:]
「……！　原来如此，快斗讨厌竹子。[rhr]
_　所以对竹炭也反应过度说梦话！」[rhp]

[:kite:]
[font color=0x4682b4]
（没错没错。就这样带回去吧）[rhp]
[resetfont]

[:princess:][puri_w kao=3 as=on ]
「莫非生前被竹子折磨过之类的……？」[rhp]

[:kite:]
[font color=0x4682b4]
（哈？）[rhp]
[resetfont]

[off_kite]

[:princess:][puri_w kao=1 ]
「嗯，这个我带走吧。做个好梦……快斗！」[rhp]

[off_puri]

[:kite:][kite kao=12 ]
[font color=0x4682b4]
（总觉得不太痛快……）[rhp]
[resetfont]

; 好感度+10
[eval exp="f.love_k  = f.love_k + 10"]

[eval exp="f.ss_kite = 5"]
[eval exp="f.ss_2nd_kite= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_06
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_01.jpg" time=1000 ]
;****************************************

[winset]

[:princess:][puri_w kao=1 ]
「你好ー」[rhp]

[:kite:][kite kao=12 as=on ]
[font color=0x4682b4]
（又来了……）[rhp]
[resetfont]

[:princess:][puri_w kao=1 ]
「啊ー，果然今天快斗也在睡觉」[rhp]
[:princess:][puri_w kao=1 ]
「真是能睡啊。在梦里度过这么多时间，[rhr]
_　究竟在做着什么梦呢……」[rhp]

[:kite:]
[font color=0x4682b4]
（什么都行啦……别管我了……）[rhp]
[resetfont]

[:princess:][puri_w kao=11 ]
「好闲啊……」[rhp]

[:kite:]
[font color=0x4682b4]
（那回房间不就好了……）[rhp]
[:kite:]
（…………，总觉得还是醒着更轻松）[rhp]
[resetfont]

[:princess:][puri_w kao=0 ]
「竹……」[rhp]

[:kite:][kite kao=12 ]
「？」[rhp]

[:princess:][puri_w kao=11 ]
「我不怕……我才不怕竹子呢……」[rhp]

[:kite:][kite kao=12 ]
[font color=0x4682b4]
（这家伙……想用睡眠学习法克服心理阴影……！）[rhp]
[resetfont]

[off_kite]

[:princess:][puri_w kao=11 ]
「竹子不可怕……竹子不可怕……」[rhp]
[:princess:][puri_w kao=0 ]
「………………」[rhp]
[:princess:][puri_w kao=6 as=on ]
「…………我在干什么啊？　我」[rhp]

[off_puri]

[:kite:][kite kao=12 ]
[font color=0x4682b4]
（这该是我的台词才对……）[rhp]
[resetfont]


; 好感度+10
[eval exp="f.love_k  = f.love_k + 10"]

[eval exp="f.ss_kite = 6"]
[eval exp="f.ss_2nd_kite= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_07
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_01.jpg" time=1000 ]
;****************************************

[winset]

[:princess:][puri_w kao=1 ]
「快斗。今天又在睡觉呢。虽然早知道了」[rhp]

[:kite:][kite kao=12 as=on ]
[font color=0x4682b4]
（不会吧……为什么就不长记性呢，这家伙……？）[rhp]
[resetfont]

[:princess:][puri_w kao=1 ]
「我呢，反过来思考过了。[rhr]
_　为什么快斗每次我来时都在睡觉」[rhp]
[:princess:][puri_w kao=1 ]
「然后想到，会不会是平时睡眠质量不好呀？」[rhp]

[:kite:][kite kao=12 as=on ]
[font color=0x4682b4]
（真是多管闲事啊……）[rhp]
[resetfont]

[:princess:][puri_w kao=1 ]
「所以呢，给。放你枕头边记得喝哦」[rhp]

[off_kite]

[:princess:][puri_w kao=1 ]
「先走啦！」[rhp]

[off_puri]

[:kite:][kite kao=12 as=on ]
「……………………」[rhp]
[:kite:][kite kao=6 as=on ]
「…………"记得喝"算什么啊？」[rhp]

[off_all]

[::]
快斗在意地看向枕边。那里放着瓶装药品。[rhr]
标签上写着『博士原创安眠药※严禁滥用』。[rhp]

[:kite:][kite kao=2 as=on ss=on ]
「……………………」[rhp]


; 好感度+10
[eval exp="f.love_k  = f.love_k + 10"]

[eval exp="f.ss_kite = 7"]
[eval exp="f.ss_2nd_kite= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_08
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_01.jpg" time=1000 ]
;****************************************

[winset]

[:princess:][puri_w kao=1 ]
「快斗，早……」[rhp]

[:kite:][kite kao=0 ]
「早安 公主」[rhp]

[:princess:][puri_w kao=4 as=on hh=on ]
「！！！　醒、醒着……快斗醒着！！」[rhp]

[:kite:][kite kao=6 ]
「啊对啊。[rhr]
_　话说那个猛药是你放的吧公主」[rhp]

[:princess:][puri_w kao=1 ]
「嗯！你喝了吗？」[rhp]

[:kite:][kite kao=2 as=on ]
「怎么可能喝那种可疑药物。[rhr]
_　真的不用再做多余的事了……我会保持清醒的」[rhp]

[:princess:][puri_w kao=1 ]
「好、好的！这样就能和快斗在白天也聊天了呢。[rhr]
_　因为想和你变亲近，一直觉得很遗憾」[rhp]

[:kite:][kite kao=0 ]
「………………。哼」[rhp]

[:princess:][puri_w kao=0 as=on ]
「啊……你不愿意吗？」[rhp]

[:kite:][kite kao=7 ]
「无所谓啦。随你便」[rhp]

[:princess:][puri_w kao=13 ]
「快斗……！谢谢你。我以后还会来找你的」[rhp]

[:kite:][kite kao=12 ]
「是是……」[rhp]
[:kite:][kite kao=6 as=on ]
[font color=0x4682b4]
（……总算阻止了暴走。太好了……）[rhp]
[resetfont]


; 好感度+10
[eval exp="f.love_k  = f.love_k + 10"]

[eval exp="f.ss_kite = 8"]
[eval exp="f.ss_2nd_kite= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_09
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_01.jpg" time=1000 ]
;****************************************

[winset]

[:princess:][puri_w kao=1 ]
「快斗！现在有空吗？」[rhp]

[:kite:][kite kao=0 ]
「嘛算是吧」[rhp]

[:princess:][puri_w kao=1 ]
「我们在那边车厢和哈蒂君他们玩人生游戏，[rhr]
_　快斗也一起来玩吗？」[rhp]

[:kite:][kite kao=12 ]
「我的人生可没那么廉价能被桌游替换掉」[rhp]
[:kite:]
「所以不行——晚安」[rhp]

[:princess:][puri_w kao=6 as=on ]
「真没劲啊……不过算了」[rhp]


; 好感度+10
[eval exp="f.love_k  = f.love_k + 10"]

[eval exp="f.ss_kite = 9"]
[eval exp="f.ss_2nd_kite= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_10
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_01.jpg" time=1000 ]
;****************************************

[winset]

[:kite:][kite kao=1 ]
「哦。公主来啦」[rhp]

[:princess:][puri_w kao=2 as=on ]
「又没睡……最近到底怎么了」[rhp]

[:kite:][kite kao=11 ]
「我发现啊，不睡觉反而比较好哦」[rhp]

[:princess:][puri_w kao=0 ]
「比较好是什么意思？」[rhp]

[:kite:]
「不会被某人死缠烂打地搭话」[rhp]

[:princess:][puri_w kao=8 as=on ]
「诶——！？你、你讨厌我吗！？」[rhp]

[:kite:][kite kao=13 ]
「不不。我很高兴啦」[rhp]
[:kite:]
「只不过呢……我也到这个年纪了。[rhr]
_　被女生主动搭话会害羞之类的」[rhp]

[:princess:][puri_w kao=2 as=on ]
「绝对是在骗人……！」[rhp]

[:kite:]
「才没有这回事呢ー」[rhp]

; 好感度+10
[eval exp="f.love_k  = f.love_k + 10"]

[eval exp="f.ss_kite = 10"]
[eval exp="f.ss_2nd_kite= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_11
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_01.jpg" time=1000 ]
;****************************************

[winset]


[:kite:][kite kao=12 ]
「……」[rhp]

[:princess:][puri_w kao=2 as=on ]
「啊，又睡着了……！」[rhp]

[:kite:][kite kao=0 ]
「又来了？」[rhp]

[:princess:]
「哇！！」[rhp]

[:kite:][kite kao=0 ]
「被小看了啊。要见识下我的真本事吗？」[rhp]

[:princess:][puri_w kao=1 ]
「听起来很厉害的样子！」[rhp]

[:kite:][kite kao=13 ]
「那我先集中精神酝酿气势 你们暂时出去一下」[rhp]

[:princess:][puri_w kao=13 ]
「明白了！」[rhp]

[se storage="door_10.ogg"]
[off_all]
[rhp]

[:princess:][puri_w kao=2 as=on ]
[font size=28]
「喂！？」[rhp]
[resetfont]

[:kite:][kite kao=13 ]
「哈哈哈。果然很配合嘛」[rhp]

[:princess:][puri_w kao=6 as=on ]
「到、到底要戏弄我到什么程度才满意……？！」[rhp]


; 好感度+10
[eval exp="f.love_k  = f.love_k + 10"]

[eval exp="f.ss_kite = 11"]
[eval exp="f.ss_2nd_kite= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_12
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_01.jpg" time=1000 ]
;****************************************

[winset]

[:kite:][kite kao=0 ]
「……」[rhp]

[:princess:][puri_w kao=1 ]
「………………」[rhp]

[:kite:][kite kao=0 ]
「干嘛这副表情。我脸上沾了东西？」[rhp]

[:princess:][puri_w kao=1 ]
「最近经常看到醒着的快斗，[rhr]
_　安静不说话时还挺帅气的。今天带着忧郁感 帅气值额外增加两成」[rhp]

[:kite:][kite kao=0 ]
「原本我就话不多 也不是每天从早到晚都在睡觉。[rhr]
_　偶尔也会有需要思考的日子啊」[rhp]

[:princess:][puri_w kao=1 ]
「是有什么烦恼吗？不介意的话可以跟我说说」[rhp]

[:kite:][kite kao=11 ]
「真可靠啊。那有机会的话就拜托了」[rhp]

[:princess:][puri_w kao=2 as=on ]
「这辈子都不会有机会的吧……」[rhp]

; 好感度+10
[eval exp="f.love_k  = f.love_k + 10"]

[eval exp="f.ss_kite = 12"]
[eval exp="f.ss_2nd_kite= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_13
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_01.jpg" time=1000 ]
;****************************************

[winset]

[:princess:][puri_w kao=1 ]
「快斗！来陪你玩啦～」[rhp]

[:kite:][kite kao=5 ]
「来得正好 公主」[rhp]
[:kite:]
「事不宜迟 先连续说十遍"肘关节"」[rhp]

[:princess:][puri_w kao=1 ]
「？肘关节肘关节肘关节肘关节肘关节……」[rhp]

[:kite:]
「我呢？」[rhp]

[:princess:][puri_w kao=1 ]
「快斗」[rhp]

[:kite:][kite kao=11 ]
「噗——。原来是人啊」[rhp]

[:princess:][puri_w kao=2 as=on ]
「好气人啊……明明和手肘没关系！」[rhp]


; 好感度+10
[eval exp="f.love_k  = f.love_k + 10"]

[eval exp="f.ss_kite = 13"]
[eval exp="f.ss_2nd_kite= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_14
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_01.jpg" time=1000 ]
;****************************************

[winset]

[:princess:][puri_w kao=1 ]
「快斗你没睡觉的时候都在干嘛？」[rhp]

[:kite:][kite kao=0 ]
「呼吸」[rhp]

[:princess:][puri_w kao=1 ]
「好好好。那具体在做什么呢？」[rhp]

[:kite:][kite kao=7 ]
「……」[rhp]
[:kite:]
「在做啥呢？」[rhp]

[:princess:][puri_w kao=2 as=on ]
「诶……」[rhp]

[:kite:]
「稀松平常的行为确实不太容易留在记忆里呢」[rhp]

[:princess:][puri_w kao=1 ]
「这点确实。真奇妙啊」[rhp]

[:kite:][kite kao=11 ]
「下次记得挑我醒着的时候来啊。[rhr]
_　用你的双眼好好见识下我的真实吧」[rhp]

[:princess:][puri_w kao=6 as=on ]
「真是的！你也太随便啦！」[rhp]


; 好感度+10
[eval exp="f.love_k  = f.love_k + 10"]

[eval exp="f.ss_kite = 14"]
[eval exp="f.ss_2nd_kite= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_15
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_01.jpg" time=1000 ]
;****************************************

[winset]

[:kite:][kite kao=13 ]
「♪」[rhp]

[:princess:][puri_w kao=1 ]
「心情不错嘛快斗，发生什么好事了？」[rhp]

[:kite:]
「因为公主来了呀」[rhp]

[:princess:][puri_w kao=4 as=on ]
「！？哈……」[rhp]

[:kite:]
「等得都要睡着了。来，坐旁边吧」[rhp]

[:princess:][puri_w kao=1 ]
「怎、怎么啦？突然这么殷勤」[rhp]

[:kite:]
「待会儿哈蒂要带自制料理过来哦」[rhp]

[:princess:][puri_w kao=2 as=on ss=on ]
「！？　啊、那两个整蛊专家的创意菜……」[rhp]

[:kite:][kite kao=14 ]
「每天每天都来见我们，公主你早就是我们的挚友啦。[rhr]
_　总不会偏偏今天就逃跑吧？」[rhp]

[:princess:][puri_w kao=2 as=on ]
「……。那、那你明天开始要好好陪我聊天哦」[rhp]

[:kite:][kite kao=0 ]
「咦？本来就是这个打算啊」[rhp]

[:princess:][puri_w kao=0 as=on ]
「！」[rhp]
[:princess:]
[font size=13]
「……还以为你会躲开」[rhp]
[resetfont]

[:kite:][kite kao=0 ]
「？」[rhp]

[:princess:][puri_w kao=13 hh=on ]
「没什么……啊、谢谢」[rhp]

[:kite:][kite kao=5 ]
「道谢等我们都活下来再说」[rhp]

[:princess:][puri_w kao=5 as=on ]
「也是……」[rhp]


; 好感度+10
[eval exp="f.love_k  = f.love_k + 10"]


[eval exp="f.ss_kite = 15"]
[eval exp="f.ss_2nd_kite= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_16
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_01.jpg" time=1000 ]
;****************************************

[winset]

[:princess:][puri_w kao=1 ]
「不过最近快斗你真经常醒着呢」[rhp]

[:kite:][kite kao=0 ]
「因为某个家伙天天跑来玩啊。[rhr]
_　继续睡觉反而更麻烦」[rhp]

[:princess:][puri_w kao=13 ]
「又来了～这是害羞了吧」[rhp]

[:kite:][kite kao=2 as=on hh=on ]
「～～～……」[rhp]

[:princess:][puri_w kao=4 as=on ]
「……啊咧？难道真的在掩饰害羞？」[rhp]

[:kite:]
「怎么可能。说什么蠢话」[rhp]
[:kite:][kite kao=12 as=on ]
「嘛别看俺这样其实是店员？开玩笑的。[rhr]
_　总要招待客人嘛」[rhp]

[:princess:][puri_w kao=6 as=on ]
[font color=0x4682b4]
（都忘了快斗是有工作的人……）[rhp]
[resetfont]
[:princess:][puri_w kao=0 as=on ]
「……话说我该不会在快斗店里光看不买吧？[rhr]
_ 要不要买点什么？虽然没钱」[rhp 
[:kite:][kite kao=7 ]
「不用。本就不是这个性质」[rhp]
[:kite:]
「和熟客聊得太投入这种事，[rhr]
_　反而让个人小店显得很难让生客进门对吧」[rhp]

[:princess:][puri_w kao=1 ]
[font color=0x4682b4]
（虽然不太明白……但算是被接纳了吧）[rhp]
[resetfont]
[:princess:][puri_w kao=13 ]
「……嘿嘿！熟客啊～听起来真不错」[rhp]

[:kite:][kite kao=1 ]
「今后也请多关照」[rhp]

[:princess:][puri_w kao=14 ]
「彼此彼此！」[rhp]


; 好感度+10
[eval exp="f.love_k  = f.love_k + 10"]


[eval exp="f.ss_kite = 16"]
[eval exp="f.ss_2nd_kite= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_2nd
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_01.jpg" time=1000 ]
;****************************************

[winset]

[:kite:][kite kao=2 as=on ss=on ]
「……」[rhp]

[:princess:][puri_w kao=2 as=on ]
「快、快斗！你脸色很差怎么了？」」[rhp]

[:kite:]
「……了……」[rhp]

[:princess:]
「？」[rhp]

[:kite:]
「被哈蒂他们看穿了招式……今天已经打烊了」[rhp]

[:princess:]
「这、这样啊……请多保重……」[rhp]


[jump target="*next"]

;---------------------------------------------------------------------------------------------
;---------------------------------------------------------------------------------------------


*next

#
[off_all]

;ev_7への分岐
[if exp="f.ev_a_07 ==1 && f.nigmode == 1"]
[jump storage="ev_a_07.ks" target="*start"]

;ev_6への分岐
[elsif exp="f.ev_a_06 ==1 && f.nigmode == 1"]
[jump storage="ev_a_06.ks" target="*start"]

;ev_3への分岐
[elsif exp="f.ev_a_03 ==1 && f.nigmode == 1"]
[jump storage="ev_a_03.ks" target="*start"]

;ev_2への分岐
[elsif exp="f.ev_a_02 ==1 && f.nigmode == 1"]
[jump storage="ev_a_02.ks" target="*start"]

;夜モードの場合
[elsif exp="f.nigmode == 1"]
[jump storage="ss_main.ks" target="*start"]

;昼モード
[else]
[jump storage="ss_select.ks" target="*select_scene_nig"]
[endif]


