﻿*start

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
;--------------------------------------------------------------------------------------------
;カイト
[voconfig sebuf=1 name=kite vostorage="kite/full/{number}.ogg" number=85]
;ハートシェイプ
[voconfig sebuf=1 name=hati vostorage="hati/full/{number}.ogg" number=52]
;ジェット
[voconfig sebuf=1 name=jet vostorage="jet/full/{number}.ogg" number=41]
;オチアイ（途中まで？？？表記
[voconfig sebuf=1 name=unknown vostorage="otiai/full/{number}.ogg" number=1]
;ヨル
[voconfig sebuf=1 name=yoru vostorage="yoru/full/{number}.ogg" number=28]
;--------------------------------------------------------------------------------------------

;****************************************
[set_00 storage="train_08.jpg"]
;****************************************

[bgm storage="bgm_01.ogg"]

[::]
从海上旅行归来的翌日清晨，[rhr]
比起平常稍微有些寂寞的东西。[rhp]
看似漫长实则短暂的3天假期。[rhr]
那些被潮声唤醒的日子，如今竟让我感到一丝眷恋。[rhp]

[:princess:][puri_w kao=2 ]
「话虽如此，但也不可能永远待在那里啊！」[rhp]

[off_all]

[::]
啪地轻轻拍了拍双颊，切换好心情。[rhr]
简单整理好行装，手扶房门正准备离开。[rhp]
就在那一刻。[rhp]

[se storage="se4_12.ogg"]
[fbgm]

[yurasu]

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
[vostart]
;--------------------------------------------------------------------------------------------

[:kite:]
[font size=27]
『啊―――――！？』[rhp]
[resetfont]

[:princess:][puri_w kao=4 as=on ]
「！？　怎、怎么了？刚才的声音……快斗？」[rhp]

[off_all]

[::]
发出不同寻常的尖叫，到底发生什么事了？[rhp]

[se storage="door_07.ogg"]

我慌忙冲出房间，[rhr]
朝着他常偷懒待着的普通车厢跑去。[rhp]

[se storage="leg_04.ogg"]

;****************************************
;客車
[bg_rule storage="train_01.jpg" rule="002.png" time=500]
;****************************************

[:princess:][puri_w kao=2 as=on ]
「快斗！你怎么……」[rhp]

[off_puri]

[:kite:][kite kao=2 as=on ]
「别开玩笑了你这家伙！　真是的～～～～……！[rhr]
_　从刚才开始你到底想干什么！」[rhp]

[off_all]

[:princess:][puri_w kao=4 as=on ]
「诶……」[rhp]

[bgm storage="bgm_33.ogg"]

;オチアイ登場

[otiai kao=0 ]

[::]
―――快斗的视线前方，站着一名陌生的少年。[rhp]

[:princess:][puri_w kao=4 as=on ]
「…………谁、谁啊！？」[rhp]

[off_all]

[::]
或许是没听见我的声音，这个素不相识的他无视了搭话，[rhr]
将快斗的手推车掀翻后挨个拆开零食包装袋。[rhp]

[chara_part name="kite" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="otiai" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:kite:]
「能不能给我适可而止！[rhr]
_　就算这样也是谋生工具啊！？虽然从来没靠它赚过钱！！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:unknown:]
「………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[::]
陌生的少年完全无视快斗的话语，只顾不断拆开商品，[rhr]
往嘴里塞一个之后，又立刻伸手去拆下一个。[rhp]

[chara_part name="kite" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="otiai" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:kite:]
「喂……快住手！别拆了！[rhr]
_　就算要拆也等吃完手里的再开下一个啊！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:unknown:]
「………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:kite:][kite kao=6 as=on ]
「……～～～呜、宙！！」[rhp]

[off_all]

[::]
被喊到名字时，少年肩膀一抖突然停住动作。[rhp]

[:kite:][kite kao=2 as=on ]
「为什么你会在这里……！？」[rhp]

[off_kite]
;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:unknown:][otiai kao=0 ]
「………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_otiai]

[:kite:][kite kao=6 as=on ]
「完全搞不懂……！那些谜之操作也好，这身打扮也好……！」[rhp]

[off_otiai]

[:princess:][puri_w kao=0 as=on ]
「宙……？」[rhp]

[off_all]

[::]
旁边喊出这个名字的快斗正瞪着这个孩子抱怨着。[rhr]
比起愤怒，更像是陷入了动摇。[rhp]
这就是少年的名字吗？[rhr]
这孩子和快斗是认识的吗？[rhp]
我只能手足无措地旁观着快斗与陌生男孩的互动。[rhr]
片刻后，隔壁车厢传来嘈杂的声响。[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:heartshape:][hati kao=5 ][s_playse storage="hati/51a.ogg" buf=1]
「怎么了怎么了！出事了吗！？」[rhp]

[off_hati]

[:jet:][jet kao=14 ][s_playse storage="jet/40a.ogg" buf=1]
「好像很有意思，让我们也掺和……」[rhp]

[off_jet]


[chara_part name="jet" body=base kao=4 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=4 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[s_playse storage="hati/51b.ogg" buf=1]
[s_playse storage="jet/40b.ogg" buf=2]

[:hutago:]
「！！？？」[rhr]
「！！？？」[rhp]

[off_all]

[::]
迟到的哈蒂君和杰特，[rhr]
大概也是听见快斗的喊声赶过来的吧。[rhp]
然后果然和我一样，看到这幅景象后彻底惊呆了。[rhp]


[:jet:][jet kao=6 ][s_playse storage="jet/40c.ogg" buf=1]
「…………。看起来玩得很开心嘛」[rhp]

[:princess:][puri_w kao=3 as=on ]
「是杰特君的朋友吗？　我也是刚到这里，完全搞不清楚状况―――」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[:unknown:][otiai kao=12 ]
「…………呼――……」[rhp]

[off_otiai]

[::]
咕嘟、咽下最后一口食物，少年终于长舒一口气。[rhp]
接着他突然站起身，猛地冲向车窗边，[rhr]
将车门完全打开后探出身去。[rhp]

;****************************************
[bg storage="train_13.jpg" time=500]
;****************************************

[:unknown:]
[font size=28]
「不是梦――――――啊啊！！」[rhp]
[resetfont]

[::]
方才始终沉默寡言的少年，[rhr]
突然用几乎要震碎玻璃的洪亮声音朝窗外呐喊。[rhp]
这过于突兀的举动让周围的我们全都目瞪口呆，[rhr]
甚至忘记了出声制止。[rhp]
他全然不顾我们，继续呐喊着。[rhp]

[:unknown:]
[font size=28]
「我……！　我会努力的――――！！」[rhp]
[:unknown:]
「谢谢你们――――！！」[rhp]
[resetfont]

;****************************************
#
[bg storage="train_01.jpg" time=500]
;****************************************
;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[chara_part name="jet" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:jet:][s_playse storage="jet/40d.ogg" buf=2]
「那家伙怎么回事？　简直疯了吧……」[rhp]

[:heartshape:][s_playse storage="hati/51c.ogg" buf=1]
「超他妈酷的小鬼啊……！！」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[:unknown:][otiai kao=3 as=on]
「…………！银河铁道……真的……真的存在啊……」[rhp]

[:princess:][puri_w kao=2 as=on ]
「那、那个！」[rhp]

[:unknown:][otiai kao=0 ]
「！」[rhp]

[:princess:][puri_w kao=8 as=on ]
「那样探出身太危险了！快回这边来」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:unknown:][otiai kao=3 ]
「………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:princess:][puri_w ]
「呃……我叫公主。你呢？」[rhp]

[:unknown:][otiai kao=2 as=on ]
「……！啊……？」[rhp]

[:princess:][puri_w kao=13 ]
「啊！刚才好像听见有人叫你宙君」[rhp]
[:princess:]
「初次见面，宙君！嘿嘿，虽然打招呼晚了点……」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:unknown:]
「………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[:kite:][kite kao=3 ]
「切……」[rhp]

[:princess:][puri_w kao=6 ]
「喂快斗。用那种眼神看人可不好哦！」[rhp]

[:kite:]
「会露出这种眼神也是理所当然吧。为什么那家伙会在这里……」[rhp]

[off_all]

[chara_part name="kite" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=1 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「话说你们俩认识……对吧？」[rhp]

[:kite:][kite kao=2 ]
「不对。我才不认识这种家伙。[rhr]
_　如果你是真的宙，那这幅模样根本不可能存在」[rhp]
[:kite:]
「那家伙是宙的冒牌货」[rhp]

[off_all]

[chara_part name="kite" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="otiai" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:unknown:]
「……哼。冒牌货？说我？」[rhp]

[:kite:]
「肯定是南干的好事吧？那家伙绝对做得出来。[rhr]
_　说什么为了我们，净是多管闲事」[rhp]

;--------------------------------------------------------------------------------------------
; カイトフルボイスここまで
; ジェットフルボイス一旦終了
;--------------------------------------------------------------------------------------------
;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:unknown:]
「―――……不管谁说什么，我都是真正的落合宙」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[off_all]

[chara_part name="jet" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:]
「落合宙？杰特你认识吗」[rhp]

[:jet:][p_j_17]
「没听说过啊……」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▼再開▼
;オチアイ名前表記変更後
[voconfig sebuf=1 name=otiai vostorage="otiai/full/{number}.ogg" number=10]
[vostart]
;------------------------------------------------------------------------------------------

[chara_part name="jet" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="otiai" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="760" top="0" wait="true" time=150]

[:otiai:]
「……所以？你们俩又是谁？」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:heartshape:][hati kao=5 as=on ]
「！！我、我是哈托谢普！」[rhp]

[:jet:][jet kao=12 ]
「……，我是杰特」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:otiai:][otiai kao=12 ]
「白发的是哈托谢普，红发的是杰特呢。[rhr]
_　明白了，请多指教」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:heartshape:][p_h_02][hati kao=14 ]
「噢！请多指教！」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:otiai:][otiai kao=8 as=on ]
「真是活力过头了……不过倒也无所谓」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:jet:][p_j_05][jet kao=6 ]
「…………」[rhp]

[off_all]

[:princess:][puri_w ]
「那个……请问！落合君是今天来这里的吗？[rhr]
_　完全没注意到你也上车了」[rhp]

[:otiai:][otiai kao=3 ]
「………………」[rhp]

[:princess:][puri_w kao=3 ]
「既然来到这里……说明你已经死了吧」[rhp]
[:princess:][puri_w kao=1 ]
「死亡虽然令人悲伤，但在这里就不用担心了。[rhr]
_　因为这里可是梦境与魔法的银河铁道啊！」[rhp]

[off_all]

[::]
―――话音刚落就立刻后悔了。[rhp]
正常情况下，不会这么快接受死亡吧。[rhr]
尤其还是这么小的孩子。[rhp]
连失去的是什么都不知道[rhr]
连悲伤都做不到的我是特别的。[rhp]
怎么办啊，该不会被第一印象就讨厌了吧……[rhp]

[off_all]

[:kite:][p_k_05][kite kao=2 ]
「究竟要犯多蠢的错才会沦落到这里。简直无语到说不出话」[rhp]

[:princess:][puri_w kao=2 as=on ]
「快、快斗你怎么这样说！太失礼了！」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:otiai:][otiai kao=7 ]
「无所谓啦。快……」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[off_all]

[chara_part name="kite" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="otiai" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:kite:][kite kao=2 ]
「是快斗。别叫错啊」[rhp]

[:otiai:][otiai kao=7 ]
「……………………」[rhp]

[:princess:][puri_w kao=0 as=on ]
[font color=0x4682b4]
（……？我记得刚才没叫错啊）[rhp]
[resetfont]

[off_puri]

[:otiai:][otiai kao=6 as=on ]
「………………」[rhp]

[off_otiai]

[:kite:][p_k_05][kite kao=3 ]
「………………」[rhp]

[off_kite]

[chara_part name="jet" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:jet:][p_j_12]
「好尴尬……」[rhp]

[:heartshape:][p_h_17]
「这种氛围我最应付不来了……」[rhp]

[off_all]

[::]
完全同意。这种紧绷的氛围让人窒息。[rhr]
无论说什么都会冷场，甚至有种根本不该开口的感觉。[rhp]
虽然想为夹在中间的两人调解[rhr]
却找不到缓解局面的合适话语……[rhp]
…………偏偏这种时候，可靠的多洛普就是不出现！[rhp]

[:princess:][puri_w kao=13 as=on ]
「那、那个，我说」[rhp]

[off_puri]

[::]
好不容易挤出来的话[rhr]
被落合君的叹息打断了。[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[chara_part name="kite" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="otiai" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:otiai:]
「……快斗会慌乱也不是不能理解」[rhp]
[:otiai:]
「不过既然来了也没办法吧。[rhr]
_　暂时要受你照顾了。请多指教」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:kite:][p_k_05]
「………………切」[rhp]

[off_all]

[:princess:][puri_w kao=2 as=on ]
[font color=0x4682b4]
（……快斗的态度很奇怪。对朋友来说这态度也太恶劣了吧……[rhr]
_　年龄看起来也相差不少）[rhp]
[:princess:]
（落合君，你到底是什么人……？）[rhp]
[resetfont]

[off_puri]

[:drop:][p_d_21][drop kao=2 as=on ]
「快斗先生！刚才的大喊是怎么回事？发生紧急状况了吗―――」[rhp]

[off_drop]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:otiai:][otiai kao=4 as=on ]
「……！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[off_otiai]

[:drop:][p_d_19][drop kao=4 as=on ]
「诶……你是」[rhp]

[off_all]

[chara_part name="jet" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:]
「多洛普！你总算来了！」[rhp]

[:jet:]
「太慢了多洛普。快想办法处理这些家伙」[rhp]

[off_all]

[:drop:][drop kao=4 as=on ]
「…………、…………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:otiai:][otiai kao=7 ]
「…………初次见面」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:drop:][drop kao=1 as=on ]
「……！啊、啊啊！初次见面！我是车长多洛普」[rhp]
[:drop:][drop kao=13 as=on ]
「…………很荣幸见到您」[rhp]

[:princess:][puri_w kao=0 ]
「多洛普，难道你认识落合君吗？」[rhp]

[:drop:][p_d_02][drop kao=14 ]
「当然。车长就该掌握乘客的一切情报！[rhr]
_　电影喜好、漫画喜好、音乐喜好，全都了如指掌！」[rhp]

[off_all]

[chara_part name="jet" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:][p_h_01]
「太可靠了！我们也得学着点啊，杰特！」[rhp]

[:jet:][p_j_17]
「话说做到这种程度反而有点恶心吧……[rhr]
_　只要哈蒂没意见就好」[rhp]

[off_all]

[chara_part name="otiai" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="drop" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:otiai:]
「……你，被称作多洛普啊」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:drop:][p_d_02][drop kao=13 ]
「是的！请多关照」[rhp]

[:otiai:][otiai kao=2 ]
「……………………」[rhp]

[off_all]

[:kite:][p_k_04][kite kao=2 ]
「所以？差不多该说实话了吧。[rhr]
_　如果你是真货宙，为什么要来到这里」[rhp]
[:kite:]
「……不，应该说为什么已经死了」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:otiai:][otiai kao=12 ]
「没死」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[off_all]

[chara_part name="kite" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="otiai" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:kite:][p_k_10]
「……！」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:otiai:]
「我没死。是活着来到这个世界的」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:kite:][p_k_13][kite kao=4 as=on ]
「诶……」[rhp]

[off_all]

[:heartshape:][hati kao=2 as=on ]
「…………这家伙，认真的吗」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:otiai:][otiai kao=3 ]
「………听说这里有银河铁道，就让人带我过来了」[rhp]
[:otiai:]
[se storage="se8_09.ogg" buf=2]
「■■■的缘、故……」[rhp]
[:otiai:][otiai kao=2 as=on ]
「…………啊？」[rhp]

[off_all]

[::]
途中话语像杂音般中断，[rhr]
完全听不清说了什么。[rhp]
最震惊的当属落合君，[rhr]
他试图重复刚才的话……却在相同地方再次卡壳。[rhp]
一通尝试后似乎心满意足的落合君，长叹了一口气。[rhp]

[:otiai:][otiai kao=3 ]
「…………，倒也无所谓」[rhp]

[fbgm]

[:princess:][puri_w kao=2 as=on ]
「等等落合君。刚才那话什么意思？活着什么的……」[rhp]

[:otiai:][otiai kao=2 ]
「字面意思。我现在——」[rhp]

[off_all]


[:heartshape:]
[font size=30]
「滚回去！！」[rhp]
[resetfont]

[off_all]

[bgm storage="bgm_08.ogg"]

[::]
发出这声怒吼的[rhr]
居然是此前和我一样茫然的哈蒂君。[rhp]

[chara_part name="otiai" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:otiai:]
「…………什么啊？你」[rhp]

[:heartshape:]
「滚回落合。这不是你该待的地方」[rhp]

[:otiai:][otiai kao=2 ]
「听不懂。虽然不认识你，但这与你无关吧」[rhp]

[:heartshape:]
「有关！你根本不明白！你现在做的——」[rhp]

[off_all]

[:jet:][jet kao=7 ]
「也没什么不好吧」[rhp]

[off_all]

[:heartshape:][hati kao=4 as=on ]
「！」[rhp]

[off_all]

[::]
出言反驳哈蒂君的是杰特君。[rhp]
至今都支持哈蒂君意见的[rhr]
一次都不曾否定过的那位杰特君。[rhp]
他以甚至让人感到冷淡的态度，对哈蒂君淡淡地说道。[rhp]

[chara_part name="jet" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:jet:]
「说到底要是知道回去的方法的话，[rhr]
_　来到这里的家伙们早就全都那么做了吧」[rhp]
[:jet:]
「乘车的那一刻就是落合的败北。挣扎也只是徒劳呢」[rhp]

[:heartshape:]
「杰特……！你清楚自己在说什么吗！？」[rhp]

[:jet:][jet kao=2 ]
「很清楚哦。……难道我说错什么了吗？全都是事实吧」[rhp]

[:heartshape:]
「我说啊！这种事情怎么能用那种话就轻描淡写地——」[rhp]


;------------------------------------------------------------------------------------------
;▲一時停止▲
;双子ここまで
[vostop]
;------------------------------------------------------------------------------------------

[off_all]

[:drop:][drop kao=6 as=on ]
「好啦好啦好啦好啦！」[rhp]

[off_all]

[::]
在多洛普用一贯的困扰表情插进即将激化的两人之间，[rhr]
阻止了他们的争吵。[rhp]

[chara_part name="jet" body=base kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="drop" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="760" top="0" wait="true" time=150]

[:drop:]
「确实如哈托谢普所说，[rhr]
_　如果还活着的话应该回去才对」[rhp]
[:drop:]
「但话说回来，现在在场有谁知道回去的方法吗？」[rhp]

[:heartshape:][hati kao=8 as=on ]
「那、那是……」[rhp]

[:jet:][p_j_04][jet kao=12 ]
「看吧。感情用事根本解决不了问题」[rhp]

[:heartshape:][p_h_12][hati kao=2 as=on ]
「你这家伙……！」[rhp]

[:drop:][p_d_04][drop ]
「那么这样吧。在落合留在这里的期间，[rhr]
_　由我们来帮他寻找回去的方法如何？」[rhp]
[:drop:]
「在此期间可以尽情享受这个地方直到满意为止。[rhr]
_　我觉得在充分享受这个世界后再回去也不错」[rhp]

[off_all]

[chara_part name="otiai" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="drop" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:drop:]
「怎么样？落合」[rhp]

[:otiai:]
「………………」[rhp]

[:drop:][p_d_32][drop kao=5 as=on ]
「哎呀呀……我这是被讨厌了吗」[rhp]

[off_all]

[:princess:][puri_w ]
「我觉得多洛普的方案最合适。[rhr]
_　就算说要回去，现在也没法把人赶走」[rhp]
[:princess:][[puri kao=13 ]
「暂时一起待在这儿吧。好吗，落合君！」[rhp]

[:otiai:][otiai kao=3 ]
「………………」[rhp]

[off_all]

[:quadrillion:][p_r_18][riri kao=0 ]
「啊——麻烦的家伙又增加了呢」[rhp]

[:drop:][drop kao=2 ]
「夸德里利昂！太慢了。[rhr]
_　都闹成这样了，你跑去哪里做什么了啊」[rhp]

[:quadrillion:][p_r_31][riri kao=13 ]
「化妆～」[rhp]
[:quadrillion:][riri kao=5 ]
「嘛，虽然听到不少传言。不过无所谓吧？[rhr]
_　现阶段我觉得多洛普的提议最合理」[rhp]

[off_all]

[chara_part name="otiai" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="riri" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:quadrillion:]
「可别给旁人添太多麻烦。[rhr]
_　还有要尊敬年长者」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:otiai:][otiai kao=6 as=on ]
「…………明白了」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:quadrillion:][p_r_19][riri kao=5 ]
「哎呀，没想到是个挺懂事的臭小鬼嘛」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:otiai:][otiai kao=3 ]
「……没什么。可能我也有点钻牛角尖了」[rhp]

[off_all]

[chara_part name="otiai" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:otiai:]
「抱歉……快斗。话说重了」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:kite:][p_k_05]
「………………」[rhp]

[off_all]

[:princess:][puri_w kao=6 as=on ]
「……快斗……」[rhp]

[off_all]

[::]
为什么唯独快斗对落合君如此敌对呢。[rhp]
或许和生前的某些事有关……？[rhr]
不过要直接问出口果然还是需要勇气的……[rhp]

就在我思考这些时，[rhr]
当事人落合君面对快斗的态度，只是轻轻发出鼻音笑了笑。[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:otiai:][otiai kao=5 ]
「倒也无所谓。反正我也没指望被所有人喜欢」[rhp]
[:otiai:]
「……嘛，总之……今后请多指教」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[off_all]

[::]
落合君朝众人轻轻点头致意。[rhr]
神情困惑的众人中，唯有多洛普满意地微笑着。[rhp]

[chara_part name="jet" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=8 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:]
「……那、那个。杰特……」[rhp]

[:jet:][p_j_34][jet kao=12 ]
「抱歉啊哈蒂。刚才是我太不成熟了」[rhp]

[:heartshape:][hati kao=4 as=on ]
「―――！　欸……啊，没有」[rhp]

[:jet:][p_j_05][jet kao=3 ]
「哈蒂真是个好家伙。[rhr]
_　我明明想成为你这样的人，结果又搞砸了」[rhp]
[:jet:]
「……讨厌我了吗？这样的我」[rhp]

[:heartshape:][p_h_32][hati kao=5 as=on ]
「啊……啊啊不是！完全没有！？我压根没在意这种事啦！」[rhp]
[:heartshape:]
「我也正打算为突然吼你的事道歉呢！[rhr]
_　我也想和你一样永远保持冷静的啊！」[rhp]

[:jet:][p_j_32][jet kao=1 ]
「哈蒂……谢谢」[rhp]

[:heartshape:][p_h_31][hati kao=14 ]
「既然多洛普都那么说了，落合的事就算了吧！[rhr]
_ 今后我们绝无二话全盘接受！这才是男子汉对吧杰特！」[rhp]

[:jet:][p_j_02][jet kao=14 hh=on ]
「啊，说得对。果然哈蒂是世界第一的男子汉啊！」[rhp]
[:jet:]
「那这次就当冲突未遂吧」[rhp]

[:heartshape:][p_h_31][hati kao=14 hh=on ]
「嘿嘿……！噢！打架根本不符合我们的风格嘛！」[rhp]

[off_all]

[:otiai:][otiai kao=6 as=on ]
「………………」[rhp]

[:princess:][puri_w kao=13 ]
「呵呵！那两人真有趣呢。[rhr]
_　因为长得特别像，所以关系很好哦」[rhp]
[:princess:]
「和其他人相比，落合君的年龄似乎也更接近，[rhr]
_　能好好相处就好了呢」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:otiai:][otiai kao=7 ]
「……无所谓……反正不认识的人，怎样都行」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------
[off_all]

[::]
落合君唰地扭过头，一动不动地望着窗外。[rhr]
他凝视着远方，仿佛已经听不见我的声音。[rhp]

[:princess:][puri_w kao=0 ]
[font color=0x4682b4]
（总觉得是个奇怪的孩子啊……[rhr]
_　而且，明明还活着却说来到这个世界这件事的意思也很在意）[rhp]
[:princess:]
（……到底是怎么回事呢……？）[rhp]
[resetfont]

[off_all]

[::]
要说可能知道这件事的人……南之类的？[rhr]
毕竟，他是赞助人嘛。[rhp]
下次见面的话，试着问问落合君的事吧……[rhp]

;****************************************
[fbgm]
;****************************************

[bgm storage="bgm_08.ogg"]

[::]
至于之后的落合君，则继续在客车里默默阅读着从快斗那里得到的……[rhr]
不，是抢夺来的大量书籍。[rhp]
除此之外没有特别的变化，时间就这么静静流逝。[rhp]

[:princess:][puri_w kao=6 ]
「嗯～～～～～～……」[rhp]

[off_all]

[::]
我藏在尾部座位的阴影处，守望着这副景象。[rhp]
不，我又没做坏事，其实没必要躲藏。[rhr]
但被发现了总觉得很尴尬……[rhp]

[:drop:][p_d_35][drop kao=0 ]
「您怎么了？公主」[rhp]

[:princess:][puri_w kao=6 ]
「啊，多洛普。……没什么，就是在想落合君的事」[rhp]
[:princess:]
「我在想有没有办法和大家搞好关系呢。[rhr]
_　难得有机会，希望你能多和大家聊聊天什么的」[rhp]

[:drop:][p_d_31][drop ]
「这份心意很棒。落合可是你的后辈乘客呢」[rhp]

[:princess:][puri_w kao=5 ]
「后辈……！对啊，确实是这么回事呢。[rhr]
_　那我更得多教教落合君才行！」[rhp]
[:princess:][puri_w kao=14 ]
「―――于是决定用这种方式找话题搭话！！」[rhp]

[:drop:][p_d_08][drop kao=13 ]
「这样很好。他一定会很高兴的」[rhp]

[:princess:][puri_w kao=13 ]
「呵呵，我好像有点明白佩奇[rhr]
_　想照顾我的心情了」[rhp]
[:princess:]
「那我这就去打个招呼！」[rhp]

[off_all]

[::]
我小跑离开时，多洛普在身后挥手道别。[rhp]
―――来到落合君就坐的座位前，[rhr]
我清了清嗓子下定决心。[rhp]

;****************************************
;スチル
[still storage="cg/a_04_1.png" rule="021.png" width="1280" height="720" time=1000]
[cg storage="cg/a_04_1.png"]
;****************************************

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:princess:]
「落、落合君！你好啊！」[rhp]

[:otiai:]
「干嘛。突然的」[rhp]

[:princess:]
「我在想叫你什么好呢——[rhr]
_　看书虽好，要不要和大家玩玩？就当联谊会！」[rhp]

[:otiai:]
「……你觉得我是个无趣的家伙吧」[rhp]

[:princess:]
「哎！？没没没，我不是这个意思」[rhp]

[:otiai:]
「倒也不是故意躲着大家」[rhp]
[:otiai:]
「……只是…………总觉得不自在」[rhp]

[:princess:]
「？　我很冷静啊？落合君。[rhr]
_　冷静得过分了」[rhp]

[:otiai:]
「…………我读书就是为了这个」[rhp]
[:otiai:]
「因为没想到真的存在这样的世界。[rhr]
_　紧张感啊心跳加速啊，这些情绪好不容易才平复下来」[rhp]

[:princess:]
「落合君……！」[rhp]

[:otiai:]
「干、干嘛」[rhp]

[:princess:]
「没什么，太好了！我还以为你会一直不高兴呢」[rhp]
[:princess:]
「我们会互相帮助的。[rhr]
_　在找到回去的方法之前，今后请多关照啦！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:otiai:]
「…………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:otiai:][font size=15]
「…………………话说我根本没打算回去」[rhp]
[resetfont]

[:princess:]
「？你说什么？」[rhp]

[:otiai:]
「没什么」[rhp]

[::]
简短说完后，落合君合上了书本。[rhp]

;****************************************
;スチル終了
[still_end frame="win.png" storage="train_02.jpg" rule="021.png" time=1000]
;****************************************

[:otiai:][otiai kao=12 ]
「该做什么好」[rhp]

[:princess:][puri_w kao=0 ]
「诶……什么该做什么？」[rhp]

[:otiai:][otiai kao=6 ]
「就是问你……除了看书之外，在这里还能干什么」[rhp]

[:princess:][puri_w kao=4 as=on hh=on ]
「――――！那、那个啊！换成我的话会和大家聊天、[rhr]
_　帮多洛普干活、或者看看星星什么的吧」[rhp]

[:otiai:][otiai kao=7 ]
「……那些，可以一起做吗」[rhp]

[:princess:][puri_w kao=14 hh=on ]
「当然！热烈欢迎啊，落合君！」[rhp]

[:otiai:][otiai kao=12 ]
「……谢谢」[rhp]

[off_all]

[::]
落合君有着与年龄不符的成熟感。[rhr]
而且不知为何，让人感到莫名怀念。[rhp]

[:princess:]
[font color=0x4682b4]
（不知为何。我总觉得认识这孩子）[rhp]
[resetfont]

[::]
我、落合君、曾经在什么地方……？[rhp]

;****************************************
[fbgm]
[s_mask time=2000]
[wait time=1000]
[bg storage="black.jpg" time=100]
[s_mask_off time=3000]
;****************************************

[::]
――――那里是漆黑的异次元。[rhp]
隔绝星光闪烁的夹缝之暗。[rhp]
有人从那里眺望着穿梭于浩瀚银河的铁道。[rhp]

[:yoru:]
「……真的可以信任吗」[rhp]

;****************************************
#
[bg storage="sky_12.jpg" time=1000]
;****************************************

―――――糠星夜。[rhp]
被称作「夜」的那个男人，不悦地叹了口气。[rhp]

[:yoru:]
「宙……因为你说无论如何都要这样，我才尝试采取了这种形式」[rhp]
[:yoru:]
「……果然……还是不能交给你……」[rhp]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
[s_mask time=3000]
;****************************************

#
[eval exp="f.ev_a_04 = 1"]

[jump storage="ev_a_05.ks" target=*start]

[s]


