﻿
*start

[jump target="*ss_2nd" cond="f.nigmode == 1 && ss_2nd_hati == 1"]
[jump target="*ss_16" cond="f.ss_hati >= 15"]
[jump target="*ss_15" cond="f.ss_hati >= 14"]
[jump target="*ss_14" cond="f.ss_hati >= 13"]
[jump target="*ss_13" cond="f.ss_hati >= 12"]
[jump target="*ss_12" cond="f.ss_hati >= 11"]
[jump target="*ss_11" cond="f.ss_hati >= 10"]
[jump target="*ss_10" cond="f.ss_hati >= 9"]
[jump target="*ss_09" cond="f.ss_hati >= 8"]
[jump target="*ss_08" cond="f.ss_hati >= 7"]
[jump target="*ss_07" cond="f.ss_hati >= 6"]
[jump target="*ss_06" cond="f.ss_hati >= 5"]
[jump target="*ss_05" cond="f.ss_hati >= 4"]
[jump target="*ss_04" cond="f.ss_hati >= 3"]
[jump target="*ss_03" cond="f.ss_hati >= 2"]
[jump target="*ss_02" cond="f.ss_hati >= 1"]
[jump target="*ss_01"]

;---------------------------------------------------------------------------------------------
*ss_01
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_04.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_31.ogg"]

[:princess:][puri_w kao=1]
「你好ー」[rhp]

[:heartshape:][hati kao=1 ]
「来了啊，大浪！！」[rhp]

[:jet:][jet kao=1 ]
「有何贵干？」[rhp]

[:princess:][puri_w kao=1]
「闲着也是闲着，机会难得和大家聊聊―――」[rhp]

[:heartshape:][hati kao=2 ]
「闲着！！！？？　？」[rhp]

[:princess:][puri_w kao=2 as=on ]
「！？」[rhp]

[:heartshape:][hati kao=6 as=on ]
「开什么玩笑！　在这条特殊铁道上怎么可能无聊！」[rhp]
[:heartshape:][hati kao=13 ]
「好嘞！　为了让公主开怀大笑，[rhr]
_　咱们去检修车厢吧杰特！」[rhp]

[:jet:][jet kao=11 ]
「既然是哈蒂说的」[rhp]

[:princess:]
「诶！　稍等……」[rhp]

[off_all]

[:jet:][jet kao=14 ]
「那回头见！」[rhp]

[off_all]

[::]
跑着离开了……[rhp]

[off_all]

; 好感度+10
[eval exp="f.love_h  = f.love_h + 10"]

[eval exp="f.ss_hati = 1"]
[eval exp="f.ss_2nd_hati = 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_02
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_04.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_31.ogg"]

[:princess:][puri_w kao=1]
「你好，」[rhp]

[:heartshape:][hati kao=5 ]
「怎么样！？」[rhp]

[:princess:][puri_w kao=2 as=on ]
「啊、什么？」[rhp]

[off_hati]

[chara_part name="jet" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:]
「就是前阵子准备的惊喜啊！」[rhp]

[:jet:][jet kao=1 ]
「打开包间门时不是有大量亮片洒下来吗」[rhp]

[:heartshape:][hati kao=1 ]
「因为你说无聊嘛！　感觉如何！？」[rhp]

[:princess:][puri_w kao=12 as=on ]
「啊……那个啊。唔……[rhr]
_　闪闪发亮的很漂亮，不过要从身上彻底弄干净可真够呛」[rhp]

[:heartshape:][hati kao=5 ]
「六十分左右吧！！　还有进步空间啊杰特！」[rhp]

[:jet:][jet kao=13 ]
「哈蒂说是那就是吧」[rhp]

[:princess:][puri_w kao=2 as=on ]
「够了！　别再搞那种事了！」[rhp]

[off_all]

; 好感度+10
[eval exp="f.love_h  = f.love_h + 10"]

[eval exp="f.ss_hati = 2"]
[eval exp="f.ss_2nd_hati= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_03
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_04.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_31.ogg"]

[:princess:][puri_w kao=13 ]
「D～是甜甜圈～的D～」[rhp]
[:princess:]
「啦～哈」[rhp]

[:heartshape:][hati kao=5 ]
[font size=25]
「传说的LEG！！！！」[rhp]
[resetfont]

[:princess:][puri_w kao=2 as=on ]
「哇啊！！」[rhp]

[off_all]

[:heartshape:][hati kao=1 ]
「公主！打扰你一个人唱卡拉OK真是不好意思啊！」[rhp]

[off_all]

[:jet:][jet kao=11 ]
「下次记得悄悄搞。拜啦」[rhp]

[off_all]

[:princess:][puri_w kao=2 as=on hh=on ]
「居、居然被听到了……好丢脸……！！」[rhp]

[off_all]

; 好感度+10
[eval exp="f.love_h  = f.love_h + 10"]

[eval exp="f.ss_hati = 3"]
[eval exp="f.ss_2nd_hati= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_04
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_04.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_31.ogg"]

[:princess:][puri_w kao=14 ]
「某～天♪森林里♪」[rhp]
[:princess:]
「遇见了♪熊先生♪」[rhp]

[off_all]

[:heartshape:][hati kao=2 as=on ]
[font size=30]
「快逃啊啊啊啊！！！」[rhp]
[resetfont]

[off_all]

[:princess:][puri_w kao=2 as=on ss=on ]
「呀！！」[rhp]

[:heartshape:][hati kao=2 as=on ]
「告诉我吧公主！[rhr]
_　遇到熊先生的家伙……！会怎样……！？」[rhp]

[:princess:][puri_w kao=6 as=on ]
「在、在花绽森林的小路上被追赶……」[rhp]

[:heartshape:]
「致死吗！！」[rhp]

[:jet:][jet kao=5 ]
「尝过人味的熊据说很危险。[rhr]
_　花绽森林的养分到底是什么啊……」[rhp]

[:princess:][puri_w kao=2 as=on ]
「真是的！听人说话啦！」[rhp]

[off_all]

; 好感度+10
[eval exp="f.love_h  = f.love_h + 10"]

[eval exp="f.ss_hati = 4"]
[eval exp="f.ss_2nd_hati= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_05
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_04.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_31.ogg"]

[:princess:][puri_w kao=2]
「两位。关于前几天那首歌」[rhp]

[chara_part name="jet" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:]
「嗯？歌？」[rhp]

[:jet:]
「就是熊先生的」[rhp]

[:princess:]
「如果熊先生吃人的话，[rhr]
_　被杀的人类不可能变成森林养分才对……」[rhp]
[:princess:]
「也就是说杰特君的说法自相矛盾！！[rhr]
_　那明明是一首可可爱爱的歌！」[rhp]

[:jet:][jet kao=6 as=on ]
「这样啊……」[rhp]

[:heartshape:][hati kao=13 as=on ]
「没想到还挺记仇的类型嘛！」[rhp]

[:princess:][puri_w kao=5 hh=on ]
「哼哼！　看招」[rhp]

[off_all]

; 好感度+10
[eval exp="f.love_h  = f.love_h + 10"]

[eval exp="f.ss_hati = 5"]
[eval exp="f.ss_2nd_hati= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_06
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_04.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_31.ogg"]

[:princess:][puri_w kao=1]
「你好呀～」[rhp]

[:heartshape:][hati kao=1 ]
「公主！　来得正是时候！」[rhp]
[:heartshape:]
「现在开始要在你房间，打开门就会不断膨胀的气球」[rhp]

[off_all]

[:jet:][jet kao=6 as=on ]
「啊笨蛋！　哈蒂！！」[rhp]

[off_all]

[chara_part name="hati" body=base kao=13 as=on ss=off hh=off hr=on hat=okan ]
[chara_show name="hati" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=2 as=on ss=off hh=off hr=on]
[chara_show name="puri_w" layer="message0" left="1" top="1" width="330" height="720" wait="true" zindex="1005" time=150]

[:heartshape:][hati kao=5 as=on ]
「……虽然我不想去设置机关，但怎么办？」[rhp]

[:princess:][puri_w kao=2 as=on ]
「就、就这样维持原状就好……」[rhp]

[off_all]

[chara_part name="jet" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:hutago:]
「…………」[rhr]
「…………」[rhp]

[off_all]

[:princess:]
[font color=0x4682b4]
（虽然不太明白但危机解除了……）[rhp]
[resetfont]

; 好感度+10
[eval exp="f.love_h  = f.love_h + 10"]

[eval exp="f.ss_hati = 6"]
[eval exp="f.ss_2nd_hati= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_07
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_04.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_31.ogg"]

[:princess:][puri_w kao=1 ]
「你好！」[rhp]

[:jet:][jet kao=1 ]
「哟公主。来得正好啊」[rhp]

[:princess:][puri_w kao=2 ]
「又在策划什么恶作剧……？」[rhp]

[:jet:][jet kao=13 ]
「哈哈哈。怎么会呢，」[rhp]

[off_all]

[:heartshape:][hati kao=2 as=on ]
「白痴杰特！　包间的小龙虾[rhr]
_　换成龙虾的事不准说出来啊！！」[rhp]

[:jet:][jet kao=2 as=on ]
「你这家伙！　自己说漏嘴要怎么办！」[rhp]

[off_all]

[:princess:][puri_w kao=2 as=on ss=on ]
[font color=0x4682b4]
（诶……？说起来根本不记得包间有过小龙虾啊……）[rhp]
[resetfont]

[off_all]

; 好感度+10
[eval exp="f.love_h  = f.love_h + 10"]

[eval exp="f.ss_hati = 7"]
[eval exp="f.ss_2nd_hati= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_08
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_04.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_31.ogg"]

[:heartshape:][hati kao=1 ]
「公主你啊，总是不厌其烦来我们这儿呢」[rhp]

[:princess:][puri_w kao=1]
「因为总归很有趣嘛。[rhr]
_　虽然抽屉里有龙虾确实吓一跳」[rhp]

[:jet:][jet kao=1 ]
「哈蒂你看起来也玩得很嗨嘛。[rhr]
_　恶作剧功力见长啊」[rhp]

[:heartshape:][hati kao=1 ]
「要说这个杰特才是活力四射呢！」[rhp]

[:heartshape:][hati kao=1 ]
「不愧是公主。[rhr]
_　光是存在就能给予他人活力的特殊能力……！　真厉害啊！」[rhp]

[:jet:][jet kao=11 as=on ]
「那个好像有点不对……」[rhp]

[:princess:][puri_w kao=13]
「欸嘿嘿……真是的，哈蒂君太夸张啦！虽然并不讨厌」[rhp]

[:jet:][jet kao=1 ]
「……嘛，本人觉得好就行」[rhp]

[off_all]

; 好感度+10
[eval exp="f.love_h  = f.love_h + 10"]

[eval exp="f.ss_hati = 8"]
[eval exp="f.ss_2nd_hati= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_09
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_04.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_31.ogg"]

[chara_part name="jet" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:]
「公主！来得正好！」[rhp]
[:heartshape:]
「你有啥喜欢的食物不？」[rhp]

[:jet:]
「什么都能给你整来」[rhp]

[:princess:][puri_w kao=0 ]
「这、这突然吹的什么风……？」[rhp]

[:heartshape:][hati kao=13 ]
「是爱啊！！」[rhp]

[:jet:][jet kao=11 ]
「因为你总来串门嘛。[rhr]
_　哈蒂说想用数量表达平日的感谢」[rhp]

[:princess:][puri_w kao=2 as=on ]
「数量……？」[rhp]

[:heartshape:][hati kao=5 ]
「要大份还是多份！？」[rhp]

[:princess:][puri_w kao=13 as=on ]
「……我、我考虑下……」[rhr]
[font color=0x4682b4]
（只有不祥的预感……！！）[rhp]
[resetfont]

[off_all]

; 好感度+10
[eval exp="f.love_h  = f.love_h + 10"]

[eval exp="f.ss_hati = 9"]
[eval exp="f.ss_2nd_hati= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_10
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_04.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_31.ogg"]

[chara_part name="jet" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:]
「落合合也挺坏心眼啊……！」[rhp]

[:princess:][puri_w kao=6 ]
「？」[rhp]

[:heartshape:]
「咯咯咯……！」[rhp]

[:jet:]
「他说这样叫比较顺口」[rhp]

[:heartshape:][hati kao=14 ]
「很有时代剧的感觉吧！」[rhp]

[:princess:][puri_w kao=2 as=on ]
「？？」[rhp]

[:jet:][jet kao=13 as=on ]
「啊，把落合叫成落合合这事要保密哦」[rhp]

[:princess:][puri_w kao=5 as=on ]
「会被骂的啦」[rhp]

[off_all]

; 好感度+10
[eval exp="f.love_h  = f.love_h + 10"]

[eval exp="f.ss_hati = 10"]
[eval exp="f.ss_2nd_hati= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_11
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_04.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_31.ogg"]

[:princess:][puri_w kao=1]
「你好ー」[rhp]

[:heartshape:][hati kao=1 ]
「噢！公主来啦，你好呀！」[rhp]

[:princess:][puri_w kao=1]
「咦？杰特君不在吗？」[rhp]

[:heartshape:][hati kao=1 ]
「那家伙正在说教。[rhr]
_　克林那什么化妆品被换成芥末了啦」[rhp]

[:princess:][puri_w kao=13 as=on ]
「真是无聊的魔法呢」[rhp]

[:heartshape:][hati kao=1 ]
「不，那家伙的魔法由我负责 所以他亲手干的」[rhp]

[:princess:][puri_w kao=2 as=on ]
「诶……」[rhp]

[:heartshape:][hati kao=11 ]
「我可是精心调包了的！」[rhp]

[off_all]

; 好感度+10
[eval exp="f.love_h  = f.love_h + 10"]

[eval exp="f.ss_hati = 11"]
[eval exp="f.ss_2nd_hati= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_12
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_04.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_31.ogg"]

[:princess:][puri_w kao=1]
「你好ー」[rhp]

[:jet:][jet kao=1 ]
「哟。是公主啊」[rhp]

[:princess:][puri_w kao=0 ]
「咦？哈蒂君呢？」[rhp]

[:jet:][jet kao=12 ]
「那家伙不在。在你房间里放了大批……」[rhp]
[:jet:][jet kao=6 ]
「……还是算了吧」[rhp]

[:princess:][puri_w kao=2 as=on ss=on ]
「我在意啊！大批的什么！？」[rhp]

[:jet:][jet kao=13 ]
「秘密。回房间自己惊讶吧」[rhp]

[:princess:][puri_w kao=8 as=on ]
「真是～……哈蒂君这孩子 真是一刻都不能松懈呢」[rhp]
[:princess:][puri_w kao=2 as=on ]
「下次要提前三十分钟行动 紧紧跟着哈蒂君才行！」[rhp]

[:jet:][jet kao=11 as=on ]
[font color=0x4682b4]
（半斤八两啊……）[rhp]
[resetfont]

[off_all]

; 好感度+10
[eval exp="f.love_h  = f.love_h + 10"]

[eval exp="f.ss_hati = 12"]
[eval exp="f.ss_2nd_hati= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_13
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_04.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_31.ogg"]

[:princess:][puri_w kao=1]
「有件事我挺在意的」[rhp]
[:princess:][puri_w kao=1]
「结果你们俩是双胞胎？还是兄弟……[rhr]
_　总不可能是撞脸吧」[rhp]

[chara_part name="jet" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:jet:]
「是双胞胎啦」[rhp]

[:princess:][puri_w kao=1]
「这样啊！难怪长得那么像呢」[rhp]

[:jet:][jet kao=13 ]
「骗你的。只是撞脸啦」[rhp]

[:princess:][puri_w kao=2 as=on ]
「到底是哪种！？」[rhp]

[:heartshape:][hati kao=5 ]
「世界上不是据说有三张相同面孔的人嘛！」[rhp]
[:heartshape:]
「第三位杰特or哈蒂 火热募集中！！」[rhp]

[:princess:][puri_w kao=1]
「到头来到底是哪边啊……？」[rhp]

[off_all]


; 好感度+10
[eval exp="f.love_h  = f.love_h + 10"]

[eval exp="f.ss_hati = 13"]
[eval exp="f.ss_2nd_hati= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_14
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_04.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_31.ogg"]

[chara_part name="jet" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:]
「呐公主。你老是往我们这儿跑」[rhp]

[:jet:]
「是不是没朋友啊？」[rhp]

[:princess:][puri_w kao=2 as=on ]
「有的！！就是因为想见你们俩才来的！」[rhp]

[:heartshape:][hati kao=5 ]
「知道啦。肯定是开玩笑吧？[rhr]
_　谢啦公主」[rhp]

[:heartshape:][hati kao=11 ]
「多亏你每天过来，我们也不无聊了」[rhp]

[:jet:][jet kao=13 ]
「是啊。因为器物损坏被多洛普责骂的次数也少了」[rhp]

[:2nin:]
「以后也请多关照啦，公主！」[rhr]
「以后也请多关照啦，公主！」[rhp]

[:princess:][puri_w kao=8 as=on ]
「可以开心吗？这是……」[rhp]
[:princess:][puri_w kao=14 hh=on ]
「……嘛、倒也不讨厌就是了！」[rhp]

[off_all]

; 好感度+10
[eval exp="f.love_h  = f.love_h + 10"]

[eval exp="f.ss_hati = 14"]
[eval exp="f.ss_2nd_hati= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_15
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_04.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_31.ogg"]

[:princess:][puri_w kao=5 ]
「哈蒂君！现在是一个人吗？」[rhp]

[:heartshape:][hati kao=13 ]
「啊。杰特那家伙对克林使了锁喉摔[rhr]
_　结果被反击打晕睡着呢！」[rhp]

[:princess:]
「我呀，刚刚想到个好主意……」[rhp]

[off_all]

[::]
窃窃私语……[rhp]

[:heartshape:][hati kao=2 as=on hh=on ]
「……！！你是天才吗！？」[rhp]

[:princess:][puri_w kao=11 ]
「承让承让。嘚瑟」[rhp]

[:heartshape:][hati kao=1 ]
「这可不能耽搁。马上着手准备吧！」[rhp]

[off_all]

; 好感度+10
[eval exp="f.love_h  = f.love_h + 10"]

[eval exp="f.ss_hati = 15"]
[eval exp="f.ss_2nd_hati= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_16
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_01.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_31.ogg"]

[:jet:][jet kao=0 ]
「喂——哈蒂你去哪了……」[rhp]
[:jet:][jet kao=2 as=on ]
[font size=30]
「！？」[rhp]
[resetfont]

[chara_part name="jet" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="jet" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:princess:]
「是杰特啦！」[rhp]

[:heartshape:]
「是杰特啦！」[rhp]

[off_all]

[:jet:][jet kao=2 as=on ]
「居、居然真的存在！第三位……」[rhp]

[bg storage="train_09.jpg" time=300 ]

[:jet:][jet kao=2 as=on ]
[font size=25]
「哈！！」[rhp]
[resetfont]
[:jet:][jet kao=6 as=on ]
「是、是梦……？对了，我在午睡……」[rhp]

[:princess:][jet kao=13 ]
「啊！早上好杰特君」[rhp]

[off_all]

[:jet:][jet kao=2 as=on ss=on ]
「诶……？」[rhp]

[off_all]
[se storage="hand_01.ogg"]
咚嚓[rhp]

[:princess:][puri_w kao=0]
「又睡着了」[rhp]

[:heartshape:][hati kao=5 ]
「明明是我的魔法啊。……哎算了不管了！」[rhp]

[:jet:][jet kao=14 ]
「恶作剧大成功～～！！」[rhp]

[:princess:][puri_w kao=14 ]
「恶作剧大成功～～！！」[rhp]

[off_all]

; 好感度+10
[eval exp="f.love_h  = f.love_h + 10"]

[eval exp="f.ss_hati = 16"]
[eval exp="f.ss_2nd_hati= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_2nd
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_04.jpg" time=1000 ]
;************************************

[:drop:][drop kao=2 as=on ]
「喂～～～～！！！给我站住～～！！」[rhp]

[off_all]

[chara_part name="jet" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:jet:][jet kao=1 ]
「才不要呢～」[rhp]

[:heartshape:][hati kao=1 ]
「有本事追到这儿来！！然后再谈！！」[rhp]

[off_all]

[:princess:][puri_w kao=5 as=on ]
「看起来很忙。没办法，下次再说吧……」[rhp]

[off_all]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
;---------------------------------------------------------------------------------------------


*next

#
[off_all]

;ev_7への分岐
[if exp="f.ev_a_07 ==1 && f.nigmode == 1"]
[jump storage="ev_a_07.ks" target="*start"]

;ev_6への分岐
[elsif exp="f.ev_a_06 ==1 && f.nigmode == 1"]
[jump storage="ev_a_06.ks" target="*start"]

;ev_3への分岐
[elsif exp="f.ev_a_03 ==1 && f.nigmode == 1"]
[jump storage="ev_a_03.ks" target="*start"]

;ev_2への分岐
[elsif exp="f.ev_a_02 ==1 && f.nigmode == 1"]
[jump storage="ev_a_02.ks" target="*start"]

;夜モードの場合
[elsif exp="f.nigmode == 1"]
[jump storage="ss_main.ks" target="*start"]

;昼モード
[else]
[jump storage="ss_select.ks" target="*select_scene_nig"]
[endif]


