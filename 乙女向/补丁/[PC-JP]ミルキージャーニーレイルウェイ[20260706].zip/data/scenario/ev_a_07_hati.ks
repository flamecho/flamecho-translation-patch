﻿
*start
;--------------------------------------------------------------------------------------------
;▼フルボイスセット▼
;ハートシェイプ
[voconfig sebuf=1 name=hati vostorage="hati/full/{number}.ogg" number=74]

;--------------------------------------------------------------------------------------------

[:princess:][puri_w kao=2 as=on hh=on ]
「…………………………」[rhp]

[off_all]

[::]
――――既然你喜欢我，那家伙肯定也会喜欢的！[rhp]

[:princess:][puri_w kao=2 as=on hh=on ]
「…………！！　你你你你你！[rhr]
_　为什么这时候会突然浮现哈蒂君的脸啊！？」[rhp]
[:princess:][puri_w kao=3 as=on hh=on ]
「啊、那那那肯定是朋友的意思啦！[rhr]
_　这种话根本不值得反复回味吧……」[rhp]
[:princess:]
「……………………」[rhp]
[:princess:][puri_w kao=6 as=on hh=on ]
「……不、不过……？　如果真是这么看重我这个朋友的话？[rhr]
_　作为邀请对象或许是最佳选择……什么的……」[rhp]

[:jet:][p_j_12][jet kao=6 ]
「自言自语太多了吧？」[rhp]

[off_jet]

[:princess:][puri_w kao=2 ss=on as=on ]
[font size=32]
「啊――――！！」[rhp]
[resetfont]

[:jet:][p_j_10][jet kao=2 as=on ]
「吵死了！　搞什么啊真是」[rhp]

[:princess:]
「杰、杰特君！！！　你敲过门了！？」[rhp]

[:jet:][jet kao=11 ]
「敲了啊。但没反应我以为你睡了」[rhp]

[:princess:][puri_w kao=6 as=on ]
「这、这样啊……抱歉，刚刚在考虑事情……」[rhp]

[:jet:][p_j_31][jet kao=7 ]
「关于哈蒂的事」[rhp]

[off_all]

[:princess:]
[font size=32]
「完蛋――――！！！！！」[rhp]
[resetfont]

[yurasu]
[se storage="hand_05.ogg"]

[:jet:]
「呜哇！！」[rhp]

[::]
被突如其来的声音吓得猛然回头，顺手抓起枕边的枕头甩了过去。[rhp]

[:princess:][puri_w kao=2 as=on hh=on ]
「哇啊！！　哇啊！！　哈、哈、哈蒂君你听到了吗！？　不是那样的！[rhr]
_　说到底这都是杰特君的胡言乱语！！」[rhp]
[:princess:][puri_w kao=0 as=on ]
「…………话说，咦？」[rhp]

[::]
说起来，平时形影不离的哈蒂君怎么不在……？[rhp]

[:jet:][jet kao=2 as=on ]
「痛痛……！　你这家伙！　突然干什么啊！」[rhp]

[:princess:][puri_w kao=0 ]
「哈蒂君呢？　今天没和你一起吗？」[rhp]

[:jet:][p_j_17][jet kao=6 ]
「那家伙现在应该正在被多洛普说教。[rhr]
_　在客车里玩杂技捉迷藏，结果把吊环全都弄坏了」[rhp]

[:princess:][puri_w kao=2 as=on ]
[font color=0x4682b4]
（还是不要追问细节吧……）[rhp]
[resetfont]

[:jet:][jet kao=7 ]
「所以只有我闲着没事干，就来找你说话了。[rhr]
_　像这样两人独处的机会可不多啊」[rhp]

[:princess:][puri_w kao=4 ]
「说话？和我？」[rhp]

[:jet:][jet kao=2 ]
「给我仔细听好。是很重要的事」[rhp]
[:jet:]
「……直说吧，哈蒂那家伙喜欢你」[rhp]

[:princess:][puri_w kao=2 as=on hh=on ]
「！！！？？？你你你胡说什么呢」[rhp]

[:jet:][jet kao=6 as=on ]
「先别激动，总之听我说完。行吗？」[rhp]

[off_all]

[::]
眼前竖起的手指让我沉默下来。[rhr]
杰特君继续用平淡的语气说着。[rhp]

[:jet:][jet kao=2 ]
「刚才也说过，杰特确实喜欢你。[rhr]
_　既然是本大爷说的，十有八九错不了」[rhp]
[:jet:]
「但问题是那家伙啊，也特别喜欢我」[rhp]

[:princess:][puri_w kao=6 as=on ]
「？？这不是好事吗……？」[rhp]

[:jet:][p_j_02][jet kao=11 ]
「啊确实是好事。哈蒂这家伙实在太温柔了……[rhr]
_　可这份温柔，现在反而成了麻烦」[rhp]

[:princess:][puri_w kao=0 ]
「什么意思？」[rhp]

[:jet:][jet kao=2 ]
「我和他是绑在一条绳上的蚂蚱。[rhr]
_　当他意识到自己心意时，很可能会搞错对象」[rhp]
[:jet:][jet kao=2 ]
「误以为我也喜欢公主」[rhp]

[:princess:][puri_w kao=4 as=on ]
「这、这样啊！？」[rhp]

[:jet:][p_j_34]
「但这是假的」[rhp]

[:princess:][puri_w kao=5 as=on ]
「这样啊……被直截了当地说出来有点受伤……」[rhp]

[:jet:][jet kao=3 ]
「那家伙就算压抑自己的感情[rhr]
_　也绝对想撮合我和公主。明明不是认真的」[rhp]

[:princess:][puri_w kao=2 as=on ]
「不用说两遍啦！」[rhp]

[:jet:][jet kao=2 ]
「况且你喜欢的是哈蒂。[rhr]
_　这种展开对你来说也很不妙吧」[rhp]

[:princess:][puri_w kao=6 as=on hh=on ]
「……！才、才没有……喜欢什么的……」[rhp]

[:jet:]
「总之。我制定了一个作战计划。[rhr]
_　和之前目的相同 无论如何都要让哈蒂结为情侣的那个」[rhp]
[:jet:][jet kao=14 ][p_j_16]
「其名为，『哈蒂与甜蜜蜜计划』！！！！」[rhp]

[:princess:][puri_w kao=13 as=on ]
[font color=0x4682b4]
（老土……）[rhp]
[resetfont]

[:jet:][jet kao=2 ]
「所以公主 去邀请杰特参加夏日祭吧！」[rhp]

[:princess:][puri_w kao=6 as=on ]
「哎！？」[rhp]

[:jet:][p_j_28][jet kao=11 ]
「反正你刚才就在想这事吧。[rhr]
_　差不多也该结束说教了 我觉得时机正好」[rhp]

[:princess:][puri_w kao=2 as=on ]
「等、等一下————————可以吗？」[rhp]

[:jet:][jet kao=2 ]
「干嘛」[rhp]

[:princess:]
「考虑各种事情是不错 但我的心情呢？[rhr]
_　我可从来没说过喜欢哈蒂君这种话哦？」[rhp]

[:jet:][p_j_17]
「不 你绝对喜欢吧。[rhr]
_　三个人在一起的时候 总是不停地盯着哈蒂看」[rhp]

[:princess:][puri_w kao=5 as=on hh=on ]
「……是、是这样吗？」[rhp]

[:jet:][p_j_26][jet kao=11 ]
「你啊 感情比你自己想的更容易表现在脸上，[rhr]
_　如果不想被发现的话，多少还是小心点比较好吧」[rhp]

[:princess:][puri_w kao=2 as=on hh=on ]
「啰、啰嗦死了～～～～……！」[rhp]

[off_all]

[::]
像是被催促似的，我似乎正在被多洛普训斥着[rhr]
为了见哈蒂君而前往机房。[rhp]
……虽然被指出连自己都没察觉的心意确实让人不爽。[rhp]

[:princess:]
[font color=0x4682b4]
（但是，如果是比谁都了解哈蒂君的杰特君这么说的话……）[rhp]
[resetfont]

[::]
我，对哈蒂君……[rhp]

[:princess:]
[font color=0x4682b4]
（……难道，喜欢吗……？）[rhp]
[resetfont]

;****************************************
[fbgm]
[filter_n]
[set_xx graphic="rule/krke_h.png" storage="sky_07.jpg"]
;****************************************

[::]
银河铁道在数小时后抵达了目标星球。[rhp]
我们换上夸德里利昂挑选准备的浴衣，[rhr]
终于踏上了那片土地。[rhp]

;****************************************
[bg storage="fes_01.jpg" time=1000]
[bgm storage="bgm_26.ogg"]
;****************************************

列车停靠在一处稍高的位置，[rhr]
面对着通往宽阔神社的漫长石阶。[rhp]

「夏日祭之星」永远沉浸在傍晚时分的氛围中，[rhr]
慵懒的闷热感令人联想到初夏。[rhp]
鲜红的灯笼将微暗的夜色明亮地映照，[rhr]
台阶上方传来太鼓和笛子的乐声，空气中飘荡着独特的甜香。[rhp]

尚未目睹的景象让心跳加速，[rhr]
迫不及待想快点跑上这段台阶。[rhp]

[chara_part name="jet" body=yukata kao=5 as=off ss=off hh=on hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=yukata kao=5 as=off ss=off hh=on hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:][p_h_14]
「这、这就是……！夏日祭典！太厉害了！」[rhp]

[:jet:][p_j_14]
「明明只看见灯笼和台阶就已经兴奋起来了！」[rhp]

[off_all]

[chara_part name="riri" body=yukata kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="kite" body=yukata kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:quadrillion:][p_r_14]
「哎呀哎呀，所以小鬼头就是这样的嘛。[rhr]
_　外面稍微热闹点就高兴成这样」[rhp]

[:kite:][p_k_14]
「说这话的克林不是也新买了相机？干劲十足啊」[rhp]

[:quadrillion:][p_r_27][riri body=yukata kao=14 ]
「讨厌～～～～！懂我嘛！？[rhr]
_　没错！这是专门针对夜间拍摄的」[rhp]

[:kite:][kite body=yukata kao=6 ]
「啊，没关系的」[rhp]

[off_all]

[:drop:][p_d_04][drop kao=1 ]
「那么各位，烟花大会预定在18点半左右开始，[rhr]
_　请大家在那之前稍微提早些到广场集合哦」[rhp]

[:vulpecula:][peku body=yukata kao=13 ]
「好呀！看烟花的时候要一起喊『玉屋～～』才开心呢！」[rhp]

[:drop:][drop kao=13 ]
「嗯。这段时间各位可以自由活动，请好好享受。[rhr]
_　我会留在车里进行检修」[rhp]

[off_all]

[:princess:][puri_w body=yukata kao=6 as=on ]
「诶……！多洛普你不去玩吗？[rhr]
_　检修什么的很无聊吧」[rhp]

[:drop:][p_d_02][drop kao=13 ]
「这些事总得有人来做。[rhr]
_　而且对我来说车内检修也是非常快乐的事，请放心」[rhp]
[:drop:]
「虽算不上补偿，但很期待你们的旅行见闻！[rhr]
_　每次听大家讲述经历，我都非常开心」[rhp]

[:princess:][puri_w body=yukata kao=6 as=on ]
「但是……」[rhp]

[:quadrillion:][p_r_34][riri body=yukata kao=6 ]
「那家伙一直都是那样啦。别管他」[rhp]
[:quadrillion:]
「我们的人生信条就是随心所欲做喜欢的事。[rhr]
_　玩不玩全看本人意愿。我们可没资格指手画脚」[rhp]

[:drop:]
「就是这个道理」[rhp]

[:princess:][puri_w body=yukata kao=3 as=on ]
「……明、明白了……」[rhp]

[off_all]

[::]
以多洛普的话语为开端，众人各自散开行动。[rhp]

[chara_part name="riri" body=yukata kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="kite" body=yukata kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:quadrillion:][p_r_15]
「快斗。和那些巨乳随便聊几句制造下空隙怎样？[rhr]
_　老娘趁这工夫多拍几张劲爆照片」[rhp]

[:kite:][kite body=yukata kao=2as=on ]
「干嘛用『反正你也想要吧』的口气说话？　我才不要？」[rhp]

[:quadrillion:][riri body=yukata kao=11 ]
「今天所有游玩开销我全包」[rhp]

[:kite:][p_k_30][kite body=yukata kao=6as=on ]
「呜咕……小、小不忍则乱大谋……」[rhp]

[off_all]

[chara_part name="otiai" body=yukata kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="peku" body=yukata kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:][p_vl_04]
「呐呐～落合！现在是一个人吗～？」[rhp]

[:otiai:]
「是又怎样」[rhp]

[:vulpecula:]
「方便的话～要不要和佩奇他们一起去探店呀～？」[rhp]

[:otiai:][p_ot_25][otiai body=yukata kao=7 ]
「没兴趣。我对现充那套……」[rhp]

[:darknebula:][p_da_37][hakase body=yukata kao=5 ]
[font size=26]
「博士可有兴趣得很呢～～！」[rhp]
[resetfont]

[:otiai:][otiai body=yukata kao=2 as=on ]
「！？」[rhp]

[:darknebula:][p_da_26]
「落合很少和我们交谈所以很有趣啊。[rhr]
_　像你这个年纪的少年究竟在思考什么，又是怀着怎样的心情步入叛逆期……真想了解！」[rhp]

[:otiai:]
「不我真的不用了……」[rhp]

[off_all]

[chara_part name="hakase" body=yukata kao=13 as=off ss=off hh=off hr=on msk=hat ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="peku" body=yukata kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:]
「落合！套圈游戏儿童票只要200円哦！？[rhr]
_　只有落合和博库两个人的话超级划算的！」[rhp]

[:darknebula:]
「关键在于离心力与重力的计算。让博士来教你诀窍吧」[rhp]

[:vulpecula:]
「好厉害～！不愧是物理学家啊！[rhr]
_　和博士在一起的话玩套圈就能无敌了呢，小落！」[rhp]

[off_all]

[:otiai:][otiai body=yukata kao=2 as=on ]
「真是的～～！要玩就玩嘛，来吧！！」[rhp]

[off_all]

[:princess:][puri_w body=yukata kao=1 ]
「呵呵！落合君，看你很开心真是太好了」[rhp]

[:jet:][p_j_09][jet body=yukata kao=2 ]
「你在这儿发什么呆。别忘记作战计划啊？和哈蒂的……你懂的！」[rhp]

[:princess:][puri_w body=yukata kao=1 ]
「我知道啦。是『3TJD作战』对吧？」[rhp]

[:jet:][p_j_06][jet body=yukata kao=1 ]
「没错。『HL（哈蒂与甜蜜蜜）计划』内部特别任务，[rhr]
『3TJD（假装三人游玩当天杰特放鸽子）作战』」[rhp]

[:princess:][puri_w body=yukata kao=6 ]
「真的没问题吗……[rhr]
_　我觉得杰特君根本就是在胡闹」[rhp]

[:jet:][p_j_10][jet body=yukata kao=2 ]
「我哪里胡闹了啊！[rhr]
_　我可是为你们考虑了这么多耶！」[rhp]

[:princess:]
「那只是杰特君自己异常起劲吧……」[rhp]

[:heartshape:][p_h_15][hati body=yukata kao=5 ]
「喂喂说什么呢？两个人偷偷讲悄悄话？」[rhp]

[:2nin:][jet body=yukata kao=4 as=on ][puri_w body=yukata kao=2 as=on ]
「！！」[rhr]
「！！」[rhp]

[:heartshape:][hati body=yukata kao=14 ]
「你们关系可真好啊。这次的庙会也是，[rhr]
_　我被多洛普训话的时候，你们偷偷策划了逛庙会的事吧？」[rhp]

[:princess:][puri_w body=yukata kao=14 as=on hh=on ]
「策、策划嘛。对、对对……怎么说呢，就是那个……」[rhp]
[:princess:]
「我、我们只是想三个人能一起逛啦！」[rhp]

[:jet:][p_j_19][jet body=yukata kao=2 as=on ]
「哈？」[rhp]

[:princess:][puri_w body=yukata kao=13 as=on hh=on ]
「喂！杰特君。是吧！？」[rhp]

[:jet:]
「不……、……～～～～」[rhp]
[:jet:][jet body=yukata kao=6 as=on ]
「………………就是这种感觉」[rhr]
[font color=0x4682b4]
（切！被氛围带跑了，公主这家伙……！）[rhp]

[:princess:][puri_w body=yukata kao=2 as=on hh=on ]
（对不起，杰特君……！虽然被交代『只邀请哈蒂君就好』[rhr]
_　但对我来说果然门槛太高了啦……！）[rhp]
[:princess:][puri_w body=yukata kao=6 as=on hh=on ]
（…………、不过……）[rhp]
[resetfont]

[off_puri]

[::]
哈蒂君倒是意外地保持着平常的状态呢。[rhr]
露营时的发言，就像完全忘记了一样……[rhp]

[off_all]

[:vulpecula:][p_vl_04][peku body=yukata kao=1 ]
「快点快点ー！快出发啦博士！佩奇！[rhr]
_　再不抓紧店铺就逛不完啦！」[rhp]

[:darknebula:][hakase body=yukata kao=1 ]
「喂喂、乱跑很危险的佩奇」[rhp]

[off_all]

[:darknebula:][p_da_31][hakase body=yukata kao=1 msk=off ]
「…………哎」[rhp]

[off_all]

[::]
博士将视线转向这边。[rhr]
啪嗒地对上目光后，他轻快地眨了眨眼。[rhp]
虽然没有发出声音，[rhr]
但能从唇形看出他在说『加油！』[rhp]

[:princess:][puri_w body=yukata kao=0 as=on hh=on ]
「…………」[rhp]

[off_puri]

[::]
倒不是因为被声援了，[rhr]
只是偷偷瞥了眼身旁的哈蒂君。[rhp]
他不知为何表情严肃地歪着头。[rhp]

[:heartshape:][p_h_17][hati body=yukata kao=6 ]
「嗯ー……」[rhp]

[:jet:][jet body=yukata kao=13 as=on ]
「怎、怎么了？你们俩果然要单独去吗？」[rhp]

[:heartshape:][hati body=yukata kao=6 ]
「不。不如说你俩自己去不就好了」[rhp]

[:jet:][p_j_19][jet body=yukata kao=2 as=on ]
「啥！？」[rhp]

[:heartshape:][hati body=yukata kao=6 ]
「最近看起来关系超好啊！[rhr]
_　杰特你也不讨厌公主对吧？」[rhp]

[:jet:][jet body=yukata kao=2 as=on ]
[font color=0x4682b4]
（哈蒂这家伙……！果然是想撮合[rhr]
_　我和公主……！别想得逞！）[rhp]
[resetfont]
[:jet:][jet body=yukata kao=14 as=on ]
「哈哈……！胡、胡说什么呢。[rhr]
_　哈蒂你今天才该和公主―――」[rhp]

[:heartshape:][hati body=yukata kao=14 ]
「不用管我啦！[rhr]
_　你们年轻人自己慢慢玩～！」[rhp]

[:jet:][p_j_28][jet body=yukata kao=2 as=on ]
「才不要！！你不和公主去的话我也不去！」[rhp]

[:heartshape:][hati body=yukata kao=2 as=on]
「哎！？难得的机会不享受太浪费了吧！」[rhp]

[:jet:]
「那就三个人。我和公主组队这种事[rhr]
_　绝对不可能。别再提了！」[rhp]

[:heartshape:][p_h_22][hati body=yukata kao=6 as=on]
「诶～……好、好吧……」[rhp]

[:princess:][puri_w body=yukata kao=13 as=on ]
「好啦好啦两位。吵架就到此为止……」[rhp]

[:jet:][jet body=yukata kao=12 ]
「虽然不是在吵架」[rhp]

[:heartshape:][hati body=yukata kao=6]
「没错！我怎么可能和杰特吵架！」[rhp]

[:princess:]
「这样啊。抱歉抱歉」[rhp]
[puri_w body=yukata kao=1 ]
「对了两位，忘了说今天的衣服很配哦！[rhr]
_　那个小包也很可爱！」[rhp]

[:jet:][jet body=yukata kao=5 ]
「偶、偶尔这样也不错啦」[rhp]

[:heartshape:][p_h_02][hati body=yukata kao=14 ]
「噢！神清气爽啊！[rhr]
_　　裆部也凉飕飕的！」[rhp]

[puri_w body=yukata kao=3 as=on ss=on ]
[jet body=yukata kao=6 as=on ]
[:2nin:]
「……………………」[rhr]
「……………………」[rhp]

[:heartshape:][hati body=yukata kao=0 ]
「咦？　什么？」[rhp]

[:princess:][puri_w body=yukata kao=13 as=on ]
「因、因为就像裙子一样嘛。[rhr]
_　哈蒂君你可能不太熟悉吧」[rhp]

[:heartshape:][hati body=yukata kao=13 ]
「是啊。这点上公主可真厉害！[rhr]
_　总是穿着那么短的迷你裙却完全不怕冷啊」[rhp]
[:heartshape:][hati body=yukata kao=14 ]
「真不愧是公主！我也要多吃点蛋糕什么的！」[rhp]

[:princess:][puri_w body=yukata kao=2 as=on ss=on ]
「这话什么意思啦！我有那么胖！？」[rhp]

[off_all]

[:jet:][jet body=yukata kao=6 as=on ]
[font color=0x4682b4]
（哈蒂还是老样子……根本不分场合乱开玩笑。[rhr]
_　虽然有点担心，还是早点开溜吧……）[rhp]
[resetfont]

[off_jet]

[chara_part name="jet" body=yukata kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=yukata kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:jet:]
「…………我去下厕所」[rhp]

[:heartshape:][p_h_31][hati body=yukata kao=14 ]
「肚子着凉了吗杰特！？是会嗖嗖发凉的……！[rhr]
_　要用魔法给你变个腹卷吗！？」[rhp]

[:jet:][jet body=yukata kao=2 as=on ]
「才不要！！」[rhp]

[:princess:][puri_w body=yukata kao=1 ]
「呵呵……！哈蒂君刚才的样子有点像妈妈呢」[rhp]

[:heartshape:][p_h_06][hati body=yukata kao=1 ]
「真的吗？看起来像两个孩子的妈！？」[rhp]

[:princess:][puri_w body=yukata kao=2 as=on ]
[font color=0x4682b4]
（咦……？说『两个孩子』，该不会包括我吧……）[rhp]
[resetfont]

[:jet:][jet body=yukata kao=14 ]
「我待会儿追上来，你们两个先走吧」[rhp]

[:heartshape:][p_h_17][hati body=yukata kao=8 ]
「可以吗？就你一个人？」[rhp]

[:jet:][jet body=yukata kao=5 ]
「我又不是小孩子。没问题的」[rhp]

[:heartshape:][hati body=yukata kao=14 as=on ]
「……！原、原来如此！抱歉。明白啦！」[rhp]

[:jet:][jet body=yukata kao=1 ]
「嗯」[rhp]

[off_all]


[:jet:][jet body=yukata kao=6 ][p_j_04]
「……公主！」[rhp]

[:princess:][puri_w body=yukata kao=0 ]
「嗯？」[rhp]

[:jet:][jet body=yukata kao=13 ]
「要小心」[rhp]

[:princess:][puri_w body=yukata kao=13 as=on ]
「好、好的……！」[rhp]

;****************************************
[fbgm]
[set_yy storage="fes_06.jpg"]
[bgm storage="bgm_31.ogg"]
;****************************************

随后过了十几分钟。[rhp]
比杰特君稍早一步，[rhr]
我正在庆典摊贩间四处闲逛时……[rhp]

[:heartshape:][hati body=yukata kao=2 ]
「～～～～～太慢了！」[rhp]

[off_all]

[::]
对着迟迟不归的杰特君，[rhr]
似乎终于忍无可忍了。[rhp]

[:heartshape:][hati body=yukata kao=2 as=on ]
「杰特那家伙在搞什么！该不会真闹肚子了吧！？[rhr]
_　所以我不是说了要穿腹卷吗……！」[rhp]
[:heartshape:]
「对不住啊公主！我去找那家伙。你在这稍等……」[rhp]

[off_all]

[::]
糟了！这其实是杰特君的计谋，[rhr]
一直不回来也是故意为之。[rhp]
要是就这样让哈蒂君去找杰特君的话，[rhr]
事后肯定会被杰特君唠唠叨叨训斥的……！！[rhp]

[:princess:][puri_w body=yukata kao=2 as=on ]
「啊——！等、等等哈蒂君！」[rhp]

[:heartshape:][hati body=yukata kao=2 ]
「啊？干嘛！」[rhp]

[:princess:]
「那、那个还是别去比较好吧。[rhr]
_　你看，杰特君也到那个年纪了嘛」[rhp]

[:heartshape:]
「……！？闹肚子是生理现象！和年纪有个屁关系！」[rhp]

[:princess:]
「虽、虽然是这样啦～～～」[rhp]

[:heartshape:]
「搞什么啊。有话就直说！」[rhp]

[off_all]

[::]
向来活泼开朗的哈蒂君开始露出几分焦躁。[rhr]
或许是被这气势压倒，我慌忙脱口而出。[rhp]

[:princess:][puri_w body=yukata kao=2 as=on hh=on ]
「我、我想和哈蒂君在一起！」[rhp]

[:heartshape:][hati body=yukata kao=0 ]
「诶……」[rhp]

[:princess:][puri_w body=yukata kao=4 as=on ]
「……啊」[rhp]

[off_all]

[::]
…………搞砸了。[rhp]

[:heartshape:][hati body=yukata kao=4 as=on ]
「你这家伙……」[rhp]

[off_all]

[::]
哈蒂君一脸惊愕地看着我。[rhr]
啊真是的……！既然这样干脆破罐子破摔！！[rhp]

[chara_part name="hati" body=yukata kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=yukata kao=2 as=on ss=off hh=on hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:][puri_w body=yukata kao=2 as=on ]
「杰、杰特君是特地为我们着想的！[rhr]
_　为了让哈蒂君能和我两个人单独逛祭典！」[rhp]

[:heartshape:][hati body=yukata kao=4 as=on ]
「诶？」[rhp]

[:princess:]
「杰特君就算等下去也不会回来的。[rhr]
_　因为杰特君他，去厕所根本就是……！」[rhp]

[:heartshape:][p_h_30][hati body=yukata kao=2 as=on ]
「……从最开始就没打算去？」[rhp]

[:princess:]
「答对啦！！」[rhp]

[:heartshape:]
「………………」[rhp]

[off_all]

[::]
怎、怎么办。说谎的事，你在生气吗？[rhr]
还是说伤害到你了呢……[rhp]

[:princess:][puri_w body=yukata kao=8 as=on ]
「那个……」[rhp]

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
[vostart]
;--------------------------------------------------------------------------------------------

[:heartshape:][hati body=yukata kao=14 ]
「―――――原来是这么回事！」[rhp]

[:princess:][puri_w body=yukata kao=4 as=on ]
「诶……」[rhp]

[:heartshape:][hati body=yukata kao=5 ]
「杰特那小子，[rhr]
_　鬼鬼祟祟的原来在打这种主意！」[rhp]
[:heartshape:]
「真是个谋士啊！不愧是他！」[rhp]

[:princess:]
「你、你没生气？」[rhp]

[:heartshape:]
「怎么会！？我现在可是高兴得很呢！」[rhp]
[:heartshape:]
「因为这可是那家伙第一次瞒着我[rhr]
_　独自执行的作战啊！」[rhp]

[:princess:]
「哈蒂君……」[rhp]

[:heartshape:][hati body=yukata kao=14 ]
「那家伙平时总是黏着我！[rhr]
_　虽然有点寂寞，但我想尊重他的意愿！」[rhp]
[:heartshape:]
「杰特真的很温柔！　连我这样的人[rhr]
_　都愿意给我留下回忆……！　不愧是心有灵犀的搭档！」[rhp]

[off_all]

[::]
……嗯？[rhp]
留下…回忆？[rhp]

[:princess:][puri_w body=yukata kao=2 as=on ]
「等、等等。刚才这话是什么意、」[rhp]

[:heartshape:][hati body=yukata kao=13 ]
「可不能辜负杰特的温柔。[rhr]
_　今天咱们俩就尽情享受祭典吧！」[rhp]

[off_all]

;****************************************
;スチル
[still storage="cg/a_07_h_1.png" rule="021.png" width="1280" height="720" time=1000]
[cg storage="cg/a_07_h_1.png"]
;****************************************

[:heartshape:]
「好嘞！　出发吧！」[rhp]

[:princess:]
「诶……！？　诶诶！？」[rhp]

[:heartshape:]
「嘿嘿！　突然变得像约会一样了呢！」[rhp]

[:princess:]
「约约约约约约会！？」[rhp]

[:heartshape:]
「没错！　就是约会！[rhr]
_　连我都觉得有点害羞了……！」[rhp]
[:heartshape:]
「不过，感觉不坏！」[rhp]

[::]
说着，哈蒂君牵着我的手跑了起来。[rhp]

[:princess:]
「哇！　等、等等！　太快了太快了！」[rhp]

[:heartshape:]
「夜晚短暂！　不抓紧时间就逛不完所有摊位啦！」[rhp]
[:heartshape:]
「别走散了，公主！」[rhp]

[:princess:]
「………！　嗯……！」[rhp]

[::]
我战战兢兢地回握那只被强行牵住的手。[rhr]
紧接着，对方掌心传来更为强劲的力道。[rhp]

[:princess:]
「…………」[rhp]

[::]
―――三个人在一起时，你总是只盯着哈蒂看。[rhp]

……被点破前我竟浑然未觉。[rhr]
亦或是我刻意忽视了这点。[rhp]
明明三人共处的时光如此愉快，[rhr]
我本以为无需区分孰轻孰重。[rhp]

[:princess:]
[font color=0x4682b4]
（可现实并非如此）[rhp]
[resetfont]

[::]
永远走在最前方，为我们领路向前的哈蒂君。[rhp]
他的身影始终闪耀夺目。[rhr]
不知不觉间我已目不能移。[rhp]

我不再迟疑。[rhr]
不必在两者间徘徊。[rhp]
持续鼓动的心脏正清晰传达着答案。[rhp]

[:princess:]
[font color=0x4682b4]
（…………原来我喜欢哈蒂君）[rhp]
[resetfont]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
; ウィンドゥの非表示
[layopt layer="message0" visible="false"]

[set_b storage="fes_04.jpg"]

; ウィンドゥの設定
[position layer="message0" frame="win.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
; ウィンドゥの表示
[layopt layer="message0" visible="true"]
;****************************************

与此同时——[rhp]

[:jet:]
「太、太好了……！」[rhp]

[:darknebula:]
「看样子两人进展顺利呢……！」[rhp]

[:otiai:][otiai body=yukata kao=2 as=on ]
「喂」[rhp]

[off_all]

[chara_part name="hakase" body=yukata kao=2 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="jet" body=yukata kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]

[:jet:]
「嘘——！！！臭小鬼！闭嘴！」[rhp]

[:darknebula:]
「现在正是关键时刻！能安静点吗！」[rhp]

[off_all]

[:otiai:][otiai body=yukata kao=2 as=on ]
「这么在意的话，干脆凑近去看……」[rhp]

[:vulpecula:][p_vl_04][peku body=yukata kao=2 ]
「那个～博士～[rhr]
_　佩奇和御好烧章鱼烧全都吃完啦」[rhp]
[:vulpecula:]
「到底要在这地方呆坐到什么时候啊。[rhr]
_　超～～～无聊的说！」[rhp]

[:otiai:][otiai body=yukata kao=2 as=on ]
「沃、沃尔佩克拉！[rhr]
_　你去那边玩啦。小孩子还太早了！」[rhp]

[:vulpecula:][peku body=yukata kao=6 ]
「什么嘛！　你该不会是想妨碍本饿鬼吃饭吧！？」[rhp]

[:otiai:][p_ot_18]
「不不不是的。那个，这边很危险所以……」[rhp]
[:otiai:][otiai body=yukata kao=13 as=on ]
「啊对了！　要、要不接下来去买苹果糖？[rhr]
_　要不要一起去买？」[rhp]

[:vulpecula:][p_vl_14][peku body=yukata kao=4 hh=on ]
「你要买给我吗！？」[rhp]

[:otiai:]
「当然。博士刚给了好多零花钱」[rhp]
[:otiai:]
[font color=0x4682b4]
（作为拖住你的开销……）[rhp]
[resetfont]

[:vulpecula:][peku body=yukata kao=2 hh=on ]
「那说好啦说好啦！　不只是苹果糖，[rhr]
_　人家的葡萄糖草莓糖橘子糖也全都要……！？」[rhp]

[:otiai:][otiai body=yukata kao=14 ss=on as=on ]
「是要和我一起发胖吗……」[rhp]

[:vulpecula:][p_vl_08][peku body=yukata kao=14 hh=on ]
「小佩最帅～～了！　嘿咻，吃饱饱！」[rhp]

[:otiai:][p_ot_11][otiai body=yukata kao=2 as=on ]
「这讽刺倒是很犀利啊……」[rhp]

[off_all]

[:otiai:][otiai body=yukata kao=6 as=on ]
[font color=0x4682b4]
（可恶，为什么我要当保姆……！　不过不想让这家伙[rhr]
_　看到少儿不宜的东西倒也能理解）[rhp]
[:otiai:]
（啊啊真是的……！[rhr]
_　我也想亲眼看看那帮家伙的下场啊……！）[rhp]
[resetfont]

[off_otiai]

[chara_part name="hakase" body=yukata kao=1 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="jet" body=yukata kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:darknebula:][p_da_15]
「不过杰特真厉害啊。就算要支援那两位，[rhr]
_　居然能切断这么杂……嗯嗯，……草率的计划」[rhp]

[:jet:][p_j_07][jet body=yukata kao=5 ]
「正是那样的博士给公主出的主意吧。[rhr]
_　潦草的挽尊彼此彼此」[rhp]

[:darknebula:]
「但是……你这样真的好吗？那个……」[rhp]

[:jet:][p_j_04][jet body=yukata kao=2 ]
「难道博士也误会了？心理学家都要傻眼」[rhp]

[:darknebula:][hakase body=yukata kao=0 ]
「哎呀……」[rhp]

[:jet:]
「哈蒂和博士都觉得我对公主[rhr]
_　有意思，简直离谱透顶」[rhp]
[:jet:]
「我只在乎自己和哈蒂。[rhr]
_　花在公主身上的时间，不如用在自己身上」[rhp]

[:darknebula:][p_da_03][hakase body=yukata kao=1 ]
「……但愿这是杰特的真心话」[rhp]
[:darknebula:]
「在万事如愿的魔法世界，不希望你有遗憾」[rhp]

[:jet:][jet body=yukata kao=13 ]
「哈哈。博士真是爱操心」[rhp]

[:darknebula:][p_da_16]
「只是被出乎意料的发展惊到了。[rhr]
_　我原以为你想成为哈托谢普」[rhp]

[:jet:][jet body=yukata kao=11 ]
「那倒没有」[rhp]
[:jet:][jet body=yukata kao=12 ]
「光是看着永远闪闪发光的哈蒂我就满足了。[rhr]
_　想成为那家伙？狂妄到撕烂嘴也说不出口」[rhp]
[:jet:]
「不过也没那个打算」[rhp]

[:darknebula:][hakase body=yukata kao=1 ]
「…………。看来决心已定」[rhp]
[:darknebula:]
「问了不识趣的话真是抱歉。我也衷心支持你们俩。[rhr]
_　有困难随时可以来找我商量」[rhp]

[:jet:][jet body=yukata kao=13 ]
「谢了。就指望你了」[rhp]

;****************************************
[s_mask color=0x000000 time=2000]
[set_xx graphic="rule/krke_h.png" storage="train_01.jpg"]
;****************************************

; イベント分岐の解除
[iscript]
delete f.ev_a_07;
[endscript]

[jump storage="ev_a_08_hati.ks"]

[s]
