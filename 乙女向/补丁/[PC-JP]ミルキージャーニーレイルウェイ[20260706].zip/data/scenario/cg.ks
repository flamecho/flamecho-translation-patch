;=========================================
; CG モード　画面作成
;=========================================

@layopt layer=message0 visible=false

@clearfix
[hidemenubutton]
[cm]

[bg storage="title/bg_cg.png" time=100]
[layopt layer=1 visible=true]


[iscript]
    
    tf.page = 0;
    tf.selected_cg_image = ""; //選択されたCGを一時的に保管
    
[endscript]



*cgpage
[layopt layer=1 visible=true]

[cm]
[button graphic="config/menu_button_close.png" enterimg="config/menu_button_close2.png"  target="*backtitle" x="1190" y="180"]

[iscript]
    tf.tmp_index = 0;
    tf.cg_index = 15 * tf.page;
    tf.top = 76;
    tf.left = 61;
    
[endscript]

[iscript]
	tf.target_page = "page_"+tf.page;
[endscript]

*cgview
@jump target=&tf.target_page

;--------------------------------------------------------------------------------------------------------------------------------------------

; １～２５までのスチル

*page_0

[cg_image_button graphic="cg/a_01_1.png" no_graphic="../../tyrano/images/system/noimage.png" x=61 y=76 width=192 height=108 folder="image" target="*cg01"]
[cg_image_button graphic="cg/a_01_2.png" no_graphic="../../tyrano/images/system/noimage.png" x=61 y=193 width=192 height=108 folder="image" target="*cg02"]
[cg_image_button graphic="cg/a_02_1.png" no_graphic="../../tyrano/images/system/noimage.png" x=61 y=310 width=192 height=108 folder="image" target="*cg03"]
[cg_image_button graphic="cg/a_02_d_1.png" no_graphic="../../tyrano/images/system/noimage.png" x=61 y=427 width=192 height=108 folder="image" target="*cg04"]
[cg_image_button graphic="cg/a_02_h_1.png" no_graphic="../../tyrano/images/system/noimage.png" x=61 y=544 width=192 height=108 folder="image" target="*cg05"]

[cg_image_button graphic="cg/a_02_r_1.png" no_graphic="../../tyrano/images/system/noimage.png" x=261 y=76 width=192 height=108 folder="image" target="*cg06"]
[cg_image_button graphic="cg/a_03_1.png" no_graphic="../../tyrano/images/system/noimage.png" x=261 y=193 width=192 height=108 folder="image" target="*cg07"]
[cg_image_button graphic="cg/a_03_2.png" no_graphic="../../tyrano/images/system/noimage.png" x=261 y=310 width=192 height=108 folder="image" target="*cg08"]
[cg_image_button graphic="cg/a_04_1.png" no_graphic="../../tyrano/images/system/noimage.png" x=261 y=427 width=192 height=108 folder="image" target="*cg09"]
[cg_image_button graphic="cg/a_05_1.png" no_graphic="../../tyrano/images/system/noimage.png" x=261 y=544 width=192 height=108 folder="image" target="*cg10"]

[cg_image_button graphic="cg/a_06_k_1.png" no_graphic="../../tyrano/images/system/noimage.png" x=461 y=76 width=192 height=108 folder="image" target="*cg11"]
[cg_image_button graphic="cg/a_06_r_1.png" no_graphic="../../tyrano/images/system/noimage.png" x=461 y=193 width=192 height=108 folder="image" target="*cg12"]
[cg_image_button graphic="cg/a_07_n_1.png" no_graphic="../../tyrano/images/system/noimage.png" x=461 y=310 width=192 height=108 folder="image" target="*cg13" ]
[cg_image_button graphic="cg/a_07_d_1.png" no_graphic="../../tyrano/images/system/noimage.png" x=461 y=427 width=192 height=108 folder="image" target="*cg14" ]
[cg_image_button graphic="cg/a_07_d_2.png" no_graphic="../../tyrano/images/system/noimage.png" x=461 y=544 width=192 height=108 folder="image" target="*cg15"]

[cg_image_button graphic="cg/a_07_h_1.png" no_graphic="../../tyrano/images/system/noimage.png" x=661 y=76 width=192 height=108 folder="image" target="*cg16"]
[cg_image_button graphic="cg/a_07_k_1.png" no_graphic="../../tyrano/images/system/noimage.png" x=661 y=193 width=192 height=108 folder="image" target="*cg17"]
[cg_image_button graphic="cg/a_07_k_2.png" no_graphic="../../tyrano/images/system/noimage.png" x=661 y=310 width=192 height=108 folder="image" target="*cg18"]
[cg_image_button graphic="cg/a_07_r_1.png" no_graphic="../../tyrano/images/system/noimage.png" x=661 y=427 width=192 height=108 folder="image" target="*cg19"]
[cg_image_button graphic="cg/a_07_r_2.png" no_graphic="../../tyrano/images/system/noimage.png" x=661 y=544 width=192 height=108 folder="image" target="*cg20"]

[cg_image_button graphic="cg/a_08_d_1.png" no_graphic="../../tyrano/images/system/noimage.png" x=861 y=76 width=192 height=108 folder="image" target="*cg21"]
[cg_image_button graphic="cg/a_08_d_2.png" no_graphic="../../tyrano/images/system/noimage.png" x=861 y=193 width=192 height=108 folder="image" target="*cg22"]
[cg_image_button graphic="cg/a_08_h_1.png" no_graphic="../../tyrano/images/system/noimage.png" x=861 y=310 width=192 height=108 folder="image" target="*cg23"]
[cg_image_button graphic="cg/a_08_h_2.png" no_graphic="../../tyrano/images/system/noimage.png" x=861 y=427 width=192 height=108 folder="image" target="*cg24"]
[cg_image_button graphic="cg/a_08_h_3.png" no_graphic="../../tyrano/images/system/noimage.png" x=861 y=544 width=192 height=108 folder="image" target="*cg25"]

[button graphic="config/cgbt_2.png" target="*nextpage" x=1125 y=390]
@jump target="*common"

;------------------------------------------------------------------------------------------------------------------------------------------
; ２６～５０まで

*page_1
[cm]

[cg_image_button graphic="cg/a_08_k_1.png" no_graphic="../../tyrano/images/system/noimage.png" x=61 y=76 width=192 height=108 folder="image" target="*cg26"]
[cg_image_button graphic="cg/a_08_k_2.png" no_graphic="../../tyrano/images/system/noimage.png" x=61 y=193 width=192 height=108 folder="image" target="*cg27"]
[cg_image_button graphic="cg/a_08_k_3.png" no_graphic="../../tyrano/images/system/noimage.png" x=61 y=310 width=192 height=108 folder="image" target="*cg28" ]
[cg_image_button graphic="cg/a_08_r_1.png" no_graphic="../../tyrano/images/system/noimage.png" x=61 y=427 width=192 height=108 folder="image" target="*cg29" ]
[cg_image_button graphic="cg/a_08_r_2.png" no_graphic="../../tyrano/images/system/noimage.png" x=61 y=544 width=192 height=108 folder="image" target="*cg30" ]

[cg_image_button graphic="cg/b1_1.png" no_graphic="../../tyrano/images/system/noimage.png" x=261 y=76 width=192 height=108 folder="image" target="*cg31"]
[cg_image_button graphic="cg/b1_2.png" no_graphic="../../tyrano/images/system/noimage.png" x=261 y=193 width=192 height=108 folder="image" target="*cg32"]
[cg_image_button graphic="cg/b1_3.png" no_graphic="../../tyrano/images/system/noimage.png" x=261 y=310 width=192 height=108 folder="image" target="*cg33"]
[cg_image_button graphic="cg/b1_4.png" no_graphic="../../tyrano/images/system/noimage.png" x=261 y=427 width=192 height=108 folder="image" target="*cg34"]
[cg_image_button graphic="cg/b1_5.png" no_graphic="../../tyrano/images/system/noimage.png" x=261 y=544 width=192 height=108 folder="image" target="*cg35"]

[cg_image_button graphic="cg/b1_6.png" no_graphic="../../tyrano/images/system/noimage.png" x=461 y=76 width=192 height=108 folder="image" target="*cg36"]
[cg_image_button graphic="cg/b2_1.png" no_graphic="../../tyrano/images/system/noimage.png" x=461 y=193 width=192 height=108 folder="image" target="*cg37"]
[cg_image_button graphic="cg/b2_2.png" no_graphic="../../tyrano/images/system/noimage.png" x=461 y=310 width=192 height=108 folder="image" target="*cg38"]
[cg_image_button graphic="cg/b2_3.png" no_graphic="../../tyrano/images/system/noimage.png" x=461 y=427 width=192 height=108 folder="image" target="*cg39"]
[cg_image_button graphic="cg/b2_4.png" no_graphic="../../tyrano/images/system/noimage.png" x=461 y=544 width=192 height=108 folder="image" target="*cg40"]

[cg_image_button graphic="cg/c_1.png" no_graphic="../../tyrano/images/system/noimage.png" x=661 y=76 width=192 height=108 folder="image" target="*cg41"]
[cg_image_button graphic="cg/c_2.png" no_graphic="../../tyrano/images/system/noimage.png" x=661 y=193 width=192 height=108 folder="image" target="*cg42"]
[cg_image_button graphic="cg/c_3.png" no_graphic="../../tyrano/images/system/noimage.png" x=661 y=310 width=192 height=108 folder="image" target="*cg43" ]
[cg_image_button graphic="cg/c_4.png" no_graphic="../../tyrano/images/system/noimage.png" x=661 y=427 width=192 height=108 folder="image" target="*cg44" ]
[cg_image_button graphic="cg/c_5.png" no_graphic="../../tyrano/images/system/noimage.png" x=661 y=544 width=192 height=108 folder="image" target="*cg45" ]

[cg_image_button graphic="cg/c_6.png" no_graphic="../../tyrano/images/system/noimage.png" x=861 y=76 width=192 height=108 folder="image" target="*cg46"]
[cg_image_button graphic="cg/d_1.png" no_graphic="../../tyrano/images/system/noimage.png" x=861 y=193 width=192 height=108 folder="image" target="*cg47"]
[cg_image_button graphic="cg/d_d1_1.png" no_graphic="../../tyrano/images/system/noimage.png" x=861 y=310 width=192 height=108 folder="image" target="*cg48"]
[cg_image_button graphic="cg/d_d1_2.png" no_graphic="../../tyrano/images/system/noimage.png" x=861 y=427 width=192 height=108 folder="image" target="*cg49"]
[cg_image_button graphic="cg/d_d1_3.png" no_graphic="../../tyrano/images/system/noimage.png" x=861 y=544 width=192 height=108 folder="image" target="*cg50"]

[button graphic="config/menu_button_close.png" enterimg="config/menu_button_close2.png"  target="*backtitle" x="1190" y="180"]
[button graphic="config/cgbt_1.png" target="*backpage" x=1125 y=290]
[button graphic="config/cgbt_2.png" target="*nextpage" x=1125 y=390]
@jump target="*common"

;------------------------------------------------------------------------------------------------------------------------------------------
; ５１～７５まで

*page_2
[cm]

[cg_image_button graphic="cg/d_d1_4.png" no_graphic="../../tyrano/images/system/noimage.png" x=61 y=76 width=192 height=108 folder="image" target="*cg51"]
[cg_image_button graphic="cg/d_d1_5.png" no_graphic="../../tyrano/images/system/noimage.png" x=61 y=193 width=192 height=108 folder="image" target="*cg52"]
[cg_image_button graphic="cg/d_d2_1.png" no_graphic="../../tyrano/images/system/noimage.png" x=61 y=310 width=192 height=108 folder="image" target="*cg53"]
[cg_image_button graphic="cg/d_d2_2.png" no_graphic="../../tyrano/images/system/noimage.png" x=61 y=427 width=192 height=108 folder="image" target="*cg54"]
[cg_image_button graphic="cg/d_d2_3.png" no_graphic="../../tyrano/images/system/noimage.png" x=61 y=544 width=192 height=108 folder="image" target="*cg55"]

[cg_image_button graphic="cg/d_d2_4.png" no_graphic="../../tyrano/images/system/noimage.png" x=261 y=76 width=192 height=108 folder="image" target="*cg56"]
[cg_image_button graphic="cg/d_d3_1.png" no_graphic="../../tyrano/images/system/noimage.png" x=261 y=193 width=192 height=108 folder="image" target="*cg57"]
[cg_image_button graphic="cg/d_d3_2.png" no_graphic="../../tyrano/images/system/noimage.png" x=261 y=310 width=192 height=108 folder="image" target="*cg58" ]
[cg_image_button graphic="cg/d_d4_1.png" no_graphic="../../tyrano/images/system/noimage.png" x=261 y=427 width=192 height=108 folder="image" target="*cg59" ]
[cg_image_button graphic="cg/d_k_1.png" no_graphic="../../tyrano/images/system/noimage.png" x=261 y=544 width=192 height=108 folder="image" target="*cg60" ]

[cg_image_button graphic="cg/d_k_2.png" no_graphic="../../tyrano/images/system/noimage.png" x=461 y=76 width=192 height=108 folder="image" target="*cg61"]
[cg_image_button graphic="cg/d_k_3.png" no_graphic="../../tyrano/images/system/noimage.png" x=461 y=193 width=192 height=108 folder="image" target="*cg62"]
[cg_image_button graphic="cg/d_k_4.png" no_graphic="../../tyrano/images/system/noimage.png" x=461 y=310 width=192 height=108 folder="image" target="*cg63"]
[cg_image_button graphic="cg/d_r_1.png" no_graphic="../../tyrano/images/system/noimage.png" x=461 y=427 width=192 height=108 folder="image" target="*cg64"]
[cg_image_button graphic="cg/d_r_2.png" no_graphic="../../tyrano/images/system/noimage.png" x=461 y=544 width=192 height=108 folder="image" target="*cg65"]

[cg_image_button graphic="cg/d_r_3.png" no_graphic="../../tyrano/images/system/noimage.png" x=661 y=76 width=192 height=108 folder="image" target="*cg66"]
[cg_image_button graphic="cg/d_r_4.png" no_graphic="../../tyrano/images/system/noimage.png" x=661 y=193 width=192 height=108 folder="image" target="*cg67"]
[cg_image_button graphic="cg/d_r_5.png" no_graphic="../../tyrano/images/system/noimage.png" x=661 y=310 width=192 height=108 folder="image" target="*cg68"]
[cg_image_button graphic="cg/e_1.png" no_graphic="../../tyrano/images/system/noimage.png" x=661 y=427 width=192 height=108 folder="image" target="*cg69"]
[cg_image_button graphic="cg/e_2.png" no_graphic="../../tyrano/images/system/noimage.png" x=661 y=544 width=192 height=108 folder="image" target="*cg70"]

[cg_image_button graphic="cg/e_3.png" no_graphic="../../tyrano/images/system/noimage.png" x=861 y=76 width=192 height=108 folder="image" target="*cg71"]
[cg_image_button graphic="cg/e_4.png" no_graphic="../../tyrano/images/system/noimage.png" x=861 y=193 width=192 height=108 folder="image" target="*cg72"]
[cg_image_button graphic="cg/e_5.png" no_graphic="../../tyrano/images/system/noimage.png" x=861 y=310 width=192 height=108 folder="image" target="*cg73" ]
[cg_image_button graphic="cg/d_h_1.png" no_graphic="../../tyrano/images/system/noimage.png" x=861 y=427 width=192 height=108 folder="image" target="*cg74" ]
[cg_image_button graphic="cg/d_h_2.png" no_graphic="../../tyrano/images/system/noimage.png" x=861 y=544 width=192 height=108 folder="image" target="*cg75" ]

[button graphic="config/menu_button_close.png" enterimg="config/menu_button_close2.png"  target="*backtitle" x="1190" y="180"]
[button graphic="config/cgbt_1.png" target="*backpage" x=1125 y=290]
[button graphic="config/cgbt_2.png" target="*nextpage" x=1125 y=390]
@jump target="*common"

;------------------------------------------------------------------------------------------------------------------------------------------
; ７６～８６、カットイン

*page_3
[cm]

[cg_image_button graphic="cg/d_h_3.png" no_graphic="../../tyrano/images/system/noimage.png" x=61 y=76 width=192 height=108 folder="image" target="*cg76"]
[cg_image_button graphic="cg/d_h_4.png" no_graphic="../../tyrano/images/system/noimage.png" x=61 y=193 width=192 height=108 folder="image" target="*cg77"]
[cg_image_button graphic="cg/d_h_5.png" no_graphic="../../tyrano/images/system/noimage.png" x=61 y=310 width=192 height=108 folder="image" target="*cg78"]
[cg_image_button graphic="cg/d_h_6.png" no_graphic="../../tyrano/images/system/noimage.png" x=61 y=427 width=192 height=108 folder="image" target="*cg79"]
[cg_image_button graphic="cg/d_h_7.png" no_graphic="../../tyrano/images/system/noimage.png" x=61 y=544 width=192 height=108 folder="image" target="*cg80"]

[cg_image_button graphic="cg/d_h_8.png" no_graphic="../../tyrano/images/system/noimage.png" x=261 y=76 width=192 height=108 folder="image" target="*cg81"]
[cg_image_button graphic="cg/d_h_9.png" no_graphic="../../tyrano/images/system/noimage.png" x=261 y=193 width=192 height=108 folder="image" target="*cg82"]
[cg_image_button graphic="cg/d_h_10.png" no_graphic="../../tyrano/images/system/noimage.png" x=261 y=310 width=192 height=108 folder="image" target="*cg83"]
[cg_image_button graphic="cg/d_h_11.png" no_graphic="../../tyrano/images/system/noimage.png" x=261 y=427 width=192 height=108 folder="image" target="*cg84"]
[cg_image_button graphic="cg/d_h_12.png" no_graphic="../../tyrano/images/system/noimage.png" x=261 y=544 width=192 height=108 folder="image" target="*cg85"]

[cg_image_button graphic="cg/f_1.png" no_graphic="../../tyrano/images/system/noimage.png" x=461 y=76 width=192 height=108 folder="image" target="*cg86"]
[cg_image_button graphic="cg/f_2.png" no_graphic="../../tyrano/images/system/noimage.png" x=461 y=193 width=192 height=108 folder="image" target="*cg87"]


[button graphic="config/menu_button_close.png" enterimg="config/menu_button_close2.png"  target="*backtitle" x="1190" y="180"]
[button graphic="config/cgbt_1.png" target="*backpage" x=1125 y=290]
@jump target="*common"

;------------------------------------------------------------------------------------------------------------------------------------------

*cg01
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/a_01_1.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg02
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/a_01_2.png" time=300]
[l]
[bg storage="cg/a_01_2b.png" time=500]
[l]
[bg storage="cg/a_01_2c.png" time=500]
[l]
[bg storage="cg/a_01_2d.png" time=500]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg03
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/a_02_1.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg04
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/a_02_d_1.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg05
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/a_02_h_1.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg06
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/a_02_r_1.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg07
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/a_03_1.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg08
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/a_03_2.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg09
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/a_04_1.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg10
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/a_05_1.png" time=300]
[l]
[bg storage="cg/a_05_1b.png" time=500]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg11
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/a_06_k_1.png" time=300]
[l]
[bg storage="cg/a_06_k_1b.png" time=500]
[l]
[bg storage="cg/a_06_k_1c.png" time=500]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg12
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/a_06_r_1.png" time=300]
[l]
[bg storage="cg/a_06_r_1b.png" time=500]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg13
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/a_07_n_1.png" time=300]
[l]
[bg storage="cg/a_07_n_1b.png" time=500]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg14
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/a_07_d_1.png" time=300]
[l]
[bg storage="cg/a_07_d_1b.png" time=500]
[l]
[bg storage="cg/a_07_d_1x.png" time=500]
[l]
[bg storage="cg/a_07_d_1d.png" time=500]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg15
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/a_07_d_2.png" time=300]
[l]
[bg storage="cg/a_07_d_2b.png" time=500]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg16
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/a_07_h_1.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg17
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/a_07_k_1.png" time=300]
[l]
[bg storage="cg/a_07_k_1b.png" time=500]
[l]
[bg storage="cg/a_07_k_1c.png" time=500]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg18
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/a_07_k_2.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg19
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/a_07_r_1.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg20
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/a_07_r_2.png" time=300]
[l]
[bg storage="cg/a_07_r_2b.png" time=500]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg21
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/a_08_d_1.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg22
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/a_08_d_2.png" time=300]
[l]
[bg storage="cg/a_08_d_2b.png" time=500]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg23
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/a_08_h_1.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg24
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/a_08_h_2.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg25
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/a_08_h_3.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg26
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/a_08_k_1.png" time=300]
[l]
[bg storage="cg/a_08_k_1b.png" time=500]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg27
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/a_08_k_2.png" time=300]
[l]
[bg storage="cg/a_08_k_2b.png" time=500]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg28
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/a_08_k_3.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg29
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/a_08_r_1.png" time=300]
[l]
[bg storage="cg/a_08_r_1b.png" time=500]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg30
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/a_08_r_2.png" time=300]
[l]
[bg storage="cg/a_08_r_2b.png" time=500]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg31
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/b1_1.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg32
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/b1_2.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg33
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/b1_3.png" time=300]
[l]
[bg storage="cg/b1_3b.png" time=500]
[l]
[bg storage="cg/b1_3c.png" time=500]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg34
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/b1_4.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg35
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/b1_5.png" time=300]
[l]
[bg storage="cg/b1_5b.png" time=500]
[l]
[bg storage="cg/b1_5c.png" time=500]
[l]
[bg storage="cg/b1_5d.png" time=500]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg36
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/b1_6.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg37
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/b2_1.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg38
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/b2_2.png" time=300]
[l]
[bg storage="cg/b2_2b.png" time=500]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg39
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/b2_3.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg40
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/b2_4.png" time=300]
[l]
[bg storage="cg/b2_4b.png" time=500]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg41
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/c_1.png" time=300]
[l]
[bg storage="cg/c_1b.png" time=500]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg42
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/c_2n.png" time=300]
[l]
[bg storage="cg/c_2.png" time=500]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg43
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/c_3.png" time=300]
[l]
[bg storage="cg/c_3b.png" time=500]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg44
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/c_4.png" time=300]
[l]
[bg storage="cg/c_4b.png" time=500]
[l]
[bg storage="cg/c_4c.png" time=500]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg45
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/c_5.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg46
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/c_6.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg47
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/d_1.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg48
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/d_d1_1.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg49
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/d_d1_2.png" time=300]
[l]
[bg storage="cg/d_d1_2b.png" time=500]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg50
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/d_d1_3.png" time=300]
[l]
[bg storage="cg/d_d1_3b.png" time=500]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg51
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/d_d1_4.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg52
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/d_d1_5.png" time=300]
[l]
[bg storage="cg/d_d1_5b.png" time=500]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg53
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/d_d2_1.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg54
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/d_d2_2.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg55
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/d_d2_3.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg56
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/d_d2_4.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg57
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/d_d3_1.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg58
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/d_d3_2.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg59
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/d_d4_1.png" time=300]
[l]
[bg storage="cg/d_d4_1b.png" time=500]
[l]
[bg storage="cg/d_d4_1c.png" time=500]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg60
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/d_k_1.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg61
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/d_k_2.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg62
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/d_k_3.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg63
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/d_k_4.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg64
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/d_r_1.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg65
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/d_r_2.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg66
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/d_r_3.png" time=300]
[l]
[bg storage="cg/d_r_3b.png" time=500]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg67
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/d_r_4.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg68
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/d_r_5.png" time=300]
[l]
[bg storage="cg/d_r_5b.png" time=500]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg69
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/e_1.png" time=300]
[l]
[bg storage="cg/e_1b.png" time=500]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg70
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/e_2.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg71
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/e_3.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg72
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/e_4.png" time=300]
[l]
[bg storage="cg/e_4b.png" time=500]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg73
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/e_5.png" time=300]
[l]
[bg storage="cg/e_5b.png" time=500]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage


*cg74
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/d_h_1.png" time=300]
[l]
[bg storage="cg/d_h_1b.png" time=500]
[l]
[bg storage="cg/d_h_1c.png" time=500]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg75
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/d_h_2.png" time=300]
[l]
[bg storage="cg/d_h_2b.png" time=500]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg76
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/d_h_3.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg77
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/d_h_4.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg78
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/d_h_5.png" time=300]
[l]
[bg storage="cg/d_h_5b.png" time=500]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg79
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/d_h_6.png" time=300]
[l]
[bg storage="cg/d_h_6b.png" time=500]
[l]
[bg storage="cg/d_h_6c.png" time=500]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg80
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/d_h_7.png" time=300]
[l]
[bg storage="cg/d_h_7b.png" time=500]
[l]
[bg storage="cg/d_h_7c.png" time=500]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg81
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/d_h_8.png" time=300]
[l]
[bg storage="cg/d_h_8b.png" time=500]
[l]
[bg storage="cg/d_h_8c.png" time=500]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg82
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/d_h_9.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg83
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/d_h_10.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg84
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/d_h_11.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg85
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/d_h_12.png" time=300]
[l]
[bg storage="cg/d_h_12b.png" time=500]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

*cg86
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/f_1.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage


*cg87
[cm]
[layopt layer=1 visible=false]
[bg storage="cg/f_2.png" time=300]
[l]
[bg storage="title/bg_cg.png" time=100]
@jump target=*cgpage

;------------------------------------------------------------------------------------------------------------------------------------------

*common

*endpage


[s]
*backtitle
[cm]
[freeimage layer=1]
@jump storage=title.ks

*nextpage
[emb exp="tf.page++;"]
@jump target="*cgpage"


*backpage
[emb exp="tf.page--;"]
@jump target="*cgpage"

*clickcg
[cm]

[layopt layer=1 visible=false]

[eval exp="tf.cg_index=0"]

*cg_next_image

[image storage=&tf.selected_cg_image[tf.cg_index] folder="bgimage"  ]
[l]
[bg storage="title/bg_cg.png" time=100]

[eval exp="tf.cg_index++"]

@jump target="cg_next_image" cond="tf.selected_cg_image.length > tf.cg_index"


@jump  target=*cgpage
[s]

*no_image

@jump  target=*cgpage



