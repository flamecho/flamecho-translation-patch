﻿
*start

[jump target="*ss_2nd" cond="f.nigmode == 1 && f.ss_2nd_drop == 1"]
[jump target="*ss_16" cond="f.ss_drop >= 15"]
[jump target="*ss_15" cond="f.ss_drop >= 14"]
[jump target="*ss_14" cond="f.ss_drop >= 13"]
[jump target="*ss_13" cond="f.ss_drop >= 12"]
[jump target="*ss_12" cond="f.ss_drop >= 11"]
[jump target="*ss_11" cond="f.ss_drop >= 10"]
[jump target="*ss_10" cond="f.ss_drop >= 9"]
[jump target="*ss_09" cond="f.ss_drop >= 8"]
[jump target="*ss_08" cond="f.ss_drop >= 7"]
[jump target="*ss_07" cond="f.ss_drop >= 6"]
[jump target="*ss_06" cond="f.ss_drop >= 5"]
[jump target="*ss_05" cond="f.ss_drop >= 4"]
[jump target="*ss_04" cond="f.ss_drop >= 3"]
[jump target="*ss_03" cond="f.ss_drop >= 2"]
[jump target="*ss_02" cond="f.ss_drop >= 1"]
[jump target="*ss_01"]

;----------------------------------------------------------------------------------
*ss_01
;----------------------------------------------------------------------------------

;****************************************
[bg storage="train_06.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_28.ogg"]

[:princess:][puri_w kao=1]
「多洛普！　我来找你玩了」[rhp]

[:drop:][drop kao=1]
「你好啊，公主」[rhp]
[:drop:]
「不好意思。现在正在打扫机房，[rhr]
_　暂时恐怕没法陪你」[rhp]

[:princess:][puri_w kao=1]
「这样啊。抱歉在你忙的时候打扰」[rhp]

[:drop:][drop kao=13]
「没事没事。别管我请随意休息」[rhp]

[off_all]

[:drop:]
「那么接下来是…………」[rhp]

[:princess:][puri_w kao=0]
[font color=0x4682b4]
（看起来好忙啊。列车长真是……）[rhp]
[resetfont]

; 好感度+10
[eval exp="f.love_d  = f.love_d + 10"]

[eval exp="f.ss_drop = 1"]
[eval exp="f.ss_2nd_drop= 1"]

[jump target="*next"]

;----------------------------------------------------------------------------------
*ss_02
;----------------------------------------------------------------------------------

;****************************************
[bg storage="train_06.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_28.ogg"]

[:princess:][puri_w kao=1]
「你好！多洛―――」[rhp]
[:princess:][puri_w kao=0 ]
「嗯？告示条……」[rhp]

[off_all]

[::]
『暂时离席。正在某处作业，[rhr]
_　有事请自行寻找！若找不到就抱歉啦』[rhp]

[:princess:][puri_w kao=0]
「哎呀呀。不在呢」[rhp]
[:princess:][puri_w kao=12 ]
「没办法。虽然想聊聊，这次就算了吧」[rhp]

; 好感度+10
[eval exp="f.love_d  = f.love_d + 10"]

[eval exp="f.ss_drop = 2"]
[eval exp="f.ss_2nd_drop= 1"]

[jump target="*next"]

;----------------------------------------------------------------------------------
*ss_03
;----------------------------------------------------------------------------------

;****************************************
[bg storage="train_06.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_28.ogg"]

[:princess:][puri_w kao=1]
「你好呀～」[rhp]

[:drop:][drop kao=1]
「公主。有什么事吗？[rhr]
_　其实我现在正要去检查车内设备……」[rhp]

[:princess:][puri_w kao=1]
「这样啊。有什么我能帮忙的吗？」[rhp]

[:drop:][drop kao=14]
「这可不行！太不好意思了。[rhr]
_　您可是尊贵的客人。请好好休息吧」[rhp]
[:drop:][drop kao=5]
「那我就先告辞了」[rhp]

[:princess:][puri_w kao=1]
「嗯、嗯……」[rhp]

[off_drop]

[:princess:][puri_w kao=0 ]
[font color=0x4682b4]
（……也罢。外行帮忙可能反而会添乱吧）[rhp]
[resetfont]

; 好感度+10
[eval exp="f.love_d  = f.love_d + 10"]

[eval exp="f.ss_drop = 3"]
[eval exp="f.ss_2nd_drop= 1"]

[jump target="*next"]

;----------------------------------------------------------------------------------
*ss_04
;----------------------------------------------------------------------------------

;****************************************
[bg storage="train_06.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_28.ogg"]

[:princess:][puri_w kao=1]
「多洛普，现在有空吗？」[rhp]

[:drop:][drop kao=1]
「抱歉。我要准备午餐，先告辞了」[rhp]

[:princess:][puri_w kao=6 as=on ]
「克林不是主厨嘛，去找克林不就好了……」[rhp]

[:drop:][drop kao=13 as=on ]
「倒也不是不行，不过你们可能永远都吃不上饭了……」[rhp]

[:princess:]
「我没打算说服你」[rhp]

[:drop:][drop kao=1]
「没关系。我是因为想做才做的。[rhr]
_　对了，有什么想吃的吗？」[rhp]

[:princess:][puri_w kao=1]
「按多洛普喜欢的来就行」[rhp]

[:drop:][drop kao=0]
「我的……吗？　…………」[rhp]
[:drop:][drop kao=5]
「……明白了！那我先去问问其他人的需求」[rhp]
[:drop:]
「那么公主殿下，待会儿见」[rhp]

[off_drop]

[:princess:][puri_w kao=8 as=on ]
[font color=0x4682b4]
（……既然是给自己做饭，按自己喜好来不就行了。真奇怪……）[rhp]
[resetfont]

; 好感度+10
[eval exp="f.love_d  = f.love_d + 10"]

[eval exp="f.ss_drop = 4"]
[eval exp="f.ss_2nd_drop= 1"]

[jump target="*next"]

;----------------------------------------------------------------------------------
*ss_05
;----------------------------------------------------------------------------------

;****************************************
[bg storage="train_06.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_28.ogg"]



[:princess:][puri_w kao=1]
「多洛普！你好呀」[rhp]

[:drop:][drop kao=1]
「公主殿下日安。来得正好！」[rhp]

[:princess:][puri_w kao=4 as=on ]
「！怎、怎么了？」[rhp]
[:princess:]
[font color=0x4682b4]
（真稀奇。平时见到我就跑的）[rhp]
[resetfont]

[:drop:][drop kao=1]
「正要准备茶点，打算去餐厅召集大家呢。[rhr]
_　省得我跑一趟正好」[rhp]

[:princess:][puri_w kao=1]
「这次是茶点啊。明明早餐也是你准备的，太辛苦啦」[rhp]

[:drop:][drop kao=1]
「不会不会。我喜欢做饭所以不觉得累」[rhp]

[:princess:][puri_w kao=13 as=on ]
「既然本人乐意，虽然不太好但也没办法咯……」[rhp]


; 好感度+10
[eval exp="f.love_d  = f.love_d + 10"]

[eval exp="f.ss_drop = 5"]
[eval exp="f.ss_2nd_drop= 1"]

[jump target="*next"]


;----------------------------------------------------------------------------------
*ss_06
;----------------------------------------------------------------------------------

;****************************************
[bg storage="train_06.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_28.ogg"]




[:princess:][puri_w kao=1]
「多洛普——我们现在要玩多米诺牌……」[rhp]

[off_all]

[::]
『暂时离席。应该在某处工作，[rhr]
_　有事请自行寻找！若找不到就抱歉啦』[rhp]

[:princess:][puri_w kao=2 as=on ]
「又来这套……！这张纸条你都循环利用了吧」[rhp]

[off_all]

[::]
『附言：麻将大赛请恕我不参加』[rhp]

[:princess:][puri_w kao=8 as=on ]
「原来你知道啊！什么嘛……」[rhp]
[:princess:][puri_w kao=3 as=on ]
「………………」[rhp]

[off_all]

[:princess:]
[font color=0x4682b4]
（……多洛普应该不会做这种事吧……）[rhp]
[:princess:]
（………………他没在躲着我吧？）[rhp]
[resetfont]

; 好感度+10
[eval exp="f.love_d  = f.love_d + 10"]

[eval exp="f.ss_drop = 6"]
[eval exp="f.ss_2nd_drop= 1"]

[jump target="*next"]

;----------------------------------------------------------------------------------
*ss_07
;----------------------------------------------------------------------------------

;****************************************
[bg storage="train_06.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_28.ogg"]



[:princess:][puri_w kao=1]
「多洛普！我来找你玩……」[rhp]

[off_all]

[:drop:][drop kao=11]
「『目前不在座位。可能正在某处工作，有事的话请……」[rhp]

[:princess:][puri_w kao=2 as=on ]
「………………」[rhp]

[:drop:][drop kao=2 as=on hh=on ]
「……啊！！公主！？」[rhp]

[:princess:]
「诶、你每次都要重写那些内容吗！？不是直接重复使用？」[rhp]

[:drop:][drop kao=1]
「是的！偷工减料可不好」[rhp]

[:princess:][puri_w kao=6 as=on ]
「既然有工夫写那么长的文章[rhr]
_　不如陪我说说话我会更开心……」[rhp]

[:drop:][drop kao=13 as=on ]
「抱歉。现在这么说话的时候已经写完了」[rhp]

[:princess:][puri_w kao=6 as=on ]
「真是手巧呢……不对、不是这个意思啦」[rhp]

[off_puri]

[:drop:][drop kao=5 as=on ]
「那么公主、我先告辞了！」[rhp]

[off_drop]

[:princess:][puri_w kao=1]
「等、等等！　这样也可以ー！？」[rhp]


; 好感度+10
[eval exp="f.love_d  = f.love_d + 10"]

[eval exp="f.ss_drop = 7"]
[eval exp="f.ss_2nd_drop= 1"]

[jump target="*next"]

;----------------------------------------------------------------------------------
*ss_08
;----------------------------------------------------------------------------------

;****************************************
[bg storage="train_06.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_28.ogg"]


[:princess:][puri_w kao=3]
「你好ー……」[rhp]

[:drop:][drop kao=1]
「你好啊，公主」[rhp]

[:princess:][puri_w kao=3]
[font color=0x4682b4]
（哈啊……今天肯定又会被各种事情糊弄过去吧……）[rhp]
[resetfont]

[:drop:][drop kao=0]
「……咦，怎么今天好像没什么精神」[rhp]

[:princess:][puri_w kao=1]
「没……没有。没什么啦」[rhp]
「比起这个，工作呢？　没问题吗？」[rhp]

[:drop:][drop kao=7]
「嗯ー……」[rhp]
[:drop:][drop kao=13]
「……就一小会儿的话！」[rhp]

[:princess:][puri_w kao=4 as=on ]
「！　哎、真的吗？为什么！」[rhp]

[:drop:][drop kao=13]
「因为您总是一如既往地光顾。[rhr]
_　先稍微和公主说几句话再走吧」[rhp]

[:princess:][puri_w kao=4 as=on ]
「那、那个，呃……！」[rhp]
[:princess:][puri_w kao=14 hh=on ]
「―――多洛普的头发真漂亮呢。浅绿色太棒了！！」[rhp]

[:drop:][drop kao=1]
「是吗？谢谢您。[rhr]
_　以我的性格来说会不会有点太张扬了……」[rhp]

[:princess:]
「才不会呢！像阳光玫瑰葡萄一样超合适！」[rhp]

[:drop:][drop kao=13 as=on ]
[font color=0x4682b4]
（这算是在夸我吗……）[rhp]
[resetfont]


; 好感度+10
[eval exp="f.love_d  = f.love_d + 10"]

[eval exp="f.ss_drop = 8"]
[eval exp="f.ss_2nd_drop= 1"]

[jump target="*next"]

;----------------------------------------------------------------------------------
*ss_09
;----------------------------------------------------------------------------------

;****************************************
[bg storage="train_06.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_28.ogg"]

[:princess:][puri_w kao=1]
「多洛普。今天也来找你聊会儿天！」[rhp]

[:drop:][drop kao=1]
「您总是这么关照我。[rhr]
_　我正想着差不多该到您来的时间了」[rhp]

[:princess:][puri_w kao=7]
「对了呀，有件事我一直很好奇。[rhr]
_　你帽子上那颗大宝石，不重吗？」[rhp]

[:drop:][drop kao=7 ]
「嗯——倒是不觉得呢」[rhp]

[:princess:]
「我老担心帽子会因为重量滑下来耶」[rhp]

[:drop:][drop kao=5 ]
「没问题的公主。因为这辆是魔法电车，[rhr]
_　任何理由都不会让帽子滑落的」[rhp]

[:princess:][puri_w kao=13 as=on ]
「从各种意义上来说魔法真方便啊」[rhp]

; 好感度+10
[eval exp="f.love_d  = f.love_d + 10"]

[eval exp="f.ss_drop = 9"]
[eval exp="f.ss_2nd_drop= 1"]

[jump target="*next"]

;----------------------------------------------------------------------------------
*ss_10
;----------------------------------------------------------------------------------

;****************************************
[bg storage="train_06.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_28.ogg"]

[:princess:][puri_w kao=1]
「你好呀——多洛普还在吗？」[rhp]

[:drop:][drop kao=1]
「公主您好。我正准备去餐车呢」[rhp]

[:princess:][puri_w kao=1]
「哦！今天也要做点心吗——」[rhp]

[:drop:][drop kao=1]
「是的！今天可是很厉害的」[rhp]
[:drop:][drop kao=5 ]
「请看！是用阳光玫瑰葡萄做的点心！」[rhp]

[:princess:][puri_w kao=4 as=on ]
「诶」[rhp]

[:drop:][drop kao=13]
「自从上次和你聊过后就一直惦念着。[rhr]
_　难得有机会，就用来之不易的阳光玫瑰葡萄做点什么吧」[rhp]

[off_puri]

[:drop:][drop kao=5 ]
「那！我去叫大家过来。[rhr]
_　你也别迟到哦。回见！」[rhp]

[off_all]

[:princess:][puri_w kao=2 as=on ]
「多洛普！」[rhp]

[:drop:][drop kao=1]
「嗯？」[rhp]

[:princess:][puri_w kao=2 as=on ]
「阳光玫瑰葡萄……！保持原样就好！！」[rhp]

[:drop:][drop kao=4 as=on ]
「！」[rhp]

[:princess:]
「因为是高级品……！保持原样就好……！」[rhp]

[:drop:][drop kao=14]
「……！！明、明白了！感谢您的吩咐！」[rhp]
[:drop:][drop kao=13]
「这还是你第一次对我下命令呢。莫名有点开心。[rhr]
_　今后也请尽管吩咐哦。待会见！」[rhp]

[off_all]

[:princess:][puri_w kao=4 as=on ]
「呜……！」[rhp]
[:princess:][puri_w kao=3 as=on ]
[font color=0x4682b4]
（……明明只是想提个建议。我是不是有点傲慢了……）[rhp]
[resetfont]

; 好感度+10
[eval exp="f.love_d  = f.love_d + 10"]

[eval exp="f.ss_drop = 10"]
[eval exp="f.ss_2nd_drop= 1"]

[jump target="*next"]

;----------------------------------------------------------------------------------
*ss_11
;----------------------------------------------------------------------------------

;****************************************
[bg storage="train_06.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_28.ogg"]

[:drop:][drop kao=12]
「……………………」[rhp]

[off_all]

[:princess:][puri_w kao=1]
「啊，多洛普睡着了」[rhp]
[:princess:][puri_w kao=13]
「呵呵，多洛普这种松懈的表情可是相当罕见――――」[rhp]

[:drop:][drop kao=14]
[font size=27]
「啊——睡得好香！！」[rhp]
[resetfont]

[:princess:][puri_w kao=2 as=on ]
「哇！！」[rhp]

[:drop:][drop kao=1]
「咦，公主？您在这种地方做什么？」[rhp]

[:princess:][puri_w kao=2 as=on ]
「这是我的台词吧。你不是在睡觉吗？」[rhp]

[:drop:][drop kao=13 as=on ]
「太丢人了……是的，其实就睡了10分钟」[rhp]
[:drop:][drop kao=13 as=on ]
「我习惯频繁进行短时间睡眠。[rhr]
_　在这条铁道上，工作永远忙不完嘛！」[rhp]

[off_puri]

[:drop:][drop kao=5]
「哎呀，都这个点了。公主，我先告辞啦！」[rhp]

[off_drop]

[:princess:][puri_w kao=13 as=on ]
「加、加油哦～……」[rhp]

; 好感度+10
[eval exp="f.love_d  = f.love_d + 10"]

[eval exp="f.ss_drop = 11"]
[eval exp="f.ss_2nd_drop= 1"]

[jump target="*next"]

;----------------------------------------------------------------------------------
*ss_12
;----------------------------------------------------------------------------------

;****************************************
[bg storage="train_06.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_28.ogg"]

[:drop:][drop kao=1]
「呀公主。您心情怎么……」[rhp]

[:princess:][puri_w kao=5]
「说到长途旅行就会想到卡拉OK」[rhp]

[:drop:][drop kao=13 as=on ]
「突然说什么呢？」[rhp]

[:princess:]
「因为、杰特君不是说过嘛。[rhr]
_　这辆电车没有吗？　我想试试唱卡拉OK呢」[rhp]

[:drop:][drop kao=1]
「原来如此。需要的话可以用魔法变出设备哦」[rhp]

[:princess:][puri_w kao=1]
「真的！？　好高兴…………」[rhp]
[:princess:][puri_w kao=2]
「…………不、还是算了」[rhp]

[:drop:][drop kao=2 as=on ]
「为什么！？」[rhp]

[:princess:][puri_w kao=12]
「总觉得这种庸俗的东西不适合这条铁道的氛围」[rhp]

[:drop:][drop kao=2 as=on ]
「这、这样啊……」[rhr]
[font color=0x4682b4]
（到现在才说也太迟了吧……）[rhp]
[resetfont]

; 好感度+10
[eval exp="f.love_d  = f.love_d + 10"]

[eval exp="f.ss_drop = 12"]
[eval exp="f.ss_2nd_drop= 1"]

[jump target="*next"]

;----------------------------------------------------------------------------------
*ss_13
;----------------------------------------------------------------------------------

;****************************************
[bg storage="train_06.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_28.ogg"]

[:princess:][puri_w kao=2]
「嗯～～……」[rhp]

[:drop:][drop kao=1]
「表情很困扰呢，公主。有什么烦恼吗？」[rhp]

[:princess:][puri_w kao=2]
「多洛普他啊……有种人妻感呢」[rhp]

[:drop:][drop kao=6 as=on ]
「诶……？　啊？」[rhp]

[:princess:]
「该说是未亡人气质吧」[rhp]

[:drop:][drop kao=13 as=on ]
「…………虽然听你这么说我一点也不开心」[rhp]

[off_drop]

[:princess:][puri_w kao=2]
「窸窣……」[rhp]

[off_puri]

[:drop:][drop kao=0]
「？？」[rhp]

[off_drop]

[:princess:][puri_w kao=2]
「走路时会发出这种声音吧。窸窣……窸窣」[rhp]

[off_puri]

[:drop:][drop kao=6 as=on ]
[font color=0x4682b4]
（肯定是在博士那里看了奇怪的书吧……）[rhp]
[resetfont]

; 好感度+10
[eval exp="f.love_d  = f.love_d + 10"]

[eval exp="f.ss_drop = 13"]
[eval exp="f.ss_2nd_drop= 1"]

[jump target="*next"]

;----------------------------------------------------------------------------------
*ss_14
;----------------------------------------------------------------------------------

;****************************************
[bg storage="train_06.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_28.ogg"]

[:princess:][puri_w kao=3]
「……………………」[rhp]

[:drop:][drop kao=1]
「怎么了公主。今天也是副忧郁的表情呢」[rhp]

[:princess:][puri_w kao=3]
「窸窣……」[rhp]

[:drop:][drop kao=2 as=on ]
「…………这个话题还没完吗？　什么人妻怎么样的……」[rhp]

[:princess:][puri_w kao=3]
「我也想成为像多洛普那样、带着淡淡哀愁的女人……」[rhp]
[yurasu]
[:princess:][puri_w kao=2]
「刚这么说着，克林和杰特君就[rhr]
_　被大笑特笑了！不过份吗！？」[rhp]

[:drop:][drop kao=13 as=on ]
「呃、嗯……我有点不太明白呢……」[rhp]

[:princess:][puri_w kao=1]
「唉—。我也想变得像多洛普那样成熟啊！」[rhp]

[:drop:]
「成熟恐怕不是指那种事吧……」[rhp]

[off_puri]

[:drop:][drop kao=2 as=on ]
[font color=0x4682b4]
（……不过我竟然给人这种印象吗。[rhr]
_　真希望自己举止能更有男子气概些……）[rhp]
[:drop:][drop kao=13 ]
（不过能让我意识到这点，得感谢公主呢！）[rhp]
[resetfont]

; 好感度+10
[eval exp="f.love_d  = f.love_d + 10"]


[eval exp="f.ss_drop = 14"]
[eval exp="f.ss_2nd_drop= 1"]

[jump target="*next"]

;----------------------------------------------------------------------------------
*ss_15
;----------------------------------------------------------------------------------

;****************************************
[bg storage="train_06.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_28.ogg"]

[:princess:][puri_w kao=1]
「多洛普喜欢的食物是什么？」[rhp]

[:drop:][drop kao=1]
「虽不能算食物，硬要说的话是可可吧」[rhp]

[:princess:][puri_w kao=13]
「好可爱！难怪经常亲手做还这么美味」[rhp]

[:drop:][drop kao=5]
「其实我有点讲究。不仅绝对不用魔法，[rhr]
_　而且不是用热水冲泡而是用锅熬煮的」[rhp]

[:princess:][puri_w kao=1]
「所以才这么美味啊。[rhr]
_　本想尝试制作，但肯定做不出多洛普的味道吧」[rhp]

[:drop:][drop kao=4 ]
「哎……你说尝试制作」[rhp]

[:princess:][puri_w kao=13]
「想作为你总陪我聊天的谢礼。[rhr]
_　本打算做多洛普喜欢的食物当礼物……」[rhp]

[:drop:][drop kao=0 as=on hh=on ]
「………………」[rhp]

[:princess:][puri_w kao=14]
「嘛，虽然比不上但也努力试试吧。[rhr]
_　就算不好喝也要全部喝完哦？」[rhp]

[:drop:][drop kao=13 ]
「是……是的。非常感谢。从现在开始就非常期待了！」[rhp]

; 好感度+10
[eval exp="f.love_d  = f.love_d + 10"]


[eval exp="f.ss_drop = 15"]
[eval exp="f.ss_2nd_drop= 1"]

[jump target="*next"]

;----------------------------------------------------------------------------------
*ss_16
;----------------------------------------------------------------------------------

;****************************************
[bg storage="train_06.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_28.ogg"]

[:princess:][puri_w kao=0]
「………………」[rhp]

[:drop:][drop kao=13 as=on ]
「？　公、公主？　您脸上有什么……」[rhp]

[:princess:][puri_w kao=1]
「说起来多洛普，你最近不再躲着我了呢」[rhp]
[:princess:][puri_w kao=1]
「以前每次我来找你玩，你都说要工作逃掉了。[rhr]
_　但最近都会好好陪我说话，我很开心哦」[rhp]
[:princess:][puri_w kao=13]
「想到和你的关系稍微变好了些，真是感慨万千」[rhp]

[:drop:][drop kao=13 as=on ]
「哈哈……我那个，如你所知不太擅长『玩耍』。[rhr]
_　如果让你感到不快的话我很抱歉」[rhp]
[:drop:][drop kao=1 ]
「不过最近，我开始期待公主过来找我了。[rhr]
_　因为你总是做些有趣的事逗我开心」[rhp]

[:princess:][puri_w kao=13 as=on ]
「有、有趣倒是没自觉……不过好高兴！」[rhp]
[:princess:][puri_w kao=1 ]
「呐，以后也能来找你玩吗？」[rhp]

[:drop:][drop kao=1]
「当然。随时恭候」[rhp]

[:princess:][puri_w kao=14 hh=on ]
「嘿嘿……！ 谢谢你，多洛普！以后也请多关照」[rhp]

[:drop:][drop kao=14]
「我才是。请多指教」[rhp]

; 好感度+10
[eval exp="f.love_d  = f.love_d + 10"]


[eval exp="f.ss_drop = 16"]
[eval exp="f.ss_2nd_drop= 1"]

[jump target="*next"]

;----------------------------------------------------------------------------------
*ss_2nd
;----------------------------------------------------------------------------------

;****************************************
[bg storage="train_06.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_28.ogg"]

[:princess:][puri_w kao=1]
「午安，多洛……」[rhp]

[off_puri]

[:drop:][drop kao=12]
「………………」[rhp]

[:princess:][puri_w kao=1]
[font color=0x4682b4]
（睡着了……呼呼，总是这么辛苦呢）[rhp]
[:princess:][puri_w kao=13]
（……好吧！现在先不打扰他了）[rhp]
[resetfont]

[jump target="*next"]

;----------------------------------------------------------------------------------
;----------------------------------------------------------------------------------

*next

#
[off_all]

;ev_7への分岐
[if exp="f.ev_a_07 ==1 && f.nigmode == 1"]
[jump storage="ev_a_07.ks" target="*start"]

;ev_6への分岐
[elsif exp="f.ev_a_06 ==1 && f.nigmode == 1"]
[jump storage="ev_a_06.ks" target="*start"]

;ev_3への分岐
[elsif exp="f.ev_a_03 ==1 && f.nigmode == 1"]
[jump storage="ev_a_03.ks" target="*start"]

;ev_2への分岐
[elsif exp="f.ev_a_02 ==1 && f.nigmode == 1"]
[jump storage="ev_a_02.ks" target="*start"]

;夜モードの場合
[elsif exp="f.nigmode == 1"]
[jump storage="ss_main.ks" target="*start"]

;昼モード
[else]
[jump storage="ss_select.ks" target="*select_scene_nig"]
[endif]


