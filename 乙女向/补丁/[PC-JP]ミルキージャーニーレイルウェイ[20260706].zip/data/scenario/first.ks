

[title name="ミルキージャーニーレイルウェイ"]

;-------------------------------------------------------------------------------

; プレイヤー操作禁止
[stop_keyconfig]

; メニューアイコン非表示
[hidemenubutton]

;メッセージボックス非表示
[layopt layer="message" visible=false]

;-------------------------------------------------------------------------------


;プラグインたち
[loadjs storage="myscript.js]
[plugin name=bg_rule]
[plugin name=mask_rule]
[plugin name="menu_plugin"]
[plugin name="menu_se" button_menu_clickse="btn_02.ogg" button_menu_enterse="btn_01.ogg" save_list_clickse="btn_02.ogg"]
[call storage="skip_effect.ks"]

; マクロ
[call storage="macro.ks"]

; システム系
[call storage="tyrano.ks"]

;-------------------------------------------------------------------------------


;サークルネーム
[bg storage="black.jpg" time=2000]
[bg storage="title/isaraza.png" time=2000]

[wait time=1000]

;-------------------------------------------------------------------------------

[mask time=2000 color=0x000000]

@jump storage="title.ks"

[s]


