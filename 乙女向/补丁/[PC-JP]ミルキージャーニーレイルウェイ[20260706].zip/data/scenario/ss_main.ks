﻿
*start

[iscript]
delete f.nigmode;
[endscript]

[eval exp="f.daymode = 1"]
[jump target="*ssmain_16" cond="f.ssmain >= 15"]
[jump target="*ssmain_15" cond="f.ssmain >= 14"]
[jump target="*ssmain_14" cond="f.ssmain >= 13"]
[jump target="*ssmain_13" cond="f.ssmain >= 12"]
[jump target="*ssmain_12" cond="f.ssmain >= 11"]
[jump target="*ssmain_11" cond="f.ssmain >= 10"]
[jump target="*ssmain_10" cond="f.ssmain >= 9"]
[jump target="*ssmain_09" cond="f.ssmain >= 8"]
[jump target="*ssmain_08" cond="f.ssmain >= 7"]
[jump target="*ssmain_07" cond="f.ssmain >= 6"]
[jump target="*ssmain_06" cond="f.ssmain >= 5"]
[jump target="*ssmain_05" cond="f.ssmain >= 4"]
[jump target="*ssmain_04" cond="f.ssmain >= 3"]
[jump target="*ssmain_03" cond="f.ssmain >= 2"]
[jump target="*ssmain_02" cond="f.ssmain == 1"]
[jump target="*ssmain_01"]

;---------------------------------------------------------------------------------------------
*ssmain_01
;---------------------------------------------------------------------------------------------

;****************************************

[s_mask graphic="rule/krke_w.png" effect="fadeInLeftBig" time=1500]
[layopt layer="message0" visible="true"]
; ウィンドゥ表示
[anim name="message_outer" time="1000" opacity="255"]
; メニューアイコン表示
[showmenubutton]
[bg storage="train_04.jpg" time=200]
[s_mask_off effect="fadeOutRightBig" time=1500 ]

;****************************************

[bgm storage="bgm_02.ogg"]

翌日[rhp]

[:drop:][drop kao=1 ]
「到了哦公主。这就是昨天没能给您介绍的……」[rhp]

[:princess:][puri_w kao=1 ]
「博士的房间……对吧！」[rhp]

[:drop:][drop kao=1 ]
「是的。他搞研究时经常把自己关在房间里。[rhr]
_　昨天刚好碰上那种状态，所以实在没办法」[rhp]

[:princess:][puri_w kao=1 ]
「这里的座椅比其他车厢豪华呢？」[rhp]

[:drop:][drop kao=1 ]
「他们是VIP所以坐特等席」[rhp]

[:princess:][puri_w kao=0 ]
「们？」[rhp]

[:drop:][drop kao=1 ]
「嗯，博士和另一个人……」[rhp]

[yurasu]
[off_all]

[:unknown:]
「啊―――――！！！！！！！！！！」[rhp]

[:princess:][puri_w kao=0 as=on ]
「！！」[rhp]

[:unknown:][peku kao=1]
「来啦！！　新公主！！」[rhp]

[off_all]

[:princess:][puri_w kao=4 as=on ]
「新？」[rhp]

[:drop:][drop kao=13 as=on ]
「那、那个先放一边。这位是沃尔佩克拉小姐哦」[rhp]

[:vulpecula:][peku kao=14]
「请多关照啦」[rhp]

[:princess:][puri_w kao=1 ]
「请多关照。没想到还有这么小的孩子」[rhp]

[off_all]
[yurasu]

[bg storage="train_07.jpg" time=500]

[:vulpecula:][peku kao=1]
「博士―――！！！　公主来啦！！」[rhp]

[off_all]

[:princess:][puri_w kao=2 as=on ]
「！！！　博士……！　是传闻中的达克内布拉博士对吧！」[rhp]

[:drop:][drop kao=13 as=on ]
「不用这么紧张啦」[rhp]

[:princess:]
「可、可是。挂着这么多听起来很厉害的头衔，[rhr]
_　根本想象不出是什么样的人啦……」[rhp]

[off_all]

[:darknebula:][hakase kao=1]
「呀！　你就是新公主吧！」[rhp]

[:princess:][puri_w kao=2 as=on ]
「！　您您您您好达克内布拉博士」[rhp]

[:darknebula:][hakase kao=0 ]
「唔……好像被害怕了？」[rhp]

[:vulpecula:][peku kao=1]
「因为博士太大只啦。像怪兽一样嘛」[rhp]

[:darknebula:][hakase kao=1]
「哦！在你眼里我像怪兽一样吗。[rhr]
_　那不可思议的视野……真让人在意呢」[rhp]

[off_all]

[:drop:][drop kao=1 ]
「不行哦博士。她才刚来，[rhr]
_　请不要吓着她」[rhp]

[off_all]

[:darknebula:][hakase kao=1]
「哎呀，说得对。都还没自我介绍呢……咳咳」[rhp]
[:darknebula:][hakase kao=5]
「重新介绍一下，公主。我是达克内布拉。[rhr]
_　大家都叫我博士，你也可以随意称呼」[rhp]

[:vulpecula:][peku kao=1]
「博库是博士的助手！[rhr]
_　大家都叫我佩奇，你也叫我佩奇就好啦！」[rhp]

[:princess:][puri_w kao=1 ]
「好、好的。那么，那个……博士！可以问个问题吗？」[rhp]

[:darknebula:][hakase kao=1]
「嗯，什么问题」[rhp]

[:princess:][puri_w kao=1 ]
「博士到底是什么领域的博士呢？」[rhp]

[:vulpecula:][peku kao=1]
「呃——。天文学家和心理学家和植物学家和经济学家和天文学家和……」[rhp]

[:darknebula:][hakase kao=1]
「啊佩奇，你说了两次『天文学家』哦」[rhp]

[:vulpecula:][peku kao=14 ]
「咦？是、是这样吗？」[rhp]
[:2nin:][hakase kao=5 ]
「啊哈哈哈！」[rhr]
「喵哈哈哈哈！」[rhp]

[:princess:][puri_w kao=2 as=on ]
「？那个，所以？」[rhp]

[off_all]

[:darknebula:][hakase kao=1 ]
「那我要继续做研究就先走啦！」[rhp]

[off_all]

[:vulpecula:][peku kao=1]
「随时来玩哦——！」[rhp]

[off_all]

[se storage="door_10.ogg"]

[:princess:][puri_w kao=2 as=on ]
「就、就这么走了……」[rhp]

[:drop:][drop kao=1 ]
「看，都是些有趣的人吧？」[rhp]


;【変な人たちだね】
[glink clickse="btn_01.ogg" x="290" y="160" width="610" high="72" text="変な人たちだね" target="**main_q1a" graphic="glink_c.png" enterimg="glink_d.png"]
;【ますます楽しくなりそう】
[glink clickse="btn_01.ogg" x="290" y="290" width="610" high="72" text="ますます楽しくなりそう" target="**main_q1b" graphic="glink_a.png" enterimg="glink_b.png"]
[s]

*main_q1a

[:princess:][puri_w kao=1 ]
「确、确实……虽然有点古怪」[rhp]

[:drop:][drop kao=1 ]
「我们也半斤八两呢。[rhr]
_　一定公主也会很快适应的」[rhp]

[jump target="*tutti"]

*main_q1b

; 好感度+10
[eval exp="f.love_d  = f.love_d + 10"]

[:princess:][puri_w kao=1 ]
「说得对。从今往后会越来越有趣呢！」[rhp]

[:drop:][drop kao=1 ]
「是的！肯定也能给公主带来良好影响哦」[rhp]

*tutti

[:drop:][drop kao=1 ]
「那么基本问候也结束了，接下来就自由活动吧。[rhr]
_　在铁道内期间可以随意行动哦」[rhp]

[:princess:][puri_w kao=1 ]
「可以去见其他人吗？」[rhp]

[:drop:][drop kao=1 ]
「当然。大家应该都在各自的包厢或车厢里，[rhr]
_　为加深交情请尽管去搭话吧」[rhp]
[:drop:][drop kao=1 ]
「累了就在自己房间好好休息。[rhr]
_　用餐都是集体进行的，早上我会去叫您的」[rhp]

[:princess:][puri_w kao=1 ]
「真是无微不至……」[rhp]

[:drop:][drop kao=1 ]
「顾客就是神明嘛。请交给我们」[rhp]

[:princess:][puri_w kao=1 ]
「虽然有点不好意思的感觉，但也不讨厌啦」[rhp]
[:princess:][puri_w kao=1 ]
「能做的事我会自己做，有问题要帮我哦。[rhr]
_　今后请多指教，多洛普！」[rhp]

[:drop:][drop kao=1 ]
「嗯，我这边也是！」[rhp]

#
[off_all]

[eval exp="f.ssmain = 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ssmain_02
;---------------------------------------------------------------------------------------------

[fbgm]

;****************************************
[set_00 storage="train_03.jpg" time=1000 ]
;****************************************

[bgm storage="bgm_01.ogg"]


翌日[rhp]
在餐车用完早餐的我，[rhr]
不知怎的就和快斗两个人在餐车里聊了起来。[rhp]

[:princess:][puri_w kao=0 ]
「话说刚刚注意到……」[rhp]
[:princess:][puri_w kao=0 ]
「这里算宇宙对吧。重力什么的怎么处理的？[rhr]
_　为什么我们没飘起来……」[rhp]

[:kite:][kite kao=0 ]
「公主」[rhp]

[:princess:][puri_w kao=1 ]
「！」[rhp]

[:kite:][kite kao=0 ]
「现在明白了吗？」[rhp]

[:princess:][puri_w kao=2 ]
「……！　原来如此」[rhp]

;【１.魔法の世界だから関係ない】
[glink clickse="btn_01.ogg" x="290" y="160" width="610" high="72" text="魔法の世界だから関係ない" target="*main_q2a" graphic="glink_c.png" enterimg="glink_d.png"]
;【２.カイトのおかげで関係ない】
[glink clickse="btn_01.ogg" x="290" y="290" width="610" high="72" text="カイトのおかげで関係ない" target="*main_q2b" graphic="glink_a.png" enterimg="glink_b.png"]
[s]

*main_q2a

[:princess:][puri_w kao=1 ]
「这里是魔法世界，所以那些都不重要」[rhp]

[:kite:][kite kao=0 ]
「就是这个道理。所谓的剧情需要啦」[rhp]

[jump target="*tutti_2"]

*main_q2b

; 好感度+10
[eval exp="f.love_k  = f.love_k + 10"]

[:princess:][puri_w kao=1 ]
「多亏快斗抵消了重力呢。我猜的——」[rhp]

[:kite:][kite kao=0 ]
「噢 察觉到了嘛。[rhr]
_　没错，正因为我的存在抵消了这个世界重力」[rhp]

[:princess:][puri_w kao=1 ]
[font color=0x4682b4]
（接梗挺快啊）」[rhp]
[resetfont]

*tutti_2

[:princess:][puri_w kao=1 ]
「说起来不光是重力，[rhr]
_　像这样也能呼吸 现在才问可能有点晚」[rhp]

[:kite:][kite kao=0 ]
「有学到东西吗 公主君」[rhp]
「呵呵。这个世界 搞不懂的事情还多着呢……！」[rhp]

[:princess:][puri_w kao=1 ]
「嗯。总之别想得太复杂就行」[rhp]

[:kite:][kite kao=0 ]
「那我回房间了」[rhp]

[:princess:][puri_w kao=1 ]
「谢谢快斗 陪我聊天」[rhp]

[:kite:][kite kao=0 ]
「客气啥 拜——」[rhp]

#
[off_all]

[iscript]
delete f.ss_2nd_drop ;
delete f.ss_2nd_kite ;
delete f.ss_2nd_riri ;
delete f.ss_2nd_hati ;
delete f.ss_2nd_hkpk ;
[endscript]

[eval exp="f.ssmain = 2"]
[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ssmain_03
;---------------------------------------------------------------------------------------------

[fbgm]

;****************************************
[set_00 storage="train_05.jpg" time=1000 ]
;****************************************

[bgm storage="bgm_04.ogg"]


当天夜里。[rhr]
在观景室眺望星空时 突然有个疑问浮上心头。[rhp]

[:princess:][puri_w kao=0 ]
「…………公主到底是什么？」[rhp]

[:quadrillion:][riri kao=6 ]
「丑八怪的隐语」[rhp]

[:princess:][puri_w kao=2 as=on ]
「呜呀！！」[rhp]

[:quadrillion:][riri kao=1]
「哈啰~ 摆着张忧郁脸怎么了？[rhr]
_　丑度加成都要爆表了哦」[rhp]

[:princess:][puri_w kao=2 as=on ]
「还是一如既往的失礼……」[rhp]
[:princess:][puri_w kao=2 as=on ]
「其实呢 我一直在想为什么自己会被叫做公主」[rhp]
[:princess:][puri_w kao=2 as=on ]
「虽然由我自己来说有点那啥，但这名字是不是太夸张了？」[rhp]

[:quadrillion:][riri kao=0]
「嗯」[rhp]

[:princess:][puri_w kao=2 as=on ss=on ]
[font color=0x4682b4]
（明明否定一下就好了……）[rhp]
[resetfont]

[:quadrillion:][riri kao=5]
「而我的名字可是兼具了美丽、力量与智慧，简直是为我量身定制的呢」[rhp]

;【１は？】
[glink clickse="btn_01.ogg" x="290" y="160" width="610" high="72" text="は？" target="*main_q3a" graphic="glink_c.png" enterimg="glink_d.png"]
;【２はい】
[glink clickse="btn_01.ogg" x="290" y="290" width="610" high="72" text="はい" target="*main_q3b" graphic="glink_a.png" enterimg="glink_b.png"]
[s]

*main_q3a

; 好感度+10
[eval exp="f.love_r  = f.love_r + 10"]

[:princess:][puri_w kao=6 ]
「哈？」[rhp]

[:quadrillion:][riri kao=1]
「干嘛。难道不对吗」[rhp]
[:quadrillion:]
「听说过千万兆切割吗。[rhr]
_　不是指发型哦？是说宝石啦」[rhp]

[:princess:][puri_w kao=0 ]
「！难道我也是那种感觉？」[rhp]

[:quadrillion:][riri kao=1]
「嘛差不多。这里的乘务员都是」[rhp]

[:princess:][puri_w kao=1 ]
「哦～！被你这么一说[rhr]
_　突然觉得公主这个称呼也挺美妙的」[rhp]

[jump target="*tutti_3"]

*main_q3b

[:princess:][puri_w kao=1 ]
「好的」[rhp]

[:quadrillion:][riri kao=6 as=on ]
「突然这么老实……好可怕」[rhp]

[:princess:][puri_w kao=2 ]
「要是你又歇斯底里起来就麻烦了……」[rhp]

[:quadrillion:][riri kao=2]
「哈！？正合我意啊库索布斯！[rhr]
_　要闹个天翻地覆吗？」[rhp]

[:princess:][puri_w kao=2 as=on ss=on ]
「不必了！」[rhp]

*tutti_3

[:quadrillion:][riri kao=6 ]
「真是的……算了」[rhp]
[:quadrillion:][riri kao=11 ]
「那人家先走啦。[rhr]
_　别在这种地方发呆，去做点更有意义的事吧」[rhp]

[:princess:][puri_w kao=1 ]
「到——」[rhp]

[off_all]

[::]
莫名被训了一顿。可恶！[rhp]


[iscript]
delete f.ss_2nd_drop ;
delete f.ss_2nd_kite ;
delete f.ss_2nd_riri ;
delete f.ss_2nd_hati ;
delete f.ss_2nd_hkpk ;
[endscript]

[eval exp="f.ssmain = 3"]
[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ssmain_04
;---------------------------------------------------------------------------------------------

[fbgm]

;****************************************
[set_00 storage="train_03.jpg" time=1000 ]
;****************************************

[bgm storage="bgm_04.ogg"]


当天夜里[rhp]

[:princess:][puri_w kao=2 as=on ss=on ]
「……………………」[rhp]

[:heartshape:][hati kao=2 as=on ]
「怎么了公主……！脸色惨白啊！」[rhp]
[:heartshape:][hati kao=2 as=on ]
「要上厕所吗！？」[rhp]

[:princess:]
「这样啊……」[rhp]

[:heartshape:]
「这样啊！那……诶！？」[rhp]

[:princess:][puri_w kao=6 as=on ]
「我、我发现了……[rhr]
_　来到这里后一次都没去过厕所……」[rhp]
[:princess:][puri_w kao=6 as=on ]
「我的身体究竟出什么问题了呢？」[rhp]

[:jet:][jet kao=6 as=on ]
「谁知道啊……不对也不算完全不知道」[rhp]

[:princess:][puri_w kao=2 as=on ]
「难道这又是惯例操作？」[rhp]

[:jet:][jet kao=12]
「没错。魔法」[rhp]

[:princess:]
「无法接受！」[rhp]

[:2nin:]
「！？」[rhr]
「！？」[rhp]

[:princess:]
「啊！等等。莫非我吃下去的东西……」[rhp]

;【１胃に入ってから魔法で消えた？】
[glink clickse="btn_01.ogg" x="290" y="160" width="610" high="72" text="胃に入ってから魔法で消えた？" target="*main_q4a" graphic="glink_c.png" enterimg="glink_d.png"]
;【２そもそも食事にカウントされてない？】
[glink clickse="btn_01.ogg" x="290" y="290" width="610" high="72" text="そもそも食事にカウントされてない？" target="*main_q4b" graphic="glink_a.png" enterimg="glink_b.png"]
[s]

*main_q4a

[:princess:][puri_w kao=1 ]
「进入胃里后就被魔法啪地变没了吧！」[rhp]

[:jet:][jet kao=1]
「怎么可能啦」[rhp]

[:princess:][puri_w kao=1 ]
「诶～」[rhp]

[jump target="*tutti_4"]

*main_q4b

; 好感度+10
[eval exp="f.love_h  = f.love_h + 10"]

[:princess:][puri_w kao=1 ]
「说到底食材本身就不是真的，[rhr]
_　不管是靠魔法变出来还是做饭，都会让人受不了吧！」[rhp]

[:heartshape:][hati kao=1]
「给你满分！」[rhp]

[:princess:][puri_w kao=1 ]
「太好啦！」[rhp]

*tutti_4

[:jet:][jet kao=1]
「不会饿肚子是优点，不过总觉得有点空虚呢」[rhp]

[:heartshape:][hati kao=1]
「确实啊。所以我偶尔会偷偷换成真货！！！」[rhp]

[:princess:][puri_w kao=2 ss=on as=on ]
「诶诶诶！那现在岂不是有各种东西在体内……」[rhp]

[:jet:][jet kao=1]
「多洛普怎么可能发现不了。[rhr]
_　每次都被他重置回去啦」[rhp]

[:2nin:]
「什么！？」[rhr]
「呼……」[rhp]

[fbgm]

#
[off_all]

[iscript]
delete f.ss_2nd_drop ;
delete f.ss_2nd_kite ;
delete f.ss_2nd_riri ;
delete f.ss_2nd_hati ;
delete f.ss_2nd_hkpk ;
[endscript]

[eval exp="f.ssmain = 4"]
[eval exp="f.ev_a_02 = 1"]


[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ssmain_05
;---------------------------------------------------------------------------------------------

;****************************************
[set_00 storage="train_08.jpg" time=1000 ]
;****************************************

[bgm storage="bgm_08.ogg"]

翌日清晨。[rhp]
机能在游乐园尽情游玩了三天。[rhr]
想到这样的旅行今后会一直持续下去就无比幸福……！[rhp]

[:sausu:][sausu kao=1 ]
「哟 公主」[rhp]

[:princess:][puri_w kao=1 ]
「！　南。你好呀」[rhp]

[:sausu:][sausu kao=1 ]
「好久不见了呢」[rhp]

[:princess:][puri_w kao=1 ]
「今天不搞偷袭了吗」[rhp]

[:sausu:][sausu kao=1 ]
「还耿耿于怀啊……本来也不是那种性质吧」[rhp]

[:princess:][puri_w kao=1 ]
「抱歉抱歉开玩笑的。所以有事吗？」[rhp]

[:sausu:][sausu kao=1 ]
「来听听你昨天的感想」[rhp]
「去游乐园了吧？玩得开心吗？」[rhp]

[:princess:][puri_w kao=1 ]
「嗯！超级开心。因为是第一次去游乐园惊、[rhr]
_　惊讶原来世上还有那样的世界！」[rhp]

[:sausu:][sausu kao=1 ]
「这样啊。太好了。烟花也很漂亮吧」[rhp]

[:princess:][puri_w kao=1 ]
「……！南当时也在那里吗？」[rhp]

[:sausu:][sausu kao=1 ]
「啊……，……」[rhp]
[:sausu:][sausu kao=1 ]
「……呵呵，你猜？我可是无所不知的」[rhp]

[:princess:][puri_w kao=1 ]
「这样啊。真不愧是神明大人」[rhp]

[:sausu:][sausu kao=1 ]
「倒也未必」[rhp]
[:sausu:][sausu kao=1 ]
「那我就先告辞了。愿你接下来的旅途愉快」[rhp]

[:princess:][puri_w kao=1 ]
「嗯！」[rhp]

[off_all]

[::]
随后南用魔法消失在了某处。[rhp]
忙忙碌碌的……是在赶时间吗？[rhr]
明明可以更悠闲一点的。[rhp]

[:princess:][puri_w kao=1 ]
「……好了，我也该准备出发了」[rhp]

[off_all]

[::]
距离下一站目的地还有时间。[rhr]
在那之前希望能和大家变得更亲近呢！[rhp]

[fbgm]
#
[off_all]

[iscript]
delete f.ss_2nd_drop ;
delete f.ss_2nd_kite ;
delete f.ss_2nd_riri ;
delete f.ss_2nd_hati ;
delete f.ss_2nd_hkpk ;
[endscript]

[eval exp="f.ssmain = 5"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ssmain_06
;---------------------------------------------------------------------------------------------

;****************************************
[set_00 storage="train_01.jpg" time=1000 ]
;****************************************

[bgm storage="bgm_04.ogg"]

翌日。[rhp]
在餐车欢聚后，回到普通车厢正发着呆时，[rhr]
被多洛普和快斗搭话了。[rhp]

[chara_part name="drop" body=base kao=1 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:drop:]
「晚上好，公主」[rhp]

[:kite:]
「在这种地方干什么呢」[rhp]

[:princess:][puri_w kao=1 ]
「在看外面。觉得好漂亮哦」[rhp]

[:kite:][kite kao=0 ]
「这种事在房间也能做啊。怪人」[rhp]

[:princess:][puri_w kao=1 ]
「我就喜欢普通车厢。因为……」[rhp]

;【１鉄道の雰囲気を味わいたいし】
[glink clickse="btn_01.ogg" x="290" y="160" width="610" high="72" text="鉄道の雰囲気を味わいたいし" target="*main_q6a" graphic="glink_c.png" enterimg="glink_d.png"]
;【２ちょっと人気がある方が落ち着くし】
[glink clickse="btn_01.ogg" x="290" y="290" width="610" high="72" text="ちょっと人気がある方が落ち着くし" target="*main_q6b" graphic="glink_a.png" enterimg="glink_b.png"]
[s]

*main_q6a

; 好感度+10
[eval exp="f.love_d  = f.love_d + 10"]

[:princess:][puri_w kao=1 ]
「难得有机会不是该好好感受铁道氛围嘛？」[rhp]

[:drop:][drop kao=1 ]
「听你这么说我很高兴。[rhr]
_　确实这里能感受到单人包厢没有的铁道原本的风情呢」[rhp]

[:kite:][kite kao=0 ]
「还风情。你是老头子吗多洛普」[rhp]

[:drop:][drop kao=6 as=on ]
「有、有什么关系嘛反正……」！[rhp]

[jump target="*tutti_6"]

*main_q6b

; 好感度+10
[eval exp="f.love_k  = f.love_k + 10"]

[:princess:][puri_w kao=1 ]
「不觉得稍微有点人气息反而更安心吗？」[rhp]

[:kite:][kite kao=0 ]
「啊——这个嘛」[rhp]

[:drop:][drop kao=1 ]
「莫非这就是[rhr]
_　快斗先生总在普通车厢睡觉的原因？」[rhp]

[:kite:][kite kao=0 ]
「老子才没这么可爱的理由。单纯喜欢宽敞房间」[rhp]

*tutti_6

[:drop:][drop kao=1 ]
「总之您能享受旅途就再好不过了。[rhr]
_　今天也请多多关照。公主！」[rhp]

[:princess:][puri_w kao=1 ]
「彼此彼此！快斗也请多指教」[rhp]

[:kite:][kite kao=0 ]
「好嘞好嘞—」[rhp]

[fbgm]

#
[off_all]

[iscript]
delete f.ss_2nd_drop ;
delete f.ss_2nd_kite ;
delete f.ss_2nd_riri ;
delete f.ss_2nd_hati ;
delete f.ss_2nd_hkpk ;
[endscript]

[eval exp="f.ssmain = 6"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ssmain_07
;---------------------------------------------------------------------------------------------

;****************************************
[set_00 storage="train_03.jpg" time=1000 ]
;****************************************

[bgm storage="bgm_03.ogg"]

翌日。[rhp]
简单用完早餐后，[rhr]
我和哈蒂君他们正热络地闲聊着。[rhp]

[chara_part name="jet" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:princess:][puri_w kao=1 ]
「诶！那你们之前也去过很多地方旅行呢」[rhp]

[:heartshape:][hati kao=1]
「对。海边山上城市乡下，那可去过不少！」[rhp]

[:princess:][puri_w kao=1 ]
「两人觉得最开心的地方是哪里？」[rhp]

[:heartshape:][hati kao=1]
「我还是选地中海！」[rhp]

[:princess:][puri_w kao=2 ]
「咦……？哈蒂君你……？」[rhp]

[:heartshape:][hati kao=1]
「因为听说土里会有海就兴奋得不行，[rhr]
_　结果被想象与现实的落差给耍了！」[rhp]

[:princess:][puri_w kao=1 ]
「啊，原来如此」[rhp]

[:heartshape:][hati kao=6 as=on ]
「你干嘛松口气啊？」[rhp]

[:jet:][jet kao=11]
「对我而言有哈蒂在的地方就是最佳」[rhp]

[:heartshape:][hati kao=14 ]
「杰特……！[rhr]
_　你这家伙就只会说漂亮话呢！」[rhp]

;【１確かにハティくんといると楽しそう！】
[glink clickse="btn_01.ogg" x="290" y="160" width="610" high="72" text="確かにハティくんといると楽しそう！" target="*main_q7a" graphic="glink_c.png" enterimg="glink_d.png"]
;【２ジェットくんは本当にハティくんが好きなんだね】
[glink clickse="btn_01.ogg" x="290" y="290" width="610" high="72" text="ジェットくんは本当にハティくんが好きだね" target="*main_q7b" graphic="glink_a.png" enterimg="glink_b.png"]
[s]

*main_q7a

; 好感度+10
[eval exp="f.love_h  = f.love_h + 10"]

[:princess:][puri_w kao=1 ]
「确实和哈蒂君在一起时很开心！」[rhp]

[:heartshape:][hati kao=1]
「谢啦！有公主在我也很开心啊！」[rhp]

[:princess:][puri_w kao=1 ]
「嘿嘿……别、别说这种让人害羞的话啦」[rhp]

[jump target="*tutti_7"]

*main_q7b

[:jet:][jet kao=1]
「对吧？你总是很有趣又能带动气氛，是最棒的搭档」[rhp]

[:heartshape:][hati kao=1]
「这话该我说才对。一直以来谢谢你，杰特！」[rhp]

*tutti_7

[:heartshape:][hati kao=1]
「……啊！！」[rhp]

[:jet:][jet kao=1]
「怎么了？」[rhp]

[:heartshape:][hati kao=1]
「糟了，我忘了……[rhr]
_　今天是把克林的粉底换成糯米粉的日子」[rhp]

[:princess:][puri_w kao=1 ]
「还有这种日常？」[rhp]

[:heartshape:][hati kao=1]
「不能这样下去了！[rhr]
_　趁克林发现前快行动，杰特！」[rhp]

[:jet:][jet kao=1]
「是是」[rhp]

[:princess:][puri_w kao=1 ]
[font color=0x4682b4]
（…………。还、还是装作没听见吧……）[rhp]
[resetfont]

[fbgm]

#
[off_all]

[iscript]
delete f.ss_2nd_drop ;
delete f.ss_2nd_kite ;
delete f.ss_2nd_riri ;
delete f.ss_2nd_hati ;
delete f.ss_2nd_hkpk ;
[endscript]

[eval exp="f.ssmain = 7"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ssmain_08
;---------------------------------------------------------------------------------------------

;****************************************
[set_00 storage="train_03.jpg" time=1000 ]
;****************************************

[bgm storage="bgm_03.ogg"]

那天早晨。[rhp]
我目睹了令人震惊的景象。[rhp]

[:quadrillion:][riri kao=3]
「………………」[rhp]

[:princess:][puri_w kao=2 as=on ]
「克、克林居然……在烦恼」[rhp]

[:quadrillion:][riri kao=6]
「哈"？我说啊。我也会偶尔烦恼的好吗」[rhp]
[:quadrillion:][riri kao=6]
「……算了。喂布兹，[rhr]
_　难得机会想听听你的意见」[rhp]

[:princess:][puri_w kao=1 ]
「怎、怎么了？真稀奇」[rhp]

[:quadrillion:][riri kao=1]
「比基尼和潜水服，你觉得多洛普适合穿哪种？」[rhp]


;【１ビキニ】
[glink clickse="btn_01.ogg" x="290" y="160" width="610" high="72" text="ビキニ" target="*main_q8a" graphic="glink_c.png" enterimg="glink_d.png"]
;【２ウェットスーツ】
[glink clickse="btn_01.ogg" x="290" y="290" width="610" high="72" text="ウェットスーツ" target="*main_q8b" graphic="glink_a.png" enterimg="glink_b.png"]
[s]

*main_q8a

; 好感度+10
[eval exp="f.love_r  = f.love_r + 10"]

[:princess:][puri_w kao=1 ]
「比基尼！」[rhp]

[:quadrillion:][riri kao=1]
「姑且问问理由？」[rhp]

[:princess:][puri_w kao=1 ]
「因为想看」[rhp]

[:quadrillion:][riri kao=1]
「男士比基尼可是高难度哟。[rhr]
_　多洛普有那种胆量吗」[rhp]

[:princess:][puri_w kao=1 ]
「要是以顾客需求为名或许……」[rhp]

[:quadrillion:][riri kao=6 as=on ]
「你只有这种时候特别狡猾……[rhr]
_　不过我并不讨厌哦」[rhp]

[jump target="*tutti_8"]

*main_q8b

[:princess:][puri_w kao=1 ]
「肯定是潜水服啊。比、比基尼什么的怎么可能……！」[rhp]

[:quadrillion:][riri kao=1]
「果然是这样呢。就算有比基尼之类的也不知道他会不会穿」[rhp]

[:princess:][puri_w kao=1 ]
「克林穿比基尼？」[rhp]

[クリリ[:quadrillion:][riri kao=1]
「才不要？　尽量不想露肌肤」[rhp]

「真是女孩子呢」[rhp]

*tutti_8

[:princess:][puri_w kao=1 ]
「话说回来，明天终于要去下一个旅行地了吧！[rhr]
_  听说要去海边呢」[rhp]

[:quadrillion:][riri kao=1]
「对。所以我才在帮你们挑泳衣啊」[rhp]
[:quadrillion:][riri kao=1]
「连你的也是毫不客气地选了图案哦。要感恩戴德呢」[rhp]

[:princess:][puri_w kao=1 ]
「嘿嘿……！谢谢你，克林！」[rhp]

[off_all]

[::]
明天终于要去第二个旅行地了……！现在就开始期待了！[rhp]

[fbgm]

#
[off_all]

[iscript]
delete f.ss_2nd_drop ;
delete f.ss_2nd_kite ;
delete f.ss_2nd_riri ;
delete f.ss_2nd_hati ;
delete f.ss_2nd_hkpk ;
[endscript]

[eval exp="f.ssmain = 8"]

[eval exp="f.ev_a_03 = 1"]
[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ssmain_09
;---------------------------------------------------------------------------------------------

;****************************************
[set_00 storage="train_03.jpg" time=1000 ]
;****************************************

[bgm storage="bgm_19.ogg"]

翌日清晨。[rhp]
……昨天夜里，我确实遇到了个叫『糠星夜』的人，[rhr]
本来打算稍微聊几句的来着……[rhp]

[:princess:][puri_w kao=2 as=on ]
「……我怎么就睡着了啊！」[rhp]

[off_all]

[::]
记得是被夜用手指戳了下额头之后，[rhr]
突然意识模糊，然后就睡着了吧。[rhp]
总觉得是个充满谜团的人，[rhr]
要是能再多问出些事情就好了……[rhp]

[:princess:]
「…………要在这条铁道下车了吗」[rhp]

[::]
明明旅程才刚开始呢。[rhp]
虽然也不是不能理解夜迫切的理由，[rhr]
但要说完全没有留恋之情也是骗人的。[rhp]

[:princess:]
「……………」[rhp]
[:princess:]
「…………总之现在也想不起来嘛」[rhp]

[::]
这样的话就请让我再继续旅行一段时间吧。[rhp]
麻烦的事情留待下次再考虑，[rhr]
我想好好享受当下的时光。[rhp]
……那么，今天也要加油呢！[rhp]

[fbgm]

[off_all]

[iscript]
delete f.ss_2nd_drop ;
delete f.ss_2nd_kite ;
delete f.ss_2nd_riri ;
delete f.ss_2nd_hati ;
delete f.ss_2nd_hkpk ;
delete f.ss_2nd_otiai ;
[endscript]

[eval exp="f.ssmain = 9"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ssmain_10
;---------------------------------------------------------------------------------------------

;****************************************
[set_00 storage="train_03.jpg" time=1000 ]
;****************************************

[bgm storage="bgm_03.ogg"]

翌日。[rhp]

[:princess:][puri_w kao=12 ]
「哈啊……」[rhp]

[:vulpecula:][peku kao=1 ]
「早上好——小公主！」[rhp]

[:darknebula:][hakase kao=1]
「睡眠不足吗？脸色看起来很糟哦」[rhp]

[:princess:][puri_w kao=12 ]
「是的。其实是昨天晚上……」[rhp]

;【１ハティくん達とドミノ制作に勤しんで】
[glink clickse="btn_01.ogg" x="290" y="160" width="610" high="72" text="ハティくん達とドミノ制作" target="*main_q10a" graphic="glink_c.png" enterimg="glink_d.png"]
;【２クリリンのメイク講座に参加して】
[glink clickse="btn_01.ogg" x="290" y="290" width="610" high="72" text="クリリンのメイク講座" target="*main_q10b" graphic="glink_a.png" enterimg="glink_b.png"]
[s]

*main_q10a

; 好感度+10
[eval exp="f.love_h  = f.love_h + 10"]

[:princess:][puri_w kao=6 ]
「昨天可折腾坏了。和哈蒂君他们[rhr]
_开始摆多米诺骨牌后就停不下手了……」[rhp]

[:vulpecula:][peku kao=1]
「听起来好好玩！要是小佩可也参加就好了～」[rhp]

[:princess:][puri_w kao=1 ]
「学问很深啊……多米诺这东西……」[rhp]

[jump target="*tutti_10"]

*main_q10b

; 好感度+10
[eval exp="f.love_r  = f.love_r + 10"]

[:princess:][puri_w kao=6 ]
「克林被强制参加美妆讲座……」[rhp]

[:darknebula:][hakase kao=1]
「他居然在做那种事啊……」[rhp]

[:princess:][puri_w kao=6 ]
「我用魔法化妆就没问题啦！[rhr]
_虽然也算是次不错的体验」[rhp]

*tutti_10

[:darknebula:][hakase kao=1]
「总之这样睡眠不足太可怜了」[rhp]

[anten]
[se storage="mag_09.ogg"]

[:princess:][puri_w kao=1 ]
「……！突然神清气爽了！谢谢你，这也是魔法吗？」[rhp]

[:darknebula:][hakase kao=1]
「是啊。难得出来旅行，希望你过得舒适些」[rhp]
「今天也请多指教了公主」[rhp]

[:princess:][puri_w kao=13 ]
「嗯！彼此彼此！」[rhp]

[fbgm]

#
[off_all]

[iscript]
delete f.ss_2nd_drop ;
delete f.ss_2nd_kite ;
delete f.ss_2nd_riri ;
delete f.ss_2nd_hati ;
delete f.ss_2nd_hkpk ;
delete f.ss_2nd_otiai ;
[endscript]

[eval exp="f.ssmain = 10"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ssmain_11
;---------------------------------------------------------------------------------------------

;****************************************
[set_00 storage="train_03.jpg" time=1000 ]
;****************************************

[bgm storage="bgm_03.ogg"]

翌日。[rhp]
用完早餐后望着窗外发呆时，[rhr]
突然有个疑问掠过脑海。[rhp]

[chara_part name="drop" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="riri" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:princess:][puri_w kao=1 ]
「平时都是用魔法准备符合目的地的星球吧」[rhp]
[:princess:][puri_w kao=1 ]
「我们基本上除了那里就不会去那颗星的任何地方了，[rhr]
_　其他地方是什么样子呢？」[rhp]

[:quadrillion:][riri kao=11 ]
「月球的背面是未知的世界……」[rhp]
[:quadrillion:][riri kao=11 ]
「我们或许就生活在这样的[rhr]
_　神秘世界里呢」[rhp]

[:princess:][puri_w kao=0 ]
「……？虽然不太明白啦」[rhp]

[:quadrillion:][riri kao=2 ]
「啧！根本谈不上什么浪漫情调嘛」[rhp]

[:drop:][drop kao=11 ]
「不必要的部分并未准备。[rhr]
_　视野之外皆是虚无世界」[rhp]

[:princess:][puri_w kao=2 ]
「总觉得有点可怕……」[rhp]

[:drop:][drop kao=13 as=on ]
「虽说不是什么值得骄傲的事，[rhr]
_　准备一颗星球确实很费工夫。实在抱歉」[rhp]

[:princess:][puri_w kao=1 ]
「没啦，只是有点好奇并不是嫌弃哦。[rhr]
_　谢谢你总是带我去各种地方玩！」[rhp]

[off_all]

[::]
随后我们兴致勃勃地聊起了至今旅途中的回忆。[rhp]
距离抵达目的地还有一小段路程。趁现在养精蓄锐吧！[rhp]

[fbgm]

#

[iscript]
delete f.ss_2nd_drop ;
delete f.ss_2nd_kite ;
delete f.ss_2nd_riri ;
delete f.ss_2nd_hati ;
delete f.ss_2nd_hkpk ;
delete f.ss_2nd_otiai ;
[endscript]

[eval exp="f.ssmain = 11"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ssmain_12
;---------------------------------------------------------------------------------------------

;****************************************
[set_00 storage="train_03.jpg" time=1000 ]
;****************************************

[bgm storage="bgm_03.ogg"]

翌日[rhp]

[:princess:][puri_w kao=12 ]
「唔嗯……」[rhp]
[:princess:][puri_w kao=2 ]
「……果然还是在意。关于以前的我」[rhp]

[chara_part name="jet" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:princess:]
「你们应该知道失忆之前的我吧？」[rhp]

[:jet:]
「还行吧」[rhp]

[:heartshape:][hati kao=5 ]
「那可是完美到极致的女人啊！真令人怀念」[rhp]

[:jet:][jet kao=12 ]
「简直就是从正统少女漫画里跳出来的女主角类型」[rhp]

[:princess:][puri_w kao=6 ]
「越听越觉得像是别人的事……」[rhp]
[:princess:][puri_w kao=1 ]
「……这样啊。那我当时还挺受欢迎的吗？」[rhp]

[:heartshape:][hati kao=1 ]
「太过分了！」[rhp]

[:princess:][puri_w kao=2 ]
「诶ー！？」[rhp]

[:jet:][jet kao=1 ]
「实在是高岭之花啊。虽然说是平易近人但...」[rhp]

[:heartshape:][hati kao=1 ]
「我觉得现在的公主很有趣，我很喜欢！」[rhp]

[:princess:][puri_w kao=1 ]
「这、这样啊……那就好」[rhp]

[off_all]

[::]
虽然过去的记忆还是完全想不起来，[rhr]
但没被讨厌的话就能暂时放心了。[rhp]
要是能一点点回想起来就好了……[rhp]

[fbgm]

#

[iscript]
delete f.ss_2nd_drop ;
delete f.ss_2nd_kite ;
delete f.ss_2nd_riri ;
delete f.ss_2nd_hati ;
delete f.ss_2nd_hkpk ;
delete f.ss_2nd_otiai ;
[endscript]

[eval exp="f.ssmain = 12"]

[eval exp="f.ev_a_06 = 1"]
[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ssmain_13
;---------------------------------------------------------------------------------------------

;****************************************
[set_00 storage="train_03.jpg" time=1000 ]
;****************************************

[bgm storage="bgm_03.ogg"]

翌日[rhp]

[:princess:][puri_w kao=2 ]
「～～～～」[rhp]

[off_all]

[:otiai:][otiai kao=2 as=on ]
「…………」[rhp]

[off_all]

[:drop:][drop kao=13 as=on ]
「公、公主。这样直勾勾盯着看很失礼哦」[rhp]

[:princess:][puri_w kao=2 ]
[font color=0x4682b4]
（好想和落合君变亲近……！[rhr]
_　就算搭话也不太会笑，是到青春期了吧）[rhp]
[resetfont]
[:princess:]
「这里要好好观察，[rhr]
_　必须认真确认落合君对什么感兴趣！」[rhp]

[:otiai:][otiai kao=0 ]
「我听得见哦」[rhp]

[:princess:][puri_w kao=6 as=on ]
「哎呀」[rhp]

[:otiai:][otiai kao=12 ]
「……真是的。都不能安心想事情了」[rhp]
[:otiai:][otiai kao=6 ]
「之前也说过的，不是觉得无聊才这样」[rhp]

[:princess:][puri_w kao=2 ]
「那你在想什么？」[rhp]

[:otiai:][otiai kao=12 ]
「……未来的计划」[rhp]

[:princess:][puri_w kao=5 as=on hh=on ]
「……！！　是、是吧？[rhr]
_　像游乐园和英雄秀这种都会在意的年纪嘛？」[rhp]
[:princess:][puri_w kao=14 hh=on ]
「太好了！这下可以放心了」[rhp]

[off_puri]

[:otiai:][otiai kao=2 as=on ]
「……那边的监护人！[rhr]
_　给我好好看着别给周围人添麻烦啊」[rhp]

[:drop:][drop kao=13 as=on ]
「好、好的……」[rhp]

[fbgm]

#
[off_all]

[iscript]
delete f.ss_2nd_drop ;
delete f.ss_2nd_kite ;
delete f.ss_2nd_riri ;
delete f.ss_2nd_hati ;
delete f.ss_2nd_hkpk ;
delete f.ss_2nd_otiai ;
[endscript]

[eval exp="f.ssmain = 13"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ssmain_14
;---------------------------------------------------------------------------------------------

;****************************************
[set_00 storage="train_03.jpg" time=1000 ]
;****************************************

翌日[rhp]

[:princess:][puri_w kao=1 ]
「说起来，矢部医生最近还好吗」[rhp]

[chara_part name="riri" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="168" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:kite:]
「应该挺好的吧」[rhp]

[:quadrillion:]
「肯定啦」[rhp]

[:princess:][puri_w kao=1 ]
「那帮人明明是敌方却靠讨喜角色设定显得很可爱呢」[rhp]

[:quadrillion:][riri kao=1 ]
「虽然说着什么下车之类的，但那样根本没法说服吧」[rhp]

[:princess:][puri_w kao=1 ]
「夜为什么要委托那两个人做各种事呢。[rhr]
_　看起来明明就不太合得来」[rhp]

[:kite:][kite kao=1]
「说不定夜私下也是那种性格哦」[rhp]

[:princess:][puri_w kao=5 as=on ]
「啊、也不是没可能吧……？」[rhp]

[:kite:][kite kao=11]
「谁知道呢？任凭各位想象咯」[rhp]

[:princess:][puri_w kao=1 ]
「不过他们都是有趣的人，能在下一段旅程再见就好啦」[rhp]

[:quadrillion:][riri kao=13 ]
「是呀。先不说矢部亲，只要米卡亲在场气氛就会热闹起来呢」[rhp]
[:quadrillion:]
「虽然不知道下次会去哪里旅行，[rhr]
_　但欣赏米卡亲的cosplay本就是旅途的乐趣所在呀」[rhp]

[:kite:][kite kao=6 ]
「这要是在过去你早被抓了可别忘了」[rhp]

[:quadrillion:][riri kao=14 ]
「银河铁道最棒！」[rhp]

[:princess:][puri_w kao=14 ]
「最棒！」[rhp]

[:kite:][kite kao=2 as=on ]
「笨蛋是会增殖的……」[rhp]

#
[off_all]

[iscript]
delete f.ss_2nd_drop ;
delete f.ss_2nd_kite ;
delete f.ss_2nd_riri ;
delete f.ss_2nd_hati ;
delete f.ss_2nd_hkpk ;
delete f.ss_2nd_otiai ;
[endscript]

[eval exp="f.ssmain = 14"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ssmain_15
;---------------------------------------------------------------------------------------------

;****************************************
[set_00 storage="train_03.jpg" time=1000 ]
;****************************************

[bgm storage="bgm_03.ogg"]

翌日[rhp]

[:princess:][puri_w kao=12 ]
「……」[rhp]

[:darknebula:][hakase kao=1 ]
「看来你有烦恼呢公主」[rhp]

[:princess:][puri_w kao=0]
「嗯，有件事有点在意」[rhp]
[:princess:][puri_w kao=1 ]
「我和落合君、博士和ぺくちー[rhr]
_　四个人呢」[rhp]

[:vulpecula:][peku kao=0 ]
「小公主想工作了？」[rhp]

[:princess:][puri_w kao=0 ]
「如果可以的话。就这样什么都不做[rhr]
_　总觉得每天这样过日子有些过意不去……」[rhp]
_　而且我，难得有机会[rhr]
_　想挑战只有在这里才能做到的事」[rhp]
[:princess:][puri_w kao=1 ]
「所以，能不能先让我从帮忙开始做起呢」[rhp]

[:darknebula:][hakase kao=1 ]
「但是公主。多洛普还说得过去，[rhr]
_　现阶段其他三个人的协助工作，那个……」[rhp]

[:princess:][puri_w kao=5 as=on ]
「……和现在没什么区别呢」[rhp]

[:vulpecula:][peku kao=13 ]
「那就维持现状吧！[rhr]
_　反正也不会有客人来了，干脆放松享乐吧！」[rhp]

[:princess:][puri_w kao=0 ]
「咦？客人不会再来了……？」[rhp]

[off_all]

[:vulpecula:][peku kao=4 ]
「啊！」[rhp]

[off_all]

[chara_part name="hakase" body=base kao=14 as=off ss=off hh=off hr=on msk=hat ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:]
「博士！！快到能观测目标星座的时间了！！[rhr]
_　快去观景室吧！」[rhp]

[:darknebula:]
「那公主，回头见！」[rhp]

[off_all]

[:princess:][puri_w kao=13 as=on ]
「嗯、嗯～待会见～」[rhp]

[fbgm]

#
[off_all]

[iscript]
delete f.ss_2nd_drop ;
delete f.ss_2nd_kite ;
delete f.ss_2nd_riri ;
delete f.ss_2nd_hati ;
delete f.ss_2nd_hkpk ;
delete f.ss_2nd_otiai ;
[endscript]

[eval exp="f.ssmain = 15"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ssmain_16
;---------------------------------------------------------------------------------------------

;****************************************
[set_00 storage="train_08.jpg" time=1000 ]
;****************************************

[bgm storage="bgm_08.ogg"]

当天夜里。[rhp]
一天结束，正在房间里休息时……[rhp]

[:yoru:][yoru kao=0]
「晚上好」[rhp]

[:princess:][puri_w kao=1 ]
「！　夜」[rhp]

[:yoru:][yoru kao=0]
「状态如何公主」[rhp]

[:princess:][puri_w kao=13 ]
「超级好！！每天都开心得不得了」[rhp]

[:yoru:][yoru kao=2]
「……这样啊」[rhp]

[:princess:][puri_w kao=2 as=on ]
「不用这么明显地摆出嫌弃的表情吧……」[rhp]

[:yoru:][yoru kao=12]
「……并不是那个意思」[rhp]
[:yoru:]
「我的目的是下车，但并不希望你们每天都过得悲痛」[rhp]
[:yoru:]
「虽然令人焦躁……但途中能这么开心比什么都好」[rhp]

[:princess:][puri_w kao=1 ]
「夜其实挺温柔的呢。[rhr]
_　虽说总是讲些难懂的话，但意外地善解人意」[rhp]

[:yoru:][yoru kao=6 ]
「并非不经意。我对你们已经相当宽容了」[rhp]
[:yoru:]
「若我真想动手，随时都能把你们―――」[rhp]

[:princess:][puri_w kao=2 as=on ]
「啊、好啦好啦！说教和小威胁可以到此为止了啦」[rhp]

[:yoru:][yoru kao=12 ]
「……听说明天又要去别的星球了」[rhp]

[:princess:][puri_w kao=1 ]
「嗯。这次是落合君的请求哦」[rhp]

[:yoru:][yoru kao=3]
「……哈」[rhp]

[:princess:][puri_w kao=0 ]
「夜？」[rhp]

[:yoru:][yoru kao=12]
「没什么」[rhp]
[:yoru:][yoru kao=0]
「……既然如此，今晚还是早点睡比较好吧。[rhr]
_　我先走了」[rhp]

[:princess:][puri_w kao=1 ]
「晚安，夜」[rhp]

[:yoru:][yoru kao=12]
「嗯。晚安」[rhp]

[off_all]

[bg storage="black.jpg" time=1000]

[:yoru:]
「……、……真是的……」[rhp]
[:yoru:]
「………………宙。别做傻事」[rhp]

[fbgm]

#
[off_all]

[iscript]
delete f.ss_2nd_drop ;
delete f.ss_2nd_kite ;
delete f.ss_2nd_riri ;
delete f.ss_2nd_hati ;
delete f.ss_2nd_hkpk ;
delete f.ss_2nd_otiai ;
[endscript]

[eval exp="f.ssmain = 16"]

[eval exp="f.ev_a_07 = 1"]
[jump target="*next"]

;---------------------------------------------------------------------------------------------
;---------------------------------------------------------------------------------------------

*next

[jump storage="ss_select.ks" target="*select_scene_day "]






