﻿
*start

[jump target="*ss_2nd" cond="f.nigmode == 1 && ss_2nd_riri == 1"]
[jump target="*ss_16" cond="f.ss_riri >= 15"]
[jump target="*ss_15" cond="f.ss_riri >= 14"]
[jump target="*ss_14" cond="f.ss_riri >= 13"]
[jump target="*ss_13" cond="f.ss_riri >= 12"]
[jump target="*ss_12" cond="f.ss_riri >= 11"]
[jump target="*ss_11" cond="f.ss_riri >= 10"]
[jump target="*ss_10" cond="f.ss_riri >= 9"]
[jump target="*ss_09" cond="f.ss_riri >= 8"]
[jump target="*ss_08" cond="f.ss_riri >= 7"]
[jump target="*ss_07" cond="f.ss_riri >= 6"]
[jump target="*ss_06" cond="f.ss_riri >= 5"]
[jump target="*ss_05" cond="f.ss_riri >= 4"]
[jump target="*ss_04" cond="f.ss_riri >= 3"]
[jump target="*ss_03" cond="f.ss_riri >= 2"]
[jump target="*ss_02" cond="f.ss_riri >= 1"]
[jump target="*ss_01"]

;---------------------------------------------------------------------------------------------
*ss_01
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_03.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_30.ogg"]

[:princess:][puri_w kao=13 ]
「你好克林。来玩、」[rhp]

[:princess:][riri kao=2 ]
「打烊了ー」[rhp]

[se storage="door_10.ogg"]
[bg_rule storage="train_04.jpg" rule="002.png" time=500]

[:princess:][puri_w kao=2 ]
「哈？凭什么赶人啊！？」[rhp]

[:quadrillion:]
『砧板已经够用啦ー』[rhp]

[:princess:][puri_w kao=2 ]
「居、居然这么说……！！　够了！」[rhp]

[off_all]

; 好感度+10
[eval exp="f.love_r  = f.love_r + 10"]

[eval exp="f.ss_riri = 1"]
[eval exp="f.ss_2nd_riri= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_02
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_03.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_30.ogg"]

[:princess:][puri_w kao=1 ]
「你好克林。我来玩、」[rhp]

[:quadrillion:][riri kao=6 ]
「打烊了ー」[rhp]

[off_all]

[se storage="door_10.ogg"]
[bg_rule storage="train_04.jpg" rule="002.png" time=500]

[:princess:][puri_w kao=2 ]
「又来！？　食堂不是公共区域吗！！」[rhp]

[:quadrillion:]
『厨房是主厨的城堡ー。请退下吧ー』[rhp]

[:princess:][puri_w kao=1 ]
「啊、啊这样说的话……！　给我记住！」[rhp]

[:quadrillion:]
『刚刚已经忘记啦～』[rhp]

[:princess:][puri_w kao=1 ]
「可、可恶～～！」[rhp]

[off_all]

; 好感度+10
[eval exp="f.love_r  = f.love_r + 10"]

[eval exp="f.ss_riri = 2"]
[eval exp="f.ss_2nd_riri= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_03
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_03.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_30.ogg"]

[:princess:][puri_w kao=1 ]
「你好克林！我来玩……」[rhp]

[off_all]
[yurasu]
[se storage="hand_05.ogg"]

[:princess:]
[font size=30]
「哼！！」[rhp]
[resetfont]

[::]
对方按惯例正要在固定时间关门时，[rhr]
我迅速把脚卡进拉门的缝隙里。[rhp]
千钧一发之际赶上，门勉强保持着15厘米的开合度。[rhp]

[:quadrillion:][riri kao=2 as=on ss=on ]
「喂！　干什么呢，把脚挪开！！」[rhp]

[:princess:][puri_w kao=5 as=on ]
「让我进去就挪开唷……！」[rhp]

[:quadrillion:][riri kao=9 ]
「咦？　那边有只好可爱的猫」[rhp]

[:princess:][puri_w kao=4 as=on ]
「哎。怎么会在这里……」[rhp]

[off_all]

[se storage="door_10.ogg"]
[bg_rule storage="train_04.jpg" rule="002.png" time=500]

[:princess:][puri_w kao=2 as=on ]
「啊―――！！！」[rhp]

[:quadrillion:]
『想骗过我还早一百亿年呢这个布兹！[rhr]
_　去做完丰胸手术再来吧！』[rhp]

[:princess:][puri_w kao=6 as=on ]
「～～～～！　啊啊知道啦！」[rhr]
_　既然说到这份上我当然有计划啦！」[rhp]
[:princess:]
「你给我记住！！　刚才的发言，我绝对会让你后悔的！」[rhp]

[off_all]

; 好感度+10
[eval exp="f.love_r  = f.love_r + 10"]

[eval exp="f.ss_riri = 3"]
[eval exp="f.ss_2nd_riri= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_04
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_03.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_30.ogg"]

[:quadrillion:][riri kao=2 ]
「讨厌啦你，怎么又来了？」[rhp]

[:princess:][puri_w kao=11 ]
「来多少次都行哦」[rhp]

[:quadrillion:][riri kao=6 ]
「你也真闲啊……」[rhp]

[:princess:][puri_w kao=0 ]
「……不打算赶我走吗？」[rhp]

[:quadrillion:][riri kao=12 ]
「嘛，反正我也刚好闲着。[rhr]
_　就算是陪你这种人说说话也无妨啦」[rhp]

[:princess:][puri_w kao=5 ]
「真是的，一点都不坦率！」[rhp]

[off_all]

; 好感度+10
[eval exp="f.love_r  = f.love_r + 10"]

[eval exp="f.ss_riri = 4"]
[eval exp="f.ss_2nd_riri= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_05
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_03.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_30.ogg"]

[:princess:][puri_w kao=6 as=on ]
「你好ー」[rhp]

[:quadrillion:][riri kao=2 ]
「呜哇，平胸女出现了」[rhp]

[:princess:][puri_w kao=6 as=on ]
「还是一如既往的没礼貌呢……」[rhp]
[:princess:]
「我说你啊，也就是因为我脾气好才忍你，[rhr]
_　对其他女性这么做绝对会被讨厌的！」[rhp]

[:quadrillion:][riri kao=2 ]
「小鬼头可不算女人ー」[rhp]

[:princess:][puri_w kao=1 ]
「唔唔唔……！」[rhp]

[off_all]

; 好感度+10
[eval exp="f.love_r  = f.love_r + 10"]

[eval exp="f.ss_riri = 5"]
[eval exp="f.ss_2nd_riri= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_06
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_03.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_30.ogg"]


[:quadrillion:][riri kao=12 ]
「……」[rhp]

[:princess:][puri_w kao=0 ]
「……在睡觉」[rhp]

[:princess:][puri_w kao=12 ]
「……」[rhp]

[off_all]

[::]
噗尼[rhp]

[:quadrillion:][riri kao=2 as=on ss=on ]
「呀！！！」[rhp]

[:princess:][puri_w kao=2 ]
「醒啦！」[rhp]

[:quadrillion:][riri kao=6 as=on ]
「啊、你！　居然趁人午睡时[rhr]
_　乱捏别人脸。妆都要掉了啦」[rhp]

[:princess:][puri_w kao=13 as=on ]
「看你嘴唇duangduang的……[rhr]
_　想着为什么皮肤比我这女生还好，不知不觉就……」[rhp]

[:quadrillion:][riri kao=2 ]
「……作为先行者我先把话说在前头」[rhp]
[:quadrillion:]
「看可以。触碰不行。任何癖好都不例外」[rhp]

[:princess:][puri_w kao=1 ]
「诶？」[rhp]

[off_all]

; 好感度+10
[eval exp="f.love_r  = f.love_r + 10"]

[eval exp="f.ss_riri = 6"]
[eval exp="f.ss_2nd_riri= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_07
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_03.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_30.ogg"]

[:princess:][puri_w kao=1 ]
「克林你啊，为什么喜欢巨乳呢？」[rhp]

[:quadrillion:][riri kao=2 ]
「干嘛突然这么问」[rhp]
[:quadrillion:][riri kao=13 ]
「这不是明摆着嘛。因为装满梦想和希望啊」[rhp]

[:princess:][puri_w kao=2 as=on ]
「我、我两方面也都有啊。[rhr]
_　照这么说贫乳岂不是既没梦想也没希望了吗」[rhp]

[:quadrillion:][riri kao=6 ]
「当然没有。只有绝望和绝壁」[rhp]

[:princess:]
「有的！太失礼了吧」[rhp]
[:princess:][puri_w kao=1 ]
「我倒觉得充满无限可能的贫乳才真正[rhr]
_　蕴含着梦想与希望呢……！」[rhp]

[:quadrillion:][riri kao=2 ]
「有时候觉得你的发言真是下流……」[rhp]

[off_all]

; 好感度+10
[eval exp="f.love_r  = f.love_r + 10"]

[eval exp="f.ss_riri = 7"]
[eval exp="f.ss_2nd_riri= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_08
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_03.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_30.ogg"]

[:princess:][puri_w kao=1 ]
「克林你为什么只留后颈的头发？」[rhp]

[:quadrillion:][riri kao=1 ]
「哼哼，很帅吧？很时尚对不对？」[rhp]

[:princess:][puri_w kao=13 ]
「嗯！我觉得很有个性」[rhp]

[:quadrillion:][riri kao=13 ]
「嘛虽然是假话」[rhp]

[:princess:][puri_w kao=6 as=on ]
「嗯？」[rhp]

[:quadrillion:][riri kao=2 as=on ]
「根本剪不掉……不管剪多少次剪多少次都会再长出来……」[rhp]

[:princess:][puri_w kao=6 as=on ]
「你就不能编个像样点的谎吗……」[rhp]

[:quadrillion:][riri kao=1 ]
「说不定这是南的执着呢」[rhp]

[:princess:][puri_w kao=1 ]
「为什么是南？」[rhp]

[:quadrillion:][riri kao=1 ]
「啊——真是的从刚才就叽叽喳喳吵死了！[rhr]
_　说到底这些全都怪你啊！」[rhp]

[:princess:][puri_w kao=1 ]
「哈啊ー！？！？　完全听不懂你在说什么！！」[rhp]

[off_all]

[::]
克林这家伙还是一如既往地不讲道理！[rhp]

; 好感度+10
[eval exp="f.love_r  = f.love_r + 10"]

[eval exp="f.ss_riri = 8"]
[eval exp="f.ss_2nd_riri= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_09
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_03.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_30.ogg"]

[:princess:][puri_w kao=2 ]
「女子力……」[rhp]

[:quadrillion:][riri kao=2 ]
「嗯？」[rhp]

[:princess:][puri_w kao=2 ]
「我觉得自己缺少的……就是女子力啊……」[rhp]

[:quadrillion:][riri kao=6 ]
「哦这样啊。多保重」[rhp]

[:princess:][puri_w kao=0 ]
「……」[rhp]

[:quadrillion:][riri kao=20 ]
「……搞什么。真恶心」[rhp]

[:princess:][puri_w kao=2 ]
「唔嗯……」[rhp]
[:princess:][puri_w kao=13 ]
「……没门！」[rhp]

[se storage="sound_01.ogg"]
[yurasu]

[:princess:][puri_w kao=1 ]
「痛痛痛痛痛痛！！！！别用拳头钻我头！！」[rhp]

[:quadrillion:]
「你倒是说说看啊库索布斯！[rhr]
_　我哪点不能作为提升女子力的参考！？」[rhp]

[:princess:]
「就是这种地方啦ー！！」[rhp]

[off_all]

; 好感度+10
[eval exp="f.love_r  = f.love_r + 10"]

[eval exp="f.ss_riri = 9"]
[eval exp="f.ss_2nd_riri= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_10
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_03.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_30.ogg"]

[:princess:][puri_w kao=1 ]
「克林没什么喜欢的料理吗？」[rhp]

[:quadrillion:][riri kao=7 ]
「这个嘛。硬要说的话应该是甜……」[rhp]

[:quadrillion:][riri kao=6 ]
「……辣的」[rhp]

[:princess:][puri_w kao=0]
「甜辣味的？　挺独特啊」[rhp]

[:quadrillion:][riri kao=5 ]
「辣的！　越辣越喜欢」[rhp]

[:princess:][puri_w kao=13 ]
「真的吗ー？　该不会只吃一口就剩下了吧？[rhr]
_　在装模作样不是？」[rhp]

[:quadrillion:]
「怎么可能。主厨会糟蹋食物吗？」[rhp]

[:princess:][puri_w kao=2 ]
「明明压根没接触过料理工作……」[rhp]

[:princess:][puri_w kao=0 ]
「话说最开始说的「甜」[rhp]是什么？」[rhp]
[:quadrillion:][riri kao=2 ]
「咦？我说过那种话吗。不知道耶——」[rhp]

[:princess:][puri_w kao=16]
「真是的。太敷衍了吧」[rhp]

[off_all]

; 好感度+10
[eval exp="f.love_r  = f.love_r + 10"]

[eval exp="f.ss_riri = 10"]
[eval exp="f.ss_2nd_riri= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_11
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_03.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_30.ogg"]
[:princess:][puri_w kao=2 ]
「大姊……不对，人妖……」[rhp]
[:princess:][puri_w kao=6 as=on ]
「好痛！」[rhp]

[:princess:][riri kao=2 ]
「你干什么啊！？」[rhp]

[:quadrillion:]
「因为我听到你说我坏话了嘛」[rhp]

[:princess:]
「哈——被害妄想可真严重呢。不是你想的那样啦」[rhp]

[:quadrillion:][riri kao=2 ]
「那你到底是来干嘛的。特地跑到餐车来嘀嘀咕咕」[rhp]

[:princess:][puri_w kao=1 ]
「就是…克林你到底是人妖还是伪娘[rhr]
_　我一直在想到底属于哪种呢」[rhp]

[:quadrillion:][riri kao=6 as=on ]
「都说五百亿遍了两者都不是……[rhr]
_　能不能别这么纠缠不休啊」[rhp]

[:princess:][puri_w kao=13 ]
「啊这个倒无所谓啦」[rhp]

[:quadrillion:]
（很有所谓好吧。居然讨论别人的性别…这家伙…）[rhp]

[:princess:][puri_w kao=1 ]
「人妖和伪娘的区别…嗯…」[rhp]

[off_all]

[:princess:][puri_w kao=13 ]
「我现在就去问博士！回见啦克林」[rhp]

[:quadrillion:][riri kao=2 ]
「那你一开始就该直接去博士那儿」[rhp]

[:princess:][puri_w kao=1 ]
「哎呀，难得有机会本来想顺便看看克林的脸来着！」[rhp]

[off_all]

[:princess:][puri_w kao=13 ]
「先走啦！」[rhp]

[off_all]

[:quadrillion:][riri kao=6 as=on ]
「……搞什么啊那家伙…莫名其妙」[rhp]

[off_all]

; 好感度+10
[eval exp="f.love_r  = f.love_r + 10"]

[eval exp="f.ss_riri = 11"]
[eval exp="f.ss_2nd_riri= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_12
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_03.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_30.ogg"]

[:princess:][puri_w kao=1 ]
「比如说半夜觉得肚子饿的情况你也有过吧」[rhp]

[:quadrillion:][riri kao=6 ]
「小胖子」[rhp]

[:princess:][puri_w kao=1 ]
「肯定有过吧。这种时候，[rhr]
_　会不会想稍微自己动手做点什么呢？」[rhp]

[:quadrillion:]
「没有啦~就算有也和胖墩布兹不一样[rhr]
_　因为人家可是会魔法的呢」[rhp]

[:princess:][puri_w kao=1 ]
「要是以后交到男朋友，对方说肚子饿了怎么办？[rhr]
_　用魔法变出来会显得很没诚意吧」[rhp]

[:quadrillion:]
「放心。这种除了你和佩奇就没女性的状况下不可能发生的」[rhp]

[:princess:][puri_w kao=2 as=on ]
「啊～这样啊～～～」[rhp]

[:quadrillion:][riri kao=5 ]
「嘛～就算真有万分之一的可能，[rhr]
_　我也不会让自己重要的女人吃夜宵的」[rhp]

[:princess:][puri_w kao=6 as=on ]
「审美标准真高呢……」[rhp]

[off_all]

; 好感度+10
[eval exp="f.love_r  = f.love_r + 10"]

[eval exp="f.ss_riri = 12"]
[eval exp="f.ss_2nd_riri= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_13
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_03.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_30.ogg"]

[:princess:][puri_w kao=11 ]
「古池塘呀，青蛙跳入水声响」[rhp]

[:quadrillion:][riri kao=0 ]
「嗯？」[rhp]

[:princess:][puri_w kao=1 ]
「因为想感受……春天。试着吟了句俳句」[rhp]

[:quadrillion:][riri kao=2 as=on ]
「你时不时就会说些怪话呢……」[rhp]
[:quadrillion:][riri kao=1 ]
「不过倒也不是不能理解这种心情」[rhp]

[:princess:][puri_w kao=1 ]
「嘿～没想到克林也懂风雅嘛」[rhp]

[:quadrillion:][riri kao=5 ]
「想到化妆品啊衣服啊那时候买下来就好了，[rhr]
_　就会后悔得要死。时尚可是稍纵即逝的呢」[rhp]

[:princess:][puri_w kao=2 as=on ]
「『青蛙』原来不是那个意思……」[rhp]

[off_all]

; 好感度+10
[eval exp="f.love_r  = f.love_r + 10"]

[eval exp="f.ss_riri = 13"]
[eval exp="f.ss_2nd_riri= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_14
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_03.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_30.ogg"]

[:princess:][puri_w kao=1 ]
「克林为什么会想自称主厨呢？」[rhp]

[:quadrillion:][riri kao=12 ]
「问得真奇怪。[rhr]
_　人家又不是因为喜欢才自称的呀」[rhp]
[:quadrillion:]
「我的主厨头衔是天生的」[rhp]

[:princess:][puri_w kao=0 ]
「既然是天生主厨应该很喜欢做菜吧。真古怪」[rhp]

[:quadrillion:][riri kao=1 ]
「在这世界上，理想和才能往往是不一致的」[rhp]
[:quadrillion:][riri kao=2 ]
「总觉得有些肤浅啊[rhp]

[:princess:][puri_w kao=1 ]
[font color=0x696969]
（也不知是肤浅还是深刻……）[rhp]
[resetfont]

[off_all]

; 好感度+10
[eval exp="f.love_r  = f.love_r + 10"]

[eval exp="f.ss_riri = 14"]
[eval exp="f.ss_2nd_riri= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_15
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_03.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_30.ogg"]

[:quadrillion:][riri kao=12 ]
「比如假设手上的面包吃完了。[rhr]
_　多洛普的魔法也被禁止了」[rhp]

[:princess:][puri_w kao=1 ]
「什么嘛，心理测试？」[rhp]

[:quadrillion:][riri kao=2 ]
「别打岔乖乖听着。[rhr]
_　明白？是自己那份面包吃完了哦」[rhp]

[:quadrillion:][riri kao=1 ]
「那么问题来了。这时候我会怎么做呢？」[rhp]

[:princess:][puri_w kao=1 ]
「抢夺别人的食物」[rhp]

[:quadrillion:][riri kao=1 ]
「果然……你们骨子里就是这种人呢」[rhp]

[:princess:][puri_w kao=1 ]
「！！果然是心理测试。喂，看出什么了？」[rhp]

[:quadrillion:][riri kao=１ ]
「刚才只是恶意调查。[rhr]
_　看你们平时都用什么眼光打量我的」[rhp]

[:princess:][puri_w kao=1 ]
「哦这样……那还有救吗？」[rhp]
[:quadrillion:][riri kao=2 ]
「该反省态度的是你们才对吧。[rhr]
_　毫无根据就说人坏话真是差劲的布兹呢」[rhp]

[:quadrillion:][riri kao=11 ]
「行！那就这样」[rhp]

[:princess:][puri_w kao=2 as=on ]
「难以接受……！」[rhp]

[off_all]

; 好感度+10
[eval exp="f.love_r  = f.love_r + 10"]

[eval exp="f.ss_riri = 15"]
[eval exp="f.ss_2nd_riri= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_16
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_03.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_30.ogg"]

[:quadrillion:][riri kao=3 ]
「哈啊⋯⋯」[rhp]

[:princess:][puri_w kao=1 ]
「怎么了。没精打采的」[rhp]

[:quadrillion:][riri kao=6 ]
「没什么……只是觉得你都把来这儿当成日常了呢」[rhp]
[:quadrillion:]
「今天连招呼都不打就进来了。当自己房间啊」[rhp]

[:princess:][puri_w kao=1 ]
「也不是你的房间吧……毕竟是餐车大家共用的」[rhp]

[:quadrillion:][riri kao=2 ]
「不是常说吗。厨房是主妇的城堡呢」[rhp]

[:princess:][puri_w kao=1 ]
「明明没做过饭还说得振振有词……不过说到餐车[rhr]
_　这里可是夸德里利昂，某种意义上或许真是你的城堡呢」[rhp]

[:princess:][puri_w kao=1 ]
「想说话的时候随时可以来这里聊。[rhr]
_　这么直白倒省事了呢」[rhp]

[:quadrillion:][riri kao=2 ]
「…………好吧。虽然我这边可是困扰得要命」[rhp]

[:princess:][puri_w kao=1 ]
「不过最近倒是很爽快地放我进来了」[rhp]

[:quadrillion:][riri kao=2 ]
「吵死了……！就是打发时间啦，打发时间！」[rhp]

[off_all]

; 好感度+10
[eval exp="f.love_r  = f.love_r + 10"]

[eval exp="f.ss_riri = 16"]
[eval exp="f.ss_2nd_riri= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_2nd
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_03.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_30.ogg"]


[:princess:][puri_w kao=5 ]
「好嘞，这次一定要让那个坏心眼大姐认输……」[rhp]
[:princess:][puri_w kao=0 ]
「嗯？」[rhp]

[off_all]

『打扫中！！闲人免进　by多洛普』[rhp]

[:princess:]
「哎呀呀。不在呢……没办法，去别处看看吧」[rhp]


[jump target="*next"]

;---------------------------------------------------------------------------------------------
;---------------------------------------------------------------------------------------------

*next

#

;ev_7への分岐
[if exp="f.ev_a_07 ==1 && f.nigmode == 1"]
[jump storage="ev_a_07.ks" target="*start"]

;ev_6への分岐
[elsif exp="f.ev_a_06 ==1 && f.nigmode == 1"]
[jump storage="ev_a_06.ks" target="*start"]

;ev_3への分岐
[elsif exp="f.ev_a_03 ==1 && f.nigmode == 1"]
[jump storage="ev_a_03.ks" target="*start"]

;ev_2への分岐
[elsif exp="f.ev_a_02 ==1 && f.nigmode == 1"]
[jump storage="ev_a_02.ks" target="*start"]

;夜モードの場合
[elsif exp="f.nigmode == 1"]
[jump storage="ss_main.ks" target="*start"]

;昼モード
[else]
[jump storage="ss_select.ks" target="*select_scene_nig"]
[endif]


