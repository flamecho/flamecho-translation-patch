﻿
*start

;--------------------------------------------------------------------------------------------
;▼フルボイスセット▼
;ハートシェイプ
[voconfig sebuf=1 name=hati vostorage="hati/full/{number}.ogg" number=58]
;ジェット
[voconfig sebuf=1 name=jet vostorage="jet/full/{number}.ogg" number=46]
;--------------------------------------------------------------------------------------------

[chara_part name="drop" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=1 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「那就这样吧！　多洛普在这里搭帐篷等克林。[rhr]
_　而我们履行各自职责的同时，公平地全员一起寻找克林」[rhp]
[:princess:]
「这样就不用全员一起行动，还能搜索更广的范围呢！」[rhp]

[:drop:]
「只能这样了。说不定夸德里利昂[rhr]
_　会自己回来呢」[rhp]

[off_all]

[chara_part name="peku" body=hood kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:kite:]
「哈啊……都怪克林搞得这么麻烦」[rhp] 

[:vulpecula:]
「确切说是哈蒂他们的错啦」[rhp]

[off_all]

[chara_part name="hakase" body=base kao=7 as=off ss=off hh=off hr=on msk=hat ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="otiai" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:otiai:]
「我赞成。海边和山脚方向大致也能分组行动」[rhp]

[:darknebula:]
「那我们负责东侧区域，[rhr]
_　哈托谢普君你们能负责西边吗」[rhp]

[:princess:][puri_w kao=2 ]
「我也跟着去吧。就两个人的话怕又搞出什么事」[rhp]

[:darknebula:]
「真可靠呢。拜托了」[rhp]

[off_all]

[chara_part name="jet" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:][p_h_06]
「自己闯的祸要自己解决吗……！[rhr]
_　太没劲了！不过正合我意！」[rhp]

[:jet:][p_j_09]
「一点也不合意好吗……」[rhp]

[:heartshape:]
「那就改说不合意！」[rhp]

[:princess:][puri_w kao=6 ]
「杰特君，不要因为被冷静对待就闹别扭啦」[rhp]

[:jet:][jet kao=3 ]
「才没闹别扭……啊—啊，真无聊。[rhr]
_　早知道不吹飞克林改吹飞公主就好了」[rhp]

[:princess:][puri_w kao=2 as=on ss=on ]
「！？」[rhp]

[:heartshape:][hati kao=5 ][p_h_31]
「安心吧杰特！　今后克林的反应绝对[rhr]
_　会超有趣的好吗！！」[rhp]

[:jet:][jet kao=5 ][p_j_29]
「那倒也是。真希望他快点发火～」[rhp]

[:princess:][puri_w kao=6 as=on ss=on ]
[font color=0x4682b4]
（完全没吸取教训……！　为了避免造成更多破坏[rhr]
_　我必须好好盯着这两个人！！）[rhp]
[resetfont]

;****************************************
[fbgm]
[set_00 storage="jungle_03.jpg"]
[bgm storage="bgm_31.ogg"]
;****************************************

[::]
就这样我们単作组分成了两支队伍[rhr]
朝着与博士他们相反的丛林方向前进。[rhp]

[:princess:][puri_w kao=2 as=on ]
「喂～～！　克林，在哪～～～！？」[rhp]

[off_puri]

[::]
在郁郁葱葱的森林中沿着兽道前行[rhr]
持续朝着可能潜伏在这片森林某处的夸德里利昂喊话。[rhp]
如此持续了约莫二十分钟[rhr]
毫无回应的迹象让焦躁逐渐压过了焦急[rhp]

[:princess:][puri_w kao=6 as=on ]
「该不会……因为是我在呼叫[rhr]
_　就故意不回应吧……」[rhp]

[chara_part name="jet" body=base kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:jet:][p_j_24]
「很有可能」[rhp]

[:heartshape:][p_h_24]
「那家伙超讨厌公主的嘛！」[rhp]

[:princess:][puri_w kao=2 as=on ]
「真是的，那里我希望能否定掉啦」[rhp]

[off_all]

[::]
就在我忧心忡忡时 哈蒂君他们却挥舞着捡来的木棍[rhr]
随意戳弄着沿途的蜘蛛网和不明花草果实 一副悠哉模样。[rhp]

[chara_part name="jet" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:][p_h_04]
「杰特快看！那边有只不认识的鸟诶！要抓吗！？」[rhp]

[:jet:][jet kao=13 ][p_j_16]
「不错啊。抓到那家伙就能向佩奇他们炫耀了」[rhp]
[:jet:][jet kao=13 as=on ]
「明明是负责水果的，却连稀有的鸡肉都轻松搞定了……[rhr]
_　……我又干啥坏事了吗？」[rhp]

[:heartshape:][hati kao=14 ]
「太离谱了！！真不愧是杰特！！」[rhp]

[off_all]

[:princess:][puri_w ]
「～～～～等等！你们两个！」[rhp]

[chara_part name="jet" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:][p_h_19]
「怎么了公主！要上厕所吗！？」[rhp]

[:princess:][puri_w kao=6 ]
「我说啊……！希望你们两个能更认真点。[rhr]
_　水果倒是采了些，可找克林的事完全没进展嘛」[rhp]

[:jet:][jet kao=12 ][p_j_17]
「当然不甘心自己闯的祸要自己收拾啊」[rhp]

[:heartshape:][hati kao=4 as=on ]
[font color=0x4682b4]
（收拾……！因为刚才说厕所才用这词！？）[rhp]
[resetfont]

[:princess:][puri_w kao=2 ]
「杰特君根本不知反省。[rhr]
_　待会被克林骂可别怪我哦！」[rhp]

[:jet:][jet kao=6 ]
「知道啦。……公主你呀，是班长型人格呢」[rhp]

[:heartshape:][hati kao=13 ][p_h_02]
「认真是好事！看到公主这么努力，[rhr]
_　我们也不能输啊！」[rhp]
[:heartshape:]
「为了别人拼尽全力的公主，超帅的！」[rhp]

[:princess:][puri_w kao=1 ]
「哈蒂君……」[rhp]
[:princess:][puri_w kao=6 ]
「――――那就用行动证明给我看啊！」[rhp]

[:heartshape:][hati kao=14 ][p_h_31]
「啊哈哈！我跟着杰特混就行啦！」[rhp]

[:jet:][jet kao=11 ][p_j_27]
「我只是跟着哈蒂而已」[rhp]

[:princess:][puri_w kao=8 as=on ]
「真是的～～～……！」[rhp]

[off_all]

[:jet:][jet kao=6 as=on ][p_j_17]
[font size=13]
「……………………不过，你还是一点没变呢……」[rhp]
[resetfont]

[off_all]

[chara_part name="jet" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:][hati kao=0 ][p_h_19]
「嗯？皱着眉头怎么了，杰特！」[rhp]

[:jet:][jet kao=13 ]
「…………、没事？我在想差不多该休息了－[rhr]
_　一直走路确实累了」[rhp]

[:heartshape:][hati kao=8 as=on ]
「没事吧？别太勉强」[rhp]

[:jet:][jet kao=3 ][p_j_34]
「抱歉啊，哈蒂。你明明想继续前进的」[rhp]

[:heartshape:][hati kao=13 ][p_h_31]
「都说没关系啦！别在意！」[rhp]
[:heartshape:][hati kao=5 as=on ]
「所以公主，不好意思能陪我们一会儿吗？[rhr]
_　杰特是脑力派，体力活不拿手」[rhp]

[:jet:][jet kao=13 ]
「温室里的豆芽菜真是抱歉」[rhp]

[off_all]

[:princess:][puri_w kao=11 as=on ]
「好好……知道了。[rhr]
_　我也有些累了，休息下吧」[rhp]

[off_all]

[::]
虽然感觉有点被带着走，但我也确实累了，[rhr]
于是暂且接受他们的提议，决定在附近树荫下休息。[rhp]

;****************************************
[set_time storage="jungle_04.jpg"]
;****************************************

[::]
休息期间，哈蒂君拿起之前采集的水果，[rhr]
开始逐个详细为我讲解。[rhp]

[:princess:][puri_w ]
「真厉害呢。有这么多品种」[rhp]

[:heartshape:][hati kao=1 ][p_h_02]
「噢！这叫布什坎，是博士的最爱。[rhr]
_　那边红色的是蛇果，佩奇特别喜欢」[rhp]

[:princess:][puri_w kao=7 ]
「那边那个看起来恶心的东西也是谁的喜好？」[rhp]

[:heartshape:][hati kao=1 ]
「不、不是。这家伙叫八重山青木，别名诺丽。[rhr]
_　就是那个好像听说过又好像没听说过的诺丽果汁的原料」[rhp]
[:heartshape:]
「虽然难喝但据说对健康超级有益，[rhr]
_　所以特地给注重养生的克林当作赔罪水果了！」[rhp]

[:princess:][puri_w kao=2 as=on ]
[font color=0x4682b4]
（绝对会被骂的吧，要是这么干的话……）[rhp]
[resetfont]

[:heartshape:][hati kao=5 ]
「其他人大抵没什么偏好，所以这是我独断决定的阵容。[rhr]
_　这边依次是山桃、普拉桑、糖苹果」[rhp]
[:heartshape:]
「而我强烈推荐的是这个水莲雾！[rhr]
_　外表像樱桃但完全不同，我更喜欢这个！」[rhp]

[:princess:][puri_w kao=6 as=on ]
「嘿欸……」[rhp]

[off_all]

[::]
…………话说从刚才就在想，[rhr]
这些水果真的全都能在丛林里采集到吗？[rhp]
产地绝对乱七八糟混在一起了吧。[rhr]
果然这也是魔法吧。真是为所欲为啊……[rhp]

[:princess:][puri_w kao=13 ]
「好！稀有的种类大致就这些吧」[rhp]

[:princess:][puri_w ]
「真厉害啊哈蒂君。对水果异常熟悉呢」[rhp]

[:heartshape:][hati kao=5 ][p_h_01]
「那是！虽然杰特不太喜欢这些。[rhr]
_　我也想模仿他，但这方面终究是个人喜好啊—」[rhp]

[:princess:][puri_w kao=2 as=on ]
[font color=0x4682b4]
（喜欢的话保持喜欢就好啦）[rhp]
[resetfont]

[:heartshape:][hati kao=14 ]
「公主也吃点水果吧！[rhr]
_　对身体好，还能减肥哦！」[rhp]

[:princess:][puri_w ]
「既然这么推荐，那我就稍微模仿下吧」[rhp]

[:heartshape:][hati kao=1 ][p_h_24]
「啊！你最近可是胖了不少呢！」[rhp]

[:princess:][puri_w kao=4 as=on ss=on ]
「！？！？！？」[rhp]

[:heartshape:][hati kao=14 ]
「那也是没办法！都怪多洛普做的饭太好吃！」[rhp]

[:princess:][puri_w kao=2 as=on ]
「才、才没胖呢……！？[rhr]
_　衣服尺码完全没变化啊！」[rhp]

[off_all]

[chara_part name="jet" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=1 as=off ss=off hh=off hr=on]
[chara_show name="puri_w" layer="message0" left="1" top="1" width="330" height="720" wait="true" zindex="1005" time=150]

[:princess:]
「呐杰特君？对吧？我没发胖吧？对吧？」[rhp]

[:jet:][p_j_02]
「我只遵从哈蒂的判断」[rhp]

[:princess:][puri_w kao=2 as=on ss=on ]
[font size=25]
「根本就没胖啊！！！」[rhp]
[resetfont]

[:jet:][jet kao=6 as=on ]
「好啦好啦。怎样都无所谓啦……」[rhp]

[off_puri]

[jet kao=2 as=on ]
「………………啧，气氛全毁了。难得人家……」[rhp]

[:heartshape:][hati kao=5 ][p_h_06]
「杰特！机会难得，我们先开吃吧。[rhr]
_　你讨厌的东西应该都没摘！」[rhp]

[:jet:][jet kao=0 ]
「………………」[rhp]

[:heartshape:][hati kao=1 ]
「？杰特？」[rhp]

[:jet:][jet kao=7 ][p_j_17]
「………………咦？没有甜瓜吗」[rhp]

[:heartshape:][hati kao=5 as=on ][p_h_28]
「这个真没办法～太重了就放弃了！」[rhp]

[off_all]

[:princess:][puri_w kao=2 as=on ]
[font color=0x4682b4]
（原来还是有带着啊……）[rhp]
[resetfont]

[off_puri]

[chara_part name="jet" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:jet:][p_j_29]
「什么嘛。我本来还想吃甜瓜呢。[rhr]
_　啊～啊，太遗憾了」[rhp]

[:heartshape:][hati 5 as=on][p_h_02]
「没问题！杰特想吃的话我现在就去……」[rhp]

[:jet:][jet kao=12 ]
「不，我去」[rhp]

[:heartshape:][hati kao=4 as=on ][p_h_13]
「诶……杰、杰特去？不是我去？」[rhp]

[:jet:][jet kao=13 ]
「偶尔我也得运动一下。[rhr]
_　我可不想像公主那样变胖」[rhp]

[:princess:][puri_w kao=2 as=on ]
「所以说了我没胖！[rhr]
_　就算真的胖了，也没到那种程度啦！」[rhp]
[:princess:]
「………………、没到那种程度……对吧！？」[rhp]

[:heartshape:][hati kao=2 as=on ]
「………………」[rhp]
[:heartshape:]
「……既然说到这份上，那你就去吧杰特！！」[rhp]

[:princess:][puri_w kao=2 as=on ss=on ]
[font color=0x4682b4]
（根本就是到那种程度了啊！！）[rhp]
[resetfont]

[off_all]

[:jet:][jet kao=11 ]
「那，我这就慢慢出发啦。你慢慢休息—」[rhp]

[off_all]

[::]
杰特君踏着悠闲的步伐消失在森林深处。[rhp]

[:heartshape:][hati kao=6 ][p_h_17]
「话说回来，那家伙明明说要休息的……现在真的没事了吗？[rhr]
_　虽然叫豆芽菜，却是个不折不扣的硬汉小子啊……」[rhp]
[:heartshape:]
「难道说……这也是杰特的计谋之一……」[rhp]

[off_all]

[:princess:][puri_w kao=2 as=on ss=on ]
「可恶，可恶……要是能用魔法马上就能瘦下来……」[rhp]

[:heartshape:][hati kao=5 as=on ]
「！　啊……没、没事的公主！[rhr]
_　你看！待会儿喝诺丽果汁就好！对吧！」[rhp]

[:princess:][puri_w kao=3 as=on ]
「那个我不要……」[rhp]

[:heartshape:][hati kao=13 as=on ][p_h_32]
「这、这样啊。真可惜……」[rhp]

[:princess:][puri_w kao=2 ]
「话说」[rhp]

[:heartshape:][hati kao=0 as=on ]
「……嗯？」[rhp]

[:princess:][puri_w kao=2 ]
「刚才你说杰特君的计谋，那是什么？」[rhp]

[:heartshape:][hati kao=5 as=on ]
「诶」[rhp]

[:princess:][puri_w kao=6 as=on ]
「你那什么表情！该不会又在打什么坏主意吧……！！」[rhp]

[:heartshape:][hati kao=14 as=on ][p_h_22]
「不、不是不是！不是什么坏点子。该怎么说呢那个～～……」[rhp]

[:princess:][puri_w kao=2 ]
「给我说清楚！这次你到底想干什么？」[rhp]

[:heartshape:][hati kao=3 as=on ]
「呜、嗯……这个可以问吗。[rhr]
_　不过，或许由我在这里抢先开口反而对杰特更有利……」[rhp]

[:princess:][puri_w kao=6 ]
「说什么呢？」[rhp]

[:heartshape:][hati kao=2 as=on ][p_h_06]
「……好！我决定了！！我要直截了当地问！！[rhr]
_　你也给我清楚地回答，公主！」[rhp]

[yurasu]

[font size=25]
「你，对杰特是怎么看的！？」[rhp]
[resetfont]

[:princess:][puri_w kao=0 ]
「嗯……虽然有点别扭，但算是个聪明有趣的朋友？」[rhp]

[yurasu]

[:heartshape:][hati kao=2 ]
[font size=27]
「别害羞啊！！！！！」[rhp]
[resetfont]

[:princess:][puri_w kao=2 as=on ]
「！？」[rhp]

[:heartshape:][hati kao=6 ]
「不是这个意思！问你如何看待杰特，[rhr]
_　就是问作为恋爱对象你觉得他怎么样啊！？」[rhp]

[:princess:][puri_w kao=8 as=on hh=on ]
「什！你说什么！？恋、恋恋恋恋……恋爱！？」[rhp]

[:heartshape:][hati kao=3 ]
「我还以为，杰特是想和公主独处[rhr]
_　才故意支使我去找甜瓜的！这就是他的计谋！」[rhp]
[:heartshape:]
「现在还来得及！公主，快追杰特―――」[rhp]

[:princess:][puri_w kao=2 as=on hh=on ]
[font size=27]
「才不要！！」[rhp]
[resetfont]

[:heartshape:][hati kao=2 as=on ][p_h_13]
「哎！？为、为什么啊！？公主你喜欢杰特吧？[rhr]
_　分明是两情相悦！这机会多难得啊！」[rhp]

[:princess:]
「我喜欢杰特君？怎么会得出这种结论！？」[rhp]

[:heartshape:][hati kao=6 as=on ][p_h_20]
「可、可是。乘坐铁道时他经常来找我们玩，[rhr]
_　旅途中你不也总是和我们一起行动吗！」[rhp]
[:heartshape:]
「那不就是因为想和杰特待在一起嘛！」[rhp]

[:princess:][puri_w kao=8 as=on ]
「～～～！你、你这是什么荒谬误解……！[rhr]
_　那是因为不仅有杰特君在，哈蒂君也在一起的缘故啦！」[rhp]

[fbgm]

[:heartshape:][hati kao=4 as=on ]
「……！！」[rhp]

[off_all]

[::]
哈蒂君保持着醍醐灌顶的表情僵在原地。[rhp]
……随后是令人窒息的沉默。[rhr]
好像第一次和哈蒂君相处得这么尴尬……[rhp]

[bgm storage="bgm_16.ogg"]

[:heartshape:][hati kao=13 ]
「…………谢了」[rhp]

[:princess:][puri_w kao=4 as=on ]
「哎……？谢什么？」[rhp]

[:heartshape:][hati kao=5 ]
「公主能这么说，我真的超级开心。[rhr]
_　杰特肯定也会高兴的」[rhp]

[:princess:][puri_w kao=0 ]
「？为什么突然提到杰特君？」[rhp]

[:heartshape:][hati kao=1 ][p_h_01]
「我和杰特是同心同体的二人三足。[rhr]
_　但我们各自都有专属的使命」[rhp]
[:heartshape:]
「主角是杰特。这个世界的光环本该属于杰特。[rhr]
_　我只想全力支持那家伙。为了杰特的幸福我什么都愿意做」[rhp]
[:heartshape:]
「说到底我就是杰特的影子。影子被夸奖就意味着，[rhr]
_　影子的主人也受到了褒奖对吧？」[rhp]
[:heartshape:][hati kao=13 ][p_h_07]
「所以这个谢谢要转达给他！[rhr]
_　感谢你夸奖杰特啊！」[rhp]

[off_all]

[::]
哈蒂君露出毫无阴霾的笑容，令我瞬间失神。[rhr]
那份情感毫无虚伪之处的感受痛彻心扉地传递而来。[rhp]
…………可是，为什么呢。[rhr]
完全无法产生共鸣。[rhp]

[:princess:][puri_w kao=2 ]
「…………影子什么的，算什么啊」[rhp]
[:princess:]
「这么华丽吵闹的影子，根本不可能存在吧」[rhp]

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
[vostart]
;--------------------------------------------------------------------------------------------

[:heartshape:][hati kao=4 as=on ]
「诶」[rhp]

[:princess:]
「影子既不会说话，也不会多管闲事」[rhp]

[:heartshape:][hati kao=6 as=on ]
「不，不是这个意思啦」[rhp]

[:princess:][puri_w kao=2 ]
「哈蒂君的心意真的非常帅气哦。[rhr]
_　能真切感受到你是真心最喜欢杰特君了」[rhp]
[:princess:]
「但我觉得，哈蒂君你错了！」[rhp]

[:heartshape:][hati kao=0 as=on ]
「……！」[rhp]

[:princess:][puri_w kao=2 ]
「为了杰特君就可以不顾自己吗？[rhr]
_　他心里肯定也盼望着哈蒂君能获得幸福啊」[rhp]
[:princess:]
「哈蒂君不是任何人的影子。哈蒂君[rhr]
_　就该保持哈蒂君的本色，为哈蒂君自己而活！」[rhp]

[:heartshape:][hati kao=4 as=on ]
「…………，我……保持自我……」[rhp]

[:princess:][puri_w kao=2 as=on ]
「说到底！我和杰特君两情相悦？[rhr]
_　不可能不可能！这点我敢斩钉截铁地说」[rhp]

[:heartshape:][hati kao=6 as=on ]
「？为什么啊？」[rhp]

[:princess:][puri_w kao=2 ]
「听说喜欢的女孩被说变胖了，怎么可能无动于衷。[rhr]
_　不过会对妙龄少女直说变胖的家伙也够离谱的」[rhp]

[:heartshape:][hati kao=8 as=on ]
「抱、抱歉那个是……！」[rhp]
[:heartshape:][hati kao=2 as=on ]
「……但是！我可是超级有自信的。我们之间心有灵犀啊！？」[rhp]
[:heartshape:]
「如果我喜欢的话，那家伙肯定也绝对会喜欢的吧！」[rhp]

[:princess:][puri_w kao=4 as=on ]
「诶」[rhp]

[:heartshape:]
「诶？　…………」[rhp]
[:heartshape:][hati kao=2 as=on hh=on ]
[font size=26]
「啊！！？？」[rhp]
[resetfont]

[off_hati]

[:princess:][puri_w kao=4 as=on ]
「刚才……」[rhp]

[off_puri]

[:jet:][jet kao=0 ]
「你在搞什么啊」[rhp]

[off_all]

[yurasu]

[:heartshape:][hati kao=2 as=on ss=on ]
[font size=28]
「哇啊啊――――！？」[rhp]
[resetfont]

[off_all]

[:jet:][jet kao=2 as=on ]
「吵死了……！突然发什么神经！」[rhp]

[off_all]

[chara_part name="jet" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=on ss=off hh=on hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:]
「突然闹哪样啊！？杰特！[rhr]
_ 这不是杰特么！你这混账！！」[rhp]

[:jet:]
「哈啊？」[rhp]

[:heartshape:]
[font size=28]
「全都是杰特干的好事！！[rhr]
_　我！！　没有！！　关系啊！！」[rhp]
[:heartshape:]
[font size=32]
「有甜瓜吗！？！？」[rhp]
[resetfont]

[:jet:]
「啊，有的」[rhp]

[:heartshape:]
[font size=26]
「不是挺好的嘛！　来，休息结束―――！！」[rhp]

[off_all]

[:heartshape:]
「等着我克林！　这就过去啊！！」[rhp]
[resetfont]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

;走る
[se storage="leg_04.ogg"]

[::]
擅自大喊大叫、擅自推进话题、擅自飞奔而去的哈蒂君。[rhp]
被抛下的我们目瞪口呆站在原地。[rhr]
猛然惊醒，咀嚼着方才的话语。[rhp]


[:heartshape:]
[font color=0x696969]
『如果我喜欢的话，那家伙也绝对―――』[rhp]
[resetfont]

[::]
――――如果我喜欢的话？[rhp]

[:princess:][puri_w kao=2 as=on hh=on ]
「呃……！！！！！」[rhp]

[:jet:][jet kao=6 ][p_j_04]
「嗯……」[rhp]

[:princess:][puri_w kao=2 as=on hh=on ]
[font size=28]
「笨、笨蛋！！　我们是纯洁的朋友关系！！」[rhp]
[resetfont]

[:jet:][jet kao=2 as=on ][p_j_19]
「啊？　不是……」[rhp]

[off_jet]

[:princess:][puri_w kao=8 as=on hh=on ]
[font size=26]
「等一下哈蒂君！！[rhr]
_　一个人去太危险了啊～～～！？」[rhp]
[resetfont]

[off_puri]

;走る
[se storage="leg_04.ogg"]

[:jet:][p_j_21]
「喂、等等！　你怎么也跟着跑……！」[rhp]

[:jet:][jet kao=2 as=on ][p_j_05]
「……真是的，已经不见人影了。那俩人精力也太旺盛了」[rhp]

[off_all]

;****************************************
#
[bg storage="sky_06.jpg" time=1000]
;****************************************

[:jet:]
「不过也好」[rhp]
[:jet:]
「………说不定反而给他们创造了独处的机会」[rhp]

;****************************************
#
[jump storage="ev_a_06.ks" target="*start2"]
;****************************************


[s]

