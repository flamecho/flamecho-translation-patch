﻿
*start

[jump target="*ss_2nd" cond="f.nigmode == 1 && ss_2nd_hkpk == 1"]
[jump target="*ss_16" cond="f.ss_hkpk >= 15"]
[jump target="*ss_15" cond="f.ss_hkpk >= 14"]
[jump target="*ss_14" cond="f.ss_hkpk >= 13"]
[jump target="*ss_13" cond="f.ss_hkpk >= 12"]
[jump target="*ss_12" cond="f.ss_hkpk >= 11"]
[jump target="*ss_11" cond="f.ss_hkpk >= 10"]
[jump target="*ss_10" cond="f.ss_hkpk >= 9"]
[jump target="*ss_09" cond="f.ss_hkpk >= 8"]
[jump target="*ss_08" cond="f.ss_hkpk >= 7"]
[jump target="*ss_07" cond="f.ss_hkpk >= 6"]
[jump target="*ss_06" cond="f.ss_hkpk >= 5"]
[jump target="*ss_05" cond="f.ss_hkpk >= 4"]
[jump target="*ss_04" cond="f.ss_hkpk >= 3"]
[jump target="*ss_03" cond="f.ss_hkpk >= 2"]
[jump target="*ss_02" cond="f.ss_hkpk >= 1"]
[jump target="*ss_01"]

;---------------------------------------------------------------------------------------------
*ss_01
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_07.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_02.ogg"]


[:princess:][puri_w kao=1 ]
「你好！」[rhp]

[:vulpecula:][peku kao=1 ]
「啊，呀吼！　你是来玩的吗～？」[rhp]

[:princess:][puri_w kao=1 ]
「嗯。难得的机会，我想和多个人聊聊天呢」[rhp]

[:vulpecula:][peku kao=1 ]
「很～好嘛！朋友越多越开心呀～」[rhp]

[:vulpecula:][peku kao=1 ]
「博士现在在睡觉呢～，在他醒来之前我们就闲聊会儿！？」[rhp]

[:princess:][puri_w kao=1 ]
「他累了吗？」[rhp]

[:vulpecula:][peku kao=1 ]
「嗯～哈蒂的超辣调味料他原液喝下去后就瘫倒啦～」[rhp]

[:princess:][puri_w kao=1 ]
「为什么要做这种事……」[rhp]

[:vulpecula:][peku kao=1 ]
「博士这个人呀～总是按捺不住好奇心！」[rhp]

[:princess:][puri_w kao=1 ]
「这样啊。那在他醒来前我就打扰一下啦」[rhp]

[:vulpecula:][peku kao=1 ]
「哇～！来，快进来～」[rhp]

[off_all]

[::]
直到回去前博士都没恢复意识，但聊天很开心！[rhp]

[eval exp="f.ss_hkpk = 1"]
[eval exp="f.ss_2nd_hkpk= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_02
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_07.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_02.ogg"]

[:princess:][puri_w kao=1 ]
「你好！」[rhp]

[:darknebula:][hakase kao=3 as=on ]
「……」[rhp]
[:darknebula:]
「……啊，公主。前些天多谢了。[rhr]
_　让你看见失态的样子了」[rhp]

[:princess:][puri_w kao=13 as=on ]
「你没事了吗？」[rhp]

[:darknebula:]
「成了不错的体验呢。原来辣到极致真的会昏过去啊……」[rhp]

[:princess:]
「……今天怎么又没精神？」[rhp]

[:vulpecula:]
「因为直接喝了鲜奶油原液导致胃胀」[rhp]
[:darknebula:]
「果然不能像喝牛奶那样……直接喝呢……」[rhp]

[:princess:][puri_w kao=6 as=on ]
「真不知该说什么好……」[rhp]

[off_all]


[eval exp="f.ss_hkpk = 2"]
[eval exp="f.ss_2nd_hkpk= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_03
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_07.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_02.ogg"]

[:princess:][puri_w kao=1 ]
「你好ー」[rhp]

[:darknebula:][hakase kao=1 ]
「呀公主。心情如何呀」[rhp]

[:princess:][puri_w kao=1 ]
「哦，今天很有精神嘛！没再乱吃东西了吧？」[rhp]

[:darknebula:][hakase kao=1 ]
「别、别误会。饮食并非我唯一的兴趣。[rhr]
_　只是碰巧连续几天都那样罢了」[rhp]

[:vulpecula:][peku kao=1 ]
「今天的研究暂停哦—。要和佩可琪一起玩啦！」[rhp]

[:darknebula:][hakase kao=1 ]
「是啊。公主有兴趣的话也一起来吧？」[rhp]

[:princess:][puri_w kao=1 ]
「可以吗？那我一定要来！」[rhp]

[:vulpecula:][peku kao=1 ]
「好嘞—！今天就来玩双世代家族过家家吧！」[rhp]

[:princess:][puri_w kao=2 as=on ]
[font color=0x4682b4]
（这什么啊……）[rhp]
[resetfont]

[off_all]

[::]
一直玩双世代家族过家家到尽兴为止！[rhp]



[eval exp="f.ss_hkpk = 3"]
[eval exp="f.ss_2nd_hkpk= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_04
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_07.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_02.ogg"]


[:princess:][puri_w kao=1 ]
「你好呀～」[rhp]

[:vulpecula:][peku kao=1 ]
「呀吼—公主！」[rhp]

[:darknebula:][hakase kao=1 ]
「哟，欢迎」[rhp]

[:princess:][puri_w kao=1 ]
「佩可琪，今天想和你一起吃这个」[rhp]

[:vulpecula:][peku kao=1 ]
「什么什么—！？！？」[rhp]

[:darknebula:][hakase kao=1 ]
「哎呀，这是…………」[rhp]

[:princess:][puri_w kao=1 ]
「狐狸乌冬面！让多洛普用魔法变出来的」[rhp]

[:darknebula:][hakase kao=1 ]
「看起来很好吃呢。还是刚做好的」[rhp]

[:vulpecula:][peku kao=1 ]
「好厉害！豆皮寿司闪闪发光好漂亮！！」[rhp]

[:darknebula:][hakase kao=1 ]
「佩可琪，这不是豆皮寿司啦……」[rhp]

[:princess:][puri_w kao=6 ]
「博士，不要泼冷水！」[rhp]

[:darknebula:][hakase kao=1 ]
「哎呀呀，被训斥了呢……」[rhp]

[:vulpecula:][peku kao=1 ]
「哇——！大家一起开动吧！！！」[rhp]

[off_all]



[eval exp="f.ss_hkpk = 4"]
[eval exp="f.ss_2nd_hkpk= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_05
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_07.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_02.ogg"]

[:vulpecula:][peku kao=1 ]
「啊！公主！正想见你—」[rhp]

[:princess:][puri_w kao=1 ]
「？怎么了？」[rhp]

[:vulpecula:][peku kao=1 ]
「那个呀，公主你……其实是公主殿下吧！？」[rhp]

[:princess:][puri_w kao=1 ]
「哎！？」[rhp]

[:vulpecula:][peku kao=1 ]
「博士说过，公主就是公主殿下啦」[rhp]

[:darknebula:][hakase kao=1 ]
「没说错吧？」[rhp]

[:princess:][puri_w kao=1 ]
「唔……公主殿下啊……这么说总感觉不太贴切呢」[rhp]

[:vulpecula:][peku kao=1 ]
「真好呀，佩奇也想成为公主殿下！」[rhp]

[:princess:][puri_w kao=1 ]
「……对了佩奇！[rhr]
_　书上说，所有女孩子都是公主殿下哦」[rhp]

[:vulpecula:][peku kao=1 ]
「真的吗！？！？」[rhp]

[:darknebula:][hakase kao=1 ]
「嗯嗯。你们两个都是非常棒的公主殿下哦」[rhp]

[off_all]



[eval exp="f.ss_hkpk = 5"]
[eval exp="f.ss_2nd_hkpk= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_06
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_07.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_02.ogg"]

[:princess:][puri_w kao=1 ]
「博士和佩奇在车里会乖乖摘帽脱兜帽真了不起呢」[rhp]

[:vulpecula:][peku kao=11 ]
「这是礼仪啦！」[rhp]

[:darknebula:][hakase kao=1 ]
「而且本来就很重嘛」[rhp]

[:princess:][puri_w kao=13 ]
「往博士帽子上堆东西应该很有趣！话说他肯定发现不了」[rhp]

[:darknebula:][hakase kao=1 ]
「就是说啊。[rhr]
_　前几天听到沙沙声还在想是什么…」[rhp]

[:vulpecula:][peku kao=14 ]
「结果是仓鼠在帽子上！超可爱！」[rhp]

[:princess:][puri_w kao=14 ]
「暖心！」[rhp]

[::]
暖心时刻！[rhp]

[off_all]


[off_all]

[eval exp="f.ss_hkpk = 6"]
[eval exp="f.ss_2nd_hkpk= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_07
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_07.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_02.ogg"]

[:princess:][puri_w kao=1 ]
「一直很好奇，你戴的到底是哪种动物的耳朵呀？」[rhp]

[:vulpecula:][peku kao=1 ]
「是小狐狸哟！」[rhp]

[:princess:][puri_w kao=1 ]
「嚯，挺冷门的选择呢」[rhp]

[:vulpecula:][peku kao=1 ]
「对吧～可爱吗？」[rhp]
[:vulpecula:][peku kao=13 ]
「这个啊，是南给我戴上的啦～」[rhp]

[:princess:][puri_w kao=1 ]
「这样啊。你们关系真好」[rhp]

[:vulpecula:][peku kao=14 ]
「嗯！是最好的朋友！」[rhp]
[:vulpecula:]
「真想有一天能和博士、佩奇、公主还有南四个人一起玩啊」[rhp]
[:vulpecula:][peku kao=13 ]
「不、不过应该不可能啦」[rhp]

[:princess:][puri_w kao=1 ]
「诶～为什么？来玩嘛！」[rhp]

[:darknebula:]
「毕竟年纪也到了……」[rhp]

[:princess:][puri_w kao=13 as=on ]
「嗯、嗯嗯……？」[rhp]

[off_all]


[eval exp="f.ss_hkpk = 7"]
[eval exp="f.ss_2nd_hkpk= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_08
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_07.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_02.ogg"]

[:princess:][puri_w kao=1 ]
「你好呀～」[rhp]

[:darknebula:][hakase kao=1 ]
「呀公主。你好啊」[rhp]

[:princess:][puri_w kao=1 ]
「咦，难得见你一个人呢」[rhp]

[:darknebula:][hakase kao=1 ]
「抱歉。佩奇今天[rhr]
_　和哈托谢普他们去玩捉鬼了」[rhp]

[:princess:][puri_w kao=1 ]
「这样啊。博士也一起玩不就好了」[rhp]

[:darknebula:][hakase kao=1 ]
「其实我有次参与过」[rhp]

[:darknebula:][hakase kao=1 ]
「结果被夸德里利昂怒吼[rhr]
_　说大块头别到处乱跑……」[rhp]

[:princess:][puri_w kao=2 ]
「什么人嘛！他自己不也是个大块头！」[rhp]

[:darknebula:][hakase kao=3 ]
「不怪他。是我不小心撞到他[rhr]
_　把里普怼进他鼻孔里了……」[rhp]

[:princess:][puri_w kao=6 ]
[font color=0x4682b4]
（有点想看看那场面……）[rhp]
[resetfont]

[off_all]

[eval exp="f.ss_hkpk = 8"]
[eval exp="f.ss_2nd_hkpk= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_09
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_07.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_02.ogg"]

[:vulpecula:][peku kao=1 ]
「公主～！你好呀！」[rhp]

[:darknebula:][hakase kao=1 ]
「欢迎」[rhp]

[:princess:][puri_w kao=1 ]
「哦，今天你们俩在啊。在干什么呢？」[rhp]

[:darknebula:][hakase kao=1 ]
「搞家庭种植」[rhp]

[:princess:][puri_w kao=1 ]
「家庭……？」[rhp]

[:vulpecula:][peku kao=1 ]
「在种豆苗什么的！！」[rhp]

[:darknebula:][hakase kao=1 ]
「我还是更喜欢迷你番茄呢」[rhp]
[:darknebula:]
「公主也要种点什么吗？[rhr]
_　把多余的种植盆分给你吧」[rhp]

[:princess:][puri_w kao=1 ]
「呃、那个……那就茄子！」[rhp]

[:vulpecula:][peku kao=1 ]
「茄子！？」[rhp]
[:vulpecula:][peku kao=1 ]
「茄子和ナスビ到底有什么区别！？　ビ是什么意思嘛！？」[rhp]

[:princess:][puri_w kao=2 as=on ]
「！？茄……茄子A、茄子B……」[rhp]

[:vulpecula:][peku kao=14 ]
「是想种很多的意思吗！？好厉害！！」[rhp]

[:darknebula:][hakase kao=1 ]
[font color=0x4682b4]
（看她有趣就不打断吧……）[rhp]
[resetfont]

[off_all]

[eval exp="f.ss_hkpk = 9"]
[eval exp="f.ss_2nd_hkpk= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_10
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_07.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_02.ogg"]

[:princess:][puri_w kao=2 ]
「……」[rhp]

[:vulpecula:][peku kao=1 ]
「怎么了小公主，一脸困扰的样子」[rhp]

[:princess:]
「是关于前几天家庭菜园的事……」[rhp]

[:vulpecula:][peku kao=14 ]
「啊！那个呀，已经种到茄子G了哟！」[rhp]

[:darknebula:][hakase kao=5 ]
「太棒了！」[rhp]

[:princess:][puri_w kao=2 ]
「…………其实……」[rhp]

[:vulpecula:][peku kao=0 ]
「嗯？」[rhp]

[:princess:][puri_w kao=2 ]
「要是小不点的话……比起豆苗选香菜……会不会更有搞笑效果……」[rhp]

[:vulpecula:][peku kao=6 ]
「在说什么呀？」[rhp]

[:darknebula:][hakase kao=5 as=on ]
「已经完全被这里的船员同化了呢……」[rhp]

[off_all]


[eval exp="f.ss_hkpk = 10"]
[eval exp="f.ss_2nd_hkpk= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_11
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_07.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_02.ogg"]


[:vulpecula:][peku kao=11 ]
「母～亲～大地～的～胸～怀～里～」[rhp]

[:princess:][puri_w kao=13 ]
「是大地赞颂呢！人类的孩～子～」[rhp]

[:vulpecula:][peku kao=1 ]
「呐博士！大地的胸怀具体指哪里？」[rhp]

[:darknebula:][hakase kao=1 ]
「地幔吧」[rhp]

[:princess:][puri_w kao=6 ]
「但地幔里可没有人类的喜悦呀」[rhp]

[:darknebula:][hakase kao=1 ]
「人类未至的星球核心……[rhr]
_　若能解开这个谜题，某种意义上说是喜悦也不为过」[rhp]

[:princess:][puri_w kao=2 as=on ]
「确、确实……这么说也是」[rhp]

[off_all]

[:vulpecula:][peku kao=11 ]
「伟大大地啊――――――」[rhp]

[off_all]

[:darknebula:][hakase kao=1 ]
「母　亲　大　　地　　啊」[rhp]

[off_all]

[:princess:][puri_w kao=2 ]
「……」[rhp]

[off_all]・

[chara_part name="hakase" body=base kao=14 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="hakase" layer="5" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=5 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]
[chara_part name="puri_w" body=base kao=15 as=off ss=off hh=off hr=on hat=okan]
[chara_show name="puri_w" layer="message0" left="1" top="1" width="330" height="720" wait="true" zindex="1005" time=150]
[:3nin:]
「啊――――――！」[rhr]
「啊――――――！」[rhr]
「啊――――――！」[rhp]

[off_all]



[eval exp="f.ss_hkpk = 11"]
[eval exp="f.ss_2nd_hkpk= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_12
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_07.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_02.ogg"]

[:princess:][puri_w kao=2 ]
「嗯ー……」[rhp]

[:vulpecula:][peku kao=6 ]
「又～在烦恼啦。佩奇才不会种香菜呢～？」[rhp]

[:princess:][
「……8岁！」[rhp]

[off_all]

[chara_part name="hakase" body=base kao=1 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=5 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:][peku kao=1 ]
「博士～！被看得年轻真是太好啦～！」[rhp]

[:darknebula:][hakase kao=1 ]
「哎呀～多亏跟夸德里利昂学了护肤！」[rhp]

[:princess:][puri_w kao=2 ]
「错啦！肯定是问佩奇的年龄呀」[rhp]

[:vulpecula:][peku kao=1 ]
「诶～博库？」[rhp]

[:princess:][puri_w kao=2 ]
「虽然外表言行稚嫩，但知晓大地赞颂……[rhr]
_　我在想大概年龄不详吧」[rhp]

[:vulpecula:][peku kao=13 ]
「遗憾～人家是永远的0岁哟～」[rhp]

[:darknebula:][hakase kao=13 ]
「哎呀哎呀，好大的小婴儿呢」[rhp]

[:vulpecula:][peku kao=14 ]
「叭噗叭噗！」[rhp]

[:princess:][puri_w kao=2 as=on ]
[font color=0x4682b4]
（佩奇……到底几岁啊！魔性之女……！）[rhp]
[resetfont]

[off_all]


[eval exp="f.ss_hkpk = 12"]
[eval exp="f.ss_2nd_hkpk= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_13
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_07.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_02.ogg"]

[:princess:][puri_w kao=2 ]
「……」[rhp]

[chara_part name="hakase" body=base kao=1 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=5 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:]
「这回又怎么啦？又在推理什么？」[rhp]

[:princess:][puri_w kao=2 ]
「博士的单片眼镜……怎么回事？」[rhp]

[:darknebula:][hakase kao=5 as=on ]
「怎么回事？…………是指？」[rhp]

[:princess:]
「去海边时明明摘下来了！[rhr]
_　也就是说其实可以不戴吗？」[rhp]

[:darknebula:][hakase kao=1 ]
「这是装饰单片眼镜啦！」[rhp]

[:princess:][puri_w kao=4 as=on ]
「其实视力很好吗！？」[rhp]

[:darknebula:][hakase kao=1 ]
「嘛～」[rhp]

[:vulpecula:][peku kao=13 ]
「角色塑造啦！」[rhp]

[:princess:][puri_w kao=14 ]
「好帅气ー！」[rhp]

[off_all]




[eval exp="f.ss_hkpk = 13"]
[eval exp="f.ss_2nd_hkpk= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_14
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_07.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_02.ogg"]


[:princess:][puri_w kao=1 ]
「你好！我来玩啦」[rhp]

[chara_part name="hakase" body=base kao=1 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=1 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:darknebula:]
「你好啊公主。今天还是一如既往地精神呢」[rhp]

[:princess:][puri_w kao=1 ]
「今天是来收集问卷的」[rhp]
[:princess:][puri_w kao=1 ]
「前几天收获的茄子，烹饪方法选油炸还是烧烤？」[rhp]

[:darknebula:][hakase kao=13 ]
「烧烤！」[rhp]

[:vulpecula:][peku kao=13 ]
「油炸！」[rhp]

[chara_part name="hakase" body=base kao=2 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=2 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:2nin:]
「…………！」[rhr]
「…………！」[rhp]

[:darknebula:][hakase kao=5 ]
「那、那个…公主选哪种？」[rhp]

[:princess:][puri_w kao=2 ]
「……煮……」[rhp]

[chara_part name="hakase" body=base kao=6 as=on ss=off hh=off hr=on msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=6 as=on ss=off hh=off hr=on msk=off ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:2nin:]
「…………！！」[rhr]
「…………！！」[rhp]

[off_all]

[:darknebula:][hakase kao=3 ]
「无论哪个时代……战争都不会消失呢……」[rhp]

[off_all]




[eval exp="f.ss_hkpk = 14"]
[eval exp="f.ss_2nd_hkpk= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_15
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_07.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_02.ogg"]

[:princess:][puri_w kao=1 ]
「佩奇不怎么看书呢」[rhp]

[:vulpecula:][peku kao=1 ]
「嗯—。因为写的净是些难懂的内容嘛」[rhp]

[:princess:][puri_w kao=1 ]
「可以让博士读给你听呀」[rhp]

[:vulpecula:][peku kao=0 ]
「嗯ー……」[rhp]
[:vulpecula:][peku kao=13 ]
「……佩奇不用啦！打扰博士可不好」[rhp]

[:princess:][puri_w kao=13 ]
「我觉得拜托他的话他会高兴哦」[rhp]

[:vulpecula:][peku kao=0 ]
「……什么都没能教给你的我，没那种资格啊」[rhp]

[:princess:][puri_w kao=0 ]
「咦？　什么？」[rhp]

[:vulpecula:][peku kao=14 ]
「没什么ー！[rhr]
_　小公主，来玩捉迷藏吧捉迷藏！把哈蒂他们也叫上！」[rhp]

[:princess:][puri_w kao=13 ]
「？好！」[rhp]


[eval exp="f.ss_hkpk = 15"]
[eval exp="f.ss_2nd_hkpk= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_16
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_07.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_02.ogg"]


[:princess:][puri_w kao=1 ]
「为什么博士要读那么多书呢？」[rhp]

[:darknebula:][hakase kao=1 ]
「突然这么问呢。这个嘛……」[rhp]

[:darknebula:][hakase kao=1 ]
「与其说是有目的，不如说更像一种本能吧」[rhp]

[:princess:][puri_w kao=0 ]
「本能？」[rhp]

[:darknebula:][hakase kao=1 ]
「即使没有意图 身体也会渴求知识。[rhr]
_　所以我什么都研究 什么书都读啊」[rhp]

[:princess:][puri_w kao=1 ]
「总觉得好厉害……我也会有吗 这样的本能」[rhp]

[:darknebula:][hakase kao=1 ]
「从现在开始寻找就好。[rhr]
_　毕竟你的旅程才刚刚开始」[rhp]

[:princess:][puri_w kao=13 ]
「……！嗯！」[rhp]

[off_all]


[eval exp="f.ss_hkpk = 16"]
[eval exp="f.ss_2nd_hkpk= 1"]

[jump target="*next"]

;---------------------------------------------------------------------------------------------
*ss_2nd
;---------------------------------------------------------------------------------------------

;****************************************
[bg storage="train_07.jpg" time=1000 ]
;****************************************

[winset][bgm storage="bgm_02.ogg"]


[:princess:][puri_w kao=1 ]
「你好ー」[rhp]

[off_all]

[:vulpecula:][peku kao=11 ]
「Zzz…………」[rhp]

[off_all]

[:princess:][puri_w kao=1 ]
「佩可酱 在睡午觉吗～ 我带了点心来哦」[rhp]

[:darknebula:][hakase kao=1 ]
「谢谢 她醒来后一定会非常开心吧」[rhp]

[off_all]



[jump target="*next"]

;---------------------------------------------------------------------------------------------
;---------------------------------------------------------------------------------------------

*next

#
[off_all]

;ev_7への分岐
[if exp="f.ev_a_07 ==1 && f.nigmode == 1"]
[jump storage="ev_a_07.ks" target="*start"]

;ev_6への分岐
[elsif exp="f.ev_a_06 ==1 && f.nigmode == 1"]
[jump storage="ev_a_06.ks" target="*start"]

;ev_3への分岐
[elsif exp="f.ev_a_03 ==1 && f.nigmode == 1"]
[jump storage="ev_a_03.ks" target="*start"]

;ev_2への分岐
[elsif exp="f.ev_a_02 ==1 && f.nigmode == 1"]
[jump storage="ev_a_02.ks" target="*start"]

;夜モードの場合
[elsif exp="f.nigmode == 1"]
[jump storage="ss_main.ks" target="*start"]

;昼モード
[else]
[jump storage="ss_select.ks" target="*select_scene_nig"]
[endif]


