﻿*start

;--------------------------------------------------------------------------------------------
;▼フルボイスセット▼

;ダークネブラ
[voconfig sebuf=1 name=hakase vostorage="hakase/full/{number}.ogg" number=1]
;ヴルペクラ
[voconfig sebuf=1 name=peku vostorage="peku/full/{number}.ogg" number=1]

;--------------------------------------------------------------------------------------------

[:princess:][puri_w ]
「博士、沃尔佩克拉酱。如果可以的话，要不要和我一起，」[rhp]

[:vulpecula:][p_vl_06][peku body=hood kao=14 hh=on ]
[font size=26]
「高兴死了～～～～！」[rhp]
[resetfont]

[:princess:][puri_w kao=0 as=on ]
「诶」[rhp]

[:vulpecula:][p_vl_04][peku body=hood kao=5 hh=on ]
「博库们要被邀请了吗！？谢谢啦！谢谢啦！」[rhp]

[:princess:][puri_w kao=13 as=on ]
「嗯、嗯。如果可能的话希望能一起逛逛」[rhp]

[:vulpecula:][p_vl_14][peku body=hood kao=14 hh=on ]
「转圈！？好啊！转呀转呀转起来！」[rhp]

[off_all]

[chara_part name="hakase" body=base kao=13 as=off ss=off hh=off hr=on msk=hat ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="peku" body=hood kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:]
「喂博士！公主说想和佩奇他们一起玩！[rhr]
_　今天三个人一起可以吗？可以吧？」[rhp]

[:darknebula:][p_da_06]
「当然啦。要转多少圈呢？」[rhp]

[:vulpecula:][p_vl_27]
「太好啦！！博士超温柔～！」[rhp]

[:princess:][puri_w kao=13 as=on ]
「啊、谢谢你们两位。请多关照……」[rhp]

[off_all]

[:quadrillion:][riri kao=6 as=on ]
「……………………」[rhp]

[:princess:][puri_w kao=0 ]
「什么？」[rhp]

[:quadrillion:][p_r_30][riri kao=5 as=on ]
「挺有胆量嘛……居然敢和那两个人同行……」[rhp]

[:princess:][puri_w ]
「为啥？看起来很有趣啊」[rhp]

[:kite:][p_k_03][kite kao=7]
「试着配合一次也不错。就当是社会实践课」[rhp]

[:quadrillion:][p_r_03]
「这倒也是。今后要是住在那个铁道上的话呢……」[rhp]

[:princess:][puri_w kao=2 ]
「？？？」[rhp]

;****************************************
[fbgm]
[set_00 storage="park_08.jpg"]
;****************************************

[bgm storage="bgm_03.ogg"]

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
[vostart]
;--------------------------------------------------------------------------------------------

[::]
就这样，我们立刻坐上了摩天轮。[rhp]

[:princess:][puri_w kao=6 as=on ss=on ]
「………………………………」[rhp]

[off_puri]

[::]
……夸德里利昂和快斗[rhr]
我终于明白他们用好奇的眼神看我的原因了。[rhp]

[chara_part name="hakase" body=base kao=5 as=off ss=off hh=off hr=on msk=hat ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="peku" body=hood kao=5 as=off ss=off hh=on hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:]
「呀——！好厉害，好厉害！好高——！」[rhp]
[:vulpecula:]
「快看博士！整个游乐园都看得见！[rhr]
_　佩奇说不定已经成为这个游乐园的万事通啦！」[rhp]

[:darknebula:]
「真厉害。不愧是佩奇呢」[rhp]

[off_all]

[:princess:][puri_w kao=2 as=on ss=on ]
[font color=0x4682b4]
（这段对话，已经重复多少次了……[rhr]
_　早就记不清超过山顶多少回了……）[rhp]
[:princess:]
（说好一起『逛』游乐园，才不是这种逛法啊……！）[rhp]
[resetfont]

[:vulpecula:][peku body=hood kao=1 ]
「呐呐公主～。呐呐～」[rhp]

[:princess:][puri_w kao=0 as=on ]
「嗯？怎么？」[rhp]

[:vulpecula:][peku body=hood kao=13 ]
「公主你啊～有没有姐姐呀～？」[rhp]

[:princess:][puri_w kao=7 ]
「嗯－，不清楚呢？因为想不起来所以不知道啦……[rhr]
_　总之在回忆起来之前，就当没有……这样行吗？」[rhp]

[:vulpecula:][peku body=hood kao=5 hh=on ]
「真的吗！？那我说啊～听着哦！[rhr]
_　欸嘿嘿……让我来当姐姐好不好呀！」[rhp]

[:princess:][puri_w kao=4 as=on ]
「诶！沃尔佩克拉当姐姐？」[rhp]

[:vulpecula:][peku body=hood kao=14 hh=on ]
「对呀！博士算是哥哥，[rhr]
_　我们就当三人是兄弟姐妹吧！就这么决定啦～！」[rhp]

[:princess:][puri_w kao=0 as=on ]
「哈、哈啊……」[rhp]

[off_peku]

[:darknebula:][hakase msk=hat ]
「呵呵……抱歉啊公主，突然说这些」[rhp]

[:princess:][puri_w ]
「没事。我倒是无所谓啦。感觉很可爱，也挺开心……」[rhp]

[:darknebula:][hakase kao=12 msk=hat ]
「被义妹毫无心理负担地喊『哥哥』实在难以接受。[rhr]
_　这种称呼必须历经多重关卡后，[rhr]
_　饱含深情的『哥哥』才够格……对吧？」[rhp]
[:darknebula:]
「所以今后还请继续叫我『博士』吧，公主」[rhp]

[:princess:][puri_w kao=2 as=on ]
「虽然我不太明白你在说什么……」[rhp]

[off_all]

[chara_part name="hakase" body=base kao=8 as=off ss=off hh=on hr=on msk=hat ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="peku" body=hood kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:]
「博士！佩奇在哪里？哥哥这边差不多准备好了吗？」[rhp]

[:darknebula:][hakase kao=2 msk=hat ]
「等一下 这个地方能不能让我坚持一下立场 佩奇[rhr]
_　虽说只是虚拟家庭 但我想重现现实中可能出现的家庭环境」[rhp]
[:darknebula:]
「因家庭变故突然成为兄妹的两人 能否毫无顾忌地互称兄妹？[rhr]
_　我还不能理解这种心情……所以想知道！」[rhp]

[:vulpecula:][peku body=hood kao=6 ]
「好麻烦～！」[rhp]

[off_all]

[:princess:][puri_w kao=6 as=on ]
[font color=0x4682b4]
（虽然一直只在意佩奇的事[rhr]
_　但博士其实也挺疯癫的呢）[rhp]
[resetfont]

[:vulpecula:][peku body=hood kao=13 ]
「博士虽然有点那个啦。公主要称呼佩奇为[rhr]
_　姐姐也可以哦？」[rhp]

[:princess:][puri_w kao=14 as=on ]
「啊、哈哈哈……！有、有机会的话吧」[rhp]

[:vulpecula:][peku body=hood kao=8 ]
「不行的吗？你是脑袋博士吗！」[rhp]
[:vulpecula:][peku body=hood kao=1 ]
「那我可以叫你小姬吗？」[rhp]

[:princess:][puri_w kao=1 hh=on ]
「！这种叫法可能还挺可爱的！」[rhp]

[:vulpecula:][peku body=hood kao=14 hh=on ]
「对吧～！和佩奇像是配套的对吧？[rhr]
_　因为是姐姐嘛 配套的名字什么的就取一个嘛」[rhp]

[:princess:][puri_w kao=13 hh=on ]
「这、这样啊。谢谢你……！」[rhp]

[:vulpecula:][peku body=hood kao=5 ]
「小姬 现在这趟电车之旅感觉怎～么样？[rhr]
_　有什么困扰的事、或者辛苦的事吗？」[rhp]
[:vulpecula:]
「有任何事都可以说出来哦！[rhr]
_　毕竟我呀，可是你的姐姐呢！」[rhp]

[:princess:][puri_w ]
「那个……真的什么都可以说吗？」[rhp]

[:vulpecula:][peku body=hood kao=5 hh=on ]
「嗯——！尽管交给我吧！」[rhp]

[:princess:][puri_w kao=13 ]
「那首先……我们能下摩天轮了吗？」[rhp]

[yurasu]
[:vulpecula:][peku body=hood kao=2 ]
[font size=30]
「不行！！！！！！」[rhp]
[resetfont]

[:princess:][puri_w kao=2 as=on ]
「为什么啊！！」[rhp]

[:vulpecula:][peku body=hood kao=6 ]
「哼！说了不行就是不行啦！」[rhp]

[:princess:][puri_w kao=3 as=on ]
「这次我真的坐腻了啦！」[rhp]

[off_all]

[chara_part name="hakase" body=base kao=1 as=off ss=off hh=off hr=on msk=hat ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="peku" body=hood kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:darknebula:]
「哈哈哈。佩奇真的很喜欢高处呢」[rhp]

[:vulpecula:]
「嗯！在高处能看见好多地方对吧」[rhp]
[:vulpecula:]
「那样的话，说不定能找到爸爸妈妈！」[rhp]

[fbgm]

[off_all]

[:princess:][puri_w kao=4 ]
「……诶……」[rhp]

[off_puri]

[::]
…………爸爸和，妈妈？[rhp]

[bgm storage="bgm_05.ogg"]

[chara_part name="hakase" body=base kao=1 as=off ss=off hh=off hr=on msk=hat ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="peku" body=hood kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:darknebula:]
「今天有找到他们吗？」[rhp]

[:vulpecula:][peku body=hood kao=7 ]
「嗯——没看到呢……这里也没有吗」[rhp]
[:vulpecula:][peku body=hood kao=13 ]
「……不过这里有这么多人！我们再找找看！」[rhp]

[:darknebula:][hakase msk=hat ]
「那我也奉陪到底吧。[rhr]
_　毕竟我还没见过你的父母呢」[rhp]

[off_all]

[:princess:][puri_w kao=0 ]
「……………………佩奇」[rhp]

[off_puri]

[::]
详细的缘由，大概不该多问吧。[rhr]
正因为知晓这里是何处、我们为何存在，才会这么想。[rhp]

[:princess:][puri_w ]
「…………我也是」[rhp]

[:vulpecula:][peku body=hood kao=0 ]
「？　小公主？」[rhp]

[:princess:][puri_w ]
「我也可以一起帮忙找佩奇的妈妈吗？」[rhp]

[:vulpecula:][peku body=hood kao=14 hh=on ]
「―――！ 嗯、好的呀！谢谢你小公主！」[rhp]
[:vulpecula:]
「那个啊、妈妈很温柔哦、爸爸也……爸爸也是个温柔的人呢！[rhr]
_　我觉得马上就能认出来的、拜托你啦！」[rhp]

[:princess:][puri_w kao=13 ]
「嗯、知道了」[rhp]

[off_all]

[:darknebula:][hakase msk=hat ]
「―――谢谢你、公主。能体谅这么多」[rhp]

[:princess:][puri_w ]
「不需要道谢呀。我只是做自己想做的事」[rhp]
[:princess:][puri_w kao=5 ]
「快看！博士也不要这么优雅地坐着啦、多帮忙找找地面呀」[rhp]

[:darknebula:][hakase kao=5 msk=hat ]
「啊抱歉。我、有恐高症。专职负责守望」[rhp]

[:princess:][puri_w kao=6 as=on ]
「居然能坐银河铁道呢……」[rhp]

[off_all]

[::]
不过即便如此还陪着坐了好几趟摩天轮、我觉得很温柔。[rhr]
这两人之间、存在着我看不见的羁绊吧……[rhp]

[:princess:]
[font color=0x4682b4]
（哥哥和、姐姐吗……）[rhp]
[resetfont]

[::]
……若是这两人、我觉得倒也不坏。[rhp]

[chara_part name="hakase" body=base kao=5 as=on ss=off hh=off hr=on msk=hat ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="peku" body=hood kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:]
「真是的、博士碍事啦！[rhr]
_　我要搜索那边、快换座位呀！」[rhp]

[:darknebula:]
「不行不行不行不行。[rhr]
_　除了这个位置外视线都不能移动」[rhp]

[:vulpecula:][peku body=hood kao=7 ]
「可以爬上来吗？」[rhp]

[:darknebula:][hakase kao=1 msk=hat ]
「啊啊可以。那样的话请便……」[rhp]

[off_all]

;踏む
[se storage="leg_06.ogg"]

[:darknebula:]
「好痛！痛痛痛痛痛！穿着鞋踩脸也太随便了吧！」[rhp]

[:princess:][puri_w kao=2 as=on ]
「……………………」[rhp]

[off_puri]

[::]
………果然还是让我再稍微考虑一下吧……。[rhp]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
[fbgm]
[set_00 storage="park_01e.jpg"]
;****************************************

[bgm storage="bgm_18.ogg"]

[:nusi:][p_ns_02][nusi ]
「好嘞、人都到齐了吧。[rhr]
_　时候也不早了，咱们今天就到这儿吧」[rhp]

[:princess:][puri_w kao=13 ]
「今天谢谢你们！托大家的福玩得超开心」[rhp]

[off_nusi]

[:gonzalez:][p_gn_20][gon kao=6 ]
「公主她们不就只是坐了摩天轮嘛。[rhr]
_　我们可啥都没干啊」[rhp]

[:princess:][puri_w kao=13 ]
「从地面挥手的样子我们都看到了哦」[rhp]

[off_all]

[chara_part name="mata" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="peku" body=hood kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1"  width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:][p_vl_16]
「博库我们呀，把大家的模样看得清·清楚楚呢！[rhr]
_　那副打扮超~显眼的啦！」[rhp]

[:mataroko:][p_mt_31][mata kao=14 ]
「呵呵……！那真是太好了呢」[rhp]
[:mataroko:][mata kao=5 as=on ]
「啊，不过……从第5周左右开始我们就放弃出来迎接了，对不起哦」[rhp]

[:princess:][puri_w kao=5 as=on ]
「没事，我觉得那样才正常……」[rhp]

[off_all]

;他ルートのひめちー呼びフラグ
[eval exp="f.senpai = 1"]

[jump storage="ev_a_02.ks" target=*return]

