﻿
*start

[chara_part name="drop" body=base kao=0 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=1 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「那就这么办！　多洛普在这里搭帐篷等克林。[rhr]
_　而我们履行各自职责的同时，公平地全员一起寻找克林」[rhp]
[:princess:]
「这样就不用全员一起行动，还能搜索更广的范围呢！」[rhp]

[:drop:][drop kao=3 ]
「只能这样了。说不定夸德里利昂[rhr]
_　会自己回来呢」[rhp]

[off_all]
[chara_part name="peku" body=hood kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:kite:]
「哈啊……都怪克林搞得这么麻烦」[rhp]

[:vulpecula:]
「确切说是哈蒂他们的错啦」[rhp]

[off_all]

[chara_part name="hakase" body=base kao=7 as=off ss=off hh=off hr=on msk=hat ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="otiai" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:otiai:]
「我赞成。海边和山脚方向大致也能分组行动」[rhp]

[:darknebula:]
「那我们负责东侧区域，[rhr]
_　哈托谢普你们能负责西侧吗」[rhp]

[off_all]

[chara_part name="jet" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:]
「哦！　包在我身上！」[rhp]

[:jet:][jet kao=3 ]
「～～～～～～～……」[rhp]

[:princess:][puri_w kao=6 ]
「喂。别因为被冷静对待就板着脸」[rhp]

[:jet:]
「真没劲。早知道就该把公主[rhr]
_　而不是克林吹飞算了」[rhp]

[:princess:][puri_w kao=2 as=on ss=on ]
「！？」[rhp]

[:heartshape:][hati kao=5 ]
「安心吧杰特！　今后克林的反应绝对[rhr]
_　会超有趣的好吗！！」[rhp]

[:jet:][jet kao=5 ]
「那倒也是。真希望他快点发火～」[rhp]

[:princess:][puri_w kao=2 as=on ]
「……………………」[rhp]

[off_all]

[:princess:][puri_w kao=13 as=on ]
「……算了不管了！」[rhp]

[off_all]

[chara_part name="hakase" body=base kao=1 as=on ss=off hh=off hr=on msk=on ]
[chara_show name="hakase" layer="1" width="571" height="720" left="40" top="0"  wait="false" time=150]
[chara_part name="kite" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="drop" body=base kao=13 as=on ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="760" top="0" wait="true" time=150]

[:3nin:]
[font color=0x4682b4]
（这样真的好吗……）[rhr]
（这样真的好吗……）[rhr]
（这样真的好吗……）[rhp]
[resetfont]

[if exp="f.a06_d2 == 1 "]
[jump storage="ev_a_06.ks" target="*start2" ]
[endif] 

;****************************************
[fbgm]
[set_00 storage="jungle_02.jpg"]
[bgm storage="bgm_07.ogg"]
;****************************************

[::]
30分钟后。[rhp]

[::]
我和多洛普用魔法在现场清理出足以搭帐篷的空地，[rhr]
制作了约五顶双人帐篷，告一段落后正休息着。[rhp]
通常这是极其费力的工作，但帐篷本身靠魔法直接生成成品，[rhr]
我们只需准备睡袋和炊具等简单物品，所以相当轻松。[rhp]

没有全部依赖魔法解决，刻意保留部分手工操作，[rhr]
能感受到多洛普对这种细节的执着。[rhp]
话说回来，这样确实更有成就感，我也乐在其中。[rhp]

[chara_part name="drop" body=base kao=1 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=1 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:drop:]
「多亏公主从旁协助[rhr]
_　才能这么快完成呢。非常感谢」[rhp]

[:princess:]
「彼此彼此。多洛普的指令清晰明确才是关键」[rhp]

[:drop:][drop kao=13 ][p_d_01]
「毕竟是第二次了。请交给我吧」[rhp]

[off_all]

[::]
他挺起胸膛说出这话时，透着几分得意。[rhr]
那模样莫名显得孩子气，让我忍不住轻笑。[rhp]

;****************************************
[set_time storage="jungle_02b.jpg"]
; 夜フィルター
[filter layer="1" brightness="60"]

;****************************************

[::]
等待其他同伴归来期间，暮色已完全笼罩四周。[rhp]
我们漫无边际地闲聊着，[rhr]
多洛普用魔法生起的篝火在眼前朦胧闪烁。[rhp]

[:drop:][drop kao=7 ]
「……………………」[rhp]

[:princess:][puri_w kao=0 ]
「…………？多洛普？」[rhp]

[:drop:][drop kao=1 ][p_d_19]
「啊、在！怎么了？」[rhp]

[off_puri]

[::]
不知为何他显得格外坐立不安。[rhp]
……该不会是我想的那样吧。[rhp]

[:princess:][puri_w kao=6 ]
「…………该不会是想回电车工作之类」[rhp]

[:drop:][drop kao=4 as=on ][p_d_22]
「为什么您会知道？」[rhp]

[:princess:][puri_w kao=2 as=on ]
「果然……！　适可而止吧。[rhr]
_　现在不是该工作的时候吧？」[rhp]

[:drop:][drop kao=8 as=on ][p_d_25]
「呜呜……！　可、可是不找点事做的话，我就静不下来」[rhp]
[:drop:][drop kao=3 as=on ]
「上次有空闲时去打扫了铁道，[rhr]
_　但这次必须等待夸德里利昂就没法那么做了」[rhp]
[:drop:]
「虽然并非讨厌和公主交谈，[rhr]
_　但像这样悠闲待着的话，该说有种莫名的罪恶感吧」[rhp]

[:princess:][puri_w kao=8 ]
「多洛普真是个工作狂。[rhr]
_　这种时候偶尔放松下不好吗」[rhp]

[:drop:][drop kao=11 ][p_d_32]
「哈哈……谢谢关心。但恕难从命。[rhr]
_　这不是我该承担的职责」[rhp]

[off_all]

[::]
……又来了。『自己的职责』这句多洛普总挂在嘴边的话。[rhp]
单听倒是个寻常词汇，但每当他如此表述时，[rhr]
不知为何在我心里总会投射出异常负面的印象。[rhp]
大概是因为那笑容，那声线，都隐约透着寂寞。[rhp]

[:princess:][puri_w kao=3 ]
「早就想说了，死后还要工作真是太辛苦」[rhp]

[:drop:][drop ][p_d_28]
「辛苦什么的绝无此事。[rhr]
_　我从未对这个职责产生过半点不满」[rhp]

[:princess:][puri_w kao=11 ]
「真了不起啊多洛普。能找到让自己感到有意义的事情真好呢」[rhp]
[:princess:][puri_w kao=3 ]
「…………我什么都没有」[rhp]

[:drop:][drop kao=4 as=on ]
「诶……」[rhp]

[:princess:][puri_w kao=3 ]
「…………我的职责到底是什么呢。[rhr]
_　嘛，虽然正是为了连同这点一起回忆起来才来露营的」[rhp]
[:princess:]
「……但现在还是完全搞不明白啊」[rhp]

[:drop:][drop kao=3 ]
「……………、……我觉得你没必要做到那种程度哦」[rhp]

[:princess:][puri_w kao=0 ]
「……什么意思？」[rhp]

[:drop:][drop kao=13 ]
「现在的你，只要尽情享受这个世界就好。[rhr]
_　我和你的立场不同。没必要执着于职责」[rhp]

[:princess:][puri_w kao=2 ]
「那样不行。没有职责的话，就等于我不存在也没区别嘛」[rhp]

[:drop:][drop ]
「存在本身，就是你的存在理由」[rhp]

[:princess:]
「难道说迄今为止的我，是能接受这种说法的吗？」[rhp]

[:drop:][drop kao=3 as=on ]
「……谁知道呢。毕竟……我从未问过你这个，所以不好说」[rhp]

[off_all]

[::]
说完这句话，多洛普便尴尬地闭上了嘴。[rhp]

[:princess:]
[font color=0x4682b4]
（……怎么办。明明没想把气氛搞成这样）[rhp]
[resetfont]

[::]
因为实在太伤心了。被告知什么都不用做，[rhr]
简直就像自己是个累赘，是个彻头彻尾的废物。[rhp]
明明我是那么希望你能依赖我。[rhp]

[:drop:]
「…………稍微说些话吧」[rhp]

[::]
多洛普凝视着眼前跃动的火焰，用平淡而安静的语气继续说道。[rhp]

[:drop:][drop kao=3 ]
「确实现在的你，什么都不用做」[rhp]
[:drop:]
「但迄今为止的你，一直肩负着职责」[rhp]

[:princess:][puri_w kao=0 as=on ]
「……！」[rhp]

[:drop:][drop kao=3 ]
「在你那天醒来之前，[rhr]
_　公主和我一样担任着乘务员的工作」[rhp]

[:princess:][puri_w kao=4 as=on ]
「哎、我当乘务员！？」[rhp]

[:drop:][drop kao=3 ][p_d_01]
「嗯。以为你难得睡过头去叫你，结果竟是失忆了。[rhr]
_　……遇见『现在的你』那天真是令人震惊」[rhp]

[:princess:][puri_w kao=0 as=on ]
「原、原来是这样……我当乘务员。完全无法想象呢……」[rhp]
[:princess:][puri_w ]
「！　那我现在就开始学习多洛普他们的工作吧！[rhr]
_　不能因为忘记了就什么都不做啊！」[rhp]

[:drop:][drop ][p_d_34]
「不必了。惊讶归惊讶，但并非难以理解。[rhr]
_　……你的职责已经终结。仅此而已」[rhp]

[:princess:][puri_w kao=2 ]
「退休未免太早了吧？」[rhp]

[:drop:][drop kao=14 ][p_d_01]
「因为这是银河铁道」[rhp]

[off_all]

[::]
什么嘛。……明显在敷衍我。[rhr]
……多洛普肯定对我隐瞒了什么。[rhp]
而且那必然与——[rhr]
这个世界既非彼世亦非现世的秘密有关。[rhp]
像我这样的，能从这顽固家伙嘴里问出什么吗。[rhp]

[:princess:]
[font color=0x4682b4]
（……现在似乎不行）[rhp]
[:princess:]
（多洛普肯定不是出于信任我才这么做的。[rhr]
_　只因我是『客人』，才会如此恭敬温柔地对待我）[rhp]
[:princess:]
（………………好不甘心。超级）[rhp]
[resetfont]

[::]
这辆电车究竟是什么。[rhr]
这趟旅途的目的又是什么。[rhp]
此刻在这里的我和多洛普究竟有何不同。[rhp]

[:princess:]
[font color=0x4682b4]
（…………好想知道）[rhp]
[resetfont]

[::]
关于这世界的一切。[rhr]
为此首先必须找回记忆。[rhp]

[:drop:][drop kao=3 ][p_d_05]
「话……话说大家真慢啊。[rhr]
_　难道是没找到什么像样的东西吗」[rhp]

[:princess:][puri_w kao=2 ]
「多洛普」[rhp]

[:drop:][drop kao=0 ]
「嗯？」[rhp]

[:princess:][puri_w kao=2 ]
「……我和夜约定好了」[rhp]

[:drop:][drop kao=2 as=on ][p_d_19]
「―――！　你见到糠星夜了吗？」[rhp]

[off_all]

[::]
果然他是知道那个人的。[rhp]
之前迂回试探时明明从未提过这个名字。[rhp]

[chara_part name="drop" body=base kao=2 as=on ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=3 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「他说这个世界归根结底是属于他的东西」[rhp]
[:princess:]
「我们这些外人擅自闯入给他添了大麻烦」[rhp]

[:drop:]
「……他竟然说这种话……」[rhp]

[:princess:][puri_w kao=2 ]
「我决定要找回记忆正是因为与他的约定」[rhp]
[:princess:]
「当记忆复苏之时，在这个能实现任何愿望的世界里[rhr]
_　我发誓要了却所有未竟的心愿」[rhp]
[:princess:]
「等全部结束后，我打算离开银河铁道」[rhp]

[:drop:][p_d_26]
「怎……怎么能这样！这样可不行。[rhr]
_　你要是从我们的电车上下去的话就会……不，我们就会……」[rhp]

[:princess:][puri_w kao=3 ]
「谢谢你们挽留我。……不过就算我恢复健康，[rhr]
_　要是这样会给别人添麻烦的话，我还是会在意的」[rhp]

[:drop:][drop kao=8 as=on ]
「但是……！」[rhp]

[:princess:][puri_w ]
「听着！接下来才是重点哦」[rhp]
[:princess:]
「虽然现在什么都还没想起来，但此刻的我唯独有一个执念」[rhp]

[:drop:][drop kao=6 as=on ]
「是、是什么……？」[rhp]

[:princess:][puri_w kao=11 ]
「多洛普不能好好休息，没法和我一起享受旅途这件事」[rhp]

[:drop:][drop kao=2 as=on ][p_d_28]
「！　不不……这与其说是执念不如说只是在抱怨，」[rhp]

[:princess:][puri_w kao=5 ]
「我决定了。等取回记忆后，我会重返乘务员岗位。[rhr]
_　然后要让多洛普定期好好休假！」[rhp]

[:drop:][drop kao=3 as=on ]
「什……！？不、不必了！我可是每天都干劲十足呢」[rhp]

[:princess:][puri_w kao=5 ]
「啊！仔细想想哈蒂君他们虽然整天扎波长扎波短的[rhr]
_　但好歹也是乘务员，可以把他们也排进轮班表呢」[rhp]
[:princess:]
「这样偶尔就能让多洛普和他们一起休息啦！」[rhp]

[:drop:][drop kao=6 as=on ][p_d_05]
「我可没听说过啊……」[rhp]
[:drop:][drop kao=2 as=on ]
「…………、……是认真的吗？」[rhp]

[:princess:][puri_w kao=11 ]
「嗯」[rhp]

[:drop:][drop kao=3 as=on ]
「……如果继续这样任性下去，总有一天你[rhr]
_　肯定会后悔的」[rhp]

[:princess:][puri_w kao=13 ]
「呵呵……会像这样给我忠告的事，之前从来没有过呢。[rhr]
_　总是被用『总有一天』啦、『没问题的』啦之类温柔的话语敷衍过去」[rhp]
[:princess:][puri_w kao=5 ]
「我啊，可比多洛普想象的要坚强得多。[rhr]
_　这点程度才不会后悔呢」[rhp]

[:drop:][drop kao=3 as=on ]
「你太天真了。事情可没这么简单」[rhp]

[:princess:][puri_w ]
「……或早或晚，我都要离开这条铁道。[rhr]
_　但在那之前，我想和多洛普一起真正意义上地遨游银河」[rhp]
[:princess:]
「不是作为乘客和列车长，而是站在相同位置的伙伴」[rhp]

[:drop:]
「…………太狡猾了。被这样说的话根本没法拒绝啊」[rhp]

[:princess:][puri_w kao=13 ]
「我就是知道」[rhp]

[:drop:][drop kao=2 ]
「…………即便如此，我也没有要休假的意思」[rhp]

[:princess:][puri_w kao=2 as=on ]
「哈……！？」[rhp]

[:drop:][drop kao=2 ]
「那份留恋，你永远留着也无妨。[rhr]
_　不会妨碍我的工作」[rhp]
[:drop:]
「而且公主您，总不会因为我不休假，[rhr]
_　就觉得至今的旅途完全不快乐吧？」[rhp]

[:princess:][puri_w kao=8 as=on ]
「那、那倒是……确实如此」[rhp]

[:drop:][drop kao=3 ]
「那就没问题了。……些许不满本就是服务业的家常便饭」[rhp]
[:drop:]
「想让我休息的你的不满，强迫我休假的你的不满。[rhr]
_　若追求对等关系，彼此都需要稍加忍耐不是吗」[rhp]

[off_all]

[::]
多洛普的眼神前所未有地认真，褪去了平日的柔和表情[rhr]
他对我说「不满」断然拒绝的态度，让我不禁有些畏缩。[rhp]
…………为何要固执到这种程度呢。[rhp]
那份『工作』到底有什么，能让他执著至此。[rhp]
……仍有太多不明白的事。[rhr]
只是有一点很清楚，继续纠缠下去也无济于事。[rhp]

[:drop:][drop kao=13 ][p_d_02]
「―――好了！这个话题到此为止」[rhp]
[drop ]
「你应该也没意见吧？公主」[rhp]

[:princess:][puri_w kao=3 ]
「…………嗯。我会放弃并重新想办法」[rhp]

[:drop:][drop kao=6 as=on ][p_d_32]
「真不死心呢……算了」[rhp]
[:drop:][drop kao=7 ]
「话说回来，各位是不是来得有点太晚了？[rhr]
_　怎么回事……只要有一组人回来，我就能去搜索的」[rhp]

[:princess:][puri_w kao=0 ]
「多洛普知道他们在哪里吗？」[rhp]

[:drop:][drop kao=0 ]
「不，现在完全不知道。但用魔法的话应该很快能找到」[rhp]

[:princess:][puri_w kao=2 as=on ]
「咦，说起来大家应该都能用魔法吧？难道……」[rhp]

[:drop:][drop kao=6 ][p_d_01]
「没错。虽然都说要去找人，[rhr]
_　其实都在偷懒吧」[rhp]

[:princess:]
「是啊……」[rhp]

[:drop:]
「看他们平时对待夸德里利昂的方式就明白了。[rhr]
_　但即便如此，在这种时候还要捉弄人就过分了！」[rhp]

[:princess:][puri_w kao=5 as=on ]
「克林，你真受欢迎呢～」[rhp]

[:drop:][drop kao=3 as=on ][p_d_10]
「是吗？总觉得有点过头了……」[rhp]

[off_all]

[:unknown:]
「各位～～～！」[rhp]

[:princess:][puri_w kao=4 ]
「……嗯？这个声音是」[rhp]

[off_all]

[::]
从遥远之处传来了熟悉的女孩子声音，[rhr]
我和多洛普四下张望。[rhp]
突然从身后传来沙沙的拨开灌木声，[rhr]
粉红缎带与白玫瑰猛然跃出。[rhp]

[chara_part name="mata" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="nusi" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="gon" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="720" top="0" wait="true" time=150]

[:3nin:]
「久等了！！！」[rhr]
「久等了！！！」[rhr]
「久等了！！！」[rhp]

[:princess:][puri_w kao=5 ]
「三位！都来了呀」[rhp]

[:nusi:][nusi kao=11 ][p_ns_36]
「迟到真对不住啦！[rhr]
_　这可是小努西和快乐伙伴们的登场哦」[rhp]

[:gonzalez:][gon kao=14 ][p_gn_35]
「既然要迟到不如彻底迟到，[rhr]
_　我们特地带了推荐的油炸丸子当伴手礼！」[rhp]

[:mataroko:][mata kao=14 ][p_mt_31]
「推荐蘸盐食用的吃法呢！」[rhp]

[off_all]

[:drop:][drop kao=13 ][p_d_07]
「非常感谢。稍后大家一起享用吧」[rhp]

[:gonzalez:][gon kao=0 ]
「…………话说咦？人数是不是有点少？」[rhp]

[:drop:][drop kao=11 as=on ][p_d_02]
「是的。发生了些状况，大家都外出了」[rhp]

[:gonzalez:][gon kao=2 as=on ][p_gn_19]
「状况？是案件吗！？」[rhp]

[:drop:][drop kao=5 as=on ][p_d_28]
「这个嘛，说是案件不如说是事故……」[rhp]
[:drop:][drop kao=14 ]
「！对了！各位能在这里帮忙看家吗？[rhr]
_　我想趁这段时间去找走失的夸德里利昂―――」[rhp]

[off_all]

[yurasu]

[:princess:][puri_w kao=2 ]
[font size=26]
「是想请三位去把它找回来吧！！」[rhp]
[resetfont]

[off_puri]

[:drop:][drop kao=2 as=on ][p_d_21]
「！？等、公主！我可一句都没说……！」[rhp]

[:nusi:][nusi kao=7 ][p_ns_19]
「到底是哪个？该留守还是该去找？」[rhp]

[:drop:][drop kao=2 as=on ]
「当然是留……」[rhp]

[:princess:][puri_w kao=2 ]
[font size=26]
「希望你们去找呀！！！！」[rhp]
[resetfont]

[:drop:][drop kao=6 as=on ][p_d_09]
「喂……真是的，公主！！」[rhp]

[:princess:][puri_w kao=12 ]
「咻——」[rhp]

[:drop:]
「……！！　这、这是什么人……！」[rhp]

[:nusi:][nusi kao=6 as=on ][p_ns_30]
「？　发生什么了……？」[rhp]

[off_all]

[chara_part name="mata" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="gon" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:mataroko:][p_mt_15]
「既然是姐姐大人的请求，我岂有拒绝之理。[rhr]
_  救命之事就交给魔太郎子吧！」[rhp]

[:princess:][puri_w kao=5 ]
「谢谢，帮大忙了！[rhr]
_  好了快去快去！现在立刻！火速！」[rhp]

[yurasu]

[:gonzalez:][gon kao=8 as=on ][p_gn_21]
「哇！别推啦」[rhp]

[off_all]

[:princess:][puri_w kao=14 as=on ]
「一路顺风！！」[rhp]

[off_all]

[::]
强行驱赶他们离开后，重归寂静的据点。[rhr]
仿佛刚干完体力活般擦了擦额头，转头看向多洛普。[rhp]

[chara_part name="drop" body=base kao=2 as=on ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=5 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:drop:][p_d_09]
「你这人真是……！」[rhp]

[:princess:]
「不劳而获的饭最香呢」[rhp]

[:drop:]
「真有说服力啊」[rhp]

[:princess:][puri_w kao=13 ]
「好啦！夸德里利昂的事暂时可以放心了，[rhr]
_  我们来玩扑克牌吧～」[rhp]

[:drop:][drop kao=12 ]
「不了。我还要劈柴……」[rhp]

[:princess:][puri_w kao=6 as=on ]
「够了！还说这个！？烦死了啦！」[rhp]

[:drop:][drop kao=6 as=on ]
「彼此彼此！」[rhp]

;****************************************
[jump storage="ev_a_06.ks" target="*start2"]
;****************************************

[s]

