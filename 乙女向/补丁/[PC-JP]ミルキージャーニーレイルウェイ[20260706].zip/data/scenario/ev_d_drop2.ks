﻿
*start

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼

;▼フルボイスセット▼
;ドロップ
[voconfig sebuf=1 name=drop vostorage="drop/full/{number}.ogg" number=101]

[vostart]
;--------------------------------------------------------------------------------------------

[:drop:]
「对不起……公主」[rhp]

[::]
终于，多洛普静静地开口了。[rhp]
那双受损的眼睛这次直直地注视着我。[rhp]

;****************************************
;スチル
[still storage="cg/d_d2_1.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/d_d2_1.png"]
;****************************************

[:drop:]
「我知道宙先生的心意」[rhp]
[:drop:]
「我比世上任何人都清楚，他对你深切的爱意、悔恨与留恋」[rhp]
[:drop:]
「…………正因如此，请允许我说出[rhr]
_　那天在火车上，想告诉你的事」[rhp]

[:princess:]
「想告诉我的事……？」[rhp]

[:drop:]
「…………即便如此，我还是喜欢你」[rhp]

[:princess:]
「―――！」[rhp]

[:drop:]
「不是生前的你，也不是『从前』的你，[rhr]
_　而是此刻存在于这里的你」[rhp]
[:drop:]
「你全然不顾身份立场，将我从阴暗处拽向光明的身影耀眼得令人目眩。[rhr]
_　真心为我担忧，愿意陪伴身旁的这份温情，比太阳更温暖」[rhp]
[:drop:]
「…………我真的非常开心。[rhr]
_　和你在一起时，我几乎要忘记自己的立场」[rhp]

[:princess:]
「那为什么要说再见……别走啊……！」[rhp]

[:drop:]
「我明白你挽留的话语字字真心」[rhp]
[:drop:]
「……但你生前确实曾倾心于宙，这也是事实」[rhp]

[:princess:]
「…………！」[rhp]

[:drop:]
「当你的记忆恢复时，你一定会选择宙」[rhp]
[:drop:]
「我和他之间隔着无法逾越的岁月长河」[rhp]
[:drop:]
「……所以我早已下定决心。[rhr]
_　当你找回记忆的时候……或是当宙先生来到这里时」[rhp]
[:drop:]
「我打算将这条铁道托付给宙先生」[rhp]

[:princess:]
「怎么会……那你从一开始就打算消失吗……」[rhp]

[:drop:]
「不能放任他继续痛苦下去。[rhr]
_　如果以我的立场可以做到，我很乐意让出位置」[rhp]
[:drop:]
「如果这能带来他和你的幸福，那对我而言也是幸福」[rhp]
[:drop:]
「……请一定要幸福。你的笑容才是我最大的动力」[rhp]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
;スチル終了
[still_end frame="win.png" storage="park_03n.jpg" time=1000]
;****************************************

[:princess:][puri_w kao=3 as=on ]
「――――――！　那样才一点都不幸福！」[rhp]

[:drop:][p_d_12][drop kao=3 ]
「为什么？你终于能和宙先生在一起了。[rhr]
_　这对你来说明明是最好的」[rhp]

[:princess:][puri_w kao=2 ]
「过去或许是这样没错！[rhr]
_　那种事真的那么重要吗……？」[rhp]
[:princess:]
「现在的我喜欢的人，是多洛普啊！」[rhp]

[:drop:][drop kao=4 ]
「――――――！」[rhp]

[:princess:][puri_w kao=3 hh=on ]
「替代品也好，现实也好……都无所谓。[rhr]
_　为什么要用这种事来拒绝我的心意」[rhp]
[:princess:]
「就算你克制着自己感情，可就像你还是喜欢上了我那样，[rhr]
_　我也会……在过去和现在之间改变的呀」[rhp]
[:princess:]
「无论是过去现在还是未来！全部加起来我最喜欢的人就是你！[rhr]
_　就算记忆恢复我也敢断言这份心意绝不会改变……！」[rhp]
[:princess:]
「所以……！留下来吧多洛普。不要把我一个人丢下！」[rhp]

[:drop:][drop kao=0 ]
「公主……」[rhp]

[:princess:][puri_w kao=3 ]
「好寂寞啊……没有多洛普的每一天……」[rhp]

[:drop:][drop kao=3 ]
「…………、可以吗……？[rhr]
_　像我这种只是替代品的人，说出这么任性的话」[rhp]
[:drop:]
「说什么想要留在这里……」[rhp]
[:drop:]
「…………说什么还想待在你身边」[rhp]

[:princess:][puri_w kao=8 ]
「我听说落合君曾经是我的朋友」[rhp]
[:princess:]
「如果那样的话，我还是希望落合君能回来。[rhr]
_　明明没死却不可以待在这种地方」[rhp]
[:princess:]
「就算不记得、就算本人希望这样！[rhr]
_　怎么可能想着让朋友去死啊！」[rhp]

[:drop:][p_d_31][drop kao=11 ]
「………………」[rhp]
[:drop:]
「―――……你真是个坚强的人呢。[rhr]
_　无论何时都能毫不畏惧地说出自己的意见」[rhp]

[:princess:][puri_w kao=8 ]
「啊……我好像有点耍威风了呢……」[rhp]

[:drop:][drop kao=13 ]
「或许呢」[rhp]

[:princess:][puri_w kao=8 as=on ]
「！」[rhp]

[:drop:][p_d_01][drop kao=13 hh=on ]
「……、我也想向你学习。[rhr]
_　无论别人怎么想，我都会坚定地说出自己的意见」[rhp]
[:drop:]
「我也……不。我喜欢你。[rhr]
_　因为想和你在一起，所以想留在这个世界」[rhp]
[:drop:]
「这件事，我会好好告诉宙。[rhr]
_　……我不会再逃避了，也不会退让。我要堂堂正正地和你吵一架」[rhp]

[:princess:][puri_w kao=4 hh=on ]
「多洛普……」[rhp]

[:drop:][drop kao=5 as=on ]
「虽然这么说了，但其实还是相当不安的啊。[rhr]
_　作为冒牌宙先生的我，竟敢反抗真正的宙先生」[rhp]
[:drop:]
「………可是，这份情感是真实的。[rhr]
_　我会尽力试试看」[rhp]

[:princess:][puri_w kao=1 hh=on ]
「呜……！嗯。这才是多洛普啊」[rhp]
[:princess:]
「能遇见你真是太好了[rhr]
_　今后我也想继续和你一起旅行」[rhp]
「你会跟我一起走的吧[rhr]
_　我的手，可是被你牵住的啊！」[rhp]

[:drop:][drop kao=1 hh=on ]
「嗯……！」[rhp]

[off_all]

[::]
十指相扣，相视而笑。[rhr]
这幅光景曾以为再也不会重现。[rhp]
不，甚至比从前更美好。[rhr]
心意得到传达，感情获得了回应。[rhp]
世上还有比这更幸福的事吗。[rhp]

[fbgm]

――――――就在这时。[rhp]

;****************************************
[bg storage="white.jpg" time=1500]
[bgm storage="bgm_12.ogg"]
;****************************************

[:drop:]
「――――――！」[rhp]

[:princess:]
「怎、怎么回事！？」[rhp]

[::]
诡异的光芒吞噬四周，多洛普的身影消失了。[rhp]
那一瞬。[rhp]
我脑海中浮现那段时光的―――……[rhp]


;-----------------------------------------------------------
;-----------------------------------------------------------

[if exp="sf.d_d_end == 1"]
要跳过公主的往事篇章吗？[rhr]　【[link target="*start2"]是[endlink]/[link storage="ev_d_drop4.ks" target="*start"]否[endlink]】
[s]
[endif] 

;-----------------------------------------------------------
;-----------------------------------------------------------

; →【ev_d_drop4】へ
[jump storage="ev_d_drop4.ks" target="*start"]

;-----------------------------------------------------------
;-----------------------------------------------------------

*start2

[cm]

;-----------------------------------------------------------
;-----------------------------------------------------------

;****************************************
[set_w storage="park_03p.jpg"]
[bgm storage="bgm_19.ogg"]
;****************************************

[::]
――――――光芒终于收束。[rhp]
因停电而陷入黑暗的游乐设施[rhr]
此刻恢复了原本，甚至更耀眼的光辉。[rhp]
面对这般景象，我竟未感到丝毫讶异。[rhr]
本人大概认为这是某种类型的演出吧。[rhp]
听着背后传来的脚步声，我静静地这样想着。[rhp]

[:unknown:]
「恭喜，公主」[rhp]

[::]
背后传来平和的声音。[rhr]
对来者是谁我已心中有数。[rhp]
我镇定地，却又带着明确的意志转过身去。[rhp]

[:sausu:][sausu kao=11 ]
「终于走到这一步了呢」[rhp]
[:sausu:][p_s_27][sausu kao=1 ]
「……现在的你，看起来非常幸福」[rhp]

[:princess:][puri_w kao=8 ]
「………南………」[rhp]

[off_puri]

[:drop:][drop kao=4 as=on ]
「南，为什么你会在这里」[rhp]

[:sausu:][sausu kao=1 ]
「我和公主打了个赌。[rhr]
_　我是来验证答案的」[rhp]

[off_all]

[:princess:][puri_w kao=7 ]
「………………」[rhp]

[:sausu:][sausu kao=1 ]
「太好了呢公主。……不，唯独此刻[player2]正想这样呼喊。[rhr]
_　已经没必要再加以限制了呐」[rhp]

[:princess:][puri_w kao=2 ]
「……………是啊」[rhp]
[:princess:]
「我的名字是、星名[player]。……全都想起来了」[rhp]

[off_all]

[:drop:][drop kao=4 as=on ]
「――――――――！」[rhp]

[off_all]

[:sausu:][p_s_16][sausu kao=1 ]
「[player2]。你是个可怜的孩子。[rhr]
_　无处可去，一无所成，简直是被囚禁的公主啊」[rhp]
[:sausu:]
「你的人生，过得如何？[rhr]
_　稍微比这个世界优秀一点的地方有吗？」[rhp]
[:sausu:]
「是在云的彼端幸福生活，还是再次在泥沼的世界中重新开始……」[rhp]
[:sausu:]
「不妨听听看。那个答案」[rhp]

[::]
虹色却不含笑意的眼睛看向这边。[rhr]
充满仿佛确信胜利一般的自信。[rhp]

[off_all]

……即便如此，我的答案早已决定。[rhp]

[:princess:][puri_w kao=2 ]
「我……」[rhp]

[off_all]

[:sora:][sora kao=2 ]
「[player2]！」[rhp]

[off_all]

[:princess:][puri_w kao=4 ]
「……！　宙君」[rhp]

[off_all]

[::]
从入口处气喘吁吁跑过来的、[rhr]
是落合君……不对、是宙君。[rhp]
看来是跑过来的样子。[rhr]
稍微调整一下呼吸，然后他开始说话。[rhp]

[:sora:][sora kao=8 as=on ]
「中途突然亮起了灯，让我有点在意。[rhr]
_　甩掉那些家伙费了些功夫……不过，总算成功摆脱了」[rhp]

[:princess:][puri_w kao=13 ]
「没什么大不了的。别在意」 
[:sora:][p_so_22][sora kao=2 ]
「真了不起啊。………我叫你宙」[rhp]

[:princess:][puri_w kao=8 ]
「！」[rhp]

[:sora:][sora kao=0 ]
「你想起来了吗」[rhp]

[:princess:][puri_w kao=1 ]
「……、嗯。全都想起来了」[rhp]

[:sora:][sora kao=3 ]
「这样啊…………」[rhp]
[:sora:]
「………………、…………太好了」[rhp]

[:princess:][puri_w kao=1 ]
「宙君……那个啊，我」[rhp]

[off_all]

[::]
像是要打断我的话一般，[rhr]
宙君夸张地发出一声明显的叹息。[rhp]

[chara_part name="drop" body=base kao=3 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sora" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sora:][p_so_27]
「哟多洛普。让你等了这么久，约会还顺利吗？」[rhp]

[:drop:][drop kao=3 as=on ]
「宙先生……」[rhp]

[:sora:][sora kao=2 ]
「差不多该适可而止了。时间也不早了，请回去吧」[rhp]
[:sora:]
「不管别人说什么，这里的列车长已经是老子了」[rhp]

[:drop:][p_d_22][drop kao=3 ]
「………………」[rhp]

[:sora:][sora kao=5 ]
「没关系的。我也一直在以自己的方式努力。[rhr]
_　绝不会让你过上受苦的人生」[rhp]
[:sora:]
「我们一起加油吧。[rhr]
_　就算立场对调，我们也一定能――――――」[rhp]

[:drop:][drop kao=0 ]
「………………」[rhp]

[:sora:][sora kao=2 as=on ]
「…………多洛普？」[rhp]

[off_all]

;****************************************
;スチル
[still storage="cg/d_d2_2.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/d_d2_2.png"]
;****************************************

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼

;ソラ
[voconfig sebuf=1 name=sora vostorage="sora/full/{number}.ogg" number=45]

[vostart]
;--------------------------------------------------------------------------------------------

[:drop:]
「…………那、那个」[rhp]
[:drop:]
「我……果然还是想留在这里」[rhp]

[:sora:]
「哈……？」[rhp]

[:drop:]
「抱歉。我知道自己在说任性的话」[rhp]
[:drop:]
「但我已经决定不再欺骗自己的心情了。[rhr]
_　要勇敢地向你表达真实想法」[rhp]
[:drop:]
「我…………我也喜欢公主」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:sora:]
「！」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:drop:]
「想在这里继续和她旅行。所以……」[rhp]

[:sora:]
「别自作主张胡说八道」[rhp]

[:drop:]
「……！宙啊，」[rhp]

[:sora:]
「你才是宙。我现在是多洛普了」[rhp]
[:sora:]
「你不是要代替我吗？[rhr]
_　那就回去啊。回到现实继续我未完成的事」[rhp]
[:sora:]
「而我留在这里继续你的人生」[rhp]

[:drop:]
「呃……！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
;スチル終了
[still_end frame="win.png" storage="park_03p.jpg" time=1000]
;****************************************

[:princess:][puri_w kao=0 ]
「………………」[rhp]

[:sausu:][p_s_16][sausu kao=13 ]
「……如何？[rhr]
_　要等看完他们的结局再决定你的答案吗？」[rhp]

[:princess:][puri_w kao=1 ]
「没这个必要」[rhp]

[:sausu:][p_s_03][sausu kao=1 ]
「……诶？」[rhp]

[off_all]

[::]
将南留在身后，我向前迈出一步，站在宙君面前。[rhp]
眼前的宙君，与那时一起欢笑的[rhr]
和那时的宙君似乎有些不同了。[rhp]
对一切都感到疲惫，仿佛将一切视为敌人的，可怕眼神。[rhp]
让他变成这样的，是抛下他离去的……[rhr]
……不是别人，正是我们。[rhp]

[:princess:][puri_w kao=3 ]
「…………对不起」[rhp]

[:sora:][p_so_11][sora kao=2 as=on ]
「道什么歉。不管你说什么，我都……」[rhp]

[:princess:][puri_w kao=8 hh=on as=on ]
「我一直迟钝地伤害了宙君很多次。[rhr]
_　首先想为这件事道歉……对不起」[rhp]
[:princess:]
「明明绝对不该说『初次见面』这种话。[rhr]
_　宙君是我重要的―――」[rhp]

[fbgm]

[:sora:][sora kao=7 ]
「无所谓」[rhp]

[off_all]

[::]
又被打断了。简直像是在躲避『那句话』般。[rhp]

[:sora:][p_so_28][sora kao=2 ]
「只要你回想起来就足够了。[rhr]
_　从今往后我们会永远在一起。终于能实现愿望了」[rhp]

[:princess:][puri_w kao=3 ]
「不……那是不行的」[rhp]

[bgm storage="bgm_13.ogg"]

[off_all]

[chara_part name="sora" body=base kao=2 as=on hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sausu:][p_s_26]
「难道你……在开玩笑？[rhr]
_　你要走下这铁道，选择转世重生？」[rhp]

[:sora:][sora kao=2 ]
「别说傻话！那怎么可能。[rhr]
_　我绝不会允许这种事……！」[rhp]
[:sora:]
「幸福是有限度的。即使转世重生，[rhr]
_　难道你不明白幸福只是开场白而已？」[rhp]
[:sora:]
「就算活着，这世界也是地狱。[rhr]
_　证明这点的正是你们这群除了等死什么都不懂的人吧！」[rhp]

[off_all]

[:princess:][puri_w kao=3 ]
「……我的人生确实没有留下任何东西，[rhr]
_　或许连是否存在意义都难以说清」[rhp]
[:princess:]
「但我不认为自己是白白死去。因为这样宙君才会、[rhr]
_　为了追寻我……追寻我们而来到这里啊」[rhp]
[:princess:]
「虽说是地狱般的人生，但有宙君在身边。[rhr]
_　那样的结局，我其实已经很满足了」[rhp]

[:sora:][sora kao=3 ]
「谁要听你说漂亮话！[rhr]
_　给我说实话。你其实―――」[rhp]

[:princess:][puri_w kao=0 as=on ]
「但我不想重活一次」[rhp]

[:sora:][p_so_13][sora kao=8 ]
「……哈……？」[rhp]

[off_all]

[::]
没错。我想说的正是这个。[rhp]
对多洛普的思念。[rhr]
与大家的羁绊。[rhp]
这些都不是可以轻易割舍的、[rhr]
对我而言无足轻重的东西。[rhp]
因此我做出这个选择。[rhr]
……即便这意味着否定过去的自己。[rhp]

[:princess:][puri_w kao=13 ]
「我不想重来。因为我以自己的人生为荣」[rhp]
[:princess:]
「我决定了。要留在银河铁道」[rhp]

[:sora:][p_so_10][sora kao=2 ]
「等等。那刚才的发言就前后矛盾了。[rhr]
_　如果我和你都留在这里，为什么『我的愿望无法实现』？」[rhp]
[:sora:]
「该不会……你以为能把我送回那边吧……！？」[rhp]

[:princess:][puri_w kao=4 ]
「当然。宙君必须回到那边的世界」[rhp]
[:princess:]
「因为宙君还活着啊」[rhp]

[:sora:][sora kao=6 ]
「开什么玩笑！现在不是说这种层面话题的时候吧！[rhr]
_　你以为这种程度的说服我会点头答应吗！？」[rhp]
[:sora:]
「别小看我啊……！薰死了，你们也死了！[rhr]
_　被留下的我怀着怎样的心情活到现在，你明白吗！」[rhp]

[:princess:][puri_w kao=3 ]
「……不明白啊……但是，即使理解了[rhr]
_　宙君的心情，我的想法也不会改变」[rhp]
[:princess:]
「无论用何种语言诉说，我都有我的信念」[rhp]

[:sora:][sora kao=8 as=on ]
「…………」[rhp]

[:princess:][puri_w kao=3 ]
「宙君，告诉过我的吧。说将来的梦想是当医生」[rhp]
[:princess:]
「那个梦想，必须实现」[rhp]

[:sora:][p_so_25][sora kao=0 ]
「……当医生没有意义了」[rhp]
[:sora:]
「我想医治的只有你们。其他人都是顺带。没兴趣」[rhp]

[:princess:][puri_w kao=1 ]
「哈哈……好久没听到这句『没兴趣』了」[rhp]

[:sora:][sora kao=2 ]
「～～～～！ 你以为是谁害得一切都变得无所谓了！」[rhp]
[:sora:]
「活下去啊你……！　凭什么擅自就死掉！[rhr]
_　明明决定好要让我来治好你的！　开什么玩笑……！」[rhp]
[:sora:]
「我可是……努力过了啊！　这种事太不讲理了！」[rhp]

[:princess:][puri_w kao=13 ]
「等着医生宙君的不止我一个人。[rhr]
_　像我们这样的孩子，一定都在等着宙君啊」[rhp]

[:sora:][sora kao=6 ]
「想当医生的人多如牛毛。比我优秀的家伙要多少有多少！[rhr]
_　既然如此 拯救他人的未必非得是我啊！」[rhp]
[:sora:]
「再说你们这些人 根本就没有谁[rhr]
_　期待过我实现梦想……！」[rhp]

[off_all]

[::]
大颗泪珠从宙君眼中滚落。[rhp]
……我自以为能理解被留下之人的心情。[rhp]
我也曾寂寞过。当薰君与和君死去时。[rhr]
……当宙君渐渐不再来玩耍时。[rhp]
想必很痛苦吧。想必很难熬吧。[rhr]
痛哭之后 不得不接受世事无常的现实。[rhp]
最后连眼泪都流干的时候 或许心早已枯萎了。[rhp]
宙君他 一定也是一样的。[rhp]

[:princess:][puri_w kao=3 hh=on ]
「………………要是能说出'留在这里就好'该多好」[rhp]
[:princess:]
「但是做不到。虽然讨厌分别 却也不想你留在这里。[rhr]
_　因为我最喜欢宙君了。不想你死」[rhp]
[:princess:]
「因为是挚友嘛。理所当然啊」[rhp]

[:sora:][sora kao=4 hh=on ]
「…………！」[rhp]

[:princess:][puri_w kao=1 hh=on ]
「那个啊……可以拜托你吗」[rhp]

[:sora:][sora kao=7 ]
「拜托……？」[rhp]

[:princess:][puri_w kao=13 ]
「欸嘿嘿……其实我呢。[rhr]
_　将来想当护士的！」[rhp]
[:princess:]
「不想毫无价值地死去。[rhr]
_　一直憧憬着米卡亲。想成为能帮助他人的人」[rhp]
[:princess:]
「听说宙君要当医生时[rhr]
_　想着要是和宙君在一起就能像那两个人一样了」[rhp]

[:sora:][p_so_29][sora kao=3 as=on ]
「………………什么啊，那种事……」[rhp]

[:princess:][puri_w kao=14 hh=on ]
「这个梦想就托付给宙君了。所以，拜托」[rhp]
[:princess:]
「活下去。宙君」[rhp]

[:sora:][sora kao=7 ]
「…………」[rhp]

[off_all]

[:drop:][drop kao=0 ]
「公主……」[rhp]

[off_all]

[:sausu:][sausu kao=3 hh=on as=on ]
「………………」[rhp]

[off_all]

[::]
我静静等待着沉默不语的宙君开口。[rhp]
多么任性的说辞啊。[rhr]
但宙君不也说了同样乱来的话吗，彼此彼此啦。[rhp]
……不过可能有点狡猾吧。[rhr]
因为我明白的。宙君对那种话最没抵抗力了。[rhp]
因为是挚友嘛。理所当然啊。[rhp]
―――宙君用双手捂住脸，深深长叹了一声。[rhp]
他擦拭眼角，抹去泪水。[rhr]
看来是下定决心了。[rhp]
在那里浮现的，是我所熟知的那个困扰至极的老好人表情。[rhp]

[:sora:][sora kao=3 ]
「…………真想拒绝啊」[rhp]

[:princess:][puri_w kao=3 as=on ]
「宙君……！」[rhp]

[:sora:]
「你这家伙真是从来不听人说话。[rhr]
_　总是擅自横冲直撞，把自己当世界的中心似的」[rhp]
[:sora:]
「…………到头来我也只能点头」[rhp]

[:princess:][puri_w kao=1 ]
「……没错。就算被拒绝被无视，[rhr]
_　我也会一直重复到你回头看我为止」[rhp]
[:princess:][puri_w kao=13 ]
「……就像初次见面时那样」[rhp]

[:sora:][sora kao=5 ]
「啊——还有这回事来着。那时候真是烦死了……」[rhp]

[off_all]

[:sora:]
「…………真怀念啊……」[rhp]

[::]
扭曲着脸仿佛又要哭出来，无力地笑了笑。[rhr]
方才的激动仿佛假象，此刻的宙君平静得出奇。[rhp]
他轻轻呼出一口气，转头看向多洛普。[rhp]

[chara_part name="drop" body=base kao=1 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sora" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sora:]
「[player2]的搭档很辛苦吧」[rhp]

[:drop:][drop kao=13 ]
「多少有点……但不知为何，和她在一起每天都很开心」[rhp]

[:sora:][sora kao=5 ]
「你没救了。到这份上这辈子都绝对拗不过她了」[rhp]
[:sora:]
「…………我们一样啊」[rhp]

[:drop:][drop kao=1 ]
「深感荣幸」[rhp]
[:drop:]
「请放心交给我。绝不会让您后悔」[rhp]

[:sora:][sora kao=11 ]
「随你便」[rhp]

[off_all]

[::]
淡淡笑了笑，背对我们准备离开的宙君。[rhr]
望着那道背影，南忧心忡忡地开口。[rhp]

[chara_part name="sora" body=base kao=3 as=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sausu:][sausu kao=1 ]
「……要回去了吗」[rhp]

[:sora:][p_so_01][sora kao=12 ]
「嗯。……突然想起来了。[rhr]
_　我最大的愿望不是当医生，也不是来到这个世界」[rhp]
[:sora:]
「……更不是只有我自己获得满足的结果」[rhp]
[:sora:]
「我希望他们能幸福。所以……」[rhp]
[:sora:][sora kao=5 ]
「……如果这样就好，那便这样吧」[rhp]

[off_all]

[:princess:][puri_w kao=4 hh=on ]
「……宙君……」[rhp]

[:sora:][sora kao=5 ]
「要是随便敷衍死人的请求，就算冤魂作祟也怨不得人。[rhr]
_　我在现世害怕的只有模拟考试成绩和幽灵」[rhp]
[:sora:]
「绝对会实现愿望。你安心死着吧」[rhp]

[:princess:][puri_w kao=13 hh=on ]
「……呵呵，明白啦。拜托你了宙君」[rhp]

[:sora:][sora kao=5 ]
「噢」[rhp]

[off_all]

[chara_part name="sora" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sausu:]
「要回去的话，需要我送你到那边吗」[rhp]

[:sora:][sora kao=7 ]
「不，不必。那家伙大概正在附近看着吧」[rhp]

[off_all]

[:princess:][puri_w kao=7 ]
「？　看着是说……」[rhp]

[off_all]

[:yoru:][p_y_17][yoru kao=2 ]
「切……」[rhp]

[off_all]

[chara_part name="drop" body=base kao=4 as=on ss=off hh=off hr=on kao=off ]
[chara_show name="drop" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=4 as=on ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「哇！　夜！？」[rhp]

[:drop:]
「难道一直在这里？」[rhp]

[off_all]

[:yoru:][p_y_15][yoru kao=6 ]
「啊。因为要监视某个蠢货」[rhp]

[off_all]

[chara_part name="sora" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sora:]
「抱歉啊夜。既然你都看见了应该明白……」[rhp]
[:sora:]
「……是我的完败」[rhp]

[:yoru:][p_y_24][yoru kao=12 ]
「……这样啊」[rhp]

[:sora:][sora kao=8 as=on ]
「冷酷的家伙。明明可以稍微安慰我一下的」[rhp]

[:yoru:][yoru kao=2 ]
「若你已按心意行事并获得满足，又何需慰藉。[rhr]
_　况且，我也正觉得该结束对你任性妄为的纵容了」[rhp]
[:yoru:]
「为了满足你的种种任性要求，积攒的力量即将耗尽」[rhp]

[:sora:][p_so_13][sora kao=4 ]
「诶……」[rhp]

[:yoru:][yoru kao=3 ]
「无论是武还是宙，都让我受够了给你们收拾烂摊子。[rhr]
_　下次必须存比现在更多的钱才行」[rhp]
[:yoru:]
「今后就由我一个人，来想办法把你们从这个世界解决掉」[rhp]

[off_sora]

[chara_part name="sausu" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="true" time=150]

[:sausu:]
「真温柔呢。……意思是暂时放过我们？」[rhp]

[:yoru:][yoru kao=2 ]
「会继续监视你。[rhr]
_　毕竟还有最优先需要解决的案子」[rhp]

[:sausu:][sausu kao=3 ]
「………………是啊」[rhp]

[:princess:][puri_w kao=0 ]
「……？那个我可能想不起来」[rhp]

[:sausu:][sausu kao=13 as=on ]
「没、没什么。公主别在意」[rhp]

[:yoru:][yoru kao=0 ]
「就算告诉你，你也什么都……」[rhp]

[:princess:][puri_w kao=0 as=on ]
「…………？」[rhp]

[off_all]

[:sora:][sora kao=6 ]
「怎样都行，快点吧。[rhr]
_　在开始舍不得之前我想赶紧回去」[rhp]

[off_all]

[:yoru:][yoru kao=12 ]
「是吗」[rhp]

[off_all]

[::]
宙君始终保持着干脆的态度。[rhr]
完全没有这是最后分别的氛围。[rhp]
即使长大成人，宙君还是那个宙君啊。[rhr]
直到现在才想起，他本就是个不表露真心的人。[rhp]

[:yoru:][p_y_15]
「…………那么」[rhp]

[::]
夜将单手举至脸侧，以他为中心展开了光芒构成的圆阵。[rhp]
宙君抬脚踏入了那个光环中。[rhp]

[fbgm]

这样啊。这下真的要分别了。[rhp]
得说点什么。那个——[rhp]

[:drop:][drop kao=1 ]
「那个！宙先生！」[rhp]

[off_all]

[bgm storage="bgm_28.ogg"]

[::]
在我犹豫不决之际，多洛普先向前迈出了一步。[rhp]
背对着我们站在光中的宙君，[rhr]
听到多洛普的声音后微微睁大眼睛转过身来。[rhp]
多洛普径直走向他，伸出紧握着某物的手。[rhp]

;****************************************
;スチル
[still storage="cg/d_d2_3.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/d_d2_3.png"]
;****************************************
;--------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;--------------------------------------------------------------------------------------------

[:drop:]
「请带上这个」[rhp]

[:sora:]
「…………？宝石？」[rhp]

[::]
多洛普递来的，是我们成对佩戴的钻石。[rhp]
让他握住那颗小钻石后，多洛普说道：[rhp]

[:drop:]
「因为我们是同伴。无论天空还是陆地，无论身在何处」[rhp]

[:sora:]
「…………哦。谢啦」[rhp]

[::]
与冷淡的言辞相反，他露出了讽刺般的笑容。[rhp]
我明白的。[rhr]
当感到开心时，宙君就会露出这样的表情。[rhp]
从那时起就真的什么都没变。[rhp]

;****************************************
;スチル終了
[still_end frame="win.png" storage="sky_07.jpg" time=1000]
;****************************************

正当我默默守望着不打扰他们时，[rhr]
宙君的视线突然朝我投来。[rhp]
继而浅浅一笑。[rhr]
那是仿佛接纳了一切般的，宁静微笑。[rhp]

[:sora:]
「再见啦，公主」[rhp]
[:sora:]
「…………要幸福啊」[rhp]

[:princess:]
「呜……嗯……宙君也是」[rhp]

[::]
拼命忍住不哭出声，嗓音颤抖着。[rhp]
有些话必须要说。[rhr]
因为这次真的是，最后一次了。[rhp]

[:princess:]
「一直一直以来谢谢你了……」[rhp]
[:princess:]
「……我，再也不会忘记了」[rhp]

[::]
倾听着这些话，宙君又笑了起来。[rhr]
这次是毫无阴霾的，如晴空般的笑容。[rhp]

;****************************************
[bg storage="white.jpg" time=1500]
;****************************************

光芒逐渐增强。[rhr]
他们的身影早已看不见了。[rhp]
他还停留在那里吗？[rhr]
怀着信念低声说道。[rhp]

[:princess:]
「……再见」[rhp]

[::]
因为是你的话，绝对没问题的。[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************

[fbgm]

[s_mask color=0xffffff time=3000]
; 背景表示
[bg storage="hsps_08a.jpg" time=100]
; ウィンドゥの設定
[position layer="message0" frame="win2.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[s_mask_off time=3000]

;****************************************

[::]
―――在不久前见过同样的景色中醒来。[rhp]

[:sora:]
「………………」[rhp]

[::]
记得那时将东西递给多洛普，[rhr]
也记得紧握它时掌心的硬度。[rhp]
…………总觉得。[rhr]
虽然真的只是下意识地，看了看手掌。[rhp]
空空如也。[rhp]

[:sora:]
[font color=0x4682b4]
（…………也是啊）[rhp]
[resetfont]

[::]
将天空的温度重新攥紧，用手背遮住双眼。[rhp]
深深吸气。充盈肺部的空气，[rhr]
带着令人怀念的、毋庸置疑属于这个世界的味道。[rhp]
……而后缓缓吐出。[rhp]
伴着残留的寂寞，慢慢地。[rhp]

;****************************************
[bg storage="sky_02.jpg" time=1000]
;****************************************

[bgm storage="bgm_39.ogg"]

[::]
啊，不知为何突然就想哭了呢。[rhp]
八云君的时候也好，薰的时候也好，和近的时候也好，[player2]的时候也好，[rhr]
比起对死亡的悲伤，愤怒更胜一筹。[rhp]
……那个理由，现在已经明白了。[rhp]

之所以愤怒，是因为谁都没有错。[rhp]
如今之所以悲伤，是因为我理解了。[rhp]
所谓现实，就是即使痛苦也必须接受的事。[rhp]

[:sora:]
「……没事的……」[rhp]

[::]
即便如此我也能看见。[rhp]
应该前进的下一段道路。[rhr]
应该追寻的梦想。[rhp]

…………春天已经近在咫尺了。[rhp]

;****************************************

[s_mask color=0xffffff time=3000]
; 背景表示
[bg storage="train_01.jpg" time=100]
[free_filter ]
; ウィンドゥの設定
[position layer="message0" frame="win.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[s_mask_off time=3000]

;****************************************

[:princess:][puri_w body=unif kao=1 hat=hat ]
「锵锵——！」[rhp]

[chara_part name="hati" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:2nin:]
「喔～～～！！」[rhr]
「喔～～～！！」[rhp]

[:princess:][puri_w body=unif kao=5 hh=on hat=hat ]
「呵呵呵！怎么样！这套服装！」[rhp]

[:heartshape:][p_h_08][hati kao=1 hh=on ]
「嚯——！超级适合你啊！！」[rhp]

[:vulpecula:][p_vl_08][peku kao=1 hh=on ]
「好帅——！最棒了！」[rhp]

[off_all]

[chara_part name="jet" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="riri" body=base kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:quadrillion:][p_r_18]
「难得当上公认可业游民，真是个好心的家伙。[rhr]
_　我都想替你去了呢」[rhp]

[:jet:][jet kao=6 as=on ]
「说得好像你平时有在干活似的」[rhp]

[off_all]

[:kite:][kite kao=7 ]
「没想到公主真的会恢复记忆呢。[rhr]
_　说实话，还以为她会永远那样下去了」[rhp]

[:princess:][puri_w body=unif kao=13 hh=on hat=hat ]
「回想过往的自己后，被叫做公主[rhr]
_　或是叫你快斗都有些害羞了呢」[rhp]

[:kite:][kite kao=1 ]
「嘛这样也不错。就当彼此都重获新生好了」[rhp]

[:princess:][puri_w body=unif kao=13 hat=hat ]
「嘿嘿……！嗯！」[rhp]

[off_all]

[::]
――――――自那以后，我依然停留在银河铁道之中。[rhp]
作为银河铁道的一员，与曾经的我同样，[rhr]
再度复职车掌继续着旅程。[rhp]


[:princess:]
[font color=0x4682b4]
（…………那时渴望重获新生的心情并非虚假）[rhp]
[:princess:]
（但在这里我找到了重要的东西。[rhr]
_　那份甚至让我觉得输给南也无所谓的心情）[rhp]
[:princess:]
（对如今的我而言，幸福就是……）[rhp]
[resetfont]

[:drop:][drop kao=14 ]
「公主！」[rhp]

[off_all]

[::]
被呼唤名字时，恍然回首。[rhr]
完全恢复状态的多洛普正绽放着灿烂笑容。[rhp]

[chara_part name="drop" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=unif kao=1 as=off ss=off hh=off hr=on hat=hat  ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:drop:][p_d_04]
「在抵达下个目的地前，要不要一起去检查车厢？」[rhp]

[:princess:][puri_w body=unif kao=5 hh=on hat=hat ]
「！嗯，交给我吧！」[rhp]

[off_all]

[:heartshape:][hati kao=13 ]
「啊，那我也…」[rhp]

[off_all]

[chara_part name="hakase" body=base kao=1 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720" left="40" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=4 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="720" top="0" wait="true" time=150]

[:darknebula:]
「喂喂这可不行」[rhp]

[:vulpecula:][peku kao=2 hh=on ]
「插队可不好！」[rhp]

[off_all]

[chara_part name="jet" body=base kao=11 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=6 as=on hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:]
「？？插队？」[rhp]

[:jet:]
「哎呀呀。风气要败坏了呢……」[rhp]

[off_all]

;****************************************
[set_b storage="train_04.jpg"]
;****************************************

离开客车厢，我们来到了机房。[rhr]
之前约定好要让多洛普教我火车操作方法的。[rhp]
虽说是车掌总觉得该会驾驶才提出请求，[rhr]
据说平时都是自动驾驶，基本不需要人工操作。[rhp]
虽说如此，在给外行人进行各种复杂说明后，[rhr]
我们决定稍作休息。[rhp]
这种微不足道的闲暇时光，从前的多洛普简直无法想象。[rhp]

[:drop:][drop kao=1 ]
「公主，工作已经习惯了吗？」[rhp]

[:princess:][puri_w body=unif kao=13 hat=hat ]
「完全没问题。虽然多洛普教得好是原因之一，[rhr]
但『公主』记忆力出色也是关键呢」[rhp]

[:drop:][p_d_31][drop kao=13n ]
「呵呵呵！她确实是个完美主义者。[rhr]
_　我也受过她很多帮助呢」[rhp]
[:drop:]
「如今的你工作起来也丝毫不逊色于她哦」[rhp]

[:princess:][puri_w body=unif kao=8 hat=hat ]
「理想还很遥远啊……我真的能成为她那样吗」[rhp]

[:drop:][drop kao=1 ]
「不是你亲口说过不必变成那样吗」[rhp]
[:drop:]
「我朋友公主和[rhr]
_　我恋人公主，本来就是完全不同的两个人啊」[rhp]

[:princess:][puri_w body=unif kao=14 hh=on hat=hat ]
「真是的！虽然听得有点害羞」[rhp]

[:drop:][p_d_28][drop kao=14 hh=on ]
「其、其实说完后我自己也觉得挺难为情的……」[rhp]

[:princess:][puri_w body=unif kao=1 hat=hat ]
「这次可不准当作没发生过哦」[rhp]

[:drop:][p_d_19][drop kao=4 as=on ]
「……诶？」[rhp]

[:princess:][puri_w body=unif kao=11 hat=hat ]
「其实我也同时想起来了。[rhr]
_　庆功会之后，多洛普居然对我k……」[rhp]

[yurasu]

[:drop:]
[font size=25]
「哇啊――――――！！！！[rhr]
_　我道歉！这事下次再说！！！」[rhp]
[resetfont]

[off_all]

[::]
自那以后，多洛普开始向我展现更多真实的自己。[rhp]
不仅是平日列车长那种一丝不苟的模样，[rhr]
还会像这样流露焦急情绪，认真地传达心意。[rhp]
现在我终于能理解他为何要部分消除我的记忆。[rhr]
能够将和宙君的关系升华成积极状态真是太好了。[rhp]
这次银河铁道的目的地清单里，[rhr]
也充分采纳了多洛普的意见。[rhp]
光是想象就令人雀跃。在他身边感受他会被何种场所吸引，[rhr]
又会以何种方式享受旅途——[rhp]

;****************************************
[bg storage="train_12.jpg" time=1000]
;****************************************
[::]
……话虽如此，关于南与夜的这个世界难题仍未解决。[rhp]
据说夜仍未放弃阻挠我们的旅行。[rhp]
若要获得他对我们存在的认可，[rhr]
至少需要找出无需依赖那幅绘画就能继续旅程的替代方案。[rhp]
正因为他是连我们灵魂滞留都抱有疑问的人物，[rhr]
虽说不会轻易让步……但至少被强制下车的情况会减少吧。[rhp]
如何才能让夜认可我们呢？[rhr]
找到这个方法，正是此刻旅途的目标。[rhp]

;****************************************
[bg storage="train_04.jpg" time=1500]
;****************************************

[:drop:][drop kao=0 ]
「那个…您脸色很凝重，发生什么事了吗？」[rhp]

[:princess:][puri_w body=unif kao=11 hat=hat ]
「……唔、没事」[rhp]
[:princess:][puri_w body=unif kao=1 hat=hat ]
「和提洛普斗嘴很开心。[rhr]
_　真希望这趟旅程能永远持续下去」[rhp]
[:princess:]
「所以想着得先说服夜才行」[rhp]

[:drop:][drop kao=12 ]
「说得是啊……虽然我觉得事情不会这么顺利……」[rhp]
[:drop:][drop kao=11 ]
「…………但我有自信」[rhp]

[:princess:][puri_w body=unif kao=0 hat=hat ]
「自信？」[rhp]

[:drop:][p_d_01][drop kao=13 ]
「我觉得只要和你在一起，什么事都能做到」[rhp]
[:drop:]
「那个……虽然没什么依据」[rhp]

[:princess:][puri_w body=unif kao=13 hh=on hat=hat ]
「呵呵！　说什么呢，真奇怪」[rhp]
[:princess:]
「但很神奇。我也隐约觉得总会有办法的。[rhr]
_　只要是和提洛普一起，好像什么都做得到」[rhp]

[:drop:][drop kao=13 ]
「这是我的荣幸」[rhp]

[off_all]

;****************************************
;スチル
[still storage="cg/d_d2_4.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/d_d2_4.png"]
;****************************************

;--------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;--------------------------------------------------------------------------------------------

[:drop:]
「……公主」[rhp]
[:drop:]
「谢谢你实现了我的梦想。[rhr]
_　能再次和你同行简直像做梦一样」[rhp]
[:drop:]
「为了回应你挽留的期待，我定会让这趟旅程精彩纷呈」[rhp]
[:drop:]
「…………、和你一起！」[rhp]

[:princess:]
「―――！　嗯！」[rhp]


;****************************************
[still_end frame="win.png" storage="train_12.jpg" time=500]
;****************************************

[:drop:]
「好了！　那就向下一站出发吧！」[rhp]

[:princess:]
「哦！」[rhp]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
#
[bg storage="white.jpg" time=1500]
;****************************************

坚定的意志很美。[rhp]
不过，也无须抗拒改变。[rhp]
也曾有过沉浸在悲伤中的日子。[rhr]
曾有过因痛苦而哭泣的日子。[rhp]
即便如此，人们仍能无数次地重新振作。[rhp]

;****************************************
[bg storage="sky_11.jpg" time=1500]
;****************************************

不再回望苦涩的过往。[rhr]
但会将其深深珍藏于心，继续前行。[rhp]

星之海。天空地面。[rhr]
虽黯淡却闪耀的银河。[rhp]
银河轨道。[rhr]
魔法铁道。[rhp]

开始旅程吧。[rhr]
在这片没有轨道的天空中。[rhp]

无论多远无论多远，都与你一同。[rhp]

[jump storage="ev_d.ks" target="*ending2"]

