﻿*start

;--------------------------------------------------------------------------------------------
;▼フルボイスセット▼
;ハートシェイプ
[voconfig sebuf=1 name=hati vostorage="hati/full/{number}.ogg" number=21]
;ジェット
[voconfig sebuf=1 name=jet vostorage="jet/full/{number}.ogg" number=18]
;ゴンザレス一億世
[voconfig sebuf=1 name=gon vostorage="gon/full/{number}.ogg" number=14]
;--------------------------------------------------------------------------------------------

[:princess:][puri_w kao=1 ]
「哈蒂君、杰特君。有件事想和你们商量……」[rhp]

[:heartshape:][p_h_02][hati kao=2 ]
[font size=27]
「不用说完我都懂！！」[rhp]
[resetfont]

[:princess:][puri_w kao=0 ]
「咦！」[rhp]

[:heartshape:][p_h_31][hati kao=5 ]
「我看到了……！　你的心声……！」[rhp]
[font size=22]
「你也想坐对吧！？[rhr]
_　过山车！」[rhp]
[resetfont]

[:princess:][puri_w kao=4 hh=on ]
「！可以吗？ 真的能跟你们一起？」[rhp]

[:heartshape:][p_h_01][hati kao=5 ]
「尖叫设施要是没人尖叫就太无聊了！[rhr]
_　我和杰特倒是不怕，公主你呢？」[rhp]

[:princess:][puri_w kao=2 as=on hh=on ]
「我、我不知道。从来没坐过」[rhp]

[:heartshape:][p_h_06][hati kao=14 ]
「那、就试试看吧！　今天要玩个痛快！」[rhp]

[:princess:][puri_w kao=14 hh=on ]
「谢谢……！　拜托你们了！」[rhp]

[off_all]

[:jet:][p_j_17][jet kao=5 ]
「话说回来，暂且不管公主参加与否……[rhr]
_　这种时候还缺那个固定班底的老朋友吧」[rhp]

[off_all]

[:gonzalez:][p_gn_18][gon kao=2 as=on ]
「哆嗦……」[rhp]

[off_all]

[chara_part name="jet" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="hati" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:hutago:]
[s_playse storage="hati/part/36.ogg" buf=1] 
[s_playse storage="jet/part/36.ogg" buf=2] 
「冈萨雷斯！」[rhr]
「冈萨雷斯！」[rhp]

[:princess:][puri_w ]
「诶！　原来你和冈萨雷斯君关系很好嘛」[rhp]

[off_all]

[chara_part name="jet" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="80" top="0" wait="false" time="150"]
[chara_part name="hati" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="421" top="0" wait="false" time="150"]
[chara_part name="gon" body=base kao=2 as=on ss=on hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="720" top="0" wait="true" time="150"]

[:3nin:]
「才怪！！」[rhr]
[font size=25]
「没错！」[rhr]
「没错！」[rhp]
[resetfont]

[off_all]

[chara_part name="mata" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="nusi" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720"left="645" top="0"  wait="false" time="150"]
[chara_part name="puri_w" body=base kao=1 as=off ss=off hh=off hr=on hat=okan]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:mataroko:]
「其实小刚虽然长得那样，但特别怕这些玩意儿呢」[rhp]

[:nusi:][nusi ]
「双子组每次这种场合都会拉上他。[rhr]
_　天生就是抖S体质」[rhp]

[:princess:][puri_w kao=13 ]
「诶！　果然关系超好的嘛」[rhp]

[off_all]

[chara_part name="jet" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="hati" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:heartshape:][p_h_31]
「押走～～～～！」[rhp]

[:jet:][p_j_06]
「小混混路过啦～快让开～」[rhp]

[off_all]

[:gonzalez:][p_gn_21][gon kao=8 as=on ss=on ]
「放开我！别闹了！我可是温柔的怪兽啊！[rhr]
_　这种粗暴的事真的不适合我啦～！」[rhp]

[off_all]

[:heartshape:][p_h_04][hati kao=5 ]
「你在干嘛啊公主！磨蹭的话我们就先走啦！」[rhp]

[:princess:][puri_w kao=4 as=on as=on ]
「啊、等、等一下啦！」[rhp]

[off_all]

;****************************************
#
[bg storage="sky_09.jpg" time=300]
;****************************************

[:drop:]
「路上小心～！」[rhp]

[::]
伴随着多洛普轻快的声音，[rhr]
我们向着游乐园进发了……！[rhp]

;****************************************
[fbgm]
[set_00 storage="park_02.jpg"]
;****************************************

[bgm storage="bgm_21.ogg"]

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
[vostart]
;--------------------------------------------------------------------------------------------

[:heartshape:][hati kao=5 ]
「好了！我第一个盯上的是[rhr]
_　那边那个会转圈的那个玩意儿！」[rhp]

[:princess:][puri_w kao=2 as=on ]
「那是什么啊！会在最高点倒过来哎！」[rhp]

[:heartshape:][hati kao=5 ]
「没错！刺激度一兆点啊！赶紧去坐——」[rhp]

[off_all]

[:gonzalez:][gon kao=3 as=on ss=on ]
「～～～～～～噫……！」[rhp]

[:heartshape:][hati kao=6 ]
「冈萨雷斯～。真不像个男人！是男人就下定决心！」[rhp]

[:gonzalez:][gon kao=2 as=on ss=on ]
「切、烦死了……！[rhr]
_　老子正在精神集中。别妨碍我！」[rhp]
[:gonzalez:][gon kao=12 as=on ss=on ]
「不可怕、不可怕、不可怕、不可怕……！[rhr]
_　和后空翻一样……和后空翻……」[rhp]

[off_all]

[:jet:][jet kao=6 ]
「话说你根本不会后空翻吧」[rhp]

[off_jet]

[chara_part name="jet" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="80" top="0" wait="false" time="150"]
[chara_part name="gon" body=base kao=5 as=on ss=on hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="355" top="0" wait="false" time="150"]
[chara_part name="hati" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="760" top="0" wait="true" time="150"]

[:gonzalez:]
「好嘞！！！小鬼们准备好了吗！！」[rhp]

[:heartshape:]
「就是在等你！快走啊！马上就要开始了！」[rhp]

[:gonzalez:][gon kao=8 as=on ss=on ]
「诶……！啊、咦？不用排队之类的吗……」[rhp]

[:jet:][jet kao=5 ]
「快速通行证也万无一失」[rhp]

[:gonzalez:][gon kao=5 as=on ss=on ]
「不、不不！别别别、别那么着急……[rhr]
_　慢慢来吧。好吗？拜托了」[rhp]

[off_all]

[:princess:][puri_w kao=6 as=on ]
「不要紧吧？冈萨雷斯君」[rhp]

[:heartshape:][hati kao=14 ]
「反正一直都这么不靠谱所以肯定没问题啦！」[rhp]

[:princess:][puri_w kao=2 as=on ]
[font color=0x4682b4]
（这根本不能算没问题！）[rhp]
[resetfont]

;****************************************
[set_00 storage="park_04.jpg"]
;****************************************

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:gonzalez:][gon kao=3 as=on ss=on ]
「……………………………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:princess:][puri_w kao=2 as=on ]
「……………………」[rhp]

[off_all]

[chara_part name="jet" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="hati" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:heartshape:]
「哇啊——！玩得太尽兴了杰特！[rhr]
_　说不定已经称霸整个游乐园了吧！？」[rhp]

[:jet:]
「搞不好都坐了两轮呢。真不愧是哈蒂」[rhp]

[:heartshape:][hati kao=5 ]
「公主觉得怎么样！？[rhr]
_　过山车有趣吗！？」[rhp]

[:princess:][puri_w kao=14 as=on ]
「！啊……超、超棒哦！特别开心！」[rhp]

[:heartshape:][hati kao=14 ]
「那就太好啦！尖叫系果然最棒啦！！」[rhp]

[:princess:][puri_w kao=5 hh=on ]
「我说不定还能再玩第三轮……！」[rhp]

[:heartshape:][hati kao=5 hh=on ]
「咱们真合拍！我当然也这么打算！」[rhp]
[:heartshape:]
「对吧杰特！？」[rhp]

[:jet:][jet kao=12 as=on ]
「我就不去了……可能有点晕车」[rhp]

[:heartshape:][hati kao=4 as=on ]
「……！真的？这样啊……！那我也算了」[rhp]

[:jet:][jet kao=6 as=on ]
「哈？不不，为啥啊。[rhr]
_　你们去玩就行了呗？别顾虑我」[rhp]

[:heartshape:][hati kao=3 as=on ]
「可、可是啊。不能丢下杰特你……」[rhp]

[:jet:][jet kao=13 ]
「没事，哈蒂玩得开心我就开心啦！」[rhp]

[:heartshape:][hati kao=6 as=on ]
「～～～～……好、好吧！既然你都这么说……」[rhp]
[:heartshape:][hati kao=1 ]
「……，好嘞！走吧公主！[rhr]
_　这次反过来比赛谁喊得更久吧！」[rhp]

[:princess:][puri_w kao=5 ]
「真是新奇的尝试……！正合我意！」[rhp]

[:jet:][jet kao=11 ]
「好啦好啦，路上小心～」[rhp]

[off_all]

[:jet:][jet kao=6 as=on ]
「……………………」[rhp]
[:jet:]
「………哈蒂这家伙。明明不用每次都对我这么客气的」[rhp]
[:jet:]
「喂。冈萨雷斯你也这么觉得吧？」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:gonzalez:][gon kao=3 as=on ss=on ]
「……………………………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[:jet:][jet kao=2 as=on ]
「已、已经死了……」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
[fbgm]
[set_00 storage="park_02.jpg"]
;****************************************

[bgm storage="bgm_31.ogg"]

和杰特君他们分开后，[rhr]
我们又继续研究起各种游乐设施。[rhp]
虽然都是刚玩过的项目，[rhr]
但因为太有趣了反而让人犹豫要不要再玩几次。[rhp]
我兴奋地转身想听取哈蒂君的意见。[rhp]

[:princess:][puri_w kao=13 ]
「哈蒂君，接下来玩哪个好？」[rhp]

[:heartshape:][hati kao=13 as=on ]
「呃、这个嘛……」[rhp]

[:princess:]
「那边转五圈的小型设施也不错，[rhr]
_　但高空俯冲的那个也很难割舍啊！」[rhp]

[:heartshape:][hati kao=5 as=on ]
「啊……」[rhp]

[:princess:]
「虽然都想玩，但也不能让公主久等！[rhr]
_　必须严格筛选出绝对不能错过的——」[rhp]

[:heartshape:][hati kao=3 as=on ]
「～～～～……唔」[rhp]

[:princess:][puri_w kao=0 ]
「……哈蒂君？从刚才就没什么精神，身体不舒服吗？」[rhp]

[:heartshape:][p_h_33][hati kao=8 as=on ]
「……！对不起公主！我还是先回去吧！」[rhp]

[:princess:][puri_w kao=4 as=on ]
「哎！为什么？」[rhp]

[:heartshape:][hati kao=3 as=on ]
「杰特是出于温柔才会那样说……但我实在做不到。[rhr]
_　把那个家伙独自留下自己却去享乐的事，我绝对办不到！」[rhp]
[:heartshape:]
「如果我是杰特的立场肯定会很寂寞！」[rhp]

[:princess:][puri_w kao=0 ]
「哈蒂君……」[rhp]
[:princess:][puri_w kao=13 ]
「……我明白了！那我们就回杰特君他们那里吧」[rhp]

[:heartshape:][hati kao=4 as=on ]
「诶……真的可以吗？这可是你第一次来游乐园？[rhr]
_　明明还有很多项目没玩够吧！」[rhp]
[:heartshape:]
「又不知道杰特什么时候能恢复，[rhr]
_　要不混进其他组里？我送你们过去」[rhp]

[:princess:][puri_w ]
「不用啦，我也要和哈蒂君一起回去。[rhr]
_　既然都到这里了，最后当然要四个人一起热闹到底！」[rhp]
[:princess:]
「上次博士不是说缓解眩晕最好靠聊天分散注意力吗[rhr]
_　有我在的话，能聊的话题也会多一倍哦！」[rhp]

[:heartshape:][hati kao=0 as=on ]
「公主……」[rhp]

[:princess:][puri_w kao=13 ]
「对了！趁休息时吃点东西吧！[rhr]
_　从刚才就超级在意这股甜香味呢」[rhp]
[:princess:]
「用游乐园特供的美食和饮料[rhr]
_　热热闹闹开派对，肯定会超开心的！」[rhp]

[:heartshape:][p_h_31][hati kao=14 hh=on ]
「……嘿嘿！也对……说得是啊」[rhp]
[:heartshape:]
「过山车也要讲究张弛有度嘛！[rhr]
_　等杰特恢复精神后，我们四个再一起逛就行啦！」[rhp]

[:princess:][puri_w kao=13 ]
「说得对！」[rhp]

[:heartshape:][p_h_06][hati kao=5 ]
「那现在赶快去买些点心回来吧！」[rhp]

[:princess:][puri_w kao=4 ]
「哈蒂君知道这个香味的真面目吗？」[rhp]

[:heartshape:][p_h_02][hati kao=14 ]
「这是爆米花哦！[rhr]
_　从甜的到咸的，有各种各样的口味呢」[rhp]
[:heartshape:]
「不过因为总是和杰特喜好撞车，[rhr]
_　其实我也不是特别了解啦」[rhp]

[:princess:][puri_w kao=0 ]
「？　那你们互相选不一样的不就好了。[rhr]
_　这样还能交换着品尝各种口味」[rhp]

[:heartshape:][p_h_31][hati kao=5 ]
「不，我们是一心同体、两人三脚的关系！[rhr]
_　选同样的东西才是至高享受啊！」[rhp]

[:princess:][puri_w kao=13 ]
「你们俩可真是固执呢。[rhr]
_　不过今天可以边交换边品尝四个人的口味哦！」[rhp]

[:heartshape:][p_h_13][hati kao=4 ]
「！！确实……！终于能吃到盐味以外的了！」[rhp]

[:princess:][puri_w kao=14 ]
「就是这么回事！那我们现在去买吧！」[rhp]

[:heartshape:][p_h_02][hati kao=14 ]
「噢！带路就交给我吧！」[rhp]

;****************************************
[set_00 storage="park_04.jpg"]
;****************************************

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[chara_part name="jet" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]
[chara_part name="puri_w" body=base kao=11 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:jet:]
「怎么是你们。结果还是回来了啊」[rhp]

[:princess:]
「嗯。难得有机会，大家决定一起休息」[rhp]

[off_all]

;****************************************
;スチル
[still storage="cg/a_02_h_1.png" rule="021.png" width="1280" height="720" time=500]
[cg storage="cg/a_02_h_1.png"]
;****************************************

[:princess:]
「所以嘛，锵锵——！[rhr]
_　我们把爆米花买回来啦！」[rhp]

[:jet:]
「……！！居然有盐味以外的！？」[rhp]

[:princess:]
「因为也有我的份和冈萨雷斯君的份呀」[rhp]
[:princess:]
「给！这就是冈萨雷斯君的那份！」[rhp]

[:gonzalez:]
「……等、等等。[rhr]
_　这诡异的颜色……究竟是什么口味？」[rhp]

[:heartshape:]
「芥末明太子辣椒蛋黄酱味！！」[rhp]

[:gonzalez:]
「芥……芥末、啥？」[rhp]

[:heartshape:]
「辣椒明太子腊肠蛋黄酱味！！」[rhp]

[:gonzalez:]
「和刚才说的不一样啊！！」[rhp]

[:princess:]
「听说冈萨雷斯先生喜欢吃辣呢。是哈蒂君告诉我的！[rhr]
_　因为是能自选配料的小摊，我就全加了一遍！」[rhp]

[:heartshape:]
「追加选项合计1000日元！！」[rhp]

[:gonzalez:]
「我是能吃辣……但我不是敢死队啊……！」[rhp]

[:jet:]
「公主那包是啥？[rhr]
_　你那个颜色看起来也不妙吧？完全乌漆嘛黑的」[rhp]

[:princess:]
「这是红豆馅味的哦」[rhp]

[:heartshape:]
「第一次吃爆米花就敢尝试新口味，可不是谁都做得到！[rhr]
_　我明明那么建议你选焦糖味的」[rhp]

[:gonzalez:]
「那你又……」[rhp]

[:heartshape:]
「男人就该沉默地选盐味！！」[rhp]

[:gonzalez:]
「居、就你自己专挑保险的！」[rhp]

[:jet:]
「不愧是哈蒂。我果然没看错人」[rhp]

[:heartshape:]
「那必须的杰特！在吃这方面我可要走稳妥路线！」[rhp]

;****************************************
;スチル終了
[still_end frame="win.png" storage="park_04.jpg" time=1000]
;****************************************

[hati kao=5 ]
「趁休息来决定下一个游乐项目吧！[rhr]
_　时间可是有限的！」[rhp]

[:princess:][puri_w ]
「好啊！想玩遍所有设施呢」[rhp]

[off_all]

[:jet:][jet kao=1 ]
「这次就让冈萨雷斯来决定吧。[rhr]
_　之前勉强你了」[rhp]

[:gonzalez:][gon kao=5 as=on hh=on ]
「……！啊、太好了！那、[rhr]
_　既然公主也在，就优雅地选咖啡杯之类……」[rhp]

[off_all]

[chara_part name="jet" body=base kao=4 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="hati" body=base kao=4 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]


[:hutago:]
[s_playse storage="hati/full/42.ogg" buf=1]
[s_playse storage="jet/full/34.ogg" buf=2]
「咖啡杯……」[rhr]
「咖啡杯……」[rhp]

[off_all]

[chara_part name="gon" body=base kao=11 as=off ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="355" top="0" wait="false" time="150"]
[chara_part name="puri_w" body=base kao=13 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「真是可爱的选择呢！」[rhp]

[:gonzalez:]
「当然啦。[rhr]
_　虽然和大哥比起来不算什么，但我也算挺可爱的……」[rhp]

[off_all]

;--------------------------------------------------------------------------------------------
;▼フルボイスセット▼

;ハートシェイプ
[voconfig sebuf=1 name=hati vostorage="hati/full/{number}.ogg" number=43]
;ジェット
[voconfig sebuf=1 name=jet vostorage="jet/full/{number}.ogg" number=35]

;--------------------------------------------------------------------------------------------

[:heartshape:][hati kao=5 hh=on ]
「太棒了！！」[rhp]

[off_all]

[:gonzalez:][gon kao=6 as=on ]
「诶？」[rhp]

[off_all]

[chara_part name="jet" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="hati" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:heartshape:]
「不错吧杰特！？」[rhp]

[:jet:]
「无可挑剔哈蒂」[rhp]

[off_all]

[:gonzalez:][gon kao=4 as=on ]
「真、真的可以吗？虽然这么说有点那个，这么轻易就……！[rhr]
_　真的不用再坐FUJISAN和火焰海豚了吗！？」[rhp]

[:heartshape:][hati kao=13 ]
「重要的是张弛有度！咖啡杯……！[rhr]
_　毋庸置疑是〝弛〝的部分！」[rhp]
[:heartshape:][hati kao=14 ]
「「然后……某些地方，就是〝张〞！」」[rhp]

[off_all]

[:princess:][puri_w kao=6 as=on ]
[font color=0x4682b4]
（咦……有种不祥的预感……）[rhp]
[resetfont]

[off_all]

[chara_part name="jet" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="gon" body=base kao=8 as=on ss=off hh=on hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="600" top="0" wait="true" time="150"]

[:gonzalez:]
「你们这些家伙……！终于肯听我的话了吗！[rhr]
_　呜呼，这一路可真漫长啊……！」[rhp]

[:jet:][jet kao=14 ss=on ]
「我很擅长精细的手工活呢～。得注意肌肉酸痛……」[rhp]

[:gonzalez:][gon kao=6 as=on ]
「咦？肌肉酸痛？」[rhp]

[:jet:][jet kao=5 ss=on ]
「手臂要开始发威了」[rhp]

[off_all]

[:heartshape:][hati kao=5 hh=on ]
「冈萨雷斯！你的挑战……！我们家杰特来接招！」[rhp]

[off_all]

[:gonzalez:][gon kao=2 as=on ss=on ]
「咦…………」[rhp]

;****************************************
[fbgm]
[set_00 storage="park_01e.jpg"]
;****************************************

[bgm storage="bgm_18.ogg"]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------


[:nusi:][nusi ]
「好嘞、人都到齐了吧。[rhr]
_　时候也不早了，咱们今天就到这儿吧」[rhp]

[:princess:][puri_w kao=13 ]
「今天谢谢你们！托大家的福玩得超开心」[rhp]

[off_nusi]

[gon kao=3 as=on ss=on ]

[:princess:]
「尤其是冈萨雷斯！[rhr]
_　不愧是专业表演者，反应就是精彩！」[rhp]

[:gonzalez:]
「……………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[chara_part name="jet" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="hati" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:heartshape:]
「你这声惨叫绝了冈萨雷斯！[rhr]
_　下次再一起坐FUJISAN啊！」[rhp]

[:jet:]
「咖啡杯也玩到叫不出声了吧」[rhp]

[off_all]

[:gonzalez:][gon kao=11 as=on ss=on ]
「哈哈……嗯……算是吧」[rhp]

[:princess:][puri_w kao=6 as=on ]
「怎么感觉你人设变了？」[rhp]

[:gonzalez:][gon kao=5 as=on ss=on ]
「没变啊……完全没变……」[rhp]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

[off_all]

[jump storage="ev_a_02.ks" target=*return]

[s]

