﻿*start
;--------------------------------------------------------------------------------------------
;▼フルボイスセット▼
;ハートシェイプ
[voconfig sebuf=1 name=hati vostorage="hati/full/{number}.ogg" number=88]
;ジェット
[voconfig sebuf=1 name=jet vostorage="jet/full/{number}.ogg" number=56]
;--------------------------------------------------------------------------------------------

;****************************************
[bgm storage="bgm_04.ogg"]
[free_filter ]
;****************************************

[::]
自夏日祭典那天起，已过去数日。[rhp]

[:princess:][puri_w kao=2 ]
「那么第二问。砰！」[rhp]

[off_all]

[chara_part name="hati" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="otiai" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:]
「放马过来吧！！」[rhp]

[:otiai:]
「……………………」[rhp]

;****************************************
;カットイン
[image layer="2" page="back" storage="ct/a_08_h_1.png" width="1260" left="10" top="40" name="nov"]
[trans layer="2" method="bounceInDown" time=1000]
[wt]
;****************************************

[:princess:][puri_w kao=2 ]
「这是带刺。[l] 
;****************************************
[image layer="2" page="back" storage="ct/a_08_h_1b.png" width="1260" left="10" top="40" name="nov"]
[trans layer="2" method="bounceInDown" time=100]
[wt]
;****************************************

这是无刺带刺。[l] 
;****************************************
[image layer="2" page="back" storage="ct/a_08_h_1c.png" width="1260" left="10" top="40" name="nov"]
[trans layer="2" method="bounceInDown" time=100]
[wt]
;****************************************

[rhr]_　然后这是有刺无刺带刺」[rhp]

[:heartshape:]
「哦！？原来如此！」[rhp]

[:princess:]
「刚才我撒谎了」[rhp]

[:heartshape:]
「什么！？」[rhp]

;****************************************
[se storage="se8_02.ogg"]
[image layer="2" page="back" storage="ct/a_08_h_1d.png" width="1260" left="10" top="40" name="nov"]
[trans layer="2" method="bounceInDown" time=100]
[wt]
;****************************************

[:princess:]
「中间这家伙并不是无刺带刺」[rhp]
[:princess:]
「现在提问：究竟哪个才是真正的无刺带刺，[rhr]
_　那么中间这家伙又是什么来头呢～？」[rhp]

;****************************************
;カットイン終了
[freeimage layer="2" ]
;****************************************

[:heartshape:][hati kao=2 as=on ]
「谁知道啊！这些不全都是普通虫子吗！？」[rhp]
[:heartshape:]
「落合！你小子知道吗？」[rhp]

[:otiai:][otiai kao=12 ]
「左边」[rhp]

[:heartshape:]
「你真能分辨！？」[rhp]

;****************************************
[image layer="2" page="back" storage="ct/a_08_h_1e.png" width="1260" left="10" top="40" name="nov"]
[trans layer="2" method="bounceInDown" time=500]
[wt]
;****************************************

[:otiai:]
「这里并不存在带刺。[rhr]
_　而中间的是无刺有刺无刺带刺」[rhp]

[:heartshape:]
「是我吗？你是说对带刺不熟悉的我才有问题！？」[rhp]

;****************************************
;カットイン終了
[freeimage layer="2" ]
;****************************************

[se storage="se8_01.ogg"]

[off_all]

[chara_part name="hati" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="otiai" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="645" top="0" wait="false" time="150"]
[chara_part name="puri_w" body=base kao=14 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「正确答案！太厉害了落合君！你对带刺很有研究嘛」[rhp]

[:otiai:]
「只是闲着无聊看了博士房间里摆的书」[rhp]

[:princess:]
「其实我也是！昆虫图鉴意外地让人着迷呢」[rhp]

[:otiai:][otiai kao=6 as=on ]
「所以才搞这问答大赛吗……玩倒是可以玩，但别把我扯进来啊」[rhp]

[:princess:]
「抢答游戏两个人玩也不会无聊吧。[rhr]
_　刚好你也很闲的样子，陪我玩啦」[rhp]

[:otiai:]
「真任性啊……」[rhp]

[:heartshape:][hati kao=6 ]
「博士那儿的书呀。普通的图鉴能有这么有趣吗？」[rhp]

[:princess:][puri_w kao=1 ]
「这个意外地好看！下次哈蒂君也借来看看？」[rhp]

[:heartshape:][hati kao=12 ]
「免了！比起安静看书，我更喜欢活动身体」[rhp]

[:otiai:][otiai kao=13 ]
「很有肌肉笨蛋的风格呢」[rhp]

[:heartshape:][hati kao=13 ]
「噢！谢啦！」[rhp]

[:otiai:][otiai kao=2 as=on ]
「就是这点没救啊你……」[rhp]

[off_all]

[::]
面对完全听不懂讽刺的哈蒂君，就连落合君也不禁招架不住。[rhr]
某种意义上他在这条铁道上算是最强了吧……[rhp]
真的，和哈蒂君在一起每天都不会腻。[rhr]
因为无论做什么、说什么，他都会露出开心的样子。[rhp]
光是待在一起就能让周围人也快乐起来的人。[rhr]
所以我对哈蒂君的事――――――[rhp]

[:jet:][jet kao=1 ]
「哟。你们在干嘛呢？」[rhp]

[:princess:][puri_w kao=1 ]
「！杰特君！」[rhp]

[off_all]

[::]
在我们喧闹的包厢座位旁，不知何时出现了杰特君的身影。[rhr]
杰特君瞥了我们一眼后，狠狠瞪向哈蒂君。[rhp]

[chara_part name="jet" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="hati" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:jet:]
「哟哈蒂。之前去哪儿了？我找你好久」[rhp]

[:heartshape:]
「抱歉啦杰特，耽误你时间了。[rhr]
_　一直在这里让昆虫博士出题考我们呢！」[rhp]

[:jet:][jet kao=2 as=on ]
「昆虫博士……？」[rhp]

[:princess:][puri_w kao=14 as=on hh=on ]
「哎呀～说什么博士啦」[rhp]

[:jet:][jet kao=12 ]
「哦对。总之哈蒂君你最好别离我太远――――――」[rhp]

[off_all]

[:heartshape:][hati kao=2 as=on ]
[font size=33]
「对了！！！」[rhp]
[resetfont]

[off_all]

[:jet:][jet kao=2 as=on ]
「！？　怎、怎么了？」[rhp]

[off_all]

[chara_part name="hati" body=base kao=5 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="421" top="0" wait="false" time="150"]
[chara_part name="puri_w" body=base kao=0 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:heartshape:]
「公主！现在你心目中最火热的图鉴是什么！？」[rhp]

[:princess:]
「诶？那个……《世界有趣！昆虫大图鉴》吧」[rhp]

[:heartshape:][hati kao=14 ]
「原来如此！既然都自称有趣了，那绝对会很有趣吧！」[rhp]
[:heartshape:]
「那我要去读这本书所以弃权这次问答大赛！[rhr]
_　替补队员就拜托备受期待的黑马——杰特！」[rhp]

[off_all]

[:jet:][jet kao=2 as=on ]
「哈？」[rhp]

[off_all]

[chara_part name="hati" body=base kao=5 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="otiai" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:heartshape:]
「噢哟落合！你也对昆虫图鉴感兴趣吗！？[rhr]
_　没办法，咱们一起去吧！跟上！」[rhp]

[:heartshape:][hati kao=2 as=on ]
「啥！？等……！突然搞什么啊。这种事根本没商量过―――」[rhp]

[off_all]

[:heartshape:][hati kao=14 as=on ]
「那我们先撤啦！各位慢聊！！」[rhp]

[off_all]

[::]
单方面劈里啪啦说完后，哈蒂君强行拽住落合君的手臂，[rhr]
转眼间就从车厢蹿了出去。[rhp]
面对这般风风火火的退场，我们连插话的空隙都没有，完全懵在原地。[rhp]

[:jet:][jet kao=2 as=on ]
「…………那家伙。又来了」[rhp]

[:princess:][puri_w kao=0 ]
「又来了？」[rhp]

[:jet:][jet kao=6 ]
「不知道为什么哈蒂那家伙最近总想和我分开行动」[rhp]
[:jet:]
「你这家伙有什么头绪吗？」[rhp]

[:princess:][puri_w kao=7 ]
「唔……倒也没什么特别的」[rhp]

[:jet:][jet kao=6 as=on ]
「…………。……我倒是有」[rhp]

[:princess:][puri_w kao=0 ]
「是这样吗？」[rhp]

[off_all]

[::]
当我反问时，杰特君重重叹了口气瞪着我。[rhp]

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
[vostart]
;--------------------------------------------------------------------------------------------

[:jet:][jet kao=2 ]
「……还不是因为你这种态度！」[rhp]

[:princess:][puri_w kao=4 as=on ]
「咦？我、我吗？」[rhp]

[:jet:]
「就因为你暧昧不清的态度，[rhr]
_　那家伙才想方设法要把你和我凑成一对」[rhp]

[:princess:][puri_w kao=2 as=on hh=on ]
「啊……啊啊！？我和杰特君！？」[rhp]

[:jet:]
「他知道分开行动我就会去找人，所以故意待在公主那儿。[rhr]
_　这样自然就能把来找人的我引到你这儿来」[rhp]
[:jet:]
「只要三人行时自己先离开，我肯定就会跟过去。[rhr]
_　所以那家伙才搞这种拐弯抹角的把戏」[rhp]
[:jet:]
「完全搞错方向。这样既浪费我的时间，也浪费哈蒂的时间」[rhp]

[:princess:][puri_w kao=6 as=on ]
「原、原来是这样。我完全没注意到」[rhp]

[:jet:][jet kao=2 ]
「公主。你给我明确表态吧。[rhr]
_　你喜欢的是哈蒂不是我，对吧？」[rhp]

[:princess:][puri_w kao=8 as=on hh=on ]
「…………！！那、那个」[rhp]

[:jet:][jet kao=8 ]
「别害羞啦。我早就注意到了，也没打算跟别人说」[rhp]
[:jet:][jet kao=6 ]
「既然你喜欢哈蒂，肯定会帮我忙的吧？」[rhp]

[:princess:][puri_w kao=0 ]
「帮忙？」[rhp]

[:jet:][jet kao=5 ]
「对啊。……把夏日祭典继续下去呗」[rhp]

[:princess:][puri_w kao=2 as=on ]
「……？」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
[set_time storage="train_08.jpg"]
;****************************************

[::]
―――――――『把夏日祭典继续下去呗』。[rhp]

说完这句话露出无畏笑容的杰特君，和他稍作交谈后。[rhr]
我回到房间，整个人扑在床铺上心烦意乱。[rhp]

[:princess:][puri_w kao=6 as=on ]
[font color=0x4682b4]
（虽然没具体问他要做什么……[rhr]
但他说了『交给我吧』，应该没问题吧）[rhp]
[:princess:]
（…………、等等？感觉好像不太妙？）[rhp]
[resetfont]

[off_all]

[yurasu]
[se storage="door_07.ogg"]

[:heartshape:][hati kao=5 ]
「公主！！」[rhp]

[:princess:][puri_w kao=2 as=on ]
「吓！哈、哈蒂君！？」[rhp]

[off_all]

[::]
连敲门都没有，哈蒂君就直接推开房门进来了。[rhr]
被这突如其来的状况吓得从床铺上弹起来的我。[rhp]
这种没分寸的地方，因为是哈蒂君所以才能被原谅吧……[rhp]

[:princess:][puri_w kao=6 as=on ss=on ]
[font color=0x4682b4]
（但果然还是希望他敲门啊……！要是在换衣服怎么办！）[rhp]
[resetfont]

[:heartshape:][hati kao=14 ]
「怎么啦，待在房间里可不像你的风格！[rhr]
_　咱们更嗨皮地玩起来吧！」[rhp]

[:princess:][puri_w kao=5 as=on ]
「哈蒂君你精力旺盛过头了哎……发生什么了？」[rhp]

[:heartshape:][hati kao=5 ]
「其实是这样的啊！刚才你告诉我的[rhr]
_　『世界有趣！　昆虫图鉴』、博士那里借来我也读过了！」[rhp]

[:princess:][puri_w kao=1 ]
「啊，真的！？　感觉怎么样？」[rhp]

[:heartshape:][hati kao=14 ]
「超有趣！！　简直让人捧腹绝倒、客厅都要爆炸的感觉！」[rhp]

[:princess:][puri_w kao=2 as=on ]
「是这样的有趣法来着么…」[rhp]

[:heartshape:][hati kao=2 ]
「而且听我说！　这个图鉴系列啊，[rhr]
_　居然还出了『鱼类篇』！」[rhp]

[:princess:][puri_w kao=4 as=on ]
「鱼类篇！？」[rhp]

[:heartshape:][hati kao=5 ]
「没错！　刚从鱼类学者达克内布拉博士那里火速借来的！」[rhp]
[:heartshape:][hati kao=11 ]
「『从溪流到深海，收集了世界上各种有趣的鱼儿！[rhr]
_　和鱼儿博士一起出发去世界旅行吧！』」[rhp]
[:heartshape:][hati kao=14 ]
「―――据、据说哦！　机会难得要不一起看？[rhr]
_　咱们一块把客厅炸翻天吧！」[rhp]

[:princess:]
「好啊！　听起来好开心～」[rhp]

[puri_w kao=2 as=on ]
「…………！　啊」[rhp]

[off_all]

[::]
糟、糟糕……！！[rhr]
照这个节奏绝对会全程被哈蒂君带着走。[rhp]
为了探知他的内心，必须想办法把话题引到我这边！[rhp]

[chara_part name="hati" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="421" top="0" wait="false" time="150"]
[chara_part name="puri_w" body=base kao=1 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「那、那个哈蒂君。是关于杰特君的事…」[rhp]

[:heartshape:][hati kao=4 as=on ]
「……！　杰特？　那家伙怎么了？」[rhp]

[:princess:][puri_w kao=1 ]
「就是…最近很少看到你和杰特君在一起呢。[rhr]
_　是有什么原因吗？」[rhp]

[off_all]

[::]
其实从杰特君那里听说了些，所以心里大概有数。[rhp]
但不知为何想亲口从他本人那里确认，[rhr]
反正也没什么特别话题，便决定直接问他。[rhp]
哈蒂君露出有些尴尬的表情移开视线。[rhp]

[:heartshape:][hati kao=6 ]
「…………也没什么大不了的。[rhr]
_只是莫名其妙就是那样的心情罢了」[rhp]
[:heartshape:]
「我在的话杰特会有所顾忌。[rhr]
_偶尔我不在的话，那家伙说不定更能放开手脚吧？」[rhp]

[:princess:][puri_w kao=7 ]
「但我觉得哈蒂君在场时，[rhr]
_杰特君看起来更开心呢」[rhp]

[:heartshape:][hati kao=3 ]
「………………」[rhp]

[off_all]

[::]
啊咧……怎么一副闷闷不乐的样子。[rhr]
本以为他会高兴的，为什么会这样……？[rhp]

[:heartshape:][hati kao=3 ]
「……怎么可能是那样啊」[rhp]
[:heartshape:]
「杰特应该觉得我碍事才对。其实我不在的话，那家伙……」[rhp]

[:princess:][puri_w kao=0 ]
「哈蒂君……？」[rhp]

[off_all]

[:jet:][jet kao=12 ]
「哟哈蒂。在吗？」[rhp]

[off_all]

[:heartshape:][hati kao=2 as=on ]
「哇！？杰、杰特！？」[rhp]

[off_all]

[chara_part name="jet" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="421" top="0" wait="false" time="150"]
[chara_part name="puri_w" body=base kao=4 as=on ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「杰、杰特君！？什么时候来的！」[rhp]

[:jet:][jet kao=6 ]
「门一直开着还说什么趁人不注意。[rhr]
_要人敲门的话，你们才更该遵守基本礼仪吧」[rhp]

[:princess:][puri_w kao=13 as=on ]
「说、说得对。被哈蒂君的气势带着就忘了……」[rhp]

[off_all]

[chara_part name="jet" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="hati" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:jet:]
「……真是。找你很久了啊哈蒂」[rhp]

[:heartshape:]
「杰、杰特……居然能找到我在的地方啊」[rhp]

[:jet:][jet kao=6 ]
「当然知道。毕竟我们是搭档」[rhp]
[:jet:]
「明明总说不要擅自跑到别的地方去。[rhr]
_　至少希望你能告诉我一下目的地吧？」[rhp]

[:heartshape:][hati kao=14 as=on ]
「抱歉抱歉。那个……因、因为突然有急事嘛！」[rhp]

[:jet:][jet kao=6 ]
「急事啊～」[rhp]

[off_all]

[::]
杰特君的视线唰地转向我。[rhr]
不知该摆什么表情，只好暧昧地笑了笑。[rhp]

[:princess:][puri_w kao=2 as=on ]
[font color=0x4682b4]
（哈蒂君说的夏日祭典后续计划，[rhr]
_　不用想也知道是要撮合我和哈蒂君的对吧）[rhp]
[:princess:]
（这次到底打算用什么手法呢。[rhr]
_　必须留心别漏掉任何信号！）[rhp]
[resetfont]

[off_all]

[chara_part name="jet" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="hati" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:jet:]
「所以？刚才好像听到窸窸窣窣的声音，在聊什么？[rhr]
_　两个人在密室里独处，很可疑啊～」[rhp]

[:heartshape:][hati kao=14 ]
「哈哈哈，有什么可疑的！[rhr]
_　刚才在说从博士那儿借的图鉴的事！！」[rhp]

[:jet:][jet kao=2 as=on ]
「………………图鉴？」[rhp]

[:heartshape:]
「博士的藏书里有本超酷的图鉴！[rhr]
_　我和公主都着迷了！」[rhp]

[:jet:][jet kao=6 as=on ss=on ]
「………………」[rhp]

[off_all]

[:princess:][puri_w kao=11 as=on ss=on ]
[font color=0x4682b4]
（视、视线好刺人……）[rhp]
[resetfont]

[off_all]

[::]
他的眼神仿佛在控诉：就不能说点更风情的话题吗。[rhr]
就算这么说，面对这样的哈蒂君我也很为难啊……！[rhp]

[chara_part name="jet" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="hati" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:jet:]
「……诶～？　两个人一起读书关系真好啊。[rhr]
_　说不定你们俩挺般配的不是吗？」[rhp]

[:princess:][puri_w kao=2 as=on ]
[font color=0x4682b4]
（突然强行往这个方向扯话题！）[rhp]
[resetfont]

[:heartshape:][hati kao=14 ]
「哈哈哈！说和我般配就等于说和杰特般配啊」[rhp]

[off_all]

[:heartshape:][hati kao=14 ]
「所以我先走啦！回头见公主。慢慢享受吧，」[rhp]

[off_all]

[yurasu]

[font size=26]
「什"么！？」[rhp]
[resetfont]

[::]
继前些天之后今天又想溜走的哈蒂君，[rhr]
被杰特君揪住后颈制止了。[rhp]
对着被抓包后神情尴尬的他，杰特君露出了灿烂笑容。[rhp]

[chara_part name="jet" body=base kao=14 as=on ss=on hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="hati" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:jet:]
「喂喂开玩笑的吧？我是因为找哈蒂有事才来的啊」[rhp]

[:heartshape:]
「哈？有事？」[rhp]

[:jet:][jet kao=13 ]
「不过要办事的不是我啦」[rhp]

[off_all]

[::]
说着，杰特君微微瞥向身后。[rhr]
我们也跟着望去，结果出现在那里的竟是……[rhp]

[:sausu:][sausu kao=14 ]
「哟！」[rhp]

[:princess:][puri_w kao=4 as=on ]
「咦……南、南！？」[rhp]

[:sausu:][sausu kao=13 ]
「午安公主。哈托谢普也是。近来可好」[rhp]

[:heartshape:][hati kao=2 as=on ]
「为、为什么你会在这里！白天不是应该不能……」[rhp]

[:sausu:][sausu kao=1 ]
「稍微想想办法还是可以的。毕竟约尔大人也不是万能的嘛。[rhr]
_　四六时中盯着我可不现实啊」[rhp]

[:princess:][puri_w kao=0 ]
[font color=0x4682b4]
（……？刚才那句话是什么意思……）[rhp]
[resetfont]

[off_all]

[:jet:][jet kao=11 ]
「好了各位。现在南要宣布重要事项，都仔细听好」[rhp]

[off_all]

[:sausu:][sausu kao=13 as=on ]
「门槛突然抬高了啊…有点紧张了……」[rhp]

[off_all]

[:princess:][puri_w kao=2 as=on ]
[font color=0x4682b4]
（南要宣布重要事项？真稀奇啊）[rhp]
[resetfont]

[off_all]

[chara_part name="sausu" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=4 as=on ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:sausu:]
「咳哼！呃——虽然很突然，现在要宣布重要事项」[rhp]
[:sausu:]
「从今天起让公主作为见习列车长，[rhr]
_　成为哈托谢普的助手！」[rhp]

[:heartshape:]
「啊……？」[rhp]

[:princess:]
「助、助手？我当？」[rhp]

[:sausu:]
「没错。虽然之前是哈蒂&杰特搭档，[rhr]
_　但从今天开始希望哈蒂&公主能合作共事」[rhp]

[:heartshape:]
「等等等等！完全搞不懂啊！[rhr]
_　这到底是什么安排啊！」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time="150"]
[chara_part name="jet" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:sausu:]
「另外，和公主交换职责的杰特将会变成普通乘客」[rhp]

[:jet:][jet kao=13 ]
「就当提前退休吧。认真工作总算有回报了」[rhp]

[:sausu:][sausu kao=13 as=on ]
「嘴上逞强就随你吧……」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:]
「慢着。从刚才开始怎么回事？各种不对劲吧！？[rhr]
_　其他人都知道这事，还都觉得没问题吗！」[rhp]

[:sausu:][sausu kao=5 as=on ]
「诶？……当、当然？」[rhp]

[:heartshape:]
「为什么要用疑问句啊！　首先只有杰特离职的话，其他人会嫉妒吧。[rhr]
_　特别是快斗啦，快斗啦，快斗啦！」[rhp]

[:sausu:][sausu kao=13 as=on ]
「呃～～～～……那个。这是……」[rhp]

[off_all]

[sausu kao=6 as=on ]
[font size=12]
「…………杰特！　我该说什么好？」[rhp]
[resetfont]

[off_all]

[:jet:][jet kao=12 ]
[font size=12]
「为了表彰平日的努力和功绩 希望让杰特休息」[rhp]
[resetfont]

[off_all]

[chara_part name="sausu" body=base kao=13 as=on ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sausu:]
「为了表彰平日的努力和功绩 希望让杰特休息……」[rhp]

[:heartshape:]
「我都看见了！　你和杰特商量过了！」[rhp]

[:sausu:][sausu kao=14 as=on ]
「才、才不是那样啦～～」[rhp]

[off_all]

[:jet:][jet kao=11 ]
「怎么样公主」[rhp]

[:princess:][puri_w kao=0 ]
「嗯？」[rhp]

[:jet:][jet kao=5 ]
「托我的福 气氛变好了吧」[rhp]

[:princess:][puri_w kao=2 as=on ]
「……！」[rhp]
[:princess:]
[font color=0x4682b4]
（难、难道……！　杰特君的策略，就是这个！？[rhr]
_　用这么强硬的方法缩短距离我也很困扰啊！）[rhp]
[:princess:]
（居然连南都能说动……再怎么说也做得太过分了）[rhp]
[resetfont]

[off_all]

[chara_part name="jet" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="hati" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:jet:]
「所以哈蒂。我暂时要和你分头行动。[rhr]
_　不过也无所谓吧。毕竟最近哈蒂你本来就是那种态度」[rhp]
[:jet:]
「反正有公主代替我。你们要齐心合力加油啊」[rhp]

[:heartshape:]
「杰特，你这家伙……！」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="293" top="0" wait="false" time="150"]
[chara_part name="puri_w" body=base kao=0 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:sausu:]
「……那个。虽然由我来说有点奇怪，这到底是怎么回事？[rhr]
_　我只是按杰特的要求转述，完全不了解具体情况」[rhp]

[:princess:][puri_w kao=11 as=on ]
「说来话长……[rhr]
_　杰特君是为了哈蒂君在努力哦」[rhp]

[:sausu:][sausu kao=0 ]
「哼嗯……是么……」[rhp]
[:sausu:][sausu kao=13 ]
「……不过为了你们的话，我倒是可以奉陪」[rhp]

[:princess:][puri_w kao=13 as=on ]
「适可而止就好……」[rhp]

[:sausu:][sausu kao=1 ]
「对了！既然说要当列车长，就送你个礼物吧」[rhp]

[:princess:][puri_w kao=0 ]
「礼物？到底是……」[rhp]

[off_all]
[yurasu]
[se storage="mag_09.ogg"]

[:princess:]
「哇！？」[rhp]

[::]
伴随可爱音效，头顶突然传来异物感。[rhr]
试着触摸那东西后发现……[rhp]

[:princess:][puri_w hat=hat kao=4 hh=on ]
「―――！帽子！？」[rhp]

[chara_part name="jet" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="sausu" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time="150"]

[:sausu:]
「很适合你呢，公主」[rhp]

[:jet:]
「说到列车长当然要配帽子啦。加油吧」[rhp]

[:princess:][puri_w hat=hat kao=1 hh=on ]
「谢、谢谢……！这个还真让人有点开心」[rhp]

[off_all]

[:heartshape:][hati kao=2 as=on ]
「～～～～～……！居、居然擅自推进话题啊啊啊……！」[rhp]

[off_all]

[chara_part name="jet" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="sausu" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time="150"]

[:sausu:]
「哈托谢普似乎不太能接受的样子……」[rhp]

[:jet:][jet kao=7 ]
「反正就现在这样。马上会恢复往常的」[rhp]

[:sausu:]
「那就好……」[rhp]

[off_all]

[chara_part name="jet" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=0 as=on ss=off hh=off hr=on hat=hat ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:jet:]
「总之从明天开始哈蒂就拜托你了」[rhp]
[:jet:]
「要好好相处啊？求你了。真的」[rhp]

[:princess:][puri_w hat=hat kao=6 as=on hh=on ]
「嗯、嗯……」[rhp]

[off_all]

[::]
就这样，我和哈蒂君的新组合正式成立。[rhr]
虽然完全无法想象接下来会变成怎样……[rhp]

[:princess:]
[font color=0x4682b4]
（拜托了请让我平安度过吧……！）[rhp]
[resetfont]

;****************************************
[fbgm]
[set_xx graphic="rule/krke_h.png" storage="train_03.jpg"]
[bgm storage="bgm_21.ogg"]
;****************************************

翌日。[rhp]
杰特君突然提出的离职消息，将由他本人在清晨第一个通知大家。[rhp]

[chara_part name="jet" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="drop" body=base kao=4 as=on ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:drop:]
「杰特先生要对乘客……吗」[rhp]

[:jet:]
「对！从今往后就算偷懒恶作剧也给我睁只眼闭只眼。[rhr]
_　顾客就是上帝啊」[rhp]

[off_all]

[:princess:][puri_w hat=hat kao=2 as=on ]
[font color=0x4682b4]
（杰特君你这混蛋！南明明说过已经向大家解释清楚了。[rhr]
_　那些全都是杰特君事先编造的谎言……什么人啊！）[rhp]
[resetfont]

[off_all]

[chara_part name="riri" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time="150"]
[chara_part name="kite" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time="150"]

[:quadrillion:]
「居然说出这么离谱的事呢……[rhr]
_　南那个家伙究竟在想什么啊」[rhp]

[:kite:]
「就是因为没脑子才会干这种事吧。[rhr]
_　哈啊～只有杰特总能占便宜呢」[rhp]

[off_all]

[:heartshape:][hati kao=3 as=on ]
「………………」[rhp]

[:otiai:][otiai kao=7 ]
「然后？搭档离职了，这边就继续正常工作吗」[rhp]

[:heartshape:][hati kao=2 ]
「哼！反正是南的心血来潮。这种状况很快就会恢复原样的」[rhp]

[:otiai:][otiai kao=12 ]
「但愿如此」[rhp]

[off_all]

[:heartshape:][hati kao=12 as=on ]
「――――――哈！算了，光烦恼也没用。[rhr]
_　既然已成定局，就转换心情前进吧！」[rhp]
[:heartshape:][hati kao=1 ]
「公主！时间可能不长，但一起加油吧！」[rhp]

[:princess:][puri_w hat=hat kao=13 ]
「很有哈蒂君的风格呢。这边才是要请您多多指教！」[rhp]

[off_hati]

[puri_w hat=hat kao=13 hh=on ]
[font color=0x4682b4]
（嘛，虽然对杰特君的作战相当吃惊……[rhr]
_　其实对这种状况，我反而觉得有点开心……）[rhp]
[resetfont]

[off_all]

[::]
因为，至今无所事事的我终于有工作可做了。[rhr]
无论何种缘由，能被赋予角色总是由衷感到高兴。[rhp]
既然我同样是这条铁道的一员，就想为大家派上用场。[rhp]

[:princess:][puri_w hat=hat kao=5 ]
「好嘞，从今往后要加油！快点把工作也记住呢！[rhr]
_　等杰特君回归后，也要让人家继续当乘务员哦！」[rhp]

[:jet:][jet kao=7 ]
「回归的事先放一边，工作很快就能适应吧。毕竟以前也做过」[rhp]

[:princess:][puri_w hat=hat kao=0 ]
「咦？以前也……？」[rhp]

[:jet:][jet kao=2 as=on ]
「……………………。啊」[rhp]

[:princess:][puri_w hat=hat kao=2 as=on ]
「杰、杰特君……！刚才，你说『以前』？[rhr]
_　那是指失去记忆之前的事对吧！？」[rhp]

[off_all]

[chara_part name="jet" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="drop" body=base kao=11 as=on ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:jet:]
「～～～～……多、多洛普。抱歉」[rhp]

[:drop:]
「说出口的话也没办法了……[rhr]
_　得注意别让南发现才行。会被骂的哦」[rhp]

[:jet:]
「那家伙可麻烦了」[rhp]

[off_all]

[:princess:][puri_w hat=hat kao=14 hh=on ]
「这样啊……！我失去记忆前原来是乘务员啊。[rhr]
_　终于想起一件往事了！」[rhp]

[:drop:][drop kao=13 ]
「……是的。那时工作表现非常优秀呢。极其出色」[rhp]

[:princess:][puri_w hat=hat kao=8 as=on ]
「啊……也就是说，自从失忆后，我那份的负担[rhr]
_　让大家一直替我承担着呢。对不起……」[rhp]

[:drop:][drop kao=1 ]
「不，这方面是我巧妙―――」[rhp]

[off_all]

[chara_part name="riri" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="30" top="0" wait="false" time="150"]
[chara_part name="kite" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="383" top="0" wait="false" time="150"]
[chara_part name="otiai" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="760" top="0" wait="true" time=150]

[:quadrillion:]
「多亏布兹可真是够呛呢～！[rhr]
_　之前的份可得好好拿特别津贴才行」[rhp]

[:kite:]
「今后就为我们的份像拉车马一样干活吧」[rhp]

[:otiai:]
「唯独不想变成你们这样的男人啊……」[rhp]

[off_all]

[:jet:][jet kao=6 ]
「好啦好啦！话题到此为止。早就过上班时间了」[rhp]

[:princess:][puri_w hat=hat kao=2 ]
「之前可没这规矩啊」[rhp]

[:jet:][jet kao=13 ]
「顾客就是神明。神明说的话是绝对的」[rhp]

[:princess:][puri_w hat=hat kao=6 as=on ]
「突然摆起架子来了啊」[rhp]

[off_jet]

[hati kao=3 as=on ]
[puri_w hat=hat kao=3  kao=2 ]
「加油吧哈蒂君！[rhr]
_　一定要让杰特君那傲慢的态度好看！」[rhp]

[:heartshape:]
「……………………」[rhp]

[:princess:][puri_w kao=0 hat=hat ]
「哈蒂君？」[rhp]

[:heartshape:][hati kao=1 as=on ]
「！……啊、没。没什么！」[rhp]
[:heartshape:][hati kao=5 ]
「我也看不惯杰特的态度。[rhr]
_　就让他亲眼见识劳动有多崇高吧！」[rhp]

[:princess:][puri_w kao=13 hat=hat ]
「嗯！两个人一起加油！」[rhp]

[off_all]

[chara_part name="jet" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="drop" body=base kao=6 as=on ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:jet:]
「哈哈哈。随你便～」[rhp]

[:drop:]
「真的没问题吗……」[rhp]

;****************************************
[set_xx graphic="rule/krke_h.png" storage="black.jpg"]
;****************************************

…………自那以后。[rhp]

;****************************************
[se storage="se7_19.ogg"]
[bg storage="train_01.jpg" time=300]
;****************************************

――――――！[rhp]

;****************************************
[bg storage="train_05.jpg" method="fadeInRightBig" time=300]
;****************************************

[chara_part name="jet" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="hati" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:heartshape:]
「杰特！突然叫我来干什么！？」[rhp]

[:jet:]
「想吃甜食。要两人以上花费工夫手工制作的限定款」[rhp]

[off_all]

;****************************************
#
[se storage="se7_19.ogg"]
[bg storage="train_01.jpg" time=300]
;****************************************

――――――！[rhp]

;****************************************
[bg storage="train_09.jpg" time=300]
;****************************************

[chara_part name="jet" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="421" top="0" wait="false" time="150"]
[chara_part name="puri_w" body=base kao=13 as=off ss=off hh=off hr=on hat=hat ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「叫我吗？杰特君」[rhp]

[:jet:]
「把东西落在观景车厢了啊。去取的时候顺便[rhr]
_　把两个人推荐的书带过来。图鉴除外」[rhp]

[off_all]

;****************************************
#
[se storage="se7_19.ogg"]
[bg storage="train_01.jpg" time=300]
;****************************************

――――――！[rhp]

;****************************************
[bg storage="train_03.jpg" time=300]
;****************************************

[chara_part name="jet" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="hati" body=base kao=5 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:heartshape:]
「让、让你们久等了……！接下来是什么！」[rhp]

[:jet:]
「今天想吃点辣的。照例拜托你们俩了」[rhp]

[off_all]

;****************************************
#
[se storage="se7_19.ogg"]
[bg storage="train_01.jpg" time=300]
;****************************************

――――――！[rhp]

;****************************************
[bg storage="train_05.jpg" time=300]
;****************************************

[chara_part name="jet" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="421" top="0" wait="false" time="150"]
[chara_part name="puri_w" body=base kao=2 as=on ss=off hh=off hr=on hat=hat ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:jet:]
「不知怎么我也突然想看图鉴了。[rhr]
_　把两个人最推荐的昆虫和鱼分别用排行榜形式展示给我」[rhp]

[:princess:]
「这都第几次了！？没新梗了啊！」[rhp]

[off_all]

;****************************************
#
[se storage="se7_19.ogg"]
[bg storage="train_01.jpg" time=300]
;****************************************

――――――！[rhp]

;****************************************
[bg storage="train_09.jpg" time=300]
;****************************************

[chara_part name="hati" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="421" top="0" wait="false" time="150"]
[chara_part name="puri_w" body=base kao=6 as=on ss=off hh=off hr=on hat=hat ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:2nin:]
「好——的！！！」[rhr]
「好——的！！！」[rhp]

[off_all]

[:jet:][jet kao=6 ]
「哈蒂你制服下摆开线了吧。[rhr]
_　你们两个要好好修补！用魔法和缝纫机都是邪道哦」[rhp]

[off_all]

[chara_part name="hati" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="421" top="0" wait="false" time="150"]
[chara_part name="puri_w" body=base kao=6 as=on ss=off hh=off hr=on hat=hat ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:heartshape:]
「搞什么啊！列车长管得……虽然这次确实有关！[rhr]
_　但谁要做什么裁缝活啊！！」[rhp]

[:princess:]
[font color=0x4682b4]
（杰特君……总是故意制造我们独处的机会，[rhr]
_　总觉得话题会往奇怪的方向发展……）[rhp]
[resetfont]

[off_all]

;****************************************
[set_xx graphic="rule/krke_h.png" storage="train_01.jpg"]
;****************************************

见习列车长生活的第五天。[rhp]
每天都被杰特君旁若无人的态度耍得团团转，[rhr]
明明觉得漫长却又转瞬即逝，想到这样的日子要一直持续下去……[rhp]

[chara_part name="hati" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="false" time="150"]
[chara_part name="puri_w" body=base kao=6 as=on ss=off hh=off hr=on hat=hat ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:2nin:]
「真是够了……」[rhr]
「真是够了……」[rhp]

[off_all]

[:drop:][drop kao=1]
「辛苦了，公主。哈托谢普」[rhp]

[off_all]

[chara_part name="drop" body=base kao=1 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="hati" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="false" time="150"]
[chara_part name="puri_w" body=base kao=8 as=on ss=off hh=off hr=on hat=hat ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「啊……多洛普……累死了……」[rhp]

[:drop:][drop kao=13 as=on ]
「两、两位看起来相当疲惫呢……现在是在休息吗？」[rhp]

[:heartshape:]
「是啊……但不知道杰特什么时候又会乱来……」[rhp]

[:drop:][drop kao=1 ]
「看起来相当辛苦呢……总之，[rhr]
_　公主似乎已经习惯列车员的工作了呢」[rhp]

[:princess:][puri_w hat=hat kao=6 as=on ]
「说是列车员，这根本就是个佣人嘛。[rhr]
_　还说是乘客呢，根本是少爷的要求」[rhp]

[:heartshape:][hati kao=2 ]
「就是啊。杰特那家伙搞什么！」[rhp]

[:princess:]
「不过要说哈蒂君你们之前[rhr]
_　有没有做过像列车员的事，我也无话可说啦……」[rhp]

[:heartshape:][hati kao=6 as=on ]
「喂！？别背叛我啊！」[rhp]

[:drop:][drop kao=13 ]
「其实我平时也就是做做点心扫扫地，差不多啦。[rhr]
_　在这辆电车上，这类工作就算是列车员的职责了」[rhp]

[:heartshape:][hati kao=11 as=on ]
「听着真刺耳……一直以来多谢了，多洛普」[rhp]

[:drop:]
「呵呵呵。我完全不在意哦」[rhp]
[:drop:][drop kao=1 ]
「希望杰特先生能早点回来工作呢。[rhr]
_　虽然取决于他的心情就是了……」[rhp]

[:heartshape:][hati kao=1 ]
「没事的。杰特的话反正很快就会回来的」[rhp]
「在这条铁道上和我一起当列车员，[rhr]
_　那家伙最大的心愿应该就是这个吧」[rhp]

[:princess:][puri_w hat=hat kao=1 ]
[font color=0x4682b4]
（杰特君，原来梦想是当列车员啊……有点意外）[rhp]
[resetfont]

[off_all]

[se storage="se7_19.ogg"]

[::]
这时，今天不知第几次的呼叫铃声响了起来。[rhp]


[chara_part name="hati" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="421" top="0" wait="false" time="150"]
[chara_part name="puri_w" body=base kao=13 as=on ss=off hh=off hr=on hat=hat ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「哎呀呀……在叫我们呢」[rhp]

[:heartshape:]
「真是的……没办法，虽然麻烦还是去一趟吧」[rhp]

[off_all]

[:drop:][drop kao=13 ]
「一路顺风。请加油哦」[rhp]

[off_all]

[::]
在多洛普的目送下，我们前往杰特君和[rhr]
哈蒂君同住的二人房间。希望别出什么事就好……[rhp]

;****************************************
[set_time storage="train_09.jpg"]
;****************************************

[:heartshape:][hati kao=2 as=on ]
「哈？」[rhp]

[:princess:][puri_w hat=hat kao=2 as=on ]
「哈蒂君……刚才你说什么？」[rhp]

[off_all]

[:jet:][jet kao=13 ]
「所以我说，把公主的房间让给我啊」[rhp]
[:jet:]
「我也觉得差不多该有个单人房间了。[rhr]
_　我住你的房间，你就和哈蒂同住吧」[rhp]

[:princess:][puri_w hat=hat kao=2 as=on ]
「不不！这当然不行啊！」[rhp]

[:jet:][jet kao=0 ]
「为什么？」[rhp]

[:princess:][puri_w hat=hat kao=6 as=on hh=on ]
「还问为什么！我、我可是女生啊！？[rhr]
_　和男孩子同住一个房间什么的……！」[rhp]
[:princess:][puri_w hat=hat kao=2 as=on ]
[font color=0x4682b4]
（……！等等。难道这道命令也是杰特君的『作战』环节……！？[rhr]
_　再、再怎么说这也太过分了！）[rhp]
[resetfont]

[off_puri]

[:jet:][jet kao=11 ]
「不是常说吗？顾客是神明。神明的命令必须绝对服从吧！」[rhp]
[:jet:][jet kao=14 ]
「总之我现在去收拾行李，公主也快点打扫房间……」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[fbgm]

[:heartshape:]
「适可而止吧」[rhp]

[se storage="hand_01.ogg"]

;****************************************
[still storage="cg/a_08_h_1.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/a_08_h_1.png"]
;****************************************

[::]
哈蒂君一反常态的平静声音打断了杰特君的话语。[rhp]

[:princess:]
「哈、哈蒂君……？」[rhp]

[::]
静默中，却仿佛蕴藏着沸腾之物的视线，[rhr]
用苦涩的表情瞪着哈蒂君。[rhp]

[bgm storage="bgm_08.ogg"]

[:heartshape:]
「……到底要我说几遍你才满意啊，杰特」[rhp]

[:jet:]
「说什么呢。我可从来没提过同样的要求」[rhp]

[:heartshape:]
「少装蒜……！」[rhp]
[:heartshape:]
「南把公主调回乘务员让我搭档，也是你的主意吧。[rhr]
_　因为你总是想把我和公主凑成一对对吧」[rhp]

[:jet:]
「！」[rhp]

[::]
果然被发现了……[rhp]

[:heartshape:]
「正如你所想，我喜欢公主」[rhp]

[:princess:]
「诶……！」[rhp]

[:heartshape:]
「和她在一起很开心，也很聊得来。她来玩的时候我会特别兴奋，[rhr]
_　看到她笑的时候，胸口和脑袋就会唰地热起来」[rhp]
[:heartshape:]
「博士也说过，这就是恋爱」[rhp]
[:heartshape:]
「可是你避开了公主。[rhr]
_　擅自对我抱有幻想，还想撮合我和公主」[rhp]
[:heartshape:]
「『要说多少次』是我的台词。[rhr]
_　别老在意我的事，为你自己行动看看啊」[rhp]
[:heartshape:]
「就是因为你这副德行，我才不得不插手……！」[rhp]

[::]
面对一触即发的紧张气氛，我只能手足无措地慌乱着。[rhp]
我觉得现在在这里无论说什么 他们都听不进去。[rhr]
毕竟 我和他们之间羁绊的深度是不同的。[rhp]

[:heartshape:]
「……杰特。我并不想吵架。[rhr]
_　我想和你继续保持友好关系。……所以才说这话」[rhp]
[:heartshape:]
「你在这里想做的事到底是什么？」[rhp]

[:jet:]
「……哈……？」[rhp]

[:heartshape:]
「你到底是为了什么才在这里的。不正是为了让自己获得幸福吗。[rhr]
_　可最近却说着为了哈蒂、自己怎样都无所谓之类的话」[rhp]
[:heartshape:]
「少管闲事。别把我当傻瓜」[rhp]
[:heartshape:]
「…………要是这么想的话，现在就给我从这辆电车上下车！」[rhp]

[:jet:]
「――――――！」[rhp]

[::]
下车什么的……[rhr]
没想到关系比谁都要好的哈蒂君会说出这种话。[rhp]
哈蒂君，没事吧。我用余光瞥着他的脸……[rhp]

;****************************************
[still_end frame="win.png" storage="train_09.jpg" time=1000]
;****************************************

[:jet:][jet kao=8 as=on ss=on ]
「对不起哈蒂！」[rhp]

[off_all]

[:princess:][puri_w hat=hat kao=4 as=on ]
「……！　诶……」[rhp]

[off_all]

[::]
原以为他会反驳，没想到他口中却吐出意料之外的道歉话语。[rhp]
他用脚猛踹刚才坐着的沙发，[rhr]
拼命地向哈蒂君跑去。[rhp]

[chara_part name="jet" body=base kao=8 as=on ss=on hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="hati" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:jet:]
「哈蒂！是我不好。对不起！我给你道歉！」[rhp]
[:jet:]
「所以别、别说那种话了。好吗？好吗？」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:heartshape:]
「………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:jet:]
「就像你最关心我一样，我也希望哈蒂能幸福。[rhr]
_　可能因为这样我有些任性了。为此道歉。对不起！」[rhp]
[:jet:]
「对不起。真的对不起。别讨厌我。[rhr]
_　今后也想和哈蒂在一起。让我继续和你一起吧。呐？好吗？」[rhp]

[:heartshape:]
「…………假惺惺的。现在只是因为被我训斥才道歉，[rhr]
_　心里肯定在想『为什么说这种话』对吧」[rhp]
[:heartshape:]
「别小看我。我比谁都更了解杰特的事」[rhp]

[off_all]

[::]
哈蒂君，似乎真的生气了。[rhr]
面对这不像他风格的冰冷话语，杰特君只是不知所措地呆立着。[rhp]

[:jet:][jet kao=3 as=on ss=on ]
「怎么办……怎么办。我本意并非……」[rhp]

[off_all]

[::]
或许是被要求下电车这件事令他深受打击，[rhr]
杰特君抱着脑袋满脸焦躁。[rhp]
……确实他至今的言行有些过度。[rhp]
但我很清楚。[rhr]
那些全都是为了我和哈蒂君着想。[rhp]
既然如此，我应该……[rhp]

[:princess:][puri_w hat=hat kao=0 ]
「……杰特君。谢谢」[rhp]

[:jet:][jet kao=8 as=on ]
「公主……？」[rhp]

[:princess:][puri_w hat=hat kao=13 ]
「之前给我提了很多建议，[rhr]
_　作为帮手也很可靠。但现在没问题了」[rhp]
[:princess:][puri_w hat=hat kao=1 ]
「从今往后，我会自己努力的」[rhp]

[:jet:][jet kao=0 as=on ]
「你这家伙……」[rhp]

[off_all]

[::]
用余光瞥了眼不安地望向我的杰特君，我直视着正面的哈蒂君。[rhr]
虽然带着疑惑，但哈蒂君还是接受了现状，重新在原地站定。[rhp]

[:princess:][puri_w hat=hat kao=0 ]
「…………哈蒂君」[rhp]

[:heartshape:][hati kao=2 ]
「干嘛啊……」[rhp]

[off_all]

;****************************************
;スチル
[still storage="cg/a_08_h_2.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/a_08_h_2.png"]
;****************************************

[:princess:]
「请和我交往！」[rhp]

[:heartshape:]
「………………啥？」[rhp]

[:princess:]
「我喜欢哈蒂君！从很久以前就这么想了！」[rhp]
[:princess:]
「大家都把我和过去的我比较，只有哈蒂君愿意正视现在的我。[rhr]
_　这真的让我很开心，和哈蒂君在一起时是最快乐的」[rhp]

[:heartshape:]
「这、这不可能！」[rhp]
[:heartshape:]
「因为我们一直在一起所以你才搞错了。[rhr]
_　你喜欢的是杰特。怎么可能是―――」[rhp]

[:princess:]
「夏日祭时你说过的吧。『也要给我创造回忆吗』」[rhp]
[:princess:]
「如果真是那样今天就不会发生这种事了。[rhr]
_　杰特君是真的，在支持我喜欢哈蒂君的这份感情」[rhp]
[:princess:]
「不管你怎么强词夺理，我的心意都不会改变。[rhr]
_　不管谁说什么，我喜欢的就是哈蒂君」[rhp]
[:princess:]
「刚才你说喜欢我……我真的好开心！」[rhp]

[:heartshape:]
「――――――！！那、那个是！」[rhp]

[:princess:]
「就算是敷衍也行。不如说现在拒绝我也好。[rhr]
_　我会努力让你喜欢上我的」[rhp]
[:princess:]
「……不过，就让我擅自喜欢着你，也没关系吧……？」[rhp]

[:heartshape:]
「…………、……」[rhp]

;****************************************
;スチル終了
[still_end frame="win.png" storage="train_09.jpg" time=1000]
;****************************************

[:princess:][puri_w hat=hat kao=12 as=on ]
「…………呼！　好！」[rhp]
[:princess:][puri_w hat=hat kao=1 as=on ]
「怎、怎样！？我说出来了哦杰特君。不奇怪吧！？」[rhp]

[:jet:][jet kao=3 as=on ]
「！　啊……还、还算不错啦。嗯……」[rhp]

[off_all]

[::]
杰特君擦拭着眼角，慌忙说道。[rhp]

[:princess:][puri_w hat=hat kao=1 ]
「为之则成。不为则不成。我只要去做也能做到的」[rhp]
[:princess:][puri_w hat=hat kao=13 ]
「……、真的太好了。能好好传达出去！」[rhp]

[off_all]

[:heartshape:][hati kao=0 as=on ]
「………………」[rhp]

[:princess:][puri_w hat=hat kao=13 as=on hh=on ]
「啊、那个哈蒂君。答复真的不用着急。[rhr]
_　至少在我恢复记忆之前还会留在这里的」[rhp]
[:princess:]
[font color=0x4682b4]
（虽、虽然对向我表白的人说这种话不太合适……）[rhp]
[resetfont]

[off_all]

[:heartshape:][hati kao=8 as=on ]
「……、……杰、……杰特……」[rhp]

[off_all]

[::]
方才还在生气的哈蒂君，[rhr]
现在动摇得就像刚才的杰特君一样。[rhp]
他神色极其凝重地望着杰特君。[rhp]

[chara_part name="jet" body=base kao=0 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="hati" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:heartshape:]
「这种时候该怎么办才好。[rhr]
_　因为我竟越过杰特做出这种事……」[rhp]

[:jet:][jet kao=12 ]
「――――――……不是说过了吗。我对公主毫无想法」[rhp]
[:jet:][jet kao=1 ]
「哈蒂按自己心意来就好。没人会责怪你的」[rhp]

[:heartshape:][hati kao=6 as=on ]
「按我的心意……？」[rhp]

[:jet:][jet kao=1 ]
「当然了。被告白的可是哈蒂你啊。[rhr]
_　既然如此能做出决定的就只有哈蒂了」[rhp]
[:jet:][jet kao=13 ]
「我的意见 你一句都不用听」[rhp]

[:heartshape:][hati kao=0 as=on ]
「………………」[rhp]

[off_all]

[::]
面对似乎仍有想法的哈蒂君，[rhr]
杰特君叹了口气 用极其温和的声音继续说道。[rhp]

[chara_part name="jet" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="hati" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:jet:]
「第一次见到哈蒂时 你对我说过吧。[rhr]
_　你要为了自己 去争取幸福」[rhp]
[:jet:]
「只要哈蒂能开心笑着 每天陪我玩 我就很幸福了」[rhp]

[:heartshape:][hati kao=2 as=on ]
「我、我也是！只要杰特幸福就好　我...」[rhp]

[:jet:][jet kao=5 ]
「所以啊。今后我们别再互相顾虑了好吗」[rhp]

[:heartshape:][hati kao=0 as=on ]
「！」[rhp]

[:jet:][jet kao=11 ]
「为了哈蒂怎样 为了杰特怎样 这种想法必须禁止」[rhp]
[:jet:]
「我会为了自己 做想做的事。所以你也该这样」[rhp]
[:jet:][jet kao=14 ]
「把『我无所谓』这种自我牺牲 和成全对方想做的事的幸福。[rhr]
_　这样我们双方 都能获得双倍快乐吧！」[rhp]

[:heartshape:][hati kao=3 as=on hh=on ]
「……杰特……」[rhp]

[:jet:][jet kao=5 ]
「哈蒂。我会照你说的 首先努力去做自己想做的事」[rhp]
[:jet:]
「所以你也该这样。[rhr]
_　你可以按照自己的心意 自由选择想做的事」[rhp]

[:heartshape:]
「…………」[rhp]

[off_all]

[:jet:][jet kao=13 ]
「怎么样公主。我的提案，很天才吧？」[rhp]

[:princess:][puri_w hat=hat kao=13 hh=on ]
「嗯……！我觉得非常好！」[rhp]

[off_all]

[::]
和方才张皇失措的杰特君截然不同，[rhr]
现在的他神情中透着释然，俨然一副下定决心的模样。[rhp]
虽不清楚是什么促成了这种转变，[rhr]
但我认为此刻的杰特君更符合他本来的样子。[rhp]
……还有，哈蒂君也是。[rhp]

[:heartshape:][hati kao=2 as=on ]
「――――――！公主！」[rhp]

[:princess:][puri_w hat=hat kao=2 as=on ]
「啊、在！」[rhp]

[:heartshape:][hati kao=2 as=on ]
「对不起啊……！我可能在奇怪的地方有点胆小。[rhr]
_　这样一点都不像我对吧？」[rhp]

[:princess:][puri_w hat=hat kao=1 ]
「……嗯。是啊。完全不像哈蒂君的风格呢」[rhp]
[:princess:][puri_w hat=hat kao=14 hh=on ]
「我喜欢的哈蒂君虽然迟钝又没分寸，[rhr]
_　但比任何人都敢说出真心话的哈蒂君啊！」[rhp]

[:heartshape:][hati kao=5 hh=on ]
「嘿嘿……这样啊！听到这个我就放心了！」[rhp]

[off_all]

[chara_part name="jet" body=base kao=11 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="hati" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:jet:]
「是男人就干脆点。一直被告白也太逊了」[rhp]

[:heartshape:][hati kao=5 ]
「说得也是……嗯，好！」[rhp]

[off_all]

;****************************************
;スチル
[still storage="cg/a_08_h_3.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/a_08_h_3.png"]
;****************************************

[:heartshape:]
「我！最喜欢公主了！」[rhp]
[:heartshape:]
「这份感情绝不会输给任何人！杰特也不例外！」[rhp]
[:heartshape:]
「所以……！今后请多指教了！」[rhp]

[::]
如此宣言的哈蒂君，耀眼得恍若盛夏晴空。[rhp]
我最喜欢这样的笑容。[rhr]
希望能在你身旁一起欢笑。[rhp]
所以现在，我开心到难以言表。[rhp]

[:heartshape:]
「喂喂，要哭了吗！？　不开心吗？」[rhp]

[:princess:]
「没有不开心……！是高兴的」[rhp]
[:princess:]
「哈蒂君，谢谢你。我也最喜欢你！」[rhp]

[:heartshape:]
「嘿嘿……！……我虽然不像杰特那么聪明，是个笨蛋！[rhr]
_　但笨蛋也有笨蛋的方式，会好好珍惜公主的」[rhp]
[:heartshape:]
「可别把我跟丢了！好好跟紧啊！」[rhp]

[:princess:]
「嗯……！」[rhp]

[::]
要跟上哈蒂君的步伐一定很不容易吧。[rhr]
能做到这种事的，恐怕只有我和杰特君了。[rhp]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
;スチル終了
[still_end frame="win.png" storage="white.jpg" time=1000]
;****************************************

无论去哪我都会跟着你。[rhr]
什么困难都一起面对。[rhp]
所以，今后也请让我陪在你身边……[rhp]

;****************************************
[fbgm]
[set_w storage="train_01.jpg"]
;****************************************

杰特君重返列车长岗位后，已过去三天。[rhp]
因他复职导致人员超额，我又变回了普通乘客。[rhr]
虽然有点寂寞，但能再次看见他俩并肩同行的身影确实令人欣喜。[rhp]

就这样，我们彻底回到了原本的日常生活。[rhr]
唯一不同的是……我的心意已经传达到杰特君那里。[rhp]
除此之外真的和往常毫无二致。[rhr]
要说有多稀松平常呢……[rhp]

[bgm storage="bgm_01.ogg"]

[:princess:][puri_w  kao=5 ]
「那么最终问题！」[rhp]

[off_all]

[chara_part name="hati" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="otiai" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:2nin:]
「噢——！！」[rhr]
「为什么又是我……」[rhp]

;****************************************
;カットイン
[image layer="2" page="back" storage="ct/a_08_h_2.png" width="1260" left="10" top="40" name="nov"]
[trans layer="2" method="bounceInDown" time=1000]
[cg storage="ct/a_08_h_2.png"]
[wt]
;****************************************

[:princess:][puri_w kao=1 ]
「这边的照片是某种海蛞蝓的图像」[rhp]

;****************************************
;カットイン終了
[freeimage layer="2" time="200"]
;****************************************

[yurasu]

[se storage="se8_05.ogg"]

[:heartshape:][hati kao=2 ]
[font size=30]
「是！！」[rhp]
[resetfont]

[off_all]

[:otiai:][otiai kao=6 as=on ]
「太快！？还没展示完图像吧！」[rhp]

[off_all]

[:heartshape:][hati kao=2 ]
「Goniobranchus splendidus！！」[rhp]

[se storage="se8_01.ogg"]

[:princess:][puri_w kao=5 ]
「正确答案！！10胜0败哈蒂君获胜！」[rhp]

[:heartshape:][hati kao=14 ]
「呜哇！！」[rhp]

[off_all]

[:otiai:][otiai kao=2 as=on ]
「诶——……」[rhp]

[off_all]

[chara_part name="hati" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=14 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「《有趣！世界腹足纲图鉴》的质量果然名不虚传。[rhr]
_出题很有价值呢～！」[rhp]

[:heartshape:]
「多亏和公主一起阅读过[rhr]
_大概能猜到会出哪些部分，所以这次很轻松！」[rhp]

[:princess:][puri_w kao=6 ]
「有点不甘心……！下次不会输了！」[rhp]

[:heartshape:][hati kao=14 ]
「随时放马过来！正合我意！」[rhp]
「就算对手是最爱的公主，我也不会手下留情！」[rhp]

[:princess:][puri_w kao=14 hh=on ]
「嘿嘿……！我才是！」[rhp]

[off_all]

[:otiai:][otiai kao=6 as=on ]
「等一下，那到底是什么题目？[rhr]
_哥尼……什么来着，到底是什么？」[rhp]

[off_all]

[:princess:]
「那么下一题！」[rhp]

[:otiai:]
「等等！很在意啊！」[rhp]

;****************************************
[set_time storage="train_04.jpg"]
;****************************************

1小时后……[rhp]

[:otiai:][otiai kao=6 as=on ]
「哈……全程都是这个节奏。受不了……[rhr]
_话说为什么每周都要拉我陪练……」[rhp]

[off_all]

[:jet:][jet kao=0 ]
「啊。落合」[rhp]

[off_all]

[:otiai:][otiai kao=0 as=on ]
「……！　杰特」[rhp]

[off_all]

[chara_part name="jet" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time="150"]
[chara_part name="otiai" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="645" top="0" wait="true" time="150"]

[:jet:]
「今天结束了吗？那个问答大会」[rhp]

[:otiai:]
「算是吧。虽然还是一头雾水……[rhr]
_　题目也越来越难了啊」[rhp]
[:otiai:]
「说到底为什么光邀请我啊？[rhr]
_　我可从没说过对世界的有趣生物感兴趣这种话！」[rhp]

[:jet:][jet kao=13 ]
「因为是小学生吧？感觉会喜欢这类东西」[rhp]

[:otiai:]
「都说了不喜欢……！[rhr]
_　别把我和普通小学生混为一谈」[rhp]
[:otiai:][otiai kao=6 as=on ]
「真是的，要是杰特你这样正经的家伙[rhr]
_　在场的话还能好些……」[rhp]

[:jet:][jet kao=5 as=on ]
「觉得我正经的，也就只有你了吧……」[rhp]

[:otiai:][otiai kao=12 ]
「能冷静交流的意思？就这么回事」[rhp]
[:otiai:][otiai kao=0 ]
「……说起来你怎么最近不和哈托谢普一起了？[rhr]
_　已经不当乘客恢复成乘务员了吗」[rhp]

[:jet:][jet kao=11 ]
「正因如此。上次休假期间[rhr]
_　折腾了他们那么久，算是赔罪」[rhp]

[:otiai:][otiai kao=0 ]
「哼嗯……」[rhp]
[:otiai:]
「…………。没关系吗？就算被抢走」[rhp]

[:jet:][jet kao=0 ]
「什么？」[rhp]

[:otiai:][otiai kao=6 ]
「我以为杰特你也喜欢公主」[rhp]

[:jet:][jet kao=6 ]
「又来了……博士和你都这样。[rhr]
_　我看着就那么像对公主有意思吗？」[rhp]

[:otiai:][otiai kao=0 ]
「哈托谢普喜欢的东西，杰特也喜欢。[rhr]
_　你们是同心同体，两人两脚……怎么说的来着？」[rhp]

[:jet:][jet kao=12 ]
「没错。也就是说，哈蒂的幸福就是我的幸福」[rhp]
[:jet:]
「所以我不会喜欢上公主」[rhp]

[:otiai:]
「哼嗯……」[rhp]

[:jet:]
「说这种话可能会被认为是在逞强，所以先声明。[rhr]
_　我真心对公主没有任何想法」[rhp]

[:otiai:][otiai kao=7 ]
「谁知道呢」[rhp]

[:jet:][jet kao=2 ]
「我早就这么觉得。大家都太喜欢公主了」[rhp]

[:otiai:][otiai kao=4 as=on ]
「……！」[rhp]

[:jet:][jet kao=3 ]
「我反而觉得不爽。那种被追捧的劲儿。[rhr]
_　不过就是个只会傻笑又爱管闲事的臭小鬼」[rhp]
[:jet:]
「在失忆之前，更早之前，[rhr]
_　我一直觉得公主什么的根本……」[rhp]

[:otiai:][otiai kao=2 ]
「…………」[rhp]

[:jet:][jet kao=12 ]
「……难道说，这只是因为我还不够了解公主？」[rhp]

[:otiai:]
「……谁知道。每个人的感受都不同」[rhp]

[:jet:][jet kao=1 ]
「是啊。那我没错」[rhp]
[:jet:][jet kao=11 ]
「好吧这么说吧。没兴趣但也不讨厌。[rhr]
_　既然哈蒂迷上了那肯定是个好人。也值得逗弄」[rhp]

[:otiai:][otiai kao=6 ]
「…………」[rhp]

[:jet:][jet kao=13 ]
「虽然和落合没关系……我前几天被哈蒂[rhr]
『多为自己行动啊』这么说来着」[rhp]
[:jet:]
「很好笑对吧。我明明无论何时 都是最优秀的那个」[rhp]

[:otiai:][otiai kao=12 ]
「好像是呢」[rhp]

[:jet:][jet kao=11 ]
「我压根没打算为那家伙耗费时间。[rhr]
_　所以希望你别对我做些无谓的揣测」[rhp]

[:otiai:]
「……明白了。我什么都不会再说了」[rhp]

[:jet:][jet kao=7 ]
「比起我的事 落合你怎么看？」[rhp]

[:otiai:][otiai kao=0 ]
「我？」[rhp]

[:jet:]
「被哈蒂抢先一步 最后悔的应该是你吧」[rhp]
[:jet:]
「曾听南随口提过。[rhr]
_　说落合你一直爱慕着公主」[rhp]
[:jet:][jet kao=0 ]
「来这里的理由 不也是为了见公主吗？」[rhp]

[:otiai:][otiai kao=3 ]
「～～～～……一个两个都这么多嘴」[rhp]

[:jet:][jet kao=1 ]
「所以？到底怎么想的」[rhp]

[:otiai:]
「…………要是说完全没有不甘心 那是谎话」[rhp]
[:otiai:][otiai kao=12 ]
「所以……我也在考虑该回去了」[rhp]

[:jet:][jet kao=2 ]
「…………这话 是认真的吗？」[rhp]

[:otiai:]
「千真万确。……不过确实挺开心的。谢了」[rhp]
[:otiai:][otiai kao=0 ]
「帮我转告哈蒂。[rhr]
_　……就说我还没认输」[rhp]

[:jet:][jet kao=0 as=on ]
「……！」[rhp]

[off_jet]

[:otiai:][otiai kao=12 ]
「我还要去和其他人打个招呼。先走了」[rhp]

[off_otiai]

[:jet:][jet kao=0 as=on ]
「啊 嗯……」[rhp]

[off_all]

[se storage="leg_01.ogg"]

[::]
……………………。[rhp]

[:jet:]
「…………蠢货」[rhp]

;-----------------------------------------------------------
;-----------------------------------------------------------

[jump storage="ev_a_08.ks" target="*start"]

;-----------------------------------------------------------
;-----------------------------------------------------------

*start2

;-----------------------------------------------------------
;-----------------------------------------------------------


;ハティ前半エンドフラグ
[eval exp="sf.a_h_end = 1"]

[mask time=2000]
[cancelskip]
[fbgm]

[iscript]
delete f.ev_a_02;
delete f.ev_a_03;
delete f.ev_a_04;
delete f.ev_a_05;
delete f.ev_a_06;
delete f.ev_a_07;
[endscript]

;フラグ初期設定
[iscript]
f.love_d = 0
f.love_k = 0
f.love_r = 0
f.love_h = 0
[endscript]

[jump storage="title.ks" target="*start_end"]

[s]