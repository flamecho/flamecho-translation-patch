﻿
*start

[fbgm]
[mask color=0x000000 time=2000]

[cm]

[clearfix]
[start_keyconfig]
[loadjs storage="myscript.js"]

;初期設定---------------------------------------------------------------------

;メッセージウィンドウの設定
[position layer="message0" frame="win.png" left=0 top=520 width=1280 height=200 page=fore visible=true]

; 文字表示領域
[position layer=message0 page=fore margint="65" marginl="420" marginr="60"]

;キャラ名表示領域
[ptext name="chara_name_area" layer="message0" color="0x000000" size=22 align=center bold=true x=420 y=550]

; 立ち絵の設定
[chara_config anim=false ptext="chara_name_area"]

[call storage="character.ks"]
[call storage="voice.ks"]

;--------------------------------------------------------------------------------

;▼フルボイス初期設定▼
;ソラ
[voconfig sebuf=1 name=sora vostorage="sora/full/{number}.ogg" number=30]
;糠星の夜
[voconfig sebuf=1 name=yoru vostorage="yoru/full/{number}.ogg" number=222]

;--------------------------------------------------------------------------------------------

;****************************************

[s_mask color=0x000000 time=2000]
[bg storage="black.jpg" time=100]
[layopt layer=message0 visible=true]
[plugin name="menu_plugin"]
[showmenubutton]
[::]

[s_mask_off time=2000]

[bgm storage="bgm_36.ogg"]
;****************************************

坠落下去。[rhp]
――――――不断坠落。[rhp]
――――――………………不断坠落。[rhp]
向着天空的底部，永无止境。[rhp]

;****************************************
#
[bg storage="sky_11.jpg" time=2000]
;****************************************

[:yoru:]
「明智的判断」[rhp]

[::]
不知从何处，传来那家伙的声音。[rhp]
看不见身影，大概因为这银河就是他本身吧。[rhp]

[:yoru:]
「念在你作出选择的份上，姑且原谅你的愚行」[rhp]
[:yoru:]
「……、天快亮了……」[rhp]

;****************************************
#
[bg storage="white.jpg" rule="004.png" time=1000]
;****************************************

[::]
夜的声音逐渐远去。[rhp]
周遭渐渐泛白。[rhp]
仿佛被吸入般的，不快感受。[rhp]

我即将醒来。[rhp]
在那空无一物的世界里――――――[rhp]

;****************************************

[fbgm]
[s_mask color=0xffffff time=3000]
; 背景表示
[bg storage="hsps_08u.jpg" time=100]
; ウィンドゥの設定
[position layer="message0" frame="win2.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[s_mask_off time=3000]

;****************************************

[:sora:]
「……………」[rhp]

[::]
朝阳刺眼。……这里是病房？[rhp]
……我……[rhp]

;****************************************
[set_kk storage="hsps_02m.jpg"]
;****************************************

[:yoru:]
「人生百味俱全。虽不鼓吹吃苦……」[rhp]
[:yoru:]
「……只希望你能活下去。这是我唯一的执念。[rhr]
_　所以我想终结他们的旅程」[rhp]
[:yoru:]
「……宙。愿意接受吗」[rhp]

;****************************************
[set_ff storage="hsps_08u.jpg"]
;****************************************

[:sora:]
[font color=0x4682b4]
（……对了……)[rhp]
[resetfont]

[::]
确实去过了。拜托夜登上了那辆银河铁道。[rhr]
能躺在病房里休息，多半是夜找了矢部医生帮忙吧。[rhp]

[:sora:]
[font color=0x4682b4]
（………、………脑袋昏昏沉沉……)[rhp]
[resetfont]

[::]
如今冷静下来后，感觉那件事简直愚蠢至极。[rhp]
实在太过草率。[rhr]
几乎一无所获。[rhp]
啊，真是疲惫不堪……[rhp]

;****************************************

[s_mask time=2000]

; メッセージウィンドゥ非表示
[layopt layer=message0 visible=false]
; メニューアイコン非表示
[hidemenubutton]
[bgm storage="bgm_19.ogg"]
[bg storage="title/title_5a.png" time=100]

[s_mask_off time=2000]

[bg storage="title/title_5c.png" time=2000]

[s_wait time=5000]

[bg storage="title/title_5b.png" time=2000]
[s_wait time=500]
[bg storage="title/title_5d.png" time=2000]

[s_wait time=3000]

[s_mask color="0x000000 time=2000]

[bg storage="train_08.jpg" time=100]

; ウィンドゥの設定
[position layer="message0" frame="win.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[layopt layer=message0 visible=true]
; メニューアイコン表示
[showmenubutton]
[plugin name="menu_plugin"]

[s_mask_off time=2000]
;****************************************

落合君离开铁道数日后。[rhp]
虽然他为离去让我寂寞，但也不能一直消沉下去。[rhr]
我们依旧继续着往常的铁道之旅。[rhp]
早已完全适应了铁道上的生活。[rhr]
但若问是否感到无聊，倒也绝非如此。[rhp]
因为……[rhp]

#
[if exp="sf.e_end == 1 "]
;【ドロップ】
[glink clickse="btn_01.ogg" x="290" y="40" width="610" high="72" text="車掌の仕事を手伝い始めたから" target="*go_drop" graphic="glink_c.png" enterimg="glink_d.png"]
;【カイト】
[glink clickse="btn_01.ogg" x="290" y="160" width="610" high="72" text="今日もカイトに呼び出されているから" target="*go_kite" graphic="glink_a.png" enterimg="glink_b.png"]
;【クリリン】
[glink clickse="btn_01.ogg" x="290" y="290" width="610" high="72" text="リリーの説得で忙しいから" target="*go_riri" graphic="glink_a.png" enterimg="glink_b.png"]
;【ハティ＆ジェット：開放】
[glink clickse="btn_01.ogg" x="290" y="400" width="610" high="72" text="クイズ大会に向けて勉強中だから" target="*go_hati" graphic="glink_a.png" enterimg="glink_b.png"]
[s]
[endif] 

;【ドロップ】
[glink clickse="btn_01.ogg" x="290" y="160" width="610" high="72" text="車掌の仕事を手伝い始めたから" target="*go_drop" graphic="glink_c.png" enterimg="glink_d.png"]
;【カイトクリリン】
[glink clickse="btn_01.ogg" x="290" y="290" width="610" high="72" text="問題児の相手をしているから" target="*root_select2" graphic="glink_a.png" enterimg="glink_b.png"]
[s]

;-----------------------------------------------------------
*root_select2

没错……究其原因，当然是问题儿童们每天制造的骚动。[rhp]
作为相对靠谱的我被迫成为善后专员，[rhr]
四处奔走解决麻烦，根本无暇感到无聊。[rhp]

[:princess:][puri_w kao=2 as=on ]
[font color=0x4682b4]
（尤其令人头疼的是……）[rhp]
[resetfont]

[off_puri]

#
;【カイト】
[glink clickse="btn_01.ogg" x="290" y="100" width="610" high="72" text="カイト" target="*go_kite" graphic="glink_a.png" enterimg="glink_b.png"]
;【クリリン】
[glink clickse="btn_01.ogg" x="290" y="220" width="610" high="72" text="クォードリリオン" target="*go_riri" graphic="glink_c.png" enterimg="glink_d.png"]
;【ハティ＆ジェット：未開放】
[glink clickse="btn_01.ogg" x="290" y="340" width="610" high="72" text="ジェット＆ハートシェイプ" target="*root_select4" graphic="glink_a.png" enterimg="glink_b.png"]
[s]

; この時点で双子選んでもキキララへ行く仕様
*root_select4

[:princess:][puri_w kao=3 ]
「哈蒂君他们为什么总是那么精力充沛呢。[rhr]
_　而且还特别喜欢破坏东西……真希望他们能体谅下收拾的人」[rhp]
[:princess:]
「不过被多洛普训斥后倒是会乖乖反省，这点值得表扬呢。[rhr]
_　毕竟有人被提醒了也完全不会心虚嘛……」[rhp]

#
;【カイト】
[glink clickse="btn_01.ogg" x="290" y="160" width="610" high="72" text="まぁ、しょうがないか" target="*go_kite" graphic="glink_c.png" enterimg="glink_d.png"]
;【クリリン】
[glink clickse="btn_01.ogg" x="290" y="290" width="610" high="72" text="今日こそハッキリ言う！" target="*go_riri" graphic="glink_a.png" enterimg="glink_b.png"]
[s]

;------------------------------------------------------

; ルート分岐＆フラグ立て１

*go_drop
[eval exp="f.root_d = 1"]
[jump storage="ev_d_drop.ks" target="*start"]

*go_kite
[eval exp="f.root_k = 1"]
[jump storage="ev_d_kite.ks" target="*start"]

*go_riri
[eval exp="f.root_r = 1"]
[jump storage="ev_d_riri.ks" target="*start"]

*go_hati
[eval exp="f.root_h = 1"]
[jump storage="ev_d_hati.ks" target="*start"]

;------------------------------------------------------
;------------------------------------------------------

;****************************************

*tutti

[:yoru:][yoru kao=6 ]
「……………………」[rhp]

[:princess:][puri_w kao=0 as=on ]
「……夜？」[rhp]

[off_all]

[::]
他正凝视着这边若有所思。[rhr]
究竟在想什么？这种微妙的氛围真让人坐立不安……[rhp]

[:princess:][puri_w kao=1 ]
「啊！难道夜也想搭乘这铁道旅行了？」[rhp]

[:yoru:][p_y_04][yoru kao=2 ]
「别胡说了」[rhp]
[:yoru:][yoru kao=0 ]
「…………你认识宙吧」[rhp]

[:princess:][puri_w kao=0 ]
「是落合君对吧。那确实认识」[rhp]

[:yoru:][yoru kao=0 ]
「他离开这列铁道时说的话，你还记得吗？」[rhp]

[:princess:]
「？　不，没什么特别的」[rhp]

[:yoru:][yoru kao=3 ]
「这样啊……」[rhp]

[:princess:][puri_w kao=1 ]
「啊，不过……好像说过『还会再来』之类的话……」[rhp]

[:yoru:][yoru kao=4 ]
「……！　这么说有胜算……？」[rhp]

[:princess:][puri_w kao=6 as=on ]
「胜算？」[rhp]

[:yoru:][yoru kao=7 ]
「…………没什么。是我的事」[rhp]

[:princess:][puri_w kao=1 ]
「话说夜你认识落合君啊。朋友吗？」[rhp]

[:yoru:][yoru kao=12 ]
「与你无关」[rhp]

[:princess:][puri_w kao=2 as=on ]
「～～～～……讨厌的家伙！」[rhp]

[:yoru:][yoru kao=12 ]
「我知道」[rhp]
[:yoru:][yoru kao=0 ]
「话说回来，你那边进展如何。之后想起什么了吗」[rhp]

[:princess:][puri_w kao=3 ]
「诶……」[rhp]

[:yoru:][p_y_05][yoru kao=8 ]
「…………看这样子，似乎不能抱太大期待。[rhr]
_　明明是你夸下海口，现在倒悠闲得很」[rhp]

[:princess:][puri_w kao=3 as=on ]
「对、对不起……」[rhp]

[:yoru:][yoru kao=2 ]
「我感受不到你主动回忆的魄力。[rhr]
_　结果揭开盖子一看，尽是露营啊祭典啊这些……」[rhp]
[:yoru:]
「要是这种程度就能恢复，我早就带你去任何地方了。[rhr]
_　正因为无计可施，才不得不依赖你自己啊？」[rhp]

[:princess:][puri_w kao=2 ]
「真是的～～……！　没必要这么说吧。[rhr]
_　夜说的也许没错，但因此困扰的只有我吧」[rhp]

[:yoru:]
「若你感到困扰便是问题所在」[rhp]

[:princess:][puri_w kao=0 as=on ]
「……！」[rhp]

[:yoru:]
「那可是重要的东西。就这样一直丢失也没关系吗」[rhp]

[:princess:][puri_w kao=3 as=on ]
「……不行、呢。抱歉……」[rhp]

[:yoru:][yoru kao=12 ]
「你能明白就好」[rhp]

[:princess:][puri_w kao=7 ]
[font color=0x4682b4]
（夜这家伙，总在奇怪的地方格外温柔呢……）[rhp]
[resetfont]

[:yoru:][yoru kao=12 ]
「尽快恢复记忆，赶紧离开这里。[rhr]
_　我重申多次，这里本就不是你们该待的地方」[rhp]

[:princess:][puri_w kao=6 ]
「好啦好啦。知道了」[rhp]

[:yoru:][yoru kao=2 ]
「应答只需一次」[rhp]

[:princess:][puri_w kao=2 as=on ]
「啊真是的！现在别说这个。虽然可能还要花些时间，[rhr]
_　但我会尽量不添麻烦。再稍微等等」[rhp]

[:yoru:][p_y_01][yoru kao=0 ]
「…………嗯」[rhp]
[:yoru:][yoru kao=3 ]
[font color=0x4682b4]
（真是悠闲啊。连宙在谋划什么都不清楚就……）[rhp]
[resetfont]

[:princess:][puri_w kao=0 ]
「夜？怎么绷着脸。啊，好像平时就这样」[rhp]

[:yoru:][yoru kao=2 as=on ]
「你话总多那么一句」[rhp]
[:yoru:][yoru kao=3 ]
「那么我这就告辞。[rhr]
_　待太久会被这里没心没肺的家伙缠上……」[rhp]

[off_all]

[:vulpecula:][p_vl_04]
[font color=0x4682b4]
『喂——博士——！[rhr]
_　这附近是不是飘着可疑味道？超可疑的啊！？』[rhp]
[resetfont]

[:darknebula:][p_hr_17]
[font color=0x4682b4]
『可疑是说情况可疑，不是实际散发臭味啦』[rhp]
[resetfont]

[:yoru:][p_y_25][yoru kao=2 ss=on]
「………………来得太快」[rhp]

[:princess:][puri_w kao=5 ]
「机会难得要不要一起玩会儿？」[rhp]

[:yoru:][yoru kao=2 ]
「是想让我过劳死吗」[rhp]

[:princess:][puri_w kao=6 as=on ]
[font color=0x4682b4]
（那么讨厌吗……）[rhp]
[resetfont]

[:yoru:][p_y_15][yoru kao=7 ]
「……算了。等宙来了，你们再好好相处吧」[rhp]

[:princess:][puri_w kao=4 ]
「诶……那个」[rhp]

[off_all]

[:yoru:]
「那就这样」[rhp]

;魔法
[bg_magic_c]

[::]
在我开口前，夜转眼间用魔法消失了。[rhp]
正好在光芒消失的同时，背后的门被打开了。[rhp]

[:vulpecula:][peku kao=14 ]
「锵——！！　发现夜啦！　全体立正～！」[rhp]

[off_all]

[chara_part name="hakase" body=base kao=1 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=4 as=on ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=1 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:vulpecula:]
「咦奇怪？　只有小姬在？」[rhp]

[:princess:][puri_w kao=1 ]
「夜的话刚才已经回去了哦」[rhp]

[:vulpecula:][p_vl_13][peku kao=8 hh=on ]
「诶～～～～～～～！？」[rhp]

[:darknebula:][p_hr_03][hakase kao=0 ]
「真罕见呢。糠星夜居然会来这里。他来做什么？」[rhp]

[:princess:][puri_w kao=13 ]
「对对，就是这件事！[rhr]
_　其实落合君可能又要来这里了！」[rhp]

[:2nin:]
「落落要来了！？」[rhr]
「落合？」[rhp]

[:princess:][puri_w kao=1 ]
「没错！夜说要我们再和他好好相处。[rhr]
_　这意思就是他还会再来对吧！」[rhp]

[:darknebula:][hakase kao=1 ]
「是啊。上次没能好好道别，真开心呢」[rhp]

[:princess:]
「对吧！还得告诉大家才行！」[rhp]

[:vulpecula:][p_vl_14][peku kao=13 ]
「没错！等落落来了就开欢迎会吧！[rhr]
_　像多洛普的劳动感谢派对那样热闹地办！」[rhp]

[:princess:][puri_w kao=13 ]
「这主意好！好嘞，既然决定就赶紧准备吧！」[rhp]

[:vulpecula:][p_vl_01][peku kao=14 ]
「嗯！」[rhp]

[off_all]

;****************************************
[fbgm]
[set_00 storage="train_03.jpg"]
[bgm storage="bgm_04.ogg"]
;****************************************

[::]
将大家召集到餐车后，我转述了从夜那里听来的关于落合君的事情。[rhp]

; ドロップルートの場合
[jump target="*drop1" cond="f.root_d == 1"]

; カイトルートの場合
[jump target="*kite1" cond="f.root_k == 1"]

; ハティルートの場合
[jump target="*hati1" cond="f.root_h == 1"]

;--------------------------------------------------------------------------------------------------
*drop1
;--------------------------------------------------------------------------------------------------

[:drop:][p_d_06][drop kao=1 ]
「如果落合能回来，我也会打起精神。[rhr]
_　之前还稍微担心过，他是不是待得不太舒服」[rhp]

[:princess:][puri_w kao=13 ]
「呵呵，就连一向完美的多洛普也会这样担心呢」[rhp]

[:drop:][drop kao=5 ]
「呵呵，这是当然。[rhr]
_　正因心怀不安，才会努力追求完美啊」[rhp]

[:princess:][puri_w kao=4 ]
[font color=0x696969]
（连对答都如此完美……！真不愧是——)[rhp]
[resetfont]

[jump target="*tutti2"]

;--------------------------------------------------------------------------------------------------
*kite1
;--------------------------------------------------------------------------------------------------

[:kite:][p_k_17][kite kao=7 ]
「来回折腾真不容易。他回来是要做什么呢」[rhp]

[:princess:][puri_w kao=1 ]
「哎呀这样不也挺好。我很开心哦。[rhr]
_　其实分别的时候，还想更正式地送别他的」[rhp]

[:kite:][kite kao=8 ]
「………………」[rhp]

[off_all]

[::]
快斗听到这句话时，露出了难以形容的厌烦表情。[rhp]
我正想吃惊地询问怎么回事，[rhr]
他却又立刻恢复了往常的面无表情。[rhp]

[:princess:]
[font color=0x696969]
（快斗是不希望落合君回来吗？应该不会吧……)[rhp]
[resetfont]

[jump target="*tutti2"]

;--------------------------------------------------------------------------------------------------
*hati1
;--------------------------------------------------------------------------------------------------

[:heartshape:][hati kao=2 ]
「………………切」[rhp]

[:jet:][p_j_26][jet kao=8 ]
「哈蒂」[rhp]

[:heartshape:][hati kao=13 ]
「……啊、啊啊。抱歉抱歉！我会注意」[rhp]

[off_all]

[:princess:][puri_w kao=6 ]
「…………？」[rhp]

[jump target="*tutti2"]

;--------------------------------------------------------------------------------------------------
*tutti2
;--------------------------------------------------------------------------------------------------

[off_all]

[chara_part name="hakase" body=base kao=1 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=13 as=off ss=off hh=on hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:][p_vl_16]
「嗯呵呵！超级期待！[rhr]
_　小落还会再陪我玩吗？」[rhp]

[:darknebula:][p_hr_31][hakase kao=13 ]
「哈哈哈，佩奇和落合关系真好啊」[rhp]
[:darknebula:]
「女儿交男朋友时大概就是这种心情吧……[rhr]
_　既想知道真相，又唯独不想知道这个……」[rhp]

[:vulpecula:][peku kao=6 as=on ]
「博士您在说什么呀～？」[rhp]

[off_all]

[:drop:][p_d_15][drop kao=13 ]
「好嘞！各位，在落合君到来之前，[rhr]
_　我们把车厢打扫得闪闪发亮吧！先来分配任务，」[rhp]

[:heartshape:][p_h_06][hati kao=5 ]
「加油啊，多洛普！！」[rhp]

[:drop:][drop kao=4 as=on ]
「咦！？那个、大家也一起来」[rhp]

[:jet:][p_j_06][jet kao=13 ]
「不愧是我们前辈……！这背影让人想效仿呢」[rhp]

[off_all]

[chara_part name="riri" body=base kao=13 as=off ss=off hh=on hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="645" top="0" wait="true" time=150]

[:quadrillion:]
「为你加油哦多洛普！」[rhp]

[:kite:][kite kao=13 ]
「哟社长！啊不，车长！」[rhp]

[off_all]

[:drop:][p_d_32][drop kao=2 ]
「果然呢……我就猜到会是这样……[rhr]
_　不过没关系啦。我都习惯了……而且喜欢这工作……」[rhp]

[:princess:][puri_w kao=13 ]
「我、我也会帮忙」[rhp]

[:drop:][p_d_07][drop kao=3 ]
「谢谢您……」[rhp]

[off_all]

;****************************************
[fbgm]
[set_b storage="train_01.jpg" ]
[bgm storage="bgm_07.ogg"]
[free_filter ]
;****************************************

; ドロップルートの場合
[jump target="*drop2" cond="f.root_d == 1"]

; カイトルートの場合
[jump target="*kite2" cond="f.root_k == 1"]

; ハティルートの場合
[jump target="*hati2" cond="f.root_h == 1"]

;-------------------------------------------------------------------------------------------------
*drop2
;-------------------------------------------------------------------------------------------------

[::]
接到落合君即将返回的报告后，我们便解散了。[rhp]
多洛普干劲十足地展现乘务员的看家本领，[rhr]
立刻离场去准备清扫工具了。[rhp]

[:princess:]
[font color=0x696969]
（我挺喜欢他们在这种地方不用魔法的坚持)[rhp]
[resetfont]

[::]
毕竟有些心情是魔法无法灌注的嘛。[rhr]
虽然我本来就不会用魔法啦。[rhp]

[jump target="*tutti3"]

;--------------------------------------------------------------------------------------------------
*kite2
;-------------------------------------------------------------------------------------------------

[::]
接到落合君即将返回的报告后，我们便解散了。[rhp]
虽然在意快斗那个表情，[rhr]
但就我个人而言真的很期待落合君回来。[rhp]

[jump target="*tutti3"]

;-------------------------------------------------------------------------------------------------
*hati2
;-------------------------------------------------------------------------------------------------

[:heartshape:][hati kao=1 ]
「………………」[rhp]

[off_all]

[::]
哈蒂君、为什么要咂舌呢。[rhr]
落合君要回来了、你不太高兴吗。[rhp]

[:princess:]
[font color=0x4682b4]
（说起来最初来的时候、也只有哈蒂君反对说让他回去……）[rhp]
[resetfont]

[::]
……哈蒂君其实知道落合君的什么事吗？[rhp]

; 合流
[jump target="*tutti3"]

;--------------------------------------------------------------------------------------------------
*tutti3
;--------------------------------------------------------------------------------------------------

[:drop:][p_d_36][drop kao=1 ]
「公主、让您久等了」[rhp]

[off_all]

[::]
这么说着的时候多洛普回来了。[rhp]
手里提着水桶啦、扫帚啦、[rhr]
还有什么看不太明白的像是清洁剂的东西。[rhp]

[:princess:][puri_w kao=4 ]
「好厉害！要正式打扫呢」[rhp]

[:drop:][drop kao=13 ]
「当然。今天可是特别的日子」[rhp]

[:princess:][puri_w kao=7 ]
「虽说如此、但也没脏到需要做到这个地步吧」[rhp]

[:drop:][p_d_02][drop kao=5 ]
「就算每天都在打扫、除夕前也要大扫除吧。[rhr]
_　这种是心情的问题啦」[rhp]

[:princess:][puri_w kao=13 ]
「原来如此。多洛普、好像妈妈一样」[rhp]

[:drop:][drop kao=13 ]
「可不敢当」[rhp]

; ドロップルートの場合
[jump storage="ev_d_drop.ks" target="*start2" cond="f.root_d == 1"]

; カイトルートの場合
[jump storage="ev_d_kite.ks" target="*start2" cond="f.root_k == 1"]

; ハティルートの場合
[jump storage="ev_d_hati.ks" target="*start2" cond="f.root_h == 1"]

;--------------------------------------------------------------------------------------------------
*tutti4
;--------------------------------------------------------------------------------------------------

;****************************************
[fbgm]

[s_mask color=0x000000 time=3000]
; 背景表示
[bg storage="black.jpg" time=100]
; 夜フィルター
[filter layer="1" brightness="60"]
; ウィンドゥの設定
[position layer="message0" frame="win2.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[s_mask_off time=3000]

;****************************************

[::]
数小时前――――――[rhp]

;****************************************
[bg storage="sky_07.jpg" time=2000]
;****************************************

[bgm storage="bgm_09.ogg"]

我把醒来的事向矢部老师他们报告后、[rhr]
稍微检查了身体状况、决定就这样直接无事回家了。[rhp]
…………本该是这样。[rhp]
是因为发生了那种事后吧、[rhr]
心情怎么也高涨不起来。[rhp]
我也提不起劲直接回家、在附近走了走、[rhr]
在长椅上反复发呆，回过神来已是夜晚。[rhp]

;****************************************
[bg storage="hsps_02m.jpg" time=1000]
;****************************************

…………然后，我又不知悔改地回到了这里。[rhp]
虽然老师们很惊讶，但当我表示落了东西时他们似乎接受了这个理由，[rhr]
没有多问就让我顺利进入了医院内部。[rhp]

;****************************************
[bg storage="hsps_06n.jpg" time=1000]
;****************************************

穿过入口大厅，漫无目的地在院内随意巡视了一会儿。[rhp]
记得从前这里还有不少人，[rhr]
如今亮着灯的房间屈指可数。[rhp]
听说几年后就要和主楼的儿科合并了。[rhr]
希望延长治疗的父母能多些倒也不是坏事。[rhp]
我也赞成这个方案，那正是矢部老师期望的医疗形态。[rhr]
虽然会感到寂寞，但我的回忆与留在这里的孩子们毫无关联。[rhp]
……这样就好。[rhp]

;****************************************
[bg storage="hsps_02m.jpg" time=1000]
;****************************************

在脑海里反复盘旋这些念头时，终究还是无处可去，[rhr]
很快便无物可看，又折返回到了入口处。[rhp]

;****************************************
[bg storage="hsps_12n.jpg" time=1000]
;****************************************

「糠星夜」。难以置信，这幅画里寄宿着神明。[rhp]
它曾以孩童之姿引领我前往银河世界。[rhr]
而这幅画正是连接现实与异界的入口。[rhp]
我始终向往着这片银河―――[rhp]

;****************************************
[bg storage="hsps_02m.jpg" time=1000]
;****************************************

[:yoru:]
「晚上好」[rhp]

[::]
突然从背后传来声音。[rhr]
声音的主人无需思考。[rhp]

[chara_part name="sora" body=prain kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sora:]
「…………夜」[rhp]

[:yoru:][yoru kao=0 ]
「招呼也不打就离开吗。是羞于自己的无礼而回来的吗」[rhp]

[:sora:][p_so_22]
「不对。……已经回不去了。总觉得，心里乱糟糟的」[rhp]

[:yoru:][yoru kao=2 ]
「那也是理所当然的吧。[rhr]
_　我并不想承认那样的蠢材构造能让人满足[rhp]
[:yoru:]
「就在见到他们的那一瞬间，和我的约定似乎就被抛到九霄云外了呢」[rhp]

[:sora:][sora body=prain kao=2 as=on ]
「真是个句句带刺的家伙……我也没说那样就很好」[rhp]

[:yoru:][p_y_28]
「辩解就免了。……我并没有责怪你的意思。[rhr]
_　即便拥有同样的热情，武和你的立场与他们不同」[rhp]
[:yoru:]
「对你来说，这想必是个残酷的任务吧」[rhp]

[:sora:][sora body=prain kao=3 ]
「……你不生气吗」[rhp]

[:yoru:][yoru kao=6 ]
「当然生气。但我也有需要反省的地方」[rhp]
[:yoru:][yoru kao=3 ]
「……对你来说是个残酷的梦吧。抱歉」[rhp]

[:sora:][sora body=prain kao=3 ]
「……倒也谈不上残酷。很久没这么犯傻反而挺开心的」[rhp]
[:sora:]
「不过确实让我明白了许多事」[rhp]
[:sora:]
「……人终究敌不过流逝的岁月啊」[rhp]

[:yoru:][yoru kao=2 ]
「……宙……」[rhp]

[:sora:]
「喂夜。有件事想拜托你」[rhp]

[:yoru:][yoru kao=0 ]
「……，……姑且听听看吧」[rhp]

[:sora:]
「再带我去一次那个世界吧」[rhp]

[:yoru:][yoru kao=12 ]
「我拒绝」[rhp]

[:sora:][sora body=prain kao=2 as=on ]
「呃！？为什么！？」[rhp]

[:yoru:][yoru kao=2 ]
「带你过去是因为觉得你能在那群孩子下车劝说时[rhr]
_　成为有益的存在」[rhp]
[:yoru:]
「我无意将那个地方作为救赎。[rhr]
_　我根本治不好你的伤――――――」[rhp]

[off_all]

[:sora:][sora body=prain kao=3 ]
「………………那就算了」[rhp]

[off_sora]

[:yoru:][yoru kao=4 ]
「……诶」[rhp]

[off_yoru]

;サクッ
[se storage="se6_07.ogg"]

;****************************************
;リストカッティングなソラ
;[image layer="2" page="back" storage="ct/ev_d_1.png" width="1260" left="10" top="40" name="nov"]
;[trans layer="2" time=500]
;[cg storage="ct/ev_d_1.png"]
;[wt]
;****************************************

[:yoru:]
「呃！？　什……你、那个手腕……！」[rhp]
[:yoru:]
「笨蛋！　你在干什么，住手呃！」[rhp]

;****************************************
;カットイン終了
;[freeimage layer="2" ]
;****************************************

[:sora:]
「唔……！」[rhp]

[::]
宙甩开我的阻拦，这次将染血的手指伸向了绘画。[rhp]

;****************************************
;スチル・真面目・シリアス
[still storage="cg/d_1.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/d_1.png"]
;****************************************

[:yoru:]
「……！？　你要……」[rhp]

[:sora:]
「如果这幅画就是那个世界的本体，[rhr]
_　在这里写下这些文字会怎样……值得试试看吧」[rhp]
[:sora:]
「说不定……我能变成多洛普呢」[rhp]

[:yoru:]
「怎么会这样……居然……」[rhp]

;****************************************
;スチル終了
[still_end frame="win2.png" storage="hsps_02m.jpg" time=1000]
;****************************************

[:yoru:][yoru kao=2 as=on ]
「你的梦想呢！？　星名[player]、伊东一近、落合薰！[rhr]
_　为了代替他们拯救更多孩子，你明明要当医生―――」[rhp]

[off_all]

[:sora:][sora body=prain kao=2 as=on ]
[font size=25]
「我想救的从来只有那几个家伙！」[rhp]
[:sora:]
[font size=22]
「正如你所说，大家都死了。[rhr]
_　我想拯救的人，已经不在这个世界了」[rhp]
[:sora:]
「就算成了医生，也没有任何意义啊！」[rhp]
[resetfont]

[off_all]

[:yoru:][yoru kao=2 as=on ]
「……哼，所以呢。即便如此也不能批准，」[rhp]

[off_all]

[:sora:][sora body=prain kao=3 ]
「我在银河铁道见过那些家伙了。[rhr]
_　我一直认为，自己就是渴望实现那个景象……！」[rhp]
[:sora:]
「坦白说我是个庸人。足球比不过薰，[rhr]
_　斗嘴赢不了和近，学习也不及理央」[rhp]
[:sora:]
「你觉得平凡的我走到今天这一步有多不容易，[rhr]
_　用魔法就能实现一切的你明白吗？」[rhp]
[:sora:]
「我、现在得到回报还不够吗……！？」[rhp]

[off_all]

[:yoru:][yoru kao=3 as=on ]
「……可是……」[rhp]

[off_all]

[chara_part name="sora" body=prain kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sora:]
「再说一次。带我去那个世界……！」[rhp]

[:yoru:][yoru kao=2 as=on ]
「…………切、烦死了！说了不行就是不行！」[rhp]
[:yoru:]
「既然说出这种话，那我也不必再求你。[rhr]
_　反正你不过是利用我，在那个世界里纵情享乐―――」[rhp]

[:sora:]
「肯带路就只割手腕。[rhr]
_　拒绝的话连颈动脉也给你割开！」[rhp]
[:sora:]
「我和八云君一起折了南的鹤！[rhr]
_　银河铁道的车票就在手里。现在死了我也能成为那边的人！」[rhp]

[:yoru:]
「索拉！！别做傻事，」[rhp]

[:sora:]
「喂夜。你向来把活着当作最优解吧」[rhp]
[:sora:]
「那我呢？就这样无视我的要求见死不救吗？」[rhp]
[:sora:]
「你想救的孩子里，难道就不包括我吗！？」[rhp]

[:yoru:]
「那、那是……」[rhp]

[:sora:][sora body=prain kao=2 as=on ]
「先说好我这可不是自杀。是你要杀我的，夜。[rhr]
_　本该能活下来的命，就要被你见死不救了……！」[rhp]

[:yoru:][yoru kao=2 as=on ]
「…………、…………」[rhp]

[off_all]

[::]
…………是我的失误。[rhp]
没能看透他心底扎根的黑暗。[rhr]
没想到他已被逼到这般境地。[rhp]
如果我没出声搭话，本不必再次经历离别。[rhr]
因为我的缘故，这孩子的心已经碎成粉末…………[rhp]
……………………无可奈何。[rhp]


[:yoru:][yoru kao=3 ]
「…………明白了」[rhp]
[:sora:]
「批准。你可以上车」[rhp]

[off_all]

[:sora:][sora body=prain kao=5 as=on ]
「夜……！！　谢、」[rhp]

[off_all]

[chara_part name="sora" body=prain kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:yoru:]
「对你很失望」[rhp]

[:sora:][sora body=prain kao=4 as=on ]
「！」[rhp]

[:yoru:]
「我已无事相求于你，[rhr]
_　更不认为为欲望赌命之人有什么价值」[rhp]
[:sora:]
「就让你如愿去死吧」[rhp]

[:sora:][sora body=prain kao=11 as=on ]
「…………、怎样都好。只要能去那边世界」[rhp]

[:yoru:][yoru kao=3 ]
「…………」[rhp]

[off_all]

[:yoru:]
[font color=0x696969]
（…………哼。这个超级笨蛋)[rhp]
[resetfont]

[chara_part name="sora" body=prain kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sora:]
「谢谢你夜。我现在幸福得无以复加。[rhr]
_　这些伤真的完全不必在……」[rhp]
[:sora:][sora body=prain kao=3 as=on ]
「……好痛！」[rhp]

[:yoru:][yoru kao=2 ]
「……伤口疼么。我去叫武来，你等着」[rhp]

[:sora:][sora body=prain kao=2 ]
「等等。先让我上银河铁道……！」[rhp]

[:yoru:][yoru kao=12 ]
「我的意志不会改变。[rhr]
_　反正都这样了 不如死得漂亮点吧」[rhp]
[:yoru:][yoru kao=2 ]
「伤口处理交给武他们。[rhr]
_　我能做的只有把你的灵魂从那具躯体里拽出来」[rhp]

[:sora:][sora body=prain kao=5 ]
「哈哈……看吧 你果然是个死神吧」[rhp]

[:yoru:][yoru kao=2 ]
「……趁我改变主意前 最好堵住那张顶嘴的嘴」[rhp]

[off_all]

[:yoru:][yoru kao=12 ]
「……累了吧？稍微睡会儿就好　醒来时就到那边的世界了」[rhp]

[off_all]

[:sora:][sora body=prain kao=3 as=on ]
「是吗……真是期待啊……」[rhp]

[off_all]

[:sora:]
「……那就恕我承您吉言……」[rhp]

*tutti5

;****************************************
[fbgm]
#
[s_mask color=0x000000 time=2000]
; 背景表示
[bg storage="train_08.jpg" time=100]
; 全部のフィルターを打ち消す
[free_filter ]
; ウィンドゥの設定
[position layer="message0" frame="win.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[s_mask_off time=2000]
;****************************************

[:yoru:][yoru kao=2 ]
「―――所以？这到底是怎么回事」[rhp]

;-----------------------------------------------------------
;ハティルートのみ
[jump target="*tutti5b" cond="f.root_h == 1"]
;-----------------------------------------------------------

[off_all]

[:sora:][sora kao=4 ]
「……诶？」[rhp]

[bgm storage="bgm_15.ogg"]

[off_all]

[::]
夜充满疑惑的声音 将意识从过去拉回现实。[rhp]
倒不是没在听他说话 但每次和夜交谈时[rhr]
总会想起我初次苏醒时的情形。[rhp]
不行 明明好不容易才舍弃了过去。[rhr]
轻轻拍打双颊重整思绪 转身面向满脸狐疑的夜。[rhp]

*tutti5b

[off_all]

[chara_part name="sora" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sora:][p_so_23]
「在现实世界死后 我醒在银河铁道的车顶。[rhr]
_　结果这家伙被吓得当场晕过去了」[rhp]

[:yoru:]
「别跳过关键情节 反正你肯定说了多余的话吧」[rhp]

[:sora:][sora kao=5 ]
「没什么。不过是从今天起由我接替多洛普的角色罢了」[rhp]

[:yoru:][yoru kao=3 ]
「你所谓『罢了』的『不过』恰恰是最敏感的问题。[rhr]
_　本该按顺序说明的……你总在关键时刻不经思考就……」[rhp]

[:sora:][sora kao=1 ]
「是我不对。但现在的我可兴奋得要命。[rhr]
_　稍微出点差错也在所难免吧」[rhp]

[:yoru:][yoru kao=7 ]
「让人昏迷的事实可算不上『稍微』」[rhp]

[:sora:][sora kao=5 ]
「烦死了……我带你来这里这件事[rhr]
_　我确实心存感激。别扫兴啊」[rhp]
[:sora:]
「我等这一刻等太久了。路途虽漫长至极……[rhr]
_　只要想到都是为了此刻，所有艰辛都能原谅」[rhp]

[:yoru:][yoru kao=6 ]
「……………………」[rhp]

[:sora:][sora kao=0 ]
「怎么？我连感激都不行吗」[rhp]

[:yoru:][yoru kao=8 ]
「……倒也不是这个意思」[rhp]

[:sora:][sora kao=13 ]
「夜你也偶尔来玩啊。[rhr]
_　见不到你会很寂寞」[rhp]

[:yoru:][yoru kao=0 ]
「免了。……另外你可千万别会错意」[rhp]
[:yoru:]
「『促使他们下车』的职责暂且保留。[rhr]
_　但若实现目标，你也要离开这里」[rhp]
[:yoru:]
「正因为是短期才能实现你可悲的愿望。[rhr]
_　给我牢牢记住这件事……明白吗」[rhp]

[:sora:][sora kao=12 ]
「是是……」[rhp]

[:yoru:][yoru kao=2 ]
「好只说一次」[rhp]

[:sora:][sora kao=3 as=on ]
「好―――的。……真是斤斤计较的家伙……」[rhp]

;--------------------------------------------------------------------------------------------------
;--------------------------------------------------------------------------------------------------
;カイトルートのみこのままtuttiへ
[jump target="*tutti6" cond="f.root_k == 1"]
;--------------------------------------------------------------------------------------------------
;--------------------------------------------------------------------------------------------------

[:yoru:][yoru kao=6 ]
「………………」[rhp]

[:sora:][sora kao=8 as=on ]
「啊真是的，到底想怎样啊！这次又有什么不满？」[rhp]

[:yoru:][yoru kao=12 ]
「不……不是那个意思」[rhp]

;--------------------------------------------------------------------------------------------------
;--------------------------------------------------------------------------------------------------
;ハティジャンプ
[jump target="*hati3" cond="f.root_h == 1"]
;--------------------------------------------------------------------------------------------------
;--------------------------------------------------------------------------------------------------

;ドロップ＆オチアイルートはジャンプせずこのまま下に

[:yoru:][yoru kao=0 ]
「…………给你一件武器吧」[rhp]

[:sora:][sora kao=8 ]
「武器……？」[rhp]

[:yoru:][yoru kao=0 ]
「希望你用在关键时刻。[rhr]
_　这事不宜宣扬，使用时务必慎重」[rhp]

[:sora:][sora kao=6 ]
「所以到底是什么啊。别卖关子了」[rhp]

[:yoru:][yoru kao=0 ]
「是恢复公主记忆的钥匙」[rhp]

[:sora:][sora kao=4 ]
「…………！！」[rhp]

[:yoru:][yoru kao=12 ]
「既然这番对话发生在画中世界，自然也会传入我的耳中。[rhr]
_　看来连南也没能限制这个机制」[rhp]
[:yoru:][yoru kao=3 ]
「八成是趁我力量衰弱，就放任不管了吧。[rhr]
_　……被小瞧了啊。真是火大」[rhp]

[:sora:][sora kao=5 ]
「那、那钥匙到底是什么！快告诉我！」[rhp]

[:yoru:][yoru kao=0 ]
「啊。她的记忆是――――――」[rhp]

;****************************************
[set_time_c]
;****************************************

[chara_part name="sora" body=base kao=4 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sora:][p_so_13]
「…………就这？」[rhp]

[:yoru:][yoru kao=12 ]
「嗯。但这很难办。原本就处于失忆状态，[rhr]
_　光靠她自己几乎不可能触发这个条件」[rhp]
[:yoru:]
「所以需要他人介入。[rhr]
_　反过来说，我们能替她做的也就只有这些了」[rhp]

[:sora:][sora kao=6 as=on ]
「道理我懂……可既然知道这个条件，[rhr]
_　你之前为什么什么都不做？」[rhp]

[:yoru:]
「满足这个条件，某种意义上是最简单的。[rhr]
_　但那样南绝对不会悔改过去的所作所为」[rhp]
[:yoru:]
「我所追求的是这个世界的解体与他的反省。要实现这两点，[rhr]
_　必须引导他向最厌恶的第二个条件迈进」[rhp]

[:sora:][sora kao=7 ]
「第二个……」[rhp]

[:yoru:][yoru kao=12 ]
「那是我们无法插嘴，只有她才能掌握的钥匙。[rhr]
_　虽然绕了极远的路，但我希望这把钥匙能被使用」[rhp]
[:yoru:]
「当第二把钥匙打开公主的记忆之门时，[rhr]
_　她的情感必定会彻底碾碎南的信念」[rhp]

[:sora:][p_so_17][sora kao=3 ]
「………………」[rhp]

[:yoru:][p_y_36][yoru kao=0 ]
「有什么疑问吗？」[rhp]

[:sora:][sora kao=6 as=on ]
「那个……可能只有我才会这么说。[rhr]
_　就算那家伙真到了使用第二把钥匙的时刻……」[rhp]
[:sora:]
「……换作是我，反而会感谢南造就这个局面。[rhr]
_　南不仅不会反省，恐怕还会……」[rhp]

[:yoru:][yoru kao=3 ]
「她比任何人目睹过更多人类的死亡」[rhp]
[:yoru:]
「从浩开始，薰、和近……见证了众多挚友的逝去。[rhr]
_　明明知晓终将轮到自己，却始终坚强地承受着」[rhp]
[:yoru:]
「她很强大。厌恶停滞，始终渴望向前迈进」[rhp]
[:yoru:]
「……那样的她，绝不可能容忍南的想法」[rhp]

[:sora:][sora kao=0 ]
「夜……」[rhp]

[:yoru:][p_y_15][yoru kao=12 ]
「这只是我的乐观推测。你所说的结果也确实有可能发生」[rhp]
[:yoru:]
「为此我给了你两个记忆的关键条件。[rhr]
_　若她倾向支持南，你就抛出第一个钥匙」[rhp]
[:yoru:]
「质问她就甘心在此停滞不前吗」[rhp]

[:sora:][p_so_19][sora kao=2 ]
「……我已经死了。要永远困在这个世界了」[rhp]

[:yoru:][p_y_15][yoru kao=12 ]
「…………啊。说起来确实如此」[rhp]
[:yoru:]
「那和她一起下车即可。[rhr]
_　那对我而言是最理想的结局」[rhp]

[:sora:][sora kao=0 ]
「就算你这么说……」[rhp]

;tuttiへ
[jump target="*tutti6" ]

;--------------------------------------------------------------------------------------------------
;--------------------------------------------------------------------------------------------------
;ハティルート
*hati3
;--------------------------------------------------------------------------------------------------
;--------------------------------------------------------------------------------------------------

[:yoru:][p_y_16][yoru kao=0 ]
「…………给你一条情报吧」[rhp]

[:sora:][sora kao=2 ]
「情报……？」[rhp]

[:yoru:][yoru kao=0 ]
「关于红白二人组的事」[rhp]

[:sora:][p_so_01][sora kao=7 ]
「啊……杰特和哈蒂吗」[rhp]

[:yoru:][yoru kao=6 ]
「你知道关于他的任何信息吗」[rhp]

[:sora:][sora kao=0 ]
「不，生前的事全然不知。[rhr]
_　大概是我不能去临终关怀院后入住的病人吧」[rhp]

[:yoru:][yoru kao=1 ]
「没错。[rhr]
_　不仅是你，这趟列车上没人认识他」[rhp]

[:sora:][sora kao=4 ]
「公主也是？」[rhp]

[:yoru:][yoru kao=3 ]
「对。那时她也几乎不出房门了。[rhr]
_　她是在101号室前一位的住户」[rhp]

[:sora:][sora kao=6 ]
「哼……那、那些家伙又算什么东西」[rhp]

[:yoru:][p_y_18][yoru kao=12 ]
「…………。他是――――――」[rhp]

;****************************************
[set_time_c]
;****************************************

[chara_part name="sora" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sora:]
「…………那种事能被允许吗？」[rhp]

[:yoru:][yoru kao=12 ]
「绝无可能被允许」[rhp]
[:yoru:][yoru kao=3 ]
「但，这已然是既成事实。更麻烦的是那两个人……[rhr]
_　杰特和哈托谢普完全理解一切却仍选择在这条铁道上生活」[rhp]
[:yoru:]
「小孩子真是棘手。[rhr]
_　他们深信自己无敌……且是世界的中心」[rhp]

[:sora:][p_so_10][sora kao=6 ]
「……把刚才的情报告诉我，是想让我怎么做？」[rhp]
[:sora:]
「我对他人没兴趣。不管那些人的出身如何，我―――」[rhp]

[:yoru:][p_y_26][yoru kao=12 ]
「那边也说了完全相同的话」[rhp]

[:sora:][sora kao=8 ]
「！」[rhp]

[:yoru:][yoru kao=0 ]
「我觉得你们或许合得来。[rhr]
_　若在此陷入劣势，可作为王牌使用」[rhp]
[:yoru:]
「比起孤军奋战，有同伴更令人安心吧」[rhp]

[:sora:][p_so_18][sora kao=8 as=on ]
「……可疑」[rhp]

[:yoru:][yoru kao=6 ]
「什么？」[rhp]

[:sora:][sora kao=2 ]
「之前明明不愿杀我吧。[rhr]
_　为什么突然对我如此关怀备至」[rhp]

[:yoru:][yoru kao=8 ]
「…………。我的魔力也非无穷无尽」[rhp]
[:yoru:]
「仅为你任性就已消耗大量魔力。即便如此，[rhp]
_　若被公主她们蛊惑而『突然要回去』就麻烦了」[rhp]
[:yoru:]
「既然已经伸出援手，要做就希望你彻底做完。[rhr]
_　别浪费我的魔力」[rhp]
「……等我的力量恢复后，反正要赶走所有人。[rhr]
_　在那之前就随他们喜欢吧」[rhp]

[:sora:][sora kao=1 ]
「…………这样啊。明白了」[rhp]

[off_all]

[:sora:][sora kao=6 as=on ]
[font color=0x4682b4]
（可疑……但毕竟是夜。[rhr]
_　就算逼问他也不会说真话吧）[rhp]
[:sora:]
（……现在起争执也没好处。暂时先服从吧）[rhp]

[off_all]

[:yoru:][yoru kao=3 ]
（……宙……可怜的孩子。还有……那两人也是）[rhp]
[:yoru:]
（希望这个谎言能稍微打破现状……）[rhp]
[resetfont]

;--------------------------------------------------------------------------------------------------
;--------------------------------------------------------------------------------------------------
*tutti6
;--------------------------------------------------------------------------------------------------
;--------------------------------------------------------------------------------------------------

[off_all]

[:princess:][puri_w kao=12 ]
「嗯……」[rhp]

[off_all]

[chara_part name="sora" body=base kao=4 as=on ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sora:][p_so_04]
「……！　[font color=0x#00008b][player3b][resetfont]！」[rhp]

[:yoru:][yoru kao=2 ]
「是公主。那些刺耳的杂音听着烦人，统一处理掉」[rhp]

[:sora:][sora kao=6 as=on ]
「好好。真令人着急……」[rhp]

[:yoru:][yoru kao=0 ]
「这个话题到此为止。不该让她听见」[rhp]
[:yoru:]
「再说一次，别用错地方。[rhr]
_　那把钥匙是用来对付南的王牌」[rhp]

[:sora:][sora kao=5 ]
「我知道」[rhp]

;--------------------------------------------------------------------------------------------------
;--------------------------------------------------------------------------------------------------
;ハティルートは個別ファイルに戻ります
[jump storage="ev_d_hati.ks" target="*start3" cond="f.root_h == 1"]
;--------------------------------------------------------------------------------------------------
;--------------------------------------------------------------------------------------------------

;****************************************
[set_time_c]
;****************************************

[::]
醒来时，我正躺在自己房间的床铺上。[rhp]
呆呆望着熟悉的天花板，意识逐渐清晰。[rhp]
对了……记得我是在车顶上昏倒……[rhp]

[:princess:]
[font color=0x4682b4]
（没办法呀……因为多洛普突然……）[rhp]
[resetfont]

[se storage="hand_01.ogg"]

[:princess:][puri_w kao=4 as=on ]
「――――――！！多洛普！」[rhp]

[:yoru:][p_y_34][yoru kao=7 ]
「这里没有那个人」[rhp]

[off_all]

[::]
一个从旁边传来的声音制止了猛然跳起的我。[rhp]
夜正倚靠在床头的墙上抱着双臂[rhr]
用那副惯常的不显露情绪的表情瞥了我一眼。[rhp]
看来并不是在照顾我……[rhp]

[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="293" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=2 as=on ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:yoru:]
「我让他们都退下了。现在这里只有我和宙」[rhp]

[:princess:]
「……！『宙』……」[rhp]

[off_all]

[:sora:][sora kao=0 ]
「早啊」[rhp]

[::]
方才那个青年正一动不动地注视着我。[rhr]
当我用戒备的眼神瞪过去时，他耸耸肩做了个俏皮的表情。[rhp]

[off_all]

我认识的落合君明明是那个小男孩。[rhr]
若不听完详细解释，这种事怎么都无法接受。[rhp]

[chara_part name="sora" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=2 as=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「……多洛普在哪？你真的是落合君吗？[rhr]
_　穿着多洛普的衣服……你对多洛普做了什么？」[rhp]

[:sora:][p_so_19][sora kao=5 ]
「在所有人倒下前我就解释过了吧。多洛普从这个世界上消失了，[rhr]
_　而我就替代他成为了多洛普」[rhp]

[:princess:][puri_w kao=0 as=on ]
「所以我才说难以置信」[rhp]

[:sora:][p_so_28][sora kao=0 ]
「那不信也无所谓」[rhp]

[:princess:][puri_w kao=4 ]
「啥！？」[rhp]

[:sora:][sora kao=5 ]
「不管你说什么，反正多洛普都不会回来了。[rhr]
_　这个世界的规则就是这样定的」[rhp]

[off_all]

[chara_part name="sora" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sora:]
「对吧？夜」[rhp]

[:yoru:]
「………………」[rhp]

[:sora:][sora kao=6 ]
「居然无视我……算了」[rhp]

[off_all]

[:sora:][sora kao=5 ]
「总之从今以后，多洛普的工作[rhr]
_　就由我接手了 你只要知道这点就行」[rhp]
[:sora:]
「以后多指教了，公主」[rhp]

[:princess:][puri_w kao=3 as=on ]
「指教什么啊！？　开什么玩笑！[rhr]
_　快向多洛普道歉！　赶紧把多洛普还回来——」[rhp]

[off_all]

[:yoru:][yoru kao=6 ]
「下车不就行了」[rhp]

[:princess:][puri_w kao=2 ]
「……哈？」[rhp]

[:yoru:][p_y_16][yoru kao=12 ]
「如果你们选择下车，我倒可以帮你们重现多洛普。[rhr]
_　虽然不会是原来那个多洛普，也不能一起旅行 但存在本身可以复原」[rhp]

[:princess:][puri_w kao=0 ]
「什、什么啊。这种……」[rhp]

[:yoru:][yoru kao=2 ]
「我会让宙负责推动你做出这个决定。[rhr]
_　上次完全交给他处理是我的失误 这次由我亲自指挥」[rhp]
[:yoru:]
「明白了吧宙。这次你也该好好履行自己的职责——」[rhp]

[off_all]

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
[vostart]
;--------------------------------------------------------------------------------------------

[:sora:][sora kao=2 ]
「哈？　凭什么？」[rhp]

[off_all]

[:yoru:][yoru kao=2 ]
「……你说什么？」[rhp]

[off_all]

[::]
…………空气骤然凝固。[rhr]
夜的杀气骤然尖锐。这是前所未见的盛怒。[rhp]
夜烦躁地咂舌 狠狠瞪视着落合君。[rhp]

[chara_part name="sora" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=2 as=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:yoru:]
「竟敢耍我。……一而再再而三」[rhp]

[:sora:]
「上当受骗只能怪你自己吧」[rhp]

[off_all]

[::]
无视怒目而视的夜 落合君转向我们这边。[rhp]
见他大步逼近 我不由吓得后退[rhr]
在床铺上退无可退地缩向墙边。[rhp]

[:sora:][sora kao=6 ]
「……我喜欢你」[rhp]

[:princess:][puri_w kao=0 as=on ]
「……！？」[rhp]

[:sora:]
「我再也不想回到现实世界。就在这里和你过一辈子」[rhp]
[:sora:]
「这就是我渴望的幸福。现在终于实现了」[rhp]

[off_all]

[:yoru:][yoru kao=2 as=on ]
「我不同意！　在这里生活什么的，那根本――――――」[rhp]

[off_all]

[chara_part name="sora" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sora:]
「不该用自己的标准衡量他人的价值观」[rhp]
[:sora:][sora kao=5 ]
「…………这话可是你自己说的吧？」[rhp]

[:yoru:]
「呃……！」[rhp]

[off_all]

[::]
落合……宙先生用寻求认同的眼神看过来。[rhr]
我避开了他的视线。……根本不想苟同。[rhp]
不想听这个蛮横抹杀多洛普的人谈论什么幸福。[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

;------------------------------------------------------------------------------------------
;------------------------------------------------------------------------------------------
; カイトルートの場合
[jump storage="ev_d_kite.ks" target="*start3" cond="f.root_k == 1"]
;------------------------------------------------------------------------------------------
;------------------------------------------------------------------------------------------

[:yoru:]
「………………」[rhp]

[::]
宙……[rhp]
…………真是个，愚蠢的孩子。[rhp]

;****************************************
[bg storage="black.jpg" time=1000]
;****************************************

小孩子总是单纯的。[rhp]
这恐怕是他们这类生物特性中[rhr]
为数不多能让人稍有好感的地方。[rhp]
比如说，那个。[rhr]
就连此刻在这里的宙也不例外――――――[rhp]

;------------------------------------------------------------------------------------------
;------------------------------------------------------------------------------------------
*tutti7
;------------------------------------------------------------------------------------------
;------------------------------------------------------------------------------------------

;****************************************
[fbgm]
[s_mask color=0x000000 time=2000]
; 背景表示
[bg storage="hsps_02m.jpg" time=100]
; 夜フィルター
[filter layer="1" brightness="60"]
; ウィンドゥの設定
[position layer="message0" frame="win2.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[s_mask_off time=2000]

[bgm storage="bgm_14.ogg"]
;****************************************

数小时前―――[rhp]

[:yoru:][yoru kao=12 ]
「――――――小睡一会吧。疼痛也会减轻」[rhp]
[:yoru:]
「醒来时就到那边的世界了」[rhp]

[off_all]

[:sora:]
「这样啊……真期待呢……。……那我就承您吉言……」[rhp]

;****************************************
[set_time_c time=1000]
;****************************************

自从宙陷入『沉睡』，我就把那两人召来这里了。[rhp]

[yurasu]

[:tiaki:][tiaki kao=8 as=on ]
「宙君！！」[rhp]

[off_all]

[::]
绘画旁的墙壁上倚靠着倒下的宙，看到这一幕[rhr]
脸色大变的千秋飞奔而来。[rhp]

[:sora:]
「………………」[rhp]

[chara_part name="take" body=base kao=4 as=on ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:takeru:]
「怎么会！难道死了……」[rhp]

[:yoru:][p_y_26][yoru kao=0 ]
「是假死状态。还没死」[rhp]

[:takeru:][take kao=3 ]
「！　是吗。太好了」[rhp]

[off_all]

[:tiaki:][tiaki kao=3 as=on ]
「马上进行止血！空着的床铺……」[rhp]

[:takeru:][p_tk_09][take kao=2 as=on ]
「二楼有空位，但先搬到诊室吧」[rhp]

[:tiaki:][tiaki kao=2 as=on ]
「好！」[rhp]

[off_all]

[::]
千秋随后匆忙地跑过走廊，去准备病房。[rhp]
武神情紧张地目送她的背影消失于楼梯，[rhr]
片刻后深深叹了口气。[rhp]

[:takeru:][take kao=12 ]
「哈啊。……暂时没事真是太好了」[rhp]

[off_all]

[:yoru:][yoru kao=8 ]
「………………」[rhp]

[off_all]

[chara_part name="take" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:takeru:]
「那个……似乎发生了争执，还……」[rhp]

[:yoru:][yoru kao=2 ]
「一点都不好」[rhp]
[:yoru:]
「宙的鲁莽让人头晕。再加上他固执得可怕」[rhp]
[:yoru:][yoru kao=3 ]
「……居然毫不怀疑地相信了我的话」[rhp]

[:takeru:][take kao=6 ]
「你对他说了什么？」[rhp]

[:yoru:]
「说要让他死」[rhp]

[:takeru:][take kao=2 as=on ]
「开什么玩笑！这种事怎么可能被允许——」[rhp]

[:yoru:][yoru kao=2 ]
「所以我才撒谎。他现在还保持着假死状态」[rhp]

[:takeru:][take kao=2 as=on ]
「………！原、原来如此……也是啊。[rhr]
_　夜不可能做出那种事」[rhp]

[:yoru:][yoru kao=3 ]
「要让宙闭嘴并松懈警惕，当时只能那么说。[rhr]
_　你和千秋如果察觉到异常也要统一口径」[rhp]

[:takeru:][take kao=3 ]
「明白。……幸好你通知我。虽说不是致命伤，[rhr]
_　但失血过多会有问题。可能还会留下疤痕」[rhp]

[:yoru:][p_y_34][yoru kao=12 ]
「提出这么任性的要求真是抱歉了。[rhr]
_　明明你这么忙，还给你增加额外工作」[rhp]

[:takeru:][take kao=6 ]
「别在意。既然是夜班就属于分内之事。[rhr]
_　比起我的麻烦，人命更重要」[rhp]

[:yoru:]
「感激不尽」[rhp]

[:takeru:][take kao=3 ]
「……但……居然做到这种地步也要去那个世界吗。[rhr]
_　明明除了旅行之外都活在铁道里」[rhp]
[:takeru:]
「简直和病房没什么两样。即便如此……」[rhp]

[:yoru:][yoru kao=0 ]
「……武」[rhp]

[:takeru:][take kao=2 as=on ]
「啊抱歉。光顾着我自己说了。怎么了？」[rhp]

[:yoru:][p_y_07][yoru kao=12 ]
「突然说这个，我要暂时离开这里」[rhp]

[:takeru:][take kao=0 as=on ]
「咦？……该不会是……」[rhp]

[:yoru:][yoru kao=2 ]
「我也要前往那边监视宙的动向。[rhr]
_　原则上从车外……视情况也可能介入」[rhp]
[:yoru:]
「在此期间，拜托你照看留在这里的宙的肉体。[rhr]
_　和之前一样，只要让他在合适的病房里睡着就足够了」[rhp]
[:yoru:]
「我会尽快解决，把他带回来」[rhp]

[:takeru:][take kao=2 ]
「…………小心点」[rhp]

[:yoru:][yoru kao=5 ]
「啊。等着好消息吧」[rhp]

;****************************************
[jump storage="ev_d_drop.ks" target="*start3"]
;****************************************

;-----------------------------------------------------------
;-----------------------------------------------------------
; スタッフロール
;-----------------------------------------------------------
;-----------------------------------------------------------

*ending

;****************************************
[s_mask color=0xffffff time=3000]
[fbgm]
[bg storage="white.jpg" time=100]
; メッセージウィンドゥ非表示
[anim name="message_outer" time="500" opacity=" 0"]
; メニューアイコン非表示
[hidemenubutton]
[s_mask_off time=3000]
[jump target="*ending3"]
;****************************************

*ending2

;****************************************
[s_mask color=0x000000 time=3000]
[fbgm]
[bg storage="black.jpg" time=100]
; メッセージウィンドゥ非表示
[anim name="message_outer" time="500" opacity=" 0"]
; メニューアイコン非表示
[hidemenubutton]
[s_mask_off time=3000]
[jump target="*ending3"]
;****************************************
;-----------------------------------------------------------

*ending3

;-----------------------------------------------------------
;ソラエンド
[if exp="f.root_s == 1 "]
[movie storage="ed_s.webm" skip="false" volume="30"]
[bg storage="black.jpg" time=200]
[jump target="*ending4"]
;-----------------------------------------------------------
;ドロップエンド
[elsif exp="f.root_d == 1 "]
[movie storage="ed_d.webm" skip="false" volume="30"]
[bg storage="black.jpg" time=200]
[jump target="*ending4"]
;-----------------------------------------------------------
;カイトエンド
[elsif exp="f.root_k == 1 "]
[movie storage="ed_k.webm" skip="false" volume="30"]
[bg storage="white.jpg" time=200]
[jump target="*ending4"]
;-----------------------------------------------------------
;クリリンエンド
[else]
[bgmovie storage="ed_r.webm" ]
[movie storage="ed_r.webm" skip="false" volume="30"]
[bg storage="white.jpg" time=200]
[jump target="*ending4"]
[endif] 
;-----------------------------------------------------------

*ending4

;ソラエンド
[if exp="f.root_s == 1 "]
[eval exp="sf.d_s_end = 1"]
[jump target="*go_title"]

;ドロップエンド
[elsif exp="f.root_d == 1 "]
[eval exp="sf.d_d_end = 1"]
[jump target="*go_title"]

;カイトエンド
[elsif exp="f.root_k == 1 "]
[eval exp="sf.d_k_end = 1"]
[jump target="*go_title"]

;クリリンエンド
[else]
[eval exp="sf.d_r_end = 1"]
[jump target="*go_title"]

[endif] 

;****************************************

*go_title


;-----------------------------------------------------------
; ハティ以外読了後の初回のみ
;-----------------------------------------------------------

; ev_eを見てる場合にスキップ。
[if exp="sf.e_end == 1"]
[jump target="*go_title2"]

; 他キャラクリア済、初回のみ
[elsif exp="sf.d_d_end == 1 && sf.d_s_end == 1 && sf.d_k_end == 1 && sf.d_r_end == 1"]
[s_mask color=0x000000 time=3000]
[fbgm]
[jump target="*d_epilogue"]

[else]
[jump target="*go_title2"]

[endif]

;****************************************

[s_mask color=0x000000 time=3000]

[fbgm]

*d_epilogue

[anim name="message_outer" time="500" opacity=" 0"]
[bg storage="black.jpg" time=100]
[hidemenubutton]
[s_mask_off time=2000]

[bgm storage="bgm_40.ogg"]

;****************************************

[layopt layer=1 visible=true]

[ptext layer=1 text="next" size=18 x=604 y=300 color=snow name="text"]

[wait time="4000"]
[freelayer layer="1" time="3000"]

[ptext layer=1 text="人の喧騒が好きだ。" size=18 x=568 y=300 color=snow name="text"]

[wait time="3000"]
[freelayer layer="1" time="2000"]

[ptext layer=1 text="潮のさざめきが好きだ。" size=18 x=550 y=300 color=snow name="text"]

[wait time="3000"]
[freelayer layer="1" time="2000"]

[ptext layer=1 text="森の静寂が好きだ。" size=18 x=568 y=300 color=snow name="text"]

[wait time="3000"]
[freelayer layer="1" time="2000"]

[ptext layer=1 text="空の彩りが好きだ。" size=18 x=568 y=300 color=snow name="text"]

[wait time="3000"]
[freelayer layer="1" time="2000"]

[ptext layer=1 text="世界の全てがあまりに眩しい。" size=18 x=550 y=300 color=snow name="text"]

[wait time="3000"]
[freelayer layer="1" time="2000"]

[ptext layer=1 text="『箱庭』の中、焦がれた世界を旅している。" size=18 x=478 y=300 color=snow name="text"]

[wait time="3000"]
[freelayer layer="1" time="2000"]

;****************************************
[bg storage="train_05.jpg" time=1000]
;****************************************
; ウィンドゥ表示
[anim name="message_outer" time="1000" opacity="255"]
; メニューアイコン表示
[showmenubutton]
;****************************************

[:unknown:]
「―――杰特！」[rhp]

[:heartshape:][hati kao=14 ]
「原来你在这里。我找遍了」[rhp]

[off_all]

[:jet:][jet kao=1 ]
「哈蒂。……抱歉抱歉」[rhp]

[off_all]

[:jet:]
「――――――这就去！」[rhp]

;****************************************

[fbgm]
#
[s_mask time=2000]
[layopt layer="message0" visible="false"]
[hidemenubutton]
[bg storage="title/title_6a.png" time=100]
[s_mask_off time=2000]

[bg storage="title/title_6c.png" time=2000]

[s_wait time=5000]

[bg storage="title/title_6b.png" time=2000]
[s_wait time=500]
[bg storage="title/title_6d.png" time=2000]

[s_wait time=3000]

[iscript]
delete f.root_d;
delete f.root_s;
delete f.root_k;
delete f.root_r;
[endscript]

[jump storage="ev_e.ks" target="*start2"  cond="sf.e_end == 1 " ]

;****************************************

;-----------------------------------------------------------
*go_title2
;-----------------------------------------------------------

[fbgm]
[mask time=2000]
[cancelskip]

[iscript]
delete f.root_d;
delete f.root_s;
delete f.root_k;
delete f.root_r;
[endscript]

[jump storage="title.ks" target="*start_end"]

[s]