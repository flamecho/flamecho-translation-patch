﻿
*start

;--------------------------------------------------------------------------------------------
;▼フルボイスセット▼
;ドロップ
[voconfig sebuf=1 name=drop vostorage="drop/full/{number}.ogg" number=59]
;ヌシ
[voconfig sebuf=1 name=nusi vostorage="nusi/full/{number}.ogg" number=72]
;魔太郎子
[voconfig sebuf=1 name=mata vostorage="mata/full/{number}.ogg" number=74]
;ゴンザレス一億世
[voconfig sebuf=1 name=gon vostorage="gon/full/{number}.ogg" number=53]
;ミカちん
[voconfig sebuf=1 name=mika vostorage="mika/full/{number}.ogg" number=94]

;--------------------------------------------------------------------------------------------

[:princess:][puri_w kao=0 ]
「…………多洛普」[rhp]

[off_puri]

[::]
脑海中浮现的是多洛普的脸。[rhp]
多洛普对谁都很温柔，工作也很认真是个非常好的人，[rhr]
正因如此他总是不太在意自己，所以总是让人担心。[rhp]
在前几天的露营里，我恢复了记忆成为列车长，[rhr]
决定要让多洛普拥有休假。[rhp]
但仔细想想，完全不知道那会是什么时候。[rhr]
或许是明天，也可能是遥远的未来。[rhp]
……这样可不行。[rhp]

[:princess:]
[font color=0x4682b4]
（我想和多洛普变得更亲密）[rhp]
[resetfont]

[::]
等关系变得更亲密、能获得他的信任之后，[rhr]
就算我不当列车长他或许也能正常休息了。[rhp]
当然不会放弃恢复记忆成为列车长的目标，[rhr]
但那始终只是最后手段。能休息的话最好是立刻实行。[rhp]

[:princess:][puri_w kao=2 ]
「……好！决定了！我要邀请多洛普参加祭典！」[rhp]

[off_puri]

[::]
为了缩短和他之间的距离。[rhr]
为了让他在真正的意义上享受旅行！[rhp]

;****************************************
[fbgm]
[set_xx graphic="rule/krke_d.png" storage="sky_07.jpg"]
;****************************************

[::]
银河铁道在数小时后抵达了目标星球。[rhp]
我们换上夸德里利昂挑选准备的浴衣，[rhr]
终于踏上了那片土地。[rhp]

;****************************************
[bg storage="fes_01.jpg" time=1000]
[filter_n]
[bgm storage="bgm_26.ogg"]
;****************************************

停车的场所位于稍高的位置，前方是通往宽阔神社的长长石阶。[rhp]

「夏日祭之星」永远沉浸在傍晚时分的氛围中，[rhr]
慵懒的闷热感令人联想到初夏。[rhp]
鲜红的灯笼将微暗的夜色明亮地映照，[rhr]
台阶上方传来太鼓和笛子的乐声，空气中飘荡着独特的甜香。[rhp]

尚未目睹的景象让心跳加速，[rhr]
迫不及待想快点跑上这段台阶。[rhp]

[chara_part name="jet" body=yukata kao=5 as=off ss=off hh=on hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=yukata kao=5 as=off ss=off hh=on hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:][p_h_14]
「这、这就是……！夏日祭典！太厉害了！」[rhp]

[:jet:][p_j_14]
「明明只看见灯笼和台阶就已经兴奋起来了！」[rhp]

[off_all]

[chara_part name="riri" body=yukata kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="kite" body=yukata kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:quadrillion:][p_r_14]
「哎呀哎呀，所以小鬼头就是这样的嘛。[rhr]
_　外面稍微热闹点就高兴成这样」[rhp]

[:kite:][p_k_14]
「说这话的克林不是也新买了相机？干劲十足啊」[rhp]

[:quadrillion:][p_r_27][riri body=yukata kao=14 ]
「讨厌～～～被发现啦！？没错！这是专门针对夜间拍摄的，」[rhp]

[:kite:][kite body=yukata kao=6 ]
「啊，没关系的」[rhp]

[off_all]

[:drop:][p_d_04][drop kao=1 ]
「那么各位，烟花大会预定在18点半左右开始，[rhr]
_　请大家在那之前稍微提早些到广场集合哦」[rhp]

[:vulpecula:][peku body=yukata kao=13 ]
「好呀！看烟花的时候要一起喊『玉屋～～』才开心呢！」[rhp]

[:drop:][drop kao=13 ]
「是啊！那么在此之前就自由活动」[rhp]

[off_all]

[::]
以多洛普的话语为开端，众人各自散开行动。[rhp]

[chara_part name="otiai" body=yukata kao=4 as=on ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=yukata kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:][p_h_24]
「听说夏日祭典上有个连小孩都能打的射击摊啊！！[rhr]
_　走吧落合！！！」[rhp]

[:otiai:][p_ot_19][otiai body=yukata kao=2 as=on ]
「啊？　啊喂、等等……！　别、别擅自！　而且那是打靶游戏，」[rhp]

[:heartshape:][p_j_06][hati body=yukata kao=14 ]
「三人来打淘汰赛吧！　输的人要扫一周厕所！」[rhp]

[off_all]

[:jet:][jet body=yukata kao=5 ]
「那可真不能输啊……[rhr]
_　落合要是弃权的话，不战而胜我也无所谓？」[rhp]

[:otiai:][p_ot_25][otiai body=yukata kao=2 as=on ]
「～～～～我奉陪。比就比啊！」[rhp]

[off_all]

[:princess:][puri_w body=yukata kao=13 ]
[font color=0x4682b4]
（嘿嘿，看来落合君也能玩得开心真是太好了）[rhp]
[resetfont]

[off_all]

[chara_part name="riri" body=yukata kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="kite" body=yukata kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:quadrillion:][p_r_15]
「快斗。和那些巨乳随便聊几句制造下空隙怎样？[rhr]
_　老娘趁这工夫多拍几张劲爆照片」[rhp]

[:kite:][kite body=yukata kao=2 as=on ]
「干嘛用『反正你也想要吧』的口气说话？　我才不要？」[rhp]

[:quadrillion:][riri body=yukata kao=11 ]
「今天所有游玩开销我全包」[rhp]

[:kite:][p_k_30][kite body=yukata kao=6 as=on ]
「呜咕……小、小不忍则乱大谋……」[rhp]

[off_all]

[:heartshape:][hati body=yukata kao=14 ]
「好嘞，干劲十足！　走着弟兄们！　可别跟丢老子……」[rhp]
[:heartshape:][hati body=yukata kao=2 as=on ]
「咦等等！？　杰特人呢！？」[rhp]

[off_all]

[chara_part name="jet" body=yukata kao=5 as=o as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="otiai" body=yukata kao=6 as=o as=on ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:jet:][p_j_21]
「这边哈蒂。那边只有临时厕所」[rhp]

[:otiai:]
「在这种细节上意外真实啊……」[rhp]

[off_all]

[:vulpecula:][p_vl_16][peku body=yukata kao=14 msk=off ]
「快快快！　走快点啦博士！[rhr]
_　再不抓紧店铺就逛不完啦！」[rhp]

[:darknebula:][hakase body=yukata kao=5 ]
「喂喂、乱跑很危险的佩奇」[rhp]

[off_all]

[:darknebula:][p_da_31][hakase body=yukata kao=1 ]
「…………哎」[rhp]

[off_all]

[::]
博士将视线转向这边。[rhr]
啪嗒地对上目光后，他轻快地眨了眨眼。[rhp]
虽然没有发出声音，但从唇形能看出他想传达的是『加油！』。[rhp]

[:princess:][puri_w body=yukata kao=0 as=on hh=on ]
「…………」[rhp]

[off_all]

[::]
虽然不是因为被鼓励才这样——我偷偷瞄向身旁的多洛普。[rhp]

[:drop:][p_d_02][drop kao=1 ]
「？怎么了？」[rhp]

[:princess:][puri_w body=yukata kao=13 as=on hh=on ]
「啊、那个……啊哈哈……」[rhp]

[:drop:][drop kao=0 ]
「……？　奇怪的公主」[rhp]

[off_drop]

[:princess:][puri_w body=yukata kao=2 as=on hh=on ]
[font color=0x4682b4]
（……仔、仔细想想对男孩子说『要不要一起去夏祭？』[rhr]
_　门槛相当高不是吗……）[rhp]
[resetfont]

[off_puri]

[::]
而且多洛普，按理说这种氛围应该能察觉到吧，[rhr]
却完全没发现我为什么在旁边坐立不安。[rhp]
证据就是，他只是满足地目送先走一步的大家，[rhr]
自己完全没有要动的意思。甚至只有他一个人没穿浴衣。[rhp]

[:drop:][drop kao=1 ]
「好了！我去工作―――」[rhp]

[:princess:][puri_w body=yukata kao=2 as=on ]
「稍等一下！！」[rhp]

[:drop:][p_d_04][drop kao=0 ]
「公主，怎么了？[rhr]
_　不快点追上去没关系吗？」[rhp]

[:princess:]
「我、我想和多洛普一起逛！」[rhp]

[:drop:][p_d_13][drop kao=4 as=on ]
「……诶」[rhp]

[off_all]

[::]
不……不知怎么就顺势脱口而出了。[rhr]
其实本想认真邀请的，不过算了。干脆就顺势而上吧！[rhp]

[chara_part name="drop" body=base kao=0 as=on ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=yukata kao=2 as=on ss=off hh=on hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「我、我明明下定决心绝对绝～对要邀请多洛普的！[rhr]
_　如果不能和多洛普一起去，我也绝不会离开铁道的！」[rhp]

[:drop:][p_d_04]
「啊⋯⋯那个⋯⋯」[rhp]

[:princess:]
「怎么样！？」[rhr]
[font color=0x4682b4]
（这么强硬的自己还是第一次吧？这次肯定能成！）[rhp]
[resetfont]

[:drop:][drop kao=13 ]
「⋯⋯抱歉公主。我无能为力」[rhp]

[:princess:][puri_w body=yukata kao=6 as=on ]
「诶！？等⋯⋯我都这么拜托你了！？」[rhp]

[:drop:][p_d_28]
「现在跑过去还赶得上和大家汇合。[rhr]
_　请不要在意我，请尽情享受祭典吧」[rhp]

[:princess:][puri_w body=yukata kao=1 ]
「那、那烟花呢？至少一起看看烟花总可以吧？」[rhp]

[:drop:]
「预定会施放非常大型的烟花。在这里观赏就足够了」[rhp]

[:princess:][puri_w body=yukata kao=3 as=on ]
「怎么这样⋯⋯！」[rhp]

[:drop:][p_d_14][drop kao=1 ]
「那段楼梯又长又陡呢。我送您过去吧」[rhp]

[:princess:][puri_w body=yukata kao=2 as=on ]
「啊？等、等等」[rhp]

[off_puri]

[:drop:]
「瞧！」[rhp]

[off_all]

;****************************************
[fbgm]
;魔法
[bg_magic storage="fes_06.jpg"]
;****************************************

[::]
被光芒包裹的瞬间，眼前铺展开绚烂的光景。[rhp]
这就是夏日祭典吗。[rhr]
五彩缤纷热闹非凡，一派欢腾景象。[rhp]
可是⋯⋯[rhp]

[:princess:]
「⋯⋯⋯⋯笨蛋⋯⋯」[rhp]

[::]
⋯⋯明明想和多洛普一起欣赏这景色的。[rhp]

;****************************************
[set_time storage="fes_02.jpg"]
[bgm storage="bgm_01.ogg"]
;****************************************

[:princess:][puri_w body=yukata kao=3 ]
「哈啊⋯⋯」[rhp]

[off_puri]

[::]
总觉得就算回到铁道也只会重复同样的事，[rhr]
就这样独自蹒跚在挤满夜市摊位的街道上。[rhp]
就算想和其他人汇合，人这么多根本找不到……[rhp]

[:princess:][puri_w body=yukata kao=6 as=on ]
「难以置信……居然落单了……」[rhp]
[:princess:]
「可恶的多洛普。既然如此就得想办法破坏他的工作……」[rhp]

[off_puri]

[::]
就这样决定了。我要在这里买很多土特产，[rhr]
直接带回铁道旁，和多洛普一起度过时光。[rhp]
反正只要在那辆电车旁边就行了吧。[rhr]
他们不过来的话，我自己回去就好！这主意好到让我害怕。[rhp]

[:princess:][puri_w body=yukata kao=7 ]
「既然决定了就找店铺吧。夜市该买什么呢……[rhr]
_  记得佩奇说过要棉花糖和苹果糖来着？」[rhp]

[off_puri]

[::]
环视四周想找找显眼的店铺。[rhp]

[:princess:][puri_w body=yukata kao=2 as=on ]
「等等，这也太夸张了！同样内容的店铺居然有好几家！[rhr]
_  而且看起来完全没有品类差异」[rhp]
[:princess:]
「头疼啊…这样完全不知该选哪家……」[rhp]

[off_puri]

[:unknown:][playse storage="yabu/full/91.ogg" buf=1]
「啊！！！！」[rhp]

[:princess:][puri_w body=yukata kao=0 as=on ]
「呃！？」[rhp]

[off_puri]

[::]
格外响亮而又熟悉的声音传入耳中。[rhr]
虽然十有八九能猜到是谁，姑且还是回头看去。[rhp]

;****************************************
[bg_rule storage="fes_03.jpg" rule="002.png" time=1000]
;****************************************

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
[voconfig sebuf=1 name=yabu vostorage="yabu/full/{number}.ogg" number=92]
[vostart]
;--------------------------------------------------------------------------------------------

[chara_part name="yabu" body=yukata kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="yabu" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="mika" body=yukata kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="mika" layer="1" width="437" height="720" left="645" top="0" wait="false" time=150]
[chara_part name="puri_w" body=yukata kao=1 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「啊—果然是矢部医生。您好」[rhp]

[:yabu:][yabu body=yukata kao=6 ]
「你那是什么反应。应该更惊慌失措才对！[rhr]
_　我们可是持续监视着要驱逐你们的强敌……」[rhp]

[:princess:][puri_w body=yukata kao=1 ]
「米卡亲也下午好」[rhp]

[:mika:][mika body=yukata kao=13 ]
「下午好。呵呵，今天穿浴衣吗？超级适合你呢♡」[rhp]

[:princess:][puri_w body=yukata kao=14 ]
「诶嘿嘿，谢谢！米卡亲你们穿着也很合适。和平时的印象不一样呢」[rhp]

[:yabu:][yabu body=yukata kao=11 ]
「果然名医穿什么都自成风范……[rhr]
_　硬要说的话，就是纯洁度还不太够」[rhp]

[:mika:][mika body=yukata kao=13 ]
「会被酱汁弄脏所以最好别穿啦」[rhp]

[:princess:][puri_w body=yukata kao=1 ]
「这样的装扮很新鲜呢。因为你们俩平时都是冷酷印象」[rhp]
[:princess:]
[font color=0x4682b4]
（虽然是个笨蛋）[rhp]
[resetfont]

[:yabu:][yabu body=yukata kao=5 ]
「哼，这就是反差萌。心动了吗？」[rhp]

[:princess:][puri_w body=yukata kao=1 ]
「不怎么……」[rhp]

[:yabu:][yabu body=yukata kao=2 as=on ]
「不怎么！？」[rhp]

[:mika:][mika body=yukata kao=14 ]
「说到矢部医生呀，刚知道你们下个目的地是夏日祭典时，就非～得[rhr]
_　说要开御好烧店不可。所以才这身打扮啦」[rhp]

[:princess:][puri_w body=yukata kao=0 ]
「嘿。为什么呢」[rhp]

[:yabu:][yabu body=yukata kao=11 ]
「就算一次也好，很想试试用这个锅铲。[rhr]
_　双刀流这样，唰……！唰唰！就这样」[rhp]
[:yabu:][yabu body=yukata kao=5 ]
「怎么样。很帅吧！？」[rhp]

[:princess:][puri_w body=yukata kao=1 ]
「不怎么……」[rhp]

[:yabu:][yabu body=yukata kao=2 as=on ]
「不怎么！？」[rhp]

[:mika:][mika body=yukata kao=14 ]
「不过不过，营业额倒是很不错呢？[rhr]
_　果然是因为米卡亲的成熟魅力吧♡」[rhp]

[:yabu:][yabu body=yukata kao=5 ]
「噗哈哈，还以为你要说什么。[rhr]
_　被这位名医的锅铲技艺吸引而来―――」[rhp]

[off_all]

[:unknown:][s_playse storage="mata/full/72.ogg" buf=1]
「噢―――呵呵呵呵！！」[rhp]

[:yabu:][yabu body=yukata kao=2 as=on ]
「唔！？　这、这个声音是……！」[rhp]

[off_all]

[:unknown:][s_playse storage="mata/full/73.ogg" buf=1]
「开什么玩笑，混账东西……」[rhp]

[yurasu]

[chara_part name="mata" body=yukata kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" left="208" top="-400" wait="false" time=150]

[:mataroko:]
[font size=30]
「就是说啊！！！！！」[rhp]
[resetfont]

[off_all]

[:princess:][puri_w body=yukata kao=13 ]
「果然是玛塔！好久不见！」[rhp]

[chara_part name="mata" body=yukata kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="421" top="0" wait="true" time=150]

[:mataroko:]
「日安呀姐姐大人！[rhr]
_　小女子是『章鱼烧小刚』的看板娘魔太郎子」[rhp]

[off_mata]

[chara_part name="mata" body=yukata kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="gon" body=yukata kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:mataroko:]
「这位是主厨小刚」[rhp]

[:gonzalez:]
「过分了吧公主！虽说我们在对面开店，[rhr]
_　但你完全不来搭话是怎么回事」[rhp]

[:princess:][puri_w body=yukata kao=13 as=on］
「哎呀，总觉得不该主动提起……[rhr]
_　那两人先不说，主要是那边那位」[rhp]

[off_all]

[::]
说着，玛塔望向章鱼烧店隔壁。[rhr]
只见努西小姐正读着报纸看管棉花糖店。[rhp]

[:nusi:][nusi body=yukata kao=6 ]
「啧！所以说我讨厌赛马。[rhr]
_　连胡萝卜喜好都和我撞了真不爽啊～」[rhp]

[:mika:][mika body=yukata kao=6 ]
「小努西～。在小孩子面前看赛马报不太好吧？」[rhp]

[:nusi:][nusi body=yukata kao=2 ]
「没关系！比起棉花糖我有更重要的东西」[rhp]

[off_all]

[chara_part name="mata" body=yukata kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="gon" body=yukata kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="600" top="0" wait="false" time=150]
[chara_part name="puri_w" body=yukata kao=0 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「没想到小努西和店面分开了呢。吵架了吗？」[rhp]

[:gonzalez:][gon body=yukata kao=7 ]
「其实这是多洛普的主意」[rhp]

[:princess:][puri_w body=yukata kao=2 as=on ]
「哎。多洛普的……」[rhp]

[:gonzalez:]
「由你们决定旅行地点，再用魔法准备相应内容星辰的事，[rhr]
_　从南那里接手这项工作的多洛普的职责，这点你们总该知道吧」[rhp]
[:gonzalez:]
「这次那家伙设计世界时，[rhr]
_　事先告知我们的内容是这样的」[rhp]
[:gonzalez:][gon body=yukata kao=14 ]
「在此地让公主最尽兴之人，[rhr]
_　将会得到超～～级丰厚的报酬哦！」[rhp]

[:princess:][puri_w body=yukata kao=2 as=on ]
「哈……！？」[rhp]

[:mataroko:][mata body=yukata kao=6 ]
「原本是和矢部亲老师他们进行团队竞赛的，[rhr]
_　但努西大人起了贪念擅自独立，结果变成三方混战了呢」[rhp]

[off_all]

[chara_part name="yabu" body=yukata kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="yabu" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="nusi" body=yukata kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:nusi:]
「因为我真的很需要军资金嘛。[rhr]
_　南已经断了我的援助……」[rhp]

[:yabu:]
「你这家伙真是糟糕透顶的大人！[rhr]
_　要不是名医早就揍你了！」[rhp]

[off_all]

[chara_part name="gon" body=yukata kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="355" top="0" wait="false" time=150]
[chara_part name="puri_w" body=yukata kao=0 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:gonzalez:]
「顺带一提我们可是瞄准了[rhr]
_　借住你们铁道一周的权利哦！」[rhp]
[:gonzalez:]
「相当～～风雅的提议吧？[rhr]
_　果然冠军该属于我们对吧？请多多关照啦！」[rhp]

[:princess:][puri_w body=yukata kao=13 as=on ]
「这、关照……就算没这种特权，你们随时想来都可以啦」[rhp]

[off_all]

[:yabu:][yabu body=yukata kao=5 ]
「哈哈哈！典型的小孩思维。简直令人无语凝噎……」[rhp]
[:yabu:][yabu body=yukata kao=2 ]
「当我们成为胜者之时！！[rhr]
_　定将你们收归麾下，立即将那铁道―――唔唔！？」[rhp]

[:mika:][mika body=yukata kao=13 ][yabu body=yukata kao=8 as=on ]
「把销售～额全部捐献给贫困儿童们啦♡」[rhp]

[off_all]

[:nusi:][nusi body=yukata kao=6 as=on ]
「米卡亲，说谎可不行啊，不行」[rhp]

[off_nusi]

[:princess:][puri_w body=yukata kao=2 as=on ]
[font color=0x4682b4]
（取悦我的人才能获胜？[rhr]
_　所以要款待到被看中为止？）[rhp]
[:princess:]
（说白了就是拖延战术嘛。[rhr]
_　为了不让我折返去引诱多洛普……）[rhp]
[:princess:][puri_w body=yukata kao=3 as=on ]
（～～～……多洛普早就预料到我会去引诱他）[rhp]
[resetfont]

[off_all]

[::]
不愧是列车长，不可小觑。[rhr]
有点……不，相当不甘心。[rhp]

[:princess:][puri_w body=yukata kao=2 ]
「…………到！　小努西」[rhp]

[::]
我下意识地举起了手。[rhp]

[:nusi:][nusi body=yukata kao=1 ]
「有请，公主」[rhp]

[::]
小努西随意地指名道。[rhp]

[:princess:][puri_w body=yukata kao=2 ]
「在此争斗也无法决定冠军归属。[rhr]
_　不如这样吧」[rhp]
[:princess:]
「接下来各自制作一道自家店里的料理！[rhr]
_　由我带回去让多洛普品尝，印象最佳者获胜！」[rhp]

[:mataroko:][mata body=yukata kao=7 ]
「不该由姐姐大人品尝吗？[rhr]
_　多洛普先生说过要款待姐姐大人哦」[rhp]

[:princess:]
「没关系。现在这心情吃什么都食不甘味」[rhp]
[:princess:]
「能让多洛普笑得最开心的人，就是我的第一名。」[rhr]
_　我正是为了让那个人开心，才来到这里的」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:mataroko:][p_mt_30][mata body=yukata kao=0 ]
「哎呀呀……」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[:mika:][mika body=yukata kao=14 ]
「…………呵呵♡　我觉得很棒呢」[rhp]

[off_mika]

[chara_part name="yabu" body=yukata kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="yabu" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="gon" body=yukata kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:yabu:]
「？　不明白什么意思。你在这里吃完直接决定名次就能速战速决。[rhr]
_　多洛普的礼物可以另外准备，逐个听取那家伙的点评反而会耽误时间……」[rhp]

[:gonzalez:][gon body=yukata kao=11 ]
「矢部亲老师。这可就太不识趣了哦」[rhp]

[:yabu:]
「哈？？」[rhp]

[off_all]

[:princess:][puri_w body=yukata kao=5 ]
「所以啊，我可是很期待能让那个工作狂停下手头工作的绝品料理呢！」[rhp]

[off_puri]

[chara_part name="mata" body=yukata kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="nusi" body=yukata kao=11 as=off ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="gon" body=yukata kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="720" top="0" wait="true" time=150]

[:nusi:]
「真拿你没办法。那么好吧，我就加把劲试试看咯」[rhp]

[:mataroko:]
「哼哼，说得好啊小刚。就算努西大人挡在面前，[rhr]
_　我们还有这章鱼烧呢。一定要夺取……天下！！」[rhp]

[:gonzalez:]
「没问题大姐头！我的铁签能突破音速！」[rhp]

[off_all]

[chara_part name="yabu" body=yukata kao=6 as=on ss=off hh=on hr=on ]
[chara_show name="yabu" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="mika" body=yukata kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="mika" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:yabu:]
「铁签……！？那是什么玩意儿。帅......才、才不是呢！[rhr]
_　御好烧肯定更帅气！我的锅铲功夫可是宇宙级......」[rhp]

[:mika:]
「别看我这样其实会自己做饭哦♡　敬请期待吧，公主！」[rhp]

[:princess:][puri_w body=yukata kao=13 ]
「呵呵呵……！大家，请多关照啦！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
[set_yy storage="fes_01.jpg" rule="002.png" time=500]
;****************************************

[::]
就在他们炮制所谓至高料理的时候，[rhr]
为了在其他摊位也采购食物，我独自逛起了夜市。[rhp]
从小努西三人组的章鱼烧到矢部医生他们的御好烧都顺利领取，[rhr]
双手提着香气四溢的袋子，我回到了社畜王多洛普身边。[rhp]

多洛普将铁道停靠在离神社稍远的开阔地带。[rhp]
或许是察觉到动静，没等我呼唤就主动迎上来的多洛普，[rhr]
看到我的模样后，毫不掩饰地绷紧了笑容。[rhp]
满脸写着难以置信。我才更不想相信呢。[rhr]
居然让我独自穿过那么喧闹的人群。[rhp]

[:drop:][p_d_04][drop kao=13 as=on ]
「…………。那个，公主……这是？」[rhp]

[:princess:][puri_w body=yukata kao=13 ]
「伴手礼哦！全都是为了多洛普一个人买来的」[rhp]
[:princess:]
[font size=30]
「一个人，买，来的」[rhp]
[resetfont]

[:drop:][drop kao=6 as=on ]
「呜、带着怨念呢……」[rhp]

[:princess:][puri_w body=yukata kao=6 ]
「从此再也不怕任何单人行动了」[rhp]

[:drop:]
「这样啊……话说不愿意的话其实不必勉强。[rhr]
_　本来也不必特意张罗，不吃这些也无所谓的」[rhp]

[:princess:][puri_w body=yukata kao=2 ]
「摊贩老板可不会这么通融哦」[rhp]
「那五个人的说辞我都听过了。[rhr]
_　说是要把报酬给让我最久开心的人呢！」[rhp]

[:drop:][p_d_22][drop kao=2 as=on ]
「为什么那些人要说出来啊……！？」[rhp]

[:princess:]
「先说好，如果一直这样下去的话，[rhr]
_　我完全不会开心的」[rhp]
[:princess:]
「多洛普。我们是同伴对吧？[rhr]
_　如果没有你一起的话，什么旅行我都不会甘心的」[rhp]

[:drop:]
「…………」[rhp]

[:princess:][puri_w body=yukata kao=12 ]
「……嘛即使是我，被这么固执地一直拒绝的话，[rhr]
_也终于明白多洛普是无论如何都只想工作的人了」[rhp]
[:princess:][puri_w body=yukata kao=6 ]
「好。想和你一起逛祭典这件事，我退一亿步放弃了。[rhr]
_　但吃饭可逃不掉吧？我们不是总是一起吃的吗？」[rhp]

[:drop:]
「………………、……嘛是的……」[rhp]

[:princess:][puri_w body=yukata kao=11 ]
「太好啦！那我们现在就在这里两个人开宴会吧！[rhr]
_　我去拿餐具之类的，稍等一下――――」[rhp]

[off_puri]

;------------------------------------------------------------------------------------------
;▼再開▼
[fbgm]
[vostart]
;------------------------------------------------------------------------------------------

[:drop:][drop kao=2 as=on ]
「那个」[rhp]

[off_drop]

[::]
兴致勃勃的我被多洛普用严肃的声音制止了。[rhp]

[:princess:][puri_w body=yukata kao=1 ]
「啊，要用魔法拿出来吗？[rhr]
_　不用啦不用啦，这种程度我自己……」[rhp]

[off_puri]

[::]
没有回应我的话，多洛普沉默着。[rhr]
过了一会儿，他沉重地开口道。[rhp]

;****************************************
;スチル
[bgm storage="bgm_19.ogg"]
[still storage="cg/a_07_d_1.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/a_07_d_1.png"]
;****************************************

[:drop:]
「为什么你要这么关心我呢」[rhp]

[:princess:]
「诶……为什么，那是」[rhp]

[:drop:]
「和我在一起时，您看起来还算享受……[rhr]
_　但这并不意味着对您有任何好处吧」[rhp]

[:princess:]
「你、你在说什么呢。我又不是按得失行动的」[rhp]

[:drop:]
「是啊……嗯，这点我也明白。[rhr]
_  痛切地明白您不是那样的女性」[rhp]
[:drop:]
「就连失忆前的您，也曾是那般完美的存在」[rhp]

[:princess:]
「…………！」[rhp]

[:drop:]
「我只是想履行自己的职责。[rhr]
_  从这个角度说，陪您享受旅程并不属于我的职责范畴」[rhp]
[:drop:]
「我的工作是引导诸位，实现你们想去的地方、想做的事……种种心愿。[rhr]
_  对于南交付的这份工作，我感到自豪」[rhp]
[:drop:]
「纵使被视作吃亏的角色 ，但这正是我的使命」[rhp]

[::]
多洛普说着 ，浮现出淡淡的笑意。[rhp]
明明和我们不同 ，本该始终如一才对 ，[rhr]
可他的身影却令人心疼到不忍直视。[rhp]

[:drop:]
「……我是个无趣的男人」[rhp]
[:drop:]
「我不认为与这样的我相处能让您获得满足。[rhr]
_  但作为乘务员 ，我衷心希望能让您享受这段旅程」[rhp]
[:drop:]
「换言之现在的我 ，对您来说只是碍事的存在吧」[rhp]
[:drop:]
「…………真希望您别说出这种话」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[::]
悲伤地低垂眼帘的多洛普。[rhr]
……没想到会被人这样说。[rhp]
对于伤害了多洛普心灵这件事，[rhr]
我不确定是否该继续这场问答。[rhp]
…………但在这里退缩是不行的。[rhr]
因为那样的话，我们一定会永远保持平行线的关系。[rhp]

[:princess:]
「我喜欢总是为他人拼命的多洛普」[rhp]
[:princess:]
「可是……！　如果连自己都不重视，[rhr]
_　那样的拼命就毫无意义了啊！」[rhp]

;****************************************
#
[bg storage="cg/a_07_d_1b.png" time=500]
[cg storage="cg/a_07_d_1b.png.png"]
;****************************************

[:drop:]
「诶……」[rhp]

[:princess:]
「正如多洛普所说，我也想发自内心享受这次旅程。[rhr]
_　既然已经死了，就想放纵自己尽情尝试一切」[rhp]
[:princess:]
「但我不愿意这趟旅程里没有多洛普！」[rhp]

[:drop:]
「……！」[rhp]

[:princess:]
「所以我会一次又一次地邀请你，一次又一次地请求你！」[rhp]
[:princess:]
「无视乘客心愿的服务，真的是理想乘务员该做的吗！」[rhp]

[:drop:][p_d_25]
「这……那个」[rhp]

[:princess:]
「没错。就是这样！我可是乘客啊。[rhr]
_　根本不需要胡思乱想，一开始就该这么做」[rhp]
[:princess:]
「那么问题来了，多洛普。[rhr]
_　银河铁道有位坐轮椅的乘客上车了！你会怎么做？」[rhp]

[:drop:]
「当、当然去协助……？」[rhp]

[:princess:]
「对吧！就该协助对吧！顺带一提我现在也，[rhr]
_　从脑功能上来说完全是需要全天候护理的状态呢」[rhp]
[:princess:]
「今后绝对绝对绝——对要在旅行时陪着我！[rhr]
_　作为要照顾各种琐事的我的辅助人员！」[rhp]

[:drop:]
「……公主……」[rhp]

[:princess:]
「要不同意的话就去向赞助人打小报告～。[rhr]
_　到时候会怎样呢～多洛普～」[rhp]

;****************************************
#
[bg storage="cg/a_07_d_1c.png" time=500]
[cg storage="cg/a_07_d_1c.png"]
;****************************************

[:drop:]
「没、没有不同意！　客人的安全是最优先的！」[rhp]
[:drop:]
「…………太、太狡猾了。公主……[rhr]
_　完全继承了其他队员强硬的作风啊……」[rhp]

[:princess:]
「呵呵！　那么？　我还没听到答复呢」[rhp]

[:drop:]
「～～～～～……」[rhp]

;****************************************
#
[bg storage="cg/a_07_d_1d.png" time=500]
[cg storage="cg/a_07_d_1d.png"]
;****************************************

[:drop:]
「………………如果我可以的话……我会陪同」[rhp]

[:princess:]
「――――！　真的！？　太好啦！」[rhp]
[:princess:]
「说定了哦多洛普。[rhr]
_　游乐园也好夏日祭也好，不许再一个人默默洗车了！」[rhp]

[:drop:]
「好好……我认命了」[rhp]

;****************************************
[fbgm]
;スチル終了
[still_end frame="win.png" storage="fes_01.jpg" time=1000]
;****************************************

[chara_part name="drop" body=base kao=0 as=on ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=yukata kao=14 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[bgm storage="bgm_28.ogg"]

[:princess:]
「好！　那现在就出发吧！　夏日祭！」[rhp]

[:drop:][drop kao=2 as=on ]
「咦？　不是预定在这里用餐吗？」[rhp]

[:princess:][puri_w body=yukata kao=1 ]
「刚说过要陪我去的对吧？　离烟花大会还有时间！[rhr]
_　换好浴衣一起走吧！　好不好嘛！」[rhp]

[:drop:][p_d_10][drop kao=6 as=on hh=on ]
「～～～！　浴、浴衣再怎么说也兴奋过头了吧」[rhp]

[:princess:][puri_w body=yukata kao=5 ]
「抗议无效！！！」[rhp]

[off_all]

[:drop:]
[font size=30]
「啊！？　等……啊啊～～～～～～！！！」[rhp]
[resetfont]

;****************************************
[set_time storage="fes_01.jpg"]
;****************************************

[:drop:][drop body=yukata kao=2 as=on hh=on hat=off hat=off ]
「…………………………」[rhp]

[off_all]

[::]
在犹豫了5分钟左右后，多洛普终于换上了浴衣。[rhp]
强行扯下背心、用力抽出腰带之后，[rhr]
他总算认命地换上了浴衣。[rhp]
顺便一提，那条腰带至今还作为人质留在我手里。[rhp]

[:drop:][drop body=yukata kao=3 as=on hh=on hat=off ]
「……很奇怪、对吧」[rhp]

[:princess:][puri_w body=yukata kao=14 ]
「很合适哦。十足人妻感！」[rhp]

[:drop:][drop body=yukata kao=2 as=on hh=on hat=off ]
[font size=28]
「果然还是脱掉吧！！」[rhp]
[resetfont]

[:princess:][puri_w body=yukata kao=13 as=on ]
「对、对不起嘛。都说是玩笑啦！[rhr]
_　难得克林特意准备的，就穿着吧」[rhp]

[:drop:][drop body=yukata kao=3 as=on hh=on hat=off ]
「呜～～～……」[rhp]

[:princess:]
「好啦好啦，乖乖的。别哭啦」[rhp]

[off_all]

[::]
啪啪轻拍着比自己还高的男孩的脑袋。[rhr]
对向来稳重的多洛普做这种事，感觉格外新鲜。[rhp]

[chara_part name="drop" body=yukata kao=6 as=on ss=off hh=on hr=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=yukata kao=1 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:drop:]
「除了制服从没穿过别的……大家会怎么说我啊……」[rhp]

[:princess:]
「自信点。超帅气的」[rhp]

[:drop:][p_d_25]
「可、可是……」[rhp]

[off_all]

[::]
看着始终缺乏自信的多洛普，[rhr]
某种恶作剧心理突然萌生。[rhp]

[:princess:][puri_w body=yukata kao=13 ]
「……呵呵呵」[rhp]

[:drop:][drop body=yukata kao=1 hat=off ]
「？怎么了？」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

;****************************************
;スチル
[still storage="cg/a_07_d_2.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/a_07_d_2.png"]
;****************************************

[:princess:]
「看招」[rhp]

[:drop:]
「――――！哎、啊」[rhp]

[:princess:]
「趁你安静时把你打扮成女友模样吧～～～」[rhp]

[:drop:]
「女、女友！？你你、胡说什么」[rhp]

[:princess:]
「多洛普是游戏初学者来着。[rhr]
_　为了不让他走散，就牵着他的手走吧」[rhp]
[:princess:]
「不可以擅自跑去别处哦？要好好跟着我」[rhp]

[:drop:]
「………………」[rhp]

[:princess:]
「……多洛普？」[rhp]

[:drop:]
「……没、没什么……」[rhp]

;****************************************
#
[bg storage="cg/a_07_d_2b.png" width="1280" height="720" time=500]
[cg storage="cg/a_07_d_2b.png"]
;****************************************

[:princess:]
「―――！」[rhp]

[::]
被动牵着的多洛普手心里，传来轻微的力道。[rhp]

[:drop:]
「……公主」[rhp]
[:drop:]
「谢谢您。为我考虑这么多」[rhp]
[:drop:]
「………，非常开心」[rhp]

[:princess:]
「……！　嗯、嗯。诶嘿嘿……」[rhp]
[:princess:]
「好、出发吧！要是那五人组看到现在的多洛普，肯定会吓一跳呢」[rhp]

[:drop:]
「我也想见他们。还要道谢收到的礼物」[rhp]

[:princess:]
「好，那就由我带路吧！」[rhp]

[:drop:]
「―――，好的！」[rhp]

;****************************************
[still_end frame="win.png" storage="sky_07.jpg" time=1000]
;****************************************

[::]
就这样直到烟火大会开始前，我们两人共同享受着夏日祭典。[rhp]
在烟火会场看见多洛普身着浴衣的模样，虽然大家都吃了一惊，[rhr]
但对他能一起来这件事感到极为欣喜。[rhp]
只要和你在一起，大家都很开心。[rhr]
这份一直想传达的心情终于被接收，今天真是非常非常美好的日子。[rhp]

[::]
[:princess:]
[font color=0x4682b4]
（……我决定了）[rhp]
[resetfont]

[::]
从今往后，不该是我跟在多洛普身后。[rhr]
应该由我带领着多洛普前行。[rhp]
就像现在这样，牵着这只手。[rhp]

;****************************************
[s_mask color=0xffffff time=2000]
[set_xx graphic="rule/krke_d.png" storage="train_08.jpg"]
;****************************************

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

; イベント分岐の解除
[iscript]
delete f.ev_a_07;
[endscript]

[jump storage="ev_a_08_drop.ks"]

[s]
