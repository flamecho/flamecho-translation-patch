﻿*start
;--------------------------------------------------------------------------------------------
;▼フルボイスセット▼
;クォードリリオン
[voconfig sebuf=1 name=riri vostorage="riri/full/{number}.ogg" number=99]
;-------------------------------------------------------------------------------------------
;****************************************
[bgm storage="bgm_22.ogg"]
;****************************************

[::]
自那场夏日祭典过去一周左右。[rhp]
我正为某个严重问题苦恼不已。[rhp]

[:princess:][puri_w kao=2 as=on ]
「…………………………」[rhp]

[off_puri]

[::]
在那场夏日祭典上，我竟爱上了夸德里利昂。[rhp]
这倒也没什么。真的没什么。[rhp]
毕竟夸德里利昂只要不说话就相当俊美，[rhr]
心情好时也会展现出温柔可靠的一面。[rhp]
但不得不承认，我有绝对不能主动出击的理由。[rhp]

[:princess:][puri_w kao=2 as=on ]
「………………ＡＡ」[rhp]

[off_puri]

[::]
缠绕在胸前的软尺数值揭露着残酷真相。[rhp]
没错。我的胸部彻底平如钢板。[rhp]
当我向博士咨询胸围测量方法时，[rhr]
他甚至建议『米卡亲的话应该会告诉你吧』程度的那种贫瘠。[rhp]

[:princess:][puri_w kao=2 as=on ]
[font color=0x4682b4]
（难道我就不能自己测量罩杯吗！[rhr]
_　米卡亲的罩杯数根本不用问也知道啦）[rhp]
[resetfont]

[off_puri]

[::]
于是实测结果是AA。[rhp]
据说AA意味着比A杯还要糟糕。[rhr]
本来以为至少能有B杯，打击实在太大。[rhp]

不言而喻，夸德里利昂是个究极巨乳控。[rhp]
从「巨乳观察」这个词汇就能看出，[rhr]
他既不想占有也不追求，只坚持远观的态度。[rhp]
换言之，绝非出于下流目的。[rhr]
怀着某种庄严信念，他虔诚地欣赏着巨乳。[rhp]
另一方面对贫乳却毫无怜悯之心，是个冷酷无情的魔鬼男人。[rhp]
既、既然如此。[rhp]

[:princess:][puri_w kao=6 as=on ss=on ]
「只能让我变成巨乳了……！！」[rhp]

[off_puri]

[::]
就算我是让您讨厌的丑女布兹，[rhr]
巨乳爱好者理应不会虐待巨乳才对。[rhp]

[:princess:][puri_w kao=5 as=on hh=on ]
「先从C罩杯开始挑战吧。哼哼，这种程度简直绰绰有余」[rhp]
[:princess:][puri_w kao=2 hh=on ]
[font size=28]
「绝对要！成为！巨乳啊――――――！！！！」[rhp]
[resetfont]

;****************************************
[set_xx graphic="rule/krke_r.png" storage="train_01.jpg"]
;****************************************

[::]
于是乎，我照例移动到客车的自己座位上。[rhp]
光靠自己总觉得变化不够明显，[rhr]
要让周围人注意到后主动说「咦？是不是变大了？」才行。[rhp]

[:kite:][kite kao=2 as=on ]
「…………………………」[rhp]

[off_kite]

[:drop:][drop kao=2 as=on ]
「…………………………」[rhp]

[off_drop]

[:princess:][puri_w kao=2 hh=on ]
「嗯～～～～……这样？」[rhp]
[:princess:]
「……。……嗯～～～～……」[rhp]
[:princess:][puri_w kao=6 hh=on ]
「…………这样呢！？」[rhp]
[:princess:][puri_w kao=2 hh=on ]
「……………………，………………嗯～～～……感觉不太明显啊」[rhp]

[off_all]

[chara_part name="drop" body=base kao=2 as=on ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:drop:]
「那个，快斗。她究竟在……」[rhp]

[:kite:]
「能不能别问我？不想扯上关系」[rhp]

[:drop:]
「那那边那位呢？」[rhp]

[off_all]

[:darknebula:][hakase msk=off kao=2 ]
「第一天：公主，尝试通过刺激乳腺激活雌性激素但以失败告终……」[rhp]
[:darknebula:][hakase msk=off kao=5 hh=on ]
「……公主观察日记！看来能写出杰作呢！」[rhp]

[off_hakase]

[chara_part name="drop" body=base kao=2 as=on ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:kite:]
「都被判定为失败了啊」[rhp]

[:drop:]
「又增加了个像夸德里利昂那样的人呢……」[rhp]

[off_all]

[:quadrillion:][riri kao=0 ]
「哎呀。我怎么了？」[rhp]

[off_all]

[chara_part name="drop" body=base kao=2 as=on ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left=80 top=0 wait="false" time=150]
[chara_part name="riri" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left=421 top=0 wait="false" time=150]
[chara_part name="kite" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left=760 top=0 wait="true" time=150]

[:drop:]
「啊，是夸德里利昂！」[rhp]

[:kite:]
「罪魁祸首来了」[rhp]

[:quadrillion:][riri kao=6 ]
「哈？突然打招呼啊」[rhp]
[:quadrillion:][riri kao=0 ]
「……！那边的难道是公主和博士？」[rhp]

[off_all]

[:princess:][puri_w kao=2 as=on ]
「记得是说吃海藻就行了吧。[rhr]
_　让多洛普做点海藻料理试试？」[rhp]

[off_all]

[:darknebula:][hakase msk=off kao=2 as=on ]
「那只是增发迷信啦！不过等等——[rhr]
_　安慰剂效应说不定会让胸毛逆向增长……」[rhp]

[off_all]

[chara_part name="riri" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left=208 top=0 wait="false" time=150]
[chara_part name="kite" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left=645 top=0 wait="true" time=150]

[:kite:][kite kao=2 as=on]
「逆向是什么……」[rhp]

[:quadrillion:][riri kao=2 as=on ]
「……他们在搞什么鬼？」[rhp]

[:drop:][drop kao=6 as=on ]
「其实是……」[rhp]

;****************************************
[set_xx graphic="rule/krke_r.png" storage="train_01.jpg"]
;****************************************

[:drop:][drop kao=6 as=on ]
「————就是这么回事」[rhp]

[off_all]

[:quadrillion:][riri kao=2 as=on ss=on ]
「……………………」[rhp]

[off_all]

[chara_part name="drop" body=base kao=6 as=on ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left=80 top=0 wait="false" time=150]
[chara_part name="riri" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left=421 top=0 wait="false" time=150]
[chara_part name="kite" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left=760 top=0 wait="true" time=150]

[:drop:]
「公主正在尝试丰胸。[rhr]
_　博士在全程跟进观察啦」[rhp]

[:kite:]
「你绝对是被克林传染了才会说这种话」[rhp]

[:quadrillion:]
「别把丰胸说得像传染病似的」[rhp]

[:drop:]
「但肯定是受你影响没错吧？[rhr]
_　公主居然做这种事……我都没脸面对南了！」[rhp]

[off_all]

[:quadrillion:][riri kao=3 as=on ]
「哎呀呀……真没办法。那老娘就助他们一臂之力吧」[rhp]

[off_all]

[:drop:][drop kao=2 as=on hh=on ]
[font size=28]
「是色情层面的帮助吗！？」[rhp]
[resetfont]

[off_all]

;****************************************
#
[se storage="door_10.ogg"]
[yurasu]
[bg_rule storage="train_04.jpg" rule="002.png" time=300]
;****************************************

[:drop:][drop kao=8 as=on ]
「啊！？为什么赶我走！」[rhp]

[off_all]

;****************************************
#
[bg storage="train_01.jpg" time=500]
;****************************************

[:quadrillion:][riri kao=2 as=on ]
「你小学生吗！[rhr]
_　当然是要解决这种局面的意思啊！」[rhp]
[:quadrillion:]
「够了。你们老实回自己岗位去」[rhp]

[off_all]

[:kite:][kite kao=7 ]
「是色情层面的回岗位吗？」[rhp]

[off_all]

;****************************************
#
[se storage="door_10.ogg"]
[yurasu]
[bg_rule storage="train_04.jpg" rule="002.png" time=500]
;****************************************

[chara_part name="drop" body=base kao=2 as=on ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:kite:]
「别老梗重提。太无趣了」[rhp]

[:drop:]
「快斗先生！　请不要开玩笑了啦」[rhp]

[:kite:]
「多洛普没资格说我吧」[rhp]

[off_all]

;****************************************
#
[bg storage="train_01.jpg" time=500]
;****************************************

[:quadrillion:][riri kao=2 ]
「真是的……！　对那几个人的天然呆已经受够了……」[rhp]

[off_all]

[:darknebula:][hakase msk=off kao=5 hh=on ]
「期待丰胸效果而食用藻类的情况下[rhr]
_　对胸部尺寸与头发的影响……！　这篇论文似乎很有意思！」[rhp]
[:darknebula:][hakase msk=off kao=2 as=on hh=on ]
「哈、等等？　这么说来……」[rhp]

[:quadrillion:][riri kao=5 as=on ]
「博士。能让我和那个布兹单独待会儿吗……」[rhp]

[:darknebula:][hakase msk=off kao=5 as=on hh=on ]
「啊呀夸德里利昂你来了！　来得正好！」[rhp]
[:darknebula:]
「你是不是在为头发烦恼啊！？[rhr]
_　要不要试试这个大豆异黄酮补充剂……」[rhp]

[off_all]

;****************************************
#
[se storage="mag_03.ogg"]

[s_mask color=0x000000 rule="009.png"]
[chara_hide_all time=150 wait=true]
[bg storage=train_07.jpg time=1500]
[s_wait time=1000]
[off_all]
[s_mask_off rule="009.png"]
;****************************************

[:darknebula:][hakase msk=off kao=2 as=on ]
「啊啊，太过分了！」[rhp]

[off_all]

[chara_part name="otiai" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:]
「咦？　博士欢迎回来！　是用魔法回来的呀」[rhp]

[:otiai:]
「你这家伙啊。把看孩子的活儿推给我到底去哪儿了」[rhp]

[off_all]

[:darknebula:][hakase msk=off kao=3 as=on ]
「可恶，明明进展顺利……算了也没办法……」[rhp]

[off_all]

[chara_part name="otiai" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:][peku kao=0 ]
「？　顺～利？」[rhp]

[off_all]

[:darknebula:][hakase msk=off kao=11 ]
「呵呵……夸德里利昂吗。挺不错嘛[rhr]
_　我可不是那么不识趣会妨碍男女关系的人……」[rhp]
[:darknebula:]
「祝好运！　公主！」[rhp]

[off_all]

[chara_part name="otiai" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:]
「喂～！　你们在说什么呀～！？」[rhp]

[:otiai:]
「别掺和比较明智哦……」[rhp]

;****************************************
[set_xx graphic="rule/krke_r.png" storage="train_01.jpg"]
;****************************************

[:quadrillion:][riri kao=6 ]
「这下吵闹的家伙们都消失了呢……」[rhp]
[:quadrillion:]
「…………好了」[rhp]

[off_riri]

[:princess:][puri_w kao=3 ]
「嗯～～～～～…………」[rhp]

[off_puri]

[:quadrillion:][riri kao=6 as=on ]
[font color=0x4682b4]
（到底在搞什么……稍微观察下好了）[rhp]
[resetfont]

[off_riri]

[:princess:][puri_w kao=3 as=on ]
「哈啊…………摸也好吃也好，完全没变化」[rhp]

[off_puri]

[:quadrillion:][riri kao=6 ]
[font color=0x4682b4]
（这不是当然的吗……[rhr]
_　妄想一朝一夕就能变成巨乳简直大错特错）[rhp]
[resetfont]

[off_riri]

[:princess:][puri_w kao=3 ]
「只要说变成巨乳或许就能想起过去，[rhr]
_　南会不会特别帮我变成巨乳呢……不可能的吧……」[rhp]
[:princess:]
「到底要怎样才能变成巨乳啊。[rhr]
_　明明听说在这里能变成理想模样的。难道是生前品行太差吗……」[rhp]
[:princess:][puri_w kao=2 as=on ]
「但不被允许拥有巨乳的日常行为是什么啊。[rhr]
_　生前明明是爆乳，难道是因为像莉莉那样嘲笑过贫乳？」[rhp]

[:quadrillion:][riri kao=6 ]
「说不定哦」[rhp]

[yurasu]

[:princess:][puri_w kao=2 as=on ]
「呜呀！！」[rhp]

[:quadrillion:][riri kao=5 ]
「午安公主。心情如何？」[rhp]

[:princess:]
「莉、莉莉！为什么在这里！？」[rhp]

[:quadrillion:][riri kao=6 ]
「普通车辆我也是会用的。这里可不是你的闺房哦」[rhp]
[:quadrillion:][riri kao=5 ]
「话说……我都看到了？刚才起就开心得很嘛。[rhr]
_　居然在鲁莽地努力丰胸呢」[rhp]

[:princess:][puri_w kao=6 as=on ss=on ]
「……………………」[rhp]

[:quadrillion:][riri kao=11 as=on ]
[font color=0x4682b4]
（太好懂了……真有趣干脆捉弄下她好了）[rhp]
[resetfont]
[:quadrillion:][riri kao=13 ]
「我说。刚才你提到南什么的对吧？」[rhp]

[:princess:][puri_w kao=0 ]
「啊，嗯。南会使用魔法，说不定……」[rhp]

[:quadrillion:][riri kao=5 ]
「诶～。你、你是为了南才想让胸变大啊」[rhp]

[:princess:][puri_w kao=2 as=on hh=on ]
「哈！？　才不是！！　为什么会这么想！　首先我觉得南根本对[rhr]
_　巨乳什么的没兴趣！　和某些人可不一样！」[rhp]

[:quadrillion:]
「真是的，你完全不懂呢。[rhr]
_　从古到今从东到西，就没有男人会讨厌巨乳哦」[rhp]

[:princess:][puri_w kao=6 as=on hh=on ]
「…………」[rhp]

[:quadrillion:][riri kao=0 ]
「干嘛突然沉默啊」[rhp]

[:princess:]
「顺便问一下……[rhr]
_　如果我变成巨乳的话，莉莉会对我有兴趣吗？」[rhp]

[:quadrillion:][riri kao=2 as=on ]
「！　这个……」[rhp]
[:quadrillion:]
「…………要看尺寸了」[rhp]

[:princess:]
「现在暂时以C为目标……」[rhp]

[:quadrillion:][riri kao=6 ]
「哈？　太没出息了」[rhp]

[:princess:][puri_w kao=2 as=on ss=on ]
「贪心鬼！！　不可理喻！」[rhp]

[:quadrillion:]
「日本女性的平均罩杯是B～C。[rhr]
_　也就是说C杯根本算不上巨乳哦」[rhp]
[:quadrillion:]
「通常男人认为的巨乳标准，据说要从E杯开始呢。[rhr]
_　顺便说米卡亲的胸部预估有J杯哦」[rhp]

[:princess:][puri_w kao=2 as=on ss=on ]
「滔滔不绝的真是……」[rhp]

[:quadrillion:][riri kao=2 ]
「话说你。刚才那个像屎一样的丰胸按摩算什么呀」[rhp]

[:princess:][puri_w kao=6 as=on hh=on ]
「诶！？　既、既然看见了那出声提醒一下也……」[rhp]

[:quadrillion:]
「根本没效果嘛。有好好查过正确方法吗？[rhr]
_　我可没在埋怨你那套野路子没效果哦。所以说外行人就是……」[rhp]

[:princess:][puri_w kao=2 as=on ]
「呜、烦死了……我乐意你管得着吗！[rhr]
_　既然这么说那莉莉你自己来试试看啊！」[rhp]

[:quadrillion:][riri kao=0 ]
「哈？」[rhp]

[:princess:][puri_w kao=4 as=on ]
「诶？………啊」[rhp]

[:quadrillion:][riri kao=6 as=on ]
「你这家伙…………」[rhp]

[:princess:][puri_w kao=2 as=on hh=on ]
「…………～～～！！」[rhp]

[off_all]

[yurasu]

[:princess:]
[font size=30]
「哇啊啊啊啊―――――――！！！！！」[rhp]
[resetfont]

[:quadrillion:]
「公、公主！？等等！！快住手啊！」[rhp]

[:quadrillion:][riri kao=6 as=on ]
「………………、走掉了」[rhp]

[off_all]

[::]
――――――『既然这样说莉莉你自己来做不就好了！』[rhp]

[:quadrillion:]
[font color=0x4682b4]
（什么啊……我知道是言语的把戏，其实没必要逃开的）[rhp]
[resetfont]
[:quadrillion:][riri kao=6 as=on ]
「…………、……虽然觉得不可能」[rhp]

[off_all]

[::]
…………那家伙，该不会在意我吧？[rhp]

[:quadrillion:]
「………………。不不不不…………」[rhp]

[::]
唯独这个不行。[rhp]
我是不会喜欢上公主的。[rhr]
就算世界天翻地覆，我也决不会选择那家伙。[rhp]
和『那家伙』同样的选择，无论如何我都不想做。[rhp]

[:quadrillion:]
「啧……真麻烦呢」[rhp]

[::]
如果这就是所谓的命运，那可太荒唐了。[rhr]
但我的人生、我的未来、我的感情，都只属于我自己。[rhp]
……虽然很麻烦，但必须采取措施。[rhp]

;****************************************
[set_xx graphic="rule/krke_r.png" storage="train_08.jpg"]
;****************************************

在不小心对夸德里利昂投下炸弹发言之后。[rhp]
从那之后已经过了几个小时，我躲在房间里因后悔而颤抖不已。[rhp]

[:princess:][puri_w kao=5 as=on ]
「哈……没、没事。毕竟莉莉应该也明白的。[rhr]
_　这种程度根本不值一提！别在意啦！」[rhp]

[off_all]

[::]
……如此这般激励着自己，伸手握住门把手的动作重复了数十次。[rhp]

[:princess:][puri_w kao=2 as=on ss=on ]
「不……因为是莉莉，肯定是明白之后还要永远把我当小笨蛋……」[rhp]
[:princess:]
「只要踏出房门，绝对会在大家面前嘲笑我……[rhr]
_　那家伙就是这种人妖嘛……」[rhp]

[off_all]

[::]
……结果还是折返回来瘫坐在沙发上，[rhr]
最终都没能正经地走出房间。[rhp]

[:princess:][puri_w kao=3 as=on ]
「哈啊啊啊啊～～～～～……[rhr]
_　是否领会为言语艺术姑且不论……」[rhp]
[:princess:]
「………………绝・对・已・经・被・嫌・弃・了」[rhp]

[off_all]

[::]
年纪轻轻就死了，记忆会消失，告白前还说变态言论……[rhr]
为什么我的人生就诸事不顺呢。[rhp]
这种时候真希望记忆能消失殆尽，[rhr]
但就算是魔法世界，似乎也没这么称心如意。[rhp]

既然如此沮丧也无济于事。[rhr]
今晚就懊悔到死，明天全部重置吧。这样最好。[rhp]
今天的失败也好，这份朦胧心意也罢，全都当没发生过就行。[rhp]
这样的话，至少觉得还能保持至今为止一起胡闹的关系。[rhp]

[:princess:]
「总觉得，胸口疼……」[rhp]

[::]
为了夸德里利昂，居然会有这种心情。[rhp]
明明是那么爱捉弄人、说话刻薄又麻烦的家伙……[rhp]
…………当真什么的，简直像傻瓜一样。[rhp]

;****************************************
[fbgm]
[s_mask color=0x000000 time=2000]
[set_xx graphic="rule/krke_r.png" storage="train_01.jpg"]
[bgm storage="bgm_30.ogg"]
;****************************************

翌日[rhp]

[:drop:][drop kao=4 as=on ]
「…………………………」[rhp]

[:quadrillion:]
「早安。多洛普」[rhp]

[:drop:]
「……早、早安……？」[rhp]

[off_all]

[:kite:][kite kao=2 as=on ]
「…………………………」[rhp]

[:quadrillion:]
「快斗也早安」[rhp]

[:kite:]
「…………………………早……」[rhp]

[off_all]

[chara_part name="jet" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:quadrillion:]
「那边的小鬼们，早安」[rhp]

[:2nin:]
「……………………」[rhr]
「……………………」[rhp]

[:heartshape:]
「…………谁？」[rhp]

[:quadrillion:]
「不不。说什么谁，我是……」[rhp]

[off_all]

[se storage="door_07.ogg"]

[:princess:][puri_w kao=14 as=on hh=on ]
「大家！早……早安～～～！！」[rhp]

[off_all]

[chara_part name="jet" body=base kao=5 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="736" top="0" wait="true" time=150]

[:3nin:]
「！！！！！」[rhr]
「！！！！！」[rhp]

[off_all]

[:drop:][drop kao=2 as=on ]
「糟了，公主……！」[rhp]

[off_all]

[::]
我散播着过度活力，推开了大家所在的车厢门。[rhr]
因为来之前练习了好几次，应该不至于显得不自然……大概。[rhp]

[:princess:][puri_w kao=0 as=on ]
[font color=0x4682b4]
（话说回来，刚才说了『糟了』？）[rhp]
[resetfont]

[off_all]

[::]
是发生了什么吗？正想不动声色地环顾四周时，[rhr]
肩膀被哈蒂君他们用力抓住，变得无法回头。[rhp]

[chara_part name="jet" body=base kao=5 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=2 as=on ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「等、等等。怎么回事？」[rhp]

[:jet:]
「早安公主！来得正好！」[rhp]

[:heartshape:]
「后面最好不要看！因为正发生有趣的事！」[rhp]

[:princess:]
「反而更在意了啊」[rhp]

[off_all]

[:kite:][kite kao=2 as=on ]
「嘿」[rhp]

[off_all]

[chara_part name="jet" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:hutago:]
「呀！！！」[rhr]
「呀！！！」[rhp]

[off_all]

[::]
快斗戳了戳红白组的侧腹。[rhr]
或许是因为怕痒，两人用相同的动作向后跳开。[rhp]

[chara_part name="jet" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="736" top="0" wait="true" time=150]

[:jet:]
「你这家伙！」[rhp]

[:heartshape:]
「突然搞什么啊！」[rhp]

[:kite:]
「因为我是喜欢分享有趣事情的类型嘛」[rhp]

[off_all]

[:princess:][puri_w kao=0 as=on ]
「有趣的事情……」[rhp]

[off_all]

[::]
我对三人的对话感到困惑，保持警戒的同时回头望去。[rhp]

[:quadrillion:][riri kao=2 ]
「………………」[rhp]

[:princess:][puri_w kao=0 as=on ]
「呜哇！！」[rhp]

[off_puri]

[::]
站在身后的是脸色阴沉的夸德里利昂。[rhp]

[:princess:][puri_w kao=0 as=on ]
「早、早安……克林……」[rhp]

[:quadrillion:][riri kao=2 ]
「……克林？」[rhp]

[off_puri]

[::]
被狠狠瞪视后，强撑的笑容抽搐起来。[rhr]
有趣的事情该不会是指他不高兴吧？骗人的？[rhp]

[off_all]

[:princess:][puri_w kao=2 as=on ]
[font color=0x4682b4]
（不、不行啊公主……！明明在镜子前练习过。[rhr]
_　平常心、平常心……！要像往常一样随意……！）[rhp]
[resetfont]

[riri kao=0 ]

[:princess:][puri_w kao=14 as=on ]
「今天早晨真不错呢！虽然外面还是那片星空！[rhr]
_　总之就是感觉很清爽？对吧克林！！」[rhp]

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
[vostart]
;--------------------------------------------------------------------------------------------

[:quadrillion:][riri kao=2 ]
「哈？」[rhp]

[:princess:][puri_w kao=1 as=on ]
「……咦？克、克林……？」[rhp]

[off_puri]

[::]
总觉得氛围和往常不太一样。[rhr]
怎么回事……表情比平时更严厉了……[rhp]

[:quadrillion:][riri kao=2 ]
「干嘛啊。一直盯着我看」[rhp]
[:quadrillion:][riri kao=5 ]
「哼，我的脸有那么美吗」[rhp]

[:princess:][puri_w kao=2 as=on ]
「你、『我』！？　你怎么了克、」[rhp]

[:quadrillion:][riri kao=2 ]
「不是克林」[rhp]
[:quadrillion:]
「―――『我』是理央」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[off_all]

[chara_part name="jet" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:jet:]
「理央？　这家伙在说什么啊」[rhp]

[:kite:]
「……可笑不起来啊」[rhp]

[off_all]

[chara_part name="riri" body=base kao=5 as=off ss=off hh=off hr=on hair=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:quadrillion:]
「『我』回来了，高兴吧？　至少快斗是」[rhp]

[:kite:]
「………………」[rhp]

[:quadrillion:][riri kao=11 ]
「哎呀呀……搞什么，这么冷淡。莫非是在害羞？」[rhp]
[:quadrillion:][riri kao=13 ]
「难得的机会告诉你也可以哦。毕竟你和我―――」[rhp]

[:kite:][kite kao=6 ]
「住口吧克林」[rhp]

[:quadrillion:]
「！　所以我是……」[rhp]

[:kite:][kite kao=6 ]
「无所谓了。赶紧回去经营你的gay bar就行」[rhp]

[off_all]

[yurasu]
[se storage="hand_05.ogg"]

瞬间，一记凌厉的耳光在快斗头上炸裂。[rhp]

[chara_part name="riri" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=2 as=on ss=on hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:kite:]
「好疼啊啊啊～～～……！！　又马上动手……！」[rhp]
[:kite:]
「这不是克林还能是谁！[rhr]
_　既然说是理央就给我更像理央一点啊！」[rhp]

[:quadrillion:][riri kao=14 ]
「像不像的，本来就是本人啊」[rhp]

[off_all]

[:princess:][puri_w kao=2 as=on ]
[font color=0x4682b4]
（理央这名字，是夏日祭听到的那个吧……？[rhr]
_　但在这里的，怎么看都是克林啊……）[rhp]
[resetfont]
[:princess:]
「…………，完全搞不懂！　到底什么情况！」[rhp]

[:drop:][drop kao=3 ]
「我们也很惊讶。[rhr]
_　我早上见到的时候就已经是这样子了」[rhp]
[:drop:]
「不明白意思。为什么突然要假扮理央先生……」[rhp]

[:princess:][puri_w kao=4 ]
「理央？」[rhp]

[:drop:][drop kao=14 as=on ]
「！　啊、没、没有……到、到底是怎么回事啊真的！[rhr]
_　昨晚是不是发生了什么」[rhp]

[:princess:][puri_w kao=2 as=on ]
「！！」[rhp]

[:drop:][drop kao=7 ]
「公主是昨天，和夸德里利昂聊了很多呢。[rhr]
_　有什么线索吗？」[rhp]

[:princess:][puri_w kao=6 as=on ]
「那个……这个」[rhp]

[off_all]

[::]
……………………………。[rhp]

[chara_part name="drop" body=base kao=0 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left=421 top=0 wait="false" time=150]
[chara_part name="puri_w" body=base kao=13 as=on ss=on hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「……咔……完全摸不着头脑呢」[rhp]

[:drop:][drop kao=6 ]
「这样吗……真是棘手啊」[rhp]

[off_all]

[:darknebula:][hakase msk=off kao=5 ]
「大家早上好，一大早就这么热闹。是有什么纠纷吗……」[rhp]

[off_all]

[chara_part name="drop" body=base kao=5 as=on ss=off hh=on hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="80" top=0 wait="false" time=150]
[chara_part name="hakase" body=base kao=1 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720" left="355" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="720" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=5 as=on ss=off hh=on hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:2nin:]
[font size=25]
「博士！！」[rhr]
「博士！！」[rhp]
[resetfont]

[:vulpecula:][peku kao=6]
「佩奇也在这里哟！！」[rhp]

[:darknebula:][hakase msk=off kao=5 as=on ]
「怎么了？感觉异常受欢迎呢……」[rhp]

[:drop:][drop kao=8 as=on ]
「实际上，现在遇到了一点麻烦……」[rhp]

[:princess:][puri_w kao=2 as=on ]
「克林他不当伪娘了！」[rhp]

[:darknebula:]
「哈？」[rhp]

[:drop:]
「其实是――――――……」[rhp]

;****************************************
[fbgm]
[set_time_b]
[bgm storage="bgm_19.ogg"]
;****************************************

[chara_part name="hakase" body=base kao=1 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="drop" body=base kao=1 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="645" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=1 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:darknebula:]
「嗯……大概情况我明白了」[rhp]
[:darknebula:]
「真想知道啊，他的心理。[rhr]
_　怎么样，这次不如交给我来处理吧」[rhp]

[:princess:][puri_w kao=14 ]
「不愧是博士！」[rhp]

[:drop:][drop kao=14 ]
「真不愧是心理学家！」[rhp]

[off_all]

[chara_part name="jet" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="736" top="0" wait="true" time=150]

[:heartshape:]
「真的没问题吗？博士虽然知识渊博，但毕竟是个怪人……」[rhp]

[:kite:]
「不没问题的。没有博士做不到的事」[rhp]

[:jet:]
「谁知道呢……不过新来的落合[rhr]
_　应该还没被博士崇拜洗脑，万一的话……」[rhp]

[off_all]

[:otiai:][otiai kao=2 as=on hh=on]
「博士……！　果然还是您厉害」[rhp]

[off_all]

[chara_part name="jet" body=base kao=2 as=on ss=on hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:jet:]
「…………」[rhp]

[:heartshape:]
「没问题的杰特！博士虽然是个怪人，但确实是个厉害角色！[rhr]
_　总会有办法的。对吧！」[rhp]

[:jet:]
「嘛，哈蒂觉得没问题的话就行啦……」[rhp]

[off_all]

[:quadrillion:][riri kao=6 ]
「你们从刚才开始就很失礼啊。我可是全都听见了」[rhp]

[:darknebula:][hakase msk=off kao=1 ]
「好啦好啦。别这么生气」[rhp]

[:quadrillion:][riri kao=0 ]
「博士……」[rhp]

[:darknebula:]
「既然都听到了就好办。要不要和我聊两句？」[rhp]

[:quadrillion:][riri kao=7 ]
「…………。好啊」[rhp]

[:darknebula:]
「谢谢。那我们去那边的包厢座位吧」[rhp]

[off_all]

[::]
博士用成熟的应对方式引导着克里利……不对是理央。[rhr]
我们决定在稍远的位置静观事态发展。[rhp]

[chara_part name="hakase" body=base kao=1 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="riri" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:darknebula:]
「那么重新问候……早安。夸德里利昂」[rhp]

[:quadrillion:][riri kao=1 ]
「早安博士。今天睡懒觉了吗？[rhr]
_　熬夜可不利于健康。要多注意身体」[rhp]

[:darknebula:]
「呵呵，谢谢」[rhp]
[:darknebula:]
「不过正式交谈起来还是觉得好别扭……[rhr]
_　为什么突然要自称理央啊？」[rhp]

[:quadrillion:][riri kao=13 ]
「因为是理央」[rhp]

[:darknebula:][hakase msk=off kao=5 as=on ]
「不，我不是这个意思……」[rhp]

[:quadrillion:][riri kao=3 ]
「为什么大家都不愿意接受我是理央？[rhr]
_　我只是在回应大家的期待而已」[rhp]
[:quadrillion:]
「比起古怪又别扭的夸德里利昂，理央更好吧。[rhr]
_　明明是如你所愿的结果，到底还有什么不满」[rhp]

[:darknebula:][hakase msk=off kao=1 ]
「要是这样的话，从开始住在这条铁道上时，就该这么做了」[rhp]
[:darknebula:]
「你从一开始，不展现女性化的一面[rhr]
_　明明有机会保持男子汉形象的理央才对」[rhp]

[:quadrillion:][riri kao=13 ]
「…………都怪南。不是我的错」[rhp]
[:quadrillion:]
「是那家伙把我变得像女人一样。[rhr]
_　要不是那家伙反复无常……」[rhp]

[off_all]

[:princess:][puri_w kao=6 as=on ]
[font color=0x4682b4]
（克林到底在说什么……？[rhr]
_　自己是人妖这件事都怪南……？怎么回事？）[rhp]
[resetfont]

[off_all]

[:quadrillion:][riri kao=3 ]
「……哈啊！真够受的。让原本的理央恢复后居然被这么说。[rhr]
_　当人妖的时候明明也没少被你说闲话……」[rhp]

[off_all]

[chara_part name="hakase" body=base kao=0 as=off ss=off hh=off hr=on msk=off ]
[chara_show name="hakase" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="riri" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:darknebula:]
「刚才说了『让恢复』对吧」[rhp]

[:quadrillion:]
「！啊……不是」[rhp]

[:darknebula:]
「也就是说现在这个『理央』的状态是刻意为之？」[rhp]
[:darknebula:]
「这倒完全无所谓，但为什么事到如今又改变主意了？[rhr]
_　之前一直维持女性化举止不是都没反抗过吗？」[rhp]
[:darknebula:]
「还是说有什么，让你无法继续保持现状的隐情……」[rhp]

[:quadrillion:][riri kao=2 as=on ]
「这些和博士你没关系―――」[rhp]
[:quadrillion:]
「……嘁、……本来就和你无关！」[rhp]

[:darknebula:][hakase msk=off kao=5 ]
「正因为没关系才这样。毕竟，他连过去的自己都要舍弃。[rhr]
_　昨晚发生了什么……我很好奇，非常」[rhp]

[:quadrillion:]
「…………」[rhp]

[off_all]

[:princess:][puri_w kao=6 as=on ]
[font color=0x4682b4]
（昨晚……虽然觉得不可能，但该不会是因为我的发言吧……[rhr]
_　……不，不会的。根本说不通啦）[rhp]
[:princess:]
（都差点让人揉了胸，这跟不做人妖有什么关系嘛。[rhr]
_　莉莉到底遭遇了什么啊？）[rhp]
[resetfont]

[off_all]

[:kite:][kite kao=3 ]
「…………那家伙真傻。根本没人要求他那么做」[rhp]

[:princess:][puri_w kao=0 ]
「什么意思？」[rhp]

[:kite:][kite kao=12 ]
「……没什么。比起理央在这里，我倒觉得克林更好些」[rhp]

[:princess:]
「…………？？」[rhp]

[:kite:][kite kao=6 ]
「说起来果然还是公主的错吧」[rhp]

[:princess:][puri_w kao=2 as=on ]
「哎。为、为什么啊。怎怎怎、怎么可能啦……」[rhr]
[font color=0x4682b4]
（该、该不会被发现了吧？没被说出去吧？）[rhp]
[resetfont]

[:kite:][kite kao=12 ]
「最好别对他太温柔。[rhr]
_　再这么下去连克林都会喜欢上他」[rhp]

[:princess:][puri_w kao=6 as=on ]
「……啊？」[rhp]

[:kite:][kite kao=3 ]
「就算那样，那家伙其实也挺可怜的。[rhr]
_　基于某个事实，彻底地想要反其道而行」[rhp]
[:kite:]
「他连一丁点儿都不愿和理央有共同点」[rhp]

[:princess:][puri_w kao=0 ]
「……？可他现在自称理央啊。[rhr]
_　话说理央到底是……」[rhp]

[:drop:][drop kao=8 ]
「快斗先生，就在那边」[rhp]

[:kite:][kite kao=7 ]
「好的好的……嘛、总之先顺其自然吧。[rhr]
_　那个别扭鬼可没那么容易搞定」[rhp]

[:princess:][puri_w kao=6 as=on ]
「嗯、嗯……」[rhp]

[off_all]

[:quadrillion:]
「公主」[rhp]

[:princess:][puri_w kao=4 as=on ]
「！」[rhp]

[off_puri]

[::]
交谈之间，夸德里利昂已近在咫尺。[rhr]
完全没注意到的我慌忙抬起头。[rhp]

[:quadrillion:][riri kao=13 ]
「之前一直捉弄你真对不起。很难过吧？[rhr]
_　今后我就是这个铁道成员了，你可以放心了哦」[rhp]

[:princess:][puri_w kao=3 as=on ]
「但那些明明都是博士故意」[rhp]

[:quadrillion:][riri kao=5 ]
「胡说八道。夸德里利昂已经不存在了」[rhp]
[:quadrillion:]
「早点忘记吧？那种男人」[rhp]

[:princess:][puri_w kao=2 as=on ]
「怎么可以……过分！」[rhp]

[:quadrillion:][riri kao=13 ]
「过分的不是我，是夸德里利昂那边……」[rhp]

[:princess:]
「不对！」[rhp]

[:quadrillion:][riri kao=0 as=on ]
「！」[rhp]

[:princess:]
「和我一路旅行的是夸德里利昂啊！[rhr]
_　虽然被说了过分的话还遭捉弄，但在一起真的很开心……！」[rhp]

[:quadrillion:][riri kao=2 as=on ]
「什、什么啊……这话」[rhp]

[:quadrillion:][riri kao=2 as=on ]
「你才莫名其妙，装什么可爱？」[rhp]
[:quadrillion:]
「我只要夸德里利昂。[rhr]
_　理央什么的……才不认识那种人！」[rhp]

[:quadrillion:]
「哈……！？」[rhp]

[off_all]

[chara_part name="hati" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:kite:]
「真敢说啊」[rhp]

[:heartshape:]
「要干架是吧！？尽管放马过来！！」[rhp]

[off_all]

[:princess:][puri_w kao=2 ]
「那么现在，我来模仿夸德里利昂～」[rhp]

[:quadrillion:][riri kao=2 as=on ]
「嗯？」[rhp]

[off_riri]

[:princess:]
「『米、米卡亲的内裤get……！哈啊……哈啊……』」[rhp]


[off_all]

[chara_part name="riri" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="jet" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:quadrillion:]
[font size=28]
「我对内裤没兴趣！！」[rhp]
[resetfont]

[:jet:]
「有过这种场景吗？」[rhp]

[off_all]

[:otiai:][otiai kao=3 ]
「………………」[rhp]

[:vulpecula:][peku kao=5 ]
「落合合～。[rhr]
_　从刚才就一脸可怕地沉默着，没事吧？」[rhp]

[:otiai:][otiai kao=13 ]
「…………嗯。没什么大不了的」[rhp]
[:otiai:]
「不管那是夸德里利昂还是理央都行啦。[rhr]
_　只是肚子饿了，想准备吃早餐而已」[rhp]

[:vulpecula:][peku kao=14 ]
「确实呢！支持落合合～！！」[rhp]

[off_all]

[chara_part name="riri" body=base kao=2 as=on ss=off hh=off hr=on hat=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="drop" body=base kao=13 as=on ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:drop:]
「是啊。在这里争执也没用，[rhr]
_　理央先生似乎也不打算停止扮演呢」[rhp]

[:quadrillion:]
「所以说不是扮演，我就是理央……」[rhp]

[off_all]

[::]
之后以多洛普为中心准备好早餐，[rhr]
我们在难以形容的氛围中结束了用餐。[rhp]

[:princess:]
[font color=0x4682b4]
（唉……接下来会变成怎样呢……）[rhp]
[resetfont]

;****************************************
[fbgm]
[set_xx graphic="rule/krke_r.png" storage="train_03.jpg"]
[bgm storage="bgm_30.ogg"]
;****************************************

3天后[rhp]

[chara_part name="jet" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:]
「哟克林！下次旅行地点决定好了吗！？」[rhp]

[:jet:]
「先问清楚可以避免重复烦恼嘛。[rhr]
_　克林要是已经决定了也告诉我吧」[rhp]

[off_all]

[:quadrillion:][riri kao=2 ]
「………………我说啊」[rhp]

[off_all]

[chara_part name="jet" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="riri" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="736" top="0" wait="true" time=150]

[:quadrillion:]
「能不能适可而止。我是理央！[rhr]
_　名叫克林的人根本不存在于这辆铁道」[rhp]

[:jet:][jet kao=7 ]
「还在说那个啊。真有毅力呢—」[rhp]

[:heartshape:][hati kao=14 ]
「还以为只是早上的即兴发挥呢。[rhr]
_　这份毅力，让我好好学习下吧！」[rhp]

[:quadrillion:][riri kao=6 as=on ]
「不必了……真是麻烦死了」[rhp]

[off_all]

[se storage="door_07.ogg"]

[:princess:][puri_w kao=1 ]
「喂—，哈蒂君你们在吗？[rhr]
_　关于旅行地点的建议，我想了一点……」[rhp]

[:quadrillion:][riri kao=1 ]
「公主！」[rhp]

[:princess:][puri_w kao=2 ]
「呃……」[rhp]

[off_all]

[chara_part name="riri" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=2 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:quadrillion:]
「早上好。该不会是在躲著我吧？[rhr]
_　开玩笑的啦，怎么可能呢」[rhp]

[:princess:][puri_w kao=6 ]
「……啊。理央先生也在啊」[rhp]

[:quadrillion:][riri kao=3 ]
「救救我啊公主。[rhr]
_　这红白组总是克林克林地叫个不停……」[rhp]

[:princess:]
「真是辛苦呢」[rhp]

[:quadrillion:][riri kao=5 ]
「只有你会叫我理央呢。[rhr]
_　一直很感谢你，我很开心哦」[rhp]

[:princess:][puri_w kao=2 ss=on ]
「……………………」[rhp]

[off_all]

[chara_part name="jet" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:]
「你想把理央塑造成什么角色啊？那家伙」[rhp]

[:jet:]
「定位还没确定呢」[rhp]

[off_all]

[:quadrillion:][riri kao=1 ]
「对了公主，今天接下来要做什么？」[rhp]

[:princess:][puri_w kao=6 ]
「房间重新布置」[rhp]

[:quadrillion:][riri kao=14 ]
「不错啊！体力活很累吧？方便的话我也可以帮忙」[rhp]

[:princess:]
「不必了，谢谢」[rhp]

[:quadrillion:][riri kao=5 as=on ]
「别、别这么说嘛。理央可是很靠得住的男人。[rhr]
_　和夸德里利昂不一样」[rhp]

[:princess:]
「不用了！！」[rhp]

[off_all]

[yurasu]
[se storage="door_10.ogg"]
―――！！！！[rhp]

[:quadrillion:][riri kao=2 as=on ]
「啊、等等！！刚来就要走！？」[rhp]

[off_all]

[chara_part name="jet" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:jet:]
「被躲开了呢，克林」[rhp]

[:heartshape:]
「果然那种演技还是别用了吧[rhr]
_　你说自己不是夸德里利昂这种事，根本没人会信」[rhp]

[off_all]

[:quadrillion:][riri kao=2 as=on ]
「啧、烦死了。少对我的事指手画脚」[rhp]
[:quadrillion:][riri kao=3 as=on ]
「……我心里有数。这种事」[rhp]

;****************************************
[set_time storage="train_08.jpg"]
;****************************************

[:princess:][puri_w kao=12 as=on ]
「哈啊……！」[rhp]

[off_all]

[::]
回到自己房间，粗暴地把自己扔进沙发的我。[rhp]
重新布置房间之类的当然是谎话。[rhr]
只是想随便找个借口逃离那个场合。[rhp]
…………夸德里利昂，至今仍坚称自己是理央。[rhr]
实在无法接受这点，现在根本不想和他说话。[rhp]

[:princess:][puri_w kao=3 ]
「…………要一直这样活下去吗」[rhp]

[off_all]

[::]
把曾是夸德里利昂的过去全数抹消。[rhr]
固执地作为理央，扮演那个八面玲珑的老好人……[rhp]

[:princess:][puri_w kao=3 ]
「…………才不要。那样」[rhp]

[off_all]

[::]
就算性格恶劣，就算是个巨乳控也无所谓。[rhr]
要是喜欢胸部的话我会努力做点什么的。[rhp]
想和那时的夸德里利昂说话。[rhr]
想见夸德里利昂。[rhp]

[:princess:][puri_w kao=3 ]
「…………果然做不到。无法放弃」[rhp]
[:princess:]
「我……不知不觉间，竟对克林你……」[rhp]

[off_all]

[se storage="door_15.ogg"]
[:unknown:]
[font color=0x4682b4]
『你好―――！！！』[rhp]
[resetfont]

[:princess:][puri_w kao=4 as=on ]
「！！　哇……！」[rhp]

[off_all]

[se storage="door_15.ogg"]


[:quadrillion:]
[font color=0x4682b4]
『我是理央。请把这儿打开ー！』[rhp]
[resetfont]

[::]
房门被咚咚敲个不停，外面传来那家伙的声音。[rhp]

[:princess:][puri_w kao=2 as=on ]
「哈、哈啊？突然干嘛！快住手！」[rhp]

[off_all]

[se storage="door_15.ogg"]

[:quadrillion:]
[font color=0x4682b4]
『那就请把这儿打开ー！不开就一直闹下去ー！』[rhp]
[resetfont]

[:princess:][puri_w kao=2 as=on ]
「都说住手了！知道了啦！」[rhp]

[off_all]

[::]
比起对理央这个存在本身的厌恶，[rhr]
更让我抗拒的是这副吵闹会招来人围观。[rhp]
来不及思考，我慌忙打开了房门锁，[rhr]
与正在门外喧闹的始作俑者正面相对。[rhp]

[se storage="door_07.ogg"]

[:quadrillion:][riri kao=5 ]
「呀」[rhp]

[:princess:][puri_w kao=2 as=on ]
「你啊……！到底想怎样啦！？」[rhp]

[:quadrillion:]
「不这么做的话你不肯让我进来吧」[rhp]
[:quadrillion:]
「我有话要说。想和公主两个人单独谈」[rhp]

[:princess:]
「………………」[rhp]

[off_all]

[::]
…………一如既往，夸德里利昂依然寄宿在理央体内。[rhp]
虽然其实根本不想看他这般行径……[rhr]
但逃避现状也确实无济于事。[rhp]

[chara_part name="riri" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left=421 top=0 wait="false" time=150]
[chara_part name="puri_w" body=base kao=2 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「……明白了」[rhp]

[:quadrillion:][riri kao=13 ]
「多谢」[rhp]

[:princess:]
「但房间免谈。去观景车厢吧」[rhp]

[:quadrillion:][riri kao=0 ]
「为什么？多麻烦啊」[rhp]

[:princess:]
「现在的你不可信任」[rhp]

[:quadrillion:][riri kao=5 ]
「…………哼。真敢说啊」[rhp]
[:quadrillion:]
「我才没兴趣呢？对你这么贫瘠的身体」[rhp]

[:princess:]
「诶……」[rhp]

[:quadrillion:][riri kao=13 ]
「开玩笑啦。怎样的你都很好？[rhr]
_　这么过分的话，我怎么可能说出口呢」[rhp]
[:quadrillion:][riri kao=5 ]
「又不是夸德里利昂，对吧？」[rhp]

[off_all]

[::]
那张微微含笑的面容里，藏着某种令人怀念的刺痛感。[rhp]
…………真不爽。[rhr]
有资格用那张脸如此微笑的，只有夸德里利昂。[rhp]
可恶。……好想见。[rhp]
不是理央，是夸德里利昂。[rhp]

[:princess:]
「……决定了」[rhp]

[::]
我一定要在这个时刻，把这家伙变回原来的夸德里利昂。[rhp]
然后……好好说出来。[rhr]
我喜欢的，是『夸德里利昂』。[rhp]

暗自立下这番誓言后，我随理央一同朝观景车厢走去―――[rhp]

;****************************************
[set_xx graphic="rule/krke_r.png" storage="train_05.jpg"]
;****************************************

片刻后，我们抵达了观景车厢。[rhp]
平常不太使用这地方，其他人也不怎么进出，[rhr]
想着这里正适合两人交谈才选在此处。[rhp]

[:quadrillion:][riri kao=11 ]
「观景车厢啊。不太熟悉所以感觉挺新奇的」[rhp]

[:princess:][puri_w kao=6 ]
「哦是吗」[rhp]

[:quadrillion:][riri kao=6 ]
「……相当不高兴呢？好可怕啊」[rhp]

[:princess:]
「你以为我心情不好不是因为你？」[rhp]

[:quadrillion:][riri kao=13 ]
「当然知道。但我也无能为力。[rhr]
_　说到底不愿接受理央的你才有问题」[rhp]

[:princess:]
「真是的……！比克林还恶劣，这种态度！」[rhp]

[:quadrillion:][riri kao=5 ]
「诶？……你不用『莉莉』这个名字啦」[rhp]

[:princess:][puri_w kao=0 ]
「！」[rhp]

[:quadrillion:][riri kao=7 ]
「嘛我倒无所谓。反正我是理央」[rhp]

[:princess:][puri_w kao=3 ]
「…………之所以改回称呼……是怕被你讨厌」[rhp]

[:quadrillion:][riri kao=0 ]
「讨厌？为什么？」[rhp]

[:quadrillion:][riri kao=8 as=on ]
「因、因为说了奇怪的话嘛……就、就是聊到胸部话题的时候！」[rhp]
[:princess:]
「就算对方是个变态，说那种话肯定会被当成危险的女人啊。[rhr]
_　所以在被讨厌受伤之前，想着先保持距离……」[rhp]

[:quadrillion:][riri kao=6 as=on ]
「哈、哈啊……这样啊……」[rhp]

[:quadrillion:][riri kao=12 as=on ]
「明明调整好了心情，打算从第二天开始像往常那样相处的。[rhr]
_　可你倒好，突然开始叫什么理央」[rhp]
[:quadrillion:][riri kao=3 as=on ]
「完全搞不懂。这转变也太过火了吧……！」[rhp]

[:quadrillion:]
「啊——」[rhp]

[:princess:]
「理央也好克林也罢，关键是你今后想怎样？[rhr]
_　切换性格开关到底打着什么算盘？」[rhp]
[:princess:]
「不管你出于什么盘算，我还是更喜欢克林。[rhr]
_　所以拜托了。如果坚持叫『理央』是在演戏的话……」[rhp]

[:quadrillion:][riri kao=12 ]
「不是演戏」[rhp]

[:princess:]
「！还要说？适可而止――――――」[rhp]

[:quadrillion:]
「真的啦。……两边都是真实的我」[rhp]

[:princess:]
「哈啊？」[rhp]

[:quadrillion:]
「诚实认真的理央也好，咄咄逼人的夸德里利昂也罢，都是我。」[rhr]
_　这并不是双重人格之类的事情」[rhp]
[:quadrillion:]
「不是演技。两者都是我」[rhp]

[:princess:]
「你、你在说什么……？」[rhp]

[fbgm]

[:quadrillion:]
「…………明白了。那我就直说吧。[rhr]
_　为什么我要摘下夸德里利昂的面具」[rhp]

[off_all]

[::]
说完这番话后，他稍作停顿，凝视着这边。[rhp]

[bgm storage="bgm_08.ogg"]

[:quadrillion:][riri kao=2 ]
「我不想爱上你」[rhp]

[:princess:][puri_w kao=2 as=on ]
「…………！」[rhp]

[off_all]

[::]
这突如其来的话语让我大脑一片空白。[rhr]
为什么要说这种话？　我做了什么……？[rhp]

[:quadrillion:][riri kao=3 ]
「你没有错。这是我个人的问题」[rhp]
[:quadrillion:]
「理央爱上的人，[rhr]
_　夸德里利昂就不能去爱」[rhp]

[:princess:][puri_w kao=2 as=on ]
「等、等等。但我今天才刚认识理央啊？[rhr]
_　素未谋面的人怎么会喜欢上我？」[rhp]

[:quadrillion:]
「不能说。因为南的魔法在生效」[rhp]

[:princess:]
[font color=0x4682b4]
（……！也就是说，这跟我的过去有关？）[rhp]
[resetfont]

[:quadrillion:]
「我希望你喜欢的是理央而非夸德里利昂。[rhr]
_　只要理央存在，夸德里利昂就不能爱你」[rhp]
[:quadrillion:]
「如果你愿意放弃，我可以变回夸德里利昂」[rhp]

[:princess:]
「啊……？」[rhp]

[:quadrillion:]
「你想留在身边的，是夸德里利昂而非理央对吧？」[rhp]
[:quadrillion:]
「即便不是作为恋人也一样。[rhr]
_　比起就这样再也见不到，现在这样不是更好吗？」[rhp]

[off_all]

[::]
他这样说着，眼神是至今未见的认真。[rhp]
我几乎完全无法理解他的话。[rhr]
明明声称两者是同一个人，语气却分明像在谈论外人。[rhp]
我顶着混乱的头脑挤出话语。[rhp]

[:princess:][puri_w kao=3 ]
「……为什么要说这种话？[rhr]
_　为什么不能成为恋人？」[rhp]

[:quadrillion:][riri kao=3 ]
「没办法啊。要选择其中一个，[rhr]
_　就必须放弃另一个。理央一直都是这样活过来的」[rhp]
[:quadrillion:]
「……夸德里利昂也是」[rhp]

[:princess:][puri_w kao=3 ]
「所以我不懂！用我能理解的方式说明啊！」[rhp]

[:quadrillion:]
「那是……在南的限制解除前很难解释」[rhp]

[:princess:][puri_w kao=2 ]
「那我也一样！[rhr]
_　只要南的限制还在，我就不会中你的计！」[rhp]

[:quadrillion:][riri kao=4 as=on ]
「！」[rhp]

[:princess:][puri_w kao=2 ]
「不管你说什么，这都是我的决定」[rhp]
[:princess:]
「果然我，还是喜欢克林……喜欢莉莉。这份心意绝不放弃。[rhr]
_　无论你说什么，继续喜欢都是我的自由！」[rhp]

[:quadrillion:][riri kao=2 as=on ]
「………………、布兹」[rhp]

[:princess:][puri_w kao=6 ss=on ]
「哈？」[rhp]

[:quadrillion:][riri kao=2 as=on ]
「！！　啊、不对」[rhp]

[:princess:]
「回来了！刚刚！[rhr]
_　虽然这时候喊布兹太荒唐，但真的回来了！？」[rhp]

[:quadrillion:]
「不、不是。这不是称呼是感想啦」[rhp]

[:princess:]
「这样更糟糕了好吗！！！」[rhp]

[:quadrillion:]
「唔呃……」[rhp]

[off_all]

[::]
理央语塞的脸扭曲了起来。[rhp]
保持了一阵欲言又止的状态后，[rhr]
理央一边深深叹息一边唰啦唰啦地抓着脑袋。[rhp]

[:quadrillion:]
「……啧！　啊啊真是的！！」[rhp]

[::]
混杂着焦躁的咂舌声响起。[rhr]
这态度与其说是理央，倒不如说是……[rhp]

[yurasu]

[:quadrillion:][riri kao=2 ]
「说布兹是丑八怪有什么不对啦！！　这个丑八怪！！」[rhp]

[:princess:][puri_w kao=0 as=on ]
「克、克林……是你吗！？」[rhp]

[:quadrillion:][riri kao=6 ]
「不是说过要叫我莉莉吗！　库索布斯！」[rhp]

[:princess:]
「啊啊啊……！　是真的！」[rhp]

[:quadrillion:]
「嘁……！　两边都是真的吧。人家忍辱负重演了这么大场戏[rhr]
_  全都让你给搅黄了！ 你要怎么负责啊！」[rhp]

[:princess:][puri_w kao=3 as=on ]
「呜咽……莉莉……！」[rhp]

[:quadrillion:][riri kao=6 ]
「哼！　哭什么哭。恶心死了」[rhp]

[:princess:]
「真是的……！　你知道我有多担心吗？[rhr]
_  我还以为、还以为被莉莉讨厌了……！」[rhp]

[:quadrillion:]
「不是说过了吗。都是你的错」[rhp]
[:quadrillion:]
「……全都是，因为你喜欢上我的错」[rhp]

[:princess:][puri_w kao=2 as=on ]
「诶……为、为什么突然说这个」[rhp]

[:quadrillion:]
「刚才不是你自己说的吗」[rhp]

[:princess:][puri_w kao=6 as=on hh=on ]
「………………原゛来゛如゛此゛」[rhp]

[:quadrillion:][riri kao=3 ]
「……我绝对不会选择和理央同样的东西。这就是这样的我」[rhr]
_　因为想念着的你实在太悲惨了，所以我才会演这出戏让你放弃」[rhp]
[:quadrillion:][riri kao=12 ]
「……这次的事就说到这里。这样可以吗？」[rhp]

[:princess:][puri_w kao=3 as=on ]
「…………、为什么莉莉不再当理央了？」[rhp]
[:princess:]
「理央究竟是谁？」[rhp]

[:quadrillion:][riri kao=3 ]
「………这和要不要停止没有关系」[rhp]
[:quadrillion:]
「………………理央是住在那个世界的另一个『我』」[rhp]
「就是你原先所在的现世中活着的那个我」[rhp]

[:princess:][puri_w kao=4 as=on ]
「！」[rhp]

[:quadrillion:]
「事先声明……」[rhp]
[:quadrillion:]
「…………遗憾的是，我才是冒牌货」[rhp]

[:princess:][puri_w kao=2 as=on ]
「冒、冒牌货是指……」[rhp]

[off_all]

;****************************************
;スチル
[still storage="cg/a_08_r_1.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/a_08_r_1.png"]
;****************************************

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:quadrillion:]
「…………我最讨厌理央了」[rhp]

[:princess:]
「！」[rhp]

[:quadrillion:]
「不久前的我总是烦恼着[rhr]
想要摆脱『理央』、想要改变」[rhp]

[:princess:]
「那为什么今天……」[rhp]

[:quadrillion:]
「…………夏日祭的时候。[rhr]
_　我向你提起过失忆前的公主的事对吧」[rhp]
[:quadrillion:]
「『以前』的你和现在的你一样要强、[rhr]
_　对谁都很温柔……但和你不同的是，她从来不会犯错」[rhp]
[:quadrillion:]
「每次看到迷茫的我，那孩子都会说」[rhp]
[:quadrillion:]
「『不必在意过去。[rhr]
_　就算不勉强改变，你们都是我最宝贵的朋友』」[rhp]
[:quadrillion:]
「不是这样的。明明我想改变。[rhr]
_　那孩子的话是对的，就像解不开的诅咒般……太可怕了」[rhp]
[:quadrillion:]
「……因为你会喜欢上我，[rhr]
_　我就不得不想起『理央』的事」[rhp]

[:princess:]
「……、……」[rhp]

[:quadrillion:]
「……我呢，并不讨厌你」[rhp]
[:quadrillion:]
「但也不能就此承认这是恋爱。[rhr]
_　因为这样的发展……和爱上『理央』时一模一样」[rhp]
[:quadrillion:]
「我不是讨厌你。是讨厌『和理央一样』的状况啊」[rhp]

[:princess:]
「『原来……是这样」[rhp]

[:quadrillion:]
「问过夜了吗？这里其实并非彼世，[rhr]
_　而是夹在彼世与此世之间的、微不足道的世界」[rhp]
[:quadrillion:]
「如果你和理央结合，我猜你一定会离开这个世界吧。[rhr]
_　为了重获新生，这次一定要和理央获得幸福」[rhp]
[:quadrillion:]
「本打算你下车后我就恢复成原来的自己。[rhr]
_　一直忍耐着，硬着头皮扮演着根本不情愿的理央」[rhp]

[:princess:]
「下车是指，这辆电车吗？」[rhp]

[::]
夸德里利昂微微颔首。[rhp]

;****************************************
[bg storage="cg/a_08_r_1b.png" width="1280" height="720" time=500]
[cg storage="cg/a_08_r_1b.png"]
;****************************************

随后――――――她温柔地、像是放弃般笑了。[rhp]

[:quadrillion:]
「……我呢。比起爱上你这件事，[rhr]
_　优先选择了保持自我」[rhp]
[:quadrillion:]
「你迷恋上的男人，比想象中更差劲。[rhr]
_　这下明白理央的可贵了吧？」[rhp]
[:quadrillion:]
「来尽管来吧，尽情幻灭吧―――」[rhp]

[:quadrillion:]

;****************************************
[se storage="body_07.ogg"]
[bg storage="cg/a_08_r_2.png" width="1280" height="720" time=500]
[cg storage="cg/a_08_r_2.png"]
;****************************************

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:quadrillion:]
「――――――！」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------


[::]
话未说完，我便抓住莉莉的后颈，[rhr]
用力拽向自己。[rhp]
眼前自虐般的表情瞬间转为惊愕。[rhp]

[:princess:]
「『公主』她！从未喜欢过其他人！[rhr]
_　不要喋喋不休地挖坟和陌生人的关系」[rhp]
[:princess:]
「我……我喜欢的是夸德里利昂。[rhr]
_　不是理央，是此刻站在这里的你！」[rhp]

[:quadrillion:]
「………………你啊」[rhp]

[:princess:]
「你根本不需要放弃什么。既然我不认识理央，[rhr]
_　你也没有必要在意理央」[rhp]
[:princess:]
「无论过去的我怎样，无论理央的心情如何……[rhr]
_　我想留在身边的，只有夸德里利昂而已！」[rhp]

[:quadrillion:]
「………………」[rhp]

;****************************************
#
[bg storage="cg/a_08_r_2b.png" width="1280" height="720" time=500]
[cg storage="cg/a_08_r_2b.png"]
;****************************************

[:quadrillion:]
「……我……」[rhp]
[:quadrillion:]
「…………我可以忘记理央吗？」[rhp]

[:princess:]
「可以。我允许」[rhp]

[:quadrillion:]
「你当真愿意？……真的……？」[rhp]
[:quadrillion:]
「…………等全部想起来时，不会后悔吗？[rhr]
_　你不会抛弃我选择理央吧？」[rhp]

[:princess:]
「莉莉你是怎么想的？不是想要忘记理央的事吗？」[rhp]

[:quadrillion:]
「…………不知道」[rhp]
[:quadrillion:]
「……我虽然讨厌理央。[rhr]
_　但也不是不明白理央的心情」[rhp]
[:quadrillion:]
「理央他……虽然是个懦弱卑鄙的家伙。[rhr]
_　即便如此也相应地，吃了不少苦头……」[rhp]
[:quadrillion:]
「……虽然想忘记，却无法割舍。[rhr]
_　因为那家伙就是我自己啊」[rhp]
[:quadrillion:]
「如果我都不管那孩子了，还有谁会站在她那边？」[rhp]

[:princess:]
「这样啊……原来你也一直在痛苦挣扎着。[rhr]
_　我在不了解的情况下擅自否定理央的事，对不起」[rhp]
[:princess:]
「虽然还是无法想起关于理央的事，但我想去了解。[rhr]
_　了解之后我肯定会选择现在的莉莉，而不是理央哦」[rhp]


;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:quadrillion:]
「………！」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------


[:princess:]
「无论想起什么都会喜欢莉莉。这份心意我觉得不会改变」[rhp]
[:princess:]
「所以啊。你想怎么做，按莉莉喜欢的来就好。[rhr]
_　无论何时我都会支持能让莉莉幸福的选择」[rhp]

[:quadrillion:]
「…………太狡猾了。真的」[rhp]

;****************************************
#
[bg storage="cg/a_08_r_2c.png" width="1280" height="720" time=500]
[cg storage="cg/a_08_r_2c.png"]
;****************************************

[:quadrillion:]
「………………」[rhp]
[:quadrillion:]
「…………你这人可真是老好人呢」[rhp]

[:princess:]
「是、是吗……我觉得很普通啊」[rhp]

[:quadrillion:]
「这方面倒是和『以前』一样呢……」[rhp]
[:quadrillion:]
「…………不过、或许就是这样的地方吧」[rhp]

[:princess:]
「？」[rhp]

[:quadrillion:]
「这种耿直的性格、我并不讨厌哦」[rhp]
[:quadrillion:]
「无论是我也好、理央也好」[rhp]

[:princess:]
「诶……！『我也好』是什么意思」[rhp]

[:quadrillion:]
「这样啊。……你、该不会是喜欢上我了吧」[rhp]

[:princess:]
「……！……是啊。不行吗？」[rhp]

[:quadrillion:]
「既然说到这个份上、那就娶了你吧」[rhp]
[:quadrillion:]
「把人变成布兹专属对象、可得负责到底哦」[rhp]

[:princess:]
「哼……！莉莉明明可以直说的。[rhr]
_　从刚才开始就用『不讨厌』含糊其辞、其实……」[rhp]

[:quadrillion:]
「喜欢哦。公主」[rhp]

[:princess:]
「呜……！啊」[rhp]

[:quadrillion:]
「我、喜欢公主。不是理央的意志、是我自己的选择」[rhp]
[:quadrillion:]
「永远都不要认错人。无论发生什么、无论到什么时候」[rhp]
[:quadrillion:]
「…………谢谢你选择了『我』」[rhp]

[:princess:]
「……真是的。坦诚得太迟了吧」[rhp]
[:princess:]
「总觉得温柔的莉莉有点恶心……倒也不坏」[rhp]

[:quadrillion:]
「说什么呢。呵呵……」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
;スチル終了
[still_end frame="win.png" storage="train_05.jpg" time=100]
;****************************************

[:quadrillion:][riri kao=6 ]
「确实」[rhp]

[off_all]

[se storage="hand_06.ogg"]
[yurasu]

[:princess:][puri_w kao=2 as=on ]
「呜哇！！」[rhp]

[off_all]

[::]
突然被松开手臂的反作用力让我失去平衡、向后倒去。[rhp]
揉着屁股站起身、[rhr]
我瞪向那个摆着臭脸的死娘娘腔。[rhp]

[chara_part name="riri" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=2 as=on ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「喂！！突然发什么神经！？」[rhp]

[:quadrillion:]
「这种反应真不像你。还是算了吧」[rhp]

[:princess:][puri_w kao=6 as=on ]
[font color=0x4682b4]
（笨、笨到要放弃也太夸张了吧。[rhr]
_明明刚才气氛那么好……！）[rhp]
[resetfont]

[off_all]

[::]
这人真是别扭得要命。[rhr]
普通发展到这地步温柔到底又不会怎样……！[rhp]

[chara_part name="riri" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=3 as=on ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「……话说回来，我完全算不上巨乳吧……」[rhp]

[:quadrillion:]
「哈？」[rhp]

[:princess:]
「ＡＡ……」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:quadrillion:][riri kao=11 ]
「……呵，傻瓜。本小姐中意的是野生巨乳。[rhr]
_要是随时能摆在手边，价值可就要打对折了」[rhp]
[:quadrillion:]
「本小姐又不是冲着胸才选上你的。[rhr]
_你根本不用在意这种事，保持原样就好」[rhp]
[:quadrillion:]
「罗马巨乳非一日建成嘛」[rhp]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

[:princess:][puri_w kao=13 ]
[font color=0x4682b4]
（虽然被漂亮话带过去有点火大，但能获得认可就好……！）[rhp]
[resetfont]

[:quadrillion:][riri kao=5 ]
「好啦。既然决定了就该正式亮相咯」[rhp]

[:princess:][puri_w kao=0 ]
「亮相？亮什么相？」[rhp]

[:quadrillion:][riri kao=14 ]
「蠢问题。本小姐既然得到了公主殿下，还能亮什么？[rhr]
_要亮相的不是理央，是这辆夸德里利昂啊！」[rhp]

[:princess:][puri_w kao=14 hh=on ]
「……哈？你果然还是这么离谱」[rhp]

[:quadrillion:][riri kao=5 ]
「能被这种离谱家伙迷恋上，你也够可以了」[rhp]
[:quadrillion:]
「…………哼，反正不会让你后悔就是了」[rhp]

[off_all]

;****************************************
[set_b storage="train_03.jpg"]
;****************************************

[::]
夸德里利昂带着我离开观景车厢后，把所有人都召集到了餐车。[rhp]
然后以只在偷看巨乳时才会露出的鲜活表情，[rhr]
得意洋洋地讲述起不再玩扮演理央游戏的事，以及和我的关系。[rhp]
但……正常送上祝福的只有多洛普、哈蒂君、博士和佩奇，[rhr]
杰特君放声大笑，快斗根本不听自顾自睡觉，简直为所欲为。[rhp]
夸德里利昂虽然闹着别扭，但看起来又有些满足。[rhr]
我欣喜于这般情景，由衷感谢他恢复成平日的模样。[rhp]

[:otiai:][otiai kao=0 ]
「……………………」[rhp]

[off_all]

[:princess:][puri_w kao=1 ]
「啊，落合君」[rhp]

[::]
在这次聚会中不知为何始终安静的他。[rhr]
虽本就不算多话之人，但今天似乎格外沉默。[rhp]
怎么办……要主动搭话吗？[rhp]

[:quadrillion:][riri kao=1 ]
「喂落合，怎么了？安静得反常呢」[rhp]

[off_all]

[:otiai:][otiai kao=0 ]
「……夸德里利昂」[rhp]

[off_all]

[::]
在我开口前，心情愉悦的莉莉先搭了话。[rhp]
既然没有插话的理由，便静静观察两人的互动。[rhp]

[chara_part name="riri" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="otiai" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:otiai:]
「………………」[rhp]

[:quadrillion:]
「怎么了。有事？」[rhp]

[:otiai:]
「…………想说声恭喜」[rhp]

[:quadrillion:][riri kao=5 ]
「哎呀谢谢。贺礼要给丰厚些哦」[rhp]

[:otiai:]
「是是」[rhp]
[:otiai:][otiai kao=7 ]
「……最初虽然感觉违和。但现在已[rhr]
_　反而觉得吵闹的氛围更让人安心，真是不可思议」[rhp]

[:quadrillion:][riri kao=1 ]
「虽然很感激你这么说，但在这条铁道上就别提理央的事了。[rhr]
_　现在和你说话的是夸德里利昂」[rhp]

[:otiai:][otiai kao=1 ]
「…………是啊」[rhp]
[:otiai:]
「那我也回房间了」[rhp]

[:quadrillion:][riri kao=0 ]
「哎呀这就走？睡觉前要好好刷牙哦」[rhp]

[:otiai:][otiai kao=12 ]
「知道啦……晚安」[rhp]

[off_all]

[::]
落合君简短告别后转身离去，脚步匆匆地消失在餐车。[rhp]
总觉得他显得有些无精打采……是我的错觉吗？[rhp]

;-----------------------------------------------------------
;-----------------------------------------------------------

[jump storage="ev_a_08.ks" target="*start"]

;-----------------------------------------------------------
;-----------------------------------------------------------

*start2

;-----------------------------------------------------------
;-----------------------------------------------------------

;****************************************
[set_b storage="train_03.jpg"]
;****************************************

―――次日清晨[rhp]

[bgm storage="bgm_19.ogg"]

[chara_part name="jet" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:hutago:]
「哈！？」[rhr]
「哈！？」[rhp]

[off_all]

[:otiai:][otiai kao=12 ]
「承蒙您一直以来的照顾」[rhp]

[:princess:][puri_w kao=3 as=on ]
「落、落合君……！这是什么意思？[rhr]
_　突然说要离开铁道……！」[rhp]

[:otiai:]
「没什么特别的意思。昨晚想了想。[rhr]
_　我觉得是时候离开这里了」[rhp]

[off_all]

[chara_part name="drop" body=base kao=6 as=off ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="kite" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:kite:]
「那家伙……？明明当初是自己要来的吧？」[rhp]

[:drop:]
「………………落合，为什么」[rhp]

[off_all]

[:otiai:][otiai kao=12 ]
「虽然发生了很多事……不过还算开心吧」[rhp]
[:otiai:]
「一直以来承蒙关照。[rhr]
_　对已死之人说这些可能有点奇怪……总之，保重」[rhp]

[off_all]

[::]
依旧是不苟言笑却郑重其事的告别。[rhr]
面对似乎毫不留恋离别的他，我震惊得合不拢嘴。[rhp]

[chara_part name="otiai" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="peku" body=base kao=8 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:vulpecula:]
「不要不要啊～！分别来得太早啦！[rhr]
_　我和小落的UNO还没分出胜负呢！」[rhp]

[:otiai:]
「抱歉。有机会再玩吧……」[rhp]

[off_all]

[chara_part name="otiai" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="drop" body=base kao=3 as=on ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:drop:]
「……真的可以吗？」[rhp]

[:otiai:]
「没问题的。别担心，我还打算再来这里」[rhp]

[:drop:][drop kao=13 ]
「……这样啊。随时欢迎您」[rhp]

[:otiai:][otiai kao=1 ]
「嗯」[rhp]
[otiai kao=7 ]
「那，就到这里吧。不用特意送行」[rhp]

[:drop:][drop kao=1 ]
「需要指定下车地点吗？有要求都可以满足」[rhp]

[:otiai:]
「无所谓」[rhp]

[:drop:][drop kao=1 ]
「不过难得的机会……」[rhp]

[off_all]

[::]
说着落合君横穿过我们面前走向某处。[rhp]
正疑惑地观察着情况，[rhr]
他理所当然地打开了行驶中严禁开启的出入口门扉。[rhp]

[chara_part name="drop" body=base kao=2 as=on ss=off hh=off hr=on hat=on ]
[chara_show name="drop" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="puri_w" body=base kao=2 as=on ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「！？为什么！？」[rhp]

[:drop:]
「你应该不会使用魔法才对！可竟然―――」[rhp]

[off_all]

[:otiai:][otiai kao=12 ]
「不是我的魔法。我的赞助人，很擅长察言观色」[rhp]

[off_all]

[:princess:][puri_w kao=2 as=on ]
「落合君的赞助人……？」[rhp]

[off_all]

[::]
落合君没有回答我的疑问。[rhp]
在这高空打开门，他究竟意欲何为。[rhp]
……有种不祥的预感。[rhp]

;****************************************
[bg storage="train_13.jpg" time=500]
;****************************************

落合君露出了挑衅的笑容。[rhp]

[:heartshape:]
「那就，再见」[rhp]

[::]
门外便是无限延伸的银河之海。[rhp]
背靠漆黑夜空中无数星辰，他就这样将重心向后―――[rhp]

[:princess:]
「！！等等……！」[rhp]

;****************************************
[::]
[bg storage="sky_11.jpg" time=500]
;****************************************

等一下。[rhp]
话音未落，落合君便消失了。[rhr]
如同倾倒般坠入了星之海。[rhp]
……不知因何觉得可笑，甚至浮现出淡淡微笑。[rhp]

;****************************************
[bg storage="train_13.jpg" time=500]
;****************************************

我奔向了他坠落的那扇门，探出身子。[rhp]

[:princess:]
「落合君！！」[rhp]

[:quadrillion:]
「喂！太危险了，快退后」[rhp]

[off_all]

[::]
试图从下车口探出身子的我，[rhr]
被夸德里利昂拽着手臂阻止。[rhp]

;****************************************
[bg_rule storage="train_03.jpg" rule="004.png" time=1000]
;****************************************

[:quadrillion:][riri kao=6 as=on ]
「这里不是真正的宇宙。那家伙应该没事」[rhp]

[:princess:][puri_w kao=2 as=on ]
「可是！」[rhp]

[off_riri]

[:drop:][drop kao=0 ]
「公主。我理解您担心的心情，[rhr]
_但夸德里利昂说得没错」[rhp]
[:drop:]
「这个世界由魔法构成。即便坠落也不会丧命。[rhr]
_他所说的『赞助人』正观望着，会将他拉回现实世界」[rhp]
[:drop:]
「…………若我的猜测正确，那定是糠星夜」[rhp]

[:princess:]
「夜……」[rhp]

[:drop:][drop kao=13 ]
「我认为可以相信他」[rhp]

[off_drop]

[:princess:][puri_w kao=3 as=on ]
「………………」[rhp]

[:quadrillion:][riri kao=6 ]
「……这样就好了。[rhr]
_终究长久滞留于此并非好事」[rhp]
[:quadrillion:]
「因为那家伙不是还活着嘛。[rhr]
_　既然如此不如早点回去不是更好」[rhp]

[:princess:]
「……嗯……」[rhp]

[off_all]

[::]
就算是这样道别也……太令人难过了。[rhp]
只顾着自己把想说的话说完，[rhr]
我们连好好说声再见都做不到不是吗。[rhp]

;****************************************
[bg storage="train_13.jpg" time=500]
;****************************************

我恋恋不舍地再次将脸探出车窗，凝视着广袤的银河。[rhp]

[:princess:]
「……落合君……」[rhp]

[::]
你真的觉得，这样的结局就可以了吗？[rhp]
如此空虚，如此仓促的离别。[rhp]

[:princess:]
[font color=0x4682b4]
（……我是不是总有一天，也会像落合君这样从这里……）[rhp]
[resetfont]

[::]
……是因为刚才看到了落合君的缘故吧。[rhr]
又或是因为，在这条铁道上有了重要的人。[rhp]
虽然确实已经约定好要离开这个地方……[rhp]
……我真的能遵守和夜的约定吗。[rhp]
曾经的信心正逐渐消融在黑暗中，[rhr]
我感受到某种难以名状的不安。[rhp]

;****************************************
[se storage="door_08.ogg"]
[bg storage="black.jpg" time=500]
;****************************************

仿佛要抗拒这种感觉般，我关上了玻璃窗。[rhp]

;-----------------------------------------------------------
;-----------------------------------------------------------
[jump storage="ev_a_08.ks" target="*start3"]
;-----------------------------------------------------------
;-----------------------------------------------------------

*start3

;クリリン前半エンドフラグ
[eval exp="sf.a_r_end = 1"]

[mask time=2000]
[cancelskip]
[fbgm]

[iscript]
delete f.ev_a_02;
delete f.ev_a_03;
delete f.ev_a_04;
delete f.ev_a_05;
delete f.ev_a_06;
delete f.ev_a_07;
[endscript]

;フラグ初期設定
[iscript]
f.love_d = 0
f.love_k = 0
f.love_r = 0
f.love_h = 0
[endscript]

[jump storage="title.ks" target="*start_end"]

[s]