﻿
*start

;--------------------------------------------------------------------------------------------
;▼フルボイスセット▼
;クォードリリオン
[voconfig sebuf=1 name=riri vostorage="riri/full/{number}.ogg"  number=77]

;--------------------------------------------------------------------------------------------

[:princess:][puri_w kao=0 ]
「………………。是克林么」[rhp]

[off_all]

[::]
倒也不是在意或者说不是那种感情。[rhr]
不过确实希望能和夸德里利昂关系再好一些。[rhp]
想借此机会拉近距离，[rhr]
希望以后能进行些没有挖苦与嘲讽的轻松对话。[rhp]
夸德里利昂虽然性格恶劣，[rhr]
但很会打扮，化妆技术也好，值得尊敬。[rhp]
要是能正常聊这些话题，旅途应该会更有趣。[rhp]

[:princess:][puri_w kao=3 ]
「……要怎样才能让对方喜欢我呢」[rhp]
[:princess:]
「………………」[rhp]
[:princess:][puri_w kao=14 as=on hh=on ]
「……――――！！　不不不不！[rhr]
_　刚刚那个绝对不是那种意思啦！」[rhp]

[off_all]

[::]
对着空气自言自语地辩解，像要甩开念头般猛摇头。[rhp]
因为这绝不是不纯的动机。[rhr]
纯粹是作为朋友相处，仅此而已！[rhp]

[:princess:][puri_w kao=2 as=on hh=on ]
「好……好吧！既然决定了就马上去邀请吧」[rhp]

[off_all]

[::]
重新鼓起干劲，我朝着克林的所在处走去。[rhp]

;****************************************
[set_00 storage="train_03.jpg"]
;****************************************

[:quadrillion:][p_r_25][riri  kao=6 ]
「不要」[rhp]

[:princess:][puri_w  kao=2 as=on ss=on ]
「完全没有接话的余地……」[rhp]

[:quadrillion:]
「为什么非得陪你看孩子直到祭典当天。[rhr]
_　小鬼就该和小鬼玩过家家去」[rhp]

[:princess:][puri_w  kao=6 ]
「只、只是结伴逛逛而已啦！？　克林你总不会[rhr]
_　打算独自行动吧！？　当个跟屁虫也行啊！」[rhp]

[:quadrillion:][p_r_29]
「你既没有自尊心也没有底线呢……[rhr]
_　不，或许你正在试图变成后者」[rhp]

[:princess:][puri_w  kao=2 as=on ]
「虽、虽然是这样……但对女孩子……！」 
[:quadrillion:][riri  kao=11 ]
「而且很遗憾。不巧我根本没打算和任何人结伴。[rhr]
_　今天可是要举办重要的巨乳观察大会呢」[rhp]

[:princess:]
「一个人？」[rhp]

[:quadrillion:][p_r_15]
「集体行动会让巨乳产生戒备啦。[rhr]
_　要想在巨乳毫无察觉的情况下观察，果然还是单独行动最合适哦」[rhp]
[:quadrillion:]
「所以说，并非针对你，我本来就不打算和任何人同行。[rhr]
_　真遗憾呢。好了，去别处碰运气吧」[rhp]

[:princess:]
「在海边不是帮你搞过偷拍吗？那这次也配合下嘛！」[rhp]

[:quadrillion:][riri  kao=6 ]
「那只是看你闲得发慌才让你当助手的。[rhr]
_　现在的你，可是打着和我共祭典的主意呢」[rhp]
[:quadrillion:]
「享受祭典就享受不到巨乳……[rhr]
_　巨乳本就是充满矛盾的生物啊」[rhp]

[:princess:][puri_w  kao=6 ]
「我也可以帮你搭讪。这样总行了吧！？」[rhp]

[:quadrillion:][p_r_26][riri  kao=2 as=on hh=on ]
「！？什……！荒唐！[rhr]
_　向巨乳搭讪什么的，这种……！简直不自量力」[rhp]

[:princess:][puri_w  kao=2 as=on ]
「说什么呢？」[rhp]

[:quadrillion:][riri  kao=6 hh=on ]
「…………咳咳。话说具体要怎样搭讪呢？」[rhp]

;-----------------------------------------------------------------------------------------------
;【見境なしに】
[glink clickse="btn_01.ogg" x="290" y="160" width="610" high="72" text="「そりゃもう見境なしに」" target="*sntk_a" graphic="glink_c.png" enterimg="glink_d.png"]
;【見定めるよ】
[glink clickse="btn_01.ogg" x="290" y="290" width="610" high="72" text="「じっくり相手を見定めるよ」" target="*sntk_b" graphic="glink_a.png" enterimg="glink_b.png"]
[s]
;-----------------------------------------------------------------------------------------------

*sntk_a

[:princess:][puri_w  kao=5 as=on ]
「那个啊……当然是见一个搭讪一个啦」[rhp]

[:quadrillion:][p_r_09][riri  kao=2 ]
「大胸也是有性格的。[rhr]
_　有被搭讪就开心的家伙，也有厌恶的家伙……」[rhp]

[:princess:][puri_w  kao=2 ]
「但我觉得……歧视大胸是不对的」[rhp]
[:princess:][puri_w  kao=13 ]
「各有各的好。我想成为能爱任何胸部的自己」[rhp]

[:quadrillion:][riri  kao=0 as=on ]
「！！　你、你……」[rhp]
[:quadrillion:][riri  kao=0 as=on ]
「……哼。你总算明白了呢。稍微对你改观了」[rhp]

[:princess:][puri_w  kao=14 as=on ]
「哈哈哈……」[rhp]
[:princess:][puri_w  kao=2 ss=on as=on ]
[font color=0x4682b4]
（这不是嫉妒……！！如果说大胸是个性，飞机场也是个性！！[rhr]
_　我要用风平浪静的心境面对大胸啊，我……！！）[rhp]
[resetfont]

[:quadrillion:][p_r_03][riri  kao=13 ]
「唔确实……搭讪或许也不错呢。[rhr]
_　能合法且自然地拍摄到正面全景的大胸」[rhp]

[jump target="*tutti2"]

;-----------------------------------------------------------------------------------------------
*sntk_b

[:princess:][puri_w  kao=5]
「当然会考虑克林的喜好，精挑细选大胸来搭讪啦」[rhp]

[:quadrillion:][p_r_31][riri  kao=12 ]
「哪有什么喜好。[rhr]
_　大胸本身就是崇高存在，每一个都值得感恩」[rhp]

[:princess:][puri_w  kao=2 as=on ss=on ]
「……………………」[rhp]

[:quadrillion:][riri  kao=6 ]
「够了，飞机场就去和菜刀说话吧」[rhp]

[:princess:][puri_w  kao=6 as=on ]
「哧……！哼。那克林就是菜刀咯？[rhr]
_　每次都说话扎心，可吵吵闹闹总在一起呢」[rhp]

[:quadrillion:][p_r_08][riri  kao=14 ]
「说得真漂亮！　聪明的男人很帅气对吧？」[rhp]
[:quadrillion:][riri  kao=2 ]
「拿走5块坐垫」[rhp]

[:princess:][puri_w  kao=2 as=on]
[font color=0x4682b4]
（被扣分了！）[rhp]
[resetfont]

[:quadrillion:][riri  kao=13 ]
「不过嘛……搭讪或许也不坏呢。[rhr]
_　能合法且自然地拍摄到正面全景的大胸」[rhp]

[jump target="*tutti2"]

;-----------------------------------------------------------------------------------------------

*tutti2

[:princess:][puri_w  kao=2 ]
[font color=0x4682b4]
（原来有意识到这是违法的啊）[rhp]
[resetfont]

[:quadrillion:][p_r_15]
「中意你了。今晚的祭典，陪你一会儿也不是不行哦」[rhp]

[:princess:][puri_w  kao=14 hh=on ]
「真的？　谢谢！[rhr]
_　我一定会好好担任助手的！」[rhp]

[:quadrillion:]
「不错嘛助手。就保持这个干劲」[rhp]

[:princess:][puri_w  kao=13 as=on hh=on ]
「啊……顺便问一下……[rhr]
_　作为帮忙的报酬，能不能陪我逛夜市排队什么的……」[rhp]

[:quadrillion:][p_r_04][riri  kao=0 ]
「………………。你，带相机了吗？」[rhp]

[:princess:][puri_w  kao=2 ]
「我会拜托多洛普准备的！」[rhp]

[:quadrillion:][riri  kao=11 ]
「很好。值得考虑」[rhp]

[:princess:][puri_w  kao=5 hh=on ]
「非常感谢！！」[rhp]

[:quadrillion:][riri  kao=1 ]
「那就现在告诉我三围吧」[rhp]

[:princess:][puri_w  kao=0 ]
「诶？」[rhp]

[:quadrillion:][p_r_31][riri  kao=13 ]
「难得夏日祭典，想着给你们准备浴衣。[rhr]
_　准备逐个问大家的，就从你开始量吧」[rhp]

[:princess:][puri_w  kao=4 as=on ]
「浴衣……」[rhp]

[:quadrillion:][riri  kao=6 as=on ]
「……你该不会打算就这身打扮去吧」[rhp]

[:princess:][puri_w  kao=0 as=on ]
「哎，不行吗？」[rhp]

[:quadrillion:][p_r_10][riri  kao=2 ss=on ]
「开―――什么玩笑！！当然不行啊这个布兹！[rhr]
_　入乡不随俗，你是瞧不起旅行吗！？！」[rhp]

[:princess:][puri_w  kao=6 as=on ]
「对、对不起（？）。但是没穿过，也不知道合不合适」[rhp]

[:quadrillion:][riri  kao=2 ]
「哼。笨蛋。那种东西肯定适合你啊」[rhp]
[:quadrillion:]
「你以为是谁在给你挑选。是这位夸德里利昂大人哟」[rhp]

[:princess:][puri_w  kao=0 ]
「……！」[rhp]

[:quadrillion:]
「嘛 其他家伙都太没眼光了，[rhr]
_　相对来说我眼光最顶尖而已啦……」[rhp]

[:princess:][puri_w  kao=13 ]
「噗噗。确实」[rhp]

[:quadrillion:][p_r_26][riri  kao=2 ]
「给我闭嘴！！！」[rhp]
[:quadrillion:]
「……哼 再说了 你今晚是要和我一起走的对吧。[rhr]
_　那就更不能在外表上偷工减料了！」[rhp]

[:princess:][puri_w  kao=0 ]
「诶……」[rhp]

[:quadrillion:][riri  kao=6 ]
「给我做个配得上站在我身边的女人。[rhr]
_　……多少会帮帮你啦」[rhp]

[:princess:][puri_w  kao=4 as=on hh=on ]
「……哼！！！　可……！」[rhp]

[off_all]

[se storage="body_07.ogg"]
[yurasu]

[:princess:]
[font size=30]
「克林～～～～！！！」[rhp]
[resetfont]

[fse]

[:quadrillion:][p_r_09][riri  kao=2 as=on ]
「哇！别、别抱过来啊。热死人的布兹！」[rhp]

[:princess:][puri_w  kao=8 hh=on ]
「克林真是的 太爱害羞了！[rhr]
_　还以为你只是个色鬼 原来真的有在为我着想呢！」[rhp]

[:quadrillion:]
「都说没害羞了……喂 既然都答应你了，[rhr]
_　就赶紧去别的地方吧。待会儿见」[rhp]

[:princess:][puri_w  kao=0 ]
「？　三围已经量好了吗？」[rhp]

[:quadrillion:][p_r_24][riri  kao=6 ]
「嗯。刚才那样大概就知道了」[rhp]

[:princess:]
「哈？　刚才那样」[rhp]

[:quadrillion:][riri  kao=12 ]
「就算把洗衣板贴上来 也根本不算什么福利嘛」[rhp]

[:princess:][puri_w  kao=2 as=on hh=on ]
「…………―――――！！！」[rhp]

[off_all]

[se storage="hand_06.ogg"]
[yurasu]

[:quadrillion:][p_r_21]
「痛死啦！！！！　你干什么啊臭布兹！！」[rhp]

[:princess:]
「果然就是个色狼！！　这个变态！！」[rhp]


[off_all]

;****************************************
[fbgm]
[filter_n]
[set_xx graphic="rule/krke_r.png" storage="sky_07.jpg"]
;****************************************

[::]
银河铁道在数小时后抵达了目标星球。[rhp]
我们换上夸德里利昂挑选准备的浴衣，[rhr]
终于踏上了那片土地。[rhp]

;****************************************
[bg storage="fes_01.jpg" time=1000]
[bgm storage="bgm_26.ogg"]
;****************************************

列车停靠在一处稍高的位置，[rhr]
面对着通往宽阔神社的漫长石阶。[rhp]

「夏日祭之星」永远沉浸在傍晚时分的氛围中，[rhr]
慵懒的闷热感令人联想到初夏。[rhp]
鲜红的灯笼将微暗的夜色明亮地映照，[rhr]
台阶上方传来太鼓和笛子的乐声，空气中飘荡着独特的甜香。[rhp]

尚未目睹的景象让心跳加速，[rhr]
迫不及待想快点跑上这段台阶。[rhp]

[chara_part name="jet" body=yukata kao=5 as=off ss=off hh=on hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=yukata kao=5 as=off ss=off hh=on hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:][p_h_14]
「这、这就是……！夏日祭典！太厉害了！」[rhp]

[:jet:][p_j_14]
「明明只看见灯笼和台阶就已经兴奋起来了！」[rhp]

[off_all]

[chara_part name="riri" body=yukata kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="kite" body=yukata kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:quadrillion:][p_r_14]
「哎呀哎呀，所以小鬼头就是这样的嘛。[rhr]
_　外面稍微热闹点就高兴成这样」[rhp]

[:kite:][p_k_14]
「说这话的克林不是也新买了相机？干劲十足啊」[rhp]

[:quadrillion:][p_r_27][riri body=yukata kao=14 ]
「讨厌～～被发现啦！？没错！这是专为夜间拍摄准备的，」[rhp]

[:kite:][kite body=yukata kao=6 ]
「啊，没关系的」[rhp]

[off_all]

[:drop:][p_d_04][drop kao=1 ]
「那么各位，烟花大会预定在18点半左右开始，[rhr]
_　请大家在那之前稍微提早些到广场集合哦」[rhp]

[:vulpecula:][peku body=yukata kao=13 ]
「好呀！看烟花的时候要一起喊『玉屋～～』才开心呢！」[rhp]

[:drop:][drop kao=13 ]
「嗯。这段时间各位可以自由活动，请好好享受。[rhr]
_　我会留在车里进行检修」[rhp]

[off_all]

[:princess:][puri_w body=yukata kao=6 as=on ]
「诶……！多洛普你不去玩吗？[rhr]
_　检修什么的很无聊吧」[rhp]

[:drop:][p_d_02][drop kao=13 ]
「这些事总得有人来做。[rhr]
_　而且对我来说车内检修也是非常快乐的事，请放心」[rhp]
[:drop:]
「虽算不上补偿，但很期待你们的旅行见闻！[rhr]
_　每次听大家讲述经历，我都非常开心」[rhp]

[:princess:][puri_w body=yukata kao=6 as=on ]
「但是……」[rhp]

[:quadrillion:][riri body=yukata kao=6 ]
「那家伙一直都是那样啦。别管他」[rhp]
[:quadrillion:]
「我们的人生信条就是随心所欲做喜欢的事。[rhr]
_　玩不玩全看本人意愿。我们可没资格指手画脚」[rhp]

[:drop:]
「就是这个道理」[rhp]

[:princess:][puri_w body=yukata kao=3 as=on ]
「……明、明白了……」[rhp]

[off_all]

[::]
以多洛普的话语为开端，众人各自散开行动。[rhp]

[chara_part name="otiai" body=yukata kao=4 as=on ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="hati" body=yukata kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:heartshape:][p_h_06]
「听说夏日祭典上有个连小孩都能打的射击摊啊！！[rhr]
_　走吧落合！！！」[rhp]

[:otiai:][p_so_10][otiai body=yukata kao=2 as=on ]
「啊？　啊喂、等等……！　别、别擅自！　而且那是打靶游戏，」[rhp]

[:heartshape:][hati body=yukata kao=14 ]
「三人来打淘汰赛吧！　输的人要扫一周厕所！」[rhp]

[off_all]

[:jet:][p_j_16][jet body=yukata kao=5 ]
「那可真不能输啊……[rhr]
_　落合要是弃权的话，不战而胜我也无所谓？」[rhp]

[:otiai:][otiai body=yukata kao=2 as=on ]
「～～～～我奉陪。比就比啊！」[rhp]

[off_all]

[:princess:][puri_w kao=13 ]
[font color=0x4682b4]
（嘿嘿，看来落合君也能玩得开心真是太好了）[rhp]
[resetfont]

[off_all]

[chara_part name="peku" body=yukata kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="peku" layer="1" width="571" height="720" left="152" top="0" wait="false" time=150]
[chara_part name="kite" body=yukata kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="kite" layer="1" width="514" height="720" left="606" top="0" wait="true" time=150]

[:vulpecula:][p_vl_04]
「呐快斗！　快斗接下来要做什么？　要跟谁一起逛吗？」[rhp]

[:kite:][p_k_02][kite body=yukata kao=12 ]
「嗯～，也没特别的事。[rhr]
_　随便吃点东西，找个地方睡觉吧……」[rhp]

[:vulpecula:][peku body=yukata kao=5 ]
「那和佩奇他们去鬼屋吧！？」[rhp]

[:kite:][kite body=yukata kao=6 as=on ]
「鬼屋？」[rhp]

[:vulpecula:][p_vl_24][peku body=yukata kao=14 ]
「之前在海边说好要浮潜，结果最后没一起玩对吧！？[rhr]
_　今天要和博库我们一起玩哦？　好不好！？」[rhp]

[:kite:]
「不不那完全是两码事―――」[rhp]

[:vulpecula:][peku body=yukata kao=8 as=on ]
[font size=25]
「我说我说我说～！！　求～你～啦！[rhr]
_　三～个～人～一～起～去～嘛～～～！！」[rhp]
[resetfont]

[off_all]

[:darknebula:][p_da_13][hakase body=yukata kao=5 ]
「我也完全赞成！[rhr]
_　真想看看呢，那个铁面具会扭曲成什么样子……」[rhp]

[:vulpecula:][peku body=yukata kao=6 ]
「才～不～是～啦博士！　快斗绝对不怕这种的！[rhr]
_　因为我们可能会哭出来，所以要快斗来保护我们对吧！」[rhp]

[:darknebula:][hakase body=yukata kao=2 ss=on as=on ]
「"们"！？　我才不会哭……才不会……，……」[rhp]
[:darknebula:]
[font size=26]
「拜托你了！！」[rhp]
[resetfont]

[off_all]

[:kite:][kite body=yukata kao=6 as=on ss=on ]
「…………。我放弃抵抗了ー」[rhp]

[off_all]

[:heartshape:][hati body=yukata kao=14 ]
「好嘞，干劲十足！　走着弟兄们！　可别跟丢老子……」[rhp]
[:heartshape:][hati body=yukata kao=2 as=on ][p_h_10]
「咦等等！？　杰特人呢！？」[rhp]

[off_all]

[chara_part name="jet" body=yukata kao=5 as=o as=on ss=off hh=off hr=on ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="otiai" body=yukata kao=6 as=o as=on ss=off hh=off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:jet:][p_j_02]
「这边哈蒂。那边只有临时厕所」[rhp]

[:otiai:]
「在这种细节上意外真实啊……」[rhp]

[off_all]

[:vulpecula:][p_vl_04][peku body=yukata kao=14 hh=on ]
「快点快点ー！　我们快走吧博士、快斗！[rhr]
_　再不抓紧店铺就逛不完啦！」[rhp]

[:darknebula:][p_da_31][hakase body=yukata kao=5 ]
「喂喂、乱跑很危险的佩奇」[rhp]

[off_all]

[:darknebula:][hakase body=yukata kao=1 ]
「…………哎」[rhp]

[off_all]

[::]
博士将视线转向这边。[rhr]
啪嗒地对上目光后，他轻快地眨了眨眼。[rhp]
虽然没有发出声音，[rhr]
但能从唇形看出他在说『加油！』[rhp]

[:princess:][puri_w body=yukata kao=0+++* ]
「…………」[rhp]

[off_all]

[::]
虽然不是因为受到鼓励——我悄悄偷瞄身旁的夸德里利昂。[rhp]

[:quadrillion:][p_r_09][riri body=yukata kao=6 ]
「？　干嘛啦」[rhp]

[:princess:][puri_w body=yukata kao=7 hh=on as=on ]
「……没、没什么」[rhp]

[:quadrillion:][riri body=yukata kao=5 ]
「哎哟～？　该不会是因为我帅得让你害羞了吧？」[rhp]

[:princess:]
「…………………………」[rhp]

[:quadrillion:][p_r_16][riri body=yukata kao=2 as=on ]
「讨厌，被说中了」[rhp]

[:princess:][puri_w body=yukata kao=2 hh=on as=on ]
「才不是！　快点，我们也该走啦！」[rhp]

[:quadrillion:][riri body=yukata kao=6 ]
「知道啦……真是的」[rhp]
[:quadrillion:][riri body=yukata kao=5 ]
「…………、…………」[rhp]

[off_all]

[:quadrillion:]
「嘿，公主」[rhp]

[:princess:][puri_w body=yukata kao=0 ]
「什么？」[rhp]

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
[vostart]
;--------------------------------------------------------------------------------------------

[:quadrillion:][riri body=yukata kao=13 ]
「那件浴衣 很配你哦」[rhp]

[:princess:][puri_w body=yukata kao=2 as=on hh=on ]
「―――！！　什！！　突然说什么呢！？」[rhp]

[:quadrillion:][riri body=yukata kao=5 hh=on ]
「太好了……心跳加速的 不只有我一个人呢」[rhp]

[:princess:]
「！？　我、我？　说谁！？　突然好可怕―――」[rhp]

[:quadrillion:][riri body=yukata kao=6 ]
「开玩笑的啦」[rhp]

[:princess:][puri_w body=yukata kao=6 as=on ]
「哈？」[rhp]

[:quadrillion:][riri body=yukata kao=5 ]
「啊哈哈哈！　丑八怪脸红啦～[rhr]
_　像猴子一样可爱呢～」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[off_all]

[se storage="hand_06.ogg"]
[yurasu]

[:quadrillion:]
「住口！！！！」[rhp]

[::]
我立刻朝对方屁股狠狠回旋踢了一脚。[rhp]

[:princess:][puri_w body=yukata kao=2 as=on ss=on ]
「你不是要去找巨乳吗！[rhr]
_　别管我这块平板 赶快走啊！！」[rhp]

[:quadrillion:][p_r_10][riri body=yukata kao=2 as=on ss=on ]
「这、这家伙怎么回事～……！？　把别人屁股当拳击沙袋！[rhr]
_　丑女稍微打扮一下就得意忘形 少嚣张了！」[rhp]

[:princess:]
「吵死了！　巨乳妖怪死宅！」[rhp]

[off_all]

[:drop:][p_d_31][drop kao=14 ]
「呵呵。你们还是这么要好呢」[rhp]

[off_all]

[chara_part name="riri" body=yukata kao=2 as=off ss=on hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="puri_w" body=yukata kao=2 as=on ss=on hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]
[:2nin:]
「才没有！！」[rhr]
「才没有！！」[rhp]

[off_all]

[:drop:][drop kao=14 as=on ss=on]
「……请、请慢慢欣赏……我先行……」[rhp]

;****************************************
[set_xx graphic="rule/krke_q.png" storage="fes_02.jpg"]
;****************************************

[:quadrillion:][riri body=yukata kao=3 ]
「……………………」[rhp]

[:princess:][puri_w body=yukata kao=0 ]
「克林 怎么了？ 周围明明这么多巨乳。[rhr]
_　和海边不同 看不到乳沟很伤心吗？」[rhp]

[:quadrillion:][p_r_10][riri body=yukata kao=6 ]
「我说啊……乳沟不是看到就好。[rhr]
_　被腰带托起的巨乳 有着泳装没有的风韵……」[rhp]
[:quadrillion:]
「…………、……不没什么。感觉有点麻烦……」[rhp]

[:princess:][puri_w body=yukata kao=6 ]
「话说回来 现在还不能主动搭讪吗？[rhr]
_　明明有这么多显眼的巨乳 却总是『稍等一下』」[rhp]

[:quadrillion:][riri body=yukata kao=2 ]
「吵死了……[rhr]
_　巨乳本来就是应该远远静观并加以保护的存在啊」[rhp]
[:quadrillion:]
「居然将其当作狩猎对象[rhr]
_　该说是下流呢 还是卑劣呢……」[rhp]

[:princess:]
「你其实是想光明正大地合法拍摄巨乳吧？」[rhp]

[:quadrillion:][p_r_11][riri body=yukata kao=3 ]
「都怪你让我起了这种念头才跟着起哄[rhr]
_　现在突然清醒过来了 该说是重拾矜持吧」[rhp]
[:quadrillion:]
「要不还是偷拍吧？」[rhp]

[:princess:][puri_w body=yukata kao=2 ]
「这选项也太极端了……才不要！」[rhp]

[:quadrillion:][riri body=yukata kao=6 ]
「………………。那算了 到此为止吧」[rhp]

[:princess:][puri_w body=yukata kao=0 ]
「咦 不拍了？ 放弃巨乳了？」[rhp]

[:quadrillion:][p_r_24][riri body=yukata kao=12 ]
「嗯～今天不知怎地提不起兴致……」[rhp]
[:quadrillion:][riri body=yukata kao=0 ]
「……………………」[rhp]

[:princess:][puri_w body=yukata kao=2 ]
「……？　干嘛。一直盯着看……」[rhp]

[:quadrillion:][riri body=yukata kao=0 ]
「……刚才虽然开玩笑 其实你穿浴衣很合适。[rhr]
_　毕竟是本小姐选的 理所当然就是了」[rhp]
[:quadrillion:][riri body=yukata kao=11 ]
「说起来浴衣和服这种东西 比起巨乳还是平板身材更相称。[rhr]
_　用裹胸布压平再穿哦。虽然你不需要这么做就是了」[rhp]
[:quadrillion:]
「因为你今天装扮得还挺像样，所以巨乳都不显眼了」[rhp]

[:princess:][puri_w body=yukata kao=4 as=on ]
「……………………」[rhp]

[off_all]

[::]
这算是在夸我吗？还是在损我？[rhp]
但今天的夸德里利昂确实和往常不同，即便用余光瞥见擦肩而过的巨乳，[rhr]
也没有像平时那样露出『大饱眼福』的陶醉表情。[rhp]

[:princess:][puri_w body=yukata kao=1 ]
「嘿嘿……是不是对我稍稍改观了？」[rhp]

[:quadrillion:][riri body=yukata kao=1 ]
「一点点。像胎毛那样的程度」[rhp]

[:princess:][puri_w body=yukata kao=2 ]
「那以后不再说挖苦话了？」[rhp]

[:quadrillion:][riri body=yukata kao=13 ]
「没戏」[rhp]

[:princess:][puri_w body=yukata kao=6 as=on ]
「这样啊……」[rhp]

[off_all]

[::]
…………唉。结果还是老样子。[rhr]
浴衣虽然受到称赞，但关键的内在评价依然如故……[rhp]
…………到底要怎样才能让克林喜欢上我呢。[rhp]

[:quadrillion:][p_r_15][riri body=yukata kao=5 ]
「―――好了！[rhr]
_　既然欣赏不了巨乳，今晚就按普通方式玩吧！」[rhp]

[:princess:][puri_w body=yukata kao=4 as=on ]
「咦！可、可那是巨乳观察的报酬啊」[rhp]

[:quadrillion:][riri body=yukata kao=5 ]
「我只做自己想做的事。[rhr]
_　既然如此就把夜市小吃挨个征服吧」[rhp]
[:quadrillion:][riri body=yukata kao=14 ]
「幸亏有个胖朋友。剩饭处理就拜托啦」[rhp]

[:princess:][puri_w body=yukata kao=6 as=on ]
「胖！？明明是丑……」[rhp]
[:princess:][puri_w body=yukata kao=2 ss=on as=on ]
[yurasu]
[font size=26]
「才不丑！！」[rhp]
[resetfont]

[:quadrillion:][p_r_18][riri body=yukata kao=6 as=on ]
「一个人玩得挺开心嘛」[rhp]

[:princess:]
[font color=0x4682b4]
（啊，好险……！[rhr]
_　差点就坦然接受了……！）[rhp]
[resetfont]

[:quadrillion:][riri body=yukata kao=7 ]
「…………嘛、今天的你至少不算布兹啦。[rhr]
_　那件浴衣，意外地合身呢」[rhp]

[:princess:][puri_w body=yukata kao=0 hh=on ]
「！　哎……啊、谢谢」[rhp]

[:quadrillion:][p_r_31][riri body=yukata kao=13 ]
「像相扑力士一样帅气哦」[rhp]

[off_all]

[yurasu]
[se storage="hand_06.ogg"]

[::]
瞬间，瞄准克林若隐若现的白皙小腿，[rhr]
再度送上凌厉的扫堂腿。[rhp]

[:quadrillion:][riri body=yukata kao=2 as=on ss=on ]
「～～～～！！　啊、你呀……！　干什么啦……！！」[rhp]

[:princess:][puri_w body=yukata kao=2 as=on ]
「被这套路骗过多少次了……！[rhr]
_　我自己都觉得丢脸啦！」[rhp]
[:princess:]
「喂！看招克林！　你能跟得上力士的胃口吗？[rhr]
_　软弱的娘娘腔可能办不到呢～～！ 瞧！我可要丢下你啦！！」[rhp]

[:quadrillion:]
「这个布兹……！啊好啦！要干架是吧！」[rhp]

[off_all]

[::]
就这样，兜兜转转开始了心心念念的夜市巡游。[rhp]
和想象中的有点……不、应该说相当不同，[rhr]
但是，比想象中快乐得多。[rhp]
能邀请夸德里利昂来，真是太好了。[rhp]

;****************************************
[fbgm]
[set_time storage="fes_05.jpg"]
[bgm storage="bgm_07.ogg"]
;****************************************

[::]
逛遍夜市后，我们决定稍早些[rhr]
前往作为集合地点的广场。[rhp]
……本来是这么打算的……。[rhp]

[chara_part name="riri" body=yukata kao=2 as=on ss=on hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="puri_w" body=yukata kao=2 as=on ss=on hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「刚、刚才的玛塔酱章鱼烧……[rhr]
_　绝对比我多吃了一个啦……」[rhp]

[:quadrillion:]
「哈、哈……！你、你后半程根本就没好好计数吧……！[rhr]
_　这场比试无效，无效……！」[rhp]

[off_all]

[::]
食物已经塞到快要突破胃袋容量的极限。[rhr]
相当不妙。稍微受点刺激就可能引发惨剧。[rhp]
无奈之下，我们决定在距夜市稍远处的[rhr]
无人老旧神社院内坐下，等待情绪平复。[rhp]

[chara_part name="riri" body=yukata kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="puri_w" body=yukata kao=0 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:quadrillion:]
「哈……不过真无聊呢……」[rhp]
[:quadrillion:]
「布兹。随便讲点有趣的事」[rhp]

[:princess:][puri_w body=yukata kao=6 ]
「真是强人所难啊……算了，反正我也闲」[rhp]
[:princess:][puri_w body=yukata kao=14 ]
「……那么！开启向克林随便提问环节～！」[rhp]

[:quadrillion:][riri body=yukata kao=8 as=on ]
「莫名其妙开始了……」[rhp]

[:princess:][puri_w body=yukata kao=1 ]
「提问。为什么当厨子却不做饭？」[rhp]

[:quadrillion:][p_r_02][riri body=yukata kao=2 ]
「因为我根本不是厨子。是被强行安排的」[rhp]

[:princess:]
「原来如此～很有克林风格呢。那下一题」[rhp]

[:quadrillion:][riri body=yukata kao=6 as=on ]
[font color=0x4682b4]
（………………该怎么说……真是浪费时间呢……）[rhp]
[resetfont]

[:princess:][puri_w body=yukata kao=6 ]
「第二问。我觉得自己长相普通，真那么丑？」[rhp]

[:quadrillion:][p_r_01][riri body=yukata kao=12 ]
「丑」[rhp]

[:princess:][puri_w body=yukata kao=2 ss=on ]
「啧！第三问」[rhp]

[:quadrillion:][riri body=yukata kao=2 as=on ]
[font color=0x4682b4]
（照这节奏究竟打算持续多久啊……）[rhp]
[resetfont]

[:princess:][puri_w body=yukata kao=0 ]
「提问。为什么要装人妖？身心都是男的吧？」[rhp]

[:quadrillion:][p_r_30][riri body=yukata kao=6 ]
「……还以为是在开玩笑的气氛，没想到是认真的提问？」[rhp]

[:princess:][puri_w body=yukata kao=2 as=on ]
「那就是说有认真的理由啦！」[rhp]

[:quadrillion:][riri body=yukata kao=2 as=on ]
「～～～～～……、诱导审问什么的太卑鄙了……」[rhp]
[riri body=yukata kao=3 ]
「…………不过也罢。正好有这个机会」[rhp]

[:princess:][puri_w body=yukata kao=4 as=on ]
「……诶，真的要告诉我吗？」[rhp]

[:quadrillion:][p_r_10][riri body=yukata kao=2 ]
「干嘛。不是你想听吗？　真是个麻烦的女人」[rhp]

[:princess:][puri_w body=yukata kao=4 as=on ]
「不、不用。这么敏感的话题，不用勉强」[rhp]

[:quadrillion:][p_r_12]
「才不敏感呢。已经到了不找人倾诉就撑不下去的程度了」[rhp]
[:quadrillion:][riri body=yukata kao=3 ]
「…………但在那个铁道里，找不到能说这种事的人。[rhr]
_　这点上你正好合适。反正不用在意好感度」[rhp]

[:princess:][puri_w body=yukata kao=6 as=on ]
「微妙地有点失礼啊……」[rhp]

[off_all]

[::]
但嘴上这么说，此刻的夸德里利昂却露出前所未有的认真表情。[rhr]
或许有着比我预想中更严肃的理由。[rhp]

[:princess:]
[font color=0x4682b4]
（居然愿意跟我说这种事……）[rhp]
[resetfont]

[::]
无论是否出于偶然，这都意味着信任正在产生吧。[rhr]
这让我有些欣喜，虽然心怀歉疚，仍侧耳倾听。[rhp]

[:quadrillion:][riri body=yukata kao=3 ]
「…………是我认识的人的故事」[rhp]
[:quadrillion:]
「那家伙啊，曾经有过憧憬的女性」[rhp]

[::]
过于突兀的发言让我不禁屏息。[rhp]
在我无言以对时，夸德里利昂继续说了下去。[rhp]

[:quadrillion:][riri body=yukata kao=3 ]
「倒也不是谈恋爱那种感情。[rhr]
_　但一直模模糊糊都定不下来，最后只剩憧憬留下来了」[rhp]
[:quadrillion:]
「好傻啊……还没等心意明确，[rhr]
_　那孩子就从那家伙眼前消失了」[rhp]
[:quadrillion:]
「连告别都没能说出口呢」[rhp]

[:princess:][puri_w body=yukata kao=13 as=on ]
「啊哈哈……！虽然不太明白，但你描述得还真详细啊。[rhr]
_ 该不会不是熟人，而是克林你自己的经历吧？」[rhp]

[:quadrillion:][riri body=yukata kao=3 ]
「………………」[rhp]

[:princess:][puri_w body=yukata kao=2 as=on ]
[font color=0x4682b4]
（……！咦……）[rhp]
[resetfont]

[::]
本来以为他肯定会否认的。[rhr]
为什么他什么都不说呢？[rhp]
…………真奇怪。心里有点乱糟糟的。[rhp]

[:princess:]
「假、假设真是克林的事！按说你肯定会果断告白的。[rhr]
_　看来那位女士门槛实在太高啦。你小子也有可爱之处嘛」[rhp]

[off_all]

;****************************************
;スチル
[still storage="cg/a_07_r_1.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/a_07_r_1.png"]
;****************************************

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:quadrillion:]
「…………是啊」[rhp]

[:princess:]
「―――！」[rhp]

[:quadrillion:]
「……门槛太高了。为什么啊」[rhp]
[:quadrillion:]
「明明那么喜欢你的」[rhp]

[:princess:]
「诶……那、那难道真的是」[rhp]

[:quadrillion:]
「还是说其实你全都明白，故意在试探我？[rhr]
_　想看看我会有什么反应是不是」[rhp]
[:quadrillion:]
「………………坏心眼的女人呢。真是的」[rhp]

[:princess:]
「克、克林……你靠得、太近了吧」[rhp]

[:quadrillion:]
「说谎。『克林？』……才怪。其实不对吧？」[rhp]
[:quadrillion:]
「没关系的。随你喜欢叫」[rhp]
[:quadrillion:]
「…………理央君也好，什么都行」[rhp]

[:princess:]
「诶……」[rhp]

[::]
…………理央？[rhp]

[:princess:]
「……希望我这么称呼你吗？」[rhp]

[:quadrillion:]
「………！　啊……」[rhp]

[:princess:]
「说不定理央这个名字，是过去克林的曾用名呢」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:quadrillion:]
「………………」[rhp]

[:princess:]
「克林？　啊、不对……理央？　……这样、可以吗」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:quadrillion:]
「…………、骗你的啦」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
;スチル終了
[still_end frame="win.png" storage="fes_05.jpg" time=1000]
;****************************************

[::]
这么说着，夸德里利昂从我身上挪开了身体。[rhp]

[:quadrillion:][riri body=yukata kao=2 ]
「……我的名字只有一个。我就只是我自己。[rhr]
_　既不是理央也不是克林。我是夸德里利昂哦」[rhp]
[:quadrillion:]
「…………谁都不是，仅此唯一的呢」[rhp]

[:princess:][puri_w body=yukata kao=0 as=on ]
「………………」[rhp]

[:quadrillion:][riri body=yukata kao=2 ]
「回答我！」[rhp]

[:princess:][puri_w body=yukata kao=2 as=on ]
「啊、在！」[rhp]

[off_all]

[::]
总觉得气氛变得微妙起来。[rhp]
虽然主要怪夸德里利昂，但觉得这样下去不行，[rhr]
拼命转动脑筋想换个话题。[rhp]

[:quadrillion:][riri body=yukata kao=6 ]
「……怎么。我也讲了『有趣的事』了，[rhr]
_　你至少该给点感想吧」[rhp]

[:princess:][puri_w body=yukata kao=3 as=on ]
「呃、那个、那个……」[rhp]
[:princess:][puri_w body=yukata kao=14 as=on ]
「……诶、诶诶！　克林喜欢的人，居然是以前的我！」[rhp]

[:quadrillion:][riri body=yukata kao=0 as=on ]
「！」[rhp]

[:princess:][puri_w body=yukata kao=2 ss=on as=on ]
「！！！」[rhr]
[font color=0x4682b4]
（喂！！　我怎么会说出这么直球的话啊！！！）[rhp]
[resetfont]

[off_all]

[::]
怎么办啊 又变得尴尬起来――――[rhp]

[:quadrillion:][riri body=yukata kao=2 ]
「哈啊゛？」[rhp]

[off_all]

[:princess:][puri_w body=yukata kao=5 as=on ss=on ]
「………………」[rhp]

[off_all]

[::]
…………看来不会变成那样 我松了口气。[rhp]

[:quadrillion:][p_r_25][riri body=yukata kao=2 ]
「我说啊。别说傻话了。[rhr]
_　我不是说过最讨厌你这种人了吗！」[rhp]

[:princess:][puri_w body=yukata kao=2 as=on ]
「刚才明明说过的！　说什么曾经那么喜欢我！！」[rhp]

[:quadrillion:]
「那不是我说的」[rhp]

[:princess:]
「哈啊～～～！？」[rhp]

[:quadrillion:][p_r_29][riri body=yukata kao=12 ]
「刚才只是被气氛带着随口说的。[rhr]
_　根本没有你期待的深层含义 能忘了吗？」[rhp]

[:princess:]
「～～～～……」[rhp]

[:quadrillion:][p_r_19][riri body=yukata kao=2 ]
「……一脸无法接受的表情呢」[rhp]

[:princess:]
「那当然啊！开玩笑也该有个限度吧！」[rhp]
[:princess:]
「怎么回事啊？突然冒出理央这种陌生名字　太奇怪了吧。[rhr]
_　不可能没有含义的 那种话绝对暗藏玄机吧」[rhp]

[:quadrillion:]
「真是个纠缠不休的女人。本人都说不是了 适可而止吧」[rhp]

[:princess:]
「一点也不好！」[rhp]

[:quadrillion:]
「……！干嘛　突然这么严肃」[rhp]

[:princess:]
「……我只是想和你好好相处而已。[rhr]
_　不要总说坏话或是吵架 像普通人那样聊聊天的说」[rhp]
[:princess:]
「可你总是打马虎眼 用可疑的演技捉弄人。[rhr]
_　我已经很认真在烦恼了 太过分了」[rhp]
[:princess:][puri_w body=yukata kao=3 ]
「…………完全搞不懂 你真正的想法啊 克林」[rhp]

[:quadrillion:][riri body=yukata kao=0 as=on ]
「………………」[rhp]

[off_all]

[::]
…………沉默持续了片刻。[rhp]
这次是我制造了凝重的空气。[rhr]
但我无法选择蒙混过关。[rhp]
若此时含糊其辞，总觉得会永远无法与这个人相互理解。[rhr]
这绝对是我无法接受的。[rhp]

[:quadrillion:][riri body=yukata kao=3 ]
「…………真心话什么的根本无所谓」[rhp]
[:quadrillion:]
「但『夸德里利昂』就是我」[rhp]

[:princess:][puri_w body=yukata kao=2 ]
「……？什么意思？」[rhp]

[:quadrillion:]
「没什么。与你无关」[rhp]

[:princess:][puri_w body=yukata kao=3 ]
「啧！还这样说……！」[rhp]

[:quadrillion:][riri body=yukata kao=2 ]
「不过...你说那蹩脚戏码『可疑』这件事」[rhp]
[:quadrillion:][riri body=yukata kao=1 ]
「…………让我很高兴」[rhp]

[:princess:][puri_w body=yukata kao=6 as=on ]
「哈？明明是贬义？」[rhp]

[:quadrillion:][riri body=yukata kao=13 ]
「价值观因人而异。世界上也有被骂反觉欢喜的男人呢」[rhp]

[off_all]

[::]
完全听不懂克林在说什么。[rhr]
从刚才起就这样。克林一直在说着我不了解的事。[rhp]
但唯有一点很明确。[rhr]
克林正因某些我不清楚的缘由而苦恼着。[rhp]
他愿意向我发这些牢骚，至少说明…[rhr]
…………算是信任着我吧？[rhp]

[:princess:]
[font color=0x4682b4]
（…………没关系吧，稍微自我陶醉一下）[rhp]
[resetfont]

[:princess:][puri_w body=yukata kao=6 as=on ]
「那、那个」[rhp]

[:quadrillion:][riri body=yukata kao=0 ]
「什么？」[rhp]

[:princess:]
「就是…虽然我不太明白克林的烦恼」[rhp]
[:princess:]
「克林啊，按照克林自己喜欢的方式去做不就好了吗」[rhp]

[:quadrillion:][p_r_12][riri body=yukata kao=2 ]
「哈……？这种事不用说我也……」[rhp]
[:quadrillion:][riri body=yukata kao=3 ]
「…………、…………不，还是做不到吧」[rhp]

[:princess:][puri_w body=yukata kao=0 ]
「克林……？」[rhp]

[:quadrillion:][riri body=yukata kao=3 ]
「话说回来你这家伙，总是一本正经的样子[rhr]
_　和失去记忆前……当优等生时的你完全没变呢」[rhp]
[:quadrillion:]
「我以前倒不讨厌那样的你……[rhr]
_　唯独这点，始终让我难以适应」[rhp]

[:princess:][puri_w body=yukata kao=0 as=on ]
「这、这样啊……不知道该高兴还是难过」[rhp]

[:quadrillion:][p_r_01][riri body=yukata kao=11 ]
「放心吧。虽这么说，不像的部分才是大多数。[rhr]
_　又蠢又吵，对我的事情完全不了解……」[rhp]
[:quadrillion:][riri body=yukata kao=5 ]
「……这样的地方，我并不讨厌哦」[rhp]

[:princess:][puri_w body=yukata kao=0 ]
「―――！明明不了解我，这样也可以吗？」[rhp]

[:quadrillion:][riri body=yukata kao=11 ]
「我呢。想去一个谁也不认识真实我的世界。[rhr]
_　也许你的存在，会成为第一步呢」[rhp]

[:princess:]
「克林……」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:quadrillion:][riri body=yukata kao=14 ]
「好啦。肚子也轻松了，该去广场了」[rhp]
[:quadrillion:]
「…………、公主！」[rhp]

[off_riri]

[:princess:][puri_w body=yukata kao=4 as=on hh=on ]
「咦！」[rhp]

[off_puri]

[::]
这是第一次被他称作『公主'。[rhr]
不是布兹或者胖子之类的，而是正经的名字。[rhp]
不明白是怎样的心境，他的真心难以捉摸。[rhr]
虽然不明白，但非常开心。[rhp]
不知为何，胸口悄然涌起一阵暖意。[rhp]

[:princess:]
[font color=0x4682b4]
（啊、啊咧……这是什么感觉……）[rhp]
[resetfont]

[::]
那个擅自迈步离去的宽阔背影，[rhr]
此刻不知为何显得比平日更为可靠。[rhp]
最近和克林相处时，我总有些难以言喻的异常。[rhr]
而此刻这种感觉尤为明显。[rhp]
心脏正不受控制地怦怦直跳。[rhp]

[:princess:]
[font color=0x4682b4]
（……开玩笑的吧？难、难道我……）[rhp]
[resetfont]

[::]
…………难道说我喜欢上夸德里利昂了吗？[rhp]

[:princess:][puri_w body=yukata kao=2 as=on hh=on ]
「―――等一下！」[rhp]

[off_puri]

[::]

[:quadrillion:][riri body=yukata kao=4 ]
「诶」[rhp]

[::]
未及细想，我已出声叫住了前方那个即将远去的身影。[rhp]
突然直呼『理央』实在有些羞人，[rhr]
便用了他曾说希望其他人都这么称呼的名字。[rhp]
克林惊讶地转身望来，在几步之遥停住脚步。[rhp]

[off_all]

我低头攥紧浴衣下摆，[rhr]
心跳自方才起就未曾平息。[rhp]

[chara_part name="riri" body=yukata kao=0 as=on ss=off hh=off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" left="383" top="0" wait="false" time=150]
[chara_part name="puri_w" body=yukata kao=1 as=off ss=off hh=off hr=on hat=okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" width=330 height=720 wait="true" zindex="1005" time=150]

[:princess:]
「那、那个…谢谢你和我聊这么多」[rhp]
[:princess:]
「本以为自己失去记忆会给很多人添麻烦。[rhr]
_　但你的话语让我的心情轻松了些」[rhp]
[:princess:][puri_w body=yukata kao=2 as=on hh=on ]
「虽然不认识过去的你…但现在的你…绝对」[rhp]
[:princess:]
「我、我觉得现在的莉莉更让人喜欢！」[rhp]

[:quadrillion:]
「―――――！！」[rhp]

[off_all]

[::]
为了掩饰害羞而拔高的嗓音。连自己都觉得缺乏感情很没出息。[rhr]
现在的克林的眼睛实在没法直视啊……。[rhp]
…………但既然说出口了，就不能退缩。[rhp]
鼓起勇气试着抬起头。[rhp]

;****************************************
[still storage="cg/a_07_r_2.png" rule="021.png" width="1280" height="720" time=1000]
[cg storage="cg/a_07_r_2.png"]
;****************************************

[::]
映入眼帘的是一张呆愣的表情。[rhp]
和之前那个毫无破绽(?)的他完全不同，让我稍微放松了紧绷的肩膀。[rhp]

[:princess:]
「啊！刚才叫你莉莉是因为、那个、你之前叫我公主来着！[rhr]
_　所以我想着也该停止用你讨厌的称呼方式了」[rhp]
[:princess:]
「讨、讨厌……？！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:quadrillion:]
「……………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:princess:]
「怎、怎么可能讨厌啊！？不是你自己一直说要这么叫的吗！？」[rhp]
[:princess:]
「还是说怎样！？米卡亲就可以唯独我不行吗！？[rhr]
_　难道没有胸就连名字都不能自由选择吗！？」[rhp]

[:quadrillion:]
「不、不是……那个……」[rhp]

;****************************************
#
[bg storage="cg/a_07_r_2b.png" width="1280" height="720" time=300]
[cg storage="cg/a_07_r_2b.png"]
;****************************************

[:quadrillion:]
「…………无所谓了，随你便吧……」[rhp]

[:princess:]
「――――！嗯！那我就不客气了！」[rhp]

[:quadrillion:]
「……搞什么啊突然这样……这样会打乱节奏的好吗」[rhp]

[:princess:]
「啊哈哈！脸超红的！！哈哈哈！逊毙――――」[rhp]

;****************************************
;スチル終了
[still_end frame="win.png" storage="fes_05.jpg" time=100]
;****************************************

[off_all]

[se storage="hand_06.ogg"]
[yurasu]
一记猛烈肘击同时粉碎了心窝和暧昧氛围。[rhp]

[:princess:][puri_w body=yukata kao=6 as=on ss=on ]
「咕哇～～～～～……！！对女生你居然……！！」[rhp]

[off_puri]

[:quadrillion:][riri body=yukata kao=2 as=on hh=on ]
「喂！别废话了快走！！布兹！！」[rhp]

[:princess:][puri_w body=yukata kao=2 as=on ss=on ]
「是公主对吧～！？快把人放回来！」[rhp]

[off_all]

[::]
迈着小碎步追赶那毫不客气大步向前的背影。[rhr]
明明惹他生气了，却感受到今日最充实的满足感。[rhp]
关于克林……不，关于莉莉的事情[rhr]
_　肯定还有许多许多未解的谜团。[rhp]
终有一天，我也能成为...[rhr]
能与之无话不谈的朋友吧。[rhp]
…………若要说贪心的话，还想更进一步。[rhp]

;****************************************
[bg storage="sky_07.jpg" time=500]
;****************************************

[:princess:]
「――――好！」[rhp]

[::]
不知为何突然干劲十足！[rhp]

;------------------------------------------------------------------------------------------
;▲フルボイスエンド▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
[free_filter ]
[fbgm]
[s_mask color=0xffffff time=2000]
[set_xx graphic="rule/krke_r.png" storage="train_08.jpg"]
;****************************************

; イベント分岐の解除
[iscript]
delete f.ev_a_07;
[endscript]

[jump storage="ev_a_08_riri.ks" ]

[s]

