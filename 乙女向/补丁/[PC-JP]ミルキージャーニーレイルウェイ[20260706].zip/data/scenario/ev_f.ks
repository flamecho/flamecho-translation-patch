﻿
*start

[fbgm]
[mask color=0xffffff time=3000]

[cm]

[clearfix]
[start_keyconfig]
[loadjs storage="myscript.js"]

;初期設定---------------------------------------------------------------------

;メッセージウィンドウの設定
[position layer="message0" frame="win2.png" left=0 top=520 width=1280 height=200 page=fore visible=true]

; 文字表示領域
[position layer=message0 page=fore margint="65" marginl="420" marginr="60"]

;キャラ名表示領域
[ptext name="chara_name_area" layer="message0" color="0x000000" size=22 align=center bold=true x=420 y=550]

; 立ち絵の設定
[chara_config anim=false ptext="chara_name_area"]

[call storage="character.ks"]
[call storage="voice.ks"]


*start2

;--------------------------------------------------------------------------------------------
;▼フルボイスセット▼

;ソラ
[voconfig sebuf=1 name=sora vostorage="sora/full/{number}.ogg" number=141]
;ジェット
[voconfig sebuf=1 name=jet vostorage="jet/full/{number}.ogg" number=208]
;リオ
[voconfig sebuf=1 name=rio vostorage="rio/full/{number}.ogg" number=3]

;サウス
[voconfig sebuf=1 name=sausu vostorage="sausu/full/{number}.ogg" number=348]
;糠星の夜
[voconfig sebuf=1 name=yoru vostorage="yoru/full/{number}.ogg" number=266]

;タケル
[voconfig sebuf=1 name=take vostorage="take/full/{number}.ogg" number=95]
;ミカちん
[voconfig sebuf=1 name=tiaki vostorage="mika/full/{number}.ogg" number=233]

; ３人組は冒頭同時なので直後から

;--------------------------------------------------------------------------------------------

;--------------------------------------------------------------------------------------------
;▼フルボイススタート▼
[vostart]
;--------------------------------------------------------------------------------------------

;****************************************
[fbgm]
; 背景表示
[bg storage="white.jpg" time=100]
; 全部のフィルターを打ち消す
[free_filter ]
; ウィンドゥの設定
[position layer="message0" frame="win2.png" left=0 top=520 width=1280 height=200 page=fore visible=true ]

[layopt layer=message0 visible=true]
[plugin name="menu_plugin"]
[showmenubutton]
[s_mask_off time=3000]

[bgm storage="bgm_12.ogg"]
;****************************************

[:sausu:]
「――――――约尔大人说的没错」[rhp]

[:sausu:]
「我从一开始就错了」[rhp]
[:sausu:]
「嘴上说着为了大家，[rhr]
_　其实是因独自寂寞，才创造了那个铁路世界」[rhp]

;****************************************
#
[bg storage="sky_12.jpg" time=1000]
;****************************************

[:sausu:]
「最初还好。大家都很开心。[rhr]
_　……我想我早已麻木了」[rhp]
[:sausu:]
「我轻看了杰特的心意和宙的思念。[rhr]
_　让他们的心灵患病，实在深感愧疚」[rhp]
[:sausu:]
「我执念于博士的死亡，[rhr]
_　不断用这种方式麻痹自己的不甘」[rhp]
[:sausu:]
「身为实现愿望的存在，真正该做的[rhr]
_　本不该是将他们禁锢在梦里」[rhp]
[:sausu:]
「为了崭新的未来，为了消弭恐惧，[rhr]
_　本应始终陪伴你们身旁才对」[rhp]
[:sausu:]
「……所谓的心灵寄托就是这样的东西」[rhp]
[:sausu:]
「这么简单的道理，若能早些明白该多好」[rhp]
[:sausu:]
「如果从一开始就这么做，[rhr]
_　我最后…是否就能和博士说上话了呢……」[rhp]

;****************************************
#
[bg storage="black.jpg" time=1000]
;****************************************

[:yoru:]
「…………回应他人期待真是件难事」[rhp]
[:yoru:]
「这方面我倒轻松，但你应该很辛苦吧」[rhp]
[:yoru:]
「正如其名，背负着千种愿望。[rhr]
_　……我虽比你强大，但作为神明你定然位阶更高」[rhp]
[:yoru:]
「坦白说，我无法揣度你的心思」[rhp]

;****************************************
#
[bg storage="sky_07.jpg" time=1000]
;****************************************

[:yoru:]
「……但即便如此，你的行径也不可饶恕」[rhp]
[:yoru:]
「并非实现愿望才是幸福。[rhr]
_　万事如意的世界并非理想」[rhp]
[:yoru:]
「真正的幸福，本就不该用单一尺度衡量」[rhp]
[:yoru:]
「傲慢即是罪孽。……望你也谨记于心」[rhp]
[:yoru:]
「…………因此」[rhp]

;****************************************
#
[bg storage="hsps_02a.jpg" time=2000]
;****************************************

[:yoru:][yoru kao=12 ]
「――――――往后要学会依赖他人」[rhp]

[off_all]

[:sausu:][sausu kao=3 as=on ]
「约尔大人……」[rhp]

[off_all]

[:unknown:][s_playse storage="nusi/full/87.ogg" buf=1]
「可不只约尔先生哦！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------


[off_all]

;３人組登場

[chara_part name="mata" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="80" top="0" wait="false" time="150"]
[chara_part name="nusi" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="383" top="0" wait="false" time="150"]
[chara_part name="gon" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="720" top="0" wait="true" time="150"]

[:3nin:]

[s_playse storage="nusi/full/88.ogg" buf=1]
[s_playse storage="mata/full/137.ogg" buf=2]
[s_playse storage="gon/full/83.ogg" buf=3]

「久等了！」[rhr]
「久等了！」[rhr]
「久等了！」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
;ヌシ
[voconfig sebuf=1 name=nusi vostorage="nusi/full/{number}.ogg" number=89]
;魔太郎子
[voconfig sebuf=1 name=mata vostorage="mata/full/{number}.ogg" number=138]
;ゴンザレス一億世
[voconfig sebuf=1 name=gon vostorage="gon/full/{number}.ogg" number=84]
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[:yoru:][yoru kao=12 ]
「没在等」[rhp]

[:nusi:][nusi kao=1 ]
「又来了又来了，说这种话。[rhr]
_　我们可是专程从主楼来庆贺你归队的，高兴点嘛」[rhp]

[:yoru:][yoru kao=2 ]
「…………啧」[rhp]

[off_all]

[chara_part name="mata" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:mataroko:]
「主楼情况如何？有比魔太郎子更可爱的玩偶吗？」[rhp]

[:yoru:][yoru kao=12 ]
「没有」[rhp]

[off_mata]
[chara_part name="gon" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="152" top="0" wait="true" time=150]

[:gonzalez:]
「有比我更帅的怪兽吗？」[rhp]

[:yoru:]
「有」[rhp]

[:gonzalez:][gon kao=6 as=on ]
「还真有啊！！」[rhp]

[off_all]

[:sausu:][sausu kao=3 as=on ]
「大、大家……」[rhp]

[:mataroko:][mata kao=2 ]
「…………南先生！我已听闻铁道事件的始末」[rhp]

[:sausu:]
「啊、嗯……让你担心了……」[rhp]

[:mataroko:]
「…………、嘛虽然有很多想法。总之先这样吧」[rhp]
[:mataroko:]
「你的心意，我非常ー同意！」[rhp]

[:sausu:][sausu kao=4 as=on ]
「……诶」[rhp]

[:mataroko:][mata kao=13 ]
「想让大家都幸福……！这不是很棒的心愿吗！[rhr]
_　请务必让我们今后也继续协助您！」[rhp]

[:sausu:][sausu kao=0 ]
「可、可是。这些都只是我一厢情愿……」[rhp]

[:gonzalez:][gon kao=1 ]
「如果独自一人确实如此。但现在已经不用担心啦」[rhp]
[:gonzalez:]
「从今往后我们会四个人当你的后盾！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:sausu:][sausu kao=4 as=on ]
「……！」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:gonzalez:][gon kao=6 ]
「喂！我们本来就是同伴吧。[rhr]
_　敌对的只有糠星那位大叔不是么」[rhp]

[:mataroko:][mata kao=1 ]
「Neo・同伴的意思啦。加上约尔大人会战力升级哟」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:sausu:][sausu kao=2 as=on ]
「………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------


[off_all]

[chara_part name="nusi" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:nusi:]
「哎呀呀，高兴得合不拢嘴了吗？[rhr]
_　这反应真让人开心啊」[rhp]
[:nusi:]
「嘛这么说吧。不如趁现在组建个付丧神同盟，[rhr]
_　把这家临终关怀院办得越来越红火吧！」[rhp]

[:yoru:][yoru kao=7 ]
「这似乎不是该追求热闹的设施吧……」[rhp]

[:nusi:][nusi kao=2 as=on ]
「不是那个意思啦！[rhr]
_　你这家伙总爱揪人话柄的老毛病！」[rhp]
[:nusi:][nusi kao=6 ]
「真是。偶尔也该给前辈留点面子吧？」[rhp]

[:yoru:][yoru kao=12 ]
「我拒绝」[rhp]

[off_all]

[chara_part name="mata" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="gon" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:gonzalez:]
「咦？前辈？」[rhp]

[:mataroko:]
「哎呀小刚不知道吗？努西大人从临终关怀院成立时[rhr]
_　马上就能找到破旧……咳咳，是资历深厚的玩偶来着……」[rhp]
[:mataroko:][mata kao=11 ]
「约尔大人是在那一个月后到来的绘画呀。[rhr]
_　所以努西大人才是我们当中最伟大的存在！」[rhp]

[off_all]

[chara_part name="nusi" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:yoru:]
「属于误差范围。不会影响等级秩序」[rhp]

[:nusi:]
「你第一次来向我问安时，真是青涩得很」[rhp]
[:nusi:][nusi kao=2 ]
「努西阁下。往后还请对在下这不才之辈多多教导鞭策……」[rhp]

[yurasu]
[se storage="hand_06.ogg"]

[:nusi:][nusi kao=8 as=on ]
「好痛！！！　没必要动手吧！？」[rhp]

[:yoru:][yoru kao=12 ]
「吵死了的兔子……」[rhp]

[off_all]

[:yoru:][yoru kao=2 as=on ]
「……！？」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=2 as=on ss=on hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sausu:][sausu kao=0 ]
「怎、怎么了吗约尔大人」[rhp]

[:yoru:][yoru kao=6 as=on ss=on ]
「………这……手好臭……」[rhp]

[off_all]

[:gonzalez:][gon kao=2 as=on ]
「呜哇。是老爷穿了十年的鞋垫味道……」[rhp]

[off_all]

[se storage="se4_08.ogg"]

[chara_part name="mata" body=base kao=2 as=on ss=on hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:mataroko:][mata kao=1 ]
「利瑟修！！　利瑟修！！」[rhp]

[:yoru:][yoru kao=0 ]
「什……住手！　你在泼什……！」[rhp]

[off_mata]
[chara_part name="nusi" body=base kao=11 as=on ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="160" top="0" wait="true" time=150]

[:nusi:][nusi kao=6 ]
「我们这些前辈组，今天也一如既往[rhr]
_　被后辈们用花束温柔包围的日子……」[rhp]
[:nusi:][nusi kao=14 ]
「不嫌弃我们的话！[rhr]
_　今后也要多依靠我们啊，南！」[rhp]

[:yoru:][yoru kao=6 as=on ]
「别把我混为一谈……！　比南更烦人的家伙！」[rhp]

[off_all]

[chara_part name="mata" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="gon" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="355" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=14 as=on ss=off hh=on hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="650" top="0" wait="true" time=150]

[:sausu:]
「…………噗、哈哈哈！」[rhp]

[:mataroko:]
「南，笑成这样对方太可怜了。[rhr]
_　两位都上了年纪呢」[rhp]

[:gonzalez:]
「体臭是没法子的。[rhr]
_　我们年轻人，也得注意这些地方才行啊」[rhp]

[off_all]

[chara_part name="nusi" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=2 as=n ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:nusi:]
「少多管闲事……」[rhp]

[off_yoru]

[chara_part name="sausu" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sausu:]
「呵呵…………总觉得，不是我认识的那个约尔大人呢」[rhp]

[:nusi:]
「是吗？这家伙本来就这样」[rhp]

[:sausu:][sausu kao=11 ]
「这样啊。……那大概是我的缘故吧。[rhr]
_　因为我总在做惹怒他的事……」[rhp]

[off_all]

[:yoru:][yoru kao=7 ]
「哼……」[rhp]

[off_all]

[chara_part name="sausu" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sausu:]
「约尔大人。……至今为止真的非常抱歉」[rhp]
[:sausu:]
「那个……如果可以的话，请让我加入你们的……就是……」[rhp]

[:yoru:][yoru kao=0 ]
「别跟我说」[rhp]

[:sausu:][sausu kao=0 as=on ]
「诶」[rhp]

[:yoru:][yoru kao=0 ]
「……问过魔太郎子了吧。长辈是那边那只兔子」[rhp]

[off_sausu]
[chara_part name="nusi" body=base kao=11 as=off ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]

[:nusi:]
「就这种时候才肯承认啊。这别扭家伙」[rhp]

[:yoru:][yoru kao=6 ]
「闭嘴」[rhp]

[:nusi:][nusi kao=14 ]
「好啦好啦……嘛，算了」[rhp]

[off_all]

[:nusi:][nusi kao=2 ]
「所以说南。虽然让你这么拘谨有点过意不去……[rhr]
_　想加入我麾下的话有条件」[rhp]

[:sausu:][sausu kao=2 as=on ]
「条件……？」[rhp]


[yurasu]
[:nusi:][nusi kao=8 as=on ss=on ]
[font size=28]
「请借我钱！！！！」[rhp]
[resetfont]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:sausu:][p_s_19][sausu kao=0 ]
「！」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[chara_part name="mata" body=base kao=2 as=off ss=on hh=off hr=on ]
[chara_show name="mata" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="gon" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" left="600" top="0" wait="true" time=150]

[:mataroko:]
「努西大人您！都这时候了还在丢人现眼！」[rhp]

[:gonzalez:][gon kao=6 ]
「真想看看同期的表情啊……！　瞥！」[rhp]

[off_all]

[:yoru:][yoru kao=12 ]
「我晚一个月入行」[rhp]

[off_all]

[chara_part name="nusi" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" left="160" top="0" wait="false" time=150]
[chara_part name="sausu" body=base kao=14 as=off ss=off hh=off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:sausu:][sausu kao=14 ]
「……！　哈哈哈……！」[rhp]
[:sausu:]
「…………、谢谢、大家……」[rhp]

[off_all]

[::]
……这段旅程真的无比漫长。[rhr]
虽然犯过许多错误，但终于快要找到了。[rhp]

[:sausu:]
[font color=0x4682b4]
（博士。沃尔佩克拉。大家……）[rhp]
[:sausu:]
（…………公主）[rhp]
[resetfont]

[::]
请你们见证从今往后的我。[rhr]
这次我绝不会再犯错。[rhp]
……今后也依然，为了孩子们的笑容。[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

;****************************************
[fbgm]
[set_w storage="white.jpg"]
[bgm storage="bgm_15.ogg"]
;****************************************

三年后[rhp]

;****************************************
[bg storage="cg/c_2.png" time=2000]
[cg storage="cg/c_2.png"]
;****************************************

――――那幅画的主题是《昨日的梦》。[rhp]
我茫然望着装饰在大厅里的儿童画。[rhp]

;****************************************
[bg storage="hsps_03.jpg" time=1000]
;****************************************

我的名字叫大美贺千秋。[rhr]
是这间即将在一周后关闭的临终关怀院的护士。[rhp]
入住的孩子们都已全部转移至主楼。[rhr]
我坐在鸦雀无声的大厅地板上整理行李。[rhp]

每月都在增加的绘本。又大又软的积木。[rhr]
更新换代过多次的玩具。[rhp]
从刚成为护士不久就被派来这里工作，此后便一直[rhr]
守护着孩子们的我看来，这些都是无可替代的珍宝。[rhp]
将它们一件件装进纸箱时，[rhr]
每个物件承载的回忆都涌上心头。[rhp]

;****************************************
[bg storage="cg/c_2.png" time=1000]
;****************************************

我犹豫不决。[rhr]
该怎样处理这些贴满整面墙的画作。[rhp]
作为著名大型医院的主楼人员有些冷漠。[rhr]
拿着这些东西过去肯定会遭到冷遇，这是明摆着的事。[rhp]
虽然由我出面说的话总能解决，[rhr]
但光是被人觉得碍事这点就令人不快。[rhp]
画这些画的孩子们，已经不在人世了。[rhr]
我还记得他们在我们面前开心地、拼命作画的模样。[rhp]
……怎么可能扔掉。[rhp]

;****************************************
[bg storage="hsps_03.jpg" time=1000]
;****************************************

要不还是等矢部老师指示吧。[rhr]
虽然知道他肯定会说同样的话，但俗话说红灯两人结伴闯也无妨。[rhp]
现在他正在主楼进行最后的商议。[rhr]
我本来也该去的，不过行李打包更要优先处理。[rhp]
专业搬运公司只被叫来搬运精密仪器。[rhr]
其他东西只想由我、老师和其他工作人员亲手收拾。[rhp]
因为这里是我们另一个家。[rhr]
不愿让陌生人随意触碰，或是粗鲁对待。[rhp]

;****************************************
[bg storage="sky_05.jpg" time=1000]
;****************************************

从宽敞的落地窗洒进斑驳阳光。[rhp]
季节轮转，不知第几个春天来临。[rhp]

[:tiaki:]
「…………稍微休息下……」[rhp]

[off_all]

[::]
虽然和工作人员分工负责打包，[rhr]
但一个人整理大厅果然还是吃力。[rhp]
矢部老师回去后肯定会被医务室的工作追着跑吧。[rhp]
打包完行李后，要扫地、擦窗……[rhp]

[:tiaki:]
[font color=0x4682b4]
（……忙得恨不得借猫的手帮忙呢……）[rhp]
[resetfont]

[::]
或者不借猫的手也行。[rhp]
比如说……[rhp]

[:unknown:]
「――――――名医的手可不推荐」[rhp]

;****************************************

#
[s_mask color=0xffffff time=2000]
; 魔法
[se storage="mag_08.ogg"]
; 背景表示
[bg storage="real_06.jpg" time=100]
; 全部のフィルターを打ち消す
[free_filter ]
; ウィンドゥの設定
[position layer="message0" frame="win.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[s_mask_off time=2000]

;****************************************

[:tiaki:][mika kao=0 ]
「……哎呀？」[rhp]

[off_all]

[:yoru:][yoru kao=0 ]
「好久不见啊，千秋。大约有三年了吧」[rhp]

[off_all]

[chara_part name="mika" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="mika" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:tiaki:]
「夜君……！真的好久不见。[rhr]
_　那之后你完全没召唤过我呢。我很担心哦」[rhp]
[:tiaki:][mika kao=7 ]
「……所以，这里是？」[rhp]

[:yoru:][yoru kao=7 ]
「既然要召唤，我觉得机会难得。[rhr]
_　你应该没见过这幅景色吧」[rhp]
[:yoru:][yoru kao=3 ]
「…………这里是旅程的终点」[rhp]

[:tiaki:][mika kao=0 ]
「！　……这样啊……」[rhp]
[:tiaki:][mika kao=13 ]
「……谢谢」[rhp]

[:yoru:][yoru kao=0 ]
「？」[rhp]

[:tiaki:][mika kao=1 ]
「不是很美妙的地方吗。[rhr]
_　大家都是从这里启程的啊」[rhp]
[:tiaki:][mika kao=14 ]
「太好了。未来肯定充满光明」[rhp]

[:yoru:][yoru kao=1 ]
「………………是啊」[rhp]

[:tiaki:][mika kao=1 ]
「所以？让我看这幅景色，就是你召唤我来的目的？」[rhp]

[:yoru:][yoru kao=3 ]
「……不是……，……」[rhp]

[:tiaki:][mika kao=0 ]
「什么嘛？说话吞吞吐吐的」[rhp]

[:yoru:][yoru kao=6 ]
「………………」[rhp]

[:tiaki:][mika kao=2 as=on ]
「……或者该说，你在生气？」[rhp]

[:yoru:]
「………………不、那件事姑且可以放后面」[rhp]

[:tiaki:][mika kao=0 ]
「？」[rhp]

[:yoru:][yoru kao=12 ]
「三年前的事……不，其实从更早之前就承蒙你们照顾了。[rhr]
_　在此，我要郑重道谢」[rhp]

[:tiaki:][mika kao=1 ]
「我们才是。[rhr]
_　要是没有夜君的话，我们至今都会一无所知呢」[rhp]
[:tiaki:][mika kao=0 ]
「但为何选现在？」[rhp]

[:yoru:][yoru kao=7 ]
「那所临终关怀院很快就要关闭了吧。[rhr]
_　听说主楼里的医护人员和病患数量，是这里的数倍之多」[rhp]
[:yoru:][yoru kao=12 ]
「所以我们决定了。[rhr]
_　无论发生什么，我们都不会再在人类面前现身」[rhp]

[:tiaki:][mika kao=0 as=on ]
「…………！」[rhp]

[:yoru:]
「为避免混乱别无他法。努西和南也都同意了」[rhp]
[:yoru:]
「我们不现身意味着——[rhr]
_　你们再也无法来到这个世界」[rhp]

[:tiaki:][mika kao=3 ]
「这样啊……真让人寂寞呢」[rhp]

[:yoru:][yoru kao=7 ]
「我一直想着必须向你们道谢。[rhr]
_　说到底连像样的语言都没能说清」[rhp]

[:tiaki:][mika kao=1 ]
「没办法呀。搬迁计划三年前就开始运作，[rhr]
_　我们也忙得不可开交呢」[rhp]

[:yoru:][yoru kao=3 ]
「看来确实如此。[rhr]
_　等待合适机会的过程中，不知不觉竟过去这么久」[rhp]

[:tiaki:][mika kao=1 ]
「呵呵。很有夜君的作风呢」[rhp]

[:yoru:][yoru kao=12 ]
「关于礼仪这件事……对千秋和武，[rhr]
_　我特意保留了本应抹除的过往记忆」[rhp]

[:tiaki:][mika kao=13 ]
「……！谢谢。这是最好的礼物了」[rhp]

[:yoru:][yoru kao=0 ]
「反正就算说给别人听，也不会有人相信吧」[rhp]

[:tiaki:]
「没关系呀。我会把它当做一生的珍宝藏在心底」[rhp]

[:yoru:][yoru kao=1 ]
「是吗」[rhp]
[:yoru:][yoru kao=12 ]
「……那么，关于矢部。我决定给他一个机会」[rhp]

[:tiaki:][mika kao=0 ]
「机会？」[rhp]
[off_all]

[:yoru:][yoru kao=0 ]
「喂。别躲了快出来吧」[rhp]

[off_all]

[:yabu:][yabu kao=3 ]
「～～～～～……」[rhp]

[off_all]

[chara_part name="yabu" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="yabu" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="mika" body=base kao=4 as=on ss=off hh=off hr=on ]
[chara_show name="mika" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:]
「呀！老、老师原来就在旁边吗？为什么要隐身呀？」[rhp]

[:yabu:]
「…………………」[rhp]

[:tiaki:][mika kao=0 ]
「老师……？」[rhp]

[:yabu:]
「…………………那个」[rhp]

[off_all]

[:yoru:][yoru kao=12 ]
「他好像有话要对千秋说」[rhp]

[yurasu]

[:yabu:][yabu kao=2 as=on ss=on ]
[font size=30]
「哇啊啊啊！！」[rhp]
[resetfont]

[off_all]

[:tiaki:][mika kao=0 ]
「想说的话？」[rhp]

[off_all]

[chara_part name="yabu" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="yabu" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:yabu:]
「你！！为什么！！要说出来啊！？」[rhp]

[:yoru:]
「因为觉得可能会变得很长……」[rhp]

[:yabu:]
[font size=30]
「笨蛋！！」[rhp]
[resetfont]

[off_yoru]
[chara_part name="mika" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="mika" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:]
「想说的话呢……是什么呢？」[rhp]

[:yabu:][yabu kao=6 as=on ]
「就就算说出来也不是那个意思哦？[rhr]
_　就、就是平日的感谢之类的！根本不是那种事情啦」[rhp]

[:tiaki:][mika kao=13 ]
「……呵呵！也是呢。肯定是这样」[rhp]

[:yabu:][yabu kao=6 as=on ]
「！呃、啊……确实是这样没错……[rhr]
_　不、不过？要说不是的话，也算不上不是…」[rhp]

[off_all]

[:yoru:][yoru kao=2 ]
「真是个磨叽的男人。赶紧的―――」[rhp]

[:yabu:][yabu kao=5 as=on ]
「啊——！　够了别说了！[rhr]
_　反倒是夜，你肚子有点饿了吧？」[rhp]

[:yoru:][yoru kao=0 ]
「我不需要人类的营养」[rhp]

[:yabu:]
「瞎说！　名医最擅长察觉身体不适！」[rhp]
[:yabu:]
「听说某星球商业街有家熟食店很受三傻追捧。[rhr]
_　我把别人给的地图给你，你也去尝尝吧」[rhp]

[:yoru:][yoru kao=0 ]
「熟食店……」[rhp]

[:yabu:][yabu kao=13 as=on ]
「据说是卖可乐饼的。边逛边吃才够风雅」[rhp]

[:yoru:][yoru kao=6 ]
「真没教养的家伙。简直……」[rhp]

[off_all]

[:yoru:][yoru kao=6 ]
「我去提醒他们一下」[rhp]

[off_all]

[chara_part name="yabu" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="yabu" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="mika" body=base kao=13 as=on ss=off hh=off hr=on ]
[chara_show name="mika" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:yabu:][yabu kao=0 ]
「路上小心！」[rhp]

[:tiaki:][mika kao=1 ]
「果然很在意……可乐饼……」[rhp]

[off_mika]

[chara_part name="yoru" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:yoru:][yoru kao=0 ]
「矢部」[rhp]

[:yabu:][yabu kao=1 ]
「干嘛？　要是伴手礼就免了……」[rhp]

[:yoru:][yoru kao=12 ]
「别管结果如何 但求无悔」[rhp]

[:yabu:][yabu kao=0 as=on ]
「……！」[rhp]

[off_all]

[:yoru:][yoru kao=1 ]
「祝你旗开得胜」[rhp]

;****************************************
[bg_magic_d]
;****************************************

[:yabu:][yabu kao=2 as=on ]
「………啊，那家伙……」[rhp]

[off_all]

[chara_part name="yabu" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="yabu" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="mika" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="mika" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:]
「老师♡」[rhp]

[:yabu:][yabu kao=6 as=on ]
「！！　哇、吓我一跳。脸、脸太近了米卡亲」[rhp]

[:tiaki:][mika kao=1 ]
「呵呵。你有话想对我说吧？」[rhp]

[:yabu:][yabu kao=6 as=on ]
「那、那是……」[rhp]

[:tiaki:][mika kao=13 ]
「…………嘻嘻♡　算了没事」[rhp]
「老师呀。陪我散散步好不好？」[rhp]

[:yabu:][yabu kao=3 as=on ]
「散步？　不不过，现在哪有那种时间……」[rhp]

[:tiaki:][mika kao=13 ]
「边走边聊不就好了吗。[rhr]
_　毕竟过了三年，彼此都有不少想说的话吧」[rhp]
[:tiaki:][mika kao=1 ]
「再说这很可能已经是最后一次了」[rhp]

[:yabu:][yabu kao=6 as=on ]
「……！」[rhp]

[:tiaki:][mika kao=14 ]
「对吧」[rhp]

[:yabu:][yabu kao=3 as=on ]
「………………」[rhp]

[off_all]

[:yabu:]
「…………明白了」[rhp]

;****************************************
[bg_b storage="real_05.jpg"]
;****************************************

[chara_part name="yabu" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="yabu" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="mika" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="mika" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:]
「不过真是久违了呢。[rhr]
_　和老师一起散步，总觉得好怀念」[rhp]

[:yabu:]
「是啊。杰特那件事上，我们完全被排除在外了」[rhp]

[:tiaki:][mika kao=6 ]
「哎呀！我当时在现实世界可辛苦啦？[rhr]
_　要和矢部老师一起搬运夜君那沉～甸甸的本体呢」[rhp]
[:tiaki:]
「而且您听我说！全部结束后[rhr]
_　还得原样搬回去！主楼的人实在太坏心眼了！」[rhp]

[:yabu:][yabu kao=1 ]
「能让米卡亲干体力活确实挺稀奇的」[rhp]

[:tiaki:][mika kao=3 ]
「对吧？足足抵得上一年的减肥效果呢」[rhp]

[:yabu:][yabu kao=6 ]
「那现在该不会……」[rhp]

[:tiaki:][mika kao=143 hh=on ]
「才没有！！哎嘿♡」[rhp]

[:yabu:][yabu kao=1 as=on ]
「哈哈……果然是米卡亲的风格」[rhp]

[:tiaki:][mika kao=1 ]
「…………。老师今天没什么精神呢」[rhp]

[:yabu:][yabu kao=0 ]
「是、是吗？」[rhp]

[:tiaki:][mika kao=1 ]
「嗯。平时明明吵得要命」[rhp]
[:tiaki:][mika kao=11 ]
「总觉得立场好像反过来了。[rhr]
_　换成我滔滔不绝，老师您静静听着……」[rhp]

[:yabu:][yabu kao=2 as=on ]
「等等。说起来之前不也经常这样吗。[rhr]
_　每次你做出荒谬举动时，都是我来收拾残局……！」[rhp]

[:tiaki:][mika kao=13 ]
「呜呼呼♡」[rhp]

[:yabu:][yabu kao=6 as=on ]
「装、装傻充愣……！就像现在这样不是吗！」[rhr]
_　为何我这名医非得负责吐槽不可」[rhp]
[:yabu:][yabu kao=3 as=on ]
「我是说……那个…该更认真些！[rhr]
_　明明是想和你谈话才叫来的！」[rhp]

[:tiaki:]
「呵呵，好啦好啦……那就开始认真谈吧」[rhp]

[off_all]

;****************************************
[bg storage="sky_02.jpg" time=1000]
;****************************************

[:tiaki:]
「老师这一年过得怎样？」[rhp]

[:yabu:]
「……目前受雇于南的铁道」[rhp]

[:tiaki:]
「！」[rhp]

[:yabu:]
「夸德里利昂和达克内布拉…还有多洛普也留在那边。[rhr]
_　受他们邀请，我也加入了这段旅程」[rhp]

[:tiaki:]
「……哼嗯，这样啊……」[rhp]
[:tiaki:]
「…………开心吗？」[rhp]

[:yabu:]
「还算可以。本以为会是更吵闹的家伙们，[rhr]
_　意外地很靠谱……那种氛围倒不讨厌」[rhp]

[:tiaki:]
「…………」[rhp]

[:yabu:]
「……即便一切结束后，对南的事还是耿耿于怀呢」[rhp]

[:tiaki:]
「……谁知道呢」[rhp]

;****************************************
[bg storage="real_05.jpg" time=1000]
;****************************************

[:yabu:][yabu kao=3 ]
「…………喂，米卡亲」[rhp]
[:yabu:]
「不如原谅南吧」[rhp]

[off_all]

[:tiaki:][mika kao=4 ]
「…………」[rhp]
[:tiaki:][mika kao=2 ]
「……认真的？这话，是对我说的？」[rhp]

[off_all]

[chara_part name="yabu" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="yabu" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="mika" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="mika" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:yabu:][yabu kao=2 ]
「你听到的杰特那些话只是措辞问题，[rhr]
_　你其实也早就察觉了吧」[rhp]

[:tiaki:][mika kao=2 ]
「…………」[rhp]

[:yabu:][yabu kao=0 ]
「南有南自己的信念。[rhr]
_　虽然方法不同，但希望孩子们幸福的心情，和你们还有夜是一样的」[rhp]
[:yabu:][yabu kao=3 ]
「这不是因为我受他庇护才这样说。[rhr]
_　我只是……，…………我」[rhp]
[:yabu:]
「…………只是不忍心看着心爱之人怀着怨恨活下去」[rhp]

[fbgm]
[off_all]

[:tiaki:][mika kao=4 as=on ]
「―――……诶」[rhp]

[off_all]

[bgm storage="bgm_13.ogg"]

[:yabu:][yabu kao=3 tear=on ]
「…………呜」[rhp]

[off_all]

[chara_part name="yabu" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="yabu" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="mika" body=base kao=2 as=on ss=off hh=off hr=on tear=on ]
[chara_show name="mika" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:]
「咦？为、为什么哭啊？」[rhp]

[:yabu:]
「没哭……！」[rhp]

[:tiaki:]
「不，怎么看都……」[rhp]

[:yabu:][yabu kao=2 as=on ]
[font size=25]
「这是不甘心的眼泪！！」[rhp]
[resetfont]

[:tiaki:][mika kao=6 as=on ]
「嗯？」[rhp]

[:yabu:]
「反正你最后也会把我的感情当成玩笑吧。[rhr]
_　因为回到现实后，站在你身边的会是真正的武」[rhp]

[:tiaki:][mika kao=0 as=on ]
「老师……」[rhp]

[off_all]

[:yabu:][yabu kao=2 tear=on ]
「但我依然敢断言。[rhr]
_　无论是作为医生还是男人，我都比武强……！」[rhp]
[:yabu:]
「因为我绝不逃避！」[rhp]
[:yabu:]
「无论是这份寂寞还是无法跨越的高墙，我都会正面承受。[rhr]
_　绝不会让任何人代替我来承担！」[rhp]

[off_all]

[:tiaki:]
「………………」[rhp]

[:yabu:]
「就算再也见不到，我也会永远――――」[rhp]

;****************************************
;ハグ
[se storage="body_07.ogg"]

[still storage="cg/f_1.png" rule="007.png" width="1280" height="720" time=500]
[cg storage="cg/f_1.png"]
;****************************************

[:yabu:]
「…………！」[rhp]
[:yabu:]
「米、米卡同……」[rhp]

[:tiaki:]
「叫我千秋就好」[rhp]
[:tiaki:]
「……三年前的我，真的非常痛苦，悲伤……[rhr]
_　那段日子简直就像在跟南较劲般地怨恨着他」[rhp]
[:tiaki:]
「可不止那样哦。我们也度过了许多快乐时光。[rhr]
_　一定是因为你总是陪在我身边的缘故吧」[rhp]
[:tiaki:]
「真令人怀念啊，那些点点滴滴。还记得我们一起看烟花吗？」[rhp]

[:yabu:]
「是……是啊」[rhp]
[:yabu:]
「…………那时候你可真把我吓得不轻」[rhp]

[:tiaki:]
「那个发饰，你还戴着吗」[rhp]

[:yabu:]
「交给我吧。下次见面时我会替你提醒他的」[rhp]

[:tiaki:]
「呵呵，那就拜托啦」[rhp]
[:tiaki:]
「……啊，我们还去过海边呢！那时候老师真是厉害。[rhr]
_　没想到居然会游泳呢」[rhp]

[:yabu:]
「……武也是会游泳的」[rhp]

[:tiaki:]
「在我面前绝对连泳衣都不会穿，肯定是的！」[rhp]
[:tiaki:]
「我怎么样？像泳衣啦、法被啦。合适我吗？」[rhp]

[:yabu:]
「嗯。这个嘛……那个」[rhp]

[:tiaki:]
「说清楚点！」[rhp]

[:yabu:]
「………………我觉得很合适」[rhp]

[:tiaki:]
「呵呵！我就说吧。[rhr]
_　米卡亲不管做什么都很有范儿呢」[rhp]

[:yabu:]
「…………不过那个御好烧实在不敢恭维」[rhp]

[:tiaki:]
「你不知道吗？世上食物只要加了苹果，[rhr]
_　多半就会变成青森风味哦」[rhp]

[:yabu:]
「还有这种说法？」[rhp]

[:tiaki:]
「就是有这种说法！」[rhp]

[:yabu:]
「……你这个人还真是乱七八糟」[rhp]

[:tiaki:]
「就是喜欢你这点呢，老师♡」[rhp]

[:yabu:]
「没错」[rhp]

[:tiaki:]
「！……啊、哈哈哈……被这么直白地说出来反而有点害羞呢……」[rhp]

[:yabu:]
「………………会寂寞的」[rhp]

[:tiaki:]
「我也是呢，老师」[rhp]

[:yabu:]
「―――！」[rhp]

[:tiaki:]
「但比起寂寞，更多的是满足感」[rhp]
[:tiaki:]
「本该是场艰苦又悲伤的战斗。[rhr]
_　多亏有你，变成了一场比想象更美妙的冒险」[rhp]
[:tiaki:
「…………真的、真的很感谢你」[rhp]

[:yabu:]
「……、那是……对什么的感谢？」[rhp]

[:tiaki:]
「当然是全部」[rhp]
[:tiaki:]
「你的心意也好，至今发生的所有事也好，全部包含在内的感谢」[rhp]

[:yabu:]
「还是这么粗枝大叶啊……」[rhp]

[:tiaki:]
「呐，老师……刚才的回答，我可以带回去吗？」[rhp]

[:yabu:]
「！但是……你已经不会再」[rhp]

[:tiaki:]
「是呢。我大概不会再回到这里了。[rhr]
_　因为在活着的世界还有好多想做的事」[rhp]
[:tiaki:]
「所以这是很久很久以后的事」[rhp]
[:tiaki:]
「就算我变成满脸皱纹的老婆婆，[rhr]
_　如果心意不变就来接我吧」[rhp]
[:tiaki:]
「……总有一天，乘着银河铁道来」[rhp]

[:yabu:]
「…………」[rhp]

[:tiaki:]
「在这个世界能变成理想模样对吧。那到时候我会以[rhr]
_　和现在一样……不，稍微再瘦一点的姿态回来哦」[rhp]
[:tiaki:]
「那么继续我们的旅程吧」[rhp]
[:tiaki:]
「一定还要、两个人一起」[rhp]

[:yabu:]
「…………、我保证」[rhp]

[:tiaki:]
「等我想做的事情全部完成后、再来接我就行」[rhp]
[:tiaki:]
「那之后、就是比任何人都努力的我应得的奖励时间啦！」[rhp]

[:yabu:]
「哈哈……这样啊。那可真是让人期待啊」[rhp]
「……再见了。千秋」[rhp]

[:tiaki:]
「嗯。老师……」[rhp]
[:tiaki:]
「…………一定会再见的！」[rhp]

;****************************************
#
[s_mask color=0xffffff time=2000]
; 背景表示
[bg storage="white.jpg" time=100]
[free_filter ]
; ウィンドゥの設定
[position layer="message0" frame="win2.png" left=0 top=520 width=1280 height=200 page=fore visible=true time=1000]
[s_mask_off time=2000]

;****************************************

[::]
………………――――[rhp]
………………――――小姐[rhp]

;****************************************
[bg storage="hsps_03.jpg" time=1000]
;****************************************

[:takeru:][take kao=6 ]
「―――――大美贺小姐！」[rhp]

[off_all]

[:tiaki:][tiaki kao=0 ]
「……！」[rhp]

[off_all]

[chara_part name="take" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:takeru:]
「终于醒了。没事吧？」[rhp]

[:tiaki:]
「啊……老师……」[rhp]
[:tiaki:]
「…………武先生那边？」[rhp]

[:takeru:][take kao=6 as=on ]
「嗯……是的」[rhp]

[:tiaki:][tiaki kao=3 ]
「这样啊……我睡着了……」[rhp]

[off_all]

[::]
……………………。[rhp]

[:tiaki:][tiaki kao=3 ]
「…………是梦吗」[rhp]

[:takeru:][take kao=0 ]
「嗯？」[rhp]

[:tiaki:][tiaki kao=1 ]
「没、没什么」[rhp]

[:takeru:][take kao=0 ]
「打盹就算了、这么叫都叫不醒倒是少见」[rhp]

[:tiaki:][tiaki kao=12 ]
「真失礼啊。我今天可是忙了一整天呢！[rhr]
_　看到那堆纸箱就该明白我根本没偷懒啦」[rhp]

[:takeru:][take kao=6 ]
「是是……」[rhp]

[:tiaki:][tiaki kao=3 ]
「………………」[rhp]

[:takeru:][take kao=12 ]
「……希望不是梦就好了」[rhp]

[:tiaki:][tiaki kao=0 ]
「嗯？」[rhp]

[:takeru:][take kao=0 ]
「因为是武先生那边，我还以为是见到了我的替身。[rhr]
_　之前听夜说过，那个世界的我和你是很好的搭档」[rhp]

[:tiaki:][tiaki kao=11 ]
「……是啊。不过……说实话是不是梦还很模糊」[rhp]
[:tiaki:][tiaki kao=3 ]
「自从一切结束后，夜君就再没出现在我们面前。[rhr]
_　说不定刚才看到的，全都是我一厢情愿的幻想」[rhp]
[:tiaki:][tiaki kao=13 ]
「…………但无论如何都是段美好的时光！」[rhp]

[:takeru:][take kao=1 ]
「这样啊。那就好」[rhp]

[:tiaki:][tiaki kao=14 ]
「不知为何夜君有点生气，那份倔强也让人怀念呢」[rhp]
[:tiaki:]
「呵呵！医生您听我说。[rhr]
_　矢部医生居然向我告白了哦♡」[rhp]

[:takeru:][take kao=2 as=on hh=on ]
「哎？等等，你们俩居然是那种……哎！？」[rhp]

[:tiaki:][tiaki kao=13 hh=on ]
「他说会一直等到我变成老婆婆呢♡[rhr]
_　真痴情呀。可爱死了♡」[rhp]
[:tiaki:][tiaki kao=1 ]
「明明长着相同的脸，却和医生您完全相反。[rhr]
_　难得的机会，您也该去见见他才是」[rhp]

[:takeru:][take kao=8 as=on ]
「见面还是算了。要是直面理想中的自己，[rhr]
_　搞不好心态会崩溃的」[rhp]

[:tiaki:][tiaki kao=11 as=on ]
[font color=0x4682b4]
（不过从另一种意义上来说确实会受冲击吧……）[rhp]
[resetfont]

[:takeru:][take kao=1 ]
「但居然向这个人告白……」[rhp]
[:takeru:]
「……眼光不错呢。真不愧是我」[rhp]

[:tiaki:][tiaki kao=1 ]
「……！医生……」[rhp]

[:takeru:][take kao=13 ]
「嘛，我这边就免了吧」[rhp]

[:tiaki:][tiaki kao=6 ]
「真是的！你总是多嘴」[rhp]
[:tiaki:][tiaki kao=5 ]
「这样的老师就没好人了吗？[rhr]
_　要我介绍关系好的工作人员给您吗？」[rhp]

[:takeru:][take kao=8 ]
「多管闲事……」[rhp]
[:takeru:]
「……话说，关于夜生气的原因，我倒是有头绪」[rhp]

[:tiaki:][tiaki kao=4 ]
「真的吗？」[rhp]

[:takeru:][take kao=12 ]
「就是『那个东西』」[rhp]

[:tiaki:][tiaki kao=6 as=on ]
「…………啊」[rhp]

[:takeru:][take kao=1 ]
「总之无论如何，重逢总是可喜」[rhp]

[:tiaki:][tiaki kao=13 ]
「那个……之后得准备些赔罪供品。[rhr]
_　果然还是食物比较好吧？」[rhp]

[:takeru:][take kao=5 as=on ]
「供品……就算是供奉，也不确定他是否会因食物高兴」[rhp]

[:tiaki:][tiaki kao=5 ]
「哎呀，夜君其实意外地贪吃呢。[rhr]
_　虽然本人总想隐瞒」[rhp]

[off_all]

[:tiaki:][tiaki kao=13 ]
「来！该走了老师。[rhr]
_　医务室还没整理完吧。我也来帮忙」[rhp]

[off_all]

[:takeru:][take kao=1 ]
「谢谢。帮大忙了」[rhp]

[off_all]

;****************************************
#
[bg storage="hsps_06.jpg" time=1000]
;****************************************

与矢部老师并肩走在熟悉的走廊上。[rhp]
回响的只有两重脚步声。[rhr]
欢快的笑声也好，轮椅的吱呀声也罢，都再也听不见了。[rhp]
沉默着走向医务室的路上，[rhr]
矢部老师突然开口。[rhp]

[chara_part name="take" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:takeru:]
「………这栋建筑，也只剩一周就要告别了」[rhp]

[:tiaki:][tiaki kao=1 ]
「哎呀呀医生。这么感伤啊」[rhp]
[:tiaki:][tiaki kao=13 ]
「……但很开心。[rhr]
_　最初的时候，说实话医生好像对调来这里工作不太满意呢」[rhp]

[:takeru:][take kao=1 ]
「我当时也还年轻。现在没有那种想法了。[rhr]
_　……能在这家临终关怀院工作，真的太好了」[rhp]

[:tiaki:][tiaki kao=14 as=on ]
「啊哈哈……怎么搞得好像最后一天似的」[rhp]
[:tiaki:][tiaki kao=5 ]
「搬东西进门才算是搬家完成。[rhr]
_　在连行李都没打包完之前，我们能不聊这些伤感的话题吗」[rhp]

[:takeru:][take kao=11 ]
「……、说的也是。失礼了」[rhp]

[off_all]

[::]
彼此藏起依依不舍的心情，就这样说着些无关紧要的闲话，[rhr]
我们偶然经过某个房间门前。[rhp]

[:tiaki:][tiaki kao=0 ]
「………………」[rhp]

[off_all]

[:takeru:][take kao=0 ]
「大美贺小姐？」[rhp]

[off_all]

[::]
――――101号室。[rhp]
在那个房间前停下脚步，并非偶然。[rhp]

[chara_part name="take" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:]
「矢部老师、对不起。我忘了东西[rhr]
_　能请您先走吗？我马上回来」[rhp]

[:takeru:]
「？　好的……明白了。请小心」[rhp]

[off_all]

[fbgm]

[::]
正转身的矢部老师调转脚跟，[rhr]
我站在原地目送他再次沿着走廊离去。[rhp]
待他在转角处消失后，[rhr]
我将身体转向左侧的101号室。[rhp]

;****************************************
[bg storage="hsps_07.jpg" time=1000]
[bgm storage="bgm_40.ogg"]
;****************************************

我缓缓吐出一口气，将手搭在那扇门上。[rhp]

;****************************************
[bg_rule storage="hsps_09.jpg" rule="002.png" time=1000]
;****************************************

101号室中设置的医疗器材早已被移往主楼。[rhr]
如今这房间只剩些玩具、书籍之类的杂物。[rhp]
而其中，当然也包括他。[rhp]

[:tiaki:][tiaki kao=2 ]
「……………………南」[rhp]

[off_all]

[::]
那褪色的千纸鹤，至今仍装饰在床铺旁。[rhp]

……此刻他是否正身在此处呢。[rhr]
最终在这设施里都未能与他相见。[rhp]
即便在银河铁道的世界，也不过在那度假胜地偶然擦肩。[rhp]

倒并非刻意回避。[rhr]
想必也并非是对方在躲着我。[rhp]

但老实说，确实不想见到他。[rhp]

;****************************************
[bg storage="sky_05.jpg" time=1000]
;****************************************

[:tiaki:]
「……我还没有原谅你」[rhp]
[:tiaki:]
「就因为你将孩子们玩弄于股掌，将他们困在那个世界」[rhr]
_　不知扼杀了多少未来可能性的幼芽」[rhp]
[:tiaki:]
「今后想必也永远不会原谅」[rhp]

[::]
我曾亲眼窥见过那个男人构筑的世界。[rhp]
那些孩子们在那里绽放的笑颜。[rhr]
唯独这点必须承认确是真实。[rhp]
……虽令人火大，但他的热忱绝非虚假。[rhp]
即便如此也无法答应矢部医生的请求。[rhr]
说什么和好简直荒唐透顶。[rhp]

……所以我已下定决心。[rhp]
最后要用最极致的刁难，给这段恩怨画上句号。[rhp]
但愿我最讨厌的南，能好好吃点苦头。[rhp]
那么……[rhp]

[:tiaki:]
「…………矢部医生的事，就拜托你了！」[rhp]

;****************************************
[set_w storage="sta_01.jpg"]
;****************************************

[chara_part name="rio" body=base kao=3 as=n ss=off hh=off hr=on ]
[chara_show name="rio" layer="1" width="437" height="720" left="208" top="0" wait="true" time=150]

[:rio:]
「……………………」[rhp]

[off_all]

[::]
还不来……。[rhp]

[chara_part name="rio" body=base kao=3 as=on ss=off hh=off hr=on ]
[chara_show name="rio" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:rio:]
「………………、…………」[rhp]

[off_all]

[::]
…………、还是没来……。[rhp]

[:rio:][rio kao=3 as=on ss=on ]
「………………～～～～～！」[rhp]

[off_all]

[:sora:][sora body=prain kao=1 ]
「哟凛生。久等了」[rhp]

[off_all]

[:rio:][rio kao=6 as=on  ]
「啊！！！！」[rhp]

[off_all]

[chara_part name="sora" body=prain kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="rio" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="rio" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:rio:]
「真是的～，宙君！太慢了吧。[rhr]
_　约定时间早就过了耶？！」[rhp]

[:sora:][sora body=prain kao=6 ]
「慢？离集合时间还有三分钟啊」[rhp]

[:rio:][rio kao=2 as=on ]
「只剩三分钟了好吗！听说过提前十分钟行动吗？」[rhp]

[:sora:][sora body=prain kao=5 as=on ]
「好啦好啦知道了知道了。[rhr]
_　下次我会稍微提前点来的」[rhp]

[:rio:]
「必须说到做到哦？本来乡下巴士班次就少，[rhr]
_　不谨慎行动的话会倒大霉的……」[rhp]

[off_all]

[:unknown:]
「喂——！抱歉，让你们久等啦！」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:rio:][rio kao=1 ]
「！杰特君！」[rhp]

[off_all]

[:jet2:][jet body=prain kao=1 hr=on3 ]
「抱歉理央，让我放个行李……」[rhp]

[off_all]

[chara_part name="sora" body=prain kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="jet" body=prain kao=2 as=on ss=off hh=off hr=on hr=on3 ]
[chara_show name="jet" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:jet2:][jet body=prain kao=2 hr=on3]
「……等等，啊！」[rhp]

[:sora:][sora body=prain kao=5 ]
「杰特。好久不见」[rhp]

[:jet2:]
「宙，你这家伙……！」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:sora:][sora body=prain kao=0 ]
「？」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:jet2:][jet body=prain kao=6 hr=on3]
「……嘿～～～。打车摆总裁架子呢。[rhr]
_　医科大学的高材生就是阔气啊」[rhp]

[:sora:][sora body=prain kao=11 ]
「别这么夸我啦」[rhp]

[:jet2:][jet body=prain kao=2 hr=on3]
「才没夸你呢！」[rhp]

[off_sora]

[off_sora]

[chara_part name="rio" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="rio" layer="1" width="437" height="720" left="208" top="0" wait="true" time=150]

[:jet2:][jet body=prain kao=6 hr=on3]
「比起这个理央。我的发型怎么样？不奇怪吗？」[rhp]

[:rio:][rio kao=13 as=on ]
「完全不。倒不如说和平常一样……」[rhp]

[:jet2:][jet body=prain kao=5 hr=on3]
「不一样。今天特意这样……强调了白色部分」[rhp]
[:jet2:]
「毕竟今天可是我和哈蒂当主角的日子啊！」[rhp]

[:rio:][rio kao=14 ]
「呵呵……！看起来很高兴呢」[rhp]

[:jet2:][jet body=prain kao=5 hr=on3]
「哼，这不是当然的吗」[rhp]

[off_all]

[:jet2:][jet body=prain kao=6 hr=on3]
「那我们现在就出发吧。呃，公交站是……」[rhp]

[off_all]

[:rio:][rio kao=1 ]
「在这里哦」[rhp]

[off_all]

[:jet2:][jet body=prain kao=14 hr=on3]
「噢，三克油」[rhp]

[off_all]

;****************************************
[set_kk storage="cg/d_h_12.png"]
;****************************************

[::]
――――3年前，杰特从植物人状态苏醒了。[rhp]
令人惊讶的是，之后他展现出惊人的恢复力，如今几乎痊愈。[rhp]
这件事当时在主楼也引起巨大轰动，[rhr]
甚至登上报纸和新闻。[rhp]
权威医学专家称之为『难以想象的奇迹』……[rhp]

;****************************************
[set_ff storage="sky_05.jpg" time=1000]
;****************************************

而我们，知道这个奇迹的真正原因。[rhp]
杰特是和哈蒂一起来到我们这边的。[rhr]
就这样，他俩真正成为了并肩同行的搭档。[rhp]
构成哈蒂的灵力恐怕转化为了杰特的生命力吧。[rhp]
除了当事人以外知晓这个真相的，[rhr]
就只有我、凛生、矢部老师和大美贺小姐了。[rhp]
当然也绝不会告诉其他人。[rhp]


;****************************************
[bg storage="sta_01.jpg" time=1000]
;****************************************

[:jet2:][jet body=prain kao=6 hr=on3]
「喂宙。你也快点跟上来！要丢下你咯」[rhp]

[off_all]

[:sora:][sora body=prain kao=5 as=on ]
「我知道的」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[::]
杰特就是这样，过着与普通人别无二致的日常生活。[rhp]
而就在前几天。[rhp]
他迎来了人生中的一个重要节点。[rhp]

;****************************************
[set_b storage="hsps_01.jpg"]
;****************************************

[::]
搭乘巴士颠簸了30分钟。[rhr]
我们正前往那所临终关怀院。[rhp]

;****************************************
[bg storage="hsps_02.jpg" timne=1000]
;****************************************

[chara_part name="sora" body=prain kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="rio" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="rio" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="jet" body=prain kao=1 as=off ss=off hh=off hr=on hr=on3 ]
[chara_show name="jet" layer="1" width="437" height="720" left="760" top="0" wait="true" time=150]

[:rio:]
「您好，米卡小姐。我们来找您玩了！」[rhp]

[off_all]

[:tiaki:][tiaki kao=14 ]
「哎呀大家！欢迎你们！」[rhp]

[off_all]

[::]
出来迎接我们的是大美贺小姐。[rhp]
虽说是提前联系过的，不过这地方的人果然都很闲吧……[rhr]
……今天应该不是这样的情况才对。[rhp]

[chara_part name="rio" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="rio" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:]
「好久不见呢。稍等！我这就去叫老师过来」[rhp]

[:rio:][rio kao=0 as=on ]
「啊，如果忙的话我们自己去就好。您不用费心」[rhp]

[:tiaki:][tiaki kao=14 ]
「没事没事。就算忙也费不了多大工―――」[rhp]

[off_all]

[:takeru:][take kao=6 ]
「费不了多大工……？」[rhp]

[off_all]

[chara_part name="sora" body=prain kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="rio" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="rio" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="jet" body=prain kao=2 as=on ss=off hh=off hr=on hr=on3 ]
[chara_show name="jet" layer="1" width="437" height="720" left="760" top="0" wait="true" time=150]

[:3nin:]
「！！」[rhr]
「！！」[rhr]
「！！」[rhp]

[off_all]

[chara_part name="take" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=1 as=on ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:][tiaki kao=1 ]
「哎呀……老、老师。您不是应该在医务室吗」[rhp]

[:takeru:][take kao=0 ]
「因为事先听说他们要来，所以提前把工作处理完了」[rhp]
[:takeru:]
「嘴上说着费不了多大工夫[rhr]
_　可玄关的行李打包还没彻底完成吧？》[rhp]

[off_all]

[::]
矢部老师狠狠瞪着脚边堆积的纸箱。[rhr]
那份严谨与唠叨，即便三年后的现在似乎也未曾改变。[rhp]

[chara_part name="take" body=base kao=2 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=13 as=on ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:takeru:]
「明天之前必须把所有东西都搬到主楼去。[rhr]
_　你居然还能这么悠闲地说出这种话。真不敢相信」[rhp]

[:tiaki:]
「整理东西时无意间翻开书，结果就停不下来了。[rhr]
_　你、你们看。大家不都这样吗？应该都有这种经历吧」[rhp]

[off_take]
[chara_part name="jet" body=prain kao=3 as=off ss=off hh=off hr=on hr=on3 ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="true" time=150]

[:jet2:][jet body=prain kao=2 hr=on3]
「超常见」[rhp]

[:tiaki:][tiaki kao=14 ]
「不愧是杰特君。果然很懂米卡亲呢」[rhp]
[:tiaki:][tiaki kao=6 as=on ]
「相比之下医生就。喂～～～？」[rhp]

[:jet2:][jet body=prain kao=13 hr=on3]
「喂～～～」[rhp]

[off_all]

[:takeru:][take kao=2 as=on ]
「是是……」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:takeru:][take kao=1 ]
「……比起这个，今天的主角应该是你吧」[rhp]

[off_all]

[::]
矢部医生突然正色转向杰特。[rhp]

[chara_part name="take" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="jet" body=prain kao=1 as=off ss=off hh=off hr=on hr=on3 ]
[chara_show name="jet" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:takeru:]
「恭喜考上高中，杰特君」[rhp]

[:jet2:][jet body=prain kao=14 hr=on3]
「嘿嘿……！啊，谢啦！」[rhp]

[off_take]
[chara_part name="sora" body=prain kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="true" time=150]

[:sora:][sora body=prain kao=1 ]
「那个杰特居然啊。真是感慨万分」[rhp]

[:jet2:][jet body=prain kao=6 hr=on3]
「你这话什么意思」[rhp]

[:sora:][sora body=prain kao=1 ]
「字面意思啦。听说你要重考时我就很吃惊，[rhr]
_　没想到真能考上」[rhp]

[:jet2:][jet body=prain kao=11 hr=on3]
「哼哼，毕竟觉醒后三年都没事可做。考上也是理所当然啦」[rhp]

[off_sora]
[chara_part name="tiaki" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="208" top="0" wait="true" time=150]

[:tiaki:][tiaki kao=5 hh=on ]
「19岁的高一新生……！同学们肯定都为你着迷吧！」[rhp]

[:jet2:][jet body=prain kao=5 hr=on3]
「我对那种事没兴趣」[rhp]

[:tiaki:][tiaki kao=6 ]
「呣。没意思……」[rhp]

[off_tiaki]

[chara_part name="take" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]

[:takeru:][take kao=0 ]
「真心祝贺你。这是你重获新生的第一步」[rhp]

[:jet2:][jet body=prain kao=1 hr=on3]
「多亏了医生。要不是你始终不放弃拯救我，就不会有现在的我」[rhp]

[:takeru:][take kao=3 ]
「快住手。你的病情好转并不是我的功劳」[rhp]

[:jet2:][jet body=prain kao=1 hr=on3]
「我听说了。是老师去主楼周旋，才给我准备了最好的重症监护室。[rhr]
_　如果没有那个，我的身体可能早就撑不住了」[rhp]
[:jet2:][jet body=prain kao=13 hr=on3]
「……多谢了。老师」[rhp]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:takeru:][take kao=0 as=on ]
「……！」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[off_all]

[:tiaki:]
「哎呀老师，你哭了吗？」[rhp]

[off_all]

[:takeru:]
「才、才没哭呢……」[rhp]

[::]
矢部老师边说边擦拭眼角。[rhr]
还是这么容易看透的人啊。[rhp]

[chara_part name="tiaki" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="208" top="0" wait="true" time=150]
[chara_part name="rio" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="rio" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:]
「凛生今年就高中毕业了吧」[rhp]

[:rio:]
「是的。春季开始就是专科学校生了」[rhp]

[:tiaki:][tiaki kao=13 ]
「说服你父母了呢。太好了」[rhp]

[:rio:][rio kao=14 hh=on ]
「嗯……！　虽说用说服这个词都有点不恰当了」[rhp]
[:rio:]
「鼓起勇气开口后，没想到他们爽快就答应了。[rhr]
_　……倒不如说，他们看起来还有点高兴」[rhp]
[:rio:][rio kao=13 hh=on ]
「说是第一次从我嘴里听到想做什么」[rhp]

[off_tiaki]
[chara_part name="take" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]

[:takeru:][take kao=1 ]
「是吗。太好了」[rhp]

[:rio:][rio kao=5 hh=on ]
「嗯……真的太开心了。我绝对要成为西点师」[rhp]
[:rio:][rio kao=14 hh=on ]
「总有一天一定会再来医院送点心的！」[rhp]

[off_take]
[chara_part name="tiaki" body=base kao=3 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="208" top="0" wait="true" time=150]

[:tiaki:][tiaki kao=1 ]
「哎呀！今天没有吗？我还很期待呢」[rhp]

[:rio:][rio kao=13 as=on ]
「呵呵。让你失望了……」[rhp]
[:rio:][rio kao=14 ]
「―――才怪！铛铛！其实早就准备好啦！」[rhp]

[:tiaki:][tiaki kao=14 hh=on ]
「凛生！真厉害～！」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[:takeru:][p_tk_30][take kao=6 ]
「………………」[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:tiaki:][tiaki kao=5 as=on ]
「哈！」[rhp]

[:takeru:][take kao=6 ]
「大美贺小姐在减肥的时候，[rhr]
_　结果在这里一次都没能看到呢……」[rhp]

[:tiaki:][tiaki kao=6 as=on ]
「才、才没有这种事呢。[rhr]
_　凛生君的点心里饱含爱意，所以实质是零卡路里哦」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[off_all]

看着两人和从前毫无变化的关系，我稍稍松了口气。[rhr]
一边漫不经心地听着他们的对话，我一边怀旧地环视室内。[rhp]

……就在这个门厅也发生过许多事情。[rhp]
[player2]正是在这里才真正成为了挚友，[rhr]
也是在这里给夜添了无数麻烦。[rhp]

我的目光停留在绘画版的《糠星夜》上。[rhr]
已经很久没见过身为付丧神的他了。[rhp]

[chara_part name="sora" body=prain kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="take" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sora:]
「夜也要去主楼对吧」[rhp]

[:takeru:][take kao=0 ]
「是啊。其实因为找不到安置场所被婉拒过……」[rhp]
[:takeru:][take kao=12 as=on ]
「…………多亏某人一句话才顺利解决」[rhp]

[:sora:][sora body=prain kao=1 ]
「某人？」[rhp]

[off_all]

[::]
脑海中最先浮现南的面孔。[rhr]
托南的福……？不，应该不至于吧。[rhp]

[:tiaki:][tiaki kao=13 ]
「不是某人啦，是米卡亲的一句话啦～」[rhp]

[off_all]

[:sora:][sora body=prain kao=0 as=on ]
「嗯？」[rhp]

[off_all]

[chara_part name="take" body=base kao=0 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:]
「真是的老师，请不要把我和他相提并论。[rhr]
_　我可比南漂亮能干得多呢」[rhp]

[:takeru:][take kao=11 ]
「麻烦程度倒是半斤八两呢」[rhp]

[off_take]
[chara_part name="jet" body=prain kao=1 as=off ss=off hh=off hr=on hr=on3 ]
[chara_show name="jet" layer="1" width="437" height="720" left="208" top="0" wait="true" time=150]

[:jet2:][jet body=prain kao=0 hr=on3]
「怎么回事？是说米卡亲事先打点好了吗？」[rhp]

[:tiaki:][tiaki kao=5 ]
「哎呀，你不知道吗？关于米卡亲的传闻。还挺有名的呢♡」[rhp]
[:tiaki:][tiaki kao=13 ]
「其实我是这家大学医院院长的孙女哦♡」[rhp]

[off_all]

[chara_part name="sora" body=prain kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="take" body=base kao=12 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="rio" body=base kao=4 as=on ss=off hh=off hr=on ]
[chara_show name="rio" layer="1" width="437" height="720" left="720" top="0" wait="true" time=150]

[:rio:][rio kao=1 ]
「这、这种事我还是第一次听说！」[rhp]

[:sora:][
「怎么想都只是传闻吧？」[rhp]

[:takeru:][take kao=6 ]
「是真的」[rhp]

[off_all]

[:2nin:]
「！！」[rhr]
「！！」[rhp]

[off_all]

[chara_part name="tiaki" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="jet" body=prain kao=2 as=on ss=off hh=off hr=on hr=on3 ]
[chara_show name="jet" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:jet2:]
「这不就是超级大小姐吗……」[rhp]

[:tiaki:]
「大美贺是母亲的姓氏。嫌麻烦才用这个姓的。[rhr]
_　当护士明明是靠自己的实力，却被人说是靠家族光环，实在无法忍受」[rhp]
[:tiaki:][tiaki kao=13 ]
「但唯独这次我要尽情使用这种特权！[rhr]
_　就说这是爷爷送给我的珍贵画作嘛～♡」[rhp]

[off_jet]
[chara_part name="rio" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="rio" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:rio:]
「难道这幅画是米卡小姐的爷爷画的吗？」[rhp]

[:tiaki:][tiaki kao=1 ]
「没错，他从前就以画画为爱好。[rhr]
_　主楼里到处都挂着他的画，但这幅的水准截然不同」[rhp]
[:tiaki:]
「据说是在祖母去世后完成的。[rhr]
_　然后由我继承了下来。作为就业礼物呢」[rhp]

[off_rio]
[chara_part name="take" body=base kao=5 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:takeru:]
「难怪夜对你特别纵容」[rhp]

[:tiaki:][tiaki kao=6 ]
「因为我长得像祖母嘛♡」[rhp]

[off_all]

[:jet2:][jet body=prain kao=1 hr=on3]
「……不过太好了。[rhr]
_　这样一来夜和南也能齐聚主楼了呢」[rhp]

[off_all]

[chara_part name="tiaki" body=base kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="rio" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="rio" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:]
「嗯。小努西被洗得干干净净，就像新的一样了呢。[rhr]
_　那三人组也一起，终于能全体搬新家了」[rhp]

[:rio:]
「这样啊……大家都和他们一起旅行，还聊过天呢」[rhp]
[:rio:]
「听说异世界的时候确实吓了一跳，[rhr]
_　不过既然是两位恩人，那我也很开心」[rhp]
[:rio:]
「……要是那个不是我的我，也能稍微派上点用场就好了」[rhp]

[:tiaki:][tiaki kao=13 ]
「放心啦。他可是个非常开朗可靠的男孩子哦」[rhp]

[:rio:][rio kao=13 hh=on ]
「嘿嘿……！那就好！」[rhp]

[off_all]

[chara_part name="sora" body=prain kao=1 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="jet" body=prain kao=1 as=off ss=off hh=off hr=on hr=on3 ]
[chara_show name="jet" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:jet2:]
「如果没那个世界，现在的我和宙肯定都不存在。[rhr]
_　虽然经历了很多，但现在真的只有感激」[rhp]

[:sora:]
「没错」[rhp]
[:sora:][sora body=prain kao=11 ]
「…………好事也好悲伤的事也好，确实经历了太多」[rhp]

[off_all]

[:rio:][rio kao=0 ]
「…………那个，话说回来」[rhp]

[off_all]

[:rio:]
「这幅画上的这个是……」[rhp]

;****************************************
[s_image layer="2" page="back" storage="ct/f_1.png" width="1260" left="10" top="40" name="nov"]
[s_trans layer="2" time=1000]
[wt]
;****************************************

[::]
顺着凛生指的位置凝视，发现我当初被血弄脏的油画部分[rhr]
被加涂成黑色，上面还用白色蜡笔写着字。[rhp]

[:sora:]
「名字？……！」[rhp]
[:sora:]
「……这是，那些家伙的。连薰的名字也……」[rhp]

;****************************************
[s_freeimage layer="2" ]
;****************************************

[:takeru:][take kao=6 ]
「是大美贺小姐一伙干的」[rhp]

[off_all]

[chara_part name="take" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:]
「真是的，什么一伙呀！」[rhp]

[:takeru:]
「但事实如此吧？唆使孩子们做这种事。[rhr]
_　要不是被威胁，我也不会做这么愧疚的事」[rhp]

[off_take]
[chara_part name="rio" body=base kao=3 as=on ss=off hh=off hr=on ]
[chara_show name="rio" layer="1" width="437" height="720" left="208" top="0" wait="true" time=150]

[:rio:]
「这不是爷爷重要的画作吗？」[rhp]

[:tiaki:][tiaki kao=5 ]
「没关系没关系。虽然拜托爷爷帮忙修补过，[rhr]
_　但只是原样修复的话不是很无趣吗？」[rhp]
[:tiaki:][tiaki kao=14 ]
「所以说啊，想画点银河站团队羁绊之类的东西！[rhr]
_　干脆画在大家都能看到的地方吧！」[rhp]

[off_rio]
[chara_part name="take" body=base kao=6 as=off ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]

[:takeru:]
「夜君就是因为这个生气的吧……」[rhp]

[:tiaki:]
「只是被瞪了一眼啦。倒没被训话」[rhp]

[off_all]

[:tiaki:][tiaki kao=1 ]
「对了！机会难得你们三个也来画吧。[rhr]
_　爷爷也说了可以随意发挥哦！」[rhp]

[off_all]

[chara_part name="sora" body=prain kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="rio" body=base kao=13 as=on ss=off hh=off hr=on ]
[chara_show name="rio" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:sora:]
「不不不」[rhp]

[:rio:]
「这、这也太」[rhp]

[off_all]

[:jet2:][jet body=prain kao=13 hr=on3]
「用蜡笔就行了吗？」[rhp]

[off_all]

[chara_part name="sora" body=prain kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="80" top="0" wait="false" time=150]
[chara_part name="jet" body=prain kao=0 as=off ss=off hh=off hr=on hr=on3 ]
[chara_show name="jet" layer="1" width="437" height="720" left="421" top="0" wait="false" time=150]
[chara_part name="rio" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="rio" layer="1" width="437" height="720" left="760" top="0" wait="true" time=150]

[:2nin:]
「杰特！」[rhr]
「杰特君！」[rhp]

[:jet2:][jet body=prain kao=5 hr=on3]
「这种既像要挨骂又不会真挨骂的事可不多见！[rhr]
_　趁还能糊弄过去你们也快来画！」[rhp]

[:rio:]
「可再怎么说也太乱来了……！」[rhp]

[off_all]

[:sora:][sora body=prain kao=7 ]
「………………有点道理」[rhp]

[off_all]

[chara_part name="sora" body=prain kao=7 as=off ss=off hh=off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="rio" body=base kao=2 as=on ss=off hh=off hr=on ]
[chara_show name="rio" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:rio:]
「宙君？难道说……」[rhp]

[:sora:]
「当成石膏签名那种性质的话，倒也不是不行」[rhp]
[:sora:][sora body=prain kao=13 ]
「……顺便问下，画什么都可以吗？」[rhp]

[off_rio]
[chara_part name="tiaki" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:]
「当然！图画或文字都随你喜欢！[rhr]
_　我觉得夜君肯定也更喜欢热闹点的」[rhp]

[:sora:][sora body=prain kao=14 ]
「确实。那家伙看起来朋友很少的样子」[rhp]
[:sora:][sora body=prain kao=5 ]
「……好！我这就来画幅杰作吧」[rhp]

[off_all]

[:rio:][rio kao=2 as=on hh=on ]
「真的没问题吗，真是的～～～……！」[rhp]
[:rio:][rio kao=6 as=on hh=on ]
「………………大、大家都画的话我也画！」[rhp]

[off_all]

[chara_part name="take" body=base kao=6 as=on ss=off hh=off hr=on ]
[chara_show name="take" layer="1" width="437" height="720" left="208" top="0" wait="false" time=150]
[chara_part name="tiaki" body=base kao=13 as=off ss=off hh=off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" left="645" top="0" wait="true" time=150]

[:tiaki:]
「唔呼呼♡　很好很好～！」[rhp]

[:takeru:]
「真是的……」[rhp]

[off_all]

;****************************************
[fbgm]
[still storage="cg/f_2.png" rule="007.png" width="1280" height="720" time=1000]
[cg storage="cg/f_2.png"]
[bgm storage="bgm_41.ogg"]
;****************************************

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:jet2:]
「宙，没想到你画画还不错」[rhp]

[:sora:]
「我做什么都能拿到及格分以上哦」[rhp]

[:rio:]
「呵呵，好厉害……！」[rhp]

;****************************************
[image layer="2" page="back" storage="ct/f_1b.png" width="1260" left="10" top="40" name="nov"]
[trans layer="2" time=1000]
[cg storage="ct/f_1b.png"]
[wt]
;****************************************

[:rio:]
「…………这是？」[rhp]

[::]
理央所指的，是长发两人组。[rhr]
是应杰特要求画的。[rhp]
当理央注意到这点时，杰特得意地说道。[rhp]

[:jet2:]
「这两个是南和夜」[rhp]　
[:jet2:]
「是神明，也是挚友」[rhp]

;****************************************
[freeimage layer="2" time="1000"]
;****************************************
[still_end frame="win2.png" storage="hsps_02.jpg" time=1000]
;人外の透明フィルター
[filter layer="1" name="sausu" opacity=50]
[filter layer="1" name="yoru" opacity=50]
;****************************************

[chara_part name="sausu" body=base kao=13 as=off ss=off hh=on hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" left="60" top="0" wait="false" time=150]
[chara_part name="yoru" body=base kao=11 as=off ss=off hh=off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" left="530" top="0" wait="true" time=150]

[:yoru:]
「哼」[rhp]

[:sausu:]
「嘿嘿……！」[rhp]

[off_all]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[resetfont]
[vostop]
;------------------------------------------------------------------------------------------

[:sora:][sora body=prain kao=0 ]
「…………？」[rhp]

[off_all]

[::]
隐约间似乎听到了夜他们的声音。[rhp]
稍稍侧耳倾听，却再听不到类似的声音或气息。[rhp]
是错觉吗……？嘛，也是当然的。[rhp]

;****************************************
[bg storage="sky_05.jpg" time=1000]
;****************************************

直到现在，偶尔仍会想起那段如梦般的日子。[rhp]

那些离开了那个世界的[player2]家伙们，应该过得不错吧。[rhr]
和近有没有成功戒掉懒散的习惯呢。[rhp]
还有同样选择了转生的沃尔佩克拉。[rhr]
留在铁道上的夸德里利昂们。[rhp]
仿佛昨日之事般，仍能清晰忆起他们的身影。[rhp]

;------------------------------------------------------------------------------------------
;▼再開▼
[vostart]
;------------------------------------------------------------------------------------------

[:sora:]
[font color=0x4682b4]
（……虽然和大家天各一方，[rhr]
_　肯定再也没机会和他们说话了）[rhp]
[:sora:]
（但是，没关系）[rhp]
[resetfont]

;------------------------------------------------------------------------------------------
;▲一時停止▲
[vostop]
;------------------------------------------------------------------------------------------

[::]
胸口的疼痛恐怕永远不会痊愈吧。[rhp]
这样也行。[rhr]
这样就可以了。[rhp]
与伤痕共存的，确有被铭刻之物。[rhp]

;****************************************
[bg storage="sky_12.jpg" time=2000]
;****************************************

银河铁道驰骋于夜空。[rhp]
数千条银河。[rhr]
穿越数亿星辰。[rhp]

直至宇宙尽头，描绘奇迹。[rhp]

;****************************************

[s_mask color=0xffffff time=3000]

; メッセージウィンドゥ非表示
[anim name="message_outer" time=500 opacity=" 0"]
; メニューアイコン非表示
[hidemenubutton]

[bg storage="title/title_7a.png" time=100]

[s_mask_off time=3000]

[p]
[bg storage="white.jpg" time=1000]
[bg storage="title/title_7b.png" time=1500]

[p]

[bg storage="white.jpg" time=1000]
[bg storage="title/title_7c.png" time=1500]

[p]

[bg storage="white.jpg" time=1000]
[bg storage="title/title_7d.png" time=1500]

[p]


[bg storage="white.jpg" time=1000]
[bg storage="title/title_7e.png" time=1500]

[p]

;****************************************
[s_mask color=0xffffff time=3000]
[fbgm]
[bg storage="black.jpg" time=100]
[s_mask_off time=3000]
;****************************************

;-----------------------------------------------------------
[movie storage="ed2.webm" skip="false" volume="30"]
[bg storage="black.jpg" time=200]

;-----------------------------------------------------------
;-----------------------------------------------------------

;エンドフラグ
[eval exp="sf.f_end = 1"]

[fbgm]
[mask time=2000]
[cancelskip]


[jump storage="title.ks" target="*start_end"]

[s]