﻿;--------------------------------------------------
;■黒十　本文テキスト　ep0 懐古趣味の回顧録　
;--------------------------------------------------
;
;■ep0_scene06
;
;--------------------------------------------------
;シナリオ分岐の設定
;
;▼コレクションを見る
;　花器　f.collection_vase=1
;　メダル　f.collection_medal=1
;　リトグラフ　f.collection_lithograph=1
;　手鏡　f.collection_mirror=1
;
;
;▼詳細を見る
;　花器　f.search_vase=1
;　メダル　f.search_medal=1
;　リトグラフ　f.search_lithograph=1
;　手鏡　f.search_mirror=1
;
;--------------------------------------------------

;BGM再生
[bgm ogg="kaiko.ogg"]

;背景　展示室
[bg10 bg="exhibition_room.jpg"]

;--------------------------------------------------
*060000
[savetitle text="コクトー、教えて"]
;--------------------------------------------------

[kokutou_真顔_c]
[ric_f cg="kokutou"]

[yuzuha_s_真顔_c]
[lec cg="yuzuha_s"]


;テキストウィンドウ表示
[start_text]

在展示的收藏品前只是沉默着。[p]

就我个人而言，关于已经消失的那些收藏品[r]　
说实话，调查也没有什么意义。[p]

而且说到底，那种东西是否真的存在也值得怀疑。[p]

一般都会认为最初就不存在吧。[p]

但是。[p]

[vo vo="ep0/yuzuha_0135.ogg"]
[yuzuha_s_疑問]
#【小仓 柚叶】
「呐，爷爷的宝贝都去哪儿了呀？」[p]
[yuzuha_s_疑問_c]
#
这个少女一旦在意起来就停不下来。[p]

[vo vo="ep0/yuzuha_0136.ogg"]
[yuzuha_s_疑問]
#【小仓 柚叶】
「科克托，告诉我嘛，爷爷的宝贝[r]　
　是连房间一起消失了吗？」[p]
[yuzuha_s_疑問_c]
#
从刚才开始就一直这样。[p]

实在吃不消。[p]

[vo vo="ep0/koku_0221.ogg"]
[kokutou_呆れ]
#【黒十 美鹤】
「哈啊，那种事我可不知道哦」[p]
[kokutou_呆れ_c]

[vo vo="ep0/yuzuha_0137.ogg"]
[yuzuha_s_疑問]
#【小仓 柚叶】
「连科克托也不知道吗？」[p]
[yuzuha_s_疑問_c]

[vo vo="ep0/koku_0222.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「嗯，不知道」[p]
[kokutou_真顔_c]

[vo vo="ep0/yuzuha_0138.ogg"]
[yuzuha_s_真顔]
#【小仓 柚叶】
「……那知道了要告诉我哦」[p]
[yuzuha_s_真顔_c]
#
说完这话，少女就直勾勾地继续盯着这边。[p]

[vo vo="ep0/koku_0223.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「……唔……！」[p]
[kokutou_哀]
#
转过身子移开视线。[p]

但马上又绕过来，再次把脸凑近窥视。[p]

终于忍无可忍地出声。[p]

[vo vo="ep0/koku_0224.ogg"]
[kokutou_怒]
#【黒十 美鹤】
「从刚才开始到底要怎样……！」[p]
[kokutou_怒_c]

[vo vo="ep0/yuzuha_0139.ogg"]
[yuzuha_s_疑問]
#【小仓 柚叶】
「科克托，搞清楚房间和宝物消失的原因了吗？」[p]
[yuzuha_s_疑問_c]

[vo vo="ep0/koku_0225.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「哈？」[p]
[kokutou_疑問_c]

[vo vo="ep0/yuzuha_0140.ogg"]
[yuzuha_s_真顔]
#【小仓 柚叶】
「因为你明明说过知道的话就会告诉我」[p]
[yuzuha_s_真顔_c]

[kokutou_驚き_c]

#
少女的话让我哑口无言。[p]

[kokutou_呆れ_c]

甚至想双手抱头。[p]

为什么会变成这样。[p]

[vo vo="ep0/koku_0226.ogg"]
[kokutou_呆れ]
#【黒十 美鹤】
「哈啊……饶了我吧……」[p]
[kokutou_呆れ_c]


;全キャラ削除
[allc]

[kokutou_哀_c]
[ri_f cg="kokutou"]

[yuzuha_s_真顔_c]
[ce_f cg="yuzuha_s"]

[azuha_微笑]
[le cg="azuha"]

[vo vo="ep0/azuha_0102.ogg"]
#【小仓 杏叶】
「看来相当受欢迎呢」[p]
[azuha_微笑_c]

#
说着这话出现的是少女的姐姐小仓杏叶。[p]

看来这对姐妹是想彻底折磨我。[p]

[vo vo="ep0/koku_0227.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「饶了我吧」[p]
[kokutou_哀_c]

[vo vo="ep0/azuha_0103.ogg"]
[azuha_微笑]
#【小仓 杏叶】
「只要你不回答柚叶的问题，这孩子就会一直说下去哦？」[p]
[azuha_微笑_c]

[vo vo="ep0/koku_0228.ogg"]
[kokutou_呆れ]
#【黒十 美鹤】
「为什么我要……清单明明已经确认完了」[p]

[vo vo="ep0/koku_0229.ogg"]
[kokutou_哀2]
#【黒十 美鹤】
「我觉得工作已经做得够多了吧？」[p]
[kokutou_哀2_c]

[vo vo="ep0/azuha_0104.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「连平时看不到的祖父收藏品都让你随便观赏了」[p][azuha_悪い笑顔]

[vo vo="ep0/azuha_0105.ogg"]
#【小仓 杏叶】
「这点小事都不愿配合是不是太不够意思了？」[p]
[azuha_悪い笑顔_c]

#
确实，世上再难找到能展出如此多珍品的地方。[p]

能亲眼目睹全部实物[r]　
不得不说是难得的体验。[p]

但自从来到这座孤岛后的精神消耗[r]　
实在是难以估量。[p]

[vo vo="ep0/azuha_0106.ogg"]
[azuha_呆れ]
#【小仓 杏叶】
「唉……」[p]
[azuha_呆れ_c]
#
看到我愁眉苦脸的样子，小仓杏叶轻轻叹了口气。[p]

[kokutou_驚き_c]

于是，对方将脸贴近我的耳畔低声细语。[p]

[vo vo="ep0/azuha_0107.ogg"]
[azuha_微笑]
#【小仓 杏叶】
「莫非忘了昨晚我救你的恩情？」[p]

[vo vo="ep0/azuha_0108.ogg"]
[azuha_悪い笑顔]
#【小仓 杏叶】
「而且，要是被人知道你在深夜强行闯入我的房间」[r]　
　「你觉得会怎样？」[p]
[azuha_悪い笑顔_c]
#
[kokutou_呆れ_c]
光是想象就让我脊背发寒。[p]

这是何等可怕的发言啊。[p]

[vo vo="ep0/koku_0230.ogg"]
[kokutou_哀2]
#【黒十 美鹤】
「可、可是放我进房间的不是你吗……！」[p]
[kokutou_哀2_c]

[vo vo="ep0/azuha_0109.ogg"]
[azuha_悪い笑顔]
#【小仓 杏叶】
「哎呀是吗？不过呢，比起你的说辞，作为小仓家长女的我所说的话……」[p]

[vo vo="ep0/azuha_0110.ogg"]
#【小仓 杏叶】
「你觉得大家会更相信谁呢……呵呵呵」[p]
[azuha_悪い笑顔_c]
#
这是威胁。[p]

这根本就是完美的胁迫行为。[p]

我带着质疑的目光望向眼前的女人。[p]

但她的态度丝毫没有动摇。[p]

[vo vo="ep0/azuha_0111.ogg"]
[azuha_微笑]
#【小仓 杏叶】
「好啦美鹤，快点做决定」[p]
[azuha_微笑_c]
#
我在脑中飞速思考对策。[p]

但令人遗憾的是[r]　
此时摆在我面前的选择只有一个。[p]

[vo vo="ep0/koku_0231.ogg"]
[kokutou_呆れ]
#【黒十 美鹤】
「咕、呜呜呜……哈啊」[p]
[kokutou_呆れ_c]
#
我长叹一声，决定放弃抵抗。[p]

[vo vo="ep0/koku_0232.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「只是考虑看看……真的只是考虑哦？」[p]
[kokutou_哀_c]

[vo vo="ep0/azuha_0112.ogg"]
[azuha_微笑]
#【小仓 杏叶】
「你明白就好」[p]
[azuha_微笑_c]
#

既然如此，还是赶快随便找个答案搪塞过去吧。[p]

否则我的精神和肉体恐怕都要撑不住了。[p]

;BGM停止
[bgm_end3]

;--------------------------------------------------
*060100
[savetitle text="考えられる可能性"]
;--------------------------------------------------

;BGM再生
[bgm ogg="tukikage.ogg"]

[vo vo="ep0/koku_0233.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「好了，有些事情不得不考虑……」[p]
[kokutou_真顔_c]

[vo vo="ep0/yuzuha_0141.ogg"]
[yuzuha_s_興味]
#【小仓 柚叶】
「爷爷的宝贝连房间一起消失了？」[p]
[yuzuha_s_興味_c]

[vo vo="ep0/koku_0234.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「对，就是这件事……」[p]
[kokutou_真顔_c]
#
结论而言，这是不可能的。[p]

那么，为何清单上记载的绘画和房间会不存在。[p]

[vo vo="ep0/koku_0235.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「或许是房间名称中途变更了？」[p]
[kokutou_真顔_c]

[azuha_真顔_c]
[yuzuha_s_疑問_c]

#
若是如此，清单记载的秋霖之间[r]　
这个房间便会消失。[p]

[vo vo="ep0/yuzuha_0142.ogg"]
[yuzuha_s_疑問]
#【小仓 柚叶】
「房间名称……变更了……是这样吗？」[p]
[yuzuha_s_疑問_c]

[vo vo="ep0/azuha_0113.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「很遗憾并非如此」[p]
[azuha_真顔_c]
#
小仓杏叶明确否定了我的想法。[p]

[vo vo="ep0/azuha_0114.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「房间名称是祖父决定的」[p]

[vo vo="ep0/azuha_0115.ogg"]
#【小仓 杏叶】
「未经那位祖父许可就更改房间名称绝不可能」[p]
[azuha_真顔_c]

[vo vo="ep0/koku_0236.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「不可是――」[p]

[vo vo="ep0/azuha_0116.ogg"]
[azuha_呆れ2]
#【小仓 杏叶】
「绝无可能」[p]
[azuha_呆れ2_c]
[kokutou_哀_c]

#
擅自篡改小仓家族成员的言辞是行不通的。[p]
[azuha_真顔_c]

她如此断言道。[p]

但继续纠缠这点也无济于事。[p]

只能另寻思路了。[p]

[vo vo="ep0/koku_0237.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「那么……这个房间从一开始就不存在」[p]
[kokutou_真顔_c]

[vo vo="ep0/yuzuha_0143.ogg"]
[yuzuha_s_疑問]
#【小仓 柚叶】
「从一开始？」[p]
[yuzuha_s_疑問_c]

[vo vo="ep0/koku_0238.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「对，换言之这份清单本身存在错误」[p]
[kokutou_真顔_c]
#
本就不存在之物，又如何能寻得。[p]

认定这幅画和房间自始未曾存在才最合理。[p]

[vo vo="ep0/azuha_0117.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「遗憾，那个也不对」[p]
[azuha_真顔_c]

[vo vo="ep0/koku_0239.ogg"]
[kokutou_哀2]
#【黒十 美鹤】
「呜咕……」[p]
[kokutou_哀2_c]

[vo vo="ep0/azuha_0118.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「我也怀疑过所以让人重新确认了」[p]

[vo vo="ep0/azuha_0119.ogg"]
[azuha_呆れ2]
#【小仓 杏叶】
「但结果相同……[r]　
　连以前制作的清单也让人取来了　还是不行」[p]

[vo vo="ep0/azuha_0120.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「秋霖之厅和其画作在所有清单上都有记载」[p]
[azuha_真顔_c]

[vo vo="ep0/koku_0240.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「也就是说……这份清单出错的可能性极低……吗」[p]
[kokutou_疑問_c]

[vo vo="ep0/azuha_0121.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「正是如此」[p]
[azuha_真顔_c]
#
名称不曾中途变更[r]　
清单记录也没有谬误。[p]

若还有其他可能性的话――。[p]

[vo vo="ep0/koku_0241.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「莫非……密室？」[p]
[kokutou_疑問_c]
#
这栋宅邸是否存在密室的可能性。[p]

这类清单虽有记载[r]　
实际却遍寻不得的房间。[p]

若是如此 因未能发现隐匿之室[r]　
便如同消失般无从寻觅。[p]

[vo vo="ep0/azuha_0122.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「密室……倒也不能断言不存在呢」[p]
[azuha_真顔_c]
#
看来难以完全否定密室的可能性。[p]

[vo vo="ep0/yuzuha_0144.ogg"]
[yuzuha_s_疑問]
#【小仓 柚叶】
「密室……密室是什么？」[p]
[yuzuha_s_疑問_c]

[vo vo="ep0/koku_0242.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「就是用来藏人或藏物的房间」[p]

[vo vo="ep0/koku_0243.ogg"]
#【黒十 美鹤】
「秋霖之厅或许并未消失 只是被隐藏起来了」[p]
[kokutou_真顔_c]

[vo vo="ep0/yuzuha_0145.ogg"]
[yuzuha_s_微笑]
#【小仓 柚叶】
「噢，原来如此！科克托超厉害！」[p]

[vo vo="ep0/yuzuha_0146.ogg"]
[yuzuha_s_疑問]
#【小仓 柚叶】
「……咦？那那个房间究竟藏在哪里？」[p]
[yuzuha_s_疑問_c]

[vo vo="ep0/koku_0244.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「现在就要开始找那个了哟」[p]
[kokutou_真顔_c]

#
话虽如此[r]　
但在这座广袤无边的宅邸里无头苍蝇般乱找也无济于事。[p]

回想着这两天是否遇到过什么可疑之处。[p]

[vo vo="ep0/koku_0245.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「……有什么……可疑的地方呢……」[p]
[kokutou_疑問_c]
#
正思索时，与脚边静静凝视着的少女四目相对。[p]

[vo vo="ep0/yuzuha_0147.ogg"]
[yuzuha_s_疑問]
#【小仓 柚叶】
「……嗯？」[p]
[yuzuha_s_疑問_c]
#
看到歪着头的少女，突然灵光一闪。[p]

确实有件难以理解的事。[p]

[vo vo="ep0/koku_0246.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「说不定那里就……」[p]
[kokutou_真顔_c]

[vo vo="ep0/azuha_0123.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「你心里已经有密室的位置了吧」[p]
[azuha_真顔_c]

[vo vo="ep0/koku_0247.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「是的，请随我来」[p]
[kokutou_真顔_c]
#

;背景　屋敷内　隠し扉がある廊下
[bg10 bg="hallway_4.jpg"]

于是来到昨夜少女长久伫立之处。[p]

[vo vo="ep0/yuzuha_0148.ogg"]
[yuzuha_s_真顔]
#【小仓 柚叶】
「啊，这里……」[p]
[yuzuha_s_真顔_c]
#
少女轻声惊呼。[p]

这是唯一让我觉得可疑的场所。[p]

[vo vo="ep0/koku_0248.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「……记得是在这附近」[p]
[kokutou_真顔_c]
#
应当有少女当时紧盯着的纹样。[p]

看向墙壁立即就发现了。[p]

[vo vo="ep0/koku_0249.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「找到了，就是这个……只有这面墙上有这种纹样」[p]
[kokutou_微笑_c]
#
用手指触碰那道纹样。[p]

那纹样像是凿刻进墙壁的凹陷。[p]

稍作确认后，敲击纹样周围的墙面。[p]

听着声响确认了猜想。[p]

[vo vo="ep0/koku_0250.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「看来只有这面墙内部存在不自然的间隙呢」[p]
[kokutou_真顔_c]
[azuha_真顔]

[vo vo="ep0/azuha_0124.ogg"]
#【小仓 杏叶】
「原来如此……那就简单了」[p]

[vo vo="ep0/azuha_0125.ogg"]
#【小仓 杏叶】
「赶紧把这种墙砸烂算了」[p]
[azuha_真顔_c]

[vo vo="ep0/koku_0251.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「请、请等一下！」[p]

[vo vo="ep0/koku_0252.ogg"]
#【黒十 美鹤】
「这未免太不妥当了吧」[p]
[kokutou_驚き_c]

[vo vo="ep0/azuha_0126.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「我说可以就没问题」[p]
[azuha_真顔_c]

[vo vo="ep0/koku_0253.ogg"]
[kokutou_怒]
#【黒十 美鹤】
「您觉得可以但我不允许！」[p]
[kokutou_怒_c]
#
这里陈列着令收藏家垂涎的众多收藏品。[p]

而为收集[r]　
并保管这些藏品，第三代家主小仓岩建造了这座宅邸。[p]

搞得不好，仅凭这点就可能让宅邸价值飙升。[p]

我绝不容许眼睁睁看着它被毁坏。[p]

[vo vo="ep0/koku_0254.ogg"]
[kokutou_怒]
#【黒十 美鹤】
「明白吗！？[r]　
　这座宅邸的价值远超您的想象！」[p]
[kokutou_怒_c]

[vo vo="ep0/azuha_0127.ogg"]
[azuha_呆れ]
#【小仓 杏叶】
「啊——好啦好啦，知道了真啰嗦」[p]

[vo vo="ep0/azuha_0128.ogg"]
#【小仓 杏叶】
「那你就快想想这面墙要怎么打开」[p]
[azuha_真顔_c]
#
[kokutou_真顔_c]

太好了。[p]

看来免去了破坏之灾。[p]

疑似隐蔽房间入口的位置已然确定。[p]

但关键的开启方法仍未可知。[p]

[vo vo="ep0/koku_0255.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「嗯……打开门需要的东西是……钥匙吗」[p]

[vo vo="ep0/koku_0256.ogg"]
#【黒十 美鹤】
「能开启这扇门的钥匙……究竟什么才是钥匙……」[p]
[kokutou_疑問_c]

[vo vo="ep0/yuzuha_0149.ogg"]
[yuzuha_s_真顔]
#【小仓 柚叶】
「科克托，你知道吗？」[p]
[yuzuha_s_真顔_c]

[vo vo="ep0/koku_0257.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「恐怕这个纹样……这个凹陷本身就是线索吧」[p]
[kokutou_疑問_c]
#
钥匙究竟在哪里呢。[p]

;■選択肢
;１：少女の手の中
;２：コレクションの中
;３：使用人が隠している

[glink x="266" y="136" graphic="txtlink.png" width="712"  size="28" text="少女の手の中" target="*little_girl"]
[glink x="266" y="249" graphic="txtlink.png" width="712" size="28" text="コレクションの中" target="*collection"]
[glink x="266" y="362" graphic="txtlink.png" width="712" size="28" text="使用人が隠している" target="*employee"]

[s]

;選択肢１、３を選ぶとバッドエンド『古く、苦い記憶』へ
;選択肢２を選ぶと正規ルートへ
;--------------------------------------------------
*little_girl
[savetitle text="少女の手の中"]
;-------------------------------------------------
;選択肢１：少女の手の中


我将目光投向身旁的少女。[p]

[vo vo="ep0/yuzuha_0150.ogg"]
[yuzuha_s_興味]
#【小仓 柚叶】
「科克托？你知道钥匙在哪里吗？」[p]
[yuzuha_s_興味_c]
#
投来充满期待目光的少女。[p]

她手中那个笔记本般的设备。[p]

自相遇时起 这少女就始终珍视地带着它。[p]

而它正是来自[r]　
少女说过这是小仓岩给她的东西。[p]

[vo vo="ep0/koku_0258.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「抱歉 能借我用下这个吗？」[p]
[kokutou_真顔_c]

[vo vo="ep0/yuzuha_0151.ogg"]
[yuzuha_s_疑問]
#【小仓 柚叶】
「咦？这个？」[p]
[yuzuha_s_疑問_c]
#
虽然歪着头表示疑惑 少女还是递了过来。[p]

我拿在手里端详。[p]

但遗憾的是 我对机械一窍不通。[p]

完全不知该如何操作这个看似电子设备的东西。[p]

[vo vo="ep0/yuzuha_0152.ogg"]
[yuzuha_s_興味]
#【小仓 柚叶】
「科克托……难道这就是钥匙吗？」[p]
[yuzuha_s_興味_c]

[vo vo="ep0/koku_0259.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「不 我也只是猜测……」[p]
[kokutou_哀_c]

[vo vo="ep0/yuzuha_0153.ogg"]
[yuzuha_s_疑問]
#【小仓 柚叶】
「光拿着不用的话 平板电脑就没意义了吧？」[p]

[vo vo="ep0/yuzuha_0154.ogg"]
#【小仓 柚叶】
「科克托想用这个做什么呢？」[p]
[yuzuha_s_疑問_c]

[vo vo="ep0/koku_0260.ogg"]
[kokutou_哀2]
#【黒十 美鹤】
「呃……」[p]
[kokutou_哀2_c]

#
面对质问不知该如何回应。[p]

正如少女所言 我到底想用这个做什么呢。[p]

[vo vo="ep0/azuha_0129.ogg"]
[azuha_呆れ]
#【小仓 杏叶】
「哈……看来这样是打不开门的呢」[p]
[azuha_呆れ_c]

[vo vo="ep0/koku_0261.ogg"]
[kokutou_哀2]
#【黒十 美鹤】
「好、好像是这样……抱歉」[p]
[kokutou_哀2_c]

[vo vo="ep0/yuzuha_0155.ogg"]
[yuzuha_s_微笑]
#【小仓 柚叶】
「科克托、试着找找其他钥匙吧！」[p]
[yuzuha_s_微笑_c]

[kokutou_真顔_c]

[azuha_真顔_c]

#
在少女的催促下，我决定寻找其他钥匙。[p]

但无论怎么找，都没发现像样的东西。[p]


;ここまで
;合流へジャンプ

;バッドエンド『古く、苦い記憶』へ
[jump  storage="ep0_scene09.ks"]
[s]

;--------------------------------------------------
*employee
[savetitle text="使用人が隠している"]
;-------------------------------------------------
;選択肢３：使用人が隠している

;BGM停止
[bgm_end3]

[vo vo="ep0/koku_0262.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「说起来那个佣人……」[p]
[kokutou_疑問_c]

;BGM再生
[bgm ogg="kaiko.ogg"]

#
好像是叫须天来着。[p]

我想起昨夜他似乎在可疑地交谈着什么。[p]

[vo vo="ep0/azuha_0130.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「莫非是须天的事吗」[p]
[azuha_真顔_c]

[vo vo="ep0/koku_0263.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「嗯，他说他不知道秋霖之间的事」[p]

[vo vo="ep0/koku_0264.ogg"]
#【黒十 美鹤】
「但果然还是藏了什么吧？」[p]
[kokutou_真顔_c]

[vo vo="ep0/azuha_0131.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「这间密室的钥匙也是须天藏的吗？」[p]
[azuha_真顔_c]

[vo vo="ep0/koku_0265.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「有可能……但他现在在哪里？」[p]
[kokutou_疑問_c]

[vo vo="ep0/azuha_0132.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「我叫他过来……嘛，估计是白费工夫呢」[p]
[azuha_真顔_c]
#
说着她从口袋里取出手机召唤佣人。[p]

;BGM停止
[bgm_end3]

;全キャラ削除
[allc]

;背景　黒背景
;//黒ベタ
[bg20 bg="black.png"]

然而即使把他叫来质问[r]　
最终还是一无所获。[p]

无论我们怎么追问，都得不到任何确凿的证据[r]　
只有时间在不断流逝。[p]


;BGM再生
[bgm ogg="mid_re.ogg"]

;背景　屋敷内　隠し扉がある廊下
[bg10 bg="hallway_4.jpg"]


[kokutou_哀]
[ri_f cg="kokutou"]

[yuzuha_s_真顔_c]
[ce_f cg="yuzuha_s"]

[azuha_真顔_c]
[le cg="azuha"]

[vo vo="ep0/koku_0266.ogg"]
#【黒十 美鹤】
「哈……别说钥匙了，什么情报都没得到啊」[p]
[kokutou_哀_c]
#
看到垂头丧气的我，小仓杏叶投来冰冷的视线。[p]

[vo vo="ep0/azuha_0133.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「所以不是说过了吗，白费力气」[p]
[azuha_真顔_c]

[vo vo="ep0/koku_0267.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「但他可疑这点是不会错的」[p]
[kokutou_哀_c]

[vo vo="ep0/azuha_0134.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「这种事还用不着你告诉我」[p]
[azuha_真顔_c]

[vo vo="ep0/koku_0268.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「那为什么，你们就那样放任他不管呢？」[p]
[kokutou_哀_c]

[vo vo="ep0/azuha_0135.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「我们可不想主动出击露出破绽」[p]

[vo vo="ep0/azuha_0136.ogg"]
#【小仓 杏叶】
「就算是落魄的小仓家佣人……也是受托管理这宅邸的人」[p]

[vo vo="ep0/azuha_0137.ogg"]
#【小仓 杏叶】
「等待对方先行动才是上策」[p]
[azuha_真顔_c]

[vo vo="ep0/koku_0269.ogg"]
[kokutou_哀2]
#【黒十 美鹤】
「是这样吗」[p]
[kokutou_哀2_c]

#
虽然我充满疑惑，但她似乎对此确信不疑。[p]

[vo vo="ep0/azuha_0138.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「只要能证明须天在说谎[r]　
　那家伙就不得不采取行动了」[p]
[azuha_真顔_c]
#
这也就是说，唯有证明秋霖之间确实存在。[p]

但最关键的是钥匙的下落完全不明。[p]


;ここまで
;合流へジャンプ

;バッドエンド『古く、苦い記憶』へ
[jump  storage="ep0_scene09.ks"]
[s]


;正規ルート
;-------------------------------------------------
*collection
[savetitle text="コレクションの中"]
;-------------------------------------------------
;選択肢２：コレクションの中

[vo vo="ep0/koku_0278.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「认为钥匙在收藏品中比较合理吧」[p]
[kokutou_真顔_c]
#
至今检查过的收藏品里应该存在钥匙。[p]

自从来到这宅邸后，我在脑海中回顾检查过的物品。[p]

总该有什么线索才对。[p]

[vo vo="ep0/yuzuha_0163.ogg"]
[yuzuha_s_興味]
#【小仓 柚叶】
「科克托，哪件是钥匙？」[p]
[yuzuha_s_興味_c]
#

;■選択肢
;選択肢「コレクション」で詳しく調べることが出来たもののみ表示される。

;１：トーム ナンジー 作『花器』
;２：村高 幸雲 作『メダル』
;３：サリー ローラン 作『リトグラフ』
;４：作者不明 『ブロンズフレーム　手鏡』

;選択肢「コレクション」で詳しく調べることが出来たもののみ表示される。

;詳しく調べなかったため選択肢がない場合のテキスト

[if exp="f.search_vase==0 && f.search_medal==0 && f.search_lithograph==0 && f.search_mirror==0"]

少女向我发问。[p]

但无论怎么回想都没有类似钥匙的物品印象。[p]

是不是该更仔细检查那些收藏品呢？[p]

;バッドエンドルート『古く、苦い記憶』（ep0_scene09.ks）へ飛ぶ
[jump  storage="ep0_scene09.ks"]

[else]
[jump target="*key_collection"]
[endif]

*key_collection

*collection_1
[if exp="f.search_vase==0"]
[jump target="*collection_2]
[else]
[endif]

[glink width="628" graphic="txtlink.png" enterimg="txtlink_on.png" enterse="cursor1.ogg" clickse="decision5.ogg" size="28" x="266" y="90" target="*mistake1" exp="f.vase=1" text="トーム ナンジー 作『花器』"]

*collection_2
[if exp="f.search_medal==0"]
[jump target="*collection_3]
[else]
[endif]

[glink width="628" graphic="txtlink.png" enterimg="txtlink_on.png" enterse="cursor1.ogg" clickse="decision5.ogg" size="28" x="266" y="180" target="*medal" exp="f.medal=1" text="村高 幸雲 作『メダル』"]

*collection_3
[if exp="f.search_lithograph==0"]
[jump target="*collection_4]
[else]
[endif]

[glink width="628" graphic="txtlink.png" enterimg="txtlink_on.png" enterse="cursor1.ogg" clickse="decision5.ogg" size="28" x="266" y="270" target="*mistake3" exp="f.lithograph=1"  text="サリー ローラン 作『リトグラフ』"]

*collection_4
[if exp="f.search_mirror==0"]
[jump target="*collection_5]
[else]
[endif]

[glink width="628" graphic="txtlink.png" enterimg="txtlink_on.png" enterse="cursor1.ogg" clickse="decision5.ogg" size="28" x="266" y="360" target="*mistake4" exp="f.mirror=1" text="作者不明 『ブロンズフレーム　手鏡』"]

*collection_5

[s]


;選択肢１、３、４を選んだ場合バッドエンド『古く、苦い記憶』へ繋がる
;-------------------------------------------------
*mistake
[savetitle text="コレクションの中"]
;-------------------------------------------------
;選択肢１、３、４を選んだ場合流れるシナリオ

;下記台詞は選択肢１を選んだ場合のみ表示されます
*mistake1
;BGM停止
[bgm_end3]

[vo vo="ep0/koku_0279.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「……汤南杰作品《花器》[r]　
　……或许这就是钥匙」[p]
[kokutou_真顔_c]

[jump target="*mistake_end"]

;下記台詞は選択肢３を選んだ場合のみ表示されます
*mistake3
;BGM停止
[bgm_end3]

[vo vo="ep0/koku_0280.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「……莎莉·罗兰作品《石版画》[r]　
　……或许这就是钥匙」[p]
[kokutou_真顔_c]

[jump target="*mistake_end"]

;下記台詞は選択肢４を選んだ場合のみ表示されます
*mistake4
;BGM停止
[bgm_end3]

[vo vo="ep0/koku_0281.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「……作者不明『青铜框手镜』[r]　
　……这也许就是钥匙」[p]
[kokutou_真顔_c]


*mistake_end
#

;BGM再生
[bgm ogg="kaiko.ogg"]

[vo vo="ep0/yuzuha_0164.ogg"]
[yuzuha_s_微笑]
#【小仓 柚叶】
「那我现在就去拿来！」[p]
[yuzuha_s_微笑_c]


;柚葉消去
[hide_yuzuha_s]

#
少女的话语让小仓杏叶微微瞥了一眼。[p]

[vo vo="ep0/azuha_0139.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「快点拿来把这里打开」[p]
[azuha_真顔_c]

;黒十消去
[hide_kokutou]

#
听到这话，立刻动身去取收藏品。[p]

;全キャラ削除
[allc]


;背景　天井、窓、空とか
[bg10 bg="transfer.jpg"]


[kokutou_哀_c]
[ric_f cg="kokutou"]

[yuzuha_s_真顔]
[lec cg="yuzuha_s"]


[vo vo="ep0/yuzuha_0165.ogg"]
#【小仓 柚叶】
「喂，快点儿快点儿！」[p]
[yuzuha_s_真顔_c]

[vo vo="ep0/koku_0282.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「别这么催我嘛」[p]
[kokutou_哀_c]

#
即将搬运的收藏品绝不能有任何闪失。[p]

要是磕出半点伤痕我这辈子都不会原谅自己。[p]

;全キャラ削除
[allc]


;背景　屋敷内　隠し扉がある廊下
[bg10 bg="hallway_4.jpg"]

[kokutou_真顔_c]
[ri_f cg="kokutou"]

[yuzuha_s_真顔_c]
[ce_f cg="yuzuha_s"]

[azuha_真顔_c]
[le cg="azuha"]


带着被怀疑是钥匙的收藏品返回。[p]

[vo vo="ep0/koku_0283.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「我觉得这个应该是钥匙……」[p]
[kokutou_真顔_c]

[vo vo="ep0/yuzuha_0166.ogg"]
[yuzuha_s_疑問]
#【小仓 柚叶】
「……可要怎么用它打开这里？」[p]
[yuzuha_s_疑問_c]

[vo vo="ep0/koku_0284.ogg"]
[kokutou_哀2]
#【黒十 美鹤】
「那个……」[p]
[kokutou_哀2_c]

;BGM停止
[bgm_end3]

#
试着贴近墙上的纹样却毫无反应。[p]

说不定，这根本不是钥匙。[p]

;BGM再生
[bgm ogg="the_window_overlooking_all_things.ogg"]

[vo vo="ep0/koku_0285.ogg"]
[kokutou_哀2]
#【黒十 美鹤】
「真奇怪啊……」[p]
[kokutou_哀2_c]

[vo vo="ep0/azuha_0140.ogg"]
[azuha_呆れ2]
#【小仓 杏叶】
「哈，果然不行」[p]
[azuha_呆れ2_c]

[vo vo="ep0/koku_0286.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「好像不是这个……要、要是别的藏品的话――」[p]

[vo vo="ep0/azuha_0141.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「够了，依赖你算我愚蠢」[p]
[azuha_真顔_c]

[vo vo="ep0/koku_0287.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「哎、可是其他收藏品肯定――」[p]
[kokutou_驚き_c]

[vo vo="ep0/azuha_0142.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「那下次你保证能打开这里？」[p]
[azuha_真顔_c]

#
这个问题让人陷入沉默。[p]

[vo vo="ep0/azuha_0143.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「这次不行就下次，你是这个意思？」[p]
[azuha_真顔_c]

[vo vo="ep0/koku_0288.ogg"]
[kokutou_呆れ]
#【黒十 美鹤】
「不，并不是那样……」[p]
[kokutou_呆れ_c]

[vo vo="ep0/azuha_0144.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「还是说，你打算把这宅邸里的收藏品全部试一遍？」[p]
[azuha_真顔_c]

[vo vo="ep0/koku_0289.ogg"]
[kokutou_哀2]
#【黒十 美鹤】
「…………」[p]
[kokutou_哀2_c]

[vo vo="ep0/azuha_0145.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「浪费时间……够了快退下吧」[p]
[azuha_真顔_c]
#

;バッドエンド『古く、苦い記憶』へ飛ぶ

[jump  storage="ep0_scene09.ks"]
[s]


;選択肢２を選んだ場合は正規ルートへ
;-------------------------------------------------
*medal
[savetitle text="村高 幸雲 作『メダル』"]
;-------------------------------------------------
;選択肢２：村高 幸雲 作『メダル』

;BGM停止
[bgm_end3]

[vo vo="ep0/koku_0290.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「说起来那时候……」[p]
[kokutou_真顔_c]

;SEを再生する
[se_f se="01.ogg"]

;回想（彫刻家が制作したとされる大きなメダルを見てる時のシーン）
[event_in event="ep0_001"]

[vo vo="ep0/koku_0095.ogg"]
#【黒十 美鹤】
「噢，这沉甸甸的分量真是令人爱不释手……！」[p]

#
表面雕刻的山羊座精妙工艺[r]　
让人不禁发出赞叹。[p]

而背面也刻有美丽的纹样。[p]

[vo vo="ep0/koku_0096.ogg"]
#【黒十 美鹤】
「这纹样是……从未见过呢」[p]
#
;//回想ここまで
[event_out]

;BGM再生
[bgm ogg="tukikage.ogg"]

冷静下来仔细回想[r]　
我岂不是见过与这墙面纹样相似的东西吗。[p]

[vo vo="ep0/koku_0291.ogg"]
[kokutou_疑問]
;村高幸雲（むらたか こううん）
#【黒十 美鹤】
「那确实是村高幸云制作的石徽章……」[p]
[kokutou_疑問_c]

[vo vo="ep0/yuzuha_0167.ogg"]
[yuzuha_s_微笑]
#【小仓 柚叶】
「那就是钥匙……快去取来！」[p]
[yuzuha_s_微笑_c]

;柚葉消去
[hide_yuzuha_s]

[vo vo="ep0/koku_0292.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「啊，请稍等一下！」[p]
[kokutou_驚き_c]

;黒十消去
[hide_kokutou]


#
见少女突然跑开，慌忙追赶其后。[p]

万一摔坏了作品就糟了。[p]

必须万分小心对待。[p]

我暗下决心一定要由我来运送。[p]

;全キャラ削除
[allc]


;背景　展示室
[bg10 bg="exhibition_room.jpg"]


[yuzuha_s_疑問_c]
[lec_f cg="yuzuha_s"]

[kokutou_真顔_c]
[ric cg="kokutou"]

;カットイン表示
[cut_in cut="cut_choice2.png"]

在展览室找到了目标徽章。[p]

[vo vo="ep0/koku_0293.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「记得这背面……」[p]
[kokutou_真顔_c]

#
;メダル裏側のアイコン表示

;カットイン表示
[cut_in cut="cut_choice2_2.png"]

找到了。[p]

上面浮雕着与那墙面完全相同的纹样。[p]

正如所料，这枚徽章似乎就是那面墙的钥匙。[p]

;カットイン削除
[cut_out]

;全キャラ削除
[allc]

;背景　屋敷内　隠し扉がある廊下
[bg10 bg="hallway_4.jpg"]


[kokutou_真顔]
[ri_f cg="kokutou"]

[yuzuha_s_真顔_c]
[ce_f cg="yuzuha_s"]

[azuha_真顔_c]
[le cg="azuha"]

[vo vo="ep0/koku_0294.ogg"]
#【黒十 美鹤】
「我拿来了哦」[p]

[vo vo="ep0/koku_0295.ogg"]
#【黒十 美鹤】
「恐怕这就是隐藏门的钥匙吧」[p]
[kokutou_真顔_c]

[vo vo="ep0/azuha_0146.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「为什么你能断言那就是钥匙呢？」[p]
[azuha_真顔_c]

[vo vo="ep0/koku_0296.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「请看」[p]
[kokutou_微笑_c]

#
展示出带来的徽章背面。[p]

[vo vo="ep0/koku_0297.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「这里描绘的花纹，与这面墙的花纹完全一致」[p]

[vo vo="ep0/koku_0298.ogg"]
#【黒十 美鹤】
「在这座宅邸的收藏品中[r]　
　再也没有其他物品绘有相同花纹了」[p]

[vo vo="ep0/koku_0299.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「也就是说……」[p]
[kokutou_真顔_c]
#
说着将徽章严丝合缝地贴到墙面的花纹上。[p]

如预料般，徽章完美地嵌入了墙壁。[p]

;SE　壁が開く音「ガタン――ゴゴゴゴゴ」[p]

;SEを再生する
[se_f se="kakusitobira_1.ogg"]

[vo vo="ep0/koku_0300.ogg"]
[kokutou_凛]
#【黒十 美鹤】
「这就是开启这扇门的钥匙了」[p]
[kokutou_凛_c]

[vo vo="ep0/yuzuha_0168.ogg"]
[yuzuha_s_笑顔]
#【小仓 柚叶】
「好厉害，真的打开了！」[p]
[yuzuha_s_笑顔_c]
#
看来正如所料，这里就是隐藏房间的入口。[p]

从敞开的墙面处出现了通往地下的阶梯。[p]

阶梯尽头的墙壁上镶嵌着一道门[r]　
其上写着「秋霖之室」。[p]

[vo vo="ep0/koku_0301.ogg"]
[kokutou_凛]
#【黒十 美鹤】
「秋霖之室……果然并非消失无踪呢」[p]
[kokutou_凛_c]

[vo vo="ep0/azuha_0147.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「确实如此呢」[p]
[azuha_真顔_c]
#
小仓杏叶说着推开了门。[p]

伴随着沉闷的声响，门扉立即应手而开。[p]

;BGM停止
[bgm_end3]

;シーン7へ移動
[jump  storage="ep0_scene07.ks"]
[s]