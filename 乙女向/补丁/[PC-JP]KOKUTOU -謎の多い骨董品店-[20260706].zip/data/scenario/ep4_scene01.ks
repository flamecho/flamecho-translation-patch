﻿;--------------------------------------------------
;■黒十　本文テキスト　ep4　鐘塔の幽霊
;--------------------------------------------------
;
;■ep4_scene01
;
;--------------------------------------------------
;シナリオ分岐の設定
[eval exp="f.登らせる=0"]
[eval exp="f.絆創膏=0"]

;OP
[movie storage="op4.webm" skip=true volume="40"]

;--------------------------------------------------
*010000
[savetitle text="同じ曜日。同じ時間。同じ場所。"]
;-------------------------------------------------
[cm]

;BGM再生
[bgm ogg="kasasagi.ogg"]

;//喫茶店
[bg20 bg="cafe01.jpg"]

;テキストウィンドウ表示
[start_text]

到底打算持续这种事情到何时呢。[p]

[bg20 bg="cafe03.jpg"]
不，不是这样。[p]

;イベントＣＧ表示
[event_in event="ep4_1_1"]
这种事情还能持续多久呢。[p]

;//喫茶店


相同的星期几。[p]

相同的时间。[p]

相同的场所。[p]

然后。[p]

;イベントＣＧ表示
[eval exp="sf.cg_ep4_1 = 1"]
[event_in event="ep4_1_2"]

然后――永远等不到来访之人。[p]

;イベントＣＧ表示
[event_in event="ep4_1_3"]

;//白背景
[bg10 bg="white.png"]
[vo vo="ep4/kaguya_0001.ogg"]
#【蓬 辉夜】
「…………哈啊」[p]
#

;//一人喫茶店で物思いにふける輝夜。[p]普段あるはずの懐中時計がない。[p]

;テキストウィンドウ削除
[end_text]

;イベントＣＧ削除
[event_out]

;BGM停止
[bgm_end3]


;//白背景
[bg20 bg="white.png"]

;--------------------------------------------------
*011000
[savetitle text="礼拝堂の噂"]
;-------------------------------------------------

;//礼拝堂　外観・昼
[bg20 bg="chapel_01a.jpg"]

;テキストウィンドウ表示
[start_text]

[vo vo="ep4/hagino_0001.ogg"]
#【萩乃司】
「呃……这些是废品，放到后院深处」[p]

[vo vo="ep4/hagino_0002.ogg"]
#【萩乃司】
「这边是资料，放在玛利亚像旁边」[p]
#
;//礼拝堂　昼
[bg20 bg="chapel_room_01a.jpg"]

;BGM再生
[bgm ogg="church.ogg"]

;輝夜衣装指定
[kaguya_c_冬]

[kaguya_無表情]
[ric_f cg="kaguya"]

[tukasa_真顔_c]
[lec cg="tukasa"]

[vo vo="ep4/kaguya_0002.ogg"]
#【蓬 辉夜】
「这个箱子呢？」[p]
[kaguya_無表情_c]

[vo vo="ep4/hagino_0003.ogg"]
[tukasa_笑顔]
#【萩乃司】
「啊—那是文集所以要保留」[p]
[tukasa_笑顔_c]

[vo vo="ep4/kaguya_0003.ogg"]
[kaguya_思考]
#【蓬 辉夜】
「……全部？留几本处理掉不就好了」[p]
[kaguya_思考_c]

[vo vo="ep4/hagino_0004.ogg"]
[tukasa_笑顔]
#【萩乃司】
「啊—也对……嗯，那就每样留三册吧」[p]
[tukasa_笑顔_c]

[vo vo="ep4/kaguya_0004.ogg"]
[kaguya_呆れ]
#【蓬 辉夜】
「哈啊……真让人担忧未来呢」[p]
[kaguya_呆れ_c]

[vo vo="ep4/hagino_0005.ogg"]
[tukasa_笑顔]
#【萩乃司】
「是吗？[r]　
　我觉得多亏辉夜帮忙才看到收尾的希望」[p]

[vo vo="ep4/hagino_0006.ogg"]
#【萩乃司】
「根本没指望过找人帮忙啊」[p]

[vo vo="ep4/hagino_0007.ogg"]
#【萩乃司】
「最近会靠近这座礼拜堂的只剩怪人们了，呐」[p]
[tukasa_笑顔_c]

[vo vo="ep4/kaguya_0005.ogg"]
[kaguya_無表情]
#【蓬 辉夜】
「啊、因为那个传闻？」[p]
[kaguya_無表情_c]

[vo vo="ep4/hagino_0008.ogg"]
[tukasa_苦笑い]
#【萩乃司】
「果然辉夜也知情呢……真是麻烦事……哎呀呀」[p]
[tukasa_苦笑い_c]

[vo vo="ep4/kaguya_0006.ogg"]
[kaguya_呆れ]
#【蓬 辉夜】
「那种谣言都当真的人才是有问题吧」[p]

[vo vo="ep4/kaguya_0007.ogg"]
[kaguya_無表情]
#【蓬 辉夜】
「比起这个 文集要怎么处理？」[p]
[kaguya_無表情_c]

[vo vo="ep4/hagino_0009.ogg"]
[tukasa_笑顔]
#【萩乃司】
「啊 那个也请放到后院」[p]
[tukasa_笑顔_c]

[vo vo="ep4/kaguya_0008.ogg"]
[kaguya_思考]
#【蓬 辉夜】
「后院啊……等等」[p]

[vo vo="ep4/kaguya_0009.ogg"]
#【蓬 辉夜】
「你刚才说 怪人们？」[p]
[kaguya_思考_c]

[vo vo="ep4/hagino_0010.ogg"]
[tukasa_笑顔]
#【萩乃司】
「嗯～？」[p]

[vo vo="ep4/hagino_0010_1.ogg"]
#【萩乃司】
「……啊— 嗯」[p]

[vo vo="ep4/hagino_0011.ogg"]
#【萩乃司】
「刚才和爱丽丝也在这里聊过这个传闻[r]　
　……有什么问题吗？」[p]
[tukasa_笑顔_c]
#

;テキストウィンドウ削除
[end_text]

;BGM停止
[bgm_end3]

;全キャラ削除
[allc]

;//白背景
[bg20 bg="white.png"]


;--------------------------------------------------
*012000
[savetitle text="黒十骨董品店"]
;-------------------------------------------------

;BGM再生
[bgm ogg="mid_re.ogg"]

;//黒十骨董品店　外観
[bg20 bg="shop_kokutou3.jpg"]

;テキストウィンドウ表示
[start_text]

[vo vo="ep4/yuzuha_0001.ogg"]
#【小仓 柚叶】
「黑十先生您弄错了[r]　
　发消息请用这边的应用程序」[p]
#
在能俯瞰港口的位置静静伫立的古董店KOKUTOU。[p]

今天这个地方也传来熟悉的少女声音。[p]

;//黒十骨董品店　店内
[bg20 bg="antique2.jpg"]

;黒十衣装指定
[kokutou_c_冬]

;柚葉衣装指定
[yuzuha_c_冬]

[kokutou_哀]
[ric_f cg="kokutou"]

[yuzuha_微笑_c]
[lec cg="yuzuha"]

[vo vo="ep4/koku_0001.ogg"]
#【黒十 美鹤】
「哈啊……APP 啊」[p]
[kokutou_哀_c]

#
在收银台前的柜台[r]　
被柚叶君指导着智能手机的使用方法。[p]

最近这已是固定的日常消遣了。[p]

自从收到她赠送的礼物后[r]　
每天都要盯着这个轻薄的最新机器大眼瞪小眼。[p]

[vo vo="ep4/koku_0002.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「说到底智能手机不就是移动电话吗？」[p]

[vo vo="ep4/koku_0003.ogg"]
#【黒十 美鹤】
「明明机器本身自带收发信息和通话功能[r]　
　为什么非要另外用APP来实现这些功能呢？」[p]
[kokutou_哀_c]

[vo vo="ep4/yuzuha_0002.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「使用APP就能免费哦，视频通话也是免费的！」[p]
[yuzuha_微笑_c]

[vo vo="ep4/koku_0004.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「……哈啊，原来如此」[p]
[kokutou_真顔_c]

#
他再次说出这个今天不知重复了多少遍的词。[p]

[vo vo="ep4/yuzuha_0003.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「现在有很多日常生活中能派上用场的便利APP，[r]　
　下载下来绝对不会吃亏的！」[p]
[yuzuha_笑顔_c]

[vo vo="ep4/koku_0005.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「对于最近才刚刚学会正常接电话的我来说，[r]　
　这种事有点难呢」[p]
[kokutou_微笑_c]

[vo vo="ep4/yuzuha_0004.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「没这回事，其实意外地简单哦」[p]

[vo vo="ep4/yuzuha_0005.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「对了，趁着练习的机会不如下载个我在用的APP试试看吧！」[p]

[vo vo="ep4/yuzuha_0006.ogg"]
#【小仓 柚叶】
「等您会用之后，给这家店也创建个账号[r]　
　试着宣传一下怎么样？」[p]
[yuzuha_笑顔_c]

[vo vo="ep4/koku_0006.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「店的账号……？」[p]
[kokutou_疑問_c]

[vo vo="ep4/yuzuha_0007.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「可以用手机拍摄店内的样子上传，[r]　
　或者把入手的古董拍下来分享也不错哦」[p]

[vo vo="ep4/yuzuha_0008.ogg"]
#【小仓 柚叶】
「喜欢这类东西的人看到之后，[r]　
　说不定就会来光顾您的店呢？」[p]
[yuzuha_微笑_c]

[vo vo="ep4/koku_0007.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「原、原来如此……」[p]
[kokutou_驚き_c]

[vo vo="ep4/yuzuha_0009.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「话说回来，黑十先生要不要也试着搜索看看？」[p]

[vo vo="ep4/yuzuha_0010.ogg"]
#【小仓 柚叶】
「虽然我个人没兴趣，不过用古董家具之类的[r]　
　关键词搜索的话，确实会出现相关的内容呢，您看」[p]
[yuzuha_微笑_c]

#
说着柚叶君将手机屏幕展示过来。[p]

[vo vo="ep4/koku_0008.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「噢！？真的哎……！」[p]
[kokutou_微笑_c]

#
最新科技，恐怖如斯。[p]

[vo vo="ep4/yuzuha_0011.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「总之呢，现在有这么多便利功能，请务必好好利用起来」[p]
[yuzuha_微笑_c]

[vo vo="ep4/koku_0009.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「我会考虑的……」[p]
[kokutou_真顔_c]

#
当我这样苦笑着时，注意到店门口有个人影。[p]

;BGM停止
[bgm_end1]

[kokutou_驚き_c]

;//店内の扉が開く音
;SE：扉オープン
[se_f se="door_op.ogg"]

那人径直推开了店门。[p]

看来是位顾客。[p]

[vo vo="ep4/koku_0010.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「欢迎光临」[p]
[kokutou_真顔_c]

#
用和平常一样的语调招呼道。[p]

;SE：足音フェイドイン
[se_f se="footsteps_in.ogg"]

来者是一名少女。[p]

不，或许用少女形容有些过于成熟了？[p]

白皙的肌肤和英气的眉眼，那双瞳孔的颜色[r]　
昭示着她是个混血儿。[p]

不过在这外籍居民众多的港口城市[p]

倒也不算稀奇。[p]

[vo vo="ep4/yuzuha_0012.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「…………咦、咦咦———！？！？」[p]
#
但站在我身旁的柚叶君[r]　
却对突然出现的顾客露出了难以掩饰的惊讶。[p]

[vo vo="ep4/yuzuha_0013.ogg"]
#【小仓 柚叶】
「为为为、为什么，你怎么会在这里！？」[p]
[yuzuha_驚き_c]

;柚葉と黒十一時削除
[kill]

;BGM再生
[bgm ogg="mid_re.ogg"]

;アリス衣装指定
[alice_c_コート]

[alice_笑み]
[ce cg="alice"]

[vo vo="ep4/alice_0001.ogg"]
;//下記、アリスの台詞
#【少女】
「刚见面就大声嚷嚷，[r]　
　还真是热情的问候呢，小仓柚叶」[p]
[alice_笑み_c]

#
游刃有余的笑容和措辞[r]　
让人能想象出她是富家千金。[p]

之所以会这么觉得，大概是因为她身上[r]　
莫名与柚叶君的姐姐有几分相似吧。[p]

[vo vo="ep4/yuzuha_0014.ogg"]
#【小仓 柚叶】
「不、可是最近在学校也完全碰不到面……[r]　
　居然会来这里……！」[p]

[vo vo="ep4/alice_0002.ogg"]
[alice_笑み]
;//下記、アリスの台詞
#【少女】
「这里离学校很近，[r]　
　我来这儿也没什么好奇怪的吧？」[p]
[alice_笑み_c]

[vo vo="ep4/yuzuha_0015.ogg"]
#【小仓 柚叶】
「那个……话是这么说……」[p]
#
柚叶君尴尬地别开视线。[p]

[vo vo="ep4/yuzuha_0016.ogg"]
#【小仓 柚叶】
「但爱丽丝前辈突然出现的话会吓到人的」[p]
#
柚叶君说出了「爱丽丝前辈」这个称呼。[p]

[vo vo="ep4/koku_0011.ogg"]
#【黒十 美鹤】
「爱丽丝……是她？」[p]
#
也就是说她就是从前向柚叶君[r]　
提出御伽俱乐部谜题的那个饴宫爱丽丝啊。[p]

听闻此事后我再次凝视她的身影。[p]

[vo vo="ep4/alice_0003.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「看来不需要自我介绍呢，黑十美鹤」[p]
[alice_笑み_c]

#
她那过度精致的嘴角优雅地扭曲着，[r]　
不知为何用全名称呼我。[p]

[vo vo="ep4/alice_0004.ogg"]
[alice_ドヤ顔]
#【饴宫 爱丽丝】
「听着，有件事要拜托你们」[p]
[alice_ドヤ顔_c]

[vo vo="ep4/koku_0012.ogg"]
#【黒十 美鹤】
「……唉，真是够了」[p]
#
预感自己又要被卷入麻烦事，只能抱头叹息。[p]

;//シーン転換

;テキストウィンドウ削除
[end_text]

;BGM停止
[bgm_end3]

;全キャラ削除
[allc]

;背景
[bg10 bg="white.png"]

;次のシーンへ移動
[jump  storage="ep4_scene02.ks"]

[s]