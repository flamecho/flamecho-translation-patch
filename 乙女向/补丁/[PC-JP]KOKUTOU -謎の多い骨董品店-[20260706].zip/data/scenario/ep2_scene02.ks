﻿;--------------------------------------------------
;■黒十　本文テキスト　ep2　招かれざる常連客
;--------------------------------------------------
;
;■ep2_scene02
;
;--------------------------------------------------
*014000
[savetitle text="なにが変だと言うんですか？"]
;-------------------------------------------------
[cm]


;BGM再生
[bgm ogg="kaiko.ogg"]

;//喫茶店
[bg10 bg="cafe06.jpg"]

[kokutou_真顔_c]
[ric_f cg="kokutou"]
[yuzuha_微笑_c]
[lec cg="yuzuha"]

;テキストウィンドウ表示
[start_text]

[vo vo="ep2/koku_0058.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「所以，您到底觉得哪里不对劲？」[p]
[kokutou_真顔_c]

#
刚要抬起的腰又咚地一声坐回椅子上。[p]

一旦变成这种局面，[r]　
我想柚叶君应该不会轻易离开这里了。[p]

只愿这个谜题能尽早解决就好。[p]

[vo vo="ep2/yuzu_0049.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「黑十先生您快看，靠窗座位的那个女人」[p]
[yuzuha_微笑_c]

[vo vo="ep2/koku_0059.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「靠窗？」[p]
[kokutou_疑問_c]
#

;イベントＣＧ表示
[event_in event="ep2_1_2"]

依言朝那个方向匆匆瞥去。[p]

只见先前见过的黑发少女正挺直腰背坐在那里。[p]

[vo vo="ep2/yuzu_0050.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「怎么样？很奇怪对吧？」[p]
[yuzuha_疑問_c]

[vo vo="ep2/koku_0060.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「您突然这么说……到底哪里奇怪了？」[p]
[kokutou_疑問_c]

[vo vo="ep2/yuzu_0051.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「您没发现吗？再仔细看看嘛」[p]
[yuzuha_疑問_c]

#
在她的催促下，再次望向窗边那位黑发少女。[p]

然而并未发现任何异常之处。[p]

黑发少女只是坐在摆着咖啡杯[r]　
与盛有餐点的碟子的桌旁。[p]

偶尔以优雅的姿态将咖啡杯送至唇边。[p]

这般景象与我们和其他客人并无二致，[r]　
在咖啡馆里本应是司空见惯的场景。[p]

;イベントＣＧ削除
[event_out]

[vo vo="ep2/koku_0061.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「看起来只是普通地在座位上坐着啊……」[p]
[kokutou_真顔_c]

[vo vo="ep2/yuzu_0052.ogg"]
[yuzuha_怒鳴る]
#【小仓 柚叶】
「就是那里呀就是那里！这样还不奇怪吗？」[p]
[yuzuha_怒鳴る_c]

#
柚叶君说，光是坐在座位上这件事本身就很奇怪。[p]

但这里是咖啡店。[p]

坐着怎么可能会奇怪。[p]

然而――。[p]

[vo vo="ep2/koku_0062.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「…………啊，原来如此」[p]
[kokutou_驚き_c]

#
观察片刻后，我察觉到了柚叶君所说的谜题。[p]

这个谜题乍看之下根本不会被认为是谜题。[p]

就这样过了一会[r]　
若不是一直盯着那位黑发少女是发现不了的。[p]

[vo vo="ep2/koku_0063.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「是这么回事啊」[p]
[kokutou_驚き_c]
#

;イベントＣＧ表示
[event_in event="ep2_1_2"]

虽然她碰过咖啡，[r]　
但点的餐……俱乐部三明治却一口未动。[p]

她进店的时间比柚叶君还早。[p]

我记得那份俱乐部三明治被端上桌的时间[r]　
是在柚叶君落座之后。[p]

;イベントＣＧ削除
[event_out]

[vo vo="ep2/koku_0064.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「那位黑发少女……完全没碰俱乐部三明治呢」[p]

[vo vo="ep2/koku_0065.ogg"]
#【黒十 美鹤】
「明明是很早之前就点的……」[p]
[kokutou_真顔_c]

[vo vo="ep2/yuzu_0053.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「就是说啊……很奇怪对吧？」[p]

[vo vo="ep2/yuzu_0054.ogg"]
#【小仓 柚叶】
「因为我点的牛肉烩饭，[r]　
　早就进到肚子里了哦？」[p]
[yuzuha_疑問_c]

#
黑发少女别说吃完俱乐部三明治[r]　
甚至根本未动分毫，实在可疑。[p]

柚叶君所说的可疑之处正是这个。[p]

原来如此，这确实称得上是个谜。[p]

[vo vo="ep2/yuzu_0055.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「黑十先生、您觉得这是为什么呢？」[p]

[vo vo="ep2/yuzu_0056.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「为什么那位女士没有碰俱乐部三明治呢？」[p]
[yuzuha_微笑_c]

#
她开心地询问道。[p]

露出这种表情时的柚叶君，对我来说真是相当难缠。[p]

因为在她得到满意的谜底前，会变得异常烦人且固执。[p]

[vo vo="ep2/koku_0066.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「……直接去问本人不就好了吗」[p]
[kokutou_哀_c]

[vo vo="ep2/yuzu_0057.ogg"]
[yuzuha_怒]
#【小仓 柚叶】
「那是最后的手段！我想和黑十先生一起解开这个谜题！」[p]
[yuzuha_怒_c]

#
而且必须要是能让她信服的答案才行。[p]

真是麻烦透顶。[p]

若要比喻这种精神损耗，[r]　
大概就和不得不照看熊孩子时的感受类似吧。[p]

[vo vo="ep2/yuzu_0058.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「求求您了，试着想想看嘛，就当是在玩解谜游戏！」[p]
[yuzuha_微笑_c]

[vo vo="ep2/koku_0067.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「……真拿你没办法」[p]
[kokutou_真顔_c]

;BGM停止
[bgm_end1]

#
算了，会陪着胡闹的我也挺可笑。[p]

不过若不解决这个游戏，恐怕没法离开咖啡店。[p]

既然如此还是速战速决为好。[p]

;BGM再生
[bgm ogg="tukikage.ogg"]

[vo vo="ep2/koku_0068.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「那么……该从何处着手分析呢」[p]
[kokutou_疑問_c]

#
只用余光瞥向窗边的位置。[p]

黑发少女依然保持着先前的姿势坐在座位上。[p]

[vo vo="ep2/koku_0069.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「不如逐步梳理现有线索吧」[p]

[vo vo="ep2/koku_0070.ogg"]
#【黒十 美鹤】
「本次的谜题是这个」[p]

[vo vo="ep2/koku_0071.ogg"]
#【黒十 美鹤】
「为何那位黑发少女始终未动俱乐部三明治」[p]
[kokutou_真顔_c]

[vo vo="ep2/yuzu_0059.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「是的，这显然很奇怪」[p]
[yuzuha_微笑_c]

[vo vo="ep2/koku_0072.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「理由是什么？」[p]

[vo vo="ep2/koku_0073.ogg"]
#【黒十 美鹤】
「能想到什么理由吗？」[p]
[kokutou_真顔_c]

[vo vo="ep2/yuzu_0060.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「咦？唔……因为肚子疼？」[p]
[yuzuha_疑問_c]

#
因为肚子疼所以没有动餐点。[p]

确实，作为不动眼前这份俱乐部三明治的理由是可能的。[p]

然而――。[p]

[vo vo="ep2/koku_0074.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「那份优雅地将咖啡杯送往唇边的姿态，[r]　
　怎么看都不像正在忍受腹痛呢」[p]
[kokutou_真顔_c]

[vo vo="ep2/yuzu_0061.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「就是说啊……」[p]
[yuzuha_哀_c]

[vo vo="ep2/koku_0075.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「假设真是腹痛，[r]　
　那应该会更早离开店铺才对」[p]
[kokutou_真顔_c]

[vo vo="ep2/yuzu_0062.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「那您认为还有其他什么理由呢？」[p]
[yuzuha_微笑_c]

[vo vo="ep2/koku_0076.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「……可能是所点餐品存在瑕疵？」[p]
[kokutou_疑問_c]

[vo vo="ep2/yuzu_0063.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「啊——原来如此……咦？[r]　
　但如果是那样的话不该立刻就叫店家吗？」[p]
[yuzuha_驚き_c]

[vo vo="ep2/koku_0077.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「就是说啊……」[p]
[kokutou_哀_c]

#
用和刚才柚叶君同样的方式回敬。[p]

[vo vo="ep2/yuzu_0064.ogg"]
[yuzuha_怒]
#【小仓 柚叶】
「黑十先生，请认真对待啦」[p]
[yuzuha_怒_c]

[vo vo="ep2/koku_0078.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「开玩笑的」[p]
[kokutou_真顔_c]

#
用双手轻拍眉头紧蹙的柚叶君以示惩戒。[p]

随后，道出了其实最初就想到的答案。[p]

[vo vo="ep2/koku_0079.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「为何唯独不动俱乐部三明治，那是因为……」[p]

[vo vo="ep2/koku_0080.ogg"]
#【黒十 美鹤】
「那不是她的东西」[p]
[kokutou_真顔_c]

[vo vo="ep2/yuzu_0065.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「咦？不是她的东西……什么意思？」[p]
[yuzuha_驚き_c]

[vo vo="ep2/koku_0081.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「就是字面意思哦」[p]

[vo vo="ep2/koku_0082.ogg"]
#【黒十 美鹤】
「不碰桌上摆放的东西是因为，[r]　
　那些不属于自己」[p]
[kokutou_真顔_c]

#
说着，指向柚叶君手边的咖啡杯。[p]

[vo vo="ep2/koku_0083.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「要是我用了柚叶君的咖啡杯会怎样？」[p]
[kokutou_真顔_c]

[vo vo="ep2/yuzu_0066.ogg"]
[yuzuha_哀]
[yuzuha_etc_頬]
#【小仓 柚叶】
「咦？那个……会以为是间接接吻吧」[p]
[yuzuha_哀_c]

[vo vo="ep2/koku_0084.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「…………少女心吗？」[p]
[kokutou_驚き_c]

#
不不，就是少女心。[p]

[vo vo="ep2/koku_0085.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「不是，很奇怪吧？明明不是自己的东西」[p]
[kokutou_真顔_c]

[vo vo="ep2/yuzu_0067.ogg"]
[yuzuha_驚き]
[yuzuha_etc_off]
#【小仓 柚叶】
「啊—，确实这样很奇怪呢」[p]

[vo vo="ep2/yuzu_0068.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「等等？但你说不属于自己……稍等一下」[p]

[vo vo="ep2/yuzu_0069.ogg"]
#【小仓 柚叶】
「那这份俱乐部三明治到底是谁的？」[p]

[vo vo="ep2/yuzu_0070.ogg"]
#【小仓 柚叶】
「特意点自己不吃的东西什么的……啊」[p]
[yuzuha_疑問_c]

;BGM停止
[bgm_end1]

[yuzuha_驚き_c]

#
说到这里，柚叶君似乎也意识到了。[p]

[vo vo="ep2/yuzu_0071.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「这样啊……是在等人对吧」[p]

[yuzuha_微笑_c]

;BGM再生
[bgm ogg="urara.ogg"]

[vo vo="ep2/koku_0086.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「没错，在我们看来是黑发少女独自一人」[p]

[vo vo="ep2/koku_0087.ogg"]
#【黒十 美鹤】
「但实际上应该是准备两个人共度的」[p]

[vo vo="ep2/koku_0088.ogg"]
#【黒十 美鹤】
「或许另一个人比约定时间迟到了」[p]

[vo vo="ep2/koku_0089.ogg"]
#【黒十 美鹤】
「所以现在俱乐部三明治一直没人动过」[p]
[kokutou_真顔_c]

#
听到这个解释，柚叶君出声表示赞同。[p]

[vo vo="ep2/yuzu_0072.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「原来如此……换我早就吃掉了，太浪费了」[p]
[yuzuha_微笑_c]

[vo vo="ep2/koku_0090.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「你关注的竟然是这点……嘛、确实是这样没错」[p]
[kokutou_微笑_c]

[vo vo="ep2/yuzu_0073.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「不过原来如此啊、是约会啊、能解开谜题真是太好了」[p]

[vo vo="ep2/yuzu_0074.ogg"]
#【小仓 柚叶】
「虽然过程很平淡，但这下总算清爽了」[p]
[yuzuha_笑顔_c]

#
;//選択肢
;//１：これでやっと帰れる。[p]
;//２：なにか引っかかることがある。[p]

[glink x="266" y="186" graphic="txtlink.png" width="712"  size="28" text="これでやっと帰れる。" storage="ep2_scene02.ks" target="*kaeru"]
[glink x="266" y="299" graphic="txtlink.png" width="712" size="28" text="なにか引っかかることがある。" storage="ep2_scene02.ks" target="*nanika"]

;//１を選ぶとバッドエンドのルート『来る待ち人と来ない待ち人』へ
;//２を選ぶと正規ルートへ
[s]

;--------------------------------------------------
*kaeru
[savetitle text="これでやっと帰れる"]
;-------------------------------------------------

;//選択肢１：これでやっと帰れる。[p]

[vo vo="ep2/koku_0091.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「那真是再好不过了」[p]
[kokutou_微笑_c]

#
看到柚叶君露出的微笑，我抚着胸口松了口气。[p]

这样应该就能顺利离开这家店了吧。[p]

[vo vo="ep2/yuzu_0075.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「那么、我们差不多该走了吧」[p]


[vo vo="ep2/yuzu_0076.ogg"]
#【小仓 柚叶】
「早点回去给黑十先生好好讲解一下[r]　
　智能手机的使用方法呢」[p]
[yuzuha_笑顔_c]

#
面对那张洋溢着满足感的笑脸，我只能回以苦笑。[p]

[vo vo="ep2/koku_0092.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「还请手下留情啊……」[p]
[kokutou_微笑_c]

[vo vo="ep2/yuzu_0077.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「好的！当然会啦！」[p]
[yuzuha_笑顔_c]

;//ここまで
;//ルート『来る待ち人、来ない待ち人』へ
;シーン5へ移動
[jump  storage="ep2_scene05.ks"]
[s]



;--------------------------------------------------
*nanika
[savetitle text="なにか引っかかることがある"]
;-------------------------------------------------
;//選択肢２：なにか引っかかることがある。[p]


;BGM停止
[bgm_end3]

[vo vo="ep2/koku_0112.ogg"]
[kokutou_真顔_c]
#【黒十 美鹤】
「…………」[p]

[vo vo="ep2/yuzu_0105.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「黑十先生？您怎么了？」[p]
[yuzuha_笑顔_c]

;BGM再生
[bgm ogg="tukikage.ogg"]

#
心头掠过一丝细微的违和感。[p]

虽然直接回去也无妨……[p]

[vo vo="ep2/koku_0113.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「不、总觉得好像忘记了什么……」[p]
[kokutou_疑問_c]

[vo vo="ep2/yuzu_0106.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「忘记了什么？究竟是指什么事呢？」[p]
[yuzuha_疑問_c]

#

;//選択肢
;//１：クラブサンドのこと。[p]
;//２：黒髪の少女のこと。[p]
;//３：御手洗庵のこと。[p]

[glink x="266" y="136" graphic="txtlink.png" width="712"  size="28" text="クラブサンドのこと。" storage="ep2_scene02.ks" target="*curabusando"]
[glink x="266" y="249" graphic="txtlink.png" width="712" size="28" text="黒髪の少女のこと。" storage="ep2_scene02.ks" target="*kurokami"]
[glink x="266" y="362" graphic="txtlink.png" width="712" size="28" text="御手洗庵のこと。" storage="ep2_scene02.ks" target="*mitarai"]

;//２を選ぶと正規ルートへ
;//１、３を選ぶとルート『来る待ち人、来ない待ち人』へ
;//ただし、３を選ぶと『来る待ち人、来ない待ち人』後に追加のエピソードが見れる。
[s]

;--------------------------------------------------
*curabusando
[savetitle text="クラブサンドのこと"]
;-------------------------------------------------
;//選択肢１：クラブサンドのこと

;イベントＣＧ表示
[event_in event="ep2_1_2"]

#
目光移向靠窗的座位。[p]

黑发少女依然端正地独自坐着，宛如画中人物。[p]

我凝视着她桌上摆放的俱乐部三明治。[p]

[vo vo="ep2/yuzu_0107.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「黑十先生，您忘记的东西该不会是……俱乐部三明治吧？」[p]
[yuzuha_疑問_c]

[vo vo="ep2/koku_0114.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「嗯……我正是这么认为的」[p]
[kokutou_疑問_c]

#
无论怎么思考，都搞不明白自己究竟对俱乐部三明治的哪部分心存芥蒂。[p]

;イベントＣＧ削除
[event_out]


;BGM停止
[bgm_end3]

[vo vo="ep2/yuzu_0108.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「唔——是不是还有什么细节被我遗漏了呢」[p]
[yuzuha_疑問_c]

#
虽然和柚叶君一起思考，但最终仍是一无所获。[p]


;BGM再生
[bgm ogg="urara.ogg"]

[vo vo="ep2/koku_0115.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「抱歉，似乎是我的错觉」[p]
[kokutou_哀_c]

[vo vo="ep2/yuzu_0109.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「哎——现在反倒让人在意起来了啦」[p]

[vo vo="ep2/yuzu_0110.ogg"]
#【小仓 柚叶】
「明明以为已经完美解开所有谜团了呢——」[p]
[yuzuha_哀_c]

[vo vo="ep2/koku_0116.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「所以我不是都道歉了嘛」[p]
[kokutou_哀_c]

#
经过再度劝说依依不舍的柚叶君，总算离开了店铺。[p]

在咖啡店停留的时间比预想中要长。[p]

;//ここまで
;//ルート『来る待ち人、来ない待ち人』へ
;シーン5へ移動
[jump  storage="ep2_scene05.ks"]
[s]

;--------------------------------------------------
*mitarai
[savetitle text="御手洗庵のこと"]
;-------------------------------------------------
;//選択肢３：御手洗庵のこと

[eval exp="f.庵マニア = 1"]

#
脑海中掠过的，是那个女装店员的容貌。[p]

那抹令人捉摸不透的挑衅笑容在记忆角落里隐隐浮现。[p]

[vo vo="ep2/koku_0117.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「结果今天他根本没现身呢」[p]
[kokutou_疑問_c]

[vo vo="ep2/yuzu_0111.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「黑十先生？」[p]
[yuzuha_疑問_c]

[vo vo="ep2/koku_0118.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「啊不，我是说庵君」[p]
[kokutou_真顔_c]

[vo vo="ep2/yuzu_0112.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「啊——说起来今天确实没见到他呢」[p]
[yuzuha_驚き_c]

#
柚叶君至今仍不知道他是小仓家派来的人。[p]

自然也不会察觉对方正尾随着我们——[r]　
准确说是围绕着柚叶君活动这件事。[p]

[vo vo="ep2/yuzu_0113.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「不过黑十先生，小庵和这次的谜题应该没关系吧？」[p]
[yuzuha_疑問_c]

;BGM停止
[bgm_end3]

[vo vo="ep2/koku_0119.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「这个嘛...确实如此」[p]
[kokutou_真顔_c]

#
将这个不在场的女装店员对照本次谜团[r]　
感觉毫无意义。[p]
;BGM再生
[bgm ogg="urara.ogg"]

[vo vo="ep2/yuzu_0114.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「可是小庵，平时都是在咖啡店的，现在在做什么呢ー」[p]
[yuzuha_微笑_c]

[vo vo="ep2/koku_0120.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「听说最近，您不太常来店里露面了呢」[p]
[kokutou_真顔_c]
#
当我把从Master那里听来的话转告给柚叶君时，她露出了略显寂寞的表情。[p]

[vo vo="ep2/yuzu_0115.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「咦——是这样吗……应该不会辞职之类的吧？」[p]
[yuzuha_哀_c]

[vo vo="ep2/koku_0121.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「为什么要那么在意呢？」[p]
[kokutou_真顔_c]

[vo vo="ep2/yuzu_0116.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「不是，因为……说不定有万分之一的可能不是吗」[p]
[yuzuha_哀_c]

[vo vo="ep2/koku_0122.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「万分之一？」[p]
[kokutou_驚き_c]

[vo vo="ep2/yuzu_0117.ogg"]
[yuzuha_怒]
#【小仓 柚叶】
「……您该不会联想到小狗了吧？我说的是存在可能性这件事」[p]
[yuzuha_怒_c]

[vo vo="ep2/koku_0123.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「可能性……啊，您是指稻饼小姐的事吗」[p]

[kokutou_微笑_c]

#
说完，轻轻笑了起来。[p]

不过确实，也不能断言绝对没可能。[p]

柚叶君和稻饼小姐认为他是拥有女性心灵的男子，[r]　
实际并非如此。[p]

女装说到底只是为了监视柚叶君而进行的伪装。[p]

[vo vo="ep2/koku_0124.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「……不，但内心真的是女性吗？」[p]
[kokutou_疑問_c]

#
独自思考这种事情开始混乱起来。[p]

但对我来说终究是别人的事。[p]

应该不必在意到那种程度吧。[p]

[vo vo="ep2/yuzu_0118.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「黑十先生？　在想什么呢？」[p]
[yuzuha_疑問_c]

[vo vo="ep2/koku_0125.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「不不确实，我觉得说不定有一次机会」[p]

[vo vo="ep2/koku_0126.ogg"]
#【黒十 美鹤】
「比起那个，我们还是回去吧」[p]
[kokutou_真顔_c]

[vo vo="ep2/yuzu_0119.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「啊，说得对！得回去教您用智能手机呢！」[p]
[yuzuha_微笑_c]

[vo vo="ep2/koku_0127.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「……手下留情」[p]
[kokutou_真顔_c]

[vo vo="ep2/yuzu_0120.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「对！」[p]
[yuzuha_笑顔_c]

#
;//ここまで
;//ルート『来る待ち人、来ない待ち人』へ
;シーン5へ移動
[jump  storage="ep2_scene05.ks"]
[s]


;--------------------------------------------------
*kurokami
[savetitle text="黒髪の少女のこと"]
;-------------------------------------------------
;//選択肢２：黒髪の少女のこと。[p]

;BGM停止
[bgm_end3]

[vo vo="ep2/koku_0128.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「对了，那个黑发少女……记得……」[p]
[kokutou_疑問_c]

#
回忆起她走进店里的情景。[p]

;//回想
[sepia]


[kaguya_無表情_c]
[ric_f cg="kaguya"]
[master_微笑]
[lec cg="master"]

[vo vo="ep2/master_0014.ogg"]
#【店主】
「哎呀，欢迎光临」[p]
[master_微笑_c]

[vo vo="ep2/kaguya_0001.ogg"]
[kaguya_無表情]
#【黑发少女】
「你好，今天也来打扰了」[p]
[kaguya_無表情_c]

[vo vo="ep2/master_0015.ogg"]
[master_微笑]
#【店主】
「嗯，还是和往常一样的订单可以吗？」[p]
[master_微笑_c]

[vo vo="ep2/kaguya_0002.ogg"]
[kaguya_無表情]
#【黑发少女】
「不好意思，那就麻烦你了」[p]
[kaguya_無表情_c]

[vo vo="ep2/master_0016.ogg"]
[master_微笑]
#【店主】
「哪里哪里，请慢慢坐」[p]
[master_微笑_c]
#

[mode_end]
;//回想ここまで


;BGM再生
[bgm ogg="tukikage.ogg"]



[kokutou_真顔]
[ric_f cg="kokutou"]
[yuzuha_疑問_c]
[lec cg="yuzuha"]

[vo vo="ep2/koku_0129.ogg"]
#【黒十 美鹤】
「对了……她是这家店的……」[p]
[kokutou_真顔_c]

;SE：足音フェイドイン
[se_f se="footsteps_in.ogg"]

[vo vo="ep2/master_0022.ogg"]
#【店主】
「要续杯咖啡吗？」[p]
#
正巧这时店主走了过来。[p]

[vo vo="ep2/koku_0130.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「店长，想向您打听件事」[p]
[kokutou_真顔_c]

[vo vo="ep2/master_0023.ogg"]
#【店主】
「在听？」[p]
#

;イベントＣＧ表示
[event_in event="ep2_1_2"]


视线不经意扫向窗边的座位。[p]

[vo vo="ep2/koku_0131.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「那位黑发少女是店里的常客吗？」[p]
[kokutou_真顔_c]

[vo vo="ep2/yuzu_0121.ogg"]
#【小仓 柚叶】
「咦？真是这样吗？」[p]
#
面对询问，店主露出略带惊讶的神情。[p]

[vo vo="ep2/master_0024.ogg"]
#【店主】
「是的……不过您怎么会知道呢？」[p]
#
果然是这么回事。[p]

;イベントＣＧ削除
[event_out]

[vo vo="ep2/koku_0132.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「不，我只是听到那位少女进店时的对话」[p]
[kokutou_真顔_c]

[vo vo="ep2/master_0025.ogg"]
#【店主】
「啊—，原来是这样啊，我明白了」[p]

[vo vo="ep2/master_0026.ogg"]
#【店主】
「那孩子每周都必定会来哦」[p]

;BGM停止
[bgm_end3]

[vo vo="ep2/koku_0133.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「每周……」[p]
[kokutou_驚き_c]

[vo vo="ep2/master_0027.ogg"]
#【店主】
「是的，而且都是同一时间，总是一个人坐在那边的靠窗座位」[p]

[vo vo="ep2/yuzu_0122.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「嘿—，不过这种心情我能理解」[p]

[vo vo="ep2/yuzu_0123.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「我也沉迷这里的咖啡呢！对吧，黑十先生！」[p]
[yuzuha_笑顔_c]

;BGM再生
[bgm ogg="tukikage_02.ogg"]

[vo vo="ep2/koku_0134.ogg"]
[kokutou_疑問_c]
#【黒十 美鹤】
「…………」[p]

[vo vo="ep2/yuzu_0124.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「黑十先生？您在沉思什么呢？」[p]
[yuzuha_微笑_c]

#
看样子，柚叶君似乎尚未察觉。[p]

[vo vo="ep2/koku_0135.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「没注意到吗？[r]　
　这样一来刚才的谜题答案，关于等人的假设就不成立了」[p]
[kokutou_真顔_c]

[vo vo="ep2/yuzu_0125.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「咦？为什么这么问？」[p]
[yuzuha_疑問_c]

[vo vo="ep2/koku_0136.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「请仔细想想」[p]

[vo vo="ep2/koku_0137.ogg"]
#【黒十 美鹤】
「那个黑发少女每周同一时间都独自坐在那个座位上哦？」[p]

[vo vo="ep2/koku_0138.ogg"]
#【黒十 美鹤】
「也就是说，并非只有今天才特意那样坐着」[p]
[kokutou_真顔_c]

[vo vo="ep2/yuzu_0126.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「啊，这样啊……如果每周都固定来，[r]　
　就不是在等人了呢」[p]
[yuzuha_疑問_c]

#
我们双双为这个错误假设苦恼不已。[p]

店主人看着我们这副模样，始终保持着笑容说道。[p]

[vo vo="ep2/master_0028.ogg"]
#【店主】
「那位常客啊，从来都不碰俱乐部三明治呢」[p]
#
真是不可思议呢，店主微笑道。[p]

望着这样的店主，柚叶君瞪大了眼睛。[p]

[vo vo="ep2/yuzu_0127.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「从不动俱乐部三明治……那、那该不会是……！」[p]

[vo vo="ep2/yuzu_0128.ogg"]
#【小仓 柚叶】
「那个人每周同一天，同一时间，同一个座位，[r]　
　每次都同样地点了俱乐部三明治吗？」[p]
[yuzuha_驚き_c]

[vo vo="ep2/master_0029.ogg"]
#【店主】
「嗯，是的不过……」[p]

[vo vo="ep2/yuzu_0129.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「不仅如此……还从来不吃？」[p]
[yuzuha_驚き_c]

[vo vo="ep2/master_0030.ogg"]
#【店主】
「啊、是的没错，俱乐部三明治确实没有动过呢」[p]
#
面对柚叶君的惊讶反应，连店长都不由得稍微退缩了。[p]

但实际上真正被惊到的应该是我们这边才对。[p]

;SE：足音フェイドアウト
[se_f se="footsteps_out.ogg"]

当店长重新倒好咖啡离开座位后，[r]　
柚叶君带着震惊的表情转向我们。[p]

[vo vo="ep2/yuzu_0130.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「黑十先生，这个难道是……」[p]
[yuzuha_微笑_c]
#
轻声低语的柚叶君嘴角逐渐舒缓开来。[p]

[yuzuha_怒鳴る_c]

很快，那表情便转化为难以抑制兴奋的笑容。[p]

每当面对谜题时柚叶君的笑颜，[r]　
总会在各种意义上让我心头一颤。[p]

[vo vo="ep2/yuzu_0131.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「这个……可是谜题啊！黑十先生！」[p]
[yuzuha_笑顔_c]

#
看来这个谜题暂时还不会让我回到古董店呢。[p]

;BGM停止
[bgm_end3]

[vo vo="ep2/koku_0139.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「谜团，似乎逐渐加深了呢……」[p]
[kokutou_哀_c]

#
本以为终于可以回去 但看来还是太天真了。[p]

与我深深叹气的样子相反 柚叶君却满脸笑容。[p]

[vo vo="ep2/yuzu_0132.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「当时没有直接回去真是太好了！」[p]

[vo vo="ep2/yuzu_0133.ogg"]
#【小仓 柚叶】
「黑十先生，这样一来'等待会合'这个答案[r]　
　就被证实是错误的了哦！」[p]
[yuzuha_笑顔_c]

[vo vo="ep2/koku_0140.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「……您看起来相当开心呢」[p]
[kokutou_哀_c]

[vo vo="ep2/yuzu_0134.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「那当然了，因为事态变得有趣到令人害怕的程度了啊！」[p]
[yuzuha_笑顔_c]

#
用手掌抵住她激动喘着粗气逼近的脸庞。[p]

无论如何，现在必须重新思考了。[p]

;BGM再生
[bgm ogg="kaiko.ogg"]

[vo vo="ep2/koku_0141.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「每周都不碰俱乐部三明治，是吧？」[p]
[kokutou_哀_c]

;イベントＣＧ表示
[event_in event="ep2_1_2"]

#
带着烦躁的心情凝视着桌上的俱乐部三明治。[p]

除了观察那个黑发少女和她所在的那张桌子外[r]　
似乎没有其他线索了。[p]

[vo vo="ep2/yuzu_0135.ogg"]
#【小仓 柚叶】
「怎么样黑十先生，发现什么了吗？」[p]

[vo vo="ep2/koku_0142.ogg"]
#【黒十 美鹤】
「就算你问发现了什么也...」[p]

#
老实说，本以为事情已经结束了。[p]

没有比在终点前被送回起点的双六更令人沮丧的游戏了。[p]

无力地呆望着黑发少女的座位。[p]

黑发少女正襟危坐，[r]　
以优雅的动作将咖啡杯送至唇边。[p]

然后――[p]

;BGM停止
[bgm_end3]

[vo vo="ep2/koku_0143.ogg"]
#【黒十 美鹤】
「……嗯？」[p]
#
注意到黑发少女时不时会拿起桌上某个物品。[p]

[vo vo="ep2/koku_0144.ogg"]
#【黒十 美鹤】
「那个是……怀表？」[p]
#
刚才就一直放在桌上吗。[p]

[vo vo="ep2/yuzu_0136.ogg"]
#【小仓 柚叶】
「啊，那个原本就放在那里的」[p]

[vo vo="ep2/yuzu_0137.ogg"]
#【小仓 柚叶】
「虽然看到他偶尔会拿在手上确认时间的样子，[r]　
　但您没注意到吗？」[p]

[vo vo="ep2/yuzu_0138.ogg"]
#【小仓 柚叶】
「或者说正因为注意到这点，黑十先生最初才会以为[r]　
　是有人在约会等候……不是吗？」[p]

[vo vo="ep2/koku_0145.ogg"]
#【黒十 美鹤】
「…………嗯，算是吧」[p]
#
或许是因注意力全被俱乐部三明治吸引了吧。[p]

我确实没注意到怀表的存在。[p]


;イベントＣＧ削除
[event_out]


;BGM再生
[bgm ogg="music.ogg"]

[vo vo="ep2/yuzu_0139.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「那位黑十先生竟会带着稀罕物件，那个也是古董吧？」[p]
[yuzuha_微笑_c]

[vo vo="ep2/koku_0146.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「呜……」[p]
[kokutou_哀_c]

#
被戳到痛处了。[p]

对于经营古董店的我而言实属不该。[p]

[vo vo="ep2/yuzu_0140.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「呵呵呵，这说明您解谜时确实全力以赴呢」[p]
[yuzuha_笑顔_c]

[vo vo="ep2/koku_0147.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「倒也不是这个意思……」[p]
[kokutou_哀_c]

[vo vo="ep2/yuzu_0141.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「好啦好啦别谦虚嘛，呵呵呵」[p]
[yuzuha_笑顔_c]

#
就算用怨念的眼神瞪着意有所指的柚叶君也无济于事。[p]

这样僵持下去也不可能提早回去，我决定不再计较。[p]

[vo vo="ep2/koku_0148.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「话说回来，居然是怀表啊」[p]

[vo vo="ep2/koku_0149.ogg"]
#【黒十 美鹤】
「作为女性随身物品来说，还挺罕见的」[p]
[kokutou_微笑_c]

[vo vo="ep2/yuzu_0142.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「不如说会随身带怀表的人本身就很稀少吧？」[p]
[yuzuha_疑問_c]

[vo vo="ep2/koku_0150.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「话虽如此，但实际上男性使用者比女性多哦」[p]

[vo vo="ep2/koku_0151.ogg"]
#【黒十 美鹤】
「日常使用的人群自不必说，[r]　
　收藏爱好者里也是男性占多数吧」[p]
[kokutou_微笑_c]

[vo vo="ep2/yuzu_0143.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「嘿～原来如此」[p]
[yuzuha_疑問_c]

;カットイン表示
[cut_in cut="cut_watch.png"]

[vo vo="ep2/koku_0152.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「嗯~不过那块怀表……设计相当不错呢……」[p]

[vo vo="ep2/koku_0153.ogg"]
#【黒十 美鹤】
「从这里虽然看不清细节 但它很可能是装饰艺术风格——[r]　
　也就是说可能是1910年代之后的产物」[p]

[vo vo="ep2/koku_0154.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「制造商是欧米茄还是华生……不对 埃尔金？」[p]
[kokutou_疑問_c]

;カットイン削除
[cut_out]

[vo vo="ep2/yuzu_0144.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「没必要调查怀表了吧~？」[p]
[yuzuha_哀_c]

#
柚叶君用死鱼眼瞪过来 但我决定无视她。[p]

对于古董物品 一旦在意就非要查个水落石出才罢休。[p]

[vo vo="ep2/koku_0155.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「唔~ 这个距离观察起来确实困难……嗯？[r]　
　那个表盘……！」[p]

[vo vo="ep2/koku_0156.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「没、没错……！　那极具锋芒又令人无法移开视线的[r]　
　刻度设计！」[p]
[kokutou_驚き_c]

[vo vo="ep2/yuzu_0145.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「从这里真的能看到~？」[p]
[yuzuha_哀_c]

[vo vo="ep2/koku_0157.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「既充满力量感 又无比可爱的设计绝对没错……[r]　
　是洛克诺兹的怀表……！」[p]
[kokutou_驚き_c]

[vo vo="ep2/yuzu_0146.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「嘿~ 那很厉害吗~？」[p]
[yuzuha_哀_c]

[vo vo="ep2/koku_0158.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「说什么呢？当然厉害啊！」[p]

[vo vo="ep2/koku_0159.ogg"]
#【黒十 美鹤】
「洛克诺兹的运营期只有短短三十年」[p]
[kokutou_驚き_c]

[vo vo="ep2/yuzu_0147.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「嘿~」[p]
[yuzuha_哀_c]

[vo vo="ep2/koku_0160.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「这期间生产的怀表数量据说不达大厂商的[r]　
　十分之一」[p]

[vo vo="ep2/koku_0161.ogg"]
#【黒十 美鹤】
「明白这意味着什么吗？」[p]
[kokutou_微笑_c]

[vo vo="ep2/yuzu_0148.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「完全不懂」[p]
[yuzuha_微笑_c]

[vo vo="ep2/koku_0162.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「这说明它的稀有性极高……[r]　
　可以说，洛克诺兹就是传说中的制造商啊！」[p]

[vo vo="ep2/koku_0163.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「没想到竟能在此处得见……[r]　
　但保存状况似乎不佳，唯独这点令人遗憾至极……」[p]

[vo vo="ep2/koku_0164.ogg"]
#【黒十 美鹤】
「洛克诺兹只生产猎人型，[r]　
　也就是带表盖的款式」[p]

[vo vo="ep2/koku_0165.ogg"]
#【黒十 美鹤】
「但那块表没有表盖……恐怕是脱落了吧」[p]

[vo vo="ep2/koku_0166.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「即便如此仍随身携带直到它停止走动……[r]　
　那位黑发少女，倒也颇懂浪漫呢」[p]

;BGM停止
[bgm_end2]

[vo vo="ep2/koku_0167.ogg"]
#【黒十 美鹤】
「你不这么认为吗，柚叶君？」[p]
[kokutou_微笑_c]

[vo vo="ep2/yuzu_0149.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「……啊，说完了？」[p]
[yuzuha_笑顔_c]

[vo vo="ep2/koku_0168.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「………………嗯，算是吧」[p]
[kokutou_真顔_c]

#
看来柚叶君与我之间的温度差实在太大。[p]

我过于沉醉其中竟未察觉。[p]

;BGM再生
[bgm ogg="un_cafe.ogg"]

[vo vo="ep2/koku_0169.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「不过对于现代派的柚叶君来说，[r]　
　或许理解不了那种精密机芯的妙处吧」[p]
[kokutou_真顔_c]

[vo vo="ep2/yuzu_0150.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「您在说什么呀，[r]　
　要看时间的话直接看手机不就好了吗」[p]
[yuzuha_微笑_c]

[vo vo="ep2/koku_0170.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「手机……如今人们竟已彻底忘却腕表的存在……」[p]
[kokutou_驚き_c]

[vo vo="ep2/yuzu_0151.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「只为确认时间的话，[r]　
　根本没必要特意携带那么笨重的东西嘛」[p]
[yuzuha_微笑_c]

[vo vo="ep2/koku_0171.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「哈哈，这评价可真不留情……[r]　
　不过嘛，确实也有道理呢」[p]
[kokutou_微笑_c]

#
一边说着一边将视线移向窗边座位的黑发少女。[p]

[vo vo="ep2/yuzu_0152.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「比起那些，现在重要的是俱乐部三明治哦」[p]

[vo vo="ep2/yuzu_0153.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「为什么那个俱乐部三明治原封未动呢？」[p]

[vo vo="ep2/yuzu_0154.ogg"]
#【小仓 柚叶】
「既然要琢磨就请拼命琢磨那个吧～」[p]
[yuzuha_疑問_c]

;BGM停止
[bgm_end2]

[vo vo="ep2/koku_0172.ogg"]
[kokutou_疑問_c]
#【黒十 美鹤】
「………………」[p]

[vo vo="ep2/yuzu_0155.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「咦？稍微听下我说话嘛？」[p]
[yuzuha_疑問_c]

[vo vo="ep2/koku_0173.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「………能够确认的工具」[p]
[kokutou_疑問_c]

[vo vo="ep2/yuzu_0156.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「嗯唔？那个……黑十先生？」[p]
[yuzuha_疑問_c]

;BGM再生
[bgm ogg="kaiko.ogg"]

[vo vo="ep2/koku_0174.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「柚叶君……刚才柚叶君说了什么？」[p]
[kokutou_真顔_c]

[vo vo="ep2/yuzu_0157.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「诶？我说既然要琢磨就拼命[r]　
　琢磨那个来着？」[p]
[yuzuha_疑問_c]

[vo vo="ep2/koku_0175.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「不对，是再之前些的」[p]

[vo vo="ep2/koku_0176.ogg"]
#【黒十 美鹤】
「要确认时间的话看手机就好了」[p]

[vo vo="ep2/koku_0177.ogg"]
#【黒十 美鹤】
「刚才这么说过对吧？」[p]
[kokutou_真顔_c]

[vo vo="ep2/yuzu_0158.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「啊，是的」[p]

[vo vo="ep2/yuzu_0159.ogg"]
#【小仓 柚叶】
「仅仅为了确认时间的工具[r]　
　根本没必要特意带着那么大的东西对吧？」[p]
[yuzuha_疑問_c]

[vo vo="ep2/koku_0178.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「……原来如此，是这么回事啊」[p]
[kokutou_真顔_c]

#
听到我的低语，柚叶君突然怔住。[p]

[vo vo="ep2/yuzu_0160.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「黑十先生，难道您明白了吗！？」[p]
[yuzuha_驚き_c]

#
面对这个问题，我点头回应。[p]

[kokutou_哀_c]
但对自己推导出的谜底，不禁用单手掩住了嘴。[p]

[vo vo="ep2/yuzu_0161.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「请告诉我吧黑十先生」[p]

[vo vo="ep2/yuzu_0162.ogg"]
#【小仓 柚叶】
「为什么那个人不碰俱乐部三明治呢？」[p]
[yuzuha_驚き_c]

#
面对柚叶君的提问，我稍显犹豫。[p]

然而 面对她直视而来的眼眸 我无法说谎。[p]

[vo vo="ep2/koku_0179.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「我们 都误会了」[p]
[kokutou_哀_c]

[vo vo="ep2/yuzu_0163.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「误会……？」[p]
[yuzuha_驚き_c]

[vo vo="ep2/koku_0180.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「每周相同时间 相同座位 相同点单……」[p]

[vo vo="ep2/koku_0181.ogg"]
#【黒十 美鹤】
「无人动过的俱乐部三明治、怀表」[p]

[vo vo="ep2/koku_0182.ogg"]
#【黒十 美鹤】
「然后那个黑发少女」[p]
[kokutou_真顔_c]

#
脑海中浮现出自己确认过的关键词。[p]

不久之后，它便逐渐引导出了那个谜题的答案。[p]

那不过是天马行空、某个过程中脱离常规的只言片语。[p]

然而作为谜题的答案可以接受，属于预料之内、可容许的范畴。[p]

而我所得出的谜题答案――[r]　
是个极其无趣的答案。[p]

[vo vo="ep2/koku_0183.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「柚叶君、我们刚才得出的答案在某种意义上是对的哦」[p]
[kokutou_真顔_c]

[vo vo="ep2/yuzu_0164.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「刚才给出的答案？那个应该是……诶？」[p]
[yuzuha_驚き_c]
#
对着歪头露出疑惑表情的柚叶君我说道。[p]

[vo vo="ep2/koku_0184.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「是的……因为我和别人有约」[p]
[kokutou_真顔_c]

;シーン3へ移動
[jump  storage="ep2_scene03.ks"]
[s]
