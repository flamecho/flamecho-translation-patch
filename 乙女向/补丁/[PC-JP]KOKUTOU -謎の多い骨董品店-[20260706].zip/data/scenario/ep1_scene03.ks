﻿;--------------------------------------------------
*012000
[savetitle text="消える男の子"]
;-------------------------------------------------
;背景
[bg10 bg="cafe01.jpg"]

;BGM再生
[bgm ogg="mid_re.ogg"]

[kokutou_哀_c]
[ric_f cg="kokutou"]
[yuzuha_微笑_c] 
[lec cg="yuzuha"]

;テキストウィンドウ表示
[start_text]

[yuzuha_怒鳴る]
[vo vo="ep1/yuzu_0048.ogg"]
#【小仓 柚叶】
「这里就是小百合小姐说的那家咖啡店吧」[p]
[yuzuha_怒鳴る_c]

#
从神秘的牵线人稻饼小姐那里听说此事的第二天。[p]

被莫名兴奋的柚叶君[r]　
拽着手臂来到的，就是那家咖啡店。[p]

[yuzuha_微笑]
[vo vo="ep1/yuzu_0049.ogg"]
#【小仓 柚叶】
「咦？怎么了黑十先生？兴致不高呢？」[p]
[yuzuha_微笑_c]

[kokutou_怒]
[vo vo="ep1/koku_0055.ogg"]
#【黒十 美鹤】
「那当然，大清早就被吵醒的话」[p]
[kokutou_怒_c]

[yuzuha_疑問]
[vo vo="ep1/yuzu_0050.ogg"]
#【小仓 柚叶】
「您在说什么啊？平时这个时间可是上学时段哦」[p]
[yuzuha_疑問_c]

#
和十几岁的学生作息时间差太多了。[p]

我本就是个夜猫子。[p]

总之只能尽快办完事回去。[p]

[kokutou_真顔]
[vo vo="ep1/koku_0056.ogg"]
#【黒十 美鹤】
「……话说正主稻饼小百合小姐人在哪？」[p]
[kokutou_真顔_c]

[yuzuha_微笑_c]
#
被带到这里时就没见到她。[p]

本以为会直接在约定地点等着的。[p]

[yuzuha_微笑]
[vo vo="ep1/yuzu_0051.ogg"]
#【小仓 柚叶】
「啊，小百合小姐今天不会来」[p]
[yuzuha_微笑_c]

[kokutou_驚き]
[vo vo="ep1/koku_0057.ogg"]
#【黒十 美鹤】
「哎？不来？」[p]
[kokutou_驚き_c]

#
超出预料的回答让我鹦鹉学舌般反问道。[p]

[yuzuha_微笑]
[vo vo="ep1/yuzu_0052.ogg"]
#【小仓 柚叶】
「是的，说是临时有其他安排……」[p]

[vo vo="ep1/yuzu_0053.ogg"]
#【小仓 柚叶】
「希望明天再详细说明」[p]
[yuzuha_微笑_c]

[kokutou_疑問]
[vo vo="ep1/koku_0058.ogg"]
#【黒十 美鹤】
「原来如此，明天再说，是吧……」[p]
[kokutou_疑問_c]

[yuzuha_微笑]
[vo vo="ep1/yuzu_0054.ogg"]
#【小仓 柚叶】
「关于那个走进咖啡店就消失的[r]　
　暗恋男生的特征我已经听说了」[p]

[vo vo="ep1/yuzu_0055.ogg"]
#【小仓 柚叶】
「出现的话大概能认出来[r]　
　还有，来咖啡馆的时间段也完全吻合」[p]
[yuzuha_微笑_c]

[kokutou_真顔]
[vo vo="ep1/koku_0059.ogg"]
#【黒十 美鹤】
「……要是心上人真能这么巧合地出现就好了」[p]
[kokutou_真顔_c]

#
这么说着，在店前的长椅上坐了下来。[p]

[yuzuha_微笑]
[vo vo="ep1/yuzu_0056.ogg"]
#【小仓 柚叶】
「听小百合小姐说周末肯定会来的！」[p]
[yuzuha_微笑_c]

#
柚叶君喘着粗气说着，在我旁边坐下。[p]

[kokutou_哀]
[vo vo="ep1/koku_0060.ogg"]
#【黒十 美鹤】
「不要啦？在这种地方干等好几个小时什么的」[p]
[kokutou_哀_c]

#
光是想想就令人战栗。[p]

这样都不知道为什么揉着困倦的眼睛出门了。[p]

[yuzuha_笑顔]
[vo vo="ep1/yuzu_0057.ogg"]
#【小仓 柚叶】
「都说了没问题的！」[p]

[vo vo="ep1/yuzu_0058.ogg"]
#【小仓 柚叶】
「听小百合小姐说，那个男孩子应该很快就来了」[p]
[yuzuha_笑顔_c]

#
说着，柚叶君取出智能手机。[p]

因为是现代人，柚叶君大概做不到安静等待吧。[p]

[kokutou_真顔]
[vo vo="ep1/koku_0061.ogg"]
#【黒十 美鹤】
「柚叶君，盯着手机屏幕没问题吗？」[p]

[vo vo="ep1/koku_0062.ogg"]
#【黒十 美鹤】
「可能会错过那个男孩子哦？」[p]
[kokutou_真顔_c]

[yuzuha_微笑]
[vo vo="ep1/yuzu_0059.ogg"]
#【小仓 柚叶】
「啊，抱歉」[p]

[vo vo="ep1/yuzu_0060.ogg"]
#【小仓 柚叶】
「想向小百合小姐报告已经到现场了」[p]

[vo vo="ep1/yuzu_0061.ogg"]
#【小仓 柚叶】
「黑十先生，请帮忙留意有没有男孩子进咖啡店」[p]
[yuzuha_微笑_c]

#
柚叶君双手灵巧地操作着手机说道。[p]

[kokutou_哀]
[vo vo="ep1/koku_0063.ogg"]
#【黒十 美鹤】 
「为什么我要……」[p]
[kokutou_哀_c]

#
用听不见的微小声音伴随着叹息嘀咕道。[p]

;柚葉削除
[chara_hide name=yuzuha]

[kokutou_真顔_c]
将视线转向那家咖啡店。[p]

咖啡店似乎已经开业[r]　
从窗户可以看到店内的灯光。[p]

但行人稀少，还没看到有客人进去的光景。[p]


;BGM停止
[bgm_end2]

[kokutou_哀]
[vo vo="ep1/koku_0064.ogg"]
#【黒十 美鹤】
「……嗯？」[p]
[kokutou_哀_c]

#
这时注意到有个少年正望着这边。[p]

不，说是「望着」或许并不准确。[p]

有个正走向咖啡店的少年。[p]

看到他的瞬间，感觉他像是在看这边，但又不确定。[p]

;BGM再生
[bgm ogg="tukikage.ogg"]

[kokutou_怒]
[vo vo="ep1/koku_0065.ogg"]
#【黒十 美鹤】
「柚叶君……那个少年」[p]
[kokutou_怒_c]

#
小声向旁边操作着手机的柚叶君搭话。[p]

[yuzuha_驚き] 
[lec cg="yuzuha"]

[vo vo="ep1/yuzu_0062.ogg"]
#【小仓 柚叶】
「诶？……啊」[p]
[yuzuha_驚き_c]

#
柚叶君发出轻微的惊呼。[p]

在我们注视下，少年径直走进了那家咖啡店。[p]

[yuzuha_驚き]
[vo vo="ep1/yuzu_0063.ogg"]
#【小仓 柚叶】
「黑十先生看到了吗？刚才进咖啡店的男孩！」[p]

[yuzuha_怒鳴る]
[vo vo="ep1/yuzu_0064.ogg"]
#【小仓 柚叶】
「就是小百合小姐单相思的那个消失的男孩，错不了！」[p]

[vo vo="ep1/yuzu_0065.ogg"]
#【小仓 柚叶】
「身高体型都和听说的一致，时间段也基本吻合！」[p]
[yuzuha_怒鳴る_c]

#
看来确实没错。[p]

[kokutou_疑問]
[vo vo="ep1/koku_0066.ogg"]
#【黒十 美鹤】
「那么问题来了」[p]
[yuzuha_疑問_c]

[yuzuha_怒鳴る]
[vo vo="ep1/yuzu_0066.ogg"]
#【小仓 柚叶】
「怎么办？要在这里等他出来吗？」[p]
[yuzuha_怒鳴る_c]

[kokutou_凛]
[vo vo="ep1/koku_0067.ogg"]
#【黒十 美鹤】
「才不要，开什么玩笑」[p]
[kokutou_凛_c]

;BGM停止
[bgm_end3]

;テキストウィンドウ削除
[end_text]

;全キャラ削除
[allc]

;背景：空
[bg10 bg="sky.jpg"]


;テキストウィンドウ表示
[start_text]

;SE：足音フェイドアウト
[se_f se="footstep_room_out.ogg"]

#
说着便起身迈开步子。[p]

[vo vo="ep1/yuzu_0067.ogg"]
#【小仓 柚叶】
「啊，请等一下黑十先生！」[p]

[vo vo="ep1/koku_0068.ogg"]
#【黒十 美鹤】
「据稻饼小姐所说，进店后那个少年就消失了是吧？」[p]

[vo vo="ep1/yuzu_0068.ogg"]
#【小仓 柚叶】
「看起来是这样不过……」[p]

[vo vo="ep1/koku_0069.ogg"]
#【黒十 美鹤】
「既然如此，现在进店确认应该是最快的方法」[p]

[vo vo="ep1/koku_0070.ogg"]
#【黒十 美鹤】
「嘛，虽然现实中根本不可能发生这种事就是了」[p]

#
我和柚叶君亲眼看见那个少年走进了咖啡馆。[p]

这种事情，根本不可能发生。[p]

;テキストウィンドウ削除
[end_text]

;SE：ベルの音
[se_f se="bell00.ogg"]

;背景：白
[bg10 bg="white.png"]

;イベントＣＧ表示
[eval exp="sf.cg_ep1_1 = 1"]
[event_in event="ep1_1"]

;テキストウィンドウ表示
[start_text]


#
推开门的瞬间，响起咖啡馆特有的叮铃铃门铃声。[p]

我立刻快速扫视店内。[p]

[vo vo="ep1/yuzu_0069.ogg"]
#【小仓 柚叶】
「黑、黑十先生……这、这是」[p]


;BGM再生
[bgm ogg="highway.ogg"]

[vo vo="ep1/koku_0071.ogg"]
#【黒十 美鹤】
「…………」[p]

;SE：足音フェイドイン
[se_f se="footsteps_out.ogg"]

#
再次环顾整个店铺。[p]

然而店内空无一人。[p]

[vo vo="ep1/yuzu_0070.ogg"]
#【小仓 柚叶】
「不、不见了……刚才进来的男孩不见了！」[p]

[vo vo="ep1/iori_0001.ogg"]
#【店员】
「欢迎光临，是两位吗？」[p]

;SE：足音フェイドイン
[se_f se="footsteps_in.ogg"]

#
正当我们慌张环视四周时，店员走了过来。[p]

[vo vo="ep1/koku_0072.ogg"]
#【黒十 美鹤】
「请问，这家店的座位只有这一层吗？」[p]

[vo vo="ep1/iori_0002.ogg"]
#【店员】
「咦？啊，是的没错？」[p]

[vo vo="ep1/koku_0073.ogg"]
#【黒十 美鹤】
「刚才在我们进来前，有没有一个少年独自进店？」[p]

[vo vo="ep1/iori_0003.ogg"]
#【店员】
「……少年？没有顾客进来哦？」[p]

[vo vo="ep1/iori_0004.ogg"]
#【店员】
「如您所见，现在店里只有您二位客人」[p]

[vo vo="ep1/yuzu_0071.ogg"]
#【小仓 柚叶】
「怎、怎么会……」[p]

#
听到店员的话，不仅柚叶君，连我也不得不陷入沉默。[p]

;背景：カフェ店内1
[bg1 bg="cafe02.jpg"]

;イベントＣＧ削除
[event_out]

[iori_微笑]
[ce cg="iori"]

[vo vo="ep1/iori_0005.ogg"]
#【店员】
「那个……请问你们是顾客吗？」[p]
[iori_微笑_c]

#
看到我们被问住后沉默不语[r]　
那名店员苦笑着露出困惑的表情。[p]

但藏不住困惑的我们亦是如此。[p]

[vo vo="ep1/master_0001.ogg"]
#【店主】
「小庵？发生什么事了吗？」[p]

;SE：足音フェイドイン
[se_f se="footsteps_in.ogg"]

[kill]
[iori_微笑_c]
[ric cg="iori"]
[master_微笑_c] 
[lec cg="master"]

#
正当众人困惑时，从柜台后方走出一位女性。[p]


看样子似乎是这家店的店主。[p]

[iori_微笑]
[vo vo="ep1/iori_0006.ogg"]
#【店员】
「啊、店主，不是的，那个」[p]
[iori_微笑_c]

[vo vo="ep1/koku_0074.ogg"]
#【黒十 美鹤】
「店主，这家咖啡馆工作的只有女性吗？」[p]

#
我突然想起便开口询问。[p]

[master_微笑]
[vo vo="ep1/master_0002.ogg"]
#【店主】
「咦？啊、是的没错哦」[p]
[master_微笑_c]

[master_笑顔]
[vo vo="ep1/master_0003.ogg"]
#【店主】
「就只有我和那边的小庵呢，呵呵呵」[p]
[master_笑顔_c]

#
不知觉得哪里有趣，店主心情愉快地笑了起来。[p]

;全キャラ削除
[kill]

[kokutou_疑問_c]
[ric cg="kokutou"]
[yuzuha_哀_c] 
[lec cg="yuzuha"]

[yuzuha_哀] 
[vo vo="ep1/yuzu_0072.ogg"]
#【小仓 柚叶】
「这简直和小百合小姐说的情况完全吻合……」[p]
[yuzuha_哀_c]
 
#
后方传来柚叶君的喃喃低语。[p]

确实，此刻的情形与昨日听闻的叙述分毫不差。[p]

也就是说――[p]

[kokutou_怒]
[vo vo="ep1/koku_0075.ogg"]
#【黒十 美鹤】
「男孩子……消失了？」[p]
[kokutou_怒_c]

;テキストウィンドウ削除
[end_text]

;BGM停止
[bgm_end3]

[allc]

;背景：白
[bg10 bg="white.png"]

;シーン4へ移動
[jump  storage="ep1_scene04.ks"]
[s]
