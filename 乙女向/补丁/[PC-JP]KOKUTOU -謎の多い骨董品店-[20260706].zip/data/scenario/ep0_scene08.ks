﻿;--------------------------------------------------
;■黒十　本文テキスト　ep0 懐古趣味の回顧録　
;--------------------------------------------------
;
;■ep0_scene08
;
;--------------------------------------------------
;シナリオ分岐の設定
;
;▼コレクションを見る
;　花器　f.collection_vase=1
;　メダル　f.collection_medal=1
;　リトグラフ　f.collection_lithograph=1
;　手鏡　f.collection_mirror=1
;
;
;▼詳細を見る
;　花器　f.search_vase=1
;　メダル　f.search_medal=1
;　リトグラフ　f.search_lithograph=1
;　手鏡　f.search_mirror=1
;
;--------------------------------------------------

;背景　孤島の船着き場
[bg10 bg="cruiser_3.jpg"]

;--------------------------------------------------
*080000
[savetitle text="小倉杏葉の真実"]
;--------------------------------------------------

[azuha_c_カーディガン]
[azuha_微笑_c]
[lec_f cg="azuha"]

[kokutou_c_書生服]
[kokutou_哀]
[ric cg="kokutou"]

尽管衣服还没完全干透，我已在码头等候船只。[p]


[vo vo="ep0/azuha_0193.ogg"]
[azuha_微笑]
#【小仓 杏叶】
「小心别再掉进海里了」[p]
[azuha_微笑_c]

#
小仓杏叶不仅没有关心这样的我，反而带着嘲弄的语气说道。[p]

[vo vo="ep0/koku_0349.ogg"]
[kokutou_哀2]
#【黒十 美鹤】
「您觉得我是因为谁才掉下去的？」[p]
[kokutou_哀2_c]

[vo vo="ep0/azuha_0194.ogg"]
[azuha_微笑]
#【小仓 杏叶】
「反正不是因为我吧？」[p]

[vo vo="ep0/azuha_0195.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「不过嘛……这次的事还是得谢谢你」[p]
[azuha_真顔_c]

[vo vo="ep0/koku_0350.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「不必了，我只是找到了画而已」[p]
[kokutou_哀_c]

[vo vo="ep0/azuha_0196.ogg"]
[azuha_微笑]
#【小仓 杏叶】
「不是指这个，是说你救了柚叶的事」[p]
[azuha_微笑_c]
#
听到这句话，我明白了一件事。[p]

这是自从来到这座岛后，一直令我感到费解的事。[p]

[vo vo="ep0/koku_0351.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「……您对令妹[r]　
　……对柚叶君表达爱的方式是错误的」[p]
[kokutou_真顔_c]

[vo vo="ep0/azuha_0197.ogg"]
[azuha_真顔_c]
#【小仓 杏叶】
「…………」[p]
#
听到我的话，她的表情消失了。[p]

[vo vo="ep0/koku_0352.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「这件事我一直很在意」[p]

[vo vo="ep0/koku_0353.ogg"]
#【黒十 美鹤】
「为什么您要把柚叶君带到这座岛上的宅邸来」[p]

[vo vo="ep0/koku_0354.ogg"]
#【黒十 美鹤】
「就这次事件而言，显然没有她在场[r]　
　对您来说事情会更顺利」[p]

[vo vo="ep0/koku_0356.ogg"]
#【黒十 美鹤】
「可您却特意把柚叶君带来了」[p]

[vo vo="ep0/koku_0357.ogg"]
#【黒十 美鹤】
「那是因为那座宅邸对柚叶君而言[r]　
　是与祖父的回忆之地」[p]
[kokutou_真顔_c]
#
核对清单与收藏品时[r]　
她常向我讲述与祖父的回忆。[p]

[vo vo="ep0/koku_0358.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「更何况[r]　
　你之所以让柚叶君远离祖父的死亡[p]

[vo vo="ep0/koku_0359.ogg"]
#【黒十 美鹤】
「甚至不惜用那种威胁般的手段掩盖事情经过[r]　
　不让柚叶君知晓真相　就是这个原因吧」[p]
[kokutou_真顔_c]
#
最初我以为，姐姐小仓杏叶根本不爱妹妹。[p]

然而，这与方才道谢的话语又有不同之处。[p]

小仓杏叶深爱着她的妹妹。[p]

然而这种做法显然是错误的吧。[p]

[vo vo="ep0/azuha_0198.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「你这话……说得可真够过分的啊」[p]
[azuha_真顔_c]

[vo vo="ep0/koku_0360.ogg"]
[kokutou_怒]
#【黒十 美鹤】
「您觉得呢？」[p]
[kokutou_怒_c]

#
当我再次追问时，我察觉到自己的心中[r]　
弥漫着一股难以名状的烦闷。[p]

同时也意识到那是一种近似愤怒的感情。[p]

为何自己的情绪会异常高涨呢。[p]

是因为和那个少女长时间待在一起的缘故吗。[p]

还是因为目睹了那个少女所处的立场呢。[p]

准备一个冠冕堂皇的回答很容易[r]　
但却怎么也无法令人信服。[p]

[vo vo="ep0/azuha_0199.ogg"]
[azuha_悪い笑顔]
#【小仓 杏叶】
「那么，你觉得呢」[p]
[azuha_悪い笑顔_c]
#
然而最终，小仓杏叶还是避开了回答。[p]

[vo vo="ep0/azuha_0200.ogg"]
[azuha_微笑]
#【小仓 杏叶】
「比起那个 道谢要先来啦」[p]
[azuha_微笑_c]

[vo vo="ep0/koku_0361.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「……所以说不需要啦，那种东西」[p]
[kokutou_哀_c]

[vo vo="ep0/azuha_0201.ogg"]
[azuha_微笑]
#【小仓 杏叶】
「那样的话我的心情可平复不下来哦」[p]

[vo vo="ep0/azuha_0202.ogg"]
#【小仓 杏叶】
「而且我可是小仓家的人？」[p]

[vo vo="ep0/azuha_0203.ogg"]
#【小仓 杏叶】
「小仓家的人向来一言九鼎」[p]
[azuha_微笑_c]

#
她的眼神在说 不允许再有更多顶嘴。[p]

[vo vo="ep0/koku_0362.ogg"]
[kokutou_呆れ]
#【黒十 美鹤】
「那么……究竟要为我做什么？」[p]
[kokutou_呆れ_c]

#
他边说着"真是够了"边摇头。[p]

[vo vo="ep0/azuha_0204.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「这个嘛……」[p]
[azuha_呆れ2_c]
#
沉吟片刻后，小仓杏叶说道。[p]

[vo vo="ep0/azuha_0205.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「你之前是不是说过关于店铺的事来着？」[p]
[azuha_真顔_c]

[vo vo="ep0/koku_0363.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「………………啊？」[p]
[kokutou_驚き_c]


;全キャラ削除
[allc]


;時系列が現代に戻る。[p]

;//BG:骨董品店事務所
[bg10 bg="antique.jpg"]

;--------------------------------------------------
*080100
[savetitle text="曰く付きの骨董品店"]
;--------------------------------------------------

[yuzuha_疑問]
[lec_f cg="yuzuha"]

[kokutou_c_夏]
[kokutou_哀_c]
[ric cg="kokutou"]

[vo vo="ep0/yuzuha_0199.ogg"]
#【小仓 柚叶】
「哎呀？黑十先生，怎么了？突然脸色发青哦？」[p]
[yuzuha_疑問_c]

[vo vo="ep0/koku_0364.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「……没、没什么特别的」[p]
[kokutou_哀_c]

#
最终也没能拒绝成功[r]　
后来小仓家连带着地皮把这里全部收购了。[p]

更惊人的是他们直接将其转让给了我。[p]

[kokutou_呆れ_c]
这里毫无疑问是黄金地段。[p]

四周林立着亿万富豪的豪宅[r]　
是遍布历史建筑的城区。[p]

说真的 我实在理解不了过度富裕之人的想法。[p]

不，应该说根本不想理解。[p]

不过多亏了那个提议[r]　
我如愿以偿在此地开了间古董店。[p]

;時系列を過去に移る。[p]
;全キャラ削除
[allc]


;背景　孤島の船着き場
[bg10 bg="cruiser_3.jpg"]



[azuha_真顔_c]
[lec_f cg="azuha"]

[kokutou_c_書生服]
[kokutou_哀2_c]
[ric cg="kokutou"]


[vo vo="ep0/koku_0365.ogg"]
#【黒十 美鹤】
「…………」[p]
#
虽然对方提出了荒唐的要求，但多半是玩笑吧。[p]

但愿这只是个玩笑。[p]

[vo vo="ep0/koku_0366.ogg"]
[kokutou_呆れ]
#【黒十 美鹤】
「……就是啊，这笔钱怎么可能随便就给出来」[p]
[kokutou_呆れ_c]
#
正当我独自释然时，小仓杏叶又抛来话语。[p]

[vo vo="ep0/azuha_0206.ogg"]
[azuha_c_夏]
[azuha_真顔]
#【小仓 杏叶】
「还有，这个」[p]
[azuha_真顔_c]
[kokutou_c_カーディガン]
[kokutou_驚き_c]

#
伴着柔和的香气，针织开衫轻轻披上了我的肩头。[p]

[vo vo="ep0/azuha_0207.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「就算是夏天，穿这么少也会感冒的哦」[p]
[azuha_真顔_c]

[vo vo="ep0/koku_0367.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「谢、谢谢」[p]
[kokutou_疑問_c]

#
;SE　携帯の鳴る音
;SE：携帯の着信音
[se_w se="mobile-phone-ringtone1.ogg"]

[kokutou_驚き_c]
小仓杏叶的手机响了。[p]

[vo vo="ep0/azuha_0208.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「知道了……嗯，马上回去」[p]
[azuha_真顔_c]

#
她接起电话只说了一句就立刻挂断。[p]

[vo vo="ep0/koku_0368.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「啊，这就要走了吗？」[p]
[kokutou_真顔_c]

[vo vo="ep0/azuha_0209.ogg"]
[azuha_悪い笑顔]
#【小仓 杏叶】
「嗯，因为还有些事要问须天」[p]

[vo vo="ep0/azuha_0210.ogg"]
#【小仓 杏叶】
「在交给警方之前，必须让他吐出各种情报来源才行」[p]
[azuha_悪い笑顔_c]

[vo vo="ep0/koku_0369.ogg"]
[kokutou_哀2]
#【黒十 美鹤】
「……听、听起来真不容易呢」[p]
[kokutou_哀2_c]

#
我只能报以苦笑。[p]

[vo vo="ep0/azuha_0211.ogg"]
[azuha_呆れ]
#【小仓 杏叶】
「反正肯定是受饴宫指使的团体吧」[p]

[vo vo="ep0/azuha_0212.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「……嗯？」[p]
[azuha_真顔_c]

#
小仓杏叶的视线定格在某处。[p]

那里站着她妹妹——小仓柚叶。[p]

[vo vo="ep0/azuha_0213.ogg"]
[azuha_微笑]
#【小仓 杏叶】
「柚叶，你替我送送这个男人」[p]
[azuha_微笑_c]

[vo vo="ep0/yuzuha_0200.ogg"]
[yuzuha_s_微笑]
#【小仓 柚叶】
「好、好的！」[p]
[yuzuha_s_微笑_c]

[vo vo="ep0/azuha_0214.ogg"]
[azuha_微笑]
#【小仓 杏叶】
「呵，真是……相当中意你呢，黑十美鹤」[p]
[azuha_微笑_c]

;杏葉消去
[hide_azuha]

#
说完这句话，小仓杏叶便离开了现场。[p]

;--------------------------------------------------
*080200
[savetitle text="お別れ"]
;--------------------------------------------------


[yuzuha_s_不安_c]
[lec cg="yuzuha_s"]

取而代之的是她的妹妹小仓柚叶跑了过来。[p]

[vo vo="ep0/yuzuha_0201.ogg"]
[yuzuha_s_不安]
#【小仓 柚叶】
「科克托……你要走了吗？」[p]
[yuzuha_s_不安_c]

[vo vo="ep0/koku_0370.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「嗯，因为船的时间到了」[p]
[kokutou_真顔_c]

[vo vo="ep0/yuzuha_0202.ogg"]
[yuzuha_s_不安]
#【小仓 柚叶】
「唔……明明可以再多待一会的」[p]
[yuzuha_s_不安_c]

#
明显地耷拉下肩膀沮丧地低下头。[p]

初次见到她的模样时，只觉得是个难以捉摸的存在。[p]

但如今这样看来，她也并没有什么特别，只是个普通的孩子。[p]

[vo vo="ep0/yuzuha_0203.ogg"]
[yuzuha_s_不安]
#【小仓 柚叶】
「那个……还能，再见面吗？」[p]
[yuzuha_s_不安_c]

[vo vo="ep0/koku_0371.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「谁知道呢」[p]
[kokutou_哀_c]

#
至少我绝不会再踏上这座岛了吧。[p]

即便这里还有多么珍贵的古董。[p]

[vo vo="ep0/yuzuha_0204.ogg"]
[yuzuha_s_真顔]
#【小仓 柚叶】
「……呐，科克托」[p]
[yuzuha_s_真顔_c]

[vo vo="ep0/koku_0372.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「怎么了」[p]
[kokutou_真顔_c]

#
当我回应时，少女猛地抬起低垂的脸。[p]


;イベントＣＧ表示
[eval exp="sf.cg_ep0_4 = 1"]
[event_in event="ep0_4"]

[vo vo="ep0/yuzuha_0205.ogg"]
[yuzuha_s_叫び]
#【小仓 柚叶】
「科克托你是怎么看待我的！？」[p]
[yuzuha_s_叫び_c]

[vo vo="ep0/koku_0373.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「…………哈？」[p]
[kokutou_驚き_c]

#
意外的话语让思维瞬间停滞。[p]

片刻后我能做到的[r]　
只有朝少女身后稍远处的佣人摆出冷脸。[p]

没能得到预期反应的少女[r]　
涨红着脸发出不满的嘟囔声。[p]

[vo vo="ep0/yuzuha_0206.ogg"]
[yuzuha_s_叫び]
#【小仓 柚叶】
「呜啊啊啊……科、科克托喜欢什么类型的女孩子嘛！？」[p]
[yuzuha_s_叫び_c]

#
少女的话让我忍不住抱住了头。[p]

「看来相当中意你呢」，这是少女姐姐的话[r]　
没想到竟到如此地步。[p]

思考着该如何应对。[p]

但是，然而。[p]

[vo vo="ep0/koku_0374.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「嗯……总之[r]　
是个能对长辈使用敬语说话的女孩子，对吧」[p]
[kokutou_真顔_c]
#
若说现在的提问我能回答的，大概也就这些了吧。[p]

[vo vo="ep0/yuzuha_0207.ogg"]
[yuzuha_s_微笑]
#【小仓 柚叶】
「敬语……嗯，明白了！」[p]
[yuzuha_s_微笑_c]

[vo vo="ep0/yuzuha_0208.ogg"]
[yuzuha_s_笑顔]
#【小仓 柚叶】
「……啊、不、不是！明白了！黑十先生！」[p]
[yuzuha_s_笑顔_c]

;イベントＣＧ削除
[event_out]

#
少女微不可察地成长了些许与[r]　
游艇抵达码头几乎是同一时刻。[p]

[vo vo="ep0/yuzuha_0209.ogg"]
[yuzuha_s_笑顔]
#【小仓 柚叶】
「黑十先生……！拜、拜拜！」[p]
[yuzuha_s_笑顔_c]


;全キャラ削除
[allc]

;//BG:青空
[bg10 bg="sky3.jpg"]

#
对着登船的我，少女呼啦啦地挥手。[p]

[vo vo="ep0/yuzuha_0210.ogg"]
#【小仓 柚叶】
「我会去找你的！[r]　
　等我长大以后，一定会去黑十先生那里找你的！」[p]

[vo vo="ep0/yuzuha_0211.ogg"]
#【小仓 柚叶】
「绝对绝对！一定会去的！」[p]

#
朝着渐远的船只，少女拼命这样喊着。[p]

看那架势，恐怕直到船影消失前都会在原地挥手吧。[p]


;//BG:船
[bg10 bg="cruiser_1.jpg"]

[kokutou_哀2]
[ric cg="kokutou"]

[vo vo="ep0/koku_0375.ogg"]
#【黒十 美鹤】
「哈啊，会来找我，吗……嗯？」[p]
[kokutou_哀2_c]

#
凝视着远去的岛屿时，突然注意到一件事。[p]
[kokutou_驚き_c]

口袋传来奇妙的重量感。[p]

究竟是什么东西呢，取出来确认着。[p]

那里放着一枚用来开启密室的石徽章。[p]

[vo vo="ep0/koku_0376.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「为、为什么这东西会在这里……？」[p]
[kokutou_疑問_c]
#
装有徽章的是方才小仓杏叶披在我身上的外套。[p]

看来她把从仆人那里取回的东西塞进口袋[r]　
就这样把外套给了我吧。[p]

[kokutou_真顔_c]
必须立刻去归还——我将视线投向岛屿。[p]

但此刻那个岛已远去至[r]　
海天交界若隐若现之处。[p]

[vo vo="ep0/koku_0377.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「……哈，真是够了」[p]
#

;全キャラ削除
[allc]

;BGM停止
[bgm_end3]

;時間軸が現在へ戻る。[p]

;背景　骨董品店事務所
;//BG:骨董品店事務所
[bg10 bg="antique.jpg"]


;--------------------------------------------------
*080300
[savetitle text="懐古趣味の回顧録"]
;--------------------------------------------------

;BGM再生
[bgm ogg="mid_re.ogg"]

[yuzuha_微笑_c]
[lec_f cg="yuzuha"]

[kokutou_c_夏]
[kokutou_哀]
[ric cg="kokutou"]

[vo vo="ep0/koku_0378.ogg"]
#【黒十 美鹤】
「……这样应该差不多了吧」[p]
[kokutou_哀_c]
#

[yuzuha_疑問2_c]
感觉把很久以前的往事[r]　
又喋喋不休地说了很久。[p]

终归是过去的事了。[p]

或许存在记忆模糊或稍加润色的部分。[p]

但故事主干应该没有偏差。[p]

何况那样刻骨铭心的事，想忘也忘不掉。[p]

[vo vo="ep0/yuzuha_0212.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「……咦？诶诶！？」[p]

[vo vo="ep0/yuzuha_0213.ogg"]
#【小仓 柚叶】
「请、请等一下！」[p]

[vo vo="ep0/yuzuha_0214.ogg"]
#【小仓 柚叶】
「也就是说[r]　
　那把钥匙现在还在黑十先生手里！？」[p]
[yuzuha_驚き_c]
#
柚叶君发出惊叫。[p]

我并未作答，只是站起身来。[p]

[vo vo="ep0/koku_0379.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「好了，回忆就到此为止吧」[p]
[kokutou_真顔_c]
#
已到该前往商谈的时间了。[p]

将事先准备好的文件小心收进包中以免遗忘。[p]

[vo vo="ep0/yuzuha_0215.ogg"]
[yuzuha_怒鳴る]
#【小仓 柚叶】
「不行不行！都说到这个份上了怎能不告诉我！」[p]

[vo vo="ep0/yuzuha_0216.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「钥匙是石徽章这件事，我已经回忆起来了」[p]

[vo vo="ep0/yuzuha_0217.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「而最终，徽章是由黑十先生保管的对吧？」[p]
[yuzuha_疑問_c]

[vo vo="ep0/koku_0380.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「是的，正是如此」[p]
[kokutou_微笑_c]

[vo vo="ep0/yuzuha_0218.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「依黑十先生的性格，想必是珍重收藏起来了吧？」[p]
[yuzuha_疑問_c]

[vo vo="ep0/koku_0381.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「不......是珍重地使用着呢」[p]
[kokutou_微笑_c]

[vo vo="ep0/yuzuha_0219.ogg"]
[yuzuha_疑問2]
#【小仓 柚叶】
「......哎？」[p]
[yuzuha_疑問2_c]

[vo vo="ep0/koku_0382.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「恕我失礼，就此告辞了」[p]

[vo vo="ep0/koku_0383.ogg"]
#【黒十 美鹤】
「若不同行的话，锁门就拜托了」[p]
[kokutou_微笑_c]

#
说罢我离开事务所。[p]

留在原地的柚叶君似乎对我的话困惑不解。[p]

[vo vo="ep0/yuzuha_0220.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「使用......啊」[p]
[yuzuha_驚き_c]

;回想　杏葉が石のメダルに対して言った言葉
[event_in event="ep0_003"]

[vo vo="ep0/azuha_0035.ogg"]
#【小仓 杏叶】
「这种东西当镇纸用倒挺合适」[p]

;回想ここまで
[event_out]

[vo vo="ep0/yuzuha_0221.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「镇纸...镇纸...难道...纸镇！！」[p]

[yuzuha_驚き_c]

#
听到恍然大悟的柚叶君发出惊呼。[p]

[yuzuha_笑顔]
正如小仓杏叶所说[r]　
那枚石徽章被我当作纸镇使用。[p]

柚叶君似乎对此十分怀念。[p]

;BGM停止
[bgm_end3]

;全キャラ削除
[allc]

对她投来的目光视若无睹，我离开了心爱的古董店。[p]



;エンディング

;BGM再生
[bgm ogg="shakespeare.ogg"]

;//店の前
[bg20 bg="shop_kokutou.jpg"]

[vo vo="ep0/yuzuha_0222.ogg"]
#【小仓 柚叶】
「黑十先生！请等一下～！」[p]


#
柚叶君从后面追了上来。[p]

[yuzuha_微笑_c]
[lec_f cg="yuzuha"]

[kokutou_c_夏]
[kokutou_真顔]
[ric cg="kokutou"]

[vo vo="ep0/koku_0384.ogg"]
#【黒十 美鹤】
「啊、店门锁好了吗？」[p]
[kokutou_真顔_c]

[vo vo="ep0/yuzuha_0223.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「嗯、完美搞定！」[p]

[vo vo="ep0/yuzuha_0224.ogg"]
[yuzuha_怒]
#【小仓 柚叶】
「唔、不是问这个啦！」[p]

[vo vo="ep0/yuzuha_0225.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「我可被吓到了哦！」[p]

[vo vo="ep0/yuzuha_0226.ogg"]
#【小仓 柚叶】
「没想到黑十先生居然那样使用石徽章！」[p]
[yuzuha_微笑_c]

[vo vo="ep0/koku_0385.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「啊哈哈，毕竟那是珍贵的古董嘛」[p]

[vo vo="ep0/koku_0386.ogg"]
#【黒十 美鹤】
「不过呢，有个[r]　
　能这样使用的古董也不错吧」[p]
[kokutou_微笑_c]

[vo vo="ep0/yuzuha_0227.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「……啊、那个、黑十先生？」[p]
[yuzuha_微笑_c]

[vo vo="ep0/koku_0387.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「怎么了？」[p]
[kokutou_疑問_c]

[vo vo="ep0/yuzuha_0228.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「最后还有一件事不太明白」[p]
[yuzuha_微笑_c]

[kokutou_疑問]
[vo vo="ep0/koku_0388.ogg"]
#【黒十 美鹤】
「不明白的事？」[p]
[kokutou_疑問_c]

[yuzuha_疑問]
[vo vo="ep0/yuzuha_0229.ogg"]
#【小仓 柚叶】
「是的……」[p]
[yuzuha_疑問_c]

[vo vo="ep0/koku_0389.ogg"]
[kokutou_呆れ]
#【黒十 美鹤】
「唉、那件事就别再提了吧」[p]
[kokutou_呆れ_c]

[yuzuha_疑問]
[vo vo="ep0/yuzuha_0230.ogg"]
#【小仓 柚叶】
「啊、不对不是那个……咦、或许就是呢？」[p]


[vo vo="ep0/yuzuha_0231.ogg"]
#【小仓 柚叶】
「要说是那时的事确实是那时……[r]　
　要说今后的话，就是今后之类的？」[p]
[yuzuha_疑問_c]

[vo vo="ep0/koku_0390.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「到底怎么了？」[p]
[kokutou_疑問_c]

[vo vo="ep0/yuzuha_0232.ogg"]
[yuzuha_etc_頬]
[yuzuha_哀]
#【小仓 柚叶】
「那个、直、直截了当地说……」[p]

[vo vo="ep0/yuzuha_0233.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「黑十先生……您是怎么看待我的呢？」[p]
[yuzuha_哀_c]

[vo vo="ep0/koku_0391.ogg"]
#【黒十 美鹤】
「……什么怎么看待」[p]

[vo vo="ep0/yuzuha_0234.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「那时您不是没回答我吗！」[p]

[vo vo="ep0/yuzuha_0235.ogg"]
[yuzuha_怒]
#【小仓 柚叶】
「所以现在想再问一次！」[p]

[vo vo="ep0/yuzuha_0236.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「黑十先生，您是怎么看待我的呢？」[p]
[yuzuha_微笑_c]

[vo vo="ep0/koku_0392.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「………………」[p]
[kokutou_真顔_c]

[vo vo="ep0/yuzuha_0237.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「那个……黑十先生？」[p]
[yuzuha_疑問_c]

[vo vo="ep0/koku_0393.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「要说明这个谜题的答案，恐怕需要花些时间」[p]
[kokutou_真顔_c]

[vo vo="ep0/yuzuha_0238.ogg"]
[yuzuha_疑問2]
#【小仓 柚叶】
「时间……大、大概要多久呢？」[p]
[yuzuha_疑問2_c]

[vo vo="ep0/koku_0394.ogg"]
[kokutou_呆れ]
#【黒十 美鹤】
「让我想想啊……[r]　
　至少得等我从小伙子变成老头子吧」[p]
[kokutou_呆れ_c]

[vo vo="ep0/yuzuha_0239.ogg"]
[yuzuha_疑問2]
#【小仓 柚叶】
「诶？」[p]
[yuzuha_疑問2_c]

[vo vo="ep0/koku_0395.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「不，说不定到死都解不开呢」[p]
[kokutou_真顔_c]

[vo vo="ep0/yuzuha_0240.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「黑、黑十先生……这、这是……那个……」[p]
[yuzuha_驚き_c]

[vo vo="ep0/koku_0396.ogg"]
[kokutou_凛]
#【黒十 美鹤】
「柚叶君」[p]
[kokutou_凛_c]

[vo vo="ep0/yuzuha_0241.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「在、在的！」[p]
[yuzuha_驚き_c]

[vo vo="ep0/koku_0397.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「但愿直到那时[r]　
　柚叶君都愿意陪我解这个谜」[p]
[kokutou_微笑_c]

[vo vo="ep0/yuzuha_0242.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「……那当然！我会永远永远陪在您身边的！」[p]
[yuzuha_etc_off]

[vo vo="ep0/yuzuha_0243.ogg"]
#【小仓 柚叶】
「……黑十先生」[p]
[yuzuha_笑顔_c]

[vo vo="ep0/koku_0398.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「怎么了」[p]
[kokutou_真顔_c]

[vo vo="ep0/yuzuha_0244.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「请您务必……活得长久些好吗？」[p]
[yuzuha_笑顔_c]

[vo vo="ep0/koku_0399.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「哈啊……真拿你没办法」[p]
[kokutou_微笑_c]
#

;テキストウィンドウ削除
[end_text]

;全キャラ削除
[allc]

;スタッフロールへ移動
[jump  storage="ep0_staff.ks"]


[s]

