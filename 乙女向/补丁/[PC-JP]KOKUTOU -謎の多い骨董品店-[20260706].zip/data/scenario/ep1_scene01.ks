﻿;--------------------------------------------------
;■黒十　本文テキスト　ep1　消えた初恋の謎
;--------------------------------------------------
;
;■ep1_scene01
;
;--------------------------------------------------
;シナリオ分岐の設定
[eval exp="f.cup_choose=0"]
[eval exp="f.怪しい=0"]

;OP
[movie storage="op1.webm" skip=true volume="40"]
;--------------------------------------------------
*010000
[savetitle text="骨董品店『KOKUTOU』"]
;-------------------------------------------------
[cm]

;BGM再生
[bgm ogg="mid_re.ogg"]

;背景
[bg30 bg="shop_kokutou.jpg"]

;テキストウィンドウ表示
[start_text]

能俯瞰海港的山丘上静静伫立着一家古董店『KOKUTOU』。[p]

这家由我出于兴趣爱好经营的店铺里，汇集了诸多珍贵的藏品。[p]

;背景
[bg10  bg="antique.jpg"]


[kokutou_c_夏]
[kokutou_微笑_c]
[ce cg="kokutou"]

[kokutou_微笑]
[vo vo="ep1/koku_0001.ogg"]
#【黒十 美鹤】
「不是19世纪俄罗斯贵族[r]　
　而是由町民制作的复活节彩蛋……」[p]

[vo vo="ep1/koku_0002.ogg"]
#【黒十 美鹤】
「虽然是模仿帝国复活节彩蛋制作的[r]　
　但还原度极高！」[p]

[vo vo="ep1/koku_0003.ogg"]
#【黒十 美鹤】
「要说区别的话也就是是否镶嵌了宝石[r]　
　这种程度了吧」[p]

[vo vo="ep1/koku_0004.ogg"]
#【黒十 美鹤】
「而且这保存状态……不错！这个真不错！」[p]
[kokutou_微笑_c]

#
这次入手的正是这个复活节彩蛋。[p]

;カットイン表示
[cut_in cut="cut_egg.png"]

#
在历史悠久的港口小镇开设古董店，就容易汇集这类珍品。[p]

我之所以经营这种麻烦的营生，正是出于这个理由。[p]

[kokutou_微笑]
[vo vo="ep1/koku_0005.ogg"]
#【黒十 美鹤】
「那么……究竟藏着怎样的惊喜呢……」[p]
[kokutou_微笑_c]

#
按捺不住胸口的悸动，朝复活节彩蛋伸出手去。[p]

[vo vo="ep1/yuzu_0001.ogg"]
#【？？？】
「黑十先生——！」[p]

#
就在此时，身后突然传来呼喊声。[p]

;カットイン削除
[cut_out]

[kokutou_哀_c]
#
汇集到这家古董店的不仅仅是稀世珍品。[p]

回头望去，门前站着一位年轻的女学生。[p]

[kill]
[kokutou_哀_c]
[ric_f cg="kokutou"]

[yuzuha_c_夏]
[yuzuha_哀_c]
[lec cg="yuzuha"]

;SE：足音フェイドイン
[se_f se="footsteps_in.ogg"]

[yuzuha_哀]
[vo vo="ep1/yuzu_0002.ogg"]
#【？？？】
「您该不会——又在对着老掉牙的破铜烂铁自我陶醉吧？」[p]
[yuzuha_哀_c]

[kokutou_哀]
[vo vo="ep1/koku_0006.ogg"]
#【黒十 美鹤】
「柚叶君、这不是老掉牙的破烂[r]　
　是复活节彩蛋」[p]
[kokutou_哀_c]

#
擅自闯入店铺办公室的女学生是小仓柚叶君。[p]

[yuzuha_疑問]
[vo vo="ep1/yuzu_0003.ogg"]
#【小仓 柚叶】
「复活节彩蛋？那是什么啊，鸡蛋？」[p]
[yuzuha_疑問_c]

[kokutou_哀]
[vo vo="ep1/koku_0007.ogg"]
#【黒十 美鹤】
「……你不知道吗？[r]　
　小仓财阀的千金居然不知道复活节彩蛋」[p]
[kokutou_哀_c]

[yuzuha_怒]
[vo vo="ep1/yuzu_0004.ogg"]
#【小仓 柚叶】
「唔……那种事根本没关系啦，我可是现代人！」[p]

[vo vo="ep1/yuzu_0005.ogg"]
#【小仓 柚叶】
「对老掉牙的破烂才没兴趣呢！」[p]
[yuzuha_怒_c]

[kokutou_怒]
[vo vo="ep1/  koku_0008.ogg"]
#【黒十 美鹤】
「好啦好啦，所以呢？现代人柚叶君到底有何贵干？」[p]
[kokutou_怒_c]

[yuzuha_驚き]
[vo vo="ep1/yuzu_0006.ogg"]
#【小仓 柚叶】
「啊！对对！我忘记说了！」[p]

[vo vo="ep1/yuzu_0007.ogg"]
#【小仓 柚叶】
「黑十先生！发生不得了的大事了！」[p]
[yuzuha_驚き_c]

[kokutou_真顔]
[vo vo="ep1/koku_0009.ogg"]
#【黒十 美鹤】
「不得了的事？」[p]
[kokutou_真顔_c]

#
不祥的预感让我不禁耸了耸肩。[p]

看来这家古董店[r]　
又聚集了多余的东西。[p]

[yuzuha_驚き]
[vo vo="ep1/yuzu_0008.ogg"]
#【小仓 柚叶】
「是啊！消失啦！有人！突然就！」[p]

[yuzuha_怒鳴る]
[vo vo="ep1/yuzu_0009.ogg"]
#【小仓 柚叶】
「太蹊跷了！又有谜题凭空砸到我们面前了！黑十先生！」[p]
[yuzuha_怒鳴る_c]

[kokutou_疑問_c]
#
这对我而言，又是个不受欢迎的谜题。[p]

;テキストウィンドウ削除
[end_text]

;BGM停止
[bgm_end3]

;全キャラ削除
[allc]

;背景
[bg20 bg="white.png"]

;シーン2へ移動
[jump  storage="ep1_scene02.ks"]
[s]
