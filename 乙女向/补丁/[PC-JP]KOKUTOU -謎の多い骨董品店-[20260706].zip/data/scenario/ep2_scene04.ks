﻿;--------------------------------------------------
;■黒十　本文テキスト　ep2　招かれざる常連客
;--------------------------------------------------
;
;■ep2_scene04
;
;--------------------------------------------------
*016000
[savetitle text="黒髪の少女が席を立った"]
;-------------------------------------------------


[kill]
[kaguya_無表情_c]
[ce cg="kaguya"]

一切都说完时 那位黑发少女从座位起身[p]

看来是准备踏上归途[p]

她就这么经过我和柚叶君的座位 排队走向收银台[p]

[vo vo="ep2/kaguya_0003.ogg"]
[kaguya_無表情]
#【黑发少女】
「店主 多谢款待」[p]


[kill]
[kaguya_無表情_c]
[ri_f cg="kaguya"]
[master_微笑]
[le cg="master"]

[vo vo="ep2/master_0031.ogg"]
#【店主】
「哎呀 这就要走了吗？」[p]
[master_微笑_c]

[vo vo="ep2/kaguya_0004.ogg"]
[kaguya_無表情]
#【黑发少女】
「嗯 今天又打扰您这么久」[p]
[kaguya_無表情_c]

[vo vo="ep2/master_0032.ogg"]
[master_微笑]
#【店主】
「哪里哪里 谢谢惠顾」[p]
[master_微笑_c]

#
店主对黑发少女的问候报以与往常无异的微笑[p]

;キャラ消去
[chara_hide name=master]

结完账后 她转身朝出口走去[p]

;SE：足音フェイドイン
[se_f se="footsteps_in.ogg"]


[kokutou_真顔_c]
[ce_f cg="kokutou"]
[yuzuha_微笑_c]
[le cg="yuzuha"]


经过时 黑发少女在我和柚叶君的座位前停下了脚步[p]

然后――[p]

;BGM再生
[bgm ogg="you_are_precious.ogg"]

[kokutou_凛_c]

[vo vo="ep2/kaguya_0005.ogg"]
[kaguya_無表情]
#【黑发少女】
「只有一点 你说错了」[p]
[kaguya_無表情_c]

#
听到这句话 我不禁露出苦笑[p]

[kokutou_真顔_c]

看来这少女长着顺风耳呢[p]

[vo vo="ep2/yuzu_0201.ogg"]
[yuzuha_怒鳴る]
#【小仓柚叶】
「哪、哪里……哪里说错了！？　请教教我！」[p]
[yuzuha_怒鳴る_c]

#
柚叶君猛地站起来 双手拍在桌上[p]

与战战兢兢的我形成鲜明对比 柚叶君毫不胆怯地反问道[p]

这种地方展现的厚脸皮 或许我也该学着点[p]

[vo vo="ep2/kaguya_0006.ogg"]
[kaguya_無表情
#【黑发少女】
「我……并不是相信约定」[p]


;イベントＣＧ表示
[eval exp="sf.cg_ep2_2 = 1"]
[event_in event="ep2_2"]

[vo vo="ep2/kaguya_0007.ogg"]
[kaguya_悪い笑顔]
#【黑发少女】
「我是……来确认约定被打破的」[p]
[kaguya_悪い笑顔_c]

#
面对那张无畏嗤笑的面容，我不由得感到脊背发寒。[p]

那是一抹仿佛在嘲笑我迄今为止所有推理的笑容。[p]

保持着那样的表情，不久后黑发少女将视线转向了柚叶君。[p]

[vo vo="ep2/kaguya_0008.ogg"]
[kaguya_悪い笑顔]
#【黑发少女】
「那么，后会有期吧――小仓柚叶」[p]
[kaguya_悪い笑顔_c]

#

;キャラ消去
[chara_hide name=kaguya]

;イベントＣＧ削除
[event_out]

;SE：足音フェイドアウト
[se_f se="footsteps_out.ogg"]

;SE：ベルの音(終了待ち)
[se_w se="bell00.ogg"]

说完这句话，她便走出了咖啡店。[p]

明明还没报上名字，却喊着柚叶君的名字。[p]

[vo vo="ep2/koku_0235.ogg"]
[kokutou_凛]
#【黑十美鹤】
「柚叶君」[p]
[kokutou_凛_c]

[vo vo="ep2/yuzu_0202.ogg"]
[yuzuha_驚き]
#【小仓柚叶】
「啊、是……」[p]
[yuzuha_驚き_c]

[vo vo="ep2/koku_0236.ogg"]
[kokutou_凛]
#【黑十美鹤】
「姑且问一下，你和她认识吗？」[p]
[kokutou_凛_c]

[vo vo="ep2/yuzu_0203.ogg"]
[yuzuha_驚き]
#【小仓柚叶】
「不、完全没见过面……」[p]
[yuzuha_驚き_c]

[vo vo="ep2/koku_0237.ogg"]
[kokutou_哀]
#【黑十美鹤】
「我就说嘛……唉」[p]
[kokutou_哀_c]

#
这次的谜团虽然终于解开了，但又有新的谜题。[p]

[vo vo="ep2/koku_0238.ogg"]
[kokutou_哀]
#【黑十美鹤】
「从上次的男扮女装店员事件开始，[r]　
　又卷入了多余的麻烦事……」[p]
[kokutou_哀_c]

#
不，这应该不是我自找的麻烦才对。[p]

[vo vo="ep2/koku_0239.ogg"]
[kokutou_哀]
#【黑十美鹤】
「哎呀呀，真是够了」[p]
[kokutou_哀_c]


;テキストウィンドウ削除
[end_text]

;全キャラ削除
[allc]

;スタッフロールへ移動
[jump  storage="ep2_staff.ks"]