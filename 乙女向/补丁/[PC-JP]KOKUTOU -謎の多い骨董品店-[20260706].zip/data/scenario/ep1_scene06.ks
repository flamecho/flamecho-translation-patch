﻿;--------------------------------------------------
*017000
[savetitle text="コーヒーのおかわりいかがです？"]
;-------------------------------------------------

;背景：カフェ照明
[bg10 bg="cafe04.jpg"]

;テキストウィンドウ表示
[start_text]

#
在咖啡店啜饮咖啡。[p]

刚才还在座位上的柚叶君和稻饼小姐已经先回去了。[p]

受到打击的稻饼小姐，由柚叶君送她回去了。[p]

;SE：足音フェイドイン
[se_f se="footsteps_in.ogg"]

;背景：カフェ店内1
[bg10 bg="cafe02.jpg"]

[kokutou_真顔_c]
[ric_f cg="kokutou"]
[iori_微笑]
[lec cg="iori"]

[vo vo="ep1/iori_0034.ogg"]
#【御手洗 庵】
「要续杯咖啡吗？」[p]
[iori_微笑_c]

[kokutou_真顔]
[vo vo="ep1/koku_0210.ogg"]
#【黒十 美鹤】
「啊不用了谢谢，这杯喝完我就告辞」[p]
[kokutou_真顔_c]

[iori_微笑]
[vo vo="ep1/iori_0035.ogg"]
#【御手洗 庵】
「这样啊……不过，您居然发现了呢，明明我有自信不会被察觉的」[p]
[iori_微笑_c]

[kokutou_真顔]
[vo vo="ep1/koku_0211.ogg"]
#【黒十 美鹤】
「嘛，只是碰巧啦」[p]

[kokutou_疑問]
[vo vo="ep1/koku_0212.ogg"]
#【黒十 美鹤】
「话说……可以问个问题吗？」[p]
[kokutou_疑問_c]

;BGM再生
[bgm ogg="renge.ogg"]

[kokutou_凛]
[vo vo="ep1/koku_0213.ogg"]
#【黒十 美鹤】
「为什么要对他们两人说谎呢？」[p]
[kokutou_凛_c]


[vo vo="ep1/iori_0036.ogg"]
#【御手洗 庵】
「…………」[p]

#
面对这个问题，庵小姐保持着微笑停止了动作。[p]

[kokutou_凛]
[vo vo="ep1/koku_0214.ogg"]
#【黒十 美鹤】
「这家咖啡店的店长[r]　
　似乎是把您当作女孩子来对待了呢」[p]

[vo vo="ep1/koku_0215.ogg"]
#【黒十 美鹤】
「若您内心是女性的话[r]　
　还有必要欺骗店长吗？」[p]

[vo vo="ep1/koku_0216.ogg"]
#【黒十 美鹤】
「像他这样性情温和的店长[r]　
　就算坦白相告说不定也会雇佣您呢」[p]
[kokutou_凛_c]

[vo vo="ep1/iori_0037.ogg"]
#【御手洗 庵】
「…………」[p]

#
庵小姐始终挂着微笑，保持着沉默。[p]

[kokutou_凛]
[vo vo="ep1/koku_0217.ogg"]
#【黒十 美鹤】
「……还有件事最让我在意」[p]
[kokutou_凛_c]

[iori_微笑]
[vo vo="ep1/iori_0038.ogg"]
#【御手洗 庵】
「……什么？」[p]
[iori_微笑_c]

[kokutou_凛]
[vo vo="ep1/koku_0218.ogg"]
#【黒十 美鹤】
「为什么知道我们偏好的咖啡口味？」[p]
[kokutou_凛_c]

[iori_無表情_c]
[vo vo="ep1/iori_0039.ogg"]
#【御手洗 庵】
「…………」[p]

#
听到这个问题，她脸上的微笑消失了。[p]

[kokutou_凛]
[vo vo="ep1/koku_0219.ogg"]
#【黒十 美鹤】
「是第一次我和柚叶君来这家店点咖啡的时候」[p]

[vo vo="ep1/koku_0220.ogg"]
#【黒十 美鹤】
「你原本该说的话却没有说出口哦」[p]

[vo vo="ep1/koku_0221.ogg"]
#【黒十 美鹤】
「请问要加砂糖和牛奶吗——这句」[p]

[vo vo="ep1/koku_0222.ogg"]
#【黒十 美鹤】
「这家咖啡店的桌上并未备有砂糖或牛奶」[p]

[vo vo="ep1/koku_0223.ogg"]
#【黒十 美鹤】
「所以在这里本该必然听到的提问[r]　
　却未曾响起」[p]

[vo vo="ep1/koku_0224.ogg"]
#【黒十 美鹤】
「可即便如此，你唯独为柚叶君的杯子取来了砂糖」[p]
[kokutou_凛_c]

[iori_無表情]
[vo vo="ep1/iori_0040.ogg"]
#【御手洗 庵】
「仅仅是觉得，她看起来不像会喝黑咖啡的样子」[p]
[iori_無表情_c]

[kokutou_凛]
[vo vo="ep1/koku_0225.ogg"]
#【黒十 美鹤】
「那为什么不顺便拿牛奶呢？」[p]

[vo vo="ep1/koku_0226.ogg"]
#【黒十 美鹤】
「只是巧合吗？」[p]
[kokutou_凛_c]

[iori_無表情]
[vo vo="ep1/iori_0041.ogg"]
#【御手洗 庵】
「那个……」[p]
[iori_無表情_c]

[kokutou_凛]
[vo vo="ep1/koku_0227.ogg"]
#【黒十 美鹤】
「隐瞒身份在这里打工也是巧合？」[p]

[vo vo="ep1/koku_0228.ogg"]
#【黒十 美鹤】
「那这家咖啡店位于柚叶君就读[r]　
　学院的必经之路上也是偶然吗？」[p]
[kokutou_凛_c]

[iori_悪い笑顔]
[vo vo="ep1/iori_0042.ogg"]
#【御手洗 庵】
「……呵呵，哈哈哈」[p]

[vo vo="ep1/iori_0043.ogg"]
#【御手洗 庵】
「真让人吃惊，是我输了，科克托先生」[p]
[iori_悪い笑顔_c]

#
他突然笑起来，露出异常清爽的表情。[p]

看来我的推测并没有错。[p]

[kokutou_哀]
[vo vo="ep1/koku_0229.ogg"]
#【黒十 美鹤】
「果然，你是柚叶君娘家的相关人士吧」[p]
[kokutou_哀_c]

[iori_悪い笑顔]
[vo vo="ep1/iori_0044.ogg"]
#【御手洗 庵】
「没错，虽然详情不便明说[r]　
　但可以保证绝非可疑人物」[p]

[iori_微笑]
[vo vo="ep1/iori_0045.ogg"]
#【御手洗 庵】
「大可放心，毕竟我是小仓家这边的人啊」[p]
[iori_微笑_c]

#
正因为是小仓家的人反而让人无法信任……。[p]

[kokutou_怒]
[vo vo="ep1/koku_0230.ogg"]
#【黒十 美鹤】
「真是的……请不要把太多麻烦事推给我啊」[p]
[kokutou_怒_c]

[iori_微笑]
[vo vo="ep1/iori_0046.ogg"]
#【御手洗 庵】
「所以说没问题的没问题的，目前来说，对吧」[p]

[vo vo="ep1/iori_0047.ogg"]
#【御手洗 庵】
「我这边也还不想让人知道真实身份已经暴露了[r]　
　不论是对于我的委托人，还是柚叶大人」[p]
[iori_微笑_c]

[kokutou_哀]
[vo vo="ep1/koku_0231.ogg"]
#【黒十 美鹤】
「哈啊，真是够呛呢」[p]
[kokutou_哀_c]

#
总之，这次的骚动应该算是真正告一段落了吧。[p]

但想到近期可能又要被卷进大麻烦里[r]　
心情就有点忧郁。[p]


;テキストウィンドウ削除
[end_text]

;全キャラ削除
[allc]

;BGM停止
[bgm_end3]

;背景
[bg30 bg="white.png"]

;--------------------------------------------------
*018000
[savetitle text="――黒糖どら焼きですっ！"]
;-------------------------------------------------

;背景
[bg20 bg="antique.jpg"]

[kokutou_哀_c]
[ric_f cg="kokutou"]
[yuzuha_怒_c] 
[lec cg="yuzuha"]


;テキストウィンドウ表示
[start_text]

;BGM再生
[bgm ogg="mid_re.ogg"]

[yuzuha_怒]
[vo vo="ep1/yuzu_0201.ogg"]
#【小仓 柚叶】
「黑十先生……黑十先生！」[p]
[yuzuha_怒_c]

#
突然被叫到名字而抬起头，发现柚叶君正站在眼前。[p]

[yuzuha_哀]
[vo vo="ep1/yuzu_0202.ogg"]
#【小仓 柚叶】
「干嘛摆出这么忧郁的表情啊？」[p]

[vo vo="ep1/yuzu_0203.ogg"]
#【小仓 柚叶】
「本来就很阴沉的脸色，变得更～加糟糕了呢」[p]
[yuzuha_哀_c]

#
看样子是刚下课就直接来这里了。[p]

[kokutou_真顔]
[vo vo="ep1/koku_0232.ogg"]
#【黒十 美鹤】
「真是多管闲事」[p]
[kokutou_真顔_c]

[yuzuha_哀]
[vo vo="ep1/yuzu_0204.ogg"]
#【小仓 柚叶】
「嘿～是多管闲事吗～……」[p]

[yuzuha_微笑]
[vo vo="ep1/yuzu_0205.ogg"]
#【小仓 柚叶】
「明明特意买来当作这次报酬的说～」[p]
[yuzuha_微笑_c]

[kokutou_疑問]
[vo vo="ep1/koku_0233.ogg"]
#【黒十 美鹤】
「报酬？」[p]

[kokutou_驚き]
[vo vo="ep1/koku_0234.ogg"]
#【黒十 美鹤】
「……啊！？难道说！？」[p]
[kokutou_驚き_c]

[yuzuha_怒鳴る]
[vo vo="ep1/yuzu_0206.ogg"]
#【小仓 柚叶】
「没错！就是黑十先生最・最・最喜欢的！」[p]

[vo vo="ep1/yuzu_0207.ogg"]
#【小仓 柚叶】
「――黑糖铜锣烧哟！」[p]
[yuzuha_怒鳴る_c]

;カットイン表示
[cut_in cut="cut_dora2.png"]

#
柚叶君挺起胸膛从纸袋里取出黑糖铜锣烧。[p]


而且还是盒装的……估计是六枚装吧。[p]

;カットイン削除
[cut_out]

[kokutou_怒_c]
[vo vo="ep1/koku_0235.ogg"]
#【黒十 美鹤】
「……唔唔」[p]

[yuzuha_怒鳴る]
[vo vo="ep1/yuzu_0208.ogg"]
#【小仓 柚叶】
「所以？到底哪部分是多管闲事来着？」[p]
[yuzuha_怒鳴る_c]

#
面对这般刻薄的话语，我完全无言以对。[p]

[yuzuha_怒鳴る]
[vo vo="ep1/yuzu_0209.ogg"]
#【小仓 柚叶】
「嘛、开玩笑的开玩笑的」[p]
[yuzuha_微笑_c]

#
柚叶君倏然变换了表情。[p]

[yuzuha_微笑]
[vo vo="ep1/yuzu_0210.ogg"]
#【小仓 柚叶】
「这次真是帮大忙了，托您的福谜题全都完美破解啦！」[p]

[yuzuha_笑顔]
[vo vo="ep1/yuzu_0211.ogg"]
#【小仓 柚叶】
「您告诉了我完全不懂的事真是太有帮助了，真的很开心」[p]
[yuzuha_笑顔_c]

[kokutou_驚き]

#
说罢，柚叶君将黑糖铜锣烧递了过来。[p]

望着她满面春风的模样，我不禁恍惚了一瞬。[p]

[kokutou_真顔_c]

果然我对柚叶君这样的表情总是毫无抵抗力。[p]

[kokutou_真顔]
[vo vo="ep1/koku_0236.ogg"]
#【黒十 美鹤】
「……酬劳里铜锣烧或许有点多余呢」[p]
[kokutou_真顔_c]

[yuzuha_笑顔]
[vo vo="ep1/yuzu_0212.ogg"]
#【小仓 柚叶】
「咦？您说什么了吗？」[p]
[yuzuha_笑顔_c]

[kokutou_微笑]
[vo vo="ep1/koku_0237.ogg"]
#【黒十 美鹤】
「没事没事，什么都没有」[p]

[vo vo="ep1/koku_0238.ogg"]
#【黒十 美鹤】
「话说回来，后来怎么样了？稻饼小姐那边」[p]
[kokutou_微笑_c]

[yuzuha_哀]
[vo vo="ep1/yuzu_0213.ogg"]
#【小仓 柚叶】
「啊，她果然受到了相当大的打击」[p]
[yuzuha_哀_c]

[kokutou_哀]
[vo vo="ep1/yuzu_0214.ogg"]
#【小仓 柚叶】
「但那种情况也确实无可奈何吧[r]　
　毕竟连恋爱对象都算不上」[p]
[kokutou_哀_c]

[yuzuha_微笑]
[vo vo="ep1/yuzu_0215.ogg"]
#【小仓 柚叶】
「不过她还是正常来上学了[r]　
　也能正常交谈，我想应该没问题」[p]
[yuzuha_微笑_c]

[kokutou_真顔]
[vo vo="ep1/koku_0239.ogg"]
#【黒十 美鹤】
「那就好……」[p]
[kokutou_真顔_c]

#
关于那位庵小姐——更正，庵君是小仓家派来的人这件事[r]　
眼下还是暂时保密吧。[p]

[yuzuha_微笑]
[vo vo="ep1/yuzu_0216.ogg"]
#【小仓 柚叶】
「不过能成为那家咖啡店的常客真是太好啦」[p]

[yuzuha_笑顔]
[vo vo="ep1/yuzu_0217.ogg"]
#【小仓 柚叶】
「因为他们家的咖啡实在太美味了！」[p]
[yuzuha_笑顔_c]

[kokutou_真顔]
[vo vo="ep1/koku_0240.ogg"]
#【黒十 美鹤】
「的确，这话说得没错[r]　
　我也打算近期再去一次」[p]
[kokutou_真顔_c]

[yuzuha_驚き]
[vo vo="ep1/yuzu_0218.ogg"]
#【小仓 柚叶】
「……啊！」[p]

[kokutou_驚き]
[vo vo="ep1/koku_0241.ogg"]
#【黒十 美鹤】
「怎么了？」[p]

[vo vo="ep1/yuzu_0219.ogg"]
#【小仓 柚叶】
「……黑、黑十先生！请小心庵小姐哦！」[p]
[yuzuha_驚き_c]

[kokutou_疑問]
[vo vo="ep1/koku_0242.ogg"]
#【黒十 美鹤】
「这是什么意思？」[p]
[kokutou_疑問_c]

[yuzuha_微笑]
[vo vo="ep1/yuzu_0220.ogg"]
#【小仓 柚叶】
「那个……你看，别被盯上了！」[p]
[yuzuha_微笑_c]

[kokutou_疑問]
[vo vo="ep1/koku_0243.ogg"]
#【黒十 美鹤】
「……哈？」[p]
[kokutou_疑問_c]

[yuzuha_驚き]
[vo vo="ep1/yuzu_0221.ogg"]
#【小仓 柚叶】
「不如说倒不如……黑十先生，您那边才更需要注意的样子！？」[p]
[yuzuha_驚き_c]

[kokutou_哀]
[vo vo="ep1/koku_0244.ogg"]
#【黒十 美鹤】
「哎，你在说什么傻话呢」[p]

;キャラ消去
[chara_hide name=kokutou time="300"]

;SE：足音フェイドアウト
[se_f se="footsteps_out.ogg"]

[yuzuha_怒]
[vo vo="ep1/yuzu_0222.ogg"]
#【小仓 柚叶】
「啊！黑十先生您要去哪儿啊！？」[p]

[vo vo="ep1/yuzu_0223.ogg"]
#【小仓 柚叶】
「话还没说完呢ーー！！！黑十先生ーー！！」[p]
[yuzuha_怒_c]
#

;テキストウィンドウ削除
[end_text]

;SE：足音フェイドアウト
[se_f se="footsteps_out.ogg"]

;全キャラ削除
[allc]

;スタッフロールへ移動
[jump  storage="ep1_staff.ks"]

[s]