﻿;--------------------------------------------------
*013000
[savetitle text="ほんとに消えちゃいました"]
;-------------------------------------------------

;背景:カフェ店内2
[bg10 bg="cafe03.jpg"]

;BGM再生
[bgm ogg="music.ogg"]

[kokutou_真顔_c]
[ric_f cg="kokutou"]
[yuzuha_怒_c] 
[lec cg="yuzuha"]

;テキストウィンドウ表示
[start_text]


# 
坐在一家没有顾客的咖啡店的桌前。[p]

[yuzuha_怒鳴る] 
[vo vo="ep1/yuzu_0073.ogg"]
#【小仓 柚叶】
「那个黑十先生，该怎么办啊……！」[p]
[yuzuha_怒鳴る_c]

#
柚叶君用带着热度的细微声音说道。[p]

[kokutou_真顔]
[vo vo="ep1/koku_0076.ogg"]
#【黒十 美鹤】
「要怎么做……你说什么呀」[p]
[kokutou_真顔_c]

[yuzuha_疑問]
[vo vo="ep1/yuzu_0074.ogg"]
#【小仓 柚叶】
「说什么呢，他真的消失了哦，那个男孩！」[p]

[vo vo="ep1/yuzu_0075.ogg"]
#【小仓 柚叶】
「黑十先生也看到了对吧！　有个男孩子进了这家咖啡店！」[p]
[yuzuha_疑問_c]

[kokutou_真顔]
[vo vo="ep1/koku_0077.ogg"]
#【黒十 美鹤】
「……嗯，确实看到了」[p]
[kokutou_真顔_c]

[yuzuha_怒鳴る]
[vo vo="ep1/yuzu_0076.ogg"]
#【小仓 柚叶】
「就是啊！不过……怎么样，请看吧」[p]
[yuzuha_怒鳴る_c]

#
柚叶君故意夸张地张开双臂展示着。[p]

[yuzuha_怒鳴る]
[vo vo="ep1/yuzu_0077.ogg"]
#【小仓 柚叶】
「这不正如所见吗」[p]

[vo vo="ep1/yuzu_0078.ogg"]
#【小仓 柚叶】
「到底，男孩子都跑到哪里去了呢！？」[p]
[yuzuha_怒鳴る_c]

[kokutou_疑問]
#
猛地将脸凑近过来。[p]

用手掌推开了那张脸。[p]

[yuzuha_怒]
[vo vo="ep1/yuzu_0079.ogg"]
#【小仓 柚叶】
「唔嗯……！唔唔……所以说请不要按住少女的脸啊！」[p]
[yuzuha_怒_c]

[kokutou_疑問]
[vo vo="ep1/koku_0078.ogg"]
#【黒十 美鹤】
「闷热死了，我知道男孩子消失的地方是这边」[p]
[kokutou_疑問_c]

[yuzuha_疑問]
[vo vo="ep1/yuzu_0080.ogg"]
#【小仓 柚叶】
「那男孩子到底消失到哪里去了呢？」[p]
[yuzuha_疑問_c]

[kokutou_真顔]
[vo vo="ep1/koku_0079.ogg"]
#【黒十 美鹤】
「那个……或者说是不是真的消失了都还不知道不是吗」[p]
[kokutou_真顔_c]

[yuzuha_疑問]
[vo vo="ep1/yuzu_0081.ogg"]
#【小仓 柚叶】
「但实际上这家店里并没有人啊？」[p]

[vo vo="ep1/yuzu_0082.ogg"]
#【小仓 柚叶】
「也没有能躲藏的地方」[p]
[yuzuha_疑問_c]

#
确实，店内找不到任何可以藏身的空间。[p]

[yuzuha_怒鳴る]
[vo vo="ep1/yuzu_0083.ogg"]
#【小仓 柚叶】
「刚才让我看了下厨房[r]　
　只有店长和那位店员在！」[p]
[yuzuha_怒鳴る_c]

#
正如柚叶君所说[r]　
让我看了厨房但确实没人藏着。[p]

[yuzuha_疑問]
[vo vo="ep1/yuzu_0084.ogg"]
#【小仓 柚叶】
「还有其他可疑的地方吗？」[p]
[yuzuha_疑問_c]

[kokutou_疑問]
[vo vo="ep1/koku_0080.ogg"]
#【黒十 美鹤】
「……唔嗯」[p]
[kokutou_疑問_c]

#

;選択肢
[glink x="266" y="186" graphic="txtlink.png" width="712" size="28" text="喫茶店の周りが怪しい。" storage="ep1_scene04.ks" target="*ayasii"]
[glink x="266" y="299" graphic="txtlink.png" width="712" size="28" text="今のところ怪しいところは見当たらない。" storage="ep1_scene04.ks" target="*miataranai"]

[s]
;--------------------------------------------------
*ayasii
[savetitle text="喫茶店の周りが怪しい"]
;-------------------------------------------------

[eval exp="f.怪しい = 1"]


#
如果不在咖啡馆里的话……。[p]

[kokutou_凛]
[vo vo="ep1/koku_0081.ogg"]
#【黒十 美鹤】
「咖啡馆周围很可疑呢」[p]

[vo vo="ep1/koku_0082.ogg"]
#【黒十 美鹤】
「可能是趁我们进去时藏在门影里溜出去了」[p]
[kokutou_凛_c]

[yuzuha_驚き]
[vo vo="ep1/yuzu_0085.ogg"]
#【小仓 柚叶】
「啊，确实……虽然巡视了店内，但后面可能没查看？」[p]
[yuzuha_驚き_c]

[kokutou_凛]
[vo vo="ep1/koku_0083.ogg"]
#【黒十 美鹤】
「我去确认下店铺周围[r]　
　柚叶君请留在店内」[p]
[kokutou_凛_c]

[yuzuha_驚き]
[vo vo="ep1/yuzu_0086.ogg"]
#【小仓 柚叶】
「好的！明白！」[p]
[yuzuha_驚き_c]

;テキストウィンドウ削除
[end_text]

;全キャラ削除
[allc]

;背景：カフェ外観
[bg10 bg="cafe01.jpg"]

;テキストウィンドウ表示
[start_text]

;SE：足音フェイドイン
[se_f se="footstep_room_in.ogg"]
#
将柚叶君留在店里走向外面。[p]

环顾四周并无行人。[p]

迅速绕店铺查看了一圈[r]　
除了入口外似乎没有能进店的地方。[p]

虽然后门确实存在[r]　
但现已被封堵无法通行。[p]

[kokutou_真顔_c]
[ce cg="kokutou"]

[kokutou_真顔]
[vo vo="ep1/koku_0084.ogg"]
#【黒十 美鹤】
「唔嗯……果然不在吗」[p]

[vo vo="ep1/koku_0085.ogg"]
#【黒十 美鹤】
「就算真的出来了[r]　
　也不会待在显眼的地方吧」[p]
[kokutou_真顔_c]

[kokutou_疑問]
[vo vo="ep1/koku_0086.ogg"]
#【黒十 美鹤】
「那个少年是否察觉到了[r]　
　我和柚叶君在埋伏？」[p]
[kokutou_疑問_c]

#
少年走进咖啡厅时，似乎朝我们这边看了一眼。[p]

[kokutou_疑問]
[vo vo="ep1/koku_0087.ogg"]
#【黒十 美鹤】
「不，那个少年和我们应该是初次见面……」[p]

[vo vo="ep1/koku_0088.ogg"]
#【黑十美鹤】
「他不可能察觉到我们在跟踪吧」[p]
[kokutou_疑問_c]

#
在原地思索片刻[r]　
却未能发现少年的踪迹。[p]

;テキストウィンドウ削除
[end_text]

;全キャラ削除
[allc]

;背景：カフェ店内2
[bg10 bg="cafe03.jpg"]

[kokutou_真顔_c]
[ce cg="kokutou"]

;テキストウィンドウ表示
[start_text]

;SE：ベルの音
[se_f se="bell00.ogg"]

最终一无所获地回到咖啡厅。[p]

[kill]
[kokutou_真顔_c]
[ric_f cg="kokutou"]
[yuzuha_微笑_c] 
[lec cg="yuzuha"]

;SE：足音フェイドイン
[se_f se="footsteps_in.ogg"]

[yuzuha_微笑] 
[vo vo="ep1/yuzu_0087.ogg"]
#【小仓 柚叶】
「啊，黑十先生！怎么样！？」[p]
[yuzuha_微笑_c] 

[kokutou_真顔]
[vo vo="ep1/koku_0089.ogg"]
#【黒十 美鹤】
「不…不行……没找到」[p]
[kokutou_真顔_c]

[yuzuha_哀]
[vo vo="ep1/yuzu_0088.ogg"]
#【小仓 柚叶】
「这样啊……」[p]
[yuzuha_哀_c]

#
她失落地垂下肩膀，遗憾之情溢于言表。[p]

[yuzuha_微笑_c]
但突然像想起什么似的绽开笑容。[p]

[yuzuha_微笑]
[vo vo="ep1/yuzu_0089.ogg"]
#【小仓 柚叶】
「啊，刚才服务员来过[r]　
　所以我先点了咖啡」[p]
[yuzuha_微笑_c]

#
真是个表情瞬息万变的女孩子。[p]

[kokutou_微笑]
[vo vo="ep1/koku_0090.ogg"]
#【黒十 美鹤】
「啊，谢谢」[p]
[kokutou_微笑_c]

[yuzuha_哀]
[vo vo="ep1/yuzu_0090.ogg"]
#【小仓 柚叶】
「不过，那个男孩也不在店外呢……」[p]
[yuzuha_哀_c]

[kokutou_真顔]
[vo vo="ep1/koku_0091.ogg"]
#【黒十 美鹤】
「是的，很遗憾，没发现任何痕迹」[p]
[kokutou_真顔_c]

[jump  storage="ep1_scene04.ks"  target="*gouryuu"]

;--------------------------------------------------
*miataranai
[savetitle text="怪しいところは見当たらない"]
;-------------------------------------------------

[kokutou_疑問]
[vo vo="ep1/koku_0092.ogg"]
#【黒十 美鹤】
「……目前看来没什么可疑之处」[p]
[kokutou_疑問_c]

[yuzuha_疑問]
[vo vo="ep1/yuzu_0091.ogg"]
#【小仓 柚叶】
「呜呜，果然是这样啊…………」[p]
[yuzuha_疑問_c]

;SE：足音フェイドイン
[se_f se="footsteps_in.ogg"]

[kill]
[kokutou_疑問_c]
[ri_f cg="kokutou"]
[yuzuha_疑問_c]
[ce_f cg="yuzuha"]
[iori_微笑_c]
[le cg="iori"]

[iori_微笑]
[vo vo="ep1/iori_0007.ogg"]
#【店员】
「那个，可以点单了吗？」[p]
[iori_微笑_c]

#
这时服务员走了过来。[p]

[kokutou_真顔]
[vo vo="ep1/koku_0093.ogg"]
#【黒十 美鹤】
「啊，请给我咖啡」[p]
[kokutou_真顔_c]

[yuzuha_疑問]
[vo vo="ep1/yuzu_0092.ogg"]
#【小仓 柚叶】
「啊，我也要同样的」[p]
[yuzuha_疑問_c]

[iori_微笑]
[vo vo="ep1/iori_0008.ogg"]
#【店员】
「明白了，两杯咖啡对吧[r]　
　马上冲泡请稍等片刻」[p]
[iori_微笑_c]

;SE：足音フェイドアウト
[se_f se="footsteps_out.ogg"]

;庵削除
[chara_hide name=iori]

#
注视着接完单的店员走回吧台的背影。[p]

[kill]
[kokutou_凛_c]
[ric_f cg="kokutou"]
[yuzuha_疑問_c] 
[lec cg="yuzuha"]

[vo vo="ep1/koku_0094.ogg"]
#【黒十 美鹤】
「…………」[p]

[yuzuha_疑問] 
[vo vo="ep1/yuzu_0093.ogg"]
#【小仓 柚叶】
「但是黑十先生，那个男孩子到底去哪儿了呢？」[p]
[yuzuha_疑問_c] 

[kokutou_疑問]
[vo vo="ep1/koku_0095.ogg"]
#【黒十 美鹤】
「…………」[p]
[kokutou_疑問_c]

[yuzuha_疑問] 
[vo vo="ep1/yuzu_0094.ogg"]
#【小仓 柚叶】
「黑十先生真是的！」[p]
[yuzuha_疑問_c] 

[kokutou_驚き]
[vo vo="ep1/koku_0096.ogg"]
#【黒十 美鹤】
「在听？」[p]
[kokutou_驚き_c]

[yuzuha_疑問]
[vo vo="ep1/yuzu_0095.ogg"]
#【小仓 柚叶】
「在听？　才不是呢，请认真一点」[p]
[yuzuha_疑問_c] 

[kokutou_真顔]
[vo vo="ep1/koku_0097.ogg"]
#【黒十 美鹤】
「抱歉……」[p]
[kokutou_真顔_c]

[yuzuha_疑問]
[vo vo="ep1/yuzu_0096.ogg"]
#【小仓 柚叶】
「真是的，请您打起精神来[r]　
　那个男孩子到底去哪儿了？」[p]
[yuzuha_疑問_c]

[kokutou_真顔]
[vo vo="ep1/koku_0098.ogg"]
#【黒十 美鹤】
「这就不清楚了，也没发现可疑的地方」[p]
[kokutou_真顔_c]

#
再次环顾四周，并没有什么异常。[p]

从那个男孩进入咖啡馆到我和柚叶君来到这里的这段时间。[p]

完全猜不到他是如何离开咖啡馆的。[p]

[yuzuha_疑問]
[vo vo="ep1/yuzu_0097.ogg"]
#【小仓 柚叶】
「唔~怎么想都想不明白啦[r]　
　黑十先生有什么发现吗？」[p]
[yuzuha_疑問_c]

[kokutou_疑問]
[vo vo="ep1/koku_0099.ogg"]
#【黒十 美鹤】
「很遗憾我也不清楚」[p]

[vo vo="ep1/koku_0100.ogg"]
#【黒十 美鹤】
「那个少年究竟是怎么离开这家咖啡馆的……[r]　
　而且，还没被我们察觉」[p]
[kokutou_疑問_c]

[yuzuha_疑問]
[vo vo="ep1/yuzu_0098.ogg"]
#【小仓 柚叶】
「是啊……但是，但是啊黑十先生」[p]
[yuzuha_疑問_c]

#
柚叶君神色凝重地凑近脸庞。[p]

;--------------------------------------------------
*gouryuu
[savetitle text="御手洗庵です"]
;-------------------------------------------------

[yuzuha_疑問]
[vo vo="ep1/yuzu_0099.ogg"]
#【小仓 柚叶】
「也就是说……」[p]
[yuzuha_疑問_c]

;BGM停止
[bgm_end1]

[kill]
[kokutou_疑問_c]
[ri_f cg="kokutou"]
[yuzuha_疑問_c]
[ce_f cg="yuzuha"]
[iori_無表情_c]
[le cg="iori"]

[iori_無表情]
[vo vo="ep1/iori_0009.ogg"]
#【店员】
「男孩子消失了？」[p]
[iori_無表情_c]

[yuzuha_驚き]
[vo vo="ep1/yuzu_0100.ogg"]
#【小仓 柚叶】
「……咦？」[p]
[yuzuha_驚き_c]

#
打断柚叶君话语出现的，是刚才那位店员。[p]

她手中托盘上端着两个咖啡杯。[p]

;BGM再生
[bgm ogg="vacances.ogg"]

[iori_微笑]
[vo vo="ep1/iori_0010.ogg"]
#【店员】
「久等了～，这是两杯咖啡」[p]
[iori_微笑_c]

;SE:カップの音
[playse  buf="0" storage="clearing_the_table.ogg"]

[kokutou_真顔]
[vo vo="ep1/koku_0101.ogg"]
#【黒十 美鹤】
「为什么提起这事？」[p]
[kokutou_真顔_c]

[iori_微笑]
[vo vo="ep1/iori_0011.ogg"]
#【店员】
「你们认识稻饼小姐对吧？」[p]
[iori_微笑_c]

[yuzuha_疑問]
[vo vo="ep1/yuzu_0101.ogg"]
#【小仓 柚叶】
「您认识小百合小姐吗？」[p]
[yuzuha_疑問_c]

[iori_微笑]
[vo vo="ep1/iori_0012.ogg"]
#【店员】
「嗯，因为你们问了和稻饼小姐同样的问题[r]　
　所以就想是不是呢——」[p]

[vo vo="ep1/iori_0013.ogg"]
#【店员】
「啊、我在这里的咖啡店打工，我是御手洗庵」[p]
[iori_微笑_c]

#
看来稻饼小姐提到的女性店员就是这位御手洗庵。[p]

[yuzuha_微笑]
[vo vo="ep1/yuzu_0102.ogg"]
#【小仓 柚叶】
「原来如此，是这么回事啊」[p]

[vo vo="ep1/yuzu_0103.ogg"]
#【小仓 柚叶】
「那店员小姐――」[p]
[yuzuha_微笑_c]

[iori_微笑]
[vo vo="ep1/iori_0014.ogg"]
#【店员】
「啊、叫我庵就可以」[p]
[iori_微笑_c]

[yuzuha_微笑]
[vo vo="ep1/yuzu_0104.ogg"]
#【小仓 柚叶】
「哦你好你好[r]　
　那个、庵小姐知道消失男孩的谜团吗？」[p]
[yuzuha_微笑_c]

[iori_微笑]
[vo vo="ep1/iori_0015.ogg"]
#【御手洗 庵】
「怎么可能，稻饼小姐说之前我完全不知道」[p]

[vo vo="ep1/iori_0016.ogg"]
#【御手洗 庵】
「不如说，是你们两位来了之后[r]　
　我才开始想或许真有这回事」[p]
[iori_微笑_c]

#
确实，就算听说有人消失也不会有人相信吧。[p]

[iori_微笑]
[vo vo="ep1/iori_0017.ogg"]
#【御手洗 庵】
「嘛，有什么能帮上忙的尽管说」[p]
[iori_微笑_c]

;SE：足音フェイドアウト
[se_f se="footsteps_out.ogg"]
;庵削除
[chara_hide name=iori]

#
说完这话，似乎是店内唯一店员的[r]　
庵小姐便返回了吧台深处。[p]

[kill]
[kokutou_真顔_c]
[ric_f cg="kokutou"]
[yuzuha_疑問_c] 
[lec cg="yuzuha"]

[yuzuha_疑問]
[vo vo="ep1/yuzu_0105.ogg"]
#【小仓 柚叶】
「唔嗯……没想到真的会有这么不可思议的经历……」[p]
[yuzuha_疑問_c]

#
一边说着，柚叶君往杯子里放入三块方糖。[p]

;SE：スプーンで混ぜる
[se_f se="spoonmaze.ogg"]

[yuzuha_疑問]
[vo vo="ep1/yuzu_0106.ogg"]
#【小仓 柚叶】
「即便是黑十先生，这回恐怕也解不开这个谜题了吧」[p]
[yuzuha_疑問_c]

[kokutou_疑問]
[vo vo="ep1/koku_0102.ogg"]
#【黒十 美鹤】
「我本来就没打算解开……」[p]
[kokutou_疑問_c]

#
说着将端来的咖啡送入口中。[p]

[kokutou_驚き]
[yuzuha_微笑]
[vo vo="ep1/yuzu_0107.ogg"]
#【小仓 柚叶】
「嗯？怎么了？」[p]
[yuzuha_微笑_c]

[kokutou_疑問]
[vo vo="ep1/koku_0103.ogg"]
#【黒十 美鹤】
「不……只是有点……」[p]
[kokutou_疑問_c]

#
柚叶君歪着头也将杯子凑到嘴边。[p]

[yuzuha_驚き]
[vo vo="ep1/yuzu_0108.ogg"]
#【小仓 柚叶】
「哇，好好喝……！」[p]
[yuzuha_驚き_c]

[kokutou_微笑]
[vo vo="ep1/koku_0104.ogg"]
#【黒十 美鹤】
「是啊，这里的咖啡确实美味」[p]
[kokutou_微笑_c]

[yuzuha_哀]
[vo vo="ep1/yuzu_0109.ogg"]
#【小仓 柚叶】
「不过那个男孩子到底消失到哪儿去了呢……」[p]
[yuzuha_哀_c]

[yuzuha_哀]
[vo vo="ep1/yuzu_0110.ogg"]
#【小仓 柚叶】
「哎……明天该怎么向小百合小姐交代啊」[p]
[yuzuha_哀_c]

[kokutou_真顔]
[vo vo="ep1/koku_0105.ogg"]
#【黒十 美鹤】
「明天？」[p]
[kokutou_真顔_c]

[yuzuha_哀]
[vo vo="ep1/yuzu_0111.ogg"]
#【小仓 柚叶】
「是的，黑十先生说过[r]　
　等谜题解开后明天会全部说明的嘛」[p]
[yuzuha_哀_c]

[kokutou_哀]
[vo vo="ep1/koku_0106.ogg"]
#【黒十 美鹤】
「…………」[p]
[kokutou_哀_c]

;テキストウィンドウ削除
[end_text]

;全キャラ削除
[allc]

;BGM停止
[bgm_end3]

;背景
[bg10 bg="sky.jpg"]

;テキストウィンドウ表示
[start_text]

;SE：足音フェイドイン
[se_f se="footstep_room_out.ogg"]

#
最终那天未能解开谜题便踏上归途。[p]

要说成果[r]　
充其量就是发现了家咖啡好喝的店。[p]


[vo vo="ep1/yuzu_0112.ogg"]
#【小仓 柚叶】
「唉……真是的，该怎么办啊」[p]

;テキストウィンドウ削除
[end_text]

;背景
[bg10 bg="white.png"]

;--------------------------------------------------
*014000
[savetitle text="期待されても困ります"]
;-------------------------------------------------

;背景
[bg10 bg="antique.jpg"]

;BGM再生
[bgm ogg="mid_re.ogg"]


[kokutou_真顔_c]
[ri_f cg="kokutou"]
[yuzuha_微笑_c]
[ce_f cg="yuzuha"]
[sayuri_哀_c]
[le cg="sayuri"]


;テキストウィンドウ表示
[start_text]

[sayuri_哀]
[vo vo="ep1/sayu_0040.ogg"]
#【稻饼 小百合】
「……这样啊，还是没能弄明白呢」[p]
[sayuri_哀_c]

[yuzuha_哀]
[vo vo="ep1/yuzu_0113.ogg"]
#【小仓 柚叶】
「是的，实在惭愧……喏，黑十先生也」[p]
[yuzuha_哀_c]

#
柚叶君说着低下头，用死鱼眼直勾勾盯过来。[p]

[kokutou_哀]
[vo vo="ep1/koku_0107.ogg"]
#【黒十 美鹤】
「……为什么连我也要」[p]
[kokutou_哀_c]

[sayuri_驚き]
[vo vo="ep1/sayu_0041.ogg"]
#【稻饼 小百合】
「啊、不不不，不用那样客气啦！」[p]
[sayuri_驚き_c]

#
看到对方犹豫的模样，稻饼小姐慌忙上前制止他低头行礼。[p]

[sayuri_哀]
[vo vo="ep1/sayu_0042.ogg"]
#【稻饼 小百合】
「说到底这种事，本来就不该拜托别人」[p]
[sayuri_哀_c]

[yuzuha_哀]
[vo vo="ep1/yuzu_0114.ogg"]
#【小仓 柚叶】
「唔……不过如果是黑十先生的话[r]　
　肯定能解开这个谜题的吧～」[p]
[yuzuha_哀_c]

[kokutou_疑問]
[vo vo="ep1/koku_0108.ogg"]
#【黒十 美鹤】
「我只是个微不足道的古董店老板，被期待也很困扰啊」[p]
[kokutou_疑問_c]

[yuzuha_哀]
[vo vo="ep1/yuzu_0115.ogg"]
#【小仓 柚叶】
「但果然还是会在意不是吗～[r]　
　可是有个人凭空消失哦？」[p]

[vo vo="ep1/yuzu_0116.ogg"]
#【小仓 柚叶】
「而且还是在我们眼前」[p]

[yuzuha_怒鳴る]
[vo vo="ep1/yuzu_0117.ogg"]
#【小仓 柚叶】
「黑十先生，这种离奇的事真的可能吗？」[p]
[yuzuha_怒鳴る_c]

#
柚叶君微微鼓起脸颊凝视着这边。[p]

那稚气的表情让我忍不住叹气。[p]

简直像在控诉着"再稍微想想看嘛"，心思完全写在脸上。[p]

;選択肢
[glink x="266" y="186" graphic="txtlink.png" width="712"  size="28" text="もう少し考えてみる。" storage="ep1_scene04.ks" target="*seikiruto"]
[glink x="266" y="299" graphic="txtlink.png" width="712" size="28" text="考えるのをやめる。" storage="ep1_scene04.ks" target="*kanngaenai"]
[s]

;--------------------------------------------------
*kanngaenai
[savetitle text="考えるのをやめる"]
;-------------------------------------------------

[bgm_end2]

#
就算被这样盯着看，不明白的事终归不明白。[p]

[kokutou_疑問]
[vo vo="ep1/koku_0109.ogg"]
#【黒十 美鹤】
「露出这种表情我也很困扰，不明白的事就是不明白啊」[p]
[kokutou_疑問_c]

[yuzuha_怒]
[vo vo="ep1/yuzu_0118.ogg"]
#【小仓 柚叶】
「诶——！怎么这样——！再稍微想想看嘛！」[p]
[yuzuha_怒_c]

[kokutou_哀]
[vo vo="ep1/koku_0110.ogg"]
#【黒十 美鹤】
「……昨天想了那么久不也没弄明白吗」[p]
[kokutou_哀_c]

[yuzuha_怒]
[vo vo="ep1/yuzu_0119.ogg"]
#【小仓 柚叶】
「那个嘛……话是这么说」[p]
[yuzuha_怒_c]

[bgm ogg="music.ogg"]

[sayuri_微笑]
[vo vo="ep1/sayu_0043.ogg"]
#【稻饼 小百合】
「那个、已经没关系了，谢谢小柚叶」[p]

[vo vo="ep1/sayu_0044.ogg"]
#【稻饼 小百合】
「也谢谢黑十先生愿意一起思考」[p]
[sayuri_微笑_c]

[kokutou_真顔]
[vo vo="ep1/koku_0111.ogg"]
#【黒十 美鹤】
「不，没能帮上忙实在抱歉」[p]
[kokutou_真顔_c]

[yuzuha_怒]
[vo vo="ep1/yuzu_0120.ogg"]
#【小仓 柚叶】
「呜呜、我以为黑十先生[r]　
　肯定能解开这个谜题的……」[p]
[yuzuha_怒_c]

[kokutou_真顔]
[vo vo="ep1/koku_0112.ogg"]
#【黒十 美鹤】
「您这实在是高估我了」[p]
[kokutou_真顔_c]

[yuzuha_哀]
[vo vo="ep1/yuzu_0121.ogg"]
#【小仓 柚叶】
「……才没有呢，黑十先生是绝对能做到的人呀」[p]
[yuzuha_哀_c]

[kokutou_驚き]
#
柚叶君鼓着脸颊小声嘀咕道。[p]

她会如此高看我[r]　
恐怕还是因为过去那件事的缘故吧。[p]

[kokutou_真顔_c]

但这次恐怕要辜负柚叶君的期待了。[p]

[kokutou_真顔]
[vo vo="ep1/koku_0113.ogg"]
#【黒十 美鹤】
「话说回来，关于那个消失在咖啡店的男孩去向之谜[r]　
　虽然还没解开，不过您打算去搭讪那个男孩吗？」[p]
[kokutou_真顔_c]

#
突然有些在意便试着问道。[p]

[yuzuha_驚き]
[vo vo="ep1/yuzu_0122.ogg"]
#【小仓 柚叶】
「诶？啊！对哦！[r]　
　就算不解开那个谜题，也能直接去见那个男孩子呢！」[p]
[yuzuha_驚き_c]

#
如果不赶在进咖啡店前搭话[r]　
那个男孩可能会消失。[p]

[sayuri_照れ]
[vo vo="ep1/sayu_0045.ogg"]
#【稻饼 小百合】
「啊、搭讪的话那个……我会试试看的！[r]　
　毕竟行动最重要嘛！」[p]
[sayuri_照れ_c]

#
果然是个行动力强的女学生。[p]

[kokutou_真顔]
[vo vo="ep1/koku_0114.ogg"]
#【黒十 美鹤】
「那我就暗中祈祷您能有好结果吧」[p]
[kokutou_真顔_c]

[yuzuha_笑顔]
[vo vo="ep1/yuzu_0123.ogg"]
#【小仓 柚叶】
「加油啊！我会支持你的！」[p]
[yuzuha_笑顔_c]

[sayuri_笑顔]
[vo vo="ep1/sayu_0046.ogg"]
#【稻饼 小百合】
「谢谢您……那么，我先告辞了」[p]
[sayuri_笑顔_c]

;BGM停止
[bgm_end3]

;テキストウィンドウ削除
[end_text]

;全キャラ削除
[allc]

;背景
[bg30 bg="white.png"]

;--------------------------------------------------
*015000
[savetitle text="大変ですよ！　黒十さんっ！！！"]
;-------------------------------------------------

;テキストウィンドウ表示
[start_text]

#
数日之后。[p]

;背景
[bg10 bg="shop_kokutou.jpg"]

[bgm ogg="mid_re.ogg"]

[vo vo="ep1/yuzu_0124.ogg"]
#【小仓 柚叶】
「不好啦！黑十先生！！！」[p]

;背景
[bg10 bg="antique.jpg"]

[kokutou_驚き_c]
[ric_f cg="kokutou"]
[yuzuha_怒鳴る_c] 
[lec cg="yuzuha"]

[kokutou_驚き]
[vo vo="ep1/koku_0115.ogg"]
#【黒十 美鹤】
「怎么了，这么慌慌张张的」[p]
[kokutou_驚き_c]

#
柚叶君朝气蓬勃地冲进店里，开口第一句就大声说道。[p]

那副模样让我也不由得有些慌乱。[p]

[yuzuha_怒鳴る] 
[vo vo="ep1/yuzu_0125.ogg"]　　
#【小仓 柚叶】
「那那那、那个啊！[r]　
　发生不得了的大事了！」[p]
[yuzuha_怒鳴る_c] 

[kokutou_哀_c]

#
不得了的大事？[p]

究竟是什么样的不得了大事。[p]

[yuzuha_怒鳴る] 
[vo vo="ep1/yuzu_0126.ogg"]
#【小仓 柚叶】
「是关于小百合小姐的事……！」[p]
[yuzuha_怒鳴る_c] 

[kokutou_哀]
[vo vo="ep1/koku_0116.ogg"]
#【黒十 美鹤】
「小百合小姐？是稻饼小百合小姐对吧？[r]　
　她出什么事了吗？」[p]
[kokutou_哀_c]

#
我回忆着上次的事情，询问是否发生了什么。[p]

[yuzuha_怒鳴る] 
[vo vo="ep1/yuzu_0127.ogg"]
#【小仓 柚叶】
「其实小百合小姐，好像向那个男孩子发动攻势了！」[p]

[vo vo="ep1/yuzu_0128.ogg"]
#【小仓 柚叶】
「据说鼓起勇气搭话，传达了心意！」[p]
[yuzuha_怒鳴る_c]

[kokutou_疑問_c]

#
什么嘛，原来是那方面的事啊，我稍稍安下心来。[p]

还以为发生了什么更严重的事件。[p]

[yuzuha_怒鳴る] 
[vo vo="ep1/yuzu_0129.ogg"]
#【小仓 柚叶】
「然后……没想到……！」[p]

[vo vo="ep1/yuzu_0130.ogg"]
#【小仓 柚叶】
「………………没想到啊！！」[p]
[yuzuha_怒鳴る_c]

[kokutou_真顔]
[vo vo="ep1/koku_0117.ogg"]
#【黒十 美鹤】
「吊胃口太厉害了吧……[r]　
　是成功了？还是失败了？」[p]
[kokutou_真顔_c]

[yuzuha_怒鳴る]
[vo vo="ep1/yuzu_0131.ogg"]
#【小仓 柚叶】
「他是个基佬！！！」[p]
[yuzuha_怒鳴る_c]

[kokutou_哀]
[vo vo="ep1/koku_0118.ogg"]
#【黒十 美鹤】
「…………………………啥？」[p]
[kokutou_哀_c]

[yuzuha_怒鳴る]
[vo vo="ep1/yuzu_0132.ogg"]
#【小仓 柚叶】
「就是说啊，那个男孩子！根本就是同性恋那类的啦！！！！！」[p]

[yuzuha_哀]
[vo vo="ep1/yuzu_0133.ogg"]
#【小仓 柚叶】
「害得小百合小姐斗志全失……或者说失去了战斗对象？」[p]

[yuzuha_怒鳴る]
[vo vo="ep1/yuzu_0134.ogg"]
#【小仓 柚叶】
「根本不是啦，倒不如说从一开始就搞错战斗对象了啊！！」[p]

[kokutou_真顔]
[vo vo="ep1/koku_0119.ogg"]
#【黒十 美鹤】
「………………开玩笑的吧？」[p]
[kokutou_真顔_c]

[yuzuha_怒]
[vo vo="ep1/yuzu_0135.ogg"]
#【小仓 柚叶】
「千～真～万～确！」[p]
[yuzuha_怒_c]

[kokutou_真顔]
[vo vo="ep1/koku_0120.ogg"]
#【黒十 美鹤】
「……………」[p]
[kokutou_真顔_c]

#
所谓无言以对便是如此。[p]

但在惊愕之中唯独存有一个。[p]

咚地一声，一个简单到令人意外的谜题在心中解开了。[p]

[kokutou_驚き]
[vo vo="ep1/koku_0121.ogg"]
#【黒十 美鹤】
「啊…………！！！！」[p]

[yuzuha_驚き]

#
关于意中人进入咖啡店后消失之谜的答案已然明了。[p]

;テキストウィンドウ削除
[end_text]

;全キャラ削除
[allc]

;考えるのを止めました。
[eval exp="sf.ep1_end3 = 1"]
[bg  storage="ep1_end3.png" time="2000"]

;処理を停止します
[wa]
[wait time=1000]
[p]


;BGM停止
[bgm_end3]

;背景
[bg30 bg="black.png"]

;タイトル画面へ移動
[jump  storage="title_screen.ks"  target="*title"]

;--------------------------------------------------
*seikiruto
[savetitle text="もう少し考えてみる"]
;-------------------------------------------------

;BGM停止
[bgm_end2]

#
面对柚叶君那样的表情，我总会有些招架不住。[p]

[kokutou_哀]
[vo vo="ep1/koku_0122.ogg"]
#【黒十 美鹤】
「哈……那么，来整理下情报吧」[p]
[kokutou_哀_c]

[yuzuha_笑顔]
[vo vo="ep1/yuzu_0136.ogg"]
#【小仓 柚叶】
「太好啦！　这才像话嘛！」[p]
[yuzuha_笑顔_c]

[sayuri_微笑_c]

#
准确来说，或许是对这不断变换的笑颜毫无抵抗力。[p]

总之先试着整理情报。[p]

;BGM再生
[bgm ogg="tukikage.ogg"]

[kokutou_真顔]
[vo vo="ep1/koku_0123.ogg"]
#【黒十 美鹤】
「登场人物共计4人」[p]
[kokutou_真顔_c]

[yuzuha_疑問]
[vo vo="ep1/yuzu_0137.ogg"]
#【小仓 柚叶】
「咦？4人？」[p]
[yuzuha_疑問_c]

[kokutou_真顔]
[vo vo="ep1/koku_0124.ogg"]
#【黒十 美鹤】
「本次谜题的委托人稻饼小百合小姐」[p]

[vo vo="ep1/koku_0125.ogg"]
#【黒十 美鹤】
「作为意中人的少年……暂时称为少年X吧」[p]

[vo vo="ep1/koku_0126.ogg"]
#【黒十 美鹤】
「咖啡店服务生庵小姐，以及咖啡店店长」[p]
[kokutou_真顔_c]

[yuzuha_疑問]
[vo vo="ep1/yuzu_0138.ogg"]
#【小仓 柚叶】
「那个，黑十先生，我和您不计算在内吗？」[p]
[yuzuha_疑問_c]

[kokutou_真顔]
[vo vo="ep1/koku_0127.ogg"]
#【黒十 美鹤】
「这种情况下，作为解谜者的我们应该被排除在外」[p]
[kokutou_真顔_c]

[yuzuha_笑顔]
[vo vo="ep1/yuzu_0139.ogg"]
#【小仓 柚叶】
「啊～原来如此，这样确实更清晰呢」[p]
[yuzuha_笑顔_c]

[kokutou_真顔]
[vo vo="ep1/koku_0128.ogg"]
#【黒十 美鹤】
「嗯，谜题概要如下」[p]

[yuzuha_微笑_c]

[vo vo="ep1/koku_0129.ogg"]
#【黒十 美鹤】
「稻饼小姐在上学路上邂逅了意中人少年X」[p]

[vo vo="ep1/koku_0130.ogg"]
#【黒十 美鹤】
「并目击到少年X走进了咖啡店」[p]

[vo vo="ep1/koku_0131.ogg"]
#【黒十 美鹤】
「稻饼小姐平日就经常目睹那位少年X[r]　
　走进咖啡店的身影」[p]

[vo vo="ep1/koku_0132.ogg"]
#【黒十 美鹤】
「她随即跟随进入店内[r]　
　却发现少年X宛如雾气般从店内消失无踪」[p]

[vo vo="ep1/koku_0133.ogg"]
#【黒十 美鹤】
「当时店内没有其他客人[r]　
　仅有女性店员庵小姐和同为女性的店主两人」[p]

[vo vo="ep1/koku_0134.ogg"]
#【黒十 美鹤】
「咖啡店虽有后门但无法使用 出入口仅限正门」[p]

[vo vo="ep1/koku_0135.ogg"]
#【黒十 美鹤】
「之后她在店门口监视着入口[r]　
　却始终未见少年X出来」[p]
[kokutou_真顔_c]

#
将收集的情报逐条念出声来。[p]

柚叶君和稻饼小姐边听边点头。[p]

[kokutou_真顔]
[vo vo="ep1/koku_0136.ogg"]
#【黒十 美鹤】
「目前为止的情报可有什么差错？」[p]
[kokutou_真顔_c]

[sayuri_微笑]
[vo vo="ep1/sayu_0047.ogg"]
#【稻饼 小百合】
「是 确实无误……但是」[p]
[sayuri_微笑_c]

[yuzuha_微笑]
[vo vo="ep1/yuzu_0140.ogg"]
#【小仓 柚叶】
「就现有情报来看……」[p]

[yuzuha_哀_c]
[sayuri_哀_c]

#
两人相视叹息。[p]

;BGM停止
[bgm_end2]

[kokutou_疑問]
[vo vo="ep1/koku_0137.ogg"]
#【黒十 美鹤】
「即便整理情报 谜团反而愈发深邃呢」[p]
[kokutou_疑問_c]

[yuzuha_疑問]
[vo vo="ep1/yuzu_0141.ogg"]
#【小仓 柚叶】
「果然还是搞不明白啦……」[p]
[yuzuha_疑問_c]

[sayuri_哀]
[vo vo="ep1/sayu_0048.ogg"]
#【稻饼 小百合】
「确实呢……」[p]
[sayuri_哀_c]

[kokutou_真顔]
[vo vo="ep1/koku_0138.ogg"]
#【黒十 美鹤】
「或许该让事情沉淀片刻」[p]

[vo vo="ep1/koku_0139.ogg"]
#【黒十 美鹤】
「纠结无解之事终究徒劳无功」[p]
[kokutou_真顔_c]

;BGM再生
[bgm ogg="music.ogg"]

[yuzuha_微笑]
[vo vo="ep1/yuzu_0142.ogg"]
#【小仓 柚叶】
「言之有理 虽然在意[r]　
　还是等出现新线索再思考吧」[p]

[yuzuha_哀]
[vo vo="ep1/yuzu_0143.ogg"]
#【小仓 柚叶】
「小百合小姐　对不起！这次就先到这里好吗？」[p]
[yuzuha_哀_c]

[sayuri_微笑]
[vo vo="ep1/sayu_0049.ogg"]
#【稻饼 小百合】
「嗯 只好这样了」[p]

[vo vo="ep1/sayu_0050.ogg"]
#【稻饼 小百合】
「小柚叶，谢谢你为我做的一切」[p]

[yuzuha_微笑_c]

[vo vo="ep1/sayu_0051.ogg"]
#【稻饼 小百合】
「黑十先生也是，这次还特意劳您大驾[r]　
　真是非常感谢」[p]
[sayuri_微笑_c]

[yuzuha_微笑]
[vo vo="ep1/yuzu_0144.ogg"]
#【小仓 柚叶】
「哪里哪里不用客气，反正我平时也总是闲着没事干！」[p]
[yuzuha_微笑_c]

[kokutou_哀]
[vo vo="ep1/koku_0140.ogg"]
#【黒十 美鹤】
「为什么是柚叶君在回答？」[p]
[kokutou_哀_c]

[yuzuha_微笑]
[vo vo="ep1/yuzu_0145.ogg"]
#【小仓 柚叶】
「因为说的都是事实啊」[p]

[vo vo="ep1/yuzu_0146.ogg"]
#【小仓 柚叶】
「昨天回来之后他不是立刻[r]　
　就盯着那个破蛋看个没完嘛」[p]
[yuzuha_微笑_c]

#
柚叶君望着搁架旁的复活节彩蛋说道。[p]

[kokutou_真顔]
[vo vo="ep1/koku_0141.ogg"]
#【黒十 美鹤】
「之前就解释过了[r]　
　这不是什么破蛋，是复活节彩蛋」[p]
[kokutou_真顔_c]

[sayuri_微笑]
[vo vo="ep1/sayu_0052.ogg"]
#【稻饼 小百合】
「复活节彩蛋……[r]　
　这玩意儿里面也藏着什么惊喜吗？」[p]
[sayuri_微笑_c]

[kokutou_驚き_c]

[yuzuha_疑問]
[vo vo="ep1/yuzu_0147.ogg"]
#【小仓 柚叶】
「你刚才说惊喜？」[p]
[yuzuha_疑問_c]

[kokutou_微笑]
[vo vo="ep1/koku_0142.ogg"]
#【黒十 美鹤】
「噢，稻饼小姐似乎知道呢[r]　
　不愧是有教养的大小姐」[p]
[kokutou_微笑_c]

[yuzuha_怒]
[vo vo="ep1/yuzu_0148.ogg"]
#【小仓 柚叶】
「嗯？刚才是不是若有若无地嘲讽了我？」[p]
[yuzuha_怒_c]

[kokutou_微笑]
[vo vo="ep1/koku_0143.ogg"]
#【黒十 美鹤】
「怎么会怎么会」[p]
[kokutou_微笑_c]

[yuzuha_疑問]
[vo vo="ep1/yuzu_0149.ogg"]
#【小仓 柚叶】
「唔唔……话说回来，你指的惊喜是什么？」[p]
[yuzuha_疑問_c]

[sayuri_微笑]
[vo vo="ep1/sayu_0053.ogg"]
#【稻饼 小百合】
「有些复活节彩蛋会装入特别的物件[r]　
　或者制作特殊的机关」[p]
[sayuri_微笑_c]

[yuzuha_疑問]
[vo vo="ep1/yuzu_0150.ogg"]
#【小仓 柚叶】
「机关？」[p]
[yuzuha_疑問_c]

[kokutou_微笑]
[vo vo="ep1/koku_0144.ogg"]
#【黒十 美鹤】
「没错，当然，这个彩蛋里也有」[p]
[kokutou_微笑_c]

[yuzuha_笑顔]
[vo vo="ep1/yuzu_0151.ogg"]
#【小仓 柚叶】
「那这个脏兮兮的破蛋里面也藏着机关喽！」[p]
[yuzuha_笑顔_c]

[kokutou_哀]
[vo vo="ep1/koku_0145.ogg"]
#【黒十 美鹤】
「就算脏兮兮的……哈啊……[r]　
　柚叶君你完全不懂得浪漫呢」[p]

[vo vo="ep1/koku_0146.ogg"]
#【黒十 美鹤】
「听好了，如果被外表欺骗[r]　
　就会忽略隐藏在其中的东西……」[p]
[kokutou_哀_c]

;BGM停止
[bgm_end1]

[kokutou_真顔_c]

#
对自己说出口的话产生了违和感。[p]

[yuzuha_微笑]
[vo vo="ep1/yuzu_0152.ogg"]
#【小仓 柚叶】
「……嗯？黑十先生？怎么了？[r]　
　突然就僵住不动了」[p]
[yuzuha_微笑_c]

;BGM再生
[bgm ogg="urara.ogg"]

#
于是，这次所有谜题的答案都被推导出来了。[p]

那根本是只要明白就非常简单的谜题。[p]

不，说是谜题都太抬举这个愚蠢的误会了。[p]

[kokutou_凛]
[vo vo="ep1/koku_0147.ogg"]
#【黒十 美鹤】
「被外表欺骗……呢」[p]
[kokutou_凛_c]

[sayuri_微笑]
[vo vo="ep1/sayu_0054.ogg"]
#【稻饼 小百合】
「发生什么事了吗？」[p]
[sayuri_微笑_c]

[yuzuha_驚き]
[vo vo="ep1/yuzu_0153.ogg"]
#【小仓 柚叶】
「……黑十先生！难道您已经明白了吗！？」[p]
[yuzuha_驚き_c]

#
柚叶君似乎察觉到我这边的异常。[p]

[sayuri_微笑]
[vo vo="ep1/sayu_0055.ogg"]
#【稻饼 小百合】
「明白……究竟是指什么？」[p]
[sayuri_微笑_c]

[kokutou_凛]
[vo vo="ep1/koku_0148.ogg"]
#【黒十 美鹤】
「稻饼小姐……你喜欢的那个男孩子」[p]

[vo vo="ep1/koku_0149.ogg"]
#【黒十 美鹤】
「肯定是个爱说谎的人吧」[p]
[kokutou_凛_c]

;テキストウィンドウ削除
[end_text]

;全キャラ削除
[allc]

;シーン5へ移動
[jump  storage="ep1_scene05.ks"]

[s]
