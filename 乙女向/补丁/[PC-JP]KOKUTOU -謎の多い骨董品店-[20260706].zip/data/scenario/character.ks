
*character

;----------------------------------------------------------------------------------------------
; プリンセス（メッセージウィンドウ横）
;----------------------------------------------------------------------------------------------

[chara_new name="puri_w" storage="chara/kesi_w.png" jname="公主" color="0x0d0015"]

; ベース
[chara_layer name="puri_w" part="body" id="base" storage="chara/puri/body_w.png" ]
; 水着
[chara_layer name="puri_w" part="body" id="mizugi" storage="chara/puri/body_w_2.png" ]
; 浴衣
[chara_layer name="puri_w" part="body" id="yukata" storage="chara/puri/body_w_3.png" ]
; 制服
[chara_layer name="puri_w" part="body" id="unif" storage="chara/puri/body_w_4.png" ]

; 表情
[chara_layer name="puri_w" part="kao" id="0" storage="chara/puri/face_w_0.png" ]
[chara_layer name="puri_w" part="kao" id="1" storage="chara/puri/face_w_1.png" ]
[chara_layer name="puri_w" part="kao" id="2" storage="chara/puri/face_w_2.png" ]
[chara_layer name="puri_w" part="kao" id="3" storage="chara/puri/face_w_3.png" ]
[chara_layer name="puri_w" part="kao" id="4" storage="chara/puri/face_w_4.png" ]
[chara_layer name="puri_w" part="kao" id="5" storage="chara/puri/face_w_5.png" ]
[chara_layer name="puri_w" part="kao" id="6" storage="chara/puri/face_w_6.png" ]
[chara_layer name="puri_w" part="kao" id="7" storage="chara/puri/face_w_7.png" ]
[chara_layer name="puri_w" part="kao" id="8" storage="chara/puri/face_w_8.png" ]
[chara_layer name="puri_w" part="kao" id="11" storage="chara/puri/face_w_11.png" ]
[chara_layer name="puri_w" part="kao" id="12" storage="chara/puri/face_w_12.png" ]
[chara_layer name="puri_w" part="kao" id="13" storage="chara/puri/face_w_13.png" ]
[chara_layer name="puri_w" part="kao" id="14" storage="chara/puri/face_w_14.png" ]

; 照れ
[chara_layer name="puri_w" part="hh" id="off" storage="none" zindex=10 ]
[chara_layer name="puri_w" part="hh" id="on" storage="chara/puri/w_hh.png"]

; 青ざめ
[chara_layer name="puri_w" part="ss" id="off" storage="none" zindex=20 ]
[chara_layer name="puri_w" part="ss" id="on" storage="chara/puri/w_ss.png"]

; 汗
[chara_layer name="puri_w" part="as" id="off" storage="none" zindex=30 ]
[chara_layer name="puri_w" part="as" id="on" storage="chara/puri/w_as.png"]

; オプション【王冠 or 帽子】
[chara_layer name="puri_w" part="hat" id="off" storage="none" zindex=50 ]
[chara_layer name="puri_w" part="hat" id="okan" storage="chara/puri/w_okan.png"]
[chara_layer name="puri_w" part="hat" id="hat" storage="chara/puri/w_hat.png"]

;----------------------------------------------------------------------------------------------
; プリンセス（立ち絵）
;----------------------------------------------------------------------------------------------

[chara_new name="puri" storage="chara/kesi_s.png" jname="公主" color="0x0d0015"]

; ベース
[chara_layer name="puri" part="body" id="base" storage="chara/puri/body.png" zindex=9 ]
; ノースリーブ
[chara_layer name="puri" part="body" id="prain" storage="chara/puri/body_2.png" ]

; 表情
[chara_layer name="puri" part="kao" id="1" storage="chara/puri/face_1.png" zindex=15 ]
[chara_layer name="puri" part="kao" id="0" storage="chara/puri/face_0.png" ]
[chara_layer name="puri" part="kao" id="2" storage="chara/puri/face_2.png" ]
[chara_layer name="puri" part="kao" id="3" storage="chara/puri/face_3.png" ]
[chara_layer name="puri" part="kao" id="4" storage="chara/puri/face_4.png" ]
[chara_layer name="puri" part="kao" id="5" storage="chara/puri/face_5.png" ]
[chara_layer name="puri" part="kao" id="6" storage="chara/puri/face_6.png" ]
[chara_layer name="puri" part="kao" id="7" storage="chara/puri/face_7.png" ]
[chara_layer name="puri" part="kao" id="8" storage="chara/puri/face_8.png" ]
[chara_layer name="puri" part="kao" id="11" storage="chara/puri/face_11.png" ]
[chara_layer name="puri" part="kao" id="12" storage="chara/puri/face_12.png" ]
[chara_layer name="puri" part="kao" id="13" storage="chara/puri/face_13.png" ]
[chara_layer name="puri" part="kao" id="14" storage="chara/puri/face_14.png" ]

; 照れ
[chara_layer name="puri" part="hh" id="off" storage="none" zindex=10 ]
[chara_layer name="puri" part="hh" id="on" storage="chara/puri/hh.png"]

; 青ざめ
[chara_layer name="puri" part="ss" id="off" storage="none" zindex=20 ]
[chara_layer name="puri" part="ss" id="on" storage="chara/puri/ss.png"]

; 汗
[chara_layer name="puri" part="as" id="off" storage="none" zindex=30 ]
[chara_layer name="puri" part="as" id="on" storage="chara/puri/as.png"]

; 前髪上乗せ
[chara_layer name="puri" part="hr" id="off" storage="none" zindex=40 ]
[chara_layer name="puri" part="hr" id="on" storage="chara/puri/hr.png"]


;----------------------------------------------------------------------------------------------
; ヒメコ（転生後）
;----------------------------------------------------------------------------------------------

[chara_new name="hime" storage="chara/kesi_s.png" jname="見知らぬ少女" color="0x0d0015"]

; ベース
[chara_layer name="hime" part="body" id="base" storage="chara/hime/body.png" zindex=9 ]

; 表情
[chara_layer name="hime" part="kao" id="0" storage="chara/hime/face_0.png" zindex=15 ]
[chara_layer name="hime" part="kao" id="0" storage="chara/hime/face_0.png" ]
[chara_layer name="hime" part="kao" id="2" storage="chara/hime/face_2.png" ]
[chara_layer name="hime" part="kao" id="3" storage="chara/hime/face_3.png" ]
[chara_layer name="hime" part="kao" id="4" storage="chara/hime/face_4.png" ]
[chara_layer name="hime" part="kao" id="5" storage="chara/hime/face_5.png" ]
[chara_layer name="hime" part="kao" id="7" storage="chara/hime/face_7.png" ]
[chara_layer name="hime" part="kao" id="8" storage="chara/hime/face_8.png" ]
[chara_layer name="hime" part="kao" id="13" storage="chara/hime/face_13.png" ]

; 照れ
[chara_layer name="hime" part="hh" id="off" storage="none" zindex=10 ]
[chara_layer name="hime" part="hh" id="on" storage="chara/hime/hh.png"]

; 青ざめ
[chara_layer name="hime" part="ss" id="off" storage="none" zindex=20 ]
[chara_layer name="hime" part="ss" id="on" storage="chara/hime/ss.png"]

; 汗
[chara_layer name="hime" part="as" id="off" storage="none" zindex=30 ]
[chara_layer name="hime" part="as" id="on" storage="chara/hime/as.png"]

; 前髪上乗せ
[chara_layer name="hime" part="hr" id="off" storage="none" zindex=40 ]
[chara_layer name="hime" part="hr" id="on" storage="chara/hime/hr.png"]

;----------------------------------------------------------------------------------------------
; ヒメコ（子供時代）
;----------------------------------------------------------------------------------------------

[chara_new name="hime2" storage="chara/kesi_s.png" jname="&sf.player_name" color="0x0d0015"]

; ベース
[chara_layer name="hime2" part="body" id="base" storage="chara/hime2/body.png" zindex=9 ]

; 表情
[chara_layer name="hime2" part="kao" id="1" storage="chara/hime2/face_1.png" zindex=15 ]
[chara_layer name="hime2" part="kao" id="0" storage="chara/hime2/face_0.png" ]
[chara_layer name="hime2" part="kao" id="2" storage="chara/hime2/face_2.png" ]
[chara_layer name="hime2" part="kao" id="3" storage="chara/hime2/face_3.png" ]
[chara_layer name="hime2" part="kao" id="4" storage="chara/hime2/face_4.png" ]
[chara_layer name="hime2" part="kao" id="5" storage="chara/hime2/face_5.png" ]
[chara_layer name="hime2" part="kao" id="6" storage="chara/hime2/face_6.png" ]
[chara_layer name="hime2" part="kao" id="7" storage="chara/hime2/face_7.png" ]
[chara_layer name="hime2" part="kao" id="8" storage="chara/hime2/face_8.png" ]
[chara_layer name="hime2" part="kao" id="11" storage="chara/hime2/face_11.png" ]
[chara_layer name="hime2" part="kao" id="12" storage="chara/hime2/face_12.png" ]
[chara_layer name="hime2" part="kao" id="13" storage="chara/hime2/face_13.png" ]
[chara_layer name="hime2" part="kao" id="14" storage="chara/hime2/face_14.png" ]
; 照れ
[chara_layer name="hime2" part="hh" id="off" storage="none" zindex=10 ]
[chara_layer name="hime2" part="hh" id="on" storage="chara/hime2/hh.png"]

; 青ざめ
[chara_layer name="hime2" part="ss" id="off" storage="none" zindex=20 ]
[chara_layer name="hime2" part="ss" id="on" storage="chara/hime2/ss.png"]

; 汗
[chara_layer name="hime2" part="as" id="off" storage="none" zindex=30 ]
[chara_layer name="hime2" part="as" id="on" storage="chara/hime2/as.png"]

; 前髪上乗せ
[chara_layer name="hime2" part="hr" id="off" storage="none" zindex=40 ]
[chara_layer name="hime2" part="hr" id="on" storage="chara/hime2/hr.png"]

;----------------------------------------------------------------------------------------------
; ドロップ
;----------------------------------------------------------------------------------------------

[chara_new name="drop" storage="chara/kesi_s.png" jname="ドロップ" color="0x0d0015"]

; ベース
[chara_layer name="drop" part="body" id="base" storage="chara/drop/body.png" zindex=9 ]
; 浴衣
[chara_layer name="drop" part="body" id="yukata" storage="chara/drop/body_2.png" ]

; 表情
[chara_layer name="drop" part="kao" id="1" storage="chara/drop/face_1.png" zindex=15 ]
[chara_layer name="drop" part="kao" id="0" storage="chara/drop/face_0.png" ]
[chara_layer name="drop" part="kao" id="2" storage="chara/drop/face_2.png" ]
[chara_layer name="drop" part="kao" id="3" storage="chara/drop/face_3.png" ]
[chara_layer name="drop" part="kao" id="4" storage="chara/drop/face_4.png" ]
[chara_layer name="drop" part="kao" id="5" storage="chara/drop/face_5.png" ]
[chara_layer name="drop" part="kao" id="6" storage="chara/drop/face_6.png" ]
[chara_layer name="drop" part="kao" id="7" storage="chara/drop/face_7.png" ]
[chara_layer name="drop" part="kao" id="8" storage="chara/drop/face_8.png" ]
[chara_layer name="drop" part="kao" id="11" storage="chara/drop/face_11.png" ]
[chara_layer name="drop" part="kao" id="12" storage="chara/drop/face_12.png" ]
[chara_layer name="drop" part="kao" id="13" storage="chara/drop/face_13.png" ]
[chara_layer name="drop" part="kao" id="14" storage="chara/drop/face_14.png" ]

; 照れ
[chara_layer name="drop" part="hh" id="off" storage="none" zindex=10 ]
[chara_layer name="drop" part="hh" id="on" storage="chara/drop/hh.png"]

; 青ざめ
[chara_layer name="drop" part="ss" id="off" storage="none" zindex=20 ]
[chara_layer name="drop" part="ss" id="on" storage="chara/drop/ss.png"]

; 汗
[chara_layer name="drop" part="as" id="off" storage="none" zindex=30 ]
[chara_layer name="drop" part="as" id="on" storage="chara/drop/as.png"]

; 前髪上乗せ
[chara_layer name="drop" part="hr" id="off" storage="none" zindex=40 ]
[chara_layer name="drop" part="hr" id="on" storage="chara/drop/hr.png"]

; オブション【帽子】
[chara_layer name="drop" part="hat" id="off" storage="none" zindex=50 ]
;車掌帽子
[chara_layer name="drop" part="hat" id="on" storage="chara/drop/hat.png"]
;麦わら帽子
[chara_layer name="drop" part="hat" id="sea" storage="chara/drop/hat_2.png"]

;----------------------------------------------------------------------------------------------
; ソラ
;----------------------------------------------------------------------------------------------

[chara_new name="sora" storage="chara/kesi_s.png" jname="落合宙" color="0x0d0015"]

; ベース（車掌）
[chara_layer name="sora" part="body" id="base" storage="chara/sora/body.png" zindex=9 ]
; 私服
[chara_layer name="sora" part="body" id="prain" storage="chara/sora/body_2.png" ]

; 表情
[chara_layer name="sora" part="kao" id="1" storage="chara/sora/face_1.png" zindex=15 ]
[chara_layer name="sora" part="kao" id="0" storage="chara/sora/face_0.png" ]
[chara_layer name="sora" part="kao" id="2" storage="chara/sora/face_2.png" ]
[chara_layer name="sora" part="kao" id="3" storage="chara/sora/face_3.png" ]
[chara_layer name="sora" part="kao" id="4" storage="chara/sora/face_4.png" ]
[chara_layer name="sora" part="kao" id="5" storage="chara/sora/face_5.png" ]
[chara_layer name="sora" part="kao" id="6" storage="chara/sora/face_6.png" ]
[chara_layer name="sora" part="kao" id="7" storage="chara/sora/face_7.png" ]
[chara_layer name="sora" part="kao" id="8" storage="chara/sora/face_8.png" ]
[chara_layer name="sora" part="kao" id="11" storage="chara/sora/face_11.png" ]
[chara_layer name="sora" part="kao" id="12" storage="chara/sora/face_12.png" ]
[chara_layer name="sora" part="kao" id="13" storage="chara/sora/face_13.png" ]
[chara_layer name="sora" part="kao" id="14" storage="chara/sora/face_14.png" ]

; 照れ
[chara_layer name="sora" part="hh" id="off" storage="none" zindex=10 ]
[chara_layer name="sora" part="hh" id="on" storage="chara/sora/hh.png"]

; 青ざめ
[chara_layer name="sora" part="ss" id="off" storage="none" zindex=20 ]
[chara_layer name="sora" part="ss" id="on" storage="chara/sora/ss.png"]

; 汗
[chara_layer name="sora" part="as" id="off" storage="none" zindex=30 ]
[chara_layer name="sora" part="as" id="on" storage="chara/sora/as.png"]

; 前髪上乗せ
[chara_layer name="sora" part="hr" id="off" storage="none" zindex=40 ]
[chara_layer name="sora" part="hr" id="on" storage="chara/sora/hr.png"]


;----------------------------------------------------------------------------------------------
; ソラ（おっさん）
;----------------------------------------------------------------------------------------------

[chara_new name="sora2" storage="chara/kesi_s.png" jname="落合宙" color="0x0d0015"]

; ベース
[chara_layer name="sora2" part="body" id="base" storage="chara/sora2/body.png" zindex=9 ]
; 私服
[chara_layer name="sora2" part="body" id="prain" storage="chara/sora2/body_2.png" ]

; 表情
[chara_layer name="sora2" part="kao" id="0" storage="chara/sora2/face_0.png" zindex=15 ]
[chara_layer name="sora2" part="kao" id="0" storage="chara/sora2/face_0.png" ]
[chara_layer name="sora2" part="kao" id="2" storage="chara/sora2/face_2.png" ]
[chara_layer name="sora2" part="kao" id="3" storage="chara/sora2/face_3.png" ]
[chara_layer name="sora2" part="kao" id="4" storage="chara/sora2/face_4.png" ]
[chara_layer name="sora2" part="kao" id="5" storage="chara/sora2/face_5.png" ]
[chara_layer name="sora2" part="kao" id="6" storage="chara/sora2/face_6.png" ]
[chara_layer name="sora2" part="kao" id="7" storage="chara/sora2/face_7.png" ]
[chara_layer name="sora2" part="kao" id="8" storage="chara/sora2/face_8.png" ]
[chara_layer name="sora2" part="kao" id="12" storage="chara/sora2/face_12.png" ]

; 照れ
[chara_layer name="sora2" part="hh" id="off" storage="none" zindex=10 ]
[chara_layer name="sora2" part="hh" id="on" storage="chara/sora2/hh.png"]

; 青ざめ
[chara_layer name="sora2" part="ss" id="off" storage="none" zindex=20 ]
[chara_layer name="sora2" part="ss" id="on" storage="chara/sora2/ss.png"]

; 汗
[chara_layer name="sora2" part="as" id="off" storage="none" zindex=30 ]
[chara_layer name="sora2" part="as" id="on" storage="chara/sora2/as.png"]

;----------------------------------------------------------------------------------------------
; オチアイ（子供時代のソラ含む）
;----------------------------------------------------------------------------------------------

[chara_new name="otiai" storage="chara/kesi_s.png" jname="オチアイ" color="0x0d0015"]

; ベース
[chara_layer name="otiai" part="body" id="base" storage="chara/otiai/body.png" zindex=9 ]
; 浴衣
[chara_layer name="otiai" part="body" id="yukata" storage="chara/otiai/body_2.png" ]
; 中学校の制服
[chara_layer name="otiai" part="body" id="unif" storage="chara/otiai/body_3.png" ]

; 表情
[chara_layer name="otiai" part="kao" id="1" storage="chara/otiai/face_1.png" zindex=15 ]
[chara_layer name="otiai" part="kao" id="0" storage="chara/otiai/face_0.png" ]
[chara_layer name="otiai" part="kao" id="2" storage="chara/otiai/face_2.png" ]
[chara_layer name="otiai" part="kao" id="3" storage="chara/otiai/face_3.png" ]
[chara_layer name="otiai" part="kao" id="4" storage="chara/otiai/face_4.png" ]
[chara_layer name="otiai" part="kao" id="5" storage="chara/otiai/face_5.png" ]
[chara_layer name="otiai" part="kao" id="6" storage="chara/otiai/face_6.png" ]
[chara_layer name="otiai" part="kao" id="7" storage="chara/otiai/face_7.png" ]
[chara_layer name="otiai" part="kao" id="8" storage="chara/otiai/face_8.png" ]
[chara_layer name="otiai" part="kao" id="11" storage="chara/otiai/face_11.png" ]
[chara_layer name="otiai" part="kao" id="12" storage="chara/otiai/face_12.png" ]
[chara_layer name="otiai" part="kao" id="13" storage="chara/otiai/face_13.png" ]
[chara_layer name="otiai" part="kao" id="14" storage="chara/otiai/face_14.png" ]

; 照れ
[chara_layer name="otiai" part="hh" id="off" storage="none" zindex=10 ]
[chara_layer name="otiai" part="hh" id="on" storage="chara/otiai/hh.png"]

; 青ざめ
[chara_layer name="otiai" part="ss" id="off" storage="none" zindex=20 ]
[chara_layer name="otiai" part="ss" id="on" storage="chara/otiai/ss.png"]

; 汗
[chara_layer name="otiai" part="as" id="off" storage="none" zindex=30 ]
[chara_layer name="otiai" part="as" id="on" storage="chara/otiai/as.png"]

; 前髪上乗せ
[chara_layer name="otiai" part="hr" id="off" storage="none" zindex=40 ]
[chara_layer name="otiai" part="hr" id="on" storage="chara/otiai/hr.png"]

;----------------------------------------------------------------------------------------------
; クォードリリオン
;----------------------------------------------------------------------------------------------

[chara_new name="riri" storage="chara/kesi_m.png" jname="クォードリリオン" color="0x0d0015"]

; ベース
[chara_layer name="riri" part="body" id="base" storage="chara/riri/body.png" zindex=9 ]
; 水着
[chara_layer name="riri" part="body" id="mizugi" storage="chara/riri/body_2.png" ]
; 浴衣
[chara_layer name="riri" part="body" id="yukata" storage="chara/riri/body_3.png" ]

; 表情
[chara_layer name="riri" part="kao" id="1" storage="chara/riri/face_1.png" zindex=15 ]
[chara_layer name="riri" part="kao" id="0" storage="chara/riri/face_0.png" ]
[chara_layer name="riri" part="kao" id="2" storage="chara/riri/face_2.png" ]
[chara_layer name="riri" part="kao" id="3" storage="chara/riri/face_3.png" ]
[chara_layer name="riri" part="kao" id="4" storage="chara/riri/face_4.png" ]
[chara_layer name="riri" part="kao" id="5" storage="chara/riri/face_5.png" ]
[chara_layer name="riri" part="kao" id="6" storage="chara/riri/face_6.png" ]
[chara_layer name="riri" part="kao" id="7" storage="chara/riri/face_7.png" ]
[chara_layer name="riri" part="kao" id="8" storage="chara/riri/face_8.png" ]
[chara_layer name="riri" part="kao" id="11" storage="chara/riri/face_11.png" ]
[chara_layer name="riri" part="kao" id="12" storage="chara/riri/face_12.png" ]
[chara_layer name="riri" part="kao" id="13" storage="chara/riri/face_13.png" ]
[chara_layer name="riri" part="kao" id="14" storage="chara/riri/face_14.png" ]

; 照れ
[chara_layer name="riri" part="hh" id="off" storage="none" zindex=10 ]
[chara_layer name="riri" part="hh" id="on" storage="chara/riri/hh.png"]

; 青ざめ
[chara_layer name="riri" part="ss" id="off" storage="none" zindex=20 ]
[chara_layer name="riri" part="ss" id="on" storage="chara/riri/ss.png"]

; 汗
[chara_layer name="riri" part="as" id="off" storage="none" zindex=30 ]
[chara_layer name="riri" part="as" id="on" storage="chara/riri/as.png"]

; 前髪上乗せ
[chara_layer name="riri" part="hr" id="off" storage="none" zindex=40 ]
[chara_layer name="riri" part="hr" id="on" storage="chara/riri/hr.png"]

;----------------------------------------------------------------------------------------------
; リオ（中高生時代）
;----------------------------------------------------------------------------------------------

[chara_new name="rio" storage="chara/kesi_s.png" jname="神崎凛生" color="0x0d0015"]

; ベース
[chara_layer name="rio" part="body" id="base" storage="chara/rio/body.png" zindex=9 ]
; 制服
[chara_layer name="rio" part="body" id="unif" storage="chara/rio/body_2.png" ]

; 表情
[chara_layer name="rio" part="kao" id="1" storage="chara/rio/face_1.png" zindex=15 ]
[chara_layer name="rio" part="kao" id="0" storage="chara/rio/face_0.png" ]
[chara_layer name="rio" part="kao" id="2" storage="chara/rio/face_2.png" ]
[chara_layer name="rio" part="kao" id="3" storage="chara/rio/face_3.png" ]
[chara_layer name="rio" part="kao" id="4" storage="chara/rio/face_2.png" ]
[chara_layer name="rio" part="kao" id="5" storage="chara/rio/face_1.png" ]
[chara_layer name="rio" part="kao" id="6" storage="chara/rio/face_2.png" ]
[chara_layer name="rio" part="kao" id="7" storage="chara/rio/face_0.png" ]
[chara_layer name="rio" part="kao" id="8" storage="chara/rio/face_3.png" ]
[chara_layer name="rio" part="kao" id="11" storage="chara/rio/face_11.png" ]
[chara_layer name="rio" part="kao" id="12" storage="chara/rio/face_12.png" ]
[chara_layer name="rio" part="kao" id="13" storage="chara/rio/face_13.png" ]
[chara_layer name="rio" part="kao" id="14" storage="chara/rio/face_14.png" ]

; 照れ
[chara_layer name="rio" part="hh" id="off" storage="none" zindex=10 ]
[chara_layer name="rio" part="hh" id="on" storage="chara/rio/hh.png"]

; 青ざめ
[chara_layer name="rio" part="ss" id="off" storage="none" zindex=20 ]
[chara_layer name="rio" part="ss" id="on" storage="chara/rio/ss.png"]

; 汗
[chara_layer name="rio" part="as" id="off" storage="none" zindex=30 ]
[chara_layer name="rio" part="as" id="on" storage="chara/rio/as.png"]

; 前髪上乗せ
[chara_layer name="rio" part="hr" id="off" storage="none" zindex=40 ]
[chara_layer name="rio" part="hr" id="on" storage="chara/rio/hr.png"]

;----------------------------------------------------------------------------------------------
; リオ（子供時代）
;----------------------------------------------------------------------------------------------

[chara_new name="rio2" storage="chara/kesi_s.png" jname="神崎凛生" color="0x0d0015"]

; ベース
[chara_layer name="rio2" part="body" id="base" storage="chara/rio2/body.png" zindex=9 ]

; 表情
[chara_layer name="rio2" part="kao" id="1" storage="chara/rio2/face_1.png" zindex=15 ]
[chara_layer name="rio2" part="kao" id="0" storage="chara/rio2/face_0.png" ]
[chara_layer name="rio2" part="kao" id="2" storage="chara/rio2/face_2.png" ]
[chara_layer name="rio2" part="kao" id="3" storage="chara/rio2/face_3.png" ]
[chara_layer name="rio2" part="kao" id="4" storage="chara/rio2/face_2.png" ]
[chara_layer name="rio2" part="kao" id="5" storage="chara/rio2/face_1.png" ]
[chara_layer name="rio2" part="kao" id="6" storage="chara/rio2/face_6.png" ]
[chara_layer name="rio2" part="kao" id="7" storage="chara/rio2/face_7.png" ]
[chara_layer name="rio2" part="kao" id="8" storage="chara/rio2/face_8.png" ]
[chara_layer name="rio2" part="kao" id="11" storage="chara/rio2/face_11.png" ]
[chara_layer name="rio2" part="kao" id="12" storage="chara/rio2/face_12.png" ]
[chara_layer name="rio2" part="kao" id="13" storage="chara/rio2/face_13.png" ]
[chara_layer name="rio2" part="kao" id="14" storage="chara/rio2/face_14.png" ]

; 照れ
[chara_layer name="rio2" part="hh" id="off" storage="none" zindex=10 ]
[chara_layer name="rio2" part="hh" id="on" storage="chara/rio2/hh.png"]

; 青ざめ
[chara_layer name="rio2" part="ss" id="off" storage="none" zindex=20 ]
[chara_layer name="rio2" part="ss" id="on" storage="chara/rio2/ss.png"]

; 汗
[chara_layer name="rio2" part="as" id="off" storage="none" zindex=30 ]
[chara_layer name="rio2" part="as" id="on" storage="chara/rio2/as.png"]

; 前髪上乗せ
[chara_layer name="rio2" part="hr" id="off" storage="none" zindex=40 ]
[chara_layer name="rio2" part="hr" id="on" storage="chara/rio2/hr.png"]

;----------------------------------------------------------------------------------------------
; カイト
;----------------------------------------------------------------------------------------------

[chara_new name="kite" storage="chara/kesi_m.png" jname="カイト" color="0x0d0015"]

; ベース
[chara_layer name="kite" part="body" id="base" storage="chara/kite/body.png" zindex=9 ]
; 水着
[chara_layer name="kite" part="body" id="mizugi" storage="chara/kite/body_2.png" ]
; 浴衣
[chara_layer name="kite" part="body" id="yukata" storage="chara/kite/body_3.png" ]
; 丹下段平
[chara_layer name="kite" part="body" id="tange" storage="chara/kite/body_4.png" ]

; 表情
[chara_layer name="kite" part="kao" id="1" storage="chara/kite/face_1.png" zindex=15 ]
[chara_layer name="kite" part="kao" id="0" storage="chara/kite/face_0.png" ]
[chara_layer name="kite" part="kao" id="2" storage="chara/kite/face_2.png" ]
[chara_layer name="kite" part="kao" id="3" storage="chara/kite/face_3.png" ]
[chara_layer name="kite" part="kao" id="4" storage="chara/kite/face_4.png" ]
[chara_layer name="kite" part="kao" id="5" storage="chara/kite/face_5.png" ]
[chara_layer name="kite" part="kao" id="6" storage="chara/kite/face_6.png" ]
[chara_layer name="kite" part="kao" id="7" storage="chara/kite/face_7.png" ]
[chara_layer name="kite" part="kao" id="8" storage="chara/kite/face_8.png" ]
[chara_layer name="kite" part="kao" id="11" storage="chara/kite/face_11.png" ]
[chara_layer name="kite" part="kao" id="12" storage="chara/kite/face_12.png" ]
[chara_layer name="kite" part="kao" id="13" storage="chara/kite/face_13.png" ]
[chara_layer name="kite" part="kao" id="14" storage="chara/kite/face_14.png" ]
[chara_layer name="kite" part="kao" id="15" storage="chara/kesi_m.png" ]

; 照れ
[chara_layer name="kite" part="hh" id="off" storage="none" zindex=10 ]
[chara_layer name="kite" part="hh" id="on" storage="chara/kite/hh.png"]

; 青ざめ
[chara_layer name="kite" part="ss" id="off" storage="none" zindex=20 ]
[chara_layer name="kite" part="ss" id="on" storage="chara/kite/ss.png"]

; 汗
[chara_layer name="kite" part="as" id="off" storage="none" zindex=30 ]
[chara_layer name="kite" part="as" id="on" storage="chara/kite/as.png"]

; 前髪上乗せ
[chara_layer name="kite" part="hr" id="off" storage="none" zindex=40 ]
[chara_layer name="kite" part="hr" id="on" storage="chara/kite/hr.png"]

; オプション【涙】
[chara_layer name="kite" part="tear" id="off" storage="none" zindex=45 ]
[chara_layer name="kite" part="tear" id="on" storage="chara/kite/tear.png"]

;----------------------------------------------------------------------------------------------
; カズチカ（子供時代）
;----------------------------------------------------------------------------------------------

[chara_new name="kazu" storage="chara/kesi_s.png" jname="伊東一近" color="0x0d0015"]

; ベース
[chara_layer name="kazu" part="body" id="base" storage="chara/kazu/body.png" zindex=9 ]

; 表情
[chara_layer name="kazu" part="kao" id="1" storage="chara/kazu/face_1.png" zindex=15 ]
[chara_layer name="kazu" part="kao" id="0" storage="chara/kazu/face_0.png" ]
[chara_layer name="kazu" part="kao" id="2" storage="chara/kazu/face_2.png" ]
[chara_layer name="kazu" part="kao" id="3" storage="chara/kazu/face_3.png" ]
[chara_layer name="kazu" part="kao" id="4" storage="chara/kazu/face_2.png" ]
[chara_layer name="kazu" part="kao" id="5" storage="chara/kazu/face_1.png" ]
[chara_layer name="kazu" part="kao" id="6" storage="chara/kazu/face_6.png" ]
[chara_layer name="kazu" part="kao" id="7" storage="chara/kazu/face_7.png" ]
[chara_layer name="kazu" part="kao" id="8" storage="chara/kazu/face_6.png" ]
[chara_layer name="kazu" part="kao" id="11" storage="chara/kazu/face_11.png" ]
[chara_layer name="kazu" part="kao" id="12" storage="chara/kazu/face_12.png" ]
[chara_layer name="kazu" part="kao" id="13" storage="chara/kazu/face_13.png" ]
[chara_layer name="kazu" part="kao" id="14" storage="chara/kazu/face_14.png" ]

; 照れ
[chara_layer name="kazu" part="hh" id="off" storage="none" zindex=10 ]
[chara_layer name="kazu" part="hh" id="on" storage="chara/kazu/hh.png"]

; 青ざめ
[chara_layer name="kazu" part="ss" id="off" storage="none" zindex=20 ]
[chara_layer name="kazu" part="ss" id="on" storage="chara/kazu/ss.png"]

; 汗
[chara_layer name="kazu" part="as" id="off" storage="none" zindex=30 ]
[chara_layer name="kazu" part="as" id="on" storage="chara/kazu/as.png"]

; 前髪上乗せ
[chara_layer name="kazu" part="hr" id="off" storage="none" zindex=40 ]
[chara_layer name="kazu" part="hr" id="on" storage="chara/kazu/hr.png"]

; オプション【車椅子】
[chara_layer name="kite" part="chair" id="off" storage="none" zindex=5 ]
[chara_layer name="kite" part="chair" id="on" storage="chara/kite/chair.png"]

;----------------------------------------------------------------------------------------------
; ハートシェイプ
;----------------------------------------------------------------------------------------------

[chara_new name="hati" storage="chara/kesi_s.png" jname="ハートシェイプ" color="0x0d0015"]

; ベース
[chara_layer name="hati" part="body" id="base" storage="chara/hati/body.png" zindex=9 ]
; 水着
[chara_layer name="hati" part="body" id="mizugi" storage="chara/hati/body_2.png" ]
; 浴衣
[chara_layer name="hati" part="body" id="yukata" storage="chara/hati/body_3.png" ]

; 表情
[chara_layer name="hati" part="kao" id="1" storage="chara/hati/face_5.png" zindex=15 ]
[chara_layer name="hati" part="kao" id="0" storage="chara/hati/face_0.png" ]
[chara_layer name="hati" part="kao" id="1" storage="chara/hati/face_1.png" ]
[chara_layer name="hati" part="kao" id="2" storage="chara/hati/face_2.png" ]
[chara_layer name="hati" part="kao" id="3" storage="chara/hati/face_3.png" ]
[chara_layer name="hati" part="kao" id="4" storage="chara/hati/face_4.png" ]
[chara_layer name="hati" part="kao" id="5" storage="chara/hati/face_5.png" ]
[chara_layer name="hati" part="kao" id="6" storage="chara/hati/face_6.png" ]
[chara_layer name="hati" part="kao" id="7" storage="chara/hati/face_7.png" ]
[chara_layer name="hati" part="kao" id="8" storage="chara/hati/face_8.png" ]
[chara_layer name="hati" part="kao" id="11" storage="chara/hati/face_11.png" ]
[chara_layer name="hati" part="kao" id="12" storage="chara/hati/face_12.png" ]
[chara_layer name="hati" part="kao" id="13" storage="chara/hati/face_13.png" ]
[chara_layer name="hati" part="kao" id="14" storage="chara/hati/face_14.png" ]

; 照れ
[chara_layer name="hati" part="hh" id="off" storage="none" zindex=10 ]
[chara_layer name="hati" part="hh" id="on" storage="chara/hati/hh.png"]

; 青ざめ
[chara_layer name="hati" part="ss" id="off" storage="none" zindex=20 ]
[chara_layer name="hati" part="ss" id="on" storage="chara/hati/ss.png"]

; 汗
[chara_layer name="hati" part="as" id="off" storage="none" zindex=30 ]
[chara_layer name="hati" part="as" id="on" storage="chara/hati/as.png"]

; 前髪上乗せ
[chara_layer name="hati" part="hr" id="off" storage="none" zindex=40 ]
[chara_layer name="hati" part="hr" id="on" storage="chara/hati/hr.png"]

;----------------------------------------------------------------------------------------------
; ジェット
;----------------------------------------------------------------------------------------------

[chara_new name="jet" storage="chara/kesi_s.png" jname="ジェット" color="0x0d0015"]

; ベース
[chara_layer name="jet" part="body" id="base" storage="chara/jet/body.png" zindex=9 ]
; 水着
[chara_layer name="jet" part="body" id="mizugi" storage="chara/jet/body_2.png" ]
; 浴衣
[chara_layer name="jet" part="body" id="yukata" storage="chara/jet/body_3.png" ]
; 病院服
[chara_layer name="jet" part="body" id="unif" storage="chara/jet/body_4.png" ]
; 私服
[chara_layer name="jet" part="body" id="prain" storage="chara/jet/body_5.png" ]

; 表情
[chara_layer name="jet" part="kao" id="1" storage="chara/jet/face_1.png" zindex=15 ]
[chara_layer name="jet" part="kao" id="0" storage="chara/jet/face_0.png" ]
[chara_layer name="jet" part="kao" id="2" storage="chara/jet/face_2.png" ]
[chara_layer name="jet" part="kao" id="3" storage="chara/jet/face_3.png" ]
[chara_layer name="jet" part="kao" id="4" storage="chara/jet/face_4.png" ]
[chara_layer name="jet" part="kao" id="5" storage="chara/jet/face_5.png" ]
[chara_layer name="jet" part="kao" id="6" storage="chara/jet/face_6.png" ]
[chara_layer name="jet" part="kao" id="7" storage="chara/jet/face_7.png" ]
[chara_layer name="jet" part="kao" id="8" storage="chara/jet/face_8.png" ]
[chara_layer name="jet" part="kao" id="11" storage="chara/jet/face_11.png" ]
[chara_layer name="jet" part="kao" id="12" storage="chara/jet/face_12.png" ]
[chara_layer name="jet" part="kao" id="13" storage="chara/jet/face_13.png" ]
[chara_layer name="jet" part="kao" id="14" storage="chara/jet/face_14.png" ]

; 照れ
[chara_layer name="jet" part="hh" id="off" storage="none" zindex=10 ]
[chara_layer name="jet" part="hh" id="on" storage="chara/jet/hh.png"]

; 青ざめ
[chara_layer name="jet" part="ss" id="off" storage="none" zindex=20 ]
[chara_layer name="jet" part="ss" id="on" storage="chara/jet/ss.png"]

; 汗
[chara_layer name="jet" part="as" id="off" storage="none" zindex=30 ]
[chara_layer name="jet" part="as" id="on" storage="chara/jet/as.png"]

; 前髪上乗せ
[chara_layer name="jet" part="hr" id="off" storage="none" zindex=40 ]
[chara_layer name="jet" part="hr" id="on" storage="chara/jet/hr.png"]
[chara_layer name="jet" part="hr" id="on2" storage="chara/jet/hr2.png"]
[chara_layer name="jet" part="hr" id="on3" storage="chara/jet/hr3.png"]

; オブション【車掌帽子】
[chara_layer name="jet" part="hat" id="off" storage="none" zindex=50 ]
[chara_layer name="jet" part="hat" id="on" storage="chara/jet/hat.png"]

; オプション【車椅子】
[chara_layer name="jet" part="chair" id="off" storage="none" zindex=5 ]
[chara_layer name="jet" part="chair" id="on" storage="chara/jet/chair.png"]

;----------------------------------------------------------------------------------------------
; ダークネブラ
;----------------------------------------------------------------------------------------------

[chara_new name="hakase" storage="chara/kesi_l.png" jname="ダークネブラ博士" color="0x0d0015"]

; ベース
[chara_layer name="hakase" part="body" id="base" storage="chara/hakase/body.png" zindex=9 ]
; アロハ
[chara_layer name="hakase" part="body" id="mizugi" storage="chara/hakase/body_2.png" ]
; 浴衣
[chara_layer name="hakase" part="body" id="yukata" storage="chara/hakase/body_3.png" ]
; シュノーケリング
[chara_layer name="hakase" part="body" id="syuno" storage="chara/hakase/body_4.png" ]

; 表情
[chara_layer name="hakase" part="kao" id="1" storage="chara/hakase/face_1.png" zindex=15 ]
[chara_layer name="hakase" part="kao" id="0" storage="chara/hakase/face_0.png" ]
[chara_layer name="hakase" part="kao" id="2" storage="chara/hakase/face_2.png" ]
[chara_layer name="hakase" part="kao" id="3" storage="chara/hakase/face_3.png" ]
[chara_layer name="hakase" part="kao" id="4" storage="chara/hakase/face_4.png" ]
[chara_layer name="hakase" part="kao" id="5" storage="chara/hakase/face_5.png" ]
[chara_layer name="hakase" part="kao" id="6" storage="chara/hakase/face_0.png" ]
[chara_layer name="hakase" part="kao" id="7" storage="chara/hakase/face_7.png" ]
[chara_layer name="hakase" part="kao" id="8" storage="chara/hakase/face_3.png" ]
[chara_layer name="hakase" part="kao" id="11" storage="chara/hakase/face_11.png" ]
[chara_layer name="hakase" part="kao" id="12" storage="chara/hakase/face_12.png" ]
[chara_layer name="hakase" part="kao" id="13" storage="chara/hakase/face_1.png" ]
[chara_layer name="hakase" part="kao" id="14" storage="chara/hakase/face_14.png" ]
; シュノーケリングマスク
[chara_layer name="hakase" part="kao" id="15" storage="chara/hakase/face_15.png" ]

; 照れ
[chara_layer name="hakase" part="hh" id="off" storage="none" zindex=10 ]
[chara_layer name="hakase" part="hh" id="on" storage="chara/hakase/hh.png"]

; 青ざめ
[chara_layer name="hakase" part="ss" id="off" storage="none" zindex=20 ]
[chara_layer name="hakase" part="ss" id="on" storage="chara/hakase/ss.png"]

; 汗
[chara_layer name="hakase" part="as" id="off" storage="none" zindex=30 ]
[chara_layer name="hakase" part="as" id="on" storage="chara/hakase/as.png"]

; 前髪上乗せ
[chara_layer name="hakase" part="hr" id="off" storage="none" zindex=40 ]
[chara_layer name="hakase" part="hr" id="on" storage="chara/hakase/hr.png"]

; オプション【帽子+モノクルorシュノーケリングマスク】
[chara_layer name="hakase" part="msk" id="off" storage="none" zindex=50 ]
[chara_layer name="hakase" part="msk" id="syuno" storage="chara/hakase/syuno.png"]
[chara_layer name="hakase" part="msk" id="hat" storage="chara/hakase/hat.png"]

;----------------------------------------------------------------------------------------------
; ヒロシ
;----------------------------------------------------------------------------------------------

[chara_new name="hiro" storage="chara/kesi_s.png" jname="八雲博士" color="0x0d0015"]

; ベース
[chara_layer name="hiro" part="body" id="base" storage="chara/hiro/body.png" zindex=9 ]

; 表情
[chara_layer name="hiro" part="kao" id="1" storage="chara/hiro/face_1.png" zindex=15 ]
[chara_layer name="hiro" part="kao" id="0" storage="chara/hiro/face_0.png" ]
[chara_layer name="hiro" part="kao" id="2" storage="chara/hiro/face_2.png" ]
[chara_layer name="hiro" part="kao" id="3" storage="chara/hiro/face_3.png" ]
[chara_layer name="hiro" part="kao" id="4" storage="chara/hiro/face_4.png" ]
[chara_layer name="hiro" part="kao" id="5" storage="chara/hiro/face_5.png" ]
[chara_layer name="hiro" part="kao" id="6" storage="chara/hiro/face_2.png" ]
[chara_layer name="hiro" part="kao" id="7" storage="chara/hiro/face_7.png" ]
[chara_layer name="hiro" part="kao" id="8" storage="chara/hiro/face_8.png" ]
[chara_layer name="hiro" part="kao" id="11" storage="chara/hiro/face_11.png" ]
[chara_layer name="hiro" part="kao" id="12" storage="chara/hiro/face_12.png" ]
[chara_layer name="hiro" part="kao" id="13" storage="chara/hiro/face_1.png" ]
[chara_layer name="hiro" part="kao" id="14" storage="chara/hiro/face_14.png" ]

; 照れ
[chara_layer name="hiro" part="hh" id="off" storage="none" zindex=10 ]
[chara_layer name="hiro" part="hh" id="on" storage="chara/hiro/hh.png"]

; 青ざめ
[chara_layer name="hiro" part="ss" id="off" storage="none" zindex=20 ]
[chara_layer name="hiro" part="ss" id="on" storage="chara/hiro/ss.png"]

; 汗
[chara_layer name="hiro" part="as" id="off" storage="none" zindex=30 ]
[chara_layer name="hiro" part="as" id="on" storage="chara/hiro/as.png"]

; 前髪上乗せ
[chara_layer name="hiro" part="hr" id="off" storage="none" zindex=40 ]
[chara_layer name="hiro" part="hr" id="on" storage="chara/hiro/hr.png"]

;----------------------------------------------------------------------------------------------
; ヴルペクラ
;----------------------------------------------------------------------------------------------

[chara_new name="peku" storage="chara/kesi_l.png" jname="ヴルペクラ" color="0x0d0015"]

; ベース
[chara_layer name="peku" part="body" id="base" storage="chara/peku/body.png" zindex=9 ]
; 水着
[chara_layer name="peku" part="body" id="mizugi" storage="chara/peku/body_2.png" ]
; 浴衣
[chara_layer name="peku" part="body" id="yukata" storage="chara/peku/body_3.png" ]
; シュノーケリング
[chara_layer name="peku" part="body" id="syuno" storage="chara/peku/body_4.png" ]
; フードあり
[chara_layer name="peku" part="body" id="hood" storage="chara/peku/body_5.png" ]


; 表情
[chara_layer name="peku" part="kao" id="1" storage="chara/peku/face_1.png" zindex=15 ]
[chara_layer name="peku" part="kao" id="0" storage="chara/peku/face_0.png" ]
[chara_layer name="peku" part="kao" id="2" storage="chara/peku/face_2.png" ]
[chara_layer name="peku" part="kao" id="3" storage="chara/peku/face_3.png" ]
[chara_layer name="peku" part="kao" id="4" storage="chara/peku/face_4.png" ]
[chara_layer name="peku" part="kao" id="5" storage="chara/peku/face_5.png" ]
[chara_layer name="peku" part="kao" id="6" storage="chara/peku/face_6.png" ]
[chara_layer name="peku" part="kao" id="7" storage="chara/peku/face_7.png" ]
[chara_layer name="peku" part="kao" id="8" storage="chara/peku/face_8.png" ]
[chara_layer name="peku" part="kao" id="11" storage="chara/peku/face_11.png" ]
[chara_layer name="peku" part="kao" id="12" storage="chara/peku/face_12.png" ]
[chara_layer name="peku" part="kao" id="13" storage="chara/peku/face_13.png" ]
[chara_layer name="peku" part="kao" id="14" storage="chara/peku/face_14.png" ]
; シュノーケリングマスク
[chara_layer name="peku" part="kao" id="15" storage="chara/peku/face_15.png" ]

; 照れ
[chara_layer name="peku" part="hh" id="off" storage="none" zindex=10 ]
[chara_layer name="peku" part="hh" id="on" storage="chara/peku/hh.png"]

; 青ざめ
[chara_layer name="peku" part="ss" id="off" storage="none" zindex=20 ]
[chara_layer name="peku" part="ss" id="on" storage="chara/peku/ss.png"]

; 汗
[chara_layer name="peku" part="as" id="off" storage="none" zindex=30 ]
[chara_layer name="peku" part="as" id="on" storage="chara/peku/as.png"]

; 前髪上乗せ
[chara_layer name="peku" part="hr" id="off" storage="none" zindex=40 ]
[chara_layer name="peku" part="hr" id="on" storage="chara/peku/hr.png"]

; オプション【シュノーケリングマスク】
[chara_layer name="peku" part="msk" id="off" storage="none" zindex=50 ]
[chara_layer name="peku" part="msk" id="on" storage="chara/peku/syuno.png"]

;----------------------------------------------------------------------------------------------
; ヴルペクラ（もやもや）
;----------------------------------------------------------------------------------------------

[chara_new name="peku2" storage="chara/kesi_l.png" jname="ヴルペクラ" color="0x0d0015"]

; ベース
[chara_layer name="peku2" part="body" id="base" storage="chara/peku2/body.png" zindex=9 ]

; 表情
[chara_layer name="peku2" part="kao" id="1" storage="chara/kesi_l.png" zindex=15 ]

; オプション【動物】
[chara_layer name="peku2" part="mimi" id="off" storage="none" zindex=30 ]
[chara_layer name="peku2" part="mimi" id="on" storage="chara/peku2/mimi.png"]

;----------------------------------------------------------------------------------------------
; ヤブ医者
;----------------------------------------------------------------------------------------------

[chara_new name="yabu" storage="chara/kesi_s.png" jname="ヤブ医者" color="0x0d0015"]

; ベース
[chara_layer name="yabu" part="body" id="base" storage="chara/yabu/body.png" zindex=9 ]
; 水着
[chara_layer name="yabu" part="body" id="mizugi" storage="chara/yabu/body_2.png" ]
; 浴衣（はっぴ）
[chara_layer name="yabu" part="body" id="yukata" storage="chara/yabu/body_3.png" ]

; 表情
[chara_layer name="yabu" part="kao" id="1" storage="chara/yabu/face_1.png" zindex=15 ]
[chara_layer name="yabu" part="kao" id="0" storage="chara/yabu/face_0.png" ]
[chara_layer name="yabu" part="kao" id="2" storage="chara/yabu/face_2.png" ]
[chara_layer name="yabu" part="kao" id="3" storage="chara/yabu/face_3.png" ]
[chara_layer name="yabu" part="kao" id="4" storage="chara/yabu/face_4.png" ]
[chara_layer name="yabu" part="kao" id="5" storage="chara/yabu/face_5.png" ]
[chara_layer name="yabu" part="kao" id="6" storage="chara/yabu/face_6.png" ]
[chara_layer name="yabu" part="kao" id="7" storage="chara/yabu/face_7.png" ]
[chara_layer name="yabu" part="kao" id="8" storage="chara/yabu/face_8.png" ]
[chara_layer name="yabu" part="kao" id="11" storage="chara/yabu/face_11.png" ]
[chara_layer name="yabu" part="kao" id="12" storage="chara/yabu/face_12.png" ]
[chara_layer name="yabu" part="kao" id="13" storage="chara/yabu/face_13.png" ]
[chara_layer name="yabu" part="kao" id="14" storage="chara/yabu/face_14.png" ]

; 照れ
[chara_layer name="yabu" part="hh" id="off" storage="none" zindex=10 ]
[chara_layer name="yabu" part="hh" id="on" storage="chara/yabu/hh.png"]

; 青ざめ
[chara_layer name="yabu" part="ss" id="off" storage="none" zindex=20 ]
[chara_layer name="yabu" part="ss" id="on" storage="chara/yabu/ss.png"]

; 汗
[chara_layer name="yabu" part="as" id="off" storage="none" zindex=30 ]
[chara_layer name="yabu" part="as" id="on" storage="chara/yabu/as.png"]

; 前髪上乗せ
[chara_layer name="yabu" part="hr" id="off" storage="none" zindex=40 ]
[chara_layer name="yabu" part="hr" id="on" storage="chara/yabu/hr.png"]

; オプション【涙】
[chara_layer name="yabu" part="tear" id="off" storage="none" zindex=50 ]
[chara_layer name="yabu" part="tear" id="on" storage="chara/yabu/tear.png"]

; オプション【パンツ】
[chara_layer name="yabu" part="pnt" id="off" storage="none" zindex=50 ]
[chara_layer name="yabu" part="pnt" id="on" storage="chara/yabu/pnt.png"]

;----------------------------------------------------------------------------------------------
; 矢部尊
;----------------------------------------------------------------------------------------------

[chara_new name="take" storage="chara/kesi_s.png" jname="矢部尊" color="0x0d0015"]

; ベース
[chara_layer name="take" part="body" id="base" storage="chara/take/body.png" zindex=9 ]

; 表情
[chara_layer name="take" part="kao" id="1" storage="chara/take/face_1.png" zindex=15 ]
[chara_layer name="take" part="kao" id="0" storage="chara/take/face_0.png" ]
[chara_layer name="take" part="kao" id="2" storage="chara/take/face_2.png" ]
[chara_layer name="take" part="kao" id="3" storage="chara/take/face_3.png" ]
[chara_layer name="take" part="kao" id="4" storage="chara/take/face_4.png" ]
[chara_layer name="take" part="kao" id="5" storage="chara/take/face_5.png" ]
[chara_layer name="take" part="kao" id="6" storage="chara/take/face_6.png" ]
[chara_layer name="take" part="kao" id="7" storage="chara/take/face_7.png" ]
[chara_layer name="take" part="kao" id="8" storage="chara/take/face_8.png" ]
[chara_layer name="take" part="kao" id="11" storage="chara/take/face_11.png" ]
[chara_layer name="take" part="kao" id="12" storage="chara/take/face_12.png" ]
[chara_layer name="take" part="kao" id="13" storage="chara/take/face_13.png" ]
[chara_layer name="take" part="kao" id="14" storage="chara/take/face_14.png" ]

; 照れ
[chara_layer name="take" part="hh" id="off" storage="none" zindex=10 ]
[chara_layer name="take" part="hh" id="on" storage="chara/yabu/hh.png"]

; 青ざめ
[chara_layer name="take" part="ss" id="off" storage="none" zindex=20 ]
[chara_layer name="take" part="ss" id="on" storage="chara/yabu/ss.png"]

; 汗
[chara_layer name="take" part="as" id="off" storage="none" zindex=30 ]
[chara_layer name="take" part="as" id="on" storage="chara/yabu/as.png"]

;----------------------------------------------------------------------------------------------
; ミカちん
;----------------------------------------------------------------------------------------------

[chara_new name="mika" storage="chara/kesi_s.png" jname="ミカちん" color="0x0d0015"]

; ベース
[chara_layer name="mika" part="body" id="base" storage="chara/mika/body.png" zindex=9 ]
; 水着
[chara_layer name="mika" part="body" id="mizugi" storage="chara/mika/body_2.png" ]
; 浴衣（はっぴ）
[chara_layer name="mika" part="body" id="yukata" storage="chara/mika/body_3.png" ]

; 表情
[chara_layer name="mika" part="kao" id="1" storage="chara/mika/face_1.png" zindex=15 ]
[chara_layer name="mika" part="kao" id="0" storage="chara/mika/face_0.png" ]
[chara_layer name="mika" part="kao" id="2" storage="chara/mika/face_2.png" ]
[chara_layer name="mika" part="kao" id="3" storage="chara/mika/face_3.png" ]
[chara_layer name="mika" part="kao" id="4" storage="chara/mika/face_4.png" ]
[chara_layer name="mika" part="kao" id="5" storage="chara/mika/face_5.png" ]
[chara_layer name="mika" part="kao" id="6" storage="chara/mika/face_6.png" ]
[chara_layer name="mika" part="kao" id="7" storage="chara/mika/face_7.png" ]
[chara_layer name="mika" part="kao" id="8" storage="chara/mika/face_8.png" ]
[chara_layer name="mika" part="kao" id="11" storage="chara/mika/face_11.png" ]
[chara_layer name="mika" part="kao" id="12" storage="chara/mika/face_12.png" ]
[chara_layer name="mika" part="kao" id="13" storage="chara/mika/face_13.png" ]
[chara_layer name="mika" part="kao" id="14" storage="chara/mika/face_14.png" ]

; 照れ
[chara_layer name="mika" part="hh" id="off" storage="none" zindex=10 ]
[chara_layer name="mika" part="hh" id="on" storage="chara/mika/hh.png"]

; 青ざめ
[chara_layer name="mika" part="ss" id="off" storage="none" zindex=20 ]
[chara_layer name="mika" part="ss" id="on" storage="chara/mika/ss.png"]

; 汗
[chara_layer name="mika" part="as" id="off" storage="none" zindex=30 ]
[chara_layer name="mika" part="as" id="on" storage="chara/mika/as.png"]

; 前髪上乗せ
[chara_layer name="mika" part="hr" id="off" storage="none" zindex=40 ]
[chara_layer name="mika" part="hr" id="on" storage="chara/mika/hr.png"]

;----------------------------------------------------------------------------------------------
; 大美賀千秋
;----------------------------------------------------------------------------------------------

[chara_new name="tiaki" storage="chara/kesi_s.png" jname="大美賀千秋" color="0x0d0015"]

; ベース
[chara_layer name="tiaki" part="body" id="base" storage="chara/mika/body_4.png" zindex=9 ]

; 表情
[chara_layer name="tiaki" part="kao" id="1" storage="chara/mika/face_1.png" zindex=15 ]
[chara_layer name="tiaki" part="kao" id="0" storage="chara/mika/face_0.png" ]
[chara_layer name="tiaki" part="kao" id="2" storage="chara/mika/face_2.png" ]
[chara_layer name="tiaki" part="kao" id="3" storage="chara/mika/face_3.png" ]
[chara_layer name="tiaki" part="kao" id="4" storage="chara/mika/face_4.png" ]
[chara_layer name="tiaki" part="kao" id="5" storage="chara/mika/face_5.png" ]
[chara_layer name="tiaki" part="kao" id="6" storage="chara/mika/face_6.png" ]
[chara_layer name="tiaki" part="kao" id="7" storage="chara/mika/face_7.png" ]
[chara_layer name="tiaki" part="kao" id="8" storage="chara/mika/face_8.png" ]
[chara_layer name="tiaki" part="kao" id="11" storage="chara/mika/face_11.png" ]
[chara_layer name="tiaki" part="kao" id="12" storage="chara/mika/face_12.png" ]
[chara_layer name="tiaki" part="kao" id="13" storage="chara/mika/face_13.png" ]
[chara_layer name="tiaki" part="kao" id="14" storage="chara/mika/face_14.png" ]

; 照れ
[chara_layer name="tiaki" part="hh" id="off" storage="none" zindex=10 ]
[chara_layer name="tiaki" part="hh" id="on" storage="chara/mika/hh.png"]

; 青ざめ
[chara_layer name="tiaki" part="ss" id="off" storage="none" zindex=20 ]
[chara_layer name="tiaki" part="ss" id="on" storage="chara/mika/ss.png"]

; 汗
[chara_layer name="tiaki" part="as" id="off" storage="none" zindex=30 ]
[chara_layer name="tiaki" part="as" id="on" storage="chara/mika/as.png"]

; 前髪上乗せ
[chara_layer name="tiaki" part="hr" id="off" storage="none" zindex=40 ]
[chara_layer name="tiaki" part="hr" id="on" storage="chara/mika/hr2.png"]

;----------------------------------------------------------------------------------------------
; ヌシ
;----------------------------------------------------------------------------------------------

[chara_new name="nusi" storage="chara/kesi_m.png" jname="ヌシ" color="0x0d0015"]

; ベース
[chara_layer name="nusi" part="body" id="base" storage="chara/nusi/body.png" zindex=9 ]
; 浴衣（はっぴ）
[chara_layer name="nusi" part="body" id="yukata" storage="chara/nusi/body_2.png" ]

; 表情
[chara_layer name="nusi" part="kao" id="1" storage="chara/nusi/face_1.png" zindex=15 ]
[chara_layer name="nusi" part="kao" id="0" storage="chara/nusi/face_0.png" ]
[chara_layer name="nusi" part="kao" id="2" storage="chara/nusi/face_2.png" ]
[chara_layer name="nusi" part="kao" id="3" storage="chara/nusi/face_3.png" ]
[chara_layer name="nusi" part="kao" id="4" storage="chara/nusi/face_4.png" ]
[chara_layer name="nusi" part="kao" id="5" storage="chara/nusi/face_5.png" ]
[chara_layer name="nusi" part="kao" id="6" storage="chara/nusi/face_6.png" ]
[chara_layer name="nusi" part="kao" id="7" storage="chara/nusi/face_7.png" ]
[chara_layer name="nusi" part="kao" id="8" storage="chara/nusi/face_8.png" ]
[chara_layer name="nusi" part="kao" id="11" storage="chara/nusi/face_11.png" ]
[chara_layer name="nusi" part="kao" id="12" storage="chara/nusi/face_12.png" ]
[chara_layer name="nusi" part="kao" id="13" storage="chara/nusi/face_13.png" ]
[chara_layer name="nusi" part="kao" id="14" storage="chara/nusi/face_14.png" ]

; 照れ
[chara_layer name="nusi" part="hh" id="off" storage="none" zindex=10 ]
[chara_layer name="nusi" part="hh" id="on" storage="chara/nusi/hh.png"]

; 青ざめ
[chara_layer name="nusi" part="ss" id="off" storage="none" zindex=20 ]
[chara_layer name="nusi" part="ss" id="on" storage="chara/nusi/ss.png"]

; 汗
[chara_layer name="nusi" part="as" id="off" storage="none" zindex=30 ]
[chara_layer name="nusi" part="as" id="on" storage="chara/nusi/as.png"]

; 前髪上乗せ
[chara_layer name="nusi" part="hr" id="off" storage="none" zindex=40 ]
[chara_layer name="nusi" part="hr" id="on" storage="chara/nusi/hr.png"]

;----------------------------------------------------------------------------------------------
; 魔太郎子
;----------------------------------------------------------------------------------------------

[chara_new name="mata" storage="chara/kesi_s.png" jname="魔太郎子" color="0x0d0015"]

; ベース
[chara_layer name="mata" part="body" id="base" storage="chara/mata/body.png" zindex=9 ]
; 浴衣（はっぴ）
[chara_layer name="mata" part="body" id="yukata" storage="chara/mata/body_2.png" ]

; 表情
[chara_layer name="mata" part="kao" id="1" storage="chara/mata/face_1.png" zindex=15 ]
[chara_layer name="mata" part="kao" id="0" storage="chara/mata/face_0.png" ]
[chara_layer name="mata" part="kao" id="2" storage="chara/mata/face_2.png" ]
[chara_layer name="mata" part="kao" id="3" storage="chara/mata/face_3.png" ]
[chara_layer name="mata" part="kao" id="4" storage="chara/mata/face_4.png" ]
[chara_layer name="mata" part="kao" id="5" storage="chara/mata/face_5.png" ]
[chara_layer name="mata" part="kao" id="6" storage="chara/mata/face_6.png" ]
[chara_layer name="mata" part="kao" id="7" storage="chara/mata/face_7.png" ]
[chara_layer name="mata" part="kao" id="8" storage="chara/mata/face_8.png" ]
[chara_layer name="mata" part="kao" id="11" storage="chara/mata/face_11.png" ]
[chara_layer name="mata" part="kao" id="12" storage="chara/mata/face_12.png" ]
[chara_layer name="mata" part="kao" id="13" storage="chara/mata/face_13.png" ]
[chara_layer name="mata" part="kao" id="14" storage="chara/mata/face_14.png" ]

; 照れ
[chara_layer name="mata" part="hh" id="off" storage="none" zindex=10 ]
[chara_layer name="mata" part="hh" id="on" storage="chara/mata/hh.png"]

; 青ざめ
[chara_layer name="mata" part="ss" id="off" storage="none" zindex=20 ]
[chara_layer name="mata" part="ss" id="on" storage="chara/mata/ss.png"]

; 汗
[chara_layer name="mata" part="as" id="off" storage="none" zindex=30 ]
[chara_layer name="mata" part="as" id="on" storage="chara/mata/as.png"]

; 前髪上乗せ
[chara_layer name="mata" part="hr" id="off" storage="none" zindex=40 ]
[chara_layer name="mata" part="hr" id="on" storage="chara/mata/hr.png"]

; オブション【帽子】
[chara_layer name="jet" part="hat" id="off" storage="none" zindex=50 ]
[chara_layer name="jet" part="hat" id="on" storage="chara/mata/hat.png"]

;----------------------------------------------------------------------------------------------
; ゴンザレス一億世
;----------------------------------------------------------------------------------------------

[chara_new name="gon" storage="chara/kesi_l.png" jname="ゴンザレス一億世" color="0x0d0015"]

; ベース

[chara_layer name="gon" part="body" id="base" storage="chara/gon/body.png" zindex=9 ]
; 浴衣（はっぴ）
[chara_layer name="gon" part="body" id="yukata" storage="chara/gon/body_2.png" ]

; 表情
[chara_layer name="gon" part="kao" id="1" storage="chara/gon/face_1.png" zindex=15 ]
[chara_layer name="gon" part="kao" id="0" storage="chara/gon/face_0.png" ]
[chara_layer name="gon" part="kao" id="2" storage="chara/gon/face_2.png" ]
[chara_layer name="gon" part="kao" id="3" storage="chara/gon/face_3.png" ]
[chara_layer name="gon" part="kao" id="4" storage="chara/gon/face_4.png" ]
[chara_layer name="gon" part="kao" id="5" storage="chara/gon/face_5.png" ]
[chara_layer name="gon" part="kao" id="6" storage="chara/gon/face_6.png" ]
[chara_layer name="gon" part="kao" id="7" storage="chara/gon/face_7.png" ]
[chara_layer name="gon" part="kao" id="8" storage="chara/gon/face_8.png" ]
[chara_layer name="gon" part="kao" id="11" storage="chara/gon/face_11.png" ]
[chara_layer name="gon" part="kao" id="12" storage="chara/gon/face_12.png" ]
[chara_layer name="gon" part="kao" id="13" storage="chara/gon/face_13.png" ]
[chara_layer name="gon" part="kao" id="14" storage="chara/gon/face_14.png" ]

; 照れ
[chara_layer name="gon" part="hh" id="off" storage="none" zindex=10 ]
[chara_layer name="gon" part="hh" id="on" storage="chara/gon/hh.png"]

; 青ざめ
[chara_layer name="gon" part="ss" id="off" storage="none" zindex=20 ]
[chara_layer name="gon" part="ss" id="on" storage="chara/gon/ss.png"]

; 汗
[chara_layer name="gon" part="as" id="off" storage="none" zindex=30 ]
[chara_layer name="gon" part="as" id="on" storage="chara/gon/as.png"]

; 前髪上乗せ
[chara_layer name="gon" part="hr" id="off" storage="none" zindex=40 ]
[chara_layer name="gon" part="hr" id="on" storage="chara/gon/hr.png"]

;----------------------------------------------------------------------------------------------
; サウス
;----------------------------------------------------------------------------------------------

[chara_new name="sausu" storage="chara/kesi_xl.png" jname="サウス" color="0x0d0015"]

; ベース
[chara_layer name="sausu" part="body" id="base" storage="chara/sausu/body.png" zindex=9 ]

; 表情
[chara_layer name="sausu" part="kao" id="1" storage="chara/sausu/face_1.png" zindex=15 ]
[chara_layer name="sausu" part="kao" id="0" storage="chara/sausu/face_0.png" ]
[chara_layer name="sausu" part="kao" id="2" storage="chara/sausu/face_2.png" ]
[chara_layer name="sausu" part="kao" id="3" storage="chara/sausu/face_3.png" ]
[chara_layer name="sausu" part="kao" id="4" storage="chara/sausu/face_4.png" ]
[chara_layer name="sausu" part="kao" id="5" storage="chara/sausu/face_5.png" ]
[chara_layer name="sausu" part="kao" id="6" storage="chara/sausu/face_6.png" ]
[chara_layer name="sausu" part="kao" id="7" storage="chara/sausu/face_7.png" ]
[chara_layer name="sausu" part="kao" id="8" storage="chara/sausu/face_8.png" ]
[chara_layer name="sausu" part="kao" id="11" storage="chara/sausu/face_11.png" ]
[chara_layer name="sausu" part="kao" id="12" storage="chara/sausu/face_12.png" ]
[chara_layer name="sausu" part="kao" id="13" storage="chara/sausu/face_13.png" ]
[chara_layer name="sausu" part="kao" id="14" storage="chara/sausu/face_14.png" ]

; 照れ
[chara_layer name="sausu" part="hh" id="off" storage="none" zindex=10 ]
[chara_layer name="sausu" part="hh" id="on" storage="chara/sausu/hh.png"]

; 青ざめ
[chara_layer name="sausu" part="ss" id="off" storage="none" zindex=20 ]
[chara_layer name="sausu" part="ss" id="on" storage="chara/sausu/ss.png"]

; 汗
[chara_layer name="sausu" part="as" id="off" storage="none" zindex=30 ]
[chara_layer name="sausu" part="as" id="on" storage="chara/sausu/as.png"]

; 前髪上乗せ
[chara_layer name="sausu" part="hr" id="off" storage="none" zindex=40 ]
[chara_layer name="sausu" part="hr" id="on" storage="chara/sausu/hr.png"]

;----------------------------------------------------------------------------------------------
; 糠星の夜
;----------------------------------------------------------------------------------------------

[chara_new name="yoru" storage="chara/kesi_xl.png" jname="糠星の夜" color="0x0d0015"]

; ベース
[chara_layer name="yoru" part="body" id="base" storage="chara/yoru/body.png" zindex=9 ]

; 表情
[chara_layer name="yoru" part="kao" id="1" storage="chara/yoru/face_1.png" zindex=15 ]
[chara_layer name="yoru" part="kao" id="0" storage="chara/yoru/face_0.png" ]
[chara_layer name="yoru" part="kao" id="2" storage="chara/yoru/face_2.png" ]
[chara_layer name="yoru" part="kao" id="3" storage="chara/yoru/face_3.png" ]
[chara_layer name="yoru" part="kao" id="4" storage="chara/yoru/face_4.png" ]
[chara_layer name="yoru" part="kao" id="5" storage="chara/yoru/face_5.png" ]
[chara_layer name="yoru" part="kao" id="6" storage="chara/yoru/face_6.png" ]
[chara_layer name="yoru" part="kao" id="7" storage="chara/yoru/face_7.png" ]
[chara_layer name="yoru" part="kao" id="8" storage="chara/yoru/face_8.png" ]
[chara_layer name="yoru" part="kao" id="11" storage="chara/yoru/face_11.png" ]
[chara_layer name="yoru" part="kao" id="12" storage="chara/yoru/face_12.png" ]
[chara_layer name="yoru" part="kao" id="13" storage="chara/yoru/face_13.png" ]
[chara_layer name="yoru" part="kao" id="14" storage="chara/yoru/face_14.png" ]

; 照れ
[chara_layer name="yoru" part="hh" id="off" storage="none" zindex=10 ]
[chara_layer name="yoru" part="hh" id="on" storage="chara/yoru/hh.png"]

; 青ざめ
[chara_layer name="yoru" part="ss" id="off" storage="none" zindex=20 ]
[chara_layer name="yoru" part="ss" id="on" storage="chara/yoru/ss.png"]

; 汗
[chara_layer name="yoru" part="as" id="off" storage="none" zindex=30 ]
[chara_layer name="yoru" part="as" id="on" storage="chara/yoru/as.png"]

; 前髪上乗せ
[chara_layer name="yoru" part="hr" id="off" storage="none" zindex=40 ]
[chara_layer name="yoru" part="hr" id="on" storage="chara/yoru/hr.png"]

;----------------------------------------------------------------------------------------------
; カオル
;----------------------------------------------------------------------------------------------

[chara_new name="kaoru" storage="chara/kesi_s.png" jname="落合薫" color="0x0d0015"]

; ベース
[chara_layer name="kaoru" part="body" id="base" storage="chara/kaoru/body.png" zindex=9 ]

; 表情
[chara_layer name="kaoru" part="kao" id="1" storage="chara/kaoru/face_1.png" zindex=15 ]
[chara_layer name="kaoru" part="kao" id="0" storage="chara/kaoru/face_0.png" ]
[chara_layer name="kaoru" part="kao" id="2" storage="chara/kaoru/face_2.png" ]
[chara_layer name="kaoru" part="kao" id="3" storage="chara/kaoru/face_3.png" ]
[chara_layer name="kaoru" part="kao" id="11" storage="chara/kaoru/face_11.png" ]
[chara_layer name="kaoru" part="kao" id="12" storage="chara/kaoru/face_12.png" ]
[chara_layer name="kaoru" part="kao" id="13" storage="chara/kaoru/face_13.png" ]
[chara_layer name="kaoru" part="kao" id="14" storage="chara/kaoru/face_14.png" ]

; 汗
[chara_layer name="kaoru" part="as" id="off" storage="none" zindex=30 ]
[chara_layer name="kaoru" part="as" id="on" storage="chara/kaoru/as.png"]

; 照れ
[chara_layer name="kaoru" part="hh" id="off" storage="none" zindex=10 ]
[chara_layer name="kaoru" part="hh" id="on" storage="chara/kaoru/hh.png"]

; 青ざめ
[chara_layer name="kaoru" part="ss" id="off" storage="none" zindex=20 ]
[chara_layer name="kaoru" part="ss" id="on" storage="chara/kaoru/ss.png"]

;----------------------------------------------------------------------------------------------

;キャラクター立ち絵表示

;----------------------------------------------------------------------------------------------

; プリンセス窓
[macro name="puri_w"]
[chara_part name="puri_w" body=%body|base kao=%kao|1 as=%as|off hh=%hh|off hr=on ss=%ss|off hat=%hat|okan ]
[chara_show name="puri_w" layer="message0" left="1" top="1" zindex="1005" time="150" width=330 height=720]
[endmacro]

; プリンセス
[macro name="puri"]
[chara_part name="puri" body=%body|base kao=%kao|1 as=%as|off hh=%hh|off ss=%ss|off hr=on hat=%hat|on ]
[chara_show name="puri" layer="1" width="437" height="720" time="150"]
[endmacro]

; 転生ヒメコ
[macro name="hime"]
[chara_part name="hime" body=base kao=%kao|1 as=%as|off hh=%hh|off ss=%ss|off hr=on ]
[chara_show name="hime" layer="1" width="437" height="720" time="150"]
[endmacro]

; ヒメコ（女児）
[macro name="hime2"]
[chara_part name="hime2" body=%body|base kao=%kao|1 as=%as|off hh=%hh|off ss=%ss|off hr=on ]
[chara_show name="hime2" layer="1" width="437" height="720" time="150"]
[endmacro]

; ドロップ
[macro name="drop"]
[chara_part name="drop" body=%body|base kao=%kao|1 as=%as|off hh=%hh|off ss=%ss|off hr=on hat=%hat|on ]
[chara_show name="drop" layer="1" width="437" height="720" time="150"]
[endmacro]

; ソラ
[macro name="sora"]
[chara_part name="sora" body=%body|base kao=%kao|0 as=%as|off hh=%hh|off ss=%ss|off hr=on ]
[chara_show name="sora" layer="1" width="437" height="720" time="150"]
[endmacro]

; ソラ（おっさん）
[macro name="sora2"]
[chara_part name="sora2" body=%body|base kao=%kao|0 as=%as|off hh=%hh|off ss=%ss|off ]
[chara_show name="sora2" layer="1" width="437" height="720" time="150"]
[endmacro]

; オチアイ
[macro name="otiai"]
[chara_part name="otiai" body=%body|base kao=%kao|0 as=%as|off hh=%hh|off ss=%ss|off hr=on ]
[chara_show name="otiai" layer="1" width="437" height="720" time="150"]
[endmacro]

; カイト
[macro name="kite"]
[chara_part name="kite" body=%body|base kao=%kao|0 as=%as|off hh=%hh|off ss=%ss|off hr=on tear=%tear|off]
[chara_show name="kite" layer="1" width="514" height="720" time="150"]
[endmacro]

; 伊東一近
[macro name="kazu"]
[chara_part name="kazu" body=%body|base kao=%kao|0 as=%as|off hh=%hh|off ss=%ss|off hr=on chair=%chair|on ]
[chara_show name="kazu" layer="1" width="437" height="720" time="150"]
[endmacro]

; クォードリリオン
[macro name="riri"]
[chara_part name="riri" body=%body|base kao=%kao|1 as=%as|off hh=%hh|off ss=%ss|off hr=on ]
[chara_show name="riri" layer="1" width="514" height="720" time="150" ]
[endmacro]

; 神崎凛生
[macro name="rio"]
[chara_part name="rio" body=%body|base kao=%kao|1 as=%as|off hh=%hh|off ss=%ss|off hr=on ]
[chara_show name="rio" layer="1" width="437" height="720" time="150"]
[endmacro]

; 神崎凛生（子供時代）
[macro name="rio2"]
[chara_part name="rio2" body=%body|base kao=%kao|1 as=%as|off hh=%hh|off ss=%ss|off hr=on ]
[chara_show name="rio2" layer="1" width="437" height="720" time="150"]
[endmacro]

; ハートシェイプ
[macro name="hati"]
[chara_part name="hati" body=%body|base kao=%kao|5 as=%as|off hh=%hh|off ss=%ss|off hr=on ]
[chara_show name="hati" layer="1" width="437" height="720" time="150"]
[endmacro]

; ジェット
[macro name="jet"]
[chara_part name="jet" body=%body|base kao=%kao|0 as=%as|off hh=%hh|off ss=%ss|off hr=%hr|on ]
[chara_show name="jet" layer="1" width="437" height="720" time="150"]
[endmacro]

; ダークネブラ
[macro name="hakase"]
[chara_part name="hakase" body=%body|base kao=%kao|1 as=%as|off hh=%hh|off ss=%ss|off hr=on msk=%msk|off ]
[chara_show name="hakase" layer="1" width="571" height="720" time="150"]
[endmacro]

; ヒロシ
[macro name="hiro"]
[chara_part name="hiro" body=%body|base kao=%kao|1 as=%as|off hh=%hh|off ss=%ss|off hr=on ]
[chara_show name="hiro" layer="1" width="437" height="720" time="150"]
[endmacro]

; ヴルペクラ
[macro name="peku"]
[chara_part name="peku" body=%body|base kao=%kao|1 as=%as|off hh=%hh|off ss=%ss|off hr=on msk=%msk|off ]
[chara_show name="peku" layer="1" width="571" height="720" time="150"]
[endmacro]

; ヴルペクラ（もやもや）
[macro name="peku2"]
[chara_part name="peku2" body=base kao=1 mimi=%mimi|off ]
[chara_show name="peku2" layer="1" width="571" height="720" time="150"]
[endmacro]

; ヤブ医者
[macro name="yabu"]
[chara_part name="yabu" body=%body|base kao=%kao|1 as=%as|off hh=%hh|off ss=%ss|off hr=on tear=%tear|off pnt=%pnt|off ]
[chara_show name="yabu" layer="1" width="437" height="720" time="150"]
[endmacro]

; 矢部尊
[macro name="take"]
[chara_part name="take" body=%body|base kao=%kao|0 as=%as|off hh=%hh|off ss=%ss|off ]
[chara_show name="take" layer="1" width="437" height="720" time="150"]
[endmacro]

; ミカちん
[macro name="mika"]
[chara_part name="mika" body=%body|base kao=%kao|1 as=%as|off hh=%hh|off ss=%ss|off hr=on ]
[chara_show name="mika" layer="1" width="437" height="720" time="150"]
[endmacro]

; 大美賀千秋
[macro name="tiaki"]
[chara_part name="tiaki" body=%body|base kao=%kao|1 as=%as|off hh=%hh|off ss=%ss|off hr=on ]
[chara_show name="tiaki" layer="1" width="437" height="720" time="150"]
[endmacro]

; ヌシ
[macro name="nusi"]
[chara_part name="nusi" body=%body|base kao=%kao|5 as=%as|off hh=%hh|off ss=%ss|off hr=on ]
[chara_show name="nusi" layer="1" width="514" height="720" time="150"]
[endmacro]

; 魔太郎子
[macro name="mata"]
[chara_part name="mata" body=%body|base kao=%kao|1 as=%as|off hh=%hh|off ss=%ss|off hr=on hat=%hat|on ]
[chara_show name="mata" layer="1" width="437" height="720" time="150"]
[endmacro]

; ゴンザレス一億世
[macro name="gon"]
[chara_part name="gon" body=%body|base kao=%kao|1 as=%as|off hh=%hh|off ss=%ss|off hr=on ]
[chara_show name="gon" layer="1" width="571" height="720" time="150"]
[endmacro]

; サウス
[macro name="sausu"]
[chara_part name="sausu" body=%body|base kao=%kao|1 as=%as|off hh=%hh|off ss=%ss|off hr=on ]
[chara_show name="sausu" layer="1" width="694" height="720" time="150"]
[endmacro]

; 糠星の夜
[macro name="yoru"]
[chara_part name="yoru" body=%body|base kao=%kao|0 as=%as|off hh=%hh|off ss=%ss|off hr=on ]
[chara_show name="yoru" layer="1" width="694" height="720" time="150"]
[endmacro]

; カオル
[macro name="kaoru"]
[chara_part name="kaoru" body=%body|base kao=%kao|1 as=%as|off hh=%hh|off ss=%ss|off ]
[chara_show name="kaoru" layer="1" width="437" height="720" time="150"]
[endmacro]

;------------------------------------------------------------------------------------------------

;キャラクター消す

;------------------------------------------------------------------------------------------------

;全部消す
[macro name="off_all"]
[chara_hide_all layer="message0" time="150" wait=false]
[chara_hide_all layer="1" time=150 wait=true]
[endmacro]

; プリンセス（MW横）
[macro name="off_puri"]
[chara_hide name=puri_w layer="message0" pos_mode=false time="150"]
[chara_part_reset name=puri_w]
[chara_hide name=puri layer="1" pos_mode=false time="150"]
[chara_part_reset name=puri]
[endmacro]

; プリンセス（立ち絵）
[macro name="off_puri2"]
[chara_hide name=puri layer="1" pos_mode=false time="150"]
[chara_part_reset name=puri]
[endmacro]

; ヒメコ
[macro name="off_hime"]
[chara_hide name=hime layer="1" pos_mode=false time="150"]
[chara_part_reset name=hime]
[endmacro]

; 幼少ヒメコ
[macro name="off_hime2"]
[chara_hide name=hime2 layer="1" pos_mode=false time="150"]
[chara_part_reset name=hime2]
[endmacro]

; ドロップ
[macro name="off_drop"]
[chara_hide name=drop layer="1" pos_mode=false time="150"]
[chara_part_reset name=drop]
[endmacro]

; ソラ
[macro name="off_sora"]
[chara_hide name=sora layer="1" pos_mode=false time="150"]
[chara_part_reset name=sora]
[endmacro]

; ソラ（子供時代）
[macro name="off_otiai"]
[chara_hide name=otiai layer="1" pos_mode=false time="150"]
[chara_part_reset name=otiai]
[endmacro]

; クォードリリオン
[macro name="off_riri"]
[chara_hide name=riri layer="1" pos_mode=false time="150"]
[chara_part_reset name=riri]
[endmacro]

; 凛生
[macro name="off_rio"]
[chara_hide name=rio layer="1" pos_mode=false time="150"]
[chara_part_reset name=rio]
[endmacro]

; ちび凛生
[macro name="off_rio2"]
[chara_hide name=rio2 layer="1" pos_mode=false time="150"]
[chara_part_reset name=rio2]
[endmacro]

; カイト
[macro name="off_kite"]
[chara_hide name=kite layer="1" pos_mode=false time="150"]
[chara_part_reset name=kite]
[endmacro]

; カズチカ
[macro name="off_kazu"]
[chara_hide name=kazu layer="1" pos_mode=false time="150"]
[chara_part_reset name=kazu]
[endmacro]

; ハートシェイプ
[macro name="off_hati"]
[chara_hide name=hati layer="1" pos_mode=false time="150"]
[chara_part_reset name=hati]
[endmacro]

; ジェット
[macro name="off_jet"]
[chara_hide name=jet layer="1" pos_mode=false time="150"]
[chara_part_reset name=jet]
[endmacro]

; ダークネブラ
[macro name="off_hakase"]
[chara_hide name=hakase layer="1" pos_mode=false time="150"]
[chara_part_reset name=hakase]
[endmacro]

; ヒロシ
[macro name="off_hiro"]
[chara_hide name=hiro layer="1" pos_mode=false time="150"]
[chara_part_reset name=hiro]
[endmacro]

; ヴルペクラ
[macro name="off_peku"]
[chara_hide name=peku layer="1" pos_mode=false time="150"]
[chara_part_reset name=peku]
[endmacro]

; もやもや
[macro name="off_peku2"]
[chara_hide name=peku2 layer="1" pos_mode=false time="150"]
[chara_part_reset name=peku2]
[endmacro]

; ヤブ医者
[macro name="off_yabu"]
[chara_hide name=yabu layer="1" pos_mode=false time="150"]
[chara_part_reset name=yabu]
[endmacro]

; タケル
[macro name="off_take"]
[chara_hide name=take layer="1" pos_mode=false time="150"]
[chara_part_reset name=take]
[endmacro]

; ミカちん
[macro name="off_mika"]
[chara_hide name=mika layer="1" pos_mode=false time="150"]
[chara_part_reset name=mika]
[endmacro]

; チアキ
[macro name="off_tiaki"]
[chara_hide name=tiaki layer="1" pos_mode=false time="150"]
[chara_part_reset name=tiaki]
[endmacro]

; ヌシ
[macro name="off_nusi"]
[chara_hide name=nusi layer="1" pos_mode=false time="150"]
[chara_part_reset name=nusi]
[endmacro]

; 魔太郎子
[macro name="off_mata"]
[chara_hide name=mata layer="1" pos_mode=false time="150"]
[chara_part_reset name=mata]
[endmacro]

; ゴンザレス一億世
[macro name="off_gon"]
[chara_hide name=gon layer="1" pos_mode=false time="150"]
[chara_part_reset name=gon]
[endmacro]

; サウス
[macro name="off_sausu"]
[chara_hide name=sausu layer="1" pos_mode=false time="150"]
[chara_part_reset name=sausu]
[endmacro]

; 糠星の夜
[macro name="off_yoru"]
[chara_hide name=yoru layer="1" pos_mode=false time="150"]
[chara_part_reset name=yoru]
[endmacro]

; カオル
[macro name="off_kaoru"]
[chara_hide name=kaoru layer="1" pos_mode=false time="150"]
[chara_part_reset name=kaoru]
[endmacro]

;----------------------------------------------------------------------------------------------

; 立ち絵なしで名前表示の人ら

;----------------------------------------------------------------------------------------------

[chara_new name="unknown" storage="chara/kesi_s.png" jname="？？？" color="0x0d0015" ]

[chara_new name="man" storage="chara/kesi_s.png" jname="青年" color="0x0d0015" ]
[chara_new name="nurse" storage="chara/kesi_s.png" jname="看護婦" color="0x0d0015" ]
[chara_new name="student" storage="chara/kesi_s.png" jname="学生" color="0x0d0015" ]
[chara_new name="kids" storage="chara/kesi_s.png" jname="子供たち" color="0x0d0015" ]
[chara_new name="turu" storage="chara/kesi_s.png" jname="千羽鶴" color="0x0d0015" ]

[chara_new name="2nin" storage="chara/kesi_s.png" jname="２人" color="0x0d0015" ]
[chara_new name="3nin" storage="chara/kesi_s.png" jname="３人" color="0x0d0015" ]
[chara_new name="xnin" storage="chara/kesi_s.png" jname="一同" color="0x0d0015" ]

[chara_new name="v_pekura" storage="chara/kesi_s.png" jname="ヴルペクラの声" color="0x0d0015" ]
[chara_new name="v_riri" storage="chara/kesi_s.png" jname="クォードリリオンの声" color="0x0d0015" ]
[chara_new name="tobira" storage="chara/kesi_s.png" jname="扉の向こう" color="0x0d0015" ]

[chara_new name="kazumama" storage="chara/kesi_s.png" jname="一近の母" color="0x0d0015" ]
[chara_new name="riomama" storage="chara/kesi_s.png" jname="凛生の母" color="0x0d0015" ]
[chara_new name="soramama" storage="chara/kesi_s.png" jname="宙の母" color="0x0d0015" ]

[chara_new name="jet2" storage="chara/kesi_s.png" jname="羽田ジェット" color="0x0d0015" ]
[chara_new name="hutago" storage="chara/kesi_s.png" jname="ハティ&ジェット" color="0x0d0015" ]
[chara_new name="kitex" storage="chara/kesi_s.png" jname="カイト？" color="0x0d0015" ]

[chara_new name="yujin" storage="chara/kesi_s.png" jname="友人" color="0x0d0015" ]

;----------------------------------------------------------------------------------------------
;名前表示
;----------------------------------------------------------------------------------------------

; プリンセス
[macro name=":princess:"]
#puri
[endmacro]

; 星名媛子
[macro name=":himeko:"]
#hime2
[endmacro]

; 星名媛子
[macro name=":girl:"]
#hime
[endmacro]

; ドロップ
[macro name=":drop:"]
#drop
[endmacro]

; 落合宙
[macro name=":sora:"]
#sora
[endmacro]

; オチアイ
[macro name=":otiai:"]
#otiai
[endmacro]

; カイト
[macro name=":kite:"]
#kite
[endmacro]

; カイト
[macro name=":kitex:"]
#kitex
[endmacro]

; 伊東一近
[macro name=":kazutika:"]
#kazu
[endmacro]

; クォードリリオン
[macro name=":quadrillion:"]
#riri
[endmacro]

; 神崎凛生
[macro name=":rio:"]
#rio
[endmacro]

; ハートシェイプ
[macro name=":heartshape:"]
#hati
[endmacro]

; ジェット
[macro name=":jet:"]
#jet
[endmacro]

; 羽田ジェット
[macro name=":jet2:"]
#jet2
[endmacro]

; ダークネブラ博士
[macro name=":darknebula:"]
#hakase
[endmacro]

; 八雲博士
[macro name=":hirosi:"]
#hiro
[endmacro]

; ヴルペクラ
[macro name=":vulpecula:"]
#peku
[endmacro]

; ヤブ医者
[macro name=":yabu:"]
#yabu
[endmacro]

; 矢部尊
[macro name=":takeru:"]
#take
[endmacro]

; ミカちん
[macro name=":mika:"]
#mika
[endmacro]

; 大美賀千秋
[macro name=":tiaki:"]
#tiaki
[endmacro]

; ヌシ
[macro name=":nusi:"]
#nusi
[endmacro]

; 魔太郎子
[macro name=":mataroko:"]
#mata
[endmacro]

; ゴンザレス
[macro name=":gonzalez:"]
#gon
[endmacro]

; サウス
[macro name=":sausu:"]
#sausu
[endmacro]

; 糠星の夜
[macro name=":yoru:"]
#yoru
[endmacro]

; ジェット&ハティ
[macro name=":hutago:"]
#hutago
[endmacro]

; ？？？
[macro name=":unknown:"]
#unknown
[endmacro]

; ２人
[macro name=":2nin:"]
#2nin
[endmacro]

; ３人
[macro name=":3nin:"]
#3nin
[endmacro]

; 一同
[macro name=":xnin:"]
#xnin
[endmacro]

; ヴルペクラの声
[macro name=":v_pekura:"]
#v_pekura
[endmacro]

; クリリンの声
[macro name=":v_riri:"]
#v_riri
[endmacro]

; 扉の向こう
[macro name=":tobira:"]
#tobira
[endmacro]

; 青年
[macro name=":man:"]
#man
[endmacro]

; 落合薫
[macro name=":kaoru:"]
#kaoru
[endmacro]

; ソラママ
[macro name=":soramama:"]
#soramama
[endmacro]

; カズママ
[macro name=":kazumama:"]
#kazumama
[endmacro]

; リオママ
[macro name=":riomama:"]
#riomama
[endmacro]

; 看護婦
[macro name=":nurse:"]
#nurse
[endmacro]

; 学生たち
[macro name=":student:"]
#student
[endmacro]

; 子供たち
[macro name=":kids:"]
#kids
[endmacro]


; 千羽鶴
[macro name=":turu:"]
#turu
[endmacro]


; 文字けし
[macro name="::"]
#
[endmacro]


;----------------------------------------------------------------------------------------------
;名前変換
;----------------------------------------------------------------------------------------------

; 名前
[macro name="player"]
[emb exp="sf.player_name"]
[endmacro]

; ナマエ
[macro name="player2"]
[emb exp="sf.player_name2"]
[endmacro]

; あだ名
[macro name="player3"]
[emb exp="sf.player_name3"]
[endmacro]

; あだ名（ノイズあり）
[macro name="player3b"]
[se storage="se8_09.ogg"]
[font color=0x#00008b]
■■■
[resetfont]
[endmacro]


;----------------------------------------------------------------------------------------------
;----------------------------------------------------------------------------------------------


[return]

