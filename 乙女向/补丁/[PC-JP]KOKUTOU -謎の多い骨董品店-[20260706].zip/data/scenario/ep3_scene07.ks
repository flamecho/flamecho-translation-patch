﻿;--------------------------------------------------
;■黒十　本文テキスト　ep3　御伽倶楽部
;--------------------------------------------------
;
;■ep3_scene07
;
;--------------------------------------------------
[eval exp="f.fourth_select=0"]
[eval exp="f.fourth_map_1=0"]
[eval exp="f.fourth_map_2=0"]
[eval exp="f.fourth_map_3=0"]
[eval exp="f.fourth_map_4=0"]
[eval exp="f.fourth_map_5=0"]
[eval exp="f.fourth_map_6=0"]
[eval exp="f.fourth_map_7=0"]
;--------------------------------------------------
;//地図画面
*fourth_select|
[savetitle text="地図画面"]
;-------------------------------------------------
;//２回場所移動を間違うとバッド・エンドのルート『首を切っておしまい』へ
[if exp="f.fourth_select==2"]
[jump target="*fourth_select_end"]
[else]
[jump target="*fourth_select_map"]
[endif]

;--------------------------------------------------
*fourth_select_map
[savetitle text="地図画面"]
;-------------------------------------------------
;//前画面の要素を削除

;テキストウィンドウ削除
[end_text]

;全キャラ削除
[allc]

;//黒ベタ
[bg10 bg="black.png"]


[bg10 bg="select_map.jpg"]

;BGM再生
[bgm ogg="tukikage.ogg"]

;//場所移動の選択肢--------------------------------------------------

*fourth_map_1
[if exp="f.fourth_map_1==1"]
[jump target="*fourth_map_2]
[else]
[endif]

;//１：校門
[button name="role_button" x="140" y="521" graphic="map/btn_select_11_off.png" enterimg="map/btn_select_11_on.png" clickimg="map/btn_select_11_off.png" target="*fourth_select_1"  enterse="cursor1.ogg" clickse="decision5.ogg" exp="f.fourth_select=f.fourth_select+1"]

*fourth_map_2
[if exp="f.fourth_map_2==1"]
[jump target="*fourth_map_3]
[else]
[endif]

;//２：職員室
[button name="role_button" x="287" y="430" graphic="map/btn_select_03_off.png" enterimg="map/btn_select_03_on.png" clickimg="map/btn_select_03_off.png" target="*fourth_select_2"  enterse="cursor1.ogg" clickse="decision5.ogg" exp="f.fourth_select=f.fourth_select+1"]

*fourth_map_3
[if exp="f.fourth_map_3==1"]
[jump target="*fourth_map_4]
[else]
[endif]

;//３：旧校舎前
[button name="role_button" x="605" y="13" graphic="map/btn_select_08_off.png" enterimg="map/btn_select_08_on.png" clickimg="map/btn_select_08_off.png" target="*fourth_select_3"  enterse="cursor1.ogg" clickse="decision5.ogg" exp="f.fourth_select=f.fourth_select+1"]

*fourth_map_4

;//４：旧校舎の庭園
[button name="role_button" x="752" y="100" graphic="map/btn_select_09_off.png" enterimg="map/btn_select_09_on.png" clickimg="map/btn_select_09_off.png" target="*fourth_select_4"  enterse="cursor1.ogg" clickse="decision5.ogg" exp="f.fourth_select=f.fourth_select+1"]

*fourth_map_5
[if exp="f.fourth_map_5==1"]
[jump target="*fourth_map_6]
[else]
[endif]

;//５：図書館
[button name="role_button" x="902" y="339" graphic="map/btn_select_13_off.png" enterimg="map/btn_select_13_on.png" clickimg="map/btn_select_13_off.png" target="*fourth_select_5"  enterse="cursor1.ogg" clickse="decision5.ogg" exp="f.fourth_select=f.fourth_select+1"]

*fourth_map_6
[if exp="f.fourth_map_6==1"]
[jump target="*fourth_map_7]
[else]
[endif]

;//６：中庭テラス
[button name="role_button" x="378" y="273" graphic="map/btn_select_04_off.png" enterimg="map/btn_select_04_on.png" clickimg="map/btn_select_04_off.png" target="*fourth_select_6"  enterse="cursor1.ogg" clickse="decision5.ogg" exp="f.fourth_select=f.fourth_select+1"]

*fourth_map_7
[if exp="f.fourth_map_7==1"]
[jump target="*fourth_map_8]
[else]
[endif]

;//８：食堂
[button name="role_button" x="508" y="196" graphic="map/btn_select_05_off.png" enterimg="map/btn_select_05_on.png" clickimg="map/btn_select_05_off.png" target="*fourth_select_7"  enterse="cursor1.ogg" clickse="decision5.ogg" exp="f.fourth_select=f.fourth_select+1"]


*fourth_map_8

[showmenubutton]

[s]

;--------------------------------------------------
;//■ルート『首を切っておしまい』
*fourth_select_end
[savetitle text="『首を切っておしまい』"]
;-------------------------------------------------

[bgm_end1]

[vo vo="ep3/alice_0095.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「哈……算了，我已经腻了」[p]
[alice_真顔_c]

#
爱丽丝学姐突然停下脚步说道。[p]

;BGM再生
[bgm ogg="highway.ogg"]

[vo vo="ep3/alice_0096.ogg"]
[alice_怒り]
#【饴宫 爱丽丝】
「回去吧辉夜，继续待在这里也只是浪费时间」[p]
[alice_怒り_c]

[vo vo="ep3/yuzu_0333.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「啊，请、请等一下！」[p]
[yuzuha_驚き_c]

[vo vo="ep3/yuzu_0334.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「谜题已经解开了――」[p]
[yuzuha_驚き_c]

[vo vo="ep3/alice_0097.ogg"]
[alice_怒り]
#【饴宫 爱丽丝】
「我可没空陪你消磨时间，小仓柚叶」[p]

[vo vo="ep3/alice_0098.ogg"]
#【饴宫 爱丽丝】
「真是严重的误会呢……我腻了，你被解雇了」[p]
[alice_怒り_c]

#
说完爱丽丝学姐便转身离去。[p]

;全キャラ削除
[allc]

;//ブラックアウト
[bg10 bg="black.png"]

自那之后，爱丽丝学姐再也没有与我有过任何交集。[p]

[bgm_end1]

;//おわり

;テキストウィンドウ削除
[end_text]


;バッジ獲得用タグ
;[give_emblem id="5346" pid="f15e23aa9846afaa256a22b8ca6fd76e"]

;//ルート『首を切っておしまい』おわり
[eval exp="sf.ep3_end2 = 1"]
[bg  storage="ep3_end_2.jpg" time="2000"]

;処理を停止します
[wa]
[wait time=1000]
[p]

;背景：暗転
[bg30 bg="black.png"]

;タイトル画面へ移動
[jump  storage="title_screen.ks"  target="*title"]

[s]


;--------------------------------------------------
;//選択肢１：校門
*fourth_select_1
[savetitle text="校門"]
;-------------------------------------------------

[eval exp="f.fourth_map_1=1"]

;選択肢ボタンクリア
[bgm_end1]
[cm]
[clearfix]


;//黒ベタ
[bg20 bg="black.png"]

;//校門
[bg10 bg="school_gate.jpg"]

[yuzuha_微笑_c]
[c3_f cg="yuzuha"]

[sayuri_微笑_c]
[c4_f cg="sayuri"]

[alice_笑み_c]
[c2_f cg="alice"]

[kaguya_無表情_c]
[c1 cg="kaguya"]

;BGM再生
[bgm ogg="4656.ogg"]




;テキストウィンドウ表示
[start_text_yuzu]

[vo vo="ep3/yuzu_0335.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「各位，久等了！」[p]
[yuzuha_笑顔_c]

#
抵达地点竟是学校的正门。[p]

[vo vo="ep3/sayu_0151.ogg"]
[sayuri_哀]
#【稻饼 小百合】
「到了……这里，是校门对吧？」[p]
[sayuri_哀_c]

[vo vo="ep3/alice_0099.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「该不会想说这里就是御伽俱乐部的活动场所吧？」[p]
[alice_真顔_c]

#
被爱丽丝学姐这么一说，我不禁畏缩起来。[p]

[vo vo="ep3/sayu_0152.ogg"]
[sayuri_哀]
#【稻饼 小百合】
「这个地方已经确认过了，应该不是吧？」[p]
[sayuri_哀_c]

[vo vo="ep3/yuzu_0336.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「诶——……说、说的也是呢——」[p]
[yuzuha_疑問_c]

#
明明早就从黑十先生那里得到了答案。[p]

或许是太疲倦了，竟犯了这么低级的错误。[p]

[vo vo="ep3/kaguya_0041.ogg"]
[kaguya_呆れ]
#【蓬 辉夜】
「唉……振作点」[p]
[kaguya_呆れ_c]

#
辉夜学姐失望地长叹一声。[p]

[vo vo="ep3/yuzu_0337.ogg"]
[yuzuha_怒鳴る]
#【小仓 柚叶】
「没问题！下次一定会成功！」[p]
[yuzuha_怒鳴る_c]

#
脑海中浮现出黑十先生说过的话。[p]

重要的是要以俯瞰的视角观察。[p]

;//地図画面
;//場所移動の選択肢
[jump target="*fourth_select"]

;--------------------------------------------------
;//選択肢２：職員室
*fourth_select_2
[savetitle text="職員室"]
;-------------------------------------------------

[eval exp="f.fourth_map_2=1"]

;選択肢ボタンクリア
[bgm_end1]
[cm]
[clearfix]


;//黒ベタ
[bg20 bg="black.png"]

;BGM再生
[bgm ogg="4656.ogg"]

;//廊下
[bg10 bg="corridor.jpg"]

[yuzuha_微笑_c]
[c3 cg="yuzuha"]

[sayuri_微笑_c]
[c4 cg="sayuri"]

[alice_笑み_c]
[c2 cg="alice"]

[kaguya_無表情_c]
[c1 cg="kaguya"]

;テキストウィンドウ表示
[start_text_yuzu]

[vo vo="ep3/yuzu_0338.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「各位，我们到了！」[p]
[yuzuha_笑顔_c]

#
来到的地方竟是教员室门前。[p]

[vo vo="ep3/sayu_0153.ogg"]
[sayuri_哀]
#【稻饼 小百合】
「到了......这里是教员室对吧？」[p]
[sayuri_哀_c]

[vo vo="ep3/alice_0100.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「虽然难以置信[r]　
　但你应该不会说这里就是活动场地吧？」[p]
[alice_真顔_c]

#
被爱丽丝学姐这么一说，我不禁畏缩起来。[p]

[vo vo="ep3/yuzu_0339.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「那个...我并没有这个打算...奇怪？」[p]
[yuzuha_疑問_c]

#
为何会来到教员室呢。[p]

[vo vo="ep3/sayu_0154.ogg"]
[sayuri_哀]
#【稻饼 小百合】
「是累了吗？小柚叶，加油！」[p]
[sayuri_哀_c]

#
被这么鼓励着，我也只能报以苦笑。[p]

但正如小百合小姐所说必须重新振作起来。[p]

[vo vo="ep3/kaguya_0042.ogg"]
[kaguya_呆れ]
#【蓬 辉夜】
「唉……振作点」[p]
[kaguya_呆れ_c]

#
辉夜学姐失望地长叹一声。[p]

[vo vo="ep3/yuzu_0340.ogg"]
[yuzuha_怒鳴る]
#【小仓 柚叶】
「没问题！下次一定会成功！」[p]
[yuzuha_怒鳴る_c]

#
脑海中浮现出黑十先生说过的话。[p]

重要的是要以俯瞰的视角观察。[p]

;//地図画面
;//場所移動の選択肢
[jump target="*fourth_select"]


;--------------------------------------------------
;//選択肢３：旧校舎前
*fourth_select_3
[savetitle text="旧校舎前"]
;-------------------------------------------------

[eval exp="f.fourth_map_3=1"]

;選択肢ボタンクリア
[bgm_end1]
[cm]
[clearfix]


;//黒ベタ
[bg20 bg="black.png"]

;BGM再生
[bgm ogg="4656.ogg"]

;//旧校舎前
[bg10 bg="garden_1.jpg"]

[yuzuha_微笑_c]
[c3_f cg="yuzuha"]

[sayuri_微笑_c]
[c4_f cg="sayuri"]

[alice_笑み_c]
[c2_f cg="alice"]

[kaguya_無表情_c]
[c1 cg="kaguya"]

;テキストウィンドウ表示
[start_text_yuzu]

[vo vo="ep3/yuzu_0341.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「请看！我们到了！」[p]
[yuzuha_笑顔_c]

#
最终抵达的是旧校舍前。[p]

[vo vo="ep3/sayu_0155.ogg"]
[sayuri_哀]
#【稻饼 小百合】
「到了......这里是旧校舍对吧？」[p]
[sayuri_哀_c]

[vo vo="ep3/yuzu_0342.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「没错！正是旧校舍！」[p]
[yuzuha_笑顔_c]

[vo vo="ep3/alice_0101.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「那具体在旧校舍哪里？」[p]
[alice_真顔_c]

[vo vo="ep3/yuzu_0343.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「……咦？」[p]
[yuzuha_驚き_c]

[vo vo="ep3/alice_0102.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「难不成你想说我们此刻站的地方[r]　
　就是御伽俱乐部的活动场所？」[p]
[alice_真顔_c]

[vo vo="ep3/sayu_0156.ogg"]
[sayuri_驚き]
#【稻饼 小百合】
「咦？就是这里吗？」[p]
[sayuri_驚き_c]

#
被爱丽丝学姐和小百合小姐质问，我不由得缩了缩脖子。[p]

[vo vo="ep3/yuzu_0344.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「不是的...并非如此...那个」[p]
[yuzuha_哀_c]

[vo vo="ep3/alice_0103.ogg"]
[alice_怒り]
#【饴宫 爱丽丝】
「那为什么要把我带到这里来啊」[p]
[alice_怒り_c]

#
我无言以对。[p]

[vo vo="ep3/kaguya_0043.ogg"]
[kaguya_呆れ]
#【蓬 辉夜】
「唉……振作点」[p]
[kaguya_呆れ_c]

#
辉夜学姐失望地长叹一声。[p]

必须像辉夜前辈说的那样振作起来。[p]

[vo vo="ep3/yuzu_0345.ogg"]
[yuzuha_怒鳴る]
#【小仓 柚叶】
「没问题！下次一定会成功！」[p]
[yuzuha_怒鳴る_c]

#
脑海中浮现出黑十先生说过的话。[p]

重要的是要以俯瞰的视角观察。[p]

;//地図画面
;//場所移動の選択肢
[jump target="*fourth_select"]


;--------------------------------------------------
;//選択肢５：図書館
*fourth_select_5
[savetitle text="図書館"]
;-------------------------------------------------

[eval exp="f.fourth_map_5=1"]

;選択肢ボタンクリア
[bgm_end1]
[cm]
[clearfix]


;//黒ベタ
[bg20 bg="black.png"]

;BGM再生
[bgm ogg="4656.ogg"]

;//図書館
[bg10 bg="library.jpg"]

[yuzuha_微笑_c]
[c3_f cg="yuzuha"]

[sayuri_微笑_c]
[c4_f cg="sayuri"]

[alice_笑み_c]
[c2_f cg="alice"]

[kaguya_無表情_c]
[c1 cg="kaguya"]

;テキストウィンドウ表示
[start_text_yuzu]

[vo vo="ep3/yuzu_0346.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「终于到了！就是这里！」[p]
[yuzuha_笑顔_c]

#
边说边来到的地方竟然是图书馆。[p]

[vo vo="ep3/sayu_0157.ogg"]
[sayuri_哀]
#【稻饼 小百合】
「到了……这里、是图书馆吧？」[p]
[sayuri_哀_c]

[vo vo="ep3/yuzu_0347.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「嗯，原来我们学校的图书馆长这样啊，我还是第一次来呢」[p]
[yuzuha_笑顔_c]

[vo vo="ep3/kaguya_0044.ogg"]
[kaguya_無表情]
#【蓬 辉夜】
「也是呢」[p]
[kaguya_無表情_c]

[vo vo="ep3/yuzu_0348.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「…………」[p]
[yuzuha_笑顔_c]

#
咦？我刚才被当成笨蛋了？[p]

[vo vo="ep3/alice_0104.ogg"]
[alice_驚き]
#【饴宫 爱丽丝】
「辉夜、真有你的」[p]
[alice_驚き_c]

#
爱丽丝前辈也表示佩服。[p]

[vo vo="ep3/kaguya_0045.ogg"]
[kaguya_無表情]
#【蓬 辉夜】
「比起这个，你说这里是御伽俱乐部的活动地点？」[p]
[kaguya_無表情_c]

[vo vo="ep3/yuzu_0349.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「那个……嗯？」[p]
[yuzuha_疑問_c]

[vo vo="ep3/alice_0105.ogg"]
[alice_怒り]
#【饴宫 爱丽丝】
「该不会是没考虑清楚就带我们来了吧？」[p]
[alice_怒り_c]

[vo vo="ep3/yuzu_0350.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「不是……那个……」[p]
[yuzuha_哀_c]

#
被爱丽丝学姐这么一说，我不禁畏缩起来。[p]

[vo vo="ep3/sayu_0158.ogg"]
[sayuri_哀]
#【稻饼 小百合】
「小柚叶、弄错了的话就老实道歉吧？」[p]
[sayuri_哀_c]

#
小百合小姐小声给我建议。[p]

[vo vo="ep3/yuzu_0351.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「对、对不起……能不能再给次机会……」[p]
[yuzuha_哀_c]

[vo vo="ep3/alice_0106.ogg"]
[alice_ドヤ顔]
#【饴宫 爱丽丝】
「真拿你没办法，感谢宽宏大量的我吧」[p]
[alice_ドヤ顔_c]

#
爱丽丝前辈打心底高兴地说道。[p]

[vo vo="ep3/kaguya_0046.ogg"]
[kaguya_呆れ]
#【蓬 辉夜】
「唉……振作点」[p]
[kaguya_呆れ_c]

[vo vo="ep3/yuzu_0352.ogg"]
[yuzuha_怒鳴る]
#【小仓 柚叶】
「没问题！下次一定会成功！」[p]
[yuzuha_怒鳴る_c]

#
脑海中浮现出黑十先生说过的话。[p]

重要的是要以俯瞰的视角观察。[p]

[eval exp="f.fourth_select=1"]

;//地図画面
;//場所移動の選択肢
[jump target="*fourth_select"]


;--------------------------------------------------
;//選択肢６：中庭テラス
*fourth_select_6
[savetitle text="中庭テラス"]
;-------------------------------------------------

[eval exp="f.fourth_map_6=1"]

;選択肢ボタンクリア
[bgm_end1]
[cm]
[clearfix]


;//黒ベタ
[bg20 bg="black.png"]

;BGM再生
[bgm ogg="4656.ogg"]

;//中庭テラス
[bg10 bg="terrace.jpg"]

[yuzuha_微笑_c]
[c3_f cg="yuzuha"]

[sayuri_微笑_c]
[c4_f cg="sayuri"]

[alice_笑み_c]
[c2_f cg="alice"]

[kaguya_無表情_c]
[c1 cg="kaguya"]

;テキストウィンドウ表示
[start_text_yuzu]

[vo vo="ep3/yuzu_0353.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「各位请看这个地方！」[p]
[yuzuha_笑顔_c]

#
说着我站到了中庭的露台上。[p]

[vo vo="ep3/sayu_0159.ogg"]
[sayuri_哀]
#【稻饼 小百合】
「请看……这里、是中庭、对吧？」[p]
[sayuri_哀_c]

[vo vo="ep3/alice_0107.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「什么嘛，还以为要带我们去哪儿，结果不还是这个地方」[p]

[vo vo="ep3/alice_0108.ogg"]
#【饴宫 爱丽丝】
「虽然觉得不太可能……你该不会想说这里就是御伽俱乐部的活动地点吧？」[p]
[alice_真顔_c]

#
被爱丽丝学姐这么一说，我不禁畏缩起来。[p]

[vo vo="ep3/yuzu_0354.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「不，那个…呃…」[p]
[yuzuha_哀_c]

[vo vo="ep3/alice_0109.ogg"]
[alice_ドヤ顔]
#【饴宫 爱丽丝】
「真的！？　这可是重大发现，[r]　
　没想到御伽俱乐部居然在这里活动！」[p]
[alice_ドヤ顔_c]

[vo vo="ep3/yuzu_0355.ogg"]
[yuzuha_怒鳴る]
#【小仓 柚叶】
「不对真的拜托别这样这里看起来完全不像啊！」[p]
[yuzuha_怒鳴る_c]

#
我慌忙向夸张地发出惊叹的爱丽丝前辈道歉。[p]

[vo vo="ep3/kaguya_0047.ogg"]
[kaguya_呆れ]
#【蓬 辉夜】
「唉……振作点」[p]
[kaguya_呆れ_c]

#
辉夜学姐失望地长叹一声。[p]

[vo vo="ep3/yuzu_0356.ogg"]
[yuzuha_怒鳴る]
#【小仓 柚叶】
「没问题！下次一定会成功！」[p]
[yuzuha_怒鳴る_c]

#
脑海中浮现出黑十先生说过的话。[p]

重要的是要以俯瞰的视角观察。[p]

;//地図画面
;//場所移動の選択肢
[jump target="*fourth_select"]


;--------------------------------------------------
;//選択肢７：食堂
*fourth_select_7
[savetitle text="食堂"]
;-------------------------------------------------

[eval exp="f.fourth_map_7=1"]

;選択肢ボタンクリア
[bgm_end1]
[cm]
[clearfix]


;//黒ベタ
[bg20 bg="black.png"]


;BGM再生
[bgm ogg="4656.ogg"]
;//食堂
[bg10 bg="cafeteria.jpg"]

[yuzuha_微笑_c]
[c3_f cg="yuzuha"]

[sayuri_微笑_c]
[c4_f cg="sayuri"]

[alice_笑み_c]
[c2_f cg="alice"]

[kaguya_無表情_c]
[c1 cg="kaguya"]

;テキストウィンドウ表示
[start_text_yuzu]

[vo vo="ep3/yuzu_0357.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「各位，我们到了！」[p]
[yuzuha_笑顔_c]

#
到达的地方是学生食堂。[p]

[vo vo="ep3/sayu_0160.ogg"]
[sayuri_哀]
#【稻饼 小百合】
「你说到了……这里，是食堂吧？」[p]
[sayuri_哀_c]

[vo vo="ep3/yuzu_0358.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「没错！而且这间食堂的咖喱真的很推荐！」[p]
[yuzuha_笑顔_c]

[vo vo="ep3/alice_0110.ogg"]
[alice_怒り]
#【饴宫 爱丽丝】
「咖喱什么的根本不重要现在请说御伽俱乐部的事」[p]

[vo vo="ep3/alice_0111.ogg"]
#【饴宫 爱丽丝】
「该不会想说这里就是御伽俱乐部的活动场所吧？」[p]
[alice_怒り_c]

#
被爱丽丝学姐这么一说，我不禁畏缩起来。[p]

[vo vo="ep3/yuzu_0359.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「不是…倒也不是这个意思…」[p]
[yuzuha_哀_c]

[vo vo="ep3/alice_0112.ogg"]
[alice_怒り]
#【饴宫 爱丽丝】
「那为什么要把我带到这里来啊」[p]
[alice_怒り_c]

[vo vo="ep3/yuzu_0360.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「不，主要是想顺便介绍一下这里的咖喱很好吃…对不起」[p]
[yuzuha_哀_c]

[vo vo="ep3/kaguya_0048.ogg"]
[kaguya_呆れ]
#【蓬 辉夜】
「唉……振作点」[p]
[kaguya_呆れ_c]

#
辉夜学姐失望地长叹一声。[p]

[vo vo="ep3/yuzu_0361.ogg"]
[yuzuha_怒鳴る]
#【小仓 柚叶】
「没问题！下次一定会成功！」[p]
[yuzuha_怒鳴る_c]

#
脑海中浮现出黑十先生说过的话。[p]

重要的是要以俯瞰的视角观察。[p]

;//地図画面
;//場所移動の選択肢
[jump target="*fourth_select"]


;-------------------------------------------------
;//選択肢４：旧校舎の庭園
*fourth_select_4
[savetitle text="旧校舎の庭園"]
;-------------------------------------------------

;選択肢ボタンクリア
[bgm_end1]
[cm]
[clearfix]


;//黒ベタ
[bg20 bg="black.png"]


[bgm_end1]

;//旧校舎の庭園
[bg10 bg="garden_2.jpg"]

[yuzuha_微笑_c]
[c3_f cg="yuzuha"]

[sayuri_微笑_c]
[c4_f cg="sayuri"]

[alice_笑み_c]
[c2_f cg="alice"]

[kaguya_無表情_c]
[c1 cg="kaguya"]

;テキストウィンドウ表示
[start_text_yuzu]

[vo vo="ep3/yuzu_0362.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「各位，我们到了！」[p]
[yuzuha_笑顔_c]

;BGM再生
[bgm ogg="urara.ogg"]

#
抵达的是旧校舍。[p]

是它的庭园。[p]

[vo vo="ep3/sayu_0161.ogg"]
[sayuri_哀]
#【稻饼 小百合】
「到了…难道说这里就是？」[p]
[sayuri_哀_c]

[vo vo="ep3/yuzu_0363.ogg"]
[yuzuha_怒鳴る]
#【小仓 柚叶】
「没错，这里就是御伽俱乐部的活动场所！」[p]
[yuzuha_怒鳴る_c]

#
话音刚落，在场所有人都不约而同环视四周。[p]

[vo vo="ep3/alice_0113.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「稍等，你这样判断的依据是？」[p]

[vo vo="ep3/alice_0114.ogg"]
;//読み方『学園の□』→暗号
#【饴宫 爱丽丝】
「为什么能断定我交给你的『学园之□』指向的就是这里？」[p]
[alice_真顔_c]

#
于是爱丽丝前辈替所有人说出了心中的疑问。[p]

我必须回答这个问题。[p]

[yuzuha_微笑_c]
我缓缓地定了定神，一边回想起刚才[r]　
黑十先生给出的回答，一边开始讲述。[p]

[vo vo="ep3/yuzu_0364.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「爱丽丝前辈，那个暗号该怎么读呢？」[p]
[yuzuha_微笑_c]

[vo vo="ep3/alice_0115.ogg"]
[alice_疑問]
;//読み方【口】→くち
#【饴宫 爱丽丝】
「那是……学园的……口？」[p]
[alice_疑問_c]

[vo vo="ep3/yuzu_0365.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「原来如此，说得对」[p]

[vo vo="ep3/yuzu_0366.ogg"]
#【小仓 柚叶】
「我们最初也是这么读着寻找御伽俱乐部的活动场所」[p]
[yuzuha_微笑_c]

[vo vo="ep3/sayu_0162.ogg"]
[sayuri_哀]
#【稻饼 小百合】
「不过那不是搞错了吗？」[p]
[sayuri_哀_c]

[vo vo="ep3/yuzu_0367.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「嗯，不对」[p]

[vo vo="ep3/yuzu_0368.ogg"]
#【小仓 柚叶】
「那个单词不是念作『口』」[p]

[vo vo="ep3/yuzu_0369.ogg"]
;//読み方『学園の□』→学園のしかく
#【小仓 柚叶】
「它真正的读法是，四角……『学园的□』」[p]
[yuzuha_微笑_c]

[vo vo="ep3/kaguya_0049.ogg"]
[kaguya_思考]
#【蓬 辉夜】
「四角……不是死角而是正方形？」[p]
[kaguya_思考_c]

[vo vo="ep3/yuzu_0370.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「是的，没错！」[p]
[yuzuha_笑顔_c]

[vo vo="ep3/kaguya_0050.ogg"]
[kaguya_無表情]
#【蓬 辉夜】
「「可是怎么就能断定是这个地方呢」」[p]
[kaguya_無表情_c]

[vo vo="ep3/yuzu_0371.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「「因为除此之外不存在」」[p]
[yuzuha_微笑_c]

[vo vo="ep3/kaguya_0051.ogg"]
[kaguya_思考]
#【蓬 辉夜】
「「不存在……什么意思？」」[p]
[kaguya_思考_c]

[vo vo="ep3/yuzu_0372.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「「只要俯瞰就能明白」」[p]

[vo vo="ep3/yuzu_0373.ogg"]
#【小仓 柚叶】
「「请看学生手册上记载的地图」」[p]

[vo vo="ep3/yuzu_0374.ogg"]
#【小仓 柚叶】
「「啊、如果没有用手机地图也行哦」」[p]
[yuzuha_微笑_c]

#
听了我的话 所有人都掏出学生手册凝视着[p]

然后――[p]

[vo vo="ep3/alice_0116.ogg"]
[alice_ドヤ顔]
#【饴宫 爱丽丝】
「「…………哼嗯」」[p]
[alice_ドヤ顔_c]

[vo vo="ep3/kaguya_0052.ogg"]
[kaguya_悪い笑顔]
#【蓬 辉夜】
「「原来如此……被摆了一道呢」」[p]
[kaguya_悪い笑顔_c]

#
看样子这两人立刻就察觉到了[p]

[vo vo="ep3/sayu_0163.ogg"]
[sayuri_哀]
#【稻饼 小百合】
「「诶？对不起　什么意思？」」[p]
[sayuri_哀_c]

#
然而似乎只有小百合小姐还没明白。[p]

确实这类事情或许是难为小百合小姐了。[p]

[vo vo="ep3/yuzu_0375.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「仔细看小百合小姐，只有这旧校舍的庭园……」[p]
[yuzuha_微笑_c]

[vo vo="ep3/sayu_0164.ogg"]
[sayuri_驚き]
#【稻饼 小百合】
「……啊、真的！[r]　
　唯独这个地方从上面看是完美的正方形！」[p]
[sayuri_驚き_c]

[vo vo="ep3/yuzu_0376.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「没错，只有这里是规整的正方形！」[p]

[vo vo="ep3/yuzu_0377.ogg"]
;//読み方『学園の□』→学園のしかく
#【小仓 柚叶】
「也就是说字面意思……御伽俱乐部的活动场所就是『学院的□』！！」[p]
[yuzuha_笑顔_c]

[vo vo="ep3/kaguya_0053.ogg"]
[kaguya_無表情]
#【蓬 辉夜】
「不从上方观察就无法察觉……既是四方，亦是死角呢」[p]
[kaguya_無表情_c]

[vo vo="ep3/alice_0117.ogg"]
[alice_呆れ]
#【饴宫 爱丽丝】
「谁让你耍嘴皮子了」[p]
[alice_呆れ_c]

[bgm_end2]

[kill]

[alice_笑み_c]
[ce cg="alice"]

#
一边说着无趣的话语，[r]　
爱丽丝前辈开始环视庭园像在搜寻什么。[p]

[vo vo="ep3/alice_0118.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「……找到了，肯定是这里」[p]
[alice_真顔_c]

#
爱丽丝前辈脚边有个用砖块砌成的花坛。[p]

[vo vo="ep3/alice_0119.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「看啊，只有这块砖是方形的对吧」[p]
[alice_真顔_c]

#
被这么一说才注意到，长方形的砖块中混着一块规整的正方形。[p]

[kill]

[yuzuha_疑問_c]
[lec_f cg="yuzuha"]

[alice_真顔_c]
[ric cg="alice"]

[vo vo="ep3/yuzu_0378.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「这个，是什么？」[p]
[yuzuha_疑問_c]

[vo vo="ep3/alice_0120.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「别管那么多快挖开下面」[p]
[alice_真顔_c]

[vo vo="ep3/yuzu_0379.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「诶？要我挖吗？」[p]
[yuzuha_驚き_c]

[vo vo="ep3/alice_0121.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「理所当然吧……快点动手」[p]
[alice_真顔_c]

[yuzuha_哀_c]

#
她优雅地扬起线条优美的下巴催促着。[p]

无奈之下我按照指示检查了砖块下方。[p]

[yuzuha_驚き_c]

掘开泥土后很快触到了硬物。[p]

出现的是一只小箱子。[p]

[vo vo="ep3/yuzu_0380.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「这是什么？」[p]
[yuzuha_疑問_c]

[vo vo="ep3/alice_0122.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「别管了赶紧打开」[p]
[alice_真顔_c]

[vo vo="ep3/yuzu_0381.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「真是的……使唤人还真狠呢」[p]
[yuzuha_哀_c]

#
轻轻拂去箱子上附着的泥土后，打开了箱子。[p]

;カットイン表示
[cut_in cut="cut_pendant.png"]


[yuzuha_驚き_c]
里面装着的是一条小小的吊坠。[p]

;BGM再生
[bgm ogg="you_are_precious.ogg"]

[vo vo="ep3/alice_0123.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「终于找到了」[p]
[alice_真顔_c]

[vo vo="ep3/yuzu_0382.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「……咦？」[p]
[yuzuha_驚き_c]

;カットイン削除
[cut_out]

[eval exp="sf.cg_ep3_2 = 1"]
[event_in event="ep3_1"]

#
爱丽丝前辈说着便将吊坠拿在手中。[p]

既然说终于找到了，[r]　
难道从一开始爱丽丝前辈的目标就是这条吊坠吗。[p]

但看她的表情却异常平静，实在有些蹊跷。[p]



[kill]

[yuzuha_驚き_c]
[c3_f cg="yuzuha"]

[sayuri_微笑_c]
[c4_f cg="sayuri"]

[alice_笑み_c]
[c2_f cg="alice"]

[kaguya_無表情_c]
[c1 cg="kaguya"]

[vo vo="ep3/sayu_0165.ogg"]
[sayuri_哀]
#【稻饼 小百合】
「一直有个疑问，[r]　
　为什么爱丽丝前辈会拿着写有御伽俱乐部活动场所的纸条呢？」[p]
[sayuri_哀_c]

[vo vo="ep3/yuzu_0383.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「啊、说起来确实……」[p]
[yuzuha_驚き_c]

[vo vo="ep3/alice_0124.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「因为御伽俱乐部的创始人，是我的血亲啊」[p]

[vo vo="ep3/alice_0125.ogg"]
#【饴宫 爱丽丝】
「御伽俱乐部原本[r]　
　是只允许上流阶层部分被选中之人参与的集会」[p]

[vo vo="ep3/alice_0126.ogg"]
#【饴宫 爱丽丝】
「据说会干涉学院的运营方针，还会举办豪华派对什么的」[p]

[vo vo="ep3/alice_0127.ogg"]
#【饴宫 爱丽丝】
「放在现在根本没法想象的、超级豪华的那种哦」[p]
[alice_真顔_c]

[vo vo="ep3/yuzu_0384.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「呜诶~原来以前还有这种超高级俱乐部啊」[p]
[yuzuha_驚き_c]

[vo vo="ep3/alice_0128.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「不过随着时代变迁俱乐部就自然消亡了」[p]

[vo vo="ep3/alice_0129.ogg"]
#【饴宫 爱丽丝】
「于是唯有传闻被煞有介事地低语着，[r]　
　如今连那都已不复存在了」[p]

[vo vo="ep3/alice_0130.ogg"]
#【饴宫 爱丽丝】
「为了确认其存在，我向这所学院的毕业生[r]　
　亦即曾是御伽俱乐部会员的祖母打听，得到了这份笔记哦」[p]
[alice_真顔_c]

[event_out]

[vo vo="ep3/yuzu_0385.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「原来如此……咦？[r]　
　但这样的话直接向那位老太太请教密码的含义不就好了吗？」[p]
[yuzuha_疑問_c]

[vo vo="ep3/alice_0131.ogg"]
[alice_呆れ]
#【饴宫 爱丽丝】
「哈……能这么办我就不用苦恼了」[p]
[alice_呆れ_c]

[vo vo="ep3/yuzu_0386.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「哎？啊……糟了……」[p]
[yuzuha_哀_c]

#
脑海中浮现出无法询问的理由，气氛略显尴尬。[p]

[vo vo="ep3/alice_0132.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「你擅自误会什么呀？她还健在啦」[p]
[alice_真顔_c]

#
看来老人家明明活得好好的。[p]

[vo vo="ep3/alice_0133.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「只是她只肯透露提示，关键部分死活不肯说」[p]

[vo vo="ep3/alice_0134.ogg"]
#【饴宫 爱丽丝】
「是个性格超级别扭的老太太呢，[r]　
　喜欢看别人困扰的恶趣味之人哦」[p]
[alice_真顔_c]

[vo vo="ep3/kaguya_0054.ogg"]
[kaguya_無表情]
#【蓬 辉夜】
「你这性格算是隔代遗传吧」[p]
[kaguya_無表情_c]

[vo vo="ep3/alice_0135.ogg"]
[alice_ドヤ顔]
#【饴宫 爱丽丝】
「你说了什么吗？」[p]
[alice_ドヤ顔_c]

[vo vo="ep3/kaguya_0055.ogg"]
[kaguya_悪い笑顔]
#【蓬 辉夜】
「没什么」[p]
[kaguya_悪い笑顔_c]

[vo vo="ep3/sayu_0166.ogg"]
[sayuri_呆れ]
#【稻饼 小百合】
「啊，哈哈哈……」[p]
[sayuri_呆れ_c]

[kaguya_無表情_c]

[vo vo="ep3/alice_0136.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「而这条吊坠，正是御伽俱乐部会长曾持有的物品」[p]

[vo vo="ep3/alice_0137.ogg"]
#【饴宫 爱丽丝】
「我在照片上见过所以不会错」[p]
[alice_真顔_c]

[vo vo="ep3/yuzu_0387.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「那么它出现在这里就意味着，[r]　
　御伽俱乐部确实真实存在过对吧！」[p]
[yuzuha_微笑_c]

[vo vo="ep3/alice_0138.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「嗯，正是如此」[p]
[alice_真顔_c]

[vo vo="ep3/yuzu_0388.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「啊……您从刚才开始是不是莫名情绪低落？」[p]

[vo vo="ep3/yuzu_0389.ogg"]
#【小仓 柚叶】
「好不容易找到的说」[p]
[yuzuha_疑問_c]

[vo vo="ep3/alice_0139.ogg"]
[alice_怒り]
#【饴宫 爱丽丝】
「哈啊……我说啊、我其实[r]　
　对御伽俱乐部是否真的存在这种事情根本无所谓」[p]

[vo vo="ep3/alice_0140.ogg"]
#【饴宫 爱丽丝】
「我真正的目的是……[r]　
　维持高级俱乐部运营并延续至今的那笔资金」[p]
[alice_怒り_c]

[vo vo="ep3/kaguya_0056.ogg"]
[kaguya_無表情]
#【蓬 辉夜】
「果然是这样呢……[r]　
　也就是说你盯上了黑金对吧」[p]
[kaguya_無表情_c]

[vo vo="ep3/yuzu_0390.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「诶！？原来是这样吗！？」[p]
[yuzuha_驚き_c]

[vo vo="ep3/alice_0141.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「谁知道呢、但没想到只有这个寒酸的小吊坠」[p]
[alice_真顔_c]

#
爱丽丝前辈用手指捻着吊坠转圈、叹了口气。[p]

和我一样、爱丽丝前辈也是富豪千金。[p]

她肯定不是冲着钱财、[r]　
只是想把祖母藏起来的东西据为己有吧。[p]

[vo vo="ep3/alice_0142.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「说不定早就被人拿走了、[r]　
　毕竟是很久以前的事了」[p]
[alice_真顔_c]

[vo vo="ep3/sayu_0167.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「那个某人该不会是……」[p]
[sayuri_微笑_c]

[vo vo="ep3/yuzu_0391.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「嗯、可能就是那位老奶奶」[p]
[yuzuha_微笑_c]

#
和小百合小姐不约而同露出了苦笑。[p]

[vo vo="ep3/kaguya_0057.ogg"]
[kaguya_無表情]
#【蓬 辉夜】
「不过你们两个可真是被使唤得团团转呢」[p]

[vo vo="ep3/kaguya_0058.ogg"]
#【蓬 辉夜】
「明明提醒过你要小心爱丽丝的」[p]
[kaguya_無表情_c]

[vo vo="ep3/yuzu_0392.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「啊哈哈、不过能揭开御伽俱乐部的谜团也不错啦」[p]

[vo vo="ep3/yuzu_0393.ogg"]
#【小仓 柚叶】
「这样就不用再去参加什么茶会了」[p]
[yuzuha_微笑_c]

[vo vo="ep3/alice_0143.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「唉……连赃款都没有……有趣的小玩具也被没收了呢」[p]
[alice_真顔_c]

[vo vo="ep3/yuzu_0394.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「您已经不打算掩饰那个性格了呢……」[p]
[yuzuha_哀_c]

[vo vo="ep3/alice_0144.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「哎呀，我有在掩饰的打算吗？」[p]
[alice_笑み_c]

#
平时或许是爱丽丝前辈的外貌和[r]　
周围孩子们憧憬的目光掩盖了她那样的性格。[p]

[vo vo="ep3/yuzu_0395.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「总之这次胜负是我赢了，拜托了哦？」[p]
[yuzuha_微笑_c]

[vo vo="ep3/alice_0145.ogg"]
[alice_呆れ]
#【饴宫 爱丽丝】
「好好，没办法只能放弃啦」[p]
[alice_呆れ_c]

[vo vo="ep3/yuzu_0396.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「啊，对了，那个吊坠……可以借我吗？」[p]
[yuzuha_微笑_c]

[vo vo="ep3/alice_0146.ogg"]
[alice_疑問]
#【饴宫 爱丽丝】
「可以是可以，但这种东西能做什么？[r]　
　又不是多值钱的玩意儿」[p]
[alice_疑問_c]

#
爱丽丝前辈近乎随手地把吊坠抛给我。[p]

[vo vo="ep3/yuzu_0397.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「不，因为有位可能会喜欢这种东西的人」[p]
[yuzuha_微笑_c]

[vo vo="ep3/alice_0147.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「哼嗯……话说我累了，辉夜，回去了」[p]
[alice_真顔_c]

;SE：
[se_f se="footstep_room_out.ogg"]

;キャラ消去
[chara_hide name=alice]

[vo vo="ep3/kaguya_0059.ogg"]
[kaguya_無表情]
#【蓬 辉夜】
「不用你说也会这么做」[p]
[kaguya_無表情_c]

;//時間経過・場面移動

;全キャラ削除
[allc]

;//黒ベタ
[bg10 bg="black.png"]

#
就这样两人离开了现场。[p]

随后我和小百合小姐也跟了上去。[p]

;//旧校舎の庭園
[bg10 bg="school_gate.jpg"]

[yuzuha_微笑_c]
[lec_f cg="yuzuha"]

[sayuri_微笑_c]
[ric cg="sayuri"]

[vo vo="ep3/yuzu_0398.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「小百合小姐，谢谢你陪我到这么晚」[p]
[yuzuha_微笑_c]

[vo vo="ep3/sayu_0168.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「没事，小柚叶也辛苦啦」[p]
[sayuri_微笑_c]

#
正如小百合小姐所言，[r]　
总觉得今天似乎累得够呛。[p]

不过这样反倒肯定能睡个好觉。[p]

我凝视着手心里的吊坠。[p]

御伽俱乐部的吊坠。[p]

真想快点让黑十先生听听这个故事。[p]

[vo vo="ep3/yuzu_0399.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「会露出什么表情呢……呵呵呵」[p]
[yuzuha_笑顔_c]

#
想象着那副表情，脚步不知不觉轻快了起来。[p]

[bgm_end2]


;//時間経過
;テキストウィンドウ削除
[end_text]

;全キャラ削除
[allc]

;//黒ベタ
[bg10 bg="black.png"]

;//停止
[wait time=2000]

;--------------------------------------------------
*014000
[savetitle text="見つかったペンダント"]
;-------------------------------------------------
;//黒十骨董品店
[bg10 bg="antique.jpg"]

;BGM再生
[bgm ogg="mid_re.ogg"]

[kokutou_微笑_c]
[ric_f cg="kokutou"]

[yuzuha_微笑_c]
[lec cg="yuzuha"]

;テキストウィンドウ表示
[start_text]

;//黒十視点

[vo vo="ep3/koku_0079.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「那么，所谓找到的吊坠就是这个吗」[p]
[kokutou_真顔_c]

;カットイン表示
[cut_in cut="cut_pendant_2.png"]

#
凝视着刚刚接过的吊坠。[p]

[vo vo="ep3/yuzu_0400.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「是的！那可是费尽千辛万苦才找到的宝贝啊！」[p]
[yuzuha_笑顔_c]

[vo vo="ep3/koku_0080.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「哈哈，看起来确实如此呢」[p]
[kokutou_微笑_c]

[vo vo="ep3/yuzu_0401.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「不不，这可不是能笑着带过的辛苦程度啊——！」[p]

[vo vo="ep3/yuzu_0402.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「不过据爱丽丝前辈说[r]　
　好像不是什么贵重物品……您觉得呢？」[p]
[yuzuha_微笑_c]

;カットイン削除
[cut_out]

[vo vo="ep3/koku_0081.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「的确像是这样呢」[p]

[vo vo="ep3/koku_0082.ogg"]
#【黒十 美鹤】
「这并非什么品牌商品[r]　
　像是定制品」[p]

[vo vo="ep3/koku_0083.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「虽然设计简约，但连细节部分都做得相当精致」[p]

[vo vo="ep3/koku_0084.ogg"]
#【黒十 美鹤】
「首先保存状态就非常好」[p]

[vo vo="ep3/koku_0085.ogg"]
#【黒十 美鹤】
「根据描述应该是相当古老的物件吧？」[p]

[vo vo="ep3/koku_0086.ogg"]
#【黒十 美鹤】
「明明世代传承却丝毫没有褪色……！」[p]

[vo vo="ep3/koku_0087.ogg"]
#【黒十 美鹤】
「由此可见历任持有者们[r]　
　是多么珍视这枚吊坠！」[p]
[kokutou_微笑_c]

[vo vo="ep3/yuzu_0403.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「那个——黑十先生……这要变成长篇大论了吗？」[p]
[yuzuha_哀_c]

[vo vo="ep3/koku_0088.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「作为古董爱好者的一员[r]　
　这份心意我确确实实接收到了！」[p]

[vo vo="ep3/koku_0089.ogg"]
#【黒十 美鹤】
「请务必让我也参与保养和检查！」[p]
[kokutou_微笑_c]

[vo vo="ep3/yuzu_0404.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「哈……又是这个……我去泡咖啡吧」[p]
[yuzuha_哀_c]

[vo vo="ep3/koku_0090.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「咦？啊、啊啊不好意思……」[p]
[kokutou_真顔_c]

#
看来我又不知不觉间太投入了。[p]

[vo vo="ep3/yuzu_0405.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「啊、对了……忘记把这个交给你了」[p]
[yuzuha_微笑_c]

#
说着柚叶君掏出来的东西是――[p]

;カットイン表示
[cut_in cut="cut_dora1.png"]

[vo vo="ep3/koku_0091.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「哇哦！黑糖铜锣烧！！」[p]
[kokutou_驚き_c]

#
正是我那独一无二最爱的铜锣烧。[p]

[vo vo="ep3/koku_0092.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「真的可以收下吗？」[p]
[kokutou_微笑_c]

;カットイン削除
[cut_out]

[vo vo="ep3/yuzu_0406.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「嘿嘿，是谢礼所以请别客气」[p]
[yuzuha_笑顔_c]

;SE：
[se_f se="footsteps_out.ogg"]

[kill]

[kokutou_微笑_c]
[ce cg="kokutou"]

#
柚叶君笑着消失在厨房里。[p]

我拿起一个咬下去。[p]

[vo vo="ep3/koku_0093.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「……嗯，果然很好吃」[p]
[kokutou_微笑_c]

#
能感受到全身细胞都在为这高雅的甜味欢呼雀跃。[p]

[bgm_end2]

[vo vo="ep3/koku_0094.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「对了……趁现在把挂坠擦干净吧」[p]
[kokutou_真顔_c]

#
这么想着盯住挂坠时，突然注意到。[p]

[vo vo="ep3/koku_0095.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「这莫非是……火箭挂坠？」[p]
[kokutou_疑問_c]

#
都怪设计过于简洁才没发现。[p]

这个挂坠的装饰部分居然能开合。[p]

而里面藏着一张折叠的纸。[p]

上面整整齐齐写着外国银行名称和疑似账号的数字。[p]

[vo vo="ep3/koku_0096.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「说起来刚才提到什么秘密资金来着……唔」[p]
[kokutou_疑問_c]

;BGM再生
[bgm ogg="renge.ogg"]

#
短暂思考后立即打断思绪。[p]

[vo vo="ep3/koku_0097.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「再妄加揣测就太不解风情了吧」[p]
[kokutou_真顔_c]

#
这枚吊坠被主人们珍视传承，因而美丽。[p]

仅此就足以让它成为无可挑剔的珍品。[p]

[kill]

[yuzuha_微笑_c]
[lec_f cg="yuzuha"]

[kokutou_微笑_c]
[ric cg="kokutou"]

[vo vo="ep3/yuzu_0407.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「黑十先生，咖啡泡好了哦……那个、[r]　
　您怎么了？在偷偷笑呢」[p]
[yuzuha_微笑_c]

[vo vo="ep3/koku_0098.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「不，没什么……[r]　
　啊，吊坠我打磨好了　还给您」[p]
[kokutou_真顔_c]

[vo vo="ep3/yuzu_0408.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「哇，闪闪发亮！简直像新的一样呢！」[p]
[yuzuha_笑顔_c]

[vo vo="ep3/koku_0099.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「它的主人……呃……」[p]
[kokutou_真顔_c]

[vo vo="ep3/yuzu_0409.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「是爱丽丝前辈对吧」[p]
[yuzuha_微笑_c]

[vo vo="ep3/koku_0100.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「对，请帮我转告那位爱丽丝前辈」[p]

[vo vo="ep3/koku_0101.ogg"]
#【黒十 美鹤】
「请她务必好好珍惜那枚吊坠」[p]
[kokutou_真顔_c]

[vo vo="ep3/yuzu_0410.ogg"]
#【小仓 柚叶】
「虽然她是否真会珍惜很让人怀疑……明白啦 我会转达的！」[p]
[yuzuha_微笑_c]


;//※※※電話中の黒十の裏話
;//選択肢４：黒十さんのこと　を選択していた時のみに見れるようになる。[p]
[if exp="f.problem_kokutou==1"]
[jump target="*kokutou_phone"]
[else]
[jump target="*overlooked"]
[endif]
;--------------------------------------------------
*kokutou_phone
[savetitle text="黒十マニュアル"]
;-------------------------------------------------
[vo vo="ep3/yuzu_0411.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「啊 说起来黑十先生、[r]　
　那次您竟然能熟练操作智能手机呢」[p]

[vo vo="ep3/yuzu_0412.ogg"]
#【小仓 柚叶】
「就是 我打电话给您的时候呀」[p]
[yuzuha_微笑_c]

#
忽然想起当时能顺利接听电话这件事让我既惊讶又在意。[p]

[vo vo="ep3/koku_0102.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「啊 是那时候啊」[p]
[kokutou_疑問_c]

[vo vo="ep3/yuzu_0413.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「我都以为您根本不会接电话呢」[p]

[vo vo="ep3/yuzu_0414.ogg"]
#【小仓 柚叶】
「没想到连地图导航都操作得那么流畅！」[p]

[vo vo="ep3/yuzu_0415.ogg"]
#【小仓 柚叶】
「莫非我不在的时候您偷偷学了很多东西？」[p]
[yuzuha_微笑_c]

[vo vo="ep3/koku_0103.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「啊— 啊哈哈……这个嘛 发生了不少事呢」[p]
[kokutou_微笑_c]

;全キャラ削除
[allc]
[bg10 bg="black.png"]

#
被柚叶君这么一说 那天的记忆再度苏醒。[p]


;//回想シーン

[bg10 bg="antique2.jpg"]

[kokutou_微笑_c]
[ric_f cg="kokutou"]

[iori_微笑_c]
[lec cg="iori"]

[vo vo="ep3/iori_0074.ogg"]
[iori_微笑]
#【御手洗 庵】
「科克托先生 陪我玩一会儿嘛」[p]
[iori_微笑_c]

#
他以那样轻快的步伐，悄无声息地来到古董店。[p]

[vo vo="ep3/koku_0104.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「什……你是……」[p]
[kokutou_驚き_c]

[vo vo="ep3/iori_0075.ogg"]
[iori_微笑]
#【御手洗 庵】
「啊哈哈，吓到了吓到了，今天大家的反应都很棒呢～」[p]
[iori_微笑_c]

[vo vo="ep3/koku_0105.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「当然会吓到啊，应该说为什么你会在这里……[r]　
　不对比起那个首先……这身打扮到底是打算干什么？」[p]
[kokutou_疑問_c]

#
唐突的出现固然令人吃惊，但更令人瞠目的是那身装束。[p]

[vo vo="ep3/iori_0076.ogg"]
[iori_微笑]
#【御手洗 庵】
「啊，注意到了吗？欸嘿嘿，可爱吧？」[p]
[iori_微笑_c]

#
他莫名骄傲地微笑着，轻巧地转了个圈展示。[p]

[vo vo="ep3/koku_0106.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「不用转圈……所以你到底来干什么的？」[p]
[kokutou_真顔_c]

[vo vo="ep3/iori_0077.ogg"]
[iori_微笑]
#【御手洗 庵】
「最开始就说过了呀，来玩的」[p]
[iori_微笑_c]

[vo vo="ep3/koku_0107.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「我拒绝」[p]
[kokutou_真顔_c]

[vo vo="ep3/iori_0078.ogg"]
[iori_微笑]
#【御手洗 庵】
「怎么这样～！至少别秒拒嘛～！」[p]
[iori_微笑_c]

[vo vo="ep3/koku_0108.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「我可没空陪你玩……[r]　
　明摆着会被卷进麻烦事里啊」[p]
[kokutou_真顔_c]

[vo vo="ep3/iori_0079.ogg"]
[iori_微笑]
#【御手洗 庵】
「唔～科克托先生还是这么冷淡呢」[p]
[iori_微笑_c]

#
他做出可爱的闹别扭表情，[r]　
但眼底却透着几分愉悦。[p]

[vo vo="ep3/iori_0080.ogg"]
[iori_無表情]
#【御手洗 庵】
「好啦，玩笑到此为止，[r]　
　其实是有件事想拜托你哦」[p]
[iori_無表情_c]

[vo vo="ep3/koku_0109.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「不想听」[p]
[kokutou_真顔_c]

[vo vo="ep3/iori_0081.ogg"]
[iori_無表情]
#【御手洗 庵】
「与其说是我的请求，不如说是……柚叶大人的请求呢」[p]
[iori_無表情_c]

[vo vo="ep3/koku_0110.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「柚叶君的？发生什么了吗？」[p]
[kokutou_疑問_c]

#
我们知道他是受雇于小仓家那边的人。[p]

从他口中说出关于柚叶君的请求，究竟会是什么呢。[p]

[vo vo="ep3/iori_0082.ogg"]
[iori_微笑]
#【御手洗 庵】
「啊——突然摆出这么严肃的表情……总觉得有点嫉妒呢」[p]
[iori_微笑_c]

[vo vo="ep3/koku_0111.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「请不要打岔，然后呢？」[p]
[kokutou_真顔_c]

[vo vo="ep3/iori_0083.ogg"]
[iori_微笑]
#【御手洗 庵】
「知道知道」[p]

[vo vo="ep3/iori_0084.ogg"]
[iori_無表情]
#【御手洗 庵】
「其实现在柚叶大人就读的学园里出了点麻烦事」[p]
[iori_無表情_c]

;テキストウィンドウ削除
[end_text]

;全キャラ削除
[allc]

;//黒ベタ
[bg10 bg="black.png"]

;//停止
[wait time=2000]

;//骨董品店事務所
[bg10 bg="antique.jpg"]

[kokutou_真顔_c]
[ric_f cg="kokutou"]

[iori_無表情_c]
[lec cg="iori"]

;テキストウィンドウ表示
[start_text]

[vo vo="ep3/koku_0112.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「原来如此，情况我了解了……御伽俱乐部是吧」[p]
[kokutou_真顔_c]

[vo vo="ep3/iori_0085.ogg"]
[iori_無表情]
#【御手洗 庵】
「对，对我来说不能让柚叶大人参加[r]　
　饴宫爱丽丝的茶会，所以很为难」[p]
[iori_微笑_c]

[vo vo="ep3/koku_0113.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「但也没必要特意来找我吧……」[p]
[kokutou_哀_c]

[vo vo="ep3/iori_0086.ogg"]
[iori_微笑]
#【御手洗 庵】
「因为我自己搞不明白嘛——这种事儿你很擅长对吧」[p]
[iori_微笑_c]

#
说得倒轻巧。[p]

不过我倒不吝于帮忙。[p]

说起来之前[r]　
这个俱乐部死缠烂打招揽成员，确实让人消沉过。[p]

现在看来似乎和这件事也有关系。[p]

[vo vo="ep3/iori_0087.ogg"]
[iori_微笑]
#【御手洗 庵】
「所以就拜托您啦，科克托先生」[p]
[iori_微笑_c]

[vo vo="ep3/koku_0114.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「……我也可以问个问题吗？」[p]
[kokutou_真顔_c]

[vo vo="ep3/iori_0088.ogg"]
[iori_微笑]
#【御手洗 庵】
「如果是能回答的事」[p]
[iori_微笑_c]

[vo vo="ep3/koku_0115.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「你的雇主是谁？」[p]
[kokutou_真顔_c]

[vo vo="ep3/iori_0089.ogg"]
[iori_悪い笑顔]
#【御手洗 庵】
「不说」[p]
[iori_悪い笑顔_c]

[vo vo="ep3/koku_0116.ogg"]
[kokutou_真顔]
;//読み方『杏葉』→あずは
#【黒十 美鹤】
「是柚叶君的姐姐……杏叶小姐，对吗？」[p]
[kokutou_真顔_c]

[vo vo="ep3/iori_0090.ogg"]
[iori_驚き]
#【御手洗 庵】
「真厉害，这都能猜到」[p]
[iori_驚き_c]

[vo vo="ep3/koku_0117.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「至少也该稍微掩饰下吧」[p]
[kokutou_真顔_c]


[vo vo="ep3/iori_0091.ogg"]
[iori_微笑]
#【御手洗 庵】
「不，我觉得对科克托先生这样说是白费功夫呢——」[p]


[vo vo="ep3/iori_0092.ogg"]
#【御手洗 庵】
「话说居然会提到杏叶大人的名字……难道你们认识？」[p]
[iori_微笑_c]

[vo vo="ep3/koku_0118.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「嘛，从前……和遇见柚叶君是同一个时期」[p]
[kokutou_疑問_c]

#
那时候的事我不太愿意回想。[p]

但今天却频频忆起那天的情景。[p]

[vo vo="ep3/koku_0119.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「也就是说你是受那位杏叶小姐指使，[r]　
　最近一直在柚叶君周围盯梢？」[p]
[kokutou_真顔_c]


[vo vo="ep3/iori_0093.ogg"]
[iori_微笑]
#【御手洗 庵】
「就是这样……[r]　
　发现饴宫爱丽丝对柚叶大人怀有恶意的执着」[p]


[vo vo="ep3/iori_0094.ogg"]
#【御手洗 庵】
「所以我才会暗中调查并试图阻止」[p]


[vo vo="ep3/iori_0095.ogg"]
#【御手洗 庵】
「看来杏叶大人也有她自己的方式想要保护柚叶大人呢」[p]
[iori_微笑_c]

[vo vo="ep3/koku_0120.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「……用错了方法就是了」[p]
[kokutou_真顔_c]


[vo vo="ep3/iori_0096.ogg"]
[iori_微笑]
#【御手洗 庵】
「嘛，终归是杏叶大人自己的方式」[p]
[iori_微笑_c]

[vo vo="ep3/koku_0121.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「原来如此……不过暗中行动，是吧……」[p]
[kokutou_疑問_c]


[vo vo="ep3/iori_0097.ogg"]
[iori_微笑]
#【御手洗 庵】
「有好好伪装吧？」[p]
[iori_微笑_c]

[vo vo="ep3/koku_0122.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「有必要女装吗？」[p]
[kokutou_真顔_c]


[vo vo="ep3/iori_0098.ogg"]
[iori_微笑]
#【御手洗 庵】
「诶嘿嘿，很合适不是嘛♪」[p]
[iori_微笑_c]

[vo vo="ep3/koku_0123.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「真是够了……啊，言归正传吧」[p]

[vo vo="ep3/koku_0124.ogg"]
#【黒十 美鹤】
「那么具体我该怎么做？」[p]
[kokutou_真顔_c]


[vo vo="ep3/iori_0099.ogg"]
[iori_微笑]
#【御手洗 庵】
「估计过会儿，[r]　
　柚叶大人会来电询问这个谜团，到时候帮帮他吧」[p]
[iori_微笑_c]

[vo vo="ep3/koku_0125.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「……电话……智能手机，对吧？」[p]
[kokutou_哀_c]


[vo vo="ep3/iori_0100.ogg"]
[iori_驚き]
#【御手洗 庵】
「咦？怎么脸色发青啊」[p]
[iori_驚き_c]

[vo vo="ep3/koku_0126.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「其实我对于最新设备实在是不拿手……[r]　
　连接电话都有些勉强」[p]
[kokutou_哀_c]

[vo vo="ep3/iori_0101.ogg"]
[iori_微笑]
#【御手洗 庵】
「啊哈哈，科克托先生难得会开这种玩笑呢」[p]
[iori_微笑_c]

[vo vo="ep3/koku_0127.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「……如果是玩笑就好了」[p]
[kokutou_哀_c]

[vo vo="ep3/iori_0102.ogg"]
[iori_驚き]
#【御手洗 庵】
「真的吗？」[p]
[iori_驚き_c]

#
面对这个问题，沉默着点了点头。[p]

[vo vo="ep3/iori_0103.ogg"]
[iori_微笑]
#【御手洗 庵】
「真拿你没办法呢……[r]　
　那有电话打来的时候我来教你吧」[p]
[iori_微笑_c]

[vo vo="ep3/koku_0128.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「实在惭愧……拜托您了」[p]
[kokutou_真顔_c]

[vo vo="ep3/iori_0104.ogg"]
[iori_微笑]
#【御手洗 庵】
「本来想立刻返回学园的……[r]　
　嘛，也没办法呢」[p]

[vo vo="ep3/iori_0105.ogg"]
#【御手洗 庵】
「啊，既然我在你身旁这件事[r]　
　请务必别让柚叶大人发现哦？」[p]
[iori_微笑_c]

[vo vo="ep3/koku_0129.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「我、我会妥善处理的……」[p]
[kokutou_真顔_c]

;//回想シーンここまで
;テキストウィンドウ削除
[end_text]

;全キャラ削除
[allc]

;//黒ベタ
[bg10 bg="black.png"]

;//停止
[wait time=2000]

;//骨董品店事務所
[bg10 bg="antique.jpg"]

[kokutou_真顔_c]
[ric_f cg="kokutou"]

[yuzuha_微笑_c]
[lec cg="yuzuha"]

;テキストウィンドウ表示
[start_text]



#
结果那时候，多亏庵少年在旁边才化险为夷。[p]

[vo vo="ep3/koku_0130.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「哈啊……姑且感谢他一下吧」[p]
[kokutou_真顔_c]

[vo vo="ep3/yuzu_0416.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「嗯？你刚才说什么？」[p]
[yuzuha_疑問_c]

[vo vo="ep3/koku_0131.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「没有没有……不过现代技术真令人吃惊，[r]　
　别说地图了，连道路导航都能做到」[p]
[kokutou_真顔_c]

[vo vo="ep3/yuzu_0417.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「不不，车载导航不是更早之前就修复了吗？」[p]
[yuzuha_疑問_c]

#
高科技设备实在应付不来。[p]

这辈子估计都这样了吧。[p]

;//※※※電話中の黒十の裏話ここまで
;--------------------------------------------------
*overlooked
[savetitle text="倶楽部の勧誘"]
;-------------------------------------------------
[vo vo="ep3/koku_0132.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「不过柚叶君平常究竟过着怎样的生活？」[p]

[vo vo="ep3/koku_0133.ogg"]
#【黒十 美鹤】
「因为这次的事稍微有些担心呢」[p]
[kokutou_真顔_c]

[vo vo="ep3/yuzu_0419.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「哎呀真是难为情……[r]　
　不过，可不是每天都这样的哦？」[p]
[yuzuha_微笑_c]

[vo vo="ep3/koku_0134.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「真的吗？」[p]
[kokutou_真顔_c]

[vo vo="ep3/yuzu_0420.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「当然了，昨天就真的什么事都没发生，[r]　
　和小百合小姐悠闲地度过了呢！」[p]
[yuzuha_笑顔_c]

[vo vo="ep3/koku_0135.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「说起来这次好像也受了稻饼小姐不少照顾」[p]
[kokutou_真顔_c]

[vo vo="ep3/yuzu_0421.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「是啊，下次得好好道谢才行——」[p]
[yuzuha_笑顔_c]

[vo vo="ep3/koku_0136.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「这样比较妥当呢」[p]
[kokutou_微笑_c]

[vo vo="ep3/yuzu_0422.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「……仔细想想，能过得这么悠闲[r]　
　完全是因为俱乐部招新停止了的缘故啊——」[p]
[yuzuha_疑問_c]

[vo vo="ep3/koku_0137.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「此话怎讲？」[p]
[kokutou_真顔_c]

[vo vo="ep3/yuzu_0423.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「其实自从那个御伽俱乐部的事件之后，[r]　
　来自各社团的邀约突然就全消失了」[p]

[vo vo="ep3/yuzu_0424.ogg"]
#【小仓 柚叶】
「连茶会的邀请也彻底没有了」[p]
[yuzuha_微笑_c]

[vo vo="ep3/koku_0138.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「社团招新和茶会邀请都没了吗」[p]
[kokutou_疑問_c]

#
脑海中浮现出一位女装店员的容颜。[p]

看来他工作卖力得有些过头了。[p]

[vo vo="ep3/yuzu_0425.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「嘛，托他的福我的校园生活总算安稳了也好」[p]
[yuzuha_微笑_c]

[vo vo="ep3/koku_0139.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「呵呵，那真是太好了」[p]
[kokutou_微笑_c]

[vo vo="ep3/yuzu_0426.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「咦？你这笑声里是不是藏着什么？」[p]
[yuzuha_疑問_c]

[vo vo="ep3/koku_0140.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「诶，给您这种感觉了吗？」[p]
[kokutou_微笑_c]

[vo vo="ep3/yuzu_0427.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「很明显很明显！[r]　
　难道黑十先生知道邀约消失的原因了！？」[p]
[yuzuha_微笑_c]

[vo vo="ep3/koku_0141.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「怎么可能，那种事不可能的吧……[r]　
　啊、要不我再给您泡杯咖啡吧」[p]
[kokutou_真顔_c]

#
为了不被继续追问而匆忙起身离开。[p]

[vo vo="ep3/yuzu_0428.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「啊、请等一下！黑十先生！黑十先生——！」[p]
[yuzuha_驚き_c]

#
柚叶君的校园生活似乎归于平静，[r]　
我的日常生活却一如既往未曾改变。[p]

;テキストウィンドウ削除
[end_text]

;全キャラ削除
[allc]

;スタッフロールへ移動
[jump  storage="ep3_staff.ks"]

[s]