﻿;--------------------------------------------------
;■黒十　本文テキスト　ep4　鐘塔の幽霊
;--------------------------------------------------
;
;■ep4_scene02
;
;--------------------------------------------------
*020000
[savetitle text="客人にコーヒーも出さないの？"]
;-------------------------------------------------

;BGM再生
[bgm ogg="music.ogg"]


;//背景、事務所
[bg20 bg="antique.jpg"]

;アリス衣装指定
[alice_c_冬]

[yuzuha_微笑_c]
[c4_f cg="yuzuha"]

[kokutou_哀]
[c3_f cg="kokutou"]

[alice_退屈_c]
[ri cg="alice"]

;テキストウィンドウ表示
[start_text]

[vo vo="ep4/koku_0013.ogg"]
#【黒十 美鹤】
「那么，饴宫小姐您这次来是有什么事？」[p]
[kokutou_哀_c]

#
面对在沙发上落座的饴宫爱丽丝，他直接切入正题。[p]

虽听说她有事相求，[r]　
却暗自盘算着听完要求就立刻回绝。[p]

然而她并未作答。[p]

正用兴致索然的目光环顾四周。[p]

[vo vo="ep4/koku_0014.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「……那个」[p]
[kokutou_哀_c]


[vo vo="ep4/yuzuha_0017.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「黑十先生，没用的哦」[p]
[yuzuha_哀_c]

#
柚叶君小声嘀咕道。[p]

[vo vo="ep4/yuzuha_0018.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「爱丽丝前辈可是超级我行我素的」[p]

[vo vo="ep4/yuzuha_0019.ogg"]
#【小仓 柚叶】
「基本上不会听别人说话呢」[p]
[yuzuha_哀_c]

#
这实在不像来别人店里委托办事之人该有的举动。[p]

[vo vo="ep4/alice_0005.ogg"]
[alice_退屈]
#【饴宫 爱丽丝】
「嗯——原来如此」[p]
[alice_退屈_c]

#
用这般态度巡视四周许久的她[r]　
又以百无聊赖的语气轻声道。[p]

虽然有些在意究竟什么「原来如此」，但终究没有问出口。[p]

谁知草丛里会窜出什么来。[p]

[vo vo="ep4/alice_0006.ogg"]
[alice_呆れ]
#【饴宫 爱丽丝】
「话说……这里都不给客人上咖啡的吗？」[p]
[alice_呆れ_c]

[vo vo="ep4/koku_0015.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「……哈啊」[p]
[kokutou_哀_c]

#
既不听人说话，又毫无歉意，[r]　
被这么一说任谁都想叹气。[p]

[vo vo="ep4/yuzuha_0020.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「啊哈哈，那个，我去准备一下」[p]
[yuzuha_微笑_c]

;SE：屋内足音フェイドアウト
[se_f se="footsteps_out.ogg"]

;キャラ消去
[hide_yuzuha]

;キャラ消去
[hide_kokutou]

[le cg="kokutou"]

[vo vo="ep4/koku_0016.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「麻烦了……客用杯子，知道在哪吗？」[p]
[kokutou_真顔_c]

[vo vo="ep4/yuzuha_0021.ogg"]
#【小仓 柚叶】
「没问题」[p]

;SE：足音フェイドアウト
[se_f se="footsteps_out.ogg"]
#
向抱着头走向厨房的柚叶君搭话。[p]

虽然觉得抱歉，但这或许是个机会。[p]

[vo vo="ep4/koku_0017.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「饴宫小姐……为什么来这里？」[p]
[kokutou_哀_c]

#
保持着抱头的姿势向她询问。[p]
[vo vo="ep4/alice_0007.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「说过了呀，有事情想拜托你」[p]
[alice_笑み_c]

[vo vo="ep4/koku_0018.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「不，不是这个意思……」[p]
[kokutou_哀_c]

[vo vo="ep4/koku_0019.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「被小仓家盯上的你为何会出现在柚叶君所在的这里？」[p]
[kokutou_真顔_c]

[alice_驚き]
#
听到这个问题，她略微睁大眼睛露出惊讶的表情。[p]

这是来到这里后第一次看到她像人类般的表情。[p]

但这份神情很快就被游刃有余的、[r]　
如同人造品般的微笑所掩盖。[p]

[vo vo="ep4/alice_0008.ogg"]
[alice_ドヤ顔]
#【饴宫 爱丽丝】
「……嘿欸」[p]
[alice_ドヤ顔_c]

[vo vo="ep4/koku_0020.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「因为上次的事，你应该被禁止[r]　
　再接触柚叶君了才对吧？」[p]
[kokutou_真顔_c]

#
正因如此，那个女装店员才会出现在这里。[p]

后来从柚叶君那里听说、[r]　
别说茶会，连社团邀约都已经取消了。[p]
[vo vo="ep4/alice_0009.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「哈……算是吧」[p]

[vo vo="ep4/alice_0010.ogg"]
#【饴宫 爱丽丝】
「不过请放心，我已经放弃小仓柚叶了」[p]
[alice_真顔_c]

[vo vo="ep4/koku_0021.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「……真的吗？」[p]
[kokutou_真顔_c]

[vo vo="ep4/alice_0011.ogg"]
[alice_怒り]
#【饴宫 爱丽丝】
「真的哦，我可对一直陈列在橱窗里的[r]　
　玩具没什么兴趣」[p]

[vo vo="ep4/alice_0012.ogg"]
[alice_ドヤ顔]
#【饴宫 爱丽丝】
「玩具只有被把玩时，[r]　
　才能真正体现它的价值不是吗？」[p]
[alice_ドヤ顔_c]

#
她挺起胸膛，仿佛在宣称这是亘古不变的真理。[p]

但将血肉之躯的人类与玩具相提并论的恶趣味，[r]　
可惜我完全不具备。[p]

见我不作声，她轻哼一声微微举起双手耸了耸肩。[p]

[vo vo="ep4/alice_0013.ogg"]
[alice_呆れ]
#【饴宫 爱丽丝】
「嘛，说到底我也不能再[r]　
　继续挑衅小仓家了」[p]

[vo vo="ep4/alice_0014.ogg"]
[alice_ドヤ顔]
#【饴宫 爱丽丝】
「况且我也不想出尔反尔呢」[p]
[alice_ドヤ顔_c]

#
她曾承诺过会与御伽俱乐部的秘密一同，[r]　
从柚叶君身边抽身而退。[p]

看来确实没有加害的意图。[p]

或许不必如此戒备。[p]

但保持警惕总没错。[p]

;//SE、カップの割れる音
;SE:カップの割れる音
[se_f se="cup_crash.ogg"]
[vo vo="ep4/yuzuha_0022.ogg"]

[alice_驚き_c]
[kokutou_驚き_c]

这时厨房传来杯子破碎的声响。[p]

同时响起柚叶君细微的惊叫。[p]

[alice_真顔_c]

[vo vo="ep4/koku_0022.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「……柚叶君？」[p]
[kokutou_疑問_c]

#
我半抬起身犹豫是否该离席，[r]　
将视线投向对座少女。[p]

她却靠着沙发背转过脸去。[p]

[vo vo="ep4/alice_0015.ogg"]
[alice_退屈]
#【饴宫 爱丽丝】
「想去就去呗？」[p]
[alice_退屈_c]

#
听到那似乎发自心底满不在乎的话语后[r]　
走向了厨房。[p]

[kill]

;//背景：キッチン
[bg-go bg="kitchen.jpg"]

[vo vo="ep4/yuzuha_0023.ogg"]
[yuzuha_驚き]
[ce cg="yuzuha"]
#【小仓 柚叶】
「啊，黑十先生」[p]

[vo vo="ep4/yuzuha_0024.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「对不起，我把杯子打碎了」[p]
[yuzuha_哀_c]

#
只见周围散落着杯子的碎片。[p]

;キャラ消去
[chara_hide name="yuzuha"]

[kokutou_真顔]
[ric_f cg="kokutou"]

[yuzuha_哀_c]
[lec cg="yuzuha"]

[vo vo="ep4/koku_0023.ogg"]
#【黒十 美鹤】
「不，不用在意」[p]
[kokutou_真顔_c]

[vo vo="ep4/yuzuha_0025.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「……但这个，该不会是古董吧……？」[p]
[yuzuha_哀_c]

#
柚叶君怯生生地观察着这边神色询问道。[p]

活像被发现做了坏事的小狗。[p]

[vo vo="ep4/yuzuha_0026.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「那个，真的很抱歉……！」[p]

[vo vo="ep4/yuzuha_0027.ogg"]
#【小仓 柚叶】
「如果您很喜欢，或者是纪念品的话……[r]　
　那个，真的非常对不起……！」[p]
[yuzuha_哀_c]

#
柚叶君猛地低头道歉。[p]

身为富豪千金若真想赔偿[r]　
本是轻而易举的少女。[p]

[vo vo="ep4/koku_0024.ogg"]
[kokutou_疑問_c]
#【黒十 美鹤】
「…………」[p]

#
这种地方该怎么说呢，狡猾。[p]

她似乎懂得珍视的不是价格[r]　
而是物件本身的意义。[p]

甚至觉得若她因此对古董稍感兴趣[r]　
倒也值得，不过这或许期望过高了。[p]

[vo vo="ep4/koku_0025.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「嘛，虽不是廉价品……[r]　
　但也不是再也买不到的东西，没关系的」[p]
[kokutou_微笑]

[vo vo="ep4/yuzuha_0028.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「哈……太好了」[p]
[yuzuha_哀_c]

[vo vo="ep4/koku_0026.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「比起这个，你没受伤吧？」[p]
[kokutou_真顔_c]

[vo vo="ep4/yuzuha_0029.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「咦？啊——呃——……」[p]
[yuzuha_微笑_c]

#
看着她试图蒙混过关的笑容，[r]　
我注意到她正把左手藏在身后。[p]

[vo vo="ep4/yuzuha_0030.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「啊……」[p]
[yuzuha_驚き_c]

#
拉起她的手查看时，无名指正渗着血。[p]

[vo vo="ep4/yuzuha_0031.ogg"]
[yuzuha_微笑]
[yuzuha_etc_頬]
#【小仓 柚叶】
「啊哈哈，那个——[r]　
　笨手笨脚的样子被看到有点难为情呢」[p]
[yuzuha_微笑_c]

#
虽然她常在这个厨房为我做饭，[r]　
但受伤还是头一遭。[p]

看样子她为此莫名窘迫。[p]

[vo vo="ep4/koku_0027.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「就算这样也没必要藏起来吧……请稍等」[p]
[kokutou_哀_c]

#
[kill]
[yuzuha_etc_off]

;//背景：洗面所
[bg-go bg="bathroom.jpg"]

记得急救箱里应该还剩着创可贴。[p]

找到创可贴盒确认时，里面还躺着最后几片。[p]

;//選択肢
;//１：一枚だけ持っていく
;//２：何枚か持っていく

[glink x="266" y="186" graphic="txtlink.png" width="712"  size="28" text="一枚だけ持っていく" storage="ep4_scene02.ks" target="*choice1_1"]
[glink x="266" y="299" graphic="txtlink.png" width="712" size="28" text="何枚か持っていく。" storage="ep4_scene02.ks" target="*choice1_2" exp="f.絆創膏 = 1"]
[s]


;//選択肢１：一枚だけ持っていく
*choice1_1

看那伤势一片就够了。[p]

从叠放的创可贴中撕下一片，我返回厨房。[p]


;//ここまで
;//合流へジャンプ
[jump  storage="ep4_scene02.ks"  target="*choice1_end"]


;//選択肢２：何枚か持っていく
*choice1_2

虽不是严重伤口，但总归越快处理越好。[p]

随手抓了几片连着的创可贴就往厨房赶。[p]


;//ここまで
;//合流へジャンプ
[jump  storage="ep4_scene02.ks"  target="*choice1_end"]


;//合流
*choice1_end

;//背景：キッチン
[bg-go bg="kitchen.jpg"]

[kokutou_哀]
[ric_f cg="kokutou"]

[yuzuha_微笑_c]
[lec cg="yuzuha"]

#
回到厨房时，[r]　
先前摔碎的杯子碎片已被收拾干净。[p]

看来是柚叶君收拾的。[p]

[vo vo="ep4/koku_0028.ogg"]
#【黒十 美鹤】
「这种小事我来就行」[p]
[kokutou_哀_c]

[vo vo="ep4/yuzuha_0032.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「没、没关系的」[p]
[yuzuha_微笑_c]

[vo vo="ep4/koku_0029.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「……来，让我看看手」[p]

[yuzuha_驚き_c]
[yuzuha_etc_頬]

#
说着将柚叶君的左手拉了过来。[p]

[vo vo="ep4/koku_0030.ogg"]
#【黒十 美鹤】
「要贴创可贴了，请保持别动哦」[p]
[kokutou_真顔_c]

[vo vo="ep4/yuzuha_0033.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「啊～其实我自己可以来的啦～！」[p]
[yuzuha_哀_c]

[vo vo="ep4/koku_0031.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「听话」[p]
[kokutou_真顔_c]

[vo vo="ep4/yuzuha_0034.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「但、但是你看那个……那、那里……」[p]
[yuzuha_驚き_c]

;イベントＣＧ表示
[eval exp="sf.cg_ep4_4 = 1"]
[event_in event="ep4_4"]
#
我无视嘟囔抱怨的柚叶君，将创可贴按在伤口上。[p]

幸运的是似乎一张就足够了。[p]

伤口看起来也没那么深，[r]　
这样的话应该不会留疤吧。[p]

为避免勒得太紧，轻轻缠绕好创可贴。[p]

[vo vo="ep4/yuzuha_0035.ogg"]
[yuzuha_怒]
#【小仓 柚叶】
「哈、哈啊啊啊……！」[p]

#
这时柚叶君发出了[r]　
某种既似沉重叹息又像悲鸣的声音。[p]

;イベントＣＧ削除
[event_out]

[vo vo="ep4/koku_0032.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「怎么了，你看，已经贴好了哦？」[p]
[kokutou_哀_c]

[vo vo="ep4/yuzuha_0036.ogg"]
[yuzuha_怒鳴る]
#【小仓 柚叶】
「是、是的……呜、嗯呜呜呜……！！！！」[p]
[yuzuha_怒鳴る_c]

#
当我把贴着创可贴的手举到胸前时，[r]　
柚叶君发出呻吟般的声音，整张脸涨得通红。[p]

从刚才开始到底是怎么回事。[p]是发作了吗。[p]

还是我哪里做错了呢。[p]

[vo vo="ep4/koku_0033.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「柚叶君？怎么了，难道是疼吗？」[p]
[kokutou_疑問_c]

[vo vo="ep4/yuzuha_0037.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「不……不疼的……呜呜……」[p]
[yuzuha_哀_c]

#
眼眶含泪的柚叶君[r]　
静静凝视着贴在手指上的创可贴。[p]

那双眼睛仿佛在凝视珍宝般注视着，[r]　
又害羞地用另一只手掩住了嘴角。[p]

难道贴个创可贴就如此令人难为情吗。[p]

或许现今的女孩子心思就是这般复杂吧。[p]

[vo vo="ep4/yuzuha_0038.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「那、那个黑十先生……谢、谢谢您」[p]
[yuzuha_微笑_c]

[vo vo="ep4/koku_0034.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「不必客气 这点小事微不足道」[p]
[kokutou_微笑_c]

;//SE：ノックの音
;SE：ノック
[se_f se="knocking_a_wooden_door1.ogg"]

#
忽然响起的叩墙声让两人同时望向声源。[p]

[kill]
[yuzuha_etc_off]
[alice_退屈]
[ce cg="alice"]

只见满脸不悦的金发少女[r]　
正倚着墙朝这边瞪视。[p]

[vo vo="ep4/alice_0016.ogg"]
#【饴宫 爱丽丝】
「喂 你们打算把客人晾到什么时候？」[p]
[alice_退屈_c]

[vo vo="ep4/koku_0035.ogg"]
#【黒十 美鹤】
「啊—抱歉 这就回去」[p]

[vo vo="ep4/yuzuha_0039.ogg"]
#【小仓 柚叶】
「对对对不起！咖啡也已经准备好了！」[p]

[vo vo="ep4/alice_0017.ogg"]
[alice_退屈]
#【饴宫 爱丽丝】
「哼嗯……」[p]
[alice_退屈_c]

#
饴宫爱丽丝直勾勾地盯着柚叶君。[p]

[vo vo="ep4/yuzuha_0040.ogg"]
#【小仓 柚叶】
「怎、怎么了？」[p]

[vo vo="ep4/alice_0018.ogg"]
[alice_退屈]
#【饴宫 爱丽丝】
「没事……倒是你们动作快点」[p]
[alice_退屈_c]

#

;テキストウィンドウ削除
[end_text]

;全キャラ削除
[allc]

;//黒背景
[bg20 bg="black.png"]

;--------------------------------------------------
*021000
[savetitle text="面白い噂"]
;-------------------------------------------------

;//背景：事務所
[bg20 bg="antique.jpg"]

;テキストウィンドウ表示
[start_text]

[yuzuha_哀]
[c4_f cg="yuzuha"]

[kokutou_哀_c]
[c3_f cg="kokutou"]

[alice_真顔_c]
[ri cg="alice"]

[vo vo="ep4/yuzuha_0041.ogg"]
#【小仓 柚叶】
「给您添了这么多麻烦实在抱歉」[p]
[yuzuha_哀_c]

[vo vo="ep4/alice_0019.ogg"]
[alice_呆れ]
#【饴宫 爱丽丝】
「就是啊」[p]
[alice_呆れ_c]

[vo vo="ep4/yuzuha_0042.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「哈哈……所以爱丽丝学姐是有什么委托对吧！」[p]

[vo vo="ep4/yuzuha_0043.ogg"]
#【小仓 柚叶】
「到底是什么样的委托呢？」[p]
[yuzuha_微笑_c]

[vo vo="ep4/alice_0020.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「……这个嘛」[p]
[alice_真顔_c]

#
轻声低语后 她缓缓地[r]　
端起桌上的杯子轻啜一口。[p]

这般举止果然尽显千金小姐的优雅风范。[p]

但我不喜欢别人卖关子。[p]

投去催促的目光希望她尽快进入正题。[p]

可她对我这般视线[r]　
却像清风拂山岗似的继续拿腔作势。[p]

正当我忍不住要开口催促时——[p]

[vo vo="ep4/alice_0021.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「其实最近学院里有个有趣的传闻呢」[p]
[alice_真顔_c]

#
饴宫爱丽丝这才切入正题。[p]

[vo vo="ep4/alice_0022.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「希望你们能协助揭露这个传闻的真相」[p]
[alice_笑み_c]

[vo vo="ep4/yuzuha_0044.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「揭露传闻的真相……？」[p]
[yuzuha_疑問_c]

[vo vo="ep4/koku_0036.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「又是类似的委托……」[p]
[kokutou_哀_c]

#
忍不住抱怨出声。[p]

[vo vo="ep4/koku_0037.ogg"]
[kokutou_怒]
#【黒十 美鹤】
「很抱歉我们只是家不起眼的古董店[r]　
　这类委托还请另寻高明」[p]
[kokutou_怒_c]

[vo vo="ep4/alice_0023.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「哎呀，可我听说你们很擅长这类事情呢？」[p]
[alice_笑み_c]

#
真是困扰，这情报究竟从哪儿泄露的。[p]

[vo vo="ep4/alice_0024.ogg"]
[alice_ドヤ顔]
#【饴宫 爱丽丝】
「据说用一个铜锣烧就能让你们任劳任怨」[p]
[alice_ドヤ顔_c]

[vo vo="ep4/koku_0038.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「一个铜锣烧就……！？」[p]
[kokutou_驚き_c]

#
被她的话动摇了心神。[p]

这离谱的谣言到底源头何在。[p]

不知不觉间居然被当成[r]　
未来猫型机器人般使唤。[p]

该怎么说呢，实在心有不甘。[p]

正想开口抗议几句，[r]　
却被柚叶君抢了先机。[p]

[vo vo="ep4/yuzuha_0045.ogg"]
[yuzuha_怒鳴る]
#【小仓 柚叶】
「比起那个，传闻是什么啊！？」[p]

[vo vo="ep4/yuzuha_0046.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「那个学园里，竟然还留有我所不知道的谜团！？」[p]
[yuzuha_笑顔_c]

[vo vo="ep4/koku_0039.ogg"]
[kokutou_呆れ]
#【黒十 美鹤】
「柚叶君……」[p]
[kokutou_呆れ_c]

#
看样子这边的开关已经被打开了。[p]

被那样说话的话也是理所当然的吧。[p]

[kokutou_哀2_c]

……不，说不定是故意的。[p]

[kokutou_真顔_c]
偷偷瞥了一眼饴宫爱丽丝。[p]

那抹微笑完美得甚至透着一股可疑。[p]

[vo vo="ep4/yuzuha_0047.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「黑十先生，您不在意吗？」[p]

[vo vo="ep4/yuzuha_0048.ogg"]
#【小仓 柚叶】
「说不定这次又会有[r]　
　谜团凭空出现在我们面前哦！」[p]
[yuzuha_微笑_c]

#
若真如此，那恐怕不是自然出现的，[r]　
而是有人刻意为之。[p]

但事已至此，[r]　
至少不得不听她讲述了。[p]

[vo vo="ep4/koku_0040.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「哈啊……只听你说说而已哦？」[p]
[kokutou_哀_c]

#
;立ち絵削除
[allc]

;BGM停止
[bgm_end3]

但愿事情能到此为止。[p]

怀揣祈祷般的心情向这位麻烦的访客伸手示意她继续。[p]


;//背景：白
[bg20 bg="white.png"]

;//黒背景（なんかそれっぽい礼拝堂とか学校の背景があればそういう演出する）
;//背景：学校
[bg20 bg="past_01.jpg"]

;BGM再生
[bgm ogg="horror.ogg"]

这所云集名门子弟的学园历史悠久，可追溯至明治初期。[p]

建国伊始，美国改革派教会的传教士登陆这座港口小镇，[r]　
创办女子学园便是其开端。[p]

占据历史景观区一隅的校舍、宿舍……以及礼拜堂。[p]

在这段悠久历史中，这座礼拜堂曾有许多人进出。[p]

作为名副其实的神圣场所[r]　
世代以来在学园内被珍视并传承着。[p]

;//背景：学校
[bg20 bg="past_02.jpg"]
作为这座礼拜堂的象征，矗立着一座钟塔。[p]

遗憾的是作为功能部件的钟早已不再鸣响，[r]　
至今其外形仍被用建材精心保存着。[p]

就在那座钟塔上。[p]

深夜12点，幽灵会出现在空无一人的礼拜堂钟塔。[p]

这样的传闻最近开始逐渐流传开来。[p]

原本就是历史悠久的建筑物。[p]

再加上学园这种场所[r]　
要说与这类怪谈相伴也是理所当然。[p]

女学生们半开玩笑地传播这种传闻并不稀奇。[p]

事实上，关于这座礼拜堂的怪谈[r]　
据说曾流传过好几个版本。[p]

但这次关于钟塔幽灵的传闻规模略有不同。[p]

有多个目击者声称[r]　
在12点整看见了钟塔的幽灵。[p]

某位女学生甚至因此出现神经衰弱症状[r]　
据说已发展到拒绝上学的程度。[p]

如今传闻导致礼拜堂再无人敢靠近。[p]

;//背景：黒
[bg20 bg="black.png"]

『12点，无人礼拜堂的钟塔上会出现幽灵。』[p]

这样的谣言正在校园内蔓延。[p]

;BGM停止
[bgm_end1]

;//事務所
[bg20 bg="antique.jpg"]

[yuzuha_微笑_c]
[c4_f cg="yuzuha"]

[kokutou_哀_c]
[c3_f cg="kokutou"]

[alice_笑み]
[ri cg="alice"]

[vo vo="ep4/alice_0025.ogg"]
#【饴宫 爱丽丝】
「呐？听起来很有趣吧？」[p]
[alice_笑み_c]

#
说完后她用手拨弄头发，露出得意的笑容。[p]

继神秘的俱乐部之后又讲起怪谈。[p]

虽然对她很抱歉，但我完全不明白有趣在哪里。[p]

但有个少女似乎对这类话题很感兴趣。[p]

;BGM再生
[bgm ogg="music.ogg"]

[vo vo="ep4/yuzuha_0049.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「听起来超级有趣呢！」[p]
[yuzuha_笑顔_c]

[vo vo="ep4/koku_0041.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「……果然会变成这样吗」[p]
[kokutou_哀_c]

[vo vo="ep4/alice_0026.ogg"]
[alice_ドヤ顔]
#【饴宫 爱丽丝】
「关于钟塔出现幽灵的传闻……希望你能查明真相」[p]
[alice_ドヤ顔_c]

[vo vo="ep4/yuzuha_0050.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「黑十先生！我们一起去调查吧！」[p]
[yuzuha_笑顔_c]

#
不出所料，柚叶君开始这么提议。[p]

看来光听故事还不能结束。[p]

[vo vo="ep4/koku_0042.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「为什么我要做这种事……」[p]
[kokutou_哀_c]

#
面对金发访客带来的麻烦事，我只能皱眉。[p]

有办法能拒绝吗。[p]

[vo vo="ep4/koku_0043.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「那个礼拜堂是在校园里的吧？」[p]

[vo vo="ep4/koku_0044.ogg"]
#【黒十 美鹤】
「记得那所学院是禁止男生入内的吧？」[p]
[kokutou_真顔_c]

[vo vo="ep4/alice_0027.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「那就不用担心了」[p]

[vo vo="ep4/alice_0028.ogg"]
[alice_ドヤ顔]
#【饴宫 爱丽丝】
「已经和学院方打过招呼了，[r]　
　我们拿到了进入校园的许可证哦」[p]
[alice_ドヤ顔_c]

[kokutou_驚き_c]
#
看到哑口无言的我，她欢快地扬起嘴角。[p]

原来如此 是被先发制人了啊。[p]

[vo vo="ep4/yuzuha_0051.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「那样的话黑十先生待在学园里也没问题了呢！」[p]
[yuzuha_微笑_c]

[vo vo="ep4/koku_0045.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「不 可是……」[p]
[kokutou_哀_c]

[vo vo="ep4/yuzuha_0052.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「黑十先生 我们走吧……[r]　
　学园里说不定有珍贵的古董哦？」[p]
[yuzuha_笑顔_c]

#
确实 根据刚才的谈话 这座学园似乎历史悠久。[p]

要说对使用的器具完全不感兴趣那是假话。[p]

[vo vo="ep4/koku_0046.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「哈……没办法 是吧」[p]
[kokutou_哀_c]

[vo vo="ep4/yuzuha_0053.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「太好啦！」[p]
[yuzuha_笑顔_c]

[vo vo="ep4/alice_0029.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「那么……就这么定啦」[p]
[alice_笑み_c]

#
反正幽灵什么的根本不可能出现。[p]

随便听听讲解 看看古董就能回去了。[p]

真的 但愿能就这样平安结束就好。[p]

;//シーン転換

;テキストウィンドウ削除
[end_text]

;BGM停止
[bgm_end3]

;全キャラ削除
[allc]

;背景
[bg10 bg="white.png"]

;次のシーンへ移動
[jump  storage="ep4_scene03.ks"]

[s]