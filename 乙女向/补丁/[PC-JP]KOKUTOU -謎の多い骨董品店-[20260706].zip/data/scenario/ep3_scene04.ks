﻿;--------------------------------------------------
;■黒十　本文テキスト　ep3　御伽倶楽部
;--------------------------------------------------
;
;■ep3_scene04
;
;--------------------------------------------------
[eval exp="f.first_select=0"]
[eval exp="f.first_map_1=0"]
[eval exp="f.first_map_2=0"]
[eval exp="f.first_map_3=0"]
[eval exp="f.first_map_4=0"]
[eval exp="f.first_map_5=0"]
;-------------------------------------------------
*first_select
[savetitle text="地図画面"]
;-------------------------------------------------
;//２回場所移動を間違うとバッド・エンドのルート『大変だ、遅刻する』へ

[if exp="f.first_select==2"]
[jump target="*first_select_end"]
[else]
[jump target="*first_select_map"]
[endif]　

;-------------------------------------------------
*first_select_map
[savetitle text="地図画面"]
;-------------------------------------------------
;//前画面の要素を削除

;テキストウィンドウ削除
[end_text]

;全キャラ削除
[allc]

;//黒ベタ
[bg10 bg="black.png"]


[bg10 bg="select_map.jpg"]

;BGM再生
[bgm ogg="tukikage.ogg"]

;//場所移動の選択肢--------------------------------------------------

*first_map_1
[if exp="f.first_map_1==1"]
[jump target="*first_map_2]
[else]
[endif]

;//１：上級生の教室
[button name="role_button" x="515" y="321" graphic="map/btn_select_10_off.png" enterimg="map/btn_select_10_on.png" clickimg="map/btn_select_10_off.png" target="*first_select_1"  enterse="cursor1.ogg" clickse="decision5.ogg" exp="f.first_select=f.first_select+1"]

*first_map_2
[if exp="f.first_map_2==1"]
[jump target="*first_map_3]
[else]
[endif]

;//２：生徒会室
[button name="role_button" x="704" y="230" graphic="map/btn_select_06_off.png" enterimg="map/btn_select_06_on.png" clickimg="map/btn_select_06_off.png" target="*first_select_2"  enterse="cursor1.ogg" clickse="decision5.ogg" exp="f.first_select=f.first_select+1"]

*first_map_3
[if exp="f.first_map_3==1"]
[jump target="*first_map_4]
[else]
[endif]

;//３：渡り廊下
[button name="role_button" x="259" y="340" graphic="map/btn_select_02_off.png" enterimg="map/btn_select_02_on.png" clickimg="map/btn_select_02_off.png" target="*first_select_3"  enterse="cursor1.ogg" clickse="decision5.ogg" exp="f.first_select=f.first_select+1"]

*first_map_4
[if exp="f.first_map_4==1"]
[jump target="*first_map_5]
[else]
[endif]

;//４：食堂
[button name="role_button" x="508" y="196" graphic="map/btn_select_05_off.png" enterimg="map/btn_select_05_on.png" clickimg="map/btn_select_05_off.png" target="*first_select_4"  enterse="cursor1.ogg" clickse="decision5.ogg" exp="f.first_select=f.first_select+1"]

*first_map_5

;//５：中庭テラス
[button name="role_button" x="378" y="273" graphic="map/btn_select_04_off.png" enterimg="map/btn_select_04_on.png" clickimg="map/btn_select_04_off.png" target="*first_select_5"  enterse="cursor1.ogg" clickse="decision5.ogg"]

[showmenubutton]

[s]

;--------------------------------------------------
;//■ルート『大変だ、遅刻する』
*first_select_end
[savetitle text="『大変だ、遅刻する』"]
;-------------------------------------------------
[bgm_end1]

;SE：チャイム
[se_f se="school_bell.ogg"]


[yuzuha_驚き]

[sayuri_驚き]


#
正在寻找前辈们却已响起预备铃的钟声。[p]

看来午休时间就要结束了。[p]

[vo vo="ep3/sayu_0035.ogg"]
[sayuri_哀]
#【稻饼 小百合】
「钟声响起来了呢」[p]
[sayuri_哀_c]

[vo vo="ep3/yuzu_0110.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「啊——……明明快要到关键部分了！」[p]
[yuzuha_哀_c]

#
明明差一点就能触及御伽俱乐部的秘密了。[p]

[vo vo="ep3/sayu_0036.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「没办法啦，放学后再找前辈们吧」[p]
[sayuri_微笑_c]

[vo vo="ep3/yuzu_0111.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「嗯～说得对……就这么办！」[p]
[yuzuha_哀_c]

#
要是能再多思考一会儿[r]　
前辈们究竟在哪里就好了，此刻后悔却为时已晚。[p]

;全キャラ削除
[allc]

[bgm_end2]

;//ブラックアウト
;//黒ベタ
[bg10 bg="black.png"]

后来虽然找到爱丽丝前辈并询问了御伽俱乐部的事。[p]

但不知为何爱丽丝前辈那时似乎已对我失去兴趣[r]　
不再理会我了。[p]

不过也因此免去了茶会邀约倒也不错……[p]

结果关于御伽俱乐部什么也没能问出来。[p]


;//終わり。[p]

;テキストウィンドウ削除
[end_text]

;//ルート『大変だ、遅刻する』おわり
[eval exp="sf.ep3_end5 = 1"]
[bg  storage="ep3_end_5.jpg" time="2000"]

;処理を停止します
[wait time="2000"]

;背景：暗転
[bg30 bg="black.png"]

;タイトル画面へ移動
[jump  storage="title_screen.ks"  target="*title"]

[s]

;//タイトル『大変だ、遅刻する』



;--------------------------------------------------
;//選択肢１：上級生の教室
*first_select_1
[savetitle text="上級生の教室"]
;-------------------------------------------------
[bgm_end1]

[eval exp="f.first_map_1=1"]

;選択肢ボタンクリア
[bgm_end1]
[cm]
[clearfix]


;//黒ベタ
[bg20 bg="black.png"]


;BGM再生
[bgm ogg="music.ogg"]

;//廊下
[bg10 bg="corridor.jpg"]

[yuzuha_微笑_c]
[lec cg="yuzuha"]

[sayuri_微笑_c]
[ric cg="sayuri"]


;テキストウィンドウ表示
[start_text_yuzu]

与小百合小姐一同来到高年级教室前。[p]

[vo vo="ep3/yuzu_0112.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「那个～爱丽丝前辈是几班来着？好像找不到呢」[p]
[yuzuha_疑問_c]

#
挨个教室张望却不见前辈们的身影。[p]

[vo vo="ep3/sayu_0037.ogg"]
[sayuri_照れ]
#【稻饼 小百合】
「比起这个，小柚叶，我们超级显眼哦？」[p]
[sayuri_照れ_c]

[vo vo="ep3/yuzu_0113.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「诶？为什么？」[p]
[yuzuha_微笑_c]

[vo vo="ep3/sayu_0038.ogg"]
[sayuri_照れ]
#【稻饼 小百合】
「因为这里是高年级的教室……[r]　
　你看，好像没人在，我们离开这里吧！」[p]
[sayuri_照れ_c]

[vo vo="ep3/yuzu_0114.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「唔嗯……不在这里啊～时间也不多了，要不要去别的地方看看」[p]
[yuzuha_微笑_c]



;//地図画面の選択肢へ
;シーン4へ移動
[jump target="*first_select"]

;--------------------------------------------------
;//選択肢２：生徒会室
*first_select_2
[savetitle text="生徒会室"]
;-------------------------------------------------

[eval exp="f.first_map_2=1"]

;選択肢ボタンクリア
[bgm_end1]
[cm]
[clearfix]


;//黒ベタ
[bg20 bg="black.png"]


;BGM再生
[bgm ogg="music.ogg"]

;//生徒会室
[bg10 bg="student_council.jpg"]

[yuzuha_微笑_c]
[lec_f cg="yuzuha"]

[sayuri_微笑_c]
[ric cg="sayuri"]

;テキストウィンドウ表示
[start_text_yuzu]

[vo vo="ep3/yuzu_0115.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「啊……虽然来到了学生会室……但一个人都没有呢」[p]
[yuzuha_哀_c]

[vo vo="ep3/sayu_0039.ogg"]
[sayuri_疑問]
#【稻饼 小百合】
「看起来是这样呢……不过为什么是学生会室？」[p]
[sayuri_疑問_c]

[vo vo="ep3/yuzu_0116.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「咦？爱丽丝前辈不是学生会长或干部之类的吗！？」[p]
[yuzuha_驚き_c]

[vo vo="ep3/sayu_0040.ogg"]
[sayuri_哀]
#【稻饼 小百合】
「嗯——……应该不是」[p]
[sayuri_哀_c]

#
糟糕了，只是凭印象就过来了。[p]

[vo vo="ep3/yuzu_0117.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「啊哈哈，对不起对不起」[p]
[yuzuha_微笑_c]

[sayuri_微笑_c]

#
必须明确决定该去哪里。[p]

[bgm_end1]

;//地図画面の選択肢へ
[jump target="*first_select"]


;-------------------------------------------------
;//選択肢３：渡り廊下
*first_select_3
[savetitle text="渡り廊下"]
;-------------------------------------------------

[eval exp="f.first_map_3=1"]

;選択肢ボタンクリア
[bgm_end1]
[cm]
[clearfix]


;//黒ベタ
[bg20 bg="black.png"]


;BGM再生
[bgm ogg="un_cafe.ogg"]

;//渡り廊下
[bg10 bg="connecting_corridor.jpg"]

[yuzuha_微笑_c]
[lec_f cg="yuzuha"]

[sayuri_微笑_c]
[ric cg="sayuri"]

;テキストウィンドウ表示
[start_text_yuzu]

[vo vo="ep3/sayu_0041.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「前辈们，找不到呢……」[p]
[sayuri_微笑_c]

[vo vo="ep3/yuzu_0118.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「哎呀——，不在这里吗？」[p]
[yuzuha_疑問_c]

[vo vo="ep3/sei2_0006.ogg"]
#【学生2】
「哎呀？[r]　
　小仓同学和稻饼小姐，在这种地方有什么事吗？」[p]

[vo vo="ep3/yuzu_0119.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「啊—，我们在找爱丽丝前辈……你知道吗？」[p]
[yuzuha_微笑_c]

[vo vo="ep3/sei2_0007.ogg"]
#【学生2】
「爱丽丝大人的话，这会儿应该在中庭的露台开茶会吧？」[p]

[vo vo="ep3/yuzu_0120.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「啊—！说起来确实这么说过！」[p]
[yuzuha_驚き_c]

#
知道爱丽丝前辈在哪里真是太好了。[p]

[vo vo="ep3/sei2_0008.ogg"]
#【学生2】
「莫非你们想参加茶会吗！？」[p]

[vo vo="ep3/yuzu_0121.ogg"]
[yuzuha_怒鳴る]
#【小仓 柚叶】
「不是不是，没这回事没这回事」[p]
[yuzuha_怒鳴る_c]

[bgm_end1]

;//地図画面の選択肢へ
[jump target="*first_select"]


;-------------------------------------------------
;//選択肢４：食堂
*first_select_4
[savetitle text="食堂"]
;-------------------------------------------------

[eval exp="f.first_map_4=1"]

;選択肢ボタンクリア
[bgm_end1]
[cm]
[clearfix]


;//黒ベタ
[bg20 bg="black.png"]


;BGM再生
[bgm ogg="4656.ogg"]

;//食堂
[bg10 bg="cafeteria.jpg"]

[yuzuha_微笑_c]
[lec_f cg="yuzuha"]

[sayuri_微笑_c]
[ric cg="sayuri"]

;テキストウィンドウ表示
[start_text_yuzu]

#
和小百合小姐一起来到了食堂。[p]

[vo vo="ep3/yuzu_0122.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「哈啊……咖喱看起来好好吃……！」[p]
[yuzuha_笑顔_c]

[vo vo="ep3/sayu_0042.ogg"]
[sayuri_呆れ]
#【稻饼 小百合】
「啊哈哈，明明刚才还一起吃了便当」[p]
[sayuri_呆れ_c]

[vo vo="ep3/yuzu_0123.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「抱歉抱歉，现在得先找爱丽丝学姐她们呢」[p]
[yuzuha_微笑_c]

#
环顾一下四周。[p]

但哪里都没看到。[p]

[vo vo="ep3/yuzu_0124.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「唔——，好像不在这里呢」[p]
[yuzuha_哀_c]

[vo vo="ep3/sayu_0043.ogg"]
[sayuri_疑問]
#【稻饼 小百合】
「是啊，或许该去别处找找看」[p]
[sayuri_疑問_c]

[vo vo="ep3/yuzu_0125.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「那就这样吧」[p]
[yuzuha_微笑_c]

[bgm_end1]

;//地図画面の選択肢へ
[jump target="*first_select"]



;-------------------------------------------------
;//選択肢５：中庭テラス
*first_select_5
[savetitle text="中庭テラス"]
;-------------------------------------------------

;選択肢ボタンクリア
[bgm_end1]
[cm]
[clearfix]


;//黒ベタ
[bg20 bg="black.png"]


[bg10 bg="terrace.jpg"]

;テキストウィンドウ表示
[start_text_yuzu]

[yuzuha_微笑_c]
[c3_f cg="yuzuha"]

[sayuri_微笑_c]
[c4 cg="sayuri"]

[vo vo="ep3/yuzu_0126.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「毕竟她们说过今天也要做的嘛……」[p]
[yuzuha_疑問_c]

#
虽然拒绝了参加，但单独过去应该没问题。[p]

[yuzuha_微笑_c]

那个场所的构造，与其称为中庭不如说是庭园更恰当。[p]

在花香氤氲的优雅角落，[r]　
恰到好处地摆放着桌椅。[p]

那个人就在那里。[p]

无比优雅地，宛如被收纳在画作中的人物们一般。[p]

;BGM再生
[bgm ogg="un_cafe.ogg"]

[alice_笑み_c]
[c2_f cg="alice"]

[kaguya_無表情_c]
[c1 cg="kaguya"]


[vo vo="ep3/alice_0016.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「哎呀，果然如我所料呢」[p]
[alice_笑み_c]

#
她手持茶杯斜睨过来，[p]

这句话让我后背窜过一阵颤栗。[p]

说起来爱丽丝学姐确实说过。[p]

「小仓柚叶……你迟早会主动来的」[p]

[vo vo="ep3/yuzu_0127.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「哎哟——，那个倒也不是这个意思啦……啊哈哈」[p]
[yuzuha_微笑_c]

#
不知该如何回应只好干笑着蒙混过去。[p]

就这样，我和小百合小姐来到了中庭露台。[p]

爱丽丝学姐和辉夜学姐正并肩站在那里。[p]

看起来他们正在课间提到的茶会中进行着。[p]

[vo vo="ep3/alice_0017.ogg"]
[alice_ドヤ顔]
#【饴宫 爱丽丝】
「呵呵，我的直觉可是很准的哦」[p]
[alice_ドヤ顔_c]

[vo vo="ep3/yuzu_0128.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「不，所以说我不是来参加茶会的啦」[p]
[yuzuha_微笑_c]

#
摇头甩开身体的颤抖。[p]

现在比起那种事，御伽俱乐部才是最重要的。[p]

[vo vo="ep3/yuzu_0129.ogg"]
[yuzuha_怒鳴る]
#【小仓 柚叶】
「小百合小姐！这两个人就是御伽俱乐部的会员！」[p]
[yuzuha_怒鳴る_c]

#
对身旁的小百合小姐这样宣告道。[p]

[vo vo="ep3/kaguya_0009.ogg"]
[kaguya_思考]
#【蓬 辉夜】
「御伽俱乐部？」[p]
[kaguya_思考_c]

#
听到我的发言，辉夜前辈皱起了眉头。[p]

[vo vo="ep3/kaguya_0010.ogg"]
[kaguya_無表情]
#【蓬 辉夜】
「你们，在哪里…」[p]

[vo vo="ep3/alice_0018.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「――辉夜」[p]
[kaguya_驚き]
[alice_笑み_c]

[vo vo="ep3/kaguya_0011.ogg"]
[kaguya_呆れ]
#【蓬 辉夜】
「……哈啊」[p]
[kaguya_呆れ_c]

[vo vo="ep3/yuzu_0130.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「那个……？」[p]
[yuzuha_疑問_c]

[kaguya_無表情_c]

[vo vo="ep3/alice_0019.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「哎呀怎么了？继续说吧小仓柚叶，让我听听？」[p]
[alice_笑み_c]

[vo vo="ep3/yuzu_0131.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「啊，是、是的……」[p]
[yuzuha_疑問_c]

#
总觉得节奏被打乱了。[p]

或者说希望你别再用全名称呼别人了。[p]

[vo vo="ep3/sayu_0044.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「小柚叶，为什么觉得前辈们是会员呢？」[p]
[sayuri_微笑_c]

[vo vo="ep3/yuzu_0132.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「是前辈们的名字啦」[p]

[vo vo="ep3/yuzu_0133.ogg"]
#【小仓 柚叶】
「爱丽丝前辈和辉夜前辈…[r]　
　两人的名字凑齐了童话故事里的角色名对吧！」[p]
[yuzuha_微笑_c]

[vo vo="ep3/sayu_0045.ogg"]
[sayuri_驚き]
#【稻饼 小百合】
「啊，确实…被你一说！」[p]
[sayuri_驚き_c]

[vo vo="ep3/yuzu_0134.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「所以大家都把她们所属的社团叫做御伽俱乐部！」[p]

[vo vo="ep3/yuzu_0135.ogg"]
#【小仓 柚叶】
「肯定是这样的！」[p]
[yuzuha_笑顔_c]

#
「哼哼！」　她挺起胸膛回答道。[p]

[vo vo="ep3/yuzu_0136.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「如何？黑十先生也被这推理能力吓呆了吧！」[p]
[yuzuha_笑顔_c]

[vo vo="ep3/alice_0020.ogg"]
[alice_ドヤ顔]
#【饴宫 爱丽丝】
「呵呵……呵呵呵呵」[p]
[alice_ドヤ顔_c]

#
有个人在嘲笑这样的我。[p]

[vo vo="ep3/yuzu_0137.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「爱丽丝前辈……？」[p]
[yuzuha_疑問_c]

[vo vo="ep3/alice_0021.ogg"]
[alice_ドヤ顔]
#【饴宫 爱丽丝】
「嘿～这样啊……所以你是说我们是那个俱乐部的会员咯」[p]
[alice_ドヤ顔_c]

[vo vo="ep3/yuzu_0138.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「难、难道不是吗？」[p]
[yuzuha_疑問_c]

[vo vo="ep3/alice_0022.ogg"]
[alice_ドヤ顔]
#【饴宫 爱丽丝】
「话说小仓柚叶，让我问你个问题……」[p]

[vo vo="ep3/alice_0023.ogg"]
#【饴宫 爱丽丝】
「你知道我们隶属于哪个俱乐部吗？」[p]
[alice_ドヤ顔_c]

[vo vo="ep3/yuzu_0139.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「那个，我不知道」[p]
[yuzuha_微笑_c]

[vo vo="ep3/alice_0024.ogg"]
[alice_ドヤ顔]
#【饴宫 爱丽丝】
「辉夜，你告诉她」[p]
[alice_ドヤ顔_c]

[vo vo="ep3/kaguya_0012.ogg"]
[kaguya_無表情]
#【蓬 辉夜】
「……茶道部」[p]
[kaguya_無表情_c]

[vo vo="ep3/yuzu_0140.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「所以说这才是御伽俱乐部的真面目啦！」[p]
[yuzuha_微笑_c]

[vo vo="ep3/kaguya_0013.ogg"]
[kaguya_無表情]
;//箏曲部（そうきょくぶ）
#【蓬 辉夜】
「另外还有花道部、弓道部、筝曲部……[r]　
　还有几个其他挂名的俱乐部哦」[p]
[kaguya_無表情_c]

[vo vo="ep3/yuzu_0141.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「…………会不会太多了？」[p]
[yuzuha_疑問_c]

#
意外的回答让我脑子一片混乱。[p]

[vo vo="ep3/alice_0025.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「我也在很多俱乐部挂名呢」[p]

[vo vo="ep3/alice_0026.ogg"]
#【饴宫 爱丽丝】
「那么，到底哪个才是那个御伽俱乐部呢？」[p]
[alice_笑み_c]

[vo vo="ep3/yuzu_0142.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「呃，呃那个……」[p]
[yuzuha_哀_c]

[vo vo="ep3/sayu_0046.ogg"]
[sayuri_哀]
#【稻饼 小百合】
「小柚叶，是不是搞错了呀？」[p]
[sayuri_哀_c]

#
小百合小姐小声说道。[p]

确实我的想法可能是错的。[p]

[vo vo="ep3/alice_0027.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「或者说我们所属的所有社团都是御伽俱乐部吗？」[p]
[alice_笑み_c]

[vo vo="ep3/yuzu_0143.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「对、对不起，好像不是这样的」[p]

[vo vo="ep3/yuzu_0144.ogg"]
#【小仓 柚叶】
「嗯……真奇怪呢……」[p]
[yuzuha_哀_c]

[vo vo="ep3/alice_0028.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「呵呵，看来是这样呢，小仓柚叶」[p]
[alice_笑み_c]

#
与板着脸的我形成鲜明对比，爱丽丝学姐开心地笑着。[p]

[vo vo="ep3/kaguya_0014.ogg"]
[kaguya_呆れ]
#【蓬 辉夜】
「爱丽丝，适可而止怎么样？」[p]
[kaguya_呆れ_c]

#
辉夜学姐责备了那样的爱丽丝学姐。[p]

[vo vo="ep3/alice_0029.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「哎呀抱歉，因为实在太有趣了」[p]
[alice_笑み_c]

[vo vo="ep3/kaguya_0015.ogg"]
[kaguya_無表情]
#【蓬 辉夜】
「真是的……」[p]
[kaguya_無表情_c]

[vo vo="ep3/alice_0030.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「你们也抱歉，不用在意」[p]
[alice_笑み_c]

[vo vo="ep3/yuzu_0145.ogg"]
[yuzuha_怒]
#【小仓 柚叶】
「……明明觉得很有趣」[p]
[yuzuha_怒_c]

[vo vo="ep3/alice_0031.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「因为关于御伽俱乐部[r]　
　说了太多离谱的事情还很自豪的样子」[p]
[alice_笑み_c]

#
像是突然想起来似的，爱丽丝学姐又笑了。[p]

[vo vo="ep3/sayu_0047.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「那个，从语气来看，[r]　
　学姐们也知道御伽俱乐部的传闻吗？」[p]
[sayuri_微笑_c]

[vo vo="ep3/yuzu_0146.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「咦？真是这样吗？」[p]
[yuzuha_疑問_c]

[vo vo="ep3/alice_0032.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「嗯，当然知道哦」[p]
[alice_笑み_c]

#
爱丽丝学姐知道御伽俱乐部的事情。[p]

也就是说，[r]　
她从一开始就知道我的推理是错误的。[p]

[vo vo="ep3/yuzu_0147.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「呜啊啊，不对的话就早点说嘛——！」[p]
[yuzuha_哀_c]

[vo vo="ep3/alice_0033.ogg"]
[alice_ドヤ顔]
#【饴宫 爱丽丝】
「因为在我面前高兴地汪汪叫，[r]　
　让我忍不住嘛」[p]
[alice_ドヤ顔_c]

#
浮现出恶作剧般笑容的爱丽丝前辈。[p]

看着那个身影，我终于明白自己为何对此人感到棘手。[p]

这种把人当傻瓜的态度，和姐姐很像。[p]

[vo vo="ep3/yuzu_0148.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「哈……真是糟透了」[p]
[yuzuha_哀_c]

[vo vo="ep3/kaguya_0016.ogg"]
[kaguya_無表情]
#【蓬 辉夜】
「你们为什么知道御伽俱乐部的事情？」[p]
[kaguya_無表情_c]

#
垂头丧气的我被无视了，辉夜前辈向小百合小姐询问道。[p]

[vo vo="ep3/sayu_0048.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「班级里流传着谣言呢」[p]
[sayuri_微笑_c]

;//下記台詞、途中でハッとしてなにかに気づく輝夜。[p]
;//柚葉がここへ来るようにアリスがわざと流した噂だと気づいた。[p]

[vo vo="ep3/kaguya_0017.ogg"]
[kaguya_驚き]
#【蓬 辉夜】
「谣言…………爱丽丝、你……」[p]
[kaguya_驚き_c]

[vo vo="ep3/alice_0034.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「哎呀辉夜，杯子空了呢？」[p]
[alice_笑み_c]

[vo vo="ep3/kaguya_0018.ogg"]
[kaguya_呆れ]
#【蓬 辉夜】
「哈啊……真受不了」[p]
[kaguya_呆れ_c]

[vo vo="ep3/sayu_0049.ogg"]
[sayuri_哀]
#【稻饼 小百合】
「那个、这是怎么……」[p]
[sayuri_哀_c]

[vo vo="ep3/alice_0035.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「对对、其实我们也在找那个御伽俱乐部哦」[p]
[alice_笑み_c]

[kaguya_無表情_c]

[sayuri_驚き_c]
#
小百合小姐的提问被爱丽丝学姐刻意打断。[p]

这也是希望从一开始就被告知的事。[p]

到现在这或许已经是无关紧要的事了。[p]

[sayuri_微笑_c]

[vo vo="ep3/yuzu_0149.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「原来是这样的吗？」[p]
[yuzuha_驚き_c]

[vo vo="ep3/alice_0036.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「是的，而且我们已经[r]　
　连御伽俱乐部在哪里都知道了」[p]
[alice_笑み_c]

#
所谓知道究竟是什么意思呢。[p]

明明知道所在之处的东西，[r]　
　根本没必要刻意去寻找。[p]

[vo vo="ep3/yuzu_0150.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「您这话是什么意思？」[p]
[yuzuha_疑問_c]

#
爱丽丝前辈的话语，让原本垂头丧气的我不禁被吸引了注意力。[p]

[vo vo="ep3/alice_0037.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「有一个谜团哦」[p]
[alice_笑み_c]

#
谜。[p]

我自己也清楚 这个词语再次点燃了我内心的火焰。[p]

;カットイン表示
[cut_in cut="cut_kami.png"]

爱丽丝前辈取出一张纸。[p]

纸张褪色得一眼就能看出是年代久远之物。[p]

[vo vo="ep3/alice_0038.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「这里写着御伽俱乐部的活动地点」[p]
[alice_真顔_c]

;カットイン削除
[cut_out]

#
爱丽丝前辈将那张纸在桌上摊开。[p]

和小百合小姐交换眼神后 我忍不住凑近桌前。[p]

然后探头看向那张据说[r]　
记载着御伽俱乐部活动场所的纸。[p]

上面只写着一行字：[p]

『学园的□』[p]

[vo vo="ep3/yuzu_0151.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「学园的……咦 这是什么东西」[p]
[yuzuha_疑問_c]

#
这确实是个谜。[p]

虽说是记载着地点[r]　
但这样根本无从得知具体位置。[p]

[vo vo="ep3/alice_0039.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「所以我们也搞不明白啊」[p]

[vo vo="ep3/alice_0040.ogg"]
#【饴宫 爱丽丝】
「本来还想着终于能知道御伽俱乐部的所在地了呢」[p]
[alice_真顔_c]

[vo vo="ep3/yuzu_0152.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「就是说啊……唔——不过 这到底是什么意思呢」[p]

[vo vo="ep3/yuzu_0153.ogg"]
#【小仓 柚叶】
「这上面写的是御伽俱乐部的活动场所对吧？」[p]
[yuzuha_疑問_c]

[vo vo="ep3/alice_0041.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「嗯 没错」[p]
[alice_真顔_c]

#
原来如此。[p]

但写着这种东西根本没法知道。[p]

正当我盯着写有『学园的□』的纸张时[r]　
突然被人抽走了。[p]

[vo vo="ep3/alice_0042.ogg"]
[alice_ドヤ顔]
#【饴宫 爱丽丝】
「呵呵，到此为止」[p]
[alice_ドヤ顔_c]

[vo vo="ep3/yuzu_0154.ogg"]
[yuzuha_怒]
#【小仓 柚叶】
「啊～你要做什么啦！」[p]
[yuzuha_怒_c]

[vo vo="ep3/alice_0043.ogg"]
[alice_ドヤ顔]
#【饴宫 爱丽丝】
「原来如此，看来你对这个谜题很感兴趣呢」[p]
[alice_ドヤ顔_c]

[vo vo="ep3/yuzu_0155.ogg"]
[yuzuha_怒鳴る]
#【小仓 柚叶】
「没错！我超想知道这到底是什么意思！」[p]
[yuzuha_怒鳴る_c]

[vo vo="ep3/alice_0044.ogg"]
[alice_ドヤ顔]
#【饴宫 爱丽丝】
「那么……这样吧……我们来比试一场」[p]
[alice_ドヤ顔_c]

#
爱丽丝前辈露出思索的表情说道。[p]

但这句话听起来像早就准备好了似的。[p]

恐怕她从一开始就预料到这个局面。[p]

[vo vo="ep3/alice_0045.ogg"]
[alice_ドヤ顔]
#【饴宫 爱丽丝】
「如果小仓柚叶解不开这个谜题[r]　
　就要来参加我的茶会」[p]
[alice_ドヤ顔_c]

[vo vo="ep3/yuzu_0156.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「茶、茶会……？」[p]
[yuzuha_驚き_c]

[vo vo="ep3/alice_0046.ogg"]
[alice_ドヤ顔]
#【饴宫 爱丽丝】
「没错……反之要是能解开谜题[r]　
　我就再也不会邀请你参加茶会」[p]

[vo vo="ep3/alice_0047.ogg"]
#【饴宫 爱丽丝】
「彻底放弃小仓柚叶……怎么样？」[p]

[vo vo="ep3/alice_0048.ogg"]
#【饴宫 爱丽丝】
「不仅能知道你在意的御伽俱乐部情报[r]　
　还不会再被骚扰」[p]

[vo vo="ep3/alice_0049.ogg"]
#【饴宫 爱丽丝】
「如何？条件不错吧？」[p]
[alice_ドヤ顔_c]

[vo vo="ep3/sayu_0050.ogg"]
[sayuri_哀]
#【稻饼 小百合】
「小柚叶……你要怎么做？」[p]
[sayuri_哀_c]

#
对小百合小姐来说，爱丽丝前辈的提议似乎让她兴致不高。[p]

她大概觉得拒绝比较好。[p]

可我……[p]

[vo vo="ep3/yuzu_0157.ogg"]
[yuzuha_怒鳴る]
#【小仓 柚叶】
「这个挑战，我接下了！！」[p]
[yuzuha_怒鳴る_c]

斗志满满地喊道。[p]

[vo vo="ep3/sayu_0051.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「啊哈哈，果然会变成这样呢……」[p]
[sayuri_微笑_c]

#
对于愿意陪我的小百合小姐[r]　
我可能做了件坏事。[p]

不过反正我会在意这个谜团直到解决为止。[p]

以我的性格，这是无法回避的。[p]

[vo vo="ep3/alice_0050.ogg"]
[alice_ドヤ顔]
#【饴宫 爱丽丝】
「那太好了，那这个就先交给你保管咯」[p]
[alice_ドヤ顔_c]

#
爱丽丝学姐爽快地将纸条递给了我。[p]

[vo vo="ep3/kaguya_0019.ogg"]
[kaguya_呆れ]
#【蓬 辉夜】
「唉……明明警告过你了」[p]
[kaguya_呆れ_c]

#
相反辉夜学姐似乎正抱着脑袋发愁。[p]

看来爱丽丝学姐麻烦的部分[r]　
辉夜学姐早已了如指掌。[p]

[vo vo="ep3/alice_0051.ogg"]
[alice_ドヤ顔]
#【饴宫 爱丽丝】
「那就祝你成功解开御伽俱乐部的谜题咯」[p]
[alice_ドヤ顔_c]

[kill]

[yuzuha_微笑_c]
[lec_f cg="yuzuha"]

[sayuri_微笑_c]
[ric cg="sayuri"]

#
说完这番话，两位学姐离开了这个过分豪华的露台。[p]

[vo vo="ep3/yuzu_0158.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「哈啊～突然觉得好累啊……[r]　
　啊，小百合小姐对不起哦」[p]
[yuzuha_微笑_c]

[vo vo="ep3/sayu_0052.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「我倒是不介意……[r]　
　可是你真的要接受那种比试吗？」[p]
[sayuri_微笑_c]
#
不顾满脸担忧的小百合小姐，[r]　
我倒没有那么悲观。[p]

这其中自然有我的道理。[p]

[vo vo="ep3/yuzu_0159.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「没关系！我有可靠的神秘武器！」[p]
[yuzuha_笑顔_c]

#
没错，那个人能解答我所有的疑问。[p]

[vo vo="ep3/sayu_0053.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「你该不会是说……」[p]
[sayuri_微笑_c]

[vo vo="ep3/yuzu_0160.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「嗯！关键时刻就让黑十先生来解谜吧！」[p]
[yuzuha_笑顔_c]

[sayuri_哀_c]

#
与我挺起胸膛微笑的样子形成鲜明对比，小百合小姐的表情却更加阴沉。[p]

[vo vo="ep3/yuzu_0161.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「小百合小姐？怎么了？看你愁眉不展的」[p]
[yuzuha_微笑_c]

[vo vo="ep3/sayu_0054.ogg"]
[sayuri_哀]
#【稻饼 小百合】
「那个、小柚叶……这话很难开口……[r]　
　这次黑十先生可能不行吧？」[p]
[sayuri_哀_c]

[vo vo="ep3/yuzu_0162.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「哎！？为、为什么为什么！？」[p]
[yuzuha_驚き_c]

[vo vo="ep3/sayu_0055.ogg"]
[sayuri_哀]
#【稻饼 小百合】
「因为这里……别说外人了，根本是男性禁区吧？」[p]
[sayuri_哀_c]

#
这句话让我的脸色瞬间变得惨白。[p]

[bgm_end2]

;//時間経過・場面移動
;テキストウィンドウ削除
[end_text]

;全キャラ削除
[allc]

;//黒ベタ
[bg10 bg="black.png"]

;//停止
[wait time=2000]

;//教室
[bg10 bg="school.jpg"]

;BGM再生
[bgm ogg="music.ogg"]

[yuzuha_微笑_c]
[lec_f cg="yuzuha"]

[sayuri_微笑_c]
[ric cg="sayuri"]

;テキストウィンドウ表示
[start_text_yuzu]

[vo vo="ep3/yuzu_0163.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「啊啊啊怎么办……[r]　
　没想到这里居然是禁止男性入内的女校……！！」[p]
[yuzuha_哀_c]

[vo vo="ep3/sayu_0056.ogg"]
[sayuri_呆れ]
#【稻饼 小百合】
「不不、再怎么说也该发现了吧」[p]
[sayuri_呆れ_c]

#
下课后的休息时间。[p]

面对垂头丧气的我，小百合小姐露出苦笑。[p]

[vo vo="ep3/yuzu_0164.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「那个当然是开玩笑啦……唉……」[p]
[yuzuha_微笑_c]

#
完全没料到作为最后依靠的黑十先生居然无法召唤[r]　
这种事。[p]

这次的谜题如果不在学校范围内[r]　
就无论如何都解决不了。[p]

也就是说，[r]　
意味着必须靠我们自己来解开这个谜团。[p]

[bgm_end2]

[vo vo="ep3/sayu_0057.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「总之现在再稍微想想这个谜题吧？」[p]
[sayuri_微笑_c]

[vo vo="ep3/yuzu_0165.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「……嗯，说得对！谢谢你小百合小姐！我会努力的！」[p]
[yuzuha_笑顔_c]

;BGM再生
[bgm ogg="tukikage.ogg"]

#
把刚才爱丽丝前辈给的羊皮纸在桌上摊开。[p]

上面果然只写着『学园的□』这几个字。[p]

[vo vo="ep3/yuzu_0166.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「学园的……那个啥、来着……」[p]
[yuzuha_微笑_c]

#
这个空白处究竟会填入什么呢。[p]

[vo vo="ep3/yuzu_0167.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「既然说是记载着御伽俱乐部的地点，[r]　
　果然应该在校内某处吧？」[p]
[yuzuha_疑問_c]

[vo vo="ep3/sayu_0058.ogg"]
[sayuri_驚き]
#【稻饼 小百合】
「咦、等、等一下」[p]
[sayuri_驚き_c]

[vo vo="ep3/yuzu_0168.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「诶？」[p]
[yuzuha_疑問_c]

#
听到我的话，小百合小姐似乎有些动摇。[p]

[vo vo="ep3/sayu_0059.ogg"]
[sayuri_驚き]
;//読み方『学園の□』→学園のくち
#【稻饼 小百合】
「这个、应该读作学院的『口』字吧？」[p]
[sayuri_驚き_c]

[vo vo="ep3/yuzu_0169.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「啊？口字……」[p]
[yuzuha_疑問_c]

#
被她这么一说 我再次看向纸上写的谜题。[p]

『学园的□』[p]

[vo vo="ep3/yuzu_0170.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「啊！的、的确也可以这么读！」[p]

[vo vo="ep3/yuzu_0171.ogg"]
#【小仓 柚叶】
「我还一直以为是填空题呢！小百合小姐好厉害！」[p]
[yuzuha_笑顔_c]

[vo vo="ep3/sayu_0060.ogg"]
[sayuri_照れ]
#【稻饼 小百合】
「是吗？啊、不过我也是擅自认为是口字……[r]　
　说不定搞错了呢」[p]
[sayuri_照れ_c]

#
但多亏小百合小姐 或许找到了一个突破口。[p]

[vo vo="ep3/yuzu_0172.ogg"]
[yuzuha_微笑]
;//読み方『学園の□』→学園のくち
#【小仓 柚叶】
「说到学院的口字……」[p]
[yuzuha_微笑_c]

[bgm_end2]

;全キャラ削除
[allc]


;シーン5へ移動
[jump  storage="ep3_scene05.ks"]
[s]