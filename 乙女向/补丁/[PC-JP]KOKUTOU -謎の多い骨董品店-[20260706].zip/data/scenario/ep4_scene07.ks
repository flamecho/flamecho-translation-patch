﻿;--------------------------------------------------
;■黒十　本文テキスト　ep4　鐘塔の幽霊
;--------------------------------------------------
;
;■ep4_scene07
;
;--------------------------------------------------
[cm]

;BGM再生
[bgm ogg="mid_re.ogg"]

;//背景：鐘塔廊下２
[bg20 bg="chapel_corridor_02.jpg"]

[kokutou_哀2_c]
[ce cg="kokutou"]

;テキストウィンドウ表示
[start_text]

#
柚叶君爬上梯子已经过了多久呢。[p]

完全没有要回来的迹象。[p]

[vo vo="ep4/koku_0142.ogg"]
[kokutou_呆れ]
#【黒十 美鹤】
「不仅如此，好像还听到了什么奇怪的歌声……」[p]
[kokutou_呆れ_c]

#
但此刻又恢复成最初的寂静。[p]

[kokutou_真顔_c]

但愿她能顺利调查完[r]　
平安返回才好啊——虽然不敢确定。[p]

原本该由我亲自爬上去才是，[r]　
终究还是做不到。[p]

只盼望钟塔里[r]　
能留有指向人类活动痕迹的线索。[p]


[vo vo="ep4/koku_0143.ogg"]
[kokutou_哀2]
#【黒十 美鹤】
「……话虽如此」[p]
[kokutou_哀2_c]

#
想到这里，我又苦恼地抱住了头。[p]

即便存在人类活动的痕迹，[r]　
究竟如何登上钟塔的谜题仍未解决。[p]

虽然确实能通过我当垫脚石让柚叶君爬上去。[p]

但实在难以想象那个引发幽灵骚动的犯人[r]　
会用同样的方式登顶。[p]

当时无论是柚叶君还是饴宫爱丽丝，[r]　
都是抓着近乎断裂的梯子勉强攀爬。[p]

有我来当踏脚石尚且如此费力。[p]

这所学园里真的存在[r]　
与我身高相仿的女学生吗？[p]

倒也不能断言绝对没有……[p]

[vo vo="ep4/koku_0144.ogg"]
[kokutou_呆れ]
#【黒十 美鹤】
「哈……果然这条线索很薄弱，吧」[p]
[kokutou_呆れ_c]

#
这样想是很自然的。[p]

那到底该怎么去钟塔呢。[p]

;全キャラ削除
[allc]

;BGM停止
[bgm_end3]

;//黒背景
[bg20 bg="black.png"]

在当场思考也想不出任何头绪。[p]

想着柚叶君也不会马上回来，[r]　
决定先回到礼拜堂。[p]

;BGM再生
[bgm ogg="church.ogg"]

;//背景：礼拝堂内
[bg20 bg="chapel_room_01.jpg"]

要重新思考似乎需要先整理信息。[p]

回到礼拜堂时，恰巧礼拜堂的主人就在那里。[p]

[lec_f cg="kokutou"]

[tukasa_笑顔]
[ric cg="tukasa"]

[vo vo="ep4/hagino_0058.ogg"]
#【萩乃司】
「啊，怎么样？幽灵的真面目，弄清楚了吗？」[p]
[tukasa_笑顔_c]

[vo vo="ep4/koku_0145.ogg"]
[kokutou_哀2]
#【黒十 美鹤】
「很遗憾……不好意思，[r]　
　能再给我讲讲幽灵传闻的事吗？」[p]
[kokutou_哀2_c]

[vo vo="ep4/hagino_0059.ogg"]
[tukasa_笑顔]
#【萩乃司】
「没问题，完全没关系哦」[p]
[tukasa_笑顔_c]

#
她微微露出笑容，[r]　
礼拜堂的主人像最初那样重新解释了这场幽灵骚动。[p]

但最终还是没有想出什么头绪。[p]

[vo vo="ep4/hagino_0060.ogg"]
[tukasa_苦笑い]
#【萩乃司】
「唔——，看起来很难呢」[p]
[tukasa_苦笑い_c]

#
对于陷入沉思的我，萩乃小姐体贴地挤出笑容。[p]

[vo vo="ep4/hagino_0061.ogg"]
[tukasa_笑顔]
#【萩乃司】
「不过对我来说，你们能来真是帮大忙了」[p]

[vo vo="ep4/hagino_0062.ogg"]
#【萩乃司】
「多亏你们弥撒应该能准时举行了，非常感谢」[p]
[tukasa_笑顔_c]

[vo vo="ep4/koku_0146.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「啊不不，我倒也没什么……弥撒什么时候开始？」[p]
[kokutou_真顔_c]

[vo vo="ep4/hagino_0063.ogg"]
[tukasa_笑顔]
#【萩乃司】
「圣诞前夜和圣诞节当日共两天，[r]　
　上午也会举行的哦」[p]

[vo vo="ep4/hagino_0064.ogg"]
#【萩乃司】
「伊芙节当天也预定向公众开放，方便的话请务必来玩！」[p]
[tukasa_笑顔_c]

[vo vo="ep4/koku_0147.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「…………从什么时候开始的……？」[p]
[kokutou_疑問_c]

[bgm_end1]

#
对自己提出的问题，感觉似乎有什么不对劲。[p]

说起来总觉得有哪里不自然。[p]

[vo vo="ep4/koku_0148.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「关于这座钟塔的幽灵传闻开始流传[r]　
　具体是从什么时候开始的来着？」[p]
[kokutou_真顔_c]

[vo vo="ep4/hagino_0065.ogg"]
[tukasa_疑問]
#【萩乃司】
「呃……大概是这个月月初吧」[p]
[tukasa_疑問_c]

[vo vo="ep4/koku_0149.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「这个月月初……」[p]
[kokutou_疑問_c]

#
几乎在同一时期还发生了另一件事。[p]

当然那个消息也是来到此处后才得知的。[p]

那就是――。[p]

;BGM再生
[bgm ogg="tukikage.ogg"]

[vo vo="ep4/koku_0150.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「那么再问一个……[r]　
　旧校舍的拆除通知是什么时候公布的？」[p]
[kokutou_真顔_c]


[kokutou_驚き_c]

[vo vo="ep4/hagino_0066.ogg"]
[tukasa_疑問]
#【萩乃司】
「也是这个月……不过这有什么问题吗？」[p]
[tukasa_疑問_c]


#
此时此刻，笼罩着礼拜堂与钟塔的迷雾骤然散尽。[p]

[vo vo="ep4/koku_0151.ogg"]
[kokutou_凛]
#【黒十 美鹤】
「……原来如此，是这么回事啊」[p]
[kokutou_凛_c]

#
虽然苦恼许久，但终于像是触碰到真相了。[p]

关于钟塔的幽灵――及其真身。[p]

[vo vo="ep4/koku_0152.ogg"]
[kokutou_凛]
#【黒十 美鹤】
「看来我……似乎抓住了幽灵呢，柚叶君」[p]
[kokutou_凛_c]

#
当我如此低语时，通往钟塔的走廊恰好喧闹起来。[p]

看来是她回来了。[p]

[kill]

[yuzuha_微笑]
[c4_f cg="yuzuha"]

[kokutou_微笑_c]
[c3_f cg="kokutou"]

[tukasa_笑顔_c]
[ri cg="tukasa"]

[vo vo="ep4/yuzuha_0191.ogg"]
#【小仓 柚叶】
「黑十先生，对不起我来晚了！」[p]
[yuzuha_微笑_c]

[vo vo="ep4/koku_0153.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「不，比起那个，情况如何，[r]　
　钟塔那边，顺利登到顶了吗？」[p]
[kokutou_微笑_c]

[vo vo="ep4/yuzuha_0192.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「超级高的！夜景超级漂亮！」[p]
[yuzuha_笑顔_c]

[vo vo="ep4/koku_0154.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「啊哈哈，不，我不是问那个……」[p]


[vo vo="ep4/koku_0155.ogg"]
#【黒十 美鹤】
「有没有什么东西掉下来？」[p]

[vo vo="ep4/koku_0156.ogg"]
[kokutou_凛]
#【黒十 美鹤】
「比方说……对了，比如怀表之类的」[p]
[kokutou_凛_c]

#
听到我的话，柚叶君瞪圆了眼睛露出惊讶的表情。[p]

[vo vo="ep4/yuzuha_0193.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「好厉害，您怎么知道的！？」[p]
[yuzuha_驚き_c]

#
看来我的推测是正确的。[p]

看到我因猜中而忍不住笑起来，[r]　
柚叶君突然反应过来。[p]

[vo vo="ep4/yuzuha_0194.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「黑十先生，难道说……」[p]
[yuzuha_驚き_c]

[vo vo="ep4/koku_0157.ogg"]
[kokutou_凛]
#【黒十 美鹤】
「没错，我搞清楚幽灵的真身了」[p]
[kokutou_凛_c]

#
;テキストウィンドウ削除
[end_text]

;BGM停止
[bgm_end3]

;全キャラ削除
[allc]

;背景
[bg10 bg="white.png"]

;次のシーンへ移動
[jump  storage="ep4_scene08.ks"]

[s]


;//断るを選んだ場合
;--------------------------------------------------
*072000
[savetitle text="断る"]
;--------------------------------------------------

[kill]

[alice_驚き_c]
[lec_f cg="alice"]

[kokutou_呆れ]
[ric cg="kokutou"]

[vo vo="ep4/koku_0158.ogg"]
#【黒十 美鹤】
「……我拒绝」[p]
[kokutou_呆れ_c]

[vo vo="ep4/alice_0104.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「哎呀？是我听错了吗，[r]　
　总觉得刚才听到了非常无聊的玩笑呢」[p]
[alice_笑み_c]

[vo vo="ep4/koku_0159.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「既不是听错，也不是玩笑哦」[p]
[kokutou_真顔_c]

[vo vo="ep4/alice_0105.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「哼嗯……」[p]
[alice_真顔_c]

#
碧眼的大小姐对我的话回以片刻的严肃凝视。[p]

[vo vo="ep4/alice_0106.ogg"]
[alice_呆れ2]
#【饴宫 爱丽丝】
「……也罢，随你便吧」[p]
[alice_呆れ2_c]

#
但很快她又嗤笑一声，转身扬长而去。[p]

;1キャラ消去
[hide_alice]


[kokutou_呆れ_c]
那离去的背影有点可怕，不过应该没问题吧。[p]

[vo vo="ep4/yuzuha_0195.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「黑十先生，那个，让她走掉真的可以吗？」[p]
[yuzuha_疑問_c]

[vo vo="ep4/koku_0160.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「好的，拜托了」[p]
[kokutou_真顔_c]


;全キャラ削除
[allc]


[kokutou_真顔]
[ce cg="kokutou"]
[kokutou_真顔_c]


#
我点头后，柚叶君略显尴尬地朝着里面走去。[p]

虽然让她独自前去也令人担心，[r]　
但让饴宫家的大小姐同行反而更让人不安。[p]

[vo vo="ep4/koku_0161.ogg"]
[kokutou_哀2]
#【黒十 美鹤】
「……那么，但愿柚叶君能找到些[r]　
　类似线索的东西吧」[p]
[kokutou_哀2_c]

#
但愿她能顺利调查完[r]　
平安返回才好啊——虽然不敢确定。[p]

原本该由我亲自爬上去才是，[r]　
终究还是做不到。[p]

只知道有人去过钟塔[r]　
现在只能祈祷存在些蛛丝马迹。[p]

[vo vo="ep4/koku_0162.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「……话虽如此」[p]
[kokutou_疑問_c]

#
想到这里，我又苦恼地抱住了头。[p]

即便存在人类活动的痕迹，[r]　
究竟如何登上钟塔的谜题仍未解决。[p]

虽然确实能通过我当垫脚石让柚叶君爬上去。[p]

但实在难以想象那个引发幽灵骚动的犯人[r]　
会用同样的方式登顶。[p]

那时，柚叶君似乎勉强抓住了[r]　
即将断裂的梯子向上攀爬。[p]

有我来当踏脚石尚且如此费力。[p]

这所学园里真的存在[r]　
与我身高相仿的女学生吗？[p]

倒也不能断言绝对没有……[p]

[vo vo="ep4/koku_0163.ogg"]
[kokutou_哀2]
#【黒十 美鹤】
「哈……果然这条线索很薄弱，吧」[p]
[kokutou_哀2_c]

#
这样想是很自然的。[p]

那到底该怎么去钟塔呢。[p]

;全キャラ削除
[allc]

;BGM停止
[bgm_end3]

;//黒背景
[bg20 bg="black.png"]

在当场思考也想不出任何头绪。[p]

想着柚叶君也不会马上回来，[r]　
决定先回到礼拜堂。[p]

;BGM再生
[bgm ogg="church.ogg"]

;//背景：礼拝堂内
[bg20 bg="chapel_room_04.jpg"]

[kokutou_哀2_c]
[ce cg="kokutou"]

要重新思考似乎需要先整理信息。[p]

但完全找不到思考的头绪。[p]

要找谁打听看看吗？[p]

[vo vo="ep4/koku_0164.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「那么，该怎么办呢」[p]
[kokutou_真顔_c]

;//選択肢

;//碧眼のご令嬢に話を聞く
;//黒髪の少女に話を聞く
;//礼拝堂の主に話を聞く
#
[glink x="266" y="136" graphic="txtlink.png" width="712"  size="28" text="碧眼のご令嬢に話を聞く" storage="ep4_scene07.ks" target="*073000"]
[glink x="266" y="249" graphic="txtlink.png" width="712" size="28" text="黒髪の少女に話を聞く" storage="ep4_scene07.ks" target="*074000"]
[glink x="266" y="362" graphic="txtlink.png" width="712" size="28" text="礼拝堂の主に話を聞く" storage="ep4_scene07.ks" target="*075000"]
[s]



;//碧眼のご令嬢に話を聞く
;--------------------------------------------------
*073000
[savetitle text="碧眼のご令嬢に話を聞く"]
;--------------------------------------------------


[vo vo="ep4/koku_0165.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「…………认真的吗？」[p]
[kokutou_驚き_c]

#
自己被脑海中浮现的想法吓了一跳。[p]

居然偏偏想去找那个饴宫爱丽丝打听。[p]

况且先前她说想去钟塔时我还拒绝了。[p]

现在要是贸然招惹，不知道会被她怎么冷嘲热讽。[p]

[vo vo="ep4/koku_0166.ogg"]
[kokutou_哀2]
#【黒十 美鹤】
「……可是也没有其他线索」[p]
[kokutou_哀2_c]

;全キャラ削除
[allc]

[bgm_end2]


#
无奈之下开始搜寻那个金发碧眼少女的身影。[p]

;//背景：礼拝堂内
[bg20 bg="chapel_room_01.jpg"]


[kokutou_哀2_c]
[lec_f cg="kokutou"]

[alice_真顔_c]
[ric cg="alice"]


她正在礼拜堂里怔怔望着十字架。[p]

;BGM再生
[bgm ogg="mid_re.ogg"]

那目光简直像在瞪人，[r]　
但或许只是因为他原本的长相和性格才给人这种错觉。[p]

像这样紧闭双唇保持沉默时，[r]　
竟会让人觉得明明是位美丽女性呢。[p]

[vo vo="ep4/alice_0107.ogg"]
[alice_退屈]
#【饴宫 爱丽丝】
「你正在想什么失礼的事对吧」[p]
[alice_退屈_c]

#
饴宫爱丽丝没有看向我这边就突然开口。[p]

显然被她发现我在注视已是蠢事，[r]　
甚至连内心想法似乎都暴露无遗。[p]

担心心思写在脸上，我下意识用手捂住嘴角。[p]

[vo vo="ep4/alice_0108.ogg"]
[alice_呆れ]
#【饴宫 爱丽丝】
「看你的样子，[r]　
　似乎还没想明白该怎么登上钟塔呢」[p]
[alice_呆れ_c]

[vo vo="ep4/koku_0167.ogg"]
[kokutou_哀2]
#【黒十 美鹤】
「呃，这个嘛……」[p]
[kokutou_哀2_c]

[vo vo="ep4/alice_0109.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「你总该发现之前的办法行不通吧？」[p]
[alice_真顔_c]

#
看来她也理解到[r]　
我们俩并非结伴前往钟塔的事实。[p]

[vo vo="ep4/koku_0168.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「要是柚叶君能发现什么线索就太好啦」[p]
[kokutou_真顔_c]

[vo vo="ep4/alice_0110.ogg"]
[alice_呆れ]
#【饴宫 爱丽丝】
「什么线索……具体指什么？」[p]
[alice_呆れ_c]

#
她将视线从十字架移开，转而看向我。[p]

[vo vo="ep4/koku_0169.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「要说线索……会是什么呢」[p]
[kokutou_疑問_c]

#
莫非是曾有人登上钟塔的痕迹之类？[p]

见到我陷入沉思的模样，饴宫爱丽丝无奈地耸了耸肩。[p]

[vo vo="ep4/alice_0111.ogg"]
[alice_退屈]
#【饴宫 爱丽丝】
「可别让我太失望啊，黑十美鹤」[p]
[alice_退屈_c]

[vo vo="ep4/koku_0170.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「……你究竟为何来到这里？」[p]
[kokutou_真顔_c]

#
在这里我试着提出了一个一直有点在意的问题。[p]

[vo vo="ep4/alice_0112.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「为什么？那当然是为了消磨时间啊」[p]
[alice_笑み_c]

#
当真如此吗。[p]

查明幽灵的真面目，真的能替她消磨时间吗。[p]
[vo vo="ep4/alice_0113.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「干嘛，你是有什么想问我的吗？」[p]
[alice_真顔_c]

[vo vo="ep4/koku_0171.ogg"]
[kokutou_呆れ]
#【黒十 美鹤】
「……不，倒也没什么特别的」[p]

[vo vo="ep4/koku_0172.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「只是，既然你这么闲[r]　
　稍微帮点忙也没关系吧？」[p]
[kokutou_真顔_c]

[vo vo="ep4/alice_0114.ogg"]
[alice_退屈]
#【饴宫 爱丽丝】
「我只做自己觉得有趣的事」[p]

[vo vo="ep4/alice_0115.ogg"]
[alice_ドヤ顔]
#【饴宫 爱丽丝】
「好啦，明白了就赶快去揭开幽灵的真面目吧」[p]
[alice_ドヤ顔_c]

#
说完她便坐在了礼拜堂的长椅上。[p]

看来只能自己想办法了。[p]

[bgm_end2]

;全キャラ削除
[allc]

;//合流へジャンプ
[jump  storage="ep4_scene07.ks"  target="*074500"]


;//黒髪の少女に話を聞く
;--------------------------------------------------
*074000
[savetitle text="黒髪の少女に話を聞く"]
;--------------------------------------------------

要不要问问那个黑发少女——蓬辉夜呢。[p]

这样想着寻找她的身影，但她似乎不在这里。[p]

去了哪里呢。[p]

[vo vo="ep4/koku_0173.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「也没有其他头绪，试着找找看吧」[p]
[kokutou_真顔_c]
#

[bgm_end2]
;全キャラ削除
[allc]

;//背景：礼拝堂前
[bg20 bg="chapel_01.jpg"]

[kokutou_哀_c]
[ce cg="kokutou"]


走出礼拜堂。[p]

寒冷的空气让人想折返室内，[r]　
但礼拜堂里似乎确实没有她的踪影。[p]

环顾四周依然不见人影。[p]

她正在收拾整理，[r]　
或许会待在堆放行李的地方。[p]


;全キャラ削除
[allc]

;//背景：裏庭
[bg20 bg="chapel_03.jpg"]

;BGM再生
[bgm ogg="the_window_overlooking_all_things.ogg"]

[kokutou_哀_c]
[lec_f cg="kokutou"]

[kaguya_思考_c]
[ric cg="kaguya"]

沿着礼拜堂走着，[r]　
终于找到了目标人物。[p]

她似乎正在搬出的行李旁沉思着什么。[p]

[kaguya_驚き_c]
不过她似乎注意到了我的靠近，[r]　
将视线转向这边。[p]

[vo vo="ep4/kaguya_0052.ogg"]
[kaguya_無表情]
#【蓬 辉夜】
「……怎么了，有事吗？」[p]
[kaguya_無表情_c]

[vo vo="ep4/koku_0174.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「啊，不，因为刚才没看到你身影」[p]
[kokutou_真顔_c]


[vo vo="ep4/kaguya_0053.ogg"]
[kaguya_無表情]
#【蓬 辉夜】
「这样啊……」[p]
[kaguya_無表情_c]

#
她似乎不是话多的人。[p]

很快我们便陷入沉默。[p]

但这样沉默下去也无济于事。[p]

我决定试着找些话题。[p]

[vo vo="ep4/koku_0175.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「那个……你在这做什么？」[p]
[kokutou_疑問_c]

[vo vo="ep4/kaguya_0054.ogg"]
[kaguya_無表情]
#【蓬 辉夜】
「……没什么，只是在核对分拣好的行李」[p]
[kaguya_無表情_c]

[vo vo="ep4/koku_0176.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「啊，原来如此，辛苦你了」[p]
[kokutou_真顔_c]

#
这时我突然疑惑——[r]　
为何她会帮忙收拾礼拜堂？[p]

这种麻烦的差事，放学后竟要留到深夜来做吗？[p]

[vo vo="ep4/koku_0177.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「说起来，蓬同学是圣歌队的成员吗？」[p]
[kokutou_疑問_c]

[vo vo="ep4/kaguya_0055.ogg"]
[kaguya_無表情]
#【蓬 辉夜】
「不是」[p]
[kaguya_無表情_c]

[vo vo="ep4/koku_0178.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「这样啊？[r]　
　那为什么要帮忙收拾呢？」[p]
[kokutou_疑問_c]

[vo vo="ep4/kaguya_0056.ogg"]
[kaguya_呆れ]
#【蓬 辉夜】
「为什么……我帮同学忙就这么不可思议？」[p]
[kaguya_呆れ_c]

[vo vo="ep4/koku_0179.ogg"]
[kokutou_哀2]
#【黒十 美鹤】
「啊、不、我不是那个意思……」[p]
[kokutou_哀2_c]

[vo vo="ep4/kaguya_0057.ogg"]
[kaguya_無表情]
#【蓬 辉夜】
「那就别问奇怪的问题」[p]
[kaguya_無表情_c]

[vo vo="ep4/koku_0180.ogg"]
[kokutou_哀2]
#【黒十 美鹤】
「对、对不起……」[p]
[kokutou_哀2_c]

#
我不由自主地道了歉。[p]

仔细想想确实如此，[r]　
帮朋友整理东西或许是件很平常的事。[p]

[vo vo="ep4/kaguya_0058.ogg"]
[kaguya_呆れ]
#【蓬 辉夜】
「你也够倒霉的，被卷进这种事情」[p]
[kaguya_呆れ_c]

[vo vo="ep4/koku_0181.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「哈哈哈……」[p]
[kokutou_哀_c]

;SE：屋外足音フェイドアウト
[se_f se="footstep_room_out.ogg"]

;1キャラ消去
[hide_kaguya]

#
我苦笑着回应，蓬辉夜迈步走向礼拜堂。[p]

大概她已确认完行李了吧。[p]

[vo vo="ep4/kaguya_0059.ogg"]
#【蓬 辉夜】
「待会儿我会告诉爱丽丝别多管闲事」[p]

[vo vo="ep4/kaguya_0060.ogg"]
#【蓬 辉夜】
「当然，就算这么说了[r]　
　爱丽丝也不会改变行事作风吧」[p]

#
这话确实在理。[p]

可最终我还是没能打听到有价值的信息。[p]

[vo vo="ep4/koku_0182.ogg"]
[kokutou_呆れ]
#【黒十 美鹤】
「接下来该怎么办呢」[p]
[kokutou_呆れ_c]

#
先赶紧回礼拜堂吧。[p]

在这冰天雪地里干站着实在让人吃不消。[p]

[bgm_end2]

;全キャラ削除
[allc]


;//合流へジャンプ
[jump  storage="ep4_scene07.ks"  target="*074500"]



;//合流（司へ話を聞かなかった場合のルート）
;--------------------------------------------------
*074500
[savetitle text="無駄足を踏んでしまった"]
;--------------------------------------------------
;//背景：礼拝堂内
[bg20 bg="chapel_room_02.jpg"]

[kokutou_真顔_c]
[ce cg="kokutou"]

本想通过交谈找到些头绪[r]　
却白跑了一趟。[p]

终究还是没搞明白该怎么登上钟塔。[p]

[vo vo="ep4/koku_0183.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「……柚叶君那边如何了」[p]
[kokutou_真顔_c]

#
从前往钟塔算起已过了不少时间。[p]

现在回来也丝毫不奇怪。[p]

说不定，[r]　
可能已经发现了一些能成为线索的东西。[p]

[vo vo="ep4/koku_0184.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「要回去看看吗」[p]
[kokutou_真顔_c]
#

;全キャラ削除
[allc]

;//背景：鐘塔廊下２
[bg20 bg="chapel_corridor_02.jpg"]

;BGM再生
[bgm ogg="mid_re.ogg"]

[yuzuha_微笑_c]
[lec_f cg="yuzuha"]

[kokutou_驚き_c]
[ric cg="kokutou"]

来到损坏的梯子前。[p]

[vo vo="ep4/yuzuha_0196.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「啊，黑十先生！」[p]
[yuzuha_笑顔_c]

#
正好柚叶君及时回来了。[p]

[vo vo="ep4/koku_0185.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「柚叶君，钟塔那边怎么样？」[p]
[kokutou_真顔_c]

[vo vo="ep4/yuzuha_0197.ogg"]
[yuzuha_笑顔_c]
#【小仓 柚叶】
「超级高，而且夜景超级漂亮！」[p]
[yuzuha_笑顔_c]

[vo vo="ep4/koku_0186.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「啊哈哈，不是不是，[r]　
　我是说有没有发现什么奇怪的东西？」[p]
[kokutou_微笑_c]

#
面对我的提问，柚叶君垂头丧气地低下头。[p]

[vo vo="ep4/yuzuha_0198.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「啊——，对不起，[r]　
　没找到特别值得一提的东西」[p]

[vo vo="ep4/yuzuha_0199.ogg"]
#【小仓 柚叶】
「钟塔那部分完全暴露在风吹雨打中，[r]　
　连有人待过的痕迹都没留下」[p]

[vo vo="ep4/yuzuha_0200.ogg"]
#【小仓 柚叶】
「也没摆放什么引人注目的物品」[p]
[yuzuha_哀_c]

[vo vo="ep4/koku_0187.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「这样啊……」[p]
[kokutou_疑問_c]


[kokutou_呆れ_c]

#
听了柚叶君的报告后只想抱头苦恼。[p]

这样一来真的连思考的线索都没有了。[p]

[vo vo="ep4/yuzuha_0201.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「啊、不过、[r]　
　两个人的话就能登上钟塔这已经确认了吧！」[p]
[yuzuha_笑顔_c]

#
对于柚叶君的话，我解释说明这次幽灵骚动[r]　
似乎并不适用。[p]

;全キャラ削除
[allc]

;//背景：空とか天井とか
;//黒ベタ
[bg20 bg="black.png"]

之后也试着探索了礼拜堂内及其周围。[p]

然而，最终什么都没能弄清楚。[p]

;//背景：礼拝堂前
[bg20 bg="chapel_01.jpg"]


[yuzuha_微笑_c]
[c4_f cg="yuzuha"]

[kokutou_哀_c]
[c3_f cg="kokutou"]

[alice_笑み]
[ri cg="alice"]

[vo vo="ep4/alice_0116.ogg"]
#【饴宫 爱丽丝】
「那么，幽灵的真面目有好好揭露出来吗？」[p]
[alice_笑み_c]


#
饴宫爱丽丝浮现出坏心眼的笑容询问道。[p]

面对那个问题，我无法回答。[p]

[vo vo="ep4/yuzuha_0202.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「哎呀~，各种方法都尝试着调查过了……[r]　
　幽灵的真面目还是没能揭开」[p]
[yuzuha_哀_c]

#
由柚叶君代替我回答。[p]

听闻此言 饴宫爱丽丝轻轻叹了口气。[p]

[vo vo="ep4/alice_0117.ogg"]
[alice_退屈]
#【饴宫 爱丽丝】
「哈啊 什么嘛 真让人失望……无聊死了」[p]
[alice_退屈_c]

[vo vo="ep4/koku_0188.ogg"]
[kokutou_呆れ]
#【黒十 美鹤】
「……你自己多少也帮下忙不就好了」[p]
[kokutou_呆れ_c]

[vo vo="ep4/alice_0118.ogg"]
[alice_怒り]
#【饴宫 爱丽丝】
「哎呀 你刚说什么了吗？」[p]
[alice_怒り_c]

[vo vo="ep4/koku_0189.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「没什么特别的」[p]
[kokutou_驚き_c]

[vo vo="ep4/alice_0119.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「哼 算了也好[r]　
　继续待在这儿似乎也没什么意义」[p]
[alice_真顔_c]

#
她倏地将视线偏向一侧。[p]

那里有着收拾完毕的蓬辉夜和礼拜堂的主人萩野司的身影。[p]

看来寻找幽灵的时限已经到了。[p]

[vo vo="ep4/alice_0120.ogg"]
[alice_呆れ2]
#【饴宫 爱丽丝】
「赶紧回去吧……完全是在浪费时间」[p]
[alice_呆れ2_c]

[bgm_end1]

;全キャラ削除
[allc]

#
;//背景：黒
[bg20 bg="black.png"]
之后与柚叶君一同踏上了归途。[p]

虽然没能揭开幽灵的真面目[r]　
但总算离开了礼拜堂。[p]

然而――。[p]

;//背景：骨董品店事務所
[bg20 bg="antique2.jpg"]

;BGM再生
[bgm ogg="mid_re.ogg"]

[yuzuha_哀]
[lec_f cg="yuzuha"]

[kokutou_真顔_c]
[ric cg="kokutou"]

[vo vo="ep4/yuzuha_0203.ogg"]
#【小仓 柚叶】
「似乎至今学生之间还在流传着幽灵的传闻呢……」[p]
[yuzuha_哀_c]

#
数日后，来到店里的柚叶君表情凝重地说道。[p]

[vo vo="ep4/yuzuha_0204.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「连黑十先生都没能查明幽灵的真身……也就是说……！」[p]

[vo vo="ep4/yuzuha_0205.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「难道这个传闻真的是实情吗！？」[p]
[yuzuha_笑顔_c]


[yuzuha_驚き]
#
用手推回步步紧逼的柚叶君的脑袋。[p]

[vo vo="ep4/koku_0190.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「所以我不是说过了吗，根本不存在那种东西」[p]
[kokutou_哀_c]

[vo vo="ep4/yuzuha_0206.ogg"]
[yuzuha_怒鳴る]
#【小仓 柚叶】
「但你们最终也没弄明白登上那座钟塔的方法吧」[p]
[yuzuha_怒鳴る_c]

[vo vo="ep4/koku_0191.ogg"]
[kokutou_哀2]
#【黒十 美鹤】
「那个……」[p]
[kokutou_哀2_c]

#
被戳中痛处顿时语塞。[p]

[vo vo="ep4/yuzuha_0207.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「如果没有幽灵，那到底是谁、[r]　
　用什么方法登上钟塔的呢？」[p]
[yuzuha_疑問_c]

[vo vo="ep4/koku_0192.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「…………说起来那堆东西、[r]　
　后来收拾好的行李怎么处理了？」[p]

[vo vo="ep4/koku_0193.ogg"]
#【黒十 美鹤】
「当时分类堆在礼拜堂外面了对吧」[p]
[kokutou_驚き_c]

[vo vo="ep4/yuzuha_0208.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「诶？啊、啊啊，是说那些啊」[p]

[vo vo="ep4/yuzuha_0209.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「大概之后很快就被回收的人清理掉了吧」[p]

[vo vo="ep4/yuzuha_0210.ogg"]
#【小仓 柚叶】
「转眼间就从那里消失了」[p]
[yuzuha_微笑_c]

[vo vo="ep4/koku_0194.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「这样啊……」[p]
[kokutou_微笑_c]

#
总算成功转移了话题。[p]

尽管不情愿，但毕竟自己也稍微帮了忙。[p]

说不在意那些东西的去向倒也是假话。[p]

[vo vo="ep4/yuzuha_0211.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「原定拆除的旧校舍，好像下个月就要动工了」[p]
[yuzuha_微笑_c]

[vo vo="ep4/koku_0195.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「拆除……啊，这么一提确实说过呢」[p]

[vo vo="ep4/koku_0196.ogg"]
#【黒十 美鹤】
「呃，就是礼拜堂的主人那个……」[p]
[kokutou_真顔_c]

[vo vo="ep4/yuzuha_0212.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「萩乃司前辈对吧、[r]　
　说你帮忙整理真是太感谢了」[p]

[vo vo="ep4/yuzuha_0213.ogg"]
#【小仓 柚叶】
「托你的福似乎能赶上弥撒了」[p]

[vo vo="ep4/yuzuha_0214.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「嘛、虽说因为幽灵骚动的缘故、[r]　
　学生们好像都不太愿意去的样子……」[p]

[vo vo="ep4/koku_0197.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「那可真遗憾呢……弥撒是从什么时候开始来着？」[p]
[kokutou_哀_c]

[vo vo="ep4/yuzuha_0215.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「应该是平安夜和圣诞节当天……我记得」[p]

[vo vo="ep4/yuzuha_0216.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「啊！　对、对了黑十先生……[r]　
　那、那个圣诞节您有什么安排……？」[p]
[yuzuha_驚き_c]

[vo vo="ep4/koku_0198.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「…………」[p]
[kokutou_真顔_c]

[vo vo="ep4/yuzuha_0217.ogg"]
[yuzuha_etc_頬]
[yuzuha_微笑]
#【小仓 柚叶】
「我那天倒是没什么特别的安排……」[p]

[vo vo="ep4/yuzuha_0218.ogg"]
#【小仓 柚叶】
「如、如果方便的话……[r]　
　两、两、两个人……一起吃个饭什么的您看怎样？」[p]
[yuzuha_微笑_c]

[vo vo="ep4/koku_0199.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「…………」[p]
[kokutou_疑問_c]

[vo vo="ep4/yuzuha_0219.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「其实有家价位稍高但味道不错的餐厅就在附近[r]　
　……那个、黑十先生？您在听吗？」[p]
[yuzuha_疑問_c]

[vo vo="ep4/koku_0200.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「咦？啊、抱歉稍微走神了」[p]
[kokutou_驚き_c]

[yuzuha_etc_off]
[yuzuha_怒_c]
#
回过神时只见柚叶君正鼓着脸瞪着我。[p]

[vo vo="ep4/yuzuha_0220.ogg"]
[yuzuha_怒]
#【小仓 柚叶】
「唔唔……刚才在想什么……？」[p]
[yuzuha_怒_c]

#
看这架势如果回答不当恐怕会更惹她生气。[p]

看来得谨慎组织语言才行。[p]

[bgm_end2]

[vo vo="ep4/koku_0201.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「没、就是在想幽灵传闻的事」[p]
[kokutou_真顔_c]

[vo vo="ep4/yuzuha_0221.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「咦？幽灵的？莫非您察觉到什么了吗！？」[p]
[yuzuha_驚き_c]

[vo vo="ep4/koku_0202.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「倒也不是……就是觉得有哪里不对劲……」[p]

[vo vo="ep4/koku_0203.ogg"]
#【黒十 美鹤】
「当时，我只是觉得可能还有其他可能性」[p]
[kokutou_疑問_c]


;BGM再生
[bgm ogg="tukikage.ogg"]

[vo vo="ep4/yuzuha_0222.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「可能性……但为什么突然这么想呢？」[p]

[vo vo="ep4/yuzuha_0223.ogg"]
#【小仓 柚叶】
「明明从那晚过去好几天了」[p]
[yuzuha_疑問_c]

[vo vo="ep4/koku_0204.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「刚才那个……关于弥撒何时开始的问题」[p]

[vo vo="ep4/koku_0205.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「从何时……嗯～该说是时间点还是时间段呢」[p]

[vo vo="ep4/koku_0206.ogg"]
#【黒十 美鹤】
「这类事情，我当时居然完全没考虑到……」[p]
[kokutou_疑問_c]


#
但如今再怎么思考，也不可能突然察觉什么线索。[p]

这里既没有深谙幽灵骚动和礼拜堂内情的人，[r]　
更没有那位礼拜堂的主人在场。[p]

若当时向萩野司请教这些事，[r]　
或许就能明白些什么了。[p]

[vo vo="ep4/koku_0207.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「……现在说这些太迟了呢」[p]
[kokutou_真顔_c]

#
我停止思考望向窗外。[p]

回想起那晚礼拜堂的事，不禁感到些许寒意。[p]

[vo vo="ep4/koku_0208.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「变冷了呢」[p]
[kokutou_真顔_c]

[vo vo="ep4/yuzuha_0224.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「毕竟是冬天嘛……幽灵的传闻能早点平息就好了」[p]
[yuzuha_微笑_c]


[kokutou_疑問_c]

#
我对柚叶君的话语感到疑惑。[p]

虽然灵异特辑确实多在夏季播放。[p]

或许是注意到我的困惑表情，[r]　
柚叶君继续解释道。[p]

[vo vo="ep4/yuzuha_0225.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「因为幽灵一直站在那里的话也会觉得冷吧」[p]
[yuzuha_笑顔_c]


[kokutou_微笑_c]

#
这话让我忍不住笑出声来。[p]

幽灵也会感冒吗——我没有问出口。[p]

这个世界上，根本不存在幽灵之类的东西。[p]

但愿那位可能正攀登着钟塔的人物[r]　
不要患上感冒才好。[p]

我正思考着这样的事情。[p]

;//おわり。
;//バッドエンド「見つけられない幽霊」

;テキストウィンドウ削除
[end_text]

;全キャラ削除
[allc]

;背景
[eval exp="sf.ep4_end3 = 1"]
[bg20 bg="ep4_end3.png"]

;処理を停止します
[wa]
[wait time=1000]
[p]

;バッジ獲得用タグ
;[give_emblem id="5610" pid="d651c25b6bfedc95142678687fa1cdbc"]

;タイトル画面へ移動
[jump  storage="title_screen.ks"  target="*title"]

[s]


;//礼拝堂の主に話を聞く。
;--------------------------------------------------
*075000
[savetitle text="礼拝堂の主に話を聞く"]
;--------------------------------------------------
;全キャラ削除
[allc]

;//背景：礼拝堂内
[bg20 bg="chapel_room_02.jpg"]

[kokutou_真顔_c]
[lec_f cg="kokutou"]

[tukasa_笑顔_c]
[ric cg="tukasa"]

决定去询问礼拜堂的主人萩乃小姐。[p]

正寻思着人在哪里时、[r]　
恰好那身影就出现了。[p]

[vo vo="ep4/hagino_0067.ogg"]
[tukasa_笑顔]
#【萩乃司】
「啊，怎么样？幽灵的真面目，弄清楚了吗？」[p]
[tukasa_笑顔_c]

[vo vo="ep4/koku_0209.ogg"]
[kokutou_呆れ]
#【黒十 美鹤】
「很遗憾……不好意思，[r]　
　能再给我讲讲幽灵传闻的事吗？」[p]
[kokutou_呆れ_c]

[vo vo="ep4/hagino_0068.ogg"]
[tukasa_笑顔]
#【萩乃司】
「没问题，完全没关系哦」[p]
[tukasa_笑顔_c]

#
微微含笑后、礼拜堂的主人如同最初那般[r]　
讲述起这幽灵骚动的始末。[p]

但最终还是没有想出什么头绪。[p]

[vo vo="ep4/hagino_0069.ogg"]
[tukasa_苦笑い]
#【萩乃司】
「唔——，看起来很难呢」[p]
[tukasa_苦笑い_c]

#
对于陷入沉思的我，萩乃小姐体贴地挤出笑容。[p]

[vo vo="ep4/hagino_0070.ogg"]
[tukasa_笑顔]
#【萩乃司】
「不过对我来说，你们能来真是帮大忙了」[p]

[vo vo="ep4/hagino_0071.ogg"]
#【萩乃司】
「多亏你们弥撒应该能准时举行了，非常感谢」[p]
[tukasa_笑顔_c]

[vo vo="ep4/koku_0210.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「啊不不，我倒也没什么……弥撒什么时候开始？」[p]
[kokutou_真顔_c]

[vo vo="ep4/hagino_0072.ogg"]
[tukasa_笑顔]
#【萩乃司】
「圣诞前夜和圣诞节当日共两天，[r]　
　上午也会举行的哦」[p]

[vo vo="ep4/hagino_0073.ogg"]
#【萩乃司】
「伊芙节当天也预定向公众开放，方便的话请务必来玩！」[p]
[tukasa_笑顔_c]

[vo vo="ep4/koku_0211.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「…………从什么时候开始的……？」[p]
[kokutou_疑問_c]

#
对自己提出的问题，感觉似乎有什么不对劲。[p]

说起来总觉得有哪里不自然。[p]

[vo vo="ep4/koku_0212.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「关于这座钟塔的幽灵传闻开始流传[r]　
　具体是从什么时候开始的来着？」[p]
[kokutou_真顔_c]

[vo vo="ep4/hagino_0074.ogg"]
[tukasa_疑問]
#【萩乃司】
「呃……大概是这个月月初吧」[p]
[tukasa_疑問_c]

[vo vo="ep4/koku_0213.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「这个月月初……」[p]
[kokutou_疑問_c]

#
几乎在同一时期还发生了另一件事。[p]

当然那个消息也是来到此处后才得知的。[p]

那就是――。[p]

[vo vo="ep4/koku_0214.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「那么再问一个……[r]　
　旧校舍的拆除通知是什么时候公布的？」[p]
[kokutou_真顔_c]

[vo vo="ep4/hagino_0075.ogg"]
[tukasa_疑問]
#【萩乃司】
「也是这个月……不过这有什么问题吗？」[p]
[tukasa_疑問_c]

#
此时此刻，笼罩着礼拜堂与钟塔的迷雾骤然散尽。[p]

[vo vo="ep4/koku_0215.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「……原来如此，是这么回事啊」[p]
[kokutou_真顔_c]

#
虽然苦恼许久，但终于像是触碰到真相了。[p]

关于钟塔的幽灵――及其真身。[p]

[vo vo="ep4/koku_0216.ogg"]
[kokutou_凛]
#【黒十 美鹤】
「看来我……似乎抓住了幽灵呢，柚叶君」[p]
[kokutou_凛_c]

#
当我如此低语时，通往钟塔的走廊恰好喧闹起来。[p]

看来是她回来了。[p]

[kill]

[yuzuha_微笑]
[c4_f cg="yuzuha"]

[kokutou_驚き_c]
[c3_f cg="kokutou"]

[tukasa_笑顔_c]
[ri cg="tukasa"]

[vo vo="ep4/yuzuha_0226.ogg"]
#【小仓 柚叶】
「黑十先生，对不起我来晚了！」[p]
[yuzuha_微笑_c]

[vo vo="ep4/koku_0217.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「不，比起那个，情况如何，[r]　
　钟塔那边，顺利登到顶了吗？」[p]
[kokutou_微笑_c]

[vo vo="ep4/yuzuha_0227.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「超级高的！夜景超级漂亮！」[p]
[yuzuha_笑顔_c]

[vo vo="ep4/koku_0218.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「啊哈哈，不，我不是问那个……」[p]
[kokutou_微笑_c]

[vo vo="ep4/yuzuha_0228.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「啊—、对不起……实在没什么特别的……」[p]
[yuzuha_哀_c]

[vo vo="ep4/koku_0219.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「是吗、不过、我们这边可是有收获哦」[p]
[kokutou_微笑_c]

#
听到我的话后、柚叶君的表情明朗起来。[p]

[vo vo="ep4/yuzuha_0229.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「收获……黑十先生、难道说……」[p]
[yuzuha_微笑_c]

[vo vo="ep4/koku_0220.ogg"]
[kokutou_凛]
#【黒十 美鹤】
「没错，我搞清楚幽灵的真身了」[p]
[kokutou_凛_c]


;テキストウィンドウ削除
[end_text]

;BGM停止
[bgm_end3]

;全キャラ削除
[allc]

;背景
[bg10 bg="white.png"]

;次のシーンへ移動
[jump  storage="ep4_scene08.ks"]

[s]