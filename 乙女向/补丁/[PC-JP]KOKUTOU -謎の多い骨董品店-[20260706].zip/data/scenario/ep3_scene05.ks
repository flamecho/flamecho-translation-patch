﻿;--------------------------------------------------
;■黒十　本文テキスト　ep3　御伽倶楽部
;--------------------------------------------------
;
;■ep3_scene04
;
;--------------------------------------------------
[eval exp="f.second_select=0"]
[eval exp="f.second_map_1=0"]
[eval exp="f.second_map_2=0"]
[eval exp="f.second_map_3=0"]
[eval exp="f.second_map_4=0"]
[eval exp="f.second_map_5=0"]
;-------------------------------------------------
;//地図画面
*second_select
[savetitle text="地図画面"]
;-------------------------------------------------
;//２回場所移動を間違うとバッド・エンドのルート『変わった夢だったのね』へ

[if exp="f.second_select==2"]
[jump target="*second_select_end"]
[else]
[jump target="*second_select_map"]
[endif]

;-------------------------------------------------
*second_select_map
[savetitle text="地図画面"]
;-------------------------------------------------
;//前画面の要素を削除

;テキストウィンドウ削除
[end_text]

;全キャラ削除
[allc]

;//黒ベタ
[bg10 bg="black.png"]


[bg10 bg="select_map.jpg"]

;BGM再生
[bgm ogg="tukikage.ogg"]

;//場所移動の選択肢--------------------------------------------------

*second_map_1
[if exp="f.second_map_1==1"]
[jump target="*second_map_2]
[else]
[endif]

;//１：食堂
[button name="role_button" x="508" y="196" graphic="map/btn_select_05_off.png" enterimg="map/btn_select_05_on.png" clickimg="map/btn_select_05_off.png" target="*second_select_1"  enterse="cursor1.ogg" clickse="decision5.ogg" exp="f.second_select=f.second_select+1"]

*second_map_2
[if exp="f.second_map_2==1"]
[jump target="*second_map_3]
[else]
[endif]

;//２：中庭テラス
[button name="role_button" x="378" y="273" graphic="map/btn_select_04_off.png" enterimg="map/btn_select_04_on.png" clickimg="map/btn_select_04_off.png" target="*second_select_2"  enterse="cursor1.ogg" clickse="decision5.ogg" exp="f.second_select=f.second_select+1"]

*second_map_3
[if exp="f.second_map_3==1"]
[jump target="*second_map_4]
[else]
[endif]

;//３：空き教室
[button name="role_button" x="367" y="90" graphic="map/btn_select_07_off.png" enterimg="map/btn_select_07_on.png" clickimg="map/btn_select_07_off.png" target="*second_select_3"  enterse="cursor1.ogg" clickse="decision5.ogg" exp="f.second_select=f.second_select+1"]

*second_map_4
[if exp="f.second_map_4==1"]
[jump target="*second_map_5]
[else]
[endif]

;//４：旧校舎前
[button name="role_button" x="605" y="13" graphic="map/btn_select_08_off.png" enterimg="map/btn_select_08_on.png" clickimg="map/btn_select_08_off.png" target="*second_select_4"  enterse="cursor1.ogg" clickse="decision5.ogg" exp="f.second_select=f.second_select+1"]

*second_map_5

;//５：校門
[button name="role_button" x="140" y="521" graphic="map/btn_select_11_off.png" enterimg="map/btn_select_11_on.png" clickimg="map/btn_select_11_off.png" target="*second_select_5"  enterse="cursor1.ogg" clickse="decision5.ogg"]

[showmenubutton]

[s]

;--------------------------------------------------
;//■ルート『変わった夢だったのね』
*second_select_end
[savetitle text="『変わった夢だったのね』"]
;-------------------------------------------------

[bgm_end1]

;SE：チャイム
[se_f se="school_bell.ogg"]

[yuzuha_驚き]

[sayuri_驚き]

[vo vo="ep3/yuzu_0173.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「啊……预备铃都响了呢」[p]
[yuzuha_哀_c]

[vo vo="ep3/sayu_0061.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「再不回去的话可能要糟糕了」[p]
[sayuri_微笑_c]

#
结果就算用上了这个休息时间[r]　
也没能解开校园□的密码。[p]

[vo vo="ep3/yuzu_0174.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「呜～、御伽俱乐部的活动地点……好在意啊……」[p]
[yuzuha_哀_c]

[vo vo="ep3/sayu_0062.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「我懂你的心情但现在先忍忍吧，[r]　
　下个休息时间我们再一起调查吧」[p]
[sayuri_微笑_c]

[vo vo="ep3/yuzu_0175.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「嗯！说得对！」[p]
[yuzuha_笑顔_c]

#
被小百合小姐说服后不情不愿地回到了教室。[p]

;全キャラ削除
[allc]

;//ブラックアウト
[bg10 bg="black.png"]


但即使调查到放学也还是没能明白校园□密码的含义[r]　
以及御伽俱乐部的活动地点。[p]

;//中庭テラス
[bg10 bg="terrace.jpg"]

[yuzuha_微笑_c]
[ce_f cg="yuzuha"]

[alice_真顔_c]
[ri_f cg="alice"]

[sayuri_哀_c]
[le cg="sayuri"]

[vo vo="ep3/alice_0052.ogg"]
[alice_ドヤ顔]
#【饴宫 爱丽丝】
「看来你们最终也没能找到御伽俱乐部的活动地点呢，小仓柚叶」[p]

[vo vo="ep3/alice_0053.ogg"]
#【饴宫 爱丽丝】
「这场比试是我赢了」[p]
[alice_ドヤ顔_c]

[vo vo="ep3/yuzu_0176.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「请、请等一下！」[p]

[vo vo="ep3/yuzu_0177.ogg"]
#【小仓 柚叶】
「今天只是没找到而已，明天一定会――」[p]
[yuzuha_驚き_c]

[vo vo="ep3/alice_0054.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「这种保证可靠吗？」[p]
[alice_真顔_c]

#
我无言以对爱丽丝学姐的话语。[p]

[vo vo="ep3/alice_0055.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「明白吗？按照约定，明天你要来参加我的茶会哦」[p]
[alice_真顔_c]

;キャラ消去
[chara_hide name=alice]

#
说完爱丽丝学姐就离开了。[p]

[vo vo="ep3/sayu_0063.ogg"]
[sayuri_哀]
#【稻饼 小百合】
「小柚叶……」[p]
[sayuri_哀_c]

#
小百合小姐用困扰的表情注视着我。[p]

我只能对此报以苦笑。[p]

但此时此刻也只能无可奈何地接受现实。[p]

约定就是约定。[p]

;全キャラ削除
[allc]

;//ブラックアウト
[bg10 bg="black.png"]



然而第二天早晨，我终究没能履行那个约定。[p]

;//黒十の店
[bg10 bg="antique.jpg"]

[yuzuha_微笑_c]
[le_f cg="yuzuha"]

[kokutou_真顔_c]
[ri_f cg="kokutou"]

;庵衣装指定
[iori_c_仕事着]

[iori_無表情_c]
[ce cg="iori"]


;BGM再生
[bgm ogg="tukikage_02.ogg"]

[vo vo="ep3/iori_0004.ogg"]
[iori_無表情]
#【御手洗 庵】
「我来接您了，柚叶大人」[p]
[iori_無表情_c]

#
当我在黑十先生家像往常一样准备早餐时，[r]　
古董店里出现了小庵的身影。[p]

我立刻察觉到那样子与平常稍有不同。[p]

会如此称呼我的人，必定都是与小仓家有关联的人。[p]

[vo vo="ep3/koku_0034.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「您这是什么意思？」[p]
[kokutou_真顔_c]

#
在我无言以对时，黑十先生代为发问了。[p]

[vo vo="ep3/iori_0005.ogg"]
[iori_無表情]
#【御手洗 庵】
「柚叶大人需要先回一趟本家」[p]
[iori_無表情_c]

[vo vo="ep3/yuzu_0178.ogg"]
[yuzuha_怒]
#【小仓 柚叶】
「哎！？那、这种事情绝对――」[p]
[yuzuha_怒_c]

[vo vo="ep3/iori_0006.ogg"]
[iori_無表情]
;//読み方『杏葉』→あずは
#【御手洗 庵】
「这是杏叶大人的命令」[p]
[iori_無表情_c]

[yuzuha_驚き_c]

#
杏叶――在姐姐的名字面前，我永远都是无能为力的。[p]

[vo vo="ep3/iori_0007.ogg"]
[iori_無表情]
#【御手洗 庵】
「外面有车在等着，能请您和我一起乘坐吗？」[p]
[iori_無表情_c]

[vo vo="ep3/yuzu_0179.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「那个……」[p]
[yuzuha_哀_c]

#
困扰的我什么都做不到。[p]

只能像抓住救命稻草般看向黑十先生。[p]

[vo vo="ep3/koku_0035.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「哈啊……至少该告诉我理由吧？」[p]
[kokutou_疑問_c]

#
面对黑十先生的提问，小庵稍稍垂下眼帘。[p]

但很快又恢复表情开口道。[p]

[vo vo="ep3/iori_0008.ogg"]
[iori_無表情]
#【御手洗 庵】
「困扰的是，身为小仓家成员的柚叶大人[r]　
　居然参加了饴宫爱丽丝的茶会」[p]
[iori_無表情_c]

[vo vo="ep3/yuzu_0180.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「呜哇……果然」[p]
[yuzuha_哀_c]

#
原因我隐约能猜到。[p]

但没想到会这么快[r]　
更没料到杏叶姐姐会出手干涉。[p]

为何能做到这种地步？[p]

只要看着眼前的小庵，就连我也能明白。[p]

[vo vo="ep3/yuzu_0181.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「啊，小庵……原来如此，是这样啊」[p]
[yuzuha_哀_c]

#
比起遗憾，这种感觉更像是歉疚。[p]

[vo vo="ep3/iori_0009.ogg"]
[iori_無表情]
#【御手洗 庵】
「那么，请跟我来」[p]
[iori_無表情_c]

#
已经无计可施了。[p]

我决定暂且放弃抵抗跟从她。[p]

[vo vo="ep3/yuzu_0182.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「黑十先生，对不起……我稍微离开下」[p]
[yuzuha_微笑_c]

#
面对强撑笑容的我[r]　
黑十先生露出了惯常的无奈表情。[p]

;全キャラ削除
[allc]

;//骨董品店前
[bg10 bg="shop_kokutou2.jpg"]

[yuzuha_微笑_c]
[le_f cg="yuzuha"]

[kokutou_真顔_c]
[ri_f cg="kokutou"]

[iori_無表情_c]
[ce cg="iori"]


和小庵一同走出店铺。[p]

[vo vo="ep3/koku_0036.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「请稍等」[p]
[kokutou_真顔_c]

[vo vo="ep3/iori_0010.ogg"]
[iori_無表情]
#【御手洗 庵】
「……还有事？」[p]
[iori_無表情_c]

[vo vo="ep3/koku_0037.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「刚才提到饴宫爱丽丝的茶会什么的吧」[p]

[vo vo="ep3/koku_0038.ogg"]
#【黒十 美鹤】
「既然这是事件的起因……请详细说明」[p]
[kokutou_真顔_c]

[vo vo="ep3/iori_0011.ogg"]
[iori_無表情]
#【御手洗 庵】
「那个……」[p]
[iori_無表情_c]

[vo vo="ep3/koku_0039.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「柚叶君，能否为我解释一下？」[p]
[kokutou_真顔_c]

[vo vo="ep3/yuzu_0183.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「……啊对！若是黑十先生的话！」[p]

[vo vo="ep3/yuzu_0184.ogg"]
[yuzuha_怒鳴る]
#【小仓 柚叶】
「拜托了黑十先生！请解开御伽俱乐部的谜团！」[p]
[yuzuha_怒鳴る_c]

[vo vo="ep3/iori_0012.ogg"]
[iori_微笑]
#【御手洗 庵】
「那个——，我要等到什么时候才好呢？」[p]
[iori_微笑_c]

[vo vo="ep3/koku_0040.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「请等一个小时左右」[p]
[kokutou_真顔_c]

[vo vo="ep3/iori_0013.ogg"]
[iori_微笑]
#【御手洗 庵】
「一小时啊……更久我可不等哦」[p]
[iori_微笑_c]

[vo vo="ep3/koku_0041.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「好了，这下有时间了，柚叶君，说说看吧」[p]
[kokutou_真顔_c]

#
我向黑十先生讲述了至今为止的经过。[p]

;//時間経過
;テキストウィンドウ削除
[end_text]

;全キャラ削除
[allc]

;//黒ベタ
[bg10 bg="black.png"]

;//停止
[wait time=2000]

;//教室
[bg10 bg="antique.jpg"]

[yuzuha_微笑_c]
[le_f cg="yuzuha"]

[kokutou_真顔_c]
[ri_f cg="kokutou"]

[iori_無表情_c]
[ce cg="iori"]

;テキストウィンドウ表示
[start_text_yuzu]


[vo vo="ep3/koku_0042.ogg"]
[kokutou_疑問]
;//読み方『学園の□』→学園のくち
#【黒十 美鹤】
「原来如此……学园之口……吗」[p]
[kokutou_疑問_c]

[vo vo="ep3/yuzu_0185.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「我怎么都想不明白那个意思……所以才要参加茶会……」[p]
[yuzuha_哀_c]

[vo vo="ep3/koku_0043.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「嗯……」[p]
[kokutou_真顔_c]

#
黑十先生若有所思地挠了挠头。[p]

这样过了一会，他瞥了小庵一眼开口说道。[p]

[vo vo="ep3/koku_0044.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「刚才说一小时，其实三十分钟也没问题哦」[p]
[kokutou_真顔_c]

[vo vo="ep3/iori_0014.ogg"]
[iori_驚き]
#【御手洗 庵】
「诶？真的吗？话说那是……」[p]
[iori_驚き_c]

[vo vo="ep3/yuzu_0186.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「黑十先生……？」[p]
[yuzuha_疑問_c]

[vo vo="ep3/koku_0045.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「这种时候最重要的是保持冷静……[r]　
　柚叶君也请再思考一下吧」[p]

[vo vo="ep3/koku_0046.ogg"]
;//読み方『学園の□』→学園のくち
#【黒十 美鹤】
「学园之口究竟是什么……」[p]
[kokutou_微笑_c]

[bgm_end2]


;全キャラ削除
[allc]

;//ブラックアウト
[bg10 bg="black.png"]

#
之后，我和黑十先生一起再次挑战了御伽俱乐部的谜题。[p]

曾经那么困扰的谜题转眼间就解开了，[r]　
我成功地不用去茶会了。[p]

;//終わり

;テキストウィンドウ削除
[end_text]

;//ルート『変わった夢だったのね』おわり
[eval exp="sf.ep3_end4 = 1"]
[bg  storage="ep3_end_4.jpg" time="2000"]

;処理を停止します
[wait time="2000"]

;バッジ獲得用タグ
;[give_emblem id="5348" pid="81e7c282a8e5d9ee1093a1281f0d5333"]

;背景：暗転
[bg30 bg="black.png"]

;タイトル画面へ移動
[jump  storage="title_screen.ks"  target="*title"]

[s]

;//タイトル『変わった夢だったのね』



;--------------------------------------------------
;//選択肢１：食堂
*second_select_1
[savetitle text="食堂"]
;-------------------------------------------------

[eval exp="f.second_map_1=1"]

;選択肢ボタンクリア
[bgm_end1]
[cm]
[clearfix]


;//黒ベタ
[bg20 bg="black.png"]

;BGM再生
[bgm ogg="4656.ogg"]

;//食堂
[bg10 bg="cafeteria.jpg"]

[yuzuha_笑顔_c]
[lec_f cg="yuzuha"]

[sayuri_微笑_c]
[ric cg="sayuri"]


;テキストウィンドウ表示
[start_text_yuzu]

[vo vo="ep3/yuzu_0187.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「说到口那就是食堂吧！」[p]

[vo vo="ep3/yuzu_0188.ogg"]
#【小仓 柚叶】
「哈啊……咖喱看起来好好吃……！」[p]
[yuzuha_笑顔_c]

[vo vo="ep3/sayu_0064.ogg"]
[sayuri_哀]
;//読み方『学園の□』→学園のくち
#【稻饼 小百合】
「唔嗯……为什么食堂是学园之口呢？」[p]
[sayuri_哀_c]

[vo vo="ep3/yuzu_0189.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「因为是吃饭的地方？」[p]
[yuzuha_笑顔_c]

[vo vo="ep3/sayu_0065.ogg"]
[sayuri_驚き]
#【稻饼 小百合】
「啊——……那个……」[p]
[sayuri_驚き_c]

#
小百合小姐陷入了沉默。[p]

看来我的想法似乎并不正确。[p]

[vo vo="ep3/yuzu_0190.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「要、要不再找找其他地方吧！」[p]
[yuzuha_驚き_c]

;//地図画面
;//場所移動の選択肢
[jump target="*second_select"]


;--------------------------------------------------
;//選択肢２：中庭テラス
*second_select_2
[savetitle text="中庭テラス"]
;-------------------------------------------------

[eval exp="f.second_map_2=1"]

;選択肢ボタンクリア
[bgm_end1]
[cm]
[clearfix]

;//黒ベタ
[bg20 bg="black.png"]

;BGM再生
[bgm ogg="music.ogg"]

;//中庭テラス
[bg10 bg="terrace.jpg"]

[yuzuha_微笑_c]
[lec_f cg="yuzuha"]

[sayuri_微笑_c]
[ric cg="sayuri"]

;テキストウィンドウ表示
[start_text_yuzu]

#
和小百合小姐一起来到了中庭。[p]

[vo vo="ep3/sayu_0066.ogg"]
[sayuri_微笑]
;//読み方『学園の□』→学園のくち
#【稻饼 小百合】
「小柚叶，这里是学院的入口吗？」[p]
[sayuri_微笑_c]

[vo vo="ep3/yuzu_0191.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「……大概？」[p]
[yuzuha_疑問_c]

[vo vo="ep3/sayu_0067.ogg"]
[sayuri_哀]
#【稻饼 小百合】
「……应该不是吧」[p]
[sayuri_哀_c]

[vo vo="ep3/yuzu_0192.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「也是呢……」[p]
[yuzuha_疑問_c]

#
如果这里是御伽俱乐部的活动场所，爱丽丝前辈应该早就调查过了。[p]

[vo vo="ep3/yuzu_0193.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「抱歉，我们去别处找找吧」[p]
[yuzuha_微笑_c]

;//地図画面
;//場所移動の選択肢
[jump target="*second_select"]


;--------------------------------------------------
;//選択肢３：空き教室
*second_select_3
[savetitle text="空き教室"]
;-------------------------------------------------

[eval exp="f.second_map_3=1"]

;選択肢ボタンクリア
[bgm_end1]
[cm]
[clearfix]

;//黒ベタ
[bg20 bg="black.png"]

;BGM再生
[bgm ogg="music.ogg"]

;//空き教室
[bg10 bg="empty_classroom.jpg"]

[yuzuha_微笑_c]
[lec_f cg="yuzuha"]

[sayuri_微笑_c]
[ric cg="sayuri"]

;テキストウィンドウ表示
[start_text_yuzu]

[vo vo="ep3/sayu_0068.ogg"]
[sayuri_微笑]
;//読み方『学園の□』→学園のくち
#【稻饼 小百合】
「空教室……？这里是学院的入口？」[p]
[sayuri_微笑_c]

[vo vo="ep3/yuzu_0194.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「……我原以为是这里，但可能弄错了？」[p]
[yuzuha_疑問_c]

#
果然还是不对。[p]

[vo vo="ep3/yuzu_0195.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「本来就没太大把握……再去找其他地方吧」[p]
[yuzuha_微笑_c]

;//地図画面
;//場所移動の選択肢
[jump target="*second_select"]



;--------------------------------------------------
;//選択肢４：旧校舎前
*second_select_4
[savetitle text="旧校舎前"]
;-------------------------------------------------

[eval exp="f.second_map_4=1"]

;選択肢ボタンクリア
[bgm_end1]
[cm]
[clearfix]

;//黒ベタ
[bg20 bg="black.png"]

;BGM再生
[bgm ogg="music.ogg"]

;//旧校舎前
[bg10 bg="garden_1.jpg"]

[yuzuha_驚き_c]
[lec_f cg="yuzuha"]

[sayuri_微笑_c]
[ric cg="sayuri"]

;テキストウィンドウ表示
[start_text_yuzu]

#
和小百合小姐一起走到了旧校舍前。[p]

[vo vo="ep3/yuzu_0196.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「哇，原来以前的校舍还留着啊」[p]
[yuzuha_驚き_c]

[vo vo="ep3/sayu_0069.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「现在完全废弃了，教学楼内部似乎禁止入内」[p]
[sayuri_微笑_c]

[vo vo="ep3/yuzu_0197.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「诶—好想进去看看呀」[p]
[yuzuha_微笑_c]

[vo vo="ep3/sayu_0070.ogg"]
[sayuri_微笑]
;//読み方『学園の□』→学園のくち
#【稻饼 小百合】
「比起这个，旧校舍是学院的入口吗？」[p]
[sayuri_微笑_c]

[vo vo="ep3/yuzu_0198.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「呃……抱歉，好像不是」[p]

[vo vo="ep3/yuzu_0199.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「去别的地方找找吧！」[p]
[yuzuha_微笑_c]

;//地図画面
;//場所移動の選択肢
[jump target="*second_select"]


;--------------------------------------------------
;//選択肢５：校門
*second_select_5
[savetitle text="校門"]
;-------------------------------------------------

;選択肢ボタンクリア
[bgm_end1]
[cm]
[clearfix]

;//黒ベタ
[bg20 bg="black.png"]

;//校門
[bg10 bg="school_gate.jpg"]

[yuzuha_微笑_c]
[lec cg="yuzuha"]

[sayuri_微笑_c]
[ric cg="sayuri"]

;テキストウィンドウ表示
[start_text_yuzu]

#
说到人类的入口就是进食的嘴巴。[p]

那么说到学院的入口，自然就是学生进出的校门。[p]

;BGM再生
[bgm ogg="music.ogg"]

[vo vo="ep3/yuzu_0200.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「抱着这个想法过来看看……你觉得呢？」[p]
[yuzuha_微笑_c]

[vo vo="ep3/sayu_0071.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「嗯——[r]　
　我仔细检查过了，应该没有关于俱乐部的东西」[p]
[sayuri_微笑_c]

#
两人四下查看了一番却一无所获。[p]

毕竟校门是每天都会看到的东西。[p]

要是有什么变化肯定会注意到。[p]

况且这种地方也不可能开展社团活动。[p]

[vo vo="ep3/yuzu_0201.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「唔——要是能找到些线索就好了……」[p]
[yuzuha_哀_c]

#
但看来没那么容易如愿以偿。[p]

[vo vo="ep3/alice_0056.ogg"]
;//下記台詞はアリス
#【？？？】
「呵呵，好像很困扰呢」[p]

[kill]

[yuzuha_驚き_c]
[ce_f cg="yuzuha"]

[sayuri_驚き_c]
[le_f cg="sayuri"]

[alice_笑み_c]
[ri cg="alice"]

[vo vo="ep3/yuzu_0202.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「呜……爱丽丝前辈」[p]
[yuzuha_哀_c]

#
满脸困扰的我和小百合小姐面前[r]　
出现了带着爽朗笑容的爱丽丝前辈。[p]

[vo vo="ep3/alice_0057.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「怎么样？找到御伽俱乐部的活动地点了吗？」[p]

[vo vo="ep3/alice_0058.ogg"]
#【饴宫 爱丽丝】
「难得我都把场地提示告诉你了[r]　
　可得好好表现才行呢」[p]
[alice_笑み_c]

[vo vo="ep3/yuzu_0203.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「……说话真讨厌」[p]
[yuzuha_疑問_c]

[vo vo="ep3/alice_0059.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「哎呀，我说什么了吗？」[p]
[alice_真顔_c]

[vo vo="ep3/yuzu_0204.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「没、没什么！」[p]
[yuzuha_驚き_c]

[vo vo="ep3/alice_0060.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「是嘛……可别忘了约定哦」[p]

[vo vo="ep3/alice_0061.ogg"]
#【饴宫 爱丽丝】
「要是找不到御伽俱乐部的活动场地的话……」[p]
[alice_笑み_c]

[vo vo="ep3/yuzu_0205.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「我知道啦，参加茶会……对吧」[p]
[yuzuha_微笑_c]

[vo vo="ep3/alice_0062.ogg"]
[alice_ドヤ顔]
#【饴宫 爱丽丝】
「没错……呵呵，会好好疼爱你的」[p]
[alice_ドヤ顔_c]

#
爱丽丝前辈看着我的眼神就像发现新玩具般闪闪发亮。[p]

不，实际上对爱丽丝前辈来说[r]　
我或许就像个玩具般的存在。[p]

[vo vo="ep3/alice_0063.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「嘛、你尽管加油吧」[p]
[alice_笑み_c]

;SE：
[se_f se="footsteps_out.ogg"]

;キャラ消去
[chara_hide name=alice]

#
说完这句话后爱丽丝前辈便离开了现场。[p]

[vo vo="ep3/sayu_0072.ogg"]
[sayuri_哀]
#【稻饼 小百合】
「小柚叶……你没事吧？」[p]
[sayuri_哀_c]

#
对小百合小姐那充满担忧的凝视回以苦笑。[p]

参加茶会就意味着加入派系。[p]

更何况爱丽丝前辈是跨国大企业家的女儿。[p]

这样人物的派系里，[r]　
虽说是幺子也要加入小仓家的人。[p]

会引发各种麻烦事态可谓显而易见。[p]

[vo vo="ep3/yuzu_0206.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「嘛，想些阴暗的事也无济于事！」[p]

[vo vo="ep3/yuzu_0207.ogg"]
#【小仓 柚叶】
「现在还是尽力而为吧！」[p]
[yuzuha_笑顔_c]

[vo vo="ep3/sayu_0073.ogg"]
[sayuri_哀]
#【稻饼 小百合】
「但该怎么办呢？[r]　
　校门口我多方调查过似乎什么都没有啊」[p]
[sayuri_哀_c]

[bgm_end2]

#
那确实是这样。[p]

「这下麻烦了呢」两人暂时陷入了沉思。[p]

休息时间也快要结束了。[p]

就在那个时候。[p]

[sayuri_驚き]
[yuzuha_驚き]


[vo vo="ep3/iori_0015.ogg"]
;//下記台詞は御手洗庵の声
#【？？？】
「哈～啊，我已经看不下去了啦」[p]

#
听到了似曾相识的声音。[p]

而且还是从头顶上传来的。[p]

[vo vo="ep3/sayu_0074.ogg"]
[sayuri_驚き]
#【稻饼 小百合】
「咦……这声音该不会……啊！」[p]
[sayuri_驚き_c]

#
小百合小姐抬头看着上方僵住了。[p]

我也不由自主地仰头望向天空。[p]


[eval exp="sf.cg_ep3_1 = 1"]
[event_in event="ep3_2"]

;BGM再生
[bgm ogg="mid_re.ogg"]

[vo vo="ep3/yuzu_0208.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「庵、庵、小庵！？」[p]
[yuzuha_驚き_c]

#
站在那里的是常去咖啡店的店员小庵。[p]

[vo vo="ep3/iori_0016.ogg"]
[iori_微笑]
#【御手洗 庵】
「呀吼—啊，在这里还是用这种问候方式比较好吧」[p]

[vo vo="ep3/iori_0017.ogg"]
#【御手洗 庵】
「日安，两位淑女♪」[p]
[iori_微笑_c]

#
她坐在树梢上心情愉快地朝这边挥手。[p]

[vo vo="ep3/sayu_0075.ogg"]
[sayuri_驚き]
#【稻饼 小百合】
「庵、庵庵庵庵庵同学！？为为为什么会在这里！？」[p]
[sayuri_驚き_c]

#
对女装店员的突然登场感到吃惊的不止我一个。[p]

曾经对小庵[r]　
怀有恋慕之情的小百合小姐比我更为震惊。[p]

不过那份恋心的后续发展究竟如何就不得而知了。[p]

[vo vo="ep3/iori_0018.ogg"]
[iori_微笑]
#【御手洗 庵】
「啊哈哈，谢谢你们这么捧场的反应」[p]

[vo vo="ep3/iori_0019.ogg"]
#【御手洗 庵】
「不过接下来能请两位暂时保持安静吗？」[p]
[iori_微笑_c]

#
话音刚落，小庵的视线移向我们身后。[p]

[event_out]

[vo vo="ep3/tea_0006.ogg"]
#【教师】
「你们几个，在那里做什么？」[p]

#
回头看见老师站在那里。[p]

[vo vo="ep3/yuzu_0209.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「咦！？啊、这个嘛——」[p]
[yuzuha_微笑_c]

#
正不知如何是好时，余光瞥向树上。[p]

[vo vo="ep3/iori_0020.ogg"]
[iori_微笑]
#【御手洗 庵】
「……嘘——」[p]
[iori_微笑_c]

#
她带着明媚笑容将食指抵在唇边。[p]

不知为何显得格外开心。[p]

眼下得想办法蒙混过关才行。[p]

要是被发现恐怕又会惹上麻烦事。[p]

[vo vo="ep3/sayu_0076.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「那个、我在找丢失的东西……」[p]
[sayuri_微笑_c]

#
小百合小姐低头盯着地面说道，以免老师抬头看见。[p]

真是个机灵的女孩子。[p]

我也决定仿效她的做法。[p]

[vo vo="ep3/yuzu_0210.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「是啊、我觉得应该就掉在这附近来着……！」[p]
[yuzuha_哀_c]

[vo vo="ep3/tea_0007.ogg"]
#【教师】
「这样啊……休息时间也快结束了，差不多该回教室了」[p]

#
老师说完便离开了现场。[p]

[vo vo="ep3/sayu_0077.ogg"]
[sayuri_哀]
#【稻饼 小百合】
「哈……总算蒙混过去了」[p]
[sayuri_哀_c]

[vo vo="ep3/iori_0021.ogg"]
[iori_微笑]
#【御手洗 庵】
「啊哈哈，干得漂亮」[p]
[iori_微笑_c]

#
坐在树上的小庵发出咯咯的笑声。[p]

[vo vo="ep3/iori_0022.ogg"]
[iori_微笑]
#【御手洗 庵】
「不过、就算被发现也提前准备好了文件[r]　
　应该能应付过去就是了」[p]

[vo vo="ep3/iori_0023.ogg"]
#【御手洗 庵】
「毕竟青春女学生[r]　
　在休息时间爬树肯定会被训斥呢」[p]

[vo vo="ep3/iori_0024.ogg"]
#【御手洗 庵】
「我啊、最讨厌挨骂了——」[p]
[iori_微笑_c]

[vo vo="ep3/yuzu_0211.ogg"]
[yuzuha_驚き]
[yuzuha_etc_off]
#【小仓 柚叶】
「比起这个、小庵你在这干什么呢？」[p]
[yuzuha_驚き_c]

[vo vo="ep3/iori_0025.ogg"]
[iori_微笑]
#【御手洗 庵】
「啊对对对、听说有重要的事要告诉我……嘿咻！」[p]
[iori_微笑_c]

#
说着，小庵从树上跳了下来。[p]

;SE：
[se_f se="landing1.ogg"]

优雅落地的身姿简直像猫咪一样。[p]

;庵衣装指定
[iori_c_セーラー服]

[iori_微笑_c]
[ri cg="iori"]

[vo vo="ep3/iori_0026.ogg"]
[iori_微笑]
#【御手洗 庵】
「呼～、着陆成功」[p]
[iori_微笑_c]

[vo vo="ep3/sayu_0078.ogg"]
[sayuri_哀]
#【稻饼 小百合】
「听说要告诉我……嗯？庵君这身打扮……」[p]
[sayuri_哀_c]

#
这时我才注意到小庵穿着和我们相同的制服。[p]

咦？比我穿着更合适？[p]

[vo vo="ep3/iori_0027.ogg"]
[iori_微笑]
#【御手洗 庵】
「啊呀、怎么样、还挺可爱的吧？」[p]
[iori_微笑_c]

[vo vo="ep3/yuzu_0212.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「我觉得超级可爱！」[p]
[yuzuha_笑顔_c]

[vo vo="ep3/sayu_0079.ogg"]
[sayuri_必死]
#【稻饼 小百合】
「不是那样的啦！」[p]
[sayuri_必死_c]

[vo vo="ep3/iori_0028.ogg"]
[iori_微笑]
#【御手洗 庵】
「啊哈哈，对不起对不起」[p]

[vo vo="ep3/iori_0029.ogg"]
#【御手洗 庵】
「其实我听到了关于比赛的事」[p]

[vo vo="ep3/iori_0030.ogg"]
#【御手洗 庵】
「如果能解开御伽俱乐部的谜题，[r]　
　就不用加入饴宫爱丽丝的派系了对吧」[p]

[vo vo="ep3/iori_0031.ogg"]
#【御手洗 庵】
「看来解谜进展相当艰难呢，我也会帮忙的」[p]
[iori_微笑_c]

[vo vo="ep3/yuzu_0213.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「噢！那可帮大忙了！」[p]
[yuzuha_笑顔_c]

#
对意外援军的加入不禁感到欣喜。[p]

相反小百合小姐却露出稍显失落的表情。[p]

[vo vo="ep3/sayu_0080.ogg"]
[sayuri_必死]
#【稻饼 小百合】
「话说庵君为什么会在这里？」[p]

[vo vo="ep3/sayu_0081.ogg"]
#【稻饼 小百合】
「这里是学院校区内，而且庵君不是学生吧？」[p]

[vo vo="ep3/sayu_0082.ogg"]
#【稻饼 小百合】
「再说无论外表如何，[r]　
　这里可是女校……还有那身制服是怎么回事？」[p]
[sayuri_必死_c]

#
经她这么一说确实如小百合小姐所言。[p]

[vo vo="ep3/iori_0032.ogg"]
[iori_微笑]
#【御手洗 庵】
「嗯……呵呵……秘密♪」[p]
[iori_微笑_c]

#
小庵顽皮地说道。[p]

[vo vo="ep3/sayu_0083.ogg"]
[sayuri_哀]
#【稻饼 小百合】
「说什么秘密……但如果被发现的话」[p]
[sayuri_哀_c]

[vo vo="ep3/iori_0033.ogg"]
[iori_微笑]
#【御手洗 庵】
「没问题的没问题，谢谢你担心我哦，稻饼小姐」[p]
[iori_微笑_c]

[vo vo="ep3/sayu_0084.ogg"]
[sayuri_必死]
#【稻饼 小百合】
「啊……呜……」[p]
[sayuri_必死_c]

#
被投以微笑的小百合小姐红着脸退缩了。[p]

看来她似乎还没从之前的状态中恢复。[p]

[vo vo="ep3/sayu_0085.ogg"]
[sayuri_必死]
#【稻饼 小百合】
「小柚叶！你也帮忙说点什么呀！」[p]
[sayuri_必死_c]

#
虽然被这样激励了……。[p]

[vo vo="ep3/yuzu_0214.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「嗯……嗯！这里就请你什么也别问先配合我吧！」[p]
[yuzuha_笑顔_c]

[vo vo="ep3/sayu_0086.ogg"]
[sayuri_驚き]
#【稻饼 小百合】
「诶？真、真的吗？」[p]
[sayuri_驚き_c]

[vo vo="ep3/iori_0034.ogg"]
[iori_微笑]
#【御手洗 庵】
「哦—，这才像话嘛！」[p]

[vo vo="ep3/iori_0035.ogg"]
#【御手洗 庵】
「那我们现在就得赶紧思考谜题了呢」[p]
[iori_微笑_c]

[bgm_end2]

;//予鈴のチャイム
[se_f se="school_bell.ogg"]


#
就在这时预备铃刚好响起。[p]

于是，小庵就这样直接离开了现场。[p]

[vo vo="ep3/yuzu_0215.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「小庵，你要怎么办？」[p]
[yuzuha_驚き_c]

#
稍微思考了一会儿之后小庵笑了。[p]

[vo vo="ep3/iori_0036.ogg"]
[iori_微笑]
#【御手洗 庵】
「嗯……好，那就这样吧」[p]

[vo vo="ep3/iori_0037.ogg"]
#【御手洗 庵】
「放学后就在另一个出口碰头咯」[p]
[iori_微笑_c]

;//時間経過
;テキストウィンドウ削除
[end_text]

;全キャラ削除
[allc]

;//黒ベタ
[bg10 bg="black.png"]

;//停止
[wait time=2000]

;//教室
[bg10 bg="school.jpg"]

[yuzuha_微笑_c]
[lec_f cg="yuzuha"]

[sayuri_微笑_c]
[ric cg="sayuri"]

;テキストウィンドウ表示
[start_text_yuzu]
;//放課後

;BGM再生
[bgm ogg="music.ogg"]

[vo vo="ep3/sayu_0087.ogg"]
[sayuri_哀]
#【稻饼 小百合】
「为什么……为什么庵君会在这里……」[p]
[sayuri_哀_c]

#
放学后。[p]

小百合小姐似乎还无法掩饰对小庵出现的动摇。[p]

[vo vo="ep3/sayu_0088.ogg"]
[sayuri_必死]
#【稻饼 小百合】
「明明是男孩子……连制服都穿着……啊啊真是的……！」[p]
[sayuri_必死_c]

#
确实这番登场充满谜团。[p]

作为常去咖啡店店员的他，为何会出现在此。[p]

而且还主动提出要协助解开御伽俱乐部的谜题。[p]

[vo vo="ep3/sayu_0089.ogg"]
[sayuri_哀]
#【稻饼 小百合】
「庵君你……到底是什么人？」[p]
[sayuri_哀_c]

[vo vo="ep3/yuzu_0216.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「唔，就是个普通的女装店员……吧？」[p]
[yuzuha_疑問_c]

[vo vo="ep3/sayu_0090.ogg"]
[sayuri_哀]
#【稻饼 小百合】
「普通什么的……光是这点就觉得不普通了吧」[p]
[sayuri_哀_c]

#
这确实说得没错。[p]

但是――。[p]

[vo vo="ep3/yuzu_0217.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「现在当务之急是先解开御伽俱乐部的谜题！」[p]
[yuzuha_笑顔_c]

#
小庵的事之后考虑也不迟。[p]

从小时候起就是一旦在意某件事[r]　
就会对其他事完全不在乎的类型。[p]

[bgm_end2]

[vo vo="ep3/sayu_0091.ogg"]
[sayuri_哀]
#【稻饼 小百合】
「诶—，可是……果然还是很危险吧？」[p]
[sayuri_哀_c]

[vo vo="ep3/yuzu_0218.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「那让小庵回去可以吗？」[p]
[yuzuha_微笑_c]

[vo vo="ep3/sayu_0092.ogg"]
[sayuri_哀]
#【稻饼 小百合】
「那个……唔唔……」[p]

[vo vo="ep3/sayu_0093.ogg"]
[sayuri_必死]
#【稻饼 小百合】
「虽然让回去比较好……但……能待在身边说不定也让人开心……」[p]
[sayuri_必死_c]

#
红着脸的小百合小姐说道。[p]

这样坦率的部分也正是小百合小姐的优点。[p]

;BGM再生
[bgm ogg="tukikage.ogg"]

[vo vo="ep3/yuzu_0219.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「那就先请你协助吧！」[p]
[yuzuha_笑顔_c]

[vo vo="ep3/sayu_0094.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「明白了……那我们快去集合地点吧」[p]
[sayuri_微笑_c]

[vo vo="ep3/yuzu_0220.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「记得……是说另一个入口对吧？」[p]

[vo vo="ep3/yuzu_0221.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「那是什么意思？」[p]
[yuzuha_疑問_c]

#
两人暂时陷入思考。[p]

小庵所在等候的地方是……。[p]

;全キャラ削除
[allc]

;シーン6へ移動
[jump  storage="ep3_scene06.ks"]
[s]