﻿;--------------------------------------------------
;■黒十　本文テキスト　ep3　御伽倶楽部
;--------------------------------------------------
;
;■ep3_scene06
;
;--------------------------------------------------
[eval exp="f.third_select=0"]
[eval exp="f.third_map_1=0"]
[eval exp="f.third_map_2=0"]
[eval exp="f.third_map_3=0"]
[eval exp="f.third_map_4=0"]
[eval exp="f.third_map_5=0"]
;--------------------------------------------------
;//地図画面
*third_select
[savetitle text="地図画面"]
;-------------------------------------------------
;//２回場所移動を間違うとバッド・エンドのルート『どの道を行ったらいいの？』へ
[if exp="f.third_select==2"]
[jump target="*third_select_end"]
[else]
[jump target="*third_select_map"]
[endif]

;--------------------------------------------------
*third_select_map
[savetitle text="地図画面"]
;-------------------------------------------------
;//前画面の要素を削除

;テキストウィンドウ削除
[end_text]

;全キャラ削除
[allc]

;//黒ベタ
[bg10 bg="black.png"]


[bg10 bg="select_map.jpg"]

;BGM再生
[bgm ogg="tukikage.ogg"]

;//場所移動の選択肢--------------------------------------------------

*third_map_1
[if exp="f.third_map_1==1"]
[jump target="*third_map_2]
[else]
[endif]

;//１：校門
[button name="role_button" x="140" y="521" graphic="map/btn_select_11_off.png" enterimg="map/btn_select_11_on.png" clickimg="map/btn_select_11_off.png" target="*third_select_1"  enterse="cursor1.ogg" clickse="decision5.ogg" exp="f.third_select=f.third_select+1"]

*third_map_2
[if exp="f.third_map_2==1"]
[jump target="*third_map_3]
[else]
[endif]

;//２：食堂
[button name="role_button" x="508" y="196" graphic="map/btn_select_05_off.png" enterimg="map/btn_select_05_on.png" clickimg="map/btn_select_05_off.png" target="*third_select_2"  enterse="cursor1.ogg" clickse="decision5.ogg" exp="f.third_select=f.third_select+1"]

*third_map_3
[if exp="f.third_map_3==1"]
[jump target="*third_map_4]
[else]
[endif]

;//３：旧校舎前
[button name="role_button" x="605" y="13" graphic="map/btn_select_08_off.png" enterimg="map/btn_select_08_on.png" clickimg="map/btn_select_08_off.png" target="*third_select_3"  enterse="cursor1.ogg" clickse="decision5.ogg" exp="f.third_select=f.third_select+1"]

*third_map_4
[if exp="f.third_map_4==1"]
[jump target="*third_map_5]
[else]
[endif]

;//４：旧校舎の庭園
[button name="role_button" x="752" y="100" graphic="map/btn_select_09_off.png" enterimg="map/btn_select_09_on.png" clickimg="map/btn_select_09_off.png" target="*third_select_4"  enterse="cursor1.ogg" clickse="decision5.ogg" exp="f.third_select=f.third_select+1"]

*third_map_5

;//５：裏門
[button name="role_button" x="976" y="30" graphic="map/btn_select_12_off.png" enterimg="map/btn_select_12_on.png" clickimg="map/btn_select_12_off.png" target="*third_select_5"  enterse="cursor1.ogg" clickse="decision5.ogg" exp="f.third_select=f.third_select+1"]

[showmenubutton]

[s]

;--------------------------------------------------
;//■ルート『どの道を行ったらいいの？』
*third_select_end
[savetitle text="『どの道を行ったらいいの？』"]
;-------------------------------------------------
[bgm_end1]

;SE：チャイム
[se_f se="school_bell.ogg"]

[yuzuha_驚き]

[sayuri_驚き]


[vo vo="ep3/yuzu_0222.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「啊呀～！上课铃都响了～！」[p]
[yuzuha_哀_c]

[vo vo="ep3/sayu_0095.ogg"]
[sayuri_哀]
#【稻饼 小百合】
「怎、怎么办，明明和庵约好要碰面的！」[p]
[sayuri_哀_c]

#
两人四处寻找后[r]　
最终还是没能找到和小庵约定的地点。[p]

;全キャラ削除
[allc]

;//空
[bg10 bg="autumn.jpg"]

[vo vo="ep3/iori_0038.ogg"]
#【御手洗 庵】
「哈啾……哈……开始变冷了呢」[p]

;//終わり

;テキストウィンドウ削除
[end_text]


;//ルート『どの道を行ったらいいの？』おわり
[eval exp="sf.ep3_end3 = 1"]
[bg  storage="ep3_end_3.jpg" time="2000"]

;処理を停止します
[wa]
[wait time=1000]
[p]

;バッジ獲得用タグ
;[give_emblem id="5347" pid="7b0b85253a2943a5047cd68e6cfc9afb"]

;背景：暗転
[bg30 bg="black.png"]

;タイトル画面へ移動
[jump  storage="title_screen.ks"  target="*title"]

[s]

;//タイトル『どの道を行ったらいいの？』


;--------------------------------------------------
;//選択肢１：校門
*third_select_1
[savetitle text="校門"]
;-------------------------------------------------

[eval exp="f.third_map_1=1"]

;選択肢ボタンクリア
[bgm_end1]
[cm]
[clearfix]

;//黒ベタ
[bg20 bg="black.png"]


;//校門
[bg10 bg="school_gate.jpg"]

;BGM再生
[bgm ogg="music.ogg"]

[yuzuha_微笑_c]
[lec_f cg="yuzuha"]

[sayuri_微笑_c]
[ric cg="sayuri"]

;テキストウィンドウ表示
[start_text_yuzu]

#
和小百合小姐一起走到校门前。[p]

[vo vo="ep3/yuzu_0223.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「刚才就是在这里和小庵碰面的对吧」[p]
[yuzuha_微笑_c]

[vo vo="ep3/sayu_0096.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「嗯，不过那会儿真是吓一跳」[p]
[sayuri_微笑_c]

[vo vo="ep3/yuzu_0224.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「没想到会从树上突然出现……而且还是穿着制服！」[p]
[yuzuha_笑顔_c]

[vo vo="ep3/sayu_0097.ogg"]
[sayuri_照れ]
#【稻饼 小百合】
「嗯，很、很衬你呢」[p]
[sayuri_照れ_c]

[vo vo="ep3/yuzu_0225.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「你那边也让人很惊讶呢！」[p]
[yuzuha_微笑_c]

[vo vo="ep3/sayu_0098.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「而且约定的放学时间已经到了，赶快去找庵吧」[p]

[vo vo="ep3/sayu_0099.ogg"]
#【稻饼 小百合】
「虽然他说过是另一个入口来着」[p]
[sayuri_微笑_c]

;//地図画面
;//場所移動の選択肢
[jump target="*third_select"]


;-------------------------------------------------- 
;//選択肢２：食堂
*third_select_2
[savetitle text="食堂"]
;-------------------------------------------------

[eval exp="f.third_map_2=1"]

;選択肢ボタンクリア
[bgm_end1]
[cm]
[clearfix]


;//黒ベタ
[bg20 bg="black.png"]

;BGM再生
[bgm ogg="4656.ogg"]

;//食堂
[bg10 bg="cafeteria.jpg"]

[yuzuha_微笑_c]
[lec_f cg="yuzuha"]

[sayuri_微笑_c]
[ric cg="sayuri"]


;テキストウィンドウ表示
[start_text_yuzu]

[vo vo="ep3/yuzu_0226.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「啊～……咖喱看起来好好吃啊～～」[p]
[yuzuha_微笑_c]

[vo vo="ep3/sayu_0100.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「小柚叶……你喜欢咖喱吗？」[p]
[sayuri_微笑_c]

[vo vo="ep3/yuzu_0227.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「这家食堂的咖喱简直是绝品啊～～」[p]
[yuzuha_笑顔_c]

[vo vo="ep3/sayu_0101.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「但庵好像不在这里」[p]
[sayuri_微笑_c]

[vo vo="ep3/yuzu_0228.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「啊，对哦！[r]　
　因为他说是另一个入口我才想到这里」[p]
[yuzuha_微笑_c]

#
看来我的判断似乎错了。[p]

[vo vo="ep3/sayu_0102.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「赶快去别的地方找吧」[p]
[sayuri_微笑_c]

;//地図画面
;//場所移動の選択肢
[jump target="*third_select"]


;-------------------------------------------------- 
;//選択肢３：旧校舎前
*third_select_3
[savetitle text="旧校舎前"]
;-------------------------------------------------

[eval exp="f.third_map_3=1"]

;選択肢ボタンクリア
[bgm_end1]
[cm]
[clearfix]


;//黒ベタ
[bg20 bg="black.png"]


;BGM再生
[bgm ogg="music.ogg"]

;//旧校舎前
[bg10 bg="garden_1.jpg"]

[yuzuha_微笑_c]
[lec_f cg="yuzuha"]

[sayuri_微笑_c]
[ric cg="sayuri"]

;テキストウィンドウ表示
[start_text_yuzu]

[vo vo="ep3/yuzu_0229.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「哎呀、虽然来到旧校舍了……」[p]
[yuzuha_微笑_c]

[vo vo="ep3/sayu_0103.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「这里就是庵同学说的另一个入口？」[p]
[sayuri_微笑_c]

[vo vo="ep3/yuzu_0230.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「呃——如果说我们平时使用的校舍正门不对的话、[r]　
　应该就是指这边的校门了吧」[p]
[yuzuha_疑問_c]

[vo vo="ep3/sayu_0104.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「啊—原来如此！但关键的庵同学似乎不在呢」[p]
[sayuri_微笑_c]

[vo vo="ep3/yuzu_0231.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「是啊……」[p]
[yuzuha_哀_c]

#
看来庵同学所说的另一个入口似乎不在这里。[p]

[vo vo="ep3/yuzu_0232.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「那另一个入口会在哪里呢？」[p]
[yuzuha_疑問_c]

;//地図画面
;//場所移動の選択肢
[jump target="*third_select"]

;--------------------------------------------------
;//選択肢４：旧校舎の庭園
*third_select_4
[savetitle text="旧校舎の庭園"]
;-------------------------------------------------

[eval exp="f.third_map_4=1"]

;選択肢ボタンクリア
[bgm_end1]
[cm]
[clearfix]


;//黒ベタ
[bg20 bg="black.png"]

;BGM再生
[bgm ogg="music.ogg"]

;//旧校舎の庭園
[bg10 bg="garden_2.jpg"]

[yuzuha_微笑_c]
[lec_f cg="yuzuha"]

[sayuri_微笑_c]
[ric cg="sayuri"]

;テキストウィンドウ表示
[start_text_yuzu]

[vo vo="ep3/yuzu_0233.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「居然有这种地方？」[p]
[yuzuha_疑問_c]

[vo vo="ep3/sayu_0105.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「我还是第一次进旧校舍呢」[p]
[sayuri_微笑_c]

[vo vo="ep3/yuzu_0234.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「我也是我也是！」[p]
[yuzuha_笑顔_c]

[vo vo="ep3/sayu_0106.ogg"]
[sayuri_哀]
#【稻饼 小百合】
「虽然没来过这里、但这就是庵同学说的另一个入口？」[p]
[sayuri_哀_c]

#
顺着小百合小姐的话环顾四周，却不见庵同学的身影。[p]

[vo vo="ep3/yuzu_0235.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「果然不对……对吧！」[p]
[yuzuha_疑問_c]

[vo vo="ep3/sayu_0107.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「啊哈哈、我们去别处找找吧」[p]
[sayuri_微笑_c]

;//地図画面
;//場所移動の選択肢
[jump target="*third_select"]

;--------------------------------------------------
;//選択肢５：裏門
*third_select_5
[savetitle text="裏門"]
;-------------------------------------------------

;選択肢ボタンクリア
[bgm_end1]
[cm]
[clearfix]


;//黒ベタ
[bg20 bg="black.png"]


;//裏門
[bg10 bg="back_gate.jpg"]

[yuzuha_微笑_c]
[lec_f cg="yuzuha"]

[sayuri_微笑_c]
[ric cg="sayuri"]

;テキストウィンドウ表示
[start_text_yuzu]

[vo vo="ep3/yuzu_0236.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「刚才试过正门……那就是后门了！」[p]
[yuzuha_笑顔_c]

[vo vo="ep3/sayu_0108.ogg"]
[sayuri_笑顔]
#【稻饼 小百合】
「对哦、也可以叫后门呢」[p]
[sayuri_笑顔_c]

#
于是将集合地点定在了后门。[p]

;全キャラ消去
[kill]

[yuzuha_微笑_c]
[le cg="yuzuha"]

[sayuri_微笑_c]
[ce cg="sayuri"]

[iori_微笑_c]
[ri cg="iori"]

[vo vo="ep3/iori_0039.ogg"]
[iori_微笑]
#【御手洗 庵】
「噢、来了来了」[p]
[iori_微笑_c]

;BGM再生
[bgm ogg="music.ogg"]

#
那里果然如预料般出现了小庵的身影。[p]

[vo vo="ep3/sayu_0109.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「果然另一个入口指的就是后门啊」[p]
[sayuri_微笑_c]

[vo vo="ep3/iori_0040.ogg"]
[iori_微笑]
#【御手洗 庵】
「对对、理解得很到位嘛」[p]
[iori_微笑_c]

[vo vo="ep3/sayu_0110.ogg"]
[sayuri_哀]
#【稻饼 小百合】
「那是柚叶她……比起这个你没事吧？」[p]

[vo vo="ep3/sayu_0111.ogg"]
#【稻饼 小百合】
「没被人发现或怀疑吗？」[p]
[sayuri_哀_c]

[vo vo="ep3/iori_0041.ogg"]
[iori_微笑]
#【御手洗 庵】
「嗯没事的，大家都很自然地走过去了」[p]

[vo vo="ep3/iori_0042.ogg"]
#【御手洗 庵】
「果然穿这身是正确的选择呢」[p]
[iori_微笑_c]

#
确实以这副模样根本不会引起任何问题。[p]

[vo vo="ep3/yuzu_0237.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「不管怎么看都是女孩子嘛——」[p]
[yuzuha_微笑_c]

[vo vo="ep3/sayu_0112.ogg"]
[sayuri_必死]
#【稻饼 小百合】
「呜、嗯……是啊」[p]
[sayuri_必死_c]

#
曾经被这副模样[r]　
彻底骗过的小百合小姐苦笑着回应。[p]

[vo vo="ep3/yuzu_0238.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「对了，现在得先找到御伽俱乐部的活动场所才行！」[p]
[yuzuha_微笑_c]

[vo vo="ep3/iori_0043.ogg"]
[iori_微笑]
#【御手洗 庵】
「在你们来之前我大概找过一轮，[r]　
　你们觉得呢」[p]

[vo vo="ep3/iori_0044.ogg"]
#【御手洗 庵】
「有什么特别的地方吗？」[p]
[iori_微笑_c]

[vo vo="ep3/sayu_0113.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「这个嘛，乍看之下……」[p]
[sayuri_微笑_c]

[vo vo="ep3/yuzu_0239.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「毕竟我们几乎没来过这个后门呢」[p]
[yuzuha_微笑_c]

[vo vo="ep3/iori_0045.ogg"]
[iori_無表情]
#【御手洗 庵】
「原来如此……[r]　
　果然还是该仔细搜查这附近才行」[p]
[iori_無表情_c]

;全キャラ削除
[allc]

[bgm_end2]

[bg10 bg="black.png"]

#
于是三人决定在后门周边[r]　
寻找是否存在异常或值得注意的地方。[p]

但无论如何搜寻[r]　
莫说御伽俱乐部的痕迹，连特别之处都未能发现。[p]

;//裏門
[bg10 bg="back_gate.jpg"]


[yuzuha_疑問_c]
[le_f cg="yuzuha"]

[sayuri_哀_c]
[ce_f cg="sayuri"]

[iori_無表情_c]
[ri cg="iori"]

[vo vo="ep3/yuzu_0240.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「嗯……难道后门也不对劲吗」[p]
[yuzuha_疑問_c]

[vo vo="ep3/sayu_0114.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「你觉得呢？」[p]
[sayuri_微笑_c]

[vo vo="ep3/yuzu_0241.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「啊，我去那边看看！」[p]
[yuzuha_笑顔_c]

[vo vo="ep3/sayu_0115.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「嗯，拜托了」[p]
[sayuri_微笑_c]

;//柚葉が離れる
;キャラ消去
[chara_hide name=yuzuha]

;BGM再生
[bgm ogg="you_are_precious.ogg"]


[vo vo="ep3/sayu_0116.ogg"]
[sayuri_哀]
#【稻饼 小百合】
「……………那个，庵君」[p]
[sayuri_哀_c]

[vo vo="ep3/iori_0046.ogg"]
[iori_微笑]
#【御手洗 庵】
「嗯？发生什么了吗？」[p]
[iori_微笑_c]

[vo vo="ep3/sayu_0117.ogg"]
[sayuri_哀]
#【稻饼 小百合】
「不，倒不是那样……」[p]

[vo vo="ep3/sayu_0118.ogg"]
#【稻饼 小百合】
「虽然小柚叶那么说了，但我果然还是……」[p]
[sayuri_哀_c]

[vo vo="ep3/iori_0047.ogg"]
[iori_無表情]
#【御手洗 庵】
「……你是好奇我为什么在这里吧？」[p]
[iori_無表情_c]

[vo vo="ep3/sayu_0119.ogg"]
[sayuri_哀]
#【稻饼 小百合】
「嗯……」[p]
[sayuri_哀_c]

[vo vo="ep3/iori_0048.ogg"]
[iori_無表情]
#【御手洗 庵】
「嘛，也确实会好奇呢……」[p]
[iori_無表情_c]

[vo vo="ep3/sayu_0120.ogg"]
[sayuri_哀]
#【稻饼 小百合】
「……抱歉」[p]
[sayuri_哀_c]

[vo vo="ep3/iori_0049.ogg"]
[iori_微笑]
#【御手洗 庵】
「哈哈，稻饼小姐为什么要道歉啊」[p]
[iori_微笑_c]

[vo vo="ep3/sayu_0121.ogg"]
[sayuri_哀]
#【稻饼 小百合】
「是、是吗？唔……」[p]
[sayuri_哀_c]

[vo vo="ep3/iori_0050.ogg"]
[iori_微笑]
#【御手洗 庵】
「啊——别摆出那种表情啦」[p]

[vo vo="ep3/iori_0051.ogg"]
#【御手洗 庵】
「哈……真拿你没办法」[p]
[iori_微笑_c]

[vo vo="ep3/sayu_0122.ogg"]
[sayuri_驚き]
#【稻饼 小百合】
「庵同学？」[p]
[sayuri_驚き_c]

[vo vo="ep3/iori_0052.ogg"]
[iori_無表情]
#【御手洗 庵】
「不能让小柚叶参加饴宫爱丽丝的茶会」[p]

[vo vo="ep3/iori_0053.ogg"]
#【御手洗 庵】
「有些人不认可那种形式的来往」[p]
[iori_無表情_c]

[vo vo="ep3/sayu_0123.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「也就是说……」[p]
[sayuri_微笑_c]

[vo vo="ep3/iori_0054.ogg"]
[iori_無表情]
#【御手洗 庵】
「那位饴宫集团的千金小姐，可有不少可疑传闻」[p]

[vo vo="ep3/iori_0055.ogg"]
#【御手洗 庵】
「找到玩具就弄坏，再换新玩具……」[p]

[vo vo="ep3/iori_0056.ogg"]
#【御手洗 庵】
「这个学园里也有几个学生被她以恶劣的方式相中，[r]　
　好像成了那孩子的猎物」[p]

[vo vo="ep3/iori_0057.ogg"]
#【御手洗 庵】
「这次也未必不会重演……[r]　
　绝不能让柚叶大人成为她的玩具」[p]
[iori_無表情_c]

[vo vo="ep3/sayu_0124.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「……庵同学是被想阻止这件事的人委托才来的？」[p]
[sayuri_微笑_c]

[vo vo="ep3/iori_0058.ogg"]
[iori_無表情]
#【御手洗 庵】
「…………」[p]
[iori_無表情_c]

[vo vo="ep3/sayu_0125.ogg"]
[sayuri_驚き]
#【稻饼 小百合】
「啊，难道之前在咖啡店说谎也是――」[p]
[sayuri_驚き_c]

[vo vo="ep3/iori_0059.ogg"]
[iori_無表情]
#【御手洗 庵】
「这已经不能说下去了……[r]　
　不是不想说，而是不能说，对不起」[p]
[iori_無表情_c]

[vo vo="ep3/sayu_0126.ogg"]
[sayuri_哀]
#【稻饼 小百合】
「…………」[p]
[sayuri_哀_c]

[vo vo="ep3/iori_0060.ogg"]
[iori_微笑]
#【御手洗 庵】
「好了，柚叶大人要回来了」[p]

[vo vo="ep3/iori_0061.ogg"]
#【御手洗 庵】
「若能对此事保密我会很高兴」[p]
[iori_微笑_c]

[vo vo="ep3/sayu_0127.ogg"]
[sayuri_必死]
#【稻饼 小百合】
「庵君，最后再告诉我一件事」[p]

[vo vo="ep3/sayu_0128.ogg"]
#【稻饼 小百合】
「……为什么要把这件事告诉我？」[p]
[sayuri_必死_c]

[vo vo="ep3/iori_0062.ogg"]
[iori_無表情]
#【御手洗 庵】
「…………」[p]

[vo vo="ep3/iori_0063.ogg"]
#【御手洗 庵】
「可能是因为……不想再对你说谎了吧」[p]
[iori_無表情_c]

[vo vo="ep3/sayu_0129.ogg"]
[sayuri_驚き]
#【稻饼 小百合】
「诶？」[p]
[sayuri_驚き_c]

[vo vo="ep3/iori_0064.ogg"]
[iori_微笑]
#【御手洗 庵】
「因为你是唯一愿意接纳这样满嘴谎言又肮脏的我……[r]　
　还说我很干净的女生」[p]
[iori_微笑_c]

[vo vo="ep3/sayu_0130.ogg"]
[sayuri_照れ]
#【稻饼 小百合】
「啊……」[p]
[sayuri_照れ_c]

[vo vo="ep3/iori_0065.ogg"]
[iori_微笑]
#【御手洗 庵】
「嘿嘿，开玩笑的――小柚叶，那边有发现吗？」[p]
[iori_微笑_c]

;//柚葉が戻ってくる
[yuzuha_微笑_c]
[le cg="yuzuha"]

[vo vo="ep3/yuzu_0242.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「没、完全没有……你们这边找到了什么吗？」[p]
[yuzuha_微笑_c]

[vo vo="ep3/iori_0066.ogg"]
[iori_微笑]
#【御手洗 庵】
「这边也毫无收获呢」[p]
[iori_微笑_c]

[vo vo="ep3/sayu_0131.ogg"]
[sayuri_照れ]
#【稻饼 小百合】
「…………」[p]
[sayuri_照れ_c]

[vo vo="ep3/yuzu_0243.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「……小百合小姐？你脸色好红，怎么了？」[p]
[yuzuha_微笑_c]

#
回来时注意到小百合小姐的样子有些反常。[p]

[vo vo="ep3/sayu_0132.ogg"]
[sayuri_驚き]
#【稻饼 小百合】
「啊！？没、没什么事啦！」[p]
[sayuri_驚き_c]

#
本以为发生了什么，看来是我想多了。[p]

[bgm_end2]

[vo vo="ep3/yuzu_0244.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「没事就好，[r]　
　果然御伽俱乐部的活动地点也不在后门呢」[p]
[yuzuha_微笑_c]

[vo vo="ep3/iori_0067.ogg"]
[iori_微笑]
;//読み方『学園の□』→学園のくち
#【御手洗 庵】
「是啊……[r]　
　再重新思考下『学院之口』究竟指什么吧」[p]
[iori_微笑_c]

#
被小庵这么一说，我取出爱丽丝前辈给的纸条。[p]

;BGM再生
[bgm ogg="mid_re.ogg"]

[vo vo="ep3/yuzu_0245.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「唔——如果这个‘口’指的不是校门也不是后门的话……[r]　
　那还会是哪里呢——？」[p]
[yuzuha_疑問_c]

#
她盯着纸上描绘的校园□形符号凝视许久。[p]

但始终没有灵光一现的念头浮现。[p]

这时，小庵突然开口了。[p]

[vo vo="ep3/iori_0068.ogg"]
[iori_微笑]
#【御手洗 庵】
「要不要换个思考方式？」[p]

[vo vo="ep3/iori_0069.ogg"]
;//読み方『学園の□』→学園のくち
#【御手洗 庵】
「不把‘学园之口’当成字面意思……试试其他解读方法如何？」[p]
[iori_微笑_c]

[vo vo="ep3/sayu_0133.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「其他解读？」[p]
[sayuri_微笑_c]

[vo vo="ep3/iori_0070.ogg"]
[iori_微笑]
;//読み方『学園の□』→学園のしかく
#【御手洗 庵】
「比如……学园的□……解读为学园的死角，之类的」[p]
[iori_微笑_c]

[vo vo="ep3/yuzu_0246.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「死角……啊！死角！确实也能这么解读呢！」[p]
[yuzuha_驚き_c]

[vo vo="ep3/sayu_0134.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「但死角具体指哪里？」[p]
[sayuri_微笑_c]

[vo vo="ep3/iori_0071.ogg"]
[iori_微笑]
#【御手洗 庵】
「校园范围里能成为死角的地方可太多啦」[p]
[iori_微笑_c]

[vo vo="ep3/sayu_0135.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「而且观察角度不同死角也会变化……」[p]
[sayuri_微笑_c]

[vo vo="ep3/iori_0072.ogg"]
[iori_無表情]
#【御手洗 庵】
「就是说啊……嗯，单靠我们果然还是太难了吧」[p]

[vo vo="ep3/iori_0073.ogg"]
#【御手洗 庵】
「真希望能有擅长这种推理的帮手呢……」[p]
[iori_無表情_c]

#
小庵嘀嘀咕咕地陷入沉思。[p]

不过除了按"死角"这个线索寻找外，似乎别无他法。[p]

;キャラ消去
[chara_hide name=iori]

[vo vo="ep3/yuzu_0247.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「总之先找找看死角吧！」[p]

[vo vo="ep3/yuzu_0248.ogg"]
#【小仓 柚叶】
「说不定找着找着就能发现什么！」[p]
[yuzuha_微笑_c]

[vo vo="ep3/sayu_0136.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「说得对，或许还能想到其他线索」[p]
[sayuri_微笑_c]

[vo vo="ep3/alice_0064.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「原来你们在这里，让我好找」[p]
[alice_笑み_c]

[kill]

[yuzuha_驚き_c]
[c3_f cg="yuzuha"]

[sayuri_微笑_c]
[c4_f cg="sayuri"]

[alice_笑み_c]
[c2_f cg="alice"]

[kaguya_無表情_c]
[c1 cg="kaguya"]

[vo vo="ep3/yuzu_0249.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「爱丽丝前辈……还有辉夜前辈」[p]
[yuzuha_驚き_c]

[vo vo="ep3/kaguya_0020.ogg"]
[kaguya_無表情]
#【蓬 辉夜】
「好像找了很久呢」[p]
[kaguya_無表情_c]

[vo vo="ep3/yuzu_0250.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「啊哈哈，这个嘛……」[p]
[yuzuha_微笑_c]

[vo vo="ep3/alice_0065.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「那么，有什么发现吗」[p]
[alice_笑み_c]

[vo vo="ep3/yuzu_0251.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「没有……其实还什么都没」[p]
[yuzuha_哀_c]

[vo vo="ep3/alice_0066.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「也是呢，看你的脸色就能猜到是这样了」[p]
[alice_笑み_c]

[vo vo="ep3/yuzu_0252.ogg"]
[yuzuha_怒]
#【小仓 柚叶】
「……那就不该问啊」[p]
[yuzuha_怒_c]

[vo vo="ep3/kaguya_0021.ogg"]
[kaguya_無表情]
#【蓬 辉夜】
「对爱丽丝说什么都是白费功夫，认清她是这类人就好」[p]
[kaguya_無表情_c]


[yuzuha_驚き_c]

#
面对小声嘟囔的我，辉夜前辈无奈地说道。[p]

看来她似乎察觉到了我的心情。[p]

[vo vo="ep3/alice_0067.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「所以，现在在做什么呢？说明看看」[p]
[alice_笑み_c]


[yuzuha_怒_c]

#
这副高高在上的态度让人忍不住想抱怨几句。[p]

但做这种事也是徒劳[r]　
因为辉夜前辈的眼神制止了我，我决定作罢。[p]

[vo vo="ep3/yuzu_0253.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「呃——那个啊」[p]
[yuzuha_微笑_c]

;全キャラ削除
[allc]

;//空とか
[bg10 bg="autumn.jpg"]

#
我决定老实地说明至今的经过。[p]

;//時間経過
;テキストウィンドウ削除
[end_text]

;全キャラ削除
[allc]

;//黒ベタ
[bg10 bg="black.png"]

;//停止
[wait time=2000]

;//教室
[bg10 bg="back_gate.jpg"]

[yuzuha_微笑_c]
[c3_f cg="yuzuha"]

[sayuri_微笑_c]
[c4_f cg="sayuri"]

[alice_笑み_c]
[c2_f cg="alice"]

[kaguya_無表情_c]
[c1 cg="kaguya"]

;テキストウィンドウ表示
[start_text_yuzu]

[vo vo="ep3/yuzu_0254.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「就是这样，现在正打算用所谓死角来寻找」[p]
[yuzuha_微笑_c]

[vo vo="ep3/alice_0068.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「哼——嗯，看来稍微往靠谱的方向前进了呢」[p]

[vo vo="ep3/alice_0069.ogg"]
#【饴宫 爱丽丝】
「这、是你想的吗？」[p]
[alice_笑み_c]

[vo vo="ep3/yuzu_0255.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「不是！这个方案是小庵……咦？」[p]
[yuzuha_微笑_c]

#
我环顾四周，却发现不知何时没了小庵的身影。[p]

[vo vo="ep3/yuzu_0256.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「不见了……去哪儿了呢？」[p]
[yuzuha_疑問_c]

[vo vo="ep3/sayu_0137.ogg"]
[sayuri_驚き]
#【稻饼 小百合】
「不知道，刚才还在这里的……」[p]
[sayuri_驚き_c]

[vo vo="ep3/alice_0070.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「你在说什么莫名其妙的话？」[p]
[alice_笑み_c]

[vo vo="ep3/yuzu_0257.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「啊、抱歉！」[p]
[yuzuha_微笑_c]

[vo vo="ep3/alice_0071.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「不过看你的样子确实在认真找啦」[p]
[alice_笑み_c]

#
虽然很在意小庵的去向，[r]　
但这人从相遇时起就神出鬼没。[p]

应该不必太担心吧。[p]

[vo vo="ep3/yuzu_0258.ogg"]
[sayuri_微笑]
[yuzuha_疑問]
#【小仓 柚叶】
「比起这个，学姐你们为什么会来这种地方？」[p]

[vo vo="ep3/yuzu_0259.ogg"]
#【小仓 柚叶】
「总不可能是专程来取笑的吧」[p]
[yuzuha_疑問_c]

[vo vo="ep3/alice_0072.ogg"]
[alice_ドヤ顔]
#【饴宫 爱丽丝】
「嗯～也算是原因之一呢」[p]
[alice_ドヤ顔_c]

[vo vo="ep3/sayu_0138.ogg"]
[sayuri_哀]
#【稻饼 小百合】
「还真是啊……」[p]
[sayuri_哀_c]

[vo vo="ep3/alice_0073.ogg"]
[alice_ドヤ顔]
#【饴宫 爱丽丝】
「今后也让我们参与进来吧」[p]
[alice_ドヤ顔_c]

#
爱丽丝学姐的发言让我措手不及。[p]


[vo vo="ep3/yuzu_0260.ogg"]
[sayuri_驚き]
[yuzuha_驚き]
#【小仓 柚叶】
「咦！？难道说――」[p]
[yuzuha_驚き_c]

[vo vo="ep3/kaguya_0022.ogg"]
[kaguya_無表情]
#【蓬 辉夜】
「什么意思嘛」[p]
[kaguya_無表情_c]

#
被爱丽丝学姐惊到的不光是我和小百合小姐，[r]　
连辉夜学姐也不例外。[p]

[vo vo="ep3/alice_0074.ogg"]
[alice_ドヤ顔]
#【饴宫 爱丽丝】
「有什么关系嘛辉夜，那样才有趣呀」[p]
[alice_ドヤ顔_c]

[vo vo="ep3/kaguya_0023.ogg"]
[kaguya_呆れ]
#【蓬 辉夜】
「或许你觉得有趣，[r]　
　但也该体谅被迫奉陪的我吧」[p]
[kaguya_呆れ_c]

[vo vo="ep3/alice_0075.ogg"]
[alice_ドヤ顔]
#【饴宫 爱丽丝】
「好啦好啦，总之辉夜你也得一起来」[p]
[alice_ドヤ顔_c]

#
辉夜学姐听着爱丽丝学姐的话，扶额摇头。[p]

[vo vo="ep3/yuzu_0261.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「请稍等」[p]

[vo vo="ep3/yuzu_0262.ogg"]
#【小仓 柚叶】
「意思是学姐们也要一起寻找御伽俱乐部的活动场所吗？」[p]
[yuzuha_疑問_c]

#
那对我来说实在是个太难应付的局面。[p]

就算辉夜前辈没问题，但要和不擅应付的爱丽丝前辈一起行动简直令人发毛。[p]

[vo vo="ep3/alice_0076.ogg"]
[alice_ドヤ顔]
#【饴宫 爱丽丝】
「难道说，负责寻找的是小仓柚叶，你们几个哦」[p]
[alice_ドヤ顔_c]

[vo vo="ep3/yuzu_0263.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「诶？那为什么……」[p]
[yuzuha_疑問_c]

[vo vo="ep3/alice_0077.ogg"]
[alice_ドヤ顔]
#【饴宫 爱丽丝】
「当然是为了在后面欣赏你们困扰的样子呀」[p]
[alice_ドヤ顔_c]

#
或许这个人比我想象中还要恶劣得多。[p]

[vo vo="ep3/alice_0078.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「另外还会各种插嘴干涉呢」[p]
[alice_笑み_c]

[vo vo="ep3/yuzu_0264.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「为什么要做这种事……」[p]
[yuzuha_微笑_c]

[vo vo="ep3/alice_0079.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「可不许你说不愿意哦？」[p]

[vo vo="ep3/alice_0080.ogg"]
#【饴宫 爱丽丝】
「你以为是谁告诉你们御伽俱乐部活动地点的线索的？」[p]
[alice_真顔_c]

[vo vo="ep3/yuzu_0265.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「呜……那个，确实是爱丽丝前辈……」[p]
[yuzuha_哀_c]

[vo vo="ep3/alice_0081.ogg"]
[alice_ドヤ顔]
#【饴宫 爱丽丝】
「那就跟着去也没什么问题吧」[p]

[vo vo="ep3/alice_0082.ogg"]
#【饴宫 爱丽丝】
「而且要是我帮忙的话，比试就失去意义了呢」[p]
[alice_ドヤ顔_c]

#
没错。[p]

这是决定能否参加茶会的比试。[p]

[vo vo="ep3/yuzu_0266.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「那个嘛……虽然可能是这样……」[r]　
　但请不要太妨碍我们好吗？」[p]
[yuzuha_微笑_c]

[vo vo="ep3/alice_0083.ogg"]
[alice_ドヤ顔]
#【饴宫 爱丽丝】
「呵呵呵，这个嘛，谁知道呢」[p]
[alice_ドヤ顔_c]

[vo vo="ep3/kaguya_0024.ogg"]
[kaguya_無表情]
#【蓬 辉夜】
「……别管爱丽丝了，我们赶紧推进话题吧」[p]
[kaguya_無表情_c]

#
辉夜前辈说着，仿佛要忽视正露出无畏微笑的爱丽丝前辈。[p]

[vo vo="ep3/kaguya_0025.ogg"]
[kaguya_無表情]
#【蓬 辉夜】
「记得是说要阅读‘学园的死角’来寻找对吧」[p]
[kaguya_無表情_c]

[vo vo="ep3/yuzu_0267.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「对，没错没错」[p]
[yuzuha_微笑_c]

[vo vo="ep3/kaguya_0026.ogg"]
[kaguya_思考]
#【蓬 辉夜】
「死角……吗」[p]
[kaguya_思考_c]

[vo vo="ep3/yuzu_0268.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「咦，辉夜前辈要和我们一起想办法吗？」[p]
[yuzuha_驚き_c]

[vo vo="ep3/kaguya_0027.ogg"]
[kaguya_無表情]
#【蓬 辉夜】
「只是想快点结束罢了」[p]
[kaguya_無表情_c]

[vo vo="ep3/yuzu_0269.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「但是，真的可以吗？」[p]
[yuzuha_微笑_c]

[vo vo="ep3/kaguya_0028.ogg"]
[kaguya_無表情]
#【蓬 辉夜】
「行不行都随我……爱丽丝也没意见吧？」[p]
[kaguya_無表情_c]

[vo vo="ep3/alice_0084.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「无所谓，你想做就做吧」[p]
[alice_笑み_c]

[vo vo="ep3/kaguya_0029.ogg"]
[kaguya_無表情]
#【蓬 辉夜】
「就是这么回事」[p]
[kaguya_無表情_c]

[vo vo="ep3/sayu_0139.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「这两个人的关系……到底怎么样呢」[p]
[sayuri_微笑_c]

#
小百合小姐凑到我耳边压低声音说道。[p]

确实让人有些在意。[p]

看起来不像是普通朋友关系。[p]

[vo vo="ep3/kaguya_0030.ogg"]
[kaguya_無表情]
#【蓬 辉夜】
「只是孽缘罢了……比起这个你们也认真想想啦」[p]
[kaguya_無表情_c]

[vo vo="ep3/yuzu_0270.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「啊、是、是的！」[p]
[yuzuha_驚き_c]

#
还是那样耳朵尖得很。[p]

在辉夜前辈的提示下试着思考「校园死角」这个关键词。[p]

但完全想不到御伽俱乐部的活动地点会是哪里。[p]

[vo vo="ep3/kaguya_0031.ogg"]
[kaguya_無表情]
#【蓬 辉夜】
「校园死角……说不定是在校园范围外？」[p]
[kaguya_無表情_c]

[vo vo="ep3/yuzu_0271.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「外面…吗？」[p]
[yuzuha_微笑_c]

[vo vo="ep3/kaguya_0032.ogg"]
[kaguya_無表情]
#【蓬 辉夜】
「校园内部也有被围墙挡住视线的建筑吧」[p]
[kaguya_無表情_c]

[vo vo="ep3/yuzu_0272.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「原来如此」[p]
[yuzuha_微笑_c]

[vo vo="ep3/sayu_0140.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「但这样范围不会太大了吗？」[p]
[sayuri_微笑_c]

[vo vo="ep3/kaguya_0033.ogg"]
[kaguya_思考]
#【蓬 辉夜】
「说得对……就算是校园内的死角也存在同样问题」[p]
[kaguya_思考_c]

[vo vo="ep3/yuzu_0273.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「就是说啊……」[p]
[yuzuha_微笑_c]

[vo vo="ep3/kaguya_0034.ogg"]
[kaguya_思考]
#【蓬 辉夜】
「那校园内的地下室呢？」[p]

[vo vo="ep3/kaguya_0035.ogg"]
#【蓬 辉夜】
「那样从校外绝对看不见，完全符合校园死角的定义」[p]
[kaguya_思考_c]

[vo vo="ep3/yuzu_0274.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「哇，地下室！太棒了！」[p]
[yuzuha_笑顔_c]

[vo vo="ep3/kaguya_0036.ogg"]
[kaguya_無表情]
#【蓬 辉夜】
「为什么要为那种地方兴奋啊？」[p]
[kaguya_無表情_c]

[vo vo="ep3/yuzu_0275.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「哎呀——总觉得越来越像秘密俱乐部了不是很好嘛」[p]
[yuzuha_笑顔_c]

[vo vo="ep3/sayu_0141.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「但学校里真的有地下室吗？」[p]
[sayuri_微笑_c]

[vo vo="ep3/kaguya_0037.ogg"]
[kaguya_無表情]
#【蓬 辉夜】
「有件事可以肯定，在这里干等着也无济于事」[p]
[kaguya_無表情_c]

[vo vo="ep3/yuzu_0276.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「说得对！那这次就在校内找找看吧！」[p]
[yuzuha_微笑_c]

[bgm_end2]

;■ep3_scene04


;全キャラ削除
[allc]

;//空
[bg10 bg="autumn.jpg"]

#
我们打起精神在校内搜寻了一阵子的地下室。[p]


[vo vo="ep3/yuzu_0277.ogg"]
#【小仓 柚叶】
「唔——完全找不到呢……」[p]

#
最终没能发现地下室。[p]


[vo vo="ep3/sayu_0142.ogg"]
#【稻饼 小百合】
「或许'学校死角'这个思路本身就是错的」[p]

[vo vo="ep3/yuzu_0278.ogg"]
#【小仓 柚叶】
「果然是这样吗」[p]


[vo vo="ep3/kaguya_0038.ogg"]
#【蓬 辉夜】
「像这样漫无目的地找下去似乎也没意义了」[p]

[vo vo="ep3/kaguya_0039.ogg"]
#【蓬 辉夜】
「先回露台重新商量吧」[p]

#
于是众人决定暂时撤回露台。[p]


;//中庭テラス
[bg10 bg="terrace.jpg"]

[yuzuha_微笑_c]
[c4_f cg="yuzuha"]

[sayuri_微笑_c]
[c3_f cg="sayuri"]

[alice_笑み_c]
[c2_f cg="alice"]

[kaguya_無表情_c]
[c1 cg="kaguya"]

[vo vo="ep3/alice_0085.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「到处搜查却什么都没发现呢」[p]
[alice_笑み_c]

#
面对垂头丧气的我们，爱丽丝学姐愉快地说道。[p]

[vo vo="ep3/yuzu_0279.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「爱丽丝学姐明明一直在后面抱怨而已」[p]
[yuzuha_哀_c]

[vo vo="ep3/alice_0086.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「那可是我的工作呀……不过也差不多厌倦了」[p]
[alice_真顔_c]

;BGM再生
[bgm ogg="globular_cluster.ogg"]

[vo vo="ep3/alice_0087.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「这场较量……就算我赢了如何，小仓柚叶」[p]
[alice_真顔_c]

[vo vo="ep3/yuzu_0280.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「才不要！胜负还没定呢！」[p]
[yuzuha_驚き_c]

#
我否定了爱丽丝学姐的宣言。[p]

[vo vo="ep3/alice_0088.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「那御伽俱乐部的活动场所搞清楚了吗？」[p]
[alice_真顔_c]

[vo vo="ep3/yuzu_0281.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「那个、目前还不太清楚……」[p]
[yuzuha_哀_c]

[vo vo="ep3/alice_0089.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「那到底什么时候才能知道？」[p]
[alice_真顔_c]

[vo vo="ep3/yuzu_0282.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「呜……这个……」[p]
[yuzuha_哀_c]

[vo vo="ep3/sayu_0143.ogg"]
[sayuri_哀]
#【稻饼 小百合】
「那个、爱丽丝前辈，能不能再给点时间？」[p]
[sayuri_哀_c]

[vo vo="ep3/alice_0090.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「所以还要多久？要等到你们找到为止吗？」[p]

[vo vo="ep3/alice_0091.ogg"]
#【饴宫 爱丽丝】
「这作为赌约来说不太合适吧」[p]
[alice_真顔_c]

[vo vo="ep3/sayu_0144.ogg"]
[sayuri_哀]
#【稻饼 小百合】
「这个……呃……」[p]
[sayuri_哀_c]

#
小百合小姐被爱丽丝前辈的话噎得哑口无言。[p]

[vo vo="ep3/yuzu_0283.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「哈……真拿你们没办法啊……」[p]
[yuzuha_哀_c]

#
我轻轻叹了口气低语道。[p]

[vo vo="ep3/sayu_0145.ogg"]
[sayuri_必死]
#【稻饼 小百合】
「小柚叶、不能放弃！[r]　
　小柚叶绝对不可以参加茶会的！」[p]
[sayuri_必死_c]

#
小百合小姐拼命向我们喊道。[p]

她的模样让我有些惊讶。[p]

没想到小百合小姐竟然如此[r]　
极力阻止我们加入派系。[p]

[vo vo="ep3/yuzu_0284.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「小百合小姐，没关系的」[p]
[yuzuha_微笑_c]

[vo vo="ep3/sayu_0146.ogg"]
[sayuri_必死]
#【稻饼 小百合】
「才、才不是没关系……[r]　
　要是小柚叶参加了的话……那个……呃……」[p]
[sayuri_必死_c]

#
她似乎想说什么，[r]　
但小百合小姐含糊其辞地停下了话头。[p]

[vo vo="ep3/sayu_0147.ogg"]
[sayuri_必死]
#【稻饼 小百合】
「总、总之就是不行！」[p]
[sayuri_必死_c]

#
虽然拼命阻止的小百合小姐很认真，但有件事她搞错了。[p]

[vo vo="ep3/yuzu_0285.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「所以说没问题的！[r]　
　我参加茶会……根本没打算加入爱丽丝前辈的派系」[p]
[yuzuha_笑顔_c]

[vo vo="ep3/sayu_0148.ogg"]
[sayuri_驚き]
#【稻饼 小百合】
「咦？但是……你刚才不是说没办法吗」[p]
[sayuri_驚き_c]

[vo vo="ep3/yuzu_0286.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「我没放弃啦，只是觉得只剩下最后的手段了」[p]
[yuzuha_微笑_c]

[vo vo="ep3/sayu_0149.ogg"]
[sayuri_驚き]
#【稻饼 小百合】
「最后的、手段……难道是……」[p]
[sayuri_驚き_c]

[vo vo="ep3/alice_0092.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「诶？你有什么计划吗？」[p]
[alice_笑み_c]

[vo vo="ep3/yuzu_0287.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「嘛，差不多就是这样」[p]
[yuzuha_微笑_c]

[vo vo="ep3/kaguya_0040.ogg"]
[kaguya_笑み]
#【蓬 辉夜】
「……啊，原来如此……是这招啊」[p]
[kaguya_笑み_c]

#
或许是察言观色读出了什么，辉夜前辈低声说道。[p]

我对那张脸微微点头。[p]

[vo vo="ep3/yuzu_0288.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「那么我先失礼了」[p]
[yuzuha_微笑_c]

[bgm_end2]

;全キャラ削除
[allc]

[bg10 bg="connecting_corridor.jpg"]

[yuzuha_微笑_c]
[ce cg="yuzuha"]

#
稍稍离开现场，从口袋里掏出某样东西。[p]

掏出来的，是智能手机。[p]

[vo vo="ep3/yuzu_0289.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「问题在于，对方肯不肯接呢」[p]
[yuzuha_微笑_c]

#
胜算相当渺茫。[p]

从通讯录选中某个人后，[r]　
我怀着祈祷般的心情按下通话键。[p]

呼叫铃响起。[p]

铃声持续了一次、两次、三次。[p]

[vo vo="ep3/yuzu_0290.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「啊～果然不行吗……」[p]
[yuzuha_哀_c]

#
求求你，我在心中默念。[p]

但电话依然没有接通。[p]

就在快要放弃希望的那瞬间。[p]

呼叫音突然中断。[p]

然后――[p]

[yuzuha_驚き_c]

[vo vo="ep3/koku_0047.ogg"]
#【黒十 美鹤】
「…………啊、出来了」[p]

;BGM再生
[bgm ogg="you_are_precious.ogg"]

[vo vo="ep3/yuzu_0291.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「先出来的是您那边啊，黑十先生」[p]
[yuzuha_微笑_c]

#
黑十先生回应了我的通话。[p]

[vo vo="ep3/yuzu_0292.ogg"]
[yuzuha_怒]
#【小仓 柚叶】
「真是的——黑十先生接得太慢啦！」[p]
[yuzuha_怒_c]

[vo vo="ep3/koku_0048.ogg"]
#【黒十 美鹤】
「这也没办法吧[r]　
　我还没完全搞明白该怎么按接听键啊」[p]

#
我无法理解只需触碰屏幕的动作究竟难在哪里。[p]

总之黑十先生总算接了电话。[p]

此刻我只能感谢这份幸运。[p]

[vo vo="ep3/koku_0049.ogg"]
#【黒十 美鹤】
「所以说，柚叶君你究竟[r]　
　有什么事情要打电话过来？」[p]

#
听到黑十先生的话，我决定立刻切入正题。[p]

[vo vo="ep3/yuzu_0293.ogg"]
[yuzuha_怒鳴る]
#【小仓 柚叶】
「黑十先生，我有不明白的事情！[r]　
　请告诉我这个谜题的答案吧！」[p]
[yuzuha_怒鳴る_c]

[bgm_end2]

;//時間経過
;//暗転（もしくは空とか地面とか）

;全キャラ削除
[allc]

;//黒ベタ
[bg10 bg="black.png"]

#
就这样，我向黑十先生说明了本次御伽俱乐部的谜题。[p]

这是我最后的手段了。[p]

如果这都不行就只能放弃。[p]

;//渡り廊下
[bg10 bg="connecting_corridor.jpg"]

[yuzuha_微笑_c]
[ce cg="yuzuha"]

;BGM再生
[bgm ogg="tukikage.ogg"]

[vo vo="ep3/koku_0050.ogg"]
;//読み方『学園の□』→学園のしかく
#【黒十 美鹤】
「原来如此……御伽俱乐部，学园的□啊……」[p]

[vo vo="ep3/yuzu_0294.ogg"]
[yuzuha_怒鳴る]
#【小仓 柚叶】
「怎么样黑十先生，听完有什么头绪吗！？」[p]
[yuzuha_怒鳴る_c]

[vo vo="ep3/koku_0051.ogg"]
#【黒十 美鹤】
「你这么问我也很为难啊……」[p]

#
眼前浮现出黑十先生那副一如既往嫌麻烦的表情。[p]

[vo vo="ep3/koku_0052.ogg"]
#【黒十 美鹤】
「光听描述可没法判断呢」[p]

[vo vo="ep3/yuzu_0295.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「诶~，这完全不行嘛~！」[p]
[yuzuha_哀_c]

[vo vo="ep3/koku_0053.ogg"]
#【黒十 美鹤】
「说什么完全不行，[r]　
　你该不会以为我是哪个名侦探吧？」[p]

[vo vo="ep3/koku_0054.ogg"]
;//読み方『学園の□』→学園のしかく
#【黒十 美鹤】
「光听你说说，就能解开那所学园的□暗号，[r]　
　找到御伽俱乐部的活动地点什么的根本不可能啦」[p]

[vo vo="ep3/yuzu_0296.ogg"]
[yuzuha_怒鳴る]
#【小仓 柚叶】
「所以才要请你想想办法呀！」[p]
[yuzuha_怒鳴る_c]

[vo vo="ep3/koku_0055.ogg"]
#【黒十 美鹤】
「不不这太难了……我连学园都没实际看过」[p]

#
这句话让我忽然想起小庵的身影。[p]

对了，小庵之前来过的。[p]

[vo vo="ep3/yuzu_0297.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「那请您过来看看吧！」[p]
[yuzuha_微笑_c]

[vo vo="ep3/koku_0056.ogg"]
#【黒十 美鹤】
「哈？开什么玩笑」[p]

[vo vo="ep3/koku_0057.ogg"]
#【黒十 美鹤】
「而且柚叶君的学园不是男宾止步的女校吗？」[p]

[vo vo="ep3/koku_0058.ogg"]
#【黒十 美鹤】
「就算不是这样，外人进入学园领地这种事，[r]　
　最近管得特别严的」[p]

#
唯独在为不出门找借口这件事上格外精明，实在让我火大。[p]

[vo vo="ep3/yuzu_0298.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「有什么关系嘛！我会想办法不让人发现的！」[p]

[vo vo="ep3/yuzu_0299.ogg"]
[yuzuha_怒鳴る]
#【小仓 柚叶】
「再这样下去的话，[r]　
　我就只能加入爱丽丝前辈的派系了啦~！」[p]
[yuzuha_怒鳴る_c]

[vo vo="ep3/koku_0059.ogg"]
#【黒十 美鹤】
「不...但连学园具体位置都不清楚」[p]

[vo vo="ep3/yuzu_0300.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「那就看手机呀！可以看地图的！」[p]
[yuzuha_微笑_c]

[vo vo="ep3/koku_0060.ogg"]
#【黒十 美鹤】
「咦？还有这种功能吗？」[p]

[vo vo="ep3/yuzu_0301.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「有啦有啦！[r]　
　地图APP本来就有预装的啦！」[p]
[yuzuha_笑顔_c]

[vo vo="ep3/koku_0061.ogg"]
#【黒十 美鹤】
「……地图……咦，是这里吗？」[p]

[vo vo="ep3/yuzu_0302.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「……嗯？黑十先生？喂喂听得到吗？」[p]
[yuzuha_疑問_c]

[vo vo="ep3/koku_0062.ogg"]
#【黒十 美鹤】
「啊、嗯、听得到哦……真的能看到地图呢」[p]

[vo vo="ep3/yuzu_0303.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「诶！？已经确认好了吗！？」[p]
[yuzuha_驚き_c]

[vo vo="ep3/koku_0063.ogg"]
#【黒十 美鹤】
「嗯总算……这样的话……啊，找到了」[p]

[vo vo="ep3/koku_0064.ogg"]
#【黒十 美鹤】
「现在通过地图确认到柚叶君就读的学园了哦」[p]

[vo vo="ep3/yuzu_0304.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「噢太好了！我在校门口等着请马上过来！」[p]
[yuzuha_笑顔_c]

[vo vo="ep3/koku_0065.ogg"]
#【黒十 美鹤】
「哈……真拿你没办法呢……嗯……这是……」[p]

[vo vo="ep3/koku_0066.ogg"]
#【黒十 美鹤】
「……嗯——……啊，原来如此是这样……」[p]

[vo vo="ep3/yuzu_0305.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「啊咧？喂喂黑十先生，怎么了？」[p]

[vo vo="ep3/yuzu_0306.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「你会过来的对吧？」[p]
[yuzuha_疑問_c]

[bgm_end2]

[vo vo="ep3/koku_0067.ogg"]
#【黒十 美鹤】
「不，看来没那个必要了」[p]

[vo vo="ep3/yuzu_0307.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「诶？这是什么意思？」[p]
[yuzuha_驚き_c]

[vo vo="ep3/koku_0068.ogg"]
#【黒十 美鹤】
「就是不用去学园的意思」[p]

[vo vo="ep3/yuzu_0308.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「不用去……咦，难道黑十先生……！」[p]
[yuzuha_驚き_c]

[vo vo="ep3/koku_0069.ogg"]
#【黒十 美鹤】
「嗯，找到御伽俱乐部的活动地点了哦」[p]

#
如此说着的黑十先生简直像个名侦探。[p]

[bgm_end2]

;//時間経過
;テキストウィンドウ削除
[end_text]

;全キャラ削除
[allc]

;//黒ベタ
[bg10 bg="black.png"]

;//停止
[wait time=2000]

;//渡り廊下
[bg10 bg="connecting_corridor.jpg"]

[yuzuha_微笑_c]
[ce cg="yuzuha"]

;テキストウィンドウ表示
[start_text_yuzu]

;BGM再生
[bgm ogg="urara.ogg"]

[vo vo="ep3/koku_0070.ogg"]
;//読み方『学園の□』→学園のしかく
#【黒十 美鹤】
「……咳，以上就是学园□这个暗号的含义」[p]

[vo vo="ep3/koku_0071.ogg"]
#【黒十 美鹤】
「而刚才说的那个地点[r]　
　无疑是御伽俱乐部的活动场所」[p]

#
听完黑十先生对这次谜题的讲解[r]　
　我不禁目瞪口呆。[p]

[vo vo="ep3/yuzu_0309.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「诶、诶！？但这个真的……这么简单！？」[p]
[yuzuha_驚き_c]

[vo vo="ep3/koku_0072.ogg"]
#【黒十 美鹤】
「不不，我觉得是个设计精妙的暗号哦」[p]

[vo vo="ep3/koku_0073.ogg"]
#【黒十 美鹤】
「实际上柚叶君你们没能明白也是情有可原呢」[p]

[vo vo="ep3/yuzu_0310.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「确实……但为什么黑十先生能如此轻易就看穿了呢？」[p]
[yuzuha_疑問_c]

[vo vo="ep3/koku_0074.ogg"]
#【黒十 美鹤】
「嗯……大概是因为我没在学园里的缘故吧」[p]

[vo vo="ep3/koku_0075.ogg"]
#【黒十 美鹤】
「所以才能比柚叶君更客观地看待问题吧」[p]

[vo vo="ep3/koku_0076.ogg"]
#【黒十 美鹤】
「不，这里我倾向于用'俯瞰性'这个词」[p]

[vo vo="ep3/yuzu_0311.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「俯瞰性……啊，那确实……原来如此」[p]
[yuzuha_驚き_c]

#
听到黑十先生的话，身体仿佛一下子轻盈起来。[p]

这样一来，又有一件不明白的事变得明朗了。[p]

[vo vo="ep3/yuzu_0312.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「非常感谢您，黑十先生！」[p]

[vo vo="ep3/yuzu_0313.ogg"]
#【小仓 柚叶】
「多亏您教会我不懂的事情……真的很开心！」[p]
[yuzuha_笑顔_c]

[vo vo="ep3/koku_0077.ogg"]
#【黒十 美鹤】
「呵呵，那是再好不过了」[p]

[vo vo="ep3/yuzu_0314.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「下次再郑重道谢！那就先这样！」[p]
[yuzuha_笑顔_c]

[vo vo="ep3/koku_0078.ogg"]
#【黒十 美鹤】
「好的，我会不抱期待地等着哟」[p]

[bgm_end2]

#
听完黑十先生的解答后挂断了通话。[p]

至此御伽俱乐部的谜题终于解开了。[p]

;BGM再生
[bgm ogg="kaiko.ogg"]


[vo vo="ep3/yuzu_0315.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「那个……这样谜题就算解开了对吧？」[p]
[yuzuha_疑問_c]

#
是否还有什么遗忘或在意的细节呢。[p]

;選択肢//画像の縦サイズは文字サイズ×3で作成し数値は指定しない。
;選択肢//画像の横幅は文字サイズ×4をマイナスした数値で指定する。

[eval exp="f.problem_kokutou=0"]

;//選択肢
;//１：問題なし！
;//２：ある！
[glink width="628" graphic="txtlink.png" enterimg="txtlink_on.png" enterse="cursor1.ogg" clickse="decision5.ogg" size="28" x="266" y="180" target="*no_problem" text="問題なし！"]

[glink width="628" graphic="txtlink.png" enterimg="txtlink_on.png" enterse="cursor1.ogg" clickse="decision5.ogg" size="28" x="266" y="280" target="*problem" text="ある！"]

[s]

;-------------------------------------------------
;//選択肢１：問題なし！
*no_problem
[savetitle text="問題なし！"]
;-------------------------------------------------

[vo vo="ep3/yuzu_0316.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「嗯……没问题！一切顺利！」[p]
[yuzuha_微笑_c]

#
虽然试着确认是否有在意的事，但似乎没有异常。[p]

御伽俱乐部的谜题已从黑十先生那里得到完美解答。[p]


;//ここまで
;//合流へジャンプ
[jump target="*description"]


;-------------------------------------------------
;//選択肢２：ある！
*problem
[savetitle text="問題ある！"]
;-------------------------------------------------

[vo vo="ep3/yuzu_0317.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「唔……总感觉还有什么耿耿于怀的事……是什么呢？」[p]
[yuzuha_疑問_c]

#
御伽俱乐部的谜团通过刚才与黑十先生的电话已经解决了。[p]

但是除此之外似乎还有另一件奇怪的事情。[p]

;//選択肢
;//１：庵ちゃんのこと
;//２：アリス先輩のこと
;//３：輝夜先輩のこと
;//４：黒十さんのこと



;//選択肢４を選ぶと電話中の黒十の裏話が見れるようになる。[p]
[glink width="628" graphic="txtlink.png" enterimg="txtlink_on.png" enterse="cursor1.ogg" clickse="decision5.ogg" size="28" x="266" y="90" target="*problem_iori" text="庵ちゃんのこと"]

[glink width="628" graphic="txtlink.png" enterimg="txtlink_on.png" enterse="cursor1.ogg" clickse="decision5.ogg" size="28" x="266" y="180" target="*problem_alice" text="アリス先輩のこと"]

[glink width="628" graphic="txtlink.png" enterimg="txtlink_on.png" enterse="cursor1.ogg" clickse="decision5.ogg" size="28" x="266" y="270" target="*problem_kaguya" text="輝夜先輩のこと"]

[glink width="628" graphic="txtlink.png" enterimg="txtlink_on.png" enterse="cursor1.ogg" clickse="decision5.ogg" size="28" x="266" y="360" target="*problem_kokutou" exp="f.problem_kokutou=1" text="黒十さんのこと"]

[s]

;-------------------------------------------------
;//選択肢１：庵ちゃんのこと
*problem_iori
[savetitle text="庵ちゃんのこと"]
;-------------------------------------------------

[cutbg_in bgin="cut_select_iori.png"]

[vo vo="ep3/yuzu_0318.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「对了，小庵」[p]
[yuzuha_微笑_c]

#
至今仍不明白她为何要来学院。[p]

[vo vo="ep3/yuzu_0319.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「嗯……不过或许是小庵的事？」[p]
[yuzuha_疑問_c]

#
隐约感觉在意的好像是另一件事。[p]

[vo vo="ep3/yuzu_0320.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「嘛，现在暂且不用深入思考也行吧」[p]
[yuzuha_微笑_c]

[cutbg_out]

;//ここまで
[jump target="*description"]


;-------------------------------------------------
;//選択肢２：アリス先輩のこと
*problem_alice
[savetitle text="アリス先輩のこと"]
;-------------------------------------------------

[cutbg_in bgin="cut_select_alice.png"]

#
爱丽丝前辈恶作剧般的微笑在脑海中闪过。[p]

[vo vo="ep3/yuzu_0321.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「不……应该不是爱丽丝前辈的事」[p]
[yuzuha_疑問_c]

#
明明解开谜团后很畅快，心情却又变得沉重起来。[p]

还是别想太多为好。[p]

[cutbg_out]

;//ここまで
[jump target="*description"]

;-------------------------------------------------
;//選択肢３：輝夜先輩のこと
*problem_kaguya
[savetitle text="輝夜先輩のこと"]
;-------------------------------------------------

[cutbg_in bgin="cut_select_kaguya.png"]

[vo vo="ep3/yuzu_0322.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「辉夜前辈……吗？」[p]
[yuzuha_疑問_c]

#
虽然在意与爱丽丝前辈的关系倒是事实。[p]

[vo vo="ep3/yuzu_0323.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「感觉现在纠结的事情似乎不是这个……应该没问题吧」[p]
[yuzuha_微笑_c]

[cutbg_out]

;//ここまで
[jump target="*description"]

;-------------------------------------------------
;//選択肢４：黒十さんのこと
*problem_kokutou
[savetitle text="黒十さんのこと"]
;-------------------------------------------------

[cutbg_in bgin="cut_select_kokutou.png"]

[bgm_end1]

[vo vo="ep3/yuzu_0324.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「黑十先生……」[p]
[yuzuha_疑問_c]

#
思索着是否有什么令人在意的事时，[r]　
那张脸划过脑海。[p]

然后――[p]

;BGM再生
[bgm ogg="tukikage.ogg"]

[vo vo="ep3/yuzu_0325.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「……为什么黑十先生能接电话呢」[p]
[yuzuha_疑問_c]

#
这个念头让人突然一惊。[p]

黑十先生连接电话都很危险。[p]

这样的黑十先生不可能在通话状态下还能打开应用。[p]

更遑论通过地图确认学校位置……[p]

[vo vo="ep3/yuzu_0326.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「偶然……会有这种事吗？」[p]
[yuzuha_疑問_c]

#
这实在令人在意。[p]

[cutbg_out]

[vo vo="ep3/yuzu_0327.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「虽然很在意，但现在不是管那个的时候吧」[p]
[yuzuha_微笑_c]

#
总之要先解决眼前的问题。[p]

这个等会儿直接问问黑十先生好了。[p]

[bgm_end2]

;//ここまで
[jump target="*description"]

;-------------------------------------------------
;//合流
*description
[savetitle text="皆に説明しなくっちゃ！"]
;-------------------------------------------------

[vo vo="ep3/yuzu_0328.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「好啦，得赶紧向大家解释才行！」[p]
[yuzuha_微笑_c]

#
御伽俱乐部的活动场所。[p]

以及『学园的□』这个暗号的含义。[p]

;//時間経過
;テキストウィンドウ削除
[end_text]

;全キャラ削除
[allc]

;//黒ベタ
[bg10 bg="black.png"]

;//停止
[wait time=2000]

;//中庭テラス
[bg10 bg="terrace.jpg"]

[yuzuha_微笑_c]
[c3_f cg="yuzuha"]

[sayuri_微笑_c]
[c4_f cg="sayuri"]

[alice_笑み_c]
[c2_f cg="alice"]

[kaguya_無表情_c]
[c1 cg="kaguya"]

;テキストウィンドウ表示
[start_text_yuzu]

;BGM再生
[bgm ogg="kaiko.ogg"]


[vo vo="ep3/sayu_0150.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「啊，小柚叶！」[p]
[sayuri_微笑_c]

#
回到大家身边时，小百合小姐满脸担忧地跑了过来。[p]

我对那样的小百合小姐回以微笑。[p]

[vo vo="ep3/alice_0093.ogg"]
[alice_ドヤ顔]
#【饴宫 爱丽丝】
「真是够慢的呢，还以为你就这样逃跑了」[p]
[alice_ドヤ顔_c]

[vo vo="ep3/yuzu_0329.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「怎么会，绝无此事」[p]
[yuzuha_微笑_c]

[vo vo="ep3/alice_0094.ogg"]
[alice_ドヤ顔]
#【饴宫 爱丽丝】
「那么，最后的那个手段怎么样了？」[p]
[alice_ドヤ顔_c]

[vo vo="ep3/yuzu_0330.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「哼哼，问得好！」[p]

[vo vo="ep3/yuzu_0331.ogg"]
#【小仓 柚叶】
「我知道御伽俱乐部的活动场所在哪儿了哟！」[p]
[yuzuha_笑顔_c]

[sayuri_驚き]
[alice_驚き]
[kaguya_無表情]

#
听到我这句话，在场所有人都露出了惊讶的表情。[p]

不过，可能只有辉夜前辈还保持着平常的面无表情。[p]

[vo vo="ep3/yuzu_0332.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「请跟我来，这就带你们去御伽俱乐部！」[p]
[yuzuha_笑顔_c]



;シーン7へ移動
[jump  storage="ep3_scene07.ks"]
[s]