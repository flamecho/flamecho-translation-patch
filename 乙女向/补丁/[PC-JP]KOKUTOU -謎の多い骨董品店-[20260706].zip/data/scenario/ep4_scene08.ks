﻿;--------------------------------------------------
;■黒十　本文テキスト　ep4　鐘塔の幽霊
;--------------------------------------------------
;
;■ep4_scene08
;
;--------------------------------------------------
*080000
[savetitle text="幽霊の正体って"]
;-------------------------------------------------

;//礼拝堂（背景切り替えたい）
[bg20 bg="chapel_room_01.jpg"]

[yuzuha_微笑_c]
[c4_f cg="yuzuha"]

[tukasa_笑顔_c]
[c3_f cg="tukasa"]

[kaguya_無表情_c]
[c2_f cg="kaguya"]

[alice_笑み_c]
[c1 cg="alice"]

;テキストウィンドウ表示
[start_text]

礼拜堂内一度全员聚集。[p]

[vo vo="ep4/hagino_0076.ogg"]
[tukasa_笑顔]
#【萩乃司】
「然后然后，幽灵的真实身份到底是谁啊？」[p]
[tukasa_笑顔_c]

[vo vo="ep4/kaguya_0061.ogg"]
[kaguya_呆れ]
#【蓬 辉夜】
「哈……真是愚蠢」[p]
[kaguya_呆れ_c]

[vo vo="ep4/alice_0121.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「嘛 无所谓啦 稍微打发下时间也不错嘛」[p]
[alice_笑み_c]

[vo vo="ep4/yuzuha_0230.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「……黑十先生、幽灵的真面目、请告诉我」[p]
[yuzuha_微笑_c]

#
凝视着各自喃喃自语的少女们。[p]

然后将视线停留在其中一位少女身上。[p]

;BGM再生
[bgm ogg="tukikage.ogg"]

[vo vo="ep4/koku_0221.ogg"]
#【黒十 美鹤】
「钟塔幽灵的真面目、那就是……莲小姐、就是你吧」[p]

[yuzuha_驚き_c]

[tukasa_驚き_c]

[alice_真顔_c]

#
听到我的话，在场所有人都看向她。[p]

黑发少女一言不发地凝视着虚空。[p]

[vo vo="ep4/alice_0122.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「那么，假设幽灵的真身是辉夜，[r]　
　又是怎么登上钟塔的呢？」[p]
[alice_笑み_c]

#
最先开口的是那位金发千金。[p]

[vo vo="ep4/alice_0123.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「通往钟塔的梯子不是坏了吗？」[p]
[alice_笑み_c]

[vo vo="ep4/koku_0222.ogg"]
#【黒十 美鹤】
「确实如此……那里根本不可能爬上去」[p]

[vo vo="ep4/koku_0223.ogg"]
#【黒十 美鹤】
「所以我最开始[r]　
　以为是萩乃小姐和莲小姐两人协力登上去的」[p]

[vo vo="ep4/yuzuha_0231.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「咦？不是吗？我还以为肯定是这样呢……」[p]
[yuzuha_疑問_c]

[vo vo="ep4/koku_0224.ogg"]
#【黒十 美鹤】
「不是的……那两个人都办不到的」[p]

[vo vo="ep4/koku_0225.ogg"]
#【黒十 美鹤】
「请回忆一下，那个梯子、[r]　
　我当柚叶君的垫脚石才刚刚能够到的高度」[p]

[vo vo="ep4/yuzuha_0232.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「啊、对哦……就算辉夜学姐你们合作也够不着！」[p]
[yuzuha_驚き_c]

[vo vo="ep4/koku_0226.ogg"]
#【黒十 美鹤】
「正是如此」[p]

[vo vo="ep4/yuzuha_0233.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「但是、那样的话到底怎么[r]　
　辉夜学姐登上钟塔的呢？」[p]
[yuzuha_疑問_c]

[vo vo="ep4/koku_0227.ogg"]
#【黒十 美鹤】
「准备了别的垫脚石哦」[p]

[vo vo="ep4/alice_0124.ogg"]
[alice_疑問]
#【饴宫 爱丽丝】
「别的垫脚石？那种东西哪里会有啊」[p]
[alice_疑問_c]

[vo vo="ep4/koku_0228.ogg"]
#【黒十 美鹤】
「……遗憾的是，并不存在那种东西呢」[p]

[alice_怒り_c]
#
碧眼千金对我的话露出了不悦的神情。[p]

要是再卖关子不知会遭什么埋怨[r]　
我决定赶紧继续说下去。[p]

[vo vo="ep4/koku_0229.ogg"]
#【黒十 美鹤】
「现在、这个地方有呢」[p]

[vo vo="ep4/alice_0125.ogg"]
[alice_疑問]
#【饴宫 爱丽丝】
「现在……？」[p]
[alice_疑問_c]

[vo vo="ep4/koku_0230.ogg"]
#【黒十 美鹤】
「没错……[r]　
　那块垫脚石、我们来到这时还存在着」[p]

[vo vo="ep4/alice_0126.ogg"]
[alice_呆れ]
#【饴宫 爱丽丝】
「啊……原来如此、被耍得团团转呢」[p]
[alice_呆れ_c]

#
看来敏锐的她立刻就明白了。[p]

[vo vo="ep4/yuzuha_0234.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「黑十先生、这是怎么回事？」[p]
[yuzuha_疑問_c]

[alice_笑み_c]

[vo vo="ep4/koku_0231.ogg"]
#【黒十 美鹤】
「莲小姐用作垫脚石的东西……[r]　
　是从旧校舍搜集来的废弃物」[p]

[vo vo="ep4/koku_0232.ogg"]
#【黒十 美鹤】
「难怪怎么找都找不到呢」[p]

[vo vo="ep4/koku_0233.ogg"]
#【黒十 美鹤】
「因为我们早就收拾干净了」[p]

[vo vo="ep4/yuzuha_0235.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「原、原来如此……咦？但那种东西能当垫脚石吗？」[p]
[yuzuha_疑問_c]

[vo vo="ep4/koku_0234.ogg"]
#【黒十 美鹤】
「当然仅靠一个是不够的吧」[p]

[vo vo="ep4/koku_0235.ogg"]
#【黒十 美鹤】
「但是，如果把纸堆或纸箱像台阶一样叠起来[r]　
　就能轻松爬上去吧」[p]

#
我的话语让柚叶君信服了。[p]

[vo vo="ep4/kaguya_0062.ogg"]
[kaguya_無表情]
#【蓬 辉夜】
「请稍等一下」[p]
[kaguya_無表情_c]

#
仿佛要打断对话般，黑发少女终于开口了。[p]

[vo vo="ep4/kaguya_0063.ogg"]
[kaguya_無表情]
#【蓬 辉夜】
「按你说的，[r]　
　假设是用这里旧校舍的废弃品堆叠攀登」[p]

[vo vo="ep4/kaguya_0064.ogg"]
#【蓬 辉夜】
「但为什么要特意爬上那种地方？」[p]

[vo vo="ep4/kaguya_0065.ogg"]
#【蓬 辉夜】
「而且目击到幽灵的学生可不止一两个人？」[p]

[vo vo="ep4/kaguya_0066.ogg"]
#【蓬 辉夜】
「也就是说，你认为我反复攀登过多次对吧」[p]

[vo vo="ep4/kaguya_0067.ogg"]
#【蓬 辉夜】
「凭什么我必须屡次登上钟塔不可？」[p]
[kaguya_無表情_c]

#
听着这话，我轻轻颔首数次。[p]

若她真是幽灵的真身，[r]　
确实必须对此作出交代。[p]

;//アリスを鐘塔へ登らせているか判定
[if exp="f.登らせる == 1"]
[jump target="*081000"]
[endif]

;//登っていない場合
[jump target="*082000"]
[s]

;//アリスを鐘塔へ向かわせていた場合のシナリオ
;--------------------------------------------------
*081000
[savetitle text="その答えを、私はもうすでに持っていた"]
;-------------------------------------------------
不过这个答案，我早已成竹在胸。[p]

[vo vo="ep4/koku_0236.ogg"]
#【黒十 美鹤】
「因为……没能找到遗失物」[p]

#
说着展示了柚叶君带来的怀表。[p]

[vo vo="ep4/kaguya_0068.ogg"]
[kaguya_驚き]
#【蓬 辉夜】
「那个是……！」[p]
[kaguya_驚き_c]

[vo vo="ep4/koku_0237.ogg"]
#【黒十 美鹤】
「是柚叶君从钟塔上找到的」[p]

[vo vo="ep4/koku_0238.ogg"]
#【黒十 美鹤】
「似乎是勉强卡在塔身外沿的缝隙里」[p]

[vo vo="ep4/koku_0239.ogg"]
#【黒十 美鹤】
「若是普通搜寻方式，[r]　
　绝对发现不了的位置呢」[p]

[vo vo="ep4/yuzuha_0236.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「啊哈哈，因为差点掉下去才注意到啦！」[p]
[yuzuha_笑顔_c]

[vo vo="ep4/alice_0127.ogg"]
[alice_呆れ]
#【饴宫 爱丽丝】
「笨蛋，这可不是什么好笑的事」[p]
[alice_呆れ_c]

[vo vo="ep4/yuzuha_0237.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「对、对不起……」[p]
[yuzuha_哀_c]

[alice_真顔_c]

[vo vo="ep4/koku_0240.ogg"]
#【黒十 美鹤】
「这似乎是你很重要的东西，还给你」[p]

[kaguya_動揺_c]

#
将手中的怀表轻轻放在她的掌心。[p]

莲小姐凝视着归还的怀表。[p]

[vo vo="ep4/koku_0241.ogg"]
#【黒十 美鹤】
「为了找到这只怀表，我多次登上钟塔」[p]

[vo vo="ep4/koku_0242.ogg"]
#【黒十 美鹤】
「结果导致幽灵目击事件增加了吧」[p]

;//ここまで
;//合流へジャンプ
[jump target="*083000"]


;//アリスを鐘塔へ向かわせていない場合のシナリオ
;--------------------------------------------------
*082000
[savetitle text="その答えは、すでに見当がついていた"]
;-------------------------------------------------

#
但那个答案，其实早已明了。[p]

[vo vo="ep4/koku_0243.ogg"]
#【黒十 美鹤】
「那是因为……没能找到要找的东西」[p]

[kaguya_驚き_c]

#
黑发少女对我的话显露出动摇。[p]

[kaguya_動揺_c]

[vo vo="ep4/koku_0244.ogg"]
#【黒十 美鹤】
「而且恐怕直到现在，[r]　
　你也还没找到那个遗失之物吧？」[p]

[vo vo="ep4/yuzuha_0238.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「遗失之物是指……？」[p]
[yuzuha_疑問_c]

[vo vo="ep4/koku_0245.ogg"]
#【黒十 美鹤】
「值得反复去寻找的东西……对她而言非常重要的物品」[p]

[vo vo="ep4/yuzuha_0239.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「啊，难道是那个怀表！？」[p]
[yuzuha_驚き_c]

[vo vo="ep4/kaguya_0069.ogg"]
[kaguya_動揺]
#【蓬 辉夜】
「…………」[p]
[kaguya_動揺_c]

#
对于柚叶君的提问，她保持着沉默。[p]

从这个反应来看，这个推测应该是正确的。[p]

[vo vo="ep4/koku_0246.ogg"]
#【黒十 美鹤】
「为了寻找怀表，多次登上钟塔」[p]

[vo vo="ep4/koku_0247.ogg"]
#【黒十 美鹤】
「结果导致幽灵目击事件增加了吧」[p]

;//ここまで
;//合流へジャンプ
[jump target="*083000"]



;//合流
*083000

[vo vo="ep4/kaguya_0070.ogg"]
[kaguya_動揺]
#【蓬 辉夜】
「……为什么知道我在找东西？」[p]
[kaguya_動揺_c]

[if exp="f.絆創膏 == 1"]
[jump target="*083100"]
[endif]

;//絆創膏をわたしていない場合は下記の台詞を表示
[vo vo="ep4/koku_0248.ogg"]
#【黒十 美鹤】
「看见你受伤那次」[p]

[jump target="*083200"]


;//絆創膏をわたしていた場合は下記の台詞を表示
*083100

[vo vo="ep4/koku_0249.ogg"]
#【黒十 美鹤】
「递给你创可贴那次」[p]


*083200
;//その時のイベントCG表示（回想用にそれっぽく加工して欲しい）

;イベントＣＧ表示
[event_in event="ep4_2_5"]

[vo vo="ep4/koku_0250.ogg"]
#【黒十 美鹤】
「那时，你的膝盖上沾着尘土」[p]

[vo vo="ep4/koku_0251.ogg"]
#【黒十 美鹤】
「起初我以为你是摔倒了，[r]　
　但受伤的原因其实另有隐情」[p]

[vo vo="ep4/koku_0252.ogg"]
#【黒十 美鹤】
「那些尘土是因为你趴在地上[r]　
　检查是否有东西掉落对吧」[p]

[vo vo="ep4/koku_0253.ogg"]
#【黒十 美鹤】
「而且那片区域正好位于钟塔的正下方」[p]

;イベントＣＧ削除
[event_out]

;//イベントCG表示ここまで

[kaguya_呆れ_c]

#
听完我的解释，她愕然叹了口气。[p]

看来她已经无话可说了。[p]

[vo vo="ep4/yuzuha_0240.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「那、那么说……这次的幽灵真身是……！？」[p]
[yuzuha_驚き_c]

#
取而代之的是，她用锐利的目光瞪着我低语道。[p]

[vo vo="ep4/kaguya_0071.ogg"]
[kaguya_呆れ]
#【蓬 辉夜】
「……明明这么不起眼，却净记些多余的事呢」[p]
[kaguya_呆れ_c]

[alice_ドヤ顔_c]

#
听到这句嘀咕，站在旁边的饴宫爱丽丝噗嗤笑出声。[p]

[vo vo="ep4/yuzuha_0241.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「唔嗯……我真的那么不起眼吗……」[p]
[yuzuha_疑問_c]
#

不知为何，柚叶君偏着头这样嘟囔道。[p]

;//時間経過
;テキストウィンドウ削除
[end_text]

;BGM停止
[bgm_end3]

;全キャラ削除
[allc]

;背景
[bg10 bg="white.png"]

;--------------------------------------------------
*084000
[savetitle text="噂の幽霊じゃないと思う"]
;-------------------------------------------------

;BGM再生
[bgm ogg="urara.ogg"]

;//礼拝堂前
[bg20 bg="chapel_01.jpg"]

;黒十衣装指定
[kokutou_c_コート]

;柚葉衣装指定
[yuzuha_c_コート]

[yuzuha_微笑_c]
[c4_f cg="yuzuha"]

[kokutou_哀_c]
[c3_f cg="kokutou"]

[tukasa_笑顔_c]
[ri cg="tukasa"]

;テキストウィンドウ表示
[start_text]

#
临别时，萩乃小姐特意来为我们送行。[p]

作为礼拜堂主人的萩乃小姐向我们连连道谢。[p]

[vo vo="ep4/hagino_0077.ogg"]
[tukasa_笑顔]
#【萩乃司】
「真的很感谢你们帮忙整理」[p]
[tukasa_笑顔_c]

[vo vo="ep4/yuzuha_0242.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「哪里哪里，别在意，我们也玩得很开心」[p]

[vo vo="ep4/yuzuha_0243.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「但没想到幽灵的真身竟然是辉夜学姐」[p]
[yuzuha_笑顔_c]

[vo vo="ep4/hagino_0078.ogg"]
[tukasa_疑問]
#【萩乃司】
「啊……呃……是啊……」[p]
[tukasa_疑問_c]

#
对于柚叶君的话语，萩乃小姐露出一丝心不在焉的微笑。[p]

[vo vo="ep4/yuzuha_0244.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「怀表也找到了，[r]　
　辉夜前辈也不再登上钟塔了」[p]

[vo vo="ep4/yuzuha_0245.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「这样幽灵骚动也会平息，礼拜堂的人们就能回来了！」[p]
[yuzuha_笑顔_c]

[vo vo="ep4/hagino_0079.ogg"]
[tukasa_苦笑い]
#【萩乃司】
「嗯、嗯……能那样就好了……」[p]
[tukasa_苦笑い_c]

#
她略显迟疑的态度令人在意。[p]

回想起来，她似乎经常[r]　
这样含糊其辞。[p]

[vo vo="ep4/koku_0254.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「发生什么了吗？　有什么在意的事吗？」[p]
[kokutou_真顔_c]


[bgm_end1]

[vo vo="ep4/hagino_0080.ogg"]
[tukasa_苦笑い]
#【萩乃司】
「唔——虽然难以启齿……[r]　
　我觉得辉夜并不是传闻中的幽灵」[p]
[tukasa_苦笑い_c]

[yuzuha_驚き_c]
#
听到这句话，柚叶君和我对视了一眼。[p]

[vo vo="ep4/yuzuha_0246.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「这话是什么意思？[r]　
　可辉夜前辈确实登上过钟塔啊？」[p]
[yuzuha_疑問_c]

[vo vo="ep4/hagino_0081.ogg"]
[tukasa_苦笑い]
#【萩乃司】
「啊——不，这点我也不怀疑」[p]

[vo vo="ep4/hagino_0082.ogg"]
#【萩乃司】
「辉夜好像真的登上过钟塔」[p]
[tukasa_苦笑い_c]

#
那到底为什么说她不是幽灵的真身呢？[p]


;BGM再生
[bgm ogg="horror.ogg"]

[vo vo="ep4/hagino_0083.ogg"]
[tukasa_疑問]
#【萩乃司】
「唔——……不，还是算了吧……」[p]
[tukasa_疑問_c]

[vo vo="ep4/yuzuha_0247.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「诶——！？　这、这种话请不要说到一半啊！」[p]

[vo vo="ep4/yuzuha_0248.ogg"]
[yuzuha_怒鳴る]
#【小仓 柚叶】
「拜托了，究竟在在意什么呢？」[p]
[yuzuha_怒鳴る_c]

[vo vo="ep4/hagino_0084.ogg"]
[tukasa_疑問]
#【萩乃司】
「那我……就说出来吧……其实呢……」[p]

[vo vo="ep4/hagino_0085.ogg"]
[tukasa_真顔]
#【萩乃司】
「大家传闻的幽灵故事，还记得吗？」[p]
[tukasa_真顔_c]

[vo vo="ep4/yuzuha_0249.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「当然了！[r]　
　12点，无人礼拜堂的钟塔会出现幽灵，对吧！」[p]
[yuzuha_笑顔_c]

[vo vo="ep4/hagino_0086.ogg"]
[tukasa_真顔]
#【萩乃司】
「嗯……你看，果然很奇怪吧」[p]
[tukasa_真顔_c]

[vo vo="ep4/yuzuha_0250.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「到底是怎么回事――」[p]

[bgm_end0]

[tukasa_真顔]
[yuzuha_驚き]
[kokutou_驚き]

[vo vo="ep4/hagino_0087.ogg"]
#【萩乃司】
「因为那可是中午12点啊」[p]
[tukasa_真顔_c]

[vo vo="ep4/yuzuha_0251.ogg"]
#【小仓 柚叶】
「…………」[p]

[vo vo="ep4/koku_0255.ogg"]
#【黒十 美鹤】
「…………」[p]

[vo vo="ep4/hagino_0088.ogg"]
[tukasa_真顔]
#【萩乃司】
「辉夜和我只有在放学后才会打扫礼拜堂」[p]

[vo vo="ep4/hagino_0089.ogg"]
#【萩乃司】
「况且如果不是白天，[r]　
　学生们在校园内……根本看不见钟塔吧？」[p]
[tukasa_真顔_c]

#
礼拜堂之主的话语让双方同时哑然。[p]

[tukasa_苦笑い_c]
看着这样的我们，萩乃小姐露出了苦笑。[p]

[vo vo="ep4/hagino_0090.ogg"]
[tukasa_苦笑い]
#【萩乃司】
「不，抱歉抱歉，肯定是哪里搞错了」[p]

[vo vo="ep4/hagino_0091.ogg"]
[tukasa_笑顔]
#【萩乃司】
「今天帮忙打扫真的很感谢！」[p]
[tukasa_笑顔_c]

;SE：屋外足音フェイドアウト
[se_f se="footstep_room_out.ogg"]

;1キャラ消去
[hide_tukasa]


#
说完便匆匆独自走进了礼拜堂。[p]

被留在原地的我们两人动弹不得。[p]

;BGM再生
[bgm ogg="mid_re.ogg"]

[vo vo="ep4/yuzuha_0252.ogg"]
[yuzuha_怒鳴る]
#【小仓 柚叶】
「黑、黑十先生……这、这是……！」[p]

;全キャラ瞬時に削除
[kill]

[yuzuha_怒鳴る]
[lec_f cg="yuzuha"]

[kokutou_驚き]
[ric cg="kokutou"]

[vo vo="ep4/koku_0256.ogg"]
;[kokutou_驚き]
#【黒十 美鹤】
「不，请等一下……什么都别说」[p]
[kokutou_驚き_c]

#
制止了正要开口的柚叶君。[p]

[kokutou_呆れ_c]

怎么可能有这种事。[p]

幽灵的存在根本不该被承认。[p]

[vo vo="ep4/koku_0257.ogg"]
[kokutou_哀2]
#【黒十 美鹤】
「还有很多我们不知道的信息……[r]　
　嗯，肯定是这样没错」[p]
[kokutou_哀2_c]

#
正如礼拜堂之主所说，可能是某种误会。[p]

[kokutou_呆れ_c]
没错，只是发生了误会。[p]

一定是这样。」[p]

[vo vo="ep4/yuzuha_0253.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「那个……您是不是有点混乱？」[p]
[yuzuha_哀_c]


[kokutou_驚き_c]

#
柚叶君的话让我回过神来。[p]

[vo vo="ep4/koku_0258.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「对、对不起……[r]　
　可能是来到不习惯的地方有点累了……」[p]
[kokutou_驚き_c]

#
勉强找了个借口搪塞过去，重新将视线移回柚叶君身上。[p]

[vo vo="ep4/yuzuha_0254.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「唔——黑十先生，其实我也有个疑问……」[p]

[vo vo="ep4/yuzuha_0255.ogg"]
#【小仓 柚叶】
「为什么辉夜前辈会[r]　
　在钟塔顶上拿着怀表呢？」[p]
[yuzuha_疑問_c]

[vo vo="ep4/koku_0259.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「怀表……？」[p]
[kokutou_疑問_c]

[vo vo="ep4/yuzuha_0256.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「黑十先生，您说过那是辉夜前辈[r]　
　用来回忆的道具对吧」[p][yuzuha_疑問_c]

#
确实之前在咖啡店看到她时，我得出了这个结论。[p]

那只怀表早已损坏，[r]　
根本不能正常计时。[p]

[vo vo="ep4/yuzuha_0257.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「为什么非要特地在钟塔顶上[r]　
　取出怀表呢？」[p]

;下記柚葉の台詞はアリスを鐘塔に登らせた場合のみ表示。

;//アリスを鐘塔へ登らせているか判定
[if exp="f.登らせる == 1"]
[jump target="*084100"]
[endif]

;//登っていない場合
[jump target="*084200"]


*084100

[vo vo="ep4/yuzuha_0258.ogg"]
#【小仓 柚叶】
「既然它被挂在那种地方，[r]　
　肯定是有人刻意放上去的」[p]

*084200

[yuzuha_疑問_c]


[kokutou_呆れ_c]

#
面对柚叶君的提问，我陷入沉思。[p]

[vo vo="ep4/koku_0260.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「……是在怀念恋人吧」[p]
[kokutou_哀_c]

#
听到我的回答，柚叶君罕见地没有接话。[p]

[vo vo="ep4/koku_0261.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「柚叶君？」[p]
[kokutou_疑問_c]

[vo vo="ep4/yuzuha_0259.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「……大概是因为想见谁吧」[p]
[yuzuha_哀_c]

[vo vo="ep4/koku_0262.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「想见谁？」[p]
[kokutou_疑問_c]

[vo vo="ep4/yuzuha_0260.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「辉夜前辈……或许是想见幽灵吧」[p]
[yuzuha_哀_c]

#
想要见幽灵。[p]

这就是那个黑发少女登上钟塔的理由。[p]

对于连幽灵存在都丝毫不相信的我而言，[r]　
那种想法实在无法理解。[p]

;//EDシナリオへジャンプ

[if exp="f.登らせる == 0"]
[jump target="*086100"]
[endif]

[if exp="f.絆創膏 == 0"]
[jump target="*086100"]
[endif]

;テキストウィンドウ削除
[end_text]

;BGM停止
[bgm_end3]

;全キャラ削除
[allc]

;背景
[bg10 bg="white.png"]

;--------------------------------------------------
*085000
[savetitle text="そんなもの……いるわけないのに"]
;-------------------------------------------------
[eval exp="f.サンドイッチ = 1"]
;//選択肢で輝夜に絆創膏を渡して、アリスを柚葉とともに鐘塔へ登らせた時のみ見れるシナリオ
;//絆創膏の時の回想。フラッシュバックするみたいにザザッと砂嵐的な演出とか？

;//黒背景
[bg20 bg="black.png"]

;イベントＣＧ表示
[event_in event="ep4_2_4"]

;SEを再生する
[se_f se="11.ogg"]

;テキストウィンドウ表示
[start_text]

[vo vo="ep4/kaguya_0051.ogg"]
#【蓬 辉夜】
「那种东西……明明不可能存在，不是太愚蠢了吗……」[p]
#
;イベントＣＧ削除
[event_out]

#
突然回想起她这样的呢喃。[p]

停止走动的怀表是为了回忆持有者的记忆工具。[p]

我确实曾经这么说过。[p]

[vo vo="ep4/yuzuha_0261.ogg"]
#【小仓 柚叶】
「……黑十先生？」[p]

;//礼拝堂前
[bg20 bg="chapel_01.jpg"]

;黒十衣装指定
[kokutou_c_コート]

;柚葉衣装指定
[yuzuha_c_コート]

[yuzuha_疑問_c]
[lec_f cg="yuzuha"]

[kokutou_真顔_c]
[ric cg="kokutou"]

#
柚叶君刚才说，莲小姐或许是想见幽灵。[p]

[vo vo="ep4/koku_0263.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「…………真是这样吗？」[p]
[kokutou_真顔_c]

#
总觉得忽略了什么重要的事情。[p]

根本不信幽灵的她为何要前往钟塔？[p]

又为何要在那种地方拿着作为记忆工具的怀表？[p]

[vo vo="ep4/koku_0264.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「持有者与钟塔有关联……[r]　
　还是说礼拜堂……不这也说不通……」[p]
[kokutou_真顔_c]

#
胸口突然涌起一阵无名的躁动。[p]

似乎遗漏了更简单的关键点。[p]

视线不自觉地搜寻着钟塔向上望去。[p]

当望向夜空时，柚叶君的话语浮现脑海。[p]

;//回想：セピアモード
;イベントＣＧ表示
[event_in event="past"]

;SEを再生する
[se_f se="01.ogg"]

[vo vo="ep4/yuzuha_0191.ogg"]
#【小仓 柚叶】
「黑十先生，对不起我来晚了！」[p]

[vo vo="ep4/koku_0153.ogg"]
#【黒十 美鹤】
「不，比起那个，情况如何，[r]　
　钟塔那边，顺利登到顶了吗？」[p]

[vo vo="ep4/yuzuha_0192.ogg"]
#【小仓 柚叶】
「超级高的！夜景超级漂亮！」[p]

;//回想ここまで：セピアモード終了
[event_out]

[vo vo="ep4/koku_0265.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「……好高……真的好高…………原来如此！」[p]
[kokutou_驚き_c]


;BGM再生
[bgm ogg="tukikage_02.ogg"]

#
然后他终于明白她登上钟塔的理由。[p]

[vo vo="ep4/koku_0266.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「不对……她本就不是冲着钟塔来的……！」[p]
[kokutou_驚き_c]

#
她的目标根本不在钟塔。[p]

她追求的并非钟塔 而是不易被人察觉的高处。[p]

脊背发寒 如坐针毡。[p]

回过神来时 我已朝着钟塔狂奔而去。[p]

[vo vo="ep4/yuzuha_0262.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「黑十先生，怎么了？」[p]
[yuzuha_驚き_c]

#
被我突然的奔跑惊到 柚叶君也跟了上来。[p]

[vo vo="ep4/koku_0267.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「现在没时间解释！[r]　
　但必须尽快赶到钟塔！」[p]
[kokutou_驚き_c]

#
眼下只能争分夺秒。[p]

为了阻止最坏的事态发生。[p]

;//礼拝堂
[bg20 bg="chapel_room_01.jpg"]

冲进礼拜堂环顾四周。[p]

但黑发少女的身影早已消失无踪。[p]

[vo vo="ep4/koku_0268.ogg"]
[kokutou_怒]
#【黒十 美鹤】
「明明刚才还在的……」[p]
[kokutou_怒_c]

#

;全キャラ削除
[allc]

;//礼拝堂・廊下
[bg-go bg="chapel_corridor_01.jpg"]
咂舌轻啧 转身奔向钟塔。[p]

;//礼拝堂・鐘塔前
[bg-go bg="chapel_corridor_02.jpg"]

穿过走廊来到破损的梯子前。[p]

那里竟堆出了先前并不存在的行李阶梯。[p]

[vo vo="ep4/yuzuha_0263.ogg"]
#【小仓 柚叶】
「这、黑十先生 难道说……」[p]

#
从现场痕迹看 对方似乎已向上攀爬。[p]

[vo vo="ep4/koku_0269.ogg"]
#【黒十 美鹤】
「抓紧时间」[p]

#
我们小心踏着摇摇欲坠的行李阶梯 向钟塔攀去。[p]

;//礼拝堂・鐘塔
[bg10 bg="bell_tower_01.jpg"]

铁门一开，四周便被黑暗笼罩。[p]

四面墙壁围绕的空间里，头顶隐约可见钟的影子。[p]

;//ハシゴの画像
[bg10 bg="ladder.jpg"]

然后――看来上方已有先到之人。[p]

[bgm_end1]

我和柚叶君屏息凝神，悄悄窥探着上方的动静。[p]

;//鐘塔
[bg20 bg="bell_tower_02.jpg"]

;BGM再生
[bgm ogg="kasasagi.ogg"]

[alice_真顔_c]
[lec_f cg="alice"]

[kaguya_無表情_c]
[ric cg="kaguya"]

[vo vo="ep4/alice_0128.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「呐，辉夜……第一次看到这景色时，你是怎么想的？」[p]
[alice_真顔_c]

#
碧眼少女向黑发少女轻声问道。[p]

[vo vo="ep4/kaguya_0072.ogg"]
[kaguya_思考]
#【蓬 辉夜】
「怎么想……就那样……」[p]
[kaguya_思考_c]

[vo vo="ep4/alice_0129.ogg"]
[alice_呆れ]
#【饴宫 爱丽丝】
「至少该觉得有点漂亮之类吧，[r]　
　连我都这么觉得」[p]
[alice_呆れ_c]

#
饴宫爱丽丝回答的语气比收到的回应更显无趣。[p]

[vo vo="ep4/kaguya_0073.ogg"]
[kaguya_無表情]
#【蓬 辉夜】
「…………」[p]
[kaguya_無表情_c]

#
面对沉默的黑发少女，[r]　
碧眼少女略显焦躁地继续说道。[p]

[vo vo="ep4/alice_0130.ogg"]
[alice_呆れ2]
#【饴宫 爱丽丝】
「哈啊，所以说你坏掉了啊，辉夜」[p]
[alice_呆れ2_c]

;//イベントCG

[vo vo="ep4/alice_0131.ogg"]
[alice_怒り]
#【饴宫 爱丽丝】
「面对这样的景色――居然想从这里跳下去」[p]
[alice_怒り_c]

#
风吹过的钟塔之上。[p]

两名少女未曾欣赏景色，[r]　
只是静静伫立原地。[p]

[vo vo="ep4/kaguya_0074.ogg"]
[kaguya_動揺_c]
#【蓬 辉夜】
「…………」[p]

[vo vo="ep4/alice_0132.ogg"]
[alice_呆れ]
#【饴宫 爱丽丝】
「所以刚才来到这里时很惊讶……[r]　
　该说是有点无奈吧」[p]
[alice_呆れ_c]

#
说完无奈后，她轻轻摇头发出「嗯」的声音。[p]

[vo vo="ep4/alice_0133.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「不――或许是感到悲伤」[p]
[alice_真顔_c]

[vo vo="ep4/kaguya_0075.ogg"]
[kaguya_驚き]
#【蓬 辉夜】
「悲伤？」[p]
[kaguya_驚き_c]

#
沉默不语的黑发少女不由得有了反应。[p]

她竟会说出悲伤这种感情，大概出乎意料吧。[p]

[vo vo="ep4/alice_0134.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「倒也不是不愿意承认啦」[p]

[vo vo="ep4/alice_0135.ogg"]
#【饴宫 爱丽丝】
「一想到这么美丽的景色，[r]　
　在你眼里却根本映不出来……就有点」[p]

[vo vo="ep4/alice_0136.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「辉夜……你就这么想死吗？」[p]

[vo vo="ep4/alice_0137.ogg"]
#【饴宫 爱丽丝】
「失去恋人对你打击这么大？」[p]
[alice_真顔_c]

[vo vo="ep4/kaguya_0076.ogg"]
[kaguya_悲しみ]
#【蓬 辉夜】
「……你根本……不会懂啦[r]　
　……不，不止是你」[p]

[vo vo="ep4/kaguya_0077.ogg"]
#【蓬 辉夜】
「失去那个人的悲伤，[r]　
　本就不是能与任何人分享的东西」[p]

[vo vo="ep4/kaguya_0078.ogg"]
#【蓬 辉夜】
「我的这种失落与空虚……没人能明白……」[p]
[kaguya_悲しみ_c]

#
这确实，或许正如她所说。[p]

失去重要之人的悲痛，他人终究只能想象。[p]

[vo vo="ep4/alice_0138.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「……是啊」[p]
[alice_真顔_c]

#
正因如此吧。[p]

饴宫爱丽丝干脆地承认了这点。[p]

[vo vo="ep4/kaguya_0079.ogg"]
[kaguya_悲しみ]
#【蓬 辉夜】
「我知道自己很可笑」[p]

[vo vo="ep4/kaguya_0080.ogg"]
#【蓬 辉夜】
「否则的话，[r]　
　才不会每周每周……重复那种无意义的事」[p]
[kaguya_悲しみ_c]

#
那声音里掺杂着某种懊悔的情绪。[p]

她当然也心知肚明。[p]

与逝者立下的约定根本不可能实现。[p]

即便如此，仍每周在相同店铺重复相同行为的自己。[p]

不断重复着这种连希望都算不上的事情的自己。[p]

然后――[p]

[vo vo="ep4/kaguya_0081.ogg"]
[kaguya_悲しみ]
#【蓬 辉夜】
「我并没有想过要从这里……跳下去」[p]
[kaguya_悲しみ_c]

#
想要自我了结的自己。[p]

黑发少女明白这些都是荒谬的事。[p]

[vo vo="ep4/alice_0139.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「那阻止她不就好了」[p]
[alice_真顔_c]

[vo vo="ep4/kaguya_0082.ogg"]
[kaguya_悲しみ]
#【蓬 辉夜】
「……可是……可是……！」[p]
[kaguya_悲しみ_c]

#
黑发少女拼命挤出声音。[p]

[vo vo="ep4/kaguya_0083.ogg"]
[kaguya_泣き]
#【蓬 辉夜】
「这样的……怀着这样的心情，我到底还要活多久？」[p]

[vo vo="ep4/kaguya_0084.ogg"]
#【蓬 辉夜】
「在那个人不存在的时间里……[r]　
　还要活多少秒、多少天、多少周才行？」[p]
[kaguya_泣き_c]

#
没有人能回答这个问题。[p]

当然，也包括近在咫尺的饴宫爱丽丝。[p]

[vo vo="ep4/kaguya_0085.ogg"]
[kaguya_泣き]
#【蓬 辉夜】
「我以为自己已经无法承受了……[r]　
　即使继续怀着这样的心情活下去……也没有意义吧？」[p]

[vo vo="ep4/kaguya_0086.ogg"]
#【蓬 辉夜】
「这样的我……根本没有容身之处……哪里都没有，哪里都没有……！」[p]
[kaguya_泣き_c]

[alice_呆れ2_c]

#
面对这颤抖的声音，饴宫爱丽丝依然无法回答。[p]

[vo vo="ep4/alice_0140.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「……你知道……我为什么要和辉夜在一起吗？」[p]
[alice_真顔_c]

#
取而代之的是完全不同的另一句话。[p]

[bgm_end1]

[vo vo="ep4/kaguya_0087.ogg"]
[kaguya_泣き]
#【蓬 辉夜】
「……咦？」[p]
[kaguya_泣き_c]

[vo vo="ep4/alice_0141.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「跳下去之前回答我，你觉得是为什么？」[p]
[alice_真顔_c]

[vo vo="ep4/kaguya_0089.ogg"]
[kaguya_無表情]
#【蓬 辉夜】
「和其他孩子一样吧……[r]　
　只是当作玩具来戏耍……现在也――」[p]

[vo vo="ep4/alice_0142.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「我对坏掉的玩具没兴趣」[p]

;BGM再生
[bgm ogg="7277.ogg"]

[alice_涙]

[vo vo="ep4/alice_0143.ogg"]
#【饴宫 爱丽丝】
「我可从来没把辉夜当作玩具什么的哦」[p]
[alice_笑み_c]

#
听到这句话，立刻就明白了。[p]

没错。[p]

原来是这样的啊。[p]

[vo vo="ep4/kaguya_0090.ogg"]
[kaguya_泣き]
#【蓬 辉夜】
「……爱丽丝？」[p]
[kaguya_泣き_c]

[vo vo="ep4/alice_0144.ogg"]
[alice_ドヤ顔]
#【饴宫 爱丽丝】
「……就辉夜那种性格的话[r]　
　根本不可能有一个朋友吧」[p]
[alice_ドヤ顔_c]

#
饴宫爱丽丝不是经常这么说吗。[p]

用名字称呼她。[p]

叫辉夜。[p]

饴宫爱丽丝只用名字来称呼的，不就只有她一个人吗。[p]

[vo vo="ep4/alice_0145.ogg"]
[alice_ドヤ顔]
#【饴宫 爱丽丝】
「所以我才大发慈悲当你的朋友……要感恩戴德哦」[p]
[alice_ドヤ顔_c]

#
面对一如既往傲慢态度的发言，但黑发少女还是流下了眼泪。[p]

[vo vo="ep4/kaguya_0091.ogg"]
[kaguya_笑み]
#【蓬 辉夜】
「你……是我的朋友？」[p]
[kaguya_笑み_c]

#
虽然流着泪，但黑发少女像是要露出微笑般问道。[p]

[vo vo="ep4/alice_0146.ogg"]
#【饴宫 爱丽丝】
「嗯，是吧，难道有过不是的时候吗？」[p]

[vo vo="ep4/alice_0147.ogg"]
#【饴宫 爱丽丝】
「所以明白了吗？在我面前说什么[r]　
　没有容身之处之类的蠢话，我可不允许哦？」[p]

[vo vo="ep4/kaguya_0092.ogg"]
[kaguya_大泣き]
#【蓬 辉夜】
「……爱丽丝……！」[p]
[kaguya_大泣き_c]

;イベントＣＧ表示
[eval exp="sf.cg_ep4_5 = 1"]
[event_in event="ep4_5"]

[vo vo="ep4/alice_0148.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「你以为我从一年级开始[r]　
　陪你开茶话会是为什么啊……真是的」[p]
[alice_笑み_c]

#
钟塔之上。[p]

黑发少女紧紧抱住友人，在她胸前哭泣。[p]

[alice_etc_off]

;イベントＣＧ削除
[event_out]

片刻后，抬起脸的少女[r]　
或许是被人看到哭脸觉得难为情。[p]

说出了这样的话。[p]

[vo vo="ep4/kaguya_0093.ogg"]
[alice_驚き_c]
[kaguya_笑み]
#【蓬 辉夜】
「……不想被你说。」[p]

[vo vo="ep4/kaguya_0094.ogg"]
#【蓬 辉夜】
「没有朋友的人，是你才对吧」[p]
[kaguya_笑み_c]

[alice_笑み_c]
#
友人以笑容回应。[p]

[vo vo="ep4/alice_0149.ogg"]
[alice_ドヤ顔]
#【饴宫 爱丽丝】
「真是有趣的玩笑呢，我就不生气了」[p]
[alice_ドヤ顔_c]

#

;全キャラ削除
[allc]

;//礼拝堂・鐘を見上げる
[bg20 bg="chapel_04.jpg"]

那晚，这座历史悠久的钟塔没有少女跳下。[p]

偷听到两位少女对话的我和柚叶君[r]　
默默离开了那里。[p]

想必她再也不会来到这个地方了吧。[p]

;テキストウィンドウ削除
[end_text]

;BGM停止
[bgm_end3]

;全キャラ削除
[allc]

;背景
[bg10 bg="white.png"]

;//選択肢によって見れるシナリオここまで



;//EDシナリオ
;--------------------------------------------------
*086000
[savetitle text="幽霊騒動の謎"]
;-------------------------------------------------
;BGM再生
[bgm ogg="mid_re.ogg"]

[bg20 bg="chapel_01.jpg"]



[yuzuha_笑顔_c]
[lec_f cg="yuzuha"]

[kokutou_微笑]
[ric cg="kokutou"]

;テキストウィンドウ表示
[start_text]

[vo vo="ep4/koku_0270.ogg"]
#【黒十 美鹤】
「嗯～～……！」[p]
[kokutou_微笑_c]

#
在原地大大地伸了个懒腰。[p]

收拾工作和幽灵骚动都已结束，大家各自踏上了归途。[p]

[jump target="*086200"]

;-------------------------------------------------
;アリス輝夜のやり取りが見れない場合のシナリオ

*086100

不过，持续思考不明白的事情也无济于事吧。[p]

像是要转换心情般在原地大大伸展身体。[p]

[vo vo="ep4/koku_0271.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「嗯～～……！」[p]
[kokutou_微笑_c]

[vo vo="ep4/yuzuha_0264.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「啊，不思考了呢？」[p]
[yuzuha_驚き_c]

[vo vo="ep4/koku_0272.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「哈哈，这样不也挺好嘛」[p]
[kokutou_微笑_c]
#

毕竟收拾工作和幽灵骚动都已结束了。[p]

真想早点离开这个鬼地方。[p]

;※ここまで
;#【小倉 柚葉】
;「いや～、楽しかったですねぇ」[p]
;に続く。

;-------------------------------------------------
*086200
[vo vo="ep4/yuzuha_0265.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「哎呀～真是开心呢」[p]
[yuzuha_笑顔_c]

[vo vo="ep4/koku_0273.ogg"]
[kokutou_呆れ]
#【黒十 美鹤】
「……哪里开心了……我再也不会来了」[p]
[kokutou_呆れ_c]

#
愤恨地瞪了礼拜堂一眼后迈步离开。[p]

[vo vo="ep4/yuzuha_0266.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「诶～为什么呀ー！？」[p]
[yuzuha_疑問_c]

#
当我快步离开现场时，柚叶君也紧随其后。[p]


[vo vo="ep4/koku_0274.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「什么都没有对吧」[p]
[kokutou_哀_c]

#
没想到会卷入如此麻烦的事。[p]

比想象的还要麻烦好几倍。[p]

[vo vo="ep4/koku_0275.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「这种麻烦事我可不想再有第二次了」[p]
[kokutou_哀_c]

[vo vo="ep4/yuzuha_0267.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「嘿嘿，抱歉啦」[p]

[vo vo="ep4/yuzuha_0268.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「不过不过，多亏了您[r]　
　我们才弄清楚了幽灵骚动的真相！」[p]

[vo vo="ep4/yuzuha_0269.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「嘛，虽然也有些不可思议的事啦……」[p]

[vo vo="ep4/yuzuha_0270.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「能把不明白的事情弄明白，真是帮大忙了，我很开心！」[p]
[yuzuha_笑顔_c]

#
柚叶君说着露出了灿烂的笑容。[p]

[vo vo="ep4/koku_0276.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「…………」[p]
[kokutou_驚き_c]

#
我对那张脸完全没辙。[p]

[vo vo="ep4/koku_0277.ogg"]
[kokutou_呆れ]
#【黒十 美鹤】
「不不，我应该不是那么好对付的类型才对……[r]　
　振作点……！」[p]
[kokutou_呆れ_c]

[vo vo="ep4/yuzuha_0271.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「嗯？怎么了？」[p]
[yuzuha_微笑_c]

[vo vo="ep4/koku_0278.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「没事没事，只是有点在意天气」[p]
[kokutou_微笑_c]

#
远方的天空中闪耀着大片的云团。[p]

看起来像是雷雨云。[p]

虽然这里还没开始下雨，但可能只是时间问题。[p]

远处时不时传来轰隆隆的声响。[p]

[vo vo="ep4/yuzuha_0272.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「呵呵呵，不过话说回来，黑十先生这次也很厉害呢」[p]
[yuzuha_笑顔_c]

[vo vo="ep4/koku_0279.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「厉害？」[p]
[kokutou_疑問_c]

[vo vo="ep4/yuzuha_0273.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「是啊，辉夜前辈到底怎么登上钟塔的[r]　
　您一下子就明白过来了！」[p]

[vo vo="ep4/yuzuha_0274.ogg"]
#【小仓 柚叶】
「那种情况下，任谁都会觉得肯定是幽灵出现了吧！」[p]
[yuzuha_笑顔_c]

[vo vo="ep4/koku_0280.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「这说法简直是在肯定幽灵存在呢」[p]

[vo vo="ep4/koku_0281.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「明白吗？世界上怎么可能会存在幽灵」[p]
[kokutou_真顔_c]

[yuzuha_哀_c]
#
我的话语让柚叶君露出了不满的表情。[p]

[vo vo="ep4/yuzuha_0275.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「咦——是这样吗——？」[p]
[yuzuha_哀_c]

[vo vo="ep4/koku_0282.ogg"]
[kokutou_呆れ]
#【黒十 美鹤】
「就是这样」[p]
[kokutou_呆れ_c]

#
无论柚叶君摆出什么表情 不存在的东西就是不存在。[p]

[vo vo="ep4/yuzuha_0276.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「不过 遇到那种情况[r]　
　承认是幽灵不是更自然吗？」[p]
[yuzuha_疑問_c]

[vo vo="ep4/koku_0283.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「自然？你说自然……」[p]
[kokutou_驚き_c]

[vo vo="ep4/yuzuha_0277.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「毕竟这所学校的学生们[r]　
　可全都相信幽灵出现了呀！」[p]
[yuzuha_笑顔_c]

#
柚叶君张开双手说道。[p]

[vo vo="ep4/yuzuha_0278.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「既然这么多人都喧嚷着幽灵出现，[r]　
　不觉得很自然吗？」[p]
[yuzuha_笑顔_c]

[vo vo="ep4/koku_0284.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「但真相并非如此」[p]
[kokutou_真顔_c]

#
从已决定拆除的旧校舍临时转移到礼拜堂的行李。[p]

利用这些登上钟塔的，是个遗落了物品的少女。[p]

仅此而已。[p]

比起幽灵现身钟塔这种谎言 要自然得多。[p]

[vo vo="ep4/koku_0285.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「我不认为真相会比谎言更不自然哦？」[p]
[kokutou_真顔_c]

[vo vo="ep4/yuzuha_0279.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「是这样么……」[p]
[yuzuha_哀_c]

[vo vo="ep4/koku_0286.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「就是这样」[p]
[kokutou_真顔_c]

[vo vo="ep4/yuzuha_0280.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「真是这样么……[r]　
　说成幽灵出现不是更自然吗？」[p]
[yuzuha_哀_c]

[vo vo="ep4/koku_0287.ogg"]
[kokutou_呆れ]
#【黒十 美鹤】
「哈……可以吗？」[p]

[vo vo="ep4/koku_0288.ogg"]
#【黒十 美鹤】
「世间万物皆有其缘由」[p]
[kokutou_呆れ_c]

[vo vo="ep4/yuzuha_0281.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「缘由……」[p]
[yuzuha_哀_c]

[vo vo="ep4/koku_0289.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「这世间的不自然之处，[r]　
　终究会被自然之事所化解」[p]
[kokutou_真顔_c]

[vo vo="ep4/yuzuha_0282.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「比方说？」[p]
[yuzuha_疑問_c]

[vo vo="ep4/koku_0290.ogg"]
[kokutou_呆れ]
#【黒十 美鹤】
「比方说那便是……」[p]
[kokutou_呆れ_c]

#
这时我想起了过去一年的事。[p]

[vo vo="ep4/koku_0291.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「那就是消失的男孩、[r]　
　无从下手的餐食、以及神秘的俱乐部」[p]
[kokutou_真顔_c]

[vo vo="ep4/yuzuha_0283.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「噢……！原来如此！」[p]
[yuzuha_笑顔_c]

#
柚叶君对我的话莫名认同地点了点头。[p]

[vo vo="ep4/koku_0292.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「所以礼拜堂的钟塔上，[r]　
　根本不可能出现什么幽灵嘛」[p]
[kokutou_微笑_c]

[vo vo="ep4/yuzuha_0284.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「……但那样的话岂不是很无趣？」[p]
[yuzuha_哀_c]

[vo vo="ep4/koku_0293.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「无……！？你竟说无趣，这话真是……！」[p]
[kokutou_驚き_c]

#
说出不该说的话的少女[r]　
歪着头露出困惑的神情。[p]

我为此付出的种种努力[r]　
可不能被她一句无趣就全盘否定。[p]

[vo vo="ep4/koku_0294.ogg"]
[kokutou_怒]
#【黒十 美鹤】
「……非常无趣！听好了，绝对无趣！」[p]
[kokutou_怒_c]

[vo vo="ep4/yuzuha_0285.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「嘿——就是说黑十先生觉得有趣咯？」[p]
[yuzuha_笑顔_c]

[vo vo="ep4/koku_0295.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「……啊、不……那个……」[p]
[kokutou_驚き_c]

[kokutou_呆れ_c]

#
糟了，被她将了一军。[p]

[vo vo="ep4/yuzuha_0286.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「啊ー，不行！　请好好说出来！[r]　
　很有趣对吧？」[p]
[yuzuha_微笑_c]

[vo vo="ep4/koku_0296.ogg"]
[kokutou_呆れ]
#【黒十 美鹤】
「并没有……那样的事……」[p]
[kokutou_呆れ_c]

[vo vo="ep4/yuzuha_0287.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「请说出来嘛～！　快看快看，很有趣对吧？」[p]
[yuzuha_笑顔_c]

[vo vo="ep4/koku_0297.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「啊ー，好了好了，知道了，我说我说很有趣――」[p]
#

[bgm_end0]

;//SE：落雷
;SE：落雷
[se_f se="lightning2.ogg"]
[image layer=0 name=thunder storage=white.png zindex=1000 time=100]
;全キャラ削除
[kill]
;イベントＣＧを背景に表示
[bg1 bg="blue.png"]
[free layer=0 name=thunder time=1000]
突然的轰鸣。[p]



[bg storage=ghost.jpg time="500"]

[vo vo="ep4/koku_0298.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「――――！？」[p]

[vo vo="ep4/yuzuha_0288.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「――诶？」[p]

;全キャラ削除
;[kill]

;イベントＣＧを背景に表示
[eval exp="sf.cg_ep4_3 = 1"]
[bg1 bg="cg_ep4_03.jpg"]


;イベントＣＧ表示
;[event_in event="ep4_3"]

[vo vo="ep4/yuzuha_0289.ogg"]
#【小仓 柚叶】
「……啊！？」[p]
#
;//おわり。[p]

;テキストウィンドウ削除
[end_text]

;イベントＣＧ削除
;[event_out]

;BGM再生
[bgm ogg="mid_re.ogg"]


;スタッフロールへ移動
[jump  storage="ep4_staff.ks"]

[s]