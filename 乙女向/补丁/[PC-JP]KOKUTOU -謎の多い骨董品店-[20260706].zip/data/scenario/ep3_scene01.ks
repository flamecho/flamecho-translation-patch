﻿;--------------------------------------------------
;■黒十　本文テキスト　ep3　御伽倶楽部
;--------------------------------------------------
;
;■ep3_scene01
;
;--------------------------------------------------
;シナリオ分岐の設定
[eval exp="f.problem_kokutou=0"]

;OP
[movie storage="op3.webm" skip=true volume="40"]

;--------------------------------------------------
*010000
[savetitle text="あの絵はなんで破けてるの？"]
;-------------------------------------------------

[cm]

;背景
[bg storage="dream.jpg" time="3000"]

;テキストウィンドウ表示
[start_text_dream]

;夢用フォント設定
[font color="0x333333" shadow="0xffffff"]

;//上記は小倉柚葉の台詞。[p]
[vo vo="ep3/yuzu_0001.ogg"]
#
『呐，那幅画为什么破了呀？』[p]

;BGM再生
[bgm ogg="kaiko.ogg"]

传来女孩子的声音。[p]

已经记不清是第几次听到这句话了。[p]

少女反复指着挂在墙上的画，[r]　
向周围的大人们重复着这个提问。[p]

但谁都没有要回答这个问题的意思。[p]

并非没有听见。[p]

只是彻底被无视了而已。[p]

;//下記は黒十美鶴の台詞。[p]
[vo vo="ep3/koku_0001.ogg"]
#【青年】
「啧…………哈……」[p]

#
在离少女稍远的位置，有个男人咂了下舌。[p]

吵死了——青年这么想着。[p]

突然不知想到什么，青年走近少女粗鲁地回答道。[p]

[vo vo="ep3/koku_0002.ogg"]
#【青年】
「那幅画并不是破损的喔」[p]

[vo vo="ep3/yuzu_0002.ogg"]
#【少女】
「……咦？」[p]

#
被突然搭话，少女掩饰不住困惑。[p]

青年甚至对这种反应都显得不耐烦，无视她继续说着。[p]

没错，他很不擅长应付小孩。[p]

[vo vo="ep3/koku_0003.ogg"]
#【青年】
「卡拉库尔……[r]　
因干燥和年久风化导致颜料裂开了」[p]

[vo vo="ep3/yuzu_0003.ogg"]
#【少女】
「卡拉……穆尔？」[p]

[vo vo="ep3/koku_0004.ogg"]
#【青年】
「卡拉库尔……说到底，那并不是破损」[p]

[vo vo="ep3/koku_0005.ogg"]
#【青年】
「只是表层颜料产生了裂纹而已」[p]

[vo vo="ep3/yuzu_0004.ogg"]
#【少女】
「……原来如此，我明白了」[p]

#
青年短暂地叹了口气。[p]

他心想这样就不用再听少女啰嗦的提问了。[p]

[vo vo="ep3/yuzu_0005.ogg"]
#【少女】
「…………」[p]

[vo vo="ep3/koku_0006.ogg"]
#【青年】
「……嗯？」[p]

#
少女笔直的视线投向青年。[p]

他很不擅长应付孩子。[p]

[vo vo="ep3/yuzu_0006.ogg"]
#【少女】
「………………」[p]

#
少女始终紧盯着青年。[p]

至于青年这边，[r]　
则是以苦涩至极的表情回望着少女。[p]

[vo vo="ep3/yuzu_0007.ogg"]
#【少女】
「…………」[p]

#
最终少女忽然绽开灿烂笑容。[p]

[vo vo="ep3/yuzu_0008.ogg"]
#【少女】
「谢谢你啦！」[p]

[vo vo="ep3/yuzu_0009.ogg"]
#【少女】
「搞懂不明白的事情，整个人都舒畅了！」[p]

[vo vo="ep3/koku_0007.ogg"]
#【青年】
「啊、啊哈，那个……不客气」[p]

[vo vo="ep3/yuzu_0010.ogg"]
#【少女】
「那再见啦！大哥哥！」[p]

#
少女向青年展露满面笑容。[p]

;テキストウィンドウ削除
[end_text]

[resetfont]

;BGM停止
[bgm_end2]

;//ここから現実
;//寝室？：黒ベタ
[bg10 bg="black.png"]

;テキストウィンドウ表示
[start_text]

[vo vo="ep3/yuzu_0011.ogg"]
#【？？？】
「……黒…………十」[p]

#
听见了熟悉的声音。[p]

[vo vo="ep3/yuzu_0012.ogg"]
#【？？？】
「……黒……十……先生！」[p]

#
这是听过无数次的声音。[p]

[vo vo="ep3/yuzu_0013.ogg"]
#【？？？】
「哈啊……真是的，黑十先生你呀……！」[p]

#
感受到身体被摇晃的触感。[p]

意识逐渐清醒过来。[p]

[vo vo="ep3/koku_0008.ogg"]
#【黒十 美鹤】
「呜……呜呜……」[p]

;//寝室
[bg10 bg="bedroom_0.jpg"]

#
微微地睁开眼睛。[p]

四周被炫目的阳光照耀着。[p]

[vo vo="ep3/yuzu_0014.ogg"]
#【？？？】
「啊、终于醒来了呢」[p]

[vo vo="ep3/koku_0009.ogg"]
#【黒十 美鹤】
「……柚叶君？」[p]

[vo vo="ep3/yuzu_0015.ogg"]
#【小仓 柚叶】
「已经早上了哦—，请快点起床啦！」[p]

[bg10 bg="bedroom.jpg"]

;BGM再生
[bgm ogg="music.ogg"]

;柚葉衣装指定
[yuzuha_c_秋]

[yuzuha_微笑_c]
[ce cg="yuzuha"]

#
房间内站着身穿制服的柚叶君。[p]

一大早就和平常一样的兴奋。[p]

[kill]

;黒十衣装指定
[kokutou_パジャマ]

[yuzuha_微笑_c]
[lec_f cg="yuzuha"]

;メガネ削除
[chara_part name="kokutou" accessory="02"] 

[kokutou_哀]
[ric cg="kokutou"]

[vo vo="ep3/koku_0010.ogg"]
#【黒十 美鹤】
「哈……请不要擅自打开木板套窗啊」[p]
[kokutou_哀_c]

[vo vo="ep3/yuzu_0016.ogg"]
[yuzuha_怒]
#【小仓 柚叶】
「你在说什么啊」[p]

[vo vo="ep3/yuzu_0017.ogg"]
#【小仓 柚叶】
「我要是不开门的话你就一直～～这么关着的毛病」[p]
[yuzuha_怒_c]

#
本想反驳些什么，但那确实是不争的事实。[p]

[vo vo="ep3/koku_0011.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「其实不用特地来叫我起床也可以哦？」[p]
[kokutou_哀_c]

[vo vo="ep3/yuzu_0018.ogg"]
[yuzuha_怒]
#【小仓 柚叶】
「因为我不来的话你马上就会昼夜颠倒生活不是吗」[p]

[vo vo="ep3/yuzu_0019.ogg"]
#【小仓 柚叶】
「不保持规律作息的话，[r]　
　本来就已经够宅的了」[p]
[yuzuha_怒_c]

#
从大清早就开始听唠叨。[p]

[vo vo="ep3/yuzu_0020.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「唔，如果黑十先生能会用手机的闹钟设定，[r]　
　我也就不会那么担心了啊」[p]

[vo vo="ep3/yuzu_0021.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「连电话也没法好好接呢ー」[p]
[yuzuha_笑顔_c]

#
她送给我的智能手机，[r]　
至今连基本操作都还不太熟练。[p]

虽然已经说明过闹钟的功能，[r]　
但始终不太能得心应手地使用。[p]

[vo vo="ep3/koku_0012.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「那个……我实在不知道该怎样才能关掉它」[p]

[vo vo="ep3/koku_0013.ogg"]
#【黒十 美鹤】
「以为关掉了却又开始定期响铃……」[p]
[kokutou_真顔_c]


[vo vo="ep3/yuzu_0022.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「那叫贪睡功能啦」[p]
[yuzuha_微笑_c]

[vo vo="ep3/koku_0014.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「贪……睡……？」[p]
[kokutou_疑問_c]

[vo vo="ep3/yuzu_0023.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「就是每隔固定时间重复响铃、[r]　
防止睡回笼觉的功能」[p]
[yuzuha_微笑_c]

[vo vo="ep3/koku_0015.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「原、原来如此……」[p]
[kokutou_哀_c]

[vo vo="ep3/yuzu_0024.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「不过呢～我都解释好多遍咯」[p]
[yuzuha_哀_c]

[vo vo="ep3/koku_0016.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「啊哈哈，真是不好意思……哈，现在情况和刚才完全相反……嗯？」[p]
[kokutou_哀_c]

#
他自言自语着歪了歪头。[p]

[vo vo="ep3/yuzu_0025.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「相反？什么相反呢？」[p]
[yuzuha_疑問_c]

[vo vo="ep3/koku_0017.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「……不，不知道你在说什么……」[p]
[kokutou_疑問_c]

[vo vo="ep3/yuzu_0026.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「黑十先生还没睡醒吗？」[p]

[vo vo="ep3/yuzu_0027.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「被子我来叠，你赶快去洗脸吧」[p]
[yuzuha_微笑_c]

[vo vo="ep3/koku_0018.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「好、好的，抱歉」[p]
[kokutou_哀_c]

#

;全キャラ削除
[allc]

;//洗面所
[bg10 bg="bathroom.jpg"]　

[kokutou_真顔_c]
[ce cg="kokutou"]

#
依言走向盥洗室刷牙洗脸。[p]

虽然头脑和身体都逐渐清醒、[r]　
但与此同时却有什么东西正在流失的错觉。[p]

[vo vo="ep3/koku_0019.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「总觉得好像做了个梦……」[p]
[kokutou_真顔_c]

#
努力回想却始终记不清具体内容。[p]

[vo vo="ep3/koku_0020.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「似乎……见到了谁？」[p]
[kokutou_疑問_c]

#
仿佛确实做了梦、[r]　
又仿佛什么都没梦见。[p]

[kokutou_真顔_c]
但继续纠结下去也无济于事。[p]

想不起来的东西终究是想不起来的。[p]

这种感受最好趁早放弃别去理会。[p]

;全キャラ削除
[allc]

;//洗面所から事務所へ
[bg10 bg="antique.jpg"]

;黒十衣装指定
[kokutou_c_晩秋]

;メガネ装着
[chara_part name="kokutou" accessory="01"] 

[kokutou_真顔_c]
[ce cg="kokutou"]

[vo vo="ep3/yuzu_0028.ogg"]
#【小仓 柚叶】
「醒了吗？」[p]

[vo vo="ep3/koku_0021.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「托您的福」[p]
[kokutou_真顔_c]

[vo vo="ep3/yuzu_0029.ogg"]
#【小仓 柚叶】
「咖啡泡好了请用」[p]

#
只见桌上放着一个杯子。[p]

[vo vo="ep3/yuzu_0030.ogg"]
#【小仓 柚叶】
「幸好还热着呢对吧？」[p]

[vo vo="ep3/koku_0022.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「嗯，谢谢」[p]
[kokutou_真顔_c]

;SE：
[se_f se="clearing_the_table.ogg"]

#
伸手拿起杯子凑到嘴边。[p]

身后的柚叶君正手忙脚乱地做着什么。[p]

看来她正在为我们准备早餐。[p]

[vo vo="ep3/koku_0023.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「不必为我做到那种地步的哟？」[p]
[kokutou_真顔_c]

#
朝着厨房的方向搭话。[p]

[vo vo="ep3/yuzu_0031.ogg"]
#【小仓 柚叶】
「诶～？因为我不准备的话你早上就不会吃嘛」[p]

[vo vo="ep3/koku_0024.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「但是，会很辛苦吧」[p]
[kokutou_真顔_c]

[vo vo="ep3/yuzu_0032.ogg"]
#【小仓 柚叶】
「已经习惯啦」[p]

;SE：
[se_f se="footsteps_in.ogg"]

#
正如那句话所说，柚叶君以熟练的动作[r]　
端来了吐司和火腿蛋。[p]

[kill]

[kokutou_真顔_c]
[ric_f cg="kokutou"]

[yuzuha_微笑_c]
[lec cg="yuzuha"]

[vo vo="ep3/koku_0025.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「一直以来都非常感谢」[p]
[kokutou_微笑_c]

[vo vo="ep3/yuzu_0033.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「哪里哪里不用谢……啊、糟糟糟都已经这个时间了！」[p]
[yuzuha_微笑_c]

#
柚叶君一边摆盘子一边看着时钟说道。[p]

从早上开始就真的很热闹呢。[p]

[vo vo="ep3/yuzu_0034.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「对不起，我该走了哦」[p]
[yuzuha_微笑_c]

#
柚叶君拿起放在沙发上的书包，[r]　
朝店门口走去。[p]

我单手端着咖啡杯，目送她的背影离去。[p]

;//店内
[bg10 bg="antique2.jpg"]

[vo vo="ep3/koku_0026.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「请小心点……别跑太快摔倒了」[p]
[kokutou_微笑_c]

[vo vo="ep3/yuzu_0035.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「明白啦！」[p]

[vo vo="ep3/yuzu_0036.ogg"]
[yuzuha_怒鳴る]
#【小仓 柚叶】
「……喂，当我是小孩子吗！」[p]
[yuzuha_怒鳴る_c]

[kill]

[kokutou_真顔_c]
[ce cg="kokutou"]

#
柚叶君一边吐槽一边冲出了店外。[p]

;SE：
[se_f se="door_op.ogg"]

[vo vo="ep3/yuzu_0037.ogg"]
#【小仓 柚叶】
「啊，对了！沙拉已经准备好了，[r]　
待会儿你就随便撕着吃吧！」[p]

[vo vo="ep3/koku_0027.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「知道知道」[p]
[kokutou_真顔_c]

[vo vo="ep3/yuzu_0038.ogg"]
#【小仓 柚叶】
「沙拉酱在冰箱右上角哦——！」[p]

#
我凝望着柚叶君渐远的背影。[p]

[vo vo="ep3/koku_0028.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「柚叶君！」[p]
[kokutou_真顔_c]

[vo vo="ep3/yuzu_0039.ogg"]
#【小仓 柚叶】
「……哈？」[p]


#
柚叶君一脸茫然地转过头来。[p]

[vo vo="ep3/koku_0029.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「路上小心，要好好学习哦」[p]
[kokutou_微笑_c]

[vo vo="ep3/yuzu_0040.ogg"]
#【小仓 柚叶】
「……嗯！我走啦！」[p]

#
她朝我绽开灿烂的笑容，再次迈步跑开了。[p]

;テキストウィンドウ削除
[end_text]

[kill]

;背景
[bg20 bg="white.png"]

;背景
[bg storage="dream.jpg" time="3000"]

;//停止
[wait time=1000]

;//店内
[bg10 bg="antique2.jpg"]

[kokutou_真顔_c]
[ce cg="kokutou"]

;テキストウィンドウ表示
[start_text]

[vo vo="ep3/koku_0030.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「……啊，想起来了」[p]
[kokutou_驚き_c]

#
看到那个笑容，我回忆起方才梦中的情景。[p]

[vo vo="ep3/koku_0031.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「呵呵……这可真是……做了个相当怀旧的梦呢」[p]
[kokutou_微笑_c]

#
还有，那个少女究竟是谁。[p]

;//スマホの通知音「ぴろん」[p]

[vo vo="ep3/koku_0032.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「嗯？」[p]
[kokutou_真顔_c]

#
当思绪飘向遥远的过去时，我不禁露出苦笑[r]　
这时手机屏幕上显示出一条消息。[p]

[vo vo="ep3/yuzu_0041.ogg"]
;//下記、小倉柚葉の台詞
『睡颜已收到！』[p]

伴随着这样的讯息，[r]　
还附带着一张毫无印象的被偷拍睡颜照。[p]

毫无疑问是柚叶君发来的。[p]

[vo vo="ep3/koku_0033.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「唉……真是的」[p]
[kokutou_微笑_c]

;全キャラ削除
[allc]

;//事務所
[bg10 bg="antique.jpg"]

[kokutou_真顔_c]
[ce cg="kokutou"]

#
我跌坐在沙发上，吃着柚叶君准备的早餐。[p]

咀嚼时突然想到：[p]

当我不在她身边的时候[p]

;全キャラ削除
[kill]

;//骨董店外観
[bg10 bg="shop_kokutou2.jpg"]

#
这孩子究竟是如何度日的呢。[p]


;テキストウィンドウ削除
[end_text]

;BGM停止
[bgm_end3]

;背景
[bg20 bg="white.png"]

;//黒十視点ここまで。[p]

;シーン2へ移動
[jump  storage="ep3_scene02.ks"]
[s]