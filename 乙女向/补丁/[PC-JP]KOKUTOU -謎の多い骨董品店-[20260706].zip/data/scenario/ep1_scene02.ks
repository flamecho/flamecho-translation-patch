﻿;--------------------------------------------------
*011000
[savetitle text="今回の謎の提供者"]
;-------------------------------------------------
[wait  time="1500"]

;背景
[bg10 bg="antique.jpg"]

[sayuri_微笑_c]
[ce cg="sayuri"]

;テキストウィンドウ表示
[start_text]

[sayuri_微笑]
[vo vo="ep1/sayu_0001.ogg"]
#【稻饼 小百合】
「初次见面，我是稻饼小百合」[p]
[sayuri_微笑_c]

;BGM再生
[bgm ogg="music.ogg"]

;全キャラ削除
[kill]

[kokutou_真顔_c]
[ric_f cg="kokutou"]
[yuzuha_微笑_c] 
[lec cg="yuzuha"]

[kokutou_真顔]
[vo vo="ep1/koku_0010.ogg"]
#【黒十 美鹤】
「啊——，那个……」[p]
[kokutou_真顔_c]

[yuzuha_微笑] 
[vo vo="ep1/yuzu_0010.ogg"]
#【小仓 柚叶】
「黑十先生，这位小百合小姐就是本次谜题的提供者，也就是委托人哦！」[p]
[yuzuha_微笑_c] 

#
隔着桌子相对而坐的女学生[r]　
正穿着和柚叶君相同的制服。[p]

[kokutou_哀]
[vo vo="ep1/koku_0011.ogg"]
#【黒十 美鹤】
「委托人……[r]　
　不如说事情太突然了我还没反应过来」[p]
[kokutou_哀_c]

[yuzuha_微笑] 
[vo vo="ep1/yuzu_0011.ogg"]
#【小仓 柚叶】
「这位小百合小姐经历了非常不可思议的事情呢」[p]
[yuzuha_微笑_c] 

[kokutou_哀]
[vo vo="ep1/koku_0012.ogg"]
#【黒十 美鹤】
「为什么我必须听那些不可思议的经历？」[p]
[kokutou_哀_c]

[yuzuha_笑顔]
[vo vo="ep1/yuzu_0012.ogg"]
#【小仓 柚叶】
「那个……嘛不是挺好的嘛！很有趣啊！」[p]
[yuzuha_笑顔_c]

[kill]
[kokutou_哀_c]
[ri_f cg="kokutou"]
[yuzuha_笑顔_c]
[ce_f cg="yuzuha"]
[sayuri_微笑_c]
[le cg="sayuri"]

[sayuri_微笑]
[vo vo="ep1/sayu_0002.ogg"]
#【稻饼 小百合】
「那个……小柚叶？我可以开始说吗？」[p]
[sayuri_微笑_c]

[yuzuha_笑顔]
[vo vo="ep1/yuzu_0013.ogg"]
#【小仓 柚叶】
「没关系没关系！」[p]
[yuzuha_笑顔_c]

[kokutou_哀]
[vo vo="ep1/koku_0013.ogg"]
#【黒十 美鹤】
「哈——，真拿你没办法……[r]　
　先泡杯咖啡吧，难得有客人来」[p]
[kokutou_哀_c]
#
预感到会是个很长的故事，说着便站起身来。[p]

[sayuri_微笑]
[vo vo="ep1/sayu_0003.ogg"]
#【稻饼 小百合】
「啊，抱歉，不用麻烦的」[p]
[sayuri_微笑_c]

[kokutou_真顔]
[vo vo="ep1/koku_0014.ogg"]
#【黒十 美鹤】
「没事没事，咖啡可以吗？要加糖和牛奶吗？」[p]
[kokutou_真顔_c]

[sayuri_微笑]
[vo vo="ep1/sayu_0004.ogg"]
#【稻饼 小百合】
「啊，黑咖啡就好」[p]
[sayuri_微笑_c]

[yuzuha_微笑]
[vo vo="ep1/yuzu_0014.ogg"]
#【小仓 柚叶】
「啊，我要加三块糖」[p]
[yuzuha_微笑_c]

[kokutou_哀]
[vo vo="ep1/koku_0015.ogg"]
#【黒十 美鹤】
「要加那么多吗？」[p]
[kokutou_哀_c]

[yuzuha_微笑]
[vo vo="ep1/yuzu_0015.ogg"]
#【小仓 柚叶】
「我喜欢超级甜的！」[p]
[yuzuha_微笑_c]

[kokutou_真顔]
[vo vo="ep1/koku_0016.ogg"]
#【黒十 美鹤】
「好啦好啦知道啦，稍等一下哦」[p]
[kokutou_真顔_c]

;黒十削除
[chara_hide name=kokutou]

;SE：足音フェイドアウト
[se_f se="footsteps_out.ogg"]
#
为冲泡咖啡而起身离席。[p]


;テキストウィンドウ削除
[end_text]

;全キャラ削除
[allc]

[bg10 bg="kitchen.jpg"]

[kokutou_真顔]
[ce cg="kokutou"]


;テキストウィンドウ表示
[start_text]

;SE：戸棚
[se_f se="sei_ge_todana_op01.ogg"]
#
打开橱柜时，正思索该选用哪个杯子。[p]

#

;選択肢
[glink x="266" y="186" graphic="txtlink.png" width="712"  size="28" text="待たせるのは良くない、ほどほどにしましょう。" storage="ep1_scene02.ks" target="*hodohodo"]
[glink x="266" y="299" graphic="txtlink.png" width="712" size="28" text="カップ選びは重要だ、真剣に悩みましょう。" storage="ep1_scene02.ks" target="*sinnkenn"]
[s]

;--------------------------------------------------
*hodohodo
[savetitle text="待たせるのはほどほどに"]
;-------------------------------------------------

[eval exp="f.cup_choose = 1"]

[kokutou_真顔]
[vo vo="ep1/koku_0017.ogg"]
#【黒十 美鹤】
「不，在这种场合[r]　
　执着于古董也毫无意义吧……」[p]
[kokutou_真顔_c]

#
正进行咖啡准备时，隐约听见远处两人的交谈声。[p]

看来二人似乎是同学院同班级的。[p]

;SE：注ぐ
[se_f se="drink.ogg"]
将咖啡注入杯中。[p]

唯独在柚叶君的杯子里放入三颗方糖。[p]
;SE：スプーンで混ぜる
[se_f se="spoonmaze.ogg"]
顺手又多加了些牛奶搅拌杯中之物。[p]


;全キャラ削除
[allc]

;背景
[bg10 bg="antique.jpg"]

[kokutou_真顔]
[ce cg="kokutou"]

[vo vo="ep1/koku_0018.ogg"]
#【黒十 美鹤】
「来请用，久等了」[p]
[kokutou_真顔_c]

;SE:カップの音
[se_f se="clearing_the_table.ogg"]

[kill]
[kokutou_真顔_c]
[ri_f cg="kokutou"]
[yuzuha_微笑_c]
[ce_f cg="yuzuha"]
[sayuri_微笑_c]
[le cg="sayuri"]

[sayuri_微笑]
[vo vo="ep1/sayu_0005.ogg"]
#【稻饼 小百合】
「非常感谢」[p]
[sayuri_微笑_c]

[yuzuha_怒]
[vo vo="ep1/yuzu_0016.ogg"]
#【小仓 柚叶】
「……啊ー！黑十先生，我的咖啡里不是加了牛奶嘛！」[p]
[yuzuha_怒_c]

[kokutou_真顔]
[vo vo="ep1/koku_0019.ogg"]
#【黒十 美鹤】
「咦？难道不该加牛奶吗？明明都放了三颗糖的？」[p]
[kokutou_真顔_c]

[yuzuha_哀]
[vo vo="ep1/yuzu_0017.ogg"]
#【小仓 柚叶】
「不加的……[r]　
　从小就这样不是吗，您不记得了吗？」[p]
[yuzuha_哀_c]

[kokutou_哀]
[vo vo="ep1/koku_0020.ogg"]
#【黒十 美鹤】
「……怎么可能记得啊」[p]
[kokutou_哀_c]

[yuzuha_哀]
[vo vo="ep1/yuzu_0018.ogg"]
#【小仓 柚叶】
「唔……请好好记住啦……」[p]
[yuzuha_哀_c]

[kokutou_真顔]
[vo vo="ep1/koku_0021.ogg"]
#【黒十 美鹤】
「要重新冲一杯吗？」[p]
[kokutou_真顔_c]

[yuzuha_微笑]
[vo vo="ep1/yuzu_0019.ogg"]
#【小仓 柚叶】
「啊，那倒不必，毕竟是黑十先生特地泡的」[p]
[yuzuha_微笑_c]

#
看来倒也不是完全不能接受。[p]


[jump  storage="ep1_scene02.ks"  target="*gouryuu"]

[s]

;--------------------------------------------------
*sinnkenn
[savetitle text="カップ選びは真剣に悩みましょう"]
;-------------------------------------------------

[eval exp="f.cup_choose = 0"]

#
作为经营古董店的成年男性自有其矜持。[p]

[kokutou_微笑]
[vo vo="ep1/koku_0022.ogg"]
#【黒十 美鹤】
「这种时候就该认真烦恼，用像样的杯子呈上才对」[p]

[kokutou_真顔]
[vo vo="ep1/koku_0023.ogg"]
#【黒十 美鹤】
「所以说马克杯在这里应该被排除」[p]

[vo vo="ep1/koku_0024.ogg"]
#【黒十 美鹤】
「人们期待的应该是坚固的咖啡杯……」[p]

[kokutou_怒]
[vo vo="ep1/koku_0025.ogg"]
#【黒十 美鹤】
「嗯……选NARUMI的杯子如何……[r]　
　不，选择历史悠久MEISSEN的如何？」[p]

[vo vo="ep1/koku_0026.ogg"]
#【黒十 美鹤】
「不不，英国皇室御用、设计独特的WEDGWOOD……！」[p]

[vo vo="ep1/koku_0027.ogg"]
#【黒十 美鹤】
「对于追求年轻感的女学生来说这类才更――」[p]
[kokutou_真顔_c]

[vo vo="ep1/yuzu_0020.ogg"]
#【小仓 柚叶】
「黑十先生！」[p]

[kill]
[kokutou_驚き_c]
[ric_f cg="kokutou"]
[yuzuha_怒_c] 
[lec cg="yuzuha"]

#
突然被大声呼唤名字而回头。[p]

只见柚叶君鼓着脸颊正瞪着我。[p]

[yuzuha_怒] 
[vo vo="ep1/yuzu_0021.ogg"]
#【小仓 柚叶】
「因为一直不回来所以过来看看[r]　
　结果你居然在摆弄相似的咖啡杯自得其乐！」[p]
[yuzuha_怒_c] 

#
糟了，看来我又在排列古董[r]　
沉浸其中了。[p]

[yuzuha_怒] 
[vo vo="ep1/yuzu_0022.ogg"]
#【小仓 柚叶】
「接下来由我来泡，请您先回去吧！」[p]
[yuzuha_怒_c] 

[kokutou_疑問]
[vo vo="ep1/koku_0028.ogg"]
#【黒十 美鹤】
「…………实在惭愧」[p]
[kokutou_疑問_c]

;テキストウィンドウ削除
[end_text]

;全キャラ削除
[allc]

;背景
[bg10 bg="antique.jpg"]

[kokutou_真顔_c]
[ri_f cg="kokutou"]

[yuzuha_怒_c]
[ce_f cg="yuzuha"]

[sayuri_微笑_c]
[le cg="sayuri"]

;テキストウィンドウ表示
[start_text]

[yuzuha_怒]
[vo vo="ep1/yuzu_0023.ogg"]
#【小仓 柚叶】
「真是的，连一秒钟都不能松懈[r]　
　马上就忘乎所以了呢」[p]
[yuzuha_怒_c]

[sayuri_微笑]
[vo vo="ep1/sayu_0006.ogg"]
#【稻饼 小百合】
「啊哈哈哈……」[p]
[sayuri_微笑_c]

#
再被数落下去可招架不住。[p]

决定赶快推进话题，便主动抛出话头。[p]

;--------------------------------------------------
*gouryuu
[savetitle text="とっても不思議な話なんです"]
;-------------------------------------------------

[kokutou_真顔]
[vo vo="ep1/koku_0029.ogg"]
#【黒十 美鹤】
「所以，到底是什么事情？」[p]
[kokutou_真顔_c]

[yuzuha_笑顔]
[vo vo="ep1/yuzu_0024.ogg"]
#【小仓 柚叶】
「呵呵呵，果然黑十先生也很在意呢！」[p]
[yuzuha_笑顔_c]

[kokutou_怒]
[vo vo="ep1/koku_0030.ogg"]
#【黒十 美鹤】
「就算不在意你也会强行告诉我吧？」[p]

[vo vo="ep1/koku_0031.ogg"]
#【黒十 美鹤】
「反正肯定又想把我卷进麻烦事里」[p]
[kokutou_怒_c]

[yuzuha_微笑]
[vo vo="ep1/yuzu_0025.ogg"]
#【小仓 柚叶】
「……哎呀哎呀……『又』是什么意思呢？」[p]
[yuzuha_微笑_c]

[kokutou_哀]
[vo vo="ep1/koku_0032.ogg"]
#【黒十 美鹤】
「麻烦事我可敬谢不敏哦？」[p]
[kokutou_哀_c]

[yuzuha_笑顔]
[vo vo="ep1/yuzu_0026.ogg"]
#【小仓 柚叶】
「好啦好啦，别这么说先听我讲嘛」[p]

[vo vo="ep1/yuzu_0027.ogg"]
#【小仓 柚叶】
「这可是非常不可思议的故事呢」[p]
[yuzuha_笑顔_c]

#
她笑容满面地回答道。[r]　
这种时候无论说什么对方都不会听进去吧。[p]

[kokutou_真顔_c]
[yuzuha_微笑_c]

;BGM停止
[bgm_end2]

[kokutou_真顔]
[vo vo="ep1/koku_0033.ogg"]
#【黒十 美鹤】
「……明白了，请说」[p]
[kokutou_真顔_c]

#
我放弃挣扎，将话题抛给似乎经历过奇妙事件的稻饼小百合小姐。[p]


[sayuri_微笑]
[vo vo="ep1/sayu_0007.ogg"]
#【稻饼 小百合】
「那个，这是最近刚发生的事情」[p]


[vo vo="ep1/sayu_0008.ogg"]
#【稻饼 小百合】
「……有个经常能看到的男孩子」[p]

;BGM再生
[bgm ogg="tukikage.ogg"]

[vo vo="ep1/sayu_0009.ogg"]
#【稻饼 小百合】
「上学路上总看到他走进一家老式咖啡馆」[p]

[sayuri_照れ]

[vo vo="ep1/sayu_0010.ogg"]
#【稻饼 小百合】
「我对他那个......一见钟情了」[p]
[sayuri_微笑_c]

#
说到这里委托人突然满脸通红。[p]

[sayuri_微笑]
[vo vo="ep1/sayu_0011.ogg"]
#【稻饼 小百合】
「起初只是觉得‘真是个漂亮的孩子呢’而已」[p]

[sayuri_必死]
[vo vo="ep1/sayu_0012.ogg"]
#【稻饼 小百合】
「但连氛围啊走路姿势啊仪态都特别棒！」[p]

[vo vo="ep1/sayu_0013.ogg"]
#【稻饼 小百合】
「回过神来，每天早上期待见到他已经成了习惯」[p]

[sayuri_照れ]
[vo vo="ep1/sayu_0014.ogg"]
#【稻饼 小百合】
「意识到这样的自己......我......[r]　
　终于明白原来是坠入爱河了！」[p]
[sayuri_照れ_c]

#
这孩子到底在跟我说些什么啊。[p]

而我又到底被迫听着些什么啊。[p]

[kokutou_疑問]
[vo vo="ep1/koku_0034.ogg"]
#【黒十 美鹤】
「柚叶君......？」[p]
[kokutou_疑問_c]
#
不安地将视线转向把这位恋爱中的女学生带来的少女。[p]

[yuzuha_笑顔]
[vo vo="ep1/yuzu_0028.ogg"]
#【小仓 柚叶】
「没关系的，就这样继续听下去吧！」[p]
[yuzuha_笑顔_c]

[kokutou_哀_c]
#
看到柚叶君微笑的表情，不安感愈发强烈。[p]

重新振作精神，将视线移回小百合小姐身上。[p]

[kokutou_真顔_c]

[yuzuha_微笑]
[vo vo="ep1/sayu_0015.ogg"]
#【稻饼 小百合】
「所以我才鼓足勇气，决定试着和他搭话」[p]

[vo vo="ep1/sayu_0016.ogg"]
#【稻饼 小百合】
「于是在上学路上，看到他进了咖啡店就追过去[r]　
　我也跟着进了咖啡店」[p]

[vo vo="ep1/sayu_0017.ogg"]
#【稻饼 小百合】
「结果……」[p]

[vo vo="ep1/sayu_0018.ogg"]
#【稻饼 小百合】
「人不见了」[p]
[yuzuha_微笑_c]

[kokutou_真顔]
[vo vo="ep1/koku_0035.ogg"]
#【黒十 美鹤】
「不见了？你是说追过去的那个他吗？」[p]
[kokutou_真顔_c]

[yuzuha_微笑]
[vo vo="ep1/sayu_0019.ogg"]
#【稻饼 小百合】
「是的，就算环视整个店内，他也没坐在任何地方」[p]
[yuzuha_微笑_c]

[kokutou_真顔]
[vo vo="ep1/koku_0036.ogg"]
#【黒十 美鹤】
「也就是说……本该进入那家店的人消失了？」[p]
[kokutou_真顔_c]

[yuzuha_怒鳴る]
[vo vo="ep1/yuzu_0029.ogg"]
#【小仓 柚叶】
「就是这样！很奇怪对吧！？」[p]
[yuzuha_怒鳴る_c]

#
回答这个问题的不是稻饼小姐，而是探出身子的柚叶君。[p]

[yuzuha_怒鳴る]
[vo vo="ep1/yuzu_0030.ogg"]
#【小仓 柚叶】
「因为走进咖啡店的初恋对象，居然从店里消失了啊！」[p]
[yuzuha_怒鳴る_c]

[kokutou_凛]
[vo vo="ep1/koku_0037.ogg"]
#【黒十 美鹤】
「不，这根本算不上奇怪吧」[p]
[kokutou_凛_c]

[yuzuha_疑問]
[vo vo="ep1/yuzu_0031.ogg"]
#【小仓 柚叶】
「诶？为什么啊？进了咖啡店的人消失了哦？」[p]
[yuzuha_疑問_c]

[kokutou_凛]
[vo vo="ep1/koku_0038.ogg"]
#【黒十 美鹤】
「他确实进了那家咖啡店吧」[p]
[kokutou_凛_c]

[yuzuha_怒鳴る]
[vo vo="ep1/yuzu_0032.ogg"]
#【小仓 柚叶】
「那么――」[p]
[yuzuha_怒鳴る_c]

[kokutou_凛]
[vo vo="ep1/koku_0039.ogg"]
#【黒十 美鹤】
「只不过不是作为顾客，而是作为在店里工作的店员」[p]
[kokutou_凛_c]

[yuzuha_疑問]
[vo vo="ep1/yuzu_0033.ogg"]
#【小仓 柚叶】
「店员？」[p]
[yuzuha_疑問_c]

[kokutou_凛]
[vo vo="ep1/koku_0040.ogg"]
#【黒十 美鹤】
「没错，所以在店里找座位自然找不到人」[p]

[vo vo="ep1/koku_0041.ogg"]
#【黒十 美鹤】
「既然在视线范围内看不到[r]　
　说不定正在后厨工作呢？」[p]
[kokutou_凛_c]

[yuzuha_驚き]
[vo vo="ep1/yuzu_0034.ogg"]
#【小仓 柚叶】
「啊——原来如此」[p]
[yuzuha_驚き_c]

#
听到这个假设，柚叶君瞪大了眼睛。[p]

[sayuri_哀]
[vo vo="ep1/sayu_0020.ogg"]
#【稻饼 小百合】
「那个……」[p]
[sayuri_哀_c]

[kokutou_真顔_c]
[yuzuha_微笑_c]
#
然而委托人的神色似乎依旧阴郁。[p]

[sayuri_哀]
[vo vo="ep1/sayu_0021.ogg"]
#【稻饼 小百合】
「我觉得那种可能性不存在」[p]

[vo vo="ep1/sayu_0022.ogg"]
#【稻饼 小百合】
「我也立即这么想了 就问当时在咖啡厅的小庵」[p]

[vo vo="ep1/sayu_0023.ogg"]
#【稻饼 小百合】
「这家咖啡店有没有男生在打工」[p]
[sayuri_哀_c]

[kokutou_真顔]
[vo vo="ep1/koku_0042.ogg"]
#【黒十 美鹤】
「小庵？」[p]
[kokutou_真顔_c]

[sayuri_微笑]
[vo vo="ep1/sayu_0024.ogg"]
#【稻饼 小百合】
「啊 不好意思[r]　
　是在那家咖啡店工作的女店员　御手洗庵小姐」[p]

[vo vo="ep1/sayu_0025.ogg"]
#【稻饼 小百合】
「因为这次事件 我们变得熟络起来」[p]
[sayuri_微笑_c]

[yuzuha_怒鳴る]
[vo vo="ep1/yuzu_0035.ogg"]
#【小仓 柚叶】
「然后呢？她怎么说！？」[p]
[yuzuha_怒鳴る_c]

[sayuri_微笑]
[vo vo="ep1/sayu_0026.ogg"]
#【稻饼 小百合】
「她说这家咖啡店没有男生打工」[p]

[vo vo="ep1/sayu_0027.ogg"]
#【稻饼 小百合】
「说在这家咖啡店工作的全是女性」[p]
[sayuri_微笑_c]

[yuzuha_笑顔]
[vo vo="ep1/yuzu_0036.ogg"]
#【小仓 柚叶】
「……太谜了……黑十先生！这简直是个谜啊！」[p]
[yuzuha_笑顔_c]

[kokutou_哀_c]
#
柚叶君莫名兴奋地说着。[p]

相反 我却为这个看似麻烦的谜题头疼不已。[p]

[yuzuha_微笑_c]
[kokutou_真顔]
[vo vo="ep1/koku_0043.ogg"]
#【黒十 美鹤】
「那个 稻饼小姐」[p]
[kokutou_真顔_c]

[sayuri_微笑]
[vo vo="ep1/sayu_0028.ogg"]
#【稻饼 小百合】
「嗯」[p]
[sayuri_微笑_c]

[kokutou_真顔]
[vo vo="ep1/koku_0044.ogg"]
#【黒十 美鹤】
「你确实亲眼看见意中人进了咖啡店对吧？」[p]
[kokutou_真顔_c]

#
我决定重新梳理状况 继续提问道。[p]

[sayuri_必死]
[vo vo="ep1/sayu_0029.ogg"]
#【稻饼 小百合】
「是的！我亲眼所见　绝不可能看错！」[p]
[sayuri_必死_c]

[kokutou_真顔]
[vo vo="ep1/koku_0045.ogg"]
#【黒十 美鹤】
「但他并不在店内[r]　
　而且据店员说打工的只有女性」[p]
[kokutou_真顔_c]

[sayuri_必死]
[vo vo="ep1/sayu_0030.ogg"]
#【稻饼 小百合】
「没错！这也是毫无疑问的！」[p]
[sayuri_必死_c]

[kokutou_疑問]
[vo vo="ep1/koku_0046.ogg"]
#【黒十 美鹤】
「哼嗯……」[p]
[kokutou_疑問_c]

#
如此一来，她所倾心的那个男孩[r]　
究竟消失到何处去了呢。[p]

理应存在之人[r]　
竟会从那个场所瞬间消失，这根本不可能。[p]

那么……。[p]

[kokutou_真顔]
[vo vo="ep1/koku_0047.ogg"]
#【黒十 美鹤】
「无论出于何种理由，他是否先进了咖啡馆[r]　
　再从后门离开了呢？」[p]
[kokutou_真顔_c]

#
我询问道，委托人却缓缓摇了摇头。[p]

[sayuri_哀]
[vo vo="ep1/sayu_0031.ogg"]
#【稻饼 小百合】
「那个也确认过了[r]　
　但后门好像被封住无法使用」[p]

[vo vo="ep1/sayu_0032.ogg"]
#【稻饼 小百合】
「我也亲眼确认过[r]　
　后门确实处于无法使用的状态」[p]
[sayuri_哀_c]

#
看来这个可能性也被排除了。[p]

这位少女，看似文静的外表下，行动力倒是出人意料。[p]

[kokutou_疑問]
[vo vo="ep1/koku_0048.ogg"]
#【黒十 美鹤】
「嗯……」[p]
[kokutou_疑問_c]

#
我试着说出目前想到的可能性，但似乎并不正确。[p]

事已至此，却想不出下一步的可能性。[p]

[yuzuha_笑顔]
[vo vo="ep1/yuzu_0037.ogg"]
#【小仓 柚叶】
「黑十先生！你看，果然很不可思议对吧！？」[p]

[vo vo="ep1/yuzu_0038.ogg"]
#【小仓 柚叶】
「进了咖啡馆的男孩，竟从店里消失了！」[p]
[yuzuha_笑顔_c]

[kokutou_怒_c]
#
我用手推开凑近逼问的柚叶君的脸。[r]　
逐渐感到麻烦起来。[p]

[yuzuha_驚き]
[vo vo="ep1/yuzu_0039.ogg"]
#【小仓 柚叶】
「呜呀！？干、干什么呀——，对少女的脸……！」[p]
[yuzuha_驚き_c]

#
无视柚叶君说道。[p]

[kokutou_真顔]
[vo vo="ep1/koku_0049.ogg"]
#【黒十 美鹤】
「是不是看错了？」[p]
[kokutou_真顔_c]

[yuzuha_驚き]
[vo vo="ep1/yuzu_0040.ogg"]
#【小仓 柚叶】
「看错？看错是指什么？」[p]
[yuzuha_驚き_c]

[kokutou_真顔]
[vo vo="ep1/koku_0050.ogg"]
#【黒十 美鹤】
「也就是说，你心仪的那个男生可能从一开始就没进过咖啡店吧？」[p]
[kokutou_真顔_c]

[yuzuha_怒]
#
对这个自暴自弃的回答，柚叶君正要提出抗议。[p]

但在这之前稻饼小姐先开了口。[p]

[sayuri_必死]
[vo vo="ep1/sayu_0033.ogg"]
#【稻饼 小百合】
「那也不可能，因为第二天我又去确认了！」[p]

[yuzuha_微笑]
[vo vo="ep1/sayu_0034.ogg"]
#【稻饼 小百合】
「结果那天那个男生确实走进咖啡店了！」[p]
[yuzuha_微笑_c]

[kokutou_驚き_c]
#
果然行动力惊人。[p]

[yuzuha_微笑]
[vo vo="ep1/sayu_0035.ogg"]
#【稻饼 小百合】
「所以实在忍不住在意[r]　
　我就在那家店门口蹲守他了！」[p]
[yuzuha_微笑_c]

[yuzuha_驚き]
[vo vo="ep1/yuzu_0041.ogg"]
#【小仓 柚叶】
「咦？蹲、蹲守！？」[p]
[yuzuha_驚き_c]

[yuzuha_微笑]
[vo vo="ep1/sayu_0036.ogg"]
#【稻饼 小百合】
「没错！一直等到那个男孩从店里出来！」[p]
[yuzuha_微笑_c]

[kokutou_真顔]
[vo vo="ep1/koku_0051.ogg"]
#【黒十 美鹤】
「看着文静，没想到除了行动力连耐力也很强呢」[p]
[kokutou_真顔_c]

#
想必这份感情是认真的吧。[p]

[yuzuha_微笑_c]
[sayuri_哀]
[vo vo="ep1/sayu_0037.ogg"]
#【稻饼 小百合】
「不过...果然还是...有点不可思议...」[p]
[sayuri_哀_c]

#
单恋中的少女突然沮丧地垂下脸。[p]

[kokutou_怒_c]

有种不祥的预感。[p]

但听到这里已经彻底失去了逃跑的机会。[p]

[sayuri_哀]
[vo vo="ep1/sayu_0038.ogg"]
#【稻饼 小百合】
「可无论等多久，他都没从咖啡店出来」[p]
[sayuri_哀_c]

[yuzuha_驚き]
[vo vo="ep1/yuzu_0042.ogg"]
#【小仓 柚叶】
「这、这这这、这就是说！」[p]

[vo vo="ep1/yuzu_0043.ogg"]
#【小仓 柚叶】
「那个男孩子进了咖啡店后就真的彻底消失了！？」[p]
[yuzuha_驚き_c]

#
柚叶君激动地说道。[p]

[sayuri_必死]
[vo vo="ep1/sayu_0039.ogg"]
#【稻饼 小百合】
「正、正是如此！」[p]
[sayuri_必死_c]

[yuzuha_怒鳴る]
[vo vo="ep1/yuzu_0044.ogg"]
#【小仓 柚叶】
「没、没错哟！」[p]
[yuzuha_怒鳴る_c]

#
两人一边争论着，一边沉默地看向神情苦涩的我。[p]

被这样盯着看，我也很困扰。[p]

只有一件事能确定――[p]

[kokutou_哀]
[vo vo="ep1/koku_0052.ogg"]
#【黒十 美鹤】
「怎么可能有这种荒唐事」[p]
[kokutou_哀_c]

[yuzuha_疑問]
[vo vo="ep1/yuzu_0045.ogg"]
#【小仓 柚叶】
「那你说那个男孩究竟消失到哪里去了？」[p]
[yuzuha_疑問_c]

[kokutou_哀]
[vo vo="ep1/koku_0053.ogg"]
#【黒十 美鹤】
「不、这我虽然不知道……」[p]
[kokutou_哀_c]

[yuzuha_笑顔]
[vo vo="ep1/yuzu_0046.ogg"]
#【小仓 柚叶】
「所以才要详细调查啊！黑十先生！」[p]
[yuzuha_笑顔_c]

#
说着，柚叶君有力地露出微笑。[p]

但到底该怎么做？[p]

[yuzuha_笑顔]
[vo vo="ep1/yuzu_0047.ogg"]
#【小仓 柚叶】
「明天直接去那家店蹲守吧！」[p]
[yuzuha_笑顔_c]

[kokutou_哀]
[vo vo="ep1/koku_0054.ogg"]
#【黒十 美鹤】
「……哈啊」[p]
[kokutou_哀_c]

#
果然要演变成麻烦事了。[p]

;BGM停止
[bgm_end3]

;テキストウィンドウ削除
[end_text]

;全キャラ削除
[allc]

;背景
[bg10 bg="white.png"]

;シーン3へ移動
[jump  storage="ep1_scene03.ks"]
[s]
