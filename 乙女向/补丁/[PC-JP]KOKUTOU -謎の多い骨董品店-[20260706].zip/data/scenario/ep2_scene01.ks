﻿;--------------------------------------------------
;■黒十　本文テキスト　ep2　招かれざる常連客
;--------------------------------------------------
;
;■ep2_scene01
;
;--------------------------------------------------
;シナリオ分岐の設定
[eval exp="f.庵マニア=0"]
[eval exp="f.怪しい=0"]

;OP
[movie storage="op2.webm" skip=true volume="40"]

;--------------------------------------------------
*010000
[savetitle text="店の外には出たくなかった"]
;-------------------------------------------------
[cm]

;BGM再生
[bgm ogg="mid_re.ogg"]

;背景
[bg30 bg="shop_kokutou2.jpg"]

;テキストウィンドウ表示
[start_text]

;SE：鍵を閉める
[se_f se="key.ogg"]

#
锁上店门。[p]

古董店『KOKUTOU』静静伫立在山丘上，俯瞰着港口。[p]

这并非一家平日里客人频繁进出的店铺。[p]

然而。[p]

;黒十衣装指定
[kokutou_c_初秋]

[kokutou_哀]
[ce cg="kokutou"]

[vo vo="ep2/koku_0001.ogg"]
#【黒十 美鹤】
「哈……虽然实在是不想出门啊」[p]

[kokutou_哀_c]
#
是啊。可能的话，我真不想踏出店门。[p]

[vo vo="ep2/koku_0002.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「更何况，还是这种假日价高的时候……」[p]

[kokutou_哀_c]
[cutbg_in bgin="cut_antique.png"]
#
想被最喜爱的古董环绕着度过时光。[p]

正因为如此才会有这家店的存在。[p]

[cutbg_out]

;全キャラ削除
[kill]
;背景　空
[bg10 bg="sky2.jpg"]

她用怨恨的目光凝视着太阳升起的蓝天。[p]

气温比前些日子低了许多，倒是变得舒适宜人。[p]

不过对于夜猫子来说，这样的日照还是有些难熬。[p]

;[kokutou_真顔]
;[ce cg="kokutou"]

[vo vo="ep2/koku_0003.ogg"]
#【黒十 美鹤】
「自言自语也无济于事呢」[p]
#

;背景　道
[bg10 bg="road.jpg"]

;SE：足音フェイドアウト
[se_f se="footsteps_out.ogg"]

他稍振作精神开始迈步。[p]

前往的目的地，是已去过数次的咖啡馆。[p]

先前，一位恋爱中的少女曾提出某个谜题。[p]

而那个谜题的舞台正是那家咖啡馆。[p]

如今与店主也已相熟，[r]　
对我来说成了能放松身心的空间。[p]

当然，与我自己的古董店相比还是无法相提并论的。[p]

平时多选在人流稀少的平日午后时分前往。[p]

不过，今天是休息日。[p]

离开最心爱的古董店，[r]　
今天特地前往咖啡馆当然有其理由。[p]

小仓柚叶。正是此人。[p]

;そういえばこの喫茶店へはじめて行くことになった理由を作ったのも[r]　彼女だったか。[p]※下記の違和感をなくすためこの地の文カット

;以下のセリフが初めて行くことになった時のセリフに見えるので、文章の順序を組み立て直すとか、対応が必要そう。

[cutbg_in bgin="cut_ceiling.png"]

[vo vo="ep2/yuzu_0001.ogg"]
#【小仓 柚叶】
「黑十先生！请明天12点在咖啡馆等我！」[p]

#
柚叶君昨天清晨把我拍醒，[r]　
只留下这句话就离开了店铺。[p]

想必是去学院前顺路过来的吧。[p]

[cutbg_in bgin="cut_bed.png"]

在睡眼朦胧中看到的柚叶君表情[r]　
记忆中仍是她一如既往的笑容。[p]

夜里醒来时，甚至怀疑那是不是场梦境。[p]

[cutbg_in bgin="cut_morning.png"]

但桌上摆着简易的早餐――按时间说该算晚餐了――[p]

[vo vo="ep2/yuzu_0002.ogg"]
看到「早上好！」的便条，[r]　
看来似乎并非梦境。[p]

[cutbg_out]
[vo vo="ep2/koku_0004.ogg"]
#【黒十 美鹤】
「要真是梦就好了呢……」[p]

#
;背景　喫茶店外観
[bg10 bg="cafe01.jpg"]

正念叨着，终于抵达了咖啡馆。[p]

隐约能嗅到咖啡的香气。[p]

[cutbg_in bgin="cut_siphon.png"]

我很中意这里的咖啡。[p]

但多次造访这家店还有别的理由。[p]

这家店唯一的店员。[p]

[cutbg_in bgin="cut_iori.png"]

有着少女般外表的少年――御手洗庵。[p]

觉得有必要重点观察她……不对是他才对。[p]

他曾自称是柚叶君娘家——小仓家一方的人。[p]

柚叶君的日常生活中未必不会发生什么不安稳的事。[p]

有钱人的想法我实在不太明白。[p]

但是，在本人毫不知情的地方，[r]　
柚叶君似乎确实正受到监视。[p]

这果然还是让我觉得不能视而不见。[p]

[cutbg_out]

[vo vo="ep2/koku_0005.ogg"]
#【黒十 美鹤】
「为什么我要做这种事……」[p]

#
这样脱口而出倒是很容易。[p]

不过更深层的理由还是决定咽下去不说为妙。[p]

;BGM停止
[bgm_end1]

;//喫茶店
[bg10 bg="cafe05.jpg"]

;//店に入るベルの音。
[se_f se="bell00.ogg"]

[vo vo="ep2/master_0001.ogg"]
#【店主】
「欢迎光临」[p]

#
;BGM再生
[bgm ogg="music.ogg"]

;//喫茶店
[bg10 bg="cafe02.jpg"]

;SE：足音フェイドアウト
[se_f se="footsteps_out.ogg"]

刚进店门，柜台里就传来店长的声音。[p]

粗略环视座位，似乎没有见到柚叶君的身影。[p]

稍迟些时候店长来到大厅。[p]

[kill]
[kokutou_微笑_c]
[ric_f cg="kokutou"]
[master_微笑]
[lec cg="master"]

[vo vo="ep2/master_0002.ogg"]
#【店主】
「哎呀，黑十先生，您来了」[p]
[master_微笑_c]

[kokutou_微笑]
[vo vo="ep2/koku_0006.ogg"]
#【黒十 美鹤】
「你好」[p]
[kokutou_微笑_c]

[vo vo="ep2/master_0003.ogg"]
[master_微笑]
#【店主】
「今天就……您一位吗？」[p]
[master_微笑_c]

[kokutou_真顔_c]
#
店长瞥了眼我身后问道。[p]

看来大家都默认我总该和柚叶君同进同出。[p]

这让我略有微词。[p]

不过事实上我外出时确实多半有柚叶君相伴。[p]

所以心有不满却也无可辩驳。[p]

[vo vo="ep2/koku_0007.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「嗯，目前暂时……听说是待会儿会来」[p]
[kokutou_真顔_c]

[vo vo="ep2/master_0004.ogg"]
[master_微笑]
#【店主】
「明白了，请随意入座」[p]

[vo vo="ep2/master_0005.ogg"]
#【店主】
「啊、咖啡可以吗？」[p]
[master_微笑_c]

[vo vo="ep2/koku_0008.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「好的，麻烦了」[p]
[kokutou_真顔_c]
#

[kill]

;//喫茶店
[bg10 bg="cafe06.jpg"]

被催促着，我在已成为固定位置的老座位坐下。[p]

可能的话真想避开阳光直射的窗边座位。[p]

落座后确认时间。[p]

时针刚过12点。[p]

[kokutou_真顔]
[ce cg="kokutou"]

[vo vo="ep2/koku_0009.ogg"]
#【黒十 美鹤】
「比柚叶君到得还早吗……」[p]
[kokutou_真顔_c]

#
以她的性格而言，迟到实属罕见。[p]

本以为她肯定早就到了。[p]

无可奈何之下决定稍作等待。[p]

想必很快就会出现吧。[p]

[vo vo="ep2/koku_0010.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「…………唔」[p]
[kokutou_疑問_c]

#
茫然环顾店内时，注意到一个违和之处。[p]

[vo vo="ep2/koku_0011.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「女装店员不在呢……」[p]
[kokutou_疑問_c]

#
本该在岗的御手洗庵不见踪影。[p]

原以为马上就会现身。[p]

和柚叶君一样，此刻他也尚未出现。[p]

;SE：足音フェイドイン
[se_f se="footsteps_in.ogg"]

[kill]
[kokutou_真顔_c]
[ric_f cg="kokutou"]
[master_微笑]
[lec cg="master"]

[vo vo="ep2/master_0006.ogg"]
#【店主】
「久等了」[p]
[master_微笑_c]

#
正思索间，店主端着盛有咖啡杯的托盘走来。[p]


;SE:カップの音
[playse  volume="100" buf="0" storage="clearing_the_table.ogg"]

咖啡竟比柚叶君先到。[p]

[vo vo="ep2/koku_0012.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「非常感谢」[p]

[vo vo="ep2/koku_0013.ogg"]
#【黒十 美鹤】
「对了有件事很好奇」[p]
[kokutou_真顔_c]

[vo vo="ep2/master_0007.ogg"]
[master_微笑]
#【店主】
「嗯，什么事？」[p]
[master_微笑_c]

[vo vo="ep2/koku_0014.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「那个…今天御手洗小姐没来吗？」[p]
[kokutou_真顔_c]

#
于是试着询问关于御手洗庵的事。[p]

[vo vo="ep2/koku_0015.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「虽然平时好像总在，休息日大概休假了吧」[p]
[kokutou_真顔_c]

[vo vo="ep2/master_0008.ogg"]
[master_哀]
#【店主】
「啊，是小庵吗……」[p]
[master_哀_c]

#
面对提问，主人低垂眉头露出了寂寞的神情。[p]

[vo vo="ep2/master_0009.ogg"]
[master_哀]
#【店主】
「平时的话连休息日也会来帮忙的……」[p]

[vo vo="ep2/master_0010.ogg"]
#【店主】
「其实这一个月左右，出勤次数减少了啊」[p]
[master_哀_c]

[vo vo="ep2/koku_0016.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「这一个月？」[p]
[kokutou_驚き_c]

#
这是件奇怪的事。[p]

明明我来这家店的时候他一定会在场。[p]

[vo vo="ep2/koku_0017.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「…………我来这家店的时候，吗」[p]
[kokutou_疑問_c]

#
心生疑惑后，我意识到了。[p]

自以为在监视别人，反而可能被对方监视了这件事。[p]

[vo vo="ep2/master_0011.ogg"]
[master_微笑]
#【店主】
「啊，黑十先生来店里时，他都会正常出勤呢」[p]

[vo vo="ep2/master_0012.ogg"]
[master_笑顔]
#【店主】
「真是惊人的巧合……呵呵」[p]

[vo vo="ep2/master_0013.ogg"]
[master_微笑]
#【店主】
「那么，今天也请您慢慢享用」[p]
[master_微笑_c]

#

[kill]
[kokutou_真顔_c]
[ce cg="kokutou"]

;SE：足音フェイドアウト
[se_f se="footsteps_out.ogg"]

店主面带微笑离开了座位。[p]

[vo vo="ep2/koku_0018.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「……如果是巧合就好了呢」[p]
[kokutou_真顔_c]

#
端起咖啡杯，送至嘴边。[p]

[vo vo="ep2/koku_0019.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「……嗯，今天也很美味」[p]
[kokutou_微笑_c]

#

;コーヒーカットイン
[cutbg_in bgin="cut_coffee.png"]

一边品味着咖啡的滋味，一边等待了几分钟。[p]

超过约定时间后，[r]　
把我叫来这里的柚叶君仍未现身。[p]

差不多该现身了吧。[p]

[cutbg_out]

;BGM停止
[bgm_end1]

;//店に入るベルの音。
[se_f se="bell00.ogg"]

正这么想着等待时，店门打开了。[p]

终于来了吗将视线转向门扉那里是熟悉的制服。[p]

[vo vo="ep2/koku_0020.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「……嗯？」[p]
[kokutou_疑問_c]

;BGM再生
[bgm ogg="kaiko.ogg"]

;SE：足音フェイドイン
[se_f se="footsteps_in.ogg"]

#
然而，前来之人却并非柚叶君。[p]

那是个肌肤苍白得骇人、留着乌黑长发的少女身影。[p]

[kill]
[kaguya_無表情_c]
[ric_f cg="kaguya"]
[master_微笑]
[lec cg="master"]

[vo vo="ep2/master_0014.ogg"]
#【店主】
「哎呀，欢迎光临」[p]
[master_微笑_c]

[vo vo="ep2/kaguya_0001.ogg"]
[kaguya_無表情]
#【黑发少女】
「你好，今天也来打扰了」[p]
[kaguya_無表情_c]

[vo vo="ep2/master_0015.ogg"]
[master_微笑]
#【店主】
「嗯，还是和往常一样的订单可以吗？」[p]
[master_微笑_c]

[vo vo="ep2/kaguya_0002.ogg"]
[kaguya_無表情]
#【黑发少女】
「不好意思，那就麻烦你了」[p]
[kaguya_無表情_c]

[vo vo="ep2/master_0016.ogg"]
[master_微笑]
#【店主】
「哪里哪里，请慢慢坐」[p]
[master_微笑_c]
#

;テキストウィンドウ削除
[end_text]

;全キャラ削除
[allc]

;背景：暗転
[bg30 bg="white.png"]

;//時間経過
[wait time=1000]

;--------------------------------------------------
*011000
[savetitle text="いつになったら来るんだか……"]
;-------------------------------------------------

;イベントＣＧ表示
[eval exp="sf.cg_ep2_1 = 1"]
[event_in event="ep2_1"]

;テキストウィンドウ表示
[start_text]

和店主交谈两三句后，她在靠窗的座位坐了下来。[p]

那件制服和柚叶君是一样的。[p]

虽然不清楚是否同年级，但应该是同一学院的学生吧。[p]

;//喫茶店
[bg10 bg="cafe06.jpg"]

;イベントＣＧ削除
[event_out]

[kokutou_哀_c]
[ce cg="kokutou"]

期待落空不禁漏出一声叹息。[p]

[vo vo="ep2/koku_0021.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「柚叶君到底要等到什么时候才来啊……」[p]
[kokutou_哀_c]

#
该不会遭遇什么事故了吧。[p]

突然涌起这种念头，心里越发不安定。[p]

[vo vo="ep2/koku_0022.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「……不不 是我担心过度了吧」[p]
[kokutou_疑問_c]

#
为了平复无意义地动摇着的心，我抿了一口咖啡。[p]

我并不喜欢等人。[p]

;テキストウィンドウ削除
[end_text]

;BGM停止
[bgm_end1]

;全キャラ削除
[allc]

;背景：暗転
[bg30 bg="white.png"]

;//時間経過
[wait time=2000]

;喫茶店店内
[bg10 bg="cafe06.jpg"]

;//店に入るベルの音。
[se_f se="bell00.ogg"]

;テキストウィンドウ表示
[start_text]

[vo vo="ep2/yuzu_0003.ogg"]
#【小仓 柚叶】
「让您久等了～！」[p]
#

;BGM再生
[bgm ogg="music.ogg"]

[kokutou_真顔_c]
[ric cg="kokutou"]

;柚葉衣装指定
[yuzuha_c_秋]

[yuzuha_微笑_c]
[lec cg="yuzuha"]

柚叶君到来的时候，[r]　
方才那位黑发少女点的餐已经全部上齐了。[p]

[vo vo="ep2/yuzu_0004.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「哎呀——抱歉抱歉，事情拖得比预期久了些」[p]
[yuzuha_微笑_c]

#
柚叶君嘿嘿笑着道歉，[r]　
但从样子来看似乎来得很匆忙。[p]

额头上微微浮着汗珠，脸颊也泛着红晕。[p]

[vo vo="ep2/koku_0023.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「其实也没关系啦」[p]

[kill]
[kokutou_真顔_c]
[ri_f cg="kokutou"]
[yuzuha_微笑_c]
[ce_f cg="yuzuha"]
[master_微笑]
[le cg="master"]

[vo vo="ep2/master_0017.ogg"]
#【店主】
「欢迎光临，小柚叶」[p]
[master_微笑_c]

#
这时店主拿着水走了过来。[p]

[vo vo="ep2/yuzu_0005.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「啊，谢谢……咕咚、咕咚……哈——！」[p]
[yuzuha_笑顔_c]

#
正值芳华的少女――而且是富豪千金[r]　
会像中年人那样喝水吗。[p]

[vo vo="ep2/yuzu_0006.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「嗯？怎么了？」[p]
[yuzuha_微笑_c]

[vo vo="ep2/koku_0024.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「不，没什么……」[p]
[kokutou_真顔_c]

[vo vo="ep2/master_0018.ogg"]
[master_微笑]
#【店主】
「小柚叶，决定好点单了吗？」[p]
[master_微笑_c]

[vo vo="ep2/yuzu_0007.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「啊，这个嘛……呃——」[p]

[vo vo="ep2/yuzu_0008.ogg"]
#【小仓 柚叶】
「黑十先生吃过饭了吗？我还饿着呢」[p]
[yuzuha_微笑_c]

#
柚叶君一边翻看菜单一边询问。[p]

但我在出门前已经简单吃过东西了。[p]

[vo vo="ep2/koku_0025.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「是啊，真不巧」[p]

[vo vo="ep2/koku_0026.ogg"]
#【黒十 美鹤】
「不过没关系，柚叶君可以在这里用午餐」[p]
[kokutou_真顔_c]

[vo vo="ep2/yuzu_0009.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「不好意思，那我要份红烩饭，[r]　
　配沙拉和咖啡的套餐」[p]
[yuzuha_微笑_c]

[vo vo="ep2/master_0019.ogg"]
[master_笑顔]
#【店主】
「明白了」[p]

[vo vo="ep2/master_0020.ogg"]
[master_微笑]
#【店主】
「咖啡是要三块糖不加奶，对吧？」[p]
[master_微笑_c]

[vo vo="ep2/yuzu_0010.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「对！」[p]
[yuzuha_笑顔_c]

#
面对店主笑眯眯的询问，柚叶君回以灿烂的笑容。[p]

[kill]
[kokutou_真顔_c]
[ric_f cg="kokutou"]
[yuzuha_微笑_c]
[lec cg="yuzuha"]

;SE：足音フェイドアウト
[se_f se="footsteps_out.ogg"]

确认完订单后，老板回到了柜台后方。[p]

[vo vo="ep2/yuzu_0011.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「呼～啊～肚子好饿啊——」[p]
[yuzuha_微笑_c]

[vo vo="ep2/koku_0027.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「今天去上课了吗？」[p]
[kokutou_真顔_c]

[vo vo="ep2/yuzu_0012.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「咦？为什么这么问？」[p]
[yuzuha_微笑_c]

[vo vo="ep2/koku_0028.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「因为你穿着制服嘛」[p]
[kokutou_真顔_c]

#
方才出现的黑发少女也穿着制服，[r]　
所以下意识这么以为了。[p]
[vo vo="ep2/yuzu_0013.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「啊这个啊，不是去上课哦」[p]

[vo vo="ep2/yuzu_0014.ogg"]
#【小仓 柚叶】
「不过确实去了趟学校呢」[p]

[vo vo="ep2/yuzu_0015.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「我们学校规定在学区范围内必须穿制服的」[p]
[yuzuha_哀_c]

[vo vo="ep2/koku_0029.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「就算没有校内事务也要穿？」[p]
[kokutou_真顔_c]

[vo vo="ep2/yuzu_0016.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「是的，[r]　
　说是要时刻保持作为本校学生的自觉」[p]
[yuzuha_哀_c]

[vo vo="ep2/koku_0030.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「哈……大小姐学校真麻烦呢……」[p]
[kokutou_哀_c]

[vo vo="ep2/yuzu_0017.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「穿制服还算好的」[p]

[vo vo="ep2/yuzu_0018.ogg"]
#【小仓 柚叶】
「真正麻烦的是学校里的人际关系」[p]

[vo vo="ep2/yuzu_0019.ogg"]
#【小仓 柚叶】
「今天还被社团招新还是什么的活动缠上了……」[p]

[vo vo="ep2/yuzu_0020.ogg"]
[yuzuha_怒]
#【小仓 柚叶】
「拒绝起来真是费劲死了！」[p]
[yuzuha_怒_c]

#

;全キャラ削除
[kill]
;喫茶店店内
[bg10 bg="cafe04.jpg"]

看来聚集着上流阶层千金们的学院里尽是麻烦事。[p]

柚叶君的抱怨似乎一时半会儿停不下来。[p]

仔细想想，[r]　
想要攀附小仓财阀千金的人恐怕不在少数。[p]

得知女儿就读的学院里有小仓家的人，[r]　
出现强迫子女交往的父母也不足为奇。[p]

听完一连串抱怨后，突然想起正事切入主题。[p]

;--------------------------------------------------
*012000
[savetitle text="プレゼントがあるんですよ"]
;-------------------------------------------------

;喫茶店店内
[bg10 bg="cafe06.jpg"]

[kokutou_真顔_c]
[ric_f cg="kokutou"]
[yuzuha_微笑_c]
[lec cg="yuzuha"]

;BGM停止
[bgm_end1]

[vo vo="ep2/koku_0031.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「说起来，今天到底有什么事？」[p]
[kokutou_真顔_c]

#
听到我的问题，柚叶君脸上浮现明朗的表情。[p]

;BGM再生
[bgm ogg="un_cafe.ogg"]

[vo vo="ep2/yuzu_0021.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「啊，对了对了！」[p]

[vo vo="ep2/yuzu_0022.ogg"]
#【小仓 柚叶】
「有礼物要送给黑十先生哦」[p]
[yuzuha_笑顔_c]

[vo vo="ep2/koku_0032.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「礼物？」[p]
[kokutou_疑問_c]

#
突如其来的词汇让我歪头不解。[p]

莫非能收到最爱的黑糖铜锣烧。[p]

但今天并非什么值得特别庆贺的日子。[p]

[vo vo="ep2/yuzu_0023.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「请收下这个」[p]
[yuzuha_笑顔_c]

;カットイン表示
[cut_in cut="cut_phone.png"]

#
柚叶君说着取出一个长方形的小盒子。[p]

[vo vo="ep2/koku_0033.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「这是什么？」[p]
[kokutou_疑問_c]

[vo vo="ep2/yuzu_0024.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「别问啦打开看看嘛，打开就知道啦」[p]
[yuzuha_笑顔_c]

;カットイン削除
[cut_out]

#
依言打开那只盒子。[p]

[vo vo="ep2/koku_0034.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「这是……手机？」[p]
[kokutou_真顔_c]

[vo vo="ep2/yuzu_0025.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「是智能手机啦！还是最新款呢！」[p]
[yuzuha_笑顔_c]

[vo vo="ep2/koku_0035.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「智能手机……最新款！？不、不需要！」[p]
[kokutou_驚き_c]

#
将放在桌上的盒子推回给柚叶君。[p]

[vo vo="ep2/yuzu_0026.ogg"]
[yuzuha_怒]
#【小仓 柚叶】
「诶！？为什么啊！？[r]　
　人家特意准备礼物送你诶！」[p]
[yuzuha_怒_c]

[vo vo="ep2/koku_0036.ogg"]
[kokutou_怒]
#【黒十 美鹤】
「明明知道我最讨厌电话的吧！？」[p]
[kokutou_怒_c]

#
没错，我对电话实在束手无策。[p]

突如其来的噪音破坏了我私人的休憩时光。[p]

更荒唐的是我还得跟一个看不见人影的人对话。[p]

对于自称家里蹲的我来说[r]　
那简直就是最糟糕的工具。[p]

[vo vo="ep2/koku_0037.ogg"]
[kokutou_怒]
#【黒十 美鹤】
「况且还是最新款电子设备……[r]　
　对经营古董店的我根本毫无用处！」[p]
[kokutou_怒_c]

[yuzuha_驚き_c]

#
听到我的话，柚叶君瞬间僵住了，但马上又摇头。[p]

[vo vo="ep2/yuzu_0027.ogg"]
[yuzuha_怒]
#【小仓 柚叶】
「哈啊？您在说什么啊！」[p]
[yuzuha_怒_c]

#
难以置信般的轻蔑神情[r]　
鲜明地浮现在那张脸上。[p]

[vo vo="ep2/yuzu_0028.ogg"]
[yuzuha_怒]
#【小仓 柚叶】
「在现代社会连智能手机都不会用怎么行！」[p]

[vo vo="ep2/yuzu_0029.ogg"]
#【小仓 柚叶】
「就是因为这样才会被社会孤立[r]　
　过着空虚的独居生活啊！」[p]
[yuzuha_怒_c]

[vo vo="ep2/koku_0038.ogg"]
[kokutou_怒]
#【黒十 美鹤】
「我的生活一点都不空虚！」[p]

[vo vo="ep2/koku_0039.ogg"]
#【黒十 美鹤】
「即使在外人眼里看来如此，我自己可是很满足的」[p]
[kokutou_怒_c]

[vo vo="ep2/yuzu_0030.ogg"]
[yuzuha_怒]
#【小仓 柚叶】
「唔唔唔唔唔……！！」[p]
[yuzuha_怒_c]

#
柚叶君明显鼓起了脸颊。[p]

就算摆出这种表情不行就是不行。[p]

[vo vo="ep2/koku_0040.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「说到底，带着那种玩意儿[r]　
　对我来说到底有什么好处？」[p]
[kokutou_疑問_c]

[yuzuha_哀]
[yuzuha_etc_頬]
;BGM停止
[bgm_end1]

[vo vo="ep2/yuzu_0031.ogg"]
#【小仓 柚叶】
「…………能说话」[p]
[yuzuha_哀_c]

[vo vo="ep2/koku_0041.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「诶？」[p]
[kokutou_驚き_c]

[vo vo="ep2/yuzu_0032.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「…………随时都能和我说话」[p]
[yuzuha_哀_c]

[vo vo="ep2/koku_0042.ogg"]
[kokutou_真顔_c]
#【黒十 美鹤】
「…………」[p]

[vo vo="ep2/yuzu_0033.ogg"]
#【小仓 柚叶】
「…………」[p]

[vo vo="ep2/koku_0043.ogg"]
#【黒十 美鹤】
「……………………」[p]

[vo vo="ep2/yuzu_0034.ogg"]
#【小仓 柚叶】
「……………………」[p]

[vo vo="ep2/koku_0044.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「害羞的话不说出来不就好了」[p]
[kokutou_哀_c]

;BGM再生
[bgm ogg="un_cafe.ogg"]

[vo vo="ep2/yuzu_0035.ogg"]
[yuzuha_怒]
#【小仓 柚叶】
「呜、呜呜呜呜吵死了！[r]　
　别废话了快点收下啦！」[p]
[yuzuha_怒_c]

#
面对泪眼汪汪的柚叶君，我再也说不出反驳的话。[p]

[vo vo="ep2/koku_0045.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「真没办法，暂时先不情愿地收下吧」[p]
[kokutou_真顔_c]

#
用不用得上――或者说会不会用才是问题。[p]

[vo vo="ep2/yuzu_0036.ogg"]
[yuzuha_笑顔]
[yuzuha_etc_off]
#【小仓 柚叶】
「呵呵呵，今后每天都会教你使用方法哦」[p]
[yuzuha_笑顔_c]

[vo vo="ep2/koku_0046.ogg"]
#【黒十 美鹤】
「…………」[p]

#
明明不用打电话也能直接见面。[p]

这句羞人的台词，我终究没能说出口。[p]

[vo vo="ep2/yuzu_0037.ogg"]
[yuzuha_疑問]
[yuzuha_etc_off]
#【小仓 柚叶】
「嗯？怎么了？」[p]
[yuzuha_疑問_c]

[vo vo="ep2/koku_0047.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「没、没什么特别的」[p]
[kokutou_微笑_c]

#
总觉得到了这个年纪再说羞耻的话未免太老成了。[p]

[vo vo="ep2/yuzu_0038.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「咦？但你好像在敷衍什么事吧？」[p]
[yuzuha_疑問_c]

[vo vo="ep2/koku_0048.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「真的没什么啦」[p]
[kokutou_微笑_c]

[vo vo="ep2/yuzu_0039.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「诶～是吗？可是――」[p]

[kill]
[kokutou_真顔_c]
[ri_f cg="kokutou"]
[yuzuha_微笑_c]
[ce_f cg="yuzuha"]
[master_微笑]
[le cg="master"]

;SE：足音フェイドイン
[se_f se="footsteps_in.ogg"]

[vo vo="ep2/master_0021.ogg"]
#【店主】
「久等了～您点的沙拉和牛肉烩饭来喽」[p]
[master_微笑_c]

#
这时，端着料理的老板出现了。[p]

;SE:カップの音
[playse  volume="100" buf="0" storage="clearing_the_table.ogg"]

多亏他来得正是时候，[r]　
总算把这个场面搪塞过去了。[p]

;テキストウィンドウ削除
[end_text]

;全キャラ削除
[allc]

;背景：暗転
[bg30 bg="white.png"]

;//時間経過
[wait time=2000]

;--------------------------------------------------
*013000
[savetitle text="やっぱり変だよ"]
;-------------------------------------------------

;喫茶店店内
[bg10 bg="cafe06.jpg"]

[kokutou_真顔_c]
[ric cg="kokutou"]
[yuzuha_疑問_c]
[lec cg="yuzuha"]

;テキストウィンドウ表示
[start_text]

[vo vo="ep2/koku_0049.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「好了，差不多该回去了」[p]
[kokutou_真顔_c]

#
我瞅准柚叶君喝完餐后咖啡的时机说道。[p]

[vo vo="ep2/yuzu_0040.ogg"]
#【小仓 柚叶】
「…………」[p]

[vo vo="ep2/koku_0050.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「柚叶君？」[p]
[kokutou_真顔_c]

#
但柚叶君正若有所思地发着呆。[p]

[vo vo="ep2/koku_0051.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「柚叶君，怎么了？肚子疼吗？」[p]
[kokutou_真顔_c]

[vo vo="ep2/yuzu_0041.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「咦？啊、不不是那样的……嗯——」[p]
[yuzuha_疑問_c]

[vo vo="ep2/koku_0052.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「如果没事的话我先回去了」[p]
[kokutou_真顔_c]

[vo vo="ep2/yuzu_0042.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「啊、说得也是[r]　
　还得给黑十先生讲解手机操作方法呢」[p]
[yuzuha_微笑_c]

[vo vo="ep2/koku_0053.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「居然真的要教啊……」[p]
[kokutou_哀_c]

[vo vo="ep2/yuzu_0043.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「这不是理所当然的吗、[r]　
　为了拿到这部手机可是等了好久呢」[p]
[yuzuha_微笑_c]

[vo vo="ep2/koku_0054.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「原来迟到是因为这个……」[p]
[kokutou_哀_c]

#
愤愤地瞪了眼收到的手机，将其塞回包装盒里。[p]

[vo vo="ep2/yuzu_0044.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「…………嗯——？」[p]
[yuzuha_疑問_c]

#
开始收拾东西时，柚叶君的表情依旧不太对劲。[p]

[vo vo="ep2/koku_0055.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「柚叶君？」[p]
[kokutou_疑問_c]

[vo vo="ep2/yuzu_0045.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「……唔……果然很奇怪啊」[p]
[yuzuha_疑問_c]

#
柚叶君轻声嘟囔着。[p]

[kokutou_真顔_c]

紧接着，柚叶君的双眸直直凝视过来。[p]

[vo vo="ep2/yuzu_0046.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「黑十先生，这个绝对有问题！」[p]
[yuzuha_疑問_c]

#
看来柚叶君的眼睛[r]　
又发现了什么不得了的谜团。[p]

不知为何产生了极其不祥的预感。[p]

[vo vo="ep2/koku_0056.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「柚叶君，我们快回――」[p]

[vo vo="ep2/yuzu_0047.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「黑十先生！」[p]
[yuzuha_疑問_c]

[kokutou_真顔_c]
#
催促的话语被本人高声打断。[p]

只见柚叶君像往常那样宣言道：[p]

[vo vo="ep2/yuzu_0048.ogg"]
[yuzuha_怒鳴る]
#【小仓 柚叶】
「可能又有新谜题从天而降啦！」[p]
[yuzuha_怒鳴る_c]

[vo vo="ep2/koku_0057.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「哈啊……真是服了」[p]
[kokutou_哀_c]

#
听到那句话，我不禁深深叹了口气。[p]


;テキストウィンドウ削除
[end_text]

;BGM停止
[bgm_end3]

;全キャラ削除
[allc]

;背景
[bg20 bg="white.png"]

;シーン2へ移動
[jump  storage="ep2_scene02.ks"]

[s]