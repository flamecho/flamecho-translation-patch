﻿;--------------------------------------------------
;■黒十　本文テキスト　ep2　招かれざる常連客
;--------------------------------------------------
*017000
[savetitle text="骨董品店への帰り道"]
;-------------------------------------------------

;
;//■ルート『来る待ち人と来ない待ち人』
;//店を出て道

#
[kill]
;背景　空
[bg10 bg="sky2.jpg"]

离开店铺返回心爱的古董店途中。[p]

高悬的太阳令人感觉比来时更加强烈了。[p]

;背景　道
[bg10 bg="road.jpg"]

[kokutou_真顔_c]
[ric_f cg="kokutou"]
[yuzuha_怒]
[lec cg="yuzuha"]

[vo vo="ep2/yuzu_0078.ogg"]
#【小仓 柚叶】
「――――就是说啊！」[p]

[vo vo="ep2/yuzu_0079.ogg"]
#【小仓 柚叶】
「拒绝多少次都换部门换人不断涌过来啊ー？」[p]
[yuzuha_怒_c]

#
在烈日下萎靡的我身旁，柚叶君仍活力十足。[p]

她从头到尾都在极力阐述拒绝社团招新有多麻烦。[p]

[vo vo="ep2/yuzu_0080.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「没想到贵族女校的社团招新[r]　
　居然这么体育系风格真是出乎意料ー」[p]
[yuzuha_哀_c]

[vo vo="ep2/koku_0093.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「毕竟谁都渴望与小仓财阀的千金交好吧」[p]
[kokutou_微笑_c]

[vo vo="ep2/yuzu_0081.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「那种人当然要拒绝啦，更别说还要在社团共处……」[p]

[vo vo="ep2/yuzu_0082.ogg"]
#【小仓 柚叶】
「他们只想和小仓家的女儿套近乎，[r]　
　根本不是想真心与我结交啊」[p]
[yuzuha_哀_c]

[vo vo="ep2/koku_0094.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「那个……」[p]
[kokutou_真顔_c]

#
确实，想必正是如此。[p]

虽然不清楚那些人具体如何接触柚叶君[r]　
毕竟未曾亲眼目睹。[p]

但以柚叶君的性格[r]　
绝不可能粗暴对待怀着真心来搭话的人。[p]

[vo vo="ep2/yuzu_0083.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「唉～真希望他们早点放弃……」[p]
[yuzuha_哀_c]

[vo vo="ep2/koku_0095.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「说的也是」[p]

[vo vo="ep2/koku_0096.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「可是，没有你感兴趣的社团吗？」[p]
[kokutou_微笑_c]

#
道听途说，柚叶君就读的学院里[r]　
应该有许多社团才对。[p]

[vo vo="ep2/koku_0097.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「我觉得至少该有一个让你在意的社团吧」[p]
[kokutou_微笑_c]

#
是个好奇心旺盛的孩子。[p]

这点毋庸置疑。[p]

[vo vo="ep2/yuzu_0084.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「嗯……这个嘛，有倒是有啦」[p]

[vo vo="ep2/yuzu_0085.ogg"]
#【小仓 柚叶】
「但应该说是还有更重要的事吧……呃——」[p]
[yuzuha_疑問_c]

#
柚叶君像日落后的向日葵般垂着头，含含糊糊地开口。[p]

然而太阳仍高悬在头顶，耀目得令人烦躁地持续照耀着。[p]

[vo vo="ep2/koku_0098.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「怎么了？」[p]
[kokutou_真顔_c]

#
用眼角余光悄悄观察着柚叶君的异常状态。[p]

[vo vo="ep2/yuzu_0086.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「因、因为还有比社团更重要的事情啦！」[p]
[yuzuha_驚き_c]

[vo vo="ep2/koku_0099.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「重要的事啊……不过抽点时间参加社团总可以吧」[p]

[vo vo="ep2/koku_0100.ogg"]
#【黒十 美鹤】
「你看，放学后不是常来找我吗」[p]
[kokutou_真顔_c]

[vo vo="ep2/yuzu_0087.ogg"]
[yuzuha_疑問]
[yuzuha_etc_頬]
#【小仓 柚叶】
「……所、所以说……这就是……重要的原因……」[p]
[yuzuha_疑問_c]

[vo vo="ep2/koku_0101.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「……嗯？柚叶君？」[p]
[kokutou_真顔_c]

#
抬起脸的柚叶君整张脸涨得通红。[p]

脚步也晃晃悠悠站不稳的样子。[p]

[vo vo="ep2/yuzu_0088.ogg"]
[yuzuha_怒鳴る]
#【小仓 柚叶】
「啊——别说这个了好吗——！」[p]

[vo vo="ep2/yuzu_0089.ogg"]
#【小仓 柚叶】
「总之我绝不会参加社团的！！」[p]
[yuzuha_怒鳴る_c]

[kokutou_微笑_c]

#
对着宣言的柚叶君苦笑自己是否太使坏了。[p]

就在这时。[p]

;BGM停止
[bgm_end1]

;//車の走る音

;BGM再生
[bgm ogg="highway.ogg"]

#
视野边缘映出一辆从远方朝这里驶来的车。[p]

确实是从远处而来，但速度比预想的更快。[p]

[kokutou_驚き_c]

察觉时它已逼近眼前。[p]

浑身因不祥预感而僵直，仿佛能听见神经噼啪作响。[p]

[vo vo="ep2/koku_0102.ogg"]
[kokutou_怒]
#【黒十 美鹤】
「柚叶君！」[p]
[kokutou_怒_c]

#
回过神时，我已将踉跄的她拽向人行道。[p]

[vo vo="ep2/yuzu_0090.ogg"]
[yuzuha_etc_off]
[yuzuha_驚き]
#【小仓 柚叶】
「……哎？」[p]

;//車が遠ざかる音
;SE：車が通り過ぎる
[se_f se="car-pass1.ogg"]

[yuzuha_驚き_c]
#
刹那间，一辆车横穿过我和柚叶君面前。[p]

应该不至于近到发生肢体接触。[p]

但瞬间吓出一身冷汗。[p]


;BGM停止
[bgm_end1]

[vo vo="ep2/yuzu_0091.ogg"]
[yuzuha_驚き]
[yuzuha_etc_頬]
#【小仓 柚叶】
「谢、谢谢您」[p]
[yuzuha_驚き_c]

;BGM再生
[bgm ogg="music.ogg"]

#
理解状况的柚叶君道谢。[p]

那声音从臂弯间传来，低头才注意到。[p]

我似乎把柚叶君紧紧搂在了怀里。[p]

[vo vo="ep2/koku_0103.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「对、对不起！我有点反应过度了！」[p]
[kokutou_微笑_c]

#
唰地松开环住柚叶君的手臂。[p]

能感觉到自己脸颊发烫。[p]

[vo vo="ep2/yuzu_0092.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「没这回事！真的帮大忙了！」[p]
[yuzuha_微笑_c]

#
柚叶君也退后一步，反复用手抚平制服裙的褶皱。[p]

[vo vo="ep2/yuzu_0093.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「我也是不够小心呢，啊哈哈」[p]
[yuzuha_笑顔_c]

#
待到看见他露出微笑的脸庞，这才总算松了口气。[p]

为了掩饰那胡乱增强的心跳，我决定动动嘴唇说话。[p]

[vo vo="ep2/koku_0104.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「说起来今天在等柚叶君的时候」[p]

[vo vo="ep2/koku_0105.ogg"]
#【黒十 美鹤】
「因为你来得太迟，我还担心是不是遇上事故了」[r]　
　稍微有点担心呢」[p]
[kokutou_微笑_c]

[vo vo="ep2/yuzu_0094.ogg"]
[yuzuha_etc_off]
[yuzuha_微笑]
#【小仓 柚叶】
「啊、原来是这么回事吗？对不起」[p]
[yuzuha_微笑_c]

[vo vo="ep2/koku_0106.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「不，只要没事就好」[p]
[kokutou_微笑_c]

;BGM停止
[bgm_end1]

#
重新迈开停驻的脚步。[p]

;BGM再生
[bgm ogg="kaiko.ogg"]

[kokutou_真顔_c]

走着走着，忽然想起方才在咖啡厅见过的黑发少女。[p]

[kokutou_哀_c]

那位少女或许也怀着和我等候柚叶君时[r]　
相同的心情吧。[p]

[vo vo="ep2/yuzu_0095.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「怎么了，表情这么寂寞」[p]
[yuzuha_哀_c]

[kokutou_真顔_c]

#
柚叶君的话语让我猛然回神。[p]

[vo vo="ep2/koku_0107.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「啊，没什么……我看起来是那样吗？」[p]
[kokutou_微笑_c]

[vo vo="ep2/yuzu_0096.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「看起来是啊」[p]

[vo vo="ep2/yuzu_0097.ogg"]
#【小仓 柚叶】
「不知怎么的，突然想起刚才咖啡厅里的黑发女生」[p]

[vo vo="ep2/yuzu_0098.ogg"]
#【小仓 柚叶】
「总觉得和那个人的表情稍微有点像呢」[p]
[yuzuha_哀_c]

#
听到柚叶君这句话，我不由止住脚步。[p]

回望通往方才那间咖啡厅的道路。[p]

[vo vo="ep2/yuzu_0099.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「黑十先生？」[p]
[yuzuha_哀_c]

[vo vo="ep2/koku_0108.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「……能来就好了呢」[p]
[kokutou_微笑_c]

[vo vo="ep2/yuzu_0100.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「诶？」[p]
[yuzuha_驚き_c]

[vo vo="ep2/koku_0109.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「那位黑发少女等待的人啊」[p]
[kokutou_微笑_c]

[vo vo="ep2/yuzu_0101.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「啊……是的，说得对」[p]
[yuzuha_微笑_c]

[vo vo="ep2/koku_0110.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「因为刚才车子的事情，[r]　
　可能不知怎的就变得有点杞人忧天了」[p]
[kokutou_微笑_c]

#
果然，比起外面还是家里更令人安心。[p]

[vo vo="ep2/yuzu_0102.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「呼呼呼，这是为总是杞人忧天的黑十先生准备的手机哦」[p]

[vo vo="ep2/yuzu_0103.ogg"]
#【小仓 柚叶】
「觉得不安的话立刻联系就好了呀！」[p]

[vo vo="ep2/yuzu_0104.ogg"]
#【小仓 柚叶】
「回去后我会好好教你使用方法的，请放心吧！」[p]
[yuzuha_笑顔_c]

#
我跟着笑着说罢就往前走的柚叶君。[p]

[vo vo="ep2/koku_0111.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「……呼，真是受不了啊」[p]
[kokutou_微笑_c]

#

;全キャラ削除
[allc]

我思考着为何那个少女没有联系要等的人。[p]

;背景　黒十骨董店
[bg10 bg="shop_kokutou2.jpg"]

直到抵达心爱的古董店后，答案仍不得而知。[p]

;テキストウィンドウ削除
[end_text]

;全キャラ削除
[allc]

;BGM停止
[bgm_end3]

;変数分岐（庵シナリオの有無）
[if exp="f.庵マニア == 1"]
[jump  storage="ep2_epilogue.ks"]
[endif]

;//終わり。
;//タイトル　『来る待ち人、来ない待ち人』
[eval exp="sf.ep2_end2 = 1"]
[bg20 bg="ep2_end2.png"]

;処理を停止します
[wa]
[wait time=1000]
[p]


;タイトル画面へ移動
[jump  storage="title_screen.ks"  target="*title"]