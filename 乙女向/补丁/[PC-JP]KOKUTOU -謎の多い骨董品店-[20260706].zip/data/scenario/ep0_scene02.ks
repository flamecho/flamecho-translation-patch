﻿;--------------------------------------------------
;■黒十　本文テキスト　ep0 懐古趣味の回顧録　
;--------------------------------------------------
;
;■ep0_scene02
;
;--------------------------------------------------
;シナリオ分岐の設定
;
;▼コレクションを見る
;　花器　f.collection_vase=1
;　メダル　f.collection_medal=1
;　リトグラフ　f.collection_lithograph=1
;　手鏡　f.collection_mirror=1
;
;
;▼詳細を見る
;　花器　f.search_vase=1
;　メダル　f.search_medal=1
;　リトグラフ　f.search_lithograph=1
;　手鏡　f.search_mirror=1
;
;--------------------------------------------------

;--------------------------------------------------
*020000
;[savetitle text="想い出"]
;--------------------------------------------------
[cm]

;//BG:骨董品店事務所
[bg10 bg="antique.jpg"]

[yuzuha_微笑_c]
[lec_f cg="yuzuha"]

[kokutou_c_夏]
[kokutou_真顔]
[ric cg="kokutou"]

[vo vo="ep0/koku_0035.ogg"]
#【黒十 美鹤】
「说起来，柚叶君一直在到处追问[r]　
　关于那幅破画的事情呢」[p]
[kokutou_真顔_c]

[vo vo="ep0/yuzuha_0030.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「啊哈哈，小时候就是特别希望有人能关注我啦」[p]

[vo vo="ep0/yuzuha_0031.ogg"]
#【小仓 柚叶】
「不过，没想到连这种事您都还记得呢」[p]

[vo vo="ep0/yuzuha_0032.ogg"]
#【小仓 柚叶】
「我还以为肯定早就被忘记了」[p]
[yuzuha_微笑_c]

#
确实已经忘记了。[p]

[vo vo="ep0/koku_0036.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「其实秋天的时候，我做了一个关于那时的梦哦」[p]
[kokutou_真顔_c]

[vo vo="ep0/yuzuha_0033.ogg"]
[yuzuha_etc_頬]
[yuzuha_驚き]
#【小仓 柚叶】
「诶！？……梦、梦里吗？」[p]


#
柚叶君的脸颊倏然染上红晕。[p]

[vo vo="ep0/yuzuha_0034.ogg"]
[yuzuha_笑顔]
;//下記の台詞は柚葉の独り言
#【小仓 柚叶】
「……哈啊～原来黑十先生也做了那时的梦呢……呵呵呵」[p]
#
[yuzuha_笑顔_c]

[kokutou_疑問_c]
对这番模样感到不解地歪着头。[p]

正想问怎么了[r]　
柚叶君却伸出双手制止了这个询问。[p]

[vo vo="ep0/yuzuha_0035.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「啊、没没没什么事！」[p]

#
;全キャラ瞬時に削除
[kill]

;BG:空
[bg10 bg="sky3.jpg"]

[vo vo="ep0/yuzuha_0036.ogg"]
#【小仓 柚叶】
「我们继续刚才的话题吧！」[p]

;BGM停止
[bgm_end3]

#
;BG:空
;BG:屋敷内・玄関ホール
[bg20 bg="entrance.jpg"]

;--------------------------------------------------
*020100
;[savetitle text="とあるリスト"]
;--------------------------------------------------

[vo vo="ep0/koku_0037.ogg"]
#【黒十 美鹤】
「嗯？」[p]
#
察觉到异常是正要从谈话室返回客房的时候。[p]

[azuha_c_夏]
[lec cg="azuha"]
[azuha_真顔]

[vo vo="ep0/azuha_0002.ogg"]
#【小仓 杏叶】
「不是一句做不到就能解决的」[p]
[azuha_真顔_c]

#
玄关大厅前传来交谈声[r]　
下意识就躲藏了起来。[p]

那里站着小仓杏叶和佣人。[p]

;BGM再生
[bgm ogg="kaiko.ogg"]

[vo vo="ep0/mob04_0001.ogg"]
#【佣人】
「非常抱歉[r]　
　原本负责调查的人突然无法前来――」[p]

[vo vo="ep0/azuha_0003.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「所以代理调查就成了你们的工作，明白吗？」[p]
[azuha_真顔_c]

[vo vo="ep0/mob04_0002.ogg"]
#【佣人】
「可、可是收藏品的数量实在太多了……」[p]

[vo vo="ep0/azuha_0004.ogg"]
[azuha_呆れ2]
#【小仓 杏叶】
「哈啊，那这份清单是干什么用的？」[p]
[azuha_呆れ2_c]

[vo vo="ep0/mob04_0003.ogg"]
#【佣人】
「但是……」[p]

#
低头谢罪的佣人手中紧攥着一份文件。[p]

从方才的对话判断，那似乎是这座宅邸内所有物品的清单。[p]

我无论如何都想亲眼看看。[p]

[azuha_真顔_c]

[kokutou_c_書生服]
[kokutou_驚き]
[ric cg="kokutou"]

[vo vo="ep0/koku_0038.ogg"]
#【黒十 美鹤】
「那个——能让我看看吗？」[p]
[kokutou_驚き_c]

#
按捺不住心情[r]　
回过神时，我已从佣人手中取过清单浏览起来。[p]

[vo vo="ep0/mob04_0004.ogg"]
#【佣人】
「喂、喂你这……！」[p]

[vo vo="ep0/koku_0039.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「噢，果然……！[r]　
　这上面记载的所有东西都在这座宅邸里吗！」[p]

[vo vo="ep0/koku_0040.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「传闻巴纳德晚年制作的陶器也在，啊啊……！[r]　
　韦奇伍德的茶具竟然收集了这么多套！」[p]

[vo vo="ep0/koku_0041.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「虽然早有耳闻，没想到竟是真的！[r]　
　我从没见过如此庞大的收藏量！」[p]

[vo vo="ep0/koku_0042.ogg"]
#【黒十 美鹤】
「哈啊啊，终于、终于能亲眼见到真品了……[r]　
　来得太值了……！」[p]

[vo vo="ep0/koku_0043.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「啊！？　古董灯具也有这么多……！？」[p]
[kokutou_驚き_c]

[vo vo="ep0/azuha_0005.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「…………这位先生」[p]
[azuha_真顔_c]

[vo vo="ep0/koku_0044.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「没想到会有这么一天……[r]　
　居然能看到不是复制品的早期雅各布森啊……！」[p]

[vo vo="ep0/azuha_0006.ogg"]
[azuha_呆れ2]
#【小仓 杏叶】
「哈啊……所以我才说收藏家们啊……」[p]
[azuha_呆れ2_c]

[vo vo="ep0/koku_0045.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「活着真是太好了…………咦！？」[p]

;杏葉消去
[hide_azuha]

[ce cg="azuha"]

[azuha_真顔_c]
#
正当沉浸在幸福感中时，突然被揪住衣领喘不过气。[p]

[kokutou_驚き_c]
被猛地拽过去后，眼前是小仓杏叶那张端正的脸。[p]

[vo vo="ep0/azuha_0007.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「你，对这些清单上的收藏品很了解吗？」[p]
[azuha_真顔_c]

[vo vo="ep0/koku_0046.ogg"]
[kokutou_哀2]
#【黒十 美鹤】
「诶？啊，那个……」[p]
[kokutou_哀2_c]

[vo vo="ep0/azuha_0008.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「比如说清单上这个，认得吗？」[p]
[azuha_真顔_c]

#
她依然揪着我的衣领抢过清单[r]　
唰地一下戳到我眼前。[p]

简直像被枪指着似的。[p]

[vo vo="ep0/azuha_0009.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「喂，快点回答我的问题」[p]
[azuha_真顔_c]

[vo vo="ep0/koku_0047.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「我我我知道的知道的……！」[p]

[vo vo="ep0/koku_0048.ogg"]
#【黒十 美鹤】
「就是刚才谈话室里挂着的[r]　
　亚历山大・米斯纳斯的油画对吧？」[p]
[kokutou_驚き_c]

#
虽然快速回答着[r]　
小仓杏叶却只是定定凝视着我的眼睛。[p]

[vo vo="ep0/koku_0049.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「那个……呃，那个……」[p]
[kokutou_哀_c]

[vo vo="ep0/azuha_0010.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「哼，倒是挺了解的嘛」[p]
[azuha_真顔_c]

[vo vo="ep0/koku_0050.ogg"]
[kokutou_哀2]
#【黒十 美鹤】
「是、是的……[r]　
　那个，毕竟想着要开古董店……还算了解……」[p]
[kokutou_哀2_c]

[vo vo="ep0/azuha_0011.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「古董店？哦～在哪儿啊？」[p]
[azuha_真顔_c]

[vo vo="ep0/koku_0051.ogg"]
[kokutou_哀2]
#【黒十 美鹤】
「啊、不 店铺还没定下来……准备近期开张……」[p]

[vo vo="ep0/koku_0052.ogg"]
#【黒十 美鹤】
「在横滨海港区看中了一处不错的房产[r]　
　但价格实在有些难以承受」[p]
[kokutou_哀2_c]

[vo vo="ep0/azuha_0012.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「……哦」[p]
[azuha_真顔_c]

#
然而这似乎构不成对话，她心不在焉地敷衍着。[p]

看来我不小心回答了根本没被问到的事。[p]

[vo vo="ep0/koku_0053.ogg"]
[kokutou_哀2]
#【黒十 美鹤】
「那个、差不多可以放开我了吧――」[p]
[kokutou_哀2_c]

[vo vo="ep0/azuha_0013.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「其实现在正在确认[r]　
　这栋宅邸里收藏品是否保存完好」[p]
[azuha_真顔_c]

#
小仓杏叶打断了我的话。[p]

[vo vo="ep0/azuha_0014.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「你刚才看到的清单就是为此准备的」[p]
[azuha_真顔_c]

[vo vo="ep0/koku_0054.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「原、原来如此……」[p]
[kokutou_哀_c]

#
先前仆人们之所以闹哄哄的[r]　
看来就是这个原因。[p]

[vo vo="ep0/azuha_0015.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「但麻烦的是，我家那个蠢佣人好像搞不清实际收藏品[r]　
　和清单上作品名的对应关系，核对工作很棘手呢」[p]

[vo vo="ep0/azuha_0016.ogg"]
#【小仓 杏叶】
「所以――」[p]
[azuha_真顔_c]

#
说到这时，她忽然嫣然一笑。[p]

反倒是我因不祥的预感绷紧了脸。[p]

[vo vo="ep0/azuha_0017.ogg"]
[azuha_悪い笑顔]
#【小仓 杏叶】
「就由你来确认这份清单上的收藏品[r]　
　是否真实存在于这栋宅邸」[p]
[azuha_悪い笑顔_c]

#
果然是这样吗。[p]

[vo vo="ep0/koku_0055.ogg"]
[kokutou_哀2]
#【黒十 美鹤】
「可是……这么大量的都要确认？」[p]
[kokutou_哀2_c]

[vo vo="ep0/azuha_0018.ogg"]
[azuha_悪い笑顔]
#【小仓 杏叶】
「嗯，我要你逐一确认每一件」[p]
[azuha_悪い笑顔_c]

#
我预定明天下午离开这座岛。[p]

如果接下这工作，恐怕会是相当繁重的体力活。[p]

[vo vo="ep0/azuha_0019.ogg"]
[azuha_悪い笑顔]
#【小仓 杏叶】
「哎呀，这不该是个坏提议呀」[p]

[vo vo="ep0/azuha_0020.ogg"]
#【小仓 杏叶】
「作为访客本来在这宅邸活动会受到时间和区域限制[r]　
　但我特准你自由参观」[p]
[azuha_悪い笑顔_c]

[vo vo="ep0/koku_0056.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「……真的吗？」[p]
[kokutou_真顔_c]

[vo vo="ep0/azuha_0021.ogg"]
[azuha_悪い笑顔]
#【小仓 杏叶】
「还不止如此」[p]

[vo vo="ep0/azuha_0022.ogg"]
#【小仓 杏叶】
「还有些从未向观光客展示的藏品」[p]

[vo vo="ep0/azuha_0023.ogg"]
#【小仓 杏叶】
「若你答应接手这件事[r]　
　自然也能见到那些吧」[p]
[azuha_悪い笑顔_c]

#
这番话对我而言极具吸引力。[p]

不如说，这种机会简直千载难逢――[r]　
不如说此生难再遇见。[p]

[vo vo="ep0/koku_0057.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「……明、明白了[r]　
　收藏品清点工作，我接受了」[p]
[kokutou_真顔_c]

[vo vo="ep0/azuha_0024.ogg"]
[azuha_微笑]
#【小仓 杏叶】
「这才像话」[p]
[azuha_微笑_c]


;杏葉消去
[hide_azuha]

[azuha_真顔_c]
[lec cg="azuha"]


#
她说着首次松开揪住我前襟的手。[p]

[vo vo="ep0/azuha_0025.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「那这份清单就交给你保管了」[p]
[azuha_真顔_c]

#
说罢她便径直从我身旁走过。[p]

看来是那种说完想说的话就立刻离开的类型。[p]

[vo vo="ep0/azuha_0026.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「啊，对了，名字……还没问呢」[p]
[azuha_真顔_c]

#
在自我介绍前，我就先被揪住了衣领。[p]

[vo vo="ep0/koku_0058.ogg"]
[kokutou_哀2]
#【黒十 美鹤】
「……黑十……黑十美鹤」[p]
[kokutou_哀2_c]

[vo vo="ep0/azuha_0027.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「黑十美鹤……哼——，这样啊」[p]

[vo vo="ep0/azuha_0028.ogg"]
#【小仓 杏叶】
「我的名字你已经知道了吧？」[p]
[azuha_真顔_c]

[vo vo="ep0/koku_0059.ogg"]
[kokutou_哀2]
#【黒十 美鹤】
「嗯，算是吧」[p]
[kokutou_哀2_c]

#
听到我的回应，她的嘴角微微放松露出笑容。[p]

[vo vo="ep0/azuha_0029.ogg"]
[azuha_微笑]
#【小仓 杏叶】
「那就好好干吧，美鹤」[p]
[azuha_微笑_c]

;杏葉消去
[hide_azuha]

[vo vo="ep0/koku_0060.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「…………突然直呼名字……？」[p]
[kokutou_驚き_c]

#
过往人生中有被女性直呼名字的经历吗？[p]

[kokutou_真顔_c]
试图瞬间回想起来 但不知该庆幸还是不幸[r]　
记忆中根本找不出半点片段。[p]

因此这种违和感实在难以估量。[p]

但不知为何那句话里[r]　
仿佛蕴含着某种能激发我干劲的东西。[p]

[vo vo="ep0/koku_0061.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「也罢，能独自鉴赏珍贵藏品，算是赚到了」[p]
[kokutou_微笑_c]

;BGM停止
[bgm_end3]

#
正当我低语时，小仓杏叶却再度抛来了早已遗忘的台词。[p]

[kokutou_驚き_c]

[vo vo="ep0/azuha_0030.ogg"]
#【小仓 杏叶】
「对了，还有一件事……[r]　
　没人说过要你独自完成吧」[p]

#
说着她指向房间深处。[p]

[kokutou_疑問_c]
虽然满腹疑问，视线还是自然地转向所指方向。[p]

[yuzuha_s_真顔_c]
[lec cg="yuzuha_s"]

;BGM再生
[bgm ogg="mid_re.ogg"]

[vo vo="ep0/yuzuha_0037.ogg"]
#【小仓 柚叶】
「…………」[p]

#
柱影里藏着个正瞪视这里的少女。[p]

[vo vo="ep0/koku_0062.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「那个……」[p]
[kokutou_疑問_c]

#
难道说居然要让那个孩子[r]　
和我一起清点收藏品？[p]

[vo vo="ep0/koku_0063.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「开玩笑的吧？」[p]
[kokutou_微笑_c]

#
她无视了苦笑着回应我的她，[r]　
单手轻轻挥了挥，便转身背对着我。[p]

[kokutou_驚き_c]

[vo vo="ep0/azuha_0031.ogg"]
#【小仓 杏叶】
「因为这个缘故，剩下的就拜托你了」[p]

[vo vo="ep0/koku_0064.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「拜托……你叫我把这个东西怎么办啊！？」[p]
[kokutou_驚き_c]

#
当我寻找时 她的身影已不在房中。[p]

[vo vo="ep0/koku_0065.ogg"]
[kokutou_呆れ]
#【黒十 美鹤】
「怎么会这样……」[p]
[kokutou_呆れ_c]

#
连名字都不知道的幼女看护工作都被强加于我。[p]

而且并非普通幼女。[p]

这个幼女可是天下闻名的小仓集团的幼女。[p]

[kokutou_哀2_c]

让我照料这种莫名其妙的生物，等同于那件事。[p]

在这种状况下还要逐一确认珍贵的收藏品[r]　
真的能做到吗。[p]

[vo vo="ep0/yuzuha_0038.ogg"]
[yuzuha_s_真顔]
#【小仓 柚叶】
「……嗯—，干嘛？」[p]
[yuzuha_s_真顔_c]

#
当时我大概是用一副吃了苦虫般的表情盯着她看吧。[p]

不知是否对我产生了怀疑，少女略带不满地向我质问。[p]

这么说来，我记得刚才关于那幅画也聊过两三句。[p]

看来语言是相通的。[p]

[vo vo="ep0/yuzuha_0039.ogg"]
[yuzuha_s_ふくれっ面]
#【小仓 柚叶】
「啊，你脸上露出了在想失礼事情的表情！」[p]
[yuzuha_s_ふくれっ面_c]

[vo vo="ep0/koku_0066.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「……没、没有这种事哦」[p]

[vo vo="ep0/koku_0067.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「比起这个，我现在必须去[r]　
　确认收藏品才行」[p]

[vo vo="ep0/koku_0068.ogg"]
#【黒十 美鹤】
「所以请你默默地跟在我后面，明白了吗？」[p]

[vo vo="ep0/koku_0069.ogg"]
#【黒十 美鹤】
「还有，绝对不要碰收藏品，懂了吗？」[p]
[kokutou_真顔_c]

[vo vo="ep0/yuzuha_0040.ogg"]
[yuzuha_s_真顔]
#【小仓 柚叶】
「……柚叶」[p]
[yuzuha_s_真顔_c]

[vo vo="ep0/koku_0070.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「诶？」[p]
[kokutou_驚き_c]

[vo vo="ep0/yuzuha_0041.ogg"]
[yuzuha_s_真顔]
#【小仓 柚叶】
「名字是小仓柚叶……君没错吧」[p]
[yuzuha_s_真顔_c]

#
凝望着这边的少女小仓柚叶说道。[p]

说起来她确实叫这个名字吗。[p]

[vo vo="ep0/koku_0071.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「……小、小仓小姐」[p]
[kokutou_哀_c]

[vo vo="ep0/yuzuha_0042.ogg"]
[yuzuha_s_真顔]
#【小仓 柚叶】
「杏叶姐姐也姓小仓哦？」[p]
[yuzuha_s_真顔_c]

[vo vo="ep0/koku_0072.ogg"]
[kokutou_哀2]
#【黒十 美鹤】
「……哈啊、柚叶……那个、酱？」[p]
[kokutou_哀2_c]

#
不对 这种称呼简直像油腻的亲戚大叔。[p]

莫名觉得自己突然老了许多 开始坐立不安。[p]

[vo vo="ep0/koku_0073.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「呃……明白了 就称呼你柚叶君吧」[p]
[kokutou_真顔_c]

#
这样听起来像是师生关系应该没问题。[p]

[vo vo="ep0/yuzuha_0043.ogg"]
[yuzuha_s_真顔]
#【小仓 柚叶】
「你呢？」[p]
[yuzuha_s_真顔_c]

[vo vo="ep0/koku_0074.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「我？啊、我吗」[p]
[kokutou_真顔_c]

#
说起来还没作自我介绍。[p]

[vo vo="ep0/koku_0075.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「黑十 黑十美鹤」[p]
[kokutou_真顔_c]

[vo vo="ep0/yuzuha_0044.ogg"]
[yuzuha_s_微笑]
#【小仓 柚叶】
「ko...ku tou…mitsu ru…科克托！」[p]
[yuzuha_s_微笑_c]

#
她指着我的脸笑了。[p]

[vo vo="ep0/yuzuha_0045.ogg"]
[yuzuha_s_笑顔]
#【小仓 柚叶】
「科克托 快来看爷爷的收藏品！」[p]
[yuzuha_s_笑顔_c]

;柚葉消去
[hide_yuzuha_s]

#
说完少女便蹦跳着走在前头。[p]

虽然疑惑这样的称呼是否妥当 却不好出言打断。[p]

[vo vo="ep0/koku_0076.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「反正只是短暂交集……怎样都无所谓吧」[p]
[kokutou_真顔_c]

;全キャラ削除
[allc]

;BGM停止
[bgm_end3]

#
;背景　屋敷の外観[p]
[bg10 bg="facade.jpg"]

;--------------------------------------------------
*020200
;[savetitle text="子供はどうも苦手です"]
;--------------------------------------------------

就这样我与小仓柚叶共同开启了[r]　
第三代首领小仓岩收藏品的检视工作。[p]

宅邸的四处零星散落着古董和艺术品。[p]

不过数量并不多。[p]

大多数收藏品似乎都保管在专用的展示室里。[p]

这样的话，在我留宿岛上的今天[r]　
也许明天之内就能完成确认工作。[p]

;BGM再生
[bgm ogg="music.ogg"]

;BG 展示室１
[bg10 bg="exhibition_room.jpg"]

[vo vo="ep0/koku_0077.ogg"]
[kokutou_真顔]
[ce cg="kokutou"]
#【黒十 美鹤】
「呼……总算是到中途节点了吧」[p]
[kokutou_真顔_c]

#
将手搭在肩上轻轻伸展脖子。[p]

最初还担心会出状况，现在看来应该能顺利解决。[p]

[vo vo="ep0/koku_0078.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「多亏有这份清单呢」[p]
[kokutou_真顔_c]

#
从小仓杏叶那里接手清单上，除了列有收藏品的名称外[r]　
还记载着每件收藏品的展示或保管位置。[p]

得益于此才不必特意去搜查[r]　
那些古董究竟存放在何处。[p]

[vo vo="ep0/koku_0079.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「不过话说回来，如果不事先了解那些古董的具体样貌[r]　
　寻找起来确实会很困难呢」[p]
#
[kokutou_真顔_c]

清单里没有实物照片。[p]

而且展示的物品上[r]　
也没有标注作品名或标题。[p]

若缺乏相关知识，恐怕很难确认[r]　
清单记载与实物收藏是否吻合吧。[p]

;黒十消去
[hide_kokutou]

[kokutou_真顔_c]
[ric_f cg="kokutou"]

[yuzuha_s_真顔]
[lec cg="yuzuha_s"]

[vo vo="ep0/yuzuha_0046.ogg"]
#【小仓 柚叶】
「科克托，结束了吗？」[p]
[yuzuha_s_真顔_c]

#
此刻出现了一位面露百无聊赖神色的少女。[p]

[vo vo="ep0/koku_0080.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「现在才要正式开始呢」[p]
[kokutou_真顔_c]


#
听到我的回答，少女沮丧地垂下肩膀。[p]

;全キャラ削除
[allc]


[kokutou_真顔_c]
[ce cg="kokutou"]

其实从刚才起就多次干扰确认工作的进行。[p]

动不动就问为什么为什么地纠缠不休[r]　
还总扯些无关的话题。[p]

[vo vo="ep0/koku_0081.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「恐怕今后也会多次来找我搭话吧……[r]　
　必须狠下心来」[p]
[kokutou_哀_c]

#
不，不需要那样的心理准备。[p]

必须以工作优先，必须尽量无视那个少女。[p]

[kokutou_真顔_c]


重新振作精神翻开清单。[p]

;BGM停止
[bgm_end3]

那么，接下来该确认哪个收藏品呢。[p]

;シーン3へ移動
[jump  storage="ep0_scene03.ks"]
[s]