﻿;--------------------------------------------------
;■黒十　本文テキスト　ep0 懐古趣味の回顧録　
;--------------------------------------------------
;
;■ep0_scene05
;
;--------------------------------------------------
;シナリオ分岐の設定
;
;▼コレクションを見る
;　花器　f.collection_vase=1
;　メダル　f.collection_medal=1
;　リトグラフ　f.collection_lithograph=1
;　手鏡　f.collection_mirror=1
;
;
;▼詳細を見る
;　花器　f.search_vase=1
;　メダル　f.search_medal=1
;　リトグラフ　f.search_lithograph=1
;　手鏡　f.search_mirror=1
;
;--------------------------------------------------


;BG:屋敷内・玄関ホール
[bg20 bg="entrance.jpg"]

;--------------------------------------------------
*050000
[savetitle text="罰ゲーム"]
;--------------------------------------------------

;BGM再生
[bgm ogg="mid_re.ogg"]

[kokutou_哀_c]
[ric cg="kokutou"]


;テキストウィンドウ表示
[start_text]

噩梦般的一天结束后的次日。[p]

虽然希望只是梦境 但昨日发生的一切都是现实。[p]

[vo vo="ep0/koku_0186.ogg"]
[kokutou_哀2_c]
#【黒十 美鹤】
「这身打扮好像在诉说那段经历……哈，真是够了」[p]
[kokutou_哀2_c]

[yuzuha_s_微笑]
[lec cg="yuzuha_s"]

[vo vo="ep0/yuzuha_0110.ogg"]
#【小仓 柚叶】
「科克托」[p]
[yuzuha_s_微笑_c]

#
回过神来时 少女已站在眼前。[p]

[vo vo="ep0/yuzuha_0111.ogg"]
[yuzuha_s_真顔]
#【小仓 柚叶】
「一脸颓相……给我打起精神来！」[p]
[yuzuha_s_真顔_c]
#
今天我也必须和这少女一起确认收藏品。[p]

[vo vo="ep0/koku_0187.ogg"]
[kokutou_呆れ]
#【黒十 美鹤】
「哈 简直像什么惩罚游戏似的……」[p]
[kokutou_呆れ_c]

[vo vo="ep0/yuzuha_0112.ogg"]
[yuzuha_s_疑問]
#【小仓 柚叶】
「嗯？惩……罚游戏……？」[p]
[yuzuha_s_疑問_c]

#
但抱怨也无法让工作提前结束。[p]

[kokutou_真顔_c]
[yuzuha_s_真顔_c]
况且小仓杏叶要求我在今日离岛前[r]　
必须完成全部确认工作。[p]

昨夜之事犹在眼前。[p]

趁还没卷入更多麻烦[r]　
不如早点离开这座岛为妙。[p]

所幸须天似乎并未察觉昨日之事。[p]

现在行动还来得及。[p]

为速战速决 我转身离开谈话室。[p]

[vo vo="ep0/yuzuha_0113.ogg"]
[yuzuha_s_疑問]
#【小仓 柚叶】
「呐科克托 惩罚游戏是什么呀？」[p]
[yuzuha_s_疑問_c]

[vo vo="ep0/koku_0188.ogg"]
[kokutou_呆れ]
#【黒十 美鹤】
「哈……所谓惩罚游戏呢」[p]
[kokutou_呆れ_c]
#

;BGM停止
[bgm_end3]

;全キャラ削除
[allc]

;//黒ベタ
[bg20 bg="black.png"]

#
衷心希望这次能平安无事地结束。[p]

;BGM再生
[bgm ogg="music.ogg"]

;背景　展示室２
[bg10 bg="exhibition_room2.jpg"]


;--------------------------------------------------
*050100
[savetitle text="なんでなんで？"]
;--------------------------------------------------


[kokutou_微笑]
[ric_f cg="kokutou"]

[yuzuha_s_真顔_c]
[lec cg="yuzuha_s"]


[vo vo="ep0/koku_0189.ogg"]
#【黒十 美鹤】
「陶艺家朔次郎制作的群青花瓶……好 这个也没问题」[p]

[vo vo="ep0/koku_0190.ogg"]
#【黒十 美鹤】
「然而每一件保存状态都好得惊人」[p]
[kokutou_微笑_c]

#
他近距离凝视着那描绘出鲜艳曲线的花瓶。[p]

[vo vo="ep0/yuzuha_0114.ogg"]
[yuzuha_s_真顔]
#【小仓 柚叶】
「盯着那种东西看会开心吗？」[p]
[yuzuha_s_真顔_c]

[vo vo="ep0/koku_0191.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「嗯，很开心喔」[p]
[kokutou_微笑_c]

[vo vo="ep0/yuzuha_0115.ogg"]
[yuzuha_s_真顔]
#【小仓 柚叶】
「怪人，科克托你真是个怪胎呢」[p]
[yuzuha_s_真顔_c]
#
看来小孩子似乎无法领会这种美好。[p]

[vo vo="ep0/koku_0192.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「啊、虽然想再多仔细观赏一会儿[r]　
　但恐怕没这个余裕呢」[p]
[kokutou_真顔_c]

#
必须赶紧确认收藏品清单才行。[p]

原本应该无缘得见的物品如今能亲眼目睹实属幸事[r]　
可惜无法从容细看却是美中不足。[p]


[kokutou_哀_c]
然而为何非得进行这种确认工作不可呢。[p]

[vo vo="ep0/koku_0193.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「而且还要小仓家的人亲自出马……未免太荒唐了吧」[p]
[kokutou_疑問_c]

[vo vo="ep0/yuzuha_0116.ogg"]
[yuzuha_s_疑問]
#【小仓 柚叶】
「荒唐……？呐、哪里荒唐了？」[p]
[yuzuha_s_疑問_c]
#

[kokutou_呆れ_c]
糟了。[p]

不知不觉把心中所想说了出来。[p]

[vo vo="ep0/yuzuha_0117.ogg"]
[yuzuha_s_微笑]
#【小仓 柚叶】
「快告诉人家哪里荒唐啦！」[p]
[yuzuha_s_微笑_c]
#
这少女一旦产生疑问[r]　
恐怕会纠缠到获得答案为止。[p]

[kokutou_哀2_c]
而且若随便搪塞谎言，不知为何总会被她识破且绝不轻饶。[p]

这种特质倒是和阿姐有几分相似。[p]

[vo vo="ep0/koku_0194.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「……没什么，只是在想为何要特地[r]　
　确认展出的收藏品是否存在罢了」[p]
[kokutou_疑問_c]

[vo vo="ep0/yuzuha_0118.ogg"]
[yuzuha_s_疑問]
#【小仓 柚叶】
「确认……」[p]
[yuzuha_s_疑問_c]

[vo vo="ep0/koku_0195.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「而且，杏叶小姐您[r]　
　的姐姐本来也不会特意过来吧」[p]
[kokutou_真顔_c]

[vo vo="ep0/yuzuha_0119.ogg"]
[yuzuha_s_疑問]
#【小仓 柚叶】
「杏叶姐姐大人？」[p]
[yuzuha_s_疑問_c]

[vo vo="ep0/koku_0196.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「肯定是这样吧」[p]

[vo vo="ep0/koku_0197.ogg"]
#【黒十 美鹤】
「说到底，就算不待在这里[r]　
　只要委托别人把结果送过来不就好了」[p]
[kokutou_真顔_c]

[vo vo="ep0/yuzuha_0120.ogg"]
[yuzuha_s_疑問_c]
#【小仓 柚叶】
「…………」[p]

#
对于我的疑问，少女像反刍般在脑海中反复思索着。[p]

随后突然恍然大悟地点了点头。[p]

[vo vo="ep0/yuzuha_0121.ogg"]
[yuzuha_s_興味]
#【小仓 柚叶】
「确实，有点奇怪……！为什么？」[p]
[yuzuha_s_興味_c]

[vo vo="ep0/koku_0198.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「不，问我也没用……」[p]
[kokutou_哀_c]

#
但越是深想就越感到毛骨悚然。[p]

结合昨天深夜的事[r]　
愈发不安起来——真的可以这样轻率地协助吗。[p]

就在我心绪不宁时，少女却采取了意料之外的行动。[p]

[vo vo="ep0/yuzuha_0122.ogg"]
[yuzuha_s_興味]
#【小仓 柚叶】
「……嗯！我去问问杏叶姐姐大人！」[p]
[yuzuha_s_興味_c]

;柚葉消去
[hide_yuzuha_s]

[vo vo="ep0/koku_0199.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「哎？等等、等一下！！？」[p]
[kokutou_驚き_c]
#

少女突然飞奔而出。[p]

我呆立原地，目送少女冲出房间。[p]

[vo vo="ep0/koku_0200.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「不行，现在不是发呆的时候……这下糟糕了！」[p]
[kokutou_驚き_c]

;BGM停止
[bgm_end3]

;全キャラ削除
[allc]

#
我也追着少女的背影跑了起来。[p]

;背景　中庭、テラス
[bg-go bg="inner_court.jpg"]

追赶少女来到中庭。[p]

本想在她遇见小仓杏叶前阻拦住她[r]　
但这个愿望显然落空了。[p]

;BGM再生
[bgm ogg="kaiko.ogg"]

[yuzuha_s_真顔]
[ric_f cg="yuzuha_s"]

[azuha_真顔_c]
[lec cg="azuha"]

[vo vo="ep0/yuzuha_0123.ogg"]
#【小仓 柚叶】
「杏叶姐姐大人，我有件事想不明白」[p]
[yuzuha_s_真顔_c]
#
当我追上时，少女已经搭完话了。[p]

[vo vo="ep0/azuha_0058.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「……请退下」[p]
[azuha_真顔_c]

[vo vo="ep0/yuzuha_0124.ogg"]
[yuzuha_s_不安]
#【小仓 柚叶】
「呜……」[p]
[yuzuha_s_不安_c]

#
但幸运的是[r]　
小仓杏叶正和其他几名佣人交涉着什么。[p]

机灵的佣人们[r]　
试图将那名寻人的少女引导至别处。[p]

回想起来，自从初次来到这座岛[r]　
少女似乎就一直受到这般对待。[p]

说不定我因此得以脱险。[p]

[vo vo="ep0/yuzuha_0125.ogg"]
[yuzuha_s_叫び]
#【小仓 柚叶】
「可、可是……这事我不明白！」[p]
[yuzuha_s_叫び_c]
#
但这次少女却紧咬着不放。[p]

[vo vo="ep0/yuzuha_0126.ogg"]
[yuzuha_s_叫び]
#【小仓 柚叶】
「为什么非要等到姐姐来了[r]　
　才确认爷爷的宝物在不在！？」[p]
[yuzuha_s_叫び_c]

[vo vo="ep0/azuha_0059.ogg"]
[azuha_怒り]
#【小仓 杏叶】
「……您说什么？」[p]
[azuha_怒り_c]

[vo vo="ep0/yuzuha_0127.ogg"]
[yuzuha_s_不安]
#【小仓 柚叶】
「爷爷的宝物，就算姐姐不来[r]　
　也能确认是否存在对吧？」[p]

[vo vo="ep0/yuzuha_0128.ogg"]
#【小仓 柚叶】
「为什么要多此一举？」[p]
[yuzuha_s_不安_c]

[vo vo="ep0/azuha_0060.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「柚叶……你……」[p]
[azuha_真顔_c]
#
这时，小仓杏叶的目光穿过少女看向了我。[p]

心想糟了，但显然为时已晚。[p]

我如同被蛇瞪视的青蛙般僵在原地动弹不得。[p]

[vo vo="ep0/azuha_0061.ogg"]
[azuha_呆れ]
#【小仓 杏叶】
「唔嗯，原来如此……[r]　
　派小孩子当使者前来，还挺有一手的嘛」[p]
[azuha_呆れ_c]
#
她用即便稍远的我也能听见的声音说道。[p]

不、并非如此，但事到如今再解释也是徒劳吧。[p]

[vo vo="ep0/azuha_0062.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「柚叶，你到那边去玩会儿」[p]
[azuha_真顔_c]

[vo vo="ep0/yuzuha_0129.ogg"]
[yuzuha_s_不安]
#【小仓 柚叶】
「哎，可是……！」[p]
[yuzuha_s_不安_c]

[vo vo="ep0/azuha_0063.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「不听姐姐的话吗？」[p]
[azuha_真顔_c]

[vo vo="ep0/yuzuha_0130.ogg"]
[yuzuha_s_ふくれっ面]
#【小仓 柚叶】
「……知道了」[p]
[yuzuha_s_ふくれっ面_c]
#
听到姐姐的话，少女垂头丧气地离开了。[p]

;BGM停止
[bgm_end3]

;全キャラ削除
[allc]

;テキストウィンドウ削除
[end_text]

;//白ベタ
[bg20 bg="white.png"]

;BGM再生
[bgm ogg="tukikage.ogg"]

;背景　書斎
[bg10 bg="study.jpg"]

;--------------------------------------------------
*050200
[savetitle text="権力者の言ノ葉"]
;--------------------------------------------------


[kokutou_真顔_c]
[ric_f cg="kokutou"]

[azuha_真顔_c]
[lec cg="azuha"]


;テキストウィンドウ表示
[start_text]

随后，我随小仓杏叶一同移步至书房。[p]

看来不仅遣散了那名少女，连佣人们也都屏退了。[p]

[vo vo="ep0/azuha_0064.ogg"]
[azuha_悪い笑顔]
#【小仓 杏叶】
「所以，究竟有什么非问不可的事呢？」[p]
[azuha_悪い笑顔_c]
[kokutou_哀2_c]

#
面对她的提问，我不仅无言以对，甚至不敢直视她的眼睛。[p]

[vo vo="ep0/azuha_0065.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「哼，罢了」[p]

[vo vo="ep0/azuha_0066.ogg"]
#【小仓 杏叶】
「为什么我要亲自前来，确认这里是否陈列、[r]　
　储藏着那些收藏品」[p]

[vo vo="ep0/azuha_0067.ogg"]
#【小仓 杏叶】
「你想确认的就是这个对吧」[p]
[azuha_真顔_c]

[vo vo="ep0/koku_0201.ogg"]
[kokutou_哀2]
#【黒十 美鹤】
「呃，这个嘛……」[p]
[kokutou_哀2_c]

[vo vo="ep0/azuha_0068.ogg"]
[azuha_悪い笑顔]
#【小仓 杏叶】
「该从何说起呢……呵，真是够呛」[p]
[azuha_悪い笑顔_c]

[vo vo="ep0/koku_0202.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「咕呶呶……」[p]
[kokutou_哀_c]

[vo vo="ep0/azuha_0069.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「你当然不会知道[r]　
　其实现在小仓家正陷入些许混乱」[p]

[vo vo="ep0/azuha_0070.ogg"]
[azuha_微笑]
#【小仓 杏叶】
「别看我这样可是相当忙碌的」[p]
[azuha_微笑_c]

#
虽说处于混乱状态，她却露出近乎愉快的笑容。[p]

[vo vo="ep0/azuha_0071.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「小仓家第三代当主的妻子，小仓红叶是在上个月去世的」[p]

[vo vo="ep0/azuha_0072.ogg"]
#【小仓 杏叶】
「我当然是[r]　
　连平时不会聚集的亲属、亲戚也都聚集起来举办了葬礼」[p]

[vo vo="ep0/azuha_0073.ogg"]
[azuha_呆れ2]
#【小仓 杏叶】
「就在那时，第三代当主小仓岩的病情也恶化了」[p]
[azuha_呆れ2_c]

[vo vo="ep0/koku_0203.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「当主也？」[p]
[kokutou_驚き_c]

[vo vo="ep0/azuha_0074.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「嗯，虽然原本就有病在身……如今已卧病不起了」[p]

[vo vo="ep0/azuha_0075.ogg"]
#【小仓 杏叶】
「主治医生坦言，恐怕时日无多了」[p]
[azuha_真顔_c]
#
她说得轻描淡写，但这应该是个相当严峻的时期吧。[p]
[kokutou_疑問_c]
但这话与她来此的缘由尚未联系上。[p]

究竟是怎么回事呢。[p]

[vo vo="ep0/azuha_0076.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「别着急，正题现在才开始」[p]

[vo vo="ep0/azuha_0077.ogg"]
#【小仓 杏叶】
「第三代……祖父持续处于几乎无意识的状态」[p]

[vo vo="ep0/azuha_0078.ogg"]
#【小仓 杏叶】
「但就在三天前，曾短暂恢复过意识」[p]

[vo vo="ep0/azuha_0079.ogg"]
#【小仓 杏叶】
「苏醒过来的祖父突然坐起身子，这样喊道」[p]
[azuha_真顔_c]

#
『――不见了！我的宝物不见了啊！』[p]

;BGM再生
[bgm ogg="tukikage_02.ogg"]

[vo vo="ep0/koku_0204.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「……宝物？」[p]
[kokutou_疑問_c]

#
对于我的提问，她点了点头。[p]

[vo vo="ep0/azuha_0080.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「祖父所说的宝物，只可能是这座岛邸里的东西」[p]

[vo vo="ep0/azuha_0081.ogg"]
#【小仓 杏叶】
「却突然声称它消失了……」[p]

[vo vo="ep0/azuha_0082.ogg"]
#【小仓 杏叶】
「这宅邸里常年有管理收藏品的佣人值守[r]　
　按理说绝不可能发生这种事」[p]

[vo vo="ep0/azuha_0083.ogg"]
#【小仓 杏叶】
「哪怕只是少了一件，也应该立刻就会有联络……」[p]

[vo vo="ep0/azuha_0084.ogg"]
#【小仓 杏叶】
「假设真的少了[r]　
　为什么连失去意识的祖父都能察觉到……」[p]
[azuha_真顔_c]

[vo vo="ep0/koku_0205.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「请、请稍等一下」[p]
[kokutou_驚き_c]
#
这过于离奇的话语让我不由出言打断。[p]

[vo vo="ep0/koku_0206.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「那么你是为了确认这件事[r]　
　才特地来到这座岛、来到宅邸的吗？」[p]
[kokutou_驚き_c]

[vo vo="ep0/azuha_0085.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「正是如此」[p]
[azuha_真顔_c]
#
小仓杏叶的发言让我愕然。[p]

听闻三代家主宝物失窃[r]　
就为此专程赶来这种事。[p]

[vo vo="ep0/koku_0207.ogg"]
[kokutou_哀2]
#【黒十 美鹤】
「怎么会……这种简直――」[p]
[kokutou_哀2_c]

[vo vo="ep0/azuha_0086.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「你是想说，这太荒谬了吧？」[p]
[azuha_真顔_c]

[kokutou_真顔_c]
#
她将视线笔直投向我。[p]

[vo vo="ep0/azuha_0087.ogg"]
[azuha_呆れ2]
#【小仓 杏叶】
「把卧病在床意识模糊的[r]　
　老人呓语当真……确实很可笑呢」[p]

[vo vo="ep0/azuha_0088.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「但这位可不是普通老人」[p]

[vo vo="ep0/azuha_0089.ogg"]
#【小仓 杏叶】
「他是小仓家第三代家主[r]　
　小仓岩……其言语必须郑重对待」[p]
[azuha_真顔_c]
#
此刻我才惊觉。[p]

她对于那位家主所言[r]　
竟没有丝毫质疑之意。[p]

那姿态宛如要让不可能化为可能。[p]

那话语仿佛要将谎言变为真实。[p]

[vo vo="ep0/azuha_0090.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「小仓家的人，可是拥有那种力量的」[p]
[azuha_真顔_c]

#
即便积累起万贯家财之人[r]　
也不可能拥有如此不可思议的力量。[p]

人类终究不过是人类。[p]

仅凭一句话就让存在的物品消失，这种事绝无可能。[p]

但这句话，我却没能对小仓杏叶说出口。[p]

[vo vo="ep0/azuha_0091.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「话就说到这里……啊，还有一件事」[p]

[vo vo="ep0/azuha_0092.ogg"]
[azuha_微笑]
#【小仓 杏叶】
「柚叶的事不准说出去[r]　
　若是走漏风声……就当自己没命了吧」[p]
[azuha_微笑_c]

#
她说得轻描淡写，却足以让人相信这是真的。[p]

那个少女自然丝毫没有四处张扬的打算。[p]

[vo vo="ep0/koku_0208.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「谁会甘心被杀啊」[p]
[kokutou_真顔_c]
#

[azuha_悪い笑顔_c]
但对我这句话，她回以冰冷的微笑。[p]

就像在说「你真蠢」般。[p]
[azuha_悪い笑顔]

[vo vo="ep0/azuha_0093.ogg"]
#【小仓 杏叶】
「要消失的未必是你，说不定是柚叶呢」[p]
[azuha_悪い笑顔_c]
#
这句话令我毛骨悚然。[p]

仿佛一桶冰水从头顶浇下。[p]

[vo vo="ep0/koku_0209.ogg"]
[kokutou_怒]
#【黒十 美鹤】
「……这玩笑可开不得」[p]
[kokutou_怒_c]
#
人类是对自身痛苦承受力极强的生物。[p]

却无法忍受因自己而施加给他人的痛苦。[p]

[vo vo="ep0/azuha_0094.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「这次真的说完了」[p]

[vo vo="ep0/azuha_0095.ogg"]
#【小仓 杏叶】
「好啦，现在马上去确认下到底有没有[r]　
　收藏品吧」[p]
[azuha_真顔_c]


;全キャラ削除
[allc]

;BGM停止
[bgm_end3]

#
;背景　黒背景
;//黒ベタ
[bg20 bg="black.png"]

;--------------------------------------------------
*050300
[savetitle text="消え失せた宝"]
;--------------------------------------------------

小仓家当主的奇异故事传入耳中，我回到收藏品的确认工作。[p]

但即便如此，那种事还是难以置信。[p]

仅因当主说出'消失了'这样的字眼[r]　
本应存在的收藏品就会不复存在什么的。[p]

说到底，要我说的话，把那种梦话当真的人才是脑子有问题。[p]

――我，本来是这么想的。[p]

;BGM再生
[bgm ogg="Yours.ogg"]

;背景　屋敷内　ホール(玄関ホール)
[bg10 bg="entrance.jpg"]


[kokutou_驚き]
[ric_f cg="kokutou"]

[yuzuha_s_真顔_c]
[lec cg="yuzuha_s"]


[vo vo="ep0/koku_0210.ogg"]
#【黒十 美鹤】
「…………不见了」[p]
[kokutou_驚き_c]

#
我在门厅呆立不动。[p]

[vo vo="ep0/yuzuha_0131.ogg"]
[yuzuha_s_疑問]
#【小仓 柚叶】
「嗯？科克托，怎么了？」[p]
[yuzuha_s_疑問_c]

#
将手中清单从头到尾再次翻阅确认。[p]

但无论确认多少次，结果都相同。[p]

[vo vo="ep0/yuzuha_0132.ogg"]
[yuzuha_s_興味]
#【小仓 柚叶】
「难道说，爷爷的宝贝不见了吗！？」[p]
[yuzuha_s_興味_c]

#
少女瞪圆双眼，仿佛充满期待。[p]

大概是注意到我困惑的神情。[p]

;全キャラ削除
[allc]


[kokutou_驚き_c]
[ri_f cg="kokutou"]

[yuzuha_s_真顔_c]
[ce cg="yuzuha_s"]

[azuha_真顔_c]
[le cg="azuha"]


附近的小仓杏叶走了过来。[p]

[vo vo="ep0/azuha_0096.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「……有收藏品消失了是吧？」[p]
[azuha_真顔_c]

[vo vo="ep0/koku_0211.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「不，但是这怎么可能……这种事」[p]
[kokutou_驚き_c]
#
像是要否定眼前发生的事，我再次翻阅清单。[p]

那姿态简直就像在逃避现实。[p]

但无论看多少次结果都不会改变。[p]

[vo vo="ep0/azuha_0097.ogg"]
[azuha_怒り]
#【小仓 杏叶】
「哈啊，黑十美鹤……！看着我的眼睛！」[p]
[azuha_怒り_c]

#
小仓杏叶叫住了动摇的我。[p]


如同被她的话语操纵般，我定定凝视着那双眸子。[p]

[vo vo="ep0/azuha_0098.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「冷静下来，然后赶紧回答我的问题」[p]
[azuha_真顔_c]
#
那句话的强制力[r]　
让我感觉自己的思绪在某种意义上回归了空白。[p]

[vo vo="ep0/koku_0212.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「好、好的……那个……」[p]
[kokutou_哀_c]
#
于是我道出了正在发生的状况。[p]

[vo vo="ep0/koku_0213.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「少了一件东西……像是画作」[p]

[kokutou_真顔]
;藤田晴嗣（ふじたはるつぐ）
[vo vo="ep0/koku_0214.ogg"]
#【黒十 美鹤】
「清单上写着藤田晴嗣的作品《秋》」[p]
[kokutou_真顔_c]
#
那是代表日本的艺术家兼画家的名字。[p]

但我并不知道那幅作品。[p]

听到我的话，她果然垂下眼帘。[p]

然而，令我震惊的不只这个原因。[p]

[vo vo="ep0/koku_0215.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「可是……只是……[r]　
　这份清单上不是也标注了收藏品的保管位置吗？」[p]
[kokutou_疑問_c]
#
我和小仓柚叶[r]　
正是根据这个来确认收藏品是否存在。[p]

据说失踪的画作也无一例外地标注着存放于『秋霖之间』。[p]

但这里出现了问题。[p]

[vo vo="ep0/koku_0216.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「找不到啊，哪里都……[r]　
　所谓的秋霖之间……这宅邸里根本不存在」[p]
[kokutou_疑問_c]

[vo vo="ep0/azuha_0099.ogg"]
[azuha_呆れ2_c]
#【小仓 杏叶】
「…………」[p]

#
听了我的话，就连小仓杏叶也陷入了沉默。[p]

[vo vo="ep0/yuzuha_0133.ogg"]
[yuzuha_s_疑問]
#【小仓 柚叶】
「……那个，也就是说……[r]　
　连房间带画一起消失了？」[p]
[yuzuha_s_疑問_c]

[vo vo="ep0/koku_0217.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「不，这种荒唐事……」[p]
[kokutou_疑問_c]

[azuha_真顔_c]

#
不可能存在。[p]

然而无法明确说出口的原因是[r]　
莫非是因为刚才从小仓杏叶那里听到的事吗。[p]

悄悄地瞥了她一眼。[p]

[azuha_ドヤ顔_c]

与我内心的动摇相反，小仓杏叶不知为何歪着嘴笑了。[p]

[vo vo="ep0/azuha_0100.ogg"]
[azuha_ドヤ顔]
#【小仓 杏叶】
「正因如此，三代目的话语才如此有分量呢」[p]
[azuha_ドヤ顔_c]

[vo vo="ep0/koku_0218.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「请住手吧……那种事，怎么可能存在」[p]
[kokutou_真顔_c]
#
仅凭一句话就能从遥远的地方[r]　
让孤岛岛邸中的一个房间消失是不可能的。[p]

反正肯定是出了什么差错。[p]

;全キャラ削除
[allc]

[suama_真顔]
[ce cg="suama"]

[vo vo="ep0/suama_0016.ogg"]
#【须天 善治】
「您这是怎么了？」[p]
[suama_真顔_c]
#
就在这时，一个佣人恰巧走了过来。[p]

他本该长年管理着这座宅邸。[p]

[vo vo="ep0/koku_0219.ogg"]
#【黒十 美鹤】
「这份清单上的房间名字……真的没错吗？」[p]

[suama_真顔]
[vo vo="ep0/suama_0017.ogg"]
#【须天 善治】
「房间的名字……？」[p]
[suama_真顔_c]

[kokutou_疑問]
[vo vo="ep0/koku_0220.ogg"]
#【黒十 美鹤】
「就是这里……这个秋霖之间指的是哪个房间？」[p]
[kokutou_疑問_c]
#
一边指着那个部分一边询问。[p]

[suama_真顔]
[vo vo="ep0/suama_0018.ogg"]
#【须天 善治】
「这个……真是奇怪了」[p]
[suama_真顔_c]

[azuha_真顔]
[vo vo="ep0/azuha_0101.ogg"]
#【小仓 杏叶】
「到底是哪里？」[p]
[azuha_真顔_c]

[suama_真顔]
[vo vo="ep0/suama_0019.ogg"]
#【须天 善治】
「秋霖之间这种房间，这宅邸里可不存在啊？」[p]
[suama_真顔_c]


;全キャラ削除
[allc]

[kokutou_驚き_c]
[ri_f cg="kokutou"]

[yuzuha_s_疑問_c]
[ce_f cg="yuzuha_s"]

[azuha_真顔_c]
[le cg="azuha"]



#
面对他的话语，我和小仓杏叶都无言以对。[p]

只有少女独自轻声嘀咕道。[p]

[vo vo="ep0/yuzuha_0134.ogg"]
[yuzuha_s_疑問]
#【小仓 柚叶】
「爷爷的宝贝，连房间一起消失掉了」[p]
#
[yuzuha_s_疑問_c]

;全キャラ削除
[allc]

;BGM停止
[bgm_end3]

;時間経過
;テキストウィンドウ削除
[end_text]

;//黒ベタ
[bg20 bg="black.png"]



;シーン6へ移動
[jump  storage="ep0_scene06.ks"]
[s]