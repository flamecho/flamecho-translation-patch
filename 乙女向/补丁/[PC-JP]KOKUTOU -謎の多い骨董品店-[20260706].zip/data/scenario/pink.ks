﻿;--------------------------------------------------
;■黒十　本文テキスト　おまけシナリオ ピンクのしおり　
;--------------------------------------------------
;
;■pink
;
;--------------------------------------------------
*010000
[savetitle text="ピンクのしおり"]
;-------------------------------------------------
[cm]

;背景　白背景
[bg20 bg="white.png"]

;SE　小鳥のさえずり（ベタな朝っぽいもの）
[se_f se="tm2_bird001.ogg"]

;背景　黒十の寝室（天井）
[bg20 bg="bedroom_0.jpg"]

;テキストウィンドウ表示

[vo vo="eppink/koku_0001.ogg"]
[start_text]
#【黒十 美鹤】
「呜……嗯嗯……」[p]
#

早晨。[p]

在小鸟的啁啾和被朝日照亮的垂闭眼睑中醒来。[p]

看来昨晚忘记关防雨窗了。[p]

;BGM再生
[bgm ogg="music.ogg"]

;背景　黒十の寝室
[bg20 bg="bedroom.jpg"]

[vo vo="eppink/koku_0002.ogg"]
#【黒十 美鹤】
「真是老套……」[p]
#
对这常见的醒转方式忍不住嘟囔。[p]

平常这个点根本不会在阳光照进卧室的时刻醒来。[p]

[bg-close]
若是睁开眼睛怕是会被阳光刺到，所以仍然紧闭着。[p]

为了不让瞌睡的头脑彻底清醒，[r]　
打算就这样睡个回笼觉。[p]

背对着阳光翻了个身，[r]　
紧紧抓住盖被。[p]

;BGM停止
[bgm_end1]

;下記台詞は柚葉の声
[vo vo="eppink/yuzuha_0001.ogg"]
#【？？？】
「……嗯」[p]
#
温暖柔软的触感和安心的气息。[p]

;下記台詞は柚葉の声
[vo vo="eppink/yuzuha_0002.ogg"]
#【？？？】
「啊……嗯嗯……」[p]
#
把缠在身上的被子当做抱枕般搂紧。[p]

那光滑的触感和糯软的柔嫩实在令人惬意。[p]

不，这未免舒服得过分了。[p]

[vo vo="eppink/koku_0003.ogg"]
#【黒十 美鹤】
「……咦？」[p]
#
情况明显不对劲。[p]

仿佛此刻抱着的根本不是被子。[p]

梦境般的舒适感反而引出了疑问。[p]

为了让沉入回笼觉的脑袋再度清醒，缓缓睁开了眼睛。[p]

[bg-open]
睁开眼皮。[p]

眼前是熟悉少女的身影。[p]

[vo vo="eppink/yuzuha_0003.ogg"]
#【小仓 柚叶】
「呼……呼……嗯呜……」[p]

;BGM再生
[bgm ogg="music.ogg"]

[vo vo="eppink/koku_0004.ogg"]
#【黒十 美鹤】
「……哈啊，什么嘛，原来是柚叶君啊……」[p]
#
对着那身影叹了口气。[p]

比起这个现在该睡回笼觉。[p]

;BGM停止　1秒
[bgm_end1]

[vo vo="eppink/koku_0005.ogg"]
#【黒十 美鹤】
「…………等等，柚叶君！？！？」[p]

;BGM再生
[bgm ogg="Peach_Sweat.ogg"]

#
猛地撑起身体顺势站了起来。[p]

那里确确实实存在着柚叶君的身影。[p]

[vo vo="eppink/koku_0006.ogg"]
#【黒十 美鹤】
「为为为、为什么柚叶君和我盖同一条被子……？」[p]
#
而且现在才发现柚叶君的衣着相当不成体统不是吗。[p]

[vo vo="eppink/koku_0007.ogg"]
#【黒十 美鹤】
「这根本不是案件级别的状况了啊！！！！」[p]

[vo vo="eppink/koku_0008.ogg"]
#【黒十 美鹤】
「到、到底发生了什么……！？」[p]
#
不，怎么可能发生过什么。[p]

[vo vo="eppink/koku_0009.ogg"]
#【黒十 美鹤】
「冷冷冷、冷静点黑十美鹤……！！」[p]

[vo vo="eppink/koku_0010.ogg"]
#【黒十 美鹤】
「什么都没发生……[r]　
　肯定绝对什么都没发生……！！」[p]
#
正 literal 抱头苦恼时，眼前的柚叶君突然蠕动起来。[p]

[vo vo="eppink/koku_0011.ogg"]
#【黒十 美鹤】
「噫呀！？」[p]
#
仅仅是柚叶君动了一下，我就后退了一步。[p]

简直像是目睹了不明真相的未确认生物。[p]

;イベントCG　起きた柚葉
;布団の上で柚葉がパンツ姿でぺたんと座り込んでいる後ろ姿（乳首が見えないくらいで横乳が見れるとか？）。[p]
;柚葉の傍らにプレゼントに使うリボンなどがある。[p]
;柚葉自身にさり気なくラッピングがされていてもいいかも？

;イベントＣＧ表示
[eval exp="sf.cg_pink_01 = 1"]
[event_in event="pink_01"]

[vo vo="eppink/yuzuha_0004.ogg"]
#【小仓 柚叶】
「嗯、嗯呜……诶？黑十先生……？」[p]
#
柚叶君慢悠悠地爬起身。[p]

她啪嗒一声坐在被褥上，睡眼惺忪地揉着眼睛。[p]

[vo vo="eppink/yuzuha_0005.ogg"]
#【小仓 柚叶】
「怎么啦～？突然这么大声……」[p]

[vo vo="eppink/koku_0012.ogg"]
#【黒十 美鹤】
「你、你问我怎……怎、怎么……」[p]

[vo vo="eppink/yuzuha_0006.ogg"]
#【小仓 柚叶】
「呜～……还……好困……啊嗯……」[p]
#
;イベントＣＧ削除
[event_out]

柚叶君小声嘀咕着，小脑袋一点一点的。[p]

看样子还没完全清醒。[p]

[vo vo="eppink/yuzuha_0007.ogg"]
#【小仓 柚叶】
「嗯……嘿嘿，是黑十先生的味道～」[p]
#
她把脸埋进紧抱在胸前的被子里。[p]

[vo vo="eppink/yuzuha_0008.ogg"]
#【小仓 柚叶】
「是……我最喜欢的、味道呢……嘿嘿♪」[p]

[vo vo="eppink/koku_0013.ogg"]
#【黒十 美鹤】
「…………」[p]
#
能感觉到自己的脸颊渐渐发烫。[p]

不对不对，现在可不是觉得她可爱的时候。[p]

脑海里警铃仍在轰鸣。[p]

但愿这并非现实中响起的警报。[p]

[vo vo="eppink/koku_0014.ogg"]
#【黒十 美鹤】
「总、总之先离开这里」[p]

[vo vo="eppink/yuzuha_0009.ogg"]
#【小仓 柚叶】
「咿？……黑十先生？嗯……要去哪里呀～？」[p]

[vo vo="eppink/yuzuha_0010.ogg"]
#【小仓 柚叶】
「不行啦……不要离开……要永远在一起哦～」[p]
#
话音未落，柚叶君咚地倒回被褥。[p]

听着这最不合时宜的梦话，我匆忙逃离了卧室。[p]

;BGM停止
[bgm_end3]

;背景　骨董品店事務所
[bg-go bg="antique.jpg"]
#
一边思索着到底发生了什么，一边暂且先来到事务所。[p]

[kokutou_c_夏]
[kokutou_驚き_c]
[ce cg="kokutou"]

在那里首次察觉到自己穿的并非睡衣而是便服。[p]

不对劲。[p]

基本上自己睡觉时应该会换衣服的。[p]

[vo vo="eppink/koku_0015.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「除了柚叶君以外……果然还是觉得有什么不对劲……嗯？」[p]
[kokutou_哀_c]

#
正陷入沉思的我视野边缘映入了可疑人物。[p]

虽然以为是自己搞错了，[r]　
但那并非看错，沙发上确实坐着那个人。[p]

;イベントCG　さゆり&庵
;リビングに行くとソファの上で稲餅さゆりがソファにあられもない姿（胸元をはだけだした状態）で座っている。[p]
;何故か鼻眼鏡をかけている（パーティー帽もかぶって顔を上に向けるようにだらしなく座っている）。[p]

;イベントＣＧ表示
[eval exp="sf.cg_pink_02 = 1"]
[event_in event="pink_02"]

[vo vo="eppink/sayuri_0001.ogg"]
#【稻饼 小百合】
「……呼……呼……」[p]

[vo vo="eppink/iori_0001.ogg"]
#【御手洗 庵】
「…………嗯、嗯呜……」[p]

;BGM再生
[bgm ogg="Peach_Sweat.ogg"]

#
稻饼小百合和御手洗庵的两人。[p]

两人又一次在沙发上以不堪入目的姿势酣睡。[p]

[vo vo="eppink/koku_0016.ogg"]
#【黒十 美鹤】
「……骗人……的吧？」[p]
#
为什么这两人会在这里？[p]

从何时起？又为何我竟不知情？[p]

总觉得头痛起来了。[p]

[vo vo="eppink/sayuri_0002.ogg"]
#【稻饼 小百合】
「……啊、不要……庵君……那里……啊啊！？」[p]
#

红着脸颊的稻饼小姐说道。[p]

究竟要做多么精准的梦[r]　
才会说出这样的梦话。[p]

不，我决不想看就是了。[p]

[vo vo="eppink/iori_0002.ogg"]
#【御手洗 庵】
「……嗯、啊啊……黑十先生……那里、不可以进去的……！！」[p]
#

已经对这边的事情连想都觉得厌烦。[p]

而且他这种情况是否属于梦话也很可疑。[p]

不自觉地用手掌抵住额头。[p]

用阵阵抽痛的脑袋整理着正在发生的事。[p]

;イベントＣＧ削除
[event_out]

[kokutou_呆れ_c]

其结果。[p]

[vo vo="eppink/koku_0017.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「……啊，是梦……？」[p]
[kokutou_微笑_c]
#
这么一想就觉得一切都能解释得通了。[p]

[vo vo="eppink/koku_0018.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「对啊……不然怎么会发生这种事……啊哈哈」[p]
[kokutou_微笑_c]
#
不禁涌出干涩的笑声。[p]

我究竟做了什么梦啊。[p]

这已经只能无奈苦笑了。[p]

[kokutou_哀2_c]
既然要做梦真想做个更正常的梦。[p]

有种说法认为[r]　
梦境会很大程度上受到自身心情的影响。[p]

方才所见的一系列景象，究竟反映出我怎样的心境。[p]

不，虽然我并不想知道。[p]

[vo vo="eppink/koku_0019.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「……既然是梦就快点醒来吧」[p]
[kokutou_哀_c]
#
即便意识到是梦境似乎也完全没有要醒来的迹象。[p]

;BGM停止
[bgm_end3]

;背景　白背景
[bg-go bg="hallway_5.jpg"]

无可奈何地离开了现场。[p]

既然如此不如去洗把脸吧，便往盥洗室走去。[p]

干脆直接从头顶浇下冷水淋浴也行。[p]

[vo vo="eppink/koku_0020.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「……嗯？」[p]
[kokutou_疑問_c]
#
平时应该开着的盥洗室门此刻却关着。[p]

也罢，反正是梦里。[p]

这种奇怪的事情也是会有的吧。[p]

一边想着这些事一边打开了通往盥洗室的门。[p]

;SE　扉を開ける音
[se_f se="opening-wooden-door-2.ogg"]

;イベントCG　着替え中の輝夜とアリス
;イベントＣＧ表示
[eval exp="sf.cg_pink_03 = 1"]
[event_in event="pink_03"]

[vo vo="eppink/koku_0021.ogg"]
#【黒十 美鹤】
「……咦？」[p]

[vo vo="eppink/alice_0001.ogg"]
#【饴宫 爱丽丝】
「……咦？」[p]

[vo vo="eppink/kaguya_0001.ogg"]
#【蓬 辉夜】
「所以司说……」[p]
#
那一刻，甚至连世界的时光都恍若停滞。[p]

相互凝视数秒。[p]

;背景　白背景
;SE　勢いよく扉を閉める音
;SE　扉を閉める音
[se_f se="slamming-wooden-door-1.ogg"]

;イベントＣＧ削除
[event_out]

;BGM再生
[bgm ogg="horror.ogg"]

我猛地关上了门。[p]

[vo vo="eppink/koku_0022.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「不……不不不、再怎么说也……刚才那不可能……绝不可能」[p]
[kokutou_驚き_c]
#
绝对是幻觉。[p]

应该说这是一场梦才对。[p]

不如说刚才那个已经确定是梦境了吧。[p]

因为那两个人根本不可能出现在这种地方。[p]

所以下次打开这扇门时，那里肯定既没有人也没有任何事发生。[p]

[vo vo="eppink/koku_0023.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「没错……本该是这样的[r]　
　这是梦，现在总该明白了吧？」[p]
[kokutou_微笑_c]

;BGM停止
[bgm_end1]

#
一边嘟囔着一边再次推开了门。[p]

;SE　扉を開ける音
[se_f se="opening-wooden-door-2.ogg"]

;イベントCG　着替え中の輝夜とアリス
;イベントＣＧ表示
[eval exp="sf.cg_pink_03 = 1"]
[event_in event="pink_03"]

果不其然，蓬辉夜和饴宫爱丽丝的身影就在那里。[p]

;BGM再生
[bgm ogg="highway.ogg"]

[vo vo="eppink/koku_0024.ogg"]
#【黒十 美鹤】
「……这是骗人的吧？」[p]


[event_in event="pink_03_2"]
[vo vo="eppink/kaguya_0002.ogg"]
#【蓬 辉夜】
「……啊……啊……咔……」[p]
#
蓬辉夜满脸通红 嘴巴一张一合地翕动着[r]　
却似乎说不出话来。[p]

与此形成鲜明对比的是[r]　
饴宫爱丽丝保持着平日的模样 露出狡黠的笑容注视这边。[p]

[vo vo="eppink/alice_0002.ogg"]
#【饴宫 爱丽丝】
「嘿，你倒是比看上去有胆量呢」[p]
#
不，这显然是个带着怒意的微笑。[p]

[vo vo="eppink/kaguya_0003.ogg"]
#【蓬 辉夜】
「哈…哈，哈哈……快给我消失！」[p]
#
此刻，蓬辉夜终于开口说话了。[p]

与此同时，[r]　
她将脚边的瓶子狠狠朝这边掷来。[p]

[vo vo="eppink/koku_0025.ogg"]
#【黒十 美鹤】
「呜呃！？」[p]
#
飞来的瓶子精准命中腹部。[p]

按着肚子慌忙关上门。[p]

;背景　白背景
;SE　扉を閉める音
[se_f se="closing-wooden-door-1.ogg"]

[kokutou_驚き_c]
;イベントＣＧ削除
[event_out]

就那样仓皇逃离了现场。[p]

这份痛楚无疑是真实的。[p]

[vo vo="eppink/kaguya_0004.ogg"]
#【蓬 辉夜】
「哈啊，哈啊，哈啊，不、不敢相信……被看到了……被看到了啊！」[p]

[vo vo="eppink/alice_0003.ogg"]
#【饴宫 爱丽丝】
「慌什么呀」[p]

[vo vo="eppink/kaguya_0005.ogg"]
#【蓬 辉夜】
「这、这还能冷静吗！」[p]

[vo vo="eppink/alice_0004.ogg"]
#【饴宫 爱丽丝】
「嘛，不是无所谓吗？又不会少块肉」[p]

[vo vo="eppink/kaguya_0006.ogg"]
#【蓬 辉夜】
「哈啊……笨蛋」[p]
#
紧闭的门后传来两人的对话声。[p]

[vo vo="eppink/koku_0026.ogg"]
[kokutou_呆れ]
#【黒十 美鹤】
「得、赶紧离开这里……」[p]
[kokutou_呆れ_c]

;背景　骨董品店事務所
[bg-go bg="antique.jpg"]
#
回到稻饼小百合和御手洗庵所在的事务所。[p]

两人仍如昏迷般沉睡着。[p]

目睹这般景象不由得喃喃自语。[p]

[vo vo="eppink/koku_0027.ogg"]
[kokutou_哀2]
#【黒十 美鹤】
「这间古董店究竟发生了什么？」[p]
[kokutou_哀2_c]
#
在自己入睡前，试图回忆昨晚的事情。[p]

但不知为何完全无法回想起来。[p]

[vo vo="eppink/koku_0028.ogg"]
[kokutou_呆れ]
#【黒十 美鹤】
「……呜……头好痛……」[p]
[kokutou_呆れ_c]
#
原本只要试图思考什么就会开始头痛。[p]

自从醒来后接连遭遇令人震惊的事，[r]　
感觉已经像这样被头痛袭击过好几次了。[p]

[kokutou_哀]
[vo vo="eppink/koku_0029.ogg"]
#【黒十 美鹤】
「总、总之先离开这个地方吧……！」[p]
[kokutou_哀_c]
#
继续待在这里还不知道会遭遇什么。[p]

决定趁着还能动的时候离开现场。[p]

;BGM停止
[bgm_end3]

;背景　骨董品店事務所
[bg-go bg="shop_kokutou.jpg"]

走出古董店后思考该前往何处。[p]

[vo vo="eppink/koku_0030.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「自称家里蹲的我能在店外感到安心的地方……」[p]
[kokutou_哀_c]
#
[allc]

;背景　空
[bg10 bg="sky.jpg"]

这个问题的答案立刻浮现在脑海。[p]

现在能让我平静下来的地方，恐怕只有那个场所了。[p]

;SE　喫茶店に入るベルの音
[se_f se="bell00.ogg"]
;背景　喫茶店
[bg10 bg="cafe02.jpg"]

[master_笑顔_c]
[lec_f cg="master"]

[kokutou_哀_c]
[ric cg="kokutou"]

[vo vo="eppink/master_0001.ogg"]
[master_笑顔]
#【店主】
「欢迎光临～……哎呀，这不是黑十先生吗」[p]
#

;BGM再生
[bgm ogg="un_cafe.ogg"]

[master_微笑_c]
来到咖啡店时，[r]　
老板像往常一样用笑容迎接我。[p]


[vo vo="eppink/koku_0031.ogg"]
[kokutou_哀2]
#【黒十 美鹤】
「您、您好……」[p]
[kokutou_哀2_c]

[master_微笑]
[vo vo="eppink/master_0002.ogg"]
#【店主】
「嗯？怎么了？脸色不太好看呢……」[p]
[master_微笑_c]

[kokutou_哀]
[vo vo="eppink/koku_0032.ogg"]
#【黒十 美鹤】
「没、没事，不必担心」[p]
[kokutou_哀_c]

[vo vo="eppink/master_0003.ogg"]
[master_微笑]
#【店主】
「这样啊……请好好放松休息吧？」[p]
[master_微笑_c]

#
说着便被引向里侧常坐的位置。[p]

;マスター削除
[hide_master]

;SE：足音フェイドアウト
[se_f se="footsteps_out.ogg"]

太好了。[p]

或许连主人自己[r]　
也开始变得有些奇怪了，这让我感到些许不安。[p]

[vo vo="eppink/koku_0033.ogg"]
[kokutou_呆れ]
#【黒十 美鹤】
「哈……但是好困扰啊……为什么会变成那样……」[p]
[kokutou_呆れ_c]
#
在坐下来的那段时间里，我只能一直抱头苦恼。[p]

在迄今为止的人生中，有过如此令人抱头苦恼的事吗？[p]

似乎有过又似乎没有。[p]

自己受苦时的事连想都不愿去想。[p]

现在总之想要冷静下来。[p]

[master_笑顔_c]
[lec_f cg="master"]

[vo vo="eppink/master_0004.ogg"]
[master_笑顔]
#【店主】
「久等了」[p]
[master_笑顔_c]
#
这时老板端着咖啡走了过来。[p]

[kokutou_真顔_c]

;SE:カップの音
[playse  buf="0" storage="clearing_the_table.ogg"]

以娴熟的动作将咖啡放置在桌面上。[p]

[vo vo="eppink/koku_0034.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「啊，谢谢」[p]
[kokutou_真顔_c]

#
我立刻将嘴唇贴近那只杯子。[p]

馥郁的香气仿佛治愈了心灵。[p]

这兼具精妙微苦与浓郁香醇的咖啡，[r]　
不知为何缓解了我头脑的疼痛。[p]

或许选择来这里果然是正确决定。[p]

就这样在我品尝咖啡的一旁，老板露出了满意的微笑。[p]

然后，轻轻地将脸凑近这边，仿佛在耳边低语。[p]

[bgm_end0]

[master_微笑]
[vo vo="eppink/master_0005.ogg"]
#【店主】
「昨天……您玩得开心吗？」[p]
[master_微笑_c]

;BGM再生
[bgm ogg="un_cafe.ogg"]

[kokutou_驚き]
[vo vo="eppink/koku_0035.ogg"]
#【黒十 美鹤】
「嗯咕……！？」[p]
[kokutou_驚き_c]
#
突然被悄声说出的那句台词让我差点把咖啡喷出来。[p]

[master_微笑]
[vo vo="eppink/master_0006.ogg"]
#【店主】
「哎呀呀」[p]
[master_微笑_c]
#
看到我这副模样的店主递来了湿毛巾。[p]

[kokutou_呆れ_c]

[vo vo="eppink/master_0007.ogg"]
[master_微笑]
#【店主】
「不要紧吗？」[p]
[master_微笑_c]

[kokutou_哀]
[vo vo="eppink/koku_0036.ogg"]
#【黒十 美鹤】
「咦、啊嗯……比起这个、刚才那话是什么意思？」[p]
[kokutou_哀_c]

[master_微笑]
[vo vo="eppink/master_0008.ogg"]
#【店主】
「什么什么意思……虽然微不足道、是我的一点心意」[p]

[vo vo="eppink/master_0009.ogg"]
#【店主】
「那个、味道如何？合您口味就再好不过了」[p]
[master_微笑_c]

[vo vo="eppink/koku_0037.ogg"]
#【黒十 美鹤】
「合……口味？这又是什么意思……」[p]
#
正欲进一步追问时，柜台深处响起了电话铃声。[p]

[master_微笑]
[vo vo="eppink/master_0010.ogg"]
#【店主】
「啊、抱歉、失陪一下」[p]
[master_微笑_c]

[kokutou_哀]
[vo vo="eppink/koku_0038.ogg"]
#【黒十 美鹤】
「嗯、请便」[p]
[kokutou_哀_c]
#

;マスター削除
[hide_master]

本想追问话中含义却时机不巧。[p]

店主的身影已消失在柜台后方。[p]

但方才店主的发言。[p]

总觉得其中暗藏着重大的线索。[p]

或者说、细想之下至今发生的每件事都是如此。[p]

虽屡屡遭遇令人惊愕的现场，[r]　
本该存在诸多蹊跷之处和疑点才对。[p]

;BGM停止　3秒
[bgm_end3]

[kokutou_呆れ]
[vo vo="eppink/koku_0039.ogg"]
#【黒十 美鹤】
「……没办法、试着整理下情报吧」[p]
[kokutou_呆れ_c]

;BGM再生
[bgm ogg="tukikage.ogg"]

[kokutou_疑問_c]

#
首先回忆今晨醒来的情形。[p]

当我醒来时柚叶君正睡在身旁。[p]

这事本身就已相当蹊跷，[r]　
但当时可有什么值得注意之处？[p]

;柚葉のイベントCGを再度表示
;イベントＣＧ表示
[event_in event="pink_01"]

仔细追忆彼时情景。[p]

意外发现自己竟能清晰回想起每个细节，也不知该骄傲还是难为情。[p]

[vo vo="eppink/koku_0040.ogg"]
#【黒十 美鹤】
「不不、比起那个……」[p]
#
我回想起挂在柚叶君身旁的那条缎带的存在。[p]

那时心慌意乱完全没顾上碰触，[r]　
那种东西平日里根本不会有的。[p]

[vo vo="eppink/koku_0041.ogg"]
#【黒十 美鹤】
「那条长长的缎带……[r]　
　简直像是用来包装礼物的玩意儿呢」[p]
#
与那条缎带一起钻进我被窝的柚叶君。[p]

这显然是异于平日的反常之处。[p]

于是我继续深入推敲。[p]

;ゆかり、庵のイベントCGを再度表示
;イベントＣＧ表示
[event_in event="pink_02"]

在客厅沙发上像昏厥般沉睡的那两人。[p]

那两人同时出现在那个地方本就蹊跷。[p]

但更奇怪的是稻饼先生的夹鼻眼镜、[r]　
以及女装店员的派对帽子。[p]

[vo vo="eppink/koku_0042.ogg"]
#【黒十 美鹤】
「没错，这两样明显都是派对上使用的物件」[p]
#
沉思间我啜饮了一口咖啡。[p]

我的思维愈发加速运转。[p]

;輝夜、アリスのイベントCGを再度表示
;イベントＣＧ表示
[event_in event="pink_03"]

对，而最关键的还是她们。[p]

她们清晨出现在我家简直难以置信。[p]

除非发生重大变故否则根本不会现身。[p]

除非被人特意召唤否则绝不可能前来。[p]

而现在最令人在意的是——[p]

当时蓬辉夜朝我扔来的那个瓶子。[p]

那毫无疑问是酒瓶。[p]

那种东西本应存在于我的古董店里，绝不该出现在家中。[p]

因为。[p]

[vo vo="eppink/koku_0043.ogg"]
#【黒十 美鹤】
「我根本一滴酒都不能喝……！」[p]

;背景　喫茶店
;イベントＣＧ削除
[event_out]

#
将这些信息汇总后，我把这些碎片逐一拼凑起来。[p]

这必定就是本次谜题的答案。[p]

缠绕在柚叶君身上的缎带。[p]

稻饼小姐的单片眼镜，以及女装店员戴过的派对帽。[p]

本应绝不会出现在古董店的蓬辉夜与饴宫爱丽丝。[p]

还有被砸碎的酒瓶。[p]

从清晨就开始纠缠的片段性失忆和这份头痛。[p]

能缓解头痛的咖啡。[p]

这种症状正是――。[p]

;BGM停止 2秒
[bgm_end2]


[kokutou_疑問]
[vo vo="eppink/koku_0044.ogg"]
#【黒十 美鹤】
「没错……宿醉……！！」[p]
[kokutou_疑問_c]
#
回想起方才店主说过的话。[p]

;回想
[event_in event="pink_001"]

[vo vo="eppink/master_0005.ogg"]
#【店主】
「昨天玩得开心吗？」[p]
#
然后。[p]

[vo vo="eppink/master_0008.ogg"]
#【店主】
「什么什么意思……虽然微不足道、是我的一点心意」[p]

[vo vo="eppink/master_0009.ogg"]
#【店主】
「那个、味道如何？合您口味就再好不过了」[p]

;//回想ここまで
[event_out]

#
将这些信息串联后得出的结论是――。[p]

;BGM再生
[bgm ogg="urara.ogg"]

[vo vo="eppink/koku_0045.ogg"]
[kokutou_呆れ]
#【黒十 美鹤】
「怎么会……」[p]
[kokutou_呆れ_c]
#
我已得出了某个答案。[p]

[master_笑顔]
[lec_f cg="master"]
[vo vo="eppink/master_0011.ogg"]
#【店主】
「抱歉，打断一下谈话」[p]
[master_笑顔_c]
#
恰在此时店主结束通话回来了。[p]

为了确认方才得出的答案，[r]　
我决定向店主提出一个问题。[p]

[vo vo="eppink/koku_0046.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「店主，能向您确认一件事吗」[p]
[kokutou_哀_c]

[vo vo="eppink/master_0012.ogg"]
[master_笑顔]
#【店主】
「嗯、可以啊，什么事呢？」[p]
[master_笑顔_c]

#
我想确认的事情是――。[p]

[vo vo="eppink/koku_0047.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「今天、是几月几号来着？」[p]
[kokutou_哀_c]

[vo vo="eppink/master_0013.ogg"]
[master_微笑]
#【店主】
「诶？今天是……」[p]
[master_微笑_c]

#
听到我的问题，店主转身确认了店里的日历。[p]

然后细心周到地连星期几一并告诉了我。[p]

听完这个，我理解了今天发生的所有谜团。[p]

于是果然、还是抱住了脑袋。[p]

[kokutou_呆れ_c]

昨晚到底发生了什么？[p]

昨天是我的――生日。[p]

[kokutou_呆れ]
[vo vo="eppink/koku_0048.ogg"]
#【黒十 美鹤】
「哈啊……」[p]
[kokutou_呆れ_c]

#
似乎我得出的答案是正确的。[p]

[kokutou_哀2_c]
意识到这点后，记忆开始逐渐苏醒。[p]

柚叶君昨天为了和大家一起庆祝我的生日，召集了那帮成员。[p]

但出乎意料的是，[r]　
庵店员带来了店主送的礼物。[p]

那居然是酒。[p]

我完全不能喝酒这件事，[r]　
大概在场所有人都不知道吧。[p]

然后我似乎、被灌酒了。[p]

不难想象派对因此泡汤了。[p]

[vo vo="eppink/koku_0049.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「……应该不至于发酒疯……但愿没有……」[p]
[kokutou_真顔_c]
#
光想想就浑身发抖。[p]

该不会说了什么奇怪的话吧。[p]

[vo vo="eppink/master_0014.ogg"]
[master_哀]
#【店主】
「呃、那个，发生什么事了吗？」[p]
[master_哀_c]

#
我趴在桌上抱着头，[r]　
店长先生担心地询问。[p]

[vo vo="eppink/koku_0050.ogg"]
[kokutou_呆れ]
#【黒十 美鹤】
「不、其实……」[p]
[kokutou_呆れ_c]
#
于是我将记忆中堪称惨剧的昨日状况悉数告知。[p]

就连总是挂着清爽笑容的店长先生[r]　
脸上也不禁浮现阴霾。[p]

[vo vo="eppink/master_0015.ogg"]
[master_哀]
#【店主】
「对、对不起！不知道你酒量这么差……！」[p]
[master_哀_c]

#
听完叙述的店长慌慌张张地道歉。[p]

[vo vo="eppink/koku_0051.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「请不要在意，店长先生您完全没有错」[p]
[kokutou_哀_c]
#
不如说整件事里根本不存在需要担责的人。[p]

这单纯只是我……不，是所有人运气太差了。[p]

[vo vo="eppink/master_0016.ogg"]
[master_哀]
#【店主】
「那个……要不要先回古董店看看？」[p]
[master_哀_c]
#
这句话让我稍作思考。[p]

但无论如何都回不去。[p]

那里现在恐怕是整座城市最危险的地方。[p]

或者说早上刚发生过那种事，实在难堪归途。[p]

[vo vo="eppink/koku_0052.ogg"]
[kokutou_呆れ]
#【黒十 美鹤】
「我心爱的古董店……竟落到这般田地……」[p]
[kokutou_呆れ_c]
#
虽颓然垂首，但确实存在一种归返之法。[p]

只要柚叶君亲自来接我就好。[p]

可这话由自己口中说出终觉不妥。[p]

[vo vo="eppink/master_0017.ogg"]
[master_笑顔]
#【店主】
「啊、哈哈哈……真是伤脑筋呢……啊」[p]
[master_微笑]
#
就在那时，店主望着店外似乎察觉到了什么。[p]

[vo vo="eppink/master_0018.ogg"]
#【店主】
「呵呵呵，看来没有我出场的必要了呢」[p]
[master_微笑_c]

[vo vo="eppink/koku_0053.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「您这话是什么意思？」[p]
[kokutou_疑問_c]
#
;マスター消去
[hide_master]
对我的问题只回以微笑后，[r]　
店主便消失在柜台后方。[p]

;SE：ベルの音
[se_f se="bell00.ogg"]

正思索着其中含义时，店门铃响起。[p]

[bg10 bg="cafe06.jpg"]
我条件反射地看向入口。[p]



;柚葉衣装指定
[yuzuha_c_私服]

[yuzuha_微笑_c]
[lec cg="yuzuha"]

眼前是熟悉少女的身影。[p]

[vo vo="eppink/yuzuha_0011.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「啊，黑十先生，果然在这里！」[p]
[yuzuha_微笑_c]
#
或许是跑着过来的，她的脸颊微微泛红。[p]

柚叶君立即朝我这边跑来。[p]

[vo vo="eppink/koku_0054.ogg"]
[kokutou_哀2]
#【黒十 美鹤】
「呃、嗯、这个嘛……」[p]
[kokutou_哀2_c]
#
我的回答莫名变得语无伦次。[p]

也难怪如此。[p]

毕竟今早发生了那样的事。[p]

[vo vo="eppink/yuzuha_0012.ogg"]
[yuzuha_微笑]
[yuzuha_etc_頬]
#【小仓 柚叶】
「啊……那个……嗯……」[p]
[yuzuha_微笑_c]
#
看到我的反应，柚叶君的脸越发通红。[p]

看来她也回想起了今早的事。[p]

[vo vo="eppink/koku_0055.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「对……对不起……」[p]
[kokutou_哀_c]

[vo vo="eppink/yuzuha_0013.ogg"]

[yuzuha_驚き]
#【小仓 柚叶】
「不不！请不要道歉！错在我这边！」[p]

[vo vo="eppink/yuzuha_0014.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「我才更应该道歉！」[p]
[yuzuha_哀_c]

#
柚叶君也像是顾虑着我般连连道歉。[p]

[yuzuha_etc_off]　
[vo vo="eppink/yuzuha_0015.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「说到底是我引起的，真的没事的！」[p]
[yuzuha_微笑_c]

[vo vo="eppink/koku_0056.ogg"]
[kokutou_呆れ]
#【黒十 美鹤】
「可是……今早的事……」[p]
[kokutou_呆れ_c]

[vo vo="eppink/yuzuha_0016.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「啊、那都是我擅自做出的举动！」[p]

[vo vo="eppink/yuzuha_0017.ogg"]
[yuzuha_etc_頬]
[yuzuha_哀]
#【小仓 柚叶】
「那个……我算是礼物、之类的……？」[p]

[vo vo="eppink/yuzuha_0018_2.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「总、总之我完全不在意啦！」[p]
[yuzuha_驚き_c]
#
既然她都说到这个份上了，[r]　
我们也不好再继续追究这件事。[p]

不过，还有件事让我放心不下。[p]


[yuzuha_etc_off]　
[yuzuha_微笑_c]
[vo vo="eppink/koku_0057.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「那个……柚叶君为什么来这里呢？」[p]
[kokutou_哀_c]

[vo vo="eppink/yuzuha_0018.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「咦？啊，因为黑十先生在那情况下[r]　
　除了古董店外能去的地方也就这儿了」[p]
[yuzuha_笑顔_c]

[vo vo="eppink/koku_0058.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「不，不是这个意思……我是想问为什么你会来找我」[p]
[kokutou_真顔_c]

[vo vo="eppink/yuzuha_0019.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「这是因为，我觉得黑十先生一个人很难回去吧」[p]

[yuzuha_etc_頬]
[yuzuha_微笑]
[vo vo="eppink/yuzuha_0020.ogg"]
#【小仓 柚叶】
「而且……好像还发生了不少其他事……啊哈哈」[p]

[yuzuha_etc_off]　
[yuzuha_笑顔]
[vo vo="eppink/yuzuha_0021.ogg"]
#【小仓 柚叶】
「啊，顺便说这边骚动已经平息得差不多了哦」[p]
[yuzuha_笑顔_c]

[vo vo="eppink/koku_0059.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「……真的吗？大家不是都很生气吗？」[p]
[kokutou_哀_c]

[vo vo="eppink/yuzuha_0022.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「没有没有，他们反而好像觉得很抱歉呢！」[p]

[vo vo="eppink/yuzuha_0023.ogg"]
#【小仓 柚叶】
「所以我才主动过来接您」[p]

[vo vo="eppink/yuzuha_0024.ogg"]
#【小仓 柚叶】
「这样回去就不会尴尬了吧？」[p]

[yuzuha_笑顔]
[vo vo="eppink/yuzuha_0025.ogg"]
#【小仓 柚叶】
「所以您看，我们这就一起回去吧」[p]
[yuzuha_笑顔_c]
#
说着柚叶君牵起我的手。[p]

[vo vo="eppink/koku_0060.ogg"]
[kokutou_哀2]
#【黒十 美鹤】
「可是……」[p]
[kokutou_哀2_c]

[vo vo="eppink/yuzuha_0026.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「好啦好啦，这种事情就是要趁势而为嘛」[p]

[vo vo="eppink/yuzuha_0027.ogg"]
#【小仓 柚叶】
「大家也都等着黑十先生回去呢」[p]
[yuzuha_微笑_c]
#
[allc]
被半拉着朝出口走去。[p]

但我明明还没结账才对。[p]

这么想着，轻轻回头一瞥。[p]

[bg5 bg="cafe02.jpg"]
[master_笑顔]
[ce cg="master"]
[vo vo="eppink/master_0019.ogg"]
#【店主】
「呵呵，随时欢迎您再次光临」[p]
[master_笑顔_c]
#
只见店长挂着亲切的笑容，正朝这边挥手。[p]

看来就这样直接离店也没有问题。[p]
[allc]

;SE　店を出るベルの音
[se_f se="bell00.ogg"]

;背景　喫茶店前
[bg10 bg="cafe01.jpg"]

[yuzuha_微笑_c]
[lec_f cg="yuzuha"]
[kokutou_哀_c]
[ric cg="kokutou"]

被柚叶君拉着走出咖啡店。[p]

最终就这样踏上了归途。[p]

[vo vo="eppink/yuzuha_0028.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「好啦，我们回家吧～！」[p]
[yuzuha_笑顔_c]

[vo vo="eppink/koku_0061.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「……好好好」[p]
[kokutou_哀_c]
#
既然能顺利回去，那倒也没什么问题。[p]

不如说正合我意。[p]

然而。[p]

[vo vo="eppink/koku_0062.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「……您是怎么察觉到的？」[p]
[kokutou_真顔_c]
#
我开口问道。[p]

[vo vo="eppink/yuzuha_0029.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「诶？指什么事呢？」[p]
[yuzuha_微笑_c]

[vo vo="eppink/koku_0063.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「就是那个……看出我似乎难以独自回去」[p]

[vo vo="eppink/koku_0064.ogg"]
[kokutou_呆れ]
#【黒十 美鹤】
「还有……唔……」[p]
[kokutou_呆れ_c]
#
以及，若不是柚叶君像这样来接我[r]　
可能就回不去了这件事。[p]

[vo vo="eppink/koku_0065.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「为什么……会知道呢？」[p]
[kokutou_真顔_c]
#
提问时突然意识到，现在和平时立场相反了。[p]

而她似乎也有同样感受，[p]

[vo vo="eppink/yuzuha_0030.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「总觉得和平时反过来了呢」[p]
[yuzuha_笑顔_c]
#
看着眉眼弯弯的柚叶君，我也微微笑了起来。[p]

[vo vo="eppink/yuzuha_0031.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「唔……谁知道呢——」[p]
[yuzuha_疑問_c]
#
稍微思考似地歪着头，[r]　
但很快柚叶君又恢复笑容回答道。[p]

[vo vo="eppink/yuzuha_0032.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「……硬要说的话，因为是黑十先生的事情！」[p]
[yuzuha_笑顔_c]

[vo vo="eppink/koku_0066.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「诶？」[p]
[kokutou_驚き_c]

[vo vo="eppink/yuzuha_0033.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「因为是黑十先生的事情，所以我才明白的」[p]
[yuzuha_笑顔_c]
#
柚叶君给出的答案，既没有任何推测也毫无道理可言。[p]

[vo vo="eppink/koku_0067.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「…………」[p]
[kokutou_真顔_c]
#
但是，正因如此。[p]

[kokutou_微笑_c]
我什么都说不出来。[p]

[allc]

;背景　空
[bg10 bg="sky2.jpg"]

不，或者说根本不需要任何反驳的话语。[p]

只要柚叶君在那里笑着就够了。[p]

;背景　道
[bg10 bg="road.jpg"]

[yuzuha_微笑_c]
[lec_f cg="yuzuha"]
[kokutou_哀_c]
[ric cg="kokutou"]

两人并肩朝着古董店走去。[p]

沿途的街道上，我向柚叶君讲述了刚才的事情。[p]

[vo vo="eppink/yuzuha_0034.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「……也就是说，黑十先生完全不记得昨天的事了呢」[p]
[yuzuha_哀_c]

[vo vo="eppink/koku_0068.ogg"]
[kokutou_呆れ]
#【黒十 美鹤】
「是啊，完全不记得」[p]
[kokutou_呆れ_c]
#
酒的力量真是可怕。[p]

[vo vo="eppink/yuzuha_0035.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「这样啊……真是可惜呢，[r]　
　明明那么开心的」[p]

[vo vo="eppink/yuzuha_0036.ogg"]
#【小仓 柚叶】
「虽然确实很折腾人……不过，嗯，这样啊……」[p]
[yuzuha_哀_c]
#
说罢，柚叶君陷入了沉思。[p]

过了一会儿，她突然用力点了点头。[p]

[vo vo="eppink/yuzuha_0037.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「嗯！决定了！」[p]

[kokutou_驚き_c]

[vo vo="eppink/yuzuha_0038.ogg"]
#【小仓 柚叶】
「黑十先生！今天我们再来办生日派对吧！」[p]
[yuzuha_笑顔_c]
#
这个提议让我有些惊讶。[p]

[vo vo="eppink/koku_0069.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「但、但是生日应该是昨天吧？」[p]
[kokutou_驚き_c]
#
尽管当事人自己并不记得，[r]　
聚集的成员们昨天也开了派对。[p]

总觉得似乎有点勉强。[p]

[vo vo="eppink/koku_0070.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「没关系的……给大家添麻烦了」[p]

[vo vo="eppink/koku_0071.ogg"]
#【黒十 美鹤】
「……而且，也不是值得特意庆祝的年纪了……」[p]
[kokutou_哀_c]

[vo vo="eppink/yuzuha_0039.ogg"]
[yuzuha_怒]
#【小仓 柚叶】
「您这说的是什么话！」[p]
[yuzuha_怒_c]
#
柚叶君蹙起眉头，像要较真似地说道。[p]

[vo vo="eppink/yuzuha_0040.ogg"]
[yuzuha_怒]
#【小仓 柚叶】
「这可是每年只有一次的生日啊！[r]　
　必须成为快乐的回忆才行！」[p]
[yuzuha_怒_c]

[vo vo="eppink/koku_0072.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「是这样吗……」[p]
[kokutou_哀_c]

[vo vo="eppink/yuzuha_0041.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「就是这样的！」[p]
[yuzuha_笑顔_c]
#
刚以为她生气了，转眼又恢复了笑容。[p]

柚叶君总是这样喜怒无常。[p]

[vo vo="eppink/yuzuha_0042.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「嘿嘿，那就再来一次！」[p]
[yuzuha_笑顔_c]
#
说着柚叶君向前小跑了几步。[p]

在我面前转身时，她脸上绽放出灿烂的笑容。[p]

;イベントCG　柚葉の満面の笑み
;イベントＣＧ表示
[eval exp="sf.cg_pink_04 = 1"]
[event_in event="pink_04"]

;//白ベタ
[bg20 bg="white.png"]

[vo vo="eppink/yuzuha_0043.ogg"]
#【小仓 柚叶】
「生日快乐，黑十先生！」[p]

[vo vo="eppink/koku_0073.ogg"]
#【黒十 美鹤】
「…………」[p]
#
柚叶君的话语让我愣住了。[p]



[vo vo="eppink/yuzuha_0044.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「咦？怎么了？」[p]
[yuzuha_笑顔_c]

[vo vo="eppink/koku_0074.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「……没什么……只是……」[p]

[vo vo="eppink/koku_0075.ogg"]
#【黒十 美鹤】
「呵呵……谢谢你」[p]
[kokutou_微笑_c]

#
若是能看到这般景象。[p]

或许变老也不是什么坏事。[p]


;全キャラ瞬時に削除
[kill]



;テキストウィンドウ削除
[end_text]


;BGM停止
[bgm_end3]


;イベントＣＧ削除
[event_out_end]

;エンド獲得フラグ
[eval exp="sf.ep_pink = 1"]

;おわり

;タイトル画面へ移動
[jump  storage="title_screen.ks"  target="*title"]

[s]






