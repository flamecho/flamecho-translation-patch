﻿;--------------------------------------------------
;■黒十　本文テキスト　ep4　鐘塔の幽霊
;--------------------------------------------------
;
;■ep4_scene04
;
;--------------------------------------------------
*040000
[savetitle text="自己紹介"]
;--------------------------------------------------

;BGM再生
[bgm ogg="mid_re.ogg"]

;//背景：礼拝堂２（数パターン欲しい）
[bg20 bg="chapel_room_02.jpg"]

;テキストウィンドウ表示
[start_text]


;//司・輝夜・アリス


;アリス衣装指定
[alice_c_冬]

[kaguya_無表情_c]
[ric_f cg="kaguya"]

[tukasa_笑顔]
[lec cg="tukasa"]

[vo vo="ep4/hagino_0021.ogg"]
#【萩乃司】
「啊—、知道知道，[r]　
　就是坡道上那家古董店，你是店长对吧」[p]

[vo vo="ep4/kaguya_0025.ogg"]
[kaguya_無表情]
#【蓬 辉夜】
「嘿—，这样啊」[p]
[kaguya_無表情_c]

#
草草结束自我介绍后，肩头莫名轻松了些。[p]

得知我是店主后，蓬小姐似乎略感佩服。[p]

[vo vo="ep4/koku_0066.ogg"]
#【黒十 美鹤】
「那个、虽然由我来问有点那个，[r]　
　两位是怎么来到这里的？」[p]

[vo vo="ep4/koku_0067.ogg"]
#【黒十 美鹤】
「这个时段要进入学院[r]　
　需要特别许可对吧？」[p]

#
提出了从刚才起就惦记着的疑问。[p]

我们这边是因为有饴宫爱丽丝这个特例[r]　
才能过来，但她们是怎么做到的呢。[p]

[vo vo="ep4/kaguya_0026.ogg"]
[kaguya_無表情]
#【蓬 辉夜】
「当然是正式取得了许可啊」[p]
[kaguya_無表情_c]

[vo vo="ep4/hagino_0022.ogg"]
[tukasa_苦笑い]
#【萩乃司】
「虽然审批花了好几周，[r]　
　还被逼着写了不少文件呢」[p]
[tukasa_苦笑い_c]

[vo vo="ep4/kaguya_0027.ogg"]
[kaguya_呆れ]
#【蓬 辉夜】
「你们是靠爱丽丝走的后门吧？[r]　
　真让人羡慕呢」[p]
[kaguya_呆れ_c]

[vo vo="ep4/hagino_0023.ogg"]
[tukasa_苦笑い]
#【萩乃司】
「嘛，不过我们的申请能通过也算破例了」[p]
[tukasa_苦笑い_c]

[vo vo="ep4/yuzuha_0075.ogg"]
#【小仓 柚叶】
「是这样吗？」[p]

[vo vo="ep4/hagino_0024.ogg"]
[tukasa_笑顔]
#【萩乃司】
「嗯嗯，要不是以准备弥撒为正当理由，[r]　
　肯定会被拒绝的吧」[p]
[tukasa_笑顔_c]

[vo vo="ep4/yuzuha_0076.ogg"]
#【小仓 柚叶】
「哇～圣诞弥撒……听起来很棒呢！」[p]

[vo vo="ep4/hagino_0025.ogg"]
[tukasa_笑顔]
#【萩乃司】
「不过今年可能没什么人来参加就是了」[p]
[tukasa_笑顔_c]

#
萩乃小姐说着挠了挠头。[p]

[vo vo="ep4/yuzuha_0077.ogg"]
#【小仓 柚叶】
「诶？为什么啊？大家应该都很想参加才对」[p]

[vo vo="ep4/hagino_0026.ogg"]
[tukasa_驚き]
#【萩乃司】
「咦？你不知道吗，幽灵骚动的事」[p]
[tukasa_驚き_c]

#
[kill]
;//柚葉・黒十・司

;黒十衣装指定
[kokutou_c_冬]

;柚葉衣装指定
[yuzuha_c_冬]

[kokutou_真顔_c]
[ri_f cg="kokutou"]

[tukasa_驚き_c]
[ce_f cg="tukasa"]

[yuzuha_驚き]
[le cg="yuzuha"]
听到萩乃小姐这句话，柚叶君转过头来。[p]

看来他此刻才想起此行的目的。[p]

[vo vo="ep4/yuzuha_0078.ogg"]
#【小仓 柚叶】
「其实我们是为捕捉那个幽灵……不、[r]　
　是为调查骚动真相而来的哦！」[p]
[yuzuha_驚き_c]

#
蓬小姐听到柚叶君的话后抱住了脑袋。[p]

我也深有同感。[p]

[vo vo="ep4/hagino_0027.ogg"]
[tukasa_笑顔]
#【萩乃司】
「哎呀是这样吗？」[p]
[tukasa_笑顔_c]

[vo vo="ep4/alice_0047.ogg"]
#【饴宫 爱丽丝】
「听起来很有趣吧？」[p]

[vo vo="ep4/hagino_0028.ogg"]
[tukasa_笑顔]
#【萩乃司】
「哼嗯，这对我说也算求之不得呢」[p]

[vo vo="ep4/hagino_0029.ogg"]
#【萩乃司】
「要是能证明根本不存在幽灵，[r]　
　说不定人们就会回到这座礼拜堂了」[p]
[tukasa_笑顔_c]

[vo vo="ep4/koku_0068.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「能不能详细说说那座钟塔的幽灵，[r]　
　把知道的情况都告诉我们呢？」[p]
[kokutou_真顔_c]

[bgm_end2]

[vo vo="ep4/hagino_0030.ogg"]
[tukasa_笑顔]
#【萩乃司】
「好呀好呀，当然可以啦」[p]
[tukasa_笑顔_c]

[vo vo="ep4/yuzuha_0079.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「那座钟塔的幽灵，究竟是什么样的幽灵啊？」[p]
[yuzuha_微笑_c]


;BGM再生
[bgm ogg="kaiko.ogg"]

[vo vo="ep4/hagino_0031.ogg"]
[tukasa_疑問]
#【萩乃司】
「那个……虽然听到了各种说法，[r]　
　但最多的还是关于女孩幽灵的传闻吧」[p]
[tukasa_疑問_c]

[vo vo="ep4/koku_0069.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「……那个幽灵的传闻，[r]　
　究竟是从什么时候开始流传的呢？」[p]
[kokutou_真顔_c]

[vo vo="ep4/hagino_0032.ogg"]
[tukasa_疑問]
#【萩乃司】
「啊呀……嗯～到底是什么时候来着……」[p]

[vo vo="ep4/hagino_0033.ogg"]
#【萩乃司】
「像幽灵传闻这类事似乎不限于这个地方 以前就一直有呢」[p]

[vo vo="ep4/hagino_0034.ogg"]
[tukasa_笑顔]
#【萩乃司】
「但像这样钟塔的幽灵目击证言开始增多[r]　
　大概是从这个月开始的吧」[p]

[vo vo="ep4/hagino_0035.ogg"]
#【萩乃司】
「不知怎么就突然激增起来了呢」[p]
[tukasa_笑顔_c]

[vo vo="ep4/yuzuha_0080.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「就是那个12点时钟塔会出现幽灵的说法对吧？」[p]
[yuzuha_疑問_c]

[vo vo="ep4/hagino_0036.ogg"]
[tukasa_笑顔]
#【萩乃司】
「对对，[r]　
　因为这个缘故　现在这个地方变得特别令人害怕」[p]

[vo vo="ep4/hagino_0037.ogg"]
#【萩乃司】
「如今连普通学生都不敢靠近[r]　
　完全变成著名的灵异景点了呢」[p]

[vo vo="ep4/hagino_0038.ogg"]
#【萩乃司】
「托这个的福 本来成员就少的圣歌队，[r]　
　现在只剩我一个人了　唉」[p]
[tukasa_笑顔_c]

[vo vo="ep4/yuzuha_0081.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「啊 所以您才成了礼拜堂之主啊」[p]
[yuzuha_微笑_c]

[vo vo="ep4/hagino_0039.ogg"]
[tukasa_苦笑い]
#【萩乃司】
「这种称号我可一点都不想要呢」[p]

[vo vo="ep4/hagino_0040.ogg"]
#【萩乃司】
「因为队员都走光了[r]　
　连面向公众开放的弥撒准备都完全没进展」[p]

[vo vo="ep4/hagino_0041.ogg"]
#【萩乃司】
「像这样拿到许可就得工作到深夜[r]　
　不得不继续赶工……真是忙得团团转啊」[p]

[vo vo="ep4/hagino_0042.ogg"]
[tukasa_笑顔]
#【萩乃司】
「嘛，只有辉夜会帮忙整理，[r]　
　总算勉强能赶上吧」[p]
[tukasa_笑顔_c]

[vo vo="ep4/yuzuha_0082.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「诶，辉夜学姐居然」[p]
[yuzuha_驚き_c]

#
柚叶君用仿佛很意外的声音说着，看向莲。[p]

她当然察觉到了那道视线的意图，用冰冷的目光回瞪过去。[p]

[kill]

[kaguya_無表情_c]
[ric_f cg="kaguya"]

[yuzuha_哀]
[lec cg="yuzuha"]

[vo vo="ep4/yuzuha_0083.ogg"]
#【小仓 柚叶】
「呜……[r]　
　那、那个话说回来这些要整理的行李到底是什么啊？」[p]
[yuzuha_哀_c]

#
柚叶君像是要转移话题般问道。[p]

[vo vo="ep4/yuzuha_0084.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「看起来不像是从礼拜堂搬出来的东西呢」[p]
[yuzuha_微笑_c]

#
确实我对这些行李也很在意。[p]

成捆的纸张、旧标语牌、告示物、坏掉的架子和椅子等[r]　
摆放的物品五花八门。[p]

[vo vo="ep4/kaguya_0028.ogg"]
[kaguya_呆れ]
#【蓬 辉夜】
「这些是从决定拆除的旧校舍收集来的东西」[p]
[kaguya_呆れ_c]

[vo vo="ep4/yuzuha_0085.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「哎？决定要拆除了？」[p]
[yuzuha_驚き_c]

[vo vo="ep4/kaguya_0029.ogg"]
[kaguya_呆れ]
#【蓬 辉夜】
「你不知道吗？这个月校方已经正式发布公告了哦」[p]
[kaguya_呆れ_c]

#
听到对方像看傻瓜般的语气，柚叶君苦笑着挠了挠头。[p]

[vo vo="ep4/yuzuha_0086.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「但为什么旧校舍的东西会在这里？」[p]
[yuzuha_疑問_c]

[vo vo="ep4/kaguya_0030.ogg"]
[kaguya_無表情]
#【蓬 辉夜】
「需要留存的资料和保管物品暂时集中到了这座礼拜堂里」[p]
[kaguya_無表情_c]

[vo vo="ep4/hagino_0043.ogg"]
#【萩乃司】
「不过没必要的东西好像也混进来了呢[r]　
　……真是够呛」[p]

[vo vo="ep4/kaguya_0031.ogg"]
[kaguya_無表情]
#【蓬 辉夜】
「说到底要判断哪些东西该留本来就是很难的吧」[p]

[vo vo="ep4/kaguya_0032.ogg"]
#【蓬 辉夜】
「那些暂未做出判断的案例，总之也被集中到了这里哦」[p]

[vo vo="ep4/kaguya_0033.ogg"]
#【蓬 辉夜】
「关于如何处理这些保管物品，[r]　
　校方在拆除旧校舍时似乎产生了争执呢」[p]
[kaguya_無表情_c]

#
原来如此。[p]

看来这里的东西是因无处可去而被搁置的。[p]

[vo vo="ep4/hagino_0044.ogg"]
#【萩乃司】
「嘛、刚才也稍微提到过，辉夜也帮忙到深夜[r]　
　所以应该是赶得上弥撒的吧」[p]

[vo vo="ep4/koku_0070.ogg"]
#【黒十 美鹤】
「嗯……原来如此」[p]

[kill]

[alice_笑み_c]
[ce cg="alice"]

#
听到这番话，为了不被察觉，偷偷瞥了一眼饴宫爱丽丝。[p]

看来她也已经知道[r]　
旧校舍即将被拆除的事情。[p]

看到这个状况，突然想起那条项链的存在。[p]

她与柚叶君有所关联，一直执着地寻找着那条项链。[p]

那或许是因为[r]　
已经知道这座旧校舍要拆除的缘故。[p]

事实上，御伽俱乐部的活动场所就在旧校舍内部。[p]

[vo vo="ep4/alice_0048.ogg"]
[alice_疑問]
#【饴宫 爱丽丝】
「……干嘛盯着别人的脸看啊」[p]
[alice_疑問_c]

[vo vo="ep4/koku_0071.ogg"]
#【黒十 美鹤】
「不，没什么……」[p]

[kill]
#
察觉到视线后慌忙低下头。[p]

不知道会被找什么茬。[p]

[kokutou_哀2_c]
[ric_f cg="kokutou"]

[yuzuha_哀]
[lec cg="yuzuha"]

[vo vo="ep4/yuzuha_0087.ogg"]
#【小仓 柚叶】
「幽灵骚动加上礼拜堂的收拾工作……真是祸不单行啊……」[p]
[yuzuha_哀_c]

#
另一方面，柚叶君似乎正在为[r]　
身为礼拜堂之主的萩乃小姐的现状而叹息。[p]

她就像感同身受般，无精打采地耷拉着肩膀。[p]

看着这样的柚叶君，我总觉得有种不好的预感。[p]

以她的性格，很可能会说出要帮忙收拾之类的话。[p]

[vo vo="ep4/yuzuha_0088.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「如果可以的话，请让我们也帮忙收拾吧！」[p]
[yuzuha_笑顔_c]

[vo vo="ep4/koku_0072.ogg"]
[kokutou_呆れ]
#【黒十 美鹤】
「哈啊……果然呢……」[p]
[kokutou_呆れ_c]

#
不自觉地叹了口气。[p]

接着，抱怨声也从身旁传来。[p]

[kill]

[yuzuha_微笑_c]
[c4_f cg="yuzuha"]

[kokutou_哀2_c]
[c3_f cg="kokutou"]

[alice_疑問]
[ri cg="alice"]

[vo vo="ep4/alice_0049.ogg"]
#【饴宫 爱丽丝】
「我们？你刚才说了「们」吧？[r]　
　该不会连我也包括在内？」[p]
[alice_疑問_c]

#
带着挖苦意味的询问声。[p]

[kokutou_微笑_c]
但此刻，总觉得这番话莫名令人心安。[p]

以她的性格 自然不可能主动做这种麻烦的整理工作。[p]

[vo vo="ep4/yuzuha_0089.ogg"]
[yuzuha_怒]
#【小仓 柚叶】
「哎～ 有什么关系嘛 再说了 就算帮忙整理的时候[r]　
　也是可以调查礼拜堂的呀！」[p]
[yuzuha_怒_c]

[vo vo="ep4/koku_0073.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「不 虽然话是这么说……」[p]
[kokutou_微笑_c]

#
边说边往旁边瞥了一眼。[p]

明确拒绝的任务就交给她好了。[p]

[vo vo="ep4/alice_0050.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「……嘛 想做的话随你便咯？」[p]
[alice_真顔_c]
[kokutou_驚き]

#
这样说着，她便一下子坐到了礼拜堂的椅子上。[p]

[vo vo="ep4/koku_0074.ogg"]
[kokutou_呆れ_c]
#【黒十 美鹤】
「…………」[p]

#
被打败了。[p]

她正是能够做出这般选择的女性。[p]
#

;テキストウィンドウ削除
[end_text]

;BGM停止
[bgm_end3]

;全キャラ削除
[allc]

;背景
[bg10 bg="white.png"]

;//時間経過

;BGM再生
[bgm ogg="un_cafe.ogg"]

;//背景：礼拝堂（何種類かほしい）
[bg20 bg="chapel_room_04.jpg"]

[yuzuha_微笑_c]
[c3_f cg="yuzuha"]

[kokutou_哀2_c]
[c4_f cg="kokutou"]

[tukasa_笑顔]
[ri cg="tukasa"]


;テキストウィンドウ表示
[start_text]

[vo vo="ep4/hagino_0045.ogg"]
#【萩乃司】
「那就拜托把这个纸箱搬到后面的深处」[p]
[tukasa_笑顔_c]

#
被这样告知后，从萩乃小姐手中接过纸箱。[p]

里面大概是某种文件吧，相较于箱子的体积显得沉甸甸的。[p]

看来这个包裹是要被运到礼拜堂的。[p]

萩乃小姐和莲小姐正在将不需要的物品等进行分类，[r]　
似乎是要放到指定的地方。[p]

刚才拿着行李走到外面时，[r]　
已经堆放着数量不少的行李。[p]

因为这些文件属于不需要的物品[r]　
必须搬出礼拜堂运到深处的不需要物品区域。[p]

[vo vo="ep4/yuzuha_0090.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「司前辈，这个落地灯要搬到哪儿？」[p]
[yuzuha_微笑_c]

[vo vo="ep4/hagino_0046.ogg"]
[tukasa_笑顔]
#【萩乃司】
「呃呃……那个已经坏了属于不需要物品」[p]
[tukasa_真顔_c]

[vo vo="ep4/yuzuha_0091.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「放在这里的……相册吗？[r]　
　这个怎么处理？」[p]
[yuzuha_微笑_c]

[vo vo="ep4/hagino_0047.ogg"]
[tukasa_笑顔]
#【萩乃司】
「啊—那是要作为学院资料的，请放到玛利亚像旁边」[p]
[tukasa_笑顔_c]

[vo vo="ep4/yuzuha_0092.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「明白啦！」[p]
[yuzuha_笑顔_c]

[se_f se="footsteps_out.ogg"]

;1キャラ消去
[hide_yuzuha]



#
从刚才开始就一直进行着这样的对话[r]　
将行李搬到外面，并进行分类。[p]

这又是个相当繁重的工作。[p]

;全キャラ削除
[allc]

[alice_退屈_c]
[ce cg="alice"]


在我和柚叶君忙碌的间隙，那位金发大小姐[r]　
正随意地哗啦哗啦翻着文集之类的东西，显得毫无兴趣。[p]

虽然想着有空的话来帮忙就好了，但当然不会说出口。[p]

不过，也不能总是这样只顾着帮忙。[p]

若不调查钟塔的幽灵，[r]　
之后不知会被怎么数落。[p]
;全キャラ削除
[allc]


况且作为暂时停手的借口，[r]　
揭开这个幽灵的真相正是绝佳的说辞。[p]

[vo vo="ep4/koku_0075.ogg"]
#【黒十 美鹤】
「那里就是钟塔吗」[p]

#
望着礼拜堂深处的门扉独自低语。[p]

杂物差不多快整理完了。[p]

趁休息时去那座钟塔看看也不错。[p]

[kokutou_真顔_c]
[ric_f cg="kokutou"]

[yuzuha_微笑]
[lec cg="yuzuha"]

[vo vo="ep4/yuzuha_0093.ogg"]
#【小仓 柚叶】
「黑十先生，怎么了？」[p]
[yuzuha_微笑_c]

[vo vo="ep4/koku_0076.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「那边是钟塔吧？我想去瞧瞧」[p]
[kokutou_真顔_c]

[vo vo="ep4/alice_0051.ogg"]
#【饴宫 爱丽丝】
「终于打算揭开幽灵的真面目了？」[p]

#
幽灵什么的根本不存在。[p]

但比起继续整理杂物[r]　
去找找幽灵说不定还稍微强些。[p]

本就缺乏运动的身体。[p]

深夜的体力劳动实在难熬。[p]

[vo vo="ep4/koku_0077.ogg"]
[kokutou_呆れ]
#【黒十 美鹤】
「……毕竟也不再年轻了」[p]
[kokutou_呆れ_c]

#
;全キャラ削除
[allc]

;SE：扉オープン
[se_f se="door_op.ogg"]
自言自语着推开通往钟塔的门。[p]

;//背景：鐘塔へ続く廊下
[bg20 bg="chapel_corridor_01.jpg"]

[vo vo="ep4/yuzuha_0094.ogg"]
#【小仓 柚叶】
「啊，我也去！」[p]

#
沿着通向钟塔的走廊前行。[p]

与刚才所在的礼拜堂截然不同，这里意外是条普通走廊。[p]

看不到特别精巧的装饰品。[p]

说不定所有礼拜堂的[r]　
背后都是这般模样。[p]

[ric_f cg="kokutou"]

[lec cg="yuzuha"]

[vo vo="ep4/yuzuha_0095.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「黑十先生、幽灵、存在吗？」[p]
[yuzuha_笑顔_c]

#
柚叶君问了个愚蠢的问题。[p]

[vo vo="ep4/koku_0078.ogg"]
[kokutou_哀2]
#【黒十 美鹤】
「幽灵这种东西怎么可能存在嘛」[p]
[kokutou_哀2_c]

[vo vo="ep4/yuzuha_0096.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「但这次的传闻流传得相当广，[r]　
　大家好像都很害怕呢？」[p]

[vo vo="ep4/yuzuha_0097.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「而且似乎也有不少人声称实际见过幽灵，[r]　
　说不定真的存在哦！」[p]
[yuzuha_笑顔_c]


[vo vo="ep4/koku_0079.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「那种事，绝无可能」[p]

[vo vo="ep4/koku_0080.ogg"]
#【黒十 美鹤】
「肯定是有人铤而走险爬上钟塔了」[p]

[vo vo="ep4/koku_0081.ogg"]
#【黒十 美鹤】
「大家误将其看成幽灵了吧」[p]
[kokutou_真顔_c]

[vo vo="ep4/yuzuha_0098.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「唔～不过钟塔是能随便爬上去的吗？」[p]
[yuzuha_疑問_c]

[vo vo="ep4/koku_0082.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「虽然传言说是废弃状态，[r]　
　但应该还是有维护的」[p]
[kokutou_真顔_c]

#
刚才从外部确认时，看起来确实有修缮痕迹。[p]

[vo vo="ep4/koku_0083.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「所以按理说能直达钟所在的区域哦」[p]
[kokutou_真顔_c]

[vo vo="ep4/yuzuha_0099.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「啊～听您这么一说确实呢，[r]　
　那我们就上去看看吧」[p]
[yuzuha_笑顔_c]

#

;全キャラ削除
[allc]

;//背景：鐘塔廊下２
[bg20 bg="chapel_corridor_02.jpg"]

登上阶梯，朝大钟所在处前进。[p]

但在即将登顶时停住了脚步。[p]

或者说不得不停下。[p]

;//背景：ハシゴの画像
[bg20 bg="ladder.jpg"]

[vo vo="ep4/koku_0084.ogg"]
#【黒十 美鹤】
「这是……」[p]

#
事实证明确实能抵达钟塔。[p]

先经阶梯登上高处，再利用固定在墙体的梯子，[r]　
整个构造似乎能让人直达钟塔正下方。[p]

然而，关键的墙上所安装的梯子已然损坏。[p]

;//背景：鐘塔廊下２
[bg20 bg="chapel_corridor_02.jpg"]

[kokutou_驚き_c]
[ric_f cg="kokutou"]

[yuzuha_哀]
[lec cg="yuzuha"]

[vo vo="ep4/yuzuha_0100.ogg"]
#【小仓 柚叶】
「啊呀……梯子断掉了呢……」[p]

[vo vo="ep4/yuzuha_0101.ogg"]
#【小仓 柚叶】
「这样可到不了钟塔那边哦」[p]

[kokutou_真顔_c]
#
正如柚叶君所说，照这样下去肯定没法到达钟的位置吧。[p]

我环顾四周，[r]　
但似乎没有替代的梯子放在那里。[p]

无奈之下，我和柚叶君两人返回了礼拜堂。[p]

;テキストウィンドウ削除
[end_text]

;BGM停止
[bgm_end3]

;全キャラ削除
[allc]

;背景
[bg10 bg="white.png"]

;BGM再生
[bgm ogg="mid_re.ogg"]

;//背景：礼拝堂
[bg20 bg="chapel_room_01.jpg"]

[yuzuha_微笑_c]
[c4_f cg="yuzuha"]

[kokutou_哀2_c]
[c3_f cg="kokutou"]

[alice_ドヤ顔]
[c1 cg="alice"]

;テキストウィンドウ表示
[start_text]

[vo vo="ep4/alice_0052.ogg"]
#【饴宫 爱丽丝】
「哎呀，回来得可真早呢」[p]
[alice_ドヤ顔_c]

#
她用带着恶作剧意味的微笑迎接返回的我们。[p]

[vo vo="ep4/koku_0085.ogg"]
[kokutou_怒]
#【黒十 美鹤】
「……您早就知道了吧？」[p]
[kokutou_怒_c]

[vo vo="ep4/alice_0053.ogg"]
[alice_ドヤ顔]
#【饴宫 爱丽丝】
「哎呀，你在说什么呢」[p]
[alice_ドヤ顔_c]

[vo vo="ep4/koku_0086.ogg"]
[kokutou_怒]
#【黒十 美鹤】
「请不要装糊涂、[r]　
　去钟塔的梯子坏了这件事您明明知道的」[p]
[kokutou_怒_c]

[vo vo="ep4/yuzuha_0102.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「诶ー、爱丽丝前辈原来知道啊ー、[r]　
　那告诉我们不就好了吗」[p]
[yuzuha_哀_c]

[vo vo="ep4/alice_0054.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「我哪能想到你们竟然会不知道啊」[p]
[alice_笑み_c]

#
绝对是骗人的吧。[p]

[vo vo="ep4/koku_0087.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「……梯子坏了这件事、是众所周知的事实吗？」[p]
[kokutou_真顔_c]

[vo vo="ep4/alice_0055.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「是啊，不仅是礼拜堂的相关人员，[r]　
　想必所有知道这个幽灵传闻的学生都听说过吧」[p]

[vo vo="ep4/alice_0056.ogg"]
#【饴宫 爱丽丝】
「对吧，萩乃司」[p]
[alice_笑み_c]

[c2_f cg="tukasa"]

#
刚搬完行李回来的萩乃，[r]　
被问到后歪着头回答道。[p]

[vo vo="ep4/hagino_0048.ogg"]
[tukasa_疑問]
#【萩乃司】
「嗯嗯……是啊，大概大家都知道了吧」[p]

[vo vo="ep4/hagino_0049.ogg"]
[tukasa_笑顔]
#【萩乃司】
「因为知道不能去钟塔，[r]　
　所以才更加害怕这个传闻吧」[p]
[tukasa_笑顔_c]

#
原来如此确实是这样吧。[p]

正因为无人能至的地方出现了人影，[r]　
大家才会承认幽灵这种不确定的存在吧。[p]

不过，这样的话反而好办了。[p]

[vo vo="ep4/koku_0088.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「只要证明在这种状况下也能登上钟塔，[r]　
　似乎就能否定幽灵的存在了呢」[p]
[kokutou_微笑_c]

[vo vo="ep4/hagino_0050.ogg"]
[tukasa_笑顔]
#【萩乃司】
「咦？啊，也对……呵呵，可能是这样呢」[p]
[tukasa_笑顔_c]

[vo vo="ep4/koku_0089.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「如果有其他梯子倒是能爬上去……不过这里有那种东西吗？」[p]
[kokutou_真顔_c]

[vo vo="ep4/hagino_0051.ogg"]
[tukasa_笑顔]
#【萩乃司】
「没有呢——」[p]
[tukasa_笑顔_c]

#
说是理所当然也是理所当然。[p]

如果真有的话，[r]　
萩乃小姐恐怕早就否定幽灵的传闻了吧。[p]

[vo vo="ep4/koku_0090.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「这么说来……[r]　
　有可能是从礼拜堂外面搬来了梯子呢」[p]
[kokutou_真顔_c]

[vo vo="ep4/alice_0057.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「很遗憾，那是不可能的哦」[p]

[vo vo="ep4/alice_0058.ogg"]
#【饴宫 爱丽丝】
「去总务室的话确实能找到一两把梯子吧」[p]

[vo vo="ep4/alice_0059.ogg"]
#【饴宫 爱丽丝】
「但是这座学校的总务室放学时就已经关门了哦」[p]

[vo vo="ep4/alice_0060.ogg"]
#【饴宫 爱丽丝】
「钥匙除了总务员保管的之外教员室也有备用……」[p]

[vo vo="ep4/alice_0061.ogg"]
#【饴宫 爱丽丝】
「如果去拿的话，就会留下使用记录哦」[p]
[alice_笑み_c]

[vo vo="ep4/koku_0091.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「是这样吗？」[p]
[kokutou_疑問_c]

#
也向圣歌队负责人萩野小姐确认了这件事。[p]

[vo vo="ep4/hagino_0052.ogg"]
[tukasa_真顔]
#【萩乃司】
「咦？啊——……是的不过……嗯，是的呢」[p]
[tukasa_真顔_c]

#
她似乎有些支吾，但还是点了点头。[p]

[vo vo="ep4/yuzuha_0103.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「那么，只要查一下[r]　
　那个取出的记录就可以了吧……」[p]
[yuzuha_微笑_c]

[vo vo="ep4/alice_0062.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「当然那种记录根本不存在吧」[p]
[alice_真顔_c]

#
从她的语气可以推测，[r]　
记录不存在这件事似乎已经确认过了。[p]

她说觉得这次幽灵骚动很有趣，[r]　
或许正是因为已经调查过这类事件了。[p]

[vo vo="ep4/koku_0092.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「那么，要调查是否有梯子的替代品能用来攀登吗」[p]
[kokutou_真顔_c]

[vo vo="ep4/yuzuha_0104.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「梯子的替代品，吗？」[p]
[yuzuha_疑問_c]

[vo vo="ep4/koku_0093.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「对，绳子或椅子、桌子之类的都可以……没有吗？」[p]
[kokutou_真顔_c]

[yuzuha_驚き_c]

[vo vo="ep4/hagino_0053.ogg"]
[tukasa_疑問]
#【萩乃司】
「唔……我想大概找不到吧」[p]
[tukasa_疑問_c]

[vo vo="ep4/koku_0094.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「比如这个礼拜堂的长椅呢？」[p]
[kokutou_疑問_c]

[yuzuha_疑問_c]

[vo vo="ep4/hagino_0054.ogg"]
[tukasa_苦笑い]
#【萩乃司】
「我们这里的长椅[r]　
　是固定在地面上的类型……虽然很遗憾」[p]
[tukasa_苦笑い_c]

#
能委任整理事务的萩乃女士是以认真严谨著称的。[p]

礼拜堂主人的话应该不会有错吧。[p]

不过这样一来事情就变得有点棘手了。[p]

[vo vo="ep4/yuzuha_0105.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「如果没有梯子的替代品……[r]　
　难道真的是有幽灵存在吗？」[p]
[yuzuha_疑問_c]

[vo vo="ep4/koku_0095.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「不，比起幽灵还有更值得追查的线索」[p]

[vo vo="ep4/koku_0096.ogg"]
#【黒十 美鹤】
「去查查从其他地方能否登上钟塔吧」[p]
[kokutou_真顔_c]

[vo vo="ep4/yuzuha_0106.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「啊，原来如此！[r]　
　我们来找找看有没有其他不用梯子就能上去的地方吧！！」[p]
[yuzuha_笑顔_c]

#
与干劲十足的柚叶君相反，萩乃小姐露出苦笑。[p]

[vo vo="ep4/hagino_0055.ogg"]
[tukasa_苦笑い]
#【萩乃司】
「唔～我觉得很难……不过，你们可以先找找看」[p]
[tukasa_苦笑い_c]

#
;全キャラ削除
[allc]

[bgm_end3]

;//背景：黒
[bg20 bg="black.png"]


背对着无精打采的礼拜堂主人的话语，[r]　
我和柚叶君二人开始在钟塔周围及礼拜堂内部探查。[p]

但渐渐发现要登上钟塔确实很困难。[p]

我们从钟塔二楼的窗户窥视上方。[p]

只见一口大钟仿佛悬浮在夜空中。[p]

;//背景：礼拝堂
[bg20 bg="chapel_room_01.jpg"]

;BGM再生
[bgm ogg="kaiko.ogg"]

[kokutou_哀2_c]
[ric_f cg="kokutou"]

[yuzuha_疑問]
[lec cg="yuzuha"]

[vo vo="ep4/yuzuha_0107.ogg"]
#【小仓 柚叶】
「嗯……没找到能通往钟塔的地方呢」[p]

[vo vo="ep4/yuzuha_0108.ogg"]
#【小仓 柚叶】
「果然还是只能从那个坏掉的梯子[r]　
　那边上去吧？」[p]
[yuzuha_疑問_c]

#
柚叶君显得有些疲惫地说道。[p]

其实她刚才就一直精神饱满地在礼拜堂里来回奔走。[p]

[vo vo="ep4/koku_0097.ogg"]
[kokutou_哀2]
#【黒十 美鹤】
「说的也是呢……我再出去一趟，[r]　
　仔细检查礼拜堂外围吧」[p]

[vo vo="ep4/koku_0098.ogg"]
#【黒十 美鹤】
「柚叶君你先稍作休息」[p]
[kokutou_哀2_c]

[vo vo="ep4/yuzuha_0109.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「好的，[r]　
　有发现的话请立刻叫我哦！」[p]
[yuzuha_笑顔_c]

;//シーン転換

;テキストウィンドウ削除
[end_text]

;BGM停止
[bgm_end3]

;全キャラ削除
[allc]

;背景
[bg10 bg="white.png"]

;次のシーンへ移動
[jump  storage="ep4_scene05.ks"]

[s]