﻿;--------------------------------------------------
*016000
[savetitle text="付いてくればわかりますよ"]
;-------------------------------------------------

;背景
[bg10 bg="sky.jpg"]

;SE：足音フェイドアウト
[se_f se="footstep_room_out.ogg"]

;テキストウィンドウ表示
[start_text]

[vo vo="ep1/yuzu_0154.ogg"]
#【小仓 柚叶】
「黑十先生、要去哪里呢？」[p]

[vo vo="ep1/koku_0150.ogg"]
#【黒十 美鹤】
「跟着来就知道了，很快就要到了」[p]

#
那之后，立刻离开了古董店。[p]

[vo vo="ep1/yuzu_0155.ogg"]
#【小仓 柚叶】
「唔、如果发现了什么请告诉我呀！」[p]

[vo vo="ep1/koku_0151.ogg"]
#【黒十 美鹤】
「本来是可以这么做的呢」[p]

[vo vo="ep1/koku_0152.ogg"]
#【黒十 美鹤】
「不过比起说明，我觉得直接让您看到会更快捷」[p]

[vo vo="ep1/sayu_0056.ogg"]
#【稻饼 小百合】
「直接？」[p]

[vo vo="ep1/koku_0153.ogg"]
#【黒十 美鹤】
「是的，到了哦」[p]

;背景
[bg10 bg="cafe01.jpg"]


[kokutou_真顔_c]
[ri_f cg="kokutou"]
[yuzuha_疑問_c]
[ce_f cg="yuzuha"]
[sayuri_微笑_c]
[le cg="sayuri"]

[yuzuha_疑問]
[vo vo="ep1/yuzu_0156.ogg"]
#【小仓 柚叶】
「这里……不是咖啡店吗？」[p]
[yuzuha_疑問_c]

#
被带来的场所，正是那家咖啡店。[p]

谜团的中枢，亦是其舞台所在。[p]

[sayuri_哀]
[vo vo="ep1/sayu_0057.ogg"]
#【稻饼 小百合】
「将我们带到这里，究竟有何打算？」[p]
[sayuri_哀_c]

[kokutou_凛]
[vo vo="ep1/koku_0154.ogg"]
#【黒十 美鹤】
「现在进入这家店的话，应该能遇见稻饼小姐心仪的对象[r]　
　……少年X」[p]
[kokutou_凛_c]

[sayuri_哀]
[vo vo="ep1/sayu_0058.ogg"]
#【稻饼 小百合】
「真、真的吗？」[p]
[sayuri_哀_c]

[yuzuha_疑問]
[vo vo="ep1/yuzu_0157.ogg"]
#【小仓 柚叶】
「可是连他是否进了咖啡店都不知道吧？」[p]
[yuzuha_疑問_c]

[kokutou_真顔]
[vo vo="ep1/koku_0155.ogg"]
#【黒十 美鹤】
「没关系，请先进去吧，来请进」[p]
[kokutou_真顔_c]

[sayuri_必死]
[vo vo="ep1/sayu_0059.ogg"]
#【稻饼 小百合】
「明、明白了……」[p]
[sayuri_必死_c]

;全キャラ削除
[allc]

;背景
[bg10 bg="cafe02.jpg"]

;SE：ベルの音
[se_f se="bell00.ogg"]

[kokutou_真顔_c]
[ri_f cg="kokutou"]
[sayuri_微笑_c]
[ce_f cg="sayuri"]
[iori_微笑_c]
[le cg="iori"]

[iori_微笑]
[vo vo="ep1/iori_0018.ogg"]
#【御手洗 庵】
「欢迎光……咦？稻饼小姐，你们也一起吗」[p]
[iori_微笑_c]

[kokutou_真顔]
[vo vo="ep1/koku_0156.ogg"]
#【黒十 美鹤】
「您好，三位」[p]
[kokutou_真顔_c]

[iori_微笑]
[vo vo="ep1/iori_0019.ogg"]
#【御手洗 庵】
「好的，请随便坐」[p]
[iori_微笑_c]

[allc]

#
于是三人、坐到了昨天和柚叶君一起坐过的位置上。[p]

柚叶君和稻饼小姐正东张西望地环视着四周。[p]

这时、店主从柜台里侧走了出来。[p]

;SE：足音フェイドイン
[se_f se="footsteps_in.ogg"]

[master_微笑]
[ce cg="master"]

[vo vo="ep1/master_0004.ogg"]
#【店主】
「啊、小庵、我稍微出去一下、这里交给你没问题吧？」[p]

[kill]
[iori_微笑]
[ric_f cg="iori"]
[master_微笑_c] 
[lec cg="master"]

[vo vo="ep1/iori_0020.ogg"]
#【御手洗 庵】
「啊、没问题的、您慢走」[p]
[iori_微笑_c]

[master_微笑] 
[vo vo="ep1/master_0005.ogg"]
#【店主】
「预计一小时左右回来[r]　
　要是过了关店时间你们可以先回去哦」[p]

[vo vo="ep1/master_0006.ogg"]
#【店主】
「那之后就拜托你啦」[p]
[master_微笑_c] 

[iori_微笑]
[vo vo="ep1/iori_0021.ogg"]
#【御手洗 庵】
「好的、明白了」[p]
[iori_微笑_c]

;全キャラ削除
[allc]

;背景
[bg10 bg="cafe03.jpg"]

[kokutou_真顔_c]
[ric_f cg="kokutou"]
[master_微笑] 
[lec cg="master"]

[vo vo="ep1/master_0007.ogg"]
#【店主】
「啊、稻饼小姐、还有你们几位」[p]
[master_微笑_c] 

#
注意到坐在座位上的我们[r]　
店主浮现出柔和的笑容向我们打招呼。[p]

[master_笑顔]
[vo vo="ep1/master_0008.ogg"]
#【店主】
「欢迎光临、真是连续光顾呢」[p]
[master_笑顔_c]

[kokutou_真顔]
[vo vo="ep1/koku_0157.ogg"]
#【黒十 美鹤】
「你好」[p]
[kokutou_真顔_c]

[master_笑顔]
[vo vo="ep1/master_0009.ogg"]
#【店主】
「不用客气、请慢慢享用」[p]

[master_微笑]
[vo vo="ep1/master_0010.ogg"]
#【店主】
「啊、请问决定好点单了吗？」[p]
[master_微笑_c]

[kokutou_真顔]
[vo vo="ep1/koku_0158.ogg"]
#【黒十 美鹤】
「啊、那我要咖啡」[p]
[kokutou_真顔_c]

[vo vo="ep1/yuzu_0158.ogg"]
#【小仓 柚叶】
「那我也一样」[p]

[vo vo="ep1/sayu_0060.ogg"]
#【稻饼 小百合】
「我也要一样的」[p]

[master_微笑]
[vo vo="ep1/master_0011.ogg"]
#【店主】
「砂糖和牛奶要加吗？稻饼小姐是喝黑咖啡对吧？」[p]
[master_微笑_c]

[vo vo="ep1/sayu_0061.ogg"]
#【稻饼 小百合】
「嗯、是的」[p]

[kokutou_真顔]
[vo vo="ep1/koku_0159.ogg"]
#【黒十 美鹤】
「我也要黑咖啡」[p]
[kokutou_真顔_c]

[vo vo="ep1/yuzu_0159.ogg"]
#【小仓 柚叶】
「啊，我咖啡请加糖，不要牛奶」[p]

[master_微笑]
[vo vo="ep1/master_0012.ogg"]
#【店主】
「好的，明白了」[p]
[master_微笑_c]

;SE：足音フェイドアウト
[se_f se="footsteps_out.ogg"]

;マスター削除
[chara_hide name=master]

#
老板说完便暂时回到柜台[r]　
交代完点单后走出了店面。[p]

三人目送他离开后，柚叶君探出身子询问道。[p]

[kill]
[kokutou_真顔_c]
[ri_f cg="kokutou"]
[yuzuha_疑問]
[ce_f cg="yuzuha"]
[sayuri_微笑_c]
[le cg="sayuri"]

[vo vo="ep1/yuzu_0160.ogg"]
#【小仓 柚叶】
「黑十先生，果然和昨天一样没有男孩子在场不是吗」[p]
[yuzuha_疑問_c]

[kokutou_微笑]
[vo vo="ep1/koku_0160.ogg"]
#【黒十 美鹤】
「是吗？我倒是已经找到了哦？」[p]
[kokutou_微笑_c]

[yuzuha_驚き]
[sayuri_驚き]
[vo vo="ep1/yuzu_0161.ogg"]
#【小仓 柚叶】
「诶！？找、找到了！？」[p]

#
柚叶君慌张地东张西望环顾四周。[p]

[yuzuha_怒]
[vo vo="ep1/yuzu_0162.ogg"]
#【小仓 柚叶】
「根本没有什么男孩子嘛」[p]
[yuzuha_怒_c]

[kokutou_凛]
[vo vo="ep1/koku_0161.ogg"]
#【黒十 美鹤】
「男孩子啊……问题就出在这里」[p]

[vo vo="ep1/koku_0162.ogg"]
#【黒十 美鹤】
「我们一直存在严重的误解」[p]
[kokutou_凛_c]

[sayuri_哀]
[vo vo="ep1/sayu_0062.ogg"]
#【稻饼 小百合】
「误解？此话怎讲？」[p]
[sayuri_哀_c]

[kokutou_凛]
[vo vo="ep1/koku_0163.ogg"]
#【黒十 美鹤】
「刚才我说过……登场人物共有4人」[p]
[kokutou_凛_c]

[yuzuha_疑問]
[vo vo="ep1/yuzu_0163.ogg"]
#【小仓 柚叶】
「呃，是小百合小姐、少年X、小庵和老板4人对吧？」[p]
[yuzuha_疑問_c]

[kokutou_凛]
[vo vo="ep1/koku_0164.ogg"]
#【黒十 美鹤】
「不是4人，其实是3人」[p]
[kokutou_凛_c]

[yuzuha_怒]
[vo vo="ep1/yuzu_0164.ogg"]
#【小仓 柚叶】
「……诶？这是什么意思？」[p]
[yuzuha_怒_c]

;BGM停止
[bgm_end2]

;SE：足音フェイドイン
[se_f se="footsteps_in.ogg"]
#
这时端着咖啡托盘的小庵走了过来。[p]

[vo vo="ep1/iori_0022.ogg"]
#【御手洗 庵】
「久等了」[p]

;SE:カップの音
[se_f se="clearing_the_table.ogg"]

#
我顺势开口。[p]

[kokutou_凛]
[vo vo="ep1/koku_0165.ogg"]
#【黒十 美鹤】
「少年X就坐在我们眼前啊」[p]
[kokutou_凛_c]

;イベントＣＧ表示
[eval exp="sf.cg_ep1_2 = 1"]
[event_in event="ep1_2"]

;[kokutou_微笑]

[vo vo="ep1/koku_0166.ogg"]
#【黒十 美鹤】
「没错，就在这里」[p]

;BGM再生
[bgm ogg="tukikage.ogg"]


#
说着，我的目光落在正在桌前摆放咖啡的小庵身上。[p]

[vo vo="ep1/yuzu_0165.ogg"]
#【小仓 柚叶】
「……诶？」[p]

;[sayuri_哀]

[vo vo="ep1/sayu_0063.ogg"]
#【稻饼 小百合】
「……呃……？」[p]

[vo vo="ep1/iori_0023.ogg"]
#【御手洗 庵】
「…………」[p]

#
面对这突如其来的发言，柚叶君和稻饼小姐露出了呆滞的表情。[p]

[vo vo="ep1/yuzu_0166.ogg"]
#【小仓 柚叶】
「黑十先生，您在说什么啊？」[p]

;[kokutou_真顔]

[vo vo="ep1/koku_0167.ogg"]
#【黒十 美鹤】
「就是字面意思哦」[p]

[vo vo="ep1/sayu_0064.ogg"]
#【稻饼 小百合】
「难、难道说小庵她……？」[p]

[vo vo="ep1/koku_0168.ogg"]
#【黒十 美鹤】
「嗯，正是如此」[p]

[vo vo="ep1/koku_0169.ogg"]
#【黒十 美鹤】
「这位庵小姐，就是您心仪的少年X」[p]

[vo vo="ep1/iori_0024.ogg"]
#【御手洗 庵】
「…………」[p]

;[yuzuha_驚き]

[vo vo="ep1/yuzu_0167.ogg"]
#【小仓 柚叶】
「诶、诶诶诶诶————！！！？？？」[p]

#
柚叶君双手撑着桌子猛地站起身。[p]

[vo vo="ep1/yuzu_0168.ogg"]
#【小仓 柚叶】
「等、等等、请等一下黑十先生！」[p]

;[yuzuha_怒鳴る]

[vo vo="ep1/yuzu_0169.ogg"]
#【小仓 柚叶】
「也就是说黑十先生认为，这个庵庵子其其其[r]　
　……是男生吗！？」[p]

[vo vo="ep1/koku_0170.ogg"]
#【黒十 美鹤】
「正是如此……换言之我们寻找的少年X[r]　
　从一开始就未曾消失过」[p]

[vo vo="ep1/koku_0171.ogg"]
#【黒十 美鹤】
「不仅如此，他从最初就一直在我们眼前」[p]

[vo vo="ep1/sayu_0065.ogg"]
#【稻饼 小百合】
「在眼前……」[p]

[vo vo="ep1/koku_0172.ogg"]
#【黒十 美鹤】
「没错，因为我们看到的少年X进入店里后[r]　
　就会换上咖啡店制服开始工作」[p]

[vo vo="ep1/koku_0173.ogg"]
#【黒十 美鹤】
「从长裤变成裙子……也就是说，从少年模样变成了少女姿态」[p]

;[yuzuha_驚き]

[vo vo="ep1/yuzu_0170.ogg"]
#【小仓 柚叶】
「啊、原来是被蛋壳般的伪装给欺骗了[r]　
　……是这么回事啊！」[p]

;[sayuri_微笑]

[vo vo="ep1/sayu_0066.ogg"]
#【稻饼 小百合】
「啊，原来如此」[p]

[vo vo="ep1/iori_0025.ogg"]
#【御手洗 庵】
「……我有一个问题」[p]

#
意想不到的人物提出了疑问。[p]

柚叶君和稻饼小姐的视线转向庵小姐。[p]

[vo vo="ep1/koku_0174.ogg"]
#【黒十 美鹤】
「什么事？」[p]

[vo vo="ep1/iori_0026.ogg"]
#【御手洗 庵】
「说我是男生的证据呢？」[p]

;[yuzuha_疑問]

;[kokutou_疑問]

[vo vo="ep1/koku_0175.ogg"]
#【黒十 美鹤】
「从现状来看应该不会错[r]　
　嘛，只要调查一下就知道了」[p]

[vo vo="ep1/iori_0027.ogg"]
#【御手洗 庵】
「啊哈哈，要验证看看吗？」[p]

#
她咧嘴一笑，做出要掀起裙摆的动作。[p]

;[kokutou_凛]

[vo vo="ep1/koku_0176.ogg"]
#【黒十 美鹤】
「不会吧，我可没有偷看男生裙底的兴趣」[p]

[vo vo="ep1/iori_0028.ogg"]
#【御手洗 庵】
「那可真是遗憾」[p]

[vo vo="ep1/koku_0177.ogg"]
#【黒十 美鹤】
「比起那个，调查更衣室的储物柜更快吧」[p]

[vo vo="ep1/koku_0178.ogg"]
#【黒十 美鹤】
「里面应该放着和少年X相同的衣服」[p]

[vo vo="ep1/iori_0029.ogg"]
#【御手洗 庵】
「啊确实，那样可能更快」[p]

[kokutou_凛_c]
[yuzuha_疑問_c]
[sayuri_必死_c]
[iori_微笑_c]

;イベントＣＧ削除
[event_out]

[sayuri_必死]
[vo vo="ep1/sayu_0067.ogg"]
#【稻饼 小百合】
「等等！小庵，真、真的吗！？」[p]

[vo vo="ep1/sayu_0068.ogg"]
#【稻饼 小百合】
「真、真的是小庵你，那个……男孩子？」[p]
[sayuri_必死_c]

[iori_微笑]
[vo vo="ep1/iori_0030.ogg"]
#【御手洗 庵】
「啊～……嗯，对不起，虽然没打算欺骗你们」[p]
[iori_微笑_c]

[yuzuha_驚き]
[vo vo="ep1/yuzu_0171.ogg"]
#【小仓 柚叶】
「骗人……真的是男孩子！？[r]　
　不管怎么看都是女孩子啊！」[p]
[yuzuha_驚き_c]

[kokutou_疑問]
[vo vo="ep1/koku_0179.ogg"]
#【黒十 美鹤】
「嘛，从下面偷看的话就能确认是男孩子了」[p]
[kokutou_疑問_c]

[yuzuha_怒鳴る]
[vo vo="ep1/yuzu_0172.ogg"]
#【小仓 柚叶】
「……啊，这样啊」[p]
[yuzuha_怒鳴る_c]

[kokutou_怒]
[vo vo="ep1/koku_0180.ogg"]
#【黒十 美鹤】
「不准偷看！」[p]
[kokutou_怒_c]

[yuzuha_笑顔]
[vo vo="ep1/yuzu_0173.ogg"]
#【小仓 柚叶】
「嘿嘿」[p]
[yuzuha_笑顔_c]

[kokutou_真顔]
[vo vo="ep1/sayu_0069.ogg"]
#【稻饼 小百合】
「但是为什么要这样？女装什么的……」[p]
[kokutou_真顔_c]

[yuzuha_微笑]

[iori_無表情]
[vo vo="ep1/iori_0031.ogg"]
#【御手洗 庵】
「那个……都说了不是存心要欺骗」[p]

[vo vo="ep1/iori_0032.ogg"]
#【御手洗 庵】
「那是真的[r]　
　如果可以的话我也不想说这种谎的……」[p]
[iori_無表情_c]

[sayuri_必死]
[vo vo="ep1/sayu_0070.ogg"]
#【稻饼 小百合】
「什么意思？」[p]
[sayuri_必死_c]

[iori_微笑]
[vo vo="ep1/iori_0033.ogg"]
#【御手洗 庵】
「如果听了理由[r]　
　我觉得稻饼小姐可能会受打击吧」[p]
[iori_微笑_c]

[sayuri_哀]
[vo vo="ep1/sayu_0071.ogg"]
#【稻饼 小百合】
「受打击？」[p]
[sayuri_哀_c]

#
歪着头疑惑，但此刻我恍然大悟。[p]

#
因为那个答案意味着[r]　
她的单恋将以意想不到的形式落幕。[p]

[yuzuha_怒鳴る]
[vo vo="ep1/yuzu_0174.ogg"]
#【小仓 柚叶】
「啊啊啊！原来如此！」[p]
[yuzuha_怒鳴る_c]

#
柚叶君似乎也察觉了，啪地拍了下手。[p]

[kokutou_驚き]

虽然有不祥的预感[r]　
但终究没能及时捂住柚叶君的嘴。[p]

;BGM停止
[bgm_end1]

[yuzuha_笑顔]
[vo vo="ep1/yuzu_0175.ogg"]
#【小仓 柚叶】
「小庵，你是同性恋对吧！」[p]
[yuzuha_笑顔_c]

[kokutou_哀_c]
[iori_驚き_c]

#
就这样一个谜团解开，少女的恋情就此落幕。[p]

;テキストウィンドウ削除
[end_text]

;全キャラ削除
[allc]

[if exp="f.cup_choose == 0"]

[jump  storage="ep1_scene05.ks"  target="*zyosoutorikkunomi"]

[elsif exp="f.怪しい == 0"]

[jump  storage="ep1_scene06.ks"  target="*017000"]

[endif]

;--------------------------------------------------
*zyosoutorikkunomi
[savetitle text="今回の謎の提供者"]
;-------------------------------------------------

;背景
[bg20 bg="white.png"]


;背景：KOKUTOU外観
[bg30 bg="shop_kokutou.jpg"]

;BGM再生
[bgm ogg="mid_re.ogg"]

;背景：KOKUTOU事務所
[bg20 bg="antique.jpg"]


[kokutou_真顔_c]
[ric_f cg="kokutou"]
[yuzuha_微笑_c] 
[lec cg="yuzuha"]


;テキストウィンドウ表示
[start_text]

[kokutou_真顔]
[vo vo="ep1/koku_0181.ogg"]
#【黒十 美鹤】
「但没想到会是那种结局……」[p]
[kokutou_真顔_c]

[yuzuha_微笑] 
[vo vo="ep1/yuzu_0176.ogg"]
#【小仓 柚叶】
「就是说啊……」[p]
[yuzuha_微笑_c] 

#
解开稻饼小姐暗恋男孩的谜团后几天。[p]

放学后的柚叶君来到店里。[p]

[kokutou_真顔]
[vo vo="ep1/koku_0182.ogg"]
#【黒十 美鹤】
「话说，后来稻饼小姐没事吧？」[p]
[kokutou_真顔_c]

[yuzuha_微笑] 
[vo vo="ep1/yuzu_0177.ogg"]
#【小仓 柚叶】
「嗯，应该没事的」[p]

[vo vo="ep1/yuzu_0178.ogg"]
#【小仓 柚叶】
「在学校她已经表现得很平常了哦？」[p]

[yuzuha_哀]
[vo vo="ep1/yuzu_0179.ogg"]
#【小仓 柚叶】
「不过那个话题当然没再提起啦……」[p]
[yuzuha_哀_c]

[kokutou_疑問]
[vo vo="ep1/koku_0183.ogg"]
#【黒十 美鹤】
「也是呢，不提为妙」[p]

[vo vo="ep1/koku_0184.ogg"]
#【黒十 美鹤】
「请不要再将我卷入那种事情了好吗？」[p]
[kokutou_疑問_c]

[yuzuha_笑顔]
[vo vo="ep1/yuzu_0180.ogg"]
#【小仓 柚叶】
「哎呀～这个可不好说呢～？」[p]
[yuzuha_笑顔_c]

#
柚叶君愉快地笑着。[p]

;SE：扉オープン
[se_f se="door_op.ogg"]
正当我想对她发牢骚时，店门打开了。[p]

[yuzuha_微笑]
[vo vo="ep1/sayu_0072.ogg"]
#【稻饼 小百合】
「那个——打扰一下——」[p]

[kill]
[kokutou_疑問_c]
[ri_f cg="kokutou"]
[yuzuha_微笑_c]
[ce_f cg="yuzuha"]
[sayuri_微笑_c]
[le cg="sayuri"]

;SE：足音フェイドイン
[se_f se="footsteps_in.ogg"]

#
走进来的正是漩涡中心的女学生——稻饼小姐本人。[p]

[kokutou_真顔_c]

[yuzuha_驚き]
[vo vo="ep1/yuzu_0181.ogg"]
#【小仓 柚叶】
「小百合小姐，您怎么了！？」[p]
[yuzuha_驚き_c]

[sayuri_微笑]
[vo vo="ep1/sayu_0073.ogg"]
#【稻饼 小百合】
「啊，没事，我是想来致谢前几日的事」[p]
[sayuri_微笑_c]
#
她这样说着露出苦笑的模样[r]　
看上去比从前少了几分精气神。[p]

[yuzuha_驚き]
[vo vo="ep1/yuzu_0182.ogg"]
#【小仓 柚叶】
「道谢什么的完全不用啦！」[p]
[yuzuha_驚き_c]

[kokutou_哀]
[vo vo="ep1/koku_0185.ogg"]
#【黒十 美鹤】
「柚叶君明明什么都没做不是吗……」[p]
[kokutou_哀_c]

[yuzuha_笑顔]
[vo vo="ep1/yuzu_0183.ogg"]
#【小仓 柚叶】
「但介绍黑十先生解开谜题的人可是我呀！」[p]
[yuzuha_笑顔_c]

[kokutou_疑問]
[vo vo="ep1/koku_0186.ogg"]
#【黒十 美鹤】
「哈……好吧好吧」[p]
[kokutou_疑問_c]

[yuzuha_笑顔]
[vo vo="ep1/yuzu_0184.ogg"]
#【小仓 柚叶】
「啊，小百合小姐，请过来这边坐！」[p]
[yuzuha_笑顔_c]

[sayuri_微笑]
[vo vo="ep1/sayu_0074.ogg"]
#【稻饼 小百合】
「抱歉，打扰了」[p]
[sayuri_微笑_c]

#
稻饼小姐和初次来访时一样坐在我面前。[p]

但和那时相同，我不知道该说些什么才好。[p]

[kokutou_疑問]
[vo vo="ep1/koku_0187.ogg"]
#【黒十 美鹤】
「那个……这次该说是……运气不好吧」[p]
[kokutou_疑問_c]

[sayuri_哀]
[vo vo="ep1/sayu_0075.ogg"]
#【稻饼 小百合】
「……啊，是的」[p]
[sayuri_哀_c]

[kokutou_疑問]
[vo vo="ep1/koku_0188.ogg"]
#【黒十 美鹤】
「…………」[p]
[kokutou_疑問_c]

#
不行，无论说什么都可能导致更糟的局面。[p]

[yuzuha_怒]
[vo vo="ep1/yuzu_0185.ogg"]
#【小仓 柚叶】
「黑十先生，不说些更得体的话吗？」[p]
[yuzuha_怒_c]

[kokutou_疑問]
[vo vo="ep1/koku_0189.ogg"]
#【黒十 美鹤】
「这种事我怎么可能做得到啊！」[p]
[kokutou_疑問_c]

[yuzuha_驚き]

[sayuri_必死]
[vo vo="ep1/sayu_0076.ogg"]
#【稻饼 小百合】
「……那个！」[p]
[sayuri_必死_c]

#
仿佛要切断我和柚叶君之间的微妙氛围般，稻饼小姐提高了嗓音。[p]

[sayuri_微笑]
[vo vo="ep1/sayu_0077.ogg"]
#【稻饼 小百合】
「这次非常感谢你们」[p]

[vo vo="ep1/sayu_0078.ogg"]
#【稻饼 小百合】
「多亏两位的帮助，我才能知道一直困扰着我的谜团答案」[p]

[sayuri_哀]
[vo vo="ep1/sayu_0079.ogg"]
#【稻饼 小百合】
「………………虽然也知道了些不想知道的事」[p]
[sayuri_哀_c]

[yuzuha_微笑]
[vo vo="ep1/yuzu_0186.ogg"]
#【小仓 柚叶】
「啊哈哈，那个嘛...呃...」[p]
[yuzuha_微笑_c]

[sayuri_微笑]
[vo vo="ep1/sayu_0080.ogg"]
#【稻饼 小百合】
「不过我觉得，总比让谜题一直悬而未决要好」[p]

[vo vo="ep1/sayu_0081.ogg"]
#【稻饼 小百合】
「所以，小柚叶、黑十先生[r]　
　这次真的非常感谢」[p]
[sayuri_微笑_c]

[kokutou_真顔]
[vo vo="ep1/koku_0190.ogg"]
#【黒十 美鹤】
「既然稻饼小姐觉得满意，那我们也算没白忙活」[p]
[kokutou_真顔_c]

[yuzuha_笑顔]
[vo vo="ep1/yuzu_0187.ogg"]
#【小仓 柚叶】
「说得对！这件事就到此告一段落吧！」[p]
[yuzuha_笑顔_c]

[sayuri_微笑]
[vo vo="ep1/sayu_0082.ogg"]
#【稻饼 小百合】
「对了，这个...请收下，是黑糖铜锣烧」[p]
[sayuri_微笑_c]

;カットイン表示
[cut_in cut="cut_dora1.png"]


[kokutou_驚き]
[vo vo="ep1/koku_0191.ogg"]
#【黒十 美鹤】
「这不是...我最爱吃的吗！」[p]
[kokutou_驚き_c]

[sayuri_微笑]
[vo vo="ep1/sayu_0083.ogg"]
#【稻饼 小百合】
「嗯，因为知道你喜欢」[p]
[sayuri_微笑_c]

[kokutou_驚き]
[vo vo="ep1/koku_0192.ogg"]
#【黒十 美鹤】
「为什么稻饼小姐会知道我的喜好？」[p]
[kokutou_驚き_c]

[sayuri_微笑]
[vo vo="ep1/sayu_0084.ogg"]
#【稻饼 小百合】
「小柚叶说起黑十先生的时候，提到过」[p]
[sayuri_微笑_c]

;カットイン削除
[cut_out]

[kokutou_疑問]
[vo vo="ep1/koku_0193.ogg"]
#【黒十 美鹤】
「说起我？」[p]
[kokutou_疑問_c]

[yuzuha_驚き]

[sayuri_笑顔]
[vo vo="ep1/sayu_0085.ogg"]
#【稻饼 小百合】
「是的，小柚叶经常提起黑十先生――」[p]
[sayuri_笑顔_c]

[yuzuha_怒鳴る]
[vo vo="ep1/yuzu_0188.ogg"]
#【小仓 柚叶】
「哇！哇哇哇！！停——快停下！！」[p]

[yuzuha_怒]
[vo vo="ep1/yuzu_0189.ogg"]
#【小仓 柚叶】
「快、快看啊黑十先生！[r]　
　咖啡！快去泡些咖啡来嘛！」[p]

[yuzuha_笑顔]
[vo vo="ep1/yuzu_0190.ogg"]
#【小仓 柚叶】
「你不是总说黑糖铜锣烧要配咖啡吗！？[r]　
　快点快点啦！」[p]

[kokutou_微笑]
[vo vo="ep1/koku_0194.ogg"]
#【黒十 美鹤】
「呵呵呵，柚叶君你经常在谈论我的事情呢」[p]
[kokutou_微笑_c]

[yuzuha_怒鳴る]
[vo vo="ep1/yuzu_0191.ogg"]
#【小仓 柚叶】
「才、才没有经常在说呢？[r]　
　只是碰巧啦，碰巧！」[p]
[yuzuha_怒鳴る_c]

[sayuri_笑顔]
[vo vo="ep1/sayu_0086.ogg"]
#【稻饼 小百合】
「呵呵呵」[p]
[sayuri_笑顔_c]

[yuzuha_笑顔]
[vo vo="ep1/yuzu_0192.ogg"]
#【小仓 柚叶】
「比起那个你看！快去准备咖啡啦？」[p]
[yuzuha_笑顔_c]

[kokutou_微笑]
[vo vo="ep1/koku_0195.ogg"]
#【黒十 美鹤】
「好啦好啦，知道啦」[p]
[kokutou_微笑_c]

;SE：足音フェイドアウト
[se_f se="footsteps_out.ogg"]
#
看着难得脸红慌乱的柚叶君，我起身离席。[p]

;テキストウィンドウ削除
[end_text]

;全キャラ削除
[allc]

;背景
[bg  storage="kitchen.jpg" time="3000"]

[kokutou_真顔_c]
[ce cg="kokutou"]

;テキストウィンドウ表示
[start_text]

;SE：注ぐ
[se_f se="drink.ogg"]
#
准备好三个咖啡杯开始冲泡咖啡。[p]

这时才想起忘了询问砂糖和牛奶的调配方式。[p]


[kokutou_真顔]
[vo vo="ep1/koku_0196.ogg"]
#【黒十 美鹤】
「啊，对哦忘记问了」[p]
[kokutou_真顔_c]

#
记得稻饼小姐应该是喝黑咖啡的。[p]

[kokutou_疑問]
[vo vo="ep1/koku_0197.ogg"]
#【黒十 美鹤】
「柚叶君的话……三份砂糖，牛奶……」[p]
[kokutou_疑問_c]

#
是要加的？还是不加来着？[p]

[kokutou_哀]
[vo vo="ep1/koku_0198.ogg"]
#【黒十 美鹤】
「唔，要是弄错肯定又要被唠叨了[r]　
　……不过就算现在去问也免不了被数落吧」[p]
[kokutou_哀_c]

;SE：足音フェイドアウト
[se_f se="footsteps_out.ogg"]
#
无奈之下只好折返两人所在处。[p]

;テキストウィンドウ削除
[end_text]

;全キャラ削除
[allc]

;背景
[bg  storage="antique.jpg" time="3000"]

[kokutou_真顔_c]
[ri_f cg="kokutou"]
[yuzuha_微笑_c]
[ce_f cg="yuzuha"]
[sayuri_微笑_c]
[le cg="sayuri"]

;テキストウィンドウ表示
[start_text]

[kokutou_真顔]
[vo vo="ep1/koku_0199.ogg"]
#【黒十 美鹤】
「柚叶君」[p]
[kokutou_真顔_c]

[yuzuha_微笑]
[vo vo="ep1/yuzu_0193.ogg"]
#【小仓 柚叶】
「嗯？怎么了？」[p]
[yuzuha_微笑_c]

[kokutou_真顔]
[vo vo="ep1/koku_0200.ogg"]
#【黒十 美鹤】
「那个，牛奶是要加的吗？」[p]
[kokutou_真顔_c]

#
听到我的问题，柚叶君的嘴唇立刻抿成尖角。[p]

[kokutou_哀_c]
[yuzuha_怒_c]

再没有比这更明显的不满表情了。[p]

[yuzuha_怒]
[vo vo="ep1/yuzu_0194.ogg"]
#【小仓 柚叶】
「不加的！三份砂糖不加牛奶，就是这样！」[p]

[vo vo="ep1/yuzu_0195.ogg"]
#【小仓 柚叶】
「这个口味从遇见黑十先生那天起就没变过啦！」[p]
[yuzuha_怒_c]

[kokutou_疑問]
[vo vo="ep1/koku_0201.ogg"]
#【黒十 美鹤】
「咖啡偏好什么的我怎么可能记得住嘛」[p]
[kokutou_疑問_c]

[yuzuha_疑問]
[vo vo="ep1/yuzu_0196.ogg"]
#【小仓 柚叶】
「唔唔唔……」[p]
[yuzuha_疑問_c]

[sayuri_微笑]
[vo vo="ep1/sayu_0087.ogg"]
#【稻饼 小百合】
「哈哈，哎呀没办法嘛，小柚叶」[p]
[sayuri_微笑_c]

#
一脸不满的柚叶君和安抚她的稻饼小姐。[p]

;BGM停止
[bgm_end2]

[kokutou_真顔]
[vo vo="ep1/koku_0202.ogg"]
#【黒十 美鹤】
「…………」[p]
[kokutou_真顔_c]

#
望着这样的两人，我突然意识到一件事。[p]

[kokutou_真顔]
[vo vo="ep1/koku_0203.ogg"]
#【黒十 美鹤】
「……很奇怪呢」[p]
[kokutou_真顔_c]

[sayuri_微笑]
[vo vo="ep1/sayu_0088.ogg"]
#【稻饼 小百合】
「……嗯？奇怪？」[p]
[sayuri_微笑_c]

[yuzuha_疑問]
[vo vo="ep1/yuzu_0197.ogg"]
#【小仓 柚叶】
「嗯？黑十先生，您说的奇怪到底是指什么呢？」[p]
[yuzuha_疑問_c]

#
看到僵在原地的我，两人面面相觑。[p]

;BGM再生
[bgm ogg="tukikage_02.ogg"]

[kokutou_真顔]
[vo vo="ep1/koku_0204.ogg"]
#【黒十 美鹤】
「稻饼小姐，稻饼小姐为什么[r]　
　会知道黑糖铜锣烧是我的最爱呢？」[p]
[kokutou_真顔_c]

[sayuri_微笑]
[vo vo="ep1/sayu_0089.ogg"]
#【稻饼 小百合】
「那个，是从柚叶君那里听说的」[p]
[sayuri_微笑_c]

[yuzuha_微笑]
[vo vo="ep1/yuzu_0198.ogg"]
#【小仓 柚叶】
「对、对！刚才也是这么说的哦？」[p]

[vo vo="ep1/yuzu_0199.ogg"]
#【小仓 柚叶】
「这完全不算奇怪的事对吧？」[p]
[yuzuha_微笑_c]

[kokutou_真顔]
[vo vo="ep1/koku_0205.ogg"]
#【黒十 美鹤】
「是的，并不奇怪」[p]

[vo vo="ep1/koku_0206.ogg"]
#【黒十 美鹤】
「人的喜好这种东西[r]　
　通常不事先打听是不会知道的」[p]

[kokutou_疑問]
[vo vo="ep1/koku_0207.ogg"]
#【黒十 美鹤】
「但……」[p]
[kokutou_疑問_c]

#
唯独有个人从一开始就知道本该无从知晓的事。[p]

[kokutou_凛]
[vo vo="ep1/koku_0208.ogg"]
#【黒十 美鹤】
「……看来我[r]　
　又留下了一个重大谜团呢」[p]
[kokutou_凛_c]

#
事到如今，我才察觉到另一个谜题。[p]

[yuzuha_怒鳴る]
[vo vo="ep1/yuzu_0200.ogg"]
#【小仓 柚叶】
「重大谜团？这到底是什么意思！？」[p]
[yuzuha_怒鳴る_c]

[kokutou_凛]
[vo vo="ep1/koku_0209.ogg"]
#【黒十 美鹤】
「为什么她，不，是他……[r]　
　会知道柚叶君的咖啡口味呢？」[p]
[kokutou_凛_c]

#
御手洗庵。[p]

直到此刻，我才终于察觉到他真实的身份。[p]

;テキストウィンドウ削除
[end_text]

;全キャラ削除
[allc]

;見破った謎
[eval exp="sf.ep1_end2 = 1"]
[bg  storage="ep1_end2.png" time="2000"]

;処理を停止します
[wa]
[wait time=1000]
[p]

;BGM停止
[bgm_end3]

;背景：暗転
[bg30 bg="black.png"]

;タイトル画面へ移動
[jump  storage="title_screen.ks"  target="*title"]
[s]
