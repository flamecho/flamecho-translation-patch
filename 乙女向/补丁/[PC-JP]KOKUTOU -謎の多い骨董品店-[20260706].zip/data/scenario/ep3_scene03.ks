﻿;--------------------------------------------------
;■黒十　本文テキスト　ep3　御伽倶楽部
;--------------------------------------------------
;
;■ep3_scene03
;
;--------------------------------------------------
*013000
[savetitle text="御伽倶楽部って知ってる？"]
;-------------------------------------------------

;//黒背景
[bg10 bg="black.png"]

;SE：
[se_f se="07.ogg"]

;//下記台詞、生徒１の台詞
[vo vo="ep3/sei_0003.ogg"]
[layopt layer="0" visible="true"]
[mtext text="『ねぇ、御伽倶楽部って知ってる？』" size="38" width="1036" align="center" x="122" y="340" in_sync="true" out_sync="true" in_effect="fadeIn" out_effect="fadeOut" time="4000"]

;テキストウィンドウ表示
[start_text_yuzu]
#
我得知那个社团的传闻就在刚才。[p]

我偶然听到同学们在谈论那个社团的事情。[p]

御伽俱乐部。[p]

别说其活动内容了，甚至连如何加入这个社团都无人知晓。[p]

但其存在本身却被传得有模有样，正是一个谜一般的社团。[p]

;教室
[bg10 bg="school.jpg"]

;BGM再生
[bgm ogg="kaiko.ogg"]

[yuzuha_微笑_c]
[lec_f cg="yuzuha"]

[sayuri_微笑_c]
[ric cg="sayuri"]

[vo vo="ep3/yuzu_0077.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「听说有这样一个神秘的社团！」[p]

[vo vo="ep3/yuzu_0078.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「对吧！？　对吧！？　很在意吧！？」[p]
[yuzuha_微笑_c]

[vo vo="ep3/sayu_0013.ogg"]
[sayuri_疑問]
#【稻饼 小百合】
「唔~确实很在意……但真的有那种社团吗？」[p]
[sayuri_疑問_c]

[vo vo="ep3/yuzu_0079.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「虽然不知道真假……但正因为不知道才让人在意啊！」[p]

[vo vo="ep3/yuzu_0080.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「那个神秘社团的真面目……一起去揭开吧！」[p]
[yuzuha_笑顔_c]

[vo vo="ep3/sayu_0014.ogg"]
[sayuri_笑顔]
#【稻饼 小百合】
「啊哈哈，已经干劲十足了呢」[p]
[sayuri_笑顔_c]

[vo vo="ep3/yuzu_0081.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「诶嘿嘿……因为实在是在意得不得了」[p]

[vo vo="ep3/yuzu_0082.ogg"]
#【小仓 柚叶】
「没想到这所学校里居然藏着这样的谜团！」[p]
[yuzuha_微笑_c]

[vo vo="ep3/sayu_0015.ogg"]
[sayuri_疑問]
#【稻饼 小百合】
「不过，你打算怎么找呢？」[p]
[sayuri_疑問_c]

[vo vo="ep3/yuzu_0083.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「嗯……首先……」[p]

[vo vo="ep3/yuzu_0084.ogg"]
#【小仓 柚叶】
「总之先看看现有的社团列表吧！」[p]

[vo vo="ep3/yuzu_0085.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「说不定学生手册上会有写呢」[p]
[yuzuha_疑問_c]

[vo vo="ep3/sayu_0016.ogg"]
[sayuri_驚き]
#【稻饼 小百合】
「啊，等一下」[p]
[sayuri_驚き_c]

#
小百合小姐拦住了我正要掏胸前口袋的手。[p]

[vo vo="ep3/sayu_0017.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「我觉得现在现存的社团列表应该在教务室」[p]

[vo vo="ep3/sayu_0018.ogg"]
[sayuri_笑顔]
#【稻饼 小百合】
「瞧，就是新生和转学生用的资料上见过的那些吧」[p]
[sayuri_笑顔_c]

[vo vo="ep3/yuzu_0086.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「啊，原来如此！」[p]
[yuzuha_笑顔_c]

#
确实，我记得自己转学时也拿到过。[p]

[vo vo="ep3/sayu_0019.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「要确认的话最新资料最好吧，我去拿过来」[p]
[sayuri_微笑_c]

;SE：去る足音
[se_f se="footsteps_out.ogg"]

;//稲餅さゆりが去る
;キャラ消去
[chara_hide name=sayuri]

[vo vo="ep3/yuzu_0087.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「啊……啊哈哈，还是这么雷厉风行……真厉害呢」[p]
[yuzuha_驚き_c]

#
而我却一步都迈不动。[p]

;//時間経過・場面移動
;テキストウィンドウ削除
[end_text]

;全キャラ削除
[allc]

;//黒ベタ
[bg10 bg="black.png"]

;//停止
[wait time=2000]

;//教室
[bg10 bg="school.jpg"]

[yuzuha_微笑_c]
[lec_f cg="yuzuha"]

[sayuri_微笑_c]
[ric cg="sayuri"]

;テキストウィンドウ表示
[start_text_yuzu]

[vo vo="ep3/sayu_0020.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「呃……资料倒是拿来了不过……」[p]
[sayuri_微笑_c]

#
和小百合小姐一起盯着资料看。[p]

[vo vo="ep3/yuzu_0088.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「御伽俱乐部的名字当然没找到，[r]　
　连像那么回事的社团都没发现呢」[p]
[yuzuha_疑問_c]

#
从上到下逐条确认，果然还是找不到。[p]

[vo vo="ep3/yuzu_0089.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「学校的社团这里都列全了吗？」[p]
[yuzuha_疑問_c]

[vo vo="ep3/sayu_0021.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「嗯，拿资料时跟老师确认过应该没错」[p]
[sayuri_微笑_c]

[vo vo="ep3/yuzu_0090.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「呵呵呵……原来如此原来如此」[p]
[yuzuha_微笑_c]

#
我不由自主地露出了笑容。[p]

看到我这副模样，小百合小姐露出了苦笑。[p]

[vo vo="ep3/sayu_0022.ogg"]
[sayuri_呆れ]
#【稻饼 小百合】
「小柚叶？看你好像挺开心的……」[p]
[sayuri_呆れ_c]

[vo vo="ep3/yuzu_0091.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「因为要是真写在上面就太无趣了吧！」[p]

[vo vo="ep3/yuzu_0092.ogg"]
#【小仓 柚叶】
「完全算不上什么谜团了！」[p]

[vo vo="ep3/yuzu_0093.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「谜题就该是这样的才对！！」[p]
[yuzuha_笑顔_c]

[vo vo="ep3/sayu_0023.ogg"]
[sayuri_呆れ]
#【稻饼 小百合】
「啊哈哈，不过接下来怎么办？」[p]
[sayuri_呆れ_c]

[vo vo="ep3/yuzu_0094.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「确实……连寻找的线索都没有了呢」[p]
[yuzuha_哀_c]

#
我们互相歪着头思索起来。[p]

[vo vo="ep3/yuzu_0095.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「从御伽这个词推测，应该还是和故事有关吧？」[p]
[yuzuha_疑問_c]

[vo vo="ep3/sayu_0024.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「这是指文艺方面吗？」[p]

[vo vo="ep3/sayu_0025.ogg"]
#【稻饼 小百合】
「如果是这样的话，虽然也有文艺部、古典部之类的」[p]
[sayuri_微笑_c]

#
小百合小姐低头看着拿来的资料说道。[p]

[vo vo="ep3/yuzu_0096.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「会不会是这类社团的俗称呢？」[p]
[yuzuha_疑問_c]

[vo vo="ep3/sayu_0026.ogg"]
[sayuri_疑問]
#【稻饼 小百合】
「唔~这两个社团都有认识的人，但没听说过呢」[p]
[sayuri_疑問_c]

[vo vo="ep3/yuzu_0097.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「那么……到底是什么呢？」[p]
[yuzuha_疑問_c]

#
再次思考却完全摸不着头脑。[p]

;BGM停止
[bgm_end2]

[vo vo="ep3/yuzu_0098.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「………………咦？」[p]
[yuzuha_疑問_c]

#
漫长的沉默后，突然袭来莫名的违和感。[p]

是往常该发生却未发生的违和感。[p]

[vo vo="ep3/sayu_0027.ogg"]
[sayuri_疑問]
#【稻饼 小百合】
「小柚叶？怎么了？」[p]
[sayuri_疑問_c]

[vo vo="ep3/yuzu_0099.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「……啊，原来如此」[p]
[yuzuha_驚き_c]

#
稍后终于察觉到了这份违和感的真面目。[p]

平时这种时候黑十先生本该察觉到什么开始发言的。[p]

或者应该正是发现奇怪古董的时机。[p]

;BGM再生
[bgm ogg="kaiko.ogg"]

[vo vo="ep3/yuzu_0100.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「要是黑十先生在就好了……」[p]
[yuzuha_哀_c]

[vo vo="ep3/sayu_0028.ogg"]
[sayuri_笑顔]
#【稻饼 小百合】
「啊，呵呵呵，确实呢」[p]
[sayuri_笑顔_c]

#
或许是察觉到我的想法，小百合小姐掩着嘴笑了。[p]

[vo vo="ep3/sayu_0029.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「如果是黑十先生的话，说不定能解开这个谜题」[p]
[sayuri_微笑_c]

#
但遗憾的是，现在黑十先生并不在场。[p]

看来只能靠我们自己想办法了。[p]

[vo vo="ep3/yuzu_0101.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「御伽倶楽部……御伽……这个御伽、[r]　
　是指童话的意思吧？」[p]
[yuzuha_疑問_c]

[vo vo="ep3/sayu_0030.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「大概是这样……比如桃太郎啊，小红帽之类的」[p]
[sayuri_微笑_c]

[vo vo="ep3/yuzu_0102.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「小时候在绘本里读过的那些呢！」[p]
[yuzuha_微笑_c]

[vo vo="ep3/sayu_0031.ogg"]
[sayuri_笑顔]
#【稻饼 小百合】
「呵呵，是啊，我以前很喜欢格林童话呢」[p]
[sayuri_笑顔_c]

[vo vo="ep3/yuzu_0103.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「诶～格林是灰姑娘和白雪公主那个对吧？」[p]
[yuzuha_微笑_c]

[vo vo="ep3/sayu_0032.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「对对，有很多可爱又有魅力的登场角色呢」[p]
[sayuri_微笑_c]

[vo vo="ep3/yuzu_0104.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「有魅力的角色啊……嗯？角色……」[p]
[yuzuha_疑問_c]

#
民间故事的登场角色。[p]

[vo vo="ep3/yuzu_0105.ogg"]
[yuzuha_怒鳴る]
#【小仓 柚叶】
「……啊咧？啊、啊啊啊——！！」[p]
[yuzuha_怒鳴る_c]

#
那已经纯属偶然了。[p]

倏然间闪现在脑海的词汇。[p]

[vo vo="ep3/yuzu_0106.ogg"]
[yuzuha_怒鳴る]
#【小仓 柚叶】
「可能知道和御伽倶楽部有关的人是谁了！！」[p]
[yuzuha_怒鳴る_c]

[vo vo="ep3/sayu_0033.ogg"]
[sayuri_驚き]
#【稻饼 小百合】
「欸，真的吗？」[p]
[sayuri_驚き_c]

[vo vo="ep3/yuzu_0107.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「嗯！」[p]
[yuzuha_笑顔_c]


#
点头的同时，我用手机确认了时间。[p]

[sayuri_哀]

现在是午休时分。[p]

[vo vo="ep3/yuzu_0108.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「小百合小姐，我们赶快去爱丽丝学姐和辉夜学姐那里吧！」[p]
[yuzuha_笑顔_c]

[vo vo="ep3/sayu_0034.ogg"]
[sayuri_驚き]
#【稻饼 小百合】
「诶？去学姐们那里？」[p]
[sayuri_驚き_c]

[vo vo="ep3/yuzu_0109.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「呃……爱丽丝学姐现在会在哪里呢？」[p]
[yuzuha_疑問_c]

;シーン4へ移動
[jump  storage="ep3_scene04.ks"]
[s]