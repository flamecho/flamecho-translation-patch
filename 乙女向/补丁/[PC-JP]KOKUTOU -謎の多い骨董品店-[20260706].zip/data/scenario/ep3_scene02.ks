﻿;--------------------------------------------------
;■黒十　本文テキスト　ep3　御伽倶楽部
;--------------------------------------------------
;
;■ep3_scene02
;
;--------------------------------------------------
*011000
[savetitle text="男の人の声が聞こえた"]
;-------------------------------------------------

;//ここから柚葉視点。[p]
;//黒十同様に柚葉が過去の夢を見ている。[p]

;BGM再生
[bgm ogg="cellar.ogg"]

;背景
[bg storage="dream_2.jpg" time="3000"]

;テキストウィンドウ表示
[start_text_dream]

;夢用フォント設定
[font color="0x333333" shadow="0xffffff"]
[vo vo="ep3/yuzu_0001.ogg"]
#
『呐，那幅画为什么破了呀？』[p]

现在想来 问题的内容是什么都无所谓。[p]

无论是母亲大人 还是姐姐们 或是其他任何人都行。[p]

只要有人能解答我的疑问就好了。[p]

可是没人愿意听我的疑问。[p]

没人愿意看我一眼。[p]

没人为我的问题给出答案。[p]

啊啊 这样简直就像透明人一样呢 我这样想着。[p]

无论做什么都得不到回应 不被任何人发现。[p]

感觉自己的色彩正在渐渐消失。[p]

身体逐渐变冷 呼吸逐渐窒息的 那种感觉。[p]

[bgm_end1]

[vo vo="ep3/koku_0002.ogg"]
『那幅画并不是破了哦』[p]

;背景
[bg storage="dream.jpg" time="3000"]

传来了男人的声音。[p]

那声音简直就像 为透明的我涂上了色彩。[p]

我这样想道。[p]

;BGM再生
[bgm ogg="kaiko.ogg"]
[vo vo="ep3/yuzu_0002.ogg"]
#【小仓 柚叶】
「……咦？」[p]

[vo vo="ep3/koku_0003.ogg"]
#【青年】
「卡拉库尔……[r]　
因干燥和年久风化导致颜料裂开了」[p]

[vo vo="ep3/yuzu_0003.ogg"]
#【小仓 柚叶】
「卡拉……库尔？」[p]

[vo vo="ep3/koku_0004.ogg"]
#【青年】
「卡拉库尔……说到底，那并不是破损」[p]

[vo vo="ep3/koku_0005.ogg"]
#【青年】
「只是表层颜料产生了裂纹而已」[p]

[vo vo="ep3/yuzu_0004.ogg"]
#【小仓 柚叶】
「……原来如此，我明白了」[p]

#
那个人是位比我年长许多的人。[p]

但和迄今为止见过的所有大人都不同。[p]

那人俯视着我轻叹了一声。[p]

[vo vo="ep3/yuzu_0005.ogg"]
#【小仓 柚叶】
「…………」[p]

#
就是这个人解答了我的疑问。[p]

[vo vo="ep3/koku_0006.ogg"]
#【青年】
「……嗯？」[p]

#
回过神来时窒息感已然消失。[p]

那里只剩晴空般的爽快感。[p]

[vo vo="ep3/yuzu_0007.ogg"]
#【小仓 柚叶】
「…………」[p]

#
是这个人让我明白[r]　
有人教导未知事物的喜悦。[p]

[vo vo="ep3/yuzu_0008.ogg"]
#【小仓 柚叶】
「谢谢你啦！」[p]

[vo vo="ep3/yuzu_0009.ogg"]
#【小仓 柚叶】
「搞懂不明白的事情，整个人都舒畅了！」[p]

[vo vo="ep3/koku_0007.ogg"]
#【青年】
「啊、啊哈，那个……不客气」[p]

[vo vo="ep3/yuzu_0010.ogg"]
#【小仓 柚叶】
「那再见啦！大哥哥！」[p]

#
存在着教导我未知事物的人。[p]

那就是有人在关注着我的证据。[p]

;テキストウィンドウ削除
[end_text]

[resetfont]

;BGM停止
[bgm_end2]

;//ホワイトアウト
[bg10 bg="white.png"]

;//夢ここまで
;//徐々に夢から覚めていく

;//黒ベタ
[bg10 bg="black.png"]

;テキストウィンドウ表示
[start_text_yuzu]

[vo vo="ep3/tea_0001.ogg"]
;//柚葉を起こす教師の声（女性）
#【？？？】
「……仓……桑」[p]

#
听见了熟悉的声音。[p]

[vo vo="ep3/tea_0002.ogg"]
#【？？？】
「小……仓桑！」[p]

#
咦？难道在叫我？[p]

[vo vo="ep3/tea_0003.ogg"]
;//柚葉を起こす教師の声（女性）
#【？？？】
「小仓桑！」[p]

[vo vo="ep3/yuzu_0042.ogg"]
#【小仓 柚叶】
「……哈？」[p]

;//教室
;//眠っていた柚葉が起きる
[bg10 bg="school.jpg"]

#
被叫到名字抬起头时，眼前是教室。[p]

[yuzuha_疑問]
[ce cg="yuzuha"]

;BGM再生
[bgm ogg="mid_re.ogg"]

[vo vo="ep3/yuzu_0043.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「……咦？呃——」[p]
[yuzuha_微笑_c]

[vo vo="ep3/tea_0004.ogg"]
#【教师】
「咦？才没有呢，真是的」[p]

[yuzuha_驚き]

#
看样子似乎在上课时睡着了。[p]

「搞砸了啊」挠着头苦笑道。[p]

周围的同学们看着这样的我轻轻笑了。[p]

不妙不妙。[p]

[vo vo="ep3/yuzu_0044.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「对不起……那个，刚才说到哪里？」[p]
[yuzuha_微笑_c]

[vo vo="ep3/tea_0005.ogg"]
#【教师】
「教科书72页……」[p]

#
糟了，遇到只告诉页码的棘手情况了。[p]

因为睡着了不知道被提问的是哪道题。[p]

哎呀哎呀，这可怎么办。[p]

;全キャラ削除
[kill]

;さゆり衣装指定
[sayuri_c_秋]

[yuzuha_微笑_c]
[lec_f cg="yuzuha"]

[sayuri_微笑]
[ric cg="sayuri"]

[vo vo="ep3/sayu_0001.ogg"]
#【稻饼 小百合】
「咳哼……」[p]
[sayuri_微笑_c]

#
正这么想着时，旁边传来稍显做作的清嗓声。[p]

只见小百合小姐正用指尖轻轻点着笔记本边缘。[p]

干得漂亮！超～级漂亮！[p]

[vo vo="ep3/yuzu_0045.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「啊～是第二题对吧～！那个～……」[p]
[yuzuha_笑顔_c]

#
照着从小百合小姐那里看到的答案念了出来。[p]

老师虽然微微皱眉，但也没再追究。[p]

;SE：チャイム
[se_f se="school_bell.ogg"]


最后的下课铃声就这样结束了课堂。[p]


;//時間経過
;テキストウィンドウ削除
[end_text]

;全キャラ削除
[allc]

;//黒ベタ
[bg10 bg="black.png"]

;//停止
[wait time=2000]

;--------------------------------------------------
*012000
[savetitle text="嫌な予感が……"]
;-------------------------------------------------

;//教室
[bg10 bg="school.jpg"]

[yuzuha_笑顔_c]
[lec_f cg="yuzuha"]

[sayuri_微笑_c]
[ric cg="sayuri"]

;テキストウィンドウ表示
[start_text_yuzu]

[vo vo="ep3/yuzu_0046.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「呼……小百合小姐，谢谢你～」[p]
[yuzuha_笑顔_c]

#
课间时分，立刻向隔壁的小百合小姐道谢。[p]

[vo vo="ep3/yuzu_0047.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「完全没听课差点就完蛋了」[p]
[yuzuha_微笑_c]

[vo vo="ep3/sayu_0002.ogg"]
[sayuri_笑顔]
#【稻饼 小百合】
「呵呵，因为小柚叶睡得很香嘛」[p]
[sayuri_笑顔_c]

[vo vo="ep3/yuzu_0048.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「啊哈哈，真是惭愧」[p]
[yuzuha_微笑_c]

[vo vo="ep3/sayu_0003.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「你是不是做了什么梦？」[p]
[sayuri_微笑_c]

[vo vo="ep3/yuzu_0049.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「诶？」[p]
[yuzuha_驚き_c]

[vo vo="ep3/sayu_0004.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「因为你的表情看起来超级幸福呢」[p]
[sayuri_微笑_c]

[vo vo="ep3/yuzu_0050.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「嗯～……是吗？」[p]
[yuzuha_疑問_c]

[vo vo="ep3/sayu_0005.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「嗯，其实本来想在你被猜中前叫醒你的」[p]

[vo vo="ep3/sayu_0006.ogg"]
#【稻饼 小百合】
「但是小柚叶，[r]　
　你睡得实在太香甜了，怎么也舍不得叫醒」[p]
[sayuri_微笑_c]

[vo vo="ep3/yuzu_0051.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「啊哈哈……好难为情呀」[p]
[yuzuha_微笑_c]

#
我原来露出了那么幸福的表情吗。[p]

不过确实。[p]

那时候真的非常幸福。[p]

与那个人的相遇改变了我的一切。[p]

甚至让我产生这样的感慨。[p]

[vo vo="ep3/sayu_0007.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「所以到底是什么梦呀？」[p]
[sayuri_微笑_c]

[vo vo="ep3/yuzu_0052.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「啊～……嘿嘿，就当是我们的秘密好不好……嗯？」[p]
[yuzuha_微笑_c]

[bgm_end2]


[yuzuha_疑問_c]

#
这时走廊方向突然传来嘈杂的声响。[p]

难道又来了吗。[p]

[vo vo="ep3/sayu_0008.ogg"]
[sayuri_微笑]
#【稻饼 小百合】
「小柚叶？怎么了？」[p]
[sayuri_微笑_c]

[vo vo="ep3/yuzu_0053.ogg"]
[yuzuha_哀]
#【小仓 柚叶】
「哎呀～总觉得有种不祥的预感……」[p]
[yuzuha_哀_c]

;全キャラ削除
[allc]

#
紧接着走廊的喧嚷声逐渐向这里逼近。[p]

然后――[p]

;BGM再生
[bgm ogg="tukikage.ogg"]

[alice_真顔]
[ce cg="alice"]

;//下記は飴宮アリス
[vo vo="ep3/alice_0001.ogg"]
#【？？？】
「打扰了，小仓柚叶在吗？」[p]
[alice_真顔_c]

#
她，饴宫爱丽丝出现了。[p]

[vo vo="ep3/sei_0001.ogg"]
#【学生1】
「爱、爱丽丝大人来了……！是饴宫集团的千金！」[p]

[vo vo="ep3/sei2_0001.ogg"]
#【学生2】
「哇……真是美丽得令人窒息……」[p]

#
随着她的登场，四周响起一片赞叹之声。[p]

被饴宫爱丽丝搭话的学生更是僵在原地无法动弹。[p]

[vo vo="ep3/alice_0002.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「哎呀，没事吧？能听见我说话吗？」[p]
[alice_真顔_c]

[vo vo="ep3/sei3_0001.ogg"]
#【学生3】
「是、是的，非常抱歉……！那、那个那个……！」[p]

[vo vo="ep3/alice_0003.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「呵呵，不用这么慌张也没关系的，[r]　
　不是什么难题吧？」[p]

[vo vo="ep3/alice_0004.ogg"]
#【饴宫 爱丽丝】
「我只向你提了一个小小的问题哦？」[p]

[vo vo="ep3/alice_0005.ogg"]
#【饴宫 爱丽丝】
「‘小仓柚叶在这儿吗’」[p]
[alice_笑み_c]

#
她那刻意做作的说话方式让人后背发痒。[p]

但被问话的学生却莫名满脸通红眼眶湿润。[p]

[vo vo="ep3/sei3_0002.ogg"]
#【学生3】
「是、是的……小仓同学的话，就在那边」[p]

[kill]

[yuzuha_微笑_c]
[lec_f cg="yuzuha"]

[alice_笑み_c]
[ric cg="alice"]

#
被询问的学生将指尖转向这个方向。[p]

于是饴宫爱丽丝的视线贯穿了我。[p]

[vo vo="ep3/alice_0006.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「日安，小仓柚叶」[p]
[alice_笑み_c]

[vo vo="ep3/yuzu_0054.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「……啊～，你好」[p]
[yuzuha_微笑_c]

[vo vo="ep3/alice_0007.ogg"]
[alice_真顔]
#【饴宫 爱丽丝】
「哎呀，这么冷淡的问候我可从没听过呢」[p]
[alice_真顔_c]

[vo vo="ep3/yuzu_0055.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「……您、您好——」[p]
[yuzuha_微笑_c]

[vo vo="ep3/alice_0008.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「呵呵，日安，对学姐要好好打招呼才行哦」[p]
[alice_笑み_c]

#
那双色素淡薄得不可思议、宛若人偶般的眼睛正注视着我。[p]

但那份美丽却像野生动物般透着锐利。[p]

[vo vo="ep3/yuzu_0056.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「那个……所以学姐特地来低年级教室是有什么事吗？」[p]
[yuzuha_微笑_c]

[vo vo="ep3/alice_0009.ogg"]
[alice_ドヤ顔]
#【饴宫 爱丽丝】
「没有啦，只是想问你要不要参加今天的茶会[r]　
　才来邀请你的哟」[p]

[vo vo="ep3/alice_0010.ogg"]
#【饴宫 爱丽丝】
「上次不是被你拒绝了吗？」[p]
[alice_ドヤ顔_c]

#
虽然用着困扰的措辞，[r]　
她脸上却挂着带挑衅意味的笑容。[p]

简直就像在说「有本事你就再拒绝看看」。[p]

[vo vo="ep3/alice_0011.ogg"]
[alice_ドヤ顔]
#【饴宫 爱丽丝】
「刚好入手了好茶叶……怎么样？今天午休时在中庭的露台」[p]
[alice_ドヤ顔_c]

#
问得再多答案也不会改变。[p]

[vo vo="ep3/yuzu_0057.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「我拒绝」[p]
[yuzuha_微笑_c]

[alice_驚き_c]

#
秒答引得周围学生骚动起来。[p]

个中缘由我倒也明白。[p]

在这所学校里举办茶会[r]　
本身就是件颇有深意的事。[p]

[vo vo="ep3/alice_0012.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「哎呀？是有什么安排吗？」[p]
[alice_笑み_c]

[vo vo="ep3/yuzu_0058.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「不，并没有什么特别的事」[p]

[vo vo="ep3/yuzu_0059.ogg"]
#【小仓 柚叶】
「只是正如我上次明确说过的[r]　
　我并没有要加入学姐派系的打算」[p]
[yuzuha_微笑_c]

#
我的回应使得周围学生们的骚动愈发明显。[p]

上流阶级聚集的这所学校茶会[r]　
实则蕴含着加入那个派系的强烈意味。[p]

其他如社团活动和委员会也带有类似强烈意图。[p]

[vo vo="ep3/yuzu_0060.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「所以很抱歉，请您另寻他人吧」[p]
[yuzuha_微笑_c]

#
我无意与上流阶级结党。[p]

更别说派系之类的东西根本敬谢不敏。[p]

但小仓之名的吸引力似乎超乎想象[r]　
这类邀请始终络绎不绝。[p]

[kill]

[sayuri_微笑_c]
[ce cg="sayuri"]

[vo vo="ep3/sei2_0002.ogg"]
#【学生2】
「稻饼小姐，您刚才听到了吗！？」[p]

[vo vo="ep3/sayu_0009.ogg"]
[sayuri_驚き]
#【稻饼 小百合】
「诶？嗯、嗯，是听到了啦……」[p]
[sayuri_驚き_c]

[vo vo="ep3/sei2_0003.ogg"]
#【学生2】
「您竟然拒绝了那位爱丽丝大人的邀请……难以置信！」[p]

[vo vo="ep3/sayu_0010.ogg"]
[sayuri_驚き]
#【稻饼 小百合】
「咦……很、很严重吗？但不愿意的话也没办法吧？」[p]
[sayuri_驚き_c]

#
身后传来小百合小姐的声音。[p]

小百合小姐这种地方正是我最喜欢的。[p]

[vo vo="ep3/sei2_0004.ogg"]
#【学生2】
「不进爱丽丝大人的派系简直难以想象！」[p]

[vo vo="ep3/sei_0002.ogg"]
#【学生1】
「不对哦[r]　
　小仓小姐是要自己组建派系呀！」[p]

[vo vo="ep3/sei2_0005.ogg"]
#【学生2】
「哎呀，是这样吗！？」[p]

[vo vo="ep3/sayu_0011.ogg"]
[sayuri_呆れ]
#【稻饼 小百合】
「啊、哈哈，问我也……」[p]
[sayuri_哀_c]

[kill]

[yuzuha_微笑_c]
[lec_f cg="yuzuha"]

[alice_笑み_c]
[ric cg="alice"]

#
喧嚣声中。[p]

但处于漩涡中心的爱丽丝学姐始终保持着完美微笑。[p]

这份游刃有余的表情才最令人困扰。[p]

[vo vo="ep3/alice_0013.ogg"]
[alice_笑み]
#【饴宫 爱丽丝】
「小仓柚叶……你迟早会主动来的」[p]
[alice_笑み_c]

[vo vo="ep3/yuzu_0061.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「咦？……啊~不过我没打算去啦」[p]
[yuzuha_微笑_c]

[vo vo="ep3/alice_0014.ogg"]
[alice_ドヤ顔]
#【饴宫 爱丽丝】
「呵呵……谁知道呢」[p]
[alice_ドヤ顔_c]

[bgm_end2]

;キャラ消去
[chara_hide name=alice]

#
简短回应后，爱丽丝前辈离开了现场。[p]

终于从麻烦事中解脱般长舒一口气。[p]

[vo vo="ep3/alice_0015.ogg"]
#【饴宫 爱丽丝】
「要走了哦，辉夜」[p]

#
爱丽丝前辈走出教室时，唤着某个人的名字。[p]

随后被爱丽丝前辈称作辉夜的少女穿过走廊。[p]

[kaguya_笑み_c]
[ric cg="kaguya"]

[vo vo="ep3/yuzu_0062.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「……咦？」[p]
[yuzuha_驚き_c]

#
那人正是咖啡店里邂逅的黑发少女。[p]


;//時間経過・場面移動
;テキストウィンドウ削除
[end_text]

;全キャラ削除
[allc]

;//黒ベタ
[bg10 bg="black.png"]

;//停止
[wait time=1000]

;//廊下
[bg10 bg="corridor.jpg"]

;BGM再生
[bgm ogg="the_window_overlooking_all_things.ogg"]

[yuzuha_笑顔_c]
[lec_f cg="yuzuha"]

[kaguya_無表情_c]
[ric cg="kaguya"]

;テキストウィンドウ表示
[start_text_yuzu]


[vo vo="ep3/yuzu_0063.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「真吃惊，没想到会以这种方式重逢！」[p]
[yuzuha_笑顔_c]


;特殊カットイン表示
[cutbg_in bgin="cut_ep2.png"]


#
之前和黑十先生去咖啡店时遇到的女性。[p]


与某个谜团一同坐在座位上[r]　
那道侧脸至今仍清晰记得。[p]


因为穿着相同制服[r]　
虽然想过可能会在学校遇见。[p]

但完全没料到会在那种时机相遇。[p]

;特殊カットイン消去
[cutbg_out]

[vo vo="ep3/yuzu_0064.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「啊、我是小仓柚叶！那个……」[p]
[yuzuha_微笑_c]

[vo vo="ep3/kaguya_0001.ogg"]
[kaguya_無表情]
#【蓬 辉夜】
「辉夜……蓬辉夜」[p]
[kaguya_無表情_c]

[vo vo="ep3/yuzu_0065.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「是辉夜学姐呢，呃……和爱丽丝前辈是朋友吗？」[p]
[yuzuha_微笑_c]

[vo vo="ep3/kaguya_0002.ogg"]
[kaguya_無表情]
#【蓬 辉夜】
「嘛，差不多吧」[p]
[kaguya_無表情_c]

[vo vo="ep3/yuzu_0066.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「该不会……果然早就知道我吗？」[p]
[yuzuha_微笑_c]

[vo vo="ep3/kaguya_0003.ogg"]
[kaguya_呆れ]
#【蓬 辉夜】
「你该不会对名人身份没自觉吧」[p]

[vo vo="ep3/kaguya_0004.ogg"]
[kaguya_無表情]
#【蓬 辉夜】
「你多次拒绝加入爱丽丝的派系，这在学院里可是出名的哦」[p]
[kaguya_無表情_c]

[vo vo="ep3/yuzu_0067.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「啊、哈哈哈……嘛……」[p]
[yuzuha_微笑_c]

#
我并不想如此引人注目。[p]

[vo vo="ep3/kaguya_0005.ogg"]
[kaguya_無表情]
#【蓬 辉夜】
「爱丽丝虽然看起来那样，其实很固执，肯定还会再来的吧」[p]
[kaguya_無表情_c]

[vo vo="ep3/yuzu_0068.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「呜哇……果、果然」[p]
[yuzuha_微笑_c]

#
辉夜前辈的话让我更加消沉了。[p]

[vo vo="ep3/kaguya_0006.ogg"]
[kaguya_笑み_c]
#【蓬 辉夜】
「呵呵」[p]

#
笑着这样的我，辉夜前辈转身离去。[p]

[vo vo="ep3/kaguya_0007.ogg"]
[kaguya_無表情]
#【蓬 辉夜】
「对了，有件事……我要给你个建议」[p]
[kaguya_無表情_c]

[vo vo="ep3/yuzu_0069.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「好、好的……？」[p]
[yuzuha_微笑_c]

[vo vo="ep3/kaguya_0008.ogg"]
[kaguya_無表情]
#【蓬 辉夜】
「你可要当心爱丽丝」[p]
[kaguya_無表情_c]

[vo vo="ep3/yuzu_0070.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「好、好的……谢、谢谢」[p]
[yuzuha_微笑_c]

;キャラ消去
[chara_hide name=kaguya]

;SE：去る足音
[se_f se="footsteps_out.ogg"]

#
留下这句话后，辉夜前辈离开了。[p]

[vo vo="ep3/yuzu_0071.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「哎呀哎呀？」[p]
[yuzuha_疑問_c]

#
说要当心是什么意思呢。[p]

[vo vo="ep3/yuzu_0072.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「是说避免见面吗？」[p]
[yuzuha_疑問_c]

#
试着思考也不明白。[p]

[vo vo="ep3/yuzu_0073.ogg"]
[yuzuha_驚き]
#【小仓 柚叶】
「啊，糟了，我也得回教室了！」[p]
[yuzuha_驚き_c]

#
急忙迈步向教室赶去。[p]

就在这时。[p]

;BGM停止
[bgm_end1]

[vo vo="ep3/yuzu_0074.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「……嗯嗯？」[p]
[yuzuha_微笑_c]

#
突然感受到某人的视线。[p]

环顾四周却没有人在。[p]

[vo vo="ep3/yuzu_0075.ogg"]
[yuzuha_疑問]
#【小仓 柚叶】
「嗯嗯嗯～？哎呀哎呀呀？」[p]
[yuzuha_疑問_c]

#
回想起方才辉夜前辈的话语。[p]

[vo vo="ep3/kaguya_0008.ogg"]
『对爱丽丝务必要多加小心』[p]

或许是因为听到那样的话，[r]　
我变得异常神经质。[p]

[sayuri_微笑]
[ric cg="sayuri"]

[vo vo="ep3/sayu_0012.ogg"]
#【稻饼 小百合】
「小柚叶，怎么了？上课要迟到了哦」[p]
[sayuri_微笑_c]

#
这时小百合小姐走了过来。[p]

大概是出于担心才来的吧。[p]

[vo vo="ep3/yuzu_0076.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「唔嗯没什么，这就去！」[p]
[yuzuha_笑顔_c]

#
果然只是心理作用吧。[p]

匆忙追赶着小百合小姐的背影。[p]

;全キャラ削除
[allc]

;//時間経過・場面移動
;テキストウィンドウ削除
[end_text]

;//黒ベタ
[bg10 bg="black.png"]

;//停止
[wait time=2000]

;//同じ場所
[bg10 bg="corridor.jpg"]

;テキストウィンドウ表示
[start_text_yuzu]


;//下記の台詞は御手洗庵
[vo vo="ep3/iori_0001.ogg"]
#【？？？】
「呼～、好险好险」[p]

[vo vo="ep3/iori_0002.ogg"]
#【？？？】
「不过，这样啊……稻饼小姐也在来着啊」[p]

[vo vo="ep3/iori_0003.ogg"]
#【？？？】
「这个看来得更小心点才行呢……嘿嘿」[p]

;//時間経過・場面移動
;テキストウィンドウ削除
[end_text]

;全キャラ削除
[allc]

;//黒ベタ
[bg10 bg="black.png"]

;//停止
[wait time=2000]


;シーン3へ移動
[jump  storage="ep3_scene03.ks"]
[s]