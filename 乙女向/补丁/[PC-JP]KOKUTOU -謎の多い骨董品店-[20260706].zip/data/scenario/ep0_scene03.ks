﻿;--------------------------------------------------
;■黒十　本文テキスト　ep0 懐古趣味の回顧録　
;--------------------------------------------------
;
;■ep0_scene03
;
;--------------------------------------------------
;シナリオ分岐の設定
;▼コレクション確認の選択肢
;　f.collection_1=1
;　f.collection_2=1
;　f.collection_3=1
;　f.collection_4=1
;
;▼コレクションを見る
;　花器　f.collection_vase=1
;　メダル　f.collection_medal=1
;　リトグラフ　f.collection_lithograph=1
;　手鏡　f.collection_mirror=1
;
;
;▼詳細を見る
;　花器　f.search_vase=1
;　メダル　f.search_medal=1
;　リトグラフ　f.search_lithograph=1
;　手鏡　f.search_mirror=1
;
;--------------------------------------------------
*collection
[savetitle text="コレクション"]
;--------------------------------------------------

;BGM停止
[bgm_end3]

;BGM再生
[bgm ogg="Peach_Sweat.ogg"]

;■選択肢「コレクション」
;一度選んだものは非表示になる。
;１～４のすべてを選択するか、５を選択することで次へ進む。
;選択肢２を選び、尚且よく調べる、を選択することでトゥルーエンドを見ることができる。


;１：トーム ナンジー 作『花器』
;２：村高 幸雲 作『メダル』
;３：サリー ローラン 作『リトグラフ』
;４：作者不明 『ブロンズフレーム　手鏡』
;５：今日はこれくらいにしておく

*collection_1
[if exp="f.collection_1==1"]
[jump target="*collection_2]
[else]
[endif]

[glink width="628" graphic="txtlink.png" enterimg="txtlink_on.png" enterse="cursor1.ogg" clickse="decision5.ogg" size="28" x="266" y="60" exp="f.collection_vase=1" target="*vase" text="トーム ナンジー 作『花器』"]

*collection_2
[if exp="f.collection_2==1"]
[jump target="*collection_3]
[else]
[endif]

[glink width="628" graphic="txtlink.png" enterimg="txtlink_on.png" enterse="cursor1.ogg" clickse="decision5.ogg" size="28" x="266" y="150" exp="f.collection_medal=1" target="*medal" text="村高 幸雲 作『メダル』"]

*collection_3
[if exp="f.collection_3==1"]
[jump target="*collection_4]
[else]
[endif]

[glink width="628" graphic="txtlink.png" enterimg="txtlink_on.png" enterse="cursor1.ogg" clickse="decision5.ogg" size="28" x="266" y="240" exp="f.collection_lithograph=1" target="*lithograph" text="サリー ローラン 作『リトグラフ』"]

*collection_4
[if exp="f.collection_4==1"]
[jump target="*collection_5]
[else]
[endif]

[glink width="628" graphic="txtlink.png" enterimg="txtlink_on.png" enterse="cursor1.ogg" clickse="decision5.ogg" size="28" x="266" y="330" exp="f.collection_mirror=1" target="*mirror" text="作者不明 『ブロンズフレーム　手鏡』"]

*collection_5

[glink width="628" graphic="txtlink.png" enterimg="txtlink_on.png" enterse="cursor1.ogg" clickse="decision5.ogg" size="28" x="266" y="420" target="*tomorrow" text="今日はこれくらいにしておく"]

[s]

;-------------------------------------------------
*vase
[savetitle text="トーム ナンジー 作『花器』"]
;-------------------------------------------------
;選択肢１：トーム ナンジー 作『花器』
[eval exp="f.collection_1=1"]

[vo vo="ep0/koku_0082.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「那么，下一个是花瓶吗」[p]

[vo vo="ep0/koku_0083.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「汤南杰……法国玻璃工艺的传奇[r]　
竟然如此随意地陈列在这里……！」[p]
[kokutou_微笑_c]

#
目睹实物后抑制不住涌起的兴奋。[p]

想要更仔细地观察看看。[p]

可以摸吗？真的可以摸吗！？[p]


;全キャラ削除
[allc]

[kokutou_真顔_c]
[ric_f cg="kokutou"]

[yuzuha_s_真顔]
[lec cg="yuzuha_s"]

[vo vo="ep0/yuzuha_0047.ogg"]
#【小仓 柚叶】
「喂科克托，别管那些了去那边玩嘛？」[p]
[yuzuha_s_真顔_c]

#
少女向犹豫不决的我搭话。[p]

该如何是好。[p]


;■選択肢
;１よく調べる
;２柚葉くんの相手をする

[glink x="266" y="186" graphic="txtlink.png" width="712"  size="28" text="よく調べる" exp="f.search_vase=1" target="*search1"]
[glink x="266" y="299" graphic="txtlink.png" width="712" size="28" text="柚葉くんの相手をする" target="*yuzuha1"]

[s]


;選択肢１：よく調べる
*search1

[kokutou_真顔_c]
现在该专注于眼前的古董。[p]

;カットイン表示
[cut_in cut="cut_choice1.png"]

[yuzuha_s_ふくれっ面_c]

[vo vo="ep0/koku_0084.ogg"]
[kokutou_微笑]
;マルトレとは　（ガラスの表面に金工の槌目のようなカット文様を施す技法）
#【黒十 美鹤】
「哈～这花卉浮雕太美了……！[r]　
　多么考究的锤痕处理啊……！」[p]
[kokutou_微笑_c]

;全キャラ削除
[allc]

[ce cg="kokutou"]

#
捧起花瓶仔细检查背面。[p]

那里清晰地镌刻着签名。[p]

;カットイン削除
[cut_out]

[vo vo="ep0/koku_0085.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「完全看不出是新艺术时期的作品[r]　
　保存状态简直完美无缺啊～」[p]
[kokutou_微笑_c]

#
老实说激动死了。[p]

[vo vo="ep0/koku_0086.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「一定要摆在我的店里……[r]　
　不对应该说无论如何都要进货绝对要拿下……！」[p]
[kokutou_微笑_c]

#
立下坚定誓言后准备查看下一件收藏品。[p]

;ここまで

;選択肢に戻る
[jump target="*collection"]
[s]



;選択肢２：柚葉くんの相手をする
*yuzuha1

;BGM停止
[bgm_end3]

;BGM再生
[bgm ogg="4656.ogg"]

[kokutou_哀2_c]
却被少女泼了冷水。[p]

[vo vo="ep0/yuzuha_0048.ogg"]
[yuzuha_s_真顔]
#【小仓 柚叶】
「诶～让我看看嘛？」[p]
[yuzuha_s_真顔_c]

[vo vo="ep0/koku_0087.ogg"]
[kokutou_呆れ]
#【黒十 美鹤】
「哈……玩是要玩什么呢」[p]
[kokutou_呆れ_c]

#
明明觉得不该搭理，却不知为何还是回应了。[p]

[vo vo="ep0/yuzuha_0049.ogg"]
[yuzuha_s_笑顔]
#【小仓 柚叶】
「我、我有游戏机！这个也能玩游戏哦！」[p]
[yuzuha_s_笑顔_c]
#
她笑着说道。[p]

[vo vo="ep0/koku_0088.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「诶？原来这个是游戏机吗？」[p]
[kokutou_驚き_c]

[vo vo="ep0/yuzuha_0050.ogg"]
[yuzuha_s_微笑]
#【小仓 柚叶】
「不不，不是啦，是能玩游戏的那个」[p]

[vo vo="ep0/yuzuha_0051.ogg"]
#【小仓 柚叶】
「还能拍照和画画呢」[p]
[yuzuha_s_微笑_c]

[vo vo="ep0/koku_0089.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「咦？就靠这一个东西？哈哈，怎么可能嘛」[p]
[kokutou_疑問_c]

#
从未听说过相机、涂鸦本和游戏机能三合一的东西。[p]

说谎也该适可而止。[p]

[vo vo="ep0/yuzuha_0052.ogg"]
[yuzuha_s_ふくれっ面]
#【小仓 柚叶】
「呜——你不信……明明是真的」[p]
[yuzuha_s_ふくれっ面_c]

[vo vo="ep0/koku_0090.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「好啦好啦，但现在没空玩哦」[p]

[vo vo="ep0/koku_0091.ogg"]
#【黒十 美鹤】
「至少等我把检查工作做完」[p]
[kokutou_真顔_c]

[vo vo="ep0/yuzuha_0053.ogg"]
[yuzuha_s_ふくれっ面]
#【小仓 柚叶】
「哎——科克托……真扫兴」[p]
[yuzuha_s_ふくれっ面_c]

[vo vo="ep0/koku_0092.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「就算闹别扭也不行就是不行」[p]
[kokutou_真顔_c]

;全キャラ削除
[allc]

[ce cg="kokutou"]



#
我决定无视鼓着腮帮的少女，继续核对收藏品。[p]

;ここまで

;選択肢に戻る
[jump target="*collection"]
[s]


;-------------------------------------------------
*medal
[savetitle text=";選択肢２：村高 幸雲 作『メダル』"]
;-------------------------------------------------
;選択肢２：村高 幸雲 作『メダル』
[eval exp="f.collection_2=1"]

[vo vo="ep0/koku_0093.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「那么，这就是明治大正时代代表雕刻家制作的勋章吗」[p]
[kokutou_真顔_c]

#
本以为是小物件，实际却比想象中要大。[p]

这似乎不是用金或铁，而是用石膏制成的勋章。[p]

[vo vo="ep0/koku_0094.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「这同样令人惊叹……工匠的技艺……！」[p]
[kokutou_微笑_c]

#
真想拿在手里仔细端详。[p]

或者说必须好好鉴赏才行。[p]


;全キャラ削除
[allc]

[kokutou_真顔_c]
[ric_f cg="kokutou"]

[yuzuha_s_微笑]
[lec cg="yuzuha_s"]

;背くらべ（せいくらべ）
[vo vo="ep0/yuzuha_0054.ogg"]
#【小仓 柚叶】
「呐，科克托，来比身高嘛——」[p]
[yuzuha_s_微笑_c]

[kokutou_真顔_c]
#
兴奋不已的我被少女搭话了。[p]

该如何是好。[p]


;■選択肢
;１よく調べる
;２柚葉くんの相手をする

[glink x="266" y="186" graphic="txtlink.png" width="712"  size="28" text="よく調べる" exp="f.search_medal=1" target="*search2"]
[glink x="266" y="299" graphic="txtlink.png" width="712" size="28" text="柚葉くんの相手をする" target="*yuzuha2"]

[s]

;選択肢１：よく調べる
*search2

我可没闲工夫陪这少女胡言乱语。[p]

[yuzuha_s_ふくれっ面_c]

现在必须好好检查眼前的这枚勋章。[p]

;全キャラ削除
[allc]


;カットイン表示
[cut_in cut="cut_choice2.png"]

[kokutou_微笑]
[ce cg="kokutou"]

[vo vo="ep0/koku_0095.ogg"]
#【黒十 美鹤】
「噢，这沉甸甸的分量真是令人爱不释手……！」[p]
[kokutou_微笑_c]

#
表面雕刻的山羊座精妙工艺[r]　
让人不禁发出赞叹。[p]

;カットイン表示
[cut_in cut="cut_choice2_2.png"]

而背面也刻有美丽的纹样。[p]

[vo vo="ep0/koku_0096.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「这纹样是……从未见过呢」[p]
[kokutou_微笑_c]

#
得仔细记住这个图案。[p]

我决定回去后仔细研究。[p]

;カットイン削除
[cut_out]

;全キャラ削除
[allc]

[kokutou_真顔_c]
[ric_f cg="kokutou"]

[azuha_真顔]
[lec cg="azuha"]

[vo vo="ep0/azuha_0032.ogg"]
#【小仓 杏叶】
「进展如何？」[p]
[azuha_真顔_c]

#
正专注端详勋章时突然被人搭话。[p]

出现在眼前的正是委托我鉴定收藏品的小仓杏叶本人。[p]

[vo vo="ep0/azuha_0033.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「这是什么？」[p]
[azuha_真顔_c]

#
说着她便随手从我这儿夺过勋章。[p]

[vo vo="ep0/koku_0097.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「啊！？　请您小心点！[r]　
　这可是极其珍贵的物件！」[p]
[kokutou_驚き_c]

[vo vo="ep0/azuha_0034.ogg"]
[azuha_真顔]
#【小仓 杏叶】
「哼——就这玩意儿啊……这种东西能派上什么用场呢」[p]
[azuha_真顔_c]

#
她兴趣索然地甩出这句话。[p]

[vo vo="ep0/koku_0098.ogg"]
[kokutou_呆れ]
#【黒十 美鹤】
「真是的……姐妹俩都一个样……」[p]
[kokutou_呆れ_c]

#
听到我的话，她的眉毛微微抽动。[p]

[vo vo="ep0/azuha_0035.ogg"]
[azuha_怒り]
#【小仓 杏叶】
「这种东西当镇纸用倒挺合适」[p]
[azuha_怒り_c]

#
用不悦的语气说道[r]　
小仓杏叶竟然直接将奖牌扔了过来。[p]


;全キャラ削除
[allc]

[kokutou_驚き]
[ce cg="kokutou"]

我拼了命才接住它。[p]

[vo vo="ep0/koku_0099.ogg"]
#【黒十 美鹤】
「要、要是摔坏了怎么办！？」[p]
[kokutou_驚き_c]

#
虽然这样喊着，但小仓杏叶已经离开了现场。[p]

真是个可怕的女人。[p]

[vo vo="ep0/koku_0100.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「真是的，怎么能把这么贵重的东西当镇纸用呢……」[p]
[kokutou_真顔_c]

#
小心翼翼地将被扔来的奖牌放回原处。[p]

好了，必须重新振作精神继续确认工作。[p]


;選択肢に戻る
[jump target="*collection"]
[s]


;選択肢２：柚葉くんの相手をする[p]
*yuzuha2

;BGM停止
[bgm_end3]

;BGM再生
[bgm ogg="4656.ogg"]

[vo vo="ep0/koku_0101.ogg"]
[kokutou_呆れ]
#【黒十 美鹤】
「比身高什么的……最讨厌了[r]　
　这种事到底有什么意义？」[p]
[kokutou_呆れ_c]

#
小孩子真是完全猜不到他们会说出什么。[p]

[vo vo="ep0/yuzuha_0055.ogg"]
[yuzuha_s_微笑]
#【小仓 柚叶】
「诶——明明很有趣的……我最近个子长高了很多哦？」[p]
[yuzuha_s_微笑_c]

[vo vo="ep0/koku_0102.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「像柚叶君这个年纪的孩子都会长高的」[p]
[kokutou_真顔_c]

[vo vo="ep0/yuzuha_0056.ogg"]
[yuzuha_s_ふくれっ面]
#【小仓 柚叶】
「唔……马上就能超过科克托的身高了！」[p]
[yuzuha_s_ふくれっ面_c]

;全キャラ削除
[allc]

[kokutou_呆れ]
[ce cg="kokutou"]

[vo vo="ep0/koku_0103.ogg"]
#【黒十 美鹤】
「不，那应该不太可能吧」[p]
[kokutou_呆れ_c]

#
想想她姐姐小仓杏叶的身高就知道不可能了。[p]

[vo vo="ep0/koku_0104.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「嘛，其实身高什么的都无所谓啦……」[p]
[kokutou_真顔_c]

#
现在应该优先确认收藏品的情况。[p]

没空陪小孩子玩。[p]

;ここまで

;選択肢に戻る
[jump target="*collection"]
[s]


;-------------------------------------------------
*lithograph
[savetitle text="サリー ローラン 作『リトグラフ』"]
;-------------------------------------------------
;選択肢３：サリー ローラン 作『リトグラフ』
[eval exp="f.collection_3=1"]

[vo vo="ep0/koku_0105.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「哈啊……这幅石版画描绘了伫立着露出忧郁表情的少女……！」[p]

[vo vo="ep0/koku_0106.ogg"]
#【黒十 美鹤】
「不愧是至今仍备受欢迎的法国女画家[r]　
　莎莉·罗兰果然与众不同……！」[p]
[kokutou_微笑_c]

;全キャラ削除
[allc]

[kokutou_疑問_c]
[ric_f cg="kokutou"]

[yuzuha_s_真顔]
[lec cg="yuzuha_s"]

[vo vo="ep0/yuzuha_0057.ogg"]
#【小仓 柚叶】
「……这幅画……总觉得……」[p]
[yuzuha_s_真顔_c]

#
站在我身旁的少女难得地凝神注视着画作。[p]

[vo vo="ep0/koku_0107.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「噢！？　柚叶君也能体会这幅画的妙处吗！？」[p]
[kokutou_驚き_c]


[vo vo="ep0/yuzuha_0058.ogg"]
[kokutou_呆れ_c]
[yuzuha_s_笑顔]
#【小仓 柚叶】
「画得真烂！！」[p]
[yuzuha_s_笑顔_c]

#
少女指着画作毫无芥蒂地笑了起来。[p]

[vo vo="ep0/koku_0108.ogg"]
[kokutou_呆れ]
#【黒十 美鹤】
「……会有所期待的我还真是愚蠢呢」[p]
[kokutou_呆れ_c]

[vo vo="ep0/yuzuha_0059.ogg"]
[yuzuha_s_微笑]
#【小仓 柚叶】
「画画的话我也会哦？去那边一起画画吧！」[p]
[yuzuha_s_微笑_c]

#
代表法国女性画家的石版画与这名少女的涂鸦。[p]

这两者本就没有可比性。[p]

我想仔细观察的是前者那件古老艺术品。[p]

[vo vo="ep0/koku_0109.ogg"]
#【黒十 美鹤】
「那么事不宜迟……」[p]
#

;■選択肢
;１よく調べる
;２柚葉くんの相手をする

[glink x="266" y="186" graphic="txtlink.png" width="712"  size="28" text="よく調べる" exp="f.search_lithograph=1" target="*search3"]
[glink x="266" y="299" graphic="txtlink.png" width="712" size="28" text="柚葉くんの相手をする" target="*yuzuha3"]

[s]

;選択肢１：よく調べる
*search3

[kokutou_真顔_c]
我轻轻捧起装有石版画的画框。[p]

;カットイン表示
[cut_in cut="cut_choice3.png"]

[yuzuha_s_ふくれっ面_c]

虽然尺寸不算特别大[r]　
但精美的画框甚至能让人感受到历史的厚重感。[p]

[kokutou_微笑]

[vo vo="ep0/koku_0110.ogg"]
#【黒十 美鹤】
「唔嗯，尽管年代久远[r]　
　不仅石版画本身保存完好，连画框也几乎没有损伤！」[p]

[vo vo="ep0/koku_0111.ogg"]
#【黒十 美鹤】
「由此可见这件作品曾多么令人倾倒[r]　
　受到何等的珍爱……！」[p]
[kokutou_微笑_c]

;カットイン削除
[cut_out]

#
姑且也检查了画框背面。[p]

上面留着多次修复固定金属件的痕迹。[p]

果然曾被精心陈列供奉着。[p]

[vo vo="ep0/yuzuha_0060.ogg"]
[yuzuha_s_ふくれっ面]
#【小仓 柚叶】
「……明明我也能画画」[p]
[yuzuha_s_ふくれっ面_c]

#
与我心满意足的样子相反，少女鼓起脸颊瞪着我。[p]

;全キャラ削除
[allc]

[kokutou_微笑_c]
[ce cg="kokutou"]

但没空理会她。[p]

还有更多收藏品在等着我。[p]

;選択肢に戻る
[jump target="*collection"]
[s]


;選択肢２：柚葉くんの相手をする
*yuzuha3

;BGM停止
[bgm_end3]

;BGM再生
[bgm ogg="4656.ogg"]

[vo vo="ep0/koku_0112.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「……柚叶君会画什么样的画呢？」[p]
[kokutou_真顔_c]

#
突然有些在意便试着问道。[p]

[vo vo="ep0/yuzuha_0061.ogg"]
[yuzuha_s_真顔]
#【小仓 柚叶】
「诶？」[p]
[yuzuha_s_真顔_c]

#
她大概没想到会得到回应吧。[p]

少女略显意外地愣住了。[p]

[yuzuha_s_笑顔]
但转眼间她的表情如花朵绽放般明亮起来。[p]

[vo vo="ep0/yuzuha_0062.ogg"]
#【小仓 柚叶】
「很多很多，各种各样的！」[p]

[vo vo="ep0/yuzuha_0063.ogg"]
#【小仓 柚叶】
「会画天空的画，还有爷爷的肖像！」[p]
[yuzuha_s_笑顔_c]

#
她所说的爷爷是指祖父[r]　
也就是收藏这些藏品的小仓岩吧。[p]

[vo vo="ep0/koku_0113.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「柚叶君很喜欢画画吗？」[p]
[kokutou_真顔_c]

[vo vo="ep0/yuzuha_0064.ogg"]
[yuzuha_s_真顔]
#【小仓 柚叶】
「不喜欢」[p]
[yuzuha_s_真顔_c]

[vo vo="ep0/koku_0114.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「……咦？」[p]
[kokutou_疑問_c]

[vo vo="ep0/yuzuha_0065.ogg"]
[yuzuha_s_真顔]
#【小仓 柚叶】
「会弄脏手……不过闲着没事才画的」[p]
[yuzuha_s_真顔_c]

[vo vo="ep0/koku_0115.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「总觉得这理由有点微妙呢……」[p]
[kokutou_哀_c]

#
被这样的小姑娘说画得差，某位女画家莫名让人觉得可怜。[p]

[vo vo="ep0/yuzuha_0066.ogg"]
[yuzuha_s_疑問]
#【小仓 柚叶】
「呐科克托，为什么对我的画感兴趣呀？」[p]
[yuzuha_s_疑問_c]

[vo vo="ep0/koku_0116.ogg"]
[kokutou_哀2]
#【黒十 美鹤】
「没什么，只是……想到流着小仓集团血脉的柚叶君[r]　
　会画出怎样的作品，稍微有点兴趣罢了」[p]
[kokutou_哀2_c]

#
不过结果似乎不必看画就能知道了。[p]

;全キャラ削除
[allc]

[kokutou_真顔]
[ce cg="kokutou"]


[vo vo="ep0/koku_0117.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「哎呀，我是不是废话太多了」[p]
[kokutou_真顔_c]
#
我决定赶快去确认其他收藏品。[p]


;ここまで

;選択肢に戻る
[jump target="*collection"]
[s]

;-------------------------------------------------
*mirror
[savetitle text="作者不明 『ブロンズフレーム　手鏡』"]
;-------------------------------------------------
;選択肢４：作者不明 『ブロンズフレーム　手鏡』
[eval exp="f.collection_4=1"]

[vo vo="ep0/koku_0118.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「这里有个作者不明的……青铜框架……看来就是这个」[p]
[kokutou_真顔_c]

#
发现了一面装饰用的手镜。[p]

遗憾的是镜面部分已经缺失，只剩下框架。[p]

[vo vo="ep0/koku_0119.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「这么说来相当古老……而且这个框架……」[p]
[kokutou_微笑_c]
#
以天使为主题的设计工艺相当精致美丽。[p]

这件必须得好好调查才行。[p]

;全キャラ削除
[allc]

[kokutou_疑問_c]
[ric_f cg="kokutou"]

[yuzuha_s_真顔]
[lec cg="yuzuha_s"]

[vo vo="ep0/yuzuha_0067.ogg"]
#【小仓 柚叶】
「呐，科克托你多大了？在努力找工作吗？」[p]
[yuzuha_s_真顔_c]

#
对这种突然抛来的问题也该置之不理[r]　
专心确认收藏品才对。[p]


;■選択肢
;１よく調べる
;２柚葉くんの相手をする

[glink x="266" y="186" graphic="txtlink.png" width="712"  size="28" text="よく調べる" exp="f.search_mirror=1" target="*search4"]
[glink x="266" y="299" graphic="txtlink.png" width="712" size="28" text="柚葉くんの相手をする" target="*yuzuha4"]

[s]

;選択肢１：よく調べる
*search4

;カットイン表示
[cut_in cut="cut_choice4.png"]

[vo vo="ep0/koku_0120.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「从设计来看，这恐怕是英国制的吧」[p]

[vo vo="ep0/koku_0121.ogg"]
#【黒十 美鹤】
「标注作者不明这点更让人恼火……[r]　
　简直像是为了抬高手镜价值而作的表演不是吗！」[p]
[kokutou_微笑_c]

[yuzuha_s_ふくれっ面_c]

#
保存状态好到堪称完美。[p]

[yuzuha_s_真顔_c]

虽然可以配备新镜片，但这个框架本身[r]　
就已经杰出到能作为摆件独立存在。[p]

;カットイン削除
[cut_out]

[vo vo="ep0/yuzuha_0068.ogg"]
[yuzuha_s_微笑]
#【小仓 柚叶】
「没有镜子的手镜……？嗯……好怪！」[p]
[yuzuha_s_微笑_c]

[vo vo="ep0/koku_0122.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「呵呵，小孩子不懂这种设计的美妙呢」[p]
[kokutou_微笑_c]

[vo vo="ep0/yuzuha_0069.ogg"]
[yuzuha_s_ふくれっ面]
#【小仓 柚叶】
「呜……科克托，怪人！」[p]
[yuzuha_s_ふくれっ面_c]

;全キャラ削除
[allc]

[kokutou_微笑_c]
[ce cg="kokutou"]

#
只要能懂得这份美妙，被说怪也无所谓。[p]

那么，这里还有许多其他的收藏品。[p]

真想更深地沉溺于古董的海洋中。[p]

我决定回到清单确认中，寻求更多的古董。[p]

;選択肢に戻る
[jump target="*collection"]
[s]


;選択肢２：柚葉くんの相手をする
*yuzuha4

;BGM停止
[bgm_end3]

;BGM再生
[bgm ogg="4656.ogg"]

[vo vo="ep0/koku_0123.ogg"]
[kokutou_哀2]
#【黒十 美鹤】
「……什么啊，那个问题」[p]
[kokutou_哀2_c]

#
如果只是年龄还好，真想知道她从哪儿学来‘求职活动’这种词。[p]

[vo vo="ep0/yuzuha_0070.ogg"]
[yuzuha_s_真顔]
#【小仓 柚叶】
「科克托你没上学吗？是更年长些？还是无业游民？」[p]
[yuzuha_s_真顔_c]

#
为什么小孩子就能这样毫无顾忌地问出这种问题呢。[p]

我最讨厌这种毫无分寸的地方了。[p]

[vo vo="ep0/koku_0124.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「我上着学呢……而且，工作也定下来了」[p]
[kokutou_真顔_c]

[vo vo="ep0/yuzuha_0071.ogg"]
[yuzuha_s_真顔]
#【小仓 柚叶】
「科克托要成为什么呀？」[p]
[yuzuha_s_真顔_c]

#
这孩子属于会刨根问底的类型。[p]

明明问了这些事也和这孩子毫无关系。[p]

[vo vo="ep0/koku_0125.ogg"]
[kokutou_呆れ]
#【黒十 美鹤】
「……古董店的店主啦」[p]
[kokutou_呆れ_c]

[vo vo="ep0/yuzuha_0072.ogg"]
[yuzuha_s_疑問]
#【小仓 柚叶】
「那是什么？好玩吗？」[p]
[yuzuha_s_疑問_c]

#
继续陪她这样问答下去恐怕没完没了。[p]

[vo vo="ep0/koku_0126.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「比起这个还是赶紧确认收藏品吧」[p]
[kokutou_真顔_c]

[vo vo="ep0/yuzuha_0073.ogg"]
[yuzuha_s_ふくれっ面]
#【小仓 柚叶】
「诶——还要继续啊——」[p]
[yuzuha_s_ふくれっ面_c]

;全キャラ削除
[allc]

[kokutou_真顔]
[ce cg="kokutou"]

#
我决定和那个满脸无聊发着牢骚的少女回到工作中。[p]


;ここまで

;選択肢に戻る
[jump target="*collection"]
[s]


;選択肢をすべて選び終えるか、選択肢５を選ぶとここにジャンプ
;-------------------------------------------------
*tomorrow
[savetitle text="今日はこれくらいにしておく"]
;-------------------------------------------------

;BGM停止
[bgm_end3]

;全キャラ削除
[allc]

;背景　黒背景
[bg10 bg="black.png"]

花了一整天总算确认了相当数量的收藏品。[p]

做到这个程度的话，明天离岛时应该[r]　
就能完成所有收藏品的确认了吧。[p]

;BGM再生
[bgm ogg="vacances.ogg"]

;背景　展示室１
[bg10 bg="exhibition_room.jpg"]

[kokutou_真顔]
[ce cg="kokutou"]

[vo vo="ep0/koku_0127.ogg"]
#【黒十 美鹤】
「哎呀～不过小仓岩留下的收藏品[r]　
　居然一天就能确认这么多……」[p]

[vo vo="ep0/koku_0128.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「果然来这座岛是对的……！」[p]
[kokutou_微笑_c]

#
虽然起初还在担心会怎么样[r]　
但实际面对这些琳琅满目的收藏品时，我发自内心这么想着。[p]

能观赏到这么多珍贵物件的地方[r]　
在日本恐怕也屈指可数吧。[p]

更何况，若是以普通游客身份前来[r]　
绝大多数藏品根本无法得见。[p]

[vo vo="ep0/koku_0129.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「该说是承蒙幸运女神眷顾吧……呵呵呵」[p]
[kokutou_微笑_c]

;全キャラ削除
[allc]

[kokutou_微笑_c]
[ric_f cg="kokutou"]

[yuzuha_s_真顔]
[lec cg="yuzuha_s"]

[vo vo="ep0/yuzuha_0074.ogg"]
#【小仓 柚叶】
「科克托，你在傻笑什么？」[p]
[yuzuha_s_真顔_c]

#
见我沉浸在喜悦中，少女出声询问。[p]

本可置之不理，但心情大好的我决定回应她。[p]

[vo vo="ep0/koku_0130.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「没什么，只是觉得能见识到柚叶君祖父的收藏品[r]　
　实在太好了」[p]
[kokutou_微笑_c]

[vo vo="ep0/yuzuha_0075.ogg"]
[yuzuha_s_疑問]
#【小仓 柚叶】
「爷爷那些破烂？科克托你果然好怪哦」[p]
[yuzuha_s_疑問_c]

[vo vo="ep0/koku_0131.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「喂喂，怎么能把令祖父收集的宝物[r]　
　说成破烂呢」[p]
[kokutou_真顔_c]
#
居然完全不懂这些物品的价值[r]　
对此我再次感到不寒而栗。[p]

[vo vo="ep0/yuzuha_0076.ogg"]
[yuzuha_s_疑問]
#【小仓 柚叶】
「但爷爷自己也说是破烂呀？」[p]
[yuzuha_s_疑問_c]

[vo vo="ep0/koku_0132.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「不，不可能有这种事吧」[p]

[vo vo="ep0/koku_0133.ogg"]
#【黒十 美鹤】
「这些可都是他特意搜集的珍品啊？」[p]

[vo vo="ep0/koku_0134.ogg"]
#【黒十 美鹤】
「肯定是因为真心喜爱才收藏的」[p]
[kokutou_真顔_c]

#
这些古董和古美术品数量庞大。[p]

可以想见不仅耗费了大量金钱，也投入了相当多的时间和精力。[p]

若非真心喜爱，根本不可能投入如此多的金钱和时间。[p]

然而听到我的话，作为小仓岩孙女的少女却歪着头表示不解。[p]

[vo vo="ep0/yuzuha_0077.ogg"]
[yuzuha_s_真顔]
#【小仓 柚叶】
「爷爷才不喜欢这些破烂呢？」[p]

[vo vo="ep0/yuzuha_0078.ogg"]
#【小仓 柚叶】
「他和我是一样的啦」[p]
[yuzuha_s_真顔_c]

#
一样的——这究竟是什么意思呢。[p]

[vo vo="ep0/yuzuha_0079.ogg"]
[yuzuha_s_微笑]
#【小仓 柚叶】
「爷爷可是个科技迷[r]　
　经常送我最新款的设备当礼物哦」[p]
[yuzuha_s_微笑_c]

[vo vo="ep0/koku_0135.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「科技迷……最新设备？」[p]
[kokutou_疑問_c]

#
这倒是头回听说。[p]

提起小仓岩，他可是知名收藏家，岛上传闻都说这位狂热的古董爱好者[r]　
在这座岛上保管着无数珍贵藏品。[p]

[vo vo="ep0/yuzuha_0080.ogg"]
[yuzuha_s_笑顔]
#【小仓 柚叶】
「这台机器也是爷爷送我的研发中产品！」[p]

[vo vo="ep0/yuzuha_0081.ogg"]
#【小仓 柚叶】
「说是超厉害的万能记事本呢！」[p]
[yuzuha_s_笑顔_c]
#
少女兴高采烈地举起手中神秘的机器说道。[p]

这番话让我不由得也歪头困惑起来。[p]

这到底是怎么回事。[p]

[vo vo="ep0/koku_0136.ogg"]
[kokutou_疑問]
#【黒十 美鹤】
「这事，当真吗？会不会是弄错了？」[p]
[kokutou_疑問_c]

[vo vo="ep0/yuzuha_0082.ogg"]
[yuzuha_s_笑顔]
#【小仓 柚叶】
「嗯——才没搞错呢……啊[r]　
　对了！爷爷还超级爱奶奶！」[p]
[yuzuha_s_笑顔_c]

[vo vo="ep0/koku_0137.ogg"]
[kokutou_哀]
#【黒十 美鹤】
「啊、啊哈哈……[r]　
　难道我知道的事情是错的……还是说……」[p]
[kokutou_哀_c]

#
孙女小仓柚叶所说的内容存在某些误解。[p]

[kokutou_微笑_c]

稍作思考后，又觉得这种想法荒唐便放弃了。[p]

我所听闻关于小仓岩的传闻绝不可能有误。[p]

方才在这座宅邸里确认过的贵重物品[r]　
不正是最有力的证据吗？」[p]

想必是小仓柚叶听错或理解有偏差吧。[p]

;BGM停止
[bgm_end3]

;SE　時計の鐘がなる音。

;SE時計の鐘をループ再生する
[fadeinse storage="tokei_kane.ogg" loop="true" time="1000" buf="0"]

[yuzuha_s_真顔_c]

就在这时，大厅里的巨钟鸣响了。[p]

;SE時計の鐘をフェイドアウトさせる
[fadeoutse time=1000 buf="0"]

[vo vo="ep0/yuzuha_0083.ogg"]
[yuzuha_s_真顔]
#【小仓 柚叶】
「啊、快到用餐时间了」[p]
[yuzuha_s_真顔_c]

[vo vo="ep0/koku_0138.ogg"]
[kokutou_真顔]
#【黒十 美鹤】
「今天的调查工作就先到此为止吧」[p]
[kokutou_真顔_c]

#
;全キャラ削除
[allc]

;//黒ベタ
[bg20 bg="black.png"]

剩余部分留待明日继续，众人便就此散去。[p]


;BGM再生
[bgm ogg="286.ogg"]

;//事務所
[bg10 bg="antique.jpg"]

[yuzuha_etc_off]
[yuzuha_微笑_c]
[lec_f cg="yuzuha"]

[kokutou_c_夏]
[kokutou_哀]
[ric cg="kokutou"]

[vo vo="ep0/koku_0139.ogg"]
#【黒十 美鹤】
「不过说真的，当时可真是让我够呛」[p]

[vo vo="ep0/koku_0140.ogg"]
#【黒十 美鹤】
「动不动就被追问为什么为什么的」[p]

[kokutou_哀_c]

[vo vo="ep0/yuzuha_0084.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「哈哈，实在抱歉」[p]
[yuzuha_微笑_c]

[vo vo="ep0/koku_0141.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「话虽如此[r]　
　能亲眼自由鉴赏这么多珍品还是很令人高兴的」[p]
[kokutou_微笑_c]

#
能随意观赏小仓岩遗留收藏品的机会绝无仅有。[p]

虽说有监护人陪同才能实现[r]　
对于古董爱好者而言唯有感激二字可言。[p]

[vo vo="ep0/yuzuha_0085.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「记得那时候，一天内就差不多全看遍了呢」[p]
[yuzuha_微笑_c]

[vo vo="ep0/koku_0142.ogg"]
[kokutou_微笑]
#【黒十 美鹤】
「是啊，对柚叶君来说应该是很无聊的一天吧」[p]
[kokutou_微笑_c]

[vo vo="ep0/yuzuha_0086.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「没有没有，才没那回事呢」[p]
[yuzuha_微笑_c]

#
这倒有些出乎意料。[p]

柚叶君对那种古董应该是完全不感兴趣的。[p]

这应该是从她小时候起就未曾改变过的。[p]

[vo vo="ep0/yuzuha_0087.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「啊，要说看爷爷的那些破烂玩意儿[r]　
　确实有点无聊呢」[p]
[yuzuha_微笑_c]

[vo vo="ep0/koku_0143.ogg"]
[kokutou_驚き]
#【黒十 美鹤】
「破....！？　唉......」[p]
[kokutou_驚き_c]

#
罢了，这事就不再多说什么了。[p]

[vo vo="ep0/yuzuha_0088.ogg"]
[yuzuha_微笑]
#【小仓 柚叶】
「但是，我当时......很开心哦」[p]

[vo vo="ep0/yuzuha_0089.ogg"]
[yuzuha_笑顔]
#【小仓 柚叶】
「因为遇到会认真注视我的眼睛[r]　
　回答我无法理解之事的人」[p]
[yuzuha_笑顔_c]

#
这么说着，柚叶君露出了仿佛追忆往昔的微笑。[p]

确实，当时的柚叶君看起来[r]　
并没有被周围任何大人认真对待。[p]

;過去に戻る。

;全キャラ削除
[allc]

;//黒ベタ
[bg20 bg="black.png"]

在相遇当天就能感受到[r]　
那位少女是何等孤独。[p]


;シーン4へ移動
[jump  storage="ep0_scene04.ks"]
[s]