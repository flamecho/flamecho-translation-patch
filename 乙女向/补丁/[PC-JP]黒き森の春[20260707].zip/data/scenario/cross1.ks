﻿[_tb_system_call storage=system/_cross1.ks]

[plugin name=auto_indent]

[plugin name="backlog"]

*start

[cm  ]
[stopbgm  time="1000"  fadeout="true"  ]
[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[tb_image_hide  time="0"  ]
[tb_ptext_hide  time="0"  ]
[tb_show_message_window  ]
[bg  time="1000"  method="crossfade"  storage="kuro.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[bg  time="1000"  method="crossfade"  storage="bak/aides_gyokza.jpg"  ]
[playbgm  volume="15"  time="1000"  loop="true"  storage="bgm/prologue.mp3"  ]
[tb_start_text mode=1 ]
#
时为20XX年，冥界之王的冥宫——[p]
[_tb_end_text]

[chara_show  name="ヘルメス2"  time="500"  wait="true"  storage="chara/22/hermes2_magao.png"  width="680"  height="1275"  left="740"  top="-75"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「哈迪斯大人可在？」[p]

[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_show  name="ハデス2"  time="600"  wait="false"  storage="chara/18/hades1_magao.png"  width="700"  height="1313"  left="280"  top="-78"  ]
[chara_show  name="ペルセポネ2"  time="600"  wait="true"  storage="chara/17/per1_odoroki.png"  width="688"  height="1290"  left="-100"  top="-100"  reflect="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「赫尔墨斯！怎么了？如此慌张」[p]

[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「——方才，我感知到那位英雄的魂核破碎了」[p]
「那件事吗？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#赫尔墨斯
「您已察觉……正是如此」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「继续」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#赫尔墨斯
「这次事件是阿波罗引发的。[r]
阿波罗怀有多年未了的心愿。因此煽动了英雄的情绪」[p]
「宙斯大人想必会惩罚阿波罗。这也是无可奈何」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#赫尔墨斯
「但现在的阿波罗，谁也猜不透他下一步会做什么——。[r]
所以我有事相求」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
赫尔墨斯递出了两只小鸟。[r]
那是猫头鹰与乌鸦。在赫尔墨斯的力量作用下，它们都沉睡着。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「雅典娜的猫头鹰和阿波罗的乌鸦吗」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#赫尔墨斯
「正是」[p]
「能否暂时将这两只的灵魂寄放在冥界？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#赫尔墨斯
「我这就去禀报宙斯大人。[r]
待安排妥当后，会正式前来恳请您——」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「这两个孩子……是被卷进来的吧。真可怜」[p]
[_tb_end_text]

[chara_mod  name="ペルセポネ2"  time="200"  cross="false"  storage="chara/17/per1_bisho.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「哈迪斯大人，我都认识它们」[p]
「是心灵纯净的孩子。[r]
若父神应允，我想在冥界治愈它们。可以吗？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
两只中，猫头鹰受了重伤。灵魂上已浮现细微裂痕。[r]
这般状态很难靠地上神明的力量恢复。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「好吧」[p]
「只要宙斯同意，冥界没有异议」[p]
[_tb_end_text]

[chara_mod  name="ヘルメス2"  time="0"  cross="false"  storage="chara/22/hermes2_kusho.png"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「太好了……！非常感谢。我这就去办」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[mask  time="800"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="false"  ]
[bg  time="0"  method="crossfade"  storage="kuro.jpg"  ]
[mask_off  time="800"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#
数小时后，赫尔墨斯重返冥界。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
就这样带着宙斯的正式委托，[r]
哈迪斯等冥界众神接管了小鸟们的灵魂。[p]
[_tb_end_text]

[mask  time="800"  effect="fadeIn"  color="0x000000"  ]
[stopbgm  time="1000"  fadeout="true"  ]
[tb_hide_message_window  ]
[tb_filter_grayscale  layer="base"  grayscale="60"  ]
[bg  time="0"  method="crossfade"  storage="bak/aides_gyokza.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[tb_image_show  time="1000"  storage="default/ex_xrossover_siro.png"  width="277"  height="50"  x="410"  y="135"  _clickable_img=""  name="img_50"  ]
[tb_image_show  time="1000"  storage="default/crosstitle.png"  width="323"  height="162"  x="590"  y="180"  _clickable_img=""  name="img_51"  ]
[wait  time="1500"  ]
[mask  time="800"  effect="fadeIn"  color="0x000000"  ]
[tb_image_hide  time="0"  ]
[bg  time="0"  method="crossfade"  storage="kuro.jpg"  ]
[tb_show_message_window  ]
[tb_free_filter  layer="all"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[bg  time="1000"  method="crossfade"  storage="bak/aides_gyokza.jpg"  ]
[playbgm  volume="15"  time="1000"  loop="true"  storage="bgm/hades_off.mp3"  ]
[chara_show  name="ペルセポネ2"  time="500"  wait="true"  storage="chara/17/per1_bisho.png"  width="688"  height="1290"  left="120"  top="-100"  reflect="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「我回来了」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_show  name="ハデス2"  time="500"  wait="true"  storage="chara/18/hades1_magao.png"  width="700"  height="1313"  left="500"  top="-78"  reflect="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「欢迎回来」[p]
「森林那边如何？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「黑杨树之森今日也沐浴着柔光」[p]
[_tb_end_text]

[chara_mod  name="ペルセポネ2"  time="200"  cross="false"  storage="chara/17/per1_egao.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「我给两只小家伙搭了间屋子。[r]
这样它们养伤时就不会被附近的魂灵打扰了」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_mod  name="ペルセポネ2"  time="200"  cross="false"  storage="chara/17/per1_bisho.png"  ]
[tb_start_text mode=1 ]
#
珀耳塞福涅热情接纳了两只鸟魂。[p]
她寻得疗愈魂体的佳处，布置好让它们共同生活的居所。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
哈迪斯与珀耳塞福涅尚无子嗣。[r]
但珀耳塞福涅是位怜爱弱小生灵的女神。[p]
她曾代为抚养其他女神托付的孩子。[r]
对于这两只鸟儿，想必也会温柔守护吧。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
珀耳塞福涅的喜悦，正是哈迪斯的幸福。[p]
[_tb_end_text]

[chara_mod  name="ハデス2"  time="100"  cross="false"  storage="chara/18/hades1_kusho.png"  ]
[tb_start_text mode=1 ]
#哈迪斯
「看来要热闹好一阵子了」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_mod  name="ペルセポネ2"  time="200"  cross="false"  storage="chara/17/per1_egao.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「是啊！」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="true"  ]
[bg  time="0"  method="crossfade"  storage="bak/gaia.jpg"  ]
[tb_start_tyrano_code]
[position layer="message0" left="40" top="30" width="1200" height="660" margint="50" marginl="100" marginr="110" marginb="50"frame="none" opacity="220"]
[button name="role_button" role="save" graphic="../others/plugin/theme_kopanda_bth_08/image/button/save3.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/save2.png" x="1216" y="531" width="45" height="20"]
[button name="role_button" role="load" graphic="../others/plugin/theme_kopanda_bth_08/image/button/load3.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/load2.png"  x="1214" y="557" width="49" height="20"]
[button name="role_button" role="auto" graphic="../others/plugin/theme_kopanda_bth_08/image/button/auto3.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/auto2.png" x="1215" y="583" width="46" height="19"]
[button name="role_button" role="skip" graphic="../others/plugin/theme_kopanda_bth_08/image/button/skip3.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/skip2.png" x="1217" y="609" width="47" height="26"]
[button name="role_button" role="backlog" graphic="../others/plugin/theme_kopanda_bth_08/image/button/log3.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/log2.png" x="1220" y="634" width="39" height="27"]
[button name="role_button" role="sleepgame" graphic="../others/plugin/theme_kopanda_bth_08/image/button/sleep3.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/sleep2.png" storage="../others/plugin/theme_kopanda_bth_08/config.ks" x="1213" y="661" width="57" height="26"]
[button name="role_button" role="title" graphic="../others/plugin/theme_kopanda_bth_08/image/button/title3.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/title2.png" x="1215" y="691" width="48" height="21"]
[button name="role_button" role="window" graphic="../others/plugin/theme_kopanda_bth_08/image/button/close.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/close3.png" x="1262" y="520" width="13" height="13"]
[_tb_end_tyrano_code]

[mask_off  time="1500"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#
在比现在更为遥远的过去——曾经围绕天地霸权的争夺中，哈迪斯六姐弟获得了胜利。[l][r]
[r]
后来，哈迪斯等三位男神抽签选择了大母神提供的签。[l][r]
[r]
这些签将决定三位柱神"各自统治哪个领域"的支配权。[l][r]
[r]
待分配的领域除属于大母神的大地外，共有天空、海洋与冥界三处。[l][r]
[r]
宙斯抽中天空，波塞冬抽中海洋，而哈迪斯则抽中了冥界。[l][r]
[r]
三位柱神遵照签文分别前往各自领域。[p]
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[bg  time="0"  method="crossfade"  storage="bak/aides_gyokza2.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#
虽然抽到哪个领域全凭运气，但或许大母神的力量也产生了影响。[r]
三兄弟前往的领地，都与各自的能力和性情相契合。[l][r]
[r]
能自由操控雷电之力、统帅战局的宙斯执掌天空。[r]
性情灵活多变、掌握流动之力却略显冲动的波塞冬掌管海洋。[r]
而无论面对何事都岿然不动的哈迪斯，则"被选中"统治冥界。[l][r]
[r]
大母神期望世间保持稳定。[l][r]
[r]
因此她或许想在环绕大地的领域之间设立分界。[r]
为了重组秩序并使之固定。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
哈迪斯至今仍记得初抵冥界那日的景象。[l][r]
[r]
那时死亡便已存在。[r]
亡魂会漂流至冥界。[l][r]
[r]
但那时它们"仅仅存在于彼处"。[r]
只是随波逐流而来，既无人整理也无人管理。[l][r]
[r]
将生与死分离，分配灵魂的归宿，在冥界与大地间划定"界限"，[r]
固定存续方式——。[r]
哈迪斯如此理解自己被赋予的使命。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
一旦明白该做什么，之后就不难了。[r]
[r]
冥界的住民们，只遵循冥界的法则。[r]
[r]
无论是刻耳柏洛斯、深渊守卫者，还是自古居于幽冥的众神，全都如此。[r]
[r]
他们需要的不是统治。[r]
只要顺应冥界律法，调整流程使其能履行职责，他们自会配合。[r]
哈迪斯首先从这里着手。[r]
[r]
没有遇到任何抵抗。[r]
就这样，哈迪斯在冥界建起了一座庭院。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
冥界住民们虽言语不多，但在'遵循冥界法则'这点上[r]
都与哈迪斯保持着合作。[r]
[r]
冥界日复一日按照既定流程，接纳无数亡魂。[r]
规定灵魂去向，修整道路以防迷途，引导亡者前行。[r]
连亡魂游荡的阿斯福德之野，也维持着稳定状态。[r]
[r]
虽是每日重复同样的工作，却从不感到厌倦。[p]
[_tb_end_text]

[mask  time="600"  effect="fadeIn"  color="0x000000"  ]
[tb_start_tyrano_code]
[position layer="message0" width="1280" height="220" top="505" left="0"]
[position layer="message0" frame="../others/plugin/theme_kopanda_bth_08/image/frame_message.png" margint="60" marginl="120" marginr="140" marginb="50" opacity="220" page="fore"]
[_tb_end_tyrano_code]

[tb_start_tyrano_code]
[button name="role_button" role="save" graphic="../others/plugin/theme_kopanda_bth_08/image/button/save.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/save2.png" x="1216" y="531" width="45" height="20"]
[button name="role_button" role="load" graphic="../others/plugin/theme_kopanda_bth_08/image/button/load.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/load2.png"  x="1214" y="557" width="49" height="20"]
[button name="role_button" role="auto" graphic="../others/plugin/theme_kopanda_bth_08/image/button/auto.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/auto2.png" x="1215" y="583" width="46" height="19"]
[button name="role_button" role="skip" graphic="../others/plugin/theme_kopanda_bth_08/image/button/skip.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/skip2.png" x="1217" y="609" width="47" height="26"]
[button name="role_button" role="backlog" graphic="../others/plugin/theme_kopanda_bth_08/image/button/log.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/log2.png" x="1220" y="634" width="39" height="27"]
[button name="role_button" role="sleepgame" graphic="../others/plugin/theme_kopanda_bth_08/image/button/sleep.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/sleep2.png" storage="../others/plugin/theme_kopanda_bth_08/config.ks" x="1213" y="661" width="57" height="26"]
[button name="role_button" role="title" graphic="../others/plugin/theme_kopanda_bth_08/image/button/title.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/title2.png" x="1215" y="691" width="48" height="21"]
[button name="role_button" role="window" graphic="../others/plugin/theme_kopanda_bth_08/image/button/close.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/close.png" x="1262" y="520" width="13" height="13"]
[_tb_end_tyrano_code]

[bg  time="0"  method="crossfade"  storage="bak/aides_hall.jpg"  ]
[mask_off  time="800"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#
意识到这种生活过于寂静，[r]
是在胞弟宙斯的安排下，将珀耳塞福涅带来冥界之后。[p]
[_tb_end_text]

[chara_show  name="ハデス_"  time="600"  wait="false"  storage="chara/27/Hades_magao.png"  width="720"  height="1350"  left="30"  top="-85"  reflect="false"  ]
[chara_show  name="ペルセポネ_"  time="600"  wait="true"  storage="chara/26/Per_magao.png"  width="720"  height="1350"  left="560"  top="-115"  reflect="false"  ]
[tb_start_text mode=1 ]
#
珀耳塞福涅最初总是神情低落。[p]
[_tb_end_text]

[chara_mod  name="ペルセポネ_"  time="200"  cross="false"  storage="chara/26/Per_kusho.png"  ]
[tb_start_text mode=1 ]
#
但她毕竟是个情感丰富的少女。[r]
渐渐会在哈迪斯面前流露各种表情。[p]
[_tb_end_text]

[chara_mod  name="ペルセポネ_"  time="200"  cross="false"  storage="chara/26/Per_bisho.png"  ]
[tb_start_text mode=1 ]
#
珀耳塞福涅带给哈迪斯的变化或许微不足道。[r]
但对日复一日的哈迪斯而言，她的一切都新鲜动人。[p]
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="true"  ]
[bg  time="0"  method="crossfade"  storage="bak/aides_gyokza.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#
珀耳塞福涅带来的改变教会了温暖，同时也让哈迪斯体会到痛苦。[p]
每当珀耳塞福涅返回人间，哈迪斯心中就像裂开巨大空洞。[p]
像往常那样工作，尚能转移注意。[r]
但空洞无法填补。不可遏止地渴望见到她。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
不知不觉间，珀耳塞福涅相伴左右已成为哈迪斯的不变日常。[p]
[_tb_end_text]

[tb_image_show  time="1000"  storage="default/w_kanbotan.png"  width="167"  height="253"  x="560"  y="211"  _clickable_img=""  name="img_114"  ]
[tb_start_text mode=1 ]
#
哈迪斯设法通过冥府之花，与地上的珀耳塞福涅交谈。[r]
纵然分离也能感知她的气息——这至少是种慰藉。[p]
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[tb_image_hide  time="0"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[chara_show  name="ハデス_"  time="600"  wait="false"  storage="chara/27/Hades_bisho.png"  width="720"  height="1350"  left="60"  top="-85"  reflect="false"  ]
[chara_show  name="ペルセポネ_"  time="600"  wait="true"  storage="chara/26/Per_bisho.png"  width="720"  height="1350"  left="500"  top="-115"  reflect="false"  ]
[tb_start_text mode=1 ]
#
当珀耳塞福涅回到冥界并驻留期间，他们共同处理了大量事务。[p]
虽偶尔遭遇难题，珀耳塞福涅始终全力辅佐哈迪斯。[p]
[_tb_end_text]

[jump  storage="cross2.ks"  target="*start"  cond=""  ]
[s  ]
