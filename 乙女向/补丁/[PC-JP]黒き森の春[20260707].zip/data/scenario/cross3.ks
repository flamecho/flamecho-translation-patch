﻿[_tb_system_call storage=system/_cross3.ks]

[plugin name=auto_indent]

[plugin name="backlog"]

*start

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[stopbgm  time="2000"  fadeout="true"  ]
[chara_hide_all  time="0"  wait="true"  ]
[tb_show_message_window  ]
[bg  time="0"  method="crossfade"  storage="kuro.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#
众神的验证开始了。[r]
天界追踪着这位未经忘却便转世的英雄的一举一动。[p]
[_tb_end_text]

[bg  time="1000"  method="crossfade"  storage="bak/aides_gyokza.jpg"  ]
[playbgm  volume="15"  time="1000"  loop="true"  storage="bgm/hades_off.mp3"  ]
[chara_show  name="ハデス2"  time="600"  wait="true"  storage="chara/18/hades1_magao.png"  width="700"  height="1313"  left="300"  top="-78"  reflect="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
（雅典娜的选择，确实符合了我的要求）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
（即便经历多次转世，英雄的力量也并未显著增强。[r]
反而随着次数增加，灵魂逐渐磨损）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
（最终在状态不稳定时，被阿波罗煽动）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
（仅凭保留记忆，人类不可能获得匹敌神明的力量。[r]
能确认这点，倒也并非全无收获。只是——）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
（我们得到这个结论的代价，是让英雄背负了过量的生命）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
（灵魂虽已粉碎，但此刻那英雄正在我的领地）[p]
（不能再继续了。到此为止）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
哈迪斯能为英雄做的，不过是允许四散灵魂的残渣留在冥界，[r]
仅此而已。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
（那两只鸟儿也一样）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
曾侍奉英雄的雅典娜猫头鹰，至今仍深陷在英雄之死的自责与悲痛中。[r]
连伤势也难以痊愈。[p]
猫头鹰对英雄的哀悼之情深邃而静谧。[r]
那份真挚的思念，为黑杨树之森镀上柔和的光芒。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
乌鸦也代替主人阿波罗，在冥府履行着职责。[p]
据说乌鸦与猫头鹰还是青梅竹马。[r]
乌鸦拼命支撑着受伤的猫头鹰。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
既然收留了这些渺小生灵，哈迪斯也必须庇护它们。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「刻耳柏洛斯」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_show  name="ケルベロス"  time="800"  wait="true"  storage="chara/16/Cerberus.png"  width="560"  height="1050"  left="-25"  top="140"  reflect="false"  ]
[tb_start_text mode=1 ]
#
听到哈迪斯的呼唤，刻耳柏洛斯现出身形。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「那两只鸟虽是珀耳塞福涅的朋友，但也是冥界的客人」[p]
「在珀耳塞福涅离开期间，就由刻耳柏洛斯你代为关照吧」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_hide_all  time="800"  wait="true"  ]
[tb_start_text mode=1 ]
#
所幸乌鸦性情极为开朗，很快就和刻耳柏洛斯熟络起来。[p]
就这样在珀耳塞福涅前往人间的日子里，两只鸟儿过着平静的生活。[p]
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#
随着时光流逝，猫头鹰的灵魂恢复进展顺利。[p]
将猫头鹰与乌鸦归还给雅典娜和阿波罗的日子正逐步临近。[p]
[_tb_end_text]

[chara_show  name="ペルセポネ2"  time="600"  wait="true"  storage="chara/17/per1_egao.png"  width="688"  height="1290"  left="120"  top="-100"  reflect="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「我回来了」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_show  name="ハデス2"  time="500"  wait="true"  storage="chara/18/hades1_magao.png"  width="700"  height="1313"  left="500"  top="-78"  reflect="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「啊，欢迎回来」[p]
[_tb_end_text]

[chara_mod  name="ペルセポネ2"  time="0"  cross="false"  storage="chara/17/per1_bisho.png"  ]
[tb_start_text mode=1 ]
#哈迪斯
「……发生什么事了吗？」[p]
[_tb_end_text]

[chara_mod  name="ペルセポネ2"  time="0"  cross="false"  storage="chara/17/per1_odoroki.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「诶？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「你看起来很高兴的样子」[p]
[_tb_end_text]

[chara_mod  name="ペルセポネ2"  time="0"  cross="false"  storage="chara/17/per1_egao.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「呵呵，果然瞒不过哈迪斯大人呢」[p]
[_tb_end_text]

[chara_mod  name="ペルセポネ2"  time="0"  cross="false"  storage="chara/17/per1_bisho.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「今天又和那两个孩子聊了很久。真的很开心」[p]
[_tb_end_text]

[chara_mod  name="ペルセポネ2"  time="0"  cross="false"  storage="chara/17/per1_egao.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「要是那些孩子能留在冥界就好了，[r]
我经常和刻耳柏洛斯这么聊呢」[p]
[_tb_end_text]

[chara_mod  name="ペルセポネ2"  time="0"  cross="false"  storage="chara/17/per1_bisho.png"  ]
[tb_start_text mode=1 ]
#哈迪斯
「那两只鸟儿是雅典娜与阿波罗的眷属。[r]
想必不会离开主人身边吧」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「虽说确实如此…但若能选择的话就好了」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「在这满是既定安排的世界里，[r]
哪怕只有一件事能挺起胸膛说是自己选的，也会让人更有底气吧」[p]
[_tb_end_text]

[chara_mod  name="ペルセポネ2"  time="0"  cross="false"  storage="chara/17/per1_egao.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「我自己就是这样」[p]
[_tb_end_text]

[chara_mod  name="ペルセポネ2"  time="0"  cross="false"  storage="chara/17/per1_bisho.png"  ]
[chara_mod  name="ハデス2"  time="0"  cross="false"  storage="chara/18/hades1_kusho.png"  ]
[tb_start_text mode=1 ]
#哈迪斯
「……这样啊」[p]
[_tb_end_text]

[chara_mod  name="ハデス2"  time="0"  cross="false"  storage="chara/18/hades1_magao.png"  ]
[tb_start_text mode=1 ]
#
天理即是天理，永世不变。[r]
即便神明也必须遵从既定的天条。[p]
但珀耳塞福涅所言也不无道理。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
总有人会把自己所选的，从命中注定之事中区分开来。[p]
正如珀耳塞福涅说自己便是如此。[r]
就像阿波罗当年虽明晓天理，仍以子为荣试图报复那般。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
哈迪斯大概也在无意识中，有过自行抉择的时刻吧。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「——既然如此，让你来给予选择权吧」[p]
[_tb_end_text]

[chara_mod  name="ペルセポネ2"  time="0"  cross="false"  storage="chara/17/per1_odoroki.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「我来吗？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[tb_image_show  time="1000"  storage="default/grape.png"  width="285"  height="285"  x="480"  y="170"  _clickable_img=""  name="img_68"  ]
[chara_mod  name="ペルセポネ2"  time="0"  cross="false"  storage="chara/17/per1_egao.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「哇啊……！好大的黑葡萄！」[p]
[_tb_end_text]

[chara_mod  name="ペルセポネ2"  time="0"  cross="false"  storage="chara/17/per1_bisho.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「长得真饱满呢。可以收下吗？」[p]
[_tb_end_text]

[chara_mod  name="ハデス2"  time="0"  cross="false"  storage="chara/18/hades1_kusho.png"  ]
[tb_start_text mode=1 ]
#哈迪斯
「本就是为你准备的。随你处置便好」[p]
[_tb_end_text]

[chara_mod  name="ハデス2"  time="0"  cross="false"  storage="chara/18/hades1_magao.png"  ]
[chara_mod  name="ペルセポネ2"  time="0"  cross="false"  storage="chara/17/per1_egao.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「呵呵，非常感谢！」[p]
[_tb_end_text]

[chara_mod  name="ペルセポネ2"  time="0"  cross="false"  storage="chara/17/per1_bisho.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「我会试着告诉他们：若愿意的话可以尝尝冥界的葡萄——[r]
也可以选择成为冥界的住民哦」[p]
[_tb_end_text]

[chara_mod  name="ペルセポネ2"  time="0"  cross="false"  storage="chara/17/per1_egao.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「要是那两个孩子不吃的话，就由我来享用吧」[p]
[_tb_end_text]

[chara_mod  name="ペルセポネ2"  time="0"  cross="false"  storage="chara/17/per1_bisho.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「请哈迪斯大人和我一起分享」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
（与珀耳塞福涅共食……）[p]
[_tb_end_text]

[chara_mod  name="ハデス2"  time="200"  cross="false"  storage="chara/18/hades1_kusho.png"  ]
[tb_start_text mode=1 ]
#哈迪斯
「好。就这么办吧」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="true"  ]
[tb_image_hide  time="0"  ]
[bg  time="0"  method="crossfade"  storage="kuro.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#
而后时光再度流转。[p]
珀耳塞福涅前些天才刚前往人间。[r]
哈迪斯正在冥宫埋头处理公务。[p]
[_tb_end_text]

[bg  time="1000"  method="crossfade"  storage="bak/aides_gyokza.jpg"  ]
[chara_show  name="ハデス2"  time="500"  wait="true"  storage="chara/18/hades1_magao.png"  width="700"  height="1313"  left="290"  top="-78"  reflect="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
（这部分事务已处理完毕。接下来——）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_hide  name="ハデス2"  time="800"  wait="true"  pos_mode="false"  ]
[tb_start_text mode=1 ]
#塔纳托斯
陛下[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_show  name="タナトス_"  time="600"  wait="false"  storage="chara/30/Tanatos_sibui.png"  width="640"  height="1200"  left="710"  top="-50"  reflect="false"  ]
[chara_show  name="ハデス2"  time="600"  wait="true"  storage="chara/18/hades1_magao.png"  width="640"  height="1200"  left="280"  top="-60"  reflect="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「是塔纳托斯啊。有何要事？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#塔纳托斯
「您又在工作……请稍作休息吧」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「待这些处理完便休息」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#塔纳托斯
陛下[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「我知道。没说永不休息」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
珀耳塞福涅不在身旁时，总忍不住伸手处理政务。[p]
虽然我觉得比从前更常休息了，[r]
但据周围人说，似乎还是在不停工作。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#？？？
「大王，又在工作啊？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_show  name="ケルベロス"  time="800"  wait="false"  storage="chara/16/Cerberus.png"  width="520"  height="975"  left="-31"  top="129"  reflect="false"  ]
[chara_show  name="カラス"  time="800"  wait="false"  storage="chara/24/kou_karas.png"  width="361"  height="677"  left="538"  top="-25"  reflect="false"  ]
[chara_show  name="梟"  time="800"  wait="true"  storage="chara/23/mize3_owl.png"  width="343"  height="643"  left="739"  top="161"  reflect="false"  ]
[chara_mod  name="タナトス_"  time="0"  cross="false"  storage="chara/30/Tanatos_magao.png"  ]
[tb_start_text mode=1 ]
#
与刻耳柏洛斯一同，乌鸦和猫头鹰走进了玉座之厅。[p]
它们是阿波罗眷属的乌鸦，和雅典娜眷属的猫头鹰。[r]
乌鸦毫不客气地停到哈迪斯肩上，猫头鹰则落在塔纳托斯伸出的手臂上。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#乌鸦
「我们啊，被珀耳塞福涅嘱咐了。[r]
说不能让大王您工作过度」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
这两只鸟，如今仍生活在黑杨树之森。[p]
看来已经完全适应冥界了。[r]
像这样造访冥宫也是常有的事。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「不过呢……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#猫头鹰
「哈迪斯大人，今天我用冥界特产的水果[r]
试着烤了珀耳塞福涅大人喜欢的点心。」[p]
「想等她回来时呈上，[r]
能请您尝尝试作品吗？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#乌鸦
「要是说这是大王送的礼物，珀耳塞福涅肯定会开心。[r]
来来，休息会儿吧」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#猫头鹰
「塔纳托斯大人也请务必」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#塔纳托斯
「多谢。我让侍女准备饮品吧」[p]
「冥王也是。可以吧？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「嗯……」[p]
[_tb_end_text]

[chara_mod  name="ハデス2"  time="200"  cross="false"  storage="chara/18/hades1_kusho.png"  ]
[tb_start_text mode=1 ]
#哈迪斯
「真是的——好生热闹」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="true"  ]
[bg  time="0"  method="crossfade"  storage="bak/aides_hall.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#
昔日哈迪斯曾独自降临冥界。[r]
遵循既定法则，致力于冥界的治理与统辖。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
法则本身不变，但若人类或其他神明介入，就会发生意外。[p]
然而哈迪斯遇见了珀耳塞福涅。知晓了温暖与伤痛。[r]
如今他明白，流转与变化本就是"理"内含的本质。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
「哈迪斯大人，请到这边坐！」[r]
「大王！快趁热吃啊！」[p]
[_tb_end_text]

[chara_show  name="ペルセポネ2"  time="500"  wait="true"  storage="chara/17/per1_egao2.png"  width="800"  height="1500"  left="258"  top="-181"  reflect="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
『哈迪斯大人』[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
与鸟儿们的声音重叠，珀耳塞福涅的嗓音浮现心间。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
对哈迪斯而言，珀耳塞福涅是温暖与变迁的象征。[r]
所有能唤起她身影的事物，都令人怜爱。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「好——这就来」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_hide  name="ペルセポネ2"  time="1000"  wait="true"  pos_mode="false"  ]
[tb_start_text mode=1 ]
#
在大地深处的冥王宫殿，今天也充盈着春天的余香。[p]
[_tb_end_text]

[wait  time="500"  ]
[tb_image_show  time="1000"  storage="default/end.png"  width="142"  height="67"  x="740"  y="275"  _clickable_img=""  ]
[wait  time="1500"  ]
[tb_image_hide  time="1000"  ]
[jump  storage="extras.ks"  target="*top"  ]
[tb_start_text mode=1 ]
[ruby text="ようや"][p]
[_tb_end_text]

