﻿[_tb_system_call storage=system/_after2.ks]

[plugin name=auto_indent]

[plugin name="backlog"]

*start

[stopbgm  time="1000"  fadeout="true"  ]
[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[tb_image_hide  time="0"  ]
[tb_ptext_hide  time="0"  ]
[tb_show_message_window  ]
[bg  time="1000"  method="crossfade"  storage="kuro.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[bg  time="1000"  method="crossfade"  storage="bak/aides_gyokza.jpg"  ]
[playbgm  volume="15"  time="1000"  loop="true"  storage="bgm/hades_off.mp3"  ]
[chara_show  name="ペルセポネ"  time="500"  wait="false"  storage="chara/10/Per_base.png"  width="720"  height="1350"  left="500"  top="-115"  reflect="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_magao_eyeB.png"  mouth="Per_p_magao_mouthA.png"  ]
[wait  time="300"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「呼……」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_magao_eyeB.png"  mouth="Per_p_magao_mouthA2.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（虽然获准旁听哈迪斯大人的公务，但还是有很多不懂的地方）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeB.png"  mouth="Per_p_magao_mouthA2.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（法律和地理好歹算掌握了大概。[r]
看来还需要多加学习）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_show  name="ハデス"  time="500"  wait="false"  storage="chara/11/Hades_base.png"  width="720"  height="1350"  left="60"  top="-85"  reflect="false"  ]
[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeA.png"  mouth="Hades_p_bisho_mouthA.png"  wait="false"  ]
[wait  time="800"  ]
[tb_start_text mode=1 ]
#哈迪斯
「累了吗」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeA.png"  mouth="Per_p_kusho_mouthA.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「哈迪斯大人」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「从中间开始就跟不上讨论了。[r]
做的记录也渐渐乱成一团」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「拿给我看看」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「是」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeB.png"  mouth="Hades_p_bisho_mouthA2.png"  wait="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeB.png"  mouth="Per_p_kusho_mouthA2.png"  ]
[tb_start_text mode=1 ]
#哈迪斯
「……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（哈迪斯大人就像老师一样。[r]
总是细致地检查我的工作呢）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeC.png"  mouth="Per_p_magao_mouthA2.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（今天做得太差了，肯定全是需要修改的地方……）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeB.png"  mouth="Per_p_magao_mouthA2.png"  ]
[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeA.png"  mouth="Hades_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「前半部分写得不错」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「！」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「是在记录死者名字增加时混乱了吧？[r]
看起来没能集中精力听取亡魂的声音」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeA.png"  mouth="Per_p_kusho_mouthA.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「您说得对」[p]
「虽然统称为灵魂，要记录的细节却很多呢」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「不必试图理解全部」[p]
「先把听到的内容记下来。就像现在这样」[p]
「只要能记下灵魂的名字和生前事迹，后续可以补充」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeA.png"  mouth="Per_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「是……！」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeB.png"  mouth="Per_p_bisho_mouthA2.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（在哈迪斯大人身边学习时，连我也能产生干劲）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeC.png"  mouth="Per_p_bisho_mouthA2.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（真是位好老师啊）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeA.png"  mouth="Per_p_bisho_mouthA.png"  ]
[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeA.png"  mouth="Hades_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「稍作休息吧」[p]
「今早从花园带了些果实来吧」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeA.png"  mouth="Per_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「是的。是无花果呢」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeB.png"  mouth="Per_p_bisho_mouthA2.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（哈迪斯大人特意为我培育了各种果实）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeA.png"  mouth="Per_p_bisho_mouthA2.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（全都很好吃呢。又甜又多汁）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeA.png"  mouth="Per_p_bisho_mouthA2.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（因为我是得墨忒耳母亲大人的女儿，待在冥界的话就能收获上等果实，[r]
哈迪斯大人是这么说的——）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeB.png"  mouth="Per_p_bisho_mouthA2.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（但我觉得是因为哈迪斯大人用心栽培，才能结出好果子）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeC.png"  mouth="Per_p_bisho_mouthA2.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（冥界正因为有哈迪斯大人才存在啊）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="true"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[tb_image_show  time="800"  storage="default/ichijiku.png"  width="250"  height="250"  x="520"  y="200"  _clickable_img=""  name="img_68"  ]
[chara_show  name="ペルセポネ"  time="500"  wait="false"  storage="chara/10/Per_base.png"  width="720"  height="1350"  left="500"  top="-115"  reflect="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA.png"  ]
[wait  time="500"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「哇……结得好密」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeB.png"  mouth="Per_p_egao_mouthA2.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（冥界的果实都像矿石般饱满呢。外表也很美丽）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_show  name="ハデス"  time="500"  wait="false"  storage="chara/11/Hades_base.png"  width="720"  height="1350"  left="60"  top="-85"  reflect="false"  ]
[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeA.png"  mouth="Hades_p_bisho_mouthA.png"  wait="false"  ]
[wait  time="500"  ]
[tb_start_text mode=1 ]
#哈迪斯
「我来切吧。过来」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeA.png"  mouth="Per_p_kusho_mouthA.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「那个……好的」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeA.png"  mouth="Per_p_kusho_mouthA2.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（哈迪斯大人总是亲手喂到我嘴里）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeB.png"  mouth="Per_p_kusho_mouthA2.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（虽然很开心——但这种互动像夫妻又像亲子。[r]
在哈迪斯大人眼里，我显得很孩子气吧……）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[mask  time="800"  effect="fadeIn"  color="0x000000"  ]
[tb_image_hide  time="0"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeC.png"  mouth="Per_p_kusho_mouthA.png"  ]
[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeA.png"  mouth="Hades_p_kusho_mouthA.png"  wait="false"  ]
[mask_off  time="800"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「好吃……！」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeA.png"  mouth="Per_p_egao_mouthA2.png"  ]
[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeB.png"  mouth="Hades_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「熟得恰到好处呢。非常甜」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「那就好」[p]
「再吃一块吧」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeC.png"  mouth="Per_p_egao_mouthA.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「谢谢您」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeA.png"  mouth="Hades_p_kusho_mouthA.png"  wait="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeA.png"  mouth="Per_p_bisho_mouthA2.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（哈迪斯大人切果实时的温柔侧脸……。[r]
看到这样的表情，就不好意思说"我自己能吃了"）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「过来」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_bisho_eyeA.png"  mouth="Per_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「是」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[wait  time="200"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「啊！」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_odoroki_eyeA.png"  mouth="Hades_p_odoroki_mouthA.png"  wait="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeB.png"  mouth="Per_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（糟了……果肉太软没能好好咀嚼。[r]
汁水从嘴角流下来了）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeB.png"  mouth="Per_p_kusho_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（简直像小孩子似的……得赶快擦掉）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeA.png"  mouth="Per_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「让您看到如此失态的样子，实在——」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_hide  name="ハデス"  time="600"  wait="true"  pos_mode="false"  ]
[tb_start_text mode=1 ]
#
——舔舐。[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「……」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_fukure_eyeA.png"  mouth="Per_p_odoroki_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（刚、刚才哈迪斯大人舔了我的……！？）[p]

[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_show  name="ハデス"  time="500"  wait="false"  storage="chara/11/Hades_base.png"  width="720"  height="1350"  left="180"  top="-85"  reflect="false"  ]
[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeA.png"  mouth="Hades_p_kusho_mouthA.png"  wait="false"  ]
[wait  time="500"  ]
[tb_start_text mode=1 ]
#哈迪斯
「确实很甜。这次的品质也很不错」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_hide  name="ハデス"  time="600"  wait="true"  pos_mode="false"  ]
[tb_start_text mode=1 ]
#
——啾。[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_fukure_eyeA.png"  mouth="Per_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「……！！」[p]

[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_show  name="ハデス"  time="500"  wait="false"  storage="chara/11/Hades_base.png"  width="720"  height="1350"  left="180"  top="-85"  reflect="false"  ]
[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeB.png"  mouth="Hades_p_kusho_mouthA.png"  wait="false"  ]
[wait  time="500"  ]
[tb_start_text mode=1 ]
#哈迪斯
「余味很浓郁。——正合我意」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeA.png"  mouth="Hades_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「要再…多品尝一会儿吗？」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_fukure_eyeB.png"  mouth="Per_p_odoroki_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「唔……」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_fukure_eyeB.png"  mouth="Per_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「请、请便……」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeB.png"  mouth="Hades_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「谢谢」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="false"  ]
[bg  time="0"  method="crossfade"  storage="kuro.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[bg  time="1000"  method="crossfade"  storage="bak/aides_gyokza.jpg"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（后来，我和哈迪斯大人接吻了很多次）[p]
（哈迪斯大人特意为我准备的无花果，带着无比甜美的滋味）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#

[_tb_end_text]

[wait  time="500"  ]
[tb_image_show  time="1000"  storage="default/end.png"  width="142"  height="67"  x="710"  y="250"  _clickable_img=""  ]
[wait  time="1500"  ]
[tb_image_hide  time="1000"  ]
[jump  storage="extras.ks"  target="*top"  ]
[s  ]
[tb_start_text mode=1 ]
[ruby text="ようや"][p]
[_tb_end_text]

[tb_start_text mode=1 ]
标题：无花果[p]
[_tb_end_text]

