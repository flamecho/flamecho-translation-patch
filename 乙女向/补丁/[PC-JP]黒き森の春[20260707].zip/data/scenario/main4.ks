﻿[_tb_system_call storage=system/_main4.ks]

*start

[cm  ]
[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[stopbgm  time="1500"  fadeout="true"  ]
[tb_show_message_window  ]
[chara_hide_all  time="0"  wait="true"  ]
[bg  time="0"  method="crossfade"  storage="kuro.jpg"  ]
[mask_off  time="1500"  effect="fadeOut"  ]
[bg  time="1000"  method="crossfade"  storage="bak/popula2.jpg"  ]
[playbgm  volume="15"  time="1000"  loop="true"  storage="bgm/hades_off.mp3"  ]
[tb_start_text mode=1 ]
#
从那之后，珀耳塞福涅每天都去森林。[p]
刻耳柏洛斯趴在水晶洞穴里，等着珀耳塞福涅出来。[p]
当珀耳塞福涅唤它时，它便慢吞吞地撑起身子。[r]
然后配合着珀耳塞福涅的步调，与她同行。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
每当珀耳塞福涅想进入森林深处，刻耳柏洛斯就会扯住她的衣角。[r]
它就这样仔细守护着她，让她不会在森林里迷路。[p]
[_tb_end_text]

[chara_show  name="ペルセポネ"  time="500"  wait="false"  storage="chara/10/Per_base.png"  width="720"  height="1350"  left="480"  top="-115"  reflect="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_bisho_eyeA.png"  mouth="Per_p_bisho_mouthA.png"  wait="false"  ]
[wait  time="300"  ]
[tb_start_text mode=1 ]
#
珀耳塞福涅总是在看得清归途的范围内，触摸树木或采摘鲜花。[p]
编花环时总是不例外，她稍稍改变形状，编出三个。[r]
为的是分别挂在刻耳柏洛斯的脖子上。[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeA.png"  mouth="Per_p_egao_mouthA.png"  wait="false"  ]
[chara_show  name="ケルベロス"  time="500"  wait="true"  storage="chara/16/Cerberus.png"  width="620"  height="1163"  left="50"  top="130"  reflect="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「呵呵，真可爱。很适合你呢」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
刻耳柏洛斯起初还会歪着脑袋不解，[r]
近来只要珀耳塞福涅呼唤，它就会主动低下头。[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_bisho_eyeA.png"  mouth="Per_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「在地上时，我也常这样编花环。[r]
编得好的就和精灵们交换，或是送给母神……」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_bisho_eyeA.png"  mouth="Per_p_naki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「好想见母神啊……」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_naki_eyeA.png"  mouth="Per_p_naki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#
只有在刻耳柏洛斯面前，她才能吐露真心。[r]
双眼经常止不住地落下泪来。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
连森林也好似笼罩在忧郁的青灰色中。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「我知道哈迪斯大人待我很好。[r]
可还是会寂寞，还是会不明白为什么……」[p]
「为什么偏偏是我呢？[r]
父神为什么连一句话都不曾对我说？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
当然，刻耳柏洛斯什么也不会回答。[r]
只是在珀耳塞福涅哭泣时，常常将身躯紧贴着她。[p]
感受着刻耳柏洛斯的体温，她的心情便能平静下来。[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_bisho_eyeA.png"  mouth="Per_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「——谢谢。刻耳柏洛斯真温柔呢」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_magao_eyeA.png"  mouth="Per_p_naki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「是不是觉得我很不懂事？像个小孩子？」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeA.png"  mouth="Per_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「没办法呀。我自幼就深得母神宠爱。[r]
要是刻耳柏洛斯突然被带离哈迪斯大人身边，也会伤心的吧？」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_bisho_eyeA.png"  mouth="Per_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「啊，不过若是刻耳柏洛斯，自己就能回到哈迪斯大人身边吧。[r]
要是我也有刻耳柏洛斯那样的力量就好了」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_magao_eyeA.png"  mouth="Per_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#
其实就算力量再强，恐怕也难以离开冥界。[r]
既定之事，终究难以颠覆。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「可若是拥有力量——至少最初就不会被当成局外人了吧。[r]
说不定还能反抗这样的命运」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeA.png"  mouth="Per_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「虽然都是些如果当初的假设罢了」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_hide_all  time="800"  wait="true"  ]
[tb_start_text mode=1 ]
#
珀耳塞福涅就这样将悲伤与寂寞，倾泻在黑杨树之森里。[p]
虽说事态并未因此发生什么改变，[r]
但至少不用在冥宫里哭得狼狈不堪了。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_show  name="タナトス"  time="800"  wait="false"  storage="chara/15/Tanatos_base.png"  width="700"  height="1313"  left="280"  top="-70"  reflect="false"  ]
[chara_part  name="タナトス"  time="800"  eye="Tanatos_p_magao_eyeA.png"  mouth="Tanatos_p_magao_mouthA.png"  wait="true"  ]
[tb_start_text mode=1 ]
#？？？
「……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[bg  time="0"  method="crossfade"  storage="kuro.jpg"  ]
[chara_hide_all  time="0"  wait="true"  ]
[mask_off  time="1500"  effect="fadeOut"  ]
[bg  time="1000"  method="crossfade"  storage="bak/aides_gyokza.jpg"  ]
[chara_show  name="ハデス"  time="500"  wait="false"  storage="chara/11/Hades_base.png"  width="752"  height="1410"  left="280"  top="-90"  reflect="false"  ]
[chara_part  name="ハデス"  time="500"  eye="Hades_p_bisho_eyeA.png"  mouth="Hades_p_magao_mouthA2.png"  wait="true"  ]
[wait  time="500"  ]
[tb_start_text mode=1 ]
#哈迪斯
（刻耳柏洛斯的气息正在靠近…今日的散步就到此为止吧）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
（但愿能让王妃的心情稍作纾解）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_hide_all  time="800"  wait="true"  ]
[bg  time="600"  method="crossfade"  storage="kuro.jpg"  ]
[bg  time="1000"  method="crossfade"  storage="bak/aides_hall.jpg"  ]
[chara_show  name="ハデス"  time="500"  wait="false"  storage="chara/11/Hades_base.png"  width="720"  height="1350"  left="10"  top="-85"  reflect="false"  ]
[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA2.png"  wait="false"  ]
[chara_show  name="タナトス"  time="500"  wait="false"  storage="chara/15/Tanatos_base.png"  width="700"  height="1313"  left="580"  top="-70"  reflect="false"  ]
[chara_part  name="タナトス"  time="0"  eye="Tanatos_p_magao_eyeA.png"  mouth="Tanatos_p_magao_mouthA.png"  wait="false"  ]
[wait  time="600"  ]
[tb_start_text mode=1 ]
#塔纳托斯
陛下[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
正当哈迪斯走向正厅时，死神塔纳托斯出声唤住了他。[p]
塔纳托斯乃夜之女神倪克斯的子嗣。[r]
作为幽冥众——栖居在黑杨树之森深处的古老神祇之一。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
若说赫尔墨斯负责引导英雄与神眷之魂前往冥界，[r]
那么凡人与罪人的魂魄回收押送，则主要由塔纳托斯承担。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
幽冥众虽皆遵奉哈迪斯统治，但塔纳托斯尤为冥界尽心效力。[p]
[_tb_end_text]

[chara_part  name="タナトス"  time="0"  eye="Tanatos_p_sibu_eyeA.png"  mouth="Tanatos_p_sibu_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#塔纳托斯
「珀耳塞福涅大人今日又外出呢。[r]
全然未尽王妃之责」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「……！」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
塔纳托斯话音刚落，入口处便传来珀耳塞福涅的气息。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
却未闻往日常有的，她那轻柔欢快的问候声。[r]
看来是躲到廊柱后面去了。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#塔纳托斯
「来冥宫途中正好瞧见。[r]
她似乎频频造访黑杨树之森」[p]
「是否该让王妃更清楚自己的身份？[r]
长此以往只会徒增陛下的负担」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#
塔纳托斯向来严守冥界戒律。[p]
想必是期望珀耳塞福涅能恪守冥界之后的仪态与分内之事。[r]
既有宙斯与得墨忒耳之女这等血统...就更该如此。」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「卿对冥界的忠心，本王自然明白」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「朕亦抱有相同考量。[r]
正因如此，才更要让她先适应冥界的生活」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「王妃已在尽力。[r]
她正用双脚丈量冥土，以切身感受这片疆域」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#塔纳托斯
「话虽如此——」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「刻耳柏洛斯也中意王妃。[r]
纵使是奉我之命，能驯服那家伙的，也只有王妃这般品性的人」[p]
[_tb_end_text]

[chara_part  name="タナトス"  time="0"  eye="Tanatos_p_magao_eyeA.png"  mouth="Tanatos_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#塔纳托斯
「……是啊。我觉得刻耳柏洛斯很听话」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「你的不安我也并非不能理解。[r]
但我的工作量本身与先前相比并无太大变化。[r]
暂时还是打算维持现状」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
见哈迪斯如此断言，塔纳托斯反而显得安心了些。[r]
他点了点头。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#塔纳托斯
「明白了。既然王都说到这个份上」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#塔纳托斯
「——那么，我这就返岗」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
塔纳托斯说完便展开双翼，朝冥宫外飞去。[p]
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="true"  ]
[bg  time="0"  method="crossfade"  storage="bak/aides_hall.jpg"  ]
[chara_show  name="ペルセポネ"  time="0"  wait="false"  storage="chara/10/Per_base.png"  width="720"  height="1350"  left="560"  top="-115"  reflect="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeB.png"  mouth="Per_p_magao_mouthA2.png"  wait="false"  ]
[mask_off  time="1500"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（……）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
珀耳塞福涅怔怔望着那暗色身影消失在青灰色的天空中。[r]
倏然，冥王转头看向珀耳塞福涅。[p]
[_tb_end_text]

[chara_show  name="ハデス"  time="500"  wait="false"  storage="chara/11/Hades_base.png"  width="720"  height="1350"  left="30"  top="-85"  reflect="false"  ]
[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[wait  time="500"  ]
[tb_start_text mode=1 ]
#哈迪斯
「可以出来了」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「！」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeB.png"  mouth="Per_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#
珀耳塞福涅的藏身处早被冥王看穿。[r]
她轻移莲步走上前去。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「我回来了……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
珀耳塞福涅小声问候着。[p]
因为自己的缘故，让冥王受到冥界老臣的诤谏。[p]
冥王却维护了她。[r]
愧疚感充满了珀耳塞福涅的心。[r]
她不敢直视冥王的脸。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「森林景象如何」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「咦？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
珀耳塞福涅像被烫到般猛地抬头。[p]
两人的视线在空中相撞。[r]
冥界之王静静等着她的回答。[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeB.png"  mouth="Per_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「那个……和往常没什么不同。[r]
整片森林都泛着蓝光，像是沐浴着月光之夜」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「是吗」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
对话在此中断。[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_magao_eyeB.png"  mouth="Per_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
珀耳塞福涅慌张起来。[p]
冥王分明是支持她去森林的。[r]
她觉得必须给出配得上这份支持的说明。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
可越是着急，脑子里就越是一片空白。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#塔纳托斯
『是否该让她更有身为王妃的自觉？』[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
方才塔纳托斯神的话语不受控制地涌上心头。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（怎么办）[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#
无力感愈发强烈。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「……」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「要不要——吃点东西？」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「诶」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
珀耳塞福涅急切地反问。[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「吃东西……是指什么？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「来到冥界后，你一直没进食吧。[r]
讨厌这里的食物？」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeB.png"  mouth="Per_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「不，不是这样……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「那么，喜欢什么」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
冥王用认真的眼神询问道。[p]
毕竟王也是同等级的神明，珀耳塞福涅就算不进食也不会困扰这件事，[r]
他应该是理解的。[p]
尽管如此还要提起这样的话题，[r]
或许是想帮我分散注意力吧。[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_bisho_eyeA.png"  mouth="Per_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#
感受到王的体贴，珀耳塞福涅的心情也平静下来。[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_bisho_eyeA.png"  mouth="Per_p_bisho_mouthA.png"  wait="false"  ]
[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「是啊……我还是最喜欢谷物和水果。[r]
受到母亲祝福的农作物，每一样都特别美味呢」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「……」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#
王沉思数秒后，终于点了点头。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「明白了。我会准备」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（居然要为我准备……）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeA.png"  mouth="Per_p_egao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「谢谢您」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「是啊」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「说起来，你好像经常送花环给刻耳柏洛斯」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「啊，是的」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「被你这样疼爱，那家伙也很开心。[r]
它多数时候令人畏惧，几乎没有能亲近的对象。希望你能好好待它」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（原来如此……明明是那么乖巧的孩子）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeC.png"  mouth="Per_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「好的。当然愿意」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_bisho_eyeA.png"  mouth="Per_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「我给那三个头分别准备了不同的花环。[r]
虽然都长着威风凛凛的脸，但个性其实各不相同呢」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeA.png"  mouth="Per_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「不过它们都很聪明对吧？[r]
有次把常戴的花环换给别的头戴，结果跟我闹脾气了……」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_odoroki_eyeA.png"  mouth="Hades_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「刻耳柏洛斯也会闹脾气么」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「这说明它们相当中意你啊」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeA.png"  mouth="Per_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「我很高兴」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「想必是因为你的心灵纯净澄澈吧」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeA.png"  mouth="Per_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「那个……」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeB.png"  mouth="Per_p_kusho_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（哈迪斯大人似乎高估我了。[r]
我的心根本不澄澈。总是充满悲伤……）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
但她无法向王坦露真实想法。[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_magao_eyeA.png"  mouth="Per_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（至少，在冥界我能派上什么用场吗）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_magao_eyeA.png"  mouth="Per_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「哈迪斯大人，如果有需要处理的工作，我愿意学习」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_odoroki_eyeA.png"  mouth="Hades_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「……」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「甚好」[p]
「慢慢适应即可。你存在于此本身就有意义」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（我存在于这里的……）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_bisho_eyeA.png"  mouth="Per_p_bisho_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（哈迪斯大人真是温柔啊）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_bisho_eyeA.png"  mouth="Per_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「谢谢您」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
虽然还没法完全整理好心情。[p]
但为了善待自己的王，她隐约觉得应该尝试做些力所能及的事。[p]
[_tb_end_text]

[jump  storage="main5.ks"  target="*start"  ]
[s  ]
[tb_start_text mode=1 ]
[ruby text="ようや"][p]
[_tb_end_text]

