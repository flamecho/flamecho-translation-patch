﻿[_tb_system_call storage=system/_cross2.ks]

[plugin name=auto_indent]

[plugin name="backlog"]

[playbgm  volume="15"  time="1000"  loop="true"  storage="bgm/hades_off.mp3"  ]
*start

[cm  ]
[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="true"  ]
[tb_show_message_window  ]
[bg  time="0"  method="crossfade"  storage="bak/aides_gyokza.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#
某日，冥界突然停止了灵魂的流入。[p]
[_tb_end_text]

[chara_show  name="ハデス_"  time="500"  wait="true"  storage="chara/27/Hades_magao.png"  width="720"  height="1350"  left="50"  top="-85"  reflect="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
（怎么回事？发生什么了？）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
死亡本该平等降临于所有人类。[p]
即便因瘟疫、灾祸或战争导致短期内灵魂接收量暴增，[r]
但连续多日数量锐减的情况几乎从未发生。[p]
更何况灵魂流入停滞这种状况，自哈迪斯降临冥界以来更是前所未有。[p]
[_tb_end_text]

[chara_show  name="タナトス_"  time="600"  wait="true"  storage="chara/30/Tanatos_magao.png"  width="700"  height="1313"  left="600"  top="-70"  reflect="false"  ]
[tb_start_text mode=1 ]
#塔纳托斯
陛下[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「塔纳托斯。查明原因了吗」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#塔纳托斯
「是。容我禀报」[p]
[_tb_end_text]

[chara_mod  name="タナトス_"  time="100"  cross="false"  storage="chara/30/Tanatos_sibui.png"  ]
[tb_start_text mode=1 ]
#塔纳托斯
「此次冥界未接收灵魂——准确说是出现'断流'现象，[r]
实为阿波罗神之子阿斯科勒庇俄斯所为」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「阿波罗的……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
身为宙斯之子的阿波罗乃是医神。[r]
既然是其子嗣，传承医术精华也在情理之中。[p]
但无论何等超凡之力，都不该违逆死亡。[r]
死亡即为法则本身。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#塔纳托斯
「阿斯科勒庇俄斯似乎在钻研医术时，觉醒了特殊力量」[p]
「能令亡者——重获新生的力量」[p]
[_tb_end_text]

[chara_mod  name="ハデス_"  time="0"  cross="false"  storage="chara/27/Hades_odoroki.png"  ]
[tb_start_text mode=1 ]
#哈迪斯
「！」[p]
「本该汇入冥界的灵魂，竟被那人强行召回阳世……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[mask  time="800"  effect="fadeIn"  color="0x000000"  ]
[tb_filter_grayscale  layer="0"  grayscale="40"  ]
[tb_filter_grayscale  layer="base"  grayscale="50"  ]
[bg  time="0"  method="crossfade"  storage="bak/plain.jpg"  ]
[chara_hide_all  time="0"  wait="true"  ]
[mask_off  time="800"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#阿斯科勒庇俄斯
『我尚未出生便失去母亲。[r]
虽受众人抚养栽培，但无一日不思念母亲』[p]
『不愿他人经历相同苦楚。[r]
只望用这份天赐之力，挽救本该消逝的生命』[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_show  name="アポロン"  time="600"  wait="true"  storage="chara/20/Apollo_bisho.png"  width="720"  height="1350"  left="290"  top="-85"  reflect="false"  ]
[tb_start_text mode=1 ]
#阿波罗
『我的孩子很出色吧』[p]
『心怀此等宏愿者实属罕见。是我的骄傲』[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[mask  time="800"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="true"  ]
[bg  time="0"  method="crossfade"  storage="bak/aides_gyokza.jpg"  ]
[tb_free_filter  layer="base"  ]
[tb_free_filter  layer="0"  ]
[chara_show  name="ハデス_"  time="0"  wait="true"  storage="chara/27/Hades_magao.png"  width="720"  height="1350"  left="50"  top="-85"  reflect="false"  ]
[chara_show  name="タナトス_"  time="0"  wait="true"  storage="chara/30/Tanatos_magao.png"  width="700"  height="1313"  left="600"  top="-70"  reflect="false"  ]
[mask_off  time="800"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#哈迪斯
「阿波罗竟纵容至此……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
起死回生绝非医术的延续。[r]
生与死本有泾渭分明之界。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
阿波罗不会不明白这个法则。他理应清楚。[p]
但身为父亲，对子嗣才能的骄傲终究占了上风。[r]
必是刻意不予斥责，默许其子的行为。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#塔纳托斯
「您意下如何？[r]
若放任不管，灵魂之流将彻底中断」[p]
「人类在地上泛滥，势必加重大地负担。[r]
秩序崩溃只是时间问题」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「绝不能让这种事发生」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「塔纳托斯，立即前往天界宙斯之处」[p]
「对于妄图理解死亡——此等违背天理之举，冥界提出严正抗议，[r]
将吾之言传达给宙斯」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#塔纳托斯
「遵命」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_hide  name="タナトス_"  time="600"  wait="true"  pos_mode="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「何等愚蠢」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[stopbgm  time="1000"  fadeout="true"  ]
[chara_hide_all  time="0"  wait="true"  ]
[bg  time="0"  method="crossfade"  storage="bak/olympos.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[playbgm  volume="12"  time="1000"  loop="true"  storage="bgm/sleep_inwoods.mp3"  ]
[chara_show  name="ゼウス_"  time="600"  wait="true"  storage="chara/29/Zeus_magao.png"  width="748"  height="1408"  left="280"  top="-70"  reflect="false"  ]
[tb_start_text mode=1 ]
#宙斯
「情况我已了解」[p]
「冥界的诉求确有道理。[r]
凡人擅自决定生死，此事绝不可容」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#宙斯
「阿斯科勒庇俄斯的能力过于危险。[r]
此等越界之力必须铲除」[p]
「——将雷霆带到这里来」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[tb_image_show  time="800"  storage="default/thunder.png"  width="640"  height="640"  x="300"  y="-35"  _clickable_img=""  name="img_67"  ]
[wait  time="800"  ]
[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[playse  volume="20"  time="1000"  buf="0"  storage="otologic_thunder4.mp3"  ]
[chara_hide  name="ゼウス_"  time="0"  wait="false"  pos_mode="false"  ]
[bg  time="0"  method="crossfade"  storage="bak/plain2_1.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#阿斯科勒庇俄斯
「！」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[stopse  time="1000"  buf="0"  fadeout="true"  ]
[tb_image_hide  time="800"  ]
[tb_start_text mode=1 ]
#
「阿斯科勒庇俄斯大人！？」[r]
「喂，现在雷电正朝着阿斯科勒庇俄斯大人独自——」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
「阿斯科勒庇俄斯大人！——不行，已经断气了……」[r]
「怎么会……阿斯科勒庇俄斯大人……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_show  name="タナトス_"  time="800"  wait="true"  storage="chara/30/Tanatos_magao.png"  width="700"  height="1313"  left="600"  top="-70"  reflect="false"  ]
[chara_show  name="アポロン"  time="500"  wait="true"  storage="chara/20/Apollo_magao.png"  width="700"  height="1313"  left="20"  top="-80"  reflect="false"  ]
[tb_start_text mode=1 ]
#阿波罗
「父神的雷霆——我察觉到异样赶来……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#阿波罗
「这究竟是怎么回事？为何我的孩子会——」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#塔纳托斯
「此乃天命。随我走」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_hide  name="タナトス_"  time="600"  wait="false"  pos_mode="false"  ]
[chara_mod  name="アポロン"  time="200"  cross="false"  storage="chara/20/Apollo_gekido.png"  ]
[tb_start_text mode=1 ]
#阿波罗
「且慢！塔纳托斯……！」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[mask  time="600"  effect="fadeIn"  color="0x000000"  ]
[chara_hide  name="アポロン"  time="0"  wait="false"  pos_mode="false"  ]
[bg  time="0"  method="crossfade"  storage="bak/plain2_2.jpg"  ]
[mask_off  time="800"  effect="fadeOut"  ]
[playse  volume="5"  time="1000"  buf="0"  storage="otologic_rain2.mp3"  ]
[chara_show  name="アポロン"  time="500"  wait="true"  storage="chara/20/Apollo_magao.png"  width="720"  height="1350"  left="290"  top="-85"  reflect="false"  ]
[tb_start_text mode=1 ]
#阿波罗
「呃……已经走了」[p]
（以我之力无法穿越冥界边界。若是赫尔墨斯或可继续追查——）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#阿波罗
（若那雷霆确属父神旨意，赫尔墨斯断不会点头相助）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#阿波罗
（所谓天命——凡人终有一死）[p]
（这番道理我自然明白。[r]
阿斯科勒庇俄斯不过是渴望用医术救治世人。[r]
并且，他确实获得了这般能力）[p]
[_tb_end_text]

[chara_mod  name="アポロン"  time="200"  cross="false"  storage="chara/20/Apollo_gekido.png"  ]
[tb_start_text mode=1 ]
#阿波罗
「竟以如此方式，将其雷击致死……！」[p]
[_tb_end_text]

[chara_mod  name="アポロン"  time="200"  cross="false"  storage="chara/20/Apollo_magao.png"  ]
[tb_start_text mode=1 ]
#阿波罗
（——裁决已然下达。[r]
即便此刻向父神抗议，也无法改变什么。阿斯科勒庇俄斯也不会复生）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#阿波罗
（但难道就要这样忍气吞声吗。[r]
阿斯科勒庇俄斯——我的孩子被夺走了啊）[p]
[_tb_end_text]

[stopse  time="1000"  buf="0"  fadeout="true"  ]
[tb_start_text mode=1 ]
#阿波罗
「向那些'锻造者'们，实施报复」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_hide  name="アポロン"  time="600"  wait="true"  pos_mode="false"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="buki_yumiya0.mp3"  ]
[wait  time="1300"  ]
[stopse  time="200"  buf="0"  fadeout="true"  ]
[playse  volume="100"  time="1000"  buf="0"  storage="buki_yumiya1.mp3"  ]
[mask  time="600"  effect="fadeIn"  color="0x000000"  ]
[stopse  time="1000"  buf="0"  fadeout="true"  ]
[bg  time="0"  method="crossfade"  storage="bak/olympos.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[chara_show  name="ゼウス_"  time="600"  wait="true"  storage="chara/29/Zeus_magao.png"  width="748"  height="1408"  left="280"  top="-70"  reflect="false"  ]
[tb_start_text mode=1 ]
#
「宙斯大人！」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#宙斯
「何事惊慌」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
「为宙斯大人铸造雷霆的工匠们，尽数死在阿波罗大人的箭下……！」[p]
[_tb_end_text]

[chara_mod  name="ゼウス_"  time="200"  cross="false"  storage="chara/29/Zeus_odoroki.png"  ]
[tb_start_text mode=1 ]
#宙斯
「——竟有此事」[p]
[_tb_end_text]

[chara_mod  name="ゼウス_"  time="200"  cross="false"  storage="chara/29/Zeus_magao.png"  ]
[tb_start_text mode=1 ]
#宙斯
「不直接针对我，却将怒火发泄在雷霆铸造者身上……」[p]
（——不，正因明知无法违逆于我，[r]
阿波罗那厮，才故意用这种方式泄愤吧）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#宙斯
「无论如何，胆敢违抗我决定之人绝不能放任不管」[p]
「必须惩戒阿波罗」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="false"  ]
[bg  time="0"  method="crossfade"  storage="kuro.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[bg  time="1000"  method="crossfade"  storage="bak/olympos.jpg"  ]
[chara_show  name="ゼウス_"  time="600"  wait="false"  storage="chara/29/Zeus_kusho.png"  width="748"  height="1408"  left="570"  top="-70"  reflect="false"  ]
[chara_show  name="ハデス_"  time="600"  wait="true"  storage="chara/27/Hades_magao.png"  width="752"  height="1410"  left="-5"  top="-90"  reflect="false"  ]
[tb_start_text mode=1 ]
#宙斯
「兄长，这次的事真的万分抱歉。[r]
请允许我再次郑重谢罪」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「无妨。你能迅速行动，正说明理解了天界的意志」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#宙斯
「能得您这般体谅，实在令我宽慰」[p]
[_tb_end_text]

[chara_mod  name="ゼウス_"  time="0"  cross="false"  storage="chara/29/Zeus_magao.png"  ]
[tb_start_text mode=1 ]
#宙斯
「今后将制定戒律禁止任何人使用复生之力。[r]
我等绝不染指冥界领域」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#宙斯
「但——虽说是阿波罗的子嗣，[r]
竟会出现掌握复生之力的人类，实在出乎意料」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#宙斯
「今后恐怕还会发生超乎预想的事态」[p]
[_tb_end_text]

[chara_mod  name="ゼウス_"  time="100"  cross="false"  storage="chara/29/Zeus_kusho.png"  ]
[tb_start_text mode=1 ]
#宙斯
「因此想与兄长商议」[p]
[_tb_end_text]

[chara_mod  name="ゼウス_"  time="0"  cross="false"  storage="chara/29/Zeus_magao.png"  ]
[tb_start_text mode=1 ]
#宙斯
「既然已出现能使用复生之力者，[r]
料想迟早会有人类能逃脱冥界的'遗忘'之力」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「遗忘么……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
在阿斯福德之野与幽冥的交界处，流淌着忘川。[p]
漫游阿斯福德尔的游魂既无法认知遗忘，也从不靠近。[r]
唯有保留强烈意志与自我的魂灵，才能觉察那条河流。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
其中被遗忘强烈吸引者，便会踏入川中。[p]
进入忘川的魂灵会逐渐释放记忆，[r]
待一切冲刷殆尽之时，即获转生。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
若有人能不经过遗忘冲刷便得转生——[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「就能无限累积记忆与经验——是吧」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#宙斯
「正是」[p]
「凡人被命运限定的时日皆有定数」[p]
「若可不断延续这等时限，恐怕极其危险」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「我明白宙斯的顾虑了」[p]
「那么，你希望我做什么」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#宙斯
「请准许我验证带记忆转生的容许范围与临界值」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「要用来到冥界的魂灵做实验么？」[p]
[_tb_end_text]

[chara_mod  name="ゼウス_"  time="0"  cross="false"  storage="chara/29/Zeus_kusho.png"  ]
[tb_start_text mode=1 ]
#宙斯
「不」[p]
[_tb_end_text]

[chara_mod  name="ゼウス_"  time="0"  cross="false"  storage="chara/29/Zeus_magao.png"  ]
[tb_start_text mode=1 ]
#宙斯
「如方才所言，我们不会踏足冥界领域」[p]
「只是希望你能答应一件事。[r]
想借用那些尚未坠入冥界的灵魂」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「恕难同意」[p]
「死亡应当平等地降临所有人类」[p]
[_tb_end_text]

[chara_mod  name="ゼウス_"  time="0"  cross="false"  storage="chara/29/Zeus_magao.png"  ]
[tb_start_text mode=1 ]
#宙斯
「我很清楚。[r]
正因如此，这个领域绝不容侵犯」[p]
「兄长，异常状况必将出现。[r]
我们决不能在此刻判断失误」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「……」[p]
「由谁来筛选灵魂？验证方法又是什么？」[p]
[_tb_end_text]

[chara_mod  name="ゼウス_"  time="0"  cross="false"  storage="chara/29/Zeus_bisho.png"  ]
[tb_start_text mode=1 ]
#宙斯
「灵魂交由雅典娜挑选」[p]
「方法是先回收尚未坠入冥界的灵魂，待容器修复后投入转生之环」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#宙斯
「我女儿雅典娜是最能领会我意志的女神。[r]
对灵魂也会予以最审慎的对待」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
确实，以智慧女神雅典娜的名誉，断不会做出违背冥界法则之举。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
所选灵魂想必也是英雄之魂——。[r]
应该会挑选那些容器强韧，能承受保留记忆转生的存在吧。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「仅此还不足以让我点头」[p]
[_tb_end_text]

[chara_mod  name="ゼウス_"  time="0"  cross="false"  storage="chara/29/Zeus_magao.png"  ]
[tb_start_text mode=1 ]
#宙斯
「兄长」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「再加两个条件」[p]
「其一，所选灵魂不得扰乱冥界法则与生死界限」[p]
「其二，验证完成后必须允诺灵魂安息」[p]
「这两条是绝对条件」[p]
[_tb_end_text]

[chara_mod  name="ゼウス_"  time="0"  cross="false"  storage="chara/29/Zeus_bisho.png"  ]
[tb_start_text mode=1 ]
#宙斯
「明白了」[p]
「——女神雅典娜！速来我座前！」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_hide_all  time="600"  wait="true"  ]
[wait  time="400"  ]
[chara_show  name="ハデス_"  time="600"  wait="false"  storage="chara/27/Hades_magao.png"  width="696"  height="1305"  left="-70"  top="-83"  reflect="false"  ]
[chara_show  name="ゼウス_"  time="600"  wait="true"  storage="chara/29/Zeus_bisho.png"  width="688"  height="1290"  left="310"  top="-65"  reflect="false"  ]
[chara_show  name="アテナ"  time="800"  wait="true"  storage="chara/21/athen3_bisho.png"  width="640"  height="1200"  left="700"  top="-50"  reflect="false"  ]
[tb_start_text mode=1 ]
#雅典娜
「您召唤我吗，父神」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="false"  ]
[bg  time="0"  method="crossfade"  storage="kuro.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[bg  time="1000"  method="crossfade"  storage="bak/aides_acheron.jpg"  ]
[chara_show  name="アイアス"  time="500"  wait="true"  storage="chara/25/aias3_magao.png"  width="696"  height="1306"  left="350"  top="-29"  reflect="false"  ]
[tb_start_text mode=1 ]
#
雅典娜选中的灵魂，是曾作为阿卡亚军士兵参与特洛伊战争的[r]
英雄埃阿斯。[p]
[_tb_end_text]

[chara_hide  name="アイアス"  time="800"  wait="true"  pos_mode="false"  ]
[tb_start_text mode=1 ]
#
据说埃阿斯因对女神及周围众人态度傲慢,[r]
被注入疯狂而蒙羞，最终走上自绝之路。[p]
[_tb_end_text]

[bg  time="600"  method="crossfade"  storage="kuro.jpg"  ]
[bg  time="1000"  method="crossfade"  storage="bak/olympos.jpg"  ]
[chara_show  name="ゼウス_"  time="600"  wait="false"  storage="chara/29/Zeus_bisho.png"  width="688"  height="1290"  left="40"  top="-65"  reflect="false"  ]
[chara_show  name="アテナ"  time="600"  wait="true"  storage="chara/21/athen3_bisho.png"  width="640"  height="1200"  left="550"  top="-50"  reflect="false"  ]
[tb_start_text mode=1 ]
#
『其一，所选灵魂不得扰乱冥界法则与生死界限』[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#雅典娜
「埃阿斯的力量仅限于武艺。[r]
没有干涉冥界法则的能力」[p]
「况且他是极度重视荣誉与羞耻心的男人。[r]
若真引起生死界限混乱，想必会主动承担责任」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
『其二，验证完成后必须允诺灵魂安息』[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#雅典娜
「这也是曾与埃阿斯较量的奥德修斯的愿望」[p]
「埃阿斯虽是个傲慢的男人，但终究是阿卡亚的一位英雄。[r]
希望他能直面毁灭自身的根源，追求灵魂的升华」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#宙斯
「好吧」[p]
「转告吾兄。[r]
要在保留记忆的状态下，让他进入轮回之环的——可是英雄埃阿斯」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[jump  storage="cross3.ks"  target="*start"  ]
[s  ]
