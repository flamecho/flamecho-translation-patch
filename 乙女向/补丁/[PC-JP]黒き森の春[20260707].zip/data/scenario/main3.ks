﻿[_tb_system_call storage=system/_main3.ks]

[playbgm  volume="13"  time="1000"  loop="true"  storage="bgm/prologue_anima.mp3"  ]
*start

[cm  ]
[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[tb_show_message_window  ]
[chara_hide_all  time="0"  wait="true"  ]
[bg  time="0"  method="crossfade"  storage="kuro.jpg"  ]
[mask_off  time="1500"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#
如此又过了数日[r]
珀耳塞福涅今日也在冥府宫殿中醒来[p]
门扉彼端传来克制的叩击声[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#侍女
「珀耳塞福涅大人 您醒了吗」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
侍奉冥府宫殿的众人都待珀耳塞福涅极为周到[p]
暂且放下对父神裁决的纠结心绪[r]
她本无意给这些侍女们添麻烦[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「嗯 请进」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
珀耳塞福涅应声让侍女们进入寝殿[r]
更衣完毕便离开了房间[p]
[_tb_end_text]

[bg  time="1000"  method="crossfade"  storage="bak/aides_hall.jpg"  ]
[tb_start_text mode=1 ]
#
前往之处正是宫殿的前厅[p]
虽宫中有专设的宴饮大厅 她却从未踏足[p]
珀耳塞福涅始终只饮用神酒与仙馔密酒——那些神明享用的珍馐[r]
本就不需饮食果腹[p]
[_tb_end_text]

[chara_show  name="ハデス"  time="500"  wait="false"  storage="chara/11/Hades_base.png"  width="720"  height="1350"  left="30"  top="-85"  reflect="false"  ]
[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[chara_show  name="ペルセポネ"  time="500"  wait="false"  storage="chara/10/Per_base.png"  width="720"  height="1350"  left="560"  top="-115"  reflect="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA2.png"  wait="false"  ]
[wait  time="500"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（啊……）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_magao_eyeA.png"  mouth="Per_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#
前厅右侧通道现出了冥王的身影[p]
每当珀耳塞福涅来到前厅 王总会现身[r]
明白他仍在挂念自己 珀耳塞福涅垂首行礼[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「休息得可好」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_bisho_eyeA.png"  mouth="Per_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「是」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「可要用膳？」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeA.png"  mouth="Per_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「不必了 抱歉 我实在没有食欲」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「是吗」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
与冥王的对话总是简短结束[p]
仅限必要事项的简短交流——但王从不会主动离去[r]
必会守在她身旁直到回房[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_magao_eyeB.png"  mouth="Per_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（该怎么办呢……）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
若因难为情躲回房间 转瞬就会被思绪的蛛网缠住[p]
为何自己身处此地 父神又为何只字未提[r]
循环诘问着无解难题 心情越发消沉[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeC.png"  mouth="Per_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（与其独处 宁可忍着尴尬留在外面）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_magao_eyeB.png"  mouth="Per_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#
这处入口对外敞开着。[r]
能感受到水流波动，草木呼吸的气息。[p]
令人窒息的沉默持续着让人紧张，但冥王并未强求什么。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
就像流水与草木，冥王也只是静默存在着。更重要的是——[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_magao_eyeA.png"  mouth="Per_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（好想感受流动的空气）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
在人间时，除了举行仪式外我从不把自己关在室内。[r]
每日巡游原野，采摘鲜花，帮母神处理政务。[r]
外出忙碌才是常态。[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_magao_eyeB.png"  mouth="Per_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（外面……）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
想起人间的空气，我忽然迫切想走出冥宫。[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_magao_eyeA.png"  mouth="Per_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「那个，哈迪斯叔叔」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
冥王瞬目回应珀耳塞福涅的呼唤。[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「我可以出去散步吗？[r]
因为…实在很怀念那些草木花朵」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
冥王凝视着珀耳塞福涅纹丝不动。[r]
表情毫无变化，谁也猜不透他在想什么。[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeA.png"  mouth="Per_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（难道…他担心我会逃跑？）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
即便逃跑，珀耳塞福涅也不懂返回人间的办法。[r]
明知会被抓回来的事，何必白费心机。[p]
但她始终无法顺畅表达这些想法。[r]
入口再度被沉默笼罩。泉水涌动声显得格外刺耳。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「好吧」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
经过如世纪般漫长的十几秒，冥王终于点头。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「去走走吧」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_hide  name="ハデス"  time="800"  wait="false"  pos_mode="false"  ]
[tb_start_text mode=1 ]
#
冥王挥动衣袍。[r]
身躯转向连接外界的通道而非王座之路。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（难道…叔叔要亲自带我去？）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
珀耳塞福涅意外地呆立原地。[p]
冥王似乎注意到她的停滞。[r]
缓缓转过身来。[p]
[_tb_end_text]

[chara_show  name="ハデス"  time="500"  wait="false"  storage="chara/11/Hades_base.png"  width="720"  height="1350"  left="30"  top="-85"  reflect="false"  ]
[chara_part  name="ハデス"  time="500"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="true"  ]
[wait  time="300"  ]
[tb_start_text mode=1 ]
#哈迪斯
「跟上来」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
说罢便迈步前行。[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「啊、是…！」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
珀耳塞福涅慌忙跟上。[p]
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[tb_show_message_window  ]
[chara_hide_all  time="0"  wait="true"  ]
[bg  time="0"  method="crossfade"  storage="kuro.jpg"  ]
[mask_off  time="1500"  effect="fadeOut"  ]
[bg  time="1000"  method="crossfade"  storage="bak/aides_entra.jpg"  ]
[tb_start_text mode=1 ]
#
跟随冥王穿过水晶洞穴时。[p]
[_tb_end_text]

[chara_show  name="ハデス"  time="500"  wait="false"  storage="chara/11/Hades_base.png"  width="720"  height="1350"  left="280"  top="-85"  reflect="false"  ]
[chara_show  name="ペルセポネ"  time="500"  wait="false"  storage="chara/10/Per_base.png"  width="720"  height="1350"  left="660"  top="-115"  reflect="false"  ]
[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_magao_eyeA.png"  mouth="Per_p_magao_mouthA2.png"  wait="false"  ]
[wait  time="600"  ]
[tb_start_text mode=1 ]
#哈迪斯
「散步该走这条道」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
洞内岔路纵横。[r]
走的似乎并非珀耳塞福涅初来时的路径。[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_magao_eyeA.png"  mouth="Per_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「明白了」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
冥王微微颔首，呼唤道：「刻耳柏洛斯」[p]
[_tb_end_text]

[chara_show  name="ケルベロス"  time="800"  wait="true"  storage="chara/16/Cerberus.png"  width="620"  height="1163"  left="-25"  top="130"  reflect="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#
应声现身的赫然是三头巨犬。[p]
冥界的看门犬刻耳柏洛斯——这名字珀耳塞福涅早有耳闻。[r]
它是对冥王绝对忠诚的守门者。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
虽然长着既像狼又像猛犬的骇人模样，[r]
刻耳柏洛斯却似乎很亲近这位王。[r]
当王抚摸其中一个头时，另外两个头也争先恐后地凑过来。[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_bisho_eyeA.png"  mouth="Per_p_bisho_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#
突然，她想起了被带到冥界的那天。[p]
那时候，拉车的马匹们也是这样被王抚摸着，不停地蹭着鼻子。[p]
看来刻耳柏洛斯和马儿们，都特别喜欢自己的主人呢。[r]
珀耳塞福涅噗嗤笑出了声。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
王似乎注意到了她的笑声，转过身来。[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（啊……太失礼了吧）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_magao_eyeA.png"  mouth="Per_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#
珀耳塞福涅缩了缩身子。[p]
王倒像是不介意她的笑声。[r]
只是平静地继续说着。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
以后你要外出时，记得带上刻耳柏洛斯[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「诶？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
它是聪明又强壮的看门犬。[r]
有它同行，你就能安心散步了。[r]
——对吧，刻耳柏洛斯？[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
三颗头同时蹭着王的手掌，像是在表态。[p]
[_tb_end_text]

[chara_hide_all  time="800"  wait="false"  ]
[tb_start_text mode=1 ]
#
虽说长相可怕，但这副模样怎么看都像是向主人撒娇的普通狗狗。[p]
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[bg  time="600"  method="crossfade"  storage="kuro.jpg"  ]
[stopbgm  time="1000"  fadeout="true"  ]
[mask_off  time="1500"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#
跟着王走到尽头时，珀耳塞福涅发现自己来到了森林。[p]
[_tb_end_text]

[bg  time="1000"  method="crossfade"  storage="bak/popula2.jpg"  ]
[playbgm  volume="15"  time="1000"  loop="true"  storage="bgm/hades_off.mp3"  ]
[chara_show  name="ハデス"  time="500"  wait="false"  storage="chara/11/Hades_base.png"  width="720"  height="1350"  left="30"  top="-85"  reflect="false"  ]
[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[chara_show  name="ペルセポネ"  time="500"  wait="false"  storage="chara/10/Per_base.png"  width="720"  height="1350"  left="560"  top="-115"  reflect="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA.png"  wait="false"  ]
[wait  time="500"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
这棵树是……[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_magao_eyeA.png"  mouth="Per_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#
黑杨树。[r]
笔直的树干冲天而起，茂密的枝叶在上方交错纠缠。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
不仅没有阳光透进来，还被漆黑的枝叶完全遮蔽。[r]
按理说这里应该更暗才对。[p]
但叶背的银白和树根处丛生的白花，却如同照亮黑暗般散发着光芒。[r]
或许正因如此，森林的漆黑反而显得格外鲜明。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
我们来时的路，就通往这座森林[p]
阿斯福德之野很广阔。不过对刻耳柏洛斯来说不会迷路[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
深渊还在更深处。[r]
应该不至于误入[p]
但幽冥界就延展在森林深处。说不定会不小心走进去。[r]
不要离开刻耳柏洛斯身边[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
人类死后，灵魂会通过冥界之门。[r]
接受审判后，将前往三个去处中的其中一个。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
大多数灵魂都被送往名为阿斯福德之野的地方。[r]
犯下重罪或违抗神明之人会坠入深渊。受英雄与诸神宠爱的灵魂则能前往乐园。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
这片森林似乎就位于阿斯福德之野。[r]
也就是说，周遭一定飘荡着许多人类的魂魄。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
而幽冥乃是远古众神栖居之地。[p]
他们比冥界之王，甚至比珀耳塞福涅的母亲得墨忒耳存在得更早。[r]
即便冥界处于哈迪斯大人的统治之下，这里也该是受尊重的区域。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
珀耳塞福涅对冥界并不熟悉。[r]
有刻耳柏洛斯待在身边似乎更让人安心。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（即便如此……）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
每一株树木都散发着强烈的生命力。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（没有阳光照耀，竟能在地底深处扎下如此扎实的根系）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_magao_eyeA.png"  mouth="Per_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#
珀耳塞福涅向前迈出一步，将手掌轻轻叠放在树干上。[r]
她仿佛听见了树木脉搏的微弱声响。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
或许因为触碰到了与丰饶女神力量相连的「植物」。[r]
珀耳塞福涅想起了母神得墨忒耳。[p]
那位温柔而坚韧的女神——母亲此刻正在做什么呢？[r]
她是否已经听闻女儿被强行掳掠至冥界的消息？[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_magao_eyeA.png"  mouth="Per_p_naki_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（好想——见母亲啊）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
但这句话终究没能说出口。[p]
虽对现状心有不甘，但哈迪斯王和侍女们并非「恶人」。[r]
他们只是遵循既定的规则履行各自的职责。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
正因为无处问责，忧郁才愈发深重。[p]
但能在这方天地思念母亲，还是让她感到些许慰藉。[r]
珀耳塞福涅依偎着黑杨树干，思念仍在地上的母神。[p]
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="true"  ]
[bg  time="0"  method="crossfade"  storage="kuro.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[bg  time="1000"  method="crossfade"  storage="bak/aides_gyokza.jpg"  ]
[chara_show  name="ハデス"  time="500"  wait="false"  storage="chara/11/Hades_base.png"  width="752"  height="1410"  left="280"  top="-90"  reflect="false"  ]
[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA2.png"  wait="false"  ]
[wait  time="300"  ]
[tb_start_text mode=1 ]
#哈迪斯
「……」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「——刻耳柏洛斯」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_show  name="ケルベロス"  time="500"  wait="true"  storage="chara/16/Cerberus.png"  width="620"  height="1163"  left="-10"  top="140"  reflect="false"  ]
[tb_start_text mode=1 ]
#
随着哈迪斯的呼唤，刻耳柏洛斯倏然现身。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
哈迪斯像往常那样依次抚摸它的三个头。[r]
连在女儿面前安静垂落的尾尖也不放过，用指腹轻触那形似蛇颚的部位。[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
今日的阿斯福德之野笼罩在青灰色之中。[p]
冥界向来是个缺乏色彩的地方。就连浓郁的青色都属罕见。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
宛如将悲哀与寂寥——珀耳塞福涅的内心[r]
具象化为色彩一般[p]
女儿仍深陷在巨大的悲伤中吧[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
（但森林对珀耳塞福涅产生了反应）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
当珀耳塞福涅触碰树干时，树木搏动的声音甚至传入了哈迪斯耳中。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
黑杨树之森是阿斯福德之野中尤为静谧的所在。[r]
每株树木都拥有安抚亡者灵魂的力量。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
在哈迪斯的记忆里，这些树木从未如今天这般明晰地作出回应。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
（是因为珀耳塞福涅乃得墨忒耳之女？）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
这或许也是原因之一。她天生就与植物相性极佳。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
（但是——不仅如此）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
森林认可了珀耳塞福涅作为冥界正统王妃的身份。[r]
树木的脉动便是最好的证明[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
（……）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
离开大地的女儿暂时还无法洗去悲伤[r]
但哈迪斯盼望着她能在冥界与自己共同生活下去[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「你们要好好对待珀耳塞福涅」[p]
「她可是重要的王妃」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
哈迪斯再次抚摸刻耳柏洛斯[p]
聪明的三头看门犬垂下头颅，三根尾巴整齐划一地向主人行礼[p]
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[stopbgm  time="2000"  fadeout="true"  ]
[bg  time="0"  method="crossfade"  storage="kuro.jpg"  ]
[chara_hide_all  time="0"  wait="true"  ]
[mask_off  time="1500"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#
此时的地面上，女神得墨忒尔正疯狂寻找失踪的女儿[p]
[_tb_end_text]

[playbgm  volume="12"  time="1000"  loop="true"  storage="bgm/sleep_inwoods.mp3"  fadein="false"  ]
[bg  time="1000"  method="crossfade"  storage="bak/herios1.jpg"  ]
[chara_show  name="デメテル"  time="500"  wait="false"  storage="chara/12/Dameter_base2.png"  width="840"  height="1575"  left="225"  top="-165"  reflect="false"  ]
[chara_part  name="デメテル"  time="0"  eye="Demeter_p_kusho_eyeB.png"  mouth="Demeter_p_magao_mouthA2.png"  ]
[wait  time="500"  ]
[tb_start_text mode=1 ]
#得墨忒耳
（啊，我可爱的科瑞…究竟去了哪里）[p]
（到今天已是整整九天…）[r]
（她是否正经历着恐惧？是否沉浸在悲伤里？）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#得墨忒耳
（附近森林里找不到任何踪迹）[r]
（精灵们也说科瑞是突然消失的）[p]
（众神与人类，乃至飞鸟，无人知晓科瑞去向）[r]
（这怎么可能？在我的神域里，我的女儿竟会凭空消失）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
得墨忒尔耳畔只闪过一瞬女儿的呼唤[r]
『救救我，母亲』[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_kusho_eyeA.png"  mouth="Demeter_p_magao_mouthA2.png"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
眼前潺潺溪流的水声仿佛还缠绕着那声呢喃[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
或许黎明将近，黑暗正逐渐淡去[r]
水面上轻盈跃动的光芒对女神的存在毫不在意[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_odoroki_eyeA.png"  mouth="Demeter_p_magao_mouthA2.png"  ]
[tb_start_text mode=1 ]
#得墨忒耳
（对了——光芒）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#得墨忒耳
（即便是我的神域，若是太阳也定能遍览万物）[r]
驾驭战车驰骋天际，守护众神与凡人的太阳神——若是赫利俄斯必然）[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_magao_eyeA.png"  mouth="Demeter_p_magao_mouthA.png"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「——洞悉万物的太阳神啊」[p]
「恳请您，回答得墨忒耳的提问」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[bg  time="2200"  method="fadeIn"  storage="bak/herios2.jpg"  ]
[tb_start_text mode=1 ]
#
仿佛响应得墨忒耳的呼唤，赫利俄斯的光芒在眼前铺展开来。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#得墨忒耳
「我想打听我那心爱的女儿的下落。[r]
我确实听到了女儿颤抖的哭声」[p]
「可是，我没能看清女儿为何发出尖叫[r]
不止是我。[r]
当时在场的所有人，没有谁知晓那孩子的去向」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#得墨忒耳
「赫利俄斯神，您以光辉普照天穹、海洋与大地[p]
「请告知真相——您可曾见过我的女儿」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#赫利俄斯
「容我禀报，丰收女神得墨忒耳」[p]
「目睹女神您不明缘由地痛苦，实在令人痛心疾首」[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_bisho_eyeA.png"  mouth="Demeter_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「感激不尽，赫利俄斯神」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#赫利俄斯
「您的令爱被唤云之神宙斯许配给了冥界的兄长」[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_odoroki_eyeA.png"  mouth="Demeter_p_odoroki_mouthA.png"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「诶……？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#赫利俄斯
「哈迪斯神遵照宙斯之言，已将令爱带往冥府」[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_odoroki_eyeB.png"  mouth="Demeter_p_gekido_mouthA.png"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「什…」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
瞬息间，得墨忒耳未能理解赫利俄斯的话语。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
但当听到宙斯与哈迪斯——那些赫利俄斯提及的兄弟之名，女神终于明白过来。[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_gekido_eyeA.png"  mouth="Demeter_p_gekido_mouthA.png"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「哈迪斯——我弟弟强行掳走了我的科瑞？[r]
还有宙斯！那个男人竟将我亲生的女儿…」[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_gekido_eyeB.png"  mouth="Demeter_p_gekido_mouthA.png"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「不可原谅…！」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#赫利俄斯
「女神啊，请平息怒火」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#赫利俄斯
「哈迪斯神作为冥界之王尽忠职守。[r]
作为夫婿，可谓不二人选」[p]
「且冷静下来，好吗」[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_gekido_eyeA.png"  mouth="Demeter_p_gekido_mouthA.png"  ]
[tb_start_text mode=1 ]
#
说罢，赫利俄斯再度策马启程。[p]
[_tb_end_text]

[bg  time="2000"  method="fadeIn"  storage="bak/herios3.jpg"  ]
[tb_start_text mode=1 ]
#
太阳神离去后的小溪，若无其事地继续流淌。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
但得墨忒耳的怒意丝毫未减。[r]
尤其对宙斯的愤怒、焦躁与嫌恶更是达到顶点。[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_gekido_eyeA.png"  mouth="Demeter_p_magao_mouthA2.png"  ]
[tb_start_text mode=1 ]
#得墨忒耳
（将科瑞，许配给哈迪斯——此话当真？）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
得墨忒耳回想着宙斯突然现身那天的情形。[p]
那天我只是满腹狐疑，不知他为何而来。[r]
现在回想起来，他必定是为确认科瑞的情况才降临凡间。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
谁曾想，宙斯竟连和得墨忒耳商量都没有，就把女儿当成物品处置。[p]
确实，科瑞是和得墨忒耳一起在人间生活。[r]
对宙斯来说，或许比其他住在奥林匹斯的女儿少些牵挂。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
但即便如此，也不该擅自决定科瑞的人生。[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_magao_eyeA.png"  mouth="Demeter_p_magao_mouthA2.png"  ]
[tb_start_text mode=1 ]
#得墨忒耳
（——不，不对）[p]
（这本就不是第一次。宙斯"从来"如此）[p]
（那个男人，总以为事事都能如他所愿）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
那大约是二十年前的事了——[p]
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="true"  ]
[tb_filter_grayscale  layer="base"  grayscale="50"  ]
[tb_filter_grayscale  layer="0"  grayscale="40"  ]
[bg  time="0"  method="fadeIn"  storage="bak/hanabatake.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[chara_show  name="ゼウス"  time="500"  wait="false"  storage="chara/14/Zeus_base.png"  width="700"  height="1313"  left="570"  top="-65"  reflect="false"  ]
[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_bisho_eyeA.png"  mouth="Zeus_p_bisho_mouthA.png"  wait="false"  ]
[chara_show  name="デメテル"  time="500"  wait="false"  storage="chara/12/Demeter_base1.png"  width="700"  height="1313"  left="40"  top="-105"  reflect="false"  ]
[chara_part  name="デメテル"  time="0"  eye="Demeter_p_magao_eyeA.png"  mouth="Demeter_p_magao_mouthA.png"  wait="false"  ]
[wait  time="500"  ]
[tb_start_text mode=1 ]
#宙斯
『姐姐对婚姻不感兴趣吗？』[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#得墨忒耳
『突然造访就为这个……什么意思？』[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#宙斯
『多亏姐姐保佑谷物丰收，人间才如此繁荣。[r]
我是来表示感谢的』[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#宙斯
『但姐姐总不能永远独身吧？[r]
该找个能分担工作的伴侣了』[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#得墨忒耳
『所以？』[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#宙斯
『来看看有没有配得上姐姐的好男人』[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#得墨忒耳
『少装蒜。根本不是这回事』[p]
[_tb_end_text]

[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_kusho_eyeA.png"  mouth="Zeus_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#宙斯
『真敏锐啊』[p]
[_tb_end_text]

[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_bisho_eyeA.png"  mouth="Zeus_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#宙斯
『我是来邀请姐姐的。凡夫俗子根本配不上你』[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#宙斯
『而且我觉得，比起男人，姐姐应该更喜欢孩子』[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_odoroki_eyeA.png"  mouth="Demeter_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#得墨忒耳
『荒唐……明明已经有那么可爱的正妻了』[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_magao_eyeA.png"  mouth="Demeter_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#得墨忒耳
『你啊，还是这么无可救药』[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#宙斯
『呵呵』[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#宙斯
『姐姐这种爱讲大道理又倔强的性子，最对我胃口了』[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#宙斯
『呐，我知道的。波塞冬也在追求姐姐。[r]
他还没放弃呢』[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#宙斯
『姐姐对正妻之位没兴趣吧？[r]
那正好。凭姐姐这样的女神，当侧妃也不会有人非议』[p]
『被母神认可继承大地的姐姐，需要的只是"继承衣钵"的孩子』[p]
『选吧。——要和我还是波塞冬生孩子？』[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="true"  ]
[bg  time="0"  method="fadeIn"  storage="bak/herios3.jpg"  ]
[tb_free_filter  layer="base"  ]
[tb_free_filter  layer="0"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[chara_show  name="デメテル"  time="500"  wait="false"  storage="chara/12/Dameter_base2.png"  width="840"  height="1575"  left="225"  top="-165"  reflect="false"  ]
[chara_part  name="デメテル"  time="0"  eye="Demeter_p_magao_eyeA.png"  mouth="Demeter_p_magao_mouthA2.png"  ]
[wait  time="500"  ]
[tb_start_text mode=1 ]
#得墨忒耳
（诞生的女儿确实可爱。这点毋庸置疑）[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_gekido_eyeB.png"  mouth="Demeter_p_magao_mouthA2.png"  ]
[tb_start_text mode=1 ]
#得墨忒耳
（但我生下并养育科瑞，不是为了被宙斯利用）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#得墨忒耳
（我绝不原谅你，宙斯。给我记住）[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_gekido_eyeA.png"  mouth="Demeter_p_gekido_mouthA.png"  ]
[tb_start_text mode=1 ]
#得墨忒耳
获得母神认可统治人间——掌管谷物耕作的，可是我[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[jump  storage="main4.ks"  target="*start"  ]
[s  ]
[tb_start_text mode=1 ]
[ruby text="ようや"][p]
母神[p]
[_tb_end_text]

