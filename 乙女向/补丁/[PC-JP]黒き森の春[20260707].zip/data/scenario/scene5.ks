﻿[_tb_system_call storage=system/_scene5.ks]

[playbgm  volume="15"  time="1000"  loop="true"  storage="bgm/hades_off.mp3"  ]
*scene5_start

[cm  ]
[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[tb_show_message_window  ]
[chara_hide_all  time="0"  wait="true"  ]
[bg  time="0"  method="crossfade"  storage="kuro.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[bg  time="1000"  method="crossfade"  storage="bak/popula2.jpg"  ]
[tb_start_text mode=1 ]
#
之后我也频繁造访黑杨树之森。[p]
经常因思念母亲而落泪。[r]
但凡能尝试的事我都想试一试。[r]
我开始带着刻耳柏洛斯向森林周边探索。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
森林边缘流淌着从催人遗忘之河分流出的溪涧。[p]
溪水呈现出如乳汁般的洁白。[r]
生长在周围的花朵显得格外耀眼。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
溪畔偶尔能看见疑似人类灵魂的身影。[p]
有刻耳柏洛斯时刻守在身旁，亡魂们不敢靠近我。[r]
但和小狗并肩凝望溪流时，渐渐产生了也想给亡魂们送礼物的念头。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（愿亡灵们能在阿斯福德之野安详度日）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
我特意编了不同于刻耳柏洛斯项圈的花环。[p]
我想，对花朵之美的感受，人类亡魂和我并无不同。[r]
将花环轻轻挂上黑杨树枝桠。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
渐渐地，亡灵们开始聚集在花环之下。[p]
因亡魂从不靠近我，刻耳柏洛斯也不再威慑它们。[r]
刻耳柏洛斯会等我编完花，再随我的步伐跟进。[p]
[_tb_end_text]

[bg  time="600"  method="crossfade"  storage="kuro.jpg"  ]
[bg  time="1000"  method="crossfade"  storage="bak/aides_carve.jpg"  ]
[tb_start_text mode=1 ]
#
有些灵魂如薄雾般在洞穴中飘荡。[p]
哈迪斯叔父说过，有些亡魂连花儿的白色微光都觉得刺眼。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
珀耳塞福涅为它们准备了黑杨树叶编织的饰品。[p]
叶背泛着朦胧的银辉。[r]
我根据亡魂们对黑暗的偏好调整编织方式。[p]
或是挂在凸岩上，或是置于凹穴之中。[r]
单调的岩洞因叶饰而有了明暗层次。[p]
[_tb_end_text]

[bg  time="600"  method="crossfade"  storage="kuro.jpg"  ]
[bg  time="1000"  method="crossfade"  storage="bak/aides_hall.jpg"  ]
[chara_show  name="ハデス"  time="500"  wait="false"  storage="chara/11/Hades_base.png"  width="752"  height="1410"  left="280"  top="-90"  reflect="false"  ]
[chara_part  name="ハデス"  time="500"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="true"  ]
[wait  time="500"  ]
[tb_start_text mode=1 ]
#
哈迪斯叔父大人始终温柔如初。[r]
每当我离开房间，他必定会陪我到玄关。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
从森林归来时，也总能见到他的身影。[r]
他倾听我诉说许多许多事。[p]
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="false"  ]
[bg  time="0"  method="crossfade"  storage="kuro.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#
就这样，一年时光流逝。[p]
虽未彻底释怀，但对冥界已相当适应。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
就在此时，来自地面的不速之客突然造访。[p]

[_tb_end_text]

[bg  time="1000"  method="crossfade"  storage="bak/aides_gyokza.jpg"  ]
[chara_show  name="ハデス"  time="500"  wait="false"  storage="chara/11/Hades_base.png"  width="720"  height="1350"  left="40"  top="-85"  reflect="false"  ]
[chara_part  name="ハデス"  time="500"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[chara_show  name="ヘルメス"  time="500"  wait="false"  storage="chara/13/Hermes_base.png"  width="700"  height="1313"  left="600"  top="-88"  reflect="false"  ]
[chara_part  name="ヘルメス"  time="500"  eye="Her_p_bisho_eyeA.png"  mouth="Her_p_bisho_mouthA.png"  ]
[wait  time="500"  ]
[tb_start_text mode=1 ]
#
从玄关走向玉座之厅时，看见哈迪斯叔父正与赫尔墨斯交谈。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
赫尔墨斯——引渡亡魂之神。[r]
对我而言算是异母兄长。在人间也曾见过几次。[p]

[_tb_end_text]

[tb_start_text mode=1 ]
#赫尔墨斯
「好久不见，珀耳塞福涅」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「好久不见，赫尔墨斯。来出差的吗？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#赫尔墨斯
「是啊。奉我们父神宙斯大人的命令而来」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「父亲大人他……？」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_kusho_eyeA.png"  mouth="Her_p_kusho_mouthA.png"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「珀耳塞福涅，你降临冥界之事让得墨忒耳大人震怒」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_magao_eyeA.png"  mouth="Her_p_magao_mouthA.png"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「她抛下农耕神职闭门不出。[r]
不仅拒绝响应宙斯大人的召唤，也不与其他诸神往来」[p]
「谷物枯萎，人类面临饥荒。[r]
结果导致凡人供品减少，宙斯大人正焦头烂额」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「母亲大人竟然…」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
果然父亲大人并没有向母亲大人提起我的婚事。[p]
母亲大人会生气也是理所当然。[r]
连平日工作得兴高采烈的母亲大人都无法履行职责，必定是非同寻常的事。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#赫尔墨斯
「因此宙斯大人决定将你送回得墨忒耳大人身边。[r]
为平息丰收女神的怒火」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#赫尔墨斯
「——哈迪斯大人，事情就是这样……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「宙斯的决定我已明了」[p]

[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「哈迪斯叔父大人……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「珀耳塞福涅也曾思念母亲。妳该回到母亲身边」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「赫尔墨斯，能请你先行去备马吗」[p]
「希望让王妃与我独处片刻」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_bisho_eyeA.png"  mouth="Her_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「遵命」[p]
「在下会于水晶洞穴外恭候」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_hide_all  time="800"  wait="true"  ]
[tb_start_text mode=1 ]
#
待赫尔墨斯的脚步声完全消失后，叔父大人开口了。[p]
[_tb_end_text]

[chara_show  name="ハデス"  time="500"  wait="false"  storage="chara/11/Hades_base.png"  width="752"  height="1410"  left="280"  top="-90"  reflect="false"  ]
[chara_part  name="ハデス"  time="500"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="true"  ]
[wait  time="500"  ]
[tb_start_text mode=1 ]
#哈迪斯
「珀耳塞福涅」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「是」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「本王自认足以配得上成为妳的丈夫」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「那里该说"我配得上成为叔父大人的妻子"才对吧」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_kusho_eyeA.png"  mouth="Hades_p_kusho_mouthA.png"  ]
[tb_start_text mode=1 ]
#哈迪斯
「不。是本王配得上做妳的丈夫」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
叔父大人脸上似乎闪过一丝苦笑。[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「所以——这些终于成熟了些。愿意尝尝吗？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_hide  name="ハデス"  time="800"  wait="true"  pos_mode="false"  ]
[tb_image_show  time="800"  storage="default/zakuro_.png"  width="300"  height="300"  x="490"  y="156"  _clickable_img=""  name="img_74"  ]
[tb_start_text mode=1 ]
#
哈迪斯大人向前伸出手。掌心托着一颗石榴。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「这是……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「妳曾说过喜欢谷物和水果吧」[p]
「适合冥界土壤的作物不多——但我觉得这颗长得不错」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
叔父大人竟记得我说过的话。[r]
正如他说「要好好准备」那般，竟为我在冥界栽种了果树。[p]
果实泛着光泽，宛如宝石。与地上的果实质地截然不同。[p]
[_tb_end_text]

[tb_image_hide  time="1000"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「感谢您。——那我开动了」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_show  name="ハデス"  time="500"  wait="false"  storage="chara/11/Hades_base.png"  width="752"  height="1410"  left="280"  top="-90"  reflect="false"  ]
[chara_part  name="ハデス"  time="500"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="true"  ]
[wait  time="500"  ]
[tb_start_text mode=1 ]
#哈迪斯
「过来」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
哈迪斯大人取出一粒果肉。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
我向哈迪斯叔父大人走近，微微张口。[p]
叔父大人将石榴果实滑入我口中。[r]
待叔父大人的手指离开，我才开始咀嚼。[p]
石榴异常香甜，与受母亲神力滋养的果实同样多汁。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「——很好吃！」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeA.png"  mouth="Hades_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#哈迪斯
「那就好」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「能亲手为你奉上这颗石榴，全因你来到冥界」[p]
「——请将这份思念，永远珍藏在心」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（叔父大人……）[p]
（哈迪斯大人确实真心在意着我啊）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「谢谢您如此珍视我」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[jump  storage="scene6.ks"  target="*scene6_start"  ]
[s  ]
[tb_start_text mode=1 ]
[ruby text="ようや"][p]
[_tb_end_text]

