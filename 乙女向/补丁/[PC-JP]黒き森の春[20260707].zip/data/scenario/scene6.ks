﻿[_tb_system_call storage=system/_scene6.ks]

[playbgm  volume="15"  time="1000"  loop="true"  storage="bgm/hades_off.mp3"  ]
*scene6_start

[cm  ]
[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[tb_show_message_window  ]
[chara_hide_all  time="0"  wait="true"  ]
[bg  time="0"  method="crossfade"  storage="bak/aides_entra.jpg"  ]
[chara_show  name="ヘルメス"  time="0"  wait="false"  storage="chara/13/Hermes_base.png"  width="700"  height="1313"  left="600"  top="-88"  reflect="false"  ]
[chara_part  name="ヘルメス"  time="0"  eye="Her_p_bisho_eyeA.png"  mouth="Her_p_bisho_mouthA.png"  ]
[chara_show  name="ハデス"  time="0"  wait="false"  storage="chara/11/Hades_base.png"  width="720"  height="1350"  left="40"  top="-85"  reflect="false"  ]
[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[mask_off  time="1500"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「马车已备好。上车吧」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「嗯，谢谢」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#赫尔墨斯
「冥王。容我们借用马匹与马车」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「是啊」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
哈迪斯大人轻抚挽车的马匹。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「珀耳塞福涅就拜托了」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
马儿们轻声嘶鸣回应。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#赫尔墨斯
「那么，出发了」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
赫尔墨斯握紧缰绳挥动马鞭。[p]
[_tb_end_text]

[playse  volume="15"  time="1000"  buf="0"  storage="buki_muchi2.mp3"  ]
[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="true"  ]
[bg  time="0"  method="crossfade"  storage="kuro.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[stopse  time="0"  buf="0"  ]
[tb_start_text mode=1 ]
#
随着马匹扬蹄，马车开始移动。[r]
仿佛要刺破黑暗般，骨碌碌地腾空而起。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
抵达地上后，沿着海边穿过无数山峦峡谷。[p]
[_tb_end_text]

[bg  time="1000"  method="crossfade"  storage="bak/ereusis.jpg"  ]
[tb_start_text mode=1 ]
#
最终马车停在了丘陵上的神庙前。[p]
[_tb_end_text]

[chara_show  name="ヘルメス"  time="500"  wait="false"  storage="chara/13/Hermes_base.png"  width="700"  height="1313"  left="600"  top="-88"  reflect="false"  ]
[chara_part  name="ヘルメス"  time="0"  eye="Her_p_bisho_eyeA.png"  mouth="Her_p_bisho_mouthA.png"  ]
[wait  time="500"  ]
[stopbgm  time="3000"  fadeout="true"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
我们到了[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#赫尔墨斯
这里就是得墨忒耳大人如今暂居之处[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[playbgm  volume="13"  time="1000"  loop="true"  storage="bgm/sleep_inwoods.mp3"  fadein="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「这片土地……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
我环顾四周。[r]
似乎与我和母亲大人曾经的居所相距甚远。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（母亲为了寻找我，竟然来到这样的地方……）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#？？？
科瑞……！[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
熟悉的声音如雨滴般洒落。[p]
[_tb_end_text]

[chara_show  name="デメテル"  time="500"  wait="false"  storage="chara/12/Dameter_base2.png"  width="700"  height="1313"  left="35"  top="-115"  reflect="false"  ]
[chara_part  name="デメテル"  time="0"  eye="Demeter_p_odoroki_eyeA.png"  mouth="Demeter_p_odoroki_mouthA.png"  ]
[tb_start_text mode=1 ]
#
裹着黑衣的母亲大人双眸牢牢锁定我。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
母亲大人……！[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
我跳下马车奔向母亲大人。[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_bisho_eyeA.png"  mouth="Demeter_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「母亲大人，母亲大人……！」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#得墨忒耳
「啊，科瑞！我亲爱的女儿……！」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
母亲大人紧抱住我，温柔梳理我的长发。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#得墨忒耳
「没想到那个宙斯竟然会同意把你送回来」[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="200"  eye="Demeter_p_gekido_eyeA.png"  mouth="Demeter_p_magao_mouthA.png"  ]
[tb_start_text mode=1 ]
#
她锐利的目光射向站在马车旁的赫尔墨斯。[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_kusho_eyeA.png"  mouth="Her_p_kusho_mouthA.png"  ]
[tb_start_text mode=1 ]
#
赫尔墨斯苦笑着耸了耸肩。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「母亲大人」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
我紧抱住母亲大人连连摇头。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「赫尔墨斯只是奉父神之命，把我送回地上来。[r]
他没有任何错」[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_bisho_eyeA.png"  mouth="Demeter_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「科瑞真是温柔啊。[r]
虽然我明白，但赫尔墨斯对宙斯太忠心了」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#得墨忒耳
「话说回来，科瑞。你在冥界没吃过东西吧？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「诶？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#得墨忒耳
「在冥界进食就意味着归属冥界。[r]
地下应该没有你喜欢的东西，我想应该没问题…」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「啊……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
听到母亲大人的话语，我顿时僵住了。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（吃下去了。我把哈迪斯叔叔给的石榴果实——吃下去了）[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_odoroki_eyeA.png"  mouth="Demeter_p_odoroki_mouthA.png"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「难道说，你吃了？」[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="200"  eye="Demeter_p_gekido_eyeA.png"  mouth="Demeter_p_magao_mouthA.png"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「哈迪斯……太卑鄙了。[r]
和宙斯串通，算计一无所知的你」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（算计……？哈迪斯叔叔他、对我？）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
我回忆起了与叔叔的对话。[p]
[_tb_end_text]

[mask  time="600"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="true"  ]
[bg  time="0"  method="crossfade"  storage="bak/aides_hall.jpg"  ]
[tb_filter_grayscale  layer="base"  grayscale="60"  ]
[tb_filter_grayscale  layer="0"  grayscale="60"  ]
[chara_show  name="ハデス"  time="0"  wait="false"  storage="chara/11/Hades_base.png"  width="752"  height="1410"  left="280"  top="-90"  reflect="false"  ]
[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[mask_off  time="800"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#哈迪斯
『要吃点——什么吗？』[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
『来到冥界后，你什么都没吃吧』[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
『喜欢什么』[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
面对叔叔平淡的询问，我回答「喜欢谷物和水果」。[p]
[_tb_end_text]

[chara_hide  name="ハデス"  time="600"  wait="false"  pos_mode="false"  ]
[tb_start_text mode=1 ]
#
后来听说哈迪斯大人为此在冥界开始了水果种植。[p]
[_tb_end_text]

[bg  time="600"  method="crossfade"  storage="kuro.jpg"  ]
[bg  time="1000"  method="crossfade"  storage="bak/aides_gyokza.jpg"  ]
[chara_show  name="ハデス"  time="500"  wait="false"  storage="chara/11/Hades_base.png"  width="752"  height="1410"  left="280"  top="-90"  reflect="false"  ]
[chara_part  name="ハデス"  time="500"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="true"  ]
[wait  time="500"  ]
[tb_start_text mode=1 ]
#哈迪斯
『你说过喜欢谷物和水果吧』[p]
『虽然冥界的土壤适合的种类不多——但这个应该种得不错』[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[mask  time="600"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="true"  ]
[bg  time="0"  method="crossfade"  storage="bak/ereusis.jpg"  ]
[tb_free_filter  layer="base"  ]
[tb_free_filter  layer="0"  ]
[chara_show  name="デメテル"  time="500"  wait="false"  storage="chara/12/Dameter_base2.png"  width="700"  height="1313"  left="35"  top="-115"  reflect="false"  ]
[chara_part  name="デメテル"  time="0"  eye="Demeter_p_magao_eyeA.png"  mouth="Demeter_p_magao_mouthA.png"  ]
[mask_off  time="800"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「不对——不是的，母亲大人」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
我摇了摇头。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「哈迪斯大人根本没有算计我」[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_odoroki_eyeA.png"  mouth="Demeter_p_odoroki_mouthA.png"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「科瑞」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「听我说，母亲大人。我在冥界吃了石榴果实。是哈迪斯大人给的」[p]
「虽然确实多次劝我进食——但回答的人是我。[r]
是我告诉他喜欢谷物和水果」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「所以叔叔才专门为我栽种了石榴」[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_magao_eyeA.png"  mouth="Demeter_p_magao_mouthA.png"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「可是，哈迪斯大人根本没向你说明冥界的规矩对吧？[r]
他是不是硬把石榴果实塞进了你这张懵懂无知的嘴里？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「不是的，母亲大人，您误会了」[p]
（因为，哈迪斯叔叔他——）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[mask  time="600"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="true"  ]
[bg  time="0"  method="crossfade"  storage="bak/aides_hall.jpg"  ]
[tb_filter_grayscale  layer="base"  grayscale="60"  ]
[tb_filter_grayscale  layer="0"  grayscale="60"  ]
[chara_show  name="ハデス"  time="0"  wait="false"  storage="chara/11/Hades_base.png"  width="752"  height="1410"  left="280"  top="-90"  reflect="false"  ]
[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[mask_off  time="800"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#哈迪斯
『看来你是真的没在听啊……』[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[mask  time="600"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="true"  ]
[bg  time="0"  method="crossfade"  storage="bak/ereusis.jpg"  ]
[tb_free_filter  layer="base"  ]
[tb_free_filter  layer="0"  ]
[chara_show  name="デメテル"  time="500"  wait="false"  storage="chara/12/Dameter_base2.png"  width="700"  height="1313"  left="35"  top="-115"  reflect="false"  ]
[chara_part  name="デメテル"  time="0"  eye="Demeter_p_magao_eyeA.png"  mouth="Demeter_p_magao_mouthA.png"  ]
[mask_off  time="800"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「叔叔对我不知道婚约的事显得很吃惊。[r]
他根本没想到我会不知道冥界的规矩吧」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#得墨忒耳
「科瑞。我知道你是个心肠柔软的孩子。[r]
但你是不是太过天真了？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#得墨忒耳
「宙斯可不是会推翻自己决定的男人。[r]
哈迪斯也一样」[p]
「何况要迎娶新娘，就该展现出十足的诚意才是正理」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
母亲说的话合情合理。[r]
可即便这样，我也无法忍受最爱的母亲贬低哈迪斯大人。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「诚意的话，我是真切感受到的」[p]
「哈迪斯叔叔最优先考虑的是让我适应冥界生活」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「当然，突然被拽上马车时确实吓坏了。[r]
但叔叔他——」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
我回想起离开冥界前哈迪斯大人说的话。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[mask  time="600"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="true"  ]
[bg  time="0"  method="crossfade"  storage="bak/aides_gyokza.jpg"  ]
[tb_filter_grayscale  layer="base"  grayscale="60"  ]
[tb_filter_grayscale  layer="0"  grayscale="60"  ]
[chara_show  name="ハデス"  time="0"  wait="false"  storage="chara/11/Hades_base.png"  width="752"  height="1410"  left="280"  top="-90"  reflect="false"  ]
[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeA.png"  mouth="Hades_p_bisho_mouthA.png"  wait="false"  ]
[mask_off  time="800"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#哈迪斯
『请你将这份心意，珍藏在心中』[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[mask  time="600"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="true"  ]
[bg  time="0"  method="crossfade"  storage="bak/ereusis.jpg"  ]
[tb_free_filter  layer="base"  ]
[tb_free_filter  layer="0"  ]
[chara_show  name="デメテル"  time="500"  wait="false"  storage="chara/12/Dameter_base2.png"  width="700"  height="1313"  left="35"  top="-115"  reflect="false"  ]
[chara_part  name="デメテル"  time="0"  eye="Demeter_p_magao_eyeA.png"  mouth="Demeter_p_magao_mouthA.png"  ]
[mask_off  time="800"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「他是真心...珍视着我的……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#得墨忒耳
「科瑞......」[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_bisho_eyeA.png"  mouth="Demeter_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「好吧。既然你拼命维护到这种程度，[r]
想必哈迪斯确实是如你所言吧」[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="200"  eye="Demeter_p_gekido_eyeA.png"  mouth="Demeter_p_magao_mouthA.png"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「但宙斯那边，我可不会轻易饶恕」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
母亲再次向赫尔墨斯投去严厉的目光。[p]
[_tb_end_text]

[chara_show  name="ヘルメス"  time="500"  wait="false"  storage="chara/13/Hermes_base.png"  width="700"  height="1313"  left="600"  top="-88"  reflect="false"  ]
[chara_part  name="ヘルメス"  time="0"  eye="Her_p_kusho_eyeA.png"  mouth="Her_p_kusho_mouthA.png"  ]
[chara_part  name="デメテル"  time="0"  eye="Demeter_p_magao_eyeA.png"  mouth="Demeter_p_magao_mouthA.png"  ]
[wait  time="300"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「去吧，赫尔墨斯。告诉宙斯——[r]
科瑞误食冥界食物这事，他打算如何交代，[r]
我要看他给出怎样的裁决」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_bisho_eyeA.png"  mouth="Her_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「遵命」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
赫尔墨斯露出为难的笑容，仍向母亲行了礼。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
随即登上马车握紧缰绳。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#赫尔墨斯
「马儿们，先随我上天界一趟可好？之后再把你们送回冥府」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
马匹轻声嘶鸣回应着赫尔墨斯。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
那群深受哈迪斯大人宠爱的——护送我回到母亲身边的冥府马。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「等一下」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
我跑到马群跟前。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「谢谢你载我来」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
马儿们呼呼地凑近我的脸。[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_odoroki_eyeA.png"  mouth="Her_p_odoroki_mouthA.png"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「哎呀，真稀奇」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_odoroki_eyeA.png"  mouth="Her_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「从没见过马儿们对哈迪斯大人以外的人撒娇」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「呵呵」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_bisho_eyeA.png"  mouth="Her_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#
我学着叔叔的样子抚摸马匹的鬃毛根部。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（请转告哈迪斯大人）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
确保母亲和赫尔墨斯听不见，我用眼神向马群传递心意。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（就说我从未后悔吃下石榴果实）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
在冥界进食意味着归属于冥界。[r]
这条规矩的深意，我不是不明白。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
但哈迪斯大人希望我在冥界用餐的心情[r]
此刻似乎能够理解了。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
马群再次嘶鸣，仿佛听懂了我心中所想。[p]
[_tb_end_text]

[jump  storage="scene7.ks"  target="*scene7_start"  ]
[s  ]
[tb_start_text mode=1 ]
[ruby text="ようや"][p]
[_tb_end_text]

