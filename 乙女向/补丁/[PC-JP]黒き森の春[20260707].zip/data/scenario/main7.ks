﻿[_tb_system_call storage=system/_main7.ks]

*start

[cm  ]
[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[stopbgm  time="2000"  fadeout="true"  ]
[tb_show_message_window  ]
[tb_start_tyrano_code]
[position layer="message0" left="40" top="30" width="1200" height="660" margint="50" marginl="100" marginr="110" marginb="50"frame="none" opacity="220"]
[button name="role_button" role="save" graphic="../others/plugin/theme_kopanda_bth_08/image/button/save3.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/save2.png" x="1216" y="531" width="45" height="20"]
[button name="role_button" role="load" graphic="../others/plugin/theme_kopanda_bth_08/image/button/load3.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/load2.png"  x="1214" y="557" width="49" height="20"]
[button name="role_button" role="auto" graphic="../others/plugin/theme_kopanda_bth_08/image/button/auto3.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/auto2.png" x="1215" y="583" width="46" height="19"]
[button name="role_button" role="skip" graphic="../others/plugin/theme_kopanda_bth_08/image/button/skip3.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/skip2.png" x="1217" y="609" width="47" height="26"]
[button name="role_button" role="backlog" graphic="../others/plugin/theme_kopanda_bth_08/image/button/log3.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/log2.png" x="1220" y="634" width="39" height="27"]
[button name="role_button" role="sleepgame" graphic="../others/plugin/theme_kopanda_bth_08/image/button/sleep3.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/sleep2.png" storage="../others/plugin/theme_kopanda_bth_08/config.ks" x="1213" y="661" width="57" height="26"]
[button name="role_button" role="title" graphic="../others/plugin/theme_kopanda_bth_08/image/button/title3.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/title2.png" x="1215" y="691" width="48" height="21"]
[button name="role_button" role="window" graphic="../others/plugin/theme_kopanda_bth_08/image/button/close.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/close3.png" x="1262" y="520" width="13" height="13"]
[_tb_end_tyrano_code]

[chara_hide_all  time="0"  wait="true"  ]
[bg  time="0"  method="crossfade"  storage="kuro.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[bg  time="1000"  method="crossfade"  storage="bak/ereusis.jpg"  ]
[tb_start_text mode=1 ]
#
父神宙斯的裁决很快下达。[l][r]
[r]
在冥界食用石榴的珀耳塞福涅需遵从古老契约。[l][r]
[r]
大地的季节分为三巡。[r]
其中一季她必须留在冥界。[l][r]
[r]
但剩余两季可与母亲得墨忒耳共度人间。[p]
[_tb_end_text]

[playbgm  volume="15"  time="1000"  loop="true"  storage="bgm/hades_off.mp3"  ]
[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[tb_start_tyrano_code]
[position layer="message0" width="1280" height="220" top="505" left="0"]
[position layer="message0" frame="../others/plugin/theme_kopanda_bth_08/image/frame_message.png" margint="60" marginl="120" marginr="140" marginb="50" opacity="220" page="fore"]
[_tb_end_tyrano_code]

[tb_start_tyrano_code]
[button name="role_button" role="save" graphic="../others/plugin/theme_kopanda_bth_08/image/button/save.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/save2.png" x="1216" y="531" width="45" height="20"]
[button name="role_button" role="load" graphic="../others/plugin/theme_kopanda_bth_08/image/button/load.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/load2.png"  x="1214" y="557" width="49" height="20"]
[button name="role_button" role="auto" graphic="../others/plugin/theme_kopanda_bth_08/image/button/auto.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/auto2.png" x="1215" y="583" width="46" height="19"]
[button name="role_button" role="skip" graphic="../others/plugin/theme_kopanda_bth_08/image/button/skip.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/skip2.png" x="1217" y="609" width="47" height="26"]
[button name="role_button" role="backlog" graphic="../others/plugin/theme_kopanda_bth_08/image/button/log.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/log2.png" x="1220" y="634" width="39" height="27"]
[button name="role_button" role="sleepgame" graphic="../others/plugin/theme_kopanda_bth_08/image/button/sleep.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/sleep2.png" storage="../others/plugin/theme_kopanda_bth_08/config.ks" x="1213" y="661" width="57" height="26"]
[button name="role_button" role="title" graphic="../others/plugin/theme_kopanda_bth_08/image/button/title.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/title2.png" x="1215" y="691" width="48" height="21"]
[button name="role_button" role="window" graphic="../others/plugin/theme_kopanda_bth_08/image/button/close.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/close.png" x="1262" y="520" width="13" height="13"]
[_tb_end_tyrano_code]

[chara_show  name="デメテル"  time="0"  wait="false"  storage="chara/12/Dameter_base2.png"  width="720"  height="1350"  left="110"  top="-120"  reflect="false"  ]
[chara_part  name="デメテル"  time="0"  eye="Demeter_p_magao_eyeA.png"  mouth="Demeter_p_magao_mouthA.png"  ]
[chara_show  name="ペルセポネ"  time="0"  wait="false"  storage="chara/10/kore_base.png"  width="700"  height="1313"  left="550"  top="-105"  reflect="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_bisho_eyeA.png"  mouth="Per_p_bisho_mouthA.png"  wait="false"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「也罢」[p]

[_tb_end_text]

[tb_start_text mode=1 ]
#得墨忒耳
「只要科瑞确定能返回地面，我认了」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeC.png"  mouth="Per_p_egao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「谢谢母亲！」[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_odoroki_eyeA.png"  mouth="Demeter_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「哎呀，为何要你来道谢？」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「诶」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#得墨忒耳
「活像你盼着去冥界似的」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeB.png"  mouth="Per_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「那个......」[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_bisho_eyeA.png"  mouth="Demeter_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「没关系的，我亲爱的科瑞」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_magao_eyeA.png"  mouth="Per_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「虽然心里还有火气[r]
但既然哈迪斯承诺会珍视你...也不是不能考虑」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#得墨忒耳
「我只愿你的丈夫能专情于你」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#得墨忒耳
「科瑞是倾心于哈迪斯了？」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeA.png"  mouth="Per_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#
说倾心于冥王——未免僭越。[p]
但当季节轮转至冥界时，她便能陪伴在那位君主身侧。[r]
与刻耳柏洛斯和天马们亦可重逢。[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeC.png"  mouth="Per_p_egao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「嗯。我想...是吧」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeA.png"  mouth="Per_p_egao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#
珀耳塞福涅轻轻颔首。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「我想更了解那位大人，更了解冥界」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#得墨忒耳
「明白了」[p]
「既然您这么说，我也该回去履行职责了」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
母亲得墨忒耳掌心朝上，轻轻呵了口气。[p]
[_tb_end_text]

[chara_mod  name="デメテル"  time="1400"  cross="true"  storage="chara/12/Demeter_base1.png"  ]
[chara_part  name="デメテル"  time="0"  eye="Demeter_p_bisho_eyeA.png"  mouth="Demeter_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#
黑色衣衫剥落，璀璨的衣裙包裹住女神。[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_bisho_eyeA.png"  mouth="Per_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「大地啊，再度萌芽吧。——结出果实之芽」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
女神轻声呼唤，从神殿俯瞰的整片土地顿时改换颜色。[r]
新绿如涟漪般延展开来。[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeC.png"  mouth="Per_p_egao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「哇啊……！」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeA.png"  mouth="Per_p_egao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「母亲果然厉害，转眼间大地就复苏了似的」[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_odoroki_eyeA.png"  mouth="Demeter_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「哎呀，你不也拥有同等力量吗？」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「真的吗？」[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_bisho_eyeA.png"  mouth="Demeter_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「只要你愿意，花朵自会在你身旁绽放。[r]
科瑞可是得墨忒耳的女儿。你播撒的种子注定会开花结果哦」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_magao_eyeA.png"  mouth="Per_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「我播撒的种子注定…」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
珀耳塞福涅忽然想起在冥界的日子。[p]
她忆起人类的亡魂，想起自己献上的花叶装饰。[r]
若那些举动确能维系冥界安宁，便是无上的喜悦。[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeB.png"  mouth="Per_p_egao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（原来像我这样的，也能为冥界尽绵薄之力）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeC.png"  mouth="Per_p_egao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「谢谢母亲！」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
珀耳塞福涅紧紧抱住母神。[p]
她从心底期待着重返冥府的那天。[p]
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="true"  ]
[bg  time="0"  method="crossfade"  storage="kuro.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#
季节轮转，珀耳塞福涅下冥界的日子终于来临。[p]
母神用华美衣裙将女儿装扮妥帖。[r]
毕竟丰饶女神之女再度前往夫家，仪容自当相称。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
在赫尔墨斯催促下，珀耳塞福涅再度登上冥王的马车。[p]
通向黑暗的道路，这次不再令她畏惧。[r]
她镇定凝视着逐渐幽暗的风景。[p]
[_tb_end_text]

[bg  time="600"  method="crossfade"  storage="kuro.jpg"  ]
[bg  time="1000"  method="crossfade"  storage="bak/popula.jpg"  ]
[tb_start_text mode=1 ]
#
马车停在了黑杨树之森的入口处。[p]
[_tb_end_text]

[chara_show  name="ヘルメス"  time="600"  wait="false"  storage="chara/13/Hermes_base.png"  width="752"  height="1410"  left="260"  top="-105"  reflect="false"  ]
[chara_part  name="ヘルメス"  time="0"  eye="Her_p_bisho_eyeA.png"  mouth="Her_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#
珀耳塞福涅借赫尔墨斯之手步下马车。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「不是在水晶洞穴前吗？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#赫尔墨斯
「嗯」[p]
「哈迪斯大人正在你钟爱的森林里候你归来」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「我钟爱的森林……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
冥王竟记得她频繁造访此林的往事。[r]
这点滴心意让她胸口发烫。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「谢谢你，赫尔墨斯」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_egao_eyeC.png"  mouth="Her_p_egao_mouthA.png"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「嗯」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_magao_eyeA.png"  mouth="Her_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「对了，作为长兄该给远嫁的妹妹赠言」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「赠言？」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_kusho_eyeA.png"  mouth="Her_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「对你们母女而言，宙斯大人或许是个麻烦的父亲…」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_bisho_eyeA.png"  mouth="Her_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「我们的父神也像得墨忒耳大人思念你那样，期盼着你的幸福」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「赫尔墨斯……」[p]
「嗯。但愿如此」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_egao_eyeC.png"  mouth="Her_p_egao_mouthA.png"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「来，请动身吧。王正在等你」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_egao_eyeA.png"  mouth="Her_p_egao_mouthA.png"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「愿冥界的王妃得享福乐」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「谢谢...也谢谢你们」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_hide  name="ヘルメス"  time="600"  wait="true"  pos_mode="false"  ]
[tb_start_text mode=1 ]
#
轻抚马匹后，珀耳塞福涅迈出了脚步。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
恍惚间觉得黑杨树之森染上了浅浅的颜色。[r]
本应充满青灰色的森林，此刻也被绿色与黄色等色彩点缀着。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
珀耳塞福涅想起母亲的话语。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#得墨忒耳
『只要你愿意，花朵就会在你身边绽放』[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（只要我愿意，花朵就会绽放——）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
珀耳塞福涅祈祷着。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（愿我和哈迪斯大人生活的这片冥界，能开出更多花朵）[p]
（并愿这些花儿能为来到冥界的魂灵们带来宁静时光）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[bg  time="1000"  method="crossfade"  storage="bak/popula3.jpg"  ]
[tb_start_text mode=1 ]
#
仿佛回应她的祈愿，鲜花愈发绚烂地盛放，将森林映照得莹白。[p]
[_tb_end_text]

[bg  time="2000"  method="fadeIn"  storage="cg2.png"  ]
[tb_start_text mode=1 ]
#
花朵的微光中，那位身披黑紫衣袍的王者身影自林间显现。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「哈迪斯大人！」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
王的身侧，忠诚的冥界守门犬也静静守候。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「刻耳柏洛斯也在！」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
珀耳塞福涅奔向前去。[r]
她轻轻提起母神为她穿上的新娘嫁衣——奔向丈夫身边。[p]
[_tb_end_text]

[bg  time="1500"  method="crossfade"  storage="cg2_21.png"  ]
[tb_start_text mode=1 ]
#哈迪斯
「欢迎回来，珀耳塞福涅。——我的妃子」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
王者的面容与往常无异，看不出多大变化。[p]
但那目光始终温暖地注视着，迎接着珀耳塞福涅。[p]
[_tb_end_text]

[wait  time="500"  ]
[mask  time="2000"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="true"  ]
[tb_hide_message_window  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[tb_ptext_show  x="150"  y="300"  size="25"  color="0xffffff"  time="1500"  text="Illustration/Logo：Ryoya&nbsp;Iritani"  face="serif,'游明朝'"  anim="false"  edge="undefined"  shadow="undefined"  ]
[tb_ptext_show  x="150"  y="350"  size="25"  color="0xffffff"  time="1500"  text="Music：minari"  face="serif,'游明朝'"  anim="false"  edge="undefined"  shadow="undefined"  ]
[tb_ptext_show  x="150"  y="400"  size="23"  color="0xffffff"  time="1500"  text="Creation&nbsp;tools：TyranoBuilder/TyranoScript"  face="serif,'游明朝'"  anim="false"  edge="undefined"  shadow="undefined"  ]
[tb_ptext_show  x="150"  y="450"  size="23"  color="0xffffff"  time="1500"  text="Plugins：空想曲線"  face="serif,'游明朝'"  anim="false"  edge="undefined"  shadow="undefined"  ]
[tb_ptext_show  x="150"  y="500"  size="25"  color="0xffffff"  time="1500"  text="Planning/Scenario/Direction/Production：Asa"  face="serif,'游明朝'"  anim="false"  edge="undefined"  shadow="undefined"  ]
[wait  time="1000"  ]
[tb_ptext_hide  time="1000"  ]
[tb_ptext_show  x="720"  y="270"  size="30"  color="0xffffff"  time="1500"  text="Thank&nbsp;you&nbsp;for&nbsp;playing."  anim="false"  face="serif,'游明朝'"  edge="undefined"  shadow="undefined"  ]
[tb_image_show  time="2000"  storage="default/end.png"  width="157"  height="75"  name="img_448"  x="1015"  y="555"  _clickable_img=""  ]
[wait  time="2000"  ]
[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[tb_ptext_hide  time="0"  ]
[tb_image_hide  time="0"  ]
[bg  time="0"  method="crossfade"  storage="kuro.jpg"  ]
[tb_eval  exp="sf.ending='clear'"  name="ending"  cmd="="  op="t"  val="clear"  val_2="undefined"  ]
[stopbgm  time="2000"  fadeout="true"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[wait  time="2000"  ]
[jump  storage="title_screen.ks"  target="*title2"  ]
[s  ]
[tb_start_text mode=1 ]
[ruby text="ようや"][p]
[_tb_end_text]

[chara_show  name="ケルベロス"  time="500"  wait="true"  storage="chara/16/Cerberus.png"  width="620"  height="1163"  left="5"  top="140"  reflect="false"  ]
[chara_show  name="ハデス"  time="500"  wait="false"  storage="chara/11/Hades_base.png"  width="752"  height="1410"  left="280"  top="-90"  reflect="false"  ]
