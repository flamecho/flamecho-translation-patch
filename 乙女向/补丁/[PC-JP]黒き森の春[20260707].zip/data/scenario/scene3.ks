﻿[_tb_system_call storage=system/_scene3.ks]

[playbgm  volume="13"  time="1000"  loop="true"  storage="bgm/prologue_anima.mp3"  ]
*scene3_start

[cm  ]
[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[tb_show_message_window  ]
[chara_hide_all  time="0"  wait="true"  ]
[bg  time="0"  method="crossfade"  storage="kuro.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#
不知又过去了多少天。[r]
今天我依然在冥府宫殿醒来。[p]
门扉彼端传来克制的叩击声[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#侍女
「珀耳塞福涅大人 您醒了吗」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
在冥府宫殿侍奉的下人们，都对我很好。[p]
暂且不论对父亲裁决的憋闷情绪，[r]
我本意并不想为难她们。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
我应了一声，让侍女们进到屋里。[r]
就这样换好衣服离开了房间。[p]
[_tb_end_text]

[bg  time="1000"  method="crossfade"  storage="bak/aides_hall.jpg"  ]
[tb_start_text mode=1 ]
#
前往之处正是宫殿的前厅[p]
虽宫中有专设的宴饮大厅 她却从未踏足[p]
从小吃着神酒和仙馔密酒——这些神明食物的我，[r]
并不特别需要饮食。[p]
[_tb_end_text]

[chara_show  name="ハデス"  time="500"  wait="false"  storage="chara/11/Hades_base.png"  width="752"  height="1410"  left="280"  top="-90"  reflect="false"  ]
[chara_part  name="ハデス"  time="500"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="true"  ]
[wait  time="500"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（啊……）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
从正厅右侧通道现身的，是哈迪斯叔叔。[p]
每当我来到正厅，叔叔总会现身。[r]
是在担心我吧。我低下头去。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「睡得好吗」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「是」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「可要用膳？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「不必了 抱歉 我实在没有食欲」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「是吗」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
和哈迪斯叔叔的对话总是草草结束。[p]
只有必要的简短交谈——但叔叔从不会主动离场。[r]
他会一直陪着，直到我回房。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（该怎么办呢……）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
若因难为情躲回房间 转瞬就会被思绪的蛛网缠住[p]
为何我会在这里？父亲为何什么都不告诉我？[r]
反复纠结着没有答案的问题，心情越来越低落。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（与其独处 宁可忍着尴尬留在外面）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
这处入口对外敞开着。[r]
能感受到水流波动，草木呼吸的气息。[p]
持续沉默令人紧张，但叔叔从不强迫我开口。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
就像水和植物一样，哈迪斯叔叔只是存在着。[r]
更重要的是——[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（好想感受流动的空气）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
在地上时，除举行仪式外我从不闭门不出。[r]
每天在原野奔跑、采花、帮母亲干活。[r]
本该是自由活动的。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（外面……）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
想起人间的空气，我忽然迫切想走出冥宫。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「那个，哈迪斯叔叔」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
叔叔像是回应我般眨了下眼。[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「我可以出去散步吗？[r]
因为…实在很怀念那些草木花朵」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
叔叔直直地凝视着我。[r]
表情丝毫不变。完全猜不透他在想什么。[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（难道…他担心我会逃跑？）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
就算逃跑，我也不知道返回地上的方法。[r]
明知会被抓回来，何必白费力气谋划。[p]
但我没能好好把这件事说清楚。[r]
入口再次被沉默笼罩。泉水涌动的声音听起来格外清晰。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「好吧」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
过了仿佛无比漫长的十几秒，哈迪斯叔叔点了点头。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「去走走吧」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_hide  name="ハデス"  time="800"  wait="false"  pos_mode="false"  ]
[tb_start_text mode=1 ]
#
叔叔的衣袍翻动。[r]
他没有转向通往王座的走廊，而是把身体转向连接外界的道路。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「诶」[p]
（难道……叔叔要亲自带我去？）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
我意外地僵在原地。[p]
大概是注意到我没动。[r]
哈迪斯叔叔缓缓转过身来。[p]
[_tb_end_text]

[chara_show  name="ハデス"  time="500"  wait="false"  storage="chara/11/Hades_base.png"  width="752"  height="1410"  left="280"  top="-90"  reflect="false"  ]
[chara_part  name="ハデス"  time="500"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="true"  ]
[wait  time="300"  ]
[tb_start_text mode=1 ]
#哈迪斯
「跟上来」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_hide  name="ハデス"  time="600"  wait="true"  pos_mode="false"  ]
[tb_start_text mode=1 ]
#
只说了这句话，叔叔便迈开脚步。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「啊、是…！」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
我也慌忙跟了上去。[p]
[_tb_end_text]

[bg  time="800"  method="crossfade"  storage="kuro.jpg"  ]
[bg  time="1000"  method="crossfade"  storage="bak/aides_entra.jpg"  ]
[tb_start_text mode=1 ]
#
跟随哈迪斯叔叔，我穿行在水晶洞穴中。[p]
[_tb_end_text]

[chara_show  name="ハデス"  time="500"  wait="false"  storage="chara/11/Hades_base.png"  width="752"  height="1410"  left="280"  top="-90"  reflect="false"  ]
[chara_part  name="ハデス"  time="500"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="true"  ]
[wait  time="500"  ]
[tb_start_text mode=1 ]
#哈迪斯
「散步该走这条道」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
洞窟内分出无数岔路。[r]
看起来走的不是我最初来时那条路。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「明白了」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
哈迪斯叔叔微微颔首，唤道："刻耳柏洛斯"[p]
[_tb_end_text]

[chara_hide  name="ハデス"  time="800"  wait="false"  pos_mode="false"  ]
[chara_show  name="ケルベロス"  time="800"  wait="true"  storage="chara/16/Cerberus.png"  width="620"  height="1163"  left="30"  top="50"  reflect="false"  ]
[tb_start_text mode=1 ]
#
应着叔叔的呼唤，出现了一只三头犬。[p]
冥界的看门犬刻耳柏洛斯——这名字我也是知道的。[r]
是对冥界之王忠心耿耿的守卫。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
虽然那介于野狼与恶犬之间的骇人外形令人胆寒[r]
刻耳柏洛斯似乎很亲近哈迪斯叔叔。[r]
当叔叔抚摸其中一个脑袋时，另外两个也争先恐后地把头凑过来。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
突然，她想起了被带到冥界的那天。[p]
那时候，拉车的马匹们也是这样被王抚摸着，不停地蹭着鼻子。[p]
刻耳柏洛斯和马儿们大概都特别喜欢哈迪斯叔叔。[r]
我噗嗤笑出了声。[p]
[_tb_end_text]

[chara_hide  name="ケルベロス"  time="500"  wait="false"  pos_mode="false"  ]
[chara_show  name="ハデス"  time="500"  wait="false"  storage="chara/11/Hades_base.png"  width="752"  height="1410"  left="280"  top="-90"  reflect="false"  ]
[chara_part  name="ハデス"  time="500"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="true"  ]
[tb_start_text mode=1 ]
#
哈迪斯叔叔似乎注意到我的声音，将视线转向我。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（啊……太失礼了吧）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
我缩了缩身子。[p]
叔叔似乎并不在意我的失笑。[r]
只是平淡地继续说着话。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
以后你要外出时，记得带上刻耳柏洛斯[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「诶？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
它是聪明又强壮的看门犬。[r]
有它同行，你就能安心散步了。[r]
——对吧，刻耳柏洛斯？[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_show  name="ケルベロス"  time="600"  wait="true"  storage="chara/16/Cerberus.png"  width="620"  height="1163"  left="5"  top="140"  reflect="false"  ]
[tb_start_text mode=1 ]
#
三颗脑袋像是表示同意般，各自将鼻子蹭上冥界之王的手掌。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
虽说长相可怕，但这副模样怎么看都像是向主人撒娇的普通狗狗。[p]
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="true"  ]
[bg  time="600"  method="crossfade"  storage="kuro.jpg"  ]
[stopbgm  time="2000"  fadeout="true"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#
被哈迪斯叔叔领着走到尽头时，我瞬间转移到了森林里。[p]
[_tb_end_text]

[bg  time="1000"  method="crossfade"  storage="bak/popula2.jpg"  ]
[playbgm  volume="15"  time="1000"  loop="true"  storage="bgm/hades_off.mp3"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
这棵树是……[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
黑杨树。[r]
笔直的树干冲天而起，茂密的枝叶在上方交错纠缠。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
不仅没有阳光透进来，还被漆黑的枝叶完全遮蔽。[r]
按理说这里应该更暗才对。[p]
但叶背的银光与簇生在根部的白花，都像要照亮黑暗般散发着光芒。[r]
或许是这个缘故，森林的漆黑显得格外美丽。[p]
[_tb_end_text]

[chara_show  name="ハデス"  time="500"  wait="false"  storage="chara/11/Hades_base.png"  width="752"  height="1410"  left="280"  top="-90"  reflect="false"  ]
[chara_part  name="ハデス"  time="500"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="true"  ]
[wait  time="500"  ]
[tb_start_text mode=1 ]
#哈迪斯
我们来时的路，就通往这座森林[p]
阿斯福德之野很广阔。不过对刻耳柏洛斯来说不会迷路[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
深渊还在更深处。[r]
应该不至于误入[p]
但幽冥界就延展在森林深处。说不定会不小心走进去。[r]
不要离开刻耳柏洛斯身边[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
人类死后，灵魂会通过冥界之门。[r]
接受审判后，将前往三个去处中的其中一个。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
大多数灵魂都被送往名为阿斯福德之野的地方。[r]
犯下重罪或违抗神明之人会坠入深渊。受英雄与诸神宠爱的灵魂则能前往乐园。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
这片森林似乎就位于阿斯福德之野。[r]
也就是说，周遭一定飘荡着许多人类的魂魄。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
而幽冥乃是远古众神栖居之地。[p]
它们的存在比哈迪斯叔叔和得墨忒耳母亲还要古老。[r]
即便冥界处于叔父统治之下，这里仍是需要尊重的领域吧。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
我对冥界并不熟悉。[r]
有刻耳柏洛斯在身边似乎更安心些。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（即便如此……）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
每一株树木都散发着强烈的生命力。[p]
虽然没有阳光，但在这种深深扎根于地底的磅礴力量面前[r]
我自然而然地感到安心。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
我向前迈出一步。试着触碰树干。[r]
——似乎隐约听到了树木的脉搏声。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
是因为触碰到了与母亲力量相连的「植物」吧。[r]
我想起了母亲。[p]
温柔又坚强的母亲——现在过得怎样了呢。[r]
我被强行掳到冥界的事，母亲应该已经听说了吧？[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（好想——见母亲啊）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
但这句话终究没能说出口。[p]
虽然对现状并不满意，但哈迪斯叔叔和侍女们「倒不算坏」。[r]
他们只是遵循既定的规则履行自己的职责。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
正因为无处问责，忧郁才愈发深重。[p]
但总觉得在这里找到了能寄托对母亲思念的场所。[r]
我轻轻倚靠黑杨树的树干，思念着地上的母亲。[p]
[_tb_end_text]

[jump  storage="scene4.ks"  target="*scene4_start"  ]
[s  ]
[tb_start_text mode=1 ]
[ruby text="ようや"][p]
[_tb_end_text]

