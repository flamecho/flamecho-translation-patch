﻿[_tb_system_call storage=system/_scene7.ks]

*scene7_start

[cm  ]
[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[stopbgm  time="2000"  fadeout="true"  ]
[tb_show_message_window  ]
[tb_start_tyrano_code]
[position layer="message0" left="40" top="30" width="1200" height="660" margint="50" marginl="100" marginr="110" marginb="50"frame="none" opacity="220"]
[button name="role_button" role="save" graphic="../others/plugin/theme_kopanda_bth_08/image/button/save3.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/save2.png" x="1216" y="531" width="45" height="20"]
[button name="role_button" role="load" graphic="../others/plugin/theme_kopanda_bth_08/image/button/load3.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/load2.png"  x="1214" y="557" width="49" height="20"]
[button name="role_button" role="auto" graphic="../others/plugin/theme_kopanda_bth_08/image/button/auto3.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/auto2.png" x="1215" y="583" width="46" height="19"]
[button name="role_button" role="skip" graphic="../others/plugin/theme_kopanda_bth_08/image/button/skip3.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/skip2.png" x="1217" y="609" width="47" height="26"]
[button name="role_button" role="backlog" graphic="../others/plugin/theme_kopanda_bth_08/image/button/log3.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/log2.png" x="1220" y="634" width="39" height="27"]
[button name="role_button" role="sleepgame" graphic="../others/plugin/theme_kopanda_bth_08/image/button/sleep3.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/sleep2.png" storage="../others/plugin/theme_kopanda_bth_08/config.ks" x="1213" y="661" width="57" height="26"]
[button name="role_button" role="title" graphic="../others/plugin/theme_kopanda_bth_08/image/button/title3.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/title2.png" x="1215" y="691" width="48" height="21"]
[button name="role_button" role="window" graphic="../others/plugin/theme_kopanda_bth_08/image/button/close.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/close3.png" x="1262" y="520" width="13" height="13"]
[_tb_end_tyrano_code]

[chara_hide_all  time="0"  wait="true"  ]
[bg  time="0"  method="crossfade"  storage="kuro.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[bg  time="1000"  method="crossfade"  storage="bak/ereusis.jpg"  ]
[tb_start_text mode=1 ]
#
父亲的裁定很快下达了。[l][r]
[r]
在冥界食用石榴的我，必须遵守古老律法。[l][r]
[r]
大地的季节轮回有三。[r]
其中一季我必须在冥界度过。[l][r]
[r]
但剩余两季允许我与地上的母亲共同生活。[p]
[_tb_end_text]

[playbgm  volume="15"  time="1000"  loop="true"  storage="bgm/hades_off.mp3"  ]
[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[tb_start_tyrano_code]
[position layer="message0" width="1280" height="220" top="505" left="0"]
[position layer="message0" frame="../others/plugin/theme_kopanda_bth_08/image/frame_message.png" margint="60" marginl="120" marginr="140" marginb="50" opacity="220" page="fore"]
[_tb_end_tyrano_code]

[tb_start_tyrano_code]
[button name="role_button" role="save" graphic="../others/plugin/theme_kopanda_bth_08/image/button/save.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/save2.png" x="1216" y="531" width="45" height="20"]
[button name="role_button" role="load" graphic="../others/plugin/theme_kopanda_bth_08/image/button/load.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/load2.png"  x="1214" y="557" width="49" height="20"]
[button name="role_button" role="auto" graphic="../others/plugin/theme_kopanda_bth_08/image/button/auto.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/auto2.png" x="1215" y="583" width="46" height="19"]
[button name="role_button" role="skip" graphic="../others/plugin/theme_kopanda_bth_08/image/button/skip.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/skip2.png" x="1217" y="609" width="47" height="26"]
[button name="role_button" role="backlog" graphic="../others/plugin/theme_kopanda_bth_08/image/button/log.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/log2.png" x="1220" y="634" width="39" height="27"]
[button name="role_button" role="sleepgame" graphic="../others/plugin/theme_kopanda_bth_08/image/button/sleep.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/sleep2.png" storage="../others/plugin/theme_kopanda_bth_08/config.ks" x="1213" y="661" width="57" height="26"]
[button name="role_button" role="title" graphic="../others/plugin/theme_kopanda_bth_08/image/button/title.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/title2.png" x="1215" y="691" width="48" height="21"]
[button name="role_button" role="window" graphic="../others/plugin/theme_kopanda_bth_08/image/button/close.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/close.png" x="1262" y="520" width="13" height="13"]
[_tb_end_tyrano_code]

[chara_show  name="デメテル"  time="0"  wait="false"  storage="chara/12/Dameter_base2.png"  width="840"  height="1575"  left="225"  top="-165"  reflect="false"  ]
[chara_part  name="デメテル"  time="0"  eye="Demeter_p_magao_eyeA.png"  mouth="Demeter_p_magao_mouthA.png"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「也罢」[p]

[_tb_end_text]

[tb_start_text mode=1 ]
#得墨忒耳
「只要科瑞确定能返回地面，我认了」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「谢谢母亲！」[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_odoroki_eyeA.png"  mouth="Demeter_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「哎呀，为何要你来道谢？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「诶」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#得墨忒耳
「活像你盼着去冥界似的」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「那个......」[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_bisho_eyeA.png"  mouth="Demeter_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「没关系的，我亲爱的科瑞」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#得墨忒耳
「虽然心里还有火气[r]
但既然哈迪斯承诺会珍视你...也不是不能考虑」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#得墨忒耳
「我只愿你的丈夫能专情于你」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#得墨忒耳
「科瑞是倾心于哈迪斯了？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
说我喜欢哈迪斯叔叔——这种话真是羞人。[p]
但在冥界度过的一整个季节里，我都能够待在哈迪斯大人身边。[r]
也能和刻耳柏洛斯还有马儿们在一起。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「嗯。我想...是吧」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
我点了点头。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「我想更了解那位大人，更了解冥界」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#得墨忒耳
「明白了」[p]
「我也该回到岗位上了」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
母亲摊开掌心，轻轻往上吹了口气。[p]
[_tb_end_text]

[chara_mod  name="デメテル"  time="1400"  cross="true"  storage="chara/12/Demeter_base1.png"  ]
[chara_part  name="デメテル"  time="0"  eye="Demeter_p_bisho_eyeA.png"  mouth="Demeter_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#
黑色外衣剥落，闪耀夺目的衣裳包裹住母亲。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#得墨忒耳
「大地啊，再度萌芽吧。——结出果实之芽」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
随着母亲的话语，从神殿俯瞰的地界逐渐变色。[r]
新绿以肉眼可见的速度蔓延开来。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「哇啊……！」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「母亲果然厉害，转眼间大地就复苏了似的」[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_odoroki_eyeA.png"  mouth="Demeter_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「哎呀，你不也拥有同等力量吗？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「咦？」[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_bisho_eyeA.png"  mouth="Demeter_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「只要你愿意，花朵自会在你身旁绽放。[r]
科瑞可是得墨忒耳的女儿。你播撒的种子注定会开花结果哦」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「我播撒的种子注定…」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
我忽然想起在冥界的生活。[p]
我为人间的灵魂们献上过花朵与叶子的装饰。[r]
若我的行为能为冥界带来安宁，那真是再好不过。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（原来像我这样的，也能为冥界尽绵薄之力）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「谢谢母亲！」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
我抱住了母亲。[p]
真心期待着重返冥界之日的到来。[p]
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="true"  ]
[bg  time="0"  method="crossfade"  storage="kuro.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#
季节流转，我降临冥界的日子终于来临。[p]
母亲用华美的衣裙装扮我。[r]
身为丰饶女神的女儿再度奔赴夫家，必须要有相称的仪态。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
在赫尔墨斯催促下，我再度登上冥界之王的马车。[p]
通往黑暗的道路如今也不再可怕。[r]
我平静地凝视着渐渐暗沉的风景。[p]
[_tb_end_text]

[bg  time="600"  method="crossfade"  storage="kuro.jpg"  ]
[bg  time="1000"  method="crossfade"  storage="bak/popula.jpg"  ]
[tb_start_text mode=1 ]
#
马车停在了黑杨树之森的入口处。[p]
[_tb_end_text]

[chara_show  name="ヘルメス"  time="600"  wait="false"  storage="chara/13/Hermes_base.png"  width="752"  height="1410"  left="260"  top="-105"  reflect="false"  ]
[chara_part  name="ヘルメス"  time="0"  eye="Her_p_bisho_eyeA.png"  mouth="Her_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#
借助赫尔墨斯的手，我走下马车。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「不是在水晶洞穴前面呢」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#赫尔墨斯
「嗯」[p]
「哈迪斯大人正在你深爱的森林里等你。快去吧」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「我钟爱的森林……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
哈迪斯大人还记得我频繁造访森林的事。[r]
就连这样的小事也让我心头一热。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「谢谢你送我，赫尔墨斯。[r]
——也谢谢你们呀」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_hide  name="ヘルメス"  time="600"  wait="true"  pos_mode="false"  ]
[tb_start_text mode=1 ]
#
轻抚过马儿们后，我迈出脚步。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
恍惚间觉得黑杨树之森染上了浅浅的颜色。[r]
本应充满青灰色的森林，此刻也被绿色与黄色等色彩点缀着。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
我想起母亲说过的话。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#得墨忒耳
『只要你愿意，花朵就会在你身边绽放』[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（只要我愿意，花朵就会绽放——）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
我祈祷着。[r]
但愿我与哈迪斯大人生活的这片冥界能绽放更多花朵。[p]
[_tb_end_text]

[bg  time="1000"  method="crossfade"  storage="bak/popula3.jpg"  ]
[tb_start_text mode=1 ]
#
仿佛回应我的愿望，鲜花愈发绚丽地绽放，将整片森林映照成雪白。[p]
[_tb_end_text]

[chara_show  name="ハデス"  time="500"  wait="false"  storage="chara/11/Hades_base.png"  width="752"  height="1410"  left="280"  top="-90"  reflect="false"  ]
[chara_part  name="ハデス"  time="500"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="true"  ]
[tb_start_text mode=1 ]
#
花朵的微光中，那位身披黑紫衣袍的王者身影自林间显现。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「哈迪斯大人！」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_show  name="ケルベロス"  time="500"  wait="true"  storage="chara/16/Cerberus.png"  width="620"  height="1163"  left="5"  top="140"  reflect="false"  ]
[tb_start_text mode=1 ]
#
王的身侧，忠诚的冥界守门犬也静静守候。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「刻耳柏洛斯也在！」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
我奔跑起来。[r]
稍稍提起母亲为我穿上的新娘嫁衣——奔向我的丈夫。[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeA.png"  mouth="Hades_p_bisho_mouthA.png"  wait="false"  ]
[wait  time="300"  ]
[tb_start_text mode=1 ]
#哈迪斯
「欢迎回来，珀耳塞福涅。——我的妃子」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
哈迪斯大人的表情与往常并无二致。[p]
但那目光始终温暖地迎接着我。[p]
[_tb_end_text]

[mask  time="2000"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="true"  ]
[tb_hide_message_window  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[tb_image_show  time="2000"  storage="default/end.png"  width="157"  height="75"  name="img_448"  x="586"  y="555"  _clickable_img=""  ]
[wait  time="3000"  ]
[tb_image_hide  time="1000"  ]
[tb_eval  exp="sf.ending='clear'"  name="ending"  cmd="="  op="t"  val="clear"  val_2="undefined"  ]
[stopbgm  time="2000"  fadeout="true"  ]
[bg  time="2500"  method="crossfade"  storage="kuro.jpg"  ]
[jump  storage="title_screen.ks"  target="*title2"  ]
[s  ]
[tb_start_text mode=1 ]
[ruby text="ようや"][p]
[_tb_end_text]

