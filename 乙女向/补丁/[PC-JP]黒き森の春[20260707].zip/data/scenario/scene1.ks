﻿[_tb_system_call storage=system/_scene1.ks]

[plugin name=auto_indent]

[plugin name="backlog"]

*scene1_start

[stopbgm  time="1000"  fadeout="true"  ]
[tb_hide_message_window  ]
[cm  ]
[bg  time="1000"  method="crossfade"  storage="kuro.jpg"  ]
[tb_image_show  time="1000"  storage="default/intro.png"  width="524"  height="398"  x="390"  y="150"  _clickable_img=""  name="img_7"  ]
[wait  time="4000"  ]
[tb_image_hide  time="1000"  ]
*prologue

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[tb_show_message_window  ]
[tb_image_hide  time="0"  ]
[tb_ptext_hide  time="0"  ]
[bg  time="1000"  method="crossfade"  storage="bak/hanabatake.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[playbgm  volume="13"  time="1000"  loop="true"  storage="bgm/kiri_alone.mp3"  fadein="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「今天也有很多可爱的小花呢」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「要编几个花环好呢？[r]
紫罗兰配番红花。点缀些玫瑰和风信子也不错」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#宁芙们
「科瑞大人，请不要太靠近森林那边」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「我知道的，没关系。我就采这附近的花」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「精灵们真是过度保护呢。我早就是堂堂正正的大姑娘了」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「父亲大人也说它们长得很美」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「我什么时候才能像母亲那样成为出色的女性呢。[r]
美丽又坚强的，我的母亲」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（我的父亲大人是统御天际的主神宙斯）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（母亲是丰饶女神得墨忒耳。摇动金色麦穗，怀抱丰饶果实）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（母亲大人与父亲大人是姐弟神。[r]
倒也并非经历过轰轰烈烈的恋情才生下我）[p]
（不仅如此，她对喜欢或讨厌这类事似乎全无兴趣。[r]
虽然姐弟间似乎有治理天地的协作关系）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「记得母亲的兄弟姐妹排序，从上到下是赫斯提亚大人、母亲、赫拉大人、[r]
哈迪斯大人、波塞冬大人、父神宙斯」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（赫斯提亚大人我很熟悉。是位文静温柔的长辈）[p]
（赫拉大人是父亲大人的正妃。[r]
几乎没有交谈过。——总觉得有些可怕）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（哈迪斯大人——冥界的君王。未曾谋面）[p]
（波塞冬舅舅经常被母亲大人训斥，[r]
倒是位随和的神明）[p]
（还有父亲大人。当他降临地面时，我们会稍作交谈）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（母亲大人很少前往天界。我也只去过寥寥数次）[p]
（有兄弟姐妹会是怎样的感受呢？）[p]
「毕竟我没有呢……。实在想象不出啊」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（会聊天谈心，偶尔也会吵架吧。[r]
像母亲和其他兄弟姐妹神明那样）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（但实在难以对母亲开口说想要弟弟妹妹啊……[r]
总觉得，母亲似乎很满足现状）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「好啦，花采得差不多了，该开始编花环了」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[tb_image_show  time="1000"  storage="default/pica.png"  width="640"  height="640"  x="-30"  y="30"  _clickable_img=""  name="img_34"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「咦？」[p]
[_tb_end_text]

[tb_image_hide  time="1000"  ]
[tb_image_show  time="1000"  storage="default/suisens.png"  width="224"  height="356"  x="230"  y="170"  _clickable_img=""  name="img_37"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「那边开的是水仙吗？[r]
孤零零只开一朵还真是少见」[p]
[_tb_end_text]

[tb_image_hide  time="1000"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「像宝石般闪闪发亮……。[r]
定是受到盖亚大人垂怜的花呢。就让它当花环的中心吧」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（美得妖异的水仙。简直不忍心采摘）[p]
[_tb_end_text]

[playse  volume="20"  time="1000"  buf="0"  storage="buki_hasiru.mp3"  fadein="true"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「？什么声音？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[bg  time="1000"  method="crossfade"  storage="bak/hanabatake2.jpg"  ]
[tb_start_text mode=1 ]
#
突然大地裂开巨口，驾着双马车的男子从中现身。[p]
[_tb_end_text]

[stopse  time="1000"  buf="0"  fadeout="true"  ]
[chara_show  name="ハデス"  time="500"  wait="false"  storage="chara/11/Hades_base.png"  width="752"  height="1410"  left="280"  top="-90"  reflect="false"  ]
[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#
马车在我面前停下。那男人与我的视线相撞了。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
被他散发出的异常气势所震慑，我不禁退缩。[p]
突然，男人抓住了我的手腕。[p]
[_tb_end_text]

[chara_hide  name="ハデス"  time="600"  wait="false"  pos_mode="false"  ]
[tb_start_text mode=1 ]
#
我被他强大的力道拽向马车边缘。[r]
双腿打结，整个人重重摔倒在马车地板上。[p]
[_tb_end_text]

[playse  volume="30"  time="1000"  buf="0"  storage="kouka_dosa.mp3"  ]
[tb_start_text mode=1 ]
#
男人瞥了我一眼，再次握紧缰绳。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「等…」[p]
（这个人是谁！？）[p]
[_tb_end_text]

[stopse  time="0"  buf="0"  fadeout="false"  ]
[tb_start_text mode=1 ]
#
[_tb_end_text]

[playse  volume="15"  time="1000"  buf="0"  storage="buki_hasiru.mp3"  fadein="true"  loop="true"  ]
[bg  time="1000"  method="crossfade"  storage="bak/hanabatake3.jpg"  ]
[tb_start_text mode=1 ]
#
马匹再次起步后不久，四周景色骤然变化。[p]
光与色彩逐渐消失，寒风愈发凛冽。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
直到这时，我才意识到自己正在被绑架。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（怎、怎么回事...！？）[p]
「不要！救救我，母亲大人！父亲大人...！」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
我的母亲是丰饶女神得墨忒耳，父亲则是执掌世界秩序的至高神。[r]
若是这两位神明，定会来救我的。[p]
毕竟我根本什么都没做，凭什么要被陌生男人掳走。[p]
[_tb_end_text]

[stopse  time="1000"  buf="0"  fadeout="true"  ]
[tb_start_text mode=1 ]
#
但父母的双臂始终未曾伸出。[p]
[_tb_end_text]

[bg  time="1000"  method="crossfade"  storage="kuro.jpg"  ]
[tb_start_text mode=1 ]
#
渐渐地，视野里的光与色彩都开始远去。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[jump  storage="scene2.ks"  target="*scene2_start"  ]
[s  ]
[tb_start_text mode=1 ]
[ruby text="ようや"][p]
[_tb_end_text]

