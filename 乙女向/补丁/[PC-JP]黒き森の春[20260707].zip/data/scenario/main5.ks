﻿[_tb_system_call storage=system/_main5.ks]

[playbgm  volume="15"  time="1000"  loop="true"  storage="bgm/hades_off.mp3"  ]
*start

[cm  ]
[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[tb_show_message_window  ]
[chara_hide_all  time="0"  wait="true"  ]
[bg  time="0"  method="crossfade"  storage="kuro.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[bg  time="1000"  method="crossfade"  storage="bak/popula2.jpg"  ]
[tb_start_text mode=1 ]
#
此后，珀耳塞福涅频繁造访黑杨树之森。[p]
经常因思念母神而落泪。[r]
即便如此，她还是想尝试所有可能做到的事。[r]
珀耳塞福涅带着刻耳柏洛斯，将足迹延伸至森林周边。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
森林边缘流淌着从催人遗忘之河分流出的溪涧。[p]
溪水呈现出如乳汁般的洁白。[r]
生长在周围的花朵显得格外耀眼。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
溪畔偶尔能看见疑似人类灵魂的身影。[p]
珀耳塞福涅身边总是跟随着刻耳柏洛斯。[r]
亡灵们从不敢靠近。[p]
但当她与亡灵们共同凝望泛着白光的小溪潺潺时，[r]
珀耳塞福涅开始想为这些灵魂准备些什么。[p]
[_tb_end_text]

[chara_show  name="ペルセポネ"  time="500"  wait="false"  storage="chara/10/Per_base.png"  width="800"  height="1500"  left="280"  top="-155"  reflect="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_bisho_eyeA.png"  mouth="Per_p_bisho_mouthA2.png"  wait="false"  ]
[wait  time="500"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（愿亡灵们能在阿斯福德之野安详度日）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
她着手编制与刻耳柏洛斯项圈不同的花环。[p]
对花朵之美的感受，神明与人类灵魂并无不同。[r]
珀耳塞福涅将编好的花环轻轻挂在黑杨树枝上。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
渐渐地，亡灵们开始聚集在花环之下。[p]
因不会靠近女神，刻耳柏洛斯也不再威慑他们。[r]
三头犬静静等待女神编完花束，随后跟随她的步伐离开。[p]
[_tb_end_text]

[chara_hide  name="ペルセポネ"  time="600"  wait="true"  pos_mode="false"  ]
[bg  time="600"  method="crossfade"  storage="kuro.jpg"  ]
[bg  time="1000"  method="crossfade"  storage="bak/aides_carve.jpg"  ]
[tb_start_text mode=1 ]
#
有些灵魂如薄雾般在洞穴中飘荡。[p]
据哈迪斯王所说，甚至有灵魂觉得花的光芒太过刺眼。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
珀耳塞福涅为它们准备了黑杨树叶编织的饰品。[p]
叶背散发着朦胧的银色微光。[r]
她根据亡灵们偏爱的暗度调整编织方式。[p]
或是挂在凸岩上，或是置于凹穴之中。[r]
单调的岩洞因叶饰而有了明暗层次。[p]
[_tb_end_text]

[bg  time="600"  method="crossfade"  storage="kuro.jpg"  ]
[bg  time="1000"  method="crossfade"  storage="bak/aides_hall.jpg"  ]
[chara_show  name="ハデス"  time="500"  wait="false"  storage="chara/11/Hades_base.png"  width="720"  height="1350"  left="30"  top="-85"  reflect="false"  ]
[chara_part  name="ハデス"  time="500"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="true"  ]
[wait  time="500"  ]
[tb_start_text mode=1 ]
#
哈迪斯王始终温柔如初。[r]
每当珀耳塞福涅经过入口，君王必定亲自相迎。[p]
[_tb_end_text]

[chara_show  name="ペルセポネ"  time="500"  wait="false"  storage="chara/10/Per_base.png"  width="720"  height="1350"  left="560"  top="-115"  reflect="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_bisho_eyeA.png"  mouth="Per_p_bisho_mouthA2.png"  wait="false"  ]
[wait  time="500"  ]
[tb_start_text mode=1 ]
#
也总是耐心倾听她的每句话语。[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeA.png"  mouth="Per_p_bisho_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#
王的表情几乎不曾变化。[r]
但他从未粗暴对待过珀耳塞福涅。[p]
[_tb_end_text]

[chara_hide_all  time="800"  wait="true"  ]
[tb_start_text mode=1 ]
#
时光就在这样的往复中流逝。[p]
心结并未完全解开。[r]
但珀耳塞福涅已逐渐习惯冥界静谧安宁的氛围。[p]
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[stopbgm  time="2000"  fadeout="true"  ]
[bg  time="0"  method="crossfade"  storage="kuro.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#
而在冥界遥不可及的穹顶之上——[p]
[_tb_end_text]

[bg  time="1000"  method="crossfade"  storage="bak/olympos.jpg"  ]
[playbgm  volume="12"  time="1000"  loop="true"  storage="bgm/sleep_inwoods.mp3"  fadein="false"  ]
[chara_show  name="ゼウス"  time="500"  wait="false"  storage="chara/14/Zeus_base.png"  width="752"  height="1410"  left="5"  top="-70"  reflect="false"  ]
[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_magao_eyeA.png"  mouth="Zeus_p_magao_mouthA.png"  ]
[chara_show  name="ヘルメス"  time="500"  wait="false"  storage="chara/13/Hermes_base.png"  width="736"  height="1380"  left="560"  top="-80"  reflect="false"  ]
[chara_part  name="ヘルメス"  time="0"  eye="Her_p_magao_eyeA.png"  mouth="Her_p_magao_mouthA.png"  ]
[wait  time="500"  ]
[tb_start_text mode=1 ]
#宙斯
「姐姐大人呢？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#赫尔墨斯
「依然闭居神殿之中」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#赫尔墨斯
「失去了得墨忒耳大人的恩惠，庄稼都不再结果了。[r]
储存的粮食也快见底了。人类灭绝只是时间问题吧」[p]
[_tb_end_text]

[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_magao_eyeB.png"  mouth="Zeus_p_magao_mouthA.png"  ]
[tb_start_text mode=1 ]
#宙斯
「这可麻烦了……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
人类若灭绝，给众神的供奉也会断绝。[p]
同时，众神的荣光也将陨落。[r]
宙斯统治的世界秩序恐怕会崩溃。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
某些人就会认定宙斯的统治有问题，开始图谋篡位。[r]
一旦动乱发生，连大地母神都不会坐视不理。[p]
[_tb_end_text]

[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_magao_eyeA.png"  mouth="Zeus_p_magao_mouthA.png"  ]
[tb_start_text mode=1 ]
#宙斯
「姐姐大人甚至拒绝接见我派去的彩虹女神」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
彩虹女神是传达宙斯旨意的使者。[r]
拒绝她就等于公然与宙斯对立。[p]
[_tb_end_text]

[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_magao_eyeA.png"  mouth="Zeus_p_magao_mouthA.png"  ]
[tb_start_text mode=1 ]
#宙斯
「我并不愿与姐姐大人为敌」[p]
[_tb_end_text]

[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_koma_eyeA.png"  mouth="Zeus_p_magao_mouthA.png"  ]
[tb_start_text mode=1 ]
#宙斯
「但——姐姐大人恐怕不会让步吧。事到如今，九头牛都拉不回了」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_kusho_eyeB.png"  mouth="Her_p_kusho_mouthA.png"  ]
[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_kusho_eyeB.png"  mouth="Zeus_p_magao_mouthA.png"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「确实。我亲自登门拜访过，可她压根听不进去」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_kusho_eyeA.png"  mouth="Her_p_kusho_mouthA.png"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「不止是我。[r]
连得墨忒耳大人疼爱的雅典娜大人、狄俄尼索斯，[r]
以及与珀耳塞福涅交好的阿尔忒弥斯和阿芙罗狄忒的话，她都置若罔闻」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_bisho_eyeA.png"  mouth="Her_p_magao_mouthA.png"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「要不再请宙斯大人的其他兄弟姐妹帮忙？」[p]
[_tb_end_text]

[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_odoroki_eyeA.png"  mouth="Zeus_p_odoroki_mouthA.png"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「若是赫斯提亚大人或赫拉大人出面，得墨忒耳大人或许愿意谈谈？」[p]
[_tb_end_text]

[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_koma_eyeA.png"  mouth="Zeus_p_magao_mouthA.png"  ]
[tb_start_text mode=1 ]
#宙斯
「不，赫拉她...多半会站在姐姐那边」[p]
[_tb_end_text]

[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_kusho_eyeA.png"  mouth="Zeus_p_kusho_mouthA.png"  ]
[tb_start_text mode=1 ]
#宙斯
「就算请赫斯提亚姐姐出面，也只会被她说教我的不是」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_kusho_eyeA.png"  mouth="Her_p_magao_mouthA.png"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「竟会如此？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#宙斯
「嗯。很容易想象那场景」[p]
[_tb_end_text]

[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_magao_eyeA.png"  mouth="Zeus_p_magao_mouthA.png"  ]
[tb_start_text mode=1 ]
#宙斯
「没办法。让珀耳塞福涅回到地面吧」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_odoroki_eyeA.png"  mouth="Her_p_odoroki_mouthA.png"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「这样妥当吗？」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_magao_eyeA.png"  mouth="Her_p_odoroki_mouthA.png"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「若对得墨忒耳大人让步，冥界这次可不会沉默」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_magao_eyeA.png"  mouth="Her_p_magao_mouthA.png"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「把已入冥界的亡者遣返人间，是否触犯天条？」[p]
[_tb_end_text]

[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_bisho_eyeA.png"  mouth="Zeus_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#宙斯
「这点无需担心」[p]
「那位大哥怎么可能轻易放走中意的王妃」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_odoroki_eyeA.png"  mouth="Her_p_magao_mouthA.png"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「哈迪斯大人中意珀耳塞福涅？」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_kusho_eyeA.png"  mouth="Her_p_odoroki_mouthA.png"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「虽说现今冥界确实一片祥和……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#宙斯
「他就是中意那姑娘。错不了」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_bisho_eyeA.png"  mouth="Her_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「原来如此」[p]
「既然宙斯大人说得如此明确，想必就是如此吧」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#宙斯
「珀耳塞福涅像她姐姐大人一样，是个美人啊」[p]
[_tb_end_text]

[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_kusho_eyeA.png"  mouth="Zeus_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#宙斯
「哎呀呀。姐姐大人明明很乐意帮忙造小孩的」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_magao_eyeA.png"  mouth="Her_p_magao_mouthA.png"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「宙斯大人」[p]
[_tb_end_text]

[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_koma_eyeA.png"  mouth="Zeus_p_koma_mouthA.png"  ]
[tb_start_text mode=1 ]
#宙斯
「我明白」[p]
[_tb_end_text]

[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_magao_eyeA.png"  mouth="Zeus_p_magao_mouthA.png"  ]
[tb_start_text mode=1 ]
#宙斯
「赫尔墨斯，立刻前往冥界与兄长协商。[r]
必须尽快将珀耳塞福涅送到得墨忒耳姐姐大人身边」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_bisho_eyeA.png"  mouth="Her_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「遵命」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="true"  ]
[stopbgm  time="2000"  fadeout="true"  ]
[bg  time="0"  method="crossfade"  storage="kuro.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[bg  time="1000"  method="crossfade"  storage="bak/aides_entra.jpg"  ]
[playbgm  volume="15"  time="1000"  loop="true"  storage="bgm/hades_off.mp3"  ]
[chara_show  name="ペルセポネ"  time="500"  wait="false"  storage="chara/10/Per_base.png"  width="720"  height="1350"  left="480"  top="-115"  reflect="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeA.png"  mouth="Per_p_egao_mouthA.png"  wait="false"  ]
[chara_show  name="ケルベロス"  time="500"  wait="true"  storage="chara/16/Cerberus.png"  width="620"  height="1163"  left="50"  top="130"  reflect="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「刻耳柏洛斯，今天也谢谢你陪我散步」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeC.png"  mouth="Per_p_egao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「明天见！」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_hide_all  time="600"  wait="true"  ]
[tb_start_text mode=1 ]
#
目送刻耳柏洛斯朝冥界之门离去后，珀耳塞福涅踏入了冥宫。[p]
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[chara_show  name="ペルセポネ"  time="0"  wait="false"  storage="chara/10/Per_base.png"  width="800"  height="1500"  left="280"  top="-155"  reflect="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA2.png"  wait="false"  ]
[bg  time="0"  method="crossfade"  storage="bak/aides_hall.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（咦？）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
往常哈迪斯王都会在门厅迎接珀耳塞福涅。[p]
但今日却不见王的身影。[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeB.png"  mouth="Per_p_odoroki_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（哈迪斯大人怎么了呢。是公务太繁忙吗……）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_bisho_eyeA.png"  mouth="Per_p_bisho_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（或许在王座之厅。我去打个招呼吧）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_hide  name="ペルセポネ"  time="600"  wait="true"  pos_mode="false"  ]
[tb_start_text mode=1 ]
#
珀耳塞福涅朝着通往王座之厅的走廊迈步前行。[p]
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[bg  time="0"  method="crossfade"  storage="bak/aides_gyokza.jpg"  ]
[chara_show  name="ヘルメス"  time="0"  wait="false"  storage="chara/13/Hermes_base.png"  width="688"  height="1290"  left="-90"  top="-84"  reflect="false"  ]
[chara_part  name="ヘルメス"  time="0"  eye="Her_p_bisho_eyeA.png"  mouth="Her_p_bisho_mouthA.png"  ]
[chara_show  name="ハデス"  time="0"  wait="false"  storage="chara/11/Hades_base.png"  width="700"  height="1313"  left="320"  top="-78"  reflect="false"  ]
[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[chara_show  name="ペルセポネ"  time="500"  wait="false"  storage="chara/10/Per_base.png"  width="700"  height="1313"  left="680"  top="-105"  reflect="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA2.png"  wait="false"  ]
[wait  time="300"  ]
[tb_start_text mode=1 ]
#
王座之厅里，赫尔墨斯正站在君王身侧。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
赫尔墨斯——身为灵魂引路之神。[r]
对珀耳塞福涅而言算是同父异母的兄长。在人间时也曾打过几次照面。[p]

[_tb_end_text]

[tb_start_text mode=1 ]
#赫尔墨斯
「好久不见，珀耳塞福涅」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_bisho_eyeA.png"  mouth="Per_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「好久不见，赫尔墨斯。来出差的吗？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#赫尔墨斯
「是啊。奉我们父神宙斯大人的命令而来」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「父亲大人他……？」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_kusho_eyeA.png"  mouth="Her_p_kusho_mouthA.png"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「珀耳塞福涅，得墨忒耳大人对你降临冥界之事大为震怒」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_magao_eyeA.png"  mouth="Her_p_magao_mouthA.png"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「她抛下农耕神职闭门不出。[r]
不仅拒绝响应宙斯大人的召唤，也不与其他诸神往来」[p]
「谷物枯萎，人类面临饥荒。[r]
结果导致凡人供品减少，宙斯大人正焦头烂额」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_magao_eyeB.png"  mouth="Per_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「母亲大人竟然…」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
父亲宙斯果然没向生母得墨忒耳提过她的婚事。[p]
母神发怒也是理所当然。[r]
连工作狂母亲都擅离职守，事态可见一斑。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#赫尔墨斯
「因此宙斯大人决定将你送回得墨忒耳大人身边。[r]
为平息丰收女神的怒火」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「诶」[p]
「要我回地上？」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_kusho_eyeA.png"  mouth="Her_p_magao_mouthA.png"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「哈迪斯大人，虽难以启齿…但的确如此…」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「宙斯的决定我已明了」[p]

[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_magao_eyeA.png"  mouth="Per_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「哈迪斯大人」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「珀耳塞福涅也曾思念母亲。妳该回到母亲身边」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_magao_eyeA.png"  mouth="Her_p_magao_mouthA.png"  ]
[tb_start_text mode=1 ]
#哈迪斯
「赫尔墨斯，能请你先行去备马吗」[p]
「希望让王妃与我独处片刻」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_bisho_eyeA.png"  mouth="Her_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「遵命」[p]
「在下会于水晶洞穴外恭候」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_hide_all  time="800"  wait="true"  ]
[tb_start_text mode=1 ]
#
待赫尔墨斯的脚步声彻底消失，冥王率先开口。[p]
[_tb_end_text]

[chara_show  name="ハデス"  time="500"  wait="false"  storage="chara/11/Hades_base.png"  width="720"  height="1350"  left="30"  top="-85"  reflect="false"  ]
[chara_part  name="ハデス"  time="500"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="true"  ]
[chara_show  name="ペルセポネ"  time="500"  wait="false"  storage="chara/10/Per_base.png"  width="720"  height="1350"  left="560"  top="-115"  reflect="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_bisho_eyeA.png"  mouth="Per_p_magao_mouthA.png"  wait="false"  ]
[wait  time="500"  ]
[tb_start_text mode=1 ]
#哈迪斯
「珀耳塞福涅」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「是」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「本王自认足以配得上成为妳的丈夫」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（哈迪斯大人要当我的丈夫……）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_bisho_eyeA.png"  mouth="Per_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「难道不该是"我配得上成为哈迪斯大人的妻子"吗？」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_kusho_eyeA.png"  mouth="Hades_p_kusho_mouthA.png"  ]
[tb_start_text mode=1 ]
#哈迪斯
「不。是本王配得上做妳的丈夫」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
冥王嘴角浮现出略带苦涩的微笑。[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「所以——这些终于成熟了些。愿意尝尝吗？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[tb_image_show  time="800"  storage="default/zakuro_.png"  width="300"  height="300"  x="500"  y="156"  _clickable_img=""  name="img_197"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#
冥王向前伸出手掌。掌心盛着石榴果实。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「这是……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「妳曾说过喜欢谷物和水果吧」[p]
「适合冥界土壤的作物不多——但我觉得这颗长得不错」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_magao_eyeB.png"  mouth="Per_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#
冥王将珀耳塞福涅的话都记在心上。[r]
正如他说「要准备礼物」，似乎为珀耳塞福涅在冥界尝试种植了水果。[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_bisho_eyeA.png"  mouth="Per_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#
石榴果实晶莹剔透，恍若宝石。质地看起来与地上的果实截然不同。[p]
[_tb_end_text]

[tb_image_hide  time="1000"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「感谢您。——那我开动了」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
冥王拈起一粒果实。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「过来」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
珀耳塞福涅走近冥王，轻启朱唇。[p]
[_tb_end_text]

[chara_hide_all  time="800"  wait="true"  ]
[bg  time="1200"  method="crossfade"  storage="cg1_2.png"  ]
[tb_start_text mode=1 ]
#
哈迪斯王将石榴果实滑入珀耳塞福涅口中。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
当冥王手指移开时，她细细咀嚼起来。[r]
石榴甘甜浓郁，与受母亲得墨忒耳神力滋养的果实同样多汁。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「——很好吃！」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「那就好」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[bg  time="800"  method="fadeIn"  storage="kuro.jpg"  cross="false"  ]
[bg  time="2000"  method="fadeIn"  storage="cg1.png"  cross="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「此刻能将这石榴送入妳口中，全因妳来到冥界」[p]
「珀耳塞福涅，请将我对妳的这份心意，珍藏于心」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（哈迪斯大人……）[p]
（哈迪斯大人是真心为我着想的啊）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「感谢您如此珍视我——」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[jump  storage="main6.ks"  target="*start"  ]
[s  ]
[tb_start_text mode=1 ]
[ruby text="ようや"][p]
[_tb_end_text]

