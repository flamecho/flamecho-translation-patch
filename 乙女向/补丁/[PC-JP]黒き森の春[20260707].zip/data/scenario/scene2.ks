﻿[_tb_system_call storage=system/_scene2.ks]

*scene2_start

[cm  ]
[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[tb_show_message_window  ]
[chara_hide_all  time="0"  wait="true"  ]
[stopbgm  time="1000"  fadeout="true"  ]
[bg  time="0"  method="crossfade"  storage="kuro.jpg"  ]
[tb_start_tyrano_code]
[position layer="message0" left="40" top="30" width="1200" height="660" margint="50" marginl="100" marginr="110" marginb="50"frame="none" opacity="220"]
[button name="role_button" role="save" graphic="../others/plugin/theme_kopanda_bth_08/image/button/save3.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/save2.png" x="1216" y="531" width="45" height="20"]
[button name="role_button" role="load" graphic="../others/plugin/theme_kopanda_bth_08/image/button/load3.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/load2.png"  x="1214" y="557" width="49" height="20"]
[button name="role_button" role="auto" graphic="../others/plugin/theme_kopanda_bth_08/image/button/auto3.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/auto2.png" x="1215" y="583" width="46" height="19"]
[button name="role_button" role="skip" graphic="../others/plugin/theme_kopanda_bth_08/image/button/skip3.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/skip2.png" x="1217" y="609" width="47" height="26"]
[button name="role_button" role="backlog" graphic="../others/plugin/theme_kopanda_bth_08/image/button/log3.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/log2.png" x="1220" y="634" width="39" height="27"]
[button name="role_button" role="sleepgame" graphic="../others/plugin/theme_kopanda_bth_08/image/button/sleep3.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/sleep2.png" storage="../others/plugin/theme_kopanda_bth_08/config.ks" x="1213" y="661" width="57" height="26"]
[button name="role_button" role="title" graphic="../others/plugin/theme_kopanda_bth_08/image/button/title3.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/title2.png" x="1215" y="691" width="48" height="21"]
[button name="role_button" role="window" graphic="../others/plugin/theme_kopanda_bth_08/image/button/close.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/close3.png" x="1262" y="520" width="13" height="13"]
[_tb_end_tyrano_code]

[mask_off  time="1000"  effect="fadeOut"  ]
[bg  time="1000"  method="crossfade"  storage="bak/aides_entra.jpg"  ]
[playbgm  volume="12"  time="1000"  loop="true"  storage="bgm/prologue_anima.mp3"  ]
[tb_start_text mode=1 ]
#
穿过黑暗的马车最终停在开阔的洞窟前。[l][r]
[r]
整个洞窟都被水晶覆盖着。[r]
寂静中伫立的冷冽光辉，稍稍缓解了我的恐惧与混乱。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
男人松开缰绳，下了马车。[l][r]
[r]
他站在两匹马前方，缓慢梳理着鬃毛根部。[r]
马儿们打了个响鼻。[l][r]
[r]
男人轻触马匹的鼻尖，再次抚过它们的脖颈。[l][r]
[r]
看这两匹马温驯的模样，这男人应该不算可怕。[r]
至少，我感觉自己不会被杀。[p]

[_tb_end_text]

[tb_start_text mode=1 ]
#
安抚马匹十几秒后，男人将视线转向斜后方。[l][r]
[r]
不知何时出现了。[r]
疑似侍从的人上前接过男人手中的缰绳。[l][r]
[r]
直到这时，男人才终于转向我。[p]
[_tb_end_text]

[mask  time="600"  effect="fadeIn"  color="0x000000"  ]
[tb_start_tyrano_code]
[position layer="message0" width="1280" height="220" top="505" left="0"]
[position layer="message0" frame="../others/plugin/theme_kopanda_bth_08/image/frame_message.png" margint="60" marginl="120" marginr="140" marginb="50" opacity="220" page="fore"]
[_tb_end_tyrano_code]

[tb_start_tyrano_code]
[button name="role_button" role="save" graphic="../others/plugin/theme_kopanda_bth_08/image/button/save.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/save2.png" x="1216" y="531" width="45" height="20"]
[button name="role_button" role="load" graphic="../others/plugin/theme_kopanda_bth_08/image/button/load.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/load2.png"  x="1214" y="557" width="49" height="20"]
[button name="role_button" role="auto" graphic="../others/plugin/theme_kopanda_bth_08/image/button/auto.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/auto2.png" x="1215" y="583" width="46" height="19"]
[button name="role_button" role="skip" graphic="../others/plugin/theme_kopanda_bth_08/image/button/skip.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/skip2.png" x="1217" y="609" width="47" height="26"]
[button name="role_button" role="backlog" graphic="../others/plugin/theme_kopanda_bth_08/image/button/log.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/log2.png" x="1220" y="634" width="39" height="27"]
[button name="role_button" role="sleepgame" graphic="../others/plugin/theme_kopanda_bth_08/image/button/sleep.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/sleep2.png" storage="../others/plugin/theme_kopanda_bth_08/config.ks" x="1213" y="661" width="57" height="26"]
[button name="role_button" role="title" graphic="../others/plugin/theme_kopanda_bth_08/image/button/title.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/title2.png" x="1215" y="691" width="48" height="21"]
[button name="role_button" role="window" graphic="../others/plugin/theme_kopanda_bth_08/image/button/close.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/close.png" x="1262" y="520" width="13" height="13"]
[_tb_end_tyrano_code]

[mask_off  time="800"  effect="fadeOut"  ]
[chara_show  name="ハデス"  time="500"  wait="false"  storage="chara/11/Hades_base.png"  width="752"  height="1410"  left="280"  top="-90"  reflect="false"  ]
[chara_part  name="ハデス"  time="500"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="true"  ]
[wait  time="200"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「唔……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
如同被他的目光钉住般，我浑身僵硬。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#男子
「……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
男人无声地向我伸出手。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（是要扶我下马车...吗）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
我迟疑着。他的手依旧悬在空中。[p]
在尴尬的沉默中，我缓缓握住那只手。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
与拽我上车时的粗暴截然不同，[r]
男人并没有将我硬拖下马车。[r]
他支撑着我，直到我的双脚完全着地。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
见我下了车，马匹便拉着车离开了原地。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
男人松开抓住我的手，衣袍翻飞。[p]
[_tb_end_text]

[chara_hide  name="ハデス"  time="600"  wait="false"  pos_mode="false"  ]
[tb_start_text mode=1 ]
#
似乎在说「跟我来」。[r]
我跟着男人向洞穴深处走去。[p]
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[bg  time="0"  method="crossfade"  storage="kuro.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#
洞穴直通冥宫。[p]
[_tb_end_text]

[bg  time="1000"  method="crossfade"  storage="bak/aides_hall.jpg"  ]
[tb_start_text mode=1 ]
#
冥宫内里广阔开阔。[r]
入口处可见喷泉与零星植物。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
男人停住脚步，回头看我。[p]
[_tb_end_text]

[chara_show  name="男性"  time="500"  wait="false"  storage="chara/11/Hades_base.png"  width="752"  height="1410"  left="280"  top="-90"  reflect="false"  ]
[chara_part  name="男性"  time="500"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="true"  ]
[wait  time="600"  ]
[tb_start_text mode=1 ]
#男子
「从今日起，此馆便是你的居所。尽管放松生活」[p]

[_tb_end_text]

[tb_start_text mode=1 ]
#
我哑然失声。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（这里——竟是我的居所？）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
一时难以置信。[r]
但男子也不像在说谎。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#男子
「更衣吧」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「诶？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
理解跟不上事态，我又问了一遍。[r]
但男人没有回答我，消失在了右侧通道。[p]
[_tb_end_text]

[chara_hide  name="男性"  time="800"  wait="false"  pos_mode="true"  ]
[tb_start_text mode=1 ]
#？？？
「珀耳塞福涅大人，请随我来」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
身后传来女声。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
转身发现数名女性站在那里。[r]
都穿着同款衣袍。看来是冥宫的侍女——大概吧。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「那个」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
若是侍女说不定能交谈。我鼓起勇气提问。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「请教我，此处是何地？[r]
方才那位男子究竟是何人？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
侍女们疑惑地歪着头。但并未无视我的问题。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#侍女
「此处乃冥界之王哈迪斯大人的宫殿」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「哈迪斯大人的宫殿……那也就是说——」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#侍女
「是的。带走珀耳塞福涅大人的，正是我们的王」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（那位竟是哈迪斯叔父……）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#侍女
「来吧珀耳塞福涅大人，请随我。[r]
容我等为您更衣」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「啊……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[bg  time="1000"  method="crossfade"  storage="kuro.jpg"  ]
[tb_start_text mode=1 ]
#
在侍女们催促下，我走向左侧通道。[r]
在引导的房间换好衣服。[p]
[_tb_end_text]

[mask  time="600"  effect="fadeIn"  color="0x000000"  ]
[bg  time="0"  method="crossfade"  storage="bak/aides_hall.jpg"  ]
[chara_show  name="ハデス"  time="0"  wait="false"  storage="chara/11/Hades_base.png"  width="752"  height="1410"  left="280"  top="-90"  reflect="false"  ]
[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="true"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#
返回入口时，那个男人——哈迪斯叔叔站在那里。[r]
是在等我吗。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
王看着换装后的我，微微颔首。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「很衬你」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「多谢……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
备好的衣裳用上等布料制成。[r]
款式也与王服相似。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
看来我似乎受到欢迎。这点我明白了。[r]
但为何被带来这里，仍旧不明就里。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「哈迪斯——叔父大人」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
我战战兢兢地开口。[p]
王面不改色地注视着我。[r]
他是'哈迪斯叔叔'这点应该没错。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「可以请教您一个问题吗」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
哈迪斯叔叔眨眼示意。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「为什么我会被带到这——冥界来呢？」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_odoroki_eyeA.png"  mouth="Hades_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#
我本以为自己只是单纯地就现状提出疑问。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
但对我的问题，哈迪斯叔叔瞪大了眼睛。[r]
这是从未改换表情的王首次显露的神色。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「你没听说？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
听完哈迪斯叔叔的回答，我陷入困惑。[p]
难不成母亲教导过的事里[r]
有我漏听或遗忘的内容吗。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
——不，无论是冥界还是哈迪斯叔叔，都不曾听母亲和精灵们提起过[r]
一次都没有。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「那个……好的」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
除此之外别无解释。[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
哈迪斯叔叔就此闭口不言。[r]
瞪大的眼睛不知何时恢复了原状。[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「那个……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「宙斯指定你为冥界王妃，我接受了这个安排」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「诶……？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
如同被重锤击中头颅。[r]
强烈冲击摇撼着我，思考停滞了。[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「……」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「看来真的不知情……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
哈迪斯叔叔简短地只说了一句。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
宙斯父王决定了我的婚事。这事本身不足为奇。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
震撼我的是父王竟未告知我——恐怕也未告知母亲[r]
就推进了这门亲事。[p]
如果母亲知道这门婚事的话，一定会告诉我的。[r]
我要嫁的是怎样的男人？嫁过去后我该做什么才好？[p]
如果是母亲的话，一定会为我着想，风风光光地举办婚礼。[r]
让那天成为最辉煌的一天。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
可父亲却认可了这种形式的婚事。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（居然这样——把我当成棋子般……）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
胸口传来剧烈绞痛。[r]
滚烫的泪水扑簌簌从双眼涌出。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
哈迪斯叔叔，什么也没说。[r]
但既没有出言安慰，也没把我留在原地径自离去。[p]
叔叔只是静静地注视着我。[p]
[_tb_end_text]

[jump  storage="scene3.ks"  target="*scene3_start"  ]
[s  ]
[tb_start_text mode=1 ]
[ruby text="ようや"][p]
[_tb_end_text]

