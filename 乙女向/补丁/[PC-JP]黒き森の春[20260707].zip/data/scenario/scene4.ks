﻿[_tb_system_call storage=system/_scene4.ks]

[playbgm  volume="15"  time="1000"  loop="true"  storage="bgm/hades_off.mp3"  ]
*scene4_start

[cm  ]
[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[tb_show_message_window  ]
[chara_hide_all  time="0"  wait="true"  ]
[bg  time="0"  method="crossfade"  storage="kuro.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[bg  time="1000"  method="crossfade"  storage="bak/popula2.jpg"  ]
[tb_start_text mode=1 ]
#
从那天起，我每天都去森林。[p]
刻耳柏洛斯趴在洞穴里等我出来。[p]
呼唤它时就会慢吞吞站起来，配合我的步调同行。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
每当我想深入森林，刻耳柏洛斯就会拽住我的衣角。[p]
在刻耳柏洛斯的守护下，我时而抚摸树木，时而采摘花朵。[p]
编花环时总会变换着形状，编出三个。[r]
然后挂在刻耳柏洛斯脖子上。[p]
[_tb_end_text]

[chara_show  name="ケルベロス"  time="500"  wait="true"  storage="chara/16/Cerberus.png"  width="620"  height="1163"  left="160"  top="50"  reflect="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「呵呵，真可爱。很适合你呢」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
最初它还会疑惑地歪头，[r]
最近只要我一呼唤，就会主动低下头来。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「在地上时，我也常这样编花环。[r]
编得好的就和精灵们交换，或是送给母神……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「好想见母神啊……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
只有在刻耳柏洛斯面前，她才能吐露真心。[r]
双眼经常止不住地落下泪来。[p]
整片森林也莫名笼罩在忧郁的青灰色中。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「我知道哈迪斯大人待我很好。[r]
可还是会寂寞，还是会不明白为什么……」[p]
「为什么偏偏是我呢？[r]
父神为什么连一句话都不曾对我说？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
当然，刻耳柏洛斯不会给我任何回应。[r]
只是在我哭泣时，常常把身体紧贴过来。[p]
感受着刻耳柏洛斯的体温，她的心情便能平静下来。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「谢谢，刻耳柏洛斯真温柔呢」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「是不是觉得我很不懂事？像个小孩子？」[p]
「没办法呀。我自幼就深得母神宠爱。[r]
要是刻耳柏洛斯突然被带离哈迪斯大人身边，也会伤心的吧？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「啊，不过如果是你的话，应该能自己跑回叔叔那里吧。[r]
要是我也有刻耳柏洛斯这样的力量就好了」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
其实就算力量再强，恐怕也难以离开冥界。[r]
既定之事，终究难以颠覆。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「可若是拥有力量——至少最初就不会被当成局外人了吧。[r]
说不定还能反抗这样的命运」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「虽然都是些如果当初的假设罢了」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
就这样，我在黑杨树之森倾吐着悲伤与寂寞。[p]
虽说事态并未因此发生什么改变，[r]
但至少不用在冥宫里哭得狼狈不堪了。[p]
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[bg  time="0"  method="crossfade"  storage="kuro.jpg"  ]
[chara_hide_all  time="0"  wait="true"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[bg  time="1000"  method="crossfade"  storage="bak/aides_entra.jpg"  ]
[tb_start_text mode=1 ]
#
那天穿过水晶洞穴后，我返回冥宫。[p]
[_tb_end_text]

[chara_show  name="ケルベロス"  time="500"  wait="true"  storage="chara/16/Cerberus.png"  width="620"  height="1163"  left="160"  top="50"  reflect="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「谢谢，刻耳柏洛斯。下次见」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_hide  name="ケルベロス"  time="600"  wait="false"  pos_mode="false"  ]
[tb_start_text mode=1 ]
#
和刻耳柏洛斯道别后，我踏上归途。[p]
[_tb_end_text]

[bg  time="600"  method="crossfade"  storage="kuro.jpg"  ]
[bg  time="1000"  method="crossfade"  storage="bak/aides_hall.jpg"  ]
[tb_start_text mode=1 ]
#
在门厅看见了哈迪斯叔叔的身影。[r]
想必如往常般在等候我归来。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
正要出声打招呼时，我却停下了脚步。[r]
叔叔似乎正在和某人交谈。[p]
虽然被叔叔挡着看不见脸，但能辨认出暗色羽翼。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（是死神塔纳托斯大人……）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
塔纳托斯神乃是夜之女神倪克斯大人的孩子。[r]
据说居住在那幽冥深处——黑杨树之森的尽头。[p]
若说引领英雄与诸神眷属之魂前往冥界是赫尔墨斯的职责，[r]
那么回收并押送凡人与罪人灵魂的，便是塔纳托斯神了。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
我不由得躲到了柱子的阴影里。[p]
虽并无冒犯之意，却终究做不到堂堂正正地行礼问候。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#塔纳托斯
「——珀耳塞福涅大人似乎常去黑杨树之森呢。[r]
来的路上正好瞧见」[p]
「是否该让王妃更清楚自己的身份？[r]
长此以往只会徒增陛下的负担」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「唔……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
这份自知之明——哈迪斯叔父大人的负担。[r]
塔纳托斯神的话语沉甸甸地压在我心头。[p]
我甚至不敢细听叔父大人会如何回应。[r]
我蜷缩身体，用双臂紧紧抱住自己。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「眼下正让她慢慢熟悉冥界的规矩」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
叔父大人平静地答道。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「王妃已在尽力。[r]
她正用双脚丈量冥土，以切身感受这片疆域」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「！」[p]
（哈迪斯叔父大人，居然会这样对我说……）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#塔纳托斯
「话虽如此——」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「刻耳柏洛斯也中意王妃。[r]
纵使是奉我之命，能驯服那家伙的，也只有王妃这般品性的人」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#塔纳托斯
「……是啊。我觉得刻耳柏洛斯很听话」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「你的不安我也并非不能理解。[r]
但我的工作量本身与先前相比并无太大变化。[r]
暂时还是打算维持现状」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#塔纳托斯
「明白了。既然王都说到这个份上」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
塔纳托斯神展开双翼，朝外飞去。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
我茫然凝望着那道暗影消逝在青灰色的天空。[r]
倏地，哈迪斯叔父大人转向我这边。[p]
[_tb_end_text]

[chara_show  name="ハデス"  time="500"  wait="false"  storage="chara/11/Hades_base.png"  width="752"  height="1410"  left="280"  top="-90"  reflect="false"  ]
[chara_part  name="ハデス"  time="500"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="true"  ]
[wait  time="500"  ]
[tb_start_text mode=1 ]
#哈迪斯
「可以出来了」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
叔父大人似乎早已看穿我的藏身之处。[r]
我缓缓踏出脚步。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「我回来了……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
我低声问候道。[r]
我没能正眼看叔父大人的脸。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「森林景象如何」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「咦？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
我像被弹开般猛地抬头。[p]
哈迪斯叔父大人的视线与我的相撞。[r]
叔父大人正等待我的回答。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「那个……和往常没什么不同。[r]
整片森林都泛着蓝光，像是沐浴着月光之夜」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「是吗」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
对话在此中断。[p]
我心焦如焚。[r]
叔父大人对我前往森林的事持乐观态度。[r]
我觉得必须给出配得上这份信任的解释。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
可越是着急，脑子里就越是一片空白。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（怎么办）[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#
唯有窝囊感不断加剧。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「……」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「要不要——吃点东西？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「诶」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
我猛地反问道。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「吃......吃什么？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「来到冥界后，你一直没进食吧。[r]
讨厌这里的食物？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「不，不是这样……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「那么，喜欢什么」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
哈迪斯大人用严肃的目光问道。[p]
叔父既是神明，应该明白我即便不吃喝也[r]
不会有什么问题的。[p]
尽管如此还要提起这些事，[r]
或许是想帮我分散注意力吧。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
这份温柔让我的心情也稍稍放松下来。[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「是啊……果然还是更喜欢谷物和水果。[r]
经过母亲大人祝福的农作物都非常美味呢」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「……」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#
哈迪斯叔父沉思了几秒，随后点了点头。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「明白了。我会准备」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（要给我准备吗！？）[p]
「谢谢您」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「是啊」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「说起来，你好像经常送花环给刻耳柏洛斯」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「啊，是的」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「被你这样疼爱，那家伙也很开心。[r]
它多数时候令人畏惧，几乎没有能亲近的对象。希望你能好好待它」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（原来如此……明明是那么乖巧的孩子）[p]
「好的。当然愿意」[p]
「我给那三个头分别准备了不同的花环。[r]
虽然都长着威风凛凛的脸，但个性其实各不相同呢」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「不过它们都很聪明对吧？[r]
有次把常戴的花环换给别的头戴，结果跟我闹脾气了……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「刻耳柏洛斯也会闹脾气么」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「这说明它们相当中意你啊」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「我很高兴」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「想必是因为你的心灵纯净澄澈吧」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「那个……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（叔父大人似乎高估了我的能力[r]
我的心根本不够澄澈。总是充满悲伤情绪……）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
但我不敢向哈迪斯叔父大人坦白真实想法。[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（至少，在这里我能帮上什么忙吗）[p]
「叔父大人，若有需要我做的事，我愿意学习」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「……」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「甚好」[p]
「慢慢适应即可。你存在于此本身就有意义」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（居然还为我考虑……叔父大人实在太温柔了）[p]
「好的……谢谢您」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
虽然情绪还未能完全平复。[r]
但隐约觉得，或许该为哈迪斯叔父大人做些力所能及的事。[p]
[_tb_end_text]

[jump  storage="scene5.ks"  target="*scene5_start"  ]
[s  ]
[tb_start_text mode=1 ]
[ruby text="ようや"][p]
[_tb_end_text]

