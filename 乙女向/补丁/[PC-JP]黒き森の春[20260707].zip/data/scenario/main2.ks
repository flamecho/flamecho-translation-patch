﻿[_tb_system_call storage=system/_main2.ks]

*start

[cm  ]
[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[tb_show_message_window  ]
[chara_hide_all  time="0"  wait="true"  ]
[stopbgm  time="1000"  fadeout="true"  ]
[bg  time="0"  method="crossfade"  storage="bak/aides_entra.jpg"  ]
[tb_start_tyrano_code]
[position layer="message0" left="40" top="30" width="1200" height="660" margint="50" marginl="100" marginr="110" marginb="50"frame="none" opacity="220"]
[button name="role_button" role="save" graphic="../others/plugin/theme_kopanda_bth_08/image/button/save3.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/save2.png" x="1216" y="531" width="45" height="20"]
[button name="role_button" role="load" graphic="../others/plugin/theme_kopanda_bth_08/image/button/load3.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/load2.png"  x="1214" y="557" width="49" height="20"]
[button name="role_button" role="auto" graphic="../others/plugin/theme_kopanda_bth_08/image/button/auto3.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/auto2.png" x="1215" y="583" width="46" height="19"]
[button name="role_button" role="skip" graphic="../others/plugin/theme_kopanda_bth_08/image/button/skip3.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/skip2.png" x="1217" y="609" width="47" height="26"]
[button name="role_button" role="backlog" graphic="../others/plugin/theme_kopanda_bth_08/image/button/log3.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/log2.png" x="1220" y="634" width="39" height="27"]
[button name="role_button" role="sleepgame" graphic="../others/plugin/theme_kopanda_bth_08/image/button/sleep3.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/sleep2.png" storage="../others/plugin/theme_kopanda_bth_08/config.ks" x="1213" y="661" width="57" height="26"]
[button name="role_button" role="title" graphic="../others/plugin/theme_kopanda_bth_08/image/button/title3.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/title2.png" x="1215" y="691" width="48" height="21"]
[button name="role_button" role="window" graphic="../others/plugin/theme_kopanda_bth_08/image/button/close.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/close3.png" x="1262" y="520" width="13" height="13"]
[_tb_end_tyrano_code]

[mask_off  time="1500"  effect="fadeOut"  ]
[playbgm  volume="12"  time="1000"  loop="true"  storage="bgm/prologue_anima.mp3"  ]
[tb_start_text mode=1 ]
#
马车穿透黑暗停在水晶洞窟前。[l][r]
[r]
整座洞窟覆满璀璨水晶。[r]
寂静中闪烁的冷光，稍稍缓解了她的恐惧与混乱。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
男子松开缰绳跃下马车。[l][r]
[r]
他站在两匹马前，缓缓抚过鬃毛根部。[r]
马匹喷着鼻息，朝他仰起鼻子。[l][r]
[r]
男子轻触马鼻，再次抚摸脖颈。[l][r]
[r]
从两匹马驯服的样子来看，这男子似乎并非凶恶之徒。[r]
至少她感觉不会被杀。[p]

[_tb_end_text]

[tb_start_text mode=1 ]
#
打理马匹十余秒后，男子斜眼向后瞟去。[l][r]
[r]
不知何时出现的[r]
疑似随从者上前接过缰绳。[l][r]
[r]
这时男子终于转头看向珀耳塞福涅。[p]
[_tb_end_text]

[mask  time="600"  effect="fadeIn"  color="0x000000"  ]
[tb_start_tyrano_code]
[position layer="message0" width="1280" height="220" top="505" left="0"]
[position layer="message0" frame="../others/plugin/theme_kopanda_bth_08/image/frame_message.png" margint="60" marginl="120" marginr="140" marginb="50" opacity="220" page="fore"]
[_tb_end_tyrano_code]

[tb_start_tyrano_code]
[button name="role_button" role="save" graphic="../others/plugin/theme_kopanda_bth_08/image/button/save.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/save2.png" x="1216" y="531" width="45" height="20"]
[button name="role_button" role="load" graphic="../others/plugin/theme_kopanda_bth_08/image/button/load.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/load2.png"  x="1214" y="557" width="49" height="20"]
[button name="role_button" role="auto" graphic="../others/plugin/theme_kopanda_bth_08/image/button/auto.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/auto2.png" x="1215" y="583" width="46" height="19"]
[button name="role_button" role="skip" graphic="../others/plugin/theme_kopanda_bth_08/image/button/skip.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/skip2.png" x="1217" y="609" width="47" height="26"]
[button name="role_button" role="backlog" graphic="../others/plugin/theme_kopanda_bth_08/image/button/log.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/log2.png" x="1220" y="634" width="39" height="27"]
[button name="role_button" role="sleepgame" graphic="../others/plugin/theme_kopanda_bth_08/image/button/sleep.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/sleep2.png" storage="../others/plugin/theme_kopanda_bth_08/config.ks" x="1213" y="661" width="57" height="26"]
[button name="role_button" role="title" graphic="../others/plugin/theme_kopanda_bth_08/image/button/title.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/title2.png" x="1215" y="691" width="48" height="21"]
[button name="role_button" role="window" graphic="../others/plugin/theme_kopanda_bth_08/image/button/close.png" enterimg="../others/plugin/theme_kopanda_bth_08/image/button/close.png" x="1262" y="520" width="13" height="13"]
[_tb_end_tyrano_code]

[mask_off  time="800"  effect="fadeOut"  ]
[chara_show  name="ハデス"  time="500"  wait="false"  storage="chara/11/Hades_base.png"  width="720"  height="1350"  left="30"  top="-85"  reflect="false"  ]
[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[chara_show  name="ペルセポネ"  time="500"  wait="false"  storage="chara/10/kore_base.png"  width="720"  height="1350"  left="560"  top="-115"  reflect="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_naki_mouthA.png"  wait="false"  ]
[wait  time="300"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「唔……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
少女身体僵直，仿佛被目光钉住。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#男子
「……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
沉默着向她伸出手。[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（是要扶我下马车...吗）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_magao_eyeA.png"  mouth="Per_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#
珀耳塞福涅犹豫不决。男子的目光始终凝视着她。[p]
她难堪地慢慢握住那只手。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
与强行掳人时截然不同[r]
男子并未粗暴地拽她下车。[r]
他稳稳托着，直到少女双足触地。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
珀耳塞福涅刚下马车，马匹便拉着车离开了。[p]
[_tb_end_text]

[chara_hide  name="ハデス"  time="600"  wait="false"  pos_mode="false"  ]
[tb_start_text mode=1 ]
#
男子松开珀耳塞福涅的手，衣袍翻飞。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
看口型似乎在说「跟我来」。[r]
珀耳塞福涅跟随男子，往洞穴深处走去。[p]
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[chara_hide  name="ペルセポネ"  time="0"  wait="false"  pos_mode="false"  ]
[bg  time="0"  method="crossfade"  storage="kuro.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#
洞穴直通冥宫。[p]
[_tb_end_text]

[bg  time="1000"  method="crossfade"  storage="bak/aides_hall.jpg"  ]
[tb_start_text mode=1 ]
#
冥宫内里广阔开阔。[r]
入口处可见喷泉与零星植物。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
男子停步回望珀耳塞福涅。[p]
[_tb_end_text]

[chara_show  name="男性"  time="500"  wait="false"  storage="chara/11/Hades_base.png"  width="720"  height="1350"  left="30"  top="-85"  reflect="false"  ]
[chara_part  name="男性"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[chara_show  name="ペルセポネ"  time="500"  wait="false"  storage="chara/10/kore_base.png"  width="720"  height="1350"  left="560"  top="-115"  reflect="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_magao_eyeA.png"  mouth="Per_p_magao_mouthA2.png"  wait="false"  ]
[wait  time="600"  ]
[tb_start_text mode=1 ]
#男子
「从今日起，此馆便是你的居所。尽管放松生活」[p]

[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#
珀耳塞福涅无言以对。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（这里——竟是我的居所？）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
一时难以置信。[r]
但男子也不像在说谎。[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#男子
「更衣吧」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「诶？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
珀耳塞福涅没反应过来，反问道。[r]
男子却未作答，消失在右侧通道。[p]
[_tb_end_text]

[chara_hide  name="男性"  time="600"  wait="false"  pos_mode="false"  ]
[tb_start_text mode=1 ]
#？？？
「珀耳塞福涅大人，请随我来」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
身后传来女声。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
回首看见数名女子站立。[r]
皆着统一服饰，似是冥宫侍女。[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_magao_eyeA.png"  mouth="Per_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「那个」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
若是侍女或可交谈。珀耳塞福涅鼓起勇气询问。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「请教我，此处是何地？[r]
方才那位男子究竟是何人？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
侍女们困惑地歪头。[r]
但并未无视她的提问。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#侍女
「此处乃冥界之王哈迪斯大人的宫殿」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「哈迪斯大人的宫殿……那也就是说——」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#侍女
「是。迎接您的那位正是吾等的王」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（那位竟是哈迪斯叔父……）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#侍女
「来吧珀耳塞福涅大人，请随我。[r]
容我等为您更衣」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_magao_eyeA.png"  mouth="Per_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「啊……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[chara_hide  name="ペルセポネ"  time="0"  wait="false"  pos_mode="false"  ]
[bg  time="0"  method="crossfade"  storage="kuro.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#
在侍女催促下，珀耳塞福涅走进左侧通道。[r]
在引导的房间里更换了衣裳。[p]
[_tb_end_text]

[bg  time="1000"  method="crossfade"  storage="bak/aides_hall.jpg"  ]
[chara_show  name="ハデス"  time="500"  wait="false"  storage="chara/11/Hades_base.png"  width="720"  height="1350"  left="30"  top="-85"  reflect="false"  ]
[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[chara_show  name="ペルセポネ"  time="500"  wait="false"  storage="chara/10/Per_base.png"  width="720"  height="1350"  left="560"  top="-115"  reflect="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_magao_mouthA.png"  wait="false"  ]
[wait  time="300"  ]
[tb_start_text mode=1 ]
#
重返入口时，男子——哈迪斯王正伫立等候。[r]
像是专程等她。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
王打量着更衣后的珀耳塞福涅，微微颔首。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「很衬你」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「多谢……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
备好的衣裳用上等布料制成。[r]
款式也与王服相似。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
看来自己确实受礼遇，这点已明了。[r]
但被带来的缘由，依旧不甚了了。[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_magao_eyeA.png"  mouth="Per_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「哈迪斯——叔父大人」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
珀耳塞福涅试探性地开口。[p]
国王面不改色地注视着珀耳塞福涅。[r]
眼前这位显然就是「哈迪斯叔父大人」无疑。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「可以请教您一个问题吗」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
国王用眨眼表示许可。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「为什么我会被带到这——冥界来呢？」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_odoroki_eyeA.png"  mouth="Hades_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#
珀耳塞福涅本意只是想对现状提出单纯疑问。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
然而面对这个问题，哈迪斯却瞪大了眼睛。[r]
这位始终面无表情的君王，初次展露出情绪波动。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「你没听说？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
听到国王的回答，珀耳塞福涅困惑了。[p]
难道母亲教导过的内容里[r]
存在自己漏听或遗忘的部分吗？[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
——不，关于冥界也好，关于叔父神也罢[r]
珀耳塞福涅从未与母亲或精灵们讨论过。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「那个……好的」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
除此之外别无解释。[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
哈迪斯王就此缄口。[r]
方才睁大的双眼已恢复常态。[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「那个……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「宙斯指定你为冥界王妃，我接受了这个安排」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「诶……？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
仿佛被巨锤狠狠击中头颅。[r]
强烈的冲击撼动珀耳塞福涅，思考就此停滞。[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「……」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「看来真的不知情……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
王只是简短地说了这句。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
父亲擅自决定婚事本身并不令人惊讶。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
真正击垮珀耳塞福涅的是——父亲不仅瞒着她，恐怕连母亲也蒙在鼓里[r]
就这么推进了婚事。[p]
倘若母亲得墨忒耳知晓这门亲事，一定会提前告知。[r]
会告诉她未来夫婿的为人，嫁过去后该做些什么。[p]
以得墨忒耳的性格，定会为爱女风光大婚[r]
让那天成为最辉煌的日子。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
而父亲宙斯却认可了这般形式的婚姻。[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_naki_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（居然这样——把我当成棋子般……）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_naki_eyeA.png"  mouth="Per_p_naki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#
胸口传来剧烈绞痛。[r]
滚烫的泪水扑簌簌从双眼涌出。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
王沉默不语。[r]
既没有轻率出言安慰，也不曾撇下泪人儿[r]
径自离去。[p]
只是静静凝视着珀耳塞福涅。[p]
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="true"  ]
[mask_off  time="1500"  effect="fadeOut"  ]
[chara_show  name="ハデス"  time="500"  wait="false"  storage="chara/11/Hades_base.png"  width="752"  height="1410"  left="280"  top="-90"  reflect="false"  ]
[chara_part  name="ハデス"  time="500"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA2.png"  wait="true"  ]
[tb_start_text mode=1 ]
#哈迪斯
「……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
（原以为是宙斯在说话）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
（若是什么都不知情地来到这里 冥界定会显得阴森可怖吧）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
（——但此地乃亡魂平等安息之所[r]
既是宙斯与得墨忒耳之女 盼你终能明白这个道理）[p]
（为此 首要之事是让她喜欢上冥界吧）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
（年轻姑娘会喜欢的东西……）[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_kusho_eyeC.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「……想不出来」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_kusho_eyeB.png"  mouth="Hades_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
（还是直接问她为好）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
『哈迪斯——叔父大人』[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
（叔父大人——吗）[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeB.png"  mouth="Hades_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「看来 还有段距离」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[jump  storage="main3.ks"  target="*start"  ]
[s  ]
