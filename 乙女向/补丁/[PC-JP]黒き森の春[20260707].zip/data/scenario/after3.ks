﻿[_tb_system_call storage=system/_after3.ks]

[plugin name=auto_indent]

[plugin name="backlog"]

*start

[stopbgm  time="1000"  fadeout="true"  ]
[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[tb_ptext_hide  time="0"  ]
[tb_image_hide  time="0"  ]
[tb_show_message_window  ]
[bg  time="1000"  method="crossfade"  storage="kuro.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[bg  time="1000"  method="crossfade"  storage="bak/aides_hall.jpg"  ]
[playbgm  volume="15"  time="1000"  loop="true"  storage="bgm/hades_off.mp3"  ]
[chara_show  name="タナトス"  time="500"  wait="false"  storage="chara/15/Tanatos_base.png"  width="712"  height="1335"  left="30"  top="-72"  reflect="false"  ]
[chara_part  name="タナトス"  time="0"  eye="Tanatos_p_sibu_eyeA.png"  mouth="Tanatos_p_magao_mouthA2.png"  wait="false"  ]
[wait  time="300"  ]
[tb_start_text mode=1 ]
#塔纳托斯
「……」[p]

[_tb_end_text]

[tb_start_text mode=1 ]
#

[_tb_end_text]

[chara_show  name="ヘルメス"  time="500"  wait="false"  storage="chara/13/Hermes_base.png"  width="688"  height="1290"  left="600"  top="-80"  reflect="false"  ]
[chara_part  name="ヘルメス"  time="0"  eye="Her_p_bisho_eyeA.png"  mouth="Her_p_bisho_mouthA.png"  ]
[wait  time="500"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「哟，塔纳托斯」[p]
[_tb_end_text]

[chara_part  name="タナトス"  time="0"  eye="Tanatos_p_magao_eyeB.png"  mouth="Tanatos_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#塔纳托斯
赫尔墨斯[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#赫尔墨斯
「怎么了？脸色这么凝重」[p]
[_tb_end_text]

[chara_part  name="タナトス"  time="0"  eye="Tanatos_p_sibu_eyeC.png"  mouth="Tanatos_p_sibu_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#塔纳托斯
「嗯……」[p]
[_tb_end_text]

[chara_part  name="タナトス"  time="0"  eye="Tanatos_p_sibu_eyeA.png"  mouth="Tanatos_p_sibu_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#塔纳托斯
「王他……遇到些棘手状况」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_magao_eyeA.png"  mouth="Her_p_magao_mouthA.png"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「哈迪斯大人？发生什么了？」[p]
[_tb_end_text]

[chara_part  name="タナトス"  time="0"  eye="Tanatos_p_sibu_eyeA.png"  mouth="Tanatos_p_sibu_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#塔纳托斯
「最近完全不眠不休地工作」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_odoroki_eyeA.png"  mouth="Her_p_magao_mouthA.png"  ]
[tb_start_text mode=1 ]
#塔纳托斯
「勤于政务是王的可贵之处，但还是希望他能适度休息」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_magao_eyeA.png"  mouth="Her_p_magao_mouthA.png"  ]
[tb_start_text mode=1 ]
#塔纳托斯
「我在犹豫是否该召唤睡神」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_kusho_eyeA.png"  mouth="Her_p_kusho_mouthA.png"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「原来如此。若是你兄弟睡神的话，确实能让王获得安眠」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_bisho_eyeA.png"  mouth="Her_p_kusho_mouthA.png"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「珀耳塞福涅现在是在人间吧？」[p]
[_tb_end_text]

[chara_part  name="タナトス"  time="0"  eye="Tanatos_p_sibu_eyeA.png"  mouth="Tanatos_p_sibu_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#塔纳托斯
「是啊」[p]
[_tb_end_text]

[chara_part  name="タナトス"  time="0"  eye="Tanatos_p_sibu_eyeB.png"  mouth="Tanatos_p_sibu_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#塔纳托斯
「王妃在冥界时倒不会这样……[r]
可每次去人间都会如此」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_kusho_eyeA.png"  mouth="Her_p_kusho_mouthA.png"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「想必是感到寂寞了吧」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#塔纳托斯
「夫妻恩爱本是好事，但这样实在令人担忧」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#赫尔墨斯
「你的顾虑不无道理」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_magao_eyeA.png"  mouth="Her_p_magao_mouthA.png"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「不过即使召唤睡神，也解决不了根本问题」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_kusho_eyeA.png"  mouth="Her_p_kusho_mouthA.png"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「稍作休整后，哈迪斯大人又会开始工作」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#塔纳托斯
「确实如此」[p]
[_tb_end_text]

[chara_part  name="タナトス"  time="0"  eye="Tanatos_p_sibu_eyeC.png"  mouth="Tanatos_p_sibu_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#塔纳托斯
唉……[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="true"  ]
[bg  time="0"  method="crossfade"  storage="kuro.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[bg  time="1000"  method="crossfade"  storage="bak/olympos.jpg"  ]
[chara_show  name="ゼウス"  time="500"  wait="false"  storage="chara/14/Zeus_base.png"  width="752"  height="1410"  left="5"  top="-70"  reflect="false"  ]
[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_magao_eyeA.png"  mouth="Zeus_p_koma_mouthA.png"  ]
[chara_show  name="ヘルメス"  time="500"  wait="false"  storage="chara/13/Hermes_base.png"  width="736"  height="1380"  left="560"  top="-80"  reflect="false"  ]
[chara_part  name="ヘルメス"  time="0"  eye="Her_p_kusho_eyeA.png"  mouth="Her_p_kusho_mouthA.png"  ]
[wait  time="500"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「——于是冥界众人陷入了苦恼」[p]
[_tb_end_text]

[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_kusho_eyeA.png"  mouth="Zeus_p_koma_mouthA.png"  ]
[tb_start_text mode=1 ]
#宙斯
「真像兄长的作风」[p]
[_tb_end_text]

[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_magao_eyeB.png"  mouth="Zeus_p_magao_mouthA.png"  ]
[tb_start_text mode=1 ]
#宙斯
「但是——不休息终究不妥」[p]
「就算兄长无恙，部下们也会惶惶不安」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#赫尔墨斯
「您说得是」[p]
[_tb_end_text]

[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_bisho_eyeA.png"  mouth="Zeus_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#宙斯
「这事我来助一臂之力吧」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_bisho_eyeA.png"  mouth="Her_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「有您出手就放心了」[p]
[_tb_end_text]

[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_bisho_eyeB.png"  mouth="Zeus_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#宙斯
「毕竟兄长至今未曾有过任何风流韵事」[p]
[_tb_end_text]

[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_bisho_eyeA.png"  mouth="Zeus_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#宙斯
「洗耳恭听」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="true"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[chara_show  name="ゼウス"  time="500"  wait="false"  storage="chara/14/Zeus_base.png"  width="748"  height="1408"  left="570"  top="-70"  reflect="false"  ]
[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_bisho_eyeA.png"  mouth="Zeus_p_bisho_mouthA.png"  wait="false"  ]
[chara_show  name="ハデス"  time="500"  wait="false"  storage="chara/11/Hades_base.png"  width="752"  height="1410"  left="-5"  top="-90"  reflect="false"  ]
[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[wait  time="500"  ]
[tb_start_text mode=1 ]
#宙斯
「兄长。劳您亲自前来实在过意不去」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「无妨」[p]
[_tb_end_text]

[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_kusho_eyeA.png"  mouth="Zeus_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#宙斯
「听闻您废寝忘食地工作，冥界上下都很担心」[p]
[_tb_end_text]

[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_magao_eyeA.png"  mouth="Zeus_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#宙斯
「若有棘手难题不妨直言。[r]
冥界的事务与天界人间都息息相关」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「并无特别状况」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「只是闲来无事处理政务罢了」[p]
[_tb_end_text]

[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_bisho_eyeA.png"  mouth="Zeus_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#宙斯
「这样啊。既然无事便好」[p]
[_tb_end_text]

[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_kusho_eyeA.png"  mouth="Zeus_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#宙斯
「但除了公务竟无其他事可做……兄长未免太过认真」[p]
[_tb_end_text]

[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_bisho_eyeA.png"  mouth="Zeus_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#宙斯
「珀耳塞福涅现在正逗留在人间你姐姐那里吧？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「正是」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#宙斯
「听说你们在冥界生活得很融洽。我女儿很可爱吧？」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeB.png"  mouth="Hades_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「是啊。非常可爱」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「笑起来自不用说，吃惊或着急的表情也惹人怜爱」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeA.png"  mouth="Hades_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「感情很丰富吧。表情总是变来变去的」[p]
[_tb_end_text]

[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_bisho_eyeA.png"  mouth="Zeus_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#宙斯
「这点倒是像她母亲」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeB.png"  mouth="Hades_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「还有，发现我的时候，总会眼睛发亮地凑过来」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeC.png"  mouth="Hades_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「仰头拼命和我说话的样子，可爱得不得了。[r]
常常看得入神，连她说什么都没听见」[p]
[_tb_end_text]

[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_odoroki_eyeA.png"  mouth="Zeus_p_odoroki_mouthA.png"  wait="false"  ]
[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeA.png"  mouth="Hades_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「遇到难题时，蹙眉歪头的模样也令人疼惜」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_kusho_eyeC.png"  mouth="Hades_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「虽然绝不是存心要为难她，[r]
但有时会忍不住想看她困扰的表情。真是折磨人」[p]
[_tb_end_text]

[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_odoroki_eyeA.png"  mouth="Zeus_p_koma_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#宙斯
「嗯……」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_kusho_eyeA.png"  mouth="Hades_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「不过珀耳塞福涅从不会在我面前鼓起脸颊。[r]
明明对刻耳柏洛斯和赫尔墨斯就会展现更多表情。真令人羡慕」[p]
[_tb_end_text]

[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_magao_eyeA.png"  mouth="Zeus_p_koma_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#宙斯
「呃——你们相处融洽比什么都好」[p]
[_tb_end_text]

[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_koma_eyeB.png"  mouth="Zeus_p_koma_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#宙斯
「……这话题还要继续？」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_odoroki_eyeA.png"  mouth="Hades_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「才说了不到一成呢」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeA.png"  mouth="Hades_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「宙斯真是急性子」[p]
[_tb_end_text]

[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_koma_eyeC.png"  mouth="Zeus_p_koma_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#宙斯
「嗯……随你怎么说」[p]
[_tb_end_text]

[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_bisho_eyeA.png"  mouth="Zeus_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#宙斯
「要是那么想念珀耳塞福涅，去见她不就好了？」[p]
「若是兄长造访，姐姐想必也会欣然应允」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「因私事擅离冥界，断不可为」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_kusho_eyeC.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「况且……要是见了面，必定会更难分离」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_kusho_eyeA.png"  mouth="Zeus_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#宙斯
「原来如此」[p]
[_tb_end_text]

[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_bisho_eyeA.png"  mouth="Zeus_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#宙斯
「不过回程时顺路去看看，总可以吧？」[p]
[_tb_end_text]

[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_kusho_eyeB.png"  mouth="Zeus_p_bisho_mouthA.png"  wait="false"  ]
[chara_part  name="ハデス"  time="0"  eye="Hades_p_odoroki_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#宙斯
「若能顺便哄好姐姐，那就帮大忙了」[p]
[_tb_end_text]

[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_kusho_eyeA.png"  mouth="Zeus_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#宙斯
「让姐姐知道兄长珍视珀耳塞福涅，她也能安心」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeA.png"  mouth="Hades_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「知道了」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeB.png"  mouth="Hades_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「这份心意，我心领了」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="false"  ]
[bg  time="0"  method="crossfade"  storage="kuro.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[bg  time="1000"  method="crossfade"  storage="bak/ereusis.jpg"  ]
[chara_show  name="ペルセポネ"  time="500"  wait="false"  storage="chara/10/Per_base.png"  width="700"  height="1313"  left="550"  top="-105"  reflect="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_bisho_eyeA.png"  mouth="Per_p_bisho_mouthA2.png"  wait="false"  ]
[wait  time="500"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（母亲的神域总是绿意盎然）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeC.png"  mouth="Per_p_bisho_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（每次我来到地面，草木就会一齐发芽。[r]
像是欢迎我似的，真开心）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeB.png"  mouth="Per_p_kusho_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（冥界的植物和果实们，都还好吗）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeA.png"  mouth="Per_p_kusho_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（有哈迪斯大人在，冥界应该没问题。可还是忍不住担心）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_magao_eyeA.png"  mouth="Per_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（……）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeB.png"  mouth="Per_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（哈迪斯大人和刻耳柏洛斯，还有其他大家——都还好吗？）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_magao_eyeB.png"  mouth="Per_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（和母亲在一起很轻松，待着也舒服。可是……）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeC.png"  mouth="Per_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（没有大家在，总觉得有点寂寞……）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeB.png"  mouth="Per_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（哈迪斯大人和父亲不同，看起来不像是特别喜欢女性的类型）」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeA.png"  mouth="Per_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（毕竟是那么温柔又认真工作的人[r]
肯定有女性对哈迪斯大人心怀爱慕吧——）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeB.png"  mouth="Per_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（……）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_show  name="デメテル"  time="500"  wait="false"  storage="chara/12/Demeter_base1.png"  width="720"  height="1350"  left="50"  top="-120"  reflect="false"  ]
[chara_part  name="デメテル"  time="0"  eye="Demeter_p_bisho_eyeA.png"  mouth="Demeter_p_bisho_mouthA.png"  wait="false"  ]
[wait  time="300"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「科瑞」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeA.png"  mouth="Per_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「母亲大人」[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_kusho_eyeA.png"  mouth="Demeter_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「怎么了？看你愁眉不展的」[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_kusho_eyeB.png"  mouth="Demeter_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「是有什么烦心事吗？」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeA.png"  mouth="Per_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「什么烦心事呀。才没有呢」[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_bisho_eyeB.png"  mouth="Demeter_p_kusho_mouthA.png"  wait="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（——有了）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_magao_eyeA.png"  mouth="Per_p_odoroki_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（母亲大人和哈迪斯大人是姐弟。也许她知道些我不知道的事）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeA.png"  mouth="Per_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「那个啊，母亲大人。我想打听些哈迪斯大人的事」[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_odoroki_eyeA.png"  mouth="Demeter_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「哈迪斯？」[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_bisho_eyeA.png"  mouth="Demeter_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「啊，是在想哈迪斯啊。你们俩还是那么要好呢」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_bisho_eyeA.png"  mouth="Per_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「哈迪斯大人是深情又完美的存在啊。总是惦记着我」[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_bisho_eyeB.png"  mouth="Demeter_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「是啊。哈迪斯确实非常重视你」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeA.png"  mouth="Per_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「但正因为他是如此出色，我才有些担心」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeC.png"  mouth="Per_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「怕我不在的时候，会有其他女性向哈迪斯大人示爱……」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeA.png"  mouth="Per_p_magao_mouthA.png"  wait="false"  ]
[chara_part  name="デメテル"  time="0"  eye="Demeter_p_odoroki_eyeA.png"  mouth="Demeter_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「母亲大人从小时候起就认识哈迪斯大人了吧。[r]
这种事...发生过很多次吗？」[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_bisho_eyeB.png"  mouth="Demeter_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「我当是什么——呵呵，真是可爱的烦恼呢」[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_bisho_eyeA.png"  mouth="Demeter_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「这个嘛……[r]
关于哈迪斯的事，或许不必太担心」[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_bisho_eyeB.png"  mouth="Demeter_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「他并非会轻易接受感情的性子」[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_bisho_eyeA.png"  mouth="Demeter_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「那样的哈迪斯——虽说最初是宙斯擅自决定的婚事，但会答应娶你...[r]
科瑞，定是因为中意你啊」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「中意我——」[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_bisho_eyeB.png"  mouth="Demeter_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「所以放心吧。哈迪斯的心意，只系于你一人」[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_kusho_eyeA.png"  mouth="Demeter_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「正因不像某些主神那么轻浮，他一旦认准目标就会异常执着。[r]
那个孩子就是这样的神啊」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeB.png"  mouth="Per_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「执着……」[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_bisho_eyeB.png"  mouth="Demeter_p_kusho_mouthA.png"  wait="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_magao_eyeA.png"  mouth="Per_p_odoroki_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（虽然从没感觉哈迪斯大人对我有什么执着……）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeB.png"  mouth="Per_p_kusho_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（但既然身为哈迪斯大人姐姐的母亲大人都这么说……应该可以相信吧？）[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_bisho_eyeA.png"  mouth="Demeter_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「哎呀，说曹操曹操到」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「诶？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_hide_all  time="600"  wait="true"  ]
[wait  time="200"  ]
[chara_show  name="デメテル"  time="300"  wait="false"  storage="chara/12/Demeter_base1.png"  width="700"  height="1313"  left="-60"  top="-115"  reflect="false"  ]
[chara_part  name="デメテル"  time="0"  eye="Demeter_p_bisho_eyeA.png"  mouth="Demeter_p_kusho_mouthA.png"  wait="false"  ]
[chara_show  name="ハデス"  time="350"  wait="false"  storage="chara/11/Hades_base.png"  width="700"  height="1313"  left="700"  top="-78"  reflect="false"  ]
[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[chara_show  name="ペルセポネ"  time="300"  wait="false"  storage="chara/10/Per_base.png"  width="688"  height="1290"  left="320"  top="-100"  reflect="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA.png"  wait="false"  ]
[wait  time="65"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「哈迪斯大人！？」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeB.png"  mouth="Hades_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「久违了，珀耳塞福涅」[p]
「别来无恙」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「嗯……我一切都好」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeA.png"  mouth="Per_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「您这是？[r]
哈迪斯大人离开冥界来到地上可真是罕见」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeA.png"  mouth="Hades_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「宙斯召见。顺道路过」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeB.png"  mouth="Hades_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「想看看你的脸再走。——能见到真好」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「哈迪斯大人……」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeB.png"  mouth="Per_p_kusho_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（是专程绕路来见我的啊……）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#得墨忒耳
「好久不见，哈迪斯」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_bisho_eyeA.png"  mouth="Per_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「姐姐」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeB.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「姐姐也一切如常吗」[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_bisho_eyeB.png"  mouth="Demeter_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「嗯。这方水土甚好。粮食长势喜人」[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_bisho_eyeA.png"  mouth="Demeter_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「人类为神殿点燃灯火，我就能借这火焰与炉灶女神姐姐交谈」[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_bisho_eyeB.png"  mouth="Demeter_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「赫斯提亚她啊，可是为你和珀耳塞福涅的婚事高兴着呢。[r]
说愿炉火永远庇佑你们」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「是吗」[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_bisho_eyeA.png"  mouth="Demeter_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「科瑞，我得回去工作了」[p]
「你就和哈迪斯好好聊聊吧」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeA.png"  mouth="Per_p_egao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「好的。谢谢您，母神」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="true"  ]
[bg  time="0"  method="crossfade"  storage="bak/hanabatake.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[chara_show  name="ハデス"  time="500"  wait="false"  storage="chara/11/Hades_base.png"  width="720"  height="1350"  left="80"  top="-85"  reflect="false"  ]
[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeA.png"  mouth="Hades_p_bisho_mouthA.png"  wait="false"  ]
[chara_show  name="ペルセポネ"  time="500"  wait="false"  storage="chara/10/Per_base.png"  width="720"  height="1350"  left="510"  top="-115"  reflect="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_bisho_eyeA.png"  mouth="Per_p_bisho_mouthA.png"  ]
[wait  time="500"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「母神常驻神殿，倒是我时不时会来这里走走」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeC.png"  mouth="Per_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「和初次遇见哈迪斯大人的地方很像吧？」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeA.png"  mouth="Hades_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「是啊。真是片美丽的花田」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_bisho_eyeA.png"  mouth="Per_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「雅典娜大人和阿尔忒弥斯偶尔也会来玩。[r]
那时候我们总是聊个不停」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeB.png"  mouth="Hades_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「看来你过得安稳」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeA.png"  mouth="Per_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「但有时候也会想念冥界」[p]
「哈迪斯大人身体可好？刻耳柏洛斯呢？冥宫的大家呢？[r]
黑杨树之森怎样了？园里的植物呢？总惦记这些」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeA.png"  mouth="Hades_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「原来你还念着我们」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「当然了。无时无刻不在想」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeB.png"  mouth="Per_p_kusho_mouthA.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「既是父神的决定，我也无可奈何。[r]
只是觉得四季流转格外漫长……」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeB.png"  mouth="Hades_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「你能这般挂念便足够了」[p]
「连衣裳——也仍穿着冥界裁制的衣物」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeA.png"  mouth="Per_p_kusho_mouthA.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「我毕竟是冥界的王妃啊」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeB.png"  mouth="Per_p_kusho_mouthA.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「无论何时都想保持相称的模样」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「嗯。能配得上这称号的唯你一人」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeC.png"  mouth="Per_p_kusho_mouthA.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「是」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeB.png"  mouth="Per_p_kusho_mouthA2.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（好开心……心脏扑通扑通跳）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_bisho_eyeA.png"  mouth="Per_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「说来——初次遇见哈迪斯大人时见到的水仙花，[r]
就是冥界生长的品种对吧？」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeA.png"  mouth="Hades_p_kusho_mouthA.png"  wait="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeA.png"  mouth="Per_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「在人间也试着找过相似的，却始终寻不到」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeB.png"  mouth="Per_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「毕竟那种如矿石般的质感，只有冥界才能孕育呢」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeB.png"  mouth="Hades_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「——若有冥府之花相伴，你会欢喜么？」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeA.png"  mouth="Per_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「嗯。想必能稍解寂寥」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeB.png"  mouth="Per_p_kusho_mouthA2.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（真的只是一点点而已）[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeA.png"  mouth="Hades_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「那么，便将冥府之花赠予你吧」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA2.png"  ]
[tb_start_text mode=1 ]
#
[_tb_end_text]

[tb_image_show  time="1000"  storage="default/w_kanbotan.png"  width="167"  height="253"  x="577"  y="211"  _clickable_img=""  name="img_341"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（如同宝石堆叠而成——能感受到分量的花朵）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeB.png"  mouth="Per_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「美得让人屏息……」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeB.png"  mouth="Hades_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「可合心意？」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeC.png"  mouth="Per_p_egao_mouthA.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「嗯！非常感谢」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeA.png"  mouth="Per_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「这样就能比现在更多思念哈迪斯大人了」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_odoroki_eyeA.png"  mouth="Hades_p_odoroki_mouthA.png"  wait="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeB.png"  mouth="Per_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「好高兴……」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeA.png"  mouth="Hades_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「竟让你欢喜至此」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeB.png"  mouth="Hades_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「既然如此，你滞留人间的日子，我会持续赠花」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeA.png"  mouth="Per_p_bisho_mouthA.png"  ]
[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeA.png"  mouth="Hades_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「哪怕无法相见，也请时常念着我」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeC.png"  mouth="Per_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「是」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[tb_image_hide  time="800"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeA.png"  mouth="Per_p_bisho_mouthA.png"  ]
[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeB.png"  mouth="Hades_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「待回归冥界后，定要立刻开始培育花卉」[p]
「来得正好。刚被人说别总顾着工作呢」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「总顾着工作……？」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeA.png"  mouth="Per_p_odoroki_mouthA.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「哈迪斯大人——该不会，您又疏于休息了吧？」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「嗯？」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_kusho_eyeB.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「啊——这个嘛」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_fukure_eyeA.png"  mouth="Per_p_magao_mouthA2.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（唔……难道）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_fukure_eyeA.png"  mouth="Per_p_magao_mouthA.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「您有好好在休息吧？」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_kusho_eyeA.png"  mouth="Hades_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「嗯……没」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_fukure_eyeA.png"  mouth="Per_p_magao_mouthA2.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（看来——根本是在连轴转）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_fukure_eyeA.png"  mouth="Per_p_fukure_mouthA.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「嗯……」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_odoroki_eyeA.png"  mouth="Hades_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「！」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_fukure_eyeA.png"  mouth="Per_p_magao_mouthA.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「哈迪斯大人，专注工作固然可贵，但休息也是重要的职责」[p]
「请您务必好好休息」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeB.png"  mouth="Hades_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「啊……」[p]
「终于肯展露笑颜了」[p]
「你任何表情都惹人怜爱」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA2.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（啊！？）[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_kusho_eyeC.png"  mouth="Hades_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「难以忍受分离之苦……」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_kusho_eyeB.png"  mouth="Hades_p_kusho_mouthA.png"  wait="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeA.png"  mouth="Per_p_magao_mouthA.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「那个……」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeA.png"  mouth="Per_p_magao_mouthA2.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（在说什么呢……？）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_fukure_eyeA.png"  mouth="Per_p_magao_mouthA.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「——总之！请您工作要适可而止」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeA.png"  mouth="Per_p_kusho_mouthA.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「因为我很期待——哈迪斯大人送来的花」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeA.png"  mouth="Hades_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「知道了」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeA.png"  mouth="Per_p_kusho_mouthA2.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（希望栽培花朵，至少能让哈迪斯大人喘口气）[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeA.png"  mouth="Hades_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「让花开在这附近吧。发现时，能否唤我一声」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「？好的。不过……」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeB.png"  mouth="Hades_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「我要让花朵记住你的话语。[r]
这样纵使分离，也能传递思念」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_kusho_eyeB.png"  mouth="Hades_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「当渴望听见你的声音时，它会抚慰我心」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeC.png"  mouth="Per_p_kusho_mouthA.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「哇……真美妙」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeB.png"  mouth="Hades_p_kusho_mouthA.png"  wait="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeA.png"  mouth="Per_p_kusho_mouthA.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「也会把哈迪斯大人的声音，传递给我吧？」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeA.png"  mouth="Hades_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「你若期望，便这样做吧」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeC.png"  mouth="Per_p_egao_mouthA.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「请务必让我聆听！」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeB.png"  mouth="Per_p_kusho_mouthA.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「没想到在地上，也有能与哈迪斯大人相连的方法……[r]
真是百感交集」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeC.png"  mouth="Per_p_egao_mouthA.png"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「我会期待着哈迪斯大人的花！」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="true"  ]
[bg  time="0"  method="crossfade"  storage="kuro.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[bg  time="1000"  method="crossfade"  storage="bak/hanabatake.jpg"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（后来，我常去的花田里，每天都会绽放一朵冥府之花）[p]
（虽然与哈迪斯大人能交流的仅只言片语，但已足够）[p]
（哈迪斯大人始终牵挂着我。[r]
即便身处人间，他的思念也温柔包裹着我）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[wait  time="500"  ]
[tb_image_show  time="1000"  storage="default/end.png"  width="142"  height="67"  x="300"  y="155"  _clickable_img=""  ]
[wait  time="1500"  ]
[tb_image_hide  time="1000"  ]
[jump  storage="extras.ks"  target="*top"  ]
[s  ]
[tb_start_text mode=1 ]
[ruby text="ようや"][p]
[_tb_end_text]

[tb_start_text mode=1 ]
标题：联结我们的纽带[p]
[_tb_end_text]

