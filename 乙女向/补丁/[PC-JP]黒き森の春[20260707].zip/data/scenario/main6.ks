﻿[_tb_system_call storage=system/_main6.ks]

[playbgm  volume="15"  time="1000"  loop="true"  storage="bgm/hades_off.mp3"  ]
*start

[cm  ]
[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[tb_show_message_window  ]
[chara_hide_all  time="0"  wait="true"  ]
[bg  time="0"  method="crossfade"  storage="bak/aides_entra.jpg"  ]
[chara_show  name="ヘルメス"  time="0"  wait="false"  storage="chara/13/Hermes_base.png"  width="688"  height="1290"  left="320"  top="-84"  reflect="false"  ]
[chara_part  name="ヘルメス"  time="0"  eye="Her_p_bisho_eyeA.png"  mouth="Her_p_bisho_mouthA.png"  ]
[chara_show  name="ハデス"  time="0"  wait="false"  storage="chara/11/Hades_base.png"  width="700"  height="1313"  left="-40"  top="-78"  reflect="false"  ]
[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[chara_show  name="ペルセポネ"  time="0"  wait="false"  storage="chara/10/Per_base.png"  width="700"  height="1313"  left="690"  top="-105"  reflect="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_bisho_eyeA.png"  mouth="Per_p_bisho_mouthA.png"  wait="false"  ]
[mask_off  time="1500"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「马车已备好。上车吧」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「嗯，谢谢」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#赫尔墨斯
「冥王。容我们借用马匹与马车」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「是啊」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
冥界之王轻抚马车前的马匹。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「珀耳塞福涅就拜托了」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
马儿们轻声嘶鸣回应。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#赫尔墨斯
「那么，出发了」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
赫尔墨斯握紧缰绳挥动马鞭。[p]
[_tb_end_text]

[playse  volume="15"  time="1000"  buf="0"  storage="buki_muchi2.mp3"  ]
[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="true"  ]
[bg  time="0"  method="crossfade"  storage="kuro.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[stopse  time="0"  buf="0"  ]
[tb_start_text mode=1 ]
#
随着马匹开始奔驰，马车也随之启动。[r]
如同刺破黑暗般，笔直朝着天空疾驰而去。[p]
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[bg  time="0"  method="crossfade"  storage="kuro.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[bg  time="1000"  method="crossfade"  storage="bak/aides_entra.jpg"  ]
[chara_show  name="ハデス"  time="500"  wait="false"  storage="chara/11/Hades_base.png"  width="752"  height="1410"  left="320"  top="-90"  reflect="false"  ]
[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA2.png"  wait="false"  ]
[wait  time="500"  ]
[tb_start_text mode=1 ]
#哈迪斯
「……」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeB.png"  mouth="Hades_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
（马儿们是来到了地上吗……）[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
（据说得墨忒耳如今正在厄琉西斯。[r]
那是片有着平缓丘陵连绵的土地，能俯瞰面海的平原）[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_kusho_eyeA.png"  mouth="Hades_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
（但终究没法在冥界为她种植谷物……[r]
但愿在地上能尽情享用她喜爱的食物）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_show  name="ケルベロス"  time="600"  wait="true"  storage="chara/16/Cerberus.png"  width="620"  height="1163"  left="20"  top="130"  reflect="false"  ]
[wait  time="400"  ]
[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「刻耳柏洛斯」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
你也是来送别珀耳塞福涅的吗[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
刻耳柏洛斯垂下了脑袋。[r]
三颗头和蛇尾都显露出沮丧的模样。[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeB.png"  mouth="Hades_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
（这也不难理解。珀耳塞福涅向来疼爱刻耳柏洛斯）[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
不必如此消沉[p]
珀耳塞福涅终会回到冥界[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
三颗头和蛇尾一齐仰望着哈迪斯。[r]
那双如同石榴石般的赤红目光里，仍闪烁着不安。[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeA.png"  mouth="Hades_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
怎么？难道不信本王的话？[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeB.png"  mouth="Hades_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
她一定会回来。毕竟她吃下了我亲手栽种的石榴果实[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeA.png"  mouth="Hades_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
（尽管与母亲分离承受着痛苦，珀耳塞福涅却未曾抗拒我）[p]
（是她自己选择吃下那颗石榴）[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeB.png"  mouth="Hades_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
我相信她在冥界的日子，并非只有不快[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeC.png"  mouth="Hades_p_bisho_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
（珀耳塞福涅总是兴高采烈地与我交谈。[r]
无论多么琐碎的小事，她都会笑容满面地向我讲述当天的见闻）[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeA.png"  mouth="Hades_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
刻耳柏洛斯，你也很好地承担了支撑王妃心灵的责任[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeB.png"  mouth="Hades_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
不过是短暂分别。这段时间，我们只需如常工作便是[p]
安静等待王妃归来吧[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[bg  time="0"  method="crossfade"  storage="kuro.jpg"  ]
[chara_hide_all  time="0"  wait="true"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[bg  time="1000"  method="crossfade"  storage="bak/ereusis.jpg"  ]
[tb_start_text mode=1 ]
#
回到地面后，沿着海岸线越过数座山峦与峡谷。[r]
最终马车停在了丘陵地带的神殿前。[p]
[_tb_end_text]

[chara_show  name="ヘルメス"  time="500"  wait="false"  storage="chara/13/Hermes_base.png"  width="688"  height="1290"  left="700"  top="-84"  reflect="false"  ]
[chara_part  name="ヘルメス"  time="0"  eye="Her_p_bisho_eyeA.png"  mouth="Her_p_bisho_mouthA.png"  ]
[wait  time="500"  ]
[stopbgm  time="3000"  fadeout="true"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
我们到了[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#赫尔墨斯
这里就是得墨忒耳大人如今暂居之处[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_show  name="ペルセポネ"  time="500"  wait="false"  storage="chara/10/Per_base.png"  width="700"  height="1313"  left="350"  top="-105"  reflect="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA.png"  wait="false"  ]
[wait  time="500"  ]
[playbgm  volume="12"  time="1000"  loop="true"  storage="bgm/sleep_inwoods.mp3"  fadein="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
这片土地……[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_magao_eyeA.png"  mouth="Per_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#
珀耳塞福涅环顾四周。[p]
神殿被能够眺望海洋的丘陵与小山环绕。[r]
这里似乎与她昔日和母亲同住的地方相去甚远。[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeB.png"  mouth="Per_p_odoroki_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（母亲为了寻找我，竟然来到这样的地方……）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#？？？
科瑞……！[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
熟悉的声音如雨滴般洒落。[p]
[_tb_end_text]

[chara_show  name="デメテル"  time="500"  wait="false"  storage="chara/12/Dameter_base2.png"  width="720"  height="1350"  left="-40"  top="-120"  reflect="false"  ]
[chara_part  name="デメテル"  time="0"  eye="Demeter_p_odoroki_eyeA.png"  mouth="Demeter_p_odoroki_mouthA.png"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#
身披黑色衣袍的母亲得墨忒耳，双眼紧紧锁住了珀耳塞福涅。[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeB.png"  mouth="Per_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
母亲大人……！[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_hide  name="ペルセポネ"  time="500"  wait="true"  pos_mode="false"  ]
[tb_start_text mode=1 ]
#
珀耳塞福涅从马车上下来，奔向母神。[p]
[_tb_end_text]

[chara_show  name="ペルセポネ"  time="500"  wait="false"  storage="chara/10/Per_base.png"  width="700"  height="1313"  left="270"  top="-105"  reflect="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_naki_eyeA.png"  mouth="Per_p_naki_mouthA.png"  wait="false"  ]
[chara_part  name="デメテル"  time="0"  eye="Demeter_p_bisho_eyeA.png"  mouth="Demeter_p_bisho_mouthA.png"  ]
[wait  time="300"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「母亲大人，母亲大人……！」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#得墨忒耳
「啊，科瑞！我亲爱的女儿……！」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
得墨忒耳紧紧抱住珀耳塞福涅的身体，轻柔地梳理她的头发。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#得墨忒耳
「没想到那个宙斯竟然会同意把你送回来」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeB.png"  mouth="Per_p_odoroki_mouthA.png"  wait="false"  ]
[chara_part  name="デメテル"  time="200"  eye="Demeter_p_gekido_eyeA.png"  mouth="Demeter_p_magao_mouthA.png"  ]
[tb_start_text mode=1 ]
#
母亲狠狠瞪视着站在马车旁的赫尔墨斯。[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_kusho_eyeA.png"  mouth="Her_p_kusho_mouthA.png"  ]
[tb_start_text mode=1 ]
#
赫尔墨斯苦笑着耸了耸肩。[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeA.png"  mouth="Per_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「母亲大人」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
珀耳塞福涅依偎在母神怀里，左右摇头。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「赫尔墨斯只是奉父神之命，把我送回地上来。[r]
他没有任何错」[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="200"  eye="Demeter_p_bisho_eyeA.png"  mouth="Demeter_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「科瑞真是温柔啊。[r]
虽然我明白，但赫尔墨斯对宙斯太忠心了」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#得墨忒耳
「话说回来，科瑞。你在冥界没吃过东西吧？」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「诶？」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_magao_eyeA.png"  mouth="Her_p_magao_mouthA.png"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「在冥界进食就意味着归属冥界。[r]
地下应该没有你喜欢的东西，我想应该没问题…」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeB.png"  mouth="Per_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「啊……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
听到母亲的话，珀耳塞福涅僵住了。[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeB.png"  mouth="Per_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（吃了。我，把哈迪斯大人给的石榴果实——吃下了）[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_odoroki_eyeA.png"  mouth="Demeter_p_odoroki_mouthA.png"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「难道说，你吃了？」[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="200"  eye="Demeter_p_gekido_eyeA.png"  mouth="Demeter_p_magao_mouthA.png"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「哈迪斯……太卑鄙了。[r]
和宙斯串通，算计一无所知的你」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（算计……？哈迪斯大人，算计我？）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
珀耳塞福涅回忆起与冥王的对话。[p]
[_tb_end_text]

[mask  time="600"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="true"  ]
[bg  time="0"  method="crossfade"  storage="bak/aides_hall.jpg"  ]
[tb_filter_grayscale  layer="base"  grayscale="60"  ]
[tb_filter_grayscale  layer="0"  grayscale="60"  ]
[chara_show  name="ハデス"  time="0"  wait="false"  storage="chara/11/Hades_base.png"  width="752"  height="1410"  left="280"  top="-90"  reflect="false"  ]
[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[mask_off  time="800"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#哈迪斯
『要吃点——什么吗？』[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
『来到冥界后，你什么都没吃吧』[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
『喜欢什么』[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
面对冥王平淡的询问，珀耳塞福涅回答「喜欢谷物和水果」。[p]
[_tb_end_text]

[chara_hide  name="ハデス"  time="600"  wait="false"  pos_mode="false"  ]
[tb_start_text mode=1 ]
#
后来哈迪斯王曾说，为了她开始在冥界栽培水果。[p]
[_tb_end_text]

[bg  time="600"  method="crossfade"  storage="kuro.jpg"  ]
[bg  time="1000"  method="crossfade"  storage="bak/aides_gyokza.jpg"  ]
[chara_show  name="ハデス"  time="500"  wait="false"  storage="chara/11/Hades_base.png"  width="752"  height="1410"  left="280"  top="-90"  reflect="false"  ]
[chara_part  name="ハデス"  time="500"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="true"  ]
[wait  time="500"  ]
[tb_start_text mode=1 ]
#哈迪斯
『你说过喜欢谷物和水果吧』[p]
『虽然冥界的土壤适合的种类不多——但这个应该种得不错』[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[mask  time="600"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="true"  ]
[bg  time="0"  method="crossfade"  storage="bak/ereusis.jpg"  ]
[tb_free_filter  layer="base"  ]
[tb_free_filter  layer="0"  ]
[chara_show  name="デメテル"  time="0"  wait="false"  storage="chara/12/Dameter_base2.png"  width="720"  height="1350"  left="-40"  top="-120"  reflect="false"  ]
[chara_part  name="デメテル"  time="0"  eye="Demeter_p_magao_eyeA.png"  mouth="Demeter_p_magao_mouthA.png"  ]
[chara_show  name="ペルセポネ"  time="0"  wait="false"  storage="chara/10/Per_base.png"  width="700"  height="1313"  left="270"  top="-105"  reflect="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeA.png"  mouth="Per_p_magao_mouthA.png"  wait="false"  ]
[mask_off  time="800"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「不对——不是的，母亲大人」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
珀耳塞福涅连连摇头。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「哈迪斯大人根本没有算计我」[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_odoroki_eyeA.png"  mouth="Demeter_p_odoroki_mouthA.png"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「科瑞」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「听我说，母亲大人。我在冥界吃了石榴果实。是哈迪斯大人给的」[p]
「虽然确实多次劝我进食——但回答的人是我。[r]
是我告诉他喜欢谷物和水果」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「所以哈迪斯大人才特意为我栽培了石榴」[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_magao_eyeA.png"  mouth="Demeter_p_magao_mouthA.png"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「可是，哈迪斯大人根本没向你说明冥界的规矩对吧？[r]
他是不是硬把石榴果实塞进了你这张懵懂无知的嘴里？」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeB.png"  mouth="Per_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「不是的，母亲大人，您误会了」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_magao_eyeA.png"  mouth="Per_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（因为，哈迪斯大人他——）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[mask  time="600"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="true"  ]
[bg  time="0"  method="crossfade"  storage="bak/aides_hall.jpg"  ]
[tb_filter_grayscale  layer="base"  grayscale="60"  ]
[tb_filter_grayscale  layer="0"  grayscale="60"  ]
[chara_show  name="ハデス"  time="0"  wait="false"  storage="chara/11/Hades_base.png"  width="752"  height="1410"  left="280"  top="-90"  reflect="false"  ]
[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[mask_off  time="800"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#哈迪斯
『看来你是真的没在听啊……』[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[mask  time="600"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="true"  ]
[bg  time="0"  method="crossfade"  storage="bak/ereusis.jpg"  ]
[tb_free_filter  layer="base"  ]
[tb_free_filter  layer="0"  ]
[chara_show  name="デメテル"  time="0"  wait="false"  storage="chara/12/Dameter_base2.png"  width="720"  height="1350"  left="-40"  top="-120"  reflect="false"  ]
[chara_part  name="デメテル"  time="0"  eye="Demeter_p_magao_eyeA.png"  mouth="Demeter_p_magao_mouthA.png"  ]
[chara_show  name="ペルセポネ"  time="0"  wait="false"  storage="chara/10/Per_base.png"  width="700"  height="1313"  left="270"  top="-105"  reflect="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeA.png"  mouth="Per_p_magao_mouthA.png"  wait="false"  ]
[mask_off  time="800"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「哈迪斯大人发现我不知道婚约的事时，显得很惊讶。[r]
他压根没想到我竟连冥界的规矩都不清楚」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#得墨忒耳
「科瑞。我知道你是个心肠柔软的孩子。[r]
但你是不是太过天真了？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#得墨忒耳
「宙斯可不是会推翻自己决定的男人。[r]
哈迪斯也一样」[p]
「何况要迎娶新娘，就该展现出十足的诚意才是正理」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_magao_eyeB.png"  mouth="Per_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「那个......」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
母亲的话确实合情合理。[r]
即便如此，珀耳塞福涅也无法忍受母神这样诋毁冥界之王。[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_magao_eyeA.png"  mouth="Per_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「诚意的话，我是真切感受到的」[p]
「哈迪斯大人最优先考虑的，是让我适应冥界生活」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_magao_eyeB.png"  mouth="Per_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「当然了，突然被拽上马车时确实吓坏了。[r]
但哈迪斯大人——」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
珀耳塞福涅想起临别冥界时，那位王者说过的话。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[mask  time="600"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="true"  ]
[bg  time="0"  method="crossfade"  storage="bak/aides_gyokza.jpg"  ]
[tb_filter_grayscale  layer="base"  grayscale="60"  ]
[tb_filter_grayscale  layer="0"  grayscale="60"  ]
[chara_show  name="ハデス"  time="0"  wait="false"  storage="chara/11/Hades_base.png"  width="752"  height="1410"  left="280"  top="-90"  reflect="false"  ]
[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeA.png"  mouth="Hades_p_bisho_mouthA.png"  wait="false"  ]
[mask_off  time="800"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#哈迪斯
『请你将这份心意，珍藏在心中』[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[mask  time="600"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="true"  ]
[bg  time="0"  method="crossfade"  storage="bak/ereusis.jpg"  ]
[tb_free_filter  layer="base"  ]
[tb_free_filter  layer="0"  ]
[chara_show  name="デメテル"  time="0"  wait="false"  storage="chara/12/Dameter_base2.png"  width="720"  height="1350"  left="-40"  top="-120"  reflect="false"  ]
[chara_part  name="デメテル"  time="0"  eye="Demeter_p_magao_eyeA.png"  mouth="Demeter_p_magao_mouthA.png"  ]
[chara_show  name="ペルセポネ"  time="0"  wait="false"  storage="chara/10/Per_base.png"  width="700"  height="1313"  left="270"  top="-105"  reflect="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_magao_eyeB.png"  mouth="Per_p_magao_mouthA.png"  wait="false"  ]
[mask_off  time="800"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「他是真心...珍视着我的……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#得墨忒耳
「科瑞......」[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_bisho_eyeA.png"  mouth="Demeter_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「好吧。既然你拼命维护到这种程度，[r]
想必哈迪斯确实是如你所言吧」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_bisho_eyeA.png"  mouth="Per_p_magao_mouthA.png"  wait="false"  ]
[chara_part  name="デメテル"  time="200"  eye="Demeter_p_gekido_eyeA.png"  mouth="Demeter_p_magao_mouthA.png"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「但宙斯那边，我可不会轻易饶恕」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
母神得墨忒耳再次向赫尔墨斯投去严厉的目光。[p]
[_tb_end_text]

[chara_show  name="ヘルメス"  time="500"  wait="false"  storage="chara/13/Hermes_base.png"  width="688"  height="1290"  left="720"  top="-84"  reflect="false"  ]
[chara_part  name="ヘルメス"  time="0"  eye="Her_p_kusho_eyeA.png"  mouth="Her_p_kusho_mouthA.png"  ]
[chara_part  name="デメテル"  time="0"  eye="Demeter_p_magao_eyeA.png"  mouth="Demeter_p_magao_mouthA.png"  ]
[wait  time="300"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「去吧，赫尔墨斯。告诉宙斯——[r]
科瑞误食冥界食物这事，他打算如何交代，[r]
我要看他给出怎样的裁决」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_bisho_eyeA.png"  mouth="Her_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「遵命」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
赫尔墨斯露出为难的笑容，仍向女神行礼致意。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
随即登上马车握紧缰绳。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#赫尔墨斯
「马儿们，先随我上天界一趟可好？之后再把你们送回冥府」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
马匹轻声嘶鸣回应着赫尔墨斯。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
这些深受冥界之王宠爱的——将珀耳塞福涅送回母神身边的冥府马。[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_magao_eyeA.png"  mouth="Per_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「等一下」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_hide  name="ペルセポネ"  time="600"  wait="true"  pos_mode="false"  ]
[tb_start_text mode=1 ]
#
珀耳塞福涅小跑到马群跟前。[p]
[_tb_end_text]

[chara_show  name="ペルセポネ"  time="500"  wait="false"  storage="chara/10/Per_base.png"  width="700"  height="1313"  left="390"  top="-105"  reflect="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_bisho_eyeA.png"  mouth="Per_p_bisho_mouthA.png"  wait="false"  ]
[wait  time="500"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「谢谢你载我来」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
马儿们喷着鼻息将鼻子凑近珀耳塞福涅的脸庞。[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_odoroki_eyeA.png"  mouth="Her_p_odoroki_mouthA.png"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「哎呀，真稀奇」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_odoroki_eyeA.png"  mouth="Her_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「从没见过马儿们对哈迪斯大人以外的人撒娇」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeC.png"  mouth="Per_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「呵呵」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_bisho_eyeA.png"  mouth="Her_p_bisho_mouthA.png"  ]
[tb_start_text mode=1 ]
#
珀耳塞福涅像冥王做过的那样，轻轻抚摸马儿的鬃毛根部。[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_bisho_eyeA.png"  mouth="Per_p_bisho_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（请转告哈迪斯大人）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
为避免母亲与赫尔墨斯听见，珀耳塞福涅只用眼神向马儿们传递讯息。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（就说我从未后悔吃下石榴果实）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
在冥界进食意味着归属冥界——[r]
这规矩的深意，珀耳塞福涅并非不明白。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
但此刻她忽然懂了[r]
那位君王为何希望她留在冥界用餐。[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeB.png"  mouth="Per_p_egao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（一定是——想与我相伴吧）[r]
（你们那位骄傲的君王）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeA.png"  mouth="Per_p_egao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（虽然父神会如何裁决，我尚不得知......）[r]
（但愿你们的王能获得幸福）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
马儿们再度嘶鸣，仿佛听懂了珀耳塞福涅的心声。[p]
[_tb_end_text]

[jump  storage="main7.ks"  target="*start"  ]
[s  ]
[tb_start_text mode=1 ]
[ruby text="ようや"][p]
[_tb_end_text]

