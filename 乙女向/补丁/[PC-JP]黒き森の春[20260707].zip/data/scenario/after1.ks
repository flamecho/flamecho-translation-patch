﻿[_tb_system_call storage=system/_after1.ks]

[plugin name=auto_indent]

[plugin name="backlog"]

*start

[stopbgm  time="1000"  fadeout="true"  ]
[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[tb_ptext_hide  time="0"  ]
[tb_image_hide  time="0"  ]
[tb_show_message_window  ]
[bg  time="1000"  method="crossfade"  storage="kuro.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[bg  time="1000"  method="crossfade"  storage="bak/aides_gyokza.jpg"  ]
[playbgm  volume="15"  time="1000"  loop="true"  storage="bgm/hades_off.mp3"  ]
[tb_start_text mode=1 ]
#塔纳托斯
「陛下」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_show  name="ハデス"  time="500"  wait="false"  storage="chara/11/Hades_base.png"  width="720"  height="1350"  left="10"  top="-85"  reflect="false"  ]
[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[chara_show  name="タナトス"  time="500"  wait="false"  storage="chara/15/Tanatos_base.png"  width="700"  height="1313"  left="580"  top="-70"  reflect="false"  ]
[chara_part  name="タナトス"  time="0"  eye="Tanatos_p_magao_eyeA.png"  mouth="Tanatos_p_magao_mouthA.png"  wait="false"  ]
[wait  time="800"  ]
[tb_start_text mode=1 ]
#哈迪斯
「是塔纳托斯啊」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#塔纳托斯
「现在方便吗？我想汇报」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「——说吧」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="true"  ]
[bg  time="0"  method="crossfade"  storage="bak/aides_hall.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[chara_show  name="ペルセポネ"  time="500"  wait="false"  storage="chara/10/Per_base.png"  width="720"  height="1350"  left="480"  top="-115"  reflect="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_bisho_eyeA.png"  mouth="Per_p_bisho_mouthA2.png"  wait="false"  ]
[wait  time="500"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（今天庭院里的植物也都生机勃勃）[p]

[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeC.png"  mouth="Per_p_bisho_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（哈迪斯大人种下的果树种子，也长得很好）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeA.png"  mouth="Per_p_egao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（哈迪斯大人一定会很高兴吧[r]
这个时间应该还在王座厅。过去说说话吧）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeC.png"  mouth="Per_p_egao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（今天也能见到您的笑容就好了）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="true"  ]
[bg  time="0"  method="crossfade"  storage="bak/aides_gyokza.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[chara_show  name="ハデス"  time="500"  wait="false"  storage="chara/11/Hades_base.png"  width="720"  height="1350"  left="10"  top="-85"  reflect="false"  ]
[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeA.png"  mouth="Hades_p_bisho_mouthA.png"  wait="false"  ]
[chara_show  name="タナトス"  time="500"  wait="false"  storage="chara/15/Tanatos_base.png"  width="700"  height="1313"  left="580"  top="-70"  reflect="false"  ]
[chara_part  name="タナトス"  time="0"  eye="Tanatos_p_magao_eyeA.png"  mouth="Tanatos_p_magao_mouthA.png"  wait="false"  ]
[wait  time="300"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（哎呀）[p]
（塔纳托斯神来了[r]
最近看他总是很忙的样子，现在总算闲下来了吗）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（哈迪斯大人的表情很柔和。看来谈的是好事）[p]
（……）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（工作的事我插不上嘴……还是改天再来吧）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="true"  ]
[bg  time="0"  method="crossfade"  storage="kuro.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[bg  time="1000"  method="crossfade"  storage="bak/aides_entra.jpg"  ]
[chara_show  name="ペルセポネ"  time="0"  wait="false"  storage="chara/10/Per_base.png"  width="700"  height="1313"  left="540"  top="-105"  reflect="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeB.png"  mouth="Per_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「唉……」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeB.png"  mouth="Per_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（哈迪斯大人和塔纳托斯神说话时，表情总会变呢）[p]
（两位都这么专注工作[r]
要是我也能多帮上忙就好了）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeC.png"  mouth="Per_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（嗯——……）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeB.png"  mouth="Per_p_kusho_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（对了[r]
要不试着向哈迪斯大人请求，让我也学习些工作吧？）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeB.png"  mouth="Per_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（不过，照顾植物的工作已经交给我了）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeC.png"  mouth="Per_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（倒也不是对这个不满啦……）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeB.png"  mouth="Per_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_show  name="ヘルメス"  time="500"  wait="false"  storage="chara/13/Hermes_base.png"  width="700"  height="1313"  left="70"  top="-88"  reflect="false"  ]
[chara_part  name="ヘルメス"  time="0"  eye="Her_p_bisho_eyeA.png"  mouth="Her_p_bisho_mouthA.png"  wait="false"  ]
[wait  time="600"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「哟，冥界的王后」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「赫尔墨斯」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_egao_eyeC.png"  mouth="Her_p_egao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「刚才开始怎么了？一个人表情变来变去的」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_bisho_eyeA.png"  mouth="Her_p_bisho_mouthA.png"  wait="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeA.png"  mouth="Per_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「讨厌，你一直在看吗？」[p]
「既然在旁边，直接叫我就好了嘛」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#赫尔墨斯
「看你陷入沉思的样子。想等你平静些再打招呼」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeC.png"  mouth="Per_p_egao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「什么嘛」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeA.png"  mouth="Per_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「有烦心事？不嫌弃的话可以跟我说说」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「咦」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeA.png"  mouth="Per_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「啊哈哈……有那么明显吗？」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_egao_eyeC.png"  mouth="Her_p_egao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「嗯」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_bisho_eyeA.png"  mouth="Her_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「让我猜猜看」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_kusho_eyeC.png"  mouth="Her_p_bisho_mouthA.png"  wait="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
『今天还没和哈迪斯大人说上话呢~好想聊天啊~[r]
什么时候去搭话比较好呢~』[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_kusho_eyeB.png"  mouth="Her_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
『啊，不过现在过去会不会打扰到~怎么办~扭扭捏捏』[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_bisho_eyeA.png"  mouth="Her_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「猜错了？」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_fukure_eyeA.png"  mouth="Per_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「唔」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「虽然没完全猜中——但也差不多啦！」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_fukure_eyeA.png"  mouth="Per_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「最后的"扭扭捏捏"纯属多余！」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_kusho_eyeA.png"  mouth="Her_p_egao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「诶——？」[p]
「可你看起来就是在扭扭捏捏啊？」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_fukure_eyeA.png"  mouth="Per_p_fukure_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「嗯——」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_fukure_eyeA.png"  mouth="Per_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「才没有在磨磨蹭蹭呢！」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_egao_eyeC.png"  mouth="Her_p_egao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「啊哈哈」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_bisho_eyeA.png"  mouth="Her_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「这么有精神的话，应该不用担心了吧」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_egao_eyeA.png"  mouth="Her_p_egao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「今天也要去森林巡逻吧？路上小心」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_bisho_eyeA.png"  mouth="Her_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「那先走啦」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_hide  name="ヘルメス"  time="600"  wait="false"  pos_mode="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_fukure_eyeA.png"  mouth="Per_p_fukure_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「嗯……」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="300"  eye="Per_p_kusho_eyeB.png"  mouth="Per_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「唉……」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeC.png"  mouth="Per_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（原来我看起来这么沮丧啊……[r]
虽然心情确实有点低落）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（不行不行！）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_magao_eyeA.png"  mouth="Per_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（我不打起精神的话，森林也会受影响的）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_magao_eyeB.png"  mouth="Per_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（……）[p]
（好想和哈迪斯大人说说话啊……）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeA.png"  mouth="Per_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「既然如此，就让刻耳柏洛斯听我好好倾诉吧」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeC.png"  mouth="Per_p_egao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「刻耳柏洛斯，过来！我们进森林去！」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeA.png"  mouth="Per_p_egao_mouthA.png"  wait="false"  ]
[chara_show  name="ケルベロス"  time="1000"  wait="true"  storage="chara/16/Cerberus.png"  width="620"  height="1163"  left="80"  top="130"  reflect="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「早啊刻耳柏洛斯，今天你也威风凛凛的呢」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeC.png"  mouth="Per_p_egao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「出发咯！」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_hide_all  time="600"  wait="false"  ]
[wait  time="600"  ]
[chara_show  name="ハデス"  time="500"  wait="false"  storage="chara/11/Hades_base.png"  width="720"  height="1350"  left="40"  top="-85"  reflect="false"  ]
[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA2.png"  wait="false"  ]
[wait  time="300"  ]
[tb_start_text mode=1 ]
#哈迪斯
「……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_show  name="ヘルメス"  time="500"  wait="false"  storage="chara/13/Hermes_base.png"  width="700"  height="1313"  left="550"  top="-88"  reflect="false"  ]
[chara_part  name="ヘルメス"  time="0"  eye="Her_p_bisho_eyeA.png"  mouth="Her_p_bisho_mouthA.png"  wait="false"  ]
[wait  time="400"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「不和珀耳塞福涅打个招呼可以吗」[p]
「我和她说话的时候，您可是对我释放了那么强烈的杀意呢」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_odoroki_eyeA.png"  mouth="Hades_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「杀意什么的」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_kusho_eyeA.png"  mouth="Her_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「哎呀，您自己倒没察觉呢」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_kusho_eyeA.png"  mouth="Hades_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「……」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_kusho_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「王妃在——赫尔墨斯面前才会露出那样的表情啊」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_odoroki_eyeA.png"  mouth="Her_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「诶」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_kusho_eyeB.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「那么生动鲜活——」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_kusho_eyeA.png"  mouth="Her_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「那个……哈迪斯大人？」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_kusho_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「果然还是年纪相近的人更好交谈吗」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_odoroki_eyeB.png"  mouth="Her_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「呃这个嘛」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_kusho_eyeC.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「或者说，和赫尔墨斯这样善谈的人在一起更轻松……」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_kusho_eyeB.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[chara_part  name="ヘルメス"  time="0"  eye="Her_p_kusho_eyeA.png"  mouth="Her_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「承蒙夸奖，不胜荣幸」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_odoroki_eyeA.png"  mouth="Her_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「——才不是这样！」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_kusho_eyeA.png"  mouth="Her_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「哈迪斯大人[r]
珀耳塞福涅因为没能和您说上话，一直很消沉哦？」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeB.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「但是和赫尔墨斯开始聊天后，就神采奕奕了」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_kusho_eyeC.png"  mouth="Hades_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「羡慕」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeB.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[chara_part  name="ヘルメス"  time="0"  eye="Her_p_odoroki_eyeA.png"  mouth="Her_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「好羡……」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_kusho_eyeC.png"  mouth="Her_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「唉……」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_kusho_eyeA.png"  mouth="Her_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「羡慕的话主动去搭话不就好了」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_odoroki_eyeA.png"  mouth="Hades_p_odoroki_mouthA.png"  wait="false"  ]
[chara_part  name="ヘルメス"  time="0"  eye="Her_p_kusho_eyeA.png"  mouth="Her_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「哈迪斯大人是冥界的王者[r]
珀耳塞福涅有时候也不太敢主动开口吧[r]
特别是您工作的时候」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_kusho_eyeA.png"  mouth="Hades_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「这份心意值得嘉许——」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「但我是她的丈夫。妻子和丈夫说话，与王权神格都无关」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_kusho_eyeA.png"  mouth="Her_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「可就是有关系啦」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#赫尔墨斯
「真是个懂事的妹妹。深刻理解冥界的重要性」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_bisho_eyeA.png"  mouth="Her_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「大概是怕在丈夫处理要务时打扰会被嫌弃吧」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_kusho_eyeA.png"  mouth="Hades_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「……」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_odoroki_eyeA.png"  mouth="Her_p_odoroki_mouthB.png"  wait="false"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「对了。说到要务想起来了」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA2.png"  wait="false"  ]
[chara_part  name="ヘルメス"  time="0"  eye="Her_p_bisho_eyeA.png"  mouth="Her_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「宙斯大人的口信」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_bisho_eyeA.png"  mouth="Her_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「部分地区持续的战事即将终结」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_bisho_eyeA.png"  mouth="Her_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「很快流入冥界的灵魂数量也会趋于平稳吧」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「塔纳托斯也提交了相同报告」[p]
「目前冥界的接待工作都进展顺利」[p]
「去告诉宙斯没有问题」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#赫尔墨斯
「遵命」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="false"  ]
[bg  time="0"  method="crossfade"  storage="kuro.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[bg  time="1000"  method="crossfade"  storage="bak/popula.jpg"  ]
[chara_show  name="ペルセポネ"  time="500"  wait="false"  storage="chara/10/Per_base.png"  width="720"  height="1350"  left="580"  top="-115"  reflect="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeC.png"  mouth="Per_p_egao_mouthA.png"  wait="false"  ]
[chara_show  name="ケルベロス"  time="500"  wait="false"  storage="chara/16/Cerberus.png"  width="620"  height="1163"  left="80"  top="130"  reflect="false"  ]
[wait  time="500"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「今天的花环做好啦！」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeA.png"  mouth="Per_p_egao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「过来刻耳柏洛斯，给你戴在脖子上」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_hide  name="ケルベロス"  time="800"  wait="true"  pos_mode="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「哎呀」[p]
「怎么了？不是那边——」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_show  name="ハデス"  time="600"  wait="false"  storage="chara/11/Hades_base.png"  width="720"  height="1350"  left="200"  top="-85"  reflect="false"  ]
[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[chara_show  name="ケルベロス"  time="600"  wait="false"  storage="chara/16/Cerberus.png"  width="620"  height="1163"  left="-50"  top="130"  reflect="false"  ]
[wait  time="600"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「哈迪斯大人……」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_bisho_eyeA.png"  mouth="Per_p_kusho_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（原来如此。刻耳柏洛斯是察觉到哈迪斯大人的气息了）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeA.png"  mouth="Per_p_kusho_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（难道是专程来接我的吗。该说什么好呢）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[glink  color="btn_18_black"  storage="after1.ks"  size="20"  x="700"  y="370"  width="400"  height=""  text="「お忙しいのに、有難うございます」"  _clickable_img=""  target="*af1_A"  ]
[glink  color="btn_18_black"  storage="after1.ks"  size="20"  x="700"  y="450"  width="400"  height=""  text="「今日の花飾りもよくできたんです」"  _clickable_img=""  target="*af1_B"  ]
[s  ]
*af1_A

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeA.png"  mouth="Per_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「您是来接我的吗？百忙之中实在感激不尽」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「无妨」[p]
「方才你去过玉座之厅吧。有何要事」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（原来您注意到了）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeB.png"  mouth="Per_p_bisho_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（所以特地追过来...真是温柔啊……）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_bisho_eyeA.png"  mouth="Per_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「是想报告庭院里的果实长势良好」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeA.png"  mouth="Per_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「但看见哈迪斯大人正与塔纳托斯神交谈，[r]
便打算改日再来」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「……」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「今后要等到谈话结束」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「诶」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「因你的汇报于我也很重要」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「哈迪斯大人……」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeB.png"  mouth="Per_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「这样可以吗？[r]
有些政务想必不便让我听闻……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「你乃冥界王妃」[p]
「没有你不能听的事」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeB.png"  mouth="Per_p_naki_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「……！」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeC.png"  mouth="Per_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「好开心……非常感谢」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeA.png"  mouth="Hades_p_bisho_mouthA.png"  wait="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeB.png"  mouth="Per_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「不如说，今后要常伴我左右」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA.png"  wait="false"  ]
[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeB.png"  mouth="Hades_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「你不在身边我便心神不宁」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_kusho_eyeA.png"  mouth="Hades_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「总担忧你会不会被人拐跑——」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeA.png"  mouth="Hades_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「因你如此美丽可爱」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeA.png"  mouth="Per_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「那个——好的」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeA.png"  mouth="Per_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（这不算客套——对吧）[p]
（以哈迪斯大人的性格，定是实话实说）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_fukure_eyeB.png"  mouth="Per_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（虽然开心——但有点难为情！）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeB.png"  mouth="Per_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（这种时候该摆什么表情啊……）[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeB.png"  mouth="Hades_p_bisho_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「……」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeA.png"  mouth="Hades_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「呵」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「你表情转得真快」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「实在惹人怜爱……爱得不行。[r]
让我多看看你千变万化的面容吧」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeA.png"  mouth="Per_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「！」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_fukure_eyeA.png"  mouth="Per_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（该、怎么办……怎么回应才好？[r]
说谢谢？还是夸哈迪斯大人仪容俊朗？）[p]
（那个，那个——）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeA.png"  mouth="Per_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「我、我也最爱哈迪斯大人了……！！」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_odoroki_eyeA.png"  mouth="Hades_p_bisho_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「！」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[jump  storage="after1.ks"  target="*af1_return"  ]
*af1_B

[tb_start_text mode=1 ]
#珀耳塞福涅
「您果然来接我了呢。非常感谢」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeC.png"  mouth="Per_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「今天的花环也编得很好。正想给刻耳柏洛斯戴上」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_bisho_eyeA.png"  mouth="Per_p_kusho_mouthA.png"  wait="false"  ]
[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeA.png"  mouth="Hades_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「是吗」[p]
「很漂亮。你手真巧」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeA.png"  mouth="Per_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「与其说是手巧，其实是从还在地面上时就开始做了。[r]
只是做得比较熟练罢了」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「要练到这么熟练，看来做过很多次吧？[r]
你的手不仅能创造美，本身也很美丽呢」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeB.png"  mouth="Per_p_kusho_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（被您这么说，总觉得有点害羞呢）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeA.png"  mouth="Per_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「你的秀发也很美。是自己打理的吗？」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_kusho_eyeB.png"  mouth="Hades_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「在冥界没受到损伤吧？」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeC.png"  mouth="Per_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「没问题的」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeA.png"  mouth="Per_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「冥界的水很清澈，而且哈迪斯大人赐给我的梳子质地非常好」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeA.png"  mouth="Hades_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「是吗。那就好」[p]
「再多准备些发饰吧。要配得上你秀发的那种」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「诶」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「你喜欢什么宝石？想要什么样式的雕工？」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeA.png"  mouth="Per_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（这个发展——是真的打算要送我啊）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeA.png"  mouth="Per_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「哈迪斯大人，饰品已经收了很多。再收的话……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「不必推辞。是我想要赠与」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeA.png"  mouth="Per_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（怎么办。虽然知道是出于好意……）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_bisho_eyeA.png"  mouth="Per_p_kusho_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（——有了）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_bisho_eyeA.png"  mouth="Per_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「哈迪斯大人，比起收发饰，我有个更想做的事」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_odoroki_eyeA.png"  mouth="Hades_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「想做的事？」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeA.png"  mouth="Hades_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「是什么」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeA.png"  mouth="Per_p_egao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「那个……能不能也让我来为您梳理头发呢？」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_odoroki_eyeA.png"  mouth="Hades_p_bisho_mouthA.png"  wait="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeB.png"  mouth="Per_p_kusho_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（这样一来，至少梳理时能独占哈迪斯大人的时间）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeC.png"  mouth="Per_p_egao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「哈迪斯大人的长发如此美丽，我一直都想要触碰」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeA.png"  mouth="Per_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「当然，前提是哈迪斯大人您愿意的话——」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeB.png"  mouth="Hades_p_bisho_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「……」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeC.png"  mouth="Hades_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「想触碰我……」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeA.png"  mouth="Per_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「哈迪斯大人……？」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeB.png"  mouth="Hades_p_bisho_mouthA.png"  wait="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeA.png"  mouth="Per_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（突然这么提，是不是太冒失了……）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeA.png"  mouth="Per_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「那个，如果您觉得为难就当我没说」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_bisho_eyeA.png"  mouth="Hades_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「拜托你了」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「诶」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「起床后立刻一次，午间和傍晚各一次，睡前再一次。[r]
至少每天总共需要打理四次」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（四次！）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeB.png"  mouth="Per_p_kusho_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（但这期间就能和哈迪斯大人独处了……）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeC.png"  mouth="Per_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「包在我身上！」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

*af1_return

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="true"  ]
[bg  time="0"  method="crossfade"  storage="kuro.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[bg  time="1000"  method="crossfade"  storage="bak/aides_hall.jpg"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（就这样，我和哈迪斯大人共度了许多时光）[p]
（只爱我一人的我的君王，总是如此温柔）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[wait  time="500"  ]
[tb_image_show  time="1000"  storage="default/end.png"  width="142"  height="67"  x="740"  y="280"  _clickable_img=""  ]
[wait  time="1500"  ]
[tb_image_hide  time="1000"  ]
[jump  storage="extras.ks"  target="*top"  ]
[s  ]
[tb_start_text mode=1 ]
[ruby text="ようや"][p]
[_tb_end_text]

[tb_start_text mode=1 ]
标题：我的君王[p]
[_tb_end_text]

