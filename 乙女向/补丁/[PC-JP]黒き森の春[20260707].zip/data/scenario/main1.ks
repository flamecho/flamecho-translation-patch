﻿[_tb_system_call storage=system/_main1.ks]

[plugin name=auto_indent]

[plugin name="backlog"]

*start

[stopbgm  time="1000"  fadeout="true"  ]
[tb_hide_message_window  ]
[cm  ]
[bg  time="1000"  method="crossfade"  storage="kuro.jpg"  ]
[tb_image_show  time="1000"  storage="default/intro.png"  width="524"  height="398"  x="390"  y="150"  _clickable_img=""  name="img_7"  ]
[wait  time="4000"  ]
[tb_image_hide  time="1000"  ]
*prologue

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[tb_show_message_window  ]
[bg  time="1000"  method="crossfade"  storage="bak/hanabatake.jpg"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[playbgm  volume="13"  time="1000"  loop="true"  storage="bgm/kiri_alone.mp3"  fadein="false"  ]
[chara_show  name="ペルセポネ"  time="500"  wait="false"  storage="chara/10/kore_base.png"  width="840"  height="1575"  left="250"  top="-165"  reflect="false"  ]
[chara_part  name="ペルセポネ"  time="500"  eye="Per_p_egao_eyeA.png"  mouth="Per_p_egao_mouthA.png"  wait="false"  ]
[wait  time="500"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「花朵香气真好闻」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_bisho_eyeA.png"  mouth="Per_p_egao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「很适合装饰母亲的神殿呢。今天去采些鸢尾花吧」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_hide  name="ペルセポネ"  time="600"  wait="true"  pos_mode="false"  ]
[wait  time="300"  ]
[chara_show  name="デメテル"  time="500"  wait="false"  storage="chara/12/Demeter_base1.png"  width="700"  height="1313"  left="-75"  top="-105"  reflect="false"  ]
[chara_part  name="デメテル"  time="0"  eye="Demeter_p_bisho_eyeA.png"  mouth="Demeter_p_bisho_mouthA.png"  wait="false"  ]
[wait  time="300"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「科瑞」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_show  name="ペルセポネ"  time="500"  wait="false"  storage="chara/10/kore_base.png"  width="688"  height="1290"  left="310"  top="-95"  reflect="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeA.png"  mouth="Per_p_egao_mouthA.png"  wait="false"  ]
[wait  time="300"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「母亲大人！」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「正好在采要供奉给母亲大人神殿的鲜花呢」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#得墨忒耳
「哎呀，真开心」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#得墨忒耳
「你采摘的花朵全都充满生机。[r]
神殿也一定会因此绚丽起来吧」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「神殿能有这般明媚氛围，我想都是母亲大人神力的恩赐」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#得墨忒耳
「呵呵，谢谢」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeA.png"  mouth="Per_p_egao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（我的母亲大人是丰收女神得墨忒耳。摇曳着金色麦穗，怀抱累累硕果）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（不知有朝一日，我是否能成为母亲大人那样出色的女性。[r]
美丽又坚强的母亲大人）[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_odoroki_eyeA.png"  mouth="Demeter_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「！」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「母亲大人？」[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_magao_eyeA.png"  mouth="Demeter_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「宙斯……」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[chara_show  name="ゼウス"  time="500"  wait="false"  storage="chara/14/Zeus_base.png"  width="700"  height="1313"  left="700"  top="-65"  reflect="false"  ]
[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_bisho_eyeA.png"  mouth="Zeus_p_bisho_mouthA.png"  wait="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeA.png"  mouth="Per_p_egao_mouthA.png"  wait="false"  ]
[wait  time="500"  ]
[tb_start_text mode=1 ]
#宙斯
「哟，好久不见」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「父亲大人！」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeA.png"  mouth="Per_p_egao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（我的父亲大人是统御天际的主神宙斯）[p]
（平日里都在高耸的奥林匹斯山上。[r]
父亲大人和我们并不共同生活）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#得墨忒耳
「您有何贵干？」[p]
[_tb_end_text]

[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_kusho_eyeA.png"  mouth="Zeus_p_kusho_mouthA.png"  wait="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeA.png"  mouth="Per_p_egao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#宙斯
「姐姐还是老样子啊」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#宙斯
「来看看大地的状况。珀耳塞福涅，过得可好？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「是啊！」[p]
[_tb_end_text]

[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_bisho_eyeA.png"  mouth="Zeus_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#宙斯
「嗯。回答得不错」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#宙斯
「出落得真漂亮呢。不愧是女神得墨忒耳的女儿」[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_magao_eyeA.png"  mouth="Demeter_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「……」[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_magao_eyeA.png"  mouth="Demeter_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「科瑞，你先回神殿去」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「诶？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#得墨忒耳
「这些花是要装饰在我的神殿里吧？」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_magao_eyeA.png"  mouth="Per_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「啊，是的……」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_magao_eyeA.png"  mouth="Per_p_odoroki_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（难得父亲大人来访，还想多说会儿话……[r]
但想必是要商讨公务吧）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_bisho_eyeA.png"  mouth="Per_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「明白了。我先回去啦」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="true"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（母亲大人与父亲大人是姐弟神。[r]
倒也并非经历过轰轰烈烈的恋情才生下我）[p]
（不仅如此，母亲对情爱之事毫无兴趣。[r]
作为姐弟倒是在治理天地的事务上有所协作）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「记得母亲大人的兄弟姐妹，从长姐开始是赫斯提亚大人、母亲大人、赫拉大人、[r]
哈迪斯大人、波塞冬大人，最后是宙斯——父亲大人」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（赫斯提亚大人我很熟悉。是位文静温柔的长辈）[p]
（赫拉大人是父亲大人的正妃。[r]
几乎没有交谈过。——总觉得有些可怕）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（哈迪斯大人——冥界的君王。未曾谋面）[p]
（波塞冬舅舅经常被母亲大人训斥，[r]
倒是位随和的神明）[p]
（还有父亲大人。[r]
只有像今天这样降临凡间时，才能说上几句话）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（母亲大人很少前往天界。我也只去过寥寥数次）[p]
（有兄弟姐妹会是怎样的感受呢？）[p]
「毕竟我没有呢……。实在想象不出啊」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（会聊天谈心，偶尔也会吵架吧。[r]
像母亲和其他兄弟姐妹神明那样）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（但很难开口对母亲说想要妹妹或弟弟呢……）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[mask_off  time="1500"  effect="fadeOut"  ]
[chara_show  name="ゼウス"  time="500"  wait="false"  storage="chara/14/Zeus_base.png"  width="700"  height="1313"  left="570"  top="-65"  reflect="false"  ]
[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_kusho_eyeA.png"  mouth="Zeus_p_kusho_mouthA.png"  wait="false"  ]
[chara_show  name="デメテル"  time="500"  wait="false"  storage="chara/12/Demeter_base1.png"  width="700"  height="1313"  left="40"  top="-105"  reflect="false"  ]
[chara_part  name="デメテル"  time="0"  eye="Demeter_p_magao_eyeA.png"  mouth="Demeter_p_magao_mouthA.png"  wait="false"  ]
[wait  time="500"  ]
[tb_start_text mode=1 ]
#宙斯
「哎呀呀。连和女儿说话都不允许吗？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#得墨忒耳
「你脑子里从没好主意」[p]
[_tb_end_text]

[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_bisho_eyeA.png"  mouth="Zeus_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#宙斯
「呵呵。姐姐这股劲儿，我最喜欢了」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#得墨忒耳
「所以？有何贵干？」[p]
[_tb_end_text]

[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_kusho_eyeA.png"  mouth="Zeus_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#宙斯
「这么急性子」[p]
[_tb_end_text]

[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_bisho_eyeA.png"  mouth="Zeus_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#宙斯
「算了」[p]
「我在想你们是不是该再要个孩子。特地来邀请」[p]

[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_odoroki_eyeA.png"  mouth="Demeter_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「你说什么！？」[p]
[_tb_end_text]

[chara_part  name="デメテル"  time="0"  eye="Demeter_p_magao_eyeA.png"  mouth="Demeter_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#得墨忒耳
「你这男人真是…」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#得墨忒耳
「免了。我有可爱的女儿就够了」[p]
「不如多珍惜赫拉才是」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#宙斯
「我很珍惜啊？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#宙斯
「能进最"深闺"的只有赫拉」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#得墨忒耳
「认知差异吧。我可看不出来」[p]
[_tb_end_text]

[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_kusho_eyeA.png"  mouth="Zeus_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#宙斯
「这次不肯答应我吗？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#得墨忒耳
「不答应。请回吧」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="true"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[chara_show  name="ゼウス"  time="500"  wait="false"  storage="chara/14/Zeus_base.png"  width="752"  height="1410"  left="5"  top="-70"  reflect="false"  ]
[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_bisho_eyeA.png"  mouth="Zeus_p_bisho_mouthA.png"  wait="false"  ]
[chara_show  name="ヘルメス"  time="500"  wait="false"  storage="chara/13/Hermes_base.png"  width="736"  height="1380"  left="560"  top="-80"  reflect="false"  ]
[chara_part  name="ヘルメス"  time="0"  eye="Her_p_kusho_eyeA.png"  mouth="Her_p_kusho_mouthA.png"  wait="false"  ]
[wait  time="300"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「哎呀呀。得墨忒耳大人发火了呢」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#宙斯
「赫尔墨斯啊」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#宙斯
「那烈性子才迷人。何况还是美人」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#赫尔墨斯
「哈」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#宙斯
「话说你刚从冥界回来吧？[r]
大哥怎么说？愿意来吗？」[p]
[_tb_end_text]

[chara_part  name="ヘルメス"  time="0"  eye="Her_p_bisho_eyeA.png"  mouth="Her_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#赫尔墨斯
「啊对。正要汇报」[p]
「转达宙斯大人有要事相商后，他说会立即动身。[r]
答应亲自移驾奥林匹斯」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#宙斯
「行。那回去吧」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[bg  time="0"  method="crossfade"  storage="kuro.jpg"  ]
[chara_hide_all  time="0"  wait="true"  ]
[mask_off  time="1000"  effect="fadeOut"  ]
[bg  time="1000"  method="crossfade"  storage="bak/olympos.jpg"  ]
[chara_show  name="ゼウス"  time="500"  wait="false"  storage="chara/14/Zeus_base.png"  width="748"  height="1408"  left="570"  top="-70"  reflect="false"  ]
[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_bisho_eyeA.png"  mouth="Zeus_p_bisho_mouthA.png"  wait="false"  ]
[chara_show  name="ハデス"  time="500"  wait="false"  storage="chara/11/Hades_base.png"  width="752"  height="1410"  left="-5"  top="-90"  reflect="false"  ]
[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[wait  time="500"  ]
[tb_start_text mode=1 ]
#宙斯
「兄长。劳您亲自前来实在过意不去」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「没问题」[p]
「何事？听说有要事」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#宙斯
「嗯，其实呢」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#宙斯
「想着大哥也该有个配偶了。[r]
听说你在冥界整天只顾工作？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「？此乃本王职责」[p]
[_tb_end_text]

[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_kusho_eyeA.png"  mouth="Zeus_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#宙斯
「嗯。话是这么说」[p]
[_tb_end_text]

[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_magao_eyeA.png"  mouth="Zeus_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#宙斯
「但王者独身终究不妥。[r]
有个能分担工作的伴侣更好吧？该立妃了」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「……」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#宙斯
「按大哥性子，肯定不会主动寻找。[r]
我打算替你决定。可行？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「行不行的」[p]
「召我来时就已决定了吧？」[p]
[_tb_end_text]

[chara_part  name="ゼウス"  time="0"  eye="Zeus_p_bisho_eyeA.png"  mouth="Zeus_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#宙斯
「算是吧」[p]
「我和得墨忒耳姐姐有个女儿。[r]
我们的女儿当冥界王妃最合适」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#宙斯
「尤其像极了姐姐，美貌绝伦。大哥定会中意。[r]
不妨用水镜看看」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「……」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_odoroki_eyeA.png"  mouth="Hades_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「……！」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#宙斯
「可以吧？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「……」[p]
[_tb_end_text]

[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#哈迪斯
「既然你已如此决定，那便这样吧」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#宙斯
「好，就这么定了」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#宙斯
「那孩子总在姐姐大人的神殿附近采摘花朵」[p]
「能给一朵冥府之花吗？就以它为信物吧」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「是啊」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[tb_image_show  time="1000"  storage="default/suisens.png"  width="264"  height="420"  x="530"  y="80"  _clickable_img=""  name="img_174"  ]
[tb_start_text mode=1 ]
#
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「这样行吗」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#宙斯
「真棒。像水晶一样。美极了」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[tb_image_hide  time="1000"  ]
[tb_start_text mode=1 ]
#宙斯
「让这朵花混入野花丛中。[r]
要避免姐姐大人和其他人误碰，只让我那孩子能看见」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#宙斯
「当这姑娘摘取此花时便是信号。那时便可带她离开」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#哈迪斯
「知道了」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[mask  time="1000"  effect="fadeIn"  color="0x000000"  ]
[chara_hide_all  time="0"  wait="true"  ]
[bg  time="0"  method="crossfade"  storage="kuro.jpg"  ]
[mask_off  time="1500"  effect="fadeOut"  ]
[bg  time="1000"  method="crossfade"  storage="bak/hanabatake.jpg"  ]
[chara_show  name="ペルセポネ"  time="500"  wait="false"  storage="chara/10/kore_base.png"  width="840"  height="1575"  left="250"  top="-165"  reflect="false"  ]
[chara_part  name="ペルセポネ"  time="500"  eye="Per_p_bisho_eyeA.png"  mouth="Per_p_bisho_mouthA.png"  wait="false"  ]
[wait  time="300"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「呵呵。今天也有好多可爱的小花呢」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
「要编几个花环好呢？[r]
紫罗兰配番红花。点缀些玫瑰和风信子也不错」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#宁芙们
「科瑞大人，请不要太靠近森林那边」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_egao_eyeA.png"  mouth="Per_p_egao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「我知道的，没关系。我就采这附近的花」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_kusho_eyeA.png"  mouth="Per_p_kusho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「精灵们真是过度保护呢。我早就是堂堂正正的大姑娘了」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_bisho_eyeA.png"  mouth="Per_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「父神也夸我出落得美丽动人呢」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_magao_eyeA.png"  mouth="Per_p_magao_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（结果都没能和父神说上几句话……）[p]
（下次什么时候才能再来人间呢？[r]
想听奥林匹斯的事，也想打听其他兄弟的消息）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（但母亲大人可能会不太高兴。[r]
上次回到神殿时，她的脸色就格外阴沉）[p]
（毕竟母亲大人对工作太过认真……。[r]
与天界的父神意见常常相左吧）[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（不想让母亲伤心……。[r]
现在父神偶尔能来人间看看我，就该心存感激了）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_bisho_eyeA.png"  mouth="Per_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「好啦，花采得差不多了，该开始编花环了」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[tb_image_show  time="1000"  storage="default/pica.png"  width="640"  height="640"  x="-30"  y="30"  _clickable_img=""  name="img_208"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「咦？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[tb_image_hide  time="1000"  ]
[tb_image_show  time="1000"  storage="default/suisens.png"  width="224"  height="356"  x="230"  y="170"  _clickable_img=""  name="img_212"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「那边开的是水仙吗？[r]
孤零零只开一朵还真是少见」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[tb_image_hide  time="1000"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_bisho_eyeA.png"  mouth="Per_p_bisho_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「像宝石般闪闪发亮……。[r]
定是受到盖亚大人垂怜的花呢。就让它当花环的中心吧」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_bisho_eyeA.png"  mouth="Per_p_bisho_mouthA2.png"  wait="false"  ]
[chara_hide  name="ペルセポネ"  time="800"  wait="false"  pos_mode="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（美得妖异的水仙。简直不忍心采摘）[p]
[_tb_end_text]

[playse  volume="10"  time="1000"  buf="0"  storage="buki_hasiru.mp3"  fadein="true"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「？什么声音？」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[bg  time="1000"  method="crossfade"  storage="bak/hanabatake2.jpg"  ]
[tb_start_text mode=1 ]
#
突然大地裂开巨口，驾着双马车的男子从中现身。[p]
[_tb_end_text]

[stopse  time="1000"  buf="0"  fadeout="true"  ]
[chara_show  name="ハデス"  time="500"  wait="false"  storage="chara/11/Hades_base.png"  width="720"  height="1350"  left="60"  top="-85"  reflect="false"  ]
[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[chara_show  name="ペルセポネ"  time="500"  wait="false"  storage="chara/10/kore_base.png"  width="720"  height="1350"  left="520"  top="-115"  reflect="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA.png"  wait="false"  ]
[wait  time="500"  ]
[tb_start_text mode=1 ]
#
马车在珀耳塞福涅眼前刹住。男子与珀耳塞福涅四目相对。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
几乎要被男子散发的气场吞没，珀耳塞福涅吓得发抖。[p]
[_tb_end_text]

[chara_hide  name="ハデス"  time="600"  wait="false"  pos_mode="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「啊……」[p]
[_tb_end_text]

[chara_hide  name="ペルセポネ"  time="600"  wait="false"  pos_mode="false"  ]
[tb_start_text mode=1 ]
#
珀耳塞福涅被猛力拽向马车边缘。[r]
脚步踉跄间，整个人重重摔进马车厢底。[p]
[_tb_end_text]

[playse  volume="20"  time="1000"  buf="0"  storage="kouka_dosa.mp3"  ]
[chara_show  name="ハデス"  time="300"  wait="false"  storage="chara/11/Hades_base.png"  width="720"  height="1350"  left="60"  top="-85"  reflect="false"  ]
[chara_part  name="ハデス"  time="0"  eye="Hades_p_magao_eyeA.png"  mouth="Hades_p_magao_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#
男子瞥了珀耳塞福涅一眼，重新握紧缰绳。[p]
[_tb_end_text]

[chara_hide  name="ハデス"  time="600"  wait="true"  pos_mode="false"  ]
[chara_show  name="ペルセポネ"  time="500"  wait="false"  storage="chara/10/kore_base.png"  width="840"  height="1575"  left="250"  top="-165"  reflect="false"  ]
[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA.png"  wait="false"  ]
[wait  time="300"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「等…」[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_odoroki_mouthA2.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
（这个人是谁！？）[p]
[_tb_end_text]

[stopse  time="0"  buf="0"  fadeout="false"  ]
[tb_start_text mode=1 ]
#
[_tb_end_text]

[playse  volume="5"  time="1000"  buf="0"  storage="buki_hasiru.mp3"  fadein="true"  loop="true"  ]
[bg  time="1000"  method="crossfade"  storage="bak/hanabatake3.jpg"  ]
[tb_start_text mode=1 ]
#
马匹再次起步后不久，四周景色骤然变化。[p]
光与色彩逐渐消失，寒风愈发凛冽。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
珀耳塞福涅这时才猛然察觉[r]
自己正被带往某个未知之地。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#珀耳塞福涅
（怎、怎么回事...！？）[p]
[_tb_end_text]

[chara_part  name="ペルセポネ"  time="0"  eye="Per_p_odoroki_eyeA.png"  mouth="Per_p_naki_mouthA.png"  wait="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「不、不要！」[p]
[_tb_end_text]

[chara_hide  name="ペルセポネ"  time="800"  wait="false"  pos_mode="false"  ]
[tb_start_text mode=1 ]
#珀耳塞福涅
「救救我，母亲大人！救救我，父亲大人...！」[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
她母亲是丰饶女神得墨忒耳，父亲宙斯则是统御世界秩序的至高神。[r]
她想两位主神定会施以援手。[p]
珀耳塞福涅自认[r]
从未做过该遭绑架的恶事。[p]
[_tb_end_text]

[stopse  time="1000"  buf="0"  fadeout="true"  ]
[tb_start_text mode=1 ]
#
但父母的双臂始终未曾伸出。[p]
[_tb_end_text]

[bg  time="1000"  method="crossfade"  storage="kuro.jpg"  ]
[tb_start_text mode=1 ]
#
最后的光影也从珀耳塞福涅视野中彻底消逝。[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#
[_tb_end_text]

[jump  storage="main2.ks"  target="*start"  ]
[s  ]
