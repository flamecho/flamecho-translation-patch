label chapter_sixteen_start:

    scene black with eye_shut
    pause(1.0)
    scene bg amaranth day with eye_open:
        xpos 0.29 ypos 1.28 xanchor 0.5 yanchor 1.0 zoom 1.11
        linear 30.0 xpos 0.71 ypos 1.28 xanchor 0.5 yanchor 1.0 zoom 1.11
        linear 30.0 xpos 0.29 ypos 1.28 xanchor 0.5 yanchor 1.0 zoom 1.11
        repeat

    with dissolve
    window show dissolve

    translate None chapter_sixteen_0001:
        "我在晨鸟鸣叫和脚步声的轻响中醒来。睁开眼时，看见伊尔兰正在巡查营地。"
    translate None chapter_sixteen_0002:
        i con "哈，早上好啊小太阳！今天不打算睡懒觉了？"
    translate None chapter_sixteen_0003:
        rs sad "……能在这种地方睡着已经算走运了。"
    translate None chapter_sixteen_0004:
        i con "偶尔吃点苦对你有好处，能磨练性格。再说，这样你才能真正感激有屋顶遮头的日子。"
    translate None chapter_sixteen_0005:
        rs smi "照这么说走完这趟我性格该磨得完美了。可能我要求太高，但至少…我得设法找张床睡。"
    translate None chapter_sixteen_0006:
        i con "随你便…既然起来了，不如去叫醒你那帮小伙伴？"
    translate None chapter_sixteen_0007:
        "我依次叫醒了另外三人。莱奥斯嘟囔着说太早了，福恩利落地爬起来，而当我戳赛恩时，他竟黏在我身上—这让福恩颇为懊恼。"
    translate None chapter_sixteen_0008:
        "我轻手轻脚走向索伦，随即意识到音量根本无关紧要。毕竟…他暂时都不会醒来。他的胸膛微弱起伏，凝固在那永恒的沉睡里。"
    translate None chapter_sixteen_0009:
        "至少他还活着…坚持住，索伦。"

    scene bg amaranth day
    show raen n neu at cenleft
    show fawn n neu at cenright
    show cyne n neu at farright
    show leos n ann at farleft
    with dissolve
    play music "sounds/bgm/Discovery.ogg" fadeout 2.0

    translate None chapter_sixteen_0010:
        i con "好了，该出发了，否则就是在浪费白昼。别哭丧着脸啊莱奥斯，要是真困得不行，我可以背你。"
    translate None chapter_sixteen_0011:
        i fli "或者你更喜欢公主抱？"
    translate None chapter_sixteen_0012:
        l "我更希望你从我眼前永远消失，不过看来你根本不在意我的喜好。"
    translate None chapter_sixteen_0013:
        i fli "快了，很快就不用见到我了。被困在这荒郊野岭可不是我选的。"
    translate None chapter_sixteen_0014:
        "我们找回杂草丛生的小路继续前进。视野所及尽是赤红的树林…这真的能通往锡德卡汉吗？"
    translate None chapter_sixteen_0015:
        show raen n sad with dis
        rs "我们离锡德卡汉还有多远？"
    translate None chapter_sixteen_0016:
        i neu "保持这个速度的话，明早就能到。"
    translate None chapter_sixteen_0017:
        v smi "往好处想，只要再露宿一晚就到了。"
    translate None chapter_sixteen_0018:
        rs "嗯…那听起来还不算太糟。"
    translate None chapter_sixteen_0019:
        show cyne n sad with dis
        c "对你来说当然不糟！但我腿都要断了！雷—恩，在我累死前背我吧！"
    translate None chapter_sixteen_0020:
        f "开什么玩笑？这才刚上路！"

    show cyne at cenright
    show fawn at farright
    with move

    translate None chapter_sixteen_0021:
        c "我娇弱纤细的身体受不了长途跋涉…雷恩…."
    translate None chapter_sixteen_0022:
        rs "…就一小会儿。"
    translate None chapter_sixteen_0023:
        show fawn n bla with dis
        "我蹲下身，他爬到我背上，双臂环住我的脖子。"
    translate None chapter_sixteen_0024:
        show leos n smi with dis
        l "可怜的小西纳库洛斯，是那对小短腿累了吗？"
    translate None chapter_sixteen_0025:
        show cyne n hap with dis
        c "才不是，是我的屁股昨晚被雷恩操得太狠。"
    translate None chapter_sixteen_0026:
        show fawn n emb at shake
        f "什么？！"
    translate None chapter_sixteen_0027:
        show leos n sur with dis
        v sur "天啊。"
    translate None chapter_sixteen_0028:
        "莱奥斯的嘴巴因赛恩的话张成了完美的圆形。"
    translate None chapter_sixteen_0029:
        show raen n sad with dis
        rs "….赛恩，你不该这样撒谎。"
    translate None chapter_sixteen_0030:
        c "你说得对，我其实没事尽管昨晚—"
    translate None chapter_sixteen_0031:
        rs "赛恩。"
    translate None chapter_sixteen_0032:
        show cyne n sad with dis
        c "好—吧……是我的小短腿累了。可惜那些风流事儿只发生在梦里。"

    show leos n ann
    show fawn n bla
    with dis

    translate None chapter_sixteen_0033:
        "他把我的脑袋搂进怀里，引来福恩和莱奥斯愤怒的视线。"
    translate None chapter_sixteen_0034:
        l "没人想听你扯这些。憋在心里吧。"
    translate None chapter_sixteen_0035:
        show cyne n sur with dis
        c "嘿，雷恩可能想听！他可对我感兴趣得很！"
    translate None chapter_sixteen_0036:
        f "....."

    hide raen
    hide fawn
    hide leos
    hide cyne
    with dis
    scene bg amaranth day:
        xpos 0.56 ypos 1.37 xanchor 0.5 yanchor 1.0 zoom 1.34
    with dissolve

    translate None chapter_sixteen_0037:
        "斗嘴持续了一阵才平息。我们走了几小时，直到日头高悬。没多久赛恩就腻了被背着，觉得招惹莱奥斯和福恩更有趣。"
    translate None chapter_sixteen_0038:
        "阳光温暖宜人，但空气仍透着寒意。霜风掠过树梢，沙沙摇动枝叶。"
    translate None chapter_sixteen_0039:
        "小径崎岖不平，连走路都变得困难。"
    translate None chapter_sixteen_0040:
        "我望向维拉斯。他连鞋都没穿，怎么毫不吃力？"
    translate None chapter_sixteen_0041:
        "说实话，不穿鞋有点奇怪。"


    scene bg amaranth day
    show raen n sur at cenleft
    show veras n o2 neu2 at cenright
    show illran n armsdown neu at farright
    show leos n neu at farleft
    with dissolve

    translate None chapter_sixteen_0042:
        rs "能问你个问题吗，维拉斯？"
    translate None chapter_sixteen_0043:
        v "当然。"
    translate None chapter_sixteen_0044:
        rs "为什么不穿鞋？"
    translate None chapter_sixteen_0045:
        show veras n sur2 with dis
        v "那是因为—"
    translate None chapter_sixteen_0046:
        show illran n con with dis
        i "哇，你没听说吗？"
    translate None chapter_sixteen_0047:
        i "这可是锡德卡汉最火的潮流，象征着力量。没有什么能打败你！无论是路上的石头、严寒，还是那些你总注意不到会撞疼脚趾的小台阶。"
    translate None chapter_sixteen_0048:
        show leos n pen with dis
        rs "等等，真的？"
    translate None chapter_sixteen_0049:
        c neu "....."
    translate None chapter_sixteen_0050:
        c hap "千真万确！锡德卡汉最帅的男人都这么干。唉，我怕是不行…但你该试试，雷恩。"
    translate None chapter_sixteen_0051:
        rs "那…伊尔兰你为什么穿鞋？"
    translate None chapter_sixteen_0052:
        i "我？我没那么勇敢。自认担不起\"世间最强壮男人\"的重任。"
    translate None chapter_sixteen_0053:
        i "维拉斯够强悍，能代表我们俩。"
    translate None chapter_sixteen_0054:
        "余光瞥见莱奥斯打量着自己的靴子。他伸手想脱，最终还是作罢了。"
    translate None chapter_sixteen_0055:
        show raen n sad with dis
        rs "维拉斯，我觉得我没你那么坚强。希望有天我也能脱掉鞋子！"
    translate None chapter_sixteen_0056:
        show illran n hap with dis
        i "噗……"
    translate None chapter_sixteen_0057:
        c hap "是啊…噗…你加油啊，雷恩！"
    translate None chapter_sixteen_0058:
        f sad "这听起来有点—"
    translate None chapter_sixteen_0059:
        c hap "嘘—你！别扫兴。"
    translate None chapter_sixteen_0060:
        show raen n sur with dis
        rs "哦对了，其实还有件事想问你。你刚才说发生了什么事迫使大部分神明降临维迪斯对吧？具体发生了什么？"
    translate None chapter_sixteen_0061:
        show veras n neu2 with dis
        v "…..你听说过奥雷连战争吗？起因是锡德卡汉国王宣布说书人和奥雷连教为非法。"
    translate None chapter_sixteen_0062:
        show illran n neu with dis
        rs "哦，赛恩提到过这事。说皇太子和说书人离开锡德卡汉，秘密建立了奥雷利亚卡维拉。"
    translate None chapter_sixteen_0063:
        v "没错。在那之前，奥雷连教曾遍布整个维迪斯，但被宣布非法后，任何被发现信奉该教的人都会遭受严惩。"
    translate None chapter_sixteen_0064:
        v "说书人离开锡德卡汉时，带走了与神明沟通的唯一途径。我们面临选择：跟他走，被困在奥雷利亚卡维拉苟活；或是留在外面，失去所有信徒。"

    $ about_FallenGods._text = ["500年前，说书人带着信徒离开锡德卡汉，建立了与世隔绝的奥雷利亚卡维拉。神明们面临抉择—追随说书人，但永远无法再守护整个维迪斯；或是拒绝，但因没有信徒而逐渐消亡。\n \n战后数年，随着信仰神明被定为非法，留在奥雷利亚卡维拉外的神明逐渐失去信徒，变得几乎无力，勉强维持生命。他们面临选择：渐渐消逝最终死亡，或付出珍贵代价化为人形。 \n \n有些选择拒绝，终得安息；有些选择接受，找到可依附的躯体以人类身份存活。 "]

    translate None chapter_sixteen_0065:
        v "如你所知，没有信徒就意味着消亡。{a=set_entry:enc_lore->about_FallenGods}{color=#87CEEB}我们多数选择了离开{/color}{/a}。有些决定铤而走险留下来守护维迪斯。失去信徒后，我们力量尽失坠入凡间，要么寻找可依附的躯体，要么选择死亡。"
    translate None chapter_sixteen_0066:
        show veras n sad2 with dis
        v "你已知道后来发生的事。我们中许多人被找到杀害，有些遭受酷刑与实验，还有些融入人类社会继续生活。我们仍在寻找存在的意义。"
    translate None chapter_sixteen_0067:
        show raen n sad with dis
        rs "那么…言者{i}确实{/i}能与诸神对话？我本已开始质疑他…"
    translate None chapter_sixteen_0068:
        v "没错。不过我猜，被长期囚禁在奥雷利亚卡维拉令他们极为不悦。他想控制他们绝非易事。"
    translate None chapter_sixteen_0069:
        rs "….他为何要囚禁他们？为何不放他们自由？"
    translate None chapter_sixteen_0070:
        v "不得而知。我从未见过你的说书人，也无法联系被困的同族。五百年间，万事皆可能改变。"
    translate None chapter_sixteen_0071:
        v "他本应是我们与凡世的纽带。虽然…现在能直接与你们对话也不错。"
    translate None chapter_sixteen_0072:
        v "雷恩，可否请教个问题？"
    translate None chapter_sixteen_0073:
        rs "嗯？当然。"
    translate None chapter_sixteen_0074:
        v "若我要你现在回到奥雷利亚卡维拉并终生囚禁，你愿意吗？你将永远无法再与福恩、赛恩或任何你认识的人交谈。"
    translate None chapter_sixteen_0075:
        v "你会想要那样的生活吗？"
    translate None chapter_sixteen_0076:
        rs "......"
    translate None chapter_sixteen_0077:
        rs "….我从未感到身陷囹圄，那时的我们懵懂无知。但现在…"
    translate None chapter_sixteen_0078:
        rs "若明知外界种种却要重回牢笼…我做不到。"
    translate None chapter_sixteen_0079:
        show veras n smi2 with dis
        "他又对我笑了笑。"
    translate None chapter_sixteen_0080:
        v "正是。我相信这也是他们的感受。他们被割裂于所爱所守护的一切。换作是我，定会让怒火化为实质。"
    translate None chapter_sixteen_0081:
        show raen n sur with dis
        rs "如何做？"
    translate None chapter_sixteen_0082:
        v "简单的事。让风渐弱，使土地贫瘠…长久累积终会逼人行动。"
    translate None chapter_sixteen_0083:
        show raen n sad with dis
        rs "这…"
    translate None chapter_sixteen_0084:
        l "…与近年的境况相差无几。"
    translate None chapter_sixteen_0085:
        l "我要确认清楚。你是说一群神明被困奥雷利亚卡维拉，为求脱身不惜将人间变炼狱？"
    translate None chapter_sixteen_0086:
        v "这是他们发声的唯一方式。"
    translate None chapter_sixteen_0087:
        rs "为何外界无人信仰他们？"
    translate None chapter_sixteen_0088:
        show veras n sad2 with dis
        v "嗯…仍有少数人暗中供奉各自的神明，但为数不多。"
    translate None chapter_sixteen_0089:
        f sad "我的家人…曾经，我们也敬奉着一位神明，但父母总是告诫我们绝不能向任何人提及此事。"
    translate None chapter_sixteen_0090:
        c neu "我们确实从未提起。在锡德卡汉，信奉任何神明都无异于自杀—无论是社交性死亡还是真正丧命。"
    translate None chapter_sixteen_0091:
        "如果说书人真是他自称的那种存在…那我的命运必定是正确的，对吗？我开始怀疑…或许…他告诉我的并非真相。也许我的「审判」实际上…是个谎言。"
    translate None chapter_sixteen_0092:
        "也许我可以成为有价值的人…"
    translate None chapter_sixteen_0093:
        "…但这不重要。神明们—像维拉斯这样的人—正违背意愿被困在那里，而说书人对此心知肚明。他知道，却任他们囚禁其中。"
    translate None chapter_sixteen_0094:
        show leos n pen with dis
        l "….我不喜欢你眼中的神色。别试图卷入与你无关的事情。"
    translate None chapter_sixteen_0095:
        rs "到如今真的与我无关吗？我…我想帮助他们！也许，总有办法，我们可以—"
    translate None chapter_sixteen_0096:
        v "循序渐进，雷恩。这份心意很好，但你应该先解开自己的谜题。"
    translate None chapter_sixteen_0097:
        v "解救他们绝非易事。即便我们真能找到奥雷利亚卡维拉，我也不知你打算如何释放他们。"
    translate None chapter_sixteen_0098:
        rs "但我很清楚它的位置。"
    translate None chapter_sixteen_0099:
        v "这不是关键问题。那里笼罩着排斥陌生人的异常迷雾。"
    translate None chapter_sixteen_0100:
        f sur "….！我也遇到过！"
    translate None chapter_sixteen_0101:
        f "我沿着河道行走，结果恍惚间又回到了自家门前。那段记忆完全空白！"
    translate None chapter_sixteen_0102:
        rs "那么就连…有朝一日回家也成为奢望了吗？"
    translate None chapter_sixteen_0103:
        show veras n smi2 with dis
        v "没有不可能的事，但要专注眼前目标，否则只会绊倒自己。你需要先找到卡斯皮安，对吧？"
    translate None chapter_sixteen_0104:
        rs "…没错。这是第一步。然后…我们再逐步解决其他问题。"
    translate None chapter_sixteen_0105:
        v "没错。"

    show bird flip with dis:
        xpos 0.62 ypos 0.98 xanchor 0.7 yanchor 1.0 zoom 0.77

    translate None chapter_sixteen_0106:
        "一只嫩黄色的小鸟从树枝间飞出，落在维拉斯肩头。眨眼间，卡斯已伫立在他身旁。"

    hide raen
    show fawn n sur at cenleft
    with dis

    translate None chapter_sixteen_0107:
        v "哈哈，知道拥有人类身体最棒的一点是什么吗？现在是我可以抚摸别人了。"
    translate None chapter_sixteen_0108:
        "他抬手轻抚小鸟的脑袋和喙，鸟儿发出欢快的啁啾声。"
    translate None chapter_sixteen_0109:
        v "不过也有点伤感。随着年岁增长，身边愿意被我抚摸的人越来越少了。"
    translate None chapter_sixteen_0110:
        show illran n hap with dis
        i "我确定如果你有礼貌地请求，很多人会很高兴让你摸摸他们。"
    translate None chapter_sixteen_0111:
        rs smi "哦，你应该试试问问看，伊尔兰！"
    translate None chapter_sixteen_0112:
        i "我？"
    translate None chapter_sixteen_0113:
        i "哦，维拉斯，你能行行好拍拍我的头吗？"
    translate None chapter_sixteen_0114:
        v "哈哈哈，当然可以！"
    translate None chapter_sixteen_0115:
        "他伸出手抚平了伊尔凌乱蓬松的头发。"
    translate None chapter_sixteen_0116:
        v "那你呢，雷恩？还有福恩？"
    translate None chapter_sixteen_0117:
        "我们都低下头，维拉斯轻轻拍了拍我们的脑袋。如果让我猜今天会做什么，被神明抚摸绝不会是我的首选。"
    translate None chapter_sixteen_0118:
        v "莱奥斯？"
    translate None chapter_sixteen_0119:
        l "不了谢谢。"
    translate None chapter_sixteen_0120:
        show veras n sur2 with dis
        v "嗯…那你更希望雷恩来摸吗？"
    translate None chapter_sixteen_0121:
        show leos n emb with dis
        l "什么？！才不是！我是说…除非他想…"
    translate None chapter_sixteen_0122:
        c hap "哦，哦，我也要！我想要摸摸头！"
    translate None chapter_sixteen_0123:
        show fawn n shy with dis
        "福恩快速瞥了我几眼又看向地面，试图引起我的注意。"
    translate None chapter_sixteen_0124:
        rs smi "你也想要摸摸吗，福恩？"
    translate None chapter_sixteen_0125:
        f "啊，好的！"
    translate None chapter_sixteen_0126:
        "我几乎能看到他开心摇晃的尾巴。他就像只小狗崽。"
    translate None chapter_sixteen_0127:
        show leos n smi with dis
        l "你知道吗，你平时是个讨厌鬼，但在这家伙面前就很听话嘛？你欠他什么？"
    translate None chapter_sixteen_0128:
        i "这话从你嘴里说出来真是讽刺得可笑。"
    translate None chapter_sixteen_0129:
        rs sur "不不，莱奥斯，你搞错了！我知道他们怎么回事。"
    translate None chapter_sixteen_0130:
        rs smi "他们结婚了！"

    show illran n emb at shake
    show veras n emb2 at shake
    show bird flip at shake


    translate None chapter_sixteen_0131:
        iv "噗哈哈哈哈哈哈…..！"
    translate None chapter_sixteen_0132:
        i "什么？！你…你大错特错！我们是朋友，只是朋友！"
    translate None chapter_sixteen_0133:
        v "哈哈哈…雷恩…你很可爱，但我们俩…没错，只是朋友。"
    translate None chapter_sixteen_0134:
        i "说真的，神明和人类？那简直是…等着出事，对吧？"
    translate None chapter_sixteen_0135:
        "他用余光偷瞄维拉斯。"

    show veras n sad2 with dis

    translate None chapter_sixteen_0136:
        v "…..确实。绝无可能。"
    translate None chapter_sixteen_0137:
        show illran n sad with dis
        i "而且我看起来像是会安定下来结婚的类型吗？别犯傻。"
    translate None chapter_sixteen_0138:
        rs sur "啊，你说得对。抱歉，我只是看你们相处的样子猜的。看来我错了。"

    scene bg amaranth night with dissolve:
        xpos 0.54 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.23
        linear 30.0 xpos 0.54 ypos 1.59 xanchor 0.5 yanchor 1.0 zoom 1.23

    translate None chapter_sixteen_0139:
        "对话尴尬地逐渐沉寂，伊尔兰稍走在前方带队，尽管路只有一条。"
    translate None chapter_sixteen_0140:
        "时间缓慢流逝，很快太阳已开始西沉。我们迅速找了过夜的地方。"
    translate None chapter_sixteen_0141:
        c sad "我饿死了…"
    translate None chapter_sixteen_0142:
        f sad "我也是…"
    translate None chapter_sixteen_0143:
        v sad "…真希望能给你们弄点吃的…"
    translate None chapter_sixteen_0144:
        i con "我去打点晚餐。我经常这么干。"
    translate None chapter_sixteen_0145:
        v smi "让我来帮忙。"
    translate None chapter_sixteen_0146:
        i neu "你们三个就待在这儿。我离开期间，可不想收到任何关于儿童失踪的报告，明白吗？"
    translate None chapter_sixteen_0147:
        "他将索伦的身体轻轻倚靠在树上，而后转身带着维拉斯离去，两人逐渐被渐浓的暮色吞没。"
    translate None chapter_sixteen_0148:
        "他看上去仍像是在安睡…但如果他在这负面情绪会被放大的地方醒来，那将酿成大祸。"

    scene bg amaranth night with dissolve
    show leos n dark neu at farright
    show raen n dark neu at cenright
    show cyne n dark neu at cenleft
    show fawn n dark neu at farleft
    with dis

    translate None chapter_sixteen_0149:
        l "总算清净了。也许终于能得会儿安宁。"
    translate None chapter_sixteen_0150:
        show cyne n dark hap with dis
        c "哎呀福恩，你该主动跟他们去的！你打猎肯定很棒！"
    translate None chapter_sixteen_0151:
        show fawn n dark sad with dis
        f "我…不会猎杀动物。我做不到。"
    translate None chapter_sixteen_0152:
        show cyne n dark sur with dis
        c "怎么，你是素食主义者还是怎么？"
    translate None chapter_sixteen_0153:
        f "…如果别人给我食物我会吃，但我自己绝不会主动捕猎。"
    translate None chapter_sixteen_0154:
        show cyne n dark hap with dis
        c "哈。我还以为你会是个顶尖的连环杀手呢。可爱的外表下说不定藏着狂野的本性！"
    translate None chapter_sixteen_0155:
        f "....."
    translate None chapter_sixteen_0156:
        f "这一点都不好笑。我不是杀人犯。"
    translate None chapter_sixteen_0157:
        show raen n dark sad with dis
        c "但想象一下如果你是！外表与隐秘人格的反差…多性感啊！"
    translate None chapter_sixteen_0158:
        show fawn n dark bla with dis
        stop music fadeout 1.0
        f "你觉得死亡好笑吗？这是能开玩笑的事吗？要是闲得慌就去纠缠别人。"
    translate None chapter_sixteen_0159:
        "他转身背对赛恩，脸上闪过一丝愠怒。"
    translate None chapter_sixteen_0160:
        "在此之前，我从没见过他这般…尖锐。他通常只会支支吾吾，从不为自己辩解。我猜是赛恩的缘故。他最懂得怎么激怒别人。"
    translate None chapter_sixteen_0161:
        show cyne n dark sad with dis
        c "好吧好吧。我识趣。雷恩，你会理我的对吧？"
    translate None chapter_sixteen_0162:
        rs "当然，随时奉陪。"
    translate None chapter_sixteen_0163:
        f "...."
    translate None chapter_sixteen_0164:
        f "我去透透气。"

    hide fawn with dissolve
    show leos at right
    show cyne at left
    show raen at center
    with move

    translate None chapter_sixteen_0165:
        "不等我们反对，他的身影已没入树林。"
    translate None chapter_sixteen_0166:
        rs "…我去找他。"
    translate None chapter_sixteen_0167:
        "我刚要起身，赛恩就横臂拦住去路。"
    translate None chapter_sixteen_0168:
        show cyne n dark hap with dis
        c "让我去！我去找他！"
    translate None chapter_sixteen_0169:
        rs "呃…好吧，如果你坚持。"

    hide cyne with dissolve
    show raen dark at slightleft
    show leos dark at slightright
    with move

    translate None chapter_sixteen_0170:
        "他朝福恩离去的方向飞奔，脸上挂着笑意。"
    translate None chapter_sixteen_0171:
        show leos n cur with dis
        l "这决定真的妥当吗？"
    translate None chapter_sixteen_0172:
        show raen n sur with dis
        rs "什么意思？"
    translate None chapter_sixteen_0173:
        l "福恩厌恶那家伙。你没注意他对话时的语气吗？看人的眼神吗？他巴不得对方立刻消失。"
    translate None chapter_sixteen_0174:
        l "我尚不确定，但若此地传说属实，他们俩最不该被单独留下。"
    translate None chapter_sixteen_0175:
        show raen n sad with dis
        rs "别犯傻了。我敢肯定赛恩绝不会伤害福恩。"
    translate None chapter_sixteen_0176:
        show leos n ang with dis
        l "我不是这个意思。"
    translate None chapter_sixteen_0177:
        i hap "老爹赚大钱回家啦！"
    translate None chapter_sixteen_0178:
        "伊尔兰和维拉斯再次出现，一个拎着几只兔子，另一个抱着一捆柴火和引火柴。"
    translate None chapter_sixteen_0179:
        rs "你自称老爹的样子真是令人毛骨悚然。"
    translate None chapter_sixteen_0180:
        i neu "那群小鬼去哪了？我不是让你们待在原地吗？"
    translate None chapter_sixteen_0181:
        rs "福恩去透气了，赛恩去找他了。"
    translate None chapter_sixteen_0182:
        i neu "我们在户外时还要出去\"透气\"，是吧。不过食物的香味应该很快就会把他们引回来。"
    translate None chapter_sixteen_0183:
        "我回头望向他们几分钟前离开的方向，此时伊尔兰已经生起了火，开始处理肉类。"
    translate None chapter_sixteen_0184:
        rs "…你觉得福恩会伤害他？不可能，他连只苍蝇都不敢伤害。"
    translate None chapter_sixteen_0185:
        l "…我不太确定—"
    translate None chapter_sixteen_0186:
        c sad "啊啊啊！！！！"

    show raen at left
    show leos at right
    with move

    show cyne n dark sca at center with dis
    play music "sounds/bgm/creepy.ogg" fadeout 2.0

    translate None chapter_sixteen_0187:
        "黑暗中，赛恩气喘吁吁地冲回营地。在他跌倒前，我跳起来接住了他。"
    translate None chapter_sixteen_0188:
        show raen n sur with dis
        rs "怎么了？！你没事吧？"
    translate None chapter_sixteen_0189:
        c "他…他疯了！他是个疯子！他要…他想…"
    translate None chapter_sixteen_0190:
        rs "冷静点，给我说清楚！"
    translate None chapter_sixteen_0191:
        show cyne n sad with dis
        c "我只是…只是想稍微逗逗他而已，明白吗？但他突然暴怒了！"
    translate None chapter_sixteen_0192:
        i neu "你觉得现在是激怒别人的时候和地方吗？"
    translate None chapter_sixteen_0193:
        c "我真没想到他会当真！我只是想找点乐子！"
    translate None chapter_sixteen_0194:
        l "要知道，他可比看起来强悍多了。生气时只是憋在心里。"
    translate None chapter_sixteen_0195:
        l "起初我以为他很软弱，但他证明了自己能独当一面。要我说，最好别惹他。"
    translate None chapter_sixteen_0196:
        "伊尔兰从原地站起身，放下没处理完的食物。他转向维拉斯低声交谈了几句。"
    translate None chapter_sixteen_0197:
        i neu "我去找他。不能让他走丢了。"
    translate None chapter_sixteen_0198:
        f bla "......"
    translate None chapter_sixteen_0199:
        "一道蓝色身影旋风般冲进营地，直扑我们而来。他从兔背上拔出刀子，举在身前。"

    window hide dissolve

    scene gallery_70 with dissolve
    window show dissolve

    translate None chapter_sixteen_0200:
        "他的眼神空洞无物。这种神情我从未见过，与我认识的那个善良羞涩的福恩判若两人。"
    translate None chapter_sixteen_0201:
        "他向赛恩走去，后者的脸已因恐惧而扭曲。刹那间，莱奥斯和我同时挡在他面前，张开双臂保护他。"
    translate None chapter_sixteen_0202:
        rs sad "福恩，等一下。你在干什么？把那个放下。"
    translate None chapter_sixteen_0203:
        l pen "没这个必要。冷静下来我们可以好好谈谈，好吗？"
    translate None chapter_sixteen_0204:
        f "不！不，我不会冷静！"
    translate None chapter_sixteen_0205:
        f "他活该遭到报应。我要在这里杀了他！让他的血浸透周围的树根滋养这些树木！"
    translate None chapter_sixteen_0206:
        f "他…他会死在这里！"
    translate None chapter_sixteen_0207:
        i neu "住手。这不是你真实的想法。你被情绪控制了。"
    translate None chapter_sixteen_0208:
        rs sad "试着冷静下来好吗？我们可以用非暴力方式解决这个问题。"
    translate None chapter_sixteen_0209:
        "他的脸色越来越愤怒，篝火随之剧烈翻腾，呼应着他的情绪。伊尔兰再次对维拉斯耳语，后者转向福恩。"
    translate None chapter_sixteen_0210:
        v sad "福恩，请把那个放下。赛恩对你没有恶意，你也不想伤害他。"
    translate None chapter_sixteen_0211:
        "福恩朝我们—朝赛恩的方向迈了几步。赛恩惊恐地尖叫着往后缩。"


    scene gallery_71 with dissolve
    translate None chapter_sixteen_0212:
        f "从你第一次出现时我就知道你是祸害。你只想把雷恩带走伤害他！你不在乎他，也不在乎我们任何人，只在乎你自己。"
    translate None chapter_sixteen_0213:
        f "你就是个自恋、没用、被宠坏的混蛋，想玷污你看到的一切！你唯一的价值就是被埋在地下六尺处当肥料！"
    translate None chapter_sixteen_0214:
        c sad "不…不是的，我—"
    translate None chapter_sixteen_0215:
        f "闭嘴！！！你敢跟我说话！你不配！"
    translate None chapter_sixteen_0216:
        "火焰骤然升腾，在我们周围投下威胁的阴影。"
    translate None chapter_sixteen_0217:
        "伊尔兰在福恩身后向莱奥斯打手势。莱奥斯对他点头示意，用口型说数到三就制服他。"
    translate None chapter_sixteen_0218:
        "一，二…三！他们同时扑了上去。"


    scene bg amaranth night at shake

    translate None chapter_sixteen_0219:
        f bla "啊，放开我！我说放开，不然连你们一起收拾！"
    translate None chapter_sixteen_0220:
        "尽管被伊尔兰和莱奥斯按在地上，福恩仍在疯狂挣扎扭动，眼看就要挣脱。"
    translate None chapter_sixteen_0221:
        i neu "雷恩，我后兜有个瓶子。快！拿出来灌进他喉咙！"
    translate None chapter_sixteen_0222:
        rs sad "什…什么..？"
    translate None chapter_sixteen_0223:
        i neu "快！没时间让你犹豫了！"
    translate None chapter_sixteen_0224:
        "我急忙在伊尔兰的后兜翻找，摸到一小瓶不明液体。福恩仍在嘶吼咒骂拼命挣扎。"
    translate None chapter_sixteen_0225:
        "对不起福恩…希望这个能帮到你。"
    translate None chapter_sixteen_0226:
        "我在他身旁跪下，强行掰开他的嘴灌了进去。他眼中充满憎恶，当这目光直直投向我时…这让我痛心。"
    translate None chapter_sixteen_0227:
        "只过了片刻，他的头便歪向一边，不再反抗我们。"
    translate None chapter_sixteen_0228:
        i neu "啧，他比我预想的强壮多了。幸好有人帮忙才制住他。"
    translate None chapter_sixteen_0229:
        "他的胸膛微微起伏，脸上愤怒的表情终于褪去。他像个天使般沉睡着。"
    translate None chapter_sixteen_0230:
        l ang "别看这小个子身材单薄，挥起拳头可真不含糊。"
    translate None chapter_sixteen_0231:
        "赛恩仍呆立原地，低头看着昏迷的福恩。"
    translate None chapter_sixteen_0232:
        i neu "别往心里去。阿玛兰斯会缠上满腔怒火又意志薄弱的人，福恩这两点都符合。刚才那不是真正的他。"
    translate None chapter_sixteen_0233:
        c sad "当…当然…我明白…"
    translate None chapter_sixteen_0234:
        "难以置信…这一切居然发生了…"
    translate None chapter_sixteen_0235:
        "森林能对人影响至此？真是某位滞留神灵的作为吗？我认识的福恩与方才所见判若两人。"
    translate None chapter_sixteen_0236:
        rs sad "我给他灌了什么？"
    translate None chapter_sixteen_0237:
        i neu "只是安眠药剂。他会昏睡一阵子，但无害。或许他正需要时间冷静。"
    translate None chapter_sixteen_0238:
        "我轻轻抱起他挪近篝火，以免他夜间受寒。他头发凌乱，缠满打斗时沾上的叶子与泥土。我尽力清理后转身面向众人。 "
    translate None chapter_sixteen_0239:
        i neu "至少今晚不用安排守夜了。"
    translate None chapter_sixteen_0240:
        rs sur "什么，为什么？"
    translate None chapter_sixteen_0241:
        i neu "队伍里两个危险分子都倒下了，而且目睹那番场景后，我想谁也没力气再争斗了。"
    translate None chapter_sixteen_0242:
        i "今夜，我们只需休息。"
    translate None chapter_sixteen_0243:
        "余下的夜晚几乎无人交谈。伊尔兰和维拉斯各怀心事，赛恩缄默不语，莱奥斯则早早睡去。"
    translate None chapter_sixteen_0244:
        "我辗转反侧难以入眠。太多事情萦绕心头，更担心福恩的状况。"
    translate None chapter_sixteen_0245:
        "最终睡意袭来，将我拽入又一个至寂空旷的梦境。"

    stop music fadeout 2.0
    window hide dissolve
    scene black with eye_shut

    if illranveras_friend >= 2:
        $ iv_scene_one = True
        jump iv_sceneone_start

    else:
        jump chapter_sixteen_continue


label iv_sceneone_start:
    pause(1.0)
    scene bg amaranth night with dissolve:
        xpos 0.58 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.66
        linear 45.0 xpos 0.58 ypos 2.2 xanchor 0.5 yanchor 1.0 zoom 1.66
    window show dissolve
    translate None chapter_sixteen_0246:
        "夜深时分，两名男子背靠树干守着营地。一个双手枕在脑后轻声吹口哨，另一个十指交叠置于膝上，跟着哼起小调。"


    scene bg amaranth night:
        xpos 0.55 ypos 1.8 xanchor 0.5 yanchor 1.0 zoom 1.67

    show veras m dark smi at closeleft
    show illran m dark armsdown neu at closeright:
        xpos 0.2 ypos 1.0 xanchor -0.25 yanchor 1.0
    with dissolve
    play music "sounds/bgm/night.ogg" fadeout 2.0

    translate None chapter_sixteen_0247:
        v "你说过不需要有人守夜，但实际上你的意思是由你来值守。"
    translate None chapter_sixteen_0248:
        "伊尔兰的目光游移至维拉斯身上。篝火温暖跃动的火光与月亮清冷的银色光芒，映照着他白皙的肌肤，更衬出他精致的五官。"
    translate None chapter_sixteen_0249:
        "他的面容如静谧面具，眼角却含着若有似无的笑意。"
    translate None chapter_sixteen_0250:
        imn"不知为何，他正享受着这一切。所有这些纷扰。比起往常，此刻要热闹得多。"
    translate None chapter_sixteen_0251:
        show illran m con with dis
        i "总得有人看着，免得他们溜走或伤着自己。瞧他们闹出的动静，还以为是一群毛头小子。"
    translate None chapter_sixteen_0252:
        show veras m sad with dis
        v "这无疑是个多事的夜晚，但把这么多强势个性聚在一处，迟早会有人崩溃。"
    translate None chapter_sixteen_0253:
        v "虽然最后相安无事，我却担心后续发展。但愿他们能重修于好。"
    translate None chapter_sixteen_0254:
        show illran m sad with dis
        i "也没什么好调解的。听这情形，他们从一开始就互看不顺眼。罢了，谁知道呢。与我无关。"
    translate None chapter_sixteen_0255:
        "维拉斯抬手将几缕蜜桃色发丝别到耳后。当他眨动纤长黑睫时，那抹暗色擦过他苍白肌肤，形成鲜明对比。"
    translate None chapter_sixteen_0256:
        show veras m smi with dis
        v "看来你比愿意承认的还要在意他们。"
    translate None chapter_sixteen_0257:
        show illran m neu with dis
        i "呵，纯粹是自私罢了。我想要他们的秘密，确信这些能助你进入奥雷利亚卡维拉。眼下我们先静观其变，帮他们处理索伦的事。之后，再各取所需。"
    translate None chapter_sixteen_0258:
        show veras m sad with dis
        v "...."
    translate None chapter_sixteen_0259:
        v "你说得像在策划战术，不过我并不反对。"
    translate None chapter_sixteen_0260:
        show illran m neu with dis
        i "你该睡了。我一个人警戒没问题。"
    translate None chapter_sixteen_0261:
        v "其实…我更想留在这里陪你。"
    translate None chapter_sixteen_0262:
        v "…..我并不困，但总觉得应该疲倦。说真的，即使现在…还能感受到诺克斯的能量在我体内奔流，从头顶直达脚尖。这种感觉…很不对劲。"
    translate None chapter_sixteen_0263:
        show illran m sad with dis
        i "..."
    translate None chapter_sixteen_0264:
        i "…..有件事想问你。若你不愿谈及也无妨，我会尊重。"
    translate None chapter_sixteen_0265:
        i "这件事我…早有察觉，只是始终找不到合适时机开口。当诺克斯提及他的遭遇时，你说也曾经历过类似的事。我…不想越界，但是—"
    translate None chapter_sixteen_0266:
        show veras m neu with dis
        v "不，没关系。你知道我愿意与你分享一切。"
    translate None chapter_sixteen_0267:
        v "…那是很久以前的事了，可我的身体至今仍觉得恍如昨日。父母去世几年后，我住在斯诺登海角的拉斯特米尔城。"
    translate None chapter_sixteen_0268:
        v "你听说过拉斯特米尔吗？"
    translate None chapter_sixteen_0269:
        i "略有耳闻。如果我没记错的话，他们曾以医学研究闻名。在那个领域他们总是处于前沿。"
    translate None chapter_sixteen_0270:
        show veras m smi with dis
        "维拉斯露出温柔而哀伤的微笑。"
    translate None chapter_sixteen_0271:
        v "是的…没错。奥雷利亚战争后，锡德卡汉国王委托当地领主进行这项研究，向人们证明他们不必信仰神明—只需要科技。"
    translate None chapter_sixteen_0272:
        v "父母去世后，我认为可以传承他们留给我知识，帮助世界变得更美好。于是我前往拉斯特米尔，用几年时间行医授课。"
    translate None chapter_sixteen_0273:
        v "那段日子还算平静。但像我们这样的人，似乎永远无法长久安宁。有人指控我是女巫，我立即被关进拉斯特米尔的地牢。"
    translate None chapter_sixteen_0274:
        show veras m dark fro with dis
        v "他们在那里做的事…至少可以说，令人发指。医药研究或许突飞猛进，但代价是什么？我很好奇他们从我的痛苦中学到了多少。"
    translate None chapter_sixteen_0275:
        i "我…不知道…你为什么不试着逃跑…？"
    translate None chapter_sixteen_0276:
        show veras m sad with dis
        v "我本可以逃。我想过逃走，但是…我听说还有其他囚犯。他们不像我。他们不是神，不是恶魔，不是\"女巫\"，也不是人类惯常恐惧的任何存在。他们只是普通人。有些是被拘留者的孩子，有些是无家可归的孤儿。"
    translate None chapter_sixteen_0277:
        v "我从未见过他们的脸，但我听见他们的尖叫与哀求，感受到他们的灵魂在呼求救赎。我经历的痛苦已难以言表，但听到那些尖叫，听到孩子们哭喊着要父母的尖叫，更令人崩溃。"
    translate None chapter_sixteen_0278:
        v "我不能…我不能丢下他们独自逃走。没人会帮助他们。当我逃脱时，我确保那个研究所永远无法再使用。那个领主没活多久，任何胆敢碰那些囚犯的人也都没有好下场。"
    translate None chapter_sixteen_0279:
        v "这不是值得骄傲的事，但我也绝不后悔。"
    translate None chapter_sixteen_0280:
        i "...."
    translate None chapter_sixteen_0281:
        imn "然而他的身体却完美无瑕。若非神明之躯，本应伤痕遍布。"
    translate None chapter_sixteen_0282:
        imn "它们只是藏在了我看不见的地方，掩埋在层层镇定之下。维拉斯…"
    translate None chapter_sixteen_0283:
        v "你觉得呢？这并不会让我比诺克斯好多少，对吧？或许我能自我辩解，但杀戮的理由就能使行为变得情有可原吗？"
    translate None chapter_sixteen_0284:
        i "…别拿自己和他比较。你们截然不同。那就是诺克斯的全部所为。他为复仇杀人，为快感杀人，甚至只为取乐。这与保护无辜性命有着天壤之别。"
    translate None chapter_sixteen_0285:
        i "也许我不是最佳判官，我自己也双手沾满鲜血，但若易地而处，我同样会做出和你一样的选择。"
    translate None chapter_sixteen_0286:
        show veras m smi with dis
        v "…谢谢你，伊尔兰。我并非寻求认可或同情，但很高兴你仍愿意接纳这个满身缺点的我。知道吗，比起初遇时，你真的成长了许多。"
    translate None chapter_sixteen_0287:
        show illran m emb with dis
        i "那时的我不过是个鲁莽冲动的毛头小子。现在想来实在难为情。真希望把那段时间从记忆里抹去。"
    translate None chapter_sixteen_0288:
        v "你确实莽撞，却也有可爱之处。当年的你可不会这么轻易接纳我。"
    translate None chapter_sixteen_0289:
        i "这都要归功于你，知道吗。如果没有你—"

    show veras m sad
    show illran m sad
    with dis

    translate None chapter_sixteen_0290:
        v "无论如何你都会过得很好。你有清醒的头脑和坚定的心。即便我不在了，你也能安然前行。"
    translate None chapter_sixteen_0291:
        show veras m smi with dis
        "维拉斯平静的神情恍惚了一瞬，旋即化作柔和的浅笑。每当他想要安抚他人时，总会露出这样的笑容。"
    translate None chapter_sixteen_0292:
        show illran m neu with dis
        i "听着，就算要耗费一生光阴我也会帮你。天涯海角随你差遣，赴汤蹈火在所不辞。"
    translate None chapter_sixteen_0293:
        v "...."
    translate None chapter_sixteen_0294:
        v "我不会这般要求你，但心意领了。你该有属于自己的人生。我已经占用了你七年时光，这实在是…不可饶恕。"
    translate None chapter_sixteen_0295:
        imn "是啊。这一切终有尽时。他也不希望永恒。对他而言，我的生命不过转瞬即逝。"
    translate None chapter_sixteen_0296:
        i "…当然。不过我觉得我们正在靠近，所以你还得忍受我一阵子。"
    translate None chapter_sixteen_0297:
        "维拉斯轻声笑着，将手搭在伊尔兰肩头轻捏了一下。"
    translate None chapter_sixteen_0298:
        v "我想我能做到。"
    translate None chapter_sixteen_0299:
        "两人继续看守营地数小时，随后并排睡去。"

    stop music fadeout 2.0
    window hide dissolve
    scene black with eye_shut
    jump chapter_sixteen_continue

label chapter_sixteen_continue:
    pause(1.0)
    scene bg amaranth day with eye_open:
        size(1920,1080)
    window show dissolve

    translate None chapter_sixteen_0300:
        l neu "嘿，雷恩。醒醒。"

    show raen n neu at slightleft
    show leos n neu at slightright
    with dissolve

    translate None chapter_sixteen_0301:
        rs "嗯…"
    translate None chapter_sixteen_0302:
        "我从睡卧处坐起身，舒展肩膀。坚硬冰冷的林地对我酸痛的背脊毫无助益。"
    translate None chapter_sixteen_0303:
        show raen n sur with dis
        rs "难得见你第一个起床。"
    translate None chapter_sixteen_0304:
        show leos n pen with dis
        l "第一个起？我几乎没怎么睡。"
    translate None chapter_sixteen_0305:
        l "倒不是我想挑剔，但这确实算不上我们住过最奢华的地方。"
    translate None chapter_sixteen_0306:
        show raen n sad with dis
        rs "我不记得我们住过什么特别奢华的地方…索伦的宅邸是很棒，但…"
    translate None chapter_sixteen_0307:
        l "我懂你意思。该动身了—伊尔兰和维拉斯刚去侦察，福恩还昏睡着，至于赛恩…他独自坐在那边，今早没和我说过一句话。"
    translate None chapter_sixteen_0308:
        play music "sounds/bgm/sad.ogg" fadeout 2.0
        rs "这…不像他作风…"
    translate None chapter_sixteen_0309:
        l "他似乎还没从发生的事情中缓过来。你去和他聊聊？"

    hide leos with dissolve

    translate None chapter_sixteen_0310:
        "我望向赛恩所在之处。他垂眸盯着地面，面无表情。我缓步靠近，挥手引起他注意。"
    translate None chapter_sixteen_0311:
        show cyne n sad at slightright with dissolve
        rs "嘿，赛恩…你还好吗？"
    translate None chapter_sixteen_0312:
        c "我…没事。挺好的。"
    translate None chapter_sixteen_0313:
        rs "但你看起来—"
    translate None chapter_sixteen_0314:
        c "你该去看看他。他从昨晚起就没动过。"
    translate None chapter_sixteen_0315:
        "他朝福恩躺着的方向点头—熄灭的篝火旁，那人确实纹丝未动。"
    translate None chapter_sixteen_0316:
        rs "好吧…需要什么就叫我，行吗？"
    translate None chapter_sixteen_0317:
        c "嗯…"


    scene bg amaranth day with Dissolve(1.0):
        xpos 0.94 ypos 1.71 xanchor 0.5 yanchor 1.0 zoom 1.48
        linear 70.0 xpos 0.03 ypos 1.71 xanchor 0.5 yanchor 1.0 zoom 1.48
        linear 70.0 xpos 0.94 ypos 1.71 xanchor 0.5 yanchor 1.0 zoom 1.48
        repeat

    translate None chapter_sixteen_0318:
        "我走到福恩身旁，用手背贴上他的脸颊。触感微凉，但不足为奇—毕竟整夜严寒刺骨。"
    translate None chapter_sixteen_0319:
        "他的胸膛轻微起伏，呼吸平稳。我想另寻休憩处，但现在不行。就快到了。"
    translate None chapter_sixteen_0320:
        i neu "看来他还昏迷着。不意外。"
    translate None chapter_sixteen_0321:
        rs sad "啊，伊尔兰，你回来了。他什么时候能醒？"
    translate None chapter_sixteen_0322:
        i neu "大概今晚。那药效很强，但不足以让人昏睡数日。我们得抬着他走。"
    translate None chapter_sixteen_0323:
        "他走近索伦，在维拉斯协助下将人扛上肩头。"
    translate None chapter_sixteen_0324:
        i neu "递给我吧，我能同时背两个。"
    translate None chapter_sixteen_0325:
        l pen "……不必。我来背他。"
    translate None chapter_sixteen_0326:
        i con "怕我会咬人吗？"
    translate None chapter_sixteen_0327:
        l pen "...."
    translate None chapter_sixteen_0328:
        "莱奥斯无言地将福恩抱起。这个动作让福恩显得娇小脆弱。莱奥斯低头看着他，眉头紧锁。"
    translate None chapter_sixteen_0329:
        l pen "他轻得像没重量，而你已经要背一个人了。我来照顾他吧。"
    translate None chapter_sixteen_0330:
        "我不由对他露出微笑。初次见面时他还想掐死福恩，但现在已经成长了很多。"
    translate None chapter_sixteen_0331:
        v neu "多带一个人会拖慢速度，看来我们天黑前赶不到了，除非现在就出发并保持匀速。"
    translate None chapter_sixteen_0332:
        v "准备好出发了吗？"
    translate None chapter_sixteen_0333:
        rs sad "好了，走吧。"
    translate None chapter_sixteen_0334:
        "伊尔兰踢散闷烧的余烬转身离开。赛恩仍坐着，没听见我的呼唤。"
    translate None chapter_sixteen_0335:
        rs sad "赛恩？"
    translate None chapter_sixteen_0336:
        c sur "嗯？！？"
    translate None chapter_sixteen_0337:
        rs sad "要出发了，准备好了吗？"
    translate None chapter_sixteen_0338:
        c sad "….嗯，当然。"
    translate None chapter_sixteen_0339:
        "他跟着我回到队伍，我们再次踏上那条被踩出的小径。"
    translate None chapter_sixteen_0340:
        "这样行进了几个小时，只有零星的交谈。赛恩走在队尾安静如鼠。福恩和索伦仍在昏迷，维拉斯和伊尔兰走在稍前方引路。"
    translate None chapter_sixteen_0341:
        "空气中的紧张感浓得能用刀切开。"
    translate None chapter_sixteen_0342:
        "我担心赛恩。从没见过他这么…沮丧，这么沉默。总该做点什么…"
    translate None chapter_sixteen_0343:
        rs sad "…到锡德卡汉后有什么计划？"
    translate None chapter_sixteen_0344:
        i neu "如果能设法让两个昏迷的人通过卫兵检查，建议先找个体面的地方过夜。"
    translate None chapter_sixteen_0345:
        l neu "同意。"
    translate None chapter_sixteen_0346:
        rs sad "光是找落脚处就够呛…"
    translate None chapter_sixteen_0347:
        rs "之后也不知从何找起。这么大的城市怎么找卡斯皮安？"
    translate None chapter_sixteen_0348:
        v neu "说大城市都算谦虚了。那是维拉斯的皇冠明珠，超级都市。"
    translate None chapter_sixteen_0349:
        rs sad "...."
    translate None chapter_sixteen_0350:
        v smi "步步为营吧雷恩。到了那里自然会有线索。"
    translate None chapter_sixteen_0351:
        rs sad "你们俩呢？"
    translate None chapter_sixteen_0352:
        i con "我们在锡德卡汉有别的事，安顿好索伦再来找你们。"
    translate None chapter_sixteen_0353:
        i "那里大概还积雪覆盖，建议弄些厚衣服。你总不想冻掉四肢吧。"
    translate None chapter_sixteen_0354:
        rs sur "你呢，维拉斯？你不冷吗？"
    translate None chapter_sixteen_0355:
        v sad "我还是不怎么喜欢穿衣服，但伊尔兰不让我光着身子到处走。"
    translate None chapter_sixteen_0356:
        i sad "而且理由很充分。你晃着那玩意儿到处走会吓到所有人的。知道吗，我还得随身背着你的衣服。"
    translate None chapter_sixteen_0357:
        v neu "你不背我也不介意。"
    translate None chapter_sixteen_0358:
        i sad "但我介意。"
    translate None chapter_sixteen_0359:
        "周围景色正慢慢变化。远处，冰峰直插云霄，树木的红色逐渐稀疏，取而代之的是白雪覆盖的大地，恰在此时天空也从鲜艳的蓝色变成了深邃的橙色。"
    translate None chapter_sixteen_0360:
        "周遭空气迅速变冷，我抱紧双臂试图留住些体温。"
    translate None chapter_sixteen_0361:
        "温差大得惊人…简直冷得要命。我开始发抖，注意到多数人也是如此。莱奥斯在福恩变身时把他搂得更紧了。"
    translate None chapter_sixteen_0362:
        "最终我们穿过最后的树林，来到一片冰封山谷。河穿谷而过，沿岸建着房屋。"
    translate None chapter_sixteen_0363:
        "但首先吸引我目光的并非这些。"


    scene bg sc sunset with dissolve:
        xpos 0.51 ypos 1.28 xanchor 0.5 yanchor 1.0 zoom 1.28

    translate None chapter_sixteen_0364:
        "嵌在山腰的是座大理石之城，金色尖塔点缀其间。建筑高耸入云，规模宏大—比我以往见过的都要庞大。"
    translate None chapter_sixteen_0365:
        "一条宽阔石径向下延伸至河畔小镇，越过桥梁，直达锡德卡汉巍峨的城门。整个山谷白雪皑皑，一望无际。"
    translate None chapter_sixteen_0366:
        rs sur "那就是…锡德卡汉？它..它和我见过的任何地方都不一样。"
    translate None chapter_sixteen_0367:
        l sur "....."
    translate None chapter_sixteen_0368:
        c sad "…终于，我快到家了。"
    translate None chapter_sixteen_0369:
        rs sad "就为回家走了这么远的路，对吧？离这么近你一定很兴奋。"
    translate None chapter_sixteen_0370:
        c sad "比起你们的旅程不算长，但能看见它真好。我想要自己的床。"
    translate None chapter_sixteen_0371:
        "福恩在莱奥斯臂弯里又动了几下。看来药效终于开始退了。"
    translate None chapter_sixteen_0372:
        "莱奥斯放下他，我轻轻摇晃他的肩膀。"
    translate None chapter_sixteen_0373:
        rs sad "福恩？福恩，我们快到了。醒醒。"
    translate None chapter_sixteen_0374:
        f sad "嗯…雷恩…？发生什么了？"
    translate None chapter_sixteen_0375:
        rs sad "现在没事了。终于能看见锡德卡汉了。"
    translate None chapter_sixteen_0376:
        f sur "....!"
    translate None chapter_sixteen_0377:
        f sad "噢..噢，不…我不是故意—"
    translate None chapter_sixteen_0378:
        "他望向赛恩，但对方别过脸去不与他对视。"
    translate None chapter_sixteen_0379:
        "福恩从地上站起来，背对着赛恩。"
    translate None chapter_sixteen_0380:
        f sad "…这就是锡德卡汉。我这辈子从没想过会见到这样的地方，而且…好冷…我什么都感觉不到了…"
    translate None chapter_sixteen_0381:
        "我看向赛恩，他比平时更加沉默，然后又看向福恩，他脸上藏不住的肯定是自我失望的情绪。"
    translate None chapter_sixteen_0382:
        v smi "….福恩，你感觉怎么样？等进城后，你就能暖和起来了。"
    translate None chapter_sixteen_0383:
        f sad "…嗯…"
    translate None chapter_sixteen_0384:
        v sad "....."
    translate None chapter_sixteen_0385:
        v smi "我一直没机会告诉你，对吧？你的歌声很美。正是在斯塔格威奇听到你的歌声，我们才找到你的。"
    translate None chapter_sixteen_0386:
        v "在我成神之前，我就一直热爱音乐。你的声音有种魔力。"
    translate None chapter_sixteen_0387:
        f sad "谢谢…"
    translate None chapter_sixteen_0388:
        "随着一阵烟雾，维拉斯的斗篷掉落在地，一只蓝色的小鸟落在了福恩手指上。它啾啾叫了几声，上下蹦跳着。"
    translate None chapter_sixteen_0389:
        "福恩的表情从惊讶变成温柔的微笑，他轻轻用手指碰了碰维拉斯的头顶。"
    translate None chapter_sixteen_0390:
        i sad "你们俩可以稍后再好好叙旧。我他妈在外面都快冻掉蛋了！走吧。"
    translate None chapter_sixteen_0391:
        "小路带着我们穿过冰封的山谷和外围建筑。与城里那些金顶白墙的尖塔相比，这些建筑显得很简陋。"
    translate None chapter_sixteen_0392:
        "居民们用余光打量着我们，但我不觉得奇怪。这么一大群衣衫单薄的旅人，风尘仆仆地走了好几天路，还有个背着尸体的人…"


    scene bg sc night with dis3:
        xpos 0.51 ypos 1.28 xanchor 0.5 yanchor 1.0 zoom 1.28

    translate None chapter_sixteen_0393:
        "尽管如此，我们还是继续前行，朝着标志锡德卡汉入口的巨型城门走去。夕阳为整座城市镀上金光，使其几乎闪闪发亮—虽然只有短短一瞬。"
    translate None chapter_sixteen_0394:
        "最后一缕阳光隐没在山后，整座山谷几乎瞬间陷入了黑暗。"
    translate None chapter_sixteen_0395:
        "就在我们即将转过拐角进入城门通道时，伊尔兰突然停住了脚步。"
    translate None chapter_sixteen_0396:
        i neu "在这等着。"
    translate None chapter_sixteen_0397:
        rs sur "你要去哪？"
    translate None chapter_sixteen_0398:
        i fli "去和守卫聊两句。我肯定在哪见过他们。"
    translate None chapter_sixteen_0399:
        "他独自走向城门，我偷偷从拐角探头观察。他把守卫拉到一旁，凑到他们耳边低声说了些什么。守卫们的表情从疑惑变成震惊，最后变成了惊恐。"
    translate None chapter_sixteen_0400:
        "两人都点点头，回到各自岗位上。他们身披整套银金配色的板甲，看起来与其说是为了防护，不如说是为了外观。"
    translate None chapter_sixteen_0401:
        "不得不承认，他们确实显得威风凛凛。剑鞘松松垮垮地挂在腰间，里面的剑恐怕从未出鞘过。"
    translate None chapter_sixteen_0402:
        "伊尔兰示意我们跟上，我们沿着小路走到尽头穿过城门。经过时守卫都移开视线，假装没看见我们。"
    translate None chapter_sixteen_0403:
        "一只雄鹰蹲踞在巨大的城门顶端，仿佛自己也在站岗。"


    scene bg sc night with Dissolve(1.0)
    $ about_SC.image = "gui/codex/entries/places/enc_sc.jpg"
    $ about_SC._text = ["维迪斯最东北端坐落着它的皇冠明珠—闪耀的都城锡德卡汉。这座依山而建的城市，白色尖塔直插云霄，数英里外都清晰可见。\n \n这里曾是言者与国王共同统治的驻地，如今据他们所知…已完全与神明隔绝。\n \n众多最富有的权贵家族聚居于此，竞相争夺国王的支持。"]
    if achievement.has("reach_sidcaeham"):
        pass
    else:
        $ renpy.display_notify("成就解锁：雪域之国")
    python:
        achievement.grant("reach_sidcaeham")
        achievement.sync()
    translate None chapter_sixteen_0405:
        "一条宽阔街道带着我们穿过城门，进入{a=set_entry:enc_places->about_SC}{color=#87CEEB}锡德卡汉{/color}{/a}。灯笼照亮每个阴暗角落，人群熙熙攘攘往来穿梭。"
    translate None chapter_sixteen_0406:
        "建筑洁白无瑕，由毫无瑕疵的白色石料砌成。连这里的人都看起来…光鲜亮丽？服饰发型一丝不苟，不见半点污渍。在他们眼里，我们八成显得…"
    translate None chapter_sixteen_0407:
        "积雪在靴底嘎吱作响，不过还不算太深。"
    translate None chapter_sixteen_0408:
        "刚进城门，伊尔兰就停步转身面对我们。"

    show raen n dark sur at slightleft
    show illran n dark armsdown neu at slightright
    show bveras n dark neu at slightright:
        xpos 0.8 ypos 1.0 xanchor 0.78 yanchor 0.98
    with dissolve

    translate None chapter_sixteen_0409:
        rs "这里每个人都这么…"
    translate None chapter_sixteen_0410:
        i "讲究？别担心，不是所有地方都这样。锡德卡汉和其他城市一样也有贫民窟。"
    translate None chapter_sixteen_0411:
        l smi "哦真好，总算有你适合待的地方了。"
    translate None chapter_sixteen_0412:
        show illran n con with dis
        i "这话倒没法反驳。"
    translate None chapter_sixteen_0413:
        i "连着赶了这么多天路。我想接下来该带索伦去见我们的…朋友扎林了。"
    translate None chapter_sixteen_0414:
        show raen n sad with dis
        rs "单独去？不行，我们也得跟着。我不想丢下索伦。"
    translate None chapter_sixteen_0415:
        show illran n neu with dis
        i "你都站不稳了。找个地方过夜休息，我们很快就来接你去见他。我保证不会对他不利。"
    translate None chapter_sixteen_0416:
        rs "....."
    translate None chapter_sixteen_0417:
        l neu "只是暂时的。"
    translate None chapter_sixteen_0418:
        rs "好吧…."

    hide bveras
    hide illran
    with dissolve
    show raen at cenleft with move
    show leos n dark neu at cenright
    show cyne n dark sad at farleft
    show fawn n dark sad at farright
    with dissolve

    translate None chapter_sixteen_0419:
        "伊尔兰肩上扛着维拉斯和索伦，消失在一条小巷中离开了我们的视线，把我们单独留在这里。福恩和赛恩站得尽可能远离对方。"
    translate None chapter_sixteen_0420:
        rs "即使在夜晚，这座城市也很美。站在这样的地方就像做梦一样。这里…奢华、富裕、绚丽…"
    translate None chapter_sixteen_0421:
        c "我们在这里有很多机会。我…很高兴回到家。"
    translate None chapter_sixteen_0422:
        c "今晚我会给你们三个找个住处，所以不用担心这个。"
    translate None chapter_sixteen_0423:
        rs "这是不是意味着…你要走了？"
    translate None chapter_sixteen_0424:
        c "...."
    translate None chapter_sixteen_0425:
        c "没错。是时候回家了。我敢肯定我父母正屏息等待着我的归来。"
    translate None chapter_sixteen_0426:
        "福恩挪得更远了，莱奥斯叹了口气。"
    translate None chapter_sixteen_0427:
        show leos n smi with dis
        l "终于可以摆脱你了。花了我们够长时间，不是吗？"
    translate None chapter_sixteen_0428:
        show cyne n hap with dis
        c "…是啊。你们再也不用见到我了。"
    translate None chapter_sixteen_0429:
        "他向我们微笑，但那笑容很空洞。没有达到他的眼底。"
    translate None chapter_sixteen_0430:
        c "来吧，我知道有个好地方。"
    translate None chapter_sixteen_0431:
        "他转身带领我们穿过锡德卡汉繁忙的街道。即使我们离进来的主路越来越远，街上每个人都还是衣着光鲜。"
    translate None chapter_sixteen_0432:
        rs "我们是不是…穿得太寒酸了？"
    translate None chapter_sixteen_0433:
        show cyne n neu with dis
        c "对其他人来说你们绝对看起来很古怪，但我不太担心这个。锡德卡汉的大多数人只关心两件事：他们自己，还有八卦。他们最多也就是告诉朋友有一群臭烘烘、脏兮兮的旅人从他们身边经过。"
    translate None chapter_sixteen_0434:
        l "嗯，这还不算太糟，对吧？"
    translate None chapter_sixteen_0435:
        rs "这不是我想要的名声，不过确实，不太糟糕。"
    translate None chapter_sixteen_0436:
        rs "赛恩，你住在哪里？离这儿近吗？"
    translate None chapter_sixteen_0437:
        c "山上更高的地方。离这儿还有段距离。"
    translate None chapter_sixteen_0438:
        "他带我们来到一栋巨大的石砌建筑前，敞开的大门邀请着我们进入。上方挂着写有{i}银柳{/i}的招牌。"
    translate None chapter_sixteen_0439:
        c "在我们进去之前…你们打算在这里待多久？"
    translate None chapter_sixteen_0440:
        rs "嗯…"
    translate None chapter_sixteen_0441:
        l "如果我们计划一直待到有卡斯皮安的消息，可能会在这里待上一阵子。"
    translate None chapter_sixteen_0442:
        c "好的，明白了。跟我来。"
    window hide dissolve

    scene bg sw night:
        size(1920, 1080)
    with dissolve
    window show dissolve

    translate None chapter_sixteen_0443:
        u "赛恩？"

    show leos n dim neu at cenright
    show cyne n dim sur at farleft
    show fawn n dim sad at farright
    show raen n dim neu at cenleft
    with dissolve

    translate None chapter_sixteen_0444:
        c "艾琳！我就盼着你今天在这儿工作呢。"
    translate None chapter_sixteen_0445:
        ey "赛恩…你父母前几天来这里找过你。你去哪儿了？"
    translate None chapter_sixteen_0446:
        c "噢，你了解我的。东奔西跑呗。我现在正准备回去呢，我保证。"
    translate None chapter_sixteen_0447:
        ey "那你在这里做什么？"
    translate None chapter_sixteen_0448:
        show cyne n neu with dis
        c "我带了三个…朋友一起来。他们不是本地人，需要找个地方住上大约一个星期。你这里有空余的房间吗？"
    translate None chapter_sixteen_0449:
        ey "这可不像你这么慷慨的样子…我们当然有空房。"
    translate None chapter_sixteen_0450:
        c "我会预付三个人的房费。记得给他们安排最好的房间，好吗？"
    translate None chapter_sixteen_0451:
        ey "好吧好吧。不过你要多来看看我，好吗？别忘了向你父母道歉。他们担心得要死。"
    translate None chapter_sixteen_0452:
        show cyne n sad with dis
        c "担心？也许吧，但绝不是为我。他们只在乎自己宝贵的公众形象。"
    translate None chapter_sixteen_0453:
        "他递过一把金币，艾琳沿着走廊离开了。"
    translate None chapter_sixteen_0454:
        c "好了。三间房一周。"
    translate None chapter_sixteen_0455:
        show raen n dim sad with dis
        rs "赛恩…我不知道该说什么…"
    translate None chapter_sixteen_0456:
        rs "我真不知道该怎么感谢你。"
    translate None chapter_sixteen_0457:
        c "哎呀，怎么说呢，我就是这么个好人。总之我也该走了，这次很愉快。"
    translate None chapter_sixteen_0458:
        rs "赛恩—"
    translate None chapter_sixteen_0459:
        c "我…"
    translate None chapter_sixteen_0460:
        c "对不起。"

    hide cyne with dissolve
    show raen at left
    show leos at center
    show fawn at right
    with move

    translate None chapter_sixteen_0461:
        "他朝福恩点头致意后，离开了旅店消失不见。"
    translate None chapter_sixteen_0462:
        f "...."
    translate None chapter_sixteen_0463:
        rs "...."
    translate None chapter_sixteen_0464:
        l "...."
    translate None chapter_sixteen_0465:
        rs "所以…又只剩下我们三个人了？"
    translate None chapter_sixteen_0466:
        l "看起来确实如此。"
    translate None chapter_sixteen_0467:
        ey "打扰一下？房间已经准备好了。请跟我来，我带你们过去。"
    translate None chapter_sixteen_0468:
        rs "哦，谢谢。"



    scene bg sw night with dissolve:
        xpos -0.25 ypos -0.2 zoom 1.49

    translate None chapter_sixteen_0469:
        "那位留着深色短发的女士领着我们上了楼梯，穿过走廊。所有地方都一尘不染，光可鉴人，照料得十分精心。"
    translate None chapter_sixteen_0470:
        ey "你们是赛恩的朋友？太好了。我原本都要以为他没有朋友了。"
    translate None chapter_sixteen_0471:
        rs sur "赛恩会没有朋友？这怎么可能？他大概是我见过最有魅力的人。"
    translate None chapter_sixteen_0472:
        ey "他确实很会说话…但他总是和人保持距离。没错，他认识很多人，但他从不让任何人真正靠近。"
    translate None chapter_sixteen_0473:
        ey "他总会甩开别人逃走。他害怕受伤。"
    translate None chapter_sixteen_0474:
        "这真是…出人意料。"
    translate None chapter_sixteen_0475:
        rs sur "…你们俩很熟吗？"
    translate None chapter_sixteen_0476:
        ey "现在没那么熟了。我们十几岁的时候几乎天天一起玩。现在，我每个月都难得见到他一次。"
    translate None chapter_sixteen_0477:
        rs sad "听你这么说我很难过.."
    translate None chapter_sixteen_0478:
        ey "不必如此。人都会长大，新的责任意味着不能再像从前那样和朋友消磨时光。不过我确实很担心他。"
    translate None chapter_sixteen_0479:
        ey "啊，我真是太不专业了，都忘了请教各位的名字。"
    translate None chapter_sixteen_0480:
        rs sad "我是雷恩，这两位是福恩和莱奥斯。我们刚从奥克斯哈伯过来，这几天的旅程实在够呛。"
    translate None chapter_sixteen_0481:
        ey "希望你们能在这里好好放松。这是你们的房间，两间相邻，每人一把钥匙。大堂里还有一道门通往浴室。"
    translate None chapter_sixteen_0482:
        ey "你们可以随时免费使用。我先告辞了，不过如果需要什么尽管来找我。"
    translate None chapter_sixteen_0483:
        "她顺着走廊离开，很快就看不见人影了。"
    translate None chapter_sixteen_0484:
        rs neu "她好像很—"


    scene bg sw night at shake

    translate None chapter_sixteen_0485:
        "随着\"砰\"的关门声，福恩钻进自己房间不见了。"
    translate None chapter_sixteen_0486:
        l pen "…..他看起来不太高兴。"
    translate None chapter_sixteen_0487:
        rs sad "换谁高兴得起来？虽然不是他的错，但他肯定很难原谅自己。"
    translate None chapter_sixteen_0488:
        l pen "…我挺心疼这孩子，他日子不好过。"
    translate None chapter_sixteen_0489:
        rs sad "嗯…"
    translate None chapter_sixteen_0490:
        "我的手在门把上犹豫了。"
    translate None chapter_sixteen_0491:
        stop music fadeout 2.0
        l neu "…你累了吗？当然知道你累，不过如果还行的话…咱们可以在这附近转转。"

    window hide

    menu:
        "四处看看吧":
            window show dissolve
            $ leos_relationship +=2
            jump scleos

        " 我有点累了，所以…":
            window show dissolve
            jump scbed

label scleos:
    translate None chapter_sixteen_0492:
        rs sur "我还是静不下心来，散散步也好。别走太远就行，迷路就麻烦了。"
    translate None chapter_sixteen_0493:
        l smi "这不是有我吗？你自己去准出事。跟我一起？万无一失。"
    translate None chapter_sixteen_0494:
        "我们沿原路返回往前门走，经过时朝艾琳点头致意。"
    translate None chapter_sixteen_0495:
        rs sur "除非突然有人把锡德卡汉的房子全点着了，然后从火海里冲出个疯子—"
    translate None chapter_sixteen_0496:
        l ang "那不是我干的！要我解释多少遍？！我才不是纵火狂。"

    window hide dissolve

    scene bg sc night with dissolve:
        zoom 1.3
    window show dissolve
    play music "sounds/bgm/night.ogg" fadeout 2.0
    show raen m dark sur at closeleft
    show leos m dark neu at closeright
    with dissolve

    translate None chapter_sixteen_0497:
        rs "呵，这可说不准。你刚还说万无一失，自己就是个大隐患。"
    translate None chapter_sixteen_0498:
        "我们来到户外，站在另一条宽阔明亮的街道上。莱奥斯示意左转，我们便沿着小路信步而行。"
    translate None chapter_sixteen_0499:
        show leos m smi with dis
        l "所幸我目前没打算伤害你。"
    translate None chapter_sixteen_0500:
        show raen m smi with dis
        rs "哈哈，\"目前\"？能不能说得好听点？"
    translate None chapter_sixteen_0501:
        l "比如？"
    translate None chapter_sixteen_0502:
        rs "{i}\"雷恩，我永远不会伤害你。你对我太重要了，那样我的心会碎的。我发誓今生今世都会保护你。\"{/i}"
    translate None chapter_sixteen_0503:
        show leos m sur with dis
        l "......"

    show leos m smi
    show raen m sur
    with dis

    translate None chapter_sixteen_0504:
        l "哈哈哈！你怎么能面不改色说出这种台词啊？肉麻死了！"
    translate None chapter_sixteen_0505:
        "莱奥斯突然笑逐颜开，那笑声我从未想象会从他嘴里发出来，真诚得不带半点往日的混蛋劲儿。"
    translate None chapter_sixteen_0506:
        l "…..雷恩？"
    translate None chapter_sixteen_0507:
        show raen m emb with dis
        rs "啊…我是说…呃…就是觉得你说这话会很好笑嘛，懂吗？完全不符合你人设啊！"
    translate None chapter_sixteen_0508:
        show leos m shy with dis
        "莱奥斯抬手抚过我的脸颊。"
    translate None chapter_sixteen_0509:
        rs "你…你干什—"
    translate None chapter_sixteen_0510:
        l "有片叶子。在你头发上。"
    translate None chapter_sixteen_0511:
        l "..."
    translate None chapter_sixteen_0512:
        "他直直望进我的眼睛。"
    translate None chapter_sixteen_0513:
        l "雷恩，我永远不会伤害你。你对我太重要了，我的心承受不起。我发誓会永远保护你。"
    translate None chapter_sixteen_0514:
        show raen m sur with dis
        rs "...."
    translate None chapter_sixteen_0515:
        l "...."
    translate None chapter_sixteen_0516:
        show leos m smi with dis
        l "噗！连我自己都听不下去了。"
    translate None chapter_sixteen_0517:
        "心脏狂跳得几乎要冲出胸腔。莱奥斯…"
    translate None chapter_sixteen_0518:
        show raen m emb with dis
        rs "不要突然说这种肉麻台词啊！"
    translate None chapter_sixteen_0519:
        l "是你让我说的。有问题？"
    translate None chapter_sixteen_0520:
        rs "…..算了。"
    translate None chapter_sixteen_0521:
        "不知从何时起，和莱奥斯相处变得轻松多了。曾经让我坐立不安的他，现在…却让我感到安心。似乎什么心事都能向他倾诉。这感觉简直和应有的反应截然相反。"
    translate None chapter_sixteen_0522:
        "尽管他突然待我如此温柔，但终究是个杀手啊。不过…"
    translate None chapter_sixteen_0523:
        "我悄悄平复呼吸，思绪又飘回福恩和赛恩身上。"
    translate None chapter_sixteen_0524:
        show raen m sad with dis
        rs "所以…你怎么看福恩和赛恩的事？"
    translate None chapter_sixteen_0525:
        show leos m pen with dis
        l "能怎么看？他俩本来就不对付。"
    translate None chapter_sixteen_0526:
        rs "我知道福恩不信任他，但没想到这么严重…"
    translate None chapter_sixteen_0527:
        l "那你就是一直在装瞎。明显福恩不想让他待在身边。可惜偏偏在那地方爆发了。"
    translate None chapter_sixteen_0528:
        l "反正他现在也不碍我们事了，没什么好纠结的。"
    translate None chapter_sixteen_0529:
        rs "你觉得我们再也见不到他了？这有点…难过。"
    translate None chapter_sixteen_0530:
        l "除非森林仙子先道歉。赛恩已经道过歉了。"
    translate None chapter_sixteen_0531:
        l "而且得先找到他。在这种大城市，避开我们很容易。就像那女孩说的，谁靠太近他就切断联系。"
    translate None chapter_sixteen_0532:
        rs "...."
    translate None chapter_sixteen_0533:
        show leos m cur with dis
        l "再说了，这鬼天气冷死人。能回去了吗？"
    translate None chapter_sixteen_0534:
        rs "我们没能好好看看这座城市，但在外面走走让我的头脑稍微清醒了些。谢谢你，莱奥斯。"
    translate None chapter_sixteen_0535:
        show leos m smi with dis
        l "乐意之至。不管你是想找个人聊天还是需要揍谁一顿，我随时为你效劳。"
    translate None chapter_sixteen_0536:
        show raen m smi with dis
        rs "有需要的时候我会记得找你帮忙的。"

    hide leos
    hide raen
    with dissolve

    translate None chapter_sixteen_0537:
        "我们转身返回旅馆，比出来时快多了。再待下去，我们的手指恐怕都要冻掉了。"


    scene bg sw night with dissolve
    translate None chapter_sixteen_0538:
        "我们路过艾琳身边时，她朝我们笑了笑。她肯定觉得特别好笑—两个穿得乱七八糟的家伙在雪里待了没几分钟就慌慌张张跑回屋。"
    translate None chapter_sixteen_0539:
        "我打开房门，和同样准备休息的莱奥斯互道晚安。"

    jump choice_twentynine_done


label scbed:
    translate None chapter_sixteen_0540:
        "说实话我已经精疲力尽了。虽然一半的我想和莱奥斯出去，但舒适床铺的诱惑力实在更大。"
    translate None chapter_sixteen_0541:
        rs sad "其实我也挺累的，所以…"
    translate None chapter_sixteen_0542:
        l neu "...."
    translate None chapter_sixteen_0543:
        l pen "明白。我也该休息了。当我没提过这事吧。"
    translate None chapter_sixteen_0544:
        "他走进房间关上门。我也决定照做。"

    jump choice_twentynine_done


label choice_twentynine_done:
    window hide dissolve
    stop music fadeout 2.0

    scene bg swroom night with dissolve:
        xpos 0.69 ypos 1.16 xanchor 0.5 yanchor 1.0 zoom 1.44
        linear 35.0 xpos 0.3 ypos 1.16 xanchor 0.5 yanchor 1.0 zoom 1.44
    window show dissolve

    translate None chapter_sixteen_0545:
        "房间很宽敞，靠墙摆着的大床占了主要空间。枕头层层叠叠的，看起来舒服得不可思议。"
    translate None chapter_sixteen_0546:
        "这装潢…非常奢华。我只希望别让赛恩破费太多…"
    translate None chapter_sixteen_0547:
        "赛恩…"
    translate None chapter_sixteen_0548:
        "我推开俯瞰街道的大窗户。楼下依然人来人往，各自忙碌着。"
    translate None chapter_sixteen_0549:
        "赛恩，事情变成这样我很抱歉。他看起来很沮丧，很痛苦…不仅因为福恩的事，还因为莱奥斯那番话。"
    translate None chapter_sixteen_0550:
        "我甚至没机会好好道别。"
    translate None chapter_sixteen_0551:
        "我长叹一声探出窗外。空气依然冰冷刺骨，但有助于理清思绪。"
    translate None chapter_sixteen_0552:
        "还有索伦…他被伊尔兰和维拉斯带走了，带到哪儿去了？我只知道个名字…扎林。他们会对他做什么？"
    translate None chapter_sixteen_0553:
        "伊尔兰说过之后会来找我们，可怎么找？他们连我们住哪儿都不知道。"
    translate None chapter_sixteen_0554:
        "事关人命还让人耐心等待实在太难了…"
    translate None chapter_sixteen_0555:
        "我关上窗户，脱下衣服钻进被窝。枕头蓬松柔软，毯子温暖宜人。先前的寒意完全消散，我渐渐沉入梦乡。"

    window hide dissolve

    scene black with eye_shut
    pause(1.0)
    play music "sounds/bgm/forgotten off.ogg" fadein 2.0
    translate None chapter_sixteen_0556:
        n "雷恩，雷恩…你能听到我吗？我的声音传到你那里了吗？"

    window show dissolve
    translate None chapter_sixteen_0557:
        rs sur "......"
    translate None chapter_sixteen_0558:
        show white with eye_open
        "我睁开眼睛，看到一片刺眼的白光。"
    translate None chapter_sixteen_0559:
        rs sur "谁…是谁在那里？"
    translate None chapter_sixteen_0560:
        n "{color=#000000}雷恩…真高兴你能听到我….他马上就要找到你了。你已经无计可施。看好你的朋友们。{/color}"
    translate None chapter_sixteen_0561:
        "那个声音…又来了…"
    translate None chapter_sixteen_0562:
        "我能够…完整地听清她的话了…这是第一次。"
    translate None chapter_sixteen_0563:
        n "{color=#000000}小心…没人能逃脱他。伤害你…夺走…{/color}"
    translate None chapter_sixteen_0564:
        rs wor "等等，别走！你究竟想告诉我什么？！"
    translate None chapter_sixteen_0565:
        n "{color=#000000}我…不能久留….找到…你….{/color}"
    translate None chapter_sixteen_0566:
        scene black with flash
        "光芒一闪，周围的亮光被黑暗吞噬，声音不断回响直到最终消失。"
    translate None chapter_sixteen_0567:
        "我感到自己在坠落，不断坠落直到…"

    pause(1.0)

    scene bg swroom day at shake:
        size(1920, 1080)
    window show dissolve
    stop music fadeout 2.0

    translate None chapter_sixteen_0568:
        rs sur "啊！"
    translate None chapter_sixteen_0569:
        rs wor "不，不，不，别走！先别走！"
    translate None chapter_sixteen_0570:
        "我闭上眼，拼命想让自己重新入睡，但无济于事。她消失了。"
    translate None chapter_sixteen_0571:
        rs sad "....."
    translate None chapter_sixteen_0572:
        "我全都记得…感觉她也能听见我的话。维拉斯告诉我这不是幻觉，这说明…她一定是在警告我。"
    translate None chapter_sixteen_0573:
        "某个人或某种东西即将到来，我无法避免与之对抗…无处可逃。"
    translate None chapter_sixteen_0574:
        "我…已卷入了一个远超我个人…远超我们所有人的巨大阴谋…"
    translate None chapter_sixteen_0575:
        "我迅速跳下床，穿戴整齐后打开窗户。外面积雪仍覆盖着四周，阳光在雪面上反射出刺眼的光芒。"
    translate None chapter_sixteen_0576:
        "穿着冬装的女士们在街头愉快交谈。店主们挂起招牌开门营业。远处，一个蓝发人影转过街角，衣着单薄得与寒冷天气格格不入。"

    play music "sounds/bgm/scary.ogg" fadeout 2.0

    translate None chapter_sixteen_0577:
        "等等…"


    scene bg sw day with swipeleft:
        size(1920, 1080)
    play sound "sounds/sfx/doorlocked.ogg"

    translate None chapter_sixteen_0579:
        "转瞬之间我已来到室外，用力敲打莱奥斯的房门。我试着转动把手，但门锁着。"
    translate None chapter_sixteen_0580:
        rs wor "莱奥斯！！快醒醒！"
    translate None chapter_sixteen_0581:
        "我挪到隔壁门前，试着开福恩的房门。门没锁，轻轻一推就开了。里面房间和我的一模一样—空空如也。"
    translate None chapter_sixteen_0582:
        l ann "你他妈一大早敲我门干什—"
    translate None chapter_sixteen_0583:
        rs wor "是福恩！他不见了！"
    translate None chapter_sixteen_0584:
        l sur "…什么？"
    translate None chapter_sixteen_0585:
        rs wor "我…我刚从窗户看到他，来他房间查看时人就不见了。快，我们得去找他！"
    translate None chapter_sixteen_0586:
        "他的表情变得严肃，迅速套上了靴子。"
    translate None chapter_sixteen_0587:
        l ang "那快说，你看见他往哪个方向去了？"
    translate None chapter_sixteen_0588:
        rs wor "是…我们来的方向，然后他右转了。"


    scene bg sc day with swipeleft:
        size(1920, 1080)

    translate None chapter_sixteen_0589:
        "我们朝着福恩离开的方向跑去，招来了不少居民愤怒的目光。抱歉！这是紧急情况！"
    translate None chapter_sixteen_0590:
        rs wor "为什么…他为什么要不告而别？他不会做傻事吧？"
    translate None chapter_sixteen_0591:
        l ang "不知道，人在绝望时会做出任何事。"
    translate None chapter_sixteen_0592:
        rs wor "那得赶紧找到他！他不能孤身待在这里！而且…我觉得有人在跟踪我们！"
    translate None chapter_sixteen_0593:
        l ang "…你怎么知道？"
    translate None chapter_sixteen_0594:
        rs wor "现在不是解释的时候。我保证之后会说明！"
    translate None chapter_sixteen_0595:
        l pen "…好吧，但你别想蒙混过关。"
    translate None chapter_sixteen_0596:
        "我们穿过一条又一条街，却没发现福恩的踪迹。哪里都看不到那抹蓝发。"
    translate None chapter_sixteen_0597:
        rs wor "该…该往哪里找？该怎么办？"
    translate None chapter_sixteen_0598:
        l ann "…该死的。我可没打算这样度过早晨，知道吗？本来计划着轻松无孩的一天。"
    translate None chapter_sixteen_0599:
        rs sad "...."
    translate None chapter_sixteen_0600:
        l sur "等等—看那边。"
    translate None chapter_sixteen_0601:
        rs sad "这不好笑。可能会出事的—"
    translate None chapter_sixteen_0602:
        l sur "嘘，闭嘴。过来。"

    stop music fadeout 2.0
    #window hide dissolve

    scene bg sc day:
        xpos 0.86 ypos 1.28 xanchor 0.5 yanchor 1.0 zoom 1.78

    show cyne n sad at slightright
    show fawn n sad at slightleft
    with dissolve
    #window show dissolve
    translate None chapter_sixteen_0603:
        "莱奥斯拉我躲到隐蔽处，指向街道那头。"
    translate None chapter_sixteen_0604:
        rs sur "...!"
    translate None chapter_sixteen_0605:
        l neu "嘘。"
    translate None chapter_sixteen_0606:
        rs sur "我们去抓住他们吧！"
    translate None chapter_sixteen_0607:
        l ang "不，别动。"
    translate None chapter_sixteen_0608:
        rs sur "为什么？"
    translate None chapter_sixteen_0609:
        l pen "他们需要自己解决这事。"
    translate None chapter_sixteen_0610:
        c "…你怎么在这里？ 你不该独自乱跑的…"
    translate None chapter_sixteen_0611:
        f "我……"
    translate None chapter_sixteen_0612:
        f "我..我不知道该怎么说，但是..我睡不着。满脑子都是发生的事…"
    translate None chapter_sixteen_0613:
        f "我必须..我必须立即来找你。"
    translate None chapter_sixteen_0614:
        f "我…真的很抱歉…抱歉到甚至找不出合适的措辞来表达我的歉意。言语永远无法传递我内心的懊悔。我…"
    translate None chapter_sixteen_0615:
        f "我做了太多错事…从一开始就错怪了你。我嫉妒又刻薄…我不想再这样了。"
    translate None chapter_sixteen_0616:
        f "我的行为无可辩驳，也不敢奢求原谅…但至少，希望你能接受我的道歉。"
    translate None chapter_sixteen_0617:
        f "我曾试图伤害你，为此…我感到羞耻。对不起。"
    translate None chapter_sixteen_0618:
        c "....."
    translate None chapter_sixteen_0619:
        c "那不是…你的错.."
    translate None chapter_sixteen_0620:
        f "是的。那些我任由在心中郁积的情绪…我为此负全责。无论是否头脑清醒，我错了。"
    translate None chapter_sixteen_0621:
        c "...."
    translate None chapter_sixteen_0622:
        c "….不。我不能让你承担所有责任。我也…很抱歉。我知道你不喜欢我，但…我以为自己很有趣。我想招惹你，我…想看你暴跳如雷。"
    translate None chapter_sixteen_0623:
        c "我和你一样有错。"
    translate None chapter_sixteen_0624:
        c "我们能不能…从头开始？我是说，我还是不确定你会不会喜欢我，但…"
    translate None chapter_sixteen_0625:
        show fawn n smi with dis
        f "….我很乐意。"
    translate None chapter_sixteen_0626:
        show cyne n hap with dis
        c "别以为这意味着我会放弃雷恩。我会为你争抢他。"
    translate None chapter_sixteen_0627:
        show fawn n emb with dis
        f "什-什么？我..我不明白你在说什么！"
    translate None chapter_sixteen_0628:
        "两人终于露出了笑容。"
    translate None chapter_sixteen_0629:
        l smi "来吧，该我们上场了。"

    stop music fadeout 2.0
    #window hide dissolve

    scene bg sc day
    #window show dissolve
    show leos n smi at farright
    show raen n smi at cenright
    show cyne n sur at cenleft
    show fawn n sur at farleft
    with Dissolve(1.0)

    translate None chapter_sixteen_0630:
        l "哎呀，看看是谁不请自来。这么快就回来了？"

    show cyne n hap with dis
    play music "sounds/bgm/sidcaeham.ogg" fadeout 2.0

    translate None chapter_sixteen_0631:
        c "我担心离开太久你会想我。没有我这个常驻美男子在身边你可怎么办？"
    translate None chapter_sixteen_0632:
        show fawn n shy with dis
        f "啊hh…你们刚才一直在偷听…？"
    translate None chapter_sixteen_0633:
        rs "才没有，什么都没听见。你们现在相处融洽了吗？"
    translate None chapter_sixteen_0634:
        f "…嗯。是的，我们很好。"
    translate None chapter_sixteen_0635:
        show cyne n sad with dis
        c "….抱歉昨天我表现得有点奇怪。不过在自己床上睡了一晚感觉好多了。"
    translate None chapter_sixteen_0636:
        rs "很高兴你回来了。和你父母谈得怎么样？"
    translate None chapter_sixteen_0637:
        c "噢，见到我他们欣喜若狂。真是美妙的家庭团聚。"
    translate None chapter_sixteen_0638:
        c "我的意思是他们训了我一整晚，说我不能再次无限期离开锡德卡汉，还不准我在他们视线范围外过夜。"
    translate None chapter_sixteen_0639:
        c "我已经是个成年人，但生活似乎仍然不受自己掌控。"
    translate None chapter_sixteen_0640:
        show leos n neu with dis
        l "你的随从呢？有他的消息吗？"
    translate None chapter_sixteen_0641:
        c "意外的是，有。他比我早一天到家。昨晚因为父母在场我没机会和他说话，所以不清楚发生了什么。总之我…很高兴他平安归来。"
    translate None chapter_sixteen_0642:
        l "这一点都不可疑呢。"
    translate None chapter_sixteen_0643:
        c "我相信他并无恶意，但..我想不出其他可能性。"
    translate None chapter_sixteen_0644:
        "身旁的福恩打了个寒颤。连莱奥斯也抱紧自己试图取暖。"
    translate None chapter_sixteen_0645:
        show cyne n hap with dis
        c "不太适应这种天气？"
    translate None chapter_sixteen_0646:
        show fawn n sad with dis
        f "这么冷的天你们怎么活下来的？"
    translate None chapter_sixteen_0647:
        show cyne n sur with dis
        c "呃，你会习惯的。其实我昨天就想提这事，但没找到机会…我认识个很棒的裁缝，他应该能给你们三个做些保暖衣服。"
    translate None chapter_sixteen_0648:
        show raen n sur with dis
        rs "定制衣服…？我从没穿过这种东西。"
    translate None chapter_sixteen_0649:
        c "我请客，除非你们宁愿冻着？"
    translate None chapter_sixteen_0650:
        rs "好吧…至少来件外套之类的。要是我们都冻死了可就哪儿也去不了了。"
    translate None chapter_sixteen_0651:
        show cyne n hap with dis
        c "跟我来！反正我一直想去那儿转转。店主是个叫阿什的老伯，在当地很有名。"
    translate None chapter_sixteen_0652:
        c "我不清楚他从哪儿搬来的，但他大概是锡德卡汉最时髦的男人了，而且人也不错。"
    translate None chapter_sixteen_0653:
        rs "…你认识锡德卡汉的每个人吗？"
    translate None chapter_sixteen_0654:
        c "噗，我可不敢这么说。只是人们都忍不住要接近我，懂吗？"
    translate None chapter_sixteen_0655:
        c "不过我跟阿什很熟。他有点像大哥哥的感觉。我几年前开始常去他店里，但那时候店名不是这个。现在他管它叫\"樱草花\"。"
    translate None chapter_sixteen_0656:
        show fawn n smi with dis
        f "樱草花…这名字很美。"
    translate None chapter_sixteen_0657:
        show cyne n sad with dis
        c "…是啊，确实。快点，我们快到了。"
    translate None chapter_sixteen_0658:
        "我们转过拐角来到一条安静的街道，几个孩子在雪地里嬉笑着玩耍。一家小商店门前立着招牌，上面用花体写着\"樱草花\"的字样。"
    translate None chapter_sixteen_0659:
        "我拉开门，我们一起走进了商店。"

    window hide dissolve
    jump chapter_seventeen_start
