label talktomorwen:
    stop music fadeout 2.0
    show raen mw dark cloak sad at mright
    show morwen m dark smi cloakup at mleft
    with dissolve
    translate None sv_night_0001:
        mor "喂，雷恩？"
    translate None sv_night_0002:
        show raen mw dark sur with dis
        play music "sounds/bgm/night.ogg" fadein 3.0
        rs "啊！你吓到我了。"
    translate None sv_night_0003:
        mor "你完全走神了。心事重重吗？"

    show raen mw dark sad with dis

    if fawn_route:
        translate None sv_night_0004:
            rs "…赛恩和莱奥斯。我很担心他们。"


    if cyne_route:
        translate None sv_night_0005:
            rs "…是福恩和莱奥斯…我担心他们。"


    if leos_route:
        translate None sv_night_0006:
            rs "..是福恩和赛恩…我很担心他们。"


    translate None sv_night_0007:
        show morwen m dark sad with dis
        mor "我也一样。"
    translate None sv_night_0008:
        rs "连水之女神都忧心忡忡，我实在不能说充满信心…"
    translate None sv_night_0009:
        mor "对这个不怎么重要的人来说，这真是个华而不实的头衔，我保证。我这一生充其量不过是个洗衣女工。"
    translate None sv_night_0010:
        mor "那时一切都不同。我所熟知的那些城镇和村庄早已被世人遗忘。"
    translate None sv_night_0011:
        show raen mw dark sur with dis
        rs "你成为神明有多久了？"
    translate None sv_night_0012:
        show morwen m dark wor with dis
        mor "…我已记不清了，雷恩。"
    translate None sv_night_0013:
        show raen mw dark sad with dis
        rs "…听起来很艰难。我觉得我做不到。"
    translate None sv_night_0014:
        mor "哪部分做不到？"
    translate None sv_night_0015:
        rs "在一个将你遗忘的世界里挣扎…看着身边的人相继离世，自己却永生不死…"
    translate None sv_night_0016:
        mor "如今这比以往任何时候都要艰难…"
    translate None sv_night_0017:
        mor "当我们还属于天界时，这并不算什么大事。"
    translate None sv_night_0018:
        rs "因为你身边都是同类，对吗？"
    translate None sv_night_0019:
        mor "正是如此…"
    translate None sv_night_0020:
        mor "许多人别无选择，只能融入人类社会。我们与人类的羁绊如此紧密，永生带来的痛苦比以往任何时候都更为明显。"
    translate None sv_night_0021:
        rs "…..比如伊尔兰和维拉斯。"
    translate None sv_night_0022:
        show morwen m dark ssmi with dissolve
        "莫温悲伤地朝我笑了笑。"
    translate None sv_night_0023:
        mor "我已经很久没见过这样的情况了。他们对彼此而言就是整个世界—甚至可以说，比世界还要重要。而这只会让长久的岁月变得更加痛苦。"
    translate None sv_night_0024:
        show morwen m dark sad with dis
        mor "维拉斯已经眼睁睁看着身边的人逝去数百年了。"
    translate None sv_night_0025:
        rs "..."
    translate None sv_night_0026:
        rs "…..维拉斯计划在奥雷利亚诸神获得自由后离世。"
    translate None sv_night_0027:
        mor "…这很难。"
    translate None sv_night_0028:
        rs "…我能问你几个问题吗？"
    translate None sv_night_0029:
        mor "你当然可以。"


label morwenchoices:
    if morwen_count == 4:
        jump morwen_after

    window hide
    menu:
        "你能多告诉我一些关于卢修斯的事吗？" if morwen_lucius:
            window show dissolve
            $ morwen_count += 1
            $ morwen_lucius = False
            $ morwen_enough = True
            jump morwenasklucius

        "艾米尔和卡斯皮安以前是什么样子的？" if morwen_casaemyl:
            window show dissolve
            $ morwen_count += 1
            $ morwen_casaemyl = False
            $ morwen_enough = True
            $ caspianaemylromance += 1
            jump morwenaskcasaemyl

        "你对伊尔兰了解多吗？" if morwen_illran:
            window show dissolve
            $ morwen_count += 1
            $ morwen_illran = False
            $ morwen_enough = True
            $ illranveras_friend += 1
            jump morwenaskillran

        "告诉我更多关于你作为人类时的经历" if morwen_human:
            window show dissolve
            $ morwen_count += 1
            $ morwen_human = False
            $ morwen_enough = True
            jump morwenaskhuman

        "问够了" if morwen_enough:
            window show dissolve
            jump morwen_after


label morwenasklucius:
    show raen mw dark neu with dis
    translate None sv_night_0030:
        rs "关于卢修斯，你还能告诉我些什么？"
    translate None sv_night_0031:
        show morwen m dark wor with dis
        mor "嗯…"
    translate None sv_night_0032:
        mor "我想我对他足够了解了。当他还担任言者的时候，艾米尔还是个襁褓中的婴儿，那时我们经常交谈。"
    translate None sv_night_0033:
        mor "他是那种深藏不露之人，唯有确信能胜才会出手。当年屠杀王室时也是如此。"
    translate None sv_night_0034:
        mor "他谋划这件事已经很多年了。他唯一的遗憾是让卡斯皮安逃脱了。"
    translate None sv_night_0035:
        show raen mw dark sad with dis
        rs "如果他一开始就是恶人，艾米尔为何如此信任他？正是他在我父亲和他之间挑拨离间的，对吧？"
    translate None sv_night_0036:
        "说\"我父亲\"这个词仍然感觉怪异又不自然。"
    translate None sv_night_0037:
        show morwen m dark sad with dis
        mor "卢修斯是他的导师和父亲般的存在。对艾米尔来说，很难想象他会做出错事。"
    translate None sv_night_0038:
        mor "当你被培养成一个言者，那一定是极其孤独的。"
    translate None sv_night_0039:
        show raen mw dark sur with dis
        rs "怎么说？"
    translate None sv_night_0040:
        show morwen m dark sur with dis
        mor "你不知道吗？"
    translate None sv_night_0041:
        "我摇了摇头，回应她惊讶的语气。"
    translate None sv_night_0042:
        mor "他们出生就被从父母身边带走，连名字都不被允许知道。"
    translate None sv_night_0043:
        rs "为什么……？"
    translate None sv_night_0044:
        mor "这是传统。向来如此。"
    translate None sv_night_0045:
        mor "言者们还有个习惯，就是和王子们差不多同时出生。所以，把他们一起抚养长大向来都是合情合理的。"
    translate None sv_night_0046:
        mor "若想共同统治，他们就必须相互了解胜过了解自己。"
    translate None sv_night_0047:
        show morwen m dark sad with dis
        mor "卢修斯…他利用了他们之间的关系为自己谋利。他就是个阴险小人。"
    translate None sv_night_0048:
        show raen mw dark sad with dis
        rs "我们能打败他吗？"
    translate None sv_night_0049:
        mor "....."
    translate None sv_night_0050:
        mor "我不知道。"

    jump morwenchoices

label morwenaskcasaemyl:
    show raen mw dark sur with dis
    translate None sv_night_0051:
        rs "艾米尔和卡斯皮安年轻时差别大吗？"
    translate None sv_night_0052:
        show morwen m dark sur with dis
        mor "艾米尔和卡斯皮安？哦，完全不一样。"
    translate None sv_night_0053:
        rs "你能告诉我关于他们的事吗？"
    translate None sv_night_0054:
        mor "嗯…艾米尔要内向安静得多，但脾气也挺火爆。除了了解他的卡斯皮安，大多数人都会觉得他害羞。"
    translate None sv_night_0055:
        show morwen m dark smi with dis
        mor "他是个好孩子。勤奋又善良。"
    translate None sv_night_0056:
        mor "不过这对他的负担太重了。我看得出来他只想作为一个普通孩子，在普通家庭里长大。"
    translate None sv_night_0057:
        rs "那卡斯皮安呢？"
    translate None sv_night_0058:
        mor "嗯…"
    translate None sv_night_0059:
        mor "他如同太阳般温暖明亮，充满活力。他无比自信，并有着强烈的冒险精神。"
    translate None sv_night_0060:
        mor "天生的领袖。当他发言时，人们都会倾听。艾米尔对此十分钦佩。"
    translate None sv_night_0061:
        rs "他们俩都是那么…不同。"
    translate None sv_night_0062:
        show morwen m dark sad with dis
        mor "时间对人就是这样的影响。他们有足够的时间来酝酿怨恨，于是情感在他们体内沸腾，无处可去。"
    translate None sv_night_0063:
        rs "你觉得他们能和好吗？"
    translate None sv_night_0064:
        mor "但愿如此。他们两个都值得拥有这样的和解。"
    translate None sv_night_0065:
        mor "但谁知道呢。原谅一个人，从来都不是件容易的事。"
    translate None sv_night_0066:
        show raen mw dark sad with dis
        rs "..."
    translate None sv_night_0067:
        mor "你呢？你原谅艾米尔或卡斯皮安了吗？"
    translate None sv_night_0068:
        rs "我想是的。"
    translate None sv_night_0069:
        rs "卡斯皮安…不，我父亲…要是他知道我还活着，我相信…他一定会回来找我的，对吧？"
    translate None sv_night_0070:
        "莫温点头作为回应，仔细聆听着。"
    translate None sv_night_0071:
        rs "而艾米尔…他自己也是个环境的受害者。当然，他本可以无视那个尖叫着要他杀了我的声音，但是…"
    translate None sv_night_0072:
        rs "经过这么多年满腔怒火…我当真确定自己会做出不同的选择吗？"
    translate None sv_night_0073:
        show morwen m dark smi with dis
        mor "…雷恩，我就喜欢你这点。你总是这么积极乐观，如此宽宏大量。只要你确保不让任何人践踏你的底线，这就是很大的优点。"

    jump morwenchoices

label morwenaskillran:
    show raen mw dark sur with dis
    translate None sv_night_0074:
        rs "你了解伊尔兰吗？"
    translate None sv_night_0075:
        show morwen m dark hap with dis
        mor "哈哈哈，我觉得应该是我来问你才对。我不能说自己知道些什么，但我非常好奇。"
    translate None sv_night_0076:
        rs "听说他小时候来自奥雷利亚卡维拉。据我所知，他现在从事赏金猎人的工作。"
    translate None sv_night_0077:
        rs "我猜…大概是在某段旅程中他遇到了维拉斯，从那以后他们就一直结伴同行。"
    translate None sv_night_0078:
        mor "他们的关系很特别。这很好。"
    translate None sv_night_0079:
        mor "他们是如此迥异。性格相异，背景相左，寿命不同，然而…"
    translate None sv_night_0080:
        mor "他们亲密无间，密不可分。这让我心生嫉妒。"
    translate None sv_night_0081:
        show raen mw dark smi with dis
        rs "维拉斯看起来对伊尔兰很不错。"
    translate None sv_night_0082:
        mor "看样子，伊尔兰对维拉斯也一样。他们互相给予了彼此从未拥有过的东西。"

    jump morwenchoices

label morwenaskhuman:
    show raen mw dark sur with dis
    translate None sv_night_0083:
        rs "你能多告诉我些你人类时期的事吗？"
    translate None sv_night_0084:
        show morwen m dark sur with dis
        mor "你想了解更多关于我的事吗？"
    translate None sv_night_0085:
        rs "求你了？"
    translate None sv_night_0086:
        mor "嗯…这个嘛，我来自维迪斯南部海岸的一个小村庄。那里叫迈尔法尔。"
    translate None sv_night_0087:
        mor "那早已从记忆和地图上抹去。我作为农家女长大，主要在村庄里做零工。"
    translate None sv_night_0088:
        show morwen m dark smi with dis
        mor "你可能在想，像我这样平凡的人是如何升格为神的，对吧？"
    translate None sv_night_0089:
        show raen mw dark sad with dis
        rs "我确实好奇，但觉得直接问可能失礼…"
    translate None sv_night_0090:
        mor "胡说什么。我说过会与你分享一切。"
    translate None sv_night_0091:
        mor "一场大瘟疫席卷了我们村庄，很多人死去。长老们说众神抛弃了我们—这是上天为我们罪行降下的诅咒。"
    translate None sv_night_0092:
        "她用手指卷弄着发梢，仰望着繁星密布的夜空。"
    translate None sv_night_0093:
        mor "我根本没有立场与他们争辩。我只是个洗衣女工，但是…有一天，当我到河边洗衣服时，我发现河水似乎有些不对劲。"
    translate None sv_night_0094:
        mor "听起来很蠢，是吧？水质不佳会导致疾病本该是常识，但那时人们还不知道。"
    translate None sv_night_0095:
        show raen mw dark sur with dis
        "这确实一定是很久以前的事了…"
    translate None sv_night_0096:
        mor "长老们不愿听取我的发现，于是我决定自己动手。我带着净化水源的知识归来，果然不出所料，疾病就此止息。"
    translate None sv_night_0097:
        rs "大家一定把你当作英雄。"
    translate None sv_night_0098:
        show morwen m dark sad with dis
        mor "大部分村民确实如此。"
    translate None sv_night_0099:
        rs "大多数是吗？"
    translate None sv_night_0100:
        mor "起初长者们回避我，一个\"单纯女孩\"竟能解决问题而他们只能干坐着搓手指，这让他们感到难堪。"
    translate None sv_night_0101:
        mor "然而，这种回避很快演变成了赤裸裸的愤怒。"
    translate None sv_night_0102:
        show raen mw dark sad with dis
        rs "我很抱歉…"
    translate None sv_night_0103:
        mor "几个月后，我像往常一样在河边洗全村人的衣物。河水湍急汹涌。"
    translate None sv_night_0104:
        mor "…有人推了我，我溺亡了。那本是我的结局，但现在我却在这里。"
    translate None sv_night_0105:
        rs "...."
    translate None sv_night_0106:
        $ about_Morwen._text.append("作为人类，她在名为迈尔法尔的小村庄长大，那里早已从记忆和地图上消失。一场大瘟疫席卷了她的村庄，夺走了许多居民的性命。不同于长老们认为这是诅咒的观点，莫温想出了净化村庄水源的方法，拯救了许多人的生命。\n \n被区区一个洗衣女孩抢了风头这件事让长老们感到难堪和愤怒。可悲的是，这个故事以莫温溺亡在她深爱的河流中结束，她是被某个无名之辈推下去的。")
        mor "别担心，那都是{a=set_entry:enc_people->about_Morwen}{color=#87CEEB}很久以前{/color}{/a}的事了。我现在已经不介意了。"
    translate None sv_night_0107:
        rs "我还是…我太愤怒了…"

    if achievement.has("morwen_backstory"):
        pass
    else:
        $ renpy.display_notify("成就已解锁：平凡的洗衣少女")

    python:
        achievement.grant("morwen_backstory")
        achievement.sync()
    translate None sv_night_0108:
        show morwen m dark smi with dis
        mor "谢谢，雷恩。"

    jump morwenchoices

label morwen_after:
    show morwen m dark neu with dis
    translate None sv_night_0109:
        mor "我说得够多了，对吧？不如换我来拜托你一件事。"
    translate None sv_night_0110:
        show raen mw dark sur with dis
        rs "那是什么？"



    if fawn_route:
        translate None sv_night_0111:
            mor "我想了解更多关于福恩的信息。"
        translate None sv_night_0112:
            rs "关于福恩？嗯，让我想想…"
        translate None sv_night_0113:
            rs "他…对我真的很重要。我想为他变得更好。"
        translate None sv_night_0114:
            show morwen m dark smi with dis
            mor "你选得不错。他是个善良的好孩子。"
        translate None sv_night_0115:
            show raen mw dark neu blush with dis
            "我的脸红了，但还是继续说着。"
        translate None sv_night_0116:
            stop music fadeout 2.0
            rs "关于他…有件事我很担心。"


        window hide dissolve
        jump fawnsecretvillage1

    if cyne_route:
        stop music fadeout 2.0
        translate None sv_night_0117:
            mor "…是关于赛恩的事。"
        window hide dissolve
        jump cynesecretvillage1


    if leos_route:
        stop music fadeout 2.0
        translate None sv_night_0118:
            mor "..这是关于莱奥斯的。"
        window hide dissolve
        jump leossecretvillage1






############################################################################################################

label caspianraen:

    if leos_route or cyne_route:
        translate None sv_night_0119:
            cas sur "啊…"


        hide morwen
        hide raen
        with dissolve
        show morwen n dark cloakup smi at center
        show raen nw dark sur cloak at left
        show caspian n dark sur at right
        with dissolve

        translate None sv_night_0120:
            mor "…卡斯皮安。过来这边，别站在那儿傻看。"
        translate None sv_night_0121:
            "卡斯皮安别扭地别开脸，朝我们走来。"
        translate None sv_night_0122:
            mor "…知道吗，我从没想过能看到你们俩并肩站在一起。"
        translate None sv_night_0123:
            cas "我也一样。"
        translate None sv_night_0124:
            mor "…我突然觉得特别累。"
        translate None sv_night_0125:
            rs "那么，我该—"
        translate None sv_night_0126:
            mor "这是个适合散步的美好夜晚，雷恩。好好享受吧。"
        translate None sv_night_0127:
            hide morwen with dissolve
            show raen at slightleft
            show caspian at slightright
            with move
            "当她离开时，我的目光转向了卡斯皮安。"


    if fawn_route:
        hide morwen
        hide fawn
        with dissolve
        show raen at slightleft with move
        show caspian n dark sur at slightright with dissolve

    translate None sv_night_0128:
        cas "啊…抱歉，不是故意打断。你现在有空吗？"
    translate None sv_night_0129:
        rs "嗯，也不算忙。有什么事吗？"
    translate None sv_night_0130:
        cas "不，没什么特别的事。我只是觉得我们可以…我不知道，聊一会儿？"
    translate None sv_night_0131:
        rs "关于什么？"
    translate None sv_night_0132:
        show caspian n dark sad with dis
        cas "就是…随便聊聊？"
    translate None sv_night_0133:
        rs ".....?"
    translate None sv_night_0134:
        cas "…我觉得自己错过了你生活中的重要部分，我知道无法立即弥补这些… 但我希望能有机会试试。"
    translate None sv_night_0135:
        show raen nw dark neu with dis
        "我向他点头示意，然后我们肩并肩地慢慢穿过村庄。 "
    translate None sv_night_0136:
        "我想了解他。我不为发生的事责怪他，可想到他是我的父亲，我仍觉得怪怪的。"
    translate None sv_night_0137:
        cas "啊…跟我说说你吧。你是在孤儿院长大的？"
    translate None sv_night_0138:
        rs "是啊，终身如此。我还只是婴孩时，女院长在自家门阶上捡到了我。我想那大概是…就在你…"
    translate None sv_night_0139:
        cas "...."
    translate None sv_night_0140:
        cas "那么这位女院长呢？她对你好吗？"
    translate None sv_night_0141:
        show raen nw dark smi with dis
        rs "最仁慈的存在。在我心里阿拉拉永远如同生母。我…真的很想念她。"
    translate None sv_night_0142:
        show caspian n dark sur with dis
        cas "阿拉拉..？"
    translate None sv_night_0143:
        rs "…你认识她吗？"
    translate None sv_night_0144:
        cas "天啊，这个世界真小。她也抚养过我。"
    translate None sv_night_0145:
        show raen nw dark sur with dis
        rs "等等，什么？怎么可能？你是在孤儿院长大的？"
    translate None sv_night_0146:
        cas "不，不是的，当然不是。她更像是…我的导师？但这段关系又远超于此。我见到她的次数比见到亲生父母还多。"
    translate None sv_night_0147:
        "我的祖父母…"
    translate None sv_night_0148:
        "我永远没机会认识他们了。"
    translate None sv_night_0149:
        rs "但是…她怎么会从皇家教师变成经营孤儿院的？这根本说不通…"
    translate None sv_night_0150:
        show caspian n dark sad with dis
        cas "...."
    translate None sv_night_0151:
        cas "我跟你说过我和艾米尔偷溜出去的事对吧？其实…她为此承担了所有责难。这是我最后悔的事。她因为我而受罚。"
    translate None sv_night_0152:
        cas "当我们终于找到回奥雷利亚卡维拉的路时，她已经被逐出王室了。在那之后，我再也没见过她。我甚至不知道她是死是活。"
    translate None sv_night_0153:
        show raen nw dark sad with dis
        rs "…她本该知道真正的我是谁…"
    translate None sv_night_0154:
        cas "别生她的气。她一定是为了保护你。"
    translate None sv_night_0155:
        rs "我永远不可能对她生气。我…想要感谢她。是她让我得以正常成长。"
    translate None sv_night_0156:
        cas "这比你想象的要幸运得多。"
    translate None sv_night_0157:
        rs "我也能问你个问题吗？"
    translate None sv_night_0158:
        cas "随时恭候。"
    translate None sv_night_0159:
        show raen nw dark neu with dis
        rs "…我母亲是个什么样的人？"
    translate None sv_night_0160:
        show caspian n dark sca with dis
        cas "啊…"
    translate None sv_night_0161:
        "他叹了口气，突然停下脚步。"
    translate None sv_night_0162:
        cas "她曾是我的慰藉，也是挚友。"
    translate None sv_night_0163:
        show raen nw dark sur with dis
        rs "只是朋友？"
    translate None sv_night_0164:
        cas "这是个…漫长复杂的故事。当时我的感情和情绪都很混乱。那时候我甚至不懂什么是爱。"
    translate None sv_night_0165:
        show caspian n dark sad with dis
        cas "但我伤心欲绝，尽管那时我还不会用这个词来形容。她善良体贴，理解我的处境。我们互相扶持，我也很享受有她相伴的时光。"
    translate None sv_night_0166:
        rs "...."
    translate None sv_night_0167:
        cas "…她需要帮助。她生了病，想逃离家庭；而我孤身一人，渴望有个依靠。我们之间不是爱情，但我确实深爱着她。"
    translate None sv_night_0168:
        rs "是艾米尔吗？"
    translate None sv_night_0169:
        cas "….那是过去的事了，但曾经一度我会称他为「那个人」。"
    translate None sv_night_0170:
        "我打了个哈欠，卡斯的忧伤从脸上消失了。"
    translate None sv_night_0171:
        show caspian n dark smi with dis
        cas "好了，去睡会儿吧。很抱歉耽误你时间。"
    translate None sv_night_0172:
        show raen nw dark neu with dis
        rs "在我离开前…是索伦指引我来找你的。"
    translate None sv_night_0173:
        show caspian n dark sur with dis
        cas "索伦…？"
    translate None sv_night_0174:
        show raen nw dark sad with dis
        rs "他对你评价极高。他非常想念你。"
    translate None sv_night_0175:
        show caspian n dark sad with dis
        cas "我一直想回去找他，但是在发生了那件事之后…"
    translate None sv_night_0176:
        rs "我听说了这事。"
    translate None sv_night_0177:
        rs "此刻他已经昏迷，有可能永远醒不过来。要是…不，等他醒来的时候，我要你陪在我身边。"
    translate None sv_night_0178:
        cas "当然。"
    translate None sv_night_0179:
        show raen nw dark smi with dis
        rs "那就好。我该去睡了，晚安。"
    translate None sv_night_0180:
        hide raen
        hide caspian
        with dissolve
        "当我转身时，听到卡斯皮安在身后踱步的声音。"
    translate None sv_night_0181:
        cas smi "雷恩？谢谢你。"
    translate None sv_night_0182:
        rs c wsmi "你也是。"


    if cyne_route:
        jump cynenighttimesv

    if leos_route:
        jump leosnighttimesv

    if fawn_route:
        jump fawnsvnightaftercas

############################################################################################################

label veraselliot:
    scene bg sv room night:
        xpos 0.51 ypos 1.15 xanchor 0.5 yanchor 1.0 zoom 1.15

    with Fade(1.0, 1.0, 1.0)

    translate None sv_night_0183:
        "维拉斯独自坐在房间里，手指轻抚着自己的嘴唇。他触碰着双唇，不确定刚才发生了什么。"
    translate None sv_night_0184:
        "就在他停下来消化刚刚发生的一切时，埃利奥特推开门走了进来。"
    translate None sv_night_0185:
        show veras n dim sad1 at slightleft
        show elliot n dim smi at slightright
        with dissolve
        play music "sounds/bgm/night.ogg" fadein 2.0
        el "…维拉斯。很高兴见到你。"
    translate None sv_night_0186:
        "维拉斯平复呼吸，试图摆出严肃表情。他知道骗不过埃利奥特，但想保留些尊严。"
    translate None sv_night_0187:
        v "已经过去太久了。什么风把你吹来了？"
    translate None sv_night_0188:
        el "我只是想和挚友简单聊几句，这都不行吗？"
    translate None sv_night_0189:
        vmn "毕竟…简单的对话往往最后都不简单…"
    translate None sv_night_0190:
        show veras n dim smi1 with dis
        v "我永远都会为你留出时间。我猜你不是来告诉我，你已经改变主意想帮助我们了吧？"
    translate None sv_night_0191:
        "他走进房间，拉过一把椅子，正对着维拉斯坐下。"
    translate None sv_night_0192:
        el "不，我不这么认为。"
    translate None sv_night_0193:
        v "看来你还是老样子。一旦做了决定，就很难动摇你。"
    translate None sv_night_0194:
        show elliot n dim sad with dis
        el "…"
    translate None sv_night_0195:
        el "如果我带他们进入锡德卡汉，他们会死的。"
    translate None sv_night_0196:
        show veras n dim sad1 with dis
        v "……我不能保证会有不同的结果。"
    translate None sv_night_0197:
        el "你为什么要把自己置于险境来帮这些人？那些…言者。"
    translate None sv_night_0198:
        v "我知道…你生前与他们为敌，埃利奥特，但他们不是坏人。"
    translate None sv_night_0199:
        show elliot n dim gla with dis
        el "我与他们对抗是因为奉命行事。我对王室保持忠诚是因为我认为这样做是正确的。"
    translate None sv_night_0200:
        el "关于众神，我错怪了他们，对于给他们造成的伤害，我深感懊悔。"
    translate None sv_night_0201:
        el "至于言者们？我一点也不后悔，丝毫不后悔。他们的历史充满了背叛与谋杀。"
    translate None sv_night_0202:
        v "雷恩不是那样的，你知道的。他心地纯良。"
    translate None sv_night_0203:
        el "那用来腐化再适合不过了。"
    translate None sv_night_0204:
        v "哈啊…我不会试图说服你，但至少希望你这次能相信我的判断。"
    translate None sv_night_0205:
        show elliot n dim smi with dis
        el "反正我来这不是为了吵架的。我是来叙旧的。"
    translate None sv_night_0206:
        el "我很好奇你是怎么和一个人类结伴同行的。这不像你的作风。"
    translate None sv_night_0207:
        show veras n dim sur1 with dis
        v "伊尔兰？"
    translate None sv_night_0208:
        show veras n dim ouc1 with dis
        v "不知从何说起。我们初见时并不友善，但他是…帮我找到方向的人。若非是他，我不会活到今天。"
    translate None sv_night_0209:
        show elliot n dim sad with dis
        "埃利奥特脸上闪过讶异的神色。"
    translate None sv_night_0210:
        el "你爱上他了？"
    translate None sv_night_0211:
        show veras n dim emb1 with dis
        v "什么？"
    translate None sv_night_0212:
        el "维拉斯，丰收之神，爱上了一个凡人。我从未想过会看到这一天。"
    translate None sv_night_0213:
        v "...."
    translate None sv_night_0214:
        v "我想我…我好像喜欢他已经很久了…"
    translate None sv_night_0215:
        el "…你知道这永远不会有结果的，对吧？"
    translate None sv_night_0216:
        show veras n dim sad1 with dis
        v "我从没想过要…付诸行动。我不敢夺走属于他的未来。"
    translate None sv_night_0217:
        v "去爱一个人然后白头偕老…这是他的权利。我给不了他。"
    translate None sv_night_0218:
        el "...."
    translate None sv_night_0219:
        el "神明与凡人相恋只会带来心碎。你最好与他保持距离。"
    translate None sv_night_0220:
        el "…话又说回来，我算老几来指挥你该做什么？有时候最好的选择也未必是正确的做法。"
    translate None sv_night_0221:
        v "谢谢你，埃利奥特。我感激你的坦诚。"
    translate None sv_night_0222:
        el "那么之后你打算做什么？如果活下来的话。"
    translate None sv_night_0223:
        v "首先我要解放奥蕾莉亚诸神，然后…"
    translate None sv_night_0224:
        el "这里永远有你的容身之处。"
    translate None sv_night_0225:
        "维拉斯摇了摇头，嘴角泛起一丝苦涩的微笑。"
    translate None sv_night_0226:
        show veras n dim smi1 with dis
        v "……然后就是我该离去的时候了，我的朋友。我的使命将就此完成。"
    translate None sv_night_0227:
        el "令人钦佩的目标。如果你改变主意了，我会等着你。"

    stop music fadeout 3.0

    if cyne_route:
        jump aftersex

    if leos_route:
        jump aftersexleos3

    if fawn_route:
        jump fawnroute5start


############################################################################################################






    #
