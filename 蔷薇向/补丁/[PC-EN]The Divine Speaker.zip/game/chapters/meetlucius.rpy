label meetlucius:
    scene bg eclipse with dissolve
    window show dissolve
    translate None lucius_part1_0001:
        "我小心翼翼地推开月蚀酒吧的门。就这样贸然闯入感觉有点尴尬，但是在寒冷的室外干站着也无济于事。"

    if leos_route:
        translate None lucius_part1_0002:
            "莱奥斯跟在我身后进来，环顾着这家店铺。"


    if cyne_route:
        show ds n dim neu at slightright
        show raen nw dim sur at slightleft
        with dissolve

    if fawn_route:
        show ds n dim neu at right
        show raen nw cloak dim sur at center
        show fawn nw cloak dim neu at left
        with dissolve

    if leos_route:
        show ds n dim neu at slightright
        show raen nw dim sur at slightleft
        show leos nw dim neu at left
        with dissolve
        translate None lucius_part1_0003:
            ae "......."


    if leos_route:
        translate None lucius_part1_0004:
            l "...."


    if fawn_route:
        translate None lucius_part1_0005:
            rs "啊…"
        translate None lucius_part1_0006:
            show fawn nw sad with dis
            f "....."


    translate None lucius_part1_0007:
        rs "啊……早上好……言者先生…"
    translate None lucius_part1_0008:
        "卡斯皮安已不见踪影。相反地，说书人正倚靠着一张桌子站着，对我突然闯入显得很是惊讶。"
    translate None lucius_part1_0009:
        show ds n dim ann with dis
        ae "….就叫我艾米尔吧。"
    translate None lucius_part1_0010:
        show raen nw dim sad with dis
        rs "啊…好吧，艾米尔…"


    if leos_route:
        translate None lucius_part1_0011:
            "我注意到身旁的莱奥斯移开了视线。"
        translate None lucius_part1_0012:
            rs "…你们两个之间发生什么事了吗？"
        translate None lucius_part1_0013:
            show leos nw dim sur with dis
            l "…没什么，什么事都没有。"
        translate None lucius_part1_0014:
            rs "好吧…"


    translate None lucius_part1_0015:
        "如果说听到卡斯皮安叫他艾米尔已经够尴尬的话，那从我口中说出这个名字几乎令人心痛。"
    translate None lucius_part1_0016:
        "出于敬意，从来没有人直呼说书人的本名。这本就不是件理所应当的事。"
    translate None lucius_part1_0017:
        "…艾米尔。艾…艾米米尔。好吧，没事的。我能做到。"


    if cyne_route:
        translate None lucius_part1_0018:
            ae "你那小朋友去哪了？"
        translate None lucius_part1_0019:
            show raen nw dim sur with dis
            rs "朋友？你是说赛恩？"
        translate None lucius_part1_0020:
            show raen nw dim sad with dis
            rs "他…"
        translate None lucius_part1_0021:
            show ds n dim icy with dis
            "察觉到我没有回应，艾米尔露出了似笑非笑的表情。这不是在嘲笑我，而更像是他确认了某件事。"

    translate None lucius_part1_0022:
            ae "总是这样的结局。被抛弃，被推到一边。每个人都向前走，把你遗忘。"
    translate None lucius_part1_0023:
            rs "那真是…"
    translate None lucius_part1_0024:
            "我想说这不是真的，但我无法摆脱那种感觉—他的话是对的。"


    translate None lucius_part1_0025:
        rs "…能问你个问题吗？"
    translate None lucius_part1_0026:
        show ds n dim neu with dis
        ae "如果你非要这么做的话。"
    translate None lucius_part1_0027:
        rs "……你到底是怎么找到我的？你怎么到这里来的？我们在路上已经走了那么久。"
    translate None lucius_part1_0028:
        ae "...."
    translate None lucius_part1_0029:
        show ds n dim ann with dis
        ae "斯塔格威奇的一个人告诉了我你的去向。"
    translate None lucius_part1_0030:
        show raen nw dim sur with dis
        rs "尼科斯？"
    translate None lucius_part1_0031:
        ae "对。"
    translate None lucius_part1_0032:
        rs "你…你有没有伤害他？"
    translate None lucius_part1_0033:
        ae "...."



    if leos_route:
        translate None lucius_part1_0034:
            show leos nw dim pis with dis
            l "你竟会卑贱至此？"


    translate None lucius_part1_0035:
        show raen nw dim sad with dis
        stop music fadeout 2.0
        rs "他只是在执行工作！你怎么能..你怎么敢—"
    translate None lucius_part1_0036:
        play music "sounds/bgm/Fooling Around Tiny.ogg" fadein 1.0
        nik smi "如果不再真的需要我了，我就回家了。这样行吗，艾米尔？"

    show raen nw dim sur with hpunch

    if leos_route or cyne_route:
        translate None lucius_part1_0037:
            rs "啊！"


    if fawn_route:
        translate None lucius_part1_0038:
            show fawn nw sur with dis
            fr "啊！"


    if leos_route:
        translate None lucius_part1_0039:
            show leos nw dim sur with dis
            l "哦，这可真滑稽。"


    show ds n dim ang with dis
    translate None lucius_part1_0040:
        ae "呃…"



    if cyne_route:
        show raen at center
        show ds at right
        with move
        show nikos n dim neu at left with dissolve

    if leos_route:
        show ds at farright with move
        show nikos n dim neu at slightright with dissolve:
            xpos 0.67 ypos 1.0 xanchor 0.8 yanchor 1.0

    if fawn_route:
        show fawn at farleft
        show raen at cenleft
        show ds at farright
        with move
        show nikos n dim neu at cenright with dissolve


    translate None lucius_part1_0041:
        nik "哎呀，不是故意吓你们的！"
    translate None lucius_part1_0042:
        rs "尼科斯？！"

    show nikos n dim smi with dis

    if fawn_route:
        translate None lucius_part1_0043:
            nik "雷恩！福恩也在！真高兴又见到你们俩。"
        translate None lucius_part1_0044: # MISSING LINE
            rs "你…你在这里做什么？！"



    if cyne_route:
        translate None lucius_part1_0045:
            nik "雷恩！又见到你真是太好了。福恩和莱奥斯怎么了？"
        translate None lucius_part1_0046:
            rs "他们…他们就在附近，只是有点忙。"
        translate None lucius_part1_0047:
            "太忙了都没能道别，看来…"


    if leos_route:
        translate None lucius_part1_0048:
            nik "雷恩！真高兴又见到你。福恩怎么了？"
        translate None lucius_part1_0049:
            rs "他就在…附近，只是有点忙。"
        translate None lucius_part1_0050:
            "忙得连道别都顾不上了，看来…"


    if cyne_route or leos_route:
        translate None lucius_part1_0051:
            rs "话说……你们在这干嘛？不该在斯塔格威奇吗？"


    translate None lucius_part1_0052:
        nik "嗯？"
    translate None lucius_part1_0053:
        show nikos n dim lau with dis
        nik "当时我正带艾米尔去锡德卡汉。起先我别无选择，但也不算太糟！"
    translate None lucius_part1_0054:
        rs "什么？！"

    stop music fadeout 2.0
    window hide dissolve

    scene bg tavern with Fade(1.0, 1.0, 1.0)
    window show dissolve
    translate None lucius_part1_0055:
        "斯塔格威奇又是一个慵懒的夜晚—镇上的灯火渐渐亮起，居民们都回到家中准备就寝。"
    translate None lucius_part1_0056:
        "尼科斯也不例外。随着表演者们的离开，酒馆空空如也，他正准备提早打烊回家。"
    translate None lucius_part1_0057:
        show nikos n lau with dissolve
        nik "这真是漫长的一天。我寻思该收拾收拾回家了。"
    translate None lucius_part1_0058:
        play sound "sounds/sfx/knock.ogg" fadein 1.0
        "一阵敲门声让尼科斯转向门口，猜测着这么晚会是谁来造访。"
    translate None lucius_part1_0059:
        play music "sounds/bgm/creepy.ogg" fadein 2.0
        show nikos n sur with dis
        nik "喂？"
    translate None lucius_part1_0060:
        show nikos with hpunch
        nik "什—"
    translate None lucius_part1_0061:
        "沉睡鸵鸟\"的门砰一声被推开了。"
    translate None lucius_part1_0062:
        show nikos at slightleft with move
        show ds n ann at slightright with dissolve
        nik "....."
    translate None lucius_part1_0063:
        show nikos n smi with dis
        nik "…呃，你好。抱歉，我们今晚准备关门了…除非你是要住店？"
    translate None lucius_part1_0064:
        ae "有个棕发男孩从这里经过吗？"
    translate None lucius_part1_0065:
        show nikos n neu with dis
        nik "...."
    translate None lucius_part1_0066:
        nik "棕色头发的…昨晚确实有个这样的人在这留宿。你认识他吗？"
    translate None lucius_part1_0067:
        show ds n ang with dis
        ae "告诉我他去哪了，否则。"
    translate None lucius_part1_0068:
        show nikos n sur with dis
        nik "哇，哇。别这么心急。他是你什么人？"
    translate None lucius_part1_0069:
        uv "别让他这样质问你。你可是说书人。他竟敢这样？抓住他。逼他说出来。"
    translate None lucius_part1_0070:
        "那个对艾米尔说话的声音并没有让他感到惊讶。毕竟从他出生起就一直在聆听众神的声音。如果说有什么特别的话，现在这个对他说话的声音反而让他感到平静、放松。"
    translate None lucius_part1_0071:
        "那些在他脑海里回荡的数百个喧嚣声音，终于不再混乱不堪。"
    translate None lucius_part1_0072:
        "艾米尔走上前去，按住尼科斯的肩膀。"
    translate None lucius_part1_0073:
        show ds with hpunch
        ae "我说过你得告诉我他去哪了！"
    translate None lucius_part1_0074:
        nik "好了！好了，冷静点。你在找…雷恩？他们不久前刚动身去奥克斯哈伯了。"
    translate None lucius_part1_0075:
        "搭在尼科斯肩膀上的手迟疑了一下。他没料到会这么容易就得到答案。"
    translate None lucius_part1_0076:
        show ds n sur with dis
        ae "噢…噢。谢谢—"
    translate None lucius_part1_0077:
        uv "你知道去奥克斯哈伯的路吗，白痴？"
    translate None lucius_part1_0078:
        show ds n ann with dis
        ae "….你得给我带路。"
    translate None lucius_part1_0079:
        nik "什么？我不确定我有时间—"
    translate None lucius_part1_0080:
        show ds n ang with dis
        ae "...."
    translate None lucius_part1_0081:
        nik "好吧，好吧！行。我可以给你带路，但我们得明天才能出发。"
    translate None lucius_part1_0082:
        show ds n neu with dis
        ae "我们马上出发。收拾好你的行李。"
    translate None lucius_part1_0083:
        show nikos n sca with dis
        nik "什…什么？很抱歉，我连一辆马车都没有，甚至连一匹马也没有。我们只能一路步行，这个时间点了是不会有人出行的！"
    translate None lucius_part1_0084:
        show ds n ann with dis
        ae "那我们就走。快些。"
    translate None lucius_part1_0085:
        nik "..........."
    translate None lucius_part1_0086:
        "就在艾米尔即将从进来的那扇门逃出去时，他快速扫视了一圈酒馆。心头突然涌起一阵刺痛，那是当人们看着曾经珍视之物时才会有的、难以言喻的感受。"
    translate None lucius_part1_0087:
        "他急忙想要掩埋的一种感觉。"

    window hide dissolve

    scene bg forestnight with dissolve:
        xpos 0.65 ypos 1.3 xanchor 0.5 yanchor 1.0 zoom 1.35
        linear 20.0 xpos 0.33 ypos 1.3 xanchor 0.5 yanchor 1.0 zoom 1.35
    window show dissolve
    translate None lucius_part1_0088:
        amn "我这是在做什么，如此疯狂地追逐着他… "
    translate None lucius_part1_0089:
        uv "复仇！这是你最擅长的，不是吗？"
    translate None lucius_part1_0090:
        amn "复仇…究竟是为了什么？仅仅因为他长得像他？"
    translate None lucius_part1_0091:
        ae sad "...."
    translate None lucius_part1_0092:
        nik sca "呃…你还好吗？"
    translate None lucius_part1_0093:
        ae ann "走。你来这儿不是为了闲扯淡的。"
    translate None lucius_part1_0094:
        nik neu "我能至少知道你的名字吗？"
    translate None lucius_part1_0095:
        ae "…艾米尔。现在，安静点。"
    translate None lucius_part1_0096:
        "他们大部分的旅程都是这样—要么寂静无声，要么就是尼科斯试图搭话却被艾米尔打断。"
    translate None lucius_part1_0097:
        "斯塔格威奇到奥克斯哈伯的路程算不上近便。走了一整夜后，尼科斯终于说服艾米尔：要想活着走完这趟旅程，他们必须休息。 "
    translate None lucius_part1_0098:
        "他们在荒野深处的参天大树树根旁倚靠，艾米尔再次暗自叹息。"
    translate None lucius_part1_0099:
        "尼科斯堆起干木头和树叶，然后看向艾米尔。"
    translate None lucius_part1_0100:
        stop music fadeout 2.0
        nik sur "你能点着这个吗？"
    translate None lucius_part1_0101:
        ae sur "你说什么？"
    translate None lucius_part1_0102:
        nik "我只是在想。这是你第一次在野外过苦日子吗？"
    translate None lucius_part1_0103:
        play music "sounds/bgm/night.ogg" fadein 2.0
        ae sad "……不，但上次是……很多年前的事了。"
    translate None lucius_part1_0104:
        nik smi "我可以教你，如果你愿意的话。说不定哪天你独自在这儿，会用得上。"
    translate None lucius_part1_0105:
        "艾米尔没有回答，但仍然紧紧盯着尼科斯的动作。不一会儿，一团火焰摇曳着燃起。"
    translate None lucius_part1_0106:
        nik "很简单对吧？那做饭呢？"
    translate None lucius_part1_0107:
        nik "我带了些食材过来。我算是半个厨师吧，如果让我自己说的话。你饿了吗？"
    translate None lucius_part1_0108:
        uv "你想被毒死吗？这可不像你，我太失望了。"
    translate None lucius_part1_0109:
        ae "啊…"
    translate None lucius_part1_0110:
        ae "我…"
    translate None lucius_part1_0111:
        "他把这个声音推到脑海深处。虽然很烦人，但挨饿更难受。"
    translate None lucius_part1_0112:
        ae "…是有点饿。谢谢你。"
    translate None lucius_part1_0113:
        nik lau "不客气。你不是本地人吧？"
    translate None lucius_part1_0114:
        ae "…你这么快就看出来了？"
    translate None lucius_part1_0115:
        nik "喂，我见过很多人。你感觉很不一样。像个王子什么的。"
    translate None lucius_part1_0116:
        ae "…我根本不是（那种人）。只是个…旅人。"
    translate None lucius_part1_0117:
        "起初，尼科斯掏出些食物—主要是蔬菜和坚果—然后才是煎锅和勺子。"
    translate None lucius_part1_0118:
        ae sur "这些都是你带来的？"
    translate None lucius_part1_0119:
        nik "人就该时刻做好应对万全的准备！"
    translate None lucius_part1_0119b:
        nik "给！搅拌这个。"
    translate None lucius_part1_0120:
        "当尼科斯往锅里加食物时，被硬塞了木勺的说书人亲自搅拌起来。"
    translate None lucius_part1_0121:
        "当然，他的厨艺糟糕透顶。像他这样的人要烹饪技能有什么用？部分食物烧焦了，其余的也不小心从锅里弹了出来。"
    translate None lucius_part1_0122:
        nik sur "....."
    translate None lucius_part1_0123:
        ae sur "....."
    translate None lucius_part1_0124:
        ae sad "我…我很抱歉，我不是故意—"
    translate None lucius_part1_0125:
        nik lau "啊哈哈哈！不用，不用。谁都有第一次嘛。来，看好了。要像这样做。"
    translate None lucius_part1_0126:
        uv "我就当没看见这回事。"
    translate None lucius_part1_0127:
        ae sur "这样？"
    translate None lucius_part1_0128:
        nik "没错。看看它现在看起来多棒！"

    scene black with dissolve

    translate None lucius_part1_0129:
        "从那以后，两人之间的对话如同河水般自然流淌。尼科斯惊讶于艾米尔的生活技能竟如此匮乏—他是怎么活到现在的？"


    scene bg oxhabor day
    show ds n dim sad at slightleft
    show nikos n dim neu at slightright
    with Fade(1.0, 1.0, 1.0)

    translate None lucius_part1_0130:
        "他们的旅途将他们带到了奥克斯哈伯，到那儿却发现雷恩已经离开。四处打听后，得知他们已经出城了。"
    translate None lucius_part1_0131:
        ae "....."
    translate None lucius_part1_0132:
        ae "……回家吧，尼科斯。我已经拖着你走了这么远，结果呢？他已经不在了。"
    translate None lucius_part1_0133:
        nik "经过昨晚那件事后让你独自离开？至少我得把你护送到锡德卡汉，不过我们肯定不会步行前往。"
    translate None lucius_part1_0134:
        "艾米尔低垂着眼眸。愧疚感压得他喘不过气。他何德何能配得上这份善意？"
    translate None lucius_part1_0135:
        "他明明只是威胁强迫对方跟着自己。"
    translate None lucius_part1_0136:
        nik "我有个主意。跟我来。"
    translate None lucius_part1_0137:
        "二人并肩走向城镇外围。商旅们正忙着装载货物，马车和马匹杂乱地散落各处。"
    translate None lucius_part1_0138:
        show nikos n dim smi with dis
        nik "我们可以搭个便车。就算乘马车，也得好几天才能到那儿。"
    translate None lucius_part1_0139:
        show ds n dim sur with dis
        ae "谁会好心到—"
    translate None lucius_part1_0140:
        show ds at left
        show nikos at right
        with move
        show lilas n dim neu with dis
        lil "你们是打算搭车去锡德卡汉？"
    translate None lucius_part1_0141:
        show nikos n dim lau with dis
        nik "哎呀，你好啊小姑娘！确实如此。你们也往那个方向去吗？"
    translate None lucius_part1_0142:
        lil "…我这里有。你要的话，我有多余空间。"
    translate None lucius_part1_0143:
        ae "你…你确定吗？"
    translate None lucius_part1_0144:
        "她缓缓地点了点头。"
    translate None lucius_part1_0145:
        lil "请上车吧。路途遥远，我宁愿现在出发。"
    translate None lucius_part1_0146:
        hide lilas
        hide ds
        hide nikos
        with dissolve
        "他俩爬进后座，各自安顿舒服了。"

    window hide dissolve

    scene bg wagon ox with dissolve:
        xpos 0.67 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 0.84
        linear 20.0 xpos 0.3 ypos 1.0  xanchor 0.5 yanchor 1.0 zoom 0.84
    window show dissolve
    translate None lucius_part1_0147:
        nik sur "这些都是什么？你是商人吗？"
    translate None lucius_part1_0148:
        lil neu "….从某种意义上说。我这可是在送货上门。要是你那么容易就心里别扭的话，我可不建议你翻这些箱子。"
    translate None lucius_part1_0149:
        nik lau "知道了。我会管好自己的手！"
    translate None lucius_part1_0150:
        lil "…虽然无需提及，但我要绕道苋红森林。这会多花一天的路程。"
    translate None lucius_part1_0151:
        nik "哈哈，要穿过这里简直是找死。还是绕过去吧！"
    translate None lucius_part1_0152:
        stop music fadeout 2.0
        nik "我已经多年没去过锡德卡汉了！你去过吗？"
    translate None lucius_part1_0153:
        ae sad "……没有。从没去过。"
    translate None lucius_part1_0154:
        ae "我年轻时…曾与人约定有一天要一起旅行到那里。"
    translate None lucius_part1_0155:
        uv "又在想那个叛徒了？"
    translate None lucius_part1_0156:
        ae "......"
    translate None lucius_part1_0157:
        nik sur "真的吗？一直没机会去？"
    translate None lucius_part1_0158:
        play music "sounds/bgm/sad.ogg" fadein 2.0
        ae "…他去世了。我不愿独自前往，所以从未成行。"
    translate None lucius_part1_0159:
        nik smi "我想你会喜欢的。就当这是在他记忆中的一次旅行吧。"


    scene black with dissolve
    translate None lucius_part1_0160:
        "这趟旅程漫长而艰辛。当他们终于抵达锡德卡汉，艾米尔踏入积雪中时，他惊呆了。"

    scene bg sc day with dissolve:
        xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.46
        linear 20.0 xpos 0.5 ypos 1.44 xanchor 0.5 yanchor 1.0 zoom 1.46
    translate None lucius_part1_0161:
        "惊呆了，却又黯然神伤。"
    translate None lucius_part1_0162:
        amn "真…美啊。要是他也能亲眼看到就好了。"
    translate None lucius_part1_0163:
        ae sur "...?"
    translate None lucius_part1_0164:
        amn "我说，要是他也能亲眼看到就好了…"
    translate None lucius_part1_0165:
        ae "什么…？"
    translate None lucius_part1_0166:
        "这一次，没人回应他。无人与他对话，也无人挤占他的思绪。生平第一次，周遭陷入完全的、死寂般的至寂。"

    stop music fadeout 2.0

    scene bg eclipse

    if fawn_route:
        show ds n dim ann at farright
        show raen nw dim cloak sur at cenleft
        show fawn nw dim cloak sur at farleft
        show nikos n dim neu at cenright
        with Fade(1.0, 1.0, 1.0)

    if cyne_route:
        show raen nw dim sur at center
        show ds n dim ann at right
        show nikos n dim lau at left
        with Fade(1.0, 1.0, 1.0)

    if leos_route:
        show ds n dim neu at right
        show raen nw dim sur at slightleft
        show leos nw dim neu at left
        show nikos n dim neu at slightright:
            xpos 0.67 ypos 1.0 xanchor 0.8 yanchor 1.0
        with Fade(1.0, 1.0, 1.0)

    play music "sounds/bgm/Discovery.ogg" fadein 3.0
    translate None lucius_part1_0167:
        rs "你们俩…结伴走了这么远？真是…出乎意料。"



    if cyne_route or fawn_route:
        translate None lucius_part1_0168:
            nik "啊哈哈，我总是能给人惊喜！总之我那可怜又无人看管的客栈肯定想我了，我先告辞。雷恩，艾米尔，你们改天该来坐坐。把朋友们也带上。"
        translate None lucius_part1_0169:
            nik "特别是那个红头发的。他一个人就能招来整屋子客人。"


    if leos_route:
        translate None lucius_part1_0170:
            nik "啊哈哈，我总是能给人惊喜！总之我那可怜又无人看管的客栈肯定想我了，我先告辞。雷恩，艾米尔，你们改天该来坐坐。把朋友们也带上。"
        translate None lucius_part1_0171:
            nik "特别是福恩。他的歌声一个人就能招来整屋子客人。"



    hide nikos with dissolve

    if fawn_route:
        show raen at center
        show fawn at left
        show ds at right
        with move

    if cyne_route:
        show raen at slightleft
        show ds at slightright
        with move

    if leos_route:
        show ds at slightright with move


    translate None lucius_part1_0172:
        "他挥了挥手，离开了建筑。"
    translate None lucius_part1_0173:
        show ds n dim ann with dis
        ae "哦，看在…的份上，现在你满意了？你觉得我就是个可怜又没用的傻瓜，连自己来的路都找不到？行吧，随你怎么想。"
    translate None lucius_part1_0174:
        rs "…..其实我刚才在想，这让你看起来更有几分人情味。"


    if fawn_route:
        show fawn nw smi with dis
        translate None lucius_part1_0175:
            f "我很高兴我们又见到他了……"
        translate None lucius_part1_0176:
            rs "我也是。咱们晚点一定要再来。"


    if leos_route or cyne_route:
        show raen nw dim sad with dis
        translate None lucius_part1_0177:
            rs "我希望还有机会与大家重逢。"


    if cyne_route:
        show ds at right
        show raen at left
        with move
        show caspian n work sur with dis

    if leos_route:
        show ds at right with move
        show caspian n dim work sur at slightright with dissolve:
            xpos 0.62 ypos 1.0 xanchor 0.8 yanchor 1.0

    if fawn_route:
        show ds at farright
        show fawn at farleft
        show raen at cenleft
        with move
        show caspian n dim work sur at cenright with dissolve

    translate None lucius_part1_0178:
        cas "唔…没想到会看到你们俩在一起。这次不是要互相残杀了吧？"
    translate None lucius_part1_0179:
        "门猛地打开，卡斯皮安跨步走了进来。"
    translate None lucius_part1_0180:
        ae "呃…"
    translate None lucius_part1_0181:
        show raen nw sur with dis
        rs "卡斯皮安…"
    translate None lucius_part1_0182:
        show raen nw sad with dis
        rs "...."
    translate None lucius_part1_0183:
        rs "我已经决定了。我想是时候该回家了。"

    show caspian n sad with dis

    if fawn_route:
        translate None lucius_part1_0184:
            cas "…我早料到了。你呢？"
        translate None lucius_part1_0185:
            show fawn nw sur with dis
            f "我？"
        translate None lucius_part1_0186:
            show fawn nw neu with dis
            f "…雷恩去哪我就去哪。如果您允许的话，长官。"
        translate None lucius_part1_0187:
            show caspian n smi with dis
            cas "你这样子简直像是在请求我祝福你们的婚事。"
        translate None lucius_part1_0188:
            show fawn nw emb with dis
            f "什么？！我—不…不是的！完全没有！还没呢！"
        translate None lucius_part1_0189:
            cas "哦？还没呢？"
        translate None lucius_part1_0190:
            f "啊…"
        translate None lucius_part1_0191:
            show raen nw smi with dis
            "他把脸埋在双手之间，卡斯皮安和我都忍不住笑了起来。艾米尔安静地看着我们，仿佛置身于我们的谈话之外。"
        translate None lucius_part1_0192:
            cas "你的朋友们呢？不想道个别吗？"
        translate None lucius_part1_0193:
            show raen nw sad with dis
            rs "…我确实认为…但我想他们不这么觉得。"


    if cyne_route:
        translate None lucius_part1_0194:
            cas "…我早该料到的。那你朋友呢？"
        translate None lucius_part1_0195:
            rs "....."
        translate None lucius_part1_0196:
            rs "我想…这只是我。"


    if leos_route:
        translate None lucius_part1_0197:
            cas "…我早该料到的。那你朋友呢？"
        translate None lucius_part1_0198:
            rs "…我猜他们太忙了。"
        translate None lucius_part1_0199:
            show leos nw dim smu with dis
            "我看向莱奥斯并露出微笑，很高兴有他在身边。他也回以微笑，但我能感觉到有些不对劲。"


    if leos_route or cyne_route:
        translate None lucius_part1_0200:
            show caspian n ang with dis
            "卡斯皮安皱了皱眉，额头出现一道皱纹。"
        translate None lucius_part1_0201:
            cas "他们没有道别，对吧？"
        translate None lucius_part1_0202:
            rs "...."


    translate None lucius_part1_0203:
        show caspian n sad with dis
        cas "…还有时间先找到他们，你知道的。不必这么匆忙离开。"
    translate None lucius_part1_0204:
        ae "如果要跟我走，那我们现在就出发。"
    translate None lucius_part1_0205:
        cas "艾米尔，发发善心吧。"
    translate None lucius_part1_0206:
        ae "如果他愿意在这些事情上浪费时间，那是他的自由。我可不等了。"

    hide ds with dissolve

    if fawn_route:
        show fawn at left
        show raen at center
        show caspian at right
        with move

    if cyne_route:
        show raen at slightleft
        show caspian at slightright
        with move

    if leos_route:
        show caspian at slightright with move


    translate None lucius_part1_0207:
        "他率先离开建筑物，甚至没有回头确认我们是否跟着。"
    translate None lucius_part1_0208:
        cas "...."
    translate None lucius_part1_0209:
        cas "…抱歉他这样，他一直都有点…喜怒无常。现在看来随着年龄增长变得更严重了。"


    if cyne_route or fawn_route:
        translate None lucius_part1_0210:
            "我们跟着他出去，小心翼翼地关上了身后的门。"


    if leos_route:
        translate None lucius_part1_0211:
            cas "……你们两个不花点时间道别吗？艾米尔交给我来对付。"
        hide caspian
        hide raen
        hide leos
        with dissolve
        translate None lucius_part1_0212:
            "卡斯皮安跟着他出去了，只留我和莱奥斯独处。"
        show leos mw dim sur at mleft
        show raen mw dim sad at mright
        with dissolve
        translate None lucius_part1_0213:
            l "我想终究是我错了。"
        translate None lucius_part1_0214:
            rs "看起来确实如此。"
        translate None lucius_part1_0215:
            l "这种情况并不常见，所以你最好好好品味。"
        translate None lucius_part1_0216:
            rs "...."
        translate None lucius_part1_0217:
            rs "莱奥斯，我…"
        translate None lucius_part1_0218:
            show leos mw dim pis with dis
            l "别。别说道别。"
        translate None lucius_part1_0219:
            show raen mw dim sur with dis
            rs "为什么……？"
        translate None lucius_part1_0220:
            l "我不知道自己能否承受得住。"
        translate None lucius_part1_0221:
            show raen mw dim neu with dis
            rs "…那么我就不说再见了。因为这不是永别。我会回来的。"
        translate None lucius_part1_0222:
            "某个时刻，他抬手将一只手掌覆在我的头顶。他轻轻揉乱我的头发，然后将手掌顺势滑落至我的脸颊。"
        translate None lucius_part1_0223:
            rs "...."
        translate None lucius_part1_0224:
            "接着他狠狠捏了它一下。"
        translate None lucius_part1_0225:
            show raen mw dim sur blush with dis
            rs "喂！"
        translate None lucius_part1_0226:
            show leos mw dim smu with dis
            l "这一切是不是有点太感情用事了？"
        translate None lucius_part1_0227:
            rs "我以为我们正有一段美好时光！"
        translate None lucius_part1_0228:
            l "以后还有很多时间创造美好回忆，对吧？"
        translate None lucius_part1_0229:
            show raen mw dim sad with dis
            rs "……嗯。"
        translate None lucius_part1_0230:
            "这太像莱奥斯了。他很容易尴尬，总是忍不住用讽刺来掩饰。"
        translate None lucius_part1_0231:
            "其实本不需要任何冗长的告别，可一种沉重的感觉却压在了我的心上。"
        translate None lucius_part1_0232:
            "这…这个选择真的对吗？"


    window hide dissolve


    scene bg sc grey with dissolve
    window show dissolve
    translate None lucius_part1_0233:
        "在我们准备离开时，卡斯皮安和艾米尔之间弥漫着尴尬的气氛。仿佛他们都有话想对对方说，却都不愿第一个开口。"
    translate None lucius_part1_0234:
        "街道依然空荡荡的—阴沉的天空让一切都暗了下来。"


    if fawn_route:
        translate None lucius_part1_0235:
            "我疯狂地在街道上搜寻莱奥斯或赛恩的踪迹，但他们始终没有出现。"
        translate None lucius_part1_0236:
            cas wsad "艾米尔，我们能单独谈谈—"


    stop music fadeout 4.0




    if cyne_route:
        translate None lucius_part1_0237:
            cas wsad "好吧..看来就是现在—"
        scene bg sc grey:
            xpos 0.51 ypos 1.24 xanchor 0.5 yanchor 1.0 zoom 1.57
        show cyne mw dim sur
        with dissolve
        translate None lucius_part1_0238:
            c "等—等等！等一下！别动！一步都别往前走！"
        translate None lucius_part1_0239:
            show cyne at mleft with move
            show raen mw dim sur at mright with dissolve
            "我猛地转身面对那个声音—一个我已经如此想念的声音。"
        translate None lucius_part1_0240:
            rs "赛恩！"
        translate None lucius_part1_0241:
            show cyne mw sad with dis
            c "我…我去了旅馆，但你已经走了。抱歉我来晚了。你…你真的要离开吗？"
        translate None lucius_part1_0242:
            show raen mw sad with dis
            rs "....."
        translate None lucius_part1_0243:
            "在你说不在乎我做什么之后，在你说不想再与我扯上关系之后，你怎么还能用这样的表情说这种话？"
        translate None lucius_part1_0244:
            rs "唉—"


    if leos_route:
        translate None lucius_part1_0245b:
            cas wsad "嗯…我想就这样了吧。"
        #translate None lucius_part1_0245c: # MISSING
            #ae "About time. Quickly, we will depart immediately."
        translate None lucius_part1_0245:
            "我想对莱奥斯说些什么—随便什么话都行。即便那不是道别，感觉也像是在告别。我真的还能再见到他吗？"
        translate None lucius_part1_0246:
            "我张开嘴，但感觉喉咙里像堵了个疙瘩，什么也说不出来。"
        translate None lucius_part1_0247:
            rs c wsad "莱奥斯—"


    translate None lucius_part1_0248:
        u "真没想到会在这儿见到你，艾米留斯！"


    if cyne_route:
        hide raen
        hide cyne
        hide fawn
        hide leos
        with dissolve

        scene bg sc grey with dissolve

    translate None lucius_part1_0249:
        play music "sounds/bgm/creepy.ogg" fadein 3.0
        "一个黑发如夜、红瞳夺目的陌生男子突然走近，对着艾米尔扬起灿烂笑容，而后者只是困惑地回望着。"
    translate None lucius_part1_0250:
        show caspian n work dim neu at center
        show ds n dim neu at left
        show luc n dim smir cloak at right
        with dissolve
        "他姿态闲适而从容。属于那种无论走到哪里，都能摆出一副此处归他所有的架势的人。"
    translate None lucius_part1_0251:
        "刹那间，我感到后颈一阵刺痛。"


    if leos_route:
        translate None lucius_part1_0252:
            l c wthi "那个声音…"
        translate None lucius_part1_0253:
            rs c wsur "...?"
        translate None lucius_part1_0254:
            "霎时间，莱奥斯抓住了我的手，一把将我拽到他身后。他站在那个神秘男人和我之间，眉头紧锁。"


    translate None lucius_part1_0255:
        show ds n ann with dis
        ae "…我们认识吗？"
    translate None lucius_part1_0256:
        show luc n dim sad cloak with dis
        luc "这太伤人了。你怎么能如此轻易就忘了你的导师？在我为你付出这么多之后？"
    translate None lucius_part1_0257:
        luc "哎呀我的天，我想我可能要哭出来。"
    translate None lucius_part1_0258:
        show caspian n sur with dis
        ca "....!"
    translate None lucius_part1_0259:
        show ds n ang with dis
        ae "..我的老师早已去世。你假装成他对你毫无益处。"
    translate None lucius_part1_0260:
        show luc n dim neu cloak with dis
        luc "嗯…"
    translate None lucius_part1_0261:
        show luc n dim smi cloak with dis
        luc "这位是谁来着？雷恩，对吧？新上任的年轻言者大人…哦等等，只是个孤儿，没错吧？"
    translate None lucius_part1_0262:
        luc "我确实在你身上看到了艾米尔。如此明亮的眼睛，如此容易被控制。我想我们会相处得非常融洽。"
    translate None lucius_part1_0263:
        show caspian n ang with hpunch
        cas "你—！"
    translate None lucius_part1_0264:
        hide caspian with dissolve
        show luc at slightright
        show ds at slightleft
        with move
        "他向侧面一闪，卡斯皮安便滑倒在地。黑发男子耸肩大笑。"


    if cyne_route:
        translate None lucius_part1_0265:
            c c wang "……您不就是里隆家族的瓦伦特大人吗？国王陛下的御前顾问？"
        translate None lucius_part1_0266:
            luc "嗯？也许我以前是，但现在不是了。谁知道呢？"
        translate None lucius_part1_0267:
            "他俯视着赛恩，仿佛他什么都不是。赛恩立即绷紧身体，移动着站到我前面来。"


    if fawn_route:
        translate None lucius_part1_0268:
            f c wbla "雷恩…退后…"
        translate None lucius_part1_0269:
            luc "没人在问你，老兄。"
        translate None lucius_part1_0270:
            "福恩因他的话畏缩了一下，但没有退让。"


    if leos_route:
        translate None lucius_part1_0271:
            l c wpis "..我们要离开这里。"
        translate None lucius_part1_0272:
            rs c wsur "等等，发生了什么？"
        translate None lucius_part1_0273:
            l "是你主动接近我的，不是吗？"
        translate None lucius_part1_0274:
            luc "啊，莱奥斯！我差点没注意到你在那儿。"
        translate None lucius_part1_0275:
            l "你怎么知道我的名字？"
        translate None lucius_part1_0276:
            show luc n dim sur with dis
            luc "真冷漠啊！我可是看着你长大的，就得到这种待遇？"
        translate None lucius_part1_0277:
            "莱奥斯在我面前绷紧了身子，一刻不停地攥紧我的手。"



    translate None lucius_part1_0278:
        cas wang "你这是在开什么愚蠢的玩笑？别费心思糊弄我们了。你绝不可能是他！"
    translate None lucius_part1_0279:
        rs c wsur "伙计们，没必要这么激动。发生什么事了—"
    translate None lucius_part1_0280:
        show luc n dim smir cloak with dis
        luc "真的吗？好吧，看来我得跟自己好好谈谈了。到底是什么样的记忆在折磨着我？"
    translate None lucius_part1_0281:
        luc "我对此看得一清二楚…我们年轻的言者大人，尾随在小王子身后，永远活在他的影子里。"
    translate None lucius_part1_0282:
        luc "他们俩偷偷溜进了森林，然后…这是什么情况？他们回来时却面临一片混乱？面对死亡与毁灭？"
    translate None lucius_part1_0283:
        luc "告诉我，如果我不能当你的导师，那我是谁？"
    translate None lucius_part1_0284:
        luc "哦，初出茅庐的王子，我得谢谢你。至少你带回来的那个女人并非一无是处。她的刀法堪称奇观，我几乎当场毙命！"
    translate None lucius_part1_0285:
        show ds n sur with dis
        ae "….你…你不可能是…怎么会？"
    translate None lucius_part1_0286:
        cas wang "你这个狗娘养的…第一次来的时候造的孽还不够，现在又来找死了？！"


    if cyne_route:
        translate None lucius_part1_0287:
            c "不，我确定。我不止一次见过你—到底怎么回事？"


    translate None lucius_part1_0288:
        luc "哎呀，你可真能絮叨啊？有人慷慨赠予我这具躯体，而我从不会拒绝善意馈赠。"


    if cyne_route:
        translate None lucius_part1_0289:
            c "........"


    translate None lucius_part1_0290:
        show ds n sad with dis
        ae "求求你…求求你了，我恳求你告诉我这不是真的…你没那么做，对不对？"
    translate None lucius_part1_0291:
        show luc n dim sur cloak with dis
        luc "它？什么，帮助皇室走向覆灭？我当然做了。"
    translate None lucius_part1_0292:
        luc "你竟然会有别的想法，真是个白痴。"
    translate None lucius_part1_0293:
        show ds with hpunch
        ae "不…!"
    translate None lucius_part1_0294:
        ae "我信任过你！我做的一切…发生的一切…都是因为你！"
    translate None lucius_part1_0295:
        ae "若不是因为你…若不是因为你，他和我…我们永远都不会…"
    translate None lucius_part1_0296:
        show luc n dim smir cloak with dis
        luc "从此过上幸福生活？哼，别笑掉大牙了。你本来就是迟早会出事的货色。我只不过轻轻推了你一把，让你往该去的方向前进罢了。"
    translate None lucius_part1_0297:
        luc "你容易上当可不是我的错。说实话，我以为你和那个雏鸟王子的关系会更亲密些，看来是我想错了。你们俩这么容易就被拆散了。"
    translate None lucius_part1_0298:
        luc "好吧，世事本就如此。君王与言者向来格格不入。"
    translate None lucius_part1_0299:
        cas wsca "……你究竟是什么东西？"
    translate None lucius_part1_0300:
        "他笑了起来，无视了卡斯皮安的问题。"
    translate None lucius_part1_0301:
        luc "艾米留斯，这些年跟在你身边真是乐趣无穷。看你受苦的样子—实在可口。"
    translate None lucius_part1_0302:
        luc "真可惜你一直这么令人失望…我命令你杀了雷恩时为什么不执行？只要你一句话，他几分钟内就能上绞架。"
    translate None lucius_part1_0303:
        ae "…原来是你。那个盖过其他人声音的洪亮嗓音，在奥雷利亚卡维拉城外一直跟着我的声音。"
    translate None lucius_part1_0304:
        luc "或许是，或许不是。"
    translate None lucius_part1_0305:
        rs c wang "你为什么在这里？！你想要什么？"
    translate None lucius_part1_0306:
        "他点了点头，两个人影从阴影中走出。"


    if fawn_route:
        translate None lucius_part1_0307:
            "一人金发，另一人红发…"
        translate None lucius_part1_0308:
            rs "赛恩！莱奥斯！你们对他们做了什么？！"


    if cyne_route:
        translate None lucius_part1_0309:
            "一人蓝发，另一人红发…"
        translate None lucius_part1_0310:
            rs "福恩！莱奥斯！你们对他们做了什么？！"


    if leos_route:
        translate None lucius_part1_0311:
            "一人蓝发，另一人金发…"
        translate None lucius_part1_0312:
            l c wpis "福恩！赛恩！"
        translate None lucius_part1_0313:
            rs c wang "你对他们做了什么？！"



    translate None lucius_part1_0314:
        show luc n dim sur cloak with dis
        luc "嘘—他们在睡觉呢。你不会想吵醒他们的，对吧？"


    if cyne_route:
        translate None lucius_part1_0315:
            c "……让他们走，就现在。"
        translate None lucius_part1_0316:
            luc "这种权威的口吻，来自一个失败的继承人。"
        translate None lucius_part1_0317:
            c "…..你一点都不了解我。"
        translate None lucius_part1_0318:
            luc "噢，我对你了解可不少呢，西纳库洛斯少爷。一位神童。上天几乎赐予了你所有才能。"
        translate None lucius_part1_0319:
            luc "但是，哎呀，你最终却如此令人失望。如今人人都在低声议论着你的名字，却并非出于什么好理由。"
        translate None lucius_part1_0320:
            c c wsad "不…那不是真的…"
        translate None lucius_part1_0321:
            show luc n dim smir cloak with dis
            luc "总是差一步就要被家族除名，嗯？"
        translate None lucius_part1_0322:
            "赛恩的脸抽搐了一下，好像不确定是该反击还是转身逃跑。我伸手握住他的手轻轻捏了捏，随后重新看向另外两人。"
        translate None lucius_part1_0323:
            "无论我怎么呼唤他们，他们都没有反应。他们的表情一片空白，双眼蒙上了阴影。"


    if fawn_route:
        translate None lucius_part1_0324:
            f "放了他们！"
        translate None lucius_part1_0325:
            luc "我在跟你说话吗，恶魔之子？"
        translate None lucius_part1_0326:
            f c wsad "...!"
        translate None lucius_part1_0327:
            "无论我怎么呼唤他们，他们都没有反应。他们的表情一片空白，双眼蒙上了阴影。"



    if leos_route:
        translate None lucius_part1_0328:
            l "如果你珍惜自己的性命，现在就放了他们。"
        translate None lucius_part1_0329:
            show luc n dim smir cloak with dis
            luc "老实说，我不能说我珍惜呢。"
        translate None lucius_part1_0330:
            "莱奥斯松开了我，不到一秒钟就站到了卢修斯面前。他抬起手—手里已然握着一把在午后阳光下闪闪发光的匕首—向那人挥去，而对方轻松抓住了他的手腕。"
        translate None lucius_part1_0331:
            "他对莱奥斯笑了笑。那种不安的笑容让我感到恶心。"
        translate None lucius_part1_0332:
            rs "放开他！"
        translate None lucius_part1_0333:
            l "你这混蛋…你在玩什么把戏？"
        translate None lucius_part1_0334:
            show luc n dim sur with dis
            luc "这可不像对上级说话的态度。"
        translate None lucius_part1_0335:
            l "你对我来说什么都不是。"
        translate None lucius_part1_0336:
            luc "在我为你做了这么多之后？"
        translate None lucius_part1_0337:
            l "我不认识你！"
        translate None lucius_part1_0338:
            show luc n dim smir cloak with dis
            luc "你的审判？我的作品。你的成长？只需给你父母一个简单的命令，他们就完全按照我的要求做了。"
        translate None lucius_part1_0339:
            luc "我创造了终极杀人机器。一个没有感情的机器，会永远效忠于我。"
        translate None lucius_part1_0340:
            luc "嗯…这本该如此，但我死了而你…哼，你终究成了个失败品，不是吗？"
        translate None lucius_part1_0341:
            "就这样，他的手腕被松开，踉跄着退向我。我迅速扶住他的后背稳住他，用杀人的目光瞪着那个男人。"
        translate None lucius_part1_0342:
            rs "他不是失败品。你根本不了解他。"
        translate None lucius_part1_0343:
            luc "随你怎么说。莱奥斯—我身边有个空位，如果你愿意来坐的话。"
        translate None lucius_part1_0344:
            l c whur "仿佛我真会这样做似的。"
        translate None lucius_part1_0345:
            luc "不再畏惧自己的宿命了吗？"
        translate None lucius_part1_0346:
            l "....."
        translate None lucius_part1_0347:
            luc "内心深处，你和我一样的冷酷无情。这些人对你来说无关紧要。"
        translate None lucius_part1_0348:
            rs "你错了！"
        translate None lucius_part1_0349:
            "我站到莱奥斯面前，他的背影在我眼前似乎已经开始萎缩。他突然显得那么瘦小、脆弱，仿佛这个男人说出的每一句尖锐话语都正中要害。"
        translate None lucius_part1_0350:
            luc "你真该信任一个手上沾满鲜血的人吗？"
        translate None lucius_part1_0351:
            rs "我愿以性命信任他。"
        translate None lucius_part1_0352:
            show luc n dim neu with dis
            luc "你不该。他对你有所隐瞒。正如你对他也有所隐瞒。"
        translate None lucius_part1_0353:
            rs "别对我说谎！"
        translate None lucius_part1_0354:
            "男人耸了耸肩，似乎毫不在意我要说的话。"
        translate None lucius_part1_0355:
            luc "给。"
        translate None lucius_part1_0356:
            "一个金属制品缓缓旋转着朝我们飞来，莱奥斯轻而易举地从空中接住了它。一把漆黑如夜的匕首。沿着刀刃刻着一个图案和几个字符。"
        translate None lucius_part1_0357:
            l c wsur "…我家的家徽。怎么会？"
        translate None lucius_part1_0358:
            show luc n dim smir cloak with dis
            luc "谁知道呢。就当这是我对你了解程度的证明吧。"
        translate None lucius_part1_0359:
            "我回头看向福恩和赛恩。两人脸上都毫无表情。我朝他们挥手，但谁都没反应。"




    translate None lucius_part1_0360:
        luc "我想这两样东西以后会派上用场，但现在…"
    translate None lucius_part1_0361:
        luc "真的很抱歉，但你们三个妨碍了我的计划。真的，我为此道歉，但我不能让你们活着。懂吗？"
    translate None lucius_part1_0362:
        rs "好吧？！不，这一点都不好！"
    translate None lucius_part1_0363:
        luc "抱歉，我不是在征求你的许可。"
    translate None lucius_part1_0364:
        "他一步步向我逼近。不像维拉斯。甚至也不像诺克斯。不，他比他们强大得多。周围的空气因他而活跃，噼啪作响。"

    hide luc
    hide ds
    with dissolve

    if cyne_route:
        translate None lucius_part1_0365:
            "赛恩把手从我的手中抽出，可还没等我感到灰心，他就跪倒在地，捧起一堆积雪，使出全力砸向那个神秘男人的脸庞。"
        translate None lucius_part1_0366:
            scene bg sc grey with hpunch
            "啪！他停下脚步，踉跄着后退。"
        translate None lucius_part1_0367:
            "赛恩再次将他的手环绕着我的，拉着我跑了起来。"
        translate None lucius_part1_0368:
            c c wsur "快！"
        translate None lucius_part1_0369:
            "艾米尔和卡斯皮安也照做，跟在我们身后跑向—好吧，只要离开这儿去哪儿都行。"
        translate None lucius_part1_0370:
            "那位神秘的黑发主角嘟哝着，怒色已然笼罩了他的面庞。我恰好回头望向他时，瞥见一道黑影从我身边掠过。"


    if leos_route:
        translate None lucius_part1_0371:
            "我再次握住莱奥斯的手，拼命四下张望，寻找我们能藏身的任何地方，寻找我能做的任何事。"
        translate None lucius_part1_0372:
            "..我只擅长一件事。"
        translate None lucius_part1_0373:
            rs c wsad "跑！"
        translate None lucius_part1_0374:
            "拉着莱奥斯的手，我们转身狂奔起来。我能看见艾米尔和卡斯皮安在我们身后同样跑了起来，我们迅速拐进一条阴暗的小巷以摆脱那个黑发男子。"
        translate None lucius_part1_0375:
            luc c neu "我不这么认为-"


    if leos_route or cyne_route:
        translate None lucius_part1_0376:
            v fro "找个安全的地方！"


    if fawn_route:
        translate None lucius_part1_0377:
            v fro "所有人，退后！"


    if leos_route or cyne_route:
        translate None lucius_part1_0378:
            rs c wsur "维拉斯？！"


    translate None lucius_part1_0379:
        "在一片粉绿交织的漩涡中，有两个人站在我们与黑发男子之间。"
    translate None lucius_part1_0380:
        rs "伊尔兰，维拉斯！"
    translate None lucius_part1_0381:
        i neu "这都快成习惯了，不是吗？总是在最后一刻赶来救你。"


    if cyne_route:
        translate None lucius_part1_0382:
            "我猛地止步，同时拽住了赛恩。"


    if leos_route:
        translate None lucius_part1_0383:
            "我猛地止步，同时拽住了莱奥斯。"
        translate None lucius_part1_0384:
            l c wneu "这可是头一回我见到你感到高兴。"
        translate None lucius_part1_0385:
            i fli "哦，让我跳动的心平静下来吧。"


    translate None lucius_part1_0386:
        rs "感谢诸神！是…你们怎么会在这里？！"
    translate None lucius_part1_0387:
        v sad "我们发现情况不对就来寻找你们—抱歉花了这么久。"
    translate None lucius_part1_0388:
        i con "但现在没时间交谈。你们先跑，我们随后跟上。"


    if cyne_route:
        translate None lucius_part1_0389:
            rs "好。赛恩，我们走！你们两个也是！"


    if fawn_route:
        translate None lucius_part1_0390:
            rs "好。福恩，我们走！你们两个也跟上！"


    if leos_route:
        translate None lucius_part1_0391:
            rs "好的—小心点！"



    translate None lucius_part1_0392:
        luc smir "我不认为—"
    translate None lucius_part1_0393:
        v fro "又没人问你。"
    translate None lucius_part1_0394:
        "我们全都转身逃跑—虽然不确定该往哪儿逃，但哪里都比这里安全。"


    if cyne_route:
        translate None lucius_part1_0395:
            "穿过一条又一条街。四下无人，我们找不到地方藏身喘口气。"
        translate None lucius_part1_0396:
            a sur "哇啊！"
        translate None lucius_part1_0397:
            rs c wsur "阿什！"
        translate None lucius_part1_0398:
            "他看着我们所有人拼命喘气的样子。"
        translate None lucius_part1_0399:
            a "赛恩，雷恩？"
        translate None lucius_part1_0400:
            a ann "…快跟我来。"

        jump veraslucius

    if fawn_route:
        translate None lucius_part1_0401:
            "穿过一条又一条街。四下无人，我们找不到地方藏身喘口气。"
        translate None lucius_part1_0402:
            tit sur "哇啊！"
        translate None lucius_part1_0403:
            rs "提图斯！"
        translate None lucius_part1_0404:
            "他看着我们所有人拼命喘气的样子。"
        translate None lucius_part1_0405:
            tit "福恩？雷恩？你们怎么在这儿？"
        translate None lucius_part1_0406:
            rs "现在没时间解释—能让我们躲躲吗？"
        translate None lucius_part1_0407:
            tit "....."
        translate None lucius_part1_0408:
            tit "跟我来。"

        jump veraslucius

    if leos_route:
        translate None lucius_part1_0409:
            "我们冲出了巷子，回到明亮开阔的街道上，在那里迎面撞见了一个我始料未及会遇到的人。"
        translate None lucius_part1_0410:
            rs c wsur "扎林！"
        translate None lucius_part1_0411:
            z sur "你们看起来都急急忙忙的…出了什么事吗？"
        translate None lucius_part1_0412:
            "他在我们几个人的面孔间来回扫视。从莱奥斯那张已经拧成深深皱纹的脸，再到艾米尔和卡斯皮安的面容—他们看起来就像是整个世界在他们周围轰然崩塌。"
        translate None lucius_part1_0413:
            z ang "…确实似乎出了什么问题。快点，我们回实验室吧。"
        translate None lucius_part1_0414:
            rs "谢谢你…！"

        jump veraslucius


label veraslucius:
    stop music fadeout 2.0
    scene bg sc grey with Fade(1.0, 1.0, 1.0):
        xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.46
        linear 25.0 xpos 0.5 ypos 1.46 xanchor 0.5 yanchor 1.0 zoom 1.46
    play music "sounds/bgm/forgotten.ogg"
    translate None lucius_part1_0415:
        "当他看着站在面前的两个人时，那令人不安的狞笑瞬间从他脸上消失了，他们破坏了他的乐趣。"
    translate None lucius_part1_0416:
        luc neu "……你想干什么？你挡着我的路了。"
    translate None lucius_part1_0417:
        v fro "你是谁？你对那两个人做了什么？"
    translate None lucius_part1_0418:
        luc "...."
    translate None lucius_part1_0419:
        luc "……你们这种微不足道的家伙，凭什么觉得自己有资格站在我面前？"
    translate None lucius_part1_0420:
        luc ang "一个过气无用的神，还有条夹着尾巴的驯养狐狸，安安静静地跟在后面。"
    translate None lucius_part1_0421:
        i ang "有人向你提出了一个问题。你是谁，你从何处而来？"
    translate None lucius_part1_0422:
        luc neu "要求真多……我就暂时陪你们玩玩吧。如果非要选个名字……就用我以前那个好了。卢修斯。"
    translate None lucius_part1_0423:
        v "卢修斯……没听说过这号人物。"
    translate None lucius_part1_0424:
        luc "我想你没有见过，因为我是在众神被关进奥雷利亚卡维拉之后才登上神位的。"
    translate None lucius_part1_0425:
        v "….你是哪方面的神？具体掌管什么？"
    translate None lucius_part1_0426:
        luc neu "这不是明摆着吗？"
    translate None lucius_part1_0427:
        luc "万神之神。终将鞭挞这个世界，使其成为值得统治之地。"
    translate None lucius_part1_0428:
        i "…当言者还不够过瘾是吗？"
    translate None lucius_part1_0429:
        luc "我的志向远不止于此。"
    translate None lucius_part1_0430:
        vmn "他…没说谎。我从没见过有人拥有如此强大的气场。"
    translate None lucius_part1_0431:
        luc "我会杀掉所有反对我的人，包括剩下的两位言者。可不能让他们坏了我的兴致，对吧？"
    translate None lucius_part1_0432:
        v "…那被困在奥雷利亚卡维拉的众神呢？"
    translate None lucius_part1_0433:
        luc "哦,他们啊？让他们烂掉吧。我本来就不太喜欢他们,动不动就因为一点折磨就大喊大叫的。"
    translate None lucius_part1_0434:
        luc "我会建造一个不需要他们的新世界。新神将取代他们的位置，与我共同统治。"
    translate None lucius_part1_0435:
        i "什么，那些愿意臣服于你的神？"
    translate None lucius_part1_0436:
        luc "如果你想这么理解的话。"
    translate None lucius_part1_0437:
        "伊尔兰的声音中充满了难以抑制的愤怒。"
    translate None lucius_part1_0438:
        v "…抱歉，我不能让你这样做。"
    translate None lucius_part1_0439:
        luc smir "哦？那么无用的神明要对此做什么？"
    translate None lucius_part1_0440:
        v "…我不想争斗，但若迫不得已，我也会挺身而战。"


    play sound "sounds/sfx/Bassy Swoosh.ogg" fadeout 1.0

    show bg sc grey
    show bloody
    with hpunch
    pause 0.5
    hide bloody with dis3
    stop music fadeout 1.0
    translate None lucius_part1_0441:
        i sca "..........."
    translate None lucius_part1_0442:
        v ouc "伊尔兰！"
    translate None lucius_part1_0443:
        luc "好吧，太容易了。"
    translate None lucius_part1_0444:
        "这一切发生在维拉斯还没来得及行动之前。一道光芒向他袭来，但没有命中目标。"
    translate None lucius_part1_0445:
        "光芒击中了伊尔兰，他几乎瞬间作出反应，跳到了那位桃红色头发神明的前面。"
    translate None lucius_part1_0446:
        v "伊尔兰.. 伊尔兰，你在干什么？！"
    translate None lucius_part1_0447:
        i "我……我没事……"
    translate None lucius_part1_0448:
        "在他面前，维拉斯正经历着他最恐惧的事，却无力阻止"
    translate None lucius_part1_0449:
        v "....!"

    play music "sounds/bgm/forgotten off.ogg" fadein 4.0
    translate None lucius_part1_0450:
        "他冲向前抓住伊尔兰的手，将他从卢修斯身边拉开，朝着雷恩逃跑的方向拖去。"
    translate None lucius_part1_0451:
        luc "尽管逃吧。你们无处可藏。"

    play sound "sounds/sfx/runningnormal.ogg" fadeout 1.0

    scene bg sc grey with swipe
    translate None lucius_part1_0452:
        v ouc "你…你…你这个白痴！你到底在想什么？！"
    translate None lucius_part1_0453:
        i con "哈哈…我欠你一次，你在奥克斯哈伯替我挡了那一下。"
    translate None lucius_part1_0454:
        i "别告诉我这就是让你最终丢掉冷静的原因？其实没那么糟，伤口很快会愈合的。"
    translate None lucius_part1_0455:
        v "要是没成功呢？！你太鲁莽了！"
    translate None lucius_part1_0456:
        i neu "…你也一样。如果换做是你，你也会这么做。"
    translate None lucius_part1_0457:
        v "我比你康复得快，伊尔兰……保护人类……是我的职责……不是反过来……"
    translate None lucius_part1_0458:
        i con "唉，我尽量不为细节烦恼。"
    translate None lucius_part1_0459:
        v lon "伊尔兰，我……我承受不起。求你了……要是你因我而出事……"
    translate None lucius_part1_0460:
        i neu "有什么区别？我终有一死，宁可为你而死，也不想无聊地老死。"
    translate None lucius_part1_0461:
        "维拉斯的手指紧扣住伊尔兰的，他将对方的手指举到自己唇边，吻了上去。"
    translate None lucius_part1_0462:
        v "求你，伊尔兰。我很少求你什么，但是……求你别死。"
    translate None lucius_part1_0463:
        i sad "......"
    translate None lucius_part1_0464:
        i "嗯…从长远来看我可能阻止不了它的发生，但…至少这一次我会竭尽全力活下去。"
    translate None lucius_part1_0465:
        "对维拉斯来说，这简直是他最可怕的噩梦。那个对他意义最重大的人，那个改变了他一生的人…正因为他的缘故，正在承受痛苦。"
    translate None lucius_part1_0466:
        "他的生命如此短暂，如此脆弱。对一个活了数千年的神明来说，那原本就只是转瞬即逝的存在。想到它还要被更早地终结…"
    translate None lucius_part1_0467:
        "泪水无声地从他脸上滚落，但他仍拖着伊尔兰继续奔跑，绝望地寻找着雷恩。"

    stop music fadeout 2.0
    window hide dissolve

    if cyne_route:
        scene bg primrose
        show cyne nw sad at slightleft
        show raen nw sad at slightright
        with Fade(1.0, 1.0, 1.0)
        window show dissolve
        translate None lucius_part1_0468:
            a sur "赛恩，你没事吧？为什么这么匆忙？"
        translate None lucius_part1_0469:
            c "…..我很好。我更担心的是…"
        translate None lucius_part1_0470:
            play music "sounds/bgm/creepy.ogg" fadein 3.0
            "赛恩眉头紧锁，陷入深思。我也有着同样的感受，为伊尔兰和维拉斯感到担忧。"
        translate None lucius_part1_0471:
            rs "所以，谁能跟我解释下刚才到底发生了什么？那个…不是你们说已经死了的说书人吗？怎么回事？"

    if fawn_route:
        scene bg zarryn
        show fawn nw sad at slightleft
        show raen nw sad at slightright
        with Fade(1.0, 1.0, 1.0)
        window show dissolve
        translate None lucius_part1_0472:
            "扎林的书房和我记忆中相差无几—温暖又宜人，和我对实验室的想象截然不同。"
        translate None lucius_part1_0473:
            "他迅速在我们身后关上门并点燃炉火，而卡斯皮安和艾米尔瘫倒在沙发上。"
        translate None lucius_part1_0474:
            play music "sounds/bgm/creepy.ogg" fadein 3.0
            rs "所以，谁能跟我解释下刚才到底发生了什么？那个…不是你们说已经死了的说书人吗？怎么回事？"
        translate None lucius_part1_0475:
            f "死人不会就这样凭空重现…除非…"



    if leos_route:
        scene bg zarryn
        show leos nw pis at slightleft
        show raen nw sad at slightright
        with Fade(1.0, 1.0, 1.0)
        window show dissolve
        translate None lucius_part1_0476:
            "扎林的书房和我记忆中的相差无几—温暖怡人，完全不像我想象中实验室的模样。"
        translate None lucius_part1_0477:
            "他迅速在我们身后关上门并点燃炉火，而卡斯皮安和艾米尔瘫倒在沙发上。"
        translate None lucius_part1_0478:
            play music "sounds/bgm/creepy.ogg" fadein 3.0
            z ang "究竟发生了什么？"
        translate None lucius_part1_0479:
            rs "..我…我不知道从何说起…"
        translate None lucius_part1_0480:
            "我皱起眉头，心中为伊尔兰和维拉斯深深担忧。"
        translate None lucius_part1_0481:
            rs "我想…他就是那个说书人吧？就是死去的…卢修斯？"
        translate None lucius_part1_0482:
            "卡斯皮安和艾米尔听到他的名字时都僵住了。"


    translate None lucius_part1_0483:
        cas wsad "….不可能是他，对吧？"
    translate None lucius_part1_0484:
        ae sad "然而他知道得太多… 说话的方式也和他如出一辙.."
    translate None lucius_part1_0485:
        rs "他怎么可能还活着？"
    translate None lucius_part1_0486:
        cas "他绝对不可能还活着！我亲眼看着他死的。"



    if leos_route:
        translate None lucius_part1_0487:
            l "…绝对是他没错。声音也许变了，但那声冷笑没变…"
        translate None lucius_part1_0488:
            rs "你真认识他？"
        translate None lucius_part1_0489:
            l "….我曾隔着门听见他的声音，在和我的父母交谈…"


    translate None lucius_part1_0490:
        play sound "sounds/sfx/slam.ogg" fadein 1.0
        "门被砰地撞开，维拉斯踉跄跌入，几乎撑不起伊尔兰的身子。血从他肩头滴落，脸上满是痛苦神色。"
    translate None lucius_part1_0491:
        show raen nw sur with dis
        v lon "拜托，我需要绷带！"


    if fawn_route:
        translate None lucius_part1_0492:
            tit sur "维拉斯？他怎么了？！"
        translate None lucius_part1_0493:
            v "求你了，他伤得很重。"
        translate None lucius_part1_0494:
            tit sur "稍等，我正好有能用上的东西！"
        translate None lucius_part1_0495:
            show fawn nw sur with dis
            f "他出什么事了？"


    if cyne_route:
        translate None lucius_part1_0496:
            a sur "伊尔兰，维拉斯…？"
        translate None lucius_part1_0497:
            a "等一下，我楼上有备用的。"
        translate None lucius_part1_0498:
            show cyne nw sur with dis
            c "究竟怎么回事？！是他把你伤成这样的？"


    if leos_route:
        translate None lucius_part1_0499:
            z sur "…伊尔兰，维拉斯？让我叫上提图斯—"
        translate None lucius_part1_0500:
            v "别！这事不能牵扯他进来，太危险了。"
        translate None lucius_part1_0501:
            z neu "…那就交给我。虽然生疏了，但我好歹还是个治疗师。"
        translate None lucius_part1_0502:
            "他冲向建筑深处的房间，留我们几人呆立原地。维拉斯小心翼翼地将伊尔兰安放在面朝炉火的扶手椅上，脸上满是惊惶。"
        translate None lucius_part1_0503:
            l "他出什么事了？"
        translate None lucius_part1_0504:
            i sad "…..只是轻伤。"


    translate None lucius_part1_0505:
        v "他袭击了我们。我…我反应不够快…"
    translate None lucius_part1_0506:
        v "天啊…妈的，伊尔兰，求你别有事…！"
    translate None lucius_part1_0507:
        "维拉斯罕见地失了态，他咒骂着，眼角泛起泪光。"
    translate None lucius_part1_0508:
        i sca "我可以…回答你的问题…"
    translate None lucius_part1_0509:
        v "在我给你包扎的时候…求你保持安静…"
    translate None lucius_part1_0510:
        $ about_Lucius.locked = False
        i "…他是个神明。要么强行占据了那具躯体，要么有人{a=set_entry:enc_people->about_Lucius}{color=#DA70D6}主动献祭{/color}{/a}给了他。"


    if cyne_route:
        show cyne nw sur

    if leos_route:
        show leos nw sur

    if fawn_route:
        show fawn nw sad

    show raen nw sur
    with dis

    translate None lucius_part1_0511:
        rs "神明…？但怎么会，他不是人类吗？"


    if cyne_route:
        translate None lucius_part1_0512:
            "阿什急忙冲下楼梯，带来了一盒医疗用品。维拉斯立刻开始进行止血处理。"


    if leos_route:
        translate None lucius_part1_0513:
            "扎林抱着一堆药剂、绷带和其他治疗用品急匆匆地冲回房间。"
        translate None lucius_part1_0514:
            "我一直认为他太过冷静，太过镇定自若而不会匆忙行事，结果证明我错了。"
        translate None lucius_part1_0515:
            z ang "伊尔兰，你最好快点解释清楚。"
        translate None lucius_part1_0516:
            "维拉斯取来一些医疗用品，两人开始为伊尔兰包扎。他的衬衣已然变成深红，当他们检查伤口时，我不得不移开视线。"
        translate None lucius_part1_0517:
            i sad "..."


    if fawn_route:
        translate None lucius_part1_0518:
            "提图斯跌跌撞撞地抱着一个大木箱回到房间。里面装着医师所需的一切—绷带药膏，药剂药品。"
        translate None lucius_part1_0519:
            "他在维拉斯身旁坐下，两人联手止血。他们配合得天衣无缝—确实都是出色的医者。"


    translate None lucius_part1_0520:
        "艾米尔和卡斯皮安面面相觑，不知道这些新来者是谁。我迅速简短地解释了一切。他们是谁、是什么身份，他们之前如何帮助过我们，甚至谈到神明与恶魔这些事。"


    if leos_route:
        translate None lucius_part1_0521:
            "伊尔兰加入对话，终于向扎林说出了真相。"

    translate None lucius_part1_0522:
        "他们全程震惊得说不出话。当然艾米尔早就知道神明的存在—他经常与神明对话，但他对奥雷利亚战争、神明陨落附身凡人之事一无所知。"


    if cyne_route:
        translate None lucius_part1_0523:
            "整个过程中，阿什都站在远离人群的地方，看起来既惊愕又恐惧。"


    if fawn_route:
        translate None lucius_part1_0524:
            "当提及维拉斯的真实身份时，提图斯突然沉默不语。"


    if leos_route:
        translate None lucius_part1_0525:
            z sur "..这么长时间以来，我所寻找的一切其实近在眼前。一位行走在我们中间的神明。"
        translate None lucius_part1_0526:
            v sad "…我为此保密向你道歉，扎林。我并非有意欺瞒你。"
        translate None lucius_part1_0527:
            z neu "你只是在守护自己的生活方式。换作是我也会这样做。"
        translate None lucius_part1_0528:
            v "我猜提图斯一定会对我很失望。"
        translate None lucius_part1_0529:
            z "胡说。你知道他一直把你当偶像崇拜。"
        translate None lucius_part1_0530:
            z "…以后也会如此。我半个字都不会告诉他。"
        translate None lucius_part1_0531:
            v "谢谢你，扎林。"
        translate None lucius_part1_0532:
            "他深深皱起眉头，似乎有什么心事困扰着他。"
        translate None lucius_part1_0533:
            v "如果…如果我没能回来，答应我…告诉他我以他为荣。"
        translate None lucius_part1_0534:
            z "…我觉得你最好还是活着回来，但这个忙我可以帮。"
        translate None lucius_part1_0535:
            z ang "现在，告诉我那个卢修斯的事。他长什么模样？"
        translate None lucius_part1_0536:
            rs "高个子，黑发，红眼睛…"
        translate None lucius_part1_0537:
            z "国王本人的顾问，至少是他身体的一部分。他一向是那种权欲熏心的人，若是将身体献给恶魔，我丝毫不会感到惊讶。"
        translate None lucius_part1_0538:
            z "凭着他的地位带来的权力，他轻易就能将整座城市玩弄于股掌之间。"
        translate None lucius_part1_0539:
            rs "不…"
        translate None lucius_part1_0540:
            z "…但我不会放任不管。我会禀报国王，设法牵制住他，至少等到你们想出对策。"
        translate None lucius_part1_0541:
            show raen nw sur with dis
            rs "扎林… 谢谢你！"
        translate None lucius_part1_0542:
            v sad "现在…言归正传。"


    translate None lucius_part1_0543:
        v sad "…..是时候告诉你们真相了。我们并非生而为神。都是在死后由凡人之躯升格而来的。"


    if cyne_route:
        translate None lucius_part1_0544:
            c "这怎么可能？你们都曾是…普通人？谁都能做到？"


    if fawn_route:
        translate None lucius_part1_0545:
            show fawn nw sad with dis
            f "我不明白…真的任何人都可以？"



    if leos_route:
        translate None lucius_part1_0546:
            show leos nw pis with dis
            l "那么，是什么阻止一个人成为神呢？任何人都能做到吗？"



    translate None lucius_part1_0547:
        v "不。是那些具有广泛影响力的存在。当然，也可能是出于好的原因。一个被世人热爱并且被热烈铭记的人可能会升格成为神明，但是…"
    translate None lucius_part1_0548:
        v "反之亦然。足够的恐惧与仇恨也能产生同样的效果。"
    translate None lucius_part1_0549:
        cas wang "恐惧与仇恨？这就是他的全部。"
    translate None lucius_part1_0550:
        v "他…他无比强大。比我见过的任何神或恶魔都要强大。诺克斯在他面前显得微不足道。"
    translate None lucius_part1_0551:
        "他将某种药用植物按进伊尔兰的伤口，伊尔兰痛得倒吸一口气。"
    translate None lucius_part1_0552:
        v "我没有能力反对他。在锡德卡汉没人有这个能力。"
    translate None lucius_part1_0553:
        ae sad "…..我曾比信任任何人都更信任他。我以为…我以为…"
    translate None lucius_part1_0554:
        ae "但…就是他。那个驱散了我脑海中始终盘桓不去的众多声音的人。那个跟随我离开奥雷利亚卡维拉的人…"
    translate None lucius_part1_0555:
        ae "要是…要是我能控制自己的能力，那么…"
    translate None lucius_part1_0556:
        v "神明有时可以将灵魂附着于人类而不占据其身体。这…并不稳定，会使他们失去力量，但确实可行。这是他们既不需要躯体也不会死亡就能生存的方式。"
    translate None lucius_part1_0557:
        rs "......"
    translate None lucius_part1_0558:
        rs "没错！"


    if fawn_route:
        translate None lucius_part1_0559:
            show fawn nw sur with dis
            f "那是什么？"


    if cyne_route:
        translate None lucius_part1_0560:
            show cyne nw sad with dis
            c "….你一直听到的那个声音，是不是很相似？"


    if leos_route:
        translate None lucius_part1_0561:
            show leos nw neu with dis
            l "⋯这和你一直听到的声音是一样的，不是吗？"


    if leos_route or cyne_route:
        translate None lucius_part1_0562:
            rs "没错！自从我离开奥雷利亚卡维拉后，那个在梦中一直呼唤我的女声…她一定就是同一个人…！"


    if fawn_route:
        translate None lucius_part1_0563: # VOICE MAP - TRIM
            rs "自从我离开奥雷利亚卡维拉后，那个在梦中一直呼唤我的女声…她一定是同一个人…！"


    translate None lucius_part1_0564:
        rs "她警告我说有人在跟踪我。我…当我看到言者时，我以为可能是他，但…这和卢修斯有关，我确信！"
    translate None lucius_part1_0565:
        show raen nw sad with dis
        rs "那么…她也是奥蕾莉亚神…"
    translate None lucius_part1_0566:
        v neu "…我想你可能是对的。她试图帮助你，保护你。"
    translate None lucius_part1_0567:
        rs "…不过她现在已经离开了.."
    translate None lucius_part1_0568:
        v sad "如果她继续留在你身边，可能会把卢修斯引向你，但…"
    translate None lucius_part1_0569:
        rs "但是什么？"
    translate None lucius_part1_0570:
        v "如果她与你没有联系，那么…"
    translate None lucius_part1_0571:
        rs "啊…"


    if fawn_route:
        translate None lucius_part1_0572:
            show fawn nw sad with dis
            f "对不起，雷恩.."


    if cyne_route:
        translate None lucius_part1_0573:
            c "对不起，雷恩。"


    if leos_route:
        translate None lucius_part1_0574:
            l "…在我们了解全部事实之前，不要妄下结论。"
        translate None lucius_part1_0575:
            rs "…你说得对。我需要好好想想这件事。"


    translate None lucius_part1_0576:
        i ang "呸…他自以为是众神中的至神。如果不加以遏制，不等我们反应过来他就能把整个锡德卡汉握于掌心。"
    translate None lucius_part1_0577:
        i "…如果以此推断，他会除掉所有不同意的人—特别是房间里的两位言者。"
    translate None lucius_part1_0578:
        show raen nw sur with dis
        rs "你们早就知道了？！"
    translate None lucius_part1_0579:
        v neu "我们有所察觉，但直到卢修斯确认才确定。"


    if leos_route or cyne_route:
        translate None lucius_part1_0580:
            "当绷带缠绕在伊尔兰的手臂和胸口后，维拉斯终于放开了他。"


    if fawn_route:
        translate None lucius_part1_0581:
            "提图斯用绷带包扎好伊尔兰的手臂和胸口，维拉斯最终发出一声悲伤的叹息。"



    translate None lucius_part1_0582:
        i "呃…"


    if fawn_route:
        translate None lucius_part1_0583:
            "提图斯紧紧盯着伊尔兰的脸，眉头深锁。他突然扯下面具—露出真容—对着伊尔兰厉声呵斥。"
        translate None lucius_part1_0584:
            tit nann"我敢说无论发生了什么都是你自找的，不是吗？你当初那样对待我师傅，活该落得如此下场。"
        translate None lucius_part1_0585:
            i ang "你这小混蛋—"
        translate None lucius_part1_0586:
            tit nsad "但是…我也确信你做了正确的事。即使我不喜欢你，这一点我还是明白的。"
        translate None lucius_part1_0587:
            i neu "....."
        translate None lucius_part1_0588:
            v sad"提图斯…"
        translate None lucius_part1_0589:
            tit nhap "我也绝不能让你失望，维拉斯！看看我进步有多大。"
        translate None lucius_part1_0590:
            "维拉斯带着温和的笑容，伸手揉了揉提图斯的头发。提图斯像个受到表扬而开心的孩子般回以微笑。"
        translate None lucius_part1_0591:
            v smi "你做得很好，提图斯。"
        translate None lucius_part1_0592:
            tit nsur "…你真的是神吗？"
        translate None lucius_part1_0593:
            v sad "很抱歉没有告诉你。"
        translate None lucius_part1_0594:
            tit nhap "……别担心，我会保密的。就算是主人也不会说。等你准备好了再告诉他吧。"
        translate None lucius_part1_0595:
            v smi "你成长得这么好。我为你感到骄傲。"
        translate None lucius_part1_0596:
            "维拉斯转向艾米尔时，脸上的笑容消失了。"


    if cyne_route:
        translate None lucius_part1_0597:
            "阿什走过来跪在他身旁，担心地看着他。"
        translate None lucius_part1_0598:
            a sad "伊尔兰…你总是太急躁了。你应该更加小心些。"
        translate None lucius_part1_0599:
            i ang "从我眼前消失，老东西。"
        translate None lucius_part1_0600:
            "他不耐烦地拍开阿什的手。这有点不符合他的性格。"
        translate None lucius_part1_0601:
            rs "...?"
        translate None lucius_part1_0602:
            rs "你们俩认识？"
        translate None lucius_part1_0603:
            i "....."
        translate None lucius_part1_0604:
            a neu "……伊尔兰在我的孤儿院住过几年。"
        translate None lucius_part1_0605:
            rs "真的吗？"
        translate None lucius_part1_0606:
            a "唔…在他没逃跑的时候。其实他十几岁时也就是每隔几个月来住一次。"
        translate None lucius_part1_0607:
            i "好了好了，我想他们明白了。"


    if leos_route:
        translate None lucius_part1_0608:
            z neu "伊尔兰…你是个不折不扣的麻烦精，不过偶尔还派得上用场。你不会就这么轻易死掉的。"
        translate None lucius_part1_0609:
            i fli "当然不会，你以为我是谁？"
        translate None lucius_part1_0610:
            "他勉强挤出笑容，但谁都看得出他疼得要命。"


    if leos_route or cyne_route:
        translate None lucius_part1_0611:
            "维拉斯变得沉默，脸上浮现严肃的神情。寂静持续蔓延，直到他终于转向艾米尔。"


    translate None lucius_part1_0612:
        v fro "……你是艾米尔，那个说书人，对吧？"
    translate None lucius_part1_0613:
        ae sur "我…我吗？是的，我是…"
    translate None lucius_part1_0614:
        v "....."
    translate None lucius_part1_0615:
        v "你知道诸神都被困在奥雷利亚卡维拉了，对吧？"
    translate None lucius_part1_0616:
        ae sad "不，我…"
    translate None lucius_part1_0617:
        ae "……请给我解释的机会。从卢修斯那里接手后，一切都得靠我自己摸索—按说他会把所有的知识和秘密都传授给我，但是.."
    translate None lucius_part1_0618:
        ae "..考虑到他的死亡来得…相当突然，他没有机会。"
    translate None lucius_part1_0619:
        ae "是的，我知道他们很生气…相信我，我听到了，但我不知道为什么…我不知道该如何解决。"
    translate None lucius_part1_0620:
        ae "声音太多就变成了一片毫无意义的噪音之海。"
    translate None lucius_part1_0621:
        v sad "明白了…"
    translate None lucius_part1_0622:
        i "如果让那个混蛋活着，他们就永远被困在那里。"
    translate None lucius_part1_0623:
        show raen nw sad with dis
        rs "但是…我们又能做什么呢？连维拉斯都阻止不了他，我们其他人还有什么机会？"


    if fawn_route:
        translate None lucius_part1_0624:
            show fawn nw neu with dis
            f "....."
        translate None lucius_part1_0625:
            f "我们也绝不能丢下赛恩和莱奥斯不管。"



    if cyne_route:
        translate None lucius_part1_0626:
            show cyne nw ang with dis
            c "我们也绝不能让他们得到福恩或莱奥斯。我不会让他得逞。"


    if leos_route:
        translate None lucius_part1_0627:
            show leos nw pis with dis
            l "就算只身一人，我也要去救福恩和赛恩。"
        translate None lucius_part1_0628:
            i fli "我还以为你不在乎他们呢。"
        translate None lucius_part1_0629:
            l "...."
        translate None lucius_part1_0630:
            l "我在乎他们的程度远超我的言语表达，但如果你想活着离开，最好忘掉我刚说的话。"
        translate None lucius_part1_0631:
            rs "我不会让你独自前往。"



    translate None lucius_part1_0632:
        "伊尔兰和维拉斯停顿了片刻，各自思索着。仿佛他们无需言语就能彼此交流。"
    translate None lucius_part1_0633:
        v fro "我们会帮忙—但有个条件。"
    translate None lucius_part1_0634:
        "两人都将注意力转向艾米尔。"
    translate None lucius_part1_0635:
        v "如果我们帮忙，你就得放了被困的神明，还得保证永远不会再强迫他们留在那儿。"
    translate None lucius_part1_0636:
        "艾米尔低头看向地面。自从卢修斯现身以来，他看起来…失魂落魄。"
    translate None lucius_part1_0637:
        ae sad "…我当然同意。"
    translate None lucius_part1_0638:
        show raen nw neu with dis
        rs "那我们该怎么办？"
    translate None lucius_part1_0639:
        v neu "如果要打倒他，我们需要更多人手。更多的神，更多的恶魔，任何愿意帮忙的人。"
    translate None lucius_part1_0640:
        show raen nw sur with dis
        rs "可你说过锡德卡汉没有足够强大的人。"
    translate None lucius_part1_0641:
        v sad "…不，没有。"
    translate None lucius_part1_0642:
        v neu "我唯一能凭借的只有传闻。我听说山中有座隐世村庄，那是众神的庇护所。虽不知真假，但这是我们最大的希望了。"


    if fawn_route:
        translate None lucius_part1_0643:
            tit nsur "…著名制图师西尔维尔发现的隐秘村庄？"
        translate None lucius_part1_0644:
            v sur "你知道这件事？"
        translate None lucius_part1_0645:
            tit "这个故事是我最喜欢的之一！"
        translate None lucius_part1_0646:
            tit "雷恩、福恩—求你们了，如果你们去了那里还能活着回来，一定要把一切都告诉我！每一个细节都不能漏！"
        translate None lucius_part1_0647:
            show fawn nw sur with dis
            f "呃…"
        translate None lucius_part1_0648:
            tit "我会把它写进正在为你创作的传记里，雷恩！这必将成为传世佳话！"
        translate None lucius_part1_0649:
            rs "…好吧，好吧。我保证会把一切都告诉你。"


    if leos_route or cyne_route:
        translate None lucius_part1_0650:
            "关于扎林和他发现的那本日记的记忆涌上心头。一个隐秘的村庄…"


    translate None lucius_part1_0651:
        rs "…那我们还等什么？"
    translate None lucius_part1_0652:
        v sad "只是…有个小问题。我还听说他们不关心人类的纷争。即使我们请求帮助，也可能被拒绝。"
    translate None lucius_part1_0653:
        v "他们独居是有原因的。对我们任何人都没有忠诚可言。"


    if fawn_route:
        translate None lucius_part1_0654:
            show fawn nw sad with dis
            f "如果他们费了这么大劲就是想自己待着，那要说服他们可能很难…"


    if cyne_route:
        translate None lucius_part1_0655:
            show cyne nw sad with dis
            c "如果他们真的住在离锡德卡汉那么近的地方，却能隐藏得这么好。我们能说服他们吗？"


    if leos_route:
        translate None lucius_part1_0656:
            show leos nw neu with dis
            l "如果他们说不怎么办？我们要怎么弥补那些旅行时间？"


    translate None lucius_part1_0657:
        show raen nw neu with dis
        rs "…我相信我们能行。"


    if cyne_route:
        translate None lucius_part1_0658:
            v sad "…阿什，我要把伊尔兰托付给你。"


    if fawn_route:
        translate None lucius_part1_0659:
            v sad "…提图斯，我要把伊尔兰托付给你。"


    if leos_route:
        translate None lucius_part1_0660:
            v sad "…扎林，我要把伊尔兰托付给你。"
        translate None lucius_part1_0661:
            v "我知道他挺麻烦的 但你可以把他交给提图斯。"


    translate None lucius_part1_0662:
        i sca "什么？！"
    translate None lucius_part1_0663:
        v fro "你现在的状态根本不适合爬山。"
    translate None lucius_part1_0664:
        i ang "我不管，我无论如何都要去。"
    translate None lucius_part1_0665:
        v sad "我们刚刚谈过这件事…"
    translate None lucius_part1_0666:
        i "我不会让你一个人走。"
    translate None lucius_part1_0667:
        v "....."

    window hide

    menu:
        "同意维拉斯的意见":
            window show dissolve
            translate None lucius_part1_0668:
                rs "…在这里等着，我们之后会回来找你。"
            translate None lucius_part1_0669:
                i ang "我刚才是在跟你说话吗？"


        "同意伊尔兰":
            window show dissolve
            translate None lucius_part1_0670:
                rs "…他受伤了，但他太过珍贵不能抛下，不是吗？"
            translate None lucius_part1_0671:
                v sad "我知道…真的知道，但是—"


    translate None lucius_part1_0672:
        i ang "维拉斯，我不会留在这里。不能在这关键时刻留下。"
    translate None lucius_part1_0673:
        "维拉斯石雕般的表情柔和下来，伸手轻抚伊尔兰的脸庞。"
    translate None lucius_part1_0674:
        v smi "⋯⋯你实在是太冒失了，但我知道一旦你下定决心的事情，没人能拦得住。好吧，你可以一起去，但如果情况变得太危险，你必须立刻回到这里来。"
    translate None lucius_part1_0675:
        i "我可不敢保证。"
    translate None lucius_part1_0676:
        v sad "唉⋯⋯我知道。"


    if fawn_route:
        translate None lucius_part1_0677:
            tit nneu "这些药膏你也带着。还有这些，以防感染。哦，再多带些绷带.."
        translate None lucius_part1_0678:
            "提图斯将无数小瓶罐塞进维拉斯怀里。他谦卑地接受，悉数收好以备后用。"
        translate None lucius_part1_0679:
            v sad "仔细听我说，提图斯。把我们带到这里来会让你身处险境。我必须向你坦白这一点。"
        translate None lucius_part1_0680:
            v "对任何人都不要提起我们—暂时连扎林也不行。若有陌生者接近，就佯装不知尽快脱身。明白吗？"
        translate None lucius_part1_0681:
            tit nhap "你可以指望我。"


    if cyne_route:
        translate None lucius_part1_0682:
            a sur "所以…你是告诉我一个神圣演说者变成了神，现在要接管这座城市，每个人都处于危险中？"
        translate None lucius_part1_0683:
            a "维拉斯，你是神吗？"
        translate None lucius_part1_0684:
            a sad "这个世界到底要变成什么样子…"
        translate None lucius_part1_0685:
            "他踉跄着后退，一屁股坐在椅子上。这一切实在令人难以消化。"
        translate None lucius_part1_0686:
            i neu "对你和你女儿来说，最好忘了这一切，就当从没见过我们，这样更安全。"
        translate None lucius_part1_0687:
            "他庄重地点了点头。"


    if leos_route:
        translate None lucius_part1_0688:
            z neu "我会把你来访的事保密。"
        translate None lucius_part1_0689:
            v sad "让你身陷如此险境，我万死难辞其咎。"
        translate None lucius_part1_0690:
            z "胡说。这恰恰是我专长的领域。不过，既然我已知道真相，我希望你回来让自己成为我研究的一部分。"
        translate None lucius_part1_0691:
            "我以为我看见了维拉斯畏缩了一下，但伊尔兰迅速伸出手，轻轻地握了握他的手。"
        translate None lucius_part1_0692:
            v sad "我…"
        translate None lucius_part1_0693:
            i ang "哪种研究？"
        translate None lucius_part1_0694:
            z "只管说出来。你的经验或许能救索伦和诺克斯。"
        translate None lucius_part1_0695:
            "维拉斯立刻放松下来，脸上浮现出温和的微笑。"
        translate None lucius_part1_0696:
            v smi "那我当然会同意。"
        translate None lucius_part1_0697:
            z smi "很好。既然你要踏上旅程，这些额外医疗物资就带上吧。"


    translate None lucius_part1_0698:
        cas wsur "这…固然极好，但我已没立场插手。此事确实与我无关，所以—"
    translate None lucius_part1_0699:
        show raen nw fro with dis
        rs "别这么窝囊废！"
    translate None lucius_part1_0700:
        rs "一直以来，我都在听闻关于魅力非凡的卡斯皮安王子的传闻。人们说他多么强大，所有人都多么敬仰他。"
    translate None lucius_part1_0701:
        rs "那他妈的到底跑去哪了？"
    translate None lucius_part1_0702:
        cas wsad "...."
    translate None lucius_part1_0703:
        rs "这…这事关所有人！锡德卡汉的每个居民，奥雷利亚卡维拉的百姓。斯塔格威奇与奥克斯哈伯的民众。所有人！"
    translate None lucius_part1_0704:
        rs "你真的连一丝一毫都不再关心你的人民了吗？你就这样放弃了吗？"
    translate None lucius_part1_0705:
        cas "不！我当然很关心他们，但是—"
    translate None lucius_part1_0706:
        show raen nw neu with dis
        rs "你不需要说完那句话。就在那里结束也很合适。"
    translate None lucius_part1_0707:
        rs "如果你还在乎，就一起来帮我们解决这事。"
    translate None lucius_part1_0708:
        cas "…..我根本没得选，对吧？"
    translate None lucius_part1_0709:
        ae sad "..."


    if fawn_route:
        translate None lucius_part1_0710:
            tit nneu "…..祝你们好运。你们最好都给我活着回来，明白吗？"


    if cyne_route:
        translate None lucius_part1_0711:
            a "既然你们又要踏上旅程，至少让我多给你们备些药。"
        translate None lucius_part1_0712:
            v smi "谢谢，阿什。啊，代我们向普莉姆问好。"
        translate None lucius_part1_0713:
            a neu "她很想念你们俩。"
        translate None lucius_part1_0714:
            v "我们也非常想念她。"


    if leos_route:
        translate None lucius_part1_0715:
            "维拉斯收好医疗用品，扶伊尔兰起身。他踉跄了一下，但很快又站稳了。"
        translate None lucius_part1_0716:
            rs "我们不在的时候，你自己多保重，好吗？"
        translate None lucius_part1_0717:
            z neu "我一直都是。"
        translate None lucius_part1_0718:
            "扎林返回了其中一个后间，而其他人迅速离开了，留下我独自和莱奥斯在一起。"
        translate None lucius_part1_0719:
            rs "结果看来还是你最在理，是吧？"
        translate None lucius_part1_0720:
            show leos nw smu with dis
            l "我倒往往如此。"
        translate None lucius_part1_0721:
            rs "我知道。"
        translate None lucius_part1_0722:
            "在内心深处，尽管一切变得糟糕透顶，我却感到了一丝解脱。"
        translate None lucius_part1_0723:
            "我想知道为什么？"
        translate None lucius_part1_0724:
            "啊…"
        translate None lucius_part1_0725:
            show raen nw smi blush with dis
            rs "…我很高兴我还不用回家。"
        translate None lucius_part1_0726:
            l "…是啊，我也这么觉得。不过你总是给自己惹麻烦，不是吗？"
        translate None lucius_part1_0727:
            rs "所以才有你在啊。帮我解决这些麻烦。"
        translate None lucius_part1_0728:
            show leos nw sur with dis
            stop music fadeout 3.0
            l "雷恩，我…还有别的事想晚点和你谈，好吗？"
        translate None lucius_part1_0729:
            show raen nw sur -blush with dis
            rs "…？当然，你可以告诉我任何事。"
        translate None lucius_part1_0730:
            "我的思绪又回到了卢修斯说过的话。说我们还在互相隐瞒着秘密。"
        translate None lucius_part1_0731:
            "…我相信他。"
        translate None lucius_part1_0732:
            l "很好。我们不该让其他人久等。"
        translate None lucius_part1_0733:
            "我们迅速离开了书房，和外面的其他人重新汇合。"






    if fawn_route:
        translate None lucius_part1_0734:
            "带着我们所有的行装准备就绪，我们迅速整理着准备出发。伊尔兰挺直了身子站起来，但谁都能看出他仍旧承受着巨大的痛苦。"
        translate None lucius_part1_0735:
            rs "我们不在的时候要小心。"
        translate None lucius_part1_0736:
            "众人开始离开，拖着脚步走出门外，最后只剩下福恩和我。提图斯给了我们独处的时刻，自己返身去查看诺克斯的情况。"
        translate None lucius_part1_0737:
            "我把他的手握在掌心轻轻捏了捏，有他在身边让我感到安慰。"
        translate None lucius_part1_0738:
            rs "我本可像维拉斯对伊尔兰说的那样劝你等待，但我知道你不会。"
        translate None lucius_part1_0739:
            show raen nw smi with dis
            rs "所以，取而代之的是…我希望你能留在我身边陪我度过这一切。"
        translate None lucius_part1_0740:
            show fawn nw smi with dis
            f "至死不渝。"
        translate None lucius_part1_0741:
            show raen nw neu with dis
            rs "我本以为我的冒险就要结束了。"
        translate None lucius_part1_0742:
            show fawn nw neu with dis
            f "你走到哪儿就把麻烦带到哪儿，对吧？"
        translate None lucius_part1_0743:
            "带着微笑，我们离开了扎林的实验室，跟随其他人而去。"




    if cyne_route:
        translate None lucius_part1_0744:
            "带着我们所有的行装准备就绪，我们迅速整理着准备出发。伊尔兰挺直了身子站起来，但谁都能看出他仍旧承受着巨大的痛苦。" # might be in Fawn route too
        show cyne nw sad with dis
        translate None lucius_part1_0745:
            c "阿什…谢谢你…"
        translate None lucius_part1_0746:
            a smi "..不必客气。你知道我一直都在照看你。"
        translate None lucius_part1_0747:
            a "…祝你们所有人好运。"
        translate None lucius_part1_0748:
            rs "我们不在的时候要小心。"
        translate None lucius_part1_0749:
            stop music fadeout 3.0
            "大家开始离开，最后只剩赛恩和我。"
        translate None lucius_part1_0750:
            show raen nw sad with dis
            rs "……你不必来的，你知道。我没法强迫你。"
        translate None lucius_part1_0751:
            c "..别傻了。我已经陪你走过了全部路程，不是吗？现在为什么要例外？"
        translate None lucius_part1_0752:
            "因为你说过不想和我有太多瓜葛。当我告诉你我喜欢你时，你逃走了。"
        translate None lucius_part1_0753:
            rs "...."
        translate None lucius_part1_0754:
            show cyne nw ang with dis
            c "…这次我不会逃开。"
        translate None lucius_part1_0755:
            "我仔细注视着他—看他专心致志说话时紧皱眉头的样子，看他双臂交叉抱在胸前仿佛要保护自己的模样。"
        translate None lucius_part1_0756:
            "…强迫他谈论这件事毫无意义。如果他愿意跟我来…那我就很开心了。"
        translate None lucius_part1_0757:
            show raen nw smi with dis
            rs "…谢谢你，赛恩。没有你我根本做不到。"
        translate None lucius_part1_0758:
            "我温柔地朝他微微一笑，我们把樱草花留在身后，跟随其他人向前走去。"



    window hide dissolve

    scene bg sc grey with dissolve:
        xpos 0.76 ypos 1.48 xanchor 0.5 yanchor 1.0 zoom 1.53
        linear 30.0 xpos 0.25 ypos 1.48 xanchor 0.5 yanchor 1.0 zoom 1.53
    window show dissolve
    translate None lucius_part1_0759:
        play music "sounds/bgm/forgotten off.ogg" fadein 3.0
        "在前往锡德卡汉城门的路上，我们穿行在小巷和岔道间。不过这很可能多此一举，因为街道上空无一人。"


    if cyne_route:
        translate None lucius_part1_0760:
            c c wsad "我不明白…大家都去哪了？"


    if fawn_route:
        translate None lucius_part1_0761:
            f c wsad "这里空荡荡的.."


    if leos_route:
        translate None lucius_part1_0762:
            l c wneu "他对每个人都做了什么？"


    translate None lucius_part1_0763:
        rs c wsad "他不可能把所有人都…他们是在躲藏吗？"
    translate None lucius_part1_0764:
        v sad "我不知道.."
    translate None lucius_part1_0765:
        "我们穿过正门，但这次没有守卫站岗。"

    window hide dissolve

    scene bg sc mountains with dissolve
    window show dissolve
    translate None lucius_part1_0766:
        "外面的太阳已经开始西沉，一种深沉刺骨的寒意正笼罩着大地。我们都把衣服紧紧裹在身上。"
    translate None lucius_part1_0767:
        i neu "你知道…这是我第一次听说这个秘密村。"
    translate None lucius_part1_0768:
        v sad "我不想在不确定的情况下谈论这件事，但我还没有机会去深入了解。"
    translate None lucius_part1_0769:
        rs c wsur "你没去找它是有原因的吗？你就不能待在那儿吗？"
    translate None lucius_part1_0770:
        v neu "嗯…"
    translate None lucius_part1_0771:
        v "嗯，我想我本可以那么做，但对我来说…那从来就不是个选择。他们也许决定从人性中抽离，但我不想放弃。"
    translate None lucius_part1_0772:
        "对话逐渐止息，我们只是跟着维拉斯在渐深的夜色中前行。当离开小路进入荒野时，积雪深厚而寒冷。"
    translate None lucius_part1_0773:
        i ang "呃…"
    translate None lucius_part1_0774:
        v ouc "你没事吧？需要我背你吗？"
    translate None lucius_part1_0775:
        i "…不，不，我没事。"
    translate None lucius_part1_0776:
        i "但我不能就这样一直装作若无其事。嘿，你。"
    translate None lucius_part1_0777:
        ae sur "我？"
    translate None lucius_part1_0778:
        i "我像是在和别人说话吗？我清楚你的底细，知道你纵容的勾当。若不停止阿祖罗斯的阴谋，你休想轻松脱身。"
    translate None lucius_part1_0779:
        ae sur "....."
    translate None lucius_part1_0780:
        rs c wsur "等等，你说什么？你怎会知道阿祖罗斯？"
    translate None lucius_part1_0781:
        i "啊…操。"
    translate None lucius_part1_0782:
        v "没有继续保密的必要了，伊尔兰。"
    translate None lucius_part1_0783:
        i neu "…我来自奥雷利亚卡维拉。算是原籍吧。"


    if leos_route:
        translate None lucius_part1_0784:
            l c whur "什么？！那么你—"


    translate None lucius_part1_0785:
        rs "我…还以为你是锡德卡汉人？"
    translate None lucius_part1_0786:
        i sad "母亲带着年幼的我逃离了那里。"
    translate None lucius_part1_0787:
        rs "为什么？"
    translate None lucius_part1_0788:
        "他用锐利的目光直视艾米尔。"
    translate None lucius_part1_0789:
        i ang "还能为什么？怕说书人降罪呗。"
    translate None lucius_part1_0790:
        ae "什么…？为什么？"
    translate None lucius_part1_0791:
        i "我偷偷溜进了阿祖罗斯。我想去看望祖父母，但父亲说不准我去。我很好奇，心想就看一眼应该没关系。我就进去打个招呼，马上出来。"
    translate None lucius_part1_0792:
        i "果然，出门时被父亲逮个正着，他拽着我在街上走，要把我押来你这儿报告。"
    translate None lucius_part1_0793:
        i "所以我妈妈赶紧拉住我就跑。"


    if leos_route:
        translate None lucius_part1_0794:
            i sad "……我欠一位非常重要的朋友一个道歉，我就这样丢下他离开，原以为再也见不到了。"
        translate None lucius_part1_0795:
            l c whur "....."
        translate None lucius_part1_0796:
            i "唉，现在只能希望他能接受我的道歉了。"


    if leos_route or cyne_route:
        translate None lucius_part1_0797:
            ae sad "我…我从来没有…"


    if fawn_route:
        translate None lucius_part1_0798:
            ae sad "我…我从来没有…" #I wouldn’t have...

    translate None lucius_part1_0799:
        "他皱起眉头，意识到是的—他本来可能会对此采取些行动的。"
    translate None lucius_part1_0800:
        ae "…我很抱歉。"
    translate None lucius_part1_0801:
        i "别白费口舌了。你真正该抱歉的是里面正在发生的事。"
    translate None lucius_part1_0802:
        rs "…你什么意思？不就是…他们获得回报的地方…吗？"
    translate None lucius_part1_0803:
        i "那是个工厂。他们都是被困神明的食物。"


    if cyne_route:
        translate None lucius_part1_0804:
            c c wsur "什么？你们把人留在那里被…吃掉？"


    if fawn_route:
        translate None lucius_part1_0805:
            f c wsur "什么？！"


    if leos_route:
        translate None lucius_part1_0806:
            rs c wsur "莱奥斯…你知道这事吗？"
        translate None lucius_part1_0807:
            l "…..我知道尸体需要被移走，但从不知道竟是这样的景象。"

    translate None lucius_part1_0808:
        cas sad "那是…真的吗？"
    translate None lucius_part1_0809:
        ae "…..是真的。这是卢修斯生前最后推行的制度。我记得他曾告诉我，是国王让他负责此事的。"
    translate None lucius_part1_0810:
        ae "他死后…那个声音告诉我继续带长老们去那里。根据这些新线索，我能猜到是谁在指使我这么做。"
    translate None lucius_part1_0811:
        v fro "…..或许他对未来的发展有所洞察，将此事布置为一种手段，使得自己在死后还能变得更加强大。如果是这样……难怪他会如此强大。"
    translate None lucius_part1_0812:
        cas ang "我早知道那个阴森邪恶的杂种本性。在他变成杀人犯前就警告过—当初听我的就好了—"
    translate None lucius_part1_0813:
        ae "……我从未想过他是这样的人…我怎么会知道？！他一直对我那么温柔。我只是…觉得他只是有点被误解了！"
    translate None lucius_part1_0814:
        cas "你本应信任我，就像我曾信任你一样。"
    translate None lucius_part1_0815:
        ae ang "你？我为什么要相信一个会如此轻易抛弃我的人？"
    translate None lucius_part1_0816:
        cas "我们非得把同样的话说上多少遍…你知道的，我没有抛弃你。"
    translate None lucius_part1_0817:
        "艾米尔的面容再度冷若冰霜，他向卡斯皮安投去刀锋般的目光。两人你来我往地争吵起来，完全忘记了旁人存在。"


    if cyne_route:
        translate None lucius_part1_0818:
            c c wneu "汪…这可真是情人间的拌嘴啊…"
        translate None lucius_part1_0819:
            rs c wsur "情人拌嘴？"
        translate None lucius_part1_0820:
            c "看看他俩，敢说你没怀疑他们至少睡过一次？"


    if fawn_route:
        translate None lucius_part1_0821:
            #i "Just ignore their little lovers' spat. It’ll sort itself out."
            i sad "你们干脆去开房算了。没人想听你们情人间的争吵。"
        translate None lucius_part1_0822:
            rs c wsur "情人拌嘴？"
        translate None lucius_part1_0823:
            f "他们看起来确实非常…亲密。你觉得会不会…？"


    if leos_route:
        translate None lucius_part1_0824:
            i sad "你们干脆去开房算了。没人想听你们情人间的争吵。"
        translate None lucius_part1_0825:
            rs c wsur "情人拌嘴？"
        translate None lucius_part1_0826:
            i "只有上过一两次床后，你们才会像那样争吵。"


    translate None lucius_part1_0827:
        "两人瞬间闭嘴。卡斯皮安绷着脸继续前行，艾米尔的脸却越来越红。"
    translate None lucius_part1_0828:
        "哦…原来是这么回事…"
    translate None lucius_part1_0829:
        "什么？！等等，真的假的？！他们有过一腿？"
    translate None lucius_part1_0830:
        rs c wemb "你们两个…真的…做了…？"
    translate None lucius_part1_0831:
        cas emb "现…现在不是说这种话的时候！"
    translate None lucius_part1_0832:
        ae emb2 "我无可奉告。"
    translate None lucius_part1_0833:
        rs "呃…"
    translate None lucius_part1_0834:
        "卡斯皮安、我父亲…还有说书人？这有什么难以想象的？"
    translate None lucius_part1_0835:
        i con "这难道不是很温馨吗。就像一个小小的家庭聚会！卷心菜田的孩子和他两位父亲！我—"
    translate None lucius_part1_0836:
        "他讽刺的话语被一阵嘶哑的、剧烈的咳嗽打断。维拉斯用手臂环住伊尔兰，稳住他的身体。"
    translate None lucius_part1_0837:
        v sad "别紧张。"
    translate None lucius_part1_0838:
        i sad "…..我没事。不用担心我。"
    translate None lucius_part1_0839:
        "维拉斯轻轻抚过伊尔兰凌乱的头发，然后松开了手。他没有走远，像往常一样留在绿发男子身边。"


    if fawn_route:
        translate None lucius_part1_0840:
            "当卡斯皮安和艾米尔在一边争论时，伊尔兰和维拉斯在另一边低声交谈，我终于有机会单独和福恩说话。"
        translate None lucius_part1_0841:
            show raen mw dark neu cloak at mright
            show fawn mw dark neu cloak at mleft
            with dissolve
            rs "你还好吗？"
        translate None lucius_part1_0842:
            show fawn mw smi with dis
            "他勉强对我笑了笑，但只维持了一瞬间。"
        translate None lucius_part1_0843:
            show fawn mw dark sad with dis
            f "我很担心安妮。"
        translate None lucius_part1_0844:
            show raen mw dark sad with dis
            rs "…她毕竟还是你妹妹。希望她只是回家了。"
        translate None lucius_part1_0845:
            f "我不会…我不能责怪她的所作所为。我是…我是个…"
        translate None lucius_part1_0846:
            show raen mw dark neu with dis
            rs "你不是。我了解你，你并不这样。"
        translate None lucius_part1_0847:
            "我伸手将他耳际散落的发丝拨到耳后，福恩的脸上重新浮现出微笑。他握住我的手，将我的掌心贴在他脸颊上，轻轻依偎着。"
        translate None lucius_part1_0848:
            show fawn mw dark smi with dis
            f "谢谢。真的。"
        translate None lucius_part1_0849:
            show fawn mw sad with dis
            f "⋯⋯但尽管如此，还是很难对她生气。从她的角度来看⋯⋯"
        translate None lucius_part1_0850:
            f "一直以来我与她最为亲近。我想这就是为何如此痛心—知道她看向我时，眼里只有愤怒…"
        translate None lucius_part1_0851:
            rs "…要知道我无法原谅她那样对你 但我会尽我所能提供帮助。如果你想和她和好…要知道我会一直站在你身边 好吗？"


    if cyne_route:
        translate None lucius_part1_0852:
            "卡斯皮安和艾米尔在一边争执，伊尔兰和维拉斯在另一边低语，终于只剩我和赛恩独处交谈。"
        translate None lucius_part1_0853:
            show raen mw dark sur cloak at mright
            show cyne mw dark neu cloak at mleft
            with dissolve
        #    play music "sounds/bgm/night.ogg" fadein 3.0
            rs "这太疯狂了，不是吗？"
        translate None lucius_part1_0854:
            show cyne mw dark smi with dis
            c "比你平时自找的那些麻烦还疯狂吗？倒也不是。"
        translate None lucius_part1_0855:
            show raen mw dark sad with dis
            rs "无法反驳的感觉如此痛苦…"
        translate None lucius_part1_0856:
            show cyne mw dark neu with dis
            c "..."
        translate None lucius_part1_0857:
            show cyne mw dark sad with dis
            stop music fadeout 2.0
            c "母亲与我断绝了关系。"
        translate None lucius_part1_0858:
            show raen mw dark sur with hpunch
            rs "什么？！"
        translate None lucius_part1_0859:
            play music "sounds/bgm/sad.ogg" fadein 3.0
            c "我只是个…毫无用处的废物，不是吗？不是个好儿子，更是个糟糕的情人…"
        translate None lucius_part1_0860:
            show raen mw dark sad with dis
            rs "你明知那不是真的…"
        translate None lucius_part1_0861:
            c "当这辈子所有人都这样告诉我时，我怎么可能会有其他想法？"
        translate None lucius_part1_0862:
            rs "...."
        translate None lucius_part1_0863:
            c "而这下我又搞砸了我们的关系。我本只想让你看到我快乐的一面。我以为…只要多说些笑话，多逗趣些，这次就不会把事情搞砸。"
        translate None lucius_part1_0864:
            c "但为时已晚。我其实没那么有趣，是吧？"
        translate None lucius_part1_0865:
            show raen mw dark neu with dis
            rs "…赛恩，知道我对你的看法吗？"
        translate None lucius_part1_0866:
            show cyne mw dark sur with dis
            c "…什么？"
        translate None lucius_part1_0867:
            show raen mw dark neu blush with dis
            rs "我觉得你是最棒的—"


    if leos_route:
        translate None lucius_part1_0868:
            "卡斯皮安和艾米尔在一边争执，伊尔兰和维拉斯在另一边低语，终于只剩我和莱奥斯独处交谈。"
        translate None lucius_part1_0869:
            show raen mw dark sur cloak at mright
            show leos mw dark neu cloak at mleft
            with dissolve
            rs "…莱奥斯，他该不会…？"
        translate None lucius_part1_0870:
            show leos mw dark sur with dis
            l "我想是的。这些年我真以为他已经死了…"
        translate None lucius_part1_0871:
            rs "你应该跟他谈谈。"
        translate None lucius_part1_0872:
            l "…我会的，等我能单独见到他的时候。"
        translate None lucius_part1_0873:
            rs "还有件事想问…卢修斯靠近时，你说听出了他的声音…？"
        translate None lucius_part1_0874:
            l "......"
        translate None lucius_part1_0875:
            "他压低声音近乎耳语，确保只有我能听见。"
        translate None lucius_part1_0876:
            l "那天我们遇见卡斯皮安后我独自离开，有个人靠近我说他能…能改变我的命运，如果我杀死说书人。"
        translate None lucius_part1_0877:
            show bg sc mountains with hpunch
            rs "杀了他？！"
        translate None lucius_part1_0878:
            show leos mw dark pis with dis
            l "嘘，小声点儿。"
        translate None lucius_part1_0879:
            l "显然不是我干的。那家伙可疑得要命，但…我不能说我没动过念头。"
        translate None lucius_part1_0880:
            show raen mw dark sad with dis
            rs "莱奥斯…"
        translate None lucius_part1_0881:
            rs "天上某个家伙对你人生的安排根本不重要。"
        translate None lucius_part1_0882:
            show leos mw dark sur with dis
            l "同样的道理也适用于你，你应该明白。"
        translate None lucius_part1_0883:
            rs "...."
        translate None lucius_part1_0884:
            rs "我该学会践行自己的建议，对吧？"



    translate None lucius_part1_0885:
        i sca "哇啊！"
    translate None lucius_part1_0886:
        v ouc "伊尔兰！"


    stop music
    play sound "sounds/sfx/fallonground3.ogg" fadein 1.0
    hide raen
    hide cyne
    hide leos
    hide fawn
    show bg mountains
    with hpunch
    translate None lucius_part1_0887:
        "一个重物击中我的后背，我砰地一声倒在地上。"
    translate None lucius_part1_0888:
        rs c wsur "啊！"
    translate None lucius_part1_0889:
        i "呃…抱歉，小家伙。"
    translate None lucius_part1_0890:
        v "伊尔兰…这不像你。你必须回去。"
    translate None lucius_part1_0891:
        i sad "不！不，我没事。太黑了，我被绊倒了。这是个意外。"


    if cyne_route:
        translate None lucius_part1_0892:
            "正当我与赛恩交谈时被打断，还被按倒在地，我试图扶起伊尔兰，同时继续与赛恩说话。"
        translate None lucius_part1_0893:
            "他终于肯听我的了。我不能浪费这个机会。"


    if leos_route:
        translate None lucius_part1_0894:
            "从与莱奥斯的讨论中被中断，我试图扶伊尔兰站起来。"


    translate None lucius_part1_0895:
        rs c wsad "我认为—"
    play music "sounds/bgm/forgotten off.ogg" fadein 3.0

    show black with flash
    translate None lucius_part1_0896:
        "一道刺眼的光芒占据了我的视线，我突然感到头晕恶心。幸好当时我躺在地上，否则肯定会摔个头破血流。"
    translate None lucius_part1_0897:
        show white with dis3
        "没有声音响起。那光芒在我脑海中扩散至每个角落，而后消逝于虚无之中。"
    translate None lucius_part1_0898:
        "取而代之的是胸中燃烧般的剧痛，让我无法呼吸。"


    hide white
    hide black
    with dissolve
    translate None lucius_part1_0899:
        i sad "......"
    translate None lucius_part1_0900:
        rs c whur "啊…呃…"
    translate None lucius_part1_0901:
        v sur "…伊尔兰？雷恩？"


    if fawn_route:
        translate None lucius_part1_0902:
            "伊尔兰迅速从我身上跳开，在我坐起时紧张地注视着我。福恩跑到我身边，看着鲜血浸透我的衣裳，覆盖肩膀和胸膛，他的表情担忧又了然。"


    if leos_route:
        translate None lucius_part1_0904:
            l c whur "雷恩！"
        translate None lucius_part1_0905:
            "莱奥斯猛冲过来，把伊尔兰从我身上掀开，然后扶我坐起来。他看着我衬衫渐渐被暗红色液体浸透。"
        translate None lucius_part1_0906:
            l "你对他做了什么？！"
        translate None lucius_part1_0907:
            i sad "我…我什么都没做…."



    if cyne_route:
        translate None lucius_part1_0908:
            "当我坐起身时，伊尔兰就蹲在我面前的地上。赛恩急忙冲到我身旁，低头看着我，鲜血已经浸透了我胸前的衣衫。"
        translate None lucius_part1_0909:
            c c wsur "怎么回事？"

    translate None lucius_part1_0910:
        i "你…" # Might be in Fawn route too
    translate None lucius_part1_0911:
        "走在稍前方的艾米尔和卡斯皮安在黑暗中向我们呼喊。当我们没有回应时，他们很快找了回来。"
    translate None lucius_part1_0912:
        cas sur "怎么了？"
    translate None lucius_part1_0913:
        rs "呃…这..好痛…"
    translate None lucius_part1_0914:
        i "你刚刚…做了什么？"
    translate None lucius_part1_0915:
        v ouc "有人能解释一下发生了什么吗？"
    translate None lucius_part1_0916:
        i ang "…不见了。"
    translate None lucius_part1_0917:
        "尽管四周风雪交加，伊尔兰仍扯掉了上衣，撕开绷带。大家都目光在我们之间来回游移。"


    if cyne_route:
        translate None lucius_part1_0918:
            c c wang "快，你能帮他包扎吗？"
        translate None lucius_part1_0919:
            v sur "好…好的！"
        translate None lucius_part1_0920:
            c "雷恩，这是什么？"
        translate None lucius_part1_0921:
            rs "…我也不清楚，就是…离开奥雷利亚卡维拉后突然出现的能力。我能治愈别人的伤口，但…"
        translate None lucius_part1_0922:
            "我低头看着那片深红的血渍。"
        translate None lucius_part1_0923:
            rs "但…这种情况会发生。"
        translate None lucius_part1_0924:
            c "为何不早点告诉我？"
        translate None lucius_part1_0925:
            rs "我…"
        translate None lucius_part1_0926:
            "我为什么没告诉他？我不知道。"
        translate None lucius_part1_0927:
            rs "我只是…"
        translate None lucius_part1_0928:
            c c wsad "…我明白了。你无法信任我。"
        translate None lucius_part1_0929:
            rs "不是那样的。"
        translate None lucius_part1_0930:
            c "就是这样。毕竟，我一向都不可靠，不是吗？"


    if fawn_route:
        translate None lucius_part1_0931:
            f c wsad "…维拉斯，你能处理他的伤口吗？"
        translate None lucius_part1_0932:
            v sur "对..对啊！"


    if leos_route:
        translate None lucius_part1_0933:
            l c whur "别光站着！他需要绷带！"
        translate None lucius_part1_0934:
            "莱奥斯按压着我的伤口，眼中带着忧虑俯视我。伤口灼痛着，我想知道伊尔兰是怎么撑到现在的。"
        translate None lucius_part1_0935:
            v sur "啊，是的，抱歉！"
        translate None lucius_part1_0936:
            l c wsur "这他妈是怎么回事？"
        translate None lucius_part1_0937:
            rs c wsad "....."
        translate None lucius_part1_0938:
            "我本该早点告诉他。不是以这种方式…"
        translate None lucius_part1_0939:
            rs "我……我……"
        translate None lucius_part1_0940:
            rs "..我不知道，就是…那是我离开奥雷利亚卡维拉之后开始出现的情况。我能治愈别人的伤口，但是…"
        translate None lucius_part1_0941:
            "我低头看着那片深红的血渍。"
        translate None lucius_part1_0942:
            rs "但…这种情况会发生。"
        translate None lucius_part1_0943:
            l "…你为什么不早告诉我？"
        translate None lucius_part1_0944:
            rs c wsur "我不是故意的，我保证！我只是…不知道该怎么提起这件事.."
        translate None lucius_part1_0945:
            l c wthi "说到底你还是不信任我。"
        translate None lucius_part1_0946:
            rs "莱奥斯，不是那样的，我保证…"
        translate None lucius_part1_0947:
            l c wsur "…这都不重要了。我本就不该指望你觉得我值得信任。"
        translate None lucius_part1_0948:
            rs c wsad "莱奥斯，求你了…！"



    translate None lucius_part1_0949:
        i neu "这不是个惊喜吗…"


    if fawn_route:
        translate None lucius_part1_0950:
            f "…这已经不是第一次发生这种事了。就在我们相遇后不久，他治好了我的伤，但是…"


    translate None lucius_part1_0951:
        v ouc "..我想我开始明白了。他的能力是通过消耗自己的生命来治愈他人，对吗？这个伤是伊尔兰的。"
    translate None lucius_part1_0952:
        rs "呃..是啊…没错…"
    translate None lucius_part1_0953:
        v "这东西若落入恶人之手会很危险。你能控制它吗？"
    translate None lucius_part1_0954:
        rs c wsad "不…"
    translate None lucius_part1_0955:
        ae neu "这是你的\"礼物\"，作为下一位言者。如果那还能被称之为礼物的话。"
    translate None lucius_part1_0956:
        rs c whur "我的..我的能力？你是说…？"
    translate None lucius_part1_0957:
        ae "它会根据不同人展现出不同形态。我完全做不到类似的事。"
    translate None lucius_part1_0958:
        "维拉斯将草药按进我的伤口，起初灼热难忍，随后整个区域便失去了知觉。他止住血后用绷带包扎起来，我迅速重新穿好衣服。"
    translate None lucius_part1_0959:
        "它仍隐隐作痛。持续的压迫感让人呼吸困难。"
    translate None lucius_part1_0960:
        v sad "….雷恩…你该回去了。我们能自己处理。"
    translate None lucius_part1_0961:
        rs "不可能！我完全可以应付…没问题的…"
    translate None lucius_part1_0962:
        v "….那我们至少可以在这里过夜，明天继续。"
    translate None lucius_part1_0963:
        "我摇摇头站了起来。"
    translate None lucius_part1_0964:
        rs "我们没有时间可浪费了。"
    translate None lucius_part1_0965:
        i con "…你们都听见了。这小子有骨气，这点我承认。"
    translate None lucius_part1_0966:
        v "也许你们俩终究没那么不同…"
    translate None lucius_part1_0967:
        i sad "这对我们俩可都不算称赞，你知道的。"


    if leos_route:
        translate None lucius_part1_0968:
            l c wneu "…过来。"
        translate None lucius_part1_0969:
            "令我惊讶的是，莱奥斯跪在我面前的雪地里，等着我爬上他的背。"
        translate None lucius_part1_0970:
            rs c wsur "你…你确定吗？"
        translate None lucius_part1_0971:
            l "再让我等下去，我可能会改变主意。"
        translate None lucius_part1_0972:
            "我小心翼翼地爬上他的背，不确定是否真的被允许触碰他—他毫不费力地将我驮了起来。"


    translate None lucius_part1_0973:
        "艾米尔尴尬地站在人群外围。他一看到我起身，便转身要走，我们赶忙追上他。"


    if cyne_route or fawn_route:
        translate None lucius_part1_0974:
            "每一步都在我身体里激起痛苦的回应，但我仍坚持在雪地中前行，拼命试图不让自己落后。"


    if cyne_route:
        translate None lucius_part1_0975:
            "赛恩没有再看向我。我以为…我以为我们终于可以好好谈谈了，可是…"
        translate None lucius_part1_0976:
            "我又一次把事情搞砸了。"


    if fawn_route:
        translate None lucius_part1_0977:
            "福恩走在我身旁，并不介意我的缓慢。当我踉跄时，他会扶住我，轻轻捏捏我的手，再搀着我继续前行。"



    if leos_route:
        translate None lucius_part1_0978:
            "莱奥斯小心地走着，确保不会撞到我的肩膀或走得太快。"
        translate None lucius_part1_0979:
            rs c wsad "....."
        translate None lucius_part1_0980:
            "即便我对他有所隐瞒，他还是会这样对我…"
        translate None lucius_part1_0981:
            "我把额头靠在他肩上，拼命忍住不让泪水落下。"
        translate None lucius_part1_0982:
            rs "对不起…"
        translate None lucius_part1_0983:
            l "...."
        translate None lucius_part1_0984:
            "莱奥斯保持着沉默，但我能看出他在苦思冥想。"
        translate None lucius_part1_0985:
            "这段路途漫长而艰辛，正因如此我越发感激有莱奥斯相伴。"
        translate None lucius_part1_0986:
            "途中我们偶尔交谈几句，但大部分路程都在沉默中度过。"


    if cyne_route or fawn_route:
        translate None lucius_part1_0987:
            "路途漫长而艰难，加上胸口阵阵绞痛更显煎熬。我们偶尔说上几句，但主要还是默默前行。"


    translate None lucius_part1_0988:
        "黑暗与寒冷让我们瑟瑟发抖，不由得裹紧外套。连维拉斯这次也破例穿上了鞋。"
    translate None lucius_part1_0989:
        cas sur "…你这身行头走路没问题吗？实在不适合登山。"
    translate None lucius_part1_0990:
        ae ann "我很好，非常感谢。"
    translate None lucius_part1_0991:
        cas "你为什么不…我不知道，穿点看起来更正常的？"
    translate None lucius_part1_0992:
        ae "....."
    translate None lucius_part1_0993:
        cas sad "...?"
    translate None lucius_part1_0994:
        ae emb2 "我就只有这些衣服，行了吧？"
    translate None lucius_part1_0995:
        cas hap "…噗呲。"
    translate None lucius_part1_0996:
        "艾米尔气呼呼地摇头，懒得搭理卡斯皮安。"
    translate None lucius_part1_0997:
        v neu "如果传闻属实的话…我们离目的地已经不远了，不过…"
    translate None lucius_part1_0998:
        v "在继续前进之前，有些事必须告诉你们。"


    if cyne_route or leos_route:
        translate None lucius_part1_0999:
            rs "那是什么？"
        translate None lucius_part1_1000:
            "我的脸上浮现出忧虑，但维拉斯像往常一样轻松平静地微笑着。"


    if fawn_route:
        translate None lucius_part1_1001:
            f "那是什么？"
        translate None lucius_part1_1002:
            "福恩的脸上布满忧虑的阴云，而维拉斯却像往常一样，轻松自若地微笑着。"


    translate None lucius_part1_1003:
        v smi "或许我这么说有些自私…但对我而言，这是最后一次旅行了。"
    translate None lucius_part1_1004:
        rs c wsur "什么？"
    translate None lucius_part1_1005:
        "伊尔兰的眉毛抽动了一下，目光从我们身上移开。"
    translate None lucius_part1_1006:
        v "数百年来我都迷失方向，直至我找到了人生目标。"


    if cyne_route:
        translate None lucius_part1_1007:
            c c wneu "…你是指那些被困住的奥雷利亚诸神？"


    if leos_route:
        translate None lucius_part1_1008:
            l c wneu "…关于协助奥蕾莉亚神明的事。"


    if fawn_route:
        translate None lucius_part1_1009:
            f c wneu "…被困住的神明？"


    translate None lucius_part1_1010:
        "他点点头。"
    translate None lucius_part1_1011:
        v "我会找到他们，我会解救他们。我将永远感激伊尔兰指引我走上这条道路。"
    translate None lucius_part1_1012:
        v "…等他们获得自由，我才能安心离去。"
    translate None lucius_part1_1013:
        rs "继续前进？你要去哪里？"
    translate None lucius_part1_1014:
        v "如果能就此了结，我就能无愧地离去。"


    if cyne_route:
        translate None lucius_part1_1015:
            cyneraen "......." # CYNE AND RAEN TOGETHER


    if leos_route:
        translate None lucius_part1_1016:
            rl "......." # LEOS AND RAEN TOGETHER


    if fawn_route:
        translate None lucius_part1_1017:
            fr "......." # FAWN AND RAEN TOGETHER


    translate None lucius_part1_1018:
        rs c wsad "我们…那我们再也见不到你了吗？"
    translate None lucius_part1_1019:
        "他的微笑短暂地僵了一下，脸上闪过一丝悲伤。"
    translate None lucius_part1_1020:
        v ouc "……我会一直想念着你们所有人。"
    translate None lucius_part1_1021:
        "……虽然不知道具体怎么回事，但猜想如果他脱离人类躯体…大概就会消逝吧，就像千百年前的神明那样。"
    translate None lucius_part1_1022:
        rs "伊尔兰，你不会寂寞吗？你觉得呢？"
    translate None lucius_part1_1023:
        i sad "…这不该由我来决定。"
    translate None lucius_part1_1024:
        "虽然看不清他的表情，但声音比平时更严肃克制。"
    translate None lucius_part1_1025:
        cas sur "等一等…看这个。"
    translate None lucius_part1_1026:
        "前方茂密的树林间隐约透出某种微光，那光亮虽被遮掩却仍依稀可见。"
    translate None lucius_part1_1027:
        ae neu "…如果我们要寻找一个隐藏的村庄，我想我们已经找到了。"
    translate None lucius_part1_1028:
        v neu "让我走在前面。我不知道他们看到人类试图进入会作何反应。"
    translate None lucius_part1_1029:
        "我们都点点头，紧随维拉斯之后，他正小心翼翼地缓步向村庄走去。"
    translate None lucius_part1_1030:
        "连绵起伏的群山环绕着我们，冰封的山尖显得咄咄逼人。眼前的景色荒凉而寂静。甚至可以说是一片孤寂。"
    translate None lucius_part1_1031:
        "我沉浸在自己的思绪里，甚至没注意到队伍又多了一个人。"
    translate None lucius_part1_1032:
        show sylvir m dark neu with dissolve
        u "旅人们，报上来意。"
    translate None lucius_part1_1033:
        "维拉斯立刻高举双手，示意他没有武器。其余的人也默不作声地效仿他的动作。"


    if leos_route:
        translate None lucius_part1_1034:
            "莱奥斯把我放到地面，我站到他身旁。"


    translate None lucius_part1_1035:
        v fro "…我们来此恳请贵方援助。"
    translate None lucius_part1_1036:
        u "那你最好趁还有机会时赶紧回头。"
    show sylvir m dark sur with dis
    translate None lucius_part1_1037:
        "她先是一个接一个地看着我们俩，"

    hide sylvir with dissolve

    if fawn_route:
        translate None lucius_part1_1038:
            f c wsur "刚才怎么回事？"


    if cyne_route:
        translate None lucius_part1_1039:
            c c wsur "刚才有点…诡异。"


    if leos_route:
        translate None lucius_part1_1040:
            l c wpis "这很可疑。"


    translate None lucius_part1_1041:
        rs c wsur "我们应该跟着她吗？"


    if fawn_route:
        translate None lucius_part1_1042:
            f "我不确定…"


    if cyne_route:
        translate None lucius_part1_1043:
            c "我们不躲起来行吗？她可能带人回来对付我们。"


    if leos_route:
        translate None lucius_part1_1044:
            l "我们肯定不该在这儿等她回来。"


    translate None lucius_part1_1045:
        moru c sad "雷恩！"
    translate None lucius_part1_1046:
        "一道白影向我冲来，转瞬间我就被紧紧抱住了。"

    stop music fadeout 2.0
    window hide dissolve

    scene gallery_97 with dissolve
    window show dissolve

    translate None lucius_part1_1047:
        rs "哇啊！"
    translate None lucius_part1_1048:
        "我的伤口隐隐作痛，但我还是立刻抱住了这个刚朝我冲来的人。"
    translate None lucius_part1_1049:
        "我所能见的只有她的白发。她把脸埋在我肩膀上，我能感觉到那里渐渐变得湿润。"


    if leos_route:
        translate None lucius_part1_1050:
            "在我身旁，我看见莱奥斯绷紧了身体，但我很快摇了摇头。"

    scene gallery_98d with dissolve
    translate None lucius_part1_1051:
        rs "我很抱歉，不过…我认识你吗？"
    translate None lucius_part1_1052:
        play music "sounds/bgm/night.ogg" fadein 3.0
        moru "哦，雷恩，你没事真是太好了。"
    translate None lucius_part1_1053:
        moru "一直以来…一直以来我都在注视着你，但我从未想过我们能正式相遇。"
    translate None lucius_part1_1054:
        "她的话音在我脑海中响起，惊得我张大了嘴。"
    translate None lucius_part1_1055:
        rs "你就是…我梦里的那个人？！"
    translate None lucius_part1_1056:
        v sur "什么…？"
    scene gallery_98 with dissolve
    translate None lucius_part1_1057:
        mor "我太高兴了。雷恩，能和你说话我真是太高兴了。"
    translate None lucius_part1_1058:
        "她的手臂更加用力地环抱我，而我也这样环抱着她。"
    translate None lucius_part1_1059:
        rs "我以为你永远消失了！你是怎么来到这里的？！"
    scene gallery_98b with dissolve
    translate None lucius_part1_1060:
        mor "说来话长，不过后面有的是时间细说。噢，我有好多话要告诉你。自从你小时候起，我就一直希望能有机会跟你谈谈。"
    translate None lucius_part1_1061:
        rs "从我小时候起…？"
    translate None lucius_part1_1062:
        scene gallery_98c with dissolve
        mor "就像那次你脑袋卡在树洞里。哦，还有你爬上屋顶那次—"
    translate None lucius_part1_1063:
        scene gallery_98e with dissolve
        rs "好了！够了，我明白了！"
    translate None lucius_part1_1064:
        "她的笑声渐渐消失，化作低声呢喃。"
    translate None lucius_part1_1065:
        mor "那些你感到迷茫的时刻，那些你觉得这世上已无希望的时刻—我只能看着。我只想像这样抱着你，告诉你一切都会好起来。"
    translate None lucius_part1_1066:
        rs "....."
    translate None lucius_part1_1067:
        mor "抱歉，这对你来说一定太突然了。一个陌生女人在荒野里扑向你，像对待小孩一样对待你。我只是…我认识你已经很久了，雷恩。"


    if achievement.has("morwen_meet"):
        pass
    else:
        $ renpy.display_notify("成就解锁：老妈，是你吗？")

    python:
        achievement.grant("morwen_meet")
        achievement.sync()
    translate None lucius_part1_1068:
        $ about_Morwen.locked = False
        mor "起码让我自我介绍一下。我的名字叫{a=set_entry:enc_people->about_Morwen}{color=#DA70D6}莫温{/color}{/a}。"
    translate None lucius_part1_1069:
        rs "…谢谢。"
    translate None lucius_part1_1070:
        "当我退缩时，她把脸从我肩膀上移开，紧紧盯着我。"
    translate None lucius_part1_1071:
        mor "…你受伤了？"
    translate None lucius_part1_1072:
        rs "还好。"
    translate None lucius_part1_1073:
        mor "你早该说出来的！告诉我哪里疼，我会让它好转的。"
    translate None lucius_part1_1074:
        su neu "等等。虽然我说过会带他们来，但人类是不允许进入村庄的。"
    translate None lucius_part1_1075:
        v neu "我不是人类。"
    translate None lucius_part1_1076:
        su "也许你不是，但你的同伴们是。你想从我们这里得到什么？"
    translate None lucius_part1_1077:
        i ang "我们需要你的帮助。我们不接受拒绝。"
    translate None lucius_part1_1078:
        su thi "对一个乞丐来说也太咄咄逼人了。"
    translate None lucius_part1_1079:
        v fro "我们来此祈求村庄神灵的庇护。锡德卡汉—不，整个维迪斯都面临巨大危机，单凭我们无法应对。"
    translate None lucius_part1_1080:
        mor "…是卢修斯，对吧？"
    translate None lucius_part1_1081:
        rs "你怎么知道的？"
    translate None lucius_part1_1082:
        mor "我们不止一次擦肩而过…他一踏入锡德卡汉我就感觉到了。"
    translate None lucius_part1_1083:
        su neu "我们不干涉人类的问题。你得另寻他处。"


    if fawn_route:
        translate None lucius_part1_1084:
            f c wsad "难道就没有一个能做主的人能谈谈吗？求你了，我们只求一见。"


    if cyne_route:
        translate None lucius_part1_1085:
            c c wneu "当问题是由你们同类引起时，这还能算是人类的问题吗？"


    if leos_route:
        translate None lucius_part1_1086:
            l c wpis "真是个笑话。你哪里不明白？他是你同类。"


    translate None lucius_part1_1087:
        su "...."
    translate None lucius_part1_1088:
        su "你可以去问某个人，但他的答案不会有区别。"
    translate None lucius_part1_1089:
        mor "…不管他说什么，我都会支持你。"

    window hide dissolve

    scene bg sc mountains with dissolve
    window show dissolve
    translate None lucius_part1_1090:
        mor c neu "西尔维尔，你能带雷恩进去检查下他的伤吗？"
    translate None lucius_part1_1091:
        s neu "…没问题。"
    translate None lucius_part1_1092:
        "西尔维尔转身默默走进了村庄。我们都跟着她，但莫温拽住了卡斯皮安和艾米尔的袖子。"
    translate None lucius_part1_1093:
        mor c hap "我们马上就好。"
    translate None lucius_part1_1094:
        cas sur "呃…"


    scene bg sc mountains with Fade(1.0, 1.0, 1.0)
    translate None lucius_part1_1095:
        mmn "现在，该怎么处理这两个家伙…？真的，我的孩子们实在太让人操心了…"
    translate None lucius_part1_1096:
        cas sur "你们…有事吗？"
    translate None lucius_part1_1097:
        "莫温凝视着他们两人的脸，而他们也带着困惑的表情回望着她。"
    translate None lucius_part1_1098:
        mor c wor "你们两个…"

    window hide dissolve

    scene gallery_99 with dissolve
    window show dissolve
    translate None lucius_part1_1099:
        mor "你们变成了非常淘气的男孩！"
    translate None lucius_part1_1100: #SYNCED
        ca "啊！"
    translate None lucius_part1_1101:
        mor "别以为你们两个逃过了我的法眼。雷恩不是我照看的第一个孩子！"
    translate None lucius_part1_1102:
        mor "你们两个打架打得实在太久太久了。是时候该停下来了。"
    translate None lucius_part1_1103:
        cas "....."
    translate None lucius_part1_1104:
        mor "当你们两个还是孩子的时候，相处得多好啊。如果我看着你们这样都这么心疼，那你们自己又是什么感受呢？"
    translate None lucius_part1_1105:
        scene gallery_100 with dissolve
        mor "再次看到你们并肩而立…这足以让我落泪。"
    translate None lucius_part1_1106:
        ae "....."
    translate None lucius_part1_1107:
        mor "我知道不会立刻见效。创伤不会那么容易愈合，但我只想请你们尝试。即使要花上多年，我也相信你们俩。"
    translate None lucius_part1_1108:
        cas "…谢谢，小姐，但—"
    translate None lucius_part1_1109:
        mor "小姐？我比你们俩都年长得多，知道吗。比这个村子里所有人加起来还要年长。你可能觉得我多管闲事，但是.."
    translate None lucius_part1_1110:
        "莫温更用力地抱紧了他们两人。"
    translate None lucius_part1_1111:
        scene gallery_100b with dissolve
        mor "我能看见。一条长长的细绳，虽然扭曲打结，却连接着你们二人。即使过了这么多年，我依然能看见它。"
    translate None lucius_part1_1112:
        scene gallery_100c with dissolve
        ae "…不可能了，再也不可能了。"
    translate None lucius_part1_1113:
        mor "我希望你能改变主意，我的小言者。"
    translate None lucius_part1_1114:
        mor "…你经历了很多。别太责备自己了，好吗？"
    translate None lucius_part1_1115:
        mor "嗯…我们不该让其他人久等，对吧？"
    translate None lucius_part1_1116:
        "莫温最终结束了拥抱，但另外两人尴尬地踟躇着。"
    translate None lucius_part1_1117:
        mor "你们还傻站着干吗？决定要拥抱和好了？"
    translate None lucius_part1_1118:
        "他俩都尴尬地看向一旁，目光四下乱瞟，像是在寻找能逃避的地方。"
    translate None lucius_part1_1119:
        "作为回应，莫温伸出手掐了掐他们的脸颊，始终保持着微笑。"
    translate None lucius_part1_1120:
        mor "那就跟我来吧，之后有的是时间弥补。"

    stop music fadeout 2.0

    scene bg sv room night:
        xpos 0.39 ypos 1.3 xanchor 0.5 yanchor 1.0 zoom 1.42
    show sylvir n dim neu at slightright
    show raen nw dim hur at slightleft
    with Fade(1.0, 1.0, 1.0)


    translate None lucius_part1_1121:
        rs "啊！"
    translate None lucius_part1_1122:
        s "别跟个孩子似的。很快就不疼了。"
    translate None lucius_part1_1123:
        play music "sounds/bgm/night.ogg" fadein 4.0
        rs "此刻疼痛难忍…"


    if fawn_route:
        translate None lucius_part1_1124:
            "西尔维尔往我的伤口上倒了点药剂，然后重新包扎。我们俩单独在一起。福恩和维拉斯、伊尔兰都在房间外等候。卡斯皮安和艾米尔依然不见踪影，因为莫温将他们拉到了一旁。"


    if cyne_route:
        translate None lucius_part1_1125:
            "西尔维尔将药水倒在我的伤口上，然后重新包扎。屋里只有我们两人。赛恩在门外等候，依然避着我。维拉斯和伊尔兰站在他身旁。卡斯皮安和艾米尔依然不见踪影—莫温把他们拉到一旁去了。"


    if leos_route:
        translate None lucius_part1_1126:
            "西尔维尔在我的伤口上倒了些药水，然后重新包扎好。莱奥斯站在房间另一头，双臂交叉静静地注视着。"


    translate None lucius_part1_1127:
        "最终，我在纱布外面重新穿上了衬衫，而西尔维尔则忙着将医疗用品放回各自的柜子和盒子里。"
    translate None lucius_part1_1128:
        s "你盯着看什么呢？"
    translate None lucius_part1_1129:
        show raen nw dim sur with dis
        rs "哦…你？"
    translate None lucius_part1_1130:
        show sylvir n dim ann with dis
        s "说话注意点，小心你的舌头。"
    translate None lucius_part1_1131:
        "….她有点苛刻。"
    translate None lucius_part1_1132:
        rs "你为什么要帮我？"
    translate None lucius_part1_1133:
        show sylvir n dim thi with dis
        s "...."
    translate None lucius_part1_1134:
        s "莫温要我来的。别想太多。"
    translate None lucius_part1_1135:
        rs "你本可以拒绝的。"
    translate None lucius_part1_1136:
        show sylvir n dim neu with dis
        s "抱歉，你更希望我解开你的伤口包扎吗？"
    translate None lucius_part1_1137:
        rs "不，不，对不起，好吗？我只是对你感到好奇。"
    translate None lucius_part1_1138:
        s "呃…有问题就直说吧。我最受不了别人扭捏作态。"

    show raen nw dim neu with dis


    $ about_Sylvir._text =[
        "西尔维尔是位著名制图师，她曾从托根出发，跨海航行至维迪斯。她是第一位绘制出整片大陆详尽地图的人。\n \n奥雷利亚战争结束后不久，她在锡德卡汉附近的深山晕倒。就在她以为生命将尽时，一个名叫埃利奥特的男人救了她，并将她带往众神居住的村庄照料。\n \n当他们最终放她离开时，她被蒙上双眼带下山。死后她升格为神，如今又回到了秘密村，尽管她仍时常梦见往日冒险的时光。"

    ]
    $ about_Sylvir.image = "gui/codex/entries/people/enc_sylvir.jpg"

    translate None lucius_part1_1139:
        rs "….你是{a=set_entry:enc_people->about_Sylvir}{color=#87CEEB}西尔维尔{/color}{/a}，那个著名的制图师？"
    translate None lucius_part1_1140:
        show sylvir n dim sur with dis
        s "...."
    translate None lucius_part1_1141:
        "她的眼睛瞪大了，嘴巴几乎张成一个完整的O形，然后才镇定下来。"
    translate None lucius_part1_1142:
        show sylvir n dim ann with dis
        s "….你怎么知道的？"
    translate None lucius_part1_1143:
        show raen nw dim sur with dis
        rs "那么，这是真的吗？"
    translate None lucius_part1_1144:
        s "还记得我的人不是早已作古，就是葬身海底了。我问你—你怎么知道的？"
    translate None lucius_part1_1145:
        rs "我偶然发现了你的日记。这纯属运气，我发誓。没想到你会在那里。"
    translate None lucius_part1_1146:
        show sylvir n dim sur with dis
        s "你能读懂托根文？"
    translate None lucius_part1_1147:
        rs "呃 不算是 但我带了帮手来处理这事。话说你怎么又来这儿了？我上次看到的消息可是有人送你离开的。"
    translate None lucius_part1_1148:
        show sylvir n dim ann with dis
        s "…你真是个好奇的家伙，不是吗。"
    translate None lucius_part1_1149:
        rs "求你了？"
    translate None lucius_part1_1150:
        s "你还指望发生什么？我死了，以为就此结束了，但显然有足够多的混蛋念我的好，让我成神了。很老套，对吧？"
    translate None lucius_part1_1151:
        rs "我遇见的神明都是在奥雷利亚战争前升格的。那到底是什么感觉？"
    translate None lucius_part1_1152:
        show sylvir n thi with dis
        s "…冰冷。"
    translate None lucius_part1_1153:
        rs "很冷？"
    translate None lucius_part1_1154:
        s "起初，这就像被按在水下，拼命想呼吸，但每一次吸气都让肺部充满水。可即便如此，你还是继续尝试着。"
    translate None lucius_part1_1155:
        s "那一刻你仿佛被四面八方同时拉扯，坠向无边的黑暗深渊。"
    translate None lucius_part1_1156:
        rs "然后…接下来呢？"
    translate None lucius_part1_1157:
        show sylvir n neu with dis
        s "….我不知道接下来发生了什么。然后我就坠落到了地面。"
    translate None lucius_part1_1158:
        s "或许那里曾是众神飞升天堂、俯瞰人间的地方，但对我们这些凡人而言，生活早已不再如此。我只是坠落而已。"
    translate None lucius_part1_1159:
        s "要是没找到这具身体，我那时就真的死了。我想这是命运安排，让我恰好在这具身体垂死时坠落。"
    translate None lucius_part1_1160:
        rs "我—"

    show raen at center
    show sylvir at right
    with move

    translate None lucius_part1_1161:
        show morwen n dim sur at left with dissolve
        mor "雷恩，原来你在这儿。"
    translate None lucius_part1_1162:
        rs "莫温…"
    translate None lucius_part1_1163:
        show morwen n dim smi with dis
        mor "艾米尔和卡斯皮安正和你的同伴们在一起。西尔维尔呢？"
    translate None lucius_part1_1164:
        s "我把他包扎好了。给你们点独处时间。"

    hide sylvir with dissolve
    show morwen at slightleft
    show raen at slightright
    with move

    if cyne_route or fawn_route:
        translate None lucius_part1_1165:
            "我还来不及开口回答，西尔维尔就冲出了房间，只留下我和莫温独处。"


    if leos_route:
        translate None lucius_part1_1166:
            "我还来不及开口回答，西尔维尔就冲出了房间，留下我与莫温和莱奥斯三人。"
        translate None lucius_part1_1167:
            "察觉到气氛不对，莱奥斯也随她离开了。"


    translate None lucius_part1_1168:
        rs "...." #LINE MISSSING
    translate None lucius_part1_1169:
        mor "….你现在感觉如何？"
    translate None lucius_part1_1170:
        show raen nw dim smi with dis
        rs "老实说还是很痛，但我能忍受。"
    translate None lucius_part1_1171:
        show raen nw dim neu with dis
        rs "能告诉我你是怎么来到这里的吗？"
    translate None lucius_part1_1172:
        "她向前走了几步，坐在房间角落的床上。她示意我坐到她身旁。"
    translate None lucius_part1_1173:
        show morwen n dim neu with dis
        mor "…我陪着你直到我们抵达锡德卡汉。在那之前我就想警告你，但我仍然无法正常和你交谈。"
    translate None lucius_part1_1174:
        mor "这可能是因为你没有接受过言者的训练—我能联系到你本身就是个奇迹。"
    translate None lucius_part1_1175:
        show raen nw dim sad with dis
        rs "对不起…"
    translate None lucius_part1_1176:
        show morwen n dim smi with dis
        mor "这不是你的错。"
    translate None lucius_part1_1177:
        "她伸出手捧住我的脸颊，嘴角挂着一丝微笑。"
    translate None lucius_part1_1178:
        mor "当卢修斯抵达锡德卡汉的那一刻，我就明白只要还与你保持联系，他立马就能找到你。虽然切断联系只能为你争取到一点时间，但如果这能决定你是生是死…对我来说，选择再明显不过。"
    translate None lucius_part1_1179:
        rs "即使你可能因此送命…？"
    translate None lucius_part1_1180:
        "她的手从我的脸颊滑落到我的手，戴着手套的纤指轻轻握住。"
    translate None lucius_part1_1181:
        mor "当你活到我这个年纪时，有时候那看起来并不是那么糟糕的事。"
    translate None lucius_part1_1182:
        mor "好吧，你显然能看出我没死。西尔维尔发现了我，并引导我找了一具身体。我很虚弱，不习惯…这具血肉之躯的重量。"
    translate None lucius_part1_1183:
        show morwen n dim sad with dis
        mor "她带我回到这里疗伤。我想逃跑，想来找你，但我的双腿不听使唤。"
    translate None lucius_part1_1184:
        rs "…谢谢你，为这一切。"
    translate None lucius_part1_1185:
        show morwen n dim smi with dis
        mor "没什么好感谢我的，孩子。我几乎什么都没做。"
    translate None lucius_part1_1186:
        "我摇头微笑。她为我做的远比她意识到的要多。"
    translate None lucius_part1_1187:
        show raen nw dim sur with dis
        "门突然开了，维拉斯走了进来。"
    translate None lucius_part1_1188:
        show morwen at left
        show raen at center
        with move
        show veras n dim smi1 at right with dissolve
        mor "…维拉斯？"
    translate None lucius_part1_1189:
        "维拉斯走近时微笑着，并不感到意外。"
    translate None lucius_part1_1190:
        v "你终究还是认出我了。"
    translate None lucius_part1_1191:
        show morwen n dim smi with dis
        mor "好久不见了，丰收之神。"
    translate None lucius_part1_1192:
        v "还有你，水之女神。"
    translate None lucius_part1_1193:
        rs "你们两位认识…？"
    translate None lucius_part1_1194:
        mor "虽然我被囚禁在奥雷利亚卡维拉时我们从未以人类形态相见，但在那之前我们就知道彼此的存在。"
    translate None lucius_part1_1195:
        show veras n dim fro1 with dis
        v "…那里情况如何？"
    translate None lucius_part1_1196:
        show morwen n dim sad with dis
        mor "糟透了。他们全都疯了。我们也只剩昔日的一小部分了。卢修斯吞噬了很多古神。"
    translate None lucius_part1_1197:
        show veras n dim sad1 with dis
        v "…难怪他如此强大。人类与神明混合在一起，任他随心所欲地大快朵颐…"
    translate None lucius_part1_1198:
        mor "如果你打算与他战斗，那我也将在场。"
    translate None lucius_part1_1199:
        v "我担心即便我们两个人联手也不够。"
    translate None lucius_part1_1200:
        mor "...."
    translate None lucius_part1_1201:
        mor "那么，我们需要村民们的帮助？"
    translate None lucius_part1_1202:
        "维拉斯庄严地点点头，思考着。"
    translate None lucius_part1_1203:
        show raen nw dim sad with dis
        rs "…西尔维尔说那不会发生。"
    translate None lucius_part1_1204:
        mor "这…会很困难。他们的领袖对人类毫无兴趣。我不信任他。"
    translate None lucius_part1_1205:
        rs "据我所闻…"
    translate None lucius_part1_1206:
        hide veras
        hide morwen
        hide raen
        with dissolve
        "没过多久，门再次打开，团队其他人重新和我们汇合。西尔维尔看起来已经蓄势待发，准备给伊尔兰迎面一拳。"
    translate None lucius_part1_1207:
        "这真是个天赋，真的。他怎么能这么快就触到别人的痛处。"


    if fawn_route:
        show raen mw dim sur at mleft
        show fawn mw dim sad at mright
        with dissolve
        translate None lucius_part1_1208:
            f "雷恩，你还好吗？"
        translate None lucius_part1_1209:
            "福恩冲了过来，我迅速从床上起身将他接在怀中。"
        translate None lucius_part1_1210:
            rs "我没事。还是有点疼，但我相信很快就会好的。"
        translate None lucius_part1_1211:
            i sad "天啊，找个房间吧。"
        translate None lucius_part1_1212:
            show raen mw dim smi with dis
            rs "我们找到房间了。你想走的话，可以离开？"
        translate None lucius_part1_1213:
            i fli"哦，真让我感动。小家伙变得有脾气了是不是？他们长得可真快。"
        translate None lucius_part1_1214:
            show fawn mw dim neu with dis
            "福恩抬起手来，用双手捧住我的脸。我对他微笑以驱散他的担忧。"
        translate None lucius_part1_1215:
            s ann "如果你们腻腻歪歪完了，是时候去见我们的老大了。他现在应该刚醒，不抓紧去就要错过见面了。"
        translate None lucius_part1_1216:
            show fawn mw dim sur with dis
            f "刚睡醒？可现在是晚上啊。"
        translate None lucius_part1_1217:
            s ann "⋯⋯没错。现在动作快点。"
        translate None lucius_part1_1218:
            "她红黑色的发丝在她又一次转身离去时旋转飞扬。其他人跟在她身后离去，只留下我和福恩。"
        translate None lucius_part1_1219:
            rs "来吧。他可能会拒绝，但问问也无妨。"
        translate None lucius_part1_1220:
            show fawn mw dim sad with dis
            f "…雷恩…"
        translate None lucius_part1_1221:
            rs "那是什么？"
        translate None lucius_part1_1222:
            "他俯身轻轻吻了我，然后又退了回去。"
        translate None lucius_part1_1223:
            show fawn mw dim smi with dis
            f "我很高兴你没事。"
        translate None lucius_part1_1224:
            show fawn mw dim sad with dis
            f "….如果出了什么事…"
        translate None lucius_part1_1225:
            f "..."
        translate None lucius_part1_1226:
            f "你只需知道，如果需要的话，我愿意为你而死。"
        translate None lucius_part1_1227:
            "我摇摇头，手指穿过他苍白的发丝。"
        translate None lucius_part1_1228:
            rs "与其为我而死…我更希望你许诺给我你的未来。"
        translate None lucius_part1_1229:
            f "嗯。"
        translate None lucius_part1_1230:
            "他的手抚上我的脸庞，指尖轻轻滑过我的肌肤。经过胸膛，来到手臂，最终握住了我的手。他悲伤地对我笑了笑，然后拉着我向门口走去。"


        stop music fadeout 2.0
        window hide dissolve

        scene bg sv night with dissolve:
            xpos 0.68 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.47
            linear 26.0 xpos 0.28 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.47
        window show dissolve
        play music "sounds/bgm/night.ogg" fadein 3.0

        translate None lucius_part1_1231:
            "西尔维尔带领我们穿过这座寂静的、陷入沉睡的村庄。那些紧闭的房门后无人走动，百叶窗间也无窥探的目光。这时想必所有人都已酣然入梦。"
        translate None lucius_part1_1232:
            rs c wsur"你们的首领是个怎样的人？"


    if cyne_route:
        show raen mw dim sur at mleft
        show cyne mw dim sad at mright
        with dissolve
        translate None lucius_part1_1233:
            c "…你怎么样？"
        translate None lucius_part1_1234:
            "赛恩落在其他人后面，但朝我喊道。"
        translate None lucius_part1_1235:
            show raen mw dim sad with dis
            rs "我…还行。虽然还在疼，但我相信很快就能痊愈。"
        translate None lucius_part1_1236:
            c "明白了…"
        translate None lucius_part1_1237:
            "莫温皱起眉头，目光在赛恩和我之间来回扫视。"
        translate None lucius_part1_1238:
            mor neu "…我们去和首领谈谈。雷恩，赛恩，你们能否在此稍等片刻？"
        translate None lucius_part1_1239:
            rs "…你需要什么吗？"
        translate None lucius_part1_1240:
            mor smi "哦不，我不留下来。就你们两个。"
        translate None lucius_part1_1241:
            i sad "我是说,我也和别的男人一样喜欢速战速决,但当个疯神要把世界给毁了的时候,可能不是最好的时机。"
        translate None lucius_part1_1242:
            show bg sv room night with hpunch
            i ang "嗷！"
        translate None lucius_part1_1243:
            s neu "他现在应该随时都会醒来。快点。"
        translate None lucius_part1_1244:
            "西尔维尔临走前给了他后脑勺一巴掌。维拉斯微笑着跟在她身后。"
        translate None lucius_part1_1245:
            i sad "天啊，这真是多此一举…"
        translate None lucius_part1_1246:
            "其他人迅速离去，只留我和赛恩独处。沉默不断延伸，我俩都无话可说。"
        translate None lucius_part1_1247:
            "不是那样的。我有太多想说的话。我只是太害怕说出口。"
        translate None lucius_part1_1248:
            rs "…..很抱歉没有告诉你真相。不是我不信任你。"
        translate None lucius_part1_1249:
            c "…..不，你做得对。你不该相信我。"
        translate None lucius_part1_1250:
            c "也许你还是不该这样做…"
        translate None lucius_part1_1251:
            rs "你为什么老说这种话？"
        translate None lucius_part1_1252:
            c "......"
        translate None lucius_part1_1253:
            c "雷恩，我…我甚至不知从何说起…"
        translate None lucius_part1_1254:
            rs "…从头开始。"
        translate None lucius_part1_1255:
            c "..........."
        translate None lucius_part1_1256:
            show cyne mw dim neu with dis
            stop music fadeout 1.0
            c "…..我母亲命令我接近你，这样她就能利用你，而我也确实这么做了。"
        translate None lucius_part1_1257:
            show raen mw dim sur with hpunch
            rs "什么？！"
        play music "sounds/bgm/sad.ogg" fadein 3.0
        translate None lucius_part1_1258:
            c "我所做的一切都只是在利用你。"
        translate None lucius_part1_1259:
            rs "......"
        translate None lucius_part1_1260:
            "不…这不可能是真的。我们一起度过的所有时光…不可能是谎言…"
        translate None lucius_part1_1261:
            rs "我…不相信你…"
        translate None lucius_part1_1262:
            show cyne mw dim sad with dis
            c "随你怎么不信，这就是事实。"
        translate None lucius_part1_1263:
            c "她会带走任何认为能帮她达成目标的人，榨干他们直至只剩空壳。你也不例外。"
        translate None lucius_part1_1264:
            c "从一开始就是个谎言。"
        translate None lucius_part1_1265:
            show raen mw dim sad with dis
            rs "在奥克斯哈伯帮助我，给我买这些衣服，和我睡觉⋯⋯你是在告诉我你做这一切都是为了欺骗我？"
        translate None lucius_part1_1266:
            c "….是的。就像我对之前所有人做的那样。"
        translate None lucius_part1_1267:
            rs "那你现在为何还与我待在一起，让她既找不到你也找不到我？！"
        translate None lucius_part1_1268:
            c "因为我是一个懦夫。"
        translate None lucius_part1_1269:
            rs "…你说她与你断绝了关系。"
        translate None lucius_part1_1270:
            c "...."
        translate None lucius_part1_1271:
            c "我拒绝将你交出去，但这改变不了我对你做的其他一切。"
        translate None lucius_part1_1272:
            rs "....."
        translate None lucius_part1_1273:
            show raen mw dim neu with dis
            rs "如果一切都是谎言…为什么不干脆把我交给她？你本可以轻易这么做的。我会跟着你去任何地方。"
        translate None lucius_part1_1274:
            c "…我不知道"
        translate None lucius_part1_1275:
            show raen mw dim sad with dis
            rs "赛恩—"
        translate None lucius_part1_1276:
            c "快点儿，咱们走吧。其他人都在等着呢。"
        translate None lucius_part1_1277:
            rs "求求你…别再躲着我了。我们谈谈吧。"
        translate None lucius_part1_1278:
            c "我没什么要对你说的了。你现在知道真相了。"
        translate None lucius_part1_1279:
            rs "可是—"
        translate None lucius_part1_1280:
            hide cyne
            hide raen
            with dissolve
            "他将手按在门上，回望了我一眼。脸上挂着我所见过最悲伤、最孤独的笑容。"
        translate None lucius_part1_1281:
            c wsmi "我触碰过的每一样东西都被摧毁了，雷恩。我不希望你也遭遇同样的命运。"
        translate None lucius_part1_1282:
            "接着就只剩我一人。"
        translate None lucius_part1_1283:
            "我低头凝视着摊在大腿上的手掌。"
        translate None lucius_part1_1284:
            "那双曾抚摸过他人全身的手。那个人曾是我的整个世界。"
        translate None lucius_part1_1285:
            "一个用谎言接近我的人。"
        translate None lucius_part1_1286:
            "….一个为保护我安全而牺牲一切的人。"
        translate None lucius_part1_1287:
            "我从床边站起身，身体传来的疼痛让我轻轻呻吟了一声。"
        translate None lucius_part1_1288:
            "站在门前，我将手放在赛恩刚才触碰的位置，随后理清思绪，转身离开去与其他人会合。"

        stop music fadeout 2.0
        window hide dissolve

        scene bg sv night with dissolve:
            xpos 0.68 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.47
            linear 26.0 xpos 0.28 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.47
        window show dissolve
        play music "sounds/bgm/night.ogg" fadein 3.0
        translate None lucius_part1_1289:
            "西尔维尔带着我们穿过寂静沉睡的村庄。紧闭的门后无人活动，百叶窗间也没人窥探。此刻，所有人必定都已熟睡。"
        translate None lucius_part1_1290:
            "无论我如何试图引起赛恩的注意，他就是不肯看我一眼。"
        translate None lucius_part1_1291:
            i sad "这次你又做了什么？"
        translate None lucius_part1_1292:
            rs c wsur "什么…？"
        translate None lucius_part1_1293:
            s neu "管好你自己的事。" # voice match with 1970
        translate None lucius_part1_1293b:
            i sad "你为什么跟我过不去？拜托，大家通常都觉得我很有魅力。"
        translate None lucius_part1_1294:
            s "我能准确判断出你是哪种类型的人。"
        translate None lucius_part1_1295:
            i con "哦？请继续。这个我很感兴趣。"
        translate None lucius_part1_1296:
            s ann "A rat."
        translate None lucius_part1_1297:
            i sad "A…. rat?"
        translate None lucius_part1_1298:
            s neu "是的。一只老鼠。"
        translate None lucius_part1_1299:
            i "想解释一下…？"
        translate None lucius_part1_1300:
            s "那种喜欢惹是生非、给人添乱的人。真是个卑鄙小人。"
        translate None lucius_part1_1301:
            i "....."
        translate None lucius_part1_1302:
            v smi "别担心，伊尔兰。你会成为一只非常可爱的老鼠。"
        translate None lucius_part1_1303:
            i hap "嗯…也许我会的。"
        translate None lucius_part1_1304:
            s "所以只要是他说的就没问题？"
        translate None lucius_part1_1305:
            rs c wsad "嘿，赛恩—"
        translate None lucius_part1_1306:
            c c whap "那么，你们那位首领是什么样的人？高大、健壮、性感？"
        translate None lucius_part1_1307:
            mor cu sur "呃…其实你说得八九不离十。"
        translate None lucius_part1_1308:
            rs "....."
        translate None lucius_part1_1309:
            rs c wsad "我们真的有希望能说服他吗…？"


    if leos_route:
        show raen mw dim sad at mright
        show leos mw dim neu at mleft
        with dissolve
        translate None lucius_part1_1310:
            l "你感觉怎么样？"
        translate None lucius_part1_1311:
            rs "心还是很痛，但我应该能挺过来。"
        translate None lucius_part1_1312:
            l "你应该在这里休息，我们去和他们的首领谈谈。"
        translate None lucius_part1_1313:
            rs "我不会让你丢下我的。"
        translate None lucius_part1_1314:
            show leos mw dim sur with dis
            l "..."
        translate None lucius_part1_1315:
            mor smi "…要不我带其他人参观一会儿？"
        translate None lucius_part1_1316:
            l "你们其他人呢？"
        translate None lucius_part1_1317:
            mor "我们先让你们单独待会儿，好吗？"
        translate None lucius_part1_1318:
            i fli "别玩得太开心。"
        translate None lucius_part1_1319:
            show raen mw dim sur with dis
            rs "等等，你不用—"
        translate None lucius_part1_1320:
            "她挥了挥手，整群人迅速离开了房间。"
        translate None lucius_part1_1321:
            stop music fadeout 2.0
            l "...."
        translate None lucius_part1_1322:
            show raen mw dim sad with dis
            rs "呃…对不起，行了吧？"
        translate None lucius_part1_1323:
            play music "sounds/bgm/sad.ogg" fadein 3.0
            l "我告诉过你，你不需要这样。"
        translate None lucius_part1_1324:
            rs "我确实信任你。"
        translate None lucius_part1_1325:
            l "…赛恩知道吗？"
        translate None lucius_part1_1326:
            rs "…也没有。"
        translate None lucius_part1_1327:
            l "福恩？"
        translate None lucius_part1_1328:
            rs "..."
        translate None lucius_part1_1329:
            rs "之所以会发现这件事…全是因为他。"
        translate None lucius_part1_1330:
            l "…我明白了"
        translate None lucius_part1_1331:
            rs "这只是个误会，好吗？我发誓，我没有其他秘密了。我只是…不知道该怎么提起这件事。"
        translate None lucius_part1_1332:
            l "我们该赶上其他人了。"
        translate None lucius_part1_1333:
            show raen mw dim sur with dis
            rs "莱奥斯—"
        translate None lucius_part1_1334:
            hide raen
            hide leos
            with dissolve
            "我还未及再说什么，他已经离开了。"
        translate None lucius_part1_1335:
            "我孤身一人。"
        translate None lucius_part1_1336:
            "我呻吟着从床上爬起来，迫切想要追上他。"

        stop music fadeout 2.0
        window hide dissolve

        scene bg sv night with dissolve:
            xpos 0.68 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.47
            linear 26.0 xpos 0.28 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.47
        window show dissolve
        play music "sounds/bgm/night.ogg" fadein 3.0
        translate None lucius_part1_1337:
            rs c wsur "莱奥斯，等等我…！"
        translate None lucius_part1_1338:
            "前方，莱奥斯已经赶上了其他人，他们正尽可能愉快地在这种境况下交谈着。"
        translate None lucius_part1_1339:
            "西尔维尔带领我们穿过这座寂静的、陷入沉睡的村庄。那些紧闭的房门后无人走动，百叶窗间也无窥探的目光。这时想必所有人都已酣然入梦。"
        translate None lucius_part1_1340:
            "无论我说什么，莱奥斯都不理睬我。"
        translate None lucius_part1_1341:
            i fli "怎么，你现在连小家伙都懒得搭理了？这可不像是我们那位光辉骑士的作风。"
        translate None lucius_part1_1342:
            l c wpis "我没有忽视任何人。"
        translate None lucius_part1_1343:
            i "可看起来就是这样。"
        translate None lucius_part1_1344:
            l "我不是。"
        translate None lucius_part1_1345:
            "伊尔兰用手肘轻推莱奥斯，想让他踉跄着撞向我，但西尔维尔抓住了他的手腕。"
        translate None lucius_part1_1346:
            s neu "管好你自己的事。" # voice match with 1895
        translate None lucius_part1_1346b:
            i sad "我一直只管自己的事！"
        translate None lucius_part1_1347:
            v smi "噗嗤。"
        translate None lucius_part1_1348:
            i "维拉斯，连你也这样！"
        translate None lucius_part1_1349:
            v "抱歉伊尔兰，但如果你真能管住自己的事，那就不像你了。"
        translate None lucius_part1_1350:
            i con "哎哟…既然是你说这话，那我就接受吧。"
        translate None lucius_part1_1351:
            l "你就像条拴着链子的狗。"
        translate None lucius_part1_1352:
            i "这比喻还不算太糟。"
        translate None lucius_part1_1353:
            "我在一旁笑了，但内心仍然隐隐作痛。"
        translate None lucius_part1_1354:
            rs c wsad"话说…你们这位首领是个什么样的人？"


    translate None lucius_part1_1355:
        s neu "他心地善良，但别以为这就是软弱。他很强硬—无论是精神上还是身体上。他的回答会和我的没两样。"
    translate None lucius_part1_1356:
        mor cu smi "我相信，他们一起肯定能说服他。"
    translate None lucius_part1_1357:
        s "你不该给他们这种虚假的希望。"
    translate None lucius_part1_1358:
        mor cu sad "我相信他们，这有什么错？"
    translate None lucius_part1_1359:
        "西尔维尔没有提出任何反驳，但她突然停下了脚步。"
    translate None lucius_part1_1360:
        s "待在这儿，我会告诉他我们有访客来了。"
    translate None lucius_part1_1361:
        "她消失在一栋小房子里。可以听到里面传来喃喃低语声，但我听不清在说什么。当她再次出现时，她挽住了莫温的手臂。"
    translate None lucius_part1_1362:
        mor cu sur "你在干什么？"
    translate None lucius_part1_1363:
        s "他们可以自己申诉情况，我需要和你谈谈。"
    translate None lucius_part1_1364:
        mor cu sad "….好吧。雷恩，祝你好运。"
    translate None lucius_part1_1365:
        stop music fadeout 4.0
        "在他们消失在拐角处几分钟后，小屋的门再次打开。"
    translate None lucius_part1_1366:
        "我能感觉到自己的心都提到嗓子眼了。成败全看能否说服这家伙了…我们能做到的，对吧？"
    translate None lucius_part1_1367:
        "一步，两步，他终于出现在视野里。"


    play music "sounds/bgm/forgotten.ogg" fadein 2.0

    show elliot m dark gla
    show bg sv night:
        xpos 0.28 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.47

    with dissolve
    translate None lucius_part1_1368:
        "一个宽肩高个的男子，神情严肃。他随手关上门，皱着眉头俯视着我。"
    translate None lucius_part1_1369:
        "他周身散发着一种力量感，凶猛而威严。即使在黑暗中，他那刺状的火红头发也格外醒目。"
    translate None lucius_part1_1370:
        show elliot m dark sad with dis
        "他的目光扫过我们所有人，突然睁大了眼睛。那股凌厉的气势瞬间消散，取而代之的是先前未曾显露的暖意。"
    translate None lucius_part1_1371:
        hide elliot
        show raen nw dark cloak sur at left
        show elliot n dark sad at center
        show veras n dark o2 sur2 at right
        with dissolve
        el "…维拉斯？"
    translate None lucius_part1_1372:
        v "埃利奥特？！"
    translate None lucius_part1_1373:
        el "我…我以为你死了…"
    translate None lucius_part1_1374:
        show veras n dark o2 smi2 with dis
        v "我也以为你死了！老友，我们分别太久了。"
    translate None lucius_part1_1375:
        "维拉斯向前走去，脸上露出罕见的由衷喜悦。他平时总是那么冷静，那么克制。"
    translate None lucius_part1_1376:
        show elliot n dark smi with dis
        el "要早知道是你，我肯定赶忙去迎接了。你来这儿做什么？"
    translate None lucius_part1_1377:
        show veras n dark o2 sad2 with dis
        v "…恐怕这次不是来叙旧的。我们需要你的帮助，情况看起来很不妙。首先，让我为你介绍大家。"
    translate None lucius_part1_1378:
        v "这位是勇敢的埃利奥特，战神，也是我的挚友。我们相识之久超乎记忆，但大约一百年前失去了联系。"
    translate None lucius_part1_1379:
        $ about_Elliot.image = "gui/codex/entries/people/enc_elliot.jpg"
    translate None lucius_part1_1380:
        $ about_Elliot._text = ["勇敢的埃利奥特，曾作为锡德卡汉对抗众神的守护者，死后重生为战神。如今他隐居在秘密村中，守护并指引着那里迷失的众神。他害怕再次失去本该保护的人们。"]
        rs "{a=set_entry:enc_people->about_Elliot}{color=#87CEEB}埃利奥特{/color}{/a}…就是那个弑神者埃利奥特吗？"
    translate None lucius_part1_1381:
        el "那你听说过我的传说。"
    translate None lucius_part1_1382:
        rs "我是，但是…你不是站在锡德卡汉那边，与诸神作对吗？"
    translate None lucius_part1_1383:
        show elliot n dark gla with dis
        el "生活就是这么奇妙，不是吗？"
    translate None lucius_part1_1384:
        el "维拉斯，你这派对有点意思。除非是我眼花了，他们…"


    if fawn_route:
        translate None lucius_part1_1385:
            v "什么都瞒不过你。这是伊尔兰，我…终生的伴侣，那是福恩。还有这位是卡斯皮安，奥雷利亚卡维拉的皇太子。"


    if cyne_route:
        translate None lucius_part1_1386:
            v "什么都瞒不过你。这位是伊尔兰，我的…终身伴侣，这位是赛恩，来自锡德卡汉的年轻少爷。然后是卡斯皮安，奥雷利亚卡维拉的皇太子。"


    if leos_route:
        translate None lucius_part1_1387:
            v "什么都瞒不过你。这位是伊尔兰，我的…终身伴侣，这位是莱奥斯，一位旅行者。然后是卡斯皮安，奥雷利亚卡维拉的皇太子。"



    translate None lucius_part1_1388:
        cas sur "呃…你好啊！"
    translate None lucius_part1_1389:
        v "最后是…"
    translate None lucius_part1_1390:
        show veras n dark o2 sad2 with dis
        v "这是雷恩和艾米尔，他们是…呃…"
    translate None lucius_part1_1391:
        el "神圣代言人。"
    translate None lucius_part1_1392:
        "维拉斯点头作为回应，他的眼睛眯了起来。"
    translate None lucius_part1_1393:
        show veras n dark o2 neu2 with dis
        v "我知道此时此刻你一定觉得很难信任他们，但我若不是对他们有信心，就不会把人类带到这里。"
    translate None lucius_part1_1394:
        show elliot n dark sad with dis
        "他叹了口气，谈话随之陷入僵局。他的目光终于从维拉斯身上移开，转而直视我的脸。"
    translate None lucius_part1_1395:
        el "既然你明白他们的身份，一开始就不该带他们来。不过看你违背了更明智的判断，我猜你们遇到麻烦了。"
    translate None lucius_part1_1396:
        v "但愿我能说不是…雷恩？"
    translate None lucius_part1_1397:
        rs "噢-哦！"
    translate None lucius_part1_1398:
        show raen nw dark cloak sad with dis
        rs "…我相信你已经知道奥雷利亚卡维拉囚禁众神的事了。"
    translate None lucius_part1_1399:
        el "它一直萦绕在我心头。"
    translate None lucius_part1_1400:
        rs "我来自奥雷利亚卡维拉。那里曾是我生活了十八年的家。我…不得不离开，之后发生了很多事。"
    translate None lucius_part1_1401:
        rs "…但这些现在都不重要。有个神从奥雷利亚卡维拉逃脱了，他的力量正威胁着整个维迪斯。"
    translate None lucius_part1_1402:
        rs "他在锡德卡汉找到了一具躯体，想迫使所有人都屈服于他的意志…他自称为万神之神。"
    translate None lucius_part1_1403:
        v "他的力量太过强大，已不能仅用神明或恶魔来称呼。我还从未见过什么人周身环绕着如此惊人的原始能量。"
    translate None lucius_part1_1404:
        el "...."
    translate None lucius_part1_1405:
        rs "我们…你看我们是绝不可能独自战胜他的—"
    translate None lucius_part1_1406:
        show elliot n dark gla with dis
        el "…维拉斯，告诉我你不是大老远跑来浪费我时间的。"
    translate None lucius_part1_1407:
        show veras n dark o2 neu2 with dis
        v "他说的是实话。他不仅对人类是个威胁，对我们所有人也是。"
    translate None lucius_part1_1408:
        el "这不是我们该打的仗。我们早就放弃保护人类了。"
    translate None lucius_part1_1409:
        show raen nw dark cloak ang with dis
        rs "这是你必须面对的战斗！他是神祇，前代言者，不仅会清除所有阻碍他的障碍，还会将其他古神永远囚禁在奥雷利亚卡维拉，让他们无法反抗他！"
    translate None lucius_part1_1410:
        rs "你以为能逃过他的耳目？当他知道你在此处，绝不会容许你继续这样下去。"
    translate None lucius_part1_1411:
        i ang "若能除掉他，奥雷利亚诸神终得自由。这不正是你想要的吗？"
    translate None lucius_part1_1412:
        el "...."
    translate None lucius_part1_1413:
        "他叹着气，交叉的双臂在胸前收得更紧了。明眼人都看得出他在思考，而且是深思熟虑的那种。"
    translate None lucius_part1_1414:
        show veras n dark o2 sad2 with dis
        v "求你了，埃利奥特。我们在乞求你的支持。没有它……我们根本没机会赢。"
    translate None lucius_part1_1415:
        show elliot n dark sad with dis
        el "…我想帮你。真的。"
    translate None lucius_part1_1416:
        el "但事情没那么简单。其他人不会轻信空言。他们已与人类断绝所有联系，人类城邦面临的威胁对他们毫无意义。"
    translate None lucius_part1_1417:
        el "我们首先且首要考虑的是自我保护。要与一个拥有如此强大力量的对手交战，会牺牲多少人的性命？"
    translate None lucius_part1_1418:
        el "栖居此地的神祇大多与凡人无异。他们爱好和平，心思单纯，本就不为战争而生。"
    translate None lucius_part1_1419:
        i "战神竟会拒绝这样的机会？"
    translate None lucius_part1_1420:
        show elliot n dark gla with dis
        el "成为战神非我所愿。"
    translate None lucius_part1_1421:
        i "但你仍可选择为更伟大的善而战。"
    translate None lucius_part1_1422:
        el "我不信什么\"更伟大的善\"。谁能断言你的善比村庄众人的善更崇高？"
    translate None lucius_part1_1423:
        show raen nw dark cloak sad with dis
        rs "真的…没有什么能说服你改变主意了吗？"
    translate None lucius_part1_1424:
        el "…你可在此留宿一夜。这是我最大的让步。"
    translate None lucius_part1_1425:
        mor cu ang "…埃利奥特。"
    translate None lucius_part1_1426:
        el "莫温，带他们去休息的地方。我明天回来。"
    translate None lucius_part1_1427:
        hide elliot with dissolve
        show morwen n dark sad cloakup with dissolve
        "莫温朝埃利奥特点点头，后者转身消失在夜色中。"
    translate None lucius_part1_1428:
        mor "看你们脸上的表情，我猜事情进展不顺利。"


    if cyne_route:
        translate None lucius_part1_1429:
            c c wsad "我不明白…他为何不肯帮忙？他在锡德卡汉可是个大英雄。"


    if leos_route:
        translate None lucius_part1_1430:
            l c wsur "他不是应该在锡德卡汉当英雄的吗？我真搞不懂凭什么。"


    if fawn_route:
        translate None lucius_part1_1431: # MISSING LINE
            show raen nw dark sad with dis
            rs "他不会帮忙的…"


    translate None lucius_part1_1432:
        v "…别把他想得太不堪。他是个好人，只是众人的生死重担让他心神沉重。"
    translate None lucius_part1_1433:
        v "他一直都很固执。固执，但并非不公。"
    translate None lucius_part1_1434:
        mor "也许好好睡一觉能帮你理清思绪。"


    if fawn_route:
        translate None lucius_part1_1435:
            f c wsad "或许…"


    if cyne_route:
        translate None lucius_part1_1436:
            c "…你说得大概没错。"


    translate None lucius_part1_1437:
        mor "来，跟我走。啊，雷恩，在那稍等片刻。"
    translate None lucius_part1_1438:
        hide morwen
        hide raen
        hide veras
        with dissolve
        "突然间只剩我一人。莫温带领其他人去各个房间准备过夜休息，而我独自站在街道上。在高高的山间，寒风比以往更加刺骨。我在心中再次感谢阿什，多亏了他给我的衣物为我带来温暖。"



    if cyne_route:
        translate None lucius_part1_1439:
            "莱奥斯,福恩…千万要保重。我会竭尽全力救你们。"
        translate None lucius_part1_1440:
            "赛恩…"


    if leos_route:
        translate None lucius_part1_1441:
            "赛恩，福恩…请务必平安。我会尽我所能来救你们。"
        translate None lucius_part1_1442:
            "莱奥斯…对不起。"


    if fawn_route:
        translate None lucius_part1_1443:
            "赛恩，莱奥斯……请务必保证安全。我会竭尽所能拯救你们。"


    jump talktomorwen

    #
