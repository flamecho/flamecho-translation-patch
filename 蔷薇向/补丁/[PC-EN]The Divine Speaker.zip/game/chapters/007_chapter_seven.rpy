label chapter_seven_start:
    scene bg stagwich day with fade:
        yanchor 0.34 zoom 1.65
    window show dissolve
    show raen n sad at center
    show fawn n neu at left
    show leos n neu at right
    with dissolve
    translate None chapter_seven_0001:
        rs "这是怎么回事？！"
    show leos n ann with dis
    translate None chapter_seven_0002:
        l "这是怎么回事\"你还好意思问？他们派我来追捕你，同样可以派别人来！"
    translate None chapter_seven_0003:
        rs "可他很友善啊！我相信只要告诉他—"
    translate None chapter_seven_0004:
        l "要我说多少遍你才能明白，你太容易轻信别人了？！再这样下去你会送命的！"
    show raen n ang with dis
    translate None chapter_seven_0005:
        rs "但我们来自哪里真的很重要吗？！"
    show fawn n sad with dis
    translate None chapter_seven_0006:
        l "你知道找到你有多简单吗？要是其他人来找你也一样容易！你简直是在给我们留下指路的面包屑！"
    translate None chapter_seven_0007:
        f "呃…各位…"
    translate None chapter_seven_0008:
        rs "那就让他们来啊！对别人保持一点信任有什么错！"
    translate None chapter_seven_0009:
        l "你简直天真得可怕。你几岁了？十岁吗？该不会以为靠友谊和信任就能解决所有问题吧！"
    translate None chapter_seven_0010:
        rs "你完全是个自大狂！你觉得对的事不一定就是对的！"
    translate None chapter_seven_0011:
        f "你们…大家都在看…"
    translate None chapter_seven_0012:
        l "要不是我这个\"自大狂\"，你早就死在森林里了！"
    translate None chapter_seven_0013:
        rs "你可是被雇来杀我的！这有什么好炫耀的！"
    show fawn n hur with dis
    translate None chapter_seven_0014:
        f "喂！！！"
    translate None chapter_seven_0015:
        rl "啊？"
    translate None chapter_seven_0016:
        f "所有人都在看着…别吵了！"
    show raen n sad with dis
    translate None chapter_seven_0017:
        rs "噢….抱歉，福恩。"
    translate None chapter_seven_0018:
        u "就是他吧…？"
    translate None chapter_seven_0019:
        rs "嗯？"
    translate None chapter_seven_0020:
        "周围的人都用眼角余光打量我们。我原以为是因为我们吵架，但…"
    translate None chapter_seven_0021:
        u "那个有神之刻印的人？"
    show fawn n sad with dis
    translate None chapter_seven_0022:
        f "他们…在说你吗？"
    show leos n neu with dis
    translate None chapter_seven_0023:
        l "跟我来。"
    translate None chapter_seven_0024:
        "莱奥斯拉着我们躲到视线死角，但仍能听见那群人的窃窃私语。"
    translate None chapter_seven_0025:
        u "你们觉得他被诅咒了吗？从来没人见过这种东西。"
    translate None chapter_seven_0026:
        u "谁知道呢？"
    translate None chapter_seven_0027:
        rs "怎么…他们怎么会知道？我一直都遮住的啊！"
    translate None chapter_seven_0028:
        rs "等等…昨晚…"
    translate None chapter_seven_0029:
        rs "可能…我卷起了袖子，完全没注意…"
    show leos n ang with dis
    translate None chapter_seven_0030:
        l "这就是我说的问题所在。你太冒失了。现在谁都瞒不住了。"
    translate None chapter_seven_0031:
        l "从没见过像你这样毫无危机意识的人。"
    translate None chapter_seven_0032:
        f "那个…但他们看起来并不了解具体情况…"
    translate None chapter_seven_0033:
        l "所以呢？有人问起时他们照样会说出去。"
    translate None chapter_seven_0034:
        f "哦…"
    translate None chapter_seven_0035:
        rs "对不起…我不是故意—"
    translate None chapter_seven_0036:
        l "算了。赶紧离开这里。"
    translate None chapter_seven_0037:
        rs "好吧……"
    play music "sounds/bgm/Discovery.ogg" fadeout 2.0
    translate None chapter_seven_0038:
        "在路人指点下，我们往医者住所走去。不时有人用怪异的目光打量我。"
    translate None chapter_seven_0039:
        rs "....."
    translate None chapter_seven_0040:
        l "....."
    translate None chapter_seven_0041:
        rs "....."
    translate None chapter_seven_0042:
        l "....."
    translate None chapter_seven_0043:
        f "呃…."
    translate None chapter_seven_0044:
        f "今天…天气不错哈？"
    translate None chapter_seven_0045:
        l "....."
    translate None chapter_seven_0046:
        rs "....."
    translate None chapter_seven_0047:
        f "呃…"
    show raen n sur with dis
    translate None chapter_seven_0048:
        rs "啊！"

    show fawn n at farleft
    show raen n at cenleft
    show leos n at farright
    with move
    show cyne n sur at cenright with dis
    show cyne n at shake
    show raen n at shake

    translate None chapter_seven_0049:
        u "哇！！！"
    show cyne n hap with dis
    translate None chapter_seven_0050:
        cyneu "啊哈哈，对不起啊！"
    translate None chapter_seven_0051:
        rs "不，我刚才没看路…"
    translate None chapter_seven_0052:
        rs "是我的错。"
    translate None chapter_seven_0053:
        cyneu "哈哈，你说得对。再见！"

    hide cyne n with dissolve
    show fawn n at left
    show raen n at center
    show leos n at right
    with move
    translate None chapter_seven_0054:
        "然后他就消失了。"
    translate None chapter_seven_0055:
        rs "刚才发生了什么？"
    translate None chapter_seven_0056:
        f "那男孩简直像阵飓风…"
    show raen n sad with dis
    translate None chapter_seven_0057:
        rs "为什么我总是撞到人…？"
    show leos n smi with dis
    translate None chapter_seven_0058:
        l "因为你不看路？"
    translate None chapter_seven_0059:
        rs "我有看…"
    translate None chapter_seven_0060:
        l "那就不会撞到人了。"
    translate None chapter_seven_0061:
        rs "随你便。"
    translate None chapter_seven_0062:
        rs "应该快到了，我们继续走吧。"

    window hide

    scene black with w19
    pause(0.3)
    scene bg stagwich day with w19
    window show dissolve
    translate None chapter_seven_0063:
        "经过短暂寻找，我们终于找到了治疗师。路边有个红金相间的小帐篷，入口处斜倚着一块木牌。"
    translate None chapter_seven_0064:
        "按尼科斯的说法，我们以为会找到医院，而不是路边摊位…"

    show raen n neu at center
    show fawn n neu at left
    show leos n neu at right
    with dis
    translate None chapter_seven_0065:
        rs "看来就是这里。"
    translate None chapter_seven_0066:
        "我正要掀开帘子，但莱奥斯拦住了我。"
    translate None chapter_seven_0067:
        l "不用拉着我的手。我自己能进去。"

    window hide


    menu:
        "那今天我和福恩在镇上转转":
            $ fawn_relationship +=1
            window show dissolve
            jump fawn_town

        "我应该和莱奥斯一起进去":
            $ leos_relationship +=1
            window show dissolve
            jump doctor_leos

label fawn_town:
    translate None chapter_seven_0068:
        rs "好吧…既然你坚持。那我和福恩去镇上其他地方看看。"
    translate None chapter_seven_0069:
        rs "我们在旅馆会合？"
    translate None chapter_seven_0070:
        l "如果你运气好的话。"

    hide leos n with dissolve
    show fawn n at slightleft
    show raen n at slightright
    with move

    translate None chapter_seven_0071:
        "莱奥斯钻进帐篷，留下我和福恩独处。"
    show raen n sad with dis
    translate None chapter_seven_0072:
        rs "…他今天脾气真差，对吧？"
    translate None chapter_seven_0073:
        rs "不知道他要多久，我们不如先去转转。"
    translate None chapter_seven_0074:
        rs "有想去的地方吗？"
    translate None chapter_seven_0075:
        f "呃…那个…"
    translate None chapter_seven_0076:
        f "…我在想…能不能…去海边？"
    translate None chapter_seven_0077:
        f "我从来没去过…"
    show raen n smi with dis
    translate None chapter_seven_0078:
        rs "哇哦！"
    translate None chapter_seven_0079:
        rs "我也没去过！走吧！"
    translate None chapter_seven_0080:
        rs "路上可以顺便逛逛镇上其他地方。"
    translate None chapter_seven_0081:
        rs "我刚向尼科斯问了去海滩的路，应该不难找。"


    scene bg stagwich day with dissolve:
        xpos 0.5 ypos 1.0 xanchor 0.55 yanchor 0.54 zoom 2.0

    translate None chapter_seven_0082:
        "我们离开治疗师，穿过熙攘的街道。和昨晚相比，氛围完全不同。"
    translate None chapter_seven_0083:
        "人们往来穿梭，交谈拥抱。孩子们在街上玩耍，摊贩卖着各式商品。"
    translate None chapter_seven_0084:
        "所有人都在微笑，享受着清晨阳光。"
    translate None chapter_seven_0085:
        rs smi "看看这些卖的东西…"
    translate None chapter_seven_0086:
        rs neu "真希望我有钱买点什么。"
    translate None chapter_seven_0087:
        rs sur "等等，福恩？"
    translate None chapter_seven_0088:
        "他不见了。我扫视人群，却找不到他。"
    translate None chapter_seven_0089:
        f smi "雷恩！这边！"
    translate None chapter_seven_0090:
        "福恩在某个摊位旁向我招手。我小跑着追上他。"
    translate None chapter_seven_0091:
        rs sur "你在这！我正担心你呢。"
    translate None chapter_seven_0092:
        rs smi "你发现什么了？"
    translate None chapter_seven_0093:
        f smiclo "看啊！看看这些多神奇！"
    translate None chapter_seven_0094:
        "摊位上一排排摆满了精美的艺术品和小玩意。整个场景就像是福恩的树屋被浓缩在一张小桌子上。"
    translate None chapter_seven_0095:
        "真希望能给他买点什么。他肯定会很喜欢的。"
    translate None chapter_seven_0096:
        rs smi "真美啊…."
    translate None chapter_seven_0097:
        rs sur "咦，这些是什么？"
    translate None chapter_seven_0098:
        f smi "是贝壳。"
    translate None chapter_seven_0099:
        "福恩睁大眼睛，带着灿烂的笑容轻轻触碰它们。这里每样东西都是他喜欢的类型。"
    translate None chapter_seven_0100:
        rs sad "确实很美…"
    translate None chapter_seven_0101:
        rs neu  "走吧，我们继续逛。回来时它们肯定还在的。"
    translate None chapter_seven_0102:
        f sad "噢，抱歉…"
    translate None chapter_seven_0103:
        "我轻轻把他从摊位拉开，但能感觉到他的目光还黏在那里。肯定有什么我能做的…"

    window hide dissolve

    scene bg beach with dissolve:
        size (1920, 1080) crop (0, 290, 1330, 789)
        linear 35.0 crop (550, 290, 1330, 789)
    window show dissolve
    translate None chapter_seven_0104:
        "没走多远就来到被极力推荐的那片海滩。辽阔的白色沙滩，海水轻轻拍打着岸线。"
    translate None chapter_seven_0105:
        "阳光在水面跃动，如宝石般闪烁。"
    translate None chapter_seven_0106:
        "微风拂过福恩的发丝，他将一绺头发别到耳后。"

    scene bg beach with dissolve
    show raen n sur at slightright
    show fawn n hap at slightleft
    with dissolve
    translate None chapter_seven_0107:
        rs "哇…"
    translate None chapter_seven_0108:
        rs "从没见过这样的景色…"
    translate None chapter_seven_0109:
        f "真的吗？"
    translate None chapter_seven_0110:
        f "等等…森林深处确实不太会有海滩对吧？难怪你不知道。"
    translate None chapter_seven_0111:
        f "在我…"
    translate None chapter_seven_0112:
        f "我是说，在住进森林前，我也住在远离海岸的地方，所以这也是我第一次见。"
    show fawn n smi with dis
    translate None chapter_seven_0113:
        f "一直很想看看海滩。"
    translate None chapter_seven_0114:
        rs "这海水就像没有尽头…比我能看到的还要远！"
    translate None chapter_seven_0115:
        "我坐下来让沙子从指间流过。"
    translate None chapter_seven_0116:
        f "我们来堆沙堡吧！"
    translate None chapter_seven_0117:
        rs "沙堡？"
    translate None chapter_seven_0118:
        f "对啊！可以挖护城河，还能插旗子！"
    translate None chapter_seven_0119:
        "福恩在我旁边坐下，开始用手把沙子拢成堆。"
    translate None chapter_seven_0120:
        f "来，我教你。"
    translate None chapter_seven_0121:
        "他示意我坐到他身旁的位置。"

    show raen n at centerright
    show fawn n at centerleft
    with move
    translate None chapter_seven_0122:
        f "首先我觉得要…呃…堆成火山形状。"
    translate None chapter_seven_0123:
        rs "这样？"
    translate None chapter_seven_0124:
        f "不对不对，是这样。"
    translate None chapter_seven_0125:
        "福恩把手覆在我的手上引导着。"
    show raen n smi with dis
    translate None chapter_seven_0126:
        rs "哦！明白了！"
    translate None chapter_seven_0127:
        "我们保持这个姿势观察\"城堡\"—目前还只是个小沙堆。"
    translate None chapter_seven_0128:
        "迎着清凉的海风，福恩的手掌格外温暖。"
    translate None chapter_seven_0129:
        rs "水边挺冷的对吧？不过你的手真暖和。"
    show fawn n sur with dis
    translate None chapter_seven_0130:
        f "啊！"
    show fawn n shy with dis
    translate None chapter_seven_0131:
        f "对-对不起…这已经是第二次…不小心…"
    translate None chapter_seven_0132:
        rs "哈哈哈。我不介意。"
    translate None chapter_seven_0133:
        f "呃…嗯…你看…"
    translate None chapter_seven_0134:
        f "那么…接下来我们要…小心地把表面拍平…"
    translate None chapter_seven_0135:
        f "现在可以把它塑造成更像城堡的样子。"
    translate None chapter_seven_0136:
        rs "我们能在这里加个塔吗？"
    translate None chapter_seven_0137:
        f "好啊！加个塔会很棒。"
    translate None chapter_seven_0138:
        f "然后你可以…呃…挖条护城河，如果你想的话…"
    translate None chapter_seven_0139:
        "我开始铲除城堡周围的沙子。整个构造真的开始成型了。"
    translate None chapter_seven_0140:
        rs "这看起来像座真正的城堡，你真是天生的建筑师！"
    translate None chapter_seven_0141:
        rs "但是，嗯…我想这部分我还需要点帮助。你能再示范一次吗？"
    translate None chapter_seven_0142:
        f "再-示范？"
    translate None chapter_seven_0143:
        rs "像刚才那样？"
    translate None chapter_seven_0144:
        f "噢..嗯..我是说…好吧…"
    translate None chapter_seven_0145:
        "他把手再次覆在我的手上，教我应该怎么做。"
    translate None chapter_seven_0146:
        "为什么我还要请求帮助？这又不难。"
    translate None chapter_seven_0147:
        "不知为何，我就是想让他再做一次。或许只是因为天气开始变凉了。他手掌覆在我手上的感觉很温暖。"
    translate None chapter_seven_0148:
        f "要像这样做…"
    translate None chapter_seven_0149:
        f "呃…"
    show fawn n hur with dis
    translate None chapter_seven_0150:
        f "我去…找根能当旗杆的树枝，你在这等着！"

    hide fawn n with dissolve
    show raen n at center with move
    show raen n sur with dis

    translate None chapter_seven_0151:
        rs "等等-"
    translate None chapter_seven_0152:
        "好吧，他跑掉了。"
    translate None chapter_seven_0153:
        rs "嗯…"
    translate None chapter_seven_0154:
        "不过这片海滩真的很美。"
    translate None chapter_seven_0155:
        rs "啊！"
    translate None chapter_seven_0156:
        "这些就是之前福恩在看的那些东西！贝壳！"
    translate None chapter_seven_0157:
        "我仔细挑选着。如果能给他挑一个，他应该不会为之前错过购买而难过。"
    translate None chapter_seven_0158:
        "但是选哪个呢…."
    translate None chapter_seven_0159:
        "一枚淡蓝色的小贝壳吸引了我的目光。它有点像他的发色，简直完美。"
    translate None chapter_seven_0160:
        "我快速赶回我们的城堡。"


    show raen n at slightright with move
    show fawn n shy at slightleft with dissolve

    translate None chapter_seven_0161:
        f "…我回来了。找到根很棒的树枝可以当旗杆。"
    show raen n neu with dis
    translate None chapter_seven_0162:
        "我把贝壳藏在身后，走过去帮他。"
    translate None chapter_seven_0163:
        f "只要把它插在顶端，我们就大功告成了。"
    show fawn n smi with dis
    translate None chapter_seven_0164:
        f "准备—"

    show fawn n sur
    show raen n sur
    with dis

    translate None chapter_seven_0165:
        f "啊！！"
    translate None chapter_seven_0166:
        rs "哇啊！"
    translate None chapter_seven_0167:
        "他刚把树枝插上去，整个建筑就垮塌进了护城河。 "
    translate None chapter_seven_0168:
        "肯定是我搞砸了…我把护城河挖得太大了…"
    translate None chapter_seven_0169:
        "他生气了吗…？"
    show fawn n smi with dis
    translate None chapter_seven_0170:
        f "…啊哈哈哈！"
    show raen n smi with dis
    translate None chapter_seven_0171:
        rs "哈哈哈。"
    translate None chapter_seven_0172:
        f "真好玩！"
    translate None chapter_seven_0173:
        rs "是啊。托你的福，我玩得很开心。"
    translate None chapter_seven_0174:
        f "那个…雷恩.."
    translate None chapter_seven_0175:
        "他把手背在身后不安地扭动着。"


    scene bg beach with dissolve:
        size (1920, 1080) crop (0, 290, 1330, 789)
        linear 35.0 crop (550, 290, 1330, 789)

    translate None chapter_seven_0176:
        f shy "给，这个是送你的！"
    translate None chapter_seven_0177:
        "福恩拽过我的手摊开，将一枚粉色小贝壳放在我掌心。"
    translate None chapter_seven_0178:
        f "我知道你刚才…没能买到东西有点失落，所以！"
    translate None chapter_seven_0179:
        f "我想着…你知道的…或许能给你找到个更漂亮的…"
    translate None chapter_seven_0180:
        rs sur "......"
    translate None chapter_seven_0181:
        "这一次他没有回避，而是直视着我的眼睛。虽然脸还是红红的。"
    translate None chapter_seven_0182:
        rs "我……"
    translate None chapter_seven_0183:
        rs "其实我也给你找到了一个…"
    translate None chapter_seven_0184:
        rs "我还以为生气的人是你呢。"
    translate None chapter_seven_0185:
        "我把找到的蓝色小贝壳递给他，他用修长的手指轻轻捏着。"
    translate None chapter_seven_0186:
        "我们一起笑出声来。"
    translate None chapter_seven_0187:
        rs smi "我确实生气了，因为我很想给你找到贝壳。但现在这样更好。"
    translate None chapter_seven_0188:
        rs "谢谢你，福恩。我会永远珍藏它的。"
    translate None chapter_seven_0189:
        f "....."
    translate None chapter_seven_0190:
        f hap "我-我也是！"
    translate None chapter_seven_0191:
        f "我永远都不会弄丢它！"
    translate None chapter_seven_0192:
        "我看着掌心里的贝壳，小巧粉红，没有一丝裂缝，完美无瑕。"
    translate None chapter_seven_0193:
        rs "这个做成项链一定很好看。"
    translate None chapter_seven_0194:
        f sur "...!"
    translate None chapter_seven_0195:
        f shy "你的…你的也是…"
    translate None chapter_seven_0196:
        "他把脸埋在手掌里，从指缝间挤出含糊的声音。 "
    translate None chapter_seven_0197:
        "我小心地把贝壳收进口袋，起身拍了拍裤子上的沙粒。"
    translate None chapter_seven_0198:
        "当我伸手拉他起来时，福恩轻轻握住了我的手。"

    window hide dissolve

    scene bg beach with dissolve
    window show dissolve
    show fawn n shy at slightleft
    show raen n smi at slightright
    with dis
    translate None chapter_seven_0199:
        rs "该回去了，莱奥斯现在应该忙完了。"
    translate None chapter_seven_0200:
        rs "不过还是要谢谢你，福恩。很高兴今天我们来了这里。经历了这么多事…能休息下真好。"
    translate None chapter_seven_0201:
        f "我也是…"
    translate None chapter_seven_0202:
        rs "走吧。"

    stop music fadeout 2.0
    window hide dissolve

    scene bg tavern with dissolve
    window show dissolve
    translate None chapter_seven_0203:
        "我们回来时，莱奥斯正翘着腿靠坐在椅子上。酒馆里除他之外空无一人。"

    show raen n neu at center
    show leos n neu at right
    show fawn n neu at left
    with dis

    translate None chapter_seven_0204:
        l "怎么这么久？"
    translate None chapter_seven_0205:
        rs "我们只是…去了趟海边？"
    translate None chapter_seven_0206:
        l "海边？认真的？"
    translate None chapter_seven_0207:
        l "..算了。你们爱干嘛干嘛。"
    translate None chapter_seven_0208:
        "我和福恩在他旁边坐下。"
    translate None chapter_seven_0209:
        rs "治疗师怎么说？"
    translate None chapter_seven_0210:
        l "..说我要死了。"
    show raen n sur with dis
    translate None chapter_seven_0211:
        rs "什么？！"
    translate None chapter_seven_0212:
        l "...."
    show leos n smi with dis
    translate None chapter_seven_0213:
        l "..哈。"
    show raen n sad with dis
    translate None chapter_seven_0214:
        rs "这一点都不好笑…"
    translate None chapter_seven_0215:
        l "我没事。他们只说让我多休息。"
    translate None chapter_seven_0216:
        "他在瞒着我什么吗…？我真的搞不懂了。"
    translate None chapter_seven_0217:
        rs "好吧…"
    jump choice_eleven_done


label doctor_leos:
    translate None chapter_seven_0218:
        rs "别自作主张了。要是你伤得很重，我会愧疚死的…去检查下总行吧？"
    translate None chapter_seven_0219:
        l "....."
    translate None chapter_seven_0220:
        rs "反正你也拦不住我。就算你拒绝，我也会跟进诊所。"
    translate None chapter_seven_0221:
        l "真固执。"
    translate None chapter_seven_0222:
        l "那快点跟上。"

    hide leos n with dissolve
    show fawn n at slightleft
    show raen n at slightright
    with move

    translate None chapter_seven_0223:
        "说完莱奥斯就钻进了帐篷，留下我和福恩在外面。"
    show raen n sad with dis
    translate None chapter_seven_0224:
        rs "我得跟进去。没人盯着的话，他肯定不会乖乖遵医嘱。"
    translate None chapter_seven_0225:
        rs "等会儿酒馆见？"
    show fawn n sad with dis
    translate None chapter_seven_0226:
        f "..哦…呃，好…"
    translate None chapter_seven_0227:
        rs "应该不会太久。待会儿见，福恩。"
    translate None chapter_seven_0228:
        f "……嗯。"
    translate None chapter_seven_0229:
        "把他一个人留在那儿让我有些过意不去，不过我估计他也不愿意被关在那种地方。"
    window hide dissolve

    scene bg tent with dissolve:
        xpos 0.78 ypos 1.21 xanchor 0.5 yanchor 1.0 zoom 1.61
        linear 30.0 xpos 0.23 ypos 1.21 xanchor 0.5 yanchor 1.0 zoom 1.61
    window show dissolve
    translate None chapter_seven_0230:
        "我拨开厚重的门帘，跟随莱奥斯走进屋内。"
    play music "sounds/bgm/night.ogg" fadeout 2.0
    translate None chapter_seven_0231:
        "入口处一位年轻女子跪坐在大型圆水盆前，手指在水面轻盈舞动。注意到莱奥斯时，她平静地抬头注视。"
    translate None chapter_seven_0232:
        "我赶紧跟上他，竖耳倾听他们的对话。"

    scene bg tent with dissolve
    show raen n neu at slightleft
    show leos n neu at slightright
    with dis
    translate None chapter_seven_0233:
        w "……今天我们的治疗师不算太忙。稍等片刻，我去看看哪位能接诊。"
    show leos n smi with dis
    translate None chapter_seven_0234:
        l "好啊，我最爱干坐着等了。"
    translate None chapter_seven_0235:
        "她上下打量我一番，随即起身拉开通往内室的另一道布帘。"
    translate None chapter_seven_0236:
        "经过时，她对我露出亲切的微笑。"
    translate None chapter_seven_0237:
        "隔着布幔低声交代几句后，她再次来到我们面前。"
    translate None chapter_seven_0238:
        w "这位是朋友？"
    show leos n neu with dis
    translate None chapter_seven_0239:
        l "朋友？不算。"
    translate None chapter_seven_0240:
        l "顶多算个熟人。这么说都勉强。"
    show raen n sad with dis
    translate None chapter_seven_0241:
        rs "....."
    translate None chapter_seven_0242:
        "可能他还在为先前的事生气……"
    translate None chapter_seven_0243:
        w "明白了。刚与首席治疗师通过话，她马上就有空。"
    translate None chapter_seven_0244:
        "莱奥斯一言不发转身走到远离我的位置坐下。"
    translate None chapter_seven_0245:
        "我跟过去，厚着脸皮站在能靠近的最近距离。"
    translate None chapter_seven_0246:
        rs "......"
    translate None chapter_seven_0247:
        "唔，气氛真僵。"
    translate None chapter_seven_0248:
        rs "......"
    translate None chapter_seven_0249:
        l "......."
    translate None chapter_seven_0250:
        rs "那个……莱奥斯？"
    translate None chapter_seven_0251:
        l "又怎么了？"
    translate None chapter_seven_0252:
        rs "之前的事我真的很抱歉…我不是有意让你心……"
    translate None chapter_seven_0253:
        l "我没心烦。好吧，是有点不爽。"
    show leos n smi with dis
    translate None chapter_seven_0254:
        l "就想问问，你是真蠢吗？要是给傻子评级，你觉得自己能排第几档？"
    translate None chapter_seven_0255:
        rs "什么？才不是！"
    translate None chapter_seven_0256:
        l "装得倒挺像。"
    translate None chapter_seven_0257:
        rs "这么说也太伤人了吧……"
    show leos n pen with dis
    translate None chapter_seven_0258:
        l "我本来就不是什么善茬。别幻想些不存在的东西。"
    translate None chapter_seven_0259:
        rs "听我说，真的很抱……"
    translate None chapter_seven_0260:
        u "请随我来。"
    translate None chapter_seven_0261:
        "待会儿必须好好道歉才行。虽说我们本来就不对付，但这样争执实在没意思……"
    translate None chapter_seven_0262:
        "眼下还是先确保他没事要紧。"
    translate None chapter_seven_0263:
        "我迟疑地跟在莱奥斯身后，等他发话让我在此等候。"
    show leos n neu with dis
    translate None chapter_seven_0264:
        l "赶紧完事走人，之后再商量下一步。"
    translate None chapter_seven_0265:
        l "这破地方我半分钟都不想多待。"
    translate None chapter_seven_0266:
        rs "好吧……"
    translate None chapter_seven_0267:
        "真摸不透他的心思。刚才还在吵架，转眼又像是对我的出现心怀感激……"
    translate None chapter_seven_0268:
        "可能是我的错觉，但他那样盯着我看时，感觉脸颊发烫。有点奇怪…"
    translate None chapter_seven_0269:
        "我们默默跟随医师穿过又一道厚帘。里面，她跪坐下来示意我们也照做。"
    translate None chapter_seven_0270:
        o "你是莱奥斯对吧？我叫奥莉安娜，是这里其他医师的负责人。"
    translate None chapter_seven_0271:
        l "呃嗯，好的，呃…很高兴认识你…"
    translate None chapter_seven_0272:
        o "这位是同伴吗？"
    translate None chapter_seven_0273:
        l "行吧，随你怎么说。能快点吗？"
    translate None chapter_seven_0274:
        rs "莱奥斯…拜托，礼貌点。抱歉，他只是—"
    translate None chapter_seven_0275:
        "莱奥斯对我挑起眉毛。"
    show raen n neu with dis
    translate None chapter_seven_0276:
        rs "…..最近几天确实很难熬。"
    translate None chapter_seven_0277:
        o "那我尽快处理。"
    translate None chapter_seven_0278:
        o "听说你几天前摔倒了？脚踝疼痛，还有些头晕，你觉得是撞到头引起的？"
    translate None chapter_seven_0279:
        "莱奥斯脑子转得真快。他肯定是当场编的谎。总不好随便告诉别人你放火烧了房子还引发爆炸吧。"
    translate None chapter_seven_0280:
        l "我是这么说的对吧？现在头痛头晕都好了。"
    translate None chapter_seven_0281:
        o "好消息。如果是头部撞击，持续眩晕才需要担心。"
    translate None chapter_seven_0282:
        "她取出各种草药合剂，递给莱奥斯服用。他毫无怨言地一一喝下。"
    translate None chapter_seven_0283:
        "她检查体温和瞳孔，在头部与喉咙处涂抹药膏。这里的医师看起来和奥雷利亚卡维拉的截然不同。"
    translate None chapter_seven_0284:
        o "恢复情况不错。体温正常，瞳孔清澈。没什么可担心的。"
    translate None chapter_seven_0285:
        o "为保险起见，我再检查下脚踝。把腿伸直。"
    translate None chapter_seven_0286:
        o "哪里痛就说。"
    translate None chapter_seven_0287:
        "莱奥斯依言伸腿脱靴。"
    show leos n hur with dis
    translate None chapter_seven_0288:
        "奥莉安娜轻柔对比他双脚踝状况。莱奥斯不时因疼痛皱眉，但没明显到让她察觉。"
    translate None chapter_seven_0289:
        "但我注意到了。我紧盯着他的表情。"
    translate None chapter_seven_0290:
        "他似乎在隐瞒伤情。为什么？来看医师却要这样？"
    show raen n sur with dis
    translate None chapter_seven_0291:
        rs "嗯…应该是这里。"
    translate None chapter_seven_0292:
        "我把莱奥斯吃痛的位置指给她看。"
    translate None chapter_seven_0293:
        "莱奥斯…他看起来有一瞬间的惊讶，但很快就把脸转开了。"
    show leos n emb with dis
    translate None chapter_seven_0294:
        "他这是…在害羞吗？"
    translate None chapter_seven_0295:
        rs "就在这里。"
    translate None chapter_seven_0296:
        "我轻轻戳了戳他的脚踝，他倒吸一口冷气。"
    translate None chapter_seven_0297:
        rs "很疼对吧？"
    translate None chapter_seven_0298:
        l "….不疼。"
    show raen n ang with dis
    translate None chapter_seven_0299:
        rs "你能不能别这么固执了？"
    translate None chapter_seven_0300:
        rs "你或许不这么想，但我可不是傻子。你脸上的表情骗不了人。"
    translate None chapter_seven_0301:
        rs "就算你不想承认，伤处也得检查。既然你自己不帮忙，那就我来帮你。"
    translate None chapter_seven_0302:
        rs "而且你阻止不了我。所以-"
    translate None chapter_seven_0303:
        "我转向奥莉安娜。"
    translate None chapter_seven_0304:
        rs "请检查下他的脚踝，我们很快就不打扰了。"
    show raen n neu with dis
    translate None chapter_seven_0305:
        rs "….咳咳。"
    translate None chapter_seven_0306:
        o "…小姑娘，能遇到这个男孩是你运气好知道吗。"
    translate None chapter_seven_0307:
        l "是啦是啦，我真是走运。"
    translate None chapter_seven_0308:
        "后续的问诊他配合多了，认真回答问题表现得体。没过几分钟，莱奥斯就系好了靴带。"
    translate None chapter_seven_0309:
        o "这次算你走运。看起来只是扭伤，尽量多休息。"
    translate None chapter_seven_0310:
        o "应该很快就能好，但别给伤脚太大压力。"
    translate None chapter_seven_0311:
        "她起身为我们拉开帘子。"
    translate None chapter_seven_0312:
        o "很高兴见到你们。希望你们不必再来复诊，首次评估是免费的。祝早日康复。"
    show raen n smi with dis
    translate None chapter_seven_0313:
        rs "谢谢您，小姐。"
    translate None chapter_seven_0314:
        o "别客气。你可得好好看着他，替我盯着他养伤。"
    translate None chapter_seven_0315:
        rs "那当然！"
    translate None chapter_seven_0316:
        l "虽然很感谢…但我们现在能走了吗？"
    translate None chapter_seven_0317:
        "他有时就像个孩子。"
    translate None chapter_seven_0318:
        rs "…好好，再见，再次感谢。"
    translate None chapter_seven_0319:
        "走出帐篷时莱奥斯用手肘碰了碰我。"
    translate None chapter_seven_0320:
        "我转身看他，结果-"
    window hide

    scene bg stagwich day with dissolve:
        xpos 0.42 ypos 1.85 xanchor 0.5 yanchor 1.0 zoom 1.76
        linear 40.0 xpos 0.42 ypos 1.02 xanchor 0.5 yanchor 1.0 zoom 1.76
    window show dissolve
    translate None chapter_seven_0321:
        "他的视线在我和地面之间游移，轻轻揉了揉我的头发。"
    translate None chapter_seven_0322:
        l pen "....."
    translate None chapter_seven_0323:
        l "那个…谢了…"
    translate None chapter_seven_0324:
        l emb "但下不为例。"
    translate None chapter_seven_0325:
        rs sur "什-"
    translate None chapter_seven_0326:
        "他脸颊泛起了红晕。这不是我第一次见他举止反常，但绝对是最震撼的一次。"
    translate None chapter_seven_0327:
        rs "我没做什么特别的事…只是…"
    translate None chapter_seven_0328:
        rs "只是想确保你照顾好自己。忙着照顾别人时最容易忽略自己。"
    translate None chapter_seven_0329:
        l ang "我才没有照顾你！"
    translate None chapter_seven_0330:
        rs sur "可你确实在照顾我啊。不过也不用这么恼羞成怒…"
    translate None chapter_seven_0331:
        l ang "不是！我是说…哎.."
    translate None chapter_seven_0332:
        l emb "我不…我不介意…"
    translate None chapter_seven_0333:
        rs sur "你不介意？"
    translate None chapter_seven_0334:
        l emb "只是—别得寸进尺了，好吗？我不可能永远保护你。"
    translate None chapter_seven_0335:
        rs sur "为什么？你要去哪？"
    translate None chapter_seven_0336:
        l pen "不是说现在，白痴。是以后。"
    translate None chapter_seven_0337:
        "啊。"
    translate None chapter_seven_0338:
        "显然他不会永远待在这里。这只是个短期安排。"
    translate None chapter_seven_0339:
        "但还是…有点难受。我知道我们的初次见面不太愉快，但他已经保护我好几次了…"
    translate None chapter_seven_0340:
        "不过我也没指望他能永远陪着我，对吧？那样就太傻了。那为什么心里会有点疼？"
    translate None chapter_seven_0341:
        rs sad "…确实还是有点疼，对吗？"
    translate None chapter_seven_0342:
        "我指了指他的脚踝。"
    translate None chapter_seven_0343:
        l pen"….有点。没想到你会注意到。"
    translate None chapter_seven_0344:
        rs sad "我一直都在看着你的脸，所以马上就发现了。尽量别太勉强，好吗？"
    translate None chapter_seven_0345:
        rs "还有…真的，我为之前的事道歉。"
    translate None chapter_seven_0346:
        l neu "....."
    translate None chapter_seven_0347:
        "他直视着我的眼睛。这一次，我甚至看不到半点他平时那种自以为是的神色。"
    translate None chapter_seven_0348:
        rs emb "我-我们该…回去了吧。"
    translate None chapter_seven_0349:
        l pen "嗯…"
    translate None chapter_seven_0350:
        "他尴尬地把手从我头顶收回。趁他不注意时，我摸了摸刚才被他触碰的地方。那里还留着余温。"
    stop music fadeout 2.0
    window hide dissolve

    scene bg tavern with dissolve
    window show dissolve

    translate None chapter_seven_0351:
        "没过多久我们就回到了旅店，看见福恩独自坐在桌边。整个大厅空荡荡的。"
    translate None chapter_seven_0352:
        "我们走近时，他转身对我们笑了笑。"

    show leos n neu at right
    show raen n neu at center
    show fawn n hap at left
    with dis
    translate None chapter_seven_0353:
        f "…还顺利吗？"
    show leos n smi with dis
    translate None chapter_seven_0354:
        l "不，我快死了。"
    translate None chapter_seven_0355:
        l "小耗子，我的孩子们就拜托你了。"
    show fawn n hur with dis
    translate None chapter_seven_0356:
        f "什么？！"
    show raen n sad with dis
    translate None chapter_seven_0357:
        rs "别犯傻了。他没事，只是需要静养几天。"
    show fawn n neu with dis
    translate None chapter_seven_0358:
        rs "对吧？"
    translate None chapter_seven_0359:
        l "哈哈。"
    translate None chapter_seven_0360:
        l "好吧，随你怎么说。不过你破坏了我的乐趣。"
    translate None chapter_seven_0361:
        "莱奥斯拉出椅子坐在福恩旁边。我想我也该坐下。"

    jump choice_eleven_done

label choice_eleven_done:
    show raen n neu with dis
    play music "sounds/bgm/daytime.ogg" fadeout 2.0
    translate None chapter_seven_0362:
        "尼科斯不见踪影，旅店里只剩我们三人。窗外阳光正盛，偶有行人匆匆走过。"
    translate None chapter_seven_0363:
        rs "那么，我们接下来该怎么办？我们还能做什么？"
    show fawn n sad with dis
    translate None chapter_seven_0364:
        f "嗯…"
    translate None chapter_seven_0365:
        l "我们究竟有什么非做不可的事？不如就在这里安稳待上一阵子。"
    translate None chapter_seven_0366:
        l "我们无路可去。"
    translate None chapter_seven_0367:
        l "说真的，你所谓的\"我们\"是什么意思？我只是不得已才跟你们同行。没理由继续耗在这里。"
    show raen n sad with dis
    translate None chapter_seven_0368:
        rs "也是…"
    translate None chapter_seven_0369:
        rs "但你不能就这样独自逃走。你还能去哪里呢？"
    translate None chapter_seven_0370:
        f "呃…我们一直赖在这里会不会有点失礼？"
    translate None chapter_seven_0371:
        rs "不能永远指望尼科斯的好心…"


    translate None chapter_seven_0372:
        l "那你有什么建议？"
    translate None chapter_seven_0373:
        f "我不知道…"
    translate None chapter_seven_0374:
        l "那何必张嘴说废话？"
    translate None chapter_seven_0375:
        f "对不起…"
    translate None chapter_seven_0376:
        rs "目前来说-"
    play sound "sounds/sfx/dooropen.ogg" fadeout 1.0
    translate None chapter_seven_0377:
        u "卡斯？是你吗？"
    translate None chapter_seven_0378:
        "酒馆的门吱呀一声打开了。"
    show raen n sur with dis
    translate None chapter_seven_0379:
        rs "嗯？抱歉，我想你认错-"
    translate None chapter_seven_0380:
        u "卡斯皮安，真的是你！"
    translate None chapter_seven_0381:
        "等等，什么？"
    translate None chapter_seven_0382:
        u "你一点都没变老！多久没见了？"
    translate None chapter_seven_0383:
        "我从座位上抬起头。一位老者站在我们桌边，热切地注视着我的脸。"
    translate None chapter_seven_0384:
        "这个名字…我在哪…"
    translate None chapter_seven_0385:
        "曾经听过…"
    show fawn n sur with dis
    translate None chapter_seven_0386:
        f "呃..他不是-"
    translate None chapter_seven_0387:
        "没错！"
    show raen n smi with dis
    translate None chapter_seven_0388:
        rs "啊哈，确实！你觉得具体有多少年了？"
    show leos n sur with dis
    translate None chapter_seven_0389:
        "福恩和莱奥斯困惑地看了我一眼，但我没理会。如果是我猜的那样…"
    translate None chapter_seven_0390:
        u "少说也有十八九年了吧！"
    translate None chapter_seven_0391:
        u "什么风把你吹回这儿来了？"
    translate None chapter_seven_0392:
        rs "哦，你知道的，就是随便走走。"
    translate None chapter_seven_0393:
        rs "话说…"
    translate None chapter_seven_0394:
        rs "还记得我们上次见面吗？我这记性不太灵光了…我当时要去哪里来着？"
    translate None chapter_seven_0395:
        u "你还是老样子啊。你不是要去奥克斯哈伯吗？"
    translate None chapter_seven_0396:
        rs "当然，我怎么会忘记！"
    translate None chapter_seven_0397:
        u "总之，很高兴再见。如果你在这附近，改天聚聚。"
    translate None chapter_seven_0398:
        rs "哦..好啊！我会在镇上，有空再来。"
    translate None chapter_seven_0399:
        "老人转身离开，房间里一片寂静。"
    translate None chapter_seven_0400:
        l "刚才发生了什么…？"
    translate None chapter_seven_0401:
        f "…卡斯皮安？"
    show raen n sur with dis
    translate None chapter_seven_0402:
        rs "就是这个！"
    translate None chapter_seven_0403:
        "我从衣服里掏出那本书放在桌上让大家看。"
    translate None chapter_seven_0404:
        rs "他可能还活着！"
    show leos n neu with dis
    translate None chapter_seven_0405:
        l "你在说什么？慢点说清楚。"
    translate None chapter_seven_0406:
        rs "前几天提过，但从没想过给你们看这本书！"
    translate None chapter_seven_0407:
        rs "当我在言者档案馆时…发现很多书。直到现在才想起来，有本叫《锡德卡汉》。福恩，你说过这是这里的城市吧？"
    translate None chapter_seven_0408:
        rs "他为什么会有这种书？里面内容全被涂掉了。难道说书人真的知道这地方？"
    translate None chapter_seven_0409:
        rs "但更重要的是，我找到了这个。"
    translate None chapter_seven_0410:
        rs "看这个。完全吻合…但我看不懂内容。"
    translate None chapter_seven_0411:
        rs "前页的内容我倒是能读懂。这是某种血脉传承，我猜应该是王室…或者说，曾经的王室。"
    translate None chapter_seven_0412:
        rs "最后记载到\"卡斯皮安王子\"。日期是37年前。"
    translate None chapter_seven_0413:
        "福恩和莱奥斯凑近查看书本并听我自言自语。"
    translate None chapter_seven_0414:
        rs "根据莱奥斯之前的说法，我原以为他肯定已经死了，这让我很沮丧因为这是我唯一的线索…"
    translate None chapter_seven_0415:
        rs "但如果在18或19年前有人在这里见过他…"
    translate None chapter_seven_0416:
        rs "他可能还活着！"
    show leos n sur with dis
    translate None chapter_seven_0417:
        l "不过…他也是从奥雷利亚卡维拉来的。他怎么会知道来这里？"
    translate None chapter_seven_0418:
        rs "也许我们不是第一批离开的人…"
    translate None chapter_seven_0419:
        rs "之前你说他被认定死亡了。有没有可能他其实活着逃出来了？"
    translate None chapter_seven_0420:
        rs "然后来到这片森林外的第一个小镇？"
    translate None chapter_seven_0421:
        l "可是…他们告诉我…"
    translate None chapter_seven_0422:
        l "….确实有这个可能性。我没见过他的尸体。"
    translate None chapter_seven_0423:
        "没见过他的尸体？"
    translate None chapter_seven_0424:
        f "但…为什么会把你错认成他？"
    show raen n sad with dis
    translate None chapter_seven_0425:
        rs "我…我不知道。"
    translate None chapter_seven_0426:
        rs "可能我们长得像吧，但我不确定。也可能那只是个神志不清的老人。"
    translate None chapter_seven_0427:
        "我仔细想了想，就算我和他相像，在家乡也从没人提起过。"

    $ about_Caspian._text.append("种种迹象表明，他可能还活着。如果18或19年前卡斯皮安曾途经斯塔格威奇，而不是和其他家人遇难…他就是我唯一的希望。")
    translate None chapter_seven_0428:
        rs "{a=set_entry:enc_people->about_Caspian}{color=#87CEEB}卡斯皮安{/color}{/a}…他可能知道这些神之刻印的线索。我必须找到他。"
    translate None chapter_seven_0429:
        rs "但…我不会强迫你们俩跟我同行。我不能这么做。"
    translate None chapter_seven_0430:
        rs "我们已经共同经历了这么多。真是段难忘的旅程。"
    show leos n neu with dis
    translate None chapter_seven_0431:
        l "....."
    translate None chapter_seven_0432:
        l "我跟你一起去。"
    show fawn n neu with dis
    translate None chapter_seven_0433:
        f "我也是。"
    show raen n sur with dis
    translate None chapter_seven_0434:
        rs "什么？"
    translate None chapter_seven_0435:
        rs "我刚说-"
    translate None chapter_seven_0436:
        l "和你相处这么久，我很清楚单独行动你会轻易送命…说来遗憾，我还欠你人情呢。"
    translate None chapter_seven_0437:
        f "而且…我就是想跟你一起走。不想独自留在这里。"
    translate None chapter_seven_0438:
        rs "大家…"
    translate None chapter_seven_0439:
        rs "实在太感谢了…"
    show leos n smi with dis
    translate None chapter_seven_0440:
        l "等我阻止花小子把你煮来当晚餐后再谢我吧。"
    show fawn n hur with dis
    translate None chapter_seven_0441:
        f "什么？！我才不吃人！"
    translate None chapter_seven_0442:
        l "当然不吃。"
    translate None chapter_seven_0443:
        "他把目光重新移向我。"
    show leos n neu with dis
    stop music fadeout 2.0
    translate None chapter_seven_0444:
        l "真正的问题是…为什么你之前不告诉我这件事？"
    translate None chapter_seven_0445:
        l "你觉得保守秘密能帮你找到他吗？"
    translate None chapter_seven_0446:
        rs "一分钟前你还在说我太容易相信别人…"
    translate None chapter_seven_0447:
        "况且他还不知道全部情况。发生在福恩身上的那件怪事…"
    show fawn n sad with dis
    translate None chapter_seven_0448:
        f "呃…"
    translate None chapter_seven_0449:
        f "我听说过奥克斯哈伯…离这儿相当远。至少要走好几天路…"
    translate None chapter_seven_0450:
        l "如果不能步行的话，我们该怎么去那里？"

    show fawn n at farleft
    show raen n at cenleft
    show leos n at farright
    with move
    show nikos n lau at cenright with dis
    play music "sounds/bgm/tavern.ogg" fadeout 2.0

    translate None chapter_seven_0451:
        nik "或许你们可以搭个便车？"

    show fawn n sur
    show raen n sur
    show leos n ann
    with dis
    translate None chapter_seven_0452:
        fr "啊！！！"
    translate None chapter_seven_0453:
        nik "哎呀，不是故意吓你的。"
    translate None chapter_seven_0454:
        l "哦，看在老天的份上…不，你就是存心要吓他们的。"
    show raen n sad with dis
    translate None chapter_seven_0455:
        rs "你到底从哪儿突然冒出来的？！"
    show nikos n smi with dis
    translate None chapter_seven_0456:
        nik "刚才听见你们在说奥克斯哈伯，所以我想给你们个建议。"
    translate None chapter_seven_0457:
        nik "奥克斯哈伯的商贩经常带着他们的，呃…货物，在当地市集和后巷贩卖。"
    translate None chapter_seven_0458:
        nik "他们回去时马车都是空的。我保证只要你们好好请求，总有人愿意捎你们一程。"
    show raen n sur with dis
    translate None chapter_seven_0459:
        rs "这…这主意太棒了！"
    translate None chapter_seven_0460:
        rs "但你说\"在后巷\"是什么意思？"

    show nikos n con with dis
    $ about_Oxhabor.locked = False
    translate None chapter_seven_0461:
        nik "{a=set_entry:enc_places->about_Oxhabor}{color=#DA70D6}奥克斯哈伯{/color}{/a}以它的…嗯，玻璃著称。品质上乘，质地坚硬。所以他们有很多…来路不明的货。等你们到了那儿自然明白。"
    translate None chapter_seven_0462:
        rs "明白了…"
    show raen n neu with dis
    translate None chapter_seven_0463:
        rs "那我们在哪儿能找到他们？"
    show nikos n smi with dis
    translate None chapter_seven_0464:
        nik "往北走，镇子郊外有我们这儿的主要马厩。他们通常把马车停在那儿。只要四处打听，肯定能找到去奥克斯哈伯的人。"
    show raen n smi with dis
    translate None chapter_seven_0465:
        rs "那我们就去那儿。"
    translate None chapter_seven_0466:
        nik "还有…拿着这个。虽然不多，但这是你们昨晚应得的。"
    translate None chapter_seven_0467:
        "他递过来一个叮当作响的小袋子。"
    show leos n neu with dis
    translate None chapter_seven_0468:
        l "这个我来保管。我可信不过你不会再次被抢。"
    translate None chapter_seven_0469:
        "莱奥斯从我手里抢过钱袋。这样可能最稳妥。"
    translate None chapter_seven_0470:
        rs "尼科斯…谢谢。虽然不知道怎么做，但我一定会报答你的。"
    show nikos n lau with dis
    translate None chapter_seven_0471:
        nik "好啊。改天再来给我表演就行了。"
    translate None chapter_seven_0472:
        rs "当然！"
    translate None chapter_seven_0473:
        "我们向尼科斯最后道别。但愿有朝一日能报答这份恩情。"

    stop music fadeout 2.0
    window hide dissolve

    scene bg stagwich sunset
    show leos n sunset neu at right
    show fawn n sunset neu at left
    show raen n sunset neu at center
    with dissolve
    window show dissolve
    play music "sounds/bgm/Discovery.ogg" fadeout 2.0
    translate None chapter_seven_0474:
        l "所以…我们要一辆辆马车问过去，逐个询问车夫是否愿意让三个男人挤在后厢？"
    translate None chapter_seven_0475:
        f "我…猜是吧？"
    translate None chapter_seven_0476:
        rs "最坏的情况无非是被拒绝。"
    translate None chapter_seven_0477:
        l "我不信任你能管住自己的嘴。让我来交涉。"
    translate None chapter_seven_0478:
        "户外，随着夕阳西沉，空气渐渐转凉。鸟儿在附近树木的枝桠间跳跃，唱着动听的歌谣。"
    translate None chapter_seven_0479:
        "让我想起昨晚那个怪人，还有他的宠物鸟…"

    hide raen
    hide leos
    hide fawn
    with dis2


    translate None chapter_seven_0480:
        "我们向北行进，最终来到村庄的马厩区。那里停满各式车辆，从简陋的板车到豪华的厢式马车应有尽有。"
    translate None chapter_seven_0481:
        "有辆漆着金边的黑色马车特别引人注目，车身抛光得锃亮。可惜不见车夫踪影—何况这种显贵恐怕也不会让三个邋遢男人搭便车。"
    translate None chapter_seven_0482:
        "事实上，大多数车夫都不在场。马厩几乎空空荡荡，车辆大多无人看管。"
    translate None chapter_seven_0483:
        rs sur "附近有活人吗…？"
    translate None chapter_seven_0484:
        f neu "看…"
    translate None chapter_seven_0485:
        "福恩指向一堆木箱，上面坐着个抠指甲的壮汉。"
    translate None chapter_seven_0486:
        rs neu "我去—"
    translate None chapter_seven_0487:
        l neu "不是。"
    translate None chapter_seven_0488:
        "莱奥斯悄声走近，轻拍那人肩膀。"
    translate None chapter_seven_0489:
        l "我们在找去奥克斯哈伯的便车。您有线索吗？"
    translate None chapter_seven_0490:
        "对方沉默地瞪着莱奥斯，最终用下巴朝反方向努了努。"

    show lilas n neu sunset with dis3

    translate None chapter_seven_0491:
        "转身望去时，我不由愣住—有辆板车的驾驶座上坐着个头发蓬乱的女人，正出神地望着远方。"
    translate None chapter_seven_0492:
        "虽然莱奥斯叮嘱过我保持安静，但…"

    show lilas n at slightleft with move
    show raen n neu sunset at slightright with dissolve

    translate None chapter_seven_0493:
        rs "小姐您好？"
    translate None chapter_seven_0494:
        "她垂下沉甸甸的眼帘俯视我。"

    translate None chapter_seven_0495:
        u "有事？"
    translate None chapter_seven_0496:
        rs "我和朋友们…想去奥克斯哈伯，但不认得路。这是您的马车吗？"
    translate None chapter_seven_0497:
        "她的板车平平无奇，木质车身边缘略显粗糙，但很结实。后厢足够容纳我们三人。"
    show lilas n sunset ang with dis
    translate None chapter_seven_0498:
        u "去奥克斯哈伯？"
    translate None chapter_seven_0499:
        "她将我们挨个打量，目光最后又落回我身上。"
    translate None chapter_seven_0500:
        u "对，是我的车。"
    translate None chapter_seven_0501:
        u "你们去那儿干嘛？"
    translate None chapter_seven_0502:
        rs "找个人…一个朋友。"
    show lilas n sunset sad with dis
    translate None chapter_seven_0503:
        u "明白了…"
    translate None chapter_seven_0504:
        rs "...."
    translate None chapter_seven_0505:
        u "...."
    show raen n sunset sad with dis
    translate None chapter_seven_0506:
        rs "那个…您会去奥克斯哈伯吗？"
    translate None chapter_seven_0507:
        u "我？"
    translate None chapter_seven_0508:
        rs "呃…是的？"
    translate None chapter_seven_0509:
        u "会去。"
    translate None chapter_seven_0510:
        "这样绕圈子简直是浪费时间…"
    translate None chapter_seven_0511:
        f "那个…小姐…能让我们搭个便车吗？"
    show lilas n sunset neu with dis
    translate None chapter_seven_0512:
        u "我不是已经答应了吗？"
    translate None chapter_seven_0513:
        l "不，你并没有…"
    translate None chapter_seven_0514:
        l pis "这姑娘该不会是…"
    show raen n sunset ang with dis
    translate None chapter_seven_0515:
        rs "嘘！"
    show raen n sunset smi with dis
    translate None chapter_seven_0516:
        rs "谢谢！你们什么时候出发？"
    translate None chapter_seven_0517:
        u "..."
    translate None chapter_seven_0518:
        u "现在就走。"
    translate None chapter_seven_0519:
        "可能她只是有点害羞…"
    translate None chapter_seven_0520:
        rs "呃…那个…"
    show raen n sunset sad with dis
    translate None chapter_seven_0521:
        rs "我们直接…坐后面就行？"
    translate None chapter_seven_0522:
        u "请便。"
    translate None chapter_seven_0523:
        "我们跟着她爬进了后车厢。"
    window hide dissolve

    scene bg wagon sunset with dissolve
    show lilas n sunset neu with dissolve

    play music "sounds/bgm/night.ogg" fadeout 2.0

    window show dissolve
    translate None chapter_seven_0524:
        rs neu "到奥克斯哈伯要多久，小姐？"
    translate None chapter_seven_0525:
        "她背对着我们答道，同时挪动木桶和板条箱给我们腾位置。后面其实挺宽敞的。"
    translate None chapter_seven_0526:
        u "…半天。明天日出前能到。"
    translate None chapter_seven_0527:
        rs "明白了…真的感激不尽。"
    translate None chapter_seven_0528:
        u "....."
    translate None chapter_seven_0529:
        u "反正我也要回去了…"
    translate None chapter_seven_0530:
        f neu "呃…要不大家自我介绍一下？"
    translate None chapter_seven_0531:
        rs "好主意。"

    show lilas at cenleft with move
    show raen n sunset smi at cenright
    show fawn n sunset neu at farleft
    show leos n sunset neu at farright
    with dissolve


    translate None chapter_seven_0532:
        rs "我叫雷恩。"
    translate None chapter_seven_0533:
        l "非要叫的话，可以叫我莱奥斯。"
    translate None chapter_seven_0534:
        f "我是福恩…"
    translate None chapter_seven_0535:
        "她目光在福恩身上停留片刻才开口。"

    $ about_Lilas.locked = False
    translate None chapter_seven_0536:
        lil "我叫{a=set_entry:enc_people->about_Lilas}{color=#DA70D6}莱拉斯{/color}{/a}。说说看，你们从哪来？"

    if achievement.has("lilas_meet"):
        pass
    else:
        $ renpy.display_notify("成就解锁：搭便车")

    python:
        achievement.grant("lilas_meet")
        achievement.sync()
    show fawn n sunset sur
    show raen n neu
    with dis
    translate None chapter_seven_0537:
        f "我-我吗？"
    translate None chapter_seven_0538:
        f "我…我自己住…我是说…"
    translate None chapter_seven_0539:
        rs "他独居在离这儿不远的地方。"
    show lilas n sunset sur with dis
    translate None chapter_seven_0540:
        lil "真的吗？"
    translate None chapter_seven_0541:
        lil "你的长相让我想起一位顾客…去过克利夫斯派尔吗？"
    translate None chapter_seven_0542:
        f "...!"
    show fawn n sunset sad with dis
    translate None chapter_seven_0543:
        f "我..没，那个..我…"
    show raen n sunset sur with dis
    translate None chapter_seven_0544:
        "嗯？反应有点奇怪啊。"
    translate None chapter_seven_0545:
        "他支支吾吾说不出话，盯着地面。虽然平时也差不多这样，但…"
    translate None chapter_seven_0546:
        rs "你…"
    translate None chapter_seven_0547:
        rs "你肯定认错人了！他是土生土长的奥雷连。"
    show leos n sunset ang with dis
    translate None chapter_seven_0548:
        "莱奥斯扶额叹气。对不住啊莱奥斯！我总得想办法帮他解围…"
    show lilas n sunset neu with dis
    translate None chapter_seven_0549:
        lil "明白了…"
    translate None chapter_seven_0550:
        lil "好吧无所谓。多说说你们要找的那位朋友吧。"

    show raen n dim neu
    show fawn n dim sad
    show leos n dim neu
    show lilas n dim neu
    show bg wagon night
    with dis4
    translate None chapter_seven_0551:
        "此刻天色渐暗，星子开始在天幕上探头。"
    show raen n dim neu with dis
    translate None chapter_seven_0552:
        rs "我们找叫卡斯皮安的男人。很多年前他路过这一带。"
    translate None chapter_seven_0553:
        lil "卡斯皮安？"
    show lilas n dim sad with dis
    translate None chapter_seven_0554:
        lil "恐怕没听说过。奥克斯哈伯地方小，你们肯定能打听到消息。"
    translate None chapter_seven_0555:
        rs "你说你是做生意的对吧？"
    translate None chapter_seven_0556:
        "福恩望向莱拉斯。"
    translate None chapter_seven_0557:
        f "…那具体卖什么呢？"
    translate None chapter_seven_0558:
        lil "嗯？"

    show lilas n dim exc with dis
    $ about_Lilas._text.append("她在奥克斯哈伯开店，经常外出贩货。问及商品内容时，她回答\"幸福\"。")
    translate None chapter_seven_0559:
        lil "{a=set_entry:enc_people->about_Lilas}{color=#87CEEB}我将快乐贩卖{/color}{/a}至每个角落，但愿有朝一日能遍及更远之地。"
    translate None chapter_seven_0560:
        "这…真是个奇怪的描述。快乐？这可泛指任何东西。"
    translate None chapter_seven_0561:
        rs "明白了…"
    show lilas n dim neu with dis
    translate None chapter_seven_0562:
        lil "那我们该启程了。"

    scene bg wagon night with dissolve
    translate None chapter_seven_0563:
        "她跨入驾驶座，纤细手指握住缰绳。她轻抚那匹独马，马儿在她的触碰下发出嘶鸣。"
    translate None chapter_seven_0564:
        "只需轻轻一动，马匹便拉着马车缓缓穿行于街道。"
    translate None chapter_seven_0565:
        "斯塔格威奇各家各户的灯笼渐次亮起。没有什么比夜晚的小镇氛围更令人沉醉。"
    translate None chapter_seven_0566:
        rs sur "....?"
    translate None chapter_seven_0567:
        "那是什么声音-"
    translate None chapter_seven_0568:
        u "来了！"


    play sound "sounds/sfx/fallonground2.ogg" fadeout 1.0
    show layer master at vpunch
    show illran n dim neu at cenleft
    show bveras n dim tal:
        xpos 0.7 ypos 1.01 xanchor 1.11 yanchor 1.21
    with dis
    translate None chapter_seven_0569:
        "随着某人弹射般撞上货车后部，整个车厢都震颤起来。"

    show raen n dim sur at cenright
    show leos n dim sur at farright
    show fawn n dim sur at farleft
    with dissolve

    translate None chapter_seven_0570:
        rs "啊！"
    translate None chapter_seven_0571:
        l "......"
    translate None chapter_seven_0572:
        f "......"
    translate None chapter_seven_0573:
        rs "......"
    show illran n con dim with dis
    translate None chapter_seven_0574:
        gr "哟。"
    translate None chapter_seven_0575:
        lil neu "又一位朋友？"
    show leos n dim ann with dis
    translate None chapter_seven_0576:
        l "才不-"
    show illran n fli dim with dis
    show fawn n neu dim with dis
    translate None chapter_seven_0577:
        gr "我们可是最要好的朋友呢！请继续赶路吧。"
    translate None chapter_seven_0578:
        lil "如您所愿。"
    translate None chapter_seven_0579:
        l "噢该死的，现在又怎么了？昨天骚扰得还不够吗？"
    show illran n neu with dis
    translate None chapter_seven_0580:
        gr "嘿，我只是想搭车去奥克斯哈伯。肯定能再多载一个人吧？"
    show raen n neu dim with dis
    translate None chapter_seven_0581:
        rs "你也要去奥克斯哈伯？去干嘛？"
    translate None chapter_seven_0582:
        gr "啊哈，你知道的，观光旅行。我们是旅人。没听说过奥克萨博的玻璃匠人吗？"
    translate None chapter_seven_0583:
        l "真是绝配。一个疯男人和他的鸟，结伴周游世界。留着这只鸟是饿的时候当备用粮？"
    show illran n dim fli with dis
    translate None chapter_seven_0584:
        gr "这么快就了解我了呢。说得人家都不好意思了。"
    translate None chapter_seven_0585:
        l "呃…"

    show fawn n dim neu
    hide bveras
    show bveras n neu dim at cenleft:
        xpos 0.3 ypos 1.0 xanchor 0.32 yanchor 0.98
    with dis
    translate None chapter_seven_0586:
        "鸟儿维拉斯从他头顶跳到肩膀，一路叽叽喳喳。"
    translate None chapter_seven_0587:
        l "我真的要和这个家伙在密闭空间里待到明天吗？我宁可走路。"
    translate None chapter_seven_0588:
        gr "那就有更多空间给我咯。"
    show raen n dim sad with dis
    translate None chapter_seven_0589:
        rs "没事的，莱奥斯…"
    translate None chapter_seven_0590:
        "我用胳膊肘轻轻碰他，凑近耳边低语。"
    translate None chapter_seven_0591:
        rs "就一晚上而已。"
    translate None chapter_seven_0592:
        gr "昨晚我们也没机会好好聊。这可是相互了解的好机会。"
    translate None chapter_seven_0593:
        rs "那么，你可以先好好做个自我介绍。"
    show illran n dim armsdown hap with dis
    translate None chapter_seven_0594:
        gr "没听说吗？我现在叫狐狸。"
    show illran n con dim with dis
    translate None chapter_seven_0595:
        "男子的目光转向肩头，他的鸟正轻啄着他。他迅速将视线移回我身上。"
    translate None chapter_seven_0596:
        gr "其实我有点好奇…"
    show illran n neu dim with dis
    translate None chapter_seven_0597:
        gr "前几天有只小鸟告诉我，斯塔格威奇浓烟弥漫。好像是附近森林起了火。你们看到了吗？"
    show raen n dim sur with dis
    translate None chapter_seven_0598:
        rs "那场火灾？从这里都能看见？"
    show illran n con dim with dis
    translate None chapter_seven_0599:
        gr "哦？你们当时离得更近？"
    translate None chapter_seven_0600:
        rs "是啊，我—"
    translate None chapter_seven_0601:
        "莱奥斯突然伸手捂住我的嘴"
    translate None chapter_seven_0602:
        gr "唔…像你们这样正派的团队肯定不会与此事有关，对吧？"
    show fawn n dim hur with dis
    translate None chapter_seven_0603:
        f "当…当然无关！"
    show illran n fli dim with dis
    translate None chapter_seven_0604:
        "他对着我们露出坏笑"
    show fawn n dim sad with dis
    translate None chapter_seven_0605:
        gr "当然无关。你们只是碰巧第二天才抵达对吧？"
    translate None chapter_seven_0606:
        rs "你怎么—"
    translate None chapter_seven_0607:
        gr "至少我很高兴能听到行走的万花筒献唱呢。噢，多么动人的嗓音，光是这个就值得专程跑来斯塔格威奇一趟"
    show raen n dim sad with dis
    translate None chapter_seven_0608:
        rs "...."
    translate None chapter_seven_0609:
        "那只鸟又啄了他一下，男人回头瞥了眼。这是它表达亲热的方式吗？可能想被摸摸头"
    translate None chapter_seven_0610:
        "注意到我的视线，绿发男子用指尖轻抚过鸟儿的头顶，它立刻安静下来"
    show illran n neu dim with dis
    translate None chapter_seven_0611:
        gr "说起来，我在镇上还听到些古怪传闻。关于半夜出现的诅咒之子"
    translate None chapter_seven_0612:
        gr "不过斯塔格威奇居民的见识能有多广呢？都是些单纯的人。稍微反常的事物，就会被称为诅咒或恶魔"
    translate None chapter_seven_0613:
        "他紧紧盯着我打量"
    translate None chapter_seven_0614:
        gr "森林中心的火灾，斯塔格威奇小镇出现的诅咒之子…我在想，这两件事会不会有关联？"
    show raen n dim wor with dis
    translate None chapter_seven_0615:
        rs "我…我不知道你为何问我这些。我完全不了解"
    show illran n fli armsup dim with dis
    translate None chapter_seven_0616:
        gr "噢，别在意。我只是自言自语"
    scene bg wagon night with dissolve
    translate None chapter_seven_0617:
        "这家伙让我浑身发毛。表面友善，却像在暗中谋求什么…很是可疑…"
    translate None chapter_seven_0618:
        gr con "放轻松，我是朋友嘛。不必这么紧张"
    translate None chapter_seven_0619:
        gr "我可是本打开的书。随便问，没有我不知道的事"
    translate None chapter_seven_0620:
        l neu "没有？你能狂妄到什么程度"
    translate None chapter_seven_0621:
        "这话从他嘴里说出来真讽刺。不过…这或许是个好机会"

    scene bg wagon night with dis2:
        xpos 0.5 ypos 1.0 xanchor 0.65 yanchor 0.65 zoom 1.5
        linear 45.0 xanchor 0.35
        pause 2.0
        linear 45.0 xanchor 0.65
        pause 2.0
        repeat
    jump choice_illran

label choice_illran:
    window hide
    menu:
        "关于奥克斯哈伯你知道多少？" if illran_oxhabor:
            $ illran_oxhabor = False
            $ illran_stop = True
            $ illran_fin += 1
            $ illranveras_friend += 1
            jump illran_oxhabor

        "你和维拉斯怎么认识的？" if illran_veras:
            $ illran_veras = False
            $ illran_stop = True
            $ illran_fin += 1
            $ illranveras_friend += 1
            jump illran_meet

        "你谈过恋爱吗？" if illran_love:
            $ illran_love = False
            $ illran_stop = True
            $ illran_fin += 1
            $ illranveras_friend += 1
            jump illran_love

        "我听够了" if illran_stop:
            window show dissolve
            jump choice_twelve_done

label illran_oxhabor:
    window show dissolve
    translate None chapter_seven_0622:
        rs neu "你去过奥克斯哈伯吗？"
    translate None chapter_seven_0623:
        gr con "就去过一次"
    translate None chapter_seven_0624:
        rs "知道那里的情况吗？"
    translate None chapter_seven_0625:
        gr neu "嗯…最近百年来基本由穆拉诺家族掌控"
    translate None chapter_seven_0626:
        gr neu "名义上不算统治者，但他们垄断玻璃产业。其他人都得仰其鼻息"
    translate None chapter_seven_0627:
        rs sur "玻璃产业？"
    translate None chapter_seven_0628:
        "尼科斯也提到过这个"
    translate None chapter_seven_0629:
        gr con "当穆拉诺家族到来时，奥克萨博玻璃极其稀有，只有富人能负担得起。他们牢牢抓住这个商机，将玻璃带给了普通大众。"
    translate None chapter_seven_0630:
        gr con "他们购置土地和重型设备，并资助其他已有企业。基本上把整片地区都买下来了。"
    translate None chapter_seven_0631:
        gr con "他们不再使用斯塔格威奇和附近海滩的沙子，转从海外各国进口。据说那里的沙子取之不尽，不过我未曾亲眼证实。"
    translate None chapter_seven_0632:
        gr neu "有点蹊跷。他们刚来时就已经富可敌国。这些人究竟从哪儿冒出来的？"
    translate None chapter_seven_0633:
        lil neu "…您真是见多识广，先生。"

    $ about_Oxhabor._text.append("据传奥克萨博主要由100年前来此的穆拉诺家族掌控。他们买下整片区域垄断了玻璃产业，如今几乎涉足奥克萨博所有行业。")
    translate None chapter_seven_0634:
        "这真是{a=set_entry:enc_places->about_Oxhabor}{color=#87CEEB}异常详尽的回答{/color}{/a}…没想到他这么认真。"
    translate None chapter_seven_0635:
        gr con "现在他们把玻璃出口到整个维迪斯地区。最远卖到锡德卡汉。"
    translate None chapter_seven_0636:
        gr neu "我已回答你的问题，现在轮到我提问了。"
    translate None chapter_seven_0637:
        gr con "像你们这样性格迥异的一群人是如何相识的？"
    translate None chapter_seven_0638:
        "我看了看莱奥斯和福恩。我们怎么认识的…？"
    translate None chapter_seven_0639:
        rs sad "呃…那个…"
    translate None chapter_seven_0640:
        "快想啊…"
    translate None chapter_seven_0641:
        rs neu "我是在…启程前往斯塔格威奇时遇见福恩的。阴差阳错他就决定加入了，对吧？"
    translate None chapter_seven_0642:
        f neu "…对。"
    translate None chapter_seven_0643:
        gr con "那雷德呢？"
    translate None chapter_seven_0644:
        rs neu "莱奥斯？他…"
    translate None chapter_seven_0645:
        l neu "…我就是来当保镖的。只要钱给够，我什么都干。"
    translate None chapter_seven_0646:
        gr fli "哦？那我记住了。"
    if illran_fin == 3:
        jump choice_twelve_done
    jump choice_illran

label illran_meet:
    window show dissolve
    translate None chapter_seven_0647:
        rs neu "其实我也有点好奇。"
    translate None chapter_seven_0648:
        rs sur "你的鸟叫维拉斯对吗？从哪儿找到的？"
    translate None chapter_seven_0649:
        gr sad "找他？是他找到我的。"
    translate None chapter_seven_0650:
        gr con "说实话，没人能抵挡我的魅力。我甚至不需要开口就—"
    show layer master at vpunch
    translate None chapter_seven_0651:
        gr flisweat "嗷！"
    translate None chapter_seven_0652:
        "鸟儿啄了他脖子，吓得他一激灵。"
    translate None chapter_seven_0653:
        gr con "好吧好吧，我也算是个音乐爱好者，会摆弄些乐器。"

    $ about_Veras._text.append("显然维拉斯是被绿发男子的魅力征服才跟来的，这事儿着实有点离奇。")
    translate None chapter_seven_0654:
        gr con "我每周会在户外演奏几次，注意到有只蓝色小鸟常来聆听。一来二去间，{a=set_entry:enc_people->about_Veras}{color=#87CEEB}维拉斯{/color}{/a}决定跟着我了。"
    translate None chapter_seven_0655:
        gr fli "被我的音乐而非魅力所吸引。"
    translate None chapter_seven_0656:
        f neu "吸引…？"
    translate None chapter_seven_0657:
        rs sad "野生动物通常都会—"
    translate None chapter_seven_0658:
        "哈，这和养着福恩其实没太大差别。"
    translate None chapter_seven_0659:
        f neu "我…我是想问…"
    translate None chapter_seven_0660:
        "他的眼睛又亮了起来。"
    translate None chapter_seven_0661:
        f sur "你能和动物交谈吗？！"
    translate None chapter_seven_0662:
        l neu "别犯傻了—"
    translate None chapter_seven_0663:
        gr neu "嗯…某种程度来说，确实。"
    translate None chapter_seven_0664:
        f sur "....!"
    translate None chapter_seven_0665:
        l ann "又来一个…"
    translate None chapter_seven_0666:
        gr con "既然你们问了我两个问题，我再问一个很公平吧？"
    translate None chapter_seven_0667:
        gr con "那么我的问题是—你们谁见过恶魔？"
    translate None chapter_seven_0668:
        rs sur "什…什么？"
    translate None chapter_seven_0669:
        gr neu "恶魔。看来你没见过。雷德？"
    translate None chapter_seven_0670:
        l neu "我有名字的。"
    translate None chapter_seven_0671:
        gr fli "莱奥斯？"
    translate None chapter_seven_0672:
        l ann "说实话，听你叫我名字更难受。"
    translate None chapter_seven_0673:
        gr con "你的答案？"
    translate None chapter_seven_0674:
        l neu "….从没听说过。"
    translate None chapter_seven_0675:
        gr neu "那就剩一位了。"
    translate None chapter_seven_0676:
        f sur "我-我吗？"
    translate None chapter_seven_0677:
        f sad "...."
    translate None chapter_seven_0678:
        "福恩在膝上攥紧了拳头。"
    translate None chapter_seven_0679:
        f sad "我应该没有…我是说…"
    translate None chapter_seven_0680:
        gr con "哦？有意思。最沉默寡言的人，最不可能的知情者？"
    translate None chapter_seven_0681:
        f sad "不-不是的，我只是…有次好像看见..某种恶魔…"
    translate None chapter_seven_0682:
        f sad "…恶魔真的都邪恶吗？"
    translate None chapter_seven_0683:
        gr con "这得由你自己判断。"
    translate None chapter_seven_0684:
        l ann "...."

    if illran_fin == 3:
        jump choice_twelve_done
    jump choice_illran

label illran_love:
    window show dissolve
    translate None chapter_seven_0685:
        "想到最近了解的新事物，我有个好奇的问题.."
    translate None chapter_seven_0686:
        rs sur "嗯…你恋爱过吗？"
    translate None chapter_seven_0687:
        gr sad "什么？"
    translate None chapter_seven_0688:
        f sad "现在不是讨论—"
    translate None chapter_seven_0689:
        gr sad "我是否恋爱过？这算什么问题？"
    translate None chapter_seven_0690:
        gr sad "你大可以问我任何事，却偏偏想知道这个？"
    translate None chapter_seven_0691:
        "我对他耸耸肩。"
    translate None chapter_seven_0692:
        rs neu "抱歉，刚才好像有人说会回答我的问题？"
    translate None chapter_seven_0693:
        gr neu "….年轻时确实和几个男人有过纠缠。算爱吗？当时自以为是吧。"
    translate None chapter_seven_0694:
        rs sur "自以为是？"
    translate None chapter_seven_0695:
        gr neu "那时候总会全身心扑在对方身上，但现在回想…大概只是欲望，或是害怕孤独。"
    translate None chapter_seven_0696:
        gr con "爱应该更深刻些。"
    translate None chapter_seven_0697:
        rs sur "是吗？能详细说说吗？"
    translate None chapter_seven_0698:
        "他对我挑眉，但还是继续开口。"
    translate None chapter_seven_0699:
        gr sad "老天，我干嘛要给小鬼头上感情课？"
    translate None chapter_seven_0700:
        gr neu "人们常把爱情描述成与伴侣相处融洽时，胸中涌起的那种幸福感受。"
    translate None chapter_seven_0701:
        gr neu "但其实远不止如此。"
    translate None chapter_seven_0702:
        gr con "爱情是在艰难时期依然选择坚守的承诺—无论是病痛缠身、意见相左，还是彼此做的所有蠢事。"
    translate None chapter_seven_0703:
        gr con "正是这些让感情历久弥坚。"
    translate None chapter_seven_0704:
        gr con "有时它必然伴随着痛苦和伤害，这都是必经之路。你要完全袒露自我，将全部信任托付给另一个人。"
    translate None chapter_seven_0705:
        gr con "而且必须双向奔赴。如果只有单方面付出，这还算真爱吗？"
    translate None chapter_seven_0706:
        rs sad "听起来好难…"
    translate None chapter_seven_0707:
        gr con "那你呢？说实话这样闲聊有点怪，但…你从没谈过恋爱吧？"
    translate None chapter_seven_0708:
        "他的目光在福恩身上停留片刻，又转向莱奥斯。"
    translate None chapter_seven_0709:
        gr fli "眼前就有几位英俊的单身汉呢。"
    translate None chapter_seven_0710:
        rs sad "我…还是不太明白那种感受。"
    translate None chapter_seven_0711:
        rs sad "莱奥斯？"
    translate None chapter_seven_0712:
        l neu "感觉是浪费时间。"
    translate None chapter_seven_0713:
        f shy "...."
    translate None chapter_seven_0714:
        gr "某只小鸟保持沉默呢。"
    translate None chapter_seven_0715:
        f shy "我…我没有过。"
    translate None chapter_seven_0716:
        gr con "有时候对自己诚实才是最难的。"

    if illran_fin == 3:
        jump choice_twelve_done
    jump choice_illran

label choice_twelve_done:
    scene bg wagon night with dis2
    translate None chapter_seven_0717:
        "斯塔格威奇早已远去。窗外掠过的风景变成连绵的农田牧场，间或点缀着农舍庄园。坐在轻轻摇晃的马车里看世界流转，本该是种宁静享受。"
    translate None chapter_seven_0718:
        "要不是车厢太小挤满聒噪的家伙，原本确实可以很宁静。"

    show illran n dim con at cenleft
    show bveras n dim tal at cenleft:
        xpos 0.3 ypos 1.0 xanchor 0.31 yanchor 0.98
    with dis
    show raen n dim neu at cenright
    show leos n dim neu at farright
    show fawn n dim neu at farleft
    with dis
    translate None chapter_seven_0719:
        gr "诶！我有个问题！"
    translate None chapter_seven_0720:
        "他舒展四肢咧嘴笑着，满脸兴味盎然。"
    show illran n dim hap at cenleft with dis
    translate None chapter_seven_0721:
        gr "你们的\"审判\"是什么？"

    show raen n dim sur
    show leos n dim sur
    show fawn n dim sur
    with hpunch

    translate None chapter_seven_0722:
        rs "什么？！"
    show illran n dim con with dis
    translate None chapter_seven_0723:
        gr "就是神明的审判啊。那三位神明对你们有什么评判？"
    translate None chapter_seven_0724:
        "我看向莱奥斯，发现他眼神和我一样慌乱。"
    show raen n wor with dis
    translate None chapter_seven_0725:
        rs "我们—"
    show fawn n dim neu with dis
    translate None chapter_seven_0726:
        f "审判？那是什么？"
    translate None chapter_seven_0727:
        "福恩面无表情地盯着绿发男子。"
    show illran n dim armsdown  neu with dis
    translate None chapter_seven_0728:
        gr "....."
    show leos n dim neu with dis
    translate None chapter_seven_0729:
        l "…别说胡话。"
    show raen n neu with dis
    show illran n dim con with dis
    translate None chapter_seven_0730:
        gr "…好吧好吧，当我没问。"
    translate None chapter_seven_0731:
        gr "反正旅途还长，我先睡个美容觉。"
    show leos n dim smi with dis
    translate None chapter_seven_0732:
        l "我觉得睡觉也挽救不了你的脸。"
    show illran n dim fli with dis
    translate None chapter_seven_0733:
        gr "你们也该试试。"

    hide illran n dim
    hide bveras
    show leos n dim neu
    with dissolve
    show fawn n dim at left
    show raen n dim at center
    show leos n dim at right
    with move

    translate None chapter_seven_0734:
        "他大笑着后仰，让维拉斯能跳到他胸前避风。"
    translate None chapter_seven_0735:
        lil neu "想睡就一路睡到底呗。"
    translate None chapter_seven_0736:
        rs "…我们睡不着。你不累吗？"
    translate None chapter_seven_0737:
        "但绿发男人已经阖上眼皮。"
    translate None chapter_seven_0738:
        lil neu "我习惯了。我一周要坐好几次夜车。"
    jump chapter_eight_start
