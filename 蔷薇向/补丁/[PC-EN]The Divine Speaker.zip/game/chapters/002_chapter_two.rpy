label chapter_two_start:
    $ about_Fawn.locked = False
    $ about_SC.locked = False
    $ about_AC.locked = False
    $ about_Azuros.locked = False
    $ about_Letter.locked = False
    $ about_Markings.locked = False
    $ about_Leos.locked = False
    $ about_Archives.locked = False

    window show dissolve
    show raen n sur with dis
    translate None chapter_two_0001:
        rs "我…真的吗？你会让我那么做…？"
    show fawn n neu with dis
    translate None chapter_two_0002:
        f "嗯…"
    translate None chapter_two_0003:
        f "我只是一个人在这里住了很久…"
    show fawn n sad with dis
    translate None chapter_two_0004:
        f "我觉得如果你现在离开，这里又会开始变得有点寂寞…"
    show fawn n hap with dis
    translate None chapter_two_0005:
        f "我可以教你在这里生活。哪些地方能去，哪些地方不能去。"
    show fawn n emb with dis
    translate None chapter_two_0006:
        f "呃，如果我太冒昧的话抱歉…！"
    translate None chapter_two_0007:
        f "毕竟我们才刚认识。我在想什么呢？！对不起…"
    translate None chapter_two_0008:
        "嗯…"
    translate None chapter_two_0009:
        "反正我也没别的地方可去。就像他说的，他在这附近没见过其他人。既然他主动提出，我们不妨结伴而行。"
    translate None chapter_two_0010:
        "另一个选择就是独自游荡。我可不想再经历一次刚来时的那个夜晚…孤独、寒冷、恐惧…"
    translate None chapter_two_0011:
        "而且，他有一张让我忍不住想照顾的脸。看着他那样喋喋不休的样子还挺可爱的。"
    show raen n smi with dis
    translate None chapter_two_0012:
        rs "…如果你愿意收留我，我会很开心住在这里。"

    show fawn n sur with dis
    translate None chapter_two_0013:
        f "真的吗？！我以为你一定会拒绝！"

    show fawn n hap with dis
    translate None chapter_two_0014:
        "他的脸立刻亮了起来，嘴角扬起微笑。他是真心希望我留下来。"
    translate None chapter_two_0015:
        f "那今天我先带你四处看看怎么样？当然要你愿意才行…"
    translate None chapter_two_0016:
        "如果真的打算在这里定居，我必须尽快熟悉环境。不能永远跟在福恩后面转悠，能收留我已经是他的恩惠了。"
    translate None chapter_two_0017:
        rs "好啊，我觉得不错。我很乐意。"
    translate None chapter_two_0018:
        "我一边穿衣一边吃完最后几颗红浆果，甘甜的味道在舌尖停留了好一会儿。"
    stop music fadeout 3.0
    window show dissolve



    play music "sounds/bgm/Discovery.ogg" fadeout 1
    scene bg forest with Fade(0.5,1,0.5)
    window show dissolve
    show raen n neu at center
    show expression AlphaMask("foliage_1", At("雷恩 的 新", center)) as mask
    with dis
    translate None chapter_two_0019:
        "整个白天我都在森林里游荡，福恩向我介绍地形。他指给我看几处地标，万一迷路时可以靠这些找到回他家的路。"
    translate None chapter_two_0020:
        "我很快学会了哪些浆果可以安全采摘，哪些光是触碰就会中毒。他说附近有很多致命植物，不确定的时候最好先问他。"
    translate None chapter_two_0021:
        "他好像无所不知。我想当只能依靠自己生存时，人必须成为行走的百科全书。"

    show raen n smi with dis
    translate None chapter_two_0022:
        "当他滔滔不绝地讲解时，眼睛闪闪发亮。显然他很享受有人能说说话。"
    translate None chapter_two_0023:
        "想到他这些年都是独自一人…其实有点难过…"

    show raen n sur with dis
    translate None chapter_two_0024:
        rs "对了，之前我差点忘记问…"
    translate None chapter_two_0025:
        rs "你从来不做饭吗？我注意到你只吃蔬菜水果。"

    show raen n sur at centtosl
    show expression AlphaMask("foliage_1", At("雷恩 微笑", centtosl)) as mask
    pause (0.1)
    show fawn n sur at slightright
    show expression AlphaMask("foliage_1", At("福恩 微笑", slightright))
    with dis
    translate None chapter_two_0026:
        f "会做饭…吗？"
    translate None chapter_two_0027:
        rs "嗯，比如用炉子那种，或者你可能直接用火？"

    show raen n smi with dis
    translate None chapter_two_0028:
        rs "其实我很擅长烹饪！"

    show fawn n neu with dis
    translate None chapter_two_0029:
        f "呃…"
    translate None chapter_two_0030:
        f "不，我….我通常不…"
    translate None chapter_two_0031:
        f "火是…"

    show fawn n sad with dis
    translate None chapter_two_0032:
        f "….不会。我一般就吃生鲜食物。"
    translate None chapter_two_0033:
        f "哈，明白了。那有机会真想给你做顿饭。"
    scene bg forest with Dissolve(1)
    translate None chapter_two_0034:
        "太阳高悬头顶，在辽阔蓝天中游弋。举目不见半片云彩，但微风拂过仍觉凉爽。"
    translate None chapter_two_0035:
        "今天我们就这样四处闲逛，探索聊天。奥雷利亚卡维拉仿佛已是遥远的记忆。说真的，这样很愉快。"
    translate None chapter_two_0036:
        "多日来我第一次感到胸口如此轻快。就像和朋友相处般自然。"

    scene bg river with dissolve
    translate None chapter_two_0037:
        "慢慢地，我们从容不迫地收集着昨天相遇河岸边的物品。"
    translate None chapter_two_0038:
        "一条旧毯子（有点潮，但福恩说还能用）、花瓶、门把手…"
    show raen n sur at center with dissolve

    translate None chapter_two_0039:
        rs "话说这些东西到底哪来的？"
    show raen n sur at slightleft with move
    show fawn n sad at slightright with dis2
    translate None chapter_two_0040:
        "我瞥向福恩，他正手忙脚乱地抱着那堆杂物。总捡起这个掉了那个。"

    show raen n smi with dis
    translate None chapter_two_0041:
        rs "哈哈，分我拿点。"
    translate None chapter_two_0042:
        f "啊..谢谢.."
    translate None chapter_two_0043:
        f "至于来源嘛…"

    show fawn n neu with dis
    translate None chapter_two_0044:
        "他望向远方，沉默片刻。"
    translate None chapter_two_0045:
        f "我想这条河连着不远处的大镇子。"
    translate None chapter_two_0046:
        f "可能是他们把东西倒进河里，顺流而下搁浅在岸边的。"

    show raen n neu with dis
    translate None chapter_two_0047:
        f "废物利用总比堆在这儿强。看着荒野满是垃圾让人难过。"
    translate None chapter_two_0048:
        rs "嗯…"
    show raen n con with dis
    translate None chapter_two_0049:
        rs "可我们镇确实有河穿过。但从没见过人往里面扔东西啊。"
    translate None chapter_two_0050:
        "这儿垃圾也太多了。难以相信都是人为丢弃的。"
    translate None chapter_two_0051:
        f "也许是别的镇子。我没去过所以不确定…"
    translate None chapter_two_0052:
        "他又开始这样了。"
    translate None chapter_two_0053:
        rs "什么意思？只能是奥雷利亚卡维拉啊。"

    show fawn n sur with dis
    translate None chapter_two_0054:
        f "但附近还有几个地方…"

    translate None chapter_two_0055:
        rs "你确定自己没…搞糊涂？"
    translate None chapter_two_0056:
        rs "还能是哪？这儿就只有森林。"
    translate None chapter_two_0057:
        rs "我不觉得会有很多像你这样的人住在…"

    show fawn n sad with dis
    translate None chapter_two_0058:
        f "可…但是…不是…"


    stop music fadeout 2.0
    show raen n sur with dis
    show fawn n sur with dis
    play sound "sounds/sfx/growl.ogg" fadeout 1
    translate None chapter_two_0059:
        "还未等福恩回答，我们就听到左侧灌木丛中传来一声低沉的吼叫。我甚至连思考的时间都没有。"

    play music "sounds/bgm/battle.ogg" fadeout 1
    translate None chapter_two_0060:
        "我们都没来得及反应，一只动物就从草丛里蹿了出来，直冲我而来。"

    show fawn n sur at center with move
    show raen n hur at left with move
    show raen n hur at shake
    translate None chapter_two_0061:
        f "小心！！！"

    show fawn n bla with dis
    translate None chapter_two_0062:
        "我正准备迎接冲撞，但撞击并未发生。相反，我被猛地推开，摔倒在地上。"
    translate None chapter_two_0063:
        "从地面上，我终于看清了那只正在福恩周围缓慢绕圈的生物。它体型很小，毛色灰暗，龇牙咧嘴地咆哮着。"

    show wolf1 with dis:
        xalign 1.00
        yalign 1.0
    translate None chapter_two_0064:
        "是只狼。从体型来看应该还是幼崽。"
    translate None chapter_two_0065:
        "它乌黑的眼睛死死盯着福恩，一动不动。"
    translate None chapter_two_0066:
        "在它扑向我之前，福恩把我推开挡在了前面。他在想什么？"
    translate None chapter_two_0067:
        "这太危险了。"
    translate None chapter_two_0068:
        "福恩毫不退让地与暴怒的野兽对视。他缓慢地向后挪着小步，小心翼翼地不让后背暴露给对方。"

    show fawn n neu with dis
    translate None chapter_two_0069:
        f "雷恩…慢慢站起来偷溜走。我来应付这个。"

    show raen n sad with dis
    translate None chapter_two_0070:
        "他声音中的犹豫消失了。我熟悉的那个紧张兮兮、神经质的福恩此刻完全不见踪影。"
    translate None chapter_two_0071:
        f "滚开！我们不怕你！"
    translate None chapter_two_0072:
        "他大幅度挥舞着手臂高声叫喊。要么是想吓退它，要么是为我争取逃跑时间。"
    translate None chapter_two_0073:
        f "雷恩，快跑！"
    translate None chapter_two_0074:
        "他的声音很轻，但充满力量。带着不容置疑的命令。"
    translate None chapter_two_0075:
        "我确保动作不会太突兀，从乱石地上缓缓起身，蹑手蹑脚地远离福恩和那只狼。"
        "我的心跳每秒百万次。我能听到耳中如雷的心跳声，全身都能感受到它的震动。"
    translate None chapter_two_0077:
        "诸神在上千万别让它们也听见。"
    translate None chapter_two_0078:
        "福恩用眼角余光瞥了我一眼，目光仍未从狼身上移开。"
    translate None chapter_two_0079:
        f "回屋里去…等你走了我再撤。"

    show raen n wor with dis
    translate None chapter_two_0080:
        rs "我不能丢下你！你会—"


    scene bg river with dissolve:
            xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.4
    translate None chapter_two_0081:
        "一切在眨眼间开始又结束。"
    play sound "sounds/sfx/whoosh1.ogg"
    translate None chapter_two_0083:
        "狼直扑福恩面门。他迅速抬起手臂护住自己，同时蹲伏在地。"
    translate None chapter_two_0084:
        "当狼正跃过他头顶时，他刚巧抬臂轻触到它，顺势将其甩进了河里。"

    show bg river at shake
    play sound "sounds/sfx/splash.ogg" fadeout 1
    translate None chapter_two_0085:
        "狼跌入水中，水花四溅，发出响亮的哀嚎。"
    translate None chapter_two_0086:
        f hur "快，就现在！"

    translate None chapter_two_0088:
        "我们俩同时加快步伐，拼命逃离那条河。福恩一把抓住我的胳膊，像钳子般紧攥着我往前拽。身后只能听见愤怒的拍水声。"
    translate None chapter_two_0089:
        rs hur "不是说要慢慢来吗！？"
    translate None chapter_two_0090:
        f hur "来不及了，快跑！"

    stop music fadeout 3.0
    window hide dissolve

    scene bg treehouseout at fadeinleft2 with dissolve
    pause 1.0
    scene bg treehousesunset at fadeinleft2 with dissolve
    window show dissolve
    show raen n hur at center with dis
    translate None chapter_two_0091:
        "福恩几乎是把我推上绳梯，催促我爬进他家。他刚爬到顶端就立即收起了绳梯。"

    play sound "sounds/sfx/fallonground.ogg"
    translate None chapter_two_0093:
        "我瘫倒在地板上直喘粗气。福恩也同样如此。"
    translate None chapter_two_0094:
        rs "刚才…刚才发生了什么？"

    show raen n hur at slightright with move
    show fawn n hur at slightleft with dis
    translate None chapter_two_0095:
        f "我..我不知道…我真的不知道"
    translate None chapter_two_0096:
        f "它们以前从没…对我表现出攻击性…"
    translate None chapter_two_0097:
        f "我们…我们是朋友…"

    show fawn n sad with dis
    translate None chapter_two_0098:
        f "至少，我原以为是"
    translate None chapter_two_0099:
        f "它通常很听我话…我时常喂它吃…"
    translate None chapter_two_0100:
        "我的呼吸虽然已趋于平稳，心跳却仍然剧烈。我扭头看向福恩。"

    show raen n sur with dis
    translate None chapter_two_0102:
        "地板上正滴落着某种红色液体。"
    translate None chapter_two_0103:
        rs "你..你受伤了！"
    #translate None chapter_two_0104:
    play sound "sounds/sfx/clothrustle.ogg"
    translate None chapter_two_0105:
        "他沮丧地卷起袖子检查手臂。"
    translate None chapter_two_0106:
        "一道道鲜红的血痕顺着手臂滴落，在木地板上溅开，醒目得刺眼。"
    translate None chapter_two_0106b:
        "他突然像藏赃物的孩子般，把手臂背到身后。"
    translate None chapter_two_0107:
        rs "得包扎一下才行…"
    translate None chapter_two_0108:
        "我懂点急救知识。平时照顾家里孩子够用，但这种伤口…"
    translate None chapter_two_0109:
        "房间里堆着成山的各种布条，可每当我伸手去拿…"

    show fawn n sur with dis
    translate None chapter_two_0110:
        f "别碰那块！"
    show fawn n sad with dis
    translate None chapter_two_0111:

        f "那块布是我前两天刚…"

    show raen n sad with dis
    translate None chapter_two_0112:
        rs "......"
    translate None chapter_two_0113:
        rs "好吧，既然不让包扎，至少让我看看伤口。"
    translate None chapter_two_0114:
        "没等他反对我就行动起来。"

    show fawn n sad with dis
    translate None chapter_two_0115:
        "他将手臂转向我。鲜血可能让伤势显得更严重，但那道伤痕确实触目惊心。"
    #translate None chapter_two_0116:
    translate None chapter_two_0117:
        "我伸手想握住他的手臂。"
    translate None chapter_two_0118:
        rs "你差点没命！应该更小心…"

    play sound "sounds/sfx/Bassy Swoosh.ogg" fadeout 1

    window hide
    scene black with flash
    translate None chapter_two_0119:
        n "…谎言…你被蒙骗了…"
    translate None chapter_two_0120:
        n "..保护好他…"
    translate None chapter_two_0121:
        n "….命运…张开双臂…"
    translate None chapter_two_0122:
        n "….承担他的…痛苦…"


    window show dissolve
    translate None chapter_two_0123:
        rs "............."
    translate None chapter_two_0124:
        " 这是…"
    translate None chapter_two_0125:
        "我在哪里……？"
    translate None chapter_two_0126:
        "震耳欲聋的声音穿透耳膜。眼前只有无尽的黑暗和那个声音。"

    show glow1 at center with Dissolve(1)
    translate None chapter_two_0127:
        "远处突然出现光亮。耀眼如初夏的朝阳。"

    show glow2 with Dissolve(1)
    translate None chapter_two_0128:
        "我伸手向它探去，指尖几乎触碰到那冰冷的辉光。"

    window hide dissolve
    show glow3 with Dissolve(1)
    show glow4 with Dissolve(1)


    play sound "sounds/sfx/Bassy Swoosh.ogg" fadeout 1
    scene bg treehousesunset with flash
    window show dissolve
    show fawn n hur at slightleft with dis
    translate None chapter_two_0129:
        f "……雷恩，你怎么了？！"

    show raen n hur at slightright with dis
    translate None chapter_two_0130:
        "当我睁开眼时，发现自己根本未曾移动。我仍在福恩家中，紧紧抓着他的手臂。"
    translate None chapter_two_0131:
        "就在指尖碰到福恩的刹那，眼前突然一片漆黑。刚才发生了什么…？"
    translate None chapter_two_0132:
        "黑暗消散了，那个声音也随之消失。一切恢复正常。"

    show fawn n sur with dis
    translate None chapter_two_0133:
        "还没等我开口，一道强光突然从福恩手臂与我手掌之间迸发。"

    show bg treehousesunset with flash
    show raen n wor with dis
    translate None chapter_two_0134:
        rs "……啊！"
    translate None chapter_two_0135:
        "疼痛从指尖开始蔓延，顺着手臂爬升。那是种灼烧般的剧痛。就像……"
    translate None chapter_two_0136:
        "那天…"

    play music "sounds/bgm/creepy.ogg" fadein 2.0
    translate None chapter_two_0137:
        "在我眼前的景象是：福恩手臂上的伤口正自动缝合，最后只剩下一道干涸的血迹。"
    translate None chapter_two_0138:
        rs "……咦？"
    translate None chapter_two_0139:
        "我的手臂开始产生呼应般的疼痛。卷起袖子查看时，我震惊得几乎下巴脱臼。"
    translate None chapter_two_0140:
        rs "这……是什么……？"

    show raen n hur with dis
    translate None chapter_two_0141:
        "好痛…"
    translate None chapter_two_0142:
        "鲜血从我手臂淌下，滴落在福恩的木地板上—就像片刻前他的情形一样。真的痛极了。"

    show fawn n neu with dis
    translate None chapter_two_0143:
        "难道这就是……福恩的感受……？"
    translate None chapter_two_0144:
        "福恩手臂上那道相同的裂伤……现在出现在了我的手臂上……"
    translate None chapter_two_0145:
        "我与福恩四目相对。他眼中的困惑不比我少半分。"
    translate None chapter_two_0146:
        f "..............."
    translate None chapter_two_0147:
        f "你刚才……做了什么？"
    translate None chapter_two_0148:
        rs "那不是……你做的……？"
    translate None chapter_two_0149:
        "他轻轻摇头，双眼圆睁。"
    translate None chapter_two_0150:
        "我震惊得张嘴呆立。对刚刚发生的事完全摸不着头脑。"
    translate None chapter_two_0151:
        rs "我不知道….我真的不知道….我从没…"

    show raen n sad with dis
    translate None chapter_two_0152:
        rs "以前从未发生过这种事…就像我…"
    translate None chapter_two_0153:
        f "就好像…你治愈了我，但现在伤口却转移到了你身上…"
    translate None chapter_two_0154:
        f "所以更像是…你代替我承受了这个伤…？"
    translate None chapter_two_0155:
        rs "什么…我…"
    translate None chapter_two_0156:
        rs "就在那时…."

    show fawn n sad with dis
    translate None chapter_two_0157:
        f "生命中的每个举动…都会引发相应的反应与后果…"
    translate None chapter_two_0158:
        f "所以…"
    translate None chapter_two_0159:
        rs "......"

    show raen n wor with dis
    translate None chapter_two_0160:
        rs "嗷…你可没说会这么疼…."
    translate None chapter_two_0161:
        "他之前确实隐瞒了这种剧痛…"
    translate None chapter_two_0162:
        rs "当我触碰你时…我听到了最近梦里出现的那些声音…"
    translate None chapter_two_0163:
        rs "但这次更加清晰…"
    translate None chapter_two_0164:
        rs "他们告诉我说保护你是我的使命…说我被欺骗了…还提到什么命运…"
    translate None chapter_two_0165:
        rs "但我的命运…"

    show fawn n neu with dis
    translate None chapter_two_0166:
        "我回想起十八年前接受的审判。那个支配我前半生命运，并将继续支配余生的判决。"
    translate None chapter_two_0167:
        "那个我时时被提醒的「审判」。即便成功了，我还是被打回原形。说到底，一个带着无用「审判」的废物男孩能有什么出息？"
    translate None chapter_two_0168:
        "现在还不想谈这个…不是时候。"
    translate None chapter_two_0169:
        rs "我出生时获得的「审判」…根本不是这样的。这究竟意味着什么…？"

    show fawn n sad with dis
    translate None chapter_two_0170:
        "福恩再次停下脚步，陷入沉思。"

    stop music fadeout 3.0
    translate None chapter_two_0171:
        f "但命运…是可以由自己创造的对吧？"
    translate None chapter_two_0172:
        f "如果人生只遵循多年前别人给定的轨迹…就永远不会有突破…"
    translate None chapter_two_0173:
        f "你并非缺乏改变的力量。"
    translate None chapter_two_0174:
        rs "可我们被赋予的命运…从不出错…"
    translate None chapter_two_0175:
        rs "「说书人」从不出错…"
    translate None chapter_two_0176:
        "我又低头看向手臂的伤口。"
    translate None chapter_two_0177:
        "我的命运不可能出错…"
    translate None chapter_two_0178:
        "突然想起在森林醒来的那个清晨。那些昨夜还未存在的花…"
    translate None chapter_two_0179:
        "难道与我有关？"
    translate None chapter_two_0180:
        "或许福恩的话确有道理…"
    translate None chapter_two_0181:
        "也可能不是。我不知道。"
    translate None chapter_two_0182:
        "尽管性情古怪，福恩确实很会说话。我…几乎要被他说服了。"

    show raen n neu with dis
    translate None chapter_two_0183:
        rs "…看来还是包扎一下为好。"

    show fawn n shy with dis
    translate None chapter_two_0184:
        f "…嗯。我来帮你。"
    translate None chapter_two_0185:
        "虽然刚才拒绝过，他还是麻利地缠好绷带，动作干净利落。"
    translate None chapter_two_0186:
        "无论怎么端详，伤口都真实存在，丝毫没有消退的迹象。"
    translate None chapter_two_0187:
        "一切都是真实发生的。"
    translate None chapter_two_0188:
        "这或许是惊人的天赋…但我不禁想到其中潜藏的危险。"
    translate None chapter_two_0189:
        "为何从前从未显现？这种事怎么可能凭空发生？触发条件是什么？"

    show raen n sur with dis
    translate None chapter_two_0190:
        rs "喂！福恩！"

    show fawn n sur with dis
    translate None chapter_two_0191:
        "他突然被我吓得跳起来。"
    #translate None chapter_two_0192:
    show raen n smi with dis
    play music "sounds/bgm/night.ogg"
    translate None chapter_two_0193:
        rs "不过你刚才超帅的！让人特别有安全感。"

    show fawn n shy with dis
    translate None chapter_two_0194:
        "他的脸又涨得通红，宛若玫瑰。"
    translate None chapter_two_0195:
        rs "没想到你也有这么飒爽的一面！"
    translate None chapter_two_0196:
        rs "哈哈哈。"


    show bg treehousenight
    show fawn n dim shy
    show raen n dim smi
    with dis3
    translate None chapter_two_0197:
        "经历种种变故后，天色终于暗了下来。夕阳沉入地平线，森林变得寒冷寂静。"
    show fawn n dim sad with dis
    translate None chapter_two_0198:
        f "其实…今天还有处地方想带你去…."

    show raen n dim sur with dis
    translate None chapter_two_0199:
        rs "现…现在合适吗？"
    translate None chapter_two_0200:
        rs "你觉得狼走远了吗？"
    translate None chapter_two_0201:
        f "嗯…我们朝反方向走应该…"
    translate None chapter_two_0202:
        f "......"
    translate None chapter_two_0203:
        f "原本没打算给你看这个，怕吓到你…"
    translate None chapter_two_0204:
        f "但我觉得我应该这么做。这是正确的选择…"
    translate None chapter_two_0205:
        "我们临时用绷带包扎好我的伤口，我把袖子拉了下来。他说\"以防吓到我\"是什么意思？"
    translate None chapter_two_0206:
        rs "那是什么？"
    translate None chapter_two_0207:
        f "呃…这有点难以解释…"

    show fawn n dim neu with dis
    translate None chapter_two_0208:
        f "但我想你已经看到它的影响了…"
    translate None chapter_two_0209:
        f "如果你胳膊不是很疼的话，愿意跟我来吗？"
    translate None chapter_two_0210:
        f "我知道很疼，所以你不用勉强自己。"

    show raen n dim sad with dis
    translate None chapter_two_0211:
        "他通常不会这么严肃，这番话让我有点紧张…特别是在之前发生的事之后。"
    translate None chapter_two_0212:
        "但既然见识过他先前的身手，真出什么意外我想可以依靠他。"
    translate None chapter_two_0213:
        "再说我也得向他证明我也能保护他。"

    show raen n dim smi with dis
    translate None chapter_two_0214:
        rs "…嗯。好啊。"

    $ about_Fawn.text = ["福恩大半辈子都独自生活在森林里，我是他在外界遇到的第一个人。随着了解加深，我觉得他并不怪异。他有时会害羞，但身心都很强大。以他的年纪来说也显得格外睿智。我能感觉到我们会相处得很好。"]
    translate None chapter_two_0215:
        "我跟着{a=set_entry:enc_people->about_Fawn}{color=#87CEEB}福恩{/color}{/a}爬下梯子，走进渐浓的夜色中。"

    stop music fadeout 3.0
    window hide

    scene bg forestnight with dissolve:
        size (1920, 1080) xpos -0.03 ypos -0.16 zoom 1.28
        linear 20.0 xpos -0.28 ypos -0.16 zoom 1.28

    window show dissolve
    #show raen n forestdark neu at center
    #show expression AlphaMask("foliage_1", At("raen  n forestdark neu", center)) as mask2
    #with dissolve
    #play sound "walkingearth.ogg" fadeout 3.0
    translate None chapter_two_0216:
        "这次我们走了很久很久。不断前行…四周景色一成不变，仿佛在原地绕圈。"
    translate None chapter_two_0217:
        "每走一步胳膊都抽痛着，但现在别无他法，只能咬牙忍耐。"
    #stop sound fadeout 2.0
    translate None chapter_two_0218:
        "外面已经漆黑一片。希望福恩认路…"

    #hide mask2
    scene bg forestnight with Dissolve(1.0)
    show raen n forestdark neu at slightright
    show expression AlphaMask("foliage_1", At("雷恩和森林暗夜图", slightright)) as mask4
    #pause(0.1)
    show fawn n forestdark neu at slightleft
    show expression AlphaMask("foliage_1", At("福恩和森林暗夜图", slightleft)) as mask3
    with dissolve
    translate None chapter_two_0219:
        "行走时我望着福恩的背影。他肩膀单薄，身形纤瘦，但看起来很精干。说不定比我还结实。大概力气也不小。"
    translate None chapter_two_0220:
        "肌肉分明，却如此纤细。"
    translate None chapter_two_0221:
        "在这种地方生活，他必须保持好体型吧。不知他独自生活多久了？又为何如此？"
    translate None chapter_two_0222:
        "打探隐私不合适，但我忍不住好奇。不过既然他不愿多谈，我也不会追问。"
    translate None chapter_two_0223:
        "他之前奔跑时弄乱的短发显得更凌乱了。好吧，比平常还要乱一点，这说明什么，反正他的头发本来就总是乱蓬蓬的。"

    show raen n forestdark sad with dis
    translate None chapter_two_0224:
        "…至少他不再受伤了。我摸了摸自己的手臂，只为确认绷带确实还在那里。没错，确实在。这一切真的发生过。"
    translate None chapter_two_0225:
        "我稍微拉起袖子瞥了眼另一只手臂。那些皮肤上的神之刻印依旧鲜明如初现之日。"
    translate None chapter_two_0226:
        "这些刻印，那些梦境，福恩的伤…"
    translate None chapter_two_0227:
        "它们之间有什么联系？"
    translate None chapter_two_0228:
        "这一切难道只是个大巧合？"
    translate None chapter_two_0229:
        "不管我如何在脑海中辗转思索，始终毫无头绪。一切都说不通。"

    hide mask4
    show raen n forestdark sur at srto
    show expression AlphaMask("foliage_1", At("雷恩和森林暗夜图", srto)) as mask6 behind fawn
    pause(0.9)
    hide mask6
    play sound "sounds/sfx/fallonground.ogg" fadeout 1
    show raen n forestdark sur at shakeslightleft behind fawn
    show expression AlphaMask("foliage_1", At("雷恩和森林暗夜图", shakeslightleft)) as mask8 behind fawn
    translate None chapter_two_0230:
        rs "哇…"
    translate None chapter_two_0231:
        "沉浸在思绪中的我直接撞上了突然停住脚步的福恩。"
    translate None chapter_two_0232:
        f "嘘。看。"
    #translate None chapter_two_0233:
    play music "sounds/bgm/scary.ogg"
    translate None chapter_two_0234:
        "我从他肩膀上方窥视。"

    show raen n forestdark wor with dis
    translate None chapter_two_0235:
        "全身瞬间变得僵硬。"
    translate None chapter_two_0236:
        rs "那…那是什么…？"

    window hide

    scene black with dis
    pause(0.5)
    show blackbars onlayer middle with dis

    show bg ghostforest with Dissolve(1.5):
        size (1920, 1080) crop (0, 210, 1257, 751)
        linear 40.0 crop (524, 210, 1093, 751)
    window show dissolve
    translate None chapter_two_0237:
        "我们面前的森林弥漫着某种泛蓝的荧光薄雾，正随着无形的韵律轻轻摇摆。那颜色既违逆自然又摄人心魄。"
    translate None chapter_two_0238:
        "在雾霭中…我几乎能看见人脸。蓝色的，毫无生气的脸。"
    translate None chapter_two_0239:
        "它们时而浮现时而消散…仿佛是我的意识在耍把戏。"


    scene bg ghostforest
    show fogblue onlayer middle:
        size (2500, 1080) crop (0, 0, 1920, 1080)
        linear 25.0 crop (1000, 0, 1920, 1080)
        linear 25.0 crop (0, 0, 1920, 1080)
        repeat
    show spirits
    with dissolve
    show fawn n forestdark neu at slightleft
    show raen n forestdark wor at slightright
    with dis
    translate None chapter_two_0240:
        f "森林的精灵们。他们发怒了。"
    translate None chapter_two_0241:
        "我屏息凝神听他说话。我们与薄雾保持着距离，从树木间隙间窥探。"
    translate None chapter_two_0242:
        f "他们最初并非来自此地。"

    show fawn n forestdark sad with dis
    translate None chapter_two_0243:
        f "西边那座镇子…你坚信是你故乡的地方…"
    translate None chapter_two_0244:
        f "......"
    translate None chapter_two_0245:
        f "他们时不时会在这里倾倒…某些东西。多数时候你根本辨认不出那是什么，但有时候…"

    show fawn n forestdark neu with dis
    translate None chapter_two_0246:
        f "有时候它们还保持完整…"

    show raen n forestdark sad with dis
    translate None chapter_two_0247:
        "我咽了口唾沫。冷汗顺着背脊流下，双手不住颤抖。我试图在永远波澜不惊的福恩面前隐藏这些反应。"
    translate None chapter_two_0248:
        rs "…东西？"
    translate None chapter_two_0249:
        f "我想…你之前已经碰见过。…在我们相遇前你发现的那条手臂…"
    translate None chapter_two_0250:
        f "从我到来之前他们就一直在这里，但…现在他们比以往更加愤怒。"

    show raen n forestdark wor with dis
    translate None chapter_two_0251:
        f "就好像…他们因某个原因滞留于此，却并非心甘情愿。"
    translate None chapter_two_0252:
        f "我实在想不出有什么理由能让如此大量的尸体以这般方式堆积。"
    translate None chapter_two_0253:
        rs ".........."
    translate None chapter_two_0254:
        f "近来，花儿不再那么早绽放，树叶凋落的速度却越来越快…"

    show fawn n forestdark sad with dis
    translate None chapter_two_0255:
        f "瓜果蔬菜几乎停止生长，动物们要么躲进我的屋子寻求庇护，要么远远地藏匿…"
    translate None chapter_two_0256:
        f "有些不对劲…"
    translate None chapter_two_0257:
        f "还有..之前那只狼…"
    translate None chapter_two_0258:
        f "整片森林似乎满腔怒火，仿佛在向伤害它的事物猛烈报复…."
    translate None chapter_two_0259:
        "我的思绪飘回家乡，飘到奥雷利亚卡维拉.."
    translate None chapter_two_0260:
        rs "他们一直..把尸体抛掷在这儿..？"
    translate None chapter_two_0261:
        "我无法…我连多看一眼都做不到。它们美得令人恐惧，美到让我反胃作呕。"
    translate None chapter_two_0262:
        "这不可能是真的。只要移开视线或闭上眼睛，它们肯定就会消失。"
    translate None chapter_two_0263:
        rs "可是…说书人说过..亡者会被安葬在阿祖罗斯..与居住在那里的长者们同眠…."
    translate None chapter_two_0264:
        f "我对这些…一无所知…"
    translate None chapter_two_0265:
        f "但尸体确实被丢弃在这里…而且它们的灵魂不知为何始终徘徊不散…"
    translate None chapter_two_0266:
        f "我不确定该不该让你看见这些…我本想带你领略美好而非可怖之物，但…"
    translate None chapter_two_0267:
        f "你有权知道真相。若你决定留下与我相伴，迟早都会发现这一切…"
    translate None chapter_two_0268:
        f "由我来告诉你更好。"
    translate None chapter_two_0269:
        "我死死攥住福恩的衣角。喉间像是堵了棉絮，半个字都挤不出来。"
    translate None chapter_two_0270:
        f "我们现在回去吧，好吗？只是…千万别独自来这儿。"
    translate None chapter_two_0271:
        f "我从不敢让它们发现我的存在，更不敢想象你若被它们察觉会遭遇什么。"
    translate None chapter_two_0272:
        "我最后回望那些朦胧身影。它们无声地漂浮游荡，时近时远。"
    translate None chapter_two_0273:
        "这不可能是真的…."
    translate None chapter_two_0274:
        "全都不是真的…."
    translate None chapter_two_0275:
        "它们肯定来自别处…但，何处呢？还能有什么地方？"
    translate None chapter_two_0276:
        "说书人不会对我们说谎。"
    translate None chapter_two_0277:
        "脑海中突然闪过他冰冷的眼神。明明素未交谈，他却用那种目光将我钉在原地…"
    translate None chapter_two_0278:
        rs "我们..我们走.."

    scene bg ghostforest with Dissolve(1.5):
        size (1920, 1080) crop (0, 210, 1257, 751)
        linear 40.0 crop (524, 210, 1093, 751)
    translate None chapter_two_0279:
        "转身离开时，我始终紧抓着福恩的衣摆。"
    translate None chapter_two_0280:
        "内心有个声音告诫我不要回头，但…我还是偷瞄了一眼。"
    translate None chapter_two_0281:
        "所有身影都静止了。它们看起来仿佛…"
    translate None chapter_two_0282:
        "仿佛正直勾勾地盯着我.. "
    translate None chapter_two_0283:
        "还是说…"
    translate None chapter_two_0284:
        "在凝视我身后的什么..？"
    translate None chapter_two_0285:
        "我猛地扭回头。"
    translate None chapter_two_0286:
        "再没敢回头张望。"

    window hide dissolve

    scene bg forestnight with dissolve
    window show dissolve
    show raen n forestdark sad at slightright
    show expression AlphaMask("foliage_1", At("雷恩和森林暗夜图", slightright)) as mask
    show fawn n forestdark neu at slightleft
    show expression AlphaMask("foliage_1", At("福恩和森林暗夜图", slightleft))
    with dis
    translate None chapter_two_0287:
        "返回小鹿之家的旅程既令人毛骨悚然又平淡无奇。即便我时刻担心会有什么东西跳出来抓住我，把我拖回那片漆黑之中，但什么也没发生。"

    show raen n forestdark sad with dis
    translate None chapter_two_0288:
        "我全程都抓着福恩的衬衫，但他似乎并不介意。还想在他面前逞强呢…"
    translate None chapter_two_0289:
        "我的眼睛四处张望，拼命寻找着什么。任何东西都好。不论看向哪里，我都能感觉到那些幽灵般的身影在注视着我。"

    $ about_Forest._text.append("原来由于某些原因，农作物停止生长，动物也都躲藏起来了。这本身就够奇怪了，但我还听说有人一直在这里丢弃尸体…为什么？")
    translate None chapter_two_0290:
        "这只是我的想象，对吧…？这只是{a=set_entry:enc_places->about_Forest}{color=#87CEEB}那片森林{/color}{/a}。"
    translate None chapter_two_0291:
        "回到福恩的树屋后，我以最快的速度爬上梯子，他也紧随其后。"
    translate None chapter_two_0292:
        "此刻我只想要四面墙带来的安全感，即使在…一棵树上。"

    window hide dissolve

    scene bg treehousenight with Fade(0.5,1,0.5)
    window show dissolve
    show raen n dim sad at slightright
    show fawn n dim sad at slightleft
    with dis
    translate None chapter_two_0293:
        "当我看向他时，他的表情显得凝重而阴郁。"
    translate None chapter_two_0294:
        f "对不起…"
    translate None chapter_two_0295:
        f "你宁愿…我没带你看那些吗..？"
    translate None chapter_two_0296:
        f "不知道这样做是对是错…."
    translate None chapter_two_0297:
        f "他们一直都在那里，但从未离开过那片区域。就好像他们…被困住了。"
    translate None chapter_two_0298:
        f "我觉得他们没法跟到这里，所以我们很安全…."
    translate None chapter_two_0299:
        f "我…我不会让你受伤的，你知道…"
    translate None chapter_two_0300:
        "他把目光从我身上移开。"
    translate None chapter_two_0301:
        f "别担心因为我…"
    translate None chapter_two_0302:
        f "我…"

    show fawn n dim hur at shake
    show raen n dim sur with dis
    stop music fadeout 3.0
    translate None chapter_two_0303:
        f "…我会保护你！"
    translate None chapter_two_0304:
        "他快速说完这句话就转过身假装忙碌。"
    translate None chapter_two_0305:
        rs "...."

    show raen n dim smi with dis
    play music "sounds/bgm/night.ogg" fadeout 1
    translate None chapter_two_0306:
        rs "哈哈…哈哈哈…"

    show fawn n dim emb with dis
    translate None chapter_two_0307:
        "他突然转回来，满脸通红。"
    translate None chapter_two_0308:
        f "怎..有什么好笑的..？！"
    translate None chapter_two_0309:
        rs "哈哈哈哈！"
    translate None chapter_two_0310:
        f "我是认真的！"
    translate None chapter_two_0311:
        "我忍不住了。"
    translate None chapter_two_0312:
        "或者说，我不想忍住。打破紧张气氛的感觉不错。"
    translate None chapter_two_0313:
        rs "啊哈哈，不，不..哈哈…我相信你….噗…"

    show fawn n dim hur with dis
    translate None chapter_two_0314:
        f "听起来可不像！"
    translate None chapter_two_0315:
        "有时候，福恩确实充满了青春活力。真是勇敢的家伙！真可靠！"
    translate None chapter_two_0316:
        rs "哈哈…"
    translate None chapter_two_0317:
        "其实，现在想想…"
    translate None chapter_two_0318:
        rs "所以福恩，虽然你说不知道来这里多久了…但你知道自己多大吗？"

    show fawn n dim shy with dis
    translate None chapter_two_0319:
        "他停下手中的活，思索了片刻。然而他的脸仍红得像番茄一般。"
    translate None chapter_two_0320:
        f "啊..我本该转过身的…今年应该是二十岁吧…"

    show raen n dim sur with dis
    translate None chapter_two_0321:
        rs "哇，不会吧！"
    translate None chapter_two_0322:
        rs "真不敢相信我比你小。"
    translate None chapter_two_0323:
        "我一直以为他和我同龄。他那瘦小的体格真是误导人…"

    show fawn n dim sur with dis
    translate None chapter_two_0324:
        f "等等，你多大了？"

    show raen n dim con with dis
    translate None chapter_two_0325:
        rs "两天前我刚过十八岁生日。"

    show fawn n dim sad with dis
    translate None chapter_two_0326:
        f "你生日那天被赶出来了？！？"
    translate None chapter_two_0327:
        "他看起来相当难过…"
    translate None chapter_two_0328:
        rs "是啊..但就像你说的，任何事情都有两面性…"
    translate None chapter_two_0329:
        rs "虽然我离开了家，但是…"

    show raen n dim smi
    show fawn n dim shy
    with dis
    translate None chapter_two_0330:
        rs "不然就不会遇见你了。"
    translate None chapter_two_0331:
        "我对他笑了笑。我甚至没有夸张，这是实话。"
    translate None chapter_two_0332:
        "虽然遭遇不幸，但福恩是我能在这里活下去的唯一理由。所以我必须往好处想。"
    translate None chapter_two_0333:
        "说实话，我们认识的时间虽短，却感觉像相识已久。和他如此亲近感觉很自然。"
    translate None chapter_two_0334:
        "是因为他的性格吗？这让我想要信任他，了解他。"
    translate None chapter_two_0335:
        f "什..我不…我是说.."
    translate None chapter_two_0336:
        "他用双手遮住通红的脸不让我看。"

    show fawn n dim hur with dis
    translate None chapter_two_0337:
        f "有时候你…会说些最浪漫又老套的话..太羞人了！这些话你是怎么想出来的！？"

    show raen n dim sur with dis
    translate None chapter_two_0338:
        rs "浪漫.."
    translate None chapter_two_0339:
        "我在脑海中反复品味这个词。浪…漫…？"
    translate None chapter_two_0340:
        "不，我绝对没听过这个词。"
    translate None chapter_two_0341:
        rs "这是什么意思？"

    show fawn n dim shy with dis
    translate None chapter_two_0342:
        "他放下手直视着我。"
    translate None chapter_two_0343:
        f "就是…那种，卿卿我我的，肉麻的…."
    translate None chapter_two_0344:
        rs "卿卿我我？"
    translate None chapter_two_0345:
        f "你知道的….爱。"

    show raen n dim sad with dis
    translate None chapter_two_0346:
        rs "....."
    translate None chapter_two_0347:
        f "你不是认真的吧…"
    translate None chapter_two_0348:
        f "就是…一个人对另一个人产生的感情…"
    translate None chapter_two_0349:
        f "然后他们结婚，生子，相爱…接吻…你懂的…"
    translate None chapter_two_0350:
        f "就是当你看着想共度余生的人时，胸口涌现的那种感觉…."
    translate None chapter_two_0351:
        rs "我从未听说过…"
    translate None chapter_two_0352:
        "这可能是某种森林术语…我该试着融入吗…？"
    translate None chapter_two_0353:
        f "难道你没见过村里相爱的人吗..？有孩子的那种..？"
    translate None chapter_two_0354:
        rs "在家里…我们当然有孩子。"
    translate None chapter_two_0355:
        rs "说书人通常只是把人们配对在一起，我们没法选择最终跟谁在一起。多数情况下，是地位或阶级相近的人配对。然后，他们生育孩子。"
    translate None chapter_two_0356:
        rs "但我从没听说过爱情、亲吻或者婚姻"

    show fawn n dim sad with dis
    translate None chapter_two_0357:
        f "你们没有…爱情吗？你是说那里不存在这些？"
    translate None chapter_two_0358:
        f "这怎么可能呢？没有爱情人怎么活得下去？"

    window hide

    menu:

        "你能教教我什么是亲吻吗？":
            $ fawn_relationship +=1
            jump fawn_kiss

        "婚姻？那是什么意思？":
            $ fawnaskmarriage = True
            $ fawn_relationship +=1
            jump fawn_marry

        "听起来不太重要":
            jump fawn_no2

label fawn_kiss:

    window show dissolve
    show raen n dim sur with dis
    translate None chapter_two_0359:
        rs "亲吻是什么…？你能教我吗？"

    show fawn n dim sur with dis
    translate None chapter_two_0360:
        f "什…！"

    show fawn n dim hur with dis
    translate None chapter_two_0361:
        f "不要！！！"
    translate None chapter_two_0362:
        f "这也太…让人难为情了….."
    translate None chapter_two_0363:
        "他不敢与我对视"
    translate None chapter_two_0364:
        "这反而让我更好奇了。感觉自己错过了什么"
    translate None chapter_two_0365:
        rs "拜托…？我以前从没听说过这些…"

    show fawn n dim shy with dis
    translate None chapter_two_0366:
        f "就像是…"
    translate None chapter_two_0367:
        "他把双唇撅了起来"
    translate None chapter_two_0368:
        f "当你把嘴唇贴在别人嘴唇上…然后像这样…轻轻动一动…"
    translate None chapter_two_0369:
        f "我也没亲过别人，所以也不太确定….."
    translate None chapter_two_0370:
        rs "把嘴唇贴在一起…？"
    translate None chapter_two_0371:
        rs "为什么要这么做呢？"
    translate None chapter_two_0372:
        f "因为感觉很好…我想…"

    show raen n dim smi with dis
    translate None chapter_two_0373:
        rs "我们能试试吗？"

    show fawn n dim hur at shake
    translate None chapter_two_0374:
        f "不行！！"

    jump choice_3_done

label fawn_marry:

    window show dissolve
    show raen n dim sur with dis
    translate None chapter_two_0375:
        rs "婚姻…你刚才提到过，那到底是什么？"

    show fawn n dim shy with dis
    translate None chapter_two_0376:
        f "嗯..当你找到想共度余生的人，你会送她一条镶着宝石的项链。通常是手工制作的，象征着你们许下永远在一起的承诺"
    translate None chapter_two_0377:
        rs "哦。有点像我们俩这样！"

    $ about_Marriage.locked = False
    show raen n dim smi with dis
    translate None chapter_two_0378:
        rs "那我们算是{a=set_entry:enc_lore->about_Marriage}{color=#DA70D6}结婚了{/color}{/a}吗？"

    show fawn n dim hur with dis
    translate None chapter_two_0379:
        "他的脸更红了"
    translate None chapter_two_0380:
        f "那-那是很特别的！只能和对你真正特别的人做！"
    translate None chapter_two_0381:
        rs "但，你就是我很特别的人啊！"

    if achievement.has("fawn_marriage"):
        pass
    else:
        $ renpy.display_notify("成就解锁：婚姻，那是什么？")

    python:
        achievement.grant("fawn_marriage")
        achievement.sync()

    jump choice_3_done

label fawn_no2:
    window show dissolve
    show raen n dim sad with dis
    translate None chapter_two_0382:
        rs "真的有那么重要吗？"

    show fawn n dim sur with dis
    translate None chapter_two_0383:
        f "当然重要！当你爱一个人时…那是…"

    show raen n dim sur with dis
    translate None chapter_two_0384:
        rs "那是…？"
    translate None chapter_two_0385:
        f "那是神奇的！"
    translate None chapter_two_0386:
        rs "嗯…"
    translate None chapter_two_0387:
        rs "你爱过谁吗？"
    translate None chapter_two_0388:
        f "什么？！"

    show fawn n dim sad with dis
    translate None chapter_two_0389:
        f "…..我不知道"
    jump choice_3_done

label choice_3_done:
    translate None chapter_two_0390:
        "还没等我继续追问，他就跳上床把脸埋进了枕头"
    hide fawn with dissolve
    show raen n dim sur at center with move
    translate None chapter_two_0391:
        f hur "我突然好累，晚安！"
    translate None chapter_two_0392:
        "他好像很尴尬。爱是令人尴尬的事吗？"
    translate None chapter_two_0393:
        "为什么我从没听说过？"

    hide raen #with dissolve

    scene bg treehousenight:
        size (1920, 1080) crop (0, 339, 1103, 649)
        linear 40.0 crop ((836, 340, 1000, 649))
    show fire
    with dissolve
    stop music fadeout 3.0
    translate None chapter_two_0394:
        "我仰躺在福恩旁边，双手枕在脑后"
    translate None chapter_two_0395:
        "…越来越多的问题…什么时候才能得到答案？"
    translate None chapter_two_0396:
        rs sad "嘿，福恩？"
    translate None chapter_two_0397:
        "没有回应。不是太尴尬就是已经睡着了。我悄悄脱得只剩下内衣"
    translate None chapter_two_0398:
        "……我该想个合适的方式谢谢他。"

    show black with eye_shut
    translate None chapter_two_0399:
        "闭上眼睛，我将过去几天发生的一切在脑海中重温。"

    play sound "sounds/sfx/Bassy Swoosh.ogg" fadeout 1
    show raen sepia with Dissolve(1.0):
        zoom 0.5
    translate None chapter_two_0400:
        "这个印记……"

    show leos sepia with dis:
        zoom 0.5
    play sound "sounds/sfx/Bassy Swoosh.ogg" fadeout 1
    translate None chapter_two_0401:
        "那个红发男人……"
    show speaker sepia with dis:
        zoom 0.5
    play sound "sounds/sfx/Bassy Swoosh.ogg" fadeout 1
    translate None chapter_two_0402:
        "说书人……"
    if persistent.voice_acting_off == False:
        play sound "sounds/VA/prologue_233.ogg"
    translate None chapter_two_0404:
        "{i}你看上去和你父亲当年一模一样。{/i}"

    pause(0.6)
    play sound "sounds/sfx/heartbeat.ogg" fadeout 1
    translate None chapter_two_0405:
        rs sad2 "...!"
    translate None chapter_two_0406:
        "他……认识我父亲？怎么认识的？为什么？"
    translate None chapter_two_0407:
        "无论我如何苦思冥想，都得不到答案。最终，在福恩轻柔的呼吸声中，我渐渐入睡。"

    scene black with Dissolve(1.0)
    window hide dissolve

    translate None chapter_two_0408:
        n "….醒……来.."
    translate None chapter_two_0409:
        n "快….点..    "
    translate None chapter_two_0410:
        n "…扩散….苏醒…."
    translate None chapter_two_0411:
        n "醒……来……"


    scene bg treehousenight with eye_open:
        size (1920, 1080) crop (836, 340, 1000, 649)
    window show dissolve
    translate None chapter_two_0412:
        "我眨了眨睁开的眼睛，把头转向一侧。"
    translate None chapter_two_0413:
        rs sad2 "呃…又是怪梦…"
    translate None chapter_two_0414:
        "要么是它们没那么可怕了，要么是我慢慢习惯了。这想法真令人不安…"
    translate None chapter_two_0415:
        "要是我能明白它们想告诉我什么就好了。"
    translate None chapter_two_0416:
        "嗯…？好像有什么不对劲…"
    translate None chapter_two_0417:
        "啊。"
    translate None chapter_two_0418:
        "太热了。我感觉自己在燃烧。"
    translate None chapter_two_0419:
        "我试图踢开腿上的被单，发现福恩把自己裹得严严实实，而我根本没盖被子。那为什么还这么热？"
    translate None chapter_two_0420:
        "他仍在熟睡，眉头微微皱着。不知道他梦见了什么？经历了昨天那些事后，他肯定累坏了。"
    translate None chapter_two_0421:
        "我伸手拂开他脸上的几缕头发。那些发丝黏在前额上，那里全是汗水。"

    scene bg treehousenight
    show fire
    with dis
    translate None chapter_two_0422:
        "我环顾房间。有种微光从地板缝隙间透上来。"
    translate None chapter_two_0423:
        "什么？"
    translate None chapter_two_0424:
        "不可能已经天亮了吧…？"
    translate None chapter_two_0425:
        "当我看向门口时，天空依然漆黑。"
    #translate None chapter_two_0426:
    play sound "sounds/sfx/fires.ogg"
    translate None chapter_two_0427:
        rs sur2 "那是什么声音？"
    translate None chapter_two_0428:
        "情况不对。"

    show raen n dim naked sur at center with dis
    translate None chapter_two_0429:
        "我迅速从福恩身边滑出，走向门口。"

    show raen n dim naked sad with dis
    translate None chapter_two_0430:
        "胸口发紧，呼吸为之一窒。"
    translate None chapter_two_0431:
        rs "不…"
    translate None chapter_two_0432:
        "一阵恐慌袭上心头。"
    #translate None chapter_two_0433:
    play music "sounds/bgm/battle.ogg"
    translate None chapter_two_0434:
        "房屋周围的树木被火焰吞噬，浓烟翻滚着升向天空。月亮和星星都看不见了。"
    translate None chapter_two_0435:
        "实际上…"
    translate None chapter_two_0436:
        "着火的不仅是周围的树木。"
    translate None chapter_two_0437:
        "火焰正舔舐着福恩木质地板的底部。不出多久整栋房子就会陷入火海。"

    hide raen
    show raen n dim sad at center
    with dis
    translate None chapter_two_0438:
        "我用最快速度抓起衣服。"
    translate None chapter_two_0439:
        "我们得马上离开这里。不是快，是现在！"

    show raen n dim hur with dis
    translate None chapter_two_0440:
        rs "福恩，快醒醒！快！"
    translate None chapter_two_0441:
        "我摇晃着他直到他睁开眼睛。"
    translate None chapter_two_0442:
        rs "着火了！我们现在就得逃出去！"
    translate None chapter_two_0443:
        "热浪开始让人呼吸困难。如果再继续等下去…"

    show raen n dim hur at slightright with move
    show fawn n dim neu at slightleft with dis
    translate None chapter_two_0444:
        "我抓起随身物品时，福恩正慌乱地从床上爬起来。"

    show fawn n dim sad with dis
    translate None chapter_two_0445:
        f "........."
    translate None chapter_two_0446:
        f "不……"
    translate None chapter_two_0447:
        "福恩完全僵立在原地，盯着地面。他丝毫没有加快动作的意思。"

    show raen n dim hur with dis
    translate None chapter_two_0448:
        rs "福恩，我们必须走了。立刻。马上就现在！"

    show fawn n dim hur at shake
    translate None chapter_two_0449:
        f "这不是…我不是故意的…！"
    translate None chapter_two_0450:
        f "我没想—"
    translate None chapter_two_0451:
        "他双手抱头盯着地面。即使我吼着要他移动，他仍纹丝不动。"
    translate None chapter_two_0452:
        "没时间耗在这了！"
    translate None chapter_two_0453:
        "我抓住他的手拽向门口。他没有反抗，但也不配合我跑动，只是任我拖着走。"
    translate None chapter_two_0454:
        "用来下滑的绳索已经着火，这条逃生路线报废了。"
    translate None chapter_two_0455:
        rs "福恩，我要你跟着我跳下来。能做到吗？"

    show fawn n dim sad with dis
    translate None chapter_two_0456:
        "我看向他。他微微点头却不与我对视。"

    window hide

    scene bg treefire:
        size (1920, 1080) crop (0, 0, 968, 551)
    show smoke onlayer middle:
        xpan 0
        linear 20.0 xpan 360
        repeat
    with w19
    window show dissolve
    translate None chapter_two_0457:
        "我先跃下，勉强避过迅速蔓延至林地的摇曳火舌。"

    show fawn m dim sad
    with dis
    translate None chapter_two_0458:
        "安全着陆后，我立即转身朝福恩张开双臂。"
    translate None chapter_two_0459:
        "但他没有动。"
    translate None chapter_two_0460:
        rs sad "福恩。你相信我吗？"

    show fawn m dim neu with dis
    translate None chapter_two_0461:
        "他眨了几下眼睛。"


    scene bg treefire
    show smoke onlayer middle:
        xpan 0
        linear 20.0 xpan 360
        repeat
    with dis

    show particle1
    show particle2
    show raen n dim sad at centerright
    show fawn n dim sad at centerleft
    with dis
    play sound "sounds/sfx/fallonground.ogg" fadeout 1
    show raen n dim sad at shakecenterright
    show fawn n dim sad at shakecenterleft
    hide mask1
    hide mask2

    translate None chapter_two_0462:
        "他一言不发。径直跳了下来。我将他接个满怀又迅速放下。 "
    translate None chapter_two_0463:
        "我们在燃烧的林地相拥而立，现实的重压渐渐袭来。"
    translate None chapter_two_0464:
        "顺着福恩的视线，我望向他的树屋。"
    translate None chapter_two_0465:
        "谁会干出这种事…？"
    translate None chapter_two_0466:
        "火光吞噬整座家园时，他失魂落魄地沉默着，甚至没落一滴泪。"
    translate None chapter_two_0467:
        "他只是凝望前方，彻底静止。"
    translate None chapter_two_0468:
        "无形的悲伤从他身上漫溢，仿佛心脏已碎成齑粉。"
    translate None chapter_two_0469:
        rs "福恩？福恩求你了…我们得离开！这里不安全—"
    translate None chapter_two_0470:
        u "有两个人。"
    translate None chapter_two_0471:
        u "不应该只有一个吗？没听说有两个啊。"

    show raen n dim sur with dis
    translate None chapter_two_0472:
        "那是..说话声？"
    translate None chapter_two_0473:
        "交谈声令我竖起耳朵。这里还有别人。"
    translate None chapter_two_0474:
        "在火焰的噼啪声中，我难以分辨声源方向。"
    translate None chapter_two_0475:
        "我攥紧福恩的手臂。他仍然呆望着…"
    translate None chapter_two_0476:
        "烟雾开始变得更加浓密，我们在这里站得越久，视线就越模糊。"
    translate None chapter_two_0477:
        "呼吸变得相当困难了…"
    translate None chapter_two_0478:
        u "我们另外那个人呢？"
    translate None chapter_two_0479:
        u "我已经看不到他了。反正跟这种家伙合作从来就没有好结果。"
    translate None chapter_two_0480:
        "他们不止一个人。"
    translate None chapter_two_0481:
        "情况不妙。如果现在不能说服福恩离开，我们要么被活活烧死，要么就会被寻找我们的人发现。"

    show raen n dim hur with dis
    translate None chapter_two_0482:
        rs "福恩。听我说。我觉得放火的人还在这里。我们真的得走了。现在就走。"

    show fawn n dim hur with dis
    translate None chapter_two_0483:
        f "我…我没有…"

    show raen n dim sad with dis
    translate None chapter_two_0484:
        "我抓住他的肩膀，让他转向我。"
    translate None chapter_two_0485:
        rs "求你了，福恩！"

    show fawn n dim sad with dis
    translate None chapter_two_0486:
        f "好…好的…"
    translate None chapter_two_0487:
        "我轻轻拉了一下他的手臂，这次他顺从地跟在我身后，但眼神空空荡荡。"
    translate None chapter_two_0488:
        "他再没说过一句话。"
    translate None chapter_two_0489:
        "掉落的火星让周围的草地起火越来越快。四面八方都快要被完全吞没了。"
    translate None chapter_two_0490:
        "如果不快点找到出路…"
    translate None chapter_two_0491:
        "感谢老天爷今天没刮风…"
    translate None chapter_two_0492:
        "我们才走出没多远，福恩就突然停住了脚步。"
    translate None chapter_two_0493:
        rs "怎么-"

    show fawn n dim neu with dis
    translate None chapter_two_0494:
        f "那边。左侧。"
    translate None chapter_two_0495:
        "左侧？"
    translate None chapter_two_0496:
        "我的目光顺着他看的方向望去。远处有两个身影，正朝福恩家的方向走来。"
    translate None chapter_two_0497:
        "他们好像还没发现我们。"
    translate None chapter_two_0498:
        "看起来…他们正在燃烧的灌木丛边搜寻着什么。"
    translate None chapter_two_0499:
        "肯定是在找我们。"
    translate None chapter_two_0500:
        "小鹿之家\"看起来随时会倒塌，火势就算没比之前更大，也丝毫没减弱。可他们仍在搜寻。我们必须立刻远离这里。"
    translate None chapter_two_0501:
        "这样冒险…我们对他们就这么重要吗？"

    scene gallery_15:
        size(1920,1080) crop (850, 900, 1179, 621)
        linear 25.0 crop (850, 400, 1179, 621)
    show particle1
    show particle2

    with Dissolve(2.0)


    window show dissolve
    translate None chapter_two_0502:
        leosu "你们两个难道不该逃命吗？"
    translate None chapter_two_0503:
        "谁…？"
    translate None chapter_two_0504:
        "另一个声音，不同于之前听到的那些，从噼啪的火焰声中突然传来。"
    translate None chapter_two_0505:
        "就在我和福恩全神贯注盯着那两个人时，我们没注意到有人从树林右侧过来了。"
    translate None chapter_two_0506:
        "第三个人现身了。他很近。近到只需我往前几步就能碰到他。"
    translate None chapter_two_0507:
        "我第一反应是求援，但手上传来的拉扯让我僵在原地。"
    translate None chapter_two_0508:
        f neu "等等。"

    show gallery_15 with Dissolve(2.0):
        size (1920, 1080) crop (352, 249, 2200, 1200)
    translate None chapter_two_0509:
        f "他带着武器…"
    translate None chapter_two_0510:
        leosu "啊，注意到了？"
    translate None chapter_two_0511:
        "男人发出轻微的冷笑。"
    translate None chapter_two_0512:
        "他手里…那是什么？看起来像是某种绳索。不过眼下看来，这已经是最不值得我们担心的事了。"
    translate None chapter_two_0513:
        "他的另一只手中握着一把匕首。"
    translate None chapter_two_0514:
        "这太危险了。我觉得我们应该—"
    translate None chapter_two_0515:
        leosu "知道吗？跟踪你们到这里简直不费吹灰之力。你们根本就没打算掩盖行踪是吧？"
    translate None chapter_two_0516:
        leosu "如果我是你，第一件事就会处理好这个。"
    translate None chapter_two_0517:
        leosu "不过嘛，看来不是所有人都能像我这般明智。"
    translate None chapter_two_0518:
        "懂了吗？"
    translate None chapter_two_0519:
        "福恩再次拽住我的手，直到把我拉到他身后，用身体挡在我前面。"

    show gallery_15b with dissolve:
        size (1920, 1080) crop (352, 249, 2200, 1200)

    translate None chapter_two_0520:
        leosu "当他们说要我来森林里追踪个家伙时，我还挺担心的，但你知道吗？"

    show gallery_16 with dissolve
    translate None chapter_two_0521:
        leosu "能在这儿逮到你们的快感，值了。"
    translate None chapter_two_0522:
        "他朝福恩和我逼近一步。"
    translate None chapter_two_0523:
        "我猛地一颤。脊背窜上一阵寒意，能感觉到冷汗浸透了全身。"
    translate None chapter_two_0524:
        "这声音…我是不是在哪听过？我拼命在浓烟中张望。"
    translate None chapter_two_0525:
        "他身材高瘦，但大部分轮廓都隐在烟里。红色…红头发…？"
    translate None chapter_two_0526:
        "唯一能看清的，是他脸上狡黠的狞笑。"
    scene gallery_15b with dissolve:
        size (1920, 1080) crop (252, 249, 2200, 1200)
    translate None chapter_two_0527:
        "依稀听见福恩用带着绝望的声音对我耳语："
    translate None chapter_two_0528:
        f hur "雷恩…我们得赶—"

    play sound "sounds/sfx/creak.ogg" fadeout 1
    translate None chapter_two_0529:
        "身后突然传来震耳的断裂声，小鹿之家的第一块构件轰然坠入森林地面。"
    translate None chapter_two_0530:
        "另外两个男人还在树根处搜索，飞溅的碎木堪堪擦过他们。他们对这边发生的事浑然不觉，仍在继续搜寻。"
    translate None chapter_two_0531:
        "福恩把我的手攥得更紧了。待会淤青了我都不会觉得奇怪。"
    translate None chapter_two_0532:
        rs sur "福恩，我觉得那人可能是—"
    window hide

    scene gallery_16 with Dissolve(1):
        size(1920,1080)

    pause(1)
    stop music
    play sound "sounds/sfx/explosion.ogg"

    show black with hpunch

    if achievement.has("fawn_burn"):
        pass
    else:
        $ renpy.display_notify("【成就解锁：烤棉花糖时间】")
    python:
        achievement.grant("fawn_burn")
        achievement.sync()

    jump chapter_three_start
