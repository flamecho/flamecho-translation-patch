label chapter_thirteen_start:
    show raen n sad with dis
    translate None chapter_thirteen_0001:
        rs "我…我不能走…"
    translate None chapter_thirteen_0002:
        show leos n ang with dis
        l "为什么？！"
    translate None chapter_thirteen_0003:
        l "你明明可以走的。别这样。别再说这种话！"
    translate None chapter_thirteen_0004:
        rs "诺克斯需要我们的帮助…而我需要他的帮助。"
    translate None chapter_thirteen_0005:
        rs "如果我现在离开，就永远不会知道真相了。他是唯一认识卡斯皮安的人。"
    translate None chapter_thirteen_0006:
        l "你怎么知道他是唯一知情人？我们可以找其他人。你就不能安心过自己的生活吗？你是想找死吗？"
    translate None chapter_thirteen_0007:
        show raen n wor at shake
        rs "当然不是！但是…但是…！"
    translate None chapter_thirteen_0008:
        show raen n sad with dis
        rs "….我觉得我们能行！我们一定能解决这个！"
    translate None chapter_thirteen_0009:
        show cyne n hap with dis
        c "这才像话。我就知道你是最带劲的那个。"
    translate None chapter_thirteen_0010:
        f "我会追随你到任何地方…所以，你做的任何决定对我来说都是正确的。"
    translate None chapter_thirteen_0011:
        "我看向莱奥斯。他看起来并未被说服。"
    translate None chapter_thirteen_0012:
        show leos n hur with dis
        l "不是。"
    translate None chapter_thirteen_0013:
        rs "求你了？"
    translate None chapter_thirteen_0014:
        l "不是。"
    translate None chapter_thirteen_0015:
        rs "….没有你我真的做不到。"
    translate None chapter_thirteen_0016:
        show leos n pen with dis
        l "......"
    translate None chapter_thirteen_0017:
        rs "......"
    translate None chapter_thirteen_0018:
        l "呃！好吧！"
    translate None chapter_thirteen_0019:
        l "等你们死了可别来找我哭诉！"
    translate None chapter_thirteen_0020:
        rs "你不是说要保护我吗？"
    translate None chapter_thirteen_0021:
        show leos n smi with dis
        l "哈！就凭这事？休想。我只是跟来看笑话的。"
    translate None chapter_thirteen_0022:
        "他对我嗤之以鼻。"
    translate None chapter_thirteen_0023:
        "我的心情依然沉重，但我还是强装勇敢。"
    translate None chapter_thirteen_0024:
        rs "你们在市场打听到什么了吗？"
    translate None chapter_thirteen_0025:
        f "呃…"
    translate None chapter_thirteen_0026:
        f "我和莱奥斯找你的时候打听了一下，但是…"
    translate None chapter_thirteen_0027:
        rs "但是什么？"
    translate None chapter_thirteen_0028:
        show leos n neu with dis
        l "…我们听到传言说镇子外围发现了一具尸体。可能值得去看看。"
    translate None chapter_thirteen_0029:
        rs "...."
    translate None chapter_thirteen_0030:
        "那…那可能最后会发现是我的尸体…"
    translate None chapter_thirteen_0031:
        "我深吸一口气。现在担心也没用。"
    translate None chapter_thirteen_0032:
        rs "赛恩？"
    translate None chapter_thirteen_0033:
        show cyne n neuclo with dis
        c "是这样，在我追上你们之前，确实听到些消息…"
    translate None chapter_thirteen_0034:
        show cyne n neu with dis
        c "镇上有个算命师。"
    translate None chapter_thirteen_0035:
        show raen n sur with dis
        rs "算…算命师？这有什么关系？"
    translate None chapter_thirteen_0036:
        l "别开玩笑了。"
    translate None chapter_thirteen_0037:
        c "不不，是真的！据说她特别灵验。说不定能告诉我们些什么。"
    translate None chapter_thirteen_0038:
        show raen n sad with dis
        rs "…我和几个人交谈过，他们不停提到\"祭品\"、\"时候终于到了\"、\"暂时安全了\"之类的话。"
    translate None chapter_thirteen_0039:
        rs "他们谈论的方式和诺克斯完全不同。我觉得我们应该先找到他，再多问些问题。"
    translate None chapter_thirteen_0040:
        c "所以…三条线索？"
    translate None chapter_thirteen_0041:
        rs "我想是的。虽然都不太确定，但至少是个开始。"
    translate None chapter_thirteen_0042:
        l "….我们不知道还剩多少时间。可能连三条线索都调查不完。"
    translate None chapter_thirteen_0043:
        f "看来得做个明智的选择…"
    translate None chapter_thirteen_0044:
        rs "嗯…"
    window hide


label ox_investigation:

    menu:
        "追查算命师" if ox_fortune:
            $ ox_fortune = False
            $ ox_fin += 1
            window show dissolve
            jump oxhabor_fortuneteller

        "追查诺克斯" if ox_nox:
            $ ox_nox = False
            $ ox_fin += 1
            window show dissolve
            jump oxhabor_nox

        "追查尸体" if ox_body:
            $ ox_body = False
            $ ox_fin += 1
            window show dissolve
            jump oxhabor_body

label oxhabor_fortuneteller:
    show raen n dim sad at cenleft
    show cyne n dim neu at cenright
    show leos n dim ang at farright
    show fawn n dim sad at farleft
    with dis
    translate None chapter_thirteen_0045:
        rs "我们何不先去找占卜师谈谈？我知道这听起来有点离谱，但她说不定真知道些什么。"
    translate None chapter_thirteen_0046:
        show leos n sur with dis
        l "占卜师？你这不是上赶着被人骗吗？"
    translate None chapter_thirteen_0047:
        c "据说她能同时窥见过去与未来。"
    translate None chapter_thirteen_0048:
        show leos n neu with dis
        l "没人能做到这种事。她就是个骗子。"
    translate None chapter_thirteen_0049:
        show fawn n neu with dis
        f "世事难料…"
    translate None chapter_thirteen_0050:
        rs "我们就去看一眼，行吗？要是觉得不对劲马上就走。"

    window hide dissolve


    scene bg ox alley with dissolve:
        xpos 0.64 ypos 1.17 xanchor 0.5 yanchor 1.0 zoom 1.96
        linear 35.0 ypos 1.94
    window show dissolve
    translate None chapter_thirteen_0051:
        "塞恩二话不说转身带我们往占卜师的方向走去。穿过一条又一条小巷，最终走进了死胡同。"
    translate None chapter_thirteen_0052:
        l smi "看来你带错路了，谁能想到呢。干得漂亮。"
    translate None chapter_thirteen_0053:
        c hap "是吗？"
    translate None chapter_thirteen_0054:
        "塞恩转向一扇没有标记的门，重重敲了两下。刚过一秒就传来拉开门闩的声音。"
    translate None chapter_thirteen_0055:
        ft "…谁啊？"
    translate None chapter_thirteen_0056:
        c hap "哎呀你好啊，小姑娘！我们想问—"
    translate None chapter_thirteen_0057:
        ft "{i}小姑娘？{/i}"
    translate None chapter_thirteen_0058:
        "她冲他嗤笑一声。"
    translate None chapter_thirteen_0059:
        ft "我的年纪当你曾祖母都绰绰有余。少跟我在这{i}小姑娘{/i}长{i}小姑娘{/i}短的。"
    translate None chapter_thirteen_0060:
        l ann "纯粹是浪费时间。"
    translate None chapter_thirteen_0061:
        ft "你们到底想干什么？来占卜的？"
    translate None chapter_thirteen_0062:
        rs sur "不，我们想打听—"
    translate None chapter_thirteen_0063:
        ft "过来孩子，你先来。"


    show bg ox alley with dissolve:
        xpos 0.39 ypos 1.38 xanchor 0.36 yanchor 1.0 zoom 1.49

    show raen m sur with dis
    translate None chapter_thirteen_0064:
        rs "呃…"
    translate None chapter_thirteen_0065:
        "老妇人把我拉到跟前，让我在街边坐下。她转身进屋，片刻后拿着个浅口金碟回来。她把碟子放在我们之间，跪坐下来与我对视。"
    translate None chapter_thirteen_0066:
        rs "那是什么？"
    translate None chapter_thirteen_0067:
        "她用一个破旧的壶往碟里倒水，直到水面与碟沿齐平。"
    translate None chapter_thirteen_0068:
        ft "...."
    translate None chapter_thirteen_0069:
        "身后传来莱奥斯嘀嘀咕咕的叹气声。"
    translate None chapter_thirteen_0070:
        ft "把左手悬在水面上，先别碰水。"
    translate None chapter_thirteen_0071:
        show raen m sad with dis
        "我顺从地将左手掌心向下悬在碟子上方。"
    translate None chapter_thirteen_0072:
        ft "别着急小子。用食指轻轻点一下水面。"
    translate None chapter_thirteen_0073:
        "她闭上眼睛。"
    translate None chapter_thirteen_0074:
        "会发生什么？"
    translate None chapter_thirteen_0075:
        "我小心翼翼地触碰水面，细小的涟漪从碟子边缘漾开。"
    translate None chapter_thirteen_0076:
        ft "...."
    translate None chapter_thirteen_0077:
        ft "…我看见了。"
    translate None chapter_thirteen_0078:
        l smi "真的？可你眼睛闭着。"
    translate None chapter_thirteen_0079:
        ft "死亡，背叛。被抛弃在阴影里，又被另一个人捡起。抚养你长大的并非至亲，却同样骨肉情深。"
    translate None chapter_thirteen_0080:
        show raen m sur with dis
        rs "我？"
    translate None chapter_thirteen_0081:
        ft "被放逐的耻辱，以及压在你肩上的命运重担。"
    translate None chapter_thirteen_0082:
        "她睁开双眼。"
    translate None chapter_thirteen_0083:
        rs "你怎么知道…？"
    translate None chapter_thirteen_0084:
        ft "我能从命运的涟漪中看见。你的左手诉说着你的过去。"
    translate None chapter_thirteen_0085:
        rs "那么，我的右手…？"
    translate None chapter_thirteen_0086:
        ft "你的未来。你想知道吗？"
    translate None chapter_thirteen_0087:
        "我想知道吗…我？"
    translate None chapter_thirteen_0088:
        "我不确定，但如果这能有帮助…"
    translate None chapter_thirteen_0089:
        show raen m sad with dis
        rs "…是的。"
    translate None chapter_thirteen_0090:
        ft "再重复一次动作。"
    translate None chapter_thirteen_0091:
        "我将右手放在盘子上，等待她再次闭上眼睛。"
    translate None chapter_thirteen_0092:
        "如同之前那样，我轻轻用指尖触碰水面。"
    translate None chapter_thirteen_0093:
        ft "...."
    translate None chapter_thirteen_0094:
        ft "再来一次。"
    translate None chapter_thirteen_0095:
        rs "...?"
    translate None chapter_thirteen_0096:
        "我又做了一遍，她睁开了眼睛。"
    translate None chapter_thirteen_0097:
        ft "…什么都没有。"
    translate None chapter_thirteen_0098:
        rs "什么都没有？"
    translate None chapter_thirteen_0099:
        rs "你是什么意思，什么都没有？"
    translate None chapter_thirteen_0100:
        $ about_FTAcc.locked = False
        ft "{a=set_entry:enc_mysteries->about_FTAcc}{color=#DA70D6}你没有未来{/color}{/a}。水面关于你无话可说。"
    translate None chapter_thirteen_0101:
        rs "这是什么意思？"
    translate None chapter_thirteen_0102:
        ft "你得自己去想明白。"
    translate None chapter_thirteen_0103:
        "没有未来…？这是和死亡一样吗？还是说我的命运尚未决定？嗯…"
    translate None chapter_thirteen_0104:
        c hap "噢，噢，下一个让我来！"
    translate None chapter_thirteen_0105:
        l pen "我们没时间做这个。"
    translate None chapter_thirteen_0106:
        ft "可以再来一个人。"

    hide raen with dissolve
    window hide


    menu:
        "选择福恩":
            window show dissolve
            $ fawn_relationship +=1
            jump ft_fawn

        "选择赛恩":
            window show dissolve
            $ cyne_relationship +=1
            jump ft_cyne

        "选择莱奥斯":
            window show dissolve
            $ leos_relationship +=1
            jump ft_leos


label ft_fawn:
    translate None chapter_thirteen_0107:
        rs sur "福恩，你来试试。"
    translate None chapter_thirteen_0108:
        show fawn m sur with dis
        f "我？"
    translate None chapter_thirteen_0109:
        rs sur "是啊，你不感兴趣吗？"
    translate None chapter_thirteen_0110:
        show fawn m sad with dis
        f "我想是吧.."
    translate None chapter_thirteen_0111:
        "我站了起来，福恩在我原来的位置面对着占卜师坐下。他将右手放在碗上。"
    translate None chapter_thirteen_0112:
        ft "…你只想看看你的未来？"
    translate None chapter_thirteen_0113:
        "他对她点头。"
    translate None chapter_thirteen_0114:
        ft "…一片红色森林…嗜血杀戮…遥远的城市，一次会面…一个远离家乡的蓝发女孩。"
    translate None chapter_thirteen_0115:
        ft "没有宽恕，只有折磨。"
    translate None chapter_thirteen_0116:
        "福恩突然抽回了手站起来。占卜师再次睁开眼睛，但没有继续说什么的打算。"

    jump choice_twentyfour_done


label ft_cyne:
    translate None chapter_thirteen_0117:
        rs "如果你想试试，来吧赛恩。"
    translate None chapter_thirteen_0118:
        show cyne m hap with dis
        c "我现在能看见了—一座巨大的城堡，莱奥斯做我的管家。每当我沐浴时，福恩为我搓背。雷恩，如果你想加入我也不介意。"
    translate None chapter_thirteen_0119:
        l ann "我宁愿去死。"
    translate None chapter_thirteen_0120:
        "赛恩接替了我的位置，先伸出了左手。"
    translate None chapter_thirteen_0121:
        show cyne m neu with dis
        ft "…这么多人。每一天，都有人新来。死亡，复仇，不忠。"
    translate None chapter_thirteen_0122:
        ft "慢慢地，被谎言与仇恨腐蚀。"
    translate None chapter_thirteen_0123:
        show cyne m sur with dis
        c "...."
    translate None chapter_thirteen_0124:
        "他将手从水中抽回，盯着自己湿漉的指尖。"
    translate None chapter_thirteen_0125:
        rs sur "….另一只手呢？"
    translate None chapter_thirteen_0126:
        show cyne m ang with dis
        c "….不必了。明显是个骗局。"
    translate None chapter_thirteen_0127:
        "他站了起来，但占卜师没有起身的意思。"

    jump choice_twentyfour_done

label ft_leos:
    translate None chapter_thirteen_0128:
        rs sur "莱奥斯，你来试试。"
    translate None chapter_thirteen_0129:
        l smi "何必呢？不过是些垃圾罢了。"
    translate None chapter_thirteen_0130:
        rs sad "来吧，难道你连一丁点儿兴趣都没有…？"
    translate None chapter_thirteen_0131:
        l smi "没有。你说破天也不可能让我参与这种蠢事。"
    translate None chapter_thirteen_0132:
        l smi "我们可不是谁都能轻易骗到的冤大头。"

    jump choice_twentyfour_done

label choice_twentyfour_done:
    hide fawn
    hide cyne
    hide leos
    with dis
    show bg ox alley:
        xpos 0.84 ypos 1.62 xanchor 0.43 yanchor 1.0 zoom 2.08
        linear 55.0 xpos 0.19
        linear 55.0 xpos 0.84
        repeat
    translate None chapter_thirteen_0133:
        "好吧…说得是挺像那么回事，但对我们毫无用处。这应该不算浪费时间吧…？"
    translate None chapter_thirteen_0134:
        rs neu "…感谢您抽空见面。夫人，我能否请教些别的事？"
    translate None chapter_thirteen_0135:
        "她挑了挑眉，但没表示反对。"
    translate None chapter_thirteen_0136:
        rs sad "其实…"


    if body_earring and search_books and ox_nox:
        $ ft_askcount += 3

    if body_earring == False and search_books and ox_nox:
        $ ft_askcount += 2

    if body_earring and search_books == False and ox_nox:
        $ ft_askcount += 2

    if body_earring and search_books == True and ox_nox == False:
        $ ft_askcount += 2

    if body_earring == False and search_books == False and ox_nox:
        $ ft_askcount += 1

    if body_earring and search_books == False and ox_nox == False:
        $ ft_askcount += 1
    window hide


label choice_twentyfive:
    menu:
        "您对连环凶杀案有所了解吗？" if ft_askmurders:
            window show dissolve
            $ ft_askcount += 1
            $ ft_enough = True
            $ ft_askmurders = False
            jump ftc1

        "最近可曾见过什么异常现象？" if ft_askstrange:
            window show dissolve
            $ ft_askcount += 1
            $ ft_enough = True
            $ ft_askstrange = False
            jump ftc2

        "关于这枚耳环的佩戴者，您能提供什么线索吗？" if ft_askearring and body_earring == False: #  if checkedoutbody + earring
            window show dissolve
            $ ft_askcount += 1
            $ ft_enough = True
            $ ft_askearring = False
            jump ftc3

        "询问日记的事" if ft_askdiary and search_books == False: #if looked at diary
            window show dissolve
            $ ft_askcount += 1
            $ ft_enough = True
            $ ft_askdiary = False
            jump ftc4

        "询问诺克斯·穆拉诺" if ft_asknox and ox_nox == False: #if spoke to nox first
            window show dissolve
            $ ft_askcount += 1
            $ ft_enough = True
            $ ft_asknox = False
            jump ftc5

        "问够了" if ft_enough:
            window show dissolve
            jump choice_twentyfive_done

label ftc1:
    translate None chapter_thirteen_0137:
        rs sad "我们注意到陆续有人失踪，还有些人…最终横死街头。您知道内情吗？"
    translate None chapter_thirteen_0138:
        ft "…也算知道也算不知道。"
    translate None chapter_thirteen_0139:
        rs sur "什么叫也算知道也算不知道？"
    translate None chapter_thirteen_0140:
        ft "我既知道很多，又什么都不知道。"
    translate None chapter_thirteen_0141:
        l ann "...."
    translate None chapter_thirteen_0142:
        l pen "能详细说说吗？"
    translate None chapter_thirteen_0143:
        ft "当我闭眼时，再也看不见他们了。灵魂都已消散。"
    translate None chapter_thirteen_0144:
        ft "但我知道他们死前饱受煎熬，被某种未知力量慢慢蚕食。你最好别掺和这事。"
    translate None chapter_thirteen_0145:
        rs sad "那么…您知道凶手可能是谁吗？"
    translate None chapter_thirteen_0146:
        ft "…不知道。但我知道随着时间推移，他们深陷绝望的痛苦会愈发剧烈。"
    translate None chapter_thirteen_0147:
        $ about_FTAcc._text.append("显然，这些谋杀案延续的时间比她母亲的一生还长。")
        ft "这些谋杀案持续{color=#87CEEB}的时间比我寿命还长{/color}，比我母亲的寿命也要久。"
    translate None chapter_thirteen_0148:
        c ang "这么久？难道是连环模仿作案？没人能活这么久犯下所有案子。"
    translate None chapter_thirteen_0149:
        ft "孩子…我答不上来。这超出我的认知。只能感受到既古老又年轻的气息，混合着令人心碎的悲伤与激烈的复仇欲。"
    translate None chapter_thirteen_0150:
        "这几乎…让我对他们产生怜悯。"


    if ft_askcount == 5:

        jump choice_twentyfive_done

    window hide
    jump choice_twentyfive

label ftc2:
    translate None chapter_thirteen_0151:
        rs sad "最近奥克斯哈伯周边可有什么异常状况？"
    translate None chapter_thirteen_0152:
        ft "异常？小伙子，我见过的怪事可不少。"
    translate None chapter_thirteen_0153:
        ft "墙皮才刷了不到两月就开始剥落。够奇怪吧。"
    translate None chapter_thirteen_0154:
        ft "昨天早晨的鸟儿往西飞而不是往东飞。真稀奇。"
    translate None chapter_thirteen_0155:
        ft "最奇怪的莫过于一个男孩不问真正想知道的事，反而对我提出些模糊的问题。"
    translate None chapter_thirteen_0156:
        rs sur "....."
    translate None chapter_thirteen_0157:
        rs sad "那么…你见过…超自然的东西吗？"
    translate None chapter_thirteen_0158:
        ft "看吧。"
    translate None chapter_thirteen_0159:
        ft "顺便说，生活中的大多数事情本来就不自然。"
    translate None chapter_thirteen_0160:
        l ann "你能别废话了吗？"
    translate None chapter_thirteen_0161:
        rs wor "莱奥斯！"
    translate None chapter_thirteen_0162:
        ft "…至于你的问题，听说有个黑眼睛的男人夜行觅食。没人见过他，但有人感受过他的存在。"
    translate None chapter_thirteen_0163:
        f sad "黑眼睛的男人？"
    translate None chapter_thirteen_0164:
        ft "黑眼睛，以及同样黑暗的灵魂。"
    translate None chapter_thirteen_0165:
        "这是什么意思？"

    if ft_askcount == 5:
        jump choice_twentyfive_done

    window hide
    jump choice_twentyfive

label ftc3:
    translate None chapter_thirteen_0166:
        rs sad "其实…我有东西要给你看…"
    translate None chapter_thirteen_0167:
        "我从口袋里掏出闪亮的耳环。令人惊讶的是，虽然是在尸体旁发现的，它却崭新如初。"
    translate None chapter_thirteen_0168:
        "我轻轻把耳环递给那女人，她好奇地打量着。"
    translate None chapter_thirteen_0169:
        ft "你递来的这件饰品萦绕着污秽能量。在哪找到的？"
    translate None chapter_thirteen_0170:
        rs sad "我..觉得可能是某个受害者的。在一具腐烂得几乎认不出的尸体旁发现的。能告诉我佩戴者的事吗？"
    translate None chapter_thirteen_0171:
        ft "我并非全知全能，年轻人。"
    translate None chapter_thirteen_0172:
        rs sad "求你了？任何线索都行。"
    translate None chapter_thirteen_0173:
        ft "..."
    translate None chapter_thirteen_0174:
        ft "佩戴者…是位二十多岁的年轻女士。来自造访奥克斯哈伯的富裕家庭。"
    translate None chapter_thirteen_0175:
        rs sur "你怎么知道的？能看见她的灵魂还是怎样？"
    translate None chapter_thirteen_0176:
        ft "何必寻魂？明眼人都能看出这种简单事实。耳环款式适合年轻女性，在奥克斯哈伯很少有人买得起这么大钻石。估计是官员之女。"
    translate None chapter_thirteen_0177:
        ft "还有…"
    translate None chapter_thirteen_0178:
        $ about_FTAcc._text.append("我给她看之前在尸体旁找到的耳环，她说上面环绕着污秽能量。说原主人遭受过难以想象的痛苦。")
        ft "她经历过{a=set_entry:enc_mysteries->about_FTAcc}{color=#87CEEB}痛苦{/color}{/a}。这点我很确定。"
    translate None chapter_thirteen_0179:
        rs sad "谢谢…这确实很有用。"


    if ft_askcount == 5:
        jump choice_twentyfive_done

    window hide
    jump choice_twentyfive

label ftc4:
    translate None chapter_thirteen_0180:
        rs sur "噢…我读到些怪事，或许你有所耳闻。"
    translate None chapter_thirteen_0181:
        rs sad "我找到一本日记—孩子的日记。末尾处那孩子突然变了，不断写着有东西\"不肯离开\"，在对他说悄悄话。字里行间充满恐惧。你听说过这种事吗？"
    translate None chapter_thirteen_0182:
        "她的脸色阴沉下来，话语停顿了片刻。"
    translate None chapter_thirteen_0183:
        l sur "你什么时候发现那本儿童日记的？"
    translate None chapter_thirteen_0184:
        rs sad "昨晚—在诺克斯家我住的房间里。没写是谁写的，但内容听起来有点…瘆人。"
    translate None chapter_thirteen_0185:
        ft "我…没法替你解读那些话的含义。我没法像那样窥探别人的心思，不过…"
    translate None chapter_thirteen_0186:
        ft "至少可以肯定，写下这些的是个深受困扰的孩子，但也可能是更严重的情况。"
    translate None chapter_thirteen_0187:
        "更严重的情况…我不太明白她的意思，但听起来不妙。"


    if ft_askcount == 5:
        jump choice_twentyfive_done

    window hide
    jump choice_twentyfive


label ftc5:
    translate None chapter_thirteen_0188:
        rs sad "你对穆拉诺家族了解多少？特别是诺克斯·穆拉诺。"
    translate None chapter_thirteen_0189:
        ft "穆拉诺家族？当然人尽皆知。多亏他们，奥克斯哈伯才有了前所未有的繁荣。"
    translate None chapter_thirteen_0190:
        "我望着占卜师居住的残破老屋。繁荣？呵。"
    translate None chapter_thirteen_0191:
        ft "…但你长着眼睛。实际上，他们确实为自己赚取了大量财富，让奥克斯哈伯声名远扬，但对我们这种人没什么帮助。"
    translate None chapter_thirteen_0192:
        ft "不过，他们的遭遇确实悲惨。我挺同情那个可怜的男孩。"
    translate None chapter_thirteen_0193:
        rs sur "悲惨？发生了什么？"
    translate None chapter_thirteen_0194:
        ft "穆拉诺家的少爷年纪轻轻就不得不接替父母的重任。他连当个孩子的权利都没有。"
    translate None chapter_thirteen_0195:
        f sad "他父母怎么了？"
    translate None chapter_thirteen_0196:
        ft "这不是明摆着的吗？他们被杀了，被奥克斯哈伯街头游荡的东西猎杀了。"
    translate None chapter_thirteen_0197:
        ft "如今那男孩深居豪宅，几乎不露面。但名字我记不清了。是叫诺克斯…？有点耳熟。"
    translate None chapter_thirteen_0198:
        rs sad "他们被杀了？可他明明说他们…"
    translate None chapter_thirteen_0199:
        $ about_FTAcc._text.append("显然诺克斯的父母多年前就死了，尽管他告诉我们他们只是出门在外。杀害他们的凶手如今仍在街头游荡。据说穆拉诺家的少爷一直深居豪宅，极少露面。")
        c ang "他说他们是{a=set_entry:enc_mysteries->about_FTAcc}{color=#87CEEB}出门在外{/color}{/a}。唔…有意思。"

    if ft_askcount == 5:
        jump choice_twentyfive_done

    window hide
    jump choice_twentyfive


label choice_twentyfive_done:
    translate None chapter_thirteen_0200:
        rs sad "这…值得深思。真是太感谢您了，夫人。"
    translate None chapter_thirteen_0201:
        ft "等等，在你走之前…"
    translate None chapter_thirteen_0202:
        ft "我能感受到你内心的某些东西，但水域拒绝向我透露这个信息。让我就这样告诉你：不要害怕你的未来，也不要害怕命运为你安排的路径。"
    translate None chapter_thirteen_0203:
        rs sad "谢谢，但是…谁能与命运抗争？我只能接受被分配的一切。"
    translate None chapter_thirteen_0204:
        ft "孩子，你说得好像你的命运无法改变似的。不要坐以待毙任由命运摆布。抓紧缰绳，去你想去的地方。没人能阻止你。"


    scene bg oxhabor day big with dissolve:
        size(1920, 1080)

    translate None chapter_thirteen_0205:
        "我们告别了那位老妇人，转身沿着来时的路返回。她给了很多值得思考的东西，而且她看起来…很有智慧。既智慧又仁慈。"
    translate None chapter_thirteen_0206:
        "现在，接下来该去哪儿？"


    if ox_fin == 2:
        jump choice_twentythree_done
    window hide
    jump ox_investigation

label oxhabor_nox:
    show raen n dim sad at cenleft
    show cyne n dim neu at cenright
    show leos n dim ang at farright
    show fawn n dim sad at farleft
    with dis
    translate None chapter_thirteen_0207:
        rs "…我想我有些问题要问诺克斯。昨晚我们没机会好好交谈。"
    translate None chapter_thirteen_0208:
        f "他肯定知道得比告诉我们的要多。"
    translate None chapter_thirteen_0209:
        show cyne n mis with dis
        c "好吧，我可不介意再见他那样的帅哥。老实说，长着那样一张脸，他干嘛窝在这种小镇里？他该去演艺圈什么的。"
    translate None chapter_thirteen_0210:
        show leos n ann with dis
        l "诸神啊，你能不能闭嘴？别把什么都当儿戏。我是不是得跪下来求你认真对待这事？"
    translate None chapter_thirteen_0211:
        show cyne n sur with dis
        c "对不起！我意识到我从来没问过…你那副一本正经的样子到底要持续多久？如果我们都像你这么严肃，那得多无聊啊？你就不能试着放松点吗？"
    translate None chapter_thirteen_0212:
        rs "…说正事。去哪儿找他？"
    translate None chapter_thirteen_0213:
        l "最明显的地方就是他家。"
    translate None chapter_thirteen_0214:
        rs "那我们先去那里看看吧。"

    hide raen
    hide leos
    hide fawn
    hide cyne


    show bg oxhabor day big:
        xpos -0.08 ypos -0.75 zoom 1.87
        linear 55.0 xpos -0.83
    with dissolve
    translate None chapter_thirteen_0215:
        "我们快步穿行在前往诺克斯宅邸的街道上。昨晚我们走过同样的路，但在黑暗中显得阴森得多。白天走起来倒是相当惬意。"
    translate None chapter_thirteen_0216:
        "接近庄园时，我们注意到大门关着但没上锁。推开门走进去时，门发出吱呀的声响。"
    translate None chapter_thirteen_0217:
        "莱奥斯敲了敲门，但没人应答。"
    translate None chapter_thirteen_0218:
        f neu "我们该去别处找找，还是直接进去…？"
    translate None chapter_thirteen_0219:
        c hap "也许他还在睡觉。莱奥斯，再用点力敲门。让整条街都听见。"
    translate None chapter_thirteen_0220:
        l smi "你是想让我把门砸成两半吗？"
    translate None chapter_thirteen_0221:
        c mis "不想，但我不介意你把我砸-"
    translate None chapter_thirteen_0222:
        rs sur "我去后院看看！"

    window hide dissolve

    scene bg ox garden with dissolve:
        xpos -0.1 ypos -0.44 zoom 1.25
        linear 35.0 xpos -0.5
    window show dissolve
    translate None chapter_thirteen_0223:
        "我脱离队伍，独自绕着宅邸外围散步。虽然花园某些角落略显荒芜，但与奥克斯哈伯其他地方相比仍显得气势恢宏。"
    translate None chapter_thirteen_0224:
        "在诺克斯庄园外，多数树木植被都濒临枯死，但此处的草坪与林木却格外繁茂。"
    translate None chapter_thirteen_0225:
        "继续前行来到宽阔的庭院。野生植物在这里肆意生长，一座古老喷泉突兀地矗立于葱茏之中。想来诺克斯并未雇佣园丁打理。 "
    translate None chapter_thirteen_0226:
        "转角处，我注意到有人跪伏在地。我便全程踮着脚尖，悄无声息地靠近那道身影。"
    translate None chapter_thirteen_0227:
        "他周围堆着小土丘。当我终于凑近能窥见他肩头前方时，我看清了。"
    translate None chapter_thirteen_0228:
        "一朵绝美的紫色花朵。"


    scene bg ox garden with dissolve
    show raen m dim sur at closeleft
    show nox m dim neu at closeright
    with dis

    translate None chapter_thirteen_0229:
        rs "你在干什么？"
    translate None chapter_thirteen_0230:
        show nox m sur at shake
        nox "啊！"
    translate None chapter_thirteen_0231:
        "他猛地从跪姿弹起，将某物藏于身后。"
    translate None chapter_thirteen_0232:
        show raen m smi with dis
        rs "抱歉吓到你了！我正在找你，猜想或许能在这儿遇见。"
    translate None chapter_thirteen_0233:
        show nox m sad with dis
        nox "你来这儿做什么？怎会知道我在此处？"
    translate None chapter_thirteen_0234:
        rs "只是想来找你谈谈。昨晚我们没能好好聊天。"
    translate None chapter_thirteen_0235:
        rs "不过我对眼下这事很感兴趣。你刚才是在栽种那株花吗？"
    translate None chapter_thirteen_0236:
        "他轻叹一声，放下藏在身后的物件—是把小铲子。"
    translate None chapter_thirteen_0237:
        nox "…..是的。老实说，没料到会被撞见。让你看到这般模样，实在惭愧。"
    translate None chapter_thirteen_0238:
        show raen m sur with dis
        rs "这般模样是指？"
    translate None chapter_thirteen_0239:
        nox "跪在泥地里。你大概觉得我很可笑吧。"
    translate None chapter_thirteen_0240:
        show raen m smi with dis
        rs "完全不。爱花有何不可？鲜花属于所有人。你该感到骄傲。毕竟若没有爱与呵护，这些花儿也不会盛开。"
    translate None chapter_thirteen_0241:
        rs "…..顺便说，它们很美。是什么品种？"
    translate None chapter_thirteen_0242:
        nox "紫色的风信子。家母最钟爱的花。"
    translate None chapter_thirteen_0243:
        rs "那她品味很好。你之前提过父母外出了对吧？"
    translate None chapter_thirteen_0244:
        $ about_NoxAcc.locked = False
        nox "是的，他们{a=set_entry:enc_mysteries->about_NoxAcc}{color=#DA70D6}因公出差{/a}{/color}。这段时间我勉强经营着家族产业。实在难以想象若没有他们，公司该如何维系。"
    translate None chapter_thirteen_0245:
        show raen m sur with dis
        rs "噢，确实。你们家族颇具影响力是吧？"
    translate None chapter_thirteen_0246:
        show nox m pen with dis
        nox "人们都这么说，但我很怀疑。如果我们只是个普通家庭，我确信我的人生会大不相同。"
    translate None chapter_thirteen_0247:
        rs "但你能住在这么酷的大房子里！我打赌你小时候一定有很多朋友。"
    translate None chapter_thirteen_0248:
        nox "只有一个。说真的，他让我想起你很多。"
    translate None chapter_thirteen_0249:
        rs "真的吗？哪些方面？"
    translate None chapter_thirteen_0250:
        nox "嗯…有点儿勇敢，非常善良，虽然他比你…固执得多。"
    translate None chapter_thirteen_0251:
        rs "听上去是个不错的人。"
    translate None chapter_thirteen_0252:
        f sur "雷恩？"
    translate None chapter_thirteen_0253:
        c sur "雷—恩—，你在哪—里—？"
    translate None chapter_thirteen_0254:
        rs "啊，大伙儿，我在这儿！"
    translate None chapter_thirteen_0255:
        "莱奥斯、赛恩和福恩从转角处走过来，朝我们这边靠近。"
    translate None chapter_thirteen_0256:
        l neu "你知道的，要是找到他了可以告诉我们一声。"
    translate None chapter_thirteen_0257:
        show raen m smi with dis
        rs "抱歉抱歉！我们只是稍微互相了解一下。"
    translate None chapter_thirteen_0258:
        l pis "我们是来寻求答案的，不是来交朋友的。"
    translate None chapter_thirteen_0259:
        c sur "别这么冷漠，莱奥斯。让这可怜的孩子交些朋友吧。"
    translate None chapter_thirteen_0260:
        rs "啊哈哈…抱歉诺克斯。其实我们想询问些关于谋杀案的事，昨晚没多少时间讨论。你介意吗？"
    translate None chapter_thirteen_0261:
        nox "我…我知道的不多，但会尽力帮忙。"
    translate None chapter_thirteen_0262:
        show raen m neu with dis
        rs "那么…."

    window hide


##   search_paper     body_earring   search_books

    if search_paper and body_earring and search_books:
        $ nox_askcount += 3

    if search_paper == False and body_earring and search_books:
        $ nox_askcount += 2

    if search_paper and body_earring == False and search_books:
        $ nox_askcount += 2

    if search_paper and body_earring and search_books == False:
        $ nox_askcount += 2

    if search_paper == False and body_earring == False and search_books:
        $ nox_askcount += 1

    if search_paper and body_earring == False and search_books == False:
        $ nox_askcount += 1

    if search_paper == False and body_earring and search_books == False:
        $ nox_askcount += 1

    window hide


label choice_twentysix:
    menu:
        "我的名字出现了…" if nox_askname:
            window show dissolve
            $ nox_askcount += 1
            $ nox_enough = True
            $ nox_askname = False
            jump noxc1

        "通常的死因是什么？" if nox_askcause:
            window show dissolve
            $ nox_askcount += 1
            $ nox_enough = True
            $ nox_askcause = False
            jump noxc2

        "多告诉我些卡斯皮安的事" if nox_askcaspian:
            window show dissolve
            $ nox_askcount += 1
            $ nox_enough = True
            $ nox_askcaspian = False
            jump noxc3

        "我发现了张奇怪的画…" if nox_askdrawing and search_paper == False: #if looked at paper the night before
            window show dissolve
            $ nox_askcount += 1
            $ nox_enough = True
            $ nox_askdrawing = False
            jump noxc4

        "你以前见过这个耳环吗？" if nox_askearring and body_earring == False: #looked at body first + looked at earring the night before
            window show dissolve
            $ nox_askcount += 1
            $ nox_enough = True
            $ nox_askearring = False
            jump noxc5

        "我房间里有本日记" if nox_askdiary and search_books == False: #if checked diary the night before
            window show dissolve
            $ nox_askcount += 1
            $ nox_enough = True
            $ nox_askdiary = False
            jump noxc6

        "问够了" if nox_enough:
            window show dissolve
            jump choice_twentysix_done


label noxc1:
    show raen m sad with dis
    translate None chapter_thirteen_0263:
        rs "首先…我想更多了解那些反复出现的名字。你知道它们是怎么出现的吗？"
    translate None chapter_thirteen_0264:
        show nox m pen with dis
        nox "没人知道。它们就在夜间凭空出现。"
    translate None chapter_thirteen_0265:
        l smi "就没人尝试过，比如说，守夜看是谁干的？"
    translate None chapter_thirteen_0266:
        nox "当然试过，但市长最后还是放弃了。他根本不在意这些事。"
    translate None chapter_thirteen_0267:
        show raen m sur with dis
        rs "他怎么可以不在意？"
    translate None chapter_thirteen_0268:
        nox "我不知道。"
    translate None chapter_thirteen_0269:
        rs "好吧，如果你不知道这个…名字出现后多久人会失踪？"
    translate None chapter_thirteen_0270:
        nox "多久？据我所知通常当天或隔天。"
    translate None chapter_thirteen_0271:
        show raen m sad with dis
        rs "...."
    translate None chapter_thirteen_0272:
        rs "我问是因为…我们去查看时…上面有我的名字。"
    translate None chapter_thirteen_0273:
        show nox m sur with dis
        nox "什么？！"
    translate None chapter_thirteen_0274:
        show nox m sad with dis
        nox "不，不，不…你肯定在开玩笑…别再来了…"
    translate None chapter_thirteen_0275:
        rs "但我保证，在可能发生任何事之前，我们会解决这个问题。"
    translate None chapter_thirteen_0276:
        nox "看到那个你怎么还能留在这里？！"
    translate None chapter_thirteen_0277:
        rs "…找到卡斯皮安对我就是如此重要。"
    translate None chapter_thirteen_0278:
        nox "….我很抱歉。我不知道该如何向你描述我让你陷入这般境地有多么懊悔…但必须结束了。我不能再这样活在恐惧中，其他任何人也不该如此。"


    if nox_askcount == 6:
        jump choice_twentysix_done

    window hide
    jump choice_twentysix

label noxc2:
    translate None chapter_thirteen_0279:
        rs "….你见过任何一具尸体吗？"
    translate None chapter_thirteen_0280:
        nox "….没有，但我听说过。听说有时它们支离破碎、面目全非，有时又像在安详沉睡。我不知道哪种说法是真的。"


    if ox_body == False:
        jump noxc2ver1

    jump noxc2ver2

label noxc2ver1:
    translate None chapter_thirteen_0281:
        rs "我…我们…实在难以启齿，但我们发现了一具尸体。坦白说惨不忍睹。骨头全碎了，还有虐待痕迹，至少莱奥斯是这么说的。"
    translate None chapter_thirteen_0282:
        rs "但即便调查过后，我还是不确定具体死因。你知道可能是什么吗？"
    translate None chapter_thirteen_0283:
        show nox m pen with dis
        nox "我…完全没头绪…为什么会有人要折磨别人呢？"
    translate None chapter_thirteen_0284:
        l neu "折磨人的理由很多，但这些伤痕太过分了。只能是为了取乐。"

    window hide

    menu:
        "询问脖子上的血迹":
            $ bloodonneck = True
            window show dissolve
            jump noxc2blood


        "别问":
            window show dissolve
            jump noxc2noblood

label noxc2blood:
    translate None chapter_thirteen_0285:
        rs "很多伤痕都很诡异。缺失的手臂、脱臼的下巴、断裂的骨头…但最奇怪的是那块血渍。"
    translate None chapter_thirteen_0286:
        rs "破布的衣衫其他部分都很干净，唯独衣领深红一片。血迹只集中在那里。"
    translate None chapter_thirteen_0287:
        show nox m sur with dis
        nox "..!"
    translate None chapter_thirteen_0288:
        nox "也许是她下巴断裂时留下的？"
    translate None chapter_thirteen_0289:
        $ about_NoxAcc._text.append("我们发现尸体的事本不该让诺克斯知道，但他却用\"她\"来指代尸体。")
        c sur "{a=set_entry:enc_mysteries->about_NoxAcc}{color=#87CEEB}她？{/color}{/a}"
    translate None chapter_thirteen_0290:
        nox "什么？我只是随口猜测…"
    translate None chapter_thirteen_0291:
        c neu "为什么会这么假设？我们根本没透露过性别。"
    translate None chapter_thirteen_0292:
        show nox m sad with dis
        nox "这…只是口误罢了。"
    translate None chapter_thirteen_0292b:
        rs "明白了…我会继续调查这点。"

    if nox_askcount == 6:
        jump choice_twentysix_done

    window hide
    jump choice_twentysix

label noxc2noblood:
    translate None chapter_thirteen_0293:
        rs "所以你不清楚常见的死因？"
    translate None chapter_thirteen_0294:
        nox "抱歉，我什么都不知道。"


    if nox_askcount == 6:
        jump choice_twentysix_done

    window hide
    jump choice_twentysix

label noxc2ver2:
    translate None chapter_thirteen_0295:
        rs "听说镇郊发现了一具尸体，我们正打算去查看。你知道些什么吗？"
    translate None chapter_thirteen_0296:
        nox "我是听说发现了一具，但没亲自调查。其实也不是刚死的，听说在那里有段时日了。"
    translate None chapter_thirteen_0297:
        l smi "那我可要期待那股气味了。"
    translate None chapter_thirteen_0298:
        show raen m sur with dis
        rs "通常就是这样任其腐烂吗？"
    translate None chapter_thirteen_0299:
        nox "虽然不总是如此…但郊区的许多房屋确实荒废已久。由于无人居住，自然也就没人会被那些恶臭打扰，所以近期内不太可能有人去清理那些地方。"
    translate None chapter_thirteen_0300:
        c hap "哦，哦，我有个问题。"
    translate None chapter_thirteen_0301:
        nox "说吧。"
    translate None chapter_thirteen_0302:
        c neu "这些谋杀案已经持续好—久—了，对吧？现在肯定有人发现凶手的作案模式了吧。"
    translate None chapter_thirteen_0303:
        rs "什么…模式？"
    translate None chapter_thirteen_0304:
        c neu "我们生来都带有习惯性行为特征。他是不是有偏好的杀人方式？尸体通常都是怎么被发现的？"
    translate None chapter_thirteen_0305:
        show nox m pen with dis
        nox "这个…我…说实话我也不清楚。有些尸体被发现时已经搁置太久，根本无法辨别死因。"
    translate None chapter_thirteen_0306:
        f sad "难道不该有人核查这些吗？这里的人难道对同胞的死亡都无动于衷？"
    translate None chapter_thirteen_0307:
        nox "我想他们已经放弃希望了。这种情况持续太久，又无人能够阻止…就像人们已经学会与死亡共存。"
    translate None chapter_thirteen_0308:
        show raen m sad with dis
        rs "这太可怕了…"
    translate None chapter_thirteen_0309:
        show nox m sad with dis
        $ about_NoxAcc._text.append("他提到尸体通常会被放任腐烂，很少得到清理。他说这里的人已经接受现实—他们中的许多人终将死去。")
        nox "{a=set_entry:enc_mysteries->about_NoxAcc}{color=#87CEEB}抱歉{/color}{/a}帮不上更多忙。"
    translate None chapter_thirteen_0310:
        rs "不用道歉，我们会继续调查的。"


    if nox_askcount == 6:
        jump choice_twentysix_done

    window hide
    jump choice_twentysix

label noxc3:
    translate None chapter_thirteen_0311:
        rs "其实这和案件无关，但我想问问…能多告诉我些关于卡斯皮安的事吗？"
    translate None chapter_thirteen_0312:
        show nox m sur with dis
        nox "关于卡斯皮安？"
    translate None chapter_thirteen_0313:
        rs "你说过你们关系亲密对吧？我现在不是要问你他的去向，只是想多了解他。"
    translate None chapter_thirteen_0314:
        show nox m pen with dis
        nox "他…他就像是我的兄长。我一直渴望的那种大哥。他强大可靠，富有魅力又心地善良。虽然总想帮忙做家务，但从来都笨手笨脚的。"
    translate None chapter_thirteen_0315:
        nox "他不会做饭也不会打扫，但却擅长许多令人惊讶的事。只要他开口，所有人都会侧耳倾听。这才是他真正的力量—他能说服你相信任何事。"
    translate None chapter_thirteen_0316:
        nox "每到夜晚他就画画，但从不让我们看。我常从门缝偷看，他脸上总带着那种悲伤的神情。虽然从不肯给我看他的素描，但那一定是他深爱的事物。"
    translate None chapter_thirteen_0317:
        show nox m sad with dis
        nox "…希望他现在过得幸福。"
    translate None chapter_thirteen_0318:
        rs "听起来他是个好人。我…真的很希望能见到他。"
    translate None chapter_thirteen_0319:
        "诺克斯凝视着我的脸，似乎想说什么，但最终还是移开了目光。"
    translate None chapter_thirteen_0320:
        nox "…..我也是。我想他会很乐意见到你。"
    translate None chapter_thirteen_0321:
        rs "....?"


    if nox_askcount == 6:
        jump choice_twentysix_done

    window hide
    jump choice_twentysix

label noxc4:
    translate None chapter_thirteen_0322:
        rs "哦，现在我想起来了…"
    translate None chapter_thirteen_0323:
        rs "昨晚我在住的房间里发现了一些奇怪的东西。我不是故意窥探，但偶然发现了一堆文件。我找到一封奇怪的信，上面写着—"
    translate None chapter_thirteen_0324:
        show nox m neu with dis
        nox "….我知道你说的是哪封信。那是我母亲的，但我现在要告诉你 - 她精神不太正常。她写些奇怪的内容，但其实没有任何意义。"
    translate None chapter_thirteen_0325:
        rs "我还发现一张像是儿童画的画，但是—"
    translate None chapter_thirteen_0326:
        nox "小孩子什么都画。不代表什么意思。"
    translate None chapter_thirteen_0327:
        rs "..."
    translate None chapter_thirteen_0328:
        l ang "你知道吗，当你这么急着否定的时候，很难不让人觉得可疑。"
    translate None chapter_thirteen_0329:
        rs "莱奥斯！"
    translate None chapter_thirteen_0330:
        l ang "没错。当然这些东西可能毫无意义，但他甚至不让你把话说完。"
    translate None chapter_thirteen_0331:
        show nox m pen with dis
        nox "….抱歉。我只是不认为讨论我母亲的文件对调查有什么帮助。"
    translate None chapter_thirteen_0332:
        c hap "任何线索都有用！"
    translate None chapter_thirteen_0333:
        nox "…..好吧，那我会认真回答。"
    translate None chapter_thirteen_0334:
        $ about_NoxAcc._text.append("诺克斯承认昨晚在我房间发现的奇怪画作是他小时候画的。他说卡斯皮安离开后他感到迷茫，那幅画没有任何意义。他还提到我发现的那封信是他母亲写的，但她当时神志不清，所以不必在意。")
        nox "{a=set_entry:enc_mysteries->about_NoxAcc}{color=#87CEEB}那幅画是我的。{/color}{/a}小时候，我..在卡斯皮安离开后感到迷失。那对我来说是段艰难时期，我母亲…好吧，我觉得她写的东西都不是真心的。我想她是糊涂了。"
    translate None chapter_thirteen_0335:
        "谜团越来越多。他留给我的问题比答案还多。"


    if nox_askcount == 6:
        jump choice_twentysix_done

    window hide
    jump choice_twentysix

label noxc5:
    translate None chapter_thirteen_0336:
        "我在口袋里摸索着不到一小时前放进去的东西。"
    translate None chapter_thirteen_0337:
        "我慢慢把它拿给诺克斯看。"
    translate None chapter_thirteen_0338:
        rs "我们检查尸体时，我在死者附近的地上发现了这个耳环。你以前见过吗？"
    translate None chapter_thirteen_0339:
        "他用手指捏起耳环仔细查看。"
    translate None chapter_thirteen_0340:
        show nox m sad with dis
        nox "…..从未见过。"
    translate None chapter_thirteen_0341:
        rs "我们只找到这一个…你确定没见过另一个？"
    translate None chapter_thirteen_0342:
        nox "我怎么可能见过另一个？"

    window hide

    menu:
        "我在你家里找到了配对的另一只":
            $ nox_earringinroom = True
            window show dissolve
            jump noxc51

        "你说得对，你怎么会知道呢？":
            window show dissolve
            jump noxc52

label noxc51:
    translate None chapter_thirteen_0343:
        rs "……昨晚我在自己住的房间里找到了配对的那只。"
    translate None chapter_thirteen_0344:
        show nox m sur with dis
        nox "什么？！"
    translate None chapter_thirteen_0345:
        nox "你确定？这不可能。"
    translate None chapter_thirteen_0346:
        rs "我没带另一只来，但我确信它们是一对。"
    translate None chapter_thirteen_0347:
        nox "....."
    translate None chapter_thirteen_0348:
        show nox m pen with dis
        nox "这…一定是巧合。没错。肯定是我妈妈不小心把她的首饰落在那里了。"
    translate None chapter_thirteen_0349:
        rs "只有一只耳环？"
    translate None chapter_thirteen_0350:
        nox "当时很黑对吧？最可能的情况是你没看到另一只罢了。"
    translate None chapter_thirteen_0351:
        "其余三人紧张地盯着那只耳环。我正要拿回来，诺克斯却把它放进了口袋。"
    translate None chapter_thirteen_0352:
        $ about_NoxAcc._text.append("我给他看了在尸体旁找到的耳环，并坚称昨晚在我房间里见过配对的另一只。他脸色煞白矢口否认，说我一定记错了。他拿走耳环，声称要交给镇长处理。")
        nox "我会把{a=set_entry:enc_mysteries->about_NoxAcc}{color=#87CEEB}这个{/color}{/a}带给镇长。他知道该怎么处理。"
    translate None chapter_thirteen_0353:
        show raen m sur with dis
        rs "...."
    translate None chapter_thirteen_0354:
        show nox m sad with dis
        rs "好吧…"


    if nox_askcount == 6:
        jump choice_twentysix_done

    window hide
    jump choice_twentysix

label noxc52:
    translate None chapter_thirteen_0355:
        rs "…不，你是对的。我不确定你怎么会知道这件事。对此我很抱歉。"
    translate None chapter_thirteen_0356:
        nox "没关系。"


    if nox_askcount == 6:
        jump choice_twentysix_done

    window hide
    jump choice_twentysix

label noxc6:
    translate None chapter_thirteen_0357:
        rs "我…我知道这听起来可能很奇怪，但是昨晚在我房间的那本日记…是你的吗？"
    translate None chapter_thirteen_0358:
        show nox m sur with dis
        nox "日记？"
    translate None chapter_thirteen_0359:
        rs "…里面提到了卡斯皮安，但是…"
    translate None chapter_thirteen_0360:
        nox "那么你读了？"
    translate None chapter_thirteen_0361:
        rs "….对不起.."
    translate None chapter_thirteen_0362:
        show nox m pen with dis
        nox "不要紧。事已至此。"
    translate None chapter_thirteen_0363:
        rs "我得承认，它最后变得有点…奇怪。阴暗。"
    translate None chapter_thirteen_0364:
        nox "…我在那本日记里写东西，因为那是我唯一能表达感受的方式。"
    translate None chapter_thirteen_0365:
        nox "那时，我正处于挣扎之中。我的父母把我当成了某种救世主，但我感受到的只有迷失。"
    translate None chapter_thirteen_0366:
        rs "你说有什么东西把你困在地下室三天是什么意思？这是你编造的吗？"
    translate None chapter_thirteen_0367:
        nox "不，这是真的。这种事发生过不止一次。"
    translate None chapter_thirteen_0368:
        show raen m sur with dis
        rs "谁会那样做啊？！"
    translate None chapter_thirteen_0369:
        show nox m sad with dis
        nox "我…我没法谈论这个。生理上就说不出口。"
    translate None chapter_thirteen_0370:
        rs "…..你写到有个人不愿离开。是谁？"
    translate None chapter_thirteen_0371:
        $ about_NoxAcc._text.append("我拿出了前一晚找到的日记，但他似乎不太高兴我读了它。我问内容是否属实—确实如此。他说有多次他被关在地下室里好几天，他的父母把他当成某种救世主。当我问他写到的某人\"永远不会离开\"是什么意思时，他说那个永远不会离开的人是\'诺克斯\'。")
        nox "….{a=set_entry:enc_mysteries->about_NoxAcc}{color=#87CEEB}诺克斯{/color}{/a}。他永远不会离开。"
    translate None chapter_thirteen_0372:
        rs "....?"
    translate None chapter_thirteen_0373:
        "我不太明白他的意思…"
    translate None chapter_thirteen_0374:
        nox "…抱歉，关于这个我说不出太多。"


    if nox_askcount == 6:
        jump choice_twentysix_done

    window hide
    jump choice_twentysix

label choice_twentysix_done:
    translate None chapter_thirteen_0375:
        nox "我们结束了吗？这开始感觉像审讯了。"
    translate None chapter_thirteen_0376:
        show raen m sur with dis
        rs "抱歉，我有点失控了…"
    translate None chapter_thirteen_0377:
        nox "…没关系。我会尽力帮你，但…我有点束手束脚。"
    translate None chapter_thirteen_0378:
        c neu "嗯…"
    translate None chapter_thirteen_0379:
        c hap "我想这么有影响力的公司继承人一定很忙。能有时间园艺真好。"
    translate None chapter_thirteen_0380:
        "诺克斯疲倦地打量着赛恩，张嘴似乎要回应，但还没说出一个字就又闭上了。"
    translate None chapter_thirteen_0381:
        show raen m sad with dis
        rs "赛恩…我想我们盘问得够多了。诺克斯，谢谢。"
    translate None chapter_thirteen_0382:
        c hap "好吧好吧。回头见，\"诺克斯\"。"
    translate None chapter_thirteen_0383:
        "另外三人转身离开，但我的目光又在诺克斯身上停留了片刻。独自站在那株娇小的花前…他看起来几乎受了伤。被抛弃的样子。孤独的样子。"
    translate None chapter_thirteen_0384:
        rs "喂…"
    translate None chapter_thirteen_0385:
        show nox m sur with dis
        rs "…我们晚点见，好吗？"
    translate None chapter_thirteen_0386:
        show nox m hap with dis
        "他略显惊讶，随后微微笑了。"
    translate None chapter_thirteen_0387:
        nox "…嗯。后会有期。"


    hide nox
    hide leos
    scene bg ox garden:
        xpos -0.1 ypos -0.44 zoom 1.25
        linear 35.0 xpos -0.5
    with dissolve
    translate None chapter_thirteen_0388:
        "我转身追上其他三人。"
    translate None chapter_thirteen_0389:
        l ann "整件事都很可疑。"
    translate None chapter_thirteen_0390:
        c neu "完全同意。他看起来不算有罪，但确实隐瞒着什么。"
    translate None chapter_thirteen_0391:
        rs sad "...."
    translate None chapter_thirteen_0392:
        rs sad "我不想怀疑他。他看起来真的很…孤独。我只是想帮他。"
    translate None chapter_thirteen_0393:
        f sad "他一定走投无路了…你们不觉得吗？"
    translate None chapter_thirteen_0394:
        rs sur "什么意思？"
    translate None chapter_thirteen_0395:
        f sad "他在向完全陌生的人求助…我们肯定是他最后的希望了…"
    translate None chapter_thirteen_0396:
        rs sad "是啊…你说得对…"


    scene bg oxhabor day big with dissolve:
        size(1920, 1080)

    translate None chapter_thirteen_0397:
        "我们沿小路返回城镇，一路思考接下来去哪里调查。"

    if ox_fin == 2:
        jump choice_twentythree_done
    window hide
    jump ox_investigation


label oxhabor_body:
    show raen n dim sad at cenleft
    show cyne n dim neu at cenright
    show leos n dim neu at farright
    show fawn n dim sad at farleft
    with dis

    translate None chapter_thirteen_0398:
        rs "出于某些原因，这是我最不愿追查的线索，但可能也最重要…"
    translate None chapter_thirteen_0399:
        rs "趁他们还没清理现场…我们去找那具尸体吧。"
    translate None chapter_thirteen_0400:
        f "这真的是个好主意吗？听起来…很危险…"
    translate None chapter_thirteen_0401:
        "我瞥向莱奥斯的方向，但他只是耸了耸肩。一如既往地\"有帮助\"。"
    translate None chapter_thirteen_0402:
        "我只是想要些安慰。本来就是他先提议的。"
    translate None chapter_thirteen_0403:
        rs "不，可能不是。这个想法很可怕，但是…"
    translate None chapter_thirteen_0404:
        rs "…我们需要看看我们将要面对什么。"
    translate None chapter_thirteen_0405:
        f "…如果你确定的话。"
    translate None chapter_thirteen_0406:
        "我不确定。我完全不确定。"
    translate None chapter_thirteen_0407:
        "最好现在先装出一副强硬的样子。"
    translate None chapter_thirteen_0408:
        l "…我们走吧。站在这里什么也干不成。"
    translate None chapter_thirteen_0409:
        c "我听说尸体是在哪里被发现的，我来带路。跟我来！"

    window hide dissolve

    scene bg ox alley with dissolve:
        xpos 0.64 ypos 1.17 xanchor 0.5 yanchor 1.0 zoom 1.96
        linear 35.0 ypos 1.94

    window show dissolve
    translate None chapter_thirteen_0410:
        "赛恩几乎是跳跳蹦蹦地穿过街道。他是如此无忧无虑…在我们寻找一具尸体的时候，他怎么可以这么轻松？"
    translate None chapter_thirteen_0411:
        "莱奥斯面无表情。他似乎也毫不惊讶，但我想这是有道理的。以他的工作性质，肯定见过不少尸体…"
    translate None chapter_thirteen_0412:
        "这几天我已经见过太多死亡了。希望这是最后一次。"
    translate None chapter_thirteen_0413:
        "我们在小巷间穿行，走在隐蔽的后街上。走得越远，周围就越安静。"

    window hide dissolve

    scene bg oxhabor day big with dissolve:
        xpos 0.72 ypos 1.43 xanchor 0.5 yanchor 1.0 zoom 1.18  xzoom -1
    window show dissolve

    translate None chapter_thirteen_0414:
        "最后，我们来到了城镇边缘。街道裂缝间杂草丛生，门被微风吹开，向所有人敞开着。窗户都用木板封住，暴风雨前的天空只是加剧了我的紧张。"
    translate None chapter_thirteen_0415:
        "我全身的骨头都能感受到诡异的气息。我忍不住不断环顾四周，看看是否有人跟踪或监视我们。"
    translate None chapter_thirteen_0416:
        "我不喜欢这里。我不想待在这里。感谢众神还有其他三人陪伴，如果只有我一个人，我绝不会走得这么远。"

    show leos m dim neu at closeright
    show raen m sad dim at closeleft
    with dis

    translate None chapter_thirteen_0417:
        l "如果你想抛尸，这就是最佳地点。我们肯定快到了。"
    translate None chapter_thirteen_0418:
        f sur "你怎么知道？"
    translate None chapter_thirteen_0419:
        l "看看四周。虽然城里其他地方看似荒废，但没这么糟糕。"
    translate None chapter_thirteen_0420:
        "街上一个人都没有。无论我们转向哪个方向，都看不到生命的迹象。"
    translate None chapter_thirteen_0421:
        rs "又怎么了？"
    translate None chapter_thirteen_0422:
        show leos m smi with dis
        l "继续找。气味迟早会指引我们。"
    translate None chapter_thirteen_0423:
        f sad "你觉得凶手可能还在附近吗？"
    translate None chapter_thirteen_0424:
        l "也许吧。"
    translate None chapter_thirteen_0425:
        f sad "也许？！"
    translate None chapter_thirteen_0426:
        show leos m neu with dis
        l "说些安慰你的谎话毫无意义。我完全不清楚他们是否还在附近，但也有可能就在附近。"
    translate None chapter_thirteen_0427:
        "福恩向我靠近一步，脸上写满担忧。我和他感同身受，但这件事必须完成。"
    translate None chapter_thirteen_0428:
        c sad "雷～恩～，我好害怕！你要是不紧紧抱住我，我觉得自己就要活不下去了！"
    translate None chapter_thirteen_0429:
        show leos m ann with dis
        l "呃…你能闭嘴吗？要是凶手真的还在附近，现在他们完全知道我们在哪了。干得好啊，小鬼。"
    translate None chapter_thirteen_0430:
        c sur "小鬼？我个子是小，但我不是小孩。"
    translate None chapter_thirteen_0431:
        l "真的吗？你对着雷恩呜咽撒娇的样子可一点说服力都没有。"
    translate None chapter_thirteen_0432:
        c hap "好啦好啦，莱奥斯。我知道你嫉妒我能和雷恩这么亲近，但没必要闹情绪嘛。要是你用超级～可爱的态度请求，说不定雷恩也会让你依偎呢。"
    translate None chapter_thirteen_0433:
        f bla "...."
    translate None chapter_thirteen_0434:
        rs "行了，到此为止。我们继续搜查吧。"
    translate None chapter_thirteen_0435:
        show leos m neu with dis
        l "….看起来离这里不远了。"
    translate None chapter_thirteen_0436:
        "不远？他怎么知道的？"
    translate None chapter_thirteen_0437:
        "莱奥斯在前面带路，我们其余人跟在后面。刚走没多远，我们就闻到了那个熟悉的味道。"
    translate None chapter_thirteen_0438:
        "那种病态的甜腻气息…像盛夏阳光下腐烂的水果。我这辈子都不想再闻到…"
    translate None chapter_thirteen_0439:
        c sur "哇靠，臭死了。那是什么？"
    translate None chapter_thirteen_0440:
        fr "...."
    translate None chapter_thirteen_0441:
        l "你以为腐烂的尸体能有好闻的味道？虽然不想打击你，但这味道只会越来越糟。"
    translate None chapter_thirteen_0442:
        show leos m pen with dis
        "我艰难地咽了口唾沫，保持沉默。莱奥斯担忧地瞥了我一眼，但我避开了他的视线。"
    translate None chapter_thirteen_0443:
        l "….这可是你的主意。是你想来看个究竟的，现在可别怂了。"
    translate None chapter_thirteen_0444:
        f hur "你怎么…怎么能这么无动于衷…"
    translate None chapter_thirteen_0445:
        l "…不过是一具尸体。没什么好怕的。它不会突然蹦起来袭击我们。"
    translate None chapter_thirteen_0446:
        l "真要对比的话，对着一具尸体你反而能比面对大多数活人时更冷静。"
    translate None chapter_thirteen_0447:
        rs "..."
    translate None chapter_thirteen_0448:
        "就是一具尸体…也许他能这么想，但我做不到。那不只是一具尸体。那曾经是个人。"
    translate None chapter_thirteen_0449:
        l "快到了。应该就是这条路。"

    hide leos
    hide raen
    with dis

    translate None chapter_thirteen_0450:
        "他指着前面不远处的路。当我犹豫不决时，他从前方向我喊话。"
    translate None chapter_thirteen_0451:
        l smi "要是没胆量的话，你大可以在这里等着。"
    translate None chapter_thirteen_0452:
        c neu "既然我们已经走到这一步，连我都感兴趣了。但如果你想在这里等，我会陪你留下。"
    translate None chapter_thirteen_0453:
        f bla "……我们还是在一起吧。"
    translate None chapter_thirteen_0454:
        rs sad "……嗯。"
    translate None chapter_thirteen_0455:
        "我跟随莱奥斯继续沿着废弃的街道前进。大多数时候我们都保持着沉默，对环境过分警惕，但赛恩还是时不时忍不住开口。"
    translate None chapter_thirteen_0456:
        c hap "我感觉自己像个真正的探险家！太刺激了！"
    translate None chapter_thirteen_0457:
        rs con "是吗……？"
    translate None chapter_thirteen_0458:
        "我们每走一步，恶臭就变得更加强烈，直到完全难以忍受。"
    translate None chapter_thirteen_0459:
        "上次来时，气味没这么重。"
    translate None chapter_thirteen_0460:
        "我一直盯着地面。真希望能转身逃跑。其他人似乎都不怎么担心，连福恩也是。只有我这么软弱。"
    translate None chapter_thirteen_0461:
        "福恩拽了拽我的袖子，在我耳边低语。"
    translate None chapter_thirteen_0462:
        f sad "我也很害怕，但是……只要我们在一起，就不会有事。"
    translate None chapter_thirteen_0463:
        "听到他的话，我的心跳稍微平静了些。"
    translate None chapter_thirteen_0464:
        l neu "……就是这里。"
    translate None chapter_thirteen_0465:
        c sur "哇，这尸体肯定在这里有段时间了。"
    translate None chapter_thirteen_0466:
        "好，没问题。我们只需要检查线索，然后就能离开了。"
    translate None chapter_thirteen_0467:
        "勇敢点。"
    translate None chapter_thirteen_0468:
        $ about_DeadBody.locked = False
        "我稳住呼吸，向{a=set_entry:enc_mysteries->about_DeadBody}{color=#DA70D6}那具尸体{/color}{/a}迈出最后几步。"
    translate None chapter_thirteen_0469:
        "脚下的景象令人毛骨悚然。这具尸体几乎看不出人形了。我用手捂住鼻子，却挡不住那股气味。"
    translate None chapter_thirteen_0470:
        "大部分躯体已经开始腐烂。几乎没有了皮肤，仅存的灰白皮肤松垮地挂着，露出爬满蛆虫的腐肉。"
    translate None chapter_thirteen_0471:
        "头颅歪向一侧，几乎没剩多少头发。破烂肮脏的衣服让我立刻联想到他们曾经历过怎样的挣扎。骨头从撕裂的布料下戳出。"
    translate None chapter_thirteen_0472:
        "太可怕了。糟透了。这是我见过最恶心最悲惨的画面。每一次呼吸都吸入更多令人窒息的气味，但我又不能停止呼吸。即使捂住口鼻也无济于事。"
    translate None chapter_thirteen_0473:
        "我匆匆扫视了几眼尸体，但注意力总被头部吸引。那里有些不对劲。"
    translate None chapter_thirteen_0474:
        f sad "……少了条手臂。"
    translate None chapter_thirteen_0475:
        l neu "还不止这个。通常不会看到这么惨烈的场面。"
    translate None chapter_thirteen_0476:
        "莱奥斯跪在尸体旁仔细检查。赛恩俯身凑近，眼中闪烁着好奇的光芒。"
    translate None chapter_thirteen_0477:
        c mis "我想你可以说…没人愿意对他们\"伸出援手\"了。"
    translate None chapter_thirteen_0478:
        f bla "这一点都不好笑。现在不是开玩笑的时候。"
    translate None chapter_thirteen_0479:
        c mis "拜托，我只是想活跃下气氛。没必要对我剑拔弩张…或者继续也行，我不介意。"
    translate None chapter_thirteen_0480:
        f hur "…呃.."
    translate None chapter_thirteen_0481:
        "甚至连福恩都对赛恩发出嫌恶的声音。无视他们，我轻轻碰了碰莱奥斯的肩膀低声说。"
    translate None chapter_thirteen_0482:
        rs sad "…我觉得这一切都很可疑，但我不清楚…尸体…哪些是正常的？能给我解释下吗？"
    translate None chapter_thirteen_0483:
        "他仰头看了我一眼，又重新转向尸体。这次他既没有争辩也没辱骂我，而是平静地解释。"
    translate None chapter_thirteen_0484:
        l neu "…就像鼠崽子说的那样，少了一只手臂。你立马就会想是什么干的，什么时候发生的。"
    translate None chapter_thirteen_0485:
        l neu "没几个人有力气直接扯断手臂。是袭击时发生的吗？还是…在他们死后？我是说如果是后者，为什么？"
    translate None chapter_thirteen_0486:
        l "然后看这里。下巴松垮垮的。在这个腐烂阶段有时确实会这样，但看起来—是死前就造成的。"
    translate None chapter_thirteen_0487:
        "他指着衣服布料间戳出的那块泛黄骨头。"
    translate None chapter_thirteen_0488:
        l neu "还有这些。不是干净利落的断裂。骨头都碎了。"
    translate None chapter_thirteen_0489:
        l neu "这人不止是被杀，他们是被慢慢折磨致死的。"
    translate None chapter_thirteen_0490:
        rs sur "…你怎么能注意到所有这些…？"
    translate None chapter_thirteen_0491:
        l smu "用眼睛看的。没什么难推断的。"
    translate None chapter_thirteen_0492:
        rs sad "真是…老实说太可怕了。我不想再看下去了，但是…"
    translate None chapter_thirteen_0493:
        c neu "….但我们得再仔细检查。谁知道还藏着什么线索。"
    translate None chapter_thirteen_0494:
        f sad "这些伤势很可怕，但真正的死因是什么？"
    translate None chapter_thirteen_0495:
        l neu "很难判断。能对骨头造成这种损伤的力量绝对不小，可能是这个原因…也可能是更隐蔽的因素，比如中毒。"
    translate None chapter_thirteen_0496:
        c sur "没想到会看到你这么严肃。看来你知道的不少啊？"
    translate None chapter_thirteen_0497:
        l neu "算是吧。"
    translate None chapter_thirteen_0498:
        c sur "而你是被雇来追踪并杀死雷恩的，嗯…我猜你是个职业杀手之类的。"
    translate None chapter_thirteen_0499:
        rs neu "现在这不重要。我们再仔细看看。"


    if search_jewellery:
        $ body_searchcount += 1

    window hide

label choice_twentyseven:
    menu:
        "那条手臂到底去哪了…？" if body_arm:
            window show dissolve
            $ body_searchcount += 1
            $ body_enough = True
            $ body_arm  = False
            jump bodyc1

        "让我们看看颌骨" if body_jaw:
            window show dissolve
            $ body_searchcount += 1
            $ body_enough = True
            $ body_jaw = False
            jump bodyc2

        "碎骨可能很重要" if body_bones:
            window show dissolve
            $ body_searchcount += 1
            $ body_enough = True
            $ body_bones = False
            jump bodyc3

        "等等…那是耳环吗？我之前见过这个！" if body_earring and search_jewellery == False : #if looked at earring the night before
            window show dissolve
            $ body_searchcount += 1
            $ body_enough = True
            $ body_earring = False
            jump bodyc4

        "问够了" if body_enough:
            window show dissolve
            jump choice_twentyseven_done


label bodyc1:
    translate None chapter_thirteen_0500:
        rs neu "那么，我们来确认手臂是在这里被撕下还是之前就断了"
    translate None chapter_thirteen_0501:
        c neu "快速检查下周围也无妨"
    translate None chapter_thirteen_0502:
        f neu "会不会是动物叼走了？"
    translate None chapter_thirteen_0503:
        l neu "动物通常会叼走手臂吗？"
    translate None chapter_thirteen_0504:
        f neu "…有些会的"
    translate None chapter_thirteen_0505:
        rs sad "我们再快速复核一遍"
    translate None chapter_thirteen_0506:
        l smi "那就继续吧"
    translate None chapter_thirteen_0507:
        rs sur "你呢？"
    translate None chapter_thirteen_0508:
        l neu "我？我可不想浪费时间找什么胳膊。你们走的时候我会继续检查这里。总算能清静会儿了"
    translate None chapter_thirteen_0509:
        "真无礼…"
    translate None chapter_thirteen_0510:
        rs sad "你们两个来吗？"
    translate None chapter_thirteen_0511:
        c hap "听起来比跟莱奥斯干等着有趣"
    translate None chapter_thirteen_0512:
        f sad "…好吧，我也去"
    translate None chapter_thirteen_0513:
        "我们检查了周边区域，但一无所获。连血迹都没有。看来莱奥斯说得对，凶案不是在这儿发生的"
    translate None chapter_thirteen_0514:
        f sur "…四周什么都没有"
    translate None chapter_thirteen_0515:
        c sur "是啊，完全没线索"
    translate None chapter_thirteen_0516:
        rs sad "回去告诉莱奥斯吧。至少能排除这里是案发现场"
    translate None chapter_thirteen_0517:
        "我们沿原路返回。没找到断臂反而让我松了口气…我对手臂实在没什么好回忆…"
    translate None chapter_thirteen_0518:
        l smi "发现什么了吗？"
    translate None chapter_thirteen_0519:
        "莱奥斯从尸体旁抬起头，眼里闪过一丝得意"
    translate None chapter_thirteen_0520:
        rs sad "不…"
    translate None chapter_thirteen_0521:
        f sad "......"
    translate None chapter_thirteen_0522:
        $ about_DeadBody._text.append("我们搜寻了丢失的手臂或任何凶案痕迹，但毫无发现，连{a=set_entry:enc_mysteries->about_DeadBody}{color=#87CEEB}血迹{/color}{/a}都没有。莱奥斯说可能是天气冲毁了证据，但更可能是他们在别处私下遇害")
        c sur "连{a=set_entry:enc_mysteries->about_DeadBody}{color=#87CEEB}血迹{/color}{/a}都没有"
    translate None chapter_thirteen_0523:
        l neu "…这具尸体已经陈旧了。说不定他们确实死在这儿，证据被雨水冲走了。也可能事后被转移来的"
    translate None chapter_thirteen_0524:
        l smi "个人认为是被运来的。折磨他们的人很从容，而且乐在其中。私下行事更稳妥"


    if body_searchcount == 4:
        jump choice_twentyseven_done

    window hide dissolve
    jump choice_twentyseven

label bodyc2:
    translate None chapter_thirteen_0525:
        rs sad "…要怎么把整个下颌骨扯下来？"
    translate None chapter_thirteen_0526:
        l smi "何不试试看？"
    translate None chapter_thirteen_0527:
        "他从大腿抽出匕首指向尸体"
    translate None chapter_thirteen_0528:
        rs wor "你干什么！？"
    translate None chapter_thirteen_0529:
        l neu "凑近看清楚，白痴"
    translate None chapter_thirteen_0530:
        "他用刀锋拨开皮肉，进一步暴露头骨"
    translate None chapter_thirteen_0531:
        f sur "这是…断了？"
    translate None chapter_thirteen_0532:
        l neu "说断都轻了。根本是从关节窝里整个敲出来的"
    translate None chapter_thirteen_0533:
        c sur "他们脸上一定遭受了重击。"
    translate None chapter_thirteen_0534:
        f sad "……听起来很疼。"
    translate None chapter_thirteen_0535:
        "部分骨头开裂了，有裂缝和缺失的部分。只有威力巨大的东西才可能造成这种伤害。"
    translate None chapter_thirteen_0536:
        "莱奥斯继续用他的小刀四处探查。"
    translate None chapter_thirteen_0537:
        l neu "……还有几颗牙齿不见了。想必是被打掉的，除非他们本来就有缺牙。"
    translate None chapter_thirteen_0538:
        c neu "嗯…"
    translate None chapter_thirteen_0539:
        c mis "你觉得他们是不是…自不量力了？"
    translate None chapter_thirteen_0540:
        l neu "闭嘴。"
    translate None chapter_thirteen_0541:
        f hur "我…我觉得不该拿死者开玩笑…"
    translate None chapter_thirteen_0542:
        f sad "....."
    translate None chapter_thirteen_0543:
        "莱奥斯把匕首在高高的杂草上擦了擦，随后收回大腿侧面的刀鞘。"
    translate None chapter_thirteen_0544:
        l neu "…….那就有一种可能。头部遭受重击，导致失血过多。但其他伤势又是怎么回事？"
    translate None chapter_thirteen_0545:
        rs wor "这…太可怕了…"


    if body_searchcount == 4:
        jump choice_twentyseven_done

    window hide dissolve
    jump choice_twentyseven

label bodyc3:
    translate None chapter_thirteen_0546:
        rs sad "究竟什么能把所有骨头都打碎？"
    translate None chapter_thirteen_0547:
        "几根骨头刺出皮肤，不是开裂就是粉碎。肯定有什么东西打断了它们，会是什么呢？"
    translate None chapter_thirteen_0548:
        f sad "太残忍了…谁会这样对待一个人？"
    translate None chapter_thirteen_0549:
        rs sad "我不知道…"
    translate None chapter_thirteen_0550:
        l neu "结合其他伤势来看，完全说不通。除非…"
    translate None chapter_thirteen_0551:
        rs sur "除非什么？"
    translate None chapter_thirteen_0552:
        l pen "除非他们是被当成玩物来伤害的。"
    translate None chapter_thirteen_0553:
        "莱奥斯皱起眉头，显得很烦躁。"
    translate None chapter_thirteen_0554:
        f neu "可能是被重物砸中…或者有人跳到他们身上？我不确定。"
    translate None chapter_thirteen_0555:
        l "有可能。但我觉得我们猜不出来。除非找到凶手当面问清楚。"


    if body_searchcount == 4:
        jump choice_twentyseven_done

    window hide dissolve
    jump choice_twentyseven

label bodyc4:
    translate None chapter_thirteen_0556:
        "在层层污垢之下，我注意到有个东西在反光。它在阳光下闪闪发亮。"
    translate None chapter_thirteen_0557:
        rs sur "莱奥斯，给我把刀。"
    translate None chapter_thirteen_0558:
        "他二话不说递来一把。我用它迅速挖出那个闪闪发亮的小物件。"
    translate None chapter_thirteen_0559:
        "是一只耳环。"
    translate None chapter_thirteen_0560:
        rs sur "…….嗯？"
    translate None chapter_thirteen_0561:
        rs sur "这是…"
    translate None chapter_thirteen_0562:
        "我回想起昨晚。一只被遗弃的耳环和项链。看起来很像，但是同一款吗？现在提这个可能不合时宜。 "
    translate None chapter_thirteen_0563:
        l neu "那是什么？"
    translate None chapter_thirteen_0564:
        $ about_DeadBody._text.append("在尸体旁边我发现了一只耳环，看起来和我昨晚在房间里找到的很相配。")
        rs sad "…….{a=set_entry:enc_mysteries->about_DeadBody}{color=#87CEEB}一只耳环{/color}{/a}。说不定以后有用，所以…"
    translate None chapter_thirteen_0565:
        "我忍着恶心用指尖捏起它，放进口袋。记得提醒我之后把这条裤子烧了。"
    translate None chapter_thirteen_0566:
        "他们都用略带怀疑的目光看着我，但没有追问。"


    if body_searchcount == 4:
        jump choice_twentyseven_done

    window hide dissolve
    jump choice_twentyseven



label choice_twentyseven_done:
    show raen n dim sad at cenleft
    show cyne n dim neu at cenright
    show leos n dim neu at farright
    show fawn n dim sad at farleft
    with dissolve

    translate None chapter_thirteen_0567:
        rs "…….分析了这么多，我们还是不知道他们怎么死的。"
    translate None chapter_thirteen_0568:
        l "我们现在只能猜测。"
    translate None chapter_thirteen_0569:
        f "所以，我们知道凶手很残忍，但除此之外…"
    translate None chapter_thirteen_0570:
        l "警告…如果你还想保住胃里的东西，最好别往这边看。"
    translate None chapter_thirteen_0571:
        show raen n sur with dis
        rs "什么？为什么？"
    translate None chapter_thirteen_0572:
        l "我警告过你了。"
    play sound "sounds/sfx/fallonground3.ogg"

    show raen with hpunch
    show raen n hur
    show fawn n hur
    show cyne n sad
    with dis
    translate None chapter_thirteen_0574:
        "莱奥斯突然把尸体翻转过来，恶臭瞬间加剧了十倍。我咳嗽着喘不过气，福恩和赛恩捂住脸转开了头。"
    translate None chapter_thirteen_0575:
        rs "你…你在干什么？！"
    translate None chapter_thirteen_0576:
        "他没理我，仔细检查尸体新暴露的部位。等我停止咳嗽后，我屏住呼吸再次靠近。"
    translate None chapter_thirteen_0577:
        show raen n sur with dis
        rs "等等…这是什么？"
    translate None chapter_thirteen_0578:
        "现在头部不再低垂，我们可以看到他们颈部的衣物沾满了血迹。"
    translate None chapter_thirteen_0579:
        l "...."
    translate None chapter_thirteen_0580:
        $ about_DeadBody._text.append("最后莱奥斯彻底翻转尸体，我们终于注意到不寻常的地方—颈部周围有暗红色的污渍，但其他部位都没有。")
        l "{a=set_entry:enc_mysteries->about_DeadBody}{color=#87CEEB}颈部的血迹{/color}{/a}…但为什么呢？"
    translate None chapter_thirteen_0581:
        "莱奥斯继续检查尸体，但没发现其他有价值的线索。他从蹲姿站起身来，伸了个懒腰。"
    translate None chapter_thirteen_0582:
        l "这就是全部发现了。我们该离开这里了。"
    translate None chapter_thirteen_0583:
        c "我们怎么既了解到很多又似乎一无所获？"
    translate None chapter_thirteen_0584:
        show raen n sad with dis
        rs "看起来挺容易的。至少我很高兴能逃离这个味道。"


    scene bg oxhabor day big with dissolve:
        size(1920, 1080)

    translate None chapter_thirteen_0585:
        "我们快速顺着来路离开尸体。我有点想给他们举行体面的葬礼，但我们没时间了。"
    translate None chapter_thirteen_0586:
        "那么接下来…该去哪里调查？"

    if ox_fin == 2:
        jump choice_twentythree_done
    window hide
    jump ox_investigation
