image bg test:
    "eng 8.png"

#label test:
    #scene bg sv day with dissolve
    #"blah blah"
    #show raen mw sur cloak blush at right with dis
    #show cyne mw smi cloak blush at left with dis
    #show raen mw cloak smi at farright
    #show fawn mw blush cloak smi at farleft
    #show hone n neu at cenright


    #with dis
    #f c wemb"bexa smells"
    #rs c wemb "yes"
