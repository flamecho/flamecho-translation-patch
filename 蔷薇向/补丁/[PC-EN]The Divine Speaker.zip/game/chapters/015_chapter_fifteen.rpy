label chapter_fifteen_start:
    scene bg nox house night with dissolve
    show raen n dim sur at cenleft
    show leos n dim sur at farright
    show fawn n dim sur at farleft
    show cyne n dim sur at cenright
    with dis

    translate None chapter_fifteen_0001a:
        f "发生什么事了….？"

    show raen n dim sad with dis
    play music "sounds/bgm/sad.ogg" fadein 2.0

    translate None chapter_fifteen_0001:
        rs "这个…说来话长…但能见到你们三个我真是太开心了…"
    translate None chapter_fifteen_0002:
        "不知不觉间，泪水已夺眶而出。能活着…能再次见到朋友们…我实在太…太高兴了…"
    translate None chapter_fifteen_0003:
        show leos n dim emb with dis
        l "你这是怎么了？"
    translate None chapter_fifteen_0004:
        show cyne n dim hap with dis
        c "哇，他哭了！看来需要来个集体拥抱！"
    translate None chapter_fifteen_0005:
        show fawn n dim sad with dis
        f "我觉得现在不是时候—"
    translate None chapter_fifteen_0006:
        "赛恩不由分说地把莱奥斯和福恩拽过来，张开臂膀把我们所有人圈住。我也立即照做了。"
    translate None chapter_fifteen_0007:
        l "好了好了，够了吧。能告诉我到底发生了什么吗？"

    show leos n dim sur
    show fawn n dim sur
    show cyne n dim sur
    with dis

    translate None chapter_fifteen_0008:
        "该从何说起呢。我缓缓讲述了刚才发生的事，详细说明着。有时他们脸上写满怀疑，有时又露出哀伤。"
    translate None chapter_fifteen_0009:
        "从我口中说出的每个字都像在撒谎。事实上，连我自己都觉得难以置信。"
    translate None chapter_fifteen_0010:
        "但即便如此…他们依然专注地聆听每一个字。"
    translate None chapter_fifteen_0011:
        rs "所以…简单来说…我们认识的诺克斯其实是索伦，而诺克斯是恶魔，是神明。"
    translate None chapter_fifteen_0012:
        rs "我…本想帮他的。我想救他，但…这已经是我们能做到的最好结果了。"
    translate None chapter_fifteen_0013:
        show leos n dim neu with dis
        l "….偏偏是这个家伙冒出来。你来干什么？"
    translate None chapter_fifteen_0014:
        gr con "见到我不开心？"
    translate None chapter_fifteen_0015:
        l "…也不完全是，不过看在你救了他命的份上，我先收起对你的厌恶。"
    translate None chapter_fifteen_0016:
        gr con "不必夸我。要是我单独进去，你们后来找到的也会是我的尸体。"
    translate None chapter_fifteen_0017:
        "他指向那个桃红色头发的男人，对方正朝我们这边张望。"
    translate None chapter_fifteen_0018:
        pr sad "很遗憾是在这种情况下相识。要是在更好的场合…"
    translate None chapter_fifteen_0019:
        f "…你之前是…一只鸟？然后变成了人…？"
    translate None chapter_fifteen_0020:
        gr neu "说来话长，这里不是讨论的地方。"
    translate None chapter_fifteen_0021:
        show cyne n dim neu with dis
        c "你们是不是该正式自我介绍了？我不得不怀疑这不是普通\"旅客\"会牵扯进来的事。"
    translate None chapter_fifteen_0022:
        pr neu "我保证之后会好好解释一切。现在必须把诺克斯和索伦送去能帮忙的人那里，而要这么做就必须离开奥克斯哈伯。"
    translate None chapter_fifteen_0023:
        "当我们走到前门时，我吹灭了蜡烛放下。莫名觉得有些伤感…这会是这座房子里最后一支被点燃的蜡烛吗？最后一支被吹灭的？"
    translate None chapter_fifteen_0024:
        "索伦他…还能回来吗？"
    translate None chapter_fifteen_0025:
        "我们穿过门廊，步入奥克斯哈伯寒冷的街道。"

    window hide dissolve

    scene bg oxhabor night with dissolve:
        xpos 0.71 ypos 1.61 xanchor 0.5 yanchor 1.0 zoom 1.59
        linear 45.0 xpos 0.21 ypos 1.61 xanchor 0.5 yanchor 1.0 zoom 1.59
        linear 45.0 xpos 0.71 ypos 1.61 xanchor 0.5 yanchor 1.0 zoom 1.59
        repeat
    window show dissolve

    translate None chapter_fifteen_0026:
        "与索伦宅邸的压抑相比，外面的黑暗竟显得明亮。空气更加清新，更有生气。"
    translate None chapter_fifteen_0027:
        "经历这一切后，我长舒一口气。我做到了。福恩、莱奥斯和赛恩都平安无事。索伦…他还有一线希望。"
    translate None chapter_fifteen_0028:
        "我们穿过大街小巷，直到抵达主干道。"
    translate None chapter_fifteen_0029:
        rs sad "….这种感觉不怎么好，对吧？"
    translate None chapter_fifteen_0030:
        f sad "…是啊。不好…他一定觉得如此孤独，如此被遗弃…无人可依靠亦无人可倾诉…不论是诺克斯还是索伦…"
    translate None chapter_fifteen_0031:
        f "我…为他们两人感到难过。"
    translate None chapter_fifteen_0032:
        rs sad "我也是…"
    translate None chapter_fifteen_0033:
        rs sur "等一下…在离开前，我还有件事必须做。"
    translate None chapter_fifteen_0034:
        "我带领众人走向镇中心，来到村庄布告栏前。"
    translate None chapter_fifteen_0035:
        "名单最后…写着我的名字。雷恩。"


    scene bg oxhabor night:
        xpos 0.61 ypos 1.31 xanchor 0.5 yanchor 1.0 zoom 1.42
    show raen m dark sad
    with Dissolve(1.0)

    translate None chapter_fifteen_0036:
        rs "有人带着能写字的东西吗？"
    translate None chapter_fifteen_0037:
        gr neu "给。"
    translate None chapter_fifteen_0038:
        "在我的名字下方，我写下\"索伦·穆拉诺\"。"
    translate None chapter_fifteen_0039:
        "我凝视片刻，转身离开。"
    translate None chapter_fifteen_0040:
        "就此了结。是时候启程了。"

label Cynaculous:
    scene bg oxhabor night with dissolve
    show raen n dark sad at cenright
    show cyne n dark neu at farright
    show veras n dark neu1 at cenleft
    show illran n dark armsdown neu at farleft
    with dissolve
    $ about_Caspian._text = ["卡斯皮安曾是奥雷利亚卡维拉最后一位王子，本应加冕为王，直到他与整个王室遭遇不测。当莱奥斯提到他的尸体从未被找到，且斯塔格威奇有位老人将我错认成他时，我便踏上了寻找他的旅程。 \n \n事实证明，他经过斯塔格威奇后曾途经奥克斯哈伯，与索伦及其家人共同生活过一段时间，直到他们试图将他作为祭品献给恶魔诺克斯。在索伦帮助下逃脱后，他逃往了锡德卡汉。"]

    translate None chapter_fifteen_0041:
        rs "下一站是…锡德卡汉。索伦提到{a=set_entry:enc_people->about_Caspian}{color=#87CEEB}卡斯皮安{/color}{/a}为躲避诺克斯逃往了那里。"
    translate None chapter_fifteen_0042:
        show cyne n dark sur with dis
        c "锡德卡汉？"
    translate None chapter_fifteen_0043:
        show cyne n dark hap with dis
        c "啊哈哈，你总能给我惊喜！其实那也是我要去的地方！"
    translate None chapter_fifteen_0044:
        show raen n dark sur with dis
        rs "等等…你不是应该回家吗？你住在锡德卡汉？"
    translate None chapter_fifteen_0045:
        c "没错！"
    translate None chapter_fifteen_0046:
        c "说实话我有点伤感，经历了这么多，眼看就要分道扬镳…但命运总是充满巧合，对吧？"
    translate None chapter_fifteen_0047:
        c "为何不搭乘我的马车回去？只需几天的行程，我车上还有充足的空位。"
    translate None chapter_fifteen_0048:
        show illran n dark hap with dis
        gr "啊，真是慷慨的提议。若我拒绝就太失礼了。"
    translate None chapter_fifteen_0049:
        l ann "谁邀请你了？用脚走。"
    translate None chapter_fifteen_0050:
        show veras n dark sad1 with dis
        pr "要我重复多少遍…你必须先请示！不能随意搭别人的车…"
    translate None chapter_fifteen_0051:
        pr "不过…若是对方主动相邀，我们自然不会拒绝。能帮诺克斯的那位也住在锡德卡汉，若是全程都得抬着他走…起码要多费数日。"
    translate None chapter_fifteen_0052:
        show cyne n dark neu with dis
        c "…当然，人多更热闹。"
    translate None chapter_fifteen_0053:
        "赛恩的笑容瞬间凝固。他显得…充满戒备。不像莱奥斯那般恼怒，倒像是在暗暗盘算什么。"
    translate None chapter_fifteen_0054:
        l sur "开什么玩笑…上次简直是地狱，现在还要再来一次？！"
    translate None chapter_fifteen_0055:
        f sad "…上次也没那么糟。"
    translate None chapter_fifteen_0056:
        l ang "对你来说当然。我可是被挤在一堆混蛋中间。"
    translate None chapter_fifteen_0057:
        show raen n dark sad with dis
        rs "…实在感激不尽。若您不嫌叨扰，我们自然乐意同行。"
    translate None chapter_fifteen_0058:
        show illran n dark neu with dis
        gr "那就别再耽搁了。黑影终将笼罩奥克斯哈伯。"
    translate None chapter_fifteen_0059:
        show veras n dark smi1 with dis
        pr "或许明日就是新阳升起之时。"
    translate None chapter_fifteen_0060:
        "我们被领着走向城郊，正是莱拉斯昨日放下我们的地方。恍如隔世的感觉几乎令人发笑，事实上我们在此仅停留了两天。"
    translate None chapter_fifteen_0061:
        show cyne n dark sad with dis
        c "事先声明，我的车夫—"
    translate None chapter_fifteen_0062:
        u "....!"

    show raen n dark sur with dis
    stop music fadeout 2.0

    translate None chapter_fifteen_0063:
        u "老爷，是您吗？！"

    play music "sounds/bgm/Fooling Around Tiny.ogg"

    translate None chapter_fifteen_0065:
        c "又来了…"
    translate None chapter_fifteen_0066:
        "他以我生平仅见的速度冲向赛恩。一个箭步扑倒在赛恩脚边啜泣。"
    translate None chapter_fifteen_0067:
        u "老爷…老爷…您怎能如此对我？！从昨天就音讯全无！"
    translate None chapter_fifteen_0068:
        u "我..我以为您遭遇不测…！担心得快要发疯！"
    translate None chapter_fifteen_0069:
        show cyne n dark emb with dis
        c "得了，不过是绕了点路。又没出事。"
    translate None chapter_fifteen_0070:
        u "没出事？！令尊令堂会宰了我…他们定会杀了我…"
    translate None chapter_fifteen_0071:
        u "每次…每次我都告诫您别乱跑，您却总这样！"
    translate None chapter_fifteen_0072:
        c "…快起来，让我难堪…"
    translate None chapter_fifteen_0073:
        rs "呃…需要帮忙吗？"
    translate None chapter_fifteen_0074:
        "我伸手想扶他起身，他却在地上狠狠瞪着我。"
    translate None chapter_fifteen_0075:
        u "这些人又是谁？！别告诉我你又结识了更多男人？！你父母会怎么想？你知道他们不喜欢你和平民百姓混在一起！"
    translate None chapter_fifteen_0076:
        l ann "嘿，他说\"平民百姓\"是什么意思？"
    translate None chapter_fifteen_0077:
        f sad "我差点觉得自己被冒犯了…"

    if achievement.has("cyne_name"):
        pass
    else:
        $ renpy.display_notify("成就解锁：哪位大人？")

    python:
        achievement.grant("cyne_name")
        achievement.sync()
    translate None chapter_fifteen_0078:
        u "噢…西纳库洛斯大人…整晚我都在街上徘徊，试图找到您…为什么要这样对我？！"
    translate None chapter_fifteen_0079:
        show cyne at shake
        c "喂，别叫我—"
    translate None chapter_fifteen_0080:
        l neu "...."
    translate None chapter_fifteen_0081:
        f neu "..."
    translate None chapter_fifteen_0082:
        rs "...."
    translate None chapter_fifteen_0083:
        l smi "噗嗤。"
    translate None chapter_fifteen_0084:
        f smi "哦..我的天…噗…"
    translate None chapter_fifteen_0085:
        show raen n dark smi with dis
        rs "西纳库洛斯…？这是…你的名字…？啊哈哈！"
    translate None chapter_fifteen_0086:
        l smi "你开玩笑的吧，这也太好笑了。让我向您鞠躬，西纳库洛斯大人..噗哈哈！"
    translate None chapter_fifteen_0087:
        c "闭嘴！假装你们从没听过这个名字！"
    translate None chapter_fifteen_0088:
        "赛恩从耳朵红到脖子根，拒绝与我对视。说也奇怪，我倒觉得他这副样子挺新鲜的。"
    translate None chapter_fifteen_0089:
        "不过\"大人\"这个称呼？有意思。看来他身份不简单，比初见时想象的要尊贵。毕竟他平时总在游手好闲，很难把他和贵族联系起来。"
    translate None chapter_fifteen_0090:
        "但他确实很有钱…还有专属的豪华马车和车夫…"
    translate None chapter_fifteen_0091:
        "只是他的性格可一点都不像贵族。"
    translate None chapter_fifteen_0092:
        "不过如果这趟旅程真像他们说的那么长，我们有的是时间探讨他的\"贵族气质\"。"
    translate None chapter_fifteen_0093:
        c "…闭…闭嘴。这是我的随从，埃瑟。"
    translate None chapter_fifteen_0094:
        "赛恩迅速把瘫在地上啜泣的埃瑟拽了起来。"
    translate None chapter_fifteen_0095:
        c "振作点….你不觉得该回家了吗？瞧，我在这儿呢，我们走吧。"
    translate None chapter_fifteen_0096:
        e "大人！我们已经迟到两天了！这次怎么解释都没用…我会被杀头的，或者更糟，被解雇…"
    translate None chapter_fifteen_0097:
        show cyne n dark sur with dis
        c "..."
    translate None chapter_fifteen_0098:
        c "好了好了，我保证不会偷溜。这样总行了吧？"
    translate None chapter_fifteen_0099:
        e "您上次也是这么说的！大人…大人，您得和我拉钩保证。"
    translate None chapter_fifteen_0100:
        show cyne n dark emb with dis
        c "…你能不能闭嘴？！我又不是小孩了！才不玩这种把戏！"
    translate None chapter_fifteen_0101:
        e "那咱们哪儿也不去！上周您拉钩时可没这么抵触！"
    translate None chapter_fifteen_0102:
        c "呃..行…行吧！好吧，我拉钩保证不再逃跑。现在能走了吗？！"
    translate None chapter_fifteen_0103:
        show raen n dark sad with dis
        rs "呃…我们搭便车真的没问题吗？如果太勉强的话，我们可以…"
    translate None chapter_fifteen_0104:
        c "不，你们必须跟我走。埃瑟，把马匹准备好出发。"
    translate None chapter_fifteen_0105:
        e "你…你要带…他们一起？不觉得他们有点…脏吗？"
    translate None chapter_fifteen_0106:
        l neu "我们就站在这儿。你说的每个字都能听见。"
    translate None chapter_fifteen_0107:
        e "呀！"
    translate None chapter_fifteen_0108:
        gr "我可扛不动这家伙一整天。动作快点。"
    translate None chapter_fifteen_0109:
        show veras n dark neu1 with dis
        pr "让我来帮你扶他。"
    translate None chapter_fifteen_0110:
        gr "谢了。就把他放在车厢后面吧。"
    translate None chapter_fifteen_0111:
        "他们推开吓呆的车夫，把昏迷的索伦安置在马车后厢。"
    translate None chapter_fifteen_0112:
        "赛恩朝埃瑟使了个眼色，后者立即跑去驾车。想到要给人家添这么多麻烦，我有点过意不去。"
    translate None chapter_fifteen_0113:
        "其余人都挤进了后车厢。"



    stop music fadeout 2.0
    window hide dissolve

    hide illran
    hide fawn
    hide veras
    hide cyne
    hide raen

    #scene bg oxhabor night:
        #xpos 0.04 ypos -0.82 xanchor 0.03 yanchor 0.03 zoom 1.64
        #linear 55.0 xpos -0.60 ypos -0.82 xanchor 0.03 yanchor 0.03 zoom 1.64
        #linear 55.0 xpos 0.04 ypos -0.82 xanchor 0.03 yanchor 0.03 zoom 1.64
        #repeat

    scene carriage cyne 2:
        xpos 0.04 ypos -0.37 xanchor 0.03 yanchor 0.03 zoom 1.00
        linear 55.0 xpos -0.60 ypos -0.37 xanchor 0.03 yanchor 0.03 zoom 1.00
        linear 55.0 xpos 0.04 ypos -0.37 xanchor 0.03 yanchor 0.03 zoom 1.00
        repeat

    with dissolve
    window show dissolve

    translate None chapter_fifteen_0114:
        "内部装潢比想象的还要奢华。莱拉斯的马车虽然舒适，但根本没法比。即便如此，七个人挤在一起还是有点局促。"
    translate None chapter_fifteen_0115:
        "赛恩、莱奥斯、福恩和我坐一边，索伦和另外两人坐对面。赛恩明明是独自旅行，没想到他的马车这么大。"
    translate None chapter_fifteen_0116:
        play music "sounds/bgm/night.ogg" fadein 2.0
        gr con "哈，挺舒服的，比步行强多了。能弄到这趟顺风车，我真该夸夸自己。"
    translate None chapter_fifteen_0117:
        l neu "呵，凭什么？没我们的话你现在还在走路呢。"
    translate None chapter_fifteen_0118:
        gr con "难道要我道谢？你不也是蹭车的？"
    translate None chapter_fifteen_0119:
        l smi "区别在于我是被邀请的。"
    translate None chapter_fifteen_0120:
        gr con "细节问题我就不计较了。"
    translate None chapter_fifteen_0121:
        "我望向对面那个桃红色头发的男子。他始终沉默不语，专心做自己的事。"
    translate None chapter_fifteen_0122:
        "他才是最神秘的。究竟是谁呢？真正的神明化身？"
    translate None chapter_fifteen_0123:
        "可…为什么看起来这么普通？为什么和我们毫无区别？但如果索伦庄园里听闻属实，他至少活了几百甚至上千年。"
    translate None chapter_fifteen_0124:
        "神明怎会降临凡间？他们不是应该驻守天堂，守护奥雷利亚卡维拉吗…"
    translate None chapter_fifteen_0125:
        "但…诺克斯和这家伙说自己是被放逐追杀的…谁有这种力量？"
    translate None chapter_fifteen_0126:
        c emb "埃瑟，请载我们回锡德卡汉。"
    translate None chapter_fifteen_0127:
        "赛恩的随从拉开一扇小玻璃窗，将脑袋探了出来。"
    translate None chapter_fifteen_0128:
        e "遵命长官！"
    translate None chapter_fifteen_0129:
        e "啊…但请允许我问…他…他死了吗？"
    translate None chapter_fifteen_0130:
        gr con "嘘—他在睡觉。你不想吵醒他吧？"
    translate None chapter_fifteen_0131:
        e "不…不敢，大人！"
    translate None chapter_fifteen_0132:
        "他关窗时的脸色活像刚吃了酸东西。看来他非常讨厌我们…而且对赛恩极度保护。他们肯定相处很久了。"
    translate None chapter_fifteen_0133:
        rs sad "他看起来…挺好相处的…？你们认识多久了？"
    translate None chapter_fifteen_0134:
        c sur "嗯？埃瑟？他们家为我们家服务了几十年，算是一起长大的。"
    translate None chapter_fifteen_0135:
        rs sur "什么，像兄弟那样？你们家族一定很有地位…"
    translate None chapter_fifteen_0136:
        c neu "他们喜欢这么认为…"
    translate None chapter_fifteen_0137:
        "马车缓缓驶过奥克斯哈伯昏暗的街道，前头三匹马正拉着车前进。"
    translate None chapter_fifteen_0138:
        "看着车厢里的众人，我总算明白埃瑟为何担忧。一个只披着斗篷的桃发男子，还有个形迹可疑的家伙肩头扛着具尸体…"
    translate None chapter_fifteen_0139:
        l neu "好了，什么时候才肯解释？这到底什么情况？"
    translate None chapter_fifteen_0140:
        f neu "你们…你们两位是谁？"
    translate None chapter_fifteen_0141:
        gr con "嘿，别急。时候不早了。先睡一觉，明天我会说明一切。"
    translate None chapter_fifteen_0142:
        l ann "明天？我们除了等待什么都没干，受够了。"
    translate None chapter_fifteen_0143:
        "我又看向那个桃发男子。莫名感到…被他吸引。就像遇见失散多年的老友…但我确信我们素未谋面。"
    translate None chapter_fifteen_0144:
        gr con "都说耐性是种美德。你该好好修炼。"
    translate None chapter_fifteen_0145:
        l ann "你这小—"
    translate None chapter_fifteen_0146:
        rs neu "无妨。我也很困了，明天再谈吧。"
    translate None chapter_fifteen_0147:
        pr smi "好好睡一觉。今天你经历了太多。"
    translate None chapter_fifteen_0148:
        "莱奥斯嘟囔着还是妥协了，仰头开始睡觉。福恩和赛恩也很快躺下。 "
    translate None chapter_fifteen_0149:
        "那晚，我辗转许久才入眠。"

    stop music fadeout 1.0
    window hide dissolve

    scene black with eye_shut
    translate None chapter_fifteen_0150:
        n "雷恩….雷恩…听得见吗？"
    translate None chapter_fifteen_0151:
        n "你前往的…是我无法追随之地…"
    translate None chapter_fifteen_0152:
        n "我会…很快追上…."


    window show dissolve
    translate None chapter_fifteen_0153:
        rs "嗯…"
    translate None chapter_fifteen_0154:
        f neu "雷恩…雷恩，醒醒。"


    scene bg forest:
        xpos 0.5 ypos 0.67 xanchor 0.61 yanchor 1.0 zoom 0.65
    show carriage cyne:
        size(1920, 1080)
    with eye_open

    show raen m sur at closeleft
    show fawn m neu at closeright
    with dissolve


    translate None chapter_fifteen_0155:
        rs sur "哈欠….已经早上了？"
    translate None chapter_fifteen_0156:
        f "你睡得像婴儿般沉。其他人都出去活动了。"
    translate None chapter_fifteen_0157:
        show raen m sad with dis
        rs "抱歉，不必等我的。我一定是太累了。"
    translate None chapter_fifteen_0158:
        show fawn m sad with dis
        f "...."
    translate None chapter_fifteen_0159:
        show fawn m shy with dis
        f "没关系….我会永远等你。"
    translate None chapter_fifteen_0160:
        show fawn m smi with dis
        "他绽放出一个久违的灿烂笑容。自从我们初次相遇以来，已经好久没能这样单纯享受彼此的陪伴了。"
    translate None chapter_fifteen_0161:
        "事实上，感觉我们已经很久没能单独交谈了。"
    translate None chapter_fifteen_0162:
        "索伦仍在角落静坐，呼吸平稳。这段时间他纹丝未动，真的…彻底昏睡过去了。"

    show raen m smi with dis
    play music "sounds/bgm/night.ogg" fadein 2.0

    translate None chapter_fifteen_0163:
        rs "….你感觉怎么样？这几天实在太过忙乱了，是吧？"
    translate None chapter_fifteen_0164:
        show fawn m sad with dis
        f "...."
    translate None chapter_fifteen_0165:
        f "老实说很高兴一切都结束了。我感觉…精疲力尽。"
    translate None chapter_fifteen_0166:
        show raen m neu with dis
        rs "这应该是你多年来最刺激的经历了吧。"
    translate None chapter_fifteen_0167:
        f "用\"刺激\"形容倒也没错。短短数日就发生这么多事。终于能稍作休息真是太好了。"
    translate None chapter_fifteen_0168:
        rs "是啊，我也很高兴结束了。嗯，基本上吧。"
    translate None chapter_fifteen_0169:
        show raen m sad with dis
        rs "真希望我当时能…做得更多。不知道…总觉得如果再努力些…本可以用更好的方式解决问题…"
    translate None chapter_fifteen_0170:
        f "…我也是。我一直…完全帮不上忙…"
    translate None chapter_fifteen_0171:
        rs "别这么说。要不是你，我根本不会在这里。"
    translate None chapter_fifteen_0172:
        f "我知道是我带你走出森林，但这远远不够。我…能力有限。我也想有所作为。连赛恩都比我有用。"
    translate None chapter_fifteen_0173:
        rs "现在的你就很好。不必为我改变什么。"
    translate None chapter_fifteen_0174:
        rs "而且，你知道…"
    translate None chapter_fifteen_0175:
        rs "虽然旅程已行进大半，但你随时可以回头。没有人会因此看轻你。"
    translate None chapter_fifteen_0176:
        show fawn m neu with dis
        f "….你能随时回头吗？你准备好就此止步了吗？"
    translate None chapter_fifteen_0177:
        rs "这个嘛…不行。对我来说只有一条路可走。"
    translate None chapter_fifteen_0178:
        f "那我也一样。天涯海角都追随你。如果你愿意接受的话。"
    translate None chapter_fifteen_0179:
        show raen m smi with dis
        rs "我求之不得。事实上要是你离开，我肯定会去追你回来。没有你我都不知道该怎么办！"
    translate None chapter_fifteen_0180:
        show fawn m shy with dis
        f "啊…"
    translate None chapter_fifteen_0181:
        c hap "哟吼吼，小情侣！希望你们没把我的马车弄得太脏！完事后记得擦座位啊。"
    translate None chapter_fifteen_0182:
        show fawn m emb with dis
        f "什么？！我们什么都没做！"
    translate None chapter_fifteen_0183:
        c hap "画面感来了。雷恩把你按在座位上，疯狂撕扯你的衣服，然后—"
    translate None chapter_fifteen_0184:
        show fawn m hur with dis
        f "闭嘴！闭嘴闭嘴闭嘴！我们只是在聊天！"
    translate None chapter_fifteen_0185:
        c hap "那就出来聊啊。"
    translate None chapter_fifteen_0186:
        show raen m sur with dis
        rs "他该不会以为我们…？"
    translate None chapter_fifteen_0187:
        f "别理他。他就是想找茬……"
    translate None chapter_fifteen_0188:
        rs "好了好了，我们这就出来。"

    window hide dissolve

    scene bg forest with dissolve:
        xpos 0.78 ypos 1.35 xanchor 0.5 yanchor 0.97 zoom 1.65
        linear 60.0 xpos 0.2 ypos 1.35 xanchor 0.5 yanchor 0.97 zoom 1.65
    window show dissolve

    translate None chapter_fifteen_0189:
        "我们推开通向马车外部的门，踏进寒冷的空气中。寒意掠过我的皮肤，让我把衣衫裹得更紧。凛冽的风穿过树林，树叶沙沙作响，寒意渗入骨髓。"
    translate None chapter_fifteen_0190:
        "我们已经远离奥克斯哈伯了。这感觉如此自由，仿佛终于能畅快呼吸。"

    scene bg forest
    show illran n con at slightleft
    show veras n smi1 at slightright
    show expression AlphaMask("foliage_1", At("伊尔兰 n con", slightleft)) as mask1
    show expression AlphaMask("foliage_1", At("维拉斯 n smi1", slightright)) as mask2
    with dissolve

    translate None chapter_fifteen_0191:
        gr "看看是谁大驾光临啊！"
    translate None chapter_fifteen_0192:
        "莱奥斯靠在不远处的树上，双臂交叉在胸前。赛恩蹦跳着来到我身边，把福恩挤到一旁。"
    translate None chapter_fifteen_0193:
        c sad "希望你们没我在也玩得很开心！我本来也想陪着你们，但是某个家伙硬要我离开…"
    translate None chapter_fifteen_0194:
        f bla "…..因为你太吵了。"
    translate None chapter_fifteen_0195:
        c hap "切，才没有！我只是想看看—"
    translate None chapter_fifteen_0196:
        f bla "所以我才把你赶出去。"
    translate None chapter_fifteen_0197:
        pr "早上好，雷恩。睡得还好吗？"
    translate None chapter_fifteen_0198:
        "那个桃红色头发的男人向我走来，脸上带着平静的微笑。"
    translate None chapter_fifteen_0199:
        rs sad "托你的福睡得不错。不过抱歉睡了这么久。"
    translate None chapter_fifteen_0200:
        l neu "既然大家都醒了，该回答我们的问题了。"
    translate None chapter_fifteen_0201:
        show illran n hap with dis
        gr "除非你们特别特别诚恳地求我。"
    translate None chapter_fifteen_0202:
        l ann "....."
    translate None chapter_fifteen_0203:
        gr "就一句\"求求你啦\"不行吗？"
    translate None chapter_fifteen_0204:
        l ann "不如你老实交代，否则我就把刀插进你肚子？"
    translate None chapter_fifteen_0205:
        stop music fadeout 2.0
        rs sad "…..别理他。他早上脾气不好。"

    play music "sounds/bgm/forgotten.ogg" fadeout 2.0
    $ about_Illran.name = "伊尔兰"

    translate None chapter_fifteen_0207:
        v "只要我能回答的都会回答。不如先自我介绍？我叫维拉斯，这位是伊尔兰。"
    translate None chapter_fifteen_0208:
        "维拉斯…果然就是之前那只鸟…"
    translate None chapter_fifteen_0209:
        v "我知道你们在担心诺克斯和索伦的事。对那次遭遇肯定有很多疑问。"
    translate None chapter_fifteen_0210:
        rs sad "在斯塔格威奇遇见你们是巧合还是…？"
    translate None chapter_fifteen_0211:
        show illran n neu with dis
        i "我们可不是专程去迎接你们的，如果是这个意思的话。本打算去奥克斯哈伯工作前办点私事。"
    translate None chapter_fifteen_0212:
        rs sur "工作？"
    translate None chapter_fifteen_0213:
        i "偶尔接些悬赏，只要够有趣。奥克斯哈伯出现恶魔？听起来挺刺激的，对吧？"
    translate None chapter_fifteen_0214:
        show veras n sad1 with dis
        v "我们早已知晓奥克斯哈伯盘踞着邪祟之物，它已在那里蛰伏多年。很抱歉承认这点，但…我们确实把你当作某种诱饵。我保证，我们一直打算让你活着离开那里。"
    translate None chapter_fifteen_0215:
        rs sur "你…早知道我会被抓？"
    translate None chapter_fifteen_0216:
        i "我们预知这事会发生，只是不确定时间和方式。我们跟着你回到索伦的宅邸，当你没有出来后，我们就跟着进去了。"
    translate None chapter_fifteen_0217:
        v "那里发生的事对你来说一定很震惊，但你处理得很好。很多人都无法应对这种情况。"
    translate None chapter_fifteen_0218:
        rs sad "你对他做了什么？他真的是…恶魔吗？"
    translate None chapter_fifteen_0219:
        v "..."
    translate None chapter_fifteen_0220:
        v "我吞噬了他的灵魂。这是个精细的过程。汲取过多就会致命。"
    translate None chapter_fifteen_0221:
        v "回答你另一个问题，是的。诺克斯是恶魔，但索伦不是。我想应该先解释下恶魔的真正含义。"
    translate None chapter_fifteen_0222:
        v "告诉我，你信仰诸神吗？"
    translate None chapter_fifteen_0223:
        "我盯着面前的男人。我信吗？当然，我这辈子都追随他们。"
    translate None chapter_fifteen_0224:
        "但是..相信他们在暗处庇佑着我，和相信有神明就站在我面前是两回事。"
    translate None chapter_fifteen_0225:
        rs sad "我…信。他们在天上守护着我们，对吧？至少…我过去是这么想的…"
    translate None chapter_fifteen_0226:
        show veras n smi1 with dis
        "他对我微笑。"
    translate None chapter_fifteen_0227:
        v "你也没全错。这本是他们的职责。"
    translate None chapter_fifteen_0228:
        show veras n neu1 with dis
        v "很久以前，我们大多数都从天界坠落。我先前应该提过，许多古神因失去信徒而死或消散。其余神明化为人形，却发现自己几乎法力全失。"
    translate None chapter_fifteen_0229:
        v "许多神明因此疯癫，无法承受珍视之物的消逝，认为死亡是更好的选择。"
    translate None chapter_fifteen_0230:
        show veras n sad1 with dis
        v "还有些…继续活着，试图寻找新的存在意义。"
    translate None chapter_fifteen_0231:
        rs sad "你是说已经没有神灵庇佑我们了？"
    translate None chapter_fifteen_0232:
        v "不完全是。有些尚存，但他们远在遥不可及之处，我不确定我们能否再次联结。"
    translate None chapter_fifteen_0233:
        rs sad "那么恶魔就是…"
    translate None chapter_fifteen_0234:
        i "堕神。两者本质相同，只是称谓与立场有别。"
    translate None chapter_fifteen_0235:
        v "选择以人类或其它生灵灵魂为食者能获得强大力量，但这为世所不齿。违背了我们想要守护的一切准则。"
    translate None chapter_fifteen_0236:
        v "通过吞噬灵魂获取力量的神明，就被称为恶魔。诺克斯正是如此。"
    translate None chapter_fifteen_0237:
        v "许多年前，他曾是狩猎之神，守护着人类与动物，但…他被人类的贪婪腐化，转而与他们为敌。"
    translate None chapter_fifteen_0238:
        v "我知道你想把所有过错都归咎于他，但他也是受害者。他实施复仇的方式是错误的，可我仍能理解他感受。被誓言要保护的人们折磨撕裂…那一定很痛苦。"
    translate None chapter_fifteen_0239:
        f sur "那么，你也是…神明？但你…"
    translate None chapter_fifteen_0240:
        v "….夺取他部分灵魂让我痛苦。这是我第一次这么做，但这是帮助他的唯一方法。我们本可以直接杀了他一了百了，但雷恩的恳求让我想做更多。"
    translate None chapter_fifteen_0241:
        v "我只希望这真的能帮到他。"
    translate None chapter_fifteen_0242:
        "他那么反对这样做，却还是为了帮助索伦和我…"
    translate None chapter_fifteen_0243:
        rs sur "你从鸟变成了人形对吧？所有神明都能这样吗？"
    translate None chapter_fifteen_0244:
        show veras n neu1 with dis
        v "这需要耗费大量能量，但我们很多都能在凡人形态和其他形态间转换。"

    show veras n smi1 with dis
    $ about_Veras._image  = "gui/codex/entries/people/enc_veras.jpg"
    $ about_Veras._text = ["曾经作为丰收之神的维拉斯，如今是与伊尔兰同行的流浪神明。多年前从天界坠落，不知怎的进入了人类躯体。"]

    translate None chapter_fifteen_0246:
        v "我觉得该重新自我介绍。我是{a=set_entry:enc_people->about_Veras}{color=#87CEEB}维拉斯{/color}{/a}，曾是丰收之神。如今主要在各处游历，尽力提供帮助。我和你们没什么不同。"
    translate None chapter_fifteen_0247:
        rs sur "伊尔兰，你也是吗？"

    show illran n hap with dis
    $ about_Illran._text = ["伊尔兰是赏金猎人，游历维迪斯各地寻找有趣悬赏。他接了处理奥克斯哈伯恶魔的委托。\n \n虽然过去常独自行动，但近几年来与另一位同行—名叫维拉斯的流浪神。两人看似截然相反，却比任何人都相处融洽。\n \n尽管他可能相当自负烦人，但早已证明自己能力超群。"]

    translate None chapter_fifteen_0248:
        i "噗，才不是。我就是个{a=set_entry:enc_people->about_Illran}{color=#87CEEB}普通人{/color}{/a}。只是凑巧一起旅行罢了。"
    translate None chapter_fifteen_0249:
        show illran n fli with dis
        i "不过，\"性爱之神\"或\"俊美之神\"这样的称号都很适合我吧，嗯？"
    translate None chapter_fifteen_0250:
        l cur "恶心。"
    translate None chapter_fifteen_0251:
        c sad "呕…"
    translate None chapter_fifteen_0252:
        f sad "呃…"
    translate None chapter_fifteen_0253:
        show illran n sad with dis
        i "哇，这话真伤人。"
    translate None chapter_fifteen_0254:
        show veras n smiclo1 with dis
        v "啊哈哈…"
    translate None chapter_fifteen_0255:
        v "我们相处得很愉快，我很享受我们在一起的时光。"
    translate None chapter_fifteen_0256:
        v "希望这能解答你的一些疑问。我知道信息量有点大。"
    translate None chapter_fifteen_0257:
        "我仍然有太多疑问…"
    translate None chapter_fifteen_0258:
        $ about_FallenGods.locked = False
        "不知为何，这些{a=set_entry:enc_lore->about_FallenGods}{color=#DA70D6}上界存在{/color}{/a}全都坠落凡间…许多陨落了，有些变成了恶魔…"
    translate None chapter_fifteen_0259:
        "还有些像普通人一样在维迪斯的道路上徘徊…比如维拉斯…"
    translate None chapter_fifteen_0260:
        "但是…那位言者…他能与那些存在对话。负责向我们传递祂们的旨意！"
    translate None chapter_fifteen_0261:
        i "我想我们该动身了。再耽搁下去，你的车夫可能会吓出心脏病。"
    translate None chapter_fifteen_0262:
        "我回头望向马车。只见埃瑟探出半个脑袋偷看我们，发现被注意到时惊呼一声逃走了。"
    translate None chapter_fifteen_0263:
        rs sad "他这人…挺有意思…"
    translate None chapter_fifteen_0264:
        c neu "…我去跟他沟通下。马上来车厢和你们会合。"
    translate None chapter_fifteen_0265:
        "赛恩走向前车厢，其余人都挤进了后车厢。"


    scene bg forest:
        xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.38 zoom 0.76
    show carriage cyne:
        xpos -0.17 ypos -0.11 zoom 0.81
    with dissolve

    translate None chapter_fifteen_0266:
        "我在维拉斯对面落座，福恩立刻抢占了我身边的位置。"
    translate None chapter_fifteen_0267:
        i neu "所以，你们正前往奥克斯哈伯寻找一个叫卡斯皮安的神秘人…现在该向我们解释来龙去脉了吧？" # Check if voice acting says "so you're on your way to Sid Caeham" other wise we'll need to fix this line. Why did I write Oxhabor ffs
    translate None chapter_fifteen_0267b:
        "我看向莱奥斯，他却只是耸肩。连他都觉得我们没理由搪塞。"
    translate None chapter_fifteen_0268:
        rs sad "好吧…"
    translate None chapter_fifteen_0269:
        rs "莱奥斯和我…来自距斯塔格威奇几天路程的小镇。我们在那生活了一辈子，直到…"
    translate None chapter_fifteen_0270:
        rs "我捅了篓子不得不离开…好吧，更像是被驱逐。莱奥斯跟着我，最后我们就结伴同行了。"
    translate None chapter_fifteen_0271:
        rs "现在…我在寻求某些答案的旅途中。希望锡德卡汉能有解决方法。"
    translate None chapter_fifteen_0272:
        i "那个地方，叫什么来着？"
    translate None chapter_fifteen_0273:
        "瞒着也没意义…"
    translate None chapter_fifteen_0274:
        rs "奥雷利亚卡维拉。"
    translate None chapter_fifteen_0275:
        v sur "....!"
    translate None chapter_fifteen_0276:
        i "果然如此。"
    translate None chapter_fifteen_0277:
        i "隐匿在森林深处的传说之城，由神圣演说者统领。"
    translate None chapter_fifteen_0278:
        rs sur "你们…知道这个地方？去过吗？"
    translate None chapter_fifteen_0279:
        "他凝视维拉斯片刻，视线又落回我身上。"
    translate None chapter_fifteen_0280:
        i sad "….没去过。只是…个人兴趣使然。"
    translate None chapter_fifteen_0281:
        i "我很好奇你到底犯了什么事被赶出来？"
    translate None chapter_fifteen_0282:
        rs sad "你看这个…"
    translate None chapter_fifteen_0283:
        "我抬起手臂，卷起袖子。伊尔兰用手指轻抚着那些神之刻印，仔细端详着。 "
    translate None chapter_fifteen_0284:
        rs "我因为擅闯说书人的档案馆被驱逐了。我本想弄清这个印记的含义。当他们发现我时，他…居然想杀了我…我想我算是侥幸逃脱，最后被放逐到森林里。"
    translate None chapter_fifteen_0285:
        rs "不知道你是否清楚，但当时我觉得这比死刑还可怕。我完全不知道奥雷利亚卡维拉之外还有文明世界。"
    translate None chapter_fifteen_0286:
        rs "我至今仍不知道这些刻印的含义，但我想卡斯皮安可能知道些什么…他是我最后的希望了。"
    translate None chapter_fifteen_0287:
        rs "你听说过他吗？"
    translate None chapter_fifteen_0288:
        i neu "听说他已经死了。我就知道这么多。"
    translate None chapter_fifteen_0289:
        rs "我有理由相信他逃走了，就藏在锡德卡汉。索伦基本上证实了这一点。"
    translate None chapter_fifteen_0290:
        i "有意思…"
    translate None chapter_fifteen_0291:
        v neu "锡德卡汉是座无与伦比的巨大城市，但愿你能找到他。"

    scene carriage cyne:
        xpos 0.04 ypos -0.37 xanchor 0.03 yanchor 0.03 zoom 1.00
        linear 55.0 xpos -0.60 ypos -0.37 xanchor 0.03 yanchor 0.03 zoom 1.00
        linear 55.0 xpos 0.04 ypos -0.37 xanchor 0.03 yanchor 0.03 zoom 1.00
        repeat
    with dissolve

    translate None chapter_fifteen_0292:
        "赛恩推门而入，在福恩和我之间坐下，这让福恩很不悦。熟悉的马车行进感再次传来，我们继续向着锡德卡汉前进。"
    translate None chapter_fifteen_0293:
        c hap"哈欠~再有差不多一天就终于能到家啦！"
    translate None chapter_fifteen_0294:
        l sur "还要一天？！开玩笑吧？"
    translate None chapter_fifteen_0295:
        c hap "啊呀，你难道希望更久些？是担心分开后会想我吗？"
    translate None chapter_fifteen_0296:
        l ann "我更担心再在这个密闭空间待下去你会没命。"
    translate None chapter_fifteen_0297:
        f sur "大家…"
    translate None chapter_fifteen_0298:
        f "这些树…全都红得诡异…怎么回事？"
    translate None chapter_fifteen_0299:
        c hap "我们正穿过苋红森林。这里的树木终年赤红，大多数人都觉得有点邪门。我倒是习惯了。"
    translate None chapter_fifteen_0300:
        i con "某人最好在穿过时保持冷静。"
    translate None chapter_fifteen_0301:
        "他对着满脸厌恶的莱奥斯眨了眨眼。"
    translate None chapter_fifteen_0302:
        l ann "什么？你觉得我控制不住脾气？再说这又有什么关系？"
    translate None chapter_fifteen_0303:
        c hap "他说得没错哦。你最好表现得乖一点！"
    translate None chapter_fifteen_0304:
        c sur "关于苋红森林有个传说。据说进入森林的人会被莫名的愤怒控制，产生杀戮冲动。你越愤怒，就越容易被蛊惑。"
    translate None chapter_fifteen_0305:
        c "据说那些杀戮产生的血液渗入土壤，滋养了树木，这才让它们常年红色不褪。"
    translate None chapter_fifteen_0306:
        c hap "…反正他们都是这么说的啦！至少我到现在还没产生过杀戮冲动呢！"
    translate None chapter_fifteen_0307:
        i neu "即使会耽误行程，人们通常也会选择绕开这座森林。"
    translate None chapter_fifteen_0308:
        c hap "唉，这条路更近些，我们肯定没问题的。"
    translate None chapter_fifteen_0309:
        v neu "能尽快让诺克斯和索伦得到治疗才是最重要的，冒点险也值得。"
    translate None chapter_fifteen_0310:
        rs sur "传说是真的吗？这里真的死了很多人？"
    translate None chapter_fifteen_0311:
        v neu "至少，我能感受到林中残留的众多灵魂气息。不过这不意味着传说就是真的。"
    translate None chapter_fifteen_0312:
        "这…有点瘆人。"
    translate None chapter_fifteen_0313:
        "赛恩毫无预兆地伸手揽住我的肩膀，将我拉近他身旁。"
    translate None chapter_fifteen_0314:
        c hap "害怕了？别担心，我经常穿行这里完全没事！"
    translate None chapter_fifteen_0315:
        l smi "「完全没事」？就你？笑死人了。"
    translate None chapter_fifteen_0316:
        rs sad "是…是啊，你说得对。肯定不会有事的。"
    translate None chapter_fifteen_0317:
        f bla "......"
    translate None chapter_fifteen_0318:
        l neu "放开他。"
    translate None chapter_fifteen_0319:
        c hap "有本事来啊！"
    translate None chapter_fifteen_0320:
        l ann "…真要我过去的话—"
    translate None chapter_fifteen_0321:
        i sad "喂喂喂，你是听不懂人话还是天生蠢货？刚说了要保持冷静。"
    translate None chapter_fifteen_0322:
        l ann "我冷静得很！"
    translate None chapter_fifteen_0323:
        i hap "就忍一晚别吃醋嘛。要是你态度够好，下回说不定也能搂着他哦。"
    translate None chapter_fifteen_0324:
        l emb "什么？！我干嘛要那样？算了算了，睡觉。"
    translate None chapter_fifteen_0325:
        c mis "睡个好觉！"

    stop music fadeout 2.0

    scene carriage cyne 2:
        size(1920, 1080)
    with Dissolve(3.0)
    translate None chapter_fifteen_0326:
        "夕阳早已褪去，夜色已深。欢乐时光总是短暂。多数人都睡着了，我却毫无睡意。"
    translate None chapter_fifteen_0327:
        "天空中悬着又大又圆的满月。我悄悄推开小窗，将手伸向月光。"
    translate None chapter_fifteen_0328:
        "虽然远离家乡，但我们仍在同一片天空下。我很好。"
    translate None chapter_fifteen_0329:
        rs sur "哎呀…！"
    translate None chapter_fifteen_0330:
        "一片树叶划过指尖，留下一道细痕。血珠滴落在森林地面上。"
    translate None chapter_fifteen_0331:
        "我闭眼靠坐，任窗户敞开。微凉的夜风轻拂而过。"
    window hide dissolve
    stop music fadeout 2.0

    show black with eye_shut
    pause(1.5)

    scene bg amaranth night:
        xpos 0.34 ypos 1.83 xanchor 0.5 yanchor 1.0 zoom 0.99 rotate -4
    show carriage cyne 2:
        size(1920, 1080)
    with eye_open
    window show dissolve

    translate None chapter_fifteen_0332:
        rs "…唔…"
    translate None chapter_fifteen_0333:
        "缓缓睁眼时，窗外依旧漆黑。想必没睡多久。"
    translate None chapter_fifteen_0334:
        "其他人都还闭着眼睛，仍在睡梦中。"
    translate None chapter_fifteen_0335:
        "马车轻轻摇晃着—"
    translate None chapter_fifteen_0336:
        "等等…"
    translate None chapter_fifteen_0337:
        "我们为什么停下了？"
    translate None chapter_fifteen_0338:
        "我悄悄打开车门，离开了马车。"

    scene bg amaranth night
    show raen n dark neu at center
    with dissolve

    translate None chapter_fifteen_0339:
        "月光足以照亮这片区域，让我找到去马车前方的路。驾驶座上空无一人，三匹马也全都不见踪影。"
    translate None chapter_fifteen_0340:
        play music "sounds/bgm/Scary.ogg" fadeout 2.0
        "我视线边缘有什么东西在移动。定睛一看，发现是只大鸟栖息在低矮的树枝上。它张开宽阔的翅膀，飞向了夜色中。白色、棕色和黄色相间…是只鹰。"

    show raen at slightright with move
    show raen n dark sad
    show veras n dark o2 neu2 at slightleft
    with dis

    translate None chapter_fifteen_0341:
        v "发生什么事了？"
    translate None chapter_fifteen_0342:
        rs "你也醒了？"
    translate None chapter_fifteen_0343:
        v "我听见你开门出去，所以来查看情况。"
    translate None chapter_fifteen_0344:
        rs "埃瑟…他消失了。马也都不见了。"
    translate None chapter_fifteen_0345:
        v "...."
    translate None chapter_fifteen_0346:
        v "待在这儿。我去把大家都叫醒。"

    hide veras
    hide raen
    with dissolve

    show bg amaranth night with Dissolve(2.0):
        xpos 0.94 ypos 1.71 xanchor 0.5 yanchor 1.0 zoom 1.48
        linear 68.0 xpos 0.03 ypos 1.71 xanchor 0.5 yanchor 1.0 zoom 1.48

    translate None chapter_fifteen_0347:
        "他扶着马车找到回车厢的路，片刻后带着其他人回来了。"
    translate None chapter_fifteen_0348:
        c ang "什么叫\"他消失了\"？！他不会就这样离开的！"
    translate None chapter_fifteen_0349:
        l neu "在我看来，他确实把我们困在这儿了。连一匹马都没留下。"
    translate None chapter_fifteen_0350:
        f sad "他为什么把我们丢在这里…？虽然他不喜欢我们，但也不至于—"
    translate None chapter_fifteen_0351:
        c sad "我认识他一辈子了。他不可能抛弃我们。"
    translate None chapter_fifteen_0352:
        c "肯定是出了什么事。"
    translate None chapter_fifteen_0353:
        i neu "他出事与否不是重点。问题是现在我们被困在这儿了。"
    translate None chapter_fifteen_0354:
        rs sad "我们该怎么办？"
    translate None chapter_fifteen_0355:
        i neu "干等着没意义。我建议现在就出发步行。"
    translate None chapter_fifteen_0356:
        "又要徒步穿越森林…"
    translate None chapter_fifteen_0357:
        rs sad "远吗？"
    translate None chapter_fifteen_0358:
        c sad "步行…大概要一天，一天半。不是不可能，但我们还有行李。"
    translate None chapter_fifteen_0359:
        i con "交给我吧。"
    translate None chapter_fifteen_0360:
        "伊尔兰回到马车里，扛着索伦出来了。"
    translate None chapter_fifteen_0361:
        l neu "显摆。"
    translate None chapter_fifteen_0362:
        c hap "我们只需要穿过森林，就几乎能到锡德卡汉的城门口了。要是我太累，你们也得有人背我！"
    translate None chapter_fifteen_0363:
        l smi "别指望我。话说回来，你正好需要锻炼。真惊讶你那双细腿能撑住身体。"
    translate None chapter_fifteen_0364:
        c hap "没人抱怨过我的腿。事实上，人们常夸赞这双腿环抱人的美妙。"
    translate None chapter_fifteen_0365:
        f sad "呃…"
    translate None chapter_fifteen_0366:
        i neu "跟我来。天色还晚，我建议先走一段，然后找地方扎营过夜。如何？"
    translate None chapter_fifteen_0367:
        "伊尔兰和维拉斯走在前面带领我们。他们靠得很近，却始终保持着肢体不触碰的距离。"
    translate None chapter_fifteen_0368:
        "他们的关系实在耐人寻味。至于最初为何会结伴同行，恐怕无人知晓。"
    translate None chapter_fifteen_0369:
        "神明与凡人，竟能如平等般并肩而行。听起来简直天方夜谭。"
    translate None chapter_fifteen_0370:
        rs sad "…今晚真冷啊。"
    translate None chapter_fifteen_0371:
        c neu "还会越来越冷的。锡德卡汉常年积雪，就像个冬日仙境。"
    translate None chapter_fifteen_0372:
        rs sad "这种极寒天气你们怎么生存？"
    translate None chapter_fifteen_0373:
        c hap "呃，早适应了。我们主要在温室种植作物，注意保暖就是了。你们到那儿后得赶紧添置冬装。"
    translate None chapter_fifteen_0374:
        "他打量着莱奥斯和福恩。"
    translate None chapter_fifteen_0375:
        c hap "特别是你俩。穿这么单薄会冻成冰棍的。"
    translate None chapter_fifteen_0376:
        f sad "我已经感觉要变成冰棍了…"
    translate None chapter_fifteen_0377:
        "四周传来遥远而模糊的声响，轻得让人分不清是真实还是幻听。"
    translate None chapter_fifteen_0378:
        "那声音像是…窃窃私语。仿佛树木在彼此交谈。我摇摇头甩开这种荒谬念头—定是树枝在风中嘎吱作响，没别的解释。"
    translate None chapter_fifteen_0379:
        "我们沉默前行良久，仅有的几句交谈也被冻僵在寒风里。所有人都疲惫不堪。"
    translate None chapter_fifteen_0380:
        i hap "在前方路边扎营吧，别挡着夜间的马车道。"
    translate None chapter_fifteen_0381:
        $ about_AmaranthForest.locked = False
        "伊尔兰扶着索伦靠树坐下，众人瘫倒在{a=set_entry:enc_places->about_AmaranthForest}{color=#DA70D6}森林{/color}{/a}的灌木丛中，四周散落着猩红落叶与荆棘。高悬的月亮毫无西沉之意。"
    translate None chapter_fifteen_0382:
        i neu "安排守夜吧，得有人保持警戒。"
    translate None chapter_fifteen_0383:
        rs sur "警戒什么？"
    translate None chapter_fifteen_0384:
        i hap "我也不知道，但最好别知道。"
    translate None chapter_fifteen_0385:
        i neu "我去找些生火材料。莱奥斯？"
    translate None chapter_fifteen_0386:
        l neu "需要帮忙？行吧。"
    translate None chapter_fifteen_0387:
        "两人身影消失在树线尽头，留下我与维拉斯、赛恩和福恩。"

    scene bg amaranth night
    show raen n dark sad at cenleft
    show veras n dark o2 neu2 at farleft
    show cyne n dark sad at cenright
    show fawn n dark sad at farright
    with dissolve


    translate None chapter_fifteen_0388:
        c "完全没料到会露宿荒野…这种条件下怎么睡得着.."
    translate None chapter_fifteen_0389:
        show cyne n dark sur with dis
        c "哦，福恩！你一定很习惯这种事吧？"
    translate None chapter_fifteen_0390:
        f "…什么？"
    translate None chapter_fifteen_0391:
        c "你知道的，作为森林居民。这里对你来说一定像家一样。"
    translate None chapter_fifteen_0392:
        show fawn n dark bla with dis
        f "...."
    translate None chapter_fifteen_0393:
        "他皱着眉头移开视线。"
    translate None chapter_fifteen_0394:
        show cyne n dark sad with dis
        c "你真无趣！啊，好冷..我晚上该怎么熬过去啊…要是有个人能暖和我就好了…"
    translate None chapter_fifteen_0395:
        rs "….如果你需要的话，可以坐得离我近点。"
    translate None chapter_fifteen_0396:
        f "….切。"
    translate None chapter_fifteen_0397:
        show raen n dark sur with dis
        rs "福恩？"
    translate None chapter_fifteen_0398:
        show fawn n dark smi with dis
        f "嗯？怎么了，雷恩？"
    translate None chapter_fifteen_0399:
        "他朝我露出甜美的微笑。我好像刚听见他咋舌，不过可能听错了。"
    translate None chapter_fifteen_0400:
        c "我的雷恩真是个温柔善良的好孩子！你要当心知道吗。要是遇到坏人，你会被占便宜的！"
    translate None chapter_fifteen_0401:
        c "别担心，我会照看你的。"
    translate None chapter_fifteen_0402:
        rs "谢谢！大家都说我有点傻乎乎的，我正在努力改掉轻易相信人的毛病。"
    translate None chapter_fifteen_0403:
        show fawn n dark neu with dis
        f "........"
    translate None chapter_fifteen_0404:
        show cyne n mis with dis
        "赛恩靠向我，紧紧依偎着。"
    translate None chapter_fifteen_0405:
        show veras n dark smi2 with dis
        v "你们三个真是有趣的三人组。真意外你们能相处得这么好。"
    translate None chapter_fifteen_0406:
        f "相处得好？你这么觉得？"
    translate None chapter_fifteen_0407:
        v "嗯…"
    translate None chapter_fifteen_0408:
        "他一直这么安静，我差点忘了他还在场。"
    translate None chapter_fifteen_0409:
        "..我想尽快和他好好谈谈。总觉得…我必须多了解他。这很重要。"
    translate None chapter_fifteen_0410:
        show raen n dark neu with dis
        rs "既然我们时间充裕，我想问问…能多告诉我些锡德卡汉的事吗？那里什么样？"
    translate None chapter_fifteen_0411:
        show cyne n dark neu with dis
        c "想象一座由大理石和黄金铸就的宏伟城市，寒冷季节水池会结冰。想象高耸的尖顶屋宇映衬着雪山背景。"
    translate None chapter_fifteen_0412:
        v "美极了。特别是当雪覆盖每条走道，孩子们在外面堆雪人的时候。"
    translate None chapter_fifteen_0413:
        show raen n dark sur with dis
        rs "你…见过吗？"
    translate None chapter_fifteen_0414:
        show veras n dark sur2 with dis
        v "啊，我忘了说，当我不是这个形态时视力很好。抱歉让你困惑了。"
    translate None chapter_fifteen_0415:
        show veras n dark smi2 with dis
        v "我以失去视力为代价换取这具人类躯体。代价虽大，但比起其他选择不值一提。反正这几百年我也习惯了。"
    translate None chapter_fifteen_0416:
        rs "作为鸟的时候能看见？那你为什么不一直保持那个形态？"
    translate None chapter_fifteen_0417:
        v "唔…我也不知道。以现在这样能帮上更多忙，但是…"
    translate None chapter_fifteen_0418:
        v "我觉得有一半原因是我喜欢和伊尔兰聊天。自从我们相遇后，我保持这种形态的时间确实更长了。"
    translate None chapter_fifteen_0419:
        show raen n dark neu with dis
        rs "你们俩看起来真的很亲密。你们是多久前认识的？"
    translate None chapter_fifteen_0420:
        v "到现在应该有七年了。那时他才十九岁。"
    translate None chapter_fifteen_0421:
        c "他当时也像现在这么难管教吗？"
    translate None chapter_fifteen_0422:
        v "哈哈哈，不。那时更糟糕。"
    translate None chapter_fifteen_0423:
        v "他尤其爱生闷气，有时充满敌意，但我们都从彼此身上学到了很多。某种程度上，我觉得我们教会了对方如何做人。"
    translate None chapter_fifteen_0424:
        l pen "…..你为什么要问这些？"
    translate None chapter_fifteen_0425:
        i neu "只是对你感到好奇。"
    translate None chapter_fifteen_0426:
        l smi "抱歉，我可没打算把个人信息透露给你这样的混蛋。"
    translate None chapter_fifteen_0427:
        i neu "那我们改天再继续这个对话吧。"
    translate None chapter_fifteen_0428:
        l smi "最好别再提了。"


    scene bg amaranth night:
        xpos 0.94 ypos 1.71 xanchor 0.5 yanchor 1.0 zoom 1.48
        linear 60.0 xpos 0.03 ypos 1.71 xanchor 0.5 yanchor 1.0 zoom 1.48
    with dissolve

    translate None chapter_fifteen_0429:
        "莱奥斯和伊尔兰从阴影中走出来，两人怀里都抱满树枝和树叶，还在争吵。他们带的量远超我们的实际需要。"
    translate None chapter_fifteen_0430:
        "我摇摇头，强忍住笑意。对他们俩来说这就像比赛。莱奥斯可不习惯输。"
    translate None chapter_fifteen_0431:
        "他们堆好引火物和木柴，伊尔兰从口袋里掏出小块燧石点燃了火堆。很快整堆柴火就燃烧起来，化作熊熊烈焰。"
    translate None chapter_fifteen_0432:
        "暖意迅速传遍全身，我终于又能感觉到手指和脚趾了。我们都凑近火堆，伸手取暖。"
    translate None chapter_fifteen_0433:
        "除了一个人。福恩坐在稍远的树下。"
    translate None chapter_fifteen_0434:
        rs sad "你不冷吗？"
    translate None chapter_fifteen_0435:
        f sad "不，我…我在这里挺暖和的。"
    translate None chapter_fifteen_0436:
        "嗯…"
    translate None chapter_fifteen_0437:
        i neu "我先来守夜。莱奥斯？"
    translate None chapter_fifteen_0438:
        l neu "…有必要的话，我接你的班。"
    translate None chapter_fifteen_0439:
        c hap "把我安排在中间时段！"
    translate None chapter_fifteen_0440:
        f sad "…随便什么时候都行…"
    translate None chapter_fifteen_0441:
        "嗯，好吧…"

    window hide

    menu:
        "我接莱奥斯的班":
            window show dissolve
            $ leos_relationship +=1
            $ watchafter_leos = True
            translate None chapter_fifteen_0442:
                rs neu "我来接莱奥斯的班！"
            jump continue_chapterfifteen

        "我接赛恩的班":
            window show dissolve
            $ cyne_relationship +=1
            $ watchafter_cyne = True
            translate None chapter_fifteen_0443:
                rs neu "我很乐意接赛恩的班。"
            jump continue_chapterfifteen

        " 我接福恩的班":
            window show dissolve
            $ fawn_relationship +=1
            $ watchafter_fawn = True
            translate None chapter_fifteen_0444:
                rs neu "啊，那我接福恩的班好了。"
            jump continue_chapterfifteen

label continue_chapterfifteen:
    translate None chapter_fifteen_0445:
        i hap "好吧，这么容易就排好了。维拉斯，你接这位\"卷心菜田\"的班。"
    translate None chapter_fifteen_0446:
        "卷心菜田…？"
    translate None chapter_fifteen_0447:
        v neu "明白。"
    translate None chapter_fifteen_0448:
        i neu "其他人抓紧时间睡会儿吧。离日出只剩几个小时了。"
    translate None chapter_fifteen_0449:
        "噼啪作响的火焰散发的热气终于让我感受到温暖的睡意，我便在火堆旁躺下闭上双眼。尽管身处此地，我还是沉入了梦乡。"
    stop music fadeout 3.0
    window hide dissolve

    scene black with eye_shut
    pause(1.5)

    scene bg amaranth night with eye_open
    window show dissolve
    translate None chapter_fifteen_0450:
        rs "嗯…"
    translate None chapter_fifteen_0451:
        "四周很安静。完全、彻底的安静。"
    translate None chapter_fifteen_0452:
        "不仅是营地—这里大多数人仍蜷缩着酣睡。我的脑海也是一片寂静。没有声音穿透我空荡的梦境对我说话。就像是…我的思绪变成了空白。"
    translate None chapter_fifteen_0453:
        "我轻叹一声微微坐起。说来奇怪，人竟能如此快速习惯某些事物。听不见那个声音…为何会让我感觉如此不适？如此不安？"
    translate None chapter_fifteen_0454:
        "我环顾营地。伊尔兰在离我不远处睡着，看来他的守夜应该结束了。我自知暂时无法再次入睡，索性起身活动腿脚。"

    #hide veras with dissolve

    if watchafter_leos:
        jump after_leos

    elif watchafter_cyne:
        jump after_cyne

    elif watchafter_fawn:
        jump after_fawn




label after_leos:
    translate None chapter_fifteen_0455:
        "莱奥斯坐在营火另一侧凝视火焰，面容严肃冷峻。既然轮班顺序在他之后，他既已醒着，想必快到我的值守时间。这么想着，我决定过去陪他待会儿。"

    show bg amaranth night:
        xpos 0.6 ypos 1.47 xanchor 0.5 yanchor 1.0 zoom 1.35
    show raen m dark neu at closeleft
    show leos m dark sur at closeright
    with dissolve
    play music "sounds/bgm/night.ogg" fadeout 2.0
    translate None chapter_fifteen_0456:
        l "你怎么起来了？还能多睡会儿。用不着在我跟前打转。"
    translate None chapter_fifteen_0457:
        show raen m smi with dis
        rs "但你看上去有点孤单。不能陪你待会儿吗？"
    translate None chapter_fifteen_0458:
        show leos m neu with dis
        l "你真是管不住自己对吧？我连独处一小时都不行。"
    translate None chapter_fifteen_0459:
        show raen m sad with dis
        rs "…..若你真要我走开，好吧…"
    translate None chapter_fifteen_0460:
        show leos m pen with dis
        l "…算了。"
    translate None chapter_fifteen_0461:
        l "想留就留着吧。"
    translate None chapter_fifteen_0462:
        show raen m smi with dis
        rs "我打赌你心里巴不得我留下。行吧，就分点宝贵时间陪你！"
    translate None chapter_fifteen_0463:
        "他身旁的位置看起来温暖舒适，我便自行挨着他坐下。"
    translate None chapter_fifteen_0464:
        show leos m smi with dis
        l "哇哦，被你发现了。你怎么知道我私底下就爱陪烦人的小虾米聊天？"
    translate None chapter_fifteen_0465:
        show raen m sur with dis
        rs "喂，我这叫标准身材。那你算什么，鳗鱼吗？"
    translate None chapter_fifteen_0466:
        l "这就开始了是吧？不如做点实事，给火堆添点柴？"
    translate None chapter_fifteen_0467:
        show leos m pen with dis
        "我往火堆加了木柴，莱奥斯手托下巴继续凝视火焰。"
    translate None chapter_fifteen_0468:
        rs "这几天够忙的，不是么？幸好现在都结束了。"
    translate None chapter_fifteen_0469:
        l "结束？哪部分结束了？我们可能甩掉了一个麻烦，可转眼又陷入了另一个。麻烦永无止境。"
    translate None chapter_fifteen_0470:
        rs "但即便只解决了一个问题也很有成就感。就像我们终于有了进展。"
    translate None chapter_fifteen_0471:
        l "我们到达的唯一地方就是穷乡僻壤。比起最初现在没好多少，只是多了一堆累赘。"
    translate None chapter_fifteen_0472:
        rs "不过你不觉得结伴而行更好吗？而且伊尔兰看起来挺有用的。他似乎很擅长…呃…生存？"
    translate None chapter_fifteen_0473:
        l "....."
    translate None chapter_fifteen_0474:
        show leos m smi with dis
        l "他可以把\"生存技能\"用在别处。我受够他那张脸了。"
    translate None chapter_fifteen_0475:
        show raen m sad with dis
        rs "别对每个新认识的人都这么充满敌意…他是有点怪，但昨天确实救了我的命。我欠他这个人情。"
    translate None chapter_fifteen_0476:
        show leos m pen with dis
        l "啧…"
    translate None chapter_fifteen_0477:
        "他咂了下舌，往火堆里又添了些柴火。今晚他显得特别烦躁…"
    translate None chapter_fifteen_0478:
        l "既然他那么有用，留着我干嘛？我不如现在就离开。"
    translate None chapter_fifteen_0479:
        show raen m sur with dis
        rs "什么…？"
    translate None chapter_fifteen_0480:
        l "你听见了。他救了你的命，对吧？以后跟着他就行。"
    translate None chapter_fifteen_0481:
        show raen m sad with dis
        rs "…为什么要拿自己和他比较？你们是截然不同的人。"
    translate None chapter_fifteen_0482:
        l "是你一直在吹捧他。"
    translate None chapter_fifteen_0483:
        rs "但我…没有啊…？"
    translate None chapter_fifteen_0484:
        "他该不会…吃醋了？莱奥斯在吃那家伙的醋？呃，这要怎么处理…真难搞…"
    translate None chapter_fifteen_0485:
        rs "除了你我不需要任何人。反正你比他有用多了。"
    translate None chapter_fifteen_0486:
        l "那你险些丧命的时候我在哪？"
    translate None chapter_fifteen_0487:
        rs "那…不是你的错。那种情况你无能为力。"
    translate None chapter_fifteen_0488:
        l "要是我再努力些—"
    translate None chapter_fifteen_0489:
        rs "是诺克斯对你动了手脚，再努力也阻止不了。"
    translate None chapter_fifteen_0490:
        l "….要是那个绿毛怪胎不在场，你已经死了。我有什么用？"
    translate None chapter_fifteen_0491:
        rs "你也救过我很多次啊。其实，现在说出口才觉得…我听起来确实很没用对吧？总是被人救。"
    translate None chapter_fifteen_0492:
        l "这还用说。"
    translate None chapter_fifteen_0493:
        rs "哈哈…我没那么差劲吧？"
    translate None chapter_fifteen_0494:
        l "你是个笨手笨脚的糊涂蛋，不过…"
    translate None chapter_fifteen_0495:
        show raen m sur with dis
        rs "但是什么？"
    translate None chapter_fifteen_0496:
        l "是个不知为何我不想看你去死的糊涂蛋。要是咱们能活到最后，我觉得该给我颁个奖。"
    translate None chapter_fifteen_0497:
        show raen m smi with dis
        rs "我给你颁！来个大大的金牌，刻上\"我的闪亮盔甲骑士"
    translate None chapter_fifteen_0498:
        show leos m sur with dis
        l "...."
    translate None chapter_fifteen_0499:
        rs "太过了？"
    translate None chapter_fifteen_0500:
        show leos m pen with dis
        l "….我保证，我会做得更好。我不会再让那样的事发生，而且…当你不可避免地惹上麻烦时，我会是那个来救你的人。你可以依赖我，你不需要{i}他{/i}。"
    translate None chapter_fifteen_0501:
        rs "是啊，我知道遇到什么事你都会帮我。我相信你。"
    translate None chapter_fifteen_0502:
        show leos m smi with dis
        l "这可能不是你最明智的决定。"
    translate None chapter_fifteen_0503:
        show raen m sad with dis
        rs "你刚说了让我多依赖你！"
    translate None chapter_fifteen_0504:
        l "话是这么说，但你说出来感觉怪恶心的。当我没提过吧。"
    translate None chapter_fifteen_0505:
        rs "好吧好吧，随你高兴。对了我想问…你觉得维拉斯说的那些话如何？你相信吗？"
    translate None chapter_fifteen_0506:
        l "就算不愿相信，我也别无选择。我觉得他…难以捉摸。他的可怕和伊尔兰是不同类型。"
    translate None chapter_fifteen_0507:
        show raen m sur with dis
        rs "什么意思？"
    translate None chapter_fifteen_0508:
        show leos m neu with dis
        l "我早就看透伊尔兰了。他有与实力相配的头脑，就像你之前说的，他很懂生存之道，但维拉斯…"
    translate None chapter_fifteen_0509:
        l "他长得像天使，看起来那么平静祥和…但他举手投足间有种感觉，警告我们别招惹他。就像是你不愿与之为敌的那种人。"
    translate None chapter_fifteen_0510:
        show raen m sad with dis
        rs "说真的，我觉得他挺和善的。"
    translate None chapter_fifteen_0511:
        l "表面是这样，但这不能减轻他的威慑力。他甚至不携带武器。太反常了。"
    translate None chapter_fifteen_0512:
        rs "....."
    translate None chapter_fifteen_0513:
        rs "你觉得言者终究是在骗我们吗？如果上面根本没有什么神能和他对话…"
    translate None chapter_fifteen_0514:
        l "我不知道。真的不知道，但迫切想知道答案想到发狂。"
    translate None chapter_fifteen_0515:
        show leos m pen with dis
        l "我想相信他和他的主张，但至今所有证据都对他不利。"
    translate None chapter_fifteen_0516:
        rs "维拉斯确实说过上面还剩几位神明，但是…"
    translate None chapter_fifteen_0517:
        l "也许神确实存在，那个人只是在履行职责，又或许…"
    translate None chapter_fifteen_0518:
        "莱奥斯舒展肩膀从篝火旁站起来。"
    translate None chapter_fifteen_0519:
        show leos m smi with dis
        l "我去眯会儿。我睡着时别把这儿烧了。"
    translate None chapter_fifteen_0520:
        show raen m smi with dis
        rs "最爱放火烧东西的不是你吗？"

    hide raen
    hide leos
    with dissolve
    show bg amaranth night with dissolve:
        xpos 0.5 ypos 1.0 xanchor 0.45 yanchor 0.98 zoom 1.49
        linear 40.0 xpos 0.5 ypos 1.0 xanchor 0.45 yanchor 0.52 zoom 1.49


    translate None chapter_fifteen_0521:
        "他边离开边嘟囔着\"才不是我\"和\"我又没那么喜欢火\"之类的话。"
    translate None chapter_fifteen_0522:
        "片刻后，有人拍了拍我肩膀。"
    translate None chapter_fifteen_0523:
        v smi "你好啊，雷恩。差不多该换我值班了，不过我倒是想先陪你待会儿。要不要散个步？"
    translate None chapter_fifteen_0524:
        "坐着太久感觉身子都僵了，我觉得走走对我有好处。"
    translate None chapter_fifteen_0525:
        rs smi "好啊，乐意至极。"
    jump choice_twentyeight_done

label after_cyne:
    translate None chapter_fifteen_0526:
        "篝火对面站着个背对我的黑影。个头不高…估计是赛恩。我得吓唬他一下，就当报复他在索伦宅邸干的好事。"
    translate None chapter_fifteen_0527:
        "我蹑手蹑脚地靠近，动作极其缓慢。"
    translate None chapter_fifteen_0528:
        "三，二，一…"

    show bg amaranth night:
        xpos 0.6 ypos 1.47 xanchor 0.5 yanchor 1.0 zoom 1.35
    show raen m dark smi at closeleft
    show cyne m dark sur at closeright
    with dissolve

    translate None chapter_fifteen_0529:
        rs "哇！！"

    play music "sounds/bgm/night.ogg" fadeout 2.0
    show cyne at shake

    translate None chapter_fifteen_0530:
        c "啊！！！！"
    translate None chapter_fifteen_0531:
        "要不是我双手正搂着他的腰，他恐怕早就瘫软在地了。"
    translate None chapter_fifteen_0532:
        rs "逮到你了！"
    translate None chapter_fifteen_0533:
        show cyne m angclo with dis
        c "….呃…"
    translate None chapter_fifteen_0534:
        c "你知道的…"
    translate None chapter_fifteen_0535:
        "他转过身来面对我，双臂环上我的脖颈。"
    translate None chapter_fifteen_0536:
        show cyne m hap with dis
        c "今晚这么有兴致啊？想引起我注意也不必搞突然袭击嘛。直接拽我进灌木丛为所欲为不就行了。"
    translate None chapter_fifteen_0537:
        show raen m sur with dis
        rs "呃…"
    translate None chapter_fifteen_0538:
        rs "我觉得现在时机场合都不太合适…"
    translate None chapter_fifteen_0539:
        c "这样才更刺激不是吗？你不觉得来点出格行为能让事情更有趣？"
    translate None chapter_fifteen_0540:
        rs "嗯…这个嘛，我不确定。也许吧？"
    translate None chapter_fifteen_0541:
        show cyne m sur with dis
        c "本来打算过会儿叫醒你交班的，既然你提前来了…我们该做点什么好呢…？"
    translate None chapter_fifteen_0542:
        c "总得找点事打发时间对吧？噢，我们能干些什么呀…？"
    translate None chapter_fifteen_0543:
        show raen m smi with dis
        rs "要是你愿意，聊会儿天我也不介意。"
    translate None chapter_fifteen_0544:
        c "光聊天…？行吧。其他事可以留着以后再说。"
    translate None chapter_fifteen_0545:
        "我们同时松开彼此，在篝火前坐下。火焰依旧平稳燃烧，暖意融融。"
    translate None chapter_fifteen_0546:
        show cyne m hap with dis
        c "说起来，在奥克斯哈伯那段经历还挺有意思的对吧？延续数百年的谋杀悬案，居然被我们侦破了！有侦探赛恩出马，当然手到擒来。"
    translate None chapter_fifteen_0547:
        show raen m sad with dis
        rs "有趣…？"
    translate None chapter_fifteen_0548:
        c "那当然！盘问调查多酷啊！"
    translate None chapter_fifteen_0549:
        rs "...."
    translate None chapter_fifteen_0550:
        c "...."
    translate None chapter_fifteen_0551:
        show cyne m sad with dis
        c "好吧我承认。最后阶段确实有点疯狂…而且我害怕了。不是一点点，是吓得要死。"
    translate None chapter_fifteen_0552:
        c "想到我们可能被堕落之神杀死吃掉就毛骨悚然。这怎么可能呢？我感觉自己完全招架不住。"
    translate None chapter_fifteen_0553:
        rs "真是幸运当时伊尔兰和维拉斯在场，要不然…我真不敢想象后果。"
    translate None chapter_fifteen_0554:
        show cyne m mis with dis
        c "你还没机会好好了解我呢！那简直就是场悲剧！你会至死都是个处男！"
    translate None chapter_fifteen_0555:
        show raen m smi with dis
        rs "你真是说不了两句正经话，对吧？哈哈哈。"
    translate None chapter_fifteen_0556:
        c "哎呀，我总不能太无趣吧？要是不知道怎么找乐子，我早就孤独终老了。"
    translate None chapter_fifteen_0557:
        show raen m sur with dis
        rs "什么？"
    translate None chapter_fifteen_0558:
        c "我觉得关于我的话题够多了！我更好奇你的事。对我来说你还是个谜。"
    translate None chapter_fifteen_0559:
        c "你既参与神魔之事，又在那座神秘隐蔽的小镇长大。关于你的一切都让我着迷。"
    translate None chapter_fifteen_0560:
        show cyne m sur with dis
        c "所以…我想知道在奥雷利亚卡维拉长大是什么感觉？像个邪教组织之类的吗？"
    translate None chapter_fifteen_0561:
        rs "在那里长大？我觉得挺正常的。我在一家小孤儿院长大，最近几年帮着照顾 younger的孩子。"
    translate None chapter_fifteen_0562:
        c "你有上学吗？"
    translate None chapter_fifteen_0563:
        rs "那里有几所学校，但我没上过。"
    translate None chapter_fifteen_0564:
        c "说书人呢？他是个什么样的人？"
    translate None chapter_fifteen_0565:
        show raen m sad with dis
        rs "这有点难回答…"
    translate None chapter_fifteen_0566:
        show cyne m sad with dis
        c "哦，就是他把你赶出来的对吧？抱歉。"
    translate None chapter_fifteen_0567:
        rs "没关系。他是…我们的领袖。我们都信任他。他能与神明对话，保护着我们…"
    translate None chapter_fifteen_0568:
        c "听起来你自己也不太确定。"
    translate None chapter_fifteen_0569:
        rs "…我的信仰确实有些动摇。我很想相信，真的，但…"
    translate None chapter_fifteen_0570:
        c "听上去挺难的。能离开那里你肯定很开心吧。"
    translate None chapter_fifteen_0571:
        rs "我…其实很矛盾。奥雷利亚卡维拉对我意义非凡，留在那里当然更容易，但…那样我就不会遇见你们，也不会踏上这些旅程。"
    translate None chapter_fifteen_0572:
        rs "我想回去告诉大家，但现在还不是时候。我得先找到所有答案。"
    translate None chapter_fifteen_0573:
        rs "现在又多了伊尔兰和维拉斯同行，还要对付诺克斯，要做的事更多了。"
    translate None chapter_fifteen_0574:
        show raen m sur with dis
        rs "哦，说到那两个，你怎么看他们？"
    translate None chapter_fifteen_0575:
        show cyne m neu with dis
        c "嗯…伊尔兰是只狡猾的狐狸，头脑特别聪明，所以我并不特别喜欢他。跟这种人扯上关系准没好事。不过…"
    translate None chapter_fifteen_0576:
        show cyne m hap with dis
        c "他确实很性感对吧？那手臂太迷人了…还有胸膛！"
    translate None chapter_fifteen_0577:
        rs "..."
    translate None chapter_fifteen_0578:
        rs "维拉斯呢？你对他的故事有什么看法？"
    translate None chapter_fifteen_0579:
        show cyne m neuclo with dis
        c "我…感到很迷茫。在此之前，我从不相信神明或恶魔。即使是现在我也难以接受…他看起来就像个普通人。"
    translate None chapter_fifteen_0580:
        c "有生以来第一次，我感觉自己才是这里唯一的普通人。不知道你意识到没有，通常我都是最突出的那个。"
    translate None chapter_fifteen_0581:
        c "这太让人困惑了。比如，我现在到底卷入了什么？这就是埃瑟警告过我的那种事，哈哈哈。"
    translate None chapter_fifteen_0582:
        show cyne m hap with dis
        c "老实说，遇见你的时候我完全没想到会这样。你真的很风趣知道吗？就算发生这么多怪事。至少一点都不无聊！"
    translate None chapter_fifteen_0583:
        show raen m sur with dis
        rs "你以前不相信这些？"
    translate None chapter_fifteen_0584:
        show cyne m neu with dis
        c "不信，从没信过，但我不反对信这个，只是从来没想到过这方面。"
    translate None chapter_fifteen_0585:
        "赛恩打着哈欠，睡意朦胧地伸了个懒腰。"
    translate None chapter_fifteen_0586:
        c "我想我该睡觉了。你一个人没问题吧？"
    translate None chapter_fifteen_0587:
        show raen m smi with dis
        rs "当然。好好休息，我们明天再聊。"
    translate None chapter_fifteen_0588:
        show cyne m mis with dis
        c "要是太想我了可以来叫醒我。"
    translate None chapter_fifteen_0589:
        rs "啊哈哈，我会记住的。晚安，赛恩。"
    translate None chapter_fifteen_0590:
        "他起身准备离开。"

    hide raen
    hide cyne
    with dissolve

    translate None chapter_fifteen_0591:
        c sur "哇啊！"

    show bg amaranth night with dissolve:
        xpos 0.5 ypos 1.0 xanchor 0.45 yanchor 0.98 zoom 1.49
        linear 40.0 xpos 0.5 ypos 1.0 xanchor 0.45 yanchor 0.52 zoom 1.49

    translate None chapter_fifteen_0592:
        v sur "哦，抱歉。你没事吧？"
    translate None chapter_fifteen_0593:
        c neu "…我没事。晚安。"
    translate None chapter_fifteen_0594:
        v sad "我可能吓到他了。快到我的轮值时间了，所以想过来陪你说会儿话。要一起走走吗？"
    translate None chapter_fifteen_0595:
        rs smi "乐意之至。"
    jump choice_twentyeight_done

label after_fawn:
    translate None chapter_fifteen_0596:
        "福恩靠在那棵我睡前看到他的树上。这说明确实快到我的班了。不如也去陪他待会儿。"

    show bg amaranth night:
        xpos 0.6 ypos 1.47 xanchor 0.5 yanchor 1.0 zoom 1.35
    show raen m dark smi at closeleft
    show fawn m dark neu at closeright
    with dissolve
    play music "sounds/bgm/night.ogg" fadeout 2.0

    translate None chapter_fifteen_0597:
        rs "困了？"
    translate None chapter_fifteen_0598:
        "他疲惫地抬眼从地上望着我。"
    translate None chapter_fifteen_0599:
        f "说实话可能有一点，平时这种短途步行不会让我累成这样，但…"
    translate None chapter_fifteen_0600:
        show raen m neu with dis
        rs "加上发生的所有事，你会精疲力尽也不奇怪。"
    translate None chapter_fifteen_0601:
        rs "现在该轮到我值班了对吧？我正好醒了。"
    translate None chapter_fifteen_0602:
        f "我本来准备过会儿去叫你的，想让你多睡会儿…不过既然你已经起来了，要不我再待会儿聊聊天？"
    translate None chapter_fifteen_0603:
        show fawn m shy with dis
        f "我是说…如果你不介意的话。我们俩单独聊天的机会可不多。"
    translate None chapter_fifteen_0604:
        "我也很怀念…那些在森林里漫游的日子，采集食物，无忧无虑地交谈…这一切感觉既像是很久以前，又恍如昨日？"
    translate None chapter_fifteen_0605:
        show raen m smi with dis
        rs "我很乐意。要不要活动下腿脚？我们可以散会儿步。"
    translate None chapter_fifteen_0606:
        "我向他伸出手，把他拉到身边站好。我的手在他手上停留了片刻，才被他轻轻抽开。"
    translate None chapter_fifteen_0607:
        f "我们不应该走太远，不过…听起来不错。"
    translate None chapter_fifteen_0608:
        "我们沿着营地边缘散步，肩膀不时轻轻相碰。这种感觉很舒适，很安心。就像并肩而行是再自然不过的事。"
    translate None chapter_fifteen_0609:
        f "雷恩…你知道吗，你真的很勇敢。如果换成我处在你的位置面对诺克斯…我可能活不下来。"
    translate None chapter_fifteen_0610:
        rs "哈哈，那可不是我的功劳。没有伊尔兰和维拉斯，我可能早就死了。我欠他们很多。"
    translate None chapter_fifteen_0611:
        show fawn m sad with dis
        f "….对不起我没能在你身边。"
    translate None chapter_fifteen_0612:
        show raen m sad with dis
        rs "那不是你的错。诺克斯对你做了手脚还引开了你，对吧？你当时无能为力。"
    translate None chapter_fifteen_0613:
        f "听你这么说很安慰，但我仍然后悔。我保证下次一定会在你身边。"
    translate None chapter_fifteen_0614:
        show raen m smi with dis
        rs "我只希望从今往后能一帆风顺，再没有下次了！"
    translate None chapter_fifteen_0615:
        show fawn m smi with dis
        f "我也希望这样！不过你确实总惹麻烦上身。你就不能安生一天吗？"
    translate None chapter_fifteen_0616:
        rs "我得承认，相比之下我前十八年的人生简直平淡乏味。现在每一天都精彩刺激！"
    translate None chapter_fifteen_0617:
        show fawn m neu with dis
        f "说精彩可能有点夸张，但确实很…热闹。我只是忍不住觉得我们卷入了远超我们理解的事务。这一切都让我难以理解。"
    translate None chapter_fifteen_0618:
        "他说得没错…"
    translate None chapter_fifteen_0619:
        show raen m sur with dis
        rs "对了，你觉得伊尔兰和维拉斯怎么样？"
    translate None chapter_fifteen_0620:
        f "嗯….他们是很奇怪的组合。一个货真价实的神明怎么会和伊尔兰这样的人同行？"
    translate None chapter_fifteen_0621:
        f "伊尔兰看起来强大能干，但总觉得…他藏着很多秘密。而维拉斯倒像个好人，这才是最奇怪的部分。"
    translate None chapter_fifteen_0622:
        f "我想我喜欢他，和他相处有种遇见老友的感觉，但是…他确实不怎么像神明，对吧？不过我相信他的话。"
    translate None chapter_fifteen_0623:
        f "我的家族信奉神明，我也是信徒，但是…想到他们大部分人都像维拉斯一样四处游荡…我不禁怀疑，当初可曾有人聆听过我的祈祷？"
    translate None chapter_fifteen_0624:
        show raen m sad with dis
        rs "我也…觉得难以置信。"
    translate None chapter_fifteen_0625:
        rs "我不确定自己提到过多少关于说书人的事，但..他本应与神明对话，聆听神谕并将祂们的审判传递给我们。难道他一直在说谎吗？我不知道。"
    translate None chapter_fifteen_0626:
        "他将双臂高举过头伸着懒腰。腹部比平时更明显些鼓起。他的身体精壮结实，但与莱奥斯的刚硬不同。更柔软些。"
    translate None chapter_fifteen_0627:
        "我突然被一种难以名状的冲动攫住，想要感受那触感。"
    translate None chapter_fifteen_0628:
        "趁他打哈欠时，我戳了戳他的肚子。"
    translate None chapter_fifteen_0629:
        "啊，是紧实的！我早该想到。"
    translate None chapter_fifteen_0630:
        show fawn m emb with dis
        f "你干什么？！"
    translate None chapter_fifteen_0631:
        show raen m smi with dis
        rs "哦，抱歉。你的小肚子实在太可爱了，忍不住想戳！"
    translate None chapter_fifteen_0632:
        f "............"
    translate None chapter_fifteen_0633:
        rs "这么结实！好想多摸摸！"
    translate None chapter_fifteen_0634:
        f "既…既然你真的很…很想摸的话…."
    translate None chapter_fifteen_0635:
        v sur "我是不是打扰你们了？"
    translate None chapter_fifteen_0636:
        show fawn at shake
        f "啊！！！！"
    translate None chapter_fifteen_0637:
        f "我…我，我…我去睡觉了！晚安！"

    hide raen
    hide fawn
    with dissolve

    translate None chapter_fifteen_0638:
        "福恩转身慌乱地跑回营地。维拉斯扶着树干站在原地，目光直直望向我这边。"

    show bg amaranth night with dissolve:
        xpos 0.5 ypos 1.0 xanchor 0.45 yanchor 0.98 zoom 1.49
        linear 40.0 xpos 0.5 ypos 1.0 xanchor 0.45 yanchor 0.52 zoom 1.49

    translate None chapter_fifteen_0639:
        v sur "听起来他相当匆忙。我让他难堪了吗？"
    translate None chapter_fifteen_0640:
        rs sur "他为什么要难堪？"
    translate None chapter_fifteen_0641:
        v sur "这个嘛..或许他不希望我听见你们调情？"
    translate None chapter_fifteen_0642:
        rs sur "调情？谁，我吗？"
    translate None chapter_fifteen_0643:
        v sur "你来自奥雷利亚卡维拉对吧？这对你来说都是新鲜事。我想问问你是否愿意聊会儿。散个步如何？"
    translate None chapter_fifteen_0644:
        "…..抱歉福恩，我没意识到…"
    translate None chapter_fifteen_0645:
        rs smi "乐意之至。"

    jump choice_twentyeight_done



label choice_twentyeight_done:

    translate None chapter_fifteen_0646:
        "我们沉默地走在绯红森林里，无光的夜色将林木染成漆黑。月光至少足够让我们不至于迷路。"
    translate None chapter_fifteen_0647:
        "偶尔，我会听见远处某种微弱的呢喃。轻柔的嗡鸣声几乎像人语，却又遥不可及。无论如何侧耳倾听，都无法辨明其意。"

    show bg amaranth night:
        xpos 0.6 ypos 1.47 xanchor 0.5 yanchor 1.0 zoom 1.35
    show raen m dark neu at closeleft
    show veras m dark neu at closeright
    with dissolve

    translate None chapter_fifteen_0648:
        v "你也听见了吗？"
    translate None chapter_fifteen_0649:
        show raen m sad with dis
        rs "听见了。是什么？昆虫？动物？"
    translate None chapter_fifteen_0650:
        v "连我也不能确定，但我有个猜想。"
    translate None chapter_fifteen_0651:
        v "我相信在很久以前，有位神明曾居住于此地并守护这片土地，但如今已不复存在。我仍能感受到各处飘散着的强大灵魂气息，但察觉不到有谁在注视我们。"
    translate None chapter_fifteen_0652:
        v "也许那位神明已经离开或消逝，只留下了守护这片森林的礼物；又或许他的灵魂仍困于此地。我不得而知。"
    translate None chapter_fifteen_0653:
        rs "更多神明…感觉无论走到哪里都避不开他们。"
    translate None chapter_fifteen_0654:
        show veras m sad with dis
        v "我不怪你。你经历的那些遭遇，是大多数人连相信都不会相信的。真不知该说你幸运还是不幸。"
    translate None chapter_fifteen_0655:
        show veras m smi with dis
        v "当然我可能判断错了。或许这片森林里根本没有神明。说不定只是个独居森林中央的疯隐士在驱赶旅人。"
    translate None chapter_fifteen_0656:
        "他轻声笑着，抬手掩住嘴。"
    translate None chapter_fifteen_0657:
        "真奇怪，面对刚认识的人我竟能如此平静。他温柔体贴，让我瞬间就愿意向他倾诉更多心事。"
    translate None chapter_fifteen_0658:
        rs "我能问你件事吗？"
    translate None chapter_fifteen_0659:
        v "随时愿意倾听。"
    translate None chapter_fifteen_0660:
        rs "这段时间我总在梦里听见奇怪的声音。有时很轻，有时又疯狂喧闹。我…不知道这些意味着什么。"
    translate None chapter_fifteen_0661:
        show veras m sur with dis
        v "....."
    translate None chapter_fifteen_0662:
        rs "但自从进入这片森林，那声音就再没出现过。本以为该高兴的…可我想查明真相，不愿它们就这样消失。"
    translate None chapter_fifteen_0663:
        rs "你可能毫无头绪，但我觉得值得一问。"
    translate None chapter_fifteen_0664:
        v "或许阿玛兰斯里确实残留着神性，阻止了那个与你对话的存在。"
    translate None chapter_fifteen_0665:
        show raen m sur with dis
        rs "你认为真有人在对我说话？不只是怪梦？"
    translate None chapter_fifteen_0666:
        show veras m neu with dis
        v "是的。现在只需弄清对方身份。"
    translate None chapter_fifteen_0667:
        "我们绕营地转了一圈回到篝火前。维拉斯率先坐下，示意我坐到他身旁。其他人四散而卧，睡得正熟。"
    translate None chapter_fifteen_0668:
        v "你对我很好奇吧？"
    translate None chapter_fifteen_0669:
        rs "我…确实。若你愿意解答，有件事想深入了解。你是从天而降的神明，但说过坠落凡间后不得不寄居在凡人之躯对吧？就像诺克斯也曾依附于索伦的身体。这是不是意味着…？"
    translate None chapter_fifteen_0670:
        show veras m sad with dis
        v "…不，这具身体原本并不属于我。能让神明占据人类躯体，后果必定非常严重。"
    translate None chapter_fifteen_0671:
        v "诺克斯是个例外，因为两者共存于一具身体中，但通常情况下，神明要获得人类形态，必须在原主灵魂离体的瞬间占据那具躯体。"
    translate None chapter_fifteen_0672:
        v "也就是说，原主必须死去。"
    translate None chapter_fifteen_0673:
        rs "那么…你的身体..？"
    translate None chapter_fifteen_0674:
        show veras m neu with dis
        v "没错。当我奄奄一息，以为只能逐渐消散时，有人提供了一个濒死婴儿的躯体给我。那孩子的双亲都是我的信徒。"
    translate None chapter_fifteen_0675:
        v "他们不断向我祈祷，希望我能拯救他们的孩子，但我无能为力。我尝试了各种方法都救不了他。占据那具躯体的决定让我内心极为沉重。"
    translate None chapter_fifteen_0676:
        show veras m smi with dis
        v "但那对父母—我的父母—欣喜若狂。他们以拯救了他们孩子的神明之名，给我取名维拉斯。我在远离此处的农场作为人类长大，生活简单而幸福。"
    translate None chapter_fifteen_0677:
        rs "人类的家人？他们现在在哪？"
    translate None chapter_fifteen_0678:
        show veras m neu with dis
        v "….他们早已离世。这是五百年前的事了。" # Changed to 500 with voice line
    translate None chapter_fifteen_0679:
        show raen m sad with dis
        rs "听你这么说…我很难过。"
    translate None chapter_fifteen_0680:
        v "不必如此。虽然他们已逝，但永远活在我心中。我永远不会忘记他们给予我的温暖。"
    translate None chapter_fifteen_0681:
        show veras m sad with dis
        v "我从未告诉他们真相。即便在他们临终之际也没有。但愿我这个儿子当得还算称职。"
    translate None chapter_fifteen_0682:
        rs "在我看来，你命中注定就是他们的孩子。"
    translate None chapter_fifteen_0683:
        v "....."
    translate None chapter_fifteen_0684:
        show veras m smi with dis
        v "谢谢，雷恩。"

    $ about_Veras._text = ["曾经是丰收之神的维拉斯，如今是跟随伊尔兰一起游历的流浪神明。\n \n许多年前，当维拉斯奄奄一息时，他听到了最后信徒的祈祷。在维迪斯一个遥远的僻静角落，信徒们向维拉斯神祈求拯救他们垂死的孩子，但为时已晚。\n \n维拉斯陷入深深的悲伤与无力感。神明的力量取决于人们的信仰程度。没有信仰，他们要么死去，要么化为人形。看到自己连一个孩子都救不了，他本以为自己大限将至，是时候离去了，但当他注视着悲痛欲绝的父母…他决定再尝试活一次。\n \n当孩子的灵魂离开躯体时，维拉斯进入了这具身体。他作为普通人长大，在普通的农场，拥有普通的家庭。他的家人多年前就已离世，而他始终没有告诉他们真相。"]

    translate None chapter_fifteen_0685:
        v "{a=set_entry:enc_people->about_Veras}{color=#87CEEB}以人类身份成长{/color}{/a}让我获得了前所未有的领悟。无论是作为神明，还是在那之前的人生都未曾获得的。为此，我将永远感激。"
    translate None chapter_fifteen_0686:
        show veras m sad with dis
        v "我想这就是诺克斯与我的不同之处。他没有机会体验人类的温情，所以从未与人类建立联系。"
    translate None chapter_fifteen_0687:
        v "他被扔进一个充满暴力与欺骗的世界，仅仅因为存在而遭受折磨。我无法想象如果这是我的初次人类体验，我会变成什么样子。"
    translate None chapter_fifteen_0688:
        v "很难为此责备他的所作所为。也许有些人确实该死，但他牵连了太多无辜者。这不是他该审判的事。"
    translate None chapter_fifteen_0689:
        rs "我无法原谅他，但是…他也是受害者，对吧？"
    translate None chapter_fifteen_0690:
        v "没错。环境造就的受害者。他从未选择成为神明的人生。"
    translate None chapter_fifteen_0691:
        show veras m smi with dis
        v "总之，我已经耽搁你太久了。现在去休息吧。明天我们还有漫长的旅途。"
    translate None chapter_fifteen_0692:
        rs "你一个人没问题吗？"
    translate None chapter_fifteen_0693:
        v "当然。过去几百年我都设法活下来了，所以我想一两个小时应该不成问题。"

    hide veras
    hide raen
    with dissolve

    translate None chapter_fifteen_0694:
        "道过晚安后，我从维拉斯身边起身，在离篝火稍远的地方找了个位置。"
    translate None chapter_fifteen_0695:
        "刚闭上眼，至寂的睡眠就立刻俘获了我。"

    stop music fadeout 2.0
    window hide dissolve

    jump chapter_sixteen_start
