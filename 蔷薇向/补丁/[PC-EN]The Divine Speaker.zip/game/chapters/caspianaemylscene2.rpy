label caspianaemylscene2:
    stop music fadeout 2.0
    window hide dissolve

    scene bg sv day with Fade(1.0, 1.0, 1.0):
        xpos 0.72 ypos 1.03 xanchor 0.5 yanchor 1.0 zoom 1.46
        linear 30.0 xpos 0.29 ypos 1.03 xanchor 0.5 yanchor 1.0 zoom 1.46
    window show dissolve
    translate None caspianaemylscene2_0001:
        "两个男人注视着同伴们陆续离开，直到突然间只剩他们独处。"
    translate None caspianaemylscene2_0002:
        casmn "他们要离开多久？如果我们独处到天黑…我到底该对他说什么…？"
    translate None caspianaemylscene2_0003:
        "起初两人都沉默不语。彼此都有千言万语想说，却都缺乏开口的勇气。即便他们都曾幻想过这样的场景，当真发生时却又双双迟疑。"
    translate None caspianaemylscene2_0004:
        "最终在令人窒息的沉默中，卡斯皮安指向了道路尽头。"
    translate None caspianaemylscene2_0005:
        play music "sounds/bgm/sad.ogg" fadein 3.0
        cas sad "我们…走走看？"
    translate None caspianaemylscene2_0006:
        ae ann "…如果你想的话。"
    translate None caspianaemylscene2_0007:
        cas "...."
    translate None caspianaemylscene2_0008:
        "横亘在两人之间的不仅仅是物理距离。他们都犯过错，也都固执己见。"
    translate None caspianaemylscene2_0009:
        "…但谁都没有真正忘记。"
    translate None caspianaemylscene2_0010:
        "卡斯皮安叹了口气，用靴尖碾着地上的泥土。"
    translate None caspianaemylscene2_0011:
        cas "我究竟把自己卷进了什么场面…"
    translate None caspianaemylscene2_0012:
        cas "神灵与言者作证，我以为早已死去的儿子，连你都出现在这里…"
    translate None caspianaemylscene2_0013:
        cas "本以为这些往事早就翻篇…现在却全都被甩到我脸上。或许我早该料到会有这么一天。"
    translate None caspianaemylscene2_0014:
        cas "过去总是不甘心成为过去，对吧？抱歉，我有点语无伦次。"
    translate None caspianaemylscene2_0015:
        ae "…确实如此。"
    translate None caspianaemylscene2_0016:
        "艾米尔几乎惜字如金。他仿佛将自己完全封闭，因此当他终于回应时，卡斯皮安忍不住心头一颤。"
    translate None caspianaemylscene2_0017:
        cas "至少…我早就不再向往冒险了。眼前这一切…远超我的预期…"
    translate None caspianaemylscene2_0018:
        ae neu "当年着魔的可是你。这不正合你胃口？"
    translate None caspianaemylscene2_0019:
        cas neu "不是着魔。只是…太无聊？"
    translate None caspianaemylscene2_0020:
        ae "着魔。"
    translate None caspianaemylscene2_0021:
        cas sad "无聊而已，说真的，你不觉得这一切太离谱了吗？"
    translate None caspianaemylscene2_0022:
        ae "...."
    translate None caspianaemylscene2_0023:
        ae sad "就是着魔，没错，确实离谱。"
    translate None caspianaemylscene2_0024:
        "艾米尔轻声叹息，突然停下脚步。卡斯皮安回头的瞬间，恍然看见了当年那个年轻版的艾米尔。"
    translate None caspianaemylscene2_0025:
        "他情不自禁笑了。"
    translate None caspianaemylscene2_0026:
        stop music fadeout 2.0
        u "当心！"
    translate None caspianaemylscene2_0027:
        cas sur "...!"

    show bg sv day with hpunch:
        xpos 0.29 ypos 1.03 xanchor 0.5 yanchor 1.0 zoom 1.46
    translate None caspianaemylscene2_0028:
        "毫无征兆地，某物突然破空袭向艾米尔。卡斯皮安不假思索地扑上前去，将艾米尔从飞射物前推开。"
    translate None caspianaemylscene2_0029:
        "但冲击力实在太大，两人重重摔倒在地。"
    translate None caspianaemylscene2_0030:
        "那个物品落在他们身旁。一个小球。"

    window hide dissolve

    scene gallery_109 with dissolve
    window show dissolve
    translate None caspianaemylscene2_0031:
        ae "....."
    translate None caspianaemylscene2_0032:
        cas "呼，就差那么一点。"
    translate None caspianaemylscene2_0033:
        ae "是啊，要是被球砸到我肯定会当场死掉。如果是危险物品你打算怎么办？"
    translate None caspianaemylscene2_0034:
        play music "sounds/bgm/night.ogg" fadein 3.0
        cas "做同样的事。"
    translate None caspianaemylscene2_0035:
        "艾米尔皱起眉头，似乎这个回答不知为何让他感到不安。他的脸正以肉眼可见的速度变得越来越红，卡斯皮安终于注意到了他们的窘境。"
    translate None caspianaemylscene2_0036:
        "他悬在自己旧日恋人的上方，两人的身体距离近得像是回到了二十年前。"
    translate None caspianaemylscene2_0037:
        "他忍不住凝视着他，仿佛时光从未流逝。在他身下的是艾米尔，他的艾米尔，与他一起长大的艾米尔…他深爱着的艾米尔。"
    translate None caspianaemylscene2_0038:
        ae "快起来啦…"
    translate None caspianaemylscene2_0039:
        cas "怎么了，言者少爷？在担心沾上一点灰尘吗？"
    translate None caspianaemylscene2_0040:
        scene gallery_110b with dissolve
        "还没等卡斯皮安反应过来，艾米尔的双臂就环抱住他并拉近距离。他迟疑片刻，最终回抱了他。"
    translate None caspianaemylscene2_0041:
        "他的手紧紧抓住艾米尔。比记忆中更高大、更宽阔、更健壮。但是…他仍然是艾米尔。"
    translate None caspianaemylscene2_0042:
        "艾米尔发出的声音难以辨别。介于笑声和哭泣之间，好像他的情绪不知该如何应对这种情况。"
    translate None caspianaemylscene2_0043:
        scene gallery_110a with dissolve
        ae "看看我，早就不再年轻了。你知道我讨厌你那么叫我。"
    translate None caspianaemylscene2_0044:
        cas "你或许长大了一点，但本质上没什么不同。在我心里你永远是那个言者少爷。"
    translate None caspianaemylscene2_0045:
        ae "你还像当年一样会调情。"
    translate None caspianaemylscene2_0046:
        cas "或许这是唯一没变的地方。我不再是领袖，不再是王子。早就不是了。"
    translate None caspianaemylscene2_0047:
        casmn "但也许…也许我对你来说还够好？这是不是奢望太多了？"
    translate None caspianaemylscene2_0048:
        ae "…对不起。我…真的…真的很抱歉…"
    translate None caspianaemylscene2_0049:
        ae "对不起怀疑过你，在你始终支持我时却没有站在你那边。我错了。我是个白痴。"
    translate None caspianaemylscene2_0050:
        ae "我…对不起抛弃了你还把一切都怪罪给你，明明…明明是我的错。"
    translate None caspianaemylscene2_0051:
        "卡斯皮安试图摇头，但艾米尔把他抱得太紧，几乎无法动弹。"
    translate None caspianaemylscene2_0052:
        cas "不…我也错了。如果我试着从你的角度看问题…我们本可以解决的，我知道。"
    translate None caspianaemylscene2_0053:
        cas "..也许…我们可以从头来过。再给彼此一次机会，像从前那样相处。如果你还愿意接受我的话。"
    translate None caspianaemylscene2_0054:
        scene gallery_110c with dissolve
        ae "..我们那时真的相处得很好吗？"
    translate None caspianaemylscene2_0055:
        cas "那段时光是我最珍贵的回忆，艾米尔。因为有你。"
    translate None caspianaemylscene2_0056:
        "他的手臂收紧，艾米尔把脸埋进卡斯皮安的肩膀。"
    translate None caspianaemylscene2_0057:
        cas "告诉我，阿拉拉还好吗？我听雷恩说她现在经营着一家孤儿院。"
    translate None caspianaemylscene2_0058:
        ae "我…从她被解雇后就再没见过她。我羞愧得不敢面对她。"
    translate None caspianaemylscene2_0059:
        cas "我一直希望能至少道个别…还有说声抱歉。"
    translate None caspianaemylscene2_0060:
        ae "我也是。"
    translate None caspianaemylscene2_0061:
        cas "也许…如果我们都能活下来，我们可以一起去看她。"
    translate None caspianaemylscene2_0062:
        ae "嗯。"
    translate None caspianaemylscene2_0063:
        cas "现在可以放开我了吗？"

    if achievement.has("caspian_makeup"):
        pass
    else:
        $ renpy.display_notify("成就达成：再抱一会儿")

    python:
        achievement.grant("caspian_makeup")
        achievement.sync()

    translate None caspianaemylscene2_0064:
        ae "再抱一会儿就好。"

    window hide dissolve

    if cyne_route:
        scene bg sv sunset with Fade(1.0, 1.0, 1.0):
            xpos 0.29 ypos 1.03 xanchor 0.5 yanchor 1.0 zoom 1.46
        window show dissolve
        jump raenaemylsv

    if leos_route:
        scene bg sv sunset with Fade(1.0, 1.0, 1.0):
            xpos 0.09 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 2.02
        window show dissolve
        jump raenaemylsv

    if fawn_route:
        scene bg sv sunset with Fade(1.0, 1.0, 1.0):
            xpos 0.09 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 2.02
        window show dissolve
        jump raenaemylsv








#
