label illranverasscene4:
    stop music fadeout 3.0

    window hide dissolve

    scene bg sv day with Fade(1.0, 1.0, 1.0)
    window show dissolve
    translate None illranveras_scene4_0001:
        "当其他人都离开后，伊尔兰和维拉斯之间陷入了沉默。两人都没有开口，不知该如何提及昨晚发生的事。"
    translate None illranveras_scene4_0002:
        play music "sounds/bgm/sad.ogg" fadein 3.0
        "每分每秒的避而不谈都加剧着伊尔兰的心痛。"
    translate None illranveras_scene4_0003:
        i sad "…镇上好像没什么可看的，要不要四处转转？"
    translate None illranveras_scene4_0004:
        v sad "我想…这样或许最好。"
    translate None illranveras_scene4_0005:
        i "…这地方不错吧？"
    translate None illranveras_scene4_0006:
        v "嗯…"
    translate None illranveras_scene4_0007:
        i "就是有点冷。"
    translate None illranveras_scene4_0008:
        v "...."
    translate None illranveras_scene4_0009:
        "两人心不在焉地漫步在小村庄里。有些村民好奇地打量着维拉斯，但看到和他同行的人类后，没人敢上前搭话。"
    translate None illranveras_scene4_0010:
        "不知不觉间，他们已走遍整个村庄。两人停在入口处，思索接下来该做什么。"
    translate None illranveras_scene4_0011:
        v "不如去周边地区看看？就算找不到有用线索，这可能是你唯一在山中漫步的机会了。"
    translate None illranveras_scene4_0012:
        i "也行。从村民那儿问不出什么。他们看我的眼神就像在打量传染病患。"
    translate None illranveras_scene4_0013:
        i "虽然—我必须声明—我健康得很。"
    translate None illranveras_scene4_0014:
        v sad "他们只是害怕。"
    translate None illranveras_scene4_0015:
        i neu "真该害怕的是我才对。说不定哪位神明会突然决定把我吞了，谁知道呢。"
    translate None illranveras_scene4_0016:
        v sad "你知道我不会让这种事发生…"
    translate None illranveras_scene4_0017:
        imn "如果是你的话…我倒不介意。"
    translate None illranveras_scene4_0018:
        i sad "…你不可能永远守着我。"

    window hide dissolve

    scene bg sc mountains day with Dissolve(1.0)
    window show dissolve
    translate None illranveras_scene4_0019:
        "沿着山径行走时，村庄逐渐消失在视野里。崎岖不平的小径显然少有人迹，却因此更显迷人。"
    translate None illranveras_scene4_0020:
        "山腰上散布着洞穴与裂谷。两个充满好奇心的人忍不住探索每个角落。"

    show illran m sad armsdown at closeright:
        ypos 1.0 xanchor -0.56 yanchor 1.0
    show veras m sad at closeleft
    with dissolve
    translate None illranveras_scene4_0021:
        imn "…好难受。"
    translate None illranveras_scene4_0022:
        imn "他为什么不提？觉得羞耻吗？还是说…那只是个安抚我的怜悯之吻？"
    translate None illranveras_scene4_0023:
        v "伊尔兰—"
    translate None illranveras_scene4_0024:
        i  "那个吻—"
    translate None illranveras_scene4_0025:
        show veras m sur with dis
        v "....."
    translate None illranveras_scene4_0026:
        show veras m emb with dis
        v "我…我只是想问你…空气湿漉漉的，这里…该不会有温泉吧？"
    translate None illranveras_scene4_0027:
        show illran m emb with dis
        i "啊…是…真厉害…"
    translate None illranveras_scene4_0028:
        "绿发男子揪着一缕散落的发丝，无意识地绕在指间把玩。"
    translate None illranveras_scene4_0029:
        show veras m sad with dis
        v "….对不起。那是个错误。我不该那样对你。这对你不公平。"
    translate None illranveras_scene4_0030:
        show illran m sad with dis
        i "...."
    translate None illranveras_scene4_0031:
        i "别说这种话。什么都可以说，唯独不要道歉。"
    translate None illranveras_scene4_0032:
        v "你说什么？"
    translate None illranveras_scene4_0033:
        i "此刻最残忍的话，就是为你我期盼多年的事道歉。"
    translate None illranveras_scene4_0034:
        v "这不过是…一时冲动的错误判断，伊尔兰。这永远不可能…这行不通…"
    translate None illranveras_scene4_0035:
        i "既然已经冲动过一次，那再来一次又何妨？"
    translate None illranveras_scene4_0036:
        "伊尔兰的目光不受控制地游移到维拉斯的唇上。"
    translate None illranveras_scene4_0037:
        v "我…"
    translate None illranveras_scene4_0038:
        i "就当是临别的吻吧。"
    translate None illranveras_scene4_0039:
        "不知何时，两人已近在咫尺，脸庞几乎相贴。伊尔兰摩挲着维拉斯冰凉的脸颊，顽皮笑意重新浮现。"
    translate None illranveras_scene4_0040:
        show illran m fli with dis
        i "我吻技没那么差吧？"
    translate None illranveras_scene4_0041:
        show illran m blu
        show veras m emb
        with dis
        "维拉斯踮起脚尖，在伊尔兰唇间落下蜻蜓点水的一吻。"
    translate None illranveras_scene4_0042:
        "但这远远不够。永远都不够。如果此生挚爱只能用错误判断来换，那就错到底吧。"
    translate None illranveras_scene4_0043:
        "既然终将别离，何不再多留一段记忆。"
    translate None illranveras_scene4_0044:
        "伊尔兰猛然将维拉斯拉近，唇舌再次纠缠，这次却带着狂乱的焦灼。七年魂牵梦萦的渴望与热情终于喷薄而出。"
    translate None illranveras_scene4_0045:
        "维拉斯手掌所触之处，伊尔兰都感到炽热蔓延全身。心跳快得几乎要冲破胸腔。"
    translate None illranveras_scene4_0046:
        imn "若此生仅此一次机会…我必须告诉他。"
    translate None illranveras_scene4_0047:
        "伊尔兰五指深深插入那蜜桃色的凌乱发丝间。轻轻拉扯时，维拉斯泄出一声明显的喘息。"
    translate None illranveras_scene4_0048:
        v "我…伊尔兰…"
    translate None illranveras_scene4_0049:
        "伊尔兰的唇离开他的嘴，沿着维拉斯的颈项落下细碎轻吻。触到的每一寸肌肤依旧冰冷刺骨。"
    translate None illranveras_scene4_0050:
        i "你很冷吗？"
    translate None illranveras_scene4_0051:
        v "有…有一点…"
    translate None illranveras_scene4_0052:
        "伊尔兰喘着灼热气息，余光瞥向温泉氤氲的热雾，视线又落回维拉斯脸上。"
    translate None illranveras_scene4_0053:
        stop music fadeout 4.0
        i "泡个温泉如何？"

    hide veras
    hide illran
    play music "sounds/bgm/moonnight.ogg" fadein 4.0
    show bg sc mountains day:
        xpos 0.51 ypos 1.41 xanchor 0.5 yanchor 1.05 zoom 1.6
        linear 15.0 xpos 0.51 ypos 1.67 xanchor 0.5 yanchor 1.05 zoom 1.6
    with dissolve
    translate None illranveras_scene4_0054:
        "伊尔兰一把扯下维拉斯颈间的围巾，随手抛向石堆。羊毛围巾在岩石上蜷成一团，像被遗弃的罪证。"
    translate None illranveras_scene4_0055:
        "维拉斯抚过他的身躯时，激起一片战栗的鸡皮疙瘩。伊尔兰肌肉线条分明，但亲手触碰又是另一番感受。"
    translate None illranveras_scene4_0056:
        "伊尔兰利落地解开维拉斯斗篷的搭扣，却被对方拽住衣襟推开。"
    translate None illranveras_scene4_0057:
        "他双颊绯红—与往日沉着冷静的模样判若两人。"
    translate None illranveras_scene4_0058:
        v emb "我觉得这实在不妥，伊尔兰，真的—"
    translate None illranveras_scene4_0059:
        i blu "有时最坏的抉择反而是最佳选择。看看我的人生就知道了。"
    translate None illranveras_scene4_0060:
        "维拉斯低垂着眼帘陷入沉思，浓密的黑色睫毛在肌肤上投下阴影。当他突然像下定决心般再次抬眸与伊尔兰四目相对时，松开了攥着斗篷的手。"
    translate None illranveras_scene4_0061:
        "解开的斗篷前襟大敞，露出几片瓷器般光洁的肌肤。伊尔兰感到喉结重重滚动了一下。"
    translate None illranveras_scene4_0062:
        imn "他真美啊…"
    translate None illranveras_scene4_0063:
        i "你先下去吧。我马上就来。"
    translate None illranveras_scene4_0064:
        "点头时，他的斗篷滑落在地。"
    translate None illranveras_scene4_0065:
        "这本是他司空见惯的景象。"
    translate None illranveras_scene4_0066:
        "那具躯体。美得不像凡人该有的模样。"
    translate None illranveras_scene4_0067:
        "可为何此刻感觉如此不同？"
    translate None illranveras_scene4_0068:
        "是因为他灼热凝视伊尔兰的眼神？是因为他将纤足探入温泉的姿势？还是他让池水漫过腰际时荡漾的波纹？"
    translate None illranveras_scene4_0069:
        "伊尔兰别过脸，面颊早已烧得通红。"
    translate None illranveras_scene4_0070:
        imn "冷静点伊尔兰，别为这种小事心神不宁。镇定，镇定…"
    translate None illranveras_scene4_0071:
        "脱衣的过程漫长得令人煎熬。身后就是他深爱的人，正赤裸着等待他。"
    translate None illranveras_scene4_0072:
        "衣物一件件坠落在岩地上堆成小山，他终于能够踏入泉中。"
    translate None illranveras_scene4_0073:
        "当伊尔兰破开水面时，维拉斯的视线游移闪躲。尽管无法看见对方，他仍偏过头去。伊尔兰沉入水中，坐在岩石天然形成的浅阶上。"
    translate None illranveras_scene4_0074:
        "两人之间隔着一段距离。一片寂静。"
    translate None illranveras_scene4_0075:
        "但这寂静只持续了片刻。"
    translate None illranveras_scene4_0076:
        "维拉斯敞露在严寒中的胸膛缓缓贴近，直至与伊尔兰肌肤相触。这样便足够。"

    window hide dissolve
    scene gallery_108:
        xpos 0.45 ypos 1.28 xanchor 0.5 yanchor 1.0 zoom 1.32

    if persistent.streamer_mode == True:
        show illran_first_sex_censor:
            xpos 0.45 ypos 1.28 xanchor 0.5 yanchor 1.0 zoom 1.32
    with dissolve

    window show dissolve
    translate None illranveras_scene4_0077:
        "伊尔兰半立起身俯向维拉斯，低头吻住他。维拉斯湿漉漉的手攀上对方后颈，回应着这个吻。"
    translate None illranveras_scene4_0078:
        "他们的身躯如此自然地交融，就像拼图最后两片终于严丝合缝。"
    translate None illranveras_scene4_0079:
        "温泉很热—尤其在凛冽山风中站立过后—但伊尔兰不确定此刻灼烧着他的究竟是水温，还是…"
    translate None illranveras_scene4_0080:
        "他忍不住透过半阖的眼睑偷瞥身下之人。"
    translate None illranveras_scene4_0081:
        "维拉斯轻轻咬住下唇，伊尔兰将此视为信号般更深地沉入他怀中，沉醉于维拉斯指尖的触感。"
    translate None illranveras_scene4_0082:
        "温柔却坚定。一如他本人。"
    translate None illranveras_scene4_0083:
        "这几乎令人难以承受。感觉如此不真实，仿佛眨眼间维拉斯就会消失。"
    translate None illranveras_scene4_0084:
        imn "…其实这近乎事实，不是吗？这就是结局…"
    translate None illranveras_scene4_0085:
        "大腿上传来的轻柔触摸将他拉回现实。维拉斯的手贴着他，缓缓游移至髋部，指尖深深嵌入肌肤。"
    translate None illranveras_scene4_0086:
        v "伊尔兰，我—"
    translate None illranveras_scene4_0087:
        scene gallery_107:
            xpos 0.45 ypos 1.28 xanchor 0.5 yanchor 1.0 zoom 1.32
        if persistent.streamer_mode == True:
            show illran_first_sex_censor:
                xpos 0.45 ypos 1.28 xanchor 0.5 yanchor 1.0 zoom 1.32
        with dissolve
        "维拉斯猛然抽身，双臂环抱着伊尔兰喘息粗重。伊尔兰无法克制地回望他眼眸，同样心旌摇曳。"
    translate None illranveras_scene4_0088:
        i "…要我停下来吗？"
    translate None illranveras_scene4_0089:
        v "…不，一刻都不想。"
    translate None illranveras_scene4_0090:
        "维拉斯从伊尔兰颈间抽回一条手臂，轻柔抚过他的脸颊，眼中交织着情欲与哀伤。"
    translate None illranveras_scene4_0091:
        v "我只是想道歉。这不是错误。只是不愿伤害你。谁都可以，唯独不能是你。"
    translate None illranveras_scene4_0092:
        i "...."
    translate None illranveras_scene4_0093:
        imn "可你还是会离开我。"
    translate None illranveras_scene4_0094:
        imn "不，别这么想伊尔兰。你太自私了。将他禁锢在此只会造成伤害。我宁愿独活一世，也不愿他承受永恒的痛苦。"
    translate None illranveras_scene4_0095:
        i "你是我全部所求，维拉斯。无论你做什么都…都不会伤我分毫。"
    translate None illranveras_scene4_0096:
        "维拉斯用神情诉说着\'即便我无法留在你身边？\'，却始终紧抿双唇。"
    translate None illranveras_scene4_0097:
        "他们心知肚明。"
    translate None illranveras_scene4_0098:
        "又何必说破此刻良辰？"
    translate None illranveras_scene4_0099:
        scene gallery_108:
            xpos 0.45 ypos 1.28 xanchor 0.5 yanchor 1.0 zoom 1.32
        if persistent.streamer_mode == True:
            show illran_first_sex_censor:
                xpos 0.45 ypos 1.28 xanchor 0.5 yanchor 1.0 zoom 1.32
        with dissolve
        "随着柔情牵引，维拉斯消弭了二人间距，唇瓣再度相合。"
    translate None illranveras_scene4_0100:
        "身躯紧密相贴，以积攒七年的炽烈热吻，很快便唤起彼此反应。"
    translate None illranveras_scene4_0101:
        "现实逐渐褪色。锡德卡汉、恶魔、诸神、言者，尽数消散。"
    translate None illranveras_scene4_0102:
        "此刻他们不过是两个比渴望万物更渴望彼此的凡人。"
    translate None illranveras_scene4_0103:
        "伊尔兰能感觉到维拉斯加速的心跳正撞击自己胸膛。如此急促，与往日感受截然不同，但他确信自己的心跳同样剧烈。"
    translate None illranveras_scene4_0104:
        "怎能不为之悸动？"
    translate None illranveras_scene4_0105:
        "伊尔兰的手指滑过对方苍白透明的肌肤，轻掠过胸膛，而后温柔握住了维拉斯半硬的阴茎。"
    translate None illranveras_scene4_0106:
        v "啊！"
    translate None illranveras_scene4_0107:
        "从这样简单轻柔的触碰开始，那物事在他手中逐渐硬挺。伊尔兰的手指滑过自己的阳具，感受着维拉斯的每一寸他从未触碰过的肌肤，目睹着这个他认为永远无法看到的另一面。"
    translate None illranveras_scene4_0108:
        "随着他们的吻逐渐加深，伊尔兰的手开始动作时，维拉斯贴着他的唇间发出了呻吟。"
    translate None illranveras_scene4_0109:
        imn "你怎么能如此完美？"
    translate None illranveras_scene4_0110:
        scene gallery_107
        if persistent.streamer_mode == True:
            show illran_first_sex_censor
        with dissolve
        "怀着这个念头，伊尔兰结束了这个吻，迫切地想要看清维拉斯脸上闪过的每个表情。"
    translate None illranveras_scene4_0111:
        "他的头向后仰靠在石壁上，眉头紧锁，唇间泄出细碎的喘息。"
    translate None illranveras_scene4_0112:
        v "啊，伊尔兰……"
    translate None illranveras_scene4_0113:
        "他呼唤自己名字的方式让伊尔兰脊背发麻。"
    translate None illranveras_scene4_0114:
        v "等…等等，啊…你也…"
    translate None illranveras_scene4_0115:
        "维拉斯修长灵巧的手指环住了伊尔兰的阳具。他的套弄带着挑逗般的缓慢与性感，但仅持续了片刻就转而将两人的性器相贴，把自己的手覆在伊尔兰的手背上。"
    translate None illranveras_scene4_0116:
        v "我想一起做。"
    translate None illranveras_scene4_0117:
        scene gallery_108
        if persistent.streamer_mode == True:
            show illran_first_sex_censor
        with dissolve
        "他们的手同步动作着，此刻的伊尔兰不可能不吻他。在交错的亲吻间，他们相互呢喃着对方的名字，彼此间的温度灼热得令人窒息。"
    translate None illranveras_scene4_0118:
        "每次触碰都让伊尔兰头晕目眩。如果再继续下去，他肯定坚持不了多久。尤其是面对着维拉斯这样的人。"
    translate None illranveras_scene4_0119:
        "但他渴望更多。他想在维拉斯每寸肌肤都刻下自己的印记。他想占有那些连做梦都不敢幻想的部位。"
    translate None illranveras_scene4_0120:
        "无论他如何试图驱散这些念头，每次套弄都让他无法自控地再次沉溺其中。"
    translate None illranveras_scene4_0121:
        imn "我本不该奢求更多—"
    translate None illranveras_scene4_0122:
        scene gallery_107
        if persistent.streamer_mode == True:
            show illran_first_sex_censor
        with dissolve
        v "啊…伊尔兰…求你，我想要你…"
    translate None illranveras_scene4_0123:
        i "真的…可以吗？"
    translate None illranveras_scene4_0124:
        "得到点头回应后，伊尔兰的手指抵住了维拉斯的入口，而那位桃红色头发的男子仍独自握着两人性器动作。"
    translate None illranveras_scene4_0125:
        scene gallery_108
        if persistent.streamer_mode == True:
            show illran_first_sex_censor
        with dissolve
        "每次维拉斯的手部动作，都像电流般穿透伊尔兰全身。与维拉斯紧密相贴的感觉远超出他的想象。他倒吸一口气，再度吻住了维拉斯。"
    translate None illranveras_scene4_0126:
        "伊尔兰的手指在入口处徘徊试探，只是轻柔地抚过维拉斯。在他身下，维拉斯早已发出夹带着呻吟的喘息。"
    translate None illranveras_scene4_0127:
        "他将一根手指缓缓推入，观察着对方的面部反应。很紧，伊尔兰不禁怀疑这是否是对方以人类形态经历的初次体验。"
    translate None illranveras_scene4_0128:
        "他开始缓慢抽送，时刻留意维拉斯的反应。几次轻柔的推进后，维拉斯终于吐出屏住的呼吸，在伊尔兰耳畔发出呻吟。"
    translate None illranveras_scene4_0129:
        i "会痛吗？不舒服就叫停。"
    translate None illranveras_scene4_0130:
        v "别…别太紧张，伊尔兰。不痛，只是…很陌生…"
    translate None illranveras_scene4_0131:
        i "我会让你舒服的，我保证。"
    translate None illranveras_scene4_0132:
        "对维拉斯而言，他正逐渐适应这种被轻柔撑开的感觉，适应伊尔兰手指的进出。温热的水流让知觉愈发鲜明。"
    translate None illranveras_scene4_0133:
        "随着适应程度加深，维拉斯发现自己开始配合伊尔兰的节奏摆动腰肢。"
    translate None illranveras_scene4_0134:
        i "再加一根手指好吗？"
    translate None illranveras_scene4_0135:
        "维拉斯点头应允，伊尔兰缓缓加入中指。虽然紧致，但这次维拉斯回应的是绵长的低吟。"
    translate None illranveras_scene4_0136:
        "伊尔兰将手指探得更深，动作变得坚定。他能感觉到自己体内积聚的压力亟待宣泄，却又不愿此刻结束。"
    translate None illranveras_scene4_0137:
        "维拉斯的呼吸急促起来，身躯仍与伊尔兰贴合律动，逐渐加快节奏。"
    translate None illranveras_scene4_0138:
        i "嗯…维拉斯，等等，我还不能…"
    translate None illranveras_scene4_0139:
        "维拉斯双手停顿，立即会意。这就是他们的默契所在。无需言语。"
    translate None illranveras_scene4_0140:
        "伊尔兰加入第三指，先以缓慢抽插让维拉斯适应，再恢复原先的节奏。水面荡开层层涟漪，拍打着石壁边缘。"
    translate None illranveras_scene4_0141:
        v "啊，呃…伊尔兰…我..我等不下去了…"
    translate None illranveras_scene4_0142:
        i "我也是，但…你确定吗？我不想超出你的承受范围。"
    translate None illranveras_scene4_0143:
        v "求你了…？"
    translate None illranveras_scene4_0144:
        "伊尔兰向来以自制力为傲。"
    translate None illranveras_scene4_0145:
        "至少在平时是的。"
    translate None illranveras_scene4_0146:
        "他抽离三指，调整姿势覆上维拉斯躯体。维拉斯抬腰相迎。"
    translate None illranveras_scene4_0147:
        "伊尔兰小心挺进，仅在顶端没入时暂停，听得维拉斯倒抽一口气。"
    translate None illranveras_scene4_0148:
        v "继续…我不想你停下。"
    translate None illranveras_scene4_0149:
        i "你确定吗..？我—"
    translate None illranveras_scene4_0150:
        v "我确定。"
    translate None illranveras_scene4_0151:
        "维拉斯紧紧攥着他的手，指甲陷入伊尔兰的手背，而他缓慢推进着。终于，他停了下来—完全被维拉斯包裹。"
    translate None illranveras_scene4_0152:
        v "是…完全进去了吗…？"
    translate None illranveras_scene4_0153:
        "伊尔兰俯下身，在维拉斯的每只眼睑上留下一个吻。"
    translate None illranveras_scene4_0154:
        scene gallery_107
        if persistent.streamer_mode == True:
            show illran_first_sex_censor
        with dissolve
        i "嗯…我现在要慢慢动了，好吗？"
    translate None illranveras_scene4_0155:
        "他平稳地退出，拼命试图保持镇定，但那紧致的热度已让他觉得自己快要发疯。接着，他又一次缓慢地完全进入。"
    translate None illranveras_scene4_0156:
        "他这样重复了几次，慢慢加快速度。身下的维拉斯面色从痛苦转为愉悦，但他仍能看出需要时间适应。"
    translate None illranveras_scene4_0157:
        "一只手被维拉斯紧握，另一只手自由活动，他握住维拉斯的硬挺，按着抽插的节奏撸动。"
    translate None illranveras_scene4_0158:
        v "啊…嗯…"
    translate None illranveras_scene4_0159:
        "维拉斯的腰终于开始摆动，与伊尔兰交缠，这只会让他更加兴奋。抽插愈发急促，呻吟愈发响亮，在石壁间回荡。"
    translate None illranveras_scene4_0160:
        scene gallery_108
        if persistent.streamer_mode == True:
            show illran_first_sex_censor
        with dissolve
        "喘着粗气，他们的唇找到彼此，仿佛世界上再无其他重要之事。"
    translate None illranveras_scene4_0161:
        "伊尔兰的自制力正以他无法控制的速度瓦解。他只愿永远与维拉斯停留在此刻。"
    translate None illranveras_scene4_0162:
        "维拉斯的声音一贯动听，但可曾像此刻这般美妙？他的面孔总是英俊，但真的总是那么{i}令人窒息{/i}的英俊吗？"
    translate None illranveras_scene4_0163:
        imn "啊，该死。我真的爱他，不是吗？"
    translate None illranveras_scene4_0164:
        i "嗯…维拉斯…."
    translate None illranveras_scene4_0165:
        "伊尔兰捏紧维拉斯的手，加快节奏，吻得更加迫切，而后退开喘息。"
    translate None illranveras_scene4_0166:
        "他觉得自己甘愿溺死在这感觉里。"
    translate None illranveras_scene4_0167:
        "维拉斯的呻吟越发急促，仅仅是听他如此欢愉的声音就将他推向极限。"
        scene gallery_107
        if persistent.streamer_mode == True:
            show illran_first_sex_censor
        with dissolve
    translate None illranveras_scene4_0168:
        i "我要…"
    translate None illranveras_scene4_0169:
        imn "我爱你，维拉斯。"
    translate None illranveras_scene4_0170:
        i "我真的…"
    translate None illranveras_scene4_0171:
        imn "我真的快到了。"
    translate None illranveras_scene4_0172:
        i "…我真的爱上了你。"
    translate None illranveras_scene4_0173:
        imn "…"
    translate None illranveras_scene4_0174:
        imn "…等等，什么？"
    translate None illranveras_scene4_0175:
        i "等等，那是…呃…不是我…"
    translate None illranveras_scene4_0176:
        v "我…我也是…"
    translate None illranveras_scene4_0177:
        v "你是…你是我的…灵魂伴侣…"
    translate None illranveras_scene4_0178:
        "若说有什么仍在羁绊着伊尔兰，维拉斯的话语已将那最后一根丝线彻底斩断。欢愉攀升至顶峰，维拉斯猛然收紧身体，他眼前炸开一片白光。"
    translate None illranveras_scene4_0179:
        "他刚结束，维拉斯也随之到达，发出一声低沉的呻吟。"
    translate None illranveras_scene4_0180:
        "伊尔兰几乎瘫软，维拉斯及时伸手将他揽入怀中，让他的脸庞浮在水面之上。"
    translate None illranveras_scene4_0181:
        i "哈啊……"
    translate None illranveras_scene4_0182:
        v "伊尔兰…你还好么…？"
    translate None illranveras_scene4_0183:

        i "你刚才…是认真的？"
    translate None illranveras_scene4_0184:
        v "…我不会对你说谎。"
    translate None illranveras_scene4_0185:
        i "那么—"
    translate None illranveras_scene4_0186:
        v "但…正因我如此在乎你，才不能留下。"
    translate None illranveras_scene4_0187:
        v "爱一个人就意味着终将失去，而我…我做不到，伊尔兰。"
    translate None illranveras_scene4_0188:
        i "......"
    translate None illranveras_scene4_0189:
        i "是啊…是啊，当然了。"
    translate None illranveras_scene4_0190:
        "伊尔兰恍惚地想，幸好他们置身于此。温泉蒸腾的热气，至少能遮掩他已开始在眼角凝聚的泪水。"
    translate None illranveras_scene4_0191:
        "即便维拉斯看不见，至少他能欺骗自己。"
    translate None illranveras_scene4_0192:
        "…但雾气掩盖不了哽咽的嗓音，而这正是维拉斯自诩擅长分辨的。"

    if achievement.has("illran_love"):
        pass
    else:
        $ renpy.display_notify("成就解锁：我无法停留")

    python:
        achievement.grant("illran_love")
        achievement.sync()


    if cyne_route:
        stop music fadeout 2.0
        scene bg sv day:
            xpos 0.29 ypos 1.03 xanchor 0.5 yanchor 1.0 zoom 1.46

        show raen nw cloak sad at cenleft
        show morwen n cloak sad at cenright
        show cyne nw cloak neu at farleft
        show sylvir n neu at farright
        with Fade(1.0, 1.0, 1.0)
        play music "sounds/bgm/Discovery.ogg" fadein 2.0
        jump cyneraencont

    if leos_route:
        stop music fadeout 2.0
        scene bg sv day:
            xpos 0.09 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 2.02

        show sylvir n neu at slightright
        show leos nw pis cloak at left
        show raen nw sur cloak at slightleft
        with Fade(1.0, 1.0, 1.0)
        play music "sounds/bgm/Discovery.ogg" fadein 2.0
        jump leosraen3cont


    if fawn_route:
        stop music fadeout 2.0
        scene bg sv day with Fade(1.0, 1.0, 1.0):
            xpos 0.09 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 2.02
        play music "sounds/bgm/Discovery.ogg" fadein 2.0
        jump fawnroute5cont










    #
