label chapter_three_start:
    scene black with dissolve
    show spirits
    pause(2.0)
    translate None chapter_three_0001:
        n "雷恩…雷恩…醒醒…"
    translate None chapter_three_0002:
        n "安全…找到他…"
    translate None chapter_three_0003:
        n "离开…远离…这里…"


    window show dissolve
    translate None chapter_three_0004:
        rs hur "呃…"
    translate None chapter_three_0005:
        "我在哪…？"
    translate None chapter_three_0006:
        "我在地上。为什么…？"
    translate None chapter_three_0007:
        "那场大火？"
    translate None chapter_three_0008:
        "那个人？"
    translate None chapter_three_0009:
        "福恩…福恩！"
    translate None chapter_three_0010:
        rs sur "福恩！"


    scene bg forest with eye_open
    show raen n hur at center
    show expression AlphaMask("foliage_1", At("raen n hur（原文保留）", center)) as mask
    with dis
    translate None chapter_three_0011:
        f hur "雷恩…"
    translate None chapter_three_0012:
        "当我坐起身时，周围的世界天旋地转。"
    translate None chapter_three_0013:
        "福恩瘫在不远处的地上。"
    translate None chapter_three_0014:
        "我爬向他。他看起来没受伤，但似乎神志不清。"
    translate None chapter_three_0015:
        rs "你…你还好吗？"

    show raen n hur at centtosr
    show expression AlphaMask("foliage_1", At("raen n hur（原文保留）", centtosr)) as mask
    pause (0.1)
    show fawn n sad at slightleft
    show expression AlphaMask("foliage_1", At("fawn n sad", slightleft)) as mask2
    with dis
    translate None chapter_three_0016:
        f "我没事…我只是…"
    translate None chapter_three_0017:
        f "呃…什么？我在哪里…？"
    translate None chapter_three_0018:
        f "刚才发生了什么？"
    translate None chapter_three_0019:
        "他看起来有些困惑，但我不怪他。我也很困惑。只希望他没撞到头。"
    translate None chapter_three_0020:
        "我检查了他的身体。有些擦伤，但没有流血。呼。"

    play music "sounds/bgm/sad.ogg" fadeout 1
    translate None chapter_three_0021:
        "缓缓地，我回头看向福恩的房子。"
    translate None chapter_three_0022:
        "或者说—曾经是房子的地方，现在只剩一片废墟。"

    show raen n sad with dis
    translate None chapter_three_0023:
        "刚才到底发生了什么？"
    translate None chapter_three_0024:
        "房子在坠落，然后…"
    translate None chapter_three_0025:
        "我只记得一声巨响。"
    translate None chapter_three_0026:
        rs "我想…是爆炸了。你房里有什么易燃物吗？"
    translate None chapter_three_0027:
        "周遭的地面和树木轻微焦黑，但最猛烈的火焰已经熄灭。只有余烬在地上噼啪作响。"
    translate None chapter_three_0028:
        "烟熏得我喉咙嘶哑。真希望有点水喝…"
    translate None chapter_three_0029:
        rs "...."
    translate None chapter_three_0030:
        "福恩拥有的一切都消失了。他所有的物品、收藏、心爱之物…"
    translate None chapter_three_0031:
        rs "我真的很-"
    translate None chapter_three_0032:
        f "我…我现在该怎么办…？"
    translate None chapter_three_0033:
        f "这都是…这都是我的错…"
    translate None chapter_three_0034:
        f "我在受惩罚…"
    translate None chapter_three_0035:
        rs "不是…那些人-"

    hide mask2
    show fawn n hur at shakeleft
    show expression AlphaMask("foliage_1", At("福恩 与 赫尔", shakeleft)) as mask2
    translate None chapter_three_0036:
        f "现…现在我还剩下什么？"
    translate None chapter_three_0037:
        "他的问题悬在空中，久久不散。我不知道该说什么。"
    translate None chapter_three_0038:
        "面对失去一切的人，你能说什么？"
    translate None chapter_three_0039:
        "无话可说。我无力挽回。这更令人痛苦。"
    translate None chapter_three_0040:
        f "我的朋友们…"

    show fawn n sad with dis
    translate None chapter_three_0041:
        f "他们在哪？！"
    translate None chapter_three_0042:
        f "......"
    translate None chapter_three_0043:
        rs "对不起，福恩…"
    translate None chapter_three_0044:
        rs "真希望我能做点什么…"
    translate None chapter_three_0045:
        "但干坐着解决不了问题。"
    translate None chapter_three_0046:
        "我撑起身子，起初有些摇晃。烟肯定呛到脑子了。"
    translate None chapter_three_0047:
        rs "我去看看有没有东西幸存-"
    translate None chapter_three_0048:
        f "你觉得…"

    show fawn n neu with dis
    translate None chapter_three_0049:
        "福恩从林地上抬头看我。"
    translate None chapter_three_0050:
        rs "…其他人呢？"
    translate None chapter_three_0051:
        rs "我不知道…"
    translate None chapter_three_0052:
        f "我会跟你一起去的。"
    translate None chapter_three_0053:
        "我向福恩伸出手，把他拉到我身边。"
    translate None chapter_three_0054:
        "这真是太…太可怕了。我侧目看向福恩，庆幸有他在身旁。我不知道我们会发现什么，也很担心那些奇怪的男人…"
    translate None chapter_three_0055:
        "他们还在这附近吗，还是…"



    scene bg forest with dissolve:
        xpos 0.32 ypos 1.44 xanchor 0.5 yanchor 1.0 zoom 1.47
        linear 35.0 xpos 0.71 ypos 1.44 xanchor 0.5 yanchor 1.0 zoom 1.47
    play sound "sounds/sfx/walkingearth.ogg" fadeout 1
    translate None chapter_three_0056:
        "我们走向那堆还在闷烧的木头，那里曾经是福恩的家。"
    translate None chapter_three_0057:
        "我看到福恩的宝贝散落一地，大多烧得焦黑难辨。"
    translate None chapter_three_0058:
        "我蹲下身子，拨开灰烬和碎石。捡起一个不知怎的逃过大火的小木玩具。是只动物。"
    translate None chapter_three_0059:
        "当我把它递给福恩时，他脸上浮现出一个小小的、悲伤的笑容。"

    scene bg forest
    show fawn n sad at slightleft
    show expression AlphaMask("foliage_1", At("fawn n sad", slightleft)) as mask
    show raen n sad at slightright
    show expression AlphaMask("foliage_1", At("雷恩 悲伤", slightright))
    with dissolve

    translate None chapter_three_0060:
        f "谢谢…"
    translate None chapter_three_0061:
        rs "对不起…"
    translate None chapter_three_0062:
        rs "我觉得如果我不在这里，这些事就不会发生在你身上…"
    translate None chapter_three_0063:
        "我无法承受这种愧疚。胸口发闷，仿佛慢慢吞噬着我。我是他在这里见到的第一个人，他本不必对我这么好。看看他得到了什么回报。"
    translate None chapter_three_0064:
        "他一生的心血在一夜之间毁于一旦。他建立的一切，他爱的一切…全都消失了。"
    translate None chapter_three_0065:
        f "不。这不是你的错。"
    translate None chapter_three_0066:
        f "我不想让你自责…这都是因为我…"
    translate None chapter_three_0067:
        rs "...."
    translate None chapter_three_0068:
        "我不知道自己还能强忍泪水多久。"
    translate None chapter_three_0069:
        "我们合力搬开一些残骸，终于辨认出几块布料的碎片。"
    translate None chapter_three_0070:
        "全都熔在那下面毫无生气的躯体上。"
    translate None chapter_three_0071:
        "尽管令人作呕，我却无法移开视线。他们…他们也是人啊，即使福恩的遭遇可能要怪他们…"
    translate None chapter_three_0072:
        rs "我猜…他们没能活下来…"
    translate None chapter_three_0073:
        "那两个男人被半埋在废墟下。"
    translate None chapter_three_0074:
        "他们毫无机会。但愿树倒下时他们死得痛快，而不是在火中慢慢煎熬。"
    translate None chapter_three_0075:
        "福恩用手臂环住我的肩膀，让我转过身去不再看那可怕的一幕。"
    translate None chapter_three_0076:
        f "别看了…只会更难受。"
    translate None chapter_three_0077:
        rs "你说得对。"
    translate None chapter_three_0078:
        rs "你…看到第三个了吗？"
    translate None chapter_three_0079:
        f "….我不确定，所有东西都烧得面目全非…"
    translate None chapter_three_0080:
        "他当时站得离我们那么近，我几乎能碰到他…他可能还活着。"
    translate None chapter_three_0081:
        "如果他还活着，是仍然在这附近？还是看到同伴的下场就逃走了？"
    translate None chapter_three_0082:
        "我不知道。"
    translate None chapter_three_0083:
        "我环顾四周。什么都没有，什么都没有…等等…"

    stop music fadeout 3.0
    translate None chapter_three_0084:
        "我在绿叶间瞥见一抹红色。"
    translate None chapter_three_0085:
        "那是什么？"

    show raen n sur with dis
    translate None chapter_three_0086:
        rs "等等…看那边。"
    translate None chapter_three_0087:
        "我朝那抹鲜艳的红色走去，拨开挡路的焦黑树枝。"
    translate None chapter_three_0088:
        "我的呼吸为之一窒。"

    #window hide dissolve

    scene bg forest with dissolve:
        size (1920, 1080) crop ((0, 318, 1216, 761))
    #window show dissolve
    play sound "sounds/sfx/creepy3.ogg" fadeout 1
    translate None chapter_three_0089:
        "一个男人颓然靠在树干上。长长的红发散落，眉头因痛苦而紧蹙。"
    translate None chapter_three_0090:
        "这也不是我第一次见到他了。"
    translate None chapter_three_0091:
        "就是几天前偶遇的那个男人。"
    translate None chapter_three_0092:
        "那个告诉我言者档案馆的人。"
    translate None chapter_three_0093:
        "来自奥雷利亚卡维拉的男人。"
    translate None chapter_three_0094:
        rs sur "不可能…"
    translate None chapter_three_0095:
        "身后传来一声惊呼。我们都没想到会这么轻易找到他。"
    translate None chapter_three_0096:
        leosu "呃啊…该死…"
    translate None chapter_three_0097:
        "万千疑问在我脑海盘旋，但现在不是时候。他看起来受伤了。"
    translate None chapter_three_0098:
        "我缓慢而安静地向他挪近。从远处看，他只有些擦伤和淤青，不算太严重。"
    translate None chapter_three_0099:
        "腹部和手臂也有些疤痕，但看起来像是旧伤。"
    translate None chapter_three_0100:
        "这些伤是怎么来的…？"
    translate None chapter_three_0101:
        "我在他身旁跪下。此刻，他的所作所为都不重要。他需要帮助。"
    translate None chapter_three_0102:
        "我从腿部开始检查，慢慢往上。这里没有受伤。"
    translate None chapter_three_0103:
        "腹部除了一两处淤青外也无碍。"
    show leos m hur
    show expression AlphaMask("foliage_1", At("莱奥斯 m hur", center)) as mask1
    with dis
    translate None chapter_three_0104:
        "我抬头看向他的脸。原先因痛苦紧闭的双眼此刻正紧盯着我。他看起来很不悦。"
    translate None chapter_three_0105:
        rs sur "啊！"
    translate None chapter_three_0106:
        "我离得太近了-"

    play sound "sounds/sfx/knifeunsheath.ogg" fadeout 1
    translate None chapter_three_0107:
        "刹那间，一把刀刃已抵住我的喉咙。"
    translate None chapter_three_0108:
        "我僵住了。怎么办？！"
    translate None chapter_three_0109:
        "他用力将刀刃压向我的皮肤，我感到一阵温热刺痛。"

    window hide

    show bg forest with flashred
    window show dissolve
    translate None chapter_three_0110:
        "…紧接着是液体顺着喉咙流下的感觉。"
    translate None chapter_three_0111:
        "我咽了咽口水，但口腔干涩得厉害。"
    translate None chapter_three_0112:
        "他的目光始终没离开过我。那眼神在审视我，仿佛在评判我的一举一动。"
    translate None chapter_three_0113:
        rs hur "你..你受伤了..让我-"

    show leos m smi with dis
    translate None chapter_three_0114:
        leosu "哈。你觉得我需要你这种人的帮助？"
    translate None chapter_three_0115:
        "他对我露出讥笑，尽管明显仍在忍痛。"
    translate None chapter_three_0116:
        leosu "我宁可死也不会让你这小不点-"

    show leos m hur with dis
    translate None chapter_three_0117:
        "话说到一半，他突然剧烈咳嗽起来。那咳声嘶哑响亮。"
    translate None chapter_three_0118:
        "机会来了-"

    show leos m hur at shakecen
    hide mask1
    show expression AlphaMask("foliage_1", At("莱奥斯 m hur", shakecen)) as mask2
    translate None chapter_three_0119:
        f hur "逮到你了！"

    #window hide dissolve

    scene bg forest
    #window show dissolve
    show leos n hur at right
    show expression AlphaMask("foliage_1", At("莱奥斯 n hur", right)) as mask
    show fawn n hur at center
    show expression AlphaMask("foliage_1", At("福恩 与 赫尔", center)) as mask2
    show raen n sur at left
    show expression AlphaMask("foliage_1", At("雷恩 微笑", left)) as mask3
    with dissolve
    translate None chapter_three_0120:
        "还没等我反应过来，福恩已走到身旁，一把打掉了那人手中的刀刃。"
    translate None chapter_three_0121:
        "我条件反射地捂住喉咙。掌心传来湿黏触感，但伤口似乎不深。刺痛感很轻微。"
    translate None chapter_three_0122:
        "当这个受伤者开始摸索其他东西时，我注意到他刚才咳嗽过的手掌沾满鲜血。"
    translate None chapter_three_0123:
        "等等。"
    translate None chapter_three_0124:
        "其他东西..？"


    hide mask3
    show raen n sur at lefttocen
    show expression AlphaMask("foliage_1", At("雷恩 微笑", lefttocen)) as mask3
    hide mask2
    show fawn n hur at centoleft
    show expression AlphaMask("foliage_1", At("福恩 与 赫尔", centoleft)) as mask4 behind raen
    translate None chapter_three_0125:
        "我迅速钳住他双臂。肌肉线条分明且结实…他显然体格健壮，远胜于我，但伤势多少削弱了他的力气。"

    show fawn n neu with dis
    translate None chapter_three_0126:
        rs "福恩，检查他是否还有别的武器。"
    translate None chapter_three_0127:
        "一，二，三…"
    translate None chapter_three_0128:
        "六把匕首。还有一条鞭子。"
    translate None chapter_three_0129:
        rs "你可真是…装备精良。"
    translate None chapter_three_0130:
        leosu "曾经是。现在啥都不剩了。"
    translate None chapter_three_0131:
        "我松开他的手臂。此刻他已无力挣扎。"
    translate None chapter_three_0132:
        "我再次端详他的面容。一缕鲜血正从嘴角蜿蜒而下。"

    show raen n sad with dis
    translate None chapter_three_0133:
        rs "哪…哪些部位疼？"
    translate None chapter_three_0134:
        "我医术不精，但总能做些什么。"
    translate None chapter_three_0135:
        leosu "哪些部位疼？天啊，从哪儿说起…"
    translate None chapter_three_0136:
        leosu "腿，后背，肚子，喉咙…"
    translate None chapter_three_0137:
        leosu "但你知道最难受的是什么吗？"
    translate None chapter_three_0138:
        "我急切地望着他，准备施以援手。"

    show leos n smi with dis
    translate None chapter_three_0139:
        leosu "是你这张该死的蠢脸凑这么近。给我滚远点。"

    show raen n neu with dis
    translate None chapter_three_0140:
        "他兀自笑了。似乎觉得特别有趣。"
    translate None chapter_three_0141:
        "这种家伙到底要怎么相处…"
    translate None chapter_three_0142:
        f "那个…打扰了…我们只是想帮忙…"
    translate None chapter_three_0143:
        leosu "啥？不好意思，我听不懂老鼠叫。"

    show fawn n sad with dis
    translate None chapter_three_0144:
        f "哦，呃…抱歉…"

    show raen n sur with dis
    translate None chapter_three_0145:
        rs "道什么歉！他对你如此无礼！"
    translate None chapter_three_0146:
        rs "而你，明明急需救助，不管你愿不愿意我们都帮定了。"
    translate None chapter_three_0147:
        leosu "我倒要看看你怎么帮。"
    translate None chapter_three_0148:
        "怎么能不识好歹到这种地步？"
    translate None chapter_three_0149:
        "为何如此抗拒明摆着需要的帮助？"

    show raen n neu with dis
    translate None chapter_three_0150:
        rs "....."
    translate None chapter_three_0151:
        "前几天…我对福恩做的事…"
    translate None chapter_three_0152:
        "或许可以再试一次？"
    translate None chapter_three_0153:
        "我不欠这混蛋什么，可是…"
    translate None chapter_three_0154:
        "若我能分担些许他的痛苦…而非全部…"
    translate None chapter_three_0155:
        "虽然不知具体方法…但试试总无妨吧？"
    translate None chapter_three_0156:
        "福恩已缴了他的械，加之负伤，触碰他应该没多大危险？"
    translate None chapter_three_0157:
        "上一次我只碰了福恩一下就发生了那种事"
    translate None chapter_three_0158:
        "我向他伸出手去。他的手臂上布满割伤和淤青"

    show leos n ann with dis
    translate None chapter_three_0159:
        leosu "碰我试试看你会发生什么"

    show raen n smi with dis
    translate None chapter_three_0160:
        rs "听起来像是空洞的威胁。你能怎样？"
    translate None chapter_three_0161:
        "他连盯着我看都很勉强，所以我不信他现在还能做什么"
    translate None chapter_three_0162:
        "我没理会他的话，轻轻用手指碰了碰他的手腕"
    translate None chapter_three_0163:
        rs "........"

    show raen n sad with dis
    translate None chapter_three_0164:
        "一道闪光，轰鸣的声音…并没有。他的皮肤感觉温热，但什么都没发生"
    translate None chapter_three_0165:
        "上次明明有效的…"
    translate None chapter_three_0166:
        leosu "你他妈到底—"
    translate None chapter_three_0167:
        "他又开始剧烈咳嗽，更多血丝从嘴角渗出"
    translate None chapter_three_0168:
        "他先前的所有抵抗都消失了。他甚至没有甩开我的手"
    translate None chapter_three_0169:
        rs "你…你还好吗？"

    show leos n hur with dis
    translate None chapter_three_0170:
        leosu "…滚开…"
    translate None chapter_three_0171:
        rs "让我们帮帮你吧.."
    translate None chapter_three_0172:
        "他的眼睛慢慢眯起，最后完全闭上"
    translate None chapter_three_0173:
        leosu "....."


    hide leos
    hide mask
    with dissolve
    show raen n sad at centtosr
    show expression AlphaMask("foliage_1", At("雷恩 悲伤", centtosr)) as mask3
    hide mask4
    show fawn n sad at lefttosl
    show expression AlphaMask("foliage_1", At("fawn n sad", lefttosl)) as mask5

    translate None chapter_three_0174:
        rs "福恩…他为什么闭上眼睛了？"

    play music "sounds/bgm/scary.ogg" fadeout 1
    translate None chapter_three_0175:
        rs "他..他还好吗？我们该怎么办？！"
    translate None chapter_three_0176:
        "福恩冲到我身边，把匕首和鞭子扔在地上"
    translate None chapter_three_0177:
        "他小心地探查那人的颈部。我只能在一旁看着"
    translate None chapter_three_0178:
        "从未感觉如此无用"
    translate None chapter_three_0179:
        f "…他还活着"
    translate None chapter_three_0180:
        f "但显然伤得很重…得带他去能检查清理伤口的地方"
    translate None chapter_three_0181:
        "在这种时候，福恩就像变了个人"
    translate None chapter_three_0182:
        "可靠，强大…不像我.."

    show raen n sad with dis
    translate None chapter_three_0183:
        rs "…为什么不起作用了..？"
    translate None chapter_three_0184:
        "福恩若有所思地看了我一会儿"
    translate None chapter_three_0185:
        f "…我不知道"
    translate None chapter_three_0186:
        f "也许你还不能控制它。也许那次是个奇迹"
    translate None chapter_three_0187:
        rs "上次那些声音让我帮你…这次它们至寂无声…"
    translate None chapter_three_0188:
        rs "总之.."
    translate None chapter_three_0189:
        "我小心翼翼地把那人背起来。他比我高得多，这姿势很别扭"
    translate None chapter_three_0190:
        rs "福恩，你能收拾他的东西吗？我们带他去河边检查"

    show fawn n sur with dis
    translate None chapter_three_0191:
        f "啊，好的！"
    translate None chapter_three_0192:
        "他四处奔走，捡起散落在林间的武器"
    translate None chapter_three_0193:
        rs "好了，我们离开这儿"
    translate None chapter_three_0194:
        "福恩最后望了一眼他已成废墟的房子方向"
    translate None chapter_three_0195:
        "只停留一瞬，就转身跟上我"

    stop music fadeout 3.0
    window hide dissolve

    scene black with w19
    window show dissolve
    play sound "sounds/sfx/walkingearth.ogg" fadeout 1
    translate None chapter_three_0196:
        "拖着这家伙穿越森林绝非易事"
    translate None chapter_three_0197:
        "福恩最终不得不帮忙扶着我的腿，因为他的腿拖在地上，每次被灌木勾住都会呻吟扭动。真是不识好歹。"
    translate None chapter_three_0198:
        "真是个麻烦的家伙。"

    window hide dissolve

    scene bg river with w19
    window show dissolve
    show raen n neu at slightright
    show fawn n neu at slightleft
    with dissolve
    play music "sounds/sfx/riverrun.ogg"
    translate None chapter_three_0200:
        "我们终于到了河边。本该十五分钟的步行慢慢变成了一小时的挣扎。"

    play sound "sounds/sfx/fallonground.ogg" fadeout 1
    translate None chapter_three_0201:
        "我小心地把他放在地上，叹了口气。"
    show raen n sad with dis
    translate None chapter_three_0202:
        rs "啊…这比我预想的要长得多…"
    translate None chapter_three_0203:
        f "是啊…他太高了…"
    translate None chapter_three_0204:
        "红发男仍然昏迷不醒。这是我们检查他伤势的好机会，不用担心他抱怨。"
    translate None chapter_three_0205:
        "我们又检查了他裸露的手臂和腹部，但没发现致命伤。"
    translate None chapter_three_0206:
        "福恩开始清理伤口上的泥土，而我检查其他部位。"
    translate None chapter_three_0207:
        "他的脸—没问题。实际上五官挺好看的，但那糟糕的表情让人几乎注意不到。"
    translate None chapter_three_0208:
        "腿似乎没什么问题…摸起来肌肉很发达。我摸了一会儿就继续检查。"
    translate None chapter_three_0209:

        "我又看了眼从他嘴角缓缓流出的鲜血。"
    translate None chapter_three_0210:
        rs "我想…我应该检查他的嘴？"
    translate None chapter_three_0211:
        "我瞥向福恩寻求确认。他微微点了点头。"
    translate None chapter_three_0212:
        "好吧…开始了…"
    translate None chapter_three_0213:
        "我把手指贴到他嘴唇上。"
    translate None chapter_three_0214:
        "他的嘴唇很软，对于一个满嘴恶言的人来说软得出奇。"
    translate None chapter_three_0215:
        "我用手指分开他的嘴唇，撑开他的嘴。"

    show raen n sad at center
    show fawn n sur at left
    with move
    show leos n ann at right with dis
    translate None chapter_three_0216:
        leosu "....."
    translate None chapter_three_0217:
        "他突然睁开了眼睛。"
    translate None chapter_three_0218:
        "我们瞬间四目相对。"
    translate None chapter_three_0219:
        rs "....."

    show raen n sur with dis
    translate None chapter_three_0220:
        rs "啊！"
    translate None chapter_three_0221:
        leosu "泥展四不四想喔里滴叟纸巴主赖？（你是不想把手指拿出来吗？）"
    translate None chapter_three_0222:
        rs "哦，呃…当然…"

    #show raen n sur at center with move
    translate None chapter_three_0223:
        "我把手指从他嘴里抽出，他脸上浮现厌恶的表情。"
    translate None chapter_three_0224:
        "他吐了口唾沫，伸手去摸腰带。"
    translate None chapter_three_0225:
        leosu "….你们把我的武器怎么了？"
    translate None chapter_three_0226:
        rs "别担心，我们保管得很好-"

    show leos n smi with dis
    translate None chapter_three_0227:
        leosu "哦，我不是担心武器。你知道俗话怎么说来着，别让孩子靠近锋利物品之类的。"
    translate None chapter_three_0228:
        leosu "特别是如果被那边的小不点儿拿着。"

    show raen n sad
    show fawn n sad
    with dis
    translate None chapter_three_0229:
        rs "....."
    translate None chapter_three_0230:
        "看来他的臭脾气没受伤。"
    translate None chapter_three_0231:
        "他坐起身，但似乎动作很吃力。现在看起来不太危险。"

    show raen n neu with dis
    translate None chapter_three_0232:
        rs "听着，你需要我们帮助。你显然无法独自离开。所以收起你的态度，让我们帮你。"
    translate None chapter_three_0233:
        rs "不如我们自我介绍一下…我叫雷恩，那边浅色头发的是福恩。"
    translate None chapter_three_0234:
        leosu "我是奥雷利亚卡维拉的国王。"
    show raen n sad with dis
    translate None chapter_three_0235:
        rs "......"
    #translate None chapter_three_0236:
    show leos n neu with dis
    $ about_Leos.name = "莱奥斯"
    translate None chapter_three_0237:
        l "好的。莱奥斯。"
    translate None chapter_three_0238:
        l "你当初就该把我丢在原地。我想不出还有什么事比欠你这种人的人情更糟了。"
    translate None chapter_three_0239:
        rs "少在这不识好歹。我们随时可以把你丢回去。"
    translate None chapter_three_0240:
        "福恩从河边走回来，打了些水准备给莱奥斯清理伤口。"


    show fawn n sad at center
    show raen n sad at left
    with move
    translate None chapter_three_0241:
        f "可能会有点疼……"

    show leos n hur at shake
    translate None chapter_three_0242:
        l "嗷！"
    translate None chapter_three_0243:
        f "啊、呃，对不起…"

    show raen n smi with dis
    translate None chapter_three_0244:
        rs "用不着。这是他活该。"
    translate None chapter_three_0245:
        "我轻轻笑了起来：这就是嘴巴不干净的代价。"
    translate None chapter_three_0246:
        "趁福恩忙碌时，我们沉默了片刻。"
    translate None chapter_three_0247:
        "终于有机会问个明白了。"

    show raen n neu with dis
    translate None chapter_three_0248:
        rs "所以…到底怎么回事？是你烧了小鹿之家吗？你和另外两个人是一伙的？"

    show leos n neu with dis
    translate None chapter_three_0249:
        "他眯着眼睛打量我，大概在考虑值不值得回答这些问题。"
    translate None chapter_three_0250:
        "最后他只是叹了口气。"
    translate None chapter_three_0251:
        l "现在瞒着也没什么意义了。"
    translate None chapter_three_0252:
        l "就算回去他们也会除掉我。我知道他们会找各种借口。"
    translate None chapter_three_0253:
        l "有人雇我来追查你。佣金给得很高。"

    show raen n sur with dis
    translate None chapter_three_0254:
        rs "另外两人呢？纵火案呢？"
    translate None chapter_three_0255:
        l "没错，我是和他们一起的，但那两个本来就是蠢货。现在八成在地狱里烧着呢。"
    translate None chapter_three_0256:
        l "着火的事可以怪在他们头上。我才不会干这么招摇的事。"
    translate None chapter_three_0257:
        rs "有人雇你追踪我…？为什么？"
    translate None chapter_three_0258:
        l "....."

    show raen n neu with dis
    translate None chapter_three_0259:
        rs "现在倒是装起哑巴了？"

    show leos n smi with dis
    translate None chapter_three_0260:
        l "抱歉，我只是在惊叹你怎么能蠢成这样。"
    translate None chapter_three_0261:
        l "当然是为了杀你啊。"

    show raen n sad with dis
    translate None chapter_three_0262:
        l "不过我不知道还有个孩子。"
    translate None chapter_three_0263:
        "他瞟了眼福恩。"
    translate None chapter_three_0264:
        rs "什么…？怎么会有人—"
    translate None chapter_three_0265:
        l "不清楚。我只负责执行命令。"
    translate None chapter_three_0266:
        "我胃里一阵翻腾。谁会这么对我..？"
    translate None chapter_three_0267:
        rs "但是…在镇广场那次…"
    translate None chapter_three_0268:
        l "哇哦，看来你也不完全是榆木脑袋嘛？真让我吃惊。"
    translate None chapter_three_0269:
        l "接到的指令只是跟踪你，想办法引你去档案馆。"
    translate None chapter_three_0270:
        l "不像是我的常规工作。正常想杀你的人肯定会让我趁你睡着下手，但报酬就是报酬。拿钱办事不问缘由。"
    translate None chapter_three_0271:
        l "本以为要多费周折，没想到你轻易就上钩了。你该学着别轻信别人。"

    show raen n ang with dis
    translate None chapter_three_0272:
        rs "可我…我因为这事被赶出来了！都怪你！"

    show leos n neu with dis
    translate None chapter_three_0273:
        l "你被赶出来是因为自己容易上当。关我什么事。"
    translate None chapter_three_0274:
        l "也许你别别人说什么都信比较好，嗯？"
    translate None chapter_three_0275:
        l "总之，你可以怪那个雇佣我的人。这个锅我可不背。"

    show raen n sad with dis
    translate None chapter_three_0276:
        rs "那么…你对我的神之刻印知道些什么？你刚才说认出了它们…"
    translate None chapter_three_0277:
        l "一无所知。我只是复述别人教我说的台词。"
    translate None chapter_three_0278:
        l "你袖子都遮住了我还怎么看清？白痴。"

    show raen n emb with dis
    translate None chapter_three_0279:
        "我的脸腾地红了。确实觉得自己像个白痴…"
    translate None chapter_three_0280:
        "这么说来，真正知道我神之刻印的是雇佣他的那人…"
    translate None chapter_three_0281:
        "现在有两条线索。"

    $ about_Leos._text = ["在这片森林里最意想不到的重逢，就是又撞见了那个红发男人。来自奥雷利亚卡维拉的他做了自我介绍—方式却是烧毁福恩的树屋（虽然他坚称是同伴干的）并把匕首抵在我喉咙上。 \n \n他在随后的爆炸中受了伤，不得不靠我和福恩帮忙。他自称莱奥斯，受雇引导我去档案馆。当我死里逃生后，他又接到跟踪刺杀我的指令。 \n \n听起来很危险，但他的个性似乎和我预想的截然不同…"]
    translate None chapter_three_0282:
        "卡斯皮安王子，以及{a=set_entry:enc_people->about_Leos}{color=#87CEEB}莱奥斯{/color}{/a}的雇主。这两个人物都不容易找到。"
    translate None chapter_three_0283:
        "我又不能大摇大摆回家去盘问他们。"
    translate None chapter_three_0284:
        "那位王子呢？他真的还活着吗？我从没听人提起过他。"
    translate None chapter_three_0285:
        "福恩用担忧的眼神看着我，手上仍在为莱奥斯清理伤口。没等我继续追问，他突然插话："

    show raen n sad
    show fawn n sad
    with dis
    translate None chapter_three_0286:
        f "我已经…尽量处理好你的伤了，但是…"

    show fawn n neu with dis
    translate None chapter_three_0287:
        "他瞥了一眼莱奥斯的嘴角。"
    translate None chapter_three_0288:
        f "有些伤口可能超出我们处理能力。得找治疗师或医生帮忙。"
    translate None chapter_three_0289:
        rs "怎么找？我们俩出现在奥雷利亚卡维拉就是自投罗网。"
    translate None chapter_three_0290:
        f "要是往东穿过森林…最后能到斯塔格威奇…"
    translate None chapter_three_0291:
        f "更远处还有锡德卡汉，但实在太远了。"
    translate None chapter_three_0292:
        "又是这些地名。他到底在说什么？"
    translate None chapter_three_0293:
        rs "福恩…有件事我之前一直没忍心说…"
    translate None chapter_three_0294:
        rs "可能你在野外待太久，有点糊涂了。"
    translate None chapter_three_0295:
        rs "这附近只有奥雷利亚卡维拉。或者说，世界上只有这一个地方。"
    translate None chapter_three_0296:
        rs "外面的世界就是森林而已，这点你应该知道。"

    show fawn n sad with dis
    translate None chapter_three_0297:
        f "你总是说这种话…"
    translate None chapter_three_0298:
        f "他们真是这样告诉你的吗…？"
    translate None chapter_three_0299:
        "他眼中流露出悲伤的神色。"
    translate None chapter_three_0300:
        f "我不确定你在家乡被灌输了什么观念，但是…"
    translate None chapter_three_0301:
        f "外面可是有一整个世界。城市、村庄、国家、形形色色的人…"
    translate None chapter_three_0302:
        f "我连奥雷利亚卡维拉这个名字都没听说过…"

    show raen n sur with dis
    translate None chapter_three_0303:
        rs "什么意思？你从没去过那里？"
    translate None chapter_three_0304:
        f "我…我觉得没有。很奇怪，我记得有次沿着河流走，但…"

    show fawn n neu with dis
    translate None chapter_three_0305:
        f "当时起了浓雾，回过神来我又站在自家门口。我开始怀疑那里根本没有什么村庄。"
    translate None chapter_three_0306:
        rs "当然存在！"

    show leos n smi with dis
    translate None chapter_three_0307:
        l "你结交的都是些…呃…有趣的主。"
    translate None chapter_three_0308:
        l "一个疯狂、妄想、野性十足的森林男孩。像是老鼠和精灵的杂交品种。"

    show fawn n sad with dis
    translate None chapter_three_0309:
        f "我才不疯…"
    translate None chapter_three_0310:
        f "难以置信会有奉行那种教条的地方…"
    translate None chapter_three_0311:
        "…我的书里确实提到过锡德卡汉，但是…"
    translate None chapter_three_0312:
        "我说不清。总觉得哪里不对劲。"
    translate None chapter_three_0313:
        f "或许你们现在还不相信我，但是…"
    translate None chapter_three_0314:
        f "就像你说的，你回不了家，需要帮助。这次你只能相信我了。"
    translate None chapter_three_0315:
        f "我可以带你们到森林边缘，你们俩下去找人帮忙。"
    translate None chapter_three_0316:
        f "然后…我猜我得试着重建家园…"

    show raen n sad with dis
    translate None chapter_three_0317:
        "听他这么说…"
    translate None chapter_three_0318:
        "确实没太多选择。我们回不去，留在这儿也不是办法。"
    translate None chapter_three_0319:
        "要是继续配合他演戏，他早晚会意识到无论走多远都到不了任何地方。"
    translate None chapter_three_0320:
        "而且离这里越远对我们可能越有利。"
    translate None chapter_three_0321:
        rs "好吧…我相信你，福恩。我们跟你走。"

    show fawn n hap with dis
    translate None chapter_three_0322:
        "他对我露出灿烂笑容。看来答对了。"
    translate None chapter_three_0323:
        l "我连发言权都没有？"

    show raen n neu with dis
    translate None chapter_three_0324:
        rs "没有。"
    show fawn n neu with dis
    translate None chapter_three_0325:
        l "所以我们要跟着这个疯子深入森林腹地。真是绝妙的主意，绝对不可能以谋杀收场。"

    show raen n smi with dis
    translate None chapter_three_0326:
        rs "这话从你嘴里说出来真有意思。"
    show leos n hur with dis
    translate None chapter_three_0327:
        "不过说真的，近距离看莱奥斯有种脆弱感。痛苦的表情，浓密的睫毛，瘦削的脸庞…"

    show raen n sur
    show leos n sur
    with dis
    translate None chapter_three_0328:
        rs "嘿，凑近看你长得还挺标致！"
    translate None chapter_three_0329:
        "这句话让他哑口无言。"
    translate None chapter_three_0330:
        rs "其实我想问…"

    show raen n neu with dis
    translate None chapter_three_0331:
        rs "那你到底是什么身份？他们为何要雇佣你？"

    show leos n pen with dis
    translate None chapter_three_0332:
        l "杀手也好，雇佣兵也罢，只要钱给够了我什么都干。"
    translate None chapter_three_0333:
        "他移开视线。看来是不想继续这个话题。"
    translate None chapter_three_0334:
        "但我仍穷追不舍。"
    show raen n sur with dis
    translate None chapter_three_0335:
        rs "杀手？这种职业真的存在？为什么？"
    translate None chapter_three_0336:
        l "除掉碍事的人。还能为什么？"
    translate None chapter_three_0337:
        l "而此刻，你看上去就相当碍眼。"

    show raen n sad with dis
    translate None chapter_three_0338:
        rs "知道吗…这附近经常出现无名尸体。你是不是知道些什么？"
    translate None chapter_three_0339:
        l "问题可真多啊你？"
    translate None chapter_three_0340:
        "看来他的耐心到此为止了。不过居然回答了我这么多问题，真是意外。"

    show fawn n neu with dis
    translate None chapter_three_0341:
        f "伤口处理好了…"
    translate None chapter_three_0342:
        f "别再把泥巴弄进去了。"

    show leos n smi with dis
    translate None chapter_three_0343:
        l "哎呀我正打算往伤口里糊泥巴呢。多谢指点啊，大善人。这恩情我可怎么还得起？"
    translate None chapter_three_0344:
        "天哪…"
    show fawn n sad with dis
    translate None chapter_three_0345:
        "福恩尴尬地别过脸。虽然我不擅长应付他这类人，但福恩显然更糟糕。"
    translate None chapter_three_0346:
        "我狠狠瞪着他，但那副欠揍的坏笑依旧挂在他脸上。"
    translate None chapter_three_0347:
        l "他们不会只派我一个人来。要是我没回去，还会继续派人。"
    translate None chapter_three_0348:
        rs "那我们得在其他人来之前离开这儿。"
    translate None chapter_three_0349:
        rs "你还能走路吗…？需要我们再抬着你吗？"

    show leos n neu with dis
    translate None chapter_three_0350:
        l "我自己能行。"
    translate None chapter_three_0351:
        "他试图站起来，双腿却仍在发抖。"
    translate None chapter_three_0352:
        "最后在我们勉为其难的搀扶下，他终于站稳了。"

    show raen n neu with dis
    translate None chapter_three_0353:
        rs "走路时要是需要搭着我肩膀，尽管开口。我不介意。"
    translate None chapter_three_0354:
        l "我怕是要弯腰才能勾着你肩膀。"
    translate None chapter_three_0355:
        rs "随你便。待会可别哭着求我帮忙。"
    translate None chapter_three_0356:
        "真是个混球。相比之下福恩简直像天使。"
    translate None chapter_three_0357:
        f "到森林边缘还有…挺长一段路。趁天色没完全暗下来，我们得赶紧动身…"
    translate None chapter_three_0358:
        "福恩朝我认为是出口的方向比划着。"
    translate None chapter_three_0359:
        "眼下先跟着他走吧。就算他可能有点妄想症，总比留在这里强。"
    translate None chapter_three_0360:
        "尤其现在知道可能还有追兵。"
    translate None chapter_three_0361:
        rs "嗯，这样最稳妥。"
    translate None chapter_three_0362:
        f "那好吧…呃…"
    translate None chapter_three_0363:
        "福恩忧心忡忡地看着莱奥斯。"
    translate None chapter_three_0364:
        "从他站立的姿势就能明显看出他已十分吃力。我在想…他真的能承受长途跋涉吗？"
    translate None chapter_three_0365:
        "我想帮他，但他根本不领情。这家伙实在太顽固了。"
    translate None chapter_three_0366:
        "但凡我试图搀扶他，他就对我破口大骂。那就算了，让他自己受着吧。"
    translate None chapter_three_0367:
        "若他真需要帮助，我希望他能主动开口。"
    translate None chapter_three_0368:
        l "那就赶快带路吧，森林小精灵。"


    if achievement.has("leos_join"):
        pass
    else:
        $ renpy.display_notify("成就解锁：刺客加入队伍")

    python:
        achievement.grant("leos_join")
        achievement.sync()

    show fawn n sur with dis
    translate None chapter_three_0369:
        f "森林小精灵…？"
    translate None chapter_three_0370:
        l "更喜欢叫你老鼠？小不点？矮冬瓜？"

    show fawn n sad with dis
    translate None chapter_three_0371:
        f "....."
    translate None chapter_three_0372:
        l "很高兴这事就这么定了。"
    translate None chapter_three_0373:
        l "赶紧动身。还是说你想在这儿被抓？"
    show leos n smu with dis
    translate None chapter_three_0374:
        l "不过看你们俩自保的样子倒是挺滑稽的。也许我们真该留下来看好戏。"

    show raen n sad with dis
    translate None chapter_three_0375:
        "可怜的福恩。他真是片刻不得安宁。"
    translate None chapter_three_0376:
        "我歉疚地看了他一眼。"
    translate None chapter_three_0377:
        "为什么莱奥斯的态度这么恶劣？"
    translate None chapter_three_0378:
        "我不抱指望，但哪怕他能表现出一丁点友好也好啊。"
    translate None chapter_three_0379:
        "横竖我们做这些都是为了他。他至少该表示点感激吧。"
    translate None chapter_three_0380:
        f "我们现在补给也耗尽了.."
    translate None chapter_three_0381:
        rs "我没考虑到这个…食物问题怎么解决？"
    translate None chapter_three_0382:
        f "沿途还得寻找水源…"
    translate None chapter_three_0383:
        rs "啊…"
    translate None chapter_three_0384:
        f "相信总能遇见淡水，若能采集些浆果之类的应该就能撑过去。"
    translate None chapter_three_0385:
        rs "住所呢？"
    translate None chapter_three_0386:
        f "不太确定…"
    translate None chapter_three_0387:
        f "希望找个能遮风挡雨的地方.."
    translate None chapter_three_0388:
        l "少废话，快赶路。"

    show raen n neu with dis
    translate None chapter_three_0389:
        rs "是是是，殿下。"
    stop music fadeout 3.0
    window hide

    scene bg forestevening with w19:
        xpos 0.61 ypos 1.19 xanchor 0.5 yanchor 1.0 zoom 1.29
        linear 18.0 xpos 0.36 ypos 1.19 xanchor 0.5 yanchor 1.0 zoom 1.29
    play music "sounds/sfx/forest amb.ogg" fadeout 1
    window show dissolve
    translate None chapter_three_0390:
        "过去几个小时走得极其缓慢。我们走了走，又走了走，继续走了走…"
    translate None chapter_three_0391:
        "福恩走在稍前方探路引领。我和莱奥斯只能跟在后面。"
    translate None chapter_three_0392:
        "夕阳将四周染成橙红色。不知为何，这个时段总显得最凄凉。"
    translate None chapter_three_0393:
        "环顾四周，这里与一小时前、两小时前、三小时前…并无二致。"
    translate None chapter_three_0394:
        "但显然福恩心中有数。或者说他自以为有数。"
    translate None chapter_three_0395:
        "莱奥斯强忍痛楚不愿示弱。虽未掉队，却已力不从心。"
    translate None chapter_three_0396:
        "我若想搭把手，就会被他挡开并再遭辱骂。"
    translate None chapter_three_0397:
        "走了这么久连我都感到筋疲力尽，所以我几乎不敢想莱奥斯是什么感受。"

    scene bg forestevening
    show raen n sunset hur at center
    show expression AlphaMask("foliage_1", At("雷恩 黄昏 笑", center)) as mask1
    show fawn n sunset neu at left
    show expression AlphaMask("foliage_1", At("福恩 黄昏 困惑", left)) as mask2
    show leos n sunset hur at right
    show expression AlphaMask("foliage_1", At("莱奥斯 黄昏 笑", right)) as mask3
    with dissolve

    translate None chapter_three_0398:
        rs "……福恩？我觉得莱奥斯和我都有点…累了…或许我们该开始找过夜的地方了？"
    show fawn n sunset sur with dis
    translate None chapter_three_0399:
        "他突然停下脚步转身面对我们。"
    translate None chapter_three_0400:
        "我在这里气喘吁吁，而他甚至没出一点汗。"
    translate None chapter_three_0401:
        "他真是个与众不同的人。"
    translate None chapter_three_0402:
        f "你可能是对的..天很快就要黑了.."
    translate None chapter_three_0403:
        f "我去看看能不能找个休息的地方。在这稍等片刻。"

    play sound "sounds/sfx/rustle.ogg" fadeout 1
    hide fawn
    hide mask2
    with dissolve
    show leos n sunset hur at righttosr
    show expression AlphaMask("foliage_1", At("莱奥斯 黄昏 笑", righttosr)) as mask3
    show raen n sunset hur at centtosl
    show expression AlphaMask("foliage_1", At("雷恩 黄昏 笑", centtosl)) as mask1
    translate None chapter_three_0404:
        "还没等我眨眼他就已经爬到了半树高。他爬树的样子就像呼吸般自然。"

    show leos n sunset sur with dis
    translate None chapter_three_0405:
        l "他到底是什么，某种猴子吗？"

    show raen n sunset sad with dis
    translate None chapter_three_0406:
        rs "我还以为你会说老鼠。"

    show leos n sunset neu with dis
    translate None chapter_three_0407:
        l "....."
    translate None chapter_three_0408:
        l "你真信任他吗？"
    translate None chapter_three_0409:
        "我困惑地看向莱奥斯。这是我们第一次真正被单独留在一起。"
    translate None chapter_three_0410:
        "和曾经想杀你的人独处实在尴尬。"

    show raen n sunset sur with dis
    translate None chapter_three_0411:
        rs "为什么不呢？"
    translate None chapter_three_0412:
        l "他住在这里。在森林里。独自一人。"
    translate None chapter_three_0413:
        l "显然他的脑子也缺根弦。"

    show raen n sunset neu with dis

    translate None chapter_three_0414:
        rs "他没给过我不信任的理由。"
    translate None chapter_three_0415:
        rs "他可能有些疯狂想法，但能活到现在全靠他，而且他也不像你想的那么弱。"
    translate None chapter_three_0416:
        rs "所以是的，我确实信任他。"

    show raen n sunset smi with dis
    translate None chapter_three_0417:
        rs "总比某个到处烧房子的杀手值得信赖吧，嗯？"

    show leos n sunset smi with dis
    translate None chapter_three_0418:
        l "哎哟，你这话可真伤人。"

    show leos n sunset neu with dis
    translate None chapter_three_0419:
        l "但是，那真的不是—"

    show fawn n sunset hap at upsidecen
    show expression AlphaMask("foliage_1", At("福恩 黄昏 快乐", upsidecen)) as mask2
    with dis
    translate None chapter_three_0420:
        f "伙计们！我看到南边有个湖！"
    translate None chapter_three_0421:
        "福恩从树丛中探出头向我们挥手。"
    translate None chapter_three_0422:
        rs "好的，看来那就是我们过夜的地方了。能带路吗？"
    translate None chapter_three_0423:
        f "当然！"
    translate None chapter_three_0424:
        "他的表情明亮而温暖。不知为何，看到他这样笑让我感到开心。"
    translate None chapter_three_0425:
        "他像猫一样优雅地跳下树。"

    hide fawn
    hide mask2
    with dissolve
    show leos n sunset neu at srtoright
    show expression AlphaMask("foliage_1", At("莱奥斯 黄昏 困惑", srtoright)) as mask3
    show raen n sunset smi at sltocen
    show expression AlphaMask("foliage_1", At("雷恩 黄昏 微笑", sltocen)) as mask1
    pause(0.1)
    show fawn n sunset hap at left
    show expression AlphaMask("foliage_1", At("福恩 黄昏 快乐", left)) as mask2
    with dis
    translate None chapter_three_0426:
        f "跟我来！"

    show leos n sunset smu with dis
    translate None chapter_three_0427:
        l "好像我们有得选似的—"

    show leos n sunset hur with dis
    show leos n sunset hur at shakeright
    show expression AlphaMask("foliage_1", At("莱奥斯 黄昏 笑", shakeright)) as mask3
    translate None chapter_three_0428:
        l "哎哟…！"
    translate None chapter_three_0429:
        "我用肘轻轻顶了下他的肋骨。希望很痛。"
    translate None chapter_three_0430:
        "哦，可能有点奇怪，但我挺想知道莱奥斯的看法。"
    translate None chapter_three_0431:
        "也许他会知道些关于福恩昨晚说的事…？"

    show raen n sunset sur with dis
    translate None chapter_three_0432:
        rs "嘿，福恩，跟莱奥斯说说那个关于亲吻的事…还有婚姻和爱情。"

    show fawn n sunset sur with dis
    translate None chapter_three_0433:
        f "呃…"

    show fawn n sunset shy with dis
    translate None chapter_three_0434:
        f "真的吗…？现在就说这个？！"
    translate None chapter_three_0435:
        "他又激动起来。"
    translate None chapter_three_0436:
        rs "福恩告诉我，当你想和某人永远在一起时，就会相爱、结婚、接吻！你听说过这个吗？"

    show leos n sunset neu with dis
    translate None chapter_three_0437:
        l "你在胡说什么啊…？"
    translate None chapter_three_0438:
        rs "而且接吻后会生小孩！你们家乡都是这样的吗？"
    translate None chapter_three_0439:
        f "不对不对不对，接吻后不会生小孩！"
    translate None chapter_three_0440:
        rs "哦？那要怎么生小孩？"
    translate None chapter_three_0441:
        l "这不是明摆着吗。当然和说书人有关了。"
    translate None chapter_three_0442:
        f "等等…你是真的不知道…？"
    translate None chapter_three_0443:
        rs "不知道啊！在我们完成配对之前，他们什么都不会告诉我们。"
    translate None chapter_three_0444:
        f "呃…当两个人相爱的时候…他们…你知道的…会有肢体接触…？"

    show leos n sunset sur with dis
    translate None chapter_three_0445:
        l "他他妈在说什么鬼话？爱情？"
    translate None chapter_three_0446:
        rs "我也完全不懂！他说那是一种看到某人时产生的感觉。但我看着你时只感到……"

    show raen n sunset neu with dis
    translate None chapter_three_0447:
        rs "……冷漠？"

    show leos n sunset smu with dis
    translate None chapter_three_0448:
        l "真是受宠若惊。我看着你时只想把你绊倒。"
    translate None chapter_three_0449:
        rs "这可不太友善。"

    show fawn n sunset sad with dis
    translate None chapter_three_0450:
        f "你怎么会连爱情这种东西都不知道…？"
    translate None chapter_three_0451:
        f "我是说，就算你不了解它，也总该能感受到吧。不需要理解爱情也能体验它。"
    translate None chapter_three_0452:
        f "事实上，我觉得大多数人都不真正理解爱情。但连这个概念都不知道…"
    translate None chapter_three_0453:
        l "听起来像是住在树上的疯才会编造的东西。"

    window hide

    menu:

        "你确定这是真实存在的？":
            window show dissolve
            $ leos_relationship +=1
            jump is_it_real

        "听起来太美妙了！":
            window show dissolve
            $ fawn_relationship +=1
            jump sounds_amazing

label is_it_real:
    show raen n sunset sur with dis
    translate None chapter_three_0454:
        rs "你确定这是真实存在的…？"
    translate None chapter_three_0455:
        l "连那个白痴都同意我的看法。"
    translate None chapter_three_0456:
        f "当然确定！在来到这里之前…我身边的每个人都彼此相爱。我的家人彼此相爱，我的…父母…"
    translate None chapter_three_0457:
        f "啊…我父母也彼此相爱。在爱的包围中长大是很正常的…"
    translate None chapter_three_0458:
        f "...."

    jump choice_4_done

label sounds_amazing:
    show raen n sunset sur with dis
    translate None chapter_three_0459:
        rs "听起来太美妙了！"

    show leos n sunset neu with dis
    translate None chapter_three_0460:
        l "是吗？"

    show fawn n sunset sur with dis
    translate None chapter_three_0461:
        f "就是这样的！"
    translate None chapter_three_0462:
        f "……好吧，至少我觉得是这样。"
    translate None chapter_three_0463:
        f "在来到这里之前…我身边的每个人都彼此相爱。我的家人彼此相爱，我的…父母…"

    show fawn n sunset sad with dis
    translate None chapter_three_0464:
        f "啊…我父母也彼此相爱。在爱的包围中长大是很正常的…"
    translate None chapter_three_0465:
        f "....."

    jump choice_4_done

label choice_4_done:
    show raen n sunset neu with dis
    translate None chapter_three_0466:
        "他的父母…？"
    translate None chapter_three_0467:
        "他不是说过不认识他们吗？"
    translate None chapter_three_0468:
        "嗯…"
    translate None chapter_three_0469:
        "他把脸转开了。"
    translate None chapter_three_0470:
        "也许现在最好不要再谈这个话题了。"

    show raen n sunset sur with dis
    translate None chapter_three_0471:
        rs "啊，这就是那个湖吗？"
    stop music fadeout 3.0
    #window hide
    jump chapter_four_start
