label fawnroute1:
    #$ persistent.voice_acting_off = True # TODO REMOVE THIS FOR FULL VOICE ACTING
    #$ config.auto_voice = None # TODO REMOVE THIS FOR FULL VOICE ACTING
    $ fawn_route = True

    stop music fadeout 3.0
    scene bg sc sunset with fade
    window show dissolve
    translate None fawn_chapter1_0001:
        "外面的寒冷差点让我吃了一惊。我的意思是，寒冷竟然不存在。阿什给我做的衣服隔绝了霜寒，锁住了温暖。我缩进大衣里，享受这份舒适的安逸。"

    play music "sounds/bgm/night.ogg" fadeout 2.0

    show fawn nw sunset neu cloak at farleft
    show cyne nw sunset neu cloak at cenright
    show raen nw sunset sur cloak at cenleft
    show leos nw sunset neu cloak at farright
    with dissolve
    translate None fawn_chapter1_0002:
        rs "…阿什真的很有天赋，对吧？"
    translate None fawn_chapter1_0003:
        show cyne nw sunset hap cloak with dis
        c "我只会带你去最好的地方，不是吗？你真的怀疑我吗？"
    translate None fawn_chapter1_0004:
        rs "不，不，当然不。我只是惊讶这衣服带来的改变如此之大。"
    translate None fawn_chapter1_0005:
        "暮色已经布满天空，将周围的一切染成橘色。真的花了一整天时间。"
    translate None fawn_chapter1_0006:
        show raen nw sunset neu cloak with dis
        rs "那么…那个舞会是怎么回事？我们有什么办法能进去吗？"
    translate None fawn_chapter1_0007:
        l "…他们不会就这么让我们进去的。我们可以偷偷溜进去，不过也许你该问问那边的钱袋先生。"
    translate None fawn_chapter1_0008:
        show cyne nw sunset neu cloak with dis
        c "哦，你是说我？嗯…我本来有邀请函的…但被禁足后就被取消了。"
    translate None fawn_chapter1_0009:
        "我看向福恩。"
    translate None fawn_chapter1_0010:
        show fawn nw sunset sad cloak with dis
        f "呃…抱歉，我实在想不出什么好主意。我以前从没参加过这种场合。"
    translate None fawn_chapter1_0011:
        show fawn nw sunset neu cloak with dis
        f "不过偷偷溜进去说不定可行。"
    translate None fawn_chapter1_0012:
        show cyne nw sunset smi cloak with dis
        c "噢，噢，我有个主意！"
    translate None fawn_chapter1_0013:
        l "哦，这可太棒了。"
    translate None fawn_chapter1_0014:
        c "也许我能带你们两个以我男仆的身份进去？"
    translate None fawn_chapter1_0015:
        show leos nw sunset thi cloak with dis
        l "你一定是在开玩笑…为什么只能带两个？"
    translate None fawn_chapter1_0016:
        show cyne nw sunset sur cloak with dis
        c "别傻了，带三个男仆也太荒谬了！"
    translate None fawn_chapter1_0017:
        show cyne nw sunset neu cloak with dis
        c "我自己其实不能参加，因为会遇到我母亲。但我应该能带几个人进去，然后在她发现我溜走之前回家。"
    translate None fawn_chapter1_0018:
        f "....."
    translate None fawn_chapter1_0019:
        f "我去。雷恩也去。"
    translate None fawn_chapter1_0020:
        rs "哦，莱奥斯，这样可以吗？"
    translate None fawn_chapter1_0021:
        show leos nw sunset neu cloak with dis
        "他对我耸耸肩，看起来并不太在意。"
    translate None fawn_chapter1_0022:
        l "你想怎么样都行。反正你也搞不出什么大乱子。"
    translate None fawn_chapter1_0023:
        show raen nw sunset smi cloak with dis
        rs "这勉强算句夸奖，我收下了。"
    translate None fawn_chapter1_0024:
        rs "那现在怎么办？"
    translate None fawn_chapter1_0025:
        show raen nw sunset neu with dis
        c "我要回家再确认明天的细节。哦，趁我还没忘…"
    translate None fawn_chapter1_0026:
        "他把一个装着厚重硬币的缎面小袋子递给我。"
    translate None fawn_chapter1_0027:
        c "这些可能会派上用场。以防我不在的时候。"
    translate None fawn_chapter1_0028:
        show raen nw sunset sad cloak with dis
        rs "…我不能收这么多…你已经给我们买了这些衣服…"
    translate None fawn_chapter1_0029:
        show cyne nw sunset smi with dis
        c "哎，不过是零花钱罢了。不管怎样，我走啦！莱奥斯，做个绅士送我回家吧。"
    translate None fawn_chapter1_0030:
        show leos nw sunset ann with dis
        l "什么？不要。"
    translate None fawn_chapter1_0031:
        c "拜托嘛！来啊！"
    translate None fawn_chapter1_0032:
        l "不是。"
    translate None fawn_chapter1_0033:
        c "好吧好吧，不问你了。你没得选。"
    translate None fawn_chapter1_0034:
        show leos nw sunset sur blush cloak with dis
        l "喂等等—，注意你的手放哪儿！"
    translate None fawn_chapter1_0035:
        show cyne nw sunset hap with dis
        c "再见啦，小情侣！明天见！"
    translate None fawn_chapter1_0036:
        show raen nw sunset sur blush cloak
        show fawn nw sunset sur blush cloak
        with dis
        rs "..."
    translate None fawn_chapter1_0037:
        rs "…呃…再见！玩得开心，莱奥斯！"
    translate None fawn_chapter1_0038:
        hide leos
        hide cyne
        with dissolve
        show raen nw sunset sur blush at slightright
        show fawn nw sunset sur blush at slightleft
        with move
        "片刻之后，他们的身影就消失在了街角，融入人群之中。"
    translate None fawn_chapter1_0039:
        rs "嗯…现在只剩我们俩了，倒像是回到了从前。要不要随便逛逛？"
    translate None fawn_chapter1_0040:
        f "好啊。之前觉得好冷，但穿上这身衣服…好像也没那么糟。"
    translate None fawn_chapter1_0041:
        show raen nw sunset smi -blush cloak with dis
        rs "对吧？！没想到差别这么大。你以前定制过衣服吗？"
    translate None fawn_chapter1_0042:
        show fawn nw sunset sad cloak -blush with dis
        f "嗯…"
    translate None fawn_chapter1_0043:
        rs"哦..我是说，在你住进森林之前。"
    translate None fawn_chapter1_0044:
        f "我…我都是穿姐姐们的旧衣服。"
    translate None fawn_chapter1_0045:
        show raen nw sunset neu cloak with dis
        "姐姐们？"
    translate None fawn_chapter1_0046:
        "我正要追问，他却别过脸去，将一缕头发拨到耳后。"
    translate None fawn_chapter1_0047:
        "他现在似乎不想谈论这个话题。"
    translate None fawn_chapter1_0048:
        show fawn nw sunset neu cloak with dis
        "我们并肩走在暮色笼罩的街道上。正如伊尔兰所说，尽管锡德卡汉有着虚假的美丽，这里的贫民窟和其他地方也没什么两样。"
    translate None fawn_chapter1_0049:
        "看来哪里都有过得不顺心的人啊。"
    translate None fawn_chapter1_0050:
        "宽阔的街道与狭窄的小巷，通往未知处的阶梯，绵延至远方的山峦…可看的东西实在太多了。"
    translate None fawn_chapter1_0051:
        rs "很美，对吧？"
    translate None fawn_chapter1_0052:
        f "是很美，但…你不觉得这里缺了点什么吗？虽然人来人往，却有种…空荡荡的感觉。"
    translate None fawn_chapter1_0053:
        show raen nw sunset smi cloak with dis
        rs "嗯…也许你说得对，不过…和你在一起的时候，我根本注意不到这些。"
    translate None fawn_chapter1_0054:
        show fawn nw sunset neu blush cloak with dis
        f "..."
    translate None fawn_chapter1_0055:
        "我们在一个青铜巨像前驻足。那是个身披铠甲的男性雕像，正遥指远方。基座上的铭牌写着："
    translate None fawn_chapter1_0056:
        show raen nw sunset sur cloak with dis
        $ about_Elliot.locked = False
        rs "{a=set_entry:enc_people->about_Elliot}{color=#DA70D6}伟大的埃利奥特{/color}{/a}" #VOICE MAP?
    translate None fawn_chapter1_0057:
        show fawn nw sunset sur -blush cloak with dis
        "福恩仰望着雕像，显得格外专注。"
    translate None fawn_chapter1_0058:
        "许多和我们一样的旅人围聚在纪念碑旁，可能来自维迪斯各地，甚至更遥远的地方。"
    translate None fawn_chapter1_0059:
        show bg sc night
        show raen nw dark sur cloak
        show fawn nw dark sur cloak
        with dis4
        "橙红的晚霞早已化作繁星满天的夜幕。雕像周围尽是各式店铺和餐馆，但看起来都很…昂贵。"
    translate None fawn_chapter1_0060:
        "最好别一次花光赛恩给我们的钱，不过我真的饿坏了。"
    translate None fawn_chapter1_0061:
        "一家黑暗中的小摊吸引了我们的目光。"
    translate None fawn_chapter1_0062:
        show raen nw dark neu cloak with dis
        rs "…你饿了吗？"
    translate None fawn_chapter1_0063:
        show fawn nw dark neu cloak with dis
        f "说实话，饿死了。"
    translate None fawn_chapter1_0064:
        "我指向街角那个摊位，它在整条街上格外显眼。"
    translate None fawn_chapter1_0065:
        rs "要不要去试试那家？"
    translate None fawn_chapter1_0066:
        "我们走近时，摊主正忙着准备肉蔬烤串，朝我们咧嘴一笑。"
    translate None fawn_chapter1_0067:
        "我比了两根手指，烤串的诱人香气立刻扑面而来。"
    translate None fawn_chapter1_0068:
        "迅速付完钱，我们便踏上了返回旅馆的路。"
    translate None fawn_chapter1_0069:
        show raen nw dark hap cloak with dis
        rs "唔…太好吃了！"
    translate None fawn_chapter1_0070:
        show fawn nw dark smi cloak with dis
        f "我的也是。想尝一口吗？"
    translate None fawn_chapter1_0071:
        show fawn nw dark sur blush cloak with dis
        rs "啊—"
    translate None fawn_chapter1_0072:
        "我张大嘴巴，福恩明显愣住了。他举起烤串让我咬了一口。"
    translate None fawn_chapter1_0073:
        "肉质鲜嫩，滋味十足。"
    translate None fawn_chapter1_0074:
        show fawn nw dark smi -blush cloak with dis
        show raen nw dark smi cloak with dis
        "他继续小口吃着，目光却飘向地面。啊…难道他…"
    translate None fawn_chapter1_0075:
        rs "也想尝尝我的？"
    translate None fawn_chapter1_0076:
        f "噢！如果…如果你不介意的话…"
    translate None fawn_chapter1_0077:
        show fawn nw dark smi blush cloak with dis
        "我刚要把整串递过去，他却赧红着脸张开了嘴。"
    translate None fawn_chapter1_0078:
        rs "哈哈，来—啊！"
    translate None fawn_chapter1_0079:
        f "嗯…两串都很好吃呢。"

    window hide dissolve

    scene bg sw night with dissolve:
        xpos 0.67 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.38
        linear 20.0 xpos 0.32 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.38
    window show dissolve
    translate None fawn_chapter1_0080:
        "不知不觉已走到银柳旅馆门口。穿过正厅直抵客房区。"
    translate None fawn_chapter1_0081:
        "仍不见莱奥斯的踪影，不过我并不担心。那家伙总能照顾好自己…大概吧。"
    translate None fawn_chapter1_0082:
        "正要开门时，福恩突然出声。"
    translate None fawn_chapter1_0083:
        f c wneu "那个…雷恩…有件事想问你…"
    translate None fawn_chapter1_0084:
        rs c wsur "嗯？你说。"
    translate None fawn_chapter1_0085:
        f "..."
    translate None fawn_chapter1_0086:
        f "我…"
    translate None fawn_chapter1_0087:
        f c wemb "…会跳舞吗？"
    translate None fawn_chapter1_0088:
        rs "跳舞？从没试过。怎么了？"
    translate None fawn_chapter1_0089:
        f "我对舞会有点紧张…怕融不入气氛…"
    translate None fawn_chapter1_0090:
        f "可能需要跳舞…所以想着…如果你愿意…我们可以先练习？"
    translate None fawn_chapter1_0091:
        rs c wsmi"哈哈，听起来很有趣。先从哪开始？"
    translate None fawn_chapter1_0092:
        "我推开门，两人走进房间。"

    window hide dissolve

label test:
    scene bg swroom night with dissolve
    window show dissolve
    translate None fawn_chapter1_0093:
        "他与我面对面站着，轻轻把手环在我颈后。"
    translate None fawn_chapter1_0094:
        show raen nw dim smi at slightright
        show fawn nw dim neu blush at slightleft
        with dissolve
        f "你可以…把手放在我背上…"
    translate None fawn_chapter1_0095:
        "按他的指引搂住腰身，静静等待下一步指示。"
    translate None fawn_chapter1_0096:
        f "....."
    translate None fawn_chapter1_0097:
        rs "....."
    translate None fawn_chapter1_0098:
        f "....."
    translate None fawn_chapter1_0099:
        show raen nw dim sur with dis
        rs "呃…然后呢？"
    translate None fawn_chapter1_0100:
        show fawn nw dim sad with dis
        f "不知道…我以为你有主意…"
    translate None fawn_chapter1_0101:
        rs "跳舞得配乐吧。要不你哼个曲子？"
    translate None fawn_chapter1_0102:
        show fawn nw dim sur with dis
        f "还是别听我唱歌为好。"
    translate None fawn_chapter1_0103:
        rs "我愿意。已经太久没听到你唱歌了。"
    translate None fawn_chapter1_0104:
        show fawn nw dim smi with dis
        "他笑着哼起在斯塔格威奇唱过的那首歌的调子，感觉那已经是很久以前的事了。"
    translate None fawn_chapter1_0105:
        show raen nw smi with dis
        rs "好吧，好吧，这样就行。"
    translate None fawn_chapter1_0106:
        "我们笨拙地跟着调子跳舞。跳得乱七八糟，不时还会绊倒对方，但很有趣。"
    translate None fawn_chapter1_0107:
        show fawn nw dim hap blush with dis
        show raen nw dim hap blush with dis
        "福恩的哼唱被咯咯的笑声打断，最后变成了开怀大笑。"
    translate None fawn_chapter1_0108:
        "我们瘫倒在地，笑得更加厉害。"
    translate None fawn_chapter1_0109:
        rs "要我说我们现在都算得上是专业舞者了。也许我该放弃寻找卡斯皮安，改行当个著名的舞蹈家。"
    translate None fawn_chapter1_0110:
        f "不过我猜舞会上的人可不会欣赏我们的舞姿，哈哈…"
    translate None fawn_chapter1_0111:
        show raen nw dim smi blush with dis
        show fawn nw dim emb blush with dis
        rs "他们要是看我跳舞可能会当场笑死，但…至少能看你跳舞是他们的福气。你知道…"
    translate None fawn_chapter1_0112:
        "并排躺着时，我翻身看向福恩的脸。"
    translate None fawn_chapter1_0113:
        rs "你笑起来真让人心动。你的笑容让我也想跟着笑。"
    translate None fawn_chapter1_0114:
        f "..."
    translate None fawn_chapter1_0115:
        f "你…你也是…"
    translate None fawn_chapter1_0116:
        "我抚摸他的头顶，理顺我们在跳舞时弄乱的蓝色发丝。"
    translate None fawn_chapter1_0117:
        show raen nw dim neu -blush with dis
        rs "哦，我有件事想和你说。"
    translate None fawn_chapter1_0118:
        show fawn nw dim neu -blush with dis
        f "那是什么？"
    translate None fawn_chapter1_0119:
        rs "你知道…我一直做的那些梦？"
    translate None fawn_chapter1_0120:
        "他表情严肃地点点头。"
    translate None fawn_chapter1_0121:
        rs "…我告诉维拉斯了，但他也不确定原因…他说可能是有人在试图保护我。"
    translate None fawn_chapter1_0122:
        f "试图保护你？"
    translate None fawn_chapter1_0123:
        show raen nw dim sad with dis
        rs "是啊…然后昨晚，她又和我说话了。但这次不一样。她好像也能听见我说话。"
    translate None fawn_chapter1_0124:
        rs "还有…抱歉我之前没提起，她说一直有人在跟踪我。说那个人马上就要找到这里了。"
    translate None fawn_chapter1_0125:
        show fawn nw dim sad with dis
        "福恩听到我的话皱起眉头，但保持着至寂。"
    translate None fawn_chapter1_0126:
        rs "然后她就消失了。她说她不能久留…我好害怕，福恩。我不仅怕我们遭遇不测，也担心她可能出了什么事。"
    translate None fawn_chapter1_0127:
        rs "对不起，我知道担心脑海里的声音听起来很荒唐…"
    translate None fawn_chapter1_0128:
        f "你觉得她永远消失了吗？"
    translate None fawn_chapter1_0129:
        rs "我不知道…真的不知道。正是这种不确定让我更加害怕。我害怕今晚入睡后发现她真的不在了。"
    translate None fawn_chapter1_0130:
        show fawn nw dim smi with dis
        f "…你心地很善良，雷恩。比我善良多了。如果你愿意，我今晚可以留在这里。嗯…如果你害怕的话，或许能帮上忙…"
    translate None fawn_chapter1_0131:
        show raen nw dim sur with dis
        rs "真的可以吗？"
    translate None fawn_chapter1_0132:
        f "当然啦。你知道我愿意为你做任何事的。"
    translate None fawn_chapter1_0133:
        "我紧紧握住他的手，然后站起身伸了个懒腰。"
    translate None fawn_chapter1_0134:
        show raen nw dim neu with dis
        rs "不知道莱奥斯和赛恩那边怎么样了…"
    translate None fawn_chapter1_0135:
        show fawn nw dim neu with dis
        f "你在担心他们吗？"
    translate None fawn_chapter1_0136:
        show raen nw dim smi with dis
        rs "哈哈哈，我更担心莱奥斯的精神状态。反正我知道他们没事。莱奥斯虽然表现得好像讨厌赛恩，但他不会让赛恩受伤的。"
    translate None fawn_chapter1_0137:
        show fawn nw dim sad with dis
        f "..."
    translate None fawn_chapter1_0138:
        show raen nw dim sur with dis
        rs "福恩？"
    translate None fawn_chapter1_0139:
        f "…你觉得我是个坏人吗？因为我试图对赛恩做的那些事…"
    translate None fawn_chapter1_0140:
        rs "怎么会呢？那不是你的错。我们都知道的。"
    translate None fawn_chapter1_0141:
        f "但…如果那就是我的错呢？如果…那才是我的本性呢？"
    translate None fawn_chapter1_0142:
        "我摇摇头，把他从地上拉起来。"
    translate None fawn_chapter1_0143:
        show raen nw dim neu with dis
        rs "我了解你，福恩，我知道你是什么样的人。我们去睡觉好吗？"
    translate None fawn_chapter1_0144:
        "他点点头，我们一起爬上了床。月光依然从窗户倾泻而入，但反而让人平静。"
    translate None fawn_chapter1_0145:
        "不知不觉中，我就睡着了。"

    stop music fadeout 3.0
    window hide dissolve

    scene black with eye_shut
    pause 2.0
    window show dissolve
    translate None fawn_chapter1_0146: # voice map
        rs "…有人吗？"
    translate None fawn_chapter1_0147: # voice map
        rs "你在吗？"
    translate None fawn_chapter1_0148:
        "…………….."
    translate None fawn_chapter1_0149:
        "寂静在我脑海中回荡。"

    window hide dissolve

    pause 2.0
    scene bg swroom day with dissolve

    window show dissolve
    translate None fawn_chapter1_0150:
        "我被一股温暖包围着，那只能是另一个人的体温。"
    translate None fawn_chapter1_0151:
        play music "sounds/bgm/romantic.ogg" fadein 2.0
        "我眨眨眼低头看去，感受到身上有重量。福恩的手臂和腿都搭在我身上，头枕着我的胸口。"
    translate None fawn_chapter1_0152:
        rs wneublu"........"
    translate None fawn_chapter1_0153:
        "当我挪动时，他反而贴得更近，在我怀里蹭了蹭。"
    translate None fawn_chapter1_0154:
        "….感觉还不赖。"
    translate None fawn_chapter1_0155:
        "现在还不该吵醒他。"
    translate None fawn_chapter1_0156:
        "他的面容柔和，肌肤如瓷。当然这不是我第一次看见，但此刻感觉有些不同。更亲密，更…美好。"
    translate None fawn_chapter1_0157:
        "就像个人偶，既脆弱又坚强。拥他在怀，让我觉得永远这样也不赖。"
    translate None fawn_chapter1_0158:
        "他的睫毛轻颤着睁开，突然与我四目相对。"
    translate None fawn_chapter1_0159:
        rs wsmi"早安，福恩。"
    translate None fawn_chapter1_0160:
        f wemb "…什…什么…你在干什么！？"
    translate None fawn_chapter1_0161:
        rs "我什么都没做。我醒来时你就这样了。别怪我。"
    translate None fawn_chapter1_0162:
        "他想要抽身，但我抱得更紧。"
    translate None fawn_chapter1_0163:
        rs wneublu "别急着走…这样不舒服吗？"
    translate None fawn_chapter1_0164:
        f "我…你…这不是—"
    translate None fawn_chapter1_0165:
        rs wsad  "…我猜得没错。她走了。我们穿过苋红森林时她也沉默不语，但这次…感觉是真的离开了。"
    translate None fawn_chapter1_0166:
        rs "我希望…希望她没事…"
    translate None fawn_chapter1_0167:
        f wsad "..."
    translate None fawn_chapter1_0168:
        f "对不起，雷恩。"
    translate None fawn_chapter1_0169:
        rs "没关系。不过我醒来时你在身边，我很开心。"
    translate None fawn_chapter1_0170:
        "我们又静静待了一会儿，谁都没有出声。这种沉默很舒适。不需要言语就能享受彼此的陪伴。"
    translate None fawn_chapter1_0171:
        "窗外的鸟儿啁啾私语，沐浴着晨光。"
    translate None fawn_chapter1_0172:
        stop music fadeout 2.0
        "最后我们起床穿衣，前往大厅寻找莱奥斯。"

    window hide dissolve


    scene bg sw day with dissolve
    window show dissolve

    play music "sounds/bgm/sidcaeham.ogg" fadein 2.0
    translate None fawn_chapter1_0173:
        rs c wneu "….莱奥斯，你在这儿！"
    translate None fawn_chapter1_0174:
        l c wsmi "你们总算出现了。顺便说声，谢谢你昨天的\"帮忙\"。"
    translate None fawn_chapter1_0175:
        rs "帮忙？我帮什么了？"
    translate None fawn_chapter1_0176:
        l c wann "你让那个急色鬼把我拽走了！"
    translate None fawn_chapter1_0177:
        rs c wsur "哦~！玩得开心吗？"
    translate None fawn_chapter1_0178:
        l c wthi "你说呢？"
    translate None fawn_chapter1_0179:
        rs c wsmi "我看你明明乐在其中！说真的，你要是不愿意，他根本拖不走你。"
    translate None fawn_chapter1_0180:
        l "我…我—"
    translate None fawn_chapter1_0181:
        c c whap "早—上好！想我了吗？"
    translate None fawn_chapter1_0182:
        c c wsur"哟，莱奥斯！昨晚怎么溜了？我本来可以留你过夜的，知道不。我的床可—大了，绝对够咱们俩睡。"
    translate None fawn_chapter1_0183:
        "莱奥斯挪到我另一侧，远离赛恩。"
    translate None fawn_chapter1_0184:
        "有意思的发展。"
    translate None fawn_chapter1_0185:
        f c wneu "早…早上好，赛恩。"
    translate None fawn_chapter1_0186:
        c c wsmi "早啊小太阳。昨天玩得开心吗？"
    translate None fawn_chapter1_0187:
        rs "我们自己在锡德卡汉转了转。这地方确实不同凡响。"
    translate None fawn_chapter1_0188:
        rs "哦对了，有个问题…我们看到一座大雕像，想知道是谁。"
    translate None fawn_chapter1_0189:
        c "埃利奥特？"
    translate None fawn_chapter1_0190:
        rs "就是他！"
        $ about_Elliot._text.append("埃利奥特是奥雷利亚战争中率领锡德卡汉军队的将军。")
    translate None fawn_chapter1_0191:
        c "嗯…人们称他为{a=set_entry:enc_people->about_Elliot}{color=#87CEEB}弑神者埃利奥特{/color}{/a}。他是奥雷利亚战争期间锡德卡汉军队的统帅。"
    translate None fawn_chapter1_0192:
        rs c wsur"他怎么得到这种称号的？"
    translate None fawn_chapter1_0193:
        c c wneu "呃…这名字说明一切。传说他斩杀了威胁锡德卡汉的邪神。当然了，我原以为有些夸张，但或许确有其事。"
    translate None fawn_chapter1_0194:
        "我的脑海中闪回与诺克斯战斗的场景，我如何无助地与他搏斗…埃利奥特如果能杀死那样的家伙，那一定很强…"
    translate None fawn_chapter1_0195:
        c c whap "无论如何，总之，我有好消息！一切我都安排妥当了，带你们两个进舞会完全—没—问题！来吧，夸夸我！"
    translate None fawn_chapter1_0196:
        rs c wsmi "干得好，赛恩！"
    translate None fawn_chapter1_0197:
        "福恩和我都鼓起了掌，但莱奥斯只是抱臂站在那。"
    translate None fawn_chapter1_0198:
        l c wneu "嗯嗯，恭喜还是怎么的。在那之前我们有什么计划？"
    translate None fawn_chapter1_0199:
        rs c wneu "唔…既然昨天没什么机会做这事，我们可以四处打听卡斯皮安的消息？说不定都不用去舞会就能撞见他。"
    translate None fawn_chapter1_0200:
        c "哦，如果是这样的话，我们应该分头行动！"
    translate None fawn_chapter1_0201:
        l "为什么你总想分开行动？"
    translate None fawn_chapter1_0202:
        c "一对一相处多有意思！好吧，我选莱奥斯！"
    translate None fawn_chapter1_0203:
        l c whur "等等，什么？为什么是我？我拒绝。"
    translate None fawn_chapter1_0204:
        "赛恩冲福恩使了个眼色，然后挽住了莱奥斯的手臂。"
    translate None fawn_chapter1_0205:
        c "为什么不行？我可以为雷恩争风吃醋，或者…我可以利用眼前这位高大英俊的男人。"
    translate None fawn_chapter1_0206:
        c "再说了，我不介意挽着你的手臂逛一天。"
    translate None fawn_chapter1_0207:
        l c wann "找别人的手臂去。"
    translate None fawn_chapter1_0208:
        c "不，我心意已决！就要你！"
    translate None fawn_chapter1_0209:
        c "你们俩—日落前在上城区和我碰头。特别好找！"
    translate None fawn_chapter1_0210:
        rs "上…上城区？"
    translate None fawn_chapter1_0211:
        c "拜拜！快来啦莱奥斯。走路时至少搂着我肩膀什么的。"
    translate None fawn_chapter1_0212:
        "莱奥斯被赛恩再次拽走时，用求助的眼神看着我。"
    translate None fawn_chapter1_0213:
        f "……我有点同情他。"
    translate None fawn_chapter1_0214:
        rs "……我也是。"
    translate None fawn_chapter1_0215:
        rs "不过我们也无能为力。我打赌他暗地里乐在其中。现在，我们该去哪儿？"
    translate None fawn_chapter1_0216:
        stop music fadeout 2.0
        "我们走向户外，步入锡德卡汉这片冬季仙境。"


    window hide dissolve
    scene bg sc day with dissolve:
        xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.18
        linear 5.0 xpos 0.5 ypos 1.12 xanchor 0.5 yanchor 1.0 zoom 1.18

    window show dissolve
    translate None fawn_chapter1_0217:
        "漫步时我望着山巅流云。雾气缭绕峰顶，给整座城市蒙上梦幻色彩。"
    translate None fawn_chapter1_0218:
        play music "sounds/bgm/Discovery.ogg" fadein 2.0
        "住在群山之间…真是不可思议。"
    translate None fawn_chapter1_0219:
        "福恩站在我身旁，昂首挺胸。他看起来没之前那么局促了。"
    translate None fawn_chapter1_0220:
        "看他这么自信让我很高兴。那个在斯塔格威奇躲在我身后的福恩早已不复存在。"
    translate None fawn_chapter1_0221:
        "起初，我们沿主街道徘徊，一路与人交谈。我们向所有人提出同样的问题，但他们全都摇头，表示不认识我所描述的人。"
    translate None fawn_chapter1_0222:
        show fawn nw cloak neu at slightleft
        show raen nw sad cloak at slightright
        with dissolve
        rs "……还是不行吗？难道他根本不存在？"
    translate None fawn_chapter1_0223:
        rs "我感觉自己在追逐一个幽灵。分明近在咫尺，却怎么也抓不住任何线索……"
    translate None fawn_chapter1_0224:
        show fawn nw sad with dis
        f "……看看这世界有多大，雷恩。比你我所能想象的还要广阔。"
    translate None fawn_chapter1_0225:
        f "充满形形色色的人。总会有人知道他的消息。"
    translate None fawn_chapter1_0226:
        rs "……要是当初我能从诺克斯那儿多问些关于卡斯皮安的事……"
    translate None fawn_chapter1_0227:
        "他把手搭在我肩上，轻轻捏了捏。"
    translate None fawn_chapter1_0228:
        show fawn nw smi with dis
        f "你已经做得很好了。我们会找到他的，我保证。"
    translate None fawn_chapter1_0229:
        "我抬手覆在他的手背上。他对我露出温柔而甜蜜的微笑。"
    translate None fawn_chapter1_0230:
        show raen nw neu with dis
        rs "福恩，我—"
    translate None fawn_chapter1_0231:
        show raen nw sur with dis
        rs "哇啊！"
    translate None fawn_chapter1_0232:
        play sound "sounds/sfx/fallonground.ogg" fadein 0.5
        scene bg sc day with hpunch
        "我在积雪的路面上滑倒，四仰八叉地躺倒在地。福恩冲到我身边跪下。"
    translate None fawn_chapter1_0233:
        f c wsad "你没事吧？！"
    translate None fawn_chapter1_0234:
        rs c wsur "呃……受伤最重的可能是我的自尊心……"
    translate None fawn_chapter1_0235:
        f c wsmi "噗！{b}现在{/b}才觉得丢脸？雷恩，我本不想说的，但你笨拙得令人发指。"
    translate None fawn_chapter1_0236:
        f "不是摔跤就是撞到别人。"
    translate None fawn_chapter1_0237:
        rs c wemb "……才没有这回事。我可是相当能干的人！"
    translate None fawn_chapter1_0238:
        f "相当擅长把事情搞砸。我就喜欢你这一点。"
    translate None fawn_chapter1_0239:
        rs c wsmi "噢，你喜欢我？"
    translate None fawn_chapter1_0240:
        f c wemb "...."
    translate None fawn_chapter1_0241:
        f "那……那不是我说的原话！"
    translate None fawn_chapter1_0242:
        rs c wsad "欸—你不喜欢吗？"
    translate None fawn_chapter1_0243:
        "他用一捧糊在我脸上的雪作为回答。"
    translate None fawn_chapter1_0244:
        rs c wsur "啊啊好冰！好吧好吧我认错！"
    translate None fawn_chapter1_0245:
        f c wsmi "哈哈哈活该！对了……我一直在想，你以前真的见过雪吗？"
    translate None fawn_chapter1_0246:
        rs c wneu "从来没有。"
    translate None fawn_chapter1_0247:
        f "看好了。"
    translate None fawn_chapter1_0248:
        "我半坐起来跪在他身旁。他滚了三个雪球，把它们叠在一起。"
    translate None fawn_chapter1_0249:
        f c whap "这是雪人雷恩！"
    translate None fawn_chapter1_0250:
        rs c wsmi "噢，真可爱。那我们也需要做个雪人福恩！"
    translate None fawn_chapter1_0251:
        "我如法炮制滚了三个雪球，在旁边堆出福恩雪人。"
    translate None fawn_chapter1_0252:
        rs "大功告成！毕竟没有你我会很寂寞。"
    translate None fawn_chapter1_0253:
        f c wneu "..."
    translate None fawn_chapter1_0254:
        f c wneu "……你有想过之后要做什么吗？"
    translate None fawn_chapter1_0255:
        rs c wneu"找到卡斯皮安之后？我现在也不太确定了。"
    translate None fawn_chapter1_0256:
        rs "不久前我可能还会说要回家。现在…这还是个选择吗？那里已经不欢迎我了。"
    translate None fawn_chapter1_0257:
        rs "所以…不，我毫无头绪。如果我留在这里，我能做什么？如果我回家，是不是得假装什么都没发生过？"
    translate None fawn_chapter1_0258:
        rs c wsad "这…实在难以想象。"
    translate None fawn_chapter1_0259:
        f c wsad "…无论如何，我希望这一切结束后还能见到你。如果真有结束的那天…"
    translate None fawn_chapter1_0260:
        f "或许我可以偶尔来拜访…之类的？"
    translate None fawn_chapter1_0261:
        rs "呃…我希望你不只是偶尔来访。"
    translate None fawn_chapter1_0262:
        f c wsad "….啊，抱歉，我不是有意—"
    translate None fawn_chapter1_0263:
        rs c wsmi "我要你和我在一起！不管最终会在哪里。"
    translate None fawn_chapter1_0264:
        "我们从雪地里站起身，我拍了拍身上的雪。周围的人都看着这两个堆了半天雪人的男人。"
    translate None fawn_chapter1_0265:
        "我向他们耸耸肩。偶尔找点乐子也无妨吧？没必要总是紧绷着。"
    translate None fawn_chapter1_0266:
        "正当我们要离开时，福恩突然停下脚步。前方拐角处有个蓝色长发的身影，发色和他很相似。"
    translate None fawn_chapter1_0267:
        "她很美。那种能让人频频回首的美人，却穿得相当朴素。"
    translate None fawn_chapter1_0268:
        rs c wsur "…你认识的人？"
    translate None fawn_chapter1_0269:
        f c wsad "…不，不可能。抱歉，我只是产生了错觉。"
    translate None fawn_chapter1_0270:
        "他对我笑了笑，我们继续寻找线索。"
    translate None fawn_chapter1_0271:
        scene bg sc sunset with dis3
        "直到日落时分，每个人的回答都没变。他们从没听说过18年前有个叫卡斯皮安的男人来过这里。"
    translate None fawn_chapter1_0272:
        rs c wsad "太阳已经西沉…"
    translate None fawn_chapter1_0273:
        f c wsmi "….我们还有舞会的邀请，而且才来这儿几天。时间很充裕。"
    translate None fawn_chapter1_0274:
        rs "…嗯，你说得对。我想我们该出发了…你觉得我们穿得体面吗…？"
    translate None fawn_chapter1_0275:
        f c wsad "我…说实话不太确定。要不要戴个面具什么的？"
    translate None fawn_chapter1_0276:
        rs "…现在想想，我们连舞会在哪举行都不知道。赛恩只说在上层区见他。"
    translate None fawn_chapter1_0277:
        "于是我们拾级而上，沿着锡德卡汉那通往山巅的无尽阶梯攀登。"
    translate None fawn_chapter1_0278:
        "最后我们来到了一片只能用上流社会住宅区来形容的街区。"
    translate None fawn_chapter1_0279:
        "放眼望去，每个人身上都穿着华丽飘逸的长袍。他们看起来…简直就像王室成员。"
    translate None fawn_chapter1_0280:
        "人群沿着宽阔的街道向前流动，走向一座白色精致的建筑。说它是宫殿也不为过。"
    translate None fawn_chapter1_0281:
        "我们跟随人流，试图融入其中。"
    translate None fawn_chapter1_0282:
        "走近时，赛恩的金发出现在视线中。我想挥手致意，但还是忍住了。"
    translate None fawn_chapter1_0283:
        c c wneu "…..你们好，两位。跟我来。"
    translate None fawn_chapter1_0284:
        "他带着优雅的气质转身，引领我们走向大门，将一封烫金信封递给守卫。"
    translate None fawn_chapter1_0285:
        c "这两位是我的同伴。"
    translate None fawn_chapter1_0286:
        "守卫将我俩打量片刻，审视每个动作。我屏住呼吸站在原地，等待驱逐令。"
    translate None fawn_chapter1_0287:
        stop music fadeout 2.0
        "最终他点头放行，三人步入建筑内部。"



    window hide dissolve
    scene bg ball with fade:
        xpos 0.9 ypos 1.74 xanchor 0.5 yanchor 1.0 zoom 1.83
        linear 45.0 xpos 0.11 ypos 1.74 xanchor 0.5 yanchor 1.0 zoom 1.83
    window show dissolve
    translate None fawn_chapter1_0288:
        "走进大厅，我差点惊呼出声。眼前的奢华景象前所未见。"
    translate None fawn_chapter1_0289:
        play music "sounds/bgm/sidcaeham.ogg"
    translate None fawn_chapter1_0290:
        "首先映入眼帘的是高耸天花板上繁复的金色螺旋纹饰，接着是悬挂的巨大枝形吊灯。"
    translate None fawn_chapter1_0291:
        "木质地板光可鉴人，甚至能照出我的倒影。"
    translate None fawn_chapter1_0292:
        "厅内早已挤满盛装出席的宾客。各色晚礼服与西装。即使我穿得够体面，仍感到相形见绌。"
    translate None fawn_chapter1_0293:
        "赛恩将我们拉到角落低语："
    translate None fawn_chapter1_0294:
        c c wneu "我只能送到这儿了，不想遇见家母…"
    translate None fawn_chapter1_0295:
        c "听着：这些人根本不在意你的言辞，但若抓到把柄就会穷追不舍。他们冷酷无情。"
    translate None fawn_chapter1_0296:
        c c whap "别太惹人注目。哦，记得享受舞会！回见！"
    translate None fawn_chapter1_0297:
        "留下我与福恩面面相觑。"
    translate None fawn_chapter1_0298:
        rs c wemb "呃…我现在不太有信心…"
    translate None fawn_chapter1_0299:
        f c wemb "我也一样…"
    translate None fawn_chapter1_0300:
        "穿过人群时，宾客们亲密交谈，对我们视若无睹。"
    translate None fawn_chapter1_0301:
        "总得找个突破口…"
    translate None fawn_chapter1_0302:
        rs c wneu "那个…打扰了，女士…"
    translate None fawn_chapter1_0303:
        "毫无反应。她连头都没转。"
    translate None fawn_chapter1_0304:
        rs "我在找…"
    translate None fawn_chapter1_0305:
        "她径自离去，兴致索然。"
    translate None fawn_chapter1_0306:
        f c wneu"....."
    translate None fawn_chapter1_0307:
        f "换我来试试。"
    translate None fawn_chapter1_0308:
        "他走向独处的青年。对方衣着考究，戴着气派的礼帽。"
    translate None fawn_chapter1_0309:
        f "先生有空吗？能否请教个问题？"
    translate None fawn_chapter1_0310:
        "那人上下打量福恩，宣称事务缠身便抽身离去。"
    translate None fawn_chapter1_0311:
        rs c wsad "他们…不太容易接近。"
    translate None fawn_chapter1_0312:
        f c wsad "这让我不禁好奇赛恩是怎么变得如此…友善的，毕竟他一生都被这样的人包围着。"
    translate None fawn_chapter1_0313:
        rs "他能成长成这样而不是那样，真的很了不起…"
    translate None fawn_chapter1_0314:
        f "…现在我大概能明白为什么他更喜欢我们了。"
    translate None fawn_chapter1_0315:
        rs "这些家伙没什么意思，对吧？他看起来完全不适合这里。"
    translate None fawn_chapter1_0316:
        "我们试着和房间里几乎所有人搭话。终于有几个人回应了我们，但他们不认识我们在说谁。"
    translate None fawn_chapter1_0317:
        "其他人忙于自己的谈话，根本不理我们。在他们面前我们真的什么都不是。"
    translate None fawn_chapter1_0318:
        "我叹了口气，坐到了一张空桌子旁。福恩也坐了下来。"
    translate None fawn_chapter1_0319:
        rs "我们还是没有进展…我该怎么做才能引起这里的一点注意？他们只在乎自己。"
    translate None fawn_chapter1_0320:
        "嗯…好吧，我确实有个主意。"
    translate None fawn_chapter1_0321:
        rs c wsmi "…跳支舞怎么样？"
    translate None fawn_chapter1_0322:
        f c wemb "跳舞？在这里？现在？不，不，周围人太多了。"
    translate None fawn_chapter1_0323:
        rs "来吧，我不想昨晚的所有练习都白费了。"
    translate None fawn_chapter1_0324:
        f "那不能算练习…我们跳得都很烂。"
    translate None fawn_chapter1_0325:
        stop music fadeout 2.0
        "我站起来，拉着福恩回到了舞厅中央，乐队的音乐声中人们正在舞池里旋转。"

    window hide dissolve

    scene gallery_155 with dissolve
    window show dissolve
    translate None fawn_chapter1_0326:
        rs "就跳一小会儿？"
    translate None fawn_chapter1_0327:
        play music "sounds/bgm/Night.ogg" fadein 2.0
        f "..."
    translate None fawn_chapter1_0328:
        f "…好吧…就一会儿…"
    translate None fawn_chapter1_0329:
        "起初我们跳得很慢，很简单，跟着柔和的音乐节奏。我试着忽视其他人的目光，他们一定在奇怪这两个从未见过的仆人为何在跳舞。"
    translate None fawn_chapter1_0330:
        "我们的脚步大多不合拍，还时不时踩到对方，但这不要紧。"
    translate None fawn_chapter1_0331:
        "我们依然微笑着。"
    translate None fawn_chapter1_0332:
        "随着歌曲节奏加快，我们的动作也稍微快了些，我带着福恩转了个圈。当他的手臂再次环上我的脖子时，我把他拉得比之前更近了。"
    translate None fawn_chapter1_0333:
        "我们的目光一直交织在一起。这一次，连福恩都不敢移开视线。"
    translate None fawn_chapter1_0334:
        f "我…我觉得有人在看…"
    translate None fawn_chapter1_0335:
        rs "让他们看吧。我不介意。"
    translate None fawn_chapter1_0336:
        f "抱歉我跳得不是很好…"
    translate None fawn_chapter1_0337:
        rs "你很完美。"
    translate None fawn_chapter1_0338:
        scene gallery_156 with dissolve
        "我把额头抵在他的额头上。不知道为什么，就是觉得此刻应该这样做。"
    translate None fawn_chapter1_0339:
        "我感觉他因为震惊而身体僵硬，但随即又放松下来，接受了这个拥抱。"
    translate None fawn_chapter1_0340:
        f "…你在干什么？"
    translate None fawn_chapter1_0341:
        rs "休息，就一会儿。"
    translate None fawn_chapter1_0342:
        "说实话，我自己也不知道在做什么。"
    translate None fawn_chapter1_0343:
        rs "我不介意此刻化为永恒。改日可否再与我共舞一曲？"
    translate None fawn_chapter1_0344:
        f "….当然。你知道我愿为你做任何事。"
    translate None fawn_chapter1_0345:
        scene gallery_155 with dissolve
        "我再次睁眼，目光越过他的肩头。"
    translate None fawn_chapter1_0346:
        rs "..."
    translate None fawn_chapter1_0347:
        "房间另一端，我的视线锁住了一个橘红色马尾的男人。他系着围裙，衣着朴素。"
    translate None fawn_chapter1_0348:
        "他看着我们跳了一会儿舞，又继续忙自己的事。"
    translate None fawn_chapter1_0349:
        stop music fadeout 2.0
        rs "福恩，看那边！我们去和他聊聊！"


    window hide dissolve
    scene bg ball
    show fawn nw dim cloak neu at left
    show raen nw dim neu cloak at center
    show hone n dim neu at right
    with dissolve
    window show dissolve

    play music "sounds/bgm/sidcaeham.ogg"
    translate None fawn_chapter1_0350:
        "我拽着福恩的手追赶那个神秘人渐远的背影。接近时，他惊诧转身，显然被脚步声吓了一跳。"
    translate None fawn_chapter1_0351:
        show raen nw sur with dis
        rs "请等一下！打扰了！"
    translate None fawn_chapter1_0352:
        show hone n sur with dis
        u "...?"
    translate None fawn_chapter1_0353:
        show raen nw neu with dis
        rs "对不起…吓到你了真的很抱歉。"
    translate None fawn_chapter1_0354:
        u "没关系，我只是有点惊讶竟然有人在注意我。"
    translate None fawn_chapter1_0355:
        show raen nw sad with dis
        rs "彼此彼此。我和别人搭话从来得不到回应。"
    translate None fawn_chapter1_0356: #NEW FAWN LINE
        show raen nw smi with dis
        rs "我叫雷恩，这是福恩。我们…呃…随西纳库洛斯大人来的。能占用你一点时间吗？"
    translate None fawn_chapter1_0357:
        show hone n awk with dis
        "他转头望向房间后方的一扇门。服务员们端着看起来很昂贵的食物频繁进出。"
    translate None fawn_chapter1_0358:
        u "有点时间，不过我得赶快回厨房。我们可以边走边聊。"
    translate None fawn_chapter1_0359:
        show hone n neu with dis
        h "对了，我叫霍恩。"
    translate None fawn_chapter1_0360:
        show raen nw sur with dis
        rs "霍恩…你是厨师之类的吗？"
    translate None fawn_chapter1_0361:
        show hone n smi with dis
        $ about_Hone.locked = False
        h "哈哈，我只是个{a=set_entry:enc_people->about_Hone}{color=#DA70D6}面包师{/color}{/a}。"
    translate None fawn_chapter1_0362:
        "他说话时长着雀斑的脸亮了起来。虽然话不多，但周身散发着让人愿意亲近的气质。"
    translate None fawn_chapter1_0363:
        rs "我在找一个叫卡斯皮安的男人。他大概…17、18年前来过这里。我知道很久远了，但如果你能仔细回忆—"
    translate None fawn_chapter1_0364:
        h "卡斯皮安？我认识他啊。"
    translate None fawn_chapter1_0365:
        rs "就算你不认识，如果能介绍其他可能知道的人—"
    translate None fawn_chapter1_0366:
        show raen nw sur with dis
        show fawn nw sur with dis
        rs "等等，什么？！"
    translate None fawn_chapter1_0367:
        h "卡斯皮安。高个子，棕色头发。我时不时能见到他。"
    translate None fawn_chapter1_0368: #NEW FAWN LINE
        f "…！能告诉我们去哪找他吗？！"
    translate None fawn_chapter1_0369:
        "走到门口时，霍恩把手搭在门框上。"
    translate None fawn_chapter1_0370:
        h "…在下城区我有个面包坊。你们明天能来一趟吗？到时候可以详细说说他的事。"
    translate None fawn_chapter1_0371:
        h "不能再聊了，否则下次可能就没邀请函了。"
    translate None fawn_chapter1_0372:
        rs "好，明白了。我一定去。"
    translate None fawn_chapter1_0373:
        hide hone
        with dissolve
        show raen nw sur cloak at slightright
        show fawn nw sur cloak at slightleft
        with move
        "他微微点头致意，随即消失在厨房里。"
    translate None fawn_chapter1_0374:
        rs "福恩…福恩，我真不敢相信！终于找到了！"
    translate None fawn_chapter1_0375: #FAWN LINE
        show fawn nw hap with dis
        f "看吧？我就说过一切都会好起来的。"
    translate None fawn_chapter1_0376:
        show raen nw neu with dis
        rs "现在怎么办？我觉得在这里并不受欢迎。"
    translate None fawn_chapter1_0377:
        show fawn nw neu with dis
        f "我也是。不如我们现在就离开？"
    translate None fawn_chapter1_0378:
        "经过时我俩顺手拿了点食物，边吃边往外走。"

    stop music fadeout 2.0


    if achievement.has("fawn_ball"):
        pass
    else:
        $ renpy.display_notify("成就解锁：舞蹈练习")

    python:
        achievement.grant("fawn_ball")
        achievement.sync()
    translate None fawn_chapter1_0379:
        "没人注意到我们，不过这也算常态了。他们都只顾忙自己的事。"



    window hide dissolve
    scene bg sc night
    with dissolve
    window show dissolve

    play music "sounds/bgm/night.ogg" fadein 2.0
    translate None fawn_chapter1_0380:
        "外面的空气刺骨寒冷，寒意直钻心底，让我们不自觉地靠得更近了些。"
    translate None fawn_chapter1_0381:
        "走出大楼时，我们注意到有人环抱双臂站在阴影处。"


    show raen nw dark neu cloak at center
    show fawn nw dark neu cloak at left
    show illran n dark armsdown fli at right
    with dissolve
    translate None fawn_chapter1_0382:
        i "终于出现了啊。是不是在里面玩得乐不思蜀了？"
    translate None fawn_chapter1_0383:
        rs "….你好啊，伊尔兰。在等我们吗？"
    translate None fawn_chapter1_0384:
        show illran n dark neu with dis
        i "确实。有些关于索伦的消息，但现在不是谈这个的时候。"
    translate None fawn_chapter1_0385:
        rs "…知道霍恩面包坊吗？在下城区。"
    translate None fawn_chapter1_0386:
        "他点点头。"
    translate None fawn_chapter1_0387:
        show raen nw sur with dis
        rs "明天中午在那儿碰面。喂等等，维拉斯去哪了？"
    translate None fawn_chapter1_0388:
        "我这才发现既不见那个桃红色头发的男人，也看不到那只蓝鸟。"
    translate None fawn_chapter1_0389:
        show illran n dark sad with dis
        i "…我们又不是形影不离的。"
    translate None fawn_chapter1_0390:
        i "..."
    translate None fawn_chapter1_0391:
        i "他现在看着索伦呢。不知为何他担心得要命。"
    translate None fawn_chapter1_0392:
        show fawn nw sad with dis
        f "…他会没事吗？"
    translate None fawn_chapter1_0393:
        i "......"
    translate None fawn_chapter1_0394:
        show illran n dark neu with dis
        i "明天再谈。中午，霍恩的面包店。"

    window hide



    menu:
        "转达谢意":
            $ illranveras_friend += 1
            window show dissolve
            translate None fawn_chapter1_0395:
                rs "谢谢你，伊尔兰。"
            jump fawnroutechoice1done

        "保持沉默":
            window show dissolve
            jump fawnroutechoice1done


label fawnroutechoice1done:
    hide illran with dissolve
    show raen at slightright
    show fawn nw at slightleft
    with move
    translate None fawn_chapter1_0396:
        "他转身离去，很快消失在夜色中。"
    translate None fawn_chapter1_0397:
        rs "还是那么神秘又麻烦…"
    translate None fawn_chapter1_0398:
        show fawn nw neu with dis
        f "....."
    translate None fawn_chapter1_0399:
        show fawn nw sad with dis
        f "你觉得他到底想从我们这里得到什么？"
    translate None fawn_chapter1_0400:
        rs "….我不知道。最初以为他别无所求。毕竟我们的相遇都是偶然。"
    translate None fawn_chapter1_0401:
        show raen nw sad with dis
        rs "…但现在感觉他确实有所图谋。我说不清。"
    translate None fawn_chapter1_0402:
        "反观维拉斯，看起来单纯善良得要命…实在难以想象他会利用我们。"
    translate None fawn_chapter1_0403:
        show raen nw smi with dis
        rs "好吧，这个问题改天再想。今晚我们要庆祝！得赶快告诉大家！"
    translate None fawn_chapter1_0404:
        "最终被刺骨严寒击败的我们冲向银柳，在初雪上留下一串足迹。"
    translate None fawn_chapter1_0405:
        "快到门口时，福恩突然停下，仔细端详我的脸。"
    translate None fawn_chapter1_0406:
        show fawn nw sur with dis
        f "你…"
    translate None fawn_chapter1_0407:
        rs "嗯？"
    translate None fawn_chapter1_0408:
        "他伸手抚上我的脸。似乎还不满足，又闭眼凑得更近。"
    translate None fawn_chapter1_0409:
        show raen nw sur with dis
        rs "你干什—"
    translate None fawn_chapter1_0410:
        window hide dissolve
        scene gallery_157 with dissolve
        window show dissolve
        "哦-哦，我…我知道…该怎么做…"
    translate None fawn_chapter1_0411:
        "现在可别搞砸了，雷恩。"
    translate None fawn_chapter1_0412:
        scene gallery_158 with dissolve
        "我闭上眼，双唇相触。柔软，甜美。"
    translate None fawn_chapter1_0413:
        scene gallery_158b with dissolve
        "感觉到他的睫毛在我脸颊扑闪，随后又轻轻合上。"
    translate None fawn_chapter1_0414:
        "心脏剧烈跳动仿佛要蹦出胸口。方才充斥脑海的万千思绪全都化作浆糊。"


    if cyne_yes:
        translate None fawn_chapter1_0415:
            "这个吻纯净平和，与我先前所有接吻体验都不同。没有急切与匆忙，却依然炽热。"

        jump frcynekiss

    else:
        translate None fawn_chapter1_0416:
            "温暖得超乎想象…此刻我找不到更想共度之人。"

        jump frcynekiss

label frcynekiss:
    translate None fawn_chapter1_0417:
        "双手贴着他冰凉的脸颊，我将人搂得更近。能感觉到他的笨拙逐渐消融，他也在加深这个吻。"
    translate None fawn_chapter1_0418:
        "不知缠绵了多久—像是一瞬又像永恒—他突然睁眼，受惊般跳开。"
    translate None fawn_chapter1_0419:
        scene gallery_157 with dissolve
        f "....."
    translate None fawn_chapter1_0420:
        rs "呃…"
    translate None fawn_chapter1_0421:
        f "雪…雪…"
    translate None fawn_chapter1_0422:
        rs "什么？"
    translate None fawn_chapter1_0423:
        f "我只是…想帮你…拂掉雪花…"
    translate None fawn_chapter1_0424:
        "他脸涨得通红，想必我也好不到哪去。我们仍维持着相拥姿势，仿佛不舍分离。"
    translate None fawn_chapter1_0425:
        rs ".........."
    translate None fawn_chapter1_0426:
        rs "我……"
    translate None fawn_chapter1_0427:
        "未及开口，他已转身冲进屋内，怕是直奔自己房间。"


    window hide dissolve
    scene bg swroom night with dissolve
    window show dissolve
    translate None fawn_chapter1_0428:
        "独自站在雪中羞恼至极，我蹒跚回房栽倒在床。"
    translate None fawn_chapter1_0429:
        "福恩和伊尔兰说过的话在脑海中不断回响。"
    translate None fawn_chapter1_0430:
        "心跳如鼓，胸腔里翻涌着奇异的暖流…"
    translate None fawn_chapter1_0431:
        "我…再也不想与他分离。"
    translate None fawn_chapter1_0432:
        "我想常伴他左右，再不让他孤独一人。"
    translate None fawn_chapter1_0433:
        "想把他拉近…再吻一次…"
    translate None fawn_chapter1_0434:
        "我…我想我是爱上福恩了。"
    translate None fawn_chapter1_0435:
        "这可能吗？这就是爱的感觉？"
    translate None fawn_chapter1_0436:
        "当初听他们解释时…觉得荒诞不经，但现在…我无比确信。这就是爱。"
    translate None fawn_chapter1_0437:
        "我站起身走向房门。手搭在门把上，却没有转动它。"
    translate None fawn_chapter1_0438:
        "我现在就想去找他。现在就想去告诉他。"
    translate None fawn_chapter1_0439:
        "……可这太可怕了。为什么爱会让人如此忐忑？从前和他说话时从不曾这样害怕。"
    translate None fawn_chapter1_0440:
        "或许……暂时搁置，明天再考虑会更好。"
    translate None fawn_chapter1_0441:
        "嗯。这主意不错。"
    translate None fawn_chapter1_0442:
        "我脱下衣服爬上床。独自躺着，床显得格外宽大空旷。手指无意识地抚上嘴唇，那里还残留着不久前福恩的温度。"
    translate None fawn_chapter1_0443:
        "……还想再尝一次。"
    translate None fawn_chapter1_0444:
        "阖上双眼，我坠入虚无的梦境，满脑子都是福恩的身影。"


    window hide dissolve
    scene black with eye_shut

    if iv_scene_one and illranveras_friend >= 3:
        stop music fadeout 2.0
        jump illranverasscene2

    else:
        pause 1.0
        jump fawnroute2continued

label fawnroute2continued:
    if iv_scene_two:
        scene black with dissolve
        pause 2.0
    window hide dissolve
    scene bg swroom day with eye_open
    window show dissolve
    translate None fawn_chapter1_0445:
        rs wsad "嗯…"
    translate None fawn_chapter1_0446:
        play music "sounds/bgm/sad.ogg" fadein 2.0
        "又是空无一物的梦境……"
    translate None fawn_chapter1_0447:
        "你在哪儿……？去了何方……？"
    translate None fawn_chapter1_0448:
        "睡眼惺忪地眨着眼，映入眼帘的是赛恩为我预定的华美房间。 "
    translate None fawn_chapter1_0449:
        "恐怕永远都适应不了这种……奢侈。"
    translate None fawn_chapter1_0450:
        "新衣裳、华美床榻、舞会…这么多新鲜事物。"
    translate None fawn_chapter1_0451:
        "……还有……"
    translate None fawn_chapter1_0452:
        "……福恩。"
    translate None fawn_chapter1_0453:
        "脸颊突然发烫，我把脸埋进掌心。"
    translate None fawn_chapter1_0454:
        "我干嘛那样做？怎么会误以为他要吻我？蠢透了。"
    translate None fawn_chapter1_0455:
        "不，等等……为何不早点行动？"
    translate None fawn_chapter1_0456:
        "胸中这份暖意，对福恩的这份悸动……并非新鲜事物，对吧？几乎从初见时就埋下了种子。"
    translate None fawn_chapter1_0457:
        "……必须尽快告诉他，可现在我连面对他的勇气都没有。"
    translate None fawn_chapter1_0458:
        "跳下床匆忙更衣时，那个吻又浮现在脑海。他双唇贴上来时的柔软触感……"
    translate None fawn_chapter1_0459:
        "停，现在别想这个。当务之急……得先把昨夜的事告诉莱奥斯和赛恩。"
    translate None fawn_chapter1_0460:
        "不是接吻的事！是关于霍恩，还有卡斯皮安。"
    translate None fawn_chapter1_0461:
        "但愿他们已经在大堂了。"
    translate None fawn_chapter1_0462:
        "目光飘向敞开的窗户。阳光灿烂，鸟雀在窗台边啁啾蹦跳。"
    translate None fawn_chapter1_0463:
        "想必已近晌午。"
    translate None fawn_chapter1_0464:
        "转眼间我已冲出房门，朝前台走去。"

    stop music fadeout 2.0

    window hide dissolve


    scene bg sw day with dissolve
    window show dissolve

    show leos nw cloak thi at left
    show cyne nw cloak smi at center
    show raen nw cloak neu at right
    with dissolve
    translate None fawn_chapter1_0465:
        l "啧，有完没完。能不能回到之前那副要死不活的样子？受够你了。"
    translate None fawn_chapter1_0466:
        play music "sounds/bgm/Fooling Around Tiny.ogg" fadein 2.0
        c "咬你？乐意之至。"
    translate None fawn_chapter1_0467:
        show leos hur with dis
        l "呃，那不是我要你从这句话里摘出来的部分。"
    translate None fawn_chapter1_0468:
        show cyne hap with dis
        c "我来啦！"
    translate None fawn_chapter1_0469:
        l "嘿—等等，别过来！"
    translate None fawn_chapter1_0470:
        c "啊哈哈哈，太迟啦！你可真是道美味的点心呢！"
    translate None fawn_chapter1_0471:
        "我赶到时，赛恩已经像往常一样缠着莱奥斯不放。他几乎整个人挂在那家伙身上，轻轻啃咬着皮肤，而莱奥斯正拼命想摆脱他。"
    translate None fawn_chapter1_0472:
        rs "…早上好。你俩可真有精神。"
    translate None fawn_chapter1_0473:
        l "雷恩，你得帮帮我。求你了，我什么都答应，快把这小矮子弄走！"
    translate None fawn_chapter1_0474:
        rs "唔…什么都行？"
    translate None fawn_chapter1_0474b:
        l "什么都行！"
    translate None fawn_chapter1_0475:
        show raen smi with dis
        "说不定以后能派上用场。"
    translate None fawn_chapter1_0476:
        rs "赛恩，过来。"
    translate None fawn_chapter1_0477:
        "转眼他就跳下来朝我走来。"
    translate None fawn_chapter1_0478:
        c "怎么了雷恩？想我啦？一刻都离不开我？"
    translate None fawn_chapter1_0479:
        c "说实话吧—你已经对福恩感到厌烦了对不对？"
    translate None fawn_chapter1_0480:
        show raen sur with dis
        rs "什么？！才没有！绝对没有！"
    translate None fawn_chapter1_0481:
        show cyne sad with dis
        c "切……等你回心转意时记得来找我。"
    translate None fawn_chapter1_0482:
        rs "….我选择无视这句话。对了，你们见到福恩了吗？"
    translate None fawn_chapter1_0483:
        c "刚才敲他房门，但他不知为什么不肯出来。"
    translate None fawn_chapter1_0484:
        rs "…他说原因了吗？"
    translate None fawn_chapter1_0485:
        c "先说身体不舒服，又说很累，最后嘟囔着很快出来。"
    translate None fawn_chapter1_0486:
        show cyne smi with dis
        c "所以是害羞了啊。雷恩你应该知道些什么吧？嗯？"
    translate None fawn_chapter1_0487:
        show raen neu blush with dis
        rs"......"
    translate None fawn_chapter1_0488:
        show leos neu with dis
        l "更重要的是，昨晚有收获吗？"
    translate None fawn_chapter1_0489:
        show raen neu -blush with dis
        "我点头的瞬间，两人神色都凝重起来。"
    translate None fawn_chapter1_0490:
        rs "几乎所有人都对我们视而不见，但总算有人说上话。霍恩，他是个…厨师或者面包师之类的。"
    translate None fawn_chapter1_0491:
        rs "他忙着干活没能多聊，但说认识卡斯皮安可以带路，约我们今天去他 bakery 见面。"
    translate None fawn_chapter1_0492:
        rs "哦对了还碰到伊尔兰，他说有关于索伦的新情报要分享，晚点也会过来。"
    translate None fawn_chapter1_0493:
        f c wsad "…….嗯…..大家早……"


    show leos at farleft
    show cyne at cenleft
    show raen at cenright
    with move
    show fawn nw cloak sad blush at farright
    with dissolve

    translate None fawn_chapter1_0494:
        "福恩出现了，整个人紧张得像团毛球。视线在众人和地面间来回躲闪，耳尖红得能滴血。"
    translate None fawn_chapter1_0495:
        "赛恩见状突然露出狡黠的笑容。"
    translate None fawn_chapter1_0496:
        show cyne hap with dis
        c "莱奥斯…我知道你最近特别特别享受我们的独处时光。"
    translate None fawn_chapter1_0497:
        l "…我不喜欢这种推测的方向。"
    translate None fawn_chapter1_0498:
        c "所以，你觉得呢？你和我，在雪中浪漫漫步…听起来不是很美妙吗？"
    translate None fawn_chapter1_0499:
        c "最后你可以俯身拂去我发间的雪花，而我可能会误会成—"
    translate None fawn_chapter1_0500:
        show raen sur blush with dis
        rs "喂！"
    translate None fawn_chapter1_0501:
        l "休想。"
    translate None fawn_chapter1_0502:
        show cyne sur with dis
        c "你真无趣。好吧，我知道你会配合的。你只是不好意思，对吧？"
    translate None fawn_chapter1_0503:
        show leos hur blush with dis
        l "什么？！那何必多此一问？！"
    translate None fawn_chapter1_0504:
        c "来吧，我{i}好歹{/i}有些教养。快点，快点，我们该出发了。"
    translate None fawn_chapter1_0505: # CHECK VOICE MAP
        show raen sur with dis
        rs "你不打算去看霍恩吗？"
    translate None fawn_chapter1_0506:
        c "这事就交给你了。"
    translate None fawn_chapter1_0507:
        rs "....?"


    hide cyne
    hide leos
    with dissolve

    show raen at slightleft
    show fawn at slightright

    with move
    translate None fawn_chapter1_0508:
        "又一次，我们目睹赛恩拖着奋力挣扎的莱奥斯离开的场景。"
    translate None fawn_chapter1_0509:
        "赛恩转身朝我们眨眼示意，随后从前门离去。"
    translate None fawn_chapter1_0510:
        "撑住啊，莱奥斯。"
    translate None fawn_chapter1_0511:
        stop music fadeout 3.0
        rs "....."
    translate None fawn_chapter1_0512:
        f "....."
    translate None fawn_chapter1_0513:
        show raen emb with dis
        rs "那个…你睡得还好吗？"
    translate None fawn_chapter1_0514:
        f "….还行。"
    translate None fawn_chapter1_0515:
        rs "咳咳…这样啊…"
    translate None fawn_chapter1_0516:
        "尴尬的沉默持续蔓延，我们都不知道何时能打破。几次局促的对视后，福恩突然叹了口气。"
    translate None fawn_chapter1_0517:
        show fawn neu with dis
        play music "sounds/bgm/Discovery.ogg" fadein 2.0
        f "…我们是不是该出发了？"
    translate None fawn_chapter1_0518:
        rs "..去霍恩的面包店，对。我把昨晚的事告诉赛恩和莱奥斯了，他们都已知情。可惜他们不一起来。"
    translate None fawn_chapter1_0519:
        "我挠了挠后脑勺，福恩缓缓点头。"
    translate None fawn_chapter1_0520:
        "片刻后，我们走出前门，迎面是凛冽的冬日景象。"


    window hide dissolve


    scene bg sc day with dissolve
    window show dissolve
    translate None fawn_chapter1_0521:
        "屋外与往日并无二致—银装素裹的仙境。孩子们早已开始互掷雪球，对周遭浑然不觉。"
    translate None fawn_chapter1_0522:
        "我和福恩左躲右闪，险些丧命雪球攻势。"
    translate None fawn_chapter1_0523:
        show fawn nw cloak sur at slightright
        show raen nw cloak sur at slightleft
        with dissolve
        rs "…他们玩得真开心…"
    translate None fawn_chapter1_0524:
        "福恩用余光打量我，脸上掠过一丝好奇。"
    translate None fawn_chapter1_0525:
        rs "我提过他们吧？孤儿院有很多孩子，但托比亚斯和米娅对我很特别。"
    translate None fawn_chapter1_0526:
        rs "这里或许不同，但在我们那，若你在孤儿院长大，基本就会一直待着。领养几乎不存在。"
    translate None fawn_chapter1_0527:
        f "为什么没人领养他们？"
    translate None fawn_chapter1_0528:
        rs "嗯…谁会收养被判为二等资质的孩子呢？这就是他们都在那里的原因。父母得知孩子难成大器后，出生不久便遗弃了。当然，我并不认同这点。"
    translate None fawn_chapter1_0529:
        show raen sad with dis
        rs "米娅对我来说就是那样。她刚来时才几周大，那时我九岁。她那么幼小，那么脆弱。我一直把她当作自己的小妹妹。"
    translate None fawn_chapter1_0530:
        rs "托比亚斯…他是个特例。他四岁时来到这里，当时他的母亲失踪了。他们也始终没能找到她。"
    translate None fawn_chapter1_0531:
        rs "这两个孩子形影不离。最好的朋友，还有…我珍贵的家人。"
    translate None fawn_chapter1_0532:
        show fawn sad with dis
        rs "真希望能带他们来这儿，让他们在雪地里玩耍。真希望他们能在海滩上堆沙堡。"
    translate None fawn_chapter1_0533:
        f "..."
    translate None fawn_chapter1_0534:
        f "我也希望他们能这样。"
    translate None fawn_chapter1_0535:
        rs "…你会来吗？"
    translate None fawn_chapter1_0536:
        f "我…我不太擅长应付孩子，你知道的…我自己生活都一团糟…"
    translate None fawn_chapter1_0537:
        show raen neu blush with dis
        rs "我们可以一起。你，我，还有孩子们。"
    translate None fawn_chapter1_0538:
        show fawn sur blush with dis
        f "你…说得好像…"
    translate None fawn_chapter1_0539:
        "我相信他会是个好父亲。"
    translate None fawn_chapter1_0540:
        show raen sur -blush with dis
        rs "啊，看那边！"
    translate None fawn_chapter1_0541:
        "我指向前方，路边坐落着一栋建筑。招牌写着\"霍恩面包坊\"，在风中轻轻摇晃。"
    translate None fawn_chapter1_0542:
        "一群人拎着鼓鼓囊囊的纸袋走出店铺，里面装着满溢的面包糕点，他们兴奋地叽叽喳喳说笑着。"
    translate None fawn_chapter1_0543:
        rs "应该就是这了。我们进去吗？时间还早，不过在里面等总比站在外面强。"
    translate None fawn_chapter1_0544:
        show fawn neu with dis
        "我拉开门，跟在福恩身后走进店内。"


    window hide dissolve

    jump honezarryn
