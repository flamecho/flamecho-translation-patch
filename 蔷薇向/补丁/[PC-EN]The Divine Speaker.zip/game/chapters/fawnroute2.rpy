
label fawnroute1continued2:
    scene bg sc sunset
    with dissolve

    window show dissolve
    translate None fawn_chapter2_0001:
        "当我们踏入寒冷时，我终于注意到自己的双手在颤抖。就是这里了…卡斯皮安。"
    translate None fawn_chapter2_0002:
        rs c wsur "如果霍恩的指引没错，我们离目的地不远了。快点，我一刻也等不及了。"

    play music "sounds/bgm/night.ogg" fadein 2.0

    show raen nw sunset cloak sur at slightleft
    show fawn nw sunset cloak sad blush at slightright
    with dissolve
    translate None fawn_chapter2_0003:
        f "等…等等！"
    translate None fawn_chapter2_0004:
        rs "...?"
    translate None fawn_chapter2_0005:
        f "我们能…先谈一会儿吗？我保证不会太久。"
    translate None fawn_chapter2_0006:
        rs "嗯？你说。"
    translate None fawn_chapter2_0007:
        show fawn nw neu blush with dis
        f "是关于…昨晚的事。"
    translate None fawn_chapter2_0008:
        show raen nw emb blush with dis
        rs "啊啊啊…."
    translate None fawn_chapter2_0009:
        "这次是福恩直勾勾盯着我的脸，而我却难堪地别开了视线。"
    translate None fawn_chapter2_0010:
        "好吧…好吧，我必须告诉他。不能有误会。"
    translate None fawn_chapter2_0011:
        rs "福恩…关于那件事，我…"
    translate None fawn_chapter2_0012:
        show fawn nw sur -blush with dis
        f ".....!!!"
    translate None fawn_chapter2_0013:
        rs "其实…我…"


    hide fawn with dissolve
    show raen nw sur with dis
    translate None fawn_chapter2_0014:
        rs "福恩？！"
    translate None fawn_chapter2_0015:
        hide raen with dissolve
        "他突然跑开，眼睛紧盯着某处，仿佛性命攸关。我未说完的话语悬在空中，被无视被抛在脑后。"
    translate None fawn_chapter2_0016:
        "我转身想看清到底是什么在这关键时刻吸引了他的注意力。"
    translate None fawn_chapter2_0017:
        rs c wsur "..."
    translate None fawn_chapter2_0018:
        "谁…？"
    translate None fawn_chapter2_0019:
        "我追上去时，正好看见他抓住一个蓝发女孩。她转过身，脸上写满震惊。"
    translate None fawn_chapter2_0020:
        "我猛地刹住脚步。"
    translate None fawn_chapter2_0021:
        stop music fadeout 3.0
        "她看起来…简直就像…"


    show raen nw sunset cloak sur at left
    show fawn nw sunset sur cloak at center
    show ani n sunset sad at right
    with dissolve

    if achievement.has("fawn_ani"):
        pass
    else:
        $ renpy.display_notify("成就解锁：等等，那不是福恩")

    python:
        achievement.grant("fawn_ani")
        achievement.sync()

    translate None fawn_chapter2_0022:
        ani "…阿登？"
    translate None fawn_chapter2_0023:
        play music "sounds/bgm/forgotten off.ogg" fadein 3.0
        f "安妮…安妮，真的是你吗？"
    translate None fawn_chapter2_0024:
        "她脸上的表情变化之快，我几乎分辨不出她的情绪。从困惑，到悲伤，到愤怒，最后归于平静。"
    translate None fawn_chapter2_0025:
        show ani n neu2 with dis
        ani "这些年你到底去哪儿了？！已经…已经过去这么久了…"
    translate None fawn_chapter2_0026:
        show fawn nw sad with dis
        f "就…就在附近，你知道的。"
    translate None fawn_chapter2_0027:
        show ani n sunset sad with dis
        ani "附近？！你怎么能在\"附近\"一待就是十年？！"
    translate None fawn_chapter2_0028:
        rs "…福恩？这位…是谁？"
    translate None fawn_chapter2_0029:
        ani "福恩？"
    translate None fawn_chapter2_0030:
        $ about_Ani.locked = False
        f "噢，那是…我现在用的名字。雷恩，这是…{a=set_entry:enc_people->about_Ani}{color=#DA70D6}安妮{/color}{/a}，我的姐姐。"
    translate None fawn_chapter2_0031:
        rs "你的…姐姐？"
    translate None fawn_chapter2_0032:
        rs"我是说…很高兴认识你。"
    translate None fawn_chapter2_0033:
        "她看起来…和福恩几乎一模一样。蓝色的长发，柔和的面容…"
    translate None fawn_chapter2_0034:
        show ani n cry with dis
        ani "阿登…我好想你…我们都很想你。没有一天我们不在思念你。"
    translate None fawn_chapter2_0035:
        ani "所有姐妹都还住在克利夫斯派尔的老家。见到你她们一定会欣喜若狂的！你必须回家看看，一定要。"
    translate None fawn_chapter2_0036:
        "克利夫斯派尔…"
    translate None fawn_chapter2_0037:
        f "真…真的吗？我以为…我以为你…"
    translate None fawn_chapter2_0038:
        show ani n hap with dis
        ani "你是我弟弟。我永远都不可能真的生你的气。"
    translate None fawn_chapter2_0039:
        show fawn nw smi with dis
        "她将他的双手紧握在自己掌中，将他拉入怀抱。他的笑容真挚而赤裸，饱含快乐与…某种别样的情绪。一丝隐隐的哀伤。"
    translate None fawn_chapter2_0040:
        ani "你会再来见我吗？我很快要回家了，但明天还会在这儿。求你了？"
    translate None fawn_chapter2_0041:
        show fawn nw sur with dis
        f "当然会来的…！"
    translate None fawn_chapter2_0042:
        show ani neu1 with dis
        ani "啊…"
    translate None fawn_chapter2_0043:
        "她的目光与我交汇。我尴尬地站在一旁，像个局外人。"
    translate None fawn_chapter2_0044:
        ani "….独自占有。我想让时光将你独留给我。"
    translate None fawn_chapter2_0045:
        f "如果…这是你的愿望，那好吧。"
    translate None fawn_chapter2_0046:
        show ani n hap with dis
        ani "那就约定好了。现在我得走了，但我会分秒倒数直到再见之时。"
    translate None fawn_chapter2_0047:
        show ani n neu2 with dis
        "她转身离去，却不忘再次瞥向我。那眼神中满含轻蔑，随后她便消失了。"


    hide ani with dissolve
    show raen at slightleft
    show fawn at slightright
    with move
    translate None fawn_chapter2_0048:
        rs "….所以…"
    translate None fawn_chapter2_0049:
        f "我…猜你想要个解释？"
    translate None fawn_chapter2_0050:
        show bg sc night
        show raen dark
        show fawn dark
        with dis3
        $ about_Archives._text.append("原来福恩在故乡克利夫斯派尔有七个姐姐。")
        f "….我姐姐。其中之一。我在克利夫斯派尔老家有…{a=set_entry:enc_people->about_Fawn}{color=#87CEEB}七位{/color}{/a}姐姐。"
    translate None fawn_chapter2_0051:
        rs "七个？这…还真不少。为何从不曾听你提起？"
    translate None fawn_chapter2_0052:
        "他的嘴角抽动，眉宇紧蹙。"
    translate None fawn_chapter2_0053:
        show fawn nw sad with dis
        f "这事…很复杂。我…十年前不得不离开，以为她们再不愿见我，可是…！"
    translate None fawn_chapter2_0054:
        f "她们想见我！真难以置信。我简直要哭出来了。"
    translate None fawn_chapter2_0055:
        show raen nw smi with dis
        rs "….替你高兴。真心实意。"
    translate None fawn_chapter2_0056:
        rs "现在去找卡斯皮安有点晚了吧？不如先回去，明天再去见他。"
    translate None fawn_chapter2_0057:
        f "对不起…都怪我。"
    translate None fawn_chapter2_0058:
        rs "不，完全不是。那对你很重要。"
    translate None fawn_chapter2_0059:
        show raen nw neu with dis
        show fawn nw neu with dis
        stop music fadeout 2.0
        "当我们想起原本要谈的正事，对话便戛然而止。我们没再提及那个话题，转而踏上了返回住所的路。"
    translate None fawn_chapter2_0060:
        rs "….夜色真美，是吧？"
    translate None fawn_chapter2_0061:
        f "Ahem… yeah…"
    translate None fawn_chapter2_0062:
        show raen nw emb with dis
        rs "哈哈…"
    translate None fawn_chapter2_0063:
        "整段路我都在构思告白的方式，可还未等行动，我们已站在银柳门前。福恩伸手要推门，我却抓住他的手腕将他拽回。"

    window hide dissolve

    scene gallery_159 with dissolve
    window show dissolve

    if chose_fawn and not fawn_oxchoose:
        translate None fawn_chapter2_0064:
            "他的手小巧柔软，与我的十指相扣宛若天造地设。自从小鹿之家湖畔那次牵手后，暌违已久…"
        translate None fawn_chapter2_0065:
            "恍如隔世。"


    if fawn_oxchoose:
        translate None fawn_chapter2_0066:
            "他的手小而柔软，恰好能嵌入我的掌心，仿佛是为彼此而生。这让我想起我们如何在奥克斯哈伯的街道上手牵手漫步，直到遇见索伦之前。"
        translate None fawn_chapter2_0067:
            "这次感觉不同。"


    play music "sounds/bgm/night.ogg" fadein 3.0
    translate None fawn_chapter2_0068:
        rs "福恩…我…我必须对你坦白。我不希望我们之间继续这种尴尬。你对我来说太重要了。"
    translate None fawn_chapter2_0069:
        rs "…我一直在苦苦思索。可能比以往任何时候都要痛苦。我仍然…仍然很困惑，但我确定一件事。"
    translate None fawn_chapter2_0070:
        rs "…你。我对你从来都很确定。"
    translate None fawn_chapter2_0071:
        f "....."
    translate None fawn_chapter2_0072:
        rs "福恩，我想我爱上你了。"
    translate None fawn_chapter2_0073:
        rs "这不是新近发生的。我想…这种感觉一直存在于我心中，只是刚刚才意识到。"
    translate None fawn_chapter2_0074:
        f "…什么？"
    translate None fawn_chapter2_0075:
        "他的回答很轻，几乎耳语。"
    translate None fawn_chapter2_0076:
        rs "你…你对我意味着一切。当我回想经历过的所有事，只要能遇见你，我愿意重来一遍。"
    translate None fawn_chapter2_0077:
        "我以全新的自信迎上他的目光。这是真相。他感觉像是…那个人。那个我想与之共度余生的人。"
    translate None fawn_chapter2_0078:
        "不，这样说不对。"
    translate None fawn_chapter2_0079:
        "不仅如此。当我设想未来时，他也在那里。"
    translate None fawn_chapter2_0080:
        rs "你真是…太棒了。英俊又可爱，聪明又睿智…好到让我自惭形秽，但是…"
    translate None fawn_chapter2_0081:
        rs "..你觉得呢？"
    translate None fawn_chapter2_0082:
        f "…我…."
    translate None fawn_chapter2_0083:
        scene gallery_160 with dissolve
        f "…我需要点时间理清思绪。可以吗？"
    translate None fawn_chapter2_0084:
        rs "哦…当然…"
    translate None fawn_chapter2_0085:
        "他抽回双手，脸色阴沉。我们就这样面对面站了一会，直到福恩再次开口。"
    translate None fawn_chapter2_0086:
        f "我…有点累，所以…我想先走了。"
    translate None fawn_chapter2_0087:
        rs "…晚安，福恩。"

    window hide dissolve

    scene bg sc night with dissolve
    window show dissolve
    translate None fawn_chapter2_0088:
        "然后只剩我独自一人。"
    translate None fawn_chapter2_0089:
        "....."
    translate None fawn_chapter2_0090:
        "这样或许最好。"
    translate None fawn_chapter2_0091:
        "如果他需要时间，我会给他。"
    translate None fawn_chapter2_0092:
        "…该睡觉了吧。"


    window hide dissolve


    scene bg swroom night with dissolve
    window show dissolve
    translate None fawn_chapter2_0093:
        "我沿着福恩走过的路回到房间。没有他显得空荡荡的。我迅速脱衣上床。"
    translate None fawn_chapter2_0094:
        "我只想入睡，但思绪不肯放过我。"
    translate None fawn_chapter2_0095:
        "如果我…如果我措辞更好些，现在还会独自一人吗？"
    translate None fawn_chapter2_0096:
        "于是开始了我的不眠之夜。"

    stop music fadeout 2.0
    window hide dissolve

    scene black with eye_shut
    pause (2.0)

    scene bg sc night with Fade(1.0, 1.0, 1.0)
    window show dissolve
    translate None fawn_chapter2_0097:
        "蓝发少年坐在雪地里，漫无目的地晃着腿。他试过入睡，但全然徒劳。"
    translate None fawn_chapter2_0098:
        play music "sounds/bgm/sad.ogg" fadein 3.0
        "他曾在房间里呆坐片刻，试图不去思考，却发现人能逃避思考的时间终究有限。"
    translate None fawn_chapter2_0099:
        "那些念头总会在你脑海角落盘旋，挥之不去。"
    translate None fawn_chapter2_0100:
        "他无意识地抓起一捧雪，看着它在掌心融化成水洼。"
    translate None fawn_chapter2_0101:
        fmn "雷恩…你为何非要那样说…？"
    translate None fawn_chapter2_0102:
        fmn "你为何非要毁掉我们之间的一切？"
    translate None fawn_chapter2_0103:
        fmn "不…不对。他不过是把我一直渴望的东西给了我。有问题的是我，不是他。"

    play sound "sounds/sfx/whoosh1.ogg"


    scene gallery_159sepia with flash
    translate None fawn_chapter2_0104: # VOICE MAOP TO ABOVE, SLIGHT REVERB EFFECT FOR MEMORY?
        rs "福恩…我…我必须对你坦白。我不希望我们之间继续这种尴尬。你对我来说太重要了。"
    translate None fawn_chapter2_0105:
        rs "…我一直在苦苦思索。可能比以往任何时候都要痛苦。我仍然…仍然很困惑，但我确定一件事。"
    translate None fawn_chapter2_0106:
        rs "…你。我对你从来都很确定。"
    translate None fawn_chapter2_0107:
        fmn "你在胡说什么？"
    translate None fawn_chapter2_0108:
        f "....."
    translate None fawn_chapter2_0109:
        rs "福恩，我想我爱上你了。"
    translate None fawn_chapter2_0110:
        rs "这不是新近发生的。我想…这种感觉一直存在于我心中，只是刚刚才意识到。"
    translate None fawn_chapter2_0111:
        f "…什么？"
    translate None fawn_chapter2_0112:
        rs "你…你对我意味着一切。当我回想经历过的所有事，只要能遇见你，我愿意重来一遍。"
    translate None fawn_chapter2_0113:
        rs "你真是…太棒了。英俊又可爱，聪明又睿智…好到让我自惭形秽，但是…"
    translate None fawn_chapter2_0114:
        rs "..你觉得呢？"
    translate None fawn_chapter2_0115:
        fmn "....."
    translate None fawn_chapter2_0116:
        fmn "当然…这不是很明显吗？我也爱你。我想告诉你，想声嘶力竭地喊出来。"
    translate None fawn_chapter2_0117:
        fmn "可是…"
    translate None fawn_chapter2_0118:
        fmn "…我不配拥有你。我是个…怪物。"
    translate None fawn_chapter2_0119:
        fmn "若我也伤害了你怎么办？我会无法原谅自己。我们…注定没有圆满结局。"
    translate None fawn_chapter2_0120:
        fmn "永远都不会有。"
    translate None fawn_chapter2_0121:
        f "…我…."
    translate None fawn_chapter2_0122:
        scene gallery_160sepia with dissolve
        f "…我需要点时间理清思绪。可以吗？"
    translate None fawn_chapter2_0123:
        fmn "我本该保持距离…我该留在森林里，让雷恩和莱奥斯自己去斯塔格威奇。"
    translate None fawn_chapter2_0124:
        fmn "对不起…"


    window hide dissolve


    scene bg sc night with dissolve
    window show dissolve
    translate None fawn_chapter2_0125:
        "福恩把脸埋进双手，几乎抑制不住泪水。"
    translate None fawn_chapter2_0126:
        fmn "像我这般肮脏的人怎配得上雷恩。我该…逃走才对。他和赛恩才更相配。"
    translate None fawn_chapter2_0127:
        "泪珠不断坠入雪中，直至干涸。即使再想哭泣，也已流不出眼泪。"


    show fawn nw cloak dark sad at slightleft
    show titus n dark mask sur at slightright
    with dissolve
    translate None fawn_chapter2_0128:
        tit "…福恩？是你吗？"
    translate None fawn_chapter2_0129:
        f "...!"
    translate None fawn_chapter2_0130:
        tit "你在下面做什么？深更半夜天寒地冻的！快起来。"
    translate None fawn_chapter2_0131:
        f "我…我只是…出来散步。"
    translate None fawn_chapter2_0132:
        tit "可我看你明明坐在雪地里哭。怎么回事？"
    translate None fawn_chapter2_0133:
        f "....."
    translate None fawn_chapter2_0134:
        f "…你是克利夫斯派尔来的，对吧？"
    translate None fawn_chapter2_0135:
        show titus sad -mask with dis
        "提图斯默默拉下面罩，露出底下烧伤的疤痕。"
    translate None fawn_chapter2_0136:
        tit "你怎么猜到的？我不记得曾透露过。"
    translate None fawn_chapter2_0137:
        f "....."
    translate None fawn_chapter2_0138:
        f "我也来自克利夫斯派尔。"
    translate None fawn_chapter2_0139:
        show titus sur with dis
        tit "你是…？那么…你知道那个恶魔的事？"
    translate None fawn_chapter2_0140:
        f "….对不起，提图斯。你父母…"
    translate None fawn_chapter2_0141:
        show titus neu with dis
        tit "…不是你的错。都是那个…怪物。半个村庄陷入火海，死了那么多人…"
    translate None fawn_chapter2_0142:
        tit "..不过都是往事了。听说他们已重建家园继续生活。我也走出来了。"
    translate None fawn_chapter2_0143:
        f "....."
    translate None fawn_chapter2_0144:
        "他认为这不可能，但眼眶再次湿润了。提图斯惊讶地跳开，不知该如何应对。"
    translate None fawn_chapter2_0145:
        show titus sur with dis
        tit "你…在那场火灾中失去谁了吗？"
    translate None fawn_chapter2_0146:
        f "..."
    translate None fawn_chapter2_0147:
        f "我父亲。后来是我母亲。我的姐妹们只能自求生路。"
    translate None fawn_chapter2_0148:
        tit "真不容易…来，站起来吧。"
    translate None fawn_chapter2_0149:
        "粉发男孩将福恩扶了起来。"
    translate None fawn_chapter2_0150:
        tit "我不确定具体问题出在哪，但对我来说…当我迷茫时，会寻找属于自己的幸福。"
    translate None fawn_chapter2_0151:
        show titus hap with dis
        tit "我得走了，不过…希望你也找到自己的幸福。"
    translate None fawn_chapter2_0152:
        hide fawn
        hide titus
        with dissolve
        "蓝发男孩再次独自伫立雪中。"
    translate None fawn_chapter2_0153:
        fmn "我的…幸福？"

    stop music fadeout 3.0

    window hide dissolve


    scene bg swroom day with Fade(1.0, 1.0, 1.0)
    window show dissolve
    translate None fawn_chapter2_0154:
        "我勉强睁开眼，看见柔和的阳光洒在床上。眼皮沉重迟缓，身体因缺眠而酸痛。"
    translate None fawn_chapter2_0155:
        play music "sounds/bgm/sad.ogg" fadein 3.0
        "大部分时间我都在回想对福恩说过的话，以及那些没说出口的话。"
    translate None fawn_chapter2_0156:
        "如果当时能做得不同些…说得更好些…"
    translate None fawn_chapter2_0157:
        "不，别再钻牛角尖了。我已经尽力了，不是吗？"
    translate None fawn_chapter2_0158:
        "揉揉眼睛，我挣扎着起床。看窗外景色，想必已近晌午。"
    translate None fawn_chapter2_0159:
        "…好久没见到莱奥斯或赛恩了。或许…可以找他们聊聊这事。"

    window hide

    menu:
        "我去找莱奥斯":
            window show dissolve
            jump fawnroutefindleos

        "赛恩应该能帮上忙":
            window show dissolve
            jump fawnroutefindcyne


label fawnroutefindleos:
    translate None fawn_chapter2_0160:
        "莱奥斯…他和福恩相处的时间不亚于和我。他会倾听的。"
    translate None fawn_chapter2_0161:
        "…但愿如此。"


    window hide dissolve
    scene bg sw day with dissolve
    window show dissolve
    translate None fawn_chapter2_0162:
        "离开房间却四处不见莱奥斯。正沮丧时，忽瞥见窗外那抹红发。"


    window hide dissolve
    scene bg sc day
    show raen nw cloak neu at slightleft
    show leos nw cloak neu at slightright
    with dissolve
    window show dissolve
    translate None fawn_chapter2_0163:
        rs "莱奥斯！"
    translate None fawn_chapter2_0164:
        l "瞧瞧这是谁。知道吗，你快给我造成被抛弃恐惧症了。"
    translate None fawn_chapter2_0165:
        show leos nw sur with dis
        l "…等等，赛恩没和你在一起吧？"
    translate None fawn_chapter2_0166:
        show raen sur with dis
        rs "这次没有。怎么？害怕了？"
    translate None fawn_chapter2_0167:
        show leos nw thi with dis
        l "说不怕是假的。"
    translate None fawn_chapter2_0168:
        rs "....."
    translate None fawn_chapter2_0169:
        rs "其实…那个…"
    translate None fawn_chapter2_0170:
        rs "能和你聊聊福恩的事吗？"
    translate None fawn_chapter2_0171:
        l "老鼠小子又干什么了？"
    translate None fawn_chapter2_0172:
        show raen nw sad with dis
        rs "不是他的问题。更多是…我的问题。"
    translate None fawn_chapter2_0173:
        l "别杵在那儿扭扭捏捏的，说吧。"
    translate None fawn_chapter2_0174:
        "我缓缓复述了前夜与福恩的经过。莱奥斯全程严肃倾听，一次都没打断。"
    translate None fawn_chapter2_0175:
        l "....."
    translate None fawn_chapter2_0176:
        l "唔…倒也不意外。谁愿意余生都当你的保姆？"
    translate None fawn_chapter2_0177:
        show raen nw sur with dis
        rs "嘿！认真点！"
    translate None fawn_chapter2_0178:
        show leos nw smu with dis
        l "我很认真。"
    translate None fawn_chapter2_0179:
        show raen nw neu with dis
        rs "你根本帮不上忙…"
    translate None fawn_chapter2_0180:
        show raen nw sur with dis
        rs "等一下…看那边！"
    translate None fawn_chapter2_0181:
        "我指向远处，看见两个蓝发人并肩走着。那绝对是福恩和他妹妹。"
    translate None fawn_chapter2_0182:
        rs "那是…那是福恩和安妮！"
    translate None fawn_chapter2_0183:
        show leos nw neu with dis
        l "安妮？"
    translate None fawn_chapter2_0184:
        rs "…福恩的妹妹。我们昨天遇见过她。"
    translate None fawn_chapter2_0185:
        show leos nw thi with dis
        l "....."
    translate None fawn_chapter2_0186:
        l "而你…你一点都不担心这事吗？"
    translate None fawn_chapter2_0187:
        show raen nw neu with dis
        rs "为什么要担心？他看起来很开心啊。"
    translate None fawn_chapter2_0188:
        l "就你认识他这些年，他什么时候愿意聊家人？什么时候愿意说他为什么离家出走独自生活十年？"
    translate None fawn_chapter2_0189:
        rs "嗯…"
    translate None fawn_chapter2_0190:
        l "就是啊。我感觉这里面有猫腻。"
    translate None fawn_chapter2_0191:
        rs "….我去跟上他们。"
    translate None fawn_chapter2_0192:
        show leos nw sur with dis
        l "等等，雷恩—"

    jump foundthebros


label fawnroutefindcyne:
    translate None fawn_chapter2_0193:
        "去找赛恩…他很聪明，对这种事很在行…他肯定能帮忙。"
    translate None fawn_chapter2_0194:
        "我得先找到他。"


    window hide dissolve
    scene bg sc day with dissolve
    window show dissolve
    translate None fawn_chapter2_0195:
        "在酒店大厅遍寻不着后，我走到锡德卡汉的冰天雪地中。"
    translate None fawn_chapter2_0196:
        "还是不见赛恩踪影。我垂头丧气地独自走着，陷入沉思。"


    show raen nw cloak sad at slightleft
    show cyne nw cloak sur at slightright
    with dissolve
    translate None fawn_chapter2_0197:
        c "哎呀这不是咱们雷恩吗？小可爱怎么愁眉苦脸的？"
    translate None fawn_chapter2_0198:
        show raen nw sur with dis
        rs "赛恩…我正找你呢。"
    translate None fawn_chapter2_0199:
        show cyne nw smi with dis
        c "天呐，终于到这天了？你是来向我表白永恒爱意的？"
    translate None fawn_chapter2_0200:
        show cyne nw sur blush with dis
        c "我还没准备好呢雷恩。让我先做个心理准备。"
    translate None fawn_chapter2_0201:
        show raen nw neu with dis
        rs "....."
    translate None fawn_chapter2_0202:
        show cyne nw neu -blush with dis
        c "才—不—是。让我猜，福恩的事？"
    translate None fawn_chapter2_0203:
        show raen nw sur with dis
        rs "这么明显吗？"
    translate None fawn_chapter2_0204:
        show cyne nw neu with dis
        c "明显得很。说说怎么回事。"
    translate None fawn_chapter2_0205:
        "我慢慢讲述了前一晚和福恩的遭遇。赛恩全程神情专注地听着，一次都没打断。"
    translate None fawn_chapter2_0206:
        "这可不像他。"
    translate None fawn_chapter2_0207:
        show cyne nw sur with dis
        c "哇哦，我现在是真吃惊了。他不是喜欢你喜欢到想杀我吗？"
    translate None fawn_chapter2_0208:
        rs "什么…？我觉得这两件事没关系…"
    translate None fawn_chapter2_0209:
        c "绝对有关系。嗯…他拒绝你一定有原因。有些事我们没察觉到…"
    translate None fawn_chapter2_0210:
        show raen nw sur with dis
        rs "等一下…看那边！"
    translate None fawn_chapter2_0211:
        "我指向远处，看见两个蓝发人并肩走着。那绝对是福恩和他妹妹。"
    translate None fawn_chapter2_0212:
        rs "那是…那是福恩和安妮！"
    translate None fawn_chapter2_0213:
        show cyne nw sur with dis
        c "安妮？他有什么秘密女友？"
    translate None fawn_chapter2_0214:
        rs "…不是，是他妹妹。我们昨天遇见过她。"
    translate None fawn_chapter2_0215:
        c "哦~哦~"
    translate None fawn_chapter2_0216:
        show cyne nw neu with dis
        c "这很可疑啊。"
    translate None fawn_chapter2_0217:
        rs "怎么说？"
    translate None fawn_chapter2_0218:
        c "你真不觉得蹊跷？他明显是离家出走，和家人关系不好。从来不愿谈过去。"
    translate None fawn_chapter2_0219:
        c "所以…他妹妹想干什么？"
    translate None fawn_chapter2_0220:
        rs "好吧…"
    translate None fawn_chapter2_0221:
        "我越想越觉得心神不宁。"
    translate None fawn_chapter2_0222:
        rs "….我去跟上他们。"
    translate None fawn_chapter2_0223:
        show cyne nw sur with dis
        c "等等，雷恩—"

    jump foundthebros


label foundthebros:

    hide raen
    hide cyne
    hide leos
    with dissolve
    translate None fawn_chapter2_0224:
        "趁他来不及阻止，我穿过人群尾随那两人。靠近时，我听见了他们谈话的只言片语。"


    show fawn nw cloak smi at slightleft
    show ani n neu1 at slightright
    with dissolve
    translate None fawn_chapter2_0225:
        ani "…这些年来你究竟在做什么？你去了哪里？"
    translate None fawn_chapter2_0226:
        "安妮领着福恩拐进附近小巷。距离太远，我听不清福恩的回答。"
    translate None fawn_chapter2_0227:
        "如同执行潜伏任务般，我躲在墙角偷看。他们站在原地交谈，起初对话和之前并无不同。"
    translate None fawn_chapter2_0228:
        "但突然…"

    show fawn nw neu
    show ani n ang

    with dis
    translate None fawn_chapter2_0229:
        ani "…你为什么要那么做？为什么杀害他们？"
    translate None fawn_chapter2_0230:
        "…？什么？我一定听错了。"
    translate None fawn_chapter2_0231:
        show fawn nw sad with dis
        f ".....!"
    translate None fawn_chapter2_0232:
        f "我…我没有…"
    translate None fawn_chapter2_0233:
        ani "你还是我记忆中的模样…装得安静无辜…你就是个怪物！怪胎！"
    translate None fawn_chapter2_0234:
        f "不…不是的…不是这样…这不是真的！"
    translate None fawn_chapter2_0235:
        ani "他们再也不会等你回家了…"
    translate None fawn_chapter2_0236:
        "她从袖中抽出某样东西。那物件在阳光下寒光闪闪。"
    translate None fawn_chapter2_0237:
        rs c wsur "不要！"

    window hide dissolve

    scene gallery_161 with dissolve
    window show dissolve
    translate None fawn_chapter2_0238:
        ani sca "啊—！"
    translate None fawn_chapter2_0239:
        rs c wsur"哇啊！"
    translate None fawn_chapter2_0240:
        f "离我远点！别靠近我！"



    if achievement.has("fawn_fire"):
        pass
    else:
        $ renpy.display_notify("成就解锁：他的真实力量")

    python:
        achievement.grant("fawn_fire")
        achievement.sync()
    translate None fawn_chapter2_0241:
        "烈焰从这对兄妹之间的地面爆燃而起，形成隔绝屏障护住福恩。"
    translate None fawn_chapter2_0242:
        "安妮向后栽倒，刚从衣襟抽出的匕首也脱手飞出。"
    translate None fawn_chapter2_0243:
        "她抬头瞪视着他的眼神充满憎恶，那目光锐利得几乎能割伤人。"
    translate None fawn_chapter2_0244:
        ani "你…你这恶心的恶魔！杀人凶手！"
    translate None fawn_chapter2_0245:
        f "不是真的！那是意外！"
    translate None fawn_chapter2_0246:
        "福恩捂住耳朵声嘶力竭地尖叫，仿佛再也承受不了一字一句。安妮仍跌坐在地，手脚并用地向后躲避逼近的火焰。"
    translate None fawn_chapter2_0247:
        "那火焰…是从…福恩身上…？"
    translate None fawn_chapter2_0248:
        rs "福恩！"
    translate None fawn_chapter2_0249:
        f "...!"
    translate None fawn_chapter2_0250:
        f "…雷恩？"
    translate None fawn_chapter2_0251:
        rs "没事了，我来了。走吧，我们离开这。"
    translate None fawn_chapter2_0252:
        ani "…你眼瞎了吗？！看看他！他是怪物，杀害我父母的凶手！"
    translate None fawn_chapter2_0253:
        rs "…什么？"
    translate None fawn_chapter2_0254:
        f "别…别说了…求你别说了…！"
    translate None fawn_chapter2_0255:
        ani "活活烧死我父亲，逼得我母亲自尽！该死的人明明是他！"
    translate None fawn_chapter2_0256:
        rs "福恩……？"
    translate None fawn_chapter2_0257:
        f "拜托…不是…不是这样的…你要相信我…"
    translate None fawn_chapter2_0258:
        f "如果连你…如果连你都不能接纳我…"

    window hide dissolve

    scene bg sc day
    show raen nw sur at slightleft
    show ani n ang at slightright
    with dissolve
    window show dissolve
    translate None fawn_chapter2_0259:
        $ about_Ani._text = ["安妮是福恩的七姐妹之一。她极度憎恨福恩，并将父母的死归咎于他。"]
        "他原地转身就跑，仿佛逃命一般。我被独自留在他那个{a=set_entry:enc_people->about_Ani}{color=#87CEEB}狡诈的妹妹{/color}{/a}身边。"
    translate None fawn_chapter2_0260:
        "我迅速捡起匕首藏进衣服—没必要让她留着这个武器。"
    translate None fawn_chapter2_0261:
        show raen nw ang with dis
        rs "……你现在感觉好些了吗？让自己心里舒坦些了吗？"
    translate None fawn_chapter2_0262:
        ani "等他的尸体埋进六尺黄土，我自然会好受些。"
    translate None fawn_chapter2_0263:
        rs "..."
    translate None fawn_chapter2_0264:
        rs "永远别再靠近他。"
    translate None fawn_chapter2_0265:
        ani "你算什么身份来对我指手画脚？！他是我哥哥—你不过是个外人。"
    translate None fawn_chapter2_0266:
        show raen nw sad with dis
        rs "...!"
    translate None fawn_chapter2_0267:
        rs "……也许我确实是个外人，但我比你更像他的家人。滚回你那个穷乡僻壤去，别再出现在这里。"


    hide raen
    hide ani
    with dissolve
    translate None fawn_chapter2_0268:
        "丢下安妮，我跳过渐弱的火焰追赶福恩。起初根本看不见他的踪影。"
    translate None fawn_chapter2_0269:
        "我在附近搜寻，穿梭于小巷窄道，最终又绕回开始搜寻的地方。"
    translate None fawn_chapter2_0270:
        stop music fadeout 2.0
        "蜷缩在角落抱着膝盖的，是个正在发抖的蓝发少年。我刚伸手触碰，他就猛地躲闪，随即抬起泪眼望着我。"


    show raen nw cloak sur at slightleft
    show fawn nw cloak sad at slightright
    with dissolve
    translate None fawn_chapter2_0271:
        f "别过来！我不想连你也伤害……"
    translate None fawn_chapter2_0272:
        play music "sounds/bgm/forgotten off.ogg" fadein 3.0
        rs "……我知道你永远不会伤害我。来，站起来。"
    translate None fawn_chapter2_0273:
        "我再次向他伸出手。他看看我的手，又看看我的脸，迟疑不决。"
    translate None fawn_chapter2_0274:
        f "为什么你…听了她那些话之后，为什么还来找我…"
    translate None fawn_chapter2_0275:
        show raen nw neu with dis
        rs "因为我信任你。"
    translate None fawn_chapter2_0276:
        f "...!"
    translate None fawn_chapter2_0277:
        "他试探性地轻轻握住我的手，仿佛认定我随时会抽回。然而我反而紧紧抓住，把他拉起来与我们平视。"
    translate None fawn_chapter2_0278:
        "他抽回手低头看着地面。"
    translate None fawn_chapter2_0279:
        f "……别碰我。"
    translate None fawn_chapter2_0280:
        show raen nw sad with dis
        rs "没关系的。我不怕你—一切都会好起来的。"
    translate None fawn_chapter2_0281:
        f "才不好！她说的每句话都是真的。我是…我是个怪物，杀人犯…我根本不配活着…"
    translate None fawn_chapter2_0282:
        f "……这是对我的惩罚。我本就不该来这里，不该妄想能有未来…更不该享受和你同行的时光…"
    translate None fawn_chapter2_0283:
        f "这些都不该属于我…"
    translate None fawn_chapter2_0284:
        rs "你既不是怪物也不是杀人犯。"
    translate None fawn_chapter2_0285:
        f "你不会懂的…"
    translate None fawn_chapter2_0286:
        show raen nw sad with dis
        "他突然崩溃大哭，拒绝任何安慰的尝试。一时间我只能看着，无力感席卷全身。"
    translate None fawn_chapter2_0287:
        "最后他止住了哭泣，但只剩下一种我难以形容的空洞。"
    translate None fawn_chapter2_0288:
        "我慢慢靠近，最终张开双臂紧紧抱住他。他用力抓住我，把头靠在我肩上。"
    translate None fawn_chapter2_0289:
        rs "一切都会好起来的。"
    translate None fawn_chapter2_0290:
        rs "你不是怪物。你是我信任的福恩…也是我爱的人。"
    translate None fawn_chapter2_0291:
        f "你应该找别人，找个真正值得爱的人…我都不知道自己还算不算人。"
    translate None fawn_chapter2_0292:
        show raen nw neu with dis
        rs "没有什么能让我那样想你。无论发生了什么。"
    translate None fawn_chapter2_0293:
        "他把我搂得更紧，脸更深地埋进我肩头。"
    translate None fawn_chapter2_0294:
        show fawn nw sad blush with dis
        f "…我也爱你。"
    translate None fawn_chapter2_0295:
        f "从第一次见面，我就知道你很特别…但…从没想过你也会喜欢我。"
    translate None fawn_chapter2_0296:
        show raen nw sur blush with dis
        rs "…真的吗？你喜欢我？"
    translate None fawn_chapter2_0297:
        f "嗯…"
    translate None fawn_chapter2_0298:
        show raen nw smi with dis
        rs "…谢谢。我是真心的。我保证会照顾好你。"
    translate None fawn_chapter2_0299:
        rs "你不必告诉我发生了什么，我也不会问…但只要你准备好了，我随时倾听。"
    translate None fawn_chapter2_0300:
        f "好吧…"
    translate None fawn_chapter2_0301:
        "我松开福恩看着他。他看起来绝对称不上开心，但似乎比刚才明亮了些，恢复了一点生气。"
    translate None fawn_chapter2_0302:
        show raen nw neu with dis
        rs "我们先把赛恩和莱奥斯找来，再去找卡斯皮安？"
    translate None fawn_chapter2_0303:
        rs "要不你留在房间休息？我不想勉强你。"
    translate None fawn_chapter2_0304:
        f "不…这对你很重要。我想一起去。"
    translate None fawn_chapter2_0305:
        rs "…走吧。我们一起去。"
    translate None fawn_chapter2_0306:
        "我轻轻握住他的手，一起走回银柳。"

    window hide dissolve

    scene bg sc day with Fade(1.0, 1.0, 1.0):
        xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.29
        linear 11.0 xpos 0.5 ypos 1.28 xanchor 0.5 yanchor 1.0 zoom 1.29
    window show dissolve

    translate None fawn_chapter2_0307:
        "蓝发女子瘫倒在地，四周是焦痕。她哀求着，泪水却止不住。"
    translate None fawn_chapter2_0308:
        "她捶打地面，愤怒与悲伤交织，充斥脑海。"
    translate None fawn_chapter2_0309:
        ani ang "该死…一切都该死！"
    translate None fawn_chapter2_0310:
        lucu smi "…可怜的女孩再次被兄长抛弃，孤身一人。"
    translate None fawn_chapter2_0311:
        ani "…谁在那里？！"
    translate None fawn_chapter2_0312:
        lucu "你想复仇对吗？像饥饿的野兽般渴望。我来实现它。"
    translate None fawn_chapter2_0313:
        stop music fadeout 2.0
        ani "....."



    window hide dissolve
    scene bg sw day with dissolve
    window show dissolve
    translate None fawn_chapter2_0314:
        "当我们穿过大门时，我低头看向我和福恩相牵的手。"
    translate None fawn_chapter2_0315:
        play music "sounds/bgm/night.ogg" fadein 3.0
        "我本以为他会抽手躲开其他人，但他却紧紧握着。"
    translate None fawn_chapter2_0316:
        "莱奥斯和赛恩正坐在大厅里。一如既往地，赛恩正竭尽全力地惹恼并羞辱莱奥斯。"
    translate None fawn_chapter2_0317:
        "他看上去还一副洋洋得意的样子。"
    translate None fawn_chapter2_0318:
        show raen nw sur at cenleft
        show fawn nw sad at farleft
        show leos nw emb blush at farright
        show cyne nw smi at cenright
        with dissolve
        rs "嘿，伙计们！"
    translate None fawn_chapter2_0319:
        "两人低头看了看我们紧扣的双手，然后又继续争吵起来。看来他们不太在意。"
    translate None fawn_chapter2_0320:
        show cyne nw smi with dis
        c "约会终于回来了？"
    translate None fawn_chapter2_0321:
        rs "…没错。长话短说，是时候去找卡斯皮安了。我知道他在哪。"
    translate None fawn_chapter2_0322:
        l "那我们还等什么？带路吧。"
    translate None fawn_chapter2_0323:
        l "哦，尽量别让我们迷路。"
    translate None fawn_chapter2_0324:
        rs "好啦好啦，我会尽力的。"


    window hide dissolve
    scene bg sc day with dissolve
    window show dissolve
    translate None fawn_chapter2_0325:
        "我走得越远，脚步就越快。能听见自己的心跳在耳畔轰鸣，呼吸都哽在喉咙里。"
    translate None fawn_chapter2_0326:
        "很近了…就快到了！"
    translate None fawn_chapter2_0327:
        "其他人跟在我身后闲聊，除了福恩。他静静地走在我身边。"
    translate None fawn_chapter2_0328:
        show raen nw neu cloak at cenleft
        show fawn nw neu cloak at farleft
        show leos nw neu cloak at farright
        show cyne nw neu cloak at cenright
        with dissolve
        c "对了—怕你忘了，那个庆典稍后也要开始了。我刚才看到他们在布置。"
    translate None fawn_chapter2_0329:
        c "就算你在这儿找到了卡斯皮安，说不定也能玩得开心点。"
    translate None fawn_chapter2_0330:
        l "我宁愿跳崖也不想和你去。"
    translate None fawn_chapter2_0331:
        show cyne nw smi with dis
        c "哎呀呀，莱奥斯你太贴心了。我正想着也是时候带你去见我父母了呢。"
    translate None fawn_chapter2_0332:
        show leos nw ann with dis
        l "恶心。我才不想见他们。"
    translate None fawn_chapter2_0333:
        show cyne nw neu with dis
        c "....."
    translate None fawn_chapter2_0334:
        c "…啊哈哈…也许这是个明智的选择。"
    translate None fawn_chapter2_0335:
        "街道越来越安静，直到我们来到镇上与众不同的区域。这里更狭小简陋，几乎让我想起家乡。"
    translate None fawn_chapter2_0336:
        hide raen
        hide leos
        hide fawn
        hide cyne
        with dissolve
        "我们分头搜查附近的店铺。"
    translate None fawn_chapter2_0337:
        "不对，不是这家…这家也不是。"
    translate None fawn_chapter2_0338:
        "一块悬吊的招牌映入眼帘，在微风中轻轻摇晃，上面绘着月轮与日轮交叠的图案。"
    translate None fawn_chapter2_0339:
        "月蚀\"。"
    translate None fawn_chapter2_0340:
        rs c wsur "就是这里…"
    translate None fawn_chapter2_0341:
        "当我推开门时，其他人也重新聚集到我身边。"

    window hide dissolve


    jump meetcaspian



label aftercaspianfawn:

    window hide dissolve
    scene bg sc sunset with dissolve
    window show dissolve
    translate None fawn_chapter2_0342:
        "其他人可能在跟我说话，但我没注意。我完全沉浸在自己的思绪里，权衡着我的选择。"
    translate None fawn_chapter2_0343:
        play music "sounds/bgm/sad.ogg" fadein 3.0
        "我该怎么办？什么是正确的选择？"
    translate None fawn_chapter2_0344:
        "我究竟…究竟该成为怎样的人？"
    translate None fawn_chapter2_0345:
        "一直以来我都以为自己在对抗命运，想证明即便背负着像我这样的审判也能有所作为。"
    translate None fawn_chapter2_0346:
        "……但看来我只是在逃避而已。我和其他人并无不同。"
    translate None fawn_chapter2_0347:
        show raen nw sad sunset cloak at cenleft
        show fawn nw sad sunset cloak at farleft
        show leos nw thi sunset cloak at farright
        show cyne nw sur sunset cloak at cenright
        with dissolve
        c "雷—恩？雷恩，你在里面吗？"
    translate None fawn_chapter2_0348:
        rs "嗯？！"
    translate None fawn_chapter2_0349:
        l "再这样心不在焉会撞到人的，谁都知道你最怕和人有肢体接触。"
    translate None fawn_chapter2_0350:
        rs "....."
    translate None fawn_chapter2_0351:
        c "嘿，我知道怎么活跃气氛了。要不要去看看庆典活动？"
    translate None fawn_chapter2_0352:
        show raen nw sad with dis
        rs "唔……"
    translate None fawn_chapter2_0353:
        "我其实不太想去，但也不想扫大家的兴…"
    translate None fawn_chapter2_0354:
        rs "也许就待一小会儿吧。"
    translate None fawn_chapter2_0355:
        show cyne nw hap with dis
        c "太好啦！来来来，快跟我走！"
    translate None fawn_chapter2_0356:
        "我看得出赛恩是想逗我开心。他的笑容并未抵达眼底。"
    translate None fawn_chapter2_0357:
        "他拽住莱奥斯的手臂开始往前拖。奇怪的是这次莱奥斯居然没有反驳。"
    translate None fawn_chapter2_0358:
        show fawn nw smi with dis
        "我回头看向福恩。对我们俩来说今天都很难熬，但他依然对我露出了微笑。"
    translate None fawn_chapter2_0359:
        show raen nw smi with dis
        "我也该这样。"
    translate None fawn_chapter2_0360:
        stop music fadeout 2.0
        rs "一起走吧？"


    hide fawn
    hide leos
    hide raen
    hide cyne
    with dissolve
    translate None fawn_chapter2_0361:
        "他上前握住我的手，我们跟上了前面两人。"

    play music "sounds/bgm/night.ogg" fadein 2.0

    scene bg sc night with dissolve:
        xpos 0.36 ypos 1.28 xanchor 0.5 yanchor 1.0 zoom 1.28
    translate None fawn_chapter2_0362:
        "庆典上挤满了各行各业的人，在这个夜晚共同享受欢乐与盛宴。"
    translate None fawn_chapter2_0363:
        "气氛温暖而振奋。比那场舞会好多了。"
    translate None fawn_chapter2_0364:
        "但…我仍感到格格不入。我不属于这里。"
    translate None fawn_chapter2_0365:
        "唯一的慰藉是福恩—我们相牵的触感让我脚踏实地，不至于随时会坠入深渊。"
    translate None fawn_chapter2_0366:
        c c wsmi "嘿，嘿，雷恩！"
    translate None fawn_chapter2_0367:
        rs c wsur"...?"
    translate None fawn_chapter2_0368:
        "他把面具往脸上一扣，突然跳到莱奥斯面前。受惊的莱奥斯打掉了面具，踉跄着后退。"
    translate None fawn_chapter2_0369:
        l c wann "……别闹了。"
    translate None fawn_chapter2_0370:
        c c whap "你来阻止我啊。"
    translate None fawn_chapter2_0371:
        "赛恩努力活跃着气氛。连莱奥斯也是。"
    translate None fawn_chapter2_0372:
        "但这远远不够。我的思绪不断飘回卡斯皮安和说书人那里。"
    translate None fawn_chapter2_0373:
        "至少看起来莱奥斯和赛恩关系更近了。好像达成了某种默契。"
    translate None fawn_chapter2_0374:
        f c wneu "……你还好吗？"
    translate None fawn_chapter2_0375:
        "我摇了摇头。"
    translate None fawn_chapter2_0376:
        rs c wsad "不太好吧。"
    translate None fawn_chapter2_0377:
        f c wsad "想聊聊吗？"
    translate None fawn_chapter2_0378:
        rs "……嗯。"
    translate None fawn_chapter2_0379:
        "我向赛恩挥手示意，指了指福恩。他了然地竖起拇指，拽着莱奥斯胳膊挤进了人群。"
    translate None fawn_chapter2_0380:
        "……抱歉，莱奥斯。你又一次为团队做出了牺牲。"
    translate None fawn_chapter2_0381:
        "福恩牵着我挤出兴奋的人群，来到安静处，他的手紧紧攥着我的。"
    translate None fawn_chapter2_0382:
        "我们在喷泉边坐下，远处是庆典的灯火。"
    translate None fawn_chapter2_0383:
        show raen mw dark sad cloak at mleft
        show fawn mw dark sad cloak at mright
        with dissolve
        f "要面对的事情太多了，对吧？"
    translate None fawn_chapter2_0384:
        rs "是啊……我该从何说起呢……"
    translate None fawn_chapter2_0385:
        rs "我……本应成为下一任说书人。要不是卡斯—"
    translate None fawn_chapter2_0386:
        rs "不，要不是我父亲和言者闹翻的话。"
    translate None fawn_chapter2_0387:
        rs "我本该在城堡长大，接受那种对我来说……不可思议的训练。"
    translate None fawn_chapter2_0388:
        f "……你想要那样的生活吗？"
    translate None fawn_chapter2_0389:
        rs "这个嘛…应该不想。我不会用现有的一切去交换。我的家人，我遇见的所有人…不，我一点也不想改变。"
    translate None fawn_chapter2_0390:
        rs "可现在怎么办？回到奥雷利亚卡维拉继承言者之位？那样就再也见不到其他人了。"
    translate None fawn_chapter2_0391:
        rs "还是留在锡德卡汉，假装家乡的人们没有在受苦？"
    translate None fawn_chapter2_0392:
        f "我不知道。两个选择都有缺憾。"
    translate None fawn_chapter2_0393:
        rs "所以没有正确选择…我到底有没有选择权？"
    translate None fawn_chapter2_0394:
        rs "原以为在反抗命运，其实始终被命运摆布。"
    translate None fawn_chapter2_0395:
        show fawn mw dark neu with dis
        f "无论你作何选择，去向何方…我都会百分之百支持你。"
    translate None fawn_chapter2_0396:
        show raen mw smi with dis
        rs "那任何决定就都没关系了。只要我们在一起。"
    translate None fawn_chapter2_0397:
        show raen mw sad with dis
        rs "我很害怕。"
    translate None fawn_chapter2_0398:
        f "我也是。"
    translate None fawn_chapter2_0399:
        f "....."
    translate None fawn_chapter2_0400:
        show fawn mw smi with dis
        f "看那些星星。让我想起我们相遇那天。"
    translate None fawn_chapter2_0401:
        f "肩并肩望着湖泊。现在回想真是单纯的时光。"
    translate None fawn_chapter2_0402:
        show fawn mw sad with dis
        f "想告诉你我的过去，如果你愿意听。"
    translate None fawn_chapter2_0403:
        "我望着他的眼睛。低垂但坚定。"
    translate None fawn_chapter2_0404:
        stop music fadeout 2.0
        f "那是我小时候的事……"

    window hide dissolve

    scene bg cliffspire with Fade(1.0, 1.0, 1.0)
    window show dissolve

    show fawny n neu1 with dissolve
    play music "sounds/bgm/Discovery.ogg" fadein 2.0
    translate None fawn_chapter2_0405:
        "那天克利夫斯派尔如常运转。农夫耕作，新鲜面包的香气从各家飘出，孩子们无忧无虑地满街奔跑。"
    translate None fawn_chapter2_0406:
        "蓝发小男孩抱着满臂蔬菜跑过昏昏欲睡的镇子。拐过街角，钻进小巷，冲进一栋茅草小屋。"
    translate None fawn_chapter2_0407:
        "房子虽不起眼，却是孩子的天堂。温暖的床铺，慈爱的家人—十岁孩童还能奢求什么？"
    translate None fawn_chapter2_0408:
        "他路过几个姐姐的身边—他有七个姐姐，所以很难不碰见至少一个。"
    translate None fawn_chapter2_0409:
        "作为最小的孩子，男孩早已习惯了被姐姐们扯来扯去，但他很享受这样的互动。"
    translate None fawn_chapter2_0410:
        "她们是他的整个世界，而他也是她们的。他与安妮特别亲近，她只比他大一岁。"
    translate None fawn_chapter2_0411:
        mot "阿登，是你吗？"
    translate None fawn_chapter2_0412:
        show fawny n hap1 with dis
        f "我把蔬菜带回来了！奶奶说她晚点也会多带些过来。"
    translate None fawn_chapter2_0413:
        "女人俯身揉了揉孩子的头发。他咧嘴笑了作为回应。当然，他爱家里的每个人，但母亲对他而言意味着整个世界。"
    translate None fawn_chapter2_0414:
        "她强壮能干，温柔慈爱。"
    translate None fawn_chapter2_0415:
        show fawny n hap2 with dis
        mot "让我们向维拉斯祈祷下次收成和这次一样丰饶。我要开始做饭了，你出去玩吧。"
    translate None fawn_chapter2_0416:
        "他摇摇头。他更愿意留在这里帮忙。母亲笑了，两人并肩站着准备蔬菜。"
    translate None fawn_chapter2_0417:
        stop music fadeout 2.0
        "这一天原本和克利夫斯派尔的任何日子没什么两样，直到变故发生。"


    scene black with dissolve
    translate None fawn_chapter2_0418:
        "当他终于把头靠在枕头上准备入睡，母亲亲吻道过晚安后，一切突然改变了。"
    translate None fawn_chapter2_0419:
        "在即将入睡之际，他做了个离奇的梦。充斥着痛苦与烈火，还有皮肉烧焦的气味。"
    translate None fawn_chapter2_0420:
        "但他没有醒来。仿佛有什么东西把他拽进梦中不愿松手。"
    translate None fawn_chapter2_0421:
        "他猛然睁眼，正好看见一只手伸下来强行把他拖下床。"
    translate None fawn_chapter2_0422:
        play music "sounds/bgm/Scary.ogg" fadein 3.0
        man "滚下床去，恶魔崽子！"
    translate None fawn_chapter2_0423:
        fchild sca "嗯…？"
    translate None fawn_chapter2_0424:
        wom "别靠太近，他也会杀了你的！"
    translate None fawn_chapter2_0425:
        fchild "什么…？"
    translate None fawn_chapter2_0426:
        "那天清晨他第一次环顾四周。他的房间完好无损—姐姐们仍在床上安睡。"
    translate None fawn_chapter2_0427:
        "甚至没给他自己站起来的机会，他就被拖出房间来到街上。他抬头看着抓住他的男人—那张面孔十分陌生。"
    translate None fawn_chapter2_0428:
        "当阿登凑近看时，他明白了原因。那人满身黑色烟灰，手臂上都是烧伤痕迹。"
    translate None fawn_chapter2_0429:
        "这时他才注意到。房子的其他部分看起来不对劲。"


    window hide dissolve
    scene bg cliffspire fire with dissolve:
        xpos 0.7 ypos 1.41 xanchor 0.5 yanchor 1.0 zoom 1.43
        linear 26.0 xpos 0.33 ypos 1.41 xanchor 0.5 yanchor 1.0 zoom 1.43
    window show dissolve
    translate None fawn_chapter2_0430:
        "而且不仅是他家。邻居们，周围的建筑都是。"
    translate None fawn_chapter2_0431:
        "有些还燃烧着烈焰，有些已成焦黑残骸。家人们抱在一起哭泣哀嚎。"
    translate None fawn_chapter2_0432:
        "他被摔倒在地，遭受着踢踹与踩踏。他哭喊着哀求他们住手。"
    translate None fawn_chapter2_0433: # MISSING LINE
        scene bg cliffspire fire
        show fawny n tea
        with dissolve
        f "住手，求求你们！我不明白—我不明白，发生了什么？！"
    translate None fawn_chapter2_0434:
        wom "恶魔崽子！你杀了他们所有人！你把他们都活活烧死了！"
    translate None fawn_chapter2_0435:
        man "那些火焰全都指向你！你这该死的、邪恶的孩子…你策划这一切多久了？！"
    translate None fawn_chapter2_0436:
        wom "甚至丧心病狂到杀害自己的父亲…"
    translate None fawn_chapter2_0437:
        "男孩在挨打间隙拼命在人群中寻找家人。他在人群中瞥见几抹蓝色，但没人来救他。"
    translate None fawn_chapter2_0438:
        "他朝那个方向伸出手，终于看见了母亲。"
    translate None fawn_chapter2_0439:
        "她面容扭曲，双眼红肿。当他们的目光终于交汇时，她脸上浮现惊恐的神色，随即瘫坐在地痛哭。"
    translate None fawn_chapter2_0440:
        f "妈…妈妈，求求你…"
    translate None fawn_chapter2_0441:
        show fawny n cry with dis
        f "我…我没有做…不是我干的…！"
    translate None fawn_chapter2_0442:
        show black with hpunch
        "不知何时昏了过去，又在滂沱大雨拍打全身的触感中醒来。他浑身湿透，遍体鳞伤布满血迹。"
    translate None fawn_chapter2_0443:
        "阿登挣扎着跪起身来。这不是梦。周围的房屋已不能称之为房屋，几乎什么都没剩下。"
    translate None fawn_chapter2_0444:
        "没有人聚集在他身边。"
    translate None fawn_chapter2_0445:
        "当他站起时，不确定断了多少根骨头—但能清晰感受到身体的异样。疼痛感前所未有。"
    translate None fawn_chapter2_0446:
        "他拖着身子走向最近那栋完好的屋子。有灯光从里面透出，他躲在墙角窥探。屋内传出对话声。"
    translate None fawn_chapter2_0447:
        wom "…我们该怎么处置他？！已经触怒了恶魔—他不会让我们活命的。"
    translate None fawn_chapter2_0448:
        man "…他们找到了他母亲的尸体。那些可怜的女孩现在成孤儿了。"
    translate None fawn_chapter2_0449:
        wom "要我说一报还一报—把他绑在火刑柱上烧死。"
    translate None fawn_chapter2_0450:
        f "...!"
    translate None fawn_chapter2_0451:
        man "那是什么声音？"
    translate None fawn_chapter2_0452:
        fmn "不..不是的，不是故意的…不是我！我…我不是恶魔！"
    translate None fawn_chapter2_0453:
        "他退出门口逃跑了。起初沿着主街跑，但越跑越害怕。"
    translate None fawn_chapter2_0454:
        "谁都有可能追上来。"
    translate None fawn_chapter2_0455:
        "目光转向森林。长久以来听过无数关于林间邪物的传说—这让他恐惧，但…"
    translate None fawn_chapter2_0456:
        "他暗自想着或许那里才是自己的归处。"

    window hide dissolve

    scene bg forestnight with dissolve
    window show dissolve

    show fawny n dark cry with dissolve
    translate None fawn_chapter2_0457:
        "突然改变路线冲进被夜幕笼罩的幽暗森林。"
    translate None fawn_chapter2_0458:
        "骨头剧痛难忍，呼吸噎在喉头。"
    translate None fawn_chapter2_0459:
        "他没有一刻停止哭泣。为他的母亲与父亲，为他的姐妹们。为他的村庄。最后，为自己。"
    translate None fawn_chapter2_0460:
        "在某个时刻，他陷入深度睡眠，因精疲力竭而倒地，浑身都疼痛不已。每个部位都因痛苦而灼烧，但他沉醉于这种感受。"
    translate None fawn_chapter2_0461:
        "毕竟，这是他应得的。"
    translate None fawn_chapter2_0462:
        "当他再次睁开双眼，他迷失在一片树海中—远离人群，深陷密林之内。"
    translate None fawn_chapter2_0463:
        show fawny n dark tea with dis
        "几束零散光线从树冠间泻下，在他周身洒落。"
    translate None fawn_chapter2_0464:
        "他用朦胧泪眼呆住了。有什么东西正在他面前移动。"
    translate None fawn_chapter2_0465:
        "他眨眨眼，周围的世界终于变得清晰起来。"
    translate None fawn_chapter2_0466:
        "一只鹿…不，是幼鹿，娇小而纯真，蜷缩成团待在几步之外。他悄声靠近，小心翼翼地生怕惊走它。"
    translate None fawn_chapter2_0467:
        "幼鹿用又大又圆的眼睛注视着阿登，却没有要离开的意思。他一点一点地接近，直到最终伸手触摸它。"
    translate None fawn_chapter2_0468: # MISSING LINE
        show fawny n dark sad with dis
        f "你的妈妈在哪里呢，小鹿？"
    translate None fawn_chapter2_0469:
        $ about_Fawn._text = ["福恩出生在一个名叫克利夫斯派尔的小村庄。他在一个大家庭中长大，家庭成员包括他（名叫阿登）、他的父母和七个姐妹。总的来说，他会说意外发生前的回忆是幸福的，他从不会奢求更多。\n \n十岁那年，灾难降临。福恩醒来时正被人从烧焦的家中拖出，扔进泥里。他记得他们的叫嚷，他们的尖叫，他们的哭喊…还有那些手指，全都指向他。整个镇子陷入火海，而所有线索都指向安然睡在床上的他。"]
        $ about_Fawn._text.append("随着父亲死去，母亲不久也撒手人寰，留下兄弟姐妹自谋生路。镇民们商讨如何处理这个恶魔—最终得出结论必须以牙还牙。\n \n听到他们的计划，福恩立即逃进了森林，拼尽全力奔跑。在那里，他起了新名字隐藏起来，直到一次偶然相遇使他重新回到人群视线中。")
        "它孤零零的，就像{a=set_entry:enc_people->about_Fawn}{color=#87CEEB}阿登{/color}{/a}一样。"
    translate None fawn_chapter2_0470:
        "当他看着那只幼鹿时，他看到了自己的影子。迷茫而孤独。"


    if achievement.has("fawn_name"):
        pass
    else:
        $ renpy.display_notify("成就已解锁：名字意味着什么？")

    python:
        achievement.grant("fawn_name")
        achievement.sync()
    translate None fawn_chapter2_0471:
        "他与那只小兽并肩而立，仰望着天空，梦想着一个永远不会属于他的未来。"


    window hide dissolve


    scene bg sc night
    show raen mw dark cloak sad at mleft
    show fawn mw dark cloak sad at mright
    with Fade(1.0, 1.0, 1.0)
    window show dissolve
    translate None fawn_chapter2_0472:
        f "…我想你知道故事的后续。我抛弃了旧名，在森林中度过了十年，直到我们相遇。"
    translate None fawn_chapter2_0473:
        rs "....."
    translate None fawn_chapter2_0474:
        "当福恩分享那样的故事时…我怎么还能坐在这里抱怨自己被好运眷顾？"
    translate None fawn_chapter2_0475:
        f "我不知道自己怎么了。我不明白那晚发生了什么。"
    translate None fawn_chapter2_0476:
        show raen mw neu with dis
        rs "…那是个意外。你不能为此责怪自己。"
    translate None fawn_chapter2_0477:
        f "....."
    translate None fawn_chapter2_0478:
        rs "你的…你的能力之所以可怕，是因为你不理解它们。"
    translate None fawn_chapter2_0479:
        f "…而我永远也不会理解。我只能接受我就是他们所说的那样—一个恶魔。"
    translate None fawn_chapter2_0480:
        rs "你知道的，我会帮你。学习控制它。"
    translate None fawn_chapter2_0481:
        f "你连自己的能力都掌控不了，如果我伤害了你，我永远不会原谅自己。"
    translate None fawn_chapter2_0482:
        show raen mw sad with dis
        rs "你…说得对。"
    translate None fawn_chapter2_0483:
        f "抱歉…你现在正背负着自己的烦恼，我不该再加上我的。"
    translate None fawn_chapter2_0484:
        "我俯身握紧了他的手。"
    translate None fawn_chapter2_0485:
        rs "在所有事情上你都陪伴着我。我也会一直在你身边倾听，好吗？而且，你已经帮了很多忙。"
    translate None fawn_chapter2_0486:
        rs "要回去吗？"
    translate None fawn_chapter2_0487:
        show fawn mw neu with dis
        f "嗯。"
    translate None fawn_chapter2_0488:
        hide fawn
        hide raen
        with dissolve
        "我确定赛恩和莱奥斯会没事的—他们能互相作伴。反正我也没有庆祝的心情。"
    translate None fawn_chapter2_0489:
        stop music fadeout 2.0
        "离庆祝活动越远，我就感觉越自在。远处隐约传来音乐声，雪花在我们周围飘落。"
    translate None fawn_chapter2_0490:
        play music "sounds/bgm/night.ogg" fadein 2.0
        "这里是…如此宁静。只有我们两人，手牵着手在雪中跋涉。"
    translate None fawn_chapter2_0491:
        "我收紧握着他的手，他也回握了我的手。"
    translate None fawn_chapter2_0492:
        "我并不孤单。"


    window hide dissolve
    scene bg sw night with dissolve
    window show dissolve
    translate None fawn_chapter2_0493:
        "银柳的门廊死一般寂静。大家一定都出去庆祝了。"
    translate None fawn_chapter2_0494:
        "当我们走向房间时，脚步声在地板上回荡。当我试图松开福恩的手去开门时，他却握得更紧了。"
    translate None fawn_chapter2_0495:
        f c wemb "....."
    translate None fawn_chapter2_0496:
        f "雷…雷恩…"
    translate None fawn_chapter2_0497:
        rs c wsur "嗯？"
    translate None fawn_chapter2_0498:
        f "我可以…今晚和你一起吗？"
    translate None fawn_chapter2_0499:
        rs c wemb "当…当然可以…你知道我总是欢迎你的。"
    translate None fawn_chapter2_0500:
        "我扶着门，他匆匆从我身边走过。"

    stop music fadeout 2.0

    window hide dissolve
    jump fawnroute3start
