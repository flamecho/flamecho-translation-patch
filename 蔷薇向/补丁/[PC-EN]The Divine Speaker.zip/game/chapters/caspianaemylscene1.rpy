label caspianaemylscene1:
    scene bg eclipse night:
        size (1920, 1080)
    show caspian n dark neu work at slightright
    show ds n dark neu at slightleft
    with Dissolve(1.0)
    window show dissolve
    play music "sounds/bgm/Scary.ogg" fadein 4.0
    translate None caspianaemylscene1_0001:
        cas "…所以你终究还是回来了。是锡德卡汉寒冷的夜晚让你受不了了吗？"
    translate None caspianaemylscene1_0002:
        cas "我已经相当习惯了，不过这气候和奥雷利亚卡维拉确实很不一样。"
    translate None caspianaemylscene1_0003:
        "「蚀」的门轻轻关上，一个银发男人走了进来。他面色阴沉难以捉摸，但显然对不得不回来这件事感到不悦。"
    translate None caspianaemylscene1_0004:
        "他叹了口气，往后靠上墙壁，凝视着眼前的景象。"
    translate None caspianaemylscene1_0005:
        "卡斯皮安，他曾经的爱人如今的敌人，是个木匠。"
    translate None caspianaemylscene1_0006:
        "这位奥雷利亚卡维拉的王子，王位的下一任继承者，整天在做桌子。"
    translate None caspianaemylscene1_0007:
        show ds n dark ann with dis
        ae "…我无处可去了。相信我，但凡有选择，我绝不会靠近这里。"
    translate None caspianaemylscene1_0008:
        "卡斯皮安耸耸肩，试图表现得若无其事。内心却波涛汹涌。站在面前的是他的旧爱—曾经对他最重要的人。即使到了现在，在经历过一切之后，他依然难以自持。"
    translate None caspianaemylscene1_0009:
        "他想要的不过是个重来的机会。或许命运已经给了这个机会，但他明白不该奢望不可能的事。"
    translate None caspianaemylscene1_0010:
        show caspian n dark sad with dis
        cas "…既然你落魄至此，我可以给你些钱去住旅店。"
    translate None caspianaemylscene1_0011:
        ae "...."
    translate None caspianaemylscene1_0012:
        ae "省省吧。就让我一个人待着，回你现在的住处去。"
    translate None caspianaemylscene1_0013:
        cas "至少…能告诉我你这些年的近况吗？"
    translate None caspianaemylscene1_0014:
        ae "我的近况？什么时候？现在？去年？还是更早之前？你何必在乎，多年前是你抛下了我。"
    translate None caspianaemylscene1_0015:
        cas "…我别无选择。你清楚这点。如果我当时留下…"
    translate None caspianaemylscene1_0016:
        "艾米尔脸色一沉。他当然知道。他知道这是自己的错—当初是他赶走了卡斯皮安。"
    translate None caspianaemylscene1_0017:
        "但这并不能减轻他心中的苦涩。"
    translate None caspianaemylscene1_0018:
        ae "我过得怎样与你无关。"
    translate None caspianaemylscene1_0019:
        cas "我想关心你。这个请求很过分吗？就当是为了老朋友。"
    translate None caspianaemylscene1_0020:
        show ds n dark ang with dis
        "听到\"朋友\"这个词，艾米尔明显僵了一下，随即皱起眉头。"
    translate None caspianaemylscene1_0021:
        ae "太迟了。求你走吧。此刻我最不想见的就是你。"
    translate None caspianaemylscene1_0022:
        cas "...."
    translate None caspianaemylscene1_0023:
        cas "我等过你，你知道吗。"
    translate None caspianaemylscene1_0024:
        cas "我在斯塔格威奇等了好几个星期，确信你会来找我，带我回家。希望这一切都只是个梦。"
    translate None caspianaemylscene1_0025:
        cas "…但事实并非如此，我不得不继续前行。"
    translate None caspianaemylscene1_0026:
        "卡斯皮安的手搭在门把手上。这些年来他进出这家店的次数数不胜数，但为什么这次如此艰难？"
    translate None caspianaemylscene1_0027:
        cas "…晚安，艾米尔。"

    stop music fadeout 2.0
    window hide dissolve

    scene black with Dissolve(2.0)
    pause 2.0

    jump morwenscene1
