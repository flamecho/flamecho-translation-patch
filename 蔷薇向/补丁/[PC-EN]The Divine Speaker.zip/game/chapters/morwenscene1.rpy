label morwenscene1:
    scene bg sc mountains with Dissolve(1.0)
    window show dissolve
    play music "sounds/bgm/forgotten.ogg" fadein 4.0
    translate None meetmorwen_scene1_0001:
        "一位白发女子独自站在宁静村庄的中央。她裹紧斗篷，眺望着视野里白雪皑皑的群山。"
    translate None meetmorwen_scene1_0002:
        "带着沉重的心情和混沌的思绪，她迈出了离开村庄的第一步。轻手轻脚，小心翼翼，以免惊动任何村民。"
    translate None meetmorwen_scene1_0003:
        show morwen n dark cloakup neu at slightleft
        show sylvir n dark neu at slightright
        with dissolve
        s "你以为你要去哪儿？"
    translate None meetmorwen_scene1_0004:
        show morwen n dark cloakup wor with dis
        mmn "已经露馅了…."
    translate None meetmorwen_scene1_0005:
        "当她猛地转身看向发现她的人时，发丝在空中翻飞。"
    translate None meetmorwen_scene1_0006:
        show morwen n dark cloakup smi with dis
        mor "……要找到我的孩子们。"
    translate None meetmorwen_scene1_0007:
        show sylvir n dark shy with dis
        s "别犯傻。你的身体需要休息。就在两天前，它还只是具尸体。"
    translate None meetmorwen_scene1_0008:
        show morwen n dark cloakup sad with dis
        mor "我再也受不了整天躺在床上无所事事，等着适应这具身体了。"
    translate None meetmorwen_scene1_0009:
        show sylvir n dark neu with dis
        s "别无选择。我们所有人都必须这么做。你也不例外。"
    translate None meetmorwen_scene1_0010:
        #show morwen n dark cloakup ang with dis
        mor "…不管你说什么，我都要去。想把我锁起来，我就拆墙也要逃出去。我非找到他们不可，哪怕爬着穿过这片雪地，直到要了我的命。"
    translate None meetmorwen_scene1_0011:
        s "看来你是认真的。"
    translate None meetmorwen_scene1_0012:
        "白发女子严厉地盯着对方，点了点头。"
    translate None meetmorwen_scene1_0013:
        s "你这是在让我为难啊，知道吗…埃利奥特让我盯着你的一举一动。"
    translate None meetmorwen_scene1_0014:
        show morwen n dark cloakup sad with dis
        mor "我不信任那个男人。你一定知道他是谁，做过什么。正是他首先导致了诸神的陨落。"
    translate None meetmorwen_scene1_0015:
        mor "我知道那是在你飞升之前发生的事，但对我来说就像昨天刚发生一样清晰。"
    translate None meetmorwen_scene1_0016:
        mor "我的孩子们…如果不是因为他，他们本不该遭受那些强加在他们身上的苦难…" # RETAKE NEEDED
    translate None meetmorwen_scene1_0017:
        show sylvir n dark thi with dis
        s "....."
    translate None meetmorwen_scene1_0018:
        s "如果这对你如此重要…那我会找到他们，确保他们安全抵达此处。"
    translate None meetmorwen_scene1_0019:
        show morwen n dark cloakup sur with dis
        mor "真的吗？"
    translate None meetmorwen_scene1_0020:
        show sylvir n dark smi with dis
        s "这大半夜的可不能让你们在雪地里跋涉。先休息一下，这事就交给我吧。"
    translate None meetmorwen_scene1_0021:
        mmn "我能相信她吗？她真会这么做吗？"
    translate None meetmorwen_scene1_0022:
        mmn "…她救过我的命，所以我欠她的。现在，我会先答应。"
    translate None meetmorwen_scene1_0023:
        show morwen n dark cloakup sad with dis
        mor "谢谢你，西尔维尔。真的、真的太感谢你了。"
    translate None meetmorwen_scene1_0024:
        "两个女人肩并肩走回村庄，轻声交谈着。"

    stop music fadeout 2.0
    window hide dissolve

    scene black with Dissolve(2.0)
    pause 2.0

    if cyne_route:
        jump cyneroute3cont

    if fawn_route:
        jump fawnroute3cont

    if leos_route:
        jump leosroute3cont
