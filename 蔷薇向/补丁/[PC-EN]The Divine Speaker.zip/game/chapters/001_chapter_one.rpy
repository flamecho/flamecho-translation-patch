label chapter_one_start:


    show blackbars
    $ renpy.music.play("sounds/sfx/runningforest.ogg", channel="sfx2", loop=False)

    show bg forestnight behind blackbars with Dissolve(1):
        size (1920, 1080) crop (0, 0, 800, 600) # Sets the initial size for the image
        linear 40.0 crop (800, 0, 800, 600)
    window show dissolve
    translate None chapter_one_01:
        "我奔跑着。从未跑得如此拼命。心脏仿佛下一秒就要从胸口炸开，每次呼吸肺部都火辣辣地疼。"
    translate None chapter_one_02:
        "连不知道自己有的肌肉都在酸痛。即便觉得再也跑不动，我仍在继续。"
    translate None chapter_one_03:
        "当最终瘫倒在地时，四面八方向只有树木与黑暗。我彻底迷失了。"
    translate None chapter_one_04:
        rs hur "呼哧…呼哧…"


    scene bg forestnight with dissolve:
        size (1920, 1080) crop (0, 0, 800, 600)


    translate None chapter_one_05:
        "仰面躺在地上喘息。现在能怎么办？我已一无所有。"
    translate None chapter_one_06:
        "无家可归。没有亲人。孤儿院的大家发现后会怎么想？"
    translate None chapter_one_07:
        "会失望吗？会愤怒吗？"
    translate None chapter_one_08:
        "会觉得我抛弃了他们吗？背叛了他们吗？"
    translate None chapter_one_09:
        "万千思绪顷刻间涌上心头。"
    translate None chapter_one_10:
        "深吸一口林间新鲜空气，我平复心绪。直到此刻才真正意识到处境。"
    play music "sounds/bgm/scary.ogg" fadeout 1
    translate None chapter_one_11:
        "我正孤身一人，在深夜，瘫倒在森林的地面。"
    translate None chapter_one_11a:
        "突然察觉所有先前未留意的声响。抓挠声。灌木沙沙。远方某处的嗥叫。 "
    translate None chapter_one_12:
        "风势渐强，发梢抽打着脸颊，心中刚涌现的恐惧愈发强烈。"
    translate None chapter_one_13:
        "儿时起听过的所有关于离开奥雷利亚卡维拉的警告悉数浮现。事实上，我不只听过这些故事，还曾无数次对孩子们重复。"
    translate None chapter_one_14:
        "没人离开过奥雷利亚卡维拉的疆界。这片蔓延至星球尽头的森林危机四伏，正是依靠上界存在的庇护，我们才得以长治久安。"
    translate None chapter_one_14a:
        "竭力睁大双眼，试图看透周遭的黑暗。"
    translate None chapter_one_15:
        "终于挣扎着从地上爬起。裹紧外套寻求安全感，紧张地确认随身物品完好无损，才转身朝来路折返。"
    translate None chapter_one_16:
        "或许紧挨城市灯光能吓退危险？"
    window hide dissolve

    scene black with dissolve
    pause(1)
    show bg forestnight with dissolve:
        size (1920, 1080) crop (0, 0, 1000, 800) # Sets the initial size for the image
        linear 40.0 crop (400, 400, 800, 600) # Pans to (400, 400) in 30 seconds
        pause 1.0 # Your specified pause...
        linear 30.0 crop (0, 0, 1000, 800) # Pans to x=800 from x=400 in 30 seconds


    window show dissolve
    translate None chapter_one_17:
        rs wor "...."
    translate None chapter_one_18:
        rs "是这边吧…？"
    translate None chapter_one_19:
        rs "还是…这边？"
    translate None chapter_one_20:
        "无论转向哪个方位，树木都毫无二致…每个角度都传来怪异声响。"
    translate None chapter_one_21:
        rs hur "快想…究竟哪条路，哪条路？"
    translate None chapter_one_22:
        "脑袋左摇右摆，最终颓然埋进掌心。不自觉叹出一口气。"
    translate None chapter_one_23:
        rs "彻底没救了。"
    translate None chapter_one_24:
        "再一次，我被森林的声音和未知的感觉所包围。谁能想到会是如此可怕。"
    translate None chapter_one_25:
        "一种怪异的感觉攫住了我的心。我能感觉到有眼睛在盯着我。"
    translate None chapter_one_26:
        rs sad "不……我一定是在胡思乱想……"
    translate None chapter_one_27:
        "突然，一切都静了下来。我只能听见自己的心跳，一秒快过一秒。我必须离开这里。"
    translate None chapter_one_28:
        "失去方向感的我只是跑着。跑直到再也跑不动。"


    scene bg forestnight with Fade(1,1,1)


    translate None chapter_one_29:
        rs wor "呼哧…呼哧…"
    translate None chapter_one_30:
        "无论我走到哪里，景象都一模一样。树木在我眼中开始模糊混合，变成一个整体。"
    $ renpy.music.play("sounds/sfx/fallonground.ogg", channel="sfx1")
    translate None chapter_one_31:
        "我瘫倒在地，向后爬行直到后背撞上一棵树。单是知道背后有东西就让我感到安心些。我把自己埋进它巨大的根系中。"
    translate None chapter_one_31a:
        "在这片漆黑的黑暗中，我几乎看不清面前的手。"
    translate None chapter_one_32:
        "夜晚冰冷刺骨。我将膝盖抱在胸前，紧紧蜷缩试图获取一点温暖。"
    translate None chapter_one_33:
        "我感受到藏在衣服里的那封信。"
    translate None chapter_one_34:
        rs "对不起……"
    translate None chapter_one_35:
        "把信紧攥在胸前，我闭上双眼试图逃离现实的危险。"
    stop music fadeout 3.0

    window hide dissolve
    scene black with eye_shut




    pause(2)
    translate None chapter_one_36:
        n "…..天命之子.."
    translate None chapter_one_36a:
        n "…..虚假预言…"
    translate None chapter_one_37:
        n "…..说吧…醒来…"
    pause(2)




    scene bg forest with eye_open


    window show dissolve
    translate None chapter_one_38:
        rs sur "啊！"
    translate None chapter_one_39:
        "我突然惊醒。"
    translate None chapter_one_40:
        rs "那个梦是怎么回事…？感觉这已经不是第一次了…"
    translate None chapter_one_41:
        "一切都显得朦胧模糊，我几乎想不起梦的内容。"
    translate None chapter_one_42:
        "我从林间地面舒展身体，开始观察四周。"
    translate None chapter_one_43:
        "明亮的阳光从树枝间洒落，给我的脸庞带来些许暖意。经过昨晚的寒风后感觉很舒服。"
    translate None chapter_one_44:
        "空气清新，说明现在应该还很早。"
    translate None chapter_one_45:
        rs "什么…？"
    window hide dissolve




    scene black with dissolve
    show blackbars
    show gallery_9 behind blackbars with fade:
        xpos 0.68 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.49
        linear 15.0 xpos 0.68 ypos 1.32 xanchor 0.5 yanchor 1.0 zoom 1.49



    window show dissolve
    translate None chapter_one_46:
        "当我真正环顾四周时，注意到了奇怪的事。"
    translate None chapter_one_47:
        "我被从未见过的美丽花朵环绕着。"
    play music "sounds/bgm/harp.ogg" fadeout 1
    translate None chapter_one_48:
        rs "这些是什么时候出现的…？"


    hide blackbars with Dissolve(1)


    translate None chapter_one_49:
        "昨晚实在太黑了…它们原先就在这儿吗？可能有，但是…像这样围绕我成一圈不是有点奇怪吗？"
    translate None chapter_one_50:
        "我叹了口气。"
    translate None chapter_one_51:
        rs "呃…为什么总有这些怪事发生在我身上？"
    translate None chapter_one_52:
        "昨天在镇广场上的莫名疼痛，那些只记得只言片语的梦，更不用说手臂上的神之刻印。"


    scene gallery_9 with dissolve


    translate None chapter_one_53:
        "我举起手臂朝向天空，在阳光下仔细检视。我用指尖轻轻描摹那些符号。"
    translate None chapter_one_54:
        rs "这绝对和我带来的书上符号一模一样…它究竟想告诉我什么？"
    translate None chapter_one_55:
        "我漫不经心地拨弄着周围的野花，同时回想着昨天发生的事。"
    translate None chapter_one_56:
        rs "我必须找个能解读这些神之刻印的人…但我不可能再偷偷溜回奥雷利亚卡维拉了…"


    scene gallery_10 with dissolve


    translate None chapter_one_57:
        "我取出书本快速翻阅其他页面。大部分内容都能读懂，但相对不那么重要。图表、清单、预算…"
    translate None chapter_one_58:
        "但这两页…王室血统，还有与我的神之刻印吻合的那一页，都是用未知语言书写的…"
    translate None chapter_one_59:
        "我再次查看家族树。众所周知大约20年前王室突然终结，但原因并未广为人知或公开。"
    translate None chapter_one_60:
        "我又核对了一遍名字。锡德卡汉的希昂国王。这个\"{i}锡德卡汉{/i}\"是什么？为什么血统只追溯到500年前？"
    translate None chapter_one_61:
        "然后是最后的卡斯皮安王子…37年前。下面有个难以辨认的签名—\"卢修斯\"。"
    translate None chapter_one_62:
        rs "他可能还活着…或许能告诉我这些神之刻印的含义..要是我知道他在哪就好了.."
    play sound "sounds/sfx/stomach.ogg" fadeout 1
    translate None chapter_one_63:
        rs "啊…"
    $ renpy.music.play("sounds/sfx/stomach.ogg", channel="sfx1", loop=False)
    translate None chapter_one_64:
        "我突然意识到自己有多饿。上次进食应该还是昨天的事。"


    scene bg forest with Fade(1,0,1)


    window show dissolve
    translate None chapter_one_64a:
        "我试图吞咽，但喉咙干涩发疼。"
    translate None chapter_one_65:
        "渴得要命。我翻遍口袋却找不到任何食物。"
    play sound "sounds/sfx/clothrustle.ogg"
    translate None chapter_one_66:
        "最后我站起身活动肩膀。只要能睡在床上而不是地上，我愿付出任何代价。"
    translate None chapter_one_67:
        "今天的首要任务：找水。"
    translate None chapter_one_68:
        rs sad "当然，说着容易…"
    translate None chapter_one_69:
        "我环顾四周树木，却想不起昨晚从哪个方向来。只能随便选个方向碰运气了。"
    translate None chapter_one_70:
        "拍掉衣服上的尘土，我开始徒步寻找水源。"
    stop music fadeout 2.0
    window hide dissolve

    scene black with w19
    pause(1.0)
    scene bg forest with w19
    window show dissolve

    show raen n neu at center
    show expression AlphaMask("foliage_1", At("雷恩 的 新", center)) as mask
    with dissolve
    translate None chapter_one_71:
        "此刻烈日当空，阳光灿烂。温暖了我冰冷的身体，也平静了心神。"
    translate None chapter_one_72:
        "比起昨夜，这片森林连一半的可怕都没有了。阳光从头顶绿叶间滤下，在地面投映出有趣的斑驳图案。"
    translate None chapter_one_73:
        "潮湿的树干和树根上爬满了青苔，让一切都显得毛茸茸而温暖。我能听到树冠上方传来鸟儿微弱的啁啾声。"
    translate None chapter_one_74:
        "这里非但不恐怖，反而有种奇异的美感。"
    translate None chapter_one_75:
        "唯一能听见的只有自己的呼吸声，以及靴子踩断枯枝的声响。阳光普照时，这里如此宁静，甚至称得上祥和。"
    show raen n hap with dis
    translate None chapter_one_76:
        "不知不觉间，我放慢了脚步，细细欣赏着风景，沉浸在这氛围中。昨晚发生的一切恍如梦境。"
    translate None chapter_one_77:
        "野花星星点点铺满我途经的地面，我尽量避开它们。俯身采了一朵，准备随身带着。"
    translate None chapter_one_78:
        "就这样按自己的节奏走了好一会儿，突然一阵恶臭袭来，瞬间盖过了手中鲜花的芬芳。"
    show raen n sad with dis
    translate None chapter_one_79:
        "那味道像是…腐肉混杂着某种甜得发腻的东西。越往前走，气味越发浓烈。"
    translate None chapter_one_80:
        rs "那是…什么？"
    stop music fadeout 3.0
    translate None chapter_one_81:
        "远处灌木丛下露出一截布料。走得越近，那股气味就越发令人窒息。"
    translate None chapter_one_82:
        "看起来像某种帆布背包。"
    translate None chapter_one_83:
        "里面会有食物吗…？水？或者能用得上的东西？"
    translate None chapter_one_84:
        "我试着把它从灌木丛里拽出来，但似乎被树枝卡住了。双手抓住背包猛力一扯。"
    show raen n wor with dis


    stop music fadeout 3.0
    play sound "sounds/sfx/fleshrip.ogg" fadeout 1
    show raen n wor at shakecen
    show expression AlphaMask("foliage_1", At("雷恩 与 雷德", shakecen)) as mask


    translate None chapter_one_85:
        rs "哇啊！"
    translate None chapter_one_86:
        "全身重量压上去的瞬间背包突然松脱，我因用力过猛跌坐在地。"
    play music "sounds/bgm/scary.ogg" fadeout 1
    translate None chapter_one_87:
        "浓烈的腐臭气味猛然袭来，恶心得我干呕不止。"
    translate None chapter_one_88:
        "低头看向膝间，背包正搁在腿间，能感觉到有湿冷的东西贴着大腿。"
    show raen n sad with dis
    translate None chapter_one_89:
        "我伸手去抓。不管是什么，触感都像石头般冰冷潮湿。"
    translate None chapter_one_90:
        "这…这是什么..？"
    translate None chapter_one_91:
        "屏住呼吸，但恶臭仍彻底占领了我的感官。"
    show raen n wor with dis
    translate None chapter_one_92:
        rs "三…二…一…"
    translate None chapter_one_93:
        "缓缓把手绕上去，最后鼓足勇气，将它拽到眼前。"
    translate None chapter_one_94:
        "不…"
    translate None chapter_one_95:
        "能感觉到血液瞬间从脸上褪去。我拼命把它抛得远远的，却仍能看见它从灌木丛中支棱出来。"
    translate None chapter_one_96:
        "我手脚并用地仓皇逃开，拼命想和那个…东西拉开距离。"
    translate None chapter_one_97:
        rs "不….不..不！"
    translate None chapter_one_98:
        "这不是真-"
    translate None chapter_one_99:
        "我迅速转身，胃里一阵翻涌。"
    translate None chapter_one_100:
        "那包东西不是卡在灌木丛里—它是卡在某人的手臂上，而我刚扯下了一条臂膀。"
    show raen n sad with dis
    translate None chapter_one_101:
        "我将手按在胸前，掌心感受到的心跳是唯一能证明这一切真实的东西。"
    translate None chapter_one_102:
        rs "呕呃。"
    translate None chapter_one_103:
        "我又开始干呕，这次比之前剧烈得多。幸亏我的胃里还是空的。"
    translate None chapter_one_104:
        rs "咳，咳。"
    translate None chapter_one_105:
        "不可能…"
    translate None chapter_one_106:
        "这种事怎么会发生在我身上？就在昨天我还在过正常生活…安全又幸福…"
    translate None chapter_one_107:
        "怎么变成这样的？"
    translate None chapter_one_108:
        "我瞥向刚才扔它的方向。它纹丝未动。"
    translate None chapter_one_109:
        "一条手臂。"
    translate None chapter_one_110:
        "正在腐烂的人手臂。"
    show raen n wor with dis
    translate None chapter_one_111:
        "谁会在这荒郊野外？我想不出有谁愿意离开奥雷利亚卡维拉。没人离开过。我甚至从没听说过有人被驱逐。"
    translate None chapter_one_112:
        "那么..难道还有其他人像我一样被流放？这具尸体在那儿多久了？"
    translate None chapter_one_113:
        "又一阵恶心感席卷而来。"
    translate None chapter_one_114:
        "我能感觉到手上的湿滑。那些粘稠液体在掌心留下了褐色的污痕。"
    translate None chapter_one_115:
        "我拼命在地面上摩擦双手直到通红生疼，但那些污渍顽固不化。"
    translate None chapter_one_116:
        "为什么擦不掉？！"
    translate None chapter_one_117:
        rs "快走开，求你了，快走开啊！"
    translate None chapter_one_118:
        "我搓了又搓，即使肉眼已经看不见…我依然能感觉到它。恶心得要命。"
    translate None chapter_one_119:
        "几分钟前还折磨着我的饥饿感此刻已荡然无存。"
    translate None chapter_one_120:
        "感谢诸神我还没找到吃的。不然肯定全吐出来了。"
    translate None chapter_one_121:
        "我动弹不得。"
    translate None chapter_one_122:
        "这东西出现在远离奥雷利亚卡维拉的地方必有缘由…可究竟为什么？"
    translate None chapter_one_123:
        "是谁…不，是什么东西能造成这种惨状？"
    show raen n sad with dis
    translate None chapter_one_124:
        "我透过刘海再次望向灌木丛。"
    translate None chapter_one_125:
        "既然有手臂…那其他部位呢？"
    translate None chapter_one_126:
        "我不想知道了。"
    translate None chapter_one_127:
        rs "必须离开这里…"
    translate None chapter_one_128:
        "我猛地跳起来转身狂奔，全然不顾草地上丢弃的背包。"
    play sound "sounds/sfx/runninggravel.ogg" fadeout 1
    stop music fadeout 3.0

    scene black with swipe

    pause(1)
    translate None chapter_one_129:
        rs "呼哧…呼哧…"
    translate None chapter_one_130:
        rs "我…跑了多久…？"
    window hide dissolve

    scene bg forest at fadeinleft2 with dissolve:
        size (1920, 1080) crop (.5, .5, 1012, 548) # Sets the initial size for the image


    window show dissolve
    translate None chapter_one_130a:
        "那触感仍在。低头看时手上明明空无一物，可我仍能感觉到。"
    play sound "sounds/sfx/trickle.ogg" fadeout 1
    translate None chapter_one_131:
        "无论望向何处，都觉得它还在那儿，仿佛正注视着我。"
    translate None chapter_one_132:
        "当我从灌木丛中扯下那个袋子时发出的声音…在我脑海中回荡。"
    play sound "sounds/sfx/waterriver.ogg" fadein 2.0
    translate None chapter_one_133:
        rs sur "等等…那是什么？"
    translate None chapter_one_134:
        "那是…水..？"
    translate None chapter_one_135:
        "我确实能听到附近有微弱的潺潺水声。我加快脚步，带起一阵纷飞的落叶从树林中冲了出来。"
    stop sound fadeout 2.0
    window hide dissolve


    scene bg river with w19
    show raen n sur at center with dissolve
    play music "sounds/bgm/daytime.ogg" fadeout 1

    window show dissolve
    translate None chapter_one_136:
        rs "水…！"
    translate None chapter_one_137:
        "我遇见了一条河。两岸的堤坝上散落着五颜六色的垃圾、衣物和各种零碎物件。"
    translate None chapter_one_138:
        "但我几乎没有注意到这些。重要的是我能清洗和喝水了。"


    show raen n naked sur with dis2
    play sound "sounds/sfx/clothrustle.ogg"


    translate None chapter_one_139:
        "不假思索地，我踢掉衣服，只剩内衣，奔向水边。"
    play sound "sounds/sfx/splash2.ogg" fadeout 1
    translate None chapter_one_140:
        "我从岸边径直跳入河中。谁会在乎内裤湿不湿？"
    translate None chapter_one_141:
        "浅水漫到了我的腰部。"

    show raen n naked smi with dis2
    $ renpy.sound.stop(fadeout=1.5)
    show fawn river with dis2

    translate None chapter_one_142:
        "清凉甘洌的水抚过我汗湿的肌肤。终于，有水了。"
    play sound "sounds/sfx/bathing.ogg" fadeout 1
    translate None chapter_one_143:
        "我不断搓洗着手臂、双手和腿，直到它们泛红粗糙。感觉就像在擦去早前的记忆。"
    translate None chapter_one_144:
        "当我对此感到满意后，便开始打理我的头发。昨日积攒的汗水和油脂已经堆积了起来。"
    play sound "sounds/sfx/twigsnap.ogg" fadeout 1
    translate None chapter_one_145:
        rs "啊，感觉好多了已-"
    stop music fadeout 2.0
    show raen n sur with dissolve
    translate None chapter_one_146:
        "我的头猛地转向对岸。"
    show raen n naked sur at slightright with move
    show fawn n sur at slightleft with dissolve
    translate None chapter_one_147:
        fawnu "....."
    show raen n naked sur with dis
    translate None chapter_one_148:
        rs "......"
    show fawn n emb with dis
    translate None chapter_one_149:
        fawnu "......."
    show raen n naked emb with dis
    translate None chapter_one_150:
        rs "........"

    scene bg river:
        xpos 0.5 ypos 1.0 xanchor 0.34 yanchor 0.74 zoom 1.5
    show fawn m emb
    with dis2


    translate None chapter_one_151:
        "在对面的河岸上站着一个蓝头发的年轻男孩，脸上露出完全呆愣的表情。他的怀里抱满了各式各样的物品。"
    scene bg river
    show raen n naked emb at slightright
    show fawn n emb at slightleft
    with dis2
    translate None chapter_one_152:
        "还没等我开口，他就转身跑了。"
    play sound "sounds/sfx/runningnormal.ogg" fadeout 1
    hide fawn with moveoutleft
    translate None chapter_one_153:
        rs "等等！"
    translate None chapter_one_154:
        "我猛地转身冲向我的衣服，朝着最后看到那个男孩的方向飞奔而去。"
    play sound "sounds/sfx/runninggravel.ogg" fadein 1.0
    window hide dissolve



    scene black onlayer middle with swipe
    window show dissolve
    stop sound fadeout 2.0
    show raen n naked emb at right
    show expression AlphaMask("foliage_1_nyoom", At("雷恩 n 赤裸 emb", right)) as mask
    show bg forest nyoom onlayer master with swipe:
        xpos 0.82 ypos 1.37 zoom 1.71
    hide black with rain



    translate None chapter_one_155:
        "奔跑时，我仍能听到前方树叶和树枝断裂的清晰声响。至少这意味着他离我不远。"
    translate None chapter_one_156:
        "这里的地面看起来经常被使用…几乎形成了一条小径。他肯定经常走这条路。"
    translate None chapter_one_157:
        "在树林间，我短暂地瞥见了他蓝色的发绺。"
    show fawn n hur at slightleft
    show expression AlphaMask("foliage_1_nyoom", At("福恩 与 赫尔", slightleft)) as mask2
    with dis
    translate None chapter_one_158:
        "很快，随着我逼近他，他的身影更多地映入眼帘。"
    translate None chapter_one_159:
        rs "嘿，等等！求你了！"
    translate None chapter_one_160:
        "他显然不打算停下等待。"
    show raen at righttosr
    show expression AlphaMask("foliage_1_nyoom", At("雷恩 n 赤裸 emb", righttosr)) as mask
    translate None chapter_one_161:
        "此刻他离得如此之近，我几乎能触碰到他。我伸手想抓住他，却只来得及让指腹掠过他的后背。"
    translate None chapter_one_162:
        "这可能是我唯一的机会。"
    translate None chapter_one_163:
        "绝不能让他逃脱。"
    translate None chapter_one_164:
        "我用尽最后的力气朝他扑去。"



    show raen n naked ang at srto
    show expression AlphaMask("foliage_1_nyoom", At("雷恩 裸体 出现", srto)) as mask
    pause (1.0)
    show raen at shakeoffcenter
    show expression AlphaMask("foliage_1_nyoom", At("雷恩 裸体 出现", shakeoffcenter)) as mask
    show fawn at shakesl
    hide mask2
    show expression AlphaMask("foliage_1_nyoom", At("福恩 与 赫尔", shakesl)) as mask3
    window hide dissolve
    scene black with rain1
    pause(0.5)


    play sound "sounds/sfx/fallonground.ogg"
    scene gallery_11 at shake with rain1

    window show dissolve
    translate None chapter_one_165:
        rs "抓到你了！"
    play music "sounds/bgm/night.ogg" fadeout 1
    translate None chapter_one_166:
        fawnu "啊！"
    translate None chapter_one_167:
        rs  "我说等等！"
    translate None chapter_one_168:
        "我将男孩扑倒在地并按住他，双臂撑在他脑袋两侧。追逐让我的肺像被灼烧般疼痛。"
    translate None chapter_one_169:
        "被我压在身下的男孩显得惊恐万分。他的身体在我下方不停颤抖。"
    translate None chapter_one_170:
        rs "我不会伤害你。"
    translate None chapter_one_171:
        rs "只是想和你谈谈。"


    scene gallery_12 with dissolve:
        size(1920,1080) crop (100,400,960,540)


    translate None chapter_one_172:
        "他突然涨红了脸。但视线并没看着我的脸。"
    translate None chapter_one_173:
        "循着他的目光，发现他在往更低处看。"


    scene gallery_12 with dissolve


    translate None chapter_one_174:
        "这时我才意识到自己还没穿衣服。"
    translate None chapter_one_175:
        rs "我…呃-我不是-我是说.."
    translate None chapter_one_176:
        fawnu ".............."
    translate None chapter_one_177:
        rs "..................."
    translate None chapter_one_178:
        "终于能近距离看清这个男孩。淡蓝色羽毛状头发散在周围，银灰色眼睛因恐惧睁得老大。当他的嘴唇颤抖时，看起来随时会哭出来。"
    translate None chapter_one_179:
        "他看起来如此脆弱，易碎。"
    translate None chapter_one_180:
        "我湿漉漉的头发抵着他越久，他的脸就慢慢变得更湿。"
    play sound "sounds/sfx/stomach.ogg" fadeout 1
    translate None chapter_one_181:
        rs "啊，真的很抱-"
    translate None chapter_one_182:
        fawnu "你…你饿了吗？"
    translate None chapter_one_183:
        rs "呃…嗯。"
    window hide dissolve

    play sound "sounds/sfx/clothrustle.ogg"
    scene bg forest with w12
    window show dissolve
    show raen n naked emb at slightright
    show fawn n sad at slightleft
    show expression AlphaMask("foliage_1", At("雷恩 n 赤裸 emb", slightright)) as mask
    show expression AlphaMask("foliage_1", At("fawn n sad", slightleft))
    with dis2


    translate None chapter_one_184:
        "我迅速从他身上起来，抓起衣物护在胸前。"
    translate None chapter_one_185:
        rs "我现在穿衣服…所以别走开。求你了。"
    translate None chapter_one_186:
        "蓝发男孩缓缓起身，始终盯着地面轻轻点头。"
    play sound "sounds/sfx/clothrustle.ogg"
    translate None chapter_one_187:
        "我背过身用最快速度套回衣服。系鞋带时笨拙地弄了好几下。"

    hide mask
    show expression AlphaMask("foliage_1", At("raen n emb", slightright)) as mask2
    show raen n dressed emb at slightright
    with dis2

    translate None chapter_one_188:
        "转身时我本以为蓝发男孩会逃走，但他还在原地。"
    translate None chapter_one_189:
        rs "我穿好了…."
    show raen n sad with dis
    translate None chapter_one_190:
        rs "听着，很抱歉那样扑倒你。我不是要伤害你，但你是我在这里…唯一见到的活人。"
    translate None chapter_one_191:
        rs "我叫雷恩。"
    show fawn n neu with dis
    translate None chapter_one_192:
        "我向他伸出手。他低头看着我摊开的掌心犹豫片刻，最终还是握住我的手轻轻摇晃。"
    translate None chapter_one_193:
        f "啊，呃…福恩…"
    translate None chapter_one_194:
        rs "福恩？"
    translate None chapter_one_195:
        f "呃…我的名字…"
    show raen n smi with dis

    if achievement.has("fawn_meet"):
        pass
    else:
        $ renpy.display_notify("成就解锁：这地方有头鹿？")

    python:
        achievement.grant("fawn_meet")
        achievement.sync()
    translate None chapter_one_196:
        rs "哦。福恩。很高兴认识你。"
    translate None chapter_one_197:
        "他原本紧抱在怀的物品散落一地，都在我扑倒他时抛飞了出去。"
    window hide


    menu:

        "帮他捡东西":
            $ fawn_relationship +=1
            window show dissolve
            jump fawn_one_yes

        "等他自己捡完":
            window show dissolve
            jump fawn_one_no

    label fawn_one_yes:
    translate None chapter_one_200:
        "我立即弯腰帮他收拾物品。"
    translate None chapter_one_201:
        "里面有彩虹色的衣服、古怪饰品、没有镜片的眼镜和各种零碎杂物。"
    translate None chapter_one_202:
        "当我把东西递还给他时，他红着脸朝我露出笑容。"
    show fawn n shy with dis
    translate None chapter_one_203:
        f "哦，谢谢你…"
    jump choice_two_done

    label fawn_one_no:
    translate None chapter_one_204:
        "我等着他收拾散落的物品。"
    show fawn n shy with dis
    translate None chapter_one_205:
        "他捡起了许多奇怪的东西…这些东西究竟有什么用呢？"
    jump choice_two_done

    label choice_two_done:
    show raen n sur with dis
    translate None chapter_one_206:
        rs "所以，这些都是什么？"
    translate None chapter_one_207:
        f "这些？是我的…私人收藏。"
    translate None chapter_one_208:
        "他的眼睛突然亮了起来。"
    show fawn n sur with dis
    translate None chapter_one_209:
        f "你想看看吗？！"
    show fawn n sad with dis
    translate None chapter_one_210:
        f "呃…那个…我是说我家里有食物和水…可以和你分享…？"
    translate None chapter_one_211:
        rs "真的吗？你确定？"
    translate None chapter_one_212:
        "先前的饥渴感又猛烈地回来了。我快饿死了。"
    translate None chapter_one_213:
        f "嗯。够我们两个人吃。"
    translate None chapter_one_214:
        "他怀里抱着要加入收藏的新物品，转身开始走。"
    translate None chapter_one_215:
        "我想他是要我跟着他？"
    translate None chapter_one_216:
        "我小跑着追上和他并肩而行。"
    translate None chapter_one_217:
        rs "所以福恩，你自己住在这片森林里？"
    translate None chapter_one_218:
        f "噢对，离这不远。不过不是一个人住，我和一群朋友住一起。"
    translate None chapter_one_219:
        rs "真的…？你们都住在这里？住了多久？"
    translate None chapter_one_220:
        f "呃…"
    translate None chapter_one_221:
        "他停顿了几秒钟才开口，看起来陷入了深思。"
    translate None chapter_one_222:
        f "…..有段时间了。"
    show raen n sad with dis
    translate None chapter_one_223:
        "真是有用的回答。"
    translate None chapter_one_224:
        rs "既然神圣存在不保护外界土地，你们为什么离开奥雷利亚卡维拉？"
    show fawn n sur with dis
    translate None chapter_one_225:
        f "什么…？"
    translate None chapter_one_226:
        rs "说书人说连进入森林都很危险，更别说住在这里了。你们怎么来的？"
    translate None chapter_one_227:
        f "说书人…？奥雷利亚卡维拉？你说的是河西边那个镇子吗？"
    translate None chapter_one_228:
        "福恩略带困惑地皱眉看着我。"
    translate None chapter_one_229:
        rs "你不知道说书人…？"
    translate None chapter_one_230:
        f "我从没去过那里，所以…"
    show raen n sur with dis
    translate None chapter_one_231:
        rs "等等，所以你是在这里出生的？"
    show fawn n sad with dis
    translate None chapter_one_232:
        f "不…我小时候来的这里。"
    translate None chapter_one_233:
        "这人怎么回事？也许是在野外待太久产生幻觉了…"
    translate None chapter_one_234:
        rs "啊…好吧。行吧。"
    $ about_Fawn.locked = False
    translate None chapter_one_235:
        "我没再追问。显然{a=set_entry:enc_people->about_Fawn}{color=#DA70D6}福恩{/color}{/a}并不完全明白我在说什么。"
    window hide dissolve

    scene bg treehouseout with fade
    window show dissolve
    show raen n sur at slightright
    show fawn n neu at slightleft
    with dis2


    translate None chapter_one_236:
        "还没来得及再问，我们就停在一棵高大的树前，树上垂着绳梯。"
    translate None chapter_one_237:
        "抬头望去，能看到树干上架着个小木屋。"
    translate None chapter_one_238:
        rs "你们住在树上…？"
    translate None chapter_one_239:
        f "夜间住在高处更安全…"
    show fawn n hap with dis
    translate None chapter_one_240:
        "他把装满新收获的背包甩到肩上，对我温和地笑了笑。"
    translate None chapter_one_241:
        "我不由得又想起了先前的那个背包……"
    translate None chapter_one_242:
        "最好还是忘了这件事吧…"
    translate None chapter_one_243:
        "福恩轻松地爬上梯子，在顶端向我挥了挥手。"
    translate None chapter_one_244:
        rs "看来该我上去了。"
    translate None chapter_one_245:
        "我抓住梯子，跟在他后面爬了上去。"
    window hide dissolve

    scene bg treehousesunset with Fade(0.5,0,1)


    window show dissolve
    translate None chapter_one_246:
        rs sur "哇…！"
    translate None chapter_one_247:
        "当我爬上梯子进入福恩的树屋时，简直不敢相信眼前的景象。只有一个房间，里面有临时搭建的床、几把椅子和许多其他零散的家具。"
    translate None chapter_one_248:
        "但让我惊讶的并不是这些。"


    #scene bg treehousesunset with dissolve
    show raen n sur at slightright
    show fawn n hap at slightleft
    with dis2


    translate None chapter_one_249:
        rs "这些都是你收集的？从河岸边？"
    translate None chapter_one_250:
        f "啊…是的…我一直在慢慢收集这些东西…"
    translate None chapter_one_251:
        "他对我的反应显得特别开心。"


    scene bg treehousesunset with dissolve:
        size (1920, 1080) crop (0, 400, 900, 500)
        linear 30.0 crop (500, 400, 900, 500)


    translate None chapter_one_252:
        "整个房间摆满了各种颜色的玻璃瓶、布料、旧书和各种杂物。它们在阳光下交织成一种神奇的氛围。"
    translate None chapter_one_253:
        "虽然这些都是被丢弃后拼凑的物品…却莫名有种家的温馨感。"
    translate None chapter_one_254:
        "福恩正忙着在房间里整理打扫。我看着阳光从外面透进来，穿过彩色玻璃，在地板上投下彩虹般的光影。"


    scene bg treehousesunset with dissolve
    show raen n sur at slightright
    show fawn n hap at slightleft
    with dissolve


    translate None chapter_one_255:
        "收拾完后，他在几个篮子里翻找，最后递给我一碗混合坚果水果和一杯清水。"
    show fawn n neu with dis
    translate None chapter_one_256:
        "之前的饥渴感又涌了上来。我狼吞虎咽地吃着食物，大口喝着水。福恩一直坐在房间对面看着我。"
    translate None chapter_one_257:
        "他眼里充满好奇的神色。这让我想起孤儿院的孩子们。他显然有话要说。"
    translate None chapter_one_258:
        f "你是…我在这里见到的第一个人，而我在这儿已经生活很久了…"
    translate None chapter_one_259:
        rs "我还以为你和朋友们住在一起呢？"
    show raen n smi with dis
    translate None chapter_one_260:
        f "哦…其实我的朋友们是-"
    play sound "sounds/sfx/clothrustle.ogg"
    translate None chapter_one_261:
        "话未说完，外面传来窸窸窣窣的声响。声音越来越近，越来越近，直到…"

    play sound "sounds/sfx/birdchirp3.ogg"
    show sq1 at slightleft
    show glider at slightleft
    show bird at slightleft
    with dis2
    pause (0.5)

    show raen n sur with dis
    translate None chapter_one_262:
        rs "啊！"
    translate None chapter_one_263:
        "我猛地从座位上跳起来。门口出现了一只狐狸、一只浣熊、两只鸟和几只我从没见过的动物。"
    show fawn n smi with dis
    translate None chapter_one_264:
        f "伙计们！你们回来啦！"
    translate None chapter_one_265:
        "我看向福恩。显然他对这一幕并不意外。"
    translate None chapter_one_266:
        "他弯下腰挨个抚摸这些小动物，边走边喂它们坚果和浆果。"
    translate None chapter_one_267:
        "我不由注视着他脸上温柔的笑容。"
    translate None chapter_one_268:
        rs "呃…"
    translate None chapter_one_269:
        f "啊，雷恩，这些是我的朋友们。我们已共同生活多年了。"
    translate None chapter_one_270:
        f "抱歉吓到你了，下次我会让他们安静些进来。"
    translate None chapter_one_271:
        rs "我想…问题不在这上面吧？"
    translate None chapter_one_272:
        "他俯身更低，开始对他们窃窃私语。"
    translate None chapter_one_273:
        rs "你能和他们对话？"
    translate None chapter_one_274:
        f "当然！不过有时他们不听话…准是到叛逆期了。"
    translate None chapter_one_275:
        "哦。看来他没法真正沟通。"
    translate None chapter_one_276:
        "但我没点破。何必让他难过呢。"
    translate None chapter_one_277:
        rs "这么说我真是你在野外见过的唯一活人？从小就这么孤独？"
    show fawn n sad with dis
    translate None chapter_one_278:
        f "是的….很抱歉逃开你，在河边见到你时我完全不知所措。"
    translate None chapter_one_279:
        f "而且…我需要些时间组织语言..我不习惯和人交谈…"
    show raen n emb with dis
    translate None chapter_one_280:
        "想起自己湿漉漉半裸着扑倒他的场景，我尴尬地盯着地板。"
    translate None chapter_one_281:
        rs "在森林里…我看到一条胳膊。尸体。我必须…把自己洗干净…"
    show raen n sad with dis
    translate None chapter_one_282:
        "我抬头瞥了福恩一眼。"
    translate None chapter_one_283:
        rs "我整夜奔逃，最后睡在树下。根本不知道这是哪儿…"
    translate None chapter_one_284:
        rs "真不懂你怎么能住这里。太可怕了。"
    translate None chapter_one_285:
        "他沉默片刻。大概在斟酌措辞。"
    translate None chapter_one_286:
        f "我能理解…你的感受。"
    translate None chapter_one_287:
        f "这附近的森林确实危险但…"
    translate None chapter_one_288:
        "他顿了顿。"
    show fawn smiclo with dis
    translate None chapter_one_289:
        f "….它也很美。"
    translate None chapter_one_290:
        f "美丽掩盖危险，危险也隐匿美丽。"
    translate None chapter_one_291:
        "我直直看着他。"
    translate None chapter_one_292:
        "早些时候…我确实觉得这里很美…"
    translate None chapter_one_293:
        "或许他是对的。但我宁愿回到奥雷利亚卡维拉。"
    translate None chapter_one_294:
        rs "明白你的意思…可我不想再露宿荒野了。真希望有其他去处…"
    translate None chapter_one_295:
        "福恩歪了歪头。"
    show fawn n neu with dis
    translate None chapter_one_296:
        f "选择很多啊。奥克斯哈伯、斯塔格威奇、达斯克莫尔、锡德卡汉、迪威克。都离这儿不远。至少上次我看是这样。"
    translate None chapter_one_297:
        "福恩提及的某个地名让我竖起耳朵。"
    show raen n sur with dis
    translate None chapter_one_298:
        rs "….锡德卡汉？那是什么？"
    translate None chapter_one_299:
        f "呃..就是..怎么说…"
    translate None chapter_one_300:
        f "首都？"
    translate None chapter_one_301:
        rs "首都？什么的首都？"
    translate None chapter_one_302:
        f "关于这个地区，我想…？"
    $ about_SC.locked = False
    translate None chapter_one_303:
        "老实说，我完全听不懂他在胡扯什么。{a=set_entry:enc_places->about_SC}{color=#DA70D6}这个地区的首府？{/color}{/a} 什么地区？"

    show bg treehousenight
    show raen n dim sur
    show fawn n dim neu
    with dis3


    translate None chapter_one_304:
        "外面，太阳正缓缓消失，夜空逐渐布满星辰。我呆望着窗外片刻，害怕回去。"
    translate None chapter_one_305:
        "昨晚…实在太可怕了，但我又能怎么办呢？"
    show raen n dim sad at slightright
    show fawn n dim neu at slightleft
    with dis
    translate None chapter_one_306:
        rs "我想…最好现在就出发，趁天还没黑到看不清路。谢谢你提供的食物和水，不敢想要是没有遇见你我会怎样。"
    translate None chapter_one_307:
        "我慢慢起身走向梯子。"
    show fawn n dim sur with dis
    translate None chapter_one_308:
        f "啊，等等！"
    translate None chapter_one_309:
        "还没开始往下爬，我的手突然被人从后面抓住。"
    translate None chapter_one_310:
        f "不如你…今晚就留在这里？"
    show raen n dim sur with dis
    translate None chapter_one_311:
        rs "真的可以吗？不会麻烦你吗？"
    translate None chapter_one_312:
        f "嗯…我的床不大，不过今晚我可以睡地板…"
    translate None chapter_one_313:
        rs "噢不，这怎么行。你睡床吧，我睡地板就很好。总比昨晚露宿强多了。"
    translate None chapter_one_314:
        f "真的，我不介意的。"
    show fawn n dim smi with dis
    show raen n dim smi with dis
    translate None chapter_one_315:
        "我们对视片刻，突然一起笑出声。照这样谦让下去我们要没完没了了。"
    translate None chapter_one_316:
        rs "呃…要不我们干脆一起睡床上？应该挤得下。"
    show fawn n dim shy with dis
    translate None chapter_one_317:
        "福恩的脸又涨得像玫瑰般通红。"
    translate None chapter_one_318:
        f "我从来没有…"
    translate None chapter_one_319:
        "他目光游移着不敢看我，手指不安地摆弄衣角。"
    translate None chapter_one_320:
        f "…和别人同床过…"
    translate None chapter_one_321:
        "这有什么好难为情的？"
    translate None chapter_one_322:
        "哦，可能是怕我会把他挤下床？"
    translate None chapter_one_323:
        rs "别担心，我会注意不占太多位置的。"
    show raen n dim neu with dis
    translate None chapter_one_324:
        rs "我是在孤儿院长大的，早习惯和人共享床铺这些了。"
    show fawn n dim neu with dis
    translate None chapter_one_325:
        "听到\"孤儿院\"这个词，他突然停下动作直视我的眼睛。"
    translate None chapter_one_326:
        f "你没见过父母吗？"
    translate None chapter_one_327:
        rs "嗯。你呢？"
    show fawn n dim sad with dis
    translate None chapter_one_328:
        f "......."
    translate None chapter_one_329:
        "他的目光再次躲开。"
    translate None chapter_one_330:
        f "…也没有。"
    translate None chapter_one_331:
        "他看起来不想多谈，我便没有追问。"
    translate None chapter_one_332:
        rs "不过我并不怨恨父母什么的。孤儿院的大家都对我很好。"
    translate None chapter_one_333:
        rs "可能因为我接受的「审判」结果不太好，所以才被抛弃吧。"
    translate None chapter_one_334:
        f "审判？"
    show raen n dim sad with dis
    translate None chapter_one_335:
        "我们又困惑地对视一眼。独自生活在这里真的让他忘记了最基本的常识吗？"
    translate None chapter_one_336:
        rs "就是…你知道的…"
    translate None chapter_one_337:
        rs "在你出生那天，会从神圣演说者那里得到审判。"
    show raen n dim smi with dis
    translate None chapter_one_338:
        rs "显然，我的命运并不怎么耀眼。"
    translate None chapter_one_339:
        f "在你出生那天就知道了自己的命运..？"
    translate None chapter_one_340:
        rs "当然，每个人都是如此。"
    translate None chapter_one_341:
        f "我家乡可没有这种做法…"
    translate None chapter_one_342:
        "是啊，确实有点难以理解。"
    translate None chapter_one_343:
        f "啊，如果你不累的话…有样东西想给你看看。"
    translate None chapter_one_344:
        "说实话我有点累了，不过既然他让我今晚住下，跟着他转转也无妨。"
    translate None chapter_one_345:
        rs "好啊，反正我不累。"
    show fawn n dim smi with dis
    translate None chapter_one_346:
        "他脸上绽放出纯真灿烂的笑容，满眼雀跃。"
    translate None chapter_one_347:
        f "离这不远，跟我来。"
    translate None chapter_one_348:
        "福恩几乎是蹦跳着冲出房间，爬下梯子落到森林地面。我跟在后面，完全猜不透要去哪。"
    window hide dissolve

    scene bg forestnight with dissolve
    window show dissolve
    show fawn n forestdark neu at slightleft
    show expression AlphaMask("foliage_1", At("福恩和森林暗夜图", slightleft)) as mask
    show raen n forestdark neu at slightright
    show expression AlphaMask("foliage_1", At("雷恩和森林暗夜图", slightright)) as mask1
    with dis3

    translate None chapter_one_349:
        "跟了福恩几分钟后，他突然停步从树缝间向外窥探。"
    translate None chapter_one_350:
        f "到了，跟着我小心点。"
    translate None chapter_one_351:
        "他轻巧地爬下缓坡。我观察了片刻，觉得看起来并不难。"
    translate None chapter_one_352:
        "显然大错特错。"
    show raen n forestdark sur at shakesr
    hide mask1
    show expression AlphaMask("foliage_1", At("雷恩和森林暗夜图", shakesr)) as mask2
    translate None chapter_one_353:
        rs "哇啊！"
    show fawn n forestdark sur with dis
    translate None chapter_one_354:
        "脚下泥土突然塌陷，碎石顺着斜坡滚落。就在我快要滑倒时，福恩伸手抓住了我的手腕。"
    translate None chapter_one_355:
        f "啊小心！这里有点滑。抓紧我的手一起下去。"
    show raen n forestdark wor with dis
    translate None chapter_one_356:
        "这次我仔细盯着地面，对他警告过后还失足感到难为情。"
    translate None chapter_one_357:
        "福恩的手坚定有力，我们缓慢下行，终于抵达陡坡底部。"
    show fawn n forestdark smiclo with dis
    translate None chapter_one_358:
        f "就是这里。看。"
    translate None chapter_one_359:
        "他拨开最后挡路的树枝。"
    window hide dissolve


    scene black with dissolve
    pause(0.5)
    show blackbars onlayer middle with dis
    show bg nightsky with dissolve:
        xpos 0.5 ypos 1.17 xanchor 0.5 yanchor 1.0 zoom 1.4
        easein 10.0 xpos 0.5 ypos 1.33 xanchor 0.5 yanchor 1.0


    window show dissolve
    translate None chapter_one_360:
        "眼前景象宛如童话。"
    translate None chapter_one_361:
        "辽阔湖泊在眼前铺展，目力所及尽是璀璨星河。"


    show gallery_13 with Dissolve(1):
        size (1920, 1080) crop (960, 440, 960, 540)
        linear 20.0 crop (960, 640, 960, 540)


    translate None chapter_one_362:
        "夜幕中的湖水化作明镜，将满天星斗尽数倒映，与穹窿争辉。"
    translate None chapter_one_363:
        rs "这…太美了…"
    translate None chapter_one_364:
        rs "从未见过这样的景致…"
    translate None chapter_one_365:
        rs "在故乡…根本想象不到世间存在此等美景…"
    translate None chapter_one_365a:
        "万语千言在心头盘旋，却不知从何说起。谁能想到世上竟有如此奇观。"
    scene gallery_13 with dissolve
    translate None chapter_one_366:
        "我与福恩并肩坐下，眼前的景色令我神往不已。"
    translate None chapter_one_367:
        f "我想你可能会喜欢这里。"
    translate None chapter_one_368:
        f "你看，这湖里满是各种鱼类。大多是那种恨不得把你当晚餐的品种。"
    translate None chapter_one_369:
        "他轻轻笑出声来，那种充满欢愉的笑容又回到他脸上。"
    translate None chapter_one_370:
        f "但危险并不能抹杀它的美丽。"
    translate None chapter_one_371:
        f "这个世界并非非黑即白…中间地带同样存在着许多事物…"
    translate None chapter_one_372:
        f "而我认为这片森林正是其中之一。"
    translate None chapter_one_373:
        f "你先前看起来不太信服，所以…"
    translate None chapter_one_374:
        f "我只是想告诉你，即便是这样危险的地方，也能成为你称之为家的所在。关键在于你如何看待它，你的视角如何。"

    show gallery_14 with dis2

    translate None chapter_one_375:
        f "啊！"
    translate None chapter_one_376:
        "他突然将手从我掌中抽离。我甚至忘了他一直握着我的手。"
    translate None chapter_one_377:
        rs "不过这个湖确实很大…奇怪的是地图上居然没有标注…."
    translate None chapter_one_378:
        f "我已经很久没看过…地图了，所以不确定…"
    translate None chapter_one_379:
        "他从耳朵尖到下巴都涨得通红，活像个番茄。"
    translate None chapter_one_380:
        "我们静默地并肩而坐。注视着水面下游弋的鱼群。繁星仿佛在我们周身起舞。"
    translate None chapter_one_381:
        "但暗地里，我凝视着福恩的侧颜。月光使他本就苍白的肌肤更显剔透。宛若在莹莹发光…"
    translate None chapter_one_382:
        "或许这个想法很奇怪，但他简直像是森林的一部分。与树木、鱼群、星辰浑然一体…他本就属于这里。"
    translate None chapter_one_383:
        "当他发现我在偷看时，难为情地别过脸去。"
    translate None chapter_one_384:
        f "反…反正，我们该回去了。很快就要变冷了。"
    translate None chapter_one_385:
        rs "好。这次我会小心不滑倒。"
    window hide dissolve


    scene bg treehousenight with Fade(1, 0.5, 1)
    show raen n dim neu at slightright
    show fawn n dim sad at slightleft
    with dissolve



    window show dissolve
    translate None chapter_one_386:
        "刚回到住处，强烈的疲惫感便席卷而来。我立刻开始准备就寝。"
    translate None chapter_one_387:
        "所有的疲倦瞬间涌了上来。今天确实太过漫长。"
    translate None chapter_one_388:
        "我卷起袖子，再次看向手臂上蔓延的神之刻印。我想对他隐瞒也没有意义了，对吧？"
    translate None chapter_one_389:
        "他迟早会以某种方式发现，而我觉得可以信任他。"
    translate None chapter_one_390:
        rs "那个…福恩…"
    show fawn n dim neu with dis
    translate None chapter_one_391:
        "他睡眼惺忪地望向我。"
    translate None chapter_one_392:
        rs "有件事想给你看…昨天还在奥雷利亚卡维拉时，这个突然出现在我手臂上。痛得像被烙进皮肉里…."
    play sound "sounds/sfx/clothrustle.ogg" fadeout 1.0
    #window hide dissolve

    #pause(0.25)
    scene bg treehousenight
    #pause(0.25)
    show raenarm2 dark:
        xpos 0.55 ypos 1.0 xanchor 0.5 yanchor 1.0
    with dis4

    window show dissolve
    translate None chapter_one_393:
        "我抬起手臂向他展示。"
    translate None chapter_one_394:
        f sur "这个…我在什么地方见过这种文字…"
    translate None chapter_one_395:
        "他迅速冲到我身旁，一把抓住我的手臂。他将我的手臂拉近，仔细检查着我的神之刻印。"
    translate None chapter_one_396:
        f "在我来到这里之前…我绝对在什么地方见过这个…"


    scene bg treehousenight with dissolve
    show raen n dim sad at slightright
    show fawn n dim sad at slightleft
    with dissolve


    translate None chapter_one_397:
        "我满怀期待地看着他，但一切都是徒劳。无论他如何绞尽脑汁，记忆就是不回来。"
    translate None chapter_one_398:
        f "我很抱歉…这是怎么发生的？"
    translate None chapter_one_399:
        rs "我不确定。上一刻我还在人群中，完全没事，然后突然就感到剧痛…我昏过去了。醒来时它就在那儿了。"
    translate None chapter_one_400:
        rs "也许这不重要…"
    show fawn n dim neu with dis
    translate None chapter_one_401:
        "他谨慎地注视着我，陷入思考。"
    translate None chapter_one_402:
        f "对我来说这似乎很重要…我会继续想想。也许等我们休息完，明早就能想起来了。"
    show fawn n dim shy with dis
    translate None chapter_one_403:
        f "转过身去，我要准备睡觉了…"


    scene bg treehousenight with dissolve:
        xpos 0.5 ypos 1.0 xanchor 0.68 yanchor 0.77 zoom 1.7


    translate None chapter_one_404:
        "福恩先上了床，迅速把自己裹进被子里。我挪动着躺到他旁边。"
    translate None chapter_one_405:
            "床本来只够一个人睡，我们挤得很紧，但还能保持不碰到对方。我又往边上挪了挪，给他更多空间。"
    translate None chapter_one_406:
        f neu "话说，你为什么在这里？"
    translate None chapter_one_407:
        "福恩从肩膀上瞥了我一眼，背仍然对着我。"
    translate None chapter_one_408:
        rs sad "我…他们…"
    translate None chapter_one_409:
        "我试图编个借口。随便什么都行，但实在想不出什么好理由。"
    translate None chapter_one_410:
        rs "…我被放逐了。我去了不该去的地方。"
    translate None chapter_one_411:
        rs "说实话，我以为自己现在已经死了。我们从小就被灌输外面是活不下去的…"
    translate None chapter_one_412:
        rs smi "但不知为何…情况没我想象的那么糟。"
    translate None chapter_one_413:
        "福恩睡意朦胧地对我笑了笑，转个身就睡着了。"
    translate None chapter_one_414:
        "没过多久我也跟着进入梦乡。"
    stop music fadeout 3.0
    window hide dissolve

    scene black with eye_shut
    pause(2)
    translate None chapter_one_415:
        n "…睁开你的眼睛…"
    translate None chapter_one_416:
        n "…保护…治愈…"
    translate None chapter_one_417:
        n "…命运…"
    translate None chapter_one_418:
        n "..睁开…你的…眼睛…"
    translate None chapter_one_419:
        n "….睁开你的眼睛！"

label jumpdemo:
    scene bg treehouse with eye_open:
        xpos 0.5 ypos 1.0 xanchor 0.68 yanchor 0.77 zoom 1.7
    window show dissolve
    show raen m hur at center with Dissolve(0.2)
    show raen m hur at shake
    translate None chapter_one_420:
        rs "啊！！"
    play sound "sounds/sfx/clothrustle.ogg"
    translate None chapter_one_421:
        "我猛然惊醒，汗流浃背，浑身发抖。心脏在胸腔里猛烈跳动，声音在脑海中回荡。"
    show raen m hur at closeright with move

    show fawn m hur at closeleft
    show fawn m hur at shake
    with dis
    translate None chapter_one_422:
        f "啊！！！"
    translate None chapter_one_423:
        "福恩以闪电般的速度坐起身，跳下床铺。"
    translate None chapter_one_424:
        f "怎么了？！"
    translate None chapter_one_425:
        "我花了一点时间平复呼吸，等待它恢复正常。"
    show raen m sad with dis
    translate None chapter_one_426:
        rs "不..没事。我只是..做了个怪梦。一直做着同样的梦…"
    translate None chapter_one_427:
        f "天啊，我以为你快死了或是我们被袭击了什么的…"
    show fawn m sad with dis
    play music "sounds/bgm/night.ogg" fadeout 1
    translate None chapter_one_428:
        f "但是..你梦见了什么把你吓成这样？"
    translate None chapter_one_429:
        "到底哪部分可怕呢…？我仔细回想了一下。轰鸣的声音，周围无尽的黑暗…"
    translate None chapter_one_430:
        "我不确定一开始它{i}是否{/i}真的可怕。"
    translate None chapter_one_431:
        "但是…它们似乎每次都变得更加强大。"
    translate None chapter_one_432:
        rs "我真的不知道…"
    translate None chapter_one_433:
        rs "有声音存在。响亮、有力、轰鸣的声音。"
    translate None chapter_one_434:
        rs "它们不断告诉我一些事情。让我睁开双眼。关于命运…"
    translate None chapter_one_435:
        "福恩停顿了片刻，就像他偶尔在思考该如何表达时会做的那样。"
    show fawn m neu with dis
    translate None chapter_one_436:
        f "也许这预示着什么？"
    translate None chapter_one_437:
        f "可能某种预视…"
    translate None chapter_one_438:
        rs "预视？可是那种东西并不存在。"
    translate None chapter_one_439:
        f "..真的吗？我听说有些人确实有…奇怪的能力…"
    translate None chapter_one_440:
        f "所以…我不觉得拥有预视能力有多大不同…"
    translate None chapter_one_441:
        rs "但是…我们一直被教导说…"
    show raen m sad with dis
    translate None chapter_one_442:
        rs "算了。我相信这些都没有意义。"
    show fawn m sad with dis
    translate None chapter_one_443:
        f "啊，抱歉，你可能是对的…我只是在自言自语…"
    show raen m sad with dis
    translate None chapter_one_444:
        rs "你知道吗，你不需要总是道歉。特别是为了说话这事。你没做错任何事。"
    translate None chapter_one_445:
        f "啊，你说得对，我很抱-"
    show fawn m neu with dis
    translate None chapter_one_446:
        f "我是说…好吧。"

    scene bg treehouse
    show raen n neu at slightright
    show fawn n neu at slightleft
    with Dissolve(1.0)
    translate None chapter_one_447:
        "福恩立刻忙活起来，在房间里走动准备食物。"
    translate None chapter_one_448:
        "我望向窗外。太阳刚刚在天际露头，时间还很早。薄雾在林间弥漫。"
    translate None chapter_one_449:
        "我们吃着搜寻来的食物，看着太阳在头顶升起。"
    translate None chapter_one_450:
        "这一切都显得太过平常。仿佛我早已在这里度过一生。"
    translate None chapter_one_451:
        "几天前的那些事恍如隔世。"
    translate None chapter_one_452:
        "存在的只有当下。"
    translate None chapter_one_453:
        f "啊..雷恩..我在想…"
    translate None chapter_one_454:
        f "虽然我们才刚认识…"
    show fawn n smiclo with dis
    translate None chapter_one_455:
        f "你愿意…和我一起生活在这里吗？"
    jump chapter_two_start
