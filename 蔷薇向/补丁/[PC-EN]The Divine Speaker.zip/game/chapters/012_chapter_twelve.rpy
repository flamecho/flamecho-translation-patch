label cyneroom:
    stop music fadeout 3.0
    scene black with dissolve
    pause(0.5)

    show bg nox bed big with eye_open:
        size (1920,1080)
        xpos -0.54 ypos -0.45 zoom 1.57

    window show dissolve
    play sound "knock.ogg"
    translate None chapter_twelves_0001a:
        "我被一阵急促的敲门声惊醒。是谁…？就不能让我再多睡会吗？"
    translate None chapter_twelve_0001:
        "我揉开惺忪睡眼，打了个哈欠环顾房间。这是哪….？哦对了，是赛恩的房间。"
    translate None chapter_twelve_0002:
        "昨晚….为什么我会如此难为情…？那件事真的应该和他做吗？"
    translate None chapter_twelve_0003:
        "我感觉…"
    window hide


    menu:
        " …那很令人愉悦":
            window show dissolve
            $ cyne_relationship +=2
            $ fawn_relationship -=1
            jump excited

        "福恩说的对，我想…":
            window show dissolve
            $ fawn_relationship +=1
            $ leos_relationship +=1
            jump wrong

label excited:
    translate None chapter_twelve_0004:
        "当我回想起昨晚的缠绵时…"
    translate None chapter_twelve_0005:
        "我感到…莫名的兴奋…如果有机会，我还想再来一次。"
    jump choice_twenty_done

label wrong:
    translate None chapter_twelve_0006:
        "但现在仔细想想…我说不清。总觉得有哪里不对劲。就像是… "
    translate None chapter_twelve_0007:
        "或许福恩终究是对的，这种事应该留给真正爱的人。"
    translate None chapter_twelve_0008:
        "爱？我爱赛恩吗？呃，应该不算。"
    jump choice_twenty_done


label choice_twenty_done:
    play music "sounds/bgm/creepy.ogg" fadein 3.0
    translate None chapter_twelve_0009:
        l ang "喂，小矮子！"
    translate None chapter_twelve_0010:
        l "快开门滚出来！"
    translate None chapter_twelve_0011:
        l "天呐，这么大动静谁能睡得着？！"
    translate None chapter_twelve_0012:
        "哦对了。敲门声。我刚才都忘了这茬。"
    translate None chapter_twelve_0013:
        "月光从窗户漫进来，鸟鸣声预示着黎明将至。天色还这么早…"
    translate None chapter_twelve_0014:
        "莱奥斯这又是要干嘛…？要是假装不在他说不定就走了。"
    translate None chapter_twelve_0015:
        f sad "莱奥斯…或许我们可以礼貌点…？你太吵了。"
    translate None chapter_twelve_0016:
        l ang "礼貌？！我这么早被吵醒都是你的错！你敲我门时可没想过要\"礼貌\"！"
    translate None chapter_twelve_0017:
        "身旁的赛恩还在轻声打鼾。他睡得可真沉。还挺可爱的。"


    scene bg nox bed big:
        size(1920, 1080)
    show raen n dark neu
    with dissolve
    translate None chapter_twelve_0018:
        "我下床伸了个懒腰。这几天背一直不太舒服，但这床确实舒服得像天堂。"
    translate None chapter_twelve_0019:
        "要不是这栋房子其他地方都…阴森森的，我可能会喜欢这里。真希望能天天睡这种超大床…"
    translate None chapter_twelve_0020:
        "刚打开门锁就遭到连珠炮般的质问和吼叫。"

    show fawn n dark hur at left
    show leos n dark ang at right
    with dis
    translate None chapter_twelve_0021:
        f "赛恩，雷恩不见-"
    show fawn n dark neu with dis
    translate None chapter_twelve_0022:
        f "................"
    show leos n dark hur with dis
    translate None chapter_twelve_0023:
        l "搞什么？！你俩在这干嘛？！我担心-我是说，被你们害得早起！"
    show raen n dark sur with dis
    translate None chapter_twelve_0024:
        rs "……早上好。"
    show leos n dark cur with dis
    translate None chapter_twelve_0025:
        l "你就只说这个？"
    translate None chapter_twelve_0026:
        l "这只小老鼠找不到你都急哭了我才踹的门，结果你在这儿？"
    show raen n dark sad with dis
    translate None chapter_twelve_0027:
        rs "抱歉…昨晚和赛恩在一起太累了，所以没听见你敲门。我很晚才睡。"
    translate None chapter_twelve_0028:
        f "等等，什么？"
    translate None chapter_twelve_0029:
        l "........"
    show raen at cenleft
    show leos at farright
    show fawn at farleft
    with move
    show cyne n dark mis at cenright with dis
    translate None chapter_twelve_0030:
        c "别让我难堪，雷恩！"
    translate None chapter_twelve_0031:
        "赛恩从背后抱住我，双臂环住我的腰，把脸埋进我身上。"
    translate None chapter_twelve_0032:
        c "我不想让他们知道我们的午夜幽会。太丢人了！"
    translate None chapter_twelve_0033:
        show fawn n dark sur with dis
        f "什么……？！"
    translate None chapter_twelve_0034:
        show leos n dark pis with dis
        l "如果你敢碰他……"
    translate None chapter_twelve_0035:
        show cyne n dark sur with dis
        c "哇，态度转变得真快！我以为你不在乎雷恩做了什么？为什么这对你如此重要？"
    translate None chapter_twelve_0036:
        c "我是不是激活了你的白马骑士模式什么的？莱奥斯要来英雄救美，把他心爱的人从邪恶的赛恩手里救出来。"
    translate None chapter_twelve_0037:
        show leos n dark emb with dis
        l "我才不在乎你做什么，我…我只是…算了。随你便吧。搞砸了别哭着回来找我。"
    translate None chapter_twelve_0038:
        rs "伙计们，冷静点。没事的！我们只是聊了聊奥雷利亚卡维拉，仅此而已。"
    translate None chapter_twelve_0039:
        c "可怜的小雷恩。他一直错过这些……"
    translate None chapter_twelve_0040:
        show cyne n dark hap with dis
        c "他很幸运，我既漂亮又善良。他想知道什么我都会教他。莱奥斯也是，如果他愿意。"
    translate None chapter_twelve_0041:
        show leos n dark pen with dis
        l "我？"
    translate None chapter_twelve_0042:
        show fawn n dark neu with dis
        f "你…你对他做了什么？"
    translate None chapter_twelve_0043:
        c "别用你那可爱的小脑袋瞎操心啦！他还是你那纯洁的小狗勾。"
    translate None chapter_twelve_0044:
        show fawn n dark emb with dis
        f "什…！我…我没有…我怎么会…"
    translate None chapter_twelve_0045:
        c "嘿嘿。你太明显啦！"
    translate None chapter_twelve_0046:
        l "随你怎么对他，看我care不care。"
    translate None chapter_twelve_0047:
        c "哦，我不知道他做决定还需要经过你同意呢。"
    translate None chapter_twelve_0048:
        c "反正我只是在帮他。他想了解爱情，而我恰好是个中高手。"
    translate None chapter_twelve_0049:
        show fawn n dark sad with dis
        f "…你为什么要告诉他？"
    translate None chapter_twelve_0050:
        "哈？难道我应该保密吗…？"
    translate None chapter_twelve_0051:
        rs "呃，是他问的……"
    translate None chapter_twelve_0052:
        c "没什么大不了的。雷恩只是告诉我你们需要学习爱的真谛。所以，我主动帮忙。真的，我的善良无边无际。"
    translate None chapter_twelve_0053:
        "福恩脸色阴郁，双手在身侧握成拳头。通常他很容易相处，但对赛恩…也许是他们性格太不合了…？"
    translate None chapter_twelve_0054:
        "赛恩只是想帮忙。他怎么就是不明白？"
    translate None chapter_twelve_0055:
        show fawn n dark bla with dis
        f "他不需要你的帮助。他现在这样就很好。"
    translate None chapter_twelve_0056:
        show cyne n dark sur with dis
        c "哦？你能代表他说话？"
    translate None chapter_twelve_0057:
        show fawn n dark sad with dis
        f "不，我-"
    translate None chapter_twelve_0058:
        c "没错。我觉得像你这样的人应该清楚自己的位置。"
    translate None chapter_twelve_0059:
        rs "别戏弄他了，赛恩。真的没什么大事发生。"
    translate None chapter_twelve_0060:
        f "好吧…."

    jump choice_twentyone_done


label cyneyesno:
    stop music fadeout 3.0
    scene black with dissolve
    pause(0.5)

    show bg nox bed big with eye_open:
        size (1920,1080)
        xpos -0.54 ypos -0.45 zoom 1.57

    window show dissolve
    play sound "knock.ogg"
    translate None chapter_twelve_0062:
        "嗯….这是什么声音…？有人在砸我的门…？"
    translate None chapter_twelve_0063:
        "…或许我该装作没听见…"
    translate None chapter_twelve_0064:
        play music "sounds/bgm/creepy.ogg" fadein 3.0
        l ang "赶紧把你的屁股从床上挪开。我们可没一整天时间等你！"
    translate None chapter_twelve_0065:
        "什么…莱奥斯？他为什么闹出这么大动静？"
    translate None chapter_twelve_0066:
        f sad "嘿…别这样说话…友善一点…"
    translate None chapter_twelve_0067:
        l ang "我们又在这儿等他了。我都敲了快五分钟的门了！"
    translate None chapter_twelve_0068:
        c hap "那个嘛～说不定他正忙着呢！男人总得处理些私事，你懂的。"
    translate None chapter_twelve_0069:
        l ann "这大清早的他能忙活什么？"
    translate None chapter_twelve_0070:
        c hap "也许他醒来时正忙着-"
    translate None chapter_twelve_0071:
        f emb "不许说那个！你没资格这么谈论他…"
    translate None chapter_twelve_0072:
        l ang "你们俩能不能闭嘴？"
    translate None chapter_twelve_0073:
        l "再让我站这儿等下去我就要掐死谁了。"
    translate None chapter_twelve_0074:
        c mis "嘿，嘿，这种好事威胁对我不奏效啊。轻轻掐两下，再来点蜡烛…"
    translate None chapter_twelve_0075:
        l ann "...."
    translate None chapter_twelve_0076:
        c hap "我们的小莱奥斯还犯困呢？不擅长早起是吧？"
    translate None chapter_twelve_0077:
        f smi "嘿嘿…"
    translate None chapter_twelve_0078:
        l ang "闭嘴。至少我醒着，不像某些人。"
    translate None chapter_twelve_0079:
        "等等，我睡过头了吗？！"
    translate None chapter_twelve_0080:
        "当我望向窗外时，天色还暗着。呼。月光柔柔地洒在房间里。远处传来鸟儿的叽喳声。离日出不远了。"
    translate None chapter_twelve_0081:
        "我还是不太明白为什么我们要这么早出门…诺克斯是觉得调查时间越多越好吗？想来也有道理…"

    scene bg nox bed big with dissolve:
        size(1920, 1080)

    translate None chapter_twelve_0082:
        "其他三人都已整装待发，我得赶快了。"

    show raen n dark sur at cenleft
    show cyne n dark mis at cenright
    show fawn n dark neu at farleft
    show leos n dark ang at farright
    with dissolve
    translate None chapter_twelve_0083:
        "我跳下床，迅速穿好衣服拉开房门插销。莱奥斯瞪着我，脸上写满睡意。"
    translate None chapter_twelve_0084:
        rs "….早安。"
    translate None chapter_twelve_0085:
        l "你就只会说这个？我在这儿站了五分钟。"
    translate None chapter_twelve_0086:
        show raen n dark neu with dis
        rs "呃…抱歉我睡过头了…？你想让我说什么？"
    translate None chapter_twelve_0087:
        f "你根本没睡过头，现在还早着呢。"
    translate None chapter_twelve_0088:
        c "只是莱奥斯被我吵醒心情不好罢了。"

    if cyne_no:
        jump cyne_noscandal

    if cyne_yes:
        jump cyne_scandal

label cyne_noscandal:
    show raen n dark smi with dis
    translate None chapter_twelve_0089:
        rs "啊哈哈…谁能想到你这家伙这么不擅长早起？"
    translate None chapter_twelve_0090:
        l "快点吧，你已经让我等得够久了。"
    translate None chapter_twelve_0091:
        show fawn n dark shy with dis
        f "睡得好吗，雷恩？"
    translate None chapter_twelve_0092:
        rs "很好。我从来没睡过这么舒服的床。"
    translate None chapter_twelve_0093:
        c "要是我们俩一起躺在里面会更舒服些，你不觉得吗？"
    translate None chapter_twelve_0094:
        show leos n dark smi with dis
        l "你想得美。"

    show cyne n dark sur
    show fawn n dark bla
    with dis
    translate None chapter_twelve_0095:
        c "哦，抱歉。我早该知道得先征得他保镖同意。"
    translate None chapter_twelve_0096:
        show leos n dark neu with dis
        l "我不是—"
    translate None chapter_twelve_0097:
        c "你必须是他的保镖对吧？不然为什么这么护着他？那就太奇怪了。"
    translate None chapter_twelve_0098:
        "两人继续斗嘴，我转向福恩。他正用奇怪的表情盯着赛恩。"
    translate None chapter_twelve_0099:
        show raen n dark sur with dis
        rs "福恩……？"
    translate None chapter_twelve_0100:
        show fawn n dark smi with dis
        f "…嗯？"
    translate None chapter_twelve_0101:
        "他的脸瞬间亮了起来。那个表情是我的错觉吗….？那种空洞的凝视？"
    translate None chapter_twelve_0102:
        show raen n dark smi with dis
        rs "啊，没什么。你睡得好吗？"
    translate None chapter_twelve_0103:
        f "这是我第一次睡在正经床上…虽然情况很糟，但总比不舒服强。"
    translate None chapter_twelve_0104:
        show raen n dark sur with dis
        rs "真的？你小时候呢？在住进森林之前？"
    translate None chapter_twelve_0105:
        show fawn n dark neu with dis
        f "..................."
    translate None chapter_twelve_0106:
        show cyne n dark hap with dis
        c "要是你喜欢那些床，你肯定会爱上我那儿。超大超软的枕头…啊啊，已经开始想念了。"
    translate None chapter_twelve_0107:
        l "没时间闲聊了。我们该出发了。"

    jump choice_twentyone_done


label cyne_scandal:
    show raen n dark sur with dis
    translate None chapter_twelve_0108:
        rs "抱歉…昨晚被赛恩折腾得挺累的…"
    translate None chapter_twelve_0109:
        show fawn n dark sur with dis
        f "等等，什么？他{i}干了什么{/i}？"
    translate None chapter_twelve_0110:
        show leos n dark sur with dis
        l "........"
    translate None chapter_twelve_0111:
        show cyne n dark hap with dis
        c "别让我难堪，雷恩！"
    translate None chapter_twelve_0112:
        c "我可不想让他们知道我们的午夜幽会！哦，多 scandal 啊！"
    translate None chapter_twelve_0113:
        show fawn n dark bla with dis
        f "........."
    translate None chapter_twelve_0114:
        show leos n dark ang with dis
        l "他对你做了什么！？没伤到你吧？！"
    translate None chapter_twelve_0115:
        show cyne n dark sur with dis
        #Added voice mapping, check
        c "哇，态度转变得真快！我以为你不在乎雷恩做了什么？为什么这对你如此重要？"
    translate None chapter_twelve_0116:
        show leos n dark pen with dis
        l "什么…？行吧，那我不管了。随你便，受伤了别来找我哭。"
    translate None chapter_twelve_0117:
        #Added voice mapping, check
        rs "伙计们，冷静点。没事的！我们只是聊了聊奥雷利亚卡维拉，仅此而已。"
    translate None chapter_twelve_0118:
        #Added voice mapping, check
        c "可怜的小雷恩。他一直错过这些……"
    translate None chapter_twelve_0119:
        show cyne n dark hap with dis
        c "他很幸运，我既漂亮又善良。他想知道什么我都会教他。莱奥斯也是，如果他愿意。"
    translate None chapter_twelve_0120:
        f "你们…到底干了啥…？"
    translate None chapter_twelve_0121:
        c "别吃醋，我把他完好无损留给你了。"
    translate None chapter_twelve_0122:
        show fawn n dark emb with dis
        #Added voice mapping, check
        f "什…！我…我才没有…怎么会…"
    translate None chapter_twelve_0123:
        #Added voice mapping, check
        c "嘿嘿。你太明显啦！"
    translate None chapter_twelve_0124:
        l "随便吧，爱怎样怎样。"
    translate None chapter_twelve_0125:
        show cyne n dark sur with dis
        #Added voice mapping, check
        c "他想做什么还需要你批准？仁慈的莱奥斯大人开恩许可我们了！万岁！"
    translate None chapter_twelve_0126:
        show cyne n dark mis with dis
        #Added voice mapping, check
        c "反正我只是帮他个忙。他想了解爱情，而我刚好是爱情大师。"
    translate None chapter_twelve_0127:
        show fawn n dark sad with dis
        f "......."
    translate None chapter_twelve_0128:
        f "你告诉他了….？"
    translate None chapter_twelve_0129:
        "哈？这要保密吗…？"
    translate None chapter_twelve_0130:
        rs "是他问的…."
    translate None chapter_twelve_0131:
        #Added voice mapping, check
        c "没什么大不了的。雷恩只是告诉我你们需要学习爱的真谛。所以，我主动帮忙。真的，我的善良无边无际。"
    translate None chapter_twelve_0132:
        "福恩脸色阴郁，双手在身侧握成拳头。通常他很容易相处，但对赛恩…也许是他们性格太不合了…？"
    translate None chapter_twelve_0133:
        "赛恩只是想帮忙。他怎么就是不明白？"
    translate None chapter_twelve_0134:
        #Added voice mapping, check
        f "他不需要你帮忙。他现在这样就很好。"
    translate None chapter_twelve_0135:
        show cyne n dark sur with dis
        #Added voice mapping, check
        c "哦？你能代表他说话？"
    translate None chapter_twelve_0136:
        #Added voice mapping, check
        f "不，我-"
    translate None chapter_twelve_0137:
        #Added voice mapping, check
        c "没错。我觉得像你这样的人应该清楚自己的位置。"
    translate None chapter_twelve_0138:
        show raen n dark sad with dis
        #Added voice mapping, check
        rs "别戏弄他了，赛恩。真的没什么大事发生。"
    translate None chapter_twelve_0139:
        #Added voice mapping, check
        f "好吧…."


    jump choice_twentyone_done

label choice_twentyone_done:
    show leos n dark neu with dis
    translate None chapter_twelve_0140:
        l "…要是闹够了，我们该走了。"

    #window hide dissolve

    scene bg nox house big with dissolve:
        size(1920, 1080)
    #window show dissolve
    translate None chapter_twelve_0141:
        "我们快速走下楼梯，来到下方大厅。此刻月光倾洒在我们四周，照亮了这个先前笼罩在阴影中的房间。那些原本被隐藏的事物，现在清晰可见。"
    translate None chapter_twelve_0142:
        "各个方向都有门通向别处，但它们都紧闭着。我好奇…门后藏着什么？"
    show raen n neu at cenleft
    show cyne n neu at cenright
    show fawn n neu at farleft
    show leos n neu at farright
    with dissolve

    translate None chapter_twelve_0143:
        show cyne n sur with dis
        c "我想知道那些门后有什么。我有点好奇。"
    translate None chapter_twelve_0144:
        show raen n sad with dis
        "看来不止我一个人这么想。"
    translate None chapter_twelve_0145:
        rs "这让我觉得自己有点爱管闲事，但…我也忍不住好奇。不过最好还是别窥探太多。我们还有任务在身。"


    if cyne_staynight:
        jump fawn_upset

    if cyne_yes:
        jump fawn_upset

    if cyne_no:
        jump ox_daytwocont


label fawn_upset:
    translate None chapter_twelve_0146:
        "时不时地，我能看到福恩用余光瞟我，但当我想引起他注意时，他就会移开视线。他还在生气吗？"
    translate None chapter_twelve_0147:
        "赛恩和莱奥斯走得稍前，正争论着窥探诺克斯房子的道德问题，于是我悄悄抓住福恩，把他拉到一边。"

    hide leos
    hide cyne
    hide fawn
    hide raen
    with dissolve
    show raen m sad at closeright
    show fawn m sad at closeleft
    with dissolve
    translate None chapter_twelve_0148:
        rs "嘿，你还好吗？"
    translate None chapter_twelve_0149:
        f "…什么意思？我很好。"
    translate None chapter_twelve_0150:
        rs "我感觉你在躲着我…"
    translate None chapter_twelve_0151:
        show fawn m sad with dis
        f "......"
    translate None chapter_twelve_0152:
        rs "是不是…因为和赛恩发生的那件事？"
    translate None chapter_twelve_0153:
        f "......"
    translate None chapter_twelve_0154:
        f "我…"
    translate None chapter_twelve_0155:
        "他又把目光从我身上移开。"

    show fawn m hur
    show raen m sur
    with dis
    translate None chapter_twelve_0156:
        f "我不希望你随便跟谁都做那些事！你…你值得比{i}他{i}好得多的人！"
    translate None chapter_twelve_0157:
        "哇哦。"
    translate None chapter_twelve_0158:
        "没想到他能说出这样的话。"
    translate None chapter_twelve_0159:
        f "我根本不相信他！他只是想利用你，用完就会把你扔到一边。"
    translate None chapter_twelve_0160:
        rs "我-"
    translate None chapter_twelve_0161:
        show fawn m sad with dis
        f "你不明白我有多-我是说…"
    translate None chapter_twelve_0162:
        f "你…我不希望你遭遇任何不幸…如果我保持沉默任由他为所欲为，我永远不会原谅自己。"

    window hide

    menu:
        "对不起，我不会再这样了":
            window show dissolve
            $ fawn_relationship +=1
            $ leos_relationship +=1
            jump fawn_sorry

        "…没事":
            window show dissolve
            $ fawn_relationship -=1
            $ cyne_relationship +=2
            jump fawn_fine

label fawn_sorry:
    show raen m sad with dis
    translate None chapter_twelve_0163:
        rs "对不起，福恩。我没想到你会这么难过。"
    translate None chapter_twelve_0164:
        "他把这件事看得太私人化了…我不想和他争吵。既然他对此反应这么强烈，那我不会再做了。"
    translate None chapter_twelve_0165:
        rs "你说得对，是我错了。我不会再犯。"
    translate None chapter_twelve_0166:
        f "......."
    translate None chapter_twelve_0167:
        f "嗯，好吧…对不起，我反应过度了…."
    translate None chapter_twelve_0168:
        f "我只是…我不…我不想看你被他带坏…"
    translate None chapter_twelve_0169:
        rs "带坏？"
    translate None chapter_twelve_0170:
        rs "抱歉…我只是在努力理解这些新鲜事物…"
    translate None chapter_twelve_0171:
        f "慢慢来没关系….你不必非要找他…"
    translate None chapter_twelve_0172:
        rs "你说得对…"
    translate None chapter_twelve_0173:
        "我轻轻揉了揉他的头发。"
    translate None chapter_twelve_0174:
        show raen m smi with dis
        rs "谢谢，福恩。"
    translate None chapter_twelve_0175:
        show fawn m shy with dis
        f "什-我-"
    translate None chapter_twelve_0176:
        f "我..没关系…."
    translate None chapter_twelve_0177:
        "赛恩和莱奥斯开始显得有些担心，于是我们朝他们走回去。"

    show raen n sad at cenleft
    show cyne n sur at cenright
    show fawn n neu at farleft
    show leos n neu at farright
    with dissolve
    jump ox_daytwocont


label fawn_fine:
    show raen m sad with dis
    translate None chapter_twelve_0178:
        rs "我明白你的意思，但…"
    translate None chapter_twelve_0179:
        rs "真的，没事。他只是想教我那些我不懂的事情。你不用这么大惊小怪。"
    translate None chapter_twelve_0180:
        f "............"
    translate None chapter_twelve_0181:
        f "那不是…那不是你需要向他学习的…你应该和重要的人一起慢慢领悟…"
    translate None chapter_twelve_0182:
        f "算了…"

    hide fawn with dissolve
    show raen at center with move
    translate None chapter_twelve_0183:
        "福恩转身走回莱奥斯和赛恩那边，留我一个人站在原地。"
    hide raen with dissolve
    translate None chapter_twelve_0184:
        "我悄悄回到了队伍中。"

    show raen n sad at cenleft
    show cyne n sur at cenright
    show fawn n neu at farleft
    show leos n neu at farright
    with dissolve
    jump ox_daytwocont

label ox_daytwocont:
    translate None chapter_twelve_0185:
        rs "那么，我们先去哪儿？"
    translate None chapter_twelve_0186:
        show leos n smi with dis
        l "要我说的话，直接回家，但既然这个选项不存在…"
    translate None chapter_twelve_0187:
        rs "对不起…我也想要那样…"
    translate None chapter_twelve_0188:
        show leos n neu with dis
        l "….不用道歉。不是你的错。"
    translate None chapter_twelve_0189:
        f "要不我们…去看看大家都在谈论的镇广场…？反正看起来是个不错的起点。"
    translate None chapter_twelve_0190:
        show cyne n hap with dis
        c "主意不错。集智慧与美貌于一身，你真是个完整个体。"
    translate None chapter_twelve_0191:
        show fawn n sad with dis
        f "......"
    translate None chapter_twelve_0192:
        f "….谢谢…？"
    translate None chapter_twelve_0193:
        rs "不知道诺克斯去哪儿了？"
    translate None chapter_twelve_0194:
        "我环顾空荡荡的房间。这里连一丝生机都没有。没有植物，没有花朵。墙上也没有挂画。"
    translate None chapter_twelve_0195:
        rs "总之先离开这里吧。今天还有很多事要做。"
    hide raen
    hide cyne
    hide leos
    hide fawn
    with dissolve
    translate None chapter_twelve_0196:
        "这次我们试着推门，发现没锁。呼。"

    stop music fadeout 3.0
    window hide dissolve

    scene bg oxhabor day big:
        size(1920, 1080)
    show raen n dim  neu at cenleft
    show cyne n dim hap at cenright
    show fawn n dim neu at farleft
    show leos n dim neu at farright
    with dissolve
    window show dissolve
    translate None chapter_twelve_0197:
        c "啊，新鲜空气！我想死你了！"
    translate None chapter_twelve_0198:
        show leos n dim cur with dis
        l "你就在里面待了一晚上。别这么夸张。"

    show cyne n dim mis with dis
    play music "sounds/bgm/Discovery.ogg" fadein 2.0
    translate None chapter_twelve_0199:
        c "噗，谁愿意整晚待在一个地方啊？有事要做，有人要见…还是说有事要见，有人要做？我老是记不清。"
    translate None chapter_twelve_0200:
        c "总之被关一整晚太闷了。都没人绑我！真浪费。"
    translate None chapter_twelve_0201:
        l "为什么？听起来像是在浪费时间。"
    translate None chapter_twelve_0202:
        show fawn n dim sad with dis
        f "...."
    translate None chapter_twelve_0203:
        show raen n dim sad with dis
        rs "所以…该往哪边走？"
    translate None chapter_twelve_0204:
        show cyne n dim hap with dis
        c "哦哦，我知道路！"
    translate None chapter_twelve_0205:
        f "你当然知道…"
    translate None chapter_twelve_0206:
        rs "怎么了？"
    translate None chapter_twelve_0207:
        f "算了。"
    translate None chapter_twelve_0208:
        "室外，阳光正奋力从厚重的灰色云层间探出头来，但此刻连这景象都显得如此宜人。"
    translate None chapter_twelve_0209:
        "我突然涌起和在斯塔格威奇时相同的感觉。尽管这里的一切都如此不同，但有些东西终究难以改变。"
    translate None chapter_twelve_0210:
        "无论我离家多远，太阳依旧东升西落，阳光依然温暖着我的脸庞。风吹拂发丝的触感，始终如一。"
    translate None chapter_twelve_0211:
        "这莫名让我感到安心。或许，我并没有真正迷失方向。"
    translate None chapter_twelve_0212:
        "更何况，我并不孤单。没有同伴们的帮助，我根本无法完成这些事。"
    translate None chapter_twelve_0213:
        "莱奥斯和赛恩正为某些事争执不休。我开始觉得他俩的相似之处比他们自己意识到的还要多。"
    translate None chapter_twelve_0214:
        show raen n dim smi with dis
        rs "哈哈，你们俩其实挺合得来的，对吧？"
    translate None chapter_twelve_0215:
        show leos n dim sur with dis
        l "啥？开什么玩笑？"
    translate None chapter_twelve_0216:
        show leos n dim ang with dis
        l "我再也想不出比这更糟糕的组合了。"
    translate None chapter_twelve_0217:
        show cyne n dim sur with dis
        c "哎呀呀，莱奥斯，你这话可真伤我心。好歹委婉点嘛？"
    translate None chapter_twelve_0218:
        l "你哪来的心？"
    translate None chapter_twelve_0219:
        c "哎哟，你这话可真伤人。"
    translate None chapter_twelve_0220:
        f "..啊哈哈哈…"
    translate None chapter_twelve_0221:
        "莱奥斯和福恩对赛恩仍心存戒备。毕竟就在昨天，他们还告诫我不要相信他。"
    translate None chapter_twelve_0222:
        "但…赛恩有种特殊的魔力让人不自觉向他敞开心扉。他善于倾听，浑身散发着与生俱来的魅力。"
    translate None chapter_twelve_0223:
        "虽然我们相识不久，但我喜欢他。该说是…有趣？"
    translate None chapter_twelve_0224:
        rs "你知道的…"
    translate None chapter_twelve_0225:
        rs "这话可能有点老套，虽然我们认识时间都不长，但是…"
    translate None chapter_twelve_0226:
        rs "真的很高兴有你们陪在我身边。"
    translate None chapter_twelve_0227:
        show leos n dim neu with dis
        l "....."
    translate None chapter_twelve_0228:
        show leos n dim smu with dis
        l "如果我是你，也会为有我作伴感到高兴的。"
    translate None chapter_twelve_0229:
        show cyne n dim hap with dis
        "福恩对我温柔浅笑，赛恩则揽住了我的腰。"
    translate None chapter_twelve_0230:
        c "开始多愁善感了？"
    translate None chapter_twelve_0231:
        show raen n dim emb with dis
        rs "才…才没有！我只是很开心！"
    translate None chapter_twelve_0232:
        l "哈！早知道你是个白痴，但没想到能蠢出新高度。杀人狂还在逍遥法外，你倒在这儿儿女情长。"
    translate None chapter_twelve_0233:
        c "杀人狂？你是指…除了你之外的那个？"
    translate None chapter_twelve_0234:
        show leos n dim neu with dis
        l "......"
    translate None chapter_twelve_0235:
        show fawn n dim neu with dis
        "福恩不动声色地抓住我的手臂，将我拉离赛恩身边。"
    translate None chapter_twelve_0236:
        l "要是你们三个闹够了，我们就出发。"
    translate None chapter_twelve_0237:
        "我们跟着赛恩穿过街道。福恩、莱奥斯和我紧随其后。没想到诺克斯的宅邸离镇中心相当远，孤零零地坐落在一片广阔的空地上。"
    translate None chapter_twelve_0238:
        "空气清新凉爽，不知为何我充满信心。今天会是个好日子。"
    translate None chapter_twelve_0239:
        show raen n dim sur with dis
        rs "喂，大伙…你们不觉得周围人太多了吗…？"
    translate None chapter_twelve_0240:
        "和昨天相比，这里几乎挤满了人。人们四处走动，忙着自己的事情。没人注意我们，只是兴奋地彼此交谈着。"
    translate None chapter_twelve_0241:
        show fawn n dim sad with dis
        f "是啊…人真多…"
    translate None chapter_twelve_0242:
        show raen n dim sad with dis
        "福恩微微缩了缩身子，显得很拘谨，但比起在斯塔格威奇时状态好多了。他正变得越来越自信，不那么害怕了，不过或许我该再关心他一下。"
    window hide

    menu:
        "关心福恩":
            $ fawn_relationship +=1
            window show dissolve
            jump ask_fawn

        "继续前进":
            window show dissolve
            jump noask_fawn


label ask_fawn:
    translate None chapter_twelve_0243:
        rs "嘿，福恩？"
    translate None chapter_twelve_0244:
        "我轻轻拉了拉他的长袖子，悄悄引起他的注意。他用眼角余光瞥了我一眼。"
    translate None chapter_twelve_0245:
        rs "这里挺忙的，对吧？你还好吗？"
    translate None chapter_twelve_0246:
        "他的目光先垂向地面，又重新抬起来与我对视。"
    translate None chapter_twelve_0247:
        show fawn n dim neu with dis
        f "...."
    translate None chapter_twelve_0248:
        f "嗯…我想还好。我只是有点担心突然发生了什么。你不觉得他们像是在…庆祝什么吗？"
    translate None chapter_twelve_0249:
        rs "…确实有这种感觉，对吧？"
    translate None chapter_twelve_0250:
        show fawn n dim sad with dis
        f "我是说..我不是说他们不能庆祝，只是这让我有点紧张。你觉得他们不会…想要伤害我吧？"
    translate None chapter_twelve_0251:
        show raen n dim sur with dis
        "这…有点跳跃啊。"
    translate None chapter_twelve_0252:
        rs "什么意思？他们为什么要伤害你？"
    translate None chapter_twelve_0253:
        f "要是他们觉得我是故意的呢？那样…他们可能会想伤害我，或者伤害你…"
    translate None chapter_twelve_0254:
        "故意做什么？"
    translate None chapter_twelve_0255:
        show raen n dim sad with dis
        rs "….你知道我不会让他们碰你，但你不用担心的。没人会伤害你。"
    translate None chapter_twelve_0256:
        f "............"
    translate None chapter_twelve_0257:
        f "要是我罪有应得呢？"
    translate None chapter_twelve_0258:
        rs "...."
    translate None chapter_twelve_0259:
        rs "就算真是那样，我也会站在你这边。我不会因为别人的看法就抛弃朋友。"
    translate None chapter_twelve_0260:
        f "…谢谢。希望只是我想多了，我们只是碰巧赶上不好的日子…但…越靠近…靠近…不，算了…"
    translate None chapter_twelve_0261:
        "越靠近什么？"
    translate None chapter_twelve_0262:
        "现在最好不要逼问他。于是我轻轻拍了拍他的背，他对我露出微笑。这才对嘛。"
    jump choice_twentytwo_done

label noask_fawn:
    translate None chapter_twelve_0263:
        "现在最好不要打扰他。他可能不想谈论这个。"
    jump choice_twentytwo_done

label choice_twentytwo_done:
    translate None chapter_twelve_0264:
        "这么热闹到底是为了什么？"
    translate None chapter_twelve_0265:
        show raen n dim sur with dis
        rs "赛恩，你知道发生什么事了吗？"
    translate None chapter_twelve_0266:
        show cyne n dim neu with dis
        c "不知道。通常我来这里只为了一件事，可不是在城里闲逛。"
    translate None chapter_twelve_0267:
        rs "哦，快看。"
    translate None chapter_twelve_0268:
        "街道两旁摆满了彩虹般五颜六色的摊位。有的堆满水果、蔬菜和其他烘焙食品，有的则陈列着小玩意和收藏品。"
    translate None chapter_twelve_0269:
        show fawn n dim sur with dis
        f "他们昨天不是都吓坏了吗…？怎么突然就在街上办起集市了？"
    translate None chapter_twelve_0270:
        rs "我…我不知道…"
    translate None chapter_twelve_0271:
        "准是发生了什么好事。除此之外没有别的解释。"
    translate None chapter_twelve_0272:
        "早前我确实说过感觉今天会是个好日子。"
    translate None chapter_twelve_0273:
        rs "那…我们要不要四处看看？肯定有人知道发生了什么事。"
    translate None chapter_twelve_0274:
        show cyne n dim hap with dis
        c "哦哟，侦探赛恩正在办案呢！"
    translate None chapter_twelve_0275:
        show leos n dim ang with dis
        l "现在不是胡闹的时候。成熟点。"
    translate None chapter_twelve_0276:
        c "我可是认真的，看好了。"
    translate None chapter_twelve_0277:
        "赛恩雄赳赳地冲上前，假装举着放大镜检查各种东西。他转回头对莱奥斯眨了眨眼，炫耀似的。"
    translate None chapter_twelve_0278:
        l "......"
    translate None chapter_twelve_0279:
        l "喂，你。"
    translate None chapter_twelve_0280:
        rs "我？"
    translate None chapter_twelve_0281:
        l "过来。"
    translate None chapter_twelve_0282:
        rs "喂—等等！"
    translate None chapter_twelve_0283:
        "莱奥斯抓住我的胳膊，把我从赛恩和福恩身边拽开，拖进了附近的小巷。"
    window hide dissolve

    stop music fadeout 2.0
    scene gallery_59 with hpunch:
        xpos 0.8 ypos 1.52 xanchor 0.5 yanchor 1.0 zoom 1.71
        linear 20.0 xpos 0.4 ypos 1.52 xanchor 0.5 yanchor 1.0 zoom 1.71
    window show dissolve
    play music "sounds/bgm/creepy.ogg" fadein 2.0
    translate None chapter_twelve_0284:
        l "听着。我不知道你在玩什么把戏，但你和那小子的来往必须停止。"
    translate None chapter_twelve_0285:
        rs "什么？那个小子？"
    translate None chapter_twelve_0286:
        l "你知道我在说谁。别接近他，别再让他跟着你转悠。"
    translate None chapter_twelve_0287:
        rs "等等…你是说赛恩？我觉得我们谈不上亲近，昨天才认识…"
    translate None chapter_twelve_0288:
        l "他却像飞蛾扑火般缠着你不放。我不喜欢这样，也不信任他。"
    translate None chapter_twelve_0289:
        l "我就是不明白你怎么能这么轻信。他明显另有所图，而你却任他予取予求。"
    translate None chapter_twelve_0290:
        rs "可是…你对他几乎一无所知，凭什么这么断定？不觉得你的评判太苛刻了吗？"
    translate None chapter_twelve_0291:
        l "这很明显！正常人不会像他那样！"
    translate None chapter_twelve_0292:
        rs "哦，所以正常人会靠放火烧山来自我介绍？"
    translate None chapter_twelve_0293:
        l "............"
    translate None chapter_twelve_0294:
        rs "再说你什么时候关心过我怎样了？为何突然这么保护过度？"
    translate None chapter_twelve_0295:
        l "什-"
    translate None chapter_twelve_0296:
        l "我才没有！哪里保护过度了？"
    translate None chapter_twelve_0297:
        rs "明明就有！你最近表现得超级古怪！"
    translate None chapter_twelve_0298:
        l "我只是…"
    scene gallery_59 with dissolve
    translate None chapter_twelve_0299:
        l "这都怪你！"
    translate None chapter_twelve_0300:
        rs "你到底在说什么啊？！"
    translate None chapter_twelve_0301:
        l "我不想靠近你。不想有这种感觉！"
    translate None chapter_twelve_0302:
        l "可你偏要强行贴近，即便我试图推开。现在我只能护你周全。你当初根本就不该帮我。"
    translate None chapter_twelve_0303:
        l "我不能让你…不像他们那样…"
    translate None chapter_twelve_0304:
        rs "什么？那不是我的错！难道你宁愿我们当时就丢下你等死吗？"
    translate None chapter_twelve_0305:
        l "没错！你们就应该那么做。"
    translate None chapter_twelve_0306:
        l "你可能觉得自己救了我的命，但只不过让我活得更加艰难罢了。"
    translate None chapter_twelve_0307:
        l "我做不到…我没法保护你…尤其是你总他妈作出这些愚蠢决定的时候！简直就像在求着别人绑架你卖去当奴隶似的！"
    translate None chapter_twelve_0308:
        rs "听着…你不需要保护我。我能保护自己。我不是小孩子了。"
    translate None chapter_twelve_0309:
        rs "…况且你也不欠我什么。我只是做了任何正派人都会做的事。"
    translate None chapter_twelve_0310:
        l "那这世上大多数人都不如你正直。"
    translate None chapter_twelve_0311:
        l "而我…我欠你的远比你以为的要多，相信我。"
    translate None chapter_twelve_0312:
        "他把脸转开了。究竟经历过什么才会让他变成这样？"
    translate None chapter_twelve_0313:
        "他脸上带着痛苦焦灼的神情。仿佛失去我就是世界末日。"
    translate None chapter_twelve_0314:
        "我早已习惯他暴躁的模样…这副伤心的表情实在不适合他。"

    stop music fadeout 2.0

    show gallery_60 with dissolve
    translate None chapter_twelve_0315:
        rs "别摆出那种丧气脸！振作点！"
    play music "sounds/bgm/night.ogg" fadein 3.0
    translate None chapter_twelve_0316:
        l "你-你干什么？！"
    translate None chapter_twelve_0317:
        rs "什么干什么？我在抱你啊。你该不会连拥抱是什么都不知道吧？那可太惨了。"
    translate None chapter_twelve_0318:
        l "知-知道啊！但为什么？！"
    translate None chapter_twelve_0319:
        rs "你看上去需要个拥抱。"
    translate None chapter_twelve_0320:
        l "放开我…"
    translate None chapter_twelve_0321:
        rs "再抱会儿。"
    translate None chapter_twelve_0322:
        "他个子太高了，我都不确定这样能否安慰到他…不过要是能让他稍微开心点…说真的，这感觉也不赖。"
    translate None chapter_twelve_0323:
        rs "抱歉。我还是不太明白，但你只是想要保护我对吧？"
    translate None chapter_twelve_0324:
        l "......"
    translate None chapter_twelve_0325:
        rs "我知道我们开始得很糟糕…但我想和你做朋友。你不想吗？"
    translate None chapter_twelve_0326:
        l "我…不想，但事到如今我还有选择吗？"
    translate None chapter_twelve_0327:
        l "当我的朋友很危险。你确定？"
    translate None chapter_twelve_0328:
        rs "当然。现在当我的朋友也挺危险的，我们扯平了。"
    translate None chapter_twelve_0329:
        "当我终于抬头看向他的脸时，他躲开了我的视线。他脸颊泛红，表情近乎痛苦。"
    translate None chapter_twelve_0330:
        l "好了好了，我知道了。快松手吧，你的意思我明白了。"
    translate None chapter_twelve_0331:
        rs "遵命长官！"
    window hide dissolve

    scene bg ox alley big with dissolve:
        size (1920, 1080)
    window show dissolve
    translate None chapter_twelve_0332:
        "我赶紧松开他。再抱下去我怕是会有生命危险。"
    translate None chapter_twelve_0333:
        l emb  "别把这事告诉其他人，嗯？"
    translate None chapter_twelve_0334:
        rs sad "好吧…那个…"
    translate None chapter_twelve_0335:
        rs sad "我会尽量小心的，好吗？"
    translate None chapter_twelve_0336:
        rs sad "但对赛恩好一点…"
    translate None chapter_twelve_0337:
        l emb "没门。"
    window hide dissolve
    stop music fadeout 2.0

    scene bg oxhabor day big with dissolve:
        size(1920, 1080)
    window show dissolve
    translate None chapter_twelve_0338:
        "当我们找到回去的路时，赛恩正围着福恩打转，福恩看起来有点害怕。"

    show raen n dim neu at cenright
    show cyne n dim hap at cenleft
    show fawn n dim sad at farleft
    show leos n dim emb at farright
    with dissolve
    play music "sounds/bgm/Fooling Around Tiny.ogg" fadein 2.0
    translate None chapter_twelve_0339:
        c "拜托，你可以告诉我的！你完全喜欢他吧？你已经完完全全沦陷了！"
    translate None chapter_twelve_0340:
        show fawn n dim emb with dis
        f "不，我…我甚至不知道你在说什-"
    translate None chapter_twelve_0341:
        rs "嘿伙计们。你们在聊什么？"
    translate None chapter_twelve_0342:
        show fawn n dim hur with dis
        f "没什么！"
    translate None chapter_twelve_0343:
        c "嘿嘿嘿。"
    translate None chapter_twelve_0344:
        c "噢，更重要的是，你们两个刚才在说什么？"

    show raen at cenleft
    show cyne at cenright
    with move
    translate None chapter_twelve_0345:
        "赛恩迅速走到莱奥斯身边，这让莱奥斯很恼火。"
    translate None chapter_twelve_0346:
        c "嗯哼，我看到了什么？我们这位不苟言笑、脾气暴躁的看门狗脸都红透了！"
    translate None chapter_twelve_0347:
        l "我没有。别围着我转。"
    translate None chapter_twelve_0348:
        l "还有别那么叫我。"
    translate None chapter_twelve_0349:
        c "为什么不？这是事实。汪汪！"
    translate None chapter_twelve_0350:
        show fawn n dim neu with dis
        f "….你会是只很可爱的狗，莱奥斯。"
    translate None chapter_twelve_0351:
        #added voice mapping to chapter_twelve_0324 - check
        l "呃…"
    translate None chapter_twelve_0352:
        rs "没关系，不是什么大事。我们别浪费时间了，去看看集市吧，可能会有人知道是怎么回事。"
    translate None chapter_twelve_0353:
        "我们越靠近，人群的声音就越嘈杂。店主和帮手们在摊位间忙忙碌碌，交易叫卖。孩子们跑来跑去玩耍，每个人看起来都很开心。从某个遥远的角落，一首轻柔的旋律向我们飘来。"
    translate None chapter_twelve_0354:
        f "一切都那么…生机勃勃。对一个弥漫着死亡气息的镇子来说，这有点…令人不安。"

    hide fawn
    hide leos
    hide cyne
    hide raen
    show bg oxhabor day big:
        xpos -0.01 ypos -0.44 zoom 1.52
        linear 55.0 xpos -0.52
    with dissolve
    translate None chapter_twelve_0355:
        "这很好，但…经历了昨天之后很诡异…我想享受这种氛围，但我不由自主地感到紧张。"
    translate None chapter_twelve_0356:
        "我们慢慢地在摊位间穿行，挤过层层人群。"
    translate None chapter_twelve_0357:
        "气氛与之前截然不同。我想说服自己昨天只是碰巧在倒霉的日子到来，但是…肯定有什么原因能解释为何大家突然都这么兴高采烈。"
    translate None chapter_twelve_0358:
        "简直人山人海。透过密集的人群甚至看不到地面。"
    translate None chapter_twelve_0359:
        "我们慢慢感受着集市的景象和气味。香料、水果、香水…如此多的气味。"
    translate None chapter_twelve_0360:
        "有些摊位的布料颜色我见都没见过。还有些摆着装饰繁复金纹的餐具，精美雅致。"
    translate None chapter_twelve_0361:
        "珠串首饰玩偶和-"
    translate None chapter_twelve_0362:
        "等一下。"
    translate None chapter_twelve_0363:
        stop music fadeout 3.0
        "大家都去哪儿了？"
    translate None chapter_twelve_0364:
        "这边…？不对，这边？"
    translate None chapter_twelve_0365:
        "他们全都不见了。"
    translate None chapter_twelve_0366:
        "左边，右边，回头望去，前方…我看不见任何人。人群中既找不到红发或蓝发的踪迹，赛恩也消失得无影无踪。"
    translate None chapter_twelve_0367:
        "当然，以他那个身高，本来就不指望能轻易发现。"



    scene bg oxhabor day big with dissolve:
        size(1920, 1080)
    translate None chapter_twelve_0368:
        u "喂，让一让。"
    translate None chapter_twelve_0369:
        rs sur "啊，抱歉！"
    translate None chapter_twelve_0370:
        "或许突然停在路中间不是个好主意…眼下还是先找找他们吧。"
    translate None chapter_twelve_0371:
        "不远处有块小空地，比市场其他地方安静得多。那里应该不错。"
    translate None chapter_twelve_0372:
        "我缓慢地穿梭在熙攘人群间，向那片空地移动。尽量不碰到任何人，但在这种地方难免会有擦撞。"
    translate None chapter_twelve_0373:
        "叹了口气，我靠墙站定，打量四周。"
    translate None chapter_twelve_0374:
        play music "sounds/bgm/tavern.ogg" fadein 3.0
        "情不自禁露出微笑。每个人都欢快地忙碌穿梭，随着音乐起舞，愉快地交谈。"
    translate None chapter_twelve_0375:
        "真是…令人神清气爽。甚至称得上兴奋。连家乡的市场都没有这种氛围。"
    translate None chapter_twelve_0376:
        "每个人都显得…很快乐。发自内心的快乐。"
    translate None chapter_twelve_0377:
        "不过这有点离题了。我该怎么找到他们呢？他们也会在找我吗？"
    translate None chapter_twelve_0378:
        "希望另外三个能待在一起。等莱奥斯找到我肯定会训斥一番。说实话最担心福恩，他向来不擅长应付人群。"
    translate None chapter_twelve_0379:
        "赛恩肯定没问题，他的自信和魅力足够应付任何状况。莱奥斯…会气喘吁吁地出现，假装根本不是在找我。"
    translate None chapter_twelve_0380:
        "想到这里，我决定在这里多待会儿。这是个放慢节奏感受世界的难得机会。"
    translate None chapter_twelve_0381:
        "先是五分钟过去。接着十分钟、二十分钟、三十分钟…依然不见同伴踪影。"
    translate None chapter_twelve_0382:
        "看来如果不主动寻找，日落时分我还得在这儿傻站着，而我们还有正事要办。总不能杵一整天。"
    translate None chapter_twelve_0383:
        "我挺直身子活动肩膀。好吧，是时候去找他们了。"
    translate None chapter_twelve_0384:
        "缓步回到摊位区。说不定逛逛就能碰上熟面孔。"
    translate None chapter_twelve_0385:
        "只需稍稍推挤，我便穿过熙攘的过道，同时仔细留意着朋友们的身影。近距离观察下，各式货物显得愈发引人注目。"
    translate None chapter_twelve_0386:
        "如果在家乡看到这些，我肯定会—好吧，实际上我大概买不起，但一定会怀着极大的兴趣驻足观赏。"
    translate None chapter_twelve_0387:
        "每个摊位都与前一个迥然不同，令人目眩神迷。"
    translate None chapter_twelve_0388:
        "我尽量避免在任何一个摊位前停留太久。囊中羞涩，也不愿占用真正顾客的空间。"
    translate None chapter_twelve_0389:
        "每当与摊主视线相遇时，我便微笑示意后离开。真是尴尬…"
    translate None chapter_twelve_0390:
        "在市场中部，我发现了个由独居少女经营的小摊。她橙色的秀发恰好垂至肩下，如扇般披散开来。"
    translate None chapter_twelve_0391:
        "她出售的连帽斗篷几乎囊括所有想得到的颜色。那些斗篷看起来厚实温暖，针脚精巧繁复。仅匆匆一瞥就能感受到上乘品质。"
    translate None chapter_twelve_0392:
        "拥有这样的珍品对我而言只能是梦想。我用指尖轻轻抚过那些细密整齐的针脚。"
    translate None chapter_twelve_0393:
        "抬头时，目光与那位看摊的少女骤然相接。糟糕，该走了。"
    translate None chapter_twelve_0394:
        u "你看起来有点迷路呢"
    translate None chapter_twelve_0395:
        show raen n dim sur with dis
        rs "....?"
    translate None chapter_twelve_0396:
        "她仅凭观察就能看出来吗？"
    translate None chapter_twelve_0397:
        rs "呃…确实如此。你怎么知道的？"
    translate None chapter_twelve_0398:
        u "过去几分钟里，我一直在看你来回走动"
    translate None chapter_twelve_0399:
        show raen n dim sad with dis
        rs "啊…"
    translate None chapter_twelve_0400:
        u "每月这个时候总是很忙。需要我给你指路吗？"
    translate None chapter_twelve_0401:
        rs "不用了，谢谢。其实我只是在找朋友们。我们逛着逛着走散了"
    translate None chapter_twelve_0402:
        u "明白了。那我可能帮不上什么忙了。今天这里已经经过太多人了"
    translate None chapter_twelve_0403:
        rs "可以想象。说起来，既然在这里…"
    translate None chapter_twelve_0404:
        rs "今天是什么特殊日子吗？我昨天刚到，那时大家都紧闭门户"
    translate None chapter_twelve_0405:
        u "今天…可以说是特别的日子。大家都在庆祝又平安度过了一个月"
    translate None chapter_twelve_0406:
        rs ".....?"
    translate None chapter_twelve_0407:
        u "还有什么能帮你的吗？我看你对这些很感兴趣"
    translate None chapter_twelve_0408:
        "她把 hand 放在我正欣赏的那件斗篷边缘。它确实美不胜收。"
    translate None chapter_twelve_0409:
        show raen n dim smi with dis
        rs "真漂亮。希望有天我也能拥有这样一件"
    translate None chapter_twelve_0410:
        u "谢谢。很少有人驻足细看，所以我很感激"
    translate None chapter_twelve_0411:
        rs "看得出做工很精细。我以前也缝过东西，但远不及这种水平。"
    translate None chapter_twelve_0412:
        rs "总之，我想我该开始找我的—"
    translate None chapter_twelve_0413:
        c hap"哦，拉—恩！！！"
    translate None chapter_twelve_0414:
        "我转身朝向那个熟悉的声音。能看到他的小脑袋随着跳跃上下晃动，试图吸引我的注意。"
    translate None chapter_twelve_0415:
        u "…这是你失散的朋友之一吗？"
    translate None chapter_twelve_0416:
        show raen n dim sad with dis
        rs "….我不认识他。"
    translate None chapter_twelve_0417:
        "我转回身去。"
    translate None chapter_twelve_0418:
        rs "那我该走了，谢谢！"
    translate None chapter_twelve_0419:
        "我挥手道别，朝赛恩走去。天啊，他真是闹出好大动静。这里可不适合这样…"
    translate None chapter_twelve_0420:
        "路过时几个人盯着我看，但从他们眼神里看不出敌意。呼，可以稍微放松点了。"
    translate None chapter_twelve_0421:
        show raen n dim sur with dis
        rs "赛恩！这边！"

    show raen at slightleft with move
    show cyne n dim hap at slightright with dis
    translate None chapter_twelve_0422:
        c "拉—恩，哦，我好想你！"
    translate None chapter_twelve_0423:
        "他几乎跳到我身上，紧紧抱着。我迅速把他放下来，抓住他袖口边缘。"
    translate None chapter_twelve_0424:
        "我不想再走散了。虽然不久前莱奥斯警告过我关于赛恩的事，但在这个陌生地方，有他在身边总比完全独自一人更安心。"
    translate None chapter_twelve_0425:
        show raen n dim sad with dis
        rs "真高兴找到你。走散后我谁都找不到…"
    translate None chapter_twelve_0426:
        rs "你有见到另外两个人吗？"
    translate None chapter_twelve_0427:
        "他低头看了眼我的手，然后仰头冲我微笑。"
    translate None chapter_twelve_0428:
        c "知道吗，我可能会爱上这样。"
    translate None chapter_twelve_0429:
        rs "什么？"
    translate None chapter_twelve_0430:
        c "你那样喊我名字的样子。能再为我喊一次吗？"
    translate None chapter_twelve_0431:
        rs "呃…"
    translate None chapter_twelve_0432:
        rs "喊你的名字？"
    translate None chapter_twelve_0433:
        c "我的名字从你舌尖滚落的样子…太美妙了。"
    translate None chapter_twelve_0434:
        rs "赛恩…？"
    translate None chapter_twelve_0435:
        show cyne n dim mis with dis
        c "哇，你听话的样子真可爱！真是个好男孩对不对？"
    translate None chapter_twelve_0436:
        c "也许不是男孩，是小狗？有时候我都能想象你摇尾巴的样子。"
    translate None chapter_twelve_0437:
        rs "….我真不明白你在说什么。见鬼，我觉得我也不想明白。"
    translate None chapter_twelve_0438:
        c "如果你好好请求，晚点我可以教你哦。"
    translate None chapter_twelve_0439:
        rs "…行吧。但现在你先告诉我，见到另外两个人了吗？这个更重要。"
    translate None chapter_twelve_0440:
        show cyne n dim sur with dis
        c "热裤小子和吱吱叫？没，没见到。"
    translate None chapter_twelve_0441:
        c "不过找他们应该不难。"
    translate None chapter_twelve_0442:
        rs "呃…我是说莱奥斯和福恩…."
    translate None chapter_twelve_0443:
        show cyne n dim hap with dis
        c "对啊，我就是这么说的。"
    translate None chapter_twelve_0444:
        rs "....."
    translate None chapter_twelve_0445:
        rs "好吧…我找了好一会儿了，但现在只找到你。"
    translate None chapter_twelve_0446:
        c "说不定他俩正单独约会呢？"
    translate None chapter_twelve_0447:
        rs "我也希望如此。我觉得莱奥斯应该没问题，但我不想让福恩一个人被困在这儿。"
    translate None chapter_twelve_0448:
        c "哈哈…可怜的、可爱的雷恩。至少你的天真很讨人喜欢。"
    translate None chapter_twelve_0449:
        rs "什么？"
    translate None chapter_twelve_0450:
        c "那我们一起去找你的同伴们吧？抓紧别松手，我可不想你又走丢了！"
    translate None chapter_twelve_0451:
        show raen n dim smi with dis
        rs "当然。谢谢，赛恩。"
    translate None chapter_twelve_0452:
        c "我的荣幸。"
    translate None chapter_twelve_0453:
        "他向我眨了眨眼，然后转身扫视人群。"
    translate None chapter_twelve_0454:
        show cyne n dim mis with dis
        c "跟我来，小帅哥。看看能不能逮住几个男人。"
    translate None chapter_twelve_0455:
        "我们穿行在市场里，仔细搜寻着其他人的踪迹。一路上我们在各个摊位驻足，赛恩会和摊主们交谈。"
    translate None chapter_twelve_0456:
        "他说话时，对话就自然而然地流动。就像…该怎么说…他的声音让人不由自主想听。和他平时的表现完全不同。"

    hide cyne with dissolve
    show raen at center with move
    show raen n dim sur with dis

    translate None chapter_twelve_0457:
        "突然，赛恩瞪大了眼睛，从我身边冲了出去。"
    translate None chapter_twelve_0458:
        rs "等等，赛恩！"
    translate None chapter_twelve_0459:
        "我追着他跑到了前面另一个摊位。"
    translate None chapter_twelve_0460:
        show raen at slightleft with move
        show cyne n dim hap at slightright with dis
        c "雷恩，雷恩，快看！我给你找到好东西了！哈哈哈！"
    translate None chapter_twelve_0461:
        rs "什-"
    translate None chapter_twelve_0462:
        "他从摊位上拿起一个紫色蔬菜，举起来给我看。"
    translate None chapter_twelve_0463:
        show raen n dim sad with dis
        rs "呃…."
    translate None chapter_twelve_0464:
        c "这是什么？！"
    translate None chapter_twelve_0465:
        rs "呃…看起来像是茄子…？不算什么稀罕东西。"
    translate None chapter_twelve_0466:
        show cyne n dim sur with dis
        c "等等等，茄子长这样？！"
    translate None chapter_twelve_0467:
        rs "...?"
    translate None chapter_twelve_0468:
        rs "就是种蔬菜…有什么好惊讶的？"
    translate None chapter_twelve_0469:
        show cyne n dim mis with dis
        c "哇，看这个弧度！"
    translate None chapter_twelve_0470:
        "他的手指顺着茄子的曲线抚摸着，全程都在傻笑。"
    translate None chapter_twelve_0471:
        c "你喜欢这么大的还是想要稍小点的？"
    translate None chapter_twelve_0472:
        rs "呃…这很重要吗？要是太小的话就吃两个呗。"
    translate None chapter_twelve_0473:
        show cyne n dim sur with dis
        c "哇哦。"
    translate None chapter_twelve_0474:
        c "够生猛啊，雷恩。"
    translate None chapter_twelve_0475:
        show raen n dim sur with dis
        rs "等等，等等，往回说。你怎么会不知道茄子长啥样？你不是会…做饭吗？"
    translate None chapter_twelve_0476:
        c "做饭？我？怎么可能？"
    translate None chapter_twelve_0477:
        rs "…..为了防止饿死？你总要吃饭的吧？"
    translate None chapter_twelve_0478:
        c "啊？这种事情不是都有人替你做的吗？"
    translate None chapter_twelve_0479:
        rs "......?"
    translate None chapter_twelve_0480:
        c "哦，我有个问题。你们做饭前会洗这个吗？"
    translate None chapter_twelve_0481:
        rs "当然？不然上面都是泥。你…不想吃土吧？"
    translate None chapter_twelve_0482:
        show cyne n dim mis with dis
        c "哦哦，像这样？是这样弄的吗？"
    translate None chapter_twelve_0483:
        "他用手握住茄子握成拳头，上下滑动，用力地搓揉着。"
    translate None chapter_twelve_0484:
        c "我觉得这茄子擦得够~干净了。雷恩，看我擦得多好！"
    translate None chapter_twelve_0485:
        "等等，这形状怎么像是—"
    translate None chapter_twelve_0486:
        show raen n dim emb with dis
        "天啊…昨晚…我感觉脸颊瞬间发烫。他该不会要在…大庭广众之下…"
    translate None chapter_twelve_0487:
        "这个性变态！看起来简直像—"
    translate None chapter_twelve_0488:
        rs "喂！快住手！"
    translate None chapter_twelve_0489:
        "我一把夺过他手里的东西。别在这儿！这不是干这事的地方！！！"
    translate None chapter_twelve_0490:
        c "哇喔小心点拿茄子啊雷恩，捏坏了多可惜！"
    translate None chapter_twelve_0491:
        rs "你…能不能别这么…"
    translate None chapter_twelve_0492:
        c "看你这反应…想必已经充分掌握我教的内容了！老师很欣慰啊！真是好学生~"
    translate None chapter_twelve_0493:
        rs "......."
    translate None chapter_twelve_0494:
        rs "给。我。闭。嘴。"
    translate None chapter_twelve_0495:
        show cyne n dim hap with dis
        c "害羞了？噢~我懂了，你是把茄子想象成你那根了对吧？"
    translate None chapter_twelve_0496:
        c "想要就直说嘛。用手、用嘴、用后面…随你挑哦。"
    translate None chapter_twelve_0497:
        "他窃笑着把茄子抢了回去。"
    translate None chapter_twelve_0498:
        c "老板！这茄子我们买了！"
    translate None chapter_twelve_0499:
        "什么…？"
    translate None chapter_twelve_0500:
        "他买这玩意儿干嘛？！"
    translate None chapter_twelve_0501:
        "我目瞪口呆地看着他掏出钱袋和摊主交易。那混蛋把茄子搂在怀里一脸坏笑。"
    translate None chapter_twelve_0502:
        rs "不是…你干嘛要买那个？！"
    translate None chapter_twelve_0503:
        c "你说呢？"
    translate None chapter_twelve_0504:
        rs "你他妈在逗我…"
    translate None chapter_twelve_0505:
        c "当然是做菜用啊！小处男思想咋这么肮脏呢~"
    translate None chapter_twelve_0506:
        rs "....."
    translate None chapter_twelve_0507:
        rs "我记得你说过不会做饭。"
    translate None chapter_twelve_0508:
        c "这个嘛…具体用法可以慢慢研究，总能派上用场的~"
    translate None chapter_twelve_0509:
        show raen n dim sad with dis
        rs "...."
    translate None chapter_twelve_0510:
        rs "算了。"
    translate None chapter_twelve_0511:
        c "对了，既然都来了…"
    translate None chapter_twelve_0512:
        show cyne n dim neu with dis
        c "这位大哥，能不能告诉我们出什么事了？昨天进城就发现家家户户都闭门不出。"
    translate None chapter_twelve_0513:
        "摊主见我们只买根茄子，没好气地耸耸肩。"
    translate None chapter_twelve_0514:
        c "嗯…"
    translate None chapter_twelve_0515:
        c "要不…用这个撬开您的金口？"
    translate None chapter_twelve_0516:
        "赛恩在摊主眼前晃了晃钱袋，对方立刻两眼放光。"
    translate None chapter_twelve_0517:
        u "…少爷想知道什么尽管问。"
    translate None chapter_twelve_0518:
        c "上道！说说今天怎么回事？"
    translate None chapter_twelve_0519:
        u "不知道您各位听说多少—"
    translate None chapter_twelve_0520:
        c "有人失踪，有些变成了尸体，诸如此类的事。"
    translate None chapter_twelve_0521:
        "他对赛恩漫不经心的语气露出了厌恶的神色，但还是继续说了下去。"
    translate None chapter_twelve_0522:
        stop music fadeout 2.0
        u "嗯…马上就要到…到时候了。"
    translate None chapter_twelve_0523:
        rs "到时候？"
    translate None chapter_twelve_0524:
        u "就是献祭的时候。"
    translate None chapter_twelve_0525:
        "献祭？这种说法真奇怪…"
    translate None chapter_twelve_0526:
        c "很好，但你还没回答我的问题。"
    translate None chapter_twelve_0527:
        "他晃了晃钱袋，商人赶忙纠正错误。"
    translate None chapter_twelve_0528:
        play music "sounds/bgm/creepy.ogg" fadein 2.0
        u "啊，这不是很明显吗？既然他们已被选中，我们就能恢复正常生活。至少在下一次之前。"
    translate None chapter_twelve_0529:
        c "嗯…"
    translate None chapter_twelve_0530:
        show cyne n dim hap with dis
        c "给，先生。请享用！"
    translate None chapter_twelve_0531:
        "他把钱袋扔向那个人，然后拽着我离开。"
    translate None chapter_twelve_0532:
        show cyne n dim neu with dis
        c "我有种不祥的预感…"
    translate None chapter_twelve_0533:
        rs "什么意思？"
    translate None chapter_twelve_0534:
        c "我们—"
    translate None chapter_twelve_0535:
        l ang "喂！你们俩！"

    show raen at cenleft
    show cyne at cenright
    with move
    show leos n dim ang at farright
    show fawn n dim sad at farleft
    with dis

    translate None chapter_twelve_0536:
        "莱奥斯挤过人群向我们走来，手臂后方拖着福恩。"
    translate None chapter_twelve_0537:
        show raen n dim sur with dis
        rs "莱奥斯！福恩！真高兴见到你们-"
    translate None chapter_twelve_0538:
        l "坏消息。跟我来。"
    translate None chapter_twelve_0539:
        "他转身就走，仍然拽着身后的福恩。"
    translate None chapter_twelve_0540:
        "我和赛恩小跑着跟上他们。"
    translate None chapter_twelve_0541:
        rs "怎么回事？"
    translate None chapter_twelve_0542:
        f "我转身时你们就不见了。我想去找你们，但莱奥斯让我跟着他…"
    translate None chapter_twelve_0543:
        rs "他有照顾你吗？"
    translate None chapter_twelve_0544:
        "听到我的问题他瞪大了眼睛。"
    translate None chapter_twelve_0545:
        f "嗯…算是有吧？"
    translate None chapter_twelve_0546:
        show cyne n dim hap with dis
        c "哎呀，原来我家莱奥斯是个软心肠呢。"
    translate None chapter_twelve_0547:
        l "闭嘴。我才不是\"你家的\"什么。"
    translate None chapter_twelve_0548:
        c "再抱会儿。"
    translate None chapter_twelve_0549:
        l "什么？"
    translate None chapter_twelve_0550:
        l "再说，我当时也没得选。"
    translate None chapter_twelve_0551:
        show raen n dim neu with dis
        rs "嗯…"
    translate None chapter_twelve_0552:
        "我打量着他，他的性格似乎和我最初想象的大不相同。"
    translate None chapter_twelve_0553:
        f "…..我都不太想问…你拿着茄子干什么…？"
    translate None chapter_twelve_0554:
        c "哈？怎么了？说不定以后用得上。"
    translate None chapter_twelve_0555:
        f "…..当我没问。"
    translate None chapter_twelve_0556:
        rs "所以，到底什么消息？"
    translate None chapter_twelve_0557:
        show leos n dim ang with dis
        l "看。"
    translate None chapter_twelve_0558:
        show cyne n dim neu with dis
        "他突然停下。在集市摊位的尽头有块大布告板，贴满了传单、地图和便条。"
    translate None chapter_twelve_0559:
        "板子中央是官方公告。婚讯、新生儿、讣告…"
    translate None chapter_twelve_0560:
        show raen n dim con with dis
        rs "这怎么了？"
    translate None chapter_twelve_0561:
        l "你是白痴吗？还记得诺克斯跟我们说的话吗？"
    translate None chapter_twelve_0562:
        rs "当然…名字出现在-"

    show raen n sur at shake
    translate None chapter_twelve_0563:
        rs "...!!!"
    translate None chapter_twelve_0564:
        "名字出现在布告板上…所有人都在庆祝…"
    translate None chapter_twelve_0565:
        "我快速浏览名单。"
    translate None chapter_twelve_0566:
        "讣告。吉尔斯、塔恩、西达、恩内尔…"
    translate None chapter_twelve_0567:
        "雷恩。"
    translate None chapter_twelve_0568:
        show raen n dim wor with dis
        rs "什么…这怎么可能 - 我明明不是-"
    translate None chapter_twelve_0569:
        c "你也听说过那个传言吧。名字出现在这里的人都会死。这感觉有点不祥。"
    translate None chapter_twelve_0570:
        show fawn n dim hur with dis
        f "肯定…肯定是指另一个叫雷恩的人！一定是这样！"
    translate None chapter_twelve_0571:
        "我艰难地咽了咽口水。肯定…是这样的，对吧…？"
    translate None chapter_twelve_0572:
        "我看向三个同伴。他们都面色凝重，难以揣测。"
    translate None chapter_twelve_0573:
        "…..没人觉得是指别的雷恩。"
    translate None chapter_twelve_0574:
        rs "我…我该怎么办……？"
    translate None chapter_twelve_0575:
        l "我们走。立刻收拾东西逃跑。"
    translate None chapter_twelve_0576:
        rs "可是那-"
    translate None chapter_twelve_0577:
        show leos n dim hur with dis
        l "没有可是。这…这不是开玩笑！这是在说你性命攸关的事。别总想着当英雄。"
    translate None chapter_twelve_0578:
        f "....."
    translate None chapter_twelve_0579:
        c "....."
    translate None chapter_twelve_0580:
        "我的手指抚过那些字迹，有些墨水沾到了手上。字迹还很新。"
    translate None chapter_twelve_0581:
        f "我…我同意…我觉得我们不能留在这里，太危险了。"
    translate None chapter_twelve_0582:
        c "真的吗？说不定逃跑正是他们想要的结果？"
    translate None chapter_twelve_0583:
        l "那你有什么建议？坐在这里等死吗！？"
    translate None chapter_twelve_0584:
        c "显然，我们要解开这个谜题。赶在任何人或任何东西伤害他之前。很简单，是吧？"
    translate None chapter_twelve_0585:
        l "这太冒险了。我不同意。"
    translate None chapter_twelve_0586:
        show cyne n dim ang with dis
        c "这是你能决定的吗？"
    translate None chapter_twelve_0587:
        show leos n dim pis with dis
        l "怎么，你觉得我在乎你的意见？你不过是昨天开始跟着我们的流浪汉。我们根本不认识你。"
    translate None chapter_twelve_0588:
        c "哦？派来杀他的人不是你吗？要说谁的意见不值一提，那应该是你吧。"
    translate None chapter_twelve_0589:
        c "说不定你自己就打算杀他呢。不想让别人抢了这个功劳？"
    translate None chapter_twelve_0590:
        show leos n dim ang with dis
        l "不！我不会-"
    translate None chapter_twelve_0591:
        c "为什么不会？我们怎么知道能相信你的话？"
    translate None chapter_twelve_0592:
        l "......"
    translate None chapter_twelve_0593:
        c "没话说了？"
    translate None chapter_twelve_0594:
        l "…..我欠他一条命。我是来保护他的，仅此而已。"
    translate None chapter_twelve_0595:
        c "抱歉，你说什么？你在那么远的地方嘟囔，我听不清。"
    translate None chapter_twelve_0596:
        show leos n dim emb with dis
        l "我说我会保护他！"
    translate None chapter_twelve_0597:
        rs "...."
    translate None chapter_twelve_0598:
        "我…我甚至没法回应。我该怎么做？"
    translate None chapter_twelve_0599:
        f "....."
    translate None chapter_twelve_0600:
        show fawn n dim sad with dis
        f "为什么不直接问问雷恩…？"
    translate None chapter_twelve_0601:
        c "好主意！"
    translate None chapter_twelve_0602:
        "他们都热切地看着我。"
    window hide

    menu:
        "尝试离开":
            window show dissolve
            jump badend_three

        "尝试解开谜题":
            window show dissolve
            jump chapter_thirteen_start


label badend_three:
    translate None chapter_twelve_0603:
        rs "我…我觉得我们应该离开…我还能有什么选择…？"
    translate None chapter_twelve_0604:
        c "就这样抛弃诺克斯？抛弃所有村民？"
    show leos n ang with dis
    translate None chapter_twelve_0605:
        l "我说过了，解决别人的问题不是我们的职责。我们只是碰巧在这里。"
    translate None chapter_twelve_0606:
        l "你做了正确的选择。我们立刻动身。"
    translate None chapter_twelve_0607:
        f "好吧…"
    translate None chapter_twelve_0608:
        c "别算上我。没想到你这么胆小。"
    translate None chapter_twelve_0609:
        c "我猜你终究还是个无聊的人。"

    hide cyne with dissolve
    show raen at center
    show fawn at left
    show leos at right
    with move

    translate None chapter_twelve_0610:
        "说完这句话，赛恩消失在人群之中。这…不是个错误的选择，对吧…？"
    translate None chapter_twelve_0611:
        rs "我们该去哪..？"
    translate None chapter_twelve_0612:
        l "无所谓。只要离开这里就行。"

    hide fawn
    hide leos
    hide raen
    with dissolve

    translate None chapter_twelve_0613:
        "莱奥斯拽着我和福恩的手臂，快速冲出市场。"

    show bg black with eye_shut
    translate None chapter_twelve_0614:
        "我紧紧闭上眼睛，拼命试图恢复镇定。"


    show bg ox bad with eye_open:
        xpos -0.01 ypos -0.44 zoom 1.52
        linear 45.0 xpos -0.52

    translate None chapter_twelve_0615:
        "当我再次睁眼时，先前那些看似友善热闹的人群突然变得面目可憎。时间仿佛在我周围慢了下来。"
    translate None chapter_twelve_0616:
        "每个人—所有人都在盯着我。他们的目光刺穿了我。他们在笑。"
    translate None chapter_twelve_0617:
        "指指点点，哄堂大笑。"
    translate None chapter_twelve_0618:
        "嘲笑着我，庆祝着我的死亡。 "
    translate None chapter_twelve_0619:
        "他们想要我—"
    translate None chapter_twelve_0620:
        f sad "雷恩？"


    scene bg oxhabor day big with vpunch:
        size(1920,1080)

    translate None chapter_twelve_0621:
        rs sad "嗯？！"
    translate None chapter_twelve_0622:
        "一切恢复正常。原来根本没人看着我。我只是…产生了幻觉。"
    translate None chapter_twelve_0623:
        f sad "你…你还好吗？"
    translate None chapter_twelve_0624:
        rs sad "…嗯，我没事。"


    show bg black with eye_shut

    translate None chapter_twelve_0626:
        "我闭上眼睛，任由莱奥斯拉着我前行。呃，头好痛。"
    translate None chapter_twelve_0627:
        n "抛弃他们。推开他们然后离开。"
    translate None chapter_twelve_0628:
        "什么？"
    translate None chapter_twelve_0629:
        "抛弃他们…？"
    translate None chapter_twelve_0630:
        n "他们想伤害你。他们想杀了你。"
    translate None chapter_twelve_0631:
        "谁？"
    translate None chapter_twelve_0632:
        n "你的朋友们。他们想看着你痛苦挣扎，乞求死亡。"
    translate None chapter_twelve_0633:
        "福恩和莱奥斯？他们不会—"
    translate None chapter_twelve_0634:
        n "他们想要你死。他们想看着你在路边慢慢流血而亡。"
    translate None chapter_twelve_0635:
        n "然后他们会大笑。你居然相信他们，真是愚蠢。"


    $ all_moves(x_express=Wiggle(freq=.2, amp=70), y_express=Wiggle(freq=.3, amp=40), z_express=Wiggle(freq=.2, amp=3))
    show bg oxhabor night blurred onlayer background with vpunch

    translate None chapter_twelve_0636:
        rs sad "才不是！从我的脑子里滚出去！"
    translate None chapter_twelve_0637:
        "我踉跄着向前，差点跌倒。视线时而模糊时而清晰，头痛欲裂，仿佛有人想要破颅而出。"
    translate None chapter_twelve_0638:
        "街道空无一人，除了凉风中树叶的沙沙声外一片寂静。"
    translate None chapter_twelve_0639:
        "两旁是连绵的旧屋。空气中弥漫着旧书、朽木的气味。弥漫着孤独与悲伤的气息。"
    translate None chapter_twelve_0640:
        "我继续前行。回头路从来都不是选择。每一步都在空荡的街道上回响着空洞的声音。"
    translate None chapter_twelve_0641:
        "走得越远，浓雾就将我包裹得越紧。夜空中布满乌云，遮住了月亮。"
    translate None chapter_twelve_0642:
        "我怎么来到这里的？这是哪儿？"
    translate None chapter_twelve_0643:
        "我不是…和莱奥斯、福恩在一起吗？"
    translate None chapter_twelve_0644:
        "记忆变得模糊不清。 "
    translate None chapter_twelve_0645:
        "我们刚才…我们刚才还在市场…"
    translate None chapter_twelve_0646:
        "莱奥斯…他给我看了什么东西。我记得被拽着离开。"
    translate None chapter_twelve_0647:
        "为什么…我在独自走路？"
    translate None chapter_twelve_0648:
        "我想停下来，但双腿似乎自行移动着，我只是被动跟随。我完全无法控制它们带我去往何方。"
    translate None chapter_twelve_0649:
        "福恩？莱奥斯？"
    translate None chapter_twelve_0650:
        "谁？"
    translate None chapter_twelve_0651:
        "我眨了眨眼，发现自己站在一栋房子前。一扇巨大的铁门守卫着入口。"
    translate None chapter_twelve_0652:
        "我来过这里吗…？"
    translate None chapter_twelve_0653:
        "不…x…？"
    translate None chapter_twelve_0654:
        "我的头部抽痛。"
    translate None chapter_twelve_0655:
        "不，我没来过。从未来过此地。"
    translate None chapter_twelve_0656:
        "当我缓缓推开大门时，冰凉的金属触感传来。"
    translate None chapter_twelve_0657:
        "我低头看向自己的手。猩红的血滴正从指尖坠落，但并不觉得疼痛。我完全感受不到。"
    translate None chapter_twelve_0658:
        "我走向前门。轻推之下，发现门未上锁。屋内漆黑，却没有渗入的雾气。"

    window hide dissolve


    $ all_moves(x_express=Wiggle(freq=.2, amp=70), y_express=Wiggle(freq=.3, amp=40), z_express=Wiggle(freq=.2, amp=3))
    show bg nox house night blurred onlayer background with dissolve:
        zoom 1.3

    window show dissolve
    translate None chapter_twelve_0659:
        "屋内是宏伟的门厅。幽暗中，一道宽阔的楼梯向上延伸，想必通往二层。"
    translate None chapter_twelve_0660:
        "每步脚步声都在木地板上回荡。"
    translate None chapter_twelve_0661:
        "如同被无形的丝线牵引，我打开了一扇偏离入口方向的房门。"

    window hide dissolve

    scene black with dissolve
    window show dissolve
    translate None chapter_twelve_0662:
        "穿过门廊时，手掌突然刺痛。我猛然停步。"
    translate None chapter_twelve_0663:
        "…我又能活动了。"
    translate None chapter_twelve_0664:
        "身后的门砰然关闭。"
    translate None chapter_twelve_0665:
        play sound "sounds/sfx/doorlocked.ogg" fadeout 1
        "我摇晃门把。锁死了。"
    translate None chapter_twelve_0666:
        "我到底…为何在此？又是怎么来到这里的？"
    translate None chapter_twelve_0667:
        "某个…市场？"
    translate None chapter_twelve_0668:
        "记忆朦胧恍惚，仿佛来自遥远的过去。"
    translate None chapter_twelve_0669:
        "走廊漆黑如墨。不时能听见滴水声。我在黑暗中前行，不知将去往何处。"
    translate None chapter_twelve_0670:
        n "欢迎回家。"
    translate None chapter_twelve_0671:
        "回家？"
    translate None chapter_twelve_0672:
        "这就是我的所在吗？"
    translate None chapter_twelve_0673:
        n "这里就是你永恒的归处。你不想离开。"
    translate None chapter_twelve_0674:
        "啊…没错…"
    translate None chapter_twelve_0675:
        "我回家了。"

    translate None chapter_twelve_0676:
        "走廊尽头是扇孤零零的门。我不假思索地推开。"

    window hide dissolve

    show bg nox spooky with dissolve:
        xpos 0.69 ypos 2.02 xanchor 0.55 yanchor 1.13 zoom 1.85
    window show dissolve
    translate None chapter_twelve_0677:
        "一支蜡烛在房间里投下摇曳的阴影。"
    translate None chapter_twelve_0678:
        play sound "sounds/sfx/crunch2.ogg" fadeout 1
        "咯吱。"
    translate None chapter_twelve_0679:
        "地板上铺满某种…白色物质，在我靴底发出碎裂声。"
    translate None chapter_twelve_0680:
        play sound "sounds/sfx/clothrustle.ogg" fadeout 1
        "我走到房间中央。突然，有双手从背后环抱而来。"
    translate None chapter_twelve_0681:
        "非但不觉得惊慌，反而令人安心。"
    translate None chapter_twelve_0682:
        "温柔的右手轻扶我侧头，左手则抚过我的胸膛。"
    translate None chapter_twelve_0683:
        "那双好奇的手滑向衣领，慢慢扯开，直到脖颈完全裸露。"
    translate None chapter_twelve_0684:
        u "这个部位闻起来真可口。"
    translate None chapter_twelve_0685:
        "声音从我右耳边传来。我眼角余光瞥见一排锋利洁白的牙齿。"
    translate None chapter_twelve_0686:
        "一个、两个、三个吻沿着我的脖颈而下。"
    translate None chapter_twelve_0687:
        u "你看起来和他一模一样。"

    if achievement.has("nox_home"):
        pass
    else:
        $ renpy.display_notify("成就解锁：归家")
    python:
        achievement.grant("nox_home")
        achievement.sync()
    translate None chapter_twelve_0688:
        "我向后靠进那个怀抱，温暖的感受充盈我的体内。我回家了。"

    stop music fadeout 0.5
    $ quick_menu = False
    window hide
    scene black
    with vpunch
    pause(2.0)
    return
