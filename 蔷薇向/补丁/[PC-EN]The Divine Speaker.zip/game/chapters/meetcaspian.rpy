label meetcaspian:
    stop music fadeout 2.0

    scene bg eclipse with dissolve
    window show dissolve
    translate None meetcaspian_0001:
        "当我们走进房间时，注意到柜台后面有个背对我们的男人。他弯着腰，大半身子都看不见。我们进来时他既没有站起来也没有转身。"
    translate None meetcaspian_0002:
        u "欢迎光临。有什么能帮您的？"
    translate None meetcaspian_0003:
        rs c wsur "呃…我在找一位叫…卡斯皮安的人？听说他在这里工作。"


    show caspian n work smi at slightright
    show raen nw sur cloak at slightleft
    with dissolve
    play music "sounds/bgm/forgotten off.ogg" fadein 2.0
    translate None meetcaspian_0005:
        cas "嗯，你找对人了。有什么我能效劳的？"
    translate None meetcaspian_0006:
        "他终于站起身转向我们，嘴角挂着微笑。"
    translate None meetcaspian_0007:
        "但我看到的景象完全出乎意料—看他的表情，显然他也同样震惊。"
    translate None meetcaspian_0008:
        rs "..........."
    translate None meetcaspian_0009:
        show caspian n sur with dis
        cas "..........."
    translate None meetcaspian_0010:
        "我们呆望着彼此，在困惑中拼命寻找答案。沉默不断蔓延，每分每秒都变得更加尴尬。"
    translate None meetcaspian_0011:
        f c wsur "你们俩…长得…实在太像了…"
    translate None meetcaspian_0012:
        rs "你…你是…卡斯皮安…？"
    translate None meetcaspian_0013:
        show caspian n sca with dis
        cas "我…我很抱歉，我想我一定是眼花了。"
    translate None meetcaspian_0014:
        "他揉了揉眼睛，眨了好几下，然后再次死死盯着我。"
    translate None meetcaspian_0015:
        cas "一定是…哪里搞错了。你从哪来？"
    translate None meetcaspian_0016:
        rs "….奥雷利亚卡维拉。"
    translate None meetcaspian_0017:
        show caspian n sur with hpunch
        cas "....!"
    translate None meetcaspian_0018:
        show raen nw sad with dis
        rs "你是…你不可能是…"
    translate None meetcaspian_0019:
        show caspian n sad with dis
        cas "哈…哈哈…哦天啊，发发慈悲吧…你是…你是…你不可能…是雷恩？"
    translate None meetcaspian_0020:
        rs "…嗯…"
    translate None meetcaspian_0021:
        cas "这不可能…我现在是见鬼了吗？是这样吗？我受的苦还不够多吗？"
    translate None meetcaspian_0022:
        cas "多残酷的玩笑啊，偏偏现在让我见到你。或许我该掐自己一把…"
    translate None meetcaspian_0023:
        "他伸出手触碰我的脸，然后重重叹了口气。"
    translate None meetcaspian_0024:
        cas "…我…我以为你早就死了。"
    translate None meetcaspian_0025:
        rs "我甚至都不知道你的存在…"

    if achievement.has("raen_caspian"):
        pass
    else:
        $ renpy.display_notify("成就解锁：雷恩，我是你父亲")

    python:
        achievement.grant("raen_caspian")
        achievement.sync()
    translate None meetcaspian_0026:
        cas "真难以置信…经过这么多年…我的亲生儿子会以成年男子的姿态出现在眼前。"
    translate None meetcaspian_0027:
        cas "或许我真的已经疯了。在眼下这种情况，这倒是更说得通。"
    translate None meetcaspian_0028:
        "他倚靠在柜台边，几乎站不稳。"
    translate None meetcaspian_0029:
        rs "我一直…我一直都在寻找你的旅程中…我从来没有意识到…"


    if fawn_route:
        translate None meetcaspian_0030:
            l c wthi "咳咳… 咱们给这俩人留点独处时间吧。" # voice map with below
        translate None meetcaspian_0031:
            "其他三人转身欲走，但我一把抓住了福恩的手。"
        translate None meetcaspian_0032: #VOICE MAP
            rs "别走…求你了。"
        translate None meetcaspian_0033:
            "福恩庄重地点头，莱奥斯和赛恩则从这场尴尬的邂逅中退开。"


    if cyne_route:
        translate None meetcaspian_0034:
            c wthi "咳咳… 咱们给这俩人留点独处时间吧。"# voice map with below
        translate None meetcaspian_0034b:
            "其他三人转身要离开，但我迅速抓住了赛恩的手。"
        translate None meetcaspian_0035:
            rs "别走…求你了。"
        translate None meetcaspian_0036:
            c c wsad "…如果你想的话。"
        translate None meetcaspian_0037:
            "赛恩点头示意，但把手从我掌中抽离。另外两人因尴尬的气氛而退避。"


    if leos_route:
        translate None meetcaspian_0038:
            l c wsur "我…我…我觉得我需要呼吸些新鲜空气。"
        translate None meetcaspian_0039:
            c c wsad "我想我可能会加入你们。"
        translate None meetcaspian_0040:
            "莱奥斯的眼睛眯了起来，眉头微微皱起。"
        translate None meetcaspian_0041:
            "他们三人转身准备离开，但我迅速抓住了莱奥斯的衣袖。"
        translate None meetcaspian_0042:
            rs "别走…求你了。"
        translate None meetcaspian_0043:
            l "我…好吧，算了。"
        translate None meetcaspian_0044:
            "他的话缺乏说服力，不知为何听起来…很困惑。"
        translate None meetcaspian_0045:
            "福恩和赛恩迅速离开了房间，留下我与莱奥斯和卡斯皮安。"



    translate None meetcaspian_0046:
        rs "您真的是我父亲吗？一位…王子？卡斯皮安王子？"
    translate None meetcaspian_0047:
        cas "已经很久没有人叫我王子了…我觉得自己早已配不上这个头衔。"
    translate None meetcaspian_0048:
        "他揉着前额，仿佛头痛即将发作。"
    translate None meetcaspian_0049:
        cas "奥雷利亚·卡维拉…我几乎已经忘记了田野的气息，宫殿的模样…已经快二十年了，雷恩。想必一切都已面目全非…"
    translate None meetcaspian_0050:
        show raen nw sur with dis
        rs "我有太多话想对你说，却不知从何说起..奥雷利亚卡维拉，这是…"
    translate None meetcaspian_0051:
        "我咽了咽口水，回想在奥雷利亚卡维拉的日子，再加上我新学到的知识。"
    translate None meetcaspian_0052:
        show raen nw sad with dis
        rs "我觉得它在消亡。不知道那里的情况还能维持多久。"
    translate None meetcaspian_0053:
        rs "那位说书人声称一切尽在掌控，只要我们虔诚祈祷，庄稼下次就能渡过难关，但是……我已经不再相信他了。"
    translate None meetcaspian_0054:
        "我回忆起与说书人发生的一切以及我们迄今的旅程—那些档案，我的流放，还有我寻找他的历程。"
    translate None meetcaspian_0055:
        "每次我提到说书人时，卡斯皮安的表情就会变得古怪，但他保持沉默聆听我的叙述。"
    translate None meetcaspian_0056:
        show caspian n ang with dis
        cas "说书人…你说得好像他对奥雷利亚卡维拉有绝对掌控权似的。"
    translate None meetcaspian_0057:
        show raen nw sur with dis
        rs "没错。我从未知晓其他可能。"
    translate None meetcaspian_0058:
        show caspian n sad with dis
        cas "但是…即便没有我在，你…你应该…"
    translate None meetcaspian_0059:
        show raen nw sad with dis
        rs "我怎么可能知道？我被抛弃了，在孤儿院长大。"
    translate None meetcaspian_0060:
        cas "我很抱歉…"
    translate None meetcaspian_0061:
        show raen nw neu with dis
        rs "不必如此。听着，我需要你的帮助。我一路寻来就是为了找到答案，而你是唯一的希望。"
    translate None meetcaspian_0062:
        "我卷起袖子给他看那些神之刻印。他的脸色明显变得苍白，又把我的袖子放了下来。"
    translate None meetcaspian_0063:
        cas "我…我帮不了你。已经过去太久了，那不再是我的人生。"
    translate None meetcaspian_0064:
        rs "求你了！你是我唯一的希望了！"
    translate None meetcaspian_0065:
        show caspian n sur with dis
        cas "不，不要—"

    window hide dissolve

    play sound "sounds/sfx/slam.ogg" fadein 1.0
    scene gallery_91 with hpunch
    window show dissolve
    translate None meetcaspian_0066:
        d "整整十二天我都辛勤劳作、奋力拼搏，横跨整个大陆。十二天啊！终于，我将你逼入绝境。"
    translate None meetcaspian_0067:
        "门砰地被推开，一个穿着长袍的身影走了进来。我很熟悉的身影，尽管他现在看起来与往常大不相同。"
    translate None meetcaspian_0068:
        "……说书人。"
    scene gallery_92 with dissolve
    translate None meetcaspian_0069:
        "他的目光与卡斯皮安锁定，两人都因震惊而面色阴沉。他们彼此凝视，脸上写满不可置信。"
    translate None meetcaspian_0070:
        cas "..............."
    translate None meetcaspian_0071:
        d ".............."
    translate None meetcaspian_0072:
        "再度，我们唇间吐不出只言片语，仿佛所有能说的话都已枯萎凋零。卡斯皮安伸出手，像是期待说书人会握住它。"


    if cyne_route:
        translate None meetcaspian_0073:
            c c wsur "..我理不清这些头绪。现在又是谁？"


    if fawn_route:
        translate None meetcaspian_0074:
            f c wsur "谁…谁…？"


    if leos_route:
        translate None meetcaspian_0075:
            l c whur "…不…怎么会？"


    translate None meetcaspian_0076:
        cas "艾米尔….."
    translate None meetcaspian_0077:
        "话音未落，他转身就跑，砰地把门甩上。"
    translate None meetcaspian_0078:
        cas "等等！"


    if cyne_route:
        translate None meetcaspian_0079:
            "转瞬间，卡斯皮安追着他冲出房门，只留下赛恩和我独处。"
        translate None meetcaspian_0080:
            rs c wsur "呃….刚才那是…说书人…？"
        translate None meetcaspian_0081:
            c c wsur "什么？！"
        translate None meetcaspian_0082:
            "事情变得越来越诡异了…"

        window hide dissolve

        scene bg eclipse with dissolve
        window show dissolve
        translate None meetcaspian_0083:
            rs c wsur "那么…我们该怎么办？"
        translate None meetcaspian_0084:
            c c wsur "你不觉得刚才那段对话有点怪怪的吗？他们之间是不是有什么前尘往事？"
        translate None meetcaspian_0085:
            rs "我可是一头雾水…我们要跟着他们吗？"
        translate None meetcaspian_0086:
            c "好吧，至少比傻站在这里强。"


    if fawn_route:
        translate None meetcaspian_0087:
            "刹那间，卡斯皮安就把他追出门外，只留下福恩和我两人独处。"
        translate None meetcaspian_0088:
            rs c wsur "呃…."
        translate None meetcaspian_0089:
            f c wsur "刚才发生了什么…？"
        translate None meetcaspian_0090:
            "事情变得越来越诡异了…"

        window hide dissolve

        scene bg eclipse with dissolve
        window show dissolve
        translate None meetcaspian_0091:
            rs c wsur "那么…我们该怎么办？"
        translate None meetcaspian_0092:
            f c wsur "我们要跟随他们吗…？"
        translate None meetcaspian_0093: # MISSING
            rs c wsur "好吧，至少比傻站在这里强。"



    if leos_route:
        translate None meetcaspian_0094:
            "转瞬间，卡斯皮安追着他冲出房门，只留下莱奥斯和我独处。"
        translate None meetcaspian_0095:
            rs c wsur "呃….刚才那是…说书人…？"
        translate None meetcaspian_0096:
            l c wsur "如果他在这里，那是否意味着…"

        window hide dissolve

        scene bg eclipse with dissolve
        window show dissolve
        translate None meetcaspian_0097:
            rs c wsur "...?"
        translate None meetcaspian_0098:
            l c wsur "这是否意味着全是谎言？"
        translate None meetcaspian_0099:
            rs "什么意思？"
        translate None meetcaspian_0100:
            l "他告诉我们森林之外一无所有。他那预言般的话语和占卜。我们的…我们的审判…"
        translate None meetcaspian_0101:
            l c whur "如果他是你父亲，那么…"
        translate None meetcaspian_0102:
            "他的眉头越来越紧锁。"
        translate None meetcaspian_0103:
            rs c wsur "你觉得我们该跟上去吗？"




    stop music fadeout 2.0
    window hide dissolve

    scene bg sc day with Fade(1.0, 1.0, 1.0):
        xpos 0.7 ypos 1.4 xanchor 0.5 yanchor 1.0 zoom 1.43
        linear 28.0 xpos 0.29 ypos 1.4 xanchor 0.5 yanchor 1.0 zoom 1.43
    window show dissolve
    translate None meetcaspian_0104:
        cas wsur "艾米尔，请等等！求你了！"
    translate None meetcaspian_0105:
        "年轻的王子冲过街道，以疯狂的决绝追随着他的目标。"
    translate None meetcaspian_0106:
        cas wsad "让我们聊聊！艾米尔！"
    translate None meetcaspian_0107:
        "就像一场猫捉老鼠的游戏，谁也不愿认输。他们跑啊跑，直到—"

    window hide dissolve

    scene gallery_93 with dissolve
    window show dissolve
    translate None meetcaspian_0108:
        ae "....."
    translate None meetcaspian_0109:
        ae "这么久以来…这么久以来，你都让我以为你死了。"
    translate None meetcaspian_0110:
        play music "sounds/bgm/sad.ogg" fadein 2.0
        cas "我…"
    translate None meetcaspian_0111:
        "他的声音哽咽了。这个场景在他脑海中预演过上千次，可此刻他却找不到合适的话对他说。"
    translate None meetcaspian_0112:
        cas "我{i}确实{/i}死了。除了名字之外一无所有。"
    translate None meetcaspian_0113:
        "两人之间陷入沉默。并非尴尬，而是仿佛都想不出任何能弥补关系裂痕的话语。"
    translate None meetcaspian_0114:
        cas "…你又留长了头发，还长得这么高了。"
    translate None meetcaspian_0115:
        ae "…十八年间可以发生很多改变。"
    translate None meetcaspian_0116:
        cas "万物都在改变…除了.."
    translate None meetcaspian_0117:
        cas "你仍保留着我给你的月亮。"
    translate None meetcaspian_0118:
        ae "别自欺欺人了。这只是习惯使然，别无其他。"
    translate None meetcaspian_0119:
        "艾米尔试图挣脱他的手臂，在两人之间筑起一道无形的隔阂，但卡斯皮安紧紧抓住了不放。"
    translate None meetcaspian_0120:
        ae "大老远跑这一趟真是浪费时间。我不知道自己当时在想什么。"
    translate None meetcaspian_0121:
        cas "我听说雷恩发生的事了…你为什么追他追到这么远的地方？"
    translate None meetcaspian_0122:
        ae "...."
    translate None meetcaspian_0123:
        ae "到现在我也不知道了。追逐一个幻影…"
    translate None meetcaspian_0124:
        ae "这是个错误。就当从没来过这里吧。"
    translate None meetcaspian_0125:
        cas "等等，艾米尔…你大老远赶来。我们该谈谈。哪怕只是一会儿也好。"
    translate None meetcaspian_0126:
        ae "你的机会已经用完了，我没义务再给你第二次！"
    translate None meetcaspian_0127:
        ae "我这辈子都不想再见到你！"
    translate None meetcaspian_0128:
        cas "你说什么？"
    translate None meetcaspian_0129:
        cas "等一下—你以为自己在这儿是无辜的吗？"
    translate None meetcaspian_0130:
        cas "你杀了她，我还以为连雷恩也被你杀了。见鬼，要不是我跑得快早就没命了。"
    translate None meetcaspian_0131:
        ae "这一切发生都是因为你那样对待卢修斯。他于我如父…"
    translate None meetcaspian_0132:
        cas "…我们所有人中就他最不无辜。你现在应该已经知道这一点了。"
    translate None meetcaspian_0133:
        cas "不，我来这里不是和你争论的。无论过错在谁，这都不能阻止我自上次分别后，每天都思念着你。求你了，回到我的店里来吧，我们可以好好谈谈。"
    translate None meetcaspian_0134:
        cas "哪怕只是待一小会儿也好。求你了。"
    translate None meetcaspian_0135:
        ae "....."

    window hide dissolve

    scene bg sc day with Fade(1.0, 1.0, 1.0)
    window show dissolve

    if cyne_route:
        translate None meetcaspian_0136:
            rs c wsur "福恩，莱奥斯！跟我们一起走！"


    if leos_route:
        translate None meetcaspian_0137:
            rs c wsur "福恩，赛恩！跟我们一起走！"


    if fawn_route:
        translate None meetcaspian_0138:
            rs c wsur "赛恩，莱奥斯！跟我们一起来！"


    translate None meetcaspian_0139:
        "沿途又载上了另外两人，我们在卡斯皮安和说书人后面疾驰穿行街道，试图赶上他们。"

    show bg sc day:
        ypos -0.37 xanchor 0.11 zoom 1.38
    show caspian n sad work at slightright
    show ds n ang at slightleft
    with dissolve
    translate None meetcaspian_0140:
        cas "哪怕只是待一小会儿也好。求你了。"
    translate None meetcaspian_0141:
        ae "....."
    translate None meetcaspian_0142:
    #stop music fadeout 3.0
        rs c wang "这他妈怎么回事？！"
    translate None meetcaspian_0143:
        ca "呃…"
    translate None meetcaspian_0144:
        rs "你们在这儿也太引人注目了。我们能回店里说吗？"
    translate None meetcaspian_0145:
        "他俩郑重其事地点头，那神情活像是两个在父母面前闯了祸的孩子。"

    window hide dissolve

    scene bg eclipse with dissolve
    window show dissolve
    translate None meetcaspian_0146:
        "我让他们俩坐下，自己站在他们面前。"


    show ds n ann at farright
    show caspian n work sad at cenright
    show raen nw sad cloak at cenleft

    if cyne_route:
        show cyne nw neu cloak at farleft
        with dissolve

    if fawn_route:
        show fawn nw sad cloak at farleft
        with dissolve

    if leos_route:
        show leos nw neu cloak at farleft
        with dissolve


    translate None meetcaspian_0147:
        rs "请问有谁能告诉我到底发生了什么？"
    translate None meetcaspian_0148:
        rs "你们两个认识吗？还有你，是不是一直在跟踪我？太可怕了！"
    translate None meetcaspian_0149:
        rs "为什么赶我走？！为什么想让我死？！"
    translate None meetcaspian_0150:
        "我所有的问题都悬在空中，我紧盯着他们两人，等待着他们的回答。"
    translate None meetcaspian_0151:
        cas "…至少我可以解释我们是怎么认识的。"
    translate None meetcaspian_0152:
        cas "我们一起长大。就这么简单。作为未来的国王和言者，我们自出生起就在同一个屋檐下成长。"
    translate None meetcaspian_0153:
        cas "当时有些…复杂情况…我们产生了小矛盾。"
    translate None meetcaspian_0154:
        show ds n ang with dis
        ae "小？！哈，你还是像以前一样爱开玩笑！你和那个女人杀了他！"
    translate None meetcaspian_0155:
        rs "谁？！你在说什么胡话！把整件事讲清楚。"
    translate None meetcaspian_0156:
        show ds n ann with dis
        ae "......"
    translate None meetcaspian_0157:
        cas "…你的母亲。"
    translate None meetcaspian_0158:
        cas "天啊…该从何说起…"
    translate None meetcaspian_0159:
        "他深吸了一口气，看起来像是不知道该说什么才好。"
    translate None meetcaspian_0160:
        cas "当艾米尔和我还年轻时，我们曾偷偷溜出奥雷利亚卡维拉一阵子。不，说得更准确些，是我拖着他陪我去的，不过…那段时光很开心。"
    translate None meetcaspian_0161:
        cas "当我们返回时…王室已被屠戮殆尽，只余我一人。"
    translate None meetcaspian_0162:
        cas "一场意外，\"卢修斯说。当时他是最接近事件的人，作为当值言者。任何人都能看出其中有蹊跷，而我知道就是他干的。"
    translate None meetcaspian_0163:
        cas "他向来权欲熏心。"
    translate None meetcaspian_0164:
        show ds n ang with dis
        ae "从来没有任何证据！你只是随便找个替罪羊—任何人都行！"
    translate None meetcaspian_0165:
        show caspian n ang with dis
        cas "证据明明很充分，你只是不愿正视罢了！"
    translate None meetcaspian_0166:
        cas "如果当时我在场，他也会杀了我。实际上，我的幸存让他很不高兴。"

    show raen nw sur with dis

    if fawn_route:
        show fawn nw sur
        with dis

    if cyne_route:
        show cyne nw sur
        with dis

    if leos_route:
        show leos nw sur with dis

    translate None meetcaspian_0167:
        rs "为什么…他为什么要那么做？"
    translate None meetcaspian_0168:
        cas "这不是很明显吗？他想要完全控制奥雷利亚卡维拉。他对和其他人合作没有兴趣。"
    translate None meetcaspian_0169:
        cas "他和历任言者没什么不同。他们都沉溺于自我，以为自己是万人膜拜的全能神明。"
    translate None meetcaspian_0170:
        rs "那个卢修斯后来怎样了？"
    translate None meetcaspian_0171:
        show caspian n sad with dis
        cas "....."
    translate None meetcaspian_0172:
        ae "你想知道他发生了什么吗？你母亲杀了他，冷酷无情地杀了他。"
    translate None meetcaspian_0173:
        cas "…这是正当防卫，你心里清楚。如果她不这么做，他本来会先杀了我们的。妮娅…她是个善良的灵魂，那么温柔体贴…"
    translate None meetcaspian_0174:
        cas "她只想保护雷恩和我。甚至连你也是！他对你的影响向来太过强大！"
    translate None meetcaspian_0175:
        rs "然后发生了什么…？"
    translate None meetcaspian_0176:
        cas "这不是明摆着的吗？他目睹了一切，然后勃然大怒。"
    translate None meetcaspian_0177:
        cas "要求把我们三个都处死，因为我们违抗了说书人的命令。"
    translate None meetcaspian_0178:
        cas "妮娅…她死了。我以为你也死了。我受了伤，但我还有力气逃跑。如果我早知道…如果我早知道你还活着，我一定会带上你一起走的。"
    translate None meetcaspian_0179:
        cas "我在昏迷前总算抵达了斯塔格威奇。一位老人发现了我并将我照料康复。"
    translate None meetcaspian_0180:
        $ about_Caspian.image = "gui/codex/entries/people/enc_caspian.jpg"
    translate None meetcaspian_0181:
        $ about_Caspian._text = ["卡斯皮安王子是奥雷利亚卡维拉王位的下一任继承人，但他的生活与他的成长环境毫不相符。童年时期，卡斯皮安总是酷爱冒险，这与家族的期望背道而驰。他经常惹是生非，通常还会拖上见习言者艾米尔一起胡闹。\n \n两人形影不离，以为永远都会陪伴在彼此身边。唉，命运是个残酷的情妇，卡斯皮安把事情做得太过火了，他带着艾米尔一起离开了奥雷利亚卡维拉的安全之地。"]
        $ about_Caspian._text.append("他们在那里知晓了外部世界。起初，这是个令人兴奋的发现，但当他们回到家中，迎接他们的只有混乱。国王与王后，已逝。往常的守卫们，正忙于寻找失踪的王子。\n \n他曾以为，经历了这一切后，至少他还拥有艾米尔。他并不孤单。他不必独自一人……\n \n 但很快，他真的孤身一人了。十八年后，他依然珍视着那些年少时的记忆。")
        cas "我… 我想回去但是… 我知道自己永远回不去了。所以我前往{a=set_entry:enc_people->about_Caspian}{color=#87CEEB}锡德卡汉{/color}{/a}。不得不说，这条路很长。途中我还在其他地方停留过几次。"
    translate None meetcaspian_0182:
        rs "好吧…这解释了你的离开原因，也说明了你们为何合不来，但是…"
    translate None meetcaspian_0183:
        show raen nw sad with dis
        rs "你给我设了局，对吧？为什么想让我死？"
    translate None meetcaspian_0184:
        show ds n ann with dis
        ae "啧…"
    translate None meetcaspian_0185:
        "他是当真对我咋舌了吗？他怎么可以这么不成熟？说书人居然表现得…那样？"
    translate None meetcaspian_0186:
        cas "再给我们看看你手臂上的神之刻印。"
    translate None meetcaspian_0187:
        cas "来啊，好好看看。你和我一样清楚这些印记的含义。"
    translate None meetcaspian_0188:
        ae "你要是知道，干嘛还要我回答？"
    translate None meetcaspian_0189:
        cas "哈…这是古老的经文。他们称之为神之文字。"
    translate None meetcaspian_0190:
        cas "这是给你的审判，作为礼物赠予你。"
    translate None meetcaspian_0191:
        show raen nw sur with dis
        rs "但是…为什么？我的审判从未受到质疑—"
    translate None meetcaspian_0192:
        stop music fadeout 2.0
        $ about_Markings._text = ["卡斯皮安和说书人告诉了我真相—这些神之刻印根本不是什么诅咒。相反，这些用古老经文写就的文字，被称为神之箴言，揭示了关于我真正的审判。我注定要成为下一任说书人。"]
        cas "这是你的天命。你始终就是下一任说书人的不二人选。这些{a=set_entry:enc_mysteries->about_Markings}{color=#87CEEB}神之刻印{/color}{/a}正意味着如此。"
    translate None meetcaspian_0193:
        cas "我想既然{i}某人{/i}没把话传到，他们就自己来告诉你了。"

    play music "sounds/bgm/forgotten off.ogg" fadein 2.0

    if fawn_route:
        translate None meetcaspian_0194: # SYNCED
            fr "什么？！"


    if cyne_route:
        translate None meetcaspian_0195:
            cyneraen "什么？！"


    if leos_route:
        translate None meetcaspian_0196:
            rl "什么！？"
        translate None meetcaspian_0197:
            l "你不是认真的吧…"


    translate None meetcaspian_0198:
        rs "但是…但是为什么？！我这辈子一直都被告知—"
    translate None meetcaspian_0199:
        ae "我撒谎了。就是这么回事。"
    translate None meetcaspian_0200:
        show raen nw sad with dis
        rs "我以为…我以为自己是在违抗命运，走自己的路…可你现在告诉我这一切都是谎言？"
    translate None meetcaspian_0201:
        ae "看起来是的。"
    translate None meetcaspian_0202:
        rs "这还是没有回答我的问题！你为什么要对我撒谎？"
    translate None meetcaspian_0203:
        ae "…我只是遵从了神的旨意行事。"
    translate None meetcaspian_0204:
        show raen nw sur with dis
        rs "那些…神明？他们…让你欺骗我？跟踪我？为什么？"
    translate None meetcaspian_0205:
        ae "我不欠你任何解释。"
    translate None meetcaspian_0206:
        show caspian n ang with dis
        cas "艾米尔。"
    translate None meetcaspian_0207:
        show ds n ang with dis
        ae "..我不知道为什么。从来都不知道为什么。"
    translate None meetcaspian_0208:
        show ds n ann with dis

        ae "从我出生起…他们的声音就始终环绕着我，影响着我的一举一动，吞噬着我的整个存在。我得竭尽全力才能在那喋喋不休中保持一丝自我感觉。"
    translate None meetcaspian_0209:
        ae "我年纪越大，情况就越糟。他们的低语变成了吼叫和尖叫，说的话再也听不清了。"
    translate None meetcaspian_0210:
        ae "但是…当我被确立为言者时，他们的声音已经到了让我几近崩溃的地步，就在这时，一个声音单独向我传来。他说他会留在我身边，让其他声音保持安静。"
    translate None meetcaspian_0211:
        ae "有生以来第一次，我近乎获得了宁静。脑海中剩下的那个声音，与先前的嘈杂相比简直微不足道。"
    translate None meetcaspian_0212:
        ae "自那以后，我确实获得了近乎宁静的状态，但…"
    translate None meetcaspian_0213:
        show caspian n sur with dis
        cas "但…？"
    translate None meetcaspian_0214:
        $ about_Speaker._text = ["神圣演说者—卡斯皮安王子称其为\'艾米尔\'—是奥雷利亚卡维拉的唯一统治者。我曾以为他天赋异禀能与神明对话，但后来发现，对他人而言每个恩赐都是诅咒。\n \n事实上，他自幼就被困在奥雷利亚卡维拉的众神之声占据心智，最终憎恶自己的使命。年少成为言者时，有个声音与他达成交易，但艾米尔始终不知接受这交易的代价。此后那个声音独占他的脑海，将其他声音拒之门外。\n \n他奉神秘神灵之命，从奥雷利亚卡维拉一路追我到锡德卡汉。最初他对我怀有深仇大恨，但旅途让他开始反思缘由，最终懊悔自己的作为。"]
        $ about_Speaker._text.append("当他抵达锡德卡汉时，那个依附在他身上的唯一神也消失了，艾米尔生平第一次体会到了寂静的感觉。\n \n艾米尔与卡斯皮安一同长大，两人曾经形影不离，直到卢修斯介入了他们之间。最终，他们的关系以卡斯皮安被认为是死去，而艾米尔将孤独终老作结。")
        ae "但当我抵达锡德卡汉后，一切都改变了。那最后孤独的声音也消失了，这辈子第一次…我的世界陷入了{a=set_entry:enc_people->about_言者}{color=#87CEEB}至寂{/color}{/a}。彻彻底底的寂静。"
    translate None meetcaspian_0215:
        ae "…但那正是他的声音 坚持认为是我对你做了那些事 而这并非我的异议之处"
    translate None meetcaspian_0216:
        cas "至寂…真的吗？想起年少时你对我说的那些话…我以为那绝无可能。"
    translate None meetcaspian_0217:
        "只有一个声音在与他对话…"

    window hide

    menu:
        "暂且相信你吧":
            window show dissolve
            $ caspianaemylromance += 1
            translate None meetcaspian_0218:
                rs "…好吧，我相信你。也许是你脑子里的某个疯狂声音让你来杀我，但…"
            translate None meetcaspian_0219:
                rs "你是不是连一秒钟都没想过，那可能是个相当糟糕的主意？"
            translate None meetcaspian_0220:
                ae "....."
            translate None meetcaspian_0221:
                rs "而你—你只是从这一切中逃离了？"
            translate None meetcaspian_0222:
                show caspian n sad with dis
                cas "......"
            jump afterchoice1

        "我为什么要相信你？":
            window show dissolve
            translate None meetcaspian_0223:
                rs "…我凭什么要相信你们两个说的话？"
            translate None meetcaspian_0224:
                rs "那个抛弃我的男人和那个企图谋杀我的男人…"
            translate None meetcaspian_0225:
                show caspian n sad with dis
                cas "我…我很抱歉…"
            jump afterchoice1

label afterchoice1:
    if leos_route:
        translate None meetcaspian_0226:
            l "…是你雇我来杀他的。"
        translate None meetcaspian_0227:
            ae "….没错。是莱奥斯，对吧？"
        translate None meetcaspian_0228:
            l "所以你终究知道我是谁…都是谎言吗？你对我们说过的每句话都是谎言吗？"
        translate None meetcaspian_0229:
            ae "若你指的是你的审判，卢修斯从未说谎。"
        translate None meetcaspian_0230:
            show leos nw hur with dis
            l "..."
        translate None meetcaspian_0231:
            l "你是怎么知道的？"
        translate None meetcaspian_0232:
            ae "他不是骗子。他比我高尚得多。"
        translate None meetcaspian_0233:
            cas "噗。"
        translate None meetcaspian_0234:
            ae "…你的家人在等你归来。"
        translate None meetcaspian_0235:
            show leos nw ann with dis
            l "哈！他们想让我回去，是吗？怎么，要为我失败而惩罚我吗？不，我可不打算回去。"
        translate None meetcaspian_0236:
            l "操他妈的。我走了。"
        translate None meetcaspian_0237:
            play sound "sounds/sfx/slam.ogg"

        show raen nw sur with dis
        hide leos with dissolve
        show raen at left
        show caspian at center
        show ds at right
        with move

        translate None meetcaspian_0238:
            rs "等等，莱奥斯！"
        translate None meetcaspian_0239:
            "随着一声巨响，他摔门而去。赛恩和福恩面面相觑，又看向那扇门，随后再次致歉离席。"
        translate None meetcaspian_0240:
            c c wsad "我们晚些再聚，好吗？"
        translate None meetcaspian_0241:
            show raen nw sad with dis
            rs "好吧…"
        translate None meetcaspian_0242:
            "我的脑海里全是莱奥斯。他为什么这么生气？"


    show raen nw sad with dis
    translate None meetcaspian_0243:
        rs "……我不远万里而来……现在又该如何？"
    translate None meetcaspian_0244:
        rs "这就是给我的答案吗？ 一段我从未祈求过的宿命。"
    translate None meetcaspian_0245:
        rs "....."


    if cyne_route:
        show cyne nw sad with dis
        translate None meetcaspian_0246:
            c "…..雷恩.."


    if fawn_route:
        show fawn nw sad with dis
        translate None meetcaspian_0247:
            f "…..雷恩.."

    translate None meetcaspian_0248:
        ae "…我明天就回家去。在这种地方闲逛根本毫无意义。"
    translate None meetcaspian_0249:
        ae "这是个错误，我会尝试尽快忘记它。"
    translate None meetcaspian_0250:
        show ds n sad with dis
        ae "….想跟来随你。或是不来，对我而言都一样。我们可以假装无事发生，你也能回归往日生活。"

    hide ds with dissolve

    if cyne_route:
        show raen at center
        show caspian at right
        show cyne at left
        with move

    if fawn_route:
        show raen at center
        show caspian at right
        show fawn at left
        with move

    if leos_route:
        show raen at slightleft
        show caspian at slightright
        with move

    translate None meetcaspian_0251:
        "他站起身离开了房间。他脸上不见了那道锋利的棱角。他看起来…很伤心。"
    translate None meetcaspian_0252:
        cas "…我稍后再去找他。我猜他已无处可去。"
    translate None meetcaspian_0253:
        rs "…他到底是怎么找到我们的？"


    if fawn_route:
        translate None meetcaspian_0254:
            f "我不知道.."
        translate None meetcaspian_0255:
            rs "我需要…斟酌该怎么办。福恩…我们还是走吧。"


    if cyne_route:
        translate None meetcaspian_0256:
            c "呃，他是个言者，对吧？我猜他大概能…那个…读取我们的思想，或者预知未来。"
        translate None meetcaspian_0257:
            rs "我得…想想该怎么做。赛恩…我们还是走吧。"


    translate None meetcaspian_0258:
        show caspian n neu with dis
        cas "..."
    translate None meetcaspian_0259:
        cas "雷恩。"
    translate None meetcaspian_0260:
        rs "什么？"
    translate None meetcaspian_0261:
        cas "…你不必回奥雷利亚卡维拉的，明白吗。永远可以选择留在这里。"
    translate None meetcaspian_0262:
        cas "我已经错过了你生命中太多时光。"
    translate None meetcaspian_0263:
        "回家还是留在这里…？我真的能如此轻易地回到过去的生活吗？"
    translate None meetcaspian_0264:
        rs "…谢谢。我会考虑的。明天我会带着答复回来。"


    if cyne_route or fawn_route:
        translate None meetcaspian_0265:
            "当我们离开时，太阳已经开始在锡德卡汉上空西沉。"


    if leos_route:
        translate None meetcaspian_0266:
            "当我离开时，太阳已经落入了锡德卡汉的地平线。"

    stop music fadeout 2.0
    window hide dissolve

    if cyne_route:
        jump aftercaspiancyne

    if leos_route:
        jump aftercaspianleos

    if fawn_route:
        jump aftercaspianfawn




    #
