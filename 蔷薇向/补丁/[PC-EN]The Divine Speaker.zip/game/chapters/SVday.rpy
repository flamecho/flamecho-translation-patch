label SV_morning:
    scene bg sv day with dissolve:
        xpos 0.72 ypos 1.03 xanchor 0.5 yanchor 1.0 zoom 1.46
        linear 30.0 xpos 0.29 ypos 1.03 xanchor 0.5 yanchor 1.0 zoom 1.46
    window show dissolve
    translate None sv_day_0001:
        $ about_SecretVillage._text = ["在环绕锡德卡汉的群山深处，有一座隐秘无名的村落，里面居住着迷失的神明。这个由昔日反神者埃利奥特领导的村庄，远离尘嚣，享受着宁静祥和的日子。"]
        $ about_SecretVillage.image = "gui/codex/entries/places/encsv.jpg"
    translate None sv_day_0002:
        "当我们穿过{a=set_entry:enc_places->about_SecretVillage}{color=#87CEEB}街道{/color}{/a}时，我能感觉到无数目光紧盯着我们的一举一动。所有人都在注视着我们，不知道我们为何来到此地。"
    translate None sv_day_0003:
        "我不能责怪他们。我们必定是第一个敢在这里公然行走的人类，而在他们眼中…我们不过是一种威胁。"
    translate None sv_day_0004:
        "我试图微笑以安抚他们的紧张情绪，但他们全都避开了我的目光。我们匆匆前行，最终在不远处发现了维拉斯和伊尔兰。"
    translate None sv_day_0005:
        "他们并肩而立，却各自望向不同方向，陷入彻底的沉默。"
    translate None sv_day_0006:
        rs c wsur "呃…早上好。"



    if fawn_route:
        translate None sv_day_0007:
            v sad "早上好，雷恩，福恩。"

    if cyne_route:
        translate None sv_day_0008:
            v sad "早上好，雷恩，赛恩。"


    if leos_route:
        translate None sv_day_0009:
            v sad "早上好，雷恩，莱奥斯。"


    translate None sv_day_0010:
        i sad "....."


    if cyne_route:
        translate None sv_day_0011:
            c c wneu "唔，这真是…愉快啊。别告诉我我们又要处理一对情侣的争吵？"


    if fawn_route:
        translate None sv_day_0012:
            f c wsur "呃…"
        translate None sv_day_0013:
            f "你们俩睡得好吗？"


    if leos_route:
        translate None sv_day_0014:
            l c wsur "这一点都不尴尬。"


    if cyne_route or leos_route:
        translate None sv_day_0015:
            rs c wsad "呃…你们俩昨晚休息得怎样？"


    translate None sv_day_0016:
        i "...."
    translate None sv_day_0017:
        v "…哈哈…是的，我睡得很好。不过昨晚发生了一件有趣的事。"
    translate None sv_day_0018:
        "伊尔兰的眉毛抽搐了一下，把脸扭得更偏了。"
    translate None sv_day_0019:
        v neu "我追上了埃利奥特。我们谈到了他的帮助，但他坚决表示无能为力。不过…"


    if cyne_route:
        translate None sv_day_0020:
            c "然而？"


    if leos_route:
        translate None sv_day_0021:
            l "然而？"


    if fawn_route:
        translate None sv_day_0022:
            f "然而？"


    translate None sv_day_0023:
        v sad "…不过，我依然相信我们能说服他。我只是不知道该说些什么才好。"
    translate None sv_day_0024:
        "就在我们思索这个问题时，卡斯皮安和艾米尔也加入了我们。"
    translate None sv_day_0025:
        ae neu "…那我们就这么离开吗？"
    translate None sv_day_0026:
        i neu "呃这要看情况—你有啥神奇的超能力能从屁股里变出来阻止卢修斯吗？"
    translate None sv_day_0027:
        ae ann "…那你有什么建议？他们拒绝帮助我们。已经无计可施了。"


    if fawn_route:
        translate None sv_day_0028:
            f  c wsad"….我还不想走。我还有很多想向埃利奥特请教的事。"


    if leos_route or cyne_route:
        translate None sv_day_0029:
            rs c wsad "一定能找到办法的。单靠我们自己…根本毫无胜算。"


    translate None sv_day_0030:
        v sad "我们不能走。一定还有别的办法…"


    if leos_route:
        translate None sv_day_0031:
            cas neu "…昨晚我听到件有趣的事。埃利奥特告诉西尔维尔，将参考她的判断决定是否帮助我们。"


    translate None sv_day_0032:
        "就在这时，我在远处瞥见一抹黑红相间的头发。是西尔维尔。"
    translate None sv_day_0033:
        rs c wsur "在这儿等一下。"
    translate None sv_day_0034:
        "我把其他人甩在身后，追向她的方向。她当然看见了这一切，但脚步并未停歇。"


    show bg sv day:
        xpos 0.29 ypos 1.03 xanchor 0.5 yanchor 1.0 zoom 1.46

    show sylvir n neu at slightright
    show raen nw sur cloak at slightleft
    with dissolve
    translate None sv_day_0035:
        s "那是什么？"
    translate None sv_day_0036:
        rs "我…只是想谢谢你，为莫温所做的一切。也为了我们。"
    translate None sv_day_0037:
        show sylvir n sur with dis
        s "..."
    translate None sv_day_0038:
        s "我只是按吩咐行事。不需要你的感谢。"
    translate None sv_day_0039:
        rs "好吧，我还是要把这个给你。"
    translate None sv_day_0040:
        show sylvir n neu with dis
        s "你其实是想打听埃利奥特的事吧？"
    translate None sv_day_0041:
        show raen nw sad with dis
        rs "哈哈哈…这么明显吗…？"
    translate None sv_day_0042:
        show sylvir n thi with dis
        s "听着…他并非对你的处境无动于衷。实际上恰恰相反。他太在乎了。"
    translate None sv_day_0043:
        s "他想帮你，但他也不会冒险放弃我们代表的一切。"
    translate None sv_day_0044:
        rs "你真觉得没办法说服他了吗？"
    translate None sv_day_0045:
        s "…可能吧，但你会是第一个能动摇他想法的人。"
    translate None sv_day_0046:
        show sylvir n neu with dis
        s "若你想再次请求他的帮助，必须等到夜幕降临。"
    translate None sv_day_0047:
        show raen nw sur with dis
        rs "为什么？"
    translate None sv_day_0048:
        s "这是他凡人之躯的代价。他不能在阳光下行走，否则会被严重灼伤。"
    translate None sv_day_0049:
        rs "啊…就像维拉斯失去视力一样。"
    translate None sv_day_0050:
        s "没错。我们都用自己的一部分来交换这副躯体。"
    translate None sv_day_0051:
        show raen nw hap with dis
        rs "好的，我会告诉其他人。我们会一直等到晚上!"


    if leos_route:
        translate None sv_day_0052:
            s "等等。"
        translate None sv_day_0053:
            show raen nw sur with dis
            rs "...?"
        translate None sv_day_0054:
            s "我自会判断你的事业是否正义。稍后再来这里见我。"
        translate None sv_day_0055:
            rs "呃…好吧…？"


    show sylvir n smi with dis
    translate None sv_day_0056:
        "我觉得她脸上似乎浮现出一丝微笑，但在我想确认那究竟是我的错觉还是真实表情之前，它已经消失不见了。"

    hide sylvir
    hide raen
    with dissolve
    translate None sv_day_0057:
        "她摆了摆手示意我离开，然后继续走她的路。"


    if fawn_route:
        translate None sv_day_0058:
            f "你们两个聊了什么？"


    if cyne_route:
        translate None sv_day_0059:
            c "她说了什么有用的话吗？"


    if leos_route:
        translate None sv_day_0060:
            l c wsur "她说了些什么？"


    if cyne_route or fawn_route:
        translate None sv_day_0061:
            rs c wneu "她觉得我们可能还有机会。我们会待到今晚晚些时候，再去问问埃利奥特。听上去不错？"


    if leos_route:
        translate None sv_day_0062:
            rs c wneu "她觉得我们还有机会说服埃利奥特，而且…她说要亲眼看看我们的事业是否正义。"



    translate None sv_day_0063:
        rs "我晚些时候会再和她见面。"

    translate None sv_day_0064:
        v neu "在那之前，分散开来在镇上调查可能是个好主意。这或许是你唯一能与这些人一起行走的机会，所以我会明智地利用它。"


    if cyne_route:
        translate None sv_day_0065:
            rs c wsmi "那我和赛恩一起去。我们会尽量避开麻烦。"


    if leos_route:
        translate None sv_day_0066:
            rs c wsmi "莱奥斯和我会一起去的。我们会尽量避开麻烦。"


    if fawn_route:
        translate None sv_day_0067:
            rs c wsmi "那我和福恩一起去。我们会尽量避开麻烦。"


    translate None sv_day_0068:
        v neu "伊尔兰？"
    translate None sv_day_0069:
        i sad "...."
    translate None sv_day_0070:
        v sad "你好，伊尔兰…？"
    translate None sv_day_0071:
        i "啊？好的好的，我们可以一起走。"
    translate None sv_day_0072:
        "艾米尔和卡斯皮安互相对视了一眼，谁都没有出声。"
    translate None sv_day_0073:
        rs c whap "哦，艾米尔。要不就跟卡斯皮安一起走吧？"
    translate None sv_day_0074:
        ae neu "...."
    translate None sv_day_0075:
        ae ann "我想我别无选择。"
    translate None sv_day_0076:
        v neu "那么我们天黑前在这里会合。大家各自小心。"


    if cyne_route:
        jump cyne_sv_scenes

    if leos_route:
        jump leos_sv_scenes

    if fawn_route:
        jump fawn_sv_scenes #check this is ok


############################################################################################################

label raenaemylsv:
    if cyne_route:
        translate None sv_day_0077:
            "夕阳终于开始西沉，为这座隐秘的村庄镀上暮色。我们备好的食物都被愉快地享用完毕后，赛恩和我穿过小镇回去寻找其他人。西尔维尔和莫温自行离开了，去…做她们自己的事吧，我想。"
        translate None sv_day_0078:
            "我们看到前方的艾米尔和卡斯皮安，便加快脚步赶上去。"


    if leos_route:
        translate None sv_day_0079:
            "夕阳终于开始西沉在这座隐秘的村庄，莱奥斯和我动身返回寻找队伍的其他人。"
        translate None sv_day_0080:
            "我感到神清气爽，但能看出莱奥斯因先前的战斗而疲惫。尽管如此，他仍在试图掩饰。"
        #translate None sv_day_0081:
            #"We didn’t manage to find much out, so hopefully the others did."
        translate None sv_day_0082:
            "我们走在街上时，看见前面的卡斯皮安和艾米尔正站得很近交谈。"


    if fawn_route:
        translate None sv_day_0083:
            "太阳终于开始在隐藏村庄的上方西沉，我和福恩往镇上的方向走去。"
        translate None sv_day_0084:
            "我的身体感到疲惫，甚至筋疲力尽，因为和福恩一起…辛苦的搜寻工作。"
        translate None sv_day_0085:
            "想到其他人都在努力工作，一丝愧疚感悄悄爬上了我的心头。"
        translate None sv_day_0086:
            "我们走在街上时，看见卡斯皮安和艾米尔就在前面。"



    translate None sv_day_0087:
        cas sur "嘿，艾米尔。你的机会来了。"
    translate None sv_day_0088:
        "卡斯皮安用肘轻推艾米尔，后者害羞地朝我这边看过来。"
    translate None sv_day_0089:
        ae ann "你…有时间吗？"
    translate None sv_day_0090:
        rs c wsur "我？"
    translate None sv_day_0091:
        ae "我看起来像是在对别人说话吗？"
    translate None sv_day_0092:
        rs "不，我只是有点惊讶你会想和我说话。"
    translate None sv_day_0093:
        rs "你一个人在这里待一会儿没问题吧？"


    if fawn_route:
        translate None sv_day_0094:
            f c wsmi "慢慢来，不用着急。"
        translate None sv_day_0095:
            "留下福恩和卡斯皮安后，艾米尔将我拽到安静的角落，用目光死死盯住我。"


    if cyne_route:
        translate None sv_day_0096:
            c c wsmi "我相信和那边那位英俊的绅士聊天也能自得其乐。"
        translate None sv_day_0097:
            "他朝卡斯皮安使了个眼色，后者只是微笑着回应。"
        translate None sv_day_0098:
            "将赛恩和卡斯皮安留在身后，艾米尔把我拉到一个安静的角落，死死盯着我。"


    if leos_route:
        translate None sv_day_0099:
            l c wpis "……你最好别碰他一根手指。"
        translate None sv_day_0100:
            ae "我保证不会动他一根头发，我发誓。"


    show ds n neu at slightleft
    show raen nw cloak sur at slightright
    with dissolve
    translate None sv_day_0101:
        "我…我是不是有麻烦了…？到头来他还是想要我死…？"
    translate None sv_day_0102:
        "寂静持续蔓延，直到一个微弱的声音突然划破长空。"
    translate None sv_day_0103:
        show ds n sad with dis
        stop music fadeout 3.0
        ae "我为之前的行为致歉。"
    translate None sv_day_0104:
        rs "什么…？"
    translate None sv_day_0105:
        ae "你耳背吗？我说过对不起了。"
    translate None sv_day_0106:
        ae "我把怒气发泄在你身上是错的。看着你时，我以为早已淡忘的背叛感又涌上心头，但这不能成为借口。"
    translate None sv_day_0107:
        "他…居然在向我道歉？"
    translate None sv_day_0108:
        rs "我…接受你的道歉吧。既然你都这么诚心了，我又怎能不接受呢？"
    translate None sv_day_0109:
        ae "......"
    translate None sv_day_0110:
        play music "sounds/bgm/forgotten off.ogg" fadein 3.0
        ae "出于嫉妒和愤怒，我伪造了你的审判，剥夺了你学习成为言者的机会，但现在还来得及弥补。"
    translate None sv_day_0111:
        show raen nw sad with dis
        rs "能说实话吗？"
    translate None sv_day_0112:
        "艾米尔点了点头，而我长久地、用力地盯着地面。"
    translate None sv_day_0113:
        rs "我不确定自己想当言者。"
    translate None sv_day_0114:
        ae "...."
    translate None sv_day_0115:
        ae "…你有选择的权利已经很幸运了。"
    translate None sv_day_0116:
        ae "无论如何，我不打算让你一无所知地困在这里。如果你同意，我会教你。"
    translate None sv_day_0117:
        show raen nw sur with dis
        rs "真的吗？"
    translate None sv_day_0118:
        ae "但是…我必须告诉你真相。我的能力…至少可以说，很难控制。它们很不寻常，被放大到了几乎无法控制的程度。"
    translate None sv_day_0119:
        ae "不过你的能力，我认为是可掌控的。"
    translate None sv_day_0120:
        show raen nw sad with dis
        rs "我还是完全控制不住它……"
    translate None sv_day_0121:
        show raen nw sur with dis
        rs "你的能力究竟是什么？"
    translate None sv_day_0122:
        "他伸出手，我凑近细看。却什么也没发现。"
    translate None sv_day_0123:
        show ds n neu with dis
        rs "...?"
    translate None sv_day_0124:
        ae "再靠近些看。"
    translate None sv_day_0125:
        "当我注视着那只手掌上方的空间，期待某种奇迹般的炫目景象出现时，我注意到了—他掌心上方有层薄雾，让周围的空气都发生了扭曲。"


    if achievement.has("speaker_power"):
        pass
    else:
        $ renpy.display_notify("成就已解锁：你正在产生幻觉")
    python:
        achievement.grant("speaker_power")
        achievement.sync()
    translate None sv_day_0126:
        ae "幻象、致幻剂。改变一个人对现实的感知，模糊真实与想象之间的界限。"
    translate None sv_day_0127:
        rs "这…太神奇了！怎么做到的？"
    translate None sv_day_0128:
        show ds n sad with dis
        ae "雷恩啊，要是我能告诉你该有多好。"
    translate None sv_day_0129:
        ae "我只知道这会影响我周围的空气。如果你吸入它，那么幻觉就会影响你的心智。有用吗？也许吧，要是我能掌控它的话。"
    translate None sv_day_0130:
        rs "所以…你的幻觉具体能{b}做到什么{/b}？"
    translate None sv_day_0131:
        ae "我能隐身藏匿，或使物品在众目睽睽之下销声匿迹。这会在周身营造出一种能左右他人看法的气息。"
    translate None sv_day_0132:
        show raen nw sad with dis
        rs "而我唯一能做的只有伤害自己…"
    translate None sv_day_0133:
        "艾米尔摇了摇头，同时微微露出笑容。"
    translate None sv_day_0134:
        ae "你拥有一种强大的天赋，可以用来行善。"
    translate None sv_day_0135:
        ae "我几乎可以肯定这里面还有你不明白的事。"
    translate None sv_day_0136:
        "艾米尔从层层衣物间抽出一把小折刀。他将刀尖抵上指尖，轻轻一刺。"
    translate None sv_day_0137:
        show ds n neu with dis
        ae "试着治好它。"
    translate None sv_day_0138:
        "我迟疑地向他伸出了手。相触的瞬间，什么都没发生。"
    translate None sv_day_0139:
        rs "没用的，我永远都控制不了它。"
    translate None sv_day_0140:
        ae "能力触发时肯定存在某种共性。仔细回想。"
    translate None sv_day_0141:
        rs "...."
    translate None sv_day_0142:
        "那次对福恩，还有对伊尔兰。两次都是在我毫无准备时…"
    translate None sv_day_0143:
        rs "我想…总是在我想帮助别人却束手无策时出现。刻意为之反而从未成功过。"
    translate None sv_day_0144:
        ae "强烈的情绪反应，加上想要帮助他人、消除痛苦的内心渴望。"
    translate None sv_day_0145:
        ae "然后，闭上你的眼睛，再次想象那些时刻。想着你真心爱着的那个人，在痛苦中挣扎。伸出手去触碰他们，但不要试图治愈。试着去安慰。"


    scene black with eye_shut
    if cyne_route:
        translate None sv_day_0146:
            "在我脑海中，我看见了赛恩—那么渺小，脆弱，受了伤。我伸手想去触碰，但我们之间突然出现了一道无可穿透的熊熊火光。"


    if leos_route:
        translate None sv_day_0147:
            "在我脑海中，我看见了莱奥斯—因保护我而受伤，正需要我的帮助。我伸出手去，但我们之间突然出现一道耀眼的强光，无法穿透。"


    if fawn_route:
        translate None sv_day_0148:
            "在我的脑海中，我看见了福恩—小小的，脆弱不堪，受了伤。我伸出手去，可一道刺目的强光在我们之间闪现，隔绝了一切。"


    translate None sv_day_0149:
        rs c wsad "还是…不行。我做不到—"
    translate None sv_day_0150:
        ae neu "继续尝试。战胜你的障碍。"
    translate None sv_day_0151:
        "我用双手、双臂和整个身体推拒那道光。起初它纹丝不动。无论我如何推拉，它都岿然不动。"
    translate None sv_day_0152:
        ae "拥抱它。"
    translate None sv_day_0153:
        "…拥抱它？"
    translate None sv_day_0154:
        "当我停止推挤时，某些东西悄然改变。那原本坚硬如墙、难以逾越的光芒，此刻竟变得柔软起来。我伸出手去，手掌竟直接穿透而过。"
    translate None sv_day_0155:
        "我向前迈出一步，将自己包裹在那片光芒之中。"


    scene bg sv sunset:
        xpos 0.29 ypos 1.03 xanchor 0.5 yanchor 1.0 zoom 1.46

    show raen nw sur cloak at slightright
    show ds n neu at slightleft
    with eye_open
    translate None sv_day_0156:
        "那一刻我终于睁开了眼睛。指尖悬着一滴血珠。"
    translate None sv_day_0157:
        ae "…看来你的经历与我相似。"
    translate None sv_day_0158:
        rs "一面…墙，但…"
    translate None sv_day_0159:
        show ds n sad with dis
        ae "当你接受时，它就会放行。我很幸运…有人教导了我这点。"
    translate None sv_day_0160:
        rs "…卢修斯？"
    translate None sv_day_0161:
        ae "....."
    translate None sv_day_0162:
        ae "曾几何时，我真切地相信他是个好人。即便现在想来，我依旧难以把他想象成别的模样。他于我如父如亲。"
    translate None sv_day_0163:
        rs "你心里想着谁？"
    translate None sv_day_0164:
        ae "…呃.."
    translate None sv_day_0165:
        rs "卡斯皮安？"
    translate None sv_day_0166:
        show ds n emb with dis
        ae "什…什么？不—不是这样的，我…"
    translate None sv_day_0167:
        show raen nw emb blush with dis
        "虽然已经从卡斯皮安那里听过这个故事，但艾米尔的反应还是让我瞬间火冒三丈。"
    translate None sv_day_0168:
        rs "没关系，别担心。卡斯皮安…他已经告诉我了。"
    translate None sv_day_0169:
        ae "他告诉你了？！他…他说我什么了？"
    translate None sv_day_0170:
        rs "他说…他认为你就是那个人。"
    translate None sv_day_0171:
        ae "...."
    translate None sv_day_0172:
        show ds n emb2 with dis
        ae "那个愚蠢的浪漫主义者…"

    show raen nw smi with dis

    if cyne_route:
        translate None sv_day_0173:
            "我微笑着，顽皮地轻拍艾米尔的肩膀，对他尴尬的样子发出笑声。"

        stop music
        play sound "sounds/sfx/heartbeat.ogg" fadein 0.5
        show raen nw hur -blush with hpunch
        translate None sv_day_0174:
            "当我的手触碰到他时，眼前一片煞白，我几乎踉跄跌倒。"
        translate None sv_day_0175:
            show ds n sur with dis
            ae "雷恩？！"
        translate None sv_day_0176:
            "我抱住头，整个世界在我周围天旋地转。一种奇怪的感受窜过我的身体。就像是站在狂风暴雨中，周遭的狂风呼啸肆虐，只不过这次风暴都被禁锢在我的体内。"
        translate None sv_day_0177:
            ae "...."
        translate None sv_day_0178:
            rs "这是…什么？"
        translate None sv_day_0179:
            ae "你…把它还回来了。"
        translate None sv_day_0180:
            show raen nw sur with dis
            rs "什么？"
        translate None sv_day_0181:
            ae "它回来了…"
        translate None sv_day_0182:
            "他向我竖起手指，展示那滴重新浮现的血珠。"
        translate None sv_day_0183:
            rs "我可以…我真能做到吗？"
        translate None sv_day_0184:
            ae "太神奇了…我就知道没那么简单。"
        translate None sv_day_0185:
            show raen nw sad with dis
            rs "这不是…一种很危险的能力吗…？"
        translate None sv_day_0186:
            show ds n neu with dis
            ae "确实。我建议你不要将这项特殊天赋告诉他人。总之，这堂课改日再上。"


    translate None sv_day_0187:
        ae "我想我们该回到大伙那里去了。天色很快就要暗下来了。"
    translate None sv_day_0188:
        show raen nw smi -blush with dis
        rs "好的，还有…谢谢您，言者。"
    translate None sv_day_0189:
        show ds n neu with dis
        ae "我配不上那个称号。走吧，我们出发。"
    stop music fadeout 3.0
    hide raen
    hide ds
    with dissolve

    scene bg sv night with dis4:
        xpos 0.29 ypos 1.03 xanchor 0.5 yanchor 1.0 zoom 1.46

    if fawn_route:
        translate None sv_day_0190:
            "我们循着来时的路返回，回到留下卡斯皮安和福恩的地方，发现他俩正并肩坐着，愉快地聊着天。"
        translate None sv_day_0191:
            play music "sounds/bgm/night.ogg" fadein 3.0
            cas sur "所以你独自住在森林里？就一个人？这实在太了不起了。"
        translate None sv_day_0192:
            f c wneu "呃…我不觉得这有什么了不起…"
        translate None sv_day_0193:
            cas "你独自建造了整个树屋，那时还是个孩子啊！"
        translate None sv_day_0194:
            "我想现在可能是我唯一的机会…"
        translate None sv_day_0195:
            rs c wneu "呃…卡斯皮安？"
        translate None sv_day_0196:
            cas sur "嗯？"
        translate None sv_day_0197:
            rs "能和你谈谈吗？"
        translate None sv_day_0198:
            "他的表情从惊讶转为欢喜，从福恩身边一跃而起，活像一只主人刚回家的大型犬。"
        translate None sv_day_0199:
            cas smi "当然。"


        show raen mw dark neu at mleft
        show caspian m dark smi at mright
        with dissolve

        translate None sv_day_0200:
            "我将他从福恩和艾米尔身边领开，艾米尔尴尬地抓了抓后脑勺看向福恩，我们找了个安静的地方交谈。"
        translate None sv_day_0201:
            rs "我，呃…"
        translate None sv_day_0202:
            rs "你会做东西对吧？"
        translate None sv_day_0203:
            show caspian sur with dis
            cas "嗯..大体上是的。做什么样的东西？"
        translate None sv_day_0204:
            rs "我想送福恩一条项链。我找到了一颗宝石，但是…我不知道剩下的该怎么做。"
        translate None sv_day_0205:
            cas "....."
        translate None sv_day_0206:
            cas "我呃…没想到你们俩这么认真。"
        translate None sv_day_0207:
            show raen mw emb with dis
            rs "..."
        translate None sv_day_0208:
            show caspian smi with dis
            cas "呃..我不是珠宝匠，但我想我能凑合做个简单的。"
        translate None sv_day_0209:
            show raen mw sur with dis
            rs "真的吗？！"
        translate None sv_day_0210:
            show caspian neu with dis
            cas "是啊，真的。当然，如果我们能活下来的话。"
        translate None sv_day_0211:
            show raen mw sad with dis
            rs "给。能替我保管这个吗？还有…如果我遭遇不测，你能代替我把它交给福恩吗？"
        translate None sv_day_0212:
            show caspian sur with dis
            cas "....."
        translate None sv_day_0213:
            cas "你要把这个托付给我？"
        translate None sv_day_0214:
            rs "我愿意。你是…我的父亲。"
        translate None sv_day_0215:
            "我以为我看见他的眼睛湿润了，但他迅速眨了眨眼掩盖过去，一个大大的笑容浮现在脸上。"
        translate None sv_day_0216:
            show caspian smi with dis
            cas "我不会让你失望的。来吧，我们去和其他人汇合。"
        translate None sv_day_0217:
            hide raen
            hide caspian
            with dissolve
            "我们原路返回，找到仍站在原处、彼此之间颇为尴尬的艾米尔和福恩。"





    if cyne_route:
        translate None sv_day_0218:
            "我们沿着原路返回，来到之前留下卡斯皮安和赛恩的地方，发现他们正肩并肩坐着，愉快地聊着天。不知为何，看到他们相处融洽，我感到很高兴。"


    if leos_route:
        translate None sv_day_0219:
            "我们沿着原路返回到留下卡斯皮安和莱奥斯的地方，发现他俩并肩坐着，正在轻声聊天。"
        translate None sv_day_0220:
            cas sur "所以，你是他们的儿子…"
        translate None sv_day_0221:
            l c wsur "对不起…"
        translate None sv_day_0222:
            cas smi "别这么说。你已经证明自己与他们不同。雷恩能有你是他的幸运。"


    if leos_route or cyne_route:
        play music "sounds/bgm/night.ogg" fadein 3.0

    translate None sv_day_0223:
        "伊尔兰和维拉斯从另一边走来，看起来心情稍微好了一些。"
    translate None sv_day_0224:
        rs c wsur "你们俩又和好了？"
    translate None sv_day_0225:
        i fli "别犯傻了。我们本来就没吵架。"
    translate None sv_day_0226:
        rs "是～吗～。有人学到什么了吗？"
    translate None sv_day_0227:
        v sad "..."
    translate None sv_day_0228:
        cas sad "...."


    if cyne_route:
        translate None sv_day_0229:
            c c wsad "....."


    if fawn_route:
        translate None sv_day_0230:
            f c wsad "....."


    if cyne_route or fawn_route:
        translate None sv_day_0231:
            rs c wsad "大…大家是不是利用这段时间出去玩了…？"
        translate None sv_day_0232:
            cas emb "哈哈…"
        translate None sv_day_0233:
            rs "那我们就别无选择了。我们只能祈求。"
        translate None sv_day_0234:
            rs c wsmi "好吧，我可能不擅长很多事情，但乞讨我想我还是能应付的。"


    if leos_route:
        translate None sv_day_0235:
            rs c wsmi "好吧，这不重要，因为…"
        translate None sv_day_0236:
            "我看向莱奥斯，他把我的话接下去说完了。"
        translate None sv_day_0237:
            l c wsmu "因为我们已经说服西尔维尔来帮我们对付埃利奥特。"
        translate None sv_day_0238:
            v sur "你学会了？真令我惊讶！"


    translate None sv_day_0239:
        ae ann "我们会在外面等埃利奥特。一起走吧。"
    translate None sv_day_0240:
        "令我惊讶的是，艾米尔带领着我们前行。当我看向同伴们的脸时，我能看出他们也同样震惊。直到此刻之前，他大多只是安静地跟在后面，从不发表意见。"
    translate None sv_day_0241:
        show elliot m dark neu with dissolve
        stop music fadeout 2.0
        el "这是什么，欢迎会？我不是说过让你们今天离开吗？"
    translate None sv_day_0242:
        play music "sounds/bgm/creepy.ogg" fadein 3.0
        rs c wneu "…我们不能就这么离开。我们需要你的帮助。"
    translate None sv_day_0243:
        show elliot m dark gla with dis
        el "我已经告诉过你—"


    if cyne_route:
        translate None sv_day_0244:
            "莫温从阴影中再次走向人群。"
        translate None sv_day_0245:
            mor cu neu "我想你应该有时间考虑过我说的话了。"
        translate None sv_day_0246:
            rs c wsur "莫温？"
        translate None sv_day_0247:
            mor cu smi "别担心，亲爱的。我们刚才在讨论身为神明的职责。"
        translate None sv_day_0248:
            rs c wsad "没有你我们做不到这件事…" # check if this is fawn route too


    if leos_route:
        translate None sv_day_0249:
            "从阴影中，西尔维尔站在我们这伙人身边。"
        translate None sv_day_0250:
            s neu "埃利奥特，你让我对他们做出审判。我认为他们的事业是正义的，他们的渴望—不，是他们对我们帮助的需求—是正当的。"
        translate None sv_day_0251:
            el "...."


    if fawn_route:
        translate None sv_day_0252:
            f c wsad "求你了，埃利奥特！我们在恳求你。"
        translate None sv_day_0253:
            f "有那么多东西我想向你学习。有那么多问题我想问你，可是…如果我们现在就走，我就永远没这个机会了。"
        translate None sv_day_0254:
            rs c wsad "没有你我们做不到这件事…"


    translate None sv_day_0255:
        ae sad "我知道…你有理由怀疑我们。说实话，连我自己有时都会怀疑自己，但是…这次我想做些能帮助他人的事。做些能挽救生命的事。"
    translate None sv_day_0256:
        el "我不能让这么多人承担风险—"
    translate None sv_day_0257:
        rs "恳求—"
    translate None sv_day_0258:
        el "但…我可以赌上自己的性命。仅此而已。"
    translate None sv_day_0259:
        rs "求求了，我们真的—"
    translate None sv_day_0260:
        rs c wsur "等等，你愿意帮我们？"
    translate None sv_day_0261:
        show elliot m dark ang with dis
        el "孤独。我不能要求这些人去打仗。我知道他们会追随我，这让我心痛。"


    if fawn_route: # MISSING LINES
        translate None sv_day_0262:
            "从阴影处，另一个人向这群人走来。"
        translate None sv_day_0263:
            mor cu neu "我也同去。可不敢把你的命运交给老天。"
        translate None sv_day_0264:
            rs c wsur "莫温…"
        translate None sv_day_0265:
            "又有一个人从她身后走了出来。她叹了口气，神情恼怒，然后直直盯着我的眼睛。"
        translate None sv_day_0266:
            s neu "总是第一个往麻烦里跳…好吧，我也跟着去吧。"


    if cyne_route:
        translate None sv_day_0267:
            "莫温身后又走出一个人影。"
        translate None sv_day_0268:
            s neu "…我想我得跟你一起去。"
        translate None sv_day_0269:
            "她叹了口气，目光久久停留在莫温身上。"
        translate None sv_day_0270:
            s thi "你们俩真像。总是头也不回地往麻烦里跳。"


    if leos_route:
        translate None sv_day_0271:
            "从西尔维尔身后走出另一个人。是莫温。"
        translate None sv_day_0272:
            mor cu neu "我也要去。你说什么也拦不住我。"
        translate None sv_day_0273:
            "西尔维尔的目光落在我身上，随后叹了口气。"



    translate None sv_day_0274:
        el "这些够吗？我给不出更多了。"
    translate None sv_day_0275:
        v fro "…我们会让它足够。"
    translate None sv_day_0276:
        v "时间紧迫。锡德卡汉现在可能已经发生任何变故了。你们有快速抵达的方法吗？"
    translate None sv_day_0277:
        hide elliot with dissolve
        "三位村庄神明点了点头，彼此低声商议片刻。"
    translate None sv_day_0278:
        s neu "我会背着莫温进城。埃利奥特，你跟大部队一起走。"
    translate None sv_day_0279:
        rs c wsur "那我们这就走？"
    translate None sv_day_0280:
        i ang "我们在这里已经待得太久了。"


    if leos_route:
        translate None sv_day_0281:
            l c wneu "这话不用你说第二遍。"


    translate None sv_day_0282:
        "随着一阵烟雾腾起，一只鹰和一只老鼠出现在西尔维尔和莫温刚才站立的地方。片刻之后，它们也消失无踪。"


    if cyne_route:
        translate None sv_day_0283:
            c c wang "快点。咱们下山应该比上山快才对。"


    if leos_route:
        translate None sv_day_0284:
            l c wpis "快。下山速度得比上山快得多。"

    window hide dissolve
    jump luciusfight















#
