label choice_twentythree_done:
    show raen n dim sad at cenleft
    show cyne n dim neu at cenright
    show leos n dim neu at farright
    show fawn n dim sad at farleft
    with dissolve

    translate None chapter_fourteen_0001:
        rs "…还有一件事需要调查。感觉我们已经搜寻了这么久，收获却如此甚微…"


    if nox_askearring == False:
        show cyne n hap with dis
        translate None chapter_fourteen_0002:
            c "哎~我可不能说我们这次是空手而归啊！"
        translate None chapter_fourteen_0003:
            l "他说得对。诺克斯对那枚耳环的反应很可疑。你说你找到了与之配对的那只？"
        translate None chapter_fourteen_0004:
            rs "我…我想是的。当时很暗，但我确定能配上。"
        translate None chapter_fourteen_0005:
            l "百分百确定？"
        translate None chapter_fourteen_0006:
            rs "….大概…百分之七十确定？"
        translate None chapter_fourteen_0007:
            show leos n smi with dis
            l "废物。"
        translate None chapter_fourteen_0008:
            f "别这么说。在那种情况下本来就很难确定。"
        translate None chapter_fourteen_0009:
            l "小老鼠，我有在跟你说话吗？"
        translate None chapter_fourteen_0010:
            f "...."
        translate None chapter_fourteen_0011:
            show fawn n neu with dis
            f "没有，但我还是可以发表意见。"


    elif ft_asknox == False:
        translate None chapter_fourteen_0012:
            rs "…那个占卜师…她说诺克斯的父母在他小时候就去世了，但是.."
        translate None chapter_fourteen_0013:
            f "…他昨晚告诉我们他父母只是外出了，对吧？"
        translate None chapter_fourteen_0014:
            rs "今天他又这么说。说他父母出差去了。"
        translate None chapter_fourteen_0015:
            show cyne n sur with dis
            c "你们觉得他可能是出现幻觉了吗？"
        translate None chapter_fourteen_0016:
            show leos n ang with dis
            l "他不是傻子。他在耍我们。"
        translate None chapter_fourteen_0017:
            rs "但是…为什么？对我们撒谎对他有什么好处？"
        translate None chapter_fourteen_0018:
            f "他父母也是被奥克斯哈伯杀手杀害的….这意味着什么？按理说，他应该会主动告诉我们…"


    elif bloodonneck == True:
        translate None chapter_fourteen_0019:
            show cyne n sur with dis
            c "不过你们知道我发现了什么可疑之处吗？听起来他好像知道我们发现的那具尸体的身份。"
        translate None chapter_fourteen_0020:
            rs "...."
        translate None chapter_fourteen_0021:
            rs "…他说是\"她\"…"
        translate None chapter_fourteen_0022:
            rs "可…或许我们中有人无意间—"
        translate None chapter_fourteen_0023:
            show leos n ang with dis
            l "没有。他就是知道。"
        translate None chapter_fourteen_0024:
            f "我也不想怀疑他，但是…这有点可疑…"


    else:
        translate None chapter_fourteen_0025:
            rs "这么多零散的线索…我们所见所闻都互相矛盾。"

    translate None chapter_fourteen_0026:
        "我们心不在焉地继续走在街上。虽然还有其他线索要查，但…"
    translate None chapter_fourteen_0027:
        show leos n smi with dis
        l "你不是有别的事要做吗？整天跟着我们不觉得无聊吗？"
    translate None chapter_fourteen_0028:
        c "什么，在跟我说话？无聊？这种状况下我怎么可能无聊？逍遥法外的杀手，一群帅哥，待解的谜团。这是我几个月来最有趣的经历了。"
    translate None chapter_fourteen_0029:
        l "你干嘛不回家玩去，让大人来干正事呢？你爸妈肯定在等你吧。"
    translate None chapter_fourteen_0030:
        c "家里确实有几个\"爸爸\"在等我，但这边有趣多了。"
    translate None chapter_fourteen_0031:
        f "说起来你还没怎么介绍过自己呢。"
    translate None chapter_fourteen_0032:
        show cyne n mis with dis
        c "你们想知道什么？"
    translate None chapter_fourteen_0033:
        f "呃…."
    translate None chapter_fourteen_0034:
        show leos n neu with dis
        l "爽快点交代。"
    translate None chapter_fourteen_0035:
        c "你这样让我很尴尬啊，把我置于这种境地！让我想想…我叫赛恩，是个英俊性感的神秘侦探，周游各地破案并赢得男人芳心。"
    translate None chapter_fourteen_0036:
        l "...."
    translate None chapter_fourteen_0037:
        show cyne n sur with dis
        c "呃好吧。好吧，部分属实？老实说我没那么有趣啦。我就是赛恩而已。"
    translate None chapter_fourteen_0038:
        l "好吧，但这个赛恩是做什么的？从哪来？"
    translate None chapter_fourteen_0039:
        c "这个赛恩嘛，大多数时候只是听家里人的话装乖宝宝。就让我放纵这一次吧。"
    translate None chapter_fourteen_0040:
        show fawn n bla with dis
        f "你不是说昨天就该回家的吗？会不会有麻烦？或许你现在回去比较好。"
    translate None chapter_fourteen_0041:
        show fawn n neu with dis
        c "哎呀，他们死不了的。"
    translate None chapter_fourteen_0042:
        show cyne n hap with dis
        c "或者想到他们的完美金童在奥克斯哈伯街头跟…讨厌鬼们游荡，会气得暴毙吧。"
    translate None chapter_fourteen_0043:
        show leos n ang with dis
        l "讨厌鬼？能待在我身边是你八辈子修来的福气。"
    translate None chapter_fourteen_0044:
        c "嘿，我可没说我认同他们。实际上你们这些讨厌鬼正合我胃口！"
    translate None chapter_fourteen_0045:
        rs "...."
    translate None chapter_fourteen_0046:
        "另外三人嬉笑打闹着互相斗嘴。尽管福恩和莱奥斯那样评价赛恩，其实他们相处得不错，只是嘴硬不肯承认。"
    translate None chapter_fourteen_0047:
        "我安静地走在后面。想加入他们，更了解他们，一起玩乐，但是…"
    translate None chapter_fourteen_0048:
        "我做不到。"
    translate None chapter_fourteen_0049:
        rs "…那个…大伙？"
    translate None chapter_fourteen_0050:
        rs "…我…我真的好害怕。"
    translate None chapter_fourteen_0051:
        rs "我试着像你们一样坚强，但我做不到。我也不想这么胆小懦弱…"
    translate None chapter_fourteen_0052:
        rs "脑子里全是可怕的画面，比如…几周后我也会在荒郊野外被人发现尸体吗？这…就是我的命运？"
    translate None chapter_fourteen_0053:
        rs "不管怎么强装镇定，我只想蜷成一团大哭。现在才真正意识到可能会发生什么。"

    show fawn n neu
    show leos n neu
    show cyne n neu
    with dis

    translate None chapter_fourteen_0054:
        f "雷恩，要知道…大家都很害怕。我很怕，莱奥斯和赛恩也是，虽然他们不肯承认。"
    translate None chapter_fourteen_0055:
        "我轮流看向他们的脸：福恩，他很快就成了我最好的朋友；莱奥斯，虽然开头相处不愉快，但现在似乎想帮我；还有赛恩…虽然不太熟，却一次次不遗余力地帮我…"
    translate None chapter_fourteen_0056:
        "他们都不再发笑或微笑了。他们也在为我担心。"
    translate None chapter_fourteen_0057:
        c "你想逃跑吗？"
    translate None chapter_fourteen_0058:
        rs "……嗯。"
    translate None chapter_fourteen_0059:
        c "但你仍旧不会这么做，对吧？"
    translate None chapter_fourteen_0060:
        rs "当然不…我答应了诺克斯要帮他，而且无论如何我都打算坚持到底…要么这样要么那样。"
    translate None chapter_fourteen_0061:
        c "这就是你的力量所在。"
    translate None chapter_fourteen_0062:
        show raen n sur with dis
        rs "什么？"
    translate None chapter_fourteen_0063:
        l "他说得对，你要知道。你是个傻瓜，但你的心意是好的。"
    translate None chapter_fourteen_0064:
        show fawn n sur with dis
        f "每个人都会害怕。懦弱的人才不敢承认。"
    translate None chapter_fourteen_0065:
        l "保持一点恐惧能让你更加警觉。只要确保看清脚下的路。"
    translate None chapter_fourteen_0066:
        show fawn n smi with dis
        f "你不是孤身一人。我们可以一起完成。"



    stop music fadeout 3.0
    hide fawn
    hide raen
    hide leos
    hide cyne
    show illran m dim hap
    show bveras m dim neu:
        xpos 0.5 ypos 1.0 xanchor 0.55 yanchor 1.02
    with dissolve

    translate None chapter_fourteen_0067:
        gr "噢，算我一个！这是什么，某种友谊誓约吗？真可爱。"
    translate None chapter_fourteen_0068:
        rs sur "啊！"
    translate None chapter_fourteen_0069:
        play music "sounds/bgm/Fooling Around Tiny.ogg" fadein 3.0
        "又来了…."

    show cyne n dim sur at left
    show illran n dim hap at right
    show raen n dim sad at center
    show bveras n dim neu at right:
        xpos 1.0 ypos 1.0 xanchor 0.95 yanchor 0.98
    with dissolve
    translate None chapter_fourteen_0070:
        l ann "噢搞什么…你知道吗？不。就是不行。走开，我们现在没心情搭理你。"
    translate None chapter_fourteen_0071:
        show illran n sad with dis
        gr "好冷漠！莱奥斯，我们一起经历了这么多后，你怎么还能这样对我？在我为你做了这么多之后？"
    translate None chapter_fourteen_0072:
        l ann "你为我做了什么？什么，烦扰和骚扰我吗？相信我，如果不是要看着这三个小鬼，我早就解决你了。"
    translate None chapter_fourteen_0073:
        show illran n fli with dis
        gr "噢，是请吃晚餐吗？天啊，真会调情。"
    translate None chapter_fourteen_0074:
        l ann "呃…"
    translate None chapter_fourteen_0075:
        gr "我看到你又收留了一个流浪者，只是…嗯，这个流浪者看起来被驯化得很厉害呢。"
    translate None chapter_fourteen_0076:
        show cyne n hap with dis
        c "即使是被驯化的动物也会杀人。赛恩。"
    translate None chapter_fourteen_0077:
        "赛恩伸出手想握手，但绿发男子迅速将其拉到嘴边，在手背上留下轻轻一吻。"
    translate None chapter_fourteen_0078:
        show illran n hap armsdown with dis
        gr "我道歉，看来我低估你了。我可不想冒犯伟大的赛恩…"
    translate None chapter_fourteen_0079:
        c "好吧，目前还没被冒犯。抱歉，我想我没听清你的名字？"
    translate None chapter_fourteen_0080:
        "虽然他们交谈愉快，但两人的语气都带有寒意。仿佛在试图压对方一筹。"
    translate None chapter_fourteen_0081:
        gr "你们有些人可能知道，在奥克斯哈伯随便透露名字可不是好主意。我觉得为了安全起见，最好还是保密。"
    translate None chapter_fourteen_0082:
        f neu "你知道些什么？"
    translate None chapter_fourteen_0083:
        gr "我只是个旅人。一无所知。"
    translate None chapter_fourteen_0084:
        l smi "真的吗？因为听上去你知道的比你透露的要多。为什么来奥克斯哈伯？这里可不是什么理想的度假胜地。"
    translate None chapter_fourteen_0085:
        gr "你这话什么意思？死亡与绝望的气息有什么不令人着迷的？除非你能推荐其他值得造访的地方？我听说这季节的锡德卡汉很不错，对吧赛恩？"
    translate None chapter_fourteen_0086:
        show cyne n neu with dis
        c "……我觉得你任何时候去都会喜欢的。不过啊，像你这样的人应该日理万机，没空跟我们闲聊才是。你难道没有别的地方要去吗？"
    translate None chapter_fourteen_0087:
        gr "哦，你说得对！我可不想错过约会。看来我和维拉斯该告辞了。"
    translate None chapter_fourteen_0088:
        "男人肩头的小鸟扑棱着翅膀。"
    translate None chapter_fourteen_0089:
        show illran n fli with dis
        gr "我走之后可别太想我！"

    hide illran
    hide bveras
    with dissolve
    show raen at slightright
    show cyne at slightleft
    with move

    translate None chapter_fourteen_0090:
        "男人转身离开，消失在小巷深处。"

    show raen n sur with dis
    stop music fadeout 3.0

    translate None chapter_fourteen_0091:
        rs "在这等会儿，我马上回来。"

    window hide dissolve
label cheese:
    scene bg ox alley with dissolve
    window show dissolve

    translate None chapter_fourteen_0092:
        "我飞快地追上去，把同伴们抛在身后。远远看见他正悠闲地踏过污水横流的巷道。"
    translate None chapter_fourteen_0093:
        rs sur "喂！等等！"


    show illran m dim neu armsdown at mright:
        xpos 0.5 ypos 1.0 xanchor 0.19 yanchor 1.0
    show bveras m dim neu:
        xpos 0.5 ypos 1.0 xanchor 0.22 yanchor 1.03
    show raen m dim sur at closeleft
    with dissolve

    translate None chapter_fourteen_0094:
        gr "哎呀，真意外。有只小狗自己找上门来了。"
    translate None chapter_fourteen_0095:
        play music "sounds/bgm/creepy.ogg" fadein 3.0
        "小狗……？"
    translate None chapter_fourteen_0096:
        show raen m sad with dis
        rs "我…我只是想说…你要小心。不知道你清不清楚，最近有人—"
    translate None chapter_fourteen_0097:
        gr "……接二连三地死去。这不算新闻，已经持续了…唔，比你年纪还长的年头。"
    translate None chapter_fourteen_0098:
        gr "只要稍加克制就没危险。比如最基本的：别透露真名，别深更半夜见陌生人。"
    translate None chapter_fourteen_0099:
        show raen m sur with dis
        rs "啊…"
    translate None chapter_fourteen_0100:
        gr "但有些人就是缺根弦。总想不制定计划就冒冒失失往危险里冲。你应该不认识这种蠢货吧？"
    translate None chapter_fourteen_0101:
        rs "呃…"
    translate None chapter_fourteen_0102:
        show illran m sad with dis
        "男人突然俯身逼近，严肃地盯着我的脸。"
    translate None chapter_fourteen_0103:
        gr "说真的，轮不到你来警告别人。你自己能活下来的概率都微乎其微。"
    translate None chapter_fourteen_0104:
        gr "不如让我给你几条建议。"
    translate None chapter_fourteen_0105:
        show raen m sad with dis
        rs "建议？"
    translate None chapter_fourteen_0106:
        show illran m neu with dis
        gr "紧要关头时，尽量拖住对方说话。别打毫无胜算的架。你可能孤立无援，别指望同伴有帮手。"
    translate None chapter_fourteen_0107:
        gr "第二，视线永远别离开他。稍有松懈就必死无疑。"
    translate None chapter_fourteen_0108:
        show illran m hap with dis
        gr "最后…祝你好运。你绝对需要这个。"
    translate None chapter_fourteen_0109:
        rs "你在说什么？难道你知道—"
    translate None chapter_fourteen_0110:
        gr "我该走了。别再跟踪我。"
    translate None chapter_fourteen_0111:
        gr "回到你朋友那儿去吧，我敢肯定他们已经开始想你了。"

    hide illran
    hide raen
    hide bveras
    with dissolve

    translate None chapter_fourteen_0112:
        "他转过拐角就消失了。"
    translate None chapter_fourteen_0113:
        "这些建议…奇怪地具体。听起来像是…他知道我有危险。盯紧他，继续搭话…"
    translate None chapter_fourteen_0114:
        "坚强点，雷恩。不会到那种地步的。"

    window hide dissolve

    scene bg oxhabor sunset big with dissolve:
        size(1920, 1080)
    window show dissolve
    translate None chapter_fourteen_0115:
        "我转身离开小巷归队。他们还站在我离开时的位置，周遭夜色渐浓。"

    show raen n dim sur at cenleft
    show cyne n dim neu at cenright
    show leos n dim ann at farright
    show fawn n dim sad at farleft
    with dissolve

    translate None chapter_fourteen_0116:
        rs "抱歉我刚才突然跑开，只是想警告他最近发生的怪事。"
    translate None chapter_fourteen_0117:
        l "他其实不需要警告，对吧？"
    translate None chapter_fourteen_0118:
        show raen n sad with dis
        rs "是啊…他好像对这里发生的一切了如指掌。"
    translate None chapter_fourteen_0119:
        c "我感觉你们关系不太融洽？"
    translate None chapter_fourteen_0120:
        f "这说法太轻了…"
    translate None chapter_fourteen_0121:
        rs "这是我们第三次遇见他。他装作一无所知，但我认为他其实精明得很。"
    translate None chapter_fourteen_0122:
        show leos n smi with dis
        l "成天肩膀上站只鸟，还为了找乐子来这种地方。他的智商也就跟奶酪片一个水平。"
    translate None chapter_fourteen_0123:
        show cyne n sur with dis
        c "你说的是哪种奶酪？"
    translate None chapter_fourteen_0124:
        show leos n sur with dis
        l "那个…好吧…重点不是这个。"
    translate None chapter_fourteen_0125:
        show fawn n sur with dis
        f "我是说，种类重要吗？有哪种奶酪能算得上聪明吗？"
    translate None chapter_fourteen_0126:
        show leos n pen with dis
        l "别扯奶酪了。这是个错误的话题。"
    translate None chapter_fourteen_0127:
        show raen n sur with dis
        rs "我觉得奶酪就是奶酪，对吧？"
    translate None chapter_fourteen_0128:
        show leos n pis with dis
        l "知道吗？我受够你们了。别再讨论奶酪。"
    translate None chapter_fourteen_0129:
        show cyne n hap with dis
        c "哎呀，我知道你心里是爱我们的。对雷恩是炽热的激情，对福恩是慈母爱，对我嘛…嗯…你恨不得掐死这么爱我的自己？"
    translate None chapter_fourteen_0130:
        l "真羡慕那些从来不必认识你的人，懂吗？"
    translate None chapter_fourteen_0131:
        c "他完全没有否认。"
    translate None chapter_fourteen_0132:
        l "我要当你不存在，所以你能不能换个对象骚扰？"
    translate None chapter_fourteen_0133:
        c "你这恶霸。幸亏我觉得男人这样很有魅力。不过话说回来…"
    translate None chapter_fourteen_0134:
        "赛恩从背后靠近，双手环住我的腰。"
    translate None chapter_fourteen_0135:
        c "像雷恩这么纯情的才最好玩。"

    show raen n emb
    show fawn n bla
    with dis

    translate None chapter_fourteen_0136:
        rs "等-等等？现在不是做这个的—"
    translate None chapter_fourteen_0137:
        "下一秒福恩就揪着赛恩的衣领把他拽开了。"
    translate None chapter_fourteen_0138:
        f "雷恩说得对，现在不是时候。而且任何时候都不该让你做这种事。"
    translate None chapter_fourteen_0139:
        show leos n smi with dis
        "莱奥斯对福恩露出坏笑但没说话。"
    translate None chapter_fourteen_0140:
        show cyne n sur with dis
        c "好啦好啦，别吃醋。想要我关注的话，开口求我就行。"
    translate None chapter_fourteen_0141:
        f "我才不要。"
    translate None chapter_fourteen_0142:
        c "真会伤人心啊。好吧，从现在起我要把全部注意力都放在雷恩身上。"
    translate None chapter_fourteen_0143:
        f "你为什么不把注意力放在更有用的事情上？培养个爱好什么的。"
    translate None chapter_fourteen_0144:
        c "你可能说到点子上了，我觉得把雷恩当爱好挺不错。他够我们俩分的，别担心。我不介意一人一半。"
    translate None chapter_fourteen_0145:
        f "没人要分他。别擅自做决定。"
    translate None chapter_fourteen_0146:
        show cyne n hap with dis
        c "开玩笑的啦。雷恩当然会做出正确决定，对吧？"
    translate None chapter_fourteen_0147:
        "他微笑着看向我寻求确认。"
    translate None chapter_fourteen_0148:
        show raen n con with dis
        rs "对…对吧…"
    translate None chapter_fourteen_0149:
        l "虽然争夺雷恩喜爱的小打小闹很有趣，但现在我们需要制定计划。天已经黑了，今天没法在这里继续搜查。"
    translate None chapter_fourteen_0150:
        rs "光线好的时候都很难辨认方向…"
    translate None chapter_fourteen_0151:
        l "所以实际上我们只有一个选择。今晚回诺克斯的庄园过夜。"
    translate None chapter_fourteen_0152:
        show fawn n sad with dis
        f "我想…我们确实有几个问题要问他。"
    translate None chapter_fourteen_0153:
        show raen n sad with dis
        rs "有些事情就是不对劲。我相信只要开口问他就会帮我们理清楚。"
    translate None chapter_fourteen_0154:
        show leos n neu with dis
        l "…是啊，希望如此，但我没抱太大期望。"


    scene bg ox alley night with dissolve:
        xpos 0.66 ypos 1.17 xanchor 0.5 yanchor 1.0 zoom 1.76
        linear 35.0 ypos 1.86

    translate None chapter_fourteen_0155:
        "街巷几乎没有灯光，漆黑得可怕。每向诺克斯的宅邸靠近一步，我心中的不安就加深一分。"
    translate None chapter_fourteen_0156:
        "双腿像灌了铅般沉重。要不要干脆回头…？不，都走到这里了。"
    translate None chapter_fourteen_0157:
        "凉风卷着枯叶从我们身旁掠过，仿佛在引导我们回到诺克斯的庄园。我们走近他那扇微微敞开的大门。"
    translate None chapter_fourteen_0158:
        "窗户和前一晚同样漆黑。他从来都不点蜡烛吗？还是说…就生活在黑暗里？"
    translate None chapter_fourteen_0159:
        "我轻轻敲门，门顺势而开。"
    translate None chapter_fourteen_0160:
        rs sad "…嗯…"
    translate None chapter_fourteen_0161:
        f sad "那是什么？"
    translate None chapter_fourteen_0162:
        rs sad "我对没上锁的门…可没什么好印象。"
    translate None chapter_fourteen_0163:
        c sur "这个顾虑真具体。"
    translate None chapter_fourteen_0164:
        rs sur "….有人吗？诺克斯？你在家吗？"
    translate None chapter_fourteen_0165:
        "我的声音在黑暗的房间里回荡。无人应答。"
    translate None chapter_fourteen_0166:
        f sad "也许他出去了…？"
    translate None chapter_fourteen_0167:
        rs sad "…我们该进去看看，对吧？"
    translate None chapter_fourteen_0168:
        "我率先踏入没有灯光的门厅，另外三人跟在我身后。"

    window hide dissolve

    scene gallery_61 with dissolve:
        xpos 0.70 ypos 1.19 xanchor 0.5 yanchor 1.0 zoom 1.42
        linear 30.0 xpos 0.33 ypos 1.19 xanchor 0.5 yanchor 1.0 zoom 1.42
    window show dissolve

    translate None chapter_fourteen_0169:
        c hap "哦，我之前还找到了这些！"
    translate None chapter_fourteen_0170:
        "听见赛恩摸索的声音后，一支蜡烛照亮了房间。"
    translate None chapter_fourteen_0171:
        c "给，雷恩，拿着这个！"
    translate None chapter_fourteen_0172:
        rs "哦，好的。"
    translate None chapter_fourteen_0173:
        "他把蜡烛递给我，我走在了前面。"
    translate None chapter_fourteen_0174:
        "门厅和前晚看起来没什么不同，但感觉有些…不对劲，不一样了。没有诺克斯在，这里显得…空荡。孤独，被遗忘。"
    translate None chapter_fourteen_0175:
        "我试图咽口水时，嗓子发干。"
    translate None chapter_fourteen_0176:
        c "喂—诺克斯？你在家吗—？"
    translate None chapter_fourteen_0177:
        l neu"…我们搜几个房间吧。他说不定还在附近。"
    translate None chapter_fourteen_0178:
        rs "你…你不会觉得他出什么事了吧？"
    translate None chapter_fourteen_0179:
        f sad "......."
    translate None chapter_fourteen_0180:
        c "诺—诺克斯—你在哪—？"
    translate None chapter_fourteen_0181:
        l ang "你能不能别这么大声嚷嚷？"
    translate None chapter_fourteen_0182:
        c sur "为什么？"
    translate None chapter_fourteen_0183:
        l "为什么\"是什么意思？很烦人，而且你太吵了。"
    translate None chapter_fourteen_0184:
        c "又没人抱怨。我觉得你就是故意找茬！"
    translate None chapter_fourteen_0185:
        l "他们只是太礼貌才没叫你闭嘴。小老鼠，很烦人对吧？帮我作证。"
    translate None chapter_fourteen_0186:
        "……"
    translate None chapter_fourteen_0187:
        "他没有回应。"
    translate None chapter_fourteen_0188:
        "我们打开一扇通往房子深处的门。仍然没有诺克斯的踪影。"
    translate None chapter_fourteen_0189:
        "每走一步都在房间里回荡，除了耳边响如擂鼓的心跳外再无其他声音。在这漆黑空旷的房子里，时间仿佛被无限拉长。在这漫长的寂静中，我突然想到：像诺克斯这么重要的人…为什么房子里没有成群的女仆或侍从？"


    if ft_asknox == False:
        translate None chapter_fourteen_0190:
            "但是…他小时候父母就去世了。难道从那时起他就一直这样独自生活？在这黑暗的房子里，无人相伴，无人可依？"


    else:
        translate None chapter_fourteen_0191:
            "不对。他就是独自住在这里。不知道他父母去世多久了…"

    translate None chapter_fourteen_0192:
        "我们继续深入这座至寂的宅邸。摇曳的烛光在墙上投下变幻的暗影，随着火焰摆动。"
    translate None chapter_fourteen_0193:
        "昨晚我们没机会仔细查看。光是第一层就比我长大的孤儿院还大…不知道这房子究竟有多大？"
    translate None chapter_fourteen_0194:
        play sound "doorcreak.ogg" fadeout 1.0
        "推开下一扇门时发出低沉刺耳的吱呀声。我们走进去时，灰尘在四周打着旋。"
    translate None chapter_fourteen_0195:
        l "怎么，终于喊够了？"
    translate None chapter_fourteen_0196:
        "….."
    translate None chapter_fourteen_0197:
        "他也反常地沉默着。"
    translate None chapter_fourteen_0198:
        l "感谢老天，他终于安静了。要是继续那么喊下去，下巴都要脱臼了。"
    translate None chapter_fourteen_0199:
        "我举起蜡烛照向前方，终于看清了我们进入的房间。灰尘覆盖着每一个表面，蛛网悬挂在每个角落。几件看似昂贵的家具散乱地弃置在房间里，但大多都被白布遮盖着。"
    translate None chapter_fourteen_0200:
        rs "这是…？"
    translate None chapter_fourteen_0201:
        "一幅巨大的肖像占据了整面墙的大部分，但它被布遮盖着。当我伸手触碰那块布时，发现它同样积满了灰尘。显然已经被遮盖很久了。"
    translate None chapter_fourteen_0202:
        "带着不祥的预感，我把手放在那块积满灰尘的白布上。看一眼应该无妨。"
    translate None chapter_fourteen_0203:
        "小心翼翼地将布从墙上揭下。"

    scene gallery_61 with dissolve
    translate None chapter_fourteen_0204:
        rs "这是…"
    translate None chapter_fourteen_0205:
        "一幅肖像画。一位黑发女子，头发整齐地束在头顶。她面容严肃，是完美的绘画模特。"
    translate None chapter_fourteen_0206:
        "一个高个男子站在她身旁，面无表情。留着整齐的胡须，头发短而利落。他的目光仿佛穿透了我。"
    translate None chapter_fourteen_0207:
        "在他们面前，是一个黑发戴眼镜的小男孩。他神情和其他两人一样严肃，但眼神出卖了他。他看起来…悲伤得无以言表。"
    translate None chapter_fourteen_0208:
        "每一笔触都显得技艺精湛，近乎完美的画作。无论谁画了这幅画都才华横溢。色调柔和而氛围…几乎可以说是阴郁的…但仍然很美。一种忧伤的美，如同冬天来临前最后的秋意。"
    translate None chapter_fourteen_0209:
        "那么…这一定是诺克斯和他的父母。"


    if ft_asknox == False:
        translate None chapter_fourteen_0210:
            "如果我们了解到的关于诺克斯父母的信息属实，那这一定是他们在去世前不久画的。"
        translate None chapter_fourteen_0211:
            "你是说这么小的孩子就被迫独自谋生？这个孩子，是穆拉诺家族的首领？他是怎么活到现在的？"

    translate None chapter_fourteen_0212:
        "不假思索地，我抬手触碰那幅肖像。画布表面在我的指尖下凹凸不平。"
    translate None chapter_fourteen_0213:
        rs "你们看到了吗？这一定是很多年前的诺克斯。"
    translate None chapter_fourteen_0214:
        "……"
    translate None chapter_fourteen_0215:
        "我转过身，将蜡烛举在面前。"
    translate None chapter_fourteen_0216:
        "房间里空荡荡的，只有我一个人。"

    show gallery_62 with dissolve
    translate None chapter_fourteen_0217:
        rs "伙计们…这可不好笑，快出来。"
    translate None chapter_fourteen_0218:
        rs "伙计们…？"
    translate None chapter_fourteen_0219:
        "我拼命地搜寻房间，但没人回应我的呼唤。冷汗瞬间浸透了我的后背，衬衫立刻贴在身上。我的心跳加速，在脑海中回荡。"
    translate None chapter_fourteen_0220:
        "好了，没事的。他们一定就在附近，对吧？毕竟无处可去。我们只是暂时走散了。这又不是第一次发生！"
    translate None chapter_fourteen_0221:
        "我将蜡烛握得更紧了些。是的，我没事。"
    translate None chapter_fourteen_0222:
        "远处传来狗吠声，嘈杂刺耳。"
    translate None chapter_fourteen_0223:
        "我回头看了眼来时的门，又望向通往房屋深处的另一扇门。"
    translate None chapter_fourteen_0224:
        "我该在这里等待吗？回去？还是继续寻找？ "


    scene gallery_61:
        xpos 0.70 ypos 1.19 xanchor 0.5 yanchor 1.0 zoom 1.42
        linear 30.0 xpos 0.33 ypos 1.19 xanchor 0.5 yanchor 1.0 zoom 1.42
    show noxcreepy:
        xpos 0.70 ypos 1.19 xanchor 0.5 yanchor 1.0 zoom 1.42
        linear 30.0 xpos 0.33 ypos 1.19 xanchor 0.5 yanchor 1.0 zoom 1.42
    with dissolve


    translate None chapter_fourteen_0225:
        "莱奥斯遇到这种情况会怎么做？"
    translate None chapter_fourteen_0226:
        "保持理智，雷恩。现在不是惊慌的时候。"
    translate None chapter_fourteen_0227:
        "我朝来时的门走去，指尖轻触冰冷的门把。最合理的做法是返回去找其他人。反正他们可能正在找我。"
    translate None chapter_fourteen_0228:
        "我推开门，窥探刚刚离开的房间。里面空无一人。"
    translate None chapter_fourteen_0229:
        "如果不在这里…那在哪？入口大厅吗？他们应该会找我，我最好回去。"
    translate None chapter_fourteen_0230:
        "我将蜡烛贴近身体，开始沿原路返回。现在想想…我最后一次见到他们是什么时候？"
    translate None chapter_fourteen_0231:
        "我真的自己走丢了吗？这不可能。他们刚才明明就在我身后。"
    translate None chapter_fourteen_0232:
        "走廊尽头有扇门虚掩着。当我注意到门缝透出的橘色微光时，几乎不敢相信。"

    scene gallery_62
    show noxcreepy
    with dissolve

    translate None chapter_fourteen_0233:
        rs "…莱奥斯？福恩？赛恩？是你们吗…？"
    translate None chapter_fourteen_0234:
        "我缓缓从门缝窥视。光源似乎是房间中央圆桌上的蜡烛。但屋内仍很昏暗，远处仍看不清。"


    scene bg nox spooky with dissolve:
        xpos 0.89 ypos 1.33 xanchor 0.5 yanchor 1.0 zoom 1.41
        linear 65.0 xpos 0.09 ypos 1.33 xanchor 0.5 yanchor 1.0 zoom 1.41
        linear 30 xpos 0.54 ypos 1.33 xanchor 0.5 yanchor 1.0 zoom 1.41
        repeat

    translate None chapter_fourteen_0235:
        "强压下恐惧，我推门而入。踮着脚走近桌子。"
    translate None chapter_fourteen_0236:
        "房间阴暗，有股淡淡的霉味。没有月光照进来，一个窗户都看不见。"
    translate None chapter_fourteen_0237:
        "我把自己的蜡烛放在桌上另一根旁边。我们走散时，是其他人留下的吗？"
    translate None chapter_fourteen_0238:
        "几件旧家具散落房间，覆盖着白布。"
    translate None chapter_fourteen_0239:
        "烛火突然被微风吹得摇曳闪烁，在墙上投下舞动的阴影。"
    translate None chapter_fourteen_0240:
        "等等…微风？！"


    play sound "sounds/sfx/slam.ogg"

    show black with vpunch

    translate None chapter_fourteen_0241:
        "我猛地转身，正好看见房门被关上。两根蜡烛同时熄灭，我陷入彻底的黑暗。"
    translate None chapter_fourteen_0243:
        rs sad "谁…谁在那里？"
    translate None chapter_fourteen_0244:
        "虽然什么都看不见，我的眼睛仍在疯狂地四处扫视。我试图控制呼吸，但心已经快跳到嗓子眼了。"
    translate None chapter_fourteen_0245:
        "我摸索着后退，直到后背抵上桌子。必须…必须重新点燃蜡烛，无论如何…"
    translate None chapter_fourteen_0246:
        "等等…它们在哪儿？明明刚才还…"
    translate None chapter_fourteen_0247:
        u "在找什么呢？"
    translate None chapter_fourteen_0248:
        rs wor "啊！！"
    translate None chapter_fourteen_0249:
        "当一声巨响在我耳边炸开时，我吓得跳了起来。"
    translate None chapter_fourteen_0250:
        rs "……谁在那里？现身吧！"
    translate None chapter_fourteen_0251:
        "我在黑暗中徒劳地搜寻。他们到底在哪儿…？"
    translate None chapter_fourteen_0252:
        u "你看样子很慌乱…该不会是在害怕吧？"
    translate None chapter_fourteen_0253:
        "那道居高临下的声音划破寂静，带着戏谑与欢快。我闭上眼，强压下内心蔓延的恐惧。"
    translate None chapter_fourteen_0254:
        "必须思考！动脑筋啊雷恩！快想！"
    translate None chapter_fourteen_0255:
        "….如果真如我所料…我得找到其他人。必须把他们引过来。"
    translate None chapter_fourteen_0256:
        rs wor "别过来！大伙儿，我在这儿！"
    translate None chapter_fourteen_0257:
        u "啊哈哈哈哈哈…."
    translate None chapter_fourteen_0258:
        "险恶的笑声在漆黑房间里回荡，撕裂空气。我死死咬住嘴唇。他在…他在嘲笑我。"
    translate None chapter_fourteen_0259:
        "虽然看不见，我能感觉到他近在咫尺。阴森邪恶的能量从他身上散发…必须拉开距离。"
    translate None chapter_fourteen_0260:
        "我绕着桌子移动。至少隔着桌子能稍感安心。况且这狭小房间也无处可逃…"
    translate None chapter_fourteen_0261:
        "紧抓着圆桌边缘，我扫视面前空荡荡的黑暗。他就…藏在某处，可究竟在哪儿？得先点亮蜡烛。"
    translate None chapter_fourteen_0262:
        "没有任何动静。除了我急促的呼吸声，万籁俱寂。"
    translate None chapter_fourteen_0263:
        rs ang "…只有懦夫才会躲在阴影里。有种现身！"
    translate None chapter_fourteen_0264:
        u "你玩得很开心是吧？在街上跟踪别人，扮演侦探。想必觉得自己聪明绝顶。"
    translate None chapter_fourteen_0265:
        u "没人告诉过你好奇心害死猫吗？"
    translate None chapter_fourteen_0266:
        rs ang "聪明？我根本没做什么。报上名来。"
    translate None chapter_fourteen_0267:
        u "我凭什么要告诉你？"


    if nox_earringinroom:
        translate None chapter_fourteen_0268:
            rs ang "…说得对。你确实没必要说。"
        translate None chapter_fourteen_0269:
            rs "告诉我，你从我这儿拿走的耳环怎么处理了？"
        translate None chapter_fourteen_0270:
            u "当然是让它们团聚了。"
        translate None chapter_fourteen_0271:
            "我的心沉到谷底。"
        translate None chapter_fourteen_0272:
            "我不愿相信这是真的。多希望他能矢口否认，但…"
        translate None chapter_fourteen_0273:
            rs sad "…我们曾经信任过你啊，诺克斯。"
        translate None chapter_fourteen_0274:
            nox "这都是你的错误决定。"

        scene bg nox spooky:
            size (1920, 1080)
        show raen n dim sur at slightright
        show nox n dim dem at slightleft
        with Dissolve(1.0)
        translate None chapter_fourteen_0275:
            "桌子另一端突然窜起一簇火苗，照亮了整个房间。"
        jump nox_cont2

    elif bloodonneck == True:
        translate None chapter_fourteen_0276:
            # added voice mapping to chapter_fourteen_0268 - check
            rs ang "…说得对。你确实没必要说。"
        translate None chapter_fourteen_0277:
            rs "刚才根本不是口误。你明明知道受害者是谁，对吧？你在她死前…就已经见过她了。"
        translate None chapter_fourteen_0278:
            u "……一个可悲的女人。如此渴望被爱，而我慷慨地满足了她。"
        translate None chapter_fourteen_0279:
            rs "慷慨？！你谋杀她！你把她折磨致死，还享受整个过程！你的所作所为没有半点仁慈！"
        translate None chapter_fourteen_0280:
            u "我给了她真正想要的东西。她应得的东西。"
        translate None chapter_fourteen_0281:
            "我的心沉到谷底。"
        translate None chapter_fourteen_0282:
            "我不愿相信这是真的。多希望他能矢口否认，但…"
        translate None chapter_fourteen_0283:
            # added voice mapping to chapter_fourteen_0273 - check
            rs sad "…我们曾经信任过你啊，诺克斯。"
        translate None chapter_fourteen_0284:
            # add voice mapping to chapter_fourteen_0274
            nox "这都是你的错误决定。"

        scene bg nox spooky:
            size (1920, 1080)
        show raen n dim sur at slightright
        show nox n dim dem at slightleft
        with Dissolve(1.0)

        translate None chapter_fourteen_0285:
            "桌子另一端突然窜起一簇火苗，照亮了整个房间。"
        jump nox_cont2

    elif ft_asknox == False:
        translate None chapter_fourteen_0286:
            # added voice mapping to chapter_fourteen_0276 - check
            rs ang "…说得对。你确实没必要说。"
        translate None chapter_fourteen_0287:
            "虽然只是大胆猜测，但他的说辞一次又一次无法自圆其说……"
        translate None chapter_fourteen_0288:
            rs sad "……那是你父母吧？肖像画里的人。"
        translate None chapter_fourteen_0289:
            rs "告诉我。这幅画是在他们死前多久完成的？"
        translate None chapter_fourteen_0290:
            u "不过几个月时间。那幅画可是他们的珍宝。呵，他们多迷恋自己的形象啊。毕竟穆拉诺家族高人一等。"
        translate None chapter_fourteen_0291:
            "我不愿相信这是真的。多希望他能矢口否认，但…"
        translate None chapter_fourteen_0292:
            # add voice mapping to chapter_fourteen_0283
            rs sad "…我们曾经信任过你啊，诺克斯。"
        translate None chapter_fourteen_0293:
            # add voice mapping to chapter_fourteen_0274
            nox "这都是你的错误决定。"

        scene bg nox spooky:
            size (1920, 1080)
        show raen n dim sur at slightright
        show nox n dim dem at slightleft
        with Dissolve(1.0)

        translate None chapter_fourteen_0294:
            "桌子另一端突然窜起一簇火苗，照亮了整个房间。"

        jump nox_cont2

    else:
        translate None chapter_fourteen_0295:
            "我们陷入沉默，我无言以对。早知如此…要是当初能更明智地利用时间…"

        translate None chapter_fourteen_0296:
            u "调查那么多，却连这么简单的事都看不透？那他对你的判断错了。他还以为你是他的救世主。"

        scene bg nox spooky:
            size (1920, 1080)
        show raen n dim sur at slightright
        show nox n dim dem at slightleft
        with Dissolve(1.0)

        translate None chapter_fourteen_0297:
            "桌子另一端突然窜起一簇火苗，照亮了整个房间。"
        translate None chapter_fourteen_0298:
            rs sur "诺克斯？！？"
        translate None chapter_fourteen_0299:
            nox "看来我们终于要见面了，雷恩。"

        jump nox_cont2

label nox_cont2:
    translate None chapter_fourteen_0300:
        show raen n dim sad with dis
        rs "我想要的…我们大家想要的都只是帮助你。我们相信你…我们…为什么？"
    translate None chapter_fourteen_0301:
        rs "你怎么能—"
    translate None chapter_fourteen_0302:
        "最终，我看向诺克斯。一样的着装，一样的发型，一样的脸。唯独有个细节不同。他的眼睛…漆黑一片，比我见过的任何东西都要深邃。"
    translate None chapter_fourteen_0303:
        show raen n dim sur with dis
        rs "……你是谁？"
    translate None chapter_fourteen_0304:
        show nox n dim demgri with dis
        nox "我们不是已经确认过了吗？"
    translate None chapter_fourteen_0305:
        "他的说话方式，行为举止，还有那双眼睛…根本不是我认识的诺克斯。真相到底是什么？！是我眼前所见，还是耳中所闻？"
    translate None chapter_fourteen_0306:
        show raen n dim wor with dis
        rs "不…你不是诺克斯。你不可能是诺克斯。告诉我真相！"
    translate None chapter_fourteen_0307:
        show nox n dim dem at slightleft with dis
        nox "你的自信简直令人吃惊。你似乎还没认清自己处境。你的朋友们都走了，抛弃了你。再没人保护你了。"
    translate None chapter_fourteen_0308:
        nox "就凭这样，你还觉得有资格随意质问我？"
    translate None chapter_fourteen_0309:
        "莱奥斯、福恩、赛恩…求求你们…一定要平安。我发誓会尽快找到你们…但首先我得从这里逃出去。"
    translate None chapter_fourteen_0310:
        nox "你认识的那个诺克斯只是个冒牌货。这是真相。"
    translate None chapter_fourteen_0311:
        "我认识的诺克斯…是假的？"
    translate None chapter_fourteen_0312:
        "他乞求我们帮助时那绝望害怕的样子…都是演技？"
    translate None chapter_fourteen_0313:
        "不…我不敢相信。简直就像…他完全变了个人。就像有别人…别人占据了他的身体。"
    translate None chapter_fourteen_0314:
        rs "不…不，你在骗我！"
    translate None chapter_fourteen_0315:
        rs "你…你是什么东西？"
    translate None chapter_fourteen_0316:
        nox "你此生见过的最后一个人。"
    translate None chapter_fourteen_0317:
        "我比先前更用力地抓住桌子边缘。此刻唯有它能支撑我不倒下。"
    translate None chapter_fourteen_0318:
        rs "不，你到底是什么？！你甚至不是人类？！"
    translate None chapter_fourteen_0319:
        show nox n dim demsur with dis
        nox "人类？好多年没人这么指责我了。"
    translate None chapter_fourteen_0320:
        "不是人类…那个绿发男人…他提到过…诅咒和恶魔…"
    translate None chapter_fourteen_0321:
        "漆黑双眼，饱受折磨的受害者，数以百计的谋杀…"
    translate None chapter_fourteen_0322:
        nox "即使隔着房间，你的气味…太美妙了。我能分辨。你很特别，对吧？我会确保细细品尝你的每一寸。"
    translate None chapter_fourteen_0323:
        "不…我得让他继续说下去。他是这么嘱咐我的。眼睛别离开他。别试图对抗。"
    translate None chapter_fourteen_0324:
        "我唯一的选择就是把他挡在桌子对面。若他真非人类，靠近我就完了。"
    translate None chapter_fourteen_0325:
        "诺克斯绕着桌子转圈试图逼近。我同步后撤着。"
    translate None chapter_fourteen_0326:
        "我能问什么，说什么…"

    scene bg nox spooky with dissolve:
        xpos 0.89 ypos 1.33 xanchor 0.5 yanchor 1.0 zoom 1.41
        linear 65.0 xpos 0.09 ypos 1.33 xanchor 0.5 yanchor 1.0 zoom 1.41
        linear 30 xpos 0.54 ypos 1.33 xanchor 0.5 yanchor 1.0 zoom 1.41
        repeat


label menunoxmansion:

    if demonnox_askcount == 3:
        jump demonnoxcont1

    window hide

    menu:
        "想想那些受害者" if demonnox_victims:
            window show dissolve
            $ demonnox_victims = False
            $ demonnox_askcount += 1
            jump nox_victims

        "想想诺克斯的背叛" if demonnox_betrayal:
            window show dissolve
            $ demonnox_betrayal = False
            $ demonnox_askcount += 1
            jump nox_betrayal

        "想想那个案子" if demonnox_business:
            window show dissolve
            $ demonnox_business = False
            $ demonnox_askcount += 1
            jump nox_business

label nox_victims:
    translate None chapter_fourteen_0327:
        rs sad "你…杀了那么多人，对吧？有多少？"
    translate None chapter_fourteen_0328:
        nox dem "上百…上千..数不清了。岁月流逝，几十年就这么过去…"
    translate None chapter_fourteen_0329:
        rs sur "但…不可能。你看起来顶多—"
    translate None chapter_fourteen_0330:
        nox dem "这具躯壳的年龄无关紧要。"
    translate None chapter_fourteen_0331:
        rs sad "......."
    translate None chapter_fourteen_0332:
        rs sad "…为什么杀他们？怎么杀的？"
    translate None chapter_fourteen_0333:
        nox dem "为什么？因为他们活该。人类是令人作呕的卑劣生物。为贪婪与仇恨抛弃良知。"
    translate None chapter_fourteen_0334:
        nox demang "他们不断索取，周而复始。渴求权势不惜牺牲自己，更践踏他人。"
    translate None chapter_fourteen_0335:
        nox "他们是星球的瘟疫。不配活着。"
    translate None chapter_fourteen_0336:
        rs ang "他们都是无辜的人..只想过好自己的生活。根本没招惹你！"
    translate None chapter_fourteen_0337:
        nox demang "他们为利益互相欺骗。背叛暗算不择手段向上爬。"
    translate None chapter_fourteen_0338:
        nox "无论他们是否伤害过我都无关紧要。假以时日，他们终会伤害身边所有人。"
    translate None chapter_fourteen_0339:
        rs sad "……你的想法是错的……你不能因为几个烂苹果就惩罚所有人……"
    translate None chapter_fourteen_0340:
        nox dem "走着瞧。"

    jump menunoxmansion


label nox_betrayal:
    translate None chapter_fourteen_0341:
        rs sad "当初何必费心来求我帮忙？既然早打定主意这样做，又何必假装？"
    translate None chapter_fourteen_0342:
        nox ang "不…不是的，我…我真的需要你帮忙…我…我绝不会-"
    translate None chapter_fourteen_0343:
        rs sur "诺克斯……？"
    translate None chapter_fourteen_0344:
        nox dem "……别打扰我进餐。"
    translate None chapter_fourteen_0345:
        rs sur "那是…那是真正的诺克斯吗？你们俩都在那具身体里？你对他做了什么？！"
    translate None chapter_fourteen_0346:
        nox dem "我不需要对他做什么，他自我惩罚得够多了。这双手夺取过多少条性命—无论是否他的过错—他永远都无法原谅自己。"
    translate None chapter_fourteen_0347:
        "这…这是什么意思？他在占用诺克斯的身体？"

    jump menunoxmansion

label nox_business:
    translate None chapter_fourteen_0348:
        rs sad "……我久闻穆拉诺家族大名。他们的势力范围有多大，对奥克斯哈伯的掌控多深…你就这么把这一切都抛弃了？"
    translate None chapter_fourteen_0349:
        nox dem "噢，他们那些小生意在暗处运作得好着呢。赚的钱多得超乎想象，但永远都不够。"
    translate None chapter_fourteen_0350:
        nox "不，他们变得贪婪。表面上装作镇子仁慈的施主，背地里却把竞争对手都赶出城。"
    translate None chapter_fourteen_0351:
        nox demang "与此同时，折磨着我…把我困在这座被上帝遗弃的城镇动弹不得。"
    translate None chapter_fourteen_0352:
        rs sur "什么…你什么意思？"
    translate None chapter_fourteen_0353:
        nox dem "我的意思是他们\"赚来\"的每分钱都是从别人手里抢来的。无论到哪儿，他们都在掠夺伤害，烧杀抢掠。"
    translate None chapter_fourteen_0354:
        nox demsmi "别担心。我打算让这买卖继续做下去。"
    translate None chapter_fourteen_0355:
        "他为什么还要继续经营…？"

    jump menunoxmansion

label demonnoxcont1:

    show bg nox spooky:
        xpos 0.53 ypos 1.13 xanchor 0.5 yanchor 1.0 zoom 1.69
        linear 20.0 ypos 1.63 xanchor 0.5 yanchor 1.0 zoom 1.69

    show nox m dim dem:
        xpos 0.51 ypos 1.01 xanchor 0.5 yanchor 1.0 zoom 1.47
        linear 20.0 xpos 0.51 ypos 1.53 xanchor 0.5 yanchor 1.0 zoom 1.47
    with dissolve

    translate None chapter_fourteen_0356:
        "诺克斯直勾勾盯着我，默默观察我的一举一动。"
    translate None chapter_fourteen_0357:
        "要是我眨个眼…是不是就完了…？要是我继续这样让他分神，然后呢？往门口跑？会有人来救我吗？"
    translate None chapter_fourteen_0358:
        "可如果福恩、莱奥斯和赛恩出事了…没人知道我来这儿…"
    translate None chapter_fourteen_0359:
        "不，现在自我怀疑没有意义。我必须坚持下去，必须活下去。"
    translate None chapter_fourteen_0360:
        "他又绕着餐桌朝我逼近。速度既不够快抓我，又足够让我逃跑。"
    translate None chapter_fourteen_0361:
        "他…很享受潜猎我的过程…"

    scene bg nox spooky with dissolve:
        xpos 0.89 ypos 1.33 xanchor 0.5 yanchor 1.0 zoom 1.41
        linear 65.0 xpos 0.09 ypos 1.33 xanchor 0.5 yanchor 1.0 zoom 1.41
        linear 30 xpos 0.54 ypos 1.33 xanchor 0.5 yanchor 1.0 zoom 1.41
        repeat

label menunoxmansion2:


    if demonnox_askcount == 6:
        jump demonnoxcont2

    window hide

    menu:
        "想想卡斯皮安" if demonnox_caspian:
            window show dissolve
            $ demonnox_caspian = False
            $ demonnox_askcount += 1
            jump nox_caspian2

        "想想恶魔" if demonnox_demons:
            window show dissolve
            $ demonnox_demons = False
            $ demonnox_askcount += 1
            jump nox_demons

        "想想穆拉诺家族" if demonnox_muranos:
            window show dissolve
            $ demonnox_muranos = False
            $ demonnox_askcount += 1
            jump nox_muranos



label nox_caspian2:
    translate None chapter_fourteen_0362:
        rs sad "你说认识卡斯皮安是在骗我吗？告诉我你知道他去向的时候也是撒谎？"
    translate None chapter_fourteen_0363:
        #missing line
        nox dem "真是奇怪…我肯定从未提起过他。毕竟这是我们第一次见面。"
    translate None chapter_fourteen_0364:
        nox demang "卡斯皮安…那个可悲又可恨的男人。总是逃避他的过去。净插手些与他无关的事。"
    translate None chapter_fourteen_0365:
        nox "十八年前他就该被我吞噬。我从不失手，告诉你，这次也不会例外。"
    translate None chapter_fourteen_0366:
        nox "你会是个不错的替代品。"
    translate None chapter_fourteen_0367:
        rs ang "你说他情同手足！难道你对他根本没有感情？"
    translate None chapter_fourteen_0368:
        nox sur "......."
    translate None chapter_fourteen_0369:
        nox sur "…卡斯皮安..他当然是—"
    translate None chapter_fourteen_0370:
        nox demang "闭嘴！手足？他也配！这等卑劣的人类不配与我共存于世。"
    translate None chapter_fourteen_0371:
        rs wor "你在说谎！我必须找到那个告诉我卡斯皮安对他多重要的人！"
    translate None chapter_fourteen_0372:
        nox dem "你爱信什么随你便。"

    jump menunoxmansion2

label nox_demons:
    translate None chapter_fourteen_0373:
        "恶…魔…？"
    translate None chapter_fourteen_0374:
        "这怎么可能？"
    translate None chapter_fourteen_0375:
        "我拒绝相信。这完全超出了我的理解范围，但那绿发男人的确知道些什么。"
    translate None chapter_fourteen_0376:
        rs wor "告诉我…你来自…这个世界吗？"
    translate None chapter_fourteen_0377:
        nox dem "哈！你觉得我该来自何处？生前死后，我唯一的愿望就是逃离这个世界…但现实残酷。临终时我以为终于解脱了。可你看。"
    translate None chapter_fourteen_0378:
        rs sur "你已…死去？我不明—"
    translate None chapter_fourteen_0379:
        nox demang "这副躯壳确实活着…但我算死物，活人，还是被困在生死之间的囚徒？"
    translate None chapter_fourteen_0380:
        "他的身体还活着？难道真正的诺克斯被困在他体内？等等…究竟哪个才是\"真正\"的诺克斯？"
    translate None chapter_fourteen_0381:
        "我不明白…完全不明白…"
    translate None chapter_fourteen_0382:
        rs wor "你的声音和举止都与我认识的诺克斯截然不同…我不信他是伪装的…说实话…你是恶魔吗？"
    translate None chapter_fourteen_0383:
        "他眼中寒光稍纵即逝。我攥紧桌角准备逃跑，却发现他毫无动作。"
    translate None chapter_fourteen_0384:
        nox demsmi "聪明。从来没人猜中过。要么你深藏不露，要么…有人泄密。"
    translate None chapter_fourteen_0385:
        "恶…魔。传说中邪恶的化身。看他神情，绝非玩笑。"
    translate None chapter_fourteen_0386:
        "但恶魔是什么？最显而易见的答案是…神的对立面，对吗？他就是这样的存在吗？"
    translate None chapter_fourteen_0387:
        "他的手指轻叩桌面，打断了我的思绪。"

    jump menunoxmansion2

label nox_muranos:
    translate None chapter_fourteen_0388:
        rs sad "穆拉诺家族发生了什么？我听说他们曾是权势滔天的家族，如今却只剩下…你。"
    translate None chapter_fourteen_0389:
        nox demang "用勺子刮桶底刮出来的渣滓—这就是穆拉诺家。秽物。淤泥。他们活该遭受这一切，也配得上即将降临的所有报应。"
    translate None chapter_fourteen_0390:
        rs sad "是你杀了他们？"
    translate None chapter_fourteen_0391:
        nox dem "哦，单纯杀掉就太仁慈了。我慢慢吸食他们的精髓，细细品味他们肮脏灵魂的每一丝滋味。"
    translate None chapter_fourteen_0392:
        "吸食…他们的精髓？什么？"
    translate None chapter_fourteen_0393:
        rs sad "……没有人该被屠杀。没有人该遭受那种对待。"
    translate None chapter_fourteen_0394:
        nox dem "真的吗？当真如此？告诉我，如果我说我折磨你的朋友直到他们求死，你会想宰了我吗？会吗？"
    translate None chapter_fourteen_0395:
        nox dem "凭什么你的行为情有可原，我的就罪无可恕？谋杀凭什么能变得正当，变得合理？"
    translate None chapter_fourteen_0396:
        rs wor "……绝不…这绝对不是正确的事…"
    translate None chapter_fourteen_0397:
        nox demang "等你被违背意愿囚禁数百年，被扎刺探查的时候再说这话吧。等你被利用虐待的时候。你还没见识过人类的自私，对吧？你没在他们手中受过苦。"
    translate None chapter_fourteen_0398:
        nox "当你的皮肉被活剥，鲜血被抽干饮尽，而痛饮者竟是你曾宣誓保护之人…那时我自会聆听你的高见。"
    translate None chapter_fourteen_0399:
        nox "不过话说回来，你永远不会有这个机会。"

    jump menunoxmansion2

label demonnoxcont2:
    scene bg nox spooky:
        xpos 0.59 ypos 1.49 xanchor 0.5 yanchor 0.97 zoom 1.51
    show raen m dim sad at closeright
    show nox m dim dem at closeleft
    with Dissolve(1.0)
    translate None chapter_fourteen_0400:
        "若他所言属实…那他就是真正的诺克斯，可他说话的方式仿佛这并非他自己的身体。"
    translate None chapter_fourteen_0401:
        "他还自称恶魔，说穆拉诺家将他囚禁于此不断折磨。莫名荒诞。"
    translate None chapter_fourteen_0402:
        "真正的诺克斯—不，我认识的那个诺克斯一定还在某处。肯定有什么话语能唤醒他。"
    translate None chapter_fourteen_0403:
        rs "诺克斯…诺克斯，求你了。你一定还在某个角落存在着。"
    translate None chapter_fourteen_0404:
        rs "我知道你还在那里！那个与卡斯皮安最要好的男孩哪去了？那个比任何人都崇敬他的少年哪去了？"
    translate None chapter_fourteen_0405:
        rs "那个需要我协助对抗镇上邪恶的男人哪去了？他没有消失，我绝不相信！"
    translate None chapter_fourteen_0406:
        nox "要我告诉你多少遍—"
    translate None chapter_fourteen_0407:
        show raen m dim ang with dis
        rs "不！别说你恨卡斯皮安，也别告诉我你才是真正的诺克斯！我不想听！"
    translate None chapter_fourteen_0408:
        rs "如果你现在不帮我，我就再也找不到卡斯皮安了。难道你不想再见到他吗？！"
    translate None chapter_fourteen_0409:
        show nox m dim ang with dis2
        nox "我…呃…我..我想！"
    translate None chapter_fourteen_0410:
        nox "雷恩..我..我很抱歉，我不知道能不能…阻止他.."
    translate None chapter_fourteen_0411:
        show raen m dim sur with dis
        rs "诺克斯！诺克斯，真的是你吗？"
    translate None chapter_fourteen_0412:
        "我借着烛光凝视他的脸。他的眼睛泛红，神情痛苦。"
    translate None chapter_fourteen_0413:
        "我抛却最后一丝疑虑，冲到他身旁。"
    translate None chapter_fourteen_0414:
        show nox m dim sad with dis
        nox "你…你必须逃走。我阻止不了他。他会杀了你—"
    translate None chapter_fourteen_0415:
        show raen m dim sad with dis
        rs "我不能就这样丢下你。绝不。如果我此刻逃了，你会怎样？！"
    translate None chapter_fourteen_0416:
        nox "别逞英雄…我能承受。已经习惯了。我会拖住他，你必须离开。"
    translate None chapter_fourteen_0417:
        "我望向门口。我能逃…只要够快，就能即刻离城，摆脱他的魔爪。"
    translate None chapter_fourteen_0418:
        "可是…"
    translate None chapter_fourteen_0419:
        "诺克斯…"
    translate None chapter_fourteen_0420:
        rs "…我说过要阻止谋杀。说过会找出真凶并拯救你。决不食言。"
    translate None chapter_fourteen_0421:
        show nox m dim sur with dis
        nox "你…真是愚蠢…"
    translate None chapter_fourteen_0422:
        show nox m dim sad with dis
        nox "…你做到了。你侦破了案件，所以…我也会遵守约定。"
    translate None chapter_fourteen_0423:
        nox "真相…关于我…以及卡斯皮安…"
    translate None chapter_fourteen_0424:
        show nox m dim demang with dis2
        nox "不！你还以为这黄毛小子能解救你？！永远别想摆脱我！"
    translate None chapter_fourteen_0425:
        show nox m dim sad with dis2
        nox "滚..滚开！别插手这事！"
    translate None chapter_fourteen_0426:
        nox "雷恩，我…并非一直如此。初见卡斯皮安时，我只是普通孩子。"
    translate None chapter_fourteen_0427:
        nox "我的家族…数百年前居于锡德卡汉，但…遭到驱逐，被其他高阶家族视为耻辱…"
    translate None chapter_fourteen_0428:
        nox "他们满腔怒火…心怀怨恨…迁徙至此地奥克斯哈伯，却在途中…"
    translate None chapter_fourteen_0429:
        nox "这听起来难以置信。说实话当初我也不信…他们发现了本不该现世之物。"
    translate None chapter_fourteen_0430:
        show raen m dim sur with dis
        nox "一尊…神祇。具现化的神明。趁其虚弱时，他们将之强行拖回奥克斯哈伯。"
    translate None chapter_fourteen_0431:
        nox "他们把神明囚于牢笼，为…可能向国王复仇而亢奋…"
    translate None chapter_fourteen_0432:
        show nox m dim demang with dis2
        nox "{b}闭嘴！{/b}不要..不要告诉他关于—"
    translate None chapter_fourteen_0433:
        show nox m dim sad with dis2
        nox "他们以为…吃掉他的血肉…就能获得长生和力量…"
    translate None chapter_fourteen_0434:
        nox "但是..这只让那位神明变得痛苦而愤怒…被囚禁数百年的折磨远超想象，谁能不怨恨呢…"
    translate None chapter_fourteen_0435:
        show nox m dim pen with dis
        nox "他…逐渐憎恨人类..孤独和虐待侵蚀了他的神志，使他…从狩猎之神…堕落成了恶魔…"
    translate None chapter_fourteen_0436:
        nox "他挣脱镣铐获得自由…心灵却已扭曲无法挽回…我的家人…被他一个个吞噬"
    translate None chapter_fourteen_0437:
        rs "他…吃了他们？"
    translate None chapter_fourteen_0438:
        nox "他不是啃食肉体，而是啖尽灵魂。那些人恐惧万分，却…舍不得恶魔的力量，最终达成交易"
    translate None chapter_fourteen_0439:
        nox "只要定期献祭，他就网开一面并赐予部分力量"
    translate None chapter_fourteen_0440:
        rs "难道…你体内的恶魔就是他？他曾是神明？！"
    translate None chapter_fourteen_0441:
        nox "没错。我猜…你肯定在想…怎么会变成这样对吧？"
    translate None chapter_fourteen_0442:
        nox "卡斯皮安…他本该是下一个祭品…名字显现时就像你一样。我不能让他死…尤其在我有能力干涉时"
    translate None chapter_fourteen_0443:
        show nox m dim demang with vpunch
        nox "你从我这里偷走了他！他本应属于我！"
    translate None chapter_fourteen_0444:
        show nox m dim ang with dis2
        nox "滚出我的脑海！他不配获得那些！他是我的家人！"
    translate None chapter_fourteen_0445:
        show nox m dim sad with dis
        nox "我的父母…会毫不犹豫把卡斯皮安献给诺克斯。所以..我帮他逃走了。提前示警让他安全脱身"
    translate None chapter_fourteen_0446:
        nox "诺克斯当时…暴怒至极。至今余怒未消。那是我见过最恐怖的盛怒。我本要代替卡斯皮安被吞噬，但父母跪求他饶我一命"
    translate None chapter_fourteen_0447:
        nox "…我是唯一继承人，这才是他们让我活着的理由。如果还有其他子嗣…"
    translate None chapter_fourteen_0448:
        nox "具体原理我不完全明白，但…他当时寄宿的躯体正在衰弱腐朽，于是…我父母…让他占据了我半身。此后每个…每个祭品都死在我手里。我无力阻止"
    translate None chapter_fourteen_0449:
        nox "我的…母亲和父亲…都因我无法控制他而惨死…"
    translate None chapter_fourteen_0450:
        show raen m dim sad with dis
        rs "为什么不早点告诉我？！我本可以…本可以做些什么的！"
    translate None chapter_fourteen_0451:
        nox "如果我一开始就告诉你，真不知道你会变成什么样子。"
    translate None chapter_fourteen_0452:
        nox "你无能为力。对我来说已经太迟了，我们在一起太久了。我…不认为还有什么办法能把我们分开。"
    translate None chapter_fourteen_0453:
        nox "向你求助…是个错误。我本就不该让你卷入如此危险的事。"
    translate None chapter_fourteen_0454:
        nox "你还有…时间。你需要像卡斯皮安那样逃走，去锡德卡汉。"
    translate None chapter_fourteen_0455:
        rs "然后呢？你就这样永远被困在这里？"
    translate None chapter_fourteen_0456:
        show nox m dim pen with dis
        nox "…如果你不想逃，那就杀了我，因为我无法自行了断。这是永远结束这一切的唯一方法。"


    scene bg nox spooky with dissolve:
        xpos 0.43 ypos 1.59 xanchor 0.5 yanchor 0.97 zoom 1.7

    translate None chapter_fourteen_0457:
        "他背过身去，走向一面墙，那里有块布遮盖着某件东西。"
    translate None chapter_fourteen_0458:
        "他猛地扯下那块布，露出一面华丽的大镜子。"
    translate None chapter_fourteen_0459:
        show nox c dim sad with Dissolve(1.0)
        "他小心翼翼地抬手触碰镜中的自己。"
    translate None chapter_fourteen_0460:
        nox "我已经不是…原来的我了。我是个怪物。"

    play sound "sounds/sfx/glasssmash2.ogg" fadeout 1.0
    hide nox c dim sad with shatterdissolve

    translate None chapter_fourteen_0461:
        rs sur "啊！"


    scene bg nox spooky:
        xpos 0.59 ypos 1.49 xanchor 0.5 yanchor 0.97 zoom 1.51
    show raen m dim sad at closeright
    show nox m dim sad at closeleft
    with Dissolve(1.0)

    translate None chapter_fourteen_0462:
        "随着一声碎裂声，他打碎了镜子，碎片中扭曲的倒影直直回望着他。他迅速回到我身边。"
    translate None chapter_fourteen_0463:
        nox "拿着这个。别害怕。"
    translate None chapter_fourteen_0464:
        "他抓起我的手，将一块锋利的大玻璃碎片塞进我掌心，仔细合拢我的手指。"
    translate None chapter_fourteen_0465:
        nox "杀了我，让我流血而死，然后逃跑。永远别再回到这里。"
    translate None chapter_fourteen_0466:
        show raen m dim ang with dis
        rs "不！我不会那么对你！你说什么我都不会照做！"
    translate None chapter_fourteen_0467:
        show nox m dim ang with dis
        nox "你怎么就是不明白？！无论…无论我怎么尝试，自己都做不到，但这是唯一的办法！如果我活着，奥克斯哈伯的每个人都会继续受苦！"
    translate None chapter_fourteen_0468:
        rs "你不只是他！你是…你是你自己，我不会这么轻易放弃你！"
    translate None chapter_fourteen_0469:
        show nox m dim demang with dis2
        nox "够了！我已经任由你废话太久了。"
    translate None chapter_fourteen_0470:
        show raen m dim sur with dis
        "我试图后退，但距离太近。根本无处可逃。"
    translate None chapter_fourteen_0471:
        nox "别移开视线。你可以看着我撕碎这个卡斯皮安的冒牌货。"
    translate None chapter_fourteen_0472:
        nox "我突然…饿极了。"
    translate None chapter_fourteen_0473:
        show raen m dim ang with dis
        rs "放了诺克斯—"
    translate None chapter_fourteen_0474:
        show raen m dim hur with vpunch
        rs "啊！"
    translate None chapter_fourteen_0475:
        "突然，我的手臂被非人的力量拽住。手中的玻璃碎片飞出去落在地板上。"
    translate None chapter_fourteen_0476:
        "无论我怎么挣扎，都无法挣脱他的钳制。"
    translate None chapter_fourteen_0477:
        rs "等等，别这样！求你了，放开我！"
    translate None chapter_fourteen_0478:
        "他更加用力地攥紧我的胳膊。仅用一只手，他就将我彻底钳制。"
    translate None chapter_fourteen_0479:
        "不…我得让他继续说下去然后挣脱…！"
    translate None chapter_fourteen_0480:
        nox "反抗我毫无意义。"
    translate None chapter_fourteen_0481:
        rs "等等！我们可以好好谈谈！"


    hide raen
    hide nox
    scene bg nox spooky:
        xpos 0.54 ypos 1.46 xanchor 0.5 yanchor 0.97 zoom 1.7
    with vpunch
    play sound "sounds/sfx/punch2.ogg" fadeout 1.0

    translate None chapter_fourteen_0482:
        "当一记重击砸向腹部时，我的身体痛苦地蜷缩起来。"
    translate None chapter_fourteen_0483:
        rs hur "啊！"
    translate None chapter_fourteen_0484:
        "我用没被束缚的手臂环住腰部，咬紧牙关。好疼…真的好疼…"
    translate None chapter_fourteen_0485:
        nox demang "能被我看中是你的荣幸，你却还想逃跑。听清楚了—我不会放你走。你将取代卡斯皮安！"
    translate None chapter_fourteen_0486:
        "余光瞥见那片碎玻璃就落在不远处。只要能够到它…"
    translate None chapter_fourteen_0487:
        "…但那样就意味着要杀掉他们两个。我…不想那样。绝对不想！"
    translate None chapter_fourteen_0488:
        rs hur "....."
    translate None chapter_fourteen_0489:
        rs "你究竟对我的朋友们做了什么？"
    translate None chapter_fourteen_0490:
        nox demsmi "他们现在很安全，只是被我送走了而已。"
    translate None chapter_fourteen_0491:
        nox "毕竟我们不需要干扰。不过别为他们错过好戏难过，结束后我自会接他们回来。"
    translate None chapter_fourteen_0492:
        "愤怒如血色浪潮冲刷全身，却只让我倍感无力。我连一条手臂都挣不脱，更别提救他们了…"
    translate None chapter_fourteen_0493:
        "他对我笑着，享受这场折磨。"
    translate None chapter_fourteen_0494:
        rs hur "…别笑了。他们…他们对我比什么都重要！敢伤害他们，我绝不放过你！"


    show bg nox spooky with hpunch
    translate None chapter_fourteen_0495:
        rs "呃啊…！"
    translate None chapter_fourteen_0496:
        "我被狠狠摔在木桌上，后背撞上硬板。他压住我，投下阴影。"
    translate None chapter_fourteen_0497:
        "糟了…完全动不了…！"
    translate None chapter_fourteen_0498:
        rs "滚开！放开我！"
    translate None chapter_fourteen_0499:
        nox "多狼狈啊，卡斯皮安的冒牌货。知道吗？真可惜。换个时间线我们本可以成为挚友。"
    translate None chapter_fourteen_0500:
        nox demang "这不正是你期待的吗？当我的救世主，拯救我。可惜人生不是童话。"
    translate None chapter_fourteen_0501:
        "我试图抽出手腕，却徒劳无功。"
    translate None chapter_fourteen_0502:
        "这就是…我的死法。"
    translate None chapter_fourteen_0503:
        rs "诺克斯！求求你救救我！诺克斯！！！"
    translate None chapter_fourteen_0504:
        nox demsmi "这次我不会让他帮你了。"
    translate None chapter_fourteen_0505:
        "他咧嘴一笑，两颗尖牙从下唇探出。"
    translate None chapter_fourteen_0506:
        "这是…结束了吗？他会轻易把我撕成碎片的…"
    translate None chapter_fourteen_0507:
        "不…不，求你了…我还没准备好去死，还没到时候。还有太多我不知道的事…太多没见过的风景…"
    translate None chapter_fourteen_0508:
        "已经无处可逃，没有退路了。"
    translate None chapter_fourteen_0509:
        "他把脸贴近我的脖子。"
    translate None chapter_fourteen_0510:
        rs "救命！来人啊，救命！"
    translate None chapter_fourteen_0511:
        nox "我会好好享受的。你可真香啊。"
    translate None chapter_fourteen_0512:
        nox "尽管叫吧，想怎么尖叫都行。没人会来救你的。"
    translate None chapter_fourteen_0513:
        "他的舌头划过我的喉咙，我能感觉到他的獠牙在摩擦着我的皮肤。"
    translate None chapter_fourteen_0514:
        "他要…撕开我的喉咙了…我要死了！"
    translate None chapter_fourteen_0515:
        rs "诺克斯，求求你—"



    play sound "sounds/sfx/slam.ogg" fadeout 1.0
    show bg nox spooky with hpunch

    translate None chapter_fourteen_0516:
        rs "啊！"
    translate None chapter_fourteen_0517:
        stop music fadeout 3.0
        "门突然被猛地推开，撞击声在房间里回荡。两道银色闪光从敞开的门飞进来，直冲餐桌。一把插进木头里，另一把扎进诺克斯的肩膀。"
    translate None chapter_fourteen_0518:
        nox "嘶—"
    translate None chapter_fourteen_0519:
        "当我看向侧面时，发现一把造型奇特的匕首插在桌上…看起来和莱奥斯的不同…而且离我的脸只有几英寸。"
    translate None chapter_fourteen_0520:
        "那…那差点就击中我了！谁会在这种地方乱扔匕首？！"
    translate None chapter_fourteen_0521:
        "诺克斯放开了我，伸手拔掉胳膊上的刀刃。"
    translate None chapter_fourteen_0522:
        nox "唉…你也知道，打扰别人用餐是很不礼貌的。敲个门就行了。"
    translate None chapter_fourteen_0523:
        "身上的重压消失后，我从桌上滚下来摔在地上，迅速站起后退远离诺克斯。"
    translate None chapter_fourteen_0524:
        "他把血迹斑斑的匕首扔在桌上，将注意力转向门口。一个身影走进房间，面色凝重。"
    translate None chapter_fourteen_0525:
        "等等…真的假的？"

    show illran m neu
    show bveras m neu:
        xpos 0.5 ypos 1.0 xanchor 0.52 yanchor 1.03
    with dis

    translate None chapter_fourteen_0526:
        "绿色的头发扎成蓬松的马尾，垂落在背后。一只小鸟停在他肩上。"
    translate None chapter_fourteen_0527:
        "他平日里戏谑的笑容消失了。"

    hide illran
    hide bveras
    with dissolve

    translate None chapter_fourteen_0528:
        "那只鸟从他肩上飞起，径直向我冲来，然后—"
    translate None chapter_fourteen_0529:
        show poof with flash
        "噗！"
    translate None chapter_fourteen_0530:
        hide poof with Dissolve(0.6)
        "我的视野突然被白色云雾遮蔽。我咳嗽着用手驱散面前的雾气。雾气逐渐消散，只剩一小团云朵环绕着…等等，什么…？"
    translate None chapter_fourteen_0531:
        "我眨了好几次眼，还是无法理解眼前的景象。这…这是什么？"


    scene bg nox spooky
    show veras n dim o3 neu1
    show raen n dim sur at right
    show nox n dim dem at left
    with dissolve

    translate None chapter_fourteen_0532:
        "第二个男人站在我面前，挡在我和诺克斯之间。他就像从云中跳出来的一样。"
    translate None chapter_fourteen_0533:
        "他的发色如同蜜桃，而且…"
    translate None chapter_fourteen_0534:
        "…他没穿衣服。就像是，完全赤裸的状态。"
    translate None chapter_fourteen_0535:
        "我的脑袋发晕…究竟发生了什么…？"

    play sound "sounds/sfx/clothrustle.ogg" fadeout 1.0
    hide nox
    hide raen
    show bg nox spooky:
        xpos 0.54 ypos 1.41 xanchor 0.5 yanchor 0.93 zoom 1.49
        linear 1.0 xpos 0.54 ypos 1.51 xanchor 0.5 yanchor 0.93 zoom 1.49
    show veras m dim neu:
        xpos 0.5 ypos 1.11 xanchor 0.5 yanchor 1.0 zoom 1.38
        linear 1.0 xpos 0.5 ypos 1.21 xanchor 0.5 yanchor 1.0 zoom 1.38
    with dis

    translate None chapter_fourteen_0536:
        "绿发男子迅速将一捆布料抛到同伴肩上，随后将目光转向我。"
    translate None chapter_fourteen_0537:
        "怎么从被人按着拼命反抗，变成现在这样…？这…这是怎么回事？！"
    translate None chapter_fourteen_0538:
        rs sur "呃…什么…？发生什么事了？！谁…？"
    translate None chapter_fourteen_0539:
        "他匆匆披上像是斗篷的衣物，拽着我的手腕带我远离诺克斯。我终于看清了他的脸—五官温润平和，神情却异常凝重。"
    translate None chapter_fourteen_0540:
        pr "雷恩，退后。"

    hide veras

    scene bg nox spooky
    show veras n dim neu1
    show nox n dim dem at left
    show illran n dim neu at right
    with Dissolve(0.7)

    translate None chapter_fourteen_0541:
        nox "哎呀呀…我们这是遇见谁了？不请自来的客人？也好，人多热闹。反正今晚我正好饿得厉害。"
    translate None chapter_fourteen_0542:
        show illran n dim hap with dis
        gr "真是慷慨的提议！谢了，不过看来今晚你得饿肚子了。"
    translate None chapter_fourteen_0543:
        nox "哈，走着瞧。"
    translate None chapter_fourteen_0544:
        "鲜血浸透诺克斯的衬衫，将衣料染得猩红，但他似乎感觉不到痛楚…反而透着几分愉悦。"
    translate None chapter_fourteen_0545:
        "冰冷的手指箍紧了我的手腕。"
    translate None chapter_fourteen_0546:
        play music "sounds/bgm/forgotten.ogg" fadeout 2.0
        show veras n dim fro1 with dis
        pr "猎神大人，您的行为有失身份。请收手。"
    translate None chapter_fourteen_0547:
        show nox n dim demang with dis
        nox "我不是神，而你…凭什么评判我的行为？区区人类—"
    translate None chapter_fourteen_0548:
        show nox n dim demsur with dis
        nox "不，等等…"
    translate None chapter_fourteen_0549:
        "诺克斯透过黑暗打量着桃发男子，审视着他的每个动作。"
    translate None chapter_fourteen_0550:
        show nox n dim demsmi with dis
        nox "…你不是人类。和我一样。"
    translate None chapter_fourteen_0551:
        gr "和你一样？一条需要戴口套的疯狗？"

    show illran n dim neu
    show nox n dim dem
    with dis

    translate None chapter_fourteen_0552:
        gr "不，你们完全不同。"
    translate None chapter_fourteen_0553:
        pr "你在此地的所作所为是错误的。你背弃了对这些子民的职责，将他们弃如敝屣。"
    translate None chapter_fourteen_0554:
        nox "我不欠他们什么。当他们决定囚禁我分食血肉时，就已解除了我的职责。这是他们自找的。"
    translate None chapter_fourteen_0555:
        show nox n dim demang with hpunch
        nox "我守护这片土地数百年。为这些人付出了一切—看看他们做了什么。他们背叛了我！"
    translate None chapter_fourteen_0556:
        show veras n dim sad1 with dis
        pr "对于你的遭遇…我深感抱歉。我知道…我明白那种感受。我的经历与你相差无几。"
    translate None chapter_fourteen_0557:
        pr "你想要复仇无可厚非。他们对你的所作所为确实错误，其中许多人都死有余辜。"
    translate None chapter_fourteen_0558:
        show veras n dim fro1 with dis
        pr "但你附身的孩子没有过错。其他受害者也是。"
    translate None chapter_fourteen_0559:
        nox "他们毫无差别！假以时日，他们终会变得和祖辈父辈一样！"
    translate None chapter_fourteen_0560:
        nox "你我本是一类人！像你这样的人应该明白…这些行走的疾病就该被扼杀在摇篮里。"
    translate None chapter_fourteen_0561:
        pr "不，看来我们分歧就在于此。"
    translate None chapter_fourteen_0562:
        pr "人类并不完美。他们有缺陷，会犯罪，内心可能充满贪婪，但是…"
    translate None chapter_fourteen_0563:
        pr "这就是人性使然。每个人都会犯错。"
    translate None chapter_fourteen_0564:
        pr "你没权力决定他们的命运。杀戮是错误的。必须让他们有机会学习成长，在过失中获得宽恕。"
    translate None chapter_fourteen_0565:
        pr "应该允许他们决定自己的命运。"

    hide illran with dissolve
    show nox at slightleft
    show veras at slightright
    with move
    show nox n dim dem with dis

    translate None chapter_fourteen_0566:
        nox "哦，你的智慧真让我吃惊。需要我提醒你上次信任人类的下场吗？我们被宣布为非法，遭到追捕杀戮。从天界放逐无处可逃。"
    translate None chapter_fourteen_0567:
        nox "我们当初都发誓要不惜一切保护他们，换来的是屠杀！幸存者失去了一切！他们不配得到宽恕，只配去死！必须为罪行付出代价！"
    translate None chapter_fourteen_0568:
        show veras n dim sad1 with dis
        pr "那都是几百年前的事了。人类会变，会适应！你该放下仇恨了。"
    translate None chapter_fourteen_0569:
        "眼前这个男人…他是…神明？"
    translate None chapter_fourteen_0570:
        "我用余光注意到那个绿发男子正趁诺克斯分神时，悄无声息地绕到他身后。"
    translate None chapter_fourteen_0571:
        "我看见他手中握着一把寒光闪闪的金属匕首。"
    translate None chapter_fourteen_0572:
        rs wor "等等！"
    translate None chapter_fourteen_0573:
        show nox n dim demang with dis
        nox "我可没忘了你，人类！"

    hide nox
    hide veras
    with dissolve

    scene bg nox spooky with hpunch:
        xpos 0.89 ypos 1.33 xanchor 0.5 yanchor 1.0 zoom 1.41

    translate None chapter_fourteen_0574:
        "他猛地转身扣住绿发男子的肩膀，直取咽喉。"
    translate None chapter_fourteen_0575:
        "桃发男子瞬间将同伴推开，自己迎了上去。诺克斯的利齿立即咬住了他的喉咙。"
    translate None chapter_fourteen_0576:
        pr ouc "呃啊…"
    translate None chapter_fourteen_0577:
        "我紧闭双眼不敢看这骇人场面。我必须…必须做点什么…！"
    translate None chapter_fourteen_0578:
        show bg nox spooky with hpunch
        "就在这时，诺克斯突然被甩出去滑倒在地。"
    translate None chapter_fourteen_0579:
        rs sur "呃…你…你没事吧？"
    translate None chapter_fourteen_0580:
        pr fro "先别管我。有更紧要的事要处理。"
    translate None chapter_fourteen_0581:
        "他用手按住颈部伤口止血。"
    translate None chapter_fourteen_0582:
        nox demsur "怎…怎么可能？！我的力量…"



    scene bg nox spooky with dissolve
    show nox n dim sur at left
    show veras n dim neu1
    show illran n dim armsdown neu at right
    with dis

    translate None chapter_fourteen_0583:
        nox "呃啊…"
    translate None chapter_fourteen_0584:
        gr "匕首淬了毒。虽不致命，但足以让你瘫痪到我们解决你。"
    translate None chapter_fourteen_0585:
        nox "求求你们…杀了我…我再也…无法这样活下去了…"
    translate None chapter_fourteen_0586:
        "两人走近仔细检视着他。"
    translate None chapter_fourteen_0587:
        show veras n dim sad1 with dis
        pr "他不该遭这种罪…没人应该…但他活着威胁太大了。"
    translate None chapter_fourteen_0588:
        pr "终于能与你面对面交谈…我很抱歉。很抱歉你不得不这样生活。很抱歉你只看到了我们最糟糕的一面，但请安心吧。你的灵魂终将获得自由。"
    translate None chapter_fourteen_0589:
        rs wor "等等，求求你，等一下！"
    translate None chapter_fourteen_0590:
        rs "一定有什么办法能救他的，求你了！除了杀死他之外的任何方法！"
    translate None chapter_fourteen_0591:
        #MISING ADDED VOICE MAPPING TO chapter_sixteen_0280
        gr "..."
    translate None chapter_fourteen_0592:
        pr "..."
    translate None chapter_fourteen_0593:
        pr "…他们在一起的时间实在太久了。如果说有什么办法能把他们分开，我并不知道，但…"
    translate None chapter_fourteen_0594:
        pr "…或许有件事我能做。"
    translate None chapter_fourteen_0595:
        rs wor "求求你！如果我现在眼睁睁看着他死去，我永远都无法原谅自己。"
    translate None chapter_fourteen_0596:
        pr "恐怕…另一种选择可能比死亡更糟。我可以抽走他足够多的灵魂让他昏迷，然后带他去找可能有办法帮忙的人，但是…不能保证他还能醒来。"
    translate None chapter_fourteen_0597:
        pr "而如果他醒不过来，他将永远与那个恶魔困在一起。"
    translate None chapter_fourteen_0598:
        rs sur "我…"
    translate None chapter_fourteen_0599:
        "…这不该由我来决定。永恒的折磨，与那个恶魔困在一起…不，我不能这样做。"

    $ about_Nox._text = ["狩猎之神。\n \n诺克斯曾是位高贵的神明，帮助猎人和那些在他森林中迷路的人。他以严肃但真诚著称。\n \n但不幸的是，那段时光无法永恒。众神的时代终结了，他被弃置一旁。追随者和信徒们背叛了他，避而远之，耗尽了他曾经拥有的所有力量。为求生存，他被迫附身在人类躯体内—正是在那时，穆拉诺家族发现了他。\n \n决心利用他的力量重振家族在锡德卡汉的地位，他们将诺克斯囚禁起来，进行各种实验—坚信能窃取他的力量，使自己获得永生。 \n \n虚弱无力的诺克斯经历了刻骨铭心的痛苦，这彻底改变了他。他等待时机，推翻囚禁者，逐个杀掉他们，最后只剩下索伦和他父母。他们乞求活命，诺克斯决定饶恕他们，条件是供奉—人命。\n \n当索伦协助卡斯皮安逃跑后，这个协定终止了，诺克斯决定与索伦共用一个身体。自此，两人合为一体，他们的想法难以区分，但这种新安排对诺克斯极其有利。这就是他迫使穆拉诺家族付出的代价—他们最后的后裔，堕落成纯粹的杀人工具。"]
    $ about_Nox.image = "gui/codex/entries/people/enc_noxdemon.jpg"

    translate None chapter_fourteen_0601:
        "我望向{a=set_entry:enc_people->about_Nox}{color=#87CEEB}诺克斯{/color}{/a}，他的眼睛已经变回粉色。"
    translate None chapter_fourteen_0602:
        show nox n dim pen with dis
        nox "雷恩，你…在我们相遇之前，这就是我梦寐以求的…但是…"
    translate None chapter_fourteen_0603:
        nox "…永远沉睡的风险是值得的，如果有朝一日…我能获得自由…我会变得强大…"
    translate None chapter_fourteen_0604:
        show nox n dim demang at shake
        nox "不！我不会这么容易被带走！"
    translate None chapter_fourteen_0605:
        gr "快，按住他！"

    scene gallery_68:
        xpos 0.79 ypos 1.59 xanchor 0.5 yanchor 1.0 zoom 1.63
        linear 15.0 xpos 0.61 ypos 1.59 xanchor 0.5 yanchor 1.0 zoom 1.63
    with hpunch

    translate None chapter_fourteen_0606:
        "我跳到绿发男子身旁，将诺克斯按在地上。在我们两人的控制下，任凭他挣扎也无法挣脱。"
    translate None chapter_fourteen_0607:
        "他依然强得可怕，但与我之前感受到的力量相比已大不如前。毒药起效了。"
    translate None chapter_fourteen_0608:
        nox "放开我！我要杀了你们！把你们全杀光！"
    translate None chapter_fourteen_0609:
        nox "我要撕开你们的喉咙，大吃特吃好几天！你们会为此付出代价！"

    scene gallery_68
    with dissolve

    translate None chapter_fourteen_0610:
        gr "抱歉老兄，你没机会了。就算能醒来，也不会是这副躯体了。"


    scene gallery_68:
        xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.77
    with hpunch

    translate None chapter_fourteen_0611:
        nox "从我身上滚开！！！"
    translate None chapter_fourteen_0612:
        pr sad "诺克斯，很抱歉我要对你做的事。为了你们俩，我希望我们能帮到你，也希望有天你能获得安宁。"


    scene gallery_68b
    with dissolve

    translate None chapter_fourteen_0613:
        nox "啊啊啊！！！"

    scene gallery_68d
    with dissolve

    translate None chapter_fourteen_0614:
        "他靠近诺克斯的喉咙，张嘴咬进了他的血肉。"
    translate None chapter_fourteen_0615:
        rs wor "他…他在干什么？！"
    translate None chapter_fourteen_0616:
        gr neu "安静点小子。他正是在做你要求的事—救他的命。"
    translate None chapter_fourteen_0617:
        "随着吸食诺克斯的血液，神秘男子颈部的伤口逐渐愈合。"
    translate None chapter_fourteen_0618:
        rs "诺克斯…诺克斯，真的很抱歉…我发誓不管发生什么，我都会…尽全力帮你！"

    scene gallery_68c with dis3
    translate None chapter_fourteen_0619:
        "他的眼眸从漆黑褪回苍白，痛苦地望向我。"

    if achievement.has("soren_free"):
        pass
    else:
        $ renpy.display_notify("【成就解锁：终获自由】")
    python:
        achievement.grant("soren_free")
        achievement.sync()

    $ about_Soren.locked = False
    translate None chapter_fourteen_0620:
        nox "….雷恩…在消失前…请叫我{a=set_entry:enc_people->about_Soren}{color=#DA70D6}索伦{/color}{/a}。"
    translate None chapter_fourteen_0621:
        "….他的真名？在…在这一切变故之前…？"
    translate None chapter_fourteen_0622:
        rs "索伦…我保证…一定会找到解救的办法！"
    translate None chapter_fourteen_0623:
        sor "…谢谢…你…"
    translate None chapter_fourteen_0624:
        sor "找到…卡斯皮安…"

    window hide dissolve

    scene bg nox spooky with dissolve
    window show dissolve

    translate None chapter_fourteen_0625:
        "他阖上双眼，头颅无力地垂向一侧。"
    translate None chapter_fourteen_0626:
        "桃发男子松开他后退几步，脸上沾满诺克斯的…不，是索伦的血。"
    translate None chapter_fourteen_0627:
        pr sad "…结束了。他不会再造成任何伤害。"
    translate None chapter_fourteen_0628:
        rs sad "索伦…对不起…如果我能更强些…"
    translate None chapter_fourteen_0629:
        gr neu "振作点。木已成舟。"
    translate None chapter_fourteen_0630:
        pr "…多一些同理心吧。雷恩，听我说。你已经尽力了。没有你，他早就放弃了。你是真正的朋友。"
    translate None chapter_fourteen_0631:
        pr "别认定自己软弱，因为这根本不是事实。"
    translate None chapter_fourteen_0632:
        rs "可他…可能永远醒不过来了… "
    translate None chapter_fourteen_0633:
        pr "我们只能怀抱希望。你已尽了本分。"
    translate None chapter_fourteen_0634:
        rs "你刚才的举动…究竟是什么…？"
    translate None chapter_fourteen_0635:
        pr neu "现在不是解释的时候。得先收拾残局。详情以后再说。"
    translate None chapter_fourteen_0636:
        gr "该离开了。我们在此逗留太久了。"
    translate None chapter_fourteen_0637:
        "我放开了索伦，他不再与我们对抗。那个绿发男子站起身，将他扛在肩上。"
    translate None chapter_fourteen_0638:
        rs sur "你要带他去哪？"
    translate None chapter_fourteen_0639:
        gr neu "我认识一个可能帮得上忙的人，但他不在奥克斯哈伯。来吧，我们离开这里。"

    window hide dissolve

    scene bg nox house night with dissolve:
        xpos 0.7 ypos 1.29 xanchor 0.5 yanchor 1.0 zoom 1.64
        linear 60.0 xpos 0.18 ypos 1.29 xanchor 0.5 yanchor 1.0 zoom 1.64
    window show dissolve
    translate None chapter_fourteen_0640:
        "我捡起点燃的蜡烛后，跟着另外两人走出房间。就像索伦告诉我的…没必要让房子烧毁。"
    translate None chapter_fourteen_0641:
        "索伦…诺克斯…这不是我想要的一切的结局…"
    translate None chapter_fourteen_0642:
        "桃红色头发的男子走在我身边，注视着前方。当一切平静下来后，我注意到他之前没被发现的一些特征。"
    translate None chapter_fourteen_0643:
        "他的眼睛浑浊不清，几乎像蒙着雾。他一定是盲人，然而…他却能毫无困难地认路。"
    translate None chapter_fourteen_0644:
        "…而且之前他…他是一只鸟，对吧？是我幻想出来的吗？一只鸟…一个男人…一位神明？"
    translate None chapter_fourteen_0645:
        pr sad "雷恩，我知道今天的种种对你来说一定很沉重，而我所说的话也无法减轻这种重担。但请记住…这已经是最好的结果了。这件事不可能有其他结局。"
    translate None chapter_fourteen_0646:
        rs sad "我…我知道，但我还是忍不住觉得本该为他做更多…"
    translate None chapter_fourteen_0647:
        "男子对我温柔地微笑。"
    translate None chapter_fourteen_0648:
        pr smi "你所做的远超你的想象。"
    translate None chapter_fourteen_0649:
        stop music fadeout 3.0
        "当我们走近门口时，我听到慌乱的喊叫声。"
    translate None chapter_fourteen_0650:
        f hur "发生什么事了？！我们为什么在这儿？"
    translate None chapter_fourteen_0651:
        c sad "….我的头好痛。福恩，能亲亲让它好起来吗？"
    translate None chapter_fourteen_0652:
        f hur "现在不是时候！莱奥斯，醒醒！"
    translate None chapter_fourteen_0653:
        l "呃…让我睡觉…"
    translate None chapter_fourteen_0654:
        f hur "醒醒！"
    translate None chapter_fourteen_0655:
        l "走开…老鼠小子…"
    translate None chapter_fourteen_0656:
        f sad "我…我不想这么做的！"

    show bg nox house night with hpunch
    translate None chapter_fourteen_0657:
        "一记耳光的声音在走廊回荡。"
    translate None chapter_fourteen_0658:
        l sur "嗷！搞什么？！你干嘛打我？！"
    translate None chapter_fourteen_0659:
        f hur "你现在能醒了吗？！雷恩不见了！"
    translate None chapter_fourteen_0660:
        l sur "他怎么了？！我们在哪？我们刚才…不是在搜查豪宅吗？"
    translate None chapter_fourteen_0661:
        rs sur "….伙计们？"
    translate None chapter_fourteen_0662:
        "当我们进入门厅时，三双眼睛转过来看向我们。起初他们露出释然的表情。然后他们注意到和我同行的人。"

    jump chapter_fifteen_start
