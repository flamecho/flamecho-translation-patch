label leosroute3:
    scene bg swroom day with eye_open
    window show dissolve
    translate None leos_chapter3_0001:
        "当我睁开眼时，眼前是一团暗红色的头发。莱奥斯安详地睡在我身旁，胸膛平稳地起伏着。"
    translate None leos_chapter3_0002:
        play music "sounds/bgm/night.ogg" fadein 3.0
        "我的嘴角立即浮现出微笑。"
    translate None leos_chapter3_0003:
        "等等，那是什么？"
    translate None leos_chapter3_0004:
        "当我低头看向他的双手时，发现他正紧紧攥着一把匕首，指节都泛白了。"
    translate None leos_chapter3_0005:
        "他拿着这个干嘛？这样睡觉不是很危险吗？"
    translate None leos_chapter3_0006:
        "困惑地叹了口气，我把武器从他手中轻轻抽出来，小心地放在地板上，生怕碰坏什么东西。"
    translate None leos_chapter3_0007:
        "我可不希望赛恩要为此赔偿损失…"
    translate None leos_chapter3_0008:
        "不过原先放匕首的位置看起来空荡荡的。就像缺了什么似的。看起来…很寂寞。"
    translate None leos_chapter3_0009:
        "嗯…如果我…"
    translate None leos_chapter3_0010:
        "战战兢兢地，我颤抖着把手伸向他的。"
    translate None leos_chapter3_0011:
        l wsur "你在干什么？"
    translate None leos_chapter3_0012:
        show bg swroom day with hpunch
        rs wsur "啊！没什么！"
    translate None leos_chapter3_0013:
        l "看起来不像是\"没什么\"。"
    translate None leos_chapter3_0014:
        rs "我真的什么都没做！"
    translate None leos_chapter3_0015:
        l "那你为什么鬼鬼祟祟的？"
    translate None leos_chapter3_0016:
        rs wemb "我只是…想…牵你的手…"
    translate None leos_chapter3_0017:
        l "什么？！"
    translate None leos_chapter3_0018:
        rs "...."
    translate None leos_chapter3_0019:
        l wthi "别…老天，别做这种事…"
    translate None leos_chapter3_0020:
        rs "…为什么不行？"
    translate None leos_chapter3_0021:
        l "不知道，就是…很奇怪。"
    translate None leos_chapter3_0022:
        rs wsad "哦…"
    translate None leos_chapter3_0023:
        l wneu "....."
    translate None leos_chapter3_0024:
        "无声地，一只手出现在我低垂的视线前。"
    translate None leos_chapter3_0025:
        rs wsur "...?"
    translate None leos_chapter3_0026:
        l wemb "你到底牵不牵？"
    translate None leos_chapter3_0027:
        rs "啊…要！"
    translate None leos_chapter3_0028:
        "我轻易地握住了他的手，他修长的手指与我的交缠在一起。"
    translate None leos_chapter3_0029:
        "呃…现在怎么办？"
    translate None leos_chapter3_0030:
        "我们面面相觑，都不知道接下来该做什么。"
    translate None leos_chapter3_0031:
        rs wneu "...."
    translate None leos_chapter3_0032:
        l wneu "....."
    translate None leos_chapter3_0033:
        l wemb "好了，适可而止。"
    translate None leos_chapter3_0034:
        rs wemb "是啊…太奇怪了。"
    translate None leos_chapter3_0035:
        "我们的脸都涨得通红，同时抽回了手。"
    translate None leos_chapter3_0036:
        "太奇怪了…这种感觉太奇怪了，对吧？"
    translate None leos_chapter3_0037:
        "莱奥斯从床上起身，穿好衣服把武器重新绑回腿上。我在床上看了他一会，也跳起来照做，除了没带武器。"
    translate None leos_chapter3_0038:
        "卡斯皮安…"
    translate None leos_chapter3_0039:
        "就是今天，我敢肯定…！"
    translate None leos_chapter3_0040:
        rl "所以—"
    translate None leos_chapter3_0041:
        l wneu "你先说。"
    translate None leos_chapter3_0042:
        rs wsur "哦…我正想说我们该去找赛恩和福恩。最近很少见到他们。"
    translate None leos_chapter3_0043:
        l "我也这么想。"
    translate None leos_chapter3_0044:
        rs "{i}你{/i}会想见赛恩？"
    translate None leos_chapter3_0045:
        l wsur "…也许我改变主意了。"
    translate None leos_chapter3_0046:
        rs wneu "你想说什么来着？"
    translate None leos_chapter3_0047:
        l "呃…"
    translate None leos_chapter3_0048:
        l "就是…谢谢。为了昨晚的事，还有那些。"
    translate None leos_chapter3_0049:
        rs "哦…不，该道谢的是我。"
    translate None leos_chapter3_0050:
        l wthi "不，我…我从来没有机会和任何人谈这件事。能说出来感觉真好。"
    translate None leos_chapter3_0051:
        rs wsur "从来没有？"
    translate None leos_chapter3_0052:
        l wneu "你是第一个。"
    translate None leos_chapter3_0053:
        "我感到心脏在胸膛里猛烈跳动，但我无视了这种奇怪的感觉。"
    translate None leos_chapter3_0054:
        rs wsad "能被你信任让我感到很荣幸…"
    translate None leos_chapter3_0055:
        l wsmu "你应该感到荣幸。现在快点，你太慢了。"
    translate None leos_chapter3_0056:
        rs wsur "什—你刚才还很友好的！"
    translate None leos_chapter3_0057:
        l wneu "我这辈子的温情额度已经用完了。"
    translate None leos_chapter3_0058:
        rs wneu "我喜欢你诚实友善的样子…"
    translate None leos_chapter3_0059:
        l "我不喜欢。快点。"
    translate None leos_chapter3_0060:
        "他没确认我是否跟上就开门离开了，像往常一样让我手忙脚乱地追赶他。"
    translate None leos_chapter3_0061:
        stop music fadeout 2.0
        "这绝对是他的坏习惯之一。"

    window hide dissolve

    scene bg sw day with dissolve
    window show dissolve
    translate None leos_chapter3_0062:
        "福恩和赛恩站在桌边和艾琳说话，当我们走近时转向我们。赛恩的脸上立刻绽放出灿烂的笑容，而福恩则移开了视线。"
    translate None leos_chapter3_0063:
        play music "sounds/bgm/Fooling Around Tiny.ogg" fadein 3.0
        show cyne nw smi at cenright
        show fawn nw sad at farright
        show leos nw neu at farleft
        show raen nw neu at cenleft
        with dissolve
        c "哎呀呀，这对爱侣终于大驾光临了。"
    translate None leos_chapter3_0064:
        show raen nw sur with dis
        rs "什么…？"
    translate None leos_chapter3_0065:
        c "莱奥斯，希望你昨晚没对我们娇嫩的小花太粗暴。"
    translate None leos_chapter3_0066:
        show leos nw sur with dis
        l "啊…？"
    translate None leos_chapter3_0067:
        show cyne nw hap with dis
        c "你把他拖回房间的样子…充满了渴望…"
    translate None leos_chapter3_0068:
        show leos nw emb blush with dis
        l "好了，闭嘴吧。我受够你的声音了。"
    translate None leos_chapter3_0069:
        "莱奥斯抬手捂住赛恩的嘴，差点把他锁喉。"
    translate None leos_chapter3_0070:
        show cyne nw sad with hpunch
        c "唔唔！"
    translate None leos_chapter3_0071:
        show leos nw neu -blush with dis
        l "清静多了。继续，告诉他们你发现了什么。"
    translate None leos_chapter3_0072:
        rs "呃…好的。我们发现卡斯皮安在这附近开了家木工店。我想现在就去找他。"
    translate None leos_chapter3_0073:
        c "唔…唔唔…"
    translate None leos_chapter3_0074:
        f "那我们就跟你一起去。"
    translate None leos_chapter3_0075:
        show cyne nw ang with hpunch
        c "唔唔唔！"
    translate None leos_chapter3_0076:
        show leos nw ann with dis
        l "呕…恶心！你刚舔我手了？！"
    translate None leos_chapter3_0077:
        c "你不放手啊！我也需要呼吸的好吗！"
    translate None leos_chapter3_0078:
        l "如果你不呼吸会安静很多。"
    translate None leos_chapter3_0079:
        c "那谁来烦你呢？"
    translate None leos_chapter3_0080:
        l "最好是没人。"
    translate None leos_chapter3_0081:
        show fawn nw smi with dis
        f "我们该出发去找他的店了。兴奋吗，雷恩？"
    translate None leos_chapter3_0082:
        show raen nw sad with dis
        rs "我想是紧张…所有这些奔波和寻找…只希望他能有答案。"
    translate None leos_chapter3_0083:
        show cyne nw neu with dis
        c "如果他没有呢？"
    translate None leos_chapter3_0084:
        stop music fadeout 4.0
        rs "说实话…我不知道。"
    translate None leos_chapter3_0085:
        "带着这份忧虑，我们很快离开银柳去寻找卡斯皮安的店铺。"

    window hide dissolve

    scene bg sc day with dissolve:
        xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.35
        linear 15.0 xpos 0.5 ypos 1.34 xanchor 0.5 yanchor 1.0 zoom 1.35
    window show dissolve
    translate None leos_chapter3_0086:
        "回忆了霍恩给我的指引后，我带头走在前面。莱奥斯始终站在我身边，一路与我同行。"
    translate None leos_chapter3_0087:
        play music "sounds/bgm/Discovery.ogg" fadein 3.0
        "越往前走，我的脚步就越快。我能听见耳中轰鸣的心跳声，呼吸都卡在喉咙里。"
    translate None leos_chapter3_0088:
        "昨晚与莱奥斯交谈后，我感到几乎…神清气爽。头脑清明，终于准备好去见卡斯皮安了。"
    translate None leos_chapter3_0089:
        "求你了，卡斯皮安…求你一定要在这里。我现在需要你。"
    translate None leos_chapter3_0090:
        c c wsur "对了，稍后还有庆典。要一起去吗？"
    translate None leos_chapter3_0091:
        f c wsmi "我不介意逛逛看。"
    translate None leos_chapter3_0092:
        l c wneu "嗯，随便吧。"
    translate None leos_chapter3_0093:
        c "哇，你的语气可真够冷淡的。就当是约会好了。"
    translate None leos_chapter3_0094:
        l c wsur"和你？免了。"
    translate None leos_chapter3_0095:
        c "不是我说—不对，你这个大笨蛋，我说的是雷恩。懂？"
    translate None leos_chapter3_0096:
        l c wemb "...."
    translate None leos_chapter3_0097:
        rs c wemb "......."
    translate None leos_chapter3_0098:
        c c wsmi "好吧，既然你没兴趣—我有！雷~~~恩，和我约会吧？"
    translate None leos_chapter3_0099:
        rs "呃…那个…"
    translate None leos_chapter3_0100:
        l c wann "他也没兴趣。"
    translate None leos_chapter3_0101:
        "赛恩突然扑过来紧紧抱住我的手臂，却被莱奥斯揪着后领拽开。我抬眼正对上莱奥斯的目光。"
    translate None leos_chapter3_0102:
        rs c wsmi "…或许我们可以大家一起去。"
    translate None leos_chapter3_0103:
        c c wsad "又被拒绝了啊…看来凡事都有第一次…"
    translate None leos_chapter3_0104:
        "街道越来越安静，直到我们来到镇上与众不同的区域。这里更狭小简陋，几乎让我想起家乡。"
    translate None leos_chapter3_0105:
        "我们分头搜索附近的店铺。不对，不是这家…这家也不是。"
    translate None leos_chapter3_0106:
        "一块悬挂的招牌映入眼帘，上面画着日月交叠的图案。"
    translate None leos_chapter3_0107:
        "月蚀\"。"
    translate None leos_chapter3_0108:
        rs c wsur "就是这里…"
    translate None leos_chapter3_0109:
        "当我推开门时，其他人也重新聚集到我身边。"

    window hide dissolve

    jump meetcaspian

label aftercaspianleos:
    scene bg sc night with dissolve
    window show dissolve
    translate None leos_chapter3_0110:
        "当我在身后关上\"月蚀\"的门时，那个期待莱奥斯会等我的渺茫希望彻底破灭了。"
    translate None leos_chapter3_0111:
        "哪儿都看不见他的身影。赛恩和福恩也不见了。"
    translate None leos_chapter3_0112:
        play music "sounds/bgm/sad.ogg" fadein 3.0
        "只剩我孤身一人。"
    translate None leos_chapter3_0113:
        "…一切都是谎言。我竭力坚持的所有，我曾相信的一切…"
    translate None leos_chapter3_0114:
        "难道全都白费了吗？"
    translate None leos_chapter3_0115:
        "思绪飘回福恩。飘回赛恩。飘回莱奥斯…"
    translate None leos_chapter3_0116:
        "不，并非全无意义，但是…现在该怎么办？"
    translate None leos_chapter3_0117:
        "我踢着脚下渐融的积雪，远处庆典的喧闹传来—但不知为何，我提不起参与的兴致。"
    translate None leos_chapter3_0118:
        "一直以来我以为我在对抗命运，证明即使拿着像我这样糟糕的\"审判\"，我也能有所作为。"
    translate None leos_chapter3_0119:
        "……但事实证明，我只是在逃而已。"
    translate None leos_chapter3_0120:
        "靴底碾碎积雪的声响，不断提醒着我为抵达此地付出的一切。那些都不是谎言。我经历的每件事都真实存在。"
    translate None leos_chapter3_0121:
        "我该怎么做？回家？留在这里？"
    translate None leos_chapter3_0122:
        "我得到了答案。我应该高兴，但是…"
    translate None leos_chapter3_0123:
        "为什么好像我达成的一切，一路走来所做的每件事，都毫无意义？"
    translate None leos_chapter3_0124:
        "仿佛我从一开始就没有真正的选择，被某个想象中的天上之人操控着。"
    translate None leos_chapter3_0125:
        "…就像我做的一切都是因为那两个家伙无法和睦相处。"
    translate None leos_chapter3_0126:
        stop music fadeout 3.0
        "……要是莱奥斯在就好了。他知道该怎么做。"


    window hide dissolve

    scene bg sc night with Fade(1.0, 1.0, 1.0):
        xpos 0.17 ypos 1.38 xanchor 0.5 yanchor 1.0 zoom 1.76
    window show dissolve
    translate None leos_chapter3_0127:
        l c whur "操！"
    translate None leos_chapter3_0128:
        play music "sounds/bgm/Scary.ogg" fadein 3.0
        "莱奥斯咬紧牙关，拳头第六还是第七次砸向冰冷的石墙。"
    translate None leos_chapter3_0129:
        lmn "妈的。该死。我究竟在干什么？！"
    translate None leos_chapter3_0130:
        l "这些年来我到底都在忙活些什么……"
    translate None leos_chapter3_0131:
        "他将前额抵在墙上，闭上双眼。"
    translate None leos_chapter3_0132:
        lmn "为什么我要怀抱希望……为什么我要相信自己能改变……"
    translate None leos_chapter3_0133:
        lmn "都是真的。全部都是真的。无论我去往何方，都注定孑然一身。"
    translate None leos_chapter3_0134:
        lmn "为什么不能像雷恩那样是场谎言？为什么我必须承受这种命运？"
    translate None leos_chapter3_0135:
        "然而纷乱思绪充斥脑海—他哪里都不想去。他不想丢下雷恩。感性正与理性激烈冲突—这对他是罕见状况。"
    translate None leos_chapter3_0136:
        lmn "我让他依靠我，却又把他推得更远。我让他相信我，结果尽是遮遮掩掩……他能忍我这么久真是奇迹。"
    translate None leos_chapter3_0137:
        l "我该怎么办……"
    translate None leos_chapter3_0138:
        lmn "如果他出了什么事，我……"
    translate None leos_chapter3_0139:
        lmn "我……我又能怎样？为何如此在意？"
    translate None leos_chapter3_0140:
        lucu smir "哎呀呀，这面墙怎么得罪你啦？"
    translate None leos_chapter3_0141:
        l "啊？"
    translate None leos_chapter3_0142:
        show bg sc night with hpunch
        "莱奥斯还未转头看清神秘声音的主人，肩膀就被狠狠撞了一下。"
    translate None leos_chapter3_0143:
        show luc n dark smir cloak at slightright
        show leos nw dark ann cloak at slightleft
        with dissolve
        "他目光锐利地瞪向那道陌生身影。"
    translate None leos_chapter3_0144:
        "莱奥斯盯着对方，等待永远不会到来的道歉。"
    translate None leos_chapter3_0145:
        l "……滚开。现在没心情。"


    show luc n dark sur with dis
    translate None leos_chapter3_0146:
        lucu "对陌生人该用这种语气吗？"
    translate None leos_chapter3_0147:
        l "我管你是谁。"
    translate None leos_chapter3_0148:
        show luc n dark smir with dis
        "他浓密的黑发在微风中飘荡，脸上绽放着灿烂的笑容。"
    translate None leos_chapter3_0149:
        lucu "在这种地方闲逛—你是雇佣兵吗？"
    translate None leos_chapter3_0150:
        l "....."
    translate None leos_chapter3_0151:
        "他身体突然僵直，手指轻轻摩挲着藏在衣物下的匕首。"
    translate None leos_chapter3_0152:
        lucu "我一直在找你这样的人。事实上，我有个人想要除掉。有兴趣吗？"
    translate None leos_chapter3_0153:
        l "我没兴趣。"
    translate None leos_chapter3_0154:
        lucu "即使这意味着能救雷恩的命？"
    translate None leos_chapter3_0155:
        l "…什么？你是谁？"
    translate None leos_chapter3_0156:
        show luc n dark neu with dis
        lucu "我对你知根知底，莱奥斯。我知道你的过去，现在，将来。我清楚你每一个恐惧。"
    translate None leos_chapter3_0157:
        l "我可不吃威胁这套。"
    translate None leos_chapter3_0158:
        show luc n dark smir with dis
        lucu "幸运的是我并非在威胁你。只是在这艰难时刻伸出援手。"
    translate None leos_chapter3_0159:
        show leos nw dark sur with dis
        "莱奥斯的目光垂向地面，避开这个神秘男子的注视。"
    translate None leos_chapter3_0160:
        l "…无论你做什么都无法改变我。我不能留在他身边。"
    translate None leos_chapter3_0161:
        lucu "如果我告诉你，我有能力改写你的命运呢？"
    translate None leos_chapter3_0162:
        lucu "你只需要杀掉说书人。"
    translate None leos_chapter3_0163:
        l "..."
    translate None leos_chapter3_0164:
        hide luc with dissolve
        show leos at center with move
        "莱奥斯猛地转身看向那人，但方才站立之处已空无一人。"
    translate None leos_chapter3_0165:
        lmn "杀掉…说书人？这样做了…我就能留在他身边？"
    translate None leos_chapter3_0166:
        lmn "…."
    translate None leos_chapter3_0167:
        stop music fadeout 3.0
        lmn "可是为什么…为什么我不想离开他？为什么我就是走不了？！"

    window hide dissolve

    scene bg sc night with Fade(1.0, 1.0, 1.0)
    window show dissolve
    translate None leos_chapter3_0168:
        rs c wsad "哈啊…"
    translate None leos_chapter3_0169:
        play music "sounds/bgm/sad.ogg" fadein 3.0
        "无论我去往何方，都看不见莱奥斯的身影。"
    translate None leos_chapter3_0170:
        "我不明白他为何如此愤怒… "
    translate None leos_chapter3_0171:
        "他又提起了那个审判。他一定希望…像我一样…那是个谎言。"
    translate None leos_chapter3_0172:
        "我想逃避命运毫无意义。我只想证明自己能突破既定的界限，却始终都在别人掌中起舞。"
    translate None leos_chapter3_0173:
        "我注定要成为下一任\"说书人\"。或者说…本该是，如果卡斯—…如果我父亲和\"言者\"没有闹翻的话。"
    translate None leos_chapter3_0174:
        "我甚至无法想象。在城堡里长大？我？"
    translate None leos_chapter3_0175:
        "我根本不想要那样。"
    translate None leos_chapter3_0176:
        "更不用说既…是王位的继承人，又是言者。这简直是闻所未闻。"
    translate None leos_chapter3_0177:
        "…"
    translate None leos_chapter3_0178:
        "一切都感觉遥不可及。"
    translate None leos_chapter3_0179:
        "而现在，我只感到彻骨的孤独。"
    translate None leos_chapter3_0180:
        "这种时候莱奥斯会怎么做？忍气吞声地回家，按别人的期望过活？"
    translate None leos_chapter3_0181:
        "还是说…拒绝？"


    show hone n dark sur at slightleft
    show raen nw dark sur cloak at slightright
    with dissolve
    translate None leos_chapter3_0182:
        h "雷恩？"
    translate None leos_chapter3_0183:
        rs "哦，霍恩…"
    translate None leos_chapter3_0184:
        "恍惚之间，我竟不知不觉又走回了霍恩的面包店。他正站在店门口，怀里抱满纸盒。招牌已经显示打烊。"
    translate None leos_chapter3_0185:
        h "你还好吗？我猜你找到卡斯皮安了？"
    translate None leos_chapter3_0186:
        show raen nw dark sad with dis
        rs "…你早就知道吗？"
    translate None leos_chapter3_0187:
        show hone n dark smi with dis
        "霍恩对我露出温暖的笑容，在怀抱成山的纸盒间，仍奇迹般地腾出手拍了拍我的肩膀。"
    translate None leos_chapter3_0188:
        h "我猜到了。你们长得太像了，而且我过去见过他的表情—那是一个失去一切之人的面容。"
    translate None leos_chapter3_0189:
        h "我很高兴他能找回些许曾经失去的东西。"
    translate None leos_chapter3_0190:
        stop music fadeout 3.0
        rs "…我发现自己像是困在深井里无路可逃。无论转向哪边都无能为力。"
    translate None leos_chapter3_0191:
        h "为何不试试向上攀登呢？"
    translate None leos_chapter3_0192:
        rs "...?"
    translate None leos_chapter3_0193:
        play music "sounds/bgm/night.ogg" fadein 3.0
        h "有时你需要自己开辟道路。不要因为别人说了什么就觉得必须照做。"
    translate None leos_chapter3_0194:
        h "慢慢考虑所有选择，做你内心真正认为正确的事。"
    translate None leos_chapter3_0195:
        "我认为正确的事…"
    translate None leos_chapter3_0196:
        show raen nw dark smi with dis
        rs "…谢谢你，霍恩。这真的帮了大忙。"
    translate None leos_chapter3_0197:
        h "给—拿些点心振作下精神吧。"
    translate None leos_chapter3_0198:
        show raen nw dark sur with dis
        rs "哦，这怎么好意思—"
    translate None leos_chapter3_0199:
        h "务必收下。没人吃就浪费了。"
    translate None leos_chapter3_0200:
        rs "那.."
    translate None leos_chapter3_0201:
        "我低头看向那些棕色小纸盒。里面装满了各式点心，有些我见过，有些甚至从未闻过香味。"
    translate None leos_chapter3_0202:
        rs "….我能拿这些吗？"
    translate None leos_chapter3_0203:
        show hone n dark hap with dis
        h "马卡龙？当然可以！这些都拿去吧。"
    translate None leos_chapter3_0204:
        "他将整盒马卡龙递给我。粉色、白色、棕色，全都看起来美味诱人。"
    translate None leos_chapter3_0205:
        "我要带给莱奥斯…他肯定会喜欢。"
    translate None leos_chapter3_0206:
        show raen nw dark smi with dis
        rs "谢谢你，霍恩。"
    translate None leos_chapter3_0207:
        show hone n dark smi with dis
        h "不客气。快回去吧，天气要变坏了。"
    translate None leos_chapter3_0208:
        "他朝天空扬了扬下巴，远处可见灰暗的乌云正在翻涌而来。"
    translate None leos_chapter3_0209:
        hide hone with dissolve
        show raen at center with move
        "他挥手作别，怀着重新燃起的些许希望，我踏上了返回银柳的路。"
    translate None leos_chapter3_0210:
        "莱奥斯一定正在那里等我。"
    translate None leos_chapter3_0211:
        "街道已笼罩在暮色中，但幸运的是，如今我对归途熟悉得宛如在此生活了一辈子。"
    translate None leos_chapter3_0212:
        "我在想，若当年卡斯皮安带着我逃走，人生会变成什么模样。那一定会截然不同。"
    translate None leos_chapter3_0213:
        "不知道是否—"

    stop music

    #scene gallery_132 with hpunch REMOVE SIDE IMAGES HERE LATER
    scene bg sc night with hpunch
    translate None leos_chapter3_0214:
        "突然，一只手臂从身旁昏暗的巷子里伸出，将我拽了进去。我被垃圾绊倒，恐惧充满心头。"
    translate None leos_chapter3_0215:
        "等等..求你了，别伤害我..！"
    translate None leos_chapter3_0216:
        rs c whur "啊！"
    translate None leos_chapter3_0217:
        "我被推到墙上，但并不重。很轻，仿佛抓我的人不愿让我受伤。"
    translate None leos_chapter3_0218:
        rs "是谁—？！"
    translate None leos_chapter3_0219:
        "所有思绪都消失了，当某人压过来时，我脑中一片空白，他们的嘴唇贴着我的。"
    translate None leos_chapter3_0220:
        "我本能地想推开他，但目光瞥见了什么—长长的红发。他紧闭的双眼，紧锁的眉头，终于慢慢舒展。"
    translate None leos_chapter3_0221:
        play music "sounds/bgm/night.ogg" fadein 3.0
        "我叫莱奥斯。"
    translate None leos_chapter3_0222:
        "他在…他在做什么…？"
    translate None leos_chapter3_0223:
        "沉浸在这种感觉中，被他气息包围着，我闭上眼回吻他。双手缠绕着他，紧贴他的身体以保持站立。"
    translate None leos_chapter3_0224:
        "仅是被他触碰，我就感觉自己要化成一滩水。仿佛这就是我一直等待的，却又始料未及。"
    translate None leos_chapter3_0225:
        "这个吻很柔软，但有些僵硬，好像我们都不清楚自己在做什么。"
    translate None leos_chapter3_0226:
        "当然，事实正是如此。"
    translate None leos_chapter3_0227:
        "当莱奥斯的手指爬上我的肌肤时，一阵颤栗从脊背窜下，他触碰的每一处都像着火般发烫。"
    translate None leos_chapter3_0228:
        "我从紧闭的眼中偷偷看向他，发现他正凝视着我，目光稳定。"
    translate None leos_chapter3_0229:
        scene gallery_131 with dissolve
        rs "这…怎么回事？你突然离开，现在又…"
    translate None leos_chapter3_0230:
        l "妈的，雷恩，我不知道。我他妈根本不知道自己干嘛这样。"
    translate None leos_chapter3_0231:
        rs "你…你…你吻了我…！"
    translate None leos_chapter3_0232:
        l "….抱歉。"
    translate None leos_chapter3_0233:
        rs "你甚至从哪…学的这种…"
    translate None leos_chapter3_0234:
        l "没地方学，我只是…想这么做就做了…"
    translate None leos_chapter3_0235:
        rs "..."
    translate None leos_chapter3_0236:
        "身后传来他的拳头砸在石墙上的声音，他精致的五官明显带着愤怒。"
    translate None leos_chapter3_0237:
        rs "为什么要逃跑？"
    translate None leos_chapter3_0238:
        l "一切都乱套了…我只是又一个自认为足够渴望就能改变的蠢货。"
    translate None leos_chapter3_0239:
        rs "没什么能阻止你改变，但—"
    translate None leos_chapter3_0240:
        l "全都在阻止！整个世界都在和我作对，一直如此。"
    translate None leos_chapter3_0241:
        l "…杀戮是我唯一擅长的事，雷恩。"
    translate None leos_chapter3_0242:
        rs "…我喜欢现在的你。"
    translate None leos_chapter3_0243:
        l "你不该这样。我本会杀了你。"
    translate None leos_chapter3_0244:
        rs "…我不介意。"
    translate None leos_chapter3_0245:
        l "你真是个白痴。"
    translate None leos_chapter3_0246:
        rs "我们可以一起犯傻，如果你想的话。"
    translate None leos_chapter3_0247:
        l "哈啊…果然是你会说的话。"
    translate None leos_chapter3_0248:
        "他大声叹气，目光先落在地上，然后又与我的视线相遇。"
    translate None leos_chapter3_0249:
        l "我害怕自己保护不了你。更让我困惑的是，我竟然会产生想要保护你的念头。"
    translate None leos_chapter3_0250:
        rs "你不需要保护我。"
    translate None leos_chapter3_0251:
        l "我可以保护你不受他人伤害。无论是恶魔还是盗贼，只要你需要我都能保护…但我恐怕…保护不了你不受我的伤害。"
    translate None leos_chapter3_0252:
        rs "这是…关于你的\"审判\"吗？"
    translate None leos_chapter3_0253:
        "他眼皮跳了跳，冲我点头。"
    translate None leos_chapter3_0254:
        l "我觉得我一定是病了。可能要死了。"
    translate None leos_chapter3_0255:
        rs "....?"
    translate None leos_chapter3_0256:
        l "这是我唯一能想到的、可以解释这种感受的理由。"
    translate None leos_chapter3_0257:
        l "言者组织，卡斯皮安，我的审判…我想逃离这一切。虽然说出来让我痛苦，但你…"
    translate None leos_chapter3_0258:
        rs "我要…"
    translate None leos_chapter3_0259:
        l "你是我唯一的慰藉。"
    translate None leos_chapter3_0260:
        rs "...!"
    translate None leos_chapter3_0261:
        l "我又在说蠢话了。就当什么都没发生过吧。我们回去—"
    translate None leos_chapter3_0262:
        rs "不要！"
    translate None leos_chapter3_0263:
        scene gallery_132 with dissolve
        "以我都不自知的力量，我把他的脸重新拉向自己，更加疯狂地吻了上去。"
    translate None leos_chapter3_0264:
        "我知道自己在做什么吗？不知道，但这阻止不了我。"
    translate None leos_chapter3_0265:
        "他…他一定和我的感受相同。那些悸动，靠近他时加速的心跳。"
    translate None leos_chapter3_0266:
        "这种只想和他在一起的感觉…"
    translate None leos_chapter3_0267:
        "他也…有同样的感受？"
    translate None leos_chapter3_0268:
        scene gallery_131 with dissolve
        l "我害怕会失去你。"
    translate None leos_chapter3_0269:
        "这句从未想过会从他口中说出的话让我艰难地咽了下口水。他的目光无比认真，不见往日那种玩世不恭的讥笑。"
    translate None leos_chapter3_0270:
        "此刻的莱奥斯如此真实，毫无掩饰地向我展露他真实的情感。"
    translate None leos_chapter3_0271:
        rs "我不会离开的。"
    translate None leos_chapter3_0272:
        l "我确实觉得自己病了。"
    translate None leos_chapter3_0273:
        rs "我也是。"
    translate None leos_chapter3_0274:
        l "而且我不配得到你的信任。无论怎么看，我都是个糟糕的人。"
    translate None leos_chapter3_0275:
        rs "你早就拥有我的信任了。这点永远不会改变。"
    translate None leos_chapter3_0276:
        "那一刻仿佛会永恒持续。雪花开始飘落，覆盖在我俩周围，莱奥斯俯视着我的脸，指尖轻抚着我的后颈。"
    translate None leos_chapter3_0277:
        "但终究还是结束了。他迅速抓住我的手，拽着我离开小巷，回到昏暗的街道上。"

    window hide dissolve

    scene bg sc night with Fade(1.0, 1.0, 1.0)
    window show dissolve
    translate None leos_chapter3_0278:
        rs c wsur "我们要去哪？"
    translate None leos_chapter3_0279:
        l c wneu"回去。"
    translate None leos_chapter3_0280:
        rs "我刚跟你说过—"
    translate None leos_chapter3_0281:
        l c wthi "这样还不够。我还有件事想做。"
    translate None leos_chapter3_0282:
        rs c wneu "....."
    translate None leos_chapter3_0283:
        "还有…什么事？"
    translate None leos_chapter3_0284:
        "我的思绪飘回了与赛恩的那堂课，突然间感到脸颊发烫。"
    translate None leos_chapter3_0285:
        "别的什么？！和我，还有…他？"
    translate None leos_chapter3_0286:
        rs c wemb "什么…什么样的\"别的\"？"
    translate None leos_chapter3_0287:
        l "我不知道。我只知道我想要。"
    translate None leos_chapter3_0288:
        "我立即深吸一口气，任由他引领着，同时我的心在胸腔里砰砰直跳，响彻全身。"

    window hide dissolve

    scene bg swroom night with dissolve
    window show dissolve
    translate None leos_chapter3_0289:
        "不记得何时回到了房间。脑中一片混乱，一切都模糊不清。最终将我拉回现实的，是莱奥斯再次将我拉近亲吻时，喉间发出的温柔轻哼。"
    translate None leos_chapter3_0290:
        "起初这意外令人窒息，但很快我就控制不住嘴角上扬。他的唇如此柔软温和，与平日判若两人。"
    translate None leos_chapter3_0291:
        "窗外的夜色很美—雪花掠过玻璃，轻轻飘落地面。而房间里却变得炽热难耐，呼吸突然困难起来。"
    translate None leos_chapter3_0292:
        "是暖气太足，还是我…？"
    translate None leos_chapter3_0293:
        "莱奥斯的手指穿过我的发丝，我的手指也插入他的头发。掌心中那触感柔顺丝滑。"
    translate None leos_chapter3_0294:
        "他用力压向我时，我突然确信升温的是我们而非房间。喉间溢出一声陌生的喘息—饱含情欲、渴望，以及前所未有的感受。"
    translate None leos_chapter3_0295:
        "我轻轻揪住他的头发，终于得以喘息。"
    translate None leos_chapter3_0296:
        rs wemb "说真的，你这套跟谁学的？！"
    translate None leos_chapter3_0297:
        l wemb "我…"
    translate None leos_chapter3_0298:
        "他的目光在房间乱飘，寻找能不注视我的焦点。最终放弃时，脸颊已红透。"
    translate None leos_chapter3_0299:
        l "..赛恩告诉我的…"
    translate None leos_chapter3_0300:
        rs wsur "....."
    translate None leos_chapter3_0301:
        rs whap "哈哈哈！天啊太滑稽了…！"
    translate None leos_chapter3_0302:
        l "闭嘴！"
    translate None leos_chapter3_0303:
        rs "想不到你居然会听进他的话！"
    translate None leos_chapter3_0304:
        l "再笑就让你付出代价。"
    translate None leos_chapter3_0305:
        rs "你能怎样？"
    translate None leos_chapter3_0306:
        l "...."
    translate None leos_chapter3_0307:
        "他把我压回门上，低头又偷走一个吻。这个吻夺走呼吸，逐渐加深。"
    translate None leos_chapter3_0308:
        "紧贴的身体令人欣喜却难以招架。我的手攀上他的胸膛，环住脖颈，像怕跌倒般紧抓不放。"
    translate None leos_chapter3_0309:
        "确实如此。他的每个举动都让人战栗，我的双腿随时都会发软。"
    translate None leos_chapter3_0310:
        "我又一次挣脱开，重重喘息着。"
    translate None leos_chapter3_0311:
        rs wemb "你这是作弊！"
    translate None leos_chapter3_0312:
        l "怎么就作弊了？"
    translate None leos_chapter3_0313:
        rs "…就…就是作弊…"
    translate None leos_chapter3_0314:
        l wsmu "至少堵住了你的嘴。"
    translate None leos_chapter3_0315:
        rs "说得好像你很嫌弃似的，我打赌你可爱听我唠叨了。"
    translate None leos_chapter3_0316:
        l "开什么玩笑？你这家伙除了叭叭叭还会干什么？"
    translate None leos_chapter3_0317:
        rs wsmi "哦？那你干嘛要亲我？"
    translate None leos_chapter3_0318:
        l wemb "我…亲不亲都无所谓。你要是不乐意就直说。"
    translate None leos_chapter3_0319:
        "作为回应，我踮起脚尖在他唇上落下轻轻一吻，随即后退半步仰头冲他微笑。"
    translate None leos_chapter3_0320:
        rs wneublu "我就是想和你这样。"
    translate None leos_chapter3_0321:
        l wneublu "哪怕会改变我们的关系？"
    translate None leos_chapter3_0322:
        rs "正因会改变关系才更要这么做。"
    translate None leos_chapter3_0323:
        l "就算可能因我受伤？"
    translate None leos_chapter3_0324:
        rs "...."
    translate None leos_chapter3_0325:
        rs "对。"
    translate None leos_chapter3_0326:
        "就这样我被他打横抱起，向后倾倒陷进蓬松柔软的床铺。他悬在上方，红发如瀑散落。"

    stop music fadeout 3.0
    window hide dissolve

    scene gallery_135 with dissolve
    window show dissolve
    play music "sounds/bgm/sex.ogg" fadein 2.0
    translate None leos_chapter3_0327:
        "他手指灵巧地解着我上衣纽扣，掌心抚上新露的肌肤。双唇再度交缠时，他的舌顶开我的齿关。"
    translate None leos_chapter3_0328:
        "我轻轻拽他头发，莱奥斯喉间溢出低沉呻吟，作为回应他手指掐住我的腰窝。"
    translate None leos_chapter3_0329:
        rs "哈啊…"
    translate None leos_chapter3_0330:
        scene gallery_134 with dissolve
        l "你能不能别…别这么…诱人？"
    translate None leos_chapter3_0331:
        rs "诱人？我？没记错的话你以前都说我是土豆。"
    translate None leos_chapter3_0332:
        l "是蠢得要命的性感土豆。"
    translate None leos_chapter3_0333:
        rs "….哈哈哈！老说我傻，你才是真傻的那个。"
    translate None leos_chapter3_0334:
        "像是回应我的调侃，有个硬物抵住了大腿。我低头看去，又震惊地抬眼望他。"
    translate None leos_chapter3_0335:
        rs "你…你…"
    translate None leos_chapter3_0336:
        l "...."
    translate None leos_chapter3_0337:
        l "这是正常生理反应行不行？！"
    translate None leos_chapter3_0338:
        rs "...."
    translate None leos_chapter3_0339:
        rs "看来你真的很吃我这套嘛。"
    translate None leos_chapter3_0340:
        l "闭嘴。"
    translate None leos_chapter3_0341:
        scene gallery_135 with dissolve
        "他再度俯身用吻封住我的抗议，而我甘之如饴。流连在腰际的手指开始轻轻揉捏。"
    translate None leos_chapter3_0342:
        "平日这种触碰该令人放松，此刻…却只觉体内窜起燥热，他每处抚触都激起肌肤战栗。"
    translate None leos_chapter3_0343:
        "他胯部压下来摩擦时的触感几乎令人窒息。"
    translate None leos_chapter3_0344:
        rs "你…这是在…做什么…？"
    translate None leos_chapter3_0345:
        "发出的声音陌生得不像是自己的。"
    translate None leos_chapter3_0346:
        scene gallery_134 with dissolve
        l "我要说多少遍你才明白我完全不知情。"
    translate None leos_chapter3_0347:
        rs "赛恩…难道赛恩没教过你…？"
    translate None leos_chapter3_0348:
        l "或许我听过他没完没了地讲接吻的事…但我划清了界限。"
    translate None leos_chapter3_0349:
        rs "那…你想怎么做？"
    translate None leos_chapter3_0350:
        l "我们会搞清楚的。"
    translate None leos_chapter3_0351:
        l "我们向来如此 你和我 主要是我"
    translate None leos_chapter3_0352:
        "微凉的空气拂过我新裸露的肌肤，我却无暇顾及—全部注意力都集中在胯部，那里衣料正变得越来越紧勒难受。"
    translate None leos_chapter3_0353:
        "他真的…在顶着我…"
    translate None leos_chapter3_0354:
        "我艰难地吞咽着，专注感受他那处硬挺抵着我的触感。这远超我任何幻想，但… "
    translate None leos_chapter3_0355:
        "但是…"
    translate None leos_chapter3_0356:
        "我想要更多。这远远不够。还差得远。"
    translate None leos_chapter3_0357:
        rs "求…求你 莱奥斯…我要你…"
    translate None leos_chapter3_0358:
        l "想让我…？"
    translate None leos_chapter3_0359:
        "他垂眼看向我的裤腰，手指游走着勾住松紧带。"
    translate None leos_chapter3_0360:
        l "对…对 当然…"
    translate None leos_chapter3_0361:
        "他眉心紧蹙陷入沉思，神情专注至极。"
    translate None leos_chapter3_0362:
        "或许我懂得不多，但…我知道想被他触碰。"
    translate None leos_chapter3_0363:
        "突然他动作停滞，仿佛彻底失去了把握。"
    translate None leos_chapter3_0364:
        rs "....?"
    translate None leos_chapter3_0365:
        "我回想起赛恩的\"指导\"。或许我该…"
    translate None leos_chapter3_0366:
        scene gallery_134 with dissolve:
            xpos 0.37 ypos 1.2 xanchor 0.5 yanchor 1.0 zoom 1.31
        "我伸手抚过他胸膛，掌心覆上他胯间，几乎是震惊地缩回了手。"
    translate None leos_chapter3_0367:
        "他…他居然因我变成这样？!"
    translate None leos_chapter3_0368:
        "喉头发紧间，我隔衣料感受着他，手掌描摹那处的轮廓。"
    translate None leos_chapter3_0369:
        "我与莱奥斯目光相接。他面染绯红，紧抿的唇间已泄出喘息。"
    translate None leos_chapter3_0370:
        "我们都渴求着这个。"
    translate None leos_chapter3_0371:
        "不，是我们都想要更多。"
    translate None leos_chapter3_0372:
        l "….啊，去他的。"
    translate None leos_chapter3_0373:
        "他模仿我的动作，指尖的触碰让我疯狂。我含泪仰视他，终于他的手探入裤腰。"
    translate None leos_chapter3_0374:
        "我浑身一颤，他掌心凉意触及肌肤的瞬间—虽非意外，却远超想象。"
    translate None leos_chapter3_0375:
        "他另一只手仍扣着我腰侧，指尖陷入皮肉—却不疼痛。正相反。"
    translate None leos_chapter3_0376:
        "他的手向下探入底裤，修长手指圈住我已硬挺的阴茎。"
    translate None leos_chapter3_0377:
        "我倒吸一口凉气，猛地抬眼与他目光相接。本以为他会露出讥笑，或是说出什么俏皮话，然而他却沉默不语。"
    translate None leos_chapter3_0378:
        rs "莱…莱奥斯…？"
    translate None leos_chapter3_0379:
        l "该死…我不知道还能不能控制住自己…"
    translate None leos_chapter3_0380:
        "他的手掌轻易环握住我的阴茎，缓缓向上撸动了一次。"
    translate None leos_chapter3_0381:
        rs "嗯嗯…！"
    translate None leos_chapter3_0382:
        l "感觉…感觉舒服吗？"
    translate None leos_chapter3_0383:
        rs "舒…舒服…"
    translate None leos_chapter3_0384:
        "我发誓看到他咬着嘴唇，手掌开始上下套弄。起初缓慢而谨慎，在看到我的反应后逐渐变得热情起来。"
    translate None leos_chapter3_0385:
        "我也…我也该…"
    translate None leos_chapter3_0386:
        "就在我即将探入他裤裆时，他阻止了我。"
    translate None leos_chapter3_0387:
        rs "...?"
    translate None leos_chapter3_0388:
        l "不用勉强自己。"
    translate None leos_chapter3_0389:
        rs "...."
    translate None leos_chapter3_0390:
        rs "不是…啊…不是勉强。我想这么做。"
    translate None leos_chapter3_0391:
        l "...."
    translate None leos_chapter3_0392:
        "他松开我的手腕，我迅速俯身抓住他的阴茎。掌心里那根东西又长又硬。"
    translate None leos_chapter3_0393:
        "我模仿着他的动作，也用手圈住了他的阳具。"
    translate None leos_chapter3_0394:
        l "嗯…"
    translate None leos_chapter3_0395:
        "莱奥斯眉头紧蹙地悬在我上方，呼吸变得粗重。"
    translate None leos_chapter3_0396:
        l "操…这还不够。"
    translate None leos_chapter3_0397:
        rs "什么…什么意思…？"


    scene gallery_135b:
        subpixel True xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.53 rotate None
        parallel:
            xpos 0.75
            easein 10.0 xpos 0.26
    if persistent.streamer_mode == True:
        show leos_first_sex_censor:
            subpixel True xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.53 rotate None
            parallel:
                xpos 0.75
                easein 10.0 xpos 0.26

    with dissolve
    translate None leos_chapter3_0398:
        "没等我追问，他已褪下我的裤子，让肌肤暴露在微凉的空气中。"
    translate None leos_chapter3_0399:
        "我感到自己羞红了脸，他却只是着迷地凝视着。"
    translate None leos_chapter3_0400:
        l "….真性感。"
    translate None leos_chapter3_0401:
        rs "才没…"
    translate None leos_chapter3_0402:
        rs "啊！"
    translate None leos_chapter3_0403:
        "当他的手再次包裹住我时，我几乎要融化在他怀里。他的目光紧锁着我，像是要捕捉我的每个反应。"
    translate None leos_chapter3_0404:
        "仿佛无法克制般，他不时俯身在我脸上和脖颈留下串串吻痕，快感随之愈发强烈。"
    translate None leos_chapter3_0405:
        "不过，这游戏可以双人玩。"

    scene gallery_135b
    if persistent.streamer_mode == True:
        show leos_first_sex_censor
    with dissolve
    translate None leos_chapter3_0406:
        rs "啊，莱奥斯…"
    translate None leos_chapter3_0407:
        "我轻轻捏住他阴茎根部，逼出他一声压抑的呻吟，在空荡的房间里久久回荡。"
    translate None leos_chapter3_0408:
        "体内涌动的压力已在寻求释放，但我希望此刻永无止境。"
    translate None leos_chapter3_0409:
        "此刻，只有我与莱奥斯。唯有我们二人。"
    translate None leos_chapter3_0410:
        "没有言者与王子，恶魔与神明—只有我们，进行这场我从未察觉竟如此渴望的缠绵。"
    translate None leos_chapter3_0411:
        "我深吸一口气平复紧张情绪，将莱奥斯肿胀的阳具从他绷紧的裤子里解放出来。我发誓他几乎要发出解脱般的呻吟。"
    translate None leos_chapter3_0412:
        "还没等我反应过来，他已经同时握住我们俩的性器开始激烈套弄。"
    translate None leos_chapter3_0413:
        "他硬挺灼热的阴茎贴着我的，这一刻我终于真切意识到我们正在做什么。"
    translate None leos_chapter3_0414:
        l "呃…"

    scene gallery_135c
    if persistent.streamer_mode == True:
        show leos_first_sex_censor
    with dissolve
    translate None leos_chapter3_0415:
        "他的手掌在我们勃起的柱身上滑动，时而停顿下来挤压顶端。"
    translate None leos_chapter3_0416:
        "他的声音早已乱成一团，浸透着情欲的醉意。此刻他终于卸下所有防备，抛却一切顾虑。"
    translate None leos_chapter3_0417:
        "我腾出手捧住他的脸颊，嘴角不自觉扬起笑容，却被他夹杂着低哑脏话的亲吻再次堵住。"
    translate None leos_chapter3_0418:
        "当他的拇指碾过我早已湿漉漉的龟头时，我差点漏出破碎的喘息。"
    translate None leos_chapter3_0419:
        "他的指节骤然收紧，我们交缠的动作瞬间变得更加凌乱。"
    translate None leos_chapter3_0420:
        "我无意识地挺腰磨蹭他的性器，渴求更多触碰。察觉到这点后，他开始模仿我的动作与我交媾。"
    translate None leos_chapter3_0421:
        "莱奥斯半阖眼帘凝视着我，那种前所未见的表情—突然让我感觉自己被渴望，被需要…性感至极。"

    scene gallery_135b
    if persistent.streamer_mode == True:
        show leos_first_sex_censor
    with dissolve
    translate None leos_chapter3_0422:
        l "我感觉快要…"
    translate None leos_chapter3_0423:
        rs "我也…呃啊…快要去了…"
    translate None leos_chapter3_0424:
        "我死命咬住嘴唇几乎要见血，在高潮边缘苦苦挣扎。"

    scene gallery_135d
    if persistent.streamer_mode == True:
        show leos_first_sex_censor
    with hpunch
    translate None leos_chapter3_0425:
        "当莱奥斯将我操射在我们胸膛上时，我终于释放。他又抽插几下后也射了出来，闷哼着将额头抵在我肩头。"
    translate None leos_chapter3_0426:
        rs "哈啊…"
    translate None leos_chapter3_0427:
        l "Ah… ha…."

    window hide dissolve

    scene bg swroom night with dissolve
    window show dissolve
    translate None leos_chapter3_0428:
        "他脱力瘫倒在我身上，我张开双臂拥住他。"
    translate None leos_chapter3_0429:
        rs wneublu "哈啊…谁能想到…莱奥斯你变得这么乖顺…"
    translate None leos_chapter3_0430:
        stop music fadeout 3.0
        l wemb "闭嘴。"
    translate None leos_chapter3_0431:
        rs "我从没想过会见到你这样。"
    translate None leos_chapter3_0432:
        l "是啊…我自己也没想到…"
    translate None leos_chapter3_0433:
        play music "sounds/bgm/night.ogg" fadein 3.0
        rs "……谢谢你信任我。"
    translate None leos_chapter3_0434:
        l wneublu "...."
    translate None leos_chapter3_0435:
        l "我们该清理一下。"
    translate None leos_chapter3_0436:
        "他突然抽离的体重让我感到莫名空虚与寒冷，我立刻就想叫他回来—但已经晚了，他起身开始清理我们制造的狼藉。"
    translate None leos_chapter3_0437:
        "我也跟着收拾，用布巾擦拭胸膛上的\"罪证\"。低头看见自己身体时仍忍不住脸红。"
    translate None leos_chapter3_0438:
        "我们真的做了。莱奥斯…他真的那样抚摸过我…"
    translate None leos_chapter3_0439:
        "这很尴尬…真的很尴尬，可是…"
    translate None leos_chapter3_0440:
        "但如果他还想再来一次…我也不介意…"
    translate None leos_chapter3_0441:
        rs "我也想再来一次。"
    translate None leos_chapter3_0442:
        l wemb "你说什么？！现在就要？！"
    translate None leos_chapter3_0443:
        rs wemb "什—不，不是现在！改…改天…"
    translate None leos_chapter3_0444:
        l "哦…"
    translate None leos_chapter3_0445:
        "他挠着后脑勺，红晕迅速爬满脸颊。"
    translate None leos_chapter3_0446:
        l "好…好啊，没问题…"
    translate None leos_chapter3_0447:
        rs wsur "真的？你是认真的？"
    translate None leos_chapter3_0448:
        l "我不是答应了吗？赶紧上床。"
    translate None leos_chapter3_0449:
        rs wsad "…但我不想让你走。"
    translate None leos_chapter3_0450:
        l wneublu "今晚我哪儿都不去。"
    translate None leos_chapter3_0451:
        "他的话令我动作加快，迅速脱衣陷入柔软温暖的床铺。我看着他如法炮制，目光流连他的身形，直到他滑入我身旁。"
    translate None leos_chapter3_0452:
        "我们之间隔着段距离，不知为何我始终不敢跨越。即使已亲密如斯。"
    translate None leos_chapter3_0453:
        "但这担忧纯属多余，因为他立即握住我的手轻捏，随后开口。"
    translate None leos_chapter3_0454:
        l wneu "我的「审判」昭示我会害死所有亲近之人。"
    translate None leos_chapter3_0455:
        rs wsur "什么？！"
    translate None leos_chapter3_0456:
        l "完美的刺客对吧？与世隔绝的那种。"
    translate None leos_chapter3_0457:
        rs "这怎么可能…怎么可能是真的…"
    translate None leos_chapter3_0458:
        l wthi "我…从来不愿相信。直到…直到我朋友失踪。这就是证明—我唯一亲近的人，就这样死了。"
    translate None leos_chapter3_0459:
        l "…我一直躲避所有人，雷恩。我不习惯…这样。对你，对福恩，还有…赛恩也是。所以当初让你留我在森林等死。"
    translate None leos_chapter3_0460:
        rs wsad "..."
    translate None leos_chapter3_0461:
        l wsur "我生来就该孤独死去。只是时间问题罢了—"
    translate None leos_chapter3_0462:
        rs "我不在乎。即便…即便我真的遭遇不测，认识你也值了。"
    translate None leos_chapter3_0463:
        l "....."
    translate None leos_chapter3_0464:
        l "你不知道自己在说什么。"
    translate None leos_chapter3_0465:
        rs wneu "那我们就战胜命运。"
    translate None leos_chapter3_0466:
        l "你这招向来管用吗？"
    translate None leos_chapter3_0467:
        rs "...."
    translate None leos_chapter3_0468:
        l "我傻到以为那可能全是谎言。当我们见到说书人，他说你的「审判」是谎言时，我很激动。"
    translate None leos_chapter3_0469:
        l "激动于我的「审判」或许也是谎言。"
    translate None leos_chapter3_0470:
        l wneu "但并不是。"
    translate None leos_chapter3_0471:
        rs wsad "你值得我冒险。"
    translate None leos_chapter3_0472:
        l "多谢，可我宁愿不用余生都背负害死你的愧疚。"
    translate None leos_chapter3_0473:
        rs wneu "那你就得保护好我。你擅长这个。"
    translate None leos_chapter3_0474:
        l wsur "诸神啊，你可真是个聒噪的小鬼。满口陈词滥调和希望。等你变成我这样又老又愤世嫉俗的男人就知道了。"
    translate None leos_chapter3_0475:
        rs "冷静点，你也没比我大多少。"
    translate None leos_chapter3_0476:
        l "足够老到被你的朝气蓬勃弄得疲惫不堪。"
    translate None leos_chapter3_0477:
        rs wsad "…他说我将来会是个废物。一个无家可归的卑微小偷。没人要，没用的东西。在孤儿院长大时，我就觉得被抛弃是理所当然的。"
    translate None leos_chapter3_0478:
        rs "谁会想要那样的儿子？"
    translate None leos_chapter3_0479:
        l "靠，真刻薄。就算要撒谎，他好歹也该说点好听的。"
    translate None leos_chapter3_0480:
        rs "我认命自己这辈子一事无成，但从一开始我就想证明我可以成为…更有价值的人。"
    translate None leos_chapter3_0481:
        l wneu "呵，看看你。你已经足够优秀了。"
    translate None leos_chapter3_0482:
        rs "哈…我试图反抗的命运本身就是个谎言。我始终在逃避现实。"
    translate None leos_chapter3_0483:
        l wsmu "你对自己太苛刻了。再说了，没用？我倒能想到你一两个妙处。"
    translate None leos_chapter3_0484:
        "他冲我坏笑，我立刻明白他在暗示什么。"
    translate None leos_chapter3_0485:
        rs wemb "喂！"
    translate None leos_chapter3_0486:
        l "开玩笑的。不过说真的，你成长了许多知道吗？你不再是奥雷利亚卡维拉那个被我戏弄的臭小鬼了。"
    translate None leos_chapter3_0487:
        "奥雷利亚卡维拉…家乡…"
    translate None leos_chapter3_0488:
        rs wneu "莱奥斯…我要回奥雷利亚卡维拉纠正错误。"
    translate None leos_chapter3_0489:
        l wneu "既然你已决定。"
    translate None leos_chapter3_0490:
        rs wsur "…？那你呢？"
    translate None leos_chapter3_0491:
        "坏笑化作苦涩的微笑，他轻轻摇头。"
    translate None leos_chapter3_0492:
        l "我不会回去了。那里已没有值得我回去的东西。"
    translate None leos_chapter3_0493:
        rs wsad "...."
    translate None leos_chapter3_0494:
        "我的心仿佛沉到胃里，我眨掉眼角泛起的泪花。"
    translate None leos_chapter3_0495:
        rs "…哦…"
    translate None leos_chapter3_0496:
        l wsur "别误会—我不是要改变你的主意。你经过深思熟虑得出这个对你最好的决定。"
    translate None leos_chapter3_0497:
        l "这才是最重要的。"
    translate None leos_chapter3_0498:
        rs "…别逞强了。要是再也见不到我，你会想死我的。"
    translate None leos_chapter3_0499:
        rs wneublu "我会回来找你。"
    translate None leos_chapter3_0500:
        l wneublu "....."
    translate None leos_chapter3_0501:
        rs "所以等着我。"
    translate None leos_chapter3_0502:
        l wsmu "….哈哈哈…你小子还真是个活宝。走着瞧吧。"
    translate None leos_chapter3_0503:
        l "说不定我早对你腻味另结新欢了。"
    translate None leos_chapter3_0504:
        rs wemb "喂！"
    translate None leos_chapter3_0505:
        l wsmu "睡一会儿吧。明天对你来说会是个重要的日子。"
    translate None leos_chapter3_0506:
        "他翻身离开我，松开了我的手。我想一把抓回来，却又不敢。于是我也转身侧卧，直直盯着墙壁。"
    translate None leos_chapter3_0507:
        "过了一阵子，黑暗中传来轻轻的说话声。"
    translate None leos_chapter3_0508:
        l wneu "….关于你母亲的事…"
    translate None leos_chapter3_0509:
        rs wsur "嗯？"
    translate None leos_chapter3_0510:
        l "….算了。呃..我们改天再谈她吧。"
    translate None leos_chapter3_0511:
        rs "...?"
    translate None leos_chapter3_0512:
        "虽然很想追问，但我的眼皮已然沉重，又沉入了另一场至寂之梦。"

    stop music fadeout 2.0
    window hide dissolve

    scene black with eye_shut
    pause 2.0

    if caspianaemylromance >= 1:
        $ ca_scene_one = True
        jump caspianaemylscene1
    else:
        jump morwenscene1


label leosroute3cont:

    scene bg swroom night with Fade(1.0, 1.0, 1.0)
    window show dissolve
    translate None leos_chapter3_0513:
        l wneu "...."
    translate None leos_chapter3_0514:
        "莱奥斯从床上坐起，凝望着黑暗。"
    translate None leos_chapter3_0515:
        play music "sounds/bgm/creepy.ogg" fadein 3.0
        "房间并不太冷，床铺也很舒适。他只是睡不着。"
    translate None leos_chapter3_0516:
        "太多思绪在他脑中盘旋，他开始怀疑发生的一切是否都是幻觉。"
    translate None leos_chapter3_0517:
        "他望向身旁熟睡的男孩，随即确定不，这一切都是真实的。"
    translate None leos_chapter3_0518:
        "他歪着嘴笑了笑，伸手拨开雷恩额前的碎发。"
    translate None leos_chapter3_0519:
        lmn "真是个傻里傻气的小鬼。"
    translate None leos_chapter3_0520:
        lmn "但是..这个傻气的小鬼头，我居然莫名很喜欢。"
    translate None leos_chapter3_0521:
        lmn "…"
    translate None leos_chapter3_0522:
        lmn "可是…这样真的可以吗？"
    translate None leos_chapter3_0523:
        "先前的记忆突然涌入脑海，他浑身僵直。巷子里那个怪异的男人…"
    translate None leos_chapter3_0524:
        lmn "他真的能改写我的命运？让我们长相厮守？"
    translate None leos_chapter3_0525:
        "他试图不去想。明知不可能，像是个陷阱，却仍被那人的话语吸引。"
    translate None leos_chapter3_0526:
        "他清楚地知道，要是雷恩想跟巷子里那个可疑分子走，他定会嘲笑他。"
    translate None leos_chapter3_0527:
        "但现在，自己却在犯同样的错。"
    translate None leos_chapter3_0528:
        "他轻手轻脚地溜下床穿好衣服。踏着寂静的步伐溜出房间，步入寒冷的夜。"

    window hide dissolve

    scene bg sc night with dissolve:
        xpos 0.67 ypos 1.06 xanchor 0.5 yanchor 1.0 zoom 1.37
        linear 23.0 xpos 0.32 ypos 1.06 xanchor 0.5 yanchor 1.0 zoom 1.37
    window show dissolve
    translate None leos_chapter3_0529:
        "街道已积起薄雪，寒风如刀割着莱奥斯的面庞。但他依然迎着凛冬前行。"
    translate None leos_chapter3_0530:
        "起初只想理清思绪。权衡选择。决定最佳对策。他珍视这独处时刻，可暂时抛却感情理性思考。"
    translate None leos_chapter3_0531:
        "但这次却格外困难。他不断想起被独自留在床上的男孩。"
    translate None leos_chapter3_0532:
        lmn "现在消失是最好的选择。他要到明天早上才会发现我离开，到那时就永远找不到我了。"
    translate None leos_chapter3_0533:
        "他抬头望去，突然意识到自己不知不觉走到了哪里。"
    translate None leos_chapter3_0534:
        "蚀。"
    translate None leos_chapter3_0535:
        "他手指搭在门框上，透过窗户窥视。里面一片漆黑。"
    translate None leos_chapter3_0536:
        "很难判断是否有人在场。"
    translate None leos_chapter3_0537:
        "藏在衣服下的手玩弄着暗藏的匕首柄。"

    window hide

    menu:
        "敲门":
            $ leos_goodend += 1
            window show dissolve
            jump leosknock

        "闯进去":
            $ leos_badend += 1
            jump leosbarge



label leosknock:
    translate None leos_chapter3_0538:
        lmn "…还是敲门吧，看看有没有人。如果没人应答，我就回去。"
    translate None leos_chapter3_0539:
        lmn "这样就不必由我做决定了。"
    play sound "sounds/sfx/knock.ogg"
    translate None leos_chapter3_0540:
        "他轻轻叩门，回声在屋内荡漾。"
    translate None leos_chapter3_0541:
        "…."
    translate None leos_chapter3_0542:
        "……"
    translate None leos_chapter3_0543:
        lmn "好吧…该回去了—"
    translate None leos_chapter3_0544:
        ae ang "我告诉过你别来烦我。"
    translate None leos_chapter3_0545:
        l wneu "…是莱奥斯。"
    translate None leos_chapter3_0546:
        ae "莱奥斯…？"

    window hide dissolve

    scene bg eclipse night with dissolve:
        size(1920, 1080)
    window show dissolve
    translate None leos_chapter3_0547:
        "门开了，艾米尔隐在暗处，见到他时满脸惊讶。"

    show leos nw dim cloak sur at slightright
    show ds n dim neu at slightleft
    with dissolve
    jump leosspeakerafter

label leosbarge:
    scene bg eclipse night with vpunch:
        size(1920, 1080)
    play sound "sounds/sfx/slam.ogg"
    translate None leos_chapter3_0548:
        "毫无预警地，莱奥斯推开了门。他本以为会遇上阻力—这门至少该上锁—没想到它轻易就敞开了。"

    #window hide dissolve

    #window show dissolve
    translate None leos_chapter3_0549:
        "狂风呼啸着灌进店铺，莱奥斯与震惊的艾米尔四目相对。"
    translate None leos_chapter3_0550:
        show leos nw dim cloak sur at slightright
        show ds n dim neu at slightleft
        with dissolve
        ae sur "...."
    translate None leos_chapter3_0551:
        l "…呃…抱歉…"
    translate None leos_chapter3_0552:
        ae "你来干什么…？"
    translate None leos_chapter3_0553:
        "莱奥斯挠了挠后脑勺。"
    translate None leos_chapter3_0554:
        lmn "我到底在做什么…"

    jump leosspeakerafter


label leosspeakerafter:
    translate None leos_chapter3_0555:
        l "…想和你谈谈。"
    translate None leos_chapter3_0556:
        "说话时，他另一只手仍在把玩武器握柄。"
    translate None leos_chapter3_0557:
        show ds n dim ann with dis
        ae "不能等天亮再说？"
    translate None leos_chapter3_0558:
        l "单独谈。"
    translate None leos_chapter3_0559:
        ae "…那就直说吧。"
    translate None leos_chapter3_0560:
        l "等我杀了雷恩后，该怎么回奥雷利亚卡维拉？"
    translate None leos_chapter3_0561:
        ae "...."
    translate None leos_chapter3_0562:
        ae "你回不去。没有我在场就没有退路。"
    translate None leos_chapter3_0563:
        show leos nw dim pis with dis
        l "你派我去执行必死任务。"
    translate None leos_chapter3_0564:
        ae "而你欣然接受了。"
    translate None leos_chapter3_0565:
        l "…如果知道真相，我不会答应。"
    translate None leos_chapter3_0566:
        ae "真的？你向来散发着\"即便赴死也会接受任务\"的气场。"
    translate None leos_chapter3_0567:
        l "......"
    translate None leos_chapter3_0568:
        lmn "他说得没错。"
    translate None leos_chapter3_0569:
        show ds n dim sad with dis
        ae "…现在说这些已无意义，但…我很抱歉。"
    translate None leos_chapter3_0570:
        show leos nw dim sur with dis
        l "你…你在道歉？"
    translate None leos_chapter3_0571:
        ae "这一切本不该发生。"


    if leos_badend > leos_goodend:
        jump leosbadending

    else:
        jump leos3notbadend



label leos3notbadend:

    translate None leos_chapter3_0572:
        lmn "干脆利落地割喉。虽不优雅，但想到他对雷恩的所作所为，看他痛苦也不赖。"
    translate None leos_chapter3_0573:
        "莱奥斯艰难地吞咽着，内心正做最后决断。"
    translate None leos_chapter3_0574:
        lmn "反抗我的宿命…这也是雷恩所愿，不是吗？"
    translate None leos_chapter3_0575:
        "然而此刻，他眼前这个被视作\"说书人\"的男人，不过是道苍白的影子。"
    translate None leos_chapter3_0576:
        "渺小而脆弱。那份高傲的态度、威严的仪态去哪儿了？"
    translate None leos_chapter3_0577:
        "不在这里。或许从一开始就不曾存在过。"
    translate None leos_chapter3_0578:
        "他的手指松开了力道。"
    translate None leos_chapter3_0579:
        show leos nw dim pis with dis
        l "你为什么跟他走这么远？"
    translate None leos_chapter3_0580:
        show ds n dim neu with dis
        ae "我以为自己在做正确的事，但现在我明白了，我只不过让自己看起来像个傻子。"
    translate None leos_chapter3_0581:
        l "你难道不想再杀他一次吗？"
    translate None leos_chapter3_0582:
        ae "生活将回归原样。我不会动他一根手指。"
    translate None leos_chapter3_0583:
        l "....."
    translate None leos_chapter3_0584:
        l "…他打算明天和你一起回去。记得装作很惊讶。"
    translate None leos_chapter3_0585:
        ae "那你呢？"
    translate None leos_chapter3_0586:
        l "你很清楚我无家可归。"
    translate None leos_chapter3_0587:
        show ds n dim sad with dis
        ae "毕竟，我们俩简直一模一样。"
    translate None leos_chapter3_0588:
        l "...?"
    translate None leos_chapter3_0589:
        ae "注定孤独终老。"
    translate None leos_chapter3_0590:
        "莱奥斯皱眉，双臂交叉抱在胸前。"
    translate None leos_chapter3_0591:
        l "我要坦白告诉你。有人找过我，说只要杀了你就能改写我的命运。"
    translate None leos_chapter3_0592:
        show ds n dim ann with dis
        ae "什么？这里不该有人认识我。"
    translate None leos_chapter3_0593:
        l "但那人确实知道。"
    translate None leos_chapter3_0594:
        ae "没有人…没有人拥有这种力量。"
    translate None leos_chapter3_0595:
        "艾米尔的眉头紧锁，仿佛在说服自己相信正在说出口的话。"
    translate None leos_chapter3_0596:
        l "但万一他真有呢？"
    translate None leos_chapter3_0597:
        ae "那我想你会杀了我。"
    translate None leos_chapter3_0598:
        show leos nw dim sur with dis
        l "你就这么坦然接受？"
    translate None leos_chapter3_0599:
        ae "如果我们交手，胜者肯定是你。这点毋庸置疑。"
    translate None leos_chapter3_0600:
        ae "…那个找你的人长什么样？"
    translate None leos_chapter3_0601:
        l "不清楚。我没看清。黑发红眸…只记得他声音里的讥讽。"
    translate None leos_chapter3_0602:
        ae "....."
    translate None leos_chapter3_0603:
        "莱奥斯的手重新搭上门框，叹了口气。"
    translate None leos_chapter3_0604:
        lmn "真是浪费时间。如果我杀了他，那就证明我毫无改变。"
    translate None leos_chapter3_0605:
        lmn "那人当然在说谎。我只是…想找任何能留在雷恩身边的借口。"
    translate None leos_chapter3_0606:
        lmn "…"
    translate None leos_chapter3_0607:
        show leos nw dim neu with dis
        l "不知为何要来这儿。我该走了。"
    translate None leos_chapter3_0608:
        show ds n dim sad with dis
        ae "等等…替我向雷恩道个歉。"
    translate None leos_chapter3_0609:
        l "不。自己去说。"
    translate None leos_chapter3_0610:
        "他摆摆手离开商店，将伤害说书人的念头彻底抛诸脑后。"

    stop music fadeout 3.0
    window hide dissolve

    scene bg swroom day with Fade(1.0, 1.0, 1.0)
    window show dissolve
    translate None leos_chapter3_0611:
        rs wneu "嗯…"
    translate None leos_chapter3_0612:
        play music "sounds/bgm/Discovery.ogg" fadein 3.0
        l wneu "终于醒了？"
    translate None leos_chapter3_0613:
        "我眨眨眼醒来，正对着莱奥斯赤裸的胸膛。"
    translate None leos_chapter3_0614:
        rs wemb "啊，对不起…！"
    translate None leos_chapter3_0615:
        "夜里不知怎么搞的，我竟然滚到了他身上…太丢人了…"
    translate None leos_chapter3_0616:
        "我慌忙想挪开，却被他的胳膊牢牢固定住。"
    translate None leos_chapter3_0617:
        rs wsur "...?"
    translate None leos_chapter3_0618:
        l wneublu "大清早别这么吵吵闹闹的。"
    translate None leos_chapter3_0619:
        rs wemb "我不是…我不是故意的…"
    translate None leos_chapter3_0620:
        l "经过昨晚的事后你还在担心这个，真的吗？"
    translate None leos_chapter3_0621:
        rs "........."
    translate None leos_chapter3_0622:
        "啊。"
    translate None leos_chapter3_0623:
        "哦，昨晚啊。对。那确实发生了些事情。"
    translate None leos_chapter3_0624:
        rs "咳…"
    translate None leos_chapter3_0625:
        l "...."
    translate None leos_chapter3_0626:
        rs "我…昨晚挺开心的。"
    translate None leos_chapter3_0627:
        l "…嗯，我也是。"
    translate None leos_chapter3_0628:
        rs "......."
    translate None leos_chapter3_0629:
        l ".........."
    translate None leos_chapter3_0630:
        "啊啊啊现在太尴尬了！就因为他抓着我不放更尴尬了！"
    translate None leos_chapter3_0631:
        l wneu "我想是时候了，对吧？"
    translate None leos_chapter3_0632:
        rs wsur "时候？"
    translate None leos_chapter3_0633:
        l "你该回家了。"
    translate None leos_chapter3_0634:
        rs wsad "..趁我把事情处理完之前。"
    translate None leos_chapter3_0635:
        l "....."
    translate None leos_chapter3_0636:
        l wsur "那在这儿耗着也没意义。"
    translate None leos_chapter3_0637:
        "他的手臂从我身边松开，从床上起身，自下而上地穿着衣服。我情不自禁远远欣赏他强壮匀称的身材。"
    translate None leos_chapter3_0638:
        l wneu "看什么呢？赶紧起来。"
    translate None leos_chapter3_0639:
        rs "好—的—"
    translate None leos_chapter3_0640:
        "我快速捞起散落的衣服穿上，昨晚的种种像一袋砖头砸中我的记忆。"
    translate None leos_chapter3_0641:
        "除了那些事…他告诉我的所有话…"
    translate None leos_chapter3_0642:
        "他现在真的信任我了，对吧？我不能让他失望。"
    translate None leos_chapter3_0643:
        "当斗篷披上肩头时，我摸到口袋里霍恩给的马卡龙。"
    translate None leos_chapter3_0644:
        "临走前送给他吧…当作临别礼物。"
    translate None leos_chapter3_0645:
        "临别礼物\"这个词在我脑海中空洞回响，我努力把它们赶到一边。"
    translate None leos_chapter3_0646:
        "未果。"
    translate None leos_chapter3_0647:
        "待我们都穿戴整齐，慢慢摸到大堂，以为福恩和赛恩会在等我们。"

    window hide dissolve

    scene bg sw day with dissolve
    window show dissolve
    stop music fadeout 2.0
    translate None leos_chapter3_0648:
        "结果空无一人。连艾琳都没站在柜台后等候客人。视野中见不到半点蓝发或金发。"
    translate None leos_chapter3_0649:
        rs c wsur "搞什…人都去哪儿了？"
    translate None leos_chapter3_0650:
        l c wpis "…不对劲。"
    translate None leos_chapter3_0651:
        play music "sounds/bgm/creepy.ogg" fadein 3.0
        rs "什么意思？可能他们还在睡。"
    translate None leos_chapter3_0652:
        l "不..感觉到了吗？气氛完全不对。"
    translate None leos_chapter3_0653:
        "唔…是有点安静…"
    translate None leos_chapter3_0654:
        "莱奥斯突然俯身铁钳般抓住我的手，急匆匆冲向大门。"



    window hide dissolve

    scene bg sc grey with dissolve:
        xpos 0.57 ypos 1.15 xanchor 0.5 yanchor 1.0 zoom 1.21
        linear 18.0 xpos 0.4 ypos 1.15 xanchor 0.5 yanchor 1.0 zoom 1.21
    window show dissolve
    translate None leos_chapter3_0655:
        "天色阴沉，暗灰云层自地平线翻涌而来。街道昏暗空旷，毫无生气。"
    translate None leos_chapter3_0656:
        rs c wsur "喂…喂，你要干什么？！"
    translate None leos_chapter3_0657:
        l  c wpis "看看周围。完全空了。"
    translate None leos_chapter3_0658:
        rs "…？人都哪去了？"
    translate None leos_chapter3_0659:
        l "不知道，但我们没必要留下查明。"
    translate None leos_chapter3_0660:
        rs c wsad "等等莱奥斯，你确定不是反应过度？"
    translate None leos_chapter3_0661:
        l c wneu "我什么时候会？"
    translate None leos_chapter3_0662:
        rs "哈哈…真是太好笑了。走吧，或许其他人已经在\"月蚀\"等了。"
    translate None leos_chapter3_0663:
        l "....."
    translate None leos_chapter3_0664:
        "他看起来想争辩什么，却忍住了没说。"
    translate None leos_chapter3_0665:
        l c wpis "…好吧，但如果我们到那儿发现人都走了，就立刻离开。"
    translate None leos_chapter3_0666:
        rs c wsur "哇哦，你破天荒竟然听我的了？"
    translate None leos_chapter3_0667:
        l c wsmu "违背了我更好的判断。"
    translate None leos_chapter3_0668:
        rs "喂！"
    translate None leos_chapter3_0669:
        "他挤出微笑，强忍着笑。"
    translate None leos_chapter3_0670:
        l "你总爱做坏决定这点我也没办法。"
    translate None leos_chapter3_0671:
        rs c wsmi "是啊，反正有你在旁边给我收拾烂摊子，不是吗？"
    translate None leos_chapter3_0672:
        l "是啦是啦。"
    translate None leos_chapter3_0673:
        "前往\"月蚀\"的路上街道空无一人。我遏制不住内心汹涌的不安。"
    translate None leos_chapter3_0674:
        "但是…为什么？"
    translate None leos_chapter3_0675:
        "因为太安静？"
    translate None leos_chapter3_0676:
        "因为一切都仿佛…停滞了？"
    translate None leos_chapter3_0677:
        "不…是因为这让我想起奥克斯哈伯。商店紧闭，街头杳无人迹。"
    translate None leos_chapter3_0678:
        "..但我确信这没什么。一定是我的大脑在捉弄我。"
    translate None leos_chapter3_0679:
        "冷风卷着枯叶在我脚边打转。无视脑海里响起的警铃，我和莱奥斯继续向\"月蚀\"前进。"

    window hide dissolve

    jump meetlucius


label leossecretvillage1:
    scene bg sv night with Fade(1.0, 1.0, 1.0):
        xpos 0.68 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.47
        linear 26.0 xpos 0.28 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.47
    window show dissolve
    play music "sounds/bgm/sad.ogg" fadein 3.0
    translate None leos_chapter3_0680:
        l c wpis "嘿。"
    translate None leos_chapter3_0681:
        "莱奥斯在夜色中潜行，终于逮住了他要找的人。绿发男子佯装惊讶地看着他，但双方都心知肚明这场会面。"
    translate None leos_chapter3_0682:
        "莱奥斯迅速离开了莫温带他去的房间。心绪翻腾让他根本无法休息。"
    translate None leos_chapter3_0683:
        "首先是雷恩的秘密。他并不愤怒，也不失望，更不怨恨。只是…心痛。"
    translate None leos_chapter3_0684:
        "他理解对方隐瞒的原因。毕竟自己是来取他性命的杀手。"
    translate None leos_chapter3_0685:
        "但还是痛。"
    translate None leos_chapter3_0686:
        "其次是卢修斯给的那把匕首。上面的家族纹章…怎么会？为什么会在锡德卡汉？那具尸体怎么会有这个？"
    translate None leos_chapter3_0687:
        "最后…是眼前这个男人。伊尔兰。"
    translate None leos_chapter3_0688:
        "…他的青梅竹马。"
    translate None leos_chapter3_0689:
        i fli "又是一次见不得人的夜访？别人会说闲话的。"
    translate None leos_chapter3_0690:
        v neu "我先走一步。"
    translate None leos_chapter3_0691:
        i con "别惹太多麻烦。"
    translate None leos_chapter3_0692:
        v smi "我什么时候会？"
    translate None leos_chapter3_0693:
        "维拉斯挥手示意，迅速隐入黑暗，留下他们二人。伊尔兰难得沉默地等对方开口。"


    scene bg sv night:
        xpos 0.22 ypos 1.01 xanchor 0.5 yanchor 1.0 zoom 1.66
    show leos nw dark neu cloak at slightleft
    show illran n dark armsdown neu at slightright
    with dissolve
    translate None leos_chapter3_0694:
        l "...."
    translate None leos_chapter3_0695:
        i "你就打算杵在那里板着脸盯着看？"
    translate None leos_chapter3_0696:
        show leos nw dark pis with dis
        l "是你没错吧？我记忆里那个男孩。"
    translate None leos_chapter3_0697:
        show illran n dark sad with dis
        i "...."
    translate None leos_chapter3_0698:
        $ about_Illran._text.append("伊尔兰出生于奥雷利亚卡维拉，与莱奥斯童年时便是挚友。当发现阿祖罗斯的真相后，他被迫逃离故乡。")
        i "没想到你还记得{a=set_entry:enc_people->about_Illran}{color=#87CEEB}我{/color}{/a}。"
    translate None leos_chapter3_0699:
        lmn "确实……"
    translate None leos_chapter3_0700:
        show leos nw dark sur with dis
        l "为何不早点告诉我？"
    translate None leos_chapter3_0701:
        "伊尔兰搓揉着后颈，罕见地流露出脆弱的一面。"
    translate None leos_chapter3_0702:
        i "都是往事。我不确定是否有重提的必要。"
    translate None leos_chapter3_0703:
        l "这些年来…我一直以为你死了。我…始终在自责。"
    translate None leos_chapter3_0704:
        i "为什么？"
    translate None leos_chapter3_0705:
        l "因为…他们总说我会害死身边所有人。虽不愿相信，可当你…当你消失时，我…我以为……"
    translate None leos_chapter3_0706:
        i "……抱歉。本想道别，但当时局势…有些失控。"
    translate None leos_chapter3_0707:
        "两人并肩坐在雪地里，肩头突然卸下千斤重担。"
    translate None leos_chapter3_0708:
        show leos nw dark sur with dis
        l "不过…既然你平安无事…或许我的「审判」终究没那么重要…"
    translate None leos_chapter3_0709:
        i "我向来不信这套。旁人的看法有什么好在意的？"
    translate None leos_chapter3_0710:
        l "你说得轻巧。整天没心没肺地活着。"
    translate None leos_chapter3_0711:
        i "...."
    translate None leos_chapter3_0712:
        i "若真给人这种印象，倒算我的本事。"
    translate None leos_chapter3_0713:
        i "知道他们怎么评价我吗？说书人的门徒，众多助手中的一个。算是圣职人员吧—不够格当说书人，却适合给神明当脚凳。"
    translate None leos_chapter3_0714:
        l "哈，你现在不就在干这个？"
    translate None leos_chapter3_0715:
        i "闭嘴。维拉斯不一样。他是我唯一愿意追随的人。"
    translate None leos_chapter3_0716:
        l "……知道吗？那时只有你让我感觉自己像个普通人。"
    translate None leos_chapter3_0717:
        show illran n dark neu with dis
        i "我走后你过得怎样？"
    translate None leos_chapter3_0718:
        l "......"
    translate None leos_chapter3_0719:
        l "被罚面壁思过很久，不过都过去了。更重要的是…当时你是和母亲一起离开的？"
    translate None leos_chapter3_0720:
        i "没错。"
    translate None leos_chapter3_0721:
        l "她还好吗？她总是笑得那么温柔。其实我…呃…曾经渴望成为你。"
    translate None leos_chapter3_0722:
        show illran n dark sad with dis
        i "……她去世了。"
    translate None leos_chapter3_0723:
        l "....."
    translate None leos_chapter3_0724:
        i "……但多亏…某个人的开解，我终于能面对这个事实。"
    translate None leos_chapter3_0725:
        show illran n dark hap with dis
        i "我会活出最精彩的人生，这样当我们再次相遇时，她就能告诉我她有多为我骄傲。"
    translate None leos_chapter3_0726:
        l "我认为这才是最好的活法。"
    translate None leos_chapter3_0727:
        i "你也该试试看。感觉还不错。"
    translate None leos_chapter3_0728:
        l "我不知道自己配不配得上。"
    translate None leos_chapter3_0729:
        show illran n dark sad with dis
        i "为什么？就因为杀过几个人？我可没被这种事绊住脚步。"
    translate None leos_chapter3_0730:
        l "要是雷恩在这儿，他肯定会叫你别把生命看得太轻。"
    translate None leos_chapter3_0731:
        i "你什么时候开始这么容易认同他了？"
    translate None leos_chapter3_0732:
        l "…我不知道"
    translate None leos_chapter3_0733:
        l "他是个傻子，对吧？"
    translate None leos_chapter3_0734:
        i "这点很明显。"
    translate None leos_chapter3_0735:
        show leos nw dark neu blush with dis
        l "但是，他…他心地很好。"
    translate None leos_chapter3_0736:
        i "你变得这么多愁善感了知道吗？"
    translate None leos_chapter3_0737:
        l "你也没好到哪去。"
    translate None leos_chapter3_0738:
        show leos nw dark thi -blush with dis
        l "我只是…现在对所有事都很困惑。我的人生，我的目标…还有雷恩。"
    translate None leos_chapter3_0739:
        i "知道吗，这种时候我喜欢想起一个海外传来的古老谚语。"
    translate None leos_chapter3_0740:
        i "活在当下，笑对每天，爱无需言。"
    translate None leos_chapter3_0741:
        show leos nw dark sur with dis
        l "哈哈哈…这听起来蠢毙了。你在耍我吗？"
    translate None leos_chapter3_0742:
        show illran n dark hap with dis
        i "是啊，抱歉。"
    translate None leos_chapter3_0743:
        show illran n dark neu with dis
        i "好吧…想要点正经建议？说真的，追随你的心。虽然老套，但阻碍你和雷恩在一起的只有你自己的不安。"
    translate None leos_chapter3_0744:
        l "和他在一起？"
    translate None leos_chapter3_0745:
        show illran n dark sad with dis
        i "对，我忘了你以前是邪教徒。约会、结婚，随你怎么称呼。你爱他，不是吗？"
    translate None leos_chapter3_0746:
        show leos nw dark neu blush with dis
        l "...."
    translate None leos_chapter3_0747:
        i "不去尝试将来后悔没有任何意义。"
    translate None leos_chapter3_0748:
        i "...."
    translate None leos_chapter3_0749:
        i "啊，该死。我真是个伪君子。"
    translate None leos_chapter3_0750:
        show leos nw dark sur -blush with dis
        l "…哈，看来我们终究没太大差别。"
    translate None leos_chapter3_0751:
        i "我想是的。"
    translate None leos_chapter3_0752:
        l "那你为什么不对他也这么做？"
    translate None leos_chapter3_0753:
        i "和维拉斯？呃，眼前的问题是我们寿命悬殊，不是吗？对他来说我转眼就会死去。"
    translate None leos_chapter3_0754:
        i "…而且我连他是否那样喜欢我都不知道。我是说..我们亲密无间，但…迈出最后一步很可怕。"
    translate None leos_chapter3_0755:
        l "为什么不干脆不管那么多？"
    translate None leos_chapter3_0756:
        i "…你听到他说的话了吧？他计划这是最后一次旅行了。"
    translate None leos_chapter3_0757:
        l "对不起…"
    translate None leos_chapter3_0758:
        i "我不知道没有他我该怎么办。"
    translate None leos_chapter3_0759:
        "莱奥斯低头看着微雪覆盖的地面，不知该说什么。"
    translate None leos_chapter3_0760:
        i "就拿我当反面教材吧，懂吗？这是你绝对不该做的。"
    translate None leos_chapter3_0761:
        i "至少先跟他睡一觉。"
    translate None leos_chapter3_0762:
        show leos nw dark thi blush with dis
        l "......"
    translate None leos_chapter3_0763:
        show illran n dark fli with dis
        i "啊…？"
    translate None leos_chapter3_0764:
        l "不，等等，我..我觉得不行…"
    translate None leos_chapter3_0765:
        i "这倒是出人意料的发展。学生已然成为老师。"
    translate None leos_chapter3_0766:
        l "我…我真不确定我们是否…"
    translate None leos_chapter3_0767:
        show illran n dark sad with dis
        i "你怎能不确定？"
    translate None leos_chapter3_0768:
        "强忍着尴尬与羞耻，他总算向对方完整道出了他们之间发生的事。"
    translate None leos_chapter3_0769:
        i "…幸好雷恩对这类事情和你一样懵懂。给，拿着这个。"
    translate None leos_chapter3_0770:
        "伊尔兰从口袋里摸出个瓶子抛向莱奥斯。后者接住后狐疑地端详着。"
    translate None leos_chapter3_0771:
        l "那是什么？"
    translate None leos_chapter3_0772:
        show illran n dark con with dis
        i "这东西能让你们俩玩得更尽兴，朋友。"
    translate None leos_chapter3_0773:
        "伊尔兰凑近莱奥斯耳语，若有旁人目睹，会看见他每听一句脸色就红上一分。"
    translate None leos_chapter3_0774:
        l "你随身带这种东西做什么？！"
    translate None leos_chapter3_0775:
        show illran n dark hap with dis
        i "以备不时之需。"
    translate None leos_chapter3_0776:
        stop music fadeout 3.0
        l ".........."

    window hide dissolve

    scene bg sv night with Fade(1.0, 1.0, 1.0):
        xpos 0.68 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.47
        linear 26.0 xpos 0.28 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.47
    window show dissolve
    translate None leos_chapter3_0777:
        i con "别惹太多麻烦。" # VOICE MAP?
    translate None leos_chapter3_0778:
        v smi "我什么时候会？" # VOICE MAP?
    translate None leos_chapter3_0779:
        play music "sounds/bgm/night.ogg" fadein 3.0
        "维拉斯独自走进夜色，留下伊尔兰与莱奥斯交谈。"
    translate None leos_chapter3_0780:
        "他知晓二人的过往，也早劝过伊尔兰坦白—但并未强求。这不该由他插手。"
    translate None leos_chapter3_0781:
        "他们的谈话声逐渐远去，唯余他独自沉思。"
    translate None leos_chapter3_0782:
        vmn "或许这是最后一次漫步山间了。最后一次聆听积雪在脚下咯吱作响。"
    translate None leos_chapter3_0783:
        vmn "还有那么多风景未及目睹。空度如许岁月，却仍有无数地方未曾踏足…"
    translate None leos_chapter3_0784:
        vmn "若能携伊尔兰同游这些地方，付出任何代价我都愿意。"
    translate None leos_chapter3_0785:
        vmn "…但他的生命不该由我挥霍。"
    translate None leos_chapter3_0786:
        "挥散这些念头时，他瞥见前方阴影处有两个小声交谈的身影。"
    translate None leos_chapter3_0787:
        "走近细看才发现，实际更像是单方面的对话。"
    translate None leos_chapter3_0788:
        v neu "…艾米尔，卡斯皮安。"
    translate None leos_chapter3_0789:
        cas sad "噢..你好啊，呃..维拉斯？"
    translate None leos_chapter3_0790:
        v "正是。二位还不休息？"
    translate None leos_chapter3_0791:
        cas "我累了，只是…"
    translate None leos_chapter3_0792:
        ae ann "....."
    translate None leos_chapter3_0793:
        cas "好，好吧，我这就走。"
    translate None leos_chapter3_0794:
        scene bg sv night:
            xpos 0.08 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 2.22
        show veras n dark o1 neu1 at slightleft
        show ds n dark neu at slightright
        with dissolve
        "他匆匆离去，留维拉斯与艾米尔并肩而立。"
    translate None leos_chapter3_0795:
        "他比想象中更为高大魁梧。有着言者的外貌，却无半分言者的做派。"
    translate None leos_chapter3_0796:
        "或许正因如此，维拉斯竟对他生出几分怜悯。"
    translate None leos_chapter3_0797:
        v "你不打算就寝？"
    translate None leos_chapter3_0798:
        ae "…我不困。"
    translate None leos_chapter3_0799:
        show veras n dark smi1 with dis
        v "那要散散步吗？新鲜空气或许有帮助。"
    translate None leos_chapter3_0800:
        "艾米尔上下打量着维拉斯，拼命搜刮婉拒的借口，最终却…"
    translate None leos_chapter3_0801:
        show ds n dark sad with dis
        ae "…好吧。"
    translate None leos_chapter3_0802:
        "艾米尔交叉双臂抱在胸前保持体温，两人沿着这条宽阔积雪的小路前行。"
    translate None leos_chapter3_0803:
        "不过称之为小路有些夸张。它简单朴素，被众多足迹磨损，但与城里的街道截然不同。"
    translate None leos_chapter3_0804:
        "在某种程度上，这让维拉斯想起了家乡。想起他的童年。想起那些简单的岁月，那时他相信自己能过普通人的生活。"
    translate None leos_chapter3_0805:
        v "或许你在疑惑为何要同来。"
    translate None leos_chapter3_0806:
        ae "....."
    translate None leos_chapter3_0807:
        v "或许你也感觉这里所有人都与你为敌。仿佛置身敌营。"
    translate None leos_chapter3_0808:
        ae "……如果确实如此呢？"
    translate None leos_chapter3_0809:
        v "那我将消除你的忧虑，因为我并非你的敌人。我只是个旅人。"
    translate None leos_chapter3_0810:
        ae "还是个神明，是我在无知中冒犯过的众多神明之一。"
    translate None leos_chapter3_0811:
        v "人生在世，我们都会无意中伤害他人。关键在于如何弥补。"
    translate None leos_chapter3_0812:
        ae "要我如何弥补？我这不是来了吗？"
    translate None leos_chapter3_0813:
        v "……物理意义上确实在此。你的身躯在此，意识在此，但心却另有所属。"
    translate None leos_chapter3_0814:
        ae "无处归属。"
    translate None leos_chapter3_0815:
        show veras n dark sad1 with dis
        v "若你真这么想，那可悲至极。"
    translate None leos_chapter3_0816:
        show veras n dark smi1 with dis
        v "或许你该换个角度看待这次旅程……这是第二次机会。你能让事情往好的方向发展。你可以寻求宽恕。"
    translate None leos_chapter3_0817:
        show ds n dark neu with dis
        ae "向谁？"
    translate None leos_chapter3_0818:
        v "当然是卡斯皮安。"
    translate None leos_chapter3_0819:
        show ds n dark sad with dis
        ae "...."
    translate None leos_chapter3_0820:
        ae "我不配得到任何人的宽恕。我犯过太多过错。"
    translate None leos_chapter3_0821:
        v "也许第一步是原谅你自己。"
    translate None leos_chapter3_0822:
        ae "......"
    translate None leos_chapter3_0823:
        v "我能看出你们彼此伤害至深，但并非无可挽回。"
    translate None leos_chapter3_0824:
        v "不过谈论他人就到此为止吧？你是否决定—这本就与我无关"
    translate None leos_chapter3_0825:
        ae "……谢谢你，我…我会试着与他谈谈。"
    translate None leos_chapter3_0826:
        v "……很高兴听你这么说。"
    translate None leos_chapter3_0827:
        v "若有闲暇，我想多听听你的故事。"
    translate None leos_chapter3_0828:
        show ds n dark sur with dis
        ae "我的故事？"
    translate None leos_chapter3_0829:
        show veras n dark neu1 with dis
        v "我活了很久。以人类之躯不过五百年，但此前没有形体的岁月更难以计数。我见过许多神圣代言人，但像你这样的实属罕见。他们都是…嗯。该怎么说？"
    translate None leos_chapter3_0830:
        v "自以为是？道貌岸然？他们表现得超脱凡尘欲望，却都堕入相同深渊。变得贪婪自私。"
    translate None leos_chapter3_0831:
        v "你…我看得出你与众不同。"
    translate None leos_chapter3_0832:
        show ds n dark sad with dis
        ae "……是吗？我从未想成为言者。至今也不想。"
    translate None leos_chapter3_0833:
        show veras n dark sur1 with dis
        v "什么？"
    translate None leos_chapter3_0834:
        ae "这个头衔并非由我选择所获。我一直渴望拥有一个平凡的家庭，过上普通的生活。"
    translate None leos_chapter3_0835:
        ae "…但也不全是坏事。有卡斯皮安陪在身边，他…他让一切变得值得。"
    translate None leos_chapter3_0836:
        v "那么，能拥有他确实是你莫大的幸运。"
    translate None leos_chapter3_0837:
        ae "…是的…确实如此，而我却把这视为理所当然。"
    translate None leos_chapter3_0838:
        ae "我真是变成了个老糊涂。若能回到过去改变一切，我什么都愿意付出。"
    translate None leos_chapter3_0839:
        show veras n dark smi1 with dis
        v "至少在我看来，你还年轻得很。"
    translate None leos_chapter3_0840:
        ae "这实在算不上什么称赞。"
    translate None leos_chapter3_0841:
        "维拉斯轻声笑了，回想起年轻时对言者们有多厌恶。"
    translate None leos_chapter3_0842:
        v "很高兴我们能这样聊天。你和我想象中不同。"
    translate None leos_chapter3_0843:
        ae "你也是。"
    translate None leos_chapter3_0844:
        v "你该去休息了。明天若如我所料，你会需要体力的。"

    stop music fadeout 2.0
    window hide dissolve

    scene bg sv night:
        xpos 0.28 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.47
    show raen mw dark cloak sad at mright
    show morwen m dark sad cloakup at mleft
    with Fade(1.0, 1.0, 1.0)
    window show dissolve
    translate None leos_chapter3_0845:
        "关于莱奥斯…？"
    translate None leos_chapter3_0846:
        play music "sounds/bgm/night.ogg" fadein 3.0
        rs "…我想我伤害了他。"
    translate None leos_chapter3_0847:
        mor "还有大把时间弥补。只要告诉他你真实的感受就好。"
    translate None leos_chapter3_0848:
        rs "我的感受…？"
    translate None leos_chapter3_0849:
        "我究竟{i}是{/i}什么感受？"
    translate None leos_chapter3_0850:
        rs "…我觉得可能要吐了。"
    translate None leos_chapter3_0851:
        show morwen m dark sur with dis
        mor "想吐？"
    translate None leos_chapter3_0852:
        rs "每次见到他，我就感觉…特别奇怪。"
    translate None leos_chapter3_0853:
        show morwen m dark smi with dis
        mor "哦，雷恩。你真是太傻了，知道吗？"
    translate None leos_chapter3_0854:
        rs "我是认真的..不知道自己怎么了。"
    translate None leos_chapter3_0855:
        mor "年轻人的爱情真是甜蜜啊，不是吗？" # VOICE MATCH WITH FAWN AND CYNE ROUTE
    translate None leos_chapter3_0856:
        show raen mw dark sur with dis
        rs "…爱？"
    translate None leos_chapter3_0857:
        mor "对，爱。"
    translate None leos_chapter3_0858:
        "一种轻松的感觉涌上心头。一种…被肯定的感觉。"
    translate None leos_chapter3_0859:
        "…我想这种心情已经持续很久了。"
    translate None leos_chapter3_0860:
        rs "我…我得去告诉他…！"
    translate None leos_chapter3_0861:
        mor "注意别语无伦次。慢慢来。"
    translate None leos_chapter3_0862:
        rs "好…！"

    jump caspianraen


label leosnighttimesv:
    translate None leos_chapter3_0863:
        "当卡斯皮安走向自己房间时，我突然感到恐惧。"
    translate None leos_chapter3_0864:
        "害怕向莱奥斯坦白真相。害怕他会推开我。害怕他不原谅我。"
    translate None leos_chapter3_0865:
        "原本迈向莱奥斯所在之处的双脚，突然踉跄着停了下来。"
    translate None leos_chapter3_0866:
        "他真的会…接受我吗？如果他不喜欢那样的我怎么办？"
    translate None leos_chapter3_0867:
        rs c wsur "...."
    translate None leos_chapter3_0868:
        l c wsur "啊…"
    translate None leos_chapter3_0869:
        rs "莱奥斯…"
    translate None leos_chapter3_0870:
        "迎面走来的，是站在雪地中央的莱奥斯。暗红发色在夜色中仍格外醒目。"
    translate None leos_chapter3_0871:
        "仿佛时间只为此刻静止。"
    translate None leos_chapter3_0872:
        "我必须…必须挽回这个局面。"
    translate None leos_chapter3_0873:
        rs "我…我—"
    translate None leos_chapter3_0874:
        l "对不起。"
    translate None leos_chapter3_0875:
        rs "…什么？"
    translate None leos_chapter3_0876:
        l "我反应过度了。"
    translate None leos_chapter3_0877:
        "我在口袋里摸索着那个从昨天起就为此刻保留的物品。"
    translate None leos_chapter3_0878:
        rs "我…我给你准备了点东西。"
    translate None leos_chapter3_0879:
        "我掏出那个小盒子。里面装着一排虽有些压扁却依然可爱的马卡龙。"
    translate None leos_chapter3_0880:
        l "...."
    translate None leos_chapter3_0881:
        l "给…给我的？你还记得？"
    translate None leos_chapter3_0882:
        "他朝我走近几步，脸慢慢皱成一团。不是愤怒，也不是悲伤。他看起来既不恼火也不难过。"
    translate None leos_chapter3_0883:
        "他看起来…很开心。"
    translate None leos_chapter3_0884:
        "一切都发生得太快。转眼间他就站在我面前。盒子掉落在积雪的地上，发出轻柔的声响。"

    window hide dissolve

    #scene gallery_136 with dissolve REMOVED BUT ADD LATER
    scene bg sv night blur
    show leos nw dark neu blush cloak at slightright:
        ypos 1.45 yanchor 1.0 zoom 1.68 xalign 0.1
    show raen nw dark neu blush cloak at slightleft:
        xpos 0.2 ypos 1.45 xanchor 0.2 yanchor 1.0 zoom 1.68 xalign 1.0
    with dissolve
    window show dissolve
    translate None leos_chapter3_0885:
        "他的手掌贴上我的脸庞，而我的手臂环住他的后背，他俯身吻了下来。"
    translate None leos_chapter3_0886:
        "这个吻很温暖，与寒冷的山夜截然不同。"
    translate None leos_chapter3_0887:
        "我踮起脚尖，急切地想够到他。"
    translate None leos_chapter3_0888:
        "他的动作缓慢而甜蜜，将我完全包裹在他的怀抱中，驱散了我心中所有疑虑。"
    translate None leos_chapter3_0889:
        "刚认识时，我想没人会用\"甜蜜\"这个词来形容他。时过境迁啊。"
    translate None leos_chapter3_0890:
        "我稍稍退开看着他的脸，双手仍环抱着他。"
    translate None leos_chapter3_0891:
        show raen sad with dis
        rs "我真的很抱歉。"
    translate None leos_chapter3_0892:
        l "你没什么需要道歉的。"
    translate None leos_chapter3_0893:
        "我摇头作为回应。"
    translate None leos_chapter3_0894:
        rs "如果这世上有人让我无法忍受对他保留秘密，那就是你。"
    translate None leos_chapter3_0895:
        l "…真肉麻。"
    translate None leos_chapter3_0896:
        rs "我知道。"
    translate None leos_chapter3_0897:
        rs "我犯了个错误。只希望你能原谅我。"
    translate None leos_chapter3_0898:
        show leos smu with dis
        l "不幸的是，我好像没办法对你生气太久。"
    translate None leos_chapter3_0899:
        rs "..."
    translate None leos_chapter3_0900:
        "现在正是时候，不是吗？告诉他真相。不再有秘密。"
    translate None leos_chapter3_0901:
        show raen neu with dis
        rs "…我想我爱上你了。"
    translate None leos_chapter3_0902:
        show leos emb with dis
        l "......."
    translate None leos_chapter3_0903:
        "他的脸瞬间红得像甜菜根，却无处可逃。"
    translate None leos_chapter3_0904:
        "他轻轻捏了捏我的脸颊，眼睛依然看向别处。"
    translate None leos_chapter3_0905:
        rs "你…你感觉怎么样？"
    translate None leos_chapter3_0906:
        l "我…."
    translate None leos_chapter3_0907:
        l "我…呃…谢谢你？"
    translate None leos_chapter3_0908:
        show raen sad with dis
        rs "....."
    translate None leos_chapter3_0909:
        l "等等…这也不该是正确答案啊。"
    translate None leos_chapter3_0910:
        "他大声叹气，通红的脸微微皱起。"
    translate None leos_chapter3_0911:
        l "我觉得我也…对你…有同样的感觉。我是说，呃…"
    translate None leos_chapter3_0912:
        l "…我也爱你。"
    translate None leos_chapter3_0913:
        show raen sur with dis
        rs "....."
    translate None leos_chapter3_0914:
        "毫无预兆地，我拉他回来再次亲吻，轻轻贴上他的嘴唇。"
    translate None leos_chapter3_0915:
        i hap "开间房吧你们！"

    window hide dissolve

    scene bg sv night with dissolve
    window show dissolve
    translate None leos_chapter3_0916:
        rs c wsur "...!"
    translate None leos_chapter3_0917:
        l c wemb "哦，糟了…"
    translate None leos_chapter3_0918:
        "远处，我看见伊尔兰在街对面朝我们挥手。他咧嘴笑得灿烂，转身走向莫温早前给他们安排的房间。"
    translate None leos_chapter3_0919:
        l c wneublu "那么…你怎么想？"
    translate None leos_chapter3_0920:
        rs "关于什么？"
    translate None leos_chapter3_0921:
        l "….关于找间房的事。"
    translate None leos_chapter3_0922:
        rs "我有点累了。"
    translate None leos_chapter3_0923:
        l "我没…好吧，行，就这样吧。"
    translate None leos_chapter3_0924:
        "他轻松抓到我的手，牵着我往前走，十指相扣。"

    window hide dissolve

    scene bg sv room night with dissolve:
        xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.11
    window show dissolve
    translate None leos_chapter3_0925:
        "房间简单整洁。没有花哨的装饰，却莫名挡得住寒气。"
    translate None leos_chapter3_0926:
        "我走进房间迅速脱下斗篷，如释重负的感觉令人愉悦。身后传来窸窣声，莱奥斯也在做同样的事。"
    translate None leos_chapter3_0927:
        rs wsmi "今天真是…可能是我们最忙的一天？"
    translate None leos_chapter3_0928:
        l wsmu "我不这么认为。"
    translate None leos_chapter3_0929:
        "我大笑着倒在床上张开双臂。身旁是给莱奥斯的盒子。"
    translate None leos_chapter3_0930:
        "他走过来打开盒子，吃了块点心。"
    translate None leos_chapter3_0931:
        rs "味道如何？"
    translate None leos_chapter3_0932:
        l "和记忆中一样甜。"
    translate None leos_chapter3_0933:
        rs "也给我一个。"
    translate None leos_chapter3_0934:
        "我张开嘴，本没指望他喂我，但转瞬就有个马卡龙挂在我嘴边。"
    translate None leos_chapter3_0935:
        rs whap "嗯…好吃。霍恩的手艺不错。"
    translate None leos_chapter3_0936:
        "莱奥斯缓缓伸手，拂去我脸上的碎屑，在床沿坐下。"
    translate None leos_chapter3_0937:
        stop music fadeout 23.0
        l wsur "你弄得一团糟。"
    translate None leos_chapter3_0938:
        rs wsur "抱歉—嗯！"
    translate None leos_chapter3_0939:
        "他忽然俯身吻住我的唇。他的重量突然压上来，胸膛紧贴着我。"
    translate None leos_chapter3_0940:
        play music "sounds/bgm/sex.ogg" fadein 3.0
        "我环住他的肩膀，仿佛这是天经地义的事，把他拉得更近，直到他几乎骑在我身上。"
    translate None leos_chapter3_0941:
        "他的长马尾从肩头滑落在我胸口。我轻轻用手指梳理着，红发男人喉间发出低沉呻吟。"
    translate None leos_chapter3_0942:
        l wneublu "你要把我逼疯了…"
    translate None leos_chapter3_0943:
        "他的手隔着衣服抚过我的胸膛，攀上肩膀，游走到颈间，然后托起我的脸。"
    translate None leos_chapter3_0944:
        "找到新领域后，他沿着我脖颈亲吻，同时把手探进衬衫抚弄我的胸口。"
    translate None leos_chapter3_0945:
        "感觉怪怪的…"
    translate None leos_chapter3_0946:
        rs wneublu "嗯…"
    translate None leos_chapter3_0947:
        "我…不想再让他一个人忙活…"
    translate None leos_chapter3_0948:
        rs wemb "等…等等…"
    translate None leos_chapter3_0949:
        l "什么事？"
    translate None leos_chapter3_0950:
        rs wneublu "…我想…"
    translate None leos_chapter3_0951:
        l "...?"
    translate None leos_chapter3_0952:
        "虽然手臂已经发软，但莱奥斯还是顺着我的推力倒下。他后背刚沾床铺，我就立即翻身上去跨坐在他腿上。"
    translate None leos_chapter3_0953:
        l "你在干什么？"
    translate None leos_chapter3_0954:
        rs "上次…感觉都是你在动，所以…这次换我来。"
    translate None leos_chapter3_0955:
        "没等他回答，我便俯身再次吻上他，身体从上而下紧贴着他。此时我已浑身发热，衣物显得太过紧绷，令人不适。"
    translate None leos_chapter3_0956:
        "脑海中满是他肌肤与我相触的画面，清冷的空气让这感觉愈发美妙。"
    translate None leos_chapter3_0957:
        "我发出愉悦的叹息，气息在我们唇间震动，同时我的双手也模仿他方才的动作，在他裸露的肌肤上游走，拂过他的胸膛。"
    translate None leos_chapter3_0958:
        "他的肌肤滚烫而柔滑。我的指尖感受着他肌肤下的肌肉线条，为之着迷。"
    translate None leos_chapter3_0959:
        "不知不觉间，我的胯部开始与莱奥斯的身体磨蹭，灼热感突然如烈焰般升腾。每当我身体微动，都能感觉到莱奥斯在我身下的颤动。"
    translate None leos_chapter3_0960:
        "我微微退开这个吻，注视他的面容。他双颊绯红，却未移开视线。他的眼眸如暴风雨般幽暗，紧紧锁住我的目光。"
    translate None leos_chapter3_0961:
        rs "⋯⋯你真美。"
    translate None leos_chapter3_0962:
        l wemb "⋯⋯你撞到头了还是怎么？"
    translate None leos_chapter3_0963:
        rs wsur "嗯⋯我不{i}觉得{/i}有？"
    translate None leos_chapter3_0964:
        l "你可真会鼓舞士气。"
    translate None leos_chapter3_0965:
        "他的身体与我相抵，裤裆间的鼓起已清晰可辨。当我的手指沿着他阳具的轮廓游走时，双唇再度与他相贴。"
    translate None leos_chapter3_0966:
        "他倒抽一口气，在我触碰下微微颤抖。我艰难地咽了咽口水，心跳加速，耳膜鼓动着剧烈声响。"
    translate None leos_chapter3_0967:
        "莱奥斯伸手想要效仿，却被我迅速拍开。"
    translate None leos_chapter3_0968:
        l "你在干什么？"
    translate None leos_chapter3_0969:
        rs "我…"
    translate None leos_chapter3_0970:
        rs "我想试试这个，好吗？"
    translate None leos_chapter3_0971:
        l "⋯⋯好吧，随你。"

    window hide dissolve

    scene gallery_139 with dissolve:
        xpos 0.73 ypos 1.48 xanchor 0.5 yanchor 1.0 zoom 1.5
    window show dissolve
    translate None leos_chapter3_0972:
        "我重重咽了下口水，随后俯身将脸庞移至与他胯部齐平的位置。黑色裤料被撑得紧绷，显得极不舒适。"
    translate None leos_chapter3_0973:
        "最后深吸一口气，我拉开裤链，将他早已坚挺的阳具从内裤中释放出来。当我的手指抚过茎干轻揉顶端时，他浑身战栗。"
    translate None leos_chapter3_0974:
        "我用手圈住他的长度，缓慢抽送着，一下，两下，三下，享受他灼热触感灼烧掌心的滋味。"
    translate None leos_chapter3_0975:
        l "呃…"
    translate None leos_chapter3_0976:
        "我在想如果⋯⋯"

    scene gallery_139

    if persistent.streamer_mode == True:
        show leos_second_sex_censor
    with dissolve
    translate None leos_chapter3_0977:
        "缓缓伸出舌尖，我舔过他的龟头。"
    translate None leos_chapter3_0978:
        l "啊！"
    translate None leos_chapter3_0979:
        rs "这样如何？"
    translate None leos_chapter3_0980:
        "他喉间漏出的呻吟就是答案—看来很不错。"
    translate None leos_chapter3_0981:
        "我继续用手套弄着，同时沿着他的茎干自上而下舔舐，透过半垂的眼帘观察他的反应。"
    translate None leos_chapter3_0982:
        "他的头发如红色海洋般在身周散开，我不禁心生赞叹。他身体的每一寸都堪称完美。"
    translate None leos_chapter3_0983:
        "我的空闲手掌抚过他肌肉紧实的身体，最终停驻在胸膛上轻轻揉捏拉扯。"
    translate None leos_chapter3_0984:
        "他的性器在我舌面上脉动，而我的舌头仍在沿着他的长度游走。这是一种新奇的味道—带着些微咸味—但并不令人反感。"
    translate None leos_chapter3_0985:
        "看到他的反应，我立即明白自己想做更多—任何能让他发出更多声音的事。"
    translate None leos_chapter3_0986:
        "我微微挪动身体，突然觉得裤子和内裤太过束缚。此刻我只渴望他也触摸我，但我想先完成这个。"
    translate None leos_chapter3_0987:
        "我抿紧腮帮，将他纳入唇舌之间，用舌尖描摹侧面的轮廓。"
    translate None leos_chapter3_0988:
        l "呃啊…操…"
    translate None leos_chapter3_0989:
        rs "古伍德这傻逼在干嘛？"
    translate None leos_chapter3_0990:
        l "闭嘴…嗯啊…"
    translate None leos_chapter3_0991:
        l "没人教过你含着东西的时候别说话吗？"
    translate None leos_chapter3_0992:
        "思绪突然闪回我们在福恩家附近河畔重逢的场景，这相似性差点让我笑出声来。 "
    translate None leos_chapter3_0993:
        "暗自憋笑的间隙，我缓缓俯首，尽可能多地容纳他。他在我口中显得如此硕大，根本不可能完全含住，但我仍不断加深吞吐。"
    translate None leos_chapter3_0994:
        "在快感与焦灼交织中，我不自觉抵着他的性器发出呻吟，这震颤引得他喉咙又溢出一声低吼。"
    translate None leos_chapter3_0995:
        "我深深含入，舌尖循着茎身上下律动，沉醉于他被我口腔包裹的触感。"
    translate None leos_chapter3_0996:
        "作为回应，莱奥斯猛然顶胯，将自己更深地送入我口中。我随之调整节奏，吞吐的速度越来越快。"
    translate None leos_chapter3_0997:
        "他的性器沾满前液与唾液，在我的唇间顺畅地进出。"
    translate None leos_chapter3_0998:
        "空闲的那只手隔着裤子抚慰自己，不知还能忍耐多久不索求他的触碰。"
    translate None leos_chapter3_0999:
        l "操，雷恩…再这样…我快不行了…"
    translate None leos_chapter3_1000:
        "他轻轻抽离，我终于得以喘息。在他翻找口袋时，我沿着他的大腿留下一串湿吻。"
    translate None leos_chapter3_1001:
        "他掏出某物悬在我眼前。深色液体在瓶中摇晃，我好奇地审视着。"

    window hide dissolve

    scene bg sv room night with dissolve:
        xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.11
    window show dissolve
    translate None leos_chapter3_1002:
        rs wneublu "那是什么？"
    translate None leos_chapter3_1003:
        l wemb "…能问你件事吗？"
    translate None leos_chapter3_1004:
        rs "这不算回答，不过好吧。"
    translate None leos_chapter3_1005:
        l "....."
    translate None leos_chapter3_1006:
        "令我惊讶的是，他尴尬地别开了视线。此刻他完全赤裸地站在我面前，距离近在咫尺，但那句想问的话似乎比裸露更加令他难堪。"
    translate None leos_chapter3_1007:
        l "我可以…可以把它放进你里面吗？"
    translate None leos_chapter3_1008:
        rs wsur "把什么放进我里面？"
    translate None leos_chapter3_1009:
        l "⋯⋯求你别让我说出口。"
    translate None leos_chapter3_1010:
        "他用恳求的眼神俯视着我，我脑中突然\"咔嗒\"一声明白了他所指何物。"
    translate None leos_chapter3_1011:
        rs "你…你真的能做到那样？"
    translate None leos_chapter3_1012:
        l "显然可以…"
    translate None leos_chapter3_1013:
        rs "..."
    translate None leos_chapter3_1014:
        "我低头看向他那处，突然觉得尺寸似乎更大了。想来只有一个地方能容纳它…"
    translate None leos_chapter3_1015:
        rs wneublu "如果…如果你想的话，那我也愿意。"
    translate None leos_chapter3_1016:
        l wneublu "你确定吗？可能会疼。"
    translate None leos_chapter3_1017:
        rs "⋯⋯如果是你的话就没关系。"
    translate None leos_chapter3_1018:
        l "....."
    translate None leos_chapter3_1019:
        l "上来吧。"
    translate None leos_chapter3_1020:
        "他轻轻将我拉起，安置在床上。动作极尽温柔，修长手指穿过我的发丝，然后撩起我的衬衫。"
    translate None leos_chapter3_1021:
        "他同样快速解除了自己的衣物。衣衫落在地板上，发出几不可闻的闷响。"
    translate None leos_chapter3_1022:
        "当他覆在我上方时，我再次为这份惊人的美貌着迷。这样的他怎会属于我？"
    translate None leos_chapter3_1023:
        "腹肌上沁着细密汗珠，当他跪入我腿间时，我忍不住伸手抚过那些起伏的沟壑。"
    translate None leos_chapter3_1024:
        rs "啊…"
    translate None leos_chapter3_1025:
        "最后蔽体的衣物被他剥离，炽热目光灼烧着裸露的肌肤。随后他拿起瓶子，将内容物倒在掌心，液体汇聚成洼，又淌落在我身上。"
    translate None leos_chapter3_1026:
        "凉得刺骨—与莱奥斯灼人视线形成的反差令人战栗。"


    scene bg sv room night with dissolve:
        xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.11
    show leosroutesex2overlay
    with dissolve
    translate None leos_chapter3_1027:
        "他单手握住我那处，借着润滑液体流畅地抚弄茎身。"
    translate None leos_chapter3_1028:
        rs "嗯⋯⋯啊⋯⋯！"
    translate None leos_chapter3_1029:
        "喉间溢出低沉呻吟，冰凉的液体与他滚烫手掌共同作用下，快感冲得我头脑发晕，甚至希望永远持续下去。"
    translate None leos_chapter3_1030:
        "当他套弄着我性器的同时，拇指不时抚过顶端，另一只手却探向下方—突然有冰凉触感抵在后穴。"
    translate None leos_chapter3_1031:
        rs "...."
    translate None leos_chapter3_1032:
        l "要是疼就告诉我，我会立刻停下。好么？"
    translate None leos_chapter3_1033:
        rs "好…好的…"
    translate None leos_chapter3_1034:
        "我艰难地咽了咽口水。"
    translate None leos_chapter3_1035:
        "那里⋯⋯真的能进去吗⋯⋯？"
    translate None leos_chapter3_1036:
        "他的手指在我的入口处打转，这感觉对我而言全然陌生。湿润而滑腻，但也不算糟糕。"
    translate None leos_chapter3_1037:
        "加上他仍上下套弄着我阴茎的手，这些感觉交融成甚至能称得上愉悦的体验。"
    translate None leos_chapter3_1038:
        l "我要…放进一根手指了，可以吗？"
    translate None leos_chapter3_1039:
        rs "手指？我原以为—"
    translate None leos_chapter3_1040:
        l "…如果就这样直接插进去会疼的。我得先…帮你扩张。"
    translate None leos_chapter3_1041:
        rs "你…这些都是从哪学来的…？"
    translate None leos_chapter3_1042:
        l "....."
    translate None leos_chapter3_1043:
        rs "我叫莱奥斯。"
    translate None leos_chapter3_1044:
        l "…伊尔兰教我的。"
    translate None leos_chapter3_1045:
        rs "什么？"
    translate None leos_chapter3_1046:
        l "我说是伊尔兰告诉我的，行了吧？！"
    translate None leos_chapter3_1047:
        rs "….哈哈哈！天哪，我真想…啊…亲眼看看那场面。"
    translate None leos_chapter3_1048:
        l "闭嘴。被你嘲笑已经够糟了。"
    translate None leos_chapter3_1049:
        rs "…你变了很多，莱奥斯。"
    translate None leos_chapter3_1050:
        l "多亏某个家伙。"
    translate None leos_chapter3_1051:
        "他从上方俯视着我微笑，打转的手指终于探入，轻轻压进我的入口。"
    translate None leos_chapter3_1052:
        rs "啊..！"
    translate None leos_chapter3_1053:
        "被他的修长手指撑开的感觉有些不适。他越来越深入，始终放慢动作，小心避免弄疼我。"
    translate None leos_chapter3_1054:
        l "会疼吗？"
    translate None leos_chapter3_1055:
        rs "不…不算疼…只是有点怪…"
    translate None leos_chapter3_1056:
        "我虽这么说，但晶莹的前液仍从阴茎顶端渗出—莱奥斯正用快感充盈着我的身体。"
    translate None leos_chapter3_1057:
        "他时而将手指抽出又推进，我很快领教到他手指真正的灵巧程度。"
    translate None leos_chapter3_1058:
        "倒也不意外—毕竟手部灵活是他的职业所需。"
    translate None leos_chapter3_1059:
        "我不禁觉得，这比他之前的营生更能发挥所长。"
    translate None leos_chapter3_1060:
        "最终这种感受逐渐转变—变得炽热，甜蜜，令人渴望更多。我抬起盈满祈求的眼睛看向莱奥斯，他简单颔首，小心地加入了第二根手指。"
    translate None leos_chapter3_1061:
        rs "嗯嗯…啊…感觉…塞得满满的…"
    translate None leos_chapter3_1062:
        "这次他的手加快了节奏，在拳头继续抚慰我阴茎的同时，手指也以相同频率抽送着。"
    translate None leos_chapter3_1063:
        "房间是从什么时候开始旋转的…？"
    translate None leos_chapter3_1064:
        "我眨着眼摇头。不，房间并未旋转。只是快感太过强烈，淹没了所有其他感官。"
    translate None leos_chapter3_1065:
        "此刻我唯一渴求的—只有莱奥斯。"
    translate None leos_chapter3_1066:
        rs "求你了，莱奥斯…我要你…"

    scene gallery_140
    if persistent.streamer_mode == True:
        show leos_second_sex_censor2
    with dissolve
    translate None leos_chapter3_1067:
        "他眨了眨眼，仿佛在确认自己听到的是真的，然后从我的身体中抽出了手指。取而代之的是某种钝物，比之前探入我体内的手指粗大得多。"
    translate None leos_chapter3_1068:
        "他轻轻往里推入，我感到自己因为这个感觉而攥紧了床单。"
    translate None leos_chapter3_1069:
        l "你还好吗…？"
    translate None leos_chapter3_1070:
        "他停下动作，给了我片刻时间去适应他的宽度。他的声音浸满情欲，如此色气，即使有些许疼痛我也无法让他停下。"
    translate None leos_chapter3_1071:
        "不，我不想要他停下，因为这就是我一直缺失的东西，无论我是否意识到这点。"
    translate None leos_chapter3_1072:
        rs "我没事…请继续…"
    translate None leos_chapter3_1073:
        l "嗯..啊…."
    translate None leos_chapter3_1074:
        "他像蜗牛般缓慢地在我体内越进越深。两根手指带来的充盈感根本无法与之相比。"
    translate None leos_chapter3_1075:
        l "天啊，你太紧了…试着放松一点…"
    translate None leos_chapter3_1076:
        "我顺从地努力放松心神和肌肉，但当一根滚烫坚硬的棍状物正被推入体内时，这着实有些困难。"
    translate None leos_chapter3_1077:
        rs "已经全部进来了吗…？"
    translate None leos_chapter3_1078:
        l "呃…"
    translate None leos_chapter3_1079:
        l "还没有…？"
    translate None leos_chapter3_1080:
        "我偷偷往下瞥了一眼，看向我们连接的地方。"
    translate None leos_chapter3_1081:
        rs "认真的吗…这才进去一半？!"
    translate None leos_chapter3_1082:
        l "对不起…"
    translate None leos_chapter3_1083:
        "他面容紧绷，似乎为了我如此缓慢地推进用尽了全部自制力。我忍不住轻笑，伸手抚平他紧皱的眉头。"
    translate None leos_chapter3_1084:
        rs "再皱眉会变成小老头的。"
    translate None leos_chapter3_1085:
        "言毕，他向更深处推进，缓慢地，一寸一寸，直到我感受到他的腹部抵上我的身体。"
    translate None leos_chapter3_1086:
        rs "呜..啊…"
    translate None leos_chapter3_1087:
        rs "你怎么会…这么大…!"
    translate None leos_chapter3_1088:
        l "这我也没办法控制。"
    translate None leos_chapter3_1089:
        "他以同样缓慢的速度开始向外抽离。同时重新伸手握住了我的阴茎，在他后撤的节奏中稳步上下撸动。"
    translate None leos_chapter3_1090:
        "当他再次推进我体内时，他的手也顺着我沾满从伊尔兰那里取得液体的阴茎滑动。"
    translate None leos_chapter3_1091:
        "极其缓慢地，我的身体开始习惯这种异样感，不适渐渐融化消失。他轻柔的推入变成了抽插，再也抑制不住呻吟。那声音天鹅绒般丝滑，我只想不断聆听他的嗓音，越多越好。"
    translate None leos_chapter3_1092:
        "当他突然碰到那个敏感点时，我的胸膛剧烈起伏着，因快感而惊叫出声。"
    translate None leos_chapter3_1093:
        "这当然让他挑了挑眉，随即他又一次顶到那个位置。然后是第三次。不知不觉中我已开始与他同步摆动，胯部随着他无形的节奏起伏扭动。"
    translate None leos_chapter3_1094:
        rs "嗯…啊…啊…"
    translate None leos_chapter3_1095:
        "换作其他时候，我喉咙里溢出的这些声音肯定会让我羞耻不已，我相信莱奥斯也一样—但现在不会，因为是莱奥斯在对我做这些事。"
    translate None leos_chapter3_1096:
        "莱奥斯将头靠在我肩上，红发披散在我周围，他轻轻啃咬我的皮肤，呼吸逐渐变成喘息，眉头再次皱起。"
    translate None leos_chapter3_1097:
        "当他在我皮肤上低语时，那声音沙哑得像砂石。"
    translate None leos_chapter3_1098:
        l "操，雷恩…我快到了…"
    translate None leos_chapter3_1099:
        "他闭上眼睛，抽插动作变得缓慢却更深。与此同时我的叫声带着绝望的颤音，身体渴求着被压抑太久的释放。"
    translate None leos_chapter3_1100:
        "我紧紧夹住莱奥斯，享受着他最终高潮时在我体内颤抖的感觉。那感觉很烫，太烫了，但绝对是我会上瘾的滋味。"
    translate None leos_chapter3_1101:
        l "呃..啊..嗯！"
    translate None leos_chapter3_1102:
        "随着一声压抑的喘息，他沉浸在高潮余韵中，仍保持着同样的节奏抽送，紧接着— "
    translate None leos_chapter3_1103:
        rs "啊…!"

    scene gallery_140b with dissolve

    if persistent.streamer_mode == True:
        show leos_second_sex_censor2
    with dissolve
    translate None leos_chapter3_1104:
        "我射在我们俩的胸膛上，身体在快感中尖叫。全身颤抖着，喉咙里发出的声音都不像自己，但这没关系。"
    translate None leos_chapter3_1105:
        "感觉到莱奥斯瘫倒在我身上，他的重量完全压住我，但这种感觉很好。他是真实的，他在我身边，他属于我。"
    translate None leos_chapter3_1106:
        "我们的手环抱着对方的后背，精疲力竭地喘着气。"

    stop music fadeout 2.0
    window hide dissolve

    scene bg sv room night with dissolve:
        xpos 0.21 ypos 1.39 xanchor 0.5 yanchor 1.0 zoom 1.62
        linear 30.0 xpos 0.79 ypos 1.39 xanchor 0.5 yanchor 1.0 zoom 1.62
    window show dissolve
    translate None leos_chapter3_1107:
        l wemb "哈啊..操…"
    translate None leos_chapter3_1108:
        "莱奥斯用手指梳理我的头发，咧嘴笑着将它们拨开。"
    translate None leos_chapter3_1109:
        rs wsad "都是汗…"
    translate None leos_chapter3_1110:
        l "我不介意。"
    translate None leos_chapter3_1111:
        rs wsmi "你真怪。"
    translate None leos_chapter3_1112:
        l "都是因为你。"
    translate None leos_chapter3_1113:
        "莱奥斯笑了，这次我能看出是真心的。没有恶意或讽刺，没有粗鲁或嘲弄。"
    translate None leos_chapter3_1114:
        "我紧紧握住他的手，他也回握住。或许我们可以就这样多待一会儿。"

    stop music fadeout 3.0
    window hide dissolve
    jump sylvirelliot


label sylvirelliot:
    scene bg sv night with Fade(1.0, 1.0, 1.0):
        xpos 0.68 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.47
        linear 26.0 xpos 0.28 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.47
    window show dissolve
    translate None leos_chapter3_1115:
        "西尔维尔倚靠着一堵墙，指尖感受着石壁的凉意。她喜欢这种肌肤触碰石壁的感觉—这提醒着她自己还活着。"
    translate None leos_chapter3_1116:
        play music "sounds/bgm/forgotten off.ogg" fadein 3.0
        "村子的夜晚一如既往，除了那些…不速之客。"
    translate None leos_chapter3_1117:
        "人类是禁止入内的。\"村民们总爱这么说。"
    translate None leos_chapter3_1118:
        "但她亲身体验过规则是可以变通的，而且村民们比外人想象的更容易妥协这些规矩。"
    translate None leos_chapter3_1119:
        "她的情况确实有些不同，毕竟她也曾以人类身份造访此地。命运就是如此奇妙，如今她竟以神明身份回归。"
    translate None leos_chapter3_1120:
        "不过西尔维尔比村里其他人都要年轻许多。她的世界观依然与众不同—仍保持着人类的视角。"
    translate None leos_chapter3_1121:
        "她心里仍萦绕着生前的那种渴望—随心所欲地去任何想去的地方旅行。"
    translate None leos_chapter3_1122:
        "这种渴望在其他人心里早已埋葬了数百年。"
    translate None leos_chapter3_1123:
        "但她克制着自己，压抑着欲望。她亏欠埃利奥特太多，永远无法偿还，因此决定听命于他留在村里。"
    translate None leos_chapter3_1124:
        "直到最近，应莫温的要求出村监视雷恩时，那份渴望才重新燃起。"
    translate None leos_chapter3_1125:
        "她终于从积雪中抬起头，与等候之人的目光相遇。"
    translate None leos_chapter3_1126:
        el neu "西尔维尔。有事吗？"
    translate None leos_chapter3_1127:
        s neu "我想我们可以聊聊那些访客。"
    translate None leos_chapter3_1128:
        "埃利奥特点头回应她，两人开始在夜色中并肩而行。"
    translate None leos_chapter3_1129:
        el "你对他们有什么看法？你知道我一向信任你的判断。"
    translate None leos_chapter3_1130:
        s thi "...."
    translate None leos_chapter3_1131:
        smn "我对他们的看法…"
    translate None leos_chapter3_1132:
        s "…他们本不该出现在这里。他们的问题与我们无关，这点显而易见。"
    translate None leos_chapter3_1133:
        el "哼。很符合你一贯的回答风格。"
    translate None leos_chapter3_1134:
        s sur "你说什么？"
    translate None leos_chapter3_1135:
        el sad "你总是说些我想听的话，但我不能确定这是你的真实想法。"
    translate None leos_chapter3_1136:
        s "那您是要我坦白直言？"
    translate None leos_chapter3_1137:
        el "当然。"
    translate None leos_chapter3_1138:
        "她的思绪飘回莫温身上—历经磨难却依然满怀爱意；又想起维拉斯—明知会承受失去人类的痛苦却依然选择与他们为伴。"
    translate None leos_chapter3_1139:
        "想起自己作为人类的时光—可以无忧无虑地四处游历。"
    translate None leos_chapter3_1140:
        s neu "我认为我们应该帮助他们。"
    translate None leos_chapter3_1141:
        el "哦？即使要我们付出生命作为代价？"
    translate None leos_chapter3_1142:
        s "我们被赐予第二次生命是有原因的。我不认为这个原因就是躲在山上与世隔绝。"
    translate None leos_chapter3_1143:
        el "听起来像个真正的冒险家。我欣赏你的坦诚。"
    translate None leos_chapter3_1144:
        s "相信我，我也不想急着去迎接第二次死亡，但这个卢修斯带来的威胁实在不容忽视，你不觉得吗？"
    translate None leos_chapter3_1145:
        el "…我不反对你，但他们要求我的事，你要求我的事…如果失败了，不仅我们会死，追随我的所有人都会死。"
    translate None leos_chapter3_1146:
        el "我不确定自己能再次承受这种代价。"
    translate None leos_chapter3_1147:
        s thi "也许拒绝帮助同样会导致我们所有人的死亡。但这不重要—决定权在你手上。一如既往，我会遵循你的判断。"
    translate None leos_chapter3_1148:
        el neu "…西尔维尔，我跟你说过…我知道你觉得欠我的，但你早就还清了。"
    translate None leos_chapter3_1149:
        el sad "我知道你梦想再次旅行。如果这是你的愿望，我会支持你。你不必永远困守于此。"
    translate None leos_chapter3_1150:
        s "我从小受的教育就不是要抛弃对我有恩之人。你救过我两次命。"
    translate None leos_chapter3_1151:
        el "而你花了二十年时间偿还这份恩情。我不再要求你什么了。"
    translate None leos_chapter3_1152:
        s ann "二十年对你来说算不了什么。"
    translate None leos_chapter3_1153:
        el "但对年轻如你的人来说却很长。"
    translate None leos_chapter3_1154:
        "前方建筑的阴影中，可见两个正在交谈的人影。是为访客准备的某个房间。"
    translate None leos_chapter3_1155:
        "走近时，她认出了他们。是莫温和卡斯皮安。"
    translate None leos_chapter3_1156:
        el smi "我看得懂你眼里的表情。想说什么就去吧。"
    translate None leos_chapter3_1157:
        s shy "不是你想的那样…"
    translate None leos_chapter3_1158:
        el "我还不至于老糊涂。这世上的爱情本就稀少—对我们这样的人来说更是如此。"
    translate None leos_chapter3_1159:
        "不给对方争辩的余地，他们走向阴影中的二人，那对男女正轻声交谈着。"
    translate None leos_chapter3_1160:
        cas sad "我刚才试着和他说话，但…维拉斯出现了，我觉得有点尴尬，所以…我就走了。"
    translate None leos_chapter3_1161:
        mor cu sad "这样可不行。你要对他坦诚相待。"
    translate None leos_chapter3_1162:
        el neu "哎呀，这不是我们的贵客之一吗。"
    translate None leos_chapter3_1163:
        "卡斯皮安立即向埃利奥特深深鞠躬，这个动作差点让西尔维尔笑出来。"
    translate None leos_chapter3_1164:
        smn "他与我见过的任何王子都不同。不仅谦逊，身上更是全无王室气派，看起来就像个普通人。"
    translate None leos_chapter3_1165:
        smn "或许这是件好事。这世界需要更多普通人。"
    translate None leos_chapter3_1166:
        el sad "请别向我低头。若真要行礼，该是我向您鞠躬才对，殿下。"
    translate None leos_chapter3_1167:
        cas sad "我…根本没资格当王子。只是个普通木匠。"
    translate None leos_chapter3_1168:
        el neu "您太自谦了。"
    translate None leos_chapter3_1169:
        cas "…近二十年来没人把我当王子看待。请直接叫我卡斯皮安就好。"
    translate None leos_chapter3_1170:
        "置身三位神明之间，他明显感到格格不入。不自在地挠着后颈，眼神频频瞟向自己的房间。"
    translate None leos_chapter3_1171:
        s neu "您不该在休息吗？明天一早就要启程了。"
    translate None leos_chapter3_1172:
        cas "…我正要回房时遇见了莫温。"
    translate None leos_chapter3_1173:
        mor "抱歉耽误您休息，请快去就寝吧。"
    translate None leos_chapter3_1174:
        el "我也该告辞了—"
    translate None leos_chapter3_1175:
        cas sur "等等..！我是说，呃…"
    translate None leos_chapter3_1176:
        cas  "其实情况是这样的…"
    translate None leos_chapter3_1177:
        "突兀地提高音量后突然语塞，仿佛自己都不明白要做什么。"
    translate None leos_chapter3_1178:
        el "什么情况？"
    translate None leos_chapter3_1179:
        cas sad "…老实说，我本不想来。听闻…近期种种变故时，我只想埋头逃避。"
    translate None leos_chapter3_1180:
        cas "我宁愿相信这些与我无关。不愿毁掉十八年来苦心经营的生活。"
    translate None leos_chapter3_1181:
        "见他眉头微蹙，西尔维尔知道他在斟字酌句。"
    translate None leos_chapter3_1182:
        cas "但…仇恨循环正是因此延续。我人生诸多错误都源于怯于抗争。"
    translate None leos_chapter3_1183:
        cas "空谈冒险与改变世界，事到临头…却成了懦夫。"
    translate None leos_chapter3_1184:
        cas "若当初…能迈出那一步不再惧惮跌倒，或许一开始就不会失去艾米尔。或许逃出来后就该回奥雷利亚卡维拉拨乱反正。"
    translate None leos_chapter3_1185:
        "不远处窗棂间，高挑剪影倏忽移动。莫温瞥向那个方向，唇角泛起会意微笑。"
    translate None leos_chapter3_1186:
        smn "她某种程度上是个媒人，对吧？她很清楚艾米尔就待在那个房间。"
    translate None leos_chapter3_1187:
        el smi "哼…你虽然喋喋不休，但我能看透你的心。"
    translate None leos_chapter3_1188:
        el neu "西尔维尔，我会尊重你的判断。明天你自己看看是否值得我花时间。"
    translate None leos_chapter3_1189:
        "说完，埃利奥特便隐入了阴影中。"
    translate None leos_chapter3_1190:
        cas emb "天啊，我真的说了好多话，不是吗…太尴尬了…"
    translate None leos_chapter3_1191:
        mor cu smi "你长成了一个好男人，卡斯皮安。"
    translate None leos_chapter3_1192:
        cas "我不太确定…"
    translate None leos_chapter3_1193:
        mor "我确定。现在去吧，好好休息。"
    translate None leos_chapter3_1194:
        "他挥了挥手，走进房间轻轻关上门。雪花温柔地飘落在她们周围，两个女人紧挨着站着，突然间只剩她们独处。"
    translate None leos_chapter3_1195:
        "西尔维尔用手指梳理了下头发，正要开口说话。"
    translate None leos_chapter3_1196:
        "但她还没来得及说，莫温就打断了她。"
    translate None leos_chapter3_1197:
        mor "我们聊会儿怎么样？"
    translate None leos_chapter3_1198:
        s neu "这么晚了？我看你来回走动半天了，是不是把其他人的耳朵都磨出茧子最后才轮到我了？"
    translate None leos_chapter3_1199:
        mor "吃醋了？"
    translate None leos_chapter3_1200:
        s sur "...."
    translate None leos_chapter3_1201:
        mor "开玩笑的，真的。我只是很高兴能见到其他人而已。我已经很久很久…没有身体了，还以为永远见不到雷恩、艾米尔和卡斯皮安了。"
    translate None leos_chapter3_1202:
        mor "…我会永远感激这具身体原来的主人，还有你，是你指引我找到它的。"
    translate None leos_chapter3_1203:
        s thi "没什么大不了的。"
    translate None leos_chapter3_1204:
        mor "对我而言很重要。"
    translate None leos_chapter3_1205:
        mor "总之…我来这儿没多久，大部分时间都卧床不起。我们还没机会一起在月光下散步呢，所以…"
    translate None leos_chapter3_1206:
        mor "一起走吧？"
    translate None leos_chapter3_1207:
        "她笑了，在西尔维尔眼中她仿佛就是月光本身—明亮而美丽。"
    translate None leos_chapter3_1208:
        s neu "..好啊。"

    stop music fadeout 3.0
    window hide dissolve

    if iv_scene_two and illranveras_friend >= 5:
        jump illranverasscene3

    else:
        jump veraselliot



label aftersexleos3:
    scene bg sv room night with Fade(1.0, 1.0, 1.0):
        xpos 0.6 ypos 1.12 xanchor 0.5 yanchor 1.0 zoom 1.35
    window show dissolve
    translate None leos_chapter3_1209:
        rs wneu "那么，你和伊尔兰谈过了？"
    translate None leos_chapter3_1210:
        play music "sounds/bgm/night.ogg" fadein 3.0
        l wneu "嗯…他果然就是我想的那个人。"
    translate None leos_chapter3_1211:
        rs wsur "哇…这有点疯狂不是吗？经过这么多年，在这广阔无边的世界，你们居然还能重逢？"
    translate None leos_chapter3_1212:
        l wsur "你说得比实际情况浪漫多了。"
    translate None leos_chapter3_1213:
        rs "抱歉抱歉，但真的…太神奇了。"
    translate None leos_chapter3_1214:
        l "..是啊，确实。"
    translate None leos_chapter3_1215:
        rs "然后你还向他请教房事技巧。"
    translate None leos_chapter3_1216:
        l wemb "...."
    translate None leos_chapter3_1217:
        l "就话赶话说到那儿的，行吗？！我不是…我不是专程去请教这些的，就是…自然而然地聊到了。"
    translate None leos_chapter3_1218:
        rs wemb "哈哈…哈..哈…等等…你的意思是说你把我们的事告诉伊尔兰了…？"
    translate None leos_chapter3_1219:
        l "哈啊…我们能不能别再提他了？就算他不在场也一样烦人。"
    translate None leos_chapter3_1220:
        rs wsad "我以后怎么还敢直视他的眼睛…"
    translate None leos_chapter3_1221:
        "叹了口气，我把小臂搭在眼睛上。伊尔兰喜欢利用信息要挟别人，对吧？呃…"
    translate None leos_chapter3_1222:
        "床边的莱奥斯紧张地轻笑了一声，然后轻轻把我的手臂从脸上挪开。"
    translate None leos_chapter3_1223:
        l wsur "我还有别的事要跟你说。"
    translate None leos_chapter3_1224:
        rs "今晚我恐怕没精力处理其他事了。"
    translate None leos_chapter3_1225:
        stop music fadeout 2.0
        l wneu "…很重要的事。"
    translate None leos_chapter3_1226:
        "他的声音严肃起来，先前那种温柔的语气消失了。我半坐起身看着他。"
    translate None leos_chapter3_1227:
        rs wneu "那是什么？"
    translate None leos_chapter3_1228:
        l "...."
    translate None leos_chapter3_1229:
        l "…你还记得艾米尔、卢修斯和卡斯皮安的事吧？"
    translate None leos_chapter3_1230:
        rs "记得…？"
    translate None leos_chapter3_1231:
        play music "sounds/bgm/sad.ogg" fadein 3.0
        l "…还有你母亲的事。"
    translate None leos_chapter3_1232:
        "他长叹一口气，交叉双臂。"
    translate None leos_chapter3_1233:
        l "…杀害你母亲、试图杀死卡斯皮安、原本也要除掉你的那些人…是我的家族。"
    translate None leos_chapter3_1234:
        rs wsur "什么…？"
    translate None leos_chapter3_1235:
        l wsur "那时候我还小，但记得一清二楚。"
    translate None leos_chapter3_1236:
        l "妮娅杀了卢修斯—现在我才知道那是正当防卫，而艾米尔下令处死皇室作为报复。"
    translate None leos_chapter3_1237:
        l "…这个决定太过草率，而且他当时还没正式成为言者，本来不该有人执行他的命令…但是…但是他们照做了。"
    translate None leos_chapter3_1238:
        rs "我…"
    translate None leos_chapter3_1239:
        rs wsad "难道你…？"
    translate None leos_chapter3_1240:
        l "…不，我当时太小了，没有参与对付卡斯皮安或妮娅，而是…"

    window hide dissolve

    scene bg aureliacavellanight with Fade(1.0, 1.0, 1.0):
        xpos 0.76 ypos 1.27 xanchor 0.5 yanchor 1.0 zoom 1.64
        linear 35.0 xpos 0.22 ypos 1.27 xanchor 0.5 yanchor 1.0 zoom 1.64
    window show dissolve
    translate None leos_chapter3_1241:
        "莱奥斯仿佛看见四周燃起战火—请别误会，并非真实的战争或火焰，但他能感受到同样灼热的恐惧。"
    translate None leos_chapter3_1242:
        "他的父母当时匆匆带着他出去平息骚动。神圣演说者卢修斯本人，竟被王子的伴侣妮娅冷血杀害。"
    translate None leos_chapter3_1243:
        "卢修斯一直暗中宣扬她的邪恶。说她会让这座城邦珍视的一切毁于一旦。"
    translate None leos_chapter3_1244:
        "当然是暗中进行的。他做任何事都见不得光。"
    translate None leos_chapter3_1245:
        "民众却听信了他的话。他们排挤她，让她感到不受欢迎，巴不得她滚回原来的阴暗角落。"
    translate None leos_chapter3_1246:
        "他们也一直觉得这事有点奇怪。从来没人见过她。她是从哪来的？"
    translate None leos_chapter3_1247:
        "莱奥斯对她也没有任何看法。毕竟他从小就是这样被教导的—冷漠无情才能心无波澜地杀人。"
    translate None leos_chapter3_1248:
        "……至少别人是这么告诉他的。"
    translate None leos_chapter3_1249:
        "但此刻当他抱着婴儿走出宫殿时，突然开始质疑这种说法的真实性。"
    translate None leos_chapter3_1250:
        "\"带走那孩子然后处理掉\"，母亲这样命令道，\"这种小事总能办到吧？"
    translate None leos_chapter3_1251:
        "她说话时语气冰冷无情，而那位名叫妮娅的女子就躺在几步之外，鲜血正在流失。"
    translate None leos_chapter3_1252:
        "直到今天，莱奥斯仍记得她的眼睛。金色的、宽恕的、没有一丝愤怒。她用给予赦免般的眼神望着莱奥斯。"
    translate None leos_chapter3_1253:
        "他不由自主地别开了视线。"
    translate None leos_chapter3_1254:
        "没有守卫或仆人阻拦他闯入并带走王子的幼子。所有人都在这场骚乱中忙得不可开交。"
    translate None leos_chapter3_1255:
        "他抱着婴儿穿过凛冽的空气，腰间匕首微微晃动。"
    translate None leos_chapter3_1256:
        "满头棕发。两颗小痣。夺目的金橙色眼瞳。"
    translate None leos_chapter3_1257:
        "这位小王子，本该命中注定成为未来的国王。"
    translate None leos_chapter3_1258:
        "莱奥斯注视得越久，决心就动摇得越厉害。"
    translate None leos_chapter3_1259:
        lmn "如果连这个都做不到…他们会很失望……"
    translate None leos_chapter3_1260:
        "他单手握住匕首，但终究无济于事。随着沉闷的落地声，匕首摔落地面，而他将婴儿更紧地搂在胸前。"
    translate None leos_chapter3_1261:
        "孩子没有哭闹，只是用那双大眼睛安静地仰望着莱奥斯。"
    translate None leos_chapter3_1262:
        lmn "我该怎么办…带回去的话会有别人处置他，但我也无处藏匿一个婴儿……"
    translate None leos_chapter3_1263:
        "他在漆黑的街道上匆忙穿行，绝望地寻找着提示。任何线索都好。"
    translate None leos_chapter3_1264:
        "走啊走啊，街道逐渐荒无人烟。当他来到城镇另一端时，发现自己站在从未涉足之地。"
    translate None leos_chapter3_1265:
        "羞耻感吞噬了他。如果连唯一的使命都完不成，他活着还有什么价值？"
    translate None leos_chapter3_1266:
        "这些忧虑本不该属于他这个年纪—他自己也不过是个孩子。"
    translate None leos_chapter3_1267:
        "他坐在人行道边缘，抬头望着月亮。他将婴儿紧紧搂在怀里保暖，但那孩子始终没有发出一点声音。"
    translate None leos_chapter3_1268:
        "身后突然传来开门声。"


    scene bg aureliacavellanight:
        xpos 0.6 ypos 1.18 xanchor 0.5 yanchor 1.0 zoom 1.41
    show cleo n dark sad at slightleft:
        zoom 0.82
    show matron dark clo at slightright
    with dissolve
    translate None leos_chapter3_1269:
        ma "……小男孩，你还好吗？"
    translate None leos_chapter3_1270:
        l "..."
    translate None leos_chapter3_1271:
        show cleo n sur with dis
        "莱奥斯转头看向她。他不习惯被人直接搭话，更害怕在这里被发现后会带来的后果。"
    translate None leos_chapter3_1272:
        ma "你怀里抱着的是……？"
    translate None leos_chapter3_1273:
        l "这是…"
    translate None leos_chapter3_1274:
        "他掀开襁褓，将婴儿展示给那位面露忧色的老妇人看。"
    translate None leos_chapter3_1275:
        ma "....."
    translate None leos_chapter3_1276:
        show cleo n sad with dis
        l "他……如果没人收留的话，他会死的。"
    translate None leos_chapter3_1277:
        show matron ope with dis
        ma "卡斯皮安，这次你到底做了什么……"
    translate None leos_chapter3_1278:
        ma "把孩子交给我吧。我保证他在我这里会很安全。这里是个孤儿院。"
    translate None leos_chapter3_1279:
        l "不行……绝对不能让人知道他的身份，不然……我父母会找到他的……"
    translate None leos_chapter3_1280:
        "莱奥斯将裹在襁褓中的婴儿递过去，随后局促地后退。"
    translate None leos_chapter3_1281:
        show matron ang with dis
        ma "……你也不安全，对吧？最好也一起进来—"
    translate None leos_chapter3_1282:
        show cleo n sur with dis
        l "不……不行！我不能，否则……否则我又要受罚了……！我得走了！"
    translate None leos_chapter3_1283:
        ma "等等—"


    scene bg aureliacavellanight with swipeleft
    play sound "sounds/sfx/runningstreet.ogg"
    translate None leos_chapter3_1284:
        "话音未落，莱奥斯便隐入阴影，朝着家的方向狂奔而去。"
    translate None leos_chapter3_1285:
        lmn "……我会说是自己做的。他们永远不必知道真相。"

    window hide dissolve

    scene bg sv room night with Fade(1.0, 1.0, 1.0):
        xpos 0.6 ypos 1.12 xanchor 0.5 yanchor 1.0 zoom 1.35
    window show dissolve
    $ about_Leos._text.append("莱奥斯年幼时，曾奉命处置皇太子的儿子……也就是我。但他却将我留在孤儿院交给女院长照顾，自己假装完成任务逃走了。")


    if achievement.has("leos_baby"):
        pass
    else:
        $ renpy.display_notify("成就解锁：婴儿王子")

    python:
        achievement.grant("leos_baby")
        achievement.sync()
    translate None leos_chapter3_1286:
        rs wsur "你……你{a=set_entry:enc_people->about_Leos}{color=#87CEEB}救过{/color}{/a}我的命……？"
    translate None leos_chapter3_1287:
        l wsur "直到我们找到卡斯皮安，我才知道原来是你。"
    translate None leos_chapter3_1288:
        l "对不起……我本该早点告诉你，只是—"
    translate None leos_chapter3_1289:
        rs wsad "谢谢你……莱奥斯，这份恩情我永远都报答不完，对吧？"
    translate None leos_chapter3_1290:
        "我张开双臂抱住这个红发少年，将他紧紧搂住。"
    translate None leos_chapter3_1291:
        l "我只是……很抱歉没能为你母亲做些什么。"
    translate None leos_chapter3_1292:
        "我摇摇头，泪水已在眼角积聚。"
    translate None leos_chapter3_1293:
        rs "原来从一开始就在保护我的人，是你啊？"
    translate None leos_chapter3_1294:
        l wneublu "……嗯，算是吧。"
    translate None leos_chapter3_1295:
        stop music fadeout 3.0
        "我们就这么相拥着，渐渐进入梦乡。"

    window hide dissolve

    scene black with eye_shut
    pause 2.0

    scene bg sv room day with eye_open:
        xpos 0.6 ypos 1.12 xanchor 0.5 yanchor 1.0 zoom 1.35
    window show dissolve
    translate None leos_chapter3_1296:
        "窗外鸟雀的啁啾声将我唤醒，和煦的晨风令人瞬间感到安心。"
    translate None leos_chapter3_1297:
        "我睁开眼，映入眼帘的是深红色和苍白的、光滑肌肤。是莱奥斯。"
    translate None leos_chapter3_1298:
        play music "sounds/bgm/Discovery.ogg" fadein 2.0
        "我微笑着伸出手，用手指梳理他的头发，享受发丝划过掌心的触感。"
    translate None leos_chapter3_1299:
        "他睡眼惺忪地半挂着笑容，将脸贴向我的手心，眼睛仍紧闭着。"
    translate None leos_chapter3_1300:
        rs wsmi "早安，莱奥斯。"
    translate None leos_chapter3_1301:
        l wsur "嗯…"
    translate None leos_chapter3_1302:
        "当我试图抽回手时，他又轻轻顶了回来。"
    translate None leos_chapter3_1303:
        rs "大清早就这么粘人…"
    translate None leos_chapter3_1304:
        l "还算好啦。想象下我要是赛恩会怎样。"
    translate None leos_chapter3_1305:
        rs whap "哈哈哈…完全无法把你和他性格联系起来…"
    translate None leos_chapter3_1306:
        rs wsmi "来嘛，试试看。"
    translate None leos_chapter3_1307:
        l wsmu "咳咳…\"哇，莱奥斯，你又高又帅，简直是最棒的！\""
    translate None leos_chapter3_1308:
        rs "哈哈哈…说来好笑，我还真能想象他说这话的样子…"
    translate None leos_chapter3_1309:
        rs wsad "..我想他们了。"
    translate None leos_chapter3_1310:
        l wneu "无论如何我都要救他们。"
    translate None leos_chapter3_1311:
        rs wsmi "…我们一起去。"
    translate None leos_chapter3_1312:
        l wsmu "好。"
    translate None leos_chapter3_1313:
        rs wsad "不过首先…得说服埃利奥特。"
    translate None leos_chapter3_1314:
        l "躺在床上可说服不了他。知道了知道了，这就起来。"
    translate None leos_chapter3_1315:
        "寒气逼人，起床尤为困难，但我们俩还是设法收拾好了散落的衣物并穿上身。"
    translate None leos_chapter3_1316:
        "我望向敞开的窗户。此刻天色已亮，村庄正慢慢苏醒。"
    translate None leos_chapter3_1317:
        "他们看起来就是普通人。他们说话的方式，走路的姿态…"
    translate None leos_chapter3_1318:
        "想到这里，我关上窗户，随莱奥斯离开房间。"

    window hide dissolve

    jump SV_morning


label leos_sv_scenes:
    translate None leos_chapter3_1319:
        "片刻之后，我与莱奥斯独处。"
    translate None leos_chapter3_1320:
        rs c wsur "那两人有点怪，你不觉得吗…？"
    translate None leos_chapter3_1321:
        l c wneu "谁？伊尔兰和维拉斯？"
    translate None leos_chapter3_1322:
        rs "嗯…你觉得他们在吵架？"
    translate None leos_chapter3_1323:
        l "…不清楚。昨晚他…这么说吧，他应该开始意识到这是追求维拉斯最后的机会了。"
    translate None leos_chapter3_1324:
        rs "所以…他们没结婚，但男方想结？"
    translate None leos_chapter3_1325:
        l c wsur "天晓得。他能处理好的，一向如此。"
    translate None leos_chapter3_1326:
        l "更重要的是，西尔维尔打算怎么考验我们？"
    translate None leos_chapter3_1326b:
        rs "毫无头绪"

    scene bg sv day:
        xpos 0.09 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 2.02
    show sylvir n neu at slightright
    show leos nw neu cloak at left
    show raen nw sur cloak at slightleft
    with dissolve
    translate None leos_chapter3_1327:
        s "你们来得正好。"
    translate None leos_chapter3_1328:
        l "你们也是。"
    translate None leos_chapter3_1329:
        rs "…听卡斯皮安说，埃利奥特把决定权交给你了。"
    translate None leos_chapter3_1330:
        s "他都告诉你们了？也罢。事实如此。"
    translate None leos_chapter3_1331:
        show leos nw pis with dis
        l "除了全知全能的神明威胁着我们，你们还想知道什么？我不确定你们怎么想，但这足够让人警醒了。"
    translate None leos_chapter3_1332:
        show raen nw sad with dis
        rs "莱奥斯…"
    translate None leos_chapter3_1333:
        l "什么？这是真的。"
    translate None leos_chapter3_1334:
        show sylvir n shy with dis
        s "…我并不反对你，只是让你知道。"
    translate None leos_chapter3_1335:
        s "我和这里的其他人不同。我并不完全认同他们决定隐居山中的选择。但即便如此，我也不会强迫埃利奥特做任何事，除非确实值得他花费时间。"
    translate None leos_chapter3_1336:
        rs "为什么他如此坚持自己无法帮忙？"
    translate None leos_chapter3_1337:
        s "你应该听说过\"勇敢者埃利奥特\"吧？生前的英雄，那也是人们记住他的原因。"
    translate None leos_chapter3_1338:
        s "但人们没有提及的是战争的残酷。他麾下的士兵追随他时遭遇了惨烈死亡。他只是害怕自己的决定会让他人付出生命代价。"
    translate None leos_chapter3_1339:
        show sylvir n neu with dis
        rs "你不能责怪他有这样的感受，对吧…我甚至无法想象那是什么感觉。"
    translate None leos_chapter3_1340:
        l "那么我们只需要向他证明这件事值得冒险。你想从我们这里得到什么？"
    translate None leos_chapter3_1341:
        s "不多。只是一场小小的比试。"
    translate None leos_chapter3_1342:
        show raen nw sur with dis
        rs "你想…打架？"
    translate None leos_chapter3_1343:
        s "我想要确认，如果我正冲向死亡，至少我所追随的人知道该怎么握剑。"


    if iv_scene_three and illranveras_friend >= 5:
        $ iv_scene_four = True
        jump illranverasscene4

    else:
        jump leosraen3cont


label leosraen3cont:
    translate None leos_chapter3_1344:
        l "呃，他连左右都分不清，所以和他打没意义。"
    translate None leos_chapter3_1345:
        rs "嘿！我才没！"
    translate None leos_chapter3_1346:
        show leos nw smu with dis
        l "是吗？除非你看着自己的手。"
    translate None leos_chapter3_1347:
        show raen nw sad with dis
        rs "...."
    translate None leos_chapter3_1348:
        s "…你觉得这话能安慰我吗？"
    translate None leos_chapter3_1349:
        l "所以我在这里。来和我打吧。"
    translate None leos_chapter3_1350:
        s "嗯…"
    translate None leos_chapter3_1351:
        show sylvir n smi with dis
        s "好吧，我同意。"

    hide sylvir
    hide leos
    with dissolve
    #show raen at slightleft with move
    show morwen n sur cloak at slightright with dissolve
    translate None leos_chapter3_1352:
        mor "这里发生了什么？"
    translate None leos_chapter3_1353:
        show raen nw neu with dis
        rs "他们准备打架。"
    translate None leos_chapter3_1354:
        mor "什么？！"
    translate None leos_chapter3_1355:
        s neu "别这么说。这只是友好切磋。"
    translate None leos_chapter3_1356:
        show morwen n sad with dis
        mor "小心点…我不想看到你受伤。"
    translate None leos_chapter3_1357:
        s shy "..."
    translate None leos_chapter3_1358:
        "她转过头去，我发誓我看见她脸颊上泛起淡淡的红晕。"
    translate None leos_chapter3_1359:
        "西尔维尔从斗篷下抽出一把银色长刀。刀刃在阳光下闪烁，看起来被保养得极好。"
    translate None leos_chapter3_1360:
        l c wsmu "不错的武器。"
    translate None leos_chapter3_1361:
        s neu "父亲送的礼物。"
    translate None leos_chapter3_1362:
        show raen nw sur with dis
        rs "你是怎么把它带到这里来的？"
    translate None leos_chapter3_1363:
        s smi "埃利奥特第一次救我后发现了它，一直保管在这里直到我最终回来。很幸运对吧？"
    translate None leos_chapter3_1364:
        l "看起来是的。"
    translate None leos_chapter3_1365:
        "作为回应，莱奥斯抽出了自己的剑—卢修斯扔给他的那把。"
    translate None leos_chapter3_1366:
        "不过我好奇他是怎么找到带有莱奥斯家徽的剑…"
    translate None leos_chapter3_1367:
        "没有任何预警，她左手持刀猛然突进，向他横斩而去。他踉跄后退，勉强避开刀锋。"
    translate None leos_chapter3_1368:
        l c wpis "嘿！这太卑鄙了！"
    translate None leos_chapter3_1369:
        show raen nw smi with dis
        rs "你不是告诉我在战斗中耍阴招是好事吗？"
    translate None leos_chapter3_1370:
        l "……闭嘴。"
    translate None leos_chapter3_1371:
        show morwen n smi with dis
        "他们两人激烈交锋，当刀刃相擦时，我发誓能看到火花四溅。"
    translate None leos_chapter3_1372:
        "我转身不再看他们，决定和莫温聊聊天，她正在我身边为西尔维尔鼓掌喝彩。"
    translate None leos_chapter3_1373:
        show raen nw sur with dis
        rs "我不知道她竟然会打架。"
    translate None leos_chapter3_1374:
    #show morwen n smi with dis
        mor "我也很惊讶。我想当她决定独自离开托根来到维迪斯时，她父母一定告诉过她需要学会自卫。"
    translate None leos_chapter3_1375:
        mor "毕竟独自穿越山岭，深入峡谷，探索从未有人涉足的区域，实在是危险重重。"
    translate None leos_chapter3_1376:
        rs "有道理…她真的非常了不起。"
    translate None leos_chapter3_1377:
        mor "而且还是仅用左臂。"
    translate None leos_chapter3_1378:
        rs "什么..？"
    translate None leos_chapter3_1379:
        "终于，我看清了。她用单臂作战，而我原以为藏在斗篷下的另一只手臂其实根本不存在。"
    translate None leos_chapter3_1380:
        rs "…我明白了。这就是她为获得人类身体付出的代价吗？从她开始绘制地图时就…"
    translate None leos_chapter3_1381:
        mor "没错。虽然有点讽刺—她新学会用左手的熟练程度，和她以前用右手时完全一样。"
    translate None leos_chapter3_1382:
        show raen nw smi with dis
        rs "她真厉害。"
    translate None leos_chapter3_1383:
        mor "可不是吗？"
    translate None leos_chapter3_1384:
        "莫温戴着皮手套掩嘴轻笑，目光投向仍在与莱奥斯激烈对战的西尔维尔，那种狠劲让我怀疑她是不是想下杀手。"
    translate None leos_chapter3_1385:
        mor "你该感到自豪。他可是在与神明抗衡。"
    translate None leos_chapter3_1386:
        rs "他确实不可思议。"
    translate None leos_chapter3_1387:
        mor "看来你们俩和好了？"
    translate None leos_chapter3_1388:
        rs "……是啊，和好了。"
    translate None leos_chapter3_1389:
        mor "真高兴听你这么说。干得好，雷恩。"
    translate None leos_chapter3_1390:
        "战斗持续进行，直到两人都气喘吁吁精疲力竭。双方势均力敌。"
    translate None leos_chapter3_1391:
        s smi "令人印象深刻。作为人类，你比我预期的更强。"
    translate None leos_chapter3_1392:
        l c wsmu "哈。等我赢了再说这话。"
    translate None leos_chapter3_1393:
        s smi "不必了。我相信你已经证明了自己的立场。今晚我会和你一起去见埃利奥特。"
    translate None leos_chapter3_1394:
        show morwen n sur with dis
        mor "原来是为了这个？"
    translate None leos_chapter3_1395:
        "莫温惊讶得张大了嘴。"
    translate None leos_chapter3_1396:
        s neu "我不是无缘无故挑起争斗。只是想确认这些人是否值得追随，仅此而已。"
    translate None leos_chapter3_1397:
        mor "噢，西尔维尔！我就知道能指望你！"
    translate None leos_chapter3_1398:
        hide morwen
        hide raen
        with dissolve
        "莫温冲了过去，她的手臂轻而易举地环抱住那个比她高的女人。西尔维尔像雕像般僵立着，双臂垂在身侧，仿佛不确定是否应该回抱莫温。"
    translate None leos_chapter3_1399:
        s shy "..."
    translate None leos_chapter3_1400:
        s "没关系，别担心这个。反正他可能根本就不会听。"
    translate None leos_chapter3_1401:
        mor c smi "我敢肯定他会听你的！"
    translate None leos_chapter3_1402:
        "莫温看起来随时准备把西尔维尔抱起来转圈，但最终她还是松开了手，后退了一步。"
    translate None leos_chapter3_1403:
        "我走在莱奥斯身旁，当他擦拭额头时拍了拍他的背。"
    translate None leos_chapter3_1404:
        stop music fadeout 3.0
        rs c wsmi "干得好。你看上去真的很酷。"

    if caspianaemylromance >= 2 and ca_scene_one == True:
        $ ca_scene_two = True
        jump caspianaemylscene2
    else:
        scene bg sv sunset with dis3:
            xpos 0.09 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 2.02
        play music "sounds/bgm/night.ogg" fadein 3.0
        jump raenaemylsv




























    #
