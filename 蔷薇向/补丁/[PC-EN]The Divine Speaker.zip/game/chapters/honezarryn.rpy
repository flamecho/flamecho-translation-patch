label honezarryn:
    scene bg bakery with dissolve:
        xpos 0.23 ypos 1.35 xanchor 0.5 yanchor 1.0 zoom 1.55
        linear 30.0 xpos 0.77 ypos 1.35 xanchor 0.5 yanchor 1.0 zoom 1.55
    window show dissolve
    translate None honezarryn_0001:
        "我们被新鲜出炉的面包香气迎接，引得我们垂涎欲滴。面包店里几乎空无一人，只有一位顾客站在柜台旁，等待他的食物被打包。"
    translate None honezarryn_0002:
        "他身材娇小，白色的头发带着粉红色发梢。如预期般，他的衣服很精致，上面有美丽的花卉图案。"
    translate None honezarryn_0003:
        "柜台后面，霍恩完成了这位顾客的食物准备，转身就要离开。他的目光与我的相遇，但我们谁都没有说话。"
    translate None honezarryn_0004:
        "大大的红色眼睛，宽大而天真，与他脸上那个占据大部分面积的黑色威严面具形成鲜明对比。"


    scene bg bakery
    show hone n smi at right
    show raen nw sur at center

    if cyne_route:
        show cyne nw neu at left
        with dissolve
        translate None honezarryn_0005:
            h "雷恩，赛恩！你们来得比我预想的要早。"


    if leos_route:
        show leos nw neu at left
        with dissolve
        translate None honezarryn_0006:
            h "雷恩和…我们见过吗？你们来得比我预想的要早。"
        translate None honezarryn_0007:
            rs "抱歉，希望我们没有带来太多麻烦。啊，对了，这位是莱奥斯。"


    if fawn_route:
        show fawn nw neu at left
        with dissolve
        translate None honezarryn_0008:
            h "雷恩，福恩！你们来得比我预想的要早。"


    if fawn_route or cyne_route:
        translate None honezarryn_0009:
            rs "抱歉，希望我们没有带来太多麻烦。"

    translate None honezarryn_0010:
        h "完全没有。请坐。你们很容易就找到我了吗？"


    if leos_route:
        translate None honezarryn_0011:
            h "还有莱奥斯，很高兴认识你。"

    translate None honezarryn_0012:
        rs "我们没遇到任何麻烦。"
    translate None honezarryn_0013:
        "我们在一张桌子旁坐下，霍恩坐在我们两人对面。我们寒暄了几句，轻松地聊了一会儿，然后转向正事。"
    translate None honezarryn_0014:
        show raen nw neu with dis
        rs "那么…你真的认识卡斯皮安？"
    translate None honezarryn_0015:
        "他点点头，脸上带着淡淡的微笑。"
    translate None honezarryn_0016:
        h "他是我多年的老主顾了。那个高个子棕头发的，对吧？你们打听他的事我不意外。你们是想要他的木工制品吗？"
        show raen nw sur


    if cyne_route:
        show cyne nw sur
        with dis

    if leos_route:
        show leos nw sur
        with dis

    if fawn_route:
        show fawn nw sur
        with dis
        translate None honezarryn_0017:
            rs "他的…什么？"

    translate None honezarryn_0018:
        show hone n hap with dis
        $ about_Caspian._text.append("据霍恩所说，卡斯皮安现在在锡德卡汉开了间小木工店。这真的是我们要找的那个人吗？")
        h "他是{a=set_entry:enc_people->about_Caspian}{color=#87CEEB}技艺精湛的木匠{/color}{/a}，在这不远处经营着一家小店。"
    translate None honezarryn_0019:
        show raen nw sad with dis
        "奥雷利亚卡维拉的王子…只是个普通木匠？这真的是我们要找的那个人…？"


    if cyne_route:
        show cyne nw smi with dis
        translate None honezarryn_0020:
            c "啊哈哈..这下有趣了！木匠？被你发现了。我们确实需要一张新桌子，明白吗？能给我们指个方向吗？"


    if leos_route:
        translate None honezarryn_0021:
            l "你是认真的吗？好吧，没问题，我们确实急需一张新桌子。现在能给我们指个方向吗？"


    if fawn_route:
        translate None honezarryn_0022:
            f "你能给我们指个方向吗？找到他对我们非常重要。就像你说的…呃…我们需要他的…特殊才能。"


    show hone n smi with dis
    translate None honezarryn_0023:
        h "我可以，没问题。"

    hide cyne
    hide raen
    hide leos
    hide fawn
    hide hone
    with dissolve

    show illran n neu at center
    show veras n smi1 at right
    show zarryn n neu at left
    with dissolve
    translate None honezarryn_0024:
        "突然，前门被猛地推开，走进来三个人。其中两个我认识，还有一个从未见过的粉红长发陌生人。"
    translate None honezarryn_0025:
        rs wsur "维拉斯，伊尔兰！噢，真高兴又见到你们…这位是…？"
    translate None honezarryn_0026:
        "他们在桌旁坐下，霍恩迅速起身将门上的招牌翻转过来，表明店铺已打烊。"


    if leos_route:
        translate None honezarryn_0027:
            l wann "诸神啊，请赐予我度过此劫的力量。"
        translate None honezarryn_0028:
            show illran n fli with dis
            i "莱奥斯！想我了吗？"
        translate None honezarryn_0029:
            l "不，完全不想。半点都不想。我都想不出该用什么词来形容我有多{i}不{/i}想你。"
        translate None honezarryn_0030:
            i "还在玩欲擒故纵是吧？好吧，我可想你了！"


    translate None honezarryn_0031:
        h smi "呃，我想厨房那边需要我帮忙。待会儿再跟你详谈，雷恩。"
    translate None honezarryn_0032:
        "他向陌生男子挥手致意，对方只是点了点头。他们显然早就认识。"
    translate None honezarryn_0033:
        show illran n hap with dis
        i "给你介绍我的挚友，我喜欢叫他扎林。"
    translate None honezarryn_0034:
        show zarryn n ang with dis
        z "……那就是我真名，蠢货。"
    translate None honezarryn_0035:
        i "对啊，所以我才喜欢这么叫你。仔细想想很合理吧。"


    if leos_route:
        translate None honezarryn_0036:
            l wann "哇哦，这笑话真棒。你酝酿多久了？"
        translate None honezarryn_0037:
            i "一周吧，前后差个几天。"

    translate None honezarryn_0038:
        show zarryn n ann with dis
        z "....."
    translate None honezarryn_0039:
        show zarryn n neu with dis
        z "我猜你是雷恩。那么你是…？"


    if cyne_route:
        translate None honezarryn_0040:
            c wsur "等等…你就是{b}那个{/b}扎林？事情越来越有意思了。国王的御医竟然卷入神学这种丑闻？"
        translate None honezarryn_0041:
            show zarryn n pen with dis
            z "……年轻的西纳库洛斯大人。终于…有幸亲眼见到您了。"


    if leos_route:
        translate None honezarryn_0042:
            l wneu "我叫莱奥斯。"
        translate None honezarryn_0043:
            z "莱奥斯，对。从奥雷利亚卡维拉来的那个。"
        translate None honezarryn_0044:
            "莱奥斯瞪向伊尔兰，后者只是耸了耸肩。"


    if fawn_route:
        translate None honezarryn_0045:
            f wsmi "……我叫福恩。"
        translate None honezarryn_0046:
            z "啊，所以你就是福恩。很好，很好。感谢你临时抽空来见我。"

    translate None honezarryn_0047:
        z "看来需要做些自我介绍…首先，我是锡德卡汉领主的皇家御医，但这个职位给了我某些…特殊权限。"
    translate None honezarryn_0048:
        z "随心所欲进行研究。我将大部分时间都投入学术事务，自认为是神学与恶魔学领域的专家。"
    translate None honezarryn_0049:
        show zarryn n ang with dis
        z "当然，这种行为很不受待见，所以希望你能保守秘密。"
    translate None honezarryn_0050:
        rs wsur "我自然不会告诉任何人。"
    translate None honezarryn_0051:
        "神学…恶魔学…？啊？"
    translate None honezarryn_0052:
        $ about_Zarryn.locked = False
        v "…{a=set_entry:enc_people->about_Zarryn}{color=#DA70D6}扎林{/color}{/a}研究恶魔与神明已有多年，我们实在想不出第二个人能比他对诺克斯和索伦更有帮助"
    translate None honezarryn_0053:
        z "诚然。平时我不会答应这种事，但可惜由于我与某人的…交情，实在别无选择"
    translate None honezarryn_0054:
        "伊尔兰咧嘴笑着靠在椅背上，双臂交叉抱在胸前"


    if leos_route:
        translate None honezarryn_0055:
            l wneu "谁能想到呢"

    translate None honezarryn_0056:
        rs wsad "他情况如何？醒来了吗？"


    show zarryn n neu with dis
    translate None honezarryn_0057:
        z "..还没有。生命体征稳定但昏迷不醒。初步检测一切正常—各项指标都在健康范围，呼吸平稳，没有内伤，只是陷入沉睡"
    translate None honezarryn_0058:
        z "能否强行唤醒？或许可以，但在找出分离恶魔的方法前我不会尝试"


    if cyne_route:
        translate None honezarryn_0059:
            c wneu "这真的可行吗？"


    if leos_route:
        translate None honezarryn_0060:
            l wneu "这种事当真可能实现？"

    translate None honezarryn_0061:
        z "…别抱太大希望。我从未见过这种案例—两个存在体在灵魂层面如此紧密交融…即便能分离，他们还能保持完整吗？现在我也说不准"
    translate None honezarryn_0062:
        rs wsad "...."
    translate None honezarryn_0063:
        show zarryn n pen with dis
        z "但并非全无希望。只是我一向不愿在风险明显时假装万事大吉"
    translate None honezarryn_0064:
        z "我把索伦安置在实验室，在弄清他们融合的本质并找到灵魂分离方法前都会留他在这里。具体需要多久无法预计，不过他俩在我这里很安全"
    translate None honezarryn_0065:
        rs wsad "…感激不尽。虽然认识索伦不久…但…我真心想救他…"
    translate None honezarryn_0066:
        rs "原来光有救人的心意远远不够。所以，他拜托你了"


    if cyne_route:
        translate None honezarryn_0067:
            c wneu "那么…你如何辨认恶魔？"
        translate None honezarryn_0068:
            z "根据他们力量的不同，会有各种不同的征兆。有时可能是眼睛变黑或长出尖牙，有时则表现得更不明显。"
        translate None honezarryn_0069:
            z "年轻的爵爷，我怀疑您的社交圈里会遇到很多恶魔。"
        translate None honezarryn_0070:
            c wsmi "哈！这你可就错了。不管他们是否想要我的血，那里的恶魔数量多到你数不清。"
        translate None honezarryn_0071:
            show zarryn n smi with dis
            z "…好吧，这话确实难以反驳。有人会说在锡德凯厄姆高阶家族间周旋，比任何恶魔都要致命得多。"
        translate None honezarryn_0072:
            "…自从来到这里后，他总是这样。贬低身边的人。某种程度上，他也在说他自己。"
        translate None honezarryn_0073:
            "究竟发生了什么让他变得如此…疏离？我一直以为他是那么自信的人。"


    if leos_route:
        translate None honezarryn_0074:
            l "你以前对付过这样的恶魔吗？"
        translate None honezarryn_0075:
            z "没有像他这么特别的。我也不敢说我在实验室里关过这种。不过，只有他觉醒时我才有危险，而看起来短期内不会发生。"
        translate None honezarryn_0076:
            l wthi "好吧…老实说他的死活我根本不在乎…"
        translate None honezarryn_0077:
            "他用眼角余光瞥了我一眼。"
        translate None honezarryn_0078:
            l wneu "..但是，为了他好，我希望你能帮帮他。"
        translate None honezarryn_0079:
            rs wsad "莱奥斯…"
        translate None honezarryn_0080:
            "我感到自己艰难地咽了口唾沫。他可不像会因为我在意某件事就跟着在意的人…"
        translate None honezarryn_0081:
            "等等…真的不像吗？他一直陪着我到现在，救我性命，帮我寻找卡斯皮安…不求任何回报。"
        translate None honezarryn_0082:
            "难道他一直都是在为我做这些？"


    if fawn_route:
        translate None honezarryn_0083:
            f wsad "你…你对恶魔很了解？"
        translate None honezarryn_0084:
            z "要说\"很\"是相当主观的，但我对这个课题确实很有信心。"
        translate None honezarryn_0085:
            f "…如果你遇到一个恶魔要怎么分辨？他们…他们自己会知道吗？"
        translate None honezarryn_0086:
            z "你是在问一个人可能在不知情的情况下成为恶魔吗？"
        translate None honezarryn_0087:
            f "..."
        translate None honezarryn_0088:
            "扎林沉默了片刻，陷入沉思。"
        translate None honezarryn_0089:
            show zarryn thi with dis
            z"..我想这并非不可能。寄宿在人体内的恶魔会像人类一样容易受到许多疾病的影响，取决于他们的力量等级。失忆虽然罕见，但完全有可能。"
        translate None honezarryn_0090:
            "这些是…相当尖锐的问题。他到底想说什么？"

    translate None honezarryn_0091:
        "没等我再问其他问题，门突然被推开了。"
    translate None honezarryn_0092:
        "又一个人走了进来。是刚才那个年轻人。"

    hide veras with dissolve
    show titus n sur mask at right with dis:
        xpos 0.93 ypos 1.0 xanchor 1.0 yanchor 1.0
    translate None honezarryn_0093:
        u "师傅，您在这儿吗？"
    translate None honezarryn_0094:

        "他的目光扫过桌边众人，看到扎林时立即快步走到他身旁。"
    translate None honezarryn_0095:
        show titus n ann with dis
        "没过多久他注意到了伊尔兰，猛地向后跳开，活像只对狗呲牙的猫。"
    translate None honezarryn_0096:
        u "你…你，来这里干什么？我警告过你别再纠缠我家主人！"
    translate None honezarryn_0097:
        show illran n armsdown fli with dis
        i "哟看看这是谁，那个小鬼。你叫啥来着？小气鬼？连片刻都离不开你亲爱的扎林吗？"
    translate None honezarryn_0098:
        show titus at shake
        u "混账你…!!!"
    translate None honezarryn_0099:
        show zarryn n neu with dis
        z "提图斯，冷静。你知道我现在正在协助他们处理些事情。"
    translate None honezarryn_0100:
        show titus n sad with dis
        tit "但为什么偏偏是他？！他…他对您如此粗鲁无礼！就是个惹事精！"
    translate None honezarryn_0101:
        i "别太抬举我，我会骄傲的。"


    if leos_route:
        translate None honezarryn_0102:
            l wsmu "你有跟谁相处得来吗？"
        translate None honezarryn_0103:
            i "嗯…维拉斯算不算？"
        translate None honezarryn_0104:
            l "不是。"
        translate None honezarryn_0105:
            i "那没有。"

    translate None honezarryn_0106:
        v neu "伊尔兰、提图斯，都先冷静。我们刚刚正在讨论索伦的事。"
    translate None honezarryn_0107:
        v smi "你也在协助监视他对吧？"
    translate None honezarryn_0108:
        show titus n neu with dis
        "他对提图斯笑了笑，对方立刻放松下来。看来是维拉斯的崇拜者，却讨厌伊尔兰…倒也不难理解。"
    translate None honezarryn_0109:
        tit "没错。要知道，他可是个怪胎。"
    translate None honezarryn_0110:
        rs wsad "…我明白…"
    translate None honezarryn_0111:
        z "…既然我亲爱的侄子决定抛弃礼节，就由我来介绍吧。"
    translate None honezarryn_0112:
        $ about_Titus.locked = False
        z "这位是我的助手，{a=set_entry:enc_people->about_Titus}{color=#DA70D6}提图斯{/color}{/a}。在我进行研究期间，将由他负责看护索伦并确保其健康状况。"


    if cyne_route:
        translate None honezarryn_0113:
            "他点头致意，随后将目光投向赛恩和我。"


    if leos_route:
        translate None honezarryn_0114:
            "他点头致意，随后将目光投向莱奥斯和我。"

    translate None honezarryn_0115:
        rs wneu "…可以叫我雷恩。"


    if fawn_route:
        translate None honezarryn_0116:
            f wsad "..福恩。"
        translate None honezarryn_0117:
            "福恩似乎对介绍环节已兴致缺缺。"



    if cyne_route:
        translate None honezarryn_0118:
            c wneu "….叫我赛恩就行。"
        translate None honezarryn_0119:
            show titus n sur with dis
            tit "哦，赛恩是…伯爵夫人之子？"
        translate None honezarryn_0120:
            c wang "...."
        translate None honezarryn_0121:
            rs wsur "伯爵夫人？"
        translate None honezarryn_0122:
            tit "人人都知道她！维蒙德家族的女主人，绰号\"伯爵夫人\"，以—"
        translate None honezarryn_0123:
            $ about_LV._text.append("据提图斯所说，维蒙德女士亦被称为\"伯爵夫人\"，且极其冷酷无情。看来她确实名声在外。")
            c "因为她是个{a=set_entry:enc_people->about_LV}{color=#87CEEB}冷酷无情{/color}{/a}的人。是的，没错，她是我母亲。如果就这些的话，我现在不想谈论她。"
        translate None honezarryn_0124:
            "赛恩的视线落在地面上，眉头紧锁。感觉到空气中的紧张气氛，我试图把注意力引到自己身上。"


    if leos_route:
        translate None honezarryn_0125:
            l wneu "莱奥斯，如果你非要问的话。"
        translate None honezarryn_0126:
            tit "莱奥斯…莱奥斯…你又是哪个来着…"
        translate None honezarryn_0127:
            show titus n sur with dis
            tit "噢！对了，我想起来了！那个又高又古板的家伙！"
        translate None honezarryn_0128:
            l wann "...."
        translate None honezarryn_0129:
            i "哎呀，我刚刚是这么形容他的吗？"
        translate None honezarryn_0130:
            l "你给我等着…"


    if cyne_route or leos_route:
        translate None honezarryn_0131:
            rs wsad "…啊哈哈…很高兴认识你，提图斯。谢谢你帮助索伦。"
        translate None honezarryn_0132:
            show titus n hap with dis
            tit "没什么。为了主人我什么都愿意做。"
        translate None honezarryn_0133:
            "主人长主人短的…"


    show titus n neu with dis
    translate None honezarryn_0134:
        z "好了，如果关于索伦的话题暂时告一段落，我想说说别的。雷恩。"
    translate None honezarryn_0135:
        rs wsur "我？"
    translate None honezarryn_0136:
        show zarryn n ang with dis
        z "…我从伊尔兰那里听说过一些你的事。我就不重复那些传说了，相信你已经听过无数遍，但这个城市已经很久没出现过像你这样的人了。"
    translate None honezarryn_0137:
        z "来自一个被认为是神话的城市的奇怪诅咒…与说书人本人的联系…你简直像是从童话里走出来的人物。"
    translate None honezarryn_0138:
        z "这座城市的每个人都会踩着别人的尸体来争夺你。你是个谜团，是隐藏的王牌，是将军绝杀。你必须小心。"


    if cyne_route:
        translate None honezarryn_0139:
            c wang "得了吧…没那么严重吧？"
        translate None honezarryn_0140:
            z "…围在你身边的人正是我最担心的，大人。"
        translate None honezarryn_0141:
            c "…什么？"
        translate None honezarryn_0142:
            z "你心里清楚我在说什么。"
        translate None honezarryn_0143:
            c "..."
        translate None honezarryn_0144:
            c "…我不会让任何人碰他。"
        translate None honezarryn_0145:
            "扎林点点头，但脸上写满怀疑。"
        translate None honezarryn_0146:
            z "…希望你是对的。"


    if leos_route:
        translate None honezarryn_0147:
            l wneu "只要我还活着，就没人能动他一根汗毛。"
        translate None honezarryn_0148:
            show illran n fli with dis
            i "天啊，干脆求婚算了。我都能想象你们的誓词了。"
        translate None honezarryn_0149:
            i "{i}\"小不点，我发誓只要我活着，就没人能动你\"{/i}。多浪漫啊！"
        translate None honezarryn_0150:
            show zarryn n neu with dis
            z "听你这么说我很高兴。锡德卡汉是个很棒的城市，但你不能小觑这里的居民。"


    if fawn_route:
        translate None honezarryn_0151:
            f wneu "…我不会让任何人伤害他。我会保护他。"
        translate None honezarryn_0152:
            "扎林点点头，对福恩的回答感到满意。"
        translate None honezarryn_0153:
            z "你有一颗坚强的心。我希望它能支撑你们完成旅程，最终仍能完好如初。"



    translate None honezarryn_0154:
        i "好了，我的任务完成了。我想我没义务继续留在这里了吧？"
    translate None honezarryn_0155:
        v smi "我们暂且告辞。雷恩，我们很快会再来找你。虽然我们已履行约定将索伦安全送达，但我们俩还有更多事要商议。"
    translate None honezarryn_0156:
        v "不过那是后话了。"
    translate None honezarryn_0157:
        v fro1 "……锡德卡汉上空笼罩着乌云，但我不知其意。请务必小心，时刻保持警惕。现在不是轻信任何人的时候。"
    translate None honezarryn_0158:
        "临行前，提图斯把维拉斯拉到一旁低语片刻，递给他一张纸条后便放他离去。"
    translate None honezarryn_0159:
        hide illran with dissolve
        show zarryn n neu with dis
        z "我要和霍恩谈些事情。你能暂时接替一下吗？"
    translate None honezarryn_0160:
        hide zarryn with dissolve
        "他望向提图斯，对方自豪地点点头。扎林很自然地起身离开我们这桌，走向霍恩所在的里屋。"




    if cyne_route:
        show raen nw neu at center
        show cyne nw neu at left
        with dissolve
        translate None honezarryn_0161:
            tit "所以你真的是赛恩…？"
        translate None honezarryn_0162:
            show cyne nw ang with dis
            c "...."
        translate None honezarryn_0163:
            c "有什么问题吗？"
        translate None honezarryn_0164:
            show titus n sur with dis
            tit "不，不，只是久闻大名而已。你和我想象中不太一样。"
        translate None honezarryn_0165:
            c "那你到底想象我是什么样？"
        translate None honezarryn_0166:
            tit "这个…我以为你会更…"
        translate None honezarryn_0167:
            show raen nw sur with dis
            c "更怎样？更高大，更粗犷？有话直说。更像个耻辱？"
        translate None honezarryn_0168:
            tit "我不是—"
        translate None honezarryn_0169:
            c "算了。雷恩，你完事后外边见。"
        translate None honezarryn_0170:
            rs "等等，赛恩—"

        play sound "sounds/sfx/slam.ogg" fadein 1.0
        hide cyne with dissolve
        show raen at slightleft
        show titus at slightright
        with move
        translate None honezarryn_0171:
            "随着\"砰\"的关门声，赛恩怒气冲冲出了房间。"
        translate None honezarryn_0172:
            show raen nw sad with dis
            rs "...."

        stop music fadeout 2.0
        window hide dissolve

        scene bg sc day with dissolve
        window show dissolve
        translate None honezarryn_0173:
            "金发少年愤恨地踢着地面，身后的门重重关上。"
        translate None honezarryn_0174:
            show cyne nw cloak sad with dissolve
            c "呃…"
        translate None honezarryn_0175:
            play music "sounds/bgm/creepy.ogg" fadein 2.0
            cmn "为什么人们就不能管好自己？总在我面前窃窃私语议论纷纷…"
        translate None honezarryn_0176:
            cmn "为什么连单纯存在都要遭受评判？"
        translate None honezarryn_0177:
            show veras n sur1 at right
            show illran n neu at left
            with dissolve
            v "赛恩…？"
        translate None honezarryn_0178:
            c "……你还杵在这儿干嘛？我没心情。"
        translate None honezarryn_0179:
            v "我们正要走。出什么事了吗？"
        translate None honezarryn_0180:
            c "一切好得很，谢谢关心。"
        translate None honezarryn_0181:
            show veras n sad1 with dis
            v "……有什么我能帮忙的？"
        translate None honezarryn_0182:
            c "我说了—"
        translate None honezarryn_0183:
            show illran n con with dis
            i "还不明显吗？虽然和他母亲一个模子刻出来的，却最恨被拿来比较—"
        translate None honezarryn_0184:
            show cyne nw ang at shake
            c "闭嘴！关你什么事？！"
        translate None honezarryn_0185:
            "赛恩一把抓住伊尔兰的衣领，将两人的脸拉近。他露出了笑容，这只会火上浇油。"
        translate None honezarryn_0186:
            i "哦，这与我无关。我只是在旁观而已。"
        translate None honezarryn_0187:
            c "那就别插手我的事！也许你觉得戳我的痛处很有趣，但我已经受够了。"
        translate None honezarryn_0188:
            c "我不是…我不是她…我永远不想成为她那样的人！"
        translate None honezarryn_0189:
            show illran n neu with dis
            "他脸上的笑容消失了，伊尔兰挣脱了赛恩的掌控。"
        translate None honezarryn_0190:
            i "很好。那就别让那些无关紧要的人的风言风语影响你。"
        translate None honezarryn_0191:
            i "走吧，维拉斯。我们还有地方要去。"
        translate None honezarryn_0192:
            v "……保重，赛恩。"
        translate None honezarryn_0193:
            hide illran
            hide veras
            with dissolve
            "两人消失在面包店外。"
        translate None honezarryn_0194:
            show cyne nw sad with dis
            "赛恩站在原地，思考着伊尔兰的话。"

        stop music fadeout 2.0
        window hide dissolve

        scene bg bakery
        show raen nw sad at slightleft
        show titus n sur mask at slightright
        with dissolve
        window show dissolve
        translate None honezarryn_0195:
            rs "等等，赛恩—"
        translate None honezarryn_0196:
            "随着\"砰\"的关门声，赛恩怒气冲冲出了房间。"
        translate None honezarryn_0197:
            rs "...."
        translate None honezarryn_0198:
            show titus n sad with dis
            play music "sounds/bgm/Discovery.ogg" fadein 2.0
            tit "我…我根本不是那个意思…"
        translate None honezarryn_0199:
            rs "……我一会儿就去找他。你是有特别的事情吗？"
        translate None honezarryn_0200:
            tit "我只是有些问题想问…你们真的来自奥雷利亚卡维拉？"
        translate None honezarryn_0201:
            show raen nw sur with dis
            rs "是的。那地方在斯塔格威奇附近的森林深处。"

        show titus n sur with dis


    if leos_route:
        show raen nw neu at center
        show leos nw neu at left:
            xpos 0.03 ypos 1.0 yanchor 1.0
        with dissolve
        show titus n sur with dis
        translate None honezarryn_0202:
            tit "你们俩真的来自奥雷利亚卡维拉！？我能问些问题吗？"
        translate None honezarryn_0203:
            l "如果你非要问的话。"
        translate None honezarryn_0204:
            show raen nw sur with dis
            rs "是的。那地方在斯塔格威奇附近的森林深处。"


    if fawn_route:
        show raen nw neu at center
        show fawn nw neu at left:
            xpos 0.03 ypos 1.0 yanchor 1.0
        with dissolve
        translate None honezarryn_0205:
            tit "那么…雷恩和…福恩？这名字真奇怪，不过无所谓。你们真的来自奥雷利亚卡维拉？"
        translate None honezarryn_0206:
            rs "是的。那地方在斯塔格威奇附近的森林深处。"



    translate None honezarryn_0207:
        tit "斯塔格威奇附近？比我想象的要远得多…多么惊人的发现啊！我多希望能亲自去看看那座城镇。"
    translate None honezarryn_0208:
        tit "一个与外界完全隔绝的文明是如何发展的？你们做事的方式肯定和我们很不同吧。啊，我得把这些都记下来…"
    translate None honezarryn_0209:
        "他拿出笔记本开始疯狂书写，记录下我说的每一句话。就像扎林一样，他一定自认为是某种学者吧。"


    if cyne_route or leos_route:
        translate None honezarryn_0210:
            rs "那你呢？你来自锡德卡汉？"


    if fawn_route:
        show fawn sur with dis
        translate None honezarryn_0211:
            f "……你呢？你一直住在锡德卡汉吗？"


    show titus n neu with dis
    translate None honezarryn_0212:
        "他抬手摸了摸面具，保持沉默。"


    if fawn_route:
        show fawn sad with dis
    $ about_Titus._text.append("提图斯的家乡在他年幼时被烧毁了，因此他才会和扎林一起住在锡德卡汉。")
    translate None honezarryn_0213:
        tit "……不，但我的家乡已经什么都不剩了。它和其他几间房屋一起被{a=set_entry:enc_people->about_Titus}{color=#87CEEB}烧毁{/color}{/a}了。"
    translate None honezarryn_0214:
        tit "人们仍住在那里，但那个令它成为我家的东西已不复存在。"


    if fawn_route:
        translate None honezarryn_0215:
            "我不知道那是何时发生的，但我注意到福恩正紧紧抓着我衬衫的后背。"


    if leos_route or cyne_route:
        show raen nw emb with dis
        translate None honezarryn_0216:
            "我尴尬地挠了挠我的手背。也许我不该问这个问题。"


    if leos_route:
        translate None honezarryn_0217:
            tit "莱奥斯，我也可以问你几个问题吗？你在奥雷利亚卡维拉做了什么？"
        translate None honezarryn_0218:
            show leos nw thi with dis
            l "好像你也没给我机会说不…呃…我…"
        translate None honezarryn_0219:
            "他皱起眉头，似乎在犹豫要不要说出实情，但最终叹了口气耸耸肩。"
        translate None honezarryn_0220:
            l "我是个杀手。"
        translate None honezarryn_0221:
            show titus n sur with dis
            tit "一名刺客？太惊人了！我很想知道在这种小镇上刺客能有多大用处。"
        translate None honezarryn_0222:
            show leos nw neu with dis
            l "用处大着呢，相信我。"
        translate None honezarryn_0223:
            tit "真令人吃惊！让我把这个记下来…"
        translate None honezarryn_0224:
            show leos nw sur with dis
            l "你不害怕我吗？"
        translate None honezarryn_0225:
            show titus n neu with dis
            tit "我的人头有悬赏吗？"
        translate None honezarryn_0226:
            l "呃，据我所知没有。"
        translate None honezarryn_0227:
            tit "那我就不算什么了！我知道像你这样的人总有自己的一套荣誉准则，对吧？你不会无缘无故杀人的。"
        translate None honezarryn_0228:
            l "...."


    show titus n sur with dis
    translate None honezarryn_0229:
        tit "啊对了，得问问你住在哪里。要是我们得知有关索伦的新消息，我会到我师父那儿找你！"
    translate None honezarryn_0230:
        show raen nw neu with dis
        rs "银柳，离这儿并不远。"
    translate None honezarryn_0231:
        tit "好，好，知道了。"
    translate None honezarryn_0232:
        "他继续在本子上涂涂写写做着记录。我几乎觉得自己在被审问。"
    translate None honezarryn_0233:
        tit "如果你不介意的话，我能看一下你的神之刻印吗？"


    if leos_route:
        translate None honezarryn_0234:
            "莱奥斯皱起眉头，但仍保持至寂。"


    window hide

    menu:
        "我看不出有什么不行":
            window show dissolve
            jump honezarrynchoice1

        "我还是不要了":
            window show dissolve
            jump honezarrynchoice2

label honezarrynchoice1:
    show raen nw sur with dis
    translate None honezarryn_0235:
        rs "我看不出有什么不行。给。"
    translate None honezarryn_0236:
        "我卷起袖子，提图斯立即抓住我的手臂检查那些神之刻印。他用手指沿着刻印描摹了几次，然后重新拿起笔记本开始画草图。"
    translate None honezarryn_0237:
        tit "我本职是个炼金术士兼治疗师，但忍不住对大多数历史和神话感兴趣。看样子…这些符文恐怕有数百年，甚至上千年的历史…"
    translate None honezarryn_0238:
        tit "无论在文化还是语言方面…这段文字都具有重要意义…我曾在古籍和卷轴上见过类似的神之刻印，但从未见过任何译文…嗯…"
    translate None honezarryn_0239:
        tit "也许…不，或许不是…除非…？"
    translate None honezarryn_0240:
        "他喃喃自语，陷入自己的思绪。我觉得从他那儿问不出什么有用的东西。"

    jump honezarrynchoicedone

label honezarrynchoice2:
    show raen nw sad with dis
    translate None honezarryn_0241:
        rs "呃..其实，我…还是不要了。"
    translate None honezarryn_0242:
        "我将手臂收回，朝扎林离开的方向瞥了一眼。他不是刚警告我要小心吗？"
    translate None honezarryn_0243:
        "这条警告也适用于他和提图斯吗？"


    if leos_route:
        translate None honezarryn_0244:
            l "明智之选。"

    translate None honezarryn_0245:
        tit "...."
    translate None honezarryn_0246:
        tit "好吧好吧，我明白了。不过等这一切结束后，请允许我研究它。"
    translate None honezarryn_0247:
        "…结束？"
    translate None honezarryn_0248:
        show raen nw smi with dis
        rs "…懂了。"

    jump honezarrynchoicedone

label honezarrynchoicedone:
    if leos_route:
        translate None honezarryn_0249:
            l "…接下来的事你能处理吧？我有要事在身。"
        translate None honezarryn_0250:
            show raen nw sur with dis
            rs "等…等等！"
        translate None honezarryn_0251:
            show leos nw neu with dis
            l "什么事？"
        translate None honezarryn_0252:
            "他还是决定单独去找伊尔兰谈话了…"
        translate None honezarryn_0253:
            show raen nw sad with dis
            rs "…不，没关系…"
        translate None honezarryn_0254:
            show leos nw thi with dis
            l "别离开面包店，好吗？如果…如果那个传言属实，我不放心让你独自乱跑。"
        translate None honezarryn_0255:
            "那些梦境，被人跟踪的感觉…"
        translate None honezarryn_0256:
            rs "好吧…."
        translate None honezarryn_0257:
            hide leos with dissolve
            show titus at slightright
            show raen at slightleft
            with move
            "不容争辩地，他径直离开了面包店，门扉紧闭时铃铛发出忧伤的叮咚声。"
        translate None honezarryn_0258:
            rs "....."



    translate None honezarryn_0259:
        tit "那么，如果我没听错，你不只是来送索伦的吧？"
    translate None honezarryn_0260:
        show raen nw sad with dis
        rs "我在找一个对我至关重要的人，或许他能解答我…必须破解的疑问。"
    translate None honezarryn_0261:
        show titus n sur with dis
        tit "原来如此…唔…"
    translate None honezarryn_0262:
        tit "你这经历堪称史诗啊？充满刺激与绝望，诅咒与恶魔，神话与传说。我迫不及待想看到这个故事的结局。"
    translate None honezarryn_0263:
        show titus n smi with dis
        tit "事实上，我想跟你做个交易！"
    translate None honezarryn_0264:
        "呃哦…"
    translate None honezarryn_0265:
        tit "就像我完美无缺的主人那样，我对历史也产生了兴趣。你知道，太多事迹被湮没遗忘，而我要尽力阻止这种情况。"
    translate None honezarryn_0266:
        tit "或许我的兴趣更在于记录当下会发生的事件。"
    translate None honezarryn_0267:
        show raen nw sur with dis
        rs "你到底…想说什么？"
    translate None honezarryn_0268:
        tit "终有一日，让我来书写你的故事吧！"
    translate None honezarryn_0269:
        rs "我的故事？比起刚才在场的所有人，我恐怕是最无趣的那个…"
    translate None honezarryn_0270:
        tit "那各自保留意见吧。好好考虑。"


    if cyne_route:
        translate None honezarryn_0271:
            "赛恩会怎么想？"


    if leos_route:
        translate None honezarryn_0272:
            "…莱奥斯会怎么想？他肯定觉得这很蠢，对吧？"


    if fawn_route:
        translate None honezarryn_0273:
            "我望向福恩，他却只是耸了耸肩。"

    translate None honezarryn_0274:
        rs "我…不介意。这样吧，如果你愿意回答几个问题，我就答应。"
    translate None honezarryn_0275:
        tit "问吧，我知无不言。"



label honezarrynchoice3:

    if titus_count == 4:
        jump honezarrynchoice3done

    window hide

    menu:
        "你认识伊尔兰吗？" if titus_illran:
            window show dissolve
            $ titus_count += 1
            $ titus_enough = True
            $ titus_illran = False
            $ illranveras_friend += 1
            jump titus_illranask

        "你和维拉斯是朋友？" if titus_veras:
            window show dissolve
            $ titus_count += 1
            $ titus_enough = True
            $ titus_veras = False
            $ illranveras_friend += 1
            jump titus_verasask

        "扎林和霍恩什么关系？" if titus_zarryn:
            window show dissolve
            $ titus_count += 1
            $ titus_enough = True
            $ titus_zarryn = False
            jump titus_zarrynzask

        "你刚才提到家乡…" if titus_home:
            window show dissolve
            $ titus_count += 1
            $ titus_enough = True
            $ titus_home = False
            jump titus_homeask

        "问够了" if titus_enough:
            window show dissolve
            jump honezarrynchoice3done


label titus_illranask:
    show raen nw sur with dis
    translate None honezarryn_0276:
        rs "所以你和伊尔兰—"
    translate None honezarryn_0277:
        show titus n neu with dis
        tit "光是听到他的名字就让我作呕…"
    translate None honezarryn_0278:
        show raen nw smi with dis
        rs "哈，你们关系很差？"
    translate None honezarryn_0279:
        show titus n ann with dis
        tit "谁能做到？！说实话，维拉斯还愿意跟着他真是他的福气。我真不知道他是怎么留住维拉斯的。"
    translate None honezarryn_0280:
        show raen nw sur with dis
        rs "你们之间…发生过什么事吗？"
    translate None honezarryn_0281:
        tit "不是我，是我师父。你知道为什么我们宁愿冒险也要帮助他吗？除了好奇心之外？"
    translate None honezarryn_0282:
        tit "基本上就是敲诈勒索。"
    translate None honezarryn_0283:
        rs "敲诈…？听起来确实很伊尔兰作风啊。"
    translate None honezarryn_0284:
        "我饶有兴致地听着，提图斯继续讲述他的故事。"
    translate None honezarryn_0285:
        show titus n neu with dis
        tit "这就是他惯用的手段。挖掘本该埋葬的秘密，然后用来谋取私利。"
    translate None honezarryn_0286:
        tit "几年前发生的事，他突然出现在我们家门口，硬闯进来还反客为主。"
    translate None honezarryn_0287:
        tit "我本来打算叫卫兵逮捕他，但师父想先听听他要说什么。你真该看看当时师父的脸色…瞬间惨白如纸，还命令我离开房间。"
    translate None honezarryn_0288:
        rs "他跟师父说了什么？"
    translate None honezarryn_0289:
        show titus n sur with dis
        tit "我完全不知道！没人肯告诉我！"
    translate None honezarryn_0290:
        $ about_Zarryn._text.append("伊尔兰掌握了扎林的把柄，迫使这个绿发男人不得不配合他，尽管心里厌恶。")
        tit "但是…从那以后…他就能{a=set_entry:enc_people->about_Zarryn}{color=#87CEEB}大摇大摆{/color}{/a}地随时登门提要求！要我说，就该直接把他轰出去。泄露一两个秘密算什么？"
    translate None honezarryn_0291:
        "没错，这确实是伊尔兰的作风。"

    jump honezarrynchoice3

label titus_verasask:
    translate None honezarryn_0292:
        "我在想…他知道维拉斯是神吗？要不我还是别提这事为妙。"
    translate None honezarryn_0293:
        show raen nw neu with dis
        rs "你对…维拉斯了解多吗？你们看起来相处得不错。"
    translate None honezarryn_0294:
        "听到我的问题，他突然来了精神。"
    translate None honezarryn_0295:
        show titus n smi with dis
        tit "维拉斯是我的榜样！他思想前卫，始终走在医术前沿。他能想出我做梦都想不到的治疗方法。"
    translate None honezarryn_0296:
        tit "有时候我很好奇他怎么积累这么多知识…我活十辈子都赶不上他的学识。"
    translate None honezarryn_0297:
        "…看来他们不知道。我会保密的。"
    translate None honezarryn_0298:
        show raen nw sur with dis
        rs "唔…没想到他自认为是医者。"
    translate None honezarryn_0299:
        show titus n neu with dis
        tit "十年前我们初见时我还小。那时我刚搬到锡德卡汉，师父收留了我。"
    translate None honezarryn_0300:
        show titus n sad with dis
        tit "我们只是偶然相遇，纯粹是运气。我当时感到…很迷茫，不知所措。我想知道自己是否能达到师父的期望，成为…他能耐的一半都好。"
    translate None honezarryn_0301:
        tit "我连最基本的药水或药膏都调配不好。正想着要逃跑放弃时，他在街头发呆的我找到了。"
    translate None honezarryn_0302:
        tit "当我告诉他后，他指出了我的错误所在。那些错误太明显了，真是让人难为情。"
    translate None honezarryn_0303:
        tit "…但我永远都感激不尽。没有他的指导，就不会有现在的我。"
    translate None honezarryn_0304:
        rs "…那时的他很不同吗？"
    translate None honezarryn_0305:
        show titus n neu with dis
        tit "嗯…"
    translate None honezarryn_0306:
        tit "从前…是的，我记得。他一向友善温和，我甚至可以说他是无私的。"
    translate None honezarryn_0307:
        tit "但…就像他周围筑起了看不见的墙。既不让别人靠近，也不让自己对任何人太过依恋。"
    translate None honezarryn_0308:
        "我想起我认识的维拉斯。那么温暖，让人安心的人…"
    translate None honezarryn_0309:
        tit "现在他的笑容能直达眼底。虽然这话说来让人难受，但我想这改变是因为伊尔兰。"
    translate None honezarryn_0310:
        rs "那两人形影不离。"
    translate None honezarryn_0311:
        tit "…被迫分离时不会更加痛苦吗？"


    if fawn_route:
        translate None honezarryn_0312:
            f "...?"


    if leos_route or cyne_route:
        translate None honezarryn_0313:
            rs "....?"

    translate None honezarryn_0314:
        tit "啊，算了。"

    jump honezarrynchoice3

label titus_zarrynzask:
    show raen nw sur with dis
    translate None honezarryn_0315:
        rs "扎林一进来霍恩就迅速关了店门。这种事经常发生吗？"
    translate None honezarryn_0316:
        show titus n neu with dis
        tit "说经常可能有点过了，但确实时有发生。尽管外表看起来不像，但他们的交情比我能记住的年头还长。"
    translate None honezarryn_0317:
        rs "哈，这确实像是个不可能存在的友谊。"
    translate None honezarryn_0318:
        show titus n sad with dis
        tit "我一直告诉他，把这段关系发展成友谊之外的机会越来越渺茫了，但他总是挥挥手不让我说下去。你看，他很容易害羞。"
    translate None honezarryn_0319:
        rs "哦-哦，原来是这么回事？"
    translate None honezarryn_0320:
        tit "他说不是，但我又不瞎。"

    jump honezarrynchoice3

label titus_homeask:
    show raen nw neu with dis
    translate None honezarryn_0321:
        rs "你提到过你的家乡，对吧？那是哪里？"

        show titus n neu with dis
        if fawn_route:
            translate None honezarryn_0322b:
                "提图斯低下头，嘟囔着说他的镇子被一场大火烧毁了。"
        else:
            $ about_Cliffspire.locked = False
            translate None honezarryn_0322:
                tit "是南方一个叫{a=set_entry:enc_places->about_Cliffspire}{color=#DA70D6}克利夫斯派尔{/color}{/a}的小镇。我…火灾后再没回去过，但听说他们把烧毁的一切都重建了。"
    translate None honezarryn_0323:
        show raen nw sad with dis
        rs "很遗憾听到这件事…火灾是怎么发生的？"
    translate None honezarryn_0324:
        show titus n sad with dis
        tit "我…我当时还小，但是…人们说是一只恶魔为惩罚而烧毁了那里。死了很多人…"
    translate None honezarryn_0325:
        tit "不过我并没有亲眼目睹灾后的情景。我被带到了锡德卡汉。"


    if fawn_route:
        translate None honezarryn_0326:
            f  "....."

    translate None honezarryn_0327:
        rs "诸神啊…我相信那个…不，那个纵火的东西一定得到了应有的报应。"
    translate None honezarryn_0328:
        tit "除此以外我不敢奢望其他。"

    jump honezarrynchoice3

label honezarrynchoice3done:

    if cyne_route:
        translate None honezarryn_0329:
            show raen nw sad with dis
            rs "还有一件事…"
        translate None honezarryn_0330:
            "我的目光迅速瞥向赛恩几分钟前站立的位置。"
        translate None honezarryn_0331:
            rs "这个\"女伯爵\"是怎么回事？"
        translate None honezarryn_0332:
            show titus n sur with dis
            tit "你真的不知道？等等，你当然不知道。"
        translate None honezarryn_0333:
            tit "…她外表完全符合人们对贵族的期待。完美的礼仪，完美的外貌，但是…"
        translate None honezarryn_0334:
            tit "关起门来…谁都知道她有多残酷。甚至可以说心狠手辣。妨碍她的人？都会失踪。"
        translate None honezarryn_0335:
            tit "她可以得到任何想要的东西和人。"
        translate None honezarryn_0336:
            show raen nw sur with dis
            rs "他父亲呢？"
        translate None honezarryn_0337:
            tit "…我不清楚。他很少公开露面。"


    if leos_route:
        translate None honezarryn_0338:
            show raen nw sad with dis
            rs "其实…关于伊尔兰…"
        translate None honezarryn_0339:
            rs "你知道他来自哪里吗？"
        translate None honezarryn_0340:
            tit "…他肯定在这里住了好几年了，但我听说他出生在很远的城市。" # MISSING LINE
        translate None honezarryn_0341:
            "莱奥斯到底想要从他那里得到什么…"


    translate None honezarryn_0342:
        "还没等我再问什么，厨房门突然打开，霍恩和扎林同时出现了。"
    translate None honezarryn_0343:
        show titus n hap with dis
        tit "主人！"


    if fawn_route:
        translate None honezarryn_0344:
            "福恩凑近我耳边低声说。"
        translate None honezarryn_0345:
            f "在我们再被打断前，应该问问卡斯皮安的事。"


    if leos_route or cyne_route:
        translate None honezarryn_0346:
            "在再次被打断前，我该问问卡斯皮安的事…"


    if fawn_route:
        translate None honezarryn_0347:
            show raen nw sur blush with dis
            "我感到呼吸一滞。我们的脸近在咫尺。"
        translate None honezarryn_0348:
            show fawn nw sur blush with dis
            "当他注意到这一点时，立即弹开了。"
        translate None honezarryn_0349:
            rs "对-对！霍恩，我们能再谈谈卡斯皮安吗？"


    if cyne_route:
        translate None honezarryn_0350:
            "…我还想去找赛恩。"


    if leos_route:
        translate None honezarryn_0351:
            "然后…我想就是等着莱奥斯出现吧。"


    if leos_route or cyne_route:
        show raen nw sur with dis
        translate None honezarryn_0352:
            rs "我能多问些关于卡斯皮安的事吗？"


    translate None honezarryn_0353:
        h sur "抱歉，让你久等了吧？"


    if fawn_route:
        translate None honezarryn_0354:
            f "我们在哪里能找到他？"

    if leos_route or cyne_route:
        translate None honezarryn_0355:
            rs "我在哪里能找到他？"


    translate None honezarryn_0356:
        h smi "离这不远。往西走上台阶，沿着路走一会儿就能轻易找到。那里叫\"月蚀\"。"


    if fawn_route:
        translate None honezarryn_0357:
            show fawn neu -blush with dis
            f "对一个木工坊来说真是个好听的名字…"


    if leos_route or cyne_route:
        translate None honezarryn_0358:
            rs "多美的名字啊…"


    translate None honezarryn_0359:
        h "他也不愿谈论这个名字。一问就会闭口不言。"
    translate None honezarryn_0360:
        h "我猜是献给某个逝去的爱人之类的。"
    translate None honezarryn_0361:
        "我在脑海中反复默念着方向，确保把它们牢牢记在心里。先向西走几步，然后沿着大路…"
    translate None honezarryn_0362:
        show raen nw sad with dis
        rs "他…他终于离得这么近了…我简直不敢相信…"
    translate None honezarryn_0363:
        h "…我知道你想要的不仅是他做家具的手艺。希望他能告诉你你在寻找的东西。"
    translate None honezarryn_0364:
        h "我想见到你他会很兴奋的。"
    translate None honezarryn_0365:
        show raen nw sur with dis
        rs "....?"
    translate None honezarryn_0366:
        "他把招牌翻转过来，店铺重新开始营业了。"
    translate None honezarryn_0367:
        z neu "既然那个烦人的家伙已经走了，你们俩想去见见索伦吗？"


    if cyne_route:
        translate None honezarryn_0368:
            rs "两个人？"
        translate None honezarryn_0369:
            z "你可以去接小少爷了。"


    if leos_route:
        translate None honezarryn_0370:
            "..莱奥斯让我待在这里，但是…反正也不是我一个人，对吧？扎林和提图斯会保护好我的。"
        translate None honezarryn_0371:
            rs "真的可以吗？"


    if fawn_route:
        show raen nw sur -blush with dis
        translate None honezarryn_0372:
            rs "我们可以？"


    translate None honezarryn_0373:
        z "我没意见。我宁愿你能完全放心把他交给我。"
    translate None honezarryn_0374:
        z "提图斯，我们走吧。"
    translate None honezarryn_0375:
        tit "再见，霍恩。再次感谢你之前的面包。"
    translate None honezarryn_0376:
        h smi "好好享用。扎林，我也给你多放了一点。"
    translate None honezarryn_0377:
        z smi "….谢谢。"
    translate None honezarryn_0378:
        "简单点头示意后，我们便出了门。"

    window hide dissolve

    scene bg sc day with dissolve:
        xpos 0.48 ypos 1.53 xanchor 0.5 yanchor 1.0 zoom 1.56
    window show dissolve

    if cyne_route:
        translate None honezarryn_0379:
            "赛恩靠在面包店门外的墙上，双臂交叉抱在胸前。看到我们出来后，他向我走来。"
        translate None honezarryn_0380:
            c c wsad "…抱歉，我刚才情绪失控了。"
        translate None honezarryn_0381:
            rs c wneu "没关系。我要和扎林去见索伦。你想一起来还是等着？"
        translate None honezarryn_0382:
            c "我跟你们一起去。我不会再让类似的事情发生。"
        translate None honezarryn_0383:
            "去扎林书房的路程轻快而安静，我们四人之间只有寥寥数语。"


    if leos_route:
        translate None honezarryn_0384:
            "我的目光扫过霍恩面包店外的白色街道，却不见莱奥斯和伊尔兰的踪影。"
        translate None honezarryn_0385:
            "沮丧之下，我重重地叹了口气，引得提图斯转头看我。"
        translate None honezarryn_0386:
            tit neu "感情问题？"
        translate None honezarryn_0387:
            rs c wsur "什么？"
        translate None honezarryn_0388:
            tit "不是吗？我不知道，只是觉得你们在一起时似乎有种特别的火花。"
        translate None honezarryn_0389:
            "火花…"
        translate None honezarryn_0390:
            "..为什么我们分开时，我的胸口会这么疼？"
        translate None honezarryn_0391:
            "去扎林书房的路程轻快而安静，我们三人之间只有寥寥数语。"



    if fawn_route:
        translate None honezarryn_0392:
            "去扎林书房的路程轻快而安静，我们四人之间只有寥寥数语。"


    translate None honezarryn_0393:
        "路程并不远。那栋建筑与周围的房屋融为一体，看不出任何特别之处。没人能猜到里面囚禁着一个恶魔。"
    translate None honezarryn_0394:
        "提图斯打开房门为我们撑着门，映入眼帘的是扎林的研究实验室。"

    stop music fadeout 2.0
    window hide dissolve

    scene bg zarryn with dissolve:
        xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.55
        linear 23.0 xpos 0.5 ypos 1.55 xanchor 0.5 yanchor 1.0 zoom 1.55
    window show dissolve
    translate None honezarryn_0395:
        rs wsur "哇…"
    translate None honezarryn_0396:
        z neu "来吧，随便坐，我去把壁炉点着。"
    translate None honezarryn_0397:
        tit hap "让我来！"
    translate None honezarryn_0398:
        "提图斯手忙脚乱地往空壁炉里塞木柴，很快点燃了火。屋子里充满暖意和松木的清香。"
    translate None honezarryn_0399:
        play music "sounds/bgm/forgotten off.ogg" fadein 2.0
        rs "索伦在哪？"
    translate None honezarryn_0400:
        z "就在那扇门后面。看完他之后过来坐坐吧，我想聊会儿。"


    if fawn_route:
        translate None honezarryn_0401:
            "我和福恩推开门，一阵凉风迎面扑来。索伦躺在一张小床上，双眼依然紧闭。"



    if cyne_route:
        translate None honezarryn_0402:
            "我和赛恩推开门，一阵凉风迎面扑来。索伦躺在一张小床上，双眼依然紧闭。 "


    translate None honezarryn_0403:
        "他的胸膛随着呼吸起伏，仿佛只是睡着了。和我们离开时一样。"
    translate None honezarryn_0404:
        "我不由松了口气—当然问题还没解决，但他没事。我可以放心把索伦交给这两个人照料。"
    translate None honezarryn_0405:
        "别担心，索伦。等你回来时，我会在这里等着你。"


    if fawn_route:
        translate None honezarryn_0406:
            f wsmi "他气色不错。我觉得他们能治好他。"
        translate None honezarryn_0407:
            rs "要说有谁能做到，就是他们了。"
        translate None honezarryn_0408:
            "我们回到沙发旁，在壁炉边取暖。扎林见此情景满意地再次开口。"

        scene bg zarryn
        show raen nw neu at farright
        show fawn nw neu at slightright
        show titus n neu mask at cenleft:
            xpos 0.36 ypos 1.0 xanchor 0.3 yanchor 1.0
        show zarryn n neu at farleft
        with dissolve

    if cyne_route:
        translate None honezarryn_0409:
            c wneu "他看起来没什么变化，不过这样也好。我想他会没事的。"
        translate None honezarryn_0410:
            rs whap "…我也这么觉得。"
        translate None honezarryn_0411:
            "我们回到沙发旁，在壁炉边取暖。扎林见此情景满意地再次开口。"

        scene bg zarryn
        show raen nw neu at farright
        show cyne nw neu at slightright
        show titus n neu mask at cenleft
        show zarryn n neu at farleft
        with dissolve

    if leos_route:
        translate None honezarryn_0412:
            rs wsmi "他确实看起来很安全…"
        translate None honezarryn_0413:
            "我回到沙发旁，在壁炉边取暖。扎林见此情景满意地再次开口。"

        scene bg zarryn
        show raen nw neu at slightright:
            xpos 0.86 ypos 1.0 xanchor 0.8 yanchor 1.0
        show titus n neu mask at center
        show zarryn n neu at slightleft:
            xpos 0.1 ypos 1.0 xanchor 0.2 yanchor 1.0
        with dissolve


    translate None honezarryn_0414:
        z "…你认为这个世界被众神遗弃了吗？"
    translate None honezarryn_0415:
        "问我是否觉得世界已被抛弃？"
    translate None honezarryn_0416:
        show raen nw sad with dis
        rs "…我不知道该相信什么了。不能责怪他们被困在无法离开的地方…"

    show zarryn n smi with dis

    if fawn_route:
        show fawn nw sad with dis
        translate None honezarryn_0417: # RETAKE
            f "…我曾经坚信我们被遗弃了。我觉得任何放任这些坏事发生的神明，都不值得我信仰…"
        translate None honezarryn_0418:
            f "但我的想法已经改变了。要说的话…我为他们感到难过。我也没法责怪他们。"


    translate None honezarryn_0419:
        "他会意地笑了，仿佛某个猜想得到了证实。"
    translate None honezarryn_0420:
        z "看来你知道的比表现出来的多。没错，你不能责怪他们，但其他存在呢？"
    translate None honezarryn_0421:
        show raen nw sur with dis
        rs "其他…存在？"
    translate None honezarryn_0422:
        z "比如诺克斯。那些占据了凡人躯体的。"
    translate None honezarryn_0423:
        "诺克斯…与其说是他抛弃了我们，不如说是我们背叛了他。对经历过如此折磨的人…确实很难加以责备。"
    translate None honezarryn_0424:
        "然后还有维拉斯…他始终没有放弃我们。我相信还有更多像他这样的人。"
    translate None honezarryn_0425:
        show raen nw sad with dis
        rs "…不，我并不认为他们放弃了。即便是…即便是诺克斯这样的人…他最终变成那样也是因为我们。"


    if fawn_route:
        translate None honezarryn_0426:
            f "...."


    translate None honezarryn_0427:
        z "有意思。单纯从事实依据来看，我本应反对你的观点，却发现不由自主地相信了你。也许，在这世界的某个角落，依然有人在守护着我们。"
    translate None honezarryn_0428:
        z "…这件事只在你我之间，但我近来确信，在锡德卡汉周边的群山中，隐藏着一个与人类世界隔绝的村庄，那些流浪的神明会在那里安度余生，远离人类的纷争。"
    translate None honezarryn_0429:
        "他从椅子上起身，滑步穿过房间，来到一个直达天花板的书架前。他从架上抽出一本书，递给忠实站在身侧的提图斯。"
    translate None honezarryn_0430:
        show zarryn n thi with dis
        z "我偶然发现了这本笔记。是著名制图师西尔维尔的原版手记。"
    translate None honezarryn_0431:
        rs "西尔维尔…？"
    translate None honezarryn_0432:
        z "她从海对岸的托根远道而来，一路来到维迪斯，只为做她最擅长的事：绘制地图。"
    translate None honezarryn_0433:
        z "日记中使用的完全是我看不懂的语言—幸好我身边带着一位非常出色的翻译家和语言学家。"

    if fawn_route:
        show fawn nw sur with dis


    translate None honezarryn_0434:
        rs "你们二位真是无所不能…"
    translate None honezarryn_0435:
        show zarryn n neu with dis
        z "只要用心去做，任何人都能做到。"
    translate None honezarryn_0436:
        z "无论如何，西尔维尔的故事大部分都不怎么精彩。除了其中一则记载，其他都是你会对旅行者产生的寻常期待。"
    translate None honezarryn_0436b:
        z "当时她正在锡德卡汉的群山中徒步，却倒在雪地里。独自旅行的她以为生命就此终结，但是…"
    translate None honezarryn_0437:
        z "醒来时，她身处一个陌生的村庄，正受到照料。她反复询问这是哪里，却没人回答她。"
    translate None honezarryn_0437b:
        show zarryn n pen with dis
        z "她的字迹开始变得凌乱，原本清晰可辨的文字也褪色模糊，但有个名字格外醒目—埃利奥特。"

    if cyne_route:
        translate None honezarryn_0439:
            show cyne nw sur with dis
            c "埃利奥特？弑神者埃利奥特？"

    if leos_route or fawn_route:
        show raen nw sur with dis
        translate None honezarryn_0440:
            rs "埃利奥特？弑神者埃利奥特？"

    translate None honezarryn_0441:
        show zarryn n neu with dis
        z "有可能，但时间线似乎对不上。埃利奥特·菲伦死在对抗说书人及其追随者的奥雷利亚战争中。西尔维尔是在那之后很久才来的。" #RETAKE NEEDED
    $ about_Sylvir.locked = False
    translate None honezarryn_0442:
        z "不论如何，最终她还是离开了—{a=set_entry:enc_people->about_Sylvir}{color=#DA70D6}蒙着眼睛{/color}{/a}，我得说明这点。他们确保她无法找到返回的路。"
    translate None honezarryn_0443:
        z "她说刚被释放时，下山途中能感觉到有人在注视自己。回头望去，树林边际有双黄色眼睛正盯着她。"
    translate None honezarryn_0444:
        $ about_SecretVillage.locked = False
        rs "那么…你觉得这就是{a=set_entry:enc_places->about_SecretVillage}{color=#DA70D6}那个村庄{/color}{/a}？"
    translate None honezarryn_0445:
        "他先是点头，最后还是耸了耸肩。"
    translate None honezarryn_0446:
        z "有这个可能。"
    translate None honezarryn_0447:
        "嗯…那种地方确实可能存在，但为什么维拉斯不选择去那里呢？"
    translate None honezarryn_0448:
        z "……我觉得耽误你太久了。长途跋涉至此，终点已近在眼前。别让我阻拦你。"


    if cyne_route:
        show cyne nw neu with dis
        translate None honezarryn_0449:
            c "等等。"
        translate None honezarryn_0450:
            c "你研究这些真的安全吗？如果国王发现—"
        translate None honezarryn_0451:
            z "他对我的研究睁只眼闭只眼，但别搞错了。跟踪调查和科学探索是两回事。"
        translate None honezarryn_0452:
            z "我是科学家。毕生所求就是学习与发现。区区几条规则阻止不了对知识的追求。" # voice map here
        translate None honezarryn_0453:
            rs "……好了赛恩，我们该走了吧？"
        translate None honezarryn_0454:
            "他点头应允，我转向扎林。"


    if fawn_route:
        show raen nw neu
        show fawn nw neu
        with dis
        translate None honezarryn_0456:
            rs "……谢谢。福恩，走吧。"




    if leos_route:
        show raen nw neu with dis
        translate None honezarryn_0457:
            rs "呃..我在想，你研究这个真的安全吗？万一他们找到索伦怎么办？"
        translate None honezarryn_0458:
            z "国王知晓我的研究范围且选择纵容。但别误会，跟踪调查和科学探索终究不同。"
        translate None honezarryn_0459:
            z "我是科学家。毕生所求就是学习与发现。区区几条规则阻止不了对知识的追求。" # voice map here
        translate None honezarryn_0459b:
            z "索伦跟着我很安全。"
        translate None honezarryn_0460:
            show raen nw smi with dis
            rs "……谢谢你扎林，这下我放心了。"



    stop music fadeout 2.0
    translate None honezarryn_0461:
        rs "请替我照顾好索伦。"
    translate None honezarryn_0462:
        show raen nw neu with dis
        "他露出微笑，提图斯将我们送至门口。道别后，我们回到了锡德卡汉的街道上。"

    window hide dissolve


    if cyne_route:
        jump cyneroute2continued2

    if leos_route:
        jump leosroute2continued2

    if fawn_route:
        jump fawnroute1continued2
