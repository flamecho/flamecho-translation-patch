label cyneroute1:
    $ cyne_route = True
    stop music fadeout 3.0
    scene bg sc sunset with fade
    window show dissolve
    translate None cyne_chapter1_0001:
        "我将身子蜷缩进外套的布料里，对这种新获得的温暖心怀感激。天气太冷了，我都不愿去想福恩和莱奥斯之前该有多冷。"
    translate None cyne_chapter1_0002:
        "我满怀感激地望向赛恩。"
    translate None cyne_chapter1_0003:
        play music "sounds/bgm/night.ogg" fadeout 2.0
        "他真是个好人。一个真正善良的人。"
    translate None cyne_chapter1_0004:
        show fawn nw sunset neu cloak at farleft
        show cyne nw sunset neu cloak at cenright
        show raen nw sunset sur cloak at cenleft
        show leos nw sunset neu cloak at farright
        with dissolve
        rs "所以…舞会？就是那种高档派对对吧？我想这可能是我们最好的选择。"
    translate None cyne_chapter1_0005:
        show fawn nw sunset sur cloak with dis
        f "我还从来没参加过舞会…"
    translate None cyne_chapter1_0006:
        show fawn nw sunset sad cloak with dis
        f "…也没参加过派对…或者说，任何社交活动…"
    translate None cyne_chapter1_0007:
        show cyne nw sunset hap with dis
        c "他们每隔几个月就会举办一次。如果你不介意那些势利的富人们，其实还挺有意思的。除了那些政治暗算什么的。"
    translate None cyne_chapter1_0008:
        show leos nw sunset smi with dis
        l "那你应该会很适应。"
    translate None cyne_chapter1_0009:
        show raen nw sunset sad
        show cyne nw sunset neu
        with dis
        rs "莱奥斯，注意礼貌。赛恩刚给我们买了这么多好东西，你还觉得可以这么无礼。"
    translate None cyne_chapter1_0010:
        rs "接着说，看来我们唯一的选择就是去参加舞会了。"
    translate None cyne_chapter1_0011:
        l "抱歉，你是耳朵不好使吗？那可是邀请制的。"
    translate None cyne_chapter1_0012:
        rs "哦…"
    translate None cyne_chapter1_0013:
        "要怎么混进舞会呢…偷偷溜进去或许可行，但似乎有点危险…要是我们有邀请函就好了。"
    translate None cyne_chapter1_0014:
        "不过话说回来，如果有机会打探到卡斯皮安的消息，任何风险都值得冒。"
    translate None cyne_chapter1_0015:
        rs "…肯定有办法能进去的。我们能不能想办法弄张邀请函？"
    translate None cyne_chapter1_0016:
        show leos nw sunset neu with dis
        l "…不是我要说难听话，但谁会邀请你这种邋里邋遢的小鬼？你只是个无名小卒。"
    translate None cyne_chapter1_0017:
        show fawn nw sunset neu with dis
        f "在我看来你{i}就是{/i}在故意说难听话。"
    translate None cyne_chapter1_0018:
        f "…我们能去门口问问吗？也许他们会直接放我们进去。"
    translate None cyne_chapter1_0019:
        show leos nw sunset thi with dis
        l "好主意啊，森林小子。这绝对不会引起任何怀疑，一点都不会。"
    translate None cyne_chapter1_0020:
        show fawn nw sunset sad with dis
        f "…对不起…"
    translate None cyne_chapter1_0021:
        show raen nw sunset neu with dis
        rs "至少你在想办法。莱奥斯，我可没听到你有什么建议。"
    translate None cyne_chapter1_0022:
        l "….那就潜入进去。翻墙，爬窗。很简单。"
    translate None cyne_chapter1_0023:
        rs "..."
    translate None cyne_chapter1_0024:
        "看来他也没提出什么有用的建议。"
    translate None cyne_chapter1_0025:
        c "…我或许能想出办法。"
    translate None cyne_chapter1_0026:
        show raen nw sunset sur with dis
        rs "真的吗？"
    translate None cyne_chapter1_0027:
        c "…我本来有张邀请函，但被禁足时立刻就被没收了。"
    translate None cyne_chapter1_0028:
        show cyne nw sunset smi with dis
        c "…不敢保证，但我会尽力。就交给你的老朋友赛恩吧！"
    translate None cyne_chapter1_0029:
        "赛恩倚靠着我笑了起来，对自己相当满意。"
    translate None cyne_chapter1_0030:
        l "那你具体打算怎么做？去求他们把邀请函还给你？"
    translate None cyne_chapter1_0031:
        c "你等着瞧吧！"
    translate None cyne_chapter1_0032:
        show leos nw sunset neu with dis
        l "好吧，太棒了。你这话现在真是让我充满信心啊。"
    translate None cyne_chapter1_0033:
        show cyne nw sunset sur with dis
        c "哎呀，莱奥斯，你不信任我吗？经历了这么多之后…我有点受伤！"
    translate None cyne_chapter1_0034:
        # added voice mapping to chapter_three_0258 - check
        l "....."
    translate None cyne_chapter1_0035:
        show fawn nw sunset sad with dis
        f "…我觉得交给赛恩处理是个好主意。他比我们任何一个人都更了解情况。"
    translate None cyne_chapter1_0036:
        show raen nw sunset smi with dis
        rs "如果赛恩同意，我没问题。"
    translate None cyne_chapter1_0037:
        show cyne nw sunset smi with dis
        c "包在我身上！"
    translate None cyne_chapter1_0038:
        rs "谢谢…只要我们有一线希望能找到关于他下落的任何信息…真的，这意义重大。"
    translate None cyne_chapter1_0039:
        hide cyne
        hide raen
        hide fawn
        hide leos
        with dissolve
        "我们四人肩并肩，继续穿行在锡德卡汉积雪的街道上。雪花从天空轻柔飘落，优雅地在我们周围舞动。"
    translate None cyne_chapter1_0040:
        "此刻太阳开始西沉，天空染上了橙红色调。阿什做这些衣服确实花了整整一天时间。"
    translate None cyne_chapter1_0041:
        "不过，可能比其他人做都要快得多。如果再遇到他，我一定要再次道谢。"
    translate None cyne_chapter1_0042:
        "行走间，莱奥斯和福恩稍微加快了脚步—留下我和赛恩并肩而行。莱奥斯狡猾地四处张望，欣赏着风景。"
    translate None cyne_chapter1_0043:
        "他和我一样入迷。"
    translate None cyne_chapter1_0044:
        "福恩毫不掩饰他的好奇。这座城市肯定与他见过的任何地方都截然不同。"
    translate None cyne_chapter1_0045:
        show cyne mw sunset cloak neu at left
        show raen mw sunset cloak hap at right
        with dissolve
        rs "我想谢谢你，赛恩。为了这些衣服，带我们来这里…为了一切。"
    translate None cyne_chapter1_0046:
        show cyne mw sunset smi with dis
        c "这是我的荣幸。虽然我很喜欢看人露点，但也不值得你们全都死于低温症。"
    translate None cyne_chapter1_0047:
        c "况且…你这样分开头发挺帅气的。我想我要坠入爱河了。"
    translate None cyne_chapter1_0048:
        rs "哈哈…真的，看起来还行吗？我感觉像个玩换装游戏的小孩…"
    translate None cyne_chapter1_0049:
        c "真的很适合你。"
    translate None cyne_chapter1_0050:
        "他对我温暖地笑了。少了平日的嬉皮笑脸。"
    translate None cyne_chapter1_0051:
        show raen mw sunset sur with dis
        rs "这料子感觉如此轻盈透气，但我却完全感觉不到寒冷…"
    translate None cyne_chapter1_0052:
        c "我不是说过他是最棒的吗？"
    translate None cyne_chapter1_0053:
        rs "你知道…他提到过你。我是说阿什。看来你给他留下了好印象。"
    translate None cyne_chapter1_0054:
        show cyne mw sunset sur with dis
        c "这可是头一回。"
    translate None cyne_chapter1_0055:
        show cyne mw sunset smi with dis
        c "开玩笑的啦。他是个好人，也是个出色的裁缝。"
    translate None cyne_chapter1_0056:
        show cyne mw sunset shy with dis
        c "但是…自从他妻子去世后，他就变了个人。"
    translate None cyne_chapter1_0057:
        show raen mw sunset sad with dis
        rs "...."
    translate None cyne_chapter1_0058:
        "我觉得我可能不该追问细节。"
    translate None cyne_chapter1_0059:
        hide raen
        hide cyne
        with dissolve
        "谈话声逐渐停歇，我们四人继续返回银柳镇的路程。很快，旅店的轮廓便映入眼帘。"
    translate None cyne_chapter1_0060:
        c c whap "嗯…我想我该走了。我不在的时候可别玩太疯！"
    translate None cyne_chapter1_0061:
        rs c wsad "你…又要走？"
    translate None cyne_chapter1_0062:
        c c wsur "雷恩，我确实有自己家。除非…你这是在邀请我？"
    translate None cyne_chapter1_0063:
        rs "房间是你付的钱，你不需要邀请也能住下。"
    translate None cyne_chapter1_0064:
        c "哎呀呀，你今天可真是主动呢。虽然很甜蜜，但如果你们明天想参加舞会，我有正事要办。"
    translate None cyne_chapter1_0065:
        "哦…"
    translate None cyne_chapter1_0066:
        "真扫兴。"
    translate None cyne_chapter1_0067:
        "等等…为什么会扫兴？他昨晚也没来啊，有什么区别？"
    translate None cyne_chapter1_0068:
        "我叹了口气，对自己的心情感到困惑。"
    translate None cyne_chapter1_0069:
        rs "当然，我早该想到的。那…明天见？"
    translate None cyne_chapter1_0070:
        l c wneu "谢谢你准备的衣服还有一切。"
    translate None cyne_chapter1_0071:
        f c wsmi "晚安，赛恩…再次感谢。"
    translate None cyne_chapter1_0072:
        "福恩对赛恩露出温暖的笑容，他也报以同样的微笑。"
    translate None cyne_chapter1_0073:
        "终于看到他们和睦相处，真好。"
    translate None cyne_chapter1_0074:
        c c wsmi "别在意。比起你的可爱模样，这点开销不值一提。"
    translate None cyne_chapter1_0075:
        f c wemb "啊…谢谢…！"
    translate None cyne_chapter1_0076:
        l "我们可以围成一圈整夜互夸，或者去睡觉。猜猜我会选哪个？"
    translate None cyne_chapter1_0077:
        l "晚安。"
    translate None cyne_chapter1_0078:
        "莱奥斯转身离去，福恩默默跟在他身后。赛恩挥手告别，脸上挂着淘气的笑容。"
    translate None cyne_chapter1_0079:
        show cyne nw sunset smi cloak at slightleft
        show raen nw sunset sad cloak at slightright
        with dissolve
        c "那么…晚安。"
    translate None cyne_chapter1_0080:
        "我还不想让他走。"
    translate None cyne_chapter1_0081:
        "今天我们甚至没机会独处…"
    translate None cyne_chapter1_0082:
        "我伸手抓住他的手腕。"
    translate None cyne_chapter1_0083:
        show raen nw sunset sur blush cloak with dis
        rs "等一下。"
    translate None cyne_chapter1_0084:
        show cyne nw sunset sur cloak with dis
        "赛恩快速转身，脸上带着讶异。"
    translate None cyne_chapter1_0085:
        c "让我猜猜。这么快分别让你难以忍受？别告诉我你已经爱上我了？"
    translate None cyne_chapter1_0086:
        "他伸手用指尖轻抚我的嘴唇调侃着。我的脸颊瞬间发烫，空闲的手不自觉地伸向他。"
    translate None cyne_chapter1_0087:
        "正当我要回应时，福恩疑惑地从门口探头望来。"
    translate None cyne_chapter1_0088:
        f c wsur "你们不冷吗？快进来啊。"
    translate None cyne_chapter1_0089:
        rs "呃…"
    translate None cyne_chapter1_0090:
        show cyne nw sunset smi cloak with dis
        "我回望赛恩，他眨着眼对我微笑。"
    translate None cyne_chapter1_0091:
        show raen nw sunset neu with dis
        rs "…我很快回来。不用等我。"
    translate None cyne_chapter1_0092:
        "福恩点点头，脸上掠过一丝落寞，随即从门口缩回了脑袋。"
    translate None cyne_chapter1_0093:
        c "啧啧，让我别等你？你整晚到底打算干什么？"
    translate None cyne_chapter1_0094:
        rs "……没什么。我只是不想你现在就走。"
    translate None cyne_chapter1_0095:
        show raen nw sunset sad cloak -blush with dis
        rs "你不觉得这有点可悲吗？我们三个住在一起，而你却孤零零的？"
    translate None cyne_chapter1_0096:
        show cyne nw sunset neu with dis
        c "至少这对我来说不是什么新鲜事。"
    translate None cyne_chapter1_0097:
        rs "什么？"
    translate None cyne_chapter1_0098:
        show cyne nw sunset smi with dis
        c "……你很可爱，知道吗？"
    translate None cyne_chapter1_0099:
        show raen nw sunset sur blush cloak with dis
        rs "什么？我才不可爱……"
    translate None cyne_chapter1_0100:
        c "那我看到的这点红晕算什么？真不知道我怎么就拐到了这么个……纯情小可爱。"
    translate None cyne_chapter1_0101:
        show raen nw sunset smi with dis
        show raen nw dark
        show cyne nw dark
        show bg sc night
        with dis3
        "当我意识到时，嘴角已不自觉上扬。身后，夕阳沉入地平线，我们被星光笼罩。"
    translate None cyne_chapter1_0102:
        c "你相信我吗？"
    translate None cyne_chapter1_0103:
        rs "当然。"
    translate None cyne_chapter1_0104:
        show cyne nw dark hap with dis
        c "先闭上眼睛。"
    translate None cyne_chapter1_0105:
        show raen nw dark sur -blush with dis
        rs "为什么？"
    translate None cyne_chapter1_0106:
        c "拜托，你刚说相信我的。"
    translate None cyne_chapter1_0107:
        rs "好吧…如果这能让你高兴的话……"
    translate None cyne_chapter1_0108:
        scene black with eye_shut
        stop music fadeout 3.0
        "按照他的要求，我闭上双眼。听到窸窣的声响，却什么都没发生。"
    translate None cyne_chapter1_0109:
        rs c wsur "赛恩…？"
    translate None cyne_chapter1_0110:
        c c whap "不准偷看！"
    translate None cyne_chapter1_0111:
        "我又等了一会儿。"
    translate None cyne_chapter1_0112:
        "….."
    translate None cyne_chapter1_0113:
        rs "你到底在—"
    translate None cyne_chapter1_0114:
        scene bg sc night at hpunch
        rs c wsur "哇啊啊啊！！！"
    translate None cyne_chapter1_0115:
        play music "sounds/bgm/Fooling Around Tiny.ogg" fadein 1.0
        c c whap "噗哈哈哈哈！噢噢，你这表情绝对值了！"
    translate None cyne_chapter1_0116:
        c "这就是轻信他人的下场！"
    translate None cyne_chapter1_0117:
        "雪块从我脸上滑进衣领，惊得我跳了起来。"
    translate None cyne_chapter1_0118:
        rs "冷死了！你发什么神经？！"
    translate None cyne_chapter1_0119:
        "赛恩笑得喘不过气。"
    translate None cyne_chapter1_0120:
        rs c wang "认真的吗？！你拿雪球砸我！"
    translate None cyne_chapter1_0121:
        c "哈哈哈哈哈哈……！"
    translate None cyne_chapter1_0122:
        c "你…你居然真的上当！"
    translate None cyne_chapter1_0123:
        rs "我以为你…我以为你要亲我！"
    translate None cyne_chapter1_0124:
        c "啊哈哈哈…啥？你不觉得这情节太浪漫了吗？"
    translate None cyne_chapter1_0125:
        rs c wemb "这样想有什么问题…？"
    translate None cyne_chapter1_0126:
        c "当然有。玩玩可以，但在飘雪的月光下接吻？噫，可不是我的风格。"
    translate None cyne_chapter1_0127:
        rs c wsad "抱歉…我—"
    translate None cyne_chapter1_0128:
        rs c wsur "哇啊！"
    translate None cyne_chapter1_0129:
        show bg sc night at hpunch
        "又一个雪球迎面飞来，这次我及时察觉。侧身躲过后，怒瞪向赛恩的方向。"
    translate None cyne_chapter1_0130:
        c c wsmi "哎呀呀，手滑了！"
    translate None cyne_chapter1_0131:
        "他再次笑弯了腰。"
    translate None cyne_chapter1_0132:
        "……这可是双人游戏。我迅速蹲下抓起一把雪。"
    translate None cyne_chapter1_0133:
        rs c wneu "看我怎么收拾你！"
    translate None cyne_chapter1_0134:
        "当他触及我的眼神，笑声戛然而止。"
    translate None cyne_chapter1_0135:
        c c wshy "糟了…等等，我们能不能好好谈谈？"
    translate None cyne_chapter1_0136:
        c "雷恩…别摆那种表情！拜托…！"
    translate None cyne_chapter1_0137:
        "一瞬间，他转身冲进了黑暗中。"
    translate None cyne_chapter1_0138:
        rs c wang "嘿…！别以为你能逃出我的手掌心！"
    translate None cyne_chapter1_0139:
        "我紧追不舍。他的速度比他看起来要快得多！"
    translate None cyne_chapter1_0140:
        c c whap "哈哈哈，看你能不能抓住我！"
    translate None cyne_chapter1_0141:
        scene black with w19
        scene bg sc night with w19
        "我扔出雪球，但轻松被他躲开。我迅速又抓起一团雪继续追赶。"
    translate None cyne_chapter1_0142:
        "街道空荡荡的，但并不太暗。他冲进一条小巷，然后又窜到另一条主干道上。"
    translate None cyne_chapter1_0143:
        "他往前飞奔，躲在一座巨大的青铜雕像后面。我们绕着雕像周旋，谁也不肯放弃。"
    translate None cyne_chapter1_0144:
        c c whap "来抓我啊…"
    translate None cyne_chapter1_0145:
        scene bg sc night at hpunch
        "这是我的机会。我的雪球正中他的面门，然后滚落在地上。"
    translate None cyne_chapter1_0146:
        rs c wsur "..."
    translate None cyne_chapter1_0147:
        c c wsur "..."
    translate None cyne_chapter1_0148:
        "沉默持续了一会儿，随即爆发出一阵大笑声。"
    translate None cyne_chapter1_0149:
        rs c whap "啊哈哈…天呐赛恩，我早说过会抓住你的，你怎么还这么惊讶？"
    translate None cyne_chapter1_0150:
        "看着他困惑的表情，实在忍不住想笑。"
    translate None cyne_chapter1_0151:
        c c wang "…看来是时候动真格的了。好吧，我陪你玩玩。"
    translate None cyne_chapter1_0152:
        "我们在寒风中追逐打闹，像孩子一样互相扔着雪球大笑。"
    translate None cyne_chapter1_0153:
        "我的手指早已冻得没了知觉，但我没有因此停下。"
    translate None cyne_chapter1_0154:
        "我们都太倔强了。谁也不肯先认输。"
    translate None cyne_chapter1_0155:
        rs c wsad "你看…发…发抖了…认输了吧？"
    translate None cyne_chapter1_0156:
        "我感觉牙齿在打颤。"
    translate None cyne_chapter1_0157:
        c c wsmi "我从小就生活在这种寒冷中。现在可是在我的地盘上！"
    translate None cyne_chapter1_0158:
        scene gallery_74 with dissolve
        "我迅速蹲下身，准备防御。"
    translate None cyne_chapter1_0159:
        scene gallery_75 with dissolve
        c "你大意了。"
    translate None cyne_chapter1_0160:
        scene gallery_75a with dissolve
        rs "啊！"
    translate None cyne_chapter1_0161:
        "这下完了…"
    translate None cyne_chapter1_0162:
        "赛恩站在我上方，威胁性地将雪球上下抛接。"
    translate None cyne_chapter1_0163:
        "我做好了被砸的准备。"
    translate None cyne_chapter1_0164:
        "…"
    translate None cyne_chapter1_0165:
        "……."
    translate None cyne_chapter1_0166:
        scene gallery_75b with dissolve
        stop music fadeout 2.0
        "然而赛恩没有扔雪球，而是轻轻弹了下我的额头，低头露出发自内心的笑容。"
    translate None cyne_chapter1_0167:
        c "告诉你，我不介意给你多添些衣服—但我想如果我们这么快就把这些弄坏，阿什会不高兴的。"
    translate None cyne_chapter1_0168:
        rs "……嗯。"
    translate None cyne_chapter1_0169:
        play music "sounds/bgm/night.ogg"
    translate None cyne_chapter1_0170:
        "又一次，我感觉脸颊发烫。"
    translate None cyne_chapter1_0171:
        scene gallery_75c with dissolve
        "慢慢地，我从雪地里站起来，在裤子上擦了擦手。"
    translate None cyne_chapter1_0172:
        "我的手好冷…真的冷极了。手指早就没了知觉。"
    translate None cyne_chapter1_0173:
        "还没意识到自己在做什么，我已经伸出手握住了赛恩的手。"
    translate None cyne_chapter1_0174:
        rs "我有点得意忘形了…对不起。"
    translate None cyne_chapter1_0175:
        c "是我开的头。挺有意思的。"
    translate None cyne_chapter1_0176:
        c "我们最好在你同伴发现前把你送回去，不然他们会以为我绑架了你。你有两个保护欲很强的同伴。"
    translate None cyne_chapter1_0177:
        rs "...."
    translate None cyne_chapter1_0178:
        c "等等…这个场景…这个场面…别告诉我你要向我表白？"
    translate None cyne_chapter1_0179:
        rs "…不是…我只是想说…"
    translate None cyne_chapter1_0180:
        rs "..."
    translate None cyne_chapter1_0181:
        "我本来想说什么来着？我要做什么？"
    translate None cyne_chapter1_0182:
        c "你本来是想说…？"
    translate None cyne_chapter1_0183:
        rs "我..我…我只是想问那座雕像是谁！就…有点好奇，你懂吗？"
    translate None cyne_chapter1_0184:
        c "...."
    translate None cyne_chapter1_0185:
        c "呵，这样啊。我还指望你会邀请我去你房间然后把我推倒呢。"
    translate None cyne_chapter1_0186:
        rs "你不是已经拒绝过我的邀请了…"

    $ about_Elliot.locked = False
    translate None cyne_chapter1_0187:
        c "那是埃利奥特。{a=set_entry:enc_people->about_Elliot}{color=#DA70D6}「伟大的埃利奥特」{/color}{/a}，或者像人们常称呼的「弑神者埃利奥特」。"
    translate None cyne_chapter1_0188:
        rs "他是谁？"

    $ about_Elliot._text.append("埃利奥特是奥雷利亚战争中率领锡德卡汉军队的将军。")

    translate None cyne_chapter1_0189:
        c "他是奥雷利亚战争期间统领锡德卡汉军队的{a=set_entry:enc_people->about_Elliot}{color=#87CEEB}将军{/color}{/a}。关于他有个有趣的故事。"
    translate None cyne_chapter1_0190:
        c "传说他杀死了一个威胁城市的邪神。本来以为是夸大其词，但经历了这么多事…说不定是真的。"
    translate None cyne_chapter1_0191:
        "我回想起与诺克斯的战斗，自己当时多么无力…如果埃利奥特真能杀死那样的存在，他一定非常强大…"
    translate None cyne_chapter1_0192:
        rs "明白了…"
    translate None cyne_chapter1_0193:
        c "...."
    translate None cyne_chapter1_0194:
        "这样站着…很舒服。他的手自然而然地与我十指相扣。"
    translate None cyne_chapter1_0195:
        c "你很冷吧？"
    translate None cyne_chapter1_0196:
        rs "我能感觉到心跳都传到指尖了…"
    translate None cyne_chapter1_0197:
        c "也许该给你要副更暖和的手套…嗯…还有耳罩，你耳朵都冻得通红了。"
    translate None cyne_chapter1_0198:
        rs "真的不用再破费了。你已经做得够多了不是吗？"
    translate None cyne_chapter1_0199:
        c "不然我的钱该花在哪里？"
    translate None cyne_chapter1_0200:
        rs "呃…不知道，但你不该都浪费在我身上。"
    translate None cyne_chapter1_0201:
        c "只要我乐意就不是浪费。放心，我的钱一时半会儿花不完。"
    translate None cyne_chapter1_0202:
        c "走吧，我该告辞了。还得去…见母亲大人。"

    window hide dissolve

    scene bg sc night with dissolve
    window show dissolve
    translate None cyne_chapter1_0203:
        "他没给我回答的机会，抽回手转身离去。"
    translate None cyne_chapter1_0204:
        rs c wsmi "……谢谢你陪我待在外面。"
    translate None cyne_chapter1_0205:
        c c wsmi "嗯嗯，我也玩得很开心。"
    translate None cyne_chapter1_0206:
        rs "路上小心。"
    translate None cyne_chapter1_0207:
        "他轻轻挥了挥手，消失在昏暗的后巷里。"
    translate None cyne_chapter1_0208:
        "我想这暗示我该进屋休息了。"


    scene bg sw night with dissolve

    translate None cyne_chapter1_0209:
        "经过门廊时，艾琳正在账簿上写着什么。经过时她抬起头，我们对视了。"
    translate None cyne_chapter1_0210:
        show raen nw dim neu cloak with dissolve
        rs "呃……晚安！"
    translate None cyne_chapter1_0211:
        ey "晚安。是雷恩，对吧？"
    translate None cyne_chapter1_0212:
        ey "……你刚才和赛恩在一起？"
    translate None cyne_chapter1_0213:
        show raen nw dim sur with dis
        rs "……？是啊。"
    translate None cyne_chapter1_0214:
        ey "真意外，我以为他被禁止这么晚出门。"
    translate None cyne_chapter1_0215:
        rs "什么意思？"
    translate None cyne_chapter1_0216:
        ey "上次从锡德卡汉回来后，听说他被实施宵禁。日落之后不准外出。"
    translate None cyne_chapter1_0217:
        show raen nw dim sad with dis
        rs "天啊……要是他惹上麻烦，都是我的错……"
    translate None cyne_chapter1_0218:
        ey "能让他甘愿惹怒刚训斥过自己的母亲，看来他很看重你。"
    translate None cyne_chapter1_0219:
        ey "请多关照他。我知道他可能有点…狂野难驯，但他只是渴望有个真正信任的人。"
    translate None cyne_chapter1_0220:
        show raen nw dim sur with dis
        rs "..."
    translate None cyne_chapter1_0221:
        ey "抱歉，我失礼了。请好好休息吧。"
    translate None cyne_chapter1_0222:
        rs "谢谢…"
    translate None cyne_chapter1_0223:
        hide raen nw dim with dissolve
        "她继续低头记账，我趁机溜回房间。"


    scene bg swroom night with dissolve:
        xpos 0.5 ypos 1.0 xanchor 0.56 yanchor 1.0 zoom 1.49
    translate None cyne_chapter1_0224:
        "独处卧室，我默默脱下衣物，把潮湿的衣衫晾开。钻进被窝将毯子拉到肩头。"
    translate None cyne_chapter1_0225:
        "温暖柔软，如同昨夜。"
    translate None cyne_chapter1_0226:
        "赛恩…"
    translate None cyne_chapter1_0227:
        "希望你和你父母谈得顺利。"
    translate None cyne_chapter1_0228:
        "我几乎瞬间就沉入了梦乡。"

    stop music fadeout 2.0
    window hide dissolve
    scene black with eye_shut
    pause(1.0)
    scene bg sc night with eye_open
    window show dissolve
    translate None cyne_chapter1_0229:
        "赛恩在漆黑街道狂奔，迫切想赶回家中。"
    translate None cyne_chapter1_0230:
        play music "sounds/bgm/creepy.ogg"
    translate None cyne_chapter1_0231:
        "{i}不不……天已经这么黑了…{/i}"
    translate None cyne_chapter1_0232:
        "{i}之前说服她就够难了，现在简直不可能…{/i}"
    translate None cyne_chapter1_0233:
        "拐过最后街角，眼前出现宏伟的雕花大门。\"维蒙德\"的草书纹样清晰可辨。"
    translate None cyne_chapter1_0234:
        "赛恩松了口气。"
    translate None cyne_chapter1_0235:
        "{i}说不定她根本没发现-{/i}"
    translate None cyne_chapter1_0236:
        "正以为能蒙混过关时，两侧卫兵突然推开大门，一位女士大步走出。"
    translate None cyne_chapter1_0237:
        "她盛装打扮仿佛全世界的目光都聚焦在她身上，高跟鞋在石径上咔嗒作响。赛恩挺直腰杆，立正站好。"
    translate None cyne_chapter1_0238:
        show cyne nw dark ang cloak at slightright
        show lv n dark ang1 at lvslightleft
        with dissolve
##### CYNE LINES MISSING FOR FOLLOWING SCENE
        lv "呵，看来有人迟到了呢。我对你还不够严厉是吗？你想被禁足在庄园里吗？"
    translate None cyne_chapter1_0239:
        c "不，母亲。请原谅我稍许迟到。我有些事耽搁了。"
    translate None cyne_chapter1_0240:
        lv "耽搁了，是吗？哎呀，究竟有什么事能比我的指令更重要，让你允许自己被耽搁？"
    translate None cyne_chapter1_0241:
        c "...."
    translate None cyne_chapter1_0242:
        c "您一直在找的那个男孩。我知道他在哪里。"
    translate None cyne_chapter1_0243:
        show lv n dark smi with dis
        lv "嗯…有意思。然后呢？"
    translate None cyne_chapter1_0244:
        show cyne nw dark sad with dis
        c "...."
    translate None cyne_chapter1_0245:
        lv "说。"
    translate None cyne_chapter1_0246:
        show cyne nw dark ang with dis
        c "…我想要求些回报。"
    translate None cyne_chapter1_0247:
        show lv n dark neu with dis
        lv "你竟敢和我谈条件，就凭你现在这处境？哈！不愧是我的儿子。"
    translate None cyne_chapter1_0248:
        c "我要求不多，母亲。只是想达成某种协议。"
    translate None cyne_chapter1_0249:
        lv "说出你的条件，我会考虑。"
    translate None cyne_chapter1_0250:
        c "我希望获得明天舞会的通行许可，并允许我带他作为我的舞伴。"
    translate None cyne_chapter1_0251:
        lv "有趣…西纳库洛斯，你向来对这些活动毫无兴趣，过去我不得不强迫你参加。现在怎么突然转变了？"
    translate None cyne_chapter1_0252:
        c "难道我就不能改变心意吗？"
    translate None cyne_chapter1_0253:
        show lv n dark ang1 with dis
        lv "这该不会又是你逃跑捣乱的伎俩吧？你最好别再让家族蒙羞。为了平息那些关于你的流言蜚语，我已经够头疼了。"
    translate None cyne_chapter1_0254:
        c "我会表现最好的。我向您保证。"
    translate None cyne_chapter1_0255:
        lv "......"
    translate None cyne_chapter1_0256:
        lv "要是你能把这份热情用在上家教课的时候就好了。"
    translate None cyne_chapter1_0257:
        show cyne nw dark sad with dis
        c "…我会努力的，母亲。"
    translate None cyne_chapter1_0258:
        show lv n dark smi with dis
        lv "我想尽快见见那个男孩。"
    translate None cyne_chapter1_0259:
        show cyne nw dark sur with dis
        c "什么？！"
    translate None cyne_chapter1_0260:
        lv "若你真如所言那般渴望参加舞会，就该按我说的做。"
    translate None cyne_chapter1_0261:
        lv "毕竟，我若没能亲自问候你这位尊贵的约会对象，未免太过失礼。我不能让其他人捷足先登。"
    translate None cyne_chapter1_0262:
        show cyne nw dark ang with dis
        c "…遵命，母亲。若这是必要条件，我很乐意带他来见您。"
    translate None cyne_chapter1_0263:
        lv "哼。或许我对你的判断有误。你终究还是有点用处的。"
    translate None cyne_chapter1_0264:
        show cyne nw dark sad with dis
        c "..."

    stop music fadeout 2.0
    window hide dissolve

    scene black with dissolve
    pause(1.0)
    window show dissolve
    translate None cyne_chapter1_0265:
        rs "…有人吗？"
    translate None cyne_chapter1_0266:
        rs "你在吗？"
    translate None cyne_chapter1_0267:
        "……………"
    translate None cyne_chapter1_0268:
        "寂静在我脑海中回荡。"
    translate None cyne_chapter1_0269:
        "又一次，杳无音讯。她已经离开了。"

    window hide dissolve

    scene bg swroom day with dissolve:
        xpos 0.5 ypos 1.0 xanchor 0.63 yanchor 0.93 zoom 1.39
        linear 30.0 xpos 0.5 ypos 1.0 xanchor 0.36 yanchor 0.93 zoom 1.39
    window show dissolve
    play music "sounds/bgm/Discovery.ogg" fadein 3.0
    translate None cyne_chapter1_0270:
        "我心不在焉地在床上翻了个身，朝窗户望去。柔和的光线洒在床上，在赛恩的皮肤上显得格外好看。"
    translate None cyne_chapter1_0271:
        "…."
    translate None cyne_chapter1_0272:
        "……..."
    translate None cyne_chapter1_0273:
        "等等，什么…？"
    translate None cyne_chapter1_0274:
        rs wsur "赛恩！你在这里干什么！？"
    translate None cyne_chapter1_0275:
        "我猛地坐起身，低头看着咧嘴笑的赛恩。他用手掌托着头，四肢舒展地躺在我旁边的床上。"
    translate None cyne_chapter1_0276:
        rs "…你在这里多久了？"
    translate None cyne_chapter1_0277:
        c whap "整整五分钟。别担心，我表现可好了。连偷看都没有！"
    translate None cyne_chapter1_0278:
        c "你看上去很累，所以我还不忍心叫醒你。"
    translate None cyne_chapter1_0279:
        rs "那你到底是怎么进来的？"
    translate None cyne_chapter1_0280:
        c "这可是你自己说的—房间是我订的，所以我不用被邀请对吧？"
    translate None cyne_chapter1_0281:
        rs "..."
    translate None cyne_chapter1_0282:
        "赛恩的视线从我脸上移到裸露的胸口。我连忙把床单拉到下巴，遮住自己。"
    translate None cyne_chapter1_0283:
        c wsur "{b}现在{/b}才害羞？得了吧，在我面前没什么好藏的。"
    translate None cyne_chapter1_0284:
        "我不情愿地松开床单。"
    translate None cyne_chapter1_0285:
        c wsmi "啊，这些房间视野确实不错，是吧？"
    translate None cyne_chapter1_0286:
        rs wsmi "…你今天早上好像特别精神。"
    translate None cyne_chapter1_0287:
        c "我什么时候不友善了？"
    translate None cyne_chapter1_0288:
        "我微微摇头。"
    translate None cyne_chapter1_0289:
        rs wsur "真希望我能像你一样快乐…"
    translate None cyne_chapter1_0290:
        c wneu "..."
    translate None cyne_chapter1_0291:
        c wsur "哎呀，这和快乐没关系吧？"
    translate None cyne_chapter1_0292:
        rs "...?"
    translate None cyne_chapter1_0293:
        c whap "啊，别想那么多！话说回来，到底是发生了什么，让你一晚上愁成这样？"
    translate None cyne_chapter1_0294:
        rs wsad "…我现在心事重重。"
    translate None cyne_chapter1_0295:
        c "比如…想我？希望你还没幻想我到失眠的程度…"
    translate None cyne_chapter1_0296:
        "我觉得是时候告诉他我的梦了…治疗那部分先不说。"
    translate None cyne_chapter1_0297:
        rs "不…不，不是那样。是关于我的梦。"
    translate None cyne_chapter1_0298:
        c wsur "…你一直做和我有关的春梦？"
    translate None cyne_chapter1_0299:
        rs wemb "什么—没有，一点都不色情！"
    translate None cyne_chapter1_0300:
        rs wsad "…是我还没告诉你的事。我们能聊聊吗？"
    translate None cyne_chapter1_0301:
        "他点点头，脸上的笑容消失了。"
    translate None cyne_chapter1_0302:
        rs "自从离开奥雷利亚卡维拉后，我就一直在做这些奇怪的梦。有个…声音在呼唤我。我想她是想帮助我。"
    translate None cyne_chapter1_0303:
        c wneu "像是…幻象？"
    translate None cyne_chapter1_0304:
        rs "差不多吧。在此之前我都没太当回事—但我跟维拉斯提过，他认为这是有人在引导我。"
    translate None cyne_chapter1_0305:
        c "那么…问题是什么？当然，除了你脑子里多了个声音这件事。"
    translate None cyne_chapter1_0306:
        rs "问题是她消失了，就在告诉我我被跟踪了而且\'他\'快要到的时候。她说我什么都做不了来阻止这件事。"
    translate None cyne_chapter1_0307:
        c "...."
    translate None cyne_chapter1_0308:
        c "而你之前就没想过要告诉我？"
    translate None cyne_chapter1_0309:
        rs "对不起…"
    translate None cyne_chapter1_0310:
        c "..."
    translate None cyne_chapter1_0311:
        c "所以，她离开了。你知道为什么吗？"
    translate None cyne_chapter1_0312:
        rs "完全没有头绪。听起来她处境不太安全。"
    translate None cyne_chapter1_0313:
        rs "我很害怕，赛恩…我当然为自己害怕，但更担心她…"
    translate None cyne_chapter1_0314:
        "赛恩眉头紧锁，全神贯注地听着我的话。"
    translate None cyne_chapter1_0315:
        c wang "之前发生过这种事吗？"
    translate None cyne_chapter1_0316:
        rs "…当我们穿过苋红森林时，她消失过一段时间，但等我们进入锡德卡汉后她就回来了。"
    translate None cyne_chapter1_0317:
        "提到那片森林时赛恩身体绷紧了一下，随后又放松地靠回我床上。看来那里发生的事还在困扰着他。"
    translate None cyne_chapter1_0318:
        c wneu "或者，她并没有在苋红森林里消失 - 只是你听不见她了。那是个诡异的地方，就算有什么阻断了你们的联系我也不意外。"
    translate None cyne_chapter1_0319:
        rs "或许…"
    translate None cyne_chapter1_0320:
        c "所以你认为我们应该认真对待她的警告？"
    translate None cyne_chapter1_0321:
        rs "是的。"
    translate None cyne_chapter1_0322:
        c "…好吧。我们寻找卡斯皮安期间必须保持警惕。"
    translate None cyne_chapter1_0323:
        c wsmi "看来你需要个穿着闪亮盔甲的骑士了，嗯？"
    translate None cyne_chapter1_0324:
        "他咯咯笑了起来，脸上又恢复了无忧无虑的表情。"
    translate None cyne_chapter1_0325:
        c "对了，我有个能让你高兴的消息。两张锡德卡汉舞会的专属邀请函，就给我们俩的。"
    translate None cyne_chapter1_0326:
        "他掏出两个用蜡封着的深红色信封，在我眼前开心地晃来晃去。"
    translate None cyne_chapter1_0327:
        rs wsur "真的？！你怎么弄到的？"
    translate None cyne_chapter1_0328:
        c whap "看吧，你可以指望我的！"
    translate None cyne_chapter1_0329:
        c wsmi "…也没那么难。我只是和我母亲聊了聊。"
    translate None cyne_chapter1_0330:
        rs "她一定是位圣人…"
    translate None cyne_chapter1_0331:
        c wsad "啊哈哈，差不多吧…"
    translate None cyne_chapter1_0332:
        "他把信封递给我，我在手中翻看。没想到{b}纸张{/b}能制作得如此精致…"
    translate None cyne_chapter1_0333:
        c wsad "不过，呃…有几个条件。不是什么大事，别担心。"
    translate None cyne_chapter1_0334:
        rs wsad "我不喜欢这种说法…"
    translate None cyne_chapter1_0335:
        c wsur "你希望是大事？哇哦，雷恩…"
    translate None cyne_chapter1_0336:
        rs "认真点。"
    translate None cyne_chapter1_0337:
        c wneu "好吧好吧。她想尽快见你。"
    translate None cyne_chapter1_0338:
        "他移开视线，不肯与我对视。"
    translate None cyne_chapter1_0339:
        "他这是…难为情了？"
    translate None cyne_chapter1_0340:
        rs wsmi "我真想见见她！和你有关的人一定都很棒。"
    translate None cyne_chapter1_0341:
        c "...."
    translate None cyne_chapter1_0342:
        c "这样啊。嗯…我相信今晚我们一定会遇到她的，毕竟她也会出席。"
    translate None cyne_chapter1_0343:
        rs "我很期待！那么…不需要偷偷摸摸了吗？我们可以像普通客人一样进去？"
    translate None cyne_chapter1_0344:
        c wsmi "我们本来就是普通客人，傻瓜。和我在一起没人会质疑你的。"
    translate None cyne_chapter1_0345:
        rs wsur "会吗？"
    translate None cyne_chapter1_0346:
        c wsad "这个嘛…我其实不常参加这种场合。可能会有一些人不乐意看到我。"
    translate None cyne_chapter1_0347:
        rs "…？你不是…超级受欢迎的吗？"
    translate None cyne_chapter1_0348:
        c wsur "为什么会这么想？"
    translate None cyne_chapter1_0349:
        rs "你的一切都在高喊\"看看我！"
    translate None cyne_chapter1_0350:
        c "我还以为我一直很低调呢。"
    translate None cyne_chapter1_0351:
        c wsad "…我想你待会就能亲眼所见了。"
    translate None cyne_chapter1_0352:
        rs wsad "…如果你不想去，我们就不去。要找卡斯皮安还有很多其他机会。"
    translate None cyne_chapter1_0353:
        c whap "然后错过和你这样出色舞伴共赴豪华舞会的机会？绝不！"
    translate None cyne_chapter1_0354:
        "出色舞伴…？"
    translate None cyne_chapter1_0355:
        rs "你费了这么多功夫，我真的希望这次能找到些关于他下落的线索…"
    translate None cyne_chapter1_0356:
        c "听着，这件事可以晚点再担心，现在…"
    translate None cyne_chapter1_0357:
        c "我有个打发时间的好主意。"
    translate None cyne_chapter1_0358:
        rs wsur "哦？"
    translate None cyne_chapter1_0359:
        "赛恩用手指示意我靠近他。当我倾身过去时，他将嘴唇贴到我耳边。"
    translate None cyne_chapter1_0360:
        c wsmi "要不要来上第二课？"
    translate None cyne_chapter1_0361:
        "上次的记忆立刻浮现在脑海，我的脸瞬间发烫。"


    if cyne_yes: # TEST TO SEE THIS WORKS
        translate None cyne_chapter1_0362:
            "赛恩坐在我腿上坏笑的画面，让我的胃里突然翻腾起蝴蝶。"
        translate None cyne_chapter1_0363:
            "当我解开他衬衫时，他目光灼灼地注视着我每个动作的感觉…"
        translate None cyne_chapter1_0364:
            "他突然亲吻我的样子，那种感觉比我想象的还要美妙…"
        translate None cyne_chapter1_0365:
            "还有..他的手指轻抚过我的皮肤，一路向下，向下，直到停在我的裤腰上…"
        translate None cyne_chapter1_0366:
            "这堂课…会比上次更进一步吗…？"
        translate None cyne_chapter1_0367:
            rs wemb "但上次…你…"
        translate None cyne_chapter1_0368:
            c "让你有点手足无措？别担心，这次我不会再那样了。我会负全责的。"
        translate None cyne_chapter1_0369:
            rs "负责？"


    else:
        translate None cyne_chapter1_0370:
            "赛恩坐在我腿上坏笑的画面，让我的胃里突然翻腾起蝴蝶。"
        translate None cyne_chapter1_0371:
            "真是爱捉弄人…"
        translate None cyne_chapter1_0372:
            "这堂课…会比上次更进一步吗…？"
        translate None cyne_chapter1_0373:
            "我想知道那种感觉…我想和赛恩一起体验。"


    translate None cyne_chapter1_0374:
        c "只要跟着我的引导，你肯定能学到一两招。不过可不许偷懒！"
    translate None cyne_chapter1_0375:
        rs wemb "好…如果…如果你想的话，那就…"
    translate None cyne_chapter1_0376:
        c whap "完美！说到底没什么能比得上清晨的欢愉。呃，正午其实也不错。哦，还有夜晚。"
    translate None cyne_chapter1_0377:
        c "啊，算了。任何时候都很美好。"
    translate None cyne_chapter1_0378:
        "赛恩站起身脱掉外套，随手扔到旁边的椅子上。他回到床边，手掌抚过我裸露的肌肤。"
    translate None cyne_chapter1_0379:
        "我从未在他人面前如此袒露自己，但这感觉并不坏。"
    translate None cyne_chapter1_0380:
        c wsmi "正式声明—我的身体任何部位你都可以随意触碰，不需要征求许可。"
    translate None cyne_chapter1_0381:
        "我咽了咽口水。怯生生地伸出手，搭在他腰间。手掌下的腰肢纤细得惊人。"
    translate None cyne_chapter1_0382:
        "他慢条斯理地解着马甲，每个动作都带着挑逗。"
    translate None cyne_chapter1_0383:
        "我该…再解开他的衬衣吗..？这样可以吗？"
    translate None cyne_chapter1_0384:
        "他确实说过不需要经过他同意…"
    translate None cyne_chapter1_0385:
        "一颗、两颗、三颗…不一会儿，衬衣就和外套一样被抛到一旁。"
    translate None cyne_chapter1_0386:
        "我的视线根本无法从他身上移开。他身体的每一寸都光滑而性感，令人着迷。"
    translate None cyne_chapter1_0387:
        c whap "喜欢你所看到的吗？"
    translate None cyne_chapter1_0388:
        rs wemb "我..我喜欢！"
    translate None cyne_chapter1_0389:
        c wsad "呵呵呵…光是看看就满足了吗？哎呦，真可怜呐…"
    translate None cyne_chapter1_0390:
        "他撅着嘴假装伤心，指尖却顽皮地拨弄着自己的裤腰。"
    translate None cyne_chapter1_0391:
        "他在等我主动。"
    translate None cyne_chapter1_0392:
        "我向前探身，缓缓褪下他的长裤。"
    translate None cyne_chapter1_0393:
        "他仰面倒在床上，双腿缠住我的腰肢磨蹭着。"
    translate None cyne_chapter1_0394:
        "我倒吸一口气，试图平复加速的心跳。"
    translate None cyne_chapter1_0395:
        "目光沿着他的身体游移—越来越往下，直到面颊烧得更烫。"
    translate None cyne_chapter1_0396:
        c wsmi "还在害羞？"
    translate None cyne_chapter1_0397:
        rs "有…有一点…"
    translate None cyne_chapter1_0398:
        c "真可爱。"
    translate None cyne_chapter1_0399:
        "当他的手指划过内裤勾勒我阳具形状时，我惊喘出声。"
    translate None cyne_chapter1_0400:
        "他的谈吐，他的动作，他的眼神…一切都充满诱惑。"

    translate None cyne_chapter1_0401:
        "我闭紧双眼，双唇轻触赛恩的嘴唇。他热情地回吻，我感受到他的舌尖滑过我的唇瓣。"
    translate None cyne_chapter1_0402:
        "他微微张嘴，像是发出邀请。每个动作都让我的体温不断升高，而逐渐加深的亲吻更是火上浇油。"
    translate None cyne_chapter1_0403:
        "他触碰的每个部位都让我战栗不已，游走的手指很快引发我身体的反应。"
    translate None cyne_chapter1_0404:
        rs "啊…"
    translate None cyne_chapter1_0405:
        "我抽身后退，终于睁开了眼睛。他正凝视着我，那双绿眸显得格外锐利。"
    translate None cyne_chapter1_0406:
        rs "啊…赛恩..感觉真好…"
    translate None cyne_chapter1_0407:
        c "那就别停。"
    translate None cyne_chapter1_0408:
        "他把我拉得更近，重新开始用臀部磨蹭我。当我再次停下来喘气时，他侧过头，用眼神邀请着我。"
    translate None cyne_chapter1_0409:
        "我轻轻吻过他的脖颈和胸膛，直到他制止了我。"
    translate None cyne_chapter1_0410:
        c "不必对我如此温柔。我保证，我不会碎掉的。"
    translate None cyne_chapter1_0411:
        rs "好吧…"
    translate None cyne_chapter1_0412:
        "我不想让他失望…我会尽力的…!"
    translate None cyne_chapter1_0413:
        "我继续沿着他的胸膛一路吻下。又舔又啃，在他躯干上留下细小的印记。"
    translate None cyne_chapter1_0414:
        c wshy "啊…!"
    translate None cyne_chapter1_0415:
        "随着我的唇往下移动，赛恩口中漏出的喘息与呻吟越发频繁。"
    translate None cyne_chapter1_0416:
        "我发现自己愈发渴望聆听—他那诱人的喘息声，毫不掩饰的呻吟方式…"
    translate None cyne_chapter1_0417:
        "如果亲吻就能让他这样反应…要是我…更多触碰他呢…？"
    translate None cyne_chapter1_0418:
        "我咬住他的胸膛换来一声明显的抽气，同时学着他对我的动作，将手覆上他逐渐硬挺的部位。"
    translate None cyne_chapter1_0419:
        c "啊..! 嗯…"
    translate None cyne_chapter1_0420:
        "那我就模仿他的做法。他{b}本来{/b}就是要当我的老师，对吧？"
    translate None cyne_chapter1_0421:
        "我重复着赛恩方才对我使用的手法。透过内裤，我能感受到他的阴茎正在迅速勃起。"
    translate None cyne_chapter1_0422:
        "我抬眼瞥向赛恩。他凝视着我的目光中满是情欲。"
    translate None cyne_chapter1_0423:
        c "你…打算一直让它们穿着吗…？"
    translate None cyne_chapter1_0424:
        rs "要…要我脱掉吗？"
    translate None cyne_chapter1_0425:
        c "拜托…"
    translate None cyne_chapter1_0426:
        "转瞬间，我的手指已勾住他的内裤边缘开始下拉，同时仍在他胸膛上留下亲吻。"
    translate None cyne_chapter1_0427:
        "他发出一声呻吟，嗓音沙哑而性感。"
    translate None cyne_chapter1_0428:
        play sound "sounds/sfx/slam.ogg" fadein 1.0
        "卧室门突然被推开，福恩和莱奥斯闯了进来。"
    translate None cyne_chapter1_0429:
        stop music fadeout 2.0
        l wann "我真的开始怀疑你聋了。难道听不见我们敲—"
    translate None cyne_chapter1_0430:
        l wsur "............"
    translate None cyne_chapter1_0431:
        f wsur ".........."
    scene bg swroom day with dissolve
    play music "sounds/bgm/Fooling Around Tiny.ogg"
    translate None cyne_chapter1_0433:
        "两人惊得张大嘴巴，我立刻从赛恩身边跳开，用床单裹住身体。"
    translate None cyne_chapter1_0434:
        f wemb "天啊..我…我…非常抱歉！"
    translate None cyne_chapter1_0435:
        c wang "呵…二位早安。我猜你们从不懂敲门？"
    translate None cyne_chapter1_0436:
        rs wemb "这不是…不是你们看到的那样…！"
    translate None cyne_chapter1_0437:
        c whap "除非…你们想加入？"
    translate None cyne_chapter1_0438:
        "我在慌乱中躲藏自己，赛恩却大剌剌地躺在外面，用手肘撑着身体。"
    translate None cyne_chapter1_0439:
        "发生的事情根本无从遮掩。"
    translate None cyne_chapter1_0440:
        "另外两人转身避开，脸涨得通红。"
    translate None cyne_chapter1_0441:
        f "不！我不想…我们不想加入！莱奥斯，我们出去等吧！"
    translate None cyne_chapter1_0442:
        stop music fadeout 2.0
        "福恩拽着莱奥斯的胳膊出去，门再次砰地关上。"
    translate None cyne_chapter1_0443:
        c wneu "呃…完全破坏气氛了。"
    translate None cyne_chapter1_0444:
        rs "哎哟….太尴尬了。"
    translate None cyne_chapter1_0445:
        "我用双手捂住脸，简直想哭。"
    translate None cyne_chapter1_0446:
        c whap "啊，别在意。前戏没什么好害羞的。"
    translate None cyne_chapter1_0447:
        c "有些人就喜欢被看着做。我不能说我反对这个主意。"
    translate None cyne_chapter1_0448:
        rs "被看着…？怎么会有人…"
    translate None cyne_chapter1_0449:
        c "人会被各种不同的事情激起欲望。我确定我们很快就能摸清你的敏感点。"
    translate None cyne_chapter1_0450:
        rs "...."
    translate None cyne_chapter1_0451:
        c "…你先去和其他人汇合吧。我马上就来。"
    translate None cyne_chapter1_0452:
        rs wsur "为什么？我们应该一起去。"
    translate None cyne_chapter1_0453:
        c "...."
    translate None cyne_chapter1_0454:
        c wsur "你想留在这里看我解决这个问题？"
    translate None cyne_chapter1_0455:
        "我的视线往下瞟，又猛地移回他脸上。"
    translate None cyne_chapter1_0456:
        rs wemb "不…不用！好吧，我去外面等你！"
    translate None cyne_chapter1_0457:
        "我手忙脚乱穿好衣服，冲出房门来到大厅。"

    window hide dissolve

    scene bg sw day with fade
    window show dissolve
    translate None cyne_chapter1_0458:
        "我裹紧斗篷从房间冲出来。"
    show fawn nw emb blush cloak at left
    show raen nw emb blush cloak at center
    show leos nw neu cloak at right
    with dissolve
    translate None cyne_chapter1_0459:
        f "...."
    translate None cyne_chapter1_0460: # FIND FILL
        l "...."
    translate None cyne_chapter1_0461:
        rs "早…早上好…"
    translate None cyne_chapter1_0462:
        play music "sounds/bgm/Discovery.ogg" fadein 3.0
        f "早…"
    translate None cyne_chapter1_0463:
        "福恩的眼睛到处乱瞟就是不看我，莱奥斯则抱着胳膊直勾勾盯着。"
    translate None cyne_chapter1_0464:
        l "你们俩刚才在干什么？"
    translate None cyne_chapter1_0465:
        f "莱奥斯！你..你不能这么问…！"
    translate None cyne_chapter1_0466:
        show leos nw thi with dis
        l "为-为什么不能？怎么，他们惹上麻烦了吗？"
    translate None cyne_chapter1_0467:
        f "呃…"
    translate None cyne_chapter1_0468:
        l "那小鬼呢？"
    translate None cyne_chapter1_0469:
        rs "他…他说他还有点事要…要收尾…."
    translate None cyne_chapter1_0470:
        f "....."

    show fawn nw at farleft
    show raen nw at cenleft
    show leos nw at farright
    with move

    show cyne nw hap cloak at cenright with dissolve
    translate None cyne_chapter1_0471:
        c "想我了吗？"
    translate None cyne_chapter1_0472:
        show leos nw neu with dis
        l "才不。怎么这么久？"
    translate None cyne_chapter1_0473:
        c "噢，你知道的。这个那个的忙。"
    translate None cyne_chapter1_0474:
        "他对莱奥斯眨眨眼，后者翻了个白眼。"
    translate None cyne_chapter1_0475:
        l "一如既往地没用。至少告诉我你还有点用，搞到舞会邀请函了吧。"
    translate None cyne_chapter1_0476:
        c "算是吧。我弄到两张，所以我要带雷恩当我的舞伴。"
    translate None cyne_chapter1_0477:
        show fawn nw sur -blush with dis
        f "什么…？"
    translate None cyne_chapter1_0478:
        show cyne nw smi with dis
        c "你有意见？"
    translate None cyne_chapter1_0479:
        show fawn nw sad with dis
        f "….没有.."
    translate None cyne_chapter1_0480:
        c "你呢，雷恩？"

    window hide

    menu:
        "这样更安全":
            $ cyne_goodend += 1
            window show dissolve
            jump cyneroute_1yes

        "嗯…":
            $ cyne_badend += 1
            window show dissolve
            jump cyneroute_1no

label cyneroute_1yes:
    show raen nw neu -blush with dis
    translate None cyne_chapter1_0481:
        rs "就我们俩不容易引人注目。"
    translate None cyne_chapter1_0482:
        f "也是…"

    jump cynechoice1done

label cyneroute_1no:
    show raen nw sad -blush with dis
    translate None cyne_chapter1_0483:
        rs "抱歉…真希望我们大家都能一起去。"
    translate None cyne_chapter1_0484:
        c "这样更安全。如果两人成伴三人成众，那四个人更容易暴露行踪。"

    jump cynechoice1done

label cynechoice1done:
    translate None cyne_chapter1_0485:
        l "那这段时间有什么计划？"
    translate None cyne_chapter1_0486:
        rs "嗯…既然昨天没机会，不如我们去打听卡斯皮安的消息？说不定不用参加舞会就能偶遇他。"
    translate None cyne_chapter1_0487:
        show cyne nw sur with dis
        c "哦，如果是这样的话，我们应该分头行动！"
    translate None cyne_chapter1_0488:
        l "为什么你总想分开行动？"
    translate None cyne_chapter1_0489:
        c "这样更有趣嘛。好啦，谁想先选搭档？"
    translate None cyne_chapter1_0490:
        f "…莱奥斯，我们一起？"
    translate None cyne_chapter1_0491:
        show raen nw sur with dis
        rs "福恩……？"
    translate None cyne_chapter1_0492:
        f "我们…给你们俩独处时间。"
    translate None cyne_chapter1_0493:
        show raen nw sad with dis
        rs "..."
    translate None cyne_chapter1_0494:
        show cyne nw hap with dis
        c "哇呜！雷恩，我可以带你参观！"
    translate None cyne_chapter1_0495:
        l "明天早上在这里集合，汇总情报。别偷懒。"
    translate None cyne_chapter1_0496:
        c "我才不会！"
    translate None cyne_chapter1_0497:
        l "随你怎么说。森林精灵，我们走"
    translate None cyne_chapter1_0498:
        hide leos
        hide fawn
        with dissolve
        "我向福恩挥手告别，但他避开我的视线，快步跟着莱奥斯离开了。"
    translate None cyne_chapter1_0499:
        rs "那么…现在怎么办？"
    translate None cyne_chapter1_0500:
        show cyne nw sur with dis
        c "我还没想法。"
    translate None cyne_chapter1_0501:
        rs "...."
    translate None cyne_chapter1_0502:
        c "不~过…新鲜空气或许能激发灵感。边走边想如何？"
    translate None cyne_chapter1_0503:
        show raen nw smi with dis
        rs "好主意！"
    translate None cyne_chapter1_0504:
        "我们走出门外，来到锡德卡汉的冰雪仙境，赛恩拽着我的胳膊前进。"

    window hide dissolve

    scene bg sc day with dissolve:
        xpos 0.38 ypos 1.1 xanchor 0.5 yanchor 1.0 zoom 1.39
    window show dissolve
    translate None cyne_chapter1_0505:
        "漫步时我望着山巅流云。雾气缭绕峰顶，给整座城市蒙上梦幻色彩。"
    translate None cyne_chapter1_0506:
        "住在群山之间…真是不可思议。"

    show raen nw sur cloak at slightright
    show cyne nw smi cloak at slightleft
    with dissolve
    translate None cyne_chapter1_0507:
        rs "你住在这么美的地方。"
    translate None cyne_chapter1_0508:
        show cyne nw sur with dis
        c "还不错对吧？不过比起宫殿窗景，我更喜欢这里的视野。"
    translate None cyne_chapter1_0509:
        rs "为什么？"
    translate None cyne_chapter1_0510:
        c "在那里总要越过层层人影。每个人都对你的人生指手画脚。"
    translate None cyne_chapter1_0511:
        show cyne nw sad with dis
        c "但在这里？我不过是个无名之辈。"
    translate None cyne_chapter1_0512:
        show raen nw sad with dis
        rs "...."
    translate None cyne_chapter1_0513:
        show cyne nw sur with dis
        c "糟，又说沉重话题了。要不要说点下流话转移注意？"
    translate None cyne_chapter1_0514:
        rs "…你知道，想倾诉的话我随时都在。"
    translate None cyne_chapter1_0515:
        show cyne nw hap with dis
        c "没什么可说的。啊快看！"
    translate None cyne_chapter1_0516:
        "如果真没事，为什么艾琳和阿什那么担心你…？为什么总是拒人千里？"
    translate None cyne_chapter1_0517:
        show raen nw sur with dis
        rs "嗯？怎么了？"
    translate None cyne_chapter1_0518:
        c "不是我亲爱的奥克斯哈伯姑娘吗！"
    translate None cyne_chapter1_0519:
        rs "…！莱拉斯？！"
    translate None cyne_chapter1_0520:
        c "嘿—莱拉斯！"

    show raen at right
    show cyne at left
    with move
    show lilas n neu at center with dissolve

    translate None cyne_chapter1_0521:
        lil "….你好啊，赛恩，雷恩。"
    translate None cyne_chapter1_0522:
        "她站在马车旁，来回打量着宽阔的街道。"
    translate None cyne_chapter1_0523:
        rs "你们在这儿干什么？"
    translate None cyne_chapter1_0524:
        lil "送些货物。你呢？还在找卡斯皮安？"
    translate None cyne_chapter1_0525:
        rs "没错。虽然还没找到线索，但我觉得我们越来越接近了。"
    translate None cyne_chapter1_0526:
        show lilas n smi2 with dis
        lil "很高兴听你这么说。"
    translate None cyne_chapter1_0527:
        show cyne nw sad with dis
        c "你们路上安全吗？你绝对{i}想不到{/i}我经历了什么。连续走好几天路？呕。完全不是我的风格。"
    translate None cyne_chapter1_0528:
        lil "…我绕着苋红森林走的，所以还挺平静。"
    translate None cyne_chapter1_0529:
        show cyne nw sur with dis
        c "看吧，这就是你的失误。既然独自旅行，何必绕远路？"
    translate None cyne_chapter1_0530:
        show lilas n neu with dis
        lil "我有同伴。载了奥克斯哈伯的两个人。"
    translate None cyne_chapter1_0531:
        c "噢噢…莱拉斯有艳遇了？"
    translate None cyne_chapter1_0532:
        "莱拉斯的表情始终平静。没什么能让赛恩的话使她难堪。"
    translate None cyne_chapter1_0533:
        lil "我对他们没兴趣，没有。"
    translate None cyne_chapter1_0534:
        c "拜托，配合着玩玩嘛。"
    translate None cyne_chapter1_0535:
        lil "…好吧。"
    translate None cyne_chapter1_0536:
        show lilas n smi1 with dis
        lil "是的，那是两个性感火辣的帅哥，我们在我的马车后座激情缠绵。这样说好点了吗？"
    translate None cyne_chapter1_0537:
        show cyne nw hap with dis
        c "好多了！"
    translate None cyne_chapter1_0538:
        rs "…他们没给你找麻烦吧？"
    translate None cyne_chapter1_0539:
        show lilas n neu with dis
        lil "没有。都是上了年纪的绅士，一个来自斯塔格威奇，另一个话很少。虽然没说为何旅行，但都很友善。"
    translate None cyne_chapter1_0540:
        c "你会待很久吗？晚点我有些东西想找你拿。"
    translate None cyne_chapter1_0541:
        lil "明天早上就走。要我把老样子给你留着吗？"
    translate None cyne_chapter1_0542:
        c "好的，麻烦了！"
    translate None cyne_chapter1_0543:
        lil "那我应该能收到赊账的钱吧？"
    translate None cyne_chapter1_0544:
        c "是是是，我把棺材本都带来。"
    translate None cyne_chapter1_0545:
        lil "…你其他同伴呢？"
    translate None cyne_chapter1_0546:
        show raen nw neu with dis
        rs "我们分头寻找能扩大范围，但我开始觉得这还不够…锡德卡汉太大了…"
    translate None cyne_chapter1_0547:
        lil "送货时我会帮你留意失踪那人。现在我得走了。"
    translate None cyne_chapter1_0548:
        c "拜拜，莱拉斯！回头见！"
    translate None cyne_chapter1_0549:
        "我忽然想起那个声音告诉我的事…有东西要来了…"
    translate None cyne_chapter1_0550:
        rs "…注意安全。"
    translate None cyne_chapter1_0551:
        show lilas n smi2 with dis

    scene bg sc day with dissolve:
        xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.47
        linear 23.0 xpos 0.5 ypos 1.46 xanchor 0.5 yanchor 1.0 zoom 1.47

    translate None cyne_chapter1_0552:
        "我和赛恩沿着宽阔的街道继续前行，边走边询问路人。不时有人呼喊赛恩，或是朝他跑来。"
    translate None cyne_chapter1_0553:
        "他确实很受欢迎。真不明白大家在担心什么。"
    translate None cyne_chapter1_0554:
        "几乎没人注意到我。仿佛当赛恩走入视线时，他就是你唯一能看见的存在。无比明亮耀眼，充满魅力又风趣…"
    translate None cyne_chapter1_0555:
        "我陪着他一同微笑，很高兴能与他为伴，但忍不住感到一丝嫉妒。"
    translate None cyne_chapter1_0556:
        rs c wsad "虽然几乎问遍了锡德卡汉的所有人，仍然没有他的踪迹…"
    translate None cyne_chapter1_0557:
        c c wneu "他会出现的，别担心。难道你不相信索伦吗？"
    translate None cyne_chapter1_0558:
        rs "我有看…"
    translate None cyne_chapter1_0559:
        c c wsmi "那就别这么焦虑了。有我在你身边，你绝不可能失败。"
    translate None cyne_chapter1_0560:
        c c wneu "说起来，我好像从没问过—你找到他之后打算做什么？"
    translate None cyne_chapter1_0561:
        rs "之后…？我…真的不知道。对我而言很难想那么远…"
    translate None cyne_chapter1_0562:
        c "但你有可能今天或明天就找到他，谁知道呢。"
    translate None cyne_chapter1_0563:
        rs "嗯…不久前我应该说想回家，但…我不确定那是否仍是选项。"
    translate None cyne_chapter1_0564:
        rs "如果我留在这里…意味着什么？抛弃家乡的所有人吗？"
    translate None cyne_chapter1_0565:
        rs "而如果我回去…是不是就得偷偷摸摸，假装外面的世界不存在？"
    translate None cyne_chapter1_0566:
        c c wsmi "看你做这么重要的决定会很有趣。你额头上小小皱纹还挺可爱的。"
    translate None cyne_chapter1_0567:
        rs "连一点建议都不给我吗…？"
    translate None cyne_chapter1_0568:
        c c wsur "为什么要给？我没资格指点你的人生。"
    translate None cyne_chapter1_0569:
        rs "但…你难道不想以后也继续见到我吗？"
    translate None cyne_chapter1_0570:
        c c wneu "...."
    translate None cyne_chapter1_0571:
        c c wsad "我不反对。只是不希望你因我的看法做决定。保持随意点，好吗？"
    translate None cyne_chapter1_0572:
        rs "...."
    translate None cyne_chapter1_0573:
        "我感到情绪有些低落。我们是朋友。这并不意外。"
    translate None cyne_chapter1_0574:
        "那…为何我如此失落？"
    translate None cyne_chapter1_0575:

        scene bg sc sunset with dissolve
        "把这些念头抛在脑后，我们继续搜寻整座城市。直到日落时分，所有人的回答依然如故。他们从未听说过约十八年前途经此地、名叫卡斯皮安的男人。"
    translate None cyne_chapter1_0576:
        rs c wsad "太阳已经西沉…"
    translate None cyne_chapter1_0577:
        c c wsur "哦哦，你知道这意味着什么吗？"
    translate None cyne_chapter1_0578:
        c c whap "过来，过来。"
    translate None cyne_chapter1_0579:
        "我俯下身，他为我整理头发，掸去外套上的灰尘。"
    translate None cyne_chapter1_0580:
        c "是时候前往舞会了。"

    scene bg sc sunset with dissolve:
        xpos 0.5 ypos 1.2 xanchor 0.47 yanchor 1.0 zoom 1.35
    translate None cyne_chapter1_0581:
        "于是我们拾级而上，沿着锡德卡汉那通往山巅的无尽阶梯攀登。"
    translate None cyne_chapter1_0582:
        "最后我们来到了一片只能用上流社会住宅区来形容的街区。"
    translate None cyne_chapter1_0583:
        "放眼望去，每个人身上都穿着华丽飘逸的长袍。他们看起来…简直就像王室成员。"
    translate None cyne_chapter1_0584:
        "人群沿着宽阔的街道向前流动，走向一座白色精致的建筑。说它是宫殿也不为过。"
    translate None cyne_chapter1_0585:
        rs c wsur "哇…"
    translate None cyne_chapter1_0586:
        c c whap "很震撼吧？"
    translate None cyne_chapter1_0587:
        rs "你们真的这样生活？"
    translate None cyne_chapter1_0588:
        c c wsad "很不幸确实是。好了，别浪费时间了。"
    translate None cyne_chapter1_0589:
        "他挽住我的胳膊，我们一起走向入口处，那里有守卫正在检查邀请函。"
    translate None cyne_chapter1_0590:
        "他递过那个烫金信封，守卫仔细检查后，又端详了一下赛恩的脸。"
    translate None cyne_chapter1_0591:
        guard "西纳库洛斯勋爵及一位客人。请进。"
    translate None cyne_chapter1_0592:
        c c wsmi "向您致以最诚挚的问候。"

    stop music fadeout 3.0
    window hide dissolve


    scene bg ball with fade:
        xpos 0.9 ypos 1.74 xanchor 0.5 yanchor 1.0 zoom 1.83
        linear 65.0 xpos 0.11 ypos 1.74 xanchor 0.5 yanchor 1.0 zoom 1.83
    window show dissolve

    translate None cyne_chapter1_0593:
        "走进大厅，我差点惊呼出声。眼前的奢华景象前所未见。"
    translate None cyne_chapter1_0594:
        play music "sounds/bgm/sidcaeham.ogg"
    translate None cyne_chapter1_0595:
        "首先映入眼帘的是装饰着精美雕刻与漩涡图案的挑高天花板，还有那盏巨大的枝形吊灯。"
    translate None cyne_chapter1_0596:
        "厅内早已挤满盛装出席的宾客。各色晚礼服与西装。即使我穿得够体面，仍感到相形见绌。"


    scene bg ball
    show raen nw dim sur at slightleft
    show cyne nw dim neu at slightright
    with dissolve
    translate None cyne_chapter1_0597:
        rs "赛恩…这太不可思议了.."
    translate None cyne_chapter1_0598:
        c "美食、音乐、场地…都无可挑剔。就是这些人要能换掉就好了。"
    translate None cyne_chapter1_0599:
        show cyne nw dim ang with dis
        c "听着。在我们行动前…我必须警告你。这里的人只在乎自己，除非你说了什么可供他们把柄的话。"
    translate None cyne_chapter1_0600:
        c "这里冷酷无情。尽量别引起注意，由我来说话。好吗？"
    translate None cyne_chapter1_0601:
        show raen nw dim sad with dis
        rs "好…好的…"
    translate None cyne_chapter1_0602:
        "我突然感到有些害怕。这些人{i}究竟{/i}是什么来头？"
    translate None cyne_chapter1_0603:
        ast "哎呀呀，这不是小西纳库洛斯勋爵吗。你母亲说你今晚不会出席…"
    translate None cyne_chapter1_0604:
        show cyne nw dim smi with dis
        c "阿斯特丽德女士…很高兴再次见到您。我临时变更了计划才有空过来—谁不想与各位杰出人士共度良宵呢？"
    translate None cyne_chapter1_0605:
        show cyne nw dim sad with dis
        c "…你还在和我母亲联系。真不错。"
    translate None cyne_chapter1_0606:
        ast "你不愿考虑家父的提议，我们都很失望。"
    translate None cyne_chapter1_0607:
        show cyne nw dim smi with dis
        c "…抱歉女士，现在已经不可能了。"
    translate None cyne_chapter1_0608:
        ast "哦？为什么这么说？"
    translate None cyne_chapter1_0609:
        show cyne nw dim hap with dis
        c "请允许我向您介绍我的未婚夫，雷恩爵士。他来自海对岸的托根。"
    translate None cyne_chapter1_0610:
        show bg ball with hpunch
        ast "你的未婚夫？！"
    translate None cyne_chapter1_0611:
        show raen nw dim sur with dis
        rs "您…您好？"
    translate None cyne_chapter1_0612:
        ast "...."
    translate None cyne_chapter1_0613:
        ast "我父亲会知道这件事的，记住我的话。"
    translate None cyne_chapter1_0614:
        "她气冲冲地离开了，精致的脸庞上布满怒容。"
    translate None cyne_chapter1_0615:
        c "再见啦！"
    translate None cyne_chapter1_0616:
        show raen nw dim sad with dis
        rs "不是说好不引人注目的吗…"
    translate None cyne_chapter1_0617:
        show cyne nw dim smi with dis
        c "不过还挺好笑的，不是吗？"

    stop music fadeout 2.0
    show cyne nw dim sad with dis
    translate None cyne_chapter1_0618:
        wom "等等…那是西纳库洛斯大人？他竟敢在这里露面…？"
    translate None cyne_chapter1_0619:
        wom "他真是家族之耻…看看他，身边又多了个乡下人。"
    translate None cyne_chapter1_0620:
        wom "他母亲居然还没和他断绝关系真是奇迹…"
    translate None cyne_chapter1_0621:
        c "...."
    translate None cyne_chapter1_0622:
        rs "赛恩…？"
    translate None cyne_chapter1_0623:
        play music "sounds/bgm/night.ogg" fadein 2.0
        c "走吧，这样下去我们打听不到任何消息。"
    translate None cyne_chapter1_0624:
        "他抓住我的手拽着我穿过人群。他脸上的表情是我从未见过的。"
    translate None cyne_chapter1_0625:
        "最后，我们来到了舞池附近。人们亲密地站在一起，愉快地闲聊着。"
    translate None cyne_chapter1_0626:
        show raen nw dim sur with dis
        rs "我们要不要和他们聊聊？"
    translate None cyne_chapter1_0627:
        show cyne nw dim neu with dis
        c "德克莱尔家的人？哦，不行。他们不会免费提供信息。"
    translate None cyne_chapter1_0628:
        rs "那…那些人怎么样？"
    translate None cyne_chapter1_0629:
        "我指向一群人。"
    translate None cyne_chapter1_0630:
        c "绝对不行。他们连看到我都受不了。"
    translate None cyne_chapter1_0631:
        show raen nw dim sad with dis
        rs "有没有我们能交谈的对象…？"
    translate None cyne_chapter1_0632:
        show cyne nw dim sad with dis
        c "..."
    translate None cyne_chapter1_0633:
        c "我会找到人的。"
    translate None cyne_chapter1_0634:
        "我们在人群中穿梭，却没能找到合适的询问对象。最后，我们在房间安静的角落稍作休息，坐了下来。"
    translate None cyne_chapter1_0635:
        c "….在这里等着好吗？我去找些人聊聊。"
    translate None cyne_chapter1_0636:
        show raen nw dim sur with dis
        rs "单独去？我和你一起—"
    translate None cyne_chapter1_0637:
        c "我没事的。好好休息吧。"


    scene bg ball with dissolve:
        xpos 0.5 ypos 1.24 xanchor 0.38 yanchor 1.0 zoom 1.64
    translate None cyne_chapter1_0638:
        "他消失在人群中，我叹着气靠回椅背。"
    translate None cyne_chapter1_0639:
        "那些人是什么意思…说他给家族蒙羞？他们口中的赛恩和我认识的是同一个人吗？"
    translate None cyne_chapter1_0640:
        "他…聪明又开朗。友善且仁慈。没错，他是喜欢惹些麻烦，但他不是坏人。"
    translate None cyne_chapter1_0641:
        wom "打扰一下…"
    translate None cyne_chapter1_0642:
        rs wsur "哦…您好，小姐。"
    translate None cyne_chapter1_0643:
        wom "抱歉打扰您…只是您看起来十分孤单。您是和别人一起来的吗？"

    window hide

    menu:
        "我是和未婚夫一起来的":
            $ cyne_goodend += 1
            window show dissolve
            jump cyneroute_2yes

        "我是和朋友一起来的":
            $ cyne_badend += 1
            window show dissolve
            jump cyneroute_2no

label cyneroute_2yes:
    translate None cyne_chapter1_0644:
        rs "实际上，我是和未婚夫一起来的。西纳库洛斯爵士，您可能听说过他。"
    translate None cyne_chapter1_0645:
        wom "哦-哦…非常抱歉打扰您了…"

    jump cynechoice2done


label cyneroute_2no:
    translate None cyne_chapter1_0646:
        rs "实际上，我是和朋友一起来的。西纳库洛斯爵士，您可能听说过他。"
    translate None cyne_chapter1_0647:
        wom "哦…和他一起？"
    translate None cyne_chapter1_0648:
        rs "…？这有什么问题吗？"
    translate None cyne_chapter1_0649:
        wom "你看起来不像是他通常会玩在一起的那种类型。"

    jump cynechoice2done

label cynechoice2done:
    translate None cyne_chapter1_0650:
        wom "这可能…很失礼，但你跟那样的人在一起能有什么安全感？"
    translate None cyne_chapter1_0651:
        rs "什么意思？"
    translate None cyne_chapter1_0652:
        wom "他压根就不是会安定下来的类型…"
    translate None cyne_chapter1_0653:
        rs wneu "...."
    translate None cyne_chapter1_0654:
        rs "也许他配不上你，但对我而言已经足够好了。"
    translate None cyne_chapter1_0655:
        lv smi "哎呀呀。当着我儿子客人的面侮辱他？桑文家族已经沦落到耍这种卑劣手段的地步了？"  ## PICK UP SCENE
    translate None cyne_chapter1_0656:
        wom "啊，夫人！对…对不起打扰了。我先告辞！"
    translate None cyne_chapter1_0657:
        "年轻小姐跑开了，取而代之的是另一个人。高挑身材，金色长发如瀑布般垂落。她低头看我，嘴角挂着微笑。"
    translate None cyne_chapter1_0658:
        rs wsur "你…一定是赛恩的母亲吧？"
    translate None cyne_chapter1_0659:
        "我慌忙从座位上跳起来，拼命想留下好的第一印象。"


    show raen nw dim sur at slightright
    show lv n dim smi at lvslightleft
    with dissolve
    $ about_LV.locked = False
    translate None cyne_chapter1_0660:
        lv "想必你就是那个我久闻大名的人了。很高兴终于见到你。请叫我{a=set_entry:enc_people->about_LV}{color=#DA70D6}维蒙德夫人{/color}{/a}。"
    translate None cyne_chapter1_0661:
        rs "哦，呃…你可以叫我雷恩。"
    translate None cyne_chapter1_0662:
        lv "雷恩。多么朴实可爱的名字。"
    translate None cyne_chapter1_0663:
        rs "谢…谢谢？"
    translate None cyne_chapter1_0664:
        "这算是侮辱还是赞美？"
    translate None cyne_chapter1_0665:
        lv "我本希望能借此机会互相了解。来个小小的私人谈话时间。"

    show lv at lvleft
    show raen at right
    with move
    show cyne nw dim ang at center with dissolve
    stop music fadeout 2.0
    translate None cyne_chapter1_0666:
        c "….母亲，我没注意到您来了。"
    translate None cyne_chapter1_0667:
        play music "sounds/bgm/creepy.ogg" fadein 3.0
        "赛恩回到我们身边，站在我身旁。看着这两人站在一起…确实能看出他们的血缘关系。"
    translate None cyne_chapter1_0668:
        lv "你是想说你没有像鹰一样盯着门口等我出现？"
    translate None cyne_chapter1_0669:
        c "恐怕没有。看来你抓住机会向我{i}亲爱的朋友{/i}自我介绍了。"
    translate None cyne_chapter1_0670:
        lv "亲爱的朋友？哎呀，听阿斯特丽德小姐的说法，我还以为你终于决定安定下来结婚了呢。"
    translate None cyne_chapter1_0671:
        show lv n dim ang1 with dis
        lv "总之，在你如此无礼地打断之前，我正试图与雷恩交谈。难道没人教过你更好的礼节吗？"
    translate None cyne_chapter1_0672:
        show cyne nw dim smi with dis
        c "怪我母亲。肯定是她没把我教养好。"
    translate None cyne_chapter1_0673:
        show lv n dim smi with dis
        lv "哈！真会耍嘴皮子，是吧？"
    translate None cyne_chapter1_0674:
        c "…我想是时候跳支舞了，你说呢，雷恩？"
    translate None cyne_chapter1_0675:
        rs "…当然。"
    translate None cyne_chapter1_0676:
        "我在母子二人之间来回看着。他们脸上挂着同样压迫性的微笑，仿佛在为什么事情较劲。"
    translate None cyne_chapter1_0677:
        lv "……享受这个夜晚吧。我希望能很快再次见到你，雷恩。"
    translate None cyne_chapter1_0678:
        show raen nw dim smi with dis
        rs "再见，女士！祝您夜晚愉快！"
    translate None cyne_chapter1_0679:
        stop music fadeout 3.0
        "赛恩抓住我的手臂，把我拉向舞厅中央，乐队的音乐让人们旋转在舞池周围。"
    window hide dissolve
    jump cyneroute2
