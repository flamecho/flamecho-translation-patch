label cynebadending:
    translate None cyne_badend_0001:
        c "...."
    translate None cyne_badend_0002:
        c "跟我一起去见我母亲，好吗？"
    translate None cyne_badend_0003:
        rs "你的…母亲？为什么偏偏是现在？"
    translate None cyne_badend_0004:
        "他的目光游移不定，嘴角掠过一丝若有若无的笑意。"
    translate None cyne_badend_0005:
        c "…如果你明天可能离开…那她…会想道别的。"
    translate None cyne_badend_0006:
        rs "...."
    translate None cyne_badend_0007:
        "我以为…他和母亲处不好？为什么会突然想让我去见她？"
    translate None cyne_badend_0008:
        rs "…如果你坚持的话…好吧。"
    translate None cyne_badend_0009:
        c "…好。很好，是的，她一定会…欣喜若狂…"

    window hide dissolve

    scene bg sc night with dissolve
    window show dissolve
    translate None cyne_badend_0010:
        "他从我身旁站起身，始终没有与我对视。我快速跟上他的脚步，我们沿着熟悉的街道向他的宅邸走去。"
    translate None cyne_badend_0011:
        "沉默。他没有开口，而我早已无话可说。我的话语…始终无法触及他的心。"
    translate None cyne_badend_0012:
        "不多时，我们站在了他家的大门前。"
    translate None cyne_badend_0013:
        "这门扉…一直都这么高大威严吗？"
    translate None cyne_badend_0014:
        "铁门缓缓开启，一个孤独的身影走了出来。"
    translate None cyne_badend_0015:
        "金发的女子。"
    translate None cyne_badend_0016:
        rs c wneu "…夫人，贸然打扰实在抱歉—"
    translate None cyne_badend_0017:
        lv smi "做得不错，西纳库洛斯。我本以为你会逃跑。"
    translate None cyne_badend_0018:
        c c wsad "..."
    translate None cyne_badend_0019:
        lv "没想到，你这辈子第一次学会了服从。值得表扬。"
    translate None cyne_badend_0020:
        rs c wsad "...?"
    translate None cyne_badend_0021:
        lv neu "现在，退下吧。我们有事要谈。"
    translate None cyne_badend_0022:
        rs c wsur "赛恩？"
    translate None cyne_badend_0023:
        c "…是，母亲。"
    translate None cyne_badend_0024:
        rs "赛恩，怎么回事？"
    translate None cyne_badend_0025:
        c "对不起…"

    window hide dissolve

    stop music
    scene black with hpunch
    scene bg sc night with Fade (2.0, 1.0, 1.0)
    window show dissolve
    play music "sounds/bgm/creepy.ogg" fadein 2.0
    translate None cyne_badend_0026:
        "就这样，赛恩独自走在街道上，如同往常一样。身后，是他连看都不愿多看一眼的母亲，以及…那个他本愿意付出一切去守护的少年。"
    translate None cyne_badend_0027:
        cmn "我什么都做不了，对吧…？无论怎样她都能得逞…"
    translate None cyne_badend_0028:
        cmn "我相信…相信他会没事的。他被困在那栋房子里，明天我就能去看他。如果他受伤了，那么… "
    translate None cyne_badend_0029:
        cmn "我一定会采取行动。"
    translate None cyne_badend_0030:
        "每一步都让他愈发不安。他盯着自己的脚尖，不知这个决定是否正确…抑或是…踏上了一条无法回头的路。"
    translate None cyne_badend_0031:
        "没想到他竟迎面撞上了什么人—这通常是雷恩才会犯的错，不是吗？"


    show bg sc night:
        xpos 0.5 ypos 1.17 xanchor 0.5 yanchor 1.0 zoom 1.42
    show cyne nw dark sad at slightright
    show luc n dark smir at slightleft
    with dissolve
    translate None cyne_badend_0032:
        c "…抱歉，是我的错。"
    translate None cyne_badend_0033:
        u "哎呀呀，西纳库洛斯少爷深夜独自游荡？真是有伤风化呢。"
    translate None cyne_badend_0034:
        show cyne nw dark neu with dis
        c "我认识你吗？"
    translate None cyne_badend_0035:
        "赛恩透过黑暗窥视，终于辨认出一些特征。乌黑的头发，还有猩红的双眸…"
    translate None cyne_badend_0036:
        c "里隆家族的瓦伦特大人？"
    translate None cyne_badend_0037:
        "他当然认得这张脸。作为现任国王的顾问，他是锡德卡汉的显赫人物。"
    translate None cyne_badend_0038:
        "有些人甚至说大多数统治工作都是他在幕后完成的。"
    translate None cyne_badend_0039:
        u "嗯，或许吧。谁知道呢？\""
    translate None cyne_badend_0040:
        cmn "什么？"
    translate None cyne_badend_0041:
        c "你在这里做什么？这个时间独自出门对你来说有点太晚了。"
    translate None cyne_badend_0042:
        u "我和你母亲有些事务要谈。"
    translate None cyne_badend_0043:
        c "你和她能有什么事务？"
    translate None cyne_badend_0044:
        u "她是个聪明的女人，手上有我想要的东西。我只希望她能明智地交出来。"
    translate None cyne_badend_0045:
        show cyne nw dark ang with dis
        c "...?"
    translate None cyne_badend_0046:
        u "我该走了。你总不想让关于你的流言传得更盛吧？"
    translate None cyne_badend_0047:
        show cyne nw dark sad with dis
        c "好吧……"
    translate None cyne_badend_0048:
        # HIDE LUCIUS HERE
        hide luc n dark with dissolve
        "黑发男子消失在阴影中，而赛恩无法驱散正在胃里翻腾的不安感。"
    translate None cyne_badend_0049:
        cmn "没关系，母亲有很多有权势的朋友。他今夜来访只是巧合。"
    translate None cyne_badend_0050:
        "尽管试图说服自己，他还是回头望了一眼童年故居的方向，但仅停留片刻便转身离去。"


    scene black with dissolve
    translate None cyne_badend_0051:
        "接下来的夜晚寒冷而孤寂。"
    translate None cyne_badend_0052:
        "他形单影只。就像一直以来那样。"

    window hide dissolve

    scene bg swroom day with Fade(1.0, 1.0, 1.0)
    window show dissolve
    translate None cyne_badend_0053:
        "赛恩被窗棂透进的光线唤醒，枕衾上洒满斑驳光影。"
    translate None cyne_badend_0054:
        "…不是他的床。而是两天前还与雷恩共枕的那张床。"
    translate None cyne_badend_0055:
        "他摇摇头，却怎么也无法驱散内心的焦灼。"
    translate None cyne_badend_0056:
        cmn "这不对…我不能就这样抛下他..!"
    translate None cyne_badend_0057:
        "他从床上一跃而起，冲出房间，穿过大厅，奔上街道。"

    window hide dissolve

    scene bg sc day with swipe
    window show dissolve
    translate None cyne_badend_0058:
        "他竭尽全力地奔跑，快得几乎以为自己会在抵达前倒下。"
    translate None cyne_badend_0059:
        "他推开所有挡路的人，招来无数愤怒的目光，但这些都不重要。"
    translate None cyne_badend_0060:
        "唯一重要的是…"
    translate None cyne_badend_0061:
        cmn "雷恩。"
    translate None cyne_badend_0062:
        "终于，他来到家门前。曾几何时，他或许会相信这些门是为了保护他而立。"
    translate None cyne_badend_0063:
        cmn "但实际上，它们只是把我关在笼中。"
    translate None cyne_badend_0064:
        "正当他伸手要推开门时，门却先开了—埃瑟走了出来。"
    translate None cyne_badend_0065:
        c c wsad "埃瑟…埃瑟，我要见雷恩。"
    translate None cyne_badend_0066:
        e "....."
    translate None cyne_badend_0067:
        c "埃瑟..？"
    translate None cyne_badend_0068:
        e "少爷…很抱歉，但是—"
    translate None cyne_badend_0069:
        show lv n sur at lvslightright
        show cyne nw ang cloak at slightleft
        with dissolve
        lv "哎呀呀，你这么快就跑回来了？"
    translate None cyne_badend_0070:
        c "我…我不能让你对他为所欲为。"
    translate None cyne_badend_0071:
        lv "你这话是什么意思？"
    translate None cyne_badend_0072:
        c "你心知肚明！你不能就这样…你不能利用他！"
    translate None cyne_badend_0073:
        show lv n smi with dis
        lv "谁说我在利用了？他是自愿留在这里的。"
    translate None cyne_badend_0074:
        show cyne with hpunch
        c "这不是真的！"
    translate None cyne_badend_0075:
        lv "卢西—啊，雷恩，出来吧。"
    translate None cyne_badend_0076:
        show lv at lvcenter
        show cyne at left
        with move
        show raen nw smi cloak at right with dissolve
        rs "刚背叛我就急着回来？"
    translate None cyne_badend_0077:
        show cyne nw sad with dis
        c "雷恩…我错了。求你了，我们离开吧，我会想办法弥补的。"
    translate None cyne_badend_0078:
        show raen nw sur with dis
        rs "离开？不必了。我在这里很好。"
    translate None cyne_badend_0079:
        show cyne nw sur with dis
        c "雷恩…？"
    translate None cyne_badend_0080:
        rs "你觉得我会想和你这种人多待一秒吗？真是蠢透了。 你怎么不照老规矩逃跑呢？继续当你的窝囊废吧。"
    translate None cyne_badend_0081:
        show cyne nw sad with dis
        c "什…什么…你在说什么？"
    translate None cyne_badend_0082:
        show raen nw neu with dis
        rs "我叫你离我远点。"
    translate None cyne_badend_0083:
        c "....."
    translate None cyne_badend_0084:
        c "对不起行吗？是我错了。求你了..！"
    translate None cyne_badend_0085:
        rs "别让我再看见你。"
    translate None cyne_badend_0086:
        "赛恩在身侧握紧拳头，眼角泛起泪光。"
    translate None cyne_badend_0087:
        cmn "雷恩，你到底怎么了？"
    translate None cyne_badend_0088:
        "无论他怎么看，那确实是雷恩。同样的棕色头发，同样温和的面容，同样的声音。"
    translate None cyne_badend_0089:
        "但本质上有东西不一样了。他的气场，他的灵魂，某些东西改变了。"
    translate None cyne_badend_0090:
        hide cyne with dissolve
        show lv at lvslightleft
        show raen at slightright
        with move
        "赛恩原地转身，逃走了。"
    translate None cyne_badend_0091:
        "总是选择逃跑。"
    translate None cyne_badend_0092:
        show lv n neu with dis
        lv "是不是有点太狠了？你要是不模仿他的言行，那孩子会起疑心的。"
    translate None cyne_badend_0093:
        rs "我可不擅长扮演他那种蠢兮兮的角色。"
    translate None cyne_badend_0094:
        lv "你立马就会露馅。"
    translate None cyne_badend_0095:
        rs "所以呢？我既有言者的力量，又有神灵撑腰。他奈何不了我。"
    translate None cyne_badend_0096:
        lv "...."
    translate None cyne_badend_0097:
        rs "好吧，女人。我晚点会去道歉，就说之前神志不清现在恢复了。别忘了我们的交易。"
    translate None cyne_badend_0098:
        show lv n smi with dis
        lv "毕竟议长大人时隔多年重返锡德卡汉，自然要尽快恢复他的职位。"
    translate None cyne_badend_0099:
        rs "而你要促成此事。作为交换…"
    translate None cyne_badend_0100:
        lv "你要让我在你身边有一席之地。"
    translate None cyne_badend_0101:
        show raen nw smi with dis
        rs "真是个精明的女人。我挺中意你。"
    translate None cyne_badend_0102:
        lv "但我说不上有多喜欢你。"
    translate None cyne_badend_0103:
        "棕发少年笑了，但这笑声不同往常。天真的魅力荡然无存，取而代之的是…"
    translate None cyne_badend_0104:
        "那是一团永远无法熄灭的残酷烈焰。"

    stop music fadeout 2.0
    window hide dissolve


    scene bg throne with Fade(1.0, 1.0, 1.0):
        xpos 0.55 ypos 1.77 xanchor 0.55 yanchor 1.0 zoom 1.8
        linear 28.0 xpos 0.55 ypos 1.03 xanchor 0.55 yanchor 1.0 zoom 1.8
    window show dissolve
    play music "sounds/bgm/sad.ogg" fadein 2.0
    translate None cyne_badend_0105:
        "随后的日子里，雷恩决定抗拒他的命运—永不返回奥雷利亚卡维拉。赛恩感到些许宽慰。"
    translate None cyne_badend_0106:
        "但这并未持续多久。"
    translate None cyne_badend_0107:
        "雷恩变了。"
    translate None cyne_badend_0108:
        "自那时起已过去六个月。福恩离开去重建他的生活，莱奥斯决定去旅行。"
    translate None cyne_badend_0109:
        "如今只剩下永远困在锡德卡汉的赛恩，以及总与他母亲一同消失的雷恩。"
    translate None cyne_badend_0110:
        "不久后重大公告发布了。说书人归来了。"
    translate None cyne_badend_0111:
        "有人支持，也有人惊恐万分。锡德卡汉分裂为两派。街头充斥着抗议与暴乱，直到国王突然宣布。"
    translate None cyne_badend_0112:
        "说书人将重登他的神圣王座。"
    translate None cyne_badend_0113:
        "于是雷恩坐在曾属于国王的宝座上，如今那位国王病重卧床，他跷着腿，手托着腮。"
    translate None cyne_badend_0114:
        rs wneu "无聊，无聊…整天坐着实在太无趣了。"
    translate None cyne_badend_0115:
        c wsad "...."
    translate None cyne_badend_0116:
        rs "赛恩，给我拿些吃的来。"
    translate None cyne_badend_0117:
        c "雷恩—"
    translate None cyne_badend_0118:
        rs "雷恩？"
    translate None cyne_badend_0119:
        c "...."
    translate None cyne_badend_0120:
        c "…言者大人…这真是您想要的吗？您…您怎么了？"
    translate None cyne_badend_0121:
        rs wsur "什么意思？我一点都没变。"
    translate None cyne_badend_0122:
        c "...."
    translate None cyne_badend_0123:
        rs "过来。"
    translate None cyne_badend_0124:
        "赛恩照做了，坐在雷恩腿上。"
    translate None cyne_badend_0125:
        rs wneu "我为你还不够吗？我处理了你母亲。我把你捧上新高度。看啊，现在我们统治着整个锡德卡汉。"
    translate None cyne_badend_0126:
        c "...."
    translate None cyne_badend_0127:
        c "我不想统治锡德卡汉。我只要你就好。"
    translate None cyne_badend_0128:
        rs "…真是无聊透顶。对你期望过高了。把你恶心的爱离我远点。"
    translate None cyne_badend_0129:
        c "雷恩，求求你—"
    translate None cyne_badend_0130:
        show bg throne with hpunch
        rs wang "别用那个该死的名字叫我！"
    translate None cyne_badend_0131:
        c wang "…你…你不可能是雷恩。"
    translate None cyne_badend_0132:
        rsbad wsmi "噢，可你总说雷恩是迟钝的那个。你反应真够慢的。"
    translate None cyne_badend_0133:
        c "你是谁？！你把他怎么了？！"
    translate None cyne_badend_0134:
        rsbad "很遗憾他早就死了。幸好他活够久把这具身体给了我。"
    translate None cyne_badend_0135:
        "金发青年从神秘男人腿上弹开，举起手摆出防御姿态。"
    translate None cyne_badend_0136:
        rsbad "跑吧，尽管跑。我不会拦你。没人会相信你说的话。"
    translate None cyne_badend_0137:
        "在他所有的岁月里，他从未真正崩溃过—然而此刻，当他回忆起与雷恩共度的时光，泪水如暴雨般从他脸颊滚落。"
    translate None cyne_badend_0138:
        cmn "我怎么能相信这就是他…!？"
    translate None cyne_badend_0139:
        "然后他开始奔跑。一如既往地奔跑。"


    scene black with dis2

    if achievement.has("cyne_badend"):
        pass
    else:
        $ renpy.display_notify("成就解锁：永恒奔跑者")

    python:
        achievement.grant("cyne_badend")
        achievement.sync()

    translate None cyne_badend_0140:
        "他不停奔跑，直到双腿如火灼般疼痛，肌肉酸痛如遭鞭笞。他冲上街道，仰望着天空。 "
    translate None cyne_badend_0141:
        "只剩他孤身一人。"
    window hide dissolve
    return
