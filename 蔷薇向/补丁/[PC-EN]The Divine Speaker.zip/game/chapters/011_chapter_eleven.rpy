label chapter_eleven_start:

    scene bg nox bed with dissolve:
        size (1920, 1080) crop (0, 290, 1330, 789)
        linear 35.0 crop (550, 290, 1330, 789)
    window show dissolve
    translate None chapter_eleven_0001:
        "房间黑暗而闷热。从外观来看，这里已经很久没人使用了。"
    translate None chapter_eleven_0002:
        "空气中弥漫着那种气味。像是多年未被触碰的旧书。像是沉积多年无人清扫的灰尘。"
    translate None chapter_eleven_0003:
        "不过我想我也没法挑三拣四了。"
    translate None chapter_eleven_0004:
        "诺克斯说我们应该锁好门睡觉，但我实在按捺不住好奇心…"

    window hide

    menu:
        "环顾房间":
            window show dissolve
            jump nox_search

        "锁门睡觉":
            window show dissolve
            jump nox_sleep

label nox_search:
    scene bg nox bed with dissolve:
        size(1920, 1080)
    show raen n dim neu at center with dis
    translate None chapter_eleven_0005:
        "稍微查看一下应该没关系吧？要是能找到根蜡烛什么的…"
    translate None chapter_eleven_0006:
        "我在房间里摸索着，最后来到一张桌子前。我在桌面上摸索，发现了一个小盒子。"
    show raen n dim sur with dis
    translate None chapter_eleven_0007:
        "啊，是一盒火柴！"
    translate None chapter_eleven_0008:
        "我将火柴在盒侧划过，很快桌上就洒满柔和温暖的亮光。"
    translate None chapter_eleven_0009:
        "这些是些什么东西…？"
    play music "sounds/bgm/creepy.ogg" fadein 3.0
    translate None chapter_eleven_0010:
        "成堆的纸张、书本、小玩意儿…真够乱的。"

    window hide
    jump nox_room


label nox_room:
    menu:
        "翻看书本" if search_books:
            $ about_NoxHouse.locked = False
            $ search_books = False
            $ search_sleep = True
            $ search_badcount +=1
            window show dissolve
            jump room_books

        "查看那叠纸" if search_paper:
            $ about_NoxHouse.locked = False
            $ search_paper = False
            $ search_sleep = True
            $ search_badcount +=1
            window show dissolve
            jump room_paper

        "那是首饰吗…？" if search_jewellery:
            $ about_NoxHouse.locked = False
            $ search_jewellery = False
            $ search_sleep = True
            $ search_badcount +=1
            window show dissolve
            jump room_jewellery

        "我想我最好别再看了" if search_sleep:
            window show dissolve
            jump nox_sleep

label room_books:
    translate None chapter_eleven_0011:
        "这么多书…我猜这就是我刚才闻到的味道来源。"
    translate None chapter_eleven_0012:
        play sound "sounds/sfx/paperrustle.ogg" fadeout 1.0
        "我随手拿起几本快速浏览。这些都是图画书。"
    translate None chapter_eleven_0013:
        "但当我凑近看时…发现所有的文字都被涂掉了…"
    translate None chapter_eleven_0014:
        "不仅如此，每个角色眼睛上都被画了小叉号…"
    show raen n dim sad with dis
    translate None chapter_eleven_0015:
        "有点瘆人…"
    translate None chapter_eleven_0016:
        "我又拿起另一本书。黑色皮质封面。打开后映入眼帘的是潦草的手写体。这肯定是某人的日记，可能是个孩子的。"
    translate None chapter_eleven_0017:
        "直接看这个不太好吧？日记是私人物品。"
    translate None chapter_eleven_0018:
        "我快速翻动书页，但当看到某个词时突然停住了。"
    show raen n dim sur with dis
    translate None chapter_eleven_0019:
        rs "卡斯皮安。"
    translate None chapter_eleven_0020:
        "上面写着\"我遇见一个叫卡斯皮安的男人。他穿着很古怪。"
    show black2 with dis
    translate None chapter_eleven_0021:
        n "‘妈妈让他住在我们家，说他无家可归。’"
    translate None chapter_eleven_0022:
        "我翻到下一页。"
    translate None chapter_eleven_0023:
        n "‘卡斯太棒了！他陪我玩了一整天，还说我们可以做最好的朋友！希望我们能永远在一起。’"
    translate None chapter_eleven_0024:
        "下一页…"
    show raen n dim sad with dis
    translate None chapter_eleven_0025:
        n "它不肯离开。说我们现在是最好的朋友了。"
    translate None chapter_eleven_0026:
        n "‘我告诉它我想要卡斯回来。’"
    translate None chapter_eleven_0027:
        n "‘它把我关在地下室三天作为惩罚。’"
    translate None chapter_eleven_0028:
        "等等，什么？"
    hide black2 with dis
    translate None chapter_eleven_0029:
        "仔细看时发现有很多页都被撕掉了。"
    translate None chapter_eleven_0030:
        "只剩下最后一页。我紧张地翻过去。"
    show black2 with dis
    translate None chapter_eleven_0031:
        n "{size=+20}‘你为什么在看这个？’{/size}"

    hide black2
    play sound "heartbeat.ogg"

    show layer master at hpunch
    show raen n dim wor with dis

    $ about_NoxHouse._text.append("一本看起来像儿童日记的东西。内容极其诡异，还提到了卡斯皮安的名字。里面写到主人\"作为惩罚\"被关在地下室三天。")
    translate None chapter_eleven_0033:
        "我啪地合上了{a=set_entry:enc_mysteries->about_NoxHouse}{color=#DA70D6}这本书{/color}{/a}。心脏剧烈跳动得像是要蹦出胸膛。"
    translate None chapter_eleven_0034:
        "我不该看那个的。 "
    translate None chapter_eleven_0035:
        "脑海里有个声音反复告诉我真的不该看这个…"
    translate None chapter_eleven_0036:
        "我用眼角余光扫视房间四周。"
    translate None chapter_eleven_0037:
        "这里依然只有我一个人。我在过度反应。黑暗里并没有藏着什么人。"
    show raen n dim sad with dis
    translate None chapter_eleven_0038:
        "我把书放回原位，深吸一口气让自己镇定下来。"
    translate None chapter_eleven_0039:
        "也许我该直接去睡觉…"


    if search_badcount == 3:
        jump badend2
    window hide
    jump nox_room

label room_paper:
    translate None chapter_eleven_0040:
        "这里有厚厚一沓纸张…"
    translate None chapter_eleven_0041:
        "我快速翻动信件浏览内容。没有一句能看明白的。"
    show black2 with dis
    translate None chapter_eleven_0042:
        n "‘伸手触碰阳光，可能会灼伤你。 \n投身黑暗之中，就能获得救赎。‘"
    translate None chapter_eleven_0043:
        n "‘献祭你自己，就能得到更多回报。’"
    hide black2 with dis
    show raen n dim wor with dis
    translate None chapter_eleven_0044:
        "奇怪。"
    translate None chapter_eleven_0045:
        "我又拿起一封信。"
    show black2 with dis
    translate None chapter_eleven_0046:
        n "‘他变了。不再像以前那样明媚。’"
    translate None chapter_eleven_0047:
        n "‘他不再玩耍。白天总是待在自己房里。 \n到了晚上，不知去向。’"
    translate None chapter_eleven_0048:
        n "‘真开心。他终于成为我们真正的儿子了。’"
    hide black2 with dis
    translate None chapter_eleven_0049:
        "太太太诡异了…."
    translate None chapter_eleven_0050:
        "我又翻了一遍那堆纸。"
    show raen n dim sur with dis
    translate None chapter_eleven_0051:
        "哦，这是什么？"
    translate None chapter_eleven_0052:
        "最下面有张画，潦草地画在皱巴巴的纸上。"
    translate None chapter_eleven_0053:
        "画上是两个牵着手的人。看样子是小孩画的。"
    translate None chapter_eleven_0054:
        "不过画里有些不对劲。"
    translate None chapter_eleven_0055:
        "左边的人好像…满身是血，右边人的脸被涂得乱七八糟。"
    show raen n dim sad with dis
    translate None chapter_eleven_0056:
        "嗯…"

    $ about_NoxHouse._text.append("关于\"整天待在房间，夜里就消失\"孩子的诡异信件。还有小孩和涂得乱七八糟的血人牵手的画。")
    translate None chapter_eleven_0057:
        "我放下{a=set_entry:enc_mysteries->about_NoxHouse}{color=#DA70D6}这幅画{/color}{/a}。不确定这些有没有意义，但确实令人毛骨悚然。"
    show raen n dim wor with dis
    translate None chapter_eleven_0058:
        "我还应该继续查看四周吗？"


    if search_badcount == 3:
        jump badend2
    window hide
    jump nox_room


label room_jewellery:
    show raen n dim neu with dis
    translate None chapter_eleven_0059:
        "那边有什么东西在闪闪发光…"
    translate None chapter_eleven_0060:
        "我把它举到火柴旁。珠子？"
    translate None chapter_eleven_0061:
        "有点缠在一起，但我觉得这是条项链…"
    translate None chapter_eleven_0062:
        "金质的，镶着白色宝石。看起来很昂贵。"
    show raen n dim sad with dis
    translate None chapter_eleven_0063:
        rs "很漂亮，但不太实用…"

    $ about_NoxHouse._text.append("一只精美的耳环，但只有单只。另外那只配对的耳环不见了。")

    translate None chapter_eleven_0064:
        "当我把耳环放回去时，注意到了别的东西。一个{a=set_entry:enc_mysteries->about_NoxHouse}{color=#DA70D6}耳环{/color}{/a}。"
    translate None chapter_eleven_0065:
        rs "只有一只…？"
    translate None chapter_eleven_0066:
        "另一只不见了。"
    translate None chapter_eleven_0067:
        "真恼人，不过倒也不算反常。耳环的主人肯定很着急。"
    translate None chapter_eleven_0068:
        "好吧，这东西没什么用处。"


    if search_badcount == 3:
        jump badend2
    window hide
    jump nox_room

label badend2:
    show raen n dim sad with dis
    translate None chapter_eleven_0069:
        "为什么这些物品都这么诡异？这里以前是谁的房间吗？"
    translate None chapter_eleven_0070:
        "重新查看这些物品后，那本日记可能是最有趣的。是谁写的？诺克斯？"
    translate None chapter_eleven_0071:
        play sound "sounds/sfx/clothrustle.ogg" fadeout 1.0
        "我没法询问，但他应该是最有可能的。"


    show raen n dim sur with dis
    translate None chapter_eleven_0072:
        "等等…那是什么声音？"
    translate None chapter_eleven_0073:
        "我完全静止不动，竖耳倾听。"
    play sound "sounds/sfx/grip.ogg" fadeout 1.0
    translate None chapter_eleven_0074:
        "这声音…听起来像是从外面传来的…？"
    play sound "sounds/sfx/dooropen3.ogg" fadeout 1.0
    show raen n dim  wor with dis
    translate None chapter_eleven_0075:
        rs "......."

    window hide

    menu:
        "快躲起来！":
            window show dissolve
            jump nox_hide

        "堵住门！":
            window show dissolve
            jump nox_door



label nox_hide:
    translate None chapter_eleven_0076:
        "我的眼睛在房间里慌乱扫视。躲哪，躲哪？！"
    translate None chapter_eleven_0077:
        "我能躲到哪里去？！？"
    translate None chapter_eleven_0078:
        "没时间多想了。我扑进衣柜，顺手关上了门。"


    hide raen
    show black
    with dissolve
    translate None chapter_eleven_0079:
        "是谁…外面是谁..？"
    translate None chapter_eleven_0080:
        "应该只是福恩或莱奥斯吧？赛恩…？"
    translate None chapter_eleven_0081:
        "内心有个声音告诉我不要出声呼唤他们。"
    translate None chapter_eleven_0082:
        play sound "sounds/sfx/doorcreak.ogg" fadeout 1.0
        "门吱呀一声打开，我听见缓慢的脚步声。那个身影在房间里走动。"
    translate None chapter_eleven_0083:
        "我听见纸张的沙沙声…还有金属碰撞的叮当声.."
    translate None chapter_eleven_0084:
        "我屏住呼吸。神明在上，若你存在，别让那人发现我。"
    translate None chapter_eleven_0085:
        "脚步声持续着。在房间里来回踱步，最终停了下来。"
    translate None chapter_eleven_0086:
        "一片至寂。他已经离开了吗？"

    window hide


    menu:
        "离开衣柜":
            window show dissolve
            jump wardrobe_leave

        "再多待会儿":
            window show dissolve
            jump wardrobe_stay


label wardrobe_leave:
    translate None chapter_eleven_0087:
        "我想现在应该安全了…"
    show bg nox bed with dissolve
    translate None chapter_eleven_0088:
        "我松了口气。该去锁那扇门了-"
    show black with hpunch
    translate None chapter_eleven_0089:
        rs wor "啊啊啊啊啊！"
    translate None chapter_eleven_0090:
        "前一秒我刚踏出衣柜，下一秒某种黑暗突然遮蔽了视线。"
    translate None chapter_eleven_0091:
        "那是什么？！是谁？！我试图扯开蒙眼的布料，但它纹丝不动。"
    translate None chapter_eleven_0092:
        "我拼命挣扎反抗袭击者，但为时已晚。眼皮突然变得沉重…"

    window hide dissolve
    jump badend2cont

label wardrobe_stay:
    translate None chapter_eleven_0093:
        "不，我还不能出去。还没听见他们离开的声音…"
    translate None chapter_eleven_0094:
        "我试图保持安静，但我的心跳仿佛每秒百万次。必要时，我宁愿整晚都躲在这里。"
    translate None chapter_eleven_0095:
        "我闭上眼睛仔细聆听。一片寂静。"
    translate None chapter_eleven_0096:
        "没有移动声，没有摩擦声，没有呼吸声…"
    translate None chapter_eleven_0097:
        play sound "sounds/sfx/dooropen3.ogg" fadeout 1.0
        "终于，我又听到了动静。这声音持续了仿佛几小时之久，直到听见门被轻轻关上。"
    translate None chapter_eleven_0098:
        "现在…现在安全了吗…？"
    translate None chapter_eleven_0099:
        "我探出头去。外面空无一人。"
    translate None chapter_eleven_0100:
        "机不可失。"
    scene bg nox bed with dissolve
    translate None chapter_eleven_0101:
        "我冲出来奔向房门。咔嗒。"

    if achievement.has("raen_search"):
        pass
    else:
        $ renpy.display_notify("成就解锁：雷恩，侦探大师")
    python:
        achievement.grant("raen_search")
        achievement.sync()
    translate None chapter_eleven_0102:
        "我锁上了门。"
    translate None chapter_eleven_0103:
        "为什么我刚进来时没立即上锁？！"
    translate None chapter_eleven_0104:
        "即便房门已安全关闭…我依然毫无安全感。"
    translate None chapter_eleven_0105:
        "我想今晚最好直接睡觉。如果真能睡得着的话…"
    translate None chapter_eleven_0106:
        "我窜上床用被子紧紧裹住自己。这样感觉稍安全些。"
    translate None chapter_eleven_0107:
        "正当我即将入睡时，又听到了声响。某种…轻叩声…？"
    translate None chapter_eleven_0108:
        "我悄悄下床，将耳朵贴在门上。"
    translate None chapter_eleven_0109:
        "没错，是有轻微的敲击声。"
    translate None chapter_eleven_0110:
        "鉴于先前发生的事，我觉得不该查看…"
    translate None chapter_eleven_0111:
        "就偷瞄一眼应该没关系吧？"

    jump choice_eighteen_done

label nox_door:
    play sound "sounds/sfx/fallonground.ogg" fadeout 1.0
    translate None chapter_eleven_0112:
        "根本来不及思考。我用身体猛撞房门死死抵住。"
    translate None chapter_eleven_0113:
        "寂静。门把手停止了转动。"
    translate None chapter_eleven_0114:
        "没有任何力量与我抗衡。难道是我的幻觉…？"

    window hide

    menu:
        "锁门睡觉":
            window show dissolve
            jump door_lock

        "偷看外面":
            window show dissolve
            jump door_peek

label door_lock:
    show raen n dim sad with dis
    translate None chapter_eleven_0115:
        "不值得冒险。我该锁好门直接睡下。"
    translate None chapter_eleven_0116:
        "我甚至不想知道门外是谁。"
    translate None chapter_eleven_0117:
        "咔嗒。锁舌入扣，我挪回床边。寒夜里，毛毯的温暖让我稍感安心。"


    if achievement.has("raen_search"):
        pass
    else:
        $ renpy.display_notify("成就解锁：雷恩，侦探大师")

    python:
        achievement.grant("raen_search")
        achievement.sync()

    translate None chapter_eleven_0118:
        "最好忘掉所有这些，好好睡一觉。"
    hide raen with dissolve
    translate None chapter_eleven_0119:
        "我在床上舒展四肢。这床真大！在家时我们只有双层床。"
    translate None chapter_eleven_0120:
        "刚有睡意又闻异响…"
    translate None chapter_eleven_0121:
        "我悄悄下床，将耳朵贴在门上。"
    translate None chapter_eleven_0122:
        "没错，是有轻微的敲击声。"
    translate None chapter_eleven_0123:
        "鉴于先前发生的事，我觉得不该查看…"
    translate None chapter_eleven_0124:
        "就偷瞄一眼应该没关系吧？"

    jump choice_eighteen_done

label door_peek:
    translate None chapter_eleven_0125:
        "是幻觉吗..？"
    translate None chapter_eleven_0126:
        "不，不可能。我分明听见门把手在转动。"
    translate None chapter_eleven_0127:
        "可能是莱奥斯或赛恩….甚至是福恩，此刻他正惊恐地被关在门外…"
    translate None chapter_eleven_0128:
        "我将手搭上门把时艰难地咽了下口水。谁能想到开个门竟让人如此紧张。"
    translate None chapter_eleven_0129:
        "可能只是错觉吧，确认一下总没坏处。"
    translate None chapter_eleven_0130:
        play sound "sounds/sfx/doorcreak.ogg" fadeout 1.0
        "我把头探出门外。"
    translate None chapter_eleven_0131:
        "咦，外面果然没有人。"
    translate None chapter_eleven_0132:
        "还是乖乖睡觉比—"

    hide raen
    show black
    with hpunch
    translate None chapter_eleven_0133:
        "未等我反应，一团黑影便充斥了我的视野。"
    translate None chapter_eleven_0134:
        "有人用东西捂住了我的脸。我拼命挣扎，但为时已晚。困意袭来，我缓缓闭上了眼睛。"

    window hide dissolve
    jump badend2cont

label badend2cont:
    stop music fadeout 1.0
    scene black with dissolve
    pause(1.5)
    window show dissolve
    translate None chapter_eleven_0135:
        rs hur "唉…"
    translate None chapter_eleven_0136:
        "当我再次睁眼，迎接我的是更浓重的黑暗。"
    translate None chapter_eleven_0137:
        "太阳穴传来尖锐的刺痛。"
    translate None chapter_eleven_0138:
        rs hur "这是……"
    translate None chapter_eleven_0139:
        "我在哪…？"
    translate None chapter_eleven_0140:
        "刚才明明…还在自己房间……"
    translate None chapter_eleven_0141:
        rs sur "…咦？！"
    translate None chapter_eleven_0142:
        "我试图抬起双臂，却发现被牢牢固定。无论怎么用力，都有东西将我的手臂死死缚住。"
    translate None chapter_eleven_0143:
        rs hur "救命！来人啊！"
    translate None chapter_eleven_0144:
        rs hur "莱奥斯！福恩！赛恩！求求你们！"
    translate None chapter_eleven_0145:
        "我的呼救声在漆黑的房间里回荡。"
    translate None chapter_eleven_0146:
        play music "sounds/bgm/Creepy.ogg" fadein 2.0
        u "他们不会来救你的。"
    translate None chapter_eleven_0147:
        rs hur "谁在那里？！"
    translate None chapter_eleven_0148:
        "耳畔响起低语。我扭头寻找，却空无一人。"
    translate None chapter_eleven_0149:
        u "你有份有趣的礼物呢，对吧？"
    translate None chapter_eleven_0150:
        rs sur "什…什么？"
    translate None chapter_eleven_0151:
        u "而且你闻起来…美味得不可思议。"
    translate None chapter_eleven_0152:
        "某种湿漉漉的东西从我的颈窝爬上了耳垂。"
    translate None chapter_eleven_0153:
        rs hur "离我远点！"
    translate None chapter_eleven_0154:
        u "离你远点？"
    translate None chapter_eleven_0155:
        u "…让我们看看这份骨气能维持多久，如何？"
    translate None chapter_eleven_0156:
        rs hur "放开我！"
    translate None chapter_eleven_0157:
        "空气再度陷入死寂。"
    translate None chapter_eleven_0158:
        "我凝神倾听，却捕捉不到任何声响。"
    translate None chapter_eleven_0159:
        "我拼命扭动束缚，却纹丝不动。我想掀翻椅子，却发现它被钉死在地面。"
    translate None chapter_eleven_0160:
        "不，这没问题对吧？一定是场噩梦。"
    translate None chapter_eleven_0161:
        "没错，噩梦。只要闭上眼睛，就会在自己床上醒来。"
    translate None chapter_eleven_0162:
        "虽然缓慢，但我的意识终于开始模糊。"

    stop music fadeout 2.0

    window hide dissolve
    pause(2.0)
    translate None chapter_eleven_0163:
        n "…..错了…要逃……"
    translate None chapter_eleven_0164:
        n "…同伴们…被困……"
    translate None chapter_eleven_0165:
        n "…快醒醒。"

    scene gallery_51 with Dissolve(2):
        xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.8
        linear 30.0 xpos 0.5 ypos 1.65 xanchor 0.5 yanchor 1.0 zoom 1.8

    window show dissolve
    translate None chapter_eleven_0166:
        "现在过去多久了？"
    translate None chapter_eleven_0167:
        "几周？几个月？几年？"
    translate None chapter_eleven_0168:
        "我已经算不清了。"
    translate None chapter_eleven_0169:
        "这里真的存在时间吗？我要永远困在这里了吗？"
    translate None chapter_eleven_0170:
        "合上眼帘，与睁眼毫无差别。上一次见到光明是何时？"
    translate None chapter_eleven_0171:
        "每个细微动作都灼烧着手腕脚踝。束缚从未松动，更遑论解除。"
    translate None chapter_eleven_0172:
        "嘴唇干裂出血。试图舔舐，却无济于事。"
    translate None chapter_eleven_0173:
        "福恩…莱奥斯…赛恩……"
    scene gallery_51b with dis3
    translate None chapter_eleven_0174:
        play music "sounds/bgm/scary.ogg" fadein 1.0
        u "…终于放弃了吗？"
    translate None chapter_eleven_0175:
        rs "…谁在那里…？"
    translate None chapter_eleven_0176:
        "时隔多年，那个声音再次呼唤着我。"
    translate None chapter_eleven_0177:
        "从前它令我恐惧。如今听来却宛若天籁。"
    translate None chapter_eleven_0178:
        u "我问，你放弃了吗？"
    translate None chapter_eleven_0179:
        "如果我答应…就能获得解脱吗？"
    translate None chapter_eleven_0180:
        rs "我…放弃了…"
    translate None chapter_eleven_0181:
        u "你能帮帮我吗？"
    translate None chapter_eleven_0182:
        rs "….好。"
    translate None chapter_eleven_0183:
        u "触碰我的手。"
    translate None chapter_eleven_0184:
        rs "...?"
    translate None chapter_eleven_0185:
        "我摸索着伸出手，手腕仍无法大幅移动。当触碰到某个东西的瞬间—"
    scene gallery_51c with hpunch
    translate None chapter_eleven_0186:
        rs "呃啊！"
    translate None chapter_eleven_0187:
        "一阵刺痛从指尖窜上手臂，最终汇聚在胸口。那只紧握我的手丝毫不给我挣脱的机会。"
    translate None chapter_eleven_0188:
        "铁锈味在空气中弥漫，温热血雾在胸膛扩散。"
    translate None chapter_eleven_0189:
        "他松开了手，但疼痛仍在持续。"
    translate None chapter_eleven_0190:
        u "….有意思。你会很有利用价值。"
    translate None chapter_eleven_0191:
        play sound "sounds/sfx/walkinghall2.ogg" fadeout 2.0
        "石板上渐远的脚步声。"

    scene gallery_51e with dissolve:
        xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.21
    translate None chapter_eleven_0192:
        rs "等等！我都照做了！"
    translate None chapter_eleven_0193:
        rs "求求你…放了我…"
    translate None chapter_eleven_0194:
        "我想哭，却流不出眼泪。"
    translate None chapter_eleven_0195:
        "福恩，莱奥斯，赛恩…为什么…"
    scene gallery_51d with dissolve:
        xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.21
    translate None chapter_eleven_0196:
        "为什么不来救我？"

    if achievement.has("nox_giveup"):
        pass
    else:
        $ renpy.display_notify("成就解锁：你放弃了吗？")

    python:
        achievement.grant("nox_giveup")
        achievement.sync()

    $ quick_menu = False
    window hide
    scene black
    with Dissolve(2.0)
    return


label nox_sleep:
    hide raen with dis
    translate None chapter_eleven_0197:
        "或许现在睡觉是最好的选择。诺克斯让我们锁门时的神情…令人不寒而栗。我会乖乖听话。"
    translate None chapter_eleven_0198:
        "当我转动门锁到一半时，走廊突然传来声响。"
    translate None chapter_eleven_0199:
        "那是什么声音？"
    translate None chapter_eleven_0200:
        "虽然他说要锁门睡觉，但现在我有点好奇…"
    translate None chapter_eleven_0201:
        "就看一眼应该没关系吧？"

    jump choice_eighteen_done

label choice_eighteen_done:
    play sound "sounds/sfx/doorcreak.ogg" fadeout 1.0
    translate None chapter_eleven_0202:
        "推开门缝窥视，那个敲击声在门外更清晰了…"
    translate None chapter_eleven_0203:
        "声音来自…走廊尽头。富有节奏的敲击。"
    translate None chapter_eleven_0204:
        "无论怎么眯眼凝视，黑暗都遮蔽了远方。要想弄清楚只能靠近…"
    translate None chapter_eleven_0205:
        "….我有点害怕。"
    translate None chapter_eleven_0206:
        "按理说锁好门就该作罢。不管那是什么都与我无关。"
    translate None chapter_eleven_0207:
        "但另一方面…我实在好奇。"
    translate None chapter_eleven_0208:
        "假装权衡选择毫无意义。按捺不住的好奇心终占上风。"

    scene bg nox house night2 with dissolve:
        xanchor 0.08 zoom 2.25
        linear 30 yanchor 861

    translate None chapter_eleven_0209:
        "踏出房间沿走廊前行。敲击声停了，我仍继续前进。"
    translate None chapter_eleven_0210:
        rs sad "…有人吗？"
    translate None chapter_eleven_0211:
        "我的声音在走廊回荡，最终消失。"
    translate None chapter_eleven_0212:
        "死寂。空洞压抑的死寂。"
    translate None chapter_eleven_0213:
        "突然脊背发凉。是不是有人在…盯着我？"
    translate None chapter_eleven_0214:
        "我完全静止不动，用双眼扫视四周。但没有看到任何人…."
    translate None chapter_eleven_0215:
        "好吧，我确实该回去睡觉了。真不想在外面多待-"

    stop music fadeout 1.0
    scene bg nox house night2:
        yanchor 874 zoom 2.15
    show cyne c dark hap with hpunch
    translate None chapter_eleven_0216:
        c "哇！"
    translate None chapter_eleven_0217:
        rs wor "啊！"


    play music "sounds/bgm/Fooling Around Tiny.ogg" fadein 1.0
    show bg nox house night2:
        yanchor 218 zoom 1.6
    show cyne m dark hap at closeright
    show raen m dark emb at closeleft
    with dis
    translate None chapter_eleven_0218:
        c "哈哈哈哈。"
    translate None chapter_eleven_0219:
        rs "赛恩？！"
    translate None chapter_eleven_0220:
        rs "这不好笑！"
    show cyne m mis with dis
    translate None chapter_eleven_0221:
        c "抱歉抱歉，吓到你了吗？"
    translate None chapter_eleven_0222:
        c "实在忍不住，你刚才的样子太惊慌了！就想小小地吓你一跳。"
    show raen m dark sad with dis
    translate None chapter_eleven_0223:
        rs "....."
    translate None chapter_eleven_0224:
        rs "你大半夜在这儿干嘛？"
    show cyne m dark sur with dis
    translate None chapter_eleven_0225:
        c "这话该我问你才对。"
    show raen m dark emb with dis
    translate None chapter_eleven_0226:
        rs "什…！我听到奇怪的敲击声才出来查看的。"
    show cyne m dark hap with dis
    translate None chapter_eleven_0227:
        c "噢，糟糕。那是我弄的。"
    translate None chapter_eleven_0228:
        rs "现在看出来了…"
    show raen m dark sad with dis
    translate None chapter_eleven_0229:
        rs "所以该你回答我了？"
    translate None chapter_eleven_0230:
        c "那个诺克斯说了那么多神神秘秘的话，我怎么可能睡得着？"
    show cyne m dark mis with dis
    translate None chapter_eleven_0231:
        c "就想调查看看！感觉自己在当侦探！"
    translate None chapter_eleven_0232:
        rs "你难道不害怕？"
    translate None chapter_eleven_0233:
        c "要是我说害怕…你会抱紧我吗？"
    show raen m dark sur with dis
    translate None chapter_eleven_0234:
        rs "抱紧你？！"
    translate None chapter_eleven_0235:
        rs "这不是应该和…恋人之间才会做的事吗…？"
    show cyne m dark sur with dis
    translate None chapter_eleven_0236:
        c "恋人…？"
    translate None chapter_eleven_0237:
        c "谁告诉你这些的？"
    show raen m dark sad with dis
    translate None chapter_eleven_0238:
        rs "福恩说的。他说外面世界里人们会谈恋爱、接吻什么的…"
    translate None chapter_eleven_0239:
        c "这说法真奇怪。"
    translate None chapter_eleven_0240:
        c "听你语气好像完全不懂爱为何物。"
    translate None chapter_eleven_0241:
        rs "确实不懂。我才刚听说这种事。"
    show cyne m dark cas with dis
    translate None chapter_eleven_0242:
        c "你还挺年轻的吧？以后慢慢就明白了。"
    translate None chapter_eleven_0243:
        rs "你明明比我更小…？"
    show cyne m dark neu with dis
    translate None chapter_eleven_0244:
        c "我22岁。"
    show raen m dark sur with dis
    translate None chapter_eleven_0245:
        rs "居然比我大四岁？！"
    show cyne m dark mis with dis
    translate None chapter_eleven_0246:
        c "别担心，我可以教你所有你不懂的事。"
    show raen m dark sad with dis
    translate None chapter_eleven_0247:
        rs "什么…？"
    translate None chapter_eleven_0248:
        rs "总之重点不是这个…我也是最近才知道…"
    translate None chapter_eleven_0249:
        c "嗯…听起来很有趣呢！"
    translate None chapter_eleven_0250:
        c "要不要去我房间继续聊？毕竟我开始觉得害怕了呢。"
    translate None chapter_eleven_0251:
        rs "呃…"
    translate None chapter_eleven_0252:
        rs "好吧。反正外面怪阴森的。"
    show cyne m dark hap with dis
    translate None chapter_eleven_0253:
        c "对对！"
    translate None chapter_eleven_0254:
        c "我也不想你绊倒…所以为安全起见还是牵手比较好？"

    window hide

    menu:
        "好吧":
            $ cyne_relationship +=2
            window show dissolve
            jump cyne_hands

        "我觉得我不会…":
            window show dissolve
            jump cyne_nohands

label cyne_hands:
    translate None chapter_eleven_0255:
        rs "这…听起来挺合理的…大概？"
    translate None chapter_eleven_0256:
        "他的手指自然地滑入我的指缝，与我们十指相扣。"
    translate None chapter_eleven_0257:
        rs "这是我第一次和人这样牵手.."
    show cyne m dark sur with dis
    translate None chapter_eleven_0258:
        c "怎样，像这样？"
    translate None chapter_eleven_0259:
        "他把我们交握的手举到我眼前。彼此缠绕的指节有种…奇妙的美感。"
    show raen m dark sad with dis
    translate None chapter_eleven_0260:
        rs "嗯…"
    translate None chapter_eleven_0261:
        c "感觉不错吧？"
    translate None chapter_eleven_0262:
        rs "....."
    translate None chapter_eleven_0263:
        rs "是啊…."
    translate None chapter_eleven_0264:
        "赛恩就这样拽着我，一路来到了他的房间。"

    stop music fadeout 2.0
    jump choice_nineteen_done

label cyne_nohands:
    translate None chapter_eleven_0265:
        rs "什么？我不会绊倒的。我自己能走得好好的。"
    show cyne m dark sad with dis
    translate None chapter_eleven_0266:
        c "切～真扫兴！"
    show raen m dark sur with dis
    translate None chapter_eleven_0267:
        rs "什么…？"
    translate None chapter_eleven_0268:
        c "那来吧，跟我走。"
    translate None chapter_eleven_0269:
        "我跟在赛恩身后回到他的房间，他一路都闷闷不乐的。"

    stop music fadeout 2.0
    jump choice_nineteen_done

label choice_nineteen_done:
    scene bg nox bed flip with fade:
        xpos 0.5 ypos 1.0 xanchor 0.43 yanchor 0.9 zoom 1.2
    translate None chapter_eleven_0270:
        "门在我们身后轻轻砰地关上，赛恩迅速锁上了门。"
    translate None chapter_eleven_0271:
        play music "sounds/bgm/night.ogg" fadein 2.0
        c mis "小心驶得万年船，对吧？"
    translate None chapter_eleven_0272:
        rs sad "嗯…"
    translate None chapter_eleven_0273:
        "赛恩的房间和我那间几乎一模一样。同样的床，同样的桌子，同样的衣柜……"
    translate None chapter_eleven_0274:
        "同样多的灰尘。最近肯定没多少客人来。这么大房子空着有什么意义？"

    scene bg nox bed flip with dissolve:
        xpos 0.5 ypos 1.0 xanchor 0.43 yanchor 0.775 zoom 1.8
        linear 0.5 yanchor 0.8

    translate None chapter_eleven_0275:
        "他在床边坐下并示意我靠近，于是我拉了把椅子面对他坐下。"
    show bg nox bed flip blur
    show cyne m dark sur
    with dis2
    translate None chapter_eleven_0276:
        c "我们还没怎么独处过呢，是吧？"
    translate None chapter_eleven_0277:
        rs sur "呃…我们才刚认识…"
    show cyne m cas with dis
    translate None chapter_eleven_0278:
        c "确实。但感觉好像认识很久了。"
    show cyne m mis with dis
    translate None chapter_eleven_0279:
        c "趁这机会互相了解下吧！我也想和你亲近些！我超～嫉妒福恩和莱奥斯的，他们想粘着你就能粘着！"
    translate None chapter_eleven_0280:
        rs smi"对啊！我也想交朋友！"
    show cyne m hap with dis
    translate None chapter_eleven_0281:
        c "哦，对。朋友！"
    show cyne m dark sur with dis
    translate None chapter_eleven_0282:
        c "嘿我有个主意。我们可以做特别的朋友！怎么样？"
    translate None chapter_eleven_0283:
        rs sur "呃…好啊！"
    show cyne m dark mis with dis
    translate None chapter_eleven_0284:
        c "真是个好孩子…不过先继续刚才的话题吧。"
    show cyne m dark neu with dis
    translate None chapter_eleven_0285:
        c "你说不知道什么是爱是什么意思？"
    translate None chapter_eleven_0286:
        rs con "我真不知该怎么说…在奥雷利亚卡维拉，根本没有爱这个概念。"
    translate None chapter_eleven_0287:
        rs "我也是刚跟着福恩才开始了解的。"
    show cyne m dark sur with dis
    translate None chapter_eleven_0288:
        c "没有爱？完全不存在？"
    translate None chapter_eleven_0289:
        rs "没有。我们都是通过说书人配对，与爱情无关。"
    translate None chapter_eleven_0290:
        rs sad "不过我现在也没完全搞懂爱啦…"
    show cyne m dark neuclo with dis
    translate None chapter_eleven_0291:
        c "嗯…"
    show cyne m dark mis with dis:
        xzoom 1
    translate None chapter_eleven_0292:
        c "那性呢？想和谁上床都行？不用负责？听着可真带劲。"
    translate None chapter_eleven_0293:
        rs sur "我-什么？！"
    show cyne m dark sur with dis
    translate None chapter_eleven_0294:
        c "等等-你在开玩笑吗？"
    translate None chapter_eleven_0295:
        c "你连性是什么都不知道？"
    translate None chapter_eleven_0296:
        rs sad "我…完全不了解。只听过一点…"
    translate None chapter_eleven_0297:
        c "但奥雷利亚卡维拉有小孩对吧？"
    translate None chapter_eleven_0298:
        rs sad "是啊…."
    show cyne m dark neu with dis
    translate None chapter_eleven_0299:
        c "但你不知道他们怎么来的。"
    translate None chapter_eleven_0300:
        rs "没错。"
    show cyne m dark sur with dis
    translate None chapter_eleven_0301:
        c "哇哦。你真是活在与世隔绝的泡泡里。"
    translate None chapter_eleven_0302:
        c "我都要佩服了。"
    translate None chapter_eleven_0303:
        rs neu "其实没有泡泡，我们是被…"
    show cyne m dark cas with dis
    translate None chapter_eleven_0304:
        c "行了行了，我懂。"
    show cyne m dark neu with dis
    translate None chapter_eleven_0305:
        c "所以福恩都和你说什么了？"
    translate None chapter_eleven_0306:
        rs "他告诉我当你胸口有一种温暖的感觉时，那就是你坠入爱河的时刻。然后你们结婚、亲吻之类的事情就会发生。"
    translate None chapter_eleven_0307:
        rs "我还遇到另一个怪人，他也向我解释了一些…"
    show cyne m dark sur with dis
    translate None chapter_eleven_0308:
        c "就这些？"
    show cyne m dark mis with dis
    translate None chapter_eleven_0309:
        c "那你还有很多要学的呢。如果你愿意，我很乐意教你。"
    translate None chapter_eleven_0310:
        rs sur "教我…？"
    show cyne m dark mis with dis
    translate None chapter_eleven_0311:
        c "对啊。你知道的，呃，出于教育目的。"
    translate None chapter_eleven_0312:
        c "反正福恩只告诉了你爱情的一面。无聊的那面。"
    translate None chapter_eleven_0313:
        c "如果你想的话，我可以教你另外一面。"
    translate None chapter_eleven_0314:
        "他人真好。"
    translate None chapter_eleven_0315:
        rs sur "好吧，既然你主动提出…"
    translate None chapter_eleven_0316:
        rs smi "请教导我。"
    show cyne m dark hap with dis
    translate None chapter_eleven_0317:
        c "真的吗？！太—好—了！"
    translate None chapter_eleven_0318:
        c "我以为你肯定会拒绝！"
    translate None chapter_eleven_0319:
        "他看起来兴奋极了。这让我的心跳也加快了些。有太多我不懂的事…"
    translate None chapter_eleven_0320:
        "赛恩真是个好人！"
    translate None chapter_eleven_0321:
        rs sad  "那么…呃…"
    translate None chapter_eleven_0322:
        rs sur "我们从哪里开始？"
    show cyne m dark mis with dis
    translate None chapter_eleven_0323:
        c "别担心，我们可以一瓣一瓣地摘掉你的童贞花瓣。咳咳。"

    scene bg nox bed flip with dis:
        xpos 0.5 ypos 1.0 xanchor 0.43 yanchor 0.9 zoom 1.2

    translate None chapter_eleven_0324:
        "他在我面前站起来，挺直腰背，双手背在身后，像个老师。"

    show cyne m dark neu at closeright
    show raen m dark neu at closeleft
    with dis
    translate None chapter_eleven_0325:
        c "要不我们先从理论开始，然后再进行些更实际的内容？"
    show cyne m dark mis with dis
    translate None chapter_eleven_0326:
        c "像你这样纯洁的男孩，我们得慢慢来。"
    show raen m dark sur with dis
    translate None chapter_eleven_0327:
        rs "Uhhh…? Okay….?"
    show cyne m dark neu with dis
    translate None chapter_eleven_0328:
        c "先从简单的开始吧。你那位蓝发公主说的爱情基本没错。"
    show cyne m dark neuclo with dis
    translate None chapter_eleven_0329:
        c "那些甜蜜的感觉、爱情、婚姻，所有那些温吞的东西。呃，无聊。知道之后会发生什么吗？好东西。"
    translate None chapter_eleven_0330:
        c "我想这差不多算是性启蒙课了吧？"
    translate None chapter_eleven_0331:
        rs "性启蒙…？"
    show cyne m dark neu with dis
    translate None chapter_eleven_0332:
        c "你可以把所有那些肉麻的、甜蜜的废话都做一遍，来场无聊的性爱，生几个孩子毁掉自己的人生，或者…"
    show cyne m dark misclo with dis
    translate None chapter_eleven_0333:
        c "你可以跳过所有无聊的部分。你不必爱上一个人才能和他上床，我向你保证，我们不需要任何孩子。"
    show cyne m dark sur with dis
    translate None chapter_eleven_0334:
        c "等等，等等。你是说你刚才在情趣用品店里闲逛时完全不知道那些东西的用途…？"
    show raen m dark sad with dis
    translate None chapter_eleven_0335:
        rs "我还是完全不懂。"
    hide raen
    hide cyne
    with dis
    translate None chapter_eleven_0336:
        "他来回踱步，陷入沉思。"
    translate None chapter_eleven_0337:
        "他停下来，转身面对我。"
    show cyne m dark mis with dis
    translate None chapter_eleven_0338:
        c "我是说…你还是有屌的吧？"
    translate None chapter_eleven_0339:
        rs emb "什…！"
    show cyne m dark hap with dis
    translate None chapter_eleven_0340:
        c "希望你不介意我坐下来。"

    stop music fadeout 2.5
    window hide dissolve

    scene gallery_53 with dissolve:
        size(1920, 1080) crop (663, 0, 1256, 698)
    window show dissolve
    translate None chapter_eleven_0341:
        c "那么，就像我刚才说的…"
    translate None chapter_eleven_0342:

        c "你确实有屌对吧？"
    translate None chapter_eleven_0343:
        "他的指尖穿过我的发丝，然后缓缓滑下我的身体。越来越往下…"
    translate None chapter_eleven_0344:
        c "看来你确实有一个。"
    translate None chapter_eleven_0345:
        "他用修长的手指轻蹭过我的裤子。"
    translate None chapter_eleven_0346:
        rs "当-当然有啦！"
    translate None chapter_eleven_0347:
        c "那么，一定一定，你有用过一两次吧？"
    translate None chapter_eleven_0348:
        rs "用…？"
    translate None chapter_eleven_0349:
        c "你在跟我害羞吗？"
    translate None chapter_eleven_0350:
        c "这可不行！你必须回答老师提出的所有问题！"
    translate None chapter_eleven_0351:
        c "就算你对爱情没概念，也不代表你没本能对吧？"
    translate None chapter_eleven_0352:
        c "快说吧，告诉我你自慰的所有细节。"
    play music "sounds/bgm/Fooling Around Tiny.ogg" fadein 2.0
    translate None chapter_eleven_0353:
        "他的手指不停挑逗，若即若离，却足以让我感受到…异样。"
    translate None chapter_eleven_0354:
        rs "....."
    translate None chapter_eleven_0355:
        rs "当然有过！但我-我…我控制不住！"
    translate None chapter_eleven_0356:
        "他的手在我身上游走，仿佛在搜寻什么。这让我脊背发颤…还有他对我说话的方式…"
    translate None chapter_eleven_0357:
        "如此撩人又流畅…"
    translate None chapter_eleven_0358:
        c "当然控制不住。你不必愧疚，那东西本就是干这个用的。"
    translate None chapter_eleven_0359:
        c "性爱就是这样。比你自慰快感强烈百倍。跟我做的话，还要爽上千倍。"
    translate None chapter_eleven_0360:
        c "听起来很有趣对吧？"
    translate None chapter_eleven_0361:
        c "所以…"
    translate None chapter_eleven_0362:
        "他用双臂环住我的脖子，直直望进我的眼睛。"
    translate None chapter_eleven_0363:
        c "……要不要上那堂实践课？"

    window hide

    menu:
        "今晚就到这儿吧":
            window show dissolve
            $ cyne_no = True
            jump cyne_nosex

        "…..好吧":
            window show dissolve
            $ cyne_relationship +=2
            jump cyne_yessex

label cyne_nosex:
    translate None chapter_eleven_0364:
        rs "我…我觉得今晚差不多了…"
    translate None chapter_eleven_0365:
        "我艰难地咽了下口水。感觉很棒，但我不确定…朋友之间会这样吗…？"
    translate None chapter_eleven_0366:
        "其实我也没把赛恩当朋友…"
    translate None chapter_eleven_0367:
        c "是不是有点太刺激了？我们可以改天继续享受。"
    translate None chapter_eleven_0368:
        c "反正追得越辛苦，抓到你就越有意思。"
    translate None chapter_eleven_0369:
        rs "什么…？"
    translate None chapter_eleven_0370:
        c "没什么，没什么！"

    stop music fadeout 2.0
    window hide dissolve

    scene bg nox bed flip with dissolve:
        xpos 0.5 ypos 1.0 xanchor 0.43 yanchor 0.9 zoom 1.2
    window show dissolve
    translate None chapter_eleven_0371:
        "他迅速从我腿上跳下，把我也从座位上拽起。这么近看他，确实…有点美？光滑的肌肤，翡翠般的大眼睛…"
    translate None chapter_eleven_0372:
        c hap "好啦快走吧！总不想让你的情人或保镖吃醋吧。"
    translate None chapter_eleven_0373:
        rs sur "谁….？"
    translate None chapter_eleven_0374:
        c hap "晚安咯！"
    show bg nox house night2 with dissolve
    translate None chapter_eleven_0375:
        "他把我推出门，迅速在我面前甩上门。情人…？保镖应该是指莱奥斯…"
    translate None chapter_eleven_0376:
        "我听见他门里传来锁舌滑动的声音。"
    translate None chapter_eleven_0377:
        "总之.."
    translate None chapter_eleven_0378:
        "现在回去睡觉可能是最好的选择。"
    show bg nox bed with dissolve
    translate None chapter_eleven_0379:
        "一进房间我就锁上门，直接钻进被窝。"
    translate None chapter_eleven_0380:
        "我最终闭上了眼睛。这是多么漫长的一天啊。感觉经历了太多事情。"
    translate None chapter_eleven_0381:
        "不过…最近每天都是如此…"

    stop music fadeout 2.0
    window hide dissolve

    jump illranveras

label cyne_yessex:
    if achievement.has("cyne_lesson"):
        pass
    else:
        $ renpy.display_notify("成就解锁：实践课程")

    python:
        achievement.grant("cyne_lesson")
        achievement.sync()

    translate None chapter_eleven_0385:
        rs "….是啊。我…我想要实践课程。"
    translate None chapter_eleven_0386:
        c "这正是我期待的答案。不过，你能不能说得更动听些？毕竟我可是在特意为你破例。"
    translate None chapter_eleven_0387:
        rs "什—！"
    translate None chapter_eleven_0388:
        "他的指尖滑过我的胸膛。每一次触碰都让我止不住地战栗。"
    translate None chapter_eleven_0389:
        rs "啊！拜…拜托了，赛恩？我想让你…教导我…"
    translate None chapter_eleven_0390:
        c "这才像话。"

    scene gallery_53 with Dissolve(1.0):
        size(1920, 1080)
    translate None chapter_eleven_0391:
        "赛恩缓缓将手移向自己的衬衫。一颗，两颗，三颗纽扣相继解开…"
    translate None chapter_eleven_0392:
        c "不来帮帮我吗？"
    translate None chapter_eleven_0393:
        rs "好…好的…"
    translate None chapter_eleven_0394:
        "我颤抖着双手解开了剩余的纽扣，露出他的胸膛。光滑美丽的肌肤…我真想用手抚遍…"
    translate None chapter_eleven_0395:
        "我的声音几乎变调。充满情欲的低语在沉重的呼吸间断续溢出。"
    translate None chapter_eleven_0396:
        "当我抬头看向赛恩时，发现他正紧紧注视着我。"
    translate None chapter_eleven_0397:
        c "你真的很特别。"


    scene gallery_54 with dissolve
    translate None chapter_eleven_0398:
        rs "唔嗯？！"
    translate None chapter_eleven_0399:
        "他的嘴唇深深印上我的，激烈的吻中，一手环住我的后颈，另一手掀起我的衬衫玩弄着胸前。"
    translate None chapter_eleven_0400:
        "在他游走的手与炙热的唇间…"
    translate None chapter_eleven_0401:
        rs "喂，你…"
    translate None chapter_eleven_0402:
        c "有反应了？你自己不也是欲火难耐。"
    translate None chapter_eleven_0403:
        rs "嗯…"
    translate None chapter_eleven_0404:
        rs "我不…唔…"
    translate None chapter_eleven_0405:
        rs "不知道该怎么…"
    translate None chapter_eleven_0406:
        c "所以才需要我指导。跟着我的节奏来！"
    translate None chapter_eleven_0407:
        rs "嗯…啊…"
    translate None chapter_eleven_0408:
        "他的舌头滑入—等等，什么？"
    translate None chapter_eleven_0409:
        rs "你…啊…在做什么…？!"
    translate None chapter_eleven_0410:
        c "嘘，放轻松。"
    translate None chapter_eleven_0411:
        "起初只是浅尝辄止，但很快转为深吻。我试图模仿他的动作，却比想象中困难得多。"
    translate None chapter_eleven_0412:
        "他轻扫我的上颚，继而与我的舌纠缠不休。"
    translate None chapter_eleven_0413:
        "他的爱抚越是深入，我身体的紧绷感就越快消散。他…真的很擅长…"
    translate None chapter_eleven_0414:
        "手指从胸膛一路下滑…挑逗性地轻擦过裤沿。"
    translate None chapter_eleven_0415:
        "指尖勾住我的裤腰。他的舌仍在侵占我的口腔，呼吸逐渐变得困难。"
    translate None chapter_eleven_0416:
        rs "嗯…"
    translate None chapter_eleven_0417:
        "如果他继续这样—"
    show gallery_53 with dissolve
    translate None chapter_eleven_0418:
        c "好了，热身结束。"
    translate None chapter_eleven_0419:
        rs "诶…？"

    translate None chapter_eleven_0420:
        "赛恩柔软的唇忽然撤离，双手重新回到我的后颈。"
    translate None chapter_eleven_0421:
        c "我有种预感，如果再继续下去，你的保镖可能会不高兴。何况还得为下次课程留些教具，对吧？"
    translate None chapter_eleven_0422:
        "他冲我眨眨眼站起身来。"

    play sound "clothrustle.ogg"

    stop music fadeout 2.0

    scene bg nox bed flip:
        xpos 0.5 ypos 1.0 xanchor 0.43 yanchor 0.9 zoom 1.2
    show raen n dark emb at slightright
    show cyne n dark mis at slightleft
    with dissolve

    translate None chapter_eleven_0424:
        "此刻我们分开后，所有血液都涌上了我的脸颊。刚才那是怎么回事？！为什么我…"
    translate None chapter_eleven_0425:
        "太难为情了！"
    $ about_Cyne._text.append("他也是个不错的…\"老师\"。")
    translate None chapter_eleven_0426:
        play music "sounds/bgm/night.ogg" fadein 1.0
        c "所以你觉得呢？我是个{a=set_entry:enc_people->about_Cyne}{color=#87CEEB}好老师{/color}{/a}，对吧？"
    translate None chapter_eleven_0427:
        c "或许我能当你的私人教师！"
    translate None chapter_eleven_0428:
        rs "...................."
    translate None chapter_eleven_0429:
        rs "我…我想我该去睡了…"
    show cyne n dark sad with dis
    translate None chapter_eleven_0430:
        c "哎呀呀，都不愿意陪我过夜吗？"
    translate None chapter_eleven_0431:
        rs "我想我应-"
    translate None chapter_eleven_0432:
        c "啊，虽然说出来有点羞人…但是…"
    translate None chapter_eleven_0433:
        c "本来不想告诉你…"
    translate None chapter_eleven_0434:
        c "我患有不治之症…如果独自过夜可能会死的。"
    show raen n dark sur with dis
    translate None chapter_eleven_0435:
        rs "什么？！"

    window hide

    menu:
        "我当然要留在这里！":
            $ cyne_staynight = True
            $ cyne_relationship +=1
            window show dissolve
            jump cyne_sleepyes

        "等一下…":
            $ cyne_yes = True
            window show dissolve
            jump cyne_sleepno

label cyne_sleepyes:
    translate None chapter_eleven_0436:
        rs "这也太严重了！"
    translate None chapter_eleven_0437:
        c "好丢脸…啊，说完这种话根本没法挽留你了…"
    show raen n dark sad with dis
    translate None chapter_eleven_0438:
        rs "但你会死的！我当然要留下！"
    translate None chapter_eleven_0439:
        c "嘿嘿嘿。"
    translate None chapter_eleven_0440:
        rs "那是什么？"
    show cyne n dark hap with dis
    translate None chapter_eleven_0441:
        c "哦没事，只是在想遇见你真是幸运。"
    show raen n dark sur with dis
    translate None chapter_eleven_0442:
        rs "噢！我，呃…也很高兴认识你。"
    translate None chapter_eleven_0443:
        c "感觉我们在一起会很有趣呢。"
    translate None chapter_eleven_0444:
        rs "是啊，肯定的。"
    translate None chapter_eleven_0445:
        c "不过现在该睡美容觉了。这么光滑的皮肤可不是白来的！"
    show raen n dark sad with dis
    translate None chapter_eleven_0446:
        rs "你居然会在意这种事…？"

    hide raen
    hide cyne
    with dissolve
    translate None chapter_eleven_0447:
        "还没反应过来，赛恩已经躺上床。我想我也该躺下。"
    translate None chapter_eleven_0448:
        "床榻大得让人几乎感觉不到他人存在。就算伸直手脚也碰不到床沿。"
    translate None chapter_eleven_0449:
        "以前也与人同榻而眠过，但这次感觉微妙不同。"
    translate None chapter_eleven_0450:
        "又或许…改变的是我自己。"
    translate None chapter_eleven_0451:
        "正当我静静思索时，忽然有只手探进衬衫轻抚我的胸口。"
    translate None chapter_eleven_0452:
        c hap "你的皮肤也很光滑呢。不介意我摸摸吧？"
    translate None chapter_eleven_0453:
        rs neu "…不介意，请便。"
    translate None chapter_eleven_0454:
        "我们就这样相拥许久，直到沉入梦乡。"

    stop music fadeout 2.0
    window hide dissolve

    jump illranveras

label cyne_sleepno:
    translate None chapter_eleven_0455:
        rs "我当然会留-"
    translate None chapter_eleven_0456:
        rs "等等…"
    translate None chapter_eleven_0457:
        rs "..你是在骗我吧？"
    translate None chapter_eleven_0458:
        c ".............."
    show cyne n dark hap with dis
    translate None chapter_eleven_0459:
        c "啊哈哈，好吧被你识破了！"
    translate None chapter_eleven_0460:
        c "好~~~~吧，今晚我只能孤零零挨冻了。"
    translate None chapter_eleven_0461:
        "他扳过我的身子把我推出了门"
    translate None chapter_eleven_0462:
        rs "喂—等等！"

    window hide dissolve

    scene black with dissolve
    scene bg nox house night2 with hpunch
    window show dissolve
    translate None chapter_eleven_0463:
        c hap "我不在的时候别玩太疯！"
    translate None chapter_eleven_0464:
        c hap "晚安咯！"
    translate None chapter_eleven_0465:
        "砰。他当着我的面关上门，我听见门锁咔嗒落下的声音"
    translate None chapter_eleven_0466:
        "诺克斯宅邸的其他角落仍笼罩在漆黑与至寂中。确实该回房休息了"
    translate None chapter_eleven_0467:
        "我很快循着原路返回房间关上门"

    window hide dissolve

    scene bg nox bed with dissolve:
        xanchor 0.32 yanchor 0.17 zoom 1.5
    window show dissolve
    translate None chapter_eleven_0468:
        "反锁房门后，我终于把自己埋进被褥"
    translate None chapter_eleven_0469:
        "赛恩…我无法相信他的所作所为…"
    translate None chapter_eleven_0470:
        "他触碰我的方式…我满脑子都是那个画面…"
    translate None chapter_eleven_0471:
        "我最终闭上了眼睛。这是多么漫长的一天啊。感觉经历了太多事情。"
    translate None chapter_eleven_0472:
        "不过…最近每天都是如此…"

    stop music fadeout 2.0
    window hide dissolve

    jump illranveras

label illranveras:

    scene black with eye_shut
    pause(0.5)
    translate None chapter_eleven_0473:
        n "命运……聆听……"
    translate None chapter_eleven_0474:
        n "….言者…..更多….."
    translate None chapter_eleven_0475:
        n "…..光明将指引你……"


    scene bg oxhabor night big with Dissolve(2.0):
        size (1920, 1080) crop (0, 290, 1330, 789)
        linear 35.0 crop (550, 290, 1330, 789)
    window show dissolve
    play music "sounds/bgm/forgotten.ogg" fadein 1.0

    translate None chapter_eleven_0476:
        "刺骨寒风掠过奥克斯哈伯郊野，两名男子正并肩而行。步伐不疾不徐，恰能品酌夜色"
    translate None chapter_eleven_0477:
        "他们就这般静默而惬意地行走许久，直到其中一人打破沉寂"

    scene bg oxhabor night big
    show illran n dark armsdown neu at slightright
    show veras n dark neu1 at slightleft
    with dissolve
    translate None chapter_eleven_0478:
        gr "这里丝毫未变，对吧？"
    translate None chapter_eleven_0479:
        pr "还是那种压抑冰冷的氛围。我依然对此存疑"
    translate None chapter_eleven_0480:
        gr "居民们也还是那么阴森。甚至比从前更加神经紧绷"
    show veras n dark sad1 at slightleft
    translate None chapter_eleven_0481:
        pr "…伊尔兰，你在转移话题"
    show illran n dark con with dis
    translate None chapter_eleven_0482:
        i "什么，我？才不会呢"
    translate None chapter_eleven_0483:
        pr "....."
    show illran n dark neu with dis
    translate None chapter_eleven_0484:
        i "好啦好啦。我保证竭尽所能护他们周全"

    window hide dissolve

    scene gallery_55c with dissolve:
        xpos 0.33 ypos 1.06 xanchor 0.5 yanchor 1.0 zoom 1.38
        linear 18.0 xpos 0.65 ypos 1.06 xanchor 0.5 yanchor 1.0 zoom 1.38

    window show dissolve
    translate None chapter_eleven_0485:
        "绿发男子用余光打量着同伴"
    translate None chapter_eleven_0486:
        "细腻白皙的肌肤，下唇缀着两颗小痣。蜜桃色蓬松头发让人忍不住想揉弄。那双失焦的眼睛仍会循声转动，尽管已无法视物"
    translate None chapter_eleven_0487:
        i "…你对他也怀有同样感受对吧？"
    translate None chapter_eleven_0488:
        pr "相遇那刻我就有所感应，但.."
    translate None chapter_eleven_0489:
        pr "他是…我难以界定的存在"
    translate None chapter_eleven_0490:
        i "你认为他可能和你同类吗？"
    translate None chapter_eleven_0491:
        pr "不…但感觉很相近。我不自觉地想靠近他"
    translate None chapter_eleven_0492:
        i "要是还没弄明白就死掉就太遗憾了"
    translate None chapter_eleven_0493:
        pr "伊尔兰"
    translate None chapter_eleven_0494:
        i "维拉斯"
    translate None chapter_eleven_0495:
        v "我们不会让这种事发生"
    translate None chapter_eleven_0496:
        v "话说你戏弄他们的程度真让我惊讶。平时明明友善得多"
    translate None chapter_eleven_0497:
        i "但效果不错不是吗？收获颇丰"
    translate None chapter_eleven_0498:
        v "从他们对问题的反应来看…"
    translate None chapter_eleven_0499:
        i "只可能来自那个地方。寻觅多年，终于有了确切线索"
    translate None chapter_eleven_0500:
        i "到时候…你就能回家了"
    translate None chapter_eleven_0501:
        v "….是啊。"
    scene gallery_55b with Dissolve(1.0):
        xpos 0.36 ypos 1.39 xanchor 0.5 yanchor 1.0 zoom 1.41
        linear 15.0 xpos 0.36 ypos 1.01 xanchor 0.5 yanchor 1.0 zoom 1.41
    translate None chapter_eleven_0502:
        "维拉斯无声地伸出手，探向某种未知的存在"
    translate None chapter_eleven_0503:
        v "整个城镇都弥漫着死亡的气息。充满哀伤与恐惧。但是…我连一个灵魂都看不到。"
    translate None chapter_eleven_0504:
        v "这些谋杀案持续的时间比你活着的时间还要长。但如果它们只是在过去几年才愈演愈烈…那死者至少有数百，甚至上千人。"
    translate None chapter_eleven_0505:
        v "那么，他们的灵魂都去哪儿了？不可能就这样凭空消失。"
    translate None chapter_eleven_0506:
        i "…我不喜欢这种推测的方向。"
    translate None chapter_eleven_0507:
        v "我也是…"
    translate None chapter_eleven_0508:
        v "伊尔兰，我确实说过我们必须保护他们，但是…答应我，如果情况变得太危险，我们就离开。"
    translate None chapter_eleven_0509:
        i "但是—"
    translate None chapter_eleven_0510:
        v "你的生命不该为我而牺牲。"
    translate None chapter_eleven_0511:
        i "..."
    translate None chapter_eleven_0512:
        i "….好吧。你也不许做任何鲁莽的事。"
    translate None chapter_eleven_0513:
        "维拉斯转回目光看向伊尔兰，露出微笑。"
    scene gallery_55 with dissolve:
        xpos 0.53 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.22
    translate None chapter_eleven_0514:
        v "你今天特别听话呢。"
    translate None chapter_eleven_0515:
        i "这可不是人们通常用来形容我的词。"
    translate None chapter_eleven_0516:
        v "那看来我很幸运。能看到你这么多种不同面貌。"
    translate None chapter_eleven_0517:
        i "...."
    translate None chapter_eleven_0518:
        i "….如果觉得冷就告诉我，我们可以找个暖和点的地方住，好吗？"
    translate None chapter_eleven_0519:
        v "不用。你会温暖我的，对吧？"
    translate None chapter_eleven_0520:
        i "…当然。"
    translate None chapter_eleven_0521:
        "夜晚寒凉而黑暗，只有渐盈的月光为他们照亮前路，但比起那座小镇，这样的夜色反而更令人安心。"

    window hide dissolve


    if cyne_staynight:
        jump cyneroom

    if cyne_yes:
        jump cyneyesno

    if cyne_no:
        jump cyneyesno
