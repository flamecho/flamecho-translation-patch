label illranverasscene2:
    $ iv_scene_two = True
    pause 0.5
    scene bg sc night with Fade(1.0, 1.0, 1.0):
        xpos 0.5 ypos 0.87 xanchor 0.44 yanchor 0.69 zoom 1.38
        linear 26.0 xpos 0.5 ypos 0.87 xanchor 0.63 yanchor 0.69 zoom 1.38


    window show dissolve
    play music "sounds/bgm/forgotten off.ogg" fadein 2.0
    translate None illranveras_scene2_0001:
        "锡德卡汉的街道夜晚格外寂寥。月光在雪地上跳跃，为一切镀上冰冷诡异的微光。"
    translate None illranveras_scene2_0002:
        "街上杳无人迹，人们都选择蜷缩在温暖舒适的床榻中。"
    translate None illranveras_scene2_0003:
        "好吧，这话基本属实。唯有一人正与凛冽寒气抗争，艰难跋涉于皑皑白雪间。"
    translate None illranveras_scene2_0004:
        "他边走边凝望月亮，同时思索着。他的思绪从不曾停歇。他甚至开始怀疑，人是否有可能停止永恒的思考与权衡。"
    translate None illranveras_scene2_0005:
        "前方浮现出一栋中等规模的低矮建筑。正是他要找寻的地方。"
    translate None illranveras_scene2_0006:
        "隔着遥远距离，他揣测被自己留在那里的那个人，此刻是否也在想着他。"
    translate None illranveras_scene2_0007:
        "怎么可能呢？那人心里装着别的事。诺克斯和索伦…"
    translate None illranveras_scene2_0008:
        "他走近建筑，用力叩门三声宣告自己的到来。"
    translate None illranveras_scene2_0009:
        "屋内传来窸窣声响，接着是门锁弹开的动静。门开了，他与一位粉发男子四目相对。"

    scene bg sc night:
        xpos 0.31 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.48
    show illran m dark fli at closeright:
        ypos 1.0 xanchor -0.61 yanchor 1.0
    show zarryn m dark ang at closeleft
    with dissolve
    translate None illranveras_scene2_0010:
        i "……嗨，扎林。想我了吗？那小鬼去哪儿了？"
    translate None illranveras_scene2_0011:
        show zarryn m dark ann with dis
        z "…就像怀念其他麻烦精一样怀念你。提图斯出去了。你知道他不喜欢你那么称呼他。"
    translate None illranveras_scene2_0012:
        z "话说你干嘛把鸟儿留在这儿？"
    translate None illranveras_scene2_0013:
        i "别这么刻薄。它怕冷。"
    translate None illranveras_scene2_0014:
        show illran m dark sad with dis
        z "你过度依赖它了。这些活物寿命很短的，明白吗？等它死了你会崩溃的。"
    translate None illranveras_scene2_0015:
        i "....."
    translate None illranveras_scene2_0016:
        imn "这话听着耳熟。"
    translate None illranveras_scene2_0017:
        show illran m dark hap with dis
        i "呸，胡说！要死也得一起死，对吧？"
    translate None illranveras_scene2_0018:
        z "又满嘴跑火车。带上你的鸟赶紧走。"
    translate None illranveras_scene2_0019:
        i "遵命。"
    translate None illranveras_scene2_0020:
        show illran m dark armsdown neu with dis
        i "哦…他现在状况如何？"
    translate None illranveras_scene2_0021:
        show zarryn m dark thi with dis
        z "……我还需要做些检测。目前无法回答你。"
    translate None illranveras_scene2_0022:
        z "至少看起来还算稳定。呼吸正常，只是不肯醒来。有必要的话，明天我会把详细情况带给你。"
    translate None illranveras_scene2_0023:
        i "你认识霍恩吧？下城区那个可爱的面包师。明天中午在那儿碰头。之前跟你提过的其他人也会等我们。"
    translate None illranveras_scene2_0024:
        show zarryn m dark neu with dis
        z "…行。现在，滚吧。我可没闲工夫跟你扯淡。"
    translate None illranveras_scene2_0025:
        i "好嘞好嘞。你这人真没劲，知道不？"

    play sound "sounds/sfx/slam.ogg" fadein 1.0
    scene bg sc night with hpunch:
        xpos 0.5 ypos 0.87 xanchor 0.44 yanchor 0.69 zoom 1.38
        linear 26.0 xpos 0.5 ypos 0.87 xanchor 0.63 yanchor 0.69 zoom 1.38
    translate None illranveras_scene2_0026:
        "蓝羽小鸟蹦上伊尔兰的肩膀，扎林以甩门作为回应。"
    translate None illranveras_scene2_0027:
        "他走出门廊一段距离后，才对在身旁啾鸣的蓝色小鸟开口。"
    translate None illranveras_scene2_0028:
        i neu "情况如何，维拉斯？"
    translate None illranveras_scene2_0029:
        "通过几次啄击，维拉斯总算传达了关于索伦发生的事情，但伊尔兰仍未完全满意。"
    translate None illranveras_scene2_0030:
        "通常他不会这么软弱，不需要维拉斯时刻保持人形陪在身边。事实上，他已经习惯了与鸟形态的他交谈，但…"
    translate None illranveras_scene2_0031:
        "今夜，他感受到一股挥之不去的孤独，无论怎样祈求都无法消弭。"
    translate None illranveras_scene2_0032:
        "见他没有回应，鸟从他的肩头振翅落下，在一阵烟雾中…"
    translate None illranveras_scene2_0033:
        "出现了一个赤裸的男人。"
    translate None illranveras_scene2_0034:
        i emb "喂喂，你干什么？！冷死了！"
    translate None illranveras_scene2_0035:
        v sur "哈…这还用你说？"
    translate None illranveras_scene2_0036:
        "片刻后他披上了伊尔兰递来的斗篷。但裸露的双腿和双脚仍在发抖。"
    translate None illranveras_scene2_0037:
        i sad "…为什么要这样？变回去吧，你这样没法在雪地里走。"
    translate None illranveras_scene2_0038:
        v smi "不要。我想聊天。"
    translate None illranveras_scene2_0039:
        i "等回屋里再说。"
    translate None illranveras_scene2_0040:
        v "那就等回屋后聊。我这样挺好。"
    translate None illranveras_scene2_0041:
        i "不，你不好。我…"
    translate None illranveras_scene2_0042:
        "他叹了口气，在维拉斯面前蹲下。"
    translate None illranveras_scene2_0043:
        v sur "….？你在干什么？"
    translate None illranveras_scene2_0044:
        i "上来吧。剩下的路我背你。"
    #window hide dissolve

    #scene gallery_82 with dissolve
    #window show dissolve
    translate None illranveras_scene2_0045:
        i hap "这样就好了。至少你的脚不会冻掉。"
    translate None illranveras_scene2_0046:
        "维拉斯紧紧贴住，拼命汲取对方的体温。"
    translate None illranveras_scene2_0047:
        v smi "感觉真好。谢谢你，伊尔兰。我总能信赖你。"
    translate None illranveras_scene2_0048:
        i sad "哈…现在知道感激了？等你又飞回天上什么的，可就没人这样惯着你了。"
    translate None illranveras_scene2_0049:
        v sad "........."
    translate None illranveras_scene2_0050:
        v "…伊尔兰…我…"
    translate None illranveras_scene2_0051:
        v "….我正想和你说这个。永恒…是孤独又无聊的东西。永远存在…真的会有人渴望这样吗？"
    translate None illranveras_scene2_0052:
        "伊尔兰屏住呼吸，不确定他将要听到什么。"
    translate None illranveras_scene2_0053:
        imn "他该不会要说想留下吧？"
    translate None illranveras_scene2_0054:
        v "......."
    translate None illranveras_scene2_0055:
        v "存在到时间尽头，甚至在那之后…我想不出更可怕的命运了，伊尔兰。这…太可怕了，光是想想都痛苦得难以忍受…"
    translate None illranveras_scene2_0056:
        v "我既不愿永远做人，更不愿永远为神。"
    translate None illranveras_scene2_0057:
        v "或许…我的时限，比原以为的要来得更早。"
    translate None illranveras_scene2_0058:
        i "什么？你在说什么…？"
    translate None illranveras_scene2_0059:
        v "你知道吗，当我最初获得人类身躯时，我觉得自己有了存在的意义。首先是和家族共同成长，然后守护我的双亲与诞生之地。"
    translate None illranveras_scene2_0060:
        v "但…时间会带走一切。除我之外的所有事物。只有我被永远留了下来。"
    translate None illranveras_scene2_0061:
        v "父母离世，故乡湮灭…那我当初的使命是什么？作为神明无能为力，作为凡人毫无价值…"
    translate None illranveras_scene2_0062:
        i "你不是…你从来都不是废物，维拉斯。就像我们初遇时我对你说的…"
    translate None illranveras_scene2_0063:
        v "......"
    translate None illranveras_scene2_0064:
        v "我游荡了数百年，无处为家。我…没有存在的理由，当我对信徒毫无助益时，这具身躯也不配属于我。"
    translate None illranveras_scene2_0065:
        v "直到遇见你们，我才想重新寻找奥雷利亚卡维拉。在那之前，我早已放弃归返的希望。"
    translate None illranveras_scene2_0066:
        v "我曾以为…若能再度找到他们，就能重归神列，变回昔日的神明…"
    translate None illranveras_scene2_0067:
        v "我思考了太久，伊尔兰。漫长到不该属于任何人的时光…才终于想明白。找到奥雷利亚卡维拉、解放诸神同伴并不能解决所有问题。"
    translate None illranveras_scene2_0068:
        v "…我不打算回归神列。这是我最后的使命，必将见证族人的自由。"
    translate None illranveras_scene2_0069:
        v "待此事完结…就该轮到我离去了。"
    translate None illranveras_scene2_0070:
        i "......"
    translate None illranveras_scene2_0071:
        imn "他不可能…不可能是认真的…不该是…这样的结局…"
    translate None illranveras_scene2_0072:
        imn "不，我比任何人都了解他。他是认真的。心意已决。"
    translate None illranveras_scene2_0073:
        v smi "旧神陨落，新神即位。会有新的丰收之神诞生，但愿他们…能完成我未竟之事，成为我未能成就的神明。"
    translate None illranveras_scene2_0074:
        i "维拉斯…没人能取代你的位置。你…配得上这个神位…"
    translate None illranveras_scene2_0075:
        "生平第一次，伊尔兰庆幸维拉斯看不见自己的脸。他眼眶发烫，泪水随时会决堤。"
    translate None illranveras_scene2_0076:
        "维拉斯将伊尔兰搂得更紧了些。"
    translate None illranveras_scene2_0077:
        v sad "你对我…实在太过温柔。"
    translate None illranveras_scene2_0078:
        v "我会…永远珍藏我们共度的记忆，至死方休。"
    window hide dissolve
    scene black with eye_shut
    pause 1.0
    window show dissolve
    translate None illranveras_scene2_0079:
        imn "多年前我们相遇时，我从没想过结局会是这样。我从没想过…我会变得如此依恋…"
    translate None illranveras_scene2_0080:
        imn "也许…如果七年前我没有推他那把…"
    stop music fadeout 2.0
    window hide dissolve

    scene bg stagwich sunset with eye_open:
        xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.61
        linear 30.0 xpos 0.5 ypos 1.69 xanchor 0.5 yanchor 1.0 zoom 1.61
    window show dissolve
    translate None illranveras_scene2_0081:
        "凉爽的海风拂过暮色笼罩的斯塔格威奇街道，带着熟悉的家乡气息。"
    translate None illranveras_scene2_0082:
        "薄薄的亚麻布篷下，路边摆满了集市摊位。"
    translate None illranveras_scene2_0083:
        "伊尔兰伸手从篷布下摸出一个苹果。"
    translate None illranveras_scene2_0084:
        play music "sounds/bgm/sad.ogg" fadein 2.0
        imn "哈，这里的人太容易轻信了。随便谁都能来把他们偷个精光。"
    translate None illranveras_scene2_0085:
        "街上有零星的过客，但没人注意到他的偷窃行为。他还没蠢到会被抓住，尤其不会被那种人抓住。"
    translate None illranveras_scene2_0086:
        "他继续沿着街道前行，漫不经心地把苹果抛接把玩。"
    translate None illranveras_scene2_0087:
        imn "..斯塔格威奇有恶魔？我都来两天了，半点儿风声都没听到。又是假线索…"
    translate None illranveras_scene2_0088:
        "越往前走，房屋就越发破败，但窗缝里仍透出烛光。这些屋子并非废弃，只是饱经沧桑。"
    translate None illranveras_scene2_0089:
        "伊尔兰朝窗内窥视。幸福的家庭围坐在一起，欢笑进食，尽管家徒四壁却其乐融融。"
    translate None illranveras_scene2_0090:
        "他猛地移开视线，一脚把石子踢向前方的路面。"
    translate None illranveras_scene2_0091:
        "………."
    translate None illranveras_scene2_0092:
        imn "趁还能享受的时候好好享受吧。"
    translate None illranveras_scene2_0093:
        "形单影只的行人，走在孤独的路上。这些年来他一直如此。"
    translate None illranveras_scene2_0094:
        "当他终于抬起视线时，发现有人跪在铺路石上，面前立着一座巨鸟雕像。"
    translate None illranveras_scene2_0095:
        "走近才发现雕像并不如初见时宏伟。石身布满裂纹和藤蔓，显然已被遗弃多年。"
    translate None illranveras_scene2_0096:
        "雕像前跪着个老人，正狂热地祈祷。"

    scene bg stagwich sunset
    show illrany n sunset cloak neu
    with dissolve
    translate None illranveras_scene2_0097:
        i "......"
    translate None illranveras_scene2_0098:
        i "老头，你在干什么？"
    translate None illranveras_scene2_0099:
        om "啊！哦，你吓了我一跳。"
    translate None illranveras_scene2_0100:
        "老人惊跳起来转身，没想到会突然被人搭话。"
    translate None illranveras_scene2_0101:
        om "..我在向维拉斯祈祷下次丰收。"
    translate None illranveras_scene2_0102:
        show illrany n sunset sad with dis
        i "祈祷？向神明？开什么玩笑。"
    translate None illranveras_scene2_0104:
        om "小子，这对你来说可能很蠢，但不代表毫无意义。我总得相信有人在眷顾我。"
    translate None illranveras_scene2_0105:
        imn "对这种恶魔般的存在盲目信仰…真可笑。诸神不在乎我们。他们从不对我们忠诚—从来如此。"
    translate None illranveras_scene2_0106:
        i "有什么意义？他根本不看顾你。像我们这样的人遭遇什么，他根本漠不关心。"
    translate None illranveras_scene2_0107:
        om "……他是否在看着，我不知道，但这不会阻止我像往常一样祈祷。"
    translate None illranveras_scene2_0108:
        i "啊，盲目的信仰，我最喜欢了。老头，你常来这儿吗？每天都来？"
    translate None illranveras_scene2_0109:
        om "每周一次。你知道，他喜欢音乐，所以我有时会坐在雕像旁给他奏个小曲。如今只剩我还为他这么做了。"
    translate None illranveras_scene2_0110:
        imn "老糊涂，这么好骗。"
    translate None illranveras_scene2_0111:
        i "我完全不在乎。我可没要听你的人生故事。"
    translate None illranveras_scene2_0112:
        om "是啊，你是没问，但你看上去像是个生活中需要点信仰的人。"
    translate None illranveras_scene2_0113:
        "伊尔兰嗤之以鼻，老人很快离开了，将他留在雕像的阴影里。"
    translate None illranveras_scene2_0114:
        imn "一点信仰，嗯？那我母亲死去的时候，他们又在哪儿？"
    translate None illranveras_scene2_0115:
        "他抬头望向雕像。指尖轻抚，拭去了牌匾上的青苔。"
    translate None illranveras_scene2_0116:
        stop music fadeout 2.0
        "丰收之神，维拉斯。"
    window hide dissolve

    scene black with fade
    pause 1.0
    window show dissolve
    play music "sounds/bgm/night.ogg" fadein 2.0
    translate None illranveras_scene2_0117:
        "连续六天，情形大抵相同。伊尔兰坐在雕像脚边，手持牧笛。他会轻柔甜美地吹奏几小时，却从不期待回报。"
    translate None illranveras_scene2_0118:
        "偶尔有只蓝鸟落在附近树上，专注地聆听他的音乐。伊尔兰觉得蹊跷，但还不至于深究。"
    window hide dissolve

    scene bg stagwich night with dissolve
    window show dissolve
    translate None illranveras_scene2_0119:
        "音符再次穿透夜色，空洞地回荡着。"
    translate None illranveras_scene2_0120:
        imn "我在做什么？这纯粹是浪费时间。"
    translate None illranveras_scene2_0121:
        imn "或许让那老头在虔诚的愚昧与平静中度过余生也好，至少他真心以为祈祷会奏效。"
    translate None illranveras_scene2_0122:
        imn "要是我的心灵也能如此轻易获得安宁……"
    translate None illranveras_scene2_0123:
        "今夜，没有蓝鸟驻足聆听他的笛声。他的曲子，只吹给自己听。"
    translate None illranveras_scene2_0124:
        "他叹着气决定放弃。起身掸去尘土正要离开，余光却瞥见什么。"
    translate None illranveras_scene2_0125:
        stop music fadeout 2.0
        "粉色的…桃色头发…有人躲在近处的树后，正朝他张望。"
    translate None illranveras_scene2_0126:
        imn "那样站在暗处…怪瘆人的。"
    translate None illranveras_scene2_0127:
        "伊尔兰向前迈了几步，与那个神秘男子面对面。他看起来有些凌乱和风尘仆仆，身上穿着松垮的破布衣服。"
    translate None illranveras_scene2_0128:
        show illrany n dark cloak neu at slightleft
        show veras n dark o2 neu2 at slightright
        with dissolve
        i "你在干什么？"
    translate None illranveras_scene2_0129:
        show veras n dark o2 sur2 with dis
        v "啊！"

    scene bg stagwich night:
        xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.53
        linear 20.0 xpos 0.5 ypos 1.6 xanchor 0.5 yanchor 1.0 zoom 1.53
    with hpunch
    translate None illranveras_scene2_0130:
        "那男子瞪大了眼睛，立刻转身就跑。伊尔兰紧追不舍，紧跟在他身后。"
    translate None illranveras_scene2_0131:
        iy ang "嘿，等等！你跑什么？！"
    translate None illranveras_scene2_0132:
        v fro1 "….别管我！"
    translate None illranveras_scene2_0133:
        show bg stagwich night with hpunch
        "桃发男子试图反抗，但伊尔兰动作更快。他伸出手抓住对方的手腕，强行止住了对方的步伐。"
    translate None illranveras_scene2_0134:
        play music "sounds/bgm/forgotten off.ogg" fadein 2.0
        "还没等伊尔兰开口，男孩就\"噗\"地化作一阵烟雾消失了。伊尔兰咳嗽着挥开眼前的雾气。"
    translate None illranveras_scene2_0135:
        "一只蓝色小鸟从烟雾中振翅高飞。见状，伊尔兰纵身一跃，将小动物搂在怀中摔落地面。"
    translate None illranveras_scene2_0136:
        "烟雾再次出现，但这次伊尔兰没有上当。他感觉到身下是人类躯体，紧紧抓住不放。"
    translate None illranveras_scene2_0137:
        "当烟雾散去，还是那头桃色头发…但是…"
    translate None illranveras_scene2_0138:
        iy sur "........."
    translate None illranveras_scene2_0139:
        "男子挣脱伊尔兰的控制，拾起衣服快速穿戴，留下伊尔兰困惑地坐在地上。"
    translate None illranveras_scene2_0140:
        "伊尔兰再次跳起来，绕着对方转圈。"

    scene bg stagwich night
    show illrany n dark ang cloak at slightright
    show veras n dark fro1 at slightleft
    with dissolve
    translate None illranveras_scene2_0141:
        i "你…你这恶心的恶魔…你到底是谁？！"
    translate None illranveras_scene2_0142:
        v ".........."
    translate None illranveras_scene2_0143:
        i "回答我！还是说我不配跟你说话？你觉得自己很了不起吗？！"
    translate None illranveras_scene2_0144:
        i "我知道你是什么东西…我知道你们的本性…你们…你的同类毁了我的人生！你让我母亲死去…是你杀了她！"
    translate None illranveras_scene2_0145:
        v "……我以前从未见过你。不要把与我无关的罪责推给我。"
    translate None illranveras_scene2_0146:
        show veras n dark sur1 with dis
        i "你应该是那个神明吧，维拉斯。"
    translate None illranveras_scene2_0147:
        "他瞪大了眼睛，却没有吐出半个字。"
    translate None illranveras_scene2_0148:
        i "好一个神明…看看你！荒郊野岭的破败神社…哈，真是可笑。你不过是个背弃了我们所有人的恶魔。你根本不在乎，对吧？"
    translate None illranveras_scene2_0149:
        i "就算…就算我们祈求你…就算我们每天向你祷告…你也依然无视我们的哀求！"
    translate None illranveras_scene2_0150:
        show veras n dark fro1 with dis
        v "……再见。我对你无话可说。"
    translate None illranveras_scene2_0151:
        i "又想逃跑？！我要杀了你！我要杀光你们这些畜生！"
    translate None illranveras_scene2_0152:
        hide illrany
        hide veras
        with dis
        play sound "sounds/sfx/knifeunsheath.ogg" fadeout 1.0
        "他从靴中抽出匕首，朝着维拉斯猛冲过去。"


    scene gallery_169 with hpunch
    translate None illranveras_scene2_0153:
        "他还没反应过来就被整个掀翻，轻得像没有重量一般，后背重重砸在地面发出闷响。剧痛窜过全身，手指都失去了知觉。"
    translate None illranveras_scene2_0154:
        i "呃…"
    translate None illranveras_scene2_0155:
        v "就这点本事？起来啊。不是说好要杀我的吗，还是说只会耍嘴皮子？"
    translate None illranveras_scene2_0156:
        v "没那份实力就别莽撞地冲过来。"
    translate None illranveras_scene2_0157:
        "维拉斯居高临下看着伊尔兰，面容冷峻。近距离对峙时，伊尔兰终于注意到…这个男人的眼神空洞涣散。"
    translate None illranveras_scene2_0158:
        i "哈！这算什么。很痛快吧？攻击本该由你守护的人！"
    translate None illranveras_scene2_0159:
        i "哦，对了。这是你的老本行。"

    scene gallery_170 with dissolve
    translate None illranveras_scene2_0160:
        v "….我在自卫。是你纠缠不休。别再来这里，回家去吧。"
    translate None illranveras_scene2_0161:
        i "家？我已经无家可归了。既然终于把你这个魔神引出来，就算同归于尽我也要宰了你。"
    translate None illranveras_scene2_0162:
        i "告诉我，我猜对了吗？你是维拉斯？"
    translate None illranveras_scene2_0163:
        v "....."
    translate None illranveras_scene2_0164:
        v "….是，我叫维拉斯，但…"
    scene gallery_171 with dissolve
    translate None illranveras_scene2_0165:
        v "早已不是神明。"
    translate None illranveras_scene2_0166:
        v "…别再找我。我会当今晚什么都没发生过。"
    translate None illranveras_scene2_0167:
        "刚要转身离去，伊尔兰的吼声惊得维拉斯浑身一颤。"
    translate None illranveras_scene2_0168:
        i "等等！"
    translate None illranveras_scene2_0169:
        imn "我在干什么…根本没必要向他解释，可是…"
    translate None illranveras_scene2_0170:
        i "你的所作所为正好印证了我的话。那个老头…他至今仍相信着你。"
    translate None illranveras_scene2_0171:
        v "我身上已无可信之物。"
    translate None illranveras_scene2_0172:
        i "明天再来这里。你自会明白。"


    scene bg stagwich night with hpunch:
        xpos 0.5 ypos 1.0 xanchor 0.51 yanchor 0.97 zoom 1.77

    translate None illranveras_scene2_0173:
        "转眼间他的身影已消失在夜色中。"
    translate None illranveras_scene2_0174:
        imn "终于见到活的了…但为什么他看起来…"
    translate None illranveras_scene2_0175:
        imn "如此忧郁？仿佛每个细胞都浸透在绝望里。"
    translate None illranveras_scene2_0176:
        imn "…和预想中不同，可他到底是…神明？恶魔？还是两者皆是？"
    translate None illranveras_scene2_0177:
        "伊尔兰仔细权衡着，回想自己的决定。把维拉斯引去见那个老头究竟有什么意义？"
    translate None illranveras_scene2_0178:
        "明明毫无意义，然而…"
    translate None illranveras_scene2_0179:
        "伊尔兰摇摇头甩开杂念，暂时离开神像过夜，决定明日再来探个究竟。"
    window hide dissolve

    scene black with Dissolve(2.0)
    pause 1.0

    scene bg stagwich night with dissolve:
        xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.61
        linear 30.0 xpos 0.5 ypos 1.69 xanchor 0.5 yanchor 1.0 zoom 1.61
    window show dissolve
    translate None illranveras_scene2_0180:
        "孤独的身影抱膝坐在巨大神像前，久久维持着沉思的姿势。"
    translate None illranveras_scene2_0181:
        "当他的手指轻触到雕像冰凉的石头时，他惊讶地发现有人清理过它。曾经长满青苔的地方，如今光滑如初，仿佛刚被安置在那里那天一样。"
    translate None illranveras_scene2_0182:
        "他清清楚楚记得那一天。人们是如何欢欣庆祝的。他又是如何在上方注视着这一切，感到前所未有的快乐。"
    translate None illranveras_scene2_0183:
        "那时他已守护这片土地数百年。人们来了又走，而维拉斯见证了一切。"
    translate None illranveras_scene2_0184:
        vmn "但现在呢？现在，我…"
    translate None illranveras_scene2_0185:
        vmn "我什么都不是。"
    translate None illranveras_scene2_0186:
        vmn "我无法再守护或保护他们。几乎失去了所有力量。像这样继续下去还有什么意义？漫无目的地四处游荡？"
    translate None illranveras_scene2_0187:
        i "{i}你要做的只是证明我是对的，知道吗。那个老人…他真的相信你。{/i}"
    translate None illranveras_scene2_0188:
        v sad "........."
    translate None illranveras_scene2_0189:
        vmn "不，我已经没有信徒了。如果有，我会知道的。我应该能听到他们的祈祷…我很确定。"
    translate None illranveras_scene2_0190:
        vmn "…他到底想要什么？真让人心烦。"
    translate None illranveras_scene2_0191:
        vmn "不过，他演奏的音乐确实很美。我确信他恨我们是有原因的。毕竟，他没有错。"
    translate None illranveras_scene2_0192:
        i "{i}就算我们哀求…就算我们每天向你祈祷…你依然对我们的恳求置之不理！{/i}"
    translate None illranveras_scene2_0193:
        vmn "他为什么如此恨我们？我做了什么招致他的愤怒？"
    translate None illranveras_scene2_0194:
        "维拉斯摇摇头，从原地站起身，伸手触碰雕像。它明明近在咫尺，却…感觉比其他任何东西都要遥远。"
    translate None illranveras_scene2_0195:
        stop music fadeout 2.0
        v "我该怎么做…才能找回我的使命？"
    window hide dissolve

    scene black with Dissolve(2.0)
    pause 1.0

    scene bg stagwich day with Dissolve(1.0)
    window show dissolve
    play music "sounds/bgm/sad.ogg" fadein 2.0
    translate None illranveras_scene2_0196:
        "今天和往常没什么不同。伊尔兰四处游走，听着闲言碎语并骗取秘密。"
    translate None illranveras_scene2_0197:
        "赏金猎人的生活并不容易，但这是他唯一熟悉的事。这是个赚钱的捷径，只是偶尔要赌上性命。对他而言，这很划算。"
    translate None illranveras_scene2_0198:
        "在荣耀的火焰中逝去…嗯，这确实很诱人。"
    translate None illranveras_scene2_0199:
        "伊尔兰抬手遮住刺眼的阳光。已是正午过后，热得不可思议。"
    translate None illranveras_scene2_0200:
        imn "时候到了。不知道他会不会出现？"
    translate None illranveras_scene2_0201:
        "他沿着走了一整周的同一条小路返回。走近时，注意到有个人影。"
    translate None illranveras_scene2_0202:
        "维拉斯躲在一棵树后，注视着老人全神贯注地祈祷。他看上去想上前，却一次次停下了脚步。"
    translate None illranveras_scene2_0203:
        "伊尔兰留在远处，目睹着这一切。"
    translate None illranveras_scene2_0204:
        show veras m sad with dis
        "终于，维拉斯从树后走出，站到了祷告老人身旁。老人慌忙起身相迎。"
    translate None illranveras_scene2_0205:
        om "哎呀，占了这么大地方真不好意思，小兄弟。你也是来祷告的吗？"
    translate None illranveras_scene2_0206:
        v "你…你在向神明祈祷？"
    translate None illranveras_scene2_0207:
        om "当然啊。向维拉斯祈祷。"
    translate None illranveras_scene2_0208:
        v "......"
    translate None illranveras_scene2_0209:
        v "可…可是…为什么…？"
    translate None illranveras_scene2_0210:
        om "…向来如此，永不会变。小时候，我们全家都会聚集在这儿祷告。其他家庭也是。要我说，斯塔格威奇半数居民当年都住在这尊雕像附近。"
    translate None illranveras_scene2_0211:
        om "我们会奏乐庆祝，惊叹聚集在雕像旁的蓝鹪鹩…那时真美好啊。要是能回到那时候该多好。"
    translate None illranveras_scene2_0212:
        v "你现在还…信仰他？你不担心…他已经不再庇佑你了吗？"
    translate None illranveras_scene2_0213:
        om "哈哈，我这把年纪才不操心这种事呢。就算他的目光已转向别处，我知道他总在某个地方行善。"
    translate None illranveras_scene2_0214:
        om "儿孙们都不信维拉斯了，老伴也走了…得有十年了吧，但我每周日都会来这儿祷告。这让我想起那些快乐时光。"
    translate None illranveras_scene2_0215:
        om "…你看上去有点迷茫。要知道这没什么。人有时候总要先迷失，才能找到真正的自己。"
    translate None illranveras_scene2_0216:
        om "好啦，我该走了。该准备晚饭喽。"
    translate None illranveras_scene2_0217:
        "老人向维拉斯点头致意，转身回家去了。"
    translate None illranveras_scene2_0218:
        show veras m lon with dis
        "雕像前突然安静下来。伊尔兰终于从藏身处走出，来到维拉斯身旁。"
    translate None illranveras_scene2_0219:
        show veras at closeright with move
        show illrany m sad at closeleft with dissolve:
            ypos 1.0 xanchor 0.13 yanchor 1.0
        "直到走近，他才听到维拉斯先是压抑的呜咽，继而变成汹涌的泪水。"
    translate None illranveras_scene2_0220:
        "他跪倒在地，仰望着雕像。"
    translate None illranveras_scene2_0221:
        v "他…他是我这一百多年来遇到的第一个…真正的信徒…"
    translate None illranveras_scene2_0222:
        v "我…我从没聆听过他的祈祷，一次都没有。我已经…不是真正的神明了，我只是…什么都不是…"
    translate None illranveras_scene2_0223:
        v "就连对他们这样的人…对那位老人和他妻子这样虔诚的信徒…我也没能帮上忙，没能保护他们…."
    translate None illranveras_scene2_0224:
        v "为什么…为什么我必须存在…我怎么可能…战胜这种痛苦…"
    translate None illranveras_scene2_0225:
        i "..........."
    translate None illranveras_scene2_0226:
        imn "为什么他…看起来如此心碎？难道他实际上…？"
    translate None illranveras_scene2_0227:
        show illrany m ang with dis
        i "…难道你把他对你的信任当作一文不值吗？"
    translate None illranveras_scene2_0228:
        "他猛地转身，目光聚焦在伊尔兰身上，尽管他看不见。"
    translate None illranveras_scene2_0229:
        v "什么？"
    translate None illranveras_scene2_0230:
        i "他把所有的信任都给了你，而不是别人，你就是这么回报他的？"
    translate None illranveras_scene2_0231:
        v "那我还能做什么？！我…我无能为力！你不会明白的…再努力也没有意义了…"
    translate None illranveras_scene2_0232:
        show illrany m sad with dis
        i "….我确实不知道你正在经历什么。但有一件事我很清楚。"
    translate None illranveras_scene2_0233:
        i "实现目标永远不是不可能的事，除非你自己觉得不可能。你可以找到你的目标。"
    translate None illranveras_scene2_0234:
        v "......."
    translate None illranveras_scene2_0235:
        "那一刻，维拉斯看起来比任何时候都要脆弱，但有什么改变了。仿佛就因为听到这么简单的话，他肩上的重担被卸下了。"
    translate None illranveras_scene2_0236:
        v "你…你说得对…确实有我能做的事…"
    translate None illranveras_scene2_0237:
        "他站起身来，带着坚定的神情擦干泪水。"
    translate None illranveras_scene2_0238:
        show veras m fro with dis
        i "你要去哪？"
    translate None illranveras_scene2_0239:
        show veras m sad with dis
        v "…我不想再和你争斗了。求你了…"
    translate None illranveras_scene2_0240:
        i "我不是来找你打架的。我问你要去哪。"
    translate None illranveras_scene2_0241:
        "他的眼中，现在燃起了火焰。"
    translate None illranveras_scene2_0242:
        imn "…我想帮助他找回失去的东西。也许，在这个过程中，我自己也能学到一两件事…"
    translate None illranveras_scene2_0243:
        show veras m fro with dis
        v "….我要去拯救我的人民，重新成为神。"
    translate None illranveras_scene2_0244:
        i "…听起来是个艰巨的任务。"
    translate None illranveras_scene2_0245:
        show veras m sad with dis
        v "老实说…我不知道该从哪里开始…"
    translate None illranveras_scene2_0246:
        i "…也许…你可以找个擅长解决问题的人相助。"
    translate None illranveras_scene2_0247:
        v "…或许你说得对…我得去找人问问…"
    translate None illranveras_scene2_0248:
        i "所以…你能变成鸟？"
    translate None illranveras_scene2_0249:
        v "…可以。"
    translate None illranveras_scene2_0250:
        show illrany m neu with dis
        i "…我会帮你，有两个条件。"
    translate None illranveras_scene2_0251:
        v "…什么条件？"
    translate None illranveras_scene2_0252:
        i "第一，你要告诉我关于众神的真相；第二，你要协助我追捕悬赏犯。"
    translate None illranveras_scene2_0253:
        v "........"
    translate None illranveras_scene2_0254:
        v "…我的旅程可能会很漫长，甚至永无止境…"


    if achievement.has("illran_verasmeet"):
        pass
    else:
        $ renpy.display_notify("成就解锁：初次相遇")

    python:
        achievement.grant("illran_verasmeet")
        achievement.sync()

    translate None illranveras_scene2_0255:
        show illrany m smi with dis
        i "反正我手头有很多空闲时间。找点有趣的事做也不错。而且我一直在寻找追捕悬赏犯的搭档。"
    window hide dissolve

    scene black with Dissolve(2.0)
    pause 1.0

    scene bg sc night:
        xpos 0.31 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.48
    #scene gallery_82 with Dissolve(1.0)
    window show dissolve
    translate None illranveras_scene2_0256:
        imn "就这样，我们从敌人变成了同伴。回想当时的举止真是难为情…那么无知，那么狂妄…"
    translate None illranveras_scene2_0257:
        imn "当我们一起旅行，离找到奥雷利亚卡维拉越来越近时，我们发现彼此相处得非常好。尽管性格迥异，却比我这辈子遇到的任何人都要合拍。"
    translate None illranveras_scene2_0258:
        imn "他既善良又幽默，甘于奉献且天性纯良…"
    translate None illranveras_scene2_0259:
        imn "在我意识到之前，我们已经形影不离了。或者说…我是这么以为的…"
    translate None illranveras_scene2_0260:
        v sad "伊尔兰？"
    translate None illranveras_scene2_0261:
        i sad "......"
    translate None illranveras_scene2_0262:
        i "….好…好的，当然。如果那…是你想要的，那么…我会帮你实现…"
    translate None illranveras_scene2_0263:
        imn "七年来我们始终相伴。没想到这一切会被如此突然地夺走…"
    translate None illranveras_scene2_0264:
        "面对那个令人不安的未来，伊尔兰脑海里只剩一个念头。一个他曾竭力压抑，却不断浮现的念头。"
    translate None illranveras_scene2_0265:
        imn "….我爱他。"
    stop music fadeout 2.0
    window hide dissolve
    $ iv_scene_two = True

    if cyne_route:
        jump cyneroute2continued

    if leos_route:
        jump leosroute2continued

    if fawn_route:
        jump fawnroute2continued
