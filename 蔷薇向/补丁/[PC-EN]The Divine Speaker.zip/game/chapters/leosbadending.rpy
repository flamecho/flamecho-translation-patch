label leosbadending:

    translate None leos_badend_0001:
        l "…你说得对，这毫无意义。你的话一文不值。"
    translate None leos_badend_0002:
        "莱奥斯艰难地咽了口唾沫，斗篷下握着匕首的手攥得更紧了。"
    translate None leos_badend_0003:
        lmn "一个人？只要杀一个人，我就能自由？仅此而已？"
    translate None leos_badend_0004:
        lmn "我已经杀了多少人？再多一个又何妨？"

    scene bg eclipse night with hpunch:
        size (1920, 1080)
    play sound "sounds/sfx/swing1.ogg"
    translate None leos_badend_0005:
        "电光火石间，莱奥斯抽出暗藏的刀刃划过那人咽喉。对方双膝跪地踉跄前倾，抓挠着喉咙徒劳喘息，最终重重倒地。"

    show black with eye_shut
    pause 2.0

    scene bg eclipse night:
        xpos 0.61 ypos 1.34 xanchor 0.5 yanchor 1.0 zoom 0.84
    show ds m sad
    with eye_open
    translate None leos_badend_0006:
        "至少…他以为是这样。但当他又一次眨眼，艾米尔完好无损地站在面前。"
    translate None leos_badend_0007:
        "汗珠顺着莱奥斯眉骨滑落，胃部泛起阵阵不适。"
    translate None leos_badend_0008:
        lmn "我刚才要做什么…？就因为巷子里陌生人的怂恿而杀人？"
    translate None leos_badend_0009:
        lmn "我…我一定是疯了…"
    translate None leos_badend_0010:
        l c whur "妈的，我…我得离开，我不能…不能这样…"
    translate None leos_badend_0011:
        "他转身冲出门去，任凭艾米尔在身后焦虑地呼喊。"
        play sound "sounds/sfx/slam.ogg"
    translate None leos_badend_0012:
        scene bg sc night with swipeleft
        "莱奥斯跌跌撞撞穿过积雪的街道，尽管肺部充盈却仍大口喘息。"
    translate None leos_badend_0013:
        "杀戮是他的本行，是他的日常工作。可为何光是动这个念头就让他如此作呕？"
    translate None leos_badend_0014:
        l c whur "我…我想要改变…"
    translate None leos_badend_0015:
        u "改变？你？我看未必可能。"
    translate None leos_badend_0016:
        "莱奥斯猛地转向声源，与某个仅有一面之缘的男人四目相对。对方黑发赤瞳，那深红的眼眸瞬间在他脑中敲响警钟。"
    translate None leos_badend_0017:
        "而这个声音…他认得。"
    translate None leos_badend_0018:
        show leos nw dark cloak hur at slightleft
        show luc n dark smir cloak at slightright
        with dissolve
        l "你…你想陷害我…！"
    translate None leos_badend_0019:
        lucu "什么，杀艾米尔？我可没提过他。"
    translate None leos_badend_0020:
        l "你说过…你说只要我杀了说书人，就能改变我的命运。"
    translate None leos_badend_0021:
        lucu "噢哟，哎呀呀。搞错了，我指的是另一位说书人。你知道的，雷恩。"
    translate None leos_badend_0022:
        show bg sc night with hpunch
        l "什么？！你这狗娘养的！我绝不会…绝不会伤害他！"
    translate None leos_badend_0023:
        lucu "哼，未必吧。最初不是你设计陷害他吗？后来不是派你去暗杀他吗？在我看来你可没少伤害他。"
    translate None leos_badend_0024:
        l "那是…那是我永世难赎的过错。"
    translate None leos_badend_0025:
        show luc n dark neu with dis
        lucu "像我们这样的人是不会改变的，莱奥斯。"
    translate None leos_badend_0026:
        "盛怒之下，莱奥斯朝那人举起拳头，但对方轻易就抓住了他的手臂。"
    translate None leos_badend_0027:
        lucu "抓到你了。"
        play sound "sounds/sfx/fallonground3.ogg"
    translate None leos_badend_0028:
        scene bg sc night with hpunch
        "毫无预兆地，莱奥斯突然抱头栽倒在地，痛苦得几乎要哭出来。"
    translate None leos_badend_0029:
        l c whur "你对我…你对我做了什么…？！"
    translate None leos_badend_0030:
        lucu smir "只是个小把戏，用来让人乖乖听话。别担心，很快就没那么疼了"
    translate None leos_badend_0031:
        lucu "可惜不是对所有人都有效。要么让对方疼得死去活来，要么让他们怒火中烧才能见效。"
    translate None leos_badend_0032:
        lucu "哈哈哈，你真该看看我是怎么对付你那些朋友的。"
    translate None leos_badend_0033:
        "那人在莱奥斯身旁蹲下，咧着人畜无害的笑容，说的话却令人毛骨悚然。"
    translate None leos_badend_0034:
        "忽然间，他的动作停滞了。莱奥斯从石板路上坐起身来。"
    translate None leos_badend_0035:
        lucu "这样好多了。现在，咱们来纠正你的错误吧？我要你回去杀了雷恩，趁他还没醒。明白吗？"
    translate None leos_badend_0036:
        l c wneu "…是的。"
    translate None leos_badend_0037:
        lucu "很好！那就快去吧。"
    translate None leos_badend_0038:
        "神秘人随意地挥挥手，将莱奥斯独自留在黑暗中。他站起身，头脑空空地朝银柳走去。"

    window hide dissolve

    scene bg swroom night with dissolve
    window show dissolve
    translate None leos_badend_0039:
        "房间很暗，雷恩平缓的呼吸声从床上传来。莱奥斯走到床边，从斗篷下抽出一把匕首。"
    translate None leos_badend_0040:
        "寒光一闪，匕首已抵住雷恩的咽喉，刀刃堪堪触及皮肤。"
    translate None leos_badend_0041:
        "他握紧刀柄。尽管寒气逼人，汗珠仍顺着额头滚落。"
    translate None leos_badend_0042:
        lmn "只要…轻轻…划过…"
    translate None leos_badend_0043:
        lmn "只要…杀了他…"
    translate None leos_badend_0044:
        lmn "动手…杀了他。快动手啊！"
    translate None leos_badend_0045:
        "他手臂颤抖，内心激烈交战。拼命抢夺身体的控制权，乞求自己停下。"
    translate None leos_badend_0046:
        rs wsur "莱奥斯，你没事吧…？"
    translate None leos_badend_0047:
        show bg swroom night with vpunch
        l whur "啊..！"
    translate None leos_badend_0048:
        "他踉跄后退，匕首当啷一声掉在地上。"
    translate None leos_badend_0049:
        rs "莱奥斯！怎么回事？！"
    translate None leos_badend_0050:
        l "我控制不住…控制不住自己…雷恩…呃…离我远点，我不安全…我得走…"
    translate None leos_badend_0051:
        l "我必须走！"
    translate None leos_badend_0052:
        rs "等等！"
    translate None leos_badend_0053:
        l "别…别来找我。"
    translate None leos_badend_0054:
        "莱奥斯冲出门去，如一阵风般消失在了漆黑街巷中。"

    window hide dissolve

    scene bg swroom night:
        xpos 0.35 ypos 1.24 xanchor 0.5 yanchor 1.0 zoom 1.88
    with Fade(1.0, 1.0, 1.0)
    window show dissolve
    translate None leos_badend_0055:
        "然后只剩我独自一人。"
    translate None leos_badend_0056:
        "我坐在黑暗中，盯着那把从莱奥斯手中滑落、哐当一声掉在地板上的匕首。"
    translate None leos_badend_0057:
        "他刚才…是把那东西抵在我的喉咙上，对吧…？"
    translate None leos_badend_0058:
        "我猛地从床上跳起来冲向门口，拼命想追上他。"
    translate None leos_badend_0059:
        "我不知道发生了什么，但…我不能就这样让他独自离开！"
    translate None leos_badend_0060:
        scene bg sc night with swipeleft
        "我冲过街道搜寻莱奥斯的身影，却哪里都找不到他。他仿佛凭空消失了。"
    translate None leos_badend_0061:
        "我跪在雪地里，眼角泛起泪花。心里明白，如果我在房间等他，明天早晨他也不会回来。"
    translate None leos_badend_0062:
        "我明白…我再也见不到他了。"
    translate None leos_badend_0063:
        "我蜷缩成一团，额头抵在膝盖上。"
    translate None leos_badend_0064:
        "一滴，两滴，泪水很快在脸上结成冰痕。"
    translate None leos_badend_0065:
        "我孤身一人。"

    stop music fadeout 2.0
    window hide dissolve

    scene black with Fade(1.0, 1.0, 1.0)
    pause 2.0

    scene bg stagwich night with Fade(1.0, 1.0, 1.0):
        xpos 0.72 ypos 1.12 xanchor 0.5 yanchor 1.0 zoom 1.59
        linear 35.0 xpos 0.21 ypos 1.12 xanchor 0.5 yanchor 1.0 zoom 1.59
    window show dissolve
    play music "sounds/bgm/sad.ogg" fadein 3.0
    translate None leos_badend_0066:
        "这几个月世界天翻地覆。"
    translate None leos_badend_0067:
        "那时我只想回家—逃避失去莱奥斯的痛苦，他再也没回到我身边。"
    translate None leos_badend_0068:
        "但谁都没料到后来的变故。"
    translate None leos_badend_0069:
        "一股极致邪恶的强大力量降临锡德卡汉。卡斯皮安逃亡。艾米尔失踪。维拉斯被那人当作力量燃料吞噬后，伊尔兰孤独留守。"
    translate None leos_badend_0070:
        "无人能阻。他长驱直入，肆意掠夺。"
    translate None leos_badend_0071:
        "那人名叫卢修斯。"
    translate None leos_badend_0072:
        "我本该反抗。我本该成为英雄。"
    translate None leos_badend_0073:
        "可我却逃了。逃离锡德卡汉，穿越苋红森林，逃得越远越好。 "
    translate None leos_badend_0074:
        "我寻找。找遍每个角落。"
    translate None leos_badend_0075:
        "莱奥斯消失了。"
    translate None leos_badend_0076:
        "今天和往常没什么不同。这已经是我第二次或第三次来到斯塔格威奇。卢修斯的统治尚未波及此地，小镇让我格外思念莱奥斯。"
    translate None leos_badend_0077:
        "我已经好几天没进食。早在灾难发生前，就没再见过福恩和赛恩。"
    translate None leos_badend_0078:
        "我孤身一人。"
    translate None leos_badend_0079:
        "视线开始模糊，身体逐渐衰竭。"
    translate None leos_badend_0080:
        "我跌倒在路面上，四周空无一人。"
    translate None leos_badend_0081:
        "其实阖上眼睛的感觉…意外地舒服。"
    translate None leos_badend_0082:
        "当视野越来越暗时，一双靴子映入眼帘。"

    window hide dissolve

    scene bg bedroom1 night with Fade(1.0, 1.0, 1.0) # pan here
    window show dissolve
    translate None leos_badend_0083:
        "一位红发男子坐在床沿，目光紧盯着床上闭紧双眼的男人。"
    translate None leos_badend_0084:
        "那双眼睛已经紧闭一周了。"
    translate None leos_badend_0085:
        l wsur "……感觉就像昨天我们还经过这里，嗯？"
    translate None leos_badend_0086:
        l "你让我在观众面前表演，不记得了吗？你嘲笑我，说我像个蹦蹦跳跳的琵琶手。"
    translate None leos_badend_0087:
        l "……我当时不觉得好笑，是吧？但其实挺有趣的。"
    translate None leos_badend_0088:
        "雷恩没有任何回应，但他的胸膛仍在缓慢起伏，平静地呼吸着。"
    translate None leos_badend_0089:
        l "然后我们去了奥克斯哈伯。那不是很疯狂吗？追查一个杀人犯，一个恶魔……我从没想过自己会做这种事。"
    translate None leos_badend_0090:
        "尽管如此，他依然沉默不语。"
    translate None leos_badend_0091:
        l "然后……在锡德卡汉，我们……我吻了你，记得吗？"
    translate None leos_badend_0092:
        l whur "我吻了你，那是我做过最美妙的事。"
    translate None leos_badend_0093:
        "他的睫毛没有颤动，双眼依然紧闭。"
    translate None leos_badend_0094:
        l "……我想念你的声音。想得要命。"
    translate None leos_badend_0095:
        l "我搞砸了……天啊，我彻底搞砸了。我从没…我本不该离开你。我发誓用余生来弥补，只要…只要你醒过来…"
    translate None leos_badend_0096:
        l "只要你对我说一句话…"
    translate None leos_badend_0097:
        l "哪怕是说你恨我，说你…永远不想再见到我。"
    translate None leos_badend_0098:
        "这时本应发生奇迹。他的眼睛应该突然睁开，他们应该相拥而吻重归于好，回到锡德卡汉让一切重回正轨。"
    translate None leos_badend_0099:
        "但生活不是童话故事。"
    translate None leos_badend_0100:
        "相反，莱奥斯俯身在雷恩的身体上方，泪水无声滑落，打湿了床单。"
    translate None leos_badend_0101:
        "他就这样哭了很久很久。"



    if achievement.has("leos_badend"):
        pass
    else:
        $ renpy.display_notify("成就解锁：我好想你")

    python:
        achievement.grant("leos_badend")
        achievement.sync()
    translate None leos_badend_0102:
        l "求求你……雷恩，我好想你。"
    return













































#
