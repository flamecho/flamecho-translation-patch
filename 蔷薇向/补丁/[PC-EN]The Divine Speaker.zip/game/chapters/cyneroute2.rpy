label cyneroute2:
    scene gallery_79 with dissolve
    window show dissolve
    translate None cyne_chapter2_0001:
        "赛恩的手臂如蛇般攀上我的肩头，悲伤地仰望着我的脸。"
    translate None cyne_chapter2_0002:
        rs "我该先提醒你…我跳得不太好。"
    play music "sounds/bgm/night.ogg"
    translate None cyne_chapter2_0003:
        c "我不介意…"
    translate None cyne_chapter2_0004:
        rs "…你没事吧？你母亲看起来…挺和善的。"
    translate None cyne_chapter2_0005:
        c "...."
    translate None cyne_chapter2_0006:
        c "我不该丢下你一个人的。我完全没想到她会主动找你。"
    translate None cyne_chapter2_0007:
        rs "你在担心什么？她又没对我怎样。"
    translate None cyne_chapter2_0008:
        c "…你不了解她的为人。"
    translate None cyne_chapter2_0009:
        c "她是个…满口谎言的骗子。为达目的可以不择手段。"
    translate None cyne_chapter2_0010:
        rs "你们俩倒是挺像的。"
    show gallery_79 with hpunch
    translate None cyne_chapter2_0011:
        c "我们一点都不像！"
    translate None cyne_chapter2_0012:
        rs "…抱歉。"
    translate None cyne_chapter2_0013:
        show gallery_78 with dissolve
        c "不…是我该道歉。我只是…希望你对她留个心眼，好吗？"
    translate None cyne_chapter2_0014:
        "我们踏着简单的舞步随音乐缓缓摇摆。不过我大部分精力都用在避免踩到赛恩的脚上了。"
    translate None cyne_chapter2_0015:
        "他看起来很悲伤，而我不知该如何安慰。"
    translate None cyne_chapter2_0016:
        rs "…看吧，我跳得很差劲对不对？"
    translate None cyne_chapter2_0017:
        c "也没那么糟糕啦。"
    translate None cyne_chapter2_0018:
        rs "对不起…你习惯的舞伴应该都更…水平相当吧。"
    translate None cyne_chapter2_0019:
        c "和那些人跳舞很无趣的。无论如何我都更想选你。"
    translate None cyne_chapter2_0020:
        rs "喔-哦？那个，呃…我在想，如果你愿意…"
    translate None cyne_chapter2_0021:
        c "嗯？"
    translate None cyne_chapter2_0022:
        rs "或许稍后我们可以…"
    show gallery_79b with dissolve
    translate None cyne_chapter2_0023:
        "赛恩的表情在刹那间从困惑转为欣喜。"
    translate None cyne_chapter2_0024:
        c "哎呀呀，这是怎么了？我这是被当面邀约了吗？"
    translate None cyne_chapter2_0025:
        rs "我们总是…被各种事情打断，所以…"
    translate None cyne_chapter2_0026:
        c "你害羞的样子很可爱，知道吗？"
    translate None cyne_chapter2_0027:
        rs "我才没害羞…"
    translate None cyne_chapter2_0028:
        c "是是是。不过想引起我的注意还得再加把劲哦。"
    translate None cyne_chapter2_0029:
        rs "什么？！"
    translate None cyne_chapter2_0030:
        "他静静仰望着我，脸上依然挂着那抹笑容。"
    translate None cyne_chapter2_0031:
        rs "我…我非常想…今晚和你共度，赛恩…可以吗？"
    translate None cyne_chapter2_0032:
        c "不错嘛！我有点心动了。"
    translate None cyne_chapter2_0033:
        rs "我—"
    translate None cyne_chapter2_0034:
        "房间另一头，我的视线锁定了那个橘色马尾的男子。"
    translate None cyne_chapter2_0035:
        "他围着围裙，衣着十分朴素。"
    translate None cyne_chapter2_0036:
        "他看着我们跳了一会儿舞，又继续忙自己的事。"
    translate None cyne_chapter2_0037:
        rs "等等…我看到可以搭话的人了！"
    window hide dissolve

    scene bg ball:
        xpos 0.21 ypos 1.16 xanchor 0.5 yanchor 1.0 zoom 1.61
    show cyne nw dim sur at slightright
    show raen nw dim sur at slightleft
    with dissolve
    window show dissolve
    translate None cyne_chapter2_0038:
        "我拽着赛恩的手追赶那个神秘男子消失的背影。接近时，他听到脚步声惊讶地转身。"
    translate None cyne_chapter2_0039:
        rs "请等一下！打扰了！"
    translate None cyne_chapter2_0040:
        show cyne at right
        show raen at left
        with move
        show hone n dim sur with dissolve # Voice map most of this scene with leos and fawn route
        u ".....?"
    translate None cyne_chapter2_0041:
        rs "对不起…吓到你了真的很抱歉。"
    translate None cyne_chapter2_0042:
        u "没关系，我只是有点惊讶竟然有人在注意我。"
    translate None cyne_chapter2_0043:
        rs "我也想说同样的话。我跟别人说话时，他们都没什么反应…"
    translate None cyne_chapter2_0044: #NEW CYNE LINE
        show raen nw dim neu
        show cyne nw dim neu
        with dis
        rs "我叫雷恩，这位是赛恩。能耽误你一点时间聊聊吗？"
    translate None cyne_chapter2_0045:
        "他转头望向房间后方的一扇门。服务员们端着看起来很昂贵的食物频繁进出。"
    translate None cyne_chapter2_0046:
        show hone n dim neu with dis
        u "有点时间，不过我得赶快回厨房。我们可以边走边聊。"
    translate None cyne_chapter2_0047:
        h "对了，我叫霍恩。"
    translate None cyne_chapter2_0048:
        rs "霍恩…你是厨师之类的吗？"
    translate None cyne_chapter2_0049:
        show hone n dim smi with dis
        $ about_Hone.locked = False
        h "哈哈，我只是个{a=set_entry:enc_people->about_Hone}{color=#DA70D6}面包师{/color}{/a}。"
    translate None cyne_chapter2_0050:
        "他说话时长着雀斑的脸亮了起来。虽然话不多，但周身散发着让人愿意亲近的气质。"
    translate None cyne_chapter2_0051:
        rs "我在找一个叫卡斯皮安的男人。他大概…17、18年前来过这里。我知道很久远了，但如果你能仔细回忆—"
    translate None cyne_chapter2_0052:
        h "卡斯皮安？我认识他啊。"
    translate None cyne_chapter2_0053:
        show raen nw dim sad
        show cyne nw dim sur
        with dis
        rs "就算你不认识，如果能介绍其他可能知道的人—"
    translate None cyne_chapter2_0054:
        show raen nw dim sur with dis
        rs "等等，什么？！"
    translate None cyne_chapter2_0055:
        show hone n dim hap with dis
        h "卡斯皮安。高个子，棕色头发。我时不时能见到他。"
    translate None cyne_chapter2_0056: #CYNE LINE
        c "…能告诉我们去哪找他吗？"
    translate None cyne_chapter2_0057:
        "走到门口时，霍恩把手搭在门框上。"
    translate None cyne_chapter2_0058:
        show hone n dim smi with dis
        h "…在下城区我有个面包坊。你们明天能来一趟吗？到时候可以详细说说他的事。"
    translate None cyne_chapter2_0059:
        h "不能再聊了，否则下次可能就没邀请函了。"
    translate None cyne_chapter2_0060:
        rs "好，明白了。我一定去。"
    translate None cyne_chapter2_0061:
        hide hone with dissolve
        show raen at slightleft
        show cyne at slightright
        with move
        "他微微点头致意，随即消失在厨房里。"
    translate None cyne_chapter2_0062:
        rs "天哪，赛恩…这就是突破口！"
    translate None cyne_chapter2_0063:
        show cyne nw dim smi with dis
        c "看吧？我就说会在这里找到线索。快，夸夸我。"
    translate None cyne_chapter2_0064:
        show raen nw dim hap with dis
        rs "太感谢了赛恩！你最棒了！"
    translate None cyne_chapter2_0065:
        "我冲上前紧紧抱住他，引来许多宾客侧目。"
    translate None cyne_chapter2_0066:
        show cyne nw dim emb blush with dis
        c "啊…喂，没想到你真…没什么的雷恩。我很乐意帮你。走吧，我们先离开这儿。"
    translate None cyne_chapter2_0067:
        show raen nw dim sur with dis
        rs "这就要走？"
    translate None cyne_chapter2_0068:
        c "我们来这儿的事办完了。没理由继续跟这群废物耗着，你说呢？"
    translate None cyne_chapter2_0069:
        "我们快速寻路回到前门，循着来时的路离开。"
    if achievement.has("cyne_date"):
        pass
    else:
        $ renpy.display_notify("成就解锁：我的未婚夫")
    python:
        achievement.grant("cyne_date")
        achievement.sync()
    translate None cyne_chapter2_0070:
        "离开时没人注意到我们。他们都太忙了，只顾着各自的事。"
    window hide dissolve

    scene bg sc night with fade:
        xpos 0.49 ypos 1.41 xanchor 0.5 yanchor 1.0 zoom 1.41
        linear 25.0 xpos 0.49 ypos 1.03 xanchor 0.5 yanchor 1.0 zoom 1.41
    window show dissolve
    translate None cyne_chapter2_0072:
        "外面的空气刺骨寒冷，寒意直钻心底，让我们不自觉地靠得更近了些。"
    translate None cyne_chapter2_0073:
        "走出大楼时，我们注意到有人环抱双臂站在阴影处。"
    translate None cyne_chapter2_0074:
        i fli "终于出现了啊。是不是在里面玩得乐不思蜀了？"
    translate None cyne_chapter2_0075:
        rs c wsur "….你好啊，伊尔兰。在等我们吗？"
    translate None cyne_chapter2_0076:
        i neu "确实。有些关于索伦的消息，但现在不是谈这个的时候。"
    translate None cyne_chapter2_0077:
        rs "…知道霍恩面包坊吗？在下城区。"
    translate None cyne_chapter2_0078:
        "他点点头。"
    translate None cyne_chapter2_0079:
        rs "明天中午在那儿碰面。喂等等，维拉斯去哪了？"
    translate None cyne_chapter2_0080:
        "我这才发现既不见那个桃红色头发的男人，也看不到那只蓝鸟。"
    translate None cyne_chapter2_0081:
        i sad "…我们又不是形影不离的。"
    translate None cyne_chapter2_0082:
        i "......."
    translate None cyne_chapter2_0083:
        i "他现在看着索伦呢。不知为何他担心得要命。"
    translate None cyne_chapter2_0084:
        c c wneu "情况如何？"
    translate None cyne_chapter2_0085:
        i "........."
    translate None cyne_chapter2_0086:
        i neu "明天再说。中午。霍恩的面包店。"

    window hide

    menu:
        "转达谢意":
            $ illranveras_friend += 1
            window show dissolve
            translate None cyne_chapter2_0087:
                rs "谢谢你，伊尔兰。"
            jump cynechoice3done

        "保持沉默":
            window show dissolve
            jump cynechoice3done

label cynechoice3done:
    translate None cyne_chapter2_0088:
        "他转身离去，很快消失在夜色中。"
    translate None cyne_chapter2_0089:
        rs "还是那么神秘又麻烦…"
    translate None cyne_chapter2_0090:
        c c wang "肯定没安好心…"
    translate None cyne_chapter2_0091:
        rs c wsur "是吗？"
    translate None cyne_chapter2_0092:
        c "我听说过他。都是些零碎传闻，但高阶家族都知道这个人。"
    translate None cyne_chapter2_0093:
        c "他迷人、聪明、狡诈…如果你有秘密，他不仅知道还会拿来要挟你。"
    translate None cyne_chapter2_0094:
        rs "我曾以为他是出于好意帮我们，但…他似乎是另有所图，对吧？"
    translate None cyne_chapter2_0095:
        "反观维拉斯，看起来单纯善良得要命…实在难以想象他会利用我们。"
    translate None cyne_chapter2_0096:
        rs c whap "好啦，现在先别操心这个。今晚该庆祝才对！"
    translate None cyne_chapter2_0097:
        "我们结伴走向银柳。赛恩步伐轻快，还挽住了我的胳膊。"
    translate None cyne_chapter2_0098:
        rs "怎么这么开心？"
    translate None cyne_chapter2_0099:
        c c whap "不明显吗？"
    translate None cyne_chapter2_0100:
        rs c wsur "…因为打听到卡斯皮安的事？"
    translate None cyne_chapter2_0101:
        c "那个…也算吧。主要是今晚终于能独占你了。"
    translate None cyne_chapter2_0102:
        rs c wemb "哦…哦…"
    translate None cyne_chapter2_0103:
        c c wsur "哦，在这里等一下好吗？我得去莱拉斯那里取点东西！"
    translate None cyne_chapter2_0104:
        "还没等我提问，他就冲进了黑暗里，留下我一个人等他。我趁机环顾四周—说真的，这座城市美得惊人。"
    translate None cyne_chapter2_0105:
        "没过多久，赛恩就回来了，手里提着个小袋子，但拒绝给我看里面的东西。"
    translate None cyne_chapter2_0106:
        "我们找路回到客栈，走进大厅时我感觉自己的心跳已经开始加速。"
    window hide dissolve

    scene bg sw night with dissolve:
        xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.62
        linear 25.0 xpos 0.5 ypos 1.58 xanchor 0.5 yanchor 1.0 zoom 1.62
    window show dissolve
    translate None cyne_chapter2_0107:
        "艾琳站在柜台后面，正忙着写些什么。她抬头看了看赛恩，微微一笑，然后继续做她的事。"
    translate None cyne_chapter2_0108:
        "赛恩拉着我快步走向我的房间。"
    stop music fadeout 2.0
    window hide dissolve

    scene bg swroom night with dissolve
    window show dissolve
    translate None cyne_chapter2_0109:
        "我轻轻关上门，转身面对赛恩。已经能感觉到脸颊在发烫。"
    translate None cyne_chapter2_0110:
        rs wemb "那么，现在要—嗯！"
    translate None cyne_chapter2_0111:
        play music "sounds/bgm/sex.ogg" fadein 3.0
        "转眼间他的脸就离我只有几英寸，双腿环住我的腰。在他跳进我怀里的瞬间，我勉强稳住自己。"
    translate None cyne_chapter2_0112:
        "他把我的脸拉向他，用舌头撬开我的嘴唇深深吻我。我的手爬过他的后背，将他紧紧贴在我身上。"
    translate None cyne_chapter2_0113:
        "这和我想象的不太一样—时间没有停止，世界也没有突然变得完美—就是炙热，充满激情，仿佛除了快感什么都不重要。"
    translate None cyne_chapter2_0114:
        "而我沉溺在这种感觉中。"
    translate None cyne_chapter2_0115:
        "他碰触的每个地方都像火烧般灼热，随时我都可能膝盖发软，瘫倒成一团幸福的浆糊。"


    show bg swroom night with hpunch:
        xpos 0.55 ypos 1.06 xanchor 0.59 yanchor 0.95 zoom 1.75

    translate None cyne_chapter2_0116:
        "当赛恩贴着我的唇呻吟时，我盲目的在房间里跌跌撞撞，最终找到床边倒下。我的身体压在他身上。他的袋子被甩到完美的床单上—如今被我们的身体弄得皱皱巴巴，被遗忘了。"
    translate None cyne_chapter2_0117:
        "赛恩用灼热的眼神抬头看着我，充满渴望。"
    translate None cyne_chapter2_0118:
        c wsmi "这就停了？"
    translate None cyne_chapter2_0119:
        "我们的嘴唇再次相接，赛恩迅速用舌头撬开我的唇。这个吻如此深入，令人沉醉。让我觉得仅仅一个吻就能让我失去理智。"
    translate None cyne_chapter2_0120:
        rs wemb "嗯…"
    translate None cyne_chapter2_0121:
        "下一秒我的背就贴在了床上，赛恩撑在我上方。他在没中断亲吻的情况下就把我翻了个身，轻松得像我没有重量。"
    translate None cyne_chapter2_0122:
        "他的胯部蹭着我，一声呻吟从我唇间逸出，这让赛恩很愉悦。他顽皮地低头冲我咧嘴笑了。"
    translate None cyne_chapter2_0123:
        c "你喜欢这样吗？"
    translate None cyne_chapter2_0124:
        rs "..."
    translate None cyne_chapter2_0125:
        c "如果不喜欢我可以停下。"
    translate None cyne_chapter2_0126:
        rs "我…我喜欢！真的…真的很喜欢…"
    translate None cyne_chapter2_0127:
        "赛恩的吻沿着我的脖颈一路上移，最后停在耳垂轻轻啃咬。当他喘着粗气向我低语时，我的呼吸瞬间停滞。"
    translate None cyne_chapter2_0128:
        c "我知道还有更让你喜欢的。"
    translate None cyne_chapter2_0129:
        rs "...?"
    translate None cyne_chapter2_0130:
        "他故意磨蹭着滑下我的身体，最后跪在床边地板上。"
    translate None cyne_chapter2_0131:
        "他的手掌顺着我的大腿向上游移，指尖离敏感处越来越近，直至完全覆住我已挺立的阴茎。"
    translate None cyne_chapter2_0132:
        "他轻轻套弄着，将脸颊贴上我的大腿，睁着湿漉漉的眼睛仰视我。"
    translate None cyne_chapter2_0133:
        rs "啊…"
    translate None cyne_chapter2_0134:
        c "想知道我在想什么吗？"
    translate None cyne_chapter2_0135:
        rs "啊…想…"
    translate None cyne_chapter2_0136:
        c "我在想你插进来填满我的样子，想你干得我明天都下不了床。"
    translate None cyne_chapter2_0137:
        "赛恩每个字都浸着色欲。他手心的温度，脸上的表情—这些都让我裤裆里胀得更硬。"
    translate None cyne_chapter2_0138:
        c "不过首先…让我尝尝怎么样？"
    translate None cyne_chapter2_0139:
        "没等我回答，赛恩已扯开我的衣物，让半硬的性器暴露在空气中。他饥渴地凝视着它。"
    translate None cyne_chapter2_0140:
        "光是想象他触碰我的画面就令小腹发紧。我羞怯地透过半阖的眼帘向下看，正撞见他用手圈住我的阴茎。"
    translate None cyne_chapter2_0141:
        rs "嗯…啊，赛恩…"
    translate None cyne_chapter2_0142:
        "他缓缓撸动，拇指蹭过顶端，同时轻啃我的大腿内侧。"
    translate None cyne_chapter2_0143:
        c "等不及要你进来了。"
    translate None cyne_chapter2_0144:
        "我能感觉到赛恩的呼吸越来越重，脊椎窜过一阵战栗。"

    window hide dissolve


    scene gallery_80:
        xpos 0.5 ypos 1.01 xanchor 0.5 yanchor 1.0 zoom 1.54
    if persistent.streamer_mode == True:
        show cyne_1_sex_censor:
            xpos 0.5 ypos 1.01 xanchor 0.5 yanchor 1.0 zoom 1.54
    with dissolve

    window show dissolve
    translate None cyne_chapter2_0145:
        "赛恩故意放慢动作，湿热的舌头从茎身慢慢舔到顶端，稍作停顿后又换回手的抚慰。"
    translate None cyne_chapter2_0146:
        c "哈啊…"
    translate None cyne_chapter2_0147:
        rs "赛恩…哈啊…太…舒服了.."
    translate None cyne_chapter2_0148:
        c "你以为我会让你失望？"
    translate None cyne_chapter2_0149:
        "他的手沾着前液熟练滑动，突然松开。我猛地睁开紧闭的眼睛，正好看见赛恩张唇将我的性器含了进去。"
    translate None cyne_chapter2_0150:
        rs "啊！"
    translate None cyne_chapter2_0151:
        scene gallery_80
        if persistent.streamer_mode == True:
            show cyne_1_sex_censor
        with dissolve
        "他直接吞到根部，我能感觉到自己顶到他喉咙深处。难以抑制的呻吟冲出喉咙，几乎能感受到赛恩贴着我的坏笑。"
    translate None cyne_chapter2_0152:
        "他的嘴温热湿润，这种感觉前所未有。"
    translate None cyne_chapter2_0153:
        "他的舌尖沿着我的柱身滑动，头部轻轻起伏几乎不费力气。"
    translate None cyne_chapter2_0154:
        rs "哈啊、嗯…啊！"
    translate None cyne_chapter2_0155:
        "未及察觉，赛恩已褪去衣衫，我再次为这美景着迷。如此美丽光滑的肌肤，还有—"
    translate None cyne_chapter2_0156:
        "还有…他硬挺的阳具，让我移不开视线。"
    translate None cyne_chapter2_0157:
        "他含住我的性器呻吟着，吞吐吮吸。他先完全退出，又再次深深吞入。"
    translate None cyne_chapter2_0158:
        "与此同时，赛恩的手指正悄悄探向自己后方按压。"
    translate None cyne_chapter2_0159:
        rs "你在、啊…做什么…？"
    translate None cyne_chapter2_0160:
        "他离开我的阴茎，垂落的涎液滴在我身上。"
    translate None cyne_chapter2_0161:
        c "哈…嗯…正在为你做准备…"
    translate None cyne_chapter2_0162:
        "赛恩吐出舌头再次舔过我的顶端，我能感觉到自己在他唇间颤动。"
    translate None cyne_chapter2_0163:
        "求你…我想…想再进入你嘴里…"
    translate None cyne_chapter2_0164:
        "我腰胯耸动，赛恩抬眼望来，绿眸蒙着水雾却继续撩拨。他的舌尖绕着顶端打转，随后轻轻含住柱身下滑。"
    translate None cyne_chapter2_0165:
        rs "操…赛恩，我要你…快疯了…"
    translate None cyne_chapter2_0166:

        scene bg swroom night with dissolve
        "转眼赛恩的唇又压了上来。我们贪婪接吻，呻吟淹没在狂热中。他双手环抱我的肩膀，将我们紧密相贴。"
    translate None cyne_chapter2_0167:
        "我们的性器互相挤压，我的手紧扣赛恩胯部，指尖陷入肌肤。能感受到自己血脉偾张，渴求更多抚触。"
    translate None cyne_chapter2_0168:
        "所有理智都被原始冲动淹没，只想完全占有赛恩。"
    translate None cyne_chapter2_0169:
        "他轻啃我下唇的瞬间终于击溃防线。我们四目相对，眼中尽是情欲。"
    translate None cyne_chapter2_0170:
        "靠…他太会接吻了…"
    translate None cyne_chapter2_0171:
        "赛恩退开身，同时抚弄我们挺立的阴茎，两人喘息粗重，蒸腾着热气。"
    translate None cyne_chapter2_0172:
        c wemb "我…从莱拉斯那里拿了点东西…"
    translate None cyne_chapter2_0173:
        "他朝包裹示意，我倾身倒出内容物。一个小瓶子滚落，泛着微光。"
    translate None cyne_chapter2_0174:
        rs wemb "这是…什么？"
    translate None cyne_chapter2_0175:
        c "嗯、哈…能让…整个过程…更顺畅…是润滑剂…"
    translate None cyne_chapter2_0176:
        "我把瓶子递给他，他迅速拧开瓶盖，将液体倾泻在我们两人的阴茎上。"
    translate None cyne_chapter2_0177:
        rs "啊…！好冰…"
    translate None cyne_chapter2_0178:
        c "不会冰太久的…"
    translate None cyne_chapter2_0179:
        show cyneroute11b with dissolve
        "他的手指同时抚弄着我们，润滑液让他的手能在我们皮肤上顺畅滑动。"
    translate None cyne_chapter2_0180:
        c "操，我需要你进来。现在就要。"
    translate None cyne_chapter2_0181:
        "他直白的表达让我的脸烧了起来，但我全身每个细胞都赞同他的说法—没必要感到难为情。他想要我，我也想要他。"
    translate None cyne_chapter2_0182:
        "他的声音嘶哑哽咽，仿佛正在极力克制自己。"
    translate None cyne_chapter2_0183:
        rs "嗯，哈啊，我该…我该怎么做…？"
    translate None cyne_chapter2_0184:
        c "…啊…交给我来处理。"
    translate None cyne_chapter2_0185:
        "他抬起胯部悬在我上方，手向下探去握住了我的阳具。"
    translate None cyne_chapter2_0186:
        "他将龟头引向自己的臀缝，挑逗地让我的性器在他股间摩擦。"
    translate None cyne_chapter2_0187:
        "我的身体猛然一颤，但赛恩稍稍退开，让我继续等待。"
    translate None cyne_chapter2_0188:
        rs "求你…"
    translate None cyne_chapter2_0189:
        "我再次抓住他的臀部，向他央求。"
    translate None cyne_chapter2_0190:
        scene gallery_81
        if persistent.streamer_mode == True:
            show cyne_2_sex_censor
        with dissolve
        "带着情欲驱动的坏笑，他缓缓坐上了我的阴茎。他咬着嘴唇，脸上浮现狂喜神情，唇间漏出大声呻吟。"
    translate None cyne_chapter2_0191:
        c "嗯…"
    translate None cyne_chapter2_0192:
        rs "啊—"
    translate None cyne_chapter2_0193:
        "操，操…这感觉…操…"
    translate None cyne_chapter2_0194:
        "赛恩轻松地容纳了我全部的尺寸。"
    translate None cyne_chapter2_0195:
        c "操，雷恩…"
    translate None cyne_chapter2_0196:
        "他的声音带着呜咽，微弱得近乎呻吟。"
    translate None cyne_chapter2_0197:
        "一切都是那么紧致炙热，我感觉自己坚持不了多久。还没等我平复呼吸适应这种感受，赛恩就再次抬起了臀部。"
    translate None cyne_chapter2_0198:
        scene gallery_81
        if persistent.streamer_mode == True:
            show cyne_2_sex_censor
        with vpunch
        "他俯身贴近我，我紧紧抱住他，随即他猛地重新坐回我的阴茎上。"
    translate None cyne_chapter2_0199:
        c "啊！啊，操，嗯…！"
    translate None cyne_chapter2_0200:
        rs "哈啊，哈啊…！"
    translate None cyne_chapter2_0201:
        "快感的电流窜过全身，我的阴茎在赛恩内壁脉动。每次抽插都将我们推向更极致的巅峰。"
    translate None cyne_chapter2_0202:
        "我的手指陷入赛恩的肌肤，发现自己的胯部正主动迎合着他，让情潮愈演愈烈。"
    translate None cyne_chapter2_0203:
        "润滑液从他臀间渗出，滴落在我们身上，但这无关紧要。无论多么狼藉，多么湿泞，这正是我渴求的。"
    translate None cyne_chapter2_0204:
        "赛恩的脸扭曲着，脊柱因快感而弓起。抽插变得愈发疯狂，越来越用力，直到我俩都沦为一团喘息与呻吟的混乱。"
    translate None cyne_chapter2_0205:
        c "操，就是那里！啊，哈啊！"
    translate None cyne_chapter2_0206:
        "每次我插入他时，赛恩的脸因快感扭曲得更厉害。他的阴茎在我腹部摩擦着跳动，沾满润滑液和前液。"
    translate None cyne_chapter2_0207:
        "我抓住他的臀，在他一次次坐上来时掰开臀瓣，他则在快感中放声尖叫。"
    translate None cyne_chapter2_0208:
        scene gallery_81b
        if persistent.streamer_mode == True:
            show cyne_2_sex_censor
        with dissolve
        "我用空着的手握住他的阴茎，随着抽插的节奏撸动。"
    translate None cyne_chapter2_0209:
        rs "太…哈啊…太紧了…"
    translate None cyne_chapter2_0210:
        "他突然慢下来，小心翼翼地缓缓退出。阴茎暴露在冷空气中的感觉让我战栗。他涨红着脸，眼帘低垂地俯视我，咬着下唇。"
    translate None cyne_chapter2_0211:
        "紧接着他猛然沉下臀部，再度将我纳入体内，重获先前的节奏。"
    translate None cyne_chapter2_0212:
        "我感到自己在他体内胀大，每次抽送都带来陌生的感受—一种压迫感，强烈到几乎让我落泪的快感。"
    translate None cyne_chapter2_0213:
        rs "赛恩我—我要—"
    translate None cyne_chapter2_0214:
        c "再…再一会儿，哈啊！"
    translate None cyne_chapter2_0215:
        "他的声音充满渴求且紧绷。"
    translate None cyne_chapter2_0216:
        "赛恩加快节奏，一次次吞入我的全部，直到我眼前几乎发白。"
    translate None cyne_chapter2_0217:
        "他更用力地抓住我肩膀稳住自己。我能感觉到他双腿颤抖得几乎无法支撑。"
    translate None cyne_chapter2_0218:
        "我向上顶弄，迎合他臀部的每次起伏，摩擦他的内壁。一切都因快感而刺痛、搏动。"
    translate None cyne_chapter2_0219:
        "他的臀肉紧紧箍住我，却仍没有减速。"
    translate None cyne_chapter2_0220:
        c "哈啊—！"
    translate None cyne_chapter2_0221:
        "我知道自己撑不久了。赛恩娇小的身躯成为我脑海中唯一的画面—他深吞我阴茎时的表情，他放浪喊出我名字的模样，毫不畏惧被人听见，而最重要的是—对他做这一切的人是我。"
    translate None cyne_chapter2_0222:
        "或者说更像是他在驾驭我的身体—他完全掌控着节奏。这感觉…令人战栗，美妙地悖德而性感。"
    translate None cyne_chapter2_0223:
        "赛恩的动作开始紊乱，重重咬上我的肩膀。"
    translate None cyne_chapter2_0224:
        c "雷恩，我要—哈，我要射了—"
    translate None cyne_chapter2_0225:
        scene gallery_81b
        if persistent.streamer_mode == True:
            show cyne_2_sex_censor
        with vpunch
        "他一声声呼唤我的名字，我的身体随之颤抖，在他体内释放后，精液从他臀间溢出，沾满了我的阴茎。片刻之后，他也达到高潮，白浊液体喷溅在我们两人的胸膛上。"
    translate None cyne_chapter2_0226:
        "他的腰胯停止摆动，整个人瘫软在我身上剧烈喘息。他全身都在颤抖，双手紧紧攀附着我。"

    stop music fadeout 2.0
    window hide dissolve

    scene bg swroom night with dissolve
    window show dissolve
    translate None cyne_chapter2_0227: #PICKUP NEEDED
        rs wemb "哈啊……赛恩……"
    translate None cyne_chapter2_0228:
        c wsmi "怎么样…还满意吗…？"
    translate None cyne_chapter2_0229:
        play music "sounds/bgm/night.ogg" fadein 2.0
        rs "我…觉得这大概是我经历过最美妙的事…"
    translate None cyne_chapter2_0230:
        c "哈哈哈…看吧，等待是值得的。"
    translate None cyne_chapter2_0231:
        rs "你可没说事后会这么筋疲力尽…"
    translate None cyne_chapter2_0232:
        c whap "这样你就能永远记住我了。"
    translate None cyne_chapter2_0233:
        rs wsur "怎么，你打算去哪？"
    translate None cyne_chapter2_0234:
        c wsur "...."
    translate None cyne_chapter2_0235:
        c "呃，我不能整夜不归。要是你忘了，我现在可是被禁足状态。"
    translate None cyne_chapter2_0236:
        rs wsad "可是…"
    translate None cyne_chapter2_0237:
        "我将他的身躯紧紧搂在怀中。他蜷缩在我臂弯里显得如此娇小而脆弱。"
    translate None cyne_chapter2_0238:
        c wsad "啊…管他呢。反正已经惹上麻烦，再多一桩又何妨？"
    translate None cyne_chapter2_0239:
        c wsmi "现在你应该准备好第二轮了吧…？"
    translate None cyne_chapter2_0240:
        rs wsur "什么？！"
    translate None cyne_chapter2_0241:
        c "啊哈哈，开玩笑的！我也没那个体力了。或许明早？"
    translate None cyne_chapter2_0242:
        rs "...."
    translate None cyne_chapter2_0243:
        c wsur "该不会现在反倒害羞了吧？明明刚才呻吟冲撞得那么热烈？"
    translate None cyne_chapter2_0244:
        rs wemb "晚…晚安！"
    translate None cyne_chapter2_0245:
        "我拉过被单盖住自己和咯咯发笑的赛恩。他依偎过来，把脑袋埋进我的颈窝。"
    translate None cyne_chapter2_0246:
        c wneu "晚安，雷恩。很愉快。真的。"
    translate None cyne_chapter2_0247:
        "我沉浸在这般思绪中慢慢入睡，耳畔仍回荡着赛恩说话时的语调。"

    window hide dissolve

    scene black with eye_shut

    if iv_scene_one and illranveras_friend >= 3:
        stop music fadeout 2.0
        jump illranverasscene2
    else:
        scene black with eye_shut
        pause 1.0
        jump cyneroute2continued

label cyneroute2continued:
    scene bg swroom day with dissolve
    window show dissolve
    translate None cyne_chapter2_0248:
        rs "嗯…"
    translate None cyne_chapter2_0249:
        "又是空虚的梦境…你在哪里…？"
    translate None cyne_chapter2_0250:
        "我睡眼惺忪地环顾奢华卧室。如此考究的陈设…恐怕永远都无法习惯。"
    translate None cyne_chapter2_0251:
        "新衣裳、华美床榻、舞会…这么多新鲜事物。"
    translate None cyne_chapter2_0252:
        "……还有……"
    translate None cyne_chapter2_0253:
        play music "sounds/bgm/night.ogg" fadein 2.0
        "赛恩。"
    translate None cyne_chapter2_0254:
        "他的胸膛在我身畔平稳起伏，双眼仍紧闭着。"
    translate None cyne_chapter2_0255:
        "光是注视他就让我心头涌起暖意。这是…什么感觉？"
    translate None cyne_chapter2_0256:
        "因为昨夜的缠绵吗…？"
    translate None cyne_chapter2_0257:
        c wsmi "现在应该准备好第二轮了吧？"
    translate None cyne_chapter2_0258:
        "我正想得出神，没注意醒来的赛恩正用手肘支起身子，冲我坏笑。"
    translate None cyne_chapter2_0259:
        rs wemb "要…要不晚点…我们还得…你懂的，有正事要办…"
    translate None cyne_chapter2_0260:
        "我脑海中的话语原本条理分明，但说出口时却变得一团混乱。"
    translate None cyne_chapter2_0261:
        "我这是怎么了？平时和他交谈从不会这样困难…"
    translate None cyne_chapter2_0262:
        "一定是太尴尬了。毕竟昨晚…"
    translate None cyne_chapter2_0263:
        c "啧，真没意思。不过晚点还有机会。今天我不介意继续扮演侦探的角色。"
    translate None cyne_chapter2_0264:
        "衣物凌乱地散落在房间里，昨晚我们毫不在意地将它们四处丢弃。当我穿衣时，能感受到赛恩灼热的视线。"
    translate None cyne_chapter2_0265:
        "我无法与他目光相接。这种心情…究竟是什么？"
    window hide dissolve

    scene bg sw day
    show raen nw sur cloak at slightright
    show cyne nw neu cloak at slightleft
    with dissolve
    window show dissolve
    translate None cyne_chapter2_0266:
        "我们离开房间，本以为会看见莱奥斯和福恩在等我们，却不见他们的踪影。"
    translate None cyne_chapter2_0267:
        c "哼，他们真扫兴。干脆我们两个走吧。"
    translate None cyne_chapter2_0268:
        show raen nw sur with dis
        rs "不该叫醒他们吗？"
    translate None cyne_chapter2_0269:
        show cyne nw sur with dis
        c "有时间吗？回头再告诉他们详情好了。"
    translate None cyne_chapter2_0270:
        show raen nw sad with dis
        rs "好吧…你说得对。"
    translate None cyne_chapter2_0271:
        "我再次躲开他的注视。倒不是介意和赛恩独处，只是…希望有另两人在场能缓解这种凝滞的气氛。"
    translate None cyne_chapter2_0272:
        show cyne nw neu with dis
        c "..."
    translate None cyne_chapter2_0273:
        show cyne nw sad with dis
        c "为什么…为什么要这样冷淡对我，明明昨晚…我都允许你那样做了..我快要哭出来了…"
    translate None cyne_chapter2_0274:
        show raen nw sur with dis
        rs "…！不，才没有！我只是…觉得有点害羞…"
    translate None cyne_chapter2_0275:
        show cyne nw hap with dis
        c "哈哈，逗你玩的。"
    translate None cyne_chapter2_0276:
        show cyne nw smi with dis
        "他的手指抚过我的大腿，倾身在我耳边低语。"
    translate None cyne_chapter2_0277:
        show raen nw emb blush with dis
        c "反正你害羞的样子很可爱。"
    translate None cyne_chapter2_0278:
        "他咧嘴笑着退开，仅是寥寥数语就让我面颊发烫。"
    translate None cyne_chapter2_0279:
        "只是有点害羞而已。不然怎会心跳加速？"
    translate None cyne_chapter2_0280:
        "我们转身推开前门，踏入寒冷的冬日景色中。"

    stop music fadeout 2.0
    window hide dissolve

    scene bg sc day with fade
    window show dissolve
    play music "sounds/bgm/discovery.ogg" fadein 2.0
    translate None cyne_chapter2_0281:
        "室外和平日毫无二致—银装素裹的仙境。孩子们已经开始互掷雪球，完全沉浸在自己的世界里。"
    translate None cyne_chapter2_0282:
        show raen nw smi cloak at slightright
        show cyne nw neu cloak at slightleft
        with dissolve
        rs "..真可爱。"
    translate None cyne_chapter2_0283:
        show cyne nw sur with dis
        c "小孩？可爱？明明是烦人精。我对养育孩子没兴趣。"
    translate None cyne_chapter2_0284:
        show raen nw sur with dis
        rs "真的？为什么？"
    translate None cyne_chapter2_0285:
        show cyne nw sad with dis
        c "....."
    translate None cyne_chapter2_0286:
        c "想象我当父亲的样子？光想想就可怕。"
    translate None cyne_chapter2_0287:
        show raen nw hap with dis
        rs "我觉得你会是个好爸爸。"
    translate None cyne_chapter2_0288:
        c "…我不能让任何人经历那种事。"
    translate None cyne_chapter2_0289:
        show raen nw sur with dis
        rs "经历什么？"
    translate None cyne_chapter2_0290:
        c "…没什么。总之你迟早会遇到好姑娘，拥有自己的孩子。"
    translate None cyne_chapter2_0291:
        show raen nw sad with dis
        rs "..."
    translate None cyne_chapter2_0292:
        show cyne nw neu with dis
        c "我们到了，看。"
    translate None cyne_chapter2_0293:
        "他指向前方路旁一栋建筑，招牌写着\"霍恩面包坊\"在风中摇晃。"
    translate None cyne_chapter2_0294:
        "一群人拎着鼓鼓囊囊的纸袋走出店铺，里面装着满溢的面包糕点，他们兴奋地叽叽喳喳说笑着。"
    translate None cyne_chapter2_0295:
        show raen nw sur with dis
        rs "应该就是这了。我们进去吗？时间还早，不过在里面等总比站在外面强。"
    translate None cyne_chapter2_0296:
        "我推开门，跟着赛恩走了进去。"

    window hide dissolve

    jump honezarryn

label cyneroute2continued2:

    scene bg sc sunset with dissolve:
        xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.33
        linear 10.0 xpos 0.5 ypos 1.2 xanchor 0.5 yanchor 1.0 zoom 1.33
    window show dissolve
    play music "sounds/bgm/night.ogg" fadein 2.0
    translate None cyne_chapter2_0297:
        rs c wsmi "…看来索伦有人照顾了。"
    translate None cyne_chapter2_0298:
        c c wneu "应该是最靠谱的人选了。伊尔兰虽然是个彻头彻尾的混蛋，但他有人脉。我只是好奇他怎么能说动扎林那样的人帮忙。"
    translate None cyne_chapter2_0299:
        rs c wsad "听说主要是靠要挟。"
    translate None cyne_chapter2_0300:
        c c wsad "我怎么一点儿都不意外呢？"
    translate None cyne_chapter2_0301:
        rs c wsur "...."
    translate None cyne_chapter2_0302:
        rs "你还好吗？"
    translate None cyne_chapter2_0303:
        c c wsur "我？我什么时候不好过？"
    translate None cyne_chapter2_0304:
        rs c wsad "嗯…"
    translate None cyne_chapter2_0305:
        c c wsad "我不是说了别管这事吗？没什么大不了的。"
    translate None cyne_chapter2_0306:
        rs "只是你从那时候起…表现就有点奇怪…"
    translate None cyne_chapter2_0307:
        c "我会恢复正常表现的，所以…别再提了。"
    translate None cyne_chapter2_0308:
        "别再提？"
    translate None cyne_chapter2_0309:
        "好吧…不关我的事。"
    translate None cyne_chapter2_0310:
        rs "那…我们去找卡斯皮安？"
    translate None cyne_chapter2_0311:
        c "先去找莱奥斯和福恩吧。他们不知道我们在哪。"
    translate None cyne_chapter2_0312:
        rs "有道理。"
    translate None cyne_chapter2_0313:
        "我们回到了银柳。赛恩勉强打起精神，但我还是能看出他不对劲。"

    stop music fadeout 2.0
    window hide dissolve

    scene bg sw day with dissolve
    window show dissolve
    translate None cyne_chapter2_0314:
        "进门时，我瞥见一抹红蓝身影。两人坐在大堂角落的小桌旁低声交谈。"
    translate None cyne_chapter2_0315:
        "本以为他们在说悄悄话，莱奥斯却突然提高了嗓门。"
    translate None cyne_chapter2_0316:
        play music "sounds/bgm/Fooling Around Tiny.ogg" fadein 1.5
        l wann "…啊！再来一局！"
    translate None cyne_chapter2_0317:
        f wsad "还来？"
    translate None cyne_chapter2_0318:
        l "我刚在热身而已，真的。来吧，再比一次。"
    translate None cyne_chapter2_0319:
        rs wsur "你俩在干嘛？"
    translate None cyne_chapter2_0320:
        f wemb "噢…雷恩…"
    translate None cyne_chapter2_0321:
        "他避开我的目光。"
    translate None cyne_chapter2_0322:
        l wneu "看不出来吗？明显在扳手腕啊。"
    translate None cyne_chapter2_0323:
        c whap "哎呀，希望你对福恩手下留情哦。"
    translate None cyne_chapter2_0324:
        l wsur "留情？！你觉得我有资格对他放水？"
    translate None cyne_chapter2_0325:
        "两人的手紧扣在桌面上，气氛剑拔弩张。我看到莱奥斯额头沁出汗珠，死死盯着福恩。"
    translate None cyne_chapter2_0326:
        "砰！莱奥斯的手瞬间被按倒在桌上。福恩叹了口气。"
    translate None cyne_chapter2_0327:
        f wsad "…这下够了吧？"
    translate None cyne_chapter2_0328:
        l wann "…我…我其实是让着你的懂不懂？！"
    translate None cyne_chapter2_0329:
        c "啊哈哈哈，这发现太精彩了。咱们的不良少年莱奥斯居然连掰手腕都赢不了福恩这么温柔可爱的人？"
    translate None cyne_chapter2_0330:
        c "哦，知道这个消息我真是太开心了。"
    translate None cyne_chapter2_0331:
        l "闭嘴吧你们。你们两个一整天都去哪儿了？"
    translate None cyne_chapter2_0332:
        c "呃…这个嘛…"
    translate None cyne_chapter2_0333:
        c wsad "雷恩把我拴在他床上不让走…他折腾了我一整天加一整夜，太丢人了…"
    translate None cyne_chapter2_0334:
        stop music fadeout 2.0
        rs wneu "...."
    translate None cyne_chapter2_0335:
        rs "要听完整版还是精简版？"
    translate None cyne_chapter2_0336:
        l wneu "精简版，我没那么多时间。"
    translate None cyne_chapter2_0337:
        l "好吧…我应该是有整天时间啦，但不想听你唠叨那么久。快点说。"
    translate None cyne_chapter2_0338:
        play music "sounds/bgm/night.ogg" fadein 3.0
        rs "…昨晚我们遇到个认识卡斯皮安的人，今天就约见了。他给我们指了正确方向。"
    translate None cyne_chapter2_0339:
        f wsur "真的吗？！"
    translate None cyne_chapter2_0340:
        rs wsmi "是啊。简直不敢相信…"
    translate None cyne_chapter2_0341:
        rs "我们还见到了伊尔兰，他介绍了照顾索伦的人给我。我觉得他被照料得很好。"
    translate None cyne_chapter2_0342:
        c whap "抱歉…我实在忍不住！你俩就在这儿掰了一整天手腕？"
    translate None cyne_chapter2_0343:
        l wemb "我不是让你闭嘴了吗？"
    translate None cyne_chapter2_0344:
        c "呜哇，我就喜欢你用这种语气命令我。再多指使我几句嘛。"
    translate None cyne_chapter2_0345:
        l "呃…"
    translate None cyne_chapter2_0346:
        f wsur "那我们还等什么？"
    translate None cyne_chapter2_0347:
        l wthi "对啊，赶紧离开这儿。我受够呆在屋里了。"
    translate None cyne_chapter2_0348:
        c wsad "等等。我，那个…"
    translate None cyne_chapter2_0349:
        "他挠着后脑勺，眼神飘忽就是不敢看我。"
    translate None cyne_chapter2_0350:
        c "能等到明天吗？"
    translate None cyne_chapter2_0351:
        rs wsur "为什么？都快成功了…"
    translate None cyne_chapter2_0352:
        c "…说实话。拿到舞会邀请函可不便宜。作为交换，我答应了今晚陪母亲吃饭。"
    translate None cyne_chapter2_0353:
        l wneu "那我们自己去好了。"
    translate None cyne_chapter2_0354:
        c "呃…其实雷恩也得一起去。"
    translate None cyne_chapter2_0355:
        rs "我？她为什么要和我吃饭？"
    translate None cyne_chapter2_0356:
        c "….不知道。"
    translate None cyne_chapter2_0357:
        rs "看来我没得选。如果陪你母亲吃晚饭就是找到卡斯皮安的代价…那我算赚到了。"
    translate None cyne_chapter2_0358:
        c "我劝你别高兴太早…"
    translate None cyne_chapter2_0359:
        rs "嗯？你说什么？"
    translate None cyne_chapter2_0360:
        c "…没什么，走吧。"
    translate None cyne_chapter2_0361:
        l "看来我们又得干等着你了。"
    translate None cyne_chapter2_0362:
        c wsmi "出去玩啊，扫兴鬼。"
    translate None cyne_chapter2_0363:
        "赛恩抓住我的手腕，拽着我出了门。当我回头挥手告别时，看到他们又开始新一轮掰手腕比赛。"
    translate None cyne_chapter2_0364:
        "莱奥斯，加油啊！"

    window hide dissolve

    scene bg sc night with dissolve
    window show dissolve
    translate None cyne_chapter2_0365:
        rs c whap "那两个人现在还真是一对儿…你该看看他们初次见面的样子。当时根本合不来。"
    translate None cyne_chapter2_0366:
        c c wsur "你会以为福恩是他弟弟什么的。他防御心特别重。"
    translate None cyne_chapter2_0367:
        rs "啊哈哈哈。"
    translate None cyne_chapter2_0368:
        "虽然赛恩的语调带着戏弄，但他眼里少了往常那种顽皮的光芒。"
    translate None cyne_chapter2_0369:
        "他最近确实表现得很奇怪。"
    translate None cyne_chapter2_0370:
        "我们并肩走在锡德卡汉积雪的漆黑街道上。话不多，但很惬意。"
    translate None cyne_chapter2_0371:
        "越往山上走—我猜是越接近他家—他的脸色就越阴沉，拳头在身侧越攥越紧。"
    translate None cyne_chapter2_0372:
        "或许我可以…"
    translate None cyne_chapter2_0373:
        "我慢慢伸出手，指尖轻轻划过他的指节。"

    if cyne_goodend > cyne_badend:
        show cyne mw dark sur cloak at mright
        show raen mw dark neu blush cloak at mleft
        with dissolve
        translate None cyne_chapter2_0374:
            c "…？你在干什么？"
        translate None cyne_chapter2_0375:
            rs "我只是觉得…"
        translate None cyne_chapter2_0376:
            "他的目光从我的手指游移到我的脸，又低垂下去，最后绽开温暖的笑容。"
        translate None cyne_chapter2_0377:
            show cyne mw dark hap with dis
            c "你还真是有点浪漫主义，对吧？"
        translate None cyne_chapter2_0378:
            show raen mw dark sad with dis
            rs "…也许是吧，我自己也不太清楚。"
        translate None cyne_chapter2_0379:
            "我们的手指如此自然地交缠在一起。"
        translate None cyne_chapter2_0380:
            show raen mw dark neu -blush with dis
            rs "你很担心，是吗？"
        translate None cyne_chapter2_0381:
            show cyne mw dark sad with dis
            c "有点…好吧，非常担心。她…你真的不能信任她。"
        translate None cyne_chapter2_0382:
            rs "别担心，我不会中任何圈套。"
        translate None cyne_chapter2_0383:
            c "雷恩…我实在不想当这个恶人，但你确实有点蠢。"
        translate None cyne_chapter2_0384:
            show raen mw dark sur with hpunch
            rs "什么？！"
        translate None cyne_chapter2_0385:
            c "我觉得你专门就往别人的陷阱里跳。"
        translate None cyne_chapter2_0386:
            rs "我才没有！"
        translate None cyne_chapter2_0387:
            c "我绞尽脑汁也想不出有谁没用某种方式骗过你。"
        translate None cyne_chapter2_0388:
            rs "连你也…？"
        translate None cyne_chapter2_0389:
            show cyne mw dark neu with dis
            c "........."
        translate None cyne_chapter2_0390:
            show cyne mw dark sad with dis
            c "噢…我们到了。"

        hide cyne
        hide raen
        with dissolve

    else:
        translate None cyne_chapter2_0391:
            c c wsur "…？你在干什么？"
        translate None cyne_chapter2_0392: # voice map line
            rs c wsad "我只是觉得…"
        translate None cyne_chapter2_0393:
            "他的目光从我的手指游离到我的脸，又低垂下去，最后转向别处。"
        translate None cyne_chapter2_0394:
            c c wsad "…抱歉，我实在没这个心情。"
        translate None cyne_chapter2_0395:
            rs c wsur "啊..不，该道歉的是我，我只是…"
        translate None cyne_chapter2_0396:
            "我尴尬地抽回手指，搜肠刮肚想找点话题。"
        translate None cyne_chapter2_0397:
            c "........"
        translate None cyne_chapter2_0398:
            c "噢…我们到了。"

    translate None cyne_chapter2_0399:
        "拐过街角后，一座气势恢宏的巨门映入眼帘。黑银两色构成的繁复纹饰中央，逐渐显现出刻着\"维蒙德\"字样的门牌。"
    translate None cyne_chapter2_0400:
        "这栋房子大得惊人—名副其实的豪宅。索伦的宅邸相形见绌。"
    translate None cyne_chapter2_0401:
        rs c wsur "这是不是…有点太过头了…？"
    translate None cyne_chapter2_0402:
        c c wsad "被震住了？别这样。都是装点门面罢了。"
    translate None cyne_chapter2_0403:
        show raen nw dark cloak neu at slightright
        show cyne nw dark cloak neu at slightleft
        with dissolve
        "我将手放在大门上，但当门突然从内侧打开时，我踉跄着向前跌去。抬头间，我与另一双眼睛四目相对。"
    translate None cyne_chapter2_0404:
        stop music fadeout 2.0
        show raen nw dark sur with dis
        play music "sounds/bgm/Fooling Around Tiny.ogg" fadein 2.0
        rs "……埃瑟？"
    translate None cyne_chapter2_0405:
        show cyne nw dark sur with dis
        e "……怎么又是你。"
    translate None cyne_chapter2_0406:
        show cyne with hpunch
        c "埃瑟！"
    translate None cyne_chapter2_0407:
        "他惊跳起来，脸上掠过恐惧的神色。"
    translate None cyne_chapter2_0408:
        show cyne nw dark sad with dis
        c "埃瑟…发生什么事了…？"
    translate None cyne_chapter2_0409:
        e "……少爷…我…我…"
    translate None cyne_chapter2_0410:
        "埃瑟跪倒在赛恩脚边，紧紧抱住他的双腿。"
    translate None cyne_chapter2_0411:
        e "真的很抱歉！我怎样才能得到原谅？！我什么都愿意做，什么都行。我…我可以裸着在宅邸里跑圈，我可以—"
    translate None cyne_chapter2_0412:
        c "那倒不必。来吧，站起来。你都把自己弄脏了。"
    translate None cyne_chapter2_0413:
        e "比起我给您带来的痛苦…这点尘土根本不算什么…如果您希望，我会立刻离开永不再来。"
    translate None cyne_chapter2_0414:
        c "…我只想知道发生了什么。"
    translate None cyne_chapter2_0415:
        e "…我不知道，大人，我…我只觉得自己恍恍惚惚。有个声音在召唤我，等我回过神来时，已经独自站在锡德卡汉的城门外了。"
    translate None cyne_chapter2_0416:
        e "您若不相信我也情有原由…连我自己都难以相信…"
    translate None cyne_chapter2_0417:
        "嗯…这事确实蹊跷…"
    translate None cyne_chapter2_0418:
        "我与赛恩交换眼神，他同样满脸困惑。我耸肩回应—考虑到最近发生的种种怪事，就算他说的是真话我也不会惊讶。"
    translate None cyne_chapter2_0419:
        c "好啦，快起来。我原谅你，行了吧？"
    translate None cyne_chapter2_0420:
        e "真的吗？！"
    translate None cyne_chapter2_0421:
        c "是真的。其实…如果你真想补偿我…"
    translate None cyne_chapter2_0422:
        show cyne nw dark neu with dis
        c "先透露下。里面现在什么情况？"
    translate None cyne_chapter2_0423:
        e "里面？噢！夫人正在餐厅等候您。她让厨师准备了极其丰盛的餐点…我都有些嫉妒了…"
    translate None cyne_chapter2_0424:
        c "待会儿我让人送些去你房间。现在先带我们进去。"
    translate None cyne_chapter2_0425:
        e "…她为什么非要见{i}这种人{/i}…"
    translate None cyne_chapter2_0426:
        show raen nw dark neu with dis
        rs "喂，我还站在这儿呢。你说的话我可都听见了。"
    translate None cyne_chapter2_0427:
        e "咿！请…请随我来，两位少爷！"
    translate None cyne_chapter2_0428:
        stop music fadeout 4.0
        "他领着我们穿过覆着柔软积雪的精致花园，穿过一扇厚重的大门。刚进入室内，就被一群穿着统一制服的人迅速迎了进来。"
    translate None cyne_chapter2_0429:
        "他们安排我们在烛光幽暗的宽敞餐厅里落座，面前是同样巨大的长桌。"

    window hide dissolve

    #scene gallery_83 with dissolve

    scene bg dining room with dis:
        subpixel True xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.46 rotate None
        parallel:
            xpos 0.72
            easein 20.79 xpos 0.45
    window show dissolve
    play music "sounds/bgm/creepy.ogg" fadein 3.0
    translate None cyne_chapter2_0430: #MISSING SCENE
        c wang"…看来您费了不少心思呢，母亲。"
    translate None cyne_chapter2_0431:
        lv smi "全力以赴？胡说。只有最好的才配得上我儿子和这样一位…尊贵的客人。"
    translate None cyne_chapter2_0432:
        c wsmi "您真是太客气了。对了，父亲去哪了？"
    translate None cyne_chapter2_0433:
        lv neu "你了解你父亲—总是忙这忙那。更重要的是…昨晚你去哪了？"
    translate None cyne_chapter2_0434:
        c wsad "....."
    translate None cyne_chapter2_0435:
        c "我…"
    translate None cyne_chapter2_0436:
        lv smi "真奇怪。我明明记得禁止你在外过夜，但仆人们今早说你不在房间。"
    translate None cyne_chapter2_0437:
        "房门再次吱呀作响地被推开，我能感觉到有人站在我身后。"
    translate None cyne_chapter2_0438:
        e "…少爷今早奉您之命，早早出门去会见阿斯特丽德小姐了，夫人。"
    translate None cyne_chapter2_0439:
        lv smi "…是这样吗？"
    translate None cyne_chapter2_0440:
        c wsmi "没错。您希望我今后不再见她吗？我很乐意照办。"
    translate None cyne_chapter2_0441:
        lv "…反正也没有见面的必要了，毕竟你的\"未婚妻\"就坐在这张餐桌旁，不是吗？"
    translate None cyne_chapter2_0442:
        c wang"....."
    translate None cyne_chapter2_0443:
        lv "你该不会对那可怜姑娘撒谎，好让她不再纠缠你吧？"
    translate None cyne_chapter2_0444:
        c "…您邀请雷恩来共进晚餐，就是为了整晚训斥我吗？"
    translate None cyne_chapter2_0445:
        lv "哎呀，我都忘了礼数。请用膳吧。"
    translate None cyne_chapter2_0446:
        "她的目光紧跟着我的一举一动。即便用餐时，她也从浓密的睫毛下注视着我。"
    translate None cyne_chapter2_0447:
        "这感觉有点…"
    translate None cyne_chapter2_0448:
        lv "那么…雷恩。别致的名字。原谅我的好奇，若你不介意，我有几个问题想问。"
    translate None cyne_chapter2_0449:
        rs wsmi "请便！呃，我是说…尽管问我好了。我知无不言。"
    translate None cyne_chapter2_0450:
        lv "知无不言？呵，真是讨人喜欢。"
    translate None cyne_chapter2_0451:
        lv "你来锡德卡汉做什么？只是来游玩吗？"
    translate None cyne_chapter2_0452:
        c "他是—"
    translate None cyne_chapter2_0453:
        lv neu "雷恩可以自己回答。"

    window hide

    menu:
        "我只是来游玩":
            $ cyne_goodend += 1
            window show dissolve
            jump cyneroute2visit

        "我在找人":
            $ cyne_badend += 1
            window show dissolve
            jump cyneroute2someone

label cyneroute2visit:
    translate None cyne_chapter2_0454:
        rs wsmi "…没错，我只是来游玩的。一直在各地旅行，见见世面。"

    jump cyneroute2after1

label cyneroute2someone:
    translate None cyne_chapter2_0455:
        rs wneu "其实…我在找一个人。一个能解答我疑问的人…"
    translate None cyne_chapter2_0456:
        lv smi "疑问？"
    translate None cyne_chapter2_0457:
        c wsmi "哎呀，母亲您可真是爱管闲事。没想到您对这么年轻的人也有兴趣。"
    translate None cyne_chapter2_0458:
        lv ang1 "…你需要学会管住舌头。"
    translate None cyne_chapter2_0459:
        lv smi "总之，这确实…非常有趣。"

    jump cyneroute2after1

label cyneroute2after1:
    translate None cyne_chapter2_0460:
        lv "好吧，这无关紧要。你来此的原因并不重要—重要的是你已经在这儿了。"
    translate None cyne_chapter2_0461:
        lv "不过我更好奇的是…你从哪来？"

    window hide

    menu:
        "托根":
            $ cyne_goodend += 1
            window show dissolve
            jump cyneroute2toggen

        "奥雷利亚卡维拉":
            $ cyne_badend += 1
            window show dissolve
            jump cyneroute2ac

label cyneroute2toggen:
    translate None cyne_chapter2_0462:
        rs wsmi "…其实我是从托根来的。你去过那里吗？"
    translate None cyne_chapter2_0463:
        lv smi "托根？噢，没有，对我来说太远了，去不了。"

    jump cyneroute2after2

label cyneroute2ac:
    translate None cyne_chapter2_0464:
        rs wneu"我是奥雷—"
    translate None cyne_chapter2_0465:
        c wang "你管他是从哪儿来的干什么？"
    translate None cyne_chapter2_0466:
        lv smi "难道我连对儿子看上的人表示点简单兴趣都不行吗？"
    translate None cyne_chapter2_0467:
        c "我希望你别这样。"

    jump cyneroute2after2

label cyneroute2after2:
    translate None cyne_chapter2_0468:
        lv smi "好吧，看来你确实经历了相当长的旅程，雷恩。这是最后一个问题，我保证。你去过斯塔格威奇或奥克斯哈伯吗？"
    translate None cyne_chapter2_0469:
        c wang "...."
    translate None cyne_chapter2_0470:
        rs wsur "你怎么会…事实上，我去过。"
    translate None cyne_chapter2_0471:
        lv "我知道。其实这些问题都只是为了消遣。我知道你是谁，也知道你去过哪里。"
    translate None cyne_chapter2_0472:
        lv "你就是那个带着神之刻印的诅咒之子。"
    translate None cyne_chapter2_0473:
        rs "什么…？"
    translate None cyne_chapter2_0474:
        lv "我不知道的是这些神之刻印到底意味着什么，但我有几个猜测。你想谈谈吗？"
    translate None cyne_chapter2_0475:
        lv "我很乐意帮你解决…你的问题，作为交换，你也要帮我解决我的问题。"
    translate None cyne_chapter2_0476:
        rs wsad "我…我觉得我帮不上你什么忙…"
    translate None cyne_chapter2_0477:
        lv "胡说。我相信你就是我要找的关键人物。"
    translate None cyne_chapter2_0478:
        c "我想我们该走了。"
    translate None cyne_chapter2_0479:
        lv "这么快？可我连订婚礼物都还没送呢。"
    translate None cyne_chapter2_0480:
        c "走吧，雷恩。待在这儿没好处。"
    translate None cyne_chapter2_0481:
        lv "又要夜不归宿了，是吗？"
    translate None cyne_chapter2_0482:
        c "会去。"
    translate None cyne_chapter2_0483:
        lv ang1 "以后你会后悔的。"
    translate None cyne_chapter2_0484:
        c "我想我会的。"
    translate None cyne_chapter2_0485:
        lv smi "既然你这么急着要走，我若挽留就太失礼了。西纳库洛斯，亲爱的，非常感谢你终于把我想要的那个男孩带来了—你提供的信息会很有用的。"
    translate None cyne_chapter2_0486:
        c "呃…雷恩，快点！"
    translate None cyne_chapter2_0487:
        "这尴尬的局面让我难受，但我还是照做了，从座位上站起来，留下盘中没吃完的食物。"

    if achievement.has("cyne_dinner"):
        pass
    else:
        $ renpy.display_notify("成就解锁：见岳母大人")

    python:
        achievement.grant("cyne_dinner")
        achievement.sync()
    translate None cyne_chapter2_0488:
        "我向赛恩的母亲微微鞠躬，然后追随着怒气冲冲冲出房间的赛恩。"
    translate None cyne_chapter2_0489:
        rs wsur "赛恩，等等…！"

    window hide dissolve

    scene bg sc night with dissolve:
        xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.46
        linear 17.0 xpos 0.5 ypos 1.43 xanchor 0.5 yanchor 1.0 zoom 1.46
    translate None cyne_chapter2_0490:
        rs c wsur "嘿，等等，赛恩…！"
    translate None cyne_chapter2_0491:
        c c wneu "快点，我们要回你的房间。"
    translate None cyne_chapter2_0492:
        rs "回我房间…？你确定不会惹上麻烦吗？"
    translate None cyne_chapter2_0493:
        c "现在我真的不在乎会惹上多大麻烦。你要整晚都宠爱我，让我忘记刚才发生的一切。"
    translate None cyne_chapter2_0494:
        rs c wemb "呃…噢…."
    translate None cyne_chapter2_0495:
        rs c wsad "但是，赛恩…她刚才说的话是什么意思…？"
    translate None cyne_chapter2_0496:
        c c wsad "...."
    translate None cyne_chapter2_0497:
        c "我们晚点再谈。嘿，过来一下。"
    translate None cyne_chapter2_0498:
        "赛恩消失在黑暗中，离开主道走进了锡德卡汉少数几处有树木覆盖的区域之一。"
    translate None cyne_chapter2_0499:
        "我往树林里张望，寻找赛恩的去向，突然一只手伸出来抓住了我的衣领。"
    translate None cyne_chapter2_0500:
        show bg sc night with hpunch
        rs c wsur "啊！"
    translate None cyne_chapter2_0501:
        stop music fadeout 2.0
        c c wsmi "嘘，嘘，你会把大家都吵醒的。"
    translate None cyne_chapter2_0502:
        "我刚因惊吓闭上眼睛，现在又缓慢而小心地睁开。"
    translate None cyne_chapter2_0503:
        c "我有那么可怕吗？"
    translate None cyne_chapter2_0504:
        rs c wsur "不，我…我没认出是你…"
    translate None cyne_chapter2_0505:
        c "你明明看着我往这边走。你真是个呆子，不是吗？"
    translate None cyne_chapter2_0506:
        "我踉跄后退，直到靠上一棵高大黑树的树干。赛恩眼中闪着光朝我逼近。"
    translate None cyne_chapter2_0507:
        rs "所以我们这是要—"


    play music "sounds/bgm/sex.ogg"
    translate None cyne_chapter2_0508:
        "赛恩瞬间缩短了我们之间的距离，将他的唇贴上我的。他把我抵在树上，踮起脚尖吻我。"
    translate None cyne_chapter2_0509:
        "一如往常，他的嘴唇很柔软—考虑到是赛恩，肯定精心保养过。他大概一天要涂好几次润唇膏。"
    translate None cyne_chapter2_0510:
        "但他的动作毫不温柔。他饥渴地、深深地吻着我，想要更多。"
    translate None cyne_chapter2_0511:
        rs "嗯…啊，赛恩…"
    translate None cyne_chapter2_0512:
        "他退开，脸上挂着狡黠的微笑，但我迅速把他拉回来，手托住他的下巴，拇指轻柔摩挲他的脸颊，然后用力回吻了他。"
    translate None cyne_chapter2_0513:
        c "总算…晚饭时我满脑子想的都是把我妈关在外面，还有你把我按在桌上的样子。"
    translate None cyne_chapter2_0514:
        rs "…你想在这里…做？要是被人看见呢？"
    translate None cyne_chapter2_0515:
        c "那才更有趣。你觉得呢？如果你不想在这里，我还有别的点子…"

    window hide

    menu:
        "我现在就想要你":
            window show dissolve
            jump outsidesex

        "我们回旅店吧":
            window show dissolve
            $ cyne_threesome = True
            jump threesome


label outsidesex:
    translate None cyne_chapter2_0516:
        rs "我再也等不及了…"
    translate None cyne_chapter2_0517:
        c "这正是我想听你说的。"
    translate None cyne_chapter2_0518:
        "当他更用力地把我按在树上轻咬我的嘴唇时，我的呼吸哽在喉咙里。我双手环抱住他的背，迅速让我们的身体贴得更近。"
    translate None cyne_chapter2_0519:
        "我能感受到他周身的热度，令人陶醉。谁在乎会不会被人看见？"
    translate None cyne_chapter2_0520:
        "我们的唇分开，我俯身将脸埋进赛恩颈弯，在他皮肤上留下细碎的吻。他慵懒地仰起头，更深入地接纳我。他发出轻柔的呻吟，全然不顾我们身在何处。"
    translate None cyne_chapter2_0521:
        "他的目光几乎要灼伤我，充满露骨的情欲热度。"
    translate None cyne_chapter2_0522:
        c "这就是你全部想要的吗，雷恩？"
        #window hide dissolve

        show cyneroute14crop with dissolve
        #window show dissolve
    translate None cyne_chapter2_0523:
        "我的名字被他喉间滚出的轻喘扼住了呼吸。当我们视线交汇，在我意识到之前，已将赛恩翻转过来。让他背靠树干，我紧贴上去，隔着衣物抚摸他的身体。"
    translate None cyne_chapter2_0524:
        "我的唇再次寻获他的喉结。每次轻咬与啄吻都引燃赛恩的低哼，他紧紧攀附着我。每一声沉重的喘息，每句脆弱呜咽都让我更加失控。"
    translate None cyne_chapter2_0525:
        c c wemb"你今天…真是热情..啊…"
    translate None cyne_chapter2_0526:
        "他的手掌流连过我身躯，最终停驻在胯部。他摆弄着衣料，手指看似无意地掠过我挺立的性器。刚好足够撩起更多渴望。"
    translate None cyne_chapter2_0527:
        rs c wemb"啊…"
    translate None cyne_chapter2_0528:
        "赛恩焦躁地拉扯着自己的衣物。"
    translate None cyne_chapter2_0529:
        c "快点…"
    translate None cyne_chapter2_0530:
        "不再满足于\"偶然\"触碰，赛恩用下身磨蹭我的裤裆，我感到布料迅速绷紧的程度超出了预期。膝盖颤抖得几乎站立不稳。"
    translate None cyne_chapter2_0531:
        "作为回应，我将手探入赛恩裤中，握住他灼热的勃起。开始稳定而缓慢地套弄，感受他脉动的阴茎在我掌中弹跳。"
    translate None cyne_chapter2_0532:
        "他的呻吟越来越响，就算此刻有居民误以为这里发生凶杀案也不足为奇。"
    translate None cyne_chapter2_0533:
        "我匆忙剥开赛恩层层衣物，将他暴露在锡德卡汉的凛冬中。他颤抖着，但分不清是因欢愉还是刺骨寒意。"
    translate None cyne_chapter2_0534:
        "赛恩手指勾住我裤沿，利落地将其扯落。"
    translate None cyne_chapter2_0535:
        "我们的衣物凌乱堆叠在雪地里。"
    translate None cyne_chapter2_0536:
        "确实冷得刺骨。"
    translate None cyne_chapter2_0537:
        "我向后探掌握住赛恩的臀部揉捏把玩。他终于找准我的性器，开始缓慢撸动。"
    translate None cyne_chapter2_0538:
        c "继续。告诉我你有多渴望我。"
    translate None cyne_chapter2_0539:
        rs "我…啊…我要你…想要得发疯…"
    translate None cyne_chapter2_0540:
        "他的声音如天鹅绒般柔滑。如此顺滑，即使充满呻吟也是如此。或许这让一切更美妙。像我这样的人竟能让像他这样的人发出这般声音。"
    translate None cyne_chapter2_0541:
        "赛恩的指尖拂过我的阴茎顶端，我不得不竭力克制自己不要因此扭动臀部。"
    translate None cyne_chapter2_0542:
        "他玩弄着我的欲望时，确保观察着我的每个反应。"
    translate None cyne_chapter2_0543:
        c "这次…这次你可以…"
    translate None cyne_chapter2_0544:
        "当他从外套口袋掏出小瓶子时，我困惑地看着他。哦。"
    translate None cyne_chapter2_0545:
        rs "…你随身带着这个？"
    translate None cyne_chapter2_0546:
        c "永远不知道什么时候会派上用场。眼下不正是时候么。"
    translate None cyne_chapter2_0547:
        "我接过瓶子，立即将液体涂抹在手指上。"
    translate None cyne_chapter2_0548:
        "只要…只要照他做的那样就行，对吧？"
    translate None cyne_chapter2_0549:
        "我几乎无法思考。每个念头都化为空白，脑海中全是光彩夺目的赛恩。"
    translate None cyne_chapter2_0550:
        "赛恩将双腿张得更开些，手上的动作毫不停歇。"
    translate None cyne_chapter2_0551:
        "我将涂了润滑剂的手指抵在他的入口处，观察他的表情确认是否可以。他点头后，我慢慢探入一根手指。他挪动身体，让手指进得更深。"
    translate None cyne_chapter2_0552:
        c "嗯…."
    translate None cyne_chapter2_0553:
        rs "这样…这样还行吗？"
    translate None cyne_chapter2_0554:
        c "何止是还行…"
    translate None cyne_chapter2_0555:
        "当我加入第二根手指后，他浅促的喘息变得更深沉。随着每次动作，每次手指的弯曲，他的背弓得越来越高，直到发出一声低沉响亮的呻吟。"
    translate None cyne_chapter2_0556:
        "我差点冲过去捂住他的嘴，提醒他我们身在何处—毕竟街道就在那边！—但我没有。此刻我完全不在乎了。"
    translate None cyne_chapter2_0557:
        "我用空着的手握住赛恩的阴茎，随着手指抽插的节奏抚弄。他的脸因快感而扭曲。"
    translate None cyne_chapter2_0558:
        c "快点…我想…啊…现在可以放进来了…"
    translate None cyne_chapter2_0559:
        "他无需再说第二遍。"
    translate None cyne_chapter2_0560:
        "我缓缓抽出手指—引得金发美人轻声呜咽—然后在赛恩惊恐的目光中将他抱起来。"
    translate None cyne_chapter2_0561:
        c "等等，等等，你要—"
    translate None cyne_chapter2_0562:
        "他很轻，几乎没什么重量，所以很容易就能把他抵在树上。"
    translate None cyne_chapter2_0563:
        scene gallery_86
        if persistent.streamer_mode:
            show cyne_3_sex_censor

        with dissolve
        "我在他入口处调整好位置，以一个缓慢悠长的动作慢慢进入，直到赛恩完全坐上了我的阴茎。"
    translate None cyne_chapter2_0564:
        "他浑身僵硬，凝固了一瞬，随后彻底瘫软在我身上。"
    translate None cyne_chapter2_0565:
        rs "嗯啊…"
    translate None cyne_chapter2_0566:
        "赛恩的双臂环绕我的肩膀，将自己紧贴在我身上。我紧紧抓住他的臀部，让他保持姿势。"
    translate None cyne_chapter2_0567:
        "他从那又长又黑的睫毛下注视着我，充满情欲的眼神乞求我继续。"
    translate None cyne_chapter2_0568:
        "他真是…太美了…"
    translate None cyne_chapter2_0569:
        "我缓缓将他托起，然后再次进入。节奏缓慢而稳定，但我们都渴望更多。"
    translate None cyne_chapter2_0570:
        "我的呼吸变得急促不匀。仅仅是这样…就已经让人难以承受。"
    translate None cyne_chapter2_0571:
        c "我又不脆弱，你知道的。你想怎么用力都行。"
    translate None cyne_chapter2_0572:
        rs "我..我知道，但是—"
    translate None cyne_chapter2_0573:
        c "既然知道，那就…"
    translate None cyne_chapter2_0574:
        "他抬起臀部又用力坐回来，一声响亮的呻吟从他唇间逸出，在街道上回荡。"
    translate None cyne_chapter2_0575:
        "我把他搂得更紧，生怕他摔下去。"
    translate None cyne_chapter2_0576:
        "当终于能喘上气时，我回顶得更猛烈、更快速。赛恩弓起背部，但我没有停下。"
    translate None cyne_chapter2_0577:
        "每次冲撞都让他的衣服后背在树干上摩擦。抱歉，阿什。希望衣服没事。"
    translate None cyne_chapter2_0578:
        "赛恩伸手抓住自己跳动的阴茎，随着我的节奏套弄。我多想也能碰触那里，但必须全力支撑着他。"
    translate None cyne_chapter2_0579:
        "我想感受，想品尝—回报他上次为我做的一切。"
    translate None cyne_chapter2_0580:
        rs "你真性感…"
    translate None cyne_chapter2_0581:
        c "我知道…你也不赖…"
    translate None cyne_chapter2_0582:
        scene gallery_85
        if persistent.streamer_mode:
            show cyne_3_sex_censor
        with dissolve
        "当我抽插时，他将臀部向下压入，让我尽根没入。每个动作，每次起伏都让我更加疯狂，动作变得越来越快，越来越狂乱。"
    translate None cyne_chapter2_0583:
        "他如铁钳般紧抓我的肩膀，脸埋在我身上，在快感中颤抖。"
    translate None cyne_chapter2_0584:
        scene gallery_86 with dissolve
        c "啊，雷恩…"
    translate None cyne_chapter2_0585:
        scene gallery_85 with dissolve
        "他在这种时刻呼唤我名字的方式总有种特别的魔力。如此情色撩人。"
    translate None cyne_chapter2_0586:
        "此刻我的双腿已经发软，动作变得更加急切。赛恩直接在我耳边呻吟，刺激着我。"
    translate None cyne_chapter2_0587:
        "他发出的每个声音都让我更加渴望他。"
    translate None cyne_chapter2_0588:
        "随着最后一次顶入，我发出低沉呻吟，在赛恩体内颤抖，额头抵着他的。片刻之后，赛恩的液体溅满了我们隔着衣服的胸膛。"
    translate None cyne_chapter2_0589:
        scene bg sc night with dissolve
        "我们仍紧紧相拥，气喘吁吁。我瘫坐在地上，仍抱着赛恩。"
    translate None cyne_chapter2_0590:
        rs c wemb"哈…哈…."
    translate None cyne_chapter2_0591:
        c c wemb "啊…哈…你从哪…学的这些…？"
    translate None cyne_chapter2_0592:
        rs "我…有个好老师…"
    translate None cyne_chapter2_0593:
        "他笑了起来，这是几天来我第一次见他笑得如此开怀。那笑容真挚，令人心头发暖。"
    translate None cyne_chapter2_0594:
        "我胸口泛起奇特的悸动。心脏猛烈跳动着，前所未有地剧烈，脸颊阵阵发烫。"
    translate None cyne_chapter2_0595:
        "这种感觉已盘旋许久，只是我始终不知其名。"
    translate None cyne_chapter2_0596:
        rs "赛恩…我真的很喜欢你。"
    translate None cyne_chapter2_0597:
        c c wsur "……什么？"
    translate None cyne_chapter2_0598:
        rs "我..我真的，真的很喜欢你。"
    translate None cyne_chapter2_0599:
        c "..........."
    translate None cyne_chapter2_0600:
        stop music fadeout 2.0
        c c wsad"….你是我很好的朋友，雷恩。我也喜欢你。"
    translate None cyne_chapter2_0601:
        rs c wsur "我不是—"
    translate None cyne_chapter2_0602:
        c c wsmi "嘶—冻死了！快穿好衣服离开这儿。"

    translate None cyne_chapter2_0603:
        "他迅速从我膝头起身，擦拭干净后穿好衣服。见我的屁股都快被雪冻麻了，我也跟着穿戴整齐。"
    translate None cyne_chapter2_0604:
        play music "sounds/bgm/sad.ogg" fadein 2.0
        rs c wsad "赛恩，我—"
    translate None cyne_chapter2_0605:
        c c whap "慢吞吞的！累死人了！"
    translate None cyne_chapter2_0606:
        "他始终没看我一眼，径直走在前头—朝着银柳方向返回。我将未竟之言咽下，默默跟在身后。"
    translate None cyne_chapter2_0607:
        "我是不是说错话了？"
    translate None cyne_chapter2_0608:
        "这种感觉不是爱吗？不是…爱情？"
    translate None cyne_chapter2_0609:
        "还是…他只是没感觉？"
    translate None cyne_chapter2_0610:
        "我想起阿什和艾琳的话。说他会把靠得太近的人推开。"
    translate None cyne_chapter2_0611:
        "我想和他好好谈谈。想抓住他的手问他是否也有同样感觉，但是…"
    translate None cyne_chapter2_0612:
        "我做不到。"
    translate None cyne_chapter2_0613:
        "这份焦灼是什么？"
    translate None cyne_chapter2_0614:
        "为何如此可怕？"
    translate None cyne_chapter2_0615:
        "我从未害怕与他说话。不曾畏惧与任何人交谈。"
    translate None cyne_chapter2_0616:
        "为何此刻却这般痛苦？"

    window hide dissolve

    scene bg swroom night with dissolve
    window show dissolve
    translate None cyne_chapter2_0617:
        "还未等我开口，赛恩已钻进被窝，面朝墙壁。"
    translate None cyne_chapter2_0618:
        rs wsad "….衣服都脏了。"
    translate None cyne_chapter2_0619:
        c wsad "…放进那个筐里。会有人来收去洗的。"
    translate None cyne_chapter2_0620:
        rs "好吧…"
    translate None cyne_chapter2_0621:
        "我噤了声。"
    translate None cyne_chapter2_0622:
        "他显然不愿谈论此事。"
    translate None cyne_chapter2_0623:
        "…明天还有时间聊。"
    translate None cyne_chapter2_0624:
        "我脱下衣物，将两人的衣服放进门口藤筐，随后躺到赛恩身边。"
    translate None cyne_chapter2_0625:
        "这种隔阂感前所未有。"
    translate None cyne_chapter2_0626:
        "那道沟壑。"
    translate None cyne_chapter2_0627:
        "我们之间不过咫尺，却像横亘着无底深渊，永难逾越。"
    translate None cyne_chapter2_0628:
        "我闭上眼睛，试图忽略它牵动我心的那种感觉。"
    translate None cyne_chapter2_0629:
        "于是开始了这个无眠无梦的夜晚。"
    translate None cyne_chapter2_0630:
        stop music fadeout 2.0
        scene black with eye_shut
        "……"
    translate None cyne_chapter2_0631:
        "…………"
    translate None cyne_chapter2_0632:
        "……………."
    translate None cyne_chapter2_0633:
        "毫无反应。"

    window hide dissolve
    jump cyneroute2_aftersex

label threesome:
    translate None cyne_chapter2_0634:
        rs "等等—等下，这也太疯狂了—我们先回我房间吧。"
    translate None cyne_chapter2_0635:
        c "啊呀…难道让大家听见我们这样的动静不会让你更兴奋吗？"
    translate None cyne_chapter2_0636:
        rs "我…呃…"
    translate None cyne_chapter2_0637:
        c "开玩笑的。好吧，先回去吧。不过要快点，我快等不及了。"

    window hide dissolve

    scene bg sc night with dissolve
    window show dissolve
    translate None cyne_chapter2_0638:
        "他把我从树上松开，结束亲吻时露出狡黠的笑容，还眨了眨眼。他抓住我的手，十指相扣，拉着我回到街上。"
    translate None cyne_chapter2_0639:
        "我踉跄地跟着他，他渐渐加快步子，从小跑到飞奔，始终紧紧攥着我的手。"
    translate None cyne_chapter2_0640:
        "他脸上的笑意具有感染力，让我不禁为这般荒唐咯咯笑起来。深更半夜在雪地里奔跑…还挺有趣。"

    window hide dissolve

    scene bg sw night with dissolve
    window show dissolve
    translate None cyne_chapter2_0641:
        "我们冲过大厅时，艾琳抬头对我们笑了笑，随即移开视线。"
    translate None cyne_chapter2_0642:
        c whap "嘿…我有个绝妙的主意。"
    translate None cyne_chapter2_0643:
        rs wsur "呃哦…"
    translate None cyne_chapter2_0644:
        c "来吧，相信我，你会喜欢的。去你房间等着我好吗？"
    translate None cyne_chapter2_0645:
        "我满脸狐疑地看着他，但最终还是决定相信。独自走进房间后，我坐在床沿等待。"

    window hide dissolve

    scene bg swroom night with dissolve:
        xpos 0.7 ypos 1.13 xanchor 0.5 yanchor 1.0 zoom 1.43
        linear 30.0 xpos 0.29 ypos 1.13 xanchor 0.5 yanchor 1.0 zoom 1.43

    window show dissolve
    translate None cyne_chapter2_0646:
        "他到底要搞什么名堂…"
    translate None cyne_chapter2_0647:
        "这么短时间内能准备出什么花样？"
    translate None cyne_chapter2_0648:
        "正当我的思绪飘向赛恩时，敲门声响起。还没等我反应，门就猛地被推开，站在门口的…"
    translate None cyne_chapter2_0649:
        "是福恩。"
    translate None cyne_chapter2_0650:
        rs wsur "搞什么…福恩？你怎么在这儿？"
    translate None cyne_chapter2_0651:
        "他涨红了脸，目光躲闪着不敢看我。"
    translate None cyne_chapter2_0652:
        "他身后又探出个笑嘻嘻的脑袋。"
    translate None cyne_chapter2_0653:
        c whap "嘿嘿…惊喜吗？"
    translate None cyne_chapter2_0654:
        rs "怎么回事？"
    translate None cyne_chapter2_0655:
        c "我觉得该给今晚添点乐子。其实本来还想叫上莱奥斯的，但敲他门没反应。真没劲。"
    translate None cyne_chapter2_0656:
        rs "...."
    translate None cyne_chapter2_0657:
        c "不过没关系！咱们该关注已经到场的，而不是缺席的。"
    translate None cyne_chapter2_0658:
        rs "我不…不明白…"
    translate None cyne_chapter2_0659:
        c "有什么难懂的？今晚你可以同时拥有我们两个。"
    translate None cyne_chapter2_0660:
        f wemb "...."
    translate None cyne_chapter2_0661:
        rs "...."
    translate None cyne_chapter2_0662:
        rs wemb "你…你当真接受这样吗，福恩？"
    translate None cyne_chapter2_0663:
        f "我…我接受…"
    translate None cyne_chapter2_0664:
        "他的脸红得更厉害了，连番茄都要自愧不如。"
    translate None cyne_chapter2_0665:
        c wsad "可怜的福恩一直被蒙在鼓里，你不觉得吗？整天痴心妄想，用充满欲望的眼神看着你，结果你却还在他背后和我上床。"
    translate None cyne_chapter2_0666:
        c wsmi "啊啊，真不公平呢。不过我突然想到…我很擅长分享，而福恩又是我的好朋友，何不帮他一把呢？你觉得呢，雷恩？"
    translate None cyne_chapter2_0667:
        rs "我…我，那个…"
    translate None cyne_chapter2_0668:
        "虽然知道想说什么，却感觉声音卡在喉咙里发不出来。这一切来得太快太突然，但…倒也不讨厌。"
    translate None cyne_chapter2_0669:
        rs "如果大家都愿意的话…我也想试试…"
    translate None cyne_chapter2_0670:
        c whap "太好了！那既然说定了…"
    translate None cyne_chapter2_0671:
        "他的双手始终没离开福恩，滑步绕到蓝发男子面前，踮起脚将手臂环上对方的肩膀。"
    translate None cyne_chapter2_0672:
        "他踮着脚尖吻上福恩，后者震惊地颤了一下，随即闭上双眼。"
    translate None cyne_chapter2_0673:
        "我看着这一幕震惊得说不出话。赛恩的举动充满老练的挑逗风情，而福恩周身却萦绕着纯真气息。"
    translate None cyne_chapter2_0674:
        "两人在一起的模样…让我感到异样，我在床上不安地挪动，呼吸急促。之前被赛恩挑逗时就已经有些躁动了，现在看着他们如此激情地接吻，更是让我裤裆发紧。"
    translate None cyne_chapter2_0675:
        "但是…除此之外，我还感到一阵嫉妒，多希望被亲吻的那个人是我。"
    translate None cyne_chapter2_0676:
        "赛恩终于放开福恩，脸上仍泛着红晕，睫毛低垂。"
    translate None cyne_chapter2_0677:
        c wsmi "希望我没抢走你的初吻。"
    translate None cyne_chapter2_0678:
        f "没关系…这不重要…"
    translate None cyne_chapter2_0679:
        c wsur "等等，你是认真的？哇，这下更有意思了。"
    translate None cyne_chapter2_0680:
        "赛恩的手滑进福恩衣内，慢慢解开他新衣服的几层系带。与此同时，我攥着床沿的指节都发白了，不知所措。"
    translate None cyne_chapter2_0681:
        c wsmi "觉得戏弄得差不多了。来吧，我有个主意。"


    scene bg swroom night with dissolve:
        xpos 0.39 ypos 1.2 xanchor 0.5 yanchor 1.0 zoom 1.86
    translate None cyne_chapter2_0682:
        "他们步步逼近时目光都落在我身上，最后停在床沿。赛恩轻推福恩一把，他踉跄着跌进我怀里。"
    translate None cyne_chapter2_0683:
        c wsmi "加油啊。你可得好好表现才能让雷恩印象深刻，毕竟他的第一次是和我，不是我自夸…"
    translate None cyne_chapter2_0684:
        c "但我确实很厉害。"
    translate None cyne_chapter2_0685:
        "福恩的目光变得坚定，他的手臂松散地搭在我肩上，赛恩跪了下来，头靠在我大腿上。"
    translate None cyne_chapter2_0686:
        f wemb "我可以…吻你吗？"
    translate None cyne_chapter2_0687:
        "作为回应，我向前倾身贴上他的唇，我们的鼻尖轻轻相触，而后福恩偏头示意我靠得更近。"
    translate None cyne_chapter2_0688:
        "初次遇见福恩时，我从没想过…从没想过我们会做这种事…！"
    translate None cyne_chapter2_0689:
        "这个吻柔软得近乎甜美，比我与赛恩任何一次亲吻都要纯粹。"
    translate None cyne_chapter2_0690:
        "仿佛是对我们接吻的回应，赛恩的手指开始在我大腿上游走，抓握住我的臀部，又在我绷紧的裤裆上撩拨起舞。"
    translate None cyne_chapter2_0691:
        "我在福恩唇间轻喘，这反倒激起他更热烈的攻势。他轻轻啃咬我的下唇，随后将这个吻加深。"
    translate None cyne_chapter2_0692:
        "双重关注让我几乎头晕目眩。单是赛恩就够让人招架不住，再加上福恩简直要令我发狂。"
    translate None cyne_chapter2_0693:
        "赛恩的挑逗逐渐升级，他迫不及待隔着裤子勾勒我勃起的轮廓，此刻裤裆已紧得令人不适。"
    translate None cyne_chapter2_0694:
        "他仿佛感知到这点，迅速解开皮带拉链，将我的坚挺暴露在空气中。福恩仅暂停接吻回头看了一眼，便以更猛烈的姿态重新吻上来。"
    translate None cyne_chapter2_0695:
        "赛恩的手掌圈住我，懒散地上下套弄着，刻意延长每次律动。"
    translate None cyne_chapter2_0696:
        "我在快感中战栗喘息，贴着福恩衣料包裹的身体。双手在他身上游移，最终隔着裤子握住他硬挺的阳具。"
    translate None cyne_chapter2_0697:
        "他贴着我的手掌磨蹭，呻吟从我们相贴的唇缝渗出。"
    translate None cyne_chapter2_0698:
        "我趁机效仿赛恩，将手探入福恩裤中掏出他发烫的阴茎。"
    translate None cyne_chapter2_0699:
        rs wemb "这样…可以吗…？"
    translate None cyne_chapter2_0700:
        f "求你…"
    translate None cyne_chapter2_0701:
        f "如果这是得到你的唯一方式…那这样就很好…"
    translate None cyne_chapter2_0702:
        "他把含糊不清的嘟囔埋进我肩头。得到默许后，我握住他脉动的炽热。"
    translate None cyne_chapter2_0703:
        "拇指抚过铃口时，他的指甲深深陷进我后背。"
    translate None cyne_chapter2_0704:
        "身下的赛恩戏谑地前倾，沿着我柱身底部舔至顶端，在龟头留下轻吻后从容退开。"
    translate None cyne_chapter2_0705:
        "我的胸膛剧烈起伏着，已经完全被正在发生的一切所淹没。"
    translate None cyne_chapter2_0706:
        c wsmi "福恩，过来帮我一把。"
    translate None cyne_chapter2_0707:
        "福恩怯生生地从床上滑下来坐在赛恩旁边，他的阴茎依然硬挺着暴露在众人面前。"
    translate None cyne_chapter2_0708:
        "他试图遮掩自己，但赛恩拍开他的手，凑近仔细观察。"
    translate None cyne_chapter2_0709:
        c wsur "真可爱。没想到你这么大。"
    translate None cyne_chapter2_0710:
        f "别看得那么仔细，太羞人了。"
    translate None cyne_chapter2_0711:
        c "才不羞。也许你只是害羞因为我的还可怜兮兮地被冷落藏着呢。"
    translate None cyne_chapter2_0712:
        "话音刚落，赛恩就脱下了裤子，内裤下的隆起清晰可见，他迅速踢掉内裤扔进衣服堆里。"
    translate None cyne_chapter2_0713:
        "不甘示弱的福恩也随即脱掉衣服，雪白的肌肤在月光下几乎发着光。并排而坐的两人都美得惊人。"
    translate None cyne_chapter2_0714:
        "而现在，他们就这样坐在我的双腿之间。"
    translate None cyne_chapter2_0715:
        "赛恩把福恩拉近，双腿跨在他身上，让两人的身体紧密相贴，直到他们刚获得自由的阴茎互相碰触。福恩惊讶地倒吸一口气，声音里夹杂着喘息和呻吟。"
    translate None cyne_chapter2_0716:
        c wemb2 "嗯…啊…"
    translate None cyne_chapter2_0717:
        f "啊..感觉好奇怪…"
    translate None cyne_chapter2_0718:
        c "嗯..是舒服的奇怪，对吧？"
    translate None cyne_chapter2_0719:
        "看着他们互相摩擦，我能感觉到自己的阴茎在抽搐。我伸手想握住它，但赛恩把我的手拍开了。"
    translate None cyne_chapter2_0720:
        c "嗯…排队等着。"
    translate None cyne_chapter2_0721:
        rs "但是…"
    translate None cyne_chapter2_0722:
        c "看着就好。"
    translate None cyne_chapter2_0723:
        "当赛恩的手握住他们两人的阴茎，用他们的前液当润滑液摩擦时，福恩紧闭双眼，嘴巴张成完美的O形。"
    translate None cyne_chapter2_0724:
        "随着福恩臀部抖动，赛恩用空闲的手伸向自己，探入一根手指。他愉悦地仰起头，发出一声低沉的呻吟。"
    translate None cyne_chapter2_0725:
        "我攥紧床单的指节开始发疼。阴茎的胀痛感前所未有，渴求着释放。"
    translate None cyne_chapter2_0726:
        f "我应该…？"
    translate None cyne_chapter2_0727:
        "福恩朝赛恩仍在扩张自己入口的手指点了点头。"
    translate None cyne_chapter2_0728:
        c "看情况…你想上吗？"
    translate None cyne_chapter2_0729:
        c "我是纯零，所以…不如让雷恩在中间？你可以上他，让他来上我。"
    translate None cyne_chapter2_0730:
        f "…!"
    translate None cyne_chapter2_0731:
        "听到他下流的话语，我几乎就要屈服，手指在我搏动的性器上方徘徊，但我还是勉强抵抗住了。我的呼吸变得粗重，先走液顺着阴茎侧面流下。"
    translate None cyne_chapter2_0732:
        c "听起来不错吧，雷恩？"
    translate None cyne_chapter2_0733:
        rs "求你…"
    translate None cyne_chapter2_0734:
        c "不过看样子你从没被进入过…要不我们帮帮他，福恩？"
    translate None cyne_chapter2_0735:
        "他们在我身下依然相互磨蹭着性器，同时转向我。赛恩倾身向前，用舌头舔过我阴茎的顶端。"
    translate None cyne_chapter2_0736:
        "当他后退时，一缕先走液在我们之间拉出银丝。我羞愧地捂住脸，他却把这当作自己做得正确的信号。"
    translate None cyne_chapter2_0737:
        "福恩模仿赛恩的动作，用他纤长的手指环住我阴茎根部，用力握紧后轻咬侧面。"
    translate None cyne_chapter2_0738:
        "他们嘴唇触碰过的每个部位都火辣辣的，几乎烫得难以忍受。我半眯着眼低头看向赛恩，他已经把第二根手指插进了自己后穴。他脸上写满快感。"
    translate None cyne_chapter2_0739:
        rs "这样…舒服吗？"
    translate None cyne_chapter2_0740:
        c "爽死了。"
    translate None cyne_chapter2_0741:
        rs "不会…疼吗？"
    translate None cyne_chapter2_0742:
        c "第一次是疼的，但现在早就习惯了。"
    translate None cyne_chapter2_0743:
        rs "..."
    translate None cyne_chapter2_0744:
        "我咬着嘴唇，突然要容纳这么…的念头让我有点担心"
    translate None cyne_chapter2_0745:
        "我瞟了眼福恩勃起的硬物"
    translate None cyne_chapter2_0746:
        "这么巨大的…"
    translate None cyne_chapter2_0747:
        c "别担心，我会让你也舒服的。"
    translate None cyne_chapter2_0748:
        "他把手指从体内抽出，离开我的阴茎，快速转身在衣物堆里翻找着什么。"
    translate None cyne_chapter2_0749:
        "福恩被独自留下，睁着又大又圆的鹿眼仰视我，随后含住了我的性器。"
    translate None cyne_chapter2_0750:
        rs "啊..！嗯嗯，福恩…！"
    translate None cyne_chapter2_0751:
        c "找到了。"
    translate None cyne_chapter2_0752:
        rs "你..啊…你随身带着这个？"
    translate None cyne_chapter2_0753:
        c "有备无患嘛。"
    translate None cyne_chapter2_0754:
        "福恩口腔内部湿热紧致，阴茎摩擦他脸颊内壁的快感让我几乎忍不住挺腰。"
    translate None cyne_chapter2_0755:
        "赛恩打开润滑液，往手指上倒了点后重新跪到我两腿之间。他沿着我的大腿轻咬，手指在我入口处画圈。"
    translate None cyne_chapter2_0756:
        "润滑液很凉，但感觉很舒服。片刻后赛恩慢慢将指尖推入。"
    translate None cyne_chapter2_0757:
        rs "啊！"
    translate None cyne_chapter2_0758:
        "我感到自己正紧紧裹住他的手指，这种异物感很快被福恩上下吞吐的脑袋和赛恩在我大腿留下红色咬痕的轻啃分散了注意。"
    translate None cyne_chapter2_0759:
        "他的手指缓缓滑入。感觉纤细修长，却依然如此陌生。"
    translate None cyne_chapter2_0760:
        rs "感觉…有点奇怪…"
    translate None cyne_chapter2_0761:
        c "刚开始都这样。别担心，你很快会习惯的。"
    translate None cyne_chapter2_0762:
        "他抽出手指，又重新插入。润滑液让通道变得极为顺滑，进入比我预想的容易得多。"
    translate None cyne_chapter2_0763:
        "但比起…手指终究是小的…"
    translate None cyne_chapter2_0764:
        "他持续这个动作好一会儿，在我适应感觉的同时不断进出着单根手指。"
    translate None cyne_chapter2_0765:
        "最终感觉从轻微不适转变为其他感受。某种…快感。他手指摩擦内壁的方式让我颤抖呻吟。"
    translate None cyne_chapter2_0766:
        "就在我以为自己已经理解状况时，赛恩突然在我体内弯曲手指，我倒抽一口气，猛地拱进福恩嘴里。他轻松含住我，阴茎直接顶到他喉咙深处。"
    translate None cyne_chapter2_0767:
        rs "啊！嗯，赛恩…什么…？！"
    translate None cyne_chapter2_0768:
        c "很舒服对吧？"
    translate None cyne_chapter2_0769:
        "他继续揉搓那个点位，看着我的手指无力揪扯床单时露出坏笑。"
    translate None cyne_chapter2_0770:
        rs "感觉…太棒了…！"
    translate None cyne_chapter2_0771:
        c "我很少有机会对别人这么做…真令人兴奋。我要加一根手指了，可以吗？"
    translate None cyne_chapter2_0772:
        rs "好…好的…"
    translate None cyne_chapter2_0773:
        "第二根手指滑入，将我扩张得更开。非但没有不适，反而带来某种饱胀感。美妙的感受。"
    translate None cyne_chapter2_0774:
        "他缓缓抽插着手指，我感到自己快要到达顶点。被他们这样双重夹击恐怕撑不了多久…"
    translate None cyne_chapter2_0775:
        rs "我…我觉得快要忍不住了…"
    translate None cyne_chapter2_0776:
        "我望向仍在吞吐着我的福恩，他同时套弄着自己的勃起。赛恩也一样，一边用手指开拓我一边抚慰自己。"
    translate None cyne_chapter2_0777:
        c "我…我也是…不准你先射，明白吗？"
    translate None cyne_chapter2_0778:
        "赛恩突然紧握我根部，眉头微蹙。"
    translate None cyne_chapter2_0779:
        "随着啵的一声我从福恩口中滑出，同时赛恩抽离了埋在我体内的手指。突然的空虚感格外鲜明。"
    translate None cyne_chapter2_0780:
        rs "我们该怎么…怎么继续？"
    translate None cyne_chapter2_0781:
        c "起来。"
    translate None cyne_chapter2_0782:
        "我从床沿站起，赛恩躺到我刚才的位置，向我大张双腿。我不禁咽了咽口水。"



    scene gallery_89:
        subpixel True xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.85 rotate None
        parallel:
            ypos 1.03
            easein 18.0 ypos 1.76
    if persistent.streamer_mode == True:
        show cyne_3p_sex_censor:
            subpixel True xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.85 rotate None
            parallel:
                ypos 1.03
                easein 18.0 ypos 1.76
    with dissolve

    translate None cyne_chapter2_0783:
        f "哈啊…"
    translate None cyne_chapter2_0784:
        "福恩站在我身后，摸索着我的臀部，他的头靠在我背上。"
    translate None cyne_chapter2_0785:
        f "我..我太需要你了…"
    translate None cyne_chapter2_0786:
        "我艰难地咽了口唾沫，把自己对准赛恩。我能感觉到福恩在后面也做着同样的事。"
    translate None cyne_chapter2_0787:
        "慢慢地，我推进赛恩体内，他愉悦地呻吟着回应。他毫不费力地接纳了我全部。"
    translate None cyne_chapter2_0788:
        "当我舒适地进入他体内后，福恩也开始行动。他用手分开我的臀瓣，将他的前端引导至我的入口。"
    translate None cyne_chapter2_0789:
        "仅仅是他抵着我的感觉就让我抽搐。"
    translate None cyne_chapter2_0790:
        scene gallery_89
        if persistent.streamer_mode == True:
            show cyne_3p_sex_censor
        with dissolve
        "福恩缓缓将前端压入我体内，突如其来的撕裂感让我倒吸一口冷气。这和几根手指的感觉如此不同。"
    translate None cyne_chapter2_0791:
        f "你还好吗？"
    translate None cyne_chapter2_0792:
        rs "啊..对…就是有点…紧…"
    translate None cyne_chapter2_0793:
        "赛恩坏笑着收缩包裹着我的部位，让我喉间迸出大声的呻吟，冲淡了我对福恩推入的感觉。"
    translate None cyne_chapter2_0794:
        rs "啊…！"
    translate None cyne_chapter2_0795:
        c "嗯…快点福恩，我想要被上。"
    translate None cyne_chapter2_0796:
        f "我…我不想伤到他…"
    translate None cyne_chapter2_0797:
        "我发出低沉的呜咽，这个节奏让我发疯。慢慢地，哦太慢了，当他的骨盆终于抵上我时，我啜泣出声。"
    translate None cyne_chapter2_0798:
        f "这样…这样可以吗？"
    translate None cyne_chapter2_0799:
        "我感觉…感觉被填满得几乎无法思考…"
    translate None cyne_chapter2_0800:
        rs "可以…可以…很好，你可以开始动了。"
    translate None cyne_chapter2_0801:
        rs "赛恩，你太棒了…怎么能这么轻松就做到…？"
    translate None cyne_chapter2_0802:
        c "经验丰富而已。深呼吸就好。"
    translate None cyne_chapter2_0803:
        rs "真走运…"
    translate None cyne_chapter2_0804:
        c "啊哈哈，算是吧。总之快点！"
    translate None cyne_chapter2_0805:
        "福恩缓缓抽离，然后再次推入。为了配合他缓慢的动作，我开始以同样节奏顶入赛恩体内。"
    translate None cyne_chapter2_0806:
        c "嗯…"
    translate None cyne_chapter2_0807:
        rs "啊…唔…"
    translate None cyne_chapter2_0808:
        "福恩缓慢的研磨开始加快，这让赛恩更加愉悦。每当他推入我体内，我就更深地进入赛恩。"
    translate None cyne_chapter2_0809:
        "最终我们找到了共同的节奏，自如地相互律动。那种充盈感仍在，但它开始转变—疼痛消失了，取而代之的是对更多的炽热渴望。"
    translate None cyne_chapter2_0810:
        rs "唔，啊…你可以…可以再快些…"
    translate None cyne_chapter2_0811:
        f "你确定？"
    translate None cyne_chapter2_0812:
        c "别这么畏手畏脚。这小子想被狠狠地上，那就赶紧满足他。"
    translate None cyne_chapter2_0813:
        f "...!"
    translate None cyne_chapter2_0814:
        rs "啊！唔…！"
    translate None cyne_chapter2_0815:
        "他突然用力将胯部向我顶来，而我随之也朝赛恩挺入，他愉悦地尖声叫了出来。"
    translate None cyne_chapter2_0816:
        "我脑中充斥着炽热的快感，眼前直冒金星，但仍持续深入赛恩体内，他正张开双臂迎接着这种欢愉。"
    translate None cyne_chapter2_0817:
        "福恩完全埋在我体内，抵着我的后背呻吟，这使我脊背一阵战栗。"
    translate None cyne_chapter2_0818:
        f "你真是太…太紧了…"
    translate None cyne_chapter2_0819:
        rs "这样…这样可以吗？"
    translate None cyne_chapter2_0820:
        f "太美妙了…"
    translate None cyne_chapter2_0821:
        "我还来不及转身面对福恩，赛恩就扣住我的下巴将我拉下去吻他。这个吻迅疾、深入而凌乱，但当我同时被插入又在插入别人时，这正是我需要的。"
    translate None cyne_chapter2_0822:
        "赛恩内壁紧紧裹绞着我，我随之加快了节奏。福恩也如此，一次次推入我的入口。"
    translate None cyne_chapter2_0823:
        "他动作越激烈，赛恩承受得就越猛烈，呻吟变成了尖叫。"
    translate None cyne_chapter2_0824:
        rs "我不…不知道这样还能坚持多久…"
    translate None cyne_chapter2_0825:
        "我的背脊微微弓起，福恩顶到了赛恩先前找到的那个位置，差点让我瘫倒在赛恩身上。"
    translate None cyne_chapter2_0826:
        rs "啊！哈，福恩…！"
    translate None cyne_chapter2_0827:
        c "嗯…啊…！"
    translate None cyne_chapter2_0828:
        f "我不行…我要…呃…！"
    translate None cyne_chapter2_0829:
        scene gallery_89
        if persistent.streamer_mode == True:
            show cyne_3p_sex_censor
        with hpunch
        "突然福恩从我体内退出，一股热流喷洒在我的后背。突如其来的空虚让我恍惚了一瞬，但赛恩没给我分神的机会。"
    translate None cyne_chapter2_0830:
        "他贴着我胯部研磨，夹紧并利用我的身体操他自己。他叫得如此响亮，就算有人以为是凶杀案也不奇怪，但我不在乎。我只在乎追寻那亟需释放的快感。"
    translate None cyne_chapter2_0831:

        show gallery_89:
            xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.88
        if persistent.streamer_mode == True:
            show cyne_3p_sex_censor:
                xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.88
        with dissolve

        "结束后的福恩倒在赛恩身旁的床上，伸手握住赛恩的阴茎。他配合着我抽插的节奏撸动，赛恩的背脊高高弓起。"
    translate None cyne_chapter2_0832:
        show gallery_89 with hpunch:
            xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.88
        window hide dissolve

        scene bg swroom night with dissolve
        window show dissolve
        "我眼前一片空白，猛烈地在赛恩体内射精，同时继续抽插以延续高潮。片刻之后金发男子也同样释放，我们三人都沾染上了白浊。"
    translate None cyne_chapter2_0833:
        rs wemb "哈…哈啊，啊，操…"
    translate None cyne_chapter2_0834:
        f wemb "哈啊…"


    translate None cyne_chapter2_0835:
        c wsmi "呼…太棒了…好久没这么尽兴过了…"
    translate None cyne_chapter2_0836:
        c "干得好，福恩。"
    translate None cyne_chapter2_0837:
        f wsad "我…我，我…"
    translate None cyne_chapter2_0838:
        f "我….想我现在该去睡觉了…"
    translate None cyne_chapter2_0839:
        c wsur "啊~连抱抱都不留一会吗？"
    translate None cyne_chapter2_0840:
        "我对着赛恩咧嘴一笑，然后转向福恩。他用受伤小猫般的眼神看着我，随后起身穿衣。"
    translate None cyne_chapter2_0841:
        rs wsur "...?"
    translate None cyne_chapter2_0842:
        "穿好衣服后，他冲我们点点头，离开了房间。"
    translate None cyne_chapter2_0843:
        rs wsad "哈啊…真不知道你是怎么做到的，赛恩。我明天怕是走不了路了。"
    translate None cyne_chapter2_0844:
        c wsmi "但难道不开心吗？"
    translate None cyne_chapter2_0845:
        rs wemb "….嗯，是很开心。"
    translate None cyne_chapter2_0846:
        c whap "那就好。不过我希望你别对福恩的阴茎上瘾到要跟他私奔抛弃我。"
    translate None cyne_chapter2_0847:
        rs wsur "什么意思？"
    translate None cyne_chapter2_0848:
        "他停顿了一下，脸上闪过一丝惊讶，随后皱起眉头。"
    translate None cyne_chapter2_0849:
        stop music fadeout 2.0
        c wsad "确实，我到底在{b}{i}说{/b}{/i}什么呢…？"
    translate None cyne_chapter2_0850:
        "他的表情变了，笑容重新浮现。"
    translate None cyne_chapter2_0851:
        c whap "毕竟你想做什么都可以。我不是你的主人。"
    translate None cyne_chapter2_0852:
        rs "...."
    translate None cyne_chapter2_0853:
        rs "我绝不会跟别人走的。我只想要你！"
    translate None cyne_chapter2_0854:
        c wsur "...."
    translate None cyne_chapter2_0855:
        c wsad "哈哈哈，你在说什么啊？"
    translate None cyne_chapter2_0856:
        "见过福恩这个样子后，我突然醒悟了。虽然很愉快，但看着福恩时我的心不会狂跳。他不会让我呼吸急促。"
    translate None cyne_chapter2_0857:
        "某种情感的名称浮现在我脑海里。"
    translate None cyne_chapter2_0858:
        "比如…爱…"
    translate None cyne_chapter2_0859:
        rs wemb "赛恩…我呃…我想我喜欢你。"
    translate None cyne_chapter2_0860:
        c wsur "……什么？"
    translate None cyne_chapter2_0861:
        rs "我..我真的，真的喜欢你。我确定。"
    translate None cyne_chapter2_0862:
        c ".........."
    translate None cyne_chapter2_0863:
        play music "sounds/bgm/sad.ogg" fadein 3.0
        c wsad "….你是我很好的朋友，雷恩。我也喜欢你。"
    translate None cyne_chapter2_0864:
        rs wsur "我不是—"
    translate None cyne_chapter2_0865:
        c "你一定是累坏了。来吧，上床睡觉吧。"
    translate None cyne_chapter2_0866:
        rs wsad "等等，赛恩—"
    translate None cyne_chapter2_0867:
        "他转过身开始清理身体，对我的话置若罔闻。"
    translate None cyne_chapter2_0868:
        c whap "慢吞吞的！累死人了！"
    translate None cyne_chapter2_0869:
        "我是不是说错话了？"
    translate None cyne_chapter2_0870:
        "我错了吗？认为这是…爱，是我的错觉吗？"
    translate None cyne_chapter2_0871:
        "还是…他只是没感觉？"
    translate None cyne_chapter2_0872:
        "我想起阿什和艾琳的话。说他会把靠得太近的人推开。"
    translate None cyne_chapter2_0873:
        "我想和他好好谈谈。想抓住他的手问他是否也有同样感觉，但是…"
    translate None cyne_chapter2_0874:
        "我做不到。"
    translate None cyne_chapter2_0875:
        "这份焦灼是什么？"
    translate None cyne_chapter2_0876:
        "为何如此可怕？"
    translate None cyne_chapter2_0877:
        "我从未害怕与他说话。不曾畏惧与任何人交谈。"
    translate None cyne_chapter2_0878:
        "为何此刻却这般痛苦？"
    translate None cyne_chapter2_0879:
        "再无言以对，我爬到他身边的床上—很近，但中间似乎隔着无法逾越的距离。"
    translate None cyne_chapter2_0880:
        "闭上眼睛，迎接我的又是一个寂静空荡的梦境。"

    if achievement.has("cyne_three"):
        pass
    else:
        $ renpy.display_notify("成就达成：两人成伴，三人更欢")
    python:
        achievement.grant("cyne_three")
        achievement.sync()

    window hide dissolve

    scene black with eye_shut
    pause 2.0
    scene bg swroom night with eye_open
    window show dissolve
    translate None cyne_chapter2_0881:
        "在漆黑寂静的房间里，赛恩躺着凝视天花板，就像他已经持续了数小时那样。"
    translate None cyne_chapter2_0882:
        "他的思绪飘回那晚的所作所为—三人行，对他来说本不新鲜，然而…"
    translate None cyne_chapter2_0883:
        "然而这次不同。"
    translate None cyne_chapter2_0884:
        cmn "我这是怎么了？通常我不会在意的，但…每次他把注意力转向福恩，我就想压他一头，迫使他所有的关注都回到我身上…"
    translate None cyne_chapter2_0885:
        cmn "我这是病了吗？从未有过这种感觉…"
    translate None cyne_chapter2_0886:
        "他的目光掠过雷恩背对着他的赤裸脊背。"
    translate None cyne_chapter2_0887:
        "他想伸手触碰，想让指尖在那肌肤上游走，但是…"
    translate None cyne_chapter2_0888:
        cmn "但不行。"
    translate None cyne_chapter2_0889:
        cmn "妈的，躺着也没用。我去走走。"
    translate None cyne_chapter2_0890:
        "他缓缓起身穿衣，凉意让他加快了动作。"
    translate None cyne_chapter2_0891:
        "手掌抵在门上，又回头看了雷恩一眼才离开。"

    window hide dissolve

    scene bg sw night with dissolve
    window show dissolve
    translate None cyne_chapter2_0892:
        "本以为大厅空无一人—毕竟哪个正常人大半夜乱晃？"
    translate None cyne_chapter2_0893:
        "但他错了。"
    translate None cyne_chapter2_0894:
        "蓝色头发的少年独自坐在大厅，背对着他。"
    translate None cyne_chapter2_0895:
        scene bg sw night blur
        show cyne mw dim sur cloak at mleft
        show fawn mw dim sad cloak at mright
        with dissolve
        c "福恩？"
    translate None cyne_chapter2_0896:
        f "哦，赛恩…你怎么起来了？"
    translate None cyne_chapter2_0897:
        show cyne mw dim neu with dis
        c "这话该我问你。"
    translate None cyne_chapter2_0898:
        f "..."
    translate None cyne_chapter2_0899:
        f "老实说，我睡不着。"
    translate None cyne_chapter2_0900:
        show cyne mw dim sad with dis
        c "我也一样。"
    translate None cyne_chapter2_0901:
        f "其实我…想和你谈谈。"
    translate None cyne_chapter2_0902:
        show fawn mw dim neu with dis
        f "你赢了。我现在认输。"
    translate None cyne_chapter2_0903:
        show cyne mw dim sur with dis
        c "什么…？"
    translate None cyne_chapter2_0904:
        show fawn mw dim sad with dis
        f "我喜欢雷恩。"
    translate None cyne_chapter2_0905:
        f "非常…非常喜欢。"
    translate None cyne_chapter2_0906:
        f "但他对我…没那种感觉。发生的种种都说明白了。他眼里只有你。"
    translate None cyne_chapter2_0907:
        show cyne mw dim sad with dis
        c "..."
    translate None cyne_chapter2_0908:
        f "别担心，我不生气。有点难过罢了，会过去的。赛恩，你是我朋友，我相信你会好好待他。"
    translate None cyne_chapter2_0909:
        c "福恩，我觉得他对我没那么认真，所以…"
    translate None cyne_chapter2_0910:
        "蓝发少年摇摇头，露出苦涩的微笑。"
    translate None cyne_chapter2_0911:
        show fawn mw dim smi with dis
        f "没关系，我接受了。也谢谢你之前给我机会。你很温柔。"
    translate None cyne_chapter2_0912:
        c "福恩…我一点都不温柔。"
    translate None cyne_chapter2_0913:
        f "你只是没意识到。"
    translate None cyne_chapter2_0914:
        c "..."
    translate None cyne_chapter2_0915:
        show fawn mw dim sad with dis
        f "现在应该能睡着了。昨晚的事我不会再提，好吗？你们可以继续。我不会碍事。"
    translate None cyne_chapter2_0916:
        cmn "操…我在干什么…"
    translate None cyne_chapter2_0917:
        scene black with dissolve
        "福恩起身离去，只剩赛恩独坐大厅，深陷思绪。"

    stop music fadeout 2.0
    window hide dissolve
    jump cyneroute2_aftersex
