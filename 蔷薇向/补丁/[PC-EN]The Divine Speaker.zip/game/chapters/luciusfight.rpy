label luciusfight:
    scene bg sc mountains with dissolve:
        xpos 0.51 ypos 1.41 xanchor 0.5 yanchor 1.05 zoom 1.6
        linear 15.0 xpos 0.51 ypos 1.67 xanchor 0.5 yanchor 1.05 zoom 1.6
    window show dissolve
    translate None lucius_fight_0000:
        "我们紧随其后冲出了村庄。奔跑在雪地里时，夜风凛冽，积雪时而深及膝盖。"
    translate None lucius_fight_0001:
        "没多久，埃利奥特效仿其他神明变化了形态—出乎我意料的巨大白虎。我们将他的衣物捆好继续奔行。"
    translate None lucius_fight_0002:
        "喉头发紧，夹着雪粒的狂风抽打着面颊。浑身麻木却同时感到刺痛。"
    translate None lucius_fight_0003:
        "心脏几乎随时要蹦出胸膛。"
    translate None lucius_fight_0004:
        "埃利奥特敏捷如飞鸟，优雅地穿梭在林间。雪白的毛皮时而与积雪融为一体，但那双眼眸无法隐藏。"
    translate None lucius_fight_0005:
        "行程比上次快得多。伤势没拖后腿，很快锡德卡汉的城门就映入眼帘。"
    translate None lucius_fight_0006:
        rs c wang "……没有守卫。"
    translate None lucius_fight_0007:
        v fro "若他们安全地躲在家中也罢，若是遭遇不测……"
    translate None lucius_fight_0008:
        "未及回神，埃利奥特已恢复人形穿戴整齐。"
    translate None lucius_fight_0009:
        v "……进去吧。"
    translate None lucius_fight_0010:
        "我们颔首穿过鎏金大门。"
    window hide dissolve

    scene bg sc night with dissolve:
        xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.31
        linear 16.0 xpos 0.5 ypos 1.28 xanchor 0.5 yanchor 1.0 zoom 1.31
    window show dissolve
    translate None lucius_fight_0011:
        "万籁俱寂。虽说是深夜时分，但这寂静……异乎寻常。"
    translate None lucius_fight_0012:
        "宛如奥克斯哈伯的死寂。令人毛骨悚然的静谧，仿佛每个转角都蛰伏着邪物。"
    translate None lucius_fight_0013:
        "正环视四周时，两名女子朝我们走来。"
    translate None lucius_fight_0014:
        mor cu sad "……感觉到了吗？"
    translate None lucius_fight_0015:
        v fro "那股压倒性的强大气息……找到他藏身之处了？"
    translate None lucius_fight_0016:
        s ang "如此招摇的力量展示，谈不上躲藏吧。"


    if cyne_route:
        translate None lucius_fight_0017:
            c c wang "不必寻找，他的所在显而易见。既然占据国王顾问的躯体……"
        translate None lucius_fight_0018:
            c "该搜查宫殿。"


    if leos_route:
        translate None lucius_fight_0019:
            l c wpis "……横竖知道他的去向，不是吗？夺取那具身体必有用意。去宫殿吧。"


    if fawn_route:
        translate None lucius_fight_0020:
            mor cu sad "他在宫殿里，与国王在一起。"
        translate None lucius_fight_0021:
            f c wneu "那就知道该往哪走了。我会陪你到最后，雷恩。"
        translate None lucius_fight_0022:
            "福恩的目光真挚动人。我明白他字字发自肺腑。"
        translate None lucius_fight_0023:
            rs c wsmi "……我也与你同在。"


    translate None lucius_fight_0024:
        v "原来这就是他的目的……操纵王室。发动圣战。"
    translate None lucius_fight_0025:
        v sad "他比上次相遇时更强了。我……担心镇民的安危。"
    translate None lucius_fight_0026:
        cas sad "这里…好空旷。不只是物理意义上的，还有…"
    translate None lucius_fight_0027:
        cas "我在这里住了将近18年。以前从未有过这种感觉。"
    translate None lucius_fight_0028:
        ae sad "卡斯皮安…"
    translate None lucius_fight_0029:
        cas smi "…但我们能做到。也许一点冒险对我有好处。"
    translate None lucius_fight_0030:
        ae "啊哈哈…你终究还是没有丢掉它嘛。"


    if cyne_route:
        translate None lucius_fight_0031:
            "莱奥斯，福恩…"


    if leos_route:
        translate None lucius_fight_0032:
            "赛恩，福恩…"


    if fawn_route:
        translate None lucius_fight_0033:
            "莱奥斯，赛恩…"


    translate None lucius_fight_0034:
        rs c wang "在这里徘徊没有意义。我们走吧。"
    translate None lucius_fight_0035:
        "本该有卫兵站岗守卫宫殿的地方，此时却空无一人。宫门大敞着，仿佛在欢迎我们进去。"
    translate None lucius_fight_0036:
        "我们彼此交换了个眼神。大家都觉得情况不妙，但除了继续前进别无选择。"

    window hide dissolve

    scene bg throneno with Dissolve (2.0):
        xpos 0.72 ypos 1.14 xanchor 0.5 yanchor 1.0 zoom 1.64
        linear 35.0 xpos 0.25 ypos 1.14 xanchor 0.5 yanchor 1.0 zoom 1.64
    window show dissolve
    translate None lucius_fight_0037:
        "我们的脚步声在巨大而俗艳的房间里回荡。室内很暗—只有月光照明。"
    translate None lucius_fight_0038:
        "我从没想过自己会置身于一座宫殿之中，尤其是在这般境况下。"
    translate None lucius_fight_0039:
        v fro "他就在附近。"


    if cyne_route:
        translate None lucius_fight_0040:
            c c wang "即使我们全员集结—我们有机会吗？有什么我应该知道的计划吗？"


    if leos_route:
        translate None lucius_fight_0041:
            l c wpis "我们有计划吗？就算和西尔维尔对练时我也只是勉强撑住，如果他更强大得多…"


    if fawn_route:
        translate None lucius_fight_0042:
            f c wsad "我们有计划吗？或者说…有什么主意都好？"

    translate None lucius_fight_0043:
        v sad "...."
    translate None lucius_fight_0044:
        i ang "我认为你可以理解为没有计划。"
    translate None lucius_fight_0045:
        rs c wsad "那么…我们唯一的选择就是以人数压制他。"
    translate None lucius_fight_0046:
        v "…没错。"
    translate None lucius_fight_0047:
        "当我们低声交谈时，某个未知方向传来了轻柔的脚步声。那声音越来越近，直到…"


    scene bg throneno with dissolve

    if cyne_route:
        show fawn nw dim neu cloak at slightleft
        show leos nw dim neu cloak at slightright
        with dissolve
        translate None lucius_fight_0048:
            rs c wsur "莱奥斯！福恩！"
        translate None lucius_fight_0049:
            l "...."
        translate None lucius_fight_0050:
            f "....."


    if leos_route:
        show fawn nw dim neu cloak at slightleft
        show cyne nw dim neu cloak at slightright
        with dissolve
        translate None lucius_fight_0051:
            rs c wsur "赛恩！福恩！"
        translate None lucius_fight_0051b:
            c "...."
        translate None lucius_fight_0051c:
            f "....."


    if fawn_route:
        show leos nw dim neu cloak at slightleft
        show cyne nw dim neu cloak at slightright
        with dissolve
        translate None lucius_fight_0052:
            rs c wsur "莱奥斯！赛恩！"
        translate None lucius_fight_0052b:
            l "...."
        translate None lucius_fight_0052c:
            c "....."


    translate None lucius_fight_0053:
        rs c wsad "大家，快醒醒—"
    translate None lucius_fight_0054:
        "当我冲向他们时，维拉斯用胳膊拦住了我。"
    translate None lucius_fight_0055:
        v fro "他们此刻对你造成伤害时绝不会犹豫。"
    translate None lucius_fight_0056:
        i ang "我从没见过如此精准的控制力……"
    translate None lucius_fight_0057:
        v sad "言者的力量，因神之力而更强大。他令人恐惧。"
    translate None lucius_fight_0058:
        i ang "…继续前进。这两个交给我来处理。"
    translate None lucius_fight_0059:
        v sur "伊尔兰！？"


    if cyne_route:
        translate None lucius_fight_0060:
            i con "拜托，对我有点信心。你以为我对付不了那个森林小子和瘦竹竿吗？"


    if leos_route:
        translate None lucius_fight_0061:
            i con "拜托，对我有点儿信心好吧。你觉得我还干不过那个矮子和森林小子吗？"


    if fawn_route:
        translate None lucius_fight_0062: # MISSING
            i con "来吧，对我有点信心。你以为我对付不了那小矮子和细竹竿吗？"


    translate None lucius_fight_0063:
        v sad "…别鲁莽行事。"
    translate None lucius_fight_0064:
        i "我想都不敢想。"
    translate None lucius_fight_0065:
        cas sad "....."
    translate None lucius_fight_0066:
        ae sad "卡斯……？"
    translate None lucius_fight_0067:
        cas ang "我也留下来。"
    translate None lucius_fight_0068:
        ae sad "为什么？"
    translate None lucius_fight_0069:
        cas "我没有像你们所有人那样与神明对抗的力量。全世界的激情也无法改变这点。"
    translate None lucius_fight_0070:
        cas smi "揍几个小鬼？这个我在行。"
    translate None lucius_fight_0071:
        "艾米尔脸上掠过一丝忧虑与渴望，但他紧紧闭上嘴，庄重地点了点头。"
    translate None lucius_fight_0072:
        ae ann "…别死，听见了吗？我们还有太多事要倾诉。"
    translate None lucius_fight_0073:
        cas "连想都没想过。"


    if cyne_route:
        play sound "sounds/sfx/kick2.ogg" fadeout 1.0
        hide fawn
        hide leos
        with hpunch
        translate None lucius_fight_0074:
            "当我们经过时，福恩和莱奥斯过来阻拦，但伊尔兰飞起一脚，分散了他们的注意力。"


    if leos_route:
        play sound "sounds/sfx/kick2.ogg" fadeout 1.0
        hide cyne
        hide fawn
        with hpunch
        translate None lucius_fight_0075:
            "当我们经过时，福恩和赛恩过来阻拦，但伊尔兰飞起一脚，分散了他们的注意力。"


    if fawn_route:
        play sound "sounds/sfx/kick2.ogg" fadeout 1.0
        hide cyne
        hide leos
        with hpunch
        translate None lucius_fight_0076:
            "当我们经过时，赛恩和莱奥斯过来阻拦，但伊尔兰飞起一脚，分散了他们的注意力。"



    translate None lucius_fight_0077:
        "维拉斯面无表情，但我能看出他内心正经历着强烈的情感波动。"


    scene black with swipe
    scene bg throneno with swipe:
        xpos 0.25 ypos 1.14 xanchor 0.5 yanchor 1.0 zoom 1.64
        linear 35.0 xpos 0.72 ypos 1.14 xanchor 0.5 yanchor 1.0 zoom 1.64
    translate None lucius_fight_0078:
        "我们穿过一条走廊，进入另一个宽敞的大厅。厅内排满铁笼—起初我以为空无一物，走近才发现每个笼子里都蠕动着密密麻麻的人影。"
    translate None lucius_fight_0079:
        "…他们被塞得如此之满，以至于面容都紧贴在铁栅栏上，那些布满血丝的眼球齐刷刷转向我们。"
    translate None lucius_fight_0080:
        mor c sad "凡人…与神明。他的盘中餐。"
    translate None lucius_fight_0081:
        rs c wsad "他怎么能在这短短的时间内完成这么多事…？"
    translate None lucius_fight_0082:
        mor c sad "他筹划这事已经太久了…"
    translate None lucius_fight_0083:
        mor "或许…从他死前就开始了。"


    if fawn_route:
        translate None lucius_fight_0084:
            f c wsad "太可怕了…"


    stop music fadeout 2.0

    play sound "sounds/sfx/fallonground3.ogg"
    scene bg throneno with hpunch:
        xpos -0.02 ypos 1.05 xanchor 0.5 yanchor 1.0 zoom 2.05
    translate None lucius_fight_0085:
        "一道阴影从黑暗角落猛扑而出，我俩的重量一起在地面光滑的漆面上滑行。"


    if cyne_route:
        translate None lucius_fight_0086:
            c c wsur "雷恩！"


    if leos_route:
        translate None lucius_fight_0087:
            l c whur "喂！"


    if fawn_route:
        translate None lucius_fight_0088:
            f c wsur "雷恩！嘿，放开他…！"

    translate None lucius_fight_0089:
        rs c whur "放…放开我！我们是来帮你们的！"


    play sound "sounds/sfx/kick1.ogg"
    show bg throneno with vpunch


    if cyne_route:
        translate None lucius_fight_0091:
            "房间在我眼前天旋地转，我拼命想甩开压在我身上的重量。仅仅一秒钟后，那个将我拽倒在地的东西又窸窸窣窣地退回了笼罩房间的黑暗阴影中。"
        translate None lucius_fight_0092:
            "当我抬头看时，赛恩正站在我上方，维拉斯在他身旁。看来那一记踢腹起了作用。"
        translate None lucius_fight_0093:
            play music "sounds/sfx/creepy3.ogg" fadein 2.0
            rs c wsad "他们有什么毛病？"
        translate None lucius_fight_0094:
            s thi "他们的心智已然支离破碎。"
        translate None lucius_fight_0095:
            mor c sad "…他们或许还保留着些许理智。"
        translate None lucius_fight_0096:
            el gla "要是有的话，那也深埋在心里。"


    if leos_route:
        translate None lucius_fight_0097:
            "当莱奥斯揪起扑在我身上的人摔向冰冷的石地板时，那股重量突然离开了我的身体。"
        translate None lucius_fight_0098:
            l "把你那肮脏的手从他身上拿开。"
        translate None lucius_fight_0099:
            "我抬头望向站在我上方的莱奥斯。他朝那个人皱眉怒视，他们便仓皇逃入黑暗之中。"
        translate None lucius_fight_0100:
            play music "sounds/sfx/creepy3.ogg" fadein 2.0
            "他小心翼翼地伸出手，扶着我站起来。在松开前，我特意轻轻握了下他的手以示感谢。"
        translate None lucius_fight_0101:
            "我眯起眼睛望向黑暗之中，努力想要看清。"


    if fawn_route:
        translate None lucius_fight_0102:
            "房间突然在烈焰中亮起，将我拖倒在地的东西窸窸窣窣地退回了困扰着整个房间的黑暗阴影中。"
        translate None lucius_fight_0103:
            "当我抬起头时，福恩的手仍然举着。"
        translate None lucius_fight_0104:
            rs c wsur "福恩……？"
        translate None lucius_fight_0105:
            "他俯身伸手。我盯着那只手。那只能够凭空召唤火焰的手…"
        translate None lucius_fight_0106:
            "我承受了这一切。他把我拉到身旁，我转身凝视黑暗。"


    translate None lucius_fight_0107:
        s neu "他们无处不在。每个门口，每片阴影里。"


    if leos_route:
        translate None lucius_fight_0108:
            l c wpis "它们是什么？"


    if fawn_route:
        translate None lucius_fight_0109:
            f c wsad "这些…是什么？"


    translate None lucius_fight_0110:
        s "他们曾经是人。是卢修斯无力掌控的人，现在他们崩溃了。"
    translate None lucius_fight_0111:
        s "对于癫狂疯癫的肉块来说，还有比当看门狗更好的用途吗？"
    translate None lucius_fight_0112:
        v fro "如果他之前没料到我们会来，现在也该知道了。"
    translate None lucius_fight_0113:
        rs c wsad "我们该怎么通过他们？"


    if fawn_route:
        translate None lucius_fight_0114:
            f "也许我该—"

    translate None lucius_fight_0115:
        el gla "...."
    translate None lucius_fight_0116:
        el "西尔维尔，莫温，你们跟我来。"
    translate None lucius_fight_0117:
        el "我们来开路，并解决任何追兵，然后把笼子里的人都解救出来。"
    translate None lucius_fight_0118:
        mor c smi "我们会尽快找到你们的。注意安全，我的孩子们。"
    translate None lucius_fight_0119:
        v fro "不能浪费他们给我们的时间。快，抓紧。"
    translate None lucius_fight_0120:
        "穿过另一道门，我们终于来到宏伟的大厅。房间尽头摆着王座。"

    stop music fadeout 2.0
    window hide dissolve

    scene bg throne blur:
        xpos 0.47 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.99
    show luc n smi cloak:
        xpos 0.5 ypos 1.68 xanchor 0.5 yanchor 1.0 zoom 2.01
    with dissolve
    #scene gallery_111 with dissolve
    window show dissolve
    play music "sounds/bgm/forgotten.ogg" fadein 3.0

    if achievement.has("lucius_throne"):
        pass
    else:
        $ renpy.display_notify("成就解锁：王座上的国王")

    python:
        achievement.grant("lucius_throne")
        achievement.sync()

    translate None lucius_fight_0121:
        "在那上面，卢修斯大模大样地倚靠着，两腿高高翘起。"
    translate None lucius_fight_0122:
        luc "哇，你真的成功来到这儿了？让我刮目相看。"
    translate None lucius_fight_0123:
        show luc n sad with dis
        luc "哦…但你漏掉了几个。好吧，一路上牺牲几个人也没什么大不了的。不过是剔除薄弱环节而已，对吧？"


    if cyne_route:
        translate None lucius_fight_0124:
            luc "等等…不，你带来的还是个废物。你可真有种啊。"

    translate None lucius_fight_0125:
        v fro "…我们没有薄弱环节。"
    translate None lucius_fight_0126:
        luc "哦，你知道的，那个绿头发的。口气很大，但毫无真本事。别担心，我的手下会解决他。不过不能保证死得痛快。"
    translate None lucius_fight_0127:
        v "...!"


    if cyne_route:
        translate None lucius_fight_0128:
            c c wang "抱歉，你是听不懂他说的话吗？他说我们没有任何薄弱环节。"
        translate None lucius_fight_0129:
            show luc n smir with dis
            luc "你又是哪位？"
        translate None lucius_fight_0130:
            luc "哦，对了。那个金发小妞，有恋母情结的那个。话说你在这儿干嘛？你真能干点啥吗？"
        translate None lucius_fight_0131:
            c c whap "显而易见，我是来揍你的。"
        translate None lucius_fight_0132:
            luc "我好害怕啊。"


    if leos_route:
        translate None lucius_fight_0133:
            l c wpis "别理他。他明显是以把人惹毛为乐。"
        translate None lucius_fight_0134:
            show luc n smir with dis
            luc "哎哟！莱奥斯，你可伤到我了。好吧，你没说错。"
        translate None lucius_fight_0135:
            luc "我必须说—我对你非常失望。我以为你会服从我的命令。"
        translate None lucius_fight_0136:
            l "谢了，但免了吧。我可没打算跟你共事。"
        translate None lucius_fight_0137:
            luc "抛弃你唯一擅长的事，还剩下什么？没人能那么轻易改变。"
        translate None lucius_fight_0138:
            l "这不是你能决定的。"


    if fawn_route:
        translate None lucius_fight_0139:
            f c wbla "冷静，维拉斯。他只是想激怒你。"
        translate None lucius_fight_0140:
            luc "你又是哪位？那个沉默寡言的无名小卒…"
        translate None lucius_fight_0141:
            show luc n smir with dis
            luc "噢，我想起来了！那个恶魔般的孩子。就是那个杀害了自己父母的孩子。"
        translate None lucius_fight_0142:
            rs c wang "这不是真的。"
        translate None lucius_fight_0143:
            f "…..完全正确。根本就不是这么回事。"
        translate None lucius_fight_0144:
            luc "看来你长骨气了嘛。"
        translate None lucius_fight_0145:
            f "承蒙关注。看来你的态度还是老样子。"


    translate None lucius_fight_0146:
        rs c wang "是时候结束这一切了。只要投降，我们就不会伤害你。"
    translate None lucius_fight_0147:
        show luc n neu with dis
        luc "...."
    translate None lucius_fight_0148:
        show luc n smi with dis
        luc "啊哈哈哈哈哈哈！"
    translate None lucius_fight_0149:
        "他的笑声在房间里回荡，触碰到每个表面又弹开。"
    translate None lucius_fight_0150:
        luc "让我退出？如果这是个玩笑，那可不太好笑。"
    translate None lucius_fight_0151:
        ae ang "……这不是玩笑。是时候结束这一切了，卢修斯。"
    translate None lucius_fight_0152:
        luc "哎呀，这不是我的傀儡吗，言者少爷本人啊。"
    translate None lucius_fight_0153:
        ae "你没有权利这么称呼我，再也不能了。"
    translate None lucius_fight_0154:
        show luc n neu with dis
        luc "你以为站在他们那边就所有罪过都能被宽恕吗？无论你做什么，你都改变不了。"
    translate None lucius_fight_0155:
        ae "…我可以试试。"
    translate None lucius_fight_0156:
        luc "如果你跪地求饶，或许我可以让你在我身边占有一席之地。"
    translate None lucius_fight_0157:
        ae "我绝不会再允许自己被你所利用。"
    translate None lucius_fight_0158:
        show luc n smi with dis
        luc "真的吗？即使卡斯皮安那样背叛了你，你还要反对我？"
    translate None lucius_fight_0159:
        ae "卡斯皮安没做错任何事！我知道真相。我知道你做了什么！"
    translate None lucius_fight_0160:
        show luc n ang with dis
        luc "….真无聊。你变得越来越像他了。真令人作呕。"
    translate None lucius_fight_0161:
        luc "满脑子青春热情和冒险精神。恶心至极。"
    translate None lucius_fight_0162:
        rs "…我们还带了帮手。要打就打。"


    if cyne_route:
        translate None lucius_fight_0163:
            show luc n smi with dis
            luc "让我把话说清楚—我难道要害怕一个过气的老头、一个失去力量的神、一个只会说谎的男孩，还有一个连左右都分不清的家伙？"


    if leos_route:
        translate None lucius_fight_0164:
            show luc n smi with dis
            luc "让我把话说清楚—我该害怕一个过气老头、一个无能的神、一个前杀手，还有一个连左右都分不清的家伙？"


    if fawn_route:
        translate None lucius_fight_0165:
            show luc n smi with dis
            luc "让我把话说清楚—我该害怕一个过气老头、一个无能的神、一个弑父的无名之辈，还有个连左右都分不清的小子？"

    translate None lucius_fight_0166:
        luc "噢，我在发抖。"


    if fawn_route:
        translate None lucius_fight_0167:
            f c wbla "你真正该害怕的是你孤身一人。你永远都是孤单的。做什么都改变不了这点。"
        translate None lucius_fight_0168:
            f c wsad "我知道，因为我也曾孤身一人。"
        translate None lucius_fight_0169:
            f "但我改变了我的命运。我没有像你那样放弃。"

    translate None lucius_fight_0170:
        v "你是哪里不明白？我们不会坐视你夺走人类的自由。"
    translate None lucius_fight_0171:
        show luc n neu with dis
        luc "人类并不渴望自由。他们期待一个强大的仰望对象。一个他们可以盲目追随的对象。"
    translate None lucius_fight_0172:
        luc "我只是在填补那个空缺。"
    translate None lucius_fight_0173:
        v "你在奥雷利亚卡维拉终生的孤寂使你看不清现实。这些人不想要独裁者，他们只希望能继续过平静的生活。"
    translate None lucius_fight_0174:
        luc "那他们的想法需要被纠正。"
    translate None lucius_fight_0175:
        rs "就像那些被你弄得神志不清到处乱跑的人一样吗？"
    translate None lucius_fight_0176:
        "他耸了耸肩。此前还挂着讥讽的脸，此刻变得面无表情。"
    translate None lucius_fight_0177:
        luc "谁会在乎少了几个人？"
    translate None lucius_fight_0178:
        v "他们—"
    translate None lucius_fight_0179:
        show luc n ang with dis
        luc "我开始厌倦这些了。你是打算教训我吗？"
    translate None lucius_fight_0180:
        v "你没有权利这么做！"
    translate None lucius_fight_0181:
        luc "我完全有这个权利！"
    translate None lucius_fight_0182:
        luc "我将创造的世界不需要言者。我们将自由行走在我的子民之中，而他们将向我们俯首称臣。"


    if fawn_route:
        translate None lucius_fight_0183:
            luc "不过…我正在考虑收几个徒弟。"
        translate None lucius_fight_0184:
            rs c wsur "...?"
        translate None lucius_fight_0185:
            show luc n smi with dis
            luc "或许你认识我的第一位候选人。"
        translate None lucius_fight_0186:
            "随着他的一个响指，一个蓝发女孩从阴影中走出，站在他身旁，愤怒的目光紧紧盯着福恩。"
        translate None lucius_fight_0187:
            f c wsur "安妮！"
        translate None lucius_fight_0188:
            f "你在干什么？！他很危险！"
        translate None lucius_fight_0189:
            luc "可怜又迷失的女孩啊。她心心念念的只是为家人报仇。我有什么资格阻止她呢？"
        translate None lucius_fight_0190:
            f c wsad "你敢动她一根手指试试！"
        translate None lucius_fight_0191:
            luc "哦，我哪敢阻拦啊。我一定会好好照顾她的。不是吗，安妮？"
        translate None lucius_fight_0192:
            ani ang "……我永远不会原谅你杀害了父亲。更不会原谅你逼得母亲自尽。"
        translate None lucius_fight_0192b:
            f "...."
        translate None lucius_fight_0193:
            ani "别只是保持沉默！你就这样不在乎他们吗？！"
        translate None lucius_fight_0193b:
            f "...."
        translate None lucius_fight_0194:
            f "…我这一生都在逃避过去。为发生的一切而自责。"
        translate None lucius_fight_0195:
            f "我当然悲痛过！我现在依然悲痛，但是…！我想跨过这道坎。我想纪念他们。"
        translate None lucius_fight_0196:
            ani "你甚至不配记住他们！"
        translate None lucius_fight_0196b:
            rs c wsad "他确实—"
        translate None lucius_fight_0197:
            f "我有锁！"
        translate None lucius_fight_0198:
            f "这件事根本不是我能控制的，你到底什么时候才能停止指责我？！"
        translate None lucius_fight_0199:
            ani sad "..."
        translate None lucius_fight_0199b:
            f "我会超越这一切，不管你是否允许。"
        translate None lucius_fight_0200:
            f "我永远不会忘记。我永远不会停止悲痛。但现在…现在我想试着活下去！"
        translate None lucius_fight_0201:
            luc "啊哈哈哈，你听到了吗？他根本不在乎你经历过什么。不在乎你的姐妹们如何不得不相互抚养长大，牺牲了她们的童年。"
        translate None lucius_fight_0202:
            luc "与此同时，他们那位犯下谋杀罪行的兄弟正在森林里无忧无虑地嬉戏玩耍。"
        translate None lucius_fight_0203:
            luc "看看他对你的痛苦有多么冷漠。"
        translate None lucius_fight_0204:
            ani ang "……我要亲手杀了他。"
        translate None lucius_fight_0204b:
            luc "噢噢噢，这可有意思了。我向来不会拒绝需要帮助的人，所以—"
        translate None lucius_fight_0205:
            "当卢修斯向安妮伸出手时，一道明亮的光照亮了房间的每个角落。一道柔和的光晕环绕着她，随后几乎完全消失了。"
        translate None lucius_fight_0206:
            "如果你眨一下眼，就能看到一道微弱的光之缚链连接着他们。"

        window hide


        menu:
            "冲向前":
                $ fawn_badend += 1
                window show dissolve
                translate None lucius_fight_0207:
                    "我的身体甚至快过了我的思考。我刚要冲上前去，福恩却抓住我的手拽住了我。"
                translate None lucius_fight_0208:
                    f c wneu "等等…求你了。"


            "等着":
                $ fawn_goodend += 1
                window show dissolve
                translate None lucius_fight_0209:
                    "我一动不动地站着等待。我身体的每一寸都想冲上前去阻止正在发生的事，但我知道那太危险了。"

        translate None lucius_fight_0210:
            f c wneu "安妮，你正在犯一个错误。即使你再也无法忍受看我一眼…回家吧。回到我们的家人身边。"
        translate None lucius_fight_0211:
            ani ang "你怎么敢说「我们」的家庭…！那里已不再是你家人了。"
        translate None lucius_fight_0211b:
            show luc n neu with dis
            luc "废话够多了。我开始觉得无聊了。"
        translate None lucius_fight_0212:
            "随着他手腕一抖，安妮被摔到了我们脚下的地面。福恩看起来很震惊，但还是伸出手想扶她起来。"
        translate None lucius_fight_0213:
            v sur "...."
        translate None lucius_fight_0214:
            v "福恩，退后！"
        translate None lucius_fight_0215:
            "维拉斯拽了拽福恩的袖子，一道长矛般的光芒刺入了他刚才站立的地面。"
        translate None lucius_fight_0216: # missing line
            rs c wsur "什么…你怎么会知道？"


    if leos_route:
        translate None lucius_fight_0218:
            show luc n smi with dis
            luc "但你并非必须独自承受。莱奥斯，我能从你眼中看出来。我们是同类。加入我吧。"
        translate None lucius_fight_0219:
            l c wsmu "…噗嗤。真好笑。"
        translate None lucius_fight_0220:
            "卢修斯那一片沉寂。"
        translate None lucius_fight_0221:
            l c wneu "噢，你是认真的？不用了，谢谢，我还好。"
        translate None lucius_fight_0222:
            "我向前伸手握住他的手。他回头看向我微微一笑，然后再次面向卢修斯。"
        translate None lucius_fight_0223:
            luc "哈哈哈哈。爱情真的会毁掉一切，不是吗？你知道吗，我刚才还在想着该活动活动筋骨了。"

        window hide dissolve

        scene bg throne with dissolve:
            xpos 0.48 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.5
        window show dissolve

        play sound "sounds/sfx/walkinghall2.ogg"
        translate None lucius_fight_0224:
            "他从王座上站起身，鞋跟在大理石地面敲击着朝我们走来。"
        translate None lucius_fight_0225:
            "卢修斯抬起手打了个响指，一把细长的武器凭空出现在他手中，如活物般散发着幽光。"



    if cyne_route:
        translate None lucius_fight_0226:
            show luc n smi with dis
            luc "不过……我确实在考虑找个帮手。算是助理吧。"
        translate None lucius_fight_0227:
            lv neu "一名助手？"
        translate None lucius_fight_0228:
            luc "一个深得我心的女人。好吧，或许我会考虑让你与我共同统治。"
        translate None lucius_fight_0229:
            c c wsur "母亲…？"
        translate None lucius_fight_0230:
            lv smi "我亲爱的儿子。见到你真让人高兴。"
        translate None lucius_fight_0231:
            c c wang "……不是说要和我断绝关系吗？"
        translate None lucius_fight_0232:
            lv "我们是一家人，不是吗？我们可以把这些都抛在脑后。加入我吧，西纳库洛斯。"
        translate None lucius_fight_0233:
            c "....."
        translate None lucius_fight_0234:
            c "你不是我的家人。"
        translate None lucius_fight_0235:
            lv neu "你说什么？我给你一次机会重新组织语言。"
        translate None lucius_fight_0236:
            c "我说了你不是我的家人！你根本不懂家人意味着什么！"
        translate None lucius_fight_0237:
            lv ang1 "在我为你做了这么多之后—"
        translate None lucius_fight_0238:
            c "你为我做过什么？！"
        translate None lucius_fight_0239:
            lv ang2"..你这一生全仗着我才有今天。你的钱财、你的衣裳、你的口粮。你做过的一切事情，都要感谢我！"
        translate None lucius_fight_0240:
            c "你连最基本的都不配得到称赞！"
        translate None lucius_fight_0241:
            lv "没有我你什么都不是。听见了吗？什么都不是！"
        translate None lucius_fight_0242:
            c "我不在乎！如果后半生能被爱我的人围绕，我甘愿做个微不足道的人！"
        translate None lucius_fight_0243:
            lv "....."
        translate None lucius_fight_0244:
            luc "哎呀呀，家庭争吵真是令人心碎呢？来吧，抱一个然后和好吧。"
        translate None lucius_fight_0245:
            c "…母亲，你只有一次离开这里的机会，能避开即将发生在你身上的事。"
        translate None lucius_fight_0246:
            lv "你无权威胁我。我站在胜利的一方。"
        translate None lucius_fight_0247:
            luc "你怎么说？有兴趣和你儿子打一架吗？"
        translate None lucius_fight_0248:
            lv ang1 "我，打架？别开玩笑了。"
        translate None lucius_fight_0249:
            show luc n neu with dis
            luc "哈……我真是找了个烦人的女人。好吧，把其他人都带上来。"
        translate None lucius_fight_0249b:
            play sound "sounds/sfx/crash1.ogg" fadeout 1.0
            show bg with vpunch # show gallery_111 with vpunch
            "随着他手指的一个响指，整个房间轰鸣震动起来，白色砖块随即在房间内四散横飞。 "
        translate None lucius_fight_0251:
            "我们全都散开了，小心翼翼地避免被任何东西击中。"
        translate None lucius_fight_0252:
            "当尘埃在我们周围落定时，我们看清了是谁走进了房间。是福恩。"
        translate None lucius_fight_0253:
            "他衣衫褴褛，神情木然。"
        translate None lucius_fight_0254:
            rs c wsur "伊尔兰和卡斯皮安怎么样了…？"
        translate None lucius_fight_0255:
            "卢修斯微笑着回应，更深地陷入王座之中。"
        translate None lucius_fight_0256:
            show luc n smir with dis
            luc "谁知道呢？也许他们已经死了。"
        translate None lucius_fight_0257:
            ae ang "...!"
        translate None lucius_fight_0258:
            v fro "不…伊尔兰不会这么轻易死去。"
        translate None lucius_fight_0259:
            luc "随便你怎么想。我根本不在乎你信什么。"
        translate None lucius_fight_0260:
            v sad "....."

        window hide

        menu:
            "冲向福恩":
                window show dissolve
                translate None lucius_fight_0261:
                    "我毫不犹豫地冲向前方，直奔福恩而去。"
                translate None lucius_fight_0262:
                    rs c wsad "福恩，快醒醒！"
                translate None lucius_fight_0263:
                    c c wsur "嘿，等等—！"
                translate None lucius_fight_0264:
                    v ouc "雷恩！"
                translate None lucius_fight_0265:
                    "瞬息之间福恩已来到我身旁。"

                window hide

                menu:
                    "滚开":
                        window show dissolve
                        translate None lucius_fight_0266:
                            "我踉跄着后退到他攻击范围之外。赛恩将我拉近，怒视着卢修斯。"


                    "试着抓住他":
                        window show dissolve
                        translate None lucius_fight_0267:
                            "我伸出手，拼命想唤醒福恩的神志。被我碰触的瞬间，他脸色阴沉下来，举起胳膊要揍我。"
                        translate None lucius_fight_0268:
                            "最后关头，有人揪着我的后颈把我拉开。是维拉斯。"


            "跟赛恩留在后面":
                window show dissolve
                translate None lucius_fight_0269:
                    "我退后几步，看着福恩。真正的他还在里面，对吧？我们能救他…对吗？"

        translate None lucius_fight_0270:
            rs c wsad "福恩，求求你，听我们说！我们是你的朋友啊！"
        translate None lucius_fight_0271:
            "没有用。我的声音传不到他那里。他继续茫然地朝我的方向盯着，然后突然抬起了手。"
        translate None lucius_fight_0272:
            "在舞台上，我能看见卢修斯操控着他的动作—掌控着他的一举一动。"
        translate None lucius_fight_0273:
            "突然，一支长矛般的箭矢破空而出，直射向福恩。他伸手一把抓住，随即将其对准了赛恩。"
        translate None lucius_fight_0274:
            c c wsur "...."


    if leos_route or cyne_route:
        translate None lucius_fight_0275:
            rs c wsur "那是…什么？"
        translate None lucius_fight_0276:
            v fro "纯粹的力量。众多灵魂的组合，全部倾注于单一容器之中。"
        translate None lucius_fight_0277:
            rs "你怎么知道？"

    translate None lucius_fight_0278:
        v "就是他之前用来伤害伊尔兰的同一个东西。"
    translate None lucius_fight_0279:
        "我的手心不在焉地摸到了肩上包扎的伤口。这伤来自伊尔兰…"
    translate None lucius_fight_0280:
        rs "……你不仅能操控人心，还能凭空变出这种东西？"


    if cyne_route or fawn_route:
        translate None lucius_fight_0281:
            luc "神明的力量可以没有边界，但他们却畏惧行使它。" #voice map with below

    if leos_route:
        translate None lucius_fight_0282:
            luc nsmir "神明的力量可以没有边界，但他们却畏惧行使它。" # voice map with above


    translate None lucius_fight_0283:
        v "因为操纵如此强大的力量完全违背了我们存在的意义！"
    translate None lucius_fight_0284:
        v "杀戮与吞噬，掠夺与谋杀—你是怪物，而非神灵。"


    if cyne_route:
        translate None lucius_fight_0285:
            v "福恩交给我来处理。你们三个专心对付卢修斯。"
        translate None lucius_fight_0286:
            c c wang "我来帮忙。"
        translate None lucius_fight_0287:
            rs c wsad "等等，赛恩—"
        translate None lucius_fight_0288:
            c c wsad "…我和你们其他人不一样，这点我很清楚。我明白自己可能帮不上什么忙。"
        translate None lucius_fight_0289:
            c c wang "但这不会阻止我去尝试。"
        translate None lucius_fight_0290:
            v "跟我来，赛恩。"
        translate None lucius_fight_0291:
            "福恩缓慢地向维拉斯和赛恩移动，后者迅速将注意力从我们身上移开。眨眼间，福恩已手持长矛来到他们面前。"
        translate None lucius_fight_0292:
            "赛恩向侧面翻滚，然后扑向福恩试图抱住他。福恩轻松地闪避开来，但维拉斯正在等着他。"
        translate None lucius_fight_0293:
            ae ang "把他交给他们吧。雷恩…这是我们的职责。"


    if leos_route:
        translate None lucius_fight_0294:
            luc "你知道的，我其实不太喜欢贴标签。"
        translate None lucius_fight_0295:
            "他将长矛在空中旋转一圈，轻松接住后指向我们这边，脸上挂着那抹将永远萦绕在我心头的笑容。"
        translate None lucius_fight_0296:
            luc "谁想第一个来？"
        translate None lucius_fight_0297:
            "维拉斯压低声音对我们咕哝了几句。"
        translate None lucius_fight_0298:
            v fro "借此机会观察他的行动并制定计划。"
        translate None lucius_fight_0299:
            rs c wsur "等等，维拉斯—"
        translate None lucius_fight_0300:
            v "…身为神明，保护人类是我的职责—这一点从未改变，也永远不会改变。即便要付出生命的代价，若能保护我所爱之人，我也将欣然赴死。"
        translate None lucius_fight_0301:
            luc nneu "别白费口舌了。"
        translate None lucius_fight_0302:
            "维拉斯甚至还没来得及思考，卢修斯就已冲上前来，武器蓄势待发随时准备攻击。"
        translate None lucius_fight_0303:
            "当莱奥斯向他喊话时，他勉强踉跄着侧身躲过了危险。"
        translate None lucius_fight_0304:
            l c wpis "接住！"
        translate None lucius_fight_0305:
            "他的一把备用匕首叮当作响地划过大理石地板飞向维拉斯。听到声音后，他弯腰抄起匕首，随即将其对准卢修斯。"
        translate None lucius_fight_0306:
            "卢修斯没给他任何反击的机会。当他无情地压向维拉斯时，攻击如连绵不绝的浪潮般袭来。"
        translate None lucius_fight_0307:
            "维拉斯很强。我知道。我亲眼见识过他和诺克斯的战斗。"
        translate None lucius_fight_0308:
            "但是…卢修斯完全是另一回事。"
        translate None lucius_fight_0309:
            "用\"怪物\"来形容会很贴切。"
        translate None lucius_fight_0310:
            "我绷紧了身体，拼命想冲到他身边帮忙，但莱奥斯紧紧抓着我的手，不让我冲进混战之中。"
        translate None lucius_fight_0311:
            l "他这是在给我们学习的机会。仔细看好了。"


    if fawn_route:
        translate None lucius_fight_0312:
            "安妮的手猛然伸出，一把攥住了横梁，借着它的支撑站起身来，站稳后将它从地面拔起。她将横梁指向福恩。"
        translate None lucius_fight_0313:
            f c wneu "...."
        translate None lucius_fight_0314:
            ani ang "...."
        translate None lucius_fight_0315:
            "她猛冲向前，直指福恩而去。他纵身闪避，在大理石地面上翻滚开来。她的动作十分生疏，明显是个使武器的生手，但那武器迸发出的纯粹力量令她危险万分。"
        #translate None lucius_fight_0315b:
            #ae ann "Leave her to them. Raen… this is our duty."

    translate None lucius_fight_0316:
        ae ang "卢修斯，你不是言者。我才是。雷恩也是。"
    translate None lucius_fight_0317:
        ae "你不过是真正自我的空洞倒影。"
    translate None lucius_fight_0318:
        luc "哈哈哈哈，把那孩子折磨成这样，现在倒自诩是他的导师了？"
    translate None lucius_fight_0319:
        ae sad "...."
    translate None lucius_fight_0320:
        ae "他将成为我们未能成就的一切。"


    if cyne_route:
        translate None lucius_fight_0321:
            "战斗持续着，我看见福恩逐渐逼近赛恩。他闪转腾挪，却始终没有真正出手。事实上，他看起来根本没打算击中对方。"


    if leos_route:
        play sound "sounds/sfx/swing1.ogg"
        translate None lucius_fight_0322:
            show bg throne with vpunch
            "他们的打斗仍在继续，但维拉斯很快就招架不住了。他闪避着、格挡着，却始终找不到机会用他那临时凑合的武器反击。"


    if fawn_route:
        translate None lucius_fight_0323:
            "另一边，安妮、维拉斯和福恩之间的战斗仍在继续。她持续发动迅猛的攻击，而福恩则不断躲避—我猜他是不忍心伤害自己的妹妹。"

    translate None lucius_fight_0324:
        luc "所有{i}你{/i}都做不到的事。我走得比任何一位前任言者都要远。"
    translate None lucius_fight_0325:
        rs c wang "……在我看来，你堕落得更深了。"
    translate None lucius_fight_0326:
        luc "…什么？"
    translate None lucius_fight_0327:
        rs "言者的职责是保护其人民，而非统治人民。你未能履行你的职责。"
    translate None lucius_fight_0328:
        luc "好像你对当言者很了解似的。"
    translate None lucius_fight_0329:
        rs "我也许懂得不多，但至少还分得清对错，这点你似乎很困扰！"


    if cyne_route:
        translate None lucius_fight_0330:
            "卢修斯狞笑着打了个响指，又一束光芒射向另外三人。"


    if leos_route:
        translate None lucius_fight_0331:
            play sound "sounds/sfx/kick1.ogg"
        translate None lucius_fight_0332:
            "卢修斯皱着眉头，一脚把维拉斯踢开，同时手腕一抖—那柄长矛突然如同光束般向他射去。"
        translate None lucius_fight_0333:
            "高悬于穹顶的枝形吊灯剧烈摇晃着。 "


    if fawn_route:
        translate None lucius_fight_0334:
            "卢修斯狞笑着打了个响指。又一束光芒射向福恩和维拉斯，接着—"



    play sound "sounds/sfx/stab3.ogg"


    if cyne_route or fawn_route:
        show bg with hpunch

    if leos_route:
        show bg throne with hpunch

    translate None lucius_fight_0335:
        v ouc "啊！"
    translate None lucius_fight_0336:
        "鲜血从维拉斯被钉在墙上的肩膀处滴落下来，在大理石地板上溅开。"
    translate None lucius_fight_0337:
        rs c wsur "维拉斯！"


    if leos_route or cyne_route:
        translate None lucius_fight_0338:
            "他伸出手，发狂般地抓挠着那杆长矛，但仍无法将其拔出。我还未来得及上前帮忙…"


    if fawn_route:
        translate None lucius_fight_0339:
            "他伸手向上，拼了命地抓挠那支长矛，却怎么也拔不出来。我还未来得及上前帮忙，就听见福恩也突然大喊起来。"
        translate None lucius_fight_0340:
            f c whur "啊！"
        translate None lucius_fight_0341:
            "安妮站在福恩上方，低头凝视着他的眼睛。"
        translate None lucius_fight_0342:
            f "这真是你想要的吗？"
        translate None lucius_fight_0343:
            ani cry "…..那个我曾经深爱的小男孩已经不在了。"
        translate None lucius_fight_0344:
            "尽管她这么说着，手却犹豫了。我刚要冲过去，安妮就轰然撞上了墙壁。"
        translate None lucius_fight_0345:
            "她的身体软绵绵地倒下，像一堆烂泥般不再动弹。"
        translate None lucius_fight_0346:
            f "安妮！"
        translate None lucius_fight_0347:
            "福恩朝她冲去，但我们所有人的目光都转向了始作俑者。"
        translate None lucius_fight_0348:
            luc "无聊，真无聊。我原本对她寄予厚望，但她对复仇的渴望并不纯粹。真是令人失望。"
        translate None lucius_fight_0349:
            luc "不过是个无聊的平凡丫头。"


    if cyne_route:
        translate None lucius_fight_0350:
            luc "一只害虫已经解决了。来吧，眼睁睁看着你那些弱小的人类朋友一个个死去。待会儿再来收拾你。"
        translate None lucius_fight_0351:
            luc "或许如果足够幸运，你能在来世遇见那位身着绿衣者。"
        translate None lucius_fight_0352:
            v ouc "........"
        translate None lucius_fight_0353:
            "赛恩转身冲向维拉斯，却露出了后背的空档。福恩朝他猛冲过来，赛恩只得趴倒在地勉强躲过这一击。他伸出一条腿，将那个蓝发男孩绊倒在地。"
        translate None lucius_fight_0354:
            "他的长矛滚落到地板上，伸手无法够到，赛恩立即猛扑过去。"
        translate None lucius_fight_0355:
            "他将福恩的双臂反剪在头顶，福恩爆发出惊人的力量拼命挣扎。他一向力气很大没错，但这次完全不同。有种非人的诡异感。"
        translate None lucius_fight_0356:
            "接着，奇怪的事情发生了。他掌心朝上，突然迸发出火星，这使得赛恩踉跄着后退。"
        translate None lucius_fight_0357:
            "火花？什么？"
        translate None lucius_fight_0358:
            "但在我来得及顺着那条思路想下去之前…"
        translate None lucius_fight_0359:
            c c wang "…福恩，对不住了。我欠你一次。"
        translate None lucius_fight_0360:
            show bg with hpunch #show gallery_111 with vpunch
            "砰！赛恩一拳打在他脸上，他眼中的光芒瞬间熄灭。他停止了踢打和挣扎，瘫软地倒向一边。"
        translate None lucius_fight_0361:
            luc "这不是很意外吗？不过没关系，像他这样的人还有很多。"
        translate None lucius_fight_0362:
            c "闭嘴。"
        translate None lucius_fight_0363:
            luc "为什么？"
        translate None lucius_fight_0364:
            c "福恩比你强大得多。"
        translate None lucius_fight_0365:
            luc "没错，这显而易见。正因如此我才能端坐宝座之上，而他只能不省人事地倒在地上。"
        translate None lucius_fight_0366:
            "我将视线从福恩身上移开，转向一个我能帮助的人。"


    if cyne_route or fawn_route:
        scene bg throne with dissolve:
            xpos 0.48 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.5

        play sound "sounds/sfx/walkinghall2.ogg" fadein 0.5
        translate None lucius_fight_0367:
            "终于，卢修斯从他的王座起身，一步步朝我们走来。所有人都定在原地，吓得连大气都不敢出。"
        translate None lucius_fight_0368:
            "不…不行，维拉斯需要我的帮助..！"

    translate None lucius_fight_0369:
        "我几步冲到维拉斯身边，伸手想要拔出那支长矛—"
    translate None lucius_fight_0370:
        rs c whur "啊！"
    translate None lucius_fight_0371:
        v ouc "...."
    translate None lucius_fight_0372:
        v "别碰它，雷恩。那可不是普通的武器。光是触碰就会被灼伤。"
    translate None lucius_fight_0373:
        v "我这副样子帮不上忙。回去和其他人待着吧。"
    translate None lucius_fight_0374:
        rs c wsad "不，不…你还不能死…！我们还有太多未竟之事…众神啊…！"
    translate None lucius_fight_0375:
        "他给了我一个轻柔的微笑。我了解到，这是他用来安抚他人的那种笑容。"
    translate None lucius_fight_0376:
        v smi "这远不是我受过最严重的伤，我只是不想拖累你。你不必担心我。"


    if iv_scene_three == True:
        translate None lucius_fight_0377:
            v "…..而且无论如何我都不会抛弃伊尔兰。"
        translate None lucius_fight_0378:
            "在我眼前，他的嘴张成了一个完美的O形，就像他突然意识到了什么。"


    window hide dissolve
    jump illrancaspianlucius

label illrancaspianlucius:
    scene bg throneno with Fade(1.0, 1.0, 1.0):
        xpos 0.72 ypos 1.14 xanchor 0.5 yanchor 1.0 zoom 1.64
        linear 35.0 xpos 0.25 ypos 1.14 xanchor 0.5 yanchor 1.0 zoom 1.64
    translate None lucius_fight_0379:
        i ang "我从没想过自己会这么说，但我觉得你们俩喋喋不休的时候反倒更好。"


    if cyne_route:
        translate None lucius_fight_0380: #SYNCED
            fl "...."


    if leos_route:
        translate None lucius_fight_0381: #SYNCED
            cf "......"


    if fawn_route:
        translate None lucius_fight_0382: #SYNCED
            lc "..........."

    translate None lucius_fight_0383:
        cas ang "没用了。他们基本就是行尸走肉。"
    translate None lucius_fight_0384:
        i "稍微鞭打几下就能让他们清醒。"
    translate None lucius_fight_0385:
        play sound "sounds/sfx/swing1.ogg" fadeout 1.0
        "伊尔兰往旁边一跳，险险避过一击。"
    translate None lucius_fight_0386:
        cas "如果没用呢！？"
    translate None lucius_fight_0387:
        i "……但我们还是要继续前进。我有太多需要守护的事物，不能让这一切在这里结束。"

    play sound "sounds/sfx/kick1.ogg" fadeout 1.0

    if cyne_route:
        translate None lucius_fight_0388:
            "福恩被一脚踹出去，摩擦着地面滑行。卡斯皮安掰响指关节，目光转向莱奥斯。"


    if leos_route:
        translate None lucius_fight_0389:
            "随着一脚踢出，福恩在地上滑行了一段。卡斯皮安掰响指关节，目光转向赛恩。"


    if fawn_route:
        translate None lucius_fight_0390:
            "随着一记踢击，赛恩贴着地面滑了出去。卡斯皮安掰响指关节，转而看向莱奥斯。"

    translate None lucius_fight_0391:
        cas smi "……又一个归我了。"
    translate None lucius_fight_0392:
        imn "维拉斯…保护好自己。千万别做傻事。"
    translate None lucius_fight_0393:
        i con "老东西，看看你能不能跟上。"
    translate None lucius_fight_0394:
        imn "我会在此坚守到底"
    translate None lucius_fight_0395:
        cas sur "卧槽老头子？！"


    if cyne_route:
        play sound "sounds/sfx/crash1.ogg" fadeout 1.0
        show bg throneno with hpunch
        translate None lucius_fight_0396:
            "突然一声巨响震撼整栋建筑，福恩已不见了踪影。他的速度快得令他们俩都来不及做出反应。"

    window hide dissolve
    jump luciusfightcont


label luciusfightcont:
    stop music fadeout 2.0

    if cyne_route or fawn_route:
        scene bg throne
        show ds n dim ang at slightleft
        show raen nw dim cloak neu at slightright
        with Fade(1.0, 1.0, 1.0)
        window show dissolve
        translate None lucius_fight_0397:
            "当卢修斯缓步走下台阶，鞋跟敲击在大理石地面上发出清脆声响时，我的目光与艾米尔交汇了。"
        translate None lucius_fight_0398:
            "他微微点头，示意我将卢修斯的注意力引开。我懊恼地离开维拉斯，转身走向王座。"


    if leos_route:
        scene bg throne
        show ds n dim ang at slightleft
        show raen nw dim cloak neu at slightright
        with Fade(1.0, 1.0, 1.0)
        window show dissolve
        translate None lucius_fight_0399:
            "我沮丧地转身离开维拉斯，看见艾米尔和莱奥斯同时冲向卢修斯。他轻松地旋转长矛，保持着安全距离。"
        translate None lucius_fight_0400:
            "他的脸上始终挂着笑容。"
        translate None lucius_fight_0401:
            "他认为这很有趣。就像一场游戏。"
        translate None lucius_fight_0402:
            "一场他稳操胜券的游戏。"
        translate None lucius_fight_0403:
            "艾米尔与莱奥斯四目相对，比手势吸引他的注意，莱奥斯立即会意。"
        translate None lucius_fight_0404:
            l c wsmu "这就是你的全部本事？我期待的可不止这些。"
        translate None lucius_fight_0405:
            "有那么一瞬间，我以为我能看穿他的伪装，他的笑容动摇了一下，但很快又像往常一样坚定地回来了。"



    show raen nw dim ang cloak with dis
    translate None lucius_fight_0406:
        rs "…何必费心做这些事呢？为何不把你的能力用于正道？"
    hide ds with w12
    show luc n dim smir cloak at slightleft with dissolve
    translate None lucius_fight_0407:
        "没有咒语，也没有任何华丽的动作。艾米尔就这么凭空消失了。我注意到周围泛起微微的闪光—是他的迷雾。这就是他制造幻象的方式，对吧？"
    translate None lucius_fight_0408:
        "他并非真正消失或去了别处—只是在愚弄我们的感官。"
    translate None lucius_fight_0409:
        luc "因为这世界总是辜负那些想要行善之人。"
    translate None lucius_fight_0410:
        luc "艾米尔，看来你一直在练习那些小把戏。只可惜—"
    translate None lucius_fight_0411:
        play music "sounds/bgm/battle.ogg" fadein 2.0
        show luc n dim smi with hpunch
        luc "这些对我根本不管用！"
        play sound "sounds/sfx/grip.ogg"
    translate None lucius_fight_0412:
        "卢修斯的手猛然探出，艾米尔瞬间闪现，咽喉被铁钳般的手掌死死扼住。"
    translate None lucius_fight_0413:
        ae hur "呃…呃…"
    translate None lucius_fight_0414:
        luc "啊哈哈哈！"
    translate None lucius_fight_0415:
        luc "你以为用{b}我{/b}教你的本事，就能杀死我？你那小脑袋瓜里哪根筋觉得这是个好主意？"
    translate None lucius_fight_0416:
        luc "我知晓关于你的一切。从你希望深埋的记忆，到你恨不得能遗忘的念头—你的任何举动都惊不到我。"
    translate None lucius_fight_0417:
        rs "放开他！"
    hide raen
    hide luc
    with dissolve
    translate None lucius_fight_0418:
        "我扑向他们，拼命想要解救艾米尔，但卢修斯既没有跳到一旁也没有试图躲闪。"
    translate None lucius_fight_0419:
        show bg throne with vpunch
        "他只是抬起胳膊，同样扼住了我的喉咙。"

    show luc m dim smir cloak
    #show blackbars
    with dissolve
    translate None lucius_fight_0420:
        luc "一手一个言者。呵，这可真是妙极了？"
    translate None lucius_fight_0421:
        "我抓挠着他冰冷的手指，但它们越掐越深。警报声在我体内轰鸣，我大口喘气，拼命想要呼吸，却没有任何空气进入肺部。"
    translate None lucius_fight_0422:
        "我的喉咙仿佛随时都会自行坍缩。那不像人类的手，而像是…一个钳子，纹丝不动。"
    translate None lucius_fight_0423:
        "卢修斯死死盯着我的眼睛，我也直视着他。那双眼眸幽暗无情…空洞至极。"
    translate None lucius_fight_0424:
        "我…我要死了…"
    translate None lucius_fight_0425:
        luc "这样未免太轻易了，不是吗？"
    translate None lucius_fight_0426:
        show luc m dim smi with dis
        luc "别担心，你们俩都不会死在这儿，哦不。会比死亡痛苦千万倍。"
    translate None lucius_fight_0427:
        luc "我—"

    hide luc
    play sound "sounds/sfx/fallonground2.ogg"

    show bg throne
    hide blackbars
    with hpunch

    if fawn_route:
        translate None lucius_fight_0428:
            "艾米尔和我重重摔在地上，冲击力震得骨头咯咯作响，但与踉跄后退的卢修斯散发的狠毒怒火相比，这点疼痛根本不算什么…他后退是为了躲避…"
        translate None lucius_fight_0429:
            "…躲避什么？"
        translate None lucius_fight_0430:
            "我转头看向福恩，他掌心仍跃动着零星的火焰。"
        translate None lucius_fight_0431:
            "我拼命想平复呼吸稳定心神，但缺氧让我头晕目眩，只能发出微弱破碎的喘息。"
        translate None lucius_fight_0432:
            luc ang "你竟敢…"
        translate None lucius_fight_0433:
            f c wbla "不，你才胆大包天！"
        translate None lucius_fight_0434:
            f "不许碰他们！"
        translate None lucius_fight_0435:
            "我惊讶地睁大了眼睛面对这突如其来的对峙。福恩双手向外张开，卢修斯则倒在他下方的地面上。"
        translate None lucius_fight_0436:
            "针对福恩的怨毒怒火在空气中翻涌，浓烈得几乎肉眼可见。"
        translate None lucius_fight_0437:
            luc "…不然怎样？"
        translate None lucius_fight_0438:
            luc "你是要我害怕这个只会逃跑的废物小孩吗？"
        translate None lucius_fight_0439:
            "卢修斯手腕轻抖，又一簇火焰冲天而起。他闪身躲避，扇动着突然遮蔽视线的滚滚浓烟。"
        translate None lucius_fight_0440:
            "瞬息之间，福恩消失了。他冲破烟雾与混沌，攥紧拳头直取卢修斯的下颌。"
        translate None lucius_fight_0441:
            show bg throne with hpunch
            "但这远远不够。卢修斯轻易接住了他的拳头，并紧紧攥住。"
        translate None lucius_fight_0442:
            "随着卢修斯越攥越紧，福恩的尖啸划破长空。我和艾米尔同时跃起，冲上前去相助。"
        translate None lucius_fight_0443:
            "卢修斯用空着的那只手找到矛状光束，将它抵在福恩的喉咙上，嘴角浮现出一抹狞笑。"
        translate None lucius_fight_0444:
            f c wsur "等…等等，别—"
        translate None lucius_fight_0445:
            play sound "sounds/sfx/fallonground3.ogg"
        translate None lucius_fight_0446:
            show bg throne with vpunch
            "我一个扫堂腿将他绊倒。福恩得以挣脱，踉跄着后退跌作一团。"
        translate None lucius_fight_0447:
            luc hur "你这小—！"
        translate None lucius_fight_0448:
            play sound "sounds/sfx/stab2.ogg"
        translate None lucius_fight_0449:
            show bg throne with hpunch
            rs c whur "啊…"
        translate None lucius_fight_0450:
            "根本没有时间移动。甚至连思考的时间都没有。"
        translate None lucius_fight_0451:
            "长矛刺入我的大腿，深深扎进肉里。疼痛瞬间扩散至全身，我的大脑一片空白。"
        translate None lucius_fight_0452:
            show black with eye_shut
            "我的双腿突然发软，跌倒在卢修斯身旁。从指尖到脚趾，一阵电击般的战栗席卷全身感官。我紧闭双眼，试图忍受这突如其来的剧痛。"
        translate None lucius_fight_0453:
            "刀刃被强行从我腿上拔出，伤口几乎立刻喷涌出鲜血。"
        translate None lucius_fight_0454:
            "艾米尔迅速冲上前去，将双掌压在伤口上施压。他怒视着卢修斯，后者看起来随时都可能跳起来准备第二轮较量。"
        translate None lucius_fight_0455:
            scene bg throne with eye_open
            f c whur "雷恩！"
        translate None lucius_fight_0456:
            "福恩的尖叫刺穿了房间里的紧张气氛。那声音充满痛苦，充满憎恨。在他通常柔和的语调位置上爆发出一种力量，让我深感震撼。"
        show smoke onlayer middle:
            xpan 0
            linear 20.0 xpan 360
            repeat
        with dissolve
        translate None lucius_fight_0457:
            play sfx4 "sounds/sfx/fires.ogg" fadein 2.0
            "窗户剧烈震颤。黄橙色的火焰在我们周围跳动飞舞。 "
        translate None lucius_fight_0457b:
            "蕴含着福恩的怒火，烈焰将我们三人团团围住，每分每秒都变得更加猛烈。火舌扭曲盘旋着冲天而起，形成急速旋转的火柱。透过火墙，我只能勉强辨认出福恩的身影。"
        translate None lucius_fight_0458:
            f "不…不，不要，雷恩！我停不下来！"
        translate None lucius_fight_0459:
            "火焰正迅速吞噬着他的身躯，但我仍能勉强看清他的脸庞。泪水如河流般顺着他的面颊滚滚而下。"
        translate None lucius_fight_0460:
            f "我控制不住…我无法控制它…雷恩，我该怎么办？！"
        translate None lucius_fight_0461:
            rs c wsad "...."
        translate None lucius_fight_0462:
            rs "带上维拉斯赶紧离开这里，越快越好。"
        translate None lucius_fight_0463:
            f "我不会丢下你！你会死的！"
        translate None lucius_fight_0464:
            rs "......"
        translate None lucius_fight_0465:
            rs c wsmi "福恩，我爱你。"
        translate None lucius_fight_0466:
            f "我—"
        translate None lucius_fight_0467:
            "饥饿的火焰在我四周腾跃而起。烟雾开始充斥我的视野，我感到头脑逐渐发晕。最后，福恩的身影终于被旋转的火浪吞没。"
        translate None lucius_fight_0468:
            "这与我生平见过的任何火焰都不同。它更…愤怒。更狂暴。势不可挡。"
        translate None lucius_fight_0469:
            "求你了，福恩。离开这里。我会完成这个。"

        window hide dissolve

        play movie "images/BGs/fire.webm" loop
        show movie with dissolve
        #scene gallery_147 with dissolve
        window show dissolve


    if cyne_route:
        translate None lucius_fight_0470:
            "艾米尔和我重重摔在地上，冲击力震得骨头咯咯作响，但与踉跄后退的卢修斯散发的狠毒怒火相比，这点疼痛根本不算什么…他后退是为了躲避…"
        translate None lucius_fight_0471:
            "…躲避什么？"
        translate None lucius_fight_0472:
            "在他身后，他自己的一件武器半截插在石头里，微微嵌了进去。他的目光转向赛恩，后者正痛苦地甩着手。"
        translate None lucius_fight_0473:
            c c wang "操…那是给福恩的，混蛋。"
        translate None lucius_fight_0474:
            "他的手掌被烫伤了，遍布着赤红的嫩肉。他捡起了福恩掉落的那个长矛…"


    if leos_route:
        translate None lucius_fight_0475:
            "艾米尔与我重重砸向地面，力道大得能感到骨头咔咔作响，但比起不远处蜷缩在地的卢修斯身上散发出的愤怒与苦痛，这点疼痛算不了什么。"
        translate None lucius_fight_0476:
            "莱奥斯站在他上方，手中兵器已然出鞘。他轻松一脚踢中了卢修斯的腿弯。"
        translate None lucius_fight_0477:
            "不等他喘息，莱奥斯猛扑过去，但卢修斯侧身翻滚迅速跃起。"
        translate None lucius_fight_0478:
            luc nang "我打赌你觉得这招很聪明。"
        translate None lucius_fight_0479:
            "面具已然消逝。他的声音化作一声低吼，笑意从脸上抹去。"
        translate None lucius_fight_0480:
            l c wsmu "我其实挺佩服自己的，多谢你的关注。"
        translate None lucius_fight_0481:
            luc "..."
        translate None lucius_fight_0482:
            luc "我想我已经受够这些把戏了。是时候让你求饶了。"
        translate None lucius_fight_0483:
            l "我？祝你好运吧。我可不太擅长乞讨。"
        translate None lucius_fight_0484:
            luc "真的？那就让我们看看你对这事能说点什么。"
            #play sound "sounds/sfx/whoosh2.ogg"
        translate None lucius_fight_0485:
            "他从地上抄起武器—那是在他摔倒时被丢弃在一旁的—手腕一抖，便朝我呼啸袭来。"
        translate None lucius_fight_0486:
            "根本来不及细想。我抬起双臂护住面部，准备承受一次始终未至的冲击。"
        translate None lucius_fight_0487:
            play sound "sounds/sfx/stab3.ogg"
        translate None lucius_fight_0488:
            show bg with hpunch
            ae hur "呃…"
        translate None lucius_fight_0489:
            rs c wsur "艾米尔！？"
        translate None lucius_fight_0490:
            ae "…这个世界就靠你了，雷恩。不要动摇。"
        translate None lucius_fight_0491:
            rs "等等…！"
        translate None lucius_fight_0492:
            "他在我面前颓然倒地，卢修斯紧扼他喉咙留下的红印仍清晰可见。"
        translate None lucius_fight_0493:
            luc "永远这么愚蠢…你竟为这个小子赌上性命？你从来就不配当言者。"
        translate None lucius_fight_0494:
            "我几乎以为卢修斯会朝艾米尔的方向啐一口。我跌倒在地，终于在莱奥斯冲向卢修斯并重新挑起他们之间的战斗时，设法把艾米尔翻了过来。他手腕一抖，长枪便回到了他手中，从艾米尔的身体里撕扯而出。"
        translate None lucius_fight_0495:
            "我把头贴在他胸前 - 他还有呼吸。"
        translate None lucius_fight_0496:
            "离我不远处，莱奥斯和卢修斯正面交锋，刀刃相击迸发出火花。"
        translate None lucius_fight_0497:
            "我们赢不了的…对吧？"
        translate None lucius_fight_0498:
            "我们做再多也于事无补…无论是艾米尔还是维拉斯都比我们强大得多，所以…我们该怎么才能赢呢？！"
        translate None lucius_fight_0499:
            "……别犹豫，雷恩。"
        translate None lucius_fight_0500:
            "带着这些念头，我从地上站起来，把艾米尔留在身后。莱奥斯重重摔在大理石地板上，一路滑到我的脚边。"
        translate None lucius_fight_0501:
            rs c wsur "莱奥斯！"
        translate None lucius_fight_0502:
            l c whur "呃…我没事，别担心…"
        translate None lucius_fight_0503:
            "他说他没事，但明显可以看出疼痛开始占据上风。当我把他拽到我身边时，他咬紧了牙关。"
        translate None lucius_fight_0504:
            "他的身体布满割伤和淤青，我能看出他已筋疲力尽。"
        translate None lucius_fight_0505:
            luc nsmi "现在只剩我们两个了。多美妙啊？"
        translate None lucius_fight_0506:
            l "我有个计划。"
        translate None lucius_fight_0507:
            rs c wsad "什么都可以。"
        translate None lucius_fight_0508:
            l "…你不会喜欢的。"
        translate None lucius_fight_0509:
            rs "..."
        translate None lucius_fight_0510:
            l "看那边。"
        translate None lucius_fight_0511:
            "他谨慎地点点头，我注意到我们头顶的枝形吊灯。就是那盏当维拉斯被钉在墙上时剧烈摇晃过的吊灯。"
        translate None lucius_fight_0512:
            l c wsmu "我们可不想发生什么意外，对吧？它已经太老旧了，随时都可能倒塌。"
        translate None lucius_fight_0513:
            l "所以我们最好在它伤害任何人之前把它处理掉。"
        translate None lucius_fight_0514:
            rs c wsur "如何做？"
        translate None lucius_fight_0515:
            l "我会引他下水并将他困在那里，再诱使他投矛刺我。这会很痛，但你必须捡起矛用尽全力投回去。"
        translate None lucius_fight_0516:
            rs "….要是你也被困在里面怎么办？"
        translate None lucius_fight_0517:
            l "好吧，这不会很愉快的。"
        translate None lucius_fight_0518:
            rs c wsad "….这是个愚蠢的计划。"
        translate None lucius_fight_0519:
            l "这么看来，我大概是和你待得太久了。"
        translate None lucius_fight_0520:
            "我不禁皱起眉头。我竭尽全力想反驳这个提议，但脑海中却浮现不出任何替代方案。"
        translate None lucius_fight_0521:
            rs "…好吧，好吧，但…你最好小心点，明白吗？"
        translate None lucius_fight_0522:
            l "我什么时候不友善了？"
        translate None lucius_fight_0523:
            luc "最后的道别结束了吗？别担心，莱奥斯，我会允许你做到这种程度。"
        translate None lucius_fight_0524:
            "莱奥斯大步向前，站在垂挂的枝形吊灯下，将匕首抛向空中又稳稳接住。"
        translate None lucius_fight_0525:
            l "我？该告别的人不该是你吗？哦等等—我想起来了，你根本没人在等你说再见啊。"
        translate None lucius_fight_0526:
            l "多么悲伤。"
        translate None lucius_fight_0527:
            "他明显咬紧了牙关冲过来。他们的打斗充满原始野性，卢修斯所有虚伪的魅力都消失了，取而代之的是燃烧的恨意。"
        translate None lucius_fight_0528:
            "莱奥斯躲开他的打击跳着舞走开，继续挑衅他的怒火，直到他怒气几乎要爆发。"
        translate None lucius_fight_0529:
            luc nang "眼睁睁看着你爱的人在你面前死去！"
        play sound "sounds/sfx/fallonground3.ogg"
        translate None lucius_fight_0530:
            show bg throne with vpunch
            "我扑倒在地，长矛堪堪擦过我的身体。"
        translate None lucius_fight_0531:
            l c wpis "雷恩，现在！"
        translate None lucius_fight_0532:
            show raen nw dim ang cloak with dissolve
            "仅仅触碰那把武器就灼伤了我的手，痛楚几乎难以想象，但我依然坚定地站立着。我将它对准枝形吊灯。"


    if cyne_route:
        translate None lucius_fight_0533:
            "我拼命想平复呼吸稳定心神，但缺氧让我头晕目眩，只能发出微弱破碎的喘息。" # check if fawn route too
        translate None lucius_fight_0533b:
            luc nang "你竟敢…"  # Need to voice map this with line 775
        translate None lucius_fight_0533c:
            c "别碰我的未婚妻。"
        translate None lucius_fight_0534:
            luc nsmir "啊哈哈哈！在过家家是吗？"
        translate None lucius_fight_0535:
            c c wsmi "总比扮演疯癫的反派强。"
        translate None lucius_fight_0536:
            "突如其来的对峙让我惊讶地瞪大了眼睛。赛恩脸上挂着狡猾的笑容，而卢修斯的笑容却已消失无踪。"
        translate None lucius_fight_0537:
            "愤怒与怨恨在空气中涌动，直指赛恩。那情绪强烈到几乎肉眼可见。"
        translate None lucius_fight_0538:
            luc nneu"我想我已经受够你了，小鬼。"
        translate None lucius_fight_0539:
            play sound "sounds/sfx/walkinghall2.ogg" fadeout 0.7
            "脚步，脚步，脚步。他的脚步声在近乎至寂的房间中回荡。赛恩向前冲去，直扑卢修斯，但他已做好准备。他轻描淡写地像拂开毫无重量的东西般把他打到一旁。"
        translate None lucius_fight_0540:
            play sound "sounds/sfx/kick2.ogg" fadeout 0.7
            show bg throne with vpunch
            c c wang "呃！"
        translate None lucius_fight_0541:
            "他砰地一声重重撞上墙壁，然后略微瘫软下来。"
        translate None lucius_fight_0542:
            rs c wsur "赛恩！"
        translate None lucius_fight_0543:
            v ouc "呜…他…他还活着…集中精神…"
        translate None lucius_fight_0544:
            luc nsmir "然后就剩两个了。"
        translate None lucius_fight_0545:
            rs c wang "…你！你甚至都不担心自己的儿子吗？！你怎么配当母亲？！"
        translate None lucius_fight_0546:
            lv smi "他选择了输家的一方。我以为我教得更好。"
        translate None lucius_fight_0547:
            luc "如此沉着冷静的女人。"
        translate None lucius_fight_0548:
            ae "…恶心。"
        translate None lucius_fight_0549:
            "卢修斯单手挺着长矛冲来，直接刺向我。我及时跪倒在地才躲过。"
        translate None lucius_fight_0550:
            "……但对他的下一击根本来不及反应。连思考的时间都没有。"
        translate None lucius_fight_0551:
            play sound "sounds/sfx/stab3.ogg" fadeout 0.7
            show bloody with hpunch
            "长矛刺入我的大腿，深深扎进肉里。疼痛瞬间扩散至全身，我的大脑一片空白。"
        translate None lucius_fight_0552:
            rs c whur "啊！"
        translate None lucius_fight_0553:
            "如果我当时不是已经在地上了，这冲击会让我瞬间跪倒在地。从指尖到脚趾，一阵震颤席卷了我所有的感官。"
        translate None lucius_fight_0554:
            "刀刃被强行从我腿上拔出，伤口几乎立刻喷涌出鲜血。"
        translate None lucius_fight_0555:
            "艾米尔冲过去将双掌压在伤口上施压。他怒视着卢修斯，后者看起来随时可能再次发动攻击。"
        translate None lucius_fight_0556:
            c "雷…雷恩…!"
        translate None lucius_fight_0557:
            "赛恩的尖叫声穿透房间，他终于恢复了意识。那声音充满灼热的恨意，却也饱含巨大的忧虑。"
        translate None lucius_fight_0558:
            rs "赛恩…快去找其他人…快点…！"
        translate None lucius_fight_0559:
            "赛恩挣扎着想要站起来，一道血线从他头部流淌下来。他靠在墙上寻求支撑，但看样子他哪儿也去不了。"
        translate None lucius_fight_0560:
            c c wsad "我不能…我不会丢下你…"
        translate None lucius_fight_0561:
            ae ang "如果你想让他活命就必须这么做！"
        translate None lucius_fight_0562:
            "赛恩泪眼朦胧地低头看了眼地面，转身逃出了房间。"
        translate None lucius_fight_0563:
            "当卢修斯居高临下地俯视我时，我腿上的剧痛难以忍受，但眼睁睁看着赛恩离开，不知道是否还能再见，这种痛苦更甚。"
        translate None lucius_fight_0564:
            lv neu "再次逃跑。"


    if cyne_route or fawn_route:
        translate None lucius_fight_0565:
            luc smi "…多么温馨的时刻啊。啊，年轻人的爱情以及诸如此类的美好。"
        translate None lucius_fight_0566:
            rs c wang "...."
        translate None lucius_fight_0567:
            luc "艾米尔也曾是这样，很久以前。那次结局如何来着？"
        translate None lucius_fight_0568:
            ae ang "闭上你的嘴。"
        translate None lucius_fight_0569:
            ae "你没资格谈论卡斯皮安。"


        if cyne_route:
            translate None lucius_fight_0570:
                luc nsur "还是个敏感话题？"# vooice map

        if fawn_route:
            translate None lucius_fight_0571:
                luc "还是个敏感话题？" # vooice map

    if fawn_route:
        translate None lucius_fight_0572:
            "他的声音仍如从前般充满狂妄自信，但表情却出卖了他。双眼因痛苦而抽搐，声音几乎可称为咆哮，时断时续。"
        translate None lucius_fight_0573:
            luc neu "呵，看来这就是我们三人的结局了？多亏那小子，咱们都得交代在这儿了。"
        translate None lucius_fight_0574:
            luc "知道自己所爱之人将成为你的劫数，这感觉如何？世事总是如此相似。"
        translate None lucius_fight_0575:
            rs c wsad"..."
        translate None lucius_fight_0576:
            rs "这不是他的错。他什么都没做错。"
        translate None lucius_fight_0577:
            rs c wsmi"其实我该感谢他。他给了我机会去做我命中注定该做的事。"
        translate None lucius_fight_0578:
            luc "哦？你说什么？"
        translate None lucius_fight_0579: # VOICE MAP
            rs "成为言者，守护我的人民。"
        translate None lucius_fight_0580:
            luc smi "啊哈哈哈！好吧，看来我只能认输了。也许下次运气会好些。" # voice map with same convo below
        translate None lucius_fight_0581:
            ae "不会再有下次了，怪物。" # voice map with same convo below
        translate None lucius_fight_0582:
            luc "哦，是吗？" # voice map with same convo below
        translate None lucius_fight_0583:
            luc "好吧，或许是对你而言。" # voice map with same convo below
        translate None lucius_fight_0584:
            ae "……什么意思？" # voice map with same convo below
        translate None lucius_fight_0585:
            luc "怎么，没人告诉你吗？言者的灵魂不过是神明转世。" # voice map with same convo below
        translate None lucius_fight_0586:
            rs c wsur "什么…？" # voice map with same convo below
        translate None lucius_fight_0587:
            luc "所以，既然知道这是我第二次转生为神，{b}而且{/b}我还是言者…我觉得再试一次的机会很大呢。" # voice map with same convo below
        translate None lucius_fight_0588:
            rs "…所以我们才能与他们对话…" # voice map with same convo below
        translate None lucius_fight_0589:
            luc "中了！也许你终究没那么迟钝…" # voice map with same convo below
        translate None lucius_fight_0590:
            ae ann "我们的…能力只是先前力量的微弱体现？"# voice map with same convo below
        translate None lucius_fight_0591:
            luc "你可真是个好徒弟啊。就当这是对你昔日能力的惊鸿一瞥吧。"# voice map with same convo below
        translate None lucius_fight_0592:
            luc "要是运气好的话，总有一天我的灵魂也会回来。我可不介意再尝试当一回言者。"# voice map with same convo below
        translate None lucius_fight_0593:
            rs c wang"你活该烂掉…"# voice map with same convo below
        translate None lucius_fight_0594:
            luc "我已经有具尸体在土里腐烂了。再多一具又如何？"# voice map with same convo below

        hide movie with dissolve
        stop movie
        #window hide dissolve

        #scene bg throne with dissolve
        #window show dissolve
        translate None lucius_fight_0595:
            "房间里充满了火焰。"
        translate None lucius_fight_0596:
            show fawn nw dim hur cloak with dissolve
            f "求你，求你…求你，就听我这一次！就这一次！"
        translate None lucius_fight_0597:
            "福恩向火焰举起双手，倾尽全力祈求着。然而这火焰风暴拒绝听从，反而变得越来越猛烈。"
        translate None lucius_fight_0598:
            "他的眼睛刺痛，嘴巴发干。烟雾已开始充斥他的肺部。"
        translate None lucius_fight_0599:
            "但这无关紧要，因为他感受到的痛苦比起内心的痛楚根本不值一提。"
        translate None lucius_fight_0600:
            fmn "如果这里的情况都这么糟…雷恩正在受苦…而我却无能为力…"

        play sound "sounds/sfx/whoosh1.ogg"
        translate None lucius_fight_0601:
            scene bg cliffspire fire with flash
            u "恶魔崽子！你杀了他们所有人！你把他们都活活烧死了！"
        translate None lucius_fight_0602:
            u "这些火都指向你！你这个该死的小恶魔…你谋划这件事多久了？！"
        translate None lucius_fight_0603:
            u "甚至丧心病狂到杀害自己的父亲…"

        play sound "sounds/sfx/whoosh1.ogg"

        scene bg treefire
        show raen n dim wor
        with flash
        translate None lucius_fight_0604:
            rs "福恩？福恩，求你了…我们得走了！这里不安全他—"
        translate None lucius_fight_0605:
            fmn "不…不…又开始重演了…我会再次失去一切的…!"

        hide raen

        show bg throne
        show fawn nw dim sad cloak at centerleft
        show morwen n dim sur cloak at centerright
        show sylvir n dim ann at farright
        show elliot n dim neu at farleft
        with hpunch
        translate None lucius_fight_0606:
            mor "福恩！发生什么事了？！"
        translate None lucius_fight_0607:
            f "我..我做不到…"
        translate None lucius_fight_0608:
            f "他们在那里面…雷恩在那里面！"
        translate None lucius_fight_0609:
            s "…这是我从未见过的景象。那热度…难以估量。"
        translate None lucius_fight_0610:
            el "......."
        translate None lucius_fight_0611:
            el "福恩。"
        translate None lucius_fight_0612:
            f "我不是故意的—我控制不住这个..！"
        translate None lucius_fight_0613:
            el "冷静。你必须现在就停手。否则他们会死。"
        translate None lucius_fight_0614:
            f "它不听我的…我无能为力…！"
        translate None lucius_fight_0615:
            el "....."
        translate None lucius_fight_0616:
            el "我教你。快过来。"
        translate None lucius_fight_0617:
            "莫温冲向维拉斯身旁，但他摇了摇头。"
        translate None lucius_fight_0618:
            v sad "别碰。接触它你也会受伤。"
        translate None lucius_fight_0619:
            s "你不能一直待在上面。"
        translate None lucius_fight_0620:
            v "我担心拔出来会更痛。请让老人家先鼓足勇气吧。"

        window hide dissolve
        jump caspianillranlucius2


    if cyne_route:
        translate None lucius_fight_0621:
            "他的声音里依然充满了一如既往的狂妄自信。"
        translate None lucius_fight_0622:
            "我闭上眼睛，因疼痛而畏缩。艾米尔仍跪在我身旁，双手覆在我的伤口上，但我的裤子早已被血浸透。"
        translate None lucius_fight_0623:
            "卢修斯转着圈，无忧无虑地自得其乐。赛恩的母亲懒洋洋地靠在王座上，仿佛身处自己家中般自在。"
        translate None lucius_fight_0624:
            luc "我还以为会有点竞争呢。这就是你们能集结的全部实力？"
        translate None lucius_fight_0625:
            rs "...."
        translate None lucius_fight_0626:
            "趁他背对着我们，我迅速把艾米尔的耳朵拉到嘴边。"
        translate None lucius_fight_0627:
            show raen nw dim cloak hur at slightright
            show ds n dim ang at slightleft
            with dissolve
            rs "我有个主意…"
        translate None lucius_fight_0628:
            ae "…我不喜欢这计划听起来的感觉。"
        translate None lucius_fight_0629:
            rs "去拿赛恩扔掉的刀。虽然会很痛…但可能是唯一的机会。"
        translate None lucius_fight_0630:
            ae "你想让我用在他身上？"
        translate None lucius_fight_0631:
            show raen nw dim smi with dis
            "我忍着疼痛对他微笑，意识到自己即将说出的话有多疯狂。"
        translate None lucius_fight_0632:
            show ds n dim sur with dis
            rs "我要你捅我。"
        translate None lucius_fight_0633:
            luc nsmir"说悄悄话呐？这下有意思了。来吧。"
        translate None lucius_fight_0634:
            ae "什么？！"
        translate None lucius_fight_0635:
            rs "同时将他拉近。我们俩的速度和力量都不足以伤害他。这是我唯一能想到击败他的方法。"
        translate None lucius_fight_0636:
            ae "……你疯了。彻底疯了。这有千百种出错的可能—你还无法完全控制它！"
        translate None lucius_fight_0637:
            rs "......"
        translate None lucius_fight_0638:
            ae "...."
        translate None lucius_fight_0639:
            show ds n ann with dis
            ae "…好吧。好，我来做。"


    if leos_route or cyne_route:
        translate None lucius_fight_0640:
            rs "你知道吗，我不禁为你感到惋惜。" # make sure Raen sprite showing on screen for this bit
        translate None lucius_fight_0640b:
            luc "哦？"
        translate None lucius_fight_0641: # voice map to lucius_fight_0671
            rs "你给了我一个你永远无法做到的机会。"
        translate None lucius_fight_0642: #voice map to lucius_fight_0672
            rs "成为言者，保护我的子民。"


    if leos_route:
        translate None lucius_fight_0643:
            luc nang "你？当言者？" # voice map
        translate None lucius_fight_0644:
            "他嘲弄我，莱奥斯抽出鞭子缠住卢修斯的脚踝，把他拖倒在地。"
        translate None lucius_fight_0645:
            luc "呃！"



    if cyne_route:
        window hide dissolve

        scene bg throneno with Fade(1.0, 1.0, 1.0):
            xpos 0.72 ypos 1.14 xanchor 0.5 yanchor 1.0 zoom 1.64
            linear 35.0 xpos 0.25 ypos 1.14 xanchor 0.5 yanchor 1.0 zoom 1.64


        translate None lucius_fight_0646:
            play sound "sounds/sfx/runningstreet.ogg"
            cmn "求求你，求求你，求求你了…!"
        translate None lucius_fight_0647:
            cmn "等我回来时你一定要活着啊！"
        translate None lucius_fight_0648:
            "赛恩迈开双腿拼命冲出房间。周遭天旋地转，头疼欲裂仿佛要炸开。"
        translate None lucius_fight_0649:
            "穿过第一道门，沿着漆黑的走廊奔跑，直到闯入另一个房间。这里比之前空荡许多—刚被清空了所有居住者。"
        translate None lucius_fight_0650:
            c c wsad "莫温，我需要你的帮助！"
        translate None lucius_fight_0651:
            mor c sad "赛恩？怎么回事？！你发生什么事了？"
        translate None lucius_fight_0652:
            c "是…是…是卢修斯！"
        translate None lucius_fight_0653:
            el gla "不必多言。莫温，西尔维尔，跟我来。"
        translate None lucius_fight_0654:
            "这群人快速穿过暗下来的房间，小心翼翼地避免绊到横陈在大理石地面上那些了无生气的躯体。"
        translate None lucius_fight_0655:
            s thi "那里发生了什么？"
        translate None lucius_fight_0656:
            c "这简直是一场屠杀。他只是在戏耍我们，然而…维拉斯已经失去战斗力，福恩也…"
        translate None lucius_fight_0657:
            c "福恩失去意识了，他需要帮助。"
        translate None lucius_fight_0658:
            mor c ang "他会得到帮助的，别担心。"

        window hide dissolve

        scene black with swipe
        scene bg throne with swipe
        window show dissolve
        translate None lucius_fight_0659:
            "赛恩与三位神突然冲回房间，却看到了意料之外的景象。"
        translate None lucius_fight_0660:
            play sound "sounds/sfx/stab3.ogg"
        translate None lucius_fight_0661:
            "电光火石间，艾米尔将雷恩腹部刺了个对穿。"
        translate None lucius_fight_0662:
            c c wsur "雷恩！"
        translate None lucius_fight_0663:
            c "你干什么？！"
        translate None lucius_fight_0664:
            "他控制不住自己。眼前的景象仿佛不真实—只要再靠近些，一切就会化为幻影。"
        translate None lucius_fight_0665:
            "他想跑到雷恩身边，想证明这不是真的，但莫温紧紧抓着他的手臂不肯松开。"
        translate None lucius_fight_0666:
            c c wang "放开我！放手！他需要我！"
        translate None lucius_fight_0667:
            el ang "我就知道我们不能相信他！"
        translate None lucius_fight_0668:
            mor c ang "……等等。"
        translate None lucius_fight_0669:
            el "等什么？！"
        translate None lucius_fight_0670:
            s ang "……你听到她说的了。等着。"

        window hide dissolve

        scene bg throne with Fade(1.0, 1.0, 1.0)
        window show dissolve
        translate None lucius_fight_0671: # voice map
            rs c wsmi "你给了我一个你永远无法做到的机会。"
        translate None lucius_fight_0672: # voice map
            rs "成为言者，保护我的子民。"
        translate None lucius_fight_0673:
            luc nsmi "你？当言者？" # voice map
        translate None lucius_fight_0674:
            "他对我嗤之以鼻，但我显然引起了他的注意。艾米尔站起身迅速抓起那把散落的刀，将它对准了卢修斯。"
        translate None lucius_fight_0675:
            "我能看见他因疼痛而畏缩，烈焰灼烧着他的掌心，但他仍稳稳握住。"
        translate None lucius_fight_0676:
            ae ang "你的意图显而易见—你想戏弄我们，就像一只猫在吃掉老鼠前玩乐那样。好吧，去见鬼吧。"
        translate None lucius_fight_0677:
            ae "跟我打一架，光明正大地。"
        translate None lucius_fight_0678:
            luc "跟你打？你以为你能在我面前撑得下去？"
        translate None lucius_fight_0679:
            ae "我知道我能。"
        translate None lucius_fight_0680:
            luc nneu "哈，那让我们瞧瞧。"
        translate None lucius_fight_0681:
            "我捂着疼痛的腿，看着卢修斯慢慢走向艾米尔。他看起来依旧从容不迫，就好像知道我们奈何不了他一样。"
        translate None lucius_fight_0682:
            "他没错。任何普通人都不可能有机会。"
        translate None lucius_fight_0683:
            "…但我必须做到。"
        translate None lucius_fight_0684:
            play sound "sounds/sfx/swing2.ogg"
        translate None lucius_fight_0685:
            show bg throne with vpunch
            "卢修斯猛冲向前，剑锋上挑。艾米尔抬臂防守，勉强格挡了这一击。"
        translate None lucius_fight_0686:
            "他眉头紧锁，压力让汗水从他的额头滴落。"
        translate None lucius_fight_0687:
            "他向后退了一步，卢修斯也跟着退开，这让艾米尔得以绕到我身后站定。"
        translate None lucius_fight_0688:
            ae hur "就这…你就这点本事？"
        translate None lucius_fight_0689:
            luc "哼。"
        translate None lucius_fight_0690:
            "中招了！"
        translate None lucius_fight_0691:
            "卢修斯再次冲上前来，但艾米尔更快。他已站在我身前，在卢修斯赶到之前先一步来到我身边。"
        translate None lucius_fight_0692:
            "当他凝视我的双眼时，我几乎能听见他的道歉。他举起刀刃，以迅疾之势猛然挥下……"
        play sound "sounds/sfx/stab3.ogg"
        translate None lucius_fight_0693: # RAEN SCREAM
            show bloody with hpunch
            "我眼前一片血红。浑身都疼。我不敢低头看自己，因为只要看一眼，肯定会晕过去。"
        translate None lucius_fight_0694:
            "但我能感觉到它。血液正在渗出，浸透了我的衣服。"
        translate None lucius_fight_0695:
            "对不起，赛恩。我弄坏了你买给我的好东西。"
        translate None lucius_fight_0696: #voice mapped
            c c wsur "雷恩！"
        translate None lucius_fight_0697: #voice mapped
            c "你干什么？！"
        translate None lucius_fight_0698: #voice mapped
            c c wang "放开我！放手！他需要我！"
        translate None lucius_fight_0699:
            el ang "我就知道我们不能相信他！"
        translate None lucius_fight_0700:
            mor c ang "……等等。"
        translate None lucius_fight_0701:
            el "等什么？！"
        translate None lucius_fight_0702:
            s ang "……你听到她说的了。等着。"
        translate None lucius_fight_0703:
            luc "真是意外。临阵倒戈？看来我终究没教错你，艾米尔。"
        translate None lucius_fight_0704:
            luc nsmir "可悲的是，现在为时已晚。"
        translate None lucius_fight_0705:
            "一步，两步，三步，他欺身上前压住艾米尔，就跨在我的躯体上方。"
        translate None lucius_fight_0706:
            "视线模糊不清，唯有痛觉清晰可辨。这就是我全部的存在感。"
        translate None lucius_fight_0707:
            "不…不行，我必须这么做..！"
        translate None lucius_fight_0708:
            "在我上方，卢修斯与艾米尔剑刃相击，同时用目光凶狠地瞪着对方。"
        translate None lucius_fight_0709:
            luc nang "你永远不会有什么出息。你并不比我好到哪里去。"
        translate None lucius_fight_0710:
            ae "…也许你是对的，但你不必留在这里等结果揭晓。"
        translate None lucius_fight_0711:
            "他使劲推搡着他，但这远远不够—永远都不够。对方的力气大得惊人—艾米尔能做到这种程度，卢修斯必定是手下留情了。"
        translate None lucius_fight_0712:
            "我将目光转回赛恩。他正向我伸出手来，眼中含泪，被莫温搀扶着。"
        translate None lucius_fight_0713:
            "但照这样下去…"
        translate None lucius_fight_0714:
            "埃利奥特和西尔维尔挤开她冲向维拉斯。卢修斯看见了他们，却完全被艾米尔吸引了注意力。其他人仿佛根本不存在。"
        translate None lucius_fight_0715: #voice map
            v ouc "别碰。接触它你也会受伤。"
        translate None lucius_fight_0716:
            s thi "你不能一直待在上面。"
        translate None lucius_fight_0717: #voice map
            v "我担心拔出来会更痛。请让老人家先鼓足勇气吧。"
        translate None lucius_fight_0718:
            "腿上的剧痛丝毫未减，但机不可失。"
        play sound "sounds/sfx/kick2.ogg"
        translate None lucius_fight_0719:
            show bg throne with hpunch
            "我猛地一记扫堂腿攻向卢修斯下盘。"

        window hide dissolve

        #scene gallery_114 with dissolve
        window show dissolve
        translate None lucius_fight_0720:
            luc "你这小—"
        translate None lucius_fight_0721:
            "他试图站起来，但艾米尔又把他按了回去。我浑身的疼痛都在哀求我不要再动，但那不是我能选的。"
        translate None lucius_fight_0722:
            "我紧紧抓住他的双臂。"
        translate None lucius_fight_0723:
            "求求你，一定要成功啊。就像之前和艾米尔那样…求你了！"
        translate None lucius_fight_0724:
            "我等待着。一秒，两秒，数秒流转恍若永恒。"
        translate None lucius_fight_0725:
            "……纹丝不动。卢修斯居高临下冲我狞笑，全身重量压在我腿上，灼烧般的痛楚瞬间贯穿全身。"
        translate None lucius_fight_0726:
            luc "这里的计划到底是什么？要把我挤死吗？"
        translate None lucius_fight_0727:
            "……结束了吧…？"
        translate None lucius_fight_0728:
            "我的视力逐渐模糊，但我仍将目光投向赛恩。"
        translate None lucius_fight_0729:
            "他眼里噙满泪水，虽然我觉得他正在尖叫，但我却听不见他的声音。"

        window hide dissolve
        jump caspianillranlucius2

label caspianillranlucius2:
    scene bg throneno
    show caspian n dim ang at slightleft
    show illran n dim armsdown ang at slightright
    with Fade(1.0, 1.0, 1.0)
    window show dissolve

    if fawn_route:
        translate None lucius_fight_0730:
            "卡斯皮安矮身躲过直冲下颌的拳头，险险避过。他疾步后撤，成功吸引了莱奥斯和赛恩的注意。"


    if cyne_route:
        translate None lucius_fight_0731:
            "卡斯皮安矮身躲过直冲下颌的拳头，险险避过。他疾步后撤，将莱奥斯的注意力重新引回自己身上。"


    if leos_route:
        translate None lucius_fight_0732:
            "卡斯皮安迅速蹲下身，拳头擦着他的下巴险险掠过。他快速闪开，将福恩的注意力再次引回自己身上。"

    translate None lucius_fight_0733:
        cas "见鬼，他们怎么就不肯乖乖倒下？！"
    translate None lucius_fight_0734:
        i "因为他甚至一开始就没醒着。老天，就他现在这样我甚至不愿称之为活着—他只是一块听从指令的肉块。"
    translate None lucius_fight_0735:
        cas "就算是肉块也该知道自己的极限吧！"
    translate None lucius_fight_0736:
        "伊尔兰来回踱步，目光死死盯着他的目标。"


    if cyne_route or fawn_route:
        show illran n dim fli with dis
        translate None lucius_fight_0737:
            i "至少当莱奥斯醒来发现自己被我揍得屁滚尿流时，我能看到他那张精彩的脸。"


    if leos_route:
        show illran n dim fli with dis
        translate None lucius_fight_0738:
            i "至少当我们毫发无损地回到队伍时，我可以向莱奥斯炫耀我比他厉害多少。"


    translate None lucius_fight_0739:
        show caspian n dim smi with dis
        cas "啊哈哈，你这家伙真是个活宝。"
    translate None lucius_fight_0740:
        show illran n dim con with dis
        i "别告诉我你不享受这个过程。"
    translate None lucius_fight_0741:
        show caspian n dim sad with dis
        cas "...."
    translate None lucius_fight_0742:
        cas "如果我说自己不害怕，那肯定是撒谎。"


    if cyne_route:
        translate None lucius_fight_0743:
            i "你居然怕这么一根细长的面条，认真的吗？"


    if leos_route:
        translate None lucius_fight_0744:
            i "你是真怵这些废物吗？"


    if fawn_route:
        translate None lucius_fight_0745:
            i "你居然怕这么一根细长的面条，认真的吗？"

    translate None lucius_fight_0746:
        cas "我好怕再也见不到艾米尔。"


    if leos_route or cyne_route:
        translate None lucius_fight_0747:
            "一声尖叫突然划破长空。卡斯皮安和伊尔兰面向众人离去的门扉，对门后发生的事充满恐惧。"


    if fawn_route:
        translate None lucius_fight_0748:
            "宫殿深处突然传来轰鸣。伊尔兰和卡斯皮安同时僵在原地，直直瞪着其他人离开的那扇门。"



    if cyne_route:
        show bg throneno with vpunch
        translate None lucius_fight_0749:
            "随着福恩的离去，同样可能遭遇任何不测。"


    translate None lucius_fight_0750:
        cas "……你爱的人也在里面吗？"
    translate None lucius_fight_0751:
        show illran n dim sad with dis
        i "…..那个对我来说比什么都重要的。"
    translate None lucius_fight_0752:
        cas "那我们最好快点。"
    window hide dissolve
    jump afterillrancaspianscene2


label afterillrancaspianscene2:

    if fawn_route:
        scene black with dissolve
        play movie "images/BGs/fire.webm" loop
        show movie with dissolve
        window show dissolve
        translate None lucius_fight_0753:
            "热浪吞噬了一切。"
        translate None lucius_fight_0754:
            "它不分是非，也不在乎。无论我死，还是卢修斯死，都无所谓。"
        translate None lucius_fight_0755:
            "卢修斯仍躺在地板上，傲慢地冲我们微笑。他可能承认了失败，但这并未阻止他那刻薄的舌头。"
        translate None lucius_fight_0756:
            luc smi "我唯一的愿望…就是在闭眼前看着你们俩咽气。"
        translate None lucius_fight_0757:
            "艾米尔上前踹了他一脚，但很快自己也倒地不起。"
        translate None lucius_fight_0758:
            ae ang "为什么你总是不懂得…什么时候该闭嘴？"
        translate None lucius_fight_0759:
            luc ang"你一直都很软弱。连你的踢腿都软绵绵的。"
        translate None lucius_fight_0760:
            ae "我宁愿软弱地站着靠自己双腿前行，也不愿成为你手中的棋子。"
        translate None lucius_fight_0761:
            luc ang "哈！你还站得住？先瞧瞧你自己吧。"
        translate None lucius_fight_0762:
            ae "…若这就是我赎罪的方式，那便如此吧。"
        translate None lucius_fight_0763:
            luc "看来你还有精力考虑这么多…好啊，试试这个..！"
        translate None lucius_fight_0764:
            "艾米尔高大的身影占据了我的整个视野。"
        translate None lucius_fight_0764b:
            rs c wsur "…什么？"
        translate None lucius_fight_0765:
            "我眨了眨眼，不确定刚刚发生了什么。艾米尔将长枪扔到一边，我瞥见了他布满灼伤的手掌。"
        translate None lucius_fight_0766:
            ae "卑鄙的偷袭…认输后还对孩子下手？"
        translate None lucius_fight_0767:
            luc "想走到…这一步…就别讲什么规矩。"
        translate None lucius_fight_0768:
            "我的视线时明时暗。我大口喘气，却只感到灼烧般的痛楚。"
        translate None lucius_fight_0769:
            "在被黑暗吞噬前，我最后看到的景象是艾米尔匍匐在我身上，用他的身躯为我遮挡烈焰。"
        hide movie with dissolve
        stop movie


        if fawn_badend > fawn_goodend:
            jump fawnbadending

        else:
            pass

        scene bg throne
        show fawn nw dim hur cloak at slightright
        show elliot n dim gla at slightleft
        with Fade(1.0, 1.0, 1.0)
        translate None lucius_fight_0770:
            el "集中注意力！"
        translate None lucius_fight_0771:
            f "我在努力！"
        translate None lucius_fight_0772:
            el "再努力些！把手伸向它。感受指尖的力量。"
        translate None lucius_fight_0773:
            f "什么也没发生！"
        translate None lucius_fight_0774:
            el "是你在掌控局面。火焰听令于你，而不是反过来。"
        translate None lucius_fight_0775:
            f "..."
        translate None lucius_fight_0776:
            el "现在抓住它！"
        translate None lucius_fight_0777:
            f "啊…！"
        translate None lucius_fight_0778:
            show elliot n dim gla with dis
            el "就这么干！别退缩。战胜你的恐惧，证明你能挣脱过去的枷锁！"
        translate None lucius_fight_0779:
            show fawn nw dim sur with dis
            f "这…这下去了！"
        translate None lucius_fight_0780:
            el "...."
        translate None lucius_fight_0781:
            stop sfx4 fadeout 2.0
            "螺旋状的火焰一圈又一圈地盘旋着，每旋转一圈速度就减慢一分。火焰逐渐减弱，仿佛它们害怕福恩。"
        translate None lucius_fight_0782:
            f "雷恩.. 雷恩…！"
        translate None lucius_fight_0783:
            "三具躯体躺在曾经燃烧着火堆的地方。一个巨大身躯覆在另一人身上，为他们挡住了火焰。"
        translate None lucius_fight_0784:
            "快如疾风般，福恩冲向那几具尸体并在旁边急刹停下。他将雷恩从艾米尔身下拉出，紧紧抱住。"
        translate None lucius_fight_0785:
            show fawn nw dim sad with dis
            f "雷恩，醒醒。现在没事了！"
        translate None lucius_fight_0786:
            "没有回应。"
        translate None lucius_fight_0787:
            stop music fadeout 3.0
            f "雷恩…一切都结束了。我们可以…我们可以离开了…！"

        window hide dissolve

    if cyne_route:
        scene bg throne
        show bloody

        with Fade(1.0, 1.0, 1.0)
        window show dissolve
        translate None lucius_fight_0788:
            c c wang "雷恩！"
        translate None lucius_fight_0789:
            "一声突如其来的尖叫划破长空，终于将我的神志唤回。"
        translate None lucius_fight_0790:
            "没错，这事还没完…！"
        translate None lucius_fight_0791:
            "我把卢修斯搂得更紧，专注回想艾米尔之前对我说过的话。集中精神，雷恩… "
        translate None lucius_fight_0792:
            "在我的意识中，几乎能看见将我和卢修斯分隔开的那堵墙。单薄，脆弱。轻易就能打破。"
        translate None lucius_fight_0793:
            luc sur "嗯？！"
        translate None lucius_fight_0794:
            "那遍布我全身的痛楚开始移动，向外扩散，直指卢修斯。他瑟缩了一下，惊讶地低头看着我，随后这惊讶转变成了一抹傲慢的笑容。"
        translate None lucius_fight_0795:
            luc "原来是这样吗？哼，你终究还是有种有趣的能力…我们本可以携手征服这个世界。"


    if leos_route:
        scene bg throne
        with Fade(1.0, 1.0, 1.0)
        window show dissolve
        translate None lucius_fight_0796:
            "那道光束般的刀锋划破长空时，空气中几乎迸发出噼啪声响，精准无误地命中目标。"
        translate None lucius_fight_0797:
            "一切都发生在瞬息之间。"
        stop music
        play sound "sounds/sfx/crash1.ogg"
        translate None lucius_fight_0798:
            scene bg throne at Shake((0.5, 1.0, 0.5, 1.0), 1.0, dist=5)
            "墙壁轰然倒塌，碎石瓦砾四散飞溅。我扑身护住艾米尔，整个房间被白色尘雾笼罩。"
        translate None lucius_fight_0799:
            "接着便是至寂。"
        translate None lucius_fight_0800:
            "不要喊叫或尖叫。没有打斗的声音。什么都没有。"
        translate None lucius_fight_0801:
            "我透过废墟窥视，急切地寻找着莱奥斯的踪迹。"
        translate None lucius_fight_0802:
            rs c wsur "啊..莱奥斯…？"
        translate None lucius_fight_0803:
            play music "sounds/bgm/sad.ogg" fadein 3.0
            l c whur "呃啊…操。我好像撞到脑袋了。"
        translate None lucius_fight_0804:
            "我猛然跃起，朝声音的方向狂奔而去，最终看见了那副光景。卢修斯被压在枝形吊灯下方动弹不得，但他的目光依然追随着我的身影。"
        translate None lucius_fight_0805:
            "莱奥斯躺在不远处的地上，一道血迹从他额头上淌下。"
        translate None lucius_fight_0806:
            "我想冲到他身边，但当卢修斯提高嗓门时，我停了下来。"
        translate None lucius_fight_0807:
            luc nhur "你…你这次也许得手了，但…我还会回来的。"
        translate None lucius_fight_0808:
            rs c wang "不，你们不会有。再也不会有下一次了。"


    if cyne_route:
        translate None lucius_fight_0809:
            luc smi "啊哈哈哈！好吧，看来我只能认输了。也许下次运气会好些。" # voice map with above
        translate None lucius_fight_0810:
            ae ang "不会再有下次了，怪物。"# voice map with above
        translate None lucius_fight_0811:
            luc "哦，是吗？"# voice map with above
        translate None lucius_fight_0812:
            luc "好吧，或许是对你而言。"# voice map with above
        translate None lucius_fight_0813:
            ae "……什么意思？"# voice map with above



    if cyne_route or leos_route:
        translate None lucius_fight_0814:
            luc "怎么，没人告诉你吗？言者的灵魂不过是神明转世。"# voice map with above
        translate None lucius_fight_0815:
            rs c wsur "什么…？"# voice map with above
        translate None lucius_fight_0816:
            luc "所以，既然知道这是我第二次转生为神，{b}而且{/b}我还是言者…我觉得再试一次的机会很大呢。"# voice map with above
        translate None lucius_fight_0817:
            rs "…所以我们才能与他们对话…"# voice map with above
        translate None lucius_fight_0818:
            luc "中了！也许你终究没那么迟钝…"# voice map with above


    if cyne_route:
        translate None lucius_fight_0819:
            ae sur "我们的…能力只是先前力量的微弱体现？"# voice map with above
        translate None lucius_fight_0820:
            luc "你可真是个好徒弟啊。就当这是对你昔日能力的惊鸿一瞥吧。"# voice map with above

    if leos_route:
        translate None lucius_fight_0821:
            rs c wsur "那么…我们的能力只是…先前力量的微弱显现？"
        translate None lucius_fight_0822:
            luc "你本可以成为多么出色的弟子啊。就把它当作是你原本能够达到境界的一丝低语吧。"


    if cyne_route or leos_route:
        translate None lucius_fight_0823:
            luc "要是运气好的话，总有一天我的灵魂也会回来。我可不介意再尝试当一回言者。"
        translate None lucius_fight_0824:
            rs c wang "你活该烂掉…"
        translate None lucius_fight_0825:
            luc "我已经有具尸体在土里腐烂了。再多一具又如何？"


    if cyne_route:
        translate None lucius_fight_0826:
            "突然间我感觉自己又能呼吸了，视线也变得清晰。我眨眨眼，抬头看向站在上方的男人。"
        translate None lucius_fight_0827:
            "他保持着狞笑，但面具已开始碎裂。他的眉毛抽动着，一颗汗珠从脸上滑落。"

        #window hide dissolve

        scene bg throne with vpunch
        #window show dissolve
        translate None lucius_fight_0828:
            "艾米尔上前一步，将卢修斯从我身上踢开。对方仰面翻滚着，大口喘息。"
        translate None lucius_fight_0829:
            luc nhur "你一直都很软弱。连你的踢腿都软绵绵的。"
        translate None lucius_fight_0830:
            ae ang "我宁愿软弱地站着靠自己双腿前行，也不愿成为你手中的棋子。"
        translate None lucius_fight_0831:
            luc "你以为自己…很了不起…？"
        translate None lucius_fight_0832:
            ae "…我会赎我的罪。这话你可说不出口。"
        translate None lucius_fight_0833:
            luc "....."


    if leos_route:
        translate None lucius_fight_0834:
            "他咳嗽着，唾沫四溅，最后终于安静下来。"
        translate None lucius_fight_0835:
            rs c wsur "结束…结束了吗…？"
        translate None lucius_fight_0836:
        #stop music fadeout 2.0
            l c wsmu "你做到了…"
        translate None lucius_fight_0837:
            "我无法阻止泪水从脸上滑落。我踉跄着滑过大理石地板，来到半坐着的莱奥斯身边，紧紧抱住了他。"

        window hide dissolve


    if cyne_route:
        jump cyneafterfight

    if leos_route:
        jump leosafterfight

    if fawn_route:
        jump fawnafterfight

label cyneafterfight:
    translate None lucius_fight_0838:
        "他在地上爬行着，姿势远比之前难看，弯腰捡起了自己的武器。"
    translate None lucius_fight_0839:
        "赛恩猛冲上前，一脚踢飞了他手中的武器。"
    translate None lucius_fight_0840:
        c c wang "你刚刚不是承认失败了吗？"
    translate None lucius_fight_0841:
        luc nsmir "我从没说过自己很公平。"
    translate None lucius_fight_0842:
        c "我也是。"
    translate None lucius_fight_0843:
        play sound "sounds/sfx/punch2.ogg"
    translate None lucius_fight_0844:
        show bg throne with hpunch
        "一记迅捷的直拳轰在脸上，卢修斯瞬间昏死过去。"
    translate None lucius_fight_0845:
        rs c wsur "成…成功了…？"
    translate None lucius_fight_0846:
        ae smi "…干得漂亮，小子。"
    translate None lucius_fight_0847:
        stop music fadeout 2.0
        "突然他单膝跪地，痛苦地喘息。在混战中不知何处受了伤，而他长时间握持长矛的双手已布满深灼的伤痕。"
    translate None lucius_fight_0848:
        c c wsad "雷恩！"
    translate None lucius_fight_0849:
        rs c wsad "赛恩…"
    translate None lucius_fight_0850:
        "赛恩在大理石地面上滑行着，尖叫着在我面前刹住。我缓缓坐起，仍感到骨子里隐隐作痛。"
    translate None lucius_fight_0851:
        "他停下动作，目光在我全身上下搜寻着伤口，不确定是否能够触碰我。"
    translate None lucius_fight_0852:
        play music "sounds/bgm/sad.ogg" fadein 3.0
        rs c wsmi "我没事…真的。"
    translate None lucius_fight_0853:
        c "....."

    #window hide dissolve
    #scene gallery_116 with dissolve
    #window show dissolve

    translate None lucius_fight_0854:
        c c wang"你究竟在想什么？！"
    translate None lucius_fight_0855:
        rs c wsad"嗯…"
    translate None lucius_fight_0856:
        c c wsad"你究竟{i}有没有{/i}在思考？"
    translate None lucius_fight_0857:
        rs "呃…"
    translate None lucius_fight_0858:
        c "你这个愚蠢…愚蠢的男孩…"
    translate None lucius_fight_0859:
        c c wang"你知道自己能活着有多幸运吗？不然我早该杀了你。"
    translate None lucius_fight_0860:
        rs "对不起…"
    translate None lucius_fight_0861:
        c c wsmi "…你做得很好。我为你感到骄傲。"
    translate None lucius_fight_0862:
        rs c wneu"卢修斯在哪？" # will need to voice map this
    translate None lucius_fight_0863:
        s neu "我正说着话呢，就把他给绑起来了。" # will need to voice map this
    translate None lucius_fight_0864:
        c c wsur"…你是怎么做到的？"
    translate None lucius_fight_0865:
        rs c wsmi"艾米尔教我的。很酷的派对把戏，对吧？"
    translate None lucius_fight_0866:
        "我将手放在他脸颊旁，轻轻抚摸。"
    translate None lucius_fight_0867:
        rs "我们都狼狈不堪。"
    translate None lucius_fight_0868:
        c c wsmi"好。"
    translate None lucius_fight_0869:
        rs "但还活着。"
    translate None lucius_fight_0870:
        c "嗯。"
    translate None lucius_fight_0871:
        "他闭上眼睛，吻了我。"
    translate None lucius_fight_0872:
        "我的身体阵阵作痛，酸软不堪，他也好不到哪去，但在那一刻这些都不重要了。"

    window hide dissolve
    jump illranverasafterfight


label leosafterfight:
    #scene gallery_141 with dissolve
    scene black with dissolve
    pause 2.0
    scene bg throne with dissolve
    window show dissolve
    translate None lucius_fight_0873:
        rs c wsad "结束了…我们真的做到了…"
    translate None lucius_fight_0874:
        l c wsmu "是啊…现在都结束了。"
    translate None lucius_fight_0875:
        "泪水从我脸上滑落，洒满了莱奥斯的全身，但他没有抱怨。在我身后，我听见脚步声走进了房间。"
    translate None lucius_fight_0876:
        rs c wang"但是…你疯了知道吗？！还是个白痴！"
    translate None lucius_fight_0877:
        l c wthi"哇哦，这算什么反应？"
    translate None lucius_fight_0878:
        rs c wsur"那计划太疯狂了！你差点…差点就没命了…"
    translate None lucius_fight_0879:
        l c wsmu "还好你枪法不算太烂，对吧。"
    translate None lucius_fight_0880:
        rs c wsad"你不该这么信任我的…"
    translate None lucius_fight_0881:
        l c wneu "...."
    translate None lucius_fight_0882:
        l "你是我在这世界上最信任的人。"
    translate None lucius_fight_0883:
        rs "啊…我实在没法对你生太久的气…"
    translate None lucius_fight_0884:
        l c wsmu "嗯，很好—"
    translate None lucius_fight_0885:
        rs c wang"但还是别再这么乱来了！"
    translate None lucius_fight_0886:
        l "好啦好啦！"
    translate None lucius_fight_0887:
        "他温柔地抬起手捧住我的脸颊，作为回应，我俯身轻吻了他。"
    translate None lucius_fight_0888:
        "我们当时都很狼狈。"
    translate None lucius_fight_0889:
        "但我们是一起经历的狼狈。"

    window hide dissolve
    jump illranverasafterfight


label fawnafterfight:
    #scene gallery_149 with dissolve REMOVED CG HERE ADD LATER
    scene black with dissolve
    pause 2.0
    scene bg throne with dissolve
    window show dissolve
    translate None lucius_fight_0890:
        f c wsad "不…求你了雷恩…！"
    translate None lucius_fight_0891:
        play music "sounds/bgm/sad.ogg" fadein 3.0
        mor c sur "雷恩…！"
    translate None lucius_fight_0892:
        s neu "…等等。让他独自待会儿吧。"
    translate None lucius_fight_0893:
        f "对不起…求求你，睁开眼吧…"
    translate None lucius_fight_0894:
        f "如果你再也不想见到我…如果你恨我恨到不愿看我一眼…那也没关系，但是求你了..！求求你睁开眼睛吧！"
    translate None lucius_fight_0895:
        f "求你…"
    translate None lucius_fight_0896:
        "泪水从福恩的脸上滑落，他把雷恩搂得更紧了。"
    translate None lucius_fight_0897:
        rs c whur "…没事了。"
    translate None lucius_fight_0898:
        "我颤抖着睁开眼帘，听见福恩压抑的抽泣声。我的手迅速抚上他的脸庞，为他拭去泪水。"
    translate None lucius_fight_0899:
        rs c wsmi "我永远不可能恨你。"
    translate None lucius_fight_0900:
        f c wsur "雷恩！"
    translate None lucius_fight_0901:
        "他俯身亲吻我。泪水止不住地流下，每次呼吸时仍会漏出呜咽。"
    translate None lucius_fight_0902:
        "我将他拉得更近，身体仍虚弱疼痛。"
    translate None lucius_fight_0903:
        "当我们最终分开时，我能看出福恩仍在颤抖。"
    translate None lucius_fight_0904:
        f c wsmi"真高兴你没事…"
    translate None lucius_fight_0905:
        rs c wsmi "我也是…艾米尔怎么样了…？"
    translate None lucius_fight_0906:
        s "他还在呼吸。你们亲热完以后，我来检查你们两个。"
    translate None lucius_fight_0907:
        rs c wneu "……卢修斯呢？"
    translate None lucius_fight_0908:
        mor c ang "我正在把他捆起来。"

    jump illranverasafterfight

label illranverasafterfight:
    # Make sure sad song is playing before this
    scene bg throne with Fade(1.0, 1.0, 1.0)
    window show dissolve
    translate None lucius_fight_0909:
        i sca "维拉斯！"
    translate None lucius_fight_0910:
        v ouc "伊尔兰…"
    translate None lucius_fight_0911:
        i ang "发生什么了？！为什么没人帮你下来？"
    translate None lucius_fight_0912:
        v "..别生气。我不想妨碍任何人。"
    translate None lucius_fight_0913:
        "伊尔兰不假思索地伸手握住了长矛。"
    translate None lucius_fight_0914:
        v "等等，伊尔兰，那里不安全—"
    translate None lucius_fight_0915:
        i "我不在乎。"
    translate None lucius_fight_0916:
        "他轻松地拔出它，轻轻将维拉斯放到地面。肩膀周围已被鲜血染成暗红，维拉斯立即按压住伤口。"
    translate None lucius_fight_0917:
        v smi "….至少我们现在扯平了。他打中了我们两个人的肩膀。"


    if iv_scene_four:
        translate None lucius_fight_0918:
            i sad "..."

        #window hide dissolve
        #scene gallery_118 with dissolve   ADD BACK IN WHEN I HAVE CG
        #window show dissolve
        translate None lucius_fight_0918b:
            "维拉斯伸出手臂，环抱住那位绿发男子。"
        translate None lucius_fight_0919:
            i "...!"
        translate None lucius_fight_0920:
            v lon "我真的好害怕…"
        translate None lucius_fight_0921:
            v "我以为我们两个都活不成了…我确信再也见不到你了…"
        translate None lucius_fight_0922:
            i "我也是…我害怕赶到这里时你已经不在了。"
        translate None lucius_fight_0923:
            i "维拉斯，我不能…我无法想象没有你的人生。"
        translate None lucius_fight_0924:
            "维拉斯把伊尔兰搂得更紧了些。泪水决堤，浸透了对方的衬衫。"
        translate None lucius_fight_0925:
            i "维拉斯…我—"
        translate None lucius_fight_0926:
            v sad "..我们可不能整天在这里坐着无所事事，你知道的。我们答应过扎林会帮他作为对索伦那次出手相助的回报。"
        translate None lucius_fight_0927:
            i "什么..？我明明答应等他康复后就会帮忙，你这是什么意思？"
        translate None lucius_fight_0928:
            v smi "……而且我们得回去查看奥克斯哈伯的情况。"
        translate None lucius_fight_0929:
            i sca "你干什—"
        translate None lucius_fight_0930:
            v "……更别说克利夫斯派尔的悬赏了，对吧？"
        translate None lucius_fight_0931:
            i sad "我不明白。"
        translate None lucius_fight_0932:
            v sad "……我是个白痴，伊尔兰。真正的白痴。直到我们被分开后我才意识到自己有多愚蠢。这么多年，我对近在眼前的事实视而不见。"
        translate None lucius_fight_0933:
            i "什么…？"
        translate None lucius_fight_0934:
            v "没有你我活不下去。我也不想活下去。我不想前往一个永远见不到你、永远触碰不到你、永远无法亲吻你的地方……"
        translate None lucius_fight_0935:
            v "如果我留你独自一人，我将永远无法原谅自己。"
        translate None lucius_fight_0936:
            i "维拉斯…"
        translate None lucius_fight_0937:
            v smi "如果你愿意接受…我想与挚爱共度最后的旅程。"
        translate None lucius_fight_0938:
            i "...."
        translate None lucius_fight_0939:
            i hap "……我已别无他求。"
        translate None lucius_fight_0940:
            i "求你了维拉斯，我们能共度余生吗？"
        translate None lucius_fight_0941:
            "作为回答，他们相向倾身。双唇自然地相触，所有忧虑烟消云散。"

        if achievement.has("illran_soulmates"):
            pass
        else:
            $ renpy.display_notify("成就解锁：灵魂伴侣")

        python:
            achievement.grant("illran_soulmates")
            achievement.sync()

        translate None lucius_fight_0942:
            "他们在一起，一切都会好的。无论如何。"

        window hide dissolve


    else:
        translate None lucius_fight_0943:
            i sad "…这会很容易痊愈吗？"
        translate None lucius_fight_0944:
            v sad "假以时日。你明白的。"
        translate None lucius_fight_0945:
            i "维拉斯，我—"
        translate None lucius_fight_0946:
            v "…请不要这样。"
        translate None lucius_fight_0947:
            v "如果你现在说出来，我肯定会心软的。"
        translate None lucius_fight_0948:
            i "那我为什么不行？我爱你，你是知道的。"
        translate None lucius_fight_0949:
            v "...."
        translate None lucius_fight_0950:
            v "我不能这样对你。我永远都不会。你值得拥有未来、家庭，而我将永远无法给予这些。我做不到…"
        translate None lucius_fight_0951:
            v "来吧，我们该回去和其他人汇合了。"

        window hide dissolve

    jump caspianaemylafterfight


label caspianaemylafterfight:
    scene bg throne with Fade(1.0, 1.0, 1.0)
    window show dissolve
    translate None lucius_fight_0952:
        cas sur "…艾米尔在哪？"


    if cyne_route:
        translate None lucius_fight_0953:
            "卡斯皮安紧跟着伊尔兰冲过门口，目光扫视着这片区域。雷恩、赛恩、伊尔兰、维拉斯…"


    if leos_route:
        translate None lucius_fight_0954:
            "卡斯皮安紧跟着伊尔兰冲进门后，他的目光扫过这片区域。雷恩，莱奥斯，伊尔兰，维拉斯…"


    if fawn_route:
        translate None lucius_fight_0955:
            "卡斯皮安紧跟着伊尔兰冲回门廊，他的目光迅速扫视着四周。房间已被烧得只剩外壳，浓重的黑烟顿时熏得他泪流不止。"
        translate None lucius_fight_0956:
            "雷恩、福恩、伊尔兰、维拉斯……"


    translate None lucius_fight_0957:
        "莫温、埃利奥特、西尔维尔…"
    translate None lucius_fight_0958:
        "但艾米尔在哪儿？"
    translate None lucius_fight_0959:
        rs c wsad "父亲…他在那边…他救了我们…"
    translate None lucius_fight_0960:
        cas "艾米尔！"


    if leos_route or cyne_route:
        translate None lucius_fight_0961:
            "王子冲向前，滑跪在那位因剧痛而蜷缩的身影旁。"


    if fawn_route:
        translate None lucius_fight_0962:
            "王子冲向前去，在灰烬中滑行刹停，来到那个躺在地上一动不动的人形旁边。"


    scene gallery_120 with Fade(1.0, 1.0, 1.0):
        xpos 0.66 ypos 1.01 xanchor 0.5 yanchor 1.0 zoom 1.56

    translate None lucius_fight_0963:
        cas "艾米尔…艾米留斯，你现在不能这样对我。你没资格闯入我的生活又离开！"
    translate None lucius_fight_0964:
        cas "我…我从没想过要再见你，或者说…我以为我不想，可同时又想见你…你总是让我如此困惑…！"
    translate None lucius_fight_0965:
        cas "我从没…从没相信我们真能获得第二次机会。我没想到你会出现在我门前…"
    translate None lucius_fight_0966:
        cas "你再次让我的情绪乱成一团…别以为你能就这么算了！"
    translate None lucius_fight_0967:
        ae "...."

    scene gallery_120 with dissolve

    translate None lucius_fight_0968:
        ae "…那你倒是说说，你到底对我做了什么？"
    translate None lucius_fight_0969:
        cas "....!"
    translate None lucius_fight_0970:
        ae "你这个老傻瓜。我才不会为这点皮肉伤就丧命。你真觉得我有那么无私？"
    translate None lucius_fight_0971:
        cas  "我知道你就是这种人，这才是问题所在！"
    translate None lucius_fight_0972:
        ae "啊哈哈…"


    if ca_scene_two:
        scene gallery_121 with dissolve

        translate None lucius_fight_0973:
            "卡斯皮安的脸越凑越近，直到他们的唇相触，就像多年前他们常做的那样。"
        translate None lucius_fight_0974:
            "这个吻如此自然，仿佛他们从未分离。"
        translate None lucius_fight_0975:
            "仿佛他们从未战斗过，卡斯皮安从未逃亡，艾米尔也从未独处十八年。"
        translate None lucius_fight_0976:
            "但他们确实分离过。"
        translate None lucius_fight_0977:
            "这样也可以。"

        scene gallery_120 with dissolve

        translate None lucius_fight_0978:
            ae "卡斯…我好想你。"
        translate None lucius_fight_0979:
            cas "我也是。"
        translate None lucius_fight_0980:
            ae "我把一切都搞砸了。如果我当时相信你…"
        translate None lucius_fight_0981:
            cas "现在没事了。你不需要向我道歉。"
        translate None lucius_fight_0982:
            ae "…跟我回奥雷利亚卡维拉吧。"
        translate None lucius_fight_0983:
            cas "...."
        translate None lucius_fight_0984:
            cas "…只是去拜访？"
        translate None lucius_fight_0985:
            ae "回来做你命中注定的国王。"
        translate None lucius_fight_0986:
            cas "...."
        translate None lucius_fight_0987:
            ae "而且…再给我一次机会。"
        translate None lucius_fight_0988:
            cas "除非你也给我一次机会。"
        translate None lucius_fight_0989:
            ae "那就说定了。"
        translate None lucius_fight_0990:
            "卡斯皮安说出一句他以为永远不会有机会再说的话。一句他此生只对艾米尔说过一次的话。"
        translate None lucius_fight_0991:
            cas "..我爱你，艾米尔。一直如此。"
        translate None lucius_fight_0992:
            "从艾米尔的唇间吐出一句话，一句他永远没机会回应的言语。"
        translate None lucius_fight_0993:
            ae "…我也是。我也爱你。"


        if achievement.has("caspian_kiss"):
            pass
        else:
            $ renpy.display_notify("成就解锁：再给我一次机会")

        python:
            achievement.grant("caspian_kiss")
            achievement.sync()

        translate None lucius_fight_0994:
            "他们相视而笑。前方或许曾暗淡无光，然而现在…地平线上终于透出一线曙光。"

        window hide dissolve

    else:
        translate None lucius_fight_0995:
            cas smi "来吧，站起来。"
        translate None lucius_fight_0996:
            ae neu "…跟我回奥雷利亚卡维拉吧。" # voice map with above
        translate None lucius_fight_0997:
            cas sur "...."# voice map with above
        translate None lucius_fight_0998:
            cas "…只是去拜访？"# voice map with above
        translate None lucius_fight_0999:
            ae smi "回来做你命中注定的国王。"# voice map with above
        translate None lucius_fight_1000:
            cas "...."# voice map with above
        translate None lucius_fight_1001:
            cas sad "我不确定自己能做到…"
        translate None lucius_fight_1002:
            ae smi "我知道你能。我一直都知道。"
        translate None lucius_fight_1003:
            cas sad "我已不复从前模样。"
        translate None lucius_fight_1004:
            ae sad "我依然能看出你眼中的光芒。"
        translate None lucius_fight_1005:
            cas smi "…我答应你，但条件是你要留在我身边。"
        translate None lucius_fight_1006:
            ae "……愉快地。"

        window hide dissolve

    if ca_scene_two and iv_scene_four:
        jump morwensylvirafterfight

    else:
        jump fightcomplete

label morwensylvirafterfight:
    scene bg throne
    show sylvir n dim neu at slightright
    show morwen n dim cloak smi at slightleft
    with Fade(1.0, 1.0, 1.0)
    window show dissolve
    translate None lucius_fight_1007:
        "莫温环顾四周，目之所及皆是爱情的火焰。"
    translate None lucius_fight_1008:
        s "...."
    translate None lucius_fight_1009:
        s "…他们全都在亲热。"
    translate None lucius_fight_1010:
        mor "啊，要是能再年轻一次多好。"


    if cyne_route:
        translate None lucius_fight_1011:
            "埃利奥特正忙着捆绑仍昏迷不醒的卢修斯。伊尔兰和维拉斯难舍难分，卡斯皮安和艾米尔也是如此。赛恩和雷恩同样缠绵悱恻。"


    if leos_route:
        translate None lucius_fight_1012:
            "埃利奥特正忙着捆绑仍昏迷不醒的卢修斯。伊尔兰和维拉斯难舍难分，卡斯皮安和艾米尔也是如此。莱奥斯和雷恩同样缠绵悱恻。"


    if fawn_route:
        translate None lucius_fight_1013:
            "埃利奥特正忙着捆绑仍昏迷不醒的卢修斯。伊尔兰和维拉斯难舍难分，卡斯皮安和艾米尔也是如此。福恩和雷恩同样缠绵悱恻。"

    translate None lucius_fight_1014:
        mor "爱情不就该是最甜蜜的吗？"
    translate None lucius_fight_1015:
        show sylvir n dim shy with dis
        s "所以呃…你们想不想，还是…？"
    translate None lucius_fight_1016:
        show morwen n dim sur with dis
        mor "什么？！"

    #hide morwen
    #hide sylvir
    #with dissolve
    window hide dissolve

    jump fightcomplete


label fightcomplete:

    if fawn_route:
        scene bg throne with Fade(1.0, 1.0, 1.0)
        window show dissolve
        translate None lucius_fight_1017:
            "当福恩终于确信我安然无恙后，我们与其他人汇合。埃利奥特拖着被五花大绑昏迷的卢修斯走来。"
        translate None lucius_fight_1018:
            show raen nw dim smi cloak at slightright
            show fawn nw dim sad cloak at slightleft
            with dissolve
            rs "……我们做到了。"



    if cyne_route:
        scene bg throne with Fade(1.0, 1.0, 1.0)
        window show dissolve
        translate None lucius_fight_1019:
            rs c wsad "我得…我得去找福恩。"
        translate None lucius_fight_1020:
            c c wsad "..."
        translate None lucius_fight_1021:
            c "你来处理这个，我要…去探望母亲。"
        translate None lucius_fight_1022:
            "我缓缓站起身来，感觉经历这一切后骨头都在嘎吱作响。"
        translate None lucius_fight_1023:
            "我慢慢走向蜷缩在房间黑暗角落里的福恩。"
        translate None lucius_fight_1024:
            show raen nw dim sur cloak at slightright
            show fawn nw dim hur cloak at slightleft
            with dissolve
            rs "福恩…！"
        translate None lucius_fight_1025:
            f "唉…"
        translate None lucius_fight_1026:
            "他眼皮颤动着睁开，双手立即摸向自己的头部。"
        translate None lucius_fight_1027:
            f "我的头…疼死我了…"
        translate None lucius_fight_1028:
            show raen nw dim sad with dis
            rs "我…真高兴你没事…."
        translate None lucius_fight_1029:
            f "....."
        translate None lucius_fight_1030:
            "另一个熟悉的声音在房间里回荡。"
        translate None lucius_fight_1031:
            show raen at center
            show fawn at left
            with move
            show leos nw dim hur cloak at right with dissolve
            l "呃…妈的…为什么我这么疼…？"
        translate None lucius_fight_1032:
            show raen nw dim sur with dis
            rs "莱奥斯！"
        translate None lucius_fight_1033:
            l "别嚷嚷了。"
        translate None lucius_fight_1034:
            "他满脸阴郁地向我们走来。但一看到福恩，那阴郁的表情立刻消散无踪。"
        translate None lucius_fight_1035:
            show leos nw dim sur with dis
            l "你看上去挨了顿揍呢，森林精灵。"
        translate None lucius_fight_1036:
            show fawn nw dim sad with dis
            f "这话我同样能说你。"
        translate None lucius_fight_1037:
            "我停下片刻望向朋友们，一阵宽慰感涌上心头。"
        translate None lucius_fight_1038:
            "他们没事。大家都好好的。"
        translate None lucius_fight_1039:
            "我们迅速重新集结，埃利奥特拖着卢修斯被捆绑得紧紧的不省人事的身体。"
        translate None lucius_fight_1040:
            "房间另一角，赛恩的母亲已惊恐跌坐在地，正从赛恩身边向后挪退。"
        translate None lucius_fight_1041:
            c c wneu "...."
        translate None lucius_fight_1042:
            c "我不会伤害你。"
        translate None lucius_fight_1043:
            lv ang2 "你…你这小混蛋！你毁了我统治的机会！"
        translate None lucius_fight_1044:
            c "...."
        translate None lucius_fight_1045:
            c c wsad "相信我，这个世界不需要像你这样的人来统治。"
        translate None lucius_fight_1046:
            c "来吧，回家吧。我不会碰你的。"
        translate None lucius_fight_1047:
            lv "为了什么？！就让我在那空房子里干坐着，等下个机会吗？！你不懂，你这小混蛋。这是我唯一的机会了！"
        translate None lucius_fight_1048:
            c c wang "....."
        translate None lucius_fight_1049:
            c "我真的、真的不在乎。赶紧走，别逼我叫别人来收拾你。他们可没我这么好说话。"
        translate None lucius_fight_1050:
            lv "我不要！"
        translate None lucius_fight_1051:
            c "...."
        translate None lucius_fight_1052:
            el gla "…需要帮忙吗？"
        translate None lucius_fight_1053:
            c "她悲痛欲绝。"
        translate None lucius_fight_1054:
            el "所以…你就是和卢修斯密谋的女人？"
        translate None lucius_fight_1055:
            lv "…关你什么事？"
        translate None lucius_fight_1056:
            el "我认为你需要些时间来学会更谦逊些。"
        translate None lucius_fight_1057:
            lv "喂—你—别碰我！"
        translate None lucius_fight_1058:
            c c wsur "你们要对她做什么？"
        translate None lucius_fight_1059:
            el smi "在山上待几个月对她这样爱慕虚荣的女人有好处。"
        translate None lucius_fight_1060:
            c "...."
        translate None lucius_fight_1061:
            lv "你竟然让一个…一个像他这样平民碰我？！西纳库洛斯，命令他马上放开我！"
        translate None lucius_fight_1062:
            c c wsad "妈妈…我爱你，真的爱你，正因如此我无法原谅你。我希望你能变得更好。"
        translate None lucius_fight_1063:
            c c wsmi "去山里待上几个月会对你有好处。"
        translate None lucius_fight_1064:
            lv "西纳库洛斯！"
        translate None lucius_fight_1065:
            show leos at farright
            show raen at cenleft
            show fawn at farleft
            with move
            show cyne nw dim neu cloak at cenright with dissolve
            "赛恩离开了她，最终她停止了喊叫，任由自己被埃利奥特拉着前行。"


    if cyne_route or fawn_route:
        translate None lucius_fight_1066:
            el neu "我们几乎什么都没做。那些恳求全都是徒劳。"
        translate None lucius_fight_1067:
            show raen nw dim smi with dis
            rs "不是这样。没有在场所有人的努力，我们不可能成功。"
        translate None lucius_fight_1068:
            el "…我希望你遵守诺言，艾米尔。"
        translate None lucius_fight_1069:
            ae ann "我一回来就会确保他们获得自由。"
        translate None lucius_fight_1070:
            rs "我想…是时候回家了。"

        jump illranverasgoback


    if leos_route:
        scene bg throne with Fade(1.0, 1.0, 1.0)
        window show dissolve
        translate None lucius_fight_1071:
            "就在我好不容易从莱奥斯身边挣脱开时，我瞥见那三位神明走过前去检视卢修斯。"
        translate None lucius_fight_1072:
            el sad "他还活得好好的。"
        translate None lucius_fight_1073:
            s neu "我们该怎么处置他？"
        translate None lucius_fight_1074:
            el "我们得把他带回去，不管用什么方法，都得给他点教训。"
        translate None lucius_fight_1075:
            "仿佛那东西轻若无物，埃利奥特将枝形吊灯扔到一旁，把卢修斯扛上了肩头。"
        translate None lucius_fight_1076:
            i fli "..你能活下来让我很惊讶，莱奥斯。"
        translate None lucius_fight_1077:
            l c wsmu "哈！这话我同样能说你。"
        translate None lucius_fight_1078:
            "在大门敞开的门口，两个身影踉踉跄跄地闯了进来，双手抱着头。"
        translate None lucius_fight_1079:
            show fawn nw dim cloak sad at farleft
            show leos nw dim cloak neu at farright
            show raen nw dim cloak sur at cenleft
            show cyne nw dim sad cloak at cenright
            with dissolve
            c "呃…我头疼，而且不是那种爽的疼…"
        translate None lucius_fight_1080:
            f "有什么好办法…？"
        translate None lucius_fight_1081b:
            r "福恩，赛恩…！"
        translate None lucius_fight_1081:
            "如果先前的眼泪已经止住，那也不重要，因为它们瞬间又哗哗地顺着我的脸颊流了下来。"
        translate None lucius_fight_1082:
            "当跑过去抱住他们俩时，一股释然感涌上心头。他们看起来略显困惑，但还是回抱住了我。"
        translate None lucius_fight_1083:
            c "发生了什么…？"
        translate None lucius_fight_1084:
            show raen nw dim smi with dis
            rs "…这是个很长的故事，明白吗？但现在一切都好了。"


        jump illranverasgoback



label illranverasgoback:
    if iv_scene_four:
        translate None lucius_fight_1085:
            v smi "..雷恩，艾米尔，我会把最后的任务托付给你们。我不需要回去了，再也不需要了。"
        translate None lucius_fight_1086:
            show raen nw dim sur with dis
            rs "你改变主意了？"
        translate None lucius_fight_1087:
            v "我曾以为自己在这世上再无容身之处。其实我早就有归宿了，只是从未察觉。"
        translate None lucius_fight_1088:
            show raen nw dim smi with dis
            stop music fadeout 2.0
            rs "我保证不会让你失望。"

        jump fightcompletecont

    if not iv_scene_four:
        translate None lucius_fight_1089:
            v sad "…雷恩，艾米尔，我将把最后的任务托付给你们。"
        translate None lucius_fight_1090:
            show raen nw dim sur with dis
            rs "你不会回来了…？"
        translate None lucius_fight_1091:
            v "我全心全意地相信你会把工作完成。这对我来说就足够了。"
        translate None lucius_fight_1092:
            i sad "...."
        translate None lucius_fight_1093:
            show raen nw dim sad with dis
            stop music fadeout 2.0
            rs "我保证不会让你失望。" # voice map

        jump fightcompletecont

label fightcompletecont:
    play music "sounds/bgm/night.ogg" fadein 2.0

    if fawn_route:
        translate None lucius_fight_1094:
            "两个人影跌跌撞撞地穿过门口，一边呻吟一边喃喃自语。"
        translate None lucius_fight_1095:
            l c whur"呃，我的头…"
        translate None lucius_fight_1096:
            c c wsur "{i}你的{/i}脑袋？! 我感觉像是被人反复揍了太多次，而且不是那种让人舒服的方式…"
        translate None lucius_fight_1097:
            l "好方法..？"
        translate None lucius_fight_1098:
            c c wsmi "待会儿给你看，好吗？"
        translate None lucius_fight_1099:
            show raen nw dim sur
            show fawn nw dim sur
            with dis
            rs "莱奥斯，赛恩！"
        translate None lucius_fight_1100:
            show fawn nw dim cloak sad at farleft
            show raen nw dim cloak sur at cenleft
            with move
            show leos nw dim cloak hur at farright
            show cyne nw dim sur cloak at cenright
            with dissolve
            "我冲向她们，她们怯怯地望着我。"
        translate None lucius_fight_1101:
            rs "真高兴你没事！"
        translate None lucius_fight_1102:
            c "真是…盛大的观众席啊。这些人都是谁？"





    if cyne_route or leos_route:
        show fawn nw dim sad with dis
        translate None lucius_fight_1103:
            f "呃…现在问可能有点晚了，不过…这些人…都是谁啊…？"


    if cyne_route:
        show leos nw dim neu with dis
        translate None lucius_fight_1104:
            l "毫无头绪。"

        show raen nw dim smi with dis

    if cyne_route or fawn_route:
        translate None lucius_fight_1105:
            rs "说来话长…不过现在都好了。"


    show raen nw dim neu with dis
    translate None lucius_fight_1106:
        rs "你还记得什么吗？" # both cyne and leos route, check if fawn route


    if cyne_route or fawn_route:
        translate None lucius_fight_1107:
            l "有点模糊…只记得被人狠狠修理了一顿。"


    if leos_route:
        translate None lucius_fight_1108:
            c "一切都那么模糊…我只记得…被痛打了一顿？"

    translate None lucius_fight_1109:
        i fli "呵呵呵…哎呀，那是我干的。"
    translate None lucius_fight_1110:
        cas sur "嘿，别把功劳全占了！按比分是15比16。我赢了。"
    translate None lucius_fight_1111:
        i hap "真的吗？也许你数错了。"
    translate None lucius_fight_1112:
        cas ang "呃-嘿!"

    if cyne_route:
        translate None lucius_fight_1113:
            show leos nw dim thi with dis
            l "…对不起。是我太软弱，让他得逞了。"
        translate None lucius_fight_1114:
            "莱奥斯脸色阴沉下来，显然在生自己的气。"
        translate None lucius_fight_1115:
            show raen nw dim neu with dis
            rs "不必道歉，这不是你的错。"
        translate None lucius_fight_1116:
            rs "最重要的是…所有人都平安无事。"
        translate None lucius_fight_1117:
            "我松了口气，但心脏依然跳动得如此剧烈，怎么也不肯平静下来。"
        translate None lucius_fight_1118:
            rs "…现在怎么办？"
        translate None lucius_fight_1119:
            show cyne nw dim smi with dis
            c "我们在奥雷利亚卡维拉完成事情。"
        translate None lucius_fight_1120:
            show raen nw dim sur with dis
            rs "…你会跟我走吗？"
        translate None lucius_fight_1121:
            c "当然。现在我绝不会放你离开。"
        translate None lucius_fight_1122:
            rs "至少，我得确保神明获得自由…之后嘛…我还没想好…这样行吗？"
        translate None lucius_fight_1123:
            c "…如果是和你一起，怎样都好。大概。有点肉麻是吧？"
        translate None lucius_fight_1124:
            l "..."
        translate None lucius_fight_1125:
            l "我不会回去了。"
        translate None lucius_fight_1126:
            show cyne nw dim sad with dis
            rs "…什么？"
        translate None lucius_fight_1127:
            l "那里已没有值得我留恋的东西。"
        translate None lucius_fight_1128:
            show leos nw dim smi with dis
            l "其实我早就有去旅行的念头了。寻找真我之类的。"
        translate None lucius_fight_1129:
            show raen nw dim sad with dis
            rs "…我会想你的。"
        translate None lucius_fight_1130:
            show leos nw dim smu with dis
            l "我也会想你的，雷恩。别惹太多麻烦，因为下次我不会在那里救你了。"
        translate None lucius_fight_1131:
            "我不假思索地转身紧紧抱住了他。更令人惊讶的是，他也回抱了我。"
        translate None lucius_fight_1132:
            rs "这很有趣。"
        translate None lucius_fight_1133:
            show leos nw dim emb blush with dis
            l "闭嘴，趁你还没把我弄哭之前。"
        translate None lucius_fight_1134:
            show fawn nw dim sad with dis
            "福恩眼泪汪汪地朝我们走来。莱奥斯抽身离开，揉了揉他的头发，微笑着。"
        translate None lucius_fight_1135:
            l "说真的，快住手，你不会想看到我哭的。"
        translate None lucius_fight_1136:
            show cyne nw dim hap with dis
            c "我有锁！"
        translate None lucius_fight_1137:
            f "莱—奥—斯！"
        translate None lucius_fight_1138:
            "在一阵泪雨中，福恩紧紧抱住莱奥斯，死活不肯撒手。眼前这难以置信的一幕让我忍不住笑出声来。"
        translate None lucius_fight_1139:
            "赛恩快步走来，边哭边笑地紧抱住莱奥斯，令他十分无奈。但这次，莱奥斯竟没有反抗。"
        translate None lucius_fight_1140:
            rs "你呢，福恩？"


    if fawn_route:
        show cyne nw dim sad with dis
        translate None lucius_fight_1141:
            c "…对不起，大家。"
        translate None lucius_fight_1142:
            show leos nw dim emb with dis
            rs "别哭了。没关系的。"
        translate None lucius_fight_1143:
            "赛恩一反常态地泪流满面。就连莱奥斯也看起来随时都可能哭出来。"


    if leos_route:
        translate None lucius_fight_1144:
            "伊尔兰对着卡斯皮安邪魅一笑，后者只是沮丧地摇摇头。尘埃落定后，我看向两位好友。"
        translate None lucius_fight_1145:
            show raen nw dim sur with dis
            rs "接下来怎么办…？"


    if leos_route or cyne_route:
        show fawn nw dim smi with dis
        translate None lucius_fight_1146:
            f "…我想重建家园。"
        translate None lucius_fight_1147:
            rs "真的吗？"
        translate None lucius_fight_1148:
            f "是啊。或许离斯塔格威奇更近些，这样我就能多去拜访了。"
        translate None lucius_fight_1149:
            show raen nw dim smi with dis
            rs "听起来很棒。"
        translate None lucius_fight_1150:
            f "你也要记得来看我。"
        translate None lucius_fight_1151:
            rs "我会帮你一起重建。"
        translate None lucius_fight_1152:
            show fawn nw dim sad with dis
            f "雷恩…"


    if leos_route:
        show cyne nw dim sad with dis
        translate None lucius_fight_1153:
            c "我还得向母亲好好解释一番…"
        translate None lucius_fight_1154:
            show raen nw dim sad with dis
            rs "就这样了吧？"
        translate None lucius_fight_1155:
            c "别搞得好像我们永远不会再见面一样。就当是…下一次冒险前的小小休息。"


    if leos_route or fawn_route:
        translate None lucius_fight_1156:
            c "…我猜你现在是要回家了？"
        translate None lucius_fight_1157:
            rs "至少我得确保神明们获得自由…之后嘛…我还没想好。"
        translate None lucius_fight_1158:
            show cyne nw dim smi with dis
            c "那我至少可以把马车借给你。"
        translate None lucius_fight_1159:
            show raen nw dim smi with dis
            rs "你听到了吗，莱奥斯？再也不用穿行森林了！"
        translate None lucius_fight_1160:
            show leos nw dim smu with dis
            l "谁知道呢？说不定你的马车夫会跑掉，结果你还是得走路—那可就不一样了，对吧？"
        translate None lucius_fight_1161:
            rs "这一点都不好笑。"


    if leos_route:
        translate None lucius_fight_1162:
            "含着泪水，我拥抱了那些对我如此重要的人们。"
        translate None lucius_fight_1163:
            "莱奥斯站在一旁，直到我把他拉过来加入拥抱。他假装很恼火，但我知道他也想参与其中。"
        translate None lucius_fight_1164:
            c "别太想我啊，莱奥斯。"
        translate None lucius_fight_1165:
            l "相信我，我不会的。"
        translate None lucius_fight_1166:
            show fawn nw dim sad with dis
            f "莱～奥～斯～，我会很想你的…！"
        translate None lucius_fight_1167:
            l "…嗯，我也是，小鬼。"
        translate None lucius_fight_1168:
            "他温柔地揉乱了福恩的头发，我不禁微笑起来。"
        translate None lucius_fight_1169:
            "分别时，埃利奥特引起了我的注意。"


    if fawn_route:
        show leos nw dim thi with dis
        translate None lucius_fight_1170:
            l "...."
        translate None lucius_fight_1171:
            l "我不会回去了。"
        translate None lucius_fight_1172:
            show raen nw dim sur with dis
            rs "…什么？"
        translate None lucius_fight_1173:
            l "那里已没有值得我留恋的东西。"
        translate None lucius_fight_1174:
            show leos nw dim smi with dis
            l "其实我早就有去旅行的念头了。寻找真我之类的。"
        translate None lucius_fight_1175:
            show raen nw dim sad with dis
            rs "…我会想你的。"
        translate None lucius_fight_1176:
            show leos nw dim smu with dis
            l "我也会想你的，雷恩。别惹太多麻烦，因为下次我不会在那里救你了。"# voice map with above
        translate None lucius_fight_1177:
            "我不假思索地转身紧紧抱住了他。更令人惊讶的是，他也回抱了我。"# voice map with above
        translate None lucius_fight_1178:
            rs "这很有趣。"
        translate None lucius_fight_1179:
            show leos nw dim emb blush with dis
            l "闭嘴，趁你还没把我弄哭之前。"# voice map with above
        translate None lucius_fight_1180:
            show fawn nw dim sad with dis
            "福恩眼泪汪汪地朝我们走来。莱奥斯抽身离开，揉了揉他的头发，微笑着。"
        translate None lucius_fight_1181:
            l "照顾好雷恩，明白吗？他需要所有能得到的帮助。"
        translate None lucius_fight_1182:
            f "莱—奥—斯！"
        translate None lucius_fight_1183:
            "在一阵泪雨中，福恩紧紧抱住莱奥斯，死活不肯撒手。眼前这难以置信的一幕让我忍不住笑出声来。"
        translate None lucius_fight_1184:
            c "我真希望能和你们一起回去，但我父母可能会杀了我。"# voice map with below
        translate None lucius_fight_1185:
            c "…我不能说这很有趣，但我不会改变任何经历。呃…好吧，或许有几件事可以改改，但是…"# voice map with below
        translate None lucius_fight_1186:
            c "谢谢，雷恩。你最好来看我们。"
        translate None lucius_fight_1187:
            rs "只要有机会我就会来。"
        translate None lucius_fight_1188:
            ani sca "呃…"
        hide fawn
        hide raen
        hide leos
        hide cyne
        with dissolve
        translate None lucius_fight_1189:
            "福恩快速跑回他姐姐身边，她正从先前瘫坐的地上站起来。"
        translate None lucius_fight_1190:
            ani sad "…阿登…？"
        translate None lucius_fight_1190b:
            f c wsad "…是我，姐姐。"
        translate None lucius_fight_1191:
            f "请听我说，就一分钟。"
        translate None lucius_fight_1192:
            ani "..."#
        translate None lucius_fight_1192b:
            f "我知道你恨透了我，恨到想要我死，但即使你永远无法原谅我，我也会永远悔恨不已。"
        translate None lucius_fight_1193:
            f "你将永远留在我心中，我所做的一切都只是为了努力过上能让父母为我们感到骄傲的生活。"
        translate None lucius_fight_1194:
            ani sad "…阿登..我..我…"
        translate None lucius_fight_1194b:
            ani cry "我非常抱歉…求求你，求求你原谅我…"
        translate None lucius_fight_1194c:
            "她号啕大哭着倒进他的怀抱。我转身走开，给他们留出片刻独处的时光。"
        translate None lucius_fight_1195:
            rs c wsur "你们打算怎么处置卢修斯？"


    jump godsleaving

label godsleaving:
    translate None lucius_fight_1196:
        el neu "我们会把他带回村庄，再决定如何处置。别担心，自由不会是选项之一。"


    if cyne_route:
        translate None lucius_fight_1197:
            el "她也一样。"

    translate None lucius_fight_1198:
        rs "谢谢你，埃利奥特。"


    if fawn_route:
        translate None lucius_fight_1199:
            f "…谢谢你，埃利奥特。如果没有你，我可能早就无法控制局面了。"
        translate None lucius_fight_1200:
            el "别以为你的训练已经结束了。我期望你能按时回到村庄。"
        translate None lucius_fight_1201:
            f c wsur "真的吗…？你是说真的吗？"
        translate None lucius_fight_1202:
            el "当然了。那我们现在就告辞了。西尔维尔，莫温，我们走吧。"




    if leos_route:
        translate None lucius_fight_1203:
            el "还有..离开之前，我能看看那个吗？"
        translate None lucius_fight_1204:
            show leos nw dim neu with dis
            "他用手指了指莱奥斯腰间的匕首。莱奥斯迅速从腰带上抽出它，递给埃利奥特。"
        translate None lucius_fight_1205:
            el smi "……这是锡德卡汉古代皇家卫队的徽记。一个世代献身于守护王权的家族。我很熟悉这个徽记。"
        translate None lucius_fight_1206:
            show leos nw dim sur with dis
            l "...."
        translate None lucius_fight_1207:
            l "这是…我们家族的纹章…"
        translate None lucius_fight_1208:
            el "嗯…看来他们在锡德卡汉的经历一定相当有趣。"


    if cyne_route or leos_route:
        translate None lucius_fight_1209:
            el "那我们就告辞了。西尔维尔，莫温，走吧。"


    if fawn_route:
        show raen nw dim cloak sur at slightleft
        show fawn nw dim cloak neu at slightright
        with dissolve

    show raen nw dim sur with dis
    translate None lucius_fight_1210:
        rs "等等，莫温…"
    translate None lucius_fight_1211:
        mor c smi "..我稍后会找到你的，好吗？别用那种眼神看着我。这又不是永别。"
    translate None lucius_fight_1212:
        mor "是\"改日再见\"。"
    translate None lucius_fight_1213:
        show raen nw dim smi with dis
        rs "…好吧。路上小心。"
    translate None lucius_fight_1214:
        "她朝我微笑，三位村庄神明离开了这座寂静阴沉的宫殿。"


    if fawn_route:
        translate None lucius_fight_1215:
            "很快其他人也相继离去。赛恩和莱奥斯结伴而行，前者不知为何非要后者再多留一晚。"
        translate None lucius_fight_1216:
            "伊尔兰和维拉斯不知何时已溜走。这对神秘组合向来如此。"
        translate None lucius_fight_1217:
            "安妮含泪踏上归途，承诺会说服姐妹们原谅福恩—最终大家再相聚。"
        translate None lucius_fight_1218:
            "最后只剩下我们四人：我、福恩、卡斯皮安和艾米尔。"

        hide fawn
        hide raen
        with dissolve



    if cyne_route:
        translate None lucius_fight_1219:
            show leos nw dim neu -blush with dis
            l "好吧…那我先走了。别担心，我相信我们很快就会再见面的。"
        translate None lucius_fight_1220:
            show fawn nw dim sad with dis
            f "莱奥斯…注意安全，好吗？"

        hide leos
        hide fawn
        hide raen
        hide cyne
        with dissolve
        translate None lucius_fight_1221:
            "他微笑着，随后再次穿过那扇门离开了，留我和赛恩、福恩、艾米尔以及卡斯皮安在一起。"
        translate None lucius_fight_1222:
            "伊尔兰和维拉斯不知何时已溜走。这对神秘组合向来如此。"


    if leos_route:
        show leos nw dim smu with dis
        translate None lucius_fight_1223:
            l "…啊哈哈哈!"
        translate None lucius_fight_1224:
            show raen nw dim sur with dis
            rs "有什么好笑的？"
        translate None lucius_fight_1225:
            l "这不好笑吗？原来我保护你的同时，一直在重温往事。"
        translate None lucius_fight_1226:
            "哦…如果我是锡德卡汉王族后裔，而他是我们贴身护卫的后代…"
        translate None lucius_fight_1227:
            show raen nw dim smi with dis
            rs "噗……我们真是命中注定要相遇啊，对吧？"
        translate None lucius_fight_1228:
            l "看起来是的。"
        translate None lucius_fight_1229:
            show cyne nw dim smi with dis
            c "那我也是时候告辞了。至少给我写封信，好吗？"
        translate None lucius_fight_1230:
            show fawn nw dim smi with dis
            f "我保证会写…！"
        translate None lucius_fight_1231:
            c "很好。"
        translate None lucius_fight_1232:
            c "我真希望能和你们一起回去，但我父母可能会杀了我。" # voice map
        translate None lucius_fight_1233:
            c "…我不能说这很有趣，但我不会改变任何经历。呃…好吧，或许有几件事可以改改，但是…" # voice map
        translate None lucius_fight_1234:
            c "谢谢，雷恩。你最好来看我们。" # voice map
        translate None lucius_fight_1235:
            rs "只要有机会我就会来。" # voice map
        translate None lucius_fight_1236:
            f "..我去帮忙准备马车。"

        hide fawn
        hide cyne
        with dissolve
        show leos at slightright
        show raen at slightleft
        with move
        translate None lucius_fight_1237:
            "两人离去后，现场只剩下我、卡斯皮安、艾米尔、维拉斯和伊尔兰。"
        translate None lucius_fight_1238:
            show leos nw dim neu with dis
            l "…雷恩，如果你想的话，我会和你一起回奥雷利亚卡维拉。"
        translate None lucius_fight_1239:
            "我想点头应允，想展露欢颜，可我深知这并非明智之选。"
        translate None lucius_fight_1240:
            show raen nw neu with dis
            rs "…不，我不想强迫你去面对你还没准备好的事情。"
        translate None lucius_fight_1241:
            rs "我会回去做必须做的事，我保证…我一定会回来找你。"
        translate None lucius_fight_1242:
            l "…只要你答应。我会等的。"
        translate None lucius_fight_1243:
            i fli "唔呃呃，那我们这边儿的雇佣兵这下子要失业咯？"
        translate None lucius_fight_1244:
            l "我想是的。我估计我得另谋生路了。"
        translate None lucius_fight_1245:
            i "曾经想过做赏金猎人吗？你干这个应该会很在行。"
        translate None lucius_fight_1246:
            show raen nw dim sur with dis
            rs "你不是说过如果我们成了赏金猎人，你就会吻赛恩吗？"
        translate None lucius_fight_1247:
            l "说实话，我觉得我还是不要这么做比较好。"
        translate None lucius_fight_1248:
            z ang "呃…"
        translate None lucius_fight_1249:
            rs "扎林？你怎么在这儿？"
        translate None lucius_fight_1250:
            "他摇了摇头，仿佛正试图让自己清醒过来。"
        translate None lucius_fight_1251:
            z "你的朋友们刚把我从笼子里放出来…"
        translate None lucius_fight_1252:
            rs "你刚才在里面？"
        translate None lucius_fight_1253:
            z neu "当我赶到国王那里时，他早已落入卢修斯的掌控之中。为时已晚。"
        translate None lucius_fight_1254:
            show raen nw dim sad with dis
            rs "天啊，我真的很抱歉…"
        translate None lucius_fight_1255:
            z "..不必如此。从形势来看，今日已获全胜，你也活下来了。表现得很好。"
        translate None lucius_fight_1256:
            z "作为额外收获，这对我的研究很有帮助。"
        translate None lucius_fight_1257:
            rs "你总是惦记着研究，对吧.."
        translate None lucius_fight_1258:
            z sur "你现在打算怎么办？"
        translate None lucius_fight_1259:
            rs "…我要回家了。"
        translate None lucius_fight_1260:
            show leos nw dim sur with dis
            l "..我还不确定要做什么。"
        translate None lucius_fight_1261:
            z "你要留下来？有住处吗？"
        translate None lucius_fight_1262:
            l "暂时没有。而且我也不太想再依赖赛恩的好意了。"
        translate None lucius_fight_1263:
            z "…好吧，我对你的经历非常感兴趣。不如这样—你可以免费住在我实验室，作为交换要把发生的事情都详细告诉我。"
        translate None lucius_fight_1264:
            show raen nw dim sur with dis
            rs "听起来很棒…莱奥斯？"
        translate None lucius_fight_1265:
            l "..我会考虑的。"

        hide leos
        hide raen
        with dissolve
        translate None lucius_fight_1266:
            "伊尔兰和维拉斯迅速离开了，如凭空消失般。依然是那对神秘的搭档。扎林也走了，在提图斯过分担心前赶回家去。"


    translate None lucius_fight_1267:
        rs c wneu "…准备好了吗，各位？"
    translate None lucius_fight_1268:
        cas smi "你知道吗…我想我准备好了。"
    translate None lucius_fight_1269:
        cas "我们回家吧。"


    if cyne_route:
        translate None lucius_fight_1270:
            ae neu "…别告诉我你们打算走路。" # check if fawn route too
        translate None lucius_fight_1271:
            c c wsmi "可以坐我的马车。"
        translate None lucius_fight_1272:
            rs c wsad "因为上次乘坐体验相当\"美好\"啊…"


    window hide dissolve

    scene bg sc day with Fade(1.0, 1.0, 1.0)
    window show dissolve

    if fawn_route:
        translate None lucius_fight_1273:
            "外面，太阳开始微弱地照耀着锡德卡汉。一辆马车等候着我们，虽然这次换了不同的车夫。"
        translate None lucius_fight_1274:
            "我悄悄把卡斯皮安拉到一旁。"
        translate None lucius_fight_1275:
            rs c wsur "我之前拜托你做的东西，还能做吗？"
        translate None lucius_fight_1276:
            cas smi "你知道的。"
        translate None lucius_fight_1277:
            "安排好这件事后，我很快找借口离开直到傍晚。毕竟，我还有个承诺要兑现。"
        translate None lucius_fight_1278:
            "我和福恩手牵着手，穿过积雪覆盖的锡德卡汉城。最后一次欣赏这里的景色—石墙与尖顶，山脉与微风。"
        translate None lucius_fight_1279:
            "我们敲响一扇门，和周围的门一样普通。脚步声匆匆向我们靠近，门很快打开了。"
        translate None lucius_fight_1280:
            show fawn nw cloak neu at center
            show raen nw cloak smi at left
            show titus n smi mask at right
            with dissolve
            tit "雷恩，福恩！见到你们俩真是太好了！是不是…是不是都结束了？"
        translate None lucius_fight_1281:
            rs "…是啊，而且我有好多故事要告诉你。"
        translate None lucius_fight_1282:
            tit "..！我去拿记事本！快进来，快进来！"
        translate None lucius_fight_1283:
            "白昼在恍惚中流逝—我把一切都告诉了提图斯，毫无保留。他兴奋地全盘接收。"
        translate None lucius_fight_1284:
            scene bg sc sunset
            show fawn nw sunset cloak neu at center
            show raen nw sunset cloak smi at left
            show titus n sunset smi mask at right
            with dis3
            "不知不觉间，外面已是落日西沉，提图斯送我们到门口。"
        translate None lucius_fight_1285:
            show fawn nw sunset sad with dis
            f "提图斯，听我说，我…"
        translate None lucius_fight_1286:
            "福恩猛咽了一下，很可能是在拼命思索该如何为过去发生的事道歉。"
        translate None lucius_fight_1287:
            f "…我知道你不明白，但…我对在克利夫斯派尔发生的一切感到很抱歉，我…"
        translate None lucius_fight_1288:
            f "说实话，我…"
        translate None lucius_fight_1289:
            "提图斯带着温和而略带笑意的表情，将一只手搭在福恩的肩上。"
        translate None lucius_fight_1290:
            show titus n sunset hap with dis
            tit "啊，不过这个故事留待下次再讲，对吧？你的故事可不比雷恩的逊色呢，所以…我期待很快再见到你！"
        translate None lucius_fight_1291:
            "福恩的眼中噙满泪水，他紧紧抱住提图斯，久久不愿松开。"
        translate None lucius_fight_1292:
            "两人之间有一种谁都无法真正理解的羁绊。"
        translate None lucius_fight_1293:
            hide titus
            hide fawn
            hide raen
            with dissolve
            "我们分道扬镳，在马车的停靠处找到了卡斯皮安和艾米尔。"


    if cyne_route:
        translate None lucius_fight_1294:
            "外面，太阳开始明亮地照耀着锡德卡汉。新的一天终于破晓。"
        translate None lucius_fight_1295:
            cas smi "至少给我一天时间收拾行李。"
        translate None lucius_fight_1296:
            ae smi "我会协助你。"
        translate None lucius_fight_1297:
            c c wsmi "哈…\"协助您\"他说得真好听。"
        translate None lucius_fight_1298:
            ae emb2 "闭嘴。"
        translate None lucius_fight_1299:
            c "好了好了…我去安排马车。"
        translate None lucius_fight_1300:
            f c wsad "…我想我该和提图斯谈谈。"
        translate None lucius_fight_1301:
            rs c wsur "提图斯？为什么？"
        translate None lucius_fight_1302:
            f "…去道个歉。"
        translate None lucius_fight_1303:
            "他显然不愿多谈，我也没追问。"
        translate None lucius_fight_1304:
            rs "好吧。那一会儿在这儿见。"
        translate None lucius_fight_1305:
            "众人各自散去，最后只剩我和赛恩。"
        translate None lucius_fight_1306:
            c "我们去找埃瑟吧。"
        translate None lucius_fight_1307:
            "手牵着手，我们朝他的庄园走去。我们饱览着四周的风景—那石砌的建筑与尖塔，那绵延的山脉与和煦的微风—这可能是很长一段时间内最后欣赏这些景致的机会了。"
        translate None lucius_fight_1308:
            "站在他家门口的是埃瑟。"
        translate None lucius_fight_1309:
            show cyne nw sad cloak at slightleft
            show raen nw neu cloak at slightright
            with dissolve
            e "先生…先生，那是血吗？！"
        translate None lucius_fight_1310:
            c "…没错。说来话长，行了吧？"
        translate None lucius_fight_1311:
            e "你去哪儿了？！快请进来，让我好好招待你…！"
        translate None lucius_fight_1312:
            c "不…不行，这次真的不行。"
        translate None lucius_fight_1313:
            c "这是个相当漫长的故事，不过…现在一切都好起来了。"
        translate None lucius_fight_1314:
            e "为什么不能进来？那个东西…对你做了什么？"
        translate None lucius_fight_1315:
            "他脸上写满不安地看着我。"
        translate None lucius_fight_1316:
            c "…我要离开一阵子，等回来的时候…我想我不能再住这房子了。"
        translate None lucius_fight_1317:
            c "而且…母亲也会离开很久。她去…进行心灵之旅了。我觉得这对她有好处。"
        translate None lucius_fight_1318:
            c "不过房子不能空着没人。我还不至于蠢到认为我父亲还会在这里花时间停留。"
        translate None lucius_fight_1319:
            c "所以…拜托，我想请你照看这个地方。我会留下足够的钱来支付员工工资，也能让你活得舒舒服服。"
        translate None lucius_fight_1320:
            e "这…这我实在不能接受，先生。"
        translate None lucius_fight_1321:
            c "我不是什么先生。就叫我赛恩，好吗？"
        translate None lucius_fight_1322:
            e "赛恩…"
        translate None lucius_fight_1323:
            e "为什么..为什么您要为我做这一切？"
        translate None lucius_fight_1324:
            show cyne nw smi with dis
            c "因为你是我最老、最信任的朋友。我知道这样很自私，但我还有另外一个请求。"
        translate None lucius_fight_1325:
            e "任何事情。"
        translate None lucius_fight_1326:
            c "我们需要今天赶回斯塔格威奇。"
        translate None lucius_fight_1327:
            e "那就这么定了，先生—呃…赛恩。"
        translate None lucius_fight_1328:
            c "今天下午在宫殿前碰面，好吗？我还得去个其他地方。"
        translate None lucius_fight_1329:
            "有一瞬间，我以为他看向我的目光柔和了些，但当我尝试微笑时，他却回以皱眉。"
        translate None lucius_fight_1330:
            "他对赛恩的保护欲真的很强…"
        translate None lucius_fight_1331:
            "嗯，我很高兴赛恩在成长过程中有人可以依靠。"
        translate None lucius_fight_1332:
            "我们道了别，赛恩立刻又握住我的手，拉着我往前走。"
        translate None lucius_fight_1333:
            show raen nw sur with dis
            rs "去哪儿？"
        translate None lucius_fight_1334:
            c "致阿什。他终究会想念他最宝贵的客人。"
        translate None lucius_fight_1335:
            "穿过城镇的路程并不远，但我们走得很慢。有很多事情需要思考，需要讨论，不过这些可以留待以后再说。"
        translate None lucius_fight_1336:
            "赛恩停在樱草花的门前，抬头看着名牌。"
        translate None lucius_fight_1337:
            show cyne nw sad with dis
            c "…你知道阿什的妻子去世了，对吧？"
        translate None lucius_fight_1338:
            show raen nw sad with dis
            rs "嗯…"
        translate None lucius_fight_1339:
            c "她死于一场火灾。有人说是意外，但阿什告诉了我真相。他知道她是被谋杀的。"
        translate None lucius_fight_1340:
            show raen nw sur with hpunch
            rs "怎么会有人这么做？！"
        translate None lucius_fight_1341:
            c "....."
        translate None lucius_fight_1342:
            c "显然是为了她与生俱来的魔法天赋。"
        translate None lucius_fight_1343:
            rs "…等等，这么说来…？"
        translate None lucius_fight_1344:
            c "是啊…我想我终于明白了。我以为他只是痛苦之下胡言乱语，但是…"
        translate None lucius_fight_1345:
            c "…他就像我的父亲一样。至少应该道个别，即使我不会离开太久。"
        translate None lucius_fight_1346:
            play sound "sounds/sfx/knock.ogg" fadeout 1.0
            "赛恩重重地敲了敲门，然后推开了大门。"


        window hide dissolve

        scene bg primrose
        with dissolve
        window show dissolve
        translate None lucius_fight_1347:
            "樱草花\"和上次我们来时一模一样。温暖而舒适。"
        translate None lucius_fight_1348:
            show ashe n sur at right
            show cyne nw smi cloak at center
            show raen nw neu cloak at left
            with dissolve
            a "赛恩！雷恩！"
        translate None lucius_fight_1349:
            a "你们两个…我以为你们死了！"
        translate None lucius_fight_1350:
            p "爸爸…他们是谁..？"
        translate None lucius_fight_1351:
            show ashe n smi with dis
            a "…别担心，亲爱的。现在上楼去吧，好吗？"
        translate None lucius_fight_1352:
            p "但是…我想等伊尔兰和维拉斯到了再说…"
        translate None lucius_fight_1353:
            "他揉乱了她的头发，脸上始终带着微笑。"
        translate None lucius_fight_1354:
            a "他们很快就会来的，我确定。他们不会错过见你的机会。"
        translate None lucius_fight_1355:
            "她跑上楼去，一路蹦蹦跳跳地唱着歌。"
        translate None lucius_fight_1356:
            show cyne nw sad with dis
            c "她真的长大了这么多…"
        translate None lucius_fight_1357:
            a "她现在让我如此强烈地想起她的母亲。"
        translate None lucius_fight_1358:
            show ashe n neu with dis
            a "…你们两个怎么了？其他人呢？"
        translate None lucius_fight_1359:
            c "…我们很好。伊尔兰和维拉斯也都安好。我肯定他们会想亲自和你聊聊。"
        translate None lucius_fight_1360:
            c "我要离开了。不知道会离开多久。我…我只是想告诉你…"
        translate None lucius_fight_1361:
            a "…你已经成长为一个坚强的人了，赛恩。"
        translate None lucius_fight_1362:
            c "...."
        translate None lucius_fight_1363:
            "他迈步上前，张开双臂紧紧抱住赛恩，给了他一个有力的拥抱，随后松开手臂端详起对方的脸庞。"
        translate None lucius_fight_1364:
            show ashe n smi with dis
            a "我不会再问更多问题了。照顾好你自己。"
        translate None lucius_fight_1365:
            show ashe n sur with dis
            a "不过…看看你这身衣服！太狼狈了！"
        translate None lucius_fight_1366:
            show raen nw smi with dis
            rs "哈哈哈…我想我被刺的次数太多了…对不起毁了你的手工。"
        translate None lucius_fight_1367:
            a "我能做的最起码的事就是迅速把它修补好。你就站在原地别动。"
        translate None lucius_fight_1368:
            "他跑上楼拿来针线盒。整个下午我们都在和他聊天，缝补衣物，还认识了他女儿。"
        translate None lucius_fight_1369:
            "我们离开时，阿什对赛恩露出悲伤的笑容，我能看出来如果我们再多待一秒他就会哭出来。"
        translate None lucius_fight_1370:
            c "我会回来的，我保证。"
        translate None lucius_fight_1371:
            show ashe n smi with dis
            a "你最好说到做到。"

        window hide dissolve

        scene bg sc sunset with dissolve
        window show dissolve
        translate None lucius_fight_1372:
            "说完这些，我们便离开了，退回到锡德卡汉寒冷的微风中。"
        translate None lucius_fight_1373:
            "我们缓缓地踏雪而归。就在几天前我们还在打雪仗、嬉戏玩耍…"
        translate None lucius_fight_1374:
            "一切都已经改变了太多。"
        translate None lucius_fight_1375:
            "我们发现卡斯皮安和艾米尔正往赛恩的马车上打包行李，埃瑟坐在驾驶座上。"
        translate None lucius_fight_1376:
            "福恩也在那里。他看起来轻松多了。显然与提图斯的那番谈话对他很有帮助。"


    if leos_route:
        translate None lucius_fight_1377:
            "外面，太阳开始微弱地照耀着锡德卡汉。一辆马车等候着我们，虽然这次换了不同的车夫。"
        translate None lucius_fight_1378:
            "赛恩早已离开，但福恩坐在后面—等待着重返森林开始重建工作。"
        translate None lucius_fight_1379:
            "卡斯皮安和艾米尔迅速回去拿他们的物品，把我留给了莱奥斯。"
        translate None lucius_fight_1380:
            "当你不知道何时才能再次相见时，你该如何向人开口？"
        translate None lucius_fight_1381:
            rs c wsad "莱奥斯，我…"
        translate None lucius_fight_1382:
            l c wthi "别说再见，好吗？我还是没法面对告别。"
        translate None lucius_fight_1383:
            rs "…..我每天都会想念你，直到我能回来。"
        translate None lucius_fight_1384:
            l "在那里别太安逸了。"
        translate None lucius_fight_1385:
            rs "我不能…我无法没有你…"
        translate None lucius_fight_1386:
            "我凝视着清晨的街道，最后一次将景致尽收眼底，许久都不会再见了。那远处的山峰，那石砌的钟楼尖顶。"
        translate None lucius_fight_1387:
            "还有莱奥斯。我曾爱过的人。"
        translate None lucius_fight_1388:
            "卡斯皮安和艾米尔抱着装满卡斯皮安物品的箱子回来了。"


    translate None lucius_fight_1389:
        rs c wsmi "都收拾好了？"
    translate None lucius_fight_1390:
        cas smi "嗯，能带的都带了，钥匙留给邻居。他们会照看房子。"


    if cyne_route:
        translate None lucius_fight_1391:
            "埃瑟招呼我们进屋，大家很快放松下来。我恋恋不舍地最后望了一眼这座城市。"
        translate None lucius_fight_1392:
            "这是一段漫长的旅程，但我们做到了。"
        translate None lucius_fight_1393:
            "我会想念这座城市，想念这里的人。"


    if leos_route:
        translate None lucius_fight_1395:
            "在率先登上马车前，我踮起脚尖站在莱奥斯面前，在他唇上落下轻柔一吻。"
        translate None lucius_fight_1396:
            rs c wneublu "我爱你。我们很快会再见面的。"
        translate None lucius_fight_1397:
            l c wneublu "……越快越好。"
        translate None lucius_fight_1398:
            rs "嘿，快点…你倒是也说句话啊…"
        translate None lucius_fight_1399:
            l "...."
        translate None lucius_fight_1400:
            l "…我也爱你。"
        translate None lucius_fight_1401:
            "这就是我踏入马车前，我们最后的对话。"
        translate None lucius_fight_1402:
            "司机跟我们打了招呼就开始驶离。我看着莱奥斯的身影在后窗渐渐变小，挥着手，尽力忍住泪水。"


    if fawn_route:
        translate None lucius_fight_1403:
            "车夫迎我们上车，众人安顿妥当。我深情地最后回望这座城市。"
        translate None lucius_fight_1404:
            "这是一段漫长的旅程，但我们做到了。"
        translate None lucius_fight_1405:
            "我会想念这座城市，想念这里的人。"
        translate None lucius_fight_1406:
            rs c wsmi "…我们回家吧。"
        translate None lucius_fight_1407:
            f c wsmi "…嗯。"



    scene black with Fade(1.0, 1.0, 1.0)
    translate None lucius_fight_1408:
        "返程比来时平静得多。车夫没在夜里逃跑，我们也没再碰上凶杀迷案。"
    translate None lucius_fight_1409:
        "路途漫长，我们多次停下吃喝补给—但我们主要的心思都放在返回奥雷利亚卡维拉上。"
    translate None lucius_fight_1410:
        "还有时间可以思考。"
    translate None lucius_fight_1411:
        "关于我的未来会怎样，以及我是否认同这样的未来。"


    if leos_route:
        translate None lucius_fight_1412:
            "关于我将如何安身立命，若是莱奥斯陪伴在侧的话。"

    translate None lucius_fight_1413:
        "五天后的夜晚，我们终于抵达奥雷利亚卡维拉周边的森林。马车无法继续前行，因为根本没有通向镇子的路。"


    if cyne_route or leos_route:
        translate None lucius_fight_1414:
            "就在那里，我们与福恩相拥而泣、依依惜别，并约定不久后再相会。"


    scene bg forestnight with Fade(1.0, 1.0, 1.0)
    translate None lucius_fight_1415:
        cas sad "感觉就像昨日我才蹦蹦跳跳地穿过这里…"
    translate None lucius_fight_1416:
        rs c wsad "对我而言这或许没那么久远，但我感同身受…"
    translate None lucius_fight_1417:
        ae neu "…接下来会发生什么？"
    translate None lucius_fight_1418:
        cas neu "嗯…"
    translate None lucius_fight_1419:
        "他们两人满含期盼地朝我看过来，脸上写满了期待。"
    translate None lucius_fight_1420:
        rs c wsur "怎么，你在期待我给你什么吗？"
    translate None lucius_fight_1421:
        ae "你有资格角逐的不止一个头衔。"
    translate None lucius_fight_1422:
        rs c whap "别犯傻了。我才不会替你收拾所有烂摊子。"


    if cyne_route:
        translate None lucius_fight_1423:
            c c wsad "天哪，你这样不是给他添太多麻烦了吗？"

    translate None lucius_fight_1424:
        ae sur "可…可是…你应该—"
    translate None lucius_fight_1425:
        rs c wsmi "嗯…不，我不这么认为。"
    translate None lucius_fight_1426:
        rs "你们两个要解决多年前犯下的过错，带领这个小镇走向未来。"


    if leos_route:
        translate None lucius_fight_1427:
            rs "总之…有人在锡德卡汉等着我。"

    translate None lucius_fight_1428:
        cas sur "那么…为何要大老远跑来？"
    translate None lucius_fight_1429:
        rs c wsmi "因为我想见见大家，也想兑现对维拉斯的承诺。"
    translate None lucius_fight_1430:
        "艾米尔和卡斯皮安对视了一眼，或许在思量即将要做的工作—但却露出了微笑。"
    translate None lucius_fight_1431:
        ae smi "我想我们能办到。"
    translate None lucius_fight_1432:
        cas smi "我也是。"


    if fawn_route:
        translate None lucius_fight_1433:
            f c wsur "雷恩…？我还以为我们也会留下。"
        translate None lucius_fight_1434:
            rs c wsmi "仅仅因为有人决定了那该是我的宿命？我想我宁愿与你共同寻找属于我们自己的未来，如果你愿意接受我的话。"
        translate None lucius_fight_1435:
            f c wsmi "….是啊，我也觉得这才是正确答案。"
        translate None lucius_fight_1436:
            "我抓住福恩的手，紧紧握住。"



    if cyne_route:
        translate None lucius_fight_1437:
            c "我承认，我确实以为你带我远道而来是要我留在这里。"
        translate None lucius_fight_1438:
            rs "难道就因他人擅自决定我的命运？我宁愿我们一起开辟前路，如果你不介意的话。"
        translate None lucius_fight_1439:
            c c wsmi "对我来说这可有意思多了。"
        translate None lucius_fight_1440:
            "我抓住赛恩的手，嘴角立即漾起笑意。"


    if leos_route:
        translate None lucius_fight_1441:
            rs "…我想开辟自己的道路，让所有人都为我骄傲。也许看起来像在逃避，但…我只是还没准备好。"

    translate None lucius_fight_1442:
        rs c wsmi "艾米尔，你能驱散这雾气吗？"
    translate None lucius_fight_1443:
        ae neu "我想可以。"
    translate None lucius_fight_1444:
        rs c wneu "……你们能答应我一件事吗？你们两个人。"
    translate None lucius_fight_1445:
        rs "告诉他们真相。让他们自己选择去留。"
    translate None lucius_fight_1446:
        stop music fadeout 3.0
        "不久后，奥雷利亚卡维拉已遥遥在望。清晨时分万籁俱寂，我们轻松地溜出树林进入街道。"

    window hide dissolve


    scene bg aureliacavelladay with Fade(1.0, 1.0, 1.0)
    window show dissolve
    play music "sounds/bgm/op.ogg" fadein 4.0
    translate None lucius_fight_1447:
        cas sur "….它一点儿都没变。"
    translate None lucius_fight_1448:
        ae smi "欢迎回家，卡斯。"
    translate None lucius_fight_1449:
        ae hur "…呃.."
    translate None lucius_fight_1450:
        rs c wsur "怎么了？"
    translate None lucius_fight_1451:
        ae "我几乎已经习惯了听不到他们的声音…"
    translate None lucius_fight_1452:
        rs c wsad "…我们必须立刻解救他们。"
    translate None lucius_fight_1453:
        u "谁在…"
    translate None lucius_fight_1454:
        "有人沿着道路向我们跑来，一路大喊大叫着。我转过身去，看见…"
    translate None lucius_fight_1455:
        "女院长。"
    translate None lucius_fight_1456:
        show raen nw sur cloak at farright
        show matron ope at slightright
        show caspian n sur at cenleft
        show ds n sur at farleft
        with dissolve
        ma "雷恩！你刚才去哪儿了，我—"
    translate None lucius_fight_1457:
        ma "我……我……"
    translate None lucius_fight_1458:
        ma "卡斯皮安……？艾米尔……？"
    translate None lucius_fight_1459:
        show caspian n smi with dis
        cas "嗨，阿拉拉。好久不见了。"
    translate None lucius_fight_1460:
        ma "...."
    translate None lucius_fight_1461:
        ma "你……"
    translate None lucius_fight_1462:
        cas "啊哈哈…"
    translate None lucius_fight_1463:
        show matron ang with dis
        ma "你这个混蛋！你到底死哪去了？！"
    translate None lucius_fight_1464:
        show caspian n sur with dis
        cas "哇，等一下—"
    translate None lucius_fight_1465:
        ma "你一直都是个麻烦精，知道吗？！我以为你死了！整整十八年你音讯全无！"
    translate None lucius_fight_1466:
        cas "我…我很抱歉…？"
    translate None lucius_fight_1467:
        ma "光是道歉不够！"
    translate None lucius_fight_1468:
        ma "还有你…你一次都没来找过我或探望我！"
    translate None lucius_fight_1469:
        show ds n sad with dis
        "艾米尔低下了头。"
    translate None lucius_fight_1470:
        ae "对不起…"
    translate None lucius_fight_1471:
        ma "你们两个，傻小子…"
    translate None lucius_fight_1472:
        ma "..我太想你们了！"
    translate None lucius_fight_1473:
        "她紧紧抱住两人，泪水顺着脸颊滑落。"
    translate None lucius_fight_1474:
        cas "我这次会留下来，我保证。"
    translate None lucius_fight_1475:
        ma "你们最好已经和好了，否则神也救不了你们。"
    translate None lucius_fight_1476:
        ae "我们和好了，夫人…"
    translate None lucius_fight_1477:
        show matron smi with dis
        ma "毕竟，争吵不符合未来国王和他的言者身份。"
    translate None lucius_fight_1478:
        show caspian n smi with dis
        cas "…看来我当初该更认真听你讲课。"
    translate None lucius_fight_1479:
        show matron ang with dis
        ma "少耍贫嘴。"
    translate None lucius_fight_1480:
        ma "还有雷恩，你到底去哪了？"
    translate None lucius_fight_1481:
        show raen nw smi with dis
        rs "噢，你知道的。四处游荡。"


    if cyne_route or fawn_route:
        translate None lucius_fight_1482:
            rs "我有个人想介绍给你。"
        translate None lucius_fight_1483:
            ma "...?"


    if cyne_route:
        translate None lucius_fight_1484:
            rs "这是赛恩…他是我的…"
        translate None lucius_fight_1485:
            c c whap "未婚夫！"
        translate None lucius_fight_1486:
            show raen nw sur blush with dis
            rs "...!"
        translate None lucius_fight_1487:
            rs "赛恩！我…我本来想说得更委婉些…！"
        translate None lucius_fight_1488:
            rs "他是…我爱的人。"
        translate None lucius_fight_1489:
            ma "啊…？"
        translate None lucius_fight_1490:
            ma "好吧，赛恩…很高兴认识你。希望你一直在照顾雷恩。"
        translate None lucius_fight_1491:
            c c wsmi "…主要都是他在照顾我，但我会尽力。"
        translate None lucius_fight_1492:
            rs "..."
        translate None lucius_fight_1493:
            show raen nw smi -blush with dis
            rs "啊哈哈哈。"


    if leos_route:
        translate None lucius_fight_1494:
            rs "…我遇到了对我很重要的人。希望…有天能介绍给你们。不过听起来你们好像见过一次。"
        translate None lucius_fight_1495:
            ma "…我会敞开心扉欢迎。"


    if fawn_route:
        translate None lucius_fight_1496:
            rs "这是福恩。我爱他。"
        translate None lucius_fight_1497:
            f c wemb "什—…雷恩！"
        translate None lucius_fight_1498:
            rs "别害羞，这是事实。"
        translate None lucius_fight_1499:
            ma "..."
        translate None lucius_fight_1500:
            ma "好吧，福恩…很高兴认识你。希望你一直在照顾雷恩。"
        translate None lucius_fight_1501:
            f "我..我会尽力的，夫人，所以您…您可以把托付给我！"
        translate None lucius_fight_1502:
            rs "..."
        translate None lucius_fight_1503:
            rs "啊哈哈哈。"

    translate None lucius_fight_1504:
        ma "孩子们都想你。告诉我你要回孤儿院吗？"

    show raen nw sad with dis

    if cyne_route or fawn_route:
        translate None lucius_fight_1505:
            rs "…对不起，女院长。"


    if leos_route:
        translate None lucius_fight_1506:
            rs "…会回去住一阵子，但…"

    translate None lucius_fight_1507:
        ma "...."
    translate None lucius_fight_1508:
        ma "你真是像极了你父亲。"
    translate None lucius_fight_1509:
        ma "那我相信你不会走太远。要比卡斯皮安更孝顺，至少接下来的十八年里来看我{i}一次{/i}。"
    translate None lucius_fight_1510:
        rs "我会尽可能常来，我保证。您甚至不会注意到我离开。"
    translate None lucius_fight_1511:
        rs "艾米尔…不，言者…你知道怎么解救他们吗？"
    translate None lucius_fight_1512:
        ae "…我想是的。很简单。"
    translate None lucius_fight_1513:
        show raen nw sur with dis
        rs "…怎么做？"
    translate None lucius_fight_1514:
        "他闭上双眼，将脸庞仰向天空。"
    translate None lucius_fight_1515:
        ae "…我能听见他们所有人的声音。答案很简单。我本可以一直这样做。"
    translate None lucius_fight_1516:
        ae "完成了。这是…至寂…"
    translate None lucius_fight_1517:
        rs "等等，什么？你干什么了？"
    translate None lucius_fight_1518:
        ae "……如此简单，却又一直超乎我的理解……原来我只需要放下那道屏障……"
    translate None lucius_fight_1519:
        ae "我从未接受它们的本质—只觉得它们的嗓音令人厌烦。"
    translate None lucius_fight_1520:
        ae "但…这就是我的使命。保护我的子民，守护我们的神明。为此，我必须真正倾听他们的心声。"
    translate None lucius_fight_1521:
        ae "……从来没有人接纳过他们。卢修斯没有，在他之前的历任说书人也没有……"
    translate None lucius_fight_1522:
        rs "如此简单…"
    translate None lucius_fight_1523:
        show raen nw sad with dis
        rs "我好开心。终于……"


    if fawn_route:
        translate None lucius_fight_1524:
            f c wsmi "已经感觉如此…自由。"

    translate None lucius_fight_1525:
        rs "一切都结束了…"
    translate None lucius_fight_1526:
        show matron ang with dis
        ma "我不这么认为。卡斯皮安、艾米留斯，你们俩还有很多活要干。"
    translate None lucius_fight_1527:
        show caspian n sad with dis
        cas "我不确定我能否做到这件事，除非你也在场…"
    translate None lucius_fight_1528:
        ma "..你知道的，我还得经营一家孤儿院。"
    translate None lucius_fight_1529:
        cas "我知道你能两者兼顾。"
    translate None lucius_fight_1530:
        ma "真不要脸…"

    hide matron
    hide raen
    hide caspian
    hide ds
    with dissolve


    if leos_route:
        translate None lucius_fight_1531:
            "他们三人转身开始行走，交谈并叙旧。我微笑着，跟在他身后。"
        translate None lucius_fight_1532:
            "我的心乞求着我跑回莱奥斯身边—但我知道我必须先在这里完成工作。去说服民众，去协助我的父亲和说书人。 "
        translate None lucius_fight_1533:
            "为确保所有人都了解真相。"
        translate None lucius_fight_1534:
            "等我做完该做的事，就该去找莱奥斯了。"


        scene black with Fade(1.0, 1.0, 1.0)
        translate None lucius_fight_1535:
            "不知不觉间，日子一天天过去，转眼已是数周，继而一月。"
        translate None lucius_fight_1536:
            "白天我让自己忙碌不堪，但每到夜里……我的梦里全是莱奥斯的怀抱。"
        translate None lucius_fight_1537:
            "而那时机终于来临。"
        translate None lucius_fight_1538:
            "我收拾好行囊，独自面对那片森林。一条新修的道路从中穿过，一直延伸到斯塔格威奇。"
        translate None lucius_fight_1539:
            "我一路跟随前行—途中遇到了福恩，接着又遇见莱拉斯。我与她一同前往奥克斯哈伯，在她店铺稍作停留取了件特别物品，而后我们动身前往锡德卡汉。"

        stop music fadeout 2.0

        scene bg sc night with Fade(1.0, 1.0, 1.0) # put in pan here
        translate None lucius_fight_1540:
            "这景象我几乎都要遗忘了。"
        translate None lucius_fight_1541:
            play music "sounds/bgm/night.ogg" fadein 3.0
            "但我来此不为看风景。"
        translate None lucius_fight_1542:
            "我匆匆穿过街巷，手指不安地摩挲着衣服下的装束。 "
        translate None lucius_fight_1543:
            "是有点难为情，但莱拉斯坚称这是久别重逢时迎接爱人的唯一正确方式。"
        translate None lucius_fight_1544:
            "我跑过街道来到我以为能找到莱奥斯的地方—扎林的实验室。"


        scene bg zarryn with hpunch
        translate None lucius_fight_1545:
            "刚敲一下门就开了，我立刻扑进他的臂弯。"
        translate None lucius_fight_1546:
            rs whap "莱奥斯…！"
        translate None lucius_fight_1547:
            l wsur "雷恩…你…你回来了..？"
        translate None lucius_fight_1548:
            "我们跌跌撞撞地趴倒在壁炉前的地板上。房间里空无一人，但炉火仍在燃烧。扎林和提图斯似乎都不在家。"
        translate None lucius_fight_1549:
            rs wsmi "对不起耽搁了这么久…！"
        translate None lucius_fight_1550:
            l wsmu "我好想你……"
        translate None lucius_fight_1551:
            rs wsad "我也是…简直度日如年…"
        translate None lucius_fight_1552:
            rs wsmi "但我再也不会离开你了，听到了吗？！"
        translate None lucius_fight_1553:
            l "……很好，因为我肯定受不了那种局面。"
        translate None lucius_fight_1554:
            "我俯身吻他，将身体紧紧贴上去。"
        translate None lucius_fight_1555:
            stop music fadeout 3.0
            rs "还有别人在吗？"
        translate None lucius_fight_1556:
            l wneu "没有，他们明天才回来。"
        translate None lucius_fight_1557:
            rs wneublu "好的，因为…呃…"
        translate None lucius_fight_1558:
            l "出了什么问题吗？"
        translate None lucius_fight_1559:
            play music "sounds/bgm/sex.ogg"

            rs "不，我…我给你准备了礼物。"
        translate None lucius_fight_1560:
            "天啊，事到临头反而害羞了…拜托告诉我莱拉斯说得没错…"
        translate None lucius_fight_1561:
            "慢慢地，我从仍躺在地上的莱奥斯身边坐起，一层层剥去衣物，直到能看清我身上穿的内衣。"
        translate None lucius_fight_1562:
            rs "....."
        translate None lucius_fight_1563:
            l wemb "........."
        translate None lucius_fight_1564:
            rs "这看起来是不是太蠢了…？"
        translate None lucius_fight_1565:
            rs wsur "啊！"
        translate None lucius_fight_1566:
            "转眼间他就把我翻倒在床，身上那点布料几乎算不得内衣。"
        translate None lucius_fight_1567:
            l wemb "你以这副模样…这副姿态回到我身边时，叫我如何自持？"
        translate None lucius_fight_1568:
            "他的话让我不由自主地抽动了一下。见到他本已让我兴奋不已，而这种被完全暴露的羞耻感加上他的话语，更让我浑身发烫。"
        translate None lucius_fight_1569:
            "他的吻沿着我的身体向下游走，指尖所到之处都引发我喉间难以自抑的低沉呻吟。"
        translate None lucius_fight_1570:
            "我伸手想隔着裤子感受他的反应，但他却把我的手拍开了。"
        translate None lucius_fight_1571:
            rs wemb "嘿…"
        translate None lucius_fight_1572:
            l "我正在忙，别干扰我。"
        translate None lucius_fight_1573:
            "他的嘴凑近我腰间单薄的布料，手指摸索着上面的花纹，同时他的头越来越往下移，最终隔着裤子亲吻我那早已坚挺、渴求从织物束缚中解放出来的阴茎。"
        translate None lucius_fight_1574:
            "他的吻落在顶端，手指顺着柱身滑下。透若薄纱的触感截然不同—某种意义上，更加淫靡。"
        translate None lucius_fight_1575:
            rs wemb "莱… 莱奥斯，求求你…"

        translate None lucius_fight_1576:
            rs "啊…！嗯…哈…"
        translate None lucius_fight_1577:
            "他将内裤拨到一边，迅速将我下身含入口中。他轻松地将我吞至喉间，嘴唇紧紧包裹并前后摆动头部。"
        translate None lucius_fight_1578:
            rs "啊…莱奥斯…"
        translate None lucius_fight_1579:
            "我拼命想抓住些什么，却只能摸到莱奥斯的头颅。我紧紧抓住，轻轻扯动他的头发。"
        translate None lucius_fight_1580:
            "他发出闷哼，那股震颤仿佛传遍了我全身。"
        translate None lucius_fight_1581:
            "他的舌头沿着我下身底部舔舐而上，全程都紧盯着我的眼睛。"
        translate None lucius_fight_1582:
            "羞耻感让我想移开视线，却根本无法做到—他的魅力令人恍惚。"
        translate None lucius_fight_1583:
            "他每个动作都如此精准，如此完美。"
        translate None lucius_fight_1584:
            rs "嗯嗯…你该不会…专门练习过吧…？"
        translate None lucius_fight_1585:
            l "我只是花了很长时间幻想着你而已。"
        translate None lucius_fight_1586:
            "他用手环绕着我，我能感觉到自己在他掌中的脉动。"
        translate None lucius_fight_1587:
            l "但实际比任何想象都美妙。"
        translate None lucius_fight_1588:
            rs "我…我也是…"
        translate None lucius_fight_1589:
            "他用舌头缓缓扫过顶端，再次将我完全纳入。同时伸手拉开不远处抽屉，取出我见过的小瓶子。"
        translate None lucius_fight_1590:
            rs "你居然…一直留着这个…？"
        translate None lucius_fight_1591:
            l "这相当方便，不是吗？我应该给伊尔兰发个感谢。也许再加个礼物篮。"
        translate None lucius_fight_1592:
            "蘸着滑液，他绕到后方将一根手指缓缓推入。突如其来的凉意让我倒抽口气，但随着深入很快变得滚烫，在他指节周围舒展。"
        translate None lucius_fight_1593:
            l "你快把我逼疯了…我不知道还能忍多久…"
        translate None lucius_fight_1594:
            "他的脑袋随着节奏加快上下晃动，原本轻微的呻吟很快变成了大声的呻吟。"
        translate None lucius_fight_1595:
            "他的第二根手指跟着第一根插入，戳刺那个让我的全身都酥麻的点。"
        translate None lucius_fight_1596:
            rs "啊…就是那里…"
        translate None lucius_fight_1597:
            "我愉悦地颤抖着，绝望地将他头发抓得更紧，仿佛那是让我保持理智的最后救命稻草。"
        translate None lucius_fight_1598:
            "当我透过半闭的眼睑向下看莱奥斯时，能看到他已从裤子里掏出自己，液体已经覆满了全身。"
        translate None lucius_fight_1599:
            "在他伸手涂抹前，我握住他的阴茎帮忙—它已经如此坚硬滚烫，我几乎想求他立即进入我体内。"
        translate None lucius_fight_1600:
            window hide dissolve

            scene gallery_143
            if persistent.streamer_mode:
                show leos_3_sex_censor

            with dissolve

            window show dissolve
            "但这已无必要。他将嘴从我坚挺上移开，并抽出了手指。当我不自觉地发出渴求的呜咽时，却感到某个更为硕大钝圆之物正抵了上来。"
        translate None lucius_fight_1601:
            rs "去…嗯…慢一点，好吗…？"
        translate None lucius_fight_1602:
            l "我会…我会尽力的…"
        translate None lucius_fight_1603:
            "起初很缓慢，他渐渐进入我体内，他的阳具撑开我的下体入口。感觉滚烫无比，比他手指的温度要高得多。"
        translate None lucius_fight_1604:
            "他推进至完全没入。"
        translate None lucius_fight_1605:
            "这个感觉我也怀念已久…那种紧密相连的感觉，没有任何人能介入我们之间…"
        translate None lucius_fight_1606:
            "知道我是唯一能看到他这副模样的人，这让我更加兴奋。我咬住嘴唇，祈求自己的身体再坚持一会儿别那么快达到高潮。"
        translate None lucius_fight_1607:
            l "还…哈啊…还好吗？"
        translate None lucius_fight_1608:
            rs "嗯…"
        translate None lucius_fight_1609:
            "我只能发出一声简单的\"嗯\"。这远不止是可以—尽管感觉很紧，我已开始享受被他填满时那种被撑到极限的感觉。"
        translate None lucius_fight_1610:
            "他开始缓慢抽送，不时确认我的状况。"
        translate None lucius_fight_1611:
            "他就是这副德行，对吧？"
        translate None lucius_fight_1612:
            "我一直认为他是如此冷漠，如此粗鲁，如此傲慢，但内心深处…"
        translate None lucius_fight_1613:
            "他一向都是这么个软心肠的人，不是吗…？"
        translate None lucius_fight_1614:
            rs "这…这种感觉太舒服了…"
        translate None lucius_fight_1615:
            "他的抽插速度迅速加快，我几乎抑制不住自己的尖叫。每次他顶进来时我的视线都会泛白，脑海完全被快感占据。"
        translate None lucius_fight_1616:
            l "妈的，我好想你。"
        translate None lucius_fight_1617:
            rs "我也很想你…莱奥斯，我…"
        translate None lucius_fight_1618:
            l "..我真的很爱你。"
        translate None lucius_fight_1619:
            rs "我…我也是！"
        translate None lucius_fight_1620:
            "他的话足以让我失去理智。当他继续在我体内抽插时，我直接高潮了，就像不久前在那个秘密村的夜晚一样。"
        translate None lucius_fight_1621:
            l "嗯..啊…"
        translate None lucius_fight_1622:
            "他的眉头皱起，脸上浮现不悦。我急促喘息着，几乎无法让肺部获得足够空气。"
        translate None lucius_fight_1623:
            "就在我感觉他即将到达时，他俯身吻了我，在我能感受到他在我体内终于释放之前。"
        translate None lucius_fight_1624:
            "他的手臂颤抖着竭力支撑身体。我笑着把他拉下来，让他全身重量压在我身上，然后紧紧搂住他。"
        translate None lucius_fight_1625:
            "那一刻我明白了，我再也不会让他离开。"


        if achievement.has("leos_goodend"):
            pass
        else:
            $ renpy.display_notify("成就已解锁：一个深得我心的刺客（注意：不是指字面上的\"得到我的心脏\"）")

        python:
            achievement.grant("leos_goodend")
            achievement.sync()

        translate None lucius_fight_1626:
            l "欢迎回家，雷恩。"

        window hide dissolve
        scene black with dissolve
        $ quick_menu = False
        call screen credits_end with dissolve

        label leos_route_afterending:
            $ quick_menu = True

            scene bg fantasy city with Fade(1.0, 1.0, 1.0):
                subpixel True xpos 0.5 ypos 1.31 xanchor 0.5 yanchor 1.0 zoom 1.41 rotate None
                parallel:
                    xpos 0.71
                    linear 25.0 xpos 0.31
            window show dissolve
            play music "sounds/bgm/forgotten.ogg" fadein 2.0
            translate None lucius_fight_1628:
                "又一座陌生城市，远离我曾经熟知的一切。"
            translate None lucius_fight_1629:
                "但无论我去到哪里，这都无关紧要，因为我的家始终与我同在—莱奥斯。"
                scene bg fantasy city
                show raen nw dark cloak neu at slightright
                show leos nw dark cloak neu at slightleft
                with dissolve
            translate None lucius_fight_1630:
                rs "这份合同是用来做什么的来着？"
            translate None lucius_fight_1631:
                l "有时候我真怀疑你是不是有记忆问题。"
            translate None lucius_fight_1632:
                show raen nw dark cloak sad with dis
                rs "别这样，我已经尽力了…！只是刚开始不熟练而已。"
            translate None lucius_fight_1633:
                show leos nw dark cloak sur with dis
                l "哈…又有恶魔目击报告，不过上次结果发现是个喜欢深夜散步的老太太。"
            translate None lucius_fight_1634:
                l "如果我们大老远跑来就为了再看那种垃圾…"
            translate None lucius_fight_1635:
                show raen nw dark cloak smi with dis
                rs "那我们可以帮老太太拎购物袋回家！"
            translate None lucius_fight_1636:
                l "这根本不是重点。你确定自己适合当赏金猎人吗？"
            translate None lucius_fight_1637:
                rs "我只是喜欢帮助别人。不过真要遇到恶魔还挺吓人的，对吧？"
            translate None lucius_fight_1638:
                l "老实说找到什么都无所谓，能赚钱就行。"
            translate None lucius_fight_1639:
                rs "这种想法可不对。你太消极了。"
            translate None lucius_fight_1640:
                l "而你又太理想主义。总想着拯救世界是吗？"
            translate None lucius_fight_1641:
                rs "而你就爱这样的我。"
            translate None lucius_fight_1642:
                show leos nw dark cloak thi blush with dis
                "莱奥斯低声嘟囔着，但没再反驳。"
            translate None lucius_fight_1643:
                "我们在夜色中潜行，终于找到目的地。"


            if iv_scene_four:
                translate None lucius_fight_1644:
                    i fli "哎呀呀，看看是谁姗姗来迟。"
                translate None lucius_fight_1645:
                    show leos nw dark cloak pis -blush with dis
                    l "哦老天，现在就杀了我吧。"
                translate None lucius_fight_1646:
                    v smi "你好，雷恩。最近怎么样？"
                translate None lucius_fight_1647:
                    rs "我过得很好！"
                translate None lucius_fight_1648:
                    i "很遗憾告诉你那些悬赏目标已经被解决了。你或许该去试试隔壁镇子。"
                translate None lucius_fight_1649:
                    l "是是，随便吧。"
                translate None lucius_fight_1650:
                    i "下次动作快点。"
                translate None lucius_fight_1651:
                    v "我们应当尝试合作而非对立。"
                translate None lucius_fight_1652:
                    l "不用了。再见。"
                translate None lucius_fight_1653:
                    show raen nw dark cloak sur with dis
                    rs "嘿，莱奥斯…"
                translate None lucius_fight_1654:
                    i neu "等等。我其实正想找你。"
                translate None lucius_fight_1655:
                    i "…我有消息要告诉你。索伦醒了，他正在找你。"
                $ persistent.prequel_ad = True
                $ persistent.game_first_opened = True

                window hide dissolve
                scene black with Dissolve(3.0)
                return




            if not iv_scene_four:
                translate None lucius_fight_1656:
                    i neu "省省吧，已经解决了。"
                translate None lucius_fight_1657:
                    show leos nw dark cloak pis -blush with dis
                    "伊尔兰从阴影中走出。身边空无一人。"
                translate None lucius_fight_1658:
                    show raen nw dark cloak sad with dis
                    "一想到他经历过的痛苦，我的心就隐隐作痛，现在他彻底孤身一人了。"
                translate None lucius_fight_1659:
                    l "真棒。纯属浪费时间。"
                translate None lucius_fight_1660:
                    "莱奥斯转身要走，突然被叫声唤住。"
                translate None lucius_fight_1661:
                    i "我一直在找你们。"
                translate None lucius_fight_1662:
                    i "…索伦醒了，他正在找你。"
                $ persistent.prequel_ad = True
                $ persistent.game_first_opened = True
                window hide dissolve
                scene black with Dissolve(3.0)
                return





    if cyne_route or fawn_route:
        translate None lucius_fight_1663:
            "三人转身前行，边走边叙旧。见我没跟上，他们停下脚步。"
        translate None lucius_fight_1664:
            rs c wsmi "我保证…很快就会回来的。"
        translate None lucius_fight_1665:
            cas smi "你最好说到做到。"
        translate None lucius_fight_1666:
            ae neu "注意安全。"
        translate None lucius_fight_1667:
            rs "等我回来时，至少该有条修好的路。"
        translate None lucius_fight_1668:
            ma clo "...?"
        translate None lucius_fight_1669:
            cas "明白，老大。"


    if fawn_route:
        translate None lucius_fight_1670:
            "朝阳下只剩我和福恩。"
        translate None lucius_fight_1671:
            show fawn nw cloak sad at slightleft
            show raen nw cloak smi at slightright
            with dissolve
            f "现在呢？这样各奔东西有点伤感。"
        translate None lucius_fight_1672:
            rs "我们也该走了，对吧？"
        translate None lucius_fight_1673:
            show fawn nw sur with dis
            f "这么快？"
        translate None lucius_fight_1674:
            rs "我们有很多事情要做，你知道的。"
        translate None lucius_fight_1675:
            f "比如…？"
        translate None lucius_fight_1676:
            rs "嗯…有整个树屋需要重建。"
        translate None lucius_fight_1677:
            show fawn nw sad with dis
            f "...."
        translate None lucius_fight_1678:
            show fawn nw smi with dis
            f "哦，雷恩，我真的爱你。"
        translate None lucius_fight_1679:
            show raen nw neu blush with dis
            rs "…我有样东西要给你。如果你不想要，别感到有压力，好吗？"
        translate None lucius_fight_1680:
            f "...?"
        translate None lucius_fight_1681:
            "我递出一块粉红色的小石头，挂在一根简单的链子上。"
        translate None lucius_fight_1682:
            rs "你对我意味着一切，福恩。我永远不想分开，而且…我希望你能接受这个。"
        translate None lucius_fight_1683:
            show fawn nw sur blush with dis
            f "你…真的要把它给我…？"
        translate None lucius_fight_1684:
            rs "很抱歉，我知道这很简单，但是…"
        translate None lucius_fight_1685:
            show fawn nw smi with dis
            f "我只愿与你共度余生，除此之外别无他求。"
        translate None lucius_fight_1686:
            show raen nw smi with dis
            rs "我也是。"
        translate None lucius_fight_1687:
            "我轻轻地把项链戴在他的头上，它小心翼翼地垂在他的胸前。"
        translate None lucius_fight_1688:
            rs "…很适合你。"
        translate None lucius_fight_1689:
            f "…等着瞧吧。你可能偷袭得手，但我会回赠你同样美丽的一击。"
        translate None lucius_fight_1690:
            rs "我正期待着这事儿呢。"
        translate None lucius_fight_1691:
            "我们手牵着手，望向那片森林。曾经是噩梦与恐惧的源头，如今已不同往昔。"

        if achievement.has("fawn_goodend"):
            pass
        else:
            $ renpy.display_notify("成就解锁：可否得到您的首肯？")

        python:
            achievement.grant("fawn_goodend")
            achievement.sync()

        translate None lucius_fight_1692:
            "感觉就像家一样温暖。"


        stop music fadeout 3.0
        window hide dissolve
        scene black with dissolve

        $ quick_menu = False
        call screen credits_end with dissolve
        label fawnroute_ending_Aftercredits:
            $ quick_menu = True
            scene bg treehouse2 with Fade(1.0, 1.0, 1.0)
            window show dissolve
            play music "sounds/bgm/night.ogg" fadein 2.0
            translate None lucius_fight_1694:
                f wsmi "我回来了！"
            translate None lucius_fight_1695:
                rs wsmi "终于！我要的东西你都带来了吗？"
            translate None lucius_fight_1696:
                f wsad "呃…番茄卖完了，不过我买到了其他所有东西！"
            translate None lucius_fight_1697:
                rs wsad "天啊…一家果蔬市场怎么会连西红柿都卖光了…"
            translate None lucius_fight_1698:
                f wneu "嗯…我不确定。我该回去问问看吗？"
            translate None lucius_fight_1699:
                rs wsmi "不了不了。缺几个番茄不会毁了我们的晚餐。"
            translate None lucius_fight_1700:
                rs "托比亚斯，米娅！"
            translate None lucius_fight_1701:
                t sad "什么？"
            translate None lucius_fight_1702:
                rs "过来帮我剥这些蔬菜。"
            translate None lucius_fight_1703:
                m sad "又来？！"
            translate None lucius_fight_1704:
                rs wneu "没错，再来一次。它们可不会自己剥落的。"
            translate None lucius_fight_1705:
                m "呃…"
            translate None lucius_fight_1706:
                rs wsmi"快点儿，我们走吧！"
            translate None lucius_fight_1707:
                "孩子们匆忙跑进屋里，一路上抱怨个不停，但我知道他们并不是真心的。"
            translate None lucius_fight_1708:
                f wsad "雷恩…现在我们一切都安顿好了，我打算很快回去看望埃利奥特。我对自己许下承诺，要学着控制自己的能力。"
            translate None lucius_fight_1709:
                rs "好吧，只要你别想丢下我单独行动。"
            translate None lucius_fight_1710:
                f wsur "..那孩子们怎么办？"
            translate None lucius_fight_1711:
                rs "反正他们都是分开住的。这只不过是和艾米尔还有我父亲一起多住些时日罢了。"
            translate None lucius_fight_1712:
                f wsmi"谢谢你，雷恩…"
            translate None lucius_fight_1713:
                "我将身子探出窗外，惬意地欣赏着风景。"
            translate None lucius_fight_1714:
                "我们的树屋离斯塔格威奇不远。想进镇随时都能去，我每周至少要去奥雷利亚卡维拉一次。"
            translate None lucius_fight_1715:
                "生活很美好。"
            translate None lucius_fight_1716:
                "当然，我们的房子不是一夜之间建成的。花费了数周时间，多亏了卡斯皮安的指导。"
            translate None lucius_fight_1717:
                "说来奇怪…国王竟亲自帮我们盖房子…"
            translate None lucius_fight_1718:
                "算了，最好别想太多。"
            translate None lucius_fight_1719:
                "正当我要关上窗板时，注意到有人朝屋子走来。红黑相间的…"
            translate None lucius_fight_1720:
                rs wsur  "莱奥斯…？"
            translate None lucius_fight_1721:
                l c wsmu "看来一个疯狂的森林住民变成了四个啊。"
            translate None lucius_fight_1722:
                rs "你这段时间去哪了？！自从…自从锡德卡汉之后就没见过你！"
            translate None lucius_fight_1723:
                l "冷静点，最多也就一个月。"
            translate None lucius_fight_1724:
                l "你了解我的。我一直很忙。"
            translate None lucius_fight_1725:
                rs wsmi "感觉已经过了好久…是什么风把你吹来了？"
            translate None lucius_fight_1726:
                l c wneu "…我带了消息。索伦…呃..他醒了。"
            $ persistent.prequel_ad = True
            $ persistent.game_first_opened = True

            window hide dissolve
            scene black with Dissolve(3.0)
            return



    if cyne_route:
        show cyne nw smi cloak at slightleft
        show raen nw smi cloak at slightright
        with dissolve
        translate None lucius_fight_1727:
            "赛恩和我被单独留在渐亮的晨光中。"
        translate None lucius_fight_1728:
            c "现在真的都结束了吗？"
        translate None lucius_fight_1729:
            rs "感觉像是这样，但…这难道不是另一个冒险的开始吗？"
        translate None lucius_fight_1730:
            show cyne nw sur with dis
            c "这么快就渴望新的冒险了？"
        translate None lucius_fight_1731:
            show raen nw sad with dis
            rs "我们至少能帮福恩重建家园，因为…你知道的，他的树屋烧毁多少和我有点关系。"
        translate None lucius_fight_1732:
            c "然后呢？"
        translate None lucius_fight_1733:
            rs "…这世上我还有太多地方未曾踏足。也许我们可以去旅行一阵子？"
        translate None lucius_fight_1734:
            c "你打算让我们怎么维持生计？我突然没了收入来源。"
        translate None lucius_fight_1735:
            show raen nw sur with dis
            rs "呃…说真的我还没想那么远，嗯…我们可以打点零工？"
        translate None lucius_fight_1736:
            c "你想让{i}我{/i}去打零工？"
        translate None lucius_fight_1737:
            rs "呃…"
        translate None lucius_fight_1738:
            show cyne nw smi with dis
            c "你知道吗…其实这主意挺完美。那我们还等什么？"
        translate None lucius_fight_1739:
            show raen nw smi blush with dis
            rs "赛恩…我太爱你了。"
        translate None lucius_fight_1740:
            show cyne nw smi blush with dis
            c "…我也爱你。"
        translate None lucius_fight_1741:
            "我们携手面向森林。尽管不久前这还是我被逼迫前来的地方，此刻却显得如此诱人。"
        translate None lucius_fight_1742:
            "我双手交握，凝视着心爱之人。"

        if achievement.has("cyne_goodend"):
            pass
        else:
            $ renpy.display_notify("成就达成：真是个好赛恩")

        python:
            achievement.grant("cyne_goodend")
            achievement.sync()
        translate None lucius_fight_1743:
            "我终于到家了。"

        stop music fadeout 3.0
        window hide dissolve

        scene black with dissolve
        $ quick_menu = False
        call screen credits_end with dissolve

        label cyne_after_credits_ending:

            $ quick_menu = True
            scene bg tavern with Fade(1.0, 1.0, 1.0)
            window show dissolve
            play music "sounds/bgm/Fooling Around Tiny.ogg" fadein 2.0
            translate None lucius_fight_1745:
                c wsur "这火怎么生不起来？！"
            translate None lucius_fight_1746:
                rs wsur "你才刚把它放上煎锅！等一分钟会死啊？！"
            translate None lucius_fight_1747:
                nik sur "喂，手稳点儿！你想把房子烧了吗！"
            translate None lucius_fight_1748:
                c wang "呃…不行，我做不到！"
            translate None lucius_fight_1749:
                rs wsad "你迟早得学会照顾自己。"
            translate None lucius_fight_1750:
                nik con "我怎么雇了个不会做饭的厨师…"
            translate None lucius_fight_1751:
                c whap "让我来负责推广工作吧…！"
            translate None lucius_fight_1752:
                rs wsmi "不行，你必须掌握些生活技能。"
            translate None lucius_fight_1753:
                c wang "呃啊…！"
            translate None lucius_fight_1754:
                "过去几天我们都待在斯塔格威奇。这是漫长旅行清单上的第一站。"
            translate None lucius_fight_1755:
                "当然，我们几乎身无分文，这对赛恩来说并不习惯，所以我们又回去找尼科斯，他张开双臂欢迎了我们。"
            translate None lucius_fight_1756:
                "他提议让我们为他工作一段时间，我们很爽快地答应了。烹饪对我来说就像第二天性，但赛恩…"
            translate None lucius_fight_1757:
                ae ann "食物{b}还没{/b}做好可以上桌吗？"
            translate None lucius_fight_1758:
                c "闭嘴，我已经尽力了。"
            translate None lucius_fight_1759:
                "另一个房间传来声音—有位访客来品尝我们的厨艺。"
            translate None lucius_fight_1760:
                cas smi "友善点，艾米尔。你知道他对这种事还不拿手。"
            translate None lucius_fight_1761:
                c "这并没让我感觉好受些…"
            translate None lucius_fight_1762:
                "世界各国的反应正如你所预料的那样—对一座传说中的城市竟然真实存在并向游客开放感到震惊和恐惧。"
            translate None lucius_fight_1763:
                "谁都没料到会这样。奥雷利亚卡维拉挤满了形形色色的访客，好在卡斯皮安和艾米尔控制住了局面。"
            translate None lucius_fight_1764:
                "他们真是绝佳搭档。"
            translate None lucius_fight_1765:
                "当众人谈笑，赛恩连最简单的饭菜都搞得手忙脚乱时，门突然被推开了。"


            if iv_scene_four:
                translate None lucius_fight_1766:
                    "我们可以听见两组脚步声穿过客栈。"
                translate None lucius_fight_1767:
                    i con "喂！雷恩和赛恩在这儿吗？"
                translate None lucius_fight_1768:
                    rs wsur "伊尔兰…？"
                translate None lucius_fight_1769:
                    v smi "你好啊雷恩。近来如何？"
                translate None lucius_fight_1770:
                    rs "维拉斯？！"
                translate None lucius_fight_1771:
                    rs wsmi "好久不见！你好吗！？"
                translate None lucius_fight_1772:
                    i "一个月真的很\"久\"吗？"
                translate None lucius_fight_1773:
                    v "我们过得很好啊，到处旅行，和你们俩没啥两样。"
                translate None lucius_fight_1774:
                    c wsmi "什么风把你们吹来了？想尝尝我的拿手好菜吗？"
                translate None lucius_fight_1775:
                    i "呃…我还是算了。"
                translate None lucius_fight_1776:
                    stop music fadeout 2.0
                    i "…我带了消息。索伦醒了，正在找你。"
                $ persistent.prequel_ad = True
                $ persistent.game_first_opened = True
                window hide dissolve
                scene black with Dissolve(3.0)
                return

            if not iv_scene_four:
                translate None lucius_fight_1777:
                    "我们可以听到一阵孤零零的脚步声穿过酒馆。"
                translate None lucius_fight_1778:
                    i neu "…喂。雷恩和赛恩在吗？"
                translate None lucius_fight_1779:
                    rs wsad "伊尔兰…？" # VOICE MAP
                translate None lucius_fight_1780:
                    i sad "就我一个人。"
                translate None lucius_fight_1781:
                    "孤身一人的伊尔兰…"
                translate None lucius_fight_1782:
                    "这几乎让人难以想象…"
                translate None lucius_fight_1783:
                    c wsur "好久不见。什么风把你吹来了？"
                translate None lucius_fight_1784:
                    stop music fadeout 2.0
                    i "..我是来报信的。索伦醒了，他正找你呢。"
                $ persistent.prequel_ad = True
                $ persistent.game_first_opened = True
                window hide dissolve
                scene black with Dissolve(3.0)
                return

    #
