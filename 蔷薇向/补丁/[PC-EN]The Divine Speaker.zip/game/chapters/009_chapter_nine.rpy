label choice_fourteen_done:
    scene bg sexshop with dissolve:
        xpos 0.28 ypos 1.47 xanchor 0.5 yanchor 1.0 zoom 2.99
        linear 30.0 xpos 0.72 ypos 1.47 xanchor 0.5 yanchor 1.0 zoom 2.99

    translate None chapter_nine_0001:
        "我们终于买完了莱奥斯的所有新…装备？莱拉斯把它们整齐地打包好，莱奥斯能收纳的都收起来了。"
    translate None chapter_nine_0002:
        "我瞥了眼莱拉斯。我在想，她对正在发生的事会知道些什么吗？"
    translate None chapter_nine_0003:
        "毕竟她住在这里。她肯定知道些什么。"
    translate None chapter_nine_0004:
        "我清了清嗓子，轻轻拍了拍她的肩膀，小声和她说话。"

    stop music fadeout 2.0

    scene bg sexshop:
        size(1920, 1080)

    show lilas n neu at slightleft
    show cyne n neu at slightright
    with dissolve

    translate None chapter_nine_0005:
        rs neu "我们想问…这里一直都这么，嗯，安静吗？"
    translate None chapter_nine_0006:
        rs sad "我们刚来的时候，外面一个人都没有，还能看见有人在窗口偷看我们。"
    show cyne n sur with dis
    translate None chapter_nine_0007:
        c "哦，我也注意到了。平时不是这样的。我还以为是我耀眼的气场把大家都吓跑了呢。"
    translate None chapter_nine_0008:
        l ann "呃…"
    show lilas n ang with dis
    translate None chapter_nine_0009:
        lil "不…最近这里有点不太对劲…"
    show cyne n neu with dis
    translate None chapter_nine_0010:
        l neu "什么意思？"
    play music "sounds/bgm/creepy.ogg" fadein 2.0
    translate None chapter_nine_0011:
        lil "我不太适合谈论这个，但是…"

    $ about_Oxhabor._text.append("镇子里正在发生些阴暗的事。居民们都闭门不出，街上空无一人。莱拉斯提到有人陆续失踪。")
    show lilas n sad with dis

    translate None chapter_nine_0012:
        lil "有诡异的事情在发生。{a=set_entry:enc_places->about_Oxhabor}{color=#87CEEB}不断有人失踪…{/color}{/a}"
    translate None chapter_nine_0013:
        lil "我不知道。我不该散播谣言。"
    translate None chapter_nine_0014:
        l "我们在找一个很久前来过这里的男人。"
    translate None chapter_nine_0015:
        lil neu "卡斯皮安，对吗？"
    translate None chapter_nine_0016:
        lil sad "你之前提到过他。很抱歉我从没听说过这个人。"
    translate None chapter_nine_0017:
        lil neu "试着多打听打听。我肯定你能找到知情的人。"
    translate None chapter_nine_0018:
        rs sad "啊，谢谢…"
    show cyne n neu with dis
    translate None chapter_nine_0019:
        c "嗯…"
    translate None chapter_nine_0020:
        c "我认识镇上很多人。也许我能帮上忙？"
    show cyne n hap with dis
    translate None chapter_nine_0021:
        c "我本~~~~来打算回家的，不过他们肯定能等!"
    translate None chapter_nine_0022:
        rs smi "真的？!那就太棒了!"
    translate None chapter_nine_0023:
        "福恩的脸拧了起来，莱奥斯又叹了口气。"
    translate None chapter_nine_0024:
        "找人帮忙怎么了？我早就习惯莱奥斯的难搞了，但福恩平时挺好说话的啊…"
    translate None chapter_nine_0025:
        l "你到底要招惹多少个麻烦人物？"
    translate None chapter_nine_0026:
        l pen "你竟然还要再带个小不点一起上路？你和耗子男孩两个还不够吗？"
    translate None chapter_nine_0027:
        rs sad "客气点…."
    translate None chapter_nine_0028:
        c "没关系。我明白是怎么回事。"
    show cyne n hap with dis
    translate None chapter_nine_0029:
        c "你就是怕我抢走你心爱的雷恩。吃醋很正常啦!"
    translate None chapter_nine_0030:
        l sur "什么？!？我才没有吃醋!"
    show cyne n mis with dis
    translate None chapter_nine_0031:
        c "哦，是吗？好吧，随你怎么想!"
    translate None chapter_nine_0032:
        l emb "我根本不喜欢他!我在这里只是因为不得不在!"
    translate None chapter_nine_0033:
        rs sad "是你自己选择跟来的…你说如果丢下我一个人我会自寻死路…"
    show cyne n hap with dis
    translate None chapter_nine_0034:
        c "多浪漫啊！一位身穿闪亮铠甲的骑士！"
    translate None chapter_nine_0035:
        c "你也会来到我身边保护我吗？带着你那坏小子的态度和岩石般坚硬的腹肌，噢我恋爱了！"
    show cyne n mis with dis
    translate None chapter_nine_0036:
        "他用指尖划过莱奥斯的腹肌和腹部。看起来他对此并不怎么高兴…"
    translate None chapter_nine_0037:
        rs sad "呃…我们还是离开这儿吧…"
    show cyne n hap with dis
    translate None chapter_nine_0038:
        c "下次见，莱拉斯！"
    show lilas n smi2 with dis
    stop music fadeout 2.0
    translate None chapter_nine_0039:
        lil "…我很期待。下次经过时我会试着抓住你。"

    play sound "sounds/sfx/dooropen3.ogg" fadein 1.0
    window hide dissolve

    scene bg ox alley
    show leos n dim neu at farright
    show cyne n dim hap at cenright
    show fawn n dim sad at farleft
    show raen n dim neu at cenleft
    with Fade(0.5, 0.5, 0.5)
    window show dissolve

    translate None chapter_nine_0040:
        c "所以……一个红发小子！"
    show cyne n dim sur with dis
    translate None chapter_nine_0041:
        c "告诉我，你是不是跑得更快？"
    show leos n dim ang with dis
    translate None chapter_nine_0042:
        l "什么？"
    show cyne n dim mis with dis
    translate None chapter_nine_0043:
        c "希望不是。"
    show leos n dim neu with dis
    translate None chapter_nine_0044:
        rs "等等，这是什么意思…？"
    show raen n dim sur with dis
    translate None chapter_nine_0045:
        rs "颜色怎么能跑得更快？"
    show cyne n dim mis with dis
    translate None chapter_nine_0046:
        c "你知道的，红色速度更快。"
    show raen n dim con with dis
    translate None chapter_nine_0047:
        rs "呃…..好吧。"
    show raen n dim neu with dis
    show cyne n dim ang with dis
    translate None chapter_nine_0048:
        c "总之总之！"
    play music "sounds/bgm/Discovery.ogg" fadein 2.0
    show cyne n dim neu with dis
    translate None chapter_nine_0049:
        c "让我理清一下。那个高个在这里是为了保护雷恩，那你呢？"
    show fawn n neu with dis
    translate None chapter_nine_0050:
        f "我…？"
    show cyne n dim neu with dis
    translate None chapter_nine_0051:
        c "是啊。你为什么在这儿？"
    show fawn n sad with dis
    translate None chapter_nine_0052:
        f "...."
    translate None chapter_nine_0053:
        f "我不知道…我没什么用，但是-"
    show raen n dim con with dis
    translate None chapter_nine_0054:
        rs "打住！"
    show raen n dim con with dis
    translate None chapter_nine_0055:
        rs "在你开口前，让我提醒你，如果不是因为你，我们都不会在这儿。你救了我不止一次。是你带领我们穿过森林抵达安全地带。"
    show raen n dim smi with dis
    translate None chapter_nine_0056:
        rs "你是我见过最善良的人。我是认真的。"
    show raen n dim sad with dis
    translate None chapter_nine_0057:
        rs "所以别再贬低自己了。"
    translate None chapter_nine_0058:
        "从昨晚开始，福恩就有点不对劲。不知道是不是莱拉斯说了什么，但确实引发了他的自我怀疑。最好趁早制止。"
    show raen n dim neu with dis
    translate None chapter_nine_0059:
        rs "我们没人觉得你没用。连莱奥斯都不这么想。"
    show leos n dim pen with dis
    translate None chapter_nine_0060:
        l "....."
    show leos n dim neu with dis
    translate None chapter_nine_0061:
        l "….他说得对。我们俩都不可能走到今天。"
    show raen n dim sur with dis
    translate None chapter_nine_0062:
        rs "哇哦，居然真的在夸人。"
    show leos n dim emb with dis
    translate None chapter_nine_0063:
        l "当我没说。"
    show fawn n dim smi with dis
    show leos n dim neu with dis
    translate None chapter_nine_0064:
        f "呃…谢谢大家…"
    show fawn n dim neu with dis
    translate None chapter_nine_0065:
        f "我想，回答你的问题…"
    translate None chapter_nine_0066:
        f "我在这儿是因为我想留下。"
    show raen n dim smi with dis
    translate None chapter_nine_0067:
        "看到他再次露出笑容让我心里暖暖的。我希望他能永远快乐。"
    show cyne n dim sur with dis
    translate None chapter_nine_0068:
        c "你们…"
    translate None chapter_nine_0069:
        c "就是这个！"
    show raen n dim con with dis
    translate None chapter_nine_0070:
        rs "啊？"
    show cyne n dim hap with dis
    translate None chapter_nine_0071:
        c "友谊的力量！我都要哭了…我也想加入！能不能也算我一个？！"
    show leos n dim ang with dis
    translate None chapter_nine_0072:
        l "呕…恶心…"
    show cyne n dim mis with dis
    translate None chapter_nine_0073:
        c "我会想办法钻进你心里的！"
    show cyne n dim sur with dis
    translate None chapter_nine_0074:
        c "好了好了。你叫福恩对吧？多奇怪的名字！你是某种动物男孩吗？"
    show fawn n dim neu with dis
    translate None chapter_nine_0075:
        f "我…我这辈子大部分时间都住在森林里。"
    translate None chapter_nine_0076:
        c "那之前呢？"
    show fawn n dim sad with dis
    translate None chapter_nine_0077:
        f "......"
    show raen n dim neu with dis
    translate None chapter_nine_0078:
        rs "是不是该轮到你回答几个问题了？你一直在问个不停。"
    translate None chapter_nine_0079:
        rs "你为什么来这里？"
    show cyne n dim sur with dis
    translate None chapter_nine_0080:
        c "我？我来是为了莱拉斯的店铺。我以为这很明显。"
    show cyne n dim mis with dis
    translate None chapter_nine_0081:
        c "这一路上我都兴奋得全身发麻。"
    show raen n dim sur with dis
    translate None chapter_nine_0082:
        rs "我…我明白了！"
    translate None chapter_nine_0083:
        rs "那你昨天为什么在斯塔格威奇？"
    show cyne n dim hap with dis
    translate None chapter_nine_0084:
        c "家族事务。他们总把我派去无聊的地方管着我。"
    translate None chapter_nine_0085:
        c "我只是在回家的路上顺便过来。"
    translate None chapter_nine_0086:
        rs "家族事务？"
    translate None chapter_nine_0087:
        c "都是些无聊事，我保证！"
    show raen n dim neu with dis
    translate None chapter_nine_0088:
        rs "哦，好吧。"
    translate None chapter_nine_0089:
        "嗯…还要问些什么呢…？"
    translate None chapter_nine_0090:
        rs "所以，呃…你是做什么的？"
    translate None chapter_nine_0091:
        c "我是做什么的？这个那个都做。"
    translate None chapter_nine_0092:
        rs "这个那个？"
    translate None chapter_nine_0093:
        c "到处打各种零工。没什么特别的。"
    show raen n dim con with dis
    translate None chapter_nine_0094:
        rs "这样啊…."
    translate None chapter_nine_0095:
        "对于一个这么能说会道的人，他还挺擅长避重就轻的…"
    translate None chapter_nine_0096:
        f "嗯…所以你认识这里的很多人？"
    translate None chapter_nine_0097:
        c "是啊！我尽量每几个月来一次。我不介意带你转转，给你介绍些人。"
    show raen n dim smi with dis
    translate None chapter_nine_0098:
        rs "非常感谢。真的，我们很感激。"
    translate None chapter_nine_0099:
        c "为你做什么都行，小可爱。"
    translate None chapter_nine_0100:
        "福恩在赛恩和我之间来回扫视，明显不赞同。"
    translate None chapter_nine_0101:
        rs "嗯…"
    show raen n dim sad with dis
    translate None chapter_nine_0102:
        rs "不知道我们能不能真的找到什么人…听起来很容易，但是.."
    show cyne n dim neu with dis
    translate None chapter_nine_0103:
        c "好吧…."
    translate None chapter_nine_0104:
        c "谁知道呢。就目前的情况来看，可能会有点困难。"
    translate None chapter_nine_0105:
        rs "嗯…"
    translate None chapter_nine_0106:
        l "……振作点，那种悲伤的表情不适合你。"
    translate None chapter_nine_0107:
        rs "抱歉…我只是真的很需要找到一些答案…"
    translate None chapter_nine_0108:
        c "答案？"
    translate None chapter_nine_0109:
        rs "是啊，你看-"
    show leos n dim pis with dis
    translate None chapter_nine_0110:
        l "好了，谈话就到这里吧。"

    translate None chapter_nine_0111:
        l "雷恩，你看起来需要休息。"
    show raen n dim sur with dis
    translate None chapter_nine_0112:
        rs "休息？"
    translate None chapter_nine_0113:
        l "休息一下别说话了，免得下巴脱臼。"
    show cyne n dim sur with dis
    translate None chapter_nine_0114:
        c "啊啊，你真无趣！"
    translate None chapter_nine_0115:
        l "我说过我有趣吗？"
    show raen n dim con with dis
    translate None chapter_nine_0116:
        rs "啊…赛恩，对他抱歉。他有时候会有点暴躁。"
    translate None chapter_nine_0117:
        l "认真的吗？你替我向这家伙道歉？！他比那个鼠小子还烦人！"
    show fawn n dim sur with dis
    translate None chapter_nine_0118:
        f "什-什么？"
    show leos n dim pen with dis
    translate None chapter_nine_0119:
        l "啊啊啊求求言者怜悯我的灵魂，把我从这个可怕的命运中拯救出来吧。"
    show leos n dim ang with dis
    translate None chapter_nine_0120:
        l "让我在睡梦中安详地死去，结束这一切吧。我不知道我还能不能继续这样过一天。"
    translate None chapter_nine_0121:
        rs "…要不你去某个地方等着，我们去打听？"
    translate None chapter_nine_0122:
        l "把你和这个瘦弱的男孩单独留下？不行。"
    show cyne n dim hap with dis
    translate None chapter_nine_0123:
        c "瘦弱？这都是肌肉。"
    translate None chapter_nine_0124:
        c "你照过镜子吗？你简直像根面条。"
    translate None chapter_nine_0125:
        c "还有这身打扮…你是个暴露狂吗？"
    show leos n dim sur with dis
    translate None chapter_nine_0126:
        l "一根面条？！我的穿着有什么问题吗？"
    show fawn n dim sad with dis
    translate None chapter_nine_0127:
        f "我觉得我们有点跑题了…"
    show raen n dim sad with dis
    translate None chapter_nine_0128:
        rs "请别吵了…这很重要…"
    show leos n dim neu with dis
    translate None chapter_nine_0129:
        l "呃…好吧。"
    translate None chapter_nine_0130:
        c "看在他这么帅的份上，我想我可以原谅他这一次！"
    translate None chapter_nine_0131:
        rs "…莱奥斯？"
    show leos n dim pen with dis
    translate None chapter_nine_0132:
        l "别烦我。只要他不来惹我，我也不会招惹他。"
    translate None chapter_nine_0133:
        rs "很好。我们看看能不能找到知情人士。"

    scene bg ox alley with dissolve
    translate None chapter_nine_0134:
        c mis "噢，看那边！我们可以从他们开始问起。"
    translate None chapter_nine_0135:
        "我还是不太明白为什么他要跟着我们帮忙，但现在我们需要接受任何援助。"
    translate None chapter_nine_0136:
        "他指向前方，那里有一群女士正聚在一起交谈。看起来是个不错的突破口。"
    translate None chapter_nine_0137:
        "当我们走近人群时，她们立刻安静下来，用戒备的眼神看着我们，并试图回避目光接触。"
    translate None chapter_nine_0138:
        rs neu "那个…打扰一下？很抱歉打扰你们，但我想问个问题可以吗？"
    translate None chapter_nine_0139:
        w3 "....."
    translate None chapter_nine_0140:
        rs sad "…呃，抱歉，我不是故意要打扰…我在找一个人，想问问你们有没有见过或听说过他。"
    translate None chapter_nine_0141:
        c mis "日安，可爱的女士们。想必你们愿意回答几个问题？我们保证不会占用太多时间。"
    translate None chapter_nine_0142:
        "女人们在我和赛恩之间来回打量，彼此交换了几个眼神。"
    translate None chapter_nine_0143:
        w1 "拜托你们两个，别表现这么可疑。"
    translate None chapter_nine_0144:
        w1 "可以回答些问题，但不能保证我们知道答案。"
    translate None chapter_nine_0145:
        w2 "这里最近发生了些怪事…就这样和陌生人搭话安全吗？！"
    translate None chapter_nine_0146:
        w1 "确实…"
    translate None chapter_nine_0147:
        w3 "那你们要找的是谁？"
    translate None chapter_nine_0148:
        rs sad "我在找名叫卡斯皮安，或者卡斯的人。"
    translate None chapter_nine_0149:
        w2 ".........."
    translate None chapter_nine_0150:
        w2 "…从没听说过这里有这个名字的人。"
    translate None chapter_nine_0151:
        w3 "我也是。"
    translate None chapter_nine_0152:
        w1 "很抱歉。祝你们搜索顺利。"
    translate None chapter_nine_0153:
        w1 "但是…请务必小心。"
    translate None chapter_nine_0155:
        w1 "希望你们能找到想找的人。"
    translate None chapter_nine_0156:
        c hap "多谢帮忙！"
    translate None chapter_nine_0157:
        f neu "啊…谢谢。"
    translate None chapter_nine_0158:
        rs "..嗯，谢谢。真的很感谢你们的帮助。"
    translate None chapter_nine_0159:
        w1 "再见。"
    translate None chapter_nine_0160:
        rs "该死…"
    translate None chapter_nine_0161:
        "他多年前来过这里…还能找到记得他的人吗？"
    translate None chapter_nine_0162:
        f "我们才问了几个人而已，所以…"
    translate None chapter_nine_0163:
        f "别灰心。"
    translate None chapter_nine_0164:
        rs "…你说得对。只是忍不住感到失望。"

    show leos n dim neu at farright
    show cyne n dim neu at cenright
    show fawn n dim neu at farleft
    show raen n dim sad at cenleft
    with dis

    translate None chapter_nine_0165:
        c "嗯…也许我们应该分头行动？这样能打听到更多消息。"
    show cyne n dim hap with dis
    translate None chapter_nine_0166:
        c "两人一组，以防迷路！"
    translate None chapter_nine_0167:
        c "当然了，雷恩应该跟我一起！"
    show leos n dim smi with dis
    translate None chapter_nine_0168:
        l "什么？呃，不，我觉得不行。"
    translate None chapter_nine_0169:
        c "啊呀，为什么不行？"
    show leos n dim ang with dis
    translate None chapter_nine_0170:
        l "为什么不行\"是什么意思？"
    translate None chapter_nine_0171:
        l "这很明显！因为…"
    show leos n dim sur with dis
    translate None chapter_nine_0172:
        l "........"
    translate None chapter_nine_0173:
        c "看吧，你根本没理由！"
    show fawn n dim sad with dis
    translate None chapter_nine_0174:
        f "……或许该让雷恩自己选？"
    translate None chapter_nine_0175:
        l "难道不该显然是我跟他一起去吗？"
    translate None chapter_nine_0176:
        c "凭什么？你有什么理由？保护他安全？"
    translate None chapter_nine_0177:
        c "你是他保镖还是怎样？管这么宽干嘛？"
    show leos n dim emb with dis
    translate None chapter_nine_0178:
        l "不…我…我才不管。随你便。想跟这个白痴私奔就请便。"
    show leos n dim neu with dis
    show cyne n dim neu with dis
    translate None chapter_nine_0179:
        rs "呃呃呃…."

    window hide

    menu:
        "为了安全起见，我想我还是跟莱奥斯走。":
            window show dissolve
            $ leos_relationship +=1
            jump ox_leos

        "福恩，我们一起吧！":
            window show dissolve
            $ fawn_oxchoose = True
            $ fawn_relationship +=1
            jump ox_fawn

        "赛恩好像对镇上很熟…":
            window show dissolve
            $ cyne_relationship +=2
            jump ox_cyne

label ox_leos:
    show raen n dim neu with dis
    translate None chapter_nine_0180:
        rs "莱奥斯，我们结伴而行如何？图个安全。"
    show leos n dim smi with dis
    translate None chapter_nine_0181:
        l "明智之选。"
    show cyne n dim sad with dis
    translate None chapter_nine_0182:
        c "逊爆了。"
    translate None chapter_nine_0183:
        c "那下次再拐跑你咯，雷恩。"
    show leos n dim ann with dis
    translate None chapter_nine_0184:
        l "唉…"
    show cyne n dim mis with dis
    translate None chapter_nine_0185:
        c "啊！不过别担心，福恩。你也超可爱的！陪陪你也无妨。"
    translate None chapter_nine_0186:
        c "就是你这甜腻长相让人想一口吃掉呢。"
    show fawn n dim sur with dis
    translate None chapter_nine_0187:
        f "什、什么？！"
    translate None chapter_nine_0188:
        f "你们要把我丢给这家伙？！"
    show raen n con dim
    show fawn n dim hur
    show leos n dim neu
    with dis
    translate None chapter_nine_0189:
        rs "就一会儿。分头行动我觉得挺好。"
    show fawn n dim sad with dis
    translate None chapter_nine_0190:
        f "...."
    translate None chapter_nine_0191:
        f "……赶紧开始找吧。"
    show raen n neu dim with dis
    translate None chapter_nine_0192:
        rs "稍后在这里集合，行吗？"
    translate None chapter_nine_0193:
        f "好吧…"

    hide fawn
    hide cyne
    with dissolve
    show raen at slightleft
    show leos at slightright
    with move

    translate None chapter_nine_0194:
        "眨眼间赛恩就拽着福恩消失在街角。我有点担心他的安危…"
    show raen n dim con with dis
    translate None chapter_nine_0195:
        rs "你觉得福恩会没事吗？"
    show leos n dim smi with dis
    translate None chapter_nine_0196:
        l "要听实话还是客套话？"
    show raen n dim wor with dis
    translate None chapter_nine_0197:
        rs "……也许让赛恩带走他不是个好主意…"
    show leos n dim neu with dis
    translate None chapter_nine_0198:
        l "木已成舟。真要回不来也没辙，正好少操两份心。"
    translate None chapter_nine_0199:
        rs "别这么说…"
    show leos n dim pen with dis
    translate None chapter_nine_0200:
        l "...."
    translate None chapter_nine_0201:
        l "他绝对别有用心。"
    show raen n dim sur with dis
    translate None chapter_nine_0202:
        rs "谁？赛恩？"
    show leos n dim ang with dis
    translate None chapter_nine_0203:
        l "我们对他一无所知，他却像跟屁虫似的。迟早要出事。"
    translate None chapter_nine_0204:
        rs "他看起来不坏啊，还在帮我们。"
    translate None chapter_nine_0205:
        l "但图什么？他能得到什么好处？"
    translate None chapter_nine_0206:
        rs "得到？"
    show leos n dim pen with dis
    translate None chapter_nine_0207:
        l "人皆有私心。他必有所图，世上没有白帮的忙。"
    show raen n dim sad with dis
    translate None chapter_nine_0208:
        rs "你和福恩也是？"
    translate None chapter_nine_0209:
        l "我说了\"人皆有\"，听不懂？"
    show leos n dim smi with dis
    translate None chapter_nine_0210:
        l "哦快看，那边有人。"
    translate None chapter_nine_0211:
        l "走吧。"
    translate None chapter_nine_0212:
        rs "呃…."

    scene bg ox alley with dissolve:
        xpos 0.5 ypos 1.0 xanchor 0.44 yanchor 0.6 zoom 2.0

    translate None chapter_nine_0213:
        "莱奥斯终止了谈话，独自走向一名男子。那人正静静地仰望着天空。"
    translate None chapter_nine_0214:
        rs neu "你说什么？"
    translate None chapter_nine_0215:
        man "…什么？"
    translate None chapter_nine_0216:
        "他的目光怀疑地在莱奥斯和我之间来回扫视。"
    translate None chapter_nine_0217:
        l neu "我们在找一个人。"
    translate None chapter_nine_0218:
        rs sad "这对我非常重要。他叫卡斯皮安，简称卡斯。"
    translate None chapter_nine_0219:
        rs "你听说过他吗？"
    translate None chapter_nine_0220:
        man "我不知道你们在说谁，也没空回答你们的蠢问题。"
    translate None chapter_nine_0221:
        l pis "好吧，或许你有时间听—"
    translate None chapter_nine_0222:
        rs sad "算了莱奥斯。还是谢谢你。"
    translate None chapter_nine_0223:
        "他又继续仰望天空。这人有点怪…"
    translate None chapter_nine_0224:
        rs sad "真令人失望。"
    translate None chapter_nine_0225:
        rs wor "我开始觉得我们永远找不到他了…谁会记得18年前的人？"
    translate None chapter_nine_0226:
        l smi "这么快就放弃？我们才刚开始。"
    translate None chapter_nine_0227:
        l pen "....."
    translate None chapter_nine_0228:
        "他停顿片刻，低头看向我的手臂。"
    translate None chapter_nine_0229:
        l neu "要知道…我还从未近距离看过你的神之刻印。"
    translate None chapter_nine_0230:
        rs sur "真的吗？"
    translate None chapter_nine_0231:
        rs neu "我想我平时都遮着它们。"
    translate None chapter_nine_0232:
        l pen "嗯…"
    translate None chapter_nine_0233:
        "噢…他想看刻印？为什么不直接说呢？"
    translate None chapter_nine_0234:
        rs "….你想看看吗？"
    translate None chapter_nine_0235:
        l smi "就像我想看赛恩的屁股那么想。"
    translate None chapter_nine_0236:
        rs con "哇…你想看他屁股？"
    translate None chapter_nine_0237:
        l hur "不，我-"
    translate None chapter_nine_0238:
        rs "这有点变态。"
    translate None chapter_nine_0239:
        l hur "不，你不明白—"
    translate None chapter_nine_0240:
        l emb "当我没说。来，把胳膊给我。"

    show leos m dim neu
    with dis2

    translate None chapter_nine_0241:
        rs sur "啊！"
    translate None chapter_nine_0242:
        "他拽过我的手臂，粗暴地卷起袖子。若不是四下无人，遍布我手臂的黑色刻印就会暴露在众目睽睽之下。"
    translate None chapter_nine_0243:
        "我几乎忘了它们的存在。但愿真能忘记。"
    show leos m dim pen with dis
    translate None chapter_nine_0244:
        l "这些刻印意味着什么…"
    translate None chapter_nine_0245:
        rs sad "说不定真是诅咒…？"
    show leos m dim smi with dis
    translate None chapter_nine_0246:
        l "不，你绝对被诅咒了。是被诅咒成吸引烦人家伙的白痴。"
    translate None chapter_nine_0247:
        rs con "怎么，包括你自己？"
    show leos m dim pen with dis
    translate None chapter_nine_0248:
        "他无视我的调侃，用指尖描摹刻印。轻微的触碰让我脊椎发颤。"
    translate None chapter_nine_0249:
        "他垂眸凝视，全神贯注。当他露出这种表情时，我几乎能忘记他的本性，以及迄今为止的所作所为。此刻他看起来就像个普通人。"
    translate None chapter_nine_0250:
        "他的手指沿着我的皮肤滑行，在刻印尽头停下。他静止片刻，陷入沉思。"
    translate None chapter_nine_0251:
        "他冰凉的手触碰着我温热的肌肤。我不耐烦地等待他的手下移。见他没有动作，我轻轻碰了碰他的手。"
    translate None chapter_nine_0252:
        rs neu "嘿，莱奥斯，我…"

    stop music fadeout 2.0
    show leos m dim sur with dis

    translate None chapter_nine_0253:
        u "…哦？新面孔？真罕见。"

    scene bg ox alley with dissolve:
        zoom 1
    show nox n neu2 dim with Dissolve(1)

    translate None chapter_nine_0254:
        "我迅速拉下袖子，莱奥斯也抽回了他的手，我们同时转向那个呼唤我们的声音。"

    show bg ox alley:
        xanchor 0.15 zoom 1.5
    show nox m neu2 dim
    with dissolve

    translate None chapter_nine_0255:
        "就在前方，一个黑发男子倚墙而立，正注视着我们。"
    translate None chapter_nine_0256:
        "比起我们遇到的其他人都显得平静许多。他面无表情地看着我们走近。"
    translate None chapter_nine_0257:
        "那副眼镜……看起来价格不菲。我从没见过这么精致的款式。"
    show nox m sur2 dim with dis
    play music "sounds/bgm/creepy.ogg" fadein 1.0
    translate None chapter_nine_0258:
        "当我们靠近时，他的眼睛突然睁大了。"
    translate None chapter_nine_0259:
        u "……你们来奥克斯哈伯做什么？这里已经很久没有访客了。"

    scene bg ox alley
    show nox n sur2 dim at left
    show raen n neu dim at center
    show leos n neu dim at right
    with dissolve
    show nox n dim sur2 at left with dis

    translate None chapter_nine_0260:
        "他上下打量着我，脸上同样带着难以置信的表情。"
    show raen n dim sur with dis
    translate None chapter_nine_0261:
        rs "呃，那个…"
    show raen n dim neu with dis
    translate None chapter_nine_0262:
        rs "我们在找一个之前来过这里的人。"
    translate None chapter_nine_0263:
        rs "他叫卡斯皮安，简称卡斯。"
    translate None chapter_nine_0264:
        u "......"
    translate None chapter_nine_0265:
        u "卡斯皮安…？"
    translate None chapter_nine_0266:
        u "但你不可能…"
    show raen n dim sur with dis
    translate None chapter_nine_0267:
        rs "我叫雷恩。哦，这位是莱奥斯。"
    translate None chapter_nine_0268:
        u "雷恩…？"
    translate None chapter_nine_0269:
        u "我差点以为你长得像……算了。"

    show raen n dim sur
    show leos n dim sur
    with dis

    translate None chapter_nine_0270:
        rs "等等，你认识他？！"
    translate None chapter_nine_0271:
        rs "你知道他可能在哪里吗？！"
    show nox n dim neu2 with dis
    translate None chapter_nine_0272:
        u "......"
    translate None chapter_nine_0273:
        u "……我认识他。或者说，曾经认识。"
    translate None chapter_nine_0274:
        u "至于他去哪了…."
    translate None chapter_nine_0275:
        "他在我和莱奥斯之间来回打量。"
    translate None chapter_nine_0276:
        u "我会告诉你们，但我也有事相求。"
    show raen n dim wor with dis
    translate None chapter_nine_0277:
        rs "什么？"
    translate None chapter_nine_0278:
        u "现在不便详谈。今晚日落后，来这里找我。"

    hide nox with dissolve
    show raen at slightleft
    show leos at slightright
    with move

    translate None chapter_nine_0279:
        "说完他便若无其事地转身离开。"
    translate None chapter_nine_0280:
        l "这到底什么情况？"
    translate None chapter_nine_0281:
        rs "我也不知道。"
    translate None chapter_nine_0282:
        rs "我们该怎么办？"
    show leos n dim neu with dis
    translate None chapter_nine_0283:
        l "嗯…听起来像个陷阱。我们该做的是无视他，继续四处打听。"
    show raen n dim sad with dis
    translate None chapter_nine_0284:
        rs "但是…他认出了这个名字。他是唯一的线索。"
    translate None chapter_nine_0285:
        rs "不如先去找赛恩和福恩，再商量对策？"
    translate None chapter_nine_0286:
    #stop music fadeout 2.0
        "我们立即折返会合点，赛恩和福恩早已在那里等候。"

    show raen at cenleft
    show leos at farright
    with move
    show cyne n dim hap at cenright
    show fawn n dim sad at farleft
    with dis

    translate None chapter_nine_0287:
        rs "伙计们！有打听到什么吗？"
    translate None chapter_nine_0288:
        c "哦，我可了解了不少！显然福恩不喜欢我逗他，或者碰他头发，拉他的手。真无趣。"
    show raen n dim sad with dis
    translate None chapter_nine_0289:
        rs "这…毫无帮助。"
    translate None chapter_nine_0290:
        c "后来我们被一群想给他编辫子的孩子缠住了。"
    translate None chapter_nine_0291:
        f "他们就是不肯放过我…"
    translate None chapter_nine_0292:
        f "不停地问我各种问题…"
    translate None chapter_nine_0293:
        "那真是彻底失败。"
    translate None chapter_nine_0294:
        rs "其实…我们遇到个戴眼镜的黑发男人。和其他人不同，他既没躲着我们也不害怕。"
    translate None chapter_nine_0295:
        rs "他认出了卡斯皮安这个名字，并说认识他。呃，曾经认识他。但他表示只有我们帮他一个忙才会告知详情。"
    translate None chapter_nine_0296:
        rs "他想在今晚日落后与我们碰面。"
    translate None chapter_nine_0297:
        f "这…这主意妥当吗？夜间和陌生人会面？"
    translate None chapter_nine_0298:
        rs "说实话…连我都觉得这听起来可疑，但这是我唯一的线索…"
    translate None chapter_nine_0299:
        l "….如果你执意要去，那好吧。只要有我在场，他就别想耍什么花招。"
    translate None chapter_nine_0300:
        c "那我也要一起去！听起来很有趣。"
    translate None chapter_nine_0301:
        f "有趣…？"
    show raen n dim smi with dis
    translate None chapter_nine_0302:
        rs "….谢谢你们！"

    jump choice_fifteen_done

label ox_fawn:
    show raen n dim smi with dis
    translate None chapter_nine_0303:
        rs "福恩，我们一起去四处看看如何？"
    show fawn n dim sur with dis
    translate None chapter_nine_0304:
        f "啊..！"
    show fawn n dim hap with dis
    translate None chapter_nine_0305:
        f "好！"
    show cyne n dim sad with dis
    translate None chapter_nine_0306:
        c "切～"
    show leos n dim sur with dis
    translate None chapter_nine_0307:
        l "你该不是想让我跟他一起行动吧？认真的？！"
    show cyne n dim mis with dis
    translate None chapter_nine_0308:
        c "其实…这样也不赖嘛！有个高大帅气的保镖跟着挺不错的。"
    show cyne n dim hap with dis
    translate None chapter_nine_0309:
        c "啊啊啊莱奥斯快来救我！"
    show leos n dim pis with dis
    translate None chapter_nine_0310:
        l "呃呃…言者保佑…"
    show raen n dim sad with dis
    translate None chapter_nine_0311:
        rs "至少试着和睦相处。我们晚点在这里集合，好吗？"
    translate None chapter_nine_0312:
        c "遵命！"
    translate None chapter_nine_0313:
        c "走吧帅哥，咱们找乐子去！"

    hide cyne
    hide leos
    with dissolve
    show fawn at slightleft
    show raen at slightright
    with move

    translate None chapter_nine_0314:
        "莱奥斯被赛恩拽走时狠狠瞪了我一眼。我差点要同情他了。"
    translate None chapter_nine_0315:
        rs "这两人还真是绝配…"
    show fawn n dim neu with dis
    translate None chapter_nine_0316:
        f "我倒是能想到几个更贴切的形容词…"
    translate None chapter_nine_0317:
        f "但…你们不觉得赛恩有点…奇怪吗？"
    show raen n dim sur with dis
    translate None chapter_nine_0318:
        rs "什么意思？"
    show fawn n dim sad with dis
    translate None chapter_nine_0319:
        f "我是说！他-他简直是在对你投怀送抱…"
    translate None chapter_nine_0320:
        rs "你这么觉得？他不就是比较热情吗？"
    show fawn n dim neu with dis
    translate None chapter_nine_0321:
        f "我可不敢苟同…"
    translate None chapter_nine_0322:
        f "我们是在\"那种\"商店遇到他的…准没好事…"
    translate None chapter_nine_0323:
        rs "刚才你说什么店？情趣用品店？"
    translate None chapter_nine_0324:
        rs "他去那种地方能有什么正经事？"
    translate None chapter_nine_0325:
        f "......"
    show fawn n dim sad with dis
    translate None chapter_nine_0326:
        f "或许我们暂时别想这个了…"
    show raen n dim smi with dis
    translate None chapter_nine_0327:
        rs "先集中精力找些人打听消息吧。"
    translate None chapter_nine_0328:
        f "嗯…"
    translate None chapter_nine_0329:
        "街道几乎空无一人，只有我们的脚步声回荡在空中。走着走着，遇见一位年轻女子。"
    show raen n dim neu with dis
    translate None chapter_nine_0330:
        rs "那个，打扰一下…？"
    translate None chapter_nine_0331:
        wom "你们是谁？！"
    show fawn n dim sur with dis
    translate None chapter_nine_0332:
        f "我们只是想打听-"
    translate None chapter_nine_0333:
        wom "离我远点！"
    show fawn n dim hur with dis
    translate None chapter_nine_0334:
        f "啊-抱歉！"
    show raen n dim sad with dis
    translate None chapter_nine_0335:
        rs "请别紧张，我们只是想打听是否见过一个人。我们没有恶意。"
    translate None chapter_nine_0336:
        rs "我们在找一个叫卡斯皮安或卡斯的人。他很久前来过这里。"
    translate None chapter_nine_0337:
        wom "我不知道！我什么都不知道！"
    translate None chapter_nine_0338:
        "这里的人是怎么回事…他们不只是害怕那么简单，简直是惊恐万状。"
    translate None chapter_nine_0339:
        rs "我知道了…不管怎样还是谢谢你。"
    translate None chapter_nine_0340:
        "我抓着福恩的手臂，把他从那个尖叫的女人身边拉开。"
    translate None chapter_nine_0341:
        rs "她怎么回事…？"
    show fawn n dim sad with dis
    translate None chapter_nine_0342:
        f "所有人都紧张兮兮的。他们到底怎么了？"
    translate None chapter_nine_0343:
        "我们继续沿着空无一人的鹅卵石街道前行。无论走到哪里，都找不到其他人。"
    translate None chapter_nine_0344:
        "但是…我们能感觉到那些注视的目光。从门缝后，从窗帘间。"
    translate None chapter_nine_0345:
        "没理会那些视线，我注意到另一件事。福恩时不时会用眼角余光偷偷看我。"
    show raen n dim sur with dis
    translate None chapter_nine_0346:
        rs "怎么了？"
    show fawn n dim sur with dis
    translate None chapter_nine_0347:
        f "诶？"
    show fawn n dim sad with dis
    translate None chapter_nine_0348:
        f "哦…没什么…"
    translate None chapter_nine_0349:
        f ".............."
    translate None chapter_nine_0350:
        f "其实…"
    translate None chapter_nine_0351:
        f "我只是想谢谢你…"
    show fawn n dim shy with dis
    translate None chapter_nine_0352:
        f "谢谢你为我说那些话。你给了我希望。"
    translate None chapter_nine_0353:
        "为他说那些话…？"
    translate None chapter_nine_0354:
        "哦，就是在赛恩和莱奥斯面前说的。"
    show raen n dim smi with dis
    translate None chapter_nine_0355:
        rs "没事。反正我说的都是实话。"
    translate None chapter_nine_0356:
        rs "我只是想看到你开心。"
    translate None chapter_nine_0357:
        f "还有，嗯…"
    translate None chapter_nine_0358:
        "他停下来思考片刻。最近他这样迟疑的时刻越来越少了。他一定是在慢慢习惯和人交流。"
    translate None chapter_nine_0359:
        f "我感觉…现在没那么害怕了。刚到斯塔格威奇时，我只想逃走。"
    translate None chapter_nine_0360:
        f "我从没想过…会重新回到人群之中。我以为余生都会独自待在树屋里。"
    translate None chapter_nine_0361:
        f "希望这能变得容易些。我知道很难理解，但做这些事对我来说太可怕了。总觉得随时都可能出错。"
    translate None chapter_nine_0362:
        f "但是…在你身边…我就不害怕了。"
    show raen n dim shy with dis
    translate None chapter_nine_0363:
        rs "真、真的吗？"
    translate None chapter_nine_0364:
        "我的胸口发紧，躲开了福恩恳切的目光。"
    show raen n dim sur with dis
    translate None chapter_nine_0365:
        rs "你知道吗…感觉我们已经认识一辈子了…但实际上才几天？"
    translate None chapter_nine_0366:
        "严格来说我们几乎还是陌生人。"
    translate None chapter_nine_0367:
        "但我们已经一起经历了这么多。这辈子从未对别人有过这样迅速的亲近感。"
    translate None chapter_nine_0368:
        "我想保护他，确保他能永远保持笑容。"
    translate None chapter_nine_0369:
        f "真希望我们能早点相遇…"
    show raen n dim sad with dis
    translate None chapter_nine_0370:
        rs "....."
    translate None chapter_nine_0371:
        rs "…..是啊，我也是。"
    translate None chapter_nine_0372:
        rs "想到你独自在外漂泊了那么久…"
    translate None chapter_nine_0373:
        "这让我心疼…也许这么说太肉麻了。"
    translate None chapter_nine_0374:
        rs "就是，呃…"
    translate None chapter_nine_0375:
        rs "让我…"
    translate None chapter_nine_0376:
        rs "胸口发闷？"
    show fawn n dim sur with dis
    translate None chapter_nine_0377:
        f "............"
    show fawn n dim smiclo with dis
    translate None chapter_nine_0378:
        f "哈哈哈。"
    translate None chapter_nine_0379:
        f "我很高兴你逃走时追上来抱住了我。"
    show raen n dim emb with dis
    translate None chapter_nine_0380:
        rs "不要啊，我想忘记那件事！"
    translate None chapter_nine_0381:
        f "你把我扑倒在地，赤裸着身子浑身湿透。我怎么可能忘记？"
    translate None chapter_nine_0382:
        rs "我还是很抱歉…"
    translate None chapter_nine_0383:
        f "不用道歉…"
    translate None chapter_nine_0384:
        f "那让我很开心…"
    show raen n dim shy with dis
    translate None chapter_nine_0385:
        rs "哦…哦…"
    translate None chapter_nine_0386:
        "我这是怎么了…？我的脸好烫…"
    translate None chapter_nine_0387:
        "这让我有点想…触碰他？"
    translate None chapter_nine_0388:
        rs "喂-喂，福恩？"
    translate None chapter_nine_0389:
        f "…..嗯？"
    translate None chapter_nine_0390:
        "大脑啊，别让我失望。想个好借口出来。"
    show raen n dim sur with dis
    translate None chapter_nine_0391:
        rs "…你的手看起来好冷！"
    show fawn n dim sur with dis
    translate None chapter_nine_0392:
        f "什么？！我的手？"
    show raen n dim emb with dis
    translate None chapter_nine_0393:
        rs "是啊，所以，呃！"
    translate None chapter_nine_0394:
        rs "或-或许我可以…"

    show raen at cenright
    show fawn at cenleft
    with move
    show raen n dim shy with dis

    translate None chapter_nine_0395:
        "我轻轻握住他小巧的手。很温暖。"
    translate None chapter_nine_0396:
        f "嗯！我-我…"
    show fawn n dim surb with dis
    translate None chapter_nine_0397:
        f "我觉得你-你可能是对的！"
    translate None chapter_nine_0398:
        f "我的手…冰凉！"
    translate None chapter_nine_0399:
        rs "是啊！我的也是！"
    translate None chapter_nine_0400:
        "他的手比我的小。纤细修长的手指。这让我想起那次在湖边滑倒…"
    translate None chapter_nine_0401:
        "等等，我在干什么？！"
    stop music fadeout 2.0
    translate None chapter_nine_0402:
        u "…哦？新面孔？真罕见。"

    show fawn at slightleft
    show raen at slightright
    with move
    show fawn n dim sur
    show raen n dim sur
    with dis

    translate None chapter_nine_0403:
        f "啊！"
    translate None chapter_nine_0404:
        "当有人喊我们时，福恩迅速把手抽了回去。"

    scene bg ox alley with dissolve:
        xpos 0.5 ypos 1.0 xanchor 0.43 yanchor 0.73 zoom 1.5
    show nox m neu2 dim with Dissolve(1.0)

    translate None chapter_nine_0405:
        "正前方有个黑发戴眼镜的男子，靠着墙注视我们。"
    translate None chapter_nine_0406:
        "他比我们之前遇到的人都平静。面无表情地看着我们走近。"
    translate None chapter_nine_0407:
        "那副眼镜……看起来价格不菲。我从没见过这么精致的款式。"
    show nox m sur2 dim with dis
    translate None chapter_nine_0408:
        "当我们靠近时，他瞪大了眼睛。"
    play music "sounds/bgm/creepy.ogg" fadein 1.0
    translate None chapter_nine_0409:
        u "……你们来奥克斯哈伯做什么？这里已经很久没有访客了。"

    scene bg ox alley
    show fawn n dim sur at right
    show nox n sur2 dim at left
    show raen n dim sur at center
    with dis

    translate None chapter_nine_0410:
        "他上下打量着我，脸上同样带着难以置信的表情。"
    show raen n dim sur with dis
    translate None chapter_nine_0411:
        rs "呃，那个…"
    show raen n dim neu with dis
    translate None chapter_nine_0412:
        rs "我们在找一个之前来过这里的人。"
    translate None chapter_nine_0413:
        rs "他叫卡斯皮安，简称卡斯。"
    translate None chapter_nine_0414:
        u "......"
    translate None chapter_nine_0415:
        u "卡斯皮安…？"
    translate None chapter_nine_0416:
        u "但你不可能…"
    translate None chapter_nine_0417:
        rs "我叫雷恩。哦，这是福恩。"
    translate None chapter_nine_0418:
        u "雷恩…？"
    translate None chapter_nine_0419:
        u "我差点以为你长得像……算了。"

    show raen n dim sur
    show fawn n dim sur
    with dis

    translate None chapter_nine_0420:
        rs "等等，你认识他？！"
    translate None chapter_nine_0421:
        rs "你知道他可能在哪里吗？！"
    show nox n dim neu2 with dis
    translate None chapter_nine_0422:
        u "......"
    translate None chapter_nine_0423:
        u "……我认识他。或者说，曾经认识。"
    translate None chapter_nine_0424:
        u "至于他去哪了…."
    translate None chapter_nine_0425:
        "他的目光在福恩和我之间游移。"
    translate None chapter_nine_0426:
        u "我会告诉你们，但我也有事相求。"
    show raen n dim wor with dis
    translate None chapter_nine_0427:
        rs "什么？"
    translate None chapter_nine_0428:
        u "现在不便详谈。今晚日落后，来这里找我。"

    hide nox with dissolve
    show raen at slightleft
    show fawn at slightright
    with move

    translate None chapter_nine_0429:
        "说完他便若无其事地转身离开。"
    show fawn n dim sad with dis
    translate None chapter_nine_0430:
        f "….天黑后和陌生人见面…这主意好吗？"
    show raen n dim sur with dis
    translate None chapter_nine_0431:
        rs "什么意思？"
    translate None chapter_nine_0432:
        f "这个…什么都有可能发生…而且他冷静得有点诡异，你不觉得吗？"
    show raen n dim sad with dis
    translate None chapter_nine_0433:
        rs "嗯…"
    translate None chapter_nine_0434:
        rs "我们不如去找赛恩和莱奥斯，看他们有没有打听到什么。"
    translate None chapter_nine_0435:
        f "好吧…"
    translate None chapter_nine_0436:
    #stop music fadeout 2.0
        "我们迅速原路返回集合点，赛恩和莱奥斯已经在那里等我们了。"

    show fawn at cenleft
    show raen at farleft
    with move
    show leos n dim pis at farright
    show cyne n dim hap at cenright
    with dis

    translate None chapter_nine_0437:
        rs "伙计们！情况如何？"
    translate None chapter_nine_0438:
        l "呃，我们什么都没打听到。"
    show leos n dim ang with dis
    translate None chapter_nine_0439:
        l "派我和他一起行动能指望什么？他只会拖我后腿。"
    show cyne n dim mis with dis
    translate None chapter_nine_0440:
        c "抱歉抱歉。"
    translate None chapter_nine_0441:
        c "但你不能怪我！一路上所有姑娘都缠着要我介绍他认识！"
    show leos n dim ang with dis
    translate None chapter_nine_0442:
        l "我真希望你没…"
    translate None chapter_nine_0443:
        l "你怎么会认识镇上每个人？！"
    translate None chapter_nine_0444:
        c "我人脉广。"
    show fawn n dim neu with dis
    show raen n dim neu with dis
    translate None chapter_nine_0445:
        f "呃…"
    translate None chapter_nine_0446:
        f "我们…算是打听到点东西。"
    show cyne n dim neu with dis
    translate None chapter_nine_0447:
        rs "其实…我们遇到个戴眼镜的黑发男人。和其他人不同，他既没躲着我们也不害怕。"
    translate None chapter_nine_0448:
        rs "他认出了卡斯皮安这个名字，说认识他。呃，曾经认识。但要我们帮个忙才肯说。"
    translate None chapter_nine_0449:
        rs "他想在今晚日落后与我们碰面。"
    translate None chapter_nine_0450:
        l "你是认真的吗？同样的话我要跟你说多少遍。你个白痴。你这样简直是在求着被别人绑架卖掉。"
    show raen n dim sad with dis
    translate None chapter_nine_0451:
        rs "但是…我觉得他真的知道些什么！"
    show cyne n dim neu with dis
    translate None chapter_nine_0452:
        c "听起来很可疑。"
    translate None chapter_nine_0453:
        l "终于有件事我们能达成一致了。"
    translate None chapter_nine_0454:
        rs "可是..他是我唯一的线索…"
    translate None chapter_nine_0455:
        l "或者更可能的是他在撒谎。"
    translate None chapter_nine_0456:
        f "我也觉得听起来不太靠谱，不过…我相信雷恩。"
    translate None chapter_nine_0457:
        rs "如果我们一起去，他就耍不了花招。我们四个人有优势。"
    translate None chapter_nine_0458:
        rs "求你了？"
    translate None chapter_nine_0459:
        l "....."
    translate None chapter_nine_0460:
        l "….为什么我总是被卷入这种破事？好吧。如果这是你想要的。"
    show cyne n dim hap with dis
    translate None chapter_nine_0461:
        c "我也要去！"
    translate None chapter_nine_0462:
        l "等等，等等，什么？为什么？我们不需要你来。"
    translate None chapter_nine_0463:
        c "当侦探多有意思啊！"
    translate None chapter_nine_0464:
        l "呃…"
    show raen n dim smi with dis
    translate None chapter_nine_0465:
        rs "谢啦，伙计们！"

    jump choice_fifteen_done

label ox_cyne:
    translate None chapter_nine_0466:
        rs "好吧…."
    translate None chapter_nine_0467:
        rs "赛恩，既然你对这里熟又在帮我们…要不要一起四处看看？"
    show cyne n dim sur with dis
    translate None chapter_nine_0468:
        c "我？"
    show raen n dim smi with dis
    translate None chapter_nine_0469:
        rs "对，如果你想的话。这是我至少能做的表示感谢的方式。"
    show cyne n dim hap with dis
    translate None chapter_nine_0470:
        c "哇喔！这会超有趣的！我们快离开这儿！"
    translate None chapter_nine_0471:
        c "回头见，莱奥斯。"
    show leos n dim sur with dis
    translate None chapter_nine_0472:
        l "认真的？"
    translate None chapter_nine_0473:
        l "你选他不选我？甚至不选老鼠小子？你真是刷新下限了。"
    show leos n dim ang with dis
    translate None chapter_nine_0474:
        l "玩得开心，你俩挺配的。两个烦人的小不点。"
    translate None chapter_nine_0475:
        c "哎呀闭嘴啦莱奥斯。我知道你吃醋了，但我会完完整整把他还给你的。不过我不能保证不先啃几口。"
    show fawn n dim sur with dis
    translate None chapter_nine_0476:
        f "…什-"
    translate None chapter_nine_0477:
        c "拜拜啦！快走，雷恩！"

    stop music fadeout 3.0
    hide fawn
    hide leos
    with dissolve
    pause(0.1)
    show cyne at slightright
    show raen at slightleft
    with move

    translate None chapter_nine_0478:
        "赛恩挽着我的胳膊把我拽走了。"
    translate None chapter_nine_0479:
        rs "我们晚点在这里会和！"
    show raen n dim sad with dis
    translate None chapter_nine_0480:
        rs "希望他们听到了。"
    show cyne n dim mis with dis
    translate None chapter_nine_0481:
        c "哼哼，哼哼。"
    translate None chapter_nine_0482:
        "有那么一会儿，他就这样拽着我走，轻声哼着歌，似乎很满足。但现在就剩我们两个人，反而没什么可说的。"
    translate None chapter_nine_0483:
        "我们才刚认识…有点尴尬…"
    translate None chapter_nine_0484:
        c "那么，既然终于能独占你了…"
    play music "sounds/bgm/Fooling Around Tiny.ogg" fadein 1.0
    translate None chapter_nine_0485:
        c "我们为什么不互相了解一下呢？"
    show raen n dim smi with dis
    translate None chapter_nine_0486:
        rs "噢，我很乐意。对了谢谢你。我们三个都很感谢你的帮助。"
    translate None chapter_nine_0487:
        rs "包括莱奥斯，虽然他不会承认。"
    translate None chapter_nine_0488:
        c "小事一桩！为你这样的小可爱做什么都行。"
    show cyne n dim mis with dis
    translate None chapter_nine_0489:
        c "噢，我有个主意。要不要和我玩问答游戏？"
    show raen n dim sur with dis
    translate None chapter_nine_0490:
        rs "问答游戏？"
    translate None chapter_nine_0491:
        c "我们互相提问，一个问题接一个问题。你必须说实话！"
    translate None chapter_nine_0492:
        rs "嗯… 如果做不到会怎样？"
    show cyne n dim sur with dis
    translate None chapter_nine_0493:
        c "嗯…"
    show cyne n dim hap with dis
    translate None chapter_nine_0494:
        c "那就要接受大冒险惩罚。公平吧？"
    show raen n dim hap with dis
    translate None chapter_nine_0495:
        rs "好吧，听起来很有趣。我先开始吗？"
    translate None chapter_nine_0496:
        rs "你最喜欢的颜色是什么？"
    show cyne n dim neu with dis
    translate None chapter_nine_0497:
        c "….可能是粉色？或是蓝色？我都喜欢。"
    show raen n dim smi with dis
    translate None chapter_nine_0498:
        rs "像你这身装扮的颜色？这些颜色很适合你。"
    show cyne n dim hap with dis
    translate None chapter_nine_0499:
        c "谢谢！那么，该我提问了…"
    show cyne n dim mis with dis
    translate None chapter_nine_0500:
        c "你在和福恩还是莱奥斯交往？"
    show raen n dim neu with dis
    translate None chapter_nine_0501:
        rs "交往？"
    translate None chapter_nine_0502:
        c "噢，你懂的。跟他们约会。"
    show raen n dim sur with dis
    translate None chapter_nine_0503:
        rs "跟他们约会？！"
    translate None chapter_nine_0504:
        "这就是福恩和那个绿头发怪人说过的事情。跟他们约会？我对他们有那种感觉吗…？"

    window hide

    menu:

        "福恩很可爱，但我没在和任何人交往":
            $ fawn_relationship +=1
            window show dissolve
            jump cyne_fawn

        "莱奥斯和我关系越来越近，但是…":
            $ leos_relationship +=1
            window show dissolve
            jump cyne_leos

        "绝对不可能！":
            $ cyne_relationship +=2
            window show dissolve
            jump cyne_cyne


label cyne_fawn:
    translate None chapter_nine_0505:
        rs "嗯…"
    show raen n dim shy with dis
    translate None chapter_nine_0506:
        rs "我没有在和任何人交往，但有时和福恩在一起时觉得他很可爱。这算吗？"
    show cyne n dim sur with dis
    translate None chapter_nine_0507:
        c "福恩？"
    translate None chapter_nine_0508:
        c "他确实讨人喜欢。你眼光不错。"

    jump cyne_cont1


label cyne_leos:
    translate None chapter_nine_0509:
        rs "呃…我没在和任何人约会…"
    show raen n dim shy with dis
    translate None chapter_nine_0510:
        rs "但是…最近我和莱奥斯走得更近了。感觉挺好的。"
    translate None chapter_nine_0511:
        c "噢～那个高个子？可以理解。真是个帅哥。"

    jump cyne_cont1

label cyne_cyne:
    show raen n dim emb with dis
    translate None chapter_nine_0512:
        rs "才不是！"
    translate None chapter_nine_0513:
        rs "我没有在和任何人交往。以前也从来没谈过恋爱…"
    show cyne n dim sur with dis
    translate None chapter_nine_0514:
        c "哦，你更喜欢单身？我也是这么想的。"
    translate None chapter_nine_0515:
        c "保持随意关系不是更有趣吗，你不觉得？"
    translate None chapter_nine_0516:
        rs "呃…是啊！"

    jump cyne_cont1

label cyne_cont1:
    translate None chapter_nine_0517:
        "我转过头去不看赛恩，稍作冷静后，把问题抛回给他。"
    show raen n dim neu with dis
    translate None chapter_nine_0518:
        rs "那么我的问题是…你为什么要帮我，说实话？"
    show cyne n dim mis with dis
    translate None chapter_nine_0519:
        c "我能说是因为你太可爱了吗？"
    show raen n dim smi with dis
    translate None chapter_nine_0520:
        rs "这取决于你想不想接受大冒险惩罚。"
    translate None chapter_nine_0521:
        c "好吧好吧。"
    show cyne n dim neu with dis
    translate None chapter_nine_0522:
        c "…因为你很有趣。你吸引了我的注意，我想更了解你。"
    translate None chapter_nine_0523:
        c "一旦我回家，我们可能永远不会再见面。你不觉得应该抓住机会吗？"
    translate None chapter_nine_0524:
        c "现在跟随直觉行动，总比日后后悔要好。"
    show raen n dim sur with dis
    translate None chapter_nine_0525:
        rs "这话有点深刻。"
    show cyne n dim mis with dis
    translate None chapter_nine_0526:
        c "可能太深刻了点。"
    translate None chapter_nine_0527:
        c "那么，我的问题也应该同样深刻。"
    show cyne n dim neuclo with dis
    translate None chapter_nine_0528:
        c "嗯…"
    show cyne n dim mis with dis
    translate None chapter_nine_0529:
        c "你有什么事瞒着我？"
    show raen n dim wor with dis
    translate None chapter_nine_0530:
        rs "瞒着你？！"
    translate None chapter_nine_0531:
        rs "什-什么意思？我没什么瞒着你的！"
    translate None chapter_nine_0532:
        c "真的吗？我不太确定。"
    show cyne n dim neu with dis
    translate None chapter_nine_0533:
        c "你这么拼命地寻找这个人…却告诉我没有特别原因？"
    translate None chapter_nine_0534:
        rs "真的，我只是想…"
    translate None chapter_nine_0535:
        rs "找到他！"
    show cyne n dim mis with dis
    translate None chapter_nine_0536:
        c "我觉得该来点刺激的了！你必须亲我一下！"
    show raen n dim sur with dis
    translate None chapter_nine_0537:
        rs "认真的吗？！"
    translate None chapter_nine_0538:
        rs "我…我不知道该怎么亲…"
    show cyne n dim sur with dis
    translate None chapter_nine_0539:
        c "等等，你居然不知道？"
    translate None chapter_nine_0540:
        c "那亲脸颊也行。"
    show raen n dim emb with dis
    translate None chapter_nine_0541:
        rs "但…但是.."
    translate None chapter_nine_0542:
        c "哎呀，别害羞嘛！"

    window hide dissolve

    scene gallery_45 with dissolve:
        xpos 0.92 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.86
        linear 35.0 xpos 0.08 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.86
    window show dissolve
    translate None chapter_nine_0543:
        "他捧住我的脸往下拉，直到我们四目相对，相距不过数寸。他翡翠般的双眸占据了我全部视线。"
    translate None chapter_nine_0544:
        rs "我该怎么办？！"
    translate None chapter_nine_0545:
        c "你居然真没亲过任何人？我知道你挺纯情，但这未免太夸张了。"
    translate None chapter_nine_0546:
        rs "确实没有…"
    translate None chapter_nine_0547:
        c "就…你懂的"
    translate None chapter_nine_0548:
        c "稍微噘嘴贴到我脸颊上就行，要求不高。"
    translate None chapter_nine_0549:
        c "我~等~着~呢！"
    translate None chapter_nine_0550:
        rs "好吧！"
    translate None chapter_nine_0551:
        "我紧紧闭眼。我能行的，福恩教过我这个。"
    translate None chapter_nine_0552:
        "三、二、一…"

    scene gallery_45 with dissolve
    translate None chapter_nine_0553:
        "我飞快地啄了下他的脸颊。难得能俯视别人感觉还不赖。"
    translate None chapter_nine_0554:
        "他脸颊的肌肤温暖柔软。这触感不错，但接下来呢？"
    translate None chapter_nine_0555:
        "要动嘴巴吗？还是保持这样？我该做点什么？"
    translate None chapter_nine_0556:
        "或者就这样僵着？感觉越来越奇怪了…"
    translate None chapter_nine_0557:
        c "....."
    show gallery_46 with dissolve
    translate None chapter_nine_0558:
        c "哈哈哈哈！"
    translate None chapter_nine_0559:
        c "你可真是个活宝！"
    translate None chapter_nine_0560:
        c "打算一直保持这个姿势？"
    translate None chapter_nine_0561:
        rs "我底该左什摸？(咬字不清)"
    translate None chapter_nine_0562:
        c "不用不用，这样正好。"
    translate None chapter_nine_0563:
        c "不过亲嘴唇应该更舒服。"

    if achievement.has("cyne_kiss"):
        pass
    else:
        $ renpy.display_notify("成就解锁：初吻")

    python:
        achievement.grant("cyne_kiss")
        achievement.sync()

    translate None chapter_nine_0564:
        c "要不要试试？我不介意教教你。"
    translate None chapter_nine_0565:
        rs "什-"
    stop music fadeout 2.0
    translate None chapter_nine_0566:
        u "…哦？新面孔？真罕见。"
    window hide dissolve

    scene bg ox alley
    show raen n dim sur at slightleft
    show cyne n dim sur at slightright
    with dissolve

    window show dissolve
    translate None chapter_nine_0567:
        "突然传来的喊声让我立刻缩回身子，和赛恩拉开距离。"

    scene bg ox alley with dissolve:
        xpos 0.5 ypos 1.0 xanchor 0.43 yanchor 0.73 zoom 1.5
    show nox m neu2 dim with Dissolve(1.0)
    translate None chapter_nine_0568:
        "前方墙边倚着个黑发青年，正注视着我们。"
    translate None chapter_nine_0569:
        "比起我们遇到的其他人都显得平静许多。他面无表情地看着我们走近。"
    translate None chapter_nine_0570:
        "那副眼镜……看起来价格不菲。我从没见过这么精致的款式。"
    show nox m sur2 dim with dis
    translate None chapter_nine_0571:
        "当我们靠近时，他的眼睛突然睁大了。"

    scene bg ox alley
    show nox n sur2 dim at left
    show raen n neu dim at center
    show cyne n neu dim at right
    with dis
    show nox n dim sur2 at left with dis
    play music "sounds/bgm/creepy.ogg" fadein 1.0

    translate None chapter_nine_0571b:
        "他上下打量着我，脸上同样带着难以置信的表情。"

    translate None chapter_nine_0572:
        u "……你们来奥克斯哈伯做什么？这里已经很久没有访客了。"
    translate None chapter_nine_0573:
        rs "呃，那个…"
    show raen n dim sad with dis
    translate None chapter_nine_0574:
        rs "我们在找一个之前来过这里的人。"
    translate None chapter_nine_0575:
        rs "他叫卡斯皮安，简称卡斯。"
    translate None chapter_nine_0576:
        u "....."
    translate None chapter_nine_0577:
        u "卡斯皮安…？"
    translate None chapter_nine_0578:
        u "但你不可能…"
    translate None chapter_nine_0579:
        rs "我是雷恩。哦，这是赛恩。"
    show cyne n dim neu with dis
    translate None chapter_nine_0580:
        u "雷恩…？"
    translate None chapter_nine_0581:
        u "我差点以为你长得像……算了。"
    show raen n dim sur with dis
    translate None chapter_nine_0582:
        rs "等等，你认识他？！"
    translate None chapter_nine_0583:
        rs "你知道他可能在哪里吗？！"
    show nox n dim neu2 with dis
    translate None chapter_nine_0584:
        u "......."
    translate None chapter_nine_0585:
        u "……我认识他。或者说，曾经认识。"
    translate None chapter_nine_0586:
        u "至于他去哪了…."
    translate None chapter_nine_0587:
        "他的目光在我和赛恩之间游移。"
    translate None chapter_nine_0588:
        u "我会告诉你们，但我也有事相求。"
    show raen n dim sur with dis
    translate None chapter_nine_0589:
        rs "什么？"
    translate None chapter_nine_0590:
        u "现在不便详谈。今晚日落后，来这里找我。"

    hide nox with dissolve
    show raen at slightleft
    show cyne at slightright
    with move

    translate None chapter_nine_0591:
        c "嗯，很可疑。"
    translate None chapter_nine_0592:
        rs "是吗？"
    translate None chapter_nine_0593:
        c "相当可疑。而且我们虽未谋面，但他长得特别像…"
    translate None chapter_nine_0594:
        c "走着瞧吧，这人肯定在盘算什么。"
    show raen n dim sad with dis
    translate None chapter_nine_0595:
        rs "我们该怎么办…？"
    translate None chapter_nine_0596:
        c "先去找另外两个人汇合吧。"
    show cyne n dim mis with dis
    translate None chapter_nine_0597:
        c "噢~还是说你想继续独处？我也奉陪哦。"
    translate None chapter_nine_0598:
        c "要不要把刚才被打断的事继续完？"
    show raen n dim emb with dis
    translate None chapter_nine_0599:
        rs "呃！我觉得该回去了…"
    show cyne n dim hap with dis
    translate None chapter_nine_0600:
        c "哈哈，好吧。"
    translate None chapter_nine_0601:
        "我们迅速原路返回到了会合点，莱奥斯和福恩已经在那里等着我们了。"

    show raen at cenleft
    show cyne at cenright
    with move

    show leos n dim neu at farright
    show fawn n dim sad at farleft
    show raen n dim neu
    with dissolve

    translate None chapter_nine_0602:
        rs "伙计们！你们有什么发现吗？"
    translate None chapter_nine_0603:
        f "……没什么特别的。"
    show leos n dim pen with dis
    translate None chapter_nine_0604:
        l "这该怪谁呢？你一直躲在我后面鬼鬼祟祟的吓人。"
    show fawn n dim hur with dis
    translate None chapter_nine_0605:
        f "这里的人很可怕啊！"
    translate None chapter_nine_0606:
        "那真是彻底失败。"
    translate None chapter_nine_0607:
        rs "其实…我们遇到个戴眼镜的黑发男人。和其他人不同，他既没躲着我们也不害怕。"
    translate None chapter_nine_0608:
        rs "他认出了卡斯皮安这个名字，说认识他。呃，曾经认识。但要我们帮个忙才肯说。"
    translate None chapter_nine_0609:
        rs "他想在今晚日落后与我们碰面。"
    translate None chapter_nine_0610:
        f "这…这主意妥当吗？夜间和陌生人会面？"
    show raen n dim sad with dis
    translate None chapter_nine_0611:
        rs "说实话…连我都觉得这听起来可疑，但这是我唯一的线索…"
    translate None chapter_nine_0612:
        l "听起来不太妙，不过……"
    translate None chapter_nine_0613:
        l "只要我在场，他就掀不起什么风浪。好吧，我们走。"
    translate None chapter_nine_0614:
        c "那我也要一起去！听起来很有趣。"
    show fawn n dim sad with dis
    translate None chapter_nine_0615:
        f "有趣…？"
    show raen n dim smi with dis
    translate None chapter_nine_0616:
        rs "谢啦，伙计们！"
    jump choice_fifteen_done
