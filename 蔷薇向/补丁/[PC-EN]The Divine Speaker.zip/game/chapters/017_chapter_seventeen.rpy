label chapter_seventeen_start:
    scene bg primrose with dissolve:
        size(1920, 1080)
    window show dissolve
    translate None chapter_seventeen_0001:
        "里面的店铺堪称\"温馨\"二字的完美诠释。布料散落在各处表面，五彩斑斓的线轴沿墙排列，昏黄温暖的灯光洒满房间。店铺后部有一道通往上层的楼梯。"


    show raen n neu at slightright
    show cyne n hap at slightleft
    with dissolve
    translate None chapter_seventeen_0002:
        "赛恩略微走在前头，他的高跟靴在地板上咔嗒作响。"
    translate None chapter_seventeen_0003:
        c "阿什？你在吗？"
    translate None chapter_seventeen_0004:
        "他的声音在空间里回荡，又传回我们耳边。"
    translate None chapter_seventeen_0005:
        show cyne n neu with dis
        c "嗯…如果他不在店里，可不是会忘记锁门的类型—"
    translate None chapter_seventeen_0006:
        a "赛恩，是你吗？"
    translate None chapter_seventeen_0007:
        a "别告诉我我最爱的顾客又需要新衣服了？你可以随便编借口，但当一个月扯破七套衣服后，我开始觉得这绝非意外…"

    show raen at center
    show cyne at left
    with move
    show ashe n smi at right with dissolve

    translate None chapter_seventeen_0008:
        "先出现双腿，然后是躯干，最后是头部…那个男人从楼梯走下来，进入我们的视线。他看起来精致时髦，脸上却挂着令人安心的微笑。"
    translate None chapter_seventeen_0009:
        show ashe n sur with dis
        a "噢，没想到你带了朋友。这两位英俊的先生是？朋友？"
    translate None chapter_seventeen_0010:
        "赛恩回头看我们，然后对阿什露出笑容。"
    translate None chapter_seventeen_0011:
        show cyne n hap with dis
        c "…嗯，是我朋友。"
    translate None chapter_seventeen_0012:
        "男人最终停在我们面前。他很高，深色头发向后扎起以免遮脸。他又笑了笑，手搭在赛恩肩上。"

    show ashe n neu with dis
    $ about_Ashe.locked = False
    translate None chapter_seventeen_0013:
        a "早知道就该准备更热情的招待了。请随意些。你们可以叫我{a=set_entry:enc_people->about_Ashe}{color=#DA70D6}阿什{/color}{/a}。"
    translate None chapter_seventeen_0014:
        "赛恩从我身后绕过来推着我向前。"
    translate None chapter_seventeen_0015:
        show raen n sur with dis
        rs "不用推啦！"
    translate None chapter_seventeen_0016:
        c "快，快点！赶紧自我介绍！"
    translate None chapter_seventeen_0017:
        "阿什看着这出互动，随后向我伸出手。他的握力坚定而温暖。"
    translate None chapter_seventeen_0018:
        show raen n smi with dis
        rs "我叫雷恩。这位是福恩，还有莱奥斯。"
    translate None chapter_seventeen_0019:
        f shy "啊，你们好。"
    translate None chapter_seventeen_0020:
        l neu "嗨，久仰大名之类的。"
    translate None chapter_seventeen_0021:
        a "我大概知道你们为何而来了。看打扮就不太适应锡德卡汉的天气呢。"
    translate None chapter_seventeen_0022:
        c "我觉得斯塔格威奇的热带海滩没法比。当然，我只信赖一个人来为他们置装。"
    translate None chapter_seventeen_0023:
        a "…让我想想。三套原创服装？"
    translate None chapter_seventeen_0024:
        c "能搞定吗？"
    translate None chapter_seventeen_0025:
        show ashe n smi with dis
        a "当然可以，既然是你要的…我们可以谈个特别优惠。"
    translate None chapter_seventeen_0026:
        c "我就知道可以指望你！太好了！其实如果我没能分到一件的话，感觉会有点被冷落呢…"
    translate None chapter_seventeen_0027:
        a "那就四套衣服。我相信你会帮我设计吧？"
    translate None chapter_seventeen_0028:
        c "噢，噢！我已经有些想法了。"
    translate None chapter_seventeen_0029:
        "阿什俯身让赛恩在他耳边低语，然后点头表示同意。"
    translate None chapter_seventeen_0030:
        a "你对这事考虑得很周全啊。好吧，我们先量尺寸。是叫莱奥斯对吧？先跟我来。"

    hide ashe with dissolve
    show raen at slightright
    show cyne at slightleft
    with move

    translate None chapter_seventeen_0031:
        "阿什领着莱奥斯上了楼，消失在视线中。与此同时，我们其余人在附近的沙发上安顿下来。"
    translate None chapter_seventeen_0032:
        rs "他看起来人不错。不过扯坏七套衣服是怎么回事？"
    translate None chapter_seventeen_0033:
        c "别为那个操心！你知道，有时候就是会发生这种事。"
    translate None chapter_seventeen_0034:
        show raen n sur with dis
        rs "真的吗？怎么发生的？"
    translate None chapter_seventeen_0035:
        show cyne n sad with dis
        c "呃…该怎么说呢…你知道，有时候情到浓时…解开衣服扣子不是你的第一反应？"
    translate None chapter_seventeen_0036:
        "我困惑地看了他一会儿才反应过来。啊…好吧。我懂了。"
    translate None chapter_seventeen_0037:
        show raen n emb with dis
        rs "噢-哦…原来如此！"
    translate None chapter_seventeen_0038:
        f sur "…把完好无损的衣服弄坏似乎有点浪费。"
    translate None chapter_seventeen_0039:
        show cyne n hap with dis
        c "这个嘛，这给了我添置新衣的理由，所以算是双赢吧。"
    translate None chapter_seventeen_0040:
        l ang "哎哟…！嘿，别这样！"
    translate None chapter_seventeen_0041:
        a neu "马上就好。我只是在给你量尺寸。"
    translate None chapter_seventeen_0042:
        l emb "好冰！喂！"
    translate None chapter_seventeen_0043:
        show raen n sad with dis
        rs "..."
    translate None chapter_seventeen_0044:
        f shy "听起来他玩得很开心…"
    translate None chapter_seventeen_0045:
        show cyne n sur with dis
        c "他确实很爱抱怨。"

    hide raen
    hide cyne
    with dissolve
    translate None chapter_seventeen_0046:
        "莱奥斯走下楼梯，示意福恩跟他上去。没过多久，福恩和莱奥斯都量完了，终于轮到我了。"


    scene bg primrose with dissolve:
        xpos 0.55 ypos 1.31 xanchor 0.5 yanchor 1.0 zoom 1.42

    translate None chapter_seventeen_0047:
        "我快步走上楼梯，进入楼上的工作室。"
    translate None chapter_seventeen_0048:
        stop music fadeout 2.0
        a neu "是叫雷恩对吧？"
    translate None chapter_seventeen_0049:
        rs sad "是的。抱歉我们突然造访，您一定很忙…"
    translate None chapter_seventeen_0050:
        a smi "一点也不。能为赛恩的朋友帮忙我很高兴。"
    translate None chapter_seventeen_0051:
        rs smi "…你们俩看起来很亲密。"
    translate None chapter_seventeen_0052:
        a neu "他一直是我重要的客户，但不仅如此…他是个有点爱惹麻烦，有点吵闹，还有些叛逆习惯的家伙…"
    translate None chapter_seventeen_0053:
        a smi "但他是个好孩子。我非常喜欢他。他身上的那股热情很难被浇灭。"
    translate None chapter_seventeen_0054:
        play music "sounds/bgm/night.ogg" fadeout 2.0
        a "…而且他显然也很喜欢你呢。"
    translate None chapter_seventeen_0055:
        rs sur "你这么认为吗？"
    translate None chapter_seventeen_0056:
        "我脱下衬衫，他开始从头到脚给我量尺寸。我注意到他颈间垂着一颗紫色宝石，在我眼前晃荡。"
    translate None chapter_seventeen_0057:
        a neu "老实说，我有点担心他。他从不是那种善于交友的人。事实上，这是他第一次带别人来这儿。"
    translate None chapter_seventeen_0058:
        a smi "我看得出你是把他们凝聚在一起的纽带。"
    translate None chapter_seventeen_0059:
        rs sur "我总以为…拥有那样的自信，不可能不被朋友环绕。"
    translate None chapter_seventeen_0060:
        a neu "我相信，这让你对他而言更加重要。"



label ashe_shop:
    if ashe_count == 3:
        jump choice_thirty_done

    window hide
    menu:
        "询问他的项链" if ashe_necklace:
            window show dissolve
            $ ashe_count += 1
            $ ashe_necklace = False
            $ ashe_enough = True
            jump askashenecklace

        "询问锡德卡汉的生活" if ashe_sc:
            window show dissolve
            $ ashe_count += 1
            $ ashe_sc = False
            $ ashe_enough = True
            jump askashesc

        "询问众神的事" if ashe_gods:
            window show dissolve
            $ ashe_count += 1
            $ ashe_gods = False
            $ ashe_enough = True
            jump askashegods

        "问够了" if ashe_enough:
            window show dissolve
            jump choice_thirty_done


label askashenecklace:
    translate None chapter_seventeen_0061:
        rs sur "你的项链…那是…？"
    translate None chapter_seventeen_0062:
        "一瞬间，他脸上的笑容僵住了。短暂得刚好能让我察觉。"
    translate None chapter_seventeen_0063:
        a smi "…是我妻子送的礼物。"
    translate None chapter_seventeen_0064:
        rs sur "真美。她也有一条相配的吗？"
    translate None chapter_seventeen_0065:
        a neu "她那颗是最深的红色，就像她本人一样耀眼美丽。"
    translate None chapter_seventeen_0066:
        rs sad "…曾经是？她不在了吗？"
    translate None chapter_seventeen_0067:
        $ about_Ashe._text.append("他戴着一条美丽的项链，是亡妻的礼物。当谈起她时，你能看出他依然深爱着她胜过一切。")
        a sad "…不，已经不在了。不是肉体意义上的存在，但我仍能感觉她{a=set_entry:enc_people->about_Ashe}{color=#87CEEB}注视着我{/color}{/a}。"
    translate None chapter_seventeen_0068:
        rs sad "听你这么说…我很难过…"
    translate None chapter_seventeen_0069:
        a sad "…我也是。"
    translate None chapter_seventeen_0070:
        "他垂着眼帘，但手上的活计没停。"

    jump ashe_shop


label askashesc:
    translate None chapter_seventeen_0071:
        rs neu "在锡德卡汉生活是怎样的？"
    translate None chapter_seventeen_0072:
        a smi "总有干不完的活儿，所以我也没什么可抱怨的。我曾是个旅人，无处为家。"
    translate None chapter_seventeen_0073:
        rs sur "巡回裁缝？"
    translate None chapter_seventeen_0074:
        a neu "信不信由你，我以前是个护卫。特尔菲尔德来的商人雇我护送商队。他们卖的是我所见过最美的丝绸，但那时除了我的剑，我对什么都不感兴趣。"
    translate None chapter_seventeen_0075:
        a neu "现在我的时间都花在这间店和孤儿院。"
    translate None chapter_seventeen_0076:
        rs sur "你在孤儿院工作？"
    translate None chapter_seventeen_0077:
        a sad "拐角那家就是我开的。我尽量多抽时间过去，但…有时候怕还是不够。"
    translate None chapter_seventeen_0078:
        rs smi "我在孤儿院长大，如果那里和我记忆中一样…我的童年充满美好回忆。相信他们也有同感。"
    translate None chapter_seventeen_0079:
        $ about_Ashe._text.append("阿什曾经是商队护卫，现在他在商店楼上经营着一家孤儿院。他还提到自己从那里收养了女儿普莉姆。")
        a neu "希望如此。我们…我也从那里收养了女儿。她叫{a=set_entry:enc_people->about_Ashe}{color=#87CEEB}普莉姆{/color}{/a}。有时她会来店里玩，但通常都在孤儿院和其他孩子在一起。"
    translate None chapter_seventeen_0080:
        "他用软尺环住我的躯干，把尺寸记录在本子上。"

    jump ashe_shop

label askashegods:
    translate None chapter_seventeen_0081:
        rs sad "说来可能有点奇怪…但我听说在锡德卡汉，崇拜任何神明都是违法的。是真的吗？"
    translate None chapter_seventeen_0082:
        a sur "你知道吗，打听这种事的人都会失踪。"
    translate None chapter_seventeen_0083:
        rs sur "哦，我没有恶意，抱歉。"
    translate None chapter_seventeen_0084:
        a sad "没关系。我只是提醒你在这里不要随便和人说这些。大家都各扫门前雪，但他们无时无刻不在监视。你以为四下无人时稍有不慎，他们就会要你的命。"
    translate None chapter_seventeen_0085:
        a "不是字面意思，但这确实是个危险话题。"
    translate None chapter_seventeen_0086:
        a "总之…你没说错。神明崇拜已被禁止数百年了。不过仍有人暗中信仰。"
    translate None chapter_seventeen_0087:
        a sad "我曾经也相信有神灵庇佑，但现在不信了。"
    translate None chapter_seventeen_0088:
        "他低头对我微笑，但眼神依然冰冷。"

    jump ashe_shop


label choice_thirty_done:
    translate None chapter_seventeen_0089:
        a smi "快量完了。抬起手臂，我量最后一个尺寸。"
    translate None chapter_seventeen_0090:
        "他的目光立刻捕捉到我手臂上的神之刻印。凝视片刻后，他继续为我量体。"
    translate None chapter_seventeen_0091:
        a ann "…..你来锡德卡汉有何贵干？"
    translate None chapter_seventeen_0092:
        rs sad "如果我说是来观光的话，你大概不会信吧？我在找一个叫卡斯皮安的人。线索从斯塔格威奇开始，经过奥克斯哈伯，现在到了这里。"
    translate None chapter_seventeen_0093:
        a neu "卡斯皮安…不能说认识。但这个名字似乎有点耳熟…"
    translate None chapter_seventeen_0094:
        "他轻轻拍了拍我的手臂，把我的注意力引回神之刻印上。"
    translate None chapter_seventeen_0095:
        a neu "你要当心。我不爱说闲话，但…在锡德卡汉，没人会放弃打压他人的机会。那些琐碎争吵、谎言…他们为了权力什么都干得出来。"
    translate None chapter_seventeen_0096:
        a sad "只是…尽量注意安全。"
    translate None chapter_seventeen_0097:
        rs sur "你是说—"
    translate None chapter_seventeen_0098:
        a smi "那我们就算完事了！你要不下楼去？我得开始工作了。大概要花上几个小时，不过你想留下也可以。"
    translate None chapter_seventeen_0099:
        a "总比穿着那身衣服在外头冻着强。"
    translate None chapter_seventeen_0100:
        "他转身就走，压根没给人提问的机会。他开始从架子上取下布料和线，准备开工。"
    translate None chapter_seventeen_0101:
        "我沿着楼梯往下走，那三人还懒洋洋地待在原地。"

    stop music fadeout 2.0

    scene bg primrose with dissolve:
        size(1920, 1080)
    show raen n neu at cenleft
    show fawn n neu at cenright
    show cyne n hap at farleft
    show leos n neu at farright
    with dissolve

    translate None chapter_seventeen_0102:
        f "搞定了？"

    show raen n smi with dis
    play music "sounds/bgm/sidcaeham.ogg" fadeout 2.0
    translate None chapter_seventeen_0103:
        rs "我从没想过人体有这么多地方需要量尺寸…现在阿什对我的了解恐怕比我自己还多。"
    translate None chapter_seventeen_0104:
        rs "他说要几个小时，但我们留在这儿也无妨。说真的，我宁可在这儿坐着，也不想再去雪地里碰运气。嘶—冷死了！"
    translate None chapter_seventeen_0105:
        show raen n sad with dis
        rs "对了，呃…我在楼上顺便打听了下卡斯皮安，但阿什不认识他。老实说我不意外，就是有点失望。要真那么简单就好了，对吧？"
    translate None chapter_seventeen_0106:
        c "要知道，你千里迢迢来到这儿。慢慢来，好好欣赏风景嘛！你有的是时间。"
    translate None chapter_seventeen_0107:
        show cyne n mis with dis
        c "啊，澄清下我刚才的话—我就是那道风景。"
    translate None chapter_seventeen_0108:
        "时间…我真有时间吗？那个声音…有人来了…"
    translate None chapter_seventeen_0109:
        show cyne n sur with dis
        c "锡德卡汉太大了。我是说，大到离谱。斯塔格威奇和奥克斯哈伯在它旁边就像蚂蚁窝。这不是一时半会儿能搞定的事，你得认清现实。"
    translate None chapter_seventeen_0110:
        c "但我们总能找到的。"
    translate None chapter_seventeen_0111:
        rs "我连从哪儿开始都不知道…"
    translate None chapter_seventeen_0112:
        show cyne n hap with dis
        c "要不我们边蹦蹦跳跳穿过街道边喊\"卡斯皮安，卡斯皮安，你在哪儿？"
    translate None chapter_seventeen_0113:
        show leos n smi with dis
        l "没靠谱主意就闭嘴。"
    translate None chapter_seventeen_0114:
        show cyne n sad with dis
        c "我觉得这主意挺好啊…你真没劲。"
    translate None chapter_seventeen_0115:
        show leos n ang with dis
        l "嘿！我可有趣了！"
    translate None chapter_seventeen_0116:
        show cyne n hap with dis
        c "哦是吗？证明看看。"
    translate None chapter_seventeen_0117:
        l "这要怎么证明？"
    translate None chapter_seventeen_0118:
        c "你可以先来个街头蹦跳然后大喊—"
    translate None chapter_seventeen_0119:
        show leos n pen with dis
        l "当我没说。行，我是很无趣。"
    translate None chapter_seventeen_0120:
        rs "你有什么想法吗，福恩？"
    translate None chapter_seventeen_0121:
        show fawn n sad with dis
        f "嗯…"
    translate None chapter_seventeen_0122:
        f "我觉得可以先在人流密集的地方打听…早晚能碰到听说过他的人。"
    translate None chapter_seventeen_0123:
        rs "像是…集市啊，庆典活动之类的…"
    translate None chapter_seventeen_0124:
        show cyne n sur with dis
        c "虽然不确定有没有用，但新光庆典再过两天就要举办了。"
    translate None chapter_seventeen_0125:
        l "这名真蠢。是干什么的？"
    translate None chapter_seventeen_0126:
        c "这是我们国王驱逐伪神的庆典—好吧，现在讲这个故事有点不合时宜了，不是吗？"
    translate None chapter_seventeen_0127:
        show leos n smi with dis
        l "听起来像是你找借口胡闹。"
    translate None chapter_seventeen_0128:
        c "什么？我？才不会！"
    translate None chapter_seventeen_0129:
        c "但说真的，这事值得记在心上。可我没从你那漂亮的嘴里听到什么聪明主意，对吧？"
    translate None chapter_seventeen_0130:
        show leos n ang with dis
        l "….他们正在…构思。好主意需要时间！"
    translate None chapter_seventeen_0131:
        show cyne n hap with dis
        c "是是是，随你怎么说。"


    scene bg primrose sunset with dissolve:
        xpos 0.81 ypos 1.35 xanchor 0.5 yanchor 1.0
        linear 55.0 xpos 0.17 ypos 1.35 xanchor 0.5 yanchor 1.0

    translate None chapter_seventeen_0132:
        "争吵持续了一整天。有时莱奥斯会站起来来回踱步，对耗费的时间感到烦躁。福恩蜷缩在大扶手椅上打瞌睡。赛恩则想方设法招惹莱奥斯来找乐子。"
    translate None chapter_seventeen_0133:
        "总之，和往常差不多。"
    translate None chapter_seventeen_0134:
        "商店橱窗透出的红黄色光芒在房间里投下阴影。搭配原本温馨的氛围，显得温暖又舒适。"
    translate None chapter_seventeen_0135:
        "就在我也开始打盹时，阿什突然从楼上探出头来。"
    translate None chapter_seventeen_0136:
        a neu "你们四个能一个一个上来吗？我只需要做最后调整。"
    translate None chapter_seventeen_0137:
        f shy "..我先去。"
    translate None chapter_seventeen_0138:
        "说完他就上去了。我们都盯着楼梯，等待盛大揭幕时刻。就连莱奥斯和赛恩也出于好奇暂时停止了争吵。"
    translate None chapter_seventeen_0139:
        "没过多久，福恩带着羞涩的表情回到了人群。"


    scene bg primrose sunset with dissolve:
        xpos 0.54 ypos 1.25 xanchor 0.5 yanchor 1.0 zoom 0.84

    show fawn mw neu cloak blush with dissolve
    translate None chapter_seventeen_0140:
        f "觉…觉得怎么样？"
    translate None chapter_seventeen_0141:
        "我首先注意到他的斗篷。看起来就像夜空—仿佛由星辰编织而成。胸前装饰着大蝴蝶结，他正腼腆地拨弄着。"
    translate None chapter_seventeen_0142:
        "头顶戴着贝雷帽，阿什甚至给他编了发辫。"
    translate None chapter_seventeen_0143:
        rs sur "你看…看起来美极了…"
    translate None chapter_seventeen_0144:
        l sur "呵，也许这终究不是浪费时间。"
    translate None chapter_seventeen_0145:
        c hap "我跟你们说过的，对吧？！我只在这家店购物是有原因的！"
    translate None chapter_seventeen_0146:
        f "这衣服…好舒服。我从来…从来没穿过这样的…"
    translate None chapter_seventeen_0147:
        "他望向赛恩，对方回以微笑。"
    translate None chapter_seventeen_0148:
        show fawn mw smi cloak blush with dis
        f "谢—"
    translate None chapter_seventeen_0149:
        c "不用谢！看你这么可爱就值了。好了大个子，该你了！"
    translate None chapter_seventeen_0150:
        l neu "…..好吧。"
    translate None chapter_seventeen_0151:
        hide fawn mw with dissolve
        "令福恩明显惊恐的是，赛恩对他新衣服的每个细节都异常感兴趣。在转了四圈把福恩转晕后，莱奥斯从楼梯走了下来。"


    show leos mw neu cloak with dissolve

    translate None chapter_seventeen_0152:
        c "哇，好健壮的身材！噢，我感觉我现在就要爱上你了！"
    translate None chapter_seventeen_0153:
        show leos mw thi cloak with dis
        "身着红黑装扮的莱奥斯透着股精明世故的气息。他不自在地拉扯着衣服，低头审视自己并叹了口气。"
    translate None chapter_seventeen_0154:
        rs smi "这很适合你！你看上去真英俊。"
    translate None chapter_seventeen_0155:
        l "本意是要我不起眼。穿这种花哨玩意儿，所有人都会盯着我看。"
    translate None chapter_seventeen_0156:
        c sur "你在开玩笑吗？这算什么笑话？"
    translate None chapter_seventeen_0157:
        c "你扎眼得像红肿的拇指。红发醒目，踩着高跟靴，还露着腹肌。这怎么能叫低调？"
    translate None chapter_seventeen_0158:
        c "至少现在你能融入这里的人群了。"
    translate None chapter_seventeen_0159:
        l "....."
    translate None chapter_seventeen_0160:
        show leos mw thi cloak blush with dis
        l "….我的头发本来可以不弄的，至少…"
    translate None chapter_seventeen_0161:
        f c wemb "他说得有道理。你之前的佣兵打扮确实有点怪。"
    translate None chapter_seventeen_0162:
        c "除非…你是那种佣兵？比如\"爸爸求求用剑捅我\"那种？"
    translate None chapter_seventeen_0163:
        rs sad "....."
    translate None chapter_seventeen_0164:
        hide leos with dissolve
        c hap "噢，轮到我了，轮到我了！"
    translate None chapter_seventeen_0165:
        "他一步跨两个台阶蹦跳着。我们在楼下都能听见他的咯咯笑声。"
    translate None chapter_seventeen_0166:
        "莱奥斯装作满不在乎，但我能看出他在偷瞄镜子。他永远不会承认，但我确定他心里很感激。"
    translate None chapter_seventeen_0167:
        "他只是有点害羞。是莱奥斯式的特殊害羞—可能捅你一刀也可能脸红，五五开吧。"
    translate None chapter_seventeen_0168:
        "没过多久，赛恩就炮弹般冲回我们身边。"
    translate None chapter_seventeen_0169:
        show cyne mw2 smi cloak with dissolve
        c "我来啦！觉得怎样？美吗？绝吗？惊艳吗？还是说闪瞎眼？快夸别憋着！"
    translate None chapter_seventeen_0170:
        "我第一眼就注意到他那被梦幻绿绸束出的细腰。披肩从肩头垂落，浑身散发着\"快看我\"的气场。"
    translate None chapter_seventeen_0171:
        "完美至极。"
    translate None chapter_seventeen_0172:
        rs sur "哇！你看起来像个王子！"
    translate None chapter_seventeen_0173:
        show cyne mw2 hap blush with dis
        c "这评价我收下！"
    translate None chapter_seventeen_0174:
        f c wsur"确实很帅…"
    translate None chapter_seventeen_0175:
        l c wsmu "你缩水了？看起来比之前还矮。"
    translate None chapter_seventeen_0176:
        show cyne mw2 sur -blush with dis
        c "呸，没礼貌！至少我不是豆秆身材！"
    translate None chapter_seventeen_0177:
        rs "我想…该我了？"
    translate None chapter_seventeen_0178:
        f "我很期待看他给你设计了什么。"
    translate None chapter_seventeen_0179:
        rs smi "嗯，我也是。马上回来！"


    scene bg primrose sunset with dissolve:
        xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 0.71 zoom 1.21
    translate None chapter_seventeen_0180:
        "今天第二次，我走上楼梯。阿什站在桌前，对他的作品做着最后检视。"
    translate None chapter_seventeen_0181:
        a neu "我得说，这件是最棘手的。"
    translate None chapter_seventeen_0182:
        rs sur "什么？"
    translate None chapter_seventeen_0183:
        a "我一生中做过许多衣服，为赛恩做的也不少。直到现在，他大多细节都交由我决定。"
    translate None chapter_seventeen_0184:
        a "但这次他的要求是\"能展现他内心的东西\"。"
    translate None chapter_seventeen_0185:
        a smi "他还补充说\"再加点性感调剂\"。"
    translate None chapter_seventeen_0186:
        "我脱下衣服，阿什帮我穿上新衣。它比以往更沉甸，更有分量。"
    translate None chapter_seventeen_0187:
        a "嗒哒。看看吧。"
    translate None chapter_seventeen_0188:
        show raen mw2 sur cloak with dissolve
        "他让我转圈，直到我面对从地板延伸到天花板的大镜子。"
    if achievement.has("group_outfits"):
        pass
    else:
        $ renpy.display_notify("【成就解锁：新形象，这是谁？】")
    python:
        achievement.grant("group_outfits")
        achievement.sync()
    translate None chapter_seventeen_0189:
        "映入眼帘的是件巨大的绿色斗篷，其繁复细节让我不由屏息。蜿蜒精致的刺绣上垂挂着宝石。"
    translate None chapter_seventeen_0190:
        "白色、金色与绿色交织…"
    translate None chapter_seventeen_0191:
        "这比我想象中还要美丽。"
    translate None chapter_seventeen_0192:
        "西装的白色与金色让我想起家乡—想到说书人。"
    translate None chapter_seventeen_0193:
        "我触碰胸前的衣料。这一切都显得…如此不真实。"
    translate None chapter_seventeen_0194:
        rs "我…我不知道该说什么…"
    translate None chapter_seventeen_0195:
        "他示意我跟随，我们回到店铺前厅。当我下楼时，福恩、赛恩和莱奥斯都抬头看向我。"


    scene bg primrose sunset:
        xpos 0.54 ypos 1.25 xanchor 0.5 yanchor 1.0 zoom 0.84

    show cyne nw sur cloak at farleft
    show raen nw neu blush cloak at cenleft
    show leos nw sur blush cloak at farright
    show fawn nw sur blush cloak at cenright
    with dissolve

    translate None chapter_seventeen_0196:
        f "...."
    translate None chapter_seventeen_0197:
        c "......"
    translate None chapter_seventeen_0198:
        l "........."
    translate None chapter_seventeen_0199:
        c "哦，阿什，这可能是你最杰出的作品！"
    translate None chapter_seventeen_0200:
        a smi "我确实为此感到骄傲。"
    translate None chapter_seventeen_0201:
        f "你…你看起来真好。就像…真的，真的好极了。"
    translate None chapter_seventeen_0202:
        show leos nw thi with dis
        l "哼..还不赖。比之前强。至少不那么像孤儿了。"
    translate None chapter_seventeen_0203:
        show raen nw sad with dis
        rs "哈哈…可我就是孤儿啊…"
    translate None chapter_seventeen_0204:
        show raen nw hap with dis
        rs "连这样的发型都让我不习惯。我像是变了个人。阿什，赛恩，不知该怎么感谢你们。太棒了。"
    translate None chapter_seventeen_0205:
        "虽只是新衣服，我却感到焕然一新，准备好继续旅程。"
    translate None chapter_seventeen_0206:
        rs "赛恩，我们看起来很配！真是巧合。"
    translate None chapter_seventeen_0207:
        show cyne nw smi with dis
        c "哦…是啊。巧合！"
    translate None chapter_seventeen_0208:
        "赛恩递来一袋钱币，在我们离开时挥手道别。"
    translate None chapter_seventeen_0209:
        a neu "等等。"
    translate None chapter_seventeen_0210:
        show raen nw sur with dis
        a "知道吗…最近我接到不少上层家族的订单。明晚将有场盛大舞会，只凭邀请函入场。"
    translate None chapter_seventeen_0211:
        show leos nw neu -blush with dis
        a "我不知道这能不能帮上忙，甚至不确定你能不能进得去，不过…如果你想找个大量人群聚集的地方，没有比这更好的选择了。"
    translate None chapter_seventeen_0212:
        show cyne nw sur with dis
        c "啊！我都忘了这茬了！"
    translate None chapter_seventeen_0213:
        rs "有可能…吗？我们能进去吗？"
    translate None chapter_seventeen_0214:
        l "我们到外面再细说。"
    translate None chapter_seventeen_0215:
        "我们最后道了谢说了再见，离开了这间沐浴在温暖落日余晖中的小店，转而踏上白雪皑皑的街道。"
    window hide dissolve

    if fawn_relationship > leos_relationship and fawn_relationship > cyne_relationship:
        jump fawnroute1

    elif leos_relationship > fawn_relationship and leos_relationship > cyne_relationship:
        jump leosroute1

    elif cyne_relationship > leos_relationship and cyne_relationship > fawn_relationship:
        jump cyneroute1

    else:
        jump cyneroute1
