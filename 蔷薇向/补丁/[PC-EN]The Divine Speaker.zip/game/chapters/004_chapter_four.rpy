label chapter_four_start:
    scene bg pondsunset with dissolve:
        xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.29
        easein 13.0 xpos 0.5 ypos 1.24 xanchor 0.5 yanchor 1.0 zoom 1.29


    window show dissolve
    translate None chapter_four_0001:
        "我们来到一小片开阔地。湖边杂草丛生、鲜花绽放，蛙鸣阵阵。"
    translate None chapter_four_0002:
        "除了涓涓细流，湖水基本静止不动。"

    scene bg pondsunset
    show leos n sunset neu at right
    show raen n sunset neu at center
    show fawn n sunset neu at left
    with dissolve

    translate None chapter_four_0003:
        rs "你觉得这水够干净能喝吗…？"
    translate None chapter_four_0004:
        l "谁知道这种地方会滋生什么污秽。"
    translate None chapter_four_0005:
        f "嗯..有些是活水，应该勉强能喝…"
    translate None chapter_four_0006:
        rs "真的吗？"
    show fawn n sunset sad with dis
    translate None chapter_four_0007:
        f "…..也许吧。如果是完全的死水我才更担心…但想必没问题…"
    translate None chapter_four_0008:
        "他看起来并未完全信服。不过这附近确实没别的取水处。"
    translate None chapter_four_0009:
        f "能这么快找到水源算走运了。但真希望我们能随身带些…"
    translate None chapter_four_0010:
        f "前路还很漫长呢。"
    show leos n sunset smu with dis
    play music "sounds/bgm/night.ogg" fadeout 1
    translate None chapter_four_0011:
        l "那我就自封为监督员了。赶紧干活。"
    play sound "sounds/sfx/fallonground.ogg" fadeout 1
    translate None chapter_four_0012:
        "他扑通坐在草地上。这很符合他的作风。"
    translate None chapter_four_0013:
        f "我看看能不能找到有用的东西。"

    hide fawn with dissolve
    show raen n sunset at slightleft
    show leos n sunset at slightright
    with move
    translate None chapter_four_0014:
        "福恩立刻开始翻检周围的灌木丛。"
    translate None chapter_four_0015:
        rs "嗯…"
    translate None chapter_four_0016:
        rs "喂，莱奥斯，你那背包里总该有点实用的东西吧。"
    translate None chapter_four_0017:
        l "非常实用的东西。过来瞧瞧。"
    translate None chapter_four_0018:
        "我凑过去看向他的行囊。"
    show raen n sunset sur with dis
    translate None chapter_four_0019:
        rs "又是匕首…？认真的？"
    show leos n sunset smi with dis
    translate None chapter_four_0020:
        "他咧嘴笑了。这个自鸣得意的混蛋。"
    show raen n sunset sad with dis
    translate None chapter_four_0021:
        rs "算了。你根本派不上用场。"
    translate None chapter_four_0022:
        l "哈哈哈。多几把利刃怎么就无用了？"
    translate None chapter_four_0023:
        rs "在荒野求生时这些全是累赘。"
    translate None chapter_four_0024:
        l "我能想到无数匕首助你活命的用途。"
    translate None chapter_four_0025:
        rs "什么…？"
    show leos n sunset neu with dis
    translate None chapter_four_0026:
        l "你太天真了。"
    translate None chapter_four_0027:
        "呃，真让人火大。"
    translate None chapter_four_0028:
        "我们为什么还要帮他来着..？"
    translate None chapter_four_0029:
        "他满脸自得地看着我和福恩在四周搜寻。"


    scene bg pondsunset with Dissolve(1.0):
        size (1920, 1080) crop (856, 436, 1063, 643)
        linear 40.0 crop ((0, 437, 1063, 643))
    translate None chapter_four_0030:
        "所以…他果然还藏着更多匕首…"
    translate None chapter_four_0031:
        "看来收缴他的武器纯属浪费时间。"
    translate None chapter_four_0032:
        "这让我隐隐不安。我完全不放心让他持有武器。何况现在也很难夺走。"
    translate None chapter_four_0033:
        "他会在夜里袭击我们吗？天晓得。我觉得他干得出来。"
    translate None chapter_four_0034:
        "但或许他觉得欠我们人情就不会动手…？可能吧。只是非常不确定的假设。"
    translate None chapter_four_0035:
        "看他那架势，显然精通武器使用。我可不想再体验被刀架脖子的滋味。"
    translate None chapter_four_0036:
        "抚上咽喉时，早先的伤口仍隐约可感。"
    translate None chapter_four_0037:
        "虽然还有点刺痛，但好在只是轻微伤。刚才那场冲突原本可能会更糟。"
    translate None chapter_four_0038:
        "我在灌木丛中略微搜寻，又在周边察看了一番。"
    translate None chapter_four_0039:
        "周围没什么东西。棍棒、石块、偶尔几朵蘑菇……"


    scene bg pondsunset
    show fawn n sunset neu at slightleft
    show raen n sunset neu at slightright
    with dissolve
    translate None chapter_four_0040:
        "我摸索着回到福恩身边。"
    show fawn n sunset sad with dis
    translate None chapter_four_0041:
        rs "找到什么了吗？"
    translate None chapter_four_0042:
        f "没有…我觉得这里太偏僻了，找不到任何有用的东西。"
    translate None chapter_four_0043:
        rs "看来我们带不走什么东西了。不过至少现在能喝上水了。"
    translate None chapter_four_0044:
        rs "莱奥斯！想喝水就自己过来取！"

    show raen n sunset at center
    show fawn n sunset at left
    with move
    show leos n sunset smu at right with dis

    translate None chapter_four_0045:
        l "你不是应该照顾我吗？难道要我一个人走过去？"
    translate None chapter_four_0046:
        l "你们两个可真是帮了大忙。"
    show leos n sunset ang with dis
    translate None chapter_four_0047:
        "他咬着嘴唇，从草地上艰难地撑起身子。"
    translate None chapter_four_0048:
        "尽管…好吧，虽然他人是这样，我还是有点同情他。真希望能帮上什么忙。"
    show fawn n sunset neu with dis
    translate None chapter_four_0049:
        f "路上我会留意更多水源。"
    translate None chapter_four_0050:
        rs "好的，谢谢福恩。"

    hide raen
    hide leos
    hide fawn
    show raen m sunset neu
    with Dissolve(0.6)
    translate None chapter_four_0051:
        "我在水边坐下，看着水中自己的倒影。"
    translate None chapter_four_0052:
        "近乎静止的水面上，我的镜像直勾勾地回望着我。"
    show raen m sunset sad with dis
    translate None chapter_four_0053:
        "呃…我看起来糟透了。"
    translate None chapter_four_0054:
        "浑身脏污，遍体鳞伤，眼睛下面已经挂着大大的黑眼圈。"
    translate None chapter_four_0055:
        "这几天确实发生了很多事，但也不该憔悴成这样。"
    translate None chapter_four_0056:
        f sad "你没事吧？不渴吗？"
    translate None chapter_four_0057:
        rs "啊…"
    translate None chapter_four_0058:
        rs "不，我当然渴…"
    translate None chapter_four_0059:
        rs "最近发生了太多事。我可能只是需要时间消化。"
    translate None chapter_four_0060:
        l neu "沉湎过去毫无意义。接受现实，继续前行吧。"
    translate None chapter_four_0061:
        l "失去重要的东西的不止你一个。"
    translate None chapter_four_0062:
        "我扭头瞥去。他们两个都站在身后，静静注视着。"
    translate None chapter_four_0063:
        "莱奥斯双臂交叉抱在胸前，脸上带着难以形容的表情。"
    translate None chapter_four_0064:
        "想来他们也都有重要的东西失去了吧…"
    translate None chapter_four_0065:
        rs "嗯，我知道…"
    translate None chapter_four_0066:
        "我把双手浸入刺骨的冷水。汗水涔涔的皮肤接触到清凉的水，顿感清爽。"
    translate None chapter_four_0067:
        "我快速洗了把脸，又喝了几口水。仅仅这样就让我的状态好了许多。"
    translate None chapter_four_0068:
        "或许该趁此机会检查下伤口。"

    hide raen with dis
    show raen n sunset sad at slightright
    show fawn n sunset sad at slightleft
    with dissolve
    translate None chapter_four_0069:
        f "让我帮忙…"
    translate None chapter_four_0070:
        "福恩盘腿坐到我面前，解开缠在我手臂上的布条查看伤势。"
    translate None chapter_four_0071:
        f "看起来已经好多了。我简单清理下重新包扎就好。"
    translate None chapter_four_0072:
        "他用指尖抬起我的下巴，快速检查了我的喉咙。看起来毕竟只是道擦伤。"
    translate None chapter_four_0073:
        f "呃..莱-莱奥斯…如果你愿意的话…我也可以帮你检查…"

    show raen n sunset sad at center
    show fawn n sunset sad at left
    with move
    show leos n sunset neu at right with dis

    translate None chapter_four_0074:
        "他没有抱怨，在我对面坐了下来。"
    translate None chapter_four_0075:
        "他神色平静地让福恩再次检查并清理他的伤口。整个过程，他都沉默地注视着我。"
    translate None chapter_four_0076:
        l "所以…你的手臂是怎么回事？那不是今天的伤。"
    show raen n sunset sur with dis
    translate None chapter_four_0077:
        rs "呃…"
    translate None chapter_four_0078:
        "就在福恩看向我的同一时刻，我也看向了他。"
    translate None chapter_four_0079:
        "我该说什么…？他为什么要关心这个？"
    translate None chapter_four_0080:
        "他对我摇了摇头。也许他认为最好不要告诉他发生了什么。"
    show raen n sunset sad with dis
    translate None chapter_four_0081:
        rs "我…晚上散步时被树枝刮伤的。"
    translate None chapter_four_0082:
        l "嗯…"
    translate None chapter_four_0083:
        "他看起来并不相信。"
    translate None chapter_four_0084:
        "好吧。我不需要说服他。"
    translate None chapter_four_0085:
        rs "嗯…虽然你说过不了解我的神之刻印…但再看看吧。说不定能想起什么…"
    translate None chapter_four_0086:
        "我卷起另一只袖子，向他展示了我手臂上蔓延的黑色刻印。"
    translate None chapter_four_0087:
        rs "你让我去档案馆时，我在一本书里发现了相同的刻印…但我完全看不懂内容。"
    translate None chapter_four_0088:
        "这一次，莱奥斯表情严肃地仔细听着我的话。"
    translate None chapter_four_0089:
        rs "我唯一注意到的是卡斯皮安这个名字。他可能是皇室最后的后裔。"
    translate None chapter_four_0090:
        rs "或许…或许他能解读这些刻印。"
    show leos n sunset sur with dis
    translate None chapter_four_0091:
        l "卡斯皮安…？"
    show leos n sunset ang with dis
    translate None chapter_four_0092:
        l "最后的国王不是卡斯皮安。他从未登基。"
    translate None chapter_four_0093:
        rs "什么…？"
    translate None chapter_four_0094:
        l "卡斯皮安从未继承王位。"
    translate None chapter_four_0095:
        rs "但你听说过他？"
    translate None chapter_four_0096:
        rs "我从未听过关于他的任何消息…"
    show leos n sunset neu with dis
    translate None chapter_four_0097:
        l "你多大年纪？"
    translate None chapter_four_0098:
        rs "我刚成年。十八岁。"
    translate None chapter_four_0099:
        l "哼，这就说得通了。那时他已经很少露面，甚至可能根本不在。你还在襁褓时他就失踪了。"
    translate None chapter_four_0100:
        l "当时的我…也只是个孩子，所以对他所知不多。"
    translate None chapter_four_0101:
        stop music fadeout 3.0
        l "我只知道他和整个家族都遭遇了不测。"
    translate None chapter_four_0102:
        rs "他们都死了…？他也死了吗？"
    translate None chapter_four_0103:
        l "…..谁知道呢。没找到他的尸体。"
    translate None chapter_four_0104:
        l "但从那以后也没人再见过他。"
    translate None chapter_four_0105:
        "我的心沉了下去。"

    $ about_Caspian.locked = False

    translate None chapter_four_0106:
        "{a=set_entry:enc_people->about_Caspian}{color=#87CEEB}卡斯皮安{/color}{/a}…他是我唯一的希望…"
    show fawn n sunset sur with dis
    translate None chapter_four_0107:
        f "呃..但你也不能确定吧。我都能在这外面活下来..说不定他正躲在某个地方。"
    show leos n sunset smi with dis
    translate None chapter_four_0108:
        l "哈！不可能。没人能在这种环境下生存这么久。"
    translate None chapter_four_0109:
        "他把福恩从头到脚打量了一遍。"
    show leos n sunset neu with dis
    translate None chapter_four_0110:
        l "至少没有正常人能做到。"
    show fawn n sunset sad with dis
    translate None chapter_four_0111:
        rs "....."
    translate None chapter_four_0112:
        l "反正…没人知道这件事，就算知道，也没人会谈论。"
    translate None chapter_four_0113:
        l "我的意思是，你甚至不知道他存在过，对吧？"
    translate None chapter_four_0114:
        l "…不过我不在乎。对我而言已经无所谓了，再也不重要了。"
    translate None chapter_four_0115:
        "再不了？"
    translate None chapter_four_0116:
        "不过…你说得确实有道理…"
    translate None chapter_four_0117:
        "我只知道我们曾经有过君主制，有国王和皇室。"
    translate None chapter_four_0118:
        "但从未听过细节。连它什么时候被废除都不清楚。"
    translate None chapter_four_0119:
        "奇怪。"
    translate None chapter_four_0120:
        l "......."
    play music "sounds/bgm/night.ogg" fadein 1
    translate None chapter_four_0121:
        l "所以呢…"
    translate None chapter_four_0122:
        l "你的衬衫-"
    show fawn n sunset sur with dis
    translate None chapter_four_0123:
        f "你是在和我说话…？"
    translate None chapter_four_0124:
        l "不然我还能跟谁说？没错，就是你。"
    translate None chapter_four_0125:
        f "我的…衬衫？这是我捡到的…"
    translate None chapter_four_0126:
        l "不久前我丢了件很像的"
    translate None chapter_four_0127:
        f "….在我家…原址附近的河岸找到的…"
    translate None chapter_four_0128:
        rs "你的衬衫是怎么丢的，莱奥斯？"
    translate None chapter_four_0129:
        l "....."
    show leos n sunset sur with dis
    translate None chapter_four_0130:
        l "我在河边洗衣服时…"
    translate None chapter_four_0131:
        f "......."
    translate None chapter_four_0132:
        l "..........."
    translate None chapter_four_0133:
        rs "哈…哈……认真的？"

    show bg pondnight2
    show fawn n dark
    show leos n dark
    show raen n dark
    with dis4

    translate None chapter_four_0134:
        f "哦…"
    translate None chapter_four_0135:
        f "天色开始变得很暗了。"
    translate None chapter_four_0136:
        rs "今天感觉特别漫长…"
    translate None chapter_four_0137:
        "我们聊了这么久，都没注意到天色越来越暗。"
    translate None chapter_four_0138:
        rs "我们该休息了。"
    show fawn n dark shy with dis
    translate None chapter_four_0139:
        f "越往前走会越冷。今晚最好…我们挨近点睡…"
    translate None chapter_four_0140:
        "他又脸红了。还挺可爱的。"
    show leos n dark neu with dis
    translate None chapter_four_0141:
        l "你俩想抱团取暖随便。我一个人没问题。"

    hide leos with dissolve
    show fawn n dark at slightleft
    show raen n dark at slightright
    with move

    translate None chapter_four_0142:
        "他掸了掸衣服就快步走开，到看不见的地方睡觉去了。"
    translate None chapter_four_0143:
        "他拒绝我倒不意外，但这样有点失礼。"
    show fawn n dark sad with dis
    translate None chapter_four_0144:
        f "我…去找个舒服的地方。"
    hide fawn with dissolve
    show raen n dark at center with move
    translate None chapter_four_0145:
        "福恩朝反方向走了。"

    window hide

    menu:

        "我得去看看莱奥斯":
            $ leos_relationship +=1
            $ chose_leos = True
            window show dissolve
            jump leos_sleep

        "今晚我会睡在福恩附近":
            $ fawn_relationship +=1
            $ chose_fawn = True
            window show dissolve
            jump fawn_sleep

label leos_sleep:
    translate None chapter_four_0146:
        "还是有点担心带着伤的莱奥斯独自离开。要是出什么事，我们得等到明早才会发现。"
    translate None chapter_four_0147:
        "而且…虽然不太想承认…"
    translate None chapter_four_0148:
        "我害怕。他身上还带着那些武器，所以我要盯着他。"
    translate None chapter_four_0149:
        "或者他可以在半夜溜走，然后告诉大家我们的位置…"
    translate None chapter_four_0150:
        "福恩应该没事的，对吧？"
    translate None chapter_four_0151:
        "回头瞥了一眼福恩后，我朝着莱奥斯刚刚离开的方向跟去。"

    show raen n dark neu at slightleft with move
    show leos n dark neu at slightright
    with dis

    translate None chapter_four_0152:
        "花了一分钟才找到他的所在。"
    translate None chapter_four_0153:
        "他正蹲在湖边的一块巨石上。"
    translate None chapter_four_0154:
        "我本想偷偷接近他，但没等我靠太近他就发现了我的视线。"
    show leos n dark smi with dis
    translate None chapter_four_0155:
        l "我还以为能享受个宁静的夜晚呢。"
    show raen n dark sad with dis
    translate None chapter_four_0156:
        rs "哦…"
    translate None chapter_four_0157:
        rs "抱歉，你想让我回去的话我这就走。"
    show leos n dark neu with dis
    translate None chapter_four_0158:
        l "….坐下。"
    translate None chapter_four_0159:
        l "你总不想吵醒你的小朋友吧？"
    translate None chapter_four_0160:
        "我在巨石另一侧坐下，与我们之间保持了些距离。"
    translate None chapter_four_0161:
        rs "….当然不想。"
    translate None chapter_four_0162:
        "然后是沉默。"
    translate None chapter_four_0163:
        "真尴尬…"
    translate None chapter_four_0164:
        l "......."
    translate None chapter_four_0165:
        "天啊太尴尬了。求你快点睡着吧。"
    translate None chapter_four_0166:
        "我完全没想好接下来怎么办。该说些什么？"
    translate None chapter_four_0167:
        rs "那个…呃…"
    translate None chapter_four_0168:
        rs "为什么你一个人来这里？"
    translate None chapter_four_0169:
        "他盯了我一会儿，又将注意力转回水面。"
    show leos n dark smi with dis
    translate None chapter_four_0170:
        l "怎么？你想让我和你那森林伙伴搂搂抱抱？谢了，没兴趣。"
    translate None chapter_four_0171:
        l "这真的很重要吗？"
    translate None chapter_four_0172:
        rs "我想不重要…"
    translate None chapter_four_0173:
        rs "但…我们都被困在同样的处境。无处可去，无人可依。我们是不是该试着好好相处？"

    show leos n dark neu with dis
    stop music fadeout 3.0

    translate None chapter_four_0174:
        l "你之前是撞到头了，还是天生就这么蠢？"
    translate None chapter_four_0175:
        rs "什-"
    show raen n dark sur with dis
    translate None chapter_four_0176:
        rs "啊！"

    play sound "sounds/sfx/fallonground.ogg"

    scene bg pondnight2 with vpunch:
        xpos 0.84 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.86
    translate None chapter_four_0177:
        "他猛地将我推倒，后背重重撞上岩石。"
    translate None chapter_four_0178:
        rs hur "嗷！"
    translate None chapter_four_0179:
        "眨眼间他已压制住我，居高临下面孔逼近。"
    play music "sounds/sfx/horror.ogg" fadein 1.0
    translate None chapter_four_0180:
        "那凝视让我不敢轻举妄动。不，是根本动弹不得，仿佛一个眼神就将我冻结。"
    translate None chapter_four_0181:
        "我彻底被逼入绝境。"
    translate None chapter_four_0182:
        l neu "抱歉，或许你忘了我出现在这里的原因。"
    translate None chapter_four_0183:
        l "忘了我是为什么才和你们两个蠢货困在一起？"
    translate None chapter_four_0184:
        rs "....."
    translate None chapter_four_0185:
        l smi "你肯定是想来监视我吧？防止我半夜搞什么动作？"
    translate None chapter_four_0186:
        l "蠢到没想过这会让你更危险吗？真以为你在这儿能降低我的威胁？"
    translate None chapter_four_0187:
        l smu "猎物自己送上门了。"

    play sound "sounds/sfx/clothrustle.ogg"
    translate None chapter_four_0188:
        "他的手伸向腿侧的皮袋。"
    translate None chapter_four_0189:
        "我们俩都知道他口袋里装了什么。就是那些福恩和我居然蠢到没从他身上收缴的匕首。"

    play sound "sounds/sfx/knifeunsheath.ogg"


    scene gallery_17 with dissolve:
        size (1920, 1080) crop (315, 150, 1261, 676)
    translate None chapter_four_0190:
        "他从腰包里抽出一把，在我脸上方比划着。"
    translate None chapter_four_0191:
        "他挑眉看着我沉默的样子。"
    translate None chapter_four_0192:
        l "哦？现在倒是学会闭嘴了？"

    scene gallery_17:
        size (1920, 1080) crop (315, 150, 1261, 676)
        easein 3.0 crop (315, 402, 1261, 676)
    pause(3.0)
    scene gallery_18 with dissolve:
        size (1920, 1080) crop (315, 402, 1261, 676)

    translate None chapter_four_0193:
        rs "….你不会动手的。"
    translate None chapter_four_0194:
        l "你说什么？"
    translate None chapter_four_0195:
        l "你凭什么觉得自己特别？凭什么觉得你比我杀过的其他人高贵？"
    scene gallery_18 with dissolve
    translate None chapter_four_0196:
        "他眼中泛着危险的光。冰冷，却又炽烈。夹杂着激情和渴望。但究竟在渴望什么？"
    translate None chapter_four_0197:
        rs "…你不会动手的。"
    translate None chapter_four_0198:
        "我始终未曾移开视线，竭尽全力掩饰着内心的不安。"
    translate None chapter_four_0199:
        "之前我就隐约觉得，近距离看他的面容有些不同。更柔和，更精巧—除了那双眼睛。"
    translate None chapter_four_0200:
        l "凭什么不会？"
    translate None chapter_four_0201:
        l "这很容易。只要轻轻割开你的气管，你连惨叫都发不出。"
    translate None chapter_four_0202:
        l "啊，我多期待听着你喉头涌血时窒息呛咳的声音。光是想象就令我愉悦。"
    translate None chapter_four_0203:
        l "那个矮冬瓜明天在湖里发现你面朝下的尸体时，根本搞不清状况。"

    scene gallery_18 with dissolve:
        size (1920, 1080) crop (315, 402, 1261, 676)
    scene gallery_19 with dissolve:
        size (1920, 1080) crop (315, 402, 1261, 676)

    translate None chapter_four_0204:
        rs "….请便啊。来，动手。"
    translate None chapter_four_0205:
        "我偏头冲他粲然一笑。"
    scene gallery_19 with dissolve
    translate None chapter_four_0206:
        rs "…要杀早杀了。我才不怕你。"
    translate None chapter_four_0207:
        "说实话他让我毛骨悚然。不过没必要让他知道。"
    translate None chapter_four_0208:
        l "......"
    translate None chapter_four_0209:
        rs "......"
    translate None chapter_four_0210:
        l "随你便。"

    scene bg pondnight2 with dis3:
        xpos 0.5 ypos 1.0 xanchor 0.74 yanchor 0.54 zoom 2.0

    translate None chapter_four_0211:
        stop music fadeout 2.0
        "他的身影从我上方撤离。"
    translate None chapter_four_0212:
        "转头望去，他正躺在不远处的岩石上凝望夜空。"
    translate None chapter_four_0213:
        "我没有挪动，依旧保持着被推倒时的姿势。"
    translate None chapter_four_0214:
        "一时间，唯有潺潺水声萦绕耳畔。"
    translate None chapter_four_0215:
        "肾上腺素逐渐褪去。经历这些事，倦意再也抑制不住。我伸着懒腰打了个大哈欠。"
    translate None chapter_four_0216:
        "不管目的地是哪儿，但愿接下来能太平点。"
    translate None chapter_four_0217:
        l neu "睡吧，雷恩。"
    translate None chapter_four_0218:
        "他突然出声吓我一跳。这么冷不丁叫我名字…"
    translate None chapter_four_0219:
        "本以为他睡着了，看来没有。他仍一动不动地望着繁星。"
    translate None chapter_four_0220:
        rs neu "…能问你个问题吗？"
    translate None chapter_four_0221:
        l neu "我想拦也拦不住吧。"
    translate None chapter_four_0222:
        rs neu "…你恨我吗？"
    translate None chapter_four_0223:
        l cur "恨你？为什么？"
    translate None chapter_four_0224:
        "我在胡说什么啊…"
    translate None chapter_four_0225:
        "我对莱奥斯的印象…说实话他看起来挺差劲的，但除了这些之外，他应该还有其他优点吧？"
    translate None chapter_four_0226:
        rs sad "要杀死一个人总得先恨他，对吧？"
    translate None chapter_four_0227:
        l pen "....."
    translate None chapter_four_0228:
        l neu "….不对。杀人并不需要恨对方。"
    translate None chapter_four_0229:
        l neu "你可以在对别人毫无感觉的情况下杀人。"
    translate None chapter_four_0230:
        l pen "….你也可以杀死对你重要的人。"
    translate None chapter_four_0231:
        rs sur "怎么会有人这么做？"
    translate None chapter_four_0232:
        l pen "谁知道呢。"
    translate None chapter_four_0233:
        l neu "晚安。"
    translate None chapter_four_0234:
        rs sad "….晚安。"
    translate None chapter_four_0235:
        "我沉沉地合上眼皮。毫不意外，很快就睡着了。"


    if achievement.has("leos_lake"):
        pass
    else:
        $ renpy.display_notify("成就达成：你真美丽")

    python:
        achievement.grant("leos_lake")
        achievement.sync()

    window hide dissolve

label narrationpond:
    scene black with eye_shut
    pause(2)
    translate None chapter_four_0236:
        n "…真相..找到它…"
    translate None chapter_four_0237:
        n "…审判…"
    translate None chapter_four_0238:
        n "….来自众神…."
    if chose_leos:
        jump leospondcont

    if chose_fawn:
        jump fawnpondcont

label leospondcont:
    scene bg pond day with eye_open:
        xpos 0.5 ypos 1.0 xanchor 0.74 yanchor 0.54 zoom 2.0
    window show dissolve

    translate None chapter_four_0239:
        "一个激灵，我在刺眼的晨光中睁开眼睛。手心与额头都是汗。"

    show leos c smi with dissolve
    translate None chapter_four_0240:
        l "早上好公主。终于醒了吗。"
    show layer master at hpunch
    translate None chapter_four_0241:
        rs sur "啊！"
    translate None chapter_four_0242:
        "他的声音在我耳边炸响。他就坐在我身旁，近到几乎肌肤相贴。"
    translate None chapter_four_0243:
        rs hur "…对、对不起。"
    translate None chapter_four_0244:
        l "怎么这么一惊一乍的？"
    translate None chapter_four_0245:
        rs sad "不，没什么。我只是…"
    translate None chapter_four_0246:
        rs "我们该去找福恩了。"

    scene bg pond day
    show leos n smi at slightright
    show raen n sad at slightleft
    with dissolve
    play sound "sounds/sfx/clothrustle.ogg"
    translate None chapter_four_0247:
        "他沉默地注视我片刻，随即起身站在我旁边。"
    translate None chapter_four_0248:
        l "你那位小朋友恐怕不乐意见你—昨晚你抛弃了他。"
    translate None chapter_four_0249:
        "两人循着昨晚的记忆回到与福恩分别的地方。他正靠着树干，望着湖水出神。"
    translate None chapter_four_0250:
        "我们走近时，他拒绝与我视线相交。"

    show leos n at right
    show raen n at center
    with move
    show fawn n sad at left with dis

    translate None chapter_four_0251:
        rs "福恩，你还好吗？"
    translate None chapter_four_0252:
        f "哦..还行，就是…有点累…"
    translate None chapter_four_0253:
        l "太阳早就升起来了。我们早该出发的。"
    jump choice_5_done

label fawn_sleep:
    translate None chapter_four_0254:
        "让莱奥斯独自待着应该没事。反正他也讨厌我在旁边，我也不想和他相处。"
    translate None chapter_four_0255:
        "按福恩说的，夜间还是集体行动更安全。我去找他吧。"
    hide raen with dissolve
    scene bg pondnight2 with dissolve:
        xpos 0.69 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.47
        linear 20.0 xpos 0.28 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.47
    translate None chapter_four_0256:
        "我沿着方才看见他离开的方向跟去。"
    translate None chapter_four_0257:
        "发现他抵着一棵大树，眼睑轻阖。"
    translate None chapter_four_0258:
        rs neu "嘿，福恩…醒着吗？"
    translate None chapter_four_0259:
        f shy "嗯。"
    translate None chapter_four_0260:
        "他微微睁眼向我点头。声音疲惫得厉害。"
    translate None chapter_four_0261:
        "我在他身旁坐下时，他朝这边挪了挪。穿这么少肯定很冷。"
    translate None chapter_four_0262:
        "衣物相触间，隔着布料都能感觉到他肌肤的寒意。"
    translate None chapter_four_0263:
        "我迅速脱下外套，披在他肩上。他张了张嘴，大概是想推辞。"
    translate None chapter_four_0264:
        rs smi "我很暖和的，真的。需要的话我会找你要回来。"
    translate None chapter_four_0265:
        f shy "...."
    translate None chapter_four_0266:
        "我仰头望向苍穹。"

    scene bg nightsky with fade:
        xpos 0.5 ypos 1.17 xanchor 0.5 yanchor 1.0 zoom 1.4
        linear 10.0 xpos 0.5 ypos 1.5 xanchor 0.5 yanchor 1.0
    translate None chapter_four_0267:
        "头顶的夜空中，成千上万颗星辰熠熠生辉。"
    translate None chapter_four_0268:
        rs smi "….要知道，熬过黑暗是值得的，因为这样你才能看见繁星。"
    scene bg pondnight2
    show fawn m shy dark
    with Fade(0.5, 0.5, 1)
    translate None chapter_four_0269:
        "我转头看向福恩。"
    translate None chapter_four_0270:
        "发现他早已在注视着我。"
    translate None chapter_four_0271:
        "他圆睁的大眼睛里仿佛盛满了星光，令我无法移开视线。"

    show fawn m sad dark with dis
    translate None chapter_four_0272:
        b "所以-"
    translate None chapter_four_0273:
        rs smi "啊哈哈…你先说。"
    translate None chapter_four_0274:
        f "噢，嗯…"
    show fawn m neu dark with dis
    translate None chapter_four_0275:
        f "那个…莱奥斯去哪了..？"
    translate None chapter_four_0276:
        rs neu "不清楚，我没注意。他应该没事的。"
    show fawn m sad dark with dis
    translate None chapter_four_0277:
        f "你今晚本可以陪着他的…他受伤了，而且-"
    translate None chapter_four_0278:
        rs neu "为什么？我更想跟着你。"
    show fawn m shy dark with dis
    translate None chapter_four_0279:
        "他别过脸去，脸颊泛起薄红。"
    translate None chapter_four_0280:
        "纤长的睫毛在他精致苍白的皮肤上投下阴影。"
    translate None chapter_four_0281:
        "虽然注意到这个有点奇怪，但不知为何格外引人注目。"
    show fawn m shy dark with dis
    translate None chapter_four_0282:
        f "….谢谢。"
    translate None chapter_four_0283:
        rs sad "呃…"
    show fawn m neu dark with dis
    translate None chapter_four_0284:
        rs "我不知道该怎么说，也明白说什么都无济于事，但是…"
    translate None chapter_four_0285:
        rs "关于你的房子…你收集的所有东西…真的很抱歉…"
    translate None chapter_four_0286:
        rs "还有你的朋友们…."
    show fawn m dark sad with dis
    translate None chapter_four_0287:
        f "我….."
    translate None chapter_four_0288:
        f "….别在意。我只是…很高兴你平安无事。庆幸你能活着逃出来。"
    translate None chapter_four_0289:
        f "希望他们都逃走了。现在能做的只有祈祷。"

    scene bg nightsky with fade:
        xpos 0.5 ypos 1.5 xanchor 0.5 yanchor 1.0 zoom 1.5
    translate None chapter_four_0290:
        "我凝望了会儿夜空。"
    translate None chapter_four_0291:
        rs neu "其实…"
    translate None chapter_four_0292:
        rs neu "说书人教导我们，众神始终在庇佑着我们。"
    translate None chapter_four_0293:
        rs smi "从月亮，从太阳，从天空的每颗星辰之上。"
    translate None chapter_four_0294:
        rs "此刻他们一定正守护着我们。我相信一切都会好起来的。"
    translate None chapter_four_0295:
        "肩头传来柔软的触感。"
    window hide

    scene gallery_21 with Fade(0.5,0.5,1):
        ypos 0.50 xanchor 0.08 yanchor 0.39 zoom 1.3
    window show dissolve
    translate None chapter_four_0296:
        rs "啊…"
    translate None chapter_four_0297:
        "低头只见他凌乱的蓝色发丝。"
    translate None chapter_four_0298:
        "他肯定累坏了。"
    translate None chapter_four_0299:
        rs "福恩…说真的，该道谢的人是我。"
    translate None chapter_four_0300:
        rs "经历了这么多事，你却始终对我不离不弃。给予我的全是温柔相待。"
    translate None chapter_four_0301:
        rs "我从没遇见过像你这样的人…"
    translate None chapter_four_0302:
        f "....."
    translate None chapter_four_0303:
        rs "还醒着吗..？"
    translate None chapter_four_0304:
        f "...."
    translate None chapter_four_0305:
        "他微微动了动。可能又让我弄得不好意思了。"

    show gallery_20 with dis:
        ypos 0.50 xanchor 0.08 yanchor 0.39 zoom 1.3
    translate None chapter_four_0306:
        rs "….你听过太阳和月亮的故事吗？"
    translate None chapter_four_0307:
        f "…太阳和月亮？"
    translate None chapter_four_0308:
        rs "太阳神与月亮神的故事。"
    translate None chapter_four_0309:
        rs "我母-我是说，孤儿院的女院长从小给我讲的。"
    translate None chapter_four_0310:
        rs "很久以前，太阳与月亮和谐共处。它们不仅掌管昼夜，更共同统治着天空。"
    translate None chapter_four_0311:
        rs "……曾经确实如此。"
    translate None chapter_four_0312:
        rs "但它们贪求更多，终致祸端。两者被永远分离，再不得相见。"
    translate None chapter_four_0313:
        rs "女院长说此后每逢黎明黄昏，它们都会试图触碰对方，却永远差那么一点距离。"

    scene gallery_20:
        ypos 0.50 xanchor 0.08 yanchor 0.39 zoom 1.3
        easein 2.0 yanchor 0.6
        "gallery_21" with Dissolve(0.5, alpha=True)
    pause(2.0)

    translate None chapter_four_0314:
        f "……为什么要告诉我这些？"
    translate None chapter_four_0315:
        rs "你很聪明，福恩。我想知道你的想法。"
    translate None chapter_four_0316:
        rs "至今我仍不明白她话中的深意。或许永远不会明白了。"
    translate None chapter_four_0317:
        rs "……希望它们还好。"
    translate None chapter_four_0318:
        f "...."
    translate None chapter_four_0319:
        f "……你觉得它们该保持分离吗？"
    translate None chapter_four_0320:
        rs "老实说，我不确定。"
    translate None chapter_four_0321:
        f "人生最大的遗憾莫过于想做未做之事。"
    translate None chapter_four_0322:
        f "若它们冒险尝试却失败，至少尽力了。为所爱之人，万事皆可为。"
    translate None chapter_four_0323:
        f "说不定它们还能弥补。"
    translate None chapter_four_0324:
        rs "……爱？"
    translate None chapter_four_0325:
        f "我猜是这样。"

    scene gallery_22 with dis:
        ypos 0.50 xanchor 0.08 yanchor 0.6 zoom 1.3
    translate None chapter_four_0326:
        "我闭眼靠在他头上。"
    translate None chapter_four_0327:
        "温暖又舒适，如此自然。"
    translate None chapter_four_0328:
        rs "说来奇怪，"
    translate None chapter_four_0329:
        rs "明明坏事连连，我却感到无比幸福。不知为何，每次你都能让我振作。"
    translate None chapter_four_0330:
        "难以言喻，但福恩确实特别。"
    translate None chapter_four_0331:
        "意识涣散时，关于福恩的思绪在脑海流转。"

    if achievement.has("fawn_lake"):
        pass
    else:
        $ renpy.display_notify("成就达成：星河之下")

    python:
        achievement.grant("fawn_lake")
        achievement.sync()

    stop music fadeout 2.0
    window hide
    scene gallery_22 with Dissolve(1.0)
    pause(0.5)

    jump narrationpond

label fawnpondcont:
    scene bg pond day with eye_open
    window show dissolve
    with dis
    translate None chapter_four_0335:
        rs sur "....."
    translate None chapter_four_0336:
        "我满身冷汗醒来，发现正紧攥着福恩的手。"
    translate None chapter_four_0337:
        "感觉他从我肩头挪开。"
    translate None chapter_four_0338:
        f neu "……你还好吗？"
    translate None chapter_four_0339:
        f neu "又是……那些梦？"
    translate None chapter_four_0340:
        rs sad "我……嗯，没事。"
    translate None chapter_four_0341:
        f neu "呃…"
    translate None chapter_four_0342:
        "他低头看着我们交握的手。"
    translate None chapter_four_0343:
        rs sur "啊，抱歉。"
    translate None chapter_four_0344:
        "我迅速抽回手。"
    translate None chapter_four_0345:
        rs neu "我们该去找—"
    show leos n smi with dis
    translate None chapter_four_0346:
        l "啧啧，两位可真亲密啊。"
    translate None chapter_four_0347:
        f hur "啊！"
    translate None chapter_four_0348:
        f shy "不是你想的那样！"
    translate None chapter_four_0349:
        rs sur "……那该是什么样？"
    translate None chapter_four_0350:
        rs neu "总之可算找到你们了。我正要来寻人呢。"
    translate None chapter_four_0351:
        rs neu "你站那儿多久了？"
    translate None chapter_four_0352:
        l "够久了。"
    translate None chapter_four_0353:
        rs sad "好吧……"

    show leos n neu at right with move
    show raen n neu
    with dissolve

    translate None chapter_four_0354:
        "我慌忙起身拍掉衣服尘土，向涨红脸的福恩伸出手。"
    translate None chapter_four_0355:
        rs "来，我拉你起来。"
    show fawn n shy at left with dissolve
    translate None chapter_four_0356:
        f "谢谢……"

    jump choice_5_done

label choice_5_done:
    show leos n neu
    show fawn n neu
    show raen n neu
    with dis
    play music "sounds/bgm/Discovery.ogg" fadein 1.0
    translate None chapter_four_0357:
        "我仔细打量着莱奥斯。他的脸色有些苍白，眼下挂着黑眼圈。"
    translate None chapter_four_0358:
        rs "你今天感觉怎么样？"
    show leos n smi with dis
    translate None chapter_four_0359:
        l "你觉得我感觉如何？"
    show raen con with dis
    translate None chapter_four_0360:
        rs "呃…不太好…？"
    translate None chapter_four_0361:
        l "那你还费心问什么？"
    show raen neu with dis
    translate None chapter_four_0362:
        rs "....."
    translate None chapter_four_0363:
        l "....."
    show leos n pen with dis
    translate None chapter_four_0364:
        l "还行。我感觉还行。有点累，还有点疼，但这不是我受过最严重的伤。"
    translate None chapter_four_0365:
        "他看起来可一点都不像\"还行\"的样子。"
    translate None chapter_four_0366:
        "他太要强了。即便需要帮助也不会承认。"
    show raen neu with dis
    translate None chapter_four_0367:
        f "嗯…我们出发前最好检查下你们俩的伤口。"
    translate None chapter_four_0368:
        f "还有水。可能要好一阵子才能找到干净水源。"
    show leos n smi with dis
    translate None chapter_four_0369:
        l "总算知道小不点说的话也不全是废话了。"
    show fawn n sad with dis
    translate None chapter_four_0370:
        f "......"
    translate None chapter_four_0371:
        "这两人就像猫捉老鼠。福恩从不为自己辩解，莱奥斯倒乐得追着他怼。"
    translate None chapter_four_0372:
        rs "话说…我们还要走多远？"
    translate None chapter_four_0373:
        f "从我家出发步行约两天路程，现在启程的话傍晚前就能到。"
    translate None chapter_four_0374:
        "不到十分钟我们就为今天的跋涉做好了准备。"
    translate None chapter_four_0375:
        "我搓了搓双手，将衣领裹紧。清晨的风凛冽刺骨。"
    translate None chapter_four_0376:
        "我知道远离奥雷利亚卡维拉是好事，但想到远离家园和在意的人，心头仍是刺痛。"
    translate None chapter_four_0377:
        "我总觉得我们在兜圈子，看不到尽头，毫无意义。仿佛要永远这样逃亡下去。"
    translate None chapter_four_0378:
        "就算到达福恩带领我们去的地方…然后呢？"
    translate None chapter_four_0379:
        "继续在森林里生活？我们三个要其乐融融住树屋度过余生？这怎么可能。"
    translate None chapter_four_0380:
        "就算活下来，我又能做什么？"


    scene bg forest with fade:
        xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.49
        linear 20.0 xpos 0.5 ypos 1.49 xanchor 0.5 yanchor 1.0 zoom 1.49
    window show dissolve

    translate None chapter_four_0381:
        "和昨天一样，我们走到几乎迈不动腿。"
    translate None chapter_four_0382:
        "确切说…是走到我几乎迈不动腿。福恩似乎习以为常，莱奥斯虽负伤却行动自如，甚至比先前更有精神。"
    translate None chapter_four_0383:
        "日头已高悬天际。即便抬手遮挡，阳光仍从指缝溢出，晃得睁不开眼。"
    translate None chapter_four_0384:
        "肺部灼烧般疼痛，双腿灌了铅般沉重。"
    translate None chapter_four_0385:
        "我真的这么弱不禁风吗…？家里有个花园需要我打理，但远没有这么耗费体力。"

    scene bg forest
    show raen n hur at center
    show expression AlphaMask("foliage_1", At("raen n hur（原文保留）", center)) as mask1
    show leos n neu at right
    show expression AlphaMask("foliage_1", At("leos n neu", right)) as mask2
    show fawn n neu at left
    show expression AlphaMask("foliage_1", At("fawn n neu", left)) as mask3
    with dissolve

    translate None chapter_four_0386:
        rs "呃，伙计们…我真的觉得…需要稍微休息下…"
    translate None chapter_four_0387:
        "我喘得上气不接下气，几乎说不出完整的话。"
    show fawn n sur with dis
    translate None chapter_four_0388:
        f "啊！"
    translate None chapter_four_0389:
        "福恩急忙冲回我身边。"
    show fawn n hur with dis
    translate None chapter_four_0390:
        f "太对不起了！你该早点说要休息的。"
    show fawn n neu with dis
    translate None chapter_four_0391:
        f "不如我们在这里停一会儿。"
    translate None chapter_four_0392:
        f "反正我觉得前面也没多少路了。"
    translate None chapter_four_0393:
        l "既然没剩多少路干嘛要停下？"
    translate None chapter_four_0394:
        f "嗯…他明显撑不住了，所以…"
    translate None chapter_four_0395:
        l "那他只要跟上就行。"
    translate None chapter_four_0396:
        f "我不认为—"
    translate None chapter_four_0397:
        u "…..哈哈哈哈！"

    show fawn n sur
    show leos n sur
    show raen n sur
    with dis
    stop music fadeout 1.0

    translate None chapter_four_0398:
        "我们全都不约而同停下脚步。"
    translate None chapter_four_0399:
        "那是什么声音？"


    scene bg forest with dissolve:
        xpos 0.66 ypos 1.44 xanchor 0.5 yanchor 1.0 zoom 1.5

    translate None chapter_four_0400:
        "福恩示意我们都蹲下。"

    play sound "sounds/sfx/walkinggroup.ogg"

    translate None chapter_four_0402:
        "伴随着欢笑声，沙沙的脚步声越来越响，越来越近。"
    translate None chapter_four_0403:
        "那是…一群人吗？"
    translate None chapter_four_0404:
        "在这种地方边走边聊？"
    translate None chapter_four_0405:
        "我刚要开口询问，福恩就把手指竖在唇前。"
    translate None chapter_four_0406:
        "我们不清楚他们是谁，最好别让他们发现我们在这儿。"
    translate None chapter_four_0407:
        "当我看向莱奥斯时，只见他眯着眼睛四处扫视。他看起来和我一样困惑。"
    translate None chapter_four_0408:
        "人…在这种偏远地方？不可能吧。"
    translate None chapter_four_0409:
        "连我们出现在这儿都够离奇了…还有别人？"
    translate None chapter_four_0410:
        u "…你们看见他钱袋的尺寸没？哈！好像他会惦记这个似的。"
    translate None chapter_four_0411:
        u "人都他妈在深渊里蹬腿了还能惦记啥！"
    translate None chapter_four_0412:
        "透过灌木丛，我们听见震耳欲聋的笑声正一秒秒逼近。"
    translate None chapter_four_0413:
        "我实在忍不住了。"
    translate None chapter_four_0414:
        rs sur "他们是谁？"
    translate None chapter_four_0415:
        f hur "嘘！"
    translate None chapter_four_0416:
        "那群人突然停下聆听，其中一个问有没有听见动静。"
    translate None chapter_four_0417:
        u "有，从那边传来的。有东西在窸窸窣窣。"
    translate None chapter_four_0418:
        "啊，糟了。"
    translate None chapter_four_0419:
        "沙，沙。不论来者何人，正慢慢靠近。"
    translate None chapter_four_0420:
        "我浑身发麻，自己的心跳声震得耳朵隐隐作痛。"
    translate None chapter_four_0421:
        "我该怎么办？！"
    translate None chapter_four_0422:
        "我要怎么—"
    translate None chapter_four_0423:
        l ann "见鬼。你们俩他妈是不是蠢到家了？！"
    translate None chapter_four_0424:
        rs sur "什-"

    scene bg forest with dissolve
    show leos n ann with dis
    show expression AlphaMask("foliage_1", At("leos n ann", center)) as mask1

    play music "sounds/bgm/battle.ogg" fadein 2.0
    translate None chapter_four_0425:
        "没等我再开口，他已经弹起身子，双手各执一柄匕首。"
    translate None chapter_four_0426:
        u "哟哟哟，看来又来个想给钱袋减负的。我们很乐意帮你这个忙。"
    translate None chapter_four_0427:
        u "今天我们走运了，老板。这儿平时可没半个人影。"
    show leos n smi with dis
    translate None chapter_four_0428:
        l "哈。尽管试试。"
    translate None chapter_four_0429:
        "他朝他们的方向啐了一口。"
    translate None chapter_four_0430:
        l "就凭你那把破刀还想碰我？我打赌你连该握哪头都不知道。"
    translate None chapter_four_0431:
        "等等…他还有伤在身。我得帮他！"
    translate None chapter_four_0432:
        "我的双手直发抖。我想跳起来跟他并肩作战，却几乎喘不上气。"
    translate None chapter_four_0433:
        "我缓缓做了几个深呼吸。终于，耳中擂鼓般的心跳声稍缓了些。"
    translate None chapter_four_0434:
        u "你他妈叫我什么？！？"
    translate None chapter_four_0435:
        l "啊哈，既耳背又笨手笨脚。真是绝妙的组合。"
    translate None chapter_four_0436:
        "我刚从灌木丛探出头，正好看见莱奥斯面对的那群男人。他们局促地挪着步子，不时偷瞄中间那人。"
    translate None chapter_four_0437:
        "那肯定是他们的头儿。手下人大概从没见他被这么羞辱过。"
    translate None chapter_four_0438:
        u "嗯？！被包围的人口气倒不小。弟兄们会让你吃不了兜着走！"
    translate None chapter_four_0439:
        "他的脸涨得越来越红，牙关咬得咯咯响。"


    show leos n smi at centtosr
    show expression AlphaMask("foliage_1", At("莱奥斯 恼怒", centtosr)) as mask1
    pause(0.1)
    show raen n ang at slightleft
    show expression AlphaMask("foliage_1", At("雷恩 愤怒", slightleft)) as mask3
    with dis
    translate None chapter_four_0441:
        "我纵身跃起冲到莱奥斯身旁。"
    translate None chapter_four_0442:
        f hur "你干什么？！"

    play sound "sounds/sfx/knifeunsheath.ogg"
    show leos n sur with dis
    translate None chapter_four_0444:
        "没等他开口抱怨，我已抽走他腰间别着的一把刀，颤巍巍举在身前。"
    translate None chapter_four_0445:
        rs "他…他不是一个人！我会保护他！"
    show leos n ang with dis
    translate None chapter_four_0446:
        "四周死寂，只有莱奥斯轻不可闻的叹息声。"
    translate None chapter_four_0447:
        "但不到片刻—"
    translate None chapter_four_0448:
        u "噗哈哈哈哈！"
    translate None chapter_four_0449:
        "那个自称老大的家伙突然爆笑，整个团伙也跟着哄笑起来。"
    translate None chapter_four_0450:
        u "哟嗬！来了个穿闪亮盔甲的骑士！没想到你还带着相好的！"
    translate None chapter_four_0451:
        u "那就别怪我们劫个色啦！"

    play sound "sounds/sfx/clenchinghand.ogg"
    translate None chapter_four_0453:
        "我死死攥住锋利的刀刃。"
    translate None chapter_four_0454:
        "冰凉金属几乎要划破皮肤。我这辈子连摸都没摸过刀，更别提使唤了。"
    show leos n hur with dis
    translate None chapter_four_0455:
        l "你搞什么？！快滚！"
    translate None chapter_four_0456:
        rs "不！我要帮你！"
    translate None chapter_four_0457:
        l "别—"

    play sound "sounds/sfx/swing2.ogg"


    scene bg forest with dis:
        xpos 0.66 ypos 1.44 xanchor 0.5 yanchor 1.0 zoom 1.5

    translate None chapter_four_0459:
        "一道寒光擦着我眼前掠过。我后仰得稍慢半拍就会见血。"
    translate None chapter_four_0460:
        rs hur "啊！"

    scene bg forest:
        xpos 0.66 ypos 1.44 xanchor 0.5 yanchor 1.0 zoom 1.5
        linear 0.3 ypos 1.2
    pause(0.3)
    scene bg forest with vpunch:
        xpos 0.66 ypos 1.2 xanchor 0.5 yanchor 1.0 zoom 1.5

    play sound "sounds/sfx/fallonground.ogg"

    translate None chapter_four_0462:
        "重重摔在地上时，肺里的空气全被撞了出来。"
    translate None chapter_four_0463:
        "下一秒同样的刀从头顶劈下。我根本来不及躲闪。"
    scene black with dis
    translate None chapter_four_0464:
        "我闭紧眼睛护住脸…但预期中的疼痛并未降临。"
    translate None chapter_four_0465:
        f hur "等等！"

    play sound "sounds/sfx/fallonground2.ogg"

    scene bg forest with dis:
        xpos 0.66 ypos 1.2 xanchor 0.5 yanchor 1.0 zoom 1.5

    translate None chapter_four_0467:
        "当我睁开眼时，看见袭击者被福恩压在身下，在肮脏的森林地面上滑行。"
    translate None chapter_four_0468:
        "福恩刚才是不是直接扑倒了他？"
    translate None chapter_four_0469:
        u "干得好，小子们。"
    translate None chapter_four_0470:
        "根本没有思考的时间。"
    scene bg forest with dis
    translate None chapter_four_0471:
        "我跳起来拉起身在地上的福恩，退后几步站到莱奥斯身边。"
    translate None chapter_four_0472:
        l neu "嘿，老鼠崽子！"

    play sound "sounds/sfx/knifeunsheath.ogg"

    translate None chapter_four_0474:
        "福恩凌空接住了抛向他的匕首。"
    play sound "sounds/sfx/clenchinghand.ogg"

    translate None chapter_four_0476:
        "他们像疯子般挥舞武器尖叫着冲来。我把匕首攥得更紧了。"
    translate None chapter_four_0477:
        "握着是一回事。我真的能用这个伤害别人吗？"
    translate None chapter_four_0478:
        "前两人径直扑向莱奥斯，毕竟是他羞辱了他们的老大。"
    translate None chapter_four_0479:
        "剩下两人在后方观望叫嚣。"
    translate None chapter_four_0480:
        "他们持剑围住莱奥斯，脸上挂着狞笑。"
    translate None chapter_four_0481:
        u "你要怎么办啊，小白脸？"
    translate None chapter_four_0482:
        l neu "哼。"
    scene black with dis
    translate None chapter_four_0483:
        "一切都发生在电光火石间。"

    show gallery_23 with Dissolve(0.1):
        xpos 0.5 ypos 1.0 xanchor 0.47 yanchor 1.0
    queue sound [ "sounds/sfx/kick1.ogg", "<silence .5>", "sounds/sfx/fallonground3.ogg" ]
    pause(0.1)
    scene black with Dissolve(0.1)
    pause(0.2)
    scene bg forest with dis
    pause(0.1)
    show layer master at vpunch

    translate None chapter_four_0484:
        "第一人刚冲上来，莱奥斯就猛踹其腹部，让他倒飞进灌木丛。"

    play sound "sounds/sfx/swing1.ogg"

    show gallery_23 with Dissolve(0.1):
        xpos 0.5 ypos 1.0 xanchor 0.25 yanchor 0.85
    pause(0.2)
    hide gallery_23 with Dissolve(0.1)
    translate None chapter_four_0486:
        "头都不回地将手中匕首朝那人摔落的方向掷去。"

    play sound "sounds/sfx/stab1.ogg"

    translate None chapter_four_0488:
        "灌木丛传来的声响说明命中目标。"

    queue sound ["sounds/sfx/whoosh2.ogg", "<silence .5>", "sounds/sfx/swing2.ogg"]
    show gallery_23 with dis:
        xpos 0.5 ypos 1.0 xanchor 0.49 yanchor 1.0 zoom 0.67
        linear 10  yanchor 0.80

    translate None chapter_four_0489:
        "当第二人袭来时，他在林间优雅腾挪。每次闪避都游刃有余，简直像在戏耍对方。躬身侧首间就将所有劈斩轻松化解。"
    translate None chapter_four_0490:
        u "别他妈跟跳蚤似的乱窜！"
    translate None chapter_four_0491:
        queue sound [ "sounds/sfx/swing1.ogg", "sounds/sfx/swing2.ogg", "sounds/sfx/swing1.ogg" ]
        "第二名袭击者的劈砍逐渐变得狂乱无章，毫无节奏可言。即便对剑术一窍不通的我，也看出他糟糕透顶。"
    translate None chapter_four_0492:
        "莱奥斯嘴角含笑，一次次闪避就像在玩弄猎物。每次劈空都让那人脸色更红一分。"
    translate None chapter_four_0493:
        "我只能呆立观战。虽想帮忙，双腿却如灌铅般寸步难移。"
    scene black with dis
    translate None chapter_four_0494:
        u "啊—！"

    play sound "sounds/sfx/fallonground2.ogg"
    show layer master at vpunch
    translate None chapter_four_0496:
        "袭击者突然跪地抱手哀嚎。"

    scene bg forest
    show bloody
    with dis

    translate None chapter_four_0497:
        "周围草叶溅满血点，痛苦的呻吟不断逸出。"
    translate None chapter_four_0498:
        "莱奥斯低头睥睨，脸上挂着讥笑。"

    show leos n smu behind bloody
    show expression AlphaMask("foliage_1", At("莱奥斯与鼠辈", center)) as mask1
    with dis
    translate None chapter_four_0499:
        l "起来啊废物。刚才不是要\"嚼碎老子\"吗？我等着呢。"
    translate None chapter_four_0500:
        u "操你妈的混—"

    play sound "sounds/sfx/punch2.ogg"

    show bloody with flash2
    show layer master at vpunch

    translate None chapter_four_0502:
        "莱奥斯没等他说完就一个扫腿，狠狠踹在他脸上。"

    play sound "sounds/sfx/fallonground.ogg"
    translate None chapter_four_0504:
        "那人仰面倒地，再也没有挣扎起身或还嘴的意思。"
    show leos n smi with dis
    translate None chapter_four_0505:
        l "啊，你这样倒是顺眼多了。闭着嘴巴的样子可爱多了。"
    translate None chapter_four_0506:
        l "可怜的小宝贝，直接晕过去了。让我们看看你的朋友们能有多大能耐。"

    scene black
    show bloody
    with dis

    translate None chapter_four_0507:
        "他…他太可怕了。"
    translate None chapter_four_0508:
        "莱奥斯像是完全变了个人。刚才还只是傲慢的混蛋模样，但现在…"
    translate None chapter_four_0509:
        "浴血狂笑的他身上透着异样的气息。那双冷眼背后藏着别的东西。"

    show gallery_23 behind bloody with dis:
        xpos 0.5 ypos 1.0 xanchor 0.47 yanchor 0.77 zoom 0.67

    translate None chapter_four_0510:
        "看他穿梭搏杀的样子，根本想不到这是个伤员。"
    translate None chapter_four_0511:
        "他眼神狂乱，只聚焦在一件事上：杀戮。死亡。"

    play sound "sounds/sfx/stab1.ogg"
    translate None chapter_four_0513:
        "他一次次旋转身躯，匕首快速扎进另一名袭击者的肩膀。"
    translate None chapter_four_0514:
        "这正是先前被福恩扑倒的那人，现在又杀了回来。"
    translate None chapter_four_0515:
        "莱奥斯被嗜血欲望支配的模样令我无法移开视线。"

    window hide
    scene bg forest
    show bloody onlayer middle
    with dis
    queue sound [ "sounds/sfx/stab3.ogg", "<silence 1.0>", "sounds/sfx/stab3.ogg", "<silence 1.0>", "sounds/sfx/stab3.ogg" ]
    window show

    translate None chapter_four_0516:
        "他将袭击者按倒在地，对着咽喉和面部连捅数刀。鲜血浸透莱奥斯的双手，但他仍未停手。"
    translate None chapter_four_0517:
        "福恩站在我身旁，同样死死盯着这恐怖场景。我拼命想转头回避，却做不到。"

    show fawn n hur at slightright
    show expression AlphaMask("foliage_1", At("福恩 与 赫尔", slightright)) as mask2
    show thug at slightleft
    with dis

    translate None chapter_four_0518:
        f "….雷恩！"
    translate None chapter_four_0519:
        rs sur "什-"

    show layer master at vpunch
    play sound "sounds/sfx/fallonground.ogg"

    translate None chapter_four_0521:
        "福恩猛地将我推回几分钟前才跳出来的灌木丛。"
    translate None chapter_four_0522:
        "我踉跄着扶住树干站稳，正好看见最后那个男人挥刀砍向福恩。"
    translate None chapter_four_0523:
        "正是刚才话最多的那个。这群人的头目。"
    translate None chapter_four_0524:
        queue sound ["sounds/sfx/swing2.ogg", "<silence .2>", "sounds/sfx/whoosh2.ogg", "<silence .2>", "sounds/sfx/kick1.ogg"]
        "福恩勉强格挡闪避，但动作比莱奥斯迟钝太多。两人的差距一目了然。"
    translate None chapter_four_0525:
        "他连闪躲都捉襟见肘，更别提反击了。"

    play sound "sounds/sfx/knifeunsheath.ogg"
    translate None chapter_four_0527:
        "我摩挲着手中紧握的匕首。"

    hide fawn
    hide thug
    show black
    with dis

    translate None chapter_four_0528:
        "我真的…能用这个吗？"
    translate None chapter_four_0529:
        "我真的能杀人…？为自保杀个素不相识的人…这样也可以吗？"
    translate None chapter_four_0530:
        "我还有…选择的余地吗？"
    translate None chapter_four_0531:
        "不。我决不能让他伤害福恩。"
    translate None chapter_four_0532:
        "每迈出一步，我的勇气就消退一分。"
    translate None chapter_four_0533:
        "我不懂战斗技巧。不会格挡防御。更不懂…如何那样伤害别人。"
    translate None chapter_four_0534:
        "我根本帮不上任何忙，是吧？"

    scene bg forest
    show thug at center
    show bloody onlayer middle
    with vpunch
    play sound "sounds/sfx/fallonground3.ogg"

    translate None chapter_four_0536:
        "我还来不及做出任何反应，福恩就被重重摔在地上，疼得叫出声来。"
    translate None chapter_four_0537:
        "那人得意地站在福恩身旁。如果我现在不做点什么…！"
    translate None chapter_four_0538:
        rs wor "住手！等等，别伤害他！"
    translate None chapter_four_0539:
        u "啊哈！我差点把你给忘了！"

    show thug at slightleft with move
    show raen n hur at slightright with dis
    show expression AlphaMask("foliage_1", At("raen n hur（原文保留）", slightright)) as mask3

    translate None chapter_four_0541:
        "他将注意力转向我，我本能地后退了一步。"

    translate None chapter_four_0542:
        "我低头看向福恩。他似乎有点晕头转向，但基本没受伤。至少现在他是安全的。"

    #    play sound "<from 0 to 0.3>sounds/sfx/walkingearth.ogg"
    translate None chapter_four_0544:
        "那人又朝我逼近一步，脸上闪过愤怒，随即又变成笑容。"
    translate None chapter_four_0545:
        "…他以为我是好欺负的目标。他…没想错。"
    translate None chapter_four_0548:
        rs wor "离…离我们远点！"
    translate None chapter_four_0549:
        "他提高嗓门，说我们寡不敌众—他的同伙很快就会解决掉另外两个人。"
    translate None chapter_four_0550:
        f bla "….同伙？真奇怪我怎么一个都没看到。"
    translate None chapter_four_0551:
        f "..雷恩，离他远点。"
    translate None chapter_four_0552:
        "福恩用膝盖支撑着爬起来。"
    translate None chapter_four_0553:
        "他的表情突然变得严肃。"
    translate None chapter_four_0556:
        "现在他离我只有一臂之遥。"
    translate None chapter_four_0557:
        "无处可逃了。莱奥斯在一侧忙着，福恩在另一侧，而我身后…只有树林。"
    translate None chapter_four_0558:
        "无论我逃到哪里他都能抓住我。"

    queue sound [ "<from 0.4 to 0.9>sounds/sfx/walkingearth.ogg", "<silence 0.5>", "sounds/sfx/fallonground.ogg" ]

    hide raen
    hide mask3
    hide thug
    show bg forest:
        xpos 0.5 ypos 1.0 xanchor 0.50 yanchor 0.79 zoom 1.94
        linear 1 xanchor 0.56
    with dis

    translate None chapter_four_0559:
        "我最后退了一步，后背抵上了树干。"
    translate None chapter_four_0560:
        "至少我成功把他引离了福恩。"
    translate None chapter_four_0561:
        "只要能给他争取足够的时间离开这里…"

    window hide dissolve
    scene black with eye_shut
    window show dissolve

    translate None chapter_four_0562:
        "我紧闭双眼，将匕首紧握在胸前，祈祷奇迹发生。"
    translate None chapter_four_0563:
        f "莱奥斯！"
    translate None chapter_four_0564:
        "福恩的尖叫声在整片森林回荡，一切都静止了。"

    play sound "sounds/sfx/whip.ogg" fadeout 1
    scene black with flash2
    scene black with vpunch
    translate None chapter_four_0565:
        u "哇啊-！"
    translate None chapter_four_0566:
        "我等待着那老板黏腻的手指碰触，但什么都没发生。"


    scene bg forest
    show bloody onlayer middle
    with eye_open

    translate None chapter_four_0567:
        "当我睁开眼睛时，面前空无一人。"
    translate None chapter_four_0568:
        "相反，他在几英尺外的草地上趴着。"
    translate None chapter_four_0569:
        "莱奥斯站在他身后，眉头紧锁地怒视着。他看起来愤怒至极。"

    show leos n ann at center
    show expression AlphaMask("foliage_1", At("leos n ann", center)) as mask1
    with dis

    translate None chapter_four_0570:
        l "要是你敢用你他妈恶心的手指碰他们任何一个人，我就把你手指全剁下来。"
    translate None chapter_four_0571:
        l "一根不剩地全部掰断。"
    translate None chapter_four_0572:
        "他一只手里还握着匕首，但另一只手握着某种长长的皮绳。另一端缠在袭击者的脚踝上。"
    translate None chapter_four_0573:
        "他刚才是用这个把那人拽倒的吗？"
    translate None chapter_four_0574:
        "感谢神明我们毕竟没有收缴莱奥斯所有的武器。"


    show leos n ann at centtosr
    show expression AlphaMask("foliage_1", At("leos n ann", centtosr)) as mask1
    pause(0.1)
    show fawn n bla at slightleft
    show expression AlphaMask("foliage_1", At("福恩和bla", slightleft)) as mask2
    with dis

    translate None chapter_four_0576:
        "福恩缓缓走近躺在地上的男人。他跪在那人身旁，将人翻转过来使其面朝上。"
    translate None chapter_four_0577:
        f "你怎敢这样对雷恩说话。"
    translate None chapter_four_0578:
        "他背对着我，我看不清他的表情，但他的声音冰冷刺骨。他朝着那人更倾近了些。"
    translate None chapter_four_0579:
        u "我他妈好害怕啊，娘娘腔要杀了我—"
    translate None chapter_four_0580:
        f "杀了你都算仁慈。"

    play sound "sounds/sfx/punch2.ogg"

    show bg forest
    with hpunch
    show leos n sur with dis

    translate None chapter_four_0582:
        "随着\"砰\"的一声，福恩重重砸在那人脸上。那人捂着脸哀嚎打滚，鼻血从指缝间涌出。"
    translate None chapter_four_0583:
        "鲜血顺着他的手指滴落，在身下草地汇成一滩。"
    translate None chapter_four_0584:
        l "……福恩？"
    translate None chapter_four_0585:
        "这真是……出乎意料。连莱奥斯都面露诧异。"
    show fawn n sur with dis
    translate None chapter_four_0586:
        "他转过身，脸上挂着人畜无害的表情。"
    translate None chapter_four_0587:
        f "怎、怎么了？"
    translate None chapter_four_0588:
        l "....."
    translate None chapter_four_0589:
        rs sur "....."

    hide leos
    hide mask1
    hide mask2
    hide fawn
    with dis
    show bg forest with dis:
        xpos 0.5 ypos 1.0 xanchor 0.50 yanchor 0.79 zoom 1.94

    translate None chapter_four_0590:
        u "狗日的杂种！等老子抓住你—"

    show bg forest:
        xpos 0.5 ypos 1.0 xanchor 0.50 yanchor 0.79 zoom 1.94
    with vpunch
    play sound "sounds/sfx/stab2.ogg"
    translate None chapter_four_0592:
        u "啊—！"
    translate None chapter_four_0593:
        "莱奥斯将最后一把匕首掷入那人小腿。"
    translate None chapter_four_0594:
        "他的裤管很快被深红色浸透。"
    translate None chapter_four_0595:
        l ann "我在和你说话吗，垃圾？我怎么不记得对你有过任何交流。"
    translate None chapter_four_0596:
        f sad "我……"
    translate None chapter_four_0597:
        "福恩低头看着自己染血的拳头，一脸茫然。"
    translate None chapter_four_0598:
        f "我不是故意—"
    translate None chapter_four_0599:
        "那人在地上翻滚挣扎，徒劳地想抓住什么。莱奥斯一脚将他踹回地面。"
    translate None chapter_four_0600:
        l smu "这下情况不太妙啊，嗯？"
    translate None chapter_four_0601:
        l "你那群狐朋狗友去哪了？啊对了。都被我宰了。"
    translate None chapter_four_0602:
        "莱奥斯单膝压住那人，从腿中拔出匕首。暗色金属刃面上血丝蜿蜒。"

    show bg forest:
        xpos 0.5 ypos 1.0 xanchor 0.50 yanchor 0.79 zoom 1.94
        linear 1 yanchor 0.74

    translate None chapter_four_0603:
        "他揪着那人油乎乎的头发拎起来，对其挣扎的模样报以冷笑。"
    translate None chapter_four_0604:
        u "靠…靠……"
    translate None chapter_four_0605:
        l "晚安。"
    #window hide dissolve

    #show blackbars onlayer middle with Dissolve(1)
    #play sound "sounds/sfx/clenchinghand.ogg"

    window show dissolve
    translate None chapter_four_0607:
        "皮质绞绳在那人脖颈间缠紧。"
    translate None chapter_four_0608:
        "喂等等，他该不会要……"
    translate None chapter_four_0609:
        "那张脸由通红转为青紫，徒劳抓挠着颈间绳索。"
    translate None chapter_four_0610:
        stop music fadeout 2.0
        rs wor "住、住手莱奥斯！"
    translate None chapter_four_0611:
        l neu "什么？"
    translate None chapter_four_0612:
        f "....."
    translate None chapter_four_0613:
        f "……让他死太便宜了。"
    translate None chapter_four_0614:
        rs "没必要杀他！我们离开这儿行吗？"
    translate None chapter_four_0615:
        l "....."
    translate None chapter_four_0616:
        "莱奥斯脸上闪过一丝动摇。是犹豫吗？我不确定。"
    translate None chapter_four_0617:
        "这是整场冲突中，我第一次在他脸上看到除战斗欲以外的情绪。"
    translate None chapter_four_0618:
        "我知道他们是恶徒。真的，我清楚。"
    translate None chapter_four_0619:
        "草地上横七竖八的其他躯体一动不动。他们死了吗？受伤了？我不知道。"
    translate None chapter_four_0620:
        "即使是为了保护我，我也不愿莱奥斯继续杀戮。"
    translate None chapter_four_0621:
        "我扔掉手中武器，深深吸了口气。尽管我并未参战，手臂肌肉却隐隐作痛。"
    translate None chapter_four_0622:
        "好了…我没理由再害怕了…"
    translate None chapter_four_0623:
        "我将颤抖的手搭在莱奥斯肩上。"
    translate None chapter_four_0624:
        "他将视线转向我，脸上带着古怪神情。"
    translate None chapter_four_0625:
        rs "没事了。你可以放开他…我们现在安全了。"
    translate None chapter_four_0626:
        l pen "......"
    translate None chapter_four_0627:
        f "…走吧。"
    translate None chapter_four_0628:
        f "这种人不值得我们浪费时间。"
    translate None chapter_four_0629:
        l "......"
    translate None chapter_four_0630:
        l "行。"
    translate None chapter_four_0631:
        l "反正他也不配死在我手里。"

    hide bloody with dissolve
    show bg forest:
        xpos 0.5 ypos 1.0 xanchor 0.50 yanchor 0.74 zoom 1.94
    with vpunch
    play sound "sounds/sfx/fallonground.ogg"
    #hide blackbars with dissolve

    translate None chapter_four_0633:
        "莱奥斯立即松手放开那人头发，对方重重摔在地上。"
    translate None chapter_four_0634:
        "脖颈绳索甫一松开，他就大口喘息着拼命爬离我们。"
    translate None chapter_four_0635:
        "他脖子上紫黑的淤痕短时间内不会消退。"

    scene bg forest
    show leos n neu
    show expression AlphaMask("foliage_1", At("leos n neu", center)) as mask1
    with dissolve

    translate None chapter_four_0636:
        l "算你走运遇到这两位心软的。要是再让我看见你，当场就给你开膛破肚。"
    show leos n smi with dis
    translate None chapter_four_0637:
        l "明白？"
    translate None chapter_four_0638:
        u "是…是的，长官。"
    translate None chapter_four_0639:
        l "哼。"
    translate None chapter_four_0640:
        u "啊！"

    show bg forest with vpunch
    play sound "sounds/sfx/kick1.ogg"
    translate None chapter_four_0642:
        "朝他屁股补上一脚让这头目直接栽进泥里，今天大概是他人生最倒霉的日子。"
    translate None chapter_four_0643:
        l "哈哈哈。"

    show leos at centoright
    show expression AlphaMask("foliage_1", At("leos n neu", centoright)) as mask1
    pause(0.1)
    show raen n sad at center
    show expression AlphaMask("foliage_1", At("雷恩 悲伤", center)) as mask2
    show fawn n sad at left
    show expression AlphaMask("foliage_1", At("fawn n sad", left)) as mask3
    with dis

    translate None chapter_four_0644:
        rs "没必要这样…"
    show leos n smu with dis
    translate None chapter_four_0645:
        l "不过确实有趣。"
    translate None chapter_four_0646:
        "我轻轻拽了拽莱奥斯的袖口。"
    translate None chapter_four_0647:
        rs "我们离开这儿…"
    translate None chapter_four_0648:
        "他弯腰捡起抛掷的武器，如流云般飘然回到我身边，每个步伐都轻盈得像踏在云端。"
    translate None chapter_four_0649:
        "眼中的疯劲已然消退，却又立即换上戏谑笑容。"
    translate None chapter_four_0650:
        rs "你高兴个什么劲？"
    translate None chapter_four_0651:
        "他俯身直到与我平视。"
    translate None chapter_four_0652:
        l "当人意识到自己不堪一击时，那种惊骇眼神真是无与伦比。"
    translate None chapter_four_0653:
        l "嘴上厉害，真动起手来全是些三脚猫。"
    translate None chapter_four_0654:
        "福恩环顾战场，恢复了平常模样。"
    show fawn n neu with dis
    translate None chapter_four_0655:
        f "其…其他人都死了吗…？"
    translate None chapter_four_0656:
        l "谁知道呢。"
    translate None chapter_four_0657:
        l "这取决于你认为我的枪法有多准。"
    show fawn n sad with dis
    translate None chapter_four_0658:
        f "....."
    translate None chapter_four_0659:
        f "死亡…不是能拿来开玩笑的事…"
    translate None chapter_four_0660:
        f "你不该这么不当回事…"
    translate None chapter_four_0661:
        l "是吗？可刚才某位不是差点要杀了那个肥猪？"
    show leos n smi with dis
    translate None chapter_four_0662:
        l "不过我猜说到底，像你这样的人永远无法理解那种感觉。"

    hide mask2
    hide raen
    with dissolve
    show fawn n sad at lefttosl
    show expression AlphaMask("foliage_1", At("fawn n neu", lefttosl)) as mask3
    show leos n smi at righttosr
    show expression AlphaMask("foliage_1", At("莱奥斯 恼怒", righttosr)) as mask1

    translate None chapter_four_0663:
        "莱奥斯走到福恩身旁站定，低头凝视着他的脸。"
    show leos n neu with dis
    translate None chapter_four_0664:
        l "还是说你…？"

    show fawn n hur at shakesl
    show expression AlphaMask("foliage_1", At("福恩 与 赫尔", shakesl)) as mask3

    translate None chapter_four_0665:
        f "不，我-"
    translate None chapter_four_0666:
        rs ang "够了！"
    translate None chapter_four_0667:
        rs sad "求你了，我只想离开。我再也看不下去了。"

    show leos n neu with dis
    translate None chapter_four_0668:
        l "....."
    translate None chapter_four_0669:
        f "....."
    show fawn n sad with dis
    translate None chapter_four_0670:
        f "…..好吧。"
    translate None chapter_four_0671:
        f "走吧。我想我们现在离森林边缘应该不远了。"

    scene bg forest with dissolve:
        size (1920, 1080) crop (0, 290, 1330, 789)
        linear 35.0 crop (550, 290, 1330, 789)

    translate None chapter_four_0672:
        "经历这一切后，我感到筋疲力尽。我的嘴巴和喉咙发干，肾上腺素刚刚开始从体内消退。"
    translate None chapter_four_0673:
        "既然他说森林边缘就在附近，那就这样吧。森林边缘就在附近。我已经没有力气争辩了。"
    translate None chapter_four_0674:
        "只要能让我坐下休息一会儿，他说什么我都相信。"
    translate None chapter_four_0675:
        "我们离开了那个地方，跟着福恩沿原路返回。"
    jump chapter_five_start
