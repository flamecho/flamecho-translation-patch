label fawnroute5start:

    window hide dissolve


    scene bg sv night with Fade(1.0, 1.0, 1.0):
        xpos 0.64 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.47
        linear 20.0 xpos 0.29 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.47
    window show dissolve

    #pan plz
    translate None fawn_chapter5_0001:
        "深夜中传来一声敲击的回响，在村庄空旷的街道上回荡。"
    translate None fawn_chapter5_0002:
        "或许称它们为街道都有些言过其实，但这对莫温来说并不重要。"
    translate None fawn_chapter5_0003:
        play music "sounds/bgm/night.ogg" fadein 3.0
        mmn "这让我想起家乡。那些躺在田间仰望星空的静谧夜晚。想起母亲烹饪的香气。"
    translate None fawn_chapter5_0004:
        "但这并非莫温的故乡。她的家早已成为遥远过去的记忆，那是世上没几个人还记得的时光。"
    translate None fawn_chapter5_0005:
        "正因如此，这座村庄更令她心碎。"
    translate None fawn_chapter5_0006:
        mmn "那么…为何有她在身边会让我如此安心？"
    translate None fawn_chapter5_0007:
        "正想着这些，她刚敲过的门突然大开，门内站着个红黑发色的女子，宽大斗篷遮掩了部分身形。"
    scene bg sv night
    show morwen n dark neu cloakup at slightleft
    show sylvir n dark neu at slightright
    with dissolve
    translate None fawn_chapter5_0008:
        s "莫温。这么晚还不睡？"
    translate None fawn_chapter5_0009:
        show morwen smi with dis
        mor "抱歉深夜打扰—希望没吵醒你。我刚才…在和雷恩说话。想来道谢。"
    translate None fawn_chapter5_0010:
        s "…反正我也没睡。你知道不必言谢。"
    translate None fawn_chapter5_0011:
        show morwen sad with dis
        mor "是的。"
    translate None fawn_chapter5_0012:
        mor "你救了我的命。把我的孩子们带回到我身边。"
    translate None fawn_chapter5_0013:
        show sylvir neu blush with dis
        "西尔维尔向来面具般不露情绪的脸上闪过一丝波动。若细看，或许还能发现她脸颊泛起的淡淡红晕。"
    translate None fawn_chapter5_0014:
        s "那只是举手之劳…"
    translate None fawn_chapter5_0015:
        mor "多数人连这点都不会做。"
    translate None fawn_chapter5_0016:
        show sylvir neu -blush with dis
        s "而且他们是自己找来的。"
    translate None fawn_chapter5_0017:
        show morwen neu with dis
        mor "你这些天一直在锡德卡汉守着他们，对吧？"
    translate None fawn_chapter5_0018:
        show sylvir sur with dis
        s "....."
    translate None fawn_chapter5_0019:
        s "你怎么知道…？"
    translate None fawn_chapter5_0020:
        show morwen smi with dis
        mor "侥幸猜中。"
    translate None fawn_chapter5_0021:
        s "唉……"
    translate None fawn_chapter5_0022:
        mor "真的，能遇见你是我莫大的幸运。"
    translate None fawn_chapter5_0023:
        show sylvir shy with dis
        s "所以，你专程来就为调情？"
    translate None fawn_chapter5_0024:
        show morwen emb blush with dis
        mor "调情？！"
    translate None fawn_chapter5_0025:
        s "难道不是？"
    translate None fawn_chapter5_0026:
        mor "我…我只是想表达感激…！"
    translate None fawn_chapter5_0027:
        s "或许这是古人表达谢意的方式，但我管深夜造访女子闺房叫调情。"
    translate None fawn_chapter5_0028:
        mor "....."
    translate None fawn_chapter5_0029:
        mor "这…这个…"
    translate None fawn_chapter5_0030:
        show sylvir neu -blush with dis
        s "逗你的。要进来吗？别在雪里站着。"
    translate None fawn_chapter5_0031:
        show morwen smi with dis
        mor "现在谁在调情？"
    translate None fawn_chapter5_0032:
        show sylvir smi blush with dis
        "西尔维尔耸耸肩，嘴角勾起一抹浅笑。"
    translate None fawn_chapter5_0033:
        s "我从没否认。"
    translate None fawn_chapter5_0034:
        "说罢转身回到房中—这房间与秘密村里其他屋子别无二致—莫温紧随其后。"
    translate None fawn_chapter5_0035:
        "她脸上的红晕已无处可藏，却仍试图掩饰。"


    window hide dissolve

    scene bg sv room night with dissolve


    window show dissolve
    translate None fawn_chapter5_0036:
        "房间光线昏暗，只有一盏灯笼的光蔓延在家具上。"
    translate None fawn_chapter5_0037:
        show morwen n dim sur cloak at slightleft
        show sylvir n dim neu at slightright
        with dissolve
        mor "郑重声明，我不是来自{i}旧时代{/i}的人。"
    translate None fawn_chapter5_0038:
        show sylvir thi with dis
        s "哦？那你出生在几百年前？"
    translate None fawn_chapter5_0039:
        show morwen emb with dis
        mor "....."
    translate None fawn_chapter5_0040:
        s "旧时代。"
    translate None fawn_chapter5_0041:
        show morwen neu with dis
        mor "好吧。我很老，而你…相当年轻，对吧？"
    translate None fawn_chapter5_0042:
        show sylvir neu with dis
        s "没错。我并没有比外表看起来年长多少。"
    translate None fawn_chapter5_0043:
        mor "..."
    translate None fawn_chapter5_0044:
        show morwen wor with dis
        mor "西尔维尔，你为什么要帮我？又为什么要帮他们？"
    translate None fawn_chapter5_0045:
        show sylvir shy with dis
        s "..."
    translate None fawn_chapter5_0046:
        s "我猜你终究会问这个问题。"
    translate None fawn_chapter5_0047:
        mor "你对埃利奥特很忠诚，却明知我不可能认同他，还把我引到这里。你让雷恩和他的同伴进来，即便知道可能会因此惹上麻烦。"
    translate None fawn_chapter5_0048:
        mor "为什么？"
    translate None fawn_chapter5_0049:
        s "没有什么重大理由。我想帮你，就这么做了。"
    translate None fawn_chapter5_0050:
        mor "..."
    translate None fawn_chapter5_0051:
        s "....."
    translate None fawn_chapter5_0052:
        s "行。"
    translate None fawn_chapter5_0053:
        s "我和这里的其他人不同。我的人生充满冒险—风往哪吹，我就往哪去。如果我想知道远方山巅有什么，我就会去一探究竟。"
    translate None fawn_chapter5_0054:
        s "最终，我为信仰而死。对此我并不后悔。"
    translate None fawn_chapter5_0055:
        s "我真正后悔的是那些未抓住的机遇—那些未曾遇见的人，那些被我抛下环游世界的家人。那时我是孤独的。"
    translate None fawn_chapter5_0056:
        s "当时觉得没什么要紧。重要的是我，是世界，是我的地图。"
    translate None fawn_chapter5_0057:
        s "但死后，又有谁来哀悼我？"
    translate None fawn_chapter5_0058:
        show morwen sad with dis
        mor "西尔维尔…"
    translate None fawn_chapter5_0059:
        s "在你身上，我看到一个我生前会彻底避开的人。但正是这点让我想帮你。"
    translate None fawn_chapter5_0060:
        s "或许是嫉妒吧。即使在你死后，仍有人环绕着你。看到你努力帮助他们，让我也想伸出援手。"
    translate None fawn_chapter5_0061:
        mor "西尔维尔…要知道，也有人环绕着你啊。我会陪着你。"
    translate None fawn_chapter5_0062:
        show sylvir thi with dis
        s "也许你是对的。"
    translate None fawn_chapter5_0063:
        s "我没有像其他人那样放弃人性。如果你打算跟他们同行，我也一起去。"
    translate None fawn_chapter5_0064:
        show morwen smi with dis
        mor "…你想说的是你其实偷偷喜欢上他们了吧？"
    translate None fawn_chapter5_0065:
        show sylvir neu with dis
        "西尔维尔耸耸肩，脸上恢复平淡的表情。"
    translate None fawn_chapter5_0066:
        s "谁知道呢。"
    translate None fawn_chapter5_0067:
        "西尔维尔无意识地抬手触碰多年前失去手臂的位置。"
    translate None fawn_chapter5_0068:
        "每个人都必须放弃些什么。"
    translate None fawn_chapter5_0069:
        show morwen sad with dis
        mor "…这种感受我也有体会。为了他人而失去对自己如此重要的东西。"
    translate None fawn_chapter5_0070:
        mor "我常想，若能帮助他们，这一切便都值得。"
    translate None fawn_chapter5_0071:
        s "你之后有什么打算？"
    translate None fawn_chapter5_0072:
        show morwen neu with dis
        mor "之后？"
    translate None fawn_chapter5_0073:
        s "你将成为自由之身，这是你生命中第一次…好吧，我们别再提你的年龄了。"
    translate None fawn_chapter5_0074:
        mor "我确实没想那么远。或许我会效仿你去旅行。我想去看看曾经的故乡。"
    translate None fawn_chapter5_0075:
        s "如果需要向导，你知道去哪儿找我。"
    translate None fawn_chapter5_0076:
        show morwen sur with dis
        mor "你会离开村庄？"
    translate None fawn_chapter5_0077:
        show sylvir thi with dis
        s "我欠埃利奥特的情怕是这辈子都还不清，但我想，尽情活过后半生就足够报答他了。"
    translate None fawn_chapter5_0078:
        show morwen smi with dis
        mor "…莫温和西尔维尔？那个著名的制图师和她的助手？"
    translate None fawn_chapter5_0079:
        show sylvir smi with dis
        s "听起来还不坏，对吧？"
    translate None fawn_chapter5_0080:
        mor "是啊，确实不坏。总之，我不能再耽搁你了。"
    translate None fawn_chapter5_0081:
        s "我不介意。"
    translate None fawn_chapter5_0082:
        "莫温猝不及防地笑了，抬手抵住门框。"
    translate None fawn_chapter5_0083:
        show morwen smi blush with dis
        mor "你总是让我惊喜，西尔维尔。我喜欢这样。"
    translate None fawn_chapter5_0084:
        stop music fadeout 2.0
        "说完最后这句话，她推开门踏入寒夜，留下西尔维尔仍回味着她的话语。" 


    scene bg sv room day with Fade(1.0, 1.0, 1.0)
    window show dissolve

    translate None fawn_chapter5_0085:
        "当我睁开眼睛，首先映入眼帘的是福恩安详的睡颜。他的睫毛轻扫过肌肤，浓密而迷人。裸露的胸膛在透窗而入的阳光下微微起伏。"
    translate None fawn_chapter5_0086:
        play music "sounds/bgm/Discovery.ogg" fadein 3.0
        "不知不觉间，我已伸手轻抚他的面庞。"
    translate None fawn_chapter5_0087:
        "我的挚爱。"
    translate None fawn_chapter5_0088:
        "他能在我身边简直就是奇迹。若我曾做出任何不同选择，或许我们根本不会相遇。"
    translate None fawn_chapter5_0089:
        "但我们终究相遇了，如今在彼此身上找到了曾经缺失的部分。"
    translate None fawn_chapter5_0090:
        "我愿永生永世与他相伴。"
    translate None fawn_chapter5_0091:
        "我必须找到某种方式向他证明这点，某种即使我不在他身边诉说，他也能心灵相通的见证。"



    if fawnaskmarriage:
        translate None fawn_chapter5_0092:
            rs wsur "….有了…"
        translate None fawn_chapter5_0093:
            "我的思绪猛然闪回到很久很久以前与福恩的一次谈话。关于人们想要永远相守时会做的事。"
        translate None fawn_chapter5_0094:
            "一条象征永不分离的项链。"
        translate None fawn_chapter5_0095:
            "中央镶嵌着精心挑选的宝石。"
        translate None fawn_chapter5_0096:
            "若要在哪里找到这样的信物，肯定就在这附近…！"


    elif ashe_necklace:
        translate None fawn_chapter5_0097:
            rs wsur "就是这个…"
        translate None fawn_chapter5_0098:
            "我的思绪飞速回到几天前阿什说过的话。关于他拥有的那条项链，那是他妻子送的礼物。"
        translate None fawn_chapter5_0099:
            "一条象征永不分离的项链。"
        translate None fawn_chapter5_0100:
            "中央镶嵌着精心挑选的宝石。"
        translate None fawn_chapter5_0101:
            "若要在哪里找到这样的信物，肯定就在这附近…！"


    else:
        translate None fawn_chapter5_0102:
            "我绞尽脑汁想着能做些什么来向福恩表明他对我有多重要。"
        translate None fawn_chapter5_0103:
            "这里应该有个习俗对吧？结…结婚？"
        translate None fawn_chapter5_0104:
            "我确实在阿什身上看到过项链…那个管用吗？"
        translate None fawn_chapter5_0105:
            "项链中央镶嵌着一颗美丽的宝石。如果我要找类似的东西，那肯定得在这附近…！"

    translate None fawn_chapter5_0106:
        "下定决心后，我的目光又飘回福恩身上，想到要送他这么特别的东西就感到头晕目眩。"
    translate None fawn_chapter5_0107:
        rs "你会喜欢这个的，福恩…我保证。"

    window hide


    menu:
        "亲吻他":
            $ fawn_goodend += 1
            window show dissolve
            translate None fawn_chapter5_0108:
                "我俯身向前，在他唇上留下轻柔一吻。作为回应，他的睫毛轻轻颤动。"
            translate None fawn_chapter5_0109:
                f wsmi "早上好，雷恩。你醒得真早。"
            translate None fawn_chapter5_0110:
                rs wsmi "早。睡得还好吗？"
            translate None fawn_chapter5_0111:
                f "…昨晚被你折腾得我觉得自己连多撑一秒都做不到。"
            translate None fawn_chapter5_0112:
                "几乎能听到脑子里齿轮转动的声音，突然恍然大悟。啊，昨晚…确实很累人。"
            translate None fawn_chapter5_0113:
                rs wemb "我也是…天哪，光是回想就觉得累。我…我很享受，所以呃…我想…改天还想再来一次。"
            translate None fawn_chapter5_0114:
                f "我也是。"

            jump fawnroute5afterchoice

        "起床":
            $ fawn_badend += 1
            window show dissolve
            translate None fawn_chapter5_0115:
                "我轻手轻脚挪到床边，尽量让福恩多睡会儿。"
            translate None fawn_chapter5_0116:
                "说不定现在可以溜出去找那颗宝石？"
            translate None fawn_chapter5_0117:
                f wsur"…连个吻都没有吗？"
            translate None fawn_chapter5_0118:
                "Ah, damn."
            translate None fawn_chapter5_0119:
                rs "你醒了。我本打算让你多睡会的。"
            translate None fawn_chapter5_0120:
                "我挠着后脑勺露出微笑，假装一副无辜模样。"
            translate None fawn_chapter5_0121:
                f "你就躺在我身边，我怎么可能睡得着？"
            translate None fawn_chapter5_0122:
                f "要是睡着的话，就会错过看着你的时光了。"
            translate None fawn_chapter5_0123:
                rs "....."
            translate None fawn_chapter5_0124:
                "我吞咽着回忆起昨晚的事。"
            translate None fawn_chapter5_0125:
                "现在不行！我得去找宝石…！"


            jump fawnroute5afterchoice


label fawnroute5afterchoice:
    translate None fawn_chapter5_0126:
        rs "要去找其他人吗？"
    translate None fawn_chapter5_0127:
        "福恩点头应允，我们起身穿衣。衣物散落房间各处，这个场景让我有点难为情。"
    translate None fawn_chapter5_0128:
        "我推开窗户向外望去。白昼降临后，村庄终于有了生机。"
    translate None fawn_chapter5_0129:
        "不过他们看起来并不像神明，只是普通人而已。"
    translate None fawn_chapter5_0130:
        "我的思绪又飘回莱奥斯和赛恩身上，心头顿时沉重起来。"
    translate None fawn_chapter5_0131:
        "当我在这里虚度光阴时，他们却…天知道在什么地方，遭受着天知道怎样的折磨…"
    translate None fawn_chapter5_0132:
        "不，我别无选择。必须寻求埃利奥特的帮助，而这也意味着我必须留在这里。"
    translate None fawn_chapter5_0133:
        "我向你们保证，很快就会回来接你们两个。"
    translate None fawn_chapter5_0134:
        "我再次关上窗户，与福恩一同离开了房间。"

    window hide dissolve

    jump SV_morning

label fawn_sv_scenes:

    scene bg sv day
    show raen nw cloak neu at slightleft
    show fawn nw cloak neu at slightright
    with dissolve
    translate None fawn_chapter5_0135:
        "仅仅片刻之后，就只剩下我和福恩独处了。"
    translate None fawn_chapter5_0136:
        show raen nw smi with dis
        rs "这里的景色真的很美，不是吗？"
    translate None fawn_chapter5_0137:
        rs "难以想象世上竟存在这样的地方…十八年从未离开过家门的我，如今竟来到这座藏匿着众神的山间小镇…"
    translate None fawn_chapter5_0138:
        show fawn nw smi with dis
        f "连我自己都觉得难以置信。"
    translate None fawn_chapter5_0139:
        "福恩伸出手，我欣然握住，我们携手踏雪而行。小镇主要由小房子构成，很快就走到了尽头。"
    translate None fawn_chapter5_0140:
        "所经之处，人们纷纷避让。不像在锡德卡汉的舞会上那样充满蔑视，更像是…他们感到恐惧。"
    translate None fawn_chapter5_0141:
        show raen nw neu with dis
        rs "我很高兴他们找到了自由的容身之所，但是…你不觉得这也有些可悲吗？"
    translate None fawn_chapter5_0142:
        show fawn nw sad with dis
        f "可悲的是他们经历过太多苦难，以至于对我们充满恐惧。"
    translate None fawn_chapter5_0143:
        rs "…顺便说，我有件事想问你。"
    translate None fawn_chapter5_0144:
        show fawn nw smi with dis
        "他心领神会地对我笑了笑。"
    translate None fawn_chapter5_0145:
        f "你想知道我昨晚在做什么？"
    translate None fawn_chapter5_0146:
        rs "是有点好奇…"
    translate None fawn_chapter5_0147:
        f "不知哪来的勇气，我就是觉得必须和埃利奥特谈谈。不确定他是否听进去了，但无论如何…和他说完话后我感觉好些了。"
    translate None fawn_chapter5_0148:
        "原来是这样…"
    translate None fawn_chapter5_0149:
        "好吧，我不想再多打探。他有保留秘密的权利。"
    translate None fawn_chapter5_0150:
        rs "我理解。很高兴你们有机会沟通。"
    translate None fawn_chapter5_0151:
        show fawn nw sur with dis
        f "等等…雷恩，快看！"
    translate None fawn_chapter5_0152:
        show raen nw sur with dis
        "福恩突然压低声音，指着雪地。"
    translate None fawn_chapter5_0153:
        "等等…颜色像雪，但质地略有不同…"
    translate None fawn_chapter5_0154:
        f "雪兔！"
    translate None fawn_chapter5_0155:
        "他松开我的手，靠近那群野性的白兔。兔子好奇地抬头看他，却没有跳开。"
    translate None fawn_chapter5_0156:
        "福恩缓缓跪坐雪中，双腿交叠，立刻有只兔子凑了过来。"
    translate None fawn_chapter5_0157:
        show fawn nw smi with dis
        f "你好啊…你可真漂亮…"
    translate None fawn_chapter5_0158:
        f "你让我想起家乡的兔子，不过你更白些。"
    translate None fawn_chapter5_0159:
        rs "它们不怕你？"
    translate None fawn_chapter5_0160:
        f "只有动物从不对我感到害怕。"
    translate None fawn_chapter5_0161:
        rs "我才不怕你呢。"
    translate None fawn_chapter5_0162:
        f "嗯哼…那你觉得这说明什么呢？"
    translate None fawn_chapter5_0163:
        rs "嘿…"
    translate None fawn_chapter5_0164:
        f "啊哈哈，开玩笑的啦。下来陪我坐会儿吧。"
    translate None fawn_chapter5_0165:
        show raen nw neu with dis
        rs "不过我不想吓跑它们…"
    translate None fawn_chapter5_0166:
        "他拍了拍身旁的积雪，我悄悄向前挪动，跪坐在他身侧。"
    translate None fawn_chapter5_0167:
        show fawn nw hap with dis
        "渐渐地，其他小兔子也凑了过来，在福恩身上堆成了小山。他大笑着抚摸它们，显得自在极了。"
    translate None fawn_chapter5_0168:
        "机会来了，但该去哪儿找石头呢？"
    translate None fawn_chapter5_0169:
        rs "我去稍微活动下腿脚可以吗？"
    translate None fawn_chapter5_0170:
        f "我会跟你一起去的。"
    translate None fawn_chapter5_0171:
        rs "不用！呃…我是说，你可能很久都碰不到和小动物玩耍的机会了，所以…不如在这儿多待会儿？我去去就回。"
    translate None fawn_chapter5_0172:
        show fawn nw sur with dis
        f "你确定这样可以吗？"
    translate None fawn_chapter5_0173:
        rs "嗯，好好玩。"
    translate None fawn_chapter5_0174:
        "我从雪地里站起身，拍掉身上的雪，离开了福恩的视线。"


    hide fawn with dissolve

    show morwen n cloak smi at slightright with dissolve
    translate None fawn_chapter5_0175:
        mor "在享受晨间空气吗？"
    translate None fawn_chapter5_0176:
        show raen nw sur with dis
        rs "莫温！我需要你帮忙！"
    translate None fawn_chapter5_0177:
        show morwen sur with dis
        mor "哦？"
    translate None fawn_chapter5_0178:
        rs "我想…给福恩准备个礼物。要找块能做项链的石头，但不知该去哪儿找。"
    translate None fawn_chapter5_0179:
        mor "项链？哦雷恩，这主意真棒。"
    translate None fawn_chapter5_0180:
        show morwen smi with dis
        mor "嗯…我知道有个地方。山上有处天然温泉形成的瀑布，瀑布底下能捡到天然宝石。"
    translate None fawn_chapter5_0181:
        rs "太完美了！"
    translate None fawn_chapter5_0182:
        mor "真是个贴心的小伙子，雷恩。他肯定会答应的。"


    hide morwen
    hide raen
    with dissolve
    translate None fawn_chapter5_0183:
        "她挥手示意我离开，我迅速赶回福恩身边。既然要去瀑布，我当然想带着福恩同行。只是得偷偷把礼物准备好。"
    translate None fawn_chapter5_0184:
        rs c wsur "福恩！"
    translate None fawn_chapter5_0185:
        "离开这会儿功夫，福恩整个人都被白毛团子淹没了。我正担心他会被兔群扛走，突然树顶掉下一团雪，兔子们瞬间四散逃开。"
    translate None fawn_chapter5_0186:
        f c wsur "....."
    translate None fawn_chapter5_0187:
        "我向他伸出手，他自然地握住。"
    translate None fawn_chapter5_0188:
        rs c wsmi "刚才遇到莫温，她说附近有处瀑布。我从没见过瀑布，想和你一起去看看。"
    translate None fawn_chapter5_0189:
        "他的脸庞顿时亮了起来—每当遇到兴奋的事他总是这样—更加用力地攥紧了我的手。"
    translate None fawn_chapter5_0190:
        f c whap"太想去啦！"


    if iv_scene_three and illranveras_friend >= 5:
        $ iv_scene_four = True
        jump illranverasscene4

    else:
        jump fawnroute5cont

label fawnroute5cont:
    translate None fawn_chapter5_0191:
        rs c wsmi "快，我们去找瀑布吧。"
    translate None fawn_chapter5_0192:
        "放下小兔子们后，福恩恋恋不舍地回头张望了一眼，随后又微笑着握紧了我的手。"
    translate None fawn_chapter5_0193:
        show bg sc mountains day with dissolve:
            xpos 0.5 ypos 1.11 xanchor 0.5 yanchor 1.0 zoom 1.12
        "我们迅速折返，沿着莫温指引的小径前行。走出村庄，踏上人迹罕至的小路，我们穿梭在荒野中，惊叹于眼前绝美的景致。"
    translate None fawn_chapter5_0194:
        rs c wsur "你听见了吗？"
    translate None fawn_chapter5_0195:
        "湍急的水声越来越近，我们兴奋地加快了脚步。"


    window hide dissolve
    scene bg waterfall with dissolve
    window show dissolve
    translate None fawn_chapter5_0196:
        "一道奔腾的瀑布豁然眼前，宁静中蕴含着磅礴力量。"
    translate None fawn_chapter5_0197:
        "除了瀑布的轰鸣声，周遭树林一片寂静，万物仿佛凝固了，这个时刻只属于我们两个人。"
    translate None fawn_chapter5_0198:
        rs c wsur "哇…真美啊。不过水声比我预想的要吵得多。"
    translate None fawn_chapter5_0199:
        f c wsur "要是水温够暖就能下去泡泡了。"
    translate None fawn_chapter5_0200:
        rs "嗯…说不定可以？莫温说上游某处连着个温泉。"
    translate None fawn_chapter5_0201:
        "福恩惊讶地眨眨眼，试探性地把手指浸入水中。"
    translate None fawn_chapter5_0202:
        f "好烫！"
    translate None fawn_chapter5_0203:
        rs "那要不要游泳？不知道水里有没有咬人的东西…"
    translate None fawn_chapter5_0204:
        f c wsmi"只要你不打算咬我，应该就安全。"
    translate None fawn_chapter5_0205:
        rs c wemb "..."
    translate None fawn_chapter5_0206:
        f c wsur "雷恩？"
    translate None fawn_chapter5_0207:
        rs "啊…啊，来了！"
    translate None fawn_chapter5_0208:
        "不知为何，虽然我们早就赤诚相见多次，但青天白日里脱衣服…还是有点难为情。"
    translate None fawn_chapter5_0209:
        "福恩倒是毫不扭捏，三两下脱个精光就泡进了热水里。"
    translate None fawn_chapter5_0210:
        f c wsmi "啊…"
    translate None fawn_chapter5_0211:
        f "不下来吗？水温正合适…"
    translate None fawn_chapter5_0212:
        rs c wemb "呃，等我…缓一下…"
    translate None fawn_chapter5_0213:
        f c wsur "你害羞了？"
    translate None fawn_chapter5_0214:
        rs c wemb "不要！"
    translate None fawn_chapter5_0215:
        f c wsmi "哎呀呀，雷恩，你什么样子我没见过，有什么不好意思的。"
    translate None fawn_chapter5_0216:
        rs "....."
    translate None fawn_chapter5_0217:
        "我快速脱掉衣服，踏入温泉挨着福恩坐下。"
    translate None fawn_chapter5_0218:
        rs c wneu "啊…确实舒服…"
    translate None fawn_chapter5_0219:
        "那么，该在这里找给福恩的…唔…"
    translate None fawn_chapter5_0220:
        "我在池底摸索着，寻找莫温说过会出现的宝石。"
    translate None fawn_chapter5_0221:
        f c wneu "你在干什么？"
    translate None fawn_chapter5_0222:
        rs "啊！？哦，呃…就是…感受下池底？"
    translate None fawn_chapter5_0223:
        f "..."
    translate None fawn_chapter5_0224:
        f "你怪怪的。"
    translate None fawn_chapter5_0225:
        "他笑着从我身旁站起来，突然坐到了我大腿上。"
    translate None fawn_chapter5_0226: # NSFW 3 STARTS HERE
        rs c wsur "你…干什么！？"
    translate None fawn_chapter5_0227:
        f c wsmi "坐着啊。"
    translate None fawn_chapter5_0228:
        rs "坐我身上？"
    translate None fawn_chapter5_0229:
        f "不可以吗？"
    translate None fawn_chapter5_0230:
        rs c wemb "当…当然可以…"
    translate None fawn_chapter5_0231:
        f "那就好！"
    translate None fawn_chapter5_0232:
        "他把脸埋进我的颈窝，双臂懒洋洋地环住我的肩膀。靠在我身上轻叹一声，整个人都放松地依偎过来。"
    translate None fawn_chapter5_0233:
        f "真舒服。"
    translate None fawn_chapter5_0234:
        "我在位置上动了动，他压在我身上的重量让我有点承受不住。"
    translate None fawn_chapter5_0235:
        f c wneu "别乱扭了。"
    translate None fawn_chapter5_0236:
        rs "我…我控制不住，你…"
    translate None fawn_chapter5_0237:
        f "...?"
    translate None fawn_chapter5_0238:
        f c wemb "啊…"
    translate None fawn_chapter5_0239:
        "当他意识到自己在做什么时，整张脸都涨红了。"
    translate None fawn_chapter5_0240:
        f c wemb "我…我不是故意的…"
    translate None fawn_chapter5_0241:
        rs c wemb "我不…介意…只是…我们有点太露天了。"
    translate None fawn_chapter5_0242:
        f c wemb "..."
    translate None fawn_chapter5_0243:
        f c wemb "没人会来这里的，对吧？"
    translate None fawn_chapter5_0244:
        rs "你说什么？"
    translate None fawn_chapter5_0245:
        f "我只是在想…"
    translate None fawn_chapter5_0246:
        stop music fadeout 3.0
        "他天真地眨着眼，把腿分跨在我两侧，在水中几乎骑在我身上。"
    translate None fawn_chapter5_0247:
        f c wneu "不管埃利奥特今晚说什么，我们都得离开。等我们回到锡德卡汉…"
    translate None fawn_chapter5_0248:
        play music "sounds/bgm/sex.ogg" fadein 4.0
        "他脸上挂着同样无辜的表情，半硬的性器抵着我的。"
    translate None fawn_chapter5_0249:
        f c wsad "即使我不想承认，但我们有可能活不下来。这可能是我们最后…"
    translate None fawn_chapter5_0250:
        rs c wemb "万…万一有人来呢？"
    translate None fawn_chapter5_0251:
        f c wemb "我敢肯定他们会被声音吓跑的。"
    translate None fawn_chapter5_0252:
        rs "....."
    translate None fawn_chapter5_0253:
        rs "这种自信到底哪来的…"
    translate None fawn_chapter5_0254:
        "我抬手抚上他的脸，他把脸埋进我掌心。"
    translate None fawn_chapter5_0255:
        rs "我绝不会让你出事，我保证—"
    translate None fawn_chapter5_0256:
        rs "啊！喂！"
    translate None fawn_chapter5_0257:
        "趁我分神时，他用手圈住我俩的性器，轻轻撸动。温泉的热气蒸腾，福恩的身体紧贴着我，再加上他现在为我们同时手淫的姿势，让我头晕目眩。"
    translate None fawn_chapter5_0258:
        rs "啊..啊，福恩…"
    translate None fawn_chapter5_0259:
        f "嗯..啊.."
    translate None fawn_chapter5_0260:
        "我们很快都有了反应，我在福恩娴熟的手法下迅速硬挺。"
    translate None fawn_chapter5_0261:
        "我无处安放的手垂在身侧，最后游移到福恩胸前，轻轻掐揉他的乳头。"
    translate None fawn_chapter5_0262:
        f "...!"
    translate None fawn_chapter5_0263:
        f "喂…喂！"
    translate None fawn_chapter5_0264:
        "当我抚弄他胸膛时他几乎从我腿上跳起来，而当我凑上前轻咬时，我以为他要打我。"
    translate None fawn_chapter5_0265:
        f "那样…感觉好奇怪…"
    translate None fawn_chapter5_0266:
        rs "糟糕的奇怪？"
    translate None fawn_chapter5_0267:
        f "不…不是…但你说过不会咬人的。"
    translate None fawn_chapter5_0268:
        rs "我从没说过不咬。"
    translate None fawn_chapter5_0269:
        "我继续沿着他胸口往下吻，留下细小的红痕。"
    translate None fawn_chapter5_0270:
        "作为回应，他手上的动作加快，我拼命咬住嘴唇抑制呻吟，但无论如何闷哼声还是从喉咙溢出，在石壁间回荡，穿过整片树林。"
    translate None fawn_chapter5_0271:
        f "要是你…啊…继续这样，肯定会被人听见。"
    translate None fawn_chapter5_0272:
        rs "嗯…都怪你.."
    translate None fawn_chapter5_0273:
        f "不是…嗯…我的错 你只是因为简单坐在你腿上就有这么大反应…"
    translate None fawn_chapter5_0274:
        rs "当我们都赤身裸体时…你还指望发生什么呢…"
    translate None fawn_chapter5_0275:
        f "好吧..也许我是故意的..？"
    translate None fawn_chapter5_0276:
        rs "你这小…"
    translate None fawn_chapter5_0277:
        "他顽皮地笑着 拇指掠过我的龟头 我的身体随之战栗 渴求更多爱抚"
    translate None fawn_chapter5_0278:
        rs "我想..我想对你做你帮我做过的事.."
    translate None fawn_chapter5_0279:
        f c wsmi "什么事？"
    translate None fawn_chapter5_0280:
        rs "你知道的..！"
    translate None fawn_chapter5_0281:
        f "不说清楚我可不知道哦"
    translate None fawn_chapter5_0282:
        "他露出甜美的笑容 但我能看出他又在试图让我难为情"
    translate None fawn_chapter5_0283:
        rs "我想用…我的嘴…伺候你.."
    translate None fawn_chapter5_0284:
        "我扭头避开视线低声嘟囔 但他轻易捕捉到了我的话"
    translate None fawn_chapter5_0285:
        f "那么…我有个主意"
    translate None fawn_chapter5_0286:
        rs "...?"
    translate None fawn_chapter5_0287:
        "他的手离开了我们紧贴的阴茎 突如其来的空虚让我几乎要哀求他回来"
    translate None fawn_chapter5_0288:
        f c wemb "躺上来"
    translate None fawn_chapter5_0289:
        rs "石头上？不会冷吗？"
    translate None fawn_chapter5_0290:
        f "可能会冷 但我会温暖你"
    translate None fawn_chapter5_0291:
        "想到这里 我跨出蒸腾的温泉踏入冷空气 立即打起寒颤 在他指定的位置躺下 偏头注视着他"
    translate None fawn_chapter5_0292:
        "他爬出池水 当他完全赤裸着勃起的状态向我走来时 我的脸颊发烫"

    window hide dissolve

    scene gallery_167
    if persistent.streamer_mode:
        show fawn_third_sex_censor
    with dissolve
    window show dissolve
    translate None fawn_chapter5_0293:
        "福恩跨跪在我上方 他硬挺的阳具悬在我脸前仅几英寸处"
    translate None fawn_chapter5_0294:
        rs "....."
    translate None fawn_chapter5_0295:
        "他没有丝毫迟疑 立刻将我含入口中 那份炽热因寒冷空气而显得愈发滚烫"
    translate None fawn_chapter5_0296:
        "当他同时用手套弄并用嘴侍奉时 我倒抽一口气"
    translate None fawn_chapter5_0297:
        "我艰难地咽了咽口水 随后按住福恩的臀部将他前端含进口中 略带咸味 却又如此灼热"
    translate None fawn_chapter5_0298:
        "我用舌头沿着他的柱身缓缓上舔 故意放慢速度 作为报复 福恩将我整根吞没 用力吸吮"
    translate None fawn_chapter5_0299:
        rs "啊..！嗯 这…不公平.."
    translate None fawn_chapter5_0300:
        "伴随着整根抽离的吸啜声 他的嘴完全离开 空气中留下细微的\"啵\"声"
    translate None fawn_chapter5_0301:
        "我迅速意识到这才是真正的公平 于是重新将福恩含入 模仿着他的动作整根吞入 感受他龟头抵住喉头的陌生触感 虽新奇却并不难受"
    translate None fawn_chapter5_0302:
        "幸好我的咽反射不算强烈…"
    translate None fawn_chapter5_0303:
        "渴望着他的唇舌，福恩终于再次开始动作，我再次被他包裹的感觉完全吞噬了。"
    translate None fawn_chapter5_0304:
        "我半眯着眼，用舌头勾勒过他下体的曲线。能看到福恩的睫毛颤动闭合，旋即又充满活力地睁开，然后他开始起伏头部。"
    translate None fawn_chapter5_0305:
        "我僵住了，几乎抑制不住挺腰的冲动。"
    translate None fawn_chapter5_0306:
        rs "哈啊.."
    translate None fawn_chapter5_0307:
        f "嗯…"
    translate None fawn_chapter5_0308:
        "他一次次深入索取，将我逼到极限，丝毫不给我平复兴奋的机会。"
    translate None fawn_chapter5_0309:
        "好啊，既然他不给我思考的余地…！"
    translate None fawn_chapter5_0310:
        "我以同样的节奏回应，将他完全纳入又彻底抽离，重复着这个动作直到我的下巴开始酸痛。"
    translate None fawn_chapter5_0311:
        "他的舌尖打着转，简直要让我发狂。更别提每次他含着我呻吟时，震感让我浑身战栗。"
    translate None fawn_chapter5_0312:
        "福恩向后撤了些，绕着我的顶端打转轻吮，舔舐着已经渗出的液体，手掌再次握住根部套弄剩余部分。"
    translate None fawn_chapter5_0313:
        "我的腰终于不受控制地挺动，但福恩没有抵抗这个动作，反而轻松地将我完全纳入，吸紧脸颊让整根没入他口中。"
    translate None fawn_chapter5_0314:
        rs "福恩..我不行…我快要撑不住了…"
    translate None fawn_chapter5_0315:
        "积累已久的压力此刻仿佛随时会爆发，于是我用力吮吸着福恩，迫切希望他能与我同时到达。"
    translate None fawn_chapter5_0316:
        "我颤抖着的双腿和腰肢不断挺入福恩敞开的、诱人的口腔，他的背脊在我上方弓起，唇间溢出的呻吟震动将我推过临界点。"
    translate None fawn_chapter5_0317:
        rs "太…太烫太湿了…福恩，我真的不行…"
    translate None fawn_chapter5_0318:
        "我的呼吸凌乱急促，视线开始模糊。不知道是温泉水汽还是福恩的缘故，但已经不重要了。"
    translate None fawn_chapter5_0319:
        "唯一重要的是我如此、如此渴望的释放。"
    translate None fawn_chapter5_0320:
        "福恩用力一吸，这就足够了。在他上下吞吐间我在他口中爆发，仿佛要榨干我的最后一滴。"
    translate None fawn_chapter5_0321:
        "眯着眼，我看到阳光洒在福恩弓起的背脊上，他忽然僵住，随即全数倾泻在我脸上。"
    translate None fawn_chapter5_0322:
        rs "福恩…"


    window hide dissolve
    scene bg waterfall with dissolve
    window show dissolve
    translate None fawn_chapter5_0323:
        "福恩瘫倒在一边，呼吸粗重，我也跟着瘫倒下来。"
    translate None fawn_chapter5_0324:
        "我听到他用力吞咽的声音，然后他又张开了嘴。"
    translate None fawn_chapter5_0325:
        f c wemb "那太棒了…"
    translate None fawn_chapter5_0326:
        rs c wemb "你刚才…你刚刚是不是…？"
    translate None fawn_chapter5_0327:
        f c wsmi "我吞下去了。"
    translate None fawn_chapter5_0328:
        rs c wsur "...!"
    translate None fawn_chapter5_0329:
        rs c wsur "这…难道不恶心吗？！"
    translate None fawn_chapter5_0330:
        f "如果是和你一起就不觉得。"
    translate None fawn_chapter5_0331:
        rs "..."
    translate None fawn_chapter5_0332:
        rs "我…我们走之前我可能得先清洗一下…"
    translate None fawn_chapter5_0333:
        "双腿颤抖着，我重新沉入温水中，感觉自己随时可能倒下。"
    translate None fawn_chapter5_0334:
        "当然，我想洗干净，但更重要的是…"
    translate None fawn_chapter5_0335:
        "远离福恩后，我搓洗着脸和身体，冲洗掉…各种液体，这时脚下突然踩到了什么。"
    translate None fawn_chapter5_0336:
        "我弯下腰，把那东西举到光线下。"
    translate None fawn_chapter5_0337:
        "一颗淡粉色的宝石在最后的午后阳光下闪闪发光，粗糙却美丽。"
    translate None fawn_chapter5_0338:
        rs c wneu "就是这里…"
    translate None fawn_chapter5_0339:
        f c wneu "你在那边干什么？"
    translate None fawn_chapter5_0340:
        rs "呃…就是在清理。来吧，离开前我们不如再四处看看？"
    translate None fawn_chapter5_0341: # NSFW 3 ENDS HERE
        stop music fadeout 2.0
        "我们从瀑布周围收集起略微积雪的衣物，穿好后又绕着山走了一会，不过这次走得慢了些。"


    if caspianaemylromance >= 2 and ca_scene_one == True:
        $ ca_scene_two = True
        jump caspianaemylscene2
    else:
        scene bg sv sunset with dissolve:
            xpos 0.09 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 2.02
        window show dissolve
        play music "sounds/bgm/night.ogg" fadein 2.0
        jump raenaemylsv
