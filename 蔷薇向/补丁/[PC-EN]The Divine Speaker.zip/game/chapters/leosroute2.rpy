label leosroute2:
    window hide dissolve

    scene bg ball with fade:
        xpos 0.9 ypos 1.74 xanchor 0.5 yanchor 1.0 zoom 1.83
        linear 45.0 xpos 0.11 ypos 1.74 xanchor 0.5 yanchor 1.0 zoom 1.83
    window show dissolve
    translate None leos_chapter2_0001:
        "莱奥斯和我悄悄穿过黑暗，循着前方某处现场乐队演奏的声音。我的视线在走廊四处游移，对周围环境充满兴趣。"
    translate None leos_chapter2_0002:
        "即使在黑暗中也能看出这个房间有多么优雅。高挑的天花板、精美的装饰、占据整面墙的油画…"
    translate None leos_chapter2_0003:
        "突然，我感觉有人抓住我的手，开始拽着我向前走。"
    translate None leos_chapter2_0004:
        rs c wsur "嘿，这是干嘛？"
    translate None leos_chapter2_0005:
        l c wthi "我不想让你又迷路。"
    translate None leos_chapter2_0006:
        stop music fadeout 2.0
        "不知为何我感到脸颊发烫，尽管空荡荡的房间里寒意逼人。"
    translate None leos_chapter2_0007:
        scene bg ball with dissolve:
            xpos 0.76 ypos 1.3 xanchor 0.5 yanchor 1.0 zoom 1.59
        "最终我们走进舞厅时，我几乎抑制不住惊叹。这里华丽得超乎想象。"
    translate None leos_chapter2_0008:
        play music "sounds/bgm/sidcaeham.ogg"
    translate None leos_chapter2_0009:
        "首先映入眼帘的是高耸天花板上繁复的金色螺旋纹饰，接着是悬挂的巨大枝形吊灯。"
    translate None leos_chapter2_0010:
        "厅内早已挤满盛装出席的宾客。各色晚礼服与西装。即使我穿得够体面，仍感到相形见绌。"

    show raen nw dim sur at slightleft
    show leos nw dim neu at slightright
    with dissolve
    translate None leos_chapter2_0011:
        rs "哇…"
    translate None leos_chapter2_0012:
        l "别表现得太吃惊。我们参加过几十次这种场合，对吧？"
    translate None leos_chapter2_0013:
        show raen nw dim neu with dis
        rs "是…是啊！我们该做什么？"
    translate None leos_chapter2_0014:
        l "嗯…从那边开始吧。"
    translate None leos_chapter2_0015:
        "莱奥斯高昂着头领路。尽管他对赛恩抱怨连连，但确实把这个角色扮演得很到位。"
    translate None leos_chapter2_0016:
        "和他相比，我…算了，或许最好不要多想。"
    translate None leos_chapter2_0017:
        "每个与他交谈的人都会回应，却用漠不关心的表情斜瞥我一眼。"
    translate None leos_chapter2_0018:
        hide leos with dissolve
        show raen at center with move
        "我知道他让我保持安静，但是…"
    translate None leos_chapter2_0019:
        show raen nw dim sur with dis
        rs "那个，打扰一下？"
    translate None leos_chapter2_0020:
        "眼前这位穿着翡翠长裙的金发女士看着我，眼神仿佛在说\"谁放这种人进来的？\"，随即转身离去。"
    translate None leos_chapter2_0021:
        show raen nw dim sad with dis
        rs "...."
    translate None leos_chapter2_0022:
        "无论我转向何人，他们都如法炮制。但当莱奥斯发言时，所有人都目不转睛地望着他，眼中闪着小星星。"
    translate None leos_chapter2_0023:
        l wsur "雷恩，过来—"
    translate None leos_chapter2_0024:
        w1 "这位绅士，愿意跳支舞吗？"
    translate None leos_chapter2_0025:
        l "呃，其实我—"
    translate None leos_chapter2_0026:
        "未等他回答，她已挽住他的手拖向舞池，后面跟着一串跃跃欲试的淑女。"
    translate None leos_chapter2_0027:
        stop music fadeout 4.0
        rs "开玩笑的吧…？"
    translate None leos_chapter2_0028:
        "叹着气，我在餐桌旁坐下注视着莱奥斯。他在舞池中游刃有余地旋转，目光始终避开那些邀舞的女士。"
    translate None leos_chapter2_0029:
        "以他的性格，大概是尴尬得不好意思拒绝跳舞，可是…"
    translate None leos_chapter2_0030:
        "这依然让我感到恼火。"
    translate None leos_chapter2_0031:
        play music "sounds/bgm/sad.ogg" fadein 2.0
        "为什么她们能和他跳舞？他明明不喜欢她们。"
    translate None leos_chapter2_0032:
        "我是他的…我是他的朋友甚至都没机会和他跳舞。她们被温柔以待，而我却被推到一旁。"
    translate None leos_chapter2_0033:
        "…."
    translate None leos_chapter2_0034:
        "我在想什么…我又不是非要和他跳舞。那样太奇怪了。我们不是那种关系。"
    translate None leos_chapter2_0035:
        "然而，我还是不由自主地被吸引—看着他与她十指相扣，看着他轻轻搭在她腰间的手。"
    translate None leos_chapter2_0036:
        "终于，她离开了莱奥斯，但下一秒就有人填补了她的位置。他总是这么受欢迎。"
    translate None leos_chapter2_0037:
        "我移开视线，胸中涌动着说不清道不明的愤怒。"
    translate None leos_chapter2_0038:
        "数十人从我身边经过却视若无睹。我出声呼唤，却无人理睬。"
    translate None leos_chapter2_0039:
        "我真是没用。"
    translate None leos_chapter2_0040:
        show raen nw dim sur with dis
        "正当这些念头快要吞噬我时，我与房间另一端的人四目相对。"
    translate None leos_chapter2_0041:
        "橙发扎成马尾的男子。他系着围裙，衣着简朴。在人群中格外醒目，却不显得突兀。"
    translate None leos_chapter2_0042:
        "我猛地起身，匆忙向他追去，无视周遭投来的恼怒目光。"
    translate None leos_chapter2_0043:
        "当我靠近时，他转过身来，脸上写满惊讶。"
    translate None leos_chapter2_0044: #voice map with cyne route
        rs "请等一下！打扰了！"
    translate None leos_chapter2_0045:
        show raen at slightright with move
        show hone n dim sur at slightleft with dissolve
        u ".....?"
    translate None leos_chapter2_0046: #voice map with cyne route
        rs "对不起…吓到你了真的很抱歉。"
    translate None leos_chapter2_0047: #voice map with cyne route
        u "没关系，我只是有点惊讶竟然有人在注意我。"
    translate None leos_chapter2_0048: #voice map with cyne route
        rs "我也想说同样的话。我跟别人说话时，他们都没什么反应…"
    translate None leos_chapter2_0049: # new Leos line
        show raen nw dim neu with dis
        rs "我叫雷恩。能占用你一点时间吗？"
    translate None leos_chapter2_0049b:
        "他转头望向房间后方的一扇门。服务员们端着看起来很昂贵的食物频繁进出。"
    translate None leos_chapter2_0050: #voice map with cyne route
        show hone n dim neu with dis
        u "有点时间，不过我得赶快回厨房。我们可以边走边聊。"
    translate None leos_chapter2_0051: #voice map with cyne route
        h "对了，我叫霍恩。"
    translate None leos_chapter2_0052: #voice map with cyne route
        rs "霍恩…你是厨师之类的吗？"
    translate None leos_chapter2_0053: #voice map with cyne route
        show hone n dim smi with dis
        $ about_Hone.locked = False
        h "哈哈，我只是个{a=set_entry:enc_people->about_Hone}{color=#DA70D6}面包师{/color}{/a}。"
    translate None leos_chapter2_0054:
        "他说话时长着雀斑的脸亮了起来。虽然话不多，但周身散发着让人愿意亲近的气质。"
    translate None leos_chapter2_0055: #voice map with cyne route
        rs "我在找一个叫卡斯皮安的男人。他大概…17、18年前来过这里。我知道很久远了，但如果你能仔细回忆—"
    translate None leos_chapter2_0056: #voice map with cyne route
        h "卡斯皮安？我认识他啊。"
    translate None leos_chapter2_0057: #voice map with cyne route
        show raen nw dim sad with dis
        rs "就算你不认识，如果能介绍其他可能知道的人—"
    translate None leos_chapter2_0058: #voice map with cyne route
        show raen nw dim sur with dis
        rs "等等，什么？！"
    translate None leos_chapter2_0059: #voice map with cyne route
        show hone n dim hap with dis
        h "卡斯皮安。高个子，棕色头发。我时不时能见到他。"
    translate None leos_chapter2_0060: # new Leos line
        rs "你能告诉我去哪里找他吗？！我到处都找遍了！"
    translate None leos_chapter2_0060b:
        "走到门口时，霍恩把手搭在门框上。"
    translate None leos_chapter2_0061: #voice map with cyne route
        show hone n dim smi with dis
        h "…在下城区我有个面包坊。你们明天能来一趟吗？到时候可以详细说说他的事。"
    translate None leos_chapter2_0062: #voice map with cyne route
        h "不能再聊了，否则下次可能就没邀请函了。"
    translate None leos_chapter2_0063: #voice map with cyne route
        rs "好，明白了。我一定去。"
    translate None leos_chapter2_0064:
        hide hone with dissolve
        show raen at center with move
        "他微微点头致意，随即消失在厨房里。"
    translate None leos_chapter2_0065:
        show raen nw dim smi with dis
        rs "天啊，莱奥斯，就是这儿—"
    translate None leos_chapter2_0066:
        show raen nw dim sad with dis
        "等等…反正他也不在这儿。我是在自言自语。"
    translate None leos_chapter2_0067:
        "莱奥斯还在舞池里，看样子…一时半会抽不开身。"
    translate None leos_chapter2_0068:
        "我的目光掠过舞厅远端那扇敞开的门—似乎通往阳台，空无一人。"
    translate None leos_chapter2_0069:
        "也许呼吸点新鲜空气会好些。"

    window hide dissolve

    scene gallery_128 with dissolve
    window show dissolve
    translate None leos_chapter2_0070:
        "阳台清冷宜人，石阶上散落着点点雪花，也没有碍事的人。"
    translate None leos_chapter2_0071:
        "不过，即便真有人在，他们大概也不会搭理我。"
    translate None leos_chapter2_0072:
        "我确实不适合这种场合。怕是像个偷穿大人衣服的孩子。"
    translate None leos_chapter2_0073:
        "我俯身倚着栏杆，凝视下方花园。繁花似锦，却无人欣赏。"
    translate None leos_chapter2_0074:
        "他们都忙着自我陶醉。"
    translate None leos_chapter2_0075:
        "…我何必难过？一开始就知道该由莱奥斯负责周旋。他擅长这种事。"
    translate None leos_chapter2_0076:
        "早料到他经不住别人邀约，这种局面在所难免。"
    translate None leos_chapter2_0077:
        "那我胸中这团灼热是什么？为何有个声音嘶吼着要我把他拽离那些人？"
    translate None leos_chapter2_0078:
        "为何我竟真想做？"
    translate None leos_chapter2_0079:
        scene gallery_129 with dissolve
        l "终于自由了…为何丢下我？"
    translate None leos_chapter2_0080:
        "莱奥斯…"
    translate None leos_chapter2_0081:
        rs "我看你挺好的啊。"
    translate None leos_chapter2_0082:
        l "好？！差点把命都丢了！"
    translate None leos_chapter2_0083:
        rs "嗯…可完全看不出来。"
    translate None leos_chapter2_0084:
        l "你以为我跳舞是因为我{i}想{/i}跳吗？ 你在跟我开玩笑吧。"
    translate None leos_chapter2_0085:
        "不…我知道你不想，但是…"
    translate None leos_chapter2_0086:
        rs "没错，我就是这么想的。你本可以拒绝他们的！"
    translate None leos_chapter2_0087:
        "我干嘛要吵架…？"
    translate None leos_chapter2_0088:
        l "如果你有问题，你本可以说出来的。"
    translate None leos_chapter2_0089:
        rs "有什么用？！反正没人会听我的！他们只在乎你说什么！"
    translate None leos_chapter2_0090:
        l "…你是嫉妒还是怎么的？如果你想跳舞，为什么不说？"
    translate None leos_chapter2_0091:
        rs "什么？嫉妒？你在开玩笑吗？"
    translate None leos_chapter2_0092:
        l "你听起来很嫉妒。"
    translate None leos_chapter2_0093:
        rs "真是自以为是！反正也没人想和你跳舞。"
    translate None leos_chapter2_0094:
        l "所以…你不想跳舞？和我跳舞有什么问题吗？"
    translate None leos_chapter2_0095:
        rs "我从没说我有问题！"
    translate None leos_chapter2_0096:
        l "那你为什么不愿意？"
    translate None leos_chapter2_0097:
        stop music fadeout 3.0
        rs "好吧，我愿意！"
    translate None leos_chapter2_0098:
        "当我走向莱奥斯并伸出手时，背景响起了柔和的旋律—流畅而缓慢，非常适合跳舞。"
    translate None leos_chapter2_0099:
        play music "sounds/bgm/night.ogg" fadein 3.0
        scene gallery_129b with dissolve
        "他轻松地握住我的手，将我拉近，就像他对之前所有人做的那样。"
    translate None leos_chapter2_0100:
        "他的手搭在我的后腰，手指微微陷入。这种感觉既新奇又令人兴奋。"
    translate None leos_chapter2_0101:
        "宽阔，且如此有力。"
    translate None leos_chapter2_0102:
        "我们随着音乐节奏摇摆，舞台上只有我们两人。鞋跟敲击在冰冷的石头上。"
    translate None leos_chapter2_0103:
        l "嗷！"
    translate None leos_chapter2_0104:
        rs "啊…抱歉！"
    translate None leos_chapter2_0105:
        l "你跳舞真的很烂。"
    translate None leos_chapter2_0106:
        rs "我在尽力了…你也没好到哪里去。"
    translate None leos_chapter2_0107:
        l "至少我没踩你的脚。"
    translate None leos_chapter2_0108:
        rs "..."
    translate None leos_chapter2_0109:
        rs "对不起…"
    translate None leos_chapter2_0110:
        l "等等，不…我…我，呃…没关系，别在意。"
    translate None leos_chapter2_0111:
        "他的目光从我身上移开，但把我的手握得比之前更紧了。"
    translate None leos_chapter2_0112:
        "音乐起伏，我们一圈圈旋转，随着节奏起舞。缓慢而平稳。"
    translate None leos_chapter2_0113:
        "业余吗？是的，但感觉很好。有时候享受一件事就够了，不必太在意自己做得好不好。"
    translate None leos_chapter2_0114:
        "不过每当我踩到莱奥斯的脚时，他还是会皱眉。"
    translate None leos_chapter2_0115:
        "慢慢地歌曲接近尾声，美妙的音符在大厅内外回荡。"
    translate None leos_chapter2_0116:
        "结束时，我感到心跳加速。莱奥斯轻松的动作，他从睫毛下俯视我的眼神，最后停了下来。"
    translate None leos_chapter2_0117:
        l "好了，现在你不用嫉妒了。"
    translate None leos_chapter2_0118:
        rs "我..我没有嫉妒。"
    translate None leos_chapter2_0119:
        l "虽然他们跳得比你好。"
    translate None leos_chapter2_0120:
        rs "...."
    translate None leos_chapter2_0121:
        "为何我的心如此纷乱？我满脑子只想着告诉他别再去找他们了。要他待在我身边。"
    translate None leos_chapter2_0122:
        rs "…那我练习好了。"
    translate None leos_chapter2_0123:
        l "啊？"
    translate None leos_chapter2_0124:
        rs "我会勤加练习，这样你就不需要和别人跳舞了。"
    translate None leos_chapter2_0125:
        l "…那我也一样。"
    translate None leos_chapter2_0126:
        "黑暗中很难分辨，但他的脸颊似乎泛起了红晕。不过也许这只是我的想象。"
    translate None leos_chapter2_0127:
        rs "那么…晚些时候，我要向你证明我跳得比你好。"
    translate None leos_chapter2_0128:
        l "我从不拒绝小小比试。但你会大失所望的。"
    translate None leos_chapter2_0129:
        l "我们回屋里去吧？天…天开始冷了。"

    window hide dissolve

    scene bg ball with dissolve:
        xpos 0.44 ypos 1.13 xanchor 0.5 yanchor 1.0 zoom 1.44
    window show dissolve
    translate None leos_chapter2_0130:
        "回到舞厅后，一切如常。新一曲已奏响，众人相拥而舞。"
    translate None leos_chapter2_0131:
        "但与莱奥斯共舞的感觉，比任何舞步都更真实，更…像真实的生命。"
    translate None leos_chapter2_0132:
        "当我们走回房间时—"
    translate None leos_chapter2_0133:
        w1 "终于回来了？要接着跳完吗？"
    translate None leos_chapter2_0134:
        "我不自觉地紧紧抓住莱奥斯背后的衬衫，无声地祈求他别再离开。"
    translate None leos_chapter2_0135:
        l wneu "…恕我告退，小姐。这支舞只好改日再续了。"
    translate None leos_chapter2_0136:
        w2 "…你知道在哪里能找到我。"
    translate None leos_chapter2_0137:
        "她带着失望的表情消失在人群中。"
    translate None leos_chapter2_0138:
        l wneu "好，那到此为止。你打听到什么了吗？"
    translate None leos_chapter2_0139:
        "我冲他点点头，然后开口回答。"
    translate None leos_chapter2_0140:
        rs wneu "信不信由你，我撞见个正常人。叫霍恩的家伙。他说认识卡斯皮安，让我们明天去他面包店碰头。"
    translate None leos_chapter2_0141:
        l wsmu "呵，还真行。这些居然都是你自己打听来的。干得好。"
    translate None leos_chapter2_0142:
        "虽然这么说着，他却始终避免眼神接触。"
    translate None leos_chapter2_0143:
        "他牵起我的手，带我穿过人群走向出口。"



    if achievement.has("leos_ball"):
        pass
    else:
        $ renpy.display_notify("【成就解锁：非法入侵】")

    python:
        achievement.grant("leos_ball")
        achievement.sync()
    translate None leos_chapter2_0144:
        "大概还在担心我会走丢。"

    window hide dissolve

    scene bg sc night with dissolve:
        xpos 0.49 ypos 1.41 xanchor 0.5 yanchor 1.0 zoom 1.41
        linear 25.0 xpos 0.49 ypos 1.03 xanchor 0.5 yanchor 1.0 zoom 1.41
    window show dissolve
    translate None leos_chapter2_0145:
        "外面的空气刺骨寒冷，寒意直钻心底，让我们不自觉地靠得更近了些。"
    translate None leos_chapter2_0146:
        "走出大楼时，我们注意到有人环抱双臂站在阴影处。"
    translate None leos_chapter2_0147:
        i fli "终于出现了啊。是不是在里面玩得乐不思蜀了？"
    translate None leos_chapter2_0148:
        l c wann "哦，糟了…"
    translate None leos_chapter2_0149:
        rs c wsur "….你好啊，伊尔兰。在等我们吗？"
    translate None leos_chapter2_0150:
        i neu "确实。有些关于索伦的消息，但现在不是谈这个的时候。"
    translate None leos_chapter2_0151:
        rs "…知道霍恩面包坊吗？在下城区。"
    translate None leos_chapter2_0152:
        "他点点头。"
    translate None leos_chapter2_0153:
        rs "明天中午在那儿碰面。喂等等，维拉斯去哪了？"
    translate None leos_chapter2_0154:
        "我这才发现既不见那个桃红色头发的男人，也看不到那只蓝鸟。"
    translate None leos_chapter2_0155:
        i sad "…我们又不是形影不离的。"
    translate None leos_chapter2_0156:
        i "......."
    translate None leos_chapter2_0157:
        i "他现在看着索伦呢。不知为何他担心得要命。"
    translate None leos_chapter2_0158:
        l c wneu "这听起来不太妙。"
    translate None leos_chapter2_0159:
        i "........."
    translate None leos_chapter2_0160:
        i neu "明天再说。中午。霍恩的面包店。"


    window hide

    menu:
        "转达谢意":
            $ illranveras_friend += 1
            window show dissolve
            translate None leos_chapter2_0161:
                rs c wsmi "谢谢你，伊尔兰。"

            jump leoschoice1done

        "保持沉默":
            window show dissolve
            jump leoschoice1done


label leoschoice1done:
    translate None leos_chapter2_0162:
        "他转身离去，很快消失在夜色中。"
    translate None leos_chapter2_0163:
        rs c wsad "还是那么神秘又麻烦…"
    translate None leos_chapter2_0164:
        l c wthi "他肯定有事瞒着我们，只是我琢磨不透。"
    translate None leos_chapter2_0165:
        rs c wsur "是吗？"
    translate None leos_chapter2_0166:
        l "我确信如此。要是能想明白…"
    translate None leos_chapter2_0167:
        rs "我曾以为他是出于好意帮我们，但…他似乎是另有所图，对吧？"
    translate None leos_chapter2_0168:
        "可话说回来，维拉斯那么善良体贴…不会对我们有所隐瞒吧？"
    translate None leos_chapter2_0169:
        rs c wneu "哎…明天再操心吧。天色已晚，我也精疲力尽了。"
    translate None leos_chapter2_0170:
        l c wneu "回你房间去吧。"
    translate None leos_chapter2_0171:
        rs c wsur "你又要来我房间…？"
    translate None leos_chapter2_0172:
        l "你有意见？"
    translate None leos_chapter2_0173:
        rs "倒不是…好吧，反正争辩也没用。"
    translate None leos_chapter2_0174:
        l c wsmu "你明白就好。记住，再也别让我参加那种场合了。"
    translate None leos_chapter2_0175:
        rs c wsad "为什么？你明明如鱼得水。"
    translate None leos_chapter2_0176:
        l c wsur "我受不了那种人。眼里只有自己…"
    translate None leos_chapter2_0177:
        "他摇着头走上返回银柳区的大道。不久我们站在建筑外。莱奥斯拉开门示意我先进。"


    scene bg sw night with dissolve
    translate None leos_chapter2_0178:
        "经过时艾琳冲我们点头，正忙着在账本上记录什么。我默不作声跟着莱奥斯回到房间。"


    scene bg swroom night with dissolve:
        xpos 0.4 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.48
    translate None leos_chapter2_0179:
        "一进屋我就瘫倒在床，满足地陷进柔软被褥里。"
    translate None leos_chapter2_0180:
        rs wsad "总算回来了…虽然糟透了，但好歹有了线索。"
    translate None leos_chapter2_0181:
        l wneu "别太贪恋这奢侈。赛恩只付了一周房费，届时我们就得搬走。"
    translate None leos_chapter2_0182:
        rs "到时又该何去何从…"
    translate None leos_chapter2_0183:
        "莱奥斯没有回答，只是把椅子拖回床边坐下，让自己舒服地待着。"
    translate None leos_chapter2_0184:
        rs wneu "...."
    translate None leos_chapter2_0185:
        rs "为什么不直接上床呢？反正你昨晚也睡在这里了。"
    translate None leos_chapter2_0186:
        l wthi "那是意志薄弱的表现。我睡着时对你毫无用处。"
    translate None leos_chapter2_0187:
        rs wsad "我觉得无论什么时候你都对我很有用…"
    translate None leos_chapter2_0188:
        l "....."
    translate None leos_chapter2_0189:
        l "好吧，但如果你睡着时出了什么事，你知道该怪谁。"
    translate None leos_chapter2_0190:
        rs wsmi "我会承担全部责任，我保证。"
    translate None leos_chapter2_0191:
        "这次莱奥斯脱下靴子，爬上了我的床躺在我旁边，钻进了被窝里。"
    translate None leos_chapter2_0192:
        l wneu "明天我可能会消失一会儿，所以跟着其他人待着。"
    translate None leos_chapter2_0193:
        rs wsur "你要去哪？"
    translate None leos_chapter2_0194:
        l wthi "我有事要和伊尔兰谈。我会彻查这件事…"
    translate None leos_chapter2_0195:
        rs "什么？"
    translate None leos_chapter2_0196:
        l wneu "别担心这个。我会处理好的。"
    translate None leos_chapter2_0197:
        rs wsad "...."
    translate None leos_chapter2_0198:
        "他翻了个身，面朝着我对面的墙壁。"
    translate None leos_chapter2_0199:
        rs "我希望你有时候也能依赖我…或者至少相信我…"
    translate None leos_chapter2_0200:
        "我对着枕头低声呢喃，但没有得到回应。"

    stop music fadeout 2.0
    window hide dissolve

    scene black with eye_shut
    pause 2.0
    window show dissolve
    play music "sounds/bgm/creepy.ogg" fadein 2.0
    translate None leos_chapter2_0201:
        "一个充满悔恨低语的黑暗深渊拉扯着思绪，要求被看见。无数声音在他脑海中低语，挖开旧伤口。他想移开视线，想捂住耳朵，想哭喊着寻求帮助，但为时已晚。"
    translate None leos_chapter2_0202:
        "现在没人能帮他了。"
    translate None leos_chapter2_0203:
        crazy "{move}{sc=2}{color=#FFFF}{size=50}他会成长为完美的刺客—冷漠无情…{/sc}{/move}"
    translate None leos_chapter2_0204:
        lmn "不…我不想…"
    translate None leos_chapter2_0205:
        crazy "{move}{sc=2}{color=#FFFF}{size=50}把他关几年—那样他就会学会不依赖任何人。{/sc}{/move}"
    translate None leos_chapter2_0206:
        lmn "求求你…我只想要一个人，任何人都行…"
    translate None leos_chapter2_0207:
        crazy "{move}{sc=2}{color=#FFFF}{size=50}…反正他会害死所有亲近他的人。{/sc}{/move}"
    translate None leos_chapter2_0208:
        lmn "谁都可以…求你了… "
    translate None leos_chapter2_0209:
        crazy "{move}{sc=2}{color=#FFFF}{size=50}别再让我失望。找到那孩子解决掉。{/sc}{/move}"


    scene bg swroom night with hpunch
    translate None leos_chapter2_0210:
        l whur "啊..！"
    translate None leos_chapter2_0211:
        lmn "该死…妈的，又来了…又做梦了。"
    translate None leos_chapter2_0212:
        "莱奥斯环顾黑暗的房间，确认环境。这里是雷恩的房间。"
    translate None leos_chapter2_0213:
        lmn "它们越来越糟糕了…为什么我就不能好好睡一晚？"
    translate None leos_chapter2_0214:
        "他擦了擦满是噩梦冷汗的额头，低头看向身旁熟睡的身影。"
    translate None leos_chapter2_0215:
        "那张睡颜平静祥和，与莱奥斯的截然不同。他深吸一口气，凝视着那安详的面容，试图平复剧烈的心跳。"
    translate None leos_chapter2_0216:
        lmn "不过是个愚蠢的梦…"
    translate None leos_chapter2_0217:
        "雷恩的面部微微皱起，在额头留下细纹。莱奥斯伸手抚平那些纹路，他的表情立刻舒展开来。"
    translate None leos_chapter2_0218:
        lmn "可爱……"
    translate None leos_chapter2_0219:
        lmn "等等…什么？不，不可爱。诸神啊，我需要更多睡眠…"
    translate None leos_chapter2_0220:
        "他的手悬在雷恩上方，几近触碰却又收回。两人之间存在着难以跨越的鸿沟。"
    translate None leos_chapter2_0221:
        "他们的生命轨迹天差地别。成长于截然不同的世界。本不该有任何交集，可是…"
    translate None leos_chapter2_0222:
        lmn "可我却像条驯服的狗般追随着他。"
    translate None leos_chapter2_0223:
        lmn "为什么？我本可以随时离开。没人能阻拦我。"
    translate None leos_chapter2_0224:
        lmn "是报答救命之恩吗？没错，但我早已十倍偿还。我到底怎么了？"
    translate None leos_chapter2_0225:
        "红发男子将叹息埋进掌心，随即发出苦涩的自嘲笑声。"
    translate None leos_chapter2_0226:
        lmn "口口声声说要保护你，待在我身边才是最危险的。"
    translate None leos_chapter2_0227:
        lmn "我保护不了你。我生来就不是保护者的料。我只懂得夺取生命…若继续留在你身边，你也会死。"
    translate None leos_chapter2_0228:
        "他闭目沉思，心绪纷乱。理智与情感相互撕扯，这种矛盾令他无所适从。"
    translate None leos_chapter2_0229:
        "冷漠，无情。麻木不仁。这才是莱奥斯。这才是他自幼被塑造的模样。"
    translate None leos_chapter2_0230:
        "可心底有个声音在尖叫着要他叛逆—走自己的路。"
    translate None leos_chapter2_0231:
        lmn "但我不配。永远都不配。"
    translate None leos_chapter2_0232:
        "他烦躁地睁开眼。纷乱的思绪让他难以入眠。虽想出去走走，却又放心不让雷恩独处。"
    translate None leos_chapter2_0233:
        lmn "还是坐着守夜吧…"
    translate None leos_chapter2_0234:
        "他再度凝视雷恩温柔的睡颜，如是想道。"

    window hide dissolve

    if iv_scene_one and illranveras_friend >= 3:
        stop music fadeout 2.0
        jump illranverasscene2
    else:
        stop music fadeout 2.0
        scene black with eye_shut
        pause 1.0
        jump leosroute2continued

label leosroute2continued:

    scene bg swroom day with Fade(1.0, 1.0, 1.0):
        xpos 0.7 ypos 1.12 xanchor 0.5 yanchor 1.0 zoom 1.49
        linear 30.0 xpos 0.26 ypos 1.12 xanchor 0.5 yanchor 1.0 zoom 1.49
    window show dissolve
    play sound "sounds/sfx/knock.ogg"
    translate None leos_chapter2_0235:
        rs wneu "嗯…"
    translate None leos_chapter2_0236:
        play music "sounds/bgm/sidcaeham.ogg" fadein 3.0
        c wsur "跟你说，这家伙雷打不动。"
    translate None leos_chapter2_0237:
        f wsad "莱奥斯的房间也没有回应…"
    translate None leos_chapter2_0238:
        c "呃，但他向来这样。你不担心雷恩吗？"
    translate None leos_chapter2_0239:
        f "担心.."
    translate None leos_chapter2_0240:
        c whap "幸好…我有这个！"
    translate None leos_chapter2_0241:
        f wsur "你是怎么拿到钥匙的？"
    translate None leos_chapter2_0242:
        c "我订房间时艾琳给了我备用钥匙。"
    translate None leos_chapter2_0243:
        "开门声和脚步声让我睁开了朦胧的双眼。"
    translate None leos_chapter2_0244:
        rs wsur "嗯…赛恩，福恩？"
    translate None leos_chapter2_0245:
        c wsur "哎呀呀，瞧瞧我们发现了什么？"
    translate None leos_chapter2_0246:
        rs "什么？"
    translate None leos_chapter2_0247:
        f wemb ".............."
    translate None leos_chapter2_0248:
        c "你们两个就是忍不住要碰彼此对吧？"
    translate None leos_chapter2_0249:
        "什么？"
    translate None leos_chapter2_0250:
        "我顺着他们的视线转头，看见莱奥斯在我身旁熟睡，眼睛仍紧闭着。"
    translate None leos_chapter2_0251:
        rs wemb "...."
    translate None leos_chapter2_0252:
        c "这确实在意料之中。毕竟，还有什么比刺客追杀你更刺激的呢？"
    translate None leos_chapter2_0253:
        rs "等等…等等，不是你们想的那样！"
    translate None leos_chapter2_0254:
        c wsad "我们的雷恩真是长得太快了。现在连\"看起来像什么\"都懂了。感动得我快哭了呢。"
    translate None leos_chapter2_0255:
        l wann "…吵什么…走开…"
    translate None leos_chapter2_0256:
        c whap "莱~~~奥斯，你的女仆来给你送早餐啦。"
    translate None leos_chapter2_0257:
        l "什么？我没有..我哪来的…"
    translate None leos_chapter2_0258:
        "他终于睁开眼睛猛地坐直，皱眉看向赛恩，然后瞥了眼旁边的我。"
    translate None leos_chapter2_0259:
        l wemb "...."
    translate None leos_chapter2_0260:
        rs "呃…真的，他只是…在守夜…"
    translate None leos_chapter2_0261:
        c wsmi "哦~~~~是嘛。既然你们两个总算醒了，赶快出来找我们吧。"
    translate None leos_chapter2_0262:
        f wsad "…我…先走了。"
    translate None leos_chapter2_0263:
        "福恩转身离开，赛恩随即蹦蹦跳跳跟了上去。"
    translate None leos_chapter2_0264:
        rs "….抱歉。"
    translate None leos_chapter2_0265:
        l wneu "为什么道歉？闯进来的是他们。随他们怎么想。"
    translate None leos_chapter2_0266:
        "他整理好衣服先出了房间，留我独自坐在床上。"
    translate None leos_chapter2_0267:
        "片刻前他躺过的地方在我掌心仍有余温。"
    translate None leos_chapter2_0268:
        "不知为何，我独自攥紧了床单。"
    translate None leos_chapter2_0269:
        "不..他们还在外面等着。在这里发呆毫无意义。"
    translate None leos_chapter2_0270:
        "我跳下床整理好衣服，向门口走去。"

    window hide dissolve

    scene bg sc day with dissolve
    window show dissolve
    show leos nw neu cloak at left
    show fawn nw sad cloak at right
    show cyne nw sad cloak at center
    with dissolve
    translate None leos_chapter2_0271:
        c "天啊，不敢相信雷恩明明有我和福恩在这儿却还是选了你。"
    translate None leos_chapter2_0272:
        l "我听不懂你在说什么。"
    translate None leos_chapter2_0273:
        c "两个随时愿意为他赴汤蹈火的男人不要，偏偏选了最冷淡的那个。嘘—"
    translate None leos_chapter2_0274:
        l "我真不明白你围着我嗡嗡叫说什么。"
    translate None leos_chapter2_0275:
        show cyne nw sur with dis
        c "不明显吗？"
    translate None leos_chapter2_0276:
        l "明显没有。"
    translate None leos_chapter2_0277:
        c "你们明明就是对彼此有意思！"
    translate None leos_chapter2_0278:
        show leos nw thi with dis
        l "意思？什么意思？"
    translate None leos_chapter2_0279:
        c "非要我说那么明白吗…你们刚才同床共枕了对吧？"
    translate None leos_chapter2_0280:
        l "所以呢？"
    translate None leos_chapter2_0281:
        show cyne nw hap with dis
        c "…那你肯定也玩得有点嗨吧？"
    translate None leos_chapter2_0282:
        show leos nw emb blush with dis
        l "...."


    show leos at farleft
    show fawn at farright
    show cyne at cenright
    with move
    show raen nw neu cloak at cenleft
    with dissolve
    translate None leos_chapter2_0283:
        "我刚走出大楼，就看到一个气得满脸通红的莱奥斯挥舞着双臂，试图吓唬赛恩—对方只是报以大笑。"
    translate None leos_chapter2_0284:
        l "你在胡说什么？！当然没有！"
    translate None leos_chapter2_0285:
        rs "大家早上好。"
    translate None leos_chapter2_0286:
        f "早安，雷恩。"
    translate None leos_chapter2_0287:
        c "总~算来了。没有你可寂寞死我了！"
    translate None leos_chapter2_0288:
        show raen nw sur with dis
        rs "呃…"
    translate None leos_chapter2_0289:
        "赛恩撇下莱奥斯走上前，双手环住我的腰紧紧抱住。"
    translate None leos_chapter2_0290:
        show cyne nw sad with dis
        c "莱奥斯刚才欺负我来着。真不懂你喜欢他什么。"
    translate None leos_chapter2_0291:
        l "我根本没欺负人！"
    translate None leos_chapter2_0292:
        c "呜呜呜，我好难过哦！"
    translate None leos_chapter2_0293:
        show cyne nw hap with dis
        "他转身对莱奥斯眨眨眼露出笑容。"
    translate None leos_chapter2_0294:
        show leos nw ann -blush with dis
        l "你这小—"
    translate None leos_chapter2_0295:
        c "有人吃~醋~咯~"
    translate None leos_chapter2_0296:
        show raen nw neu with dis
        rs "别吵架了。快说说昨晚查到什么。"
    translate None leos_chapter2_0297:
        show fawn nw sur with dis
        f "有什么发现吗？"
    translate None leos_chapter2_0298:
        rs "遇到个叫霍恩的男人，他说认识卡斯皮安。约了今天在他店里见面。对了，伊尔兰也会来。"
    translate None leos_chapter2_0299:
        show cyne nw smi with dis
        c "哇哦，看来昨晚挺精彩啊。希望你们至少跳了支舞。"
    translate None leos_chapter2_0300:
        show raen nw emb blush
        show leos nw emb blush
        with dis
        rs "...."
    translate None leos_chapter2_0301:
        l "......."
    translate None leos_chapter2_0302:
        show cyne nw sur with dis
        c "卧槽真的假的？！你们真一起跳舞了？！靠，花多少钱我都想亲眼看看。"
    translate None leos_chapter2_0303:
        show fawn nw neu with dis
        f "…但更重要的是，这次可能真有眉目了。"
    translate None leos_chapter2_0304:
        show raen nw neu -blush with dis
        rs "感觉离他很近了…"
    translate None leos_chapter2_0305:
        show cyne nw smi with dis
        c "那还等什么？快走啊！"
    translate None leos_chapter2_0306:
        l "想走就别扒着他。"
    translate None leos_chapter2_0307:
        c "为什么？我们可以手牵手走嘛。"
    translate None leos_chapter2_0308:
        show leos nw ann -blush with dis
        l "...."
    translate None leos_chapter2_0309:
        show cyne nw sur with dis
        c "喂喂别用眼神杀人。好啦好啦，不碰你家那位了。"
    translate None leos_chapter2_0310:
        l "他不是我的—唉算了。"
    translate None leos_chapter2_0311:
        hide cyne
        hide leos
        with dissolve
        show raen at slightleft
        show fawn at slightright
        with move
        "他气呼呼地走开，在雪地上留下深深脚印。赛恩咯咯笑着追上去，只剩我和福恩留在原地。"
    translate None leos_chapter2_0312:
        show fawn nw sad with dis
        f "那个…雷恩，我在想…待会儿要不要一起逛逛城镇？之前都没机会结伴。"

    window hide

    menu:
        "好的":
            $ leos_badend += 1
            window show dissolve
            jump leosfawnyes

        "不要":
            $ leos_goodend += 1
            window show dissolve
            jump leosfawnno



label leosfawnyes:
    show raen nw smi with dis
    translate None leos_chapter2_0313:
        rs "太棒了，当然想！"
    translate None leos_chapter2_0314:
        show fawn nw hap with dis
        "他笑得咧开了嘴。"
    translate None leos_chapter2_0315:
        show raen nw sad with dis
        "我也笑着，直到想起莱奥斯昨晚说的话。他说要单独去见伊尔兰。"
    translate None leos_chapter2_0316:
        "这事让我心里很不舒服。"
    translate None leos_chapter2_0317:
        rs "…其实我…待会儿约了要和莱奥斯…"

    show fawn nw sad with dis
    jump leosfawnafter

label leosfawnno:
    show raen nw sad with dis
    translate None leos_chapter2_0318:
        rs "噢，其实是…"
    translate None leos_chapter2_0319:
        "……莱奥斯说他今天晚些时候会消失，去和伊尔兰谈谈。我……我不想让他一个人待着……"
    translate None leos_chapter2_0320:
        rs "…其实我…待会儿约了要和莱奥斯…"

    jump leosfawnafter

label leosfawnafter:
    translate None leos_chapter2_0321:
        f "哦…真的吗？"
    translate None leos_chapter2_0322:
        rs "是啊，抱歉。改天吧？"
    translate None leos_chapter2_0323:
        f "……别担心。"
    translate None leos_chapter2_0324:
        show raen nw sur with dis
        rs "等等，福恩—"
    translate None leos_chapter2_0325:
        hide raen
        hide fawn
        with dissolve
        "没等我说完，他已经追着另外两人离开了。我赶紧跟上，正好听见赛恩又在调侃莱奥斯。"
    translate None leos_chapter2_0326:
        "略微恼火地，我站到莱奥斯身旁，让赛恩退后和福恩并肩而行。"
    translate None leos_chapter2_0327:
        l c wneu "怎么这么久？"
    translate None leos_chapter2_0328:
        rs c wsmi "没什么！我这不来了吗？"
    translate None leos_chapter2_0329:
        "终于，我们抬头看见了在风中摇晃的招牌—「霍恩面包坊」。"
    translate None leos_chapter2_0330:
        "一群人拎着鼓鼓囊囊的纸袋走出店铺，里面装着满溢的面包糕点，他们兴奋地叽叽喳喳说笑着。"
    translate None leos_chapter2_0331:
        rs c wneu "应该就是这了。我们进去吗？时间还早，不过在里面等总比站在外面强。"
    translate None leos_chapter2_0332:
        f c wsad "....."
    translate None leos_chapter2_0333:
        c c wneu "嗯…我突然想起来有事要办。福恩，你陪我去？"
    translate None leos_chapter2_0334:
        f "我？什么事？"
    translate None leos_chapter2_0335:
        c c wsmi "特别重要的事！快来，路上告诉你。"
    translate None leos_chapter2_0336:
        f "好…好的…"
    translate None leos_chapter2_0337:
        c "我们晚点来找你们俩。别玩得太开心。"
    translate None leos_chapter2_0338:
        "赛恩拽着福恩的袖子把他拉走了。"
    translate None leos_chapter2_0339:
        rs c wsur "他们怎么回事…"
    translate None leos_chapter2_0340:
        l "谁知道呢。"
    translate None leos_chapter2_0341:
        "莱奥斯没再多说，替我拉开门，我们走了进去。"


    window hide dissolve
    jump honezarryn


label leosroute2continued2:
    scene bg sc day with Fade(1.0, 1.0, 1.0)
    window show dissolve
    translate None leos_chapter2_0342:
        l c wann "喂。"
    translate None leos_chapter2_0343:
        "红发男人猛地攥住同伴手腕拽停对方。伊尔兰原本锐利如刀的眼神，在看清来人后缓和下来。"
    translate None leos_chapter2_0344:
        show leos nw cloak neu at slightleft
        show illran n armsdown fli at slightright
        with dissolve
        play music "sounds/bgm/Scary.ogg" fadein 3.0
        i "你知道这样拽人很失礼吧？换作别人，早就被捅穿肚子了。"
    translate None leos_chapter2_0345:
        l "我要谈谈。"
    translate None leos_chapter2_0346:
        i "好好好，别这么着急。不过我可不打算约会，明白？"
    translate None leos_chapter2_0347:
        l "正好，我也没这意思。"
    translate None leos_chapter2_0348:
        v neu "我…想找机会和雷恩单独谈谈，得回去找他。回头见，伊尔兰。"
    translate None leos_chapter2_0349:
        show illran n sad with dis
        i "等等—该死。"
    translate None leos_chapter2_0350:
        show leos nw sur with dis
        l "五分钟都离不开他？"
    translate None leos_chapter2_0351:
        i "这话从你嘴里说出来可真讽刺。"
    translate None leos_chapter2_0352:
        "莱奥斯紧握的手纹丝不动，两人剑拔弩张地对峙着，直到伊尔兰突然又对他咧嘴一笑。"
    translate None leos_chapter2_0353:
        show illran n hap with dis
        i "所以，你是打算开口说话，还是准备就这么站那儿瞪我一整天？"
    translate None leos_chapter2_0354:
        show leos nw thi with dis
        l "告诉我你的计划。我不会让你伤害雷恩的。"
    translate None leos_chapter2_0355:
        i "呃，其实我不太擅长制定计划。我更喜欢随遇而安。"
    translate None leos_chapter2_0356:
        "莱奥斯听到他的话眉头皱得更深了，脑海中思绪万千。"
    translate None leos_chapter2_0357:
        l "为什么我就是无法信任你？"
    translate None leos_chapter2_0358:
        show illran n neu with dis
        i "也许你没意识到，但我确实不是这附近最值得信赖的人。或者，也可能是你那根深蒂固的信任问题在作祟。"
    translate None leos_chapter2_0359:
        l "你总是拐弯抹角回答问题。就像之前在苋红森林那次。你为什么那么想了解我？"
    translate None leos_chapter2_0360:
        i "我只是有些怀疑需要证实，仅此而已。"
    translate None leos_chapter2_0361:
        show leos nw neu with dis
        l "跟我说实话。我是不是在哪儿见过你？"
    translate None leos_chapter2_0362:
        show illran n sad with dis
        i "...."
    translate None leos_chapter2_0363:
        i "哇哦，别告诉我这么快就被识破了啊？"
    translate None leos_chapter2_0364:
        l "果然如此！"
    translate None leos_chapter2_0365:
        i "谁知道呢。"
    translate None leos_chapter2_0366:
        "他挣脱莱奥斯的手腕，揉着上面留下的红印子。"
    translate None leos_chapter2_0367:
        i "哎哟。要是想吸引你家那个向日葵男孩，你可得学着温柔点儿。"
    translate None leos_chapter2_0368:
        i "照这样下去，他迟早会被别人抢走的。"
    translate None leos_chapter2_0369:
        show leos nw ann with dis
        l "为什么你从来不肯正面回答我的问题？！"
    translate None leos_chapter2_0370:
        show illran n ang with dis
        i "因为我没什么好回答的。你自己想明白吧。"
    translate None leos_chapter2_0371:
        "绿发男子转身要走，刚走出几步又回头瞥了一眼。"
    translate None leos_chapter2_0372:
        show illran n sad with dis
        i "嘿，至少…我现在跳房子稍微厉害点儿了。"
    translate None leos_chapter2_0373:
        show leos nw sur with dis
        l "什么…？等等！"
    translate None leos_chapter2_0374:
        hide illran with dissolve
        show leos at center with move
        lmn "该死。他消失了。"
    translate None leos_chapter2_0375:
        lmn "不可能是他的，对吧？他死了。很多年前就死了，我确定。"
    translate None leos_chapter2_0376:
        lmn "可是…当我看着他时，我的信念又动摇了。"
    translate None leos_chapter2_0377:
        stop music fadeout 2.0
        lmn "伊尔兰…是你吗？" ##

    window hide dissolve

    scene bg sc sunset with Fade(1.0, 1.0, 1.0):
        xpos 0.28 ypos 1.39 xanchor 0.5 yanchor 1.0 zoom 1.45
        linear 25.0 xpos 0.72 ypos 1.39 xanchor 0.5 yanchor 1.0 zoom 1.45
    window show dissolve
    translate None leos_chapter2_0378:
        rs c wsad "哈啊…"
    translate None leos_chapter2_0379:
        play music "sounds/bgm/sad.ogg" fadein 3.0
        "我百无聊赖地踢着地上灰扑扑的半融积雪。"
    translate None leos_chapter2_0380:
        "等莱奥斯真是够呛。谁知道他要磨蹭多久。"
    translate None leos_chapter2_0381:
        "…也许我该直接回房间。让他自个儿找我。给他个教训。"
    translate None leos_chapter2_0382:
        "或者…既然大家都在忙自己的事，也许我该自己去找卡斯皮安。"
    translate None leos_chapter2_0383:
        scene bg sc sunset
        show veras n sunset o1 smi1 at slightleft
        show raen nw sunset cloak sur at slightright
        with dissolve
        v "雷恩。"
    translate None leos_chapter2_0384:
        rs "维拉斯？你怎么在这儿？"
    translate None leos_chapter2_0385:
        v "来聊聊呗，反正伊尔兰正忙着应付莱奥斯。"
    translate None leos_chapter2_0386:
        show raen nw sunset sad with dis
        rs "所以他最终还是找到他了…"
    translate None leos_chapter2_0387:
        show veras n sunset sur1 with dis
        v "你听起来情绪低落。出什么事了吗？"
    translate None leos_chapter2_0388:
        rs "嗯…没什么特别的…"
    translate None leos_chapter2_0389:
        v "但有什么事压在你心头。我们何不聊一会儿？"
    translate None leos_chapter2_0390:
        show raen nw sunset sur with dis
        rs "真的可以吗？不会麻烦你吗？"
    translate None leos_chapter2_0391:
        show veras n sunset smi1 with dis
        v "随时奉陪。我自认是个不错的倾听者。"
    translate None leos_chapter2_0392:
        show raen nw sunset sad with dis
        rs "嗯…我只是很郁闷莱奥斯从不依赖我。就像他不信任我能走近他似的。"
    translate None leos_chapter2_0393:
        rs "不过很明显他不会…我只是个没用的无名小卒。"
    translate None leos_chapter2_0394:
        "维拉斯平静地摇头，将手搭在我肩上。"
    translate None leos_chapter2_0395:
        v "万物皆有其用，雷恩。或许只是你自己没能看见。"
    translate None leos_chapter2_0396:
        rs "也是…"
    translate None leos_chapter2_0397:
        show veras n sunset sad1 with dis
        v "我确信莱奥斯信任你。真心这么认为。更像是…他太沉浸在自己的世界里，根本没想过依赖别人。"
    translate None leos_chapter2_0398:
        v "仿佛依靠他人获得支持对他来说根本不在考虑范围内。"
    translate None leos_chapter2_0399:
        show raen nw sunset sur with dis
        rs "是吗？"
    translate None leos_chapter2_0400:
        v "真的。他绝对在乎你。否则为何对你如此维护？"
    translate None leos_chapter2_0401:
        rs "...."
    translate None leos_chapter2_0402:
        show raen nw sunset sad with dis
        rs "可能因为我们成长环境不同，但我从小就被教育要依靠身边的人。"
    translate None leos_chapter2_0403:
        v "或许他接受的是相反的教育。认为依赖他人是软弱的表现。"
    translate None leos_chapter2_0404:
        rs "听你这么一说…我对他的童年一无所知。见鬼，我连遇见他之前的生活都不清楚。"
    translate None leos_chapter2_0405:
        rs "我根本不了解他…"
    translate None leos_chapter2_0406:
        v "我怀疑刺客的成长经历不会太美好。从小就明白必须杀死身边的人，想想就痛苦。"
    translate None leos_chapter2_0407:
        rs "…若我们年龄再接近些，说不定能早点相遇。不知道我们会不会成为朋友.."
    translate None leos_chapter2_0408:
        show veras n sunset smi1 with dis
        v "何不试着更了解他？"
    translate None leos_chapter2_0409:
        rs "不知道该怎么..我怕他又会推开我。"
    translate None leos_chapter2_0410:
        v "从小事开始。他喜欢的食物，最珍藏的回忆。什么都行。"
    translate None leos_chapter2_0411:
        stop music fadeout 2.0
        l c wthi "我不是让你在面包店等着吗。"
    translate None leos_chapter2_0412:
        show raen nw sunset sur with hpunch
        rs "啊！"
    translate None leos_chapter2_0413:
        "我吓得跳起来，转身看见莱奥斯。"
    translate None leos_chapter2_0414:
        show raen at right
        show veras at center
        with move
        show leos nw sunset neu blush cloak at left with dissolve
        play music "sounds/bgm/night.ogg" fadein 3.0
        "他像凭空出现般朝我们跑来，神色慌张。看来他刚才肯定到处在找我。"
    translate None leos_chapter2_0415:
        rs "扎林想让我看看索伦。"
    translate None leos_chapter2_0416:
        l "哦…他现在状况如何？"
    translate None leos_chapter2_0417:
        show raen nw sunset sad blush with dis
        "跟我来不就知道了…"
    translate None leos_chapter2_0418:
        rs "…好吧。体征平稳，但还在昏迷。"
    translate None leos_chapter2_0419:
        l "这样反而安全些。他们会想办法救他。"
    translate None leos_chapter2_0420:
        show veras n sunset sur1 with dis
        v "啊…现在我明白了。"
    translate None leos_chapter2_0421:
        l "明白什么？"
    translate None leos_chapter2_0422:
        show veras n sunset smi1 with dis
        v "没关系。我想我该告辞了。雷恩，很高兴和你聊天，虽然时间很短暂。"
    translate None leos_chapter2_0423:
        hide veras with dissolve
        show raen at slightright
        show leos at slightleft
        with move
        "他微笑着挥手告别，转身去寻找伊尔兰。"
    translate None leos_chapter2_0424:
        "…他真的很了不起。那么聪明，那么强大，那么善良…我希望能像他一样。"
    translate None leos_chapter2_0425:
        show leos nw sunset sur with dis
        l "你本应该在屋里等的。外面冷死了。"
    translate None leos_chapter2_0426:
        rs "我暖和着呢。所以…你和伊尔兰聊了什么？"
    translate None leos_chapter2_0427:
        l "没什么，别担心。"
    translate None leos_chapter2_0428:
        show raen nw sunset neu -blush with dis
        rs "....."
    translate None leos_chapter2_0429:
        l "说真的，我只是想问个问题。没什么大不了的。"
    translate None leos_chapter2_0430:
        show raen nw sunset sad with dis
        rs "....."
    translate None leos_chapter2_0431:
        show leos nw sunset neu -blush with dis
        l "…我们不如去找其他人，开始寻找你那位失踪的王子？"
    translate None leos_chapter2_0432:
        "听到他的话，我感到脸部肌肉绷紧，一种难以名状的感觉压在胸口—沉重而纹丝不动。"
    translate None leos_chapter2_0433:
        "为什么？为什么我不想去寻找他，这明明正是我来此的目的？"
    translate None leos_chapter2_0434:
        "只是…这些感觉到底是什么？"
    translate None leos_chapter2_0435:
        "我想和莱奥斯待在一起，聊聊我们从未能畅谈的一切。"
    translate None leos_chapter2_0436:
        "我想熬到深夜，当月光是房间里唯一的光源时，了解关于他的一切。"
    translate None leos_chapter2_0437:
        "了解他不敢谈论的一切，以及他永远不敢对任何人启齿的一切。"
    translate None leos_chapter2_0438:
        "呃…我到底怎么了？"
    translate None leos_chapter2_0439:
        l "喂，雷恩？"
    translate None leos_chapter2_0440:
        "我病了吗？就是这样吗？"
    translate None leos_chapter2_0441:
        "我没感觉特别不舒服啊…"
    translate None leos_chapter2_0442:
        show leos nw sunset thi with dis
        l "喂—有人在听吗？"
    translate None leos_chapter2_0443:
        show raen nw sur with dis
        "这个声音让我猛地后退。莱奥斯俯身向前，困惑地注视着我的脸，直到我们的目光相遇。"
    translate None leos_chapter2_0444:
        show raen nw sunset sad blush with dis
        "我的脸开始发烫，莱奥斯睁大了眼睛，随即退后一步，不自在地摸着后颈。"
    translate None leos_chapter2_0445:
        rs "对…对不起…呃，其实…我们能聊聊吗？"
    translate None leos_chapter2_0446:
        show leos nw sunset sur with dis
        l "聊聊？"
    translate None leos_chapter2_0447:
        "我点头回应他的问题，内心充满自我怀疑。"
    translate None leos_chapter2_0448:
        "他不会想和我说话的，对吧？"
    translate None leos_chapter2_0449:
        l "我们真的没时间—"
    translate None leos_chapter2_0450:
        "啊…果然。他真的不想和我这种人说话。"
    translate None leos_chapter2_0451:
        l "....."
    translate None leos_chapter2_0452:
        show leos nw sunset neu blush with dis
        l "…好吧，好吧，行。我们可以聊聊，如果这能让你高兴的话。"
    translate None leos_chapter2_0453:
        rs "能去我房间吗？"


    scene bg sc sunset with dissolve:
        xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.48
        linear 20.0 xpos 0.5 ypos 1.48 xanchor 0.5 yanchor 1.0 zoom 1.48
    translate None leos_chapter2_0454:
        "他点点头，领着我穿过街道返回银柳。他不时用余光瞥我，但一旦被我察觉就迅速移开视线。"
    translate None leos_chapter2_0455:
        "当我们转过最后一个拐角，两张熟悉的面孔映入眼帘。"
    translate None leos_chapter2_0456:
        c c wsur "哇，他们在那里！"
    translate None leos_chapter2_0457:
        rs c wsur "你们去哪儿了？"
    translate None leos_chapter2_0458:
        f c wsad "呃…"
    translate None leos_chapter2_0459:
        c c wsmi "哦你知道的，没去什么特别的地方。我的好朋友福恩看起来需要振作一下，仅此而已。"
    translate None leos_chapter2_0460:
        "他们也不肯告诉我任何事…"
    translate None leos_chapter2_0461:
        l c wthi "...."
    translate None leos_chapter2_0462:
        "突然莱奥斯拉住我的手腕，他修长的手指缠绕着我，把我拉到身后远离其他人。"
    translate None leos_chapter2_0463:
        rs "喂…喂，你要干什么？！"
    translate None leos_chapter2_0464:
        l "你说想和我说话，不是和他们。"
    translate None leos_chapter2_0465:
        c c wsur "…啧啧，他变得这么主动了。"
    translate None leos_chapter2_0466:
        f "....."
    translate None leos_chapter2_0467:
        "一言不发地把其他人抛在身后，我们走进了银柳。"

    window hide dissolve

    scene bg swroom night
    show raen mw dark sad at mright
    show leos mw dark neu at mleft
    with dissolve
    window show dissolve
    translate None leos_chapter2_0468:
        rs "…他们不会觉得这样很失礼吗？"
    translate None leos_chapter2_0469:
        l "如果他们到现在都没发现我很无礼，那就是他们的问题了。"
    translate None leos_chapter2_0470:
        rs "...."
    translate None leos_chapter2_0471:
        "门在我们身后轻轻关上了，四周陷入寂静。"
    translate None leos_chapter2_0472:
        "我该从何说起…维拉斯说过什么来着…？"
    translate None leos_chapter2_0473:
        "我的靴子踩在凉爽的石地板上咔咔作响，我在房间里踱步后坐在床上。双手不知所措地搭在膝上。"
    translate None leos_chapter2_0474:
        "外面，太阳已经落下了锡德卡汉的山头。我整天都和所有人在一起，除了我最想陪伴的人。"
    translate None leos_chapter2_0475:
        "…但现在是我的机会。天知道下次要等到什么时候。"
    translate None leos_chapter2_0476:
        rs "…嗯…莱奥斯，你最喜欢吃什么？"
    translate None leos_chapter2_0477:
        show leos mw dark sur with dis
        l "什么？天哪，希望你不是认真的。你该不会真的为这种问题耽误了我们的搜寻吧？"
    translate None leos_chapter2_0478:
        rs "...."
    translate None leos_chapter2_0479:
        l "你是认真的。太好了。"
    translate None leos_chapter2_0480:
        rs "…我感觉我一点儿都不了解你。这让我觉得…怪怪的。"
    translate None leos_chapter2_0481:
        l "怪怪的？"
    translate None leos_chapter2_0482:
        rs "我不知道！我也不明白！"
    translate None leos_chapter2_0483:
        l "你对我一无所知反而更好。等我离开后，对你更安全。"
    translate None leos_chapter2_0484:
        "等我离开\"，他说…"
    translate None leos_chapter2_0485:
        rs "我不在乎什么对我更安全。我…我只是想感觉我们是平等的…"
    translate None leos_chapter2_0486:
        rs "你几乎知道我的一切，却仍然与我保持距离。为什么我就不能也了解你呢？"
    translate None leos_chapter2_0487:
        show leos mw neu dark blush with dis
        l "…我不擅长谈论自己。"
    translate None leos_chapter2_0488:
        show raen mw neu dark with dis
        rs "我…我很有耐心，也是个好听众，我保证…"

    show leos mw dark thi with dis

    if achievement.has("leos_macaron"):
        pass
    else:
        $ renpy.display_notify("成就解锁：马卡龙")

    python:
        achievement.grant("leos_macaron")
        achievement.sync()
    translate None leos_chapter2_0489:
        l "我喜欢马卡龙。"
    translate None leos_chapter2_0490:
        show raen mw dark sur blush with dis
        rs "我…什么？"
    translate None leos_chapter2_0491:
        l "哪个部分让你困惑？"
    translate None leos_chapter2_0492:
        rs "甜食？真让人意外。"
    translate None leos_chapter2_0493:
        l "怎么？我不配喜欢甜食吗？"
    translate None leos_chapter2_0494:
        rs "我只是没料到会这样，仅此而已。我从未品尝过这些点心，但记得在家乡的面包店橱窗里见过它们。"
    translate None leos_chapter2_0495:
        l "…小时候我只尝过那么一次。"
    translate None leos_chapter2_0496:
        rs "是什么阻止你再次尝试呢？"
    translate None leos_chapter2_0497:
        l "…不知道，可能是害怕它们无法达到记忆中的美味。"
    translate None leos_chapter2_0498:
        show raen mw dark neu with dis
        rs "或许有天我们可以一起品尝。"
    translate None leos_chapter2_0499:
        show leos mw dark sur with dis
        l "...."
    translate None leos_chapter2_0500:
        "他静静地在我床边坐下。"
    translate None leos_chapter2_0501:
        l "你就只想知道这个？随时都可以问我啊。"
    translate None leos_chapter2_0502:
        show raen mw dark sur with dis
        rs "那我能问更多问题吗？"
    translate None leos_chapter2_0503:
        l "尽管问吧。今天也做不成其他事了。"
    translate None leos_chapter2_0504:
        rs "…你这些伤痕是怎么来的？"
    translate None leos_chapter2_0505:
        show leos mw dark smu -blush with dis
        l "我的伤疤？嗯…这道是在刀战中留下的。"
    translate None leos_chapter2_0506:
        "他指着胳膊上的白色疤痕，始终带着笑意。"
    translate None leos_chapter2_0507:
        l "当然是我赢了，但毫发无伤地回家多没面子对吧？这真的只是小擦伤。"
    translate None leos_chapter2_0508:
        rs "那你背上的呢？"
    translate None leos_chapter2_0509:
        show leos mw dark neu with dis
        l "哦…那些…是犯错时挨鞭子留下的。"
    translate None leos_chapter2_0510:
        show raen mw dark sad -blush with dis
        rs "什么？你…犯错就要被鞭打…？"
    translate None leos_chapter2_0511:
        l "说真的，我该庆幸伤疤不算多。这是让孩子快速成长的必修课。"
    translate None leos_chapter2_0512:
        rs "太…太残忍了…"
    translate None leos_chapter2_0513:
        l "也没那么糟。习惯就好。"
    translate None leos_chapter2_0514:
        "我都不敢继续问…但是…"
    translate None leos_chapter2_0515:
        rs "…你的童年到底是怎样的？"
    translate None leos_chapter2_0516:
        "他死死盯着地面，像是要把地板灼穿。"
    translate None leos_chapter2_0517:
        rs "实在不想说可以不说。"
    translate None leos_chapter2_0518:
        show leos mw dark sur with dis
        l "不..没关系。我…出生在刺客世家。虽不多见，但我们族人都被赐予相同的审判。"
    translate None leos_chapter2_0519:
        l "嗯..想来也不稀奇—那些获得不同审判的家族新生儿，都会被立即抛弃。"
    translate None leos_chapter2_0520:
        rs "太过分了…"
    translate None leos_chapter2_0521:
        l "这就是人生。至死方休的残酷。所以…我的父母、祖父母，所有亲戚—我认识的人都这样。"
    translate None leos_chapter2_0522:
        l "当你被这种环境包围时，根本想象不出别的生活。"
    translate None leos_chapter2_0523:
        "从一开始，我们就如此不同…"
    translate None leos_chapter2_0524:
        rs "…至少，你还能依靠家人吗？"
    translate None leos_chapter2_0525:
        l "....."
    translate None leos_chapter2_0526:
        l "我从来都是独自一人。过去是，以为永远都会是。童年大部分时间都被关在狭小的房间里。"
    translate None leos_chapter2_0527:
        l "我开始怀疑那四面墙之外是否真的存在任何事物。"
    translate None leos_chapter2_0528:
        rs "为什么要那样对你？！"
    translate None leos_chapter2_0529:
        l "…有几个原因。首先，这样我就不会对任何人产生依恋。甚至对我的父母也不例外。"
    translate None leos_chapter2_0530:
        l "所以…所以即使有人带着要我杀死自己家人的契约来找我，我也能不带着丝毫悔意地完成任务。"
    translate None leos_chapter2_0531:
        rs "….我…我甚至不知道该说什么。"
    translate None leos_chapter2_0532:
        show leos mw dark smu with dis
        l "不必同情我。没有那段独处的时光，我不会有现在这般精湛的技术。"
    translate None leos_chapter2_0533:
        rs "这…这不对…我真希望能做些什么来帮助你…"
    translate None leos_chapter2_0534:
        show leos mw dark neu with dis
        l "其实也没那么糟—好啦，你可以不用再做那个表情了。好吧…好吧，确实挺糟糕的。"
    translate None leos_chapter2_0535:
        l "当我最终被放出来时，接到的第一份工作就是夺取某个人的生命。他们脸上的表情将永远萦绕在我心头。"
    translate None leos_chapter2_0536:
        "我甚至完全无法与他产生共鸣…"
    translate None leos_chapter2_0537:
        show raen mw dark neu with dis
        rs "你后悔吗？"
    translate None leos_chapter2_0538:
        l "我不知道。我从未被给予后悔的选项。"
    translate None leos_chapter2_0539:
        show raen mw dark blush neu with dis
        rs "现在你有了。你已经不在那个家族了，你现在是和我一起在锡德卡汉。"
    translate None leos_chapter2_0540:
        show leos mw dark sur with dis
        l "....."
    translate None leos_chapter2_0541:
        show leos mw dark smu with dis
        "他的嘴几乎张成了完美的O型，随后伪装崩塌，发出了由衷的大笑。"
    translate None leos_chapter2_0542:
        l "这话说得真像你的风格。"
    translate None leos_chapter2_0543:
        show raen mw dark emb blush with dis
        rs "怎…怎么了，有什么问题吗？"
    translate None leos_chapter2_0544:
        l "不，不…你说得对。"
    translate None leos_chapter2_0545:
        "他擦去眼角泛起的泪水，笑得前所未有地开怀。那笑声充满了真挚的感情。"
    translate None leos_chapter2_0546:
        "我感到一阵心慌意乱，急忙移开视线。"
    translate None leos_chapter2_0547:
        "..为什么他总能让我产生这种感觉？"
    translate None leos_chapter2_0548:
        rs "我希望…希望你至少曾有过…一个朋友。"
    translate None leos_chapter2_0549:
        show leos mw dark neu with dis
        $ about_Leos._text = ["莱奥斯出生于奥雷利亚卡维拉的刺客世家。\n \n每一个人—他的父母、祖父母、所有家族成员，都背负着相同的审判。童年时期他大部分时间都在独处，犯错时会受到严厉惩罚。"]
        l "…有的…嗯，我确实有过{a=set_entry:enc_people->about_Leos}{color=#87CEEB}朋友{/color}{/a}。"
    translate None leos_chapter2_0550:
        rs "他是个怎样的人？"
    translate None leos_chapter2_0551:
        stop music fadeout 2.0
        l "嗯…"

    window hide dissolve

    scene black with Fade(1.0, 1.0, 1.0)
    pause 2.0
    window show dissolve
    translate None leos_chapter2_0552:
        "鞭子划过空气的声响。刀刃堪堪偏离目标的瞬间。冰凉金属接触肌肤的触感。"
    translate None leos_chapter2_0553:
        "那阴暗空荡的房间里，他度过了大半生。没错，万籁俱寂，却仿佛能感受到某种生命在呼吸—宛如独立的存在体，将他永远囚禁于此。"
    translate None leos_chapter2_0554:
        play music "sounds/bgm/forgotten off.ogg" fadein 3.0
        "红发少年睁开双眼，环顾四周。"
    translate None leos_chapter2_0555:
        "他沉思片刻。想着下次进食会是何时。下次见到阳光会是何时。父母是否很快会来探望。"
    translate None leos_chapter2_0556:
        "这些问题答案他心知肚明，内心却仍渴求更多。"
    translate None leos_chapter2_0557:
        "身下是铺在木地板上的薄毯—这就是他的床。盛夏尚可，严冬时他总觉得自己会冻死。"
    translate None leos_chapter2_0558:
        "但解脱之日迟迟未至。"
    translate None leos_chapter2_0559:
        "身旁地板上搁着皮革缠柄的刀。不远处矮桌边倚着一把弓。"
    translate None leos_chapter2_0560:
        "他紧握皮革刀柄，指节发白。唯有这触感能让他确信自己真实存活。"
    translate None leos_chapter2_0561:
        "角落里摆着箭靶与训练假人。"
    translate None leos_chapter2_0562:
        "手腕轻抖，利刃深深刺入假人的人造肌肤。这声响让他颅内泛起欢愉。"
    translate None leos_chapter2_0563:
        "但有时他怀疑这算不算真正的快乐。"
    translate None leos_chapter2_0564:
        "他猛然摇头，驱散这些念头。"
    translate None leos_chapter2_0565:
        lmn "{move}{sc=2}{color=#FFFF}这就是幸福。{/sc}{/move}"
    translate None leos_chapter2_0566:
        "从临时床铺起身，他走向假人轻松拔刀。假人身上早已布满无数刀孔，早该更换。"
    translate None leos_chapter2_0567:
        "当他扫视黑暗环境时，身体突然僵直。"
    translate None leos_chapter2_0568:
        "房门显得异常庞大，异常压抑。向来如此。"
    translate None leos_chapter2_0569:
        "可奇怪的是，此刻它竟透着诱惑。如同禁果。"
    translate None leos_chapter2_0570:
        "能穿过这扇门的声音屈指可数。母亲，父亲。一个素未谋面的兄弟。偶尔还有他最恐惧的阴森语调。"
    translate None leos_chapter2_0571:
        "那是说书人卢修斯的声音。"
    translate None leos_chapter2_0572:
        "明知门会如常锁死—他却被无形力量牵引，仿佛听见某种召唤。"
    translate None leos_chapter2_0573:
        "他伸手轻触门板，动作谨慎如惧伤害。"
    translate None leos_chapter2_0574:
        "门无声开启。门外空间寂静空旷。"
    translate None leos_chapter2_0575:
        "怀着满心恐惧，他踏出了第一步。"

    window hide dissolve

    scene bg aureliacavellanight
    show cleo n dark sur
    with dissolve
    window show dissolve
    translate None leos_chapter2_0576:
        l "...."
    translate None leos_chapter2_0577:
        "夜空中繁星点点，数目之多出乎他的想象。虽然夜色阴冷，但肌肤感受着久违的微风拂过。"
    translate None leos_chapter2_0578:
        "眼眶瞬间盈满了泪水，他却不敢发出声响。他知道一旦被发现，等待他的将是严厉的惩罚。"
    translate None leos_chapter2_0579:
        "迈出第一步后，之后便容易得多—他沿着黑暗的道路奔跑，见识了从未知晓的风景。"
    translate None leos_chapter2_0580:
        show cleo n dark hap with dis
        "目光所及皆是新奇事物。"
    translate None leos_chapter2_0581:
        "然而盘踞在胃底的深深恐惧始终挥之不去。"
    translate None leos_chapter2_0582:
        show cleo n dark neu2 with dis
        l "……再几分钟就好……"
    translate None leos_chapter2_0583:
        stop music fadeout 2.0
        show bg with hpunch
        show cleo at slightright with move
        show cil n dark sur at slightleft with dissolve
        u "哇！看着点路啊！" ### KID ILLRAN
    translate None leos_chapter2_0584:
        "当莱奥斯全力撞上那个小男孩时，对方吓得往后跳开。"
    translate None leos_chapter2_0585:
        "他看起来…看起来像是…"
    translate None leos_chapter2_0586:
        "……却怎么也想不起来。"
    translate None leos_chapter2_0587:
        "唯有那抹充满自信的笑容深深刻在记忆里。"
    translate None leos_chapter2_0588:
        l "对…对不起…"
    translate None leos_chapter2_0589:
        show cil n dark hap with dis
        u "什么？说大声点，你声音太小了。"
    translate None leos_chapter2_0590:
        show cleo n dark sad with dis
        l "我…对不…起…"
    translate None leos_chapter2_0591:
        show cil n dark neu with dis
        u "噢，你害怕吗？嘿没事的，不用道歉。我叫—"
    translate None leos_chapter2_0592:
        n "{move}{sc=2}{color=#FFFF}{i}{b}{size=50}他叫什么名字来着？{/i}{/b}{/sc}{/move}"
    translate None leos_chapter2_0593:
        l "我是…莱奥斯…"
    translate None leos_chapter2_0594:
        u "那么莱奥斯，你是迷路了吗？要我帮你找妈妈吗？"
    translate None leos_chapter2_0595:
        show cleo n dark sur with dis
        l "不要！"
    translate None leos_chapter2_0596:
        show cil n dark sur with dis
        u "...."
    translate None leos_chapter2_0597:
        l "我得…现在就得回家…！"
    translate None leos_chapter2_0598:
        u "等等—"
    translate None leos_chapter2_0599:
        hide cleo
        hide cil
        with dissolve
        play music "sounds/bgm/forgotten off.ogg" fadein 3.0
        "男孩转身就跑。他自己也不太明白为何如此。也许是害怕逗留太久会被发现，也许是恐惧与同龄人交谈—这从来都是被禁止的。"
    translate None leos_chapter2_0600:
        "又或许…是害怕那个审判终将应验。"
    translate None leos_chapter2_0601:
        scene black with dissolve
        "他一路狂奔回家。轻轻关上房门，飞快钻回被窝。"
    translate None leos_chapter2_0602:
        "接下来几天风平浪静。他没敢再碰那扇门，食物也照常送来，终于松开了不知何时屏住的呼吸。"
    translate None leos_chapter2_0603:
        "目光又一次落在那扇威严却充满诱惑的门上，思绪飘回那个萍水相逢的男孩。"
    translate None leos_chapter2_0604:
        "或许…如果一切不是这样，他们本可以成为朋友。"
    translate None leos_chapter2_0605:
        "他艰难地咽了口唾沫，手又摸回门把。还是没有上锁。"


    scene bg aureliacavellanight
    show cleo n dark neu1
    with dissolve
    translate None leos_chapter2_0606:
        "这次步伐轻松多了。自由的冲动如此美好，让他无法抗拒，他跑过黑暗的街道，回到几天前遇见那个男孩的地方。"
    translate None leos_chapter2_0607:
        "说实话，他并没指望能遇到任何人。"
    translate None leos_chapter2_0608:
        "但他遇到了。"
    translate None leos_chapter2_0609:
        show cleo at slightright with move
        show cil n dark win at slightleft with dissolve
        u "莱奥斯！" ### KID ILLRAN
    translate None leos_chapter2_0610:
        show cleo n dark sur with dis
        "他身边站着个墨绿色头发的女人，温柔地牵着他的手。她对男孩笑了笑，揉乱他的头发，让他去玩。"
    translate None leos_chapter2_0611:
        "她看他的眼神，以及他回望她的样子，正是莱奥斯一生都在渴望的。"
    translate None leos_chapter2_0612:
        show cleo n dark sad with dis
        "他不由得移开了视线。"
    translate None leos_chapter2_0613:
        u "嘿，莱奥斯！我在跟你说话呢！想去玩吗？" ### KID ILLRAN
    translate None leos_chapter2_0614:
        l "玩…玩？和我吗？"
    translate None leos_chapter2_0615:
        show cil n dark hap with dis
        u "对啊！妈妈说我们可以去。"
    translate None leos_chapter2_0616:
        show cleo n dark sur with dis
        l "...."
    translate None leos_chapter2_0617:
        show cleo n dark hap with dis
        l "好…好啊，我…我想去。"
    translate None leos_chapter2_0618:
        "莱奥斯与女人—他猜是男孩的母亲对视，她回以温暖的微笑，然后从包里掏出什么。"
    translate None leos_chapter2_0619:
        "她给两个男孩各递了一样东西—粉粉小小的，看起来很好吃。"
    translate None leos_chapter2_0620:
        "他想起了受过的训练—无缘无故给你东西的人是想利用你。"
    translate None leos_chapter2_0621:
        "给你食物的人是想毒死你。"
    translate None leos_chapter2_0622:
        "他咬了一口，甜蜜的滋味充满口腔。"
    translate None leos_chapter2_0623:
        u "好吃吧？我妈做的马卡龙最棒了。"
    translate None leos_chapter2_0624:
        "她挥挥手离开了，留下两个小男孩独处。"
    translate None leos_chapter2_0625:
        l "是…是很好吃…"
    translate None leos_chapter2_0626:
        u "对吧？走啦，我们去玩！"
    translate None leos_chapter2_0627:
        "他抓起莱奥斯的手就跑。"


    scene bg aureliacavellanight with dissolve:
        xpos 0.74 ypos 1.32 xanchor 0.5 yanchor 1.0 zoom 1.56
        linear 35.0 xpos 0.22 ypos 1.32 xanchor 0.5 yanchor 1.0 zoom 1.56
    translate None leos_chapter2_0628:
        "两人玩了一整夜—跑遍全镇。去风车磨坊和田野，去城堡和市集。"
    translate None leos_chapter2_0629:
        "那天回家时，莱奥斯满怀着一种说不清的感受，直到多年后他才明白那是什么—幸福。"
    translate None leos_chapter2_0630:
        "于是接下来的几个月，他都沉浸在这种无名的幸福中，每晚溜出去与男孩相会。"
    translate None leos_chapter2_0631:
        "他们很快成了形影不离的朋友。莱奥斯对自己的生活守口如瓶，所以当他展示飞刀技巧时，男孩更加好奇了。"
    translate None leos_chapter2_0632:
        "当然，这引发了场飞刀比赛，虽然男孩母亲不太赞成，但这也是乐趣的一部分。"
    translate None leos_chapter2_0633:
        "在一个特别的暴风雨之夜，莱奥斯又一次盯着那扇门。"
    translate None leos_chapter2_0634:
        "天气如此恶劣，他不太确定是否该再次尝试溜出去，但最终逃跑的欲望战胜了理智，不知不觉间他已站在了户外。"
    translate None leos_chapter2_0635:
        "他跑回到经常遇见另一个男孩的地方。他跑得就像在逃命一样。吹拂在肌肤上的风清爽宜人。"
    translate None leos_chapter2_0636:
        "但当他到达那个地点时，那里空无一人。"
    translate None leos_chapter2_0637:
        "他低头凝视脚下的一滩水洼。也许是夜色太暗，也许是他眼花了，但是…"
    translate None leos_chapter2_0638:
        "他确信水面被染成了红色。"
    translate None leos_chapter2_0639:
        "恐惧充斥着他的心脏，他猛然转身看到远处有个身影。"
    translate None leos_chapter2_0640:
        "当那个身影向他走来时，恐惧感渗透了他的全身。"
    translate None leos_chapter2_0641:
        stop music fadeout 2.0
        "是他的父母。"

    window hide dissolve

    scene bg swroom night
    show raen mw dark sur at mright
    show leos mw dark sur at mleft
    with Fade(1.0, 1.0, 1.0)
    window show dissolve
    translate None leos_chapter2_0642:
        rs "他们…难道是他…？"
    translate None leos_chapter2_0643:
        play music "sounds/bgm/sad.ogg" fadein 3.0
        l "…我不知道。我被扯着头发拖回家，被告知这就是我亲近任何人的后果。"
    translate None leos_chapter2_0644:
        show raen mw dark sad with dis
        rs "....."
    translate None leos_chapter2_0645:
        rs "莱奥斯，我…我不知道该说什么…"
    translate None leos_chapter2_0646:
        l "如果他死了，那就是我的错。我完全清楚与他相处会让他陷入危险。更不用说我的…我的审判…"
    translate None leos_chapter2_0647:
        "听到\"审判\"这个词时他瑟缩了一下，然后摇着头。当他的目光再次与我相遇时，眼里满是痛苦。"
    translate None leos_chapter2_0648:
        rs "他叫什么名字？"
    translate None leos_chapter2_0649:
        l "真希望我能记得。那时我还那么小…之后的岁月里我一直在强迫自己忘记这件事。"
    translate None leos_chapter2_0650:
        rs "…这不是你的错。这怎么能怪你呢？交朋友…不该为此受罚的。"
    translate None leos_chapter2_0651:
        l "..你现在明白为什么我不能留在你身边了吗？为什么我不希望你靠近我？同样的事会发生在你身上。"
    translate None leos_chapter2_0652:
        rs "不会的！我们…我们离家这么远…我不会让任何人再伤害你。"
    translate None leos_chapter2_0653:
        l "你不明白。"
    translate None leos_chapter2_0654:
        rs "我…"
    translate None leos_chapter2_0655:
        show leos mw dark neu with dis
        l "..你当然不明白。我还没告诉你原因。对不起，雷恩…不是我不信任你。我只是还没准备好谈这个。"
    translate None leos_chapter2_0656:
        "他的审判…为什么会给他带来如此多的痛苦？为什么他必须如此害怕亲近任何人？"
    translate None leos_chapter2_0657:
        "这不公平…"
    translate None leos_chapter2_0658:
        show raen mw dark neu with dis
        rs "…好的，我理解。"
    translate None leos_chapter2_0659:
        "天空早已变成深蓝色，我窗外的夜空中繁星点点。"
    translate None leos_chapter2_0660:
        "我的内心无法平静。我为莱奥斯心痛，为他失去的童年，为他被灌输的恐惧。"

    #window hide dissolve
    stop music fadeout 2.0

    #scene gallery_130 with dissolve
    #window show dissolve
    translate None leos_chapter2_0661:
        rs "我…我现在就在这里陪着你，等你准备好告诉我时，我依然会在。"
    translate None leos_chapter2_0662:
        "我紧紧地抱住莱奥斯。"
    translate None leos_chapter2_0663:
        play music "sounds/bgm/night.ogg" fadein 3.0
    #show leos mw dark smu with dis
        l "….谢谢，雷恩。我很感激。"
    translate None leos_chapter2_0664:
        rs "不，该我谢谢你信任我。"
    translate None leos_chapter2_0665:
        show leos mw dark thi with dis
        l "这没什么大不了的。我本该早点告诉你。"
    translate None leos_chapter2_0666:
        rs "但对我而言很重要。"
    translate None leos_chapter2_0667:
        show raen mw dark smi with dis
        l "天啊，你什么时候变得这么感性了？"
    translate None leos_chapter2_0668:
        show raen mw dark neu with dis
        rs "我不…我不知道，我自己也不明白。"
    translate None leos_chapter2_0669:
        l "...."
    translate None leos_chapter2_0670:
        l "天色已晚。我该回自己房间了。"
    translate None leos_chapter2_0671:
        rs "什么…？"
    translate None leos_chapter2_0672:
        l "过去几晚你都好好的。记得锁好门，我保证如果发生任何事都会立刻赶来。"
    translate None leos_chapter2_0673:
        show raen mw dark sad with dis
        "我将他搂得更紧，思绪开始混乱。我到底想从他那里得到什么？为何如此渴望争执？"
    translate None leos_chapter2_0674:
        rs "请不要走。"
    translate None leos_chapter2_0675:
        show leos mw dark smu with dis
        l "连一刻都离不开我吗？"
    translate None leos_chapter2_0676:
        rs "....."
    translate None leos_chapter2_0677:
        show leos mw dark neu with dis
        l "…可是说真的，为什么？你明明没问题的。"
    translate None leos_chapter2_0678:
        rs "我不知道…我一直在想，却始终想不明白。我只是…不想你去任何地方。这是唯一能确定的。"
    translate None leos_chapter2_0679:
        l "...."
    translate None leos_chapter2_0680:
        l "好吧…仅此最后一次，好吗？别变得太依赖我。"
    translate None leos_chapter2_0681:
        rs "我不介意…反正我只想待在你身边。"
    translate None leos_chapter2_0682:
        rs "还有，莱奥斯…那个…我相信你的朋友从未后悔与你共度的时光…所以别再自责了。"
    translate None leos_chapter2_0683:
        l "…你开始说胡话了。来吧，该睡了。"
    translate None leos_chapter2_0684:
        rs "我累坏了…"
    translate None leos_chapter2_0685:
        l "明天还有重要的事。快从我身上下来。"
    translate None leos_chapter2_0686:
        hide raen
        hide leos
        with dissolve
        "叹了口气，我松开他，重重倒向床铺。"
    translate None leos_chapter2_0687:
        "他尴尬地揉着后颈，盯着我身旁的空位。"
    translate None leos_chapter2_0688:
        rs wneu "还等什么？过来啊。"
    translate None leos_chapter2_0689:
        "我拍着床铺示意，他终于妥协躺到我身边。"
    translate None leos_chapter2_0690:
        "不知为何，注视着他让我感到安心，眼皮越来越沉，最终彻底陷入黑暗。"

    stop music fadeout 2.0
    window hide dissolve

    scene black with eye_shut
    pause 2.0
    scene bg swroom night with eye_open:
        xpos 0.32 ypos 1.15 xanchor 0.5 yanchor 1.0 zoom 1.51
    window show dissolve
    translate None leos_chapter2_0691:
        l wneu"......"
    translate None leos_chapter2_0692:
        play music "sounds/bgm/sad.ogg" fadein 3.0
        "莱奥斯睁开布满疲惫的双眼。他已精疲力竭，却仍有几个让他无法入睡的理由。"
    translate None leos_chapter2_0693:
        "第一个原因。"
    translate None leos_chapter2_0694:
        "自从离开奥雷利亚卡维拉，他的噩梦就越来越严重—严重到需要几个小时才能入睡，而入睡后，迎接他的又是他宁愿忘却的记忆。"
    translate None leos_chapter2_0695:
        "他在心里嘲笑自己。"
    translate None leos_chapter2_0696:
        lmn "他们总说我早晨状态差…"
    translate None leos_chapter2_0697:
        "但第二个原因，却是他自己也说不清的。"
    translate None leos_chapter2_0698:
        "他的目光转向身侧，久久停留在那个熟睡的年轻人身上。 "
    translate None leos_chapter2_0699:
        "雷恩。"
    translate None leos_chapter2_0700:
        "他的视线不由自主地在他身上游移，流连于他的眼睛、鼻子、嘴唇…"
    translate None leos_chapter2_0701:
        "而自从睡在他身旁，他的梦境大多归于至寂。仿佛那些困扰他的梦魇，都被某个如此…"
    translate None leos_chapter2_0702:
        "所以…"
    translate None leos_chapter2_0703:
        "如此什么？"
    translate None leos_chapter2_0704:
        "恼人的？无用的？"
    translate None leos_chapter2_0705:
        "不…是被某个如此温柔的人给吓跑了。"
    translate None leos_chapter2_0706:
        "这才是最让他困惑的。那人有时确实恼人又无能吗？没错，但还有别的…"
    translate None leos_chapter2_0707:
        "某种牵动莱奥斯心弦的东西，让他再也不愿离开。"
    translate None leos_chapter2_0708:
        "而这种感觉令他恐惧。"
    translate None leos_chapter2_0709:
        "这违背了他所有的信仰。"
    translate None leos_chapter2_0710:
        "神圣演说者为他铺就的道路原本如同一道直线。"
    translate None leos_chapter2_0711:
        "从A点到B点，这就是他的人生。"
    translate None leos_chapter2_0712:
        "但现在…那条路似乎已经偏离，眼前出现了无数岔路。 "
    translate None leos_chapter2_0713:
        "他该去向何方？C点？D点？谁能做出抉择？"
    translate None leos_chapter2_0714:
        "正当思绪混乱时，他听到雷恩在一旁翻身，突然明白该走哪条路其实显而易见。"
    translate None leos_chapter2_0715:
        "但他没有勇气踏出那一步。"
    translate None leos_chapter2_0716:
        "上次他亲近某个人时，对方就死了。无论他去往何处，死亡如影随形。"
    translate None leos_chapter2_0717:
        "正如他的审判所宣判的那样。他注定孤独终老，这是事实。"
    translate None leos_chapter2_0718:
        "…真是如此吗？ "
    translate None leos_chapter2_0719:
        "说书人对外界只字未提。或许，如果这点他都错了，那他对莱奥斯的判断也可能是错的。"
    translate None leos_chapter2_0720:
        "或许…从一开始他就拥有选择，只是不敢承认。"
    translate None leos_chapter2_0721:
        lmn "…但这一切都取决于他是否在说谎。如果他真能与众神对话，如果我们的命运早已注定，那么…"
    translate None leos_chapter2_0722:
        lmn "那么除了离开他，我别无选择。我不能让他陷入比他自己招致的更危险的境地。"
    translate None leos_chapter2_0723:
        lmn "呃..我变得越来越心软了。这完全不像我。"
    translate None leos_chapter2_0724:
        "他不假思索地伸出手，玩弄起雷恩的一缕头发。他的脸微微皱起，随后又舒展开来。"
    translate None leos_chapter2_0725:
        lmn "真可爱。"
    translate None leos_chapter2_0726:
        lmn "什么，可爱？他才不可爱…"
    translate None leos_chapter2_0727:
        lmn "我一定是哪里不对劲了。"
    translate None leos_chapter2_0728:
        stop music
        play sound "sounds/sfx/heartbeat.ogg"
        n "你的猎物就在那儿。还睡得很沉。他甚至不会知道发生了什么。"
    translate None leos_chapter2_0729:
        l whur "...!"
    translate None leos_chapter2_0730:
        play sound "sounds/sfx/heartbeat.ogg"
    translate None leos_chapter2_0731:
        n "你从没搞砸过任务。杀了他，然后回奥雷利亚卡维拉去。"
    translate None leos_chapter2_0732:
        l "不…不，我不会…"
    translate None leos_chapter2_0733:
        "他放开雷恩，抓起一把被遗落的匕首，在房间里疯狂挥舞，拼命寻找那个声音的主人。"
    translate None leos_chapter2_0734:
        "…但寂静无声。"
    translate None leos_chapter2_0735:
        "他从原地跳起来，蹑手蹑脚走到门前。依然锁着。"
    translate None leos_chapter2_0736:
        "他的拳头在身侧攥紧。"
    translate None leos_chapter2_0737:
        play music "sounds/bgm/sad.ogg" fadein 3.0
        lmn "我以为我已经改变了…我想要改变…"
    translate None leos_chapter2_0738:
        lmn "谁都行，除了雷恩…"
    translate None leos_chapter2_0739:
        "在脑海里，他仿佛听见有人在嘲笑他，但那里空无一人。"
    translate None leos_chapter2_0740:
        "手腕一抖，他将匕首掷向房间角落—那里在他心中仍留有靶子的阴影—而后立即感到后悔。"
    translate None leos_chapter2_0741:
        "那儿根本没有什么靶子。这里不是奥雷利亚卡维拉，是锡德卡汉。"
    translate None leos_chapter2_0742:
        lmn "好吧，赛恩可以赔偿损失，我想。这是他唯一擅长的事。"
    translate None leos_chapter2_0743:
        "他从墙上拔出匕首—现在它看起来不那么完美无缺了—又瘫倒在雷恩身边的床上。"
    translate None leos_chapter2_0744:
        "正如他所想，手握武器让他感到最安心。"
    translate None leos_chapter2_0745:
        scene black with eye_shut
        "他闭上眼睛，仍紧紧握着皮革包裹的刀柄。"
    translate None leos_chapter2_0746:
        u "好吧，你玩匕首确实很在行！但是，总该有我擅长的东西吧。" ### KID ILLRAN
    translate None leos_chapter2_0747:
        stop music fadeout 3.0
        u "哦，哦！我知道了，我们来玩跳房子吧！"

    window hide dissolve

    pause 1.0

    jump leosroute3




    #
