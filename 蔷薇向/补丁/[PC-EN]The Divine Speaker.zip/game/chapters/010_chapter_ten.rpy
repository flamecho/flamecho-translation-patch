label choice_fifteen_done:
    translate None chapter_ten_0001:
        rs "那就这么决定了。我们只需要消磨时间等到晚上。"
    show leos n dim smi with dis
    translate None chapter_ten_0002:
        l "我还是觉得这是个馊主意。我是说，你提出来的能有什么好主意？"
    show raen n dim sad with dis
    translate None chapter_ten_0003:
        rs "喂…"
    translate None chapter_ten_0004:
        c "有这么大个强壮的男性保护我们，肯定没问题的！"
    translate None chapter_ten_0005:
        l "不久前你还说我像面条一样软弱。我既没义务也不想帮你。"
    show cyne n dim neu with dis
    translate None chapter_ten_0006:
        c "义务？这种说法真有趣。"
    translate None chapter_ten_0007:
        c "我很好奇像你这样的人怎么会欠雷恩那种人的人情！"
    show leos n dim ang with dis
    translate None chapter_ten_0008:
        l "…..不关你的事。"
    show cyne n dim sur with dis
    translate None chapter_ten_0009:
        c "那我们的小福恩怎么办？你也会保护他吗，还是这份守护只留给你那位棕发美人？"
    translate None chapter_ten_0010:
        l "每次你一开口都让我内心死掉一点点。"
    translate None chapter_ten_0011:
        rs "我觉得玩笑开得够多了…"
    translate None chapter_ten_0012:
        f "在那之前我们做些什么…？"
    show cyne n dim mis with dis
    translate None chapter_ten_0013:
        c "吃午饭怎么样？我请客。"
    show raen n dim sur with dis
    translate None chapter_ten_0014:
        rs "呃，我确实饿坏了…"
    translate None chapter_ten_0015:
        c "那就这么定了！跟我来。"

    scene bg ox alley with dissolve:
        xpos 0.5 ypos 1.0 xanchor 0.44 yanchor 1.0 zoom 2.0
        linear 50.0 yanchor 0.5

    translate None chapter_ten_0016:
        "赛恩转身就领头带路，没有丝毫犹豫。他的自信令人震惊…"
    translate None chapter_ten_0017:
        "我还没来得及迈步，福恩就抓住了我的手臂。"
    translate None chapter_ten_0018:
        f sad "雷恩…"
    translate None chapter_ten_0019:
        f "我…不确定这是不是个好主意…"
    translate None chapter_ten_0020:
        l neu "同意。"
    translate None chapter_ten_0021:
        rs sad "什么意思？"
    translate None chapter_ten_0022:
        f neu "你得小心欠谁的人情。我们接受他太多恩惠了，却没法回报。"

    $ about_Cyne._text.append("莱奥斯和福恩对他突如其来的热情有些担忧。我觉得他可能就是个好人，但他们确信他是冲我来的。")
    translate None chapter_ten_0023:
        l ang "{a=set_entry:enc_people->about_Cyne}{color=#87CEEB}他对我们有所企图。{/color}{/a}"
    translate None chapter_ten_0024:
        rs sur "你这么觉得？他不就是比较热情吗？"
    translate None chapter_ten_0025:
        l pen "不，他另有所图。我觉得他比表现出来的要精明得多。"
    translate None chapter_ten_0026:
        rs sad "嗯…"
    translate None chapter_ten_0027:
        rs "唉..可我实在饿得不行了。你们俩不饿吗？"
    translate None chapter_ten_0028:
        f sad "呃…饿啊…"
    stop music fadeout 3.0
    translate None chapter_ten_0029:
        c hap "快—点—啊，慢—吞—吞—的！照这速度我们还没走到街上我就要饿死了。"
    translate None chapter_ten_0030:
        rs sur "啊，来啦！"
    play music "sounds/bgm/Discovery.ogg" fadein 2.0
    translate None chapter_ten_0031:
        rs sad "暂且先跟他去吃吧。关于他的事我们之后再想办法。"
    translate None chapter_ten_0032:
        rs neu "不过我确实认为他只是想帮忙。他有点怪，但人似乎不错。"
    translate None chapter_ten_0033:
        l ann "唉…"
    translate None chapter_ten_0034:
        l "你这榆木脑袋什么也听不进去。"

    scene bg oxhabor day with Dissolve(1):
        xanchor 0.3 yanchor 0.43 zoom 2.0
    show cyne n dim neu at center with dis
    translate None chapter_ten_0035:
        "我们在赛恩身后追赶着，跟着他穿过奥克斯哈伯的街道，这时我开始注意到一些之前未曾留意的细节。"
    translate None chapter_ten_0036:
        "大多数树木都已枯死，几乎看不见任何绿色植物。与斯塔格威奇的古朴氛围相比，这里看起来更具工业气息。更冰冷。"
    translate None chapter_ten_0037:
        "听说这里是玻璃生产的避风港。感觉就像一座巨型工厂。"
    translate None chapter_ten_0038:
        rs sur "我们要去哪里吃饭？我快饿死了。"
    translate None chapter_ten_0039:
        c "我知道一个不错的小地方。希望那里的人比我们遇到的其他人热情些。"
    translate None chapter_ten_0040:
        l cur "这要求不算高。"
    translate None chapter_ten_0041:
        f sad "这里的人…他们不太友善。"
    translate None chapter_ten_0042:
        c "我们可以边吃午饭边聊，快点。"

    scene bg oxhabor day with Dissolve(1)
    translate None chapter_ten_0043:
        "赛恩催促我们重回主街道。街上依旧空无一人。"
    translate None chapter_ten_0044:
        "这里看起来如此荒凉，很难想象真的有人居住。"
    translate None chapter_ten_0045:
        c hap "我们到了！"
    translate None chapter_ten_0046:
        "赛恩站立的门廊上方挂着一块写着\"灯塔\"的招牌。"
    translate None chapter_ten_0047:
        c hap "这是我最喜欢的地方！"
    translate None chapter_ten_0048:
        "当赛恩推开门时，我们都鱼贯而入。"

    play sound "dooropen3.ogg" fadeout 1.0
    window hide dissolve

    scene gallery_47 with dissolve:
        xpos 0.32 ypos 1.33 xanchor 0.5 yanchor 1.0 zoom 1.52
        linear 30.0 xpos 0.74 ypos 1.33 xanchor 0.5 yanchor 1.0 zoom 1.52
    window show dissolve
    translate None chapter_ten_0049:
        "几乎立刻，我们就被带到用隔板围起的僻静餐桌。在这里杀人恐怕都没人会注意到。"
    translate None chapter_ten_0050:
        "一切都一尘不染且奢华。看起来有点…"
    translate None chapter_ten_0051:
        rs "这地方似乎有点贵…"
    translate None chapter_ten_0052:
        c "啊，别担心那个。我不是说过午饭我请吗？"
    translate None chapter_ten_0053:
        "我能感受到莱奥斯和福恩投来的目光。是关于接受无法回报的馈赠这件事，对吧？"
    translate None chapter_ten_0054:
        "我觉得没问题。这顿饭后，我们就会分道扬镳，可能永远都不会再见了。他可能热情得有点过头，但看上去像是个好人。"
    translate None chapter_ten_0055:
        "只是吃顿午饭应该没什么大不了的。"
    translate None chapter_ten_0056:
        rs "那就谢谢你了。我们都饿坏了。"
    translate None chapter_ten_0057:
        rs "从昨天早上起我们就没吃过东西…"
    translate None chapter_ten_0058:
        c "不客气。你们知道的，我这人一向慷慨。只要能帮到你们。"
    translate None chapter_ten_0059:
        l ang "不，我们并不了解你。为什么要这么慷慨？"
    translate None chapter_ten_0060:
        "赛恩无视莱奥斯的疑问，挥手招来服务员。"
    translate None chapter_ten_0061:
        c "能现在给我们菜单吗？我们准备点餐了。"
    translate None chapter_ten_0062:
        wa "马上就来，赛恩先生。"
    translate None chapter_ten_0063:
        "莱奥斯警惕地审视着这番互动。"
    translate None chapter_ten_0064:
        l "哦，他们都认识你名字？还以为你不是本地人。"
    translate None chapter_ten_0065:
        c "我经常来这里。"
    translate None chapter_ten_0066:
        l "嗯。"
    translate None chapter_ten_0067:
        wa "您的专属菜单，先生。"
    scene gallery_47 with dissolve
    translate None chapter_ten_0068:
        c "谢谢。"
    translate None chapter_ten_0069:
        c "请随意点餐。毕竟这些菜品都是他们为我精心挑选的。"
    translate None chapter_ten_0070:
        "我浏览着菜单。上面的内容几乎像一门外语。我连一个认识的菜名都没有。"
    translate None chapter_ten_0071:
        "这些都是什么…？我看向福恩，他似乎也同样困惑。"
    translate None chapter_ten_0072:
        f sur "呃…这些都是什么啊？"
    translate None chapter_ten_0073:
        c "什么意思？这就是菜单啊。"
    translate None chapter_ten_0074:
        f sad "我…我从来没听说过这些菜。"
    translate None chapter_ten_0075:
        c "什么，认真的吗？你是在谷仓里长大的还是怎么着？"
    translate None chapter_ten_0076:
        c "哦，等等。"
    translate None chapter_ten_0077:
        c "你是个森林男孩，是吧。那你们两个呢？"
    translate None chapter_ten_0078:
        rs "呃…是啊，我也从没尝过这些。听都没听说过。"
    translate None chapter_ten_0079:
        rs "莱奥斯？"
    translate None chapter_ten_0080:
        l pen "......"
    translate None chapter_ten_0081:
        l "我也一样。"
    translate None chapter_ten_0082:
        c "好吧，请原谅我的失礼。要不我来点几道菜，大家可以一起分享？"
    translate None chapter_ten_0083:
        rs "听起来很棒。"
    translate None chapter_ten_0084:
        "他招手叫来服务员，为我们所有人选了几道菜。一看就知道他经常这么做。"
    translate None chapter_ten_0085:
        "他平时说话很随意，但和服务员讲话时语气会有微妙变化。就像…带着几分威仪。"
    translate None chapter_ten_0086:
        "而且服务员对他百依百顺。这种地方看起来不像是会分食的场所…"
    translate None chapter_ten_0087:
        "转眼间，各式菜肴已铺满整张餐桌。就连先前满腹狐疑的福恩和莱奥斯都瞪大了眼睛。"
    translate None chapter_ten_0088:
        c "开动吧！"
    translate None chapter_ten_0089:
        "场景和昨天早上尼科斯为我们准备盛宴时如出一辙。我们每样都取了些放在自己盘子里。"
    translate None chapter_ten_0090:
        l "等—等一下，这里没有用牛蹄子做的菜吧？"
    translate None chapter_ten_0091:
        c "啊？"
    translate None chapter_ten_0092:
        rs "别理他。"
    translate None chapter_ten_0093:
        "我吃了好几叉食物，又把注意力转回同伴身上。"
    translate None chapter_ten_0094:
        rs "所以…我觉得我们应该整理下对这个地方的了解。"
    translate None chapter_ten_0095:
        l pen "这重要吗？反正与我们无关。待会儿和那人谈完就离开这儿。"
    translate None chapter_ten_0096:
        rs "如果要找关于卡斯皮安的线索，这里就是希望所在。那个人可能什么都不知道。"
    translate None chapter_ten_0097:
        l "到处解决别人的问题又不是我们的义务。这里发生什么都与我们无关。"
    translate None chapter_ten_0098:
        c "不过，你们就一点都不好奇吗？反正我很感兴趣。"
    translate None chapter_ten_0099:
        f "我…不得不承认，连我都觉得好奇。"
    translate None chapter_ten_0100:
        rs "看吧？那么，我们目前知道些什么？"
    translate None chapter_ten_0101:
        f "我们知道这个镇子几乎空无一人…"
    translate None chapter_ten_0102:
        rs "与其说是空城，不如说居民都躲起来了。我们在外面遇见的人都惊恐万分。"
    translate None chapter_ten_0103:
        l "唉…"
    translate None chapter_ten_0104:
        l "莱拉斯提到有人失踪的事，而镇中心似乎牵涉其中。"
    translate None chapter_ten_0105:
        c "我每隔几个月来一次，通常情况没这么糟糕。"
    translate None chapter_ten_0106:
        "我慢慢咀嚼食物陷入沉思。无论如何绞尽脑汁，我都理不清头绪。"
    translate None chapter_ten_0107:
        rs "可这家餐厅却照常营业。也许服务员知道些什么？"
    translate None chapter_ten_0108:
        c "服务员？"
    translate None chapter_ten_0109:
        "他瞬间就出现在赛恩身旁。服务真是无可挑剔。"
    translate None chapter_ten_0110:
        c "你肯定知道。镇上究竟发生了什么？为什么大家都这么安静？"
    translate None chapter_ten_0111:
        wa "........"
    translate None chapter_ten_0112:
        "他神色惊恐地别过脸去。"
    translate None chapter_ten_0113:
        wa "我不确定能不能说…"
    translate None chapter_ten_0114:
        wa "我-我不该讨论这个，但是…"
    stop music fadeout 3.0
    scene gallery_47b with dissolve
    translate None chapter_ten_0115:
        wa "大批民众接连失踪…"
    translate None chapter_ten_0116:
        rs "大批？这么多人能去哪儿？"
    translate None chapter_ten_0117:
        wa "我们毫无头绪…但是，其中有部分人…"
    translate None chapter_ten_0118:
        wa "部分人的尸体陆续出现。遍布全镇，就像被刻意展示。"
    translate None chapter_ten_0119:
        wa "准确说是…他们残缺的遗体…"
    translate None chapter_ten_0120:
        wa "抱歉，我只能说到这…"
    translate None chapter_ten_0121:
        c "胡扯。你透露的够多了。多谢。"
    translate None chapter_ten_0122:
        "赛恩往他手里塞了几枚硬币，对方千恩万谢后离开了。"
    translate None chapter_ten_0123:
        rs "....."
    translate None chapter_ten_0124:
        f sad "....."
    play music "sounds/bgm/creepy.ogg" fadeout 2.0
    translate None chapter_ten_0125:
        f "情况比预想的更糟…"
    translate None chapter_ten_0126:
        l pen "冷静想想，我们只有一个选择。撤离。没必要白白送命。"
    translate None chapter_ten_0127:
        rs "才不是白送！我必须找到他！"
    translate None chapter_ten_0128:
        l ang "不，你不需要。没有他也能活。就当这个人不存在。"
    translate None chapter_ten_0129:
        rs "我需要！否则我永远查不出这些神之刻印的…"
    translate None chapter_ten_0130:
        c "神之刻印？"
    translate None chapter_ten_0131:
        rs "呃那是…不，没什么…"
    translate None chapter_ten_0132:
        l "看在老天的份上…别费劲了。事到如今不如坦白。"
    translate None chapter_ten_0133:
        l "你这张嘴能保密到现在真是奇迹。"
    translate None chapter_ten_0134:
        "我羞愧低头。莱奥斯说得对，我太冒失了。但我不是故意说漏嘴…"
    translate None chapter_ten_0135:
        rs "嗯…"
    translate None chapter_ten_0136:
        "他急切地注视着我。"
    translate None chapter_ten_0137:
        "确认四周无人注意后，我卷起袖子展示手臂上的刻印。"
    translate None chapter_ten_0138:
        c "果然是你。"
    translate None chapter_ten_0139:
        rs "什么？"
    translate None chapter_ten_0140:
        c "斯塔格威奇人人都在议论胳膊带刻印的少年。没想到是你。"
    translate None chapter_ten_0141:
        c "真是意外的惊喜。"
    translate None chapter_ten_0142:
        rs "哦…"
    translate None chapter_ten_0143:
        "他轻轻触碰那些黑色符文。"
    translate None chapter_ten_0144:
        rs "你能认出这些文字吗？"
    translate None chapter_ten_0145:
        c "….不疼。"
    translate None chapter_ten_0146:
        c "但我不禁感觉曾在某处见过它们。"
    translate None chapter_ten_0147:
        f "我也有同感。"
    translate None chapter_ten_0148:
        c "嗯。你是怎么得到它们的？这跟找到那个家伙有什么关系？"
    translate None chapter_ten_0149:
        rs "它就是…某天突然出现的。当时一切都模糊不清，但最终我被驱逐出奥雷利亚卡维拉，独自流落森林。卡斯皮安是唯一掌握的线索名字，但他可能已经不在人世了。"
    translate None chapter_ten_0150:
        rs "但如果他还活着，或许能解读其中的含义。"
    stop music fadeout 2.0
    translate None chapter_ten_0151:
        c "等等，奥雷利亚卡维拉？"
    translate None chapter_ten_0152:
        l "你听说过？"
    #scene gallery_47 with dissolve
    translate None chapter_ten_0153:
        c "当然。谁没听过呢？鉴于我们血腥的历史，人人都愿意相信它真实存在。那座深藏森林的神话之城，免受外界玷污。由传说中的神圣演说者统治，作为神明的代言人。"
    translate None chapter_ten_0154:
        c "多有趣的故事！哈哈，要真存在那种地方该多好？那不是很美妙吗？"
    translate None chapter_ten_0155:
        rs ".................."
    translate None chapter_ten_0156:
        l sur ".................."
    play music "sounds/bgm/Discovery.ogg" fadeout 2.0
    translate None chapter_ten_0157:
        "什么？"
    translate None chapter_ten_0158:
        rs "什么故事？那就是我的故乡。莱奥斯也是。奥雷利亚卡维拉。"
    translate None chapter_ten_0159:
        c "等等，当真？不是虚构的？！"
    translate None chapter_ten_0160:
        rs "你所说的每件事都是事实。言者统领城镇，担任神与人之间的传声筒，而且确实位于森林深处。"
    translate None chapter_ten_0161:
        c "哇等等等一下！那人真实存在？！我以为只是传说。几百年来没人听说真有神圣演说者。"
    translate None chapter_ten_0162:
        rs "是真的！他个子很高，留着白色长发！"
    translate None chapter_ten_0163:
        c "听起来很英俊。能引荐一下吗？"
    translate None chapter_ten_0164:
        l "先别急。把你了解的相关传说告诉我们。"
    translate None chapter_ten_0165:
        c "为什么？"
    translate None chapter_ten_0166:
        l pen "或许还隐藏着更多真相。"
    translate None chapter_ten_0167:
        c "呃这个嘛……"
    translate None chapter_ten_0168:
        c "如果你们真想知道，我可以讲讲。这是个很长的故事，而且并不美好。"
    stop music fadeout 2.0
    translate None chapter_ten_0169:
        c "至少部分内容真实可信。到某个时间点为止，余下部分就被迷雾笼罩了。至少我一直这么认为。"
    translate None chapter_ten_0170:
        c "五百多年前，锡德卡汉由国王与神圣演说者共同统治。两人平起平坐，协力治理疆土。"
    translate None chapter_ten_0171:
        c "人们不远万里前来接受奥雷利亚诸神的祝福。那时这个信仰已遍及大半个维迪斯地区。"
    translate None chapter_ten_0172:
        c "虽然表面上国王与说书人看似合作无间，但众所周知他们之间关系紧张。我只是不明白为何如此。国王是因为说书人备受瞩目而恼怒吗？他是否想独自统治锡德卡汉？"
    translate None chapter_ten_0173:
        c "无论如何，这种冰冷的关系延续了几代人，最终在五百年前的那场战争中达到顶峰。"
    translate None chapter_ten_0174:
        rs "一场战争？"
    translate None chapter_ten_0175:
        c "我们的国王集结力量要废除说书人的权力，并获得了全体议会的支持。他颁布法令宣布说书人和所有奥雷利亚诸神为非法存在，任何被发现崇拜他们的人都将面临死刑。"
    translate None chapter_ten_0176:
        c "当然，说书人对此并不友善…于是延续了我们历代国王与说书人之间的血腥历史。一场夺走无数生命的惨烈战争，在信徒与非信徒之间展开。"
    translate None chapter_ten_0177:
        c "以上就是我所知道的真实历史。有人说说书人与他的大部分追随者都在那里死去，但这也太无趣了，不是吗？"

    $ about_AClegend.locked = False
    translate None chapter_ten_0178:
        c "还有人说，双胞胎王子之一的希昂王子—那个反对父亲和兄长的王子—与说书人及其追随者一同离去，{a=set_entry:enc_lore->about_AClegend}{color=#DA70D6}建立了属于他们自己的城市{/color}{/a}。奥雷利亚卡维拉。"
    translate None chapter_ten_0179:
        c "我总觉得这听起来太过浪漫，但谁知道呢？"
    play music "sounds/bgm/sad.ogg" fadein 2.5
    translate None chapter_ten_0180:
        rs "不可能…."
    translate None chapter_ten_0181:
        l "哦天啊…"
    translate None chapter_ten_0182:
        c "什么？"
    translate None chapter_ten_0183:
        rs "锡德卡汉的希昂王子…难怪…"
    translate None chapter_ten_0184:
        rs "他…在我们的记载中是五百年前奥雷利亚卡维拉的建立者…"
    translate None chapter_ten_0185:
        rs "当时我觉得很奇怪…如果我们唯一的文明，为什么直到那时才开始？"
    translate None chapter_ten_0186:
        rs "这是否意味着….他们一直在对我们隐瞒？说书人其实心知肚明？"
    translate None chapter_ten_0187:
        rs "他真的在欺骗我们吗？"
    translate None chapter_ten_0188:
        l "我…我现在也搞不清了…"
    translate None chapter_ten_0189:
        rs "...."
    translate None chapter_ten_0190:
        rs "…奥雷利亚卡维拉早已没有国王。王室已经灭亡了。"
    translate None chapter_ten_0191:
        c "历史确实在不断重演。或许国王与说书人注定永远要争斗？"
    translate None chapter_ten_0192:
        rs "你是说说书人可能就是杀害他们的凶手？！"
    translate None chapter_ten_0193:
        c "谁知道呢。我只是说存在这种可能性，我自己也不清楚。"
    translate None chapter_ten_0194:
        rs "我不确定该不该说这个，但是…卡斯皮安是—不，曾经是奥雷利亚卡维拉的最后一位王子。据说他从未加冕，是与家人一同死去的，但…"
    translate None chapter_ten_0195:
        rs "看起来他可能逃走了。这就是我们为何如此拼命搜寻的原因。"
    translate None chapter_ten_0196:
        "…说书人可能知道这件事吗？他认识卡斯皮安吗？"
    translate None chapter_ten_0197:
        "赛恩吃完盘中最后一口食物，转头看向我。"
    translate None chapter_ten_0198:
        c "我们何不到外面再多聊会儿？"
    translate None chapter_ten_0199:
        rs "好吧…"
    translate None chapter_ten_0200:
        "他招呼服务员，不动声色地递上钱。这顿饭可不便宜。"
    translate None chapter_ten_0201:
        c "这是单独给你的小费，帅哥！"
    translate None chapter_ten_0202:
        wa "谢谢您，先生。"
    translate None chapter_ten_0203:
        "食物很美味，但我口中却残留着一丝苦涩。"

    play sound "sounds/sfx/dooropen3.ogg" fadeout 1.0
    stop music fadeout 2.0
    window hide dissolve

    scene bg oxhabor night with dissolve
    window show dissolve
    play music "sounds/bgm/Creepy.ogg" fadein 3.0
    translate None chapter_ten_0204:
        "推开门时，我们发觉天色已暗。不知不觉竟在里面待了好几个小时。"

    show fawn n dark neu at farleft
    show leos n dark neu at farright
    show cyne n dark neu at cenright
    show raen n dark neu at cenleft
    with dis

    translate None chapter_ten_0205:
        c "那么，我们先把事情捋清楚。"
    translate None chapter_ten_0206:
        c "奥雷利亚卡维拉真实存在，你中了诅咒之类的，然后被赶了出来。接着你就遇见了这两个人？"
    translate None chapter_ten_0207:
        c "你被驱逐的具体原因是什么？"
    show raen n dark sad with dis
    translate None chapter_ten_0208:
        rs "我…有人告诉我能在档案室查到关于神之刻印的信息，但看来不是真的…"
    translate None chapter_ten_0209:
        rs  "说书人发现我在那儿，直接把我扔了出来。"
    translate None chapter_ten_0210:
        l "….我是受人雇佣去告诉他这个的。不知道雇主是谁。"
    show cyne n dark sur with dis
    translate None chapter_ten_0211:
        c "这不觉得有点可疑吗？你是不是做了什么得罪你们那位说书人的事？"
    show raen n dark sur with dis
    translate None chapter_ten_0212:
        rs "什—没有啊！那还是我第一次跟他说话。我们生活在完全不同的世界，以前从没见过面。"
    translate None chapter_ten_0213:
        c "唔，既然你这么说。"
    show cyne n dark neu with dis
    translate None chapter_ten_0214:
        c "听起来像是某种设局。"
    show raen n dark sad with dis
    translate None chapter_ten_0215:
        rs "我不觉得自己做过什么会惹恼别人的事…"
    show leos n dark smi with dis
    translate None chapter_ten_0216:
        l "既然你什么都在往外说，那也应该提一句我是被派来杀你的。"
    show cyne n dark sur with dis
    translate None chapter_ten_0217:
        c "哇哦。你现在还在试图杀他吗？"
    show leos n dark ang with dis
    translate None chapter_ten_0218:
        l "…也没有。"
    translate None chapter_ten_0219:
        l "要是你敢把这些事告诉任何人，你就死定了。"
    show cyne n dark hap with dis
    translate None chapter_ten_0220:
        c "你可以相信我！我是这儿最靠谱的人。"
    translate None chapter_ten_0221:
        l "是啊，如果这屋里就你一个人的话。"
    translate None chapter_ten_0222:
        c "我有做过什么显得不可信的事吗？"
    translate None chapter_ten_0223:
        "还有些事我没告诉他们，但现在最好保密。连莱奥斯都不知道我的梦境和那晚与福恩发生的事。"
    translate None chapter_ten_0224:
        "福恩说那些事最好别对外说，所以我可能暂时先不提。"
    translate None chapter_ten_0225:
        "现在想来，仅仅因为进了档案室就够得上处死吗？我以前从不认为说书人是残忍之人。"
    translate None chapter_ten_0226:
        "话又说回来，如果他知道外界的事，还会同意驱逐我吗？我不知道。"
    translate None chapter_ten_0227:
        "也许这背后还有更多隐情。又或者是我过度解读了。"
    show cyne n dark neu with dis
    translate None chapter_ten_0228:
        c "所以，这一切把你带到了这里，寻找一个可能知道答案的人。"
    translate None chapter_ten_0229:
        rs "没错。"
    translate None chapter_ten_0230:
        c "那么莱奥斯说的不是真的。找到他很重要。"
    show cyne n dark mis with dis
    translate None chapter_ten_0231:
        c "我当然会帮你！现在事情变得有趣，我不能就此离开。"
    translate None chapter_ten_0232:
        c "我简直像个圣人似的。"
    translate None chapter_ten_0233:
        "福恩在这场谈话中大多保持沉默。就在他开口时，我转头望向他。"
    translate None chapter_ten_0234:
        f "........"
    translate None chapter_ten_0235:
        f "如果我们永远找不到他呢？"
    translate None chapter_ten_0236:
        rs "那么…."
    translate None chapter_ten_0237:
        rs "我想…等真到那时再处理吧。"
    show cyne n dark hap with dis
    translate None chapter_ten_0238:
        c "乐观些！我觉得是时候去见见我们那位神秘人物了。"
    translate None chapter_ten_0239:
        rs "你说得对。"
    translate None chapter_ten_0240:
        "我深吸一口气。空气很凉。离家乡越远，天气就越冷。"
    translate None chapter_ten_0241:
        "不知为何，当我们返回最初遇见那个男人的地方时，我感到一阵紧张。"
    translate None chapter_ten_0242:
        rs "赛恩，我想问你件事—你对奥克斯哈伯了解多少？"
    translate None chapter_ten_0243:
        c "我知道什么？他们制造最棒的玩具—"
    show leos n dark ang with dis
    translate None chapter_ten_0244:
        l "认真回答。"
    show cyne n dark neu with dis
    translate None chapter_ten_0245:
        c "好吧好吧。我知道穆拉诺家族控制着他们城镇的大部分。"
    show raen n dark neu with dis
    translate None chapter_ten_0246:
        rs "穆拉诺家？我们之前略有耳闻。他们掌管这里的玻璃生产？"
    show cyne n dark mis with dis
    translate None chapter_ten_0247:
        c "没错！你知道吗，男人的知识储备很有魅力。"
    show raen n dark con with dis
    translate None chapter_ten_0248:
        rs "…..你就知道这些？"
    show cyne n dark neu with dis
    translate None chapter_ten_0249:
        c "…我听说穆拉诺家族原本来自锡德卡汉，但几百年前夹着尾巴逃到这里。他们白手起家建设了奥克斯哈伯。"
    show raen n dark sur with dis
    translate None chapter_ten_0250:
        rs "他们做了什么错事吗？"
    translate None chapter_ten_0251:
        "他对我的问题耸了耸肩。"
    translate None chapter_ten_0252:
        c "不知道。我自己从没调查过。"


    scene bg oxhabor night with dissolve:
        xpos 0.5 ypos 1.0 xanchor 0.61 yanchor 1 zoom 2.0
        linear 20 yanchor 0.83

    translate None chapter_ten_0253:
        "我们继续穿行在昏暗的街道上，前往与神秘人约定的地点。"
    translate None chapter_ten_0254:
        "万籁俱寂。这本与早些时候没太大不同，但当月光成为街道唯一光源时，却散发出诡异氛围。"
    translate None chapter_ten_0255:
        "我们的每步脚步声都在空荡的街道回响。虽未言明，但我们默契地互相戒备着。"
    translate None chapter_ten_0256:
        "情况有些不对劲。"
    translate None chapter_ten_0257:
        "感觉不像身处城市中心。就像那晚我独自穿越森林时的感受。一种致命的寂静。"

    scene bg ox alley night with dissolve

    translate None chapter_ten_0258:
        "当我们终于到达早先的地点时，看见有人倚在月光照亮的暗墙上。"
    show nox n dark neu2 with dis2
    translate None chapter_ten_0259:
        "我们走近时，他转身面向我们。"
    translate None chapter_ten_0260:
        u "那么，你还是来了。"
    translate None chapter_ten_0261:
        "他在我们几张脸之间来回看着。可能没想到我们会有这么多人。"
    translate None chapter_ten_0262:
        u "…..跟我来。"

    hide nox with dissolve
    play sound "walkinghall2.ogg"
    translate None chapter_ten_0264:
        "他转身走进黑暗，没有确认我们是否跟上。"
    translate None chapter_ten_0265:
        "我深吸一口气。现在只有一个选择。"
    translate None chapter_ten_0266:
        rs sad "快走，别跟丢了。"
    translate None chapter_ten_0267:
        "莱奥斯严肃地看了我一眼，福恩显得忧心忡忡。"
    translate None chapter_ten_0268:
        "原本不害怕的，但此刻深更半夜置身于这片浓墨般的黑暗里…"
    translate None chapter_ten_0269:
        "我甩开这些念头，跟上那个神秘男人。"

    window hide dissolve

    scene black with dissolve
    window show dissolve
    translate None chapter_ten_0270:
        "我们很快追上。他走得很慢，但每一步都很坚定。"
    translate None chapter_ten_0271:
        "他始终一言不发。"
    translate None chapter_ten_0272:
        "在静默中前行数分钟后，他在一栋大宅前停住。黑暗中虽看不真切，但那宅邸确实气派非凡。"
    translate None chapter_ten_0273:
        "高耸的围栏圈着地产，配着巨大的金属门。我从没见过这样的门。门牌上写着\"穆拉诺\"。"
    translate None chapter_ten_0274:
        u "保持安静。"
    translate None chapter_ten_0275:
        "我对他微微点头，随他穿过大门进入宅内。"

    stop music fadeout 2.0
    window hide dissolve

    scene bg nox house night with dissolve:
        size (1920, 1080) crop (0, 290, 1330, 789)
        linear 35.0 crop (550, 290, 1330, 789)
    window show dissolve
    translate None chapter_ten_0276:
        "室内的广阔黑暗丝毫未减。漆黑如墨，看不见一支蜡烛或提灯。"
    play sound "sounds/sfx/dooropen.ogg" fadein 1.0
    translate None chapter_ten_0277:
        "等我们都进来后，他砰地关上门。"
    translate None chapter_ten_0278:
        "他从桌上拿起蜡烛点亮，但诡异气氛丝毫未散。"
    translate None chapter_ten_0279:
        "他慢慢用蜡烛点燃两盏提灯。光线逐渐照亮四周。"
    translate None chapter_ten_0280:
        "一切都那么…奢华。巨大的楼梯占据大半视野，精美的木地板与昂贵的装饰…"
    translate None chapter_ten_0281:
        "在我家，所有东西都讲究实用。这里纯粹在炫富。"


    scene bg nox house night with Dissolve(1):
        xanchor 0.05 yanchor 0.17 zoom 1.58
    show nox m dim neu2 with dis
    translate None chapter_ten_0282:
        u "我父母…外出，现在这里只有我们。可以畅所欲言。"
    translate None chapter_ten_0283:
        l ang "…..\"我们一路跟你到这。把你知道的说出来。"
    translate None chapter_ten_0284:
        u "…\"还不行。"
    translate None chapter_ten_0285:
        l "简直是浪费时间。我们走。"
    show nox m dim sad2 with dis
    translate None chapter_ten_0286:
        u "等等—"

    play music "sounds/bgm/Creepy.ogg" fadein 4.0
    play sound "sounds/sfx/doorlocked.ogg" fadeout 1
    translate None chapter_ten_0287:
        "莱奥斯转身拧动门把，发现纹丝不动。"
    translate None chapter_ten_0288:
        u "进来时我就锁了。别担心，不会伤害你们。只需要你们听我说。"
    show nox m dim neu2 with dis
    translate None chapter_ten_0289:
        u "我知道卡斯皮安的事。知道他去哪了。"
    translate None chapter_ten_0290:
        u "…\"我会告诉你们，但需要帮忙。"
    translate None chapter_ten_0291:
        c ang "大半夜的？白天不能找我们帮忙？"
    show nox m dim ang2 with dis
    translate None chapter_ten_0292:
        u "不要！"
    show nox m dim sad2 with dis
    translate None chapter_ten_0293:
        u "我是说…这事…"
    translate None chapter_ten_0294:
        u "现在说话比较安全，没人能听见我们。"
    translate None chapter_ten_0295:
        f sad "什么…什么事情需要如此保密，不能让任何人听到？"
    translate None chapter_ten_0296:
        u "......"
    show nox m dim neu2 with dis
    translate None chapter_ten_0297:
        u "我确信你已经注意到了。所有人都神经紧绷。"
    translate None chapter_ten_0298:
        rs sad "….我们确实注意到了。"
    translate None chapter_ten_0299:
        u "你也应该听说了最近有人失踪的消息。有些人被发现时已经死了。"
    translate None chapter_ten_0300:
        rs sad "没错。"
    show nox m dim pen2 with dis
    translate None chapter_ten_0301:
        u "那些被找到的尸体…几乎不能称之为尸体了。他们的胳膊和腿通常都不见了…脸也被砸得血肉模糊。"
    translate None chapter_ten_0302:
        u "你可能不知道的是…"
    translate None chapter_ten_0303:
        u "那些失踪的人，还有那些被发现死亡的人…"
    show nox m dim neu2 with dis
    translate None chapter_ten_0304:
        u "他们的名字都被预先公示过。"
    translate None chapter_ten_0305:
        rs sur "什么…？"
    translate None chapter_ten_0306:
        u "城镇中心是我们祭奠逝者的地方。最近去世的人名会显示在镇上的告示牌上。"
    translate None chapter_ten_0307:
        u "起初没人注意到。就算多出一两个名字，谁会逐个检查呢？"
    translate None chapter_ten_0308:
        rs sad "你是说-"
    translate None chapter_ten_0309:
        u "活人的名字正在被慢慢添加上去。我们还以为是小孩的恶作剧。"
    show nox m dim sad2 with dis
    translate None chapter_ten_0310:
        u "但是…当他们开始陆续死亡…就没人再觉得这是玩笑了。"
    translate None chapter_ten_0311:
        rs wor "这…这种情况持续多久了？！"
    show nox m dim pen2 with dis
    translate None chapter_ten_0312:
        u "好几年了。直到最近数量激增，人们才注意到异常。"
    translate None chapter_ten_0313:
        "我感觉心跳快得像要跃出胸膛。莱奥斯、赛恩和福恩看起来也同样震惊。这事远超出我们的能力范围。"
    translate None chapter_ten_0314:
        c "为什么…为什么不向上面求助？国王应该-"
    translate None chapter_ten_0315:
        u "国王早就把我们遗忘了。再说他也不会帮助我们这种人。"
    show nox m dim sad2 with dis
    translate None chapter_ten_0316:
        u "…无论凶手是谁，都必须阻止它。"
    translate None chapter_ten_0317:
        rs wor "你…想让我们来阻止？"
    translate None chapter_ten_0318:
        u "我一个人办不到。我也会被杀死的。"
    translate None chapter_ten_0319:
        l "这太危险了。我们不值得为这种事赌上性命。"
    show nox m dim ang with dis
    translate None chapter_ten_0320:
        "他猛地摘下眼镜，眼中透着绝望。"
    translate None chapter_ten_0321:
        u "等等，求你！我知道卡斯皮安的事。如果你们肯帮我，我就告诉你们。我知道很多关于他的事。"

    window hide

    menu:
        "询问更多关于失踪者的事":
            window show dissolve
            jump nox_missing

        "询问卡斯皮安的事":
            window show dissolve
            jump nox_caspian

        "询问他的事":
            window show dissolve
            jump nox_nox


label nox_missing:
    show nox m dim neu with dis
    translate None chapter_ten_0322:
        rs sad "…如果要我们帮忙，你必须告诉我们更多失踪者的情况。"
    translate None chapter_ten_0323:
        l "你不是认真的吧。"
    translate None chapter_ten_0324:
        c "失踪者之间有什么共同特征吗？"
    translate None chapter_ten_0325:
        u "我没发现。小孩，大人…它似乎来者不拒。"
    translate None chapter_ten_0326:
        rs sad "已经有多少人失踪了？"
    show nox m dim pen with dis
    translate None chapter_ten_0327:
        u "…数不清了。最开始，只有零星几个。"
    translate None chapter_ten_0328:
        u "偶尔会有人失踪，所以一年一两个人并不奇怪。"
    show nox m dim neu with dis
    translate None chapter_ten_0329:
        u "但现在…每个月都有好些个。五、十、十五。"
    translate None chapter_ten_0330:
        f "这么多？"

    jump choice_sixteen_done

label nox_caspian:
    show nox m dim neu with dis
    translate None chapter_ten_0331:
        rs sad "….关于卡斯皮安你知道些什么？"
    translate None chapter_ten_0332:
        u "他在我们这里住过一段时间，但…"
    show nox m dim sad with dis
    translate None chapter_ten_0333:
        u "他不得不离开。"
    translate None chapter_ten_0334:
        c "他为什么离开？和现在发生的事情有关系吗？"
    show nox m dim pen with dis
    translate None chapter_ten_0335:
        u "....."
    show nox m dim sad with dis
    translate None chapter_ten_0336:
        u "我不….知道…."

    jump choice_sixteen_done

label nox_nox:
    show nox m dim neu with dis
    translate None chapter_ten_0337:
        rs sad "……你是谁？"
    show nox m dim sur with dis
    translate None chapter_ten_0338:
        u "我？"
    translate None chapter_ten_0339:
        rs sad "你住在这样的房子里，半夜到处游荡…"
    show nox m dim sad with dis
    translate None chapter_ten_0340:
        u "我不是什么重要人物。"
    translate None chapter_ten_0341:
        u "我只是个希望生活恢复正常的人。"

    jump choice_sixteen_done

label choice_sixteen_done:
    translate None chapter_ten_0342:
        "….这个人绝对有问题，但这里正在发生的事情很严重。"
    translate None chapter_ten_0343:
        rs sad "至少能告诉我们你的名字吗？"
    show nox m dim pen with dis
    translate None chapter_ten_0344:
        u "我的名字…"

    $ about_Nox.locked = False
    show nox m dim neu with dis

    translate None chapter_ten_0345:
        nox "我想起来了。你可以叫我{a=set_entry:enc_people->about_Nox}{color=#DA70D6}诺克斯{/color}{/a}。"

    if achievement.has("nox_meet"):
        pass
    else:
        $ renpy.display_notify("成就解锁：昏暗庄园")

    python:
        achievement.grant("nox_meet")
        achievement.sync()

    translate None chapter_ten_0346:
        c "诺克斯？"
    translate None chapter_ten_0347:
        nox "没错。"
    translate None chapter_ten_0348:
        rs neu "我叫雷恩，这是莱奥斯、福恩和赛恩。"
    translate None chapter_ten_0349:
        rs neu "我能和朋友们谈谈这件事吗？"
    show nox n dim neu with dis
    translate None chapter_ten_0350:
        nox "……当然。我会去准备些东西等着。"

    hide nox with dissolve
    show cyne n neu dim at left
    show fawn n neu dim at right
    show leos n ang dim at center
    with dissolve

    translate None chapter_ten_0351:
        "诺克斯缓缓走上楼梯，离开了我们的视线。他一离开，莱奥斯就抓住了我的肩膀。"
    translate None chapter_ten_0352:
        l "你疯了吗？！"
    translate None chapter_ten_0353:
        l "你是多想找死？！"
    translate None chapter_ten_0354:
        rs sad "什-！我才不想！"
    translate None chapter_ten_0355:
        rs sad "我们还有其他选择吗？"
    show leos n hur dim with dis
    translate None chapter_ten_0356:
        l "什么叫\"我们还有其他选择\"？！别说这种话！我们现在转身离开。这不是我们的问题。"
    show cyne n dim ang with dis
    translate None chapter_ten_0357:
        c "真的吗？我觉得这就是我们的问题。"
    translate None chapter_ten_0358:
        l "你怎么会认为这事和我们有关系？"
    show cyne n dim neu with dis
    translate None chapter_ten_0359:
        c "呃，我们被锁在这里了。"
    show fawn n dim sad with dis
    translate None chapter_ten_0360:
        f "如果我们拒绝…他会放我们出去吗？"
    translate None chapter_ten_0361:
        "我环顾这个昏暗的房间。还有其他门通往房屋深处，但谁知道有没有通向室外的。"
    translate None chapter_ten_0362:
        c "……我之前没机会说，这里是穆拉诺庄园。你们都看到大门上的名字了吧？"
    translate None chapter_ten_0363:
        rs wor "我注意到了…他是…？"
    translate None chapter_ten_0364:
        c "不想引起恐慌，但…据我所知，穆拉诺家族里没有叫\"诺克斯\"的人。"
    show fawn n dim hur with dis
    translate None chapter_ten_0365:
        f "我…我害怕。"
    translate None chapter_ten_0366:
        rs sad "别怕。我们会没事的。"
    translate None chapter_ten_0367:
        "但愿他没听出我声音的颤抖，也没看到我发抖的双手。"

    window hide

    menu:
        "同意帮助他":
            window show dissolve
            jump nox_help

        "尝试逃跑":
            window show dissolve
            jump nox_escape

label nox_escape:
    hide leos
    hide fawn
    hide cyne
    with dis2
    translate None chapter_ten_0368:
        rs sad "莱奥斯说的对。我们必须离开这里。"
    play sound "sounds/sfx/doorlocked.ogg" fadeout 1
    translate None chapter_ten_0369:
        "我抓住门把手。该死，还是卡住了。"
    translate None chapter_ten_0370:
        l ang "快，在他回来之前。试试那些门。"
    translate None chapter_ten_0371:
        "当我冲去试门时，呼吸卡在喉咙里。他随时可能回来。"
    translate None chapter_ten_0372:
        "我汗湿的手从把手上滑脱。快啊雷恩，抓紧。"
    play sound "sounds/sfx/dooropen3.ogg" fadeout 1
    translate None chapter_ten_0373:
        "咔嗒。"
    play sound "sounds/sfx/doorcreak.ogg" fadeout 1
    translate None chapter_ten_0374:
        "我的门发出吱呀声打开了。"
    translate None chapter_ten_0375:
        rs sad "大伙儿，这边！"
    translate None chapter_ten_0376:
        "他们三人迅速跟上我，我关上了门。"


    show black with dissolve
    translate None chapter_ten_0377:
        "里面没有光线，只有黑暗。唯一能听见的是我们越来越快的呼吸声。"
    translate None chapter_ten_0378:
        l ang "沿着墙壁摸索其他出口，快！"
    translate None chapter_ten_0379:
        nox sur2 "雷恩？"
    translate None chapter_ten_0380:
        "从外面的门厅，有人喊我的名字。惊慌中，我沿着墙摸索得更快了。"
    translate None chapter_ten_0381:
        nox "你们去哪儿了？我需要帮忙。"
    play sound "sounds/sfx/glasssmash.ogg" fadeout 1
    translate None chapter_ten_0382:
        "不…不，不行…"
    translate None chapter_ten_0383:
        "我刚才撞倒了什么？！"
    translate None chapter_ten_0384:
        "外面的声音安静下来。"
    translate None chapter_ten_0385:
        "一步，两步…"
    translate None chapter_ten_0386:
        "脚步声越来越响，最后停在门外。"
    translate None chapter_ten_0387:
        "人都去哪儿了？这么黑，这么静…"
    translate None chapter_ten_0388:
        "他们找到出路了吗？"
    translate None chapter_ten_0389:
        "我感觉自己完全孤立无援。"
    translate None chapter_ten_0390:
        nox "你们在里面吗…？"
    translate None chapter_ten_0391:
        nox "求你们别跑—我保护不了你们。出来吧。"
    play sound "sounds/sfx/crash.ogg" fadeout 1
    translate None chapter_ten_0392:
        "那是什么？！"
    translate None chapter_ten_0393:
        "门依然关着。肯定有别的人—"
    translate None chapter_ten_0394:
        u "啊—！"
    stop music fadeout 4.0
    translate None chapter_ten_0395:
        rs wor "大家—"

    play sound "sounds/sfx/fallonground2.ogg" fadeout 1.0
    window hide dissolve
    show black with hpunch
    pause(2.0)

    window show dissolve
    translate None chapter_ten_0396:
        rs wor "呃，我的头…"
    translate None chapter_ten_0397:
        "我紧闭双眼，试图在头痛欲裂中思考。"
    translate None chapter_ten_0398:
        "刚才发生了什么？"
    translate None chapter_ten_0399:
        "我们…我们之前在房间里。"
    translate None chapter_ten_0400:
        "有东西砸碎了，有人尖叫…"
    translate None chapter_ten_0401:
        "好像有人击中了我的头…或者是我摔倒了…"
    translate None chapter_ten_0402:
        "但是，门从未打开过。难道…房间里还有别人？"
    translate None chapter_ten_0403:
        "我现在在哪儿？"
    translate None chapter_ten_0404:
        "这是什么…气味？"


    scene bg nox house night2:
        size (1920, 1080) crop (200, 290, 1330, 789)
    show bloody
    with eye_open

    translate None chapter_ten_0405:
        "我小心翼翼地睁开眼睛。"
    translate None chapter_ten_0406:
        "房间光线昏暗，地面上覆盖着黑色物质。"
    play music "sounds/bgm/creepy.ogg" fadein 2.0
    translate None chapter_ten_0407:
        "血。到处都是。所有东西都浸在血里。"
    translate None chapter_ten_0408:
        "我靠墙坐着。"
    translate None chapter_ten_0409:
        "摸摸头，湿的。"
    translate None chapter_ten_0410:
        "看向手掌，也是暗红色。"
    translate None chapter_ten_0411:
        "气味令人作呕。太浓烈了，我不得不捂住脸。"
    translate None chapter_ten_0412:
        "其他人…去哪儿了？这是谁的血？"
    translate None chapter_ten_0413:
        "我试图看清黑暗深处，但什么也看不见。"
    translate None chapter_ten_0414:
        "只有一根燃着的蜡烛。要是能拿到它，或许能找到其他人。"
    translate None chapter_ten_0415:
        "我缓缓站起身，小心翼翼地扶着墙壁支撑身体。"
    translate None chapter_ten_0416:
        "整个房间在我眼前天旋地转。该死，头疼欲裂。"
    translate None chapter_ten_0417:
        "我伸手抓住了那支蜡烛。"
    translate None chapter_ten_0418:
        "往常我会用柔和来形容烛光，此刻它却将周遭照得鬼气森森。"
    translate None chapter_ten_0419:
        "我举着蜡烛向前探照。这里是穆拉诺庄园的玄关。"
    translate None chapter_ten_0420:
        "斑驳血痕引我深入房间。"
    translate None chapter_ten_0421:
        "眼角突然掠过一抹蓝色。"
    translate None chapter_ten_0422:
        rs wor "福恩！"
    translate None chapter_ten_0423:
        "我冲过去，竭力避开满地狼藉以免滑倒。"

    #window hide dissolve

    scene bg nox house night2:
        xpos -0.03 ypos -0.24 zoom 1.5
        linear 30.0 xpos -0.33 ypos -0.24 zoom 1.5
    show bloody:
        xpos -0.03 ypos -0.24 zoom 1.5
        linear 30.0 xpos -0.33 ypos -0.24 zoom 1.5
    with dissolve

    #   window show dissolve
    translate None chapter_ten_0424:
        rs hur"福…福恩…？"
    translate None chapter_ten_0425:
        "他的目光穿透了我的身体。身旁赛恩和莱奥斯一字排开，全都靠着墙瘫坐。"
    translate None chapter_ten_0426:
        rs ang "伙计们…？这不好笑！"
    translate None chapter_ten_0427:
        "他们某些部位还保持着生前的模样…"
    translate None chapter_ten_0428:
        "直到我察觉异样。"
    translate None chapter_ten_0429:
        "莱奥斯凝固在惊骇表情中的面孔。赛恩被撕成碎布的衣衫，还有福恩血肉模糊的脖颈。"
    translate None chapter_ten_0430:
        "我抓住他的手。毫无反应。"
    translate None chapter_ten_0431:
        rs wor "求你们快停下！这…这不可能…"
    translate None chapter_ten_0432:
        "福恩修长的手从我掌心滑落，砰地砸在地板上。"
    translate None chapter_ten_0433:
        rs "不…不，不该是这样的！"
    translate None chapter_ten_0434:
        "他们直勾勾盯着我。那些眼睛像是在哀求。哀求我救救他们，可惜为时已晚。"
    translate None chapter_ten_0435:
        "……真的晚了吗？"
    translate None chapter_ten_0436:
        "屋里死一般寂静，只有我越来越急促的呼吸和心跳声。思绪猛地闪回小鹿之家。"
    translate None chapter_ten_0437:
        "他受的伤如今落在我身上。"
    translate None chapter_ten_0438:
        "……还能再来一次吗？"

    window hide

    menu:
        "抓住赛恩的手臂":
            window show dissolve
            jump bad_cyne

        "握住福恩的手":
            window show dissolve
            jump bad_fawn

        "抚摸莱奥斯的脸":
            window show dissolve
            jump bad_leos

label bad_cyne:
    translate None chapter_ten_0439:
        "赛恩…他一向机敏过人，肯定知道该怎么办。"
    translate None chapter_ten_0440:
        "要是…能问问他…"
    translate None chapter_ten_0441:
        "我深吸一口气，立刻后悔这个举动—满嘴都是血腥味。"
    translate None chapter_ten_0442:
        "战战兢兢地，我向赛恩的手臂探去。黑暗中他们看起来那么瘦小脆弱。"
    translate None chapter_ten_0443:
        "诸神在上，若你们在看，请助我一臂之力。"
    translate None chapter_ten_0444:
        "我将手放在他手臂上。余温尚存。"

    jump badend1_cont

label bad_fawn:
    translate None chapter_ten_0445:
        "福恩的脸色已经惨白…而现在…他身上所有生机都消散了。"
    translate None chapter_ten_0446:
        rs "福恩，求求你…醒一醒…"
    translate None chapter_ten_0447:
        "我不能…不能让他就这样躺着。"
    translate None chapter_ten_0448:
        "这都是我的错。"
    translate None chapter_ten_0449:
        "我朝着他的手伸去。那修长的手指，漂亮的指甲。"
    translate None chapter_ten_0450:
        "诸神啊，若你们正在聆听…求求你们，让我救救他吧。"
    translate None chapter_ten_0451:
        "他的手还是温热的。"
    translate None chapter_ten_0452:
        "请便。"

    jump badend1_cont

label bad_leos:
    translate None chapter_ten_0453:
        "莱奥斯…我本该听莱奥斯的话。"
    translate None chapter_ten_0454:
        "他立刻就察觉这事不对劲…如果我们一开始就没碰到诺克斯，那么.."
    translate None chapter_ten_0455:
        "要是我信任他就好了。"
    translate None chapter_ten_0456:
        "我低头望向他的脸，顿时感到一阵作呕。那张脸如此…空洞。"
    translate None chapter_ten_0457:
        "他的面容凝固在某种尖叫的状态，双眼布满血丝。这是个残酷的玩笑吗…？求求谁告诉我这不是真的。"
    translate None chapter_ten_0458:
        "我深吸一口气，强压下深深的恐惧，将双手轻轻覆在他脸上。他的下颌如此纤细，皮肤如此柔软…"

    jump badend1_cont

label badend1_cont:
    translate None chapter_ten_0459:
        "一定要成功。"
    translate None chapter_ten_0460:
        "必须成功…"
    translate None chapter_ten_0461:
        rs "呃啊！"
    translate None chapter_ten_0462:
        rs "不…再来…求你了！"
    translate None chapter_ten_0463:
        rs "呃…为什么…"
    translate None chapter_ten_0464:
        "我尝试了一遍又一遍，但是…"
    translate None chapter_ten_0465:
        "毫无反应。"
    translate None chapter_ten_0466:
        "我低头看向自己的手掌。上面沾满了血，不是我的血。我怎么能…"
    translate None chapter_ten_0467:
        "我怎么能让他们遭遇这种事…？"
    translate None chapter_ten_0468:
        "我凝视着黑暗。看不见任何人，却能感觉到有谁—或者说有什么东西在注视着我。"
    window hide dissolve
    $ quick_menu = False

    play sound "sounds/VA/chapter_ten_0469a.ogg"
    show black with Dissolve(1)
    pause(2)

    translate None chapter_ten_0469:
        dem "{cps=15}继续啊。逃跑吧。"
    translate None chapter_ten_0470:
        dem "{cps=15}抛弃你的朋友们。你已经辜负了他们。"

    window show dissolve
    translate None chapter_ten_0471:
        rs wor "不..我…我不是故意的-"
    window hide dissolve

    translate None chapter_ten_0472:
        dem "{cps=15}他们因你而死。"
    translate None chapter_ten_0473:
        dem "{cps=15}你让他们失望了，现在看看他们的样子。"

    window show dissolve
    translate None chapter_ten_0474:
        rs ang "不要！"

    play audio "/sounds/VA/chapter_ten_0475a.ogg"
    window hide dissolve

    pause(2)

    translate None chapter_ten_0475:
        dem "{cps=15}所以，逃跑吧。"

    window show dissolve
    translate None chapter_ten_0476:
        rs wor "我不会的！我不能丢下他们！"
    translate None chapter_ten_0477:
        "我感到双腿在颤抖。我比任何时候都想逃跑。"

    window hide dissolve

    pause(0.5)
    translate None chapter_ten_0478:
        dem "{cps=0}{size=150}快逃！{/size}"

    show bg nox house night2 with dissolve

    window show dissolve
    translate None chapter_ten_0479:
        "我猛地跳起来冲向门口。"
    translate None chapter_ten_0480:
        "对不起…真的对不起…福恩…赛恩…莱奥斯…"
    play sound "sounds/sfx/doorcreak.ogg" fadeout 2.0
    translate None chapter_ten_0481:
        "门猛地打开。它根本没锁。"

    play sound "sounds/VA/chapter_ten_0482a.ogg"
    window hide dissolve
    show black2 with Dissolve(2)
    pause(1.5)


    translate None chapter_ten_0482:
        dem "{cps=15}追杀你会更有趣呢。"
    window hide dissolve

    stop music fadeout 2.0

    scene black with Dissolve(2)
    pause(2.0)

    window show dissolve
    play music "sounds/bgm/forgotten.ogg" fadein 2.0
    translate None chapter_ten_0483:
        u "是他，对吧？"
    translate None chapter_ten_0484:
        u "….看起来是的。"
    window hide dissolve

    scene bg oxhabor day:
        xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.5
    show veras n dim neu1 at slightleft
    show illran n dim neu at slightright
    with Dissolve(1)


    window show dissolve
    translate None chapter_ten_0485:
        "两名男子站在奥克斯哈伯郊外，检视着最新的受害者。那张脸几乎无法辨认。"

    show veras n sad1 with dis

    translate None chapter_ten_0486:
        u "…这不是你的错。我们无能为力。"

    show illran n ang with dis

    translate None chapter_ten_0487:
        gr "….不该是这样的结局。来得太突然了。"
    translate None chapter_ten_0488:
        u "…我们至少该给他一个体面的葬礼。"

    scene black with dissolve

    translate None chapter_ten_0489:
        gr "….是啊。"
    translate None chapter_ten_0490:
        gr "很抱歉没能保护好你。"
    window hide dissolve

    scene bg oxhabor day with Dissolve(1.5)

    window show dissolve
    translate None chapter_ten_0491:
        "始终无人前来寻找这名受害者，也无人探寻他那无名冢。"
    translate None chapter_ten_0492:
        "时光继续流逝，经年累月，青草重新覆上他长眠之地。"

    if achievement.has("illran_bury"):
        pass
    else:
        $ renpy.display_notify("成就解锁：很抱歉我们未能保护你")

    python:
        achievement.grant("illran_bury")
        achievement.sync()

    $ quick_menu = False
    window hide
    scene black
    with Dissolve(2.0)
    return

label nox_help:
    translate None chapter_ten_0493:
        rs sad "….我们必须同意帮助他。"
    translate None chapter_ten_0494:
        rs sad "不知为何，我有种不祥的预感。总觉得如果我们试图离开…"
    show fawn n sad dim with dis
    translate None chapter_ten_0495:
        f "我…我也有同感。"
    translate None chapter_ten_0496:
        rs sad "我不认为他有危险性，只是极度需要帮助罢了。"
    translate None chapter_ten_0497:
        c "….我同意。再说就这么离开也打听不到任何消息。"
    show cyne n dim mis with dis
    translate None chapter_ten_0498:
        c "况且你要是难过的话，我也会伤心的！"
    show leos n dim ang with dis
    translate None chapter_ten_0499:
        l "现在不是开玩笑的时候，这事很严肃。"
    show cyne n dim neu with dis
    translate None chapter_ten_0500:
        c "拜托，我只是想让气氛轻松点。"
    translate None chapter_ten_0501:
        l "….你总是头也不回地扎进危险里。"
    translate None chapter_ten_0502:
        l "好吧，我们帮他。但如果他拒绝告知我们想知道的事…"

    hide fawn
    hide leos
    hide cyne
    with dissolve
    translate None chapter_ten_0503:
        "随着诺克斯重新归队，脚步声在楼梯间回荡。"
    show nox m dim neu with dissolve
    translate None chapter_ten_0504:
        nox "考虑得如何？愿意帮我吗？"
    translate None chapter_ten_0505:
        rs neu "…可以帮你，但必须如实交代所有关于卡斯皮安的事。"
    translate None chapter_ten_0506:
        l neu "而且现在就要说。"
    translate None chapter_ten_0507:
        nox "….现在只能说一半，不能再多。"
    translate None chapter_ten_0508:
        c neu "另一半事后再说？"
    translate None chapter_ten_0509:
        nox "没错。"
    translate None chapter_ten_0510:
        f sad "我想…这还算公平？"
    translate None chapter_ten_0511:
        l "那就开始吧。"
    show nox m dim sad with dis
    translate None chapter_ten_0512:
        nox "卡斯皮安…"
    translate None chapter_ten_0513:
        nox "…在我很小的时候，那时还是孩童…我与他的初遇。"
    show nox m dim pen with dis
    translate None chapter_ten_0514:
        nox "当时正和母亲逛市集。有个比我大不少的男孩站在中央，神色茫然。"
    translate None chapter_ten_0515:
        nox "我记得…他顶着头乱蓬蓬的棕发，脸上带着好奇的表情。"
    translate None chapter_ten_0516:
        nox "他打量世界的方式…就像初次目睹这一切。"
    translate None chapter_ten_0517:
        rs sur "后来呢？"
    translate None chapter_ten_0518:
        nox "我母亲…问他是否有去处，他说没有。"
    show nox m dim hap with dis
    translate None chapter_ten_0519:
        nox "他在我们家暂住过，我们变得很亲近。他就像个兄长，真的…我曾希望我们能永远在一起。"
    show nox m dim sad with dis
    translate None chapter_ten_0520:
        nox "他从未向我父母透露来历，只告诉我来自遥远的异乡，是不得已才逃离的。他眼底总带着哀伤，后来…"
    translate None chapter_ten_0522:
        nox "他的名字…某天夜里，他的名字…"
    translate None chapter_ten_0523:
        nox "浮现了…我不能…我绝不会…"
    translate None chapter_ten_0524:
        nox "我绝不能让它发生在他身上。"
    translate None chapter_ten_0525:
        rs sad "所以…你是说他离开了…？"
    translate None chapter_ten_0526:
        rs sad "之后…你还见过他吗？"
    translate None chapter_ten_0527:
        nox "我…已经快二十年没见过他了…"
    show nox m dim neu with dis
    translate None chapter_ten_0528:
        nox "但是，我保证。我可以向你保证…他还活着。那东西没抓到他。"
    translate None chapter_ten_0529:
        "这里？"
    translate None chapter_ten_0530:
        rs sad "好吧…但我们不能在午夜时分展开搜索。"
    translate None chapter_ten_0531:
        c neu "是啊~你得先放我们出去。然后我们可以明天再调查。"
    translate None chapter_ten_0532:
        nox "…不行。你们今晚要用客卧。"
    translate None chapter_ten_0533:
        l ang "什么？你开玩笑的吧。怎么，你是想把我们扣在这里当人质吗？"
    show nox m dim sur with dis
    translate None chapter_ten_0534:
        nox "不！不不不…"
    translate None chapter_ten_0535:
        nox "但是…街上很危险…你们有其他住处吗…？"
    show nox m dim neu with dis
    translate None chapter_ten_0536:
        "他说得对。虽然这里很瘆人，我们可能得接受这个安排…"
    translate None chapter_ten_0537:
        rs neu "唔…"
    translate None chapter_ten_0538:
        f sad "雷恩…"
    translate None chapter_ten_0539:
        rs neu "冷静点，各位。他只是表达待客之道。对吧？"
    translate None chapter_ten_0540:
        nox "对。外面不安全。如果留在这里，你们会平安度过今晚。"
    translate None chapter_ten_0541:
        c "嗯…"
    translate None chapter_ten_0542:
        "每个人都显得不安。"

    window hide

    menu:
        "询问赛恩的意见":
            window show dissolve
            $ cyne_relationship +=2
            jump cyne_op

        "询问莱奥斯的意见":
            window show dissolve
            $ leos_relationship +=1
            jump leos_op

        "询问福恩的意见":
            window show dissolve
            $ fawn_relationship +=1
            jump fawn_op

label cyne_op:
    translate None chapter_ten_0543:
        rs sad "赛恩…你怎么想？"
    translate None chapter_ten_0544:
        c "我？"
    translate None chapter_ten_0545:
        c "嗯…这个点去别处找住处有点晚了…"

    jump choice_seventeen_done

label leos_op:
    translate None chapter_ten_0546:
        rs sad "莱奥斯…你怎么看？"
    translate None chapter_ten_0547:
        l "我怎么看？"
    translate None chapter_ten_0548:
        l "我觉得这地方挺不错，能在这过夜我会高兴疯的。"
    translate None chapter_ten_0549:
        l "哇，我多幸运啊。"
    translate None chapter_ten_0550:
        rs sad "......"

    jump choice_seventeen_done

label fawn_op:
    translate None chapter_ten_0551:
        rs sad "福恩…你觉得我们应该…？"
    translate None chapter_ten_0552:
        f "呃…我有点害怕，不过…"
    translate None chapter_ten_0553:
        f "如果你想留下…我会保护你的！"
    jump choice_seventeen_done

label choice_seventeen_done:
    translate None chapter_ten_0554:
        "就今晚而言，我认为最好听他的。"
    translate None chapter_ten_0555:
        rs neu "就今晚，行吗？"
    show nox m dim neu with dis
    translate None chapter_ten_0556:
        nox "….当然。"
    translate None chapter_ten_0557:
        l smi "我一直想在鬼屋通宵留宿！"
    translate None chapter_ten_0558:
        c hap "噢噢，我也是！"
    translate None chapter_ten_0559:
        l ang "我不是认真的。"
    translate None chapter_ten_0560:
        c "哦，但我是。"
    translate None chapter_ten_0561:
        l pis "唉…"
    translate None chapter_ten_0562:
        nox "我带你们去看房间。跟我来。"

    scene bg nox house night with dissolve

    translate None chapter_ten_0563:
        "他缓缓起身走向楼梯间，我们都跟在后面。"
    translate None chapter_ten_0564:
        "这真是正确的选择吗？当我环视阴森的环境时，我不那么确定了。"
    translate None chapter_ten_0565:
        "每远离门厅一步，我们就更深地陷入黑暗。"
    translate None chapter_ten_0566:
        nox neu "你们可以用这四个房间，都空着。"
    translate None chapter_ten_0567:
        nox neu "我…建议别点蜡烛，也不要四处走动。"
    translate None chapter_ten_0568:
        f sad "为什么？"
    translate None chapter_ten_0569:
        nox sad "呃…"
    translate None chapter_ten_0570:
        nox sad "不想你们睡着后让蜡烛燃着。"
    translate None chapter_ten_0571:
        nox sad "我见过整栋房子因为这类小疏忽被烧毁。"
    translate None chapter_ten_0572:
        rs sad "明白了…"
    translate None chapter_ten_0573:
        nox sad "锁好房门，尽量在日出前离开。"
    translate None chapter_ten_0574:
        c neu "哇，这一点都不令人毛骨悚然呢。"
    translate None chapter_ten_0575:
        nox neu "……你们越早开始搜索越好。"
    translate None chapter_ten_0576:
        rs neu "好吧…谢谢你，诺克斯。我们一定会这么做的。"
    translate None chapter_ten_0577:
        nox neu "那么，我就先告辞了。"
    translate None chapter_ten_0578:
        nox neu "至于明天…有很多线索要追查，祝你们好运。"
    translate None chapter_ten_0579:
        rs sad "晚安。"
    translate None chapter_ten_0580:
        "诺克斯悄然隐入黑暗，留下我们四人独自站在大厅里。"
    translate None chapter_ten_0581:
        l ang "我们到底在这儿做什么…"
    translate None chapter_ten_0582:
        rs neu "至少我们有地方过夜？"
    translate None chapter_ten_0583:
        f sad "可是…"
    translate None chapter_ten_0584:
        f sad "…..为什么我们必须锁门？"
    translate None chapter_ten_0585:
        rs sad "......"
    translate None chapter_ten_0586:
        rs sad "也许他担心会有盗贼…？"
    translate None chapter_ten_0587:
        c mis "也许他担心如果我不锁门，他会把持不住我？"
    translate None chapter_ten_0588:
        rs sur "那个….有可能是这个原因？"
    translate None chapter_ten_0589:
        l neu "或者，他担心会有东西进来抓我们。"
    translate None chapter_ten_0590:
        rs sad "那不可能是真的…"
    translate None chapter_ten_0591:
        rs sad "只要我们照他说的做，我相信我们会没事，明天就能离开。"
    translate None chapter_ten_0592:
        l neu "所以你承认了，他基本上就是在挟持我们。"
    translate None chapter_ten_0593:
        c hap "作为人质被关押的地方还有更糟的。"
    translate None chapter_ten_0594:
        l cur "比如？"
    translate None chapter_ten_0595:
        c hap "比如那些不让我们免费睡大床房的地方！"
    translate None chapter_ten_0596:
        c mis "他甚至没给我们戴镣铐！当然我是不介意的。"
    translate None chapter_ten_0597:
        l cur "真高兴你这么容易满足。"
    translate None chapter_ten_0598:
        c cas "人们通常可不是这么评价我的。"
    translate None chapter_ten_0599:
        c mis "不过如果你想试试的话，我很乐意。可以多试几次，专门为你。事实上，欢迎你整晚都来尝试。"
    translate None chapter_ten_0600:
        l sur "呃…什么…？"
    translate None chapter_ten_0601:
        f hur "我…我觉得该睡觉了！"
    translate None chapter_ten_0602:
        rs sur "福恩，你一个人没关系吧？"
    translate None chapter_ten_0603:
        f sad "我…"
    translate None chapter_ten_0604:
        f sad "我会锁门的，所以…应该没问题。"
    translate None chapter_ten_0605:
        rs sad "好吧，嗯…那我就选这个房间了。"
    translate None chapter_ten_0606:
        c hap "晚安，睡个好觉！"
    translate None chapter_ten_0607:
        l pis "呃…"
    translate None chapter_ten_0608:
        c hap "莱奥斯，如果你觉得孤单，你知道我房间在哪！"
    translate None chapter_ten_0609:
        l pis "我一个人能行，但还是谢谢了。"
    translate None chapter_ten_0610:
        "莱奥斯砰地关上门，留下赛恩在窃笑。"
    translate None chapter_ten_0611:
        f sad "嗯…晚安…"
    translate None chapter_ten_0612:
        rs neu "晚安，福恩。如果发生什么事，就来找我。"
    translate None chapter_ten_0613:
        f sad "我会的。谢谢，雷恩。"
    translate None chapter_ten_0614:
        "另外两人轻轻关上了身后的门。"
    translate None chapter_ten_0615:
        "突然的空旷让我后颈汗毛直竖。不知为何，独自待在外面的感觉很不妙。我迅速进入房间关上了门。"
    stop music fadeout 3.0
    window hide dissolve
    jump chapter_eleven_start
