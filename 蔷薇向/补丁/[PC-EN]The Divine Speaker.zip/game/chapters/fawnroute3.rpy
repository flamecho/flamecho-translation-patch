label fawnroute3start:

    scene bg swroom night with dissolve:
        xpos 0.71 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.49
        linear 30.0 xpos 0.26 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.49
    window show dissolve


    play music "sounds/bgm/sex.ogg" fadein 2.0
    translate None fawn_chapter3_0001:
        "我还没来得及反应一切就发生了。我把福恩拉近，揽住他的腰，我的唇找到了他的。"
    translate None fawn_chapter3_0002:
        "这个吻仓促而热烈，我们拼命想抱得更紧，确保谁都没法逃走。福恩双臂环住我的脖子，同样热切地回吻着我。"
    translate None fawn_chapter3_0003:
        "我们在房间里跌跌撞撞，磕磕绊绊地挪到床边。双双跌进被褥时，依然唇齿相依。"
    translate None fawn_chapter3_0004:
        "当双唇终于分开时，福恩用那双湿润渴求的大眼睛抬头望着我。"
    translate None fawn_chapter3_0005:
        f c wsmi "雷恩…"
    translate None fawn_chapter3_0006:
        "他的双手捧住我的脸颊，那个消失许久的笑容重新浮现。 "
    translate None fawn_chapter3_0007:
        "他灿烂快乐的笑容具有传染性，我不由自主地笑着再次吻了上去。"
    translate None fawn_chapter3_0008:
        f c wsur "嘿…你是在笑话我吗？"
    translate None fawn_chapter3_0009: # NSFW 1 STARTS HERE
        rs c wsur "不..不，我没在笑，只是…"
    translate None fawn_chapter3_0010:
        rs c wsmi "你很美，知道吗？"
    translate None fawn_chapter3_0011:
        f "…我？美？"
    translate None fawn_chapter3_0012:
        rs "嗯。最美的人。"
    translate None fawn_chapter3_0013:
        "他咯咯笑着回应，再次将我拉向他的唇瓣。"
    translate None fawn_chapter3_0014:
        "起初纯洁甜蜜的吻慢慢变质了。随着胯部紧贴，呼吸愈发灼热，福恩发出一声低沉的呻吟，在我耳边回荡。"
    translate None fawn_chapter3_0015:
        "我惊讶得浑身一颤。"
    translate None fawn_chapter3_0016:
        "这声音…也太可爱了…？"
    translate None fawn_chapter3_0017:
        rs c wsur "福恩…？"
    translate None fawn_chapter3_0018:
        f c wemb "啊…雷恩…"
    translate None fawn_chapter3_0019:
        f "你这样我好难为情…别看了…"
    translate None fawn_chapter3_0020:
        "我凝视着他迅速涨红的脸庞，渴望再听到他发出那样的声音。"
    translate None fawn_chapter3_0021:
        "我的唇缓缓从他唇上移开，顺着喉结向下，亲吻他颈间的凹陷。"
    translate None fawn_chapter3_0022:
        "他的双手搭在我肩头，不是推开而是牢牢固定着我，又发出带着喘息的气音。"
    translate None fawn_chapter3_0023:
        rs c wsur"....."
    translate None fawn_chapter3_0024:
        "他的指尖陷入我的皮肉，但并不疼痛。反倒感觉…很舒服？"
    translate None fawn_chapter3_0025:
        "我的手掠过他的胸膛，感受着阻隔在我们之间的衣料。"
    translate None fawn_chapter3_0026:
        "我并不确定自己在做什么—但…这阻止不了我想要做些什么。 "
    translate None fawn_chapter3_0027:
        "想要更加贴近他，比我曾经与任何人都更接近的距离。"
    translate None fawn_chapter3_0028:
        rs "福恩，我…我想…"
    translate None fawn_chapter3_0029:
        f "....."
    translate None fawn_chapter3_0030:
        f "你…真的确定要和我这样的人做这种事吗？"
    translate None fawn_chapter3_0031:
        rs "我只愿意和你…如果你不嫌弃我的话？"
    translate None fawn_chapter3_0032:
        f "…！怎么会嫌弃！"
    translate None fawn_chapter3_0033:
        rs c wemb"很好。那就…"
    translate None fawn_chapter3_0034:
        "当我们双唇再次相触时，他的手指稍稍放松了些。每当他发出呻吟，颤抖的唇瓣便贴着我的唇，让我脊柱发麻。"
    translate None fawn_chapter3_0035:
        "不仅如此。我的裤子突然紧绷得难受。紧贴着福恩时，我已经浑身燥热，沉醉在欢愉中。"
    translate None fawn_chapter3_0036:
        "我想..或许可以…碰碰他？就像赛恩之前告诉我的那样…"
    translate None fawn_chapter3_0037:
        "我的手指缓缓滑下他的身体，越来越往下，最终触到他裤子里逐渐勃发的硬挺。"
    translate None fawn_chapter3_0038:
        "我吃惊地缩回了手。"
    translate None fawn_chapter3_0039:
        "没想到..他居然真的因我起了反应。现在该怎么办？！"
    translate None fawn_chapter3_0040:
        "呼吸凝滞间，我撞上福恩的视线。他面颊潮红，却没有因羞耻移开目光。"
    translate None fawn_chapter3_0041:
        "他只是含糊地挤出一个词。"
    translate None fawn_chapter3_0042:
        f "雷恩…"
    translate None fawn_chapter3_0043:
        "我迟疑着再次将手覆上去，隔着布料抚摸。他又逸出一声轻吟，眼中盈满情欲。"
    translate None fawn_chapter3_0044:
        "他慢慢抬手，拉扯我的衣衫。"
    translate None fawn_chapter3_0045:
        rs "怎…怎么了？"
    translate None fawn_chapter3_0046:
        f "快点…求你…"
    translate None fawn_chapter3_0047:
        "由着他动作，他迅速扯下我的斗篷。房间透着凉意，但福恩灼热的体温足以让我温暖。"
    translate None fawn_chapter3_0048:
        "作为回应，我的动作大胆起来。当我隔着裤子描摹他阴茎轮廓时，他浑身战栗，再度加快了动作节奏。"
    translate None fawn_chapter3_0049:
        "我的衬衫敞开着，裸露的胸膛与他着衣的胸膛摩挲，激起我阵阵战栗。"
    translate None fawn_chapter3_0050:
        "不知何时，我也解开了他的衬衫，双唇游走过他的肌肤，轻咬啃吻，最后蹭上他的乳尖。"
    translate None fawn_chapter3_0051:
        "每当听见他泄出那些呜咽与呻吟，我就知道又找对了地方。"
    translate None fawn_chapter3_0052:
        "或许我从未做过这种事—但这不重要，不是吗？哪怕要花上几小时、几天、几周来摸索他最舒服的方式，我都不在乎。"
    translate None fawn_chapter3_0053:
        "只要对象是他。"
    translate None fawn_chapter3_0054:
        rs wneu "可以…吗？"
    translate None fawn_chapter3_0055:
        "得到他首肯后，我拽下他的裤子，露出早已硬挺的阴茎。"

    window hide dissolve


    scene gallery_163:
        xpos 0.12 ypos 1.2 xanchor 0.5 yanchor 1.0 zoom 1.78
    if persistent.streamer_mode == True:
        show fawn_first_sex_censor:
            xpos 0.12 ypos 1.2 xanchor 0.5 yanchor 1.0 zoom 1.78

    with dissolve

    window show dissolve
    translate None fawn_chapter3_0056:
        "正当我以为他开始害羞时，他也对我做了同样的事—剥开我层层衣物，让彼此的性器相贴。"
    translate None fawn_chapter3_0057:
        "热度惊人，仅是贴着他的感觉就让我心跳加速。"
    translate None fawn_chapter3_0058:
        f "嗯…好…硬…"
    translate None fawn_chapter3_0059:
        rs "这是你第一次…？"
    translate None fawn_chapter3_0060:
        f "是…是啊…那你—"
    translate None fawn_chapter3_0061:
        f "等等，这问题真蠢。肯定是你第一次吧…？"
    translate None fawn_chapter3_0062:
        rs "啊…对，是的。"
    translate None fawn_chapter3_0063:
        "他修长的手指轻柔地环绕着我俩的阳物，起初缓缓抚弄。"
    translate None fawn_chapter3_0064:
        "空闲的那只手用指尖掠过我的顶端，抹走前液后竟伸到自己唇边舔净。"
    translate None fawn_chapter3_0065:
        rs "你干什么…？！"
    translate None fawn_chapter3_0066:
        f "我想尝遍你每寸肌肤。"
    translate None fawn_chapter3_0067:
        rs "....."
    translate None fawn_chapter3_0068:
        scene gallery_163
        if persistent.streamer_mode == True:
            show fawn_first_sex_censor
        with dissolve
        "他饱含欲火的灼灼目光配上这句话，促使我主动出击。我握住我倆昂扬，手的套弄越来越快。"
    translate None fawn_chapter3_0069:
        rs "啊…嗯…"
    translate None fawn_chapter3_0070:
        "福恩呼吸愈发急促，我的临界感便愈加强烈。快感不断堆积，我感觉自己马上就要溃堤。"
    translate None fawn_chapter3_0071:
        rs "我..我不行了—"
    translate None fawn_chapter3_0072:
        "福恩突然掐住我肩膀的力度，仿佛在回应我的告饶，逼出我渴求的呻吟。"
    translate None fawn_chapter3_0073:
        f "还…嗯…不行…"
    translate None fawn_chapter3_0074:
        rs "还不行…？"
    translate None fawn_chapter3_0075:
        f "我…"
    translate None fawn_chapter3_0076:
        f "我想和你做更多。"
    translate None fawn_chapter3_0077:
        rs "...?"
    translate None fawn_chapter3_0078:
        "福恩早已气喘吁吁，眉头紧蹙的脸上写满焦躁。"
    translate None fawn_chapter3_0079:
        "他的顶端仍抵着我的，此刻我只想再度贴合，继续感受他的抚触。"
    translate None fawn_chapter3_0080:
        "但我耐心等待着福恩说出他真正的渴望。"
    translate None fawn_chapter3_0081:
        f "非要我说出来吗…？"
    translate None fawn_chapter3_0082:
        "见我实在不解风情，他泄出挫败的轻叹。"
    translate None fawn_chapter3_0083:
        f "…我想要你进来。"
    translate None fawn_chapter3_0084:
        rs "....."
    translate None fawn_chapter3_0085:
        rs "真的…？"
    translate None fawn_chapter3_0086:
        f "嗯。"
    translate None fawn_chapter3_0087:
        rs "我…我不太会…"
    translate None fawn_chapter3_0088:
        f "我问过赛恩…"
    translate None fawn_chapter3_0089:
        "福恩含糊的嘟囔声淹没在喘息里。"
    translate None fawn_chapter3_0090:
        rs "什么？没听清。"
    translate None fawn_chapter3_0091:
        f "我说我问了赛恩！"
    translate None fawn_chapter3_0092:
        rs "等等，真的？"
    translate None fawn_chapter3_0093:
        "他羞耻地垂头叹息。"
    translate None fawn_chapter3_0094:
        f "你真该看他当时的表情。我..我说只是好奇，结果他…！"
    translate None fawn_chapter3_0095:
        rs "他怎样？"
    translate None fawn_chapter3_0096:
        f "…他说祝我们玩得开心，还承认自己输了"
    translate None fawn_chapter3_0097:
        rs "你们在打赌…？"
    translate None fawn_chapter3_0098:
        f "....."
    translate None fawn_chapter3_0099:
        f "你真是迟钝，雷恩。"
    translate None fawn_chapter3_0100:
        f "但我就爱你这点。"
    translate None fawn_chapter3_0101:
        scene bg swroom night with dissolve
        "他突然微微坐起身，倾过身子，从外套口袋掏出一个小瓶子—里面装着某种液体。"
    translate None fawn_chapter3_0102:
        "他神情羞怯地将瓶子递到我手里。"
    translate None fawn_chapter3_0103:
        rs wsur "那是什么？"
    translate None fawn_chapter3_0104:
        f wemb "用来…让整个过程更…顺滑些…"
    translate None fawn_chapter3_0105:
        rs "...?"
    translate None fawn_chapter3_0106:
        f "....."
    translate None fawn_chapter3_0107:
        f "先倒一些在你…"
    translate None fawn_chapter3_0108:
        rs "我的…？"
    translate None fawn_chapter3_0109:
        f "…你老二上啊，天…"
    translate None fawn_chapter3_0110:
        "他脸色更红了，我却从中窥见良机。"
    translate None fawn_chapter3_0111:
        rs "像…这样？"
    translate None fawn_chapter3_0112:
        "我拧开瓶盖，将冰凉的粘稠液体缓缓倾泻在我俩身上，比想象中浓稠得多。"
    translate None fawn_chapter3_0113:
        "倒完后，我睁着狗狗眼回望福恩。"
    translate None fawn_chapter3_0114:
        rs wsmi "接着…？"
    translate None fawn_chapter3_0115:
        f "你是故意的吧？"
    translate None fawn_chapter3_0116:
        rs "才没呢！"
    translate None fawn_chapter3_0117:
        f "明明就是！"
    translate None fawn_chapter3_0118:
        rs "哈哈，也许你说得对～但永远别想知道答案！"
    translate None fawn_chapter3_0119:
        "他突然热情地攥住我，差点让我摔下床。"
    translate None fawn_chapter3_0120:
        "他圈紧手掌上下撸动，我猝不及防漏出呻吟。"
    translate None fawn_chapter3_0121:
        rs wemb "啊…"
    translate None fawn_chapter3_0122:
        f wsmi "这下安静了吧？"
    translate None fawn_chapter3_0123:
        rs "你…你也是…"
    translate None fawn_chapter3_0124:
        "我伸手想碰他，却被他拍开，他别过脸小声说："
    translate None fawn_chapter3_0125:
        f wemb "…想进来的话…得先帮我扩张…"
    translate None fawn_chapter3_0126:
        rs wneublu "…不会疼吗？"
    translate None fawn_chapter3_0127:
        f "我相信你。"
    translate None fawn_chapter3_0128:
        rs "这不算回答…"
    translate None fawn_chapter3_0129:
        f "雷恩，求你了？我想要…"
    translate None fawn_chapter3_0130:
        "他渴求的眼神烫得惊人，其实我何尝不是同样渴望。"
    translate None fawn_chapter3_0131:
        rs "那…我们慢慢来。"
    translate None fawn_chapter3_0132:
        "他点头后，我将润滑液倒在指尖，探向福恩微微张开的腿间。"
    translate None fawn_chapter3_0133:
        "手指轻触穴口的瞬间，我抬头用眼神征询他的同意。"
    translate None fawn_chapter3_0134:
        f "没…没关系…"
    translate None fawn_chapter3_0135:
        "我艰难咽了咽口水。轻点…再慢点…"
    translate None fawn_chapter3_0136:
        "当手指渐渐没入时，我惊讶于他内部的温热紧致。福恩撸弄我阴茎的手更让我险些失控。"
    translate None fawn_chapter3_0137:
        "但我忍住了。强压冲动轻轻扩张时…"
    translate None fawn_chapter3_0138:
        rs "疼吗…？"
    translate None fawn_chapter3_0139:
        f "不疼…就是有点…怪怪的…"
    translate None fawn_chapter3_0140:
        "每次当我觉得福恩即将把我推向边缘时，他就会放慢速度，用手指缓慢而折磨般地划过我的阴茎和龟头，带着戏弄般的从容。"
    translate None fawn_chapter3_0141:
        "我的手指开始加速，福恩的声调随之升高了几个八度，他越来越适应这种感觉。"
    translate None fawn_chapter3_0142:
        "借助赛恩的神秘液体，我又加进一根手指，继续着这种折磨般的缓慢节奏。"
    translate None fawn_chapter3_0143:
        "无意中我将手指向上弯曲，福恩突然发出如此响亮的呻吟，我都担心邻居随时会来敲门投诉。"
    translate None fawn_chapter3_0144:
        rs "…那是什么感觉？"
    translate None fawn_chapter3_0145:
        f "就是..就是…啊!"
    translate None fawn_chapter3_0146:
        "我不依不饶地刺激着那个让福恩脚趾蜷曲的点，他的拳头也以前所未有的速度为我套弄着。"
    translate None fawn_chapter3_0147:
        rs "舒服吗？"
    translate None fawn_chapter3_0148:
        f "嗯..啊…舒服…!"
    translate None fawn_chapter3_0149:
        "掌握这个新发现后，我戏谑地绕着他的敏感点打着圈，聆听着他美妙的呻吟在房间里回荡。"
    translate None fawn_chapter3_0150:
        f "雷恩…快点…"
    translate None fawn_chapter3_0151:
        rs "真的可以吗…？我们可以慢慢来，我不想弄疼你—"
    translate None fawn_chapter3_0152:
        f "我…我等不及了…"
    translate None fawn_chapter3_0153:
        rs "....."
    translate None fawn_chapter3_0154:
        "说实话，我也等不及了。"
    translate None fawn_chapter3_0155:
        "稍微调整姿势后，我将手指从福恩体内抽出，将龟头对准他的穴口，扶住他纤细的腰胯。"



    scene gallery_164:
        subpixel True xpos 0.5 ypos 1.17 xanchor 0.5 yanchor 1.0 zoom 1.52 rotate None
        parallel:
            xpos 0.26
            easein 8.0 xpos 0.46
    if persistent.streamer_mode == True:
        show fawn_first_sex_censor2:
            subpixel True xpos 0.5 ypos 1.17 xanchor 0.5 yanchor 1.0 zoom 1.52 rotate None
            parallel:
                xpos 0.26
                easein 8.0 xpos 0.46

    with dissolve
    translate None fawn_chapter3_0156:
        "我极其缓慢地进入他。如果说手指的感觉是炽热的，那么这个就是无限炽热与紧致。"
    translate None fawn_chapter3_0157:
        f "啊…"
    translate None fawn_chapter3_0158:
        rs "你还好吗？"
    translate None fawn_chapter3_0159:
        f "好…好的…"
    translate None fawn_chapter3_0160:
        "随着深入，我先亲吻他的左眼睑，然后是右边。他原先紧绷的面容稍稍舒展，浮现出平静的微笑。"
    translate None fawn_chapter3_0161:
        f "没关系…你可以继续…"
    translate None fawn_chapter3_0162:
        "得到他的允许后，我继续深入探索福恩的身体。当完全进入时，我恰好看到他眼角泛起泪光。"
    translate None fawn_chapter3_0163:
        rs "…!要停下来吗？!"
    translate None fawn_chapter3_0164:
        f "不，不…请不要停..我正在适应…"
    translate None fawn_chapter3_0165:
        "我极其缓慢地退出，然后再次进入。一声混杂痛苦与愉悦的呻吟从他喉咙深处溢出。"
    translate None fawn_chapter3_0166:
        f "啊!我…能感觉到你好深…"
    translate None fawn_chapter3_0167:
        "光是这句话就几乎让我失控，但我坚持着慢慢抽插，让他逐渐适应体内这个坚硬之物的感觉。"
    translate None fawn_chapter3_0168:
        "我俯下身，轻咬他的脖颈，他的整个身躯随之在我怀中战栗。"
    translate None fawn_chapter3_0169:
        scene gallery_164
        if persistent.streamer_mode == True:
            show fawn_first_sex_censor2
        with dissolve
        f "别…别留下……啊……痕迹…"
    translate None fawn_chapter3_0170:
        rs "为什么？"
    translate None fawn_chapter3_0171:
        f "我…不想让别人…这样看待你…我想独占你的这一面…"
    translate None fawn_chapter3_0172:
        "他猛然仰头喘息，我感到自己在他体内又胀大几分。终于我开始加快节奏，疯狂追逐那被压抑许久的释放。"
    translate None fawn_chapter3_0173:
        scene gallery_164
        if persistent.streamer_mode == True:
            show fawn_first_sex_censor2
        with hpunch
        f "啊！！雷…雷恩…就是那里…！"
    translate None fawn_chapter3_0174:
        "福恩彻底放弃了先前的克制，随着我一次次顶入而呻吟，终于再次触碰到那个敏感点。"
    translate None fawn_chapter3_0175:
        "他的指甲深深陷入我的皮肉，配合着他紧致内壁的挤压，我眼前泛起星光。"
    translate None fawn_chapter3_0176:
        "福恩分腿邀请我更深入，我自然不会拒绝这样的邀约。"
    translate None fawn_chapter3_0177:
        f "感…感觉好奇怪…但是好舒服…啊，雷恩…我快要坚持不住了…！"
    translate None fawn_chapter3_0178:
        rs "我…我也是。"
    translate None fawn_chapter3_0179:
        "我有些跌跌撞撞，但持续猛烈的顶弄很快让福恩化作呻吟的泥泞。他紧抓床单的指节已绷得惨白。"


    scene gallery_164b:
        xpos 0.45 ypos 1.21 xanchor 0.5 yanchor 1.0 zoom 1.59
    if persistent.streamer_mode == True:
        show fawn_first_sex_censor2:
            xpos 0.45 ypos 1.21 xanchor 0.5 yanchor 1.0 zoom 1.59
    with flash
    translate None fawn_chapter3_0180:
        "突然他全身绷紧，后穴猛然收缩，浊液溅满我们胸膛。片刻后快感顺着脊椎窜上，我在他体内颤抖着释放。"
    translate None fawn_chapter3_0181:
        "我咬紧牙关熬过余韵，随即瘫倒在福恩身上，浑身气力尽失。"


    window hide dissolve

    scene bg swroom night with dissolve
    window show dissolve
    translate None fawn_chapter3_0182:
        rs wemb "哈啊…哈啊…"
    translate None fawn_chapter3_0183:
        f wemb "哈啊……"
    translate None fawn_chapter3_0184:
        rs "刚才…哈…还舒服吗？"
    translate None fawn_chapter3_0185:
        f "何止…舒服…"
    translate None fawn_chapter3_0186:
        rs "我们搞得一团糟…"
    translate None fawn_chapter3_0187:
        f "明早再说…好困…"
    translate None fawn_chapter3_0188:
        "就这样，我们相拥着昏睡过去。"


    stop music fadeout 2.0
    window hide dissolve

    scene black with eye_shut
    pause 2.0

    if caspianaemylromance >= 1:
        $ ca_scene_one = True
        jump caspianaemylscene1
    else:
        jump morwenscene1

label fawnroute3cont:

    scene bg swroom day with eye_open
    window show dissolve
    translate None fawn_chapter3_0189:
        rs wneu "嗯…"
    translate None fawn_chapter3_0190:
        "睁眼时我终于确信昨夜不是梦境。我的手臂仍垫在福恩颈下，他正安然酣睡。"
    translate None fawn_chapter3_0191:
        "但是…我俩浑身狼藉，沾满了…"
    translate None fawn_chapter3_0192:
        "我羞愧地捂住脸。天哪，我都干了什么，昨晚该清理的。现在满屋子都是…"
    translate None fawn_chapter3_0193:
        "情欲的气息。"
    translate None fawn_chapter3_0194:
        "我怯生生地从指缝间偷看，注视着福恩胸膛的起伏渐渐趋于平稳。"
    translate None fawn_chapter3_0195:
        "我真的做到了。和福恩一起。"
    translate None fawn_chapter3_0196:
        "和…我心爱的人。"
    translate None fawn_chapter3_0197:
        "谁能想到我能与如此特别的人分享这份亲密。"
    translate None fawn_chapter3_0198:
        "我轻轻拨开他额前的碎发，露出微笑。"
    translate None fawn_chapter3_0199:
        "我真的很幸运。"
    translate None fawn_chapter3_0200:
        "谢谢你，福恩。你让我变得坚强。我知道自己该做什么了。"
    translate None fawn_chapter3_0201:
        "窗外的朝阳渐渐升起，在床单上投下斑驳光影。这种感觉令人放松而安心。"
    translate None fawn_chapter3_0202:
        "和福恩在一起的感觉就像回到了家。"
    translate None fawn_chapter3_0203:
        "我们就这个姿势待了整个清晨。或许福恩早就醒了，或许没有。我们谁都没出声。就这样相拥而卧实在太过美好。"
    translate None fawn_chapter3_0204:
        "至少在这一刻，我们可以忘掉其他所有事。"
    translate None fawn_chapter3_0205:
        "可惜这一刻终究无法成为永恒。"
    translate None fawn_chapter3_0206:
        play music "sounds/bgm/sad.ogg" fadein 2.0
        rs "我做了决定。"
    translate None fawn_chapter3_0207:
        rs "…是时候回家了，福恩。"
    translate None fawn_chapter3_0208:
        f wsmi "…我猜到你会这么说。你从不会逃避这些。"
    translate None fawn_chapter3_0209:
        "我又将他搂紧了些，指尖在他裸露的背上游走。"
    translate None fawn_chapter3_0210:
        rs "没有理由继续徘徊在这座不属于我的城市。我找到了答案，完成了旅程。"
    translate None fawn_chapter3_0211:
        f wsad "…那我们怎么办？"
    translate None fawn_chapter3_0212:
        rs "..."
    translate None fawn_chapter3_0213:
        rs "你会跟我走的，对吧？"
    translate None fawn_chapter3_0214:
        f wneu "嗯。天涯海角，只要你愿意带着我。"
    translate None fawn_chapter3_0215:
        rs wsmi "那我就确信这是个正确的决定了。只要有你在身边，任何选择都不会错。"
    translate None fawn_chapter3_0216:
        f wsmi "我倒不敢这么说，但无论对错我都会陪着你。"
    translate None fawn_chapter3_0217:
        rs wneu "要去找其他人吗？"
    translate None fawn_chapter3_0218:
        f wemb "呃…我们是不是该…先收拾一下？你把我弄得黏糊糊的…"
    translate None fawn_chapter3_0219:
        rs wemb "…！对…真的很抱歉…"
    translate None fawn_chapter3_0220:
        f "不必道歉。除非你以后都不再对我这么做才需要道歉。"
    translate None fawn_chapter3_0221:
        rs wsur "....."
    translate None fawn_chapter3_0222:
        rs wemb "或许…我们可以再多待一会儿…？"
    translate None fawn_chapter3_0223:
        f whap "哈哈哈，我是不是唤醒了雷恩体内的野兽？"
    translate None fawn_chapter3_0224:
        "他将脑袋埋进我的颈窝，手臂收得更紧些，又摇了摇头。"
    translate None fawn_chapter3_0225:
        f wsmi "真想永远和你这样依偎着…不过以后还会有时间的，对吧？"
    translate None fawn_chapter3_0226: # NSFW 1 END HERE
        rs wsmi "…是啊。你说得对。"
    translate None fawn_chapter3_0227:
        "我揉乱他的头发，在他额前落下轻吻。他绽放出明媚灿烂的笑容。"
    translate None fawn_chapter3_0228:
        "就这样，我们慢慢地从床上爬起来，清理着自己。"
    translate None fawn_chapter3_0229:
        "我们确实搞得一团糟…"
    translate None fawn_chapter3_0230:
        "当福恩穿衣时，我的目光流连在他未着寸缕的身体上。他缓缓将衣物披在身上，不知为何我竟看得入迷。"
    translate None fawn_chapter3_0231:
        "他注意到我偷瞄的眼神，但保持沉默，任由我注视着他。"
    translate None fawn_chapter3_0232:
        stop music fadeout 2.0
        "真奇怪。经历了这么多之后，为什么他穿衣的动作看起来如此…撩人？"
    translate None fawn_chapter3_0233:
        "我移开视线开始自己穿衣。随后，我们一起离开了我的房间。"


    window hide dissolve
    scene bg sw day with dissolve
    window show dissolve
    translate None fawn_chapter3_0234:
        "玄关处很暗，通往锡德卡汉的门仍然紧闭。柜台后没有人迎接我们。"
    translate None fawn_chapter3_0235:
        play music "sounds/bgm/creepy.ogg" fadein 3.0
        "奇怪…通常这时候应该大门敞开迎接客人才对。"
    translate None fawn_chapter3_0236:
        show raen nw cloak sur -blush at slightleft
        show fawn nw cloak neu at slightright
        with dissolve
        rs "现在…不算太早吧？艾琳去哪儿了？"
    translate None fawn_chapter3_0237:
        show fawn nw sur with dis
        f "…太安静了。"
    translate None fawn_chapter3_0238:
        rs "我本希望能遇见莱奥斯或赛恩…我去检查下房间，你在这儿等着。"
    hide raen with dissolve
    show fawn at center with move
    translate None fawn_chapter3_0239:
        "我快速查看了莱奥斯的房间。刚握住门把手门就开了，里面是…"
    translate None fawn_chapter3_0240:
        "空无一人。"
    translate None fawn_chapter3_0241:
        "…他离开时该锁门的，真是的。"
    translate None fawn_chapter3_0242:
        "我回到福恩身边摇摇头。"
    translate None fawn_chapter3_0243:
        show fawn at slightright with move
        show raen nw neu cloak at slightleft with dissolve
        rs "哪儿都找不到人。希望路上能碰见他们吧。现在我们先回去找说书人和卡斯皮安。"
    translate None fawn_chapter3_0244:
        f "…你不觉得奇怪吗？"
    translate None fawn_chapter3_0245:
        "我摇摇头。确实感觉不对劲，但现在我最不需要的就是节外生枝。"


    window hide dissolve
    scene bg sc grey with dissolve
    window show dissolve
    translate None fawn_chapter3_0246:
        "天色阴沉，暗灰云层自地平线翻涌而来。街道昏暗空旷，毫无生气。"
    translate None fawn_chapter3_0247:
        "雪终于停了片刻，只有零星雪点从天空飘落。"
    translate None fawn_chapter3_0248:
        "当我走过空荡的街道时，一种压倒性的恐惧感袭来—却说不出确切缘由。"
    translate None fawn_chapter3_0249:
        "因为太安静？"
    translate None fawn_chapter3_0250:
        "因为一切都仿佛…停滞了？"
    translate None fawn_chapter3_0251:
        "不…是因为这让我想起奥克斯哈伯。店铺紧闭，街上杳无人烟。"
    translate None fawn_chapter3_0252:
        rs c wsur "…可能确实有点古怪。"
    translate None fawn_chapter3_0253:
        f c wsad "大家都去哪儿了？"
    translate None fawn_chapter3_0254:
        "嗯…"
    translate None fawn_chapter3_0255:
        "我们小心翼翼地朝蚀走去，一路上警惕地寻找着某个人—不，任何人。"
    translate None fawn_chapter3_0256:
        "寒风吹过街道，卷起枯叶。落叶在我们周围飞舞，仿佛想要追随我们。"

    window hide dissolve

    jump meetlucius
