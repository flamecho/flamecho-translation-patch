label chapter_eight_start:
    window hide
    menu:
        "提议坐到前面去":
            window show dissolve
            jump wagon_front

        "提议让福恩坐到前面":
            window show dissolve
            $ leos_relationship +=1
            jump wagon_fawn

        "提议让莱奥斯坐到前面":
            window show dissolve
            $ fawn_relationship +=1
            jump wagon_leos

        "好吧，那我们就先休息了":
            window show dissolve
            jump wagon_sleep


label wagon_front:
    show raen n smi with dis
    translate None chapter_eight_0001:
        rs "要不我到前面陪你一会儿？"
    translate None chapter_eight_0002:
        rs "你们三个可以先休息。"
    translate None chapter_eight_0003:
        lil "请便。"
    show fawn n neu with dis
    translate None chapter_eight_0004:
        f "你确定…？你不也很累吗？"
    show raen n neu with dis
    translate None chapter_eight_0005:
        rs "目前还行。等累了我会记得休息的。"
    show leos n neu with dis
    translate None chapter_eight_0006:
        "莱奥斯凑近我的耳边。"
    translate None chapter_eight_0007:
        l "说话小心点。他看起来像是在睡觉，但我觉得未必。"
    show raen n sad with dis
    translate None chapter_eight_0008:
        rs "好吧…"



    scene bg wagon night with dissolve:
        xpos 0.5 ypos 1.11 xanchor 0.7 yanchor 0.84 zoom 1.7

    translate None chapter_eight_0009:
        "我爬到前面和莱拉斯坐在一起。"
    show raen m dim neu at closeright
    show lilas m dim smi2 at closeleft
    with Dissolve(1.0)
    translate None chapter_eight_0010:
        rs "嘿。"
    translate None chapter_eight_0011:
        lil "你好。"
    translate None chapter_eight_0012:
        "嗯…聊点什么好呢…"
    translate None chapter_eight_0013:
        "我们沉默地坐了几分钟，但并不觉得尴尬。我觉得她是个话不多的女人。"
    translate None chapter_eight_0014:
        rs "那么…我在想…"
    translate None chapter_eight_0015:
        rs "你驾驶这辆马车多久了？"
    translate None chapter_eight_0016:
        lil "这辆？三年了。这是我人生中最快乐的三年。"
    translate None chapter_eight_0017:
        rs "真的吗？那之前是做什么的？"
    show lilas m dim sad with dis
    translate None chapter_eight_0018:
        lil "…以前在奥克斯哈伯的本地学校上学。后来发现自己不适合。"
    translate None chapter_eight_0019:
        rs "不适合吗？"
    translate None chapter_eight_0020:
        lil "很迷茫。感觉身边每个人都在进步，只有我停滞不前…但我不想让家人失望。"
    translate None chapter_eight_0021:
        lil "家里人把所有积蓄都投在我的教育上。他们说我将会是带给他们荣耀和幸福的人。每天都背负着这种期待。"
    translate None chapter_eight_0022:
        lil "所以又多读了一年。后来亲友说我看起来像个空壳。当时不懂\"空壳\"是什么意思，但我想改变。"
    translate None chapter_eight_0023:
        lil "当我终于说出真实感受时，他们为我流泪。说我的快乐比什么都重要。"

    $ about_Lilas._text.append("在创业买马车前，她就读于奥克斯哈伯的学校。听起来经历很艰难，但最终走了出来，现在很快乐。")
    translate None chapter_eight_0024:
        lil "于是我决定旅行。{a=set_entry:enc_people->about_Lilas}{color=#87CEEB}我退了学{/color}{/a}，买了这辆马车开始做小生意。只要可能都亲自送货。"
    show raen m dim sur with dis
    translate None chapter_eight_0025:
        rs "有帮助吗？"
    show lilas m dim smi2 with dis
    translate None chapter_eight_0026:
        "她微微笑了笑。"
    translate None chapter_eight_0027:
        lil "你说呢？"
    translate None chapter_eight_0028:
        "我可能会用\"疏离\"而非\"空虚\"来形容她。看来这就是答案了。"
    show lilas m neu with dis
    translate None chapter_eight_0029:
        lil "那你呢？"
    translate None chapter_eight_0030:
        rs "我？"
    translate None chapter_eight_0031:
        rs "我…我在自己长大的孤儿院帮了一辈子忙。现在，我想你可以说我也在旅行。"
    show lilas m smi1 with dis
    translate None chapter_eight_0032:
        lil "嗯。知识充实头脑，旅行滋养灵魂。两者都很重要，但你必须找到适合自己的平衡点。"
    show raen m dim smi with dis
    translate None chapter_eight_0033:
        rs "这个观点很不错。"
    show raen m dim neu with dis
    show lilas m neu with dis
    translate None chapter_eight_0034:
        rs "那么，奥克斯哈伯是什么样的地方？"
    show lilas m dim ang with dis
    translate None chapter_eight_0035:
        lil "奥克斯哈伯…它是…"
    translate None chapter_eight_0036:
        lil "…在内心深处，那是个美丽的地方。抛开那些污垢和政治。"
    translate None chapter_eight_0037:
        lil "最近…发生了一些怪事。我先提醒你，如果你打算留在那里—要小心。"
    translate None chapter_eight_0038:
        "我探头望向马车后部。他们三个已经睡得很熟了。"
    translate None chapter_eight_0039:
        rs "等他们醒了我会告诉他们。他们已经睡得很熟了。"
    show lilas m dim neu with dis
    translate None chapter_eight_0040:
        lil "你似乎跟他们很亲近，但和每个人亲近的方式都不一样。"
    translate None chapter_eight_0041:
        rs "我们几天前才刚认识，但感觉就像认识了很久。我觉得我和福恩相处得很自然。至于莱奥斯，我们一开始相处得不太好，但现在我感觉我们也变得更亲近了。"
    translate None chapter_eight_0042:
        rs "我信任他们两个。不过别告诉莱奥斯我跟你说了这话。"
    show raen m dim sad with dis
    translate None chapter_eight_0043:
        rs "啊，至于那个绿头发的家伙—我跟他真的不熟。很抱歉他就这么跳上车了。"
    translate None chapter_eight_0044:
        lil "一个吃白食的还是五个，对我来说没什么区别。"
    show lilas m smi2 with dis
    translate None chapter_eight_0045:
        lil "告诉我，他们中间有谁对你来说很特别吗？"
    show raen m dim sur with dis
    translate None chapter_eight_0046:
        rs "特别？这个…"

    window hide

    menu:
        "我想莱奥斯对我来说很特别":
            $ leos_relationship +=1
            window show dissolve
            jump leos_special

        "我和福恩一见如故":
            $ fawn_relationship +=1
            window show dissolve
            jump fawn_special

        "也许我还没遇到那个人":
            $ cyne_relationship +=1
            window show dissolve
            jump cyne_special

        "他们两个对我来说都很特别":
            window show dissolve
            jump both_special

label leos_special:
    show raen m dim neu with dis
    translate None chapter_eight_0047:
        rs "莱奥斯…我觉得他对我来说变得特别了。"
    translate None chapter_eight_0048:
        rs "我们有时会吵架，但他总是支持我。我很高兴我们能成为朋友。"
    jump wagon_front_cont

label fawn_special:
    show raen m dim neu with dis
    translate None chapter_eight_0049:
        rs "我觉得我和福恩能够深深理解彼此。他对我来说很特别。"
    translate None chapter_eight_0050:
        rs "有时候我觉得我需要保护他，但通常反而是他在保护我…"
    jump wagon_front_cont

label cyne_special:
    show raen m dim neu with dis
    translate None chapter_eight_0051:
        rs "我不确定。他们对我都很重要，但也许我还没遇到那个真正特别的人。"
    translate None chapter_eight_0052:
        rs "我想特别的人可能是任何人。甚至只是你在街上偶遇的某个人。"
    jump wagon_front_cont

label both_special:
    show raen m dim neu with dis
    translate None chapter_eight_0053:
        rs "他们两个对我来说既重要又特别。如果没有他们，我不会在这里。"
    jump wagon_front_cont

label wagon_front_cont:
    show lilas m dim smi2 with dis
    translate None chapter_eight_0054:
        lil "…真好。被信任的人环绕是很重要的。如果没有我那些特别的人，我也不会是现在的我。"

    scene bg wagon night with dis
    translate None chapter_eight_0055:
        rs yaw "哈~~~欠。"
    translate None chapter_eight_0056:
        lil smi2 "你一定累了。该去和朋友们会合休息了。等你们醒来时，我们应该就到目的地了。"
    translate None chapter_eight_0057:
        rs neu "你确定你没事吗？"
    translate None chapter_eight_0058:
        lil smi2 "当然。晚安。"
    translate None chapter_eight_0059:
        "我爬回莱奥斯和福恩睡觉的地方，找了个舒服的姿势。看来今晚的睡眠会不太安稳…"

    window hide dissolve
    jump choice_thirteen_done

label wagon_fawn:
    translate None chapter_eight_0060:
        "或许福恩需要些新鲜空气，他之前看起来有点心烦。"
    show raen n dim sur with dis
    translate None chapter_eight_0061:
        rs "嘿福恩，你还好吗？"
    show fawn n dim sad with dis
    translate None chapter_eight_0062:
        f "嗯…"
    translate None chapter_eight_0063:
        "他看起来有些疏离。"
    show raen n dim sad with dis
    translate None chapter_eight_0064:
        rs "也许你该出去透透气，你看起来有点紧张。"
    translate None chapter_eight_0065:
        f "哦…呃…"
    translate None chapter_eight_0066:
        f "好吧…我想可以…"
    hide fawn n dim with dissolve
    show raen m dim neu at closeleft
    show leos m dim neu at closeright
    with Dissolve(1.0)
    translate None chapter_eight_0067:
        "他朝莱奥斯的方向短暂瞥了一眼，走出马车前部去和莱拉斯坐在一起。"

    translate None chapter_eight_0068:
        "我尴尬地坐在莱奥斯旁边，不确定该睡在哪里。"
    translate None chapter_eight_0069:
        l "你能不能别这么坐立不安？累了就直接睡觉。"
    show raen m dim sad with dis
    translate None chapter_eight_0070:
        rs "….不用这么暴躁。"
    show leos m dim smi with dis
    translate None chapter_eight_0071:
        l "为什么不？看看我的处境。每天情况都在变糟。"
    translate None chapter_eight_0072:
        "那个狐狸般的男人发出轻微的鼾声。睡得真快。"
    translate None chapter_eight_0073:
        rs "你该知足了…至少我们搭上了便车。"
    show leos m dim neu with dis
    translate None chapter_eight_0074:
        l "如果不是捡了这个流浪汉，也许我会感激。"
    translate None chapter_eight_0075:
        l "我不想被人群包围。感觉不对劲。"
    show raen m dim sur with dis
    translate None chapter_eight_0076:
        rs "…不对劲？为什么？"
    translate None chapter_eight_0077:
        l "你不需要知道。"
    translate None chapter_eight_0078:
        "我在想…这和他的工作有关吗？他很少提起这个。"
    translate None chapter_eight_0079:
        "我承认，初次见面时我对他毫无兴趣。但现在我看穿了他的刻薄、态度和冷漠。他这个人没那么简单。"
    window hide

    menu:
        "无论发生过什么都是往事":
            window show dissolve
            $ fawn_relationship -=1
            jump leos_past

        "它已成为你的一部分":
            window show dissolve
            $ leos_relationship +=1
            jump leos_part

        "你知道吗…在月光下…":
            window show dissolve
            $ leos_relationship +=2
            jump leos_moon

label leos_past:
    show raen m dim sad with dis
    translate None chapter_eight_0080:
        rs "…无论发生过什么，不都已经过去了吗？我不明白你为什么非要独处，但你不必再为此烦恼了。"
    translate None chapter_eight_0081:
        l "烦恼？我没有在烦恼。是你在烦恼吗？"
    translate None chapter_eight_0082:
        rs "我们都得努力向前看。我正在尝试，我知道你也可以。"
    translate None chapter_eight_0083:
        rs "我们可以一起前行。"
    show leos m dim neu with dis
    translate None chapter_eight_0084:
        l "….这可能是你的想法，但我无意向前。"
    show leos m pen with dis
    translate None chapter_eight_0085:
        l "我的过去永远影响着未来。再怎么努力向前都无法改变这点。"
    translate None chapter_eight_0086:
        l "过去总会卷土重来。不过谢谢你对我内心的剖析，我很感激。"
    translate None chapter_eight_0087:
        rs "哦…"

    hide leos m dim
    hide raen m dim
    show bg wagon:
        size(1920, 1080)
    with dissolve
    translate None chapter_eight_0088:
        "他别过脸去。也许我不该那样说…"
    translate None chapter_eight_0089:
        "随着马车缓缓左右摇晃，我在想着莱奥斯的过程中睡着了。"
    window hide dissolve
    jump choice_thirteen_done

label leos_part:
    show raen m dim neu with dis
    translate None chapter_eight_0090:
        rs "我不介意。毕竟，这也是你故事的一部分。"
    translate None chapter_eight_0091:
        rs "我想更了解你。"
    show leos m dim neu with dis
    translate None chapter_eight_0092:
        l "....."
    translate None chapter_eight_0093:
        l "你真是个笨蛋。明知会受伤为什么还要什么事都掺和？"
    translate None chapter_eight_0094:
        l "你总是这样莽撞地卷入与己无关的事。"
    translate None chapter_eight_0095:
        rs "我依然想知道。"
    translate None chapter_eight_0096:
        "我直视着他的眼睛，保持着目光接触。我需要让他明白我说的每一个字。我希望他能够信任我。"
    translate None chapter_eight_0097:
        l "....."
    translate None chapter_eight_0098:
        l "现在不行。"
    translate None chapter_eight_0099:
        "他瞥了一眼坐在我们对面的鼾声大作的男人。"
    translate None chapter_eight_0100:
        l "….下次吧，如果你运气好的话。"
    show raen m dim sad with dis
    translate None chapter_eight_0101:
        rs "好吧.."
    show leos m dim smi with dis
    translate None chapter_eight_0102:
        l "别这么垂头丧气的。\"也许\"并不代表\"不\"。"
    translate None chapter_eight_0103:
        rs "…那就当作约定吧。"
    translate None chapter_eight_0104:
        l "…到时候再说。"
    show raen m dim smi with dis
    translate None chapter_eight_0105:
        rs "我相信你。"
    translate None chapter_eight_0106:
        "他脸颊上泛起的淡淡红晕有点出乎意料。"
    translate None chapter_eight_0107:
        "还挺…可爱的。"
    translate None chapter_eight_0108:
        "等-等等…什么？我在想什么？"
    show leos m dim neu with dis
    translate None chapter_eight_0109:
        l "…算了。"
    translate None chapter_eight_0110:
        l "睡觉。我需要休息。你也是。"
    translate None chapter_eight_0111:
        "当他开口时，一种温暖的感觉充盈在我胸口。我不知道为什么。"
    translate None chapter_eight_0112:
        "但感觉很美好。"
    translate None chapter_eight_0113:
        rs "晚安，莱奥斯…"
    window hide dissolve
    jump choice_thirteen_done

label leos_moon:
    show raen m dim smi with dis
    translate None chapter_eight_0114:
        rs "你知道吗莱奥斯…在月光下你的头发简直像在发光。真的美极了！"
    show leos m dim emb with dis
    translate None chapter_eight_0115:
        l "呃…"
    translate None chapter_eight_0116:
        rs "抱歉，我是不是说过头了？"
    translate None chapter_eight_0117:
        l "不…不是，只是…"
    translate None chapter_eight_0118:
        l "你突然说这个干什么？"
    show raen m dim sur with dis
    translate None chapter_eight_0119:
        rs "等-等等，你现在是在害羞吗？"
    translate None chapter_eight_0120:
        "一瞬间他的脸又红了好几分。"
    translate None chapter_eight_0121:
        "或许该轮到我小小捉弄他一下了？他总是这样戏弄福恩和我…"
    translate None chapter_eight_0122:
        l "不，我为什么要害羞？"
    translate None chapter_eight_0123:
        "谁能想到莱奥斯会露出这种表情…不知道如果我…"
    show raen m dim smi at closeleft2
    show leos m dim at closeright2
    with move
    translate None chapter_eight_0124:
        rs "你的头发总是这么柔顺有光泽。"
    translate None chapter_eight_0125:
        rs "还有这个长度…真不知道你是怎么保养的。"
    translate None chapter_eight_0126:
        "我伸手捻起一缕他的发丝。"
    translate None chapter_eight_0127:
        rs "…而且好柔软。"
    translate None chapter_eight_0128:
        l "....."
    translate None chapter_eight_0129:
        rs "说真的，你是怎么保持得这么好的？"
    translate None chapter_eight_0130:
        l "....."
    translate None chapter_eight_0131:
        "现在他连耳尖都泛着红。"
    translate None chapter_eight_0132:
        rs "我的就没这么软，你看？"
    translate None chapter_eight_0133:
        "我抓着他的手臂，把他的手放在我头顶。这种重量感很舒服。"
    translate None chapter_eight_0134:
        l "......"
    translate None chapter_eight_0135:
        rs "看到了吗？"
    translate None chapter_eight_0136:
        "真奇怪，有些东西既能让人平静，又会让心跳加速。"
    translate None chapter_eight_0137:
        l "你的…你的也很柔软啊…"
    translate None chapter_eight_0138:
        l "……我们该休息了。"
    translate None chapter_eight_0139:
        "我觉得他今天被捉弄得差不多了。再多一点，他可能会爆炸。"
    translate None chapter_eight_0140:
        "但能看到他那一脸困惑的样子还是挺不错的，难得一次。"
    translate None chapter_eight_0141:
        rs "哦，对啊！"

    hide leos m dim
    hide raen m dim
    with dissolve

    translate None chapter_eight_0142:
        "我松开他的头发，向后挪了挪，这时莱奥斯的手也从我头上移开。我向后靠去，闭上眼睛准备休息。"
    translate None chapter_eight_0143:
        "不过，我还是能感觉到他的目光落在我身上。"
    translate None chapter_eight_0144:
        "感觉过了好久之后，我听到他叹了口气，翻身调整睡姿。"

    window hide dissolve
    jump choice_thirteen_done


label wagon_leos:
    show raen n dim neu with dis
    translate None chapter_eight_0145:
        rs "莱奥斯，你要不要到前面坐一会儿？"
    show leos n dim sur with dis
    translate None chapter_eight_0146:
        l "什么，为什么？"
    translate None chapter_eight_0147:
        rs "呃，你看起来没那么累，而且我们都睡着免费搭车不太礼貌…"
    translate None chapter_eight_0148:
        l "所以你是要让我保持清醒。真棒。你的好心总是让我惊讶。"

    hide leos n dim
    hide raen n dim
    hide fawn n dim
    with dis
    show fawn m dim sad at closeleft2
    show raen m dim neu at closeright2
    with dissolve
    translate None chapter_eight_0149:
        "他一路抱怨个不停，但还是爬到了前面。他变得真的很听话。"
    translate None chapter_eight_0150:
        "福恩看起来还是有点恍惚。我不想在莱奥斯面前小题大做，但现在我们独处了，或许他会说些什么。"
    translate None chapter_eight_0151:
        rs "嘿，福恩…？"
    translate None chapter_eight_0152:
        "我压低声音，这样其他人就听不见了。"
    translate None chapter_eight_0153:
        "我轻轻地把手放在他的手臂上。"
    show fawn m dim sur with dis
    show fawn m dim sur at shake
    translate None chapter_eight_0154:
        f "嗯？！"
    show raen m dim sur with dis
    translate None chapter_eight_0155:
        rs "哇啊！你还好吗？"
    show fawn m dim sad with dis
    translate None chapter_eight_0156:
        f "我…没事…"
    show raen m dim sad with dis
    translate None chapter_eight_0157:
        rs "但你看上去不太对劲…"
    translate None chapter_eight_0158:
        rs "是她说的什么话让你困扰了？还是他说的？"
    translate None chapter_eight_0159:
        "我朝那个发出轻微鼾声、长得像狐狸的男人点了点头。"
    translate None chapter_eight_0160:
        "莱拉斯说了什么？好像是关于一个叫克利夫斯派尔的地方？"
    translate None chapter_eight_0161:
        rs "是关于克利夫斯派尔的事吗？"
    translate None chapter_eight_0162:
        "听到这话，他整个身子都僵住了。"
    translate None chapter_eight_0163:
        rs "你是不是知道些什么？"
    show fawn m dim hur with dis
    translate None chapter_eight_0164:
        f "不-不知道！我不…知道…"
    translate None chapter_eight_0165:
        rs "好了好了，我相信你。"
    translate None chapter_eight_0166:
        "我用指尖在他背上轻轻画圈。肯定有什么事，但现在可能不是聊这个的合适时机。"
    translate None chapter_eight_0167:
        "在我的安抚下，他停止了颤抖，但依然沉默。"
    translate None chapter_eight_0168:
        "我能做些什么来帮你…"
    show fawn m dim sad with dis
    translate None chapter_eight_0169:
        f "什么…"
    translate None chapter_eight_0170:
        f "如果我们找到这个人…你打算怎么办？"
    translate None chapter_eight_0171:
        rs "我打算怎么办？"
    translate None chapter_eight_0172:
        rs "嗯…我会问问他关于我的神之刻印，还有奥雷利亚卡维拉的事。希望他知道些什么。"
    translate None chapter_eight_0173:
        rs "我会问他怎么知道外界的事情，还有说书人是否知情。"
    translate None chapter_eight_0174:
        rs "我只是想找出一些答案。"
    translate None chapter_eight_0175:
        f "然后呢，如果他真的知道呢？"
    translate None chapter_eight_0176:
        f "那之后呢？"
    translate None chapter_eight_0177:
        rs "我…还没想那么远…"
    translate None chapter_eight_0178:
        f "...."
    translate None chapter_eight_0179:
        f "你会…回去吗？留下来？"
    translate None chapter_eight_0180:
        rs "我不知道…"
    translate None chapter_eight_0181:
        f "...."
    translate None chapter_eight_0182:
        "他凝视着远方。那眼神…满是痛苦与孤独。"
    translate None chapter_eight_0183:
        "我是不是说错话了？"


    window hide
    menu:
        "我不会丢下你一个人":
            window show dissolve
            jump fawn_lalone

        "你之前是不是经历过什么？":
            $ fawn_relationship +=1
            window show dissolve
            jump fawn_before

        "…月光下的你真美":
            $ fawn_relationship +=2
            window show dissolve
            jump fawn_moon

label fawn_lalone:
    translate None chapter_eight_0184:
        rs "无论我去哪里…我都希望你能一起，知道吗？我不会把你丢在任何地方。"
    translate None chapter_eight_0185:
        f "….我害怕。"
    translate None chapter_eight_0186:
        rs "害怕什么？"
    translate None chapter_eight_0187:
        f "害怕你在撒谎，又害怕你说的是真话。"
    translate None chapter_eight_0188:
        "什么…？"
    translate None chapter_eight_0189:
        rs "我不想要你害怕。我希望你相信我。"
    jump fawn_wagon_cont

label fawn_before:
    translate None chapter_eight_0190:
        rs "你…你之前是不是发生过什么事？"
    translate None chapter_eight_0191:
        f "...."
    translate None chapter_eight_0192:
        rs "我不会让任何人伤害你，好吗？"
    translate None chapter_eight_0193:
        rs "我保证。"
    translate None chapter_eight_0194:
        rs "我会竭尽全力保护你的安全。"
    jump fawn_wagon_cont

label fawn_moon:
    show raen m dim sur with dis
    translate None chapter_eight_0195:
        rs "嘿，之前一直没机会说…"
    translate None chapter_eight_0196:
        rs "当月光映在你的脸庞上时，真的很美。"
    show fawn m dim emb with dis
    translate None chapter_eight_0197:
        f "什…什么？！美？说我吗？"
    translate None chapter_eight_0198:
        f "不…不可能！"
    translate None chapter_eight_0199:
        "他把发红的脸埋进手掌里。至少这样比刚才的悲伤表情要好些。"
    show raen m dim smi with dis
    translate None chapter_eight_0200:
        rs "不，真的…你美得惊人。"
    translate None chapter_eight_0201:
        rs "你有种与众不同的宁静气质。"
    translate None chapter_eight_0202:
        "我把手放在他的手背上轻轻握了握。"
    translate None chapter_eight_0203:
        rs "我会保护好你的，好吗？"
    translate None chapter_eight_0204:
        f "嗯…"

    jump fawn_wagon_cont

label fawn_wagon_cont:
    show fawn m dim neu with dis
    translate None chapter_eight_0205:
        f "我累了…想休息会儿.."
    translate None chapter_eight_0206:
        "马车后厢虽不豪华，但至少有足够空间让人靠坐着稍作休憩。"
    show raen m dim neu with dis
    translate None chapter_eight_0207:
        rs "你不该这样怀疑自己。我们是朋友，我会永远照顾你。"
    translate None chapter_eight_0208:
        f "......"
    translate None chapter_eight_0209:
        f "如果我做了坏事呢？那时怎么办？"
    translate None chapter_eight_0210:
        rs "嗯…"
    translate None chapter_eight_0211:
        rs "你不会无缘无故做坏事。我不会抛弃你的。"
    translate None chapter_eight_0212:
        rs "所以振作点。这是场大冒险，谁知道明天会发生什么。"
    translate None chapter_eight_0213:
        "他闭眼入睡时的面容…既不算悲伤，也不算孤独或愤怒…"
    translate None chapter_eight_0214:
        "我想那是人类最本真的样子。脆弱，却也坚强。"
    translate None chapter_eight_0215:
        "我轻轻揉了揉他柔软的头发，随后也闭上了眼睛。"

    window hide
    jump choice_thirteen_done

label wagon_sleep:
    show raen n dim neu with dis
    translate None chapter_eight_0216:
        rs "看来我们接受你的提议了。我累坏了。"
    translate None chapter_eight_0217:
        f "我也累了…"

    hide raen n dim
    hide leos n dim
    hide fawn n dim
    with dissolve

    translate None chapter_eight_0218:
        "莱奥斯打量着那个打着轻柔鼾声的绿发男子。其实连我也有点担心和他同睡，但现在也没别的办法。"
    translate None chapter_eight_0219:
        "他很快放弃了纠结，双臂交叉在胸前闭上了眼睛。"
    translate None chapter_eight_0220:
        "斯塔格威奇。我们没在那待多久，但那里太棒了。那里的人、食物，还有风景。"
    translate None chapter_eight_0221:
        "希望有一天我能重返那里。"
    translate None chapter_eight_0222:
        rs smi "你们两位呢？"
    translate None chapter_eight_0223:
        rs smi "谢谢。"
    translate None chapter_eight_0224:
        "真高兴我不是孤身一人。"
    translate None chapter_eight_0225:
        "我闭上眼睛慢慢沉入梦乡，马车轻柔的摇晃更助我入睡。"
    window hide dissolve
    jump choice_thirteen_done

label choice_thirteen_done:
    stop music fadeout 2.0
    scene black with eye_shut
    pause(0.5)
    scene bg tavern with eye_open:
        size (1920, 1080)
    window show dissolve
    show nikos n smi at center with dis
    translate None chapter_eight_0226:
        nik "这真是漫长的一天。我寻思该收拾收拾回家了。"
    play sound "sounds/sfx/knock.ogg" fadeout 1
    show nikos n sur with dis
    translate None chapter_eight_0227:
        nik "喂？"
    show nikos n sca with dis
    translate None chapter_eight_0228:
        nik "什-"
    window hide dissolve


    scene black at shake:
        size (1920, 1080)
    pause(2.0)
    translate None chapter_eight_0229:
        n "…..跟..随.."
    translate None chapter_eight_0230:
        n "…..救….我们…"
    translate None chapter_eight_0231:
        n "…..自由….注视.."


    window show dissolve
    translate None chapter_eight_0232:
        rs "嗯…"
    translate None chapter_eight_0233:
        f "…..醒醒…"
    translate None chapter_eight_0234:
        f "嘿…雷恩…"
    translate None chapter_eight_0235:
        l "喂，醒醒！"


    scene bg wagon ox with eye_open:
        size(1920, 1080)
    window show dissolve
    show raen m sur at shakecen
    translate None chapter_eight_0236:
        rs "哇啊！"
    translate None chapter_eight_0237:
        rs "醒了醒了！"

    scene bg wagon ox with dis2:
        size(1920, 1080)
    show leos n smi at right
    show raen n sur at center
    show fawn n neu at left
    with dis2

    translate None chapter_eight_0238:
        l "你可算醒了。做美梦呢？"
    show raen n sad with dis
    translate None chapter_eight_0239:
        rs "呃…"
    translate None chapter_eight_0240:
        rs "我们到哪了…？"
    show leos n neu with dis

    if achievement.has("reach_oxhabor"):
        pass
    else:
        $ renpy.display_notify("成就解锁：天边乌云")

    python:
        achievement.grant("reach_oxhabor")
        achievement.sync()

    translate None chapter_eight_0241:
        l "奥克斯哈伯。要是之前我们叫醒你的那上百次里任意一次你醒过来，早该知道了。"
    show raen n sad with dis
    translate None chapter_eight_0242:
        rs "抱歉…."
    translate None chapter_eight_0243:
        l "那个烦人的混蛋已经走了。趁我们都没醒就溜了。"
    translate None chapter_eight_0244:
        "我把头探出马车。这就是奥克斯哈伯啊。"
    translate None chapter_eight_0245:
        "氛围和斯塔格威奇完全不同。街道寂静，天色阴暗。"
    translate None chapter_eight_0246:
        rs "咦，莱拉斯去哪了？"
    translate None chapter_eight_0247:
        f "她说有要事处理…不过可能会在附近遇见她。"
    translate None chapter_eight_0248:
        f "那个…你们没觉得这里…有点不对劲吗？"
    translate None chapter_eight_0249:
        l "太安静了…"
    translate None chapter_eight_0250:
        l "安静得有点瘆人。"
    translate None chapter_eight_0251:
        rs "可能大伙儿都还在睡觉？"
    translate None chapter_eight_0252:
        l "....."
    translate None chapter_eight_0253:
        l "也许吧。不过可不是谁都像你这么能睡。"
    translate None chapter_eight_0254:
        "我跳下马车，仔细打量我们所在的地方。"

    window hide dissolve

    $ about_Oxhabor.image = "gui/codex/entries/places/enc_oxhabor.jpg"

    scene bg oxhabor day with fade:
        xanchor 0.3 yanchor 0.43 zoom 2.0
        easein 40.0 yanchor 0.05
    #pause(2.5)
    #scene bg oxhabor day with Dissolve(1)

    window show dissolve
    play music "sounds/bgm/creepy.ogg" fadein 2.0
    translate None chapter_eight_0255:
        "我们被扔在一条昏暗空旷的街道上，毫无生气。干燥的风吹得窗框咯吱作响，栅栏发出沉闷的呻吟。"
    translate None chapter_eight_0257:
        "斯塔格威奇的鲜活气息荡然无存。"

    scene bg oxhabor day with dissolve:
        xanchor 0.3 yanchor 0.43 zoom 2.0
    show raen n dim neu at center
    show leos n dim neu at right
    show fawn n dim neu at left
    with dissolve

    translate None chapter_eight_0258:
        rs "呃，我确信这里的居民也很友善。"
    show raen n dim sad with dis
    translate None chapter_eight_0259:
        rs "从哪开始找？总不能挨家挨户敲门问…"
    translate None chapter_eight_0260:
        l "跟我来。"
    show raen n dim sur with dis
    translate None chapter_eight_0261:
        rs "你怎么知道该往哪走？"
    translate None chapter_eight_0262:
        l "不知道，但跟着我肯定比跟着你惹的麻烦少。"
    translate None chapter_eight_0263:
        f "那个…大家…"
    translate None chapter_eight_0264:
        f "看。"
    translate None chapter_eight_0265:
        "福恩不动声色地微微侧头示意。我顺着望去…"
    translate None chapter_eight_0266:
        "看见无数眼睛。从周围每扇窗户后窥探的眼睛。"
    show raen n dim sad with dis
    translate None chapter_eight_0267:
        rs "他们是在…监视我们…？"
    translate None chapter_eight_0268:
        l "这地方肯定有问题。"
    translate None chapter_eight_0269:
        l "这边走。"
    scene black with dis
    translate None chapter_eight_0270:
        "莱奥斯拽着我们两人的胳膊钻进一条小巷，躲开了那些窥探的视线。"


    scene bg ox alley with Dissolve(1)
    show raen n dim sad at center
    show leos n dim neu at right
    show fawn n dim sad at left
    with dissolve

    translate None chapter_eight_0271:
        rs "他们为什么要那样盯着我们看？！"
    translate None chapter_eight_0272:
        l "不知道，但总感觉不对劲。"
    translate None chapter_eight_0273:
        "我忍不住想起昨晚的梦…要是能记清楚就好了！"
    translate None chapter_eight_0274:
        "被跟踪…？被监视…？"
    translate None chapter_eight_0275:
        "我环顾四周，明明没有人。却总觉得有眼睛在盯着我。"
    translate None chapter_eight_0276:
        rs "你觉得…该不会有人跟踪我们吧？"
    translate None chapter_eight_0277:
        l "说不准。不是没可能。"
    translate None chapter_eight_0278:
        l "先往后巷走吧。"
    translate None chapter_eight_0279:
        f "总会遇到友善的人…对吧？"
    show leos n dim smi with dis
    translate None chapter_eight_0280:
        l "别立这种flag行不行？"
    stop music fadeout 2.0
    translate None chapter_eight_0281:
        u "小伙子们看起来需要些新装备呢。"
    show raen n dim sur with dis
    translate None chapter_eight_0282:
        rs "啊？"
    translate None chapter_eight_0283:
        "在两条巷道的交叉口，一位留着黑色长发的女士叫住了我们。她穿着紧身闪亮的衣服。"
    show leos n dim neu with dis
    translate None chapter_eight_0284:
        l "装备？"
    translate None chapter_eight_0285:
        u "是啊。我看见你带的鞭子了，我店里肯定有你们感兴趣的东西。"
    translate None chapter_eight_0286:
        rs "真有我们能用的东西？当真？"
    translate None chapter_eight_0287:
        u "当然。我们店专营情趣用品，双人单人的都有。"
    translate None chapter_eight_0288:
        f "那个…伙计们…"
    translate None chapter_eight_0289:
        l "双人用的？从没见过这种玩意儿。"
    translate None chapter_eight_0290:
        u "三人用的也有，如果你们好这口的话。"
    translate None chapter_eight_0291:
        "哇哦。"
    translate None chapter_eight_0292:
        u "不如进来看看吧？"
    translate None chapter_eight_0293:
        f "呃…"
    translate None chapter_eight_0294:
        f "雷恩…"
    translate None chapter_eight_0295:
        l "来吧。囤点货总没坏处。"
    translate None chapter_eight_0296:
        f "但是—"
    translate None chapter_eight_0297:
        rs "别担心福恩，莱奥斯肯定心里有数。"
    translate None chapter_eight_0298:
        f "别啊，这可是—"
    translate None chapter_eight_0299:
        u "跟我来。"
    scene black with dis
    translate None chapter_eight_0300:
        "尽管福恩极力想拉我们离开，我们还是跟着那位女士走进巷子深处一扇没有招牌的门。楼梯直通地下某种地下室。"

    window hide dissolve

    scene bg sexshop with Dissolve(1):
        size(1920, 1080)
    window show dissolve
    play music "sounds/bgm/Fooling Around Tiny.ogg" fadein 3.0
    translate None chapter_eight_0300b:
        u "欢迎来到我们的情趣天堂。"

    translate None chapter_eight_0301:
        f hur "我的天！"
    translate None chapter_eight_0302:
        "墙上挂满了我从未见过的玩意儿。绳索，锁链…还有各种形状奇怪的…雕塑？"
    translate None chapter_eight_0303:
        "莱奥斯立刻被某个展台吸引。福恩满脸通红把脸埋进了手掌。"
    translate None chapter_eight_0304:
        l sur "这些…这些太完美了！"
    translate None chapter_eight_0305:
        u "看来你喜欢鞭子和绳索？"
    translate None chapter_eight_0306:
        l sur "那当然！虽然不是我惯用的武器，但绝对实用。老家的货色可没这么全。"
    translate None chapter_eight_0307:
        u "尤其当你想防止猎物…逃跑的时候，对吧？"
    translate None chapter_eight_0308:
        l smu "这些鞭子…材质轻便，做工精良。"
    translate None chapter_eight_0309:
        u "只为极致欢愉。"
    translate None chapter_eight_0310:
        "我让莱奥斯去挑鞭子，自己在店里随便转转。后面的货架上摆着装满液体的玻璃瓶，还有些小项链和手镯。"
    translate None chapter_eight_0311:
        rs con "咦，这些首饰有点不对劲…根本没法扣上，就是一长串珠子…."
    translate None chapter_eight_0312:
        f emb "快放下那些！"
    translate None chapter_eight_0313:
        f hur "天啊，真不敢相信我们居然进了这种地方…！"
    translate None chapter_eight_0314:
        rs smi "怎么了？至少我们终于遇到些友善的人了。"
    translate None chapter_eight_0315:
        f hur "你不懂！这可是家—"
    show lilas n smi2 with dis
    translate None chapter_eight_0316:
        lil "没想到这么快又见面了。欢迎光临。"
    translate None chapter_eight_0317:
        rs sur "啊！莱拉斯！"
    translate None chapter_eight_0318:
        rs smi "这是你的店？真是太巧了。"
    translate None chapter_eight_0319:
        rs "你这里有些很有意思的东西。"
    show lilas n smi1 with dis
    translate None chapter_eight_0320:
        lil "谢谢。"
    show lilas n neu with dis
    translate None chapter_eight_0321:
        lil "莱奥斯在挑鞭子呢。第一次见面时我就注意到他随身带着鞭子。你们经常一起用吗？"
    translate None chapter_eight_0322:
        rs con "呃…一起用？"
    translate None chapter_eight_0323:
        rs neu "算是吧，有时候我们一起时他会用。"
    translate None chapter_eight_0324:
        rs smi "不过他多数时候都用小刀…有点吓人，但又很刺激。"
    show lilas n smi2 with dis
    translate None chapter_eight_0325:
        lil "听起来确实够刺激。让他注意别伤着你。相信你们都能在这找到感兴趣的东西。"
    translate None chapter_eight_0326:
        f emb "这就是你说的那家店？你特别热爱的工作？！"
    translate None chapter_eight_0327:
        f sad "早该想到的，你说你贩卖快乐的时候…"
    show lilas n exc with dis
    translate None chapter_eight_0328:
        lil "没有比给人带去欢愉更有意义的事业了。驾着这辆货车，我就能把快乐传播到每个角落。"
    hide lilas with dissolve
    show leos n smu with dissolve
    translate None chapter_eight_0329:
        "莱奥斯抱着一堆东西回来了。"
    translate None chapter_eight_0330:
        rs "买了些什么？"
    translate None chapter_eight_0331:
        l "哦，就…每样都拿了一点。"
    show leos n neu with dis
    translate None chapter_eight_0332:
        l "大部分看起来挺结实的，但我不懂她为什么要强调柔软度。绑人的时候还要讲究温柔吗？"
    translate None chapter_eight_0333:
        f emb ".............."
    hide leos with dis
    translate None chapter_eight_0334:
        rs "你不四处看看吗？"
    show layer master at hpunch
    translate None chapter_eight_0335:
        f hur "不要！"
    translate None chapter_eight_0336:
        f emb "这些东西…都是…"
    translate None chapter_eight_0337:
        f hur "做-"
    translate None chapter_eight_0338:
        f sad "你知道的…"
    translate None chapter_eight_0339:
        rs hap "我还是看看有什么实用的吧。幸好这次带了钱。"

    show raen n hap at slightright
    show fawn n shy at slightleft
    with Dissolve(1)

    translate None chapter_eight_0340:
        "拖着福恩在店里转悠。很多商品都是玻璃材质的。"
    show raen n neu with dis
    translate None chapter_eight_0341:
        rs "这是…手铐？"
    translate None chapter_eight_0342:
        rs "像是莱奥斯会喜欢的东西。"
    show fawn n emb with dis
    translate None chapter_eight_0343:
        f "........."
    show raen n sur with dis
    translate None chapter_eight_0344:
        rs "这个呢？软软的圆环…但我手指戴太大了吧？"
    show fawn n hur with dis
    translate None chapter_eight_0345:
        f "求你了…我求求你…"
    show raen n con with dis
    translate None chapter_eight_0346:
        rs "这个形状好奇怪…"
    translate None chapter_eight_0347:
        rs "这些都是干什么用的…？"
    translate None chapter_eight_0348:
        f "我一直想告诉你！"
    show fawn n shy with dis
    translate None chapter_eight_0349:
        f "这些是用来…那个…"
    translate None chapter_eight_0350:
        f "取-取悦别人…或者自己…"
    show raen n sur with dis
    translate None chapter_eight_0351:
        rs "取悦？"
    show raen n neu with dis
    translate None chapter_eight_0352:
        rs "嗯…"

    hide fawn
    hide raen
    with dissolve
    show leos n neu with dissolve

    translate None chapter_eight_0353:
        "我们带着几件物品走回莱奥斯身边。我指着他手中握着的鞭子问。"
    translate None chapter_eight_0354:
        rs neu "莱奥斯，这个能给你带来快感吗？"
    translate None chapter_eight_0355:
        f emb "....!"
    translate None chapter_eight_0356:
        l smi "这些？要是不能带给我快感就不会买了。"
    translate None chapter_eight_0357:
        rs smi "啊，明白了。福恩，看来你是对的。"
    translate None chapter_eight_0358:
        f emb "我不是这个意思…"
    translate None chapter_eight_0359:
        f hur "我放弃了…你简直要我的命…"
    translate None chapter_eight_0360:
        rs neu "那这些要买吗？"
    hide leos with dis
    translate None chapter_eight_0361:
        "莱奥斯将挑选的各式物品交给莱拉斯，她逐一清点着。有些东西看起来有点奇怪，但我相信他的选择。"
    translate None chapter_eight_0362:
        lil neu "总共是350枚羽币。"
    translate None chapter_eight_0363:
        l sur "350?!"
    translate None chapter_eight_0364:
        "他在翻找尼科斯昨晚给我们的钱袋。我很确定里面的钱远远不够支付。"
    translate None chapter_eight_0365:
        rs sad "呃…我们可能得退回几件…"
    translate None chapter_eight_0366:
        cyneu "可以记在我的账上。"

    window hide dissolve

    scene gallery_43b with dissolve:
        xpos 0.43 ypos 1.01 xanchor 0.5 yanchor 1.0 zoom 1.38
        linear 10.0 xpos 0.43 ypos 1.39 xanchor 0.5 yanchor 1.0 zoom 1.38
    window show dissolve

    translate None chapter_eight_0367:
        rs sur "你是…"
    translate None chapter_eight_0368:
        rs "等等！我们之前见过…"
    translate None chapter_eight_0369:
        cyneu "啊哈哈，这么可爱的脸怎么会忘记呢！"
    translate None chapter_eight_0370:
        rs "昨天在斯塔格威奇…我们撞了个正着…"
    scene gallery_43 with dissolve
    translate None chapter_eight_0371:
        cyneu "现在又相遇了。这一定是命运的安排！难道我终于遇见了命中注定的王子？你是来把我抱进夕阳里的吗？"
    translate None chapter_eight_0372:
        cyneu "总之都记我账上吧。你知道我信誉很好的！"
    translate None chapter_eight_0373:
        rs sur "为什么要这么做…？"
    translate None chapter_eight_0374:
        cyneu "只要想象你们用这些东西能做些什么…我怎么能不帮忙呢？"
    translate None chapter_eight_0375:
        cyneu "只希望你们记得邀请我。"

    $ about_Cyne.locked = False
    translate None chapter_eight_0376:
        c "啊，看我多失礼？你们可以叫我{a=set_entry:enc_people->about_Cyne}{color=#DA70D6}赛恩{/color}{/a}。"

    if achievement.has("cyne_meet"):
        pass
    else:
        $ renpy.display_notify("成就解锁：你可以叫我赛恩")

    python:
        achievement.grant("cyne_meet")
        achievement.sync()
    translate None chapter_eight_0377:
        rs "我是雷恩，这是福恩和莱奥斯。"

    scene gallery_43c with dissolve

    translate None chapter_eight_0378:
        c "不是一个，而是三个美男子！今天真是我的幸运日。"
    translate None chapter_eight_0379:
        c "让我看看…"
    translate None chapter_eight_0380:
        c "你肯定是高个子淘气坏男孩，这位是害羞但饥渴的类型…至于你…"
    translate None chapter_eight_0381:
        c "你如何描述自己？"
    translate None chapter_eight_0382:
        rs sur "我-我吗？"
    translate None chapter_eight_0383:
        rs con "嗯…持久？"

    scene gallery_43 with dissolve:
        size(1920, 1080)

    translate None chapter_eight_0384:
        c "真是奇怪的回答。明明有那么多可选的形容词…"
    translate None chapter_eight_0385:
        c "但持久确实很重要！最讨厌他们节奏刚好就突然换姿势了。要坚持有效的方式！"
    translate None chapter_eight_0386:
        rs sur "呃…"

    scene gallery_43c with dissolve:
        size(1920, 1080)

    translate None chapter_eight_0387:
        c "你很有趣。我喜欢你。"
    translate None chapter_eight_0388:
        rs con "嗯…谢谢？"
    translate None chapter_eight_0389:
        c "真高兴见到些新面孔！是什么风把你们吹来的？你们一定听说过奥克萨博玻璃的耐用性吧？"
    translate None chapter_eight_0390:
        rs sur "呃，我略有耳闻—"
    translate None chapter_eight_0391:
        c "不然你们大老远跑来干嘛？这里的产品可是举世无双的好货。"
    translate None chapter_eight_0392:
        c "当一个人表现糟糕还自我感觉良好时，这些东西就能派上用场了。"
    translate None chapter_eight_0393:
        c "这帮人唯一的工作都干不好。"
    translate None chapter_eight_0394:
        l pen "他到底在胡说八道什么？"
    translate None chapter_eight_0395:
        rs con "完全搞不懂…."
    window hide dissolve

    scene bg sexshop:
        size(1920, 1080)

    show raen n sur at cenleft
    show cyne n mis at cenright
    show fawn n sad at farleft
    show leos n neu at farright
    with dissolve
    window show dissolve
    translate None chapter_eight_0396:
        lil neu "行吧，我给你记在账上，纯粹看在你这个老主顾份上，赛恩。"
    translate None chapter_eight_0397:
        c "你知道我向来只光顾你家！这些宝贝能用一辈子。"
    translate None chapter_eight_0398:
        rs "宝贝？什么意思？"
    translate None chapter_eight_0399:
        f "这些…我刚才就想说！这些都是性…性玩具！"
    translate None chapter_eight_0400:
        rs "性玩具？"
    show cyne n sur with dis
    translate None chapter_eight_0401:
        c "怎么，你们不知道？误入成人用品店逛了半天还没发现吗？"
    show cyne n hap with dis
    translate None chapter_eight_0402:
        c "要是你们感兴趣…我很乐意示范用法。"
    translate None chapter_eight_0403:
        f "不必！我是说…"
    show fawn n hur with dis
    translate None chapter_eight_0404:
        f "我可以解释！"
    translate None chapter_eight_0405:
        l "那就说吧，小老鼠。"
    hide fawn
    hide raen
    hide cyne
    hide leos
    with dissolve
    show fawn m sad with dis

    translate None chapter_eight_0406:
        f "你…用它们来…"
    translate None chapter_eight_0407:
        l neu "直接？"
    translate None chapter_eight_0408:
        f "来…"
    show fawn m hur with dis
    show fawn m hur at shake
    translate None chapter_eight_0409:
        f "来造小孩！！！"

    hide fawn with dissolve
    show raen n sur at cenleft
    show cyne n mis at cenright
    show fawn n sad at farleft
    show leos n sur at farright
    with dis

    translate None chapter_eight_0410:
        c "嗯…"
    translate None chapter_eight_0411:
        c "不知道你们怎样，但我更习惯实践教学。"
    translate None chapter_eight_0412:
        c "雷恩肯定也一样。你们说呢？"
    window hide

    menu:
        "这可是难得的学习机会！":
            $ cyne_relationship +=2
            window show dissolve
            jump cyne_yes

        "我觉得这可能有危险…":
            window show dissolve
            jump cyne_no

label cyne_yes:
    translate None chapter_eight_0413:
        rs "不过…我倒想学点新知识。"
    show fawn n hur with dis
    translate None chapter_eight_0414:
        f "等等别！他根本不懂！"
    translate None chapter_eight_0415:
        c "所以我才说要好好教他嘛。"
    translate None chapter_eight_0416:
        c "雷恩都没意见，你们就坐下观摩吧？说不定能学到新知识。"
    translate None chapter_eight_0417:
        f "…这…太荒唐了…"
    show raen n smi with dis
    translate None chapter_eight_0418:
        rs "别紧张福恩，我保证很快结束。"
    translate None chapter_eight_0419:
        c "快？你应该知道我喜欢慢慢来，特别是对你这样的男孩。"
    translate None chapter_eight_0420:
        rs "啊抱歉，那请便吧。"
    translate None chapter_eight_0421:
        c "乐意之至。我可以用后面那间屋子吧？"
    translate None chapter_eight_0422:
        lil neu "当然，记得完事后打扫干净。"
    translate None chapter_eight_0423:
        c "一定。谢啦！"
    translate None chapter_eight_0424:
        c "跟我来。"

    hide fawn
    hide raen
    hide leos
    hide cyne
    show bg sexshop:
        xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 0.55 zoom 2.0
    with dissolve

    translate None chapter_eight_0425:
        "赛恩带我们走向店铺后方的小门。门板破旧没挂牌，看起来像储物间之类的地方。"
    translate None chapter_eight_0426:
        "在我们行走时，福恩和莱奥斯都跟在后面。福恩看起来很不情愿继续前进，而莱奥斯则显得…饶有兴趣？"
    translate None chapter_eight_0427:
        "为什么福恩如此抗拒？跟随陌生人去一个僻静的房间可能不是最明智的主意…"
    translate None chapter_eight_0428:
        "我确信没问题的。如果出现什么状况，莱奥斯会在场的。"
    translate None chapter_eight_0429:
        c hap "好了，进来吧。"
    play sound "sounds/sfx/dooropen3.ogg" fadeout 1.0
    translate None chapter_eight_0430:
        "赛恩拉开门，在我们鱼贯而入时撑着门。"
    translate None chapter_eight_0431:
        rs neu "谢谢。"
    translate None chapter_eight_0432:
        c mis "这是我的荣幸。"
    translate None chapter_eight_0433:
        "当福恩环顾赛恩带我们进入的房间时，他深深地吸了一口气。"
    translate None chapter_eight_0434:
        "莱拉斯住在这里吗？房间中央有张巨大的床。"
    translate None chapter_eight_0435:
        l sur "啊！还有更多鞭子。轻盈但耐用。"
    translate None chapter_eight_0436:
        "莱奥斯与我们分开，发现一面墙上整齐排列着鞭子和绳索。"
    translate None chapter_eight_0437:
        c mis "我喜欢你的品位。你叫莱奥斯对吧？"
    translate None chapter_eight_0438:
        l smu "嗯。"
    translate None chapter_eight_0439:
        "莱奥斯对鞭子的兴趣远比赛恩的话要大。至少他很享受。"
    translate None chapter_eight_0440:
        c hap "好吧…等你忙完了随时加入我们。"
    translate None chapter_eight_0441:
        c mis "现在开始重头戏！躺在这儿，小可爱。"
    translate None chapter_eight_0442:
        rs sur "我？小可爱？"
    translate None chapter_eight_0443:
        c hap "对，就是你。把你可爱的小屁股挪过来。"
    translate None chapter_eight_0444:
        "他指向房间中央的床。用别人的床感觉有点怪，但是…"
    translate None chapter_eight_0445:
        "我想应该没关系，我们确实得到了使用这个房间的许可。"
    translate None chapter_eight_0446:
        rs neu "那就给我两秒钟。"
    translate None chapter_eight_0447:
        "我脱下鞋坐在床边。赛恩在房间里四处拿了些东西。"
    translate None chapter_eight_0448:
        "看着他从一个架子冲到另一个架子…好像这不是他第一次这么做了…他知道每样东西的位置。"
    translate None chapter_eight_0449:
        c mis "我们开始吧。"
    translate None chapter_eight_0450:
        c mis "快乐入门课程。让我们慢慢来。"
    translate None chapter_eight_0451:
        c neu "我只需要-"
    translate None chapter_eight_0452:
        "赛恩轻轻把我推倒在床上，直到我的背触及床面。他的手虽小，但很有力。"
    translate None chapter_eight_0453:
        "哇，这张床超级舒服。不错。"
    translate None chapter_eight_0454:
        "莱奥斯忙完手头的事，饶有兴趣地站在床边。"
    translate None chapter_eight_0455:
        c mis "为了获得完整体验，我只需把这个往上拉一点。"
    translate None chapter_eight_0456:
        c hap "完美！"
    play sound "sounds/sfx/clothrustle.ogg" fadeout 1.0
    translate None chapter_eight_0457:
        "他把我的衬衫拉到下巴处，向所有人展示我的整个胸膛。一直露到锁骨。"
    translate None chapter_eight_0458:
        c neu "把你的衬衫举好。"
    translate None chapter_eight_0459:
        c mis "你的皮肤真美。如此纯净光滑。"
    translate None chapter_eight_0460:
        "我按他的要求掀起衬衫，看着他拿起一个小瓶子，啪地打开瓶盖。"
    translate None chapter_eight_0461:
        rs sur "谢谢。"
    translate None chapter_eight_0462:
        "总觉得有点尴尬啊……"
    translate None chapter_eight_0463:
        f emb "各位…你们真的…应该要—"
    translate None chapter_eight_0464:
        c hap "刚开始可能会有点凉，但相信我很快就会热起来的。"
    translate None chapter_eight_0465:
        l sur "那是什么？"
    translate None chapter_eight_0466:
        c hap "哦！看来性感先生终于也感兴趣了是吗？"
    translate None chapter_eight_0467:
        l neu "什么先生？快告诉我这是什么。"
    translate None chapter_eight_0468:
        c hap "嗯—既然你非要知道！这是超级无敌特效乳液！"
    translate None chapter_eight_0469:
        rs sur "乳液？会很舒服吗？"
    translate None chapter_eight_0470:
        c hap "不舒服我怎么会用！我示范给你看。"
    translate None chapter_eight_0471:
        "赛恩用指尖挖出一大坨乳液，冲我笑了笑。"
    translate None chapter_eight_0472:
        "他真的很享受教导别人。真是个好人。"
    translate None chapter_eight_0473:
        f hur "…雷恩…这…这不是个好主意。"
    translate None chapter_eight_0474:
        f hur "我们为什么要做这种事…."
    translate None chapter_eight_0475:
        c neu "我不想强迫任何人，所以再确认一次…"
    translate None chapter_eight_0476:
        c neu "你也是想要的，对吧？"
    translate None chapter_eight_0477:
        rs neu "….嗯，我感兴趣。"
    translate None chapter_eight_0478:
        "还没等我回应福恩，赛恩就把乳液抹在了我的胸口。"
    translate None chapter_eight_0479:
        rs sur "啊！好冰！"
    window hide dissolve

    scene gallery_57 with dissolve:
        xpos 0.77 ypos 1.02 xanchor 0.5 yanchor 1.0 zoom 1.62
        linear 30.0 xpos 0.21 ypos 1.02 xanchor 0.5 yanchor 1.0 zoom 1.62
    window show dissolve

    translate None chapter_eight_0480:
        c "抱歉抱歉。"
    translate None chapter_eight_0481:
        c "稍等片刻就会产生神奇效果。"
    translate None chapter_eight_0482:
        "赛恩用指尖在我胸口打着小圈涂抹。大约一分钟后，乳液逐渐开始发热。"
    translate None chapter_eight_0483:
        rs "唔，感觉…挺舒服？有点温热。"
    translate None chapter_eight_0484:
        f hur "雷恩！？"
    translate None chapter_eight_0485:
        f "我早说过，这东西是拿来……"
    translate None chapter_eight_0486:
        c "看吧？我说过的。接下来只会越来越舒服。"
    translate None chapter_eight_0487:
        "哇，这是什么感觉？话音刚落，我就感到胸口微微刺痛起来。"
    translate None chapter_eight_0488:
        c "有感觉了吗？"




    scene gallery_57 with dissolve
    translate None chapter_eight_0489:
        rs "感觉？"
    translate None chapter_eight_0490:
        "刺痛感每秒都在加剧。让我身体发热发痒。"
    translate None chapter_eight_0491:
        "好…好羞耻…但被福恩和莱奥斯盯着看…这种心跳加速的感觉是怎么回事…"
    translate None chapter_eight_0492:
        rs "刺…刺刺的。"
    translate None chapter_eight_0493:
        c "别担心，这就是正常反应。"
    translate None chapter_eight_0494:
        rs "我…我不—"
    translate None chapter_eight_0495:
        "一阵战栗窜过全身，某种异样的感觉从体内涌出。赛恩根本没用力，只是用指尖轻轻掠过我的胸口，可是…"
    translate None chapter_eight_0496:
        "他挑逗的动作、皮肤上的刺痛感、还有围观者们…"
    translate None chapter_eight_0497:
        c "当众答应做这种事…反而更刺激了，对吧？"
    translate None chapter_eight_0498:
        "赛恩的手指穿过我的发丝，将头发从我脸庞拂开。他的另一只手正极其缓慢地向下移动。"
    translate None chapter_eight_0499:
        "每次肌肤相触，我都感觉自己正一点点沉溺在赛恩的气息里。"
    scene gallery_57 with dissolve:
        xpos 0.24 ypos 1.56 xanchor 0.5 yanchor 1.0 zoom 1.58
        easein 3.0 xpos 0.29 ypos 1.56 xanchor 0.5 yanchor 1.0 zoom 1.58

    translate None chapter_eight_0500:
        "突然，他的手停住了。"
    translate None chapter_eight_0501:
        rs "....?"
    translate None chapter_eight_0502:
        c "怎么了？你不想让我停下？"
    translate None chapter_eight_0503:
        c "如果想让我继续…你得求我才行。"
    translate None chapter_eight_0504:
        "当他的双手撤离时，那阵暖意渐渐消退。哀求？这也太…"
    translate None chapter_eight_0505:
        f hur "够了！停！快住手！"
    translate None chapter_eight_0506:
        f "我再也看不下去了！"


    scene bg sexshop with dissolve:
        xpos 0.84 ypos 1.07 xanchor 0.55 yanchor 0.65 zoom 3.51
    translate None chapter_eight_0507:
        "福恩的喊声将我拉回现实。他脸色通红，双手在身侧紧握成拳。"
    translate None chapter_eight_0508:
        rs sur "福恩…？"
    translate None chapter_eight_0509:
        f hur "这种…这种场面我实在无法忍受…"
    translate None chapter_eight_0510:
        f hur "我不能允许别人—我是说你不能由着他在这里…！"
    translate None chapter_eight_0511:
        c sur "哎呀为什么？我们明明都很享受。"
    translate None chapter_eight_0512:
        c neu "连莱奥斯都看得很开心呢。你该不会是在吃醋吧？"
    translate None chapter_eight_0513:
        c sur "我又没抢你男朋友，对不对？"
    translate None chapter_eight_0514:
        f hur "胡—才不是！"
    translate None chapter_eight_0515:
        "莱奥斯？"
    translate None chapter_eight_0516:
        "他扭头避开我的视线，连耳尖都泛着微红。"
    translate None chapter_eight_0517:
        f hur "不是那样！他们是…改天我再跟你解释…！"
    translate None chapter_eight_0518:
        f sad "拜托，我真的受不了了…"
    translate None chapter_eight_0519:
        "福恩…看起来很难过。我应该相信他的判断。"
    translate None chapter_eight_0520:
        rs sad "呃…对不起福恩…"
    translate None chapter_eight_0521:
        f sad "不、不必道歉…我只是…不希望你…"
    translate None chapter_eight_0522:
        f sad "…走吧。"
    translate None chapter_eight_0523:
        l emb "..…"
    translate None chapter_eight_0524:
        c mis "好~吧。反正总有机会继续的！"
    translate None chapter_eight_0525:
        c mis "那就拜托你帮我调教他了，福恩。"
    translate None chapter_eight_0526:
        c hap "毕竟技术这种东西，不用就会生疏呢！"
    translate None chapter_eight_0527:
        f emb "什…什么？！"
    translate None chapter_eight_0528:
        c hap "对了雷恩？"
    translate None chapter_eight_0529:
        rs sur "是、是的？"
    translate None chapter_eight_0530:
        c mis "那款按摩油很快会失效，不用担心。"
    translate None chapter_eight_0531:
        rs sur "哦…好的。谢谢。"
    translate None chapter_eight_0532:
        fl "......"
    translate None chapter_eight_0533:
        "赛恩率先离开，只剩下我、莱奥斯和福恩。我拉好衣摆匆忙系上鞋带。"
    translate None chapter_eight_0534:
        "胸口仍有些酥麻，但远没有方才强烈。"
    translate None chapter_eight_0535:
        "但这和…孕育后代有什么关系…？"
    translate None chapter_eight_0536:
        f sad "那个…我们先出去再说。"


    if achievement.has("cyne_shop"):
        pass
    else:
        $ renpy.display_notify("成就解锁：欢愉入门课程")
    python:
        achievement.grant("cyne_shop")
        achievement.sync()


    scene bg sexshop with dissolve:
        size(1920, 1080)
    play sound "sounds/sfx/dooropen3.ogg" fadeout 1.0

    translate None chapter_eight_0537:
        "整理好衣着后，我们回到了店铺前厅。"
    translate None chapter_eight_0538:
        "赛恩正在那儿等我们。"
    translate None chapter_eight_0539:
        f sad "......"
    translate None chapter_eight_0540:
        c hap "别这么紧张，什么都没发生。只是个小教训。"
    translate None chapter_eight_0541:
        f sad "我知道…"
    translate None chapter_eight_0542:
        f sad "只是…算了…"
    translate None chapter_eight_0543:
        l neu "既然这件事已经了结了…"
    translate None chapter_eight_0544:
        l smu "我也想弄根这样的鞭子。他会为此付出代价的。"
    translate None chapter_eight_0545:
        f sad "认真的吗…"

    jump choice_fourteen_done

label cyne_no:
    show leos n pis with dis
    translate None chapter_eight_0546:
        l "绝对不行。你别想带他去任何地方。"
    show cyne n sur with dis
    translate None chapter_eight_0547:
        c "你以为你是谁？他男朋友？"
    show fawn n hur with dis
    translate None chapter_eight_0548:
        f "不是！他们不是那种关系！"
    translate None chapter_eight_0549:
        c "噢。所以其实你是他男朋友？"
    show fawn n sad with dis
    translate None chapter_eight_0550:
        f "不…不是…"
    show cyne n hap with dis
    translate None chapter_eight_0551:
        c "那他就是无主之物了！这叫什么来着…"
    translate None chapter_eight_0552:
        c "他是免费房产！"
    translate None chapter_eight_0553:
        c "嗯…免费的雷恩房产？"
    translate None chapter_eight_0554:
        l "如果你觉得能靠近他哪怕一根手指的距离，那你就大错特错了。"
    translate None chapter_eight_0555:
        c "哇哦，你站那么高说话谁听得见啊？上面风景如何？"
    translate None chapter_eight_0556:
        l "什么？"
    translate None chapter_eight_0557:
        rs "呃！"
    translate None chapter_eight_0558:
        rs "我觉得…福恩的解释已经足够了…"
    translate None chapter_eight_0559:
        rs "这就是你们之前说的事，对吧？"
    translate None chapter_eight_0560:
        f "嗯…"
    translate None chapter_eight_0561:
        "说实话我不太明白，但福恩和莱奥斯看起来很担心，我相信他们的判断。"
    translate None chapter_eight_0562:
        c "哼。那这次就算了，但下次我绝不会放过你。"
    jump choice_fourteen_done
