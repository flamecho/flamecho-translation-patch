
label cyneroute2_aftersex:
    scene bg swroom day with eye_open
    window show dissolve
    translate None cyne_chapter3_0001:
        rs wneu "嗯…"
    translate None cyne_chapter3_0002:
        c wneu "终于醒了？"
    translate None cyne_chapter3_0003:
        "当我伸手去抓赛恩时，身边的位置又冷又空。我睁开仍因疲倦而沉重的眼皮，发现他已经穿戴整齐站在床边。"
    translate None cyne_chapter3_0004:
        rs wsur "几点了？为什么不叫醒我？"
    translate None cyne_chapter3_0005:
        c wsad "…我觉得你需要多睡会。反正你不是说今天要去找卡斯皮安吗？"
    translate None cyne_chapter3_0006:
        rs "我是要…"
    translate None cyne_chapter3_0007:
        c "我就知道！我先去找其他人—你准备好就出来。"
    translate None cyne_chapter3_0008:
        rs "等等，赛恩—"
    translate None cyne_chapter3_0009:
        play music "sounds/bgm/sad.ogg" fadein 3.0
        "他退出房门，轻轻把门关上。我感觉心情一下子低落了。"
    translate None cyne_chapter3_0010:
        "他绝对在躲我。"
    translate None cyne_chapter3_0011:
        "我慢慢整理着衣裳和思绪。他一直表现得很奇怪—每当涉及他私生活的话题时—但自从我告诉他我喜欢他后…"
    translate None cyne_chapter3_0012:
        "唉…我真是个傻瓜。总是这么莽撞…"
    translate None cyne_chapter3_0013:
        "但是…这不正是伊尔兰和福恩跟我说过的感觉吗？这种…温暖的感觉？"
    translate None cyne_chapter3_0014:
        "…."
    translate None cyne_chapter3_0015:
        "暂且把这些念头放下，我穿上刚洗好的干净衣服，离开了房间。"

    window hide dissolve

    scene bg sw day with dissolve
    window show dissolve
    translate None cyne_chapter3_0016:
        "我扫视大厅，终于发现了两个我要找的人—福恩和莱奥斯坐在角落里自说自话。"
    translate None cyne_chapter3_0017:
        "我朝他们走去，本以为也能看到赛恩，但他们单独坐着。"

    stop music fadeout 2.0

    scene bg sw day:
        xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.56
    show raen nw sur cloak at center
    show leos nw neu cloak at left
    show fawn nw neu cloak at right
    with dissolve
    play music "sounds/bgm/creepy.ogg" fadein 2.0
    translate None cyne_chapter3_0018:
        rs "…赛恩去哪了？"
    translate None cyne_chapter3_0019:
        l "他出去和他的宠物说话了。"
    translate None cyne_chapter3_0020:
        rs "他的…宠物？"
    translate None cyne_chapter3_0021:
        show leos nw smi with dis
        l "看情况他整晚都坐在外面的雪地里等。"
    translate None cyne_chapter3_0022:
        show fawn nw sad with dis
        f "…你俩…吵架了？"


    if cyne_threesome:
        translate None cyne_chapter3_0023:
            "福恩直视我的眼睛，脸上写满担忧。我本以为经历了昨晚他会害羞，但他表现得很正常…"


    show raen nw sad with dis
    translate None cyne_chapter3_0024:
        rs "没…没有，我们没有—"
    translate None cyne_chapter3_0025:
        show leos nw neu with dis
        l "很明显那个混蛋留不住朋友。他可能已经对你厌烦了。"
    translate None cyne_chapter3_0026:
        rs "…你真的这么想吗？"
    translate None cyne_chapter3_0027:
        f "我相信不是这样…没人会对你感到厌倦的，雷恩。"
    translate None cyne_chapter3_0028:
        show leos nw smu with dis
        l "哈！你什么时候学会开玩笑了？"
    translate None cyne_chapter3_0029:
        "我盯着门外，看着赛恩和埃瑟的身影。他们挨得很近，低声交谈。到底是什么事让他非得这么急着告诉他？"

    window hide dissolve

    scene bg sc day with fade:
        xpos 0.49 ypos 1.02 xanchor 0.5 yanchor 1.0 zoom 1.29
        linear 14.0 xpos 0.49 ypos 1.29 xanchor 0.5 yanchor 1.0 zoom 1.29
    window show dissolve
    translate None cyne_chapter3_0030:
        c c wsad "…你都冻僵了。在这干什么？"
    translate None cyne_chapter3_0031:
        e "我在等您，先生。您母亲让我带个口信，但我找不到您…"
    translate None cyne_chapter3_0032:
        c "所以你就整晚坐在这里？"
    translate None cyne_chapter3_0033:
        e "....."
    translate None cyne_chapter3_0034:
        c "哈…她还想怎样？插手我的事还不够多吗？"
    translate None cyne_chapter3_0035:
        e "…她要求你今晚把这男孩交出来。"
    translate None cyne_chapter3_0036:
        "金发男子眉头紧锁，面容扭曲。他的声音几乎像在笑—充满讥讽，又仿佛难以置信。"
    translate None cyne_chapter3_0037:
        c c wang "交出来？他又不是能在人间传递的物品。"
    translate None cyne_chapter3_0038:
        e "大人…您为何对他如此在意？您最初不也是奉母亲之命寻他而来的吗…？"
    translate None cyne_chapter3_0039:
        c "...."
    translate None cyne_chapter3_0040:
        c "谁告诉你这些的？"
    translate None cyne_chapter3_0041:
        e "自然是我的女主人。"
    translate None cyne_chapter3_0042:
        c "….这不重要。情况有变。"
    translate None cyne_chapter3_0043:
        e "大人—"
    translate None cyne_chapter3_0044:
        c "你要我怎么做，埃瑟？！像交出一块肉那样把他交出去…就为了让她利用，像利用其他能推进她目标的人那样？"
    translate None cyne_chapter3_0045:
        e "…她到底想要他做什么？他看起来…格外普通。出身低微，肮脏，愚钝…"
    translate None cyne_chapter3_0046:
        c "他现在这样就很好。"
    translate None cyne_chapter3_0047:
        e "….大人…"
    translate None cyne_chapter3_0048:
        "赛恩揉着眉间，已经开始头痛了。"
    translate None cyne_chapter3_0049:
        cmn "现在我没法处理这个…"
    translate None cyne_chapter3_0050:
        c c wsad "…连我也不知道她想要他做什么，但你应该听过那些传闻吧？关于被诅咒男孩的流言。"
    translate None cyne_chapter3_0051:
        e "就是他？"
    translate None cyne_chapter3_0052:
        c "我不知道她在计划什么，但我绝不参与。再也不了。他是我的…他是我的朋友。"
    translate None cyne_chapter3_0053:
        e "您爱上他了吗，大人？"
    translate None cyne_chapter3_0054:
        c c wsur "什么？！"
    translate None cyne_chapter3_0055:
        c c wsad "….别…别犯傻。你知道我不相信爱情。"
    translate None cyne_chapter3_0056:
        e "…她说今晚带他过来，否则就正式断绝关系。"
    translate None cyne_chapter3_0057:
        e "抱歉大人。真希望我能帮上忙。"
    translate None cyne_chapter3_0058:
        c "..你做得够多了。给，去买点热饮吧。"
    translate None cyne_chapter3_0059:
        "赛恩从口袋里掏出几张钞票，数了数递给埃瑟。"
    translate None cyne_chapter3_0060:
        e "大人，我…"
    translate None cyne_chapter3_0061:
        e "无论您作何选择，我都会追随。哪怕是…保护那个…{i}东西{/i}。"
    translate None cyne_chapter3_0062:
        c "埃瑟…"

    window hide dissolve

    scene bg sw day:
        xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.56
    show raen nw sad cloak at center
    show leos nw neu cloak at left
    show fawn nw neu cloak at right
    with Dissolve(1.5)
    window show dissolve
    translate None cyne_chapter3_0063:
        "我越看他们的交谈，越感到不安。"
    translate None cyne_chapter3_0064:
        "还有嫉妒。原来就是这种感觉？"
    translate None cyne_chapter3_0065:
        "赛恩将某个我看不见的东西交给侍从，随后皱着眉头回到门前。"

    show raen at cenleft
    show leos at farleft
    show fawn at farright
    with move

    show cyne nw ang cloak at cenright with dissolve
    translate None cyne_chapter3_0066:
        c "…抱歉，我回来了。"
    translate None cyne_chapter3_0067:
        rs "刚才怎么回事？"
    translate None cyne_chapter3_0068:
        show cyne nw sur with dis
        c "什么，埃瑟？"
    translate None cyne_chapter3_0069:
        show cyne nw hap with dis
        c "你不会是在吃醋吧？哈哈，别担心，他只是来传个话而已。没什么大不了的。"
    translate None cyne_chapter3_0070:
        rs "如果你确定的话…"
    translate None cyne_chapter3_0071:
        l "你搞定…呃，不管那是什么事了没？我都开始觉得等我们准备出发时，我头发都要等白了。"
    translate None cyne_chapter3_0072:
        c "我觉得你有点白发说不定会更帅呢。"

    hide cyne
    hide raen
    hide leos
    hide fawn
    with dissolve
    translate None cyne_chapter3_0073:
        "莱奥斯翻了个白眼，无视赛恩的奉承，追上了红发男子与他并肩而行。"
    translate None cyne_chapter3_0074:
        "他还是一如既往地黏着莱奥斯，但…"
    translate None cyne_chapter3_0075:
        "我不假思索地抓住赛恩的袖子。他转回头看我，先是板着脸，继而露出笑容。"
    translate None cyne_chapter3_0076:
        stop music fadeout 2.0
        c c wsmi "那是什么？"
    translate None cyne_chapter3_0077:
        rs c wsad "…没什么，算了。"
    translate None cyne_chapter3_0078:
        "说完他又继续挂在莱奥斯身上。福恩走到我身边笑了笑，然后跟在他们后面。"

    window hide dissolve

    scene bg sc day with dissolve:
        xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.35
        linear 15.0 xpos 0.5 ypos 1.34 xanchor 0.5 yanchor 1.0 zoom 1.35
    window show dissolve
    translate None cyne_chapter3_0079:
        "我花了点时间回忆霍恩给我的指示，然后带队前行。莱奥斯开玩笑说可别带错路，但我连笑的力气都没有。"
    translate None cyne_chapter3_0080:
        play music "sounds/bgm/Discovery.ogg" fadein 3.0
        "越往前走，我的脚步就越快。我能听见耳中轰鸣的心跳声，呼吸都卡在喉咙里。"
    translate None cyne_chapter3_0081:
        "现在必须把关于赛恩的念头搁置一边。我离寻找的答案已经很近了。"
    translate None cyne_chapter3_0082:
        "其他人轻松闲聊取乐，我却做不到。"
    translate None cyne_chapter3_0083:
        "卡斯皮安…求你了，一定要在这里。"
    translate None cyne_chapter3_0084:
        c c whap "莱奥斯，莱奥斯，别忘了—晚点有庆典。你愿意当我的舞伴吗？"
    translate None cyne_chapter3_0085:
        l c wneu "我宁愿跳崖也不想和你去。"
    translate None cyne_chapter3_0086:
        c "哎呀呀，莱奥斯你太贴心了。我正想着也是时候带你去见我父母了呢。"
    translate None cyne_chapter3_0087:
        l c wthi "恶心。"
    translate None cyne_chapter3_0088:
        rs c wsad "...."
    translate None cyne_chapter3_0089:
        "我摇摇头，努力不去听他们的对话。"
    translate None cyne_chapter3_0090:
        "我们是朋友。一直以来不都是这样吗。"
    translate None cyne_chapter3_0091:
        "街道越来越安静，直到我们来到镇上与众不同的区域。这里更狭小简陋，几乎让我想起家乡。"
    translate None cyne_chapter3_0092:
        "我们分头搜索附近的店铺。不对，不是这家…这家也不是。"
    translate None cyne_chapter3_0093:
        "一块悬挂的招牌映入眼帘，上面画着日月交叠的图案。"
    translate None cyne_chapter3_0094:
        "月蚀\"。"
    translate None cyne_chapter3_0095:
        rs c wsur "就是这里…"
    translate None cyne_chapter3_0096:
        "当我推开门时，其他人也重新聚集到我身边。"

    window hide dissolve

    jump meetcaspian

label aftercaspiancyne:

    scene bg sc sunset with dissolve:
        xpos 0.65 ypos 1.34 xanchor 0.5 yanchor 1.0 zoom 1.35
        linear 24.0 xpos 0.33 ypos 1.34 xanchor 0.5 yanchor 1.0 zoom 1.35
    window show dissolve
    translate None cyne_chapter3_0097:
        "其他人可能在跟我说话，但我没注意。我完全沉浸在自己的思绪里，权衡着我的选择。"
    translate None cyne_chapter3_0098:
        "我该怎么办？什么是正确的选择？"
    translate None cyne_chapter3_0099:
        play music "sounds/bgm/sad.ogg" fadeout 2.0
        "我……我到底该成为什么样的人？"
    translate None cyne_chapter3_0100:
        "一直以来我以为我在对抗命运，证明即使拿着像我这样糟糕的\"审判\"，我也能有所作为。"
    translate None cyne_chapter3_0101:
        "…..但看来我只是在逃避。我没什么不同。"
    translate None cyne_chapter3_0102:
        f c wsad "雷恩，你还好吗？"
    translate None cyne_chapter3_0103:
        rs c wsad "我不知道。"
    translate None cyne_chapter3_0104:
        l c wneu "….算了。"
    translate None cyne_chapter3_0105:
        l "有时候不知道也没关系。"
    translate None cyne_chapter3_0106:
        "我望向赛恩，但他迅速转过头去，忙着做其他事。"
    translate None cyne_chapter3_0107:
        rs "…..我想一个人待会儿。回头见，好吗？"
    translate None cyne_chapter3_0108:
        f "等等，雷恩—"
    translate None cyne_chapter3_0109:
        l "让他走吧。"
    translate None cyne_chapter3_0110:
        "独处时，万千思绪涌上心头。最重要的是…现在该怎么办？"
    translate None cyne_chapter3_0111:
        "靴子踩在雪上发出嘎吱声，提醒着我身在何处，以及为到达这里所做的一切。"
    translate None cyne_chapter3_0112:
        "然后呢？"
    translate None cyne_chapter3_0113:
        "为了接受这个从一开始就不想要的半吊子命运？"
    translate None cyne_chapter3_0114:
        show bg sc night with dis5
        "寒风在我周围呼啸，街角的暗处积着雪。空气冰冷刺骨，我的呼吸苍白无力。"
    translate None cyne_chapter3_0115:
        "我该怎么做？回家？留在这里？"
    translate None cyne_chapter3_0116:
        "我得到了答案。我应该高兴，但是…"
    translate None cyne_chapter3_0117:
        "为什么好像我达成的一切，一路走来所做的每件事，都毫无意义？"
    translate None cyne_chapter3_0118:
        "仿佛我从一开始就没有真正的选择，被某个想象中的天上之人操控着。"
    translate None cyne_chapter3_0119:
        "…就像我做的一切都是因为那两个家伙无法和睦相处。"
    translate None cyne_chapter3_0120:
        "在锡德卡汉漆黑的街道上，每一步都加深了我的困惑。远处传来音乐声，我看到明亮的灯光。"
    translate None cyne_chapter3_0121:
        "啊，是庆典。"
    translate None cyne_chapter3_0122:
        "我没心情参加。"
    translate None cyne_chapter3_0123:
        "我坐在冰冷的大理石喷泉上，远远看着。孩子们玩着烟花棒，奔跑欢笑。其他人吃着节庆食物，与所爱之人漫步。"
    translate None cyne_chapter3_0124:
        "而我独自坐在这里。完完全全，彻彻底底地，孤独一人。"
    translate None cyne_chapter3_0125:
        "试图逃避没有意义，对吧？"
    translate None cyne_chapter3_0126:
        "我注定要成为下一任\"说书人\"。或者说…本该是，如果卡斯—…如果我父亲和\"言者\"没有闹翻的话。"
    translate None cyne_chapter3_0127:
        "我甚至无法想象。在城堡里长大？我？"
    translate None cyne_chapter3_0128:
        "我根本不想要那样。"
    translate None cyne_chapter3_0129:
        "更不用说既…是王位的继承人，又是言者。这简直是闻所未闻。"
    translate None cyne_chapter3_0130:
        "…"
    translate None cyne_chapter3_0131:
        "一切都感觉遥不可及。"
    translate None cyne_chapter3_0132:
        "几乎无声地，一个身影走近并在我身边坐下。我转头看向他—完美的金色短发，大大的绿眼睛……"
    translate None cyne_chapter3_0133:
        "赛恩。"


    scene bg sc night:
        xpos 0.49 ypos 1.37 xanchor 0.5 yanchor 1.0 zoom 1.64
    show cyne mw dark sad cloak at mleft
    show raen mw dark sad cloak at mright
    with dissolve

    translate None cyne_chapter3_0134:
        c "……过得不太好吗？"
    translate None cyne_chapter3_0135:
        rs "..."
    translate None cyne_chapter3_0136:
        rs "我该怎么办，赛恩？"
    translate None cyne_chapter3_0137:
        rs "我应该回去吗？然后呢？接受训练成为言者？这完全不像是我会做的事。"
    translate None cyne_chapter3_0138:
        rs "或者……留在这里，假装奥雷利亚卡维拉不存在，遗忘我的家人？"
    translate None cyne_chapter3_0139:
        c "……我—"
    translate None cyne_chapter3_0140:
        rs "等等。别回答。你不想牵扯进来，对吧？"
    translate None cyne_chapter3_0141:
        c "雷恩…"
    translate None cyne_chapter3_0142:
        rs "我真的有选择吗？"
    translate None cyne_chapter3_0143:
        c "..."
    translate None cyne_chapter3_0144:
        c "别人总是想告诉你该如何生活，而你只能照他们说的做。否则就会受到惩罚。"
    translate None cyne_chapter3_0145:
        c "这不公平，不是吗？"
    translate None cyne_chapter3_0146:
        c "……做你想做的事，雷恩。而不是别人告诉你必须做的事。"
    translate None cyne_chapter3_0147:
        rs "我很害怕。"
    translate None cyne_chapter3_0148:
        c "……我明白你的感受。那种……被迫完成他人期待的压迫感。"
    translate None cyne_chapter3_0149:
        rs "明天的这个时候，我可能已经在回家的路上了。再也见不到你们任何人。"
    translate None cyne_chapter3_0150:
        "他的眼睛令人着迷。他用如此复杂的眼神注视着我，让我无法移开视线。"


    translate None cyne_chapter3_0151:
        "本能地，我的手抚上他的脸颊，拇指轻轻摩挲着他的脸。"
    translate None cyne_chapter3_0152:
        "我们只是朋友，对吧？那为什么当你不敢直视我时，我的心会如此疼痛？"
    translate None cyne_chapter3_0153:
        "为什么看见你时，呼吸会在喉咙里凝滞？又该如何解释此刻心底的悸动？"
    translate None cyne_chapter3_0154:
        "是忧虑？是压力？"
    translate None cyne_chapter3_0155:
        "还是说……终究是爱意呢？"
    translate None cyne_chapter3_0156:
        window hide dissolve

        scene gallery_95 with Fade(1.0, 1.0, 1.0)
        window show dissolve
        "我俯身向前，轻轻将唇贴上他的。他闭上眼睛作为回应。"
    translate None cyne_chapter3_0157:
        "这个吻柔软而甜蜜，比我们曾有过的任何亲吻都更加温柔。我不希望这一刻结束，但无论如何，它必须结束。"
    translate None cyne_chapter3_0158:
        "如果我的话语无法说服他，或许这能行。"
    translate None cyne_chapter3_0159:
        "我喜欢你，赛恩。喜欢你的一切。"
    translate None cyne_chapter3_0160:
        "从那个在众人面前永远保持灿烂笑容的你，到当别人转身时露出悲伤面具的你。"
    translate None cyne_chapter3_0161:
        scene gallery_96 with dissolve
        "他结束了这个吻，睫毛轻颤着睁开双眼。"
    translate None cyne_chapter3_0162:
        c "...."
    translate None cyne_chapter3_0163:
        rs "我会想念你，赛恩。胜过世上任何事物。"


    if cyne_badend > cyne_goodend:
        jump cynebadending
    else:
        pass

    window hide dissolve

    scene bg sc night with dissolve
    window show dissolve

    translate None cyne_chapter3_0164:
        c c wsad "..."
    translate None cyne_chapter3_0165:
        c "我不能这样对你……"
    translate None cyne_chapter3_0166:
        rs c wsad"什么？"
    translate None cyne_chapter3_0167:
        c "对不起，我得走了。"
    translate None cyne_chapter3_0168:
        c "而…雷恩？我相信你会做出正确的决定。"


    translate None cyne_chapter3_0169:
        rs c wsad "赛恩，求你了，我们就不能谈谈吗？"
    translate None cyne_chapter3_0170:
        "我看到的只是他再次离我而去时的背影。"
    translate None cyne_chapter3_0171:
        rs "......."
    translate None cyne_chapter3_0172:
        rs "该死的…"
    translate None cyne_chapter3_0173:
        "我只会把事情搞砸。莱奥斯说得对，他肯定受够我了。"
    translate None cyne_chapter3_0174:
        "远处传来的笑声和音乐此刻显得如此刺耳，仿佛在嘲笑我。"
    translate None cyne_chapter3_0175:
        "我从喷泉边站起来，脚下的雪已融化成泥泞。"
    translate None cyne_chapter3_0176:
        "继续待在这个寒冷的地方毫无意义。我要去睡觉，希望…明天醒来能想到解决办法。"
    translate None cyne_chapter3_0177:
        "离节庆的喧嚣越远，我的头脑就越清醒。雪夜漫步确实能让人神清气爽。"
    translate None cyne_chapter3_0178:
        "映入眼帘的银柳旅馆—与往常毫无二致，但…独自归来时心境却截然不同。"

    window hide dissolve

    scene bg swroom night with dissolve
    window show dissolve
    translate None cyne_chapter3_0179:
        "房间黑暗、寂静而冰冷。我点亮门廊的油灯，柔和的光线洒在我的床铺上。"
    translate None cyne_chapter3_0180:
        "那张床昨夜还躺着赛恩，此刻却空空如也。"
    translate None cyne_chapter3_0181:
        "我甩开这些念头，脱掉衣服钻进被窝。拜托了，思绪，让我一个人静一静。"
    translate None cyne_chapter3_0182:
        "当我闭上眼睛时，几乎能感觉到他就在身旁。"

    stop music fadeout 3.0
    window hide dissolve

    scene bg sc night with Fade (1.0, 1.0, 1.0)
    show cyne nw dark ang cloak at slightright
    show lv n dark neu at lvslightleft
    with dissolve
    play music "sounds/bgm/creepy.ogg" fadein 2.0
    window show dissolve
    translate None cyne_chapter3_0183:
        lv "看来我儿子是空手而归啊。我在等你的解释，以及接下来确保他会很快被送到我这儿的保证。"
    translate None cyne_chapter3_0184:
        c "…你想对他做什么？"
    translate None cyne_chapter3_0185:
        lv "这重要吗？"
    translate None cyne_chapter3_0186:
        c "对我来说非常重要。"
    translate None cyne_chapter3_0187:
        lv "我只是想利用他的…特殊才能。如果他在这儿，你随时都能见到他。毕竟我岂敢拆散未婚夫妻。"
    translate None cyne_chapter3_0188:
        c "…特殊才能？"
    translate None cyne_chapter3_0189:
        show lv n dark ang1 with dis
        lv "别跟我装傻，孩子。我清楚知道他的底细—如果他加入我们？我们立刻就能登上锡德卡汉的顶峰。"
    translate None cyne_chapter3_0190:
        c "那就让他自己选择！"
    translate None cyne_chapter3_0191:
        lv "他会按我说的做，否则…我不能让任何人破坏我的计划。"
    translate None cyne_chapter3_0192:
        c "…我不会把他交给你的。"
    translate None cyne_chapter3_0193:
        lv "..什么？"
    translate None cyne_chapter3_0194:
        show bg sc night with hpunch
        c "我说我不会把他交给你！"
    translate None cyne_chapter3_0195:
        lv "是我的耳朵出问题了，还是你{i}真的{/i}要反抗我？"
    translate None cyne_chapter3_0196:
        c "我不会改变主意。把你的脏手从他身上拿开！"
    translate None cyne_chapter3_0197:
        show lv n dark ang2 with dis
        lv "我能摧毁你的整个世界，西纳库洛斯。你最好管住自己的舌头。"
    hide cyne
    hide lv
    with dissolve
    translate None cyne_chapter3_0198:
        lv ang1 "…呃！那个可恶的、诡计多端的小混蛋…真是个没用的儿子！"
    translate None cyne_chapter3_0199:
        lv "我不会让你毁掉我努力争取的一切！"
    translate None cyne_chapter3_0200:
        u "哎呀呀，如此高贵的女士，为这点小事声嘶力竭地尖叫？这可真是个可悲的景象。"
    translate None cyne_chapter3_0201:
        show luc n dark smir cloak with dissolve
        "金发女子转过身，愤怒扭曲了她通常平静的面容。在她庄园外漆黑的街道上站着个黑影，几乎看不清他的微笑。"
    translate None cyne_chapter3_0202:
        show luc n dark smi with dis
        u "你想要那个年轻的言者，对吧？也许我们可以达成协议。"
    translate None cyne_chapter3_0203:
        lv "...."

    stop music fadeout 2.0
    window hide dissolve

    scene black with Dissolve(2.0)
    pause 2.0

    if caspianaemylromance >= 1:
        $ ca_scene_one = True
        jump caspianaemylscene1
    else:
        jump morwenscene1

label cyneroute3cont:
    scene bg swroom day with Dissolve(1.0)
    window show dissolve
    translate None cyne_chapter3_0204:
        rs wsur "等等..等等，赛恩…！"
    translate None cyne_chapter3_0205:
        "我突然惊醒，脑海充斥着赛恩背影逐渐远去的画面。"
    translate None cyne_chapter3_0206:
        "只是个梦…"
    translate None cyne_chapter3_0207:
        play music "sounds/bgm/sad.ogg" fadein 3.0
        "…但现实并无不同。"
    translate None cyne_chapter3_0208:
        "我用胳膊遮住脸，大声叹气。身边的位置空无一人，也没有熟悉的轻鼾声。"
    translate None cyne_chapter3_0209:
        "我缓缓离开温暖的床铺穿衣。这些都是赛恩为我买的，按照他的要求精心制作。"
    translate None cyne_chapter3_0210:
        "…."
    translate None cyne_chapter3_0211:
        "手搭在门把上时，我回想起他为我做的一切。远超我所能回报的。"
    translate None cyne_chapter3_0212:
        "而现在…我想这里已没有让我留下的理由。或许这真是诸神的旨意—我的家园需要我，我不该分心。"
    translate None cyne_chapter3_0213:
        "我已经历过我的旅程了，不是吗？一生的冒险。神明、恶魔、谜团与谋杀…"
    translate None cyne_chapter3_0214:
        "我想是时候回家了。"
    translate None cyne_chapter3_0215:
        "强压心头刺痛，我离开房间寻找其他人。"

    window hide dissolve

    scene bg sw day with dissolve
    window show dissolve
    translate None cyne_chapter3_0216:
        "没人在等我。完全不见福恩、莱奥斯或…赛恩的踪影。"
    translate None cyne_chapter3_0217:
        "我扫视房间。这里也没有其他人。连艾琳都不在。"
    translate None cyne_chapter3_0218:
        "…."
    translate None cyne_chapter3_0219:
        "满心沮丧，我最后一次离开银柳。"

    window hide dissolve

    scene bg sc grey with dissolve:
        xpos 0.57 ypos 1.15 xanchor 0.5 yanchor 1.0 zoom 1.21
        linear 18.0 xpos 0.4 ypos 1.15 xanchor 0.5 yanchor 1.0 zoom 1.21
    window show dissolve
    translate None cyne_chapter3_0220:
        "天色阴沉，暗灰云层自地平线翻涌而来。街道昏暗空旷，毫无生气。"
    translate None cyne_chapter3_0221:
        "当我走过空荡的街道，压倒性的恐惧感袭来—却说不出确切缘由。"
    translate None cyne_chapter3_0222:
        "因为太安静？"
    translate None cyne_chapter3_0223:
        "因为一切都仿佛…停滞了？"
    translate None cyne_chapter3_0224:
        "不…是因为这让我想起奥克斯哈伯。商店紧闭，街头杳无人迹。"
    translate None cyne_chapter3_0225:
        "..但我确信这没什么。一定是我的大脑在捉弄我。"
    translate None cyne_chapter3_0226:
        "凉爽的风吹动着环绕在我四周的干枯落叶。我无视脑海中响起的警铃声，继续向蚀之地方向前进。"

    window hide dissolve

    jump meetlucius

label cynesecretvillage1:

    scene bg sv room night with Fade(1.0, 1.0, 1.0):
        xpos 0.65 ypos 1.08 xanchor 0.5 yanchor 1.0 zoom 1.32
    window show dissolve
    play music "sounds/bgm/sad.ogg" fadein 4.0
    translate None cyne_chapter3_0227:
        "一位年轻男子仰躺在不属于他的床上，身处不属于他的地方。"
    translate None cyne_chapter3_0228:
        "就像他生命中待过的所有其他场所一样。"
    translate None cyne_chapter3_0229:
        "他轻叹一声，双臂枕在脑后，缓缓合上双眼。"
    translate None cyne_chapter3_0230:
        cmn "我在这里做什么？我根本帮不上雷恩—只会拖累他。"
    translate None cyne_chapter3_0231:
        cmn "他大概再也不想见到我了。我欺骗他，利用他，接近他只为最后背叛他。"
    translate None cyne_chapter3_0232:
        cmn "…我不配有这样的感受。我没资格沮丧，尤其在错全在我时。"
    translate None cyne_chapter3_0233:
        "赛恩又叹了口气，坐起身，下床在房间里来回踱步。"
    translate None cyne_chapter3_0234:
        "这房间很简朴—比他以往任何过夜处都要简单，而他住过的地方多到数不清。"
    translate None cyne_chapter3_0235:
        "只要能远离{i}那栋{/i}房子。远离{i}那群{/i}人。"
    translate None cyne_chapter3_0236:
        "但现在，他发现自己陷入了超乎想象的境地。神明、恶魔、言者、神话人物…这一切何时才是个头？"
    translate None cyne_chapter3_0237:
        cmn "与他们相比…我算什么？一个普通人。不，连普通人都不如。"
    translate None cyne_chapter3_0238:
        stop music fadeout 2.0
        cmn "伊尔兰能打斗。他狡猾、聪明又富有魅力。卡斯皮安是皇室血脉。而我格格不入。我是无名小卒。我一无是处。"
    translate None cyne_chapter3_0239:
        cmn "我从来都不够好…"

    window hide dissolve

    play music "sounds/bgm/moonnight.ogg" fadein 4.0
    scene gallery_101 with fade:
        subpixel True xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.49 rotate None
        parallel:
            xpos 0.71
            easein 15.0 xpos 0.47
    window show dissolve
    translate None cyne_chapter3_0240:
        "人来人往。"
    translate None cyne_chapter3_0241:

        "就像永不停歇的溪流。今天一人，昨日两人。明日又将如何？无人能料。"
    translate None cyne_chapter3_0242:
        "一个小男孩坐在宽敞的庄园里，手指悬在钢琴键上。他弹奏着一支曲子。"
    translate None cyne_chapter3_0243:
        "这是他为自学自娱谱写的。无论如何都是头一遭。第一次为自己做选择，第一次尝试夺回人生的微小掌控权。"
    translate None cyne_chapter3_0244:
        "身着绿裙的女人倚在大楼梯扶手上，从他身后静静注视。"
    translate None cyne_chapter3_0245:
        "不了解她的人或许会以为，她正专注聆听，兴致盎然。"
    translate None cyne_chapter3_0246:
        "男孩笔直地坐在琴凳边缘，背脊挺直，双臂放松。他的手指在琴键上舞动，弹奏着一曲忧伤的旋律。"
    translate None cyne_chapter3_0247:
        "琴声在空荡昏暗的房间里回荡。没有听众，但他弹得仿佛全世界的目光都聚焦于此。"
    translate None cyne_chapter3_0248:
        "那是一曲萦绕于空，沉甸于心的歌。一首让你充满悲伤的歌，一种终身难忘的悲戚。"
    translate None cyne_chapter3_0249:
        "他的手指突然停下。乐曲终了。"
        scene gallery_101 with Dissolve(2.0)
    translate None cyne_chapter3_0250:
        lv neu "精彩。多么美妙的曲子。"
    translate None cyne_chapter3_0251:
        "若非男孩本就坐姿端正，这个声音的出现会让他瞬间改变姿势。"
    translate None cyne_chapter3_0252:
        lv "不过，我想这应该不是你的导师要求练习的曲目吧？"
    translate None cyne_chapter3_0253:
        c "….不是，母亲。"
    translate None cyne_chapter3_0254:
        lv "下不为例。"
    translate None cyne_chapter3_0255:
        "女子转身走回房间，那里还有另一个陌生人在等她。"
    translate None cyne_chapter3_0256:
        "男孩望着她的背影。一个他已见过无数次的背影。"
    translate None cyne_chapter3_0257:
        "一个永远背对着他的人。"
    translate None cyne_chapter3_0258:
        c "…母亲，父亲在哪里？"
    translate None cyne_chapter3_0259:
        lv "…出去了。别再提他。"
    translate None cyne_chapter3_0260:
        c "是，母亲…"
    translate None cyne_chapter3_0261:
        $ about_Cyne._text = [
        "一个孤独的男孩坐在钢琴前。\n \n这就是赛恩。\n \n童年时期，他就在父母没有爱情的婚姻中长大。有些观念从小就烙印进他的骨髓—你必须以特定方式着装、言谈、行事。你必须循规蹈矩。绝不能让家族蒙羞。\n \n但最重要的是，阴影里发生的事都无关紧要。只要别让人看见。\n \n年复一年，赛恩对这种生活逐渐麻木。何必隐藏真实的自己？何必维持虚伪的表象？既然爱情只是门面，又何必在乎爱情？\n \n他就这样生活了许多年，直到遇见某个人。一个改变他所有观念的人。"
        ]
    translate None cyne_chapter3_0262:
        "房门在她身后重重关上，{a=set_entry:enc_people->about_Cyne}{color=#87CEEB}他再度孑然一身{/color}{/a}。"
    translate None cyne_chapter3_0263:
        "一如既往。"
    translate None cyne_chapter3_0264:
        "若不是钢琴，就是小提琴。若不是小提琴，或许是大提琴。但无论他做什么，无论取得多少成就，永远都不够好。"
    translate None cyne_chapter3_0265:
        "他不过是达成目的的工具。一件多余的累赘。一段为金钱权力联姻的产物，一个只为母亲利益而存在的孩子。"
    translate None cyne_chapter3_0266:
        "充其量只是块垫脚石。"
    translate None cyne_chapter3_0267:
        "当少年坐在钢琴前，月光从窗外漫进来时，他突然产生一个念头。"
    translate None cyne_chapter3_0268:
        "他想，或许这就是人类爱的极限了。"
    translate None cyne_chapter3_0269:
        "任何声称有更高层次爱的人都是在撒谎。"
    translate None cyne_chapter3_0270:
        "如果爱的意义仅止于此，那又何苦追求？"
    translate None cyne_chapter3_0271:
        "于是他的手指再次悬在琴键上方，弹奏起一首曲子。"


    scene black with Dissolve(2.0)
    translate None cyne_chapter3_0272:
        "起初一切如常。少年机械地完成被要求的每件事，但绝不多做分毫。"
    translate None cyne_chapter3_0273:
        "无人注意时他为所欲为。后来厌倦伪装，便也不再介意旁人眼光。"
    translate None cyne_chapter3_0274:
        "想惹事时就惹事，想逃离时就逃离，想放纵时就放纵。"
    translate None cyne_chapter3_0275:
        "他就这样苟活着。幸存着。"
    translate None cyne_chapter3_0276:
        "但这不可能不被察觉。"
    translate None cyne_chapter3_0277:
        "以他的身份，本应遵守某种心照不宣的礼仪规范。"
    translate None cyne_chapter3_0278:
        "他却对此嗤之以鼻。这种虚伪的规则令他发笑。"
    translate None cyne_chapter3_0279:
        "关起门来，人人都一个德行。欺骗，谎言，背后捅刀。"
    translate None cyne_chapter3_0280:
        "他们交头接耳议论这位周旋于众人之间的年轻贵族，仿佛自己就没干过同样的事。"
    translate None cyne_chapter3_0281:
        stop music fadeout 2.0
        "只要不被发现就可以为所欲为，对吧？"
    translate None cyne_chapter3_0282:
        "只要能出人头地，做什么都行，对吧？"
    translate None cyne_chapter3_0283:
        "世道就是如此。攀高枝结婚，把玩具养在外头。"
    translate None cyne_chapter3_0284:
        play music "sounds/bgm/creepy.ogg" fadein 2.0
        mn "要听母亲的话知道吗？娶个门当户对的姑娘。不必喜欢她。大可以私下找别的乐子。"

    window hide dissolve

    translate None cyne_chapter3_0285:
        crazy "{move}{sc=2}{color=#FFFF}{size=50}麻烦制造者。{/sc}{/move}"
    translate None cyne_chapter3_0286:
        crazy "{move}{sc=2}{color=#FFFF}{size=50}肮脏。{/sc}{/move}"
    translate None cyne_chapter3_0287:
        crazy "{move}{sc=2}{color=#FFFF}{size=50}祸害。{/sc}{/move}"
    translate None cyne_chapter3_0288:
        crazy "{move}{sc=2}{color=#FFFF}{size=50}粗鄙。{/sc}{/move}"
    translate None cyne_chapter3_0289:
        crazy "{move}{sc=2}{color=#FFFF}{size=50}恶俗。{/sc}{/move}"
    translate None cyne_chapter3_0290:
        crazy "{move}{sc=2}{color=#FFFF}{size=50}下流.{/sc}{/move}"
    translate None cyne_chapter3_0291:
        crazy "{move}{sc=2}{color=#FFFF}{size=50}粗鄙.{/sc}{/move}"


    stop music
    scene bg sv room night:
        xpos 0.51 ypos 1.15 xanchor 0.5 yanchor 1.0 zoom 1.15
    show cyne nw dim sad
    with hpunch
    translate None cyne_chapter3_0292:
        c "不，不…闭嘴…"
    translate None cyne_chapter3_0293:
        show cyne nw dim ang with dis
        c "闭嘴！"
    translate None cyne_chapter3_0294:
        show cyne nw dim sad with dis
        c "求你了…求求你闭嘴.."
    translate None cyne_chapter3_0295:
        "赛恩用双手捂住脸，拼命想要忘记。"
    translate None cyne_chapter3_0296:
        "他永远无法融入—那为何还要尝试？他永远无法适应他们的模板—那为何还要强迫自己？"
    translate None cyne_chapter3_0297:
        "但如果他不尝试，也不强迫自己，还剩下什么？"
    translate None cyne_chapter3_0298:
        play sound "sounds/sfx/knock.ogg" fadein 1.0
        show cyne nw dim neu with dis
        "一阵敲门声响起，赛恩的目光猛地投向这个突兀刺耳的声音，把他从自己的思绪中拽了出来。"
    translate None cyne_chapter3_0299:
        play music "sounds/bgm/Scary.ogg" fadein 4.0
        c "……进来。"
    translate None cyne_chapter3_0300:
        show cyne at slightleft with move
        show caspian n dim sad at slightright with dissolve
        cas "抱歉打扰，但我听到叫喊声。一切都还好吗？"
    translate None cyne_chapter3_0301:
        "赛恩抬头看着这个男人，将他脸上的每一寸都尽收眼底。没错，他年纪大了些，也更粗犷了些，但他的眼神依旧。那种感觉依旧。"
    translate None cyne_chapter3_0302:
        show cyne nw dim sad with dis
        c "…..你给我的感觉就像雷恩。"
    translate None cyne_chapter3_0303:
        show caspian n dim sur with dis
        cas "什么？"
    translate None cyne_chapter3_0304:
        c "…..算了。我没事，只是…想起了一段糟糕的回忆。"
    translate None cyne_chapter3_0305:
        show caspian n dim sad with dis
        cas "...."
    translate None cyne_chapter3_0306:
        cas "也许我们可以互相倾听一会儿。"
    translate None cyne_chapter3_0307:
        c "...."
    translate None cyne_chapter3_0308:
        "卡斯皮安拉了把椅子，坐下，面对着赛恩。"
    translate None cyne_chapter3_0309:
        cas "说吧，告诉我怎么了。我或许能给点建议。"
    translate None cyne_chapter3_0310:
        cmn "我不这么认为。"
    translate None cyne_chapter3_0311:
        c "...."
    translate None cyne_chapter3_0312:
        c "我不知道从何说起。"
    translate None cyne_chapter3_0313:
        show caspian n dim neu with dis
        cas "从头开始。"
    translate None cyne_chapter3_0314:
        cmn "他甚至说的话都和雷恩一样。"
    translate None cyne_chapter3_0315:
        c "…..那我就长话短说，不浪费你的时间了。"
    translate None cyne_chapter3_0316:
        c "我只是家族的工具。一个筹码。我所做的任何事情都不够好。"
    translate None cyne_chapter3_0317:
        c "在我身边，我看到的尽是背叛、谎言、欺骗，而这一切都被视为理所当然。但你最好不要谈论它，哦不。"
    translate None cyne_chapter3_0318:
        c "而我想…我想如果爱一个人意味着你必须坐等着被背叛，那又何必。"
    translate None cyne_chapter3_0319:
        show caspian n dim sur with dis
        cas "...."
    translate None cyne_chapter3_0320:
        c "...."
    translate None cyne_chapter3_0321:
        cas "好吧，我不知道我期待你会说什么，但不是这个。"
    translate None cyne_chapter3_0322:
        cas "你让我想起了艾米尔，知道吗。"
    translate None cyne_chapter3_0323:
        show cyne nw dim ang with dis
        c "什么…？怎么会？"
    translate None cyne_chapter3_0324:
        cas "我不清楚你对他了解多少，但他一出生就被从家人身边带走，在我身边长大。"
    translate None cyne_chapter3_0325:
        show caspian n dim sad with dis
        cas "他恨透了这个。他被强迫扮演一个他厌恶的角色，无处可逃。"
    translate None cyne_chapter3_0326:
        cas "…你知道吗？我以前从未注意到这些。我太过沉浸在自己的世界里，满脑子都是对冒险的渴望。一切总是我、我、我。"
    translate None cyne_chapter3_0327:
        cas "我把事情搞砸了。但那是另一个问题了。"
    translate None cyne_chapter3_0328:
        c "所以，这对我来说有什么用呢？"
    translate None cyne_chapter3_0329:
        cas "他无处宣泄。他把所有情绪都压抑在心里，直到爆发，而那时…伤害已经造成了。"
    translate None cyne_chapter3_0330:
        cas "不同的是你有机会说出来，改变现状。在事情变糟之前挽回一切。"
    translate None cyne_chapter3_0331:
        cas "爱的一部分就是让自己暴露在可能受伤的风险中。这可能会很痛苦，可能会导致心碎，但你知道吗？"
    translate None cyne_chapter3_0332:
        show caspian n dim smi with dis
        cas "这个冒险是值得的。不要等到为时已晚时才后悔没有勇敢尝试。"
    translate None cyne_chapter3_0333:
        show cyne nw dim sad with dis
        c "..."
    translate None cyne_chapter3_0334:
        cas "总之，该说的我都说了。好好想想吧。哦，如果你见到雷恩，能不能…让他来找我？"
    translate None cyne_chapter3_0335:
        "卡斯皮安站起来，朝门口走去。就在他正要离开时，赛恩叫住了他。"
    translate None cyne_chapter3_0336:
        show cyne nw dim neu with dis
        c "…对你来说还不算太晚。"
    translate None cyne_chapter3_0337:
        show caspian n dim sur with dis
        cas "什么？"
    translate None cyne_chapter3_0338:
        c "他还是喜欢你的。"
    translate None cyne_chapter3_0339:
        cas "真的吗…？"
    translate None cyne_chapter3_0340:
        show cyne nw dim smi with dis
        c "当然是真的。"
    translate None cyne_chapter3_0341:
        show caspian n dim hap with dis
        "卡斯皮安带着一个让他想起雷恩的笑容离开了房间。"

    window hide dissolve
    stop music fadeout 3.0



    scene bg sv night:
        xpos 0.28 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.47
    show raen mw dark cloak sad at mright
    show morwen m dark sad cloakup at mleft
    with Fade(1.0, 1.0, 1.0)
    window show dissolve
    translate None cyne_chapter3_0342:
        "我想…谁都看得出来…"
    translate None cyne_chapter3_0343:
        play music "sounds/bgm/night.ogg" fadein 3.0
        rs "他最近表现得…很奇怪。"
    translate None cyne_chapter3_0344:
        mor "奇怪？"
    translate None cyne_chapter3_0345:
        rs "就是…很疏远。他一直在躲着我。"
    translate None cyne_chapter3_0346:
        rs "而且…我对他也感觉很不一样。"
    translate None cyne_chapter3_0347:
        show morwen m dark smi with dis
        mor "年轻人的爱情真是甜蜜啊，不是吗？"
    translate None cyne_chapter3_0348:
        rs "你真的觉得是这样吗？"
    translate None cyne_chapter3_0349:
        mor "是的。"
    translate None cyne_chapter3_0350:
        "一种轻松的感觉涌上心头。一种…被肯定的感觉。"
    translate None cyne_chapter3_0351:
        "是啊…我是爱他的，对吧？"
    translate None cyne_chapter3_0352:
        rs "那…他为什么那样表现呢？"
    translate None cyne_chapter3_0353:
        show morwen m dark sad with dis
        mor "对有些人来说…爱并不容易。"
    translate None cyne_chapter3_0354:
        mor "你信任他，不是吗？"
    translate None cyne_chapter3_0355:
        rs "是的。"
    translate None cyne_chapter3_0356:
        show morwen m dark hap with dis
        "她笑了起来，整张脸都焕发光彩。"
    translate None cyne_chapter3_0357:
        mor "那就一切都会好的。或许需要一点推力，但我知道你们能解决。"
    translate None cyne_chapter3_0358:
        mor "找个时间和他坐下来好好谈谈。"


    jump caspianraen

label cynenighttimesv:
    translate None cyne_chapter3_0359:
        "当卡斯皮安离开后，我发现自己徘徊在赛恩的房门外。他只隔着一扇门。近得我几乎能感受到他的存在。"
    translate None cyne_chapter3_0360:
        "但是…又感觉他那么遥不可及。"

    window hide dissolve

    scene bg sv room night:
        xpos 0.5 ypos 1.26 xanchor 0.5 yanchor 1.0 zoom 1.33
    show cyne nw dim sur at slightleft
    show raen nw dim sur at slightright
    with dissolve
    window show dissolve
    translate None cyne_chapter3_0361:
        c "...!"
    translate None cyne_chapter3_0362:
        show raen nw dim sad with dis
        rs "…赛恩。"
    translate None cyne_chapter3_0363:
        show cyne nw dim sad with dis
        c "嘿…这么晚了你在这里做什么？"
    translate None cyne_chapter3_0364:
        rs "我碰到了卡斯—不，是我父亲。"
    translate None cyne_chapter3_0365:
        c "所以他还是找到你了…"
    translate None cyne_chapter3_0366:
        "身后，门锁\"咔嗒\"一声关上了。"
    translate None cyne_chapter3_0367:
        c "…我不会逃跑的。我也想和你谈谈。"
    translate None cyne_chapter3_0368:
        c "我…我非常抱—"
    translate None cyne_chapter3_0369:
        rs "对不起。"
    translate None cyne_chapter3_0370:
        show cyne nw dim sur with dis
        c "等等，什么？为什么道歉？"
    translate None cyne_chapter3_0371:
        rs "我很抱歉对你隐瞒了秘密。很抱歉把你卷进这么多麻烦。"
    translate None cyne_chapter3_0372:
        rs "我为很多事情感到抱歉。我犯了太多错误，最终不得不过分依赖周围的人。"
    translate None cyne_chapter3_0373:
        rs "但是…爱上你这件事，我绝不后悔。我永远不会为此道歉。"
    translate None cyne_chapter3_0374:
        c "...."
    translate None cyne_chapter3_0375:
        show cyne nw dim sad with dis
        c "雷恩—"
    translate None cyne_chapter3_0376:
        rs "我该怎么做才能弥补？"
    translate None cyne_chapter3_0377:
        c "雷恩…你是世界上唯一一个明明没做错事还会道歉的人。这太像你了。"
    translate None cyne_chapter3_0378:
        c "都是我的错。是我推开你的。我害怕了。"
    translate None cyne_chapter3_0379:
        hide cyne
        hide raen
        with dissolve
        "当他双唇贴上我的时，我屏住了呼吸。轻柔而缓慢的触碰，仿佛他仍不确定自己在做什么。"
    translate None cyne_chapter3_0380:
        "我俯身靠近他，将他拉入怀中。时间仿佛停止了。说真的，我希望时间就此停驻。"
    translate None cyne_chapter3_0381:
        "我的所有感官都被他占据。他的气息，他的味道，他唇瓣的触感。"
    translate None cyne_chapter3_0382:
        "缓缓地，他退开一些，与我额头相抵。"
    translate None cyne_chapter3_0383:
        c wemb"这都是你的错，你知道吗？"
    translate None cyne_chapter3_0384:
        rs wemb "什么？"
    translate None cyne_chapter3_0385:
        c "所有这些！因为你，我再也无法看向别人。这感觉像是背叛。你彻底毁了我！"
    translate None cyne_chapter3_0386:
        rs "我很—"
    translate None cyne_chapter3_0387:
        c "闭嘴。"
    translate None cyne_chapter3_0388:
        c "你不是刚说过绝不后悔吗？"
    translate None cyne_chapter3_0389:
        "我的目光在他脸上流连，拼命想读懂他的想法。当然，我的视线也不止一次游移到他的唇上。"
    translate None cyne_chapter3_0390:
        "他再次吻住我，比先前热烈得多。他的舌头轻舔过我的唇瓣，却又倏然退开。"
    translate None cyne_chapter3_0391:
        c wang "你最好负起责任来。"

    show bg sv room night with vpunch:
        xpos 0.77 ypos 1.4 xanchor 0.5 yanchor 1.0 zoom 1.85
    translate None cyne_chapter3_0392:
        "我的心在胸腔里剧烈跳动，声音大得惊人，但此刻没什么能阻止我们。我们再度缠绵相拥，跌跌撞撞穿过房间，重重倒在了床上。"
    translate None cyne_chapter3_0393:
        "赛恩的身体被我压在身下，我们的胸膛紧紧相贴。他中断这个吻，用那双翠绿的大眼睛凝视着我。"
    translate None cyne_chapter3_0394:
        c whap "我想我爱上你了。"
    translate None cyne_chapter3_0395:
        "他的手臂环住我的脖子，对我露出笑容。笨拙的，凌乱的，完全不像他惯常的微笑。"
    translate None cyne_chapter3_0396:
        "一个真诚的，温暖人心的笑容。"
    translate None cyne_chapter3_0397:
        "我感到一股暖流漫过全身，不由自主地回以微笑。"
    translate None cyne_chapter3_0398:
        "他…对我也有同样的感觉。我的感受没有错。"
    translate None cyne_chapter3_0399:
        "赛恩扣住我的后颈将我拉回亲吻，我们的身体贴得更紧。那个悠闲温柔的吻很快演变成更淫靡的东西—更下流，也更充满柔情与激情。"
    translate None cyne_chapter3_0400:
        "他的一切都吞噬着我。"
    translate None cyne_chapter3_0401:
        "他的呼吸在我唇畔变得愈发灼热，我的也是。"
    translate None cyne_chapter3_0402:
        rs wemb "赛恩…"

    stop music fadeout 3.0

    translate None cyne_chapter3_0403:
        "我带着哀求的目光低头凝视他。他点头回应，我便小心翼翼地开始解开他的层层衣物。"
    translate None cyne_chapter3_0404:
        c wemb "等等雷恩，这个…"
    translate None cyne_chapter3_0405:
        "他从口袋里摸出一个小瓶递给我。那个我已经见过好几次的瓶子。"
    translate None cyne_chapter3_0406:
        play music "sounds/bgm/sex.ogg" fadein 5.0
        rs wemb"真的…？"
    translate None cyne_chapter3_0407:
        c "我不是告诉过你吗？这东西随时可能…派上用场。"
    translate None cyne_chapter3_0408:
        "房间冰冷刺骨，只是简陋的木结构。完全不像锡德卡汉那些温暖隔音的墙壁。"
    translate None cyne_chapter3_0409:
        "但此刻赛恩却允许我为他宽衣。缓慢地，性感地，仿佛仅是褪去衣物的过程就让他更加兴奋。"
    translate None cyne_chapter3_0410:
        "我用指尖托起他的下巴，在他脖颈至胸膛留下一连串轻吻。每次轻咬都会在他皮肤上留下红痕，这让我格外着迷。"
    translate None cyne_chapter3_0411:
        "作为回应，他急切地拉扯我的衣服。我已然能感觉到他抵着我的硬挺。"
    translate None cyne_chapter3_0412:
        c "雷恩…"
    translate None cyne_chapter3_0413:
        "最后一件衣物坠落地面，他那光滑诱人的肌肤—点缀着我留下的吻痕—终于完全展露。"
    translate None cyne_chapter3_0414:
        rs "你…天啊你真美…"
    translate None cyne_chapter3_0415:
        "他美得惊人—在清冷月光下几乎散发着微光。我一刻都无法忍受嘴唇离开他的身体。"
    translate None cyne_chapter3_0416:
        "当我吻遍他的躯体时他逸出呻吟，当我的舌头滑过他的茎身时那声音又再度响起。"
    translate None cyne_chapter3_0417:
        "他曾经为我这样做过…我只要模仿他就好，对吧…？"
    translate None cyne_chapter3_0418:
        "回想起那个仿佛很久以前的夜晚，我模仿着他的动作，吮吸舔舐着他的顶端。"
    translate None cyne_chapter3_0419:
        "他的双眼因快感而朦胧，手指紧攥床单。光是看着他我就迫不及待想要品尝他的每一寸。"
    translate None cyne_chapter3_0420:
        "我慢慢将他含入口中，双颊凹陷。当他顶到我喉咙深处时，任何事物都阻止不了他充满情欲的呻吟。"
    translate None cyne_chapter3_0421:
        "它比我想象中要大得多、热得多。他是怎么做到如此轻松地全部含进去的？"
    translate None cyne_chapter3_0422:
        c "啊！嗯…"
    translate None cyne_chapter3_0423:
        "接下…接下来他该怎么做来着？"
    translate None cyne_chapter3_0424:
        "见我迟迟不动，他便主动把臀部往后抽了抽，然后慢慢推回到我嘴里。他的阴茎刮擦着我的上颚，我赶紧模仿他的动作，一边上下摆动头部一边吮吸着。"
    translate None cyne_chapter3_0425:
        "他在我舌头上膨胀跳动，眉头紧锁、满脸通红地注视着我。时不时会忍不住抓住我的脑袋往喉咙里顶。我并不介意。"
    translate None cyne_chapter3_0426:
        "腾出双手后，我迅速打开赛恩留给我那瓶东西的盖子，将手指沾满滑溜溜的湿滑液体。"
    translate None cyne_chapter3_0427:
        "我把两根手指抵在他入口处，他毫不费力地接纳了。他的手指穿进我发间，抓握着拉扯。"
    translate None cyne_chapter3_0428:
        c "啊，操，雷恩…别停…！"
    translate None cyne_chapter3_0429:
        "我故意慢慢用舌面顺着他的阴茎底部舔舐，同时紧盯着他的眼睛。"
    translate None cyne_chapter3_0430:
        "每深入一寸，他的呻吟就越发急促，我沿着湿润的痕迹舔回源头，再次将它全部含入。"
    translate None cyne_chapter3_0431:
        c "呃…我要…我要—"
    translate None cyne_chapter3_0432:
        "当加入第三根手指时，赛恩突然用力按住我的头，在我口中爆发时仍将我牢牢抵在他性器上。"
    translate None cyne_chapter3_0433:
        "这过于突然让我眼角泛起泪花，但我全数咽下，才抬头望向赛恩。"
    translate None cyne_chapter3_0434:
        "现在，他当时是怎么做的来着…？"
    translate None cyne_chapter3_0435:
        "啊，想起来了！"
    translate None cyne_chapter3_0436:
        "我吞咽完毕，冲满脸通红的赛恩露出笑容。"
    translate None cyne_chapter3_0437:
        c "你这小淫魔…谁教你这些的？"
    translate None cyne_chapter3_0438:
        rs wsmi"有位优秀导师，你大概认识他。"
    translate None cyne_chapter3_0439:
        "我的手指仍在他体内，赛恩颤抖着俯身拿走我手中的瓶子。轻轻倾斜瓶身，滑腻液体便倾泻在我的阴茎上，赛恩只撸动几下就让它完全裹满了液体。"
    translate None cyne_chapter3_0440:
        "他饥渴地俯视着我，用眼神发出邀请。最后冲刺一次后，我抽出手指，抵上了他的入口。"
    translate None cyne_chapter3_0441:
        rs wemb "现在…哈啊…可以了吗？"
    translate None cyne_chapter3_0442:
        c "何止可以…求你了…"
    translate None cyne_chapter3_0443:
        scene gallery_103
        if persistent.streamer_mode:
            show cyne_4_sex_censor

        with dissolve
        "我没有再浪费一刻。起初我缓缓进入他，让自己沉浸在他温暖的包裹中。不疾不徐，在每次抽离与再次进入时细细品味这份感受。"
    translate None cyne_chapter3_0444:
        "我发出一阵不受控制的颤抖—赛恩显然注意到了。他抬手捧住我的脸，随即吻了上来。"
    translate None cyne_chapter3_0445:
        "他轻咬我的下唇，用舌尖挑逗着我。作为回应，我朝他摆动腰肢，这次更快了些，也稍微加重了力道。"
    translate None cyne_chapter3_0446:
        "他在我阴茎周围延展开来，伴随着颤栗完全容纳了它，抵着我的唇边发出呻吟。 "
    translate None cyne_chapter3_0447:
        "为什么…为什么他仅仅一个声响就能让我如此燥热？仿佛他口中逸出的每个音符都直击我心脏。"
    translate None cyne_chapter3_0448:
        "哦，或许该说是直击我的胯下，而非心脏。"
    translate None cyne_chapter3_0449:
        "又或者…两处都是？"
    translate None cyne_chapter3_0450:
        "赛恩的手指游走在我胸口，用颤抖的双手爱抚我的肌肤，随后与我十指相扣。"
    translate None cyne_chapter3_0451:
        c "啊..嗯…这是..我的第一次…"
    translate None cyne_chapter3_0452:
        rs "啊？什么…什么意思..？"
    translate None cyne_chapter3_0453:
        c "这是我第一次…啊！第一次和爱的人做…"
    translate None cyne_chapter3_0454:
        "我低头看他。被我填满着，如此珍重地拥抱着我。说着让我心脏鼓胀的话语。"
    translate None cyne_chapter3_0455:
        rs "…我也是…"
    translate None cyne_chapter3_0456:
        "我的抽插变得更快、更重、更无章法。面对面看着他每次被我进入时扭动颤抖的模样。"
    translate None cyne_chapter3_0457:
        "他双手与我紧紧相扣，手指都陷进我肉里。我也用力回握。"
    translate None cyne_chapter3_0458:
        "我调整角度，用力冲撞着寻找那个位置—那个能让赛恩愉悦尖叫的位置。"
    translate None cyne_chapter3_0459:
        "在我们交合处，赛恩的阴茎因彼此肌肤摩擦已经再度半勃。虽然我极想伸手抚慰它，在操干他的同时套弄它看他的表情，但他正铁钳般抓着我的手。"
    translate None cyne_chapter3_0460:
        c "啊！！！"
    translate None cyne_chapter3_0461:
        "找到了。"
    translate None cyne_chapter3_0462:
        "对准那个让他起反应的角度，我突然猛烈撞击，他顿时发出响亮的呻吟，简直让人以为我在杀他。"
    translate None cyne_chapter3_0463:
        c "啊、雷恩，啊！！别停！"
    translate None cyne_chapter3_0464:
        "这景象让我呼吸一滞，但我没有停下。毕竟我们初见时他说过什么来着？保持连贯很重要。"
    translate None cyne_chapter3_0465:
        "赛恩的背部弓起，我开始怀疑明天手上会不会留下淤青。"
    translate None cyne_chapter3_0466:
        "唔，谁在乎呢？"
    translate None cyne_chapter3_0467:
        "在我们之间，赛恩的分身已经完全挺立，我遗憾不能给予它应有的对待，但这似乎并不重要—它已经被前液弄得湿滑。"
    translate None cyne_chapter3_0468:
        "热度变得几乎难以忍受，仿佛赛恩的内壁正在向我压来—紧紧包裹着我。事实上，我觉得他确实正在这么做。"
    translate None cyne_chapter3_0469:
        "我的世界已经缩小到只剩下赛恩。我们之间的欢愉，他身体的曲线，他声音的呢喃。我几乎快要克制不住自己了。"
    translate None cyne_chapter3_0470:
        rs "赛恩，我…我觉得我要—"
    translate None cyne_chapter3_0471:
        c "继…唔…继续。"
    translate None cyne_chapter3_0472:
        show gallery_103
        if persistent.streamer_mode:
            show cyne_4_sex_censor

        with hpunch
        "随着一声压抑的呻吟，赛恩的体液洒在我们身上，大部分落在他自己胸前，而仅仅片刻之后，我终于找到了追寻的释放。"
    translate None cyne_chapter3_0473:
        "双手仍然交缠，我无力地倒在赛恩身上，再也支撑不住自己。"

    window hide dissolve

    scene bg sv room night with dissolve:
        xpos 0.6 ypos 1.12 xanchor 0.5 yanchor 1.0 zoom 1.35
    window show dissolve
    translate None cyne_chapter3_0474:
        rs wemb "哈…哈…"
    translate None cyne_chapter3_0475:
        c wemb "哈….你真的进步了很多…"
    translate None cyne_chapter3_0476:
        rs "这都多亏了你。"
    translate None cyne_chapter3_0477:
        c "被我所腐蚀这件事，值得你这么开心吗？"
    translate None cyne_chapter3_0478:
        rs "我随时都乐意被你腐蚀。"
    translate None cyne_chapter3_0479:
        c wsur "...."
    translate None cyne_chapter3_0480:
        c wsad "天啊…从今以后我都要忍受这种肉麻的情话了吗？也许我该重新考虑这段关系了…"
    translate None cyne_chapter3_0481:
        rs wsad "喂！"
    translate None cyne_chapter3_0482:
        c whap "啊哈哈哈，开玩笑的，开玩笑啦。"
    translate None cyne_chapter3_0483:
        rs wsmi "….我真的很喜欢你，赛恩。"
    translate None cyne_chapter3_0484:
        "他的脸变得更红了，同时轻轻捏了捏我的手。"
    translate None cyne_chapter3_0485:
        c wemb "我…我也喜欢你。"
    translate None cyne_chapter3_0486:
        c "但拜托，从我身上下来。看看你搞的一团糟！我还能感觉到有东西从里面流出来—"
    translate None cyne_chapter3_0487:
        rs wemb "好了好了，我知道了。行吧。"
    translate None cyne_chapter3_0488:
        "我与他分开。顷刻间便被不愿放手的渴望所充斥，但我把这念头赶出了脑海。"
    translate None cyne_chapter3_0489:
        "只要能看着他，知道他是我的…"
    translate None cyne_chapter3_0490:
        "这就够了。"

    stop music fadeout 3.0
    window hide dissolve

    if iv_scene_two and illranveras_friend >= 5:
        jump illranverasscene3

    else:
        jump veraselliot


label aftersex:
    scene bg sv room night with Fade(1.0, 1.0, 1.0):
        xpos 0.6 ypos 1.12 xanchor 0.5 yanchor 1.0 zoom 1.35
    translate None cyne_chapter3_0491:
        "我躺回床上，将薄毯拉过来盖住赛恩和我。房间里很冷，甚至带着寒意，但有赛恩紧贴着…我感到足够温暖。"
    translate None cyne_chapter3_0492:
        play music "sounds/bgm/night.ogg" fadein 4.0
        "他紧紧抱住我，把脸埋在我的颈窝里。"
    translate None cyne_chapter3_0493:
        c wsmi "准备好第二轮了吗？啊，别摆那副表情。我只是在逗你玩。"
    translate None cyne_chapter3_0494:
        rs wsad "我永远猜不透你…"
    translate None cyne_chapter3_0495:
        c wsad "今天真是糟透了的一天，就连我也有自己的极限。"
    translate None cyne_chapter3_0496:
        rs wsmi "有时候我不确定你是否真有极限…"
    translate None cyne_chapter3_0497:
        c "…对不起，你知道的。我犯了个错误。"
    translate None cyne_chapter3_0498:
        rs wsad "你选择保护我，即使这意味着要对抗自己的母亲，对吧？你没有什么需要道歉的。"
    translate None cyne_chapter3_0499:
        c wsur "你难道一点都不担心我还在骗你吗？"
    translate None cyne_chapter3_0500:
        rs wsmi "不担心。也许你没注意到，但我有点傻。不过有时候这反而对我有利。"
    translate None cyne_chapter3_0501:
        c whap "噢，我注意到了。"
    translate None cyne_chapter3_0502:
        c wemb "…谢谢，雷恩。"
    translate None cyne_chapter3_0503:
        rs "你不必现在就说，但如果你想倾诉，我随时都在。"
    translate None cyne_chapter3_0504:
        c wsad "其实没什么好说的…我只是…"
    translate None cyne_chapter3_0505:
        c "我身边的人都让我明白，爱不过是达到目的的手段。一种困住别人然后抛弃的方式。"
    translate None cyne_chapter3_0506:
        c "所以我选择了反抗。你看到人们是怎么说我的。他们觉得我恶心、肮脏，只因为我公开了他们偷偷摸摸做的事，但他们却觉得自己比我高尚。"
    translate None cyne_chapter3_0507:
        rs wsur "你父亲怎么了？我从没见过他。"
    translate None cyne_chapter3_0508:
        c "我不知道。他偶尔会来。母亲似乎认为他只是在书房里为家族努力工作，但我们都知道他是和他真正爱的女人在一起。"
    translate None cyne_chapter3_0509:
        c "我几乎不能怪他，毕竟是被她困住的。"
    translate None cyne_chapter3_0510:
        c "但…但这意味着我要单独和她相处。我们见面时他对我还算不错，但…很明显当他看着我的时候，看到的都是她，我能看到他眼中的轻蔑。"
    translate None cyne_chapter3_0511:
        rs "赛恩…"
    translate None cyne_chapter3_0512:
        c "我不需要怜悯。"
    translate None cyne_chapter3_0513:
        rs "我是来倾听的，不是评判的。如果不是因为爱，他们为什么要结婚？"
    translate None cyne_chapter3_0514:
        c "因为我父亲的姓氏比她的更有价值，就是这样。她一直…渴望着晋升，渴望着权力。他不过是她向上爬的阶梯。"
    translate None cyne_chapter3_0515:
        rs "这太可怕了…"
    translate None cyne_chapter3_0516:
        c "但和其他人也没什么不同。如果你看看其他高阶家族，他们都一样。父母、子女，所有人都是如此。"
    translate None cyne_chapter3_0517:
        c "这就是为什么我和他们处不来。为什么我没有很多朋友。"
    translate None cyne_chapter3_0518:
        rs "你有艾琳，不是吗？"
    translate None cyne_chapter3_0519:
        c "这让我的母亲很沮丧…最终她不再反对，只要我发誓不娶她。这显然不是问题。"
    translate None cyne_chapter3_0520:
        rs "你知道吗…当我遇见她时，她向我提起过你。她非常在乎你。也很担心。"
    translate None cyne_chapter3_0521:
        c wsur "…是吗？嗯…也许等这一切结束后，是时候让我们叙叙旧了。"
    translate None cyne_chapter3_0522:
        rs wsmi "听起来不错。"
    translate None cyne_chapter3_0523:
        c "唯一我想不通的是…她到底想从你身上得到什么。我是说，当然，你是言者或其他什么身份—但她不可能知道这个。"
    translate None cyne_chapter3_0524:
        c wsad "不过现在这不重要了。我对她来说什么都不是。"
    translate None cyne_chapter3_0525:
        rs "我们可以组建自己的家庭。我们不需要她。"
    translate None cyne_chapter3_0526:
        c "呃，雷恩，我不确定你是否了解我的身体构造，但是—"
    translate None cyne_chapter3_0527:
        rs "不，不，我不是那个意思。我可以成为你的家人。"
    translate None cyne_chapter3_0528:
        c wsur "...."
    translate None cyne_chapter3_0529:
        c wemb "你又来了，老套的情话。"
    translate None cyne_chapter3_0530:
        rs "而且为此骄傲。"
    translate None cyne_chapter3_0531:
        c "好了，快睡觉吧，否则我真的准备好第二轮了。"
    translate None cyne_chapter3_0532:
        "赛恩闭上眼睛，我静静地注视了他一会儿。"
    translate None cyne_chapter3_0533:
        "看着他胸膛平静地起伏。看着他眉头舒展，安详的神情笼罩面容。看着他睫毛轻触肌肤的模样。"
    translate None cyne_chapter3_0534:
        "他的头发虽然乱糟糟的，但美得惊人。"
    translate None cyne_chapter3_0535:
        "我闭上眼睛，沉入一个无声而幸福的梦境。"

    stop music fadeout 2.0
    window hide dissolve

    scene black with eye_shut
    pause 1.5
    jump morwenelliot


label morwenelliot:

    scene bg sc mountains with Fade(1.0, 1.0, 1.0):
        xpos 0.51 ypos 1.41 xanchor 0.5 yanchor 1.05 zoom 1.6
        linear 15.0 xpos 0.51 ypos 1.67 xanchor 0.5 yanchor 1.05 zoom 1.6
    window show dissolve
    play music "sounds/bgm/forgotten.ogg" fadein 3.0
    translate None cyne_chapter3_0536:
        "一位白发女子，身披冬装，将斗篷紧紧裹在身上。她呼出的白气在寒冷的夜空中清晰可见，她好奇地注视着这一切。"
    translate None cyne_chapter3_0537:
        "在她漫长的一生中，见过雪的次数屈指可数，直到现在才第一次触摸到它。"
    translate None cyne_chapter3_0538:
        "而讽刺的是，如今她终于拥有能触摸雪、在雪中玩耍的身体，却再也做不到了。"
    translate None cyne_chapter3_0539:
        "带着怅然的微笑，她穿行在冬夜里，回忆着年少时光。那些本可以和朋友在雪夜奔跑，打雪仗堆雪人的日子。"
    translate None cyne_chapter3_0540:
        "但现在，永远不可能了。"
    translate None cyne_chapter3_0541:
        "曾经是洗衣女工，如今却不能触碰水。这就是被囚禁在人类躯壳里的神明的宿命。得到某些东西，就必须失去另一些。"
    translate None cyne_chapter3_0542:
        "她的脚印在雪地上留下浅浅痕迹，朝着村庄边缘走去，那里接壤着广袤森林，一直延伸到锡德卡汉才终止。"
    translate None cyne_chapter3_0543:
        "她不停地走啊，走啊。"
    translate None cyne_chapter3_0544:
        "直到她站在幽暗树林的环绕中。手套下的手指轻抚过树皮，白雪轻柔地飘落在林地上。低垂的枝桠上悬挂着衣物，在微风中轻轻摇曳。"
    translate None cyne_chapter3_0545:
        mor cu neu "埃利奥特。"
    translate None cyne_chapter3_0546:
        "黑暗中，两点明亮的黄色光晕朝她靠近。她没有逃跑也没有躲藏。这已是她司空见惯的景象。"
    translate None cyne_chapter3_0547:
        "弑神者埃利奥特。锡德卡汉军队的统帅，曾为驱逐说书人及其信徒而战。"
    translate None cyne_chapter3_0548:
        "正是那个人，在她前往奥雷利亚卡维拉之前，曾目睹他屠戮数百名她的追随者。"
    translate None cyne_chapter3_0549:
        "而今，他竟成了神明。命运的讽刺有时就是如此荒谬。"
    translate None cyne_chapter3_0550:
        mor cu neu "埃利奥特，我想谈谈。"
    translate None cyne_chapter3_0551:
        "如雪般洁白的老虎从阴影中迈出。常人见此必定惊慌失措—但对莫温而言，这不过是寻常景象。"
    translate None cyne_chapter3_0552:
        "她转过身去，给男人留出整理仪容的间隙。"


    scene bg sc mountains
    show morwen m cloakup dark neu at mright
    show elliot m dark neu at mleft
    with dissolve
    translate None cyne_chapter3_0553:
        el "主动召见可不像是你的作风。"
    translate None cyne_chapter3_0554:
        mor "非常时期需要非常手段。你穿好衣服了吗？"
    translate None cyne_chapter3_0555:
        "身后传来埃利奥特更衣的窸窣声。作为神明的恼人之处确实如此，但相比获得的力量，这点不便微不足道。"
    translate None cyne_chapter3_0556:
        "她不再等待，转身面向这个高大魁梧的男人。"
    translate None cyne_chapter3_0557:
        "他与她记忆中的模样截然不同。毕竟这已非他最初的躯体。正如她自己，也早已面目全非。"
    translate None cyne_chapter3_0558:
        el "若是为人类之事而来，就不必白费唇舌。我已无能为力。"
    translate None cyne_chapter3_0559:
        show morwen m cloakup dark ang with dis
        mor "你能做的还有很多，只是懦弱让你止步不前。"
    translate None cyne_chapter3_0560:
        el "那你希望我怎么做？牺牲所有人的性命？不，我这辈子见证的战争够多了—死亡从来都不值得。"
    translate None cyne_chapter3_0561:
        mor "我不是要你放弃他们的生命。是希望你能够再次相信人性。"
    translate None cyne_chapter3_0562:
        show elliot m dark gla with dis
        el "已无甚可信。他们的领袖腐败堕落，下属们争权夺位。与我生前所见毫无二致。"
    translate None cyne_chapter3_0563:
        mor "但这正是变革的时代。对每个人都是。雷恩必须直面宿命，艾米尔需要抗争既定的道路，卡斯皮安已放弃称王的所有可能。"
    translate None cyne_chapter3_0564:
        show morwen m cloakup dark ssmi with dis
        mor "对我们亦是如此。"
    translate None cyne_chapter3_0565:
        el "我们现在已经适应了这种生活方式。我看不出有任何改变的理由。即便奥雷利亚诸神获得自由，一切也不会回到从前的样子。"
    translate None cyne_chapter3_0566:
        mor "…你说得没错。我们的生活可能永远无法回到从前了。"
    translate None cyne_chapter3_0567:
        mor "有些人可能会选择留在奥雷利亚卡维拉，坚守他们无形的形体。另一些人可能会离开，但被迫披上人类的躯壳…"
    translate None cyne_chapter3_0568:
        mor "但那重要吗？无法回到过去真的很重要吗？我认为不重要。他们将重获被剥夺的选择自由。"
    translate None cyne_chapter3_0569:
        mor "…."
    translate None cyne_chapter3_0570:
        show elliot m dark sad with dis
        el "你就这样相信他们的话？相信一个言者的话？"
    translate None cyne_chapter3_0571:
        show morwen m cloakup dark ang with dis
        mor "是的。我相信他们两个。他们才是能打破循环的人。"
    translate None cyne_chapter3_0572:
        el "你知道帮助他们对我们毫无益处，不会改变我们的生活。即使人类重新开始信仰我们，也不足以让我们重返天界。他们的信仰无法供养我们所有人。"
    translate None cyne_chapter3_0573:
        show morwen m cloakup dark ssmi with dis
        "莫温笑了。她知道—她清楚自己的未来就是这副躯体。没有任何瞬间改变。"
    translate None cyne_chapter3_0574:
        mor "我知道。"
    translate None cyne_chapter3_0575:
        mor "但现在或许正是不计个人得失，做出改变的机会。"
    translate None cyne_chapter3_0576:
        mor "我们的生活将充满困难。无论是对融入社会的人，还是隐匿行踪的人。但这不意味着我们就该安于现状。"
    translate None cyne_chapter3_0577:
        mor "我没什么可对你说的了。只希望你能考虑我的话。"
    translate None cyne_chapter3_0578:
        el "...."
    translate None cyne_chapter3_0579:
        el "为什么这么恨我？"
    translate None cyne_chapter3_0580:
        show morwen m cloakup dark neu with dis
        mor "我恨那个向我挚爱之人拔剑的怪物。至于对你的感受，还有待观察。"
    translate None cyne_chapter3_0581:
        hide morwen
        hide elliot
        with dissolve
        "说完最后的话，她转身走向村庄，斗篷在身后翻飞。每一步都缓慢而谨慎。"
    translate None cyne_chapter3_0582:
        "她抬头望向天空。乌云密布，阴沉灰暗。"
    translate None cyne_chapter3_0583:
        mmn "看来风暴也快抵达这里了。"

    window hide dissolve
    stop music fadeout 3.0

    scene bg sv room day with Fade(1.0, 1.0, 1.0):
        xpos 0.68 ypos 1.24 xanchor 0.5 yanchor 1.0 zoom 1.48
    window show dissolve
    translate None cyne_chapter3_0584:
        "一阵微风将我从深沉、至寂的梦境中唤醒。听不见她的声音，这种空虚感如此陌生。"
    translate None cyne_chapter3_0585:
        "更奇怪的是想到那个声音可能就在几门之隔。"
    translate None cyne_chapter3_0586:
        "柔和的光芒从微微敞开的窗户流淌进来，洒落在枕边人身上。"
    translate None cyne_chapter3_0587:
        "他金色的头发凌乱不堪，双眼依旧轻轻阖着。"
    translate None cyne_chapter3_0588:
        "那种空洞、孤独的感觉顿时烟消云散。"
    translate None cyne_chapter3_0589:
        "一个吻后，赛恩的眼皮微微颤动睁开了。"
    translate None cyne_chapter3_0590:
        play music "sounds/bgm/Discovery.ogg" fadein 2.0
        c wsad "已经早上了…？"
    translate None cyne_chapter3_0591:
        rs whap "你听起来像莱奥斯。"
    translate None cyne_chapter3_0592:
        c whap "拜托，他明明更像是…\"{i}吼吼，我有20块腹肌还会用鞭子抽你{/i}\"，对吧？"
    translate None cyne_chapter3_0593:
        rs "噗嗤！这根本不像他说的话！"
    translate None cyne_chapter3_0594:
        c "哦真的吗？让我们看看你能做得更好吗。"
    translate None cyne_chapter3_0595:
        rs "他更像是…\'{i}呃…我被一群小不点包围了。这种折磨什么时候结束？{/i}\' 你得加点讽刺的语气。"
    translate None cyne_chapter3_0596:
        rs wsad "……我很想念他们。"
    translate None cyne_chapter3_0597:
        c wsad "我也是…但别这么愁眉苦脸的！我们会救他们的，没问题。"
    translate None cyne_chapter3_0598:
        rs "是吗？"
    translate None cyne_chapter3_0599:
        c whap "我知道会的。如果我得砸开埃利奥特的门逼他帮忙，那也无所谓。"
    translate None cyne_chapter3_0600:
        rs wsmi "那咱们去找其他人吧。也许他们已经想出了计划。"
    translate None cyne_chapter3_0601:
        "寒气逼人，起床尤为困难，但我们俩还是设法收拾好了散落的衣物并穿上身。"
    translate None cyne_chapter3_0602:
        "我望向敞开的窗户。此刻天色已亮，村庄正慢慢苏醒。"
    translate None cyne_chapter3_0603:
        "他们看起来就是普通人。他们说话的方式，走路的姿态…"
    translate None cyne_chapter3_0604:
        "这样想着，我关上窗户，带着赛恩离开了房间。"

    window hide dissolve

    jump SV_morning

label cyne_sv_scenes:
    translate None cyne_chapter3_0605:
        "仅仅片刻之后，赛恩和我便独处一地。"
    translate None cyne_chapter3_0606:
        show cyne nw smi cloak at slightright
        show raen nw neu cloak at slightleft
        with dissolve
        c "嗯…有什么想法吗？如果你愿意的话，我倒是不介意来场雪地速战速决。"
    translate None cyne_chapter3_0607:
        show raen nw sur with dis
        rs "…虽然听起来很有趣，但我觉得有更合适的时机。"
    translate None cyne_chapter3_0608:
        c "也有更糟的时机啊，不过好吧。"
    translate None cyne_chapter3_0609:
        play sound "sounds/sfx/stomach.ogg" fadeout 2.0
        rs "我不确定会有人想和我们说话…我在想—"
    translate None cyne_chapter3_0610:
        show raen nw emb with dis
        "就在这时，仿佛接到信号般，我的肚子咕咕叫了起来。"
    translate None cyne_chapter3_0611:
        play sound "sounds/sfx/stomach.ogg" fadeout 2.0
        rs "啊…我在想—"
    translate None cyne_chapter3_0612:
        "又一次。"
    translate None cyne_chapter3_0613:
        show cyne nw hap with dis
        c "饿了吗？"
    translate None cyne_chapter3_0614:
        show raen nw neu with dis
        rs "…我在想我们可以先找到莫温，然后吃点东西。不过这附近可能没什么餐馆。" #RETAKE NEEDED
    translate None cyne_chapter3_0615:
        show cyne nw sur with dis
        c "要我说，像这样的村庄大概没什么餐馆吧，雷恩…"
    translate None cyne_chapter3_0616:
        "这座村庄相对小而安静—至少比起锡德卡汉来是这样。就连斯塔格威奇都比它大。"
    translate None cyne_chapter3_0617:
        "这只会让人更容易找到某人。"
    translate None cyne_chapter3_0618:
        "当我们一起行走时，我悄悄地把手覆在他的手上，没有说一句话。赛恩低头看着我们交握的双手，然后又抬眼看我。"
    translate None cyne_chapter3_0619:
        show cyne nw emb with dis
        c "唉…我一直发誓绝不会让自己陷入这种境地的。"
    translate None cyne_chapter3_0620:
        show raen nw sur with dis
        rs "什么样的状况？"
    translate None cyne_chapter3_0621:
        c "我曾如此绝望地想要抓住某人，以至于不惜在这个过程中毁掉自己。"
    translate None cyne_chapter3_0622:
        rs "我保证，不会毁掉任何东西！"
    translate None cyne_chapter3_0623:
        c "……也许你终究与众不同。啊，该死，我变得多愁善感起来了……"
    translate None cyne_chapter3_0624:
        hide cyne
        hide raen
        with dissolve
        "只稍作寻找，我们就找到了要找的人。她和西尔维尔并肩而坐，轻声交谈着。"
    translate None cyne_chapter3_0625:
        "西尔维尔的脸上时不时浮现笑容，随即又恢复成看似平静的表情。仿佛不愿让对方察觉她的情绪。"
    translate None cyne_chapter3_0626:
        "走近她们让我有些尴尬…但…我们俩都很饿了。"
    translate None cyne_chapter3_0627:

        mor c sad "昨晚我和埃利奥特谈过。希望我的话能让他有所顾虑。"
    translate None cyne_chapter3_0628:
        s thi "你知道他是真心拒绝他们的。别无选择。"
    translate None cyne_chapter3_0629:
        mor "...."
    translate None cyne_chapter3_0630:
        mor "我想作为曾经的人类，你和埃利奥特应该特别在意这件事。"
    translate None cyne_chapter3_0631:
        s neu "我不是这里的人，你知道的。"
    translate None cyne_chapter3_0632:
        mor "人就是人，不管他们来自哪里。"
    translate None cyne_chapter3_0633:
        rs wsad "嗯…我不是有意打扰—"
    translate None cyne_chapter3_0634:
        s "那就别打扰。"
    translate None cyne_chapter3_0635:
        show raen nw cloak sad at cenleft
        show morwen n cloak sad at cenright
        show cyne nw cloak neu at farleft
        show sylvir n neu at farright
        with dissolve
        mor "西尔维尔…"
    translate None cyne_chapter3_0636:
        show morwen n smi with dis
        mor "早上好雷恩，赛恩。睡得好吗？"
    translate None cyne_chapter3_0637:
        "她朝我眨眨眼，我发现自己不自觉移开了视线。"
    translate None cyne_chapter3_0638:
        show raen nw emb blush with dis
        rs "很—很好，谢谢！"
    translate None cyne_chapter3_0639:
        show morwen n hap with dis
        mor "很高兴听你这么说。有什么困扰吗？"
    translate None cyne_chapter3_0640:
        rs "其实…呃…我们有点饿，我想知道哪里能弄到吃的。"
    translate None cyne_chapter3_0641:
        s "像只讨食的小鸡崽。"
    translate None cyne_chapter3_0642:
        show raen nw sad with dis
        rs "喂！"
    translate None cyne_chapter3_0643:
        show morwen n neu with dis
        mor "嗯…我不确定我们能进哪里吃东西…不如我去收集些食材，我们一起做饭？"
    translate None cyne_chapter3_0644:
        show cyne nw sur with dis
        c "做饭？一起？"
    translate None cyne_chapter3_0645:
        show raen nw hap with dis
        rs "太完美了！"
    translate None cyne_chapter3_0646:
        s "玩过家家吗？好吧，晚点再来找你们。"
    translate None cyne_chapter3_0647:
        mor "别傻了。你也一起来吃。"
    translate None cyne_chapter3_0648:
        show sylvir n thi with dis
        s "...."
    translate None cyne_chapter3_0649:
        show cyne nw sad with dis
        c "我真的…真的不会做饭。"
    translate None cyne_chapter3_0650:
        rs "别担心，我来做给你吃！"
    translate None cyne_chapter3_0651:
        s "这次肯定会很顺利…"


    if iv_scene_three and illranveras_friend >= 5:
        $ iv_scene_four = True
        jump illranverasscene4

    else:
        jump cyneraencont


label cyneraencont:
    translate None cyne_chapter3_0652:
        "我们四人围坐在远离村庄的小火堆旁。西尔维尔消失得如此之快，我没想到她会回来，但她抱着一捆柴火添进了渐旺的火堆。"
    translate None cyne_chapter3_0653:
        "她比我想象的还要认真。或者，也许她只是喜欢莫温？我不确定。"
    translate None cyne_chapter3_0654:
        show morwen n hap with dis
        mor "看我带了什么好吃的！"
    translate None cyne_chapter3_0655:
        "洋葱、土豆、胡萝卜、芹菜…茄子…"
    translate None cyne_chapter3_0656:
        show raen nw sad with dis
        rs "别。"
    translate None cyne_chapter3_0657:
        show cyne nw sad with dis
        c "啊呀，但是雷恩…我之前不得不把最后一个留在马车里…"
    translate None cyne_chapter3_0658:
        show cyne nw sur with dis
        c "等等—嘿，我还什么都没说呢！"
    translate None cyne_chapter3_0659:
        rs "但我知道你会来的。"
    translate None cyne_chapter3_0660:
        s "……？有时间说闲话不如过来帮忙准备。"
    translate None cyne_chapter3_0661:
        c "我们要做什么？"
    translate None cyne_chapter3_0662:
        mor "我觉得热蔬菜汤能让大家都暖和起来。赛恩，雷恩，你们俩负责切菜。"
    translate None cyne_chapter3_0663:
        "她递给我们一块薄木板和每人一把刀。我看到赛恩接刀时微微颤抖了一下。"
    translate None cyne_chapter3_0664:
        "我麻利地处理着我的那堆蔬菜，在西尔维尔和莫温聊天时将它们切好。"
    translate None cyne_chapter3_0665:
        "当我看向赛恩时，他正盯着刀发呆，好像不知道该怎么握。"
    translate None cyne_chapter3_0666:
        show raen nw sur with dis
        rs "怎么了？"
    translate None cyne_chapter3_0667:
        show cyne nw sad with dis
        c "我…我从没切过东西。"
    translate None cyne_chapter3_0668:
        show raen nw smi with dis
        rs "很简单的。来，像这样拿刀。"
    translate None cyne_chapter3_0669:
        "他握住刀柄，将刀刃稳稳悬在胡萝卜上方。"
    translate None cyne_chapter3_0670:
        "当他用力下切时，胡萝卜飞了出去，栽进雪地里竖着，让所有人都看得清清楚楚。"
    translate None cyne_chapter3_0671:
        show raen nw sur with dis
        rs "....."
    translate None cyne_chapter3_0672:
        show cyne nw sur with dis
        c "........"
    translate None cyne_chapter3_0673:
        show raen nw hap with dis
        rs "哈哈哈，你在搞什么啊？！"
    translate None cyne_chapter3_0674:
        show cyne nw emb with dis
        c "闭嘴！我刚说过我从没干过这个！"
    translate None cyne_chapter3_0675:
        "我捡回逃跑的胡萝卜，然后双手覆住赛恩的手，慢慢教他我认为是常识的切菜方法。"
    translate None cyne_chapter3_0676:
        c "你怎么能切得这么好…"
    translate None cyne_chapter3_0677:
        rs "我刚能拿刀的时候就开始学做饭了。"
    translate None cyne_chapter3_0678:
        c "…果然比不过你啊？"
    translate None cyne_chapter3_0679:
        rs "拜托，至少给我留{i}一件{/i}擅长的事好吗。其他都让你赢。"
    translate None cyne_chapter3_0680:
        show cyne nw sur with dis
        c "嗯…挺公平，不过我倒想到你还有其他长处。"
    translate None cyne_chapter3_0681:
        show raen nw sur with dis
        rs "诶…诶？"
    translate None cyne_chapter3_0682:
        c "......"
    translate None cyne_chapter3_0683:
        show cyne nw smi with dis
        c "惹麻烦啊，笨蛋！你想到哪去了，变态？"
    translate None cyne_chapter3_0684:
        mor "看你们俩又和好如初，我真开心。"
    translate None cyne_chapter3_0685:
        show sylvir n thi with dis
        s "莫温，你别太惯着他们。"
    translate None cyne_chapter3_0686:
        mor "我不是惯着。难道我不能为\"儿子带人回家见我\"而感到欣慰吗？"
    translate None cyne_chapter3_0687:
        show morwen n hap with dis
        mor "啊…照这个说法，假设性来讲，你岂不是得当我妻子？"
    translate None cyne_chapter3_0688:
        show sylvir n shy blush with dis
        s "...."

    hide sylvir
    hide morwen
    hide raen
    hide cyne
    with dissolve
    translate None cyne_chapter3_0689:
        "这句话成功让她闭嘴了。"
    translate None cyne_chapter3_0690:
        "我们俩终于切完蔬菜，倒进莫温准备好的那锅加了香草的水里。"
    translate None cyne_chapter3_0691:
        "我搅拌着汤锅，其他人轻声交谈。"
    translate None cyne_chapter3_0692:
        "这种氛围…很安宁。"
    translate None cyne_chapter3_0693:
        "几乎就像家的感觉。"
    translate None cyne_chapter3_0694:
        "饭菜做好后，我们都围坐在火堆旁取暖饮酒。"
    translate None cyne_chapter3_0695:
        "这是一种质朴的风味—带着泥土气息却异常美味。在这雪地里，它从内而外地温暖着我们。"
    translate None cyne_chapter3_0696:
        "莫温坐下时显得格外小心翼翼。"
    translate None cyne_chapter3_0697:
        c c wsur "哇…这个太好吃了。"
    translate None cyne_chapter3_0698:
        rs c wsmi "要我喂你吗？"
    translate None cyne_chapter3_0699:
        c c whap "啊—"
    translate None cyne_chapter3_0700:
        "我把勺子送到他嘴边，他高兴地把食物吃得一干二净。"
    translate None cyne_chapter3_0701:
        s neu "开个房间去吧。"
    translate None cyne_chapter3_0702:
        mor c hap "哎呀，别吃醋啊西尔维尔。来，我也喂你一口。"
    translate None cyne_chapter3_0703:
        "她缓缓将勺子递到西尔维尔唇边，后者的目光在莫温的脸和勺子间来回游移，最终还是一口吃下。"
    translate None cyne_chapter3_0704:
        s shy "谁都不许说出去。"
    translate None cyne_chapter3_0705:
        c c whap "噗。赶紧去开个房间。"
    translate None cyne_chapter3_0706:
        stop music fadeout 3.0
        "我们又继续吃了会儿，谈笑着。这是难得的放松时刻，我比什么都珍惜这段时间。"



    if caspianaemylromance >= 2 and ca_scene_one == True:
        $ ca_scene_two = True
        jump caspianaemylscene2
    else:
        scene bg sv sunset with dis3:
            xpos 0.29 ypos 1.03 xanchor 0.5 yanchor 1.0 zoom 1.46
        play music "sounds/bgm/night.ogg" fadein 3.0
        jump raenaemylsv











    #
