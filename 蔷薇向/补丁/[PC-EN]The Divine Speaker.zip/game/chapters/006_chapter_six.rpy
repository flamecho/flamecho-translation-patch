label chapter_six_start:
    menu:

        "你可以选择":
            window show dissolve
            jump singing_choice1

        "不如你来唱一首关于我的歌？":
            $ fawn_relationship +=1
            window show dissolve
            jump singing_choice2

label singing_choice1:
    show raen n neu with dis
    translate None chapter_six_0001:
        rs "嗯…我不确定。你有什么想法吗？"
    translate None chapter_six_0002:
        f "那个…如果可以的话…我能唱关于你的歌吗？"
    show raen n sur with dis
    translate None chapter_six_0003:
        rs "我？"
    show fawn n sad with dis
    translate None chapter_six_0004:
        f "嗯…"
    show raen n smi with dis
    translate None chapter_six_0005:
        rs "当然可以！"
    translate None chapter_six_0006:
        f "希望我能把你唱好…"
    translate None chapter_six_0007:
        rs "别太紧张。我们试着玩得开心点！"
    jump choice_eight_done

label singing_choice2:
    show raen n sur with dis
    translate None chapter_six_0008:
        rs "哦，要不你来唱一首关于我的歌？"
    show fawn n shy with dis
    translate None chapter_six_0009:
        f "关于…关于你？"
    translate None chapter_six_0010:
        f "这有点…"
    translate None chapter_six_0011:
        "他低头看着自己的脚，小声嘀咕着。"
    translate None chapter_six_0012:
        "人群比他过去经历过的任何场面都要庞大，所以我不能怪他感到紧张。"
    translate None chapter_six_0013:
        "但如果这意味着今晚我们都能睡上真正的床…"
    show raen n smi with dis
    translate None chapter_six_0014:
        rs "没错！"
    translate None chapter_six_0015:
        rs "我们就当作玩玩吧。别这么紧张兮兮的！"

    jump choice_eight_done

label choice_eight_done:
    translate None chapter_six_0016:
        l "这太荒唐了…"
    show fawn n sad with dis
    translate None chapter_six_0017:
        f "好吧…我想也是…"
    translate None chapter_six_0018:
        rs "你不会一个人在台上的。我们都会站在你身边。"
    translate None chapter_six_0019:
        f "好吧…"
    translate None chapter_six_0020:
        f "但是…真的可以唱关于你的歌吗…？"
    translate None chapter_six_0021:
        rs "我不介意。"
    translate None chapter_six_0022:
        "我凑近他的耳朵，无视莱奥斯投来的怪异目光。"
    show raen n neu with dis
    translate None chapter_six_0023:
        rs "不过最好还是别提到…手臂的事。"
    translate None chapter_six_0024:
        f "好的…我只是不想让你不舒服-"
    translate None chapter_six_0025:
        l "你们两个聊完了吗？咱们速战速决吧。"
    translate None chapter_six_0026:
        br "祝你好运！"

    stop music fadeout 2.0

    scene bg tavern with dis2
    translate None chapter_six_0027:
        "人群没太注意我们在舞台上做准备。他们自顾自地聊天，喝酒说笑。"
    play sound "sounds/sfx/pluck.ogg" fadein 0.5 fadeout 1.0

    scene tavernband_leos with dis2
    translate None chapter_six_0028:
        "莱奥斯拨弄了几下琴弦，对调子感到满意。"
    translate None chapter_six_0029:
        "我想我只需要敲敲三角铁？真的挺简单的。"

    scene tavernband_raen with dis2
    play sound "sounds/sfx/triangle.ogg"
    translate None chapter_six_0031:
        "我敲了几下。"
    translate None chapter_six_0032:
        "嗯，这确实是个三角铁。"

    show tavernband_fawn with dis2
    translate None chapter_six_0033:
        "福恩一直盯着木地板看。他可能需要一点鼓励。"

    scene bg tavern with dissolve
    translate None chapter_six_0034:
        rs smi "准备好了吗？"
    translate None chapter_six_0035:
        l pen "随时可以。"
    translate None chapter_six_0036:
        f sad "....."
    translate None chapter_six_0037:
        rs neu "福恩？"
    translate None chapter_six_0038:
        f hur "嗯？！"
    translate None chapter_six_0039:
        f sad "哦..没事.."
    translate None chapter_six_0040:
        "他清了清嗓子，轻轻向我点了点头。"
    translate None chapter_six_0041:
        "酒保靠着吧台看我们表演，莱奥斯开始弹奏他的鲁特琴。"
    translate None chapter_six_0042:
        "嘿，他其实弹得还不错。"

    scene gallery_28 with dis2
    translate None chapter_six_0043:
        f "...."
    translate None chapter_six_0044:
        f "我……"
    translate None chapter_six_0045:
        "我朝他笑了笑，又低声对他说。"

    show gallery_28b with dis2
    translate None chapter_six_0046:
        rs "你能做到的！"
    translate None chapter_six_0047:
        f "…呼。"




    if persistent.voice_acting_off == False:
        play sound "sounds/sfx/inn 1.ogg" fadein 1.0
        window hide dissolve
        scene gallery_28b with dissolve:
            xpos -0.27 ypos -0.52 zoom 1.58
            linear 19.0 xpos -0.27 ypos -0.02 zoom 1.58
        $ renpy.pause(11.0, hard='确实')

        scene gallery_29 with dissolve
        show black2 with Dissolve(1)


        translate None chapter_six_0048:
            show text "{i}{font=gui/LibreBaskerville-Bold.ttf}{size=40}{cps=40}{color=#FFFFFF}我站在这些墙后…{w=6.0}{nw}{/color}{/cps}{/size}{/font}{/i}"
        $ renpy.pause(6.0, hard='确实')
        translate None chapter_six_0049:
            show text "{i}{font=gui/LibreBaskerville-Bold.ttf}{size=40}{cps=40}{color=#FFFFFF}静待他们堕落。{w=6.0}{nw}{/color}{/cps}{/size}{/font}{/i}"
        $ renpy.pause(6.0, hard='确实')
        translate None chapter_six_0050:
            show text "{i}{font=gui/LibreBaskerville-Bold.ttf}{size=40}{cps=40}{color=#FFFFFF}我将铺就一条路…{w=6.0}{nw}{/color}{/cps}{/size}{/font}{/i}"
        $ renpy.pause(6.0, hard='确实')
        translate None chapter_six_0051:
            show text "{i}{font=gui/LibreBaskerville-Bold.ttf}{size=40}{cps=40}{color=#FFFFFF}跨越灰暗。{w=4.0}{nw}{/color}{/cps}{/size}{/font}{/i}"
        $ renpy.pause(4.0, hard='确实')
        hide text

        hide black2 with dissolve
        #window show dissolve
        stop sound fadeout 1.0

        translate None chapter_six_0052:
            "什么…？哇…"

        window hide dissolve
        show black2 with dis3

        if persistent.voice_acting_off == False:
            play sound "sounds/sfx/inn 2.ogg" fadein 1.0
        translate None chapter_six_0053:
            show text "{i}{font=gui/LibreBaskerville-Bold.ttf}{size=40}{cps=40}{color=#FFFFFF}我要逃走了。{w=3.0}{nw}{/color}{/cps}{/size}{/font}{/i}"
        $ renpy.pause(3.0, hard='确实')
        translate None chapter_six_0054:
            show text "{i}{font=gui/LibreBaskerville-Bold.ttf}{size=40}{cps=40}{color=#FFFFFF}穿越迷雾的旅程…{w=6.0}{nw}{/color}{/cps}{/size}{/font}{/i}"
        $ renpy.pause(6.0, hard='确实')
        hide text
        hide black2 with dissolve
        window show dissolve
        translate None chapter_six_0055:
            "他…确实很出色…"

        scene bg tavern with dis2
        translate None chapter_six_0056:
            "他柔软忧郁的嗓音直达观众内心，俘获了他们。就在片刻前，他们还在为莱奥斯高声欢呼，现在却安静地注视着福恩。"
        translate None chapter_six_0057:
            "所有人都屏息聆听着，如痴如醉。"
        translate None chapter_six_0058:
            "莱奥斯用鲁特琴演奏着轻柔的曲调，完美配合着福恩的歌声。"
        window hide dissolve

        pause(0.2)
        show bg tavern blur onlayer middle:
            yanchor -0.23
            size (1920, 500) crop (100, 200, 1920, 500)
            easein 0.5 crop (200, 200, 1920, 500)
        show blacklines onlayer middle
        with dissolve

        show illran m con onlayer middle:
            yanchor -0.23 xanchor -0.18
            size (1920, 500) crop (0, 420, 1920, 500)
        show bveras m neu onlayer middle:
            xpos 0.5 ypos 1.0 xanchor 0.58 yanchor 1.29 zoom 0.83
        with dissolve

        play sound "sounds/sfx/birdchirp2.ogg"

        translate None chapter_six_0060:
            u "好了好了，别咬我耳朵了，我们可以进去了！"
        window hide dissolve

        scene bg tavern with dissolve


        window show dissolve
        translate None chapter_six_0061:
            "大门敞开，路人们被福恩天使般的嗓音吸引，纷纷加入人群。"
        window hide dissolve

        show gallery_29:
            xpos 0.5 ypos 1.0 xanchor 0.48 yanchor 0.59 zoom 2.5
            linear 20 yanchor 0.42
        show black2
        with Dissolve(1)

        if persistent.voice_acting_off == False:
            play sound "sounds/sfx/inn 3.ogg" fadein 1.0
        translate None chapter_six_0062:
            show text "{i}{font=gui/LibreBaskerville-Bold.ttf}{size=40}{cps=40}{color=#FFFFFF}我的命运，我听见它在召唤…{w=6.0}{nw}{/color}{/cps}{/size}{/font}{/i}"
        $ renpy.pause(6.0, hard='确实')
        translate None chapter_six_0063:
            show text "{i}{font=gui/LibreBaskerville-Bold.ttf}{size=40}{cps=40}{color=#FFFFFF}我将书写自己的故事…{w=6.0}{nw}{/color}{/cps}{/size}{/font}{/i}"
        $ renpy.pause(6.0, hard='确实')

        hide text
        hide black2 with Dissolve(1)


        window show dissolve
        translate None chapter_six_0064:
            u "你说得对，他确实很棒。"

        play sound "sounds/sfx/triangle.ogg" fadeout 1

        translate None chapter_six_0065:
            "哎呀，我想我也该拨弄几下三角铁了…"
        translate None chapter_six_0066:
            "反正也不会有谁注意到。有福恩的歌声和莱奥斯的鲁特琴演奏，其他什么都不需要了。"
        translate None chapter_six_0067:
            "福恩站在舞台中央，闭着眼睛唱着。"
        translate None chapter_six_0068:
            "他先前的所有紧张都烟消云散。"
        window hide dissolve

        scene gallery_29
        show black2
        with Dissolve(1)
        if persistent.voice_acting_off == False:
            play sound "sounds/sfx/inn 4.ogg" fadein 1.0
        translate None chapter_six_0069:
            show text "{i}{font=gui/LibreBaskerville-Bold.ttf}{size=40}{cps=40}{color=#FFFFFF}在那自由的银河中……{w=4.0}{nw}{/color}{/cps}{/size}{/font}{/i}"
        $ renpy.pause(4.0, hard='确实')

        translate None chapter_six_0070:
            show text "{i}{font=gui/LibreBaskerville-Bold.ttf}{size=40}{cps=40}{color=#FFFFFF}做我自己。{w=4.0}{nw}{/color}{/cps}{/size}{/font}{/i}"
        $ renpy.pause(4.0, hard='确实')
        hide black2 with Dissolve(1)
        hide text dissolve


    if persistent.voice_acting_off == True:
        play sound "sounds/bgm/op.ogg" fadein 1.0
        window hide dissolve
        scene gallery_28b with dissolve:
            xpos -0.27 ypos -0.52 zoom 1.58
            linear 19.0 xpos -0.27 ypos -0.02 zoom 1.58
        show black2 with Dissolve(1)


        n "{i}{font=gui/LibreBaskerville-Bold.ttf}{size=40}{cps=40}{color=#FFFFFF}我站在这些墙后…{w=6.0}{nw}{/color}{/cps}{/size}{/font}{/i}"
        n "{i}{font=gui/LibreBaskerville-Bold.ttf}{size=40}{cps=40}{color=#FFFFFF}静待他们堕落。{w=6.0}{nw}{/color}{/cps}{/size}{/font}{/i}"
        n "{i}{font=gui/LibreBaskerville-Bold.ttf}{size=40}{cps=40}{color=#FFFFFF}我将铺就一条路…{w=6.0}{nw}{/color}{/cps}{/size}{/font}{/i}"
        n "{i}{font=gui/LibreBaskerville-Bold.ttf}{size=40}{cps=40}{color=#FFFFFF}跨越灰暗。{w=4.0}{nw}{/color}{/cps}{/size}{/font}{/i}"

        hide black2 with dissolve

        "什么…？哇…"

        window hide dissolve
        show black2 with dis3

        n"{i}{font=gui/LibreBaskerville-Bold.ttf}{size=40}{cps=40}{color=#FFFFFF}我要逃走了。{w=3.0}{nw}{/color}{/cps}{/size}{/font}{/i}"
        n"{i}{font=gui/LibreBaskerville-Bold.ttf}{size=40}{cps=40}{color=#FFFFFF}穿越迷雾的旅程…{w=6.0}{nw}{/color}{/cps}{/size}{/font}{/i}"
        hide black2 with dissolve
        window show dissolve
        "他…确实很出色…"

        scene bg tavern with dis2
        "他柔软忧郁的嗓音直达观众内心，俘获了他们。就在片刻前，他们还在为莱奥斯高声欢呼，现在却安静地注视着福恩。"
        "所有人都屏息聆听着，如痴如醉。"
        "莱奥斯用鲁特琴演奏着轻柔的曲调，完美配合着福恩的歌声。"
        window hide dissolve

        pause(0.2)
        show bg tavern blur onlayer middle:
            yanchor -0.23
            size (1920, 500) crop (100, 200, 1920, 500)
            easein 0.5 crop (200, 200, 1920, 500)
        show blacklines onlayer middle
        with dissolve

        show illran m con onlayer middle:
            yanchor -0.23 xanchor -0.18
            size (1920, 500) crop (0, 420, 1920, 500)
        show bveras m neu onlayer middle:
            xpos 0.5 ypos 1.0 xanchor 0.58 yanchor 1.29 zoom 0.83
        with dissolve

        play sound "sounds/sfx/birdchirp2.ogg"

        u "好了好了，别咬我耳朵了，我们可以进去了！"
        window hide dissolve

        scene bg tavern with dissolve

        window show dissolve
        "大门敞开，路人们被福恩天使般的嗓音吸引，纷纷加入人群。"
        window hide dissolve

        show gallery_29:
            xpos 0.5 ypos 1.0 xanchor 0.48 yanchor 0.59 zoom 2.5
            linear 20 yanchor 0.42
        show black2
        with Dissolve(1)


        n "{i}{font=gui/LibreBaskerville-Bold.ttf}{size=40}{cps=40}{color=#FFFFFF}我的命运，我听见它在召唤…{w=6.0}{nw}{/color}{/cps}{/size}{/font}{/i}"
        n"{i}{font=gui/LibreBaskerville-Bold.ttf}{size=40}{cps=40}{color=#FFFFFF}我将书写自己的故事…{w=6.0}{nw}{/color}{/cps}{/size}{/font}{/i}"

        hide black2 with Dissolve(1)

        window show dissolve

        u "你说得对，他确实很棒。"

        play sound "sounds/sfx/triangle.ogg" fadeout 1

        "哎呀，我想我也该拨弄几下三角铁了…"
        "反正也不会有谁注意到。有福恩的歌声和莱奥斯的鲁特琴演奏，其他什么都不需要了。"
        "福恩站在舞台中央，闭着眼睛唱着。"
        "他先前的所有紧张都烟消云散。"
        window hide dissolve

        scene gallery_29
        show black2
        with Dissolve(1)
        n "{i}{font=gui/LibreBaskerville-Bold.ttf}{size=40}{cps=40}{color=#FFFFFF}在那自由的银河中……{w=4.0}{nw}{/color}{/cps}{/size}{/font}{/i}"
        n "{i}{font=gui/LibreBaskerville-Bold.ttf}{size=40}{cps=40}{color=#FFFFFF}做我自己。{w=4.0}{nw}{/color}{/cps}{/size}{/font}{/i}"

        hide black2 with Dissolve(1)
        hide text dissolve
    #####

    window show dissolve
    translate None chapter_six_0071:
        "然后……寂静。"
    translate None chapter_six_0072:
        "歌声停歇，越来越多的观众爆发出欢呼与掌声。"

    if achievement.has("group_band"):
        pass
    else:
        $ renpy.display_notify("成就解锁：我们何不组个乐队？")
    python:
        achievement.grant("group_band")
        achievement.sync()


    scene bg tavern with dissolve


    translate None chapter_six_0073:
        "莱奥斯很快离开了舞台。呃…更像是被姑娘们拽下去的。"
    translate None chapter_six_0074:
        "福恩仍静静地站着，闭目片刻后才看向我。"

    show raen n sur at slightright
    show fawn n neu at slightleft
    with dis

    translate None chapter_six_0075:
        rs "哇……那首歌是关于我的？"
    translate None chapter_six_0076:
        "我能感觉到心脏在胸腔里跳得越来越快…"
    translate None chapter_six_0077:
        "为什么……？"
    translate None chapter_six_0078:
        "演出的紧张感终于追上我了吗？是因为福恩那美妙的歌声吗？"
    show raen n smi with dis
    translate None chapter_six_0079:
        rs "那个…很美。你表现得很好。"
    show fawn n sur with dis
    translate None chapter_six_0080:
        f "啊！"
    translate None chapter_six_0081:
        f "…真的吗？"
    translate None chapter_six_0082:
        rs "真的。"
    translate None chapter_six_0083:
        rs "你是即兴创作的？"
    show fawn n shy with dis
    translate None chapter_six_0084:
        f "我..呃…是的…"
    translate None chapter_six_0085:
        "他移开视线，摆弄着自己淡色的头发。"
    translate None chapter_six_0086:
        "那发丝衬托着他小巧的脸庞…还有他温柔的嗓音…"
    translate None chapter_six_0087:
        "这让他看起来真像个天使。"
    scene bg tavern with dis2
    translate None chapter_six_0088:
        "当我们离开舞台去找莱奥斯时，我胸口依然砰砰直跳。"
    translate None chapter_six_0089:
        "演出期间，酒吧里挤进了更多人。现在每张桌子都坐满了，人们欢快地聊着天。"

    show nikos n sur with dis2
    play music "sounds/bgm/tavern.ogg" fadeout 2.0

    translate None chapter_six_0090:
        br "太棒了！我该长期雇佣你们！"
    translate None chapter_six_0091:
        br "看看你们带来的人气，我从没见过这么多人！"
    translate None chapter_six_0092:
        rs sur "谢谢…不过这都是他们两个的功劳。"
    show nikos n lau with dis
    translate None chapter_six_0093:
        br "如约所言，我这就去给你们准备好房间。"
    hide nikos with dissolve
    translate None chapter_six_0094:
        "他又快速从后门离开了，留下我和福恩、莱奥斯以及新聚集的人群。"
    translate None chapter_six_0095:
        "大多数人顾不上注意我们，所以我们在角落找了张小桌子，等着酒保回来。"
    translate None chapter_six_0096:
        rs smi "嘿，刚才真是开心！"
    translate None chapter_six_0097:
        l ann "如果对你来说尴尬到可笑就意味着好玩的话，那确实。"
    translate None chapter_six_0098:
        l "我怎么就沦落到和你们两个在这儿做这种事了？"
    translate None chapter_six_0099:
        l pen "我是得罪了谁才配得上这种命运？"
    translate None chapter_six_0100:
        "他把脸埋进手掌里，叹了口气。"
    translate None chapter_six_0101:
        rs "呃…总比独自困在森林里强吧？"
    translate None chapter_six_0102:
        l "我可不确定。"
    translate None chapter_six_0103:
        f shy "那个…我觉得还挺有趣的…"
    translate None chapter_six_0104:
        rs smi "看吧！有人很积极呢。"
    translate None chapter_six_0105:
        rs "而且今晚我们总算有地方睡了。"

    show illran n con
    show bveras n tal:
        xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 0.98
    with dis2

    translate None chapter_six_0106:
        u "哎呀呀，刚才表演得还不赖嘛。"
    translate None chapter_six_0107:
        u "当然看得出你们是新手，不过后面那个雷德散发的原始性感让演出很值得一看。"
    translate None chapter_six_0108:
        l neu "….现在要干嘛？"
    translate None chapter_six_0109:
        "当我们三人围坐桌边时，人群中走来一个身影。"



    show bg tavern blur:
        xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 0.45 zoom 1.25
    show illran m con
    show bveras m tal:
        xpos 0.5 ypos 1.0 xanchor 0.52 yanchor 1.03
    with dissolve

    translate None chapter_six_0110:
        "高挑的男子，墨绿色长发扎成马尾。肩头站着一只蓝色小鸟，正顽皮地东张西望。"
    translate None chapter_six_0111:
        u "听不得夸奖？"

    show illran m armsdown fli
    with dis

    translate None chapter_six_0112:
        "他咧嘴露出犬齿的笑容。"

    scene bg tavern
    show illran n fli at cenright
    show bveras n tal at cenright:
        xpos 0.7 ypos 1.0 xanchor 0.67 yanchor 0.98
    with dissolve
    show leos n smi at farright
    show raen n neu at cenleft
    show fawn n sur at farleft
    with dissolve

    translate None chapter_six_0113:
        l "抱歉，我一般不听满嘴胡话的人发言。你想干什么？"
    show bveras neu2 with dis2
    translate None chapter_six_0114:
        u "某人脾气不小啊。又高又忧郁？就算几个音准有问题，估计也挺受欢迎吧。不过至少尽力了。"
    translate None chapter_six_0115:
        l "你说什么？"

    show illran n con with dis
    play sound "sounds/sfx/drag chair.ogg" fadeout 2.0
    scene bg tavern with dis2

    translate None chapter_six_0116:
        "那人拽过椅子，刻意让椅腿在地上刮出刺耳声响。"
    translate None chapter_six_0117:
        "蓝色小鸟轻盈地跳上他手指，被安置在桌面。"

    scene gallery_30b with dissolve:
        xpos 0.5 ypos 1.0 xanchor 0.55 yanchor 0.88 zoom 2.0

    translate None chapter_six_0118:
        f "....."
    translate None chapter_six_0119:
        "福恩的眼睛瞬间亮了起来。"

    scene gallery_30b with dis2

    translate None chapter_six_0120:
        l "打住。没必要看见每个动物都馋得流口水。"
    show groupcg3_fawn_left with dis2
    translate None chapter_six_0121:
        f "流口水？！我又不想吃它！"
    translate None chapter_six_0122:
        l "不然你养那么多动物干嘛？"
    translate None chapter_six_0123:
        f "我觉得你—"
    show groupcg3_illran_ser with dis2
    translate None chapter_six_0124:
        u "抱歉，这小家伙不送人。"
    show groupcg3_fawn_stars with dis2
    translate None chapter_six_0126:
        "蓝色小鸟在福恩面前蹦跳，扑棱着翅膀啾啾鸣叫。"

    scene gallery_30 with dis2:
        xpos 0.5 ypos 1.0 xanchor 0.27 yanchor 0.53 zoom 2.0
        linear 0.5 xanchor 0.26

    translate None chapter_six_0127:
        l "这儿不是动物园，宠物请带到别处去。"

    show gallery_30 with dis2:
        xpos 0.5 ypos 1.0 xanchor 0.74 yanchor 0.5 zoom 2.0
        linear 0.5 xanchor 0.75

    translate None chapter_six_0128:
        u "他们不也放你进来了？我本以为他们会叫\"卷心菜田\"和\"万花筒\"那两位把你拴在外头呢。"

    scene gallery_30b with dis2

    translate None chapter_six_0129:
        rs "卷心菜田…？"
    show groupcg3_fawn_right with dis2
    translate None chapter_six_0130:
        f "万花筒…？"
    translate None chapter_six_0131:
        u "看来屋里不止我养了鸟。你这对鹦鹉训得真不错！"
    translate None chapter_six_0132:
        "莱奥斯的表情以秒为单位变得烦躁。当他俯视那个吊儿郎当的男人时，空气中几乎迸出火花。"
    translate None chapter_six_0133:
        rs "呃…听着，我们能帮上什么忙吗？"
    show groupcg3_illran_ser with dis2
    translate None chapter_six_0134:
        u "好了好了。我只是来祝贺你们演出精彩的。一个人要怎么做才能表达对演出的欣赏？"

    scene gallery_30
    show groupcg3_fawn_right
    with dis2

    translate None chapter_six_0135:
        rs "显然不该像你这样。"
    translate None chapter_six_0136:
        rs "没关系的莱奥斯，别管他了。"
    show groupcg3_illran_smi with dis2
    translate None chapter_six_0137:
        u "坐下，狗子。"
    translate None chapter_six_0138:
        rs "呃…"
    translate None chapter_six_0139:
        "莱奥斯的手指悄悄摸向匕首，把玩着刀柄。我迅速在桌下踢了他一脚。"
    show groupcg3_illran_smi with hpunch
    translate None chapter_six_0140:
        l "嗷！"
    show groupcg3_raen_right with dis2
    translate None chapter_six_0141:
        rs "说完了吗？谢谢夸奖，但我们长途跋涉很累了，而他—呃，他很容易被惹恼。"
    translate None chapter_six_0142:
        u "长途跋涉？这么有趣的队伍是从哪儿来的？"
    translate None chapter_six_0143:
        rs "莱奥斯和我从奥-"
    show groupcg3_leos_ann with dis2
    translate None chapter_six_0144:
        l "关你屁事。"

    show gallery_31 with dis2
    play sound "/sounds/sfx/birdchirp3.ogg"

    translate None chapter_six_0146:
        "小鸟在我面前蹦跳几下，突然飞起来落在我头顶。"
    translate None chapter_six_0147:
        rs "呃…"
    translate None chapter_six_0148:
        u "...."
    translate None chapter_six_0149:
        u "…不能说我去过关你屁事那地方。天气怎么样？"

    scene gallery_31 with dis2:
        xpos 0.5 ypos 1.0 xanchor 0.63 yanchor 0.5 zoom 2.0
        linear 0.5 xanchor 0.64

    translate None chapter_six_0150:
        "他还在开玩笑，但脸色突然严肃起来。"
    translate None chapter_six_0151:
        "他是在盯着我看吗？"

    window hide dissolve
    show gallery_31:
        xpos 0.5 ypos 1.0 xanchor 0.64 yanchor 0.5 zoom 2.0
        easein 2 xanchor 0.52
    pause(2)
    window show dissolve
    show gallery_31a with dis2:
        xpos 0.5 ypos 1.0 xanchor 0.52 yanchor 0.5 zoom 2.0

    translate None chapter_six_0152:
        "不…他在盯着我头顶那只鸟。"
    translate None chapter_six_0153:
        "在他钢铁般的注视下，我感觉身体僵住了。"
    translate None chapter_six_0154:
        u "说实话，我忍不住对你们这样奇特的组合感到好奇。斯塔格威奇游客很多，但像你们三位这样的可不多见。"
    translate None chapter_six_0155:
        rs "我们只是旅人。抱歉我们长得不像普通人。"
    translate None chapter_six_0156:
        u "嗯…"

    scene gallery_31a with dis3
    translate None chapter_six_0157:
        "他打量着我们三个，最后目光又落在我头顶的鸟上。"
    translate None chapter_six_0158:
        f "…你的鸟有名字吗？"

    show groupcg3_illran_smi with dis2
    $ about_Veras.locked = False
    translate None chapter_six_0159:
        u "他叫{a=set_entry:enc_people->about_Veras}{color=#DA70D6}维拉斯{/color}{/a}。"
    translate None chapter_six_0160:
        "福恩伸手想摸维拉斯，但还没碰到小鸟就飞走了。"

    hide groupcg3_illran_smi
    show gallery_31b
    with dis3

    translate None chapter_six_0161:
        "它重新落回绿发男子面前，有节奏地啄着桌面，最后跳上他的头顶。"
    translate None chapter_six_0162:
        rs "那你叫什么？"
    translate None chapter_six_0163:
        u "你觉得我叫什么？"
    translate None chapter_six_0164:
        l "我们怎么会知道？"
    translate None chapter_six_0165:
        rs "毫无头绪。"
    translate None chapter_six_0166:
        f "呃…."
    translate None chapter_six_0167:
        f "…你长得像狐狸，所以…"
    show groupcg3_illran_smi with dis2
    translate None chapter_six_0168:
        u "一次猜中。干得好，蓝毛。"

    window hide dissolve

    show bg tavern big with dissolve:
        xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 0.69 zoom 0.85
    window show dissolve
    show illran n armsdown fli at center
    show bveras n tal at center:
        xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 0.98
    with dis

    translate None chapter_six_0169:
        "他从椅子上起身准备离开。转头眨了下眼，又看了眼莱奥斯。"
    translate None chapter_six_0170:
        u "看来我该告辞了。回头见，莱奥斯。"
    show illran n neu with dis
    translate None chapter_six_0171:
        "他的目光在莱奥斯身上停留了片刻，脸上掠过一丝难以言喻的神情。"
    show illran con with dis
    translate None chapter_six_0172:
        u "哦，这个可以还给你了。你们的货币挺有趣，但对我们也用处不大。"
    translate None chapter_six_0173:
        "他将一个破旧的信封扔在桌上，里面的东西散落出来：几张纸币，还有一封手写信。"
    translate None chapter_six_0174:
        rs sur "喂！你怎么能-"
    translate None chapter_six_0175:
        u "晚安啦！"


    if achievement.has("illran_meet"):
        pass
    else:
        $ renpy.display_notify("成就解锁：狐狸与鸟")

    python:
        achievement.grant("illran_meet")
        achievement.sync()


    hide illran
    hide bveras
    with dissolve

    translate None chapter_six_0176:
        rs sad "...."
    translate None chapter_six_0177:
        rs "说到底…他究竟想要什么？"
    translate None chapter_six_0178:
        l neu "显然是为了惹人厌。虽然他表现得像个混蛋，但衣服里可不止藏了一件武器。"
    translate None chapter_six_0179:
        "等他走后，我们三个人都瘫在了椅子上。今天可真是一波未平一波又起。"

    $ about_Illran.locked = False

    translate None chapter_six_0180:
        rs "先是长途跋涉，然后打架斗殴，在酒吧表演，最后还被某个养着宠物鸟的<a=set_entry:enc_people->about_Illran><color=#DA70D6>绿毛怪胎</color></a>骚扰…"
    translate None chapter_six_0181:
        rs "我现在真想倒头就睡。"
    translate None chapter_six_0182:
        l "说起来之前…"
    translate None chapter_six_0183:
        l "喂，老鼠小子。"
    translate None chapter_six_0184:
        f sur "干、干嘛？"
    translate None chapter_six_0185:
        l "...."
    translate None chapter_six_0186:
        l smu "你那拳…打得还不赖。"
    translate None chapter_six_0187:
        f sur "哪一拳？"
    translate None chapter_six_0188:
        l "你确实把那家伙的鼻子打歪了…但姿势太差。"
    translate None chapter_six_0189:
        f neu "...."
    translate None chapter_six_0190:
        l pen "拳头要这样握。"
    translate None chapter_six_0191:
        "莱奥斯拉起福恩的手，帮他摆出拳击姿势。"
    translate None chapter_six_0192:
        "表面装得漠不关心，结果却做这种事…"
    translate None chapter_six_0193:
        rs smi "其实你人挺好的吧？"
    translate None chapter_six_0194:
        l sur "什么？！"
    translate None chapter_six_0195:
        "他猛地甩开福恩的手砸在桌上。"
    translate None chapter_six_0196:
        l emb "谁在乎你们这两个家伙！"
    translate None chapter_six_0197:
        rs "是~是~不过刚才多亏你保护我们呢。"
    translate None chapter_six_0198:
        l "不知道你在说什么。"
    translate None chapter_six_0199:
        "酒馆逐渐喧闹起来，充斥着叫嚷声、歌声和欢呼声。话说回来…"
    translate None chapter_six_0200:
        rs neu "对了！现在总算没人打扰，那些姑娘到底想干嘛？"
    translate None chapter_six_0201:
        l ann "天知道，谢天谢地她们终于不缠着我了。再多听一秒那种尖叫声我准要杀人。"
    translate None chapter_six_0202:
        rs sad "别这么干。"
    translate None chapter_six_0203:
        f neu "呃…"

    scene bg tavern
    show fawn n neu at left
    show raen n neu at center
    show leos n neu at right
    with dis

    translate None chapter_six_0204:
        f "之前尝试解释过，但现在说你应该会相信…"
    translate None chapter_six_0205:
        rs "说吧。"
    show leos n neu with dis
    translate None chapter_six_0206:
        f "所以…你说在奥雷利亚卡维拉，人们不能自主选择伴侣，都是被强制配对的？"
    translate None chapter_six_0207:
        f "其他地方的话…该怎么解释呢…"
    translate None chapter_six_0208:
        f "在其他地方，人们可以自行决定想跟谁在一起。"
    show raen n sur with dis
    translate None chapter_six_0209:
        rs "但是，他们怎么知道该选谁呢？你怎么可能会选？"
    translate None chapter_six_0210:
        f "爱。"
    translate None chapter_six_0211:
        f "多数情况下是这样的。"
    translate None chapter_six_0212:
        f "你会感到胸口有种奇妙的感觉，心跳加速，然后你就知道想和这个人共度一生。"
    translate None chapter_six_0213:
        f "然后你们可能会结婚生子。"
    translate None chapter_six_0214:
        rs "我还是不明白…怎么确定这种感觉就是爱？"
    translate None chapter_six_0215:
        f "我觉得当它来临时你自然就会知道。"
    translate None chapter_six_0216:
        f "有时令人兴奋，有时让人安心。不同的人对爱的感受也不同。"
    translate None chapter_six_0217:
        l "这解释不了那些女孩想要什么。"
    translate None chapter_six_0218:
        f "呃…我想，她们喜欢你？"
    translate None chapter_six_0219:
        l "喜欢我？"
    translate None chapter_six_0220:
        f "就是…想和你在一起？可能觉得你长得好看。"
    show fawn n shy with dis
    translate None chapter_six_0221:
        f "我是说你…个子高…五官端正…还有腹肌…"
    translate None chapter_six_0222:
        l "在外面这样就能让人喜欢你？"
    translate None chapter_six_0223:
        f "是啊…有些人可能想跳过爱情和婚姻，直接…"
    translate None chapter_six_0224:
        f "....."
    translate None chapter_six_0225:
        rs "直接？"
    translate None chapter_six_0226:
        f "更进一步…"
    show leos n sur with dis
    translate None chapter_six_0227:
        l "别在最有趣的地方停下。"
    translate None chapter_six_0228:
        f "你知道的…"
    translate None chapter_six_0229:
        f "做-"
    translate None chapter_six_0230:
        rs "做？"
    translate None chapter_six_0231:
        "我们都凑近想听清福恩微弱的声音。"
    show fawn n hur with dis
    translate None chapter_six_0232:
        f "做-"
    show nikos n lau at cenright behind raen with dis
    translate None chapter_six_0233:
        br "我回来了！"


    show leos n at shake
    show fawn n at shake
    show raen n at shake

    translate None chapter_six_0234:
        boys "啊！！！！"

    show raen n at cenleft
    show fawn n at farleft
    show leos n at farright
    with move
    show fawn n sur
    with dis

    translate None chapter_six_0235:
        br "哇，不是故意吓你们的。"
    show nikos n con with dis
    translate None chapter_six_0236:
        br "那个…可能有个小问题。"
    show leos n neu with dis
    translate None chapter_six_0237:
        l "又来了。这次是什么？"
    translate None chapter_six_0238:
        br "呃，因为你们招来了这么多客人…"
    show nikos n lau with dis
    translate None chapter_six_0239:
        br "现在只剩一间房了！"
    show leos n sur with dis
    translate None chapter_six_0240:
        l "....."
    show raen n wor with dis
    translate None chapter_six_0241:
        rs "就一间？"
    show fawn n hur with dis
    translate None chapter_six_0242:
        f "….有…有几张床？"
    show nikos n smi with dis
    translate None chapter_six_0243:
        br "很遗憾，只有一张。"
    translate None chapter_six_0244:
        br "不过…"
    translate None chapter_six_0245:
        "他把我们都打量了一遍，目光在福恩身上多停留了一会儿。"
    translate None chapter_six_0246:
        br "你们身材都很纤瘦，挤挤应该能睡下。"
    translate None chapter_six_0247:
        br "抱歉小伙子们，你们太受欢迎了。真该把你们长期留在店里！"
    show fawn n hur with dis
    translate None chapter_six_0248:
        f "…你确定…没有其他空房了？"
    translate None chapter_six_0249:
        "莱奥斯狐疑地盯着店主。"
    show leos n ann with dis
    translate None chapter_six_0250:
        l "你从一开始就计划好了，对吧？"
    translate None chapter_six_0251:
        rs "伙计们，冷静。"
    translate None chapter_six_0252:
        rs "既然他说能挤下，应该没问题，对吧？"
    translate None chapter_six_0253:
        "莱奥斯后退一步叹了口气。"
    show leos n neu with dis
    translate None chapter_six_0254:
        l "如果这意味着我能睡真正的床…那就这样吧。"
    translate None chapter_six_0255:
        f "这…我是说…"
    translate None chapter_six_0256:
        "福恩放弃争辩，也妥协了。"
    translate None chapter_six_0257:
        f "好吧…"
    translate None chapter_six_0258:
        br "来吧，我带你们上楼。"
    show raen n smi with dis
    translate None chapter_six_0259:
        rs "那太好了，谢谢。"


    scene bg tavern with dissolve:
        size (1920, 1080) crop (0, 0, 1481, 796)

    translate None chapter_six_0260:
        "我们跟着他走上狭窄的木楼梯，穿过幽长的走廊。"
    translate None chapter_six_0261:
        "这些门中必有一扇通向为我们准备的房间。"
    translate None chapter_six_0262:
        br smi "你会发现房间…很舒适。晚上应该能睡个好觉。"
    translate None chapter_six_0263:
        br lau "这间是你的。"
    translate None chapter_six_0264:
        "他指向走廊尽头的一扇门。"
    translate None chapter_six_0265:
        br smi "如果需要多住几天，明早下来找我聊聊。你带来的那群人可帮了我大忙。"
    translate None chapter_six_0266:
        br smi "所以，再次感谢。"
    translate None chapter_six_0267:
        rs neu "真的不用客气！该道谢的是我们。"
    translate None chapter_six_0268:
        br smi "有需要随时下来找我。"
    translate None chapter_six_0269:
        "男子转身下楼，回到酒吧方向。"
    translate None chapter_six_0270:
        rs neu "要进去看看吗？"
    translate None chapter_six_0271:
        "莱奥斯推开门，我们打量着今晚的住处。"

    jump game_cont


    ########################
    ####FOR BETA BUILD####
    ########################

label beta_end:


    stop music fadeout 2.0
    window hide dissolve
    scene black with dissolve
    pause(1.0)
    window show dissolve
    translate None chapter_six_0272:
        "这标志着《神圣演说者》扩展试玩版首个测试版本完成！"
    translate None chapter_six_0273:
        "完整扩展版即将推出，很快就能向大家介绍赛恩。希望您喜欢目前游戏内容！"

    translate None chapter_six_0275:
        "我们很快会再见面！"
    return
    ####FOR BETA BUILD####
    ########################

label game_cont:

    stop music fadeout 2.0
    window hide dissolve

    scene bg bedroom1 night with dissolve:
        size (1920, 1080)
    window show dissolve

    translate None chapter_six_0276:
        "房间确实很温馨。"
    play music "sounds/bgm/night.ogg" fadeout 2.0
    translate None chapter_six_0277:
        "空间不大，有张双人床和几把零散的椅子。"

    show raen n dim neu at center
    show fawn n dim neu at left
    show leos n dim neu at right
    with dis

    translate None chapter_six_0278:
        rs "虽然有点挤…但很干净，也很安全。"
    translate None chapter_six_0279:
        f "我想我们确实没什么可抱怨的。"

    scene bg bedroom1 night with dissolve:
        size (1920, 1080) ypos -0.12 xanchor 0.29 zoom 1.42

    translate None chapter_six_0280:
        "窗外的喧嚣渐息，灯笼陆续熄灭，人们都钻进被窝。"
    translate None chapter_six_0281:
        rs neu "真奇妙啊…"

    scene bg bedroom1 night with dissolve:
        size (1920, 1080)
    pause(0.5)
    show raen n dim neu at center
    show fawn n dim neu at left
    show leos n dim neu at right
    with dis

    translate None chapter_six_0282:
        l "什么？"
    translate None chapter_six_0283:
        rs "虽离家万里，许多事却毫无二致。"
    translate None chapter_six_0284:
        rs "远处猫头鹰啼声中渐暗的灯火。楼下欢快的谈笑。既熟悉又陌生。"
    translate None chapter_six_0285:
        "我闭目倾听海潮声。"
    show leos n dim smi with dis
    translate None chapter_six_0286:
        l "别想得太深，小心掉进思维黑洞。"
    show raen n dim smi with dis
    translate None chapter_six_0287:
        rs "哈。抱歉，我可能太累了。"
    translate None chapter_six_0288:
        rs "睡觉吧。"
    show fawn n dim shy with dis
    translate None chapter_six_0289:
        f "这个…怎么分配？"
    translate None chapter_six_0290:
        l "我睡左边。"
    play sound "sounds/sfx/beltbuckle.ogg" fadein 1
    translate None chapter_six_0291:
        "莱奥斯已解开行囊，在床侧整理衣物。"

    play sound "sounds/sfx/clotherustle2.ogg"
    translate None chapter_six_0293:
        "福恩局促地站在右侧，摆弄着衣角。"
    translate None chapter_six_0294:
        rs "怎么了？"
    translate None chapter_six_0295:
        f "呃…"
    translate None chapter_six_0296:
        f "不知道该穿什么睡觉…"
    show raen n dim neu with dis
    translate None chapter_six_0297:
        rs "穿着内衣就行吧？"
    translate None chapter_six_0298:
        f "啊…好吧…"
    translate None chapter_six_0299:
        rs "...."
    translate None chapter_six_0300:
        f "....."
    show fawn n dim hur with dis
    show fawn n dim at shake
    translate None chapter_six_0301:
        f "别盯着看！"
    show raen n wor with dis
    translate None chapter_six_0302:
        rs "对、对不起！"

    hide fawn n with dissolve
    show raen n at slightleft
    show leos n at slightright
    with move

    translate None chapter_six_0303:
        "我转向莱奥斯，他已脱得只剩底衣。"
    show raen n dim sur with dis
    translate None chapter_six_0304:
        rs "哇，你身材真不错。"
    translate None chapter_six_0305:
        "他得意地冲我咧嘴一笑。"
    translate None chapter_six_0306:
        l "不像某个家伙。想摸摸看吗？"
    translate None chapter_six_0307:
        rs "哇，真的可以吗？"
    translate None chapter_six_0308:
        "福恩猛地转过身，脸上满是惊恐的神情。"

    show raen n dim at slightright
    show leos n dim at right
    with move
    show fawn n dim hur at left with dis

    translate None chapter_six_0309:
        f "你们两个在干什么？！"
    translate None chapter_six_0310:
        "我的双手抵在莱奥斯的胸膛上，转头看向福恩。"
    translate None chapter_six_0311:
        rs "呃…莱奥斯说我可以摸摸他的肌肉…？"
    translate None chapter_six_0312:
        l "嫉妒吗？你也可以啊。也许某天你也能练出这样的身材。哈，我在开什么玩笑，你当然不可能。"
    translate None chapter_six_0314:
        f "不，我…"
    show fawn n dim sad with dis
    translate None chapter_six_0315:
        f "我们能睡觉了吗，求求你们了…"

    hide leos n with dissolve
    show raen n at slightright
    show fawn n at slightleft
    with move

    translate None chapter_six_0316:
        "莱奥斯面朝墙壁滑进被窝，宽阔的肩膀裸露在外。那肌肤白皙纯净，却布满了伤疤。"
    hide fawn n with dissolve
    show raen n at center with move
    translate None chapter_six_0317:
        "另一边，福恩正慢慢挪进被窝，整个人蜷缩在被子里。"
    show raen n naked with dis2
    translate None chapter_six_0318:
        "好吧，看来中间的位置是我的了！\"我飞快地脱得只剩内裤，把叠好的衣服放在地板上。"
    show raen n dim smi with dis
    translate None chapter_six_0319:
        rs "我来啦！"
    translate None chapter_six_0320:
        rs "哈哈，还挺有意思的！就像睡衣派对一样。你们有什么恐怖故事吗？"
    hide raen n with dissolve

    play sound "sounds/sfx/bedcreak1.ogg" fadeout 1
    scene bg bedroom1 night at fadeintop2 with dissolve:
        size (1920, 1080) xanchor 0.06 yanchor 0.37 zoom 1.71

    translate None chapter_six_0321:
        l pen "有意思？被挤成肉饼可不算我的乐趣。"
    translate None chapter_six_0322:
        rs smi "哈哈，好吧，不讲故事了。"
    translate None chapter_six_0323:
        rs "晚安。"
    translate None chapter_six_0324:
        fl "晚安。"
    window hide dissolve

    show black with eye_shut

    window show dissolve
    translate None chapter_six_0325:
        "我闭上眼睛。真是漫长的一天。"
    translate None chapter_six_0326:
        "辗转反侧许久，我还是睡不着。"
    translate None chapter_six_0327:
        "说不定这两个人里也有谁睡不着…"

    window hide dissolve

    menu:

        "向左翻身":
            $ leos_relationship +=1
            jump leos_left

        "向右翻身":
            $ fawn_relationship +=1
            jump fawn_right

label leos_left:
    play sound "sounds/sfx/clothrustle.ogg"
    scene gallery_32 with Dissolve(1)

    window show dissolve
    translate None chapter_six_0328:
        "我悄悄向左翻身，依稀能看见莱奥斯的肩膀在缓慢起伏。"
    translate None chapter_six_0329:
        "他纹丝不动。毕竟今天肯定累坏了。"
    translate None chapter_six_0330:
        "他那布满伤痕的白皙肌肤莫名吸引着我…就像禁忌之美。"

    show gallery_33 with dissolve

    translate None chapter_six_0331:
        "我的手指沿着他的脊椎游走，描摹着一道伤疤的轮廓。"
    translate None chapter_six_0332:
        l  "你在干什么？"
    translate None chapter_six_0333:
        "哇啊！"

    scene gallery_32 with dissolve
    translate None chapter_six_0334:
        "我猛地向后缩回，把手从他身上移开。"
    translate None chapter_six_0335:
        rs emb "啊…"
    translate None chapter_six_0336:
        "实在想不出什么好借口…"
    translate None chapter_six_0337:
        rs "我睡不着…对不起，我不打扰你了。"
    translate None chapter_six_0338:
        l "也许我该开始收费让人摸我了。光是今天那些女人就够我发财的。"
    translate None chapter_six_0339:
        rs "什么…？"
    translate None chapter_six_0340:
        l "......"
    translate None chapter_six_0341:
        rs "......"
    translate None chapter_six_0342:
        "我把手紧紧缩在胸前。最好还是别再碰到他了。"
    translate None chapter_six_0343:
        l "........."
    translate None chapter_six_0344:
        rs "......................."
    translate None chapter_six_0345:
        l "噢，操。"

    show gallery_34 with dissolve

    translate None chapter_six_0346:
        "他突然转身面对我。我们之间的距离比刚才近了许多。"
    translate None chapter_six_0347:
        l "有话直说。"
    translate None chapter_six_0348:
        rs sur "什么？"
    translate None chapter_six_0349:
        l "想说什么就说。我要睡觉了。"
    translate None chapter_six_0350:
        l "你总不会想让我错过美容觉吧？"
    translate None chapter_six_0351:
        rs "我不-"
    translate None chapter_six_0352:
        l "你想。"
    translate None chapter_six_0353:
        rs emb "那个…我想谢谢你之前的事。"
    translate None chapter_six_0354:
        rs "你某种程度上…算是救了我的命…"
    translate None chapter_six_0355:
        l "....."
    translate None chapter_six_0356:
        rs "之前我开玩笑提过这事，但我是认真的。谢谢你。"
    translate None chapter_six_0357:
        rs "要不是你在场，我们早就死了。"
    translate None chapter_six_0358:
        rs sur "哦还有…你用的那个武器也很厉害。"
    translate None chapter_six_0359:
        l "我的鞭子？"
    translate None chapter_six_0360:
        rs "对啊！你怎么用得这么好啊？"
    translate None chapter_six_0361:
        l "我被要求每天练习。"
    translate None chapter_six_0362:
        l "不仅是鞭子。匕首、长剑、弓箭。任何武器都要练。"
    translate None chapter_six_0363:
        rs "明白了…"
    translate None chapter_six_0364:
        rs "刚才那家伙完全没预料到呢？"
    translate None chapter_six_0365:
        l "….那种打斗方式并非我的首选。"
    translate None chapter_six_0366:
        rs "什么意思？"
    translate None chapter_six_0367:
        rs "你的工作不就是…跟人打架吗？"
    translate None chapter_six_0368:
        l "不是。"
    translate None chapter_six_0369:
        l "我的工作是杀人。"
    translate None chapter_six_0370:
        rs sad "呃…这不是一回事吗..？"
    translate None chapter_six_0371:
        l "在睡梦中悄无声息地杀死一个人，和挥拳互殴完全是两码事。"
    translate None chapter_six_0372:
        "啊。"
    translate None chapter_six_0373:
        rs "明白了…"
    translate None chapter_six_0374:
        "我注视着他的脸，看到悲伤、愤怒与担忧交织的表情。"
    translate None chapter_six_0375:
        "我和他相处这么久，都快忘了他杀人时不会犹豫这件事了。"
    translate None chapter_six_0376:
        "他和福恩与我生活在截然不同的世界。"
    translate None chapter_six_0377:
        "看他那张精致的脸…我根本猜不出他的职业。"
    translate None chapter_six_0378:
        rs "怎么了？"
    translate None chapter_six_0379:
        l "….完全没事。"
    translate None chapter_six_0380:
        l "只是在想这趟旅行至今有多愉快。哇，我真的很感激。"
    translate None chapter_six_0381:
        rs "真的只是这样？"
    translate None chapter_six_0382:
        "他的目光与我短暂相接，又迅速移开。"
    translate None chapter_six_0383:
        l "睡吧。"
    translate None chapter_six_0384:
        rs "…好吧。"


    scene gallery_34:
        xpos 0.64 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.75
        linear 0.5 ypos 1.02
    show black2
    with dissolve



    translate None chapter_six_0385:
        "我看着他闭眼入睡的侧脸。此刻的他看起来异常平静。那种柔和的神情竟显得有点可爱。"
    window hide dissolve
    stop music fadeout 3.0
    jump choice_nine_done

label fawn_right:
    scene bg bedroom1 night with dissolve:
        xanchor 0.15 yanchor 0.44 zoom 2.0

    window show dissolve
    translate None chapter_six_0386:
        "我向右翻身。福恩背对着我，面朝墙壁。"
    translate None chapter_six_0387:
        "可能他已经睡着了吧…."
    translate None chapter_six_0388:
        "身后传来轻微的鼾声。看来莱奥斯入睡毫无困难。"
    translate None chapter_six_0389:
        rs neu "嘿，福恩…"
    translate None chapter_six_0390:
        rs "你还醒着吗？"
    translate None chapter_six_0391:
        f neu "嗯…勉强。"
    translate None chapter_six_0392:
        f "睡不着？"
    translate None chapter_six_0393:
        rs neu "是啊…累得要命却睡不着。"
    translate None chapter_six_0394:
        rs smi "转过来这边。"
    translate None chapter_six_0395:
        f "呃…"
    translate None chapter_six_0396:
        f "好吧…"
    play sound "sounds/sfx/clothrustle.ogg"
    window hide dissolve

    scene gallery_35 with dissolve:
        xpos 0.26 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.56
        linear 20.0 xpos 0.56 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.56

    window show dissolve
    translate None chapter_six_0397:
        "黑暗中我只能辨认出他瘦小的轮廓。这不是我们第一次同睡，却是头一回靠得这么近。"
    translate None chapter_six_0398:
        "他的肌肤和莱奥斯一样白皙，却更显柔嫩。窗外流泻的月光让他面容恍若幽灵，近乎梦幻。"
    translate None chapter_six_0399:
        rs smi "你刚才表现太棒了。你的嗓音很美。"
    translate None chapter_six_0400:
        f "谢谢…当时真的很害怕，但最终却很享受。"

    scene gallery_35 with dissolve
    translate None chapter_six_0401:
        rs sur "而你的歌…简直太棒了。我无法相信你是即兴创作的。"

    show gallery_36 with dissolve

    translate None chapter_six_0402:
        f "呃…"
    translate None chapter_six_0403:
        f "其实…"

    hide gallery_36 with dissolve

    translate None chapter_six_0404:
        f "自从我们初次见面…我就一直在构思这首歌…"
    translate None chapter_six_0405:
        rs "真的吗？"
    translate None chapter_six_0406:
        f "嗯…"
    translate None chapter_six_0407:
        rs "...."
    translate None chapter_six_0408:
        f "...."

    translate None chapter_six_0409:
        rs "…你还好吗？脸看起来有点红。"
    translate None chapter_six_0410:
        rs smi "在你苍白的皮肤衬托下特别明显。很美。"
    translate None chapter_six_0411:
        f "哦…我们只是有点，呃…靠得太近了…"

    show gallery_36b with dissolve

    translate None chapter_six_0412:
        "在我意识到自己在做什么之前，已经伸手卷着他的一缕头发。"
    translate None chapter_six_0413:
        rs sur "你的头发真柔软…"
    translate None chapter_six_0414:
        f "....."
    translate None chapter_six_0415:
        rs "啊！"
    translate None chapter_six_0416:
        rs "对不起…"
    translate None chapter_six_0417:
        "我在干什么啊！？"

    hide gallery_36b with dissolve

    translate None chapter_six_0418:
        "我把手从他发间抽回，但他并没有移开视线。"
    translate None chapter_six_0419:
        f "你…"
    translate None chapter_six_0420:
        f "可以继续把手放在那里…"

    play sound "sounds/sfx/clothrustle.ogg"
    show gallery_36b with dissolve

    translate None chapter_six_0421:
        "我的手不自觉又回到他头上，摆弄着他几缕发丝。"
    translate None chapter_six_0422:
        "连我自己都不明白为何要这样做…"
    translate None chapter_six_0423:
        "但就是感觉…很自然？很舒服？"
    translate None chapter_six_0424:
        "他闭上双眼，不久后我便听到福恩熟睡时轻柔的呼吸声。"


    show gallery_36b:
        xpos 0.68 ypos 1.29 xanchor 0.5 yanchor 1.0 zoom 1.64
        linear 0.5 ypos 1.23
    show black2
    with dissolve

    translate None chapter_six_0425:
        "我也跟随他闭上眼睛，手依然停留在他发间。"

    stop music fadeout 3.0
    window hide dissolve
    jump choice_nine_done

label choice_nine_done:
    pause(1)
    scene black with eye_shut
    pause(2)

    translate None chapter_six_0426:
        n "…更近了…"
    translate None chapter_six_0427:
        n "…去往锡德卡汉..…"
    translate None chapter_six_0428:
        n "紧随…."

    pause(1)

    scene bg bedroom1 day with eye_open
    window show dissolve
    translate None chapter_six_0429:
        "我睁开惺忪睡眼，发现身处陌生房间。昨天发生了什么…？"
    translate None chapter_six_0430:
        "啊，对了…那场打斗，福恩的歌声…"
    translate None chapter_six_0431:
        "那个怪人…"
    translate None chapter_six_0432:
        "我揉着隐隐作痛的太阳穴。又是那个梦…"
    translate None chapter_six_0433:
        "不过现在已经不会觉得惊惶了。它们就那么存在着。"
    translate None chapter_six_0434:
        "我抓挠着手臂上蔓延的黑色神之刻印。也还在呢，是吧？"
    translate None chapter_six_0435:
        "至少我试图抓挠它们。有重物压着我的胳膊。"
    translate None chapter_six_0436:
        "还有我的腿…等等…"

    window hide dissolve

    show gallery_37 with dissolve:
        xpos 0.5 ypos 1.5 xanchor 0.5 yanchor 1.0 zoom 2.0
        easeout 0.3 zoom 1 ypos 1.0
    window show dissolve
    translate None chapter_six_0437:
        rs "......"
    translate None chapter_six_0438:
        rs "呃…你们俩谁醒着？"
    translate None chapter_six_0439:
        "我们怎么会变成这样…？"
    translate None chapter_six_0440:
        "莱奥斯和福恩四肢与我纠缠着横陈整张床铺。被子早不知去向。"
    translate None chapter_six_0441:
        "哈哈。想象下他们此刻醒来的反应。"
    translate None chapter_six_0442:
        rs "…喂—你们两个？"

    show gallery_37b with dis2

    translate None chapter_six_0443:
        "我必须保持镇定…这一点都不好笑…"
    translate None chapter_six_0444:
        rs "噗。"

    show gallery_37b with dis2:
        xpos 0.72 ypos 1.44 xanchor 0.5 yanchor 1.0 zoom 2.0
        linear 0.5 xpos 0.75

    translate None chapter_six_0445:
        l "太早了…"

    show gallery_37b with dis2:
        ypos 1.11 xpos 0.07 xanchor 0.5 yanchor 1.0 zoom 2.0
        linear 0.5 xpos 0.04

    translate None chapter_six_0446:
        f "离他远点…"


    window hide dissolve
    show gallery_37b with dissolve:
        xpos 0.38 ypos 1.05 xanchor 0.5 yanchor 1.0 zoom 1.5

    window show dissolve
    translate None chapter_six_0447:
        "他们肯定还在做梦…"
    translate None chapter_six_0448:
        rs "........"
    translate None chapter_six_0449:
        rs "哈哈哈哈。"
    translate None chapter_six_0450:
        l "呃…大清早的怎么这么吵…"
    translate None chapter_six_0451:
        f "哈啊~~~~"

    show gallery_38 with hpunch:
        xpos 0.38 ypos 1.05 xanchor 0.5 yanchor 1.0 zoom 1.5

    translate None chapter_six_0452:
        fl "嗯？！？"
    translate None chapter_six_0453:
        "好吧。这下可好。"

    scene gallery_38 with dissolve

    translate None chapter_six_0454:
        rs "早上好！"
    translate None chapter_six_0455:
        "我朝他们露出灿烂笑容。这才是我期待的反应。"
    translate None chapter_six_0456:
        rs "该起床啦两位！"
    translate None chapter_six_0457:
        f "什-怎么…为什么这是-"
    translate None chapter_six_0458:
        "他的话甚至都说不完整。天啊…"
    translate None chapter_six_0459:
        l "这…明显是个意外！对，就是个意外！"
    translate None chapter_six_0460:
        "噢。有些出乎我意料。莱奥斯的脸也变得通红。"
    translate None chapter_six_0461:
        rs "别不好意思。我不介意被你们俩夹在中间！"
    translate None chapter_six_0462:
        rs "你们让我感觉温暖又舒适。"

    window hide dissolve

    scene bg bedroom1 day with dissolve:
        ypos -0.32 zoom 1.5
    window show dissolve

    translate None chapter_six_0463:
        "这成了压垮骆驼的最后一根稻草。福恩跳起来，拼命寻找毯子想要遮住自己。"
    translate None chapter_six_0464:
        "莱奥斯也差不多，迅速抓起了自己的衣服。"

    play music "sounds/bgm/Discovery.ogg" fadeout 2.0
    translate None chapter_six_0465:
        rs neu "嗯…"
    translate None chapter_six_0466:
        "当他们俩手忙脚乱穿衣时，我坐下来想着今天要做的事。"
    translate None chapter_six_0467:
        rs "所以。今天我们要去找个治疗师给莱奥斯检查下，顺便看看这个镇子。你们觉得怎么样？"
    translate None chapter_six_0468:
        f shy "嗯嗯。"
    translate None chapter_six_0469:
        "他还是不肯看我。"
    translate None chapter_six_0470:
        l neu "何必呢？我觉得现在挺好的。"
    translate None chapter_six_0471:
        rs neu "你还有伤在身。就让医生看看吧，以防万一。"
    translate None chapter_six_0472:
        l cur "呃，随便吧，只要你能高兴。"
    window hide dissolve

    scene bg bedroom1 day with Dissolve(1)
    show raen n neu at center
    show leos n neu at right
    show fawn n shy at left
    with dissolve


    window show dissolve
    translate None chapter_six_0473:
        "既然我们都穿好衣服了，就下楼去找酒保。"
    window hide dissolve

    show black with wipeleft
    scene bg tavern with wipeleft

    show raen n neu at center
    show leos n neu at right
    show fawn n neu at left
    with dissolve


    window show dissolve
    translate None chapter_six_0474:
        "走下楼梯时，吧台后飘来的香味让我们精神一振。"
    translate None chapter_six_0475:
        rs "…我好饿…"
    show nikos n lau plates at cenleft behind raen with dissolve
    translate None chapter_six_0476:
        br "哦！小伙子们！"

    show fawn n sur at shake
    show raen n sur at shake
    with dis

    translate None chapter_six_0477:
        fr "啊！！！！"

    show leos n at farright
    show fawn n at farleft
    show raen n at cenright
    with move
    show leos n ann with dis

    translate None chapter_six_0478:
        l "闭嘴，你们俩太吵了。"
    translate None chapter_six_0479:
        "莱奥斯用手指按着太阳穴。"
    show nikos n sur with dis
    translate None chapter_six_0480:
        br "哎呀，不是故意吓你们的！"
    translate None chapter_six_0481:
        l "真的吗？你每次都这样。"
    translate None chapter_six_0482:
        "不知怎么，他从我们背后冒出来，抓住我和福恩的肩膀。"
    translate None chapter_six_0483:
        br "你们睡得好吗？"
    translate None chapter_six_0484:
        f "...."
    translate None chapter_six_0485:
        l "...."
    translate None chapter_six_0486:
        rs "...."
    translate None chapter_six_0487:
        rs "嗯，睡得不错。非常感谢让我们用那个房间。"
    show nikos n smi with dis
    translate None chapter_six_0488:
        br "其实吧，我对自己的行为有点过意不去-"
    translate None chapter_six_0489:
        l "就一点？我得贴着这两个家伙睡觉，你只是\"有点\"过意不去？"
    translate None chapter_six_0490:
        br "所~以~呢，我决定给你们做顿饭补偿！"
    show fawn n sad with dis
    translate None chapter_six_0491:
        f "我们…该不会又要表演才艺吧…？"
    translate None chapter_six_0492:
        br "当然不用！免费招待。坐下等着就行。"
    hide nikos with dis
    translate None chapter_six_0493:
        "他转身又钻进了厨房。"

    show fawn n at left
    show leos n at right
    show raen n at center
    with move

    translate None chapter_six_0494:
        rs "嗯，他人还挺好。"
    translate None chapter_six_0495:
        l "说不定正给我们下毒呢，谁知道。"
    translate None chapter_six_0496:
        f "那个…你不觉得…可能…你总是把别人往坏处想…？"
    show leos n smi with dis
    translate None chapter_six_0497:
        l "有谁问你意见了吗，费恩？"
    translate None chapter_six_0498:
        f "什…那不是我的-"
    show raen n sad with dis
    translate None chapter_six_0499:
        rs "友善点。眼下有的吃就不错了。"
    translate None chapter_six_0500:
        f "那不是我的…."
    translate None chapter_six_0501:
        rs "要想在这里生存下去，我们得想办法搞点钱。"
    translate None chapter_six_0502:
        f "……不是我的名字……"
    translate None chapter_six_0503:
        l "那你想怎么做？学森林里那群家伙吗？"
    translate None chapter_six_0504:
        f "唉……"
    translate None chapter_six_0505:
        rs "不！当然不是，我们和他们不一样。"
    translate None chapter_six_0506:
        l "你可真是个好到家的小天真，对吧？"
    show leos n neu with dis
    translate None chapter_six_0507:
        l "你该庆幸我没早点发现你，不然你连站在这儿的机会都没有。"
    translate None chapter_six_0508:
        "看来有人今天起床气不小啊。"
    translate None chapter_six_0509:
        rs "你非要找茬是不是？你—"

    show leos n at farright
    show fawn n at farleft
    show raen n at cenright
    with move
    show nikos n lau plates at cenleft with dis

    translate None chapter_six_0510:
        br "早餐好了！"
    show fawn n sur with dis
    translate None chapter_six_0511:
        f "哇…！"
    translate None chapter_six_0512:
        "他摆出了将近十几盘菜，堆满了我从未见过的肉类、蔬菜和水果。"
    show raen n sur with dis
    translate None chapter_six_0513:
        rs "太厉害了…这些都是你做的？"
    show nikos n smi plates with dis
    translate None chapter_six_0514:
        br "我周末兼职当厨师，这不算什么。再说你们三个也算帮了我的忙。"
    translate None chapter_six_0515:
        rs "我们一定会想办法报答你的，我保证。"
    translate None chapter_six_0516:
        br "没必要。好好享用这顿饭就是最好的回报。"
    show raen n smi with dis
    translate None chapter_six_0517:
        rs "那…至少坐下来和我们一起吃吧，这么多东西我们根本吃不完。"
    translate None chapter_six_0518:
        "他在餐桌边坐下，给我们分好餐盘。"
    show raen n neu with dis
    translate None chapter_six_0519:
        rs "对了，该怎么称呼你？"

    $ about_Nikos.locked = False
    translate None chapter_six_0520:
        nik "我叫{a=set_entry:enc_people->about_Nikos}{color=#DA70D6}尼科斯{/color}{/a}！负责经营这家店，打扫通常是我弟弟的工作。"
    translate None chapter_six_0521:
        l "真的吗…？"
    translate None chapter_six_0522:
        nik "昨晚你们来得挺匆忙。是刚来镇上吗？"
    show raen n sad with dis
    translate None chapter_six_0523:
        rs "对..我们这几天一直在赶路。占了你们的房间有点过意不去，真的很感谢。"
    translate None chapter_six_0524:
        nik "别见外。看到昨晚的客流没？平常一个月都没这么多顾客。"
    translate None chapter_six_0525:
        nik "有什么问题尽管问。我很乐意帮忙。"
    translate None chapter_six_0526:
        rs "嗯…"
    window hide

    menu:

        "旅馆为什么叫这个名字？":
            window show dissolve
            jump inn_name

        "这里工作怎么样？":
            window show dissolve
            jump inn_work

        "斯塔格威奇的生活如何？":
            window show dissolve
            jump inn_stagwich

label inn_name:
    show raen n sur with dis
    translate None chapter_six_0527:
        rs "不得不说…\"沉睡鸵鸟\"这名字挺怪的…鸵鸟是什么？"
    show nikos n lau with dis
    translate None chapter_six_0528:
        nik "哈哈哈，这有个有趣的故事。"
    translate None chapter_six_0529:
        nik "沉睡鸵鸟\"是我们家族产业。第一任店主—我的高祖父梦见过这种腿很粗的大鸟…而且还不会飞！"
    translate None chapter_six_0530:
        nik "它一直在尖叫\"鸵鸟！鸵鸟！\"。所以才有了沉睡鸵鸟酒馆这个名字。"
    show leos n smi with dis
    translate None chapter_six_0531:
        l "哇。真是个滑稽的故事。真的，我笑得停不下来。"
    show fawn n neu with dis
    translate None chapter_six_0532:
        f "我觉得有点好笑…"
    translate None chapter_six_0533:
        rs "这确实是个…有趣的名字。"

    jump choice_ten_done

label inn_work:
    translate None chapter_six_0534:
        nik "好吧，它能付账单。至少偶尔可以。"
    show raen n sur with dis
    translate None chapter_six_0535:
        rs "只是偶尔？"
    show nikos n lau with dis
    translate None chapter_six_0536:
        nik "不是每晚都像昨晚那么忙！"
    translate None chapter_six_0537:
        nik "真的，我已经很满足了。能遇见很多人，偶尔做做饭，没人的时候还能偷偷喝点酒。"
    show nikos n smi with dis
    translate None chapter_six_0538:
        nik "我妈妈一直希望我们经营这个地方。她爱这里胜过一切。"

    jump choice_ten_done


label inn_stagwich:
    translate None chapter_six_0539:
        rs "斯塔格威奇的生活如何？"
    translate None chapter_six_0540:
        nik "嗯。有很多过路客，甚至还有些外国人。我能遇见各种不同的人。"
    show raen n smi with dis
    translate None chapter_six_0541:
        rs "住在海边一定很棒。"
    show nikos n lau with dis
    translate None chapter_six_0542:
        nik "是的。没有什么比在海的气息中醒来更美妙了。"
    translate None chapter_six_0543:
        nik "美丽的风景和美味的食物是我们的招牌。我们这里有最好吃的鱼和水果。"
    jump choice_ten_done

label choice_ten_done:
    translate None chapter_six_0544:
        "我们都忙着把食物堆满盘子。每样都拿了一点，因为看起来都太好吃了。"
    show raen n sur with dis
    translate None chapter_six_0545:
        rs "哦，这是什么？"
    show fawn n sur with dis
    translate None chapter_six_0546:
        f "火龙果…我好多年没吃过了…"
    translate None chapter_six_0547:
        "福恩看起来像在天堂一样。我猜他一直独自生活，只吃些干果和坚果…"
    translate None chapter_six_0548:
        rs "哦哦，这个呢？！"
    show nikos n smi with dis
    translate None chapter_six_0549:
        nik "他们叫它萨洛。是我母亲家乡的一种早餐汤。"
    translate None chapter_six_0550:
        l "嗯，里面有什么？其实还不错。"
    translate None chapter_six_0551:
        nik "牛的头、胃和脚。"
    translate None chapter_six_0552:
        nik "很棒的是我能用上平时会扔掉的部分。"

    show leos n ann with dis
    show leos n at shake

    translate None chapter_six_0553:
        l "噗－－－－－－－－－－－－－。"
    translate None chapter_six_0554:
        l "你是认真的吗？我都把这肮脏东西放进嘴里了，你现在才告诉我？！"

    show raen n smi
    show fawn n hap
    with dis

    translate None chapter_six_0555:
        rs "哈哈哈。"
    translate None chapter_six_0556:
        f "…嘿嘿嘿。"

    translate None chapter_six_0557:
        l "你觉得这很好笑？它进过我嘴里！我的嘴里！"
    translate None chapter_six_0558:
        rs "我觉得太搞笑了！你应该尝试新事物！"
    translate None chapter_six_0559:
        "我舀了一勺萨洛送到嘴边，慢慢尝了尝。虽然原料很特别，但味道其实相当不错。"
    translate None chapter_six_0560:
        l "你真让我恶心。"
    translate None chapter_six_0561:
        f "我也要尝尝看…"
    translate None chapter_six_0562:
        f "嗯，太好吃了！"
    translate None chapter_six_0563:
        rs "哦！茄子！"
    translate None chapter_six_0564:
        f "你喜欢？"
    translate None chapter_six_0565:
        rs "这是我最爱的！我们在家乡的孤儿院里种过。"
    translate None chapter_six_0566:
        l "所以你现在是个茄子农夫？了不起。"
    translate None chapter_six_0567:
        rs "......."
    translate None chapter_six_0568:
        "莱奥斯打着哈欠，脸上挂着暴躁的表情。显然即使是佣兵也不擅长早起。"
    show raen n sur with dis
    translate None chapter_six_0569:
        rs "哦，我其实想问你件事。你们镇上哪里有治疗师吗？"
    translate None chapter_six_0570:
        nik "有的，在镇子东边。离这儿不远。"
    translate None chapter_six_0571:
        "他上下打量着我。"
    translate None chapter_six_0572:
        nik "你受伤了吗？"
    show raen n smi with dis
    translate None chapter_six_0573:
        rs "谢谢！我们就是想快速检查点东西，然后在镇上逛逛。"
    translate None chapter_six_0574:
        nik "要是观光的话，我们这有锡德卡汉境内数一数二的海滩。"
    translate None chapter_six_0575:
        f "听起来不错…"
    translate None chapter_six_0576:
        rs "那我们待会儿去看看。"
    translate None chapter_six_0577:
        "此刻餐盘已经擦得锃亮。我从没吃过这么美味的一餐。"
    translate None chapter_six_0578:
        rs "你们这儿的食物…比我家乡的好吃多了。"
    translate None chapter_six_0579:
        nik "哦？你从哪来？"
    show layer master at vpunch
    show raen n hur with dis
    translate None chapter_six_0580:
        rs "奥雷—哎哟！"
    show leos n neu with dis
    show raen n sad with dis
    translate None chapter_six_0581:
        l "我们来自北边的一座岛。"
    show nikos n sur with dis
    translate None chapter_six_0582:
        nik "真的？还没遇到过那边来的人呢。"
    show raen n hur with dis
    translate None chapter_six_0583:
        rs "你们为什么离—嗷！"
    translate None chapter_six_0584:
        "他又用手肘捅我。"
    show nikos n lau with dis
    translate None chapter_six_0585:
        nik "维迪斯还不错吧？"
    show raen n sur with dis
    translate None chapter_six_0586:
        rs "维迪斯？"
    show nikos n sur with dis
    translate None chapter_six_0587:
        nik "....?"
    translate None chapter_six_0588:
        nik "你连自己所在国家的名字都不知道？"
    translate None chapter_six_0589:
        rs "啊..哈哈…当然知道！是啊，这儿挺好的。"

    show nikos n smi with dis
    $ about_Nikos._text.append("他母亲五十年前从斯塔格威奇海岸外的黑岛来。希望他有天能去看看。")
    translate None chapter_six_0590:
        nik "我母亲五十年前从{a=set_entry:enc_people->about_Nikos}{color=#87CEEB}黑岛{/color}{/a}来到这儿。有朝一日，真想去看看她的故乡。"
    translate None chapter_six_0591:
        rs "希望你将来能如愿。"
    translate None chapter_six_0592:
        "莱奥斯在桌下扯了扯我的袖子。"
    translate None chapter_six_0593:
        l "那个，看起来我们不知不觉就把食物吃光了。该走了对吧？"
    show fawn n neu with dis
    translate None chapter_six_0594:
        f "对…"
    translate None chapter_six_0595:
        rs "你干嘛总—"
    translate None chapter_six_0596:
        "他揪着我耳朵把我拽起来。"
    show leos n smi with dis
    translate None chapter_six_0597:
        l "回见。"
    translate None chapter_six_0598:
        nik "要是你们仨今晚需要住处，记得回来啊！"
    stop music fadeout 2.0
    play sound "sounds/sfx/dooropen.ogg" fadeout 1.0
    window hide dissolve
    jump chapter_seven_start
