label chapter_five_start:
    scene bg forestevening with dissolve:
        size (1920, 1080) crop (0, 184, 1516, 895)

    show fawn n sad sunset at left
    show expression AlphaMask("foliage_1", At("fawn n sad", left)) as mask1
    show leos n neu sunset at right
    show expression AlphaMask("foliage_1", At("leos n neu", right)) as mask2
    show raen n sad sunset at center
    show expression AlphaMask("foliage_1", At("雷恩 悲伤", center)) as mask3
    with dissolve
    play music "sounds/sfx/forest amb.ogg" fadein 1.0

    translate None chapter_five_0001:
        rs "所以…"
    translate None chapter_five_0002:
        rs "他们在这里干什么？"
    translate None chapter_five_0003:
        f "看起来像是一伙盗贼—"
    translate None chapter_five_0004:
        l "还是不怎么高明的盗贼。"
    translate None chapter_five_0005:
        f "至于为何会出现在此…我也不清楚…"
    translate None chapter_five_0006:
        f "这是我第一次走到这么远…"
    translate None chapter_five_0007:
        l "你从未来过这里，却如此自信地带路？"
    show leos n ang with dis
    translate None chapter_five_0008:
        l "看吧，他在胡说八道。这一路上都在带我们绕圈子。"
    translate None chapter_five_0009:
        f "不！我确定这条路是对的！"
    translate None chapter_five_0010:
        f "我朋友们告诉我这么走的！"
    translate None chapter_five_0011:
        l "朋友们？"
    translate None chapter_five_0012:
        "太棒了。"
    translate None chapter_five_0013:
        "就在我以为莱奥斯需要新理由捉弄福恩的时候。"
    translate None chapter_five_0014:
        rs "等—"
    translate None chapter_five_0015:
        f "我朋友们…和我一起生活的动物们—"

    show leos n smi with dis
    translate None chapter_five_0016:
        l "曾经和你生活。"
    translate None chapter_five_0017:
        f "....."
    translate None chapter_five_0018:
        f "曾和我生活的动物们。它们帮过我。"
    translate None chapter_five_0019:
        l "哇哦，它们帮过你。"
    translate None chapter_five_0020:
        l "当然帮过。"
    translate None chapter_five_0021:
        l "它们也给你做饭洗衣？帮你穿衣洗澡？"
    translate None chapter_five_0022:
        f "什么…不，当然没有。"
    translate None chapter_five_0023:
        f "主要就是陪着我。我确保它们安全，它们也这样对我。"
    show leos n sur with dis
    translate None chapter_five_0024:
        l "....."
    translate None chapter_five_0025:
        f "有时候，它们会给我带路。"
    translate None chapter_five_0026:
        l "....."
    translate None chapter_five_0027:
        f "我们是一家人，互相照应。至少…曾经是…"
    translate None chapter_five_0028:
        f "真希望能介绍你们认识。只希望…它们都还好…"
    translate None chapter_five_0029:
        l "....."
    translate None chapter_five_0030:
        rs "....."

    show fawn n neu with dis
    translate None chapter_five_0031:
        f "什么？"
    translate None chapter_five_0032:
        l "......"
    show leos n hur with dis
    translate None chapter_five_0033:
        l "你他妈有什么毛病？"
    translate None chapter_five_0034:
        f "没…没什么？"
    translate None chapter_five_0035:
        l "你是说我们跟着你转悠，就因一群动物告诉你这么走？"
    translate None chapter_five_0036:
        l "疯了吗？你真觉得这听起来合理？"
    translate None chapter_five_0037:
        rs "....."
    window hide

    menu:

        "莱奥斯说得对…":
            $ leos_relationship +=1
            window show dissolve
            jump leos_right

        "别为难福恩":
            $ fawn_relationship +=1
            window show dissolve
            jump fawn_alone

label leos_right:

    translate None chapter_five_0038:
        "老实说…我不得不同意部分。莱奥斯说得有道理。"
    translate None chapter_five_0039:
        "就因为一群动物的指引走这么多天…听起来确实荒唐。"
    translate None chapter_five_0040:
        "但话说回来，我们也没太多选择。莱奥斯需要治疗，而且离奥雷利亚卡维拉越远越好。"
    translate None chapter_five_0041:
        "福恩在这里生活多年，活得好好的，总该相信他说的…对吧？"
    translate None chapter_five_0042:
        "…对吧？"

    show leos n neu with dis
    translate None chapter_five_0043:
        rs "莱奥斯…友善点。"
    show leos n ang with dis
    translate None chapter_five_0044:
        l "抱歉，你是没听见吗？"
    translate None chapter_five_0045:
        l "他‘会跟动物说话’。"
    show fawn n sad with dis
    translate None chapter_five_0046:
        f "......"
    translate None chapter_five_0047:
        rs "我知道…"
    translate None chapter_five_0048:
        rs "听着，我懂你的意思，但现在争论有何用？我们不能停在这里。"
    translate None chapter_five_0049:
        l "他疯了。他会让我们一直转圈直到耗尽体力，然后他就会…比如说…吃掉我们或什么的。"
    translate None chapter_five_0050:
        "我看向福恩。他低垂着眼帘，不敢与我们直视。"
    translate None chapter_five_0051:
        "他会对我们撒谎吗…？他是不是正带我们进行一场毫无目的地的疯狂旅程？在此之前，他一直都在帮我。"
    translate None chapter_five_0052:
        rs "都走到这一步了。现在回头毫无意义。"

    jump choice_six_done


label fawn_alone:

    translate None chapter_five_0053:
        rs "莱奥斯…友善点。"
    show leos n neu with dis
    translate None chapter_five_0054:
        l "你没听见他说的话吗？"
    translate None chapter_five_0055:
        l "他能和动物\"交谈\"。"

    show fawn n sad with dis
    translate None chapter_five_0056:
        f "....."
    translate None chapter_five_0057:
        rs "…我听见了。这事就此打住吧。"

    show leos n sur with dis
    translate None chapter_five_0058:
        l "打住？你想一辈子在原地打转吗？简直疯了！"
    translate None chapter_five_0059:
        rs "说真的，够了。"
    translate None chapter_five_0060:
        l "小不点肯定是故意的。把我们带到荒郊野外就为了吃掉我们。"

    show raen n ang
    show fawn n sur
    with dis

    translate None chapter_five_0061:
        rs "闭嘴！"
    translate None chapter_five_0062:
        rs "你能不能别烦他了？"
    translate None chapter_five_0063:
        rs "你只会不停地打击他，让他难受。"
    translate None chapter_five_0064:
        rs "他从没做过让我失去信任的事，你呢？"
    translate None chapter_five_0065:
        rs "你本来是被雇来杀我的，现在却指望我相信你说的每一句话，而不是那些真心帮我的人？"
    translate None chapter_five_0066:
        rs "都闭嘴继续走！"
    translate None chapter_five_0067:
        b "....."

    show raen n neu with dis
    translate None chapter_five_0068:
        rs "…咳咳。"
    translate None chapter_five_0069:
        rs "福恩…你刚才说我们快到了？"
    show fawn n neu with dis
    translate None chapter_five_0070:
        f "嗯…应该不远了…"
    show leos n neu with dis
    translate None chapter_five_0071:
        l "太好了。"
    translate None chapter_five_0072:
        l "看来你们两个都疯了。"
    translate None chapter_five_0073:
        l "我真高兴你们对这个处境一点都不担心。"

    show raen n sad with dis
    translate None chapter_five_0074:
        rs "我当然担心，但我们还能怎么办..？"
    show leos n ang with dis
    translate None chapter_five_0075:
        l "....."

    jump choice_six_done

label choice_six_done:
    show fawn n neu
    show raen n neu
    show leos n neu
    with dis
    translate None chapter_five_0076:
        f "呃…这里要小心。"
    translate None chapter_five_0077:
        "周围的绿色植被逐渐变成砾石和瓦砾。前方的树木越来越稀疏。"
    translate None chapter_five_0078:
        f "就是这里…"
    translate None chapter_five_0079:
        l "这里？"
    translate None chapter_five_0080:
        f "森林的边缘。"
    translate None chapter_five_0081:
        "我们悄悄靠近从树缝间透进来的光亮。"
    translate None chapter_five_0082:
        "每一步都让我感到心跳越来越沉重。"
    translate None chapter_five_0083:
        "这是什么地方…？"
    translate None chapter_five_0084:
        "我屏住呼吸，迈出了走出森林的最后一步。"

    stop music fadeout 2.0
    window hide dissolve

    scene bg scenic with dissolve:
        size (1920, 1080) crop (0, 290, 1330, 789)
        linear 35.0 crop (550, 290, 1330, 789)
    window show dissolve
    play music "sounds/bgm/op.ogg" fadein 3.0

    translate None chapter_five_0085:
        rs sur "....."

    $ about_Stagwich.locked = False
    translate None chapter_five_0086:
        f neu "看。那就是沿海城市{a=set_entry:enc_places->about_Stagwich}{color=#DA70D6}斯塔格威奇。{/color}{/a}"
    translate None chapter_five_0087:
        "我双膝跪地，碎石在身下嘎吱作响。"
    translate None chapter_five_0088:
        "越过树林线，夕阳给下方绵延的景色镀上一层灿烂的金黄。"

    $ about_AC._text.append("…至少，我原本是这样想的….")
    translate None chapter_five_0089:
        "巨大的石质建筑…无边无际的水面…一座城市…"
    translate None chapter_five_0090:
        "一座城市？！"
    translate None chapter_five_0091:
        rs wor "福恩你…你没有说谎…你终究不是疯子…"
    translate None chapter_five_0092:
        f sur "你真以为我是吗？!我绝不会骗你的!"
    translate None chapter_five_0093:
        l sur "......"
    translate None chapter_five_0094:
        "小镇环抱着海岸线，随着太阳一点点沉入水中，周围的灯笼渐次闪烁亮起。"
    translate None chapter_five_0095:
        rs wor "所有….我所知晓的一切，我们被教导的一切…都是谎言…？"
    translate None chapter_five_0096:
        "这景象令我眩晕。我必须抓紧地面才能感到安心。"


    scene bg scenic with dissolve
    show leos n sunset hur at right
    show fawn n sunset neu at center
    show raen n sunset wor at left
    with dis

    translate None chapter_five_0097:
        l "这….这不可能是真的.."
    translate None chapter_five_0098:
        l "言者说的话不会是谎言….他没理由欺骗我们…"
    translate None chapter_five_0099:
        "没错。说书人。他不会在这种事上说谎。"
    translate None chapter_five_0100:
        rs "也许他…并不知道？"
    translate None chapter_five_0101:
        "微风吹乱我的发丝，我将几绺头发别到耳后。这里很冷，比家乡更凉。"

    show fawn n sunset sad with dis
    translate None chapter_five_0102:
        f "嗯…"
    translate None chapter_five_0103:
        f "隐瞒外部世界…"
    translate None chapter_five_0104:
        f "…似乎是件困难的事。可能是无心之失，但是…"
    translate None chapter_five_0105:
        rs "那么…你说的那些话，关于你不是来自奥雷利亚卡维拉，关于周边城镇的事…也都是真的？"
    translate None chapter_five_0106:
        f "当然。我从未对你说谎。"
    translate None chapter_five_0107:
        f "我甚至没见过奥雷利亚卡维拉。几乎不知道它的存在。"
    translate None chapter_five_0108:
        "我爬到悬崖边缘。福恩和莱奥斯坐在我身旁。"

    show raen n sunset sur with dis
    translate None chapter_five_0109:
        rs "好多水。从没见过这么多!它会永远延伸下去吗？"

    show fawn n sunset neu with dis
    translate None chapter_five_0110:
        f "这是海洋。它会延伸到另一片陆地为止，对岸还有其他城市。"
    translate None chapter_five_0111:
        "粼粼波光在暮色中闪烁。美极了。"
    translate None chapter_five_0112:
        "美丽，却莫名让我感到….哀伤。"

    show raen n sunset sad
    with dis

    translate None chapter_five_0113:
        "我越凝视这片延绵至天际的奇幻景色，就越感到迷失。"
    translate None chapter_five_0114:
        "我这一生…"
    translate None chapter_five_0115:
        "我本永远不会知道…"
    translate None chapter_five_0116:
        rs "那些呢？那些巨石是什么？"
    translate None chapter_five_0117:
        f "山脉？"
    translate None chapter_five_0118:
        rs "是人建造的吗？好巨大!"
    show fawn n sunset hap with dis
    translate None chapter_five_0119:
        f "哈哈哈!"
    translate None chapter_five_0120:
        f "不，它们是自然形成的。就像海洋，森林，和我们周围的一切。"
    translate None chapter_five_0121:
        rs "原来如此…"
    translate None chapter_five_0122:
        "我的手臂隐隐发麻。能感受到神之刻印在嗡鸣，仿佛具有生命。"
    translate None chapter_five_0123:
        "我们坐了一会儿，沉浸在这景象中。"
    translate None chapter_five_0124:
        rs "或许…"

    show fawn n sunset neu with dis
    translate None chapter_five_0125:
        f "嗯？"
    translate None chapter_five_0126:
        rs "命运根本不存在吧…？"
    translate None chapter_five_0127:
        rs "我的人生…本该平静安稳…但我却在这里。"
    translate None chapter_five_0128:
        rs "我的审判与此截然不同。"
    translate None chapter_five_0129:
        l "说书人是….说书人永远正确…"
    show leos n pen with dis
    translate None chapter_five_0130:
        l "他说的每句话都会应验…"
    translate None chapter_five_0131:
        "他望着我们下方的土地，脸上带着忧虑的神情。连他自己都不太确信。"
    translate None chapter_five_0132:
        f "也许…."
    translate None chapter_five_0133:
        f "也许是因为你们全都对他言听计从。"
    translate None chapter_five_0134:
        f "我相信命运的存在，但更相信命运掌握在自己手中。你可以成为任何你想成为的人。"
    translate None chapter_five_0135:
        f "我不认识他，但不能因为他的一句话就放弃自己想要的生活。"
    translate None chapter_five_0136:
        rs "命运并非绝对..？"
    translate None chapter_five_0137:
        f "我是这么认为的。你的努力与付出才是决定命运能否实现的关键。"
    translate None chapter_five_0138:
        rs "我从未这样思考过。"

    show leos n sunset ang with dis
    translate None chapter_five_0139:
        l "你他妈在跟我开玩笑吧？这居然是真的？"
    translate None chapter_five_0140:
        rs "看起来确实如此。"
    translate None chapter_five_0141:
        l "家里就没人想到过来这里查看吗？"
    translate None chapter_five_0142:
        rs "大概没有.."
    translate None chapter_five_0143:
        "我无话可说。"
    translate None chapter_five_0144:
        "当发现毕生所学全是谬误时，还能说什么呢？"
    translate None chapter_five_0145:
        "我望向福恩。他说会带我们到森林边缘，然后我和莱奥斯可以去找救兵，但是…"
    translate None chapter_five_0146:
        rs "福恩-"
    translate None chapter_five_0147:
        f "如果…如果你不介意…我想跟你们一起走…"

    show raen n sunset sur with dis
    translate None chapter_five_0148:
        rs "真的吗？！"
    translate None chapter_five_0149:
        f "现在回去也不安全，而且…"

    show fawn n sunset shy with dis
    translate None chapter_five_0150:
        f "….会有点孤单。"
    translate None chapter_five_0151:
        "他的脸颊和耳尖又泛起了红晕。"

    show raen n sunset smi with dis
    translate None chapter_five_0152:
        rs "我求之不得！"
    translate None chapter_five_0153:
        "我对他笑了笑。难以想象没有他的帮助该如何继续前进。"
    translate None chapter_five_0154:
        f "我可能帮不上什么忙但..谢谢你们。"

    show leos n sunset smu with dis
    translate None chapter_five_0155:
        l "看来你也没我想的那么没用嘛。"
    translate None chapter_five_0156:
        "莱奥斯伸手揉了揉福恩的头发。"
    translate None chapter_five_0157:
        f "....."
    translate None chapter_five_0158:
        f "呃，谢谢…大概…"
    translate None chapter_five_0159:
        rs "哈哈哈。"
    translate None chapter_five_0160:
        "我眺望地平线，又看向坐在身旁的两人。"
    translate None chapter_five_0161:
        rs "你们…"
    translate None chapter_five_0162:
        rs "谢谢。如果没有你们俩，我可能早没命了。"
    translate None chapter_five_0163:
        l "那可不。至少我得教你怎么拿武器。"
    translate None chapter_five_0164:
        "不过话说回来，我也可能因为他俩中的某一个送命。算了。可能现在感性压倒了理性。"
    show fawn n sunset neu with dis
    translate None chapter_five_0165:
        f "那我们现在开始下山？天快黑了。"
    show raen n sunset neu with dis
    translate None chapter_five_0166:
        rs "好主意。"
    translate None chapter_five_0167:
        "我们全都爬起身，开始沿着岩石斜坡下行。"
    translate None chapter_five_0168:
        "但我一直留意着莱奥斯。尽管他表现如常，实际上伤势未愈…"
    translate None chapter_five_0169:
        rs "需要帮忙吗？"
    show leos n sunset smi with dis
    translate None chapter_five_0170:
        l "靠你这种菜鸟？免了。"
    show raen n sunset sad with dis
    translate None chapter_five_0171:
        rs "....."
    translate None chapter_five_0172:
        rs "几分钟前那个彬彬有礼的莱奥斯去哪儿了？"
    translate None chapter_five_0173:
        l "我不认识他，抱歉。"
    translate None chapter_five_0174:
        "当我们沿着斜坡向下朝着眼前的小镇前进时，夕阳正缓缓沉入广阔的海平面。"

    stop music fadeout 2.0
    window hide dissolve

    scene bg stagwich night with dissolve:
        size(1920, 1080)
    window show dissolve
    translate None chapter_five_0175:
        "屋外已是漆黑一片，但幸运的是城市的灯光为我们指引着方向。"
    translate None chapter_five_0176:
        "树木逐渐稀疏，取而代之的是小块稻田和麦田，最终我们来到了镇口。"
    translate None chapter_five_0177:
        "小镇热闹非凡。居民们来往穿梭，门窗开开关关，人们兴奋地交谈着，孩童在街道上追逐嬉戏。"


    show raen n dark sur at center
    show leos n dark sur at right
    show fawn n dark neu at left
    with dis

    if achievement.has("reach_stagwich"):
        pass
    else:
        $ renpy.display_notify("成就解锁：海边小镇")

    python:
        achievement.grant("reach_stagwich")
        achievement.sync()

    translate None chapter_five_0178:
        rs "简直不敢相信这是真实的，我们真的站在这里。"
    translate None chapter_five_0179:
        f "嗯。我确实试图告诉过你。"

    show raen n dark sad with dis
    translate None chapter_five_0180:
        rs "我知道…"
    translate None chapter_five_0181:
        rs "抱歉福恩…不该怀疑你。"
    translate None chapter_five_0182:
        rs "在我的认知里…这样的地方根本不可能存在。但如今我们确确实实站在这里。"
    translate None chapter_five_0183:
        rs "抱歉，在你眼里我肯定很蠢吧…"
    translate None chapter_five_0184:
        f "没关系，我理解。"
    translate None chapter_five_0185:
        f "当你们一直被灌输相反的观念时，又怎么能相信我的话呢？"
    translate None chapter_five_0186:
        l "虽然很痛苦，但不得不承认…连我都感到有些内疚。"

    show raen n dark smi with dis
    play music "sounds/bgm/night.ogg" fadein 2.0
    translate None chapter_five_0187:
        rs "…让我们往好处想。"
    translate None chapter_five_0188:
        rs "从现在开始，我们有那么多新鲜事物可以学习和体验。这听起来不是很有趣吗？"
    show raen n dark sad with dis
    translate None chapter_five_0189:
        rs "我只是希望…能让家乡的人也看看这一切…"
    translate None chapter_five_0190:
        f "谁知道呢…也许有一天你就能回去告诉他们。"
    translate None chapter_five_0191:
        "我发自内心地希望，总有一天能把眼前景象展现给他们看。给女院长，给米娅和托比亚斯….给所有人。"
    translate None chapter_five_0192:
        "这或许是个不切实际的愿望，但我仍会为此祈祷。"
    translate None chapter_five_0193:
        "终有一天，我能带他们亲眼见证。"
    show fawn n dark hap with dis
    translate None chapter_five_0194:
        f "一定会有那一天的。"

    show fawn n dark neu
    show leos n dark neu
    with dis

    translate None chapter_five_0195:
        l "好了，我们别再浪费时间了。"
    translate None chapter_five_0196:
        l "我不知道你们怎么想，反正我再也受不了睡地上了。"
    show leos n dark smu with dis
    translate None chapter_five_0197:
        l "有张床就好了。"
    translate None chapter_five_0198:
        "即使在福恩的小鹿之家，那张床也只是草草拼凑的。今晚要是能睡张正经床该多好…"
    show raen n dark smi with dis
    translate None chapter_five_0199:
        rs "我举双手赞成！"
    translate None chapter_five_0200:
        f "那我们就…沿着主街走？"
    show raen n dark sad with dis
    translate None chapter_five_0201:
        rs "需要躲躲藏藏吗？会被盘问吗？"
    translate None chapter_five_0202:
        f "我…我觉得不用。我们应该能自由进出。"
    translate None chapter_five_0203:
        rs "真的吗？哇…"
    show leos n dark neu with dis
    translate None chapter_five_0204:
        "我们慢慢穿过城镇外围。正如福恩所说，这里没有人把守。"
    translate None chapter_five_0205:
        "他们真的可以随心所欲地来去自由。"
    translate None chapter_five_0206:
        "他们可以眺望大海并决定去看看。他们可以遥望远方然后说走就走。我真羡慕他们。"
    translate None chapter_five_0207:
        "当我们穿行在建筑物之间时，我的手臂阵阵作痛。那种隐隐的抽痛从手腕一直蔓延到肩膀。"
    translate None chapter_five_0208:
        "我用另一只手揉按着，但无济于事。"
    translate None chapter_five_0209:
        f "你的手臂不舒服吗？"
    translate None chapter_five_0210:
        "在排排房屋间穿行时，他们俩一直紧紧盯着我。"
    translate None chapter_five_0211:
        rs "哦，没事…是有点疼，但很快就会好的。没什么大不了的。"
    show leos n dark neu with dis
    translate None chapter_five_0212:
        l "....."
    translate None chapter_five_0213:
        f "好吧…如果实在受不了要告诉我们，好吗？"
    translate None chapter_five_0214:
        rs "嗯…"
    translate None chapter_five_0215:
        l "喂，看那边…"
    translate None chapter_five_0216:
        "不远处，我们见到了第一个镇民。我本能地绷紧身体想躲起来。她会怎么做？"
    translate None chapter_five_0217:
        "她总不会因为一群衣冠不整的陌生人大半夜闲逛就叫卫兵吧？"
    translate None chapter_five_0218:
        "我们全都紧张地注视着她。"
    translate None chapter_five_0219:
        "她经过时对我们温柔地笑了笑，然后继续走自己的路。仅此而已。"
    translate None chapter_five_0220:
        fl "....."
    show raen n dark sur with dis
    translate None chapter_five_0221:
        rs "她看起来…还挺友好的…"
    translate None chapter_five_0222:
        f "确实…我听说这里的人很友善，但是…"
    show fawn n dark sad with dis
    translate None chapter_five_0223:
        rs "但是什么？"
    translate None chapter_five_0224:
        l "该不会又是你那群\"小朋友\"说的？"
    translate None chapter_five_0225:
        f "不，是—"
    translate None chapter_five_0226:
        f "我是说…对。他们告诉我的。"
    translate None chapter_five_0227:
        f "就算人们表现得很友善…也不代表真的友好…"
    translate None chapter_five_0228:
        f "不过看起来今晚在这里过夜应该安全。"
    show leos n dark pen with dis
    translate None chapter_five_0229:
        l "好吧。你那群朋友有没有顺便提到能落脚的地方，小老鼠？"
    translate None chapter_five_0230:
        f "噢，没有…他们没说…"
    translate None chapter_five_0231:
        f "对不起…"
    show raen n dark smi with dis
    translate None chapter_five_0232:
        rs "没关系。不能指望你什么都懂。我们可以一起找找看。对吧，莱奥斯？"
    translate None chapter_five_0233:
        "我瞪了他一眼。希望他能读懂我眼里\"闭嘴\"的意思。"
    show leos n dark smi with dis
    translate None chapter_five_0234:
        l "…随你便。"
    translate None chapter_five_0235:
        rs "好，那就这么定了。"
    translate None chapter_five_0236:
        rs "任务一，找住处。"
    translate None chapter_five_0237:
        rs "任务二，找人给你疗伤。"
    translate None chapter_five_0238:
        rs "明白吗？"
    translate None chapter_five_0239:
        l "遵命，长官。"
    translate None chapter_five_0240:
        rs "要是你一直这么听话就好了。我喜欢这样的莱奥斯。"
    translate None chapter_five_0241:
        "我们更有信心地继续穿行在小镇里。"
    translate None chapter_five_0242:
        "人们行色匆匆，忙于自己的生活。根本没人注意我们。"
    show raen n dark sur with dis
    translate None chapter_five_0243:
        rs "这些建筑看起来好奇怪！"
    show leos n neu dark with dis
    translate None chapter_five_0244:
        l "我也正想这么说。"
    show fawn n dark neu with dis
    translate None chapter_five_0245:
        f "什么意思？"
    translate None chapter_five_0246:
        rs "老家的房子完全不是这样的！太神奇了！"
    translate None chapter_five_0247:
        f "真的吗？"
    translate None chapter_five_0248:
        "我环顾四周。是的，这里和家乡不一样。完全不一样。就连空气都不同。"
    translate None chapter_five_0249:
        "我们继续走着，慢慢经过对我们毫无注意的路人。没人向我们打招呼，也没人问我们为何来此。"
    translate None chapter_five_0250:
        rs "他们甚至没注意到我们…"
    show fawn n dark sad with dis
    translate None chapter_five_0251:
        "他们看起来和家乡的人如此相似，却又如此不同。不同的发型，不同的衣着…脸庞似曾相识，却又微妙地陌生。"
    translate None chapter_five_0252:
        "太奇怪了。"
    show raen n dark sad with dis
    translate None chapter_five_0253:
        "我瞥了眼福恩。他稍微落后于我，目光垂向地面。"
    translate None chapter_five_0254:
        rs "福恩..？"
    show fawn n dark sur at shake
    translate None chapter_five_0255:
        f "嗯？！"
    translate None chapter_five_0256:
        "他的视线立刻从地面弹起。"
    translate None chapter_five_0257:
        rs "你还好吗？"
    show fawn n dark sad with dis
    translate None chapter_five_0258:
        f "哦..没事.."
    translate None chapter_five_0259:
        f "只是有点累。"
    translate None chapter_five_0260:
        l "我们难得达成共识。"
    translate None chapter_five_0261:
        rs "好吧…"
    translate None chapter_five_0262:
        rs "虽然我说得轻巧，但我们究竟该在哪落脚？"
    translate None chapter_five_0263:
        l "嗯。在这等着。"

    hide leos n dark with dissolve
    show fawn n dark at slightleft
    show raen n dark at slightright
    with move

    translate None chapter_five_0264:
        "还没来得及反对或追问，莱奥斯就不见了踪影。他在建筑物间穿梭，转眼消失。"

    window hide

    menu:

        "我该和福恩在这等着":
            $ fawn_relationship +=1
            window show dissolve
            jump fawn_stay

        "或许我该追上去？":
            $ leos_relationship +=1
            window show dissolve
            jump leos_go

label fawn_stay:
    show raen n dark sad with dis
    translate None chapter_five_0265:
        rs "唉，有时候真拦不住他…"
    translate None chapter_five_0266:
        "这片区域相对安静，偶尔只有零星路人经过，于是我蹲下身，背靠着后面的墙壁。"
    translate None chapter_five_0267:
        rs "真是漫长的一天…"
    translate None chapter_five_0268:
        "福恩尴尬地站着，仍然盯着地面。"
    translate None chapter_five_0269:
        rs "嘿，过来和我一起坐着吧？"
    translate None chapter_five_0270:
        f "哦…好的…"
    translate None chapter_five_0271:
        "他在离我几步远的人行道上坐下，双手抱头。"
    translate None chapter_five_0272:
        "嗯。"
    translate None chapter_five_0273:
        "我不喜欢这里…"

    window hide dissolve

    scene gallery_24b with dissolve
    window show dissolve
    translate None chapter_five_0274:
        "我挪过去撞了撞他，手臂搭上他的肩膀。"
    translate None chapter_five_0275:
        rs "嘿，别这么疏远。"
    translate None chapter_five_0276:
        "当他与我四目相对时，我终于注意到他泛红的眼眶。"
    translate None chapter_five_0276b:
        f "........."
    translate None chapter_five_0277:
        rs "怎…怎么了？！"
    translate None chapter_five_0278:
        "我说错什么了吗？！自从到这儿他就一直怪怪的…"
    translate None chapter_five_0279:
        rs "对不起，我做什么了？"
    translate None chapter_five_0280:
        f "不，我…呃.."
    translate None chapter_five_0281:
        f "我只是…"
    translate None chapter_five_0282:
        f "我很害怕…"
    translate None chapter_five_0283:
        f "我….我不知道该怎么办…"
    translate None chapter_five_0284:
        rs "该怎么办？"
    translate None chapter_five_0285:
        f "突然周围这么多人…我已经…已经十年没踏入过这种地方了…"
    translate None chapter_five_0286:
        f "感觉自己很没用…也很害怕。至少在外面我还能帮上忙，但现在…"
    translate None chapter_five_0287:
        "原来，他一直记得自己独居了多久啊…"
    translate None chapter_five_0288:
        rs "你并非无用之人。若非有你，我们绝不可能寻得此地。"
    translate None chapter_five_0289:
        f "但那是在外面…在这里，我一无所知。"
    translate None chapter_five_0290:
        f "每次与人对视，我都想逃得越远越好。我想躲起来永远不再出现。"
    translate None chapter_five_0291:
        f "我不…我不想让他们伤害我…我不是有意-"
    translate None chapter_five_0292:
        rs "他们不会伤害你。"
    translate None chapter_five_0293:
        f "若是他们真动手呢？"
    translate None chapter_five_0294:
        rs "你该明白，我绝不会允许。"
    translate None chapter_five_0295:
        rs "当我需要帮助时，是你伸出了援手。你不止一次保护过我，现在换我来帮你。"
    translate None chapter_five_0296:
        rs "….虽然我对这类事懂的也不比你多多少。"
    translate None chapter_five_0297:
        "他只是沉默地盯着地面。"
    translate None chapter_five_0298:
        rs "为何如此忧虑..？"
    translate None chapter_five_0299:
        rs "这些人曾对你不利吗？"
    translate None chapter_five_0300:
        f "不…"
    translate None chapter_five_0301:
        f "但上次我…"
    translate None chapter_five_0302:
        f "....."
    translate None chapter_five_0303:
        f "只是..不愿回想…"
    translate None chapter_five_0304:
        "他不想谈及此事。我不该追问。"
    translate None chapter_five_0305:
        rs "好吧，信我。我不会让他们动你分毫。"
    translate None chapter_five_0306:
        "我收紧环住他肩膀的手臂，将他拉近了些。"
    translate None chapter_five_0307:
        "当他望向我时，我回以微笑。这是我仅能做到的。唯有如此方能让他知晓我在此相伴。"
    translate None chapter_five_0308:
        f "嗯。好吧。"


    show gallery_25 with dissolve
    translate None chapter_five_0309:
        "他用长袖擦拭双眼，轻轻叹息。略微偏头，用红肿的眼睛和泛红的脸颊注视着我。"
    translate None chapter_five_0310:
        f "喂….在公众场合这样不好…"
    translate None chapter_five_0311:
        rs "什么意思？"
    translate None chapter_five_0312:
        f "你的手臂…"
    translate None chapter_five_0313:
        rs "我的手臂？怎么了？当众安慰人不可以吗？"
    translate None chapter_five_0314:
        rs "难道这里风俗不同么？"
    translate None chapter_five_0315:
        rs "我觉得没什么。某种程度上，你让我想起孤儿院的两个孩子。我想照顾你。"
    translate None chapter_five_0316:
        f "哦…"
    translate None chapter_five_0317:
        rs "什-"
    translate None chapter_five_0318:
        "未及开口，我们就被一阵嬉笑喧哗打断。"
    translate None chapter_five_0319:
        rs "那是什么？"
    translate None chapter_five_0320:
        "我松开福恩站起身。伸手相扶时，他迅速握住并立在我身旁。"

    stop music fadeout 2.0
    window hide dissolve

    scene bg stagwich night:
        size(1920, 1080)

    show raen n dark neu at slightright
    show fawn n dark neu at slightleft
    with dissolve
    window show dissolve
    translate None chapter_five_0321:
        u "天啊，你这身太辣了！从哪儿来的？"
    play music "sounds/bgm/Fooling Around Tiny.ogg" fadein 2.0
    translate None chapter_five_0322:
        u "还有头发！这么顺滑用啥护理的？"
    translate None chapter_five_0323:
        u "你和谁一起来的？"
    translate None chapter_five_0324:
        u "能摸摸腹肌吗？！"
    translate None chapter_five_0325:
        l emb "呃…"

    show raen n dark at right
    show fawn n dark at left
    with move
    show leos n dark hur at center with dis
    translate None chapter_five_0326:
        "转角处出现莱奥斯的身影，身后跟着一小群女性。"
    translate None chapter_five_0327:
        "几个姑娘围着他问东问西，动手动脚。"

    show raen n dark sur
    show fawn n dark sur
    with dis
    translate None chapter_five_0328:
        rs "呃，莱奥斯？"
    translate None chapter_five_0329:
        u "这些都是你朋友？小兄弟？"
    translate None chapter_five_0330:
        l "呃…"
    translate None chapter_five_0331:
        l "这些是我的…同伴…我们正在一起旅行。"
    translate None chapter_five_0332:
        u "太可爱了！"
    show raen n dark sad with dis
    translate None chapter_five_0333:
        rs "是吗…？"
    translate None chapter_five_0334:
        rs "这里发生了什么…？"
    translate None chapter_five_0335:
        l "我，呃…我刚问了一个人知不知道哪里能过夜。然后来的人越来越多，最后我被人群包围了…"
    translate None chapter_five_0336:
        l "我不知道他们要干什么…"
    show fawn n dark sad with dis
    translate None chapter_five_0337:
        f "....."
    translate None chapter_five_0338:
        "福恩被突然聚集的人群吓得后退，更深地躲进阴影里。"
    translate None chapter_five_0339:
        rs "那么…你找到我们能住的地方了吗？"
    translate None chapter_five_0340:
        u "我们可以带你们去本地旅馆！这是镇上最好的！"
    translate None chapter_five_0341:
        rs "我不确定我们付不付得起—"
    translate None chapter_five_0342:
        u "来吧，跟我们来！"

    hide leos n dark with dissolve
    show fawn n dark at slightleft
    show raen n dark at slightright
    with move

    translate None chapter_five_0343:
        "两位女士一左一右挽着莱奥斯的手臂带他离开。"
    translate None chapter_five_0344:
        "我轻轻揉了揉福恩的头发。"
    show raen n dark smi with dis
    translate None chapter_five_0345:
        rs "记住，我会照顾你的。来吧。"
    translate None chapter_five_0346:
        "他微微点头，我们随即追上莱奥斯。"

    jump choice_7_done

label leos_go:
    stop music fadeout 2.0
    translate None chapter_five_0347:
        rs "抱歉福恩，我得去追上他。你在这等着。"
    show fawn n dark sad with dis
    translate None chapter_five_0348:
        f "等等，别丢下我—"

    hide fawn n dark
    hide raen n dark
    with dissolve

    scene bg stagwich night with dissolve:
        size (1920, 1080) crop (0, 210, 1257, 751)
        linear 40.0 crop (524, 210, 1093, 751)

    translate None chapter_five_0349:
        "我追赶着莱奥斯。在黑暗中几乎看不清路，几乎没有光线指引。"
    translate None chapter_five_0350:
        "啊…福恩自己待一会儿应该没事，对吧…？"
    translate None chapter_five_0351:
        "但我一个人在这里真的没问题吗？"
    translate None chapter_five_0352:
        "周围空无一人，连莱奥斯也不见了。"
    translate None chapter_five_0353:
        "他往哪个方向去了…？"

    show gallery_26 onlayer middle:
        yanchor -0.23
        size (1920, 500) crop (0, 650, 1440, 375)
    show blacklines onlayer middle
    with dissolve

    translate None chapter_five_0354:
        u "哇，你的头发超—级顺滑！用的什么洗发水？"

    translate None chapter_five_0355:
        l emb "呃呃呃…."

    show gallery_26 onlayer middle:
        yanchor -0.23
        size (1920, 500) crop (0, 650, 1440, 375)
        easein 1 crop (0, 350, 1440, 375)

    translate None chapter_five_0356:
        u "你的穿搭也好性感！"
    translate None chapter_five_0357:
        u "你从哪来的？"

    translate None chapter_five_0358:
        u "你自己一个人在这吗？"

    hide gallery_26
    hide blacklines
    with dissolve

    translate None chapter_five_0359:
        "我循着尖细的嗓音来到一个小型集市区域，人群熙攘。"


    scene gallery_26 with Dissolve(1.0)
    translate None chapter_five_0360:
        "人群中央是莱奥斯，他醒目的发色在人群中格外突出。"
    translate None chapter_five_0361:
        rs "莱奥斯？"
    play music "sounds/bgm/Fooling Around Tiny.ogg" fadein 2.0
    translate None chapter_five_0362:
        l "诸神啊，救救我吧…"

    translate None chapter_five_0363:
        "我试图挤过人群，但他们纹丝不动。最后只能踮起脚尖引起莱奥斯注意。"
    translate None chapter_five_0364:
        rs "怎么回事？"
    translate None chapter_five_0365:
        l "我，呃…我刚问了一个人知不知道哪里能过夜。然后来的人越来越多，最后我被人群包围了…"
    translate None chapter_five_0366:
        l "我不知道他们要干什么…"
    translate None chapter_five_0367:
        "围着他的女士们正摸着他的头发拽来拽去。"
    translate None chapter_five_0368:
        rs "明白了…"
    translate None chapter_five_0369:
        u "这位是谁？"
    translate None chapter_five_0370:
        l "他？我们…一起旅行的。我们是同伴。"
    translate None chapter_five_0371:
        u "真是可—爱！"
    translate None chapter_five_0372:
        rs "总之…至少找到我们可以过夜的地方了吗..？"
    translate None chapter_five_0373:
        u "噢噢，你们一定要住我们本地旅馆！全镇最好的！"
    translate None chapter_five_0374:
        rs "你们镇上有多少家旅馆？"
    translate None chapter_five_0375:
        u "就这一家。"
    translate None chapter_five_0376:
        rs "好吧……"
    translate None chapter_five_0377:
        "姑娘们完全没注意到我，只是围着莱奥斯嗡嗡转悠骚扰他。她们又戳又摸，摆弄他的头发，就是不让他清静。"
    translate None chapter_five_0378:
        "看得出他开始有些不耐烦了。就连我也不希望这些陌生人随便碰他。"
    show bg stagwich night with dissolve:
        size(1920,1080)
    translate None chapter_five_0379:
        "大概在他发作前我该做点什么。"
    translate None chapter_five_0380:
        rs sad "呃…能不能请—"
    translate None chapter_five_0381:
        u "不如你今晚就住我家吧！我保证让你暖暖和和的。"
    translate None chapter_five_0382:
        rs sad "等等，我们应该都—"
    translate None chapter_five_0383:
        u "不，住我家！"
    translate None chapter_five_0384:
        u "你不能去她家！"
    translate None chapter_five_0385:
        rs "你们能不能听—"
    translate None chapter_five_0386:
        u "你居然敢邀请陌生男人在家过夜！她根本不可信，她就是—"
    translate None chapter_five_0387:
        rs ang "能不能都给我闭嘴！"

    translate None chapter_five_0388:
        "我挤开人群站到女孩们和莱奥斯之间。"
    translate None chapter_five_0389:
        "既然必须把话说透，那就这样吧。"
    translate None chapter_five_0390:
        rs ang "现在都听我说了吗？！"
    translate None chapter_five_0391:
        rs "我们有三个人。今晚都需要住处，除非你能收留所有人，否则免谈。"
    translate None chapter_five_0392:
        u "哦…"

    scene gallery_27 with dis
    translate None chapter_five_0393:
        "我猛地拽住莱奥斯胳膊把他拉到身边。"
    translate None chapter_five_0394:
        "说起来他安静得出奇。"
    translate None chapter_five_0395:
        "平时这张嘴根本闲不住。"
    translate None chapter_five_0396:
        l "....."
    translate None chapter_five_0397:
        u "等等，你们俩该不会…"
    translate None chapter_five_0398:
        rs "嗯？"
    translate None chapter_five_0399:
        u "天哪，他们果然！"
    translate None chapter_five_0400:
        rs "你们在说什么..？"
    translate None chapter_five_0401:
        "她们交换着我读不懂的眼神。"
    translate None chapter_five_0402:
        u "你们俩…是在交往吗？"
    show bg stagwich night with dissolve:
        size(1920,1080)
    show raen n sur dark at slightleft
    show leos n sur dark at slightright
    with dis
    translate None chapter_five_0403:
        l "什么？"
    translate None chapter_five_0404:
        u "噢～肯定是情侣啦。"
    translate None chapter_five_0405:
        rs "啊？"
    translate None chapter_five_0406:
        "看着我们困惑的表情，有个女人突然开口："
    translate None chapter_five_0407:
        u "你们睡过了？！"
    show raen n sad dark at slightleft
    show leos n neu dark at slightright
    with dis
    translate None chapter_five_0408:
        rs "睡觉？昨晚确实一起睡了。毕竟没得选。"
    translate None chapter_five_0409:
        u "天呐！"
    translate None chapter_five_0410:
        "我现在完全糊涂了。"
    translate None chapter_five_0411:
        f hur "等等！"
    show raen n sur dark at slightleft with dis
    translate None chapter_five_0412:
        "福恩涨红着脸冲过来。"
    translate None chapter_five_0413:
        rs "你跟着我来的？"
    translate None chapter_five_0414:
        f sad "我不想一个人待在那儿…"
    translate None chapter_five_0415:
        "他委屈巴巴的样子。或许我不该丢下他…"
    translate None chapter_five_0416:
        f sad "那个…大家别误会！我们只是朋友。"
    translate None chapter_five_0417:
        f sad "这两位有点…"
    translate None chapter_five_0418:
        f sad "呃…长途旅行后有点混乱。"
    show raen n sad dark at slightleft with dis
    translate None chapter_five_0419:
        u "真的吗…"
    translate None chapter_five_0420:
        "她们交头接耳，窃窃私语着\"那他还可以追？"
    translate None chapter_five_0421:
        f sad "呃…."
    translate None chapter_five_0422:
        "福恩盯着地面小声嘟囔。"
    translate None chapter_five_0423:
        "刚才应对人群的勇气似乎耗尽了。能主动和这么多人搭话已属难得。"
    show raen n sur dark at slightleft with dis
    translate None chapter_five_0424:
        rs "噢，呃…他想说的是好的！"
    show raen n neu dark at slightleft with dis
    translate None chapter_five_0425:
        rs "他仍然…空闲着？"

    scene bg stagwich night with dissolve:
        xpos -0.02 ypos -0.25 zoom 1.35
        linear 19.0 xpos -0.26 ypos -0.25 zoom 1.35


    translate None chapter_five_0426:
        "我转身背对莱奥斯，将嘴贴近福恩的耳边。"
    translate None chapter_five_0427:
        rs sur "空闲\"是什么意思？"
    translate None chapter_five_0428:
        f sad "呃…"
    translate None chapter_five_0429:
        f "意思是她们想…"
    translate None chapter_five_0430:
        f hur "晚点我再跟你解释，好吗？"
    translate None chapter_five_0431:
        rs sad "好吧…"
    translate None chapter_five_0432:
        "真是糟糕的一天….这只会让情况更糟。我没精力应付她们。"
    translate None chapter_five_0433:
        rs neu "拜托，能带我们去旅馆吗？"
    translate None chapter_five_0434:
        rs wor "我们累坏了。"
    translate None chapter_five_0435:
        "她们都望向莱奥斯寻求某种确认，直到他对她们点头才认可我说的话。"
    translate None chapter_five_0436:
        u "当然！跟我们来。"
    translate None chapter_five_0437:
        "我抓住莱奥斯的手腕拽着他一起走。"
    translate None chapter_five_0438:
        rs "你还好吗？"
    translate None chapter_five_0439:
        l smi "你以为我是谁？我不需要你照顾。"
    translate None chapter_five_0440:
        rs neu "....."
    translate None chapter_five_0441:
        l neu "行。多谢。"
    translate None chapter_five_0442:
        l "我只是不知道该怎么应付她们。"
    translate None chapter_five_0443:
        rs sad "没关系。我相信她们本意是好的…"
    translate None chapter_five_0444:
        l "你觉得她们是故意惹人厌吗？"
    translate None chapter_five_0445:
        f sad "......"
    translate None chapter_five_0446:
        rs neu "暂时先跟着她们吧。"
    translate None chapter_five_0447:
        rs hur "要是情况不对，我们就离开回森林过夜。"
    translate None chapter_five_0448:
        l smi "完美。真是太棒了。"

    jump choice_7_done

label choice_7_done:
    scene bg stagwich night with dissolve:
        xpos 0.53 ypos 1.03 xanchor 0.5 yanchor 1.0 zoom 1.51
        linear 30.0 xpos 0.53 ypos 1.58 xanchor 0.5 yanchor 1.0 zoom 1.51
    #stop music fadeout 2.0
    translate None chapter_five_0449:
        "前往所谓\"镇上最好的旅馆\"的路途并不远。这片区域很安静，我们只遇到零星几个路人。"
    translate None chapter_five_0450:
        "没有莱奥斯的粉丝带路我们可能找不到这里。看来我该心存感激。"
    translate None chapter_five_0451:
        "有几个人聚在小楼门口说笑，但这旅馆看起来实在不怎么样。"
    translate None chapter_five_0452:
        "一位年轻女子倚门而立，抽着某种烟斗。墨绿色头发的男子坐在外侧桌边逗弄着一只鸟。"
    translate None chapter_five_0453:
        "我透过窗户向内张望，里面几乎空无一人。"

    scene bg stagwich night
    show raen n dark neu at center
    show fawn n dark neu at left
    show leos n dark neu at right
    with dis
    #play music "night.ogg" fadein 2.0
    translate None chapter_five_0454:
        f "沉睡鸵鸟酒馆…"
    show leos n dark smi with dis
    translate None chapter_five_0455:
        l "哇！"
    translate None chapter_five_0456:
        l "你的森林小伙伴还教你识字了？"
    show fawn n dark sad with dis
    translate None chapter_five_0457:
        f "....."
    translate None chapter_five_0458:
        f "我本来就会读书…"
    show raen n dark sad with dis
    translate None chapter_five_0459:
        rs "拜托，友善点。"
    translate None chapter_five_0460:
        l "我什么时候不友善了？"
    show raen n dark sad with dis

    translate None chapter_five_0461:
        rs "…你确定要我回答这个问题？"
    translate None chapter_five_0462:
        rs "进去吧。"
    translate None chapter_five_0463:
        l "总比傻站在外面强。"
    translate None chapter_five_0464:
        "带路的那群姑娘推推搡搡地把我们拥进门。"

    stop music fadeout 2.0
    window hide dissolve

    scene bg tavern with dissolve:
        size (1920, 1080) crop (0, 210, 1257, 751)
        linear 30.0 crop (524, 210, 1093, 751)
    window show dissolve
    translate None chapter_five_0465:
        "酒馆内部有些破旧，地板吱呀作响，吧台也很老旧，但相比我们最近的露宿地点…"
    play music "sounds/bgm/tavern.ogg" fadein 3.0
    translate None chapter_five_0466:
        "这里堪称天堂。"
    translate None chapter_five_0467:
        "几张桌子零散摆放，吧台旁搁着几个圆凳。只有零星几个酒客独坐饮酒。气氛相当沉闷。"

    show bg tavern blur onlayer middle:
        yanchor -0.23
        size (1920, 500) crop (0, 300, 1920, 500)
    show blacklines onlayer middle
    show nikos n sur onlayer middle:
        yanchor -0.23
        size (1920, 500) crop (-550, 100, 1920, 500)
    with dissolve


    translate None chapter_five_0468:
        "我们推门而入时，酒保抬起头来，看到突然涌进大门的近15个人，他瞪大了眼睛。"

    scene bg tavern with dissolve

    translate None chapter_five_0469:
        "莱奥斯那群人立刻让他坐在桌边，瞬间将他团团围住，不停地和他闲聊。"
    translate None chapter_five_0470:
        "抱歉了，莱奥斯。你是值得牺牲的。"

    scene bg tavern with dissolve:
        size (1920, 1080)
    show raen n neu at center with dis

    translate None chapter_five_0471:
        rs "我想我得去和酒保聊聊。"
    show raen n at slightright with move
    show fawn n neu at slightleft with dis
    translate None chapter_five_0472:
        f "呃，我也一起去吧…"
    translate None chapter_five_0473:
        "就连我在那群人周围都感到不自在，所以不能怪福恩想跟我一起过来。"
    translate None chapter_five_0474:
        "等我们走到吧台时，有几个女孩已经买了几轮酒带回桌上了。"

    show raen n at center
    show fawn n at left
    with move
    show nikos n sur at right with dis
    translate None chapter_five_0475:
        br "好大一群人！你从哪儿找来的？"
    show raen n sur with dis
    translate None chapter_five_0476:
        "他是在跟我说话吗？"
    translate None chapter_five_0477:
        rs "所有人？你是说那些女孩？"
    translate None chapter_five_0478:
        br "当然是指那些女孩！平常花钱请她们都不肯来这儿。"

    translate None chapter_five_0479:
        br "她们总爱抱怨这地方脏什么的。呸！胡说八道！"
    translate None chapter_five_0480:
        br "你找不到比这儿更干净的地方了！"
    show raen n neu with dis
    translate None chapter_five_0481:
        "我看了眼吧台上厚厚的灰尘。好吧…"
    translate None chapter_five_0482:
        rs "我的朋友—好吧，是我的一个同伴在我们进城时遇到了她们。"
    translate None chapter_five_0483:
        rs "我们问她们知不知道哪里能过夜，她们就指引我们来了这里。"
    show raen n sad with dis
    translate None chapter_five_0484:
        rs "说实话，更像是她们硬把我们拽过来的。"
    show nikos n neu with dis
    translate None chapter_five_0485:
        br "那个同伴？"
    translate None chapter_five_0486:
        "他指了指被女人包围、显得很不自在的莱奥斯。"
    translate None chapter_five_0487:
        rs "对，就是他。"
    show nikos n lau with dis
    translate None chapter_five_0488:
        br "不奇怪。她们会为了像他这么帅的男人做任何事。啊，年轻真好。"
    translate None chapter_five_0489:
        "他怅然地叹了口气。"
    translate None chapter_five_0490:
        br "如果你们要找住处，那算来对地方了。你们多少人？"
    show raen n sad with dis
    translate None chapter_five_0491:
        rs "就我们三个。希望如此。"
    translate None chapter_five_0492:
        br "那就是三间房？每间30羽币。我们是全镇最便宜的，当然也是最好的。"
    translate None chapter_five_0493:
        rs "羽币..？你们不收马克？"
    show nikos n con with dis
    translate None chapter_five_0494:
        "我们困惑地对视一眼。"
    translate None chapter_five_0495:
        f "呃…"
    translate None chapter_five_0496:
        f "这里的货币可能和我们常用的不一样…"
    translate None chapter_five_0497:
        br "不一样？这地区我想不出有哪个镇用别的货币。"
    translate None chapter_five_0498:
        rs "明白了…"
    translate None chapter_five_0499:
        rs "我们能不能商量下？我们已经赶了好几天的路…"
    translate None chapter_five_0500:
        br "...."
    show nikos n neu with dis
    translate None chapter_five_0501:
        br "好吧…你们确实带来了不少客人。这点我承认。"
    translate None chapter_five_0502:
        "他突然停下话头，视线转向房间远端。"
    translate None chapter_five_0503:
        "角落里有个小舞台，因使用而磨损但布满了蜘蛛网。我猜它有段时间没人用过了。"
    translate None chapter_five_0504:
        br "我有个提议。如果你们能让他们玩得尽兴待到晚上，来场小表演，你们就能住便宜的房间。成交？"
    show raen n sur with dis
    translate None chapter_five_0505:
        rs "娱乐他们…？怎么娱乐？"
    translate None chapter_five_0506:
        br "我们在后面储物间有些老旧的音乐设备。"
    translate None chapter_five_0507:
        "音乐？"
    translate None chapter_five_0508:
        "现在真不是挑剔的时候，可是…我该怎么告诉他我根本不懂音乐…？"
    translate None chapter_five_0509:
        "没得选了。我们只能硬着头皮上了。"
    show raen n smi with dis
    translate None chapter_five_0510:
        rs "太感谢了！我们真的不想今晚就离开。"
    show fawn n sad with dis
    translate None chapter_five_0511:
        f "等等，雷恩-"
    show nikos n smi with dis
    translate None chapter_five_0512:
        br "太好了！那我去拿些乐器来。"

    hide nikos with dissolve
    show fawn n at slightleft
    show raen n at slightright
    with move
    translate None chapter_five_0513:
        "那人穿过门口消失了，显然是去取乐器了。"
    translate None chapter_five_0514:
        f "你在想什么…？"
    translate None chapter_five_0515:
        f "我们不可能做到的！"
    show raen n neu with dis
    translate None chapter_five_0516:
        rs "你还有其他主意吗？"
    translate None chapter_five_0517:
        "他若有所思地看向别处。"
    translate None chapter_five_0518:
        rs "这是我们最好的选择。"
    translate None chapter_five_0519:
        "我走回莱奥斯身边，轻轻拍了拍他的肩膀。"

    show fawn n at left
    show raen n at center
    with move
    show leos n neu at right with dis
    translate None chapter_five_0520:
        l "什么？"
    show raen n smi with dis
    translate None chapter_five_0521:
        rs "好吧，好消息！今晚我们可以住这儿了！"
    show leos n sur with dis
    translate None chapter_five_0522:
        l "哇啊！"
    translate None chapter_five_0523:
        l "你总算不是完全没用了！"
    translate None chapter_five_0524:
        rs "坏消息是，我们得搞些音乐表演让这些女孩开心。"
    show leos n ann with dis
    translate None chapter_five_0525:
        l "....."
    translate None chapter_five_0526:
        l "我收回刚才的话。我从没见过像你这么没用的人。"
    translate None chapter_five_0527:
        l "我看上去像吹笛手吗？像那种蹦蹦跳跳弹竖琴或鲁特琴的乐手？你就这么想我的？"
    translate None chapter_five_0528:
        rs "老实说，有点那种感觉。"
    translate None chapter_five_0529:
        l "....."
    show fawn n hap with dis
    translate None chapter_five_0530:
        f "…噗。"
    translate None chapter_five_0531:
        l "闭嘴。"
    show raen n neu with dis
    translate None chapter_five_0532:
        rs "抱歉抱歉，但说实话，要么留下要么睡大街。我更想留在这儿。"
    show fawn n neu with dis
    translate None chapter_five_0533:
        f "我觉得我做不到-"

    show fawn n at farleft
    show raen n at cenleft
    show leos n at farright
    with move
    show nikos n lau at cenright with dis

    translate None chapter_five_0534:
        br "我回来了！选一个吧。"
    translate None chapter_five_0535:
        "他在吧台上摆出各式乐器，等着我们挑选。"
    show nikos n smi with dis
    translate None chapter_five_0536:
        "鲁特琴、小号、排箫，还有许多我叫不出名字的。"
    show raen n smi with dis
    translate None chapter_five_0537:
        rs "哦，我觉得我能演奏这个！"
    translate None chapter_five_0538:
        "我挑了其中最不起眼的一个。我没什么音乐天赋，即使这个可能也是赶鸭子上架。"
    show leos n neu with dis
    translate None chapter_five_0539:
        l "三角铁？认真的？"
    translate None chapter_five_0540:
        rs "那就看看你选什么吧。"
    translate None chapter_five_0541:
        "他怯生生地拨动鲁特琴弦。"
    translate None chapter_five_0542:
        rs "噢嚯，这是什么？我眼前这位是蹦蹦跳跳的鲁特琴手吗？"
    show leos n emb with dis
    translate None chapter_five_0543:
        l "闭嘴。我小时候确实玩过一点，行了吧？"
    translate None chapter_five_0544:
        rs "是是是，你说是就是吧！"
    translate None chapter_five_0545:
        "福恩站在我身后，打量着我们面前摆开的各式物品。"
    translate None chapter_five_0546:
        "怎么感觉越来越热了？我拽了拽脖子周围的衣服，但无济于事。或许我只是有点紧张…"
    translate None chapter_five_0547:
        "我把袖子卷到手肘处，试图降降温。"
    show fawn n sad with dis
    translate None chapter_five_0548:
        f "我真的不行…这些我都从没玩过…"
    translate None chapter_five_0549:
        f "要不我去别处待着，明早再来这儿和你们碰面…"
    show raen n sur with dis
    translate None chapter_five_0550:
        rs "等等！"
    translate None chapter_five_0551:
        rs "肯定有你擅长的项目。"
    translate None chapter_five_0552:
        f "我不确-"
    show leos n neu with dis
    translate None chapter_five_0553:
        l "唱歌怎么样？"
    translate None chapter_five_0554:
        l "你肯定给宠物唱过歌吧。"
    translate None chapter_five_0555:
        f "我…"
    translate None chapter_five_0556:
        f "我不行…他们会笑话我的…"
    translate None chapter_five_0557:
        f "而且它们不是我的宠物…"
    show raen n neu with dis
    translate None chapter_five_0558:
        rs "当然不会！我打赌他们根本不会注意我们。他们都忙着自娱自乐呢。"
    translate None chapter_five_0559:
        rs "他们可能根本不会听你唱歌，都去看莱奥斯了。"
    translate None chapter_five_0560:
        f "嗯…要不我试试看…"
    translate None chapter_five_0561:
        f "可是…"
    translate None chapter_five_0562:
        rs "怎么了？我们会陪你一起上台的。"
    show fawn n neu with dis
    translate None chapter_five_0563:
        f "我该唱什么好呢…？"
    translate None chapter_five_0564:
        rs "嗯…"
    window hide
    jump chapter_six_start
