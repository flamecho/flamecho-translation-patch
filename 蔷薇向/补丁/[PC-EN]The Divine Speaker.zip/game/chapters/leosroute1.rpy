label leosroute1:
    #$ persistent.voice_acting_off = True # TODO REMOVE THIS FOR FULL VOICE ACTING
    #$ config.auto_voice = None # TODO REMOVE THIS FOR FULL VOICE ACTING
    $ leos_route = True
    stop music fadeout 3.0
    scene bg sc sunset with fade:
        xpos 0.5 ypos 1.12 xanchor 0.5 yanchor 1.0 zoom 1.38
    window show dissolve
    translate None leos_chapter1_0001:
        "锡德卡汉的建筑群逐渐吞没最后几缕阳光时，我身上新衣的温暖正舒适地包裹着全身。远处传来乌鸦的啼叫，预示着夜幕即将降临。"
    translate None leos_chapter1_0002:
        "就连莱奥斯似乎也更往温暖衣料里蜷缩了些，我猜他很高兴能盖住腹部。"
    translate None leos_chapter1_0003:
        play music "sounds/bgm/night.ogg" fadeout 2.0
        "换作是我也会的。"
    translate None leos_chapter1_0004:
        "我们一行人静静地在街道上走了一段，直到我率先开口。"
    translate None leos_chapter1_0005:
        show fawn nw sunset neu cloak at farleft
        show cyne nw sunset smi cloak at cenright
        show raen nw sunset smi cloak at cenleft
        show leos nw sunset neu cloak at farright
        with dissolve
        rs "赛恩…真的很感谢你做这些。我由衷感激，大家也是。"
    translate None leos_chapter1_0006:
        c "不必言谢，不过我得承认…我一点儿都不介意听你夸我。"
    translate None leos_chapter1_0007:
        rs "那么既然我们都稍加打扮过了…要怎么混进那个舞会？"
    translate None leos_chapter1_0008:
        show cyne nw sunset shy with dis
        c "呃，这个嘛…事实是…我现在处于软禁状态，所以请柬被没收了。"
    translate None leos_chapter1_0009:
        c "倒也不算坏事，毕竟我本来就讨厌参加舞会。说实话他们没强制我去当惩罚，我还挺意外的。"
    translate None leos_chapter1_0010:
        show leos nw sunset smu with dis
        l "那你怎么还在这儿晃？赶紧回家吧，免得被你妈咪训斥。"
    translate None leos_chapter1_0011:
        show cyne nw sunset hap with dis
        c "喂喂，我总不能每次都乖乖听话吧？那多没劲。反正请柬估计是要不回来了。"
    translate None leos_chapter1_0012:
        show raen nw sunset sad with dis
        rs "该死…谁还有办法？福恩？"
    translate None leos_chapter1_0013:
        show fawn nw sunset sad with dis
        f "我也想不出…"
    translate None leos_chapter1_0014:
        show leos nw sunset neu with dis
        "我瞥向莱奥斯，他回了个耸肩的动作。"
    translate None leos_chapter1_0015:
        "总该有办法的…"
    translate None leos_chapter1_0016:
        "只要那儿有一个人掌握卡斯皮安的情报，就值得一试。"
    translate None leos_chapter1_0017:
        "我抱臂陷入沉思。"
    translate None leos_chapter1_0018:
        l "舞会在哪儿举办？"
    translate None leos_chapter1_0019:
        show cyne nw sunset sur with dis
        c "上层区有个大型会场。问这干嘛？"
    translate None leos_chapter1_0020:
        show leos nw sunset sur with dis
        l "随便问问。非要站在冰天雪地里商量吗？"
    translate None leos_chapter1_0021:
        show cyne nw sunset sur with dis
        c "哎呀呀，你下面没冻掉什么零件吧？"
    translate None leos_chapter1_0022:
        l "…我就当没听见，行吗？"
    translate None leos_chapter1_0023:
        show cyne nw sunset smi with dis
        c "别这样，我又没那么糟。给我个机会嘛莱奥斯。"
    translate None leos_chapter1_0024:
        l "我想不出比给你机会更糟的事了。你爱在雪地里站多久随你便。"
    translate None leos_chapter1_0025:
        "莱奥斯加快脚步朝旅店走去，八成是想和赛恩拉开距离。"
    translate None leos_chapter1_0026:
        "他们俩的性格都这么强势…我真没想到会遇到能让莱奥斯如此烦躁的人。"
    translate None leos_chapter1_0027:
        show fawn nw sunset neu with dis
        f "你在担心吗？"
    translate None leos_chapter1_0028:
        rs "有点。"
    translate None leos_chapter1_0029:
        show fawn nw sunset smi with dis
        f "…我确信这里有人能帮我们，所以先别太焦虑。"
    translate None leos_chapter1_0030:
        "他对我温柔一笑，温暖了我的心，顿时很难再保持消极情绪。"
    translate None leos_chapter1_0031:
        rs "…我只是担心会错过找到他的唯一机会。如果那里有人认识他，甚至如果他本人也出席…"
    translate None leos_chapter1_0032:
        f "…不论我们能不能进去，我们都会找到他的，好吗？"
    translate None leos_chapter1_0033:
        show cyne nw sunset neu with dis
        c "要我说，我从没听说过这个人，所以怀疑他会不会是受邀者。拿到邀请函可不容易。"
    translate None leos_chapter1_0034:
        rs "我想你是对的…"
    translate None leos_chapter1_0035:
        show bg sc night
        show leos nw dark
        show cyne nw dark
        show raen nw dark
        show fawn nw dark
        with dis3
        c "我最好在妈妈发现之前溜回家。要是再惹麻烦我肯定活不成。"
    translate None leos_chapter1_0036:
        "莱奥斯扭头对着赛恩嗤笑一声。"
    translate None leos_chapter1_0037:
        show leos nw dark smi with dis
        l "你今年到底多大了？"
    translate None leos_chapter1_0038:
        show cyne nw dark smi with dis
        c "哈哈，你可真幽默。这玩笑我还是头回听。"
    translate None leos_chapter1_0039:
        c "唉，看来不是所有人都能幸运地没有控制欲强的父母。你不会懂的。"
    translate None leos_chapter1_0040:
        show leos nw dark thi with dis
        "莱奥斯转开脸，眉头紧锁。"
    translate None leos_chapter1_0041:
        show fawn nw dark neu with dis
        f "你不会有事吧？"
    translate None leos_chapter1_0042:
        c "她大概不会杀了我。"
    translate None leos_chapter1_0043:
        show fawn nw dark sur with dis
        f "....!"
    translate None leos_chapter1_0044:
        rs "晚安赛恩，回去路上小心。"
    translate None leos_chapter1_0045:
        l "终于要走了？好极了。"
    translate None leos_chapter1_0046:
        hide cyne with dissolve
        show raen at center
        show fawn at left
        show leos at right
        with move
        "赛恩抬手挥了挥，身影消失在夜色中。"
    translate None leos_chapter1_0047:
        "真希望他不会因为我有太多麻烦…我是说，当初他被禁足也算是我的错吧？"
    translate None leos_chapter1_0048:
        "没等我深入细想，福恩把手搭在我肩上。"
    translate None leos_chapter1_0049:
        show fawn nw dark smi with dis
        f "他肯定没事的。趁天还没更冷，我们回去吧。"
    translate None leos_chapter1_0050:
        l "你们尽管站在这里互相安慰多久都行，我要进去了。"
    translate None leos_chapter1_0051:
        hide leos
        hide raen
        hide fawn
        with dissolve
        "福恩把手从我肩上收回抱在胸前，低头盯着积雪。"
    translate None leos_chapter1_0052:
        "莱奥斯真的就这么走了。我瞄了眼福恩，笑了笑，随即快步追上莱奥斯。"
    translate None leos_chapter1_0053:
        "返程路上我们大多沉默地走过昏暗的街道。夜色中的城市更显壮美，月光映照在皑皑白雪上。"
    translate None leos_chapter1_0054:
        "不多时，我们回到了旅馆门外。"

    window hide dissolve

    scene bg sw night with dissolve
    window show dissolve
    translate None leos_chapter1_0055:
        f c wneu "看来今晚没什么可做的了…明天再碰头？"
    translate None leos_chapter1_0056:
        rs c wneu "好主意。莱奥斯？"
    translate None leos_chapter1_0057:
        l c wthi "......."
    translate None leos_chapter1_0058:
        rs c wsur "喂—莱奥斯？"
    translate None leos_chapter1_0059:
        l "什么？哦，当然。"
    translate None leos_chapter1_0060:
        rs "你心不在焉的，在想什么？"
    translate None leos_chapter1_0061:
        l c wneu "我只是在思考。"
    translate None leos_chapter1_0062:
        f "好吧，嗯…那晚安了，你们俩。"
    translate None leos_chapter1_0063:
        l "晚安，小不点。"
    translate None leos_chapter1_0064:
        "福恩转身朝我们的房间走去。我正要跟上，却发现莱奥斯仍在出神地沉思着。"
    translate None leos_chapter1_0065:
        "好吧，让他静一静。"
    translate None leos_chapter1_0066:
        "跟在福恩身后，我叹息着将手搭在房门上。"
    translate None leos_chapter1_0067:
        "这座庞大无边的城市，拥挤着超乎想象的人群…简直像大海捞针。"
    translate None leos_chapter1_0068:
        "我连他的样貌、声音、如今做什么都不知道…卡斯皮安，你到底在哪儿？"

    window hide dissolve

    scene bg swroom night with dissolve
    window show dissolve
    translate None leos_chapter1_0069:
        "慢慢推开房门时，我突然想起住在索伦宅邸的经历，于是特意检查了门锁。"
    translate None leos_chapter1_0070:
        "我试图把门关上…确切说是想关。但砰的一声，某个东西卡住了门。"
    translate None leos_chapter1_0071:
        rs c wsur "呃…？"
    translate None leos_chapter1_0072:
        l c wsmi "不请我进去吗？真无情啊。"
    translate None leos_chapter1_0073:
        "莱奥斯的靴子卡在门缝里。我连忙拉开门，他闪身进了我的房间。"
    translate None leos_chapter1_0074:
        show bg swroom night:
            xpos 0.7 ypos 1.03 xanchor 0.5 yanchor 1.0 zoom 1.42
        show leos mw dim neu at mleft
        show raen mw dim sur at mright
        with dissolve
        rs "什么事？有话说刚才怎么不直说。"
    translate None leos_chapter1_0075:
        l "人多眼杂。这事只能咱俩谈。"
    translate None leos_chapter1_0076:
        "一阵异样的情绪涌上心头，但我按捺住了。"
    translate None leos_chapter1_0077:
        rs "怎么，连赛恩和福恩都不能说？"
    translate None leos_chapter1_0078:
        show leos mw dim thi with dis
        l "....."
    translate None leos_chapter1_0079:
        l "我有个计划。"
    translate None leos_chapter1_0080:
        rs "关于…？"
    translate None leos_chapter1_0081:
        l "我要你…我要你相信我。就今晚。"
    translate None leos_chapter1_0082:
        rs "我一直都信你啊。"
    translate None leos_chapter1_0083:
        "他眉头一皱抱起双臂，仿佛这不是他想听的答案，最后叹着气直视我的眼睛。"
    translate None leos_chapter1_0084:
        show leos mw dim neu with dis
        l "…很好。那就跟我来，保持安静。"
    translate None leos_chapter1_0085:
        hide leos
        hide raen
        with dissolve
        "说完他径自走向门廊，根本不管我有没有跟上。"
    translate None leos_chapter1_0086:
        "这就是莱奥斯的作风…总指望我盲目跟随，永远不解释…"

    window hide dissolve

    scene bg sw night with dissolve
    window show dissolve
    translate None leos_chapter1_0087:
        "讽刺的是，我确实小跑着追了上去。他的大长腿走得比想象中还快。"
    translate None leos_chapter1_0088:
        rs wneu "要叫上福恩吗？"
    translate None leos_chapter1_0089:
        l wneu "不。就我们两个去。"
    translate None leos_chapter1_0090:
        rs wsur "所以…我们是要偷偷溜出去？"
    translate None leos_chapter1_0091:
        l wsur "什么？偷偷溜出去？雷恩，我们不是小孩子了。没必要所有地方都集体行动，那样太显眼了。"
    translate None leos_chapter1_0092:
        rs wsad "也是…就是感觉有点鬼鬼祟祟的。"
    translate None leos_chapter1_0093:
        "我回头望了望福恩的房门方向。把他一个人留下让我有些愧疚，但我们别无选择。"
    translate None leos_chapter1_0094:
        "莱奥斯明明刚刚还抱怨天气冷，现在却立刻要带我返回那个地方。"

    window hide dissolve

    scene bg sc night
    show leos nw dark cloak neu at slightleft
    show raen nw dark cloak neu at slightright
    with dissolve
    window show dissolve
    translate None leos_chapter1_0095:
        rs "能告诉我我们要去哪吗？"
    translate None leos_chapter1_0096:
        l "还不是时候。跟着我就行。"
    translate None leos_chapter1_0097:
        show raen nw dark sad with dis
        rs "你自己不是警告过我，要小心提防，别轻易相信别人吗？"
    translate None leos_chapter1_0098:
        show leos nw dark thi with dis
        l "呃…我是说过，但这次不一样。"
    translate None leos_chapter1_0099:
        rs "所以相信你就没问题了吗？"
    translate None leos_chapter1_0100:
        l "不，我…不，你最不该相信的人就是我。"
    translate None leos_chapter1_0101:
        l "反正你都跟我到这儿了，不妨继续跟着吧。"
    translate None leos_chapter1_0102:
        "不知为何，我的胸口一阵发闷—他为我做了这么多，为什么我还是不能信任他？他又为何不肯信我？"
    translate None leos_chapter1_0103:
        "可我仍跟在他身侧走着，只是此刻心情更加沉重。"
    translate None leos_chapter1_0104:
        show leos nw dark neu with dis
        l "…上层区啊…希望没走错路。"
    translate None leos_chapter1_0105:
        "他低声自语，带着我在楼梯间穿行，四周一片漆黑。"
    translate None leos_chapter1_0106:
        "他一直很聪明。这点我知道。他几乎能瞬间想出解决办法，但是…"
    translate None leos_chapter1_0107:
        "就不能分我一起商量吗？让我也帮上忙不行吗？ "
    translate None leos_chapter1_0108:
        "就好像他害怕与人过分亲近，害怕接受任何人的帮助。"
    translate None leos_chapter1_0109:
        "就像初次见面时他说的…他讨厌欠人情。当时他宁可我们把他丢在森林里等死也不愿被救…"
    translate None leos_chapter1_0110:
        show bg sc night with hpunch
        "我正想得出神，没注意到莱奥斯突然停步。视线仍盯着地面的我直接撞上了他的后背。"
    translate None leos_chapter1_0111:
        show leos nw dark smi with dis
        l "发什么愣？不会看路吗？"
    translate None leos_chapter1_0112:
        rs "我有在看，只是…"
    translate None leos_chapter1_0113:
        "我只是希望偶尔…你也能让我帮帮你…"
    translate None leos_chapter1_0114:
        rs "算了。"
    translate None leos_chapter1_0115:
        l "所以你总撞到人。多注意点。"
    translate None leos_chapter1_0116:
        rs "对不起…"
    translate None leos_chapter1_0117:
        show leos nw dark neu with dis
        l "…不用道歉…唉，当我没说。走吧，方向应该没错。"
    translate None leos_chapter1_0118:
        "普通民宅逐渐被豪华建筑与庄园取代，连周遭空气都突然变得精致起来。"
    translate None leos_chapter1_0119:
        show raen nw dark sur with dis
        rs "我们该不会…？"
    translate None leos_chapter1_0120:
        l "当然是去舞会。"
    translate None leos_chapter1_0121:
        rs "莱奥斯…我不想打击你，但活动明天才开始。"
    translate None leos_chapter1_0122:
        show leos nw dark sur with dis
        l "…有时候我真不敢相信你这么蠢。不，白痴，我们是去踩点的。"
    translate None leos_chapter1_0123:
        rs "像…像间谍那样？"
    translate None leos_chapter1_0124:
        l "当然，如果能让你高兴的话。"
    translate None leos_chapter1_0125:
        rs "我们不会惹上麻烦吧…？"
    translate None leos_chapter1_0126:
        l "只要不被抓到就不会。"
    translate None leos_chapter1_0127:
        show bg sc night with vpunch
        rs "什么？！"
    translate None leos_chapter1_0128:
        show leos nw dark thi with dis
        l "嘘！你就不能闭嘴五分钟吗？"
    translate None leos_chapter1_0129:
        show raen nw dark sad with dis
        rs "你疯了吗？这种事情怎么能偷偷混进去！"
    translate None leos_chapter1_0130:
        l "为什么不行？我以前可溜进过不少地方。如果这里的人都像看起来那么浮夸自大，根本不会注意到我们。"
    translate None leos_chapter1_0131:
        rs "可是…"
    translate None leos_chapter1_0132:
        l "雷恩，我学会走路的时候就学过怎么闯进建筑物了。这简直小菜一碟。"
    translate None leos_chapter1_0133:
        rs "可要是被抓到—"
    translate None leos_chapter1_0134:
        show leos nw dark neu with dis
        l "我们不会的。"
    translate None leos_chapter1_0135:
        rs "但万一—"
    translate None leos_chapter1_0136:
        l "我说了我们不会。所以我才没告诉你去哪。"
    translate None leos_chapter1_0137:
        rs "…好吧…好吧，行。我们…偷偷溜进去。"
    translate None leos_chapter1_0138:
        l "很高兴你终于同意了，如果我没猜错…那里就是舞会的绝佳位置。"
    translate None leos_chapter1_0139:
        show raen nw dark sur with dis
        rs "就是这里？"
    translate None leos_chapter1_0140:
        l "看起来是。"
    translate None leos_chapter1_0141:
        rs "但是…我们要怎么…？"
    translate None leos_chapter1_0142:
        hide leos
        hide raen
        show bg sc night:
            xpos 0.69 ypos 1.27 xanchor 0.5 yanchor 1.0 zoom 1.42
            linear 20.0 xpos 0.29 ypos 1.27 xanchor 0.5 yanchor 1.0 zoom 1.42
        with dissolve
        "莱奥斯轻松爬上墙头，居高临下看着我。他一条腿晃荡着，眼神里满是玩味，招手示意我上去。"
    translate None leos_chapter1_0143:
        "我咽了咽口水，纵身跳起，但指尖只能勉强碰到墙顶。试了好几次都够不着。"
    translate None leos_chapter1_0144:
        l c wsmi "个子矮真可怜啊。"
    translate None leos_chapter1_0145:
        rs c wsad "闭嘴…这又不是我的错。是你长得太高了。"
    translate None leos_chapter1_0146:
        l "听说喝牛奶能长高。"
    translate None leos_chapter1_0147:
        rs "...."
    translate None leos_chapter1_0148:
        l "果然指望别人不如靠自己…"
    translate None leos_chapter1_0149:
        "他叹了口气从墙上跳下，优雅地落在我身旁。"
    translate None leos_chapter1_0150:
        l "尽量别叫出声。"
    translate None leos_chapter1_0151:
        show bg sc night with hpunch
        rs c wsur "什—啊！"
    translate None leos_chapter1_0152:
        "他毫不费力就把我往上托，几乎是把扔到了墙头上。我死死扒着墙像抓住了救命稻草。"
    translate None leos_chapter1_0153:
        rs c whur "你干嘛？！"
    translate None leos_chapter1_0154:
        l c wneu "我不是让你别叫吗？"
    translate None leos_chapter1_0155:
        rs "没有，你说的是{i}尽量{/i}别叫，你突然那样谁能不叫啊？！"
    translate None leos_chapter1_0156:
        "他咧嘴一笑，轻松跃上墙头坐到我旁边，那副游刃有余的样子让我心生嫉妒。"
    translate None leos_chapter1_0157:
        rs c wsad "我该把你推下去。那样会很有趣。"
    translate None leos_chapter1_0158:
        l c wsmu "至少我不会大喊大叫这么多。"
    translate None leos_chapter1_0159:
        rs "呃…"
    translate None leos_chapter1_0160:
        "栅栏的另一侧是个种满鲜花的大花园。一条小溪蜿蜒流过，小桥连接两岸。"
    translate None leos_chapter1_0161:
        "我小心翼翼地在莱奥斯身旁蹲下，拍打着阿什好心为我们缝制的衣服。"
    translate None leos_chapter1_0162:
        rs c wsur "哇…这里还挺漂亮的，对吧？能随时来这种地方的人可真幸运…"
    translate None leos_chapter1_0163:
        l c wneu "但我打赌他们正是那种对身边鲜花不屑一顾的人。别看了，我们不是来赏花的。"
    translate None leos_chapter1_0164:
        rs c wsad "对不起…"
    translate None leos_chapter1_0165:
        l c wthi "别老是道歉。"
    translate None leos_chapter1_0166:
        rs "可是…我真的很抱歉。"
    translate None leos_chapter1_0167:
        l "…走吧。那看起来像是我们的入场券。"
    translate None leos_chapter1_0168:
        "他指向一扇看似敞开的窗户。走过木桥时，我低头看见水中游动的彩色鱼儿。"
    translate None leos_chapter1_0169:
        "怎么会有人不珍惜这些美好事物？"
    translate None leos_chapter1_0170:
        "我们来到窗前，但窗户太高难以翻入。即使莱奥斯踮起脚也远远够不着。"
    translate None leos_chapter1_0171:
        rs "又怎么了？"
    translate None leos_chapter1_0172:
        l "…嗯…"
    translate None leos_chapter1_0173:
        l c wneu "过来，我有个主意。"
    translate None leos_chapter1_0174:
        rs "又来了…"
    translate None leos_chapter1_0175:
        "突然莱奥斯单膝跪地，侧首看向我。"
    translate None leos_chapter1_0176:
        l "好了。上来吧。"
    translate None leos_chapter1_0177:
        rs c wsur "上…骑你肩膀上…？"
    translate None leos_chapter1_0178:
        l c wsmi "你有更好的办法吗？要不换我骑你？"
    translate None leos_chapter1_0179:
        rs c wsmi "那才叫好笑。"
    translate None leos_chapter1_0180:
        l "那就请吧，公主殿下。"

    window hide dissolve

    scene gallery_124
    show leosroute1 overlay 2
    with dissolve
    window show dissolve
    translate None leos_chapter1_0181:
        "我红着脸迅速坐上他的肩膀，他轻松起身仿佛我没有重量。两人叠起来终于能看到建筑内部。"
    translate None leos_chapter1_0182:
        "他的手掌贴着我的大腿保持平衡。不知为何，我对这种触碰异常敏感，掌心接触的皮肤突然发烫。"
    translate None leos_chapter1_0183:
        "肯定是太尴尬了…这场面确实难为情。自从…呃，就没人让我骑过肩膀！"
    translate None leos_chapter1_0184:
        hide leosroute1 overlay 2
        show leosroute1 overlay 1
        with dissolve
        l "上面怎么没声了？能看到里面吗？"
    translate None leos_chapter1_0185:
        rs "可以…"
    translate None leos_chapter1_0186:
        l "然—后—呢？"
    translate None leos_chapter1_0187:
        "我双手撑着窗台向走廊张望，眼睛适应光线花了几秒钟。"
    translate None leos_chapter1_0188:
        "室内衣冠楚楚的权贵们品着香槟交谈，声音一直传到花园。"
    translate None leos_chapter1_0189:
        rs "…里面有人的。"
    translate None leos_chapter1_0190:
        l "有人？"
    translate None leos_chapter1_0191:
        rs "是啊…他们看起来挺有钱的，像赛恩那样。"
    translate None leos_chapter1_0192:
        l "宾果。"
    translate None leos_chapter1_0193:
        "我凑得更近了些，窥视着那些根本没注意到我的人。"
    translate None leos_chapter1_0194:
        rs "哇，他们真的没发现我。"
    translate None leos_chapter1_0195:
        l "这是好事。走吧，我们该离开这里了。"
    translate None leos_chapter1_0196:
        rs "啊！"
    translate None leos_chapter1_0197:
        "突然，一个金发女人转过身来，眼睛先是看向窗户，然后又移开视线。"
    translate None leos_chapter1_0198:
        scene gallery_125:
            xpos 0.55 ypos 1.03 xanchor 0.5 yanchor 1.0 zoom 1.7
            linear 10.0 xpos 0.55 ypos 1.69 xanchor 0.5 yanchor 1.0 zoom 1.7
        #show leosroute1 overlay 1
        with dissolve
        rs "哇啊！"
    translate None leos_chapter1_0199:
        "当我试图躲藏时，双手在结冰的窗台上打滑，我向前摔去。就在我以为要跌落时，莱奥斯的手指紧紧掐进了我的大腿。"
    translate None leos_chapter1_0200:
        l "靠…！你在干什么？！"
    translate None leos_chapter1_0201:
        rs "我…我不是故意的…！只是有人转身了，所以我…呃，对不起…"
    translate None leos_chapter1_0202:
        l "当心点，不然你会受伤的。不过也许撞到头后你至少能安静些。"
    translate None leos_chapter1_0203:
        l "快说，还看到什么了？"
    translate None leos_chapter1_0204:
        scene gallery_125
        show leosroute1 overlay 1
        with dissolve
        rs "看起来像个走廊…再往里一点儿有扇门通向更大的房间.."
    translate None leos_chapter1_0205:
        l "很好。我们知道怎么进去了。"
    translate None leos_chapter1_0206:
        rs "要是他们明天锁了窗户呢？"
    translate None leos_chapter1_0207:
        l "那我就撬开它。很简单。"

    window hide dissolve

    scene bg sc night with dissolve:
        xpos 0.69 ypos 1.27 xanchor 0.5 yanchor 1.0 zoom 1.42
        linear 36.0 xpos 0.29 ypos 1.27 xanchor 0.5 yanchor 1.0 zoom 1.42
    window show dissolve
    translate None leos_chapter1_0208:
        l c wneu "你怎么总是这么冒冒失失的？"
    translate None leos_chapter1_0209:
        rs c wsad "我也不想的…"
    translate None leos_chapter1_0210:
        l c wsur "总有一天你会惹上我摆不平的麻烦。走吧，离开这儿。"
    translate None leos_chapter1_0211:
        "稍微优雅些的动作，莱奥斯把我托上墙头，确认四下无人后，我们重新跳回漆黑空旷的街道，没人知道我们刚才干了什么。"
    translate None leos_chapter1_0212:
        scene bg sc night
        show raen nw dark cloak sur at slightleft
        show leos nw dark cloak neu at slightright
        with dissolve
        rs "哈，还挺好玩的。"
    translate None leos_chapter1_0213:
        l "好玩？"
    translate None leos_chapter1_0214:
        show raen nw dark smi with dis
        rs "你不觉得吗？我们就像…两个赏金猎人，在追捕猎物！"
    translate None leos_chapter1_0215:
        show leos nw dark smu with dis
        l "你和我？赏金猎人？你连左右都分不清。"
    translate None leos_chapter1_0216:
        show raen nw dark sad with dis
        rs "别这么打击人嘛。要是伊尔兰和维拉斯能做到，我们为什么不行？"
    translate None leos_chapter1_0217:
        l "他们可都是有本事的人。我们俩里只有一个能这么说。"
    translate None leos_chapter1_0218:
        rs "...."
    translate None leos_chapter1_0219:
        l "我跟你说，要是哪天咱俩真成了赏金猎人，我就…不知道，我就亲赛恩还是怎么的。"
    translate None leos_chapter1_0220:
        show raen nw dark sur with dis
        rs "噫，啥？你想亲他？"
    translate None leos_chapter1_0221:
        show leos nw dark emb blush with dis
        l "不..天啊不想，我不—我说这个是因为这根本不可能—"
    translate None leos_chapter1_0222:
        rs "把你奇怪的幻想留着自己享用吧。"
    translate None leos_chapter1_0223:
        l ".............."
    translate None leos_chapter1_0224:
        rs "话说我们为什么不叫上福恩？"
    translate None leos_chapter1_0225:
        l "嗯…"
    translate None leos_chapter1_0226:
        show leos nw dark neu -blush with dis
        "他突然沉默了，陷入沉思。"
    translate None leos_chapter1_0227:
        show leos nw dark thi with dis
        l "人少才方便潜行…光你一个人就够吵的了。"
    translate None leos_chapter1_0228:
        rs "那干嘛不自己一个人去？"
    translate None leos_chapter1_0229:
        show leos nw dark sur with dis
        l "什么？"
    translate None leos_chapter1_0230:
        show raen nw dark sad with dis
        rs "你看，既然我这么碍事。"
    translate None leos_chapter1_0231:
        l "我…"
    translate None leos_chapter1_0232:
        show raen nw dark smi with dis
        rs "承认吧，你就是舍不得和我分开！"
    translate None leos_chapter1_0233:
        show leos nw dark emb blush with dis
        "他皱起眉头，脸颊泛起一片红晕。"
    translate None leos_chapter1_0234:
        l "才…才不是这样。这本来就是你的问题，我当然要带上你。"
    translate None leos_chapter1_0235:
        rs "是是是，随便你怎么自圆其说。"
    translate None leos_chapter1_0236:
        l "你和那个金发小不点待的时间也太长了。"
    translate None leos_chapter1_0237:
        rs "是因为新衣服？帅得让你把持不住了？"
    translate None leos_chapter1_0238:
        l "…确实跟他混太久了…"
    translate None leos_chapter1_0239:
        show raen nw dark sur with dis
        rs "不是吗？"
    translate None leos_chapter1_0240:
        l "....."
    translate None leos_chapter1_0241:
        rs "里~奥~斯~"
    translate None leos_chapter1_0242:
        l "你看…看起来还行。"
    translate None leos_chapter1_0243:
        rs "还行？"
    translate None leos_chapter1_0244:
        l "你是鹦鹉吗？对，还行。"
    translate None leos_chapter1_0245:
        show raen nw dark sad with dis
        "我感觉自己有点噘嘴。"
    translate None leos_chapter1_0246:
        "这可不是我想要的答案…"
    translate None leos_chapter1_0247:
        "但是…为什么？"
    translate None leos_chapter1_0248:
        l "…很好看。"
    translate None leos_chapter1_0249:
        show raen nw dark sur with dis
        rs "嗯？什么？"
    translate None leos_chapter1_0250:
        l "我说很好看行了吧？别逼我说第三遍。"
    translate None leos_chapter1_0251:
        show raen nw dark neu blush with dis
        rs "...."
    translate None leos_chapter1_0252:
        rs "其实你也挺好看的。"
    translate None leos_chapter1_0253:
        l "哼，这不是明摆着的。"
    translate None leos_chapter1_0254:
        show leos nw dark neu -blush with dis
        l "言归正传，说点更重要的事—你怎么知道我们被跟踪了？"
    translate None leos_chapter1_0255:
        show raen nw dark sad -blush with dis
        rs "这里…不是说话的地方。到我房间来。"
    translate None leos_chapter1_0256:
        "他点头应允。"
    translate None leos_chapter1_0257:
        "返回银柳旅馆的路上，我们经过一尊雕像—高大威严，一个男子举手向天，仿佛在指挥千军万马。"
    translate None leos_chapter1_0258:
        show raen nw dark sur with dis
        rs "不知道那是谁？"
    translate None leos_chapter1_0259:
        show leos nw dark smu with dis
        l "但凡立这么大雕像的，都是在弥补某些缺陷。"
    translate None leos_chapter1_0260:
        $ about_Elliot.locked = False
        "基座铭牌上刻着{a=set_entry:enc_people->about_Elliot}{color=#DA70D6}\"伟大的埃利奥特\"{/color}{/a}。我饶有兴趣地端详着，但很快继续往旅馆走去。"
    translate None leos_chapter1_0261:
        "不知为何总想着这件事，我决定晚些时候问问赛恩。"
    translate None leos_chapter1_0262:
        #window hide dissolve
        scene bg sw night with dissolve
        #window show dissolve
        "我们顺利穿过大堂，艾琳甚至没往这边看一眼。"


    scene bg swroom night
    show raen nw dim neu at slightright
    show leos nw dim neu at slightleft
    with dissolve
    stop music fadeout 2.0
    translate None leos_chapter1_0263:
        l "说吧。"
    translate None leos_chapter1_0264:
        show raen nw dim sad with dis
        rs "从何说起呢…这事听起来有点疯狂，明白吗？不过话说回来，我们经手的哪件事不疯狂。"
    translate None leos_chapter1_0265:
        play music "sounds/bgm/forgotten off.ogg" fadein 2.0
        l "是相当疯狂。"
    translate None leos_chapter1_0266:
        rs "好吧…自从离开奥雷利亚卡维拉，我就开始做怪梦。有个声音一直在呼唤我，但几乎听不清她在说什么。"
    translate None leos_chapter1_0267:
        l "..."
    translate None leos_chapter1_0268:
        rs "我确信她当时是想帮我"
    translate None leos_chapter1_0269:
        l "她还告诉你我们被跟踪了？"
    translate None leos_chapter1_0270:
        rs "是的…她说无论谁在跟踪我们都快到了，我们逃不掉的。然后…她就消失了"
    translate None leos_chapter1_0271:
        rs "……你觉得这听起来很蠢吗？"
    translate None leos_chapter1_0272:
        show leos nw dim thi with dis
        l "更蠢的事都发生过，不觉得。为什么拖这么久才告诉我？"
    translate None leos_chapter1_0273:
        rs "我…不知道该怎么开口"
    translate None leos_chapter1_0274:
        l "好吧……"
    translate None leos_chapter1_0275:
        rs "我跟维拉斯说过这事，他也认为像是有人在试图指引我"
    translate None leos_chapter1_0276:
        show leos nw dim sur with dis
        l "你告诉他却不告诉我？"
    translate None leos_chapter1_0277:
        show raen nw dim sur with dis
        rs "我…"
    translate None leos_chapter1_0278:
        l "算了。反正你别太依赖我可能更好"
    translate None leos_chapter1_0279:
        l "以我们这种赶路方式，谁都能轻易跟踪。一开始我就警告过你"
    translate None leos_chapter1_0280:
        show raen nw dim sad with dis
        rs "我害怕她遭遇不测了"
    translate None leos_chapter1_0281:
        l "...."
    translate None leos_chapter1_0282:
        show leos nw dim smu with dis
        l "哈哈，真像你会说的话。明明被警告说有危险人物在找你，却还在担心别人"
    translate None leos_chapter1_0283:
        show leos nw dim neu with dis
        l "你就不能先顾好自己一次吗？"
    translate None leos_chapter1_0284:
        rs "我在努力了…"
    translate None leos_chapter1_0285:
        stop music fadeout 2.0
        show leos nw dim thi with dis
        l "今晚我要留在这里"
    translate None leos_chapter1_0286:
        show raen nw dim sur with dis
        rs "在…我房间？为什么？"
    translate None leos_chapter1_0287:
        play music "sounds/bgm/night.ogg" fadein 3.0
        l "因为以你的性子，睡觉前肯定连门都不锁"
    translate None leos_chapter1_0288:
        rs "我有锁！"
    translate None leos_chapter1_0289:
        show leos nw dim neu with dis
        l "..但我不在身边时你最没防备。这事没得商量"

    #hide leos
    #hide raen
    #with dissolve

    scene bg swroom night with dissolve:
        xpos 0.25 ypos 1.28 xanchor 0.5 yanchor 1.0 zoom 1.68
        linear 36.0 xpos 0.8 ypos 1.28 xanchor 0.5 yanchor 1.0 zoom 1.68
    translate None leos_chapter1_0290:
        "莱奥斯拉过一把椅子靠近床边坐下，翘起二郎腿往后靠"
    translate None leos_chapter1_0291:
        "见争辩无果，我钻进被窝朝他那边望去"
    translate None leos_chapter1_0292:
        rs wsad "你就打算整晚坐着？"
    translate None leos_chapter1_0293:
        l wneu "要是我也睡觉就没意义了"
    translate None leos_chapter1_0294:
        rs "你不能通宵不睡…"
    translate None leos_chapter1_0295:
        l wsur "习惯了。我…反正经常失眠。快睡吧"
    translate None leos_chapter1_0296:
        "夜里独处的氛围很特别。或许是月光，又或许我特别疲惫，一切都变得柔软。仿佛什么都能聊"
    translate None leos_chapter1_0297:
        "可我还是沉默着。我只是个累赘，总给他添麻烦。他永远无法信任或依靠我"
    translate None leos_chapter1_0298:
        "带着这个念头，我合眼陷入无声的梦境"

    stop music fadeout 2.0
    window hide dissolve

    scene black with eye_shut
    pause 2.0
    window show dissolve
    translate None leos_chapter1_0299: #voice map with cyne route
        rs wsad "…有人吗？"
    translate None leos_chapter1_0300: #voice map with cyne route
        rs "你在吗？"
    translate None leos_chapter1_0301:
        "…………….."
    translate None leos_chapter1_0302:
        "寂静在我脑海中回荡。"
    translate None leos_chapter1_0303:
        "又一次，杳无音讯。她已经离开了。"

    window hide dissolve
    pause 2.0

    scene bg swroom day with eye_open
    window show dissolve
    translate None leos_chapter1_0304:
        "我眨眨眼醒来，心头立刻涌上失落"
    translate None leos_chapter1_0305:
        play music "sounds/bgm/sad.ogg" fadein 2.0
        "她真的消失了"
    translate None leos_chapter1_0306:
        "那份寂静本应让我珍惜。这本是我生命中重获自主、回归正常的一小段时光，但…"
    translate None leos_chapter1_0307:
        "我只感到不安。"
    translate None leos_chapter1_0308:
        "突然，身旁传来声响使我浑身僵硬。有什么东西窸窣翻动着被褥。"
    translate None leos_chapter1_0309:
        "……莱奥斯？"
    translate None leos_chapter1_0310:
        "映入眼帘的是长长的红发。躺在我身旁的是莱奥斯，他连靴子都没脱就沉睡不醒。"
    translate None leos_chapter1_0311:
        "..这家伙真是固执。既然累成这样，何必装作不打算睡觉？最初就该直接躺下休息。"
    translate None leos_chapter1_0312:
        "该让他多睡会儿，他显然需要休息。"
    translate None leos_chapter1_0313:
        "我几乎不自觉地想触碰那缎子般顺滑的红发，最终还是垂下了手。"
    translate None leos_chapter1_0314:
        "他自己说过。最好别太亲近，对吧？"
    translate None leos_chapter1_0315:
        stop music fadeout 2.0
        l wneu "…你盯着我看什么？怎么不叫醒我？"
    translate None leos_chapter1_0316:
        rs wsmi "早安，公主。做美梦了吗？"
    translate None leos_chapter1_0317:
        play music "sounds/bgm/Fooling Around Tiny.ogg" fadein 2.0
        l wsmi "哈。真好笑。"
    translate None leos_chapter1_0318:
        rs "说好\"整晚都要像个硬汉坐着守夜\"的人哪去了？"
    translate None leos_chapter1_0319:
        l wemb "我…我才没那么说话！"
    translate None leos_chapter1_0320:
        rs wsur "明明就有。"
    translate None leos_chapter1_0321:
        l "没有！"
    translate None leos_chapter1_0322:
        rs "就有。算了，我只是想让你多睡会，反正你早上总是昏昏沉沉的。"
    translate None leos_chapter1_0323:
        l wthi "我早上清醒得很。"
    translate None leos_chapter1_0324:
        rs wsmi "是~是~随你怎么说。"
    translate None leos_chapter1_0325:
        l wann "知道吗，就算半夜真有人来绑架你也不错。"
    translate None leos_chapter1_0326:
        rs "你根本不是这么想的，莱奥斯，否则你就不会在这儿了。"
    translate None leos_chapter1_0327:
        l wsur "我来是因为欠你的债…可能永远还不清的情分。"
    translate None leos_chapter1_0328:
        rs wneu "就因为救过你命？你救我那么多次早就两清了。"
    translate None leos_chapter1_0329:
        l "...."
    translate None leos_chapter1_0330:
        rs "况且我根本不在意这些。你不欠我什么。"
    translate None leos_chapter1_0331:
        "我只希望你是自愿留在这里…"
    translate None leos_chapter1_0332:
        "可我说不出口。"
    translate None leos_chapter1_0333:
        "他留下来不过是出于责任感。"
    translate None leos_chapter1_0334:
        stop music fadeout 2.0
        rs wsad "那个声音…她消失了。我觉得她不会回来了。"
    translate None leos_chapter1_0335:
        l "…我很抱歉。"
    translate None leos_chapter1_0336:
        "我摇摇头表示不必自责—我们都无能为力。"
    translate None leos_chapter1_0337:
        "只希望…但愿她平安无事。"
    translate None leos_chapter1_0338:
        rs "走吧，该去找其他人了。可以把之后的计划告诉他们。"
    translate None leos_chapter1_0339:
        "他没再多言，起身整理衣物。我也迅速照做，对着镜子梳理头发。"

    window hide dissolve

    scene bg sw day
    show cyne nw smi at slightright
    show fawn nw sur at slightleft
    with dissolve
    window show dissolve
    translate None leos_chapter1_0340:
        play music "sounds/bgm/sidcaeham.ogg" fadein 2.0
        c "我跟你讲，那东西有我整条前臂那么长！"
    translate None leos_chapter1_0341:
        f "这…这真的有可能吗？"
    translate None leos_chapter1_0342:
        show cyne nw hap with dis
        c "我才没骗人！那玩意儿可大了！"
    translate None leos_chapter1_0343:
        f "哇…"

    show cyne at cenright
    show fawn at cenleft
    with move

    show raen nw neu at farright
    show leos nw neu at farleft
    with dissolve
    translate None leos_chapter1_0344:
        rs "你们在聊啥呢？"
    translate None leos_chapter1_0345:
        c "我和福恩刚才在讨论—"
    translate None leos_chapter1_0346:
        show fawn nw emb blush with dis
        f "嘘！没事雷恩，别在意！"
    translate None leos_chapter1_0347:
        "奇怪。"
    translate None leos_chapter1_0348:
        show cyne nw sad with dis
        c "很遗憾我也没能拿回舞会邀请函。"
    translate None leos_chapter1_0349:
        l "用不着，我已经找到混进去的方法了。"
    translate None leos_chapter1_0350:
        show fawn nw sur -blush with dis
        f "什么？"
    translate None leos_chapter1_0351:
        l "我们昨晚踩过点了。他们安保很松懈，所以我和雷恩准备翻墙溜进去。"
    translate None leos_chapter1_0352:
        show cyne nw sad with dis
        c "啊啊，不带上我们吗？呸，没劲。"
    translate None leos_chapter1_0353:
        l "没听过\"两人成伴三人不欢\"吗？要我说，连两人都嫌多。"
    translate None leos_chapter1_0354:
        show fawn nw sad with dis
        f "可是—"
    translate None leos_chapter1_0355:
        l "人太多容易暴露。交给我们就行。"
    translate None leos_chapter1_0356:
        f "好吧…"
    translate None leos_chapter1_0357:
        show cyne nw smi with dis
        c "别太难过福恩。那种舞会无聊死了—我们可以自己办个更好的。"
    translate None leos_chapter1_0358:
        show fawn nw sur with dis
        f "啊？"
    translate None leos_chapter1_0359:
        "赛恩咧嘴一笑，福恩似乎也稍微打起了精神。看到他们终于恢复正常真好。"
    translate None leos_chapter1_0360:
        "应该说比从前更好，毕竟他们以前相处得可不怎么样。现在看起来像是真正的朋友了。"
    translate None leos_chapter1_0361:
        c "让那些扫兴的家伙自己约会去吧。"
    translate None leos_chapter1_0362:
        show leos nw ann with dis
        l "等等，你怎么还在这儿？你不是被软禁了吗？快溜快溜。"
    translate None leos_chapter1_0363:
        show cyne nw sad with dis
        c "太伤人了吧莱奥斯！为何要如此刺痛我的心？"
    translate None leos_chapter1_0364:
        "他语气里满是讥讽，可我仍从他眼中看出一丝自我怀疑。"
    translate None leos_chapter1_0365:
        show leos nw neu with dis
        l "再说—这根本不算约会。全世界那么多人，我怎么可能对他有意思？"
    translate None leos_chapter1_0366:
        show raen nw sad with dis
        rs "喂，我也没那么差吧。"
    translate None leos_chapter1_0367:
        l "也没多好。"
    translate None leos_chapter1_0368:
        show fawn nw neu with dis
        f "那…今天有什么计划？"
    translate None leos_chapter1_0369:
        "福恩用干巴巴的语气打断了我们的争执。"
    translate None leos_chapter1_0370:
        l "考虑到舞会很可能找不到卡斯皮安的线索，我们需要其他方向。今天应该去搜集情报。"
    translate None leos_chapter1_0371:
        show leos nw thi with dis
        l "顺便留意伊尔兰和维拉斯的动向。"
    translate None leos_chapter1_0372:
        show cyne nw hap with dis
        c "噢！我们应该分头行动！"
    translate None leos_chapter1_0373:
        l "你怎么老想着分头？"
    translate None leos_chapter1_0374:
        c "这样效率更高。你觉得呢雷恩？"
    translate None leos_chapter1_0375:
        "好吧…"


    window hide

    menu:
        "我跟莱奥斯一组":
            $ leos_goodend += 1
            window show dissolve
            jump leoschoice1good

        "我没意见":
            $ leos_badend += 1
            window show dissolve
            jump leoschoice1bad


label leoschoice1good:
    show raen nw smi with dis
    translate None leos_chapter1_0376:
        rs "那我和莱奥斯一起！"
    translate None leos_chapter1_0377:
        show leos nw thi with dis
        l "呃…"
    translate None leos_chapter1_0378:
        show raen nw sad with dis
        rs "你能不能表现得开心点啊！"

    jump leoschoice1after

label leoschoice1bad:
    show raen nw neu with dis
    translate None leos_chapter1_0379:
        rs "当然，我不介意。"
    translate None leos_chapter1_0380:
        c "没有偏好？那我就选雷恩—"
    translate None leos_chapter1_0381:
        l "他跟我一起走。"
    translate None leos_chapter1_0382:
        show cyne nw sad with dis
        c "凭什么你先选？好吧，那我带福恩。"
    translate None leos_chapter1_0383:
        show fawn nw sad with dis
        f "这让我觉得自己像个备胎…"

    jump leoschoice1after

label leoschoice1after:
    show raen nw neu with dis
    translate None leos_chapter1_0384:
        rs "那就在舞会前在这里集合吧。"
    translate None leos_chapter1_0385:
        show cyne nw smi with dis
        c "好主意！来吧福恩，我带你逛逛。"
    translate None leos_chapter1_0386:
        show leos nw neu with dis
        l "这可不是观光旅行，认真点。"
    translate None leos_chapter1_0387:
        show cyne nw sur with dis
        c "别这么扫兴。也许你该试着找点乐子，这样说不定会更讨人喜欢。"
    translate None leos_chapter1_0388:
        show leos nw ann with dis
        l "我现在就很讨人喜欢！"
    translate None leos_chapter1_0389:
        show fawn nw sad with dis
        f "再见两位，注意安全。"
    translate None leos_chapter1_0390:
        l "喂—别跑啊，我说了我很讨人喜欢的！"

    hide cyne
    hide fawn
    with dissolve

    show raen at slightright
    show leos at slightleft
    with move
    translate None leos_chapter1_0391:
        "两人从前门离开，回头挥手但完全忽略了莱奥斯。"
    translate None leos_chapter1_0392:
        l "...."
    translate None leos_chapter1_0393:
        show raen nw smi with dis
        rs "别担心莱奥斯，你还不算太糟！"
    translate None leos_chapter1_0394:
        show leos nw sur with dis
        l "哇，真是谢谢啊…"

    window hide dissolve

    scene bg sc day with dissolve
    window show dissolve
    translate None leos_chapter1_0395:
        "雪花轻轻从天空飘落，温柔地附着在冰冷的石头上。放眼望去尽是皑皑白光，诱人玩乐。"


    show raen nw cloak neu at slightright
    show leos nw cloak neu at slightleft
    with dissolve
    translate None leos_chapter1_0396:
        rs "我们堆个雪人怎么样？"
    translate None leos_chapter1_0397:
        l "我看起来像想堆雪人的人吗？"
    translate None leos_chapter1_0398:
        rs "你看起来像从没机会堆雪人的人。"
    translate None leos_chapter1_0399:
        show leos nw thi with dis
        l "没兴趣。"
    translate None leos_chapter1_0400:
        show raen nw smi with dis
        rs "或许由不得你选择！"
    translate None leos_chapter1_0401:
        show leos nw emb blush with dis
        "我抓住他的手拽着往前跑，在新落的雪地里狂奔，留下显眼的脚印。"
    translate None leos_chapter1_0402:
        "路人用余光瞥视我们，默默用眼神谴责这两个制造骚动的家伙。"
    translate None leos_chapter1_0403:
        l "嘿，你干什么？！"
    translate None leos_chapter1_0404:
        rs "赛恩说得对，你需要放松点。"
    translate None leos_chapter1_0405:
        l "才不用。"
    translate None leos_chapter1_0406:
        rs "明明需要！我们不在家了，没人管着我们。为什么不能玩雪？"
    translate None leos_chapter1_0407:
        l "因为…因为我…"
    translate None leos_chapter1_0408:
        rs "因为什么？"
    translate None leos_chapter1_0409:
        l "因为…我..我不会。"
    translate None leos_chapter1_0410:
        show raen nw sur with dis
        rs "...."
    translate None leos_chapter1_0411:
        show raen nw smi with dis
        rs "我也不会，但我们可以一起摸索。"
    translate None leos_chapter1_0412:
        l "我才不要—"
    translate None leos_chapter1_0413:
        u "打扰一下，先生？"
    translate None leos_chapter1_0414:
        show leos nw sur with dis
        l "啊？"
    translate None leos_chapter1_0415:
        "一个铜色头发的小女孩站在雪地里，裹着厚厚的冬装。她仰头看着莱奥斯，眼里充满好奇。"
    translate None leos_chapter1_0416:
        rs "她在跟你说话，莱奥斯。"
    translate None leos_chapter1_0417:
        show leos nw thi with dis
        l "呃..啊…你好…？"
    translate None leos_chapter1_0418:
        "莱奥斯僵在原地，话语充满尴尬。"
    translate None leos_chapter1_0419:
        u "先生，你的头发真漂亮！"
    translate None leos_chapter1_0420:
        l "我？呃…谢谢？"
    translate None leos_chapter1_0421:
        u "我想给你戴花。可以吗？"
    translate None leos_chapter1_0422:
        show raen nw sur with dis
        rs "...."
    translate None leos_chapter1_0423:
        show leos nw emb with dis
        l "呃…"
    translate None leos_chapter1_0424:
        "他斜瞥了我一眼，眼神里满是乞求我帮忙的意味。"
    translate None leos_chapter1_0425:
        show raen nw smi with dis
        rs "他会喜欢的。"
    translate None leos_chapter1_0426:
        show bg sc day with hpunch
        l "呃！？"
    translate None leos_chapter1_0427:
        u "跪下来，先生。你太高了。"
    translate None leos_chapter1_0428:
        l "哦…好吧…"
    translate None leos_chapter1_0429:
        "莱奥斯跪在新落的雪地里，向前倾着头。小女孩从书包里掏出一把有点压扁的花朵，然后一朵朵仔细地别在莱奥斯的头发上。"
    translate None leos_chapter1_0430:
        rs "哇，真好看。"
    translate None leos_chapter1_0431:
        u "我从远处看到你，觉得你戴花会更好看。"
    translate None leos_chapter1_0432:
        "小孩子说话总是口无遮拦啊…"
    translate None leos_chapter1_0433:
        u "看看，先生。你喜欢吗？"
    translate None leos_chapter1_0434:
        "她把镜子举到莱奥斯面前，莱奥斯几乎是厌恶地看着镜中的自己，但还是对小女生尴尬地笑了笑。"
    translate None leos_chapter1_0435:
        show leos nw smi with dis
        l "很…很好看…"
    translate None leos_chapter1_0436:
        show leos nw neu with dis
        rs "是吧！嘿，你叫什么名字？莱奥斯得好好谢谢你。"
    translate None leos_chapter1_0437:
        u "我叫—"

    show leos at left
    show raen at center
    with move

    show ashe n sur at right with dissolve
    $ about_Prim.locked = False
    translate None leos_chapter1_0438:
        a "{a=set_entry:enc_people->about_Prim}{color=#DA70D6}普莉姆{/color}{/a}!你们在那边干什么。"
    translate None leos_chapter1_0439:
        show raen nw sur with dis
        p "爸爸！"
    translate None leos_chapter1_0440:
        show ashe n smi with dis
        a "你把落在店里了。来，我给你戴上。"
    translate None leos_chapter1_0441:
        rs "阿什？"
    translate None leos_chapter1_0442:
        show ashe n sad with dis
        a "雷恩，莱奥斯…抱歉，普莉姆打扰你们了吗？"
    translate None leos_chapter1_0443:
        p "才没有！我只是在给他头发上插花！"
    translate None leos_chapter1_0444:
        a "你知道不该和陌生人说话…不过…"
    translate None leos_chapter1_0445:
        show ashe n smi with dis
        a "干得好。看起来很漂亮。"
    translate None leos_chapter1_0446:
        p "嘿嘿。"
    translate None leos_chapter1_0447:
        "两人相视而笑。那份亲密不言而喻。"
    translate None leos_chapter1_0448:
        show raen nw smi with dis
        rs "来吧莱奥斯，好好谢谢她。"
    translate None leos_chapter1_0449:
        l "谢谢你的…花。"
    translate None leos_chapter1_0450:
        a "走吧，我们去吃点东西怎么样？"
    translate None leos_chapter1_0451:
        p "…..能顺便吃甜点吗？"
    translate None leos_chapter1_0452:
        a "当然。"

    hide ashe with dissolve
    show leos at slightleft
    show raen at slightright
    with move
    translate None leos_chapter1_0453:
        "普莉姆和阿什手牵着手在雪地里走着，开心地聊着天。"
    translate None leos_chapter1_0454:
        l "...."
    translate None leos_chapter1_0455:
        rs "....."
    translate None leos_chapter1_0456:
        show raen nw hap with dis
        rs "噗哈哈哈哈！"
    translate None leos_chapter1_0457:
        show leos nw emb with dis
        l "闭嘴。一个字都不许提这事。"
    translate None leos_chapter1_0458:
        rs "你怎么能对小孩子这么笨拙？！斯塔格威奇那些女士也是！你就是不知道怎么对人好吗？"
    translate None leos_chapter1_0459:
        l "...."
    translate None leos_chapter1_0460:
        l "我…以前从没和这么多人打过交道…"
    translate None leos_chapter1_0461:
        rs "但对人无礼倒是很在行。"
    translate None leos_chapter1_0462:
        l "雷恩，我和别人的交往仅限于想杀我的人和我想要杀死的人。通常这两者是同一批人。"
    translate None leos_chapter1_0463:
        show raen nw smi with dis
        rs "你需要多点生活经验。"
    translate None leos_chapter1_0464:
        l "这话从你嘴里说出来真是滑稽。"
    translate None leos_chapter1_0465:
        rs "你小时候至少和其他孩子玩过吧。"
    translate None leos_chapter1_0466:
        show leos nw sur -blush with dis
        l "..."
    translate None leos_chapter1_0467:
        "等普莉姆走远后，莱奥斯把头发上的花都抖了下来，任它们散落在雪地里。"
    translate None leos_chapter1_0468:
        show raen nw sur with dis
        rs "她会难过的，你知道的。"
    translate None leos_chapter1_0469:
        show leos nw thi with dis
        l "呃…"
    translate None leos_chapter1_0470:
        "他嘟囔着弯下腰，随手摘了朵花塞进口袋。"
    translate None leos_chapter1_0471:
        l "真是浪费时间…"
    translate None leos_chapter1_0472:
        rs "待在一起可不是浪费时间。"
    translate None leos_chapter1_0473:
        show leos nw neu with dis
        l "得了吧，既然要浪费时间，不如让它稍微有点价值。"
    translate None leos_chapter1_0474:
        rs "...?"
    translate None leos_chapter1_0475:
        "他在我身旁站起身，拽住我的手腕带着我往街道深处走去。日头已经高悬，积雪却纹丝未动—寒气刺骨，像在啃咬我们的皮肤。"
    translate None leos_chapter1_0476:
        "他的手指突然松开我手腕，向前走出几步又转回身来。"
    translate None leos_chapter1_0477:
        l "接住。"
    translate None leos_chapter1_0478:
        show bg sc day with hpunch
        "一道金属寒光直冲面门而来，我差点没能在它击中前抓住。"
    translate None leos_chapter1_0479:
        show raen nw sad with dis
        rs "哇啊！你想杀了我吗？！"
    translate None leos_chapter1_0480:
        show leos nw smu with dis
        l "目前还没有这个打算。"
    translate None leos_chapter1_0481:
        rs "可你差点就得手了！"
    translate None leos_chapter1_0482:
        l "那说明你通过了第一课。要是连把匕首都接不住，你就彻底没救了。"
    translate None leos_chapter1_0483:
        rs "呃…你到底想干嘛？"
    translate None leos_chapter1_0484:
        l "我要教你自保的方法。我不会永远陪着你，而我最不想看见的就是你死在我手上。"
    translate None leos_chapter1_0485:
        l "好消息—看来你知道该握哪头！"
    translate None leos_chapter1_0486:
        rs "是个人都知道…"
    translate None leos_chapter1_0487:
        l "你会惊讶于有多少人不知道。"
    translate None leos_chapter1_0488:
        show raen nw neu with dis
        rs "所以…我们怎么做？"
    translate None leos_chapter1_0489:
        show leos nw neu with dis
        l "首先—你完全握错了。虎口卡在这儿，拇指按这个位置。"
    translate None leos_chapter1_0490:
        "莱奥斯踏着轻快的步子走回来，手指穿进我的指缝，带着我重新握住刀柄。"
    translate None leos_chapter1_0491:
        "握在手中轻盈灵巧，可只要瞥见那开刃的寒光，我就浑身不自在。"
    translate None leos_chapter1_0492:
        show raen nw sad with dis
        rs "我不确定我能行…"
    translate None leos_chapter1_0493:
        l "不需要你成为专家，只求危急时刻能保住性命。"
    translate None leos_chapter1_0494:
        l "匕首本就不是最好的防身武器，但胜在便于藏匿。"


    scene bg sc day with dissolve:
        xpos 0.71 ypos 1.4 xanchor 0.5 yanchor 1.0 zoom 1.44
        linear 30.0 xpos 0.29 ypos 1.4 xanchor 0.5 yanchor 1.0 zoom 1.44

    stop music fadeout 3.0
    translate None leos_chapter1_0495:
        rs c wneu "…好吧，我该怎么做？"
    translate None leos_chapter1_0496:
        l c wsmu "用它攻击我。抱着杀死我的决心。"
    translate None leos_chapter1_0497:
        rs c wsur "什么？！我可不想伤到你！"
    translate None leos_chapter1_0498:
        l "相信我，你做不到的。"
    translate None leos_chapter1_0499:
        rs c wsad "..."
    translate None leos_chapter1_0500:
        "这话简直像在挑衅…"
    translate None leos_chapter1_0501:
        play music "sounds/bgm/creepy.ogg" fadein 3.0
        "他又后退几步，把匕首抛向空中又稳稳接住。当他歪着嘴冲我笑时，我知道该进攻了。"
    translate None leos_chapter1_0502:
        "我高举起匕首冲过去，对着他当头劈下。"
    translate None leos_chapter1_0503:
        play sound "sounds/sfx/swing1.ogg"
    translate None leos_chapter1_0504:
        "在我还没看清发生了什么之前，他就抬手格挡，我的匕首飞出去落在几步之外的雪地里。"
    translate None leos_chapter1_0505:
        rs c wsur "……怎么…？"
    translate None leos_chapter1_0506:
        l "你表现得还不如个孩子，就是这么回事。"
    translate None leos_chapter1_0507:
        rs c wsad "哦…"
    translate None leos_chapter1_0508:
        l c wneu "不过这很正常，别担心。你进攻得太急了。放慢节奏，找准破绽。"
    translate None leos_chapter1_0509:
        l "噢对了…这样，把刀举在身前。如果像刚才那样向下劈砍，你立刻就会被捅个对穿。"
    translate None leos_chapter1_0510:
        "捅个对穿…"
    translate None leos_chapter1_0511:
        l "你觉得你刚才在瞄准哪里？"
    translate None leos_chapter1_0512:
        rs "呃，不知道…就是…朝着你？"
    translate None leos_chapter1_0513:
        l "瞄准肋骨下方，向上突刺。你要追求一击毙命，不是给人挠痒痒。如果觉得太难，可以瞄准心脏，但要计算好武器的长度。"
    translate None leos_chapter1_0514:
        rs c wsur "你懂得真多…"
    translate None leos_chapter1_0515:
        l "再来。"
    translate None leos_chapter1_0516:
        "我举着武器挡在胸前，拼命让自己冷静下来。"
    translate None leos_chapter1_0517:
        "等待破绽，等待破绽…"
    translate None leos_chapter1_0518:
        "就在他又要把武器抛向空中时，我猛冲过去，用力将刀刃刺向他。"
    translate None leos_chapter1_0519:
        play sound "sounds/sfx/fallonground3.ogg"
    translate None leos_chapter1_0520:
        show bg sc day with vpunch
        "他轻松接住空中落下的匕首，侧身一闪，害我踉跄着栽进雪堆里。"
    translate None leos_chapter1_0521:
        rs c wsad"……没用的。我果然还是不行。"
    translate None leos_chapter1_0522:
        l c wsur "为什么这么快就放弃？"
    translate None leos_chapter1_0523:
        rs "因为我不擅长这个!"
    translate None leos_chapter1_0524:
        l "没人能天生擅长任何事。你以为我拿到第一把武器那天就懂这些吗？当然不是。"
    translate None leos_chapter1_0525:
        l c wneu "换个训练方式。站起来。"
    translate None leos_chapter1_0526:
        "他伸手拉我起来，拍掉我肩上的雪沫。"
    translate None leos_chapter1_0527:
        l c wsmu "这次换我进攻。"
    translate None leos_chapter1_0528:
        rs "什么？！"
    translate None leos_chapter1_0529:
        l "我会留手的，别担心。专注格挡我的攻击。"
    translate None leos_chapter1_0530:
        "还没等我反应过来，他的刀刃已呼啸而至。我刚躲过第一击，不到半秒他又贴到眼前。"
    translate None leos_chapter1_0531:
        l "知道刀战中最好的保命方法吗？"
    translate None leos_chapter1_0532:
        rs c wsad "当然不知道!"
    translate None leos_chapter1_0533:
        l "逃跑。匕首是贴身武器—只要保持距离，存活几率就大得多。"
    translate None leos_chapter1_0534:
        rs "可我见过你飞刀伤人!"
    translate None leos_chapter1_0535:
        l "绝大多数人可没这本事。"
    translate None leos_chapter1_0536:
        "这话不用他说第二遍。"
    translate None leos_chapter1_0537:
        "我后跳出战圈，转身就要跑。"
    translate None leos_chapter1_0538:
        "直到—"
        play sound "sounds/sfx/fallonground3.ogg"
    translate None leos_chapter1_0539:
        scene bg sc day with hpunch:
            xpos 0.69 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.5
        rs c whur "哇啊！"
    translate None leos_chapter1_0540:
        "我的脸结结实实砸进雪地。"
    translate None leos_chapter1_0541:
        rs "你是认真的吗？刚才绊倒我？"
    translate None leos_chapter1_0542:
        l c wsmu "逃跑时若不注意周围环境，你就跟死人没两样。"
    translate None leos_chapter1_0543:
        "他轻松翻过我的身体，俯身悬在我上方微笑。他的红发散落在我周身，与皑皑白雪形成鲜明对比。"
    translate None leos_chapter1_0544:
        rs c wneu "..."
    translate None leos_chapter1_0545:
        l "今天就到此为止吧。我不想被守卫举报。"
    translate None leos_chapter1_0546:
        rs "....."
    translate None leos_chapter1_0547:
        stop music fadeout 3.0
        "不知为何，我僵在原地，被…他完全吸引了。"
    translate None leos_chapter1_0548:
        l "喂？还在线吗？还是说今天脑容量已经耗尽？"
    translate None leos_chapter1_0549:
        rs c wemb "呃…啊，什么？"
    translate None leos_chapter1_0550:
        play music "sounds/bgm/night.ogg" fadein 3.0
        l c wsmi "天色不早了，我们该去和其他人汇合。"
    translate None leos_chapter1_0551:
        "这次当他伸手拉我起来时，我异常清晰地感知到他触碰我手掌的触感，但他几乎是刚碰到就立刻缩回了手。"


    scene bg sc day
    show raen nw cloak neu blush at slightright
    show leos nw cloak smu at slightleft
    with dissolve
    translate None leos_chapter1_0552:
        rs "抱歉我这么难教…"
    translate None leos_chapter1_0553:
        show leos nw neu with dis
        l "第一次能做到这样不错了。反正你遇到的大多数对手都不会像我这么强。"
    translate None leos_chapter1_0554:
        rs "没人能比你更厉害。"
    translate None leos_chapter1_0555:
        show leos nw thi blush with dis
        l "…这我可不敢保证"
    translate None leos_chapter1_0556:
        rs "这是事实。你是最棒的。"
    translate None leos_chapter1_0557:
        "他局促地揉着后颈，目光从我身上移开。"
    translate None leos_chapter1_0558:
        l "只要我还在…你本来也不需要学这些。"
    translate None leos_chapter1_0559:
        show raen nw smi with dis
        rs "那我们就必须永远在一起啦！"
    translate None leos_chapter1_0560:
        show leos nw sur -blush with dis
        l "..."
    translate None leos_chapter1_0561:
        show leos nw smu with dis
        l "怎么可能忍受你那么久。快点跟上。你腿怎么这么短？"
    translate None leos_chapter1_0562:
        show raen nw sur -blush with dis
        rs "你腿才太长呢！我当然跟不上。"


    show raen at cenleft
    show leos at farleft
    with move

    show fawn nw cloak smi at farright
    show cyne nw cloak sur at cenright
    with dissolve
    translate None leos_chapter1_0563:
        c "哟，看看这是谁！"
    translate None leos_chapter1_0564:
        show raen nw smi with dis
        rs "赛恩，福恩！我们正要去找你们。"
    translate None leos_chapter1_0565:
        "福恩啃着某个看起来很甜的零食，冲我笑了笑。"
    translate None leos_chapter1_0566:
        rs "你俩玩得开心吗？"
    translate None leos_chapter1_0567:
        f "赛恩带我逛遍了全镇。这里太棒了！"
    translate None leos_chapter1_0568:
        "比起初次相遇时，他的变化如此巨大。从那个害怕周围所有人的安静男孩，变成能在这个大城市里逛得乐不思蜀的人。"
    translate None leos_chapter1_0569:
        l "让我猜猜—你俩全程都在瞎逛吧。"
    translate None leos_chapter1_0570:
        c "失礼了！我们可是认真搜寻的！你们肯定毫无收获。"
    translate None leos_chapter1_0571:
        show leos nw thi with dis
        l "...."
    translate None leos_chapter1_0572:
        show cyne nw hap with dis
        c "啊哈，我说对了吧！瞧，我们有发现！"
    translate None leos_chapter1_0573:
        show raen nw sur with dis
        rs "真有发现！？"
    translate None leos_chapter1_0574:
        show cyne nw neu with dis
        c "呃…勉强算。我们在市场听到有人说\"卡斯皮安\"这个名字，但没找到说话的人。"
    translate None leos_chapter1_0575:
        show leos nw neu with dis
        l "哇，真有用呢。太感谢你专程来告诉我们这个毫无价值的消息。"
    translate None leos_chapter1_0576:
        show cyne nw smi with dis
        c "比你们强多了。看来福恩和我搭档起来终究比你和雷恩要强。"
    translate None leos_chapter1_0577:
        c "我们可是把时间花在探索城市上，而不是彼此\"探索\"。"
    translate None leos_chapter1_0578:
        show leos nw emb blush with dis
        l "什么？"
    translate None leos_chapter1_0579:
        show fawn nw sad with dis
        c "你没听错。管好你的裤裆，天哪。"
    translate None leos_chapter1_0580:
        show fawn nw sur with dis
        f "没想到有朝一日会轮到赛恩叫别人管好裤裆。"
    translate None leos_chapter1_0581:
        l "我..我..我才没做那种事！"
    translate None leos_chapter1_0582:
        c "是~是~。怪不得你现在脸红得跟什么似的。"
    translate None leos_chapter1_0583:
        l "闭嘴。要聊完了就走吧，还有个舞会等着呢。"
    translate None leos_chapter1_0584:
        show cyne nw sur with dis
        c "等—等等等等！你总不能摆着这张臭脸直接闯进去吧！"
    translate None leos_chapter1_0585:
        l "为什么不能？"
    translate None leos_chapter1_0586:
        c "你得…对他们温柔些。那些人可娇贵了。"
    translate None leos_chapter1_0587:
        show leos nw ann -blush with dis
        l "哦太好了。我可不打算行屈膝礼，趁早死了这条心。"
    translate None leos_chapter1_0588:
        c "哎呀别傻了。想在那儿混下去就一个法子—假装你比所有人都更有钱、更尊贵、更好看。"
    translate None leos_chapter1_0589:
        show raen nw sur with dis
        rs "什么..？"
    translate None leos_chapter1_0590:
        show cyne nw sad with dis
        c "好看这点倒是能蒙混过关，可惜你浑身都散发着穷酸味。"
    translate None leos_chapter1_0591:
        show fawn nw smi with dis
        "莱奥斯的眉毛抽动了一下，但保持至寂。"
    translate None leos_chapter1_0592:
        show cyne nw neu with dis
        c "挺直腰杆，下巴微抬。对了，千万别说任何会被人抓住把柄的话—那些人可狠毒了。"
    translate None leos_chapter1_0593:
        rs "那我呢？"
    translate None leos_chapter1_0594:
        show cyne nw smi with dis
        c "呃…跟着莱奥斯当个漂亮花瓶就行？"
    translate None leos_chapter1_0595:
        show raen nw smi with dis
        rs "我会努力的！"
    translate None leos_chapter1_0596:
        "福恩举手轻轻拉住我的袖子，用眼神示意想单独谈话。"

    hide cyne
    hide leos
    with dissolve

    show raen at slightleft
    show fawn at slightright
    with move
    translate None leos_chapter1_0597:
        "赛恩和莱奥斯还在为礼仪争执不休，我趁机跟着福恩走到一旁。"
    translate None leos_chapter1_0598:
        show raen nw sur with dis
        rs "那是什么？"
    translate None leos_chapter1_0599:
        show fawn nw neu blush with dis
        f "雷恩…有件事我想告诉你…"
    translate None leos_chapter1_0600:
        show fawn nw sad with dis
        f "我…这件事压在心头很久了，但现在…我担心是不是太迟了…"
    translate None leos_chapter1_0601:
        "不知不觉间，我的视线又飘向莱奥斯，他正抱臂叹息着等我。"
    translate None leos_chapter1_0602:
        show fawn nw neu -blush with dis
        f "...."
    translate None leos_chapter1_0603:
        show raen nw smi with dis
        rs "噢抱歉福恩。你刚才要说什么？我有点走神。"
    translate None leos_chapter1_0604:
        show fawn nw sad with dis
        f "…没什么，别在意。只是…万事小心，好吗？"
    translate None leos_chapter1_0605:
        rs "嗯，当然！"


    show raen at cenleft
    show fawn at farright
    with move

    show cyne nw neu cloak at cenright
    show leos nw ann cloak at farleft
    with dissolve
    translate None leos_chapter1_0606:
        l "诸神在上，我真是烦透这种场合。管他们自以为多高贵，在我眼里屁都不是。我去那儿只为办一件事。"
    translate None leos_chapter1_0607:
        show cyne nw sur with dis
        c "你要是这副德行，他们一个字都不会对你说的！"
    translate None leos_chapter1_0608:
        l "呃啊啊…好吧！好吧，我会尽力的！我们能走了吗？"
    translate None leos_chapter1_0609:
        c "等等…你也该把武器取下来。"
    translate None leos_chapter1_0610:
        show leos nw ann -weapons with dis
        "他叹了口气，解开各种扣带，把武器藏进了衣服里。"
    translate None leos_chapter1_0611:
        rs "好了，走吧。"
    translate None leos_chapter1_0612:
        hide raen
        hide fawn
        hide leos
        hide cyne
        with dissolve
        "我们挥手告别了福恩和赛恩，他俩肩并肩朝着银柳方向走去。"


    scene bg sc sunset with dissolve:
        xpos 0.7 ypos 1.49 xanchor 0.5 yanchor 1.0 zoom 1.49
        linear 33.0 xpos 0.26 ypos 1.49 xanchor 0.5 yanchor 1.0 zoom 1.49
    translate None leos_chapter1_0613:
        "不知何时太阳已开始沉入地平线，将锡德卡汉染成橘红色。"
    translate None leos_chapter1_0614:
        "于是我们拾级而上，沿着锡德卡汉那通往山巅的无尽阶梯攀登。"
    translate None leos_chapter1_0615:
        stop music fadeout 3.0
        "最终，我们来到了昨晚潜行经过的那些华丽建筑群中。只是这次，街上熙熙攘攘的人群都穿着适合皇室的华美服饰。我猜他们都是去参加舞会的。"
    translate None leos_chapter1_0616:
        rs c wsad "我们该怎么从这么多人眼皮底下溜过去？"
    translate None leos_chapter1_0617:
        play music "sounds/bgm/creepy.ogg" fadein 3.0
        l c wneu "….你听到赛恩说的了。挺直腰板。我们就这么从他们身边走过，绕过前面那个拐角，然后像昨晚一样行动。明白吗？"
    translate None leos_chapter1_0618:
        rs "好…好的…"
    translate None leos_chapter1_0619:
        "我试图咽下紧张情绪，但脑海中回荡的心跳声震耳欲聋。"
    translate None leos_chapter1_0620:
        "牢记莱奥斯的嘱咐，我们混在人群中沿着街道行走，随后拐进一条安静的侧巷，贴着围墙走直到避开所有视线。"
    translate None leos_chapter1_0621:
        l "准备好了吗？"
    translate None leos_chapter1_0622:
        rs "随时可以。"
    translate None leos_chapter1_0623:
        l "翻墙前先观察有没有人，明白吗？进去后让我来应付。"
    translate None leos_chapter1_0624:
        "我点点头，莱奥斯单膝跪地准备托我上去。"
    translate None leos_chapter1_0625:
        "我小心翼翼抓住墙沿偷瞄。花园里乐声飘扬，从敞开的窗户流淌而出，但四下无人。"
    translate None leos_chapter1_0626:
        rs c wneu "…看来没问题。周围没人。"
    translate None leos_chapter1_0627:
        "我奋力爬上墙头，迅速翻到另一侧，落在修剪整齐的花园里。片刻后莱奥斯也如法炮制，轻巧地落在我身旁。"
    translate None leos_chapter1_0628:
        rs c wsmi "到目前为止一切顺利。"
    translate None leos_chapter1_0629:
        l c wthi "别高兴太早。动作快。"
    translate None leos_chapter1_0630:
        "我们越过木桥再次接近那扇窗户。莱奥斯一言不发地蹲下，让我重新骑上他的肩膀。"
    translate None leos_chapter1_0631:
        "透过仍然敞开的窗户向内窥探，可以听见建筑深处传来嘈杂的人声和音乐。"
    translate None leos_chapter1_0632:
        rs "看起来没人把守。"
    translate None leos_chapter1_0633:
        l c wsmu "很好。爬进去帮我一把。"
    translate None leos_chapter1_0634:
        "我小心翼翼地攀上窗沿，滑进昏暗的走廊，随后向莱奥斯拉出手。"
    translate None leos_chapter1_0635:
        "他轻松抓住我的手，很快我们两人都进入了室内。"
    translate None leos_chapter1_0636:
        play sound "sounds/sfx/walkinghall2.ogg" fadeout 1.0
        "正当我们准备朝音乐声方向移动时，走廊尽头突然传来脚步声和说笑声。"
    translate None leos_chapter1_0637:
        l c wann "该死…见鬼！"
    translate None leos_chapter1_0638:
        rs c wsur "快，躲这里！"

    window hide dissolve

    scene gallery_126 with dissolve
    window show dissolve
    translate None leos_chapter1_0639:
        "我拽着莱奥斯冲进两根立柱之间。虽然挤得难受，但在这几乎空荡的走廊里，这是唯一的藏身之处。"
    translate None leos_chapter1_0640:
        rs "嘘。"
    translate None leos_chapter1_0641:
        "我将食指竖在唇前，自下而上地望向莱奥斯。他低头瞥了我一眼，我们脸庞相距不过数寸。"
    translate None leos_chapter1_0642:
        "身体如此紧密地相贴着，他每次呼吸的起伏、每个细微的动作都令我异常敏感。"
    translate None leos_chapter1_0643:
        "脚步声愈来愈近。"
    translate None leos_chapter1_0644:
        "糟糕…求求你，千万别往这边看…"
    translate None leos_chapter1_0645:
        "我们本该假装是迷路的宾客…为什么我总把事情搞砸？"
    translate None leos_chapter1_0646:
        "不知不觉间，我轻轻将前额抵上莱奥斯的胸膛无声叹息，却在两道身影经过时瞬间僵住。"
    translate None leos_chapter1_0647:
        "随后他们一语不发地离开了。脚步声渐行渐远。"
    translate None leos_chapter1_0648:
        stop music fadeout 2.0
        rs "...."
    translate None leos_chapter1_0649:
        l "......."
    translate None leos_chapter1_0650:
        scene gallery_127 with dissolve
        rs "对不起—"
    translate None leos_chapter1_0651:
        play music "sounds/bgm/night.ogg" fadein 3.0
        l "不，做得很好。"
    translate None leos_chapter1_0652:
        rs "啊？"
    translate None leos_chapter1_0653:
        l "反应很机敏。刚才多亏了你。"
    translate None leos_chapter1_0654:
        "…."
    translate None leos_chapter1_0655:
        "我眨了眨眼别开视线，胃里翻腾着陌生的情绪。"
    translate None leos_chapter1_0656:
        rs "哦…我还以为…你又会说我没用。"
    translate None leos_chapter1_0657:
        l "……不，你…你并不没用…只是偶尔犯傻。但这次不是。走吧，趁还没来更多守卫。"
    translate None leos_chapter1_0658:
        "当他抽身离开时，我无法忽略骤然涌上的孤独感。那些被他触碰过的地方仿佛在发烫。"

    #stop music fadeout 2.0

    jump leosroute2





    #
