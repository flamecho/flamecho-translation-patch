label illranverasscene3:
    $ iv_scene_three = True
    scene bg sv night with Fade(1.0, 1.0, 1.0):
        xpos 0.51 ypos 1.02 xanchor 0.5 yanchor 1.0 zoom 1.56
    window show dissolve
    play music "sounds/bgm/night.ogg" fadein 3.0
    translate None illranveras_scene3_0001:
        imn "好吧。我就敲敲门，走进去，表现得自然随意些。没什么大不了的，对吧？"
    translate None illranveras_scene3_0002:
        "伊尔兰一反常态地在维拉斯的门前踱来踱去。若是换作别人，他早就直接闯进去了，但有什么东西让他感到紧张。"
    translate None illranveras_scene3_0003:
        "他试图将那东西从脑海中赶走，但他心里再清楚不过那是什么。"
    translate None illranveras_scene3_0004:
        v neu "伊尔兰，你再这样来回踱步会把所有人都吵醒的。"
    translate None illranveras_scene3_0005:
        "门突然打开，维拉斯站在门口。"
    translate None illranveras_scene3_0006:
        i sad "我没在踱步，我只是…只是在思考。"
    translate None illranveras_scene3_0007:
        v smi "在我门口跺着脚走来走去地思考？不如进来吧。"
    translate None illranveras_scene3_0008:
        i con "大半夜的邀请我进去？天哪，真不害臊。别人会怎么说啊？"
    translate None illranveras_scene3_0009:
        v "我们大多数夜晚都在一起度过，伊尔兰。别人爱怎么说就怎么说，我不在乎。"
    translate None illranveras_scene3_0010:
        "他把门开得更大了些，伊尔兰跟在他身后走进房间。"

    window hide dissolve

    scene bg sv room night:
        xpos 0.51 ypos 1.15 xanchor 0.5 yanchor 1.0 zoom 1.15
    show illran n dim armsdown neu at slightright
    show veras n dim smi1 at slightleft
    with dissolve
    window show dissolve
    translate None illranveras_scene3_0011:
        "令伊尔兰惊讶的是，这个房间与他自己的出奇相似。维拉斯在床边坐下。"
    translate None illranveras_scene3_0012:
        "他平静地微笑着，很高兴有伊尔兰作伴。"
    translate None illranveras_scene3_0013:
        v "你是有话要问我吗？"
    translate None illranveras_scene3_0014:
        i "呃，没什么特别的…我只是想我们或许可以聊会天。我想知道你认识埃利奥特多久了？从没听你提起过他。"
    translate None illranveras_scene3_0015:
        v "大概几百年吧。我们在锡德卡汉相识，那时他刚升格不久，随后获得了凡人身体。他是我遇到的另一个神，所以我们很快就成了朋友。" # check line
    translate None illranveras_scene3_0016:
        show veras n dim sad1 with dis
        v "……看到他活着我很高兴。他突然消失了，我还以为……"
    translate None illranveras_scene3_0017:
        show illran n dim sad with dis
        i "……这里看起来是个不错的地方。难怪他会来这儿。"
    translate None illranveras_scene3_0018:
        v "……是啊，看起来确实不错。"
    translate None illranveras_scene3_0019:
        i "也很宁静。"
    translate None illranveras_scene3_0020:
        show veras n dim neu1 with dis
        v "...."
    translate None illranveras_scene3_0021:
        show illran n dim fli with dis
        i "简单美好的乡村生活或许会让人耳目一新。当然，这不像悬赏追捕那么刺激，但至少是正经营生。"
    translate None illranveras_scene3_0022:
        show veras n dim sad1 with dis
        v "...."
    translate None illranveras_scene3_0023:
        show illran n dim sad with dis
        i "我只是在想……你上次见到埃利奥特已经是很久以前的事了，而且村子里肯定还有其他友好的神明。"
    translate None illranveras_scene3_0024:
        i "你可以……你知道的……住在这里，安全地生活，被同族围绕。"
    translate None illranveras_scene3_0025:
        stop music fadeout 2.0
        v "伊尔兰…"
    translate None illranveras_scene3_0026:
        i "你父母是农民对吧？你可以重操旧业。"
    translate None illranveras_scene3_0027:
        i "没必要……非要继续漂泊……你完全可以留在这里。"
    translate None illranveras_scene3_0028:
        "维拉斯脸上的笑容早已消失了。"
    translate None illranveras_scene3_0029:
        i "也许…我甚至可以去拜访你，你知道的？或者你可以来拜访我。"

    window hide dissolve

    scene gallery_105 with dissolve
    window show dissolve
    play music "sounds/bgm/moonnight.ogg" fadein 3.0
    translate None illranveras_scene3_0030:
        v "伊尔兰，请听我说。"
    translate None illranveras_scene3_0031:
        v "自从我们相遇的那天起，每一天都是恩赐。即使这意味着要经历之前那些年的所有艰辛，我也愿意重来一遍。"
    translate None illranveras_scene3_0032:
        v "能拥有一个让告别如此痛彻心扉的人在身边，我是世界上最幸运的人。"
    translate None illranveras_scene3_0033:
        i "你还不明白吗？我们可以一直这样继续下去。不必结束。"
    translate None illranveras_scene3_0034:
        v "这不可能永远持续。"
    translate None illranveras_scene3_0035:
        i "为什么不能？"
    translate None illranveras_scene3_0036:
        v "....."
    translate None illranveras_scene3_0037:
        scene gallery_106 with dissolve
        i "即使当我成为躺在临终床上的老人时，我也想要你在身边。"
    translate None illranveras_scene3_0038:
        v "一个躺在临终床上的老人，身边却是个将永远悲伤的人。"
    translate None illranveras_scene3_0039:
        i "那我就撕碎这个世界。让所有人都恨我入骨，直到那该死的在天上做决定的家伙让我变得跟你一样。"
    translate None illranveras_scene3_0040:
        v "....."
    translate None illranveras_scene3_0041:
        i "为什么你不听？你会…你会在这里过得很舒适，很快乐。"
    translate None illranveras_scene3_0042:
        v "...."
    translate None illranveras_scene3_0043:
        i "如果不在这个地方，那就去锡德卡汉，和我一起。如果你厌倦了赏金猎人的生活，我们就停下。"
    translate None illranveras_scene3_0044:
        v "伊尔兰—"
    translate None illranveras_scene3_0045:
        i "我该说什么才能说服你？"
    translate None illranveras_scene3_0046:
        v "伊尔兰，你愿意吻我吗？"
    translate None illranveras_scene3_0047:
        i "....."
    translate None illranveras_scene3_0048:
        i "什么…？"
    translate None illranveras_scene3_0049:
        v "你愿意吻我吗？"


    scene gallery_106b with Dissolve(2.0)
    translate None illranveras_scene3_0050:
        "伊尔兰没有等待第二次请求。"

    if achievement.has("illran_kiss"):
        pass
    else:
        $ renpy.display_notify("成就解锁：他们的初吻，他们的诀别之吻")

    python:
        achievement.grant("illran_kiss")
        achievement.sync()

    translate None illranveras_scene3_0051:
        "当他俯身亲吻维拉斯时，绿色的长发如瀑布般垂落。 "
    translate None illranveras_scene3_0052:
        "他们的初吻。伊尔兰幻想这一刻已有多年，却从未期待它真的发生。能在他身边守望，就已足够幸福。"
    translate None illranveras_scene3_0053:
        "这感觉比他想象的还要美妙。"
    translate None illranveras_scene3_0054:
        "他们的手依然轻柔相连，伊尔兰紧握着对他而言最重要的人—那个他愿意为之放弃一切的人。"
    translate None illranveras_scene3_0055:
        "这个吻细腻而甜蜜，夹杂着激情与渴望。透过窗户的月光照亮他们的身影，用清冷的光线勾勒出轮廓。"
    translate None illranveras_scene3_0056:
        "维拉斯抬手，指尖轻抚过伊尔兰的胸膛。伊尔兰因此而颤抖。"
    translate None illranveras_scene3_0057:
        "他温柔地抚摸着维拉斯的脸，无法摆脱这就像一场梦的预感—仿佛睁开眼睛维拉斯就会消失。"
    translate None illranveras_scene3_0058:
        "就在这时—"

    play sound "sounds/sfx/knock.ogg" fadeout 1.0

    scene bg sv room night:
        xpos 0.51 ypos 1.15 xanchor 0.5 yanchor 1.0 zoom 1.15
    show illran n dim armsdown emb at slightright
    show veras n dim emb1 at slightleft
    with vpunch
    translate None illranveras_scene3_0059:
        iv "啊！"
    translate None illranveras_scene3_0060:
        i "...."
    translate None illranveras_scene3_0061:
    #show illran n dim sad with dis
        i "…怎么了？"
    translate None illranveras_scene3_0062:
        "两人猛然分开，心跳比以往任何时候都剧烈。伊尔兰揉着后脑勺移开视线，尴尬地试图找些话来说。"
    translate None illranveras_scene3_0063:
        imn "我再也无法逃避了，我…我…"

    stop music fadeout 3.0
    window hide dissolve

    scene bg forestnight with Fade(1.0, 1.0, 1.0):
        xpos 0.23 ypos 1.42 xanchor 0.5 yanchor 1.0 zoom 1.57
        linear 35.0 xpos 0.78 ypos 1.42 xanchor 0.5 yanchor 1.0 zoom 1.57
    window show dissolve
    play music "sounds/bgm/night.ogg" fadein 4.0
    translate None illranveras_scene3_0064:
        "噼啪作响的篝火声穿过茂密的树林，两名男子蜷缩在熊熊火焰旁。"
    translate None illranveras_scene3_0065:
        "伊尔兰又扔了几根木柴进去，火焰欢快地咆哮起来。"
    translate None illranveras_scene3_0066:
        "这两人结伴旅行才不过几个月时间。维拉斯是神明，而伊尔兰是赏金猎人。"
    translate None illranveras_scene3_0067:
        "他们开始时磕磕绊绊，但渐渐地发现彼此竟有不少共同点。自那以后，他们相处得很愉快。"
    translate None illranveras_scene3_0068:
        iy sad "又要在野外过夜了。真可悲，我居然开始习惯了。"
    translate None illranveras_scene3_0069:
        v neu "也许我们该置办一辆马车。"
    translate None illranveras_scene3_0070:
        iy smi "呵，到头来不过是增加拖累的重量罢了。"
    translate None illranveras_scene3_0071:
        "伊尔兰用细长的树枝拨弄着火堆，陷入沉思。"
    translate None illranveras_scene3_0072:
        iy neu "知道吗，你对我来说仍是个谜。我们相处数月，你却从未谈及自己。"
    translate None illranveras_scene3_0073:
        v sur "你也从没问过。若想知道什么，我都会告诉你。"
    translate None illranveras_scene3_0074:
        iy sad "我只是对你的成长经历有点好奇。"
    translate None illranveras_scene3_0075:
        v neu "没什么好说的。我作为人类长大，没觉得自己有何特别。住在乡下的小村庄里。"
    translate None illranveras_scene3_0076:
        iy "你父母是什么样的人？"
    translate None illranveras_scene3_0077:
        v smi "他们善良又充满爱。我再也找不到更好的人了。"
    translate None illranveras_scene3_0078:
        iy "那…你知道的，你真正的父母呢？"
    translate None illranveras_scene3_0079:
        v sur "我…真正的父母？"
    translate None illranveras_scene3_0080:
        iy "你第一世的时候。"
    translate None illranveras_scene3_0081:
        v "...."
    translate None illranveras_scene3_0082:
        v smi "你应该知道我凡世是只鸟吧？"
    translate None illranveras_scene3_0083:
        iy sur "…什么？真的是鸟？"
    translate None illranveras_scene3_0084:
        v "其他神明大多以人类身份生活过，所以你不清楚也难怪。"
    translate None illranveras_scene3_0085:
        iy "那是什么感觉？"
    translate None illranveras_scene3_0086:
        "伊尔兰双手枕着脑袋躺下，仰望繁星密布的天空。维拉斯也照做了。"
    translate None illranveras_scene3_0087:
        v "很自在。不像现在这样忧心忡忡。可以随心所欲地飞往任何地方。"
    translate None illranveras_scene3_0088:
        iy smi "鸟也有父母吧？"
    translate None illranveras_scene3_0089:
        v "哈哈哈，你说得对。它们对我也非常重要。"
    translate None illranveras_scene3_0090:
        v "你呢？"
    translate None illranveras_scene3_0091:
        iy sad"...."
    translate None illranveras_scene3_0092:
        v sad "如果让你不适可以不用回答。"
    translate None illranveras_scene3_0093:
        iy neu "不，这很公平。毕竟你回答了我的问题。"
    translate None illranveras_scene3_0094:
        iy smi "…我母亲是这世上最美好的女人。她意志坚强，有时甚至固执，但充满慈悲心肠。"
    translate None illranveras_scene3_0095:
        v sur "「曾经」是？"
    translate None illranveras_scene3_0096:
        iy sad "….她去世了。"
    translate None illranveras_scene3_0097:
        v sad "节哀顺变。"
    translate None illranveras_scene3_0098:
        iy "直到生命的最后一刻，她都在祈祷。即便病情日渐沉重，她仍未停止。"
    translate None illranveras_scene3_0099:
        iy "但她并非为自己祷告。她是在为我祈求。"
    translate None illranveras_scene3_0100:
        iy "…我当时太愚蠢了。天真得可笑。我觉得她完全不可理喻。我嘲笑她和她的信仰。心想\"如果神明任由你病成这样，祈祷还有什么意义\"。"
    translate None illranveras_scene3_0101:
        v "所以这就是我们初见时你说那些话的原因…"
    translate None illranveras_scene3_0102:
        iy "…对不起。我当时…充满怒火…只想把责任推给任何人。"
    translate None illranveras_scene3_0103:
        iy "…但错的是我。我竟用怨恨糟蹋了她最后的时光。"
    translate None illranveras_scene3_0104:
        "一缕轻柔的重量落在伊尔兰胸口。低头看去，是蜜桃色的发丝。维拉斯伸手环住伊尔兰，轻轻收紧臂弯。"
    translate None illranveras_scene3_0105:
        v "不是你的错，伊尔兰。"
    translate None illranveras_scene3_0106:
        "尚未察觉时，泪水已充盈眼眶，顺着脸颊滚落。"
    translate None illranveras_scene3_0107:
        iy "她值得比我更好的儿子。我好想她，维拉斯。想得心都疼了。"
    translate None illranveras_scene3_0108:
        v "…你是个善良的人，伊尔兰。相信你母亲仍在某处守望着你，并以你为荣。"
    translate None illranveras_scene3_0109:
        "维拉斯将头靠在伊尔兰胸前，哼起轻柔的曲调。"
    translate None illranveras_scene3_0110:
        "伊尔兰闭目聆听着维拉斯的慢歌，回应着环抱住对方。两人就这样相拥着度过余夜—沉浸在令人安心的怀抱里。"


    scene bg sv room night:
        xpos 0.51 ypos 1.15 xanchor 0.5 yanchor 1.0 zoom 1.15
    show illran n dim armsdown emb at slightright
    show veras n dim emb1 at slightleft
    with Fade(1.0, 1.0, 1.0)
    translate None illranveras_scene3_0111:
        imn "….我爱他。这份感情已经持续了很久很久。"
    translate None illranveras_scene3_0112:
        i "我该…我该走了…反正你也有访客了。"
    translate None illranveras_scene3_0113:
        show veras n dim sad1 with dis
        v "伊尔兰—"
    translate None illranveras_scene3_0114:
        "没等听清维拉斯的话语，伊尔兰已冲出房门。撞见满脸错愕的埃利奥特，却未作停留便匆匆离去。"
    stop music fadeout 2.0
    jump veraselliot



    #
