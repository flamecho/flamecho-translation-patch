label fawnsecretvillage1:
    scene bg sv night with Fade(1.0, 1.0, 1.0)
    window show dissolve
    translate None fawn_chapter4_0001:
        "福恩确认外面没有人后，悄悄溜出了几分钟前刚被安置的房间。他迅速沿着原路返回埃利奥特的住所，敲响了门。"
    translate None fawn_chapter4_0001b:
        play music "sounds/bgm/forgotten off.ogg"
    translate None fawn_chapter4_0002:
        "无人应答。"
    translate None fawn_chapter4_0003:
        "叹了口气，他转身准备离开，却迎面撞上了正主。"
    translate None fawn_chapter4_0004:
        "不过说\"迎面\"可能有些夸张。更准确的描述是脸对胸膛。"


    show fawn nw dark cloak sur at slightleft
    show elliot n dark neu at slightright
    with dissolve
    translate None fawn_chapter4_0005:
        f "啊！"
    translate None fawn_chapter4_0006:
        el "……是那个蓝皮肤的。福恩？"
    translate None fawn_chapter4_0007:
        f "……是的，是我。"
    translate None fawn_chapter4_0008:
        show elliot dark gla with dis
        el "你来这里做什么？去休息吧。"
    translate None fawn_chapter4_0009:
        show fawn nw dark neu with dis
        f "我是来找你谈话的。"
    translate None fawn_chapter4_0010:
        el "....."
    translate None fawn_chapter4_0011:
        show fawn nw dark emb with dis
        f "我……如果你有空的话。"
    translate None fawn_chapter4_0012:
        "福恩结结巴巴地说着，面前站着个块头足有他三倍的男人。"
    translate None fawn_chapter4_0013:
        el "来吧，陪我走走。我为你腾出时间。"
    translate None fawn_chapter4_0014:
        "当福恩与埃利奥特并肩而立时，他简直像个孩子。不仅是身高差异，体型气质也截然不同。"
    translate None fawn_chapter4_0015:
        el "所以，你找我到底想说什么？记住，我的答案不会改变。"
    translate None fawn_chapter4_0016:
        show fawn nw dark neu with dis
        f "……我想知道你为何拒绝帮助我们。"
    translate None fawn_chapter4_0017:
        el "我之前的回答还不够明确吗？这些人—"
    translate None fawn_chapter4_0018:
        f "本应是我们敬仰的神明。"
    translate None fawn_chapter4_0019:
        el "你不会明白的。我也没指望你理解。"
    translate None fawn_chapter4_0020:
        f "那就解释给我听。说说你自己，为何帮忙的可能性完全不存在。"
    translate None fawn_chapter4_0021:
        el "....."
    translate None fawn_chapter4_0022:
        "在埃利奥特直白严肃的注视下，福恩感到浑身僵硬，但他没有逃跑或后退。"
    translate None fawn_chapter4_0023:
        el "有胆量，这点我承认。好吧，就陪你聊聊。"
    translate None fawn_chapter4_0024:
        show elliot dark sad with dis
        el "你亲眼见过战争带来的毁灭吗？目睹过相伴一生的战友像蝼蚁般死去吗？"
    translate None fawn_chapter4_0025:
        el "可曾肩负整个世界的重量却最终失败？"
    translate None fawn_chapter4_0026:
        show fawn nw dark sad with dis
        f "……不，我没有。"
    translate None fawn_chapter4_0027:
        el "所以你永远无法理解。"
    translate None fawn_chapter4_0028:
        show elliot dark neu with dis
        el "我曾是颗耀眼将星—在锡德卡汉军队中平步青云的统帅，仿佛天生就该如此。"
    translate None fawn_chapter4_0029:
        show fawn nw dark neu with dis
        f "我看过你的雕像。那里的人民至今仍对你推崇备至。"
    translate None fawn_chapter4_0030:
        el "对他们而言，我不过是反抗神明压迫的自由象征。但那不是我。"
    translate None fawn_chapter4_0031:
        el "从来都不是我想成为的样子。我只是想守护家园，坚持正义。"
    translate None fawn_chapter4_0032:
        el "当时摆脱那个密谋对抗我们国王的神圣演说者，似乎是对的。"
    translate None fawn_chapter4_0033:
        f "你现在还这么认为吗？"
    translate None fawn_chapter4_0034:
        show elliot dark gla with dis
        el "我不认为现在还那么容易判断对错了。"
    translate None fawn_chapter4_0035:
        el "无论我活了多少年，总有一段记忆如此根深蒂固，如此深刻烙印在我脑海中，以至于任何战斗的念头都不复存在。"
    translate None fawn_chapter4_0036:
        el "我曾站在一群惊恐的士兵面前。这些士兵渴望母亲烹饪的温暖，渴望一个不需要铭文的生活。年轻、易受影响、充满恐惧。"
    translate None fawn_chapter4_0037:
        show elliot dark sad with dis
        el "你知道我怎么对他们说的吗？我告诉他们可能活不下去，许多人会死去，但这样做能拯救他们所爱之人的生命。"
    translate None fawn_chapter4_0038:
        el "他们欢呼我的名字，为我的话语而战—也为这些话而死。"
    translate None fawn_chapter4_0039:
        el "…那些他们誓死保护的爱人们，很多也难逃一死。"
    translate None fawn_chapter4_0040:
        show fawn nw dark sad with dis
        f "....."
    translate None fawn_chapter4_0041:
        show elliot dark hur with dis
        el "正如我告诉他们的一样，但当我躺在最后的战场上流血时，我才惊觉他们有多么恐惧。"
    translate None fawn_chapter4_0042:
        el "我不会再带领任何人走向死亡，永远不会了。"
    translate None fawn_chapter4_0043:
        f "…对你的损失我感到抱歉。没有人应该经历这种事。"
    translate None fawn_chapter4_0044:
        show elliot dark neu with dis
        el "那么你应该理解为什么我不会对这些人做同样的事。在他们眼中，我看到了那些被我害死的年轻恐惧士兵的影子。"
    translate None fawn_chapter4_0045:
        show fawn nw dark neu with dis
        f "....."
    translate None fawn_chapter4_0046:
        f "所以，你在害怕。"
    translate None fawn_chapter4_0047:
        el "承认恐惧并不可耻。"
    translate None fawn_chapter4_0048:
        f "当然不。我这一生都在恐惧。从导致父母死亡的那天离家出走，到十年后重新踏入文明社会。"
    translate None fawn_chapter4_0049:
        f "我以为自己做不到。旅途中有无数次我只想逃跑，回家假装什么都没发生过。"
    translate None fawn_chapter4_0050:
        show fawn nw dark sad with dis
        f "但…这次我不能逃避。有时候即使害怕也必须向前一步。"
    translate None fawn_chapter4_0051:
        el "他们的生命不该由我来挥霍。他们不在乎人类城市发生了什么—"
    translate None fawn_chapter4_0052:
        f "那只是借口。他们都在害怕。害怕被那些他们暗自渴望重新崇拜自己的人排斥。"
    translate None fawn_chapter4_0053:
        el "也许你是对的，但是—"
    translate None fawn_chapter4_0054:
        f "没有但是。"
    translate None fawn_chapter4_0055:
        el "....."
    translate None fawn_chapter4_0056:
        el "我不是铁石心肠。想到有人威胁这么多人的生命，我内心当然很沉重。福恩，我不喜欢战争，但我所做的一切，是为了让别人能过上我永远无法拥有的和平生活。"
    translate None fawn_chapter4_0057:
        f "那就认真考虑这件事吧，因为整个世界都会受到卢修斯的影响。"
    translate None fawn_chapter4_0058:
        el "好吧。我答应会考虑，但仅此而已。"
    translate None fawn_chapter4_0059:
        el "来，坐我旁边一会儿。"
    translate None fawn_chapter4_0060:
        show fawn nw dark sur with dis
        f "在雪地里…？"
    translate None fawn_chapter4_0061:
        "埃利奥特跪倒在地，轻轻闭上眼睛。"
    translate None fawn_chapter4_0062:
        el "冥想。有助于理清思绪。"
    translate None fawn_chapter4_0063:
        f "....."
    translate None fawn_chapter4_0064:
        show fawn nw dark neu with dis
        "福恩模仿他的动作，当他跪在埃利奥特身旁时，积雪在他身下发出嘎吱声响。"
    translate None fawn_chapter4_0065:
        "当他闭上眼睛，他看到了一段永远无法忘却的过去，和一个不久前还觉得遥不可及，如今却触手可及的未来。"
    translate None fawn_chapter4_0066:
        f "你看到了什么？"
    translate None fawn_chapter4_0067:
        el "我看到一片青翠的草地，深藏在山谷中。一栋房子，我亲手搭建的，虽小而简陋，却是个可以称之为家的地方。"
    translate None fawn_chapter4_0068:
        el "我看到一排排苹果树，和简单的生活。"
    translate None fawn_chapter4_0069:
        f "…这仍然可能实现，但前提是我们必须解决卢修斯的问题。"
    translate None fawn_chapter4_0070:
        el "你还真是执着啊。"
    translate None fawn_chapter4_0071:
        f "我觉得你表面强硬，但内心十分柔软。"
    translate None fawn_chapter4_0072:
        show elliot dark sad with dis
        el "我得说我不习惯被人这样剖析。"
    translate None fawn_chapter4_0073:
        el "你知道吗，我不想被困在这里。我梦想着漫游维迪斯，寻找我失散的朋友们。"
    translate None fawn_chapter4_0074:
        f "那是什么阻拦了你？"
    translate None fawn_chapter4_0075:
        el "当神明化身为人时，据说会失去最珍贵的东西。对某些人而言是视力。对其他人则是手臂，或双腿。任何让你无法继续从事昔日闻名之事的东西。"
    translate None fawn_chapter4_0076:
        el "很残酷，不是吗？"
    translate None fawn_chapter4_0077:
        el "对我来说，这意味着阳光会杀死我。很奇怪吧？你会以为他们会夺走我的声音才对。"
    translate None fawn_chapter4_0078:
        show fawn nw dark sad with dis
        f "…所以你才留在这里？"
    translate None fawn_chapter4_0079:
        show elliot dark neu with dis
        el "如果走得太远，我就会陷入危险。如果我以野兽形态游历—所有神明都能做到这点—又会遭到人类追猎。"
    translate None fawn_chapter4_0080:
        el "不过别误会。我留在这里是因为这些人需要我。"
    translate None fawn_chapter4_0081:
        show fawn nw dark neu with dis
        f "你曾是位高明的战术家和演说家，对吧？"
    translate None fawn_chapter4_0082:
        el "我很认真。"
    translate None fawn_chapter4_0083:
        show fawn nw dark smi with dis
        f "那一定是哪里出错了，因为我看出你骨子里仍具备再次做到的能力。"
    translate None fawn_chapter4_0084:
        "福恩羞涩地微笑，埃利奥特唇角隐约浮现一丝弧度。"
    translate None fawn_chapter4_0085:
        show elliot dark smi with dis
        el "那么，或许真正被夺走的是我的自信。"
    translate None fawn_chapter4_0086:
        f "..."
    translate None fawn_chapter4_0087:
        f "其实我来找你谈话还有另一个原因。"
    translate None fawn_chapter4_0088:
        show elliot dark neu with dis
        el "还有别的事？"
    translate None fawn_chapter4_0089:
        f "..."
    translate None fawn_chapter4_0090:
        show fawn nw dark sad with dis
        f "我知道这里任何人都能问…但你身上让我感受到某种特别的东西。"
    translate None fawn_chapter4_0091:
        "福恩抬起手臂，将手掌摊开在埃利奥特面前。顷刻间，一簇火苗在他掌心跃动，宛如拥有自我意识般跳动。"
    translate None fawn_chapter4_0092:
        "转瞬之间，火光便消失无踪。"
    translate None fawn_chapter4_0093:
        show elliot dark gla with dis
        el "......."
    translate None fawn_chapter4_0094:
        "埃利奥特猛地从雪地上站起，拽着福恩让他也站起来，脸上写满难以置信。"
    translate None fawn_chapter4_0095:
        show fawn nw dark neu with dis
        f "我想知道这意味着什么。我身上到底出了什么问题？"
    translate None fawn_chapter4_0096:
        el "你从什么时候开始能这么做的？"
    translate None fawn_chapter4_0097:
        f "从…十年前开始。"
    translate None fawn_chapter4_0098:
        el "在你离家出走，造成父母死亡之后…我想我开始明白为何会对你产生共鸣了。"
    translate None fawn_chapter4_0099:
        show fawn nw dark sad with dis
        f "我在睡梦中几乎点燃了整个村庄。人人都称我为恶魔。"
    translate None fawn_chapter4_0100:
        show elliot dark neu with dis
        el "如此毁灭性，却又如此美丽…潜力惊人。现在能控制它吗？"
    translate None fawn_chapter4_0101:
        f "不。我太害怕了，从不敢尝试学习。它只是不断提醒我犯下的罪孽。"
    translate None fawn_chapter4_0102:
        el "我从未见过这种情况。说实话，甚至没听说过类似案例。无论怎么看，你都是人类，然而…"
    translate None fawn_chapter4_0103:
        show fawn nw dark sur with dis
        f "我不是恶魔？"
    translate None fawn_chapter4_0104:
        el "若真是恶魔，你会知道的。你绝对是凡人之躯。"

    window hide dissolve


    scene bg sv night
    show raen nw dark cloak sad at slightleft
    show morwen n dark cloakup wor at slightright
    with Fade(1.0, 1.0, 1.0)
    window show dissolve
    translate None fawn_chapter4_0105:
        mor "你在担心他什么？"
    translate None fawn_chapter4_0106:
        rs "…他很痛苦，而我却无能为力。"
    translate None fawn_chapter4_0107:
        mor "他总显得…像是害怕着什么。"
    translate None fawn_chapter4_0108:
        rs "他的过去。"
    translate None fawn_chapter4_0109:
        mor "发生了什么…？"
    translate None fawn_chapter4_0110:
        "我低声复述了福恩童年的故事。"
    translate None fawn_chapter4_0111:
        show morwen sad with dis
        mor "......."
    translate None fawn_chapter4_0112:
        mor "所以他姐姐又出现了…对他肯定很难熬。能有你这样的支持者在身边是他的幸运。"
    translate None fawn_chapter4_0113:
        show morwen neu with dis
        mor "眼下我们必须先找到他。有些事我想确认。"
    translate None fawn_chapter4_0114:
        show raen nw neu with dis
        rs "什么…？现在？他应该还在房间里。"
    translate None fawn_chapter4_0115:
        "她拽着我起身，拖我回到为福恩准备的房间。敲门无人应答。"
    translate None fawn_chapter4_0116:
        "又等了片刻，莫温轻轻推开门，但室内空无一人。"
    translate None fawn_chapter4_0117: # missing line
        show raen nw sur with dis
        rs "他会去哪里呢？"
    translate None fawn_chapter4_0118:
        show morwen wor with dis
        "我努力平复砰砰直跳的心脏。"
    translate None fawn_chapter4_0119:
        "没事的…他不会就这样离开的，对吧？一定只是出去透透气！"
    translate None fawn_chapter4_0120:
        "莫温再次抓住我的手臂，我们开始在村庄里寻找。哪儿都不见他的踪影。"
    translate None fawn_chapter4_0121:
        mor "…他该不会是逃跑了吧…？"
    translate None fawn_chapter4_0122:
        rs "..."
    translate None fawn_chapter4_0123:
        el gla "若真是恶魔，你会知道的。你绝对是凡人之躯。"
    translate None fawn_chapter4_0124:
        show morwen sur with dis
        mor "...!"
    translate None fawn_chapter4_0125:
        "拐过街角时，我们与两个人迎面相遇。埃利奥特的目光迅速瞥向我们，又转回福恩身上。"

    show morwen at cenleft
    show raen at farleft
    with move
    show fawn nw dark cloak sur at cenright
    show elliot n dark neu at farright
    with dissolve
    translate None fawn_chapter4_0126:
        mor "福恩，还有…埃利奥特。看来你们先我一步。"
    translate None fawn_chapter4_0127:
        show raen nw dark neu with dis
        f "...?"
    translate None fawn_chapter4_0128:
        show morwen dark smi with dis
        mor "相信我一次，福恩。把手给我。"
    translate None fawn_chapter4_0129:
        show fawn nw dark neu with dis
        "他怯生生地让莫温握住他的手，她轻轻刺破他的手指。将渗血的手指举到唇边尝了尝。"
    translate None fawn_chapter4_0130:
        f "你在干什么？"
    translate None fawn_chapter4_0131:
        mor "果然如我所料。"
    translate None fawn_chapter4_0132:
        show morwen dark neu with dis
        mor "在你的家族血脉中，有位你可能毫不知情的先祖。一位神明。"
    translate None fawn_chapter4_0133:
        mor "他们的神血有一滴流淌在你的血管里，如今已然苏醒。你就是我们所说的…半神。"
    translate None fawn_chapter4_0134:
        show raen nw dark sur with dis
        show fawn nw dark sur with dis
        fr "什么…？"
    translate None fawn_chapter4_0135:
        show morwen dark sur with dis
        mor "我从没见过这种情况…要知道，神明通常无法繁衍后代…"
    translate None fawn_chapter4_0136:
        mor "你是个奇迹。"
    translate None fawn_chapter4_0137:
        f "....."
    translate None fawn_chapter4_0138:
        f "奇…奇迹…？从来没人这么称呼过我。"
    translate None fawn_chapter4_0139:
        show morwen dark neu with dis
        mor "听说你还不能控制自己的能力，但我保证…经过训练，你一定能做到。"
    translate None fawn_chapter4_0140:
        "福恩抬头望向埃利奥特，对方也正俯视着他。"
    translate None fawn_chapter4_0141:
        el "嗯…有意思。"
    translate None fawn_chapter4_0142:
        f "..."
    translate None fawn_chapter4_0143:
        f "雷恩，莫温，能再给我点时间吗？我保证很快就来找你们。"
    translate None fawn_chapter4_0144:
        rs "....."
    translate None fawn_chapter4_0145:
        "我忧虑地看着埃利奥特。虽然莫温不信任他，但是…"
    translate None fawn_chapter4_0146:
        "如果这是福恩的意愿。"


    hide morwen
    hide raen
    with dissolve

    show fawn at slightleft
    show elliot at slightright
    with move
    translate None fawn_chapter4_0147:
        "雷恩和莫温默默离开，再次留下福恩与埃利奥特独处。少年仰望着高个子男人的脸庞，眼中闪过一丝坚毅。"
    translate None fawn_chapter4_0148:
        show fawn nw neu with dis
        f "我想请你教我控制能力的方法。"
    translate None fawn_chapter4_0149:
        el "凭什么认为我能教你？你可以求助的神明多的是。"
    translate None fawn_chapter4_0150:
        f "因为我信任你，而且从谈话中就能看出你是个好人。"
    translate None fawn_chapter4_0151:
        el "那就留下吧。"
    translate None fawn_chapter4_0152:
        show fawn nw dark sur with dis
        f "留下…？"
    translate None fawn_chapter4_0153:
        el "如果你真心想学会掌控，就别指望一蹴而就。"
    translate None fawn_chapter4_0154:
        f "..."
    translate None fawn_chapter4_0155:
        show fawn nw dark neu with dis
        f "那就帮助我们。让我们向你证明值得你这样做。"
    translate None fawn_chapter4_0156:
        f "我就是神与人之间存在联系的最好证明。"
    translate None fawn_chapter4_0157:
        el "…我说过会考虑的，不是吗？"
    translate None fawn_chapter4_0158:
        el "去休息吧，小福恩。我会判断这份羁绊是否足够。"
    translate None fawn_chapter4_0159:
        hide elliot
        hide fawn
        with dissolve
        "埃利奥特悄悄溜进了阴影中，仿佛与夜色融为一体。带着心头沉甸甸的新发现，福恩回到了雷恩和莫温身边。"


    window hide dissolve


    scene bg sv night with Fade(1.0, 1.0, 1.0)
    window show dissolve

    show raen nw dark cloak sad at slightleft
    show morwen n dark cloakup wor at slightright
    with dissolve
    translate None fawn_chapter4_0160:
        mor "我很好奇他们两个在谈什么…"
    translate None fawn_chapter4_0161:
        rs "我也想知道…"


    show raen nw at center
    show morwen at right
    with move

    show fawn nw dark neu cloak at left with dissolve
    translate None fawn_chapter4_0162:
        f "没什么。我只是想和他谈谈。"
    translate None fawn_chapter4_0163:
        show raen sur with dis
        rs "福恩！你还好吗？"
    translate None fawn_chapter4_0164:
        show fawn smi with dis
        f "实际上…我从没感觉这么好过。"
    translate None fawn_chapter4_0165:
        show morwen n smi with dis
        mor "…你们两个一定累坏了。去休息吧。我们明天再详谈。"
    translate None fawn_chapter4_0166:
        "仅从福恩的一瞥我就能看出他不想争辩。一夜安眠对我们都有好处。"
    translate None fawn_chapter4_0167:
        "正当我转身离开时，注意到有人站在与我们保持距离的地方。当目光交汇时，他怯生生地挥了挥手。"
    translate None fawn_chapter4_0168:
        f "…要不我先回去，给你们俩独处的时间？"
    translate None fawn_chapter4_0169:
        rs "你确定这样可以吗？"
    translate None fawn_chapter4_0170:
        show morwen dark smi with dis
        mor "去吧。去跟他谈谈。"


    jump caspianraen

label fawnsvnightaftercas:

    hide raen
    hide caspian
    with dissolve
    stop music fadeout 2.0
    translate None fawn_chapter4_0171:
        "终于独处时，我沿着几分钟前看到福恩和莫温离去的方向，开始返回自己的房间。"
    translate None fawn_chapter4_0172:
        "最终找到了房间，推开木门。走进去发现福恩正坐在床上等我。"


    window hide dissolve
    scene bg sv room night with dissolve
    window show dissolve

    show raen nw sur at slightleft
    show fawn nw neu blush at slightright
    with dissolve
    play music "sounds/bgm/night.ogg"
    translate None fawn_chapter4_0173: # NSFW 2 STARTS HERE
        rs "…嘿。"
    translate None fawn_chapter4_0174:
        f "你们俩有机会好好谈谈了吗？"
    translate None fawn_chapter4_0175:
        show raen nw smi with dis
        rs "谈过了。谢谢你，福恩。我…真的很想有机会了解他。"
    translate None fawn_chapter4_0176:
        show fawn nw smi with dis
        f "他看起来是个好人。你们长得真像，是吧？"
    translate None fawn_chapter4_0177:
        show raen nw sur with dis
        rs "怎么，准备把我晾在一边去追我爸了？"
    translate None fawn_chapter4_0178:
        show raen nw smi with dis
        "我笑了起来，跌跌撞撞穿过黑暗的房间，直到瘫倒在床上。虽然床铺老旧，但经历这一天的种种后，它看起来宛若天堂。"
    translate None fawn_chapter4_0179:
        "福恩在我身旁躺下。我们盯着天花板，福恩笑出了声。"
    translate None fawn_chapter4_0180:
        f "才不呢！不过…他确实挺帅的，对吧？"
    translate None fawn_chapter4_0181:
        "随着房间里大象越来越明显，沉默笼罩着我们。我回想着莫温对福恩的评价。"
    translate None fawn_chapter4_0182:
        show raen nw neu with dis
        "该怎么提起这件事…"
    translate None fawn_chapter4_0183:
        "我想我还是直说吧。"
    translate None fawn_chapter4_0184:
        rs "....."
    translate None fawn_chapter4_0185:
        show fawn nw neu -blush with dis
        f "........"
    translate None fawn_chapter4_0186:
        rs "所以，你算是跟神明沾亲带故咯？"
    translate None fawn_chapter4_0187:
        f "而你是言者。"
    translate None fawn_chapter4_0188:
        f "你觉得这就是我们互相吸引的原因吗？"
    translate None fawn_chapter4_0189:
        show raen nw smi with dis
        rs "..."
    translate None fawn_chapter4_0190:
        rs "不是。"
    translate None fawn_chapter4_0191:
        show fawn nw sur with dis
        f "不是？"
    translate None fawn_chapter4_0192:
        rs "我被你吸引，因为你如此出众、可爱，在各个方面都完美得无可挑剔。我最终成为言者而你拥有一滴神血或者其他什么，这些都无关紧要。"
    translate None fawn_chapter4_0193:
        show fawn nw smi with dis
        f "你说得真肉麻。"
    translate None fawn_chapter4_0194:
        rs "抱歉，我保证正在努力改进调情技巧。请再多包容我一会儿。"
    translate None fawn_chapter4_0195:
        f "不需要改变。现在的你就很好。"
    translate None fawn_chapter4_0196:
        show fawn nw neu with dis
        f "….其实我很害怕。"
    translate None fawn_chapter4_0197:
        show raen nw neu with dis
        rs "我也是。"
    translate None fawn_chapter4_0198:
        f "我害怕…但如果说掌握火焰意味着能保护你，我会学会控制它。"
    translate None fawn_chapter4_0199:
        "我抬手触碰仍在隐隐作痛的伤口。"
    translate None fawn_chapter4_0200:
        rs "我也想学会控制自己的能力。即便它并不那么实用。"
    translate None fawn_chapter4_0201:
        show raen nw smi with dis
        rs "我可不是什么火焰半神，这点很确定。"
    translate None fawn_chapter4_0202:
        show fawn nw emb with dis
        f "哦，闭嘴。我没什么特别的。"
    translate None fawn_chapter4_0203:
        rs "真的吗？对我来说你非常特别。"
    translate None fawn_chapter4_0204:
        show fawn nw neu with dis
        f "..."
    translate None fawn_chapter4_0205:
        "突然，福恩的面容占据了我全部视线。他坐起身，此刻正俯身笼罩着我。他神情肃穆，不见往日的局促与羞赧。"
    translate None fawn_chapter4_0206:
        "我抬手捧住他的双颊。"
    translate None fawn_chapter4_0207:
        rs "我爱你。"
    translate None fawn_chapter4_0208:
        "他没有回答，只是俯身吻住我。这个吻缓慢、安宁、充满爱意。"
    translate None fawn_chapter4_0209:
        show fawn nw smi with dis
        f "我也爱你。"
    translate None fawn_chapter4_0210:
        f "尽管经历了这么多…我依然非常…非常庆幸遇见你。我想我生来就是为了找到你。"
    translate None fawn_chapter4_0211:
        rs "现在是谁在说老套台词了？"
    translate None fawn_chapter4_0212:
        show fawn nw emb with dis
        f "哦，闭嘴啦…"
    translate None fawn_chapter4_0213:
        "我双手勾住他的脖子，将他拉下来再次亲吻，我们的身体紧紧相贴。"
    translate None fawn_chapter4_0214:
        "房间或许冰冷，但他的体温立即让我温暖起来。"
    translate None fawn_chapter4_0215:
        hide fawn
        hide raen
        with dissolve
        "很快这个吻就变得热烈，我的手滑下他的脊背，隔着衣物感受他肌理的轮廓。"
    translate None fawn_chapter4_0216:
        "说实话仍令人惊讶。他确实蕴藏着力量。"
    translate None fawn_chapter4_0217:
        stop music fadeout 3.0
        rs wemb "福恩…"
    translate None fawn_chapter4_0218:
        f wemb "我…那个…我…"
    translate None fawn_chapter4_0219:
        play music "sounds/bgm/sex.ogg" fadein 4.0
        "他结结巴巴地说，那张我熟悉又喜爱的脸上又泛起福恩特有的红晕。"
    translate None fawn_chapter4_0220:
        f "我…带了…那个…"
    translate None fawn_chapter4_0221:
        rs wsur "哪个…？"
    translate None fawn_chapter4_0222:
        f "就..就是那个啊…！"
    translate None fawn_chapter4_0223:
        rs wsmi "嗯？再说是哪个呢？"
    translate None fawn_chapter4_0224:
        f "..."
    translate None fawn_chapter4_0225:
        f "你在捉弄我对吧？"
    translate None fawn_chapter4_0226:
        rs "或许有一点。我发现自己开始喜欢这样了。"
    translate None fawn_chapter4_0227:
        f wsmi"唔，那或许我也该试试？"
    translate None fawn_chapter4_0228:
        "他凝视着我的眼睛，手顺着我的身体滑下，而后隔着裤子抚上我的敏感处。"
    translate None fawn_chapter4_0229:
        rs wemb "呃…喂，这样有点不公平啊…"
    translate None fawn_chapter4_0230:
        f "哦？你不喜欢我这样碰你吗？"
    translate None fawn_chapter4_0231:
        rs "当然喜欢…！"
    translate None fawn_chapter4_0232:
        f "很好。那具体来说，你想让我怎么做？"
    translate None fawn_chapter4_0233:
        rs "..."
    translate None fawn_chapter4_0234:
        f "只要你愿意，我可以为你做些非常美妙的事。"
    translate None fawn_chapter4_0235:
        "他沙哑的嗓音几乎微不可闻，从我上方贴着耳朵低语。手指开始游走，抚弄我已经挺立的部位。"
    translate None fawn_chapter4_0236:
        rs "啊…是…是吗…？"
    translate None fawn_chapter4_0237:
        f "怎么说？相信我么？"
    translate None fawn_chapter4_0238:
        rs "是的。"
    translate None fawn_chapter4_0239:
        f "很好。"
    translate None fawn_chapter4_0240:
        "他眼里闪着光，慢慢剥离我层叠的衣物，直到下半身几乎完全赤裸。沿着大腿向上亲吻，指尖勾住内裤边缘。"
    translate None fawn_chapter4_0241:
        "福恩轻咬着我的胯骨，我感到脸上发烫。每次双唇触碰皮肤都羞耻得要命。"
    translate None fawn_chapter4_0242:
        "这到底怎么回事？！"
    translate None fawn_chapter4_0243:
        "一个利落的动作后，我彻底赤裸。他迅速将我握在手中，从各个角度欣赏。"
    translate None fawn_chapter4_0244:
        f wsur "已经这么硬了…"
    translate None fawn_chapter4_0245:
        rs "好了好了，知道了，不逗你了！"
    translate None fawn_chapter4_0246:
        f "真的吗？不过我觉得还需要再惩罚一下呢。"
    translate None fawn_chapter4_0247:
        rs "惩罚…？"
    translate None fawn_chapter4_0248:
        "他手掌完全包裹住半硬的性器开始缓慢套弄，然后…"
    translate None fawn_chapter4_0249:
        "他…"

    window hide dissolve

    scene gallery_165
    if persistent.streamer_mode == True:
        show fawn_second_sex_censor
    with dissolve
    window show dissolve
    translate None fawn_chapter4_0250:
        "俯身用舌尖划过顶端，全程都直视着我的眼睛。"
    translate None fawn_chapter4_0251:
        rs "你干什么？！"
    translate None fawn_chapter4_0252:
        f "…可以吗？"
    translate None fawn_chapter4_0253:
        rs "好…好的…"
    translate None fawn_chapter4_0254:
        f "呃…虽然我现在想表现得性感点…但毕竟是第一次做这种事…"
    translate None fawn_chapter4_0255:
        "他的语气终于显出一丝动摇，声音又紧张起来，但转瞬即逝。"
    translate None fawn_chapter4_0256:
        "平展舌头从根部开始，一路舔舐至顶端。"
    translate None fawn_chapter4_0257:
        rs "嗯…！"
    translate None fawn_chapter4_0258:
        "呻吟声脱口而出，羞得几乎想捂脸，却又挪不开眼。"
    translate None fawn_chapter4_0259:
        "看着福恩这样侍奉我的画面…实在太珍贵了。"
    translate None fawn_chapter4_0260:
        "拼命克制着挺腰的冲动，在他手掌的缓慢套弄和舌尖对顶端的挑弄下，快感如潮水般淹没理智。"
    translate None fawn_chapter4_0261:
        "这感觉超乎所有想象。他的舌头湿热灵巧，每个细微动作都引发全身战栗。"
    translate None fawn_chapter4_0262:
        "福恩对我的反应报以微笑，享受这样戏弄我的感觉。"
    translate None fawn_chapter4_0263:
        "但是戏弄没有持续多久。片刻后，福恩急切地向前倾身，将我的长度含入口中。"
    translate None fawn_chapter4_0264:
        rs "啊..！"
    translate None fawn_chapter4_0265:
        "他缓慢地移动着嘴，享受着每一寸，延长着每一秒。正当我感觉快要因为这美妙感受而爆发时，他突然加快了速度。"
    translate None fawn_chapter4_0266:
        "他口腔的湿润炽热感比之前更加美妙，不知不觉间我的手已经抵在他头顶，抓着他凌乱的蓝发。"
    translate None fawn_chapter4_0267:
        rs "啊，该死…福恩，感觉太棒了…"
    translate None fawn_chapter4_0268:
        f "古伍德。"
    translate None fawn_chapter4_0269:
        rs "不要含着东西…嗯…说话…"
    translate None fawn_chapter4_0270:
        "福恩对着我的阳具发出呻吟，震动感只会带来更多快感。"
    translate None fawn_chapter4_0271:
        "仅是他享受的声音就让我颤抖渴求释放。他将我完全吐出，绕着顶端打转舔舐，又用手戏弄我。"
    translate None fawn_chapter4_0272:
        rs "我..我..啊！我不知道如果你…如果你继续这样…我还能坚持多久…"
    translate None fawn_chapter4_0273:
        f "那么…我会自己做好准备，这样你就能.."
    translate None fawn_chapter4_0274:
        "我低头看着福恩，他的脸涨得通红，呼吸变得断断续续。"
    translate None fawn_chapter4_0275:
        rs "……这次你能对我这么做吗？"
    translate None fawn_chapter4_0276:
        f "什么？"
    translate None fawn_chapter4_0277:
        rs "我…我想知道那是什么感觉…"
    translate None fawn_chapter4_0278:
        f "真的可以吗…？"
    translate None fawn_chapter4_0279:
        "我点点头，饥渴地等待着接下来的事。"
    translate None fawn_chapter4_0280:
        "福恩深吸一口气，好像不确定自己真的被允许这么做，之后又打起精神再次缓慢地套弄我的阳具。"
    translate None fawn_chapter4_0281:
        "同时，他从口袋里掏出一个瓶子。他快速打开瓶盖，将里面的液体淋在我身上。"
    translate None fawn_chapter4_0282:
        "液体沿着我的身体流下，包裹着我的阳具后流到入口处。"
    translate None fawn_chapter4_0283:
        "感觉又冷又滑腻，但这种感觉和他口腔的对比让我颤抖。"
    translate None fawn_chapter4_0284:
        "似乎想要最后一次品尝，他顺着我的大腿一路吻下，然后吮吸着我的长度，他的唾液与润滑液混合在一起。"
    translate None fawn_chapter4_0285:
        scene bg sv room night with dissolve
        "他的手指挑逗着我的边缘，轻轻摩擦着入口处。我惊讶地倒吸一口气，但这感觉并不坏。"
    translate None fawn_chapter4_0286:
        "我没料到的是，在他手指动作的同时，他温暖的舌头也会轻轻压上我的入口。"
    translate None fawn_chapter4_0287:
        "我更没料到的是这会如此美妙。它微微探入，在里面探索着。"
    translate None fawn_chapter4_0288:
        "起初他舌头的温度让我感到陌生，但当那配合着抚摸我阴茎的拳头时，这份触感逐渐转变成灼热而愉悦的体验。"
    translate None fawn_chapter4_0289:
        rs wemb "啊，福恩…"
    translate None fawn_chapter4_0290:
        "回应着我的呻吟，他缓缓滑入一根涂满润滑液的手指。"
    translate None fawn_chapter4_0291:
        "我感到身体骤然紧绷。那个从未被异物侵入的部位此刻正承受着坚硬物体的挤压，这感觉怪异极了。"
    translate None fawn_chapter4_0292:
        "不算疼痛，但绝对超出我的认知范畴。"
    translate None fawn_chapter4_0293:
        f wneu "会疼吗？"
    translate None fawn_chapter4_0294:
        rs "不…不疼…"
    translate None fawn_chapter4_0295:
        "他将嘴唇移向侧边，轻咬着我的大腿，留下令我倒抽凉气的绯红印记。"
    translate None fawn_chapter4_0296:
        "当那根手指终于完全进入后，开始抽插的动作，拓展着我的甬道。"
    translate None fawn_chapter4_0297:
        "最终，那种怪异感消退了，取而代之的是渴求更多的欲望。"
    translate None fawn_chapter4_0298:
        rs "我…我觉得可以再加一根手指了…"
    translate None fawn_chapter4_0299:
        f "..."
    translate None fawn_chapter4_0300:
        "第二根手指进入时我咬住下唇，那种陌生的异物感再度袭来。可每当福恩的手指滑过我的柱身，或是拇指摩擦顶端时，愉悦的喘息便不受控制地溢出。"
    translate None fawn_chapter4_0301:
        "我的阴茎随之脉动，叫嚣着要求释放。看福恩的神情，他也快撑到极限了。"
    translate None fawn_chapter4_0302:
        rs "你…你现在可以放进来了…"
    translate None fawn_chapter4_0303:
        f wemb "…再等等。我想—"
    translate None fawn_chapter4_0304:
        "他说话时弯曲手指，突然顶到某个让我浑身战栗的凸起。快感的浪潮席卷全身，又一声呻吟脱口而出。"
    translate None fawn_chapter4_0305:
        rs "嗯…！"
    translate None fawn_chapter4_0306:
        rs "那个…那是什么…？"
    translate None fawn_chapter4_0307:
        f "找到了。"
    translate None fawn_chapter4_0308:
        "他毫不留情地用指尖碾磨那处，我揪住他头发的力度大得几乎要扯下一把来。"
    translate None fawn_chapter4_0309:
        rs "求…求你了福恩，我太想要你了…！"
    translate None fawn_chapter4_0310:
        "闻言他抽出了手指。分离的每一秒都近乎折磨。"
    translate None fawn_chapter4_0311:
        "最终我凝视着他那根阴茎，看起来既痛苦地勃起着，又比记忆中庞大了许多。"
    translate None fawn_chapter4_0312:
        "或许是因为想到这般巨物即将进入我的身体。"
    translate None fawn_chapter4_0313:
        "…这种想法莫名令人兴奋。"
    translate None fawn_chapter4_0314:
        "福恩被情欲笼罩的面容近在咫尺，他在自己硬挺的性器上倒了更多润滑液，随后对准我的入口。"
    translate None fawn_chapter4_0315:
        "仅仅是龟头抵上来的触感就激起阵阵战栗。如此…粗壮、钝重，却又灼热得惊人。"
    translate None fawn_chapter4_0316:
        "我艰难地咽了下唾沫，准备迎接突如其来的疼痛，但福恩却俯身吻在我的下颌、脸颊和嘴唇上。"
    translate None fawn_chapter4_0317:
        rs "哈啊…"
    translate None fawn_chapter4_0318:
        scene gallery_166
        if persistent.streamer_mode == True:
            show fawn_second_sex_censor2
        with dissolve
        "他以极缓慢的速度开始推进。我因突如其来的疼痛咬住嘴唇，向福恩点头示意继续。"
    translate None fawn_chapter4_0319:
        rs "啊…"
    translate None fawn_chapter4_0320:
        f "还好吗？你…你那里好紧…"
    translate None fawn_chapter4_0321:
        rs "还…还好，就是有点…奇怪…"
    translate None fawn_chapter4_0322:
        "他面带微笑继续深入，最终完全埋入我体内。 "
    translate None fawn_chapter4_0323:
        f "嗯…哈啊…"
    translate None fawn_chapter4_0324:
        rs "全都进去了吗？"
    translate None fawn_chapter4_0325:
        f "差..差不多了…."
    translate None fawn_chapter4_0326:
        "福恩呼吸颤抖着慢慢退出，不断颤动。即使动作如此缓慢，我仍能感受到所有细节。"
    translate None fawn_chapter4_0327:
        "当他再次推进时，我的指甲深深陷入他的肩膀。"
    translate None fawn_chapter4_0328:
        f "我希望你…也能享受…"
    translate None fawn_chapter4_0329:
        "福恩一只手顺着我的身体下滑，抚过裸露的肌肤，潜向两腿之间。"
    translate None fawn_chapter4_0330:
        "他指尖轻触我的阴茎，顺着柱身抚下后握住了根部。"
    translate None fawn_chapter4_0331:
        "渐渐地，不适感消退，取而代之的是我不太理解的灼热欲望。"
    translate None fawn_chapter4_0332:
        "福恩的手掌环握住我，随着抽插的节奏开始套弄。"
    translate None fawn_chapter4_0333:
        "我深吸一口气屏住呼吸，身体终于开始适应体内坚硬的物体。"
    translate None fawn_chapter4_0334:
        "感觉…好深。"
    translate None fawn_chapter4_0335:
        "我在福恩身下扭动，渴求更多。突然觉得这个速度折磨人。不是痛苦的折磨，而是美好得让我只想要更多。"
    translate None fawn_chapter4_0336:
        rs "你可以…嗯…再快点…"
    translate None fawn_chapter4_0337:
        f "你确定？"
    translate None fawn_chapter4_0338:
        "他的动作变得更快，更加热切地撞击我。我们疯狂交缠的吻越来越凌乱炽热，同时承受的抽插和套弄让我开始头晕目眩。"
    translate None fawn_chapter4_0339:
        rs "啊..！"
    translate None fawn_chapter4_0340:
        "当他顶到那个点时，我的后腰从床铺弓起。那个让我眼前发白，从喉咙里逼出呜咽的点。"
    translate None fawn_chapter4_0341:
        "被福恩撑开的感觉几乎让我流泪。不是由于疼痛，而是因为灼热的渴望。"
    translate None fawn_chapter4_0342:
        "不仅是出于渴望，更因那种无论发生什么，福恩都会陪在我身边的确定感。他是那个能与我共度一生，永远相伴的人。"
    translate None fawn_chapter4_0343:
        "和那个人，我们亲密无间，宛若一体。"
    translate None fawn_chapter4_0344:
        "他的抽插变得急促，越来越快越来越用力，喉咙里溢出响亮的呻吟。"
    translate None fawn_chapter4_0345:
        f "我大概撑不了多久了…"
    translate None fawn_chapter4_0346:
        "我的身体渴求解脱，在福恩身下不住颤抖。"
    translate None fawn_chapter4_0347:
        rs "福恩…啊！"
    translate None fawn_chapter4_0348:
        "他的舌缠绕着我的，在福恩的律动中我醺然欲醉。"
    translate None fawn_chapter4_0349:
        rs "我要—！"
    translate None fawn_chapter4_0350:
        scene gallery_166b
        if persistent.streamer_mode == True:
            show fawn_second_sex_censor2
        with hpunch
        "当快感终于决堤时，我的声音哽咽在喉头，我们胸口沾满白浊，福恩以更快速度深入我体内，这感觉将我推向更高处。"
    translate None fawn_chapter4_0351:
        "我紧闭双眼，眼睑后闪烁着绚丽光斑。"
    translate None fawn_chapter4_0352:
        "片刻之后，福恩在我体内释放。那滚烫黏腻的触感惊得我几乎弹跳起来。"
    translate None fawn_chapter4_0353:
        rs "哈啊…福恩…"
    translate None fawn_chapter4_0354:
        f "哈、哈啊…天哪，这感觉…"
    translate None fawn_chapter4_0355:
        rs "太棒了…"
    translate None fawn_chapter4_0356:
        f "你也喜欢吗…？"
    translate None fawn_chapter4_0357:
        rs "特别喜欢。"
    translate None fawn_chapter4_0358:
        f "我没…没想到你会要我…"
    translate None fawn_chapter4_0359:
        rs "为什么不？不问你怎知我男女通吃。我喜欢尝试新鲜事物。"
    translate None fawn_chapter4_0360:
        f "..."
    translate None fawn_chapter4_0361:
        f "为什么连你最纯真的话语听起来都这么下流.."
    translate None fawn_chapter4_0362:
        rs "老天，我现在累坏了。你可真把我折腾惨了。"
    translate None fawn_chapter4_0363:
        f "抱歉…我保证会好好照顾你。"

    window hide dissolve

    show bg sv room night with dissolve
    window show dissolve
    translate None fawn_chapter4_0364:
        "他执起我的手轻吻指节。十指相扣间，他将我从床上拉起与我四目相对。"
    translate None fawn_chapter4_0365:
        rs wsur "嘶…"
    translate None fawn_chapter4_0366:
        f wsad "你还好吗？"
    translate None fawn_chapter4_0367:
        rs wsmi "只是有点疼，但好得不得了。"
    translate None fawn_chapter4_0368:
        "我腼腆地笑着，任由福恩为我清理并掖好被角。完成后他躺在我身侧，凝视我的侧脸。"
    translate None fawn_chapter4_0369:
        f wsmi "你真美…"
    translate None fawn_chapter4_0370:
        rs wsur "美…？谢谢夸奖。"
    translate None fawn_chapter4_0371:
        "我含笑闭眼，再难维持清醒。福恩贴近我，将头枕在我胸前。"
    translate None fawn_chapter4_0372:
        stop music fadeout 2.0
        "就这样，我们相拥入眠。" # NSFW 2 ENDS HERE


    if iv_scene_two and illranveras_friend >= 5:
        jump illranverasscene3

    else:
        jump veraselliot
