label fawnbadending:
    scene bg throne
    show fawn nw dim hur cloak at slightright
    show elliot n dim gla at slightleft
    with Fade(1.0, 1.0, 1.0)
    translate None fawn_badend_0001:
        el "集中注意力！"
    translate None fawn_badend_0002:
        f "我在努力！"
    translate None fawn_badend_0003:
        el "再努力些！把手伸向它。感受指尖的力量。"
    translate None fawn_badend_0004:
        f "什么也没发生！"
    translate None fawn_badend_0005:
        el "是你在掌控局面。火焰听令于你，而不是反过来。"
    translate None fawn_badend_0006:
        f "我做不到…我做不到…！我又要失去一切了！"
    translate None fawn_badend_0007:
        show elliot n dim ang with dis
        el "你不会的！专心！"
    translate None fawn_badend_0008:
        "福恩的呼吸变得急促，眼前的景象天旋地转。无论他如何努力都无法集中精神，恐惧充斥着他的脑海。"
    translate None fawn_badend_0009:
        f "我做不到…"
    translate None fawn_badend_0010:
        el "你必须做到！否则他们会死！"
    translate None fawn_badend_0011:
        "螺旋状的火焰不断盘旋攀升，从地面直冲天花板，势不可挡。"
    translate None fawn_badend_0012:
        hide elliot
        hide fawn
        show bg throne:
            xpos 0.43 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.4
        with hpunch
        "蓝发少年跪倒在地，泪水汹涌划过脸庞。他用拳头重击地面，愤怒淹没了他。"
    translate None fawn_badend_0013:
        el hur "福恩，冷静—"
    translate None fawn_badend_0014:
        f c whur "我做什么都没用！都没用…"
    translate None fawn_badend_0015:
        "火焰后方浮现出黑色暗影。它扩张、收缩，最终爆裂。火舌向四面八方飞溅，房中众人皆被掀翻在地。"
    translate None fawn_badend_0016:
        "一道孤影踏出火海。"
    translate None fawn_badend_0017:
        luc smir "看来幸运女神今天终究是站在我这边。"
    translate None fawn_badend_0018:
        "他嗓音嘶哑，衣衫褴褛。"
    translate None fawn_badend_0019:
        f "不…"
    translate None fawn_badend_0020:
        "一只手向下探去，从地面拾起被遗弃的武器。他轻松举起它，然后—"
        play sound "sounds/sfx/stab2.ogg"
    translate None fawn_badend_0021:
        "哧。"
    translate None fawn_badend_0022:
        "刺入雷恩的腹部。"
    translate None fawn_badend_0023:
        f "不要！"
    translate None fawn_badend_0024:
        "不远处，艾米尔昏迷不醒，呼吸沉重却一动不动。"
    translate None fawn_badend_0025:
        luc "这样就解决掉一个言者了。"
    translate None fawn_badend_0026:
        fmn "不，不，不，不，不，不，不，不，不，不，不，不，不，不，不，不，不，不，不，不，不，不，不，不，不，不，不，不，不，不，不，不，不，不，不，不，不，不，不，不，不，不，不……"
    translate None fawn_badend_0027:
        fmn "不，不，不，不，不，不，不，不，不，不，不，不，不，不，不……"
    translate None fawn_badend_0028:
        fmn "不要！"
    translate None fawn_badend_0029:
        "周遭一切在福恩眼中都化作模糊光影，但已无关紧要。他抱头尖叫，声如裂帛，令在场所有人毛骨悚然。"
    translate None fawn_badend_0030:
        "众人目光投向他，但已无意义。"
    translate None fawn_badend_0031:
        "他早已深陷癫狂。"
    translate None fawn_badend_0032:
        "渐趋熄灭的火焰愤怒地复燃，在房间里疯狂旋转。无法遏制的原始怒火划破空气，将整个房间笼罩在灼热之中。"
    translate None fawn_badend_0033:
        luc neu "...."
    translate None fawn_badend_0034:
        luc "看来这是我该离开的时候了。我今天不会死在这里，更不会死在你这种人手里。"
    translate None fawn_badend_0035:
        el ang "福恩，立刻住手！"
    translate None fawn_badend_0036:
        mor c sur "你能听见我们吗，福恩？求你冷静下来。"
    translate None fawn_badend_0037:
        "脚步声向他靠近，但他毫无察觉。他蜷缩成团，细小的身躯不断迸发出火焰。"
    translate None fawn_badend_0038:
        i sca "维拉斯？！怎么回事？"
    translate None fawn_badend_0039:
        v lon "伊尔兰…"
    translate None fawn_badend_0040:
        "伊尔兰和卡斯皮安冲进房间，眼前的景象令他们震惊。维拉斯迅速从墙面挣脱，随着痛苦的闷哼跌入伊尔兰的怀抱。"
    translate None fawn_badend_0041:
        i ang "我这就带你离开。我绝不能失去你。"
    translate None fawn_badend_0042:
        v "可、可是福恩—"
    translate None fawn_badend_0043:
        i "你才是最重要的。"
    translate None fawn_badend_0044:
        v "...."
    translate None fawn_badend_0045:
        v sad "对不起，福恩…"
    translate None fawn_badend_0046:
        cas sca "艾米尔…艾米尔，睁开眼睛！"
    translate None fawn_badend_0047:
        ae hur "呃。"
    translate None fawn_badend_0048:
        cas "我们得走了…呃，你太重了…"
    translate None fawn_badend_0049:
        "卡斯皮安将艾米尔背起，拖着他冲出房间。"
    translate None fawn_badend_0050:
        "莫温、西尔维尔和埃利奥特在失控的火焰中面面相觑，火舌正舔舐着他们的身躯。"
    translate None fawn_badend_0051:
        mor c wor "我们该怎么办？！怎么会…怎么会变成这样？！"
    translate None fawn_badend_0052:
        el "......."
    translate None fawn_badend_0053:
        el "现在就走。立刻。"
    translate None fawn_badend_0054:
        mor "不！我绝不会抛弃孩子们！"
    translate None fawn_badend_0055:
        "一记至寂敲在后脑，莫温向前瘫倒在西尔维尔怀中。"
    translate None fawn_badend_0056:
        s sad "请原谅我。"
    translate None fawn_badend_0057:
        el "...."
    translate None fawn_badend_0058:
        el "如果他当时能相信自己…跟我来，西尔维尔。撤离途中我会收拢其他落单者。"
    translate None fawn_badend_0059:
        "转眼间，蓝发少年被独自留下。"
    translate None fawn_badend_0060:
        "他的泪水比火焰更灼人。"
    translate None fawn_badend_0061:
        "他挣扎着站起，蹒跚几步后又重重跌倒。"
    translate None fawn_badend_0062:
        "他在失控的火海中一寸寸艰难爬行，朝着那个不能失去的人越来越近。"
    translate None fawn_badend_0063:
        "即便衣衫焦灼，十指渗血，他仍未停歇。"
    translate None fawn_badend_0064:
        "就这样持续爬行，直到终于来到雷恩身边，浸没在他的血泊里。"
    translate None fawn_badend_0065:
        f c whur "雷恩…雷恩…求求你醒过来…"
    translate None fawn_badend_0066:
        f "没有你…我做不到…"
    translate None fawn_badend_0067:
        f "求你…"
    translate None fawn_badend_0068:
        "他的声音嘶哑，嘴唇干裂。试图舔舐却无济于事，所有水分都蒸发殆尽。"
    translate None fawn_badend_0069:
        "他的哭喊变成了尖叫，火焰化作风暴。"
    translate None fawn_badend_0070:
        "在他的脑海中，仍能看见雷恩微笑的面容。他声音的余韵。那温柔的触感。"
    translate None fawn_badend_0071:
        "他闭上眼睛，祈求这一切只是场梦。"

    window hide dissolve

    stop music
    stop sfx4
    with dissolve

    scene black with eye_shut
    pause 3.0

    scene bg throne with eye_open
    window show dissolve
    translate None fawn_badend_0072:
        f c whur "唔…"
    translate None fawn_badend_0073:
        play music "sounds/bgm/forgotten off.ogg" fadein 3.0
        i neu "嘿，快起来。皇室卫队马上就要攻进城堡了。要是他们发现你在这儿，你会被以叛国罪论处。"
    translate None fawn_badend_0074:
        f "雷恩…"
    translate None fawn_badend_0075:
        i "....."
    translate None fawn_badend_0076:
        i sad "我把他的遗体带走去安葬了。"
    translate None fawn_badend_0077:
        f "不…"
    translate None fawn_badend_0078:
        i "现在别对我发疯。我可应付不了再来一场火灾。"
    translate None fawn_badend_0079:
        f "我做不到…就让我留在这里吧。我不在乎自己的下场。"
    translate None fawn_badend_0080:
        i "你真觉得雷恩会这样要求你吗？"
    translate None fawn_badend_0081:
        f c wsad "…!"
    translate None fawn_badend_0082:
        i "我不知道你怎么想，但我觉得他会希望你尽力活出精彩人生。"
    translate None fawn_badend_0083:
        f "......"
    translate None fawn_badend_0084:
        f "……我做不到…我做不到……"
    translate None fawn_badend_0085:
        i ang "跟着我，我们会替你报仇。"
    translate None fawn_badend_0086:
        f "跟着你…？"
    translate None fawn_badend_0087:
        i "卢修斯逃走了。如果我的情报准确，他已经控制了国王。"
    translate None fawn_badend_0088:
        f "我们…输了…？"
    translate None fawn_badend_0089:
        i "我们输掉了一场战役，但战争还没结束。"
    translate None fawn_badend_0090:
        f "我们该怎么做…？"
    translate None fawn_badend_0091:
        i "重新集结所有人。街上不再安全，在解决卢修斯之前恐怕都不会安全。"
    translate None fawn_badend_0092:
        i "我们转入地下行动，追杀卢修斯和他的所有党羽。他麾下已有神明与恶魔效力。"
    translate None fawn_badend_0093:
        f "....."
    translate None fawn_badend_0094:
        i "怎么样？心中燃烧着无法平息的复仇之焰吧？"
    translate None fawn_badend_0095:
        "伊尔兰伸出手。福恩犹豫着，凝视那只伸来的手掌，最终坚定地握住。"
    translate None fawn_badend_0096:
        f "我会杀了他，哪怕会同归于尽。"
    translate None fawn_badend_0097:
        i "这才像话。"

    stop music fadeout 2.0
    window hide dissolve

    scene black with Fade(1.0, 1.0, 1.0)
    pause 2.0




    scene bg sc night with Fade(1.0, 1.0, 1.0):
        xpos 0.72 ypos 1.12 xanchor 0.5 yanchor 1.0 zoom 1.59
        linear 35.0 xpos 0.21 ypos 1.12 xanchor 0.5 yanchor 1.0 zoom 1.59
    window show dissolve
    play music "sounds/bgm/forgotten.ogg" fadein 3.0
    translate None fawn_badend_0098:
        "自卢修斯掌控锡德卡汉后的数月里，世界天翻地覆。人类知晓了神明的存在，或屈服顺从，或沦为食物，或加入反抗军。"
    translate None fawn_badend_0099:
        "许多人类城镇被夷平—那些不愿遵守卢修斯新秩序的。人们失去家园，亲人离散，毕生心血毁于一旦。"
    translate None fawn_badend_0100:
        "他们全都祈祷这一切结束，但他们的祷告不面向任何神明。"
    translate None fawn_badend_0101:
        "只献给一个人。"
    translate None fawn_badend_0102:
        "人们说他发如碧海，眼似银雷。双臂布满灼痕，面容永远凝固着狂怒。"
    translate None fawn_badend_0103:
        "能看到他的人不多，而那些见着他的人都会立时毙命—他是一名神猎手，是那寥寥可数的几人之一，其所属的秘密组织无人能够渗透。"
    translate None fawn_badend_0104:
        "在这个时代，他们是人类唯一可依赖的存在，也是卢修斯唯一畏惧的人物，尽管他拒不承认这一点。"
    translate None fawn_badend_0106:
        "虽从未得到证实，但关于其他成员的传言一直存在：一个来自神话小镇的言者，一位皇太子，一名赏金猎手，还有一位古神。"
    translate None fawn_badend_0107:
        "不论他派谁去对付那个被世人称为\"蓝魔\"的家伙，最后都难逃败北的命运，被残忍地抛回那片浩瀚的灵魂深渊。"
    translate None fawn_badend_0108:
        "目击者们会说，他杀死那些人时脸上几乎没有任何表情，唯有当无人注视时，那张空白的面具才会扭曲成愤怒的模样。"
    translate None fawn_badend_0109:
        "而每当他独处时，总会带着渴盼仰望着天空，怀念那些已经逝去的日子。"
    translate None fawn_badend_0110:
        "至少传闻是这么说的。"
    translate None fawn_badend_0111:
        "今晚的锡德卡汉与往常并无二致。积雪堆满街道，却没有孩童嬉戏。他们从不敢玩耍，生怕被游荡的恶魔抓去当点心吃掉。"
    translate None fawn_badend_0112:
        "一道孤影穿行夜色中，目光锁定了远方那座焦黑的城堡残骸。"
    translate None fawn_badend_0113:
        "那里正是锡德卡汉新晋国王卢修斯的现居所。"
    translate None fawn_badend_0114:
        "他攥紧颈间的项链，月光在粉红宝石上流转。这是她最后的礼物。"
    translate None fawn_badend_0115:
        f c wsad "……这是为你而做的，我的挚爱。"



    if achievement.has("fawn_badend"):
        pass
    else:
        $ renpy.display_notify("成就解锁：独行猎手")

    python:
        achievement.grant("fawn_badend")
        achievement.sync()
    translate None fawn_badend_0116:
        "将这番言语散入夜色，他朝着城堡迈步走去。"

    return
