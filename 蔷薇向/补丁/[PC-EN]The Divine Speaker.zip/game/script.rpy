init -3:
    define _preferences.language = None

    style langbutton:
        xmargin 10
        ymargin 10
    style langtext:
        hover_color "#fff"
        idle_color "#f9ecb2"
        selected_color "#d3d3d3"
        font "DejaVuSans.ttf"
        outlines [ (absolute(1), "#704f3a", absolute(0), absolute(0)) ]
define build.include_i686 = False


## achievements #

init python:
    achievement.register("prologue_end")
    achievement.register("fawn_meet")
    achievement.register("fawn_marriage")
    achievement.register("fawn_burn")
    achievement.register("leos_join")
    achievement.register("leos_lake")
    achievement.register("fawn_lake")
    achievement.register("reach_stagwich")
    achievement.register("group_band")
    achievement.register("illran_meet")
    achievement.register("lilas_meet")
    achievement.register("reach_oxhabor")
    achievement.register("cyne_meet")
    achievement.register("cyne_shop")
    achievement.register("cyne_kiss")
    achievement.register("nox_meet")
    achievement.register("illran_bury")
    achievement.register("raen_search")
    achievement.register("nox_giveup")
    achievement.register("cyne_lesson")
    achievement.register("nox_home")
    achievement.register("soren_free")
    achievement.register("cyne_name")
    achievement.register("reach_sidcaeham")
    achievement.register("group_outfits")
    achievement.register("cyne_date")
    achievement.register("cyne_dinner")
    achievement.register("cyne_three")
    achievement.register("raen_caspian")
    achievement.register("cyne_badend")
    achievement.register("morwen_meet")
    achievement.register("morwen_backstory")
    achievement.register("speaker_power")
    achievement.register("lucius_throne")
    achievement.register("cyne_goodend")
    achievement.register("illran_verasmeet")
    achievement.register("illran_kiss")
    achievement.register("illran_love")
    achievement.register("illran_soulmates")
    achievement.register("caspian_makeup")
    achievement.register("caspian_kiss")
    achievement.register("leos_ball")
    achievement.register("leos_macaron")
    achievement.register("leos_badend")
    achievement.register("leos_baby")
    achievement.register("leos_goodend")
    achievement.register("fawn_ball")
    achievement.register("fawn_ani")
    achievement.register("fawn_fire")
    achievement.register("fawn_name")
    achievement.register("fawn_badend")
    achievement.register("fawn_goodend")

#######################################################
##################### Variables #######################
#######################################################

############## Point System Declaration  #############
init:
    $ fawn_relationship = 0
    $ leos_relationship = 0
    $ cyne_relationship = 0
    $ illranveras_friend = 0
    $ caspianaemylromance = 0

############## ROUTE TRACKER #############
init:
    $ fawn_route = False
    $ leos_route = False
    $ cyne_route = False

############### Illran/Veras Scene Tracker #######################
init:
    $ iv_scene_one = False
    $ iv_scene_two = False
    $ iv_scene_three = False
    $ iv_scene_four = False

############### Caspian/Aemyl Scene Tracker #######################
init:
    $ ca_scene_one = False
    $ ca_scene_two = False


############### Night by the Pond #######################
init:
    $ chose_leos = False
    $ chose_fawn = False

############### Nox investigation #######################
init:
    $ search_books = True
    $ search_paper = True
    $ search_jewellery = True
    $ search_sleep = False
    $ search_badcount = 0

############### Illran Wagon Scene #######################
init:
    $ illran_love = True
    $ illran_veras = True
    $ illran_oxhabor = True
    $ illran_stop = False
    $ illran_fin = 0

############### Cyne Sleep Scene #######################
init:
    $ cyne_staynight = False
    $ cyne_yes = False
    $ cyne_no = False

init:
    $ fawn_oxchoose = False

############### Oxhabor Investigation Scene #######################
init:
    $ ox_fortune = True
    $ ox_body = True
    $ ox_nox = True
    $ ox_fin = 0

############### Fortune Teller Scene #######################
init:
    $ ft_askcount = 0
    $ ft_askmurders = True
    $ ft_askstrange = True
    $ ft_askearring = True
    $ ft_askdiary = True
    $ ft_asknox = True
    $ ft_enough = False

############### Nox Scene #######################
init:
    $ nox_askcount = 0
    $ nox_askname = True
    $ nox_askcause = True
    $ nox_askcaspian = True
    $ nox_askdrawing = True
    $ nox_askearring = True
    $ nox_askdiary = True
    $ nox_enough = False

    $ nox_earringinroom = False

############### Body Scene #######################
init:
    $ body_searchcount = 0
    $ body_arm = True
    $ body_jaw = True
    $ body_bones = True
    $ body_earring = True
    $ body_enough = False
    $ bloodonneck = False

############### Demon Nox Scene #####################
init:
    $ demonnox_victims = True
    $ demonnox_betrayal = True
    $ demonnox_business = True

    $ demonnox_caspian = True
    $ demonnox_demons = True
    $ demonnox_muranos = True

    $ demonnox_askcount = 0

############# Amaranth Forest Nightwatch ###################
init:
    $ watchafter_leos = False
    $ watchafter_cyne = False
    $ watchafter_fawn = False

############# Ashe Convo Tracker ###################
init:
    $ ashe_count = 0
    $ ashe_necklace = True
    $ ashe_sc = True
    $ ashe_gods = True
    $ ashe_enough = False

############# Cyne Route Tracker ###################
init:
    $ cyne_badend = 0
    $ cyne_goodend = 0
    $ cyne_threesome = False


############# Fawn Route Tracker ###################
init:
    $ fawn_badend = 0
    $ fawn_goodend = 0

############# Leos Route Tracker ###################
init:
    $ leos_badend = 0
    $ leos_goodend = 0

############# Titus Convo Tracker ###################
init:
    $ titus_count = 0
    $ titus_illran = True
    $ titus_veras = True
    $ titus_zarryn = True
    $ titus_home = True
    $ titus_enough = False

############# Morwen Convo Tracker ###################
init:
    $ morwen_count = 0
    $ morwen_lucius = True
    $ morwen_casaemyl = True
    $ morwen_illran = True
    $ morwen_human = True
    $ morwen_enough = False


################ MISC ###########################
init:
    $ fawnaskmarriage = False # If you asked fawn what marriage was


############################################################################
#intro scene
image gallery_3 dark = im.MatrixColor("/images/gallery/dscg1.jpg", im.matrix.tint(.44,.44,.75)*im.matrix.brightness(-0.03))
############################################################################


init -3:
    transform zoom(n):
         zoom n

    transform xzoom(n):
        xzoom n

    transform yzoom(n):
        yzoom n

init:
    image particle1 = SnowBlossom(At("images/Various/flying.png", zoom(0.8)),
        count=150,
        border=50,
        xspeed=(-50, 80),
        yspeed=(-300, -50),
        start=0,
        fast=True,
        horizontal=False)

    image particle2 = SnowBlossom(At("images/Various/flying.png", zoom(1.2)),
        count=100,
        border=50,
        xspeed=(-10, 40),
        yspeed=(-120, -5),
        start=0,
        fast=True,
        horizontal=False)

# Regional map
image map = "images/Various/map.jpg"

init -1 python hide:

    def hide(name, layer='master'):
        for l in _3d_layers:
            if renpy.showing(name, l):
                renpy.hide(name, l)
        else:
            renpy.hide(name, layer)

    config.hide = hide

    def scene(layer='master'):

        renpy.scene(layer)
        for l in _3d_layers:
            renpy.scene(l)

    config.scene = scene


init -1:
    $ flash = Fade(.25, 0, .75, color="#fff")
    $ flash2 = Fade(.1, 0, .2, color="#fff")
    $ flashred = Fade(.25, 0.0, .75, color="#ba1b1d")

init python:
  def eyewarp(x):
    return x**1.33
  eye_open = ImageDissolve("Various/eye.png", 1.0, ramplen=128, reverse=False, time_warp=eyewarp)
  eye_shut = ImageDissolve("Various/eye.png", 1.0, ramplen=128, reverse=True, time_warp=eyewarp)


# 3D camera wobbling
init python:
    class Wiggle(object):
        def __init__(self, freq, amp, octaves=1, ampMulti=.5, time=0):
            from random import random
            self.randoms = [(1+random(), 1+random()) for i in range(0, 100)]
            self.freq = freq
            self.amp = amp
            self.octaves = octaves
            self.ampMulti = ampMulti
            self.time = time

        def __call__(self, time, at):
            from math import sin, pi, ceil
            r1, r2 = self.randoms[int(ceil(time*self.freq)%100)]

            return r1*self.amp*sin(2*pi*self.freq*time) + r2*self.amp*self.ampMulti*sin(2*pi*self.freq*2*self.octaves*(time+self.time))

init python:
    style.hyperlink_text.color = "#fff"
    style.hyperlink_text.hover_color = "#d3d3d3"


default persistent.voice_acting_off = False
default persistent.streamer_mode = False

label splashscreen:
    $ _preferences.language = None
    $ persistent.voice_acting_off = False
    $ config.auto_voice = get_voice_file
    pause(1.0)
    show logo with dissolve:
        xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 0.31
    pause (1.5)
    hide logo with dissolve
    return

####################################################
            ##Character Declarations##
####################################################

init -2:
    
    image blank = "images/blank.png"
### RAEN GANG ###
    define r = Character(_('雷恩'), image="雷恩", voice_tag="雷恩", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define rs = Character(_('雷恩'), image='雷恩',voice_tag="雷恩", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define c = Character(_('赛恩'), image='赛恩', voice_tag="赛恩",what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define f = Character(_('福恩'), image = '福恩', voice_tag="福恩", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define l = Character(_('莱奥斯'), image='莱奥斯', voice_tag="莱奥斯", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')

    define leosu = Character(_('???'), image='莱奥斯', voice_tag="莱奥斯", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define fawnu  = Character(_('???'), image='福恩', voice_tag="福恩", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define cyneu  = Character(_('???'), image='赛恩', voice_tag="赛恩", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define fchild = Character(_('福恩'), image = 'fawny', voice_tag="福恩", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')


### SIDE COUPLES ###
    define i = Character(_('伊尔兰'),voice_tag="其他", image = 'illran',what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define iy = Character(_('伊尔兰'),voice_tag="其他", image = 'illrany',what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define gr = Character(_('绿发男子'),voice_tag="其他", image = 'illran', what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define v = Character(_('维拉斯'),voice_tag="其他", image = 'veras', what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define pr = Character(_('桃发男子'),voice_tag="其他", image = 'veras', what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define d = Character (_('神谕者'),voice_tag="其他", image = 'ds', what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define ae = Character (_('艾米尔'),voice_tag="其他", image = 'ds', what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define cas = Character (_('卡斯皮安'),voice_tag="其他", image = 'caspian', what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define ca = Character (_('卡斯皮安 & 艾米尔'),voice_tag="其他", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')

### SIDE CHARACTERS ###
    define n = Character(_('旁白'), centered, what_font="gui/LibreBaskerville-Bold.ttf",voice_tag="其他", what_cps=40, window_background=None, what_xsize=1250, what_line_spacing=20, image='blank')
    define nox = Character(_('诺克斯'),voice_tag="其他", image='nox', what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define dem =  Character(_('???'), centered, what_font="gui/LibreBaskerville-Bold.ttf",voice_tag="其他", window_background=None, what_xsize=1250, what_line_spacing=20, what_color="#ff0000",  what_size=50)
    define sor = Character(_('索伦'),voice_tag="其他", image='nox', what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define nik = Character(_('Nikos'),voice_tag="其他", image='nikos', what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define br = Character(_('Bartender'),voice_tag="其他", image='nikos', what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define lil = Character(_('Lilas'),voice_tag="其他", image='lilas', what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define a = Character(_('Ashe'),voice_tag="其他", image='ashe',what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define mor = Character(_('Morwen'),voice_tag="其他", image='morwen',what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define el = Character(_('Elliot'),voice_tag="其他", image='elliot',what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define z = Character(_('Zarryn'),voice_tag="其他", image='zarryn',what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define tit = Character(_('Titus'),voice_tag="其他", image='titus',what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define h = Character(_('Hone'),voice_tag="其他", image='hone',what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define lv = Character(_('Lady Vemond'),voice_tag="其他", image='lv', what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define s = Character(_('Sylvir'),voice_tag="其他", image='sylvir',what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define luc = Character(_('Lucius'),voice_tag="其他", image='luc',what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define lucu = Character(_('???'),voice_tag="其他", image='luc',what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define crazy = Character(None, centered, what_font="gui/LibreBaskerville-Bold.ttf", what_cps=40, window_background=None, what_xsize=1850, what_line_spacing=20)
    define moru = Character(_('???'),voice_tag="其他", image='morwen',what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define su = Character(_('???'),voice_tag="其他", image='sylvir',what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')

### MINOR CHARACTERS ###
    define m = Character(_('米娅'),voice_tag="其他", image='miah', what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define t = Character(_('托比亚斯'),voice_tag="其他",image='tobias', what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define ma = Character(_('院长'),voice_tag="其他", image='matron', what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define ls = Character(_('Lord Septam'),voice_tag="其他", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define e = Character(_('Ether'),voice_tag="其他", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define ey = Character(_('Eyrn'),voice_tag="其他", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define ast = Character(_('Lady Astrid'),voice_tag="其他", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define p = Character(_('Prim'),voice_tag="其他", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define ani = Character(_('Ani'),voice_tag="其他", image='ani', what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define mot = Character(_('Mother'),voice_tag="其他", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')

### OTHERS ###
    define u = Character(_('???'),voice_tag="其他", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define uv = Character(_('???'),voice_tag="其他", what_italic=True, what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define cr = Character(_('人群'),voice_tag="其他", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define b = Character(_('Both'),voice_tag="其他", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define fl = Character(_('Fawn & Leos'),voice_tag="其他", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define fr = Character(_('Fawn & Raen'),voice_tag="其他", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define iv = Character(_('伊尔兰与维拉斯'),voice_tag="其他", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define rl = Character(_('Raen & Leos'),voice_tag="其他", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define cf = Character(_('Cyne & Fawn'),voice_tag="其他", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define lc = Character(_('Cyne & Leos'),voice_tag="其他", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define boys = Character(_('All'),voice_tag="其他", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define w = Character(_('Woman'),voice_tag="其他", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define wom = Character(_('Woman'),voice_tag="其他", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define man = Character(_('Man'),voice_tag="其他", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define o = Character(_('Oriana'),voice_tag="其他", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define w1 = Character(_('Woman 1'),voice_tag="其他", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define w2 = Character(_('Woman 2'),voice_tag="其他", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define w3 = Character(_('Woman 3'),voice_tag="其他", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define wa = Character(_('Waiter'),voice_tag="其他", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define ft = Character(_('Fortune Teller'),voice_tag="其他", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define guard = Character(_('Guard'),voice_tag="其他", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define mn = Character(None, what_italic=True)
    define cmn = Character(_('{i}Cyne{/i}'), what_italic=True)
    define fmn = Character(_('{i}Fawn{/i}'), what_italic=True)
    define imn = Character(_('{i}Illran{/i}'), what_italic=True)
    define amn = Character(_('{i}Aemyl{/i}'), what_italic=True)
    define mmn = Character(_('{i}Morwen{/i}'), what_italic=True)
    define vmn = Character(_('{i}Veras{/i}'), what_italic=True)
    define lmn = Character(_('{i}Leos{/i}'), what_italic=True)
    define smn = Character(_('{i}Sylvir{/i}'), what_italic=True)
    define casmn = Character(_('{i}Caspian{/i}'), what_italic=True)
    define om = Character(_('Old Man'),voice_tag="其他", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define cyneraen = Character(_('Cyne & Raen'),voice_tag="其他", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')
    define rsbad = Character(_('Raen?'),voice_tag="其他", image='雷恩', what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]')

    define quotepre = _("\"")
    define quotesuf = _("\"")

    default persistent.game_first_opened = False

init python:
    def nar_jp(tag, argument, contents):
        return [
                (renpy.TEXT_TAG, u"size=45"),
                (renpy.TEXT_TAG, u"font=gui/NotoSerifJP-Bold.otf"),
            ] + contents + [
                (renpy.TEXT_TAG, u"size=45"),
                (renpy.TEXT_TAG, u"font=gui/NotoSerifJP-Bold.otf"),
            ]
    config.custom_text_tags["narj"] = nar_jp

####################################################
            ##Start Game##
####################################################
label start:
    $ persistent.game_first_opened = True

    python:
        enc_people = Encyclopaedia()


    python:
        enc_places = Encyclopaedia()


    python:
        enc_lore = Encyclopaedia()


    python:
        enc_mysteries = Encyclopaedia()


    python:

        about_Forest = EncEntry(
        parent=enc_places,
        name="森林",
        text=[
            "据言者所说，环绕奥雷利亚卡维拉的森林既致命又危险。无人敢外出冒险，唯恐丧命。不过，我不太确定具体是什么让它如此危险。 \n \n有人说那里充斥着邪恶野兽与凶猛动物，有人说超自然力量在作祟，还有人说离开神明庇佑之地会遭天谴。 \n \n老实说，我不知该信哪种说法。"
            ],
        image = "gui/codex/entries/places/enc_acforest.jpg"
        )

        about_Gods = EncEntry(
        parent=enc_lore,
        name="神圣存在",
        text=[
            "神圣存在是守护奥雷利亚卡维拉的众神，使其免受森林中的邪恶侵袭。尽管神明众多，但大多神名已被遗忘，通常是被视为整体而非单独的神明来供奉。"
            ],
        )

        about_Tobias = EncEntry(
        parent=enc_people,
        name="Tobias",
        text=[
            "托比亚斯四年前被带到孤儿院，那时他母亲失踪了。他现在八岁，和米娅是最好的朋友。他们互相陪伴，一起惹麻烦。 \n \n我一直觉得有点奇怪。在这里怎么会有人失踪呢？不过我从未问过相关的问题。"
            ],
        image = "gui/codex/entries/people/enc_tobias.jpg"
        )

        about_Miah = EncEntry(
        parent=enc_people,
        name="Miah",
        text=[
            "米娅从出生几周后就住在孤儿院。她因【审判】结果不佳被父母遗弃，但始终保持着开朗的性格。她今年九岁，和托比亚斯是最好的朋友。\n \n她就像我的小妹妹一样。"
            ],
        image = "gui/codex/entries/people/enc_miah.jpg"
        )

        about_Matron = EncEntry(
        parent=enc_people,
        name="Matron Aralla",
        text=[
            "女院长阿拉拉经营这家孤儿院已有约十九年。孩子们有时觉得她可怕，但她心地非常善良。她很少谈及过去的经历，不过她在养育孩子方面很有天赋，或许与此有关。"
            ],
        image = "gui/codex/entries/people/enc_matron.jpg"
        )

        about_AC = EncEntry(
        parent=enc_places,
        name="Aurelia Cavella",
        text=[
            "奥雷利亚卡维拉是一座广阔的城市，四周被无人敢进的致命森林环绕。这是世界上已知的唯一文明，由神圣演说者本人统领。"
            ],
        locked=True,
        image = "gui/codex/entries/places/enc_ac.jpg"
        )

        about_Judgement = EncEntry(
        parent=enc_lore,
        name="The Judgement",
        text=[
            "【审判】由神圣演说者本人亲自授予。新生儿出生时，言者会与神明沟通，赐予决定其一生命运的预言。"
            ],
        )


        about_Azuros= EncEntry(
        parent=enc_places,
        name="Azuros",
        text=[
            "阿祖罗斯位于奥雷利亚卡维拉北部，靠近言者住所的僻静区域。年满规定年龄者可进入此地，在安宁闲适中度过余生。"
            ],
        locked=True,
        )

        about_Speaker= EncEntry(
        parent=enc_people,
        name=_("神圣演说者"),
        text=[
            "说书人是统治奥雷利亚卡维拉的人，拥有与神沟通的能力，能为新生儿赐予审判。尽管他与公众保持距离，却受到所有人的爱戴与崇拜。 \n \n他看似仁慈，却有些孤独。我仅见过他本人寥寥数次。"
            ],
        image = "gui/codex/entries/people/enc_speaker.jpg"
        )

        about_Letter= EncEntry(
        parent=enc_lore,
        name="Matron's Letter",
        text=[
            "女院长的来信。上面写着：\n \n 亲爱的雷恩，生日快乐，我的孩子。 \n \n 很抱歉我们无力送你贵重礼物，但愿这点心意够你买些喜欢的东西。 \n \n孩子们都在为了你偷偷攒钱呢。 \n \n从捡到你的那天起，我就把你当亲生儿子。如今你已成年，很快就能婚配生子了。 \n \n在那之前，请继续留在孤儿院吧。要是没有你，我和孩子们都不知该如何是好。 \n \n我相信若你父母看到现在的你，定会如我般以你为荣。 \n \n爱你的，女院长阿拉拉"
            ],
        locked=True
        )

        about_Markings= EncEntry(
        parent=enc_mysteries,
        name="Strange Markings",
        text=[
            "听完说书人的演讲后，我浑身突然灼痛难忍。在巷子里昏倒后醒来，发现手臂上爬满了诡异的神之刻印。 \n \n我看不懂这些纹路。"
            ],
        locked=True,
        image = "gui/codex/entries/mysteries/enc_markings.jpg"
        )

        about_Leos= EncEntry(
        parent=enc_people,
        name="红发男子",
        text=[
            "回孤儿院途中撞见个红发男子。他既咄咄逼人又粗鲁无礼，但认出了我手臂的神之刻印，指引我去某个可能找到答案的地方。"
            ],
        locked=True,
        image = "gui/codex/entries/people/enc_leos.jpg"
        )

        about_Archives= EncEntry(
        parent=enc_places,
        name="Archives",
        text=[
            "说书人档案馆位于城镇北侧，紧邻他的城堡。馆内堆满古老手稿、典籍与包罗万象的书籍，穷尽一生也读不完。 \n \n这里向来禁止入内，今天却莫名敞开着。"
            ],
        locked=True,
        image = "gui/codex/entries/places/enc_archives.jpg"
        )

        about_Fawn= EncEntry(
        parent=enc_people,
        name="福恩",
        text=[
            "在森林里遇到个自称福恩的少年。他说和朋友们住在这里，从没去过奥雷利亚卡维拉。当我提到说书人时，他满脸困惑。 \n \n这孩子似乎…不太清醒。或许是长期野外生活让他精神失常了。 \n \n另外，他好像有囤积癖…"
            ],
        locked=True,
        image = "gui/codex/entries/people/enc_fawn.jpg"
        )

        about_SC= EncEntry(
        parent=enc_places,
        name="Sid Caeham",
        text=[
            "福恩将锡德卡汉描述成\'这片地区的首府\'。 \n \n说书人档案馆的典籍也提到过这个地方… \n \n这意味着什么？"
            ],
        locked=True
        )

        about_Marriage= EncEntry(
        parent=enc_lore,
        name="Marriage",
        text=[
            "显然，当你找到想共度余生之人时，可以选择赠予对方项链作为信物。 \n \n福恩说这些项链通常用亲手挑选的宝石制成，要与你未来配偶的气质相配。 \n \n不知道，我会被赠予什么宝石呢？"
            ],
        locked=True
        )

        about_Caspian= EncEntry(
        parent=enc_people,
        name="Caspian",
        text=[
            "卡斯皮安是奥雷利亚卡维拉最后的王子，本将加冕为王，直到他与全家人突然离世。不过莱奥斯说他的尸体至今未被找到。"
            ],
        locked=True
        )

        about_Stagwich= EncEntry(
        parent=enc_places,
        name="Stagwich",
        text=[
            "斯塔格威奇是座海滨小镇，距奥雷利亚卡维拉不远。当地居民友善淳朴，早已习惯商旅往来。 \n \n这里的集市售卖着全世界最新鲜美味的渔获。"
            ],
        locked=True,
        image = "gui/codex/entries/places/enc_stagwich.jpg"
        )

        about_Illran= EncEntry(
        parent=enc_people,
        name="绿发男子",
        text=[
            "原以为莱奥斯绝对是我见过最烦人的家伙… \n \n我们在斯塔格威奇酒馆遇见个绿发男子。他肩上停着叫维拉斯的鸟，但未透露姓名。短短几分钟内，他仅用三言两语就激怒莱奥斯（新纪录？）、洗劫了我后扬长而去。 \n \n这人绝对有问题…"
            ],
        locked=True,
        image = "gui/codex/entries/people/enc_illran.jpg"
        )

        about_Nikos= EncEntry(
        parent=enc_people,
        name="Nikos",
        text=[
            "尼科斯是沉睡鸵鸟酒馆的老板，为人真诚友善，还免费给我们安排了房间。 \n \n不过看起来他不太习惯我们带来的客流量。"
            ],
        locked=True,
        image = "gui/codex/entries/people/enc_nikos.jpg"
        )

        about_Oxhabor= EncEntry(
        parent=enc_places,
        name="Oxhabor",
        text=[
            "这座城镇距斯塔格威奇数日路程。据尼科斯描述，当地以优质玻璃制品闻名，也流通着些…来路不明的商品？"
            ],
        locked=True,
        )

        about_Lilas= EncEntry(
        parent=enc_people,
        name="Lilas",
        text=[
            "莱拉斯看似安静却不腼腆，更像是只讲必要的话。虽然有点冷淡，但还是好心让我们搭便车前往奥克斯哈伯。"
            ],
        locked=True,
        image = "gui/codex/entries/people/enc_lilas.jpg"
        )

        about_Veras= EncEntry(
        parent=enc_people,
        name="Veras",
        text=[
            "这是那个古怪绿发男子随身携带的鸟，模样倒是挺讨人喜欢。"
            ],
        locked=True,
        image = "gui/codex/entries/people/enc_bveras.png"
        )

        about_Cyne= EncEntry(
        parent=enc_people,
        name="赛恩",
        text=[
            "我们在莱拉斯店里撞见自称赛恩的少年。这小子…精力过剩吵得要命…"
            ],
        locked=True,
        image = "gui/codex/entries/people/enc_cyne.jpg"
        )

        about_AClegend= EncEntry(
        parent=enc_lore,
        name="Aurelian War",
        text=[
            "《奥雷利亚卡维拉传奇》半基于事实，半基于推测。 \n\n500多年前，锡德卡汉处于国王与说书人的双重统治下。两人本应无缝合作。 \n \n彼时，奥雷连教已遍布维迪斯。 \n \n历代国王与说书人间始终剑拔弩张。最终敌对态势突破临界点，锡德卡汉爆发了两派大战。国王颁布法令禁止说书人及所有奥雷利亚诸神，凡被发现崇拜他们者皆处死刑。 \n \n这场战争血腥惨烈，最终以说书人携锡德卡汉王子率领追随者建立新城邦告终：奥雷利亚卡维拉。他们在此与世隔绝，营造自己的小乐园。民众继续崇拜神圣存在—奥雷利亚诸神，始终未被国王察觉。"
            ],
        locked=True
        )

        about_Nox= EncEntry(
        parent=enc_people,
        name="诺克斯",
        text=[
            "诺克斯的第一印象并不理想。 \n \n关于他的真实身份几乎无人知晓，但他声称知道卡斯皮安的下落。唯有协助侦破奥克斯哈伯连环命案，他才肯透露。 \n \n他看起来近乎恐惧，但我不知缘由。"
            ],
        locked=True,
        image = "gui/codex/entries/people/enc_Nox.jpg"
        )

        about_NoxHouse= EncEntry(
        parent=enc_mysteries,
        name="诺克斯宅邸物品清单",
        text=[
            "我在诺克斯宅邸发现以下物品："
            ],
        locked=True,
        )

        about_NoxAcc= EncEntry(
        parent=enc_mysteries,
        name="诺克斯的供述",
        text=[
            "我们折返再度询问诺克斯。发现他在户外做园艺时显得窘迫。他告诉我正在种植母亲最爱的紫色的风信子。 \n \n他再次提及父母因商务旅行外出。"
            ],
        locked=True,
        )

        about_FTAcc= EncEntry(
        parent=enc_mysteries,
        name="占卜师的供述",
        text=[
            "尽管莱奥斯反对，我们仍决定拜访赛恩提及的占卜师。她精准得骇人地解读了我的过去，却断言我没有未来。"
            ],
        locked=True,
        )


        about_DeadBody= EncEntry(
        parent=enc_mysteries,
        name="奥克斯哈伯尸体",
        text=[
            "或许违背了更理智的判断，我们决定调查尸体。在完全荒废的城郊发现它时，仅瞥见尸骸就令我作呕。\n \n尸体缺失手臂，下颌松脱，泛黄的骨头从破烂衣物中刺出。"
            ],
        locked=True,
        )

        about_Soren= EncEntry(
        parent=enc_people,
        name="Soren",
        text=[
            "少年时，索伦曾帮助卡斯皮安逃离威胁他生命的恶魔诺克斯。虽然卡斯皮安安全逃脱，但索伦却不得不独自承担后果。\n \n起初诺克斯勃然大怒，决定让索伦代替卡斯皮安的位置。但索伦的父母乞求饶他一命，因为他是唯一的继承人。诺克斯看准机会与索伦父母达成协议—他将占据索伦身体的半侧。\n \n融合过程对双方都极为痛苦，这是种极少施行的仪式，大多数时候会导致双方死亡。\n \n不久后，索伦的父母死于他亲自之手。他始终无法原谅自己身体犯下的罪孽，从此孤身一人。他时常梦见遥远的过去，那时卡斯皮安还在他身旁。"
            ],
        locked=True,
        image = "gui/codex/entries/people/enc_Nox.jpg"
        )

        about_FallenGods= EncEntry(
        parent=enc_lore,
        name="诸神陨落",
        text=[
            "许多年前，那些在奥雷利亚卡维拉（奥雷利亚战争前曾遍布维迪斯）被追随的神圣存在—众神，因未知原因从天界坠入凡尘。有些神明随即消亡或消散，另一些则寄居于人类躯体，如今在世间游荡寻找新的意义。"
            ],
        locked=True,
        )

        about_AmaranthForest = EncEntry(
        parent=enc_places,
        name="苋红森林",
        text=[
            "通往锡德卡汉的最快捷径贯穿着苋红森林的深红树影，但人们通常不惜一切代价避开此处。\n \n传说苋红森林能操控满腔怒火之人，驱使他们杀戮，而喷洒的鲜血正是树木常年猩红的根源。\n \n传言真实性难以考证，但多数人仍对此警告深信不疑。"
            ],
        locked=True,
        image = "gui/codex/entries/places/enc_amforest.jpg"

        )

        about_Ashe = EncEntry(
        parent=enc_people,
        name="Ashe",
        text=[
            "阿什在锡德卡汉经营一家名为\"樱草花\"的小裁缝店。他似乎不仅将赛恩视为顾客，更视为值得尊重的人。"
            ],
        locked=True,
        image = "gui/codex/entries/people/enc_ashe.jpg"
        )

        about_Elliot = EncEntry(
        parent=enc_people,
        name="伟大的埃利奥特",
        text=[
            "锡德卡汉矗立着名为\"伟大的埃利奥特\"的男子雕像。"
            ],
        locked=True,
        )

        about_Hone = EncEntry(
        parent=enc_people,
        name="Hone",
        text=[
            "霍恩是我们在舞会上遇见的面包师。在所有舞客中，他显得最为友善—考虑到他是唯一与我们搭话的人…"
            ],
        locked=True,
        image = "gui/codex/entries/people/enc_hone.jpg"
        )

        about_LV = EncEntry(
        parent=enc_people,
        name="Lady Vemond",
        text=[
            "赛恩的母亲维蒙德夫人与儿子相貌惊人地相似，看起来极为端庄威严。"
            ],
        locked=True,
        image = "gui/codex/entries/people/enc_LV.jpg"
        )

        about_Prim = EncEntry(
        parent=enc_people,
        name="Prim",
        text=[
            "普莉姆是阿什的养女，显得聪慧而无畏。阿什将她教养得十分出色。"
            ],
        locked=True,
        )


        about_Zarryn = EncEntry(
        parent=enc_people,
        name="Zarryn",
        text=[
            "扎林是锡德卡汉的皇家医师，这个头衔给他带来了不少特权—其中一项就是当他研究那些可能惹上麻烦的学问时，旁人会睁一只眼闭一只眼—比如神学和恶魔学。\n \n他目前负责照料索伦。"
            ],
        locked=True,
        image = "gui/codex/entries/people/enc_zarryn.jpg"
        )

        about_Titus= EncEntry(
        parent=enc_people,
        name="Titus",
        text=[
            "提图斯是扎林的侄子和助手。除去诸多才能外，他似乎是位技艺高超的炼金术士和历史学家。他对叔父有着很深的依恋。"
            ],
        locked=True,
        image = "gui/codex/entries/people/enc_titus.jpg"
        )

        about_Cliffspire = EncEntry(
        parent=enc_places,
        name="Cliffspire",
        text=[
            "提图斯的家乡克利夫斯派尔约十年前被焚为焦土。虽然现已重建，但在许多人心中永远无法复原如初。"
            ],
        locked=True,
        )

        about_Sylvir = EncEntry(
        parent=enc_people,
        name="Sylvir",
        text=[
            "西尔维尔是位著名制图师，她从托根出发跨海航行至维迪斯。她是首位绘制出整片大陆详图的人。\n \n奥雷利亚战争结束后某日，她昏倒在锡德卡汉附近的深山之中。正当她以为生命将尽时，名为埃利奥特的男子救下了她，并在某个无名村庄为其疗伤。\n \n最终获准离开时，他们蒙住她的眼睛带她下山。扎林认为这里隐藏着神明们逃避人世的庇护所。"
            ],
        locked=True,
        )

        about_SecretVillage = EncEntry(
        parent=enc_places,
        name="Secret Village",
        text=[
            "深山中可能存在着专属于神明的城镇。真假与否，无人知晓。"
            ],
        locked=True,
        )

        about_Ani = EncEntry(
        parent=enc_people,
        name="Ani",
        text=[
            "安妮是我们在锡德卡汉遇到的福恩的姐妹之一。见到他时她喜出望外。\n \n她称呼他为「阿登」。"
            ],
        locked=True,
        )

        about_Lucius = EncEntry(
        parent=enc_people,
        name="Lucius",
        text=[
            "卢修斯是前任神圣演说者，也是培养艾米尔的导师。他始终怀揣崇高抱负，却又因某种不为人知的原因，对国王抱有私人嫌恶—尽管两人年少时曾是挚友。\n \n解决完国王与王后的事宜后，他在艾米尔与卡斯皮安之间制造隔阂，刻意孤立二人，全为推进其不可告人的计划。不过他的死亡是否也在计划之中，唯有他自己知晓。\n \n如今他以神明之姿归来，竟觊觎着比神位更高的王座。"
            ],
        locked=True,
        image = "gui/codex/entries/people/enc_lucius.jpg"

        )


        about_Morwen = EncEntry(
        parent=enc_people,
        name="Morwen",
        text=[
            "莫温是被囚禁在奥雷利亚卡维拉的神明之一，也是我旅途过程中始终与我对话的声音。多年来她一直在暗中注视着我。"
            ],
        locked=True,
        image = "gui/codex/entries/people/enc_morwen.jpg"
        )



    show screen pause_button
    stop music
    scene black
    with Dissolve(2)

    #jump prologue_start

    # ####BETA BUILD, REMOVE LATER#####
    # show black with Dissolve(2.0)
    # window show dissolve
    # # "Welcome to the Fawn route beta! Where would you like to start? (you can ignore the black BG that comes up in the route skips!"
    # window hide
    # #
    # menu:
    # #
    #     "Show me the story from the beginning":
    #         jump prologue_start
    #
    #     "Jump to the end of the original demo":
    #         window show dissolve
    #         $ about_Fawn.locked = False
    #         $ about_SC.locked = False
    #         $ about_AC.locked = False
    #         $ about_Azuros.locked = False
    #         $ about_Letter.locked = False
    #         $ about_Markings.locked = False
    #         $ about_Leos.locked = False
    #         $ about_Archives.locked = False
    #         jump jumpdemo
    # #
    # #
    #     "Jump to the end of the extended demo":
    #         window show dissolve
    #         $ about_Fawn.locked = False
    #         $ about_SC.locked = False
    #         $ about_AC.locked = False
    #         $ about_Azuros.locked = False
    #         $ about_Letter.locked = False
    #         $ about_Markings.locked = False
    #         $ about_Leos.locked = False
    #         $ about_Archives.locked = False
    #         $ about_Cyne.locked = False
    #         $ about_Stagwich.locked = False
    #         $ about_Caspian.locked = False
    #         $ about_Oxhabor.locked = False
    #         $ about_Veras.locked = False
    #         $ about_Illran.locked = False
    #         $ about_Nikos.locked = False
    #         $ about_AClegend.locked = False
    #         $ about_Nox.locked = False
    #         $ illranveras_friend = 3
    #         $ iv_scene_one = True
    #         jump chapter_eleven_start
    # #
    #     "Cyne Route Jump":
    #
    #         window show dissolve
    #         $ cyne_relationship = 5
    #         $ about_Fawn.locked = False
    #         $ about_SC.locked = False
    #         $ about_AC.locked = False
    #         $ about_Azuros.locked = False
    #         $ about_Letter.locked = False
    #         $ about_Markings.locked = False
    #         $ about_Leos.locked = False
    #         $ about_Archives.locked = False
    #         $ about_Cyne.locked = False
    #         $ about_Stagwich.locked = False
    #         $ about_Caspian.locked = False
    #         $ about_Oxhabor.locked = False
    #         $ about_Veras.locked = False
    #         $ about_Illran.locked = False
    #         $ about_Nikos.locked = False
    #         $ about_AClegend.locked = False
    #         $ about_Nox.locked = False
    #         $ illranveras_friend = 3
    #         $ iv_scene_one = True
    #         jump choice_thirty_done
    # #
    #     "Leos Route Jump":
    #         window show dissolve
    #         $ leos_relationship = 5
    #         $ about_Fawn.locked = False
    #         $ about_SC.locked = False
    #         $ about_AC.locked = False
    #         $ about_Azuros.locked = False
    #         $ about_Letter.locked = False
    #         $ about_Markings.locked = False
    #         $ about_Leos.locked = False
    #         $ about_Archives.locked = False
    #         $ about_Cyne.locked = False
    #         $ about_Stagwich.locked = False
    #         $ about_Caspian.locked = False
    #         $ about_Oxhabor.locked = False
    #         $ about_Veras.locked = False
    #         $ about_Illran.locked = False
    #         $ about_Nikos.locked = False
    #         $ about_AClegend.locked = False
    #         $ about_Nox.locked = False
    #         $ illranveras_friend = 3
    #         $ iv_scene_one = True
    #         jump choice_thirty_done
    # #
    #     "Fawn Route Jump":
    #         window show dissolve
    #         $ fawn_relationship = 5
    #         $ about_Fawn.locked = False
    #         $ about_SC.locked = False
    #         $ about_AC.locked = False
    #         $ about_Azuros.locked = False
    #         $ about_Letter.locked = False
    #         $ about_Markings.locked = False
    #         $ about_Leos.locked = False
    #         $ about_Archives.locked = False
    #         $ about_Cyne.locked = False
    #         $ about_Stagwich.locked = False
    #         $ about_Caspian.locked = False
    #         $ about_Oxhabor.locked = False
    #         $ about_Veras.locked = False
    #         $ about_Illran.locked = False
    #         $ about_Nikos.locked = False
    #         $ about_AClegend.locked = False
    #         $ about_Nox.locked = False
    #         $ illranveras_friend = 3
    #         $ iv_scene_one = True
    #         jump choice_thirty_done




    ####BETA BUILD, REMOVE LATER#####

    jump prologue_start
    #jump outside_aurelia
