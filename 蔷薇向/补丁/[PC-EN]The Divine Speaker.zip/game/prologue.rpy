label prologue_start:

    $ renpy.start_predict("dscg1_dark")
    $ renpy.start_predict("ds n dark neu")
    $ renpy.start_predict("bg forestnight")
    $ camera_reset

    window hide
    $ quick_menu = False
    scene black with dissolve
    pause (0.2)
    scene bg forestnight with dissolve:
        size (1920, 1080) crop (0, 0, 800, 600) # Sets the initial size for the image
        linear 40.0 crop (400, 400, 800, 600) # Pans to (400, 400) in 30 seconds
        pause 2.0 # Your specified pause...
        linear 30.0 crop (800, 400, 800, 600) # Pans to x=800 from x=400 in 30 seconds


    show eye with eye_shut
    play music "sounds/bgm/startsong.ogg" fadein 1.0
    translate None prologue_001:
        n "一个孩子的诞生预示着许多事情—变化、适应、混乱，但最重要的是…"
    translate None prologue_002:
        n "【审判】。"

    translate None prologue_003:
        n "新生儿的第一站不是母亲的怀抱，而是另一个人的怀抱。"

    window hide
    show black with eye_shut
    pause(0.2)
    show ds n dark neu at center behind eye
    hide black with eye_open

    translate None prologue_004:
        n "神谕者，这个人的职责是从孩子出生那天起就决定其命运，直至生命终结。"


    show black with eye_shut
    hide ds dark
    pause(0.2)
    show dscg1_dark behind eye:
        xpos 0.5 ypos 1.0 xanchor 0.55 yanchor 0.83 zoom 1.5
        easein 25 xpos 0.5 ypos 1.0 xanchor 0.41 yanchor 0.67 zoom 1.5
    hide black with eye_open

    translate None prologue_005:
        n "这种命运是通过抽签决定的。 \n神谕者的手在上界力量的引导下，总能给正确的孩子选择正确的命运。"
    translate None prologue_006:
        n "这个【审判】会引导他们最终成为命中注定要成为的人。"

    $ renpy.music.stop(fadeout=1.0)

    show black with eye_shut
    pause(0.2)
    scene black with dissolve

    pause(2)

    scene bg orphanage with Dissolve(3)
    play music "sounds/bgm/daytime.ogg" fadeout 1
    show tobias sur at left with dissolve
    window show
    $ quick_menu = True

    translate None prologue_007:
        t "雷恩，我们可以去外面玩吗？求求你啦！"
    show miah smi at center with dis2
    translate None prologue_008:
        m "我们保证天黑前就回来！"
    show raen n neu at right with dis2
    translate None prologue_009:
        "我快速瞥了眼女院长的方向，她向我微微点头。"
    translate None prologue_010:
        "我其实没有权力决定他们能做什么，但这从没能阻止他们来问我。好吧，我并不介意。"
    translate None prologue_011:
        "他们知道我永远无法拒绝他们。"
    show raen n smi with dis
    translate None prologue_012:
        rs"好吧，但确保在日落前回来…别靠近森林，好吗？"
    show tobias hap with dis
    translate None prologue_013:
        t "太好啦！谢谢雷恩！我们保证不会的！"
    show miah sur with dis
    translate None prologue_014:
        m "但为什么永远不能在那里玩？我们成年后能去吗？"
    show raen n sad with dis
    translate None prologue_015:
        rs "不…不能。"
    show miah sad with dis
    translate None prologue_016:
        m "为什么啊？这不公平！"
    translate None prologue_017:
        "我叹了口气，但感觉脸上不自觉地露出微笑。他们每次想出去玩都会问同样的问题，这份天真让我忍不住发笑。"
    translate None prologue_018:
        rs "过来，我解释给你们听。"



    scene bg orphanage with dissolve:
        zoom 2.0
        xanchor 200 yanchor 650



    translate None prologue_019:
        "我走向大厅尽头的长桌。桌面散落着纸张、儿童书籍和铅笔。其间埋着一张地图。"
    window hide dissolve




    show map with dissolve:
        size (1920, 1080)
        crop (163, 92, 1900, 1300)

    play sound "sounds/sfx/paperrustle.ogg" fadeout 1



    pause(0.5)

    $ about_AC.locked = False

    window show dissolve
    translate None prologue_020:
        rs neu "仔细看这张地图—我们位于中央的家园{a=set_entry:enc_places->about_AC}{color=#DA70D6}奥雷利亚卡维拉{/color}{/a}四面都被森林包围。"
    translate None prologue_021:
        rs "森林里满是坏人和危险动物。知道为什么吗？"

    show tobias sur with dissolve

    translate None prologue_022:
        t "因为神圣存在不庇护外界土地。"
    translate None prologue_023:
        rs "没错。上界存在只在我们身处奥雷利亚卡维拉时提供保护，这份庇佑不会延伸到领地之外。"
    translate None prologue_024:
        rs smi "没有人能在外面生存。这就是为什么大家都住在这里，在这里我们既安全又幸福。我知道现在这样说可能显得不公平，但等你长大就会明白，我们只是想保护你。"
    translate None prologue_025:
        rs "外面根本找不到任何东西。森林无边无际，而我们正好处于中心位置。"

    show miah sur at slightright with dissolve

    translate None prologue_026:
        m "整个世界的人都住在这里？"
    translate None prologue_027:
        "我想有些人可能每天回答相同的问题会觉得烦。但我不会。他们充满好奇心，我不能责怪他们。"
    translate None prologue_028:
        "我在他们这个年龄时，也向大孩子们问过一模一样的问题。"
    translate None prologue_029:
        rs "没错。一直都是这样的。"

    show map:
        size (1920, 1080)
        easein 2.0 crop (883, 0, 1036, 621)
    show tobias sad with dis

    translate None prologue_030:
        m "但那边这个地方是哪里？阿祖罗斯？"
    translate None prologue_031:
        "她指着城市北部的一个地方，地图上那个位置下方写着\"阿祖罗斯\"。"

    $ about_Azuros.locked = False

    translate None prologue_032:
        rs neu "啊..{a=set_entry:enc_places->about_Azuros}{color=#DA70D6}阿祖罗斯{/color}{/a}？我不太了解那里，但是.."
    translate None prologue_033:
        rs "当你老了—不是像我这样的老，而是年迈到极致—神明代言人和神谕者会因你一生的侍奉而奖赏你。所有长者都会去那里独居，享受宁静与安逸。"
    translate None prologue_034:
        rs "听说那里相当奢华，但我从未去过…只有被召唤时才能前往。"
    translate None prologue_035:
        "孩子们抬头看着我，显然想听更多。但实在没什么可说的了，没人真正知道那里是什么样子。"
    show tobias hap with dis
    translate None prologue_036:
        "神谕者告诉我们阿祖罗斯的奢华生活，这让我们更加努力工作，期盼有朝一日能进入那里。我们只知道这么多。"
    window hide dissolve



    scene bg orphanage with dissolve
    show miah sur at slightleft
    show tobias hap at center
    show raen n smi at slightright
    with dissolve



    window show dissolve
    translate None prologue_037:
        rs "好啦，趁太阳还没下山，出去玩吧！"

    hide miah with moveoutleft
    hide tobias with moveoutleft

    translate None prologue_038:
        "两人蹦蹦跳跳地冲出门口，一路尖叫奔跑着。"
    play sound "sounds/sfx/runningnormal.ogg" fadeout 1



    translate None prologue_039:
        "啊..他们真的很可爱。我很高兴在这里有这样一个美好的大家庭。托比亚斯、米娅，还有其他人…都像是我的兄弟姐妹。"
    show raen n neu with dis
    translate None prologue_040:
        "其实…严格来说我没有{i}真正{/i}的家人，但他们一直给予我足够的关爱。我是个被丢弃在路边的婴儿，最后来到了这里。"
    translate None prologue_041:
        "我从不知道父母是谁，但在这里长大的生活如此美好，实在很难为此感到愤怒。"
    translate None prologue_042:
        ma "雷恩，我能和你谈一会儿吗？"
    translate None prologue_043:
        "我抬头望向那个无比熟悉的声音。孤儿院的女院长。一位坚强的女性，却有着难以置信的爱心。她照顾了我一辈子，还有几十个其他孩子。"
    translate None prologue_044:
        rs "当然，院长。您有什么事吗？我希望今天让孩子们出去玩没有关系。"


    show matron clo at slightleft with dissolve


    translate None prologue_045:
        ma "不，不，不是关于那个。我只是想聊聊天。"
    show matron ope with dis
    translate None prologue_046:
        ma "你已经和我们在一起很久了。大约18年前的今天，我在阴沟里发现了你。"
    translate None prologue_047:
        "啊…真的已经那么久了吗…？确实我现在应该成年了，所以她可能觉得是我该离开的时候了…"
    show raen n sad with dis
    translate None prologue_048:
        rs "是的，已经很久了。如果给我几天时间，我会和孩子们道别，开始收拾行李。"
    translate None prologue_049:
        ma "什么？我想你误解了。"
    translate None prologue_050:
        "她把手伸进口袋，拿出一个小信封。"
    show matron smi with dis
    translate None prologue_051:
        ma "这是给你的。生日快乐。去买些好东西吧。"
    show raen n sur with dis
    translate None prologue_052:
        "她微笑着看着我，充满温暖，但很快就变成了皱眉。"
    show matron ang with dis
    translate None prologue_053:
        ma "还有，别以为你随时都能离开这里。每天回答那些问题会让我疯掉的！"
    translate None prologue_054:
        "她把信封塞进我手里，然后走开了。一如既往地生硬。"
    show raen smi with dis
    translate None prologue_055:
        rs "非常感谢您，院长！那我就出去买您之前让我买的杂货。很快就回来！"
    translate None prologue_056:
        "当我推开门时，那扇老旧沉重的门发出呻吟声。我走出去，呼吸新鲜空气，享受阳光。"
    play sound "sounds/sfx/dooropen.ogg" fadeout 1
    stop music fadeout 1.0




label outside_aurelia:
    scene bg aureliacavelladay with Fade(0.5,1,1):
        size (1920, 1080) crop (700, 0, 900, 500)
        linear 20 crop (500, 0, 900, 500)
    play sound "sounds/sfx/morningbird.ogg" fadeout 3



    translate None prologue_057:
        "太阳高挂在天空，一阵宜人的微风吹过城市。这是美好的一天。"
    translate None prologue_058:
        "但我忍不住注意到昨天还盛开的花已经开始凋谢。也许今早没人给它们浇水？"
    translate None prologue_059:
        rs neu "不管怎样…"
    translate None prologue_060:
        "我猜这意味着今天是我的生日。并不是我没有意识到它快到了，但它并不是我最关心的事。对我来说从来都不是什么大事。"
    window hide dissolve

    scene gallery_1 with dissolve:
        size (1920, 1080) crop (200, 550, 900, 500)

    window show dissolve
    translate None prologue_061:
        "我仔细看着手中的信封。白色而简单。这…是我第一次收到生日礼物。"
        "我害怕打开它。我几乎想让它保持原封不动…突然收到东西有点可怕。"
    translate None prologue_063:
        "虽说好奇心已经快占据上风了。这向来是我的毛病…"
    translate None prologue_064:
        rs "三…二…一…"
    translate None prologue_065:
        rs "拆！"
    translate None prologue_066:
        "我一把撕开封口。"

    play sound "sounds/sfx/paperrip.ogg" fadeout 1
    play music "sounds/bgm/harp.ogg" fadeout 1


    scene gallery_2 with dissolve:
        size (1920, 1080)
        crop (200, 550, 900, 500)
        easein 5.0 crop (200, 500, 900, 500)


    translate None prologue_067:
        rs "天啊…众神在上…"
    translate None prologue_068:
        "里面装着10马克—比我这辈子见过的钱都多，还有一封写给我的信。"
    translate None prologue_069:
        rs "让我看看…亲爱的雷恩…"
    window hide dissolve


    scene gallery_2 with dissolve


    window show dissolve
    translate None prologue_070:
        ma "亲爱的雷恩："
    translate None prologue_071:
        ma "生日快乐，亲爱的。很抱歉我们只能给你这么微薄的礼物，但希望够你买些喜欢的东西。孩子们一直都在为你攒钱呢。"
    translate None prologue_072:
        ma "自从发现你的那天起，我就一直把你当作亲生儿子。现在你已成年，很快也会配对姻缘，拥有自己的孩子。"
    translate None prologue_073:
        ma "在那天到来前，请继续留在孤儿院吧。没有你的话，我和孩子们都会手足无措的。"
    translate None prologue_074:
        ma "我相信如果你的父母看到现在的你，一定会像我一样为你骄傲。"
    translate None prologue_075:
        ma "爱你的阿拉拉院长"
    window hide dissolve


    scene bg aureliacavelladay with Dissolve(1)

    window show dissolve
    translate None prologue_076:
        rs sad "..呃…"

    $ about_Letter.locked = False

    translate None prologue_077:
        "我完全控制不住。眼泪瞬间夺眶而出，浸湿了{a=set_entry:enc_lore->about_Letter}{color=#DA70D6}信纸{/color}{/a}。"
    translate None prologue_078:
        rs "..谢谢你们…"
    translate None prologue_079:
        "他们竟为我存下这么多钱…绝不能辜负他们。我要去买些好东西和大家分享。"
    translate None prologue_080:
        "我暗下决心，将信封和钱币贴身藏好，朝市场走去。"
    play sound "sounds/sfx/runningstreet.ogg" fadeout 1





    scene bg townsquare with Fade(0.5,1,1)
    translate None prologue_081:
        "市场就在奥雷利亚卡维拉城西侧，穿过镇广场即是。镇广场是新来孩童接受审判的地方，也是神谕者宣读神谕之处。"
    translate None prologue_082:
        u "上界存在为你们对寒舍的奉献献上赞歌。"
    translate None prologue_083:
        u "同样，祂们恳请你们继续献出生命，因祂们庇护着你们免受林间潜伏的邪恶侵害。"
    window hide dissolve


    stop music fadeout 1
    play sound "<from 1 to 10>sounds/sfx/crowdmurmur.ogg" fadeout 1


    scene gallery_3 with dissolve:
        xanchor 0.1 yanchor 0.33 zoom 1.5
        linear 15.0 yanchor 0.1

    pause(0.5)
    window show dissolve
    translate None prologue_084:
        rs sur "啧…看起来神谕者正在宣读神谕…"
    translate None prologue_085:
        "他通身金银白袍，仪典长袍尽显华贵。银白长发一丝不苟地垂在身后。"

    $ about_AC._text.append("据说最近几个月大量庄稼枯萎。从未如此严重过，人们开始担心粮食储备。")

    translate None prologue_086:
        d "我理解你们对{a=set_entry:enc_places->about_AC}{color=#87CEEB}歉收作物{/color}{/a}的沮丧。但请不要担心，因为上界存在做每件事都有其理由。很快，你们就会明白他们为何让你们经历这些考验。"


    scene gallery_3 with dissolve
    play sound "sounds/VA/YesLordSpeaker.ogg" fadeout 8


    translate None prologue_087:
        "人群" "\"是的，神谕者大人！\""
    translate None prologue_087a:
        "歉收的作物？嗯…我想我从女院长那里听到了一些情况。这似乎是几百年来第一次收成如此糟糕，有人担心这个冬天我们的粮食会不够。"
    translate None prologue_088:
        rs smi "是，神谕者大人！"
    translate None prologue_089:
        "不知不觉中，我已站在人群中，与其他居民一起高喊着。他雄辩而优美的演讲几乎让人着迷。"
    translate None prologue_090:
        "奥雷利亚卡维拉最受尊敬的人，地位仅次于神明。仅仅站在他面前就令人惊叹。他讲话时，整个人群都如痴如醉。我沉浸其中，甚至没注意到他的演讲已近尾声。"
    translate None prologue_091:
        d "时候一到，你们都将获得阿祖罗斯带来的自由作为奖赏。记住这一点，我希望你们能继续供奉和履行职责。谢谢。"
    play sound "sounds/sfx/crowdapplause.ogg" fadeout 1
    translate None prologue_092:
        "演讲结束时，人群中爆发出热烈掌声。他微笑着向人群挥手致意，目光扫过在场每个人。"


    scene gallery_4 with dis2:
        subpixel True xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 0.99 zoom 1.02 rotate None


    translate None prologue_093:
        "当他的目光与我相遇之前，我也跟着人群挥手欢呼。"
    play sound "sounds/sfx/heartbeat.ogg" fadeout 1

    scene gallery_4 blurred onlayer background with vpunch:
        subpixel True
        xpos 0.5 ypos 1.0
        xanchor 0.5 yanchor 0.99
        zoom 1.02

    translate None prologue_094:
        "几乎瞬间，一阵战栗传遍我的全身。"


    $ all_moves(x_express=Wiggle(freq=.2, amp=100), y_express=Wiggle(freq=.3, amp=50), z_express=Wiggle(freq=.2, amp=3))

    translate None prologue_095:
        rs hur "呃啊…"

    play sound "sounds/sfx/pain.ogg" fadeout 1
    $ renpy.music.play("sounds/sfx/pain.ogg", channel="sfx2", loop=False)

    translate None prologue_096:
        "战栗变成了灼热，灼热又化作燃烧。我还没反应过来就已蜷缩在地，拼命喘息却感觉肺部在燃烧。每次呼吸都让内脏更加灼痛。"

    $ renpy.music.play("<from 0 to 5>sounds/sfx/crowdmurmur.ogg", channel="sfx1")
#    play sound "<from 1 to 10>crowdmurmur.ogg" fadeout 1
#    play sound "pain.ogg" fadeout 1
    translate None prologue_097:
        "周围所有人都在看着我，但最可怕的是他的眼睛。神谕者的眼睛。我仍能感受到他穿透我的目光。仿佛…他能看透一切。甚至灵魂深处埋藏的秘密。"
    translate None prologue_098:
        "我必须…我现在必须逃离！"
    window hide dissolve


    pause(0.5)
    scene black with swipe
    $ renpy.music.play("sounds/sfx/runningstreet.ogg", channel="sfx2")


    window show dissolve
    translate None prologue_099:
        "我强迫自己爬起来，拼命跑进附近的小巷。"
    window hide dissolve

    $ all_moves(x_express=Wiggle(freq=.2, amp=150), y_express=Wiggle(freq=.3, amp=100), z_express=Wiggle(freq=.2, amp=3))

    $ persistent.bgalley= True

    pause(0.5)
    show bg alley blurred onlayer background with w21:
        xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 0.9 zoom 1.4

    window show dissolve
    translate None prologue_100:
        rs hur "呼哧，呼哧…"
    translate None prologue_101:
        "我感觉周围世界逐渐变暗、模糊。"
    $ renpy.music.play("sounds/sfx/fallonground.ogg", channel="sfx1")
    show bg alley blurred with vpunch
    translate None prologue_101a:
        "我像胎儿般蜷缩在地上啜泣。"
    translate None prologue_102:
        "突然，疼痛开始移动。它全部集中到我的左臂，强度堪比之前所有痛苦的总和。"
    translate None prologue_103:
        rs "有…有人吗…求求你…"
    translate None prologue_104:
        "我浑身颤抖，紧紧抓着手臂忍受着灼烧般的疼痛，直到眼前陷入黑暗。"
    window hide dissolve




    pause(0.5)
    scene black with eye_shut


    $ renpy.sound.stop(fadeout=1.5)

    pause(2)
    translate None prologue_105:
        n "你必须…保护…"
    translate None prologue_106:
        n "….觉醒…命运…"
    translate None prologue_107:
        n "….审判…"
    pause(2)




    scene bg alley night with eye_open
    show black with eye_shut
    hide black with eye_open

    pause(0.5)
    window show dissolve
    translate None prologue_108:
        rs hur "........"
    translate None prologue_109:
        "我眨了眨眼，试图弄清自己身在何处。当我坐起身时，笼罩视野的黑暗慢慢消退。"
    translate None prologue_110:
        rs "对了…我记得在镇广场听\"神谕者\"演讲，然后…"
    translate None prologue_111:
        "等等…我是晕倒在这里了吗？我迅速检查全身，疼痛感已经完全消失。"
    translate None prologue_112:
        rs sur "咦..？"
    window hide dissolve


    scene gallery_5 with dissolve:
        size (1920, 1080) crop (500, 443, 960, 540)
        easein 8 crop (500, 343, 960, 540)
    play music "sounds/bgm/scary.ogg" fadeout 1


    pause(0.5)

    window show dissolve
    translate None prologue_113:
        rs "这…这是什么？"


    window hide dissolve
    pause(0.25)
    show raenarm2 dark with dissolve:
        xpos 0.55 ypos 1.0 xanchor 0.5 yanchor 1.0
    with dissolve

    window show dissolve
    translate None prologue_114:
        "当我凑近观察，发现手臂上多了些原本不存在的东西。"

    $ about_Markings.locked = False

    translate None prologue_115:
        "某种…{a=set_entry:enc_mysteries->about_Markings}{color=#DA70D6}奇异的神之刻印{/color}{/a}正沿着我的手臂延伸。这些符号我从没见过。"
    translate None prologue_116:
        "第一反应是想把它们刮掉，但它们就像烙在皮肤上似的，根本擦不掉。"
    window hide dissolve

    pause(0.1)
    show gallery_6 with dissolve
    window show dissolve
    translate None prologue_117:
        rs "我得…回孤儿院。他们肯定不知道我去哪了.."
    translate None prologue_118:
        "我离开时太阳还在正空，现在却已入夜。我昏迷了多久…？"
    window hide dissolve

    scene bg alley night with fade
    window show dissolve
    translate None prologue_119:
        "我扶着墙壁慢慢站起，试图保持平衡。"
    show bg alley night with hpunch
    translate None prologue_120:
        rs hur "呃…."
    translate None prologue_121:
        "灼烧感消失了，只剩下浑身酸痛。八成是摔在地上造成的…"
    translate None prologue_122:
        rs neu "这是哪？或许该顺着来路回去.."
    play sound "sounds/sfx/runningnormal.ogg"
    translate None prologue_123:
        "穿过浓重的黑暗，我沿着小巷原路折返，多么希望这一切只是场噩梦。"
    window hide dissolve

    scene bg townsquarenight with Fade(1, 0.5, 1)
    show raen n dim neu at center with dissolve

    window show dissolve
    translate None prologue_124:
        "摸索片刻后，我竟回到了镇广场。零星的路人还在赶着最后的采买，或三三两两闲聊。"
    show raen n dim sad with dis
    play music "sounds/bgm/night.ogg" fadeout 1
    translate None prologue_125:
        "我把烙着印记的手臂紧贴在胸前，确保没人能看见。"
    translate None prologue_126:
        "不知道被人发现会怎样。连我自己都搞不清这是什么状况。我止不住紧张地四处张望，活像个怕被逮住的小偷。"
    translate None prologue_127:
        "正因如此，当我迎面撞上某人摔倒在地时，根本来不及反应。"

    play sound "sounds/sfx/fallonground.ogg"
    show layer master at hpunch
    show raen n dim hur at shake with dis

    show raen with dis:
        alpha 1
        pause 0.5
        easein 0.5 alpha 0

    play sound "sounds/sfx/fallonground.ogg"
    translate None prologue_128:
        rs "痛..！"

    show leos n neu dim at slightright with dis3

    translate None prologue_128a:
        "我抬头看向站在面前的人。"
    window hide dissolve

    scene bg townsquarenight:
        xpos 0.5 ypos 1.0 xanchor 0.67 yanchor 0.77 zoom 1.7
    show leos m dim neu at center
    with Dissolve(1)


    window show dissolve
    translate None prologue_129:
        "那是个高瘦男子，约莫二十来岁，暗红色长发垂落腰际，面容严肃。"
    translate None prologue_130:
        rs hur "啊，非常抱歉！"
    translate None prologue_131:
        "他在那儿站了片刻，就那么盯着我。他的目光令我紧张。就像一条蛇在打量猎物。"
    translate None prologue_132:
        "这时我才注意到他凝视的不是我，而是我的手臂。"
    translate None prologue_133:
        rs sur "啊！"
    translate None prologue_134:
        "我本能地将手臂紧抱在胸前。"


    show leos m dim smi with dissolve


    translate None prologue_135:
        leosu "这儿就是你平常撞人的地方吗，还是说你有几个特别钟意的撞人地点？"
    translate None prologue_136:
        rs sad "什么…？不，我一般不撞—"
    translate None prologue_137:
        leosu "啊哈，看来这是种特权了。我感到很幸运。"
    translate None prologue_138:
        "我嘴巴半张着呆住了。这人怎么回事？我从来没见过这么…这么…粗鲁的人！"
    translate None prologue_139:
        rs sad "我…我很抱歉撞到了你。我只是想快点回家去—"
    show leos m dim smu with dis
    translate None prologue_140:
        leosu "去藏起你手臂上那个东西？"
    translate None prologue_141:
        "又一次，我只能震惊地看着他。我们对视了片刻，随后他向我伸出手来。"
    window hide dissolve

    scene gallery_7 with Fade(1, .5, 1):
        size (1920, 1080) crop (720, 531, 1012, 548)
        linear 12.0 crop (720, 100, 1012, 548)

    window show dissolve
    translate None prologue_142:
        leosu "让我扶你起来。要是趴得太久，别人会把你当成风景的一部分。"
    window hide dissolve
    scene gallery_7 with dissolve


    menu:

        "握住他的手":
            $ leos_relationship +=1
            jump leos_one_yes

        "自己站起来":
            jump leos_one_no

label leos_one_yes:


    scene gallery_8 with dissolve


    window show dissolve
    translate None prologue_145a:
        "我犹豫了一瞬，最终还是轻轻抓住了他的手。他把我拉了起来，这时我才真切感受到他有多高大。"
    translate None prologue_146a:
        rs "呃…谢谢.."
    translate None prologue_147a:
        leosu "以后别总表现得这么鬼鬼祟祟的。谁知道会招来什么人。"
    translate None prologue_148a:
        "他说这话时脸上的假笑令人不适。我觉得我得赶紧离开这儿。"
    translate None prologue_149a:
        rs "当然。我现在真的该走了，我已经迟到了。再次为引起的骚动道歉。"
    jump choiceonedone


label leos_one_no:


    scene gallery_7 with dissolve


    window show dissolve
    translate None prologue_145b:
        "我看着他伸出的手，但决定不理会。"
    translate None prologue_146b:
        "谁需要这么无礼的人帮忙？"
    translate None prologue_147b:
        rs "多谢，不过我自己完全能站起来。"
    translate None prologue_148b:
        "我站起身，拍了拍衣服上的灰。"
    translate None prologue_149b:
        rs "我要走了。给你添麻烦了。"
    jump choiceonedone

label choiceonedone:

    window hide dissolve

    scene bg townsquarenight with dissolve
    show raen n dim sad at slightright
    show leos n dim neu at slightleft
    with dissolve

    window show dissolve
    translate None prologue_150:
        "我迅速转身离开。这家伙根本不值得我浪费时间。"
    show leos n dim sur with dis
    translate None prologue_151:
        leosu "等一下。我…知道你手臂上那些刻印的事。"
    translate None prologue_152:
        "我猛地转回来面对他，速度快得前所未有。"
    show raen n dim sur with dis
    show leos n dim smi with dis
    translate None prologue_153:
        rs "啊…你知道？！"
    show raen n dim emb with dis
    translate None prologue_154:
        "糟糕…"
    show raen n dim neu with dis
    translate None prologue_155:
        rs "呃，我是说…你知道？你了解些什么？"
    show leos n dim neu with dis
    translate None prologue_156:
        leosu "我知道神谕者的私人藏书室里收藏着用相同刻写符号编纂的典籍。他今晚破例允许访客阅览，仅限今晚。"
    translate None prologue_157:
        leosu "真遗憾你看起来这么忙…这可能是最后一次向公众开放了。总之，晚安。"


    hide leos with dissolve
    show raen at center with move


    $ about_Leos.locked = False

    translate None prologue_158:
        "那个{a=set_entry:enc_people->about_Leos}{color=#DA70D6}红发男子{/color}{/a}转身消失在阴影中。只留下他的话语悬在空气里。"
    translate None prologue_159:
        rs "呃…我想再绕一小段路也无妨，反正已经迟到了…"
    translate None prologue_160:
        "我咬着嘴唇，仔细思索着他的话。"
    show raen n dim sad with dis
    translate None prologue_161:
        "我绝不能错过这个机会！如果这是唯一能弄清这些神之刻印含义的方法，那么…"
    translate None prologue_162:
        "下定决心后，我转身朝神谕者的档案馆方向走去。"
    window hide dissolve

    scene black with dissolve

    window show
    play sound "sounds/sfx/walkingstreet.ogg"
    translate None prologue_163:
        "穿过城镇走到神谕者的宫殿花了不少时间。宫殿很大，但几乎空无一人，因为他是唯一的居住者。"

    $ about_Archives.locked = False

    translate None prologue_164:
        "不过这是我第一次听说有人被允许进入他的{a=set_entry:enc_places->about_Archives}{color=#DA70D6}私人档案馆{/color}{/a}。我想即使是领主也没有完全开放权限。"
    translate None prologue_165:
        "也许今天终究是我的幸运日…？"
    play sound "sounds/sfx/doorknock.ogg"
    translate None prologue_166:
        "我走到门前轻轻敲门。"
    translate None prologue_167:
        rs neu "…有人吗？神谕者？您在家吗？"
    play sound "<from 0 to 2.5>sounds/sfx/dooropen2.ogg"
    translate None prologue_168:
        "当我敲门时，门自动打开了。它原本就没锁，我能看见里面的灯光。"
    translate None prologue_169:
        rs neu "看来他可能已经在里面，正给别人展示档案馆…打扰了。"
    play sound "sounds/sfx/walkinghall.ogg"
    translate None prologue_170:
        "我把门再推开些，沿着走廊来到另一扇虚掩的门前。"
    window hide dissolve


    scene bg archives2 with Dissolve(1)


    window show dissolve
    translate None prologue_171:
        "进入房间时，我震惊得差点跌倒。幸好没有，否则这将是我今天第三次摔倒了…"
    translate None prologue_172:
        "书架上摆满了直达天花板的书籍。每处平面上都散落着典籍和文件，烛光摇曳产生的朦胧光线更增添了我的惊叹。"
    translate None prologue_173:
        "太美了。我这辈子从没见过这么多书。"


    show bg archives2 with Dissolve(1):
        size (1920, 1080) crop (800, 500, 900, 500)


    translate None prologue_174:
        "我继续往里走，用手指触摸书脊，闻着房间里发霉的气味。 "
    translate None prologue_175:
        "房间中央的桌面上散落着各式书籍。我走近查看。"
    translate None prologue_176:
        "我读到一些书名：《简史》、《锡德卡汉》、《血脉》。这里有成千上万本我想读的书。"
    translate None prologue_177:
        "可惜他只允许访客参观一天。"


    show raen n neu with dis2


    play sound "sounds/sfx/paperrustle.ogg" fadeout 1
    translate None prologue_178:
        "我拿起第一本书《简史》，慢慢翻阅着，每一页都读上几句。"
    translate None prologue_179:
        "看起来有些页码缺失了。前一刻还在谈论宫殿的建造，下一页就跳转到栖息在这片土地上的动物。"
    translate None prologue_180:
        rs "让我看看…建国史？…奥雷利亚卡维拉王国由希昂王子在奥古斯都月的第二个月夜建立…"
    translate None prologue_181:
        "有意思…我从没听说过王国最初是谁建立的。如果这本书记载了这个，那它一定非常古老。"
    show raen n sur with dis

    $ about_Archives._text.append("我读的第一本书叫《简史》，主要讲述了奥雷利亚卡维拉的历史，从皇家宫殿的建造到本土动物。书中还提到\'奥雷利亚卡维拉王国由希昂王子在奥古斯都月的第二个月夜建立\'。 \n \n第二本名为《锡德卡汉》的书更像日记，但我无法阅读。书内全被黑色墨水浸染。")

    translate None prologue_182:
        "我将{a=set_entry:enc_places->about_Archives}{color=#87CEEB}第一本书{/color}{/a}放回原位，转而拿起《锡德卡汉》。它与其他书籍不同，是本日记。当我打开时，发现每页都被黑色墨水覆盖，无法阅读。"
    translate None prologue_183:
        "看起来像是有人不小心打翻了墨水瓶，或者…是故意的？"
    translate None prologue_184:
        "接下来是《血脉》。我从书堆中拿起它。"
    translate None prologue_185:
        "我直接翻到中间。老实说书名本该让我猜到内容的。这是某种出生记录，记录着看似高贵的血脉谱系。"
    translate None prologue_186:
        "这一页的血脉从\"锡德卡汉的希昂国王，10XX年\"开始，延续到更近代。最后记录的是\"卡斯皮安王子\"。"
    translate None prologue_187:
        rs "我不断读到这个锡德卡汉，不知道它是什么意思…等等…"
    show raen n neu with dis
    translate None prologue_188:
        "希昂王子是我们城市的建立者，对吧？那这一定是王室血脉，但…为什么只从500年前开始记录？奥雷利亚卡维拉自古就存在，已有数千年历史…"
    translate None prologue_189:
        "这里肯定有错。在那之前人们总得生活在某处，而且谁都知道在我们的保护区外没有适合居住的地方。"
    translate None prologue_190:
        "只有这里，和那片森林。"
    translate None prologue_191:
        "我将书页翻至下一页。"
    show raen n sur with dis
    translate None prologue_192:
        rs "啊..！"
    translate None prologue_193:
        "页面上布满奇异的刻痕，那种我从未见过的文字。我匆忙撸起袖子与之比对，发现了一些相同的字符。"
    translate None prologue_194:
        "这种排版与王族谱系十分相似，所以…这必然也是一份名单，但记载的是谁？"
    translate None prologue_195:
        rs "看起来这份名单最后添加的记录距今已有19年…"
    play sound "sounds/sfx/walkinghall2.ogg"
    translate None prologue_196:
        "我太过专注于解读其中的含义，以至没听见身后开门的声音。"
    stop music fadeout 1
    show raen n sur with dis2
    translate None prologue_197:
        u "瞧瞧，瞧瞧。我的档案室里混进了不速之客？"
    window hide dissolve

    scene bg archives2 with Dissolve(1)
    show ds n neu with Dissolve(1)

    $ about_Archives._text.append("我又拿起一本名为《血脉》的书。它有些破旧磨损，上面有手写的笔记和图表。记录着我猜测可能是皇室血脉的信息，最后的条目标题是37年前的\'卡斯皮安\'。当我翻到下一页时，映入眼帘的是一整页与我身上相似的神之刻印，最后的条目日期是19年前。 \n \n我不知道它们是否有关联，但不知为何，卡斯皮安的名字特别引起我的注意。")

    window show dissolve
    translate None prologue_198:
        "我猛地转身面向那个声音。不是别人，正是神谕者本人。我从未如此近距离地见过他。我本能地将书藏进了斗篷里。"
    translate None prologue_199:
        rs sur "啊，神谕者！"
    translate None prologue_200:
        "出于敬意，我单膝跪地。"
    translate None prologue_201:
        rs smi "呃…非常感谢您今天开放档案馆，我从没见过这么多书。"
    show ds n sur with dis
    translate None prologue_202:
        d "抱歉？开放档案馆？"
    translate None prologue_203:
        "他一脸困惑地看着我。"
    translate None prologue_204:
        rs sad "没错。镇广场上的那个人…他告诉我…"
    translate None prologue_205:
        "等等，什么？我确信自己没有听错。他说的是对所有人开放。那…为什么神谕者看起来对此一无所知？"
    show ds n neu with dis
    translate None prologue_206:
        d "我不知道你听谁说了什么，但除了我之外，任何人都不得查阅我的档案。"
    play music "sounds/bgm/sad.ogg" fadeout 1
    translate None prologue_207:
        "在他身后，我看到守卫从四面八方涌来。"
    translate None prologue_208:
        d "擅闯禁区是背叛行为。对背叛家园之人唯一的惩罚就是死刑。"
    translate None prologue_209:
        "当他说出「死刑」这个词时，我感到一阵天旋地转。"
    translate None prologue_210:
        "死…死刑？我从未听说过有人被判死刑！不，不，这完全错了！"
    translate None prologue_211:
        rs wor "不，等-等一下…求你了，我没有背叛-我只是想阅读-"
    translate None prologue_212:
        d "我不知你此来有何意图，但我必须为居民和诸神的利益采取行动。卫兵们，拿下他。"
    translate None prologue_213:
        u "且慢，神谕者。"
    translate None prologue_214:
        "我看见有人穿过卫兵队列，挤到人群前方。是我们的领主大人，他与神谕者共同治理这片土地。"
    translate None prologue_215:
        ls "我们并未准备立即举行公开处决，神谕者大人。多年来我们都不需要这种刑罚。不如将其流放，任他自生自灭于森林亦是死路一条。"
    translate None prologue_216:
        "我的心沉到谷底。原以为他是来解救我的，这提议却比死刑更残酷。在我有生之年，从未有人遭受流放之刑。"
    translate None prologue_217:
        "在野外遭受的折磨，远比在此迅速绞死要痛苦得多。"
    translate None prologue_218:
        rs "求您…我并非有意—"
    show ds n ang with dis
    translate None prologue_219:
        d "肃静。"
    translate None prologue_220:
        "他站在我面前，冰冷的目光刺穿我的灵魂。不禁想起早先在集市四目相对的场景，此刻我怯懦地移开视线。"
    translate None prologue_221:
        d "或许你是对的。与其让罪犯的鲜血玷污我们的土地，不如让大自然代为惩戒。"
    translate None prologue_222:
        d "卫兵，架住他双臂。我将亲自押送他到森林边界。"
    translate None prologue_223:
        "我被魁梧的卫兵钳制双臂，毫无挣脱可能。只能被迫跟随神谕者前行，全程被人从背后推搡。"


    scene  bg aureliacavellanight with Fade(1,1,1)


    translate None prologue_224:
        "游街示众时我羞愧垂首，途经的每扇窗户后都有窥探的面孔。"
    translate None prologue_225:
        "我唯一能做的就是盯着地面。"
    translate None prologue_226:
        "谁能责怪他们呢？换作是我也会驻足观望。"
    window hide dissolve




    scene bg forestedge with Dissolve(1)
    show ds n dim neu at slightleft
    show raen n dim sad at slightright
    with Dissolve(1)




    window show Dissolve(.5)
    translate None prologue_227:
        d "松绑。你们可以回去了，接下来交给我。"
    translate None prologue_228:
        "两名卫兵行礼后列队返城。待其背影消失，他开口道："
    translate None prologue_229:
        d "我不明白你为何作出此等行径。但你必须承担后果。"
    show ds n dim sad with dis2
    translate None prologue_230:
        d "或许你觉得不公。但早些见识这世界的残酷对你未必是坏事。"
    window hide dissolve

    scene bg forestedgeb
    with dissolve
    show ds n dim sad with dissolve

    window show dissolve
    translate None prologue_231:
        "我抬头望向他面容，完全猜不透他的心思，却不由自主地沉溺其中。"
    play sound "sounds/sfx/skintouch.ogg"
    translate None prologue_232:
        "他伸出手，指尖轻轻抚过我的下巴。近看时，他长长的睫毛在风中微颤，整个人恍若谪仙，仿佛他自己就是上界存在的一员。"
    translate None prologue_233:
        d "你和你父亲简直一模一样。"


    scene bg forestedge
    show ds n dim neu
    with Dissolve(1)


    translate None prologue_234:
        "说罢他松开我的脸，转身离去。"
    translate None prologue_235:
        d "跑吧。跑吧，别回头。就像他当年那样。"


    scene bg forestedge with dis3


    play sound "<from 0 to 3>sounds/sfx/walkingstreet.ogg"
    translate None prologue_236:
        "他的背影渐渐消失在城镇里。我想过原路返回，躲回孤儿院，可所有人都看见我被那样押着穿过城镇。"


    scene black with dis3


    translate None prologue_237:
        "别无选择。"
    translate None prologue_238:
        "我不得不离开，身上只有单薄的衣衫、女院长的信封、从神谕者那里意外偷来的书，以及满心悔恨。"


    if achievement.has("prologue_end"):
        pass
    else:
        $ renpy.display_notify("成就解锁：隐秘世界")

    python:
        achievement.grant("prologue_end")
        achievement.sync()



    window hide dissolve
    pause(2)
    stop music
    jump chapter_one_start
