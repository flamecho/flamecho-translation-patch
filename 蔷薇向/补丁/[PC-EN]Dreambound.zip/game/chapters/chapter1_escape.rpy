################################
## MOUSE CURSOR NOTES
## In Images, define each cursor image
## The name for each should match whatever iteminhand can be set to
## In Inventory, clicking at item should change iteminhand to the right image (thus changing the HOVER cursor to the same) and should change default cursor
## In each imagebutton, if iteminhand == None, use the original hover cursor, otherwise use whatever iteminhand is set to


init:
    $ iteminhand = "None" # Start with nothing in hand
    $ chapter = 1 # Change to current chapter
    $ default_mouse = "default"

    # Items clicked tracker - can be picked up
    $ schedule = False
    $ screwdriver = False
    $ tablekey = False
    $ gloves = False
    $ hexagonpiece = False
    $ candle = False
    $ litcandle = False

    $ waitpaper  = False # This one stops the paper from showing until the right time
    $ gratewait = False # This one stops the grate from showing until the right time
    $ boxwait = False # This one stops the puzzle box from showing until the right time


    # Items clicked tracker - can't be picked up
    $ barsclicked = False
    $ brickclicked = False # when true, weights will break it
    $ ballclicked = False
    $ grateclicked = False
    $ boxclicked = False
    $ wallscrawlclicked = False
    $ bedsidescrawlclicked = False
    $ brickbroken = False
    $ grateunlocked = False
    $ puzzleboxcomplete = False
    $ drawerunlocked = False
    $ keystried = False
    $ bedpuzzlefixed = False
    $ bedpuzzleclicked = False
    $ bedpuzzlecomplete = False
    $ bucketclicked = False
    $ bucketbottleretrieved = False


    $ keysdropped = False # this is set to true once the keys are burnt down with the candle

    $ puzzleboxcount = 0 # if 8, clear our puzzle player list
    $ puzzlebox1hint = 1
    $ puzzlebox2hint = 1


############################################


define puzzleplayer = []
default puzzleanswer = ["3", "1", "4", "2", "2", "4", "1", "3"]



default puzzleanswerbed = [3, 3, 4, 2]
define bedpuzzlenumber1 = 1
define bedpuzzlenumber2 = 1
define bedpuzzlenumber3 = 1
define bedpuzzlenumber4 = 1
define puzzleplayerbed = [bedpuzzlenumber1, bedpuzzlenumber2, bedpuzzlenumber3, bedpuzzlenumber4]


############################################


label chapter1escape:
    $ quick_menu = False
    window hide dissolve
    $ chapter = 1 # set the chapter at the start of each chapter
    $ _skipping = False

label chapter1escaperepeat:
    scene bg prisonroom onlayer farback:
        zoom 1.1 yalign 0.5 xalign 0.5

    if schedule == False and barsclicked == True:
        show note onlayer farback:
            zoom 1.1 yalign 0.5 xalign 0.5

    show bars onlayer farback:
        zoom 1.1 yalign 0.5 xalign 0.5

    show bedsidetable onlayer farback:
        zoom 1.1 yalign 0.5 xalign 0.5

    show bed onlayer farback:
        zoom 1.1 yalign 0.5 xalign 0.5



    if brickbroken == False:
        show brick onlayer farback:
            zoom 1.1 yalign 0.5 xalign 0.5

    if brickbroken == True and grateunlocked == False:
        show grate onlayer farback:
            zoom 1.1 yalign 0.5 xalign 0.5



    if grateunlocked == True:
        show box onlayer farback:
            zoom 1.1 yalign 0.5 xalign 0.5
    show balls onlayer farback:
        zoom 1.1 yalign 0.5 xalign 0.5

    show scribble onlayer farback:
        zoom 1.1 yalign 0.5 xalign 0.5

    if bedpuzzlefixed == False:
        show finbox onlayer farback:
            zoom 1.1 yalign 0.5 xalign 0.5

    if bedpuzzlefixed == True:
        show finbox onlayer farback:
            zoom 1.1 yalign 0.5 xalign 0.5

    show bucket2 onlayer farback:
        zoom 1.1 yalign 0.5 xalign 0.5

    with dissolve

    $ renpy.transition(dissolve)
    $ renpy.call_screen("prisonescape", _layer="farback") # calls the escape room segment


screen prisonescape:
    on "show" action Show("inventoryshow", dissolve)
    on "hide" action Hide("inventoryshow", dissolve)


##################################
########## IMAGEBUTTONS ##########
##################################

########## Paper outside bars ##########
    if iteminhand == "None" and barsclicked == True and schedule == False and waitpaper == True: # if nothing in hand, the bars have been clicked and you haven't already picked up the schedule
        vbox yalign 0.5 xalign 0.5:
            imagebutton auto "images/bgs/escape1/note_%s.png" action [SetVariable("schedule", True), Jump("schedulescene1")] tooltip "Paper":
                if iteminhand == "None":
                    mouse "imagemap"
                else:
                    mouse "[iteminhand]"
                focus_mask True at bgzoom

########## Bars actions ##########
    if iteminhand == "None" and barsclicked == False or iteminhand == "None" and barsclicked == True or iteminhand == "note" or iteminhand == "screwdriver" and keysdropped == False or iteminhand == "key" and keystried == False or iteminhand == "key" and keystried == True or iteminhand == "gloves" or iteminhand == "hexagon" or iteminhand == "candle" or iteminhand == "litcandle": # First time you click on the bars
        vbox yalign 0.5 xalign 0.5:
            imagebutton auto "images/bgs/escape1/bars_%s.png":
                if iteminhand == "None" and barsclicked == False: # first time bars clicked
                    action [SetVariable("barsclicked", True), Jump("barsscene1")] tooltip "Bars"
                elif iteminhand == "None" and barsclicked == True: # all times after you click on the bars with nothing in hand
                    action Jump("barsscene2") tooltip "Bars"
                elif iteminhand == "note": # if note in hand click on bars
                    action Jump("barsnotescene") tooltip "Bars"
                elif iteminhand == "screwdriver" and keysdropped == False: # if note in and the keys arent yet on the ground
                    action Jump("barsscrewscene") tooltip "Bars"
                elif iteminhand == "key" and keystried == False:
                    action [SetVariable("keystried", True), Jump("barkeyscene1")] tooltip "Bars"
                elif iteminhand == "key" and keystried == True:
                    action Jump("barkeyscene2") tooltip "Bars"
                elif iteminhand == "gloves":
                    action Jump("barsglovesscene") tooltip "Bars"
                elif iteminhand == "hexagon":
                    action Jump("barshexagonscene") tooltip "Bars"
                elif iteminhand == "candle":
                    action Jump("barscandlescene") tooltip "Bars"
                elif iteminhand == "litcandle":
                    action Jump("barslitcandlescene") tooltip "Bars"

                if iteminhand == "None":
                    mouse "imagemap"
                else:
                    mouse "[iteminhand]"

                focus_mask True at bgzoom


#### Bedside Table Actions ###

    if iteminhand == "None" and bedsidescrawlclicked == False and drawerunlocked == False or iteminhand == "None" and bedsidescrawlclicked == True or iteminhand == "screwdriver" and drawerunlocked == False or iteminhand == "screwdriver" and drawerunlocked == True or iteminhand == "note" or iteminhand == "key" and drawerunlocked == False or iteminhand == "key" and drawerunlocked == True or iteminhand == "None" and drawerunlocked == True or iteminhand == "gloves" or iteminhand == "hexagon" or iteminhand == "candle" or iteminhand == "litcandle":
        vbox yalign 0.5 xalign 0.5:
            imagebutton auto "images/bgs/escape1/bedsidetable_%s.png":
                if iteminhand == "None" and bedsidescrawlclicked == False:
                    action [SetVariable("bedsidescrawlclicked", True), Jump("bedsidescrawlclickedscene1")]
                elif iteminhand == "None" and bedsidescrawlclicked == True and drawerunlocked == False:
                    action Jump("bedsidescrawlclickedscene2")
                elif iteminhand == "screwdriver" and drawerunlocked == False:
                    action Jump("bedsidescrewscene1")
                elif iteminhand == "screwdriver" and drawerunlocked == True:
                    action Jump("bedsidescrewscene2")
                elif iteminhand == "note":
                    action Jump("bedsideschedulescene")
                elif iteminhand == "key" and drawerunlocked == False:
                    action [Hide("inventoryshow", dissolve), SetVariable("drawerunlocked", True), SetVariable("gloves", True), SetVariable("bedsidescrawlclicked", True), Jump("bedsidekeyscene")]
                elif iteminhand == "key" and drawerunlocked == True:
                    action [Hide("inventoryshow", dissolve), Jump("bedsidekeyscene2")]
                elif iteminhand == "None" and drawerunlocked == True:
                    action Jump("bedsidecomplete")
                elif iteminhand == "gloves":
                    action Jump("bedsideglovesscene")
                elif iteminhand == "hexagon":
                    action Jump("bedsidehexagonscene")
                elif iteminhand == "candle":
                    action Jump("bedsideunlitcandlescene")
                elif iteminhand == "litcandle":
                    action Jump("bedsidelitcandlescene")

                tooltip "Bedside Table"
                if iteminhand == "None":
                    mouse "imagemap"
                else:
                    mouse "[iteminhand]"
                focus_mask True at bgzoom


########## Bed actions ##########
    if iteminhand == "None" and screwdriver == False or iteminhand == "None" and screwdriver == True or iteminhand == "note" or iteminhand == "screwdriver" or iteminhand == "key" or iteminhand == "gloves" or iteminhand == "hexagon" or iteminhand == "candle" or iteminhand == "litcandle": # First time you click on the bed
        vbox yalign 0.5 xalign 0.5:
            imagebutton auto "images/bgs/escape1/bed_%s.png":
                if iteminhand == "None" and screwdriver == False:
                    action [SetVariable("screwdriver", True), Jump("bedscene1")]
                elif iteminhand == "None" and screwdriver == True:
                    action Jump("bedscene2")
                elif iteminhand == "note":
                    action Jump("bednotescene")
                elif iteminhand == "screwdriver":
                    action Jump("bedscrewscene")
                elif iteminhand == "key":
                    action Jump("bedkeyscene")
                elif iteminhand == "gloves":
                    action Jump("bedglovesscene")
                elif iteminhand == "hexagon":
                    action Jump("bedhexagonscene")
                elif iteminhand == "candle" or "litcandle":
                    action Jump("bedcandlescene")

                tooltip "Bed"
                if iteminhand == "None":
                    mouse "imagemap"
                else:
                    mouse "[iteminhand]"
                focus_mask True at bgzoom


########## Brick actions ##########
    if iteminhand == "None" and brickclicked == False and brickbroken == False or iteminhand == "None" and brickclicked == True and brickbroken == False or iteminhand == "note" and brickbroken == False or iteminhand == "screwdriver" and brickclicked == True and brickbroken == False or iteminhand == "screwdriver" and brickclicked == False and brickbroken == False:
        vbox yalign 0.5 xalign 0.5:
            imagebutton auto "images/bgs/escape1/brick_%s.png":
                if iteminhand == "None" and brickclicked == False and brickbroken == False:
                    action [SetVariable("brickclicked", True), Jump("brickscene1")]
                elif iteminhand == "None" and brickclicked == True and brickbroken == False: # Nothing in hand, all times clicked after
                    action Jump("brickscene2")
                elif iteminhand == "note" and brickbroken == False:
                    action Jump("bricknotescene")
                elif iteminhand == "screwdriver" and brickclicked == True and brickbroken == False:
                    action Jump("brickscrewscene2")
                elif iteminhand == "screwdriver" and brickclicked == False and brickbroken == False:
                    action Jump("brickscrewscene1")

                tooltip "Loose Brick"
                if iteminhand == "None":
                    mouse "imagemap"
                else:
                    mouse "[iteminhand]"
                focus_mask True at bgzoom


###### Grate Actions ########
    if iteminhand == "None" and brickbroken == True and grateunlocked == False and grateclicked == False and gratewait == True or iteminhand == "screwdriver" and brickbroken == True and grateunlocked == False and gratewait == True or iteminhand == "note" and grateunlocked == False and brickbroken == True:
        vbox yalign 0.5 xalign 0.5:
            imagebutton auto "images/bgs/escape1/grate_%s.png":
                if iteminhand == "None" and brickbroken == True and grateunlocked == False and grateclicked == False and gratewait == True:
                    action [SetVariable("grateclicked", True), Jump("gratescene1")] # if grate is showing, it hasn't been unlocked and it hasn't been clicked before:
                elif iteminhand == "screwdriver" and brickbroken == True and grateunlocked == False and gratewait == True: # if grate is showing, it hasn't been unlocked and it hasn't been clicked before plus the screwddriver is in the hand
                    action [SetVariable("grateclicked", True), SetVariable("grateunlocked", True), Jump("gratescene2")]
                elif iteminhand == "note" and grateunlocked == False and brickbroken == True:
                    action Jump("grateschedulescene")


                tooltip "Metal Grate"
                if iteminhand == "None":
                    mouse "imagemap"
                else:
                    mouse "[iteminhand]"
                focus_mask True at bgzoom

#### Puzzle Box Actions ####
    if iteminhand == "None" and grateunlocked == True and boxclicked == False and boxwait == True or iteminhand == "None" and grateunlocked == True and boxclicked == True and puzzleboxcomplete == False and boxwait == True or iteminhand == "screwdriver" and grateunlocked == True and boxclicked == True and puzzleboxcomplete == False and boxwait == True or iteminhand == "screwdriver" and grateunlocked == True and boxclicked == False and puzzleboxcomplete == False and boxwait == True or iteminhand == "note" and grateunlocked == True  and puzzleboxcomplete == False and boxwait == True:
        vbox yalign 0.5 xalign 0.5:
            imagebutton auto "images/bgs/escape1/box_%s.png":
                if iteminhand == "None" and grateunlocked == True and boxclicked == False and boxwait == True:  # if box is showing and it hasn't been clicked before
                    action [SetVariable("boxclicked", True), Jump("boxscene1")]
                elif iteminhand == "None" and grateunlocked == True and boxclicked == True and puzzleboxcomplete == False and boxwait == True:
                    action [Hide("inventory", dissolve), Hide("prisonscape"), ToggleScreen("puzzlebox")]
                elif iteminhand == "screwdriver" and grateunlocked == True and boxclicked == True and puzzleboxcomplete == False and boxwait == True:
                    action Jump("boxscrewdriverscene1")
                elif iteminhand == "screwdriver" and grateunlocked == True and boxclicked == False and puzzleboxcomplete == False and boxwait == True:
                    action Jump("boxscrewdriverscene2")
                elif iteminhand == "note" and grateunlocked == True  and puzzleboxcomplete == False and boxwait == True:
                    action Jump("boxschedulescene")

                tooltip "Strange Box"
                if iteminhand == "None":
                    mouse "imagemap"
                else:
                    mouse "[iteminhand]"
                focus_mask True at bgzoom


############# Ball actions ##########
    if iteminhand == "None" and brickclicked == True and ballclicked == False or iteminhand == "None" and brickclicked == False and ballclicked == False or iteminhand == "None" and ballclicked == True or iteminhand == "screwdriver" or iteminhand == "note" or iteminhand == "key" or iteminhand == "gloves" or iteminhand == "hexagon" or iteminhand == "candle" or iteminhand == "litcandle": # Click on balls after looked at loose brick
        vbox yalign 0.5 xalign 0.5:
            imagebutton auto "images/bgs/escape1/balls_%s.png":
                if iteminhand == "None" and brickclicked == True and ballclicked == False:
                    action [SetVariable("ballclicked", True), SetVariable("brickbroken", True), Jump("ballscene1")]
                elif iteminhand == "None" and brickclicked == False and ballclicked == False:
                    action  Jump("ballscene2")
                elif iteminhand == "None" and ballclicked == True:
                    action Jump("ballscene3")
                elif iteminhand == "screwdriver":
                    action Jump("ballscrewdriverscene")
                elif iteminhand == "note":
                    action Jump("ballschedulescene")
                elif iteminhand == "key":
                    action Jump("ballkeyscene")
                elif iteminhand == "gloves":
                    action Jump("ballglovesscene")
                elif iteminhand == "hexagon":
                    action Jump("ballhexagonscene")
                elif iteminhand == "candle" or "litcandle":
                    action Jump("ballcandlescene")

                tooltip "Ball and Chains"
                if iteminhand == "None":
                    mouse "imagemap"
                else:
                    mouse "[iteminhand]"
                focus_mask True at bgzoom


#### Scribble Actions ###
    if iteminhand == "None" and wallscrawlclicked == False or iteminhand == "None" and wallscrawlclicked == True or iteminhand == "screwdriver" or iteminhand == "note" or iteminhand == "key" or iteminhand == "gloves" or iteminhand == "hexagon" or iteminhand == "candle" or iteminhand == "litcandle":
        vbox yalign 0.5 xalign 0.5:
            imagebutton auto "images/bgs/escape1/scribble_%s.png":
                if iteminhand == "None" and wallscrawlclicked == False:
                    action [SetVariable("wallscrawlclicked", True), Jump("scribblescene1")]
                elif iteminhand == "None" and wallscrawlclicked == True:
                    action [Hide("inventory", dissolve), ToggleScreen("wallnumbers")]
                elif iteminhand == "screwdriver":
                    action Jump("scribblescrewscene")
                elif iteminhand == "note":
                    action Jump("scribbleschedulescene")
                elif iteminhand == "key":
                    action Jump("scribblekeyscene")
                elif iteminhand == "gloves":
                    action Jump("scribbleglovesscene")
                elif iteminhand == "hexagon":
                    action Jump("scribblehexagonscene")
                elif iteminhand == "candle" or "litcandle":
                    action Jump("scribblecandlescene")

                tooltip "Wall Engravings"
                if iteminhand == "None":
                    mouse "imagemap"
                else:
                    mouse "[iteminhand]"
                focus_mask True at bgzoom


#### Bed Puzzle Actions ###
    if iteminhand == "None" and bedpuzzleclicked == False and bedpuzzlefixed == False or iteminhand == "None" and bedpuzzleclicked == True and bedpuzzlefixed == True or iteminhand == "None" and bedpuzzleclicked == True and bedpuzzlefixed == False or iteminhand == "hexagon" or iteminhand == "None" and bedpuzzlecomplete == True or iteminhand == "gloves" or iteminhand == "screwdriver" or iteminhand == "note" or  iteminhand == "key":
        vbox yalign 0.5 xalign 0.5:
            imagebutton auto "images/bgs/escape1/turningboxfinished_%s.png":
                if iteminhand == "None" and bedpuzzleclicked == False and bedpuzzlefixed == False: # Nothing in hand, hasn't been clicked before, and the button hasn't been restored
                    action [Hide("inventoryshow", dissolve), SetVariable("bedpuzzleclicked", True), Jump("bedpuzzle1")]
                elif iteminhand == "None" and bedpuzzleclicked == True and bedpuzzlefixed == True :# Nothing in hand, has been clicked before, jump straight to puzzle
                    action [Hide("inventoryshow", dissolve), Jump("prepuzzlebox2")]
                elif iteminhand == "None" and bedpuzzleclicked == True and bedpuzzlefixed == False: # Nothing in hand, has been clicked before, and the button hasn't been restored, jump straight to puzzle
                    action [Hide("inventoryshow", dissolve), Jump("prepuzzlebox2")]
                elif iteminhand == "hexagon": #Hexagon piece in hand, fixes the puzzle
                    action [SetVariable("hexagonpiece", False), Hide("inventoryshow", dissolve), SetVariable("bedpuzzleclicked", True), SetVariable("bedpuzzlefixed", True), Jump("prepuzzlebox3")]
                elif iteminhand == "None" and bedpuzzlecomplete == True:
                    action [Hide("inventoryshow", dissolve), SetVariable("bedpuzzleclicked", True), Jump("bedpuzzle4")]
                elif iteminhand == "gloves":
                    action [Hide("inventoryshow", dissolve), Jump("bedpuzzleglove2")]
                elif iteminhand == "screwdriver":
                    action [Hide("inventoryshow", dissolve), Jump("bedpuzzlescrew")]
                elif iteminhand == "note":
                    action [Hide("inventoryshow", dissolve), Jump("bedpuzzlenote")]
                elif iteminhand == "key":
                    action [Hide("inventoryshow", dissolve), Jump("bedpuzzlekey1")]


                tooltip "Box with Buttons"
                if iteminhand == "None":
                    mouse "imagemap"
                else:
                    mouse "[iteminhand]"
                focus_mask True at bgzoom


#### Bucket Puzzle Actions ###



    if iteminhand == "None" and bucketclicked == False or iteminhand == "None" and bucketclicked == True or iteminhand == "screwdriver" and bucketbottleretrieved == False or iteminhand == "screwdriver" and bucketbottleretrieved == True or iteminhand == "note" or iteminhand == "key" or iteminhand == "gloves" and bucketbottleretrieved == False or iteminhand == "gloves" and  bucketbottleretrieved == True or iteminhand == "hexagon" or iteminhand == "candle" or iteminhand == "litcandle":
        vbox yalign 0.862 xalign 0.08:
            imagebutton auto "images/bgs/escape1/bucket_%s.png" :
                if iteminhand == "None" and bucketclicked == False:
                    action [SetVariable("bucketclicked", True), Hide("inventoryshow", dissolve), Jump("bucketscene1")]
                elif iteminhand == "None" and bucketclicked == True:
                    action [Hide("inventoryshow", dissolve), Jump("bucketscene2")]
                elif iteminhand == "screwdriver" and bucketbottleretrieved == False:
                    action [Hide("inventoryshow", dissolve), Jump("bucketscrewscene1")]
                elif iteminhand == "screwdriver" and bucketbottleretrieved == True:
                    action [Hide("inventoryshow", dissolve), Jump("bucketscrewscene2")]
                elif iteminhand == "note":
                    action [Hide("inventoryshow", dissolve), Jump("bucketnotescene")]
                elif iteminhand == "key":
                    action [Hide("inventoryshow", dissolve), Jump("bucketkeyscene")]
                elif iteminhand == "gloves" and bucketbottleretrieved == False:
                    action [SetVariable("hexagonpiece", True), SetVariable("bucketbottleretrieved", True), SetVariable("bucketclicked", True), Hide("inventoryshow", dissolve), Jump("bucketglovesscene")]
                elif iteminhand == "gloves" and  bucketbottleretrieved == True:
                    action [Hide("inventoryshow", dissolve), Jump("bucketglovesscene2")]
                elif iteminhand == "hexagon":
                    action [Hide("inventoryshow", dissolve), Jump("buckethexagonscene")]
                elif iteminhand == "candle" or "litcandle":
                    action [Hide("inventoryshow", dissolve), Jump("bucketcandlescene")]

                tooltip "Dubious Bucket"
                if iteminhand == "None":
                    mouse "imagemap"
                else:
                    mouse "[iteminhand]"
                focus_mask True




    $ tooltip = GetTooltip()

    if tooltip:
        vbox:
            add "gui/Custom/Information/name.png"
            yalign 0.9 xalign 0.5
        vbox:
            text "[tooltip]" size 40 color "#FFFFFF"
            yalign 0.88 xalign 0.5




## Scenes when items clicked
label barsscene1:
    hide prisonescape

    $ gametype = "NVL"
    $ charleft = "诺亚"
    $ charright = "凯恩"

    $cs_left = "noah n neu"
    $cs_right = "kaine n sad"


    $ nvl_show(Dissolve(1))
    nv "在铁栏杆外，能听到各种声音。有些只是低语，转瞬即逝的话语永远不会被发现。还有些是尖叫和呼喊，那些永远无法获得自由的人在乞求解脱。"
    knvl "即使这些人不是真的...这也不对。"
    nonvl "除非你想留在这里和他们在一起，否则我们必须离开这里。"
    knvl "这么说很好，但这里有一道厚重的铁栏杆阻挡我们离开。"
    $cs_left = "noah n sca"
    nonvl "..."
    gnvl "喂！里面安静点！"
    $cs_left = "noah n sur"
    $cs_right = "kaine n sur"
    nv "一名守卫走过，用剑柄敲打着金属栏杆。诺亚和凯恩吓了一跳。"
    $ waitpaper = True
    show note behind bars
    knvl "看到有人拿着剑，这可不在我今天的计划之内..."
    nonvl "..."
    nv "就在栏杆外，钥匙挂在一根绳子上的钩子上，够不到。绳子垂下来，恳求被拉动。"
    $cs_left = "noah n sca"
    nonvl "钥匙就挂在那里...如果我们能够够到它..."
    $cs_right = "kaine n sad"
    knvl "从这么远的地方？"
    $cs_left = "noah n neu"
    nonvl "也许这里有什么东西可以用来抓住它...不过我想这会比那更难。"
    $cs_right = "kaine n ser"
    knvl "嘿...那是什么？"
    nv "凯恩指着牢房外的地面，那里有一张纸。"
    nonvl "之前没有这个。"
    knvl "快，把它拿起来。"

    nvl clear

    $ nvl_hide(Dissolve(0.6))
    jump chapter1escaperepeat


label barsscene2:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape

    "外面持续不断的低语声并未停歇。不过都是那些即将被遗忘的喃喃自语。"
    window hide dissolve
    jump chapter1escaperepeat


label schedulescene1:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape

    "快速环顾四周，确保没有更多的守卫，诺亚盯着那张被扔在牢房外的纸。"
    "伸出手臂穿过金属栏杆，诺亚用指尖够到了那张纸。"
    "凯恩站在他身后，检查着这件新获得的物品。"

    show popout onlayer front
    show schedulepopout onlayer front:
        xpos 0.52 ypos 0.648 xanchor 0.5 yanchor 1.0
    with dissolve

    no sur "这是..."
    k sur "一个时间表？"
    no "看起来是的。"
    no "7点到1点...4点到8点...2点到6点...1点到7点..."
    k "不过现在到底几点，谁知道呢。"
    no "也许这意味着什么..."
    k "但愿守卫不会在我们试图逃脱的时候盯着我们的脖子。"
    "阻挡他们自由的牢房外，传来一声空洞的金属声响。一股寒意顺着诺亚的背脊而下，回荡在整个监狱中，源头不明。"
    no sca "...是的。"
    hide popout onlayer front
    hide schedulepopout onlayer front
    with dissolve
    k "现在，让我们再仔细看看四周。"
    window hide dissolve
    jump chapter1escaperepeat


label barsnotescene:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape

    "牢房外的房间黑暗潮湿。空气中弥漫着苔藓的气息，如同久远的秘密。"
    "还有其他的东西，更加阴险的东西，但诺亚决定不去注意它。"
    "他低头看着手中的纸，怀着怀疑的心情。"
    no neu "我想也不用再把它扔出去了。"
    window hide dissolve
    jump chapter1escaperepeat


label bedscene1:
    $ gametype = "NVL"
    hide prisonescape

    $ charleft = "诺亚"
    $ charright = "凯恩"
    $cs_left = "noah n neu"
    $cs_right = "kaine n neu"

    $ nvl_show(Dissolve(1))

    nv "怀着不安的心情，诺亚望向房间中央的大床。"
    knvl "看起来就是我预料中的中世纪监狱床样子。"
    $ cs_left = "noah n sca"
    nonvl "...我想我还是检查一下吧。"
    nonvl "不过我可不太兴奋要在别人用过的床上翻找。"
    knvl "要我来做吗？"
    nv "诺亚愣了一下，然后点了点头。"
    nv "毕竟他和凯恩在一起。凯恩一直是那种愿意做别人不愿意做的事情的人。"
    $cs_right = "kaine n ser"
    knvl "嗯...这里似乎没什么。"
    nonvl "枕头里呢？"
    $cs_right = "kaine n sur"
    nv "他摸索着枕头套，眼睛睁大了。"
    $cs_right = "kaine n hap"
    knvl "真是个好主意。"
    nv "他拿出一件小巧的金属物品。"
    nv "一把螺丝刀。"
    $cs_right = "kaine n ser"
    knvl "他怎么会把这个带进来的呢..."
    $ cs_left = "noah n neu"
    nonvl "可能是看了太多电视剧，以为每个人的牢房里都藏着一把螺丝刀。"
    $cs_right = "kaine n hap"
    knvl "不过这对我们很有用。希望他也梦到了我们可以用这个的地方。"
    nv "凯恩迅速把螺丝刀递给诺亚，他的手在另一个男人手上停留了一会儿，然后才收回。"

    nvl clear

    $ nvl_hide(Dissolve(0.6))
    jump chapter1escaperepeat

label bedscene2:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    "脏乱的床单上布满了月余的汗渍。它们注定只能在梦境中存在，再也无法拥有。"
    no neu "这也许是件好事...下次，梦到一张更干净的床吧。"
    k neu "嗯？"
    no neu "没什么，别担心。"
    k sad "...."
    k hap "决定还是在他的床上翻找了？"
    no sca "呃，不。我想还是让专家来做吧，也就是你。"
    window hide dissolve
    jump chapter1escaperepeat


label bednotescene:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    "诺亚紧紧握着那张守卫时间表，干燥陈旧的纸张在他的掌心感觉很陌生。"
    "不过这只是一种假象，一种虚假。这种感觉并不真实，却又真实存在。"
    no hur "一切都不是真的..."
    no "我只是想知道，到底哪个世界更加虚假。"
    k sad "..."
    window hide dissolve
    jump chapter1escaperepeat


label barsscrewscene:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    "走廊某处传来轻微的滴水声，来自监狱的某个偏远角落。"
    "不管是水还是其他什么，谁也无法得知。"
    "诺亚盯着手中的螺丝刀，感受着它的重量。"
    no neu "..."
    k ser "你在想什么？"
    no "...你还擅长运动吗？"
    k sad "诺亚，我上次做运动还是好几年前的事了。"
    no sca "...好的。"
    k ser "你想把螺丝刀扔出去，希望能打落钥匙？"
    no hur "说实话，我也不知道我在想什么。"
    k "...我们可能还需要这把螺丝刀。如果实在没办法，我稍后再试试。"
    window hide dissolve
    jump chapter1escaperepeat

label bedscrewscene:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    no neu "我怀疑他不会把什么东西藏在床架里...可能也不值得拆开。"
    k ser "好吧，如果我们陷入困境，我们随时可以尝试一下。"
    no neu "...让我们把它作为最后的手段。我真的不想碰那个东西。"
    window hide dissolve
    jump chapter1escaperepeat


label brickscene1:
    $ gametype = "NVL"
    hide prisonescape


    $ charleft = "诺亚"
    $ charright = "凯恩"
    $cs_left = "noah n neu"
    $cs_right = "kaine n ser"

    $ nvl_show(Dissolve(1))
    nv "房间很冷，冻得房客骨头都在发抖。墙壁冰冷的石头提醒他们，这里并不欢迎他们。"
    nv "诺亚伸手摸了摸那些石头。冰冷刺骨，湿气粘在他的皮肤上。"
    $cs_left = "noah n sad"
    nonvl "它和我记忆中一样栩栩如生..."
    knvl "...你说你以前经常这样做，对吗？它们...一直都是这样的吗？"
    $ cs_left = "noah n neu"
    nonvl "什么样的？"
    $cs_right = "kaine n sad"
    knvl "...如此敌意？"
    nonvl "......."
    nonvl "我以为我见识过周围人的最坏一面。我以为我在某种程度上知道自己有多不受欢迎。"
    nonvl "...事实证明，那只是他们真实感受的一小部分。人们隐藏在心底的真相，他们所保守的秘密，人们对你的真实想法..."
    $cs_left = "noah n sad"
    nonvl "你都能在这里找到。"
    nonvl "所以，是的，它们都是这样的，某种程度上来说。"
    knvl "诺亚...并不是所有人都是那样的。"
    nonvl "...剩下的人都是那样的。"
    knvl ".........."
    nv "诺亚的手掌沿着灰色的墙壁滑动，一块石头在下面移动。"
    $cs_left = "noah n sur"
    nonvl "这块石头松动了。"
    $cs_right = "kaine n sur"
    knvl "你能把它拽出来吗？"
    $ cs_left = "noah n neu"
    nonvl "...不行。它还是太重了。"
    $cs_right = "kaine n ser"
    knvl "周围一定有什么东西可以用来打碎它。"
    nonvl "我们继续找吧。"
    knvl "好的...还有，诺亚..."
    $cs_right = "kaine n sad"
    knvl "我...永远不会伤害你。你知道的。"
    nonvl "..."
    $cs_left = "noah n sad"
    nonvl "...也许吧。"

    nvl clear

    $ nvl_hide(Dissolve(0.6))
    jump chapter1escaperepeat

label brickscrewscene1:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape

    "诺亚用螺丝刀轻轻敲击着墙壁，倾听着回响的声音。"
    no neu "听起来不是空心的..."
    k ser "这个梦境到底有多大？"
    no "他的想象力有多广阔？"

    window hide dissolve
    jump chapter1escaperepeat



label brickscrewscene2:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    "紧握着螺丝刀，诺亚转向那块松动的砖块。"
    k sur "你真的要用这么小的螺丝刀去对付它吗？"
    no neu "你有更好的主意吗？"
    k "嗯，没有，但是..."
    k neu "好吧，那你就试试看吧。"
    "他举起小工具，像刺穿肉体一样刺向石头。但仍然不够。"
    no sad "该死..."
    k ser "别担心。我相信这里一定有其他可以用的东西。"

    window hide dissolve
    jump chapter1escaperepeat

label brickscene2:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    "在冰冷的石墙的另一边，有人几乎无声地哭泣着。"
    "每个房间可能都一样。一个空虚、冰冷的世界。"
    window hide dissolve
    jump chapter1escaperepeat

label bricknotescene:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    "诺亚举起纸张，盯着上面的字。"
    "那些根本不存在，也永远不会存在的人的名字。"
    "也许他们是真实人物的反映，也许不是。"
    no sad "但这又有什么区别呢...无论如何，他们最终都是一样的。"
    k sad "...."
    k "诺亚？"
    window hide dissolve
    jump chapter1escaperepeat

label ballscene1:
    $ gametype = "NVL"
    hide prisonescape
    $ charleft = "诺亚"
    $ charright = "凯恩"
    $cs_left = "noah n sur"
    $cs_right = "kaine n ser"

    $ nvl_show(Dissolve(1))

    nonvl "嗯..原来如此。"
    knvl "什么原来如此？"
    nonvl "天花板上悬挂的球形铁球和链条，完美地对准那块松动的砖块。"
    $cs_right = "kaine n sur"
    knvl "好眼力。我没有注意到。"
    $ cs_left = "noah n neu"
    nonvl "让我们试试看。"
    nv "经过一番努力，诺亚尽可能地拉开沉重的铁球，然后放开了手。"
    nv "它穿过空气，砰地撞击在砖块上，将其粉碎。"
    $cs_right = "kaine n hap"
    knvl "干得好！"
    $cs_left = "noah n hap"
    nonvl "谢谢！"
    $cs_left = "noah n sad"
    nv "最初兴奋的表情，诺亚很快收敛了起来。"
    nonvl "...我是说，这没什么大不了的。我们只需要离开这里。"
    knvl "你做得很好。没什么可不高兴的。"
    nonvl "..."
    nonvl "这不是应该高兴的地方。"
    $cs_right = "kaine n ser"
    knvl "高兴也没什么不好的。"

    nvl clear
    $ gratewait = True
    $ nvl_hide(Dissolve(0.6))
    jump chapter1escaperepeat


label ballscene2:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape

    "两个金属球无动于衷地悬挂在天花板上，连一丝微风都没有。"
    "在遥远的牢房里，有人拖着虚弱的身体在坚硬的石地上爬行，脚踝上的球链拖慢了他们的速度。"
    "他们倒下了，眼中最后一丝光芒也熄灭了。"

    no sad "...也许这就是我应该待的地方。"
    window hide dissolve
    jump chapter1escaperepeat

label ballscene3:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    "铁球仍然静止不动，气势汹汹。"
    window hide dissolve
    jump chapter1escaperepeat


label ballscrewdriverscene:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    no neu "我想看看能不能搬动这些重物..."
    k ser "干什么？"
    no "如果实在不行，我们就把墙打穿吧。"
    k sad "嗯...让这个作为最后的手段吧。我不想让你受伤。"
    window hide dissolve
    jump chapter1escaperepeat


label ballschedulescene:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    "诺亚盯着那张纸条，寻找任何线索，突然被一只手抓住了手腕。"
    no fro "什么？"
    k ser "你差点一头撞上那些东西。小心点。"
    no sad "谢谢..."
    window hide dissolve
    jump chapter1escaperepeat

label gratescene1:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    "松散的砖块残骸后面是一个厚重的金属栅格，用四颗螺丝牢牢固定在墙上。"
    k ser "你能看到栅格后面有什么吗？"
    "诺亚凝视着，但什么也看不到。"
    no neu "不行。我们得把这个栅格拆下来。"
    window hide dissolve
    jump chapter1escaperepeat

label gratescene2:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    $ boxwait = True
    "诺亚小心翼翼地用螺丝刀拧开栅格四角的螺丝，迅速将其从墙上取下。"
    k hap "我就知道这把螺丝刀最终会派上用场。"
    no neu "但栅格后面是什么...？"
    window hide dissolve
    jump chapter1escaperepeat


label grateschedulescene:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    "栅格的孔洞很小，尽管诺亚努力尝试，但还是什么也看不到。"
    "他卷起纸条，小心地穿过孔洞戳了进去。它撞到了里面的什么东西，但他们看不到。"
    no neu "里面肯定有什么东西...我们得把这个栅格拆下来。"
    window hide dissolve
    jump chapter1escaperepeat

label boxscene1:
    $ gametype = "NVL"
    hide prisonescape
    $ charleft = "诺亚"
    $ charright = "凯恩"
    $cs_left = "noah n neu"
    $cs_right = "kaine n ser"

    $ nvl_show(Dissolve(1))

    nv "诺亚和凯恩走近墙上的洞，发现里面有一个小方盒。诺亚小心翼翼地伸手拿起了它。"
    nonvl "嗯..."
    nv "他在手中转动着这个盒子。表面似乎没有什么特别的地方，除了前面有四个没有标记的按钮。"
    knvl "这东西是干什么用的？"
    nonvl "好问题..."
    nv "他按了几个按钮，但什么也没发生。"
    $cs_right = "kaine n sur"
    knvl "你觉得我们要按正确的顺序按？"
    nonvl "很可能。没什么是简单的。"
    knvl "我们怎么猜？可能是任何东西。"
    nonvl "房间里肯定有线索。梦境里通常都是这样...希望如此。"
    nv "凯恩点了点头，目光盯着那个小盒子。"
    knvl "或者...我们可以试着把它砸碎？"
    nonvl "如果里面有易碎的东西呢？"
    $cs_right = "kaine n hap"
    knvl "...对，你说得对。我们总能想出办法的。"
    $cs_left = "noah n sad"
    nonvl "你自己说吧。"

    nvl clear
    $ gratewait = True
    $ nvl_hide(Dissolve(0.6))
    jump chapter1escaperepeat

label boxscrewdriverscene1:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    "诺亚拿起盒子，再次在手中转动。"
    "另一只手握着凯恩找到的螺丝刀，准备随时使用。"
    k ser "有什么发现吗？"
    no neu "没有。它似乎没有螺丝...只有前面的四个按钮。"
    k neu "...有谜题就一定有答案。我们继续想办法吧。"
    window hide dissolve
    jump chapter1escaperepeat

label boxscrewdriverscene2:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    "诺亚盯着从栅格后发现的那个神秘物品，手中仍握着螺丝刀。"
    "他举起螺丝刀，好像在保护自己。"
    k hap "在你试图拆开它之前，让我们先看看它吧。"
    no neu "好的..."
    k neu "如果你担心的话，我可以来看看。"
    no neu "不...不用，我自己来看。"
    window hide dissolve
    jump chapter1escaperepeat

label boxschedulescene:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    "诺亚盯着卫兵值班表上的数字，目光几乎要在那张旧羊皮纸上烧出洞来。"
    no sad "这一定有关联..."
    window hide dissolve
    jump chapter1escaperepeat


####### PUZZLE BOX SECTION #########
screen puzzlebox:
    modal True

    add "images/puzzles/overlay.png"
    add "images/puzzles/frame.png"

    vbox:
        spacing 30
        align 0.6, 0.33
        hbox:
            spacing 30
            imagebutton auto "images/puzzles/chapter_1/button_%s.png" action  [Play("sound", "audio/sfx/click.ogg"), Jump("puzzleboxchecker1")] mouse "[iteminhand]" focus_mask True
            imagebutton auto "images/puzzles/chapter_1/button_%s.png" action [Play("sound", "audio/sfx/click.ogg"), Jump("puzzleboxchecker2")] mouse "[iteminhand]" focus_mask True
        hbox:
            spacing 30
            imagebutton auto "images/puzzles/chapter_1/button_%s.png" action [Play("sound", "audio/sfx/click.ogg"), Jump("puzzleboxchecker3")] mouse "[iteminhand]" focus_mask True
            imagebutton auto "images/puzzles/chapter_1/button_%s.png" action [Play("sound", "audio/sfx/click.ogg"), Jump("puzzleboxchecker4")] mouse "[iteminhand]" focus_mask True

    textbutton "Close" action [Hide("puzzlebox", dissolve), Jump("puzzleclose")]:
        xalign 0.93 yalign 0.1
        text_color "#ffffff"
        text_hover_color "#dcad2b"

    textbutton "Hint":
        if puzzlebox1hint == 1:
            action [SetVariable("puzzlebox1hint", puzzlebox1hint + 1), Show("puzzlebox1hint1", dissolve)]
        if puzzlebox1hint == 2:
            action [SetVariable("puzzlebox1hint", puzzlebox1hint + 1), Show("puzzlebox1hint2", dissolve)]
        if puzzlebox1hint == 3:
            action [SetVariable("puzzlebox1hint", puzzlebox1hint + 1), Show("puzzlebox1hint3", dissolve)]
        if puzzlebox1hint == 4:
            action Show("puzzlebox1hint4", dissolve)

        xalign 0.928 yalign 0.15
        text_color "#ffffff"
        text_hover_color "#dcad2b"

screen puzzlebox1hint1:
    modal True

    add "images/Various/black overlay.png"
    add "gui/popup.png" xalign 0.5 yalign 0.5
    text "Hint" xalign 0.5 yalign 0.34 color "#fefefe" size 50
    textbutton "x" action [Hide("puzzlebox1hint1", dissolve)]:
        text_color "#ffffff"
        text_hover_color "#dcad2b"
        xalign 0.68
        yalign 0.28
    vbox:
        xanchor 0.0
        spacing 20.0
        xpos 700
        ypos 450
        text "打开盒子的密码是8位数字。"
        text "再次点击提示按钮可获得另一个提示。"

screen puzzlebox1hint2:
    modal True

    add "images/Various/black overlay.png"
    add "gui/popup.png" xalign 0.5 yalign 0.5
    text "Hint" xalign 0.5 yalign 0.34 color "#fefefe" size 50
    textbutton "x" action [Hide("puzzlebox1hint2", dissolve)]:
        text_color "#ffffff"
        text_hover_color "#dcad2b"
        xalign 0.68
        yalign 0.28
    vbox:
        xanchor 0.0
        spacing 20.0
        xpos 700
        ypos 450
        text "将值班表上的数字组合起来，就能找到解锁密码。"
        text "再次点击提示按钮可获得另一个提示。"

screen puzzlebox1hint3:
    modal True

    add "images/Various/black overlay.png"
    add "gui/popup.png" xalign 0.5 yalign 0.5
    text "Hint" xalign 0.5 yalign 0.34 color "#fefefe" size 50
    textbutton "x" action [Hide("puzzlebox1hint3", dissolve)]:
        text_color "#ffffff"
        text_hover_color "#dcad2b"
        xalign 0.68
        yalign 0.28
    vbox:
        xanchor 0.0
        spacing 20.0
        xpos 700
        ypos 450
        text "你可以在墙上找到每个按钮对应的数字。"
        text "再次点击提示按钮可获得答案。"

screen puzzlebox1hint4:
    modal True

    add "images/Various/black overlay.png"
    add "gui/popup.png" xalign 0.5 yalign 0.5
    text "Hint" xalign 0.5 yalign 0.34 color "#fefefe" size 50
    textbutton "x" action [Hide("puzzlebox1hint4", dissolve)]:
        text_color "#ffffff"
        text_hover_color "#dcad2b"
        xalign 0.68
        yalign 0.28
    vbox:
        xanchor 0.0
        spacing 20.0
        xpos 700
        ypos 450
        text "按照下面显示的顺序按下按钮。"

    add "images/Various/chapter1_puzzlebox1hint.png" xalign 0.5 yalign 0.6 zoom 0.3


label puzzleboxchecker1:
    $ puzzleboxcount += 1
    $ puzzleplayer.append("1")

    jump puzzleboxcheckerfinal

label puzzleboxchecker2:
    $ puzzleboxcount += 1
    $ puzzleplayer.append("2")

    jump puzzleboxcheckerfinal

label puzzleboxchecker3:
    $ puzzleboxcount += 1
    $ puzzleplayer.append("3")

    jump puzzleboxcheckerfinal

label puzzleboxchecker4:
    $ puzzleboxcount += 1
    $ puzzleplayer.append("4")

    jump puzzleboxcheckerfinal


label puzzleboxcheckerfinal:
    if puzzleboxcount == 8:
        if puzzleplayer == puzzleanswer:
            jump puzzleboxcomplete

        else:
            play sound "audio/sfx/wrong.ogg"
            $ puzzleplayer = []
            $ puzzleboxcount = 0

            window show dissolve
            $ gametype = "ADV"
            hide prisonescape

            no sur "啊！"
            k sur "你没事吧？！"
            no sad "我没事...只是吓了一跳。"
            k sad "...让我来吧。"
            no neu "没关系，我来处理。"
            window hide dissolve
            $ renpy.transition(dissolve)
            $ renpy.call_screen("puzzlebox")

    else:
        $ renpy.call_screen("puzzlebox")


label puzzleclose:
    $ puzzleplayer = []
    $ puzzleboxcount = 0
    jump chapter1escaperepeat


label puzzleboxcomplete:
    play sound "audio/sfx/correct.ogg"
    $ puzzleboxcomplete = True
    $ tablekey = True

    $ gametype = "NVL"
    hide prisonescape
    $ charleft = "诺亚"
    $ charright = "凯恩"
    $cs_left = "noah n neu"
    $cs_right = "kaine n ser"

    $ nvl_show(Dissolve(1))

    nv "诺亚手中的盒子发出轻微的叮咚声，然后打开，露出了里面的内容。"
    $cs_left = "noah n sur"
    nonvl "一把...钥匙？"
    $cs_right = "kaine n sur"
    knvl "一把钥匙？！"
    nonvl "...不过这太容易了。太容易了。"
    knvl "你什么意思？"
    $cs_left = "noah n sad"
    nonvl "..."
    nv "诺亚盯着它，不信任地看着。"
    $cs_right = "kaine n sad"
    knvl "说真的，有时候事情就是这么简单。来吧，这是值得庆祝的事情！"
    nonvl "...."
    nonvl "我想也是。好吧，我们试试看。"
    nv "诺亚叹了口气，揉了揉后颈，目光从凯恩身上移开。"
    knvl "有什么不对吗？"
    nonvl "...没有，没什么不对，只是..."
    nonvl "啊，无所谓了。"
    knvl "别这样吊着我。"
    nonvl "....."
    nonvl "谢谢。谢谢你在这里。"
    $cs_right = "kaine n sur"
    nv "诺亚诚实的话让凯恩脸上露出了惊讶的表情。"
    $cs_right = "kaine n hap"
    knvl "好吧，我也没什么选择，但只要你需要，我随时都会陪你。"
    nonvl "说实话，我宁愿永远不要回到这里。"
    $cs_right = "kaine n ser"
    knvl "...我也是。"
    knvl "...你知道，这可能是多年来你对我说的最多的话了。"
    nonvl "...对不起。"

    nvl clear
    $ gratewait = True
    $ nvl_hide(Dissolve(0.6))
    jump chapter1escaperepeat


label scribblescene1:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    "诺亚跪在墙边，仔细观察着墙上刻的东西。"
    show popout onlayer front
    show wallscrawlpopout onlayer front:
        yalign 0.3 xalign 0.5
    with dissolve
    no neu "...这里有些东西。"
    k neu "让我看看。"
    "他跪在诺亚身边，看着墙上标记的数字。"
    k ser "...这到底是什么意思？"
    no "好问题。"
    k "我们记下这个。"
    hide popout onlayer front
    hide wallscrawlpopout onlayer front
    with dissolve
    window hide dissolve
    jump chapter1escaperepeat

screen wallnumbers:
    modal True
    add "gui/popup.png" xalign 0.5 yalign 0.5
    add "images/Various/wallscrawl_chapter1.png" yalign 0.5 xalign 0.5
    textbutton "Close" action [Hide("wallnumbers", dissolve), Jump("chapter1escaperepeat")] xalign 0.68 yalign 0.28

label scribblescrewscene:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    no fro "..."
    "诺亚再次跪下，用拇指摩挲着那些凹痕。"
    k sad "你会以为一个老师不会去破坏东西。"
    no fro "他可能坐在这里，慢慢地用螺丝刀在墙上刻了很长时间。"
    no sad "...还是说这些已经在梦开始的时候就在这里了？谁知道呢。"
    k "...好久没见到他了。"
    no sad "...我也是。"
    no "不知道他还在不在教书。"
    k "我听说他在...你知道的那件事之后就辞职了。"
    no neu "你可以直接说，是因为我被开除了。"
    k "那不是你的错。是他先做出那种事的。"
    no fro "他活该。"
    k "...."
    k "你有没有希望...他遭到更严厉的惩罚？"
    no "一直都有。"
    k "诺亚..."
    k "你从来没告诉过我，他对你父母说了什么。"
    no "那已经不重要了。"
    window hide dissolve
    jump chapter1escaperepeat


label scribbleschedulescene:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    no neu "嗯..."
    k sur "怎么了？"
    no "没什么，只是一个猜测，但是...我觉得这些数字可能和那个时间表上的数字有关。"
    k "你这么认为？怎么个关系？"
    no sad "这部分我还没想明白。"
    window hide dissolve
    jump chapter1escaperepeat


label barkeyscene1:
    $ gametype = "NVL"
    hide prisonescape
    $ charleft = "诺亚"
    $ charright = "凯恩"
    $cs_left = "noah n sad"
    $cs_right = "kaine n ser"

    $ nvl_show(Dissolve(1))

    nv "诺亚和凯恩冲向那扇上了锁的门，手心都是汗。"
    nv "诺亚把钥匙伸向锁孔，手在发抖。"
    nonvl "...."
    $cs_left = "noah n fro"
    nonvl "该死。"
    $cs_right = "kaine n sad"
    knvl "...."
    knvl "谁会想到一个锁着的房间里竟然有一把钥匙，但它打不开门？"
    $cs_left = "noah n sad"
    nonvl "我就知道这不可能这么简单。妈的。"
    nonvl "这么多年过去了，他还是在搞破坏我的生活。"
    knvl "别慌张。好吧，我们一定会找到另一条出路的，我相信一定会有的。"
    nonvl "我真希望我也能像你一样乐观。"
    $cs_right = "kaine n neu"
    knvl "交给我吧。反正我一直都是我们两个里面更聪明的那个。"
    knvl "你就呆在你那个悲观的角落里吧。"
    $cs_left = "noah n sur"
    $cs_right = "kaine n sur"
    nv "两个人身后传来一阵窸窣声。他们都惊讶地转过身去。"
    knvl "...."
    nv "被锁链拴在地上的那个男人第一次抬起头看向诺亚，目光坚定。"
    nonvl "......"
    nv "他的眼睛红肿，只看着他就让人感到一种不应有的罪疚感。"

    $ charright = "弗洛伊德先生"
    $cs_right = "mf n sad"

    mrwnvl "诺亚...诺亚..."
    nonvl "嗯？你想要什么？"
    mrwnvl "我一直...一直想要...和你们谈谈..."
    mrwnvl "这么长时间以来..."
    nv "话说到一半，泪水再次滑落下他的脸颊。他的声音破碎不堪，反映了他现在的状态。"
    $cs_right = "kaine n sad"
    $ charright = "凯恩"
    knvl "...别太在意他。他现在有点...不太正常。"
    $cs_left = "noah n sad"
    nonvl "反正也没什么好谈的..."
    $ charright = "弗洛伊德先生"
    $cs_right = "mf n sad"
    mrwnvl "那不是...不是我干的..."

    nvl clear

    $ nvl_hide(Dissolve(0.6))
    jump chapter1escaperepeat

label bedkeyscene:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    "诺亚跪在冰冷坚硬的地面上，探头查看床底，寻找任何可以用钥匙打开的东西。"
    no neu "这里似乎什么也没有。"
    k neu "我们继续四处看看吧。"
    window hide dissolve
    jump chapter1escaperepeat

label ballkeyscene:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    "从黑暗的走廊传来一声响动，让诺亚背上一阵发凉。"
    no sad "这里也没有什么可以打开的..."
    window hide dissolve
    jump chapter1escaperepeat


label scribblekeyscene:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    k sur "你知道吗，我真的很佩服你能解开那个盒子。"
    no neu "为什么？"
    k "我肯定解不出来。"
    "诺亚微笑着紧紧握住那把钥匙-他的战利品。"
    no hap "我在解谜方面一直都比你强。"
    k sad "嘿。"
    window hide dissolve
    jump chapter1escaperepeat


label bedsidescrawlclickedscene1:
    $ gametype = "NVL"
    hide prisonescape
    $ charleft = "诺亚"
    $ charright = "凯恩"
    $cs_left = "noah n neu"
    $cs_right = "kaine n ser"

    $ nvl_show(Dissolve(1))
    nv "一张破旧的床边有一张木制的床头柜，上面放着一支小蜡烛，固定在表面上。"
    nv "诺亚小心翼翼地走近，伸手触摸表面。"
    nonvl "很干净..."
    knvl "抽屉里有什么？"
    nonvl "让我们看看吧。"
    nv "诺亚抓住抽屉把手轻轻拉动，但它纹丝不动。"
    nonvl ".........."
    nonvl "看来是锁住了。"
    $cs_right = "kaine n sad"
    knvl "什么样的监狱会让囚犯有上锁的抽屉？"
    nonvl "这里就是这样。"
    knvl "我想在梦境里什么都有可能。我们找点东西来打开它吧。"
    nv "诺亚转头看向那个被锁在墙上的男人，但他拒绝回视。"
    $cs_left = "noah n fro"
    knvl "嘿，这里有什么？"
    nonvl "算了，别管他了。很明显他不想和我们说话。"
    knvl "...."

    nvl clear

    $ nvl_hide(Dissolve(0.6))
    jump chapter1escaperepeat

label bedsidescrawlclickedscene2:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    "金属碰撞的声音在背景中持续响起。"
    "在监狱的某个地方，一个囚犯正遭受鞭打，他的尖叫声无法传出。"
    window hide dissolve
    jump chapter1escaperepeat

label bedsidescrewscene1:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    no neu "我想我可以试着强行打开抽屉。"
    k hap "来，让我来试试。"
    "凯恩迅速拿起螺丝刀开始工作，但无论他怎么尝试，抽屉都纹丝不动。"
    k sur "天啊，这抽屉是用什么做的..."
    no "看来他在梦中设置了特定的开启方式，其他办法都不会奏效。"
    no "好吧，我们继续找找看。"
    window hide dissolve
    jump chapter1escaperepeat

label bedsidescrewscene2:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    no neu "我想这个抽屉里也没什么隐藏的东西..."
    no "那么这里就不需要螺丝刀了。"
    window hide dissolve
    jump chapter1escaperepeat

label bedsideschedulescene:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    "诺亚把狱警的时间表放在床头柜上，环顾四周。"
    no sad "这个梦真是糟透了。"
    no "在所有梦境中，偏偏被困在这一个..."
    k ser "你不是说它们都很糟糕吗？"
    no neu "...是的，它们都很糟糕。但这个特别糟糕。"
    window hide dissolve
    jump chapter1escaperepeat


label bedsidekeyscene:
    $ gametype = "NVL"
    hide prisonescape
    $ charleft = "诺亚"
    $ charright = "凯恩"
    $cs_left = "noah n neu"
    $cs_right = "kaine n ser"

    nv "钥匙轻轻一转，抽屉就打开了。"
    nonvl "当然，这把钥匙能打开抽屉..."
    knvl "也许里面还有另一把钥匙？"
    nonvl "只有打开看看才知道。"
    nv "随着吱呀一声，抽屉打开了。"
    nv "里面空空如也，除了..."
    $cs_left = "noah n sad"
    nonvl "...手套？认真的？"
    $cs_right = "kaine n sur"
    knvl "...."
    nonvl "里面有什么？"
    knvl "嗯..."
    nv "凯恩尴尬地抓挠着脸，目光移开。"
    nv "诺亚顺着他的视线看过去，直到看到一样他想忽视的东西。"
    $cs_left = "noah n hur"
    nonvl "...真是太棒了。"
    knvl "等等...那是什么？"
    nv "诺亚低头看到了别的东西——刻在木头上的东西。"
    knvl "让我们仔细看看那个。"

    nvl clear

    $ nvl_hide(Dissolve(0.6))
    jump chapter1escaperepeat

label bedsidekeyscene2:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    no hur "一定是手套吧..."
    window hide dissolve
    jump chapter1escaperepeat


label barkeyscene2:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    no hur "生活真的不容易啊..."
    k sad "很遗憾..."
    window hide dissolve
    jump chapter1escaperepeat

label bedsidecomplete:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    show popout onlayer front
    show drawerpopout onlayer front:
        xpos 0.5 ypos 0.65 xanchor 0.5 yanchor 1.0
    with dissolve
    no neu "你觉得这是什么意思呢？"
    k sur "嗯...这是个好问题。"
    k sad "...."
    k "不管我们现在能不能弄明白，我觉得这可能很重要。"
    hide popout onlayer front
    hide drawerpopout onlayer front
    with dissolve
    no "有帮助..."
    window hide dissolve
    jump chapter1escaperepeat



label bedpuzzle1:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    no neu "这是什么..."
    k sur "前面有什么？"
    "诺亚转动六角形的旋钮，但似乎没有任何反应。"
    no neu "看起来缺少一个按钮...在修好之前可能没什么用。"
    window hide dissolve
    jump chapter1escaperepeat


default rotate1 = 1
default rotate2 = 1
default rotate3 = 1
default rotate4 = 1

label prepuzzlebox2:
    $ renpy.transition(dissolve)
    $ renpy.call_screen("puzzlebox2")

label prepuzzlebox3:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    $ iteminhand = "None"
    $ default_mouse = "default"
    "拼图块与其他部件锁在一起，等待被转动。"
    k sur "好了，修好了。"
    window hide dissolve
    $ renpy.transition(dissolve)
    $ renpy.call_screen("puzzlebox2")

screen puzzlebox2:
    add "images/puzzles/overlay.png"
    add "images/puzzles/frame.png"



    #################### BUTTON 1 #######################

    vbox yalign 0.4 xalign 0.2:
        imagebutton:
            idle "images/puzzles/chapter_1/sunmoon_left.png" # Hexagon 1 left
            hover "images/puzzles/chapter_1/sunmoon_left.png"
            action  [SetVariable("rotate1", rotate1 + 1), Jump("bedpuzzlebox1add")] mouse "puzzleleft" focus_mask True

    vbox yalign 0.4 xalign 0.2:
        imagebutton:
            idle "images/puzzles/chapter_1/sunmoon_right.png" # Hexagon 1 right
            hover "images/puzzles/chapter_1/sunmoon_right.png"
            action [SetVariable("rotate1", rotate1 - 1), Jump("bedpuzzlebox1minus")] mouse "puzzleright" focus_mask True


            #################### BUTTON 2 #######################

    if bedpuzzlefixed:
        vbox yalign 0.4 xalign 0.42:
            imagebutton:
                idle "images/puzzles/chapter_1/sunmoon_left.png" # Hexagon 2 left
                hover "images/puzzles/chapter_1/sunmoon_left.png"
                action [SetVariable("rotate2", rotate2 + 1), Jump("bedpuzzlebox2add")] mouse "puzzleleft" focus_mask True

        vbox yalign 0.4 xalign 0.42:
            imagebutton:
                idle "images/puzzles/chapter_1/sunmoon_right.png" # Hexagon 2 right
                hover "images/puzzles/chapter_1/sunmoon_right.png"
                action [SetVariable("rotate2", rotate2 - 1), Jump("bedpuzzlebox2minus")] mouse "puzzleright" focus_mask True

                #################### BUTTON 3 #######################
    vbox yalign 0.4 xalign 0.64:
        imagebutton:
            idle "images/puzzles/chapter_1/sunmoon_left.png" # Hexagon 3 left
            hover "images/puzzles/chapter_1/sunmoon_left.png"
            action [SetVariable("rotate3", rotate3 + 1), Jump("bedpuzzlebox3add")] mouse "puzzleleft" focus_mask True

    vbox yalign 0.4 xalign 0.64:
        imagebutton:
            idle "images/puzzles/chapter_1/sunmoon_right.png" # Hexagon 3 right
            hover "images/puzzles/chapter_1/sunmoon_right.png"
            action [SetVariable("rotate3", rotate3 - 1), Jump("bedpuzzlebox3minus")] mouse "puzzleright" focus_mask True

            #################### BUTTON 4 #######################
    vbox yalign 0.4 xalign 0.86:
        imagebutton:
            idle "images/puzzles/chapter_1/sunmoon_left.png" # Hexagon 4 left
            hover "images/puzzles/chapter_1/sunmoon_left.png"
            action [SetVariable("rotate4", rotate4 + 1), Jump("bedpuzzlebox4add")] mouse "puzzleleft" focus_mask True

    vbox yalign 0.4 xalign 0.86:
        imagebutton:
            idle "images/puzzles/chapter_1/sunmoon_right.png" # Hexagon 4 right
            hover "images/puzzles/chapter_1/sunmoon_right.png"
            action [SetVariable("rotate4", rotate4 - 1), Jump("bedpuzzlebox4minus")] mouse "puzzleright" focus_mask True

    if rotate1 == 1:
        add "sun":
            yalign 0.43 xalign 0.22

    if rotate1 == 2:
        add "sun2":
            yalign 0.43 xalign 0.22

    if rotate1 == 3:
        add "sun3":
            yalign 0.43 xalign 0.22


    if rotate1 == 4:
        add "sun4":
            yalign 0.43 xalign 0.22


    if bedpuzzlefixed:
        if rotate2 == 1:
            add "moon":
                yalign 0.43 xalign 0.425

        if rotate2 == 2:
            add "moon2":
                yalign 0.43 xalign 0.425
        if rotate2 == 3:
            add "moon3":
                yalign 0.43 xalign 0.425

        if rotate2 == 4:
            add "moon4":
                yalign 0.43 xalign 0.425

    if rotate3 == 1:
        add "sun":
            yalign 0.43 xalign 0.63

    if rotate3 == 2:
        add "sun2":
            yalign 0.43 xalign 0.63

    if rotate3 == 3:
        add "sun3":
            yalign 0.43 xalign 0.63

    if rotate3 == 4:
        add "sun4":
            yalign 0.43 xalign 0.63

    if rotate4 == 1:
        add "moon":
            yalign 0.43 xalign 0.835

    if rotate4 == 2:
        add "moon2":
            yalign 0.43 xalign 0.835

    if rotate4 == 3:
        add "moon3":
            yalign 0.43 xalign 0.835

    if rotate4 == 4:
        add "moon4":
            yalign 0.43 xalign 0.835


    textbutton "Close" action [Hide("puzzlebox2", dissolve), Jump("bedpuzzleclose")]:
        text_color "#ffffff"
        text_hover_color "#dcad2b"
        xalign 0.93 yalign 0.1

    textbutton "Hint":
        if puzzlebox2hint == 1:
            action [SetVariable("puzzlebox2hint", puzzlebox2hint + 1), Show("puzzlebox2hint1", dissolve)]
        if puzzlebox2hint == 2:
            action [SetVariable("puzzlebox2hint", puzzlebox2hint + 1), Show("puzzlebox2hint2", dissolve)]
        if puzzlebox2hint == 3:
            action [SetVariable("puzzlebox2hint", puzzlebox2hint + 1), Show("puzzlebox2hint3", dissolve)]
        if puzzlebox2hint == 4:
            action Show("puzzlebox2hint4", dissolve)

        xalign 0.928 yalign 0.15
        text_color "#ffffff"
        text_hover_color "#dcad2b"

    textbutton "Reset puzzle" action [SetVariable("bedpuzzlenumber1", 1), SetVariable("bedpuzzlenumber2", 1), SetVariable("bedpuzzlenumber3", 1), SetVariable("bedpuzzlenumber4", 1), SetVariable("rotate1", 1), SetVariable("rotate2", 1), SetVariable("rotate3", 1), SetVariable("rotate4", 1)]:
        text_color "#ffffff"
        text_hover_color "#dcad2b"
        xalign 0.93 yalign 0.77



screen puzzlebox2hint1:
    modal True

    add "images/Various/black overlay.png"
    add "gui/popup.png" xalign 0.5 yalign 0.5
    text "Hint" xalign 0.5 yalign 0.34 color "#fefefe" size 50
    textbutton "x" action [Hide("puzzlebox2hint1", dissolve)]:
        text_color "#ffffff"
        text_hover_color "#dcad2b"
        xalign 0.68
        yalign 0.28
    vbox:
        xanchor 0.0
        spacing 20.0
        xpos 700
        ypos 450
        text "你可以向左或向右转动每个六角形。"
        text "再次点击提示按钮可获得另一个提示。"

screen puzzlebox2hint2:
    modal True

    add "images/Various/black overlay.png"
    add "gui/popup.png" xalign 0.5 yalign 0.5
    text "Hint" xalign 0.5 yalign 0.34 color "#fefefe" size 50
    textbutton "x" action [Hide("puzzlebox2hint2", dissolve)]:
        text_color "#ffffff"
        text_hover_color "#dcad2b"
        xalign 0.68
        yalign 0.28
    vbox:
        xanchor 0.0
        spacing 20.0
        xpos 700
        ypos 450
        text "你可以在抽屉里找到应该转动六角形的方向。"
        text "再次点击提示按钮可获得另一个提示。"

screen puzzlebox2hint3:
    modal True

    add "images/Various/black overlay.png"
    add "gui/popup.png" xalign 0.5 yalign 0.5
    text "Hint" xalign 0.5 yalign 0.34 color "#fefefe" size 50
    textbutton "x" action [Hide("puzzlebox2hint3", dissolve)]:
        text_color "#ffffff"
        text_hover_color "#dcad2b"
        xalign 0.68
        yalign 0.28
    vbox:
        xanchor 0.0
        spacing 20.0
        xpos 700
        ypos 450
        text "抽屉里每一列箭头对应一个六角形。"
        text "再次点击提示按钮可获得答案。"

screen puzzlebox2hint4:
    modal True

    add "images/Various/black overlay.png"
    add "gui/popup.png" xalign 0.5 yalign 0.5
    text "Hint" xalign 0.5 yalign 0.34 color "#fefefe" size 50
    textbutton "x" action [Hide("puzzlebox2hint4", dissolve)]:
        text_color "#ffffff"
        text_hover_color "#dcad2b"
        xalign 0.68
        yalign 0.28
    vbox:
        xanchor 0.0
        spacing 20.0
        xpos 700
        ypos 450
        text "按照以下方式转动六角形："
        text "Sun 1: Left twice"
        text "Moon 1: Right twice"
        text "Sun 2: Left once, right twice"
        text "Moon 2: Right thrice"



label bedpuzzlebox1add:
    if rotate1 == 5:
        $ rotate1 = 1

    if rotate1 == 0:
        $ rotate1 = 4

    if bedpuzzlenumber1 == 4:
        $ bedpuzzlenumber1 = 1
    else:
        $ bedpuzzlenumber1 += 1

    jump bedpuzzleboxchecker

label bedpuzzlebox1minus:
    if rotate1 == 5:
        $ rotate1 = 1

    if rotate1 == 0:
        $ rotate1 = 4

    if bedpuzzlenumber1 == 1:
        $ bedpuzzlenumber1 = 4
    else:
        $ bedpuzzlenumber1 -= 1

    jump bedpuzzleboxchecker

label bedpuzzlebox2add:
    if rotate2 == 5:
        $ rotate2 = 1

    if rotate2 == 0:
        $ rotate2 = 4

    if bedpuzzlenumber2 == 4:
        $ bedpuzzlenumber2 = 1
    else:
        $ bedpuzzlenumber2 += 1

    jump bedpuzzleboxchecker

label bedpuzzlebox2minus:
    if rotate2 == 5:
        $ rotate2 = 1

    if rotate2 == 0:
        $ rotate2 = 4

    if bedpuzzlenumber2 == 1:
        $ bedpuzzlenumber2 = 4
    else:
        $ bedpuzzlenumber2 -= 1

    jump bedpuzzleboxchecker

label bedpuzzlebox3add:
    if rotate3 == 5:
        $ rotate3 = 1

    if rotate3 == 0:
        $ rotate3 = 4

    if bedpuzzlenumber3 == 4:
        $ bedpuzzlenumber3 = 1
    else:
        $ bedpuzzlenumber3 += 1

    jump bedpuzzleboxchecker

label bedpuzzlebox3minus:
    if rotate3 == 5:
        $ rotate3 = 1

    if rotate3 == 0:
        $ rotate3 = 4

    if bedpuzzlenumber3 == 1:
        $ bedpuzzlenumber3 = 4
    else:
        $ bedpuzzlenumber3 -= 1

    jump bedpuzzleboxchecker

label bedpuzzlebox4add:
    if rotate4 == 5:
        $ rotate4 = 1

    if rotate4 == 0:
        $ rotate4 = 4

    if bedpuzzlenumber4 == 4:
        $ bedpuzzlenumber4 = 1
    else:
        $ bedpuzzlenumber4 += 1

    jump bedpuzzleboxchecker

label bedpuzzlebox4minus:
    if rotate4 == 5:
        $ rotate4 = 1

    if rotate4 == 0:
        $ rotate4 = 4
    if bedpuzzlenumber4 == 1:
        $ bedpuzzlenumber4 = 4
    else:
        $ bedpuzzlenumber4 -= 1

    jump bedpuzzleboxchecker

label bedpuzzleclose:
    $ bedpuzzlenumber1 = 1
    $ bedpuzzlenumber2 = 1
    $ bedpuzzlenumber3 = 1
    $ bedpuzzlenumber4 = 1
    $ rotate1 = 1
    $ rotate2 = 1
    $ rotate3 = 1
    $ rotate4 = 1

    $ renpy.transition(dissolve)
    jump chapter1escaperepeat

label bedpuzzleboxchecker:
    $ puzzleplayerbed = [bedpuzzlenumber1, bedpuzzlenumber2, bedpuzzlenumber3, bedpuzzlenumber4]

    if puzzleplayerbed == puzzleanswerbed:
        jump boxpuzzleboxcomplete

    else:
        $ renpy.call_screen("puzzlebox2")

label boxpuzzleboxcomplete:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    $ bedpuzzlecomplete = True
    no sur "啊！"
    $ candle = True
    "四个按钮发出咔哒声锁定到位。凯恩和诺亚俯身等待着会发生什么。"
    k ser "嗯..."
    no sad "这不像那个其他的拼图那么令人满足啊..."
    k "如果能发出声音就好了..."
    no neu "不管怎样，让我们看看这东西里面有什么。"
    no sur "一支...蜡烛？"
    k sur "有趣..."

    mrf sca "诺亚..."
    "诺亚僵住了。那个声音，那个从未改变的声音。"
    k sad "诺亚，如果你不想和他说话，你不必这样做。"
    no ann "如果我想离开这里，我就别无选择。"
    no neu "里面有什么？"
    mrf sad "我不是...我不是故意的..."
    mrf "这么多年来，我只是想再见到你。向你道歉-"
    no fro "好吧，我在这里了，但这一切都没有意义，因为这不是真正的你。你只是在为自己感到难过而已。"
    no "你觉得你是受害者吗？你觉得我必须原谅你，只因为你想要我这样做？"
    no "不，我宁愿让你坐在那里为自己感到难过。"
    no "除非你能帮助我们离开，否则别来跟我说话。"
    mrf "....."

    window hide dissolve
    jump chapter1escaperepeat


    jump chapter1escaperepeat

label bedpuzzle4:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    "那个盒子被丢弃了——它已经完成了它的目的，现在变得毫无意义。"
    "就像世界上的许多其他事物和人一样。"
    window hide dissolve
    jump chapter1escaperepeat

label bedpuzzleglove:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    "戴上一只手套，诺亚仔细检查着那个盒子。"
    no neu "里面肯定有东西。"
    k neu "听起来是什么样的？"
    no neu "好像是什么长的东西...但我不太确定。"
    k hap "那就赶快把这东西打开吧。"
    no sca "说起来容易做起来难..."
    window hide dissolve
    jump chapter1escaperepeat

label bedpuzzleglove2:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    k neu "谁会把梦境填满谜题呢？这太没道理了。"
    no neu "我怎么会知道？"
    k "你以前做过这样的事，对吗？"
    no "...不，它们不都是这样的。"
    no "我们只是碰到了一个很难完成的梦境而已。"
    window hide dissolve
    jump chapter1escaperepeat

label bedpuzzlescrew:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    "转动着盒子，诺亚仔细检查是否有什么可疑的地方。"
    no neu "什么都没有..."
    k sad "他至少可以想象这些谜题能更容易被破解。"
    no "那就太好了。"
    window hide dissolve
    jump chapter1escaperepeat


label bedpuzzlenote:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    "凯恩盯着手中的纸片，仔细地看着上面的字母。"
    k sad "这真是太奇怪了，不是吗？"
    no neu "什么奇怪？"
    k "这些名字。这些人...他们甚至不是真实的，但却存在于这里..."
    k "我无法理解。"
    no "你会习惯的。"
    no sca "但是...有时候连我自己也分不清什么是真实的，什么是假的。"
    k "..."
    k "嘿，诺亚..."
    no neu "嗯？"
    k "你有没有...也许这不重要..."
    no "快说出来吧。"
    k "....你有没有在这里见过你认识的人？"
    no sad"..."
    no "很久没有了。"
    k "..."
    k "对不起。"
    window hide dissolve
    jump chapter1escaperepeat

label bedpuzzlekey1:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    no neu "这里不合适..."
    k hap "那就从名单上划掉一个地方。"
    no "你总是能在任何事情中找到积极的一面，你知道。"
    k "我们中的一个人必须这样。"
    window hide dissolve
    jump chapter1escaperepeat

label bedpuzzlekey2:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    no neu "这里似乎没有别的东西了..."
    k neu "没有，看起来完全是空的。"
    window hide dissolve
    jump chapter1escaperepeat

label barsglovesscene:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    "在牢房外，只有两样东西存在。"
    "黑暗，和钥匙。"
    "诺亚紧紧抓住栏杆，指节发白。"
    k ser "...我们快到了。我能感觉到。"
    no sca "是啊..."
    window hide dissolve
    jump chapter1escaperepeat

label bedglovesscene:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    no neu "我想现在我有这些了，我可以再检查一下床铺..."
    "诺亚戴上手套，再次仔细检查了脏乱的床铺。"
    no "看来只有那把螺丝刀。"
    k hap "我开始觉得你在那里玩侦探游戏，很享受。"
    no "这一点也不好笑。"
    window hide dissolve
    jump chapter1escaperepeat

label ballglovesscene:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    "戴着手套的手指轻轻滑过各个表面。"
    no neu "对于一个牢房来说，还算干净。"
    k neu "看来这里的清洁服务还不错。"
    window hide dissolve
    jump chapter1escaperepeat

label scribbleglovesscene:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    k hap "你真的在拖延时间，不是吗？"
    no fro "我不知道你在说什么。"
    k "每次你不小心看向那个桶的时候，你眼中的恐惧都说明了一切。"
    no "...."
    k "拜托，我说我会做的。"
    no sca "....没关系。"
    window hide dissolve
    jump chapter1escaperepeat

label bedsideglovesscene:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    k hap "把它们放回去也救不了你了。"
    no sca "...."
    no "我很高兴你玩得开心。不管我是死在这里还是不死，我都不在乎。我只是为了你在努力。"
    k "为了我？我的铠甲骑士。那我就努力忍住笑声吧。"
    no neu "谢谢，我很感激。"
    k "呼呼..."
    no "这只持续了大约五秒钟。"
    window hide dissolve
    jump chapter1escaperepeat

label bucketscene1:
    $ gametype = "NVL"
    hide prisonescape
    $ charleft = "诺亚"
    $ charright = "凯恩"
    $cs_left = "noah n neu"
    $cs_right = "kaine n ser"

    $ nvl_show(Dissolve(1))

    knvl "...."
    nonvl "...."
    $cs_right = "kaine n sur"
    knvl "看来是逃不过要看它的命运了，是吗..."
    $cs_left = "noah n hur"
    nonvl "啊..."
    nv "捏住鼻子，诺亚探头看向桶边。一种浑浊的液体静静地躺在里面。"
    nonvl "我绝对不会把手伸进去的。"
    $cs_right = "kaine n hap"
    knvl "那就让你来吧。"
    $ cs_left = "noah n sca"
    nonvl "你多大了？"
    knvl "上次我检查的时候是24岁。"
    nonvl "哈哈。"
    $cs_right = "kaine n ser"
    knvl "我幽默的事情就不说了，你...真的认为在*那里*会有什么东西藏着吗？"
    nonvl "我也不会对他有什么期望。"
    knvl "...."
    nonvl "......"
    knvl ".........."
    nonvl ".............."
    knvl "...我们为什么不把这个留到最后一个选择呢？"
    nonvl"....是的，这可能是个好主意。"
    $cs_right = "kaine n hap"
    knvl "除非你愿意把手伸进去？"
    $cs_left = "noah n hur"
    nonvl"不，不，我们现在就把这个放一放吧！"


    nvl clear

    $ nvl_hide(Dissolve(0.6))
    jump chapter1escaperepeat

label bucketscene2:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    no sca "为什么他要梦到这种细节..."
    "身后传来一声抽泣，诺亚尽力忽视了它。"
    window hide dissolve
    jump chapter1escaperepeat

label bucketscrewscene1:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    "手里拿着螺丝刀，对活下去的意志也快要消失殆尽，诺亚转向了那个桶。"
    no sca "...."
    no "看来没有别的选择了..."
    k sur "接下来的计划是什么？"
    k "拧开它？"
    no "让里面的东西洒满地板？不行。"
    no "我只是想看看里面是否真的有什么东西。"
    "螺丝刀插入那浑浊的液体，越插越深，直到碰到了一些东西，发出了轻微的声响。"
    no "里面确实有什么东西。"
    k "哦？"
    no hur "但我还是不想把赤手直接伸进去。我不知道里面有什么。"
    k hap "我想我可以猜个大概。"
    no "请不要。"
    window hide dissolve
    jump chapter1escaperepeat

label bucketscrewscene2:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    no neu "这里已经没有什么可以用螺丝刀的了...我希望如此。"
    k hap "你想再来一次那个桶吗？"
    no sca "我想我会放弃，不过你随意。"
    window hide dissolve
    jump chapter1escaperepeat

label bucketnotescene:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    k ser "所以，诺亚..."
    no neu "什么？"
    "凯恩把手里的纸团成一团——这是他在对某事感到焦虑时的习惯。"
    k sad "我只是在想，你知道..."
    no "不，我不知道。"
    k ser "....我只是在想，很高兴看到你变得更加...主动。"
    no neu "这是什么意思？"
    k "我只是说，这是你第一次离开家...多久了？"
    no "...."
    no sca "...那又怎样？这不关你的事。"
    k hap "我只是很高兴，好吗？我一直都希望你能这样。"
    no "被困在一个肮脏的桶里聊天？"
    k neu "嗯..不完全是。不过，这至少是朝着正确方向迈出的一步。"
    no "...."
    no "是啊，随便吧。这次我没有选择，但我不会再这样做了。"
    k sur "但是...为什么不呢？"
    no "...我不想继续前进。"
    k sad "诺亚，我...我不是说你必须完全放下，或忘记他，但是—"
    no fro "我说我不想。"
    k "好吧...."
    window hide dissolve
    jump chapter1escaperepeat

label bucketkeyscene:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    "诺亚手指上的钥匙不停地旋转，他盯着桶底看。"
    no neu "我从未如此感谢生活在现代社会。"
    window hide dissolve
    jump chapter1escaperepeat


label bucketglovesscene:
    hide prisonescape
    $ gametype = "NVL"
    hide prisonescape
    $ charleft = "诺亚"
    $ charright = "凯恩"
    $cs_left = "noah n sca"
    $cs_right = "kaine n ser"

    $ nvl_show(Dissolve(1))

    nonvl "我真不敢相信我在做这件事。"
    knvl "如果你想让我来试试的话，我随时奉陪。"
    nonvl "....不，不...我至少可以自己做到这一点。"
    $cs_right = "kaine n sad"
    knvl "依赖我也没什么不好的。"
    $cs_left = "noah n sad"
    nonvl "...."
    nv "诺亚皱了皱眉头，没有回应凯恩，而是把手伸进了桶里。"
    $cs_right = "kaine n ser"
    knvl "怎么样？"
    nonvl "..."
    nv "他小心翼翼地把手里的东西拿了出来，好像害怕发现自己抓到了什么。"
    $ cs_left = "noah n neu"
    nonvl "一个瓶子..."
    nv "玻璃瓶很脏，遮住了里面的东西。"
    nv "凯恩凑近观察，诺亚拔掉瓶塞，把里面的东西倒在了石头地上，发出咔哒一声。"
    nv "从地上向上看，是一个小六边形，上面有新月图案。"
    $cs_right = "kaine n sur"
    knvl "说实话，这不是我预料中的东西。"
    nonvl "我把手伸进那么脏的东西里，总算找到了这个，真是值得。"

    $ charright = "弗洛伊德先生"
    $cs_right = "mf n sad"

    mrwnvl "...那个桶只是用来接漏水的，已经放在那里很久了..."
    $cs_left = "noah n sur"
    nonvl "..."
    $ charright = "凯恩"
    $cs_right = "kaine n hap"
    knvl "看来你白担心了，是吧？"

    nvl clear
    $ nvl_hide(Dissolve(0.6))
    jump chapter1escaperepeat


label bucketglovesscene2:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    k hap "再看一眼吗？"
    no sad "不用了..."
    window hide dissolve
    jump chapter1escaperepeat


label barshexagonscene:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    k ser "你知道，我一直在想一件事。"
    no neu "那是什么事？"
    k "你最后一次遇到他是什么时候？"
    "当凯恩指向那个被锁链锁住的男人时，诺亚握住手中六边形物品的手更紧了。"
    no fro "为什么这很重要？"
    k "我只是好奇。"
    no "...从那之后就再也没见过他。"
    k "是这样啊..."
    no "什么？"
    k "我听说，在他被强制撤职后，他就辞去了教师的工作。"
    no "好极了。"
    window hide dissolve
    jump chapter1escaperepeat

label bedhexagonscene:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    "凯恩和诺亚转过身，看向被锁在墙上的男人，他动了动，锁链在石头地板上发出刺耳的声音。"
    "金属摩擦的声音刺痛了他们的耳朵，但那个男人没有开口说话。"
    "相反，他盯着诺亚，诺亚迅速移开了视线，手仍然紧握着那个奇怪的六边形物品。"
    window hide dissolve
    jump chapter1escaperepeat

label ballhexagonscene:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    "诺亚的手在金属物品上摸索着。"
    no neu "这里什么都没有。"
    k sur "看来只是一个普通的球形锁链。"
    k "在这里，有些简单朴素的东西反而让人感到舒适。"
    no hap "这只是冰山一角，涉及到奇怪的梦境。"
    window hide dissolve
    jump chapter1escaperepeat

label scribblehexagonscene:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    k ser "我不认为这与我们手头的这个拼图碎片有任何关系。"
    no neu "你说得很对。"
    window hide dissolve
    jump chapter1escaperepeat

label bedsidehexagonscene:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    k sur "嘿...再给我看看你找到的那个东西。"
    no neu "你知道，我找到了很多东西。"
    k "你知道的，那个六边形的东西。"
    no "你从一开始就可以这么说...给你。"
    show popout onlayer front
    show drawerpopout onlayer front:
        xpos 0.49 ypos 0.69 xanchor 0.5 yanchor 1.0
    with dissolve
    k "你不觉得这看起来很像抽屉里的那幅画吗？"
    hide popout onlayer front
    hide drawerpopout onlayer front
    with dissolve
    no sur "...你说得对，它们很相似。"
    window hide dissolve
    jump chapter1escaperepeat

label buckethexagonscene:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    k hap "别把它扔回去了。你可不想再去捞它出来吧？"
    no sca "好吧，好吧..."
    window hide dissolve
    jump chapter1escaperepeat


label barscandlescene:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    "诺亚盯着那把钥匙，它还在守卫离开时留下的地方摇晃。他紧紧握住了手中未点燃的蜡烛。"
    no sca "我们经历了这么多愚蠢的障碍，而钥匙还是那么遥不可及。该死。"
    k sad "..."
    k "我觉得我们已经取得了一些进展。"
    no "如果我能...拉一下那根绳子，或者..."
    "他再次低头看着手中的蜡烛，眼睛睁大了。"
    no sur "或者..."
    window hide dissolve
    jump chapter1escaperepeat

label bedcandlescene:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    "诺亚和凯恩绕着床走动，目光在房间里游移。"
    "冰冷、不友好。这里弥漫着一种等待死亡降临的氛围。"
    "诺亚的目光落在他的老师身上，他看起来和记忆中一样苍老。"
    no sad "不管死亡是否降临在他身上，我都不在乎。"
    k sur "诺亚？"
    window hide dissolve
    jump chapter1escaperepeat


label ballcandlescene:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    k neu "我觉得这里什么都帮不了我们。"
    no fro "我知道。你不用告诉我。"
    k sad "..."
    k "诺亚，我...我知道你不想来这里。或者说，你也不想和我一起来。"
    k "但是..."
    k "如果我必须和谁一起经历这一切，那个人就是你。我很想念和你在一起的时光。"
    "心中一阵刺痛。"
    no sad "...我们就赶快离开这里吧，好吗？"
    window hide dissolve
    jump chapter1escaperepeat

label scribblecandlescene:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    k sad "嘿，诺亚。"
    "诺亚跪下来，用手指沿着刻在墙上的雕刻边缘摸索。"
    no neu "什么？"
    k "我..."
    "凯恩的声音有些紧张。"
    k "我希望你当时就告诉过我这一切。所有的一切。"
    no fro "...那又有什么区别呢？"
    k "也许没什么区别。我可能当时也不会相信你，但是..."
    k "...但我以为你可以依赖我，告诉我任何事。"
    no sad "...."
    no "这不是我想要让你承担的负担。"
    k "你告诉他了吗？"
    no "...."
    no ang "你为什么关心我告诉了谁什么？"
    k "...我不是那个意思。对不起。"
    k "我们就赶快离开这里吧。"

    window hide dissolve
    jump chapter1escaperepeat

label bedsideunlitcandlescene:

    hide prisonescape
    $ gametype = "NVL"
    hide prisonescape
    $ charleft = "诺亚"
    $ charright = "凯恩"
    $cs_left = "noah n neu"
    $cs_right = "kaine n ser"

    $ nvl_show(Dissolve(1))

    nv "被锁链拴在墙上的那个男人在原地挪动。"
    nv "金属摩擦石头的刺耳声音让凯恩忍不住在原地来回移动。"
    nv "当诺亚转向那个声音时，一个场景浮现在他的脑海中。"
    nv "外面，阳光高照。有人站在教室前，在白板上写着什么。"
    nv "他无意识地用笔敲着桌子，老师的声音变成了背景噪音。他瞥向一边。"
    nv "一个戴着圆眼镜的金发男孩回望着他，然后微笑。"
    nv "那个场景渐渐消失在虚无之中。"
    nv "取而代之的是他童年时的老师，蜷缩在地上，完全孤独。"
    nv "诺亚转身离开那个人的残躯，转向床头柜。上面固定着一盏小灯。"
    nv "他迅速将蜡烛浸入其中，点燃了灯芯。"
    nv "火焰摇曳不定。"
    nv "诺亚屏住了呼吸。"
    nv "自由。"

    $ litcandle = True
    $ default_mouse = "default"
    $ iteminhand = "None"

    nvl clear
    $ nvl_hide(Dissolve(0.6))
    jump chapter1escaperepeat


label bedsidelitcandlescene:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    "桌子上再也没有其他东西了。它已经像这个梦境中的许多其他事物一样，放弃了自由。"
    window hide dissolve
    jump chapter1escaperepeat

label bucketcandlescene:
    $ gametype = "ADV"
    window show dissolve
    hide prisonescape
    no neu "这里似乎没有别的东西了..."
    window hide dissolve
    jump chapter1escaperepeat

label barslitcandlescene:
    $ default_mouse = "default"
    $ iteminhand = "None"
    $ gametype = "NVL"
    hide prisonescape
    $ charleft = "诺亚"
    $ charright = "凯恩"
    $cs_left = "noah n neu"
    $cs_right = "kaine n ser"
    $ _skipping = True

    nonvl "...就是这个了。"
    $cs_right = "kaine n sur"
    knvl "什么就是这个了？你在做什么？"
    nonvl "这是我们唯一的选择。看。"
    nv "诺亚指向悬挂在细绳上的钥匙，周围有一些黑色的液体。"
    knvl "你是...打算赌上一切，用蜡烛去点燃那根绳子吗？"
    $cs_left = "诺亚和安娜"
    nonvl "你不觉得那看起来像是油吗？如果着火了，钥匙掉到地上，我们应该能够够到它。"
    $cs_right = "kaine n sad"
    knvl "...."
    $cs_right = "kaine n hap"
    knvl "对...好吧，我相信你。我们开始吧。"
    nv "诺亚艰难地吞了口唾沫。"
    nv "平稳他颤抖的手，他紧紧握住点燃的蜡烛，估量着他需要扔多远。"
    $cs_left = "noah n fro"
    nonvl "好了！"
    nv "轻轻地，为了不在到达绳子之前就熄灭，诺亚把蜡烛扔向了钥匙。"
    nv "瞬间，油池起了火，绳子也迅速燃烧了起来。"
    nv "几秒钟后，钥匙落到了石头地板上，发出一声响亮的撞击声，几乎弹向了诺亚。"
    nv "他尽可能地伸进栏杆之间，以至于他的肩膀因被硬金属压迫而感到疼痛。"
    nv "终于，它在他的掌握之中了。一把由黑色生锈金属制成的钥匙，静静地躺在他的掌心。"
    nv "他紧紧地抱住它。"
    $cs_left = "noah n hap"
    nonvl "是的...！"
    $cs_right = "kaine n sur"
    knvl "你拿到了吗？！"
    nv "当他从地上站起来时，凯恩用胳膊搂住了诺亚的肩膀，把他拉近，几乎要揉乱他的头发。"
    $cs_right = "kaine n hap"
    knvl "我从未怀疑过你。"
    $cs_left = "noah n shy"
    nonvl "胡说八道。嘿，放开我..."
    nv "在这个昏暗肮脏的监狱里，这一幕在梦境中上演，让诺亚感到了一种怀旧。"
    nv "好像什么都没有改变。"
    nv "就像他还是个上学的孩子，前途一片光明。"
    nv "当他突然意识到未来和现在的重担时，他脸上的笑容消失了。"
    nv "这种感觉，这种怀旧，他怎么会有这种感觉？"
    nv "他怎么敢有这种感觉？感到幸福？"
    nv "他从凯恩身边退开，拍了拍自己的衣服。"
    $cs_left = "noah n fro"
    nonvl"...来吧，我来解开他的锁链。"
    $cs_right = "kaine n shy"
    nv "一直在和诺亚一起微笑的凯恩也停下了兴奋。他挠了挠后脑勺，好像为自己突然的爆发而感到尴尬。"
    knvl "对，对。这就是我们来这里的原因。"
    nonvl "..."
    nonvl "是时候走了，弗洛伊德先生。"
    $cs_right = "mf n sad"
    $ charright = "弗洛伊德先生"
    mrwnvl "...我真的可以离开吗？"
    nv "诺亚跪下来，迅速解开了束缚住那个男人的锁链。他的手腕都是血淋淋的瘀伤。"
    $cs_left = "诺亚和安娜"
    nonvl "是的。是时候走了。"
    nv "出于某种不知原因的原因，诺亚伸出手帮助他的老师从地上站起来。弗洛伊德先生的脸上满是复杂的情绪，但似乎没有一种情绪占上风。"
    nv "他张开嘴又闭上，反复几次。"
    nv "他有很多话想说。"
    nv "但什么也没有说出口。"
    nv "诺亚背过身去，朝着上锁的门走去。"
    "钥匙轻松地插进锁孔，门开了。"
    $ persistent.chapter1_escapecomplete = True
    hide note
    nvl clear
    $ ui.layer("farback") # NEED THIS AFTER AN ESCAPE ROOM TO CLEAR THE SCREEN
    $ ui.clear()
    $ ui.close()

    $ nvl_hide(Dissolve(0.6))

    stop music fadeout 5.0

    jump chapter1_escape_complete


label chapter1_escape_VN_version:
    stop music fadeout 2.0
    scene bg prison2
    $ camera_reset()

    $all_moves(camera_check_points={u'y': [(-1813, 0, u'ease')], u'x': [(-4451, 0, u'ease'), (4750, 35.24, u'ease')], u'z': [(767, 0, u'ease')]})
    with dissolve
    "凯恩走到门边，摇晃着栏杆，而诺亚则沿着墙壁摸索，寻找隐藏的隔间。"
    play music letmedown fadein 4.0
    "石头冰冷刺骨，他打了个寒战，继续前进。"
    "从这个石头房间里看不见的牢房里，诺亚能听到轻声的哭泣和低语的祈祷。"
    "他闭上了眼睛。"
    "这一切都不是真的。他知道。"
    "但它感觉很真实。每一个细节都是如此。"
    "摇了摇头，他继续搜索，寻找任何逃脱的线索。"
    "与此同时，弗洛伊德先生一直在沉默地观察他的动作。"
    "诺亚讨厌他的目光。他感到自己很透明，对这个他如此憎恨的男人来说太过可见。"
    "但他还是继续搜索，最终找到了一块松动的砖块。"
    "但不管他怎么推拉，它都纹丝不动。"
    no ann "凯恩，你能帮帮忙吗？"
    "这个棕发男子走了过来，诺亚让开了位置。"
    "凯恩和诺亚可能是同龄人，但而诺亚有一个隐居艺术家的体型，凯恩显然经常锻炼。"
    "他的肌肉很壮实...显然也很强劲，因为他只是轻轻一用力，那块砖块就被撬了出来。"
    "两个人都围在这个小洞边，看看里面有什么。"
    "...一把钥匙。"
    k sur "哈。没那么难，是吧？"
    no "你现在就在诅咒它。"
    "他从小凹陷处抽出手，走回到被锁链束缚在墙上的弗洛伊德先生身边。"
    "他那样无助，甚至可以说是可怜。这让诺亚感到一阵内疚，但他立刻压制住了这种感觉。"
    no "...我们有钥匙了。来吧，我们要离开这里。"
    mrf sad "...."
    mrf "诺亚，我..."
    no "没时间闲聊，我也不想听。"
    mrf "...你的眼睛为什么会是那样？"
    "这个问题让诺亚措手不及。他和凯恩交换了一个眼神，然后又看向弗洛伊德先生。"
    no sho "你是什么意思...？"
    mrf "它们失去了光芒。"
    no "...."
    no ann "我所有的世界里都没有光明了。"
    mrf "...这真是太令人伤心了。"
    no fro "是啊，生活就是这么操蛋。别浪费我的时间了，把手伸出来。"
    "那个高大的男人照做了，尽可能远离墙壁伸出一只手臂，让诺亚能够够到他的手铐。"
    "费了一番功夫，但诺亚最终还是设法打开了那个大金属手铐的锁，解救了弗洛伊德先生。"
    no "让我们打开门吧。"
    "弗洛伊德先生没有动。他只是一直盯着诺亚。"
    mrf "诺亚...我不是...我不是故意的..."
    mrf "这么多年来，我只是想再见到你。向你道歉-"
    no "好吧，我在这里了，但这一切都没有意义，因为这不是真正的你。你只是一个空虚的人影，正在为自己感到过于抱歉。"
    no "你觉得你是受害者吗？你觉得我必须原谅你，只因为你想要我这样做？"
    no "绝对不行。"
    no "所以别装作你在乎，因为我可以向你保证，我根本不在乎你的理由。你那时毁掉了我的生活，一切只会越来越糟。"
    mrf "我..."
    no ann "我以为我可以相信你。"
    k sad "诺亚，来吧，让我们试试门。"
    "诺亚最后看了一眼那个男人，然后跟着凯恩走向门口。"
    k "你还好吗？"
    no ann "...不太好。"
    no "我从没想过会再见到他。"
    k ser "老实说，我也没想过。"
    k "我相信我们离开这里后就再也不会见到他了。"
    no "...是的。"
    "他回头看了一眼，发现弗洛伊德先生没有动。他只是静静地坐着，看着两人互动。"
    "诺亚试着把钥匙插进锁孔，但很快就听到了沉重的脚步声朝这个牢房走来。"
    "诺亚和凯恩赶紧躲到一边，贴着墙壁蹲下，尽量让自己看起来很小。"
    "很快，脚步声就渐渐远去了，诺亚站起来，把钥匙插进锁孔。"
    scene bg prison2
    $ camera_reset()

    with dissolve
    k sad "嘿，诺亚..."
    k "...你说你以前经常这样做，对吗？它们...一直都是这样的吗？"
    no neu"什么样的？"
    k  "...如此敌意？"
    no "..."
    no ann "我以为我在成长过程中见识过周围人最糟糕的一面，我以为我在某种程度上知道自己有多不受欢迎。"
    no "...事实证明，那只是他们真实感受的冰山一角。一旦我开始来这里，我就很快就明白了。"
    no "现实世界只会让你看到人们真实想法的一小部分。"
    no "在这里，他们会说出一切。你真的会知道人们对你的看法。"
    no "所以，是的，它们都是这样的，某种程度上来说。"
    k sad "诺亚...并不是所有人都是那样的。"
    no hur "...剩下的人都是那样的。"
    "然后他转动了钥匙。"
    "凯恩用胳膊搂住他的肩膀，门开了，他咧嘴一笑，揉了揉诺亚的头发。"
    k hap "我从未怀疑过你。"
    no hap "胡说八道。嘿，放开我..."
    "诺亚也忍不住微微一笑。"
    "在这个昏暗肮脏的监狱里，这一幕在梦境中上演，让诺亚感到了一种怀旧。"
    "好像什么都没有改变。"
    "就像他还是个上学的孩子，前途一片光明。"
    "当他突然意识到未来和现在的重担时，他脸上的笑容消失了。"
    "这种感觉，这种怀旧，他怎么会有这种感觉？"
    "他怎么敢有这种感觉？感到幸福？"
    "他从凯恩身边退开，拍了拍自己的衣服。"
    no sca "...好了，是时候走了。"
    "一直在和诺亚一起微笑的凯恩也停下了兴奋。他挠了挠后脑勺，好像为自己突然的爆发而感到尴尬。"
    k shy "对，对。这就是我们来这里的原因。"
    "出于某种不知原因的原因，诺亚伸出手帮助他的老师从地上站起来。弗洛伊德先生的脸上满是复杂的情绪，但似乎没有一种情绪占上风。"
    "他张开嘴又闭上，反复几次。"
    "他有很多话想说。"
    "但什么也没有说出口。"
    "诺亚背对着那个男人走回门口。"
    stop music fadeout 5.0

    jump chapter1_escape_complete




    #
