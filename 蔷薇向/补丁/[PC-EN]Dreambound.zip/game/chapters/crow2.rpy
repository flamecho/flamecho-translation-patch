label crow_chapter2:


    window auto
    scene black with dissolve
    pause 1.0

    call screen crow2_chapter_screen
    scene bg noahbedroom night
    $ camera_reset()

    with Fade(1.0, 1.0, 1.0)
    window show

    no ann "啊..."
    play music thiscloud fadein 4.0
    "诺亚在床上翻滚，直到撞到一个坚硬的东西。"
    "一个坚硬、温暖、肉乎乎的东西，这绝对不是你在床上意料之外会遇到的最佳组合。"
    no sur "这是什么..."
    "伊万翻了个身，伸展了一下肩膀，打了个哈欠。"
    no fro "{i}你{/i}他妈怎么会在这里？"
    i neu "你的朋友让我进来的。"
    no sho "谁...？"
    i ann "在你的沙发上。别跟我说话，我要睡觉了。"
    "他翻了个身，背对着诺亚。"
    no ann "....好吧。"

    scene bg paint day with Fade(1.0, 1.0, 1.0)

    "坐在沙发上，表情既严肃又疲惫的是凯恩。"
    scene bg paint day:
        subpixel True xpos 0.62 ypos 1.4 xanchor 0.5 yanchor 1.08 zoom 1.31 rotate None
    show noah m dim ann at slightright:
        xpos 0.87 ypos 1.0 xanchor 0.8 yanchor 1.0
    show kaine m dim ser at slightleft:
        subpixel True xpos 0.12 ypos 1.0 xanchor 0.2 yanchor 1.0 rotate None
    with dissolve

    no "...早上好。"
    no "我想是这样的。"
    show kaine m dim fro with dis
    k "......."
    no "....很高兴看到你还活着。"
    "凯恩继续盯着放在腿上的双手。诺亚走近了一些。"
    no "一切...都还好吗？"
    k "一切都很完美。完美极了。"
    "他长长地叹了一口气。"
    show kaine m dim sad with dis
    k "我被解雇了。"
    show noah m dim sho with dis
    no "..."
    show noah m dim sad with dis
    no "对不起——"
    k "我差点失去你。"
    show noah m dim ann with dis
    no "我...我很好..."
    show kaine m dim fro with dis
    k "如果你没有呢？如果卢卡真的杀了你呢？"
    show kaine m dim sad with dis
    k "我知道这很危险。我知道当我同意跟你来的时候，好吗？但是...这太过分了..."
    show noah m dim fro with dis
    no "..."
    stop music fadeout 4.0
    no "我没有要你来。"
    no "你说你不会试图阻止我去。"
    show kaine m dim ser with dis

    play music someonessign fadein 4.0
    k "直到我证明克劳不是...不可能是奥古斯特。"
    k "你和我一样看到了卢卡给我们看的那个故事。"
    k "它说...它说他不是人类。他是在{i}那里{/i}出现的。"
    k "你还需要什么更多的证据？"
    show noah m dim ann with dis
    no "这并不能证明什么。卢卡一直都是个说谎者。"
    k "我觉得他没有说谎。"
    show noah m dim fro with dis
    no "所以你相信他而不相信我？"
    show kaine m dim sur with dis
    k "什么？诺亚，不，这不是...这根本不是我的意思..."
    show noah m dim ang with dis
    no "那你{i}到底{/i}是什么意思？"
    show kaine m dim ser with dis
    k "我的意思是...我就是能感觉到那是真的。你有没有看到他的反应？"
    k "这不可能是假的。"
    show noah m dim sad with dis
    no "...这并不能证明什么。"
    no "他可能忘记了...他可能被困在那里...你为什么这么快就放弃他？"
    show kaine m dim sad with dis
    k "你为什么这么坚持要相信一个陌生人而不是你最好的朋友？"
    show noah m dim ang with dis
    no "嗯，我不知道，也许是因为这是我拯救一个我以前无法拯救的人的唯一机会！"
    show noah m dim fro with dis
    no "那罗莎米呢？那确实是她。她被{i}困{/i}在那里，需要帮助。"
    show kaine m dim ang with dis
    k "为什么非得是你来帮她？！"
    show noah m dim ann with dis
    no "为什么不应该是我？"
    no "不管我喜不喜欢，我都有这种能力。为什么不应该用它来做点好事？"
    no "为什么我就应该视而不见，只因为有点危险？"
    show kaine m dim sad with dis
    k "哈...我不是来吵架的，我只是..."
    "凯恩从沙发上站了起来，诺亚终于注意到他眼角有泪水。"
    "他用他那双长腿大步走到诺亚面前。"
    show noah m dim sur with dis
    "他伸出双臂抱住了黑发男子，把脸埋在他的肩膀上。诺亚呆立在那里，然后轻轻地抚摸着他的背。"
    show kaine m dim sad with dis
    k "我不会...我不会食言，但是..."
    k "我不想再失去你了。我做不到。这太不公平了。"
    show noah m dim sho with dis
    no "........"
    k "你从来没有想过...也许...如果那些人不在的话，你的生活会更好吗？"
    no "....."
    "诺亚皱起了眉头。"
    show noah m dim fro with dis
    no "是啊，那又怎样？"
    show kaine m dim ser with dis
    k "那为什么不就——"
    show noah m dim ang with dis
    no "你怎么了？"
    no "在这个世界上，我以为你会是最关心别人死亡的人。"
    show kaine m dim ser with dis
    k "....."
    k "我不关心其他任何人。我只想让你安全和快乐。这就是全部。"
    show kaine m dim sur with dis
    no "如果你想让我快乐，那就让我一个人呆着吧！"
    no "你一直在说你，你，你。你不想独自一个人，你不想发生什么事情在我身上，你不想失去我。"
    no "但是你有没有想过我想要什么？！"
    show kaine m dim sad with dis
    k "我—"
    show noah m dim ann with dis
    no "也许如果你{i}真的{/i}失去了我，你才会感受到一丝我失去唯一关心我的人时的痛苦。"
    show kaine m dim sur with dis
    k "......"
    show noah m dim sur with dis
    no "......"
    show noah m dim sad with dis
    no "我不是...我不是那个意思..."
    i neu "哎呀。"
    "伊万站在诺亚卧室的门口，双臂交叉。"
    k "唯一的人？"
    no "..."
    no "我出去了。"
    k "去哪里？"
    no "去见奥古..."
    show noah m dim fro with dis
    no "...去见克劳。亲自见一见。"
    no "你可以继续相信他不是真的。"
    show kaine m dim sad with dis
    k "....我亲眼看到奥古斯特死去的，诺亚。他不是他。"
    no "..."
    no "...我不相信你。你当时不在场。"
    show kaine m dim fro with dis

    k "不，{i}你{/i}当时不在场！"
    "诺亚打开了门，然后重重地关上了。"

    stop music
    play sound doorslam
    scene bg streets day

    $all_moves(camera_check_points={u'y': [(3010, 0, u'ease')], u'x': [(6000, 0, u'ease'), (-6000, 45.85, u'ease')], u'z': [(1015, 0, u'ease')]})
    with hpunch

    nothought "该死...我受够被困在那里了..."
    play music whodidyoulove fadein 5.0
    nothought "我需要呼吸些新鲜空气..."
    nothought "就像我的生活陷入了循环重复...凯恩一直来找我，让我停下..."
    "然后这件事发生在了诺亚身上。"
    "他并没有对户外感到紧张或害怕。相反，蓝天的景象让他感到宁静。"
    nothought "我要去见他。"
    nothought "现在就去见他。"
    nothought "你一定就在这片天空下某处等待着我，对吗？"
    "他的脚步越来越快，朝着他们说好的会面地点赶去。"

    scene bg diner day
    $ camera_reset()

    $all_moves(camera_check_points={u'y': [(2470, 0, u'ease'), (942, 4.14, u'ease')], u'z': [(855, 0, u'ease')]})
    with Fade(1.0, 1.0, 1.0)

    nothought "希望他们不会认出我...我知道我们最后还是付了账单，但还是..."
    "服务员领诺亚到了座位，他点了一杯饮料，感到有些紧张。"
    tv "又有一具尸体出现了，与之前的案件有相似的标记。这次是一名名叫卢卡·贝尔沃斯的年轻成年人。"
    tv "警方今天早上发布了声明。"
    "诺亚转过身，不再关注电视。"
    no neu "所以他真的死了。"
    nothought "他活该，我也不为他感到遗憾。"
    nothought "不过...这并不是我想要的结果。"
    "服务员端来诺亚的苏打水，里面有五块冰块。"

    $all_moves(camera_check_points={u'y': [(2937, 0.0, u'ease'), (-1024, 10.57, u'ease')], u'x': [(5561, 0, u'ease')], u'z': [(1088, 0, u'ease')]})
    with dissolve
    "半个小时过去了。"
    "诺亚漫不经心地看着云朵缓缓飘过。"

    $all_moves(camera_check_points={u'y': [(708, 0, u'ease')], u'x': [(-337, 0, u'ease'), (-6000, 15.62, u'ease')], u'z': [(1008, 0, u'ease')]})
    with dissolve
    "一个小时过去了。"
    "诺亚不耐烦地敲着桌子。"

    $all_moves(camera_check_points={u'y': [(-2982, 0, u'ease'), (2433, 15.17, u'ease')], u'x': [(328, 0, u'ease')], u'z': [(869, 0, u'ease')]})
    with dissolve
    "两个小时过去了。"
    "诺亚看着最后一块冰块融化在苏打水中。"
    "他喝了一口，已经没什么味道了。"
    "没有人来。"
    "一阵疲惫感袭来。"
    nothought "我就闭上眼睛休息一会儿...是的，等我醒来他就会在这里了。"

    scene bg diner day with Fade(1.0, 3.0, 1.0)

    no sho "....."
    "诺亚从桌边坐了起来。"
    "咖啡馆里空无一人，服务员都走了，厨房也静悄悄的。"
    "他焦急地把目光转向对面的座位。"


    scene bg diner day with dis:
        subpixel True xpos 0.73 ypos 1.15 xanchor 0.5 yanchor 1.0 zoom 1.66 rotate None
    show noah m sur at slightleft:
        subpixel True xpos 0.13 ypos 1.0 xanchor 0.2 yanchor 1.0 rotate None

    show crow m sadsmi at slightright:
        xpos 0.85 ypos 1.0 xanchor 0.8 yanchor 1.0
    with dissolve

    no "...你来了。"
    "克劳微微一笑，但与往常有些不同。"
    show noah m sho with dis
    no "我去给我们点些饮料—"
    "但就在他说这话的时候，他意识到了。"
    "这里已经没有人可以点饮料了。"
    "窗外的世界已经停滞不前。"
    show noah m sur with dis
    no "........"
    no "这是一个梦吗？"
    c "...对不起，我来晚了。我花了一些时间来安排这一切。"
    "诺亚感到整个存在都被一种沉重压在了灵魂之上。"
    show noah m sad with dis
    no "....."
    no "你说...你就在这里，这就足够了，但是..."
    no "但是卢卡说的..."
    c "你在想...我是否真的存在？"
    c "不，我...我想我并不真实。"
    no "那你到底是...什么？"
    c "只是一个存在来帮助你的无名之辈而已。"
    c "卢卡说的大部分是真的。"
    no "但...这说不通啊，那奥古斯特呢？！"
    show crow m sad with dis
    c "我从来没有...我做不到..."
    c "我...我从未真正成为过奥古斯特。我想要假扮他，如果这能帮到你的话...但是..."
    c "但这太痛苦了...太痛苦了，去假扮一个对你如此重要的人，一个我永远无法成为的人。"
    no "但你看起来就像他..."
    c "......"
    c "我知道。"
    nothought "他...不是奥古斯特。"
    nothought "凯恩是对的。"
    nothought "奥古斯特..."
    nothought "已经死了。"
    "意识到奥古斯特真的已经不在了，让他感到麻木，但不知为何，当他看着克劳时，他竟然感到内心平静了下来。"
    c "对不起，诺亚，我很抱歉。我撒了谎，欺骗了你。我想要你...我以为如果我..."
    c "....."
    c "我多希望我就是他。我多希望我能成为他，为了你。"
    c "如果你恨我...如果你想让我离开，我会理解的。"
    "他的话语变成了痛苦的低语，他低头凝视着，太害怕去直视诺亚的眼睛。"
    no "我并不讨厌你。"
    nothought "你不是奥古斯特。"
    nothought "但是...在内心深处，我难道不已经知道了吗？"
    nothought "你一直都是克劳。"
    show crow m sur with dis
    c "什么？"
    "克劳低垂的绿色眼睛终于与诺亚的目光相遇。"
    show noah m neu with dis
    no "....你是克劳。你不是一个无名之辈。"
    no "....我喜欢你的本来面目。"
    c "诺亚..."
    show noah m sad with dis
    no "但是有太多我不明白的事情。太多事情都不合逻辑。"
    c "......"
    show noah m neu with dis
    no "你到底是什么？"
    c "我是..."
    show crow m hea with dis
    c "一种只能存在于梦境中的存在。我已经在这里等待了六年左右。"
    show noah m sho with dis
    no "........"
    no "一直独自等待？"
    "独自等待这么长时间的痛苦。他们两个都有过这种感受。"
    c "但是...但是，这没关系。我...我其实无法感受到孤独，也无法感受到其他任何情感。我被设计成无法感受情感的存在，所以—"
    no "....."
    no "那为什么你在哭泣？"
    show crow m sho with dis
    c "..."
    show crow m hea with dis
    c "哦..."
    c "原来这就是感受的感觉..."
    show noah m sad with dis
    no "..."
    "他用双手触摸自己湿润的脸颊。"
    c "我...我不知道...发生了什么，我...以前从未..."
    c "这种沉重的感觉是什么...？"
    "诺亚再也等不及了。他跳了起来，把克劳拥入怀中。"
    "他把脸埋在诺亚的肩膀上，泪水不断涌出，抽泣不止。"
    no "...没关系。"
    no "你不必现在就谈论这些。以后再说吧。"
    "克劳点了点头，把脸埋在他的肩膀上。"
    c "我想要...我想继续帮助你..."
    show noah m ann with dis
    no "当然。我需要所有可以得到的帮助。"
    c "即使我曾经欺骗过你，你也愿意接纳我吗？"
    no "....."
    no "你没有欺骗我。你只是告诉了我我想听的话。"
    no "........"
    show noah m sad with dis
    no "奥古斯特已经...不在了。"
    "克劳再次摇头，然后把手掌放在诺亚的胸口，贴在他的心脏上。"
    show crow m sadsmi with dis
    c "他...他永远都在这里...永远。"
    no "....."

    "当克劳终于沉默下来时，诺亚离开了他。"
    show noah m neu with dis
    no "卢卡死了。"
    show crow m sadsmi with dis
    c "...他...之前曾给你带来痛苦，对吗？"
    c "但我很抱歉。你尽了最大努力去拯救他。我们都是。"
    no "之前？"
    "克劳摇了摇头，看起来仍然有些悲伤。"
    c "....没什么。我只是...觉得你们两个相处得不太好。"
    no "你说得对。当我还在上学的时候..."
    show noah m fro with dis
    no "我确实希望他能死掉，这样我就可以独自一个人了，但是..."
    no "但是..."
    c "但是如此轻易地抛弃生命并不对，对吗？"
    show noah m ann with dis
    no "我很高兴有人和我持相同的观点。"
    show crow m sho with dis
    c "有人？"
    no "...凯恩。他总是和我争论，告诉我应该接受他们的死亡，继续前进。他说得好像这是一种恩惠一样。"
    show crow m sur with dis
    c "这似乎不太像他..."
    show noah m neu with dis
    no "对吧？"
    c "也许他和你一样在挣扎。我觉得他并不想失去你，诺亚。"
    no "我...知道。"
    show crow m sho with dis
    c "除了凯恩的奇怪行为之外，你还有其他线索吗？下一个可能成为目标的人是谁？"
    show noah m ann with dis
    no "嗯..."
    no "我觉得看到她之后，罗莎米可能会成为下一个目标。"
    no "我们两个私下里相处得很好，但在公众面前，没有人知道我们是朋友。"
    no "虽然说朋友也有些勉强..."
    no "你有设法帮助到她吗？"
    show crow m sadsmi with dis
    c "就在卢卡的梦境崩溃之前，我试图抓住她，但她消失了。"
    c "我不知道这怎么可能，但她竟然肉身陷入了梦境之中...不老不变。"
    c "她竟然还活着，我真是不解..."
    no "...我很庆幸她还活着。"
    c "罗莎米...我对她一无所知。"
    show crow m neu with dis
    c "...你什么时候遇到她的？"
    show noah m sad with dis
    no "在...在..."
    no "....."
    no "在我辍学之前不久。"
    "克劳同情地点了点头。"
    show crow m sadsmi with dis
    c "好吧。这就解释得通了。"
    c "那我们必须尽快找到她。"
    c "但要小心，诺亚。我担心..."
    c "那些针对这些人的人比我们想象的更接近。"
    no "..."
    no "好的，我会小心的。"
    show noah m ann with dis
    no "...你觉得会不会是伊万？"
    show crow m sho with dis
    c "伊万？那个...白发的人？"
    no "对，你有没有注意到他身上的..."
    c "身上的标记...是的，我注意到了。"
    show crow m sadsmi with dis
    c "我不知道他为什么会有那些标记。总之，不要太相信任何人，好吗？"
    no "那你呢？我能相信你吗？"
    c "我永远会站在你这边。无论发生什么。"
    show crow m neu with dis
    c "虽然我承认，告诉你不要太相信任何人，然后又说这样的话，有点讽刺。"
    "但诺亚内心深处{i}觉得{/i}，克劳的话是真诚的。"
    no "我能问你一个问题吗？"
    c "当然。"
    no "....你说你独自待了六年。"
    no "当我不在这里的时候...你都在做什么？"
    c "我在等你。"
    "诺亚皱了皱眉头。不知为什么，这四个字听起来是如此孤独。"
    show noah m fro with dis
    no "为什么？"
    show crow m sadsmi with dis
    c "嗯...我应该做些什么呢？我的存在就是为了帮助你。"
    show crow m neu with dis
    c "除此之外，我也会偶尔去拜访别人的梦境，只是为了瞥见一下真实的世界。"
    show noah m ann with dis
    nothought "我..."
    nothought "我从未想过这一点。他从未见过真实的世界。"
    nothought "这..."
    nothought "真是太悲伤了。"
    no "你想看看真实的世界吗？"
    show crow sadsmi with dis
    c "那是...不可能的。"
    no "为什么不行？"
    c "我没有身体。我更像是...一个想象中的朋友。"
    c "而你是血肉之躯，真正活着的。"
    show noah m neu with dis
    no "如果这是可能的，你想看到什么？"
    c "........"
    "外面，太阳正开始在地平线上落下，蓝色渐变为橙色。"
    nothought "他在夕阳下也会很漂亮。"
    c "嗯..."
    c "...没什么。太幼稚了。"
    no "你还是告诉我吧。"
    c "我..."
    c "我只想早起看日出。感受那个神奇时刻的温暖阳光。"
    "不知何时，克劳已经把手贴在了窗户上，看着落日。"
    show noah m sho with dis
    no "就这样？"
    c "我告诉你这很傻。"
    show noah m neu with dis
    no "这不傻，一点也不傻。"
    no "这是个美丽的愿望。"
    show crow m hap with dis
    c "谢谢你，诺亚。"
    show noah m ann with dis
    no "..."
    no "当我还小的时候，我的...我的家人，我们都很亲密..."
    no "我们一起去远离城市的地方旅行。"
    no "我们一起看日落，四个人，然后天空就满是星星。数也数不清。"
    show noah m hap with dis
    no "我想你也会喜欢那样的。"
    "两个人越凑越近，几乎要碰到了。"
    "克劳的脸颊微微泛红，诺亚的也是如此。"
    show crow m shy with dis
    c "听起来真美好。我希望...我能和你一起看到。"
    show noah m shy with dis
    no "那我们为什么不约定一起去看看呢？"
    c "但是我—"
    "两个男人都不确定是谁先向前倾斜的，但只用了一瞬间，他们的脸就只有几英寸远。"
    "诺亚的呼吸哽在喉咙里。"
    c "我..."
    "他能感受到克劳颤抖的呼吸。感受到他的温暖。几乎能听到他剧烈的心跳。"
    "如果这不是真的，那什么才是真的呢？"
    show black with eye_shut
    "诺亚闭上了眼睛。"
    "但是他期待的感觉从未出现。"
    "克劳惊慌失措地跳了回去。"

    scene bg diner day:
        subpixel True xpos 0.73 ypos 1.15 xanchor 0.5 yanchor 1.0 zoom 1.66 rotate None
    show noah m shy at slightleft:
        subpixel True xpos 0.13 ypos 1.0 xanchor 0.2 yanchor 1.0 rotate None

    show crow m sur at slightright:
        xpos 0.85 ypos 1.0 xanchor 0.8 yanchor 1.0
    with hpunch

    c "是...是时候你回去了。"
    no "....."
    c "如果你再次逃避付款，你可能会惹上麻烦。"
    "克劳的眼睛盯着任何东西，只是不看诺亚。"
    show noah m sad with dis
    no "啊，该死。你说得对。"
    no "我会...那么走吧，我想。我们后来再见面，试着找到罗莎米。"
    show crow m shy with dis
    c "是、是的。"
    show noah m ann with dis
    no "........"
    c "........."
    nothought "没有情感，我的屁股。"
    "当诺亚转身离开时，他感受到了一种很久没有感受到的情绪。"
    nothought "我不想走。我想留在这里和他在一起。"
    nothought "他会在之后做什么？"
    nothought "就...等我？"

    show black with eye_shut
    stop music fadeout 3.0
    "诺亚闭上眼睛，等待那种怀旧的感觉淹没他——在现实之间转换时总会出现的自由落体的感觉。"
    "他等待着。"
    "又等了一会儿。"
    "最后，他睁开了眼睛。"

    play music traintodarkness fadein 5.0
    hide black with eye_open
    show noah m sho with dis
    no "这是什么..."
    show crow m neu with dis
    c "怎么了？"
    no "这不是...这不管用。"
    show crow m sho with dis
    c "什么意思，不管用？"
    no "通常我只是开始下落，但是...什么都没发生。"
    c "哼..."
    "脸颊仍然发红的克劳再次走近诺亚，把手放在他的额头上。"
    show crow m neu with dis
    c "我可以送你走。"
    c "再见，诺亚。"

    show black with eye_shut

    "诺亚再次闭上了眼睛。"
    "再次，什么都没发生。"
    hide black with eye_open
    show crow m sur with dis
    c "这是什么..."
    show crow m sho with dis
    c "这真的不管用，是吗...？"
    show noah m fro with dis
    no "怎么会不管用呢？"
    c "..."
    c "这个梦不应该属于任何人...这是我从你的记忆中艰难创造的领域..."
    c "但就像是...就像有人...占据了它？并把我们锚定在这里。"
    show noah m sho with dis
    no "所以我们...要一直困在这里，直到找到那个人？"
    c "或者梦境崩溃..."
    show crow m neu with dis
    c "但现在它似乎很稳定。"
    "一种宽慰感淹没了诺亚。这种宽慰感让他花了一点时间才认出其中的原因。"
    nothought "我还没准备好离开他..."
    no "那是什么？"
    "皱着眉头，克劳转过身去跟随诺亚的目光。就在窗外，似乎在下雨——下着闪闪发光的泡泡雨。"
    show crow m sho with dis
    c "这通常会这样吗？"
    no "呃，不会。"
    no "来吧，我们去看看。"
    stop music fadeout 3.0
    "仍然有些脸红，两人离开了咖啡馆，里面的宁静被泡泡般的雨点在人行道上有节奏的拍打声所取代。"

    scene bg streets day
    show bubbles
    with Fade(1.0, 1.0, 1.0)
    play sound bubblepop
    "诺亚慢慢地伸出手去触碰一个闪闪发光的彩虹泡泡。它轻轻地爆裂了，留下了一种让他想起夏天的气味——特别是刚刚割过的草的气味。"
    play music moment fadein 4.0
    no sho "这很...奇怪。"
    c sho "不过很漂亮。"
    "克劳也伸出手，但泡泡并没有在他的皮肤上爆裂。相反，它轻轻地停留在他的指尖上。"
    "带着微笑，他把它举到诺亚面前，近到诺亚眼睛都斜了，然后把它放在鼻子的尖端。"
    "一会儿后它就爆破了，克劳忍不住笑了。"
    c hap "我很抱歉，但这是一个我无法错过的机会..."
    no shy "..."
    "诺亚再次伸出手，这次小心翼翼地抓住一个泡泡而不是戳破它，并重复了克劳的动作——小心翼翼地把它放在克劳的鼻尖上。"
    c "它改变周围世界的方式...太神奇了。"
    no "你从来没有玩过泡泡吗？"
    c "没有，我从来没有。"
    c "说实话，在我...遇到你之前，这甚至都没有出现在我的脑海里。"
    "两人并肩走在街道上，空虚既令人安心又令人不安。"
    hide bubbles with dissolve
    "泡泡在他们周围继续落下并爆裂了一段时间，直到它们也停止了。"
    c neu "这就是你的世界吗？"
    c "你也是这样走在街上的吗？"
    no neu "...嗯，通常城市里还会有很多鸣笛声，但是大致就是这样。"
    no "你...从未来过这里吗？"
    "克劳悲伤地摇了摇头。"
    c sadsmi "我只是通过他人的梦境瞥见过你的世界——我从未在你居住的街道上行走过。"
    c "这些刺入天空的高耸建筑物...脚下的地面感觉...和你并肩而行..."
    c "我几乎感觉自己真的存在了。"
    no sad "..."
    no "你现在就在这里，难道不够吗？"
    c "....."
    c "对，我确实是这么说过的，不是吗？"
    c "对不起，是这些..."
    "克劳将手放在胸前，手指轻轻抓住衣服。"
    c "这些...在我胸中的感受..."
    c "它们让我变得很奇怪，对吗？"
    no shy "...你并不奇怪。感受会让我们每个人的行为都不同。"
    c "也许吧..."
    c "但我感觉每一个动作都变得十倍艰难。每一句话对我来说都被放大了十倍..."
    c "胸中的重量...如果说实话，是令人痛苦的。"
    nothought "你以前从未告诉过我这些...你总是很神秘。你总是带着微笑。"
    nothought "我喜欢你的微笑。"
    nothought "但这更像是你真实的自己。"
    no neu "我...无法想象从没有感受到到突然拥有感受是什么感觉。"
    c sad "没关系。我会驾驭好它们的。"
    no "你..."
    no shy "你可以在我面前表达自己。"
    no "我不会逃避。"
    c sur "..."
    c shy "谢谢你，诺亚..."
    "两人继续前行，寻找着他们并不确定的东西。一个人，一件物品，或是困住他们的梦境的什么。"
    "但无论走多远，他们都找不到任何人。"
    no fro "就像在干草堆里找针一样。我们怎么能在这么大的城市里找到任何人呢？"
    c sho "我从未见过这么大的梦境。"
    c "我根据你的记忆创造了咖啡馆。其余的只是简单的背景...但看来你的想象力相当强大。"
    c "这是你的城市的完整复制品。"
    no sho "如果是完整的复制品..."
    no "我们可以试试去我家？"
    c "你家？"
    c neu "对，对，人类都有自己的家可以回去，不是吗？"
    no "那你呢？"
    c sad "嗯..."
    c "我想梦境之间的深渊就是我的家。"
    nothought "那无尽的、白色的、阴郁的地方..."
    no ann "你知道，我的房子对一个人来说太大了。"
    no neu "...我的家也可以是你的家。"
    no "呃，如果你...你想要一个可以称之为家的地方，而不是独自一人。"
    c sadsmi "...哦。"
    c "那我...很乐意。"
    "很快，诺亚和克劳就找到了诺亚公寓的入口。它和现实生活一模一样——如果不是因为一切都是空荡荡的，诺亚都分不清。"
    stop music fadeout 4.0
    "诺亚为克劳打开门，他们沉默地乘电梯上楼。看起来这个金发男子从未在电梯里待过，他安静地被各种按钮迷住了。"

    scene bg paint day
    show crow n dim sho at slightleft
    show noah n dim ann at slightright
    $ camera_reset()
    with Fade(1.0, 1.0, 1.0)

    play music shift
    c "....."
    no "....."
    no "抱歉，呃...这里有点乱。"
    c "{i}这{/i}就是你的房子？"
    "和往常一样，地板上散落着已用和未用的画布，到处都是颜料溅落的痕迹。"
    c "...看起来就像你的灵魂。"
    show noah n sho with dis
    no "什么？"
    show crow n hap with dis
    c "当然有些凌乱，但充满了色彩。没有一个表面不被你的想象力覆盖。"
    "克劳走进房间，目光从一件作品移到另一件，手指轻轻抚摸着许多干涸的绘画。"
    "尽管周围一片混乱，但克劳在每一幅画布的融合中看到了美，它们形成了一幅色彩和情感的织锦，诉说着诺亚的孤独和对联系的渴望。"
    "正是他自己现在拥有的那些确切的感受。"
    show crow n neu with dis
    c "它们很美，就像你一样。"
    c "不过我们至少可以{i}稍微{/i}整理一下...不过在梦境里也没什么意义，我想。"
    show crow n sho with dis
    c "我知道你会画画，但我从未见过你的作品...你真的很了不起，诺亚。"

    $all_moves(camera_check_points={u'z': [(0, 0, None), (453, 0.5, u'ease')]})
    show bg with hpunch
    "乌鸦向后退了一步，绊到了一堆画布，差点摔倒在地。"
    "诺亚反应很快，抓住乌鸦将他拉到自己的怀里稳住了他。"
    show crow n sur with dis
    c "啊！"
    show crow n sho with dis
    c "谢谢你，诺亚。我应该更小心地注意脚下。"
    "诺亚放松了对他的握力，但还是没有完全放开。他们沉默地站了一会儿，然后诺亚再次开口。"
    show noah n ann with dis
    no "...你有没有试过？"
    c "试过...什么？"
    show noah n neu with dis
    no "绘画。"
    show crow n sad with dis
    c "..."
    show crow n sadsmi with dis
    c "嗯..."
    c "没有，我想我还没有。不是...直接的。"
    no "你想试试吗？"
    show crow n sur with dis
    "乌鸦眨了几次眼睛，显得很惊讶。"
    c "现在就试吗？我很感谢你的邀请，但这真的是最好的时机吗...？"
    no "..."
    show noah n sad with dis
    no "我们之间什么时候才会有好的时机呢？"
    no "我们总是在梦中相见，我总是匆匆离开..."
    no "拜托？"
    show crow n sur with dis
    c "..."
    show crow n sho with dis
    c "我..."
    show crow n sadsmi with dis
    c "我很乐意和你一起画画，诺亚。尽管我想我可能不太擅长。"
    "这就是他需要听到的全部。他最终放开了乌鸦，开始在房间里收集用具。一切都和他在现实世界里留下的一模一样。他的空白画布、颜料和画笔。"
    "最后，拿着所有东西，他让乌鸦坐在画架前，自己站在他身后。"
    show crow n neu with dis
    c "我应该画什么？"
    show noah n neu with dis
    no "任何你想画的。任何你内心渴望的。"
    c "..."
    "他的第一笔很谨慎，好像在试探自己创作的能力。接下来的笔触越来越快，第三笔更是迅捷。"
    "一笔接一笔，颜料在画布上铺展开来，每一笔都比上一笔更加大胆自信。看着这一切，诺亚感到胸中涌起一股暖意。仿佛他正目睹着一件全新而美丽的事物的诞生。"
    "这就像他再次第一次画画一样——在自己的卧室里，比现在年轻得多，有一个重要的人坐在对面。"
    "诺亚微笑着，心中隐隐作痛，因为他看到了乌鸦的热情被点燃。曾经在诺亚孤独的世界里显得黯淡无光的颜色，如今却爆发出了勃勃生机和活力。"
    "他无法完全解读乌鸦到底在画什么，但这对他来说并不重要。他只是沉浸在乌鸦每一次笔触都让他的脸庞焕发光彩，以及他在颜色混合交织时睁大眼睛惊讶的样子。"
    "对诺亚来说，已经太久没有和别人一起画画了。艺术对他来说一直是一种独处的行为，是逃离他发现自己被困在其中的世界的方式。"
    "但现在，他明白艺术最好是与他人分享的。"
    "慢慢地，他的画作成型了。它描绘了一片开阔的天空，有几朵悠闲飘浮的云彩。还有一片茂密的草地，远处有一只正在觅食的羊。"
    "当然，看起来有些像是个孩子画的，但这也在意料之中，毕竟这是他第一次尝试绘画。"
    show crow n sho with dis
    c "啊..."
    c "这有点让我觉得尴尬..."
    c "尤其是当我被你那些美丽的画作包围着的时候..."
    show noah n ann with dis
    no "..."
    no "你的作品比我已经很久没有过的那些作品更有灵魂。"
    show crow n hap with dis
    c "这就是你。"
    show noah n sho with dis
    no "我？"
    c "你自己去领悟它的含义吧。"
    "乌鸦用手指抵住嘴唇，再次表示他不会进一步解释。"
    show noah n sad with dis
    no "我真希望我能把它带走..."
    "诺亚低声自语道，声音小到乌鸦几乎听不见。"
    show crow n sadsmi with dis
    c "我也是..."
    "乌鸦低声回答，声音中透露出明显的悲伤。他站起身来，伸展了一下肩膀，打了个哈欠，这让诺亚有些惊讶。他从未听过乌鸦打哈欠，也从未注意到他会感到疲惫。"
    "离开自己的画作让它干燥，乌鸦走到诺亚的沙发边，坐在一堆散落的纸张上。上面画满了诺亚多年来的各种素描。"
    "诺亚小心翼翼地坐在他旁边。"
    c "看来我们找不到让你离开这里的办法。"
    nothought "这有什么不好的吗？"
    show noah n neu with dis
    no "稍作休息也不会有什么坏处吧？你看起来很疲惫。"
    show crow n sho with dis
    c "疲惫...我{i}确实{/i}感到疲惫...真奇怪。"
    c "我相信这是我第一次感受到这种...这种遍布全身的倦怠感。"
    no "也许你比你自己想象的更加人性化。"
    show crow n sadsmi with dis
    c "但愿如此..."
    "时间仿佛在乌鸦将头靠在诺亚肩上的时候慢了下来。这是一个简单而小的动作，但诺亚仍然感到自己的身体紧张了起来。"
    c "..."
    c "你觉得我很难相处吗？"
    show noah n sho with dis
    no "为什么会—"
    c "因为我看起来像他。而你非常爱他。"

    window show

    menu:
        no "我..."
        "不再是了":
            $ CrowPoints += 1
            show noah n ann with dis
            no "...以前是的。"
            show crow n sad with dis
            c "对不起——"
            no "不，等等，请听我说..."
            show noah n sad with dis
            no "当然我觉得很难相处...因为我希望你是他，我多么希望你是{i}奥古斯特{/i}..."
            "诺亚回想起了与乌鸦的所有过往经历。他们在一起度过的所有时光。"
            "他之所以享受这些，是因为乌鸦就是乌鸦。而不是因为他长得像奥古斯特。"
            show noah n neu with dis
            no "但是...我想我一直知道你不是他。你们在很多方面都很相似，但在千千万万个方面又不同。"
            no "你永远不会成为他。"
            show noah n hap with dis
            no "这是件好事。因为你就是你。而我喜欢你现在的样子。"

        "是的，确实":
            show noah n ann with dis
            no "说实话...是的。有时候我确实觉得很困难。"
            show noah n sho with dis
            no "不是和你在一起的时候。我...我喜欢和你在一起的时候。"
            show noah n sad with dis
            no "走出来才是最困难的部分..."
            show crow n sad with dis
            c "我很抱歉..."
            show noah n ann with dis
            no "你没有什么需要道歉的。"
            no "你就是你，这就是全部。"
            no "我喜欢你现在的样子。"

    show crow n sho with dis
    c "真的吗？"
    show noah n hap with dis
    no "是的。"
    show crow n sadsmi with dis
    c "任何旁观这种情况的人都会说你疯了。"
    no "也许我是疯了。"
    no "如果这意味着我有机会遇到你，我很乐意疯掉。"
    show crow n sur with dis
    c "..."

    hide noah
    hide crow

    $all_moves(camera_check_points={u'y': [(-205, 0.0, u'ease')], u'x': [(3676, 0.0, u'ease'), (-4210, 25.17, u'ease')], u'z': [(679, 0.0, u'ease')]})
    with dissolve
    no sho "抱歉，我现在像个白痴一样喋喋不休...我只是想说...我很高兴我们相遇了。"
    c "..."
    no shy "更高兴我们真的...可以在一起度过一些时光。"
    no sho "...克劳？"
    "从靠在诺亚肩膀上的男人那里传来了安静入睡的柔和声音。"
    no shy "..."
    "他睡着时面容安详。他长长的黑色睫毛轻轻地落在柔软的皮肤上，胸膛轻轻地起伏。"
    "这样睡着的他，很难想象他不是人类。"
    no sad "我后悔太多..."
    no "我浪费的生命中的那些年...发生在凯恩身上的一切...逃离..."
    "他并不是在对任何人说话。这些话只是在他的脑海中盘旋，渴望被释放。"
    no "我现在所做的并不能弥补任何事情...但如果帮助这些人可以成为走出来的第一步..."
    no "那我就这么做。"
    "诺亚犹豫地把手放在克劳的头顶。他的头发摸起来很柔软，他忍不住轻轻地用手指梳理着。"
    no "你呢？"
    no "你一直告诉我你会为我做任何事...但你自己想要什么？"
    no "我希望你也能稍微自私一点。"
    show black with dissolve
    "他们就这样呆了一段时间，直到克劳动了起来。诺亚不禁感到失望——说实话，他本来很乐意就这样呆下去更长一些时间。"
    "有人在你身边睡觉，这种感觉很安宁。"



    scene bg paint day
    show crow n dim sho at slightleft
    show noah n dim ann at slightright
    $ camera_reset()
    with Fade(1.0, 1.0, 1.0)

    "克劳先是缓缓坐了起来，然后几乎是跳到了沙发的另一边，惊讶地看着诺亚。"
    show crow n sur with dis
    c "我...我很抱歉...！"
    show noah n neu with dis
    no "没什么好道歉的。"
    no "看来你真的很累。"
    "他脸上露出了困惑的表情。"
    show crow n sho with dis
    c "我...做了个梦。"
    show noah n sho with dis
    no "真的吗？"
    c "我从来没有做过梦。我从来没有睡过觉。"
    no "我想...每个人都会有第一次。"
    c "但为什么现在—"
    stop music fadeout 3.0
    play sound clock fadein 1.0
    queue sound clock
    queue sound clock
    "从四面八方，又从无处不在，滴答声在空气中回荡，在空荡荡的房间和街道外回响。"
    play music traintodarkness fadein 4.0
    "克劳和诺亚跳了起来，眼睛在阴影中来回搜寻，寻找任何危险的迹象。"
    show noah n sur with dis
    no "那声音是从哪里来的..."
    show crow n sur with dis
    c "它似乎就是梦境本身的一部分。"
    c "来，我们去外面看看。"
    show black with dissolve
    "克劳打开门，但诺亚先走了出去。在外面，他看到通往电梯的走廊，电梯可以带他走出去。"
    "但是，一踏出门，他就发现自己身在别处。"

    scene bg teenagebg1_waves:
        size(1920, 1080)
    show noah n sur at center

    $all_moves(camera_check_points={u'y': [(-1162, 0, u'linear')], u'z': [(738, 0, u'linear')]})
    with Fade(1.0, 1.0, 1.0)
    stop music fadeout 4.0
    no "这是什么..."
    "诺亚回头看向刚刚走出的那扇门，但它已经不见了。"
    "克劳也不见了。"
    show noah n sca with dis
    no "该死，我们走散了—"
    play music whodidyoulove fadein 4.0
    m "诺亚！你不应该在父母面前说脏话。"
    f "他已经是个成年人了。我们应该给他一些宽容。"
    m "哦，亲爱的，别对他太纵容了。"
    "诺亚缓缓转过身，面对着那两个熟悉的声音。"
    "他的父母并排站着，用一种并不感到惊讶的表情看着他。"
    nothought "这只是一个梦...如果克劳说的是真的，这只是源自我自己思维的一个梦。"
    show noah n sho with dis
    no "妈妈...爸爸。"
    no "..."
    m "亲爱的，你一定很累了。为什么不来躺一会儿呢？"
    "诺亚摇了摇头。"
    show noah n sad with dis
    no "我不能。我有地方要去。有人需要我。"
    m "有人比你的父母更需要你吗？"
    no "...是的。"
    f "即使在你离开我们而让我们死去之后？"
    show noah n sur with dis
    no "我...我不是...！"
    m "连你父亲去世后你都不愿意帮助..."
    no "....."
    f "但是我们原谅你了。"


    window show

    menu:
        f "原谅是很重要的，你不觉得吗？我们可以再次成为一家人。"
        "我不原谅你们":
            $ CrowPoints += 1
            show noah n fro with dis
            no "...那很好，但我不原谅你们两个。"
            m "诺亚—"
            no "让我说完。"
            no "我不原谅你们。我感谢你们为我做的事，但我永远不会原谅你们。"
            show noah n neu with dis
            no "但是我已经准备好向前看了。"

        "我原谅你们":
            show noah n fro with dis
            no "...现在，如果这样能让我离开的话，我也准备说我原谅你们了。"
            m "这就是你唯一关心的吗？再次离开我们？"
            no "是你们逼迫我离开的。不要责备我，而是看看自己。"
            show noah n neu with dis
            no "我已经准备好向前看了。"

    f "从我们这里向前看？"
    no "从过去向前看。你们也已经成为过去的一部分了。我已经准备好放下曾经伤害我的一切。"
    no "再见，妈妈。再见，爸爸。"
    "他们两个都微笑了。"
    maf "再见，诺亚。"
    "那两个人消失了，只留下闪耀的尘埃。诺亚的目光回到了他进来的地方——门又重新出现了。"
    show noah n sur with dis
    no "克劳！"
    "他冲进门，急忙回去寻找克劳。"

    scene bg classroomnight_waves with Fade(1.0, 1.0, 1.0):
        size(1920, 1080)

    "诺亚的心跳加快，他走进了那间教室，这是他作为学生度过无数时光的教室。"
    "教室笼罩在黑暗之中，只有月光从窗户透进来。"
    "当诺亚的眼睛适应了黑暗，他看到弗洛伊德先生站在他的旧桌子旁，望着窗外。他看起来很沉重。"
    "岁月在他的脸上刻下了痕迹，诺亚能看到他眼中的疲惫。"

    mrf neu "诺亚..."
    no sho "原来是你..."
    "弗洛伊德先生半靠在桌子上。"
    "他温和地对诺亚微笑。"
    mrf smi "很高兴这么快就见到你。"
    "他的声音里已经没有遗憾、愤怒或悲伤，时间冲刷走了他们过去的误解和错误，只留下了接纳和原谅。"
    "诺亚向那个男人走去，肩上的重担已经消失了。"
    mrf smi "我们之间已经没有什么好说的了，是吗？"
    "诺亚摇了摇头。这是事实——他们已经原谅了彼此。"
    mrf neu "...我为你成长为现在的样子感到骄傲，诺亚。"
    mrf neu "只要你向着未来前进，你就会越走越远。"


    window show

    menu:
        no ann "...谢谢你，弗洛伊德先生...我..."
        "已经准备好向前看了":
            $ CrowPoints += 1
            no neu "我已经准备好向前看了。"
            mrf smi "很好。我就知道你会这样的。"

        "还没准备好向前看":
            no sad "我...我不确定我是否已经准备好向前看。"
            mrf smi "这也没什么不好的。"
            mrf neu "这种事情我们并不总是确定。"
            mrf neu "重要的是你已经迈出了改变的第一步。"

    mrf neu "我不会再耽误你了。你不是还有人在等你吗？"
    no hap "是的。谢谢你，弗洛伊德先生。"
    no neu "..."
    no neu "你现在满意了吗？"
    mrf sho "幸福？"
    no neu "你那个结婚的朋友。你是否曾经...？"
    mrf sho "原来你还记得那件事..."
    mrf neu "是的，我很幸福。我已经向前看了，找到了新的幸福。"
    mrf smi "我希望你也能找到属于自己的幸福。"
    "说完，他消失了，只留下一串闪耀的尘埃。"
    "诺亚转身离开，再次找到身后的门。他迅速进入，完全知道自己可能会出现在任何地方。"

    scene bg river_waves with Fade(1.0, 1.0, 1.0):
        subpixel True xpos 0.5 ypos 1.14 xanchor 0.5 yanchor 1.0 zoom 0.79 rotate None

    "诺亚的心情随着走向河岸而激动起来，阳光下的河水闪闪发光。他能听到轻柔的水流声，以及微风中树叶的沙沙声。"
    "在河中央的一块大岩石上，坐着他的哥哥艾许。"
    ash neu "我们又见面了。"
    no sho "艾许..."
    ash neu "好久不见了，是不是？"
    ash neu "自从你逃走之后，我们就再也没有好好见过面。"
    no fro "是啊，我们当时可不是在最好的条件下分开的。"
    ash mock "我们可能永远也无法和好如初。"
    no neu "可能吧。"
    ash fro "..."
    no neu "..."
    "诺亚站在岸边，不知道接下来该做什么或说什么。"
    "沉重的沉默在他们之间弥漫，只有水轻轻拍打在岩石上的声音打破了这片寂静。"
    "但接着，艾许站了起来，脸上带着严肃和决心。"
    ash neu "我不原谅你，你也不原谅我。"
    no neu "没错。"
    ash neu "那为什么我们不重新开始呢。"
    ash sad "我已经准备好把过去抛在脑后了。"


    window show
    menu:
        no sho "..."
        "我还没准备好":
            no fro "那如果我还没准备好呢？"
            ash mock "那我就说你是个心胸狭窄的混蛋。"
            no fro "你自己说吧。"
            ash fro "..."
            ash sad "我只是累了。我们都失去了太多。我已经没有力气再去争斗了。"
            no ann "...这一点我同意。"

        "我也准备好了":
            $ CrowPoints += 1
            no ann "...我也准备好了。"
            no ann "我想要向前看。"
            ash sad "我...累了。我们都失去了太多。"

    ash neu "回复我，好吗？"
    no neu "...也许吧。"
    ash fro "你这个混蛋。"
    "他也消失了，就像其他人一样，融入了环绕着他的河流之中。"
    "这次，他没有逃跑或匆忙离开。他慢慢地走进那扇门，希望能更接近那滴答声的源头，以及克劳。"

    scene bg art_waves with Fade(1.0, 1.0, 1.0)

    "这个房间和诺亚记忆中的一模一样，只是少了那些让它真正成为一个俱乐部的人。"
    "他犹豫地走进熟悉的美术社室。房间里空荡荡的，一片黑暗。"
    "然后他看到了卢卡，坐在他原来的座位上，目光盯着诺亚。"

    l smi "又见面了，诺亚。嘿，在这里呢。"
    no fro "..."
    no fro "卢卡。"
    l smi "没想到这么快就见到你了。难道我在你心中占据了如此重要的地位？哇，我都脸红了~。"
    "空气中弥漫着紧张的气氛。"
    l hap "你是来和我和好的吗？"
    no fro "你已经死了，卢卡。你活该。"


    window show
    menu:

        l sad "噢，诺亚，庆祝死亡可不是向前看的好方式——"
        "我永远不会原谅你":
            $ CrowPoints += 1
            no ann "我也没打算原谅你。向前看并不意味着原谅每一个伤害过你的人。"
            no neu "而是选择放下仇恨、愤怒和苦涩，决定继续前进。"
            "卢卡的脸色稍有变化，但没有做出任何回应。"
            no neu "我不会假装一切都好。你是个说谎者，也是个混蛋。"
            no neu "但你已经死了，而我还活着。"

        "我会原谅你":
            no fro "为了向前看...也许有一天我会原谅你。"
            no fro "但不是今天。"

    l neu "哇，你真的变了，是不是？"
    no neu "也许吧。"
    l neu "是什么导致了这种变化？"
    no neu "..."
    no neu "有人提醒了我什么叫活着，什么叫真正地存在。"
    no neu "我决定要效仿他的榜样。"
    l smirk "哦，是那个和奥古斯特长得一模一样的人。"
    no fro "他的名字叫克劳。"
    l smi "对对，克劳——"
    "他慢慢消失了，闪烁的碎片落到了地板上。"
    "诺亚转向再次出现的门。当他越来越靠近时，钟表的滴答声似乎变得越来越大。"
    no sca "克劳...！"
    "他跳进了门，发现自己出现在一个意想不到的地方，竟然是出自自己的内心。"


    scene bg empty dream:
        subpixel True xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.63 rotate None
        parallel:
            xpos 0.27
            ease 22.95 xpos 0.5
    $ camera_reset()
    with Fade(1.0, 1.0, 1.0)

    "这就是克劳一直称之为家的那片空虚之地。一片无尽的纯白虚空正在等待着他。"
    "他深吸了一口气，克劳的孤独感如同一记重锤击中了他。它从四面八方压迫而来，仿佛是一种实在的重量。"
    stop music fadeout 3.0
    "当他向前走去，他能听到声音变得越来越大、越来越混乱。他加快了脚步，每一步都让他的心跳得越来越快。"
    "一群由{i}阴影{/i}组成的人群围绕着一个蜷缩成一团的人。"
    play music someonessign fadein 4.0
    "诺亚试图穿过他们，但就像他们的存在在边缘模糊一样，他们变成了一堵无法突破的墙。"
    u "你是个假货。"
    u "你永远也比不上他。"
    u "诺亚只是因为你让他想起了奥古斯特。"
    u "假奥古斯特！假奥古斯特！"
    no sca "克劳！克劳，我在这里！"
    "他的声音被人群淹没，消失在虚无之中。"
    u "你是多余的。你只会让他更受伤。"
    u "你不过是过去的一个回忆。"
    u "你永远也不会成为自己的人。"
    c hea "不...不，求你们..."
    no sca "克劳，你能听到我吗？我在这里！"
    "不管他怎么大声呼喊，他的声音都被人群此起彼伏的喧嚣所淹没。"
    "他用尽全身力气推挤着他们，但他们也在推拒着他。"
    nothought "如果这一切都来自我的内心...那么我就是这里的主宰！让我通过！"
    "渐渐地，人墙开始分开，诺亚一步一步地挤了进去，越来越接近克劳。"
    "终于，他站在克劳的身体上方，克劳已经缩成了一团，双膝紧紧地抱在头上。"
    "诺亚跪下来，用双臂环抱住了这个男人。"

    $all_moves(camera_check_points={u'y': [(0, 0, None), (-695, 2.42, u'ease')], u'z': [(0, 0, None), (518, 5.42, u'ease')]})
    show noah n sad at slightright
    show crow n hea at slightleft
    with dissolve

    no "不要听他们的...不要听他们的，他们不是真的—"
    c "就像...我不是真的吗？"
    show noah n sho with dis
    no "不！你是真实的！你是真实的，足够的，很多的—"

    no "你是真实的，足够的，很多的—"
    show crow n sad with dis
    c "我...和他们没什么不同..."
    u "假的！你是个假货！"
    c "....."
    show noah n sad with dis
    no "你必须起来，克劳。不要听他们的—"
    c "他们...说得对，诺亚。"
    c "我可能看起来像这样，但我和他们没什么不同..."
    no "请，不要听他们的..."
    "突然，人群的嘲笑和嘲弄变成了低声的耳语，人群再次分开。"
    u "是她..."
    u "梦之女王...来拯救我们..."
    u "来给我们人性..."
    "像从天而降的天使一样，翻滚的人群完全分开，取而代之的是一个粉发的年轻女子。"
    show noah n sur with dis
    no "罗莎米..."
    "克劳终于从地上抬起头来。他的眼睛红红的，脸颊湿润。"

    $all_moves(camera_check_points={u'y': [(-695, 0, None), (591, 3.04, u'ease')], u'x': [(0, 0, None), (-220, 3.04, u'ease')], u'z': [(518, 0, None), (95, 3.04, u'ease')]})
    show noah n sur at center
    show crow n sad at left


    with move
    show rosamie n sur at right with dissolve

    r "诺亚，我..."
    r "我在这里做什么...这些人都是谁...？"
    show noah n sho with dis
    "诺亚能感觉到她身上有某种东西-可以说是一种吸引力。"
    "这是她的梦，现在。"
    no "你...所以你就是一直把我们困在这里的人..."
    r "我...什么？"
    no "..."
    show noah n neu with dis
    no "不管怎样，这样也省去了我们去找你的时间。所以你可以...回家了。"
    "诺亚从地上站起来，仍然拉着克劳，把他拉到身边。克劳仍然缩回远离那些阴影般的生物。"
    show noah n sho with dis
    no "他们为什么这样称呼你？"
    show rosamie n sad with dis
    r "我不知道...天啊，我真的什么都不知道..."
    r "我一直被拽来拽去..."
    "诺亚回头看向克劳。随着时间的流逝，他看起来越来越糟糕。"
    show noah n neu with dis
    no "我们必须离开这里，罗莎米。你能把我们带回我的公寓吗？"
    show rosamie n ann with dis
    r "我怎么可能做到那样？"
    show noah n ann with dis
    no "我不知道，但你最好赶快想办法—"
    "人群又开始推推搡搡，围拢过来。罗莎米立即跳到诺亚和克劳前面，伸出双臂，阻挡住那些\'人\'。"
    show rosamie n sur with dis
    r "等等...等等，等等。你们都想要什么？"
    u "公主大人，请赐予我们人性吧..."
    show rosamie n hur with dis
    r "我可不是什么公主，你这个愚蠢的黑色团块！"
    nothought "这听起来更像是我记忆中的罗莎米..."
    u "请，给我们肉体吧..."
    r "嘿...嘿，回去-"
    r "退后！"
    show bg with flash
    "罗莎米向着阴暗的人群后退了一步，她染成粉红色的头发在身后飘动。当她伸手去阻止他们快速逼近时，一道明亮的光充满了这个三人组周围的区域。"
    show noah n sur with dis
    "当光芒消失时，阴暗的人群也不见了。取而代之的是有形的生灵，有血有肉，有跳动的心脏。"
    "诺亚惊讶地看着这些人从梦幻般的状态中缓缓醒来，环顾着新的环境。"
    u "谢谢您，陛下！谢谢您，谢谢您！"
    u "感谢您给予我们肉体...我们会好好利用它的。"
    show noah n sur with dis
    no "这他妈是什么..."
    show rosamie n sur with dis
    r "..."
    "罗莎米站在那里，仍在消化刚刚发生的事情。不管是她，还是诺亚或克劳，都不明白刚才发生了什么。"
    "梦幻般的人群散去，只剩下这三人独自留在空荡荡、阴郁的梦境中。"
    no "你打算解释一下吗？"
    r "看来，你虽然变大了，但还是没变聪明，是吗？"
    r "我告诉过你，我一点也不知道。"
    show noah n neu with dis
    no "那个之前哭泣的罗莎米呢？"
    no "看来已经恢复正常了。"
    show rosamie n ann with dis
    r "那已经是{i}几个星期{/i}前的事了，诺亚。"
    show noah n sho with dis
    no "几个星期...？"
    no "我们明明是昨天才见面的。"
    show rosamie n sur with dis
    r "自从...发生了卢卡的事之后，我一直在数十个，或许是{i}数百个{/i}梦境中。"
    no "怎么会..."
    c "时间在这里...有时会流逝得有些不同..."
    no "时间在这里流逝不同？"
    "克劳终于再次开口说话，尽管他的眼睛仍然盯着地面。很明显，他现在不想说话。"
    no "那么..."
    show noah n sad with dis
    no "你等待我的那些年呢？"
    c "........"
    r "这样就解释得通了，我想。"
    r "我既感觉就像昨天我还不在这里，又感觉像是过了一个永恒。"
    no "..."
    show noah n neu with dis
    no "我们以后再好好谈谈这件事。现在，我们先试着离开这里吧。"
    "罗莎米点了点头表示同意，然后开始带路。诺亚稍微落后了一些，不确定该如何处理眼睛仍然红肿低垂的克劳。"
    "最后，他决定把他们的手指交织在一起，然后快速拉着克劳追上罗莎米。"
    no "我们到底要去哪里？"
    r "好问题..."
    r "只是感觉...这就是方向。"
    scene black
    $ camera_reset()
    with dissolve
    "她向前走去，周围的景观开始变化，在他们行走中转换成不同的场景。他们穿过一片森林、一片沙漠，最后来到一座废弃的城市，然后才回到最初那片空旷、苍白的领域。"
    scene bg empty dream with Fade(1.0, 1.0, 1.0):
        subpixel True xpos 0.76 ypos 0.98 xanchor 0.5 yanchor 1.0 zoom 1.51 rotate None
    "只不过现在，他们站在一扇小小的摇摇欲坠的门前，这是在这片广阔的白色中唯一可见的东西。"


    no sur "好吧，这可能就是出口了。"
    r ann "总比留在这里强。"
    "罗莎米吱呀一声打开了门，然后先走了进去。"
    "克劳紧紧抓住诺亚的手。"
    c sad "我很抱歉..."
    c "我的心好沉重啊..."
    no sad "..."
    no "他们说的都是谎言。"
    c "因为这是事实，所以才会痛苦，诺亚。"
    no "..."
    no "不要松开，好吗？"
    no "我不会让我们再次分开的。"
    c "...好的。"
    show black with flash
    "两人一起走了进去，一道刺眼的白光瞬间充满了他们的视野。"
    "周围的世界在一瞬间溶解成一片模糊的色彩和形状，然后才逐渐凝聚成一个熟悉的景观。"
    stop music fadeout 3.0
    "他们回到了诺亚的公寓——至少是梦境中的公寓。"

    scene bg paint day
    show crow n dim sad at slightleft
    show noah n dim ann at center
    show rosamie n dim ann at slightright

    $all_moves(camera_check_points={u'y': [(-629, 0, u'ease')], u'z': [(453, 0, u'ease')]})
    with Fade(1.0, 1.0, 1.0)
    play music letmedown fadein 3.0
    r "这是你的地方？"
    show noah n fro with dis
    no "有什么问题吗？"
    r "这地方真烂。"
    r "说真的，这比你父母的地方差远了。"
    no "我父母已经去世了。"
    show rosamie n hur with dis
    r "..."
    r "什么？"
    r "真的吗？"
    show noah n ann with dis
    no "我们应该...把发生的一切都告诉你。"
    "她瘫倒在诺亚的沙发上，目光从未离开过他。"
    show rosamie n sad with dis
    r "那就好。"
    no "我不知道我们还有多少时间，所以我会简短地告诉你。"
    no "我认识的很多人在现实世界里接连死亡。"
    no "有人在人们的梦境中杀害他们。"
    r "为什么在梦中杀死一个人会导致他们真正死亡？"
    c "人类...当他们做梦时，他们的灵魂也随之而来。"
    show crow n sadsmi with dis
    c "对于像诺亚这样能进入他人梦境的人来说也是如此。"
    show crow n sad with dis
    c "杀死一个人会切断他们与身体的灵魂联系...从而导致死亡。"
    no "所以克劳和我一直在试图帮助那些受到攻击的人...直到卢卡..."
    r "卢卡...让我们无法帮助他。"
    r "所以他真的死了？"
    show noah n neu with dis
    no "...是的。我很抱歉。"
    r "哈..."
    show rosamie n neu with dis
    r "那么，我呢？"
    r "我为什么会在这里？"
    c "这是我们需要弄清楚的事情。"
    no "你最后记得的是什么？"
    r "..."
    r "我独自在晚上走在离家不远的山里。"
    r "我和父母吵了架，然后就冲了出去..."
    r "然后...我告诉你我要逃走，然后就离开了。"
    r "我听到有人走在小路上，所以我躲了起来。"
    no "为什么？"
    show rosamie n sad with dis
    r "诺亚，我当时是个16岁的{i}女孩{/i}，独自在夜晚的山里走着。我不想被杀害。"
    show noah n sho with dis
    no "对不起，我的错..."
    show rosamie n neu with dis
    r "然后突然之间，脚下的世界消失了，那个人也不见了。我一直在坠落，最后来到了这里。"
    r "从一个梦境跌入另一个梦境..."
    no "你怎么知道这些都是梦境？"
    r "那还{i}能{/i}是什么呢？"
    show noah n neu with dis
    no "很有道理。"
    r "那么，这些关于谋杀的事情和我有什么关系呢？"
    "诺亚和克劳交换了一个眼神，无声地交流着。过了一会，诺亚转向罗莎米。"
    no "嗯...除了我想把你救出来之外，我觉得...你也可能会有危险。"
    show rosamie n sur with dis
    r "我？为什么？"
    show noah n ann with dis
    no "我不知道。但卢卡是最后一个被杀的人，所以..."
    "罗莎米点了点头，似乎明白了。"
    show rosamie n sad with dis
    r "那我该怎么办？"
    show crow n sadsmi with dis
    c "考虑到你特殊的情况，这可能有用，也可能没用，但你应该拿着这个护身符。"
    c "老实说，被困在梦境世界的人类应该已经死了。这里不安全，人类的身体会直接排斥它。"
    c "但你还活着并且很好，所以你的灵魂一定还在你体内。有了诺亚的帮助，你应该能安全地回家。"
    r "你呢？"
    c "..."
    c "你不用担心我。"
    show rosamie n neu with dis
    r "你不能和我一起走吗？"
    c "很遗憾...我不能。"
    c "但没关系，我在这里很好。"
    show rosamie n sad with dis
    r "..."
    "房间里沉默了好几秒钟，然后她终于再次开口。"
    r "你们两个救了我，我不会就这样离开你们—"
    stop music fadeout 1.0
    play sound earthquake fadein 1.0
    scene bg paint night at Shake((0.5, 1.0, 0.5, 1.0), 75.0, dist=2)
    "在罗莎米说完句子之前，房间变得黑暗，就像遭受了地震一样开始摇晃。一道巨大的裂缝出现在其中一面墙上，天花板开始像一个面包一样塌陷。灯光闪烁着熄灭了。"
    no sca "克劳，罗莎米...！"
    play music traintodarkness fadein 2.0
    scene bg paint day with dissolve
    "灯光慢慢亮了起来。"
    "房间另一边出现了一个看起来由烟雾和阴影组成的男人，他抓住了罗莎米的手腕。"
    "诺亚站得笔直，目不转睛地盯着那个被阴影笼罩的男人。空气中弥漫着紧张的能量。他知道这不是之前围绕着克劳的那些人。"
    "不，这正是他很久以前见过的那个人，那个把枪抵在他父亲头上无情开枪的人。"
    no ann "你...看来我们终于又见面了。"
    "诺亚的下巴紧绷，怒视着他。"
    s neu "你们两个要停止干涉与你们无关的事情。这是徒劳的努力。"
    no "..."
    no ang "放开她。"
    "他的声音低沉而危险，他稍稍站在克劳前面，保护着他。"
    s "只要你答应我的要求，我就会放开她。"
    "诺亚坚定地摇了摇头。"
    no "...我不会停下来直到你这么做。"
    play sound stab
    show bg with hpunch
    "两人之间的空气越发紧张，那个男人终于松开了罗莎米—但庆祝的时间很短，因为他的手突然插进了她的胸膛。"
    play sound bodyhit
    "当那个男人抽出手时，手中握着一样发出明亮光芒的东西，罗莎米就瘫倒在地上。"
    "而他的另一只手中，则拿着一把枪。诺亚盯着枪口，没有后退。"
    s "你害怕吗？"
    "克劳伸手想拉住诺亚，但不知为何，他的手穿过了诺亚。"
    s "再动一下我就开枪。"
    no "害怕？害怕你？不，我没有。"
    no "我心里有比你更多的烦恼。"
    "克劳从诺亚身后走出来，上前一步。他的声音带着担忧，试图与那个男人理论。"
    c sca "停下你的行为。伤害无辜的生命从来都不是正确的答案。"
    s "我不会接受一个本来就不{i}真实{/i}的人的建议。"
    "那个被阴影笼罩的男人向前迈了一步，他的声音充满了恶意和蔑视。"
    s "像你这样的假货不配存在。你站在一个人类身边，还以为自己和他平等？"
    s "你以为自己是人类吗？"
    s "你根本就不是。"
    "克劳站稳脚跟，目不转睛地盯着那个高大的身影。尽管恐惧和怀疑悄悄渗入他的思绪，但他仍然不肯退缩。"
    c fro "..."
    c "你说什么都行，那些我早就知道了。"
    c ang "你{i}必须{/i}停下你正在做的事。"
    "克劳的话似乎触动了那个男人的某根神经。他大步向前，声音在房间里回荡。"
    s "你所做的一切不过是阻碍那些需要前进的人。你戴着一张{i}不属于你的{/i}面孔。"
    no sur "...什么？"
    c sho "..."
    "克劳没有回应他的喊叫——似乎他想不出任何反驳的话。"
    s "继续说啊，说点什么。"
    "他握紧了手中的枪。"
    "克劳的声音很轻，但并没有颤抖。"
    c sad "你正在做的事是错误的。"
    c "逃避过去，摧毁它...这不是前进的方式。{i}你{/i}也不能假装你正在帮助诺亚。"
    s "你懂什么是前进？！"
    play sound gun
    scene bg paint day at Chromatic(offset=10) with hpunch:
        zoom 1.2 xalign 0.5 yalign 0.5
    "一切发生得太快了。他扣动了扳机，一颗子弹直冲向克劳。"
    "克劳站稳脚跟，闭上了眼睛，等待着子弹的到来。"
    "但他等待的痛苦并没有到来。"
    "相反，子弹穿过了他，就像他只是空气一样，然后射中了诺亚的肩膀。诺亚痛苦地后退，捂住伤口。克劳睁开眼睛，意识到刚刚发生了什么。"
    "鲜血从指缝中渗了出来。"
    c sca "诺亚...！"
    s neu "..."
    "克劳试图在诺亚倒下之前接住他，但他的手只是穿过了男人的身体。克劳张开又合上嘴，找不到合适的话说。"

    show crow n dim hea at Chromatic(offset=2), center:
        alpha 0.7
    $ camera_reset()
    with dissolve
    $all_moves(camera_check_points={u'y': [(0, 0, None), (-636, 2.73, u'ease')], u'z': [(0, 0, None), (665, 2.73, u'ease')]})
    c hea "诺亚...诺亚，不要..."
    "鲜血不断从他的肩膀流出，似乎与地板上溅开的痛苦融为一体。"
    no hur "该死的...啊，好痛..."
    c "不...不，求你不要死...我...我很抱歉..."
    no "这...这不是你的错..."
    "那个似乎被阴影笼罩的男人就像被微风吹走一样消失了。"
    "罗莎米仍然一动不动地躺在地上，就在一米外。"
    c "我..."
    c "我能做的唯一事情...我唯一有用的地方..."
    c "它...它消失了...我现在连帮你都做不到..."
    no sca "发生了什么？为什么...？"
    c "我—我也不知道..."
    c "你必须回去...你必须立刻去寻求帮助...拜托。"
    c "拜托，不要死。拜托。"
    no "我...我不会离开...啊...我不想离开你..."
    c "拜托。拜托，诺亚。"
    c "如果你能活下去，我再也不会向你要求任何事。"
    "克劳的声音颤抖着，恳求诺亚{i}活{/i}下去。泪水顺着他的脸颊流下，双手在木地板上握成拳头。"
    "诺亚试图伸出手，但即使是这样简单的动作也让他全身都在疼痛。"
    "但比那更让他害怕的是，伸出手却触碰不到他。"
    no "如果我..."
    no "如果我走了..."
    "克劳抽泣着，拼命想控制住自己的哭泣。"
    no "当我回来的时候，你还会在这里吗？"
    c "我..."
    c "我会没事的，诺亚，请不要在这种时候担心我—"
    no hur "我之所以担心，是因为你一直说你会没事！"
    no hea "你...你并不好...这没关系...这就是你告诉我的。"
    c "..."
    c "我会...我会永远在这里陪伴你。"
    c "拜托了。我会照顾罗莎米，所以请你快点回去。"
    "黑暗开始渗入诺亚的视野边缘。他抬头看向克劳恳求的眼睛，最终还是屈服了。"
    "他尽力为克劳露出微笑，就像别人一直对他微笑，说一切都会好起来。"
    no sad "好吧...好吧，我会...呃...我会去。"
    "克劳哭得更厉害了，但诺亚强迫自己移开视线，不再看那个男人脸上流下的泪水，否则他也会哭。"
    "他的胳膊感觉像是着了火，他不知道自己已经失血了多少，但他太害怕检查衣服下面，确认这一点。"
    "相反，他看向了罗莎米。她没有动，但胸膛还在起伏，呼吸着。这是个好兆头。"
    nothought "你最好在我回来的时候还在这里...我不能失去你也..."
    "当周围的世界渐渐消失时，诺亚伸向克劳，迫切地想要最后一次感受他。他觉得如果现在不这样做，他可能永远也没有机会了。"
    "也许这是真的，因为当他陷入黑暗时，他的手指只是穿过了克劳。"

    scene bg diner day
    with Fade(1.0, 3.0, 1.0)

    play sound bodyhit fadein 0.5
    show bg with hpunch
    no hur "呃...！"
    "他的肩膀撞到了桌子，重新回到原位，衣服已经被血染红了。"
    "周围的顾客们听到了骚动，都跳了起来，看到血迹后大声尖叫。一个年轻的女服务员急忙跑了过来，眼睛睁得大大的。"
    w "天啊...发生什么事了？你没事吧？我要叫救护车-"
    no ann "不...不要叫救护车..."
    no hur "我自己会去...你不用叫任何人。"
    w "等等，让我去叫经理-"
    "她消失在厨房里，诺亚趁机逃了出去。"
    "他艰难地站起来，疼痛模糊了他的思维。"
    "他一生中经历过无数次疼痛，但没有一次能与此相比。他的肩膀感觉像是在烧，就像有人把沸腾的油浇在上面，然后在下面点了一根火柴。"
    "但尽管如此，他还是强迫自己向前走，朝餐厅的前门走去，在离开前在桌上扔下了一些钱来支付饮料和小费。他用单手尽快打开了门，然后走了出去。"

    scene bg streets day:
        subpixel True xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 2.0 rotate None
        parallel:
            ypos 1.0
            ease 24.52 ypos 2.0

    $ camera_reset()
    with Fade(1.0, 1.0, 1.0)

    "阳光还高高挂在天空中，当他蹒跚地走在人行道上时，每一步都比前一步更加痛苦。周围的声音都融合成一片，汽车喇叭声、行人谈话声、狗叫声。"
    nothought "该死...该死，我不能去医院...没时间了..."
    nothought "我必须回到克劳那里去..."
    "用剩下的那只手，诺亚从口袋里掏出手机。和往常一样，手机上满是未接来电和未读短信，他忽略了那些，转而去找联系人，在一个名字上停了下来。"
    "他的手指停在凯恩的名字上，然后他的眼睛找到了另一个人的名字。伊万。"
    nothought "这什么时候加进来的..."
    nothought "算了。我不信任你，但...你不是那个做这一切的人，对吧？"
    "他小心翼翼地，慢慢地打出了一条消息。"

    "嘿。长话短说，我被枪击了。你能来我家吗？\'" #text
    "\'不要告诉任何人。\'" #text

    "他没有等待回复就把手机放下了。伊万似乎不是那种会回应的人-如果他来帮忙，那就来帮忙，否则他就会无视这件事。"
    "尽管他的公寓只有一小段距离，但在终于到达家里之前，感觉就像过了一个世纪。他的肩膀已经变得如此沉重，仿佛和他整个身体一样重，走路更像是踉跄而不是行走。"

    scene bg noahbedroom night with Fade(1.0, 1.0, 1.0) :
        subpixel True xpos 0.84 ypos 1.02 xanchor 0.5 yanchor 1.0 zoom 1.74 rotate None

    no hur "操...好痛..."
    "他倒在床上，筋疲力尽。"
    "他的胳膊一直在跳动，让他不得不紧紧抓住身边的床单，终于拨开衣服看了看肩膀上的伤口。"
    "子弹进入的地方一片血肉模糊，看着就让他感到恶心。"
    "但不知为什么，诺亚似乎被它迷住了。它就像一幅空白画布上最美丽的红色油彩，吸引着他的注意力，激发了他的思维。"
    "不过，最后他肯定不会去画画。他连好好躺在床上都做不到。"
    "他的意识时而清晰，时而模糊，有时感到温暖，有时感到寒冷，但无法从中获得任何缓解。他不禁想知道，这是不是死亡的感觉。"
    nothought "我...我还不想死..."
    nothought "我需要回到克劳那里...我需要帮助罗莎米..."
    "不知是过了五分钟还是两个小时，诺亚的卧室门终于打开了，一个白发男人走了进来，脸上依旧没有什么表情。"

    i neu "所以，你被枪击了。"
    i "我没想到你还有这本事。"
    no hur "是啊，我也没什么选择。"
    "伊万似乎不想费心问为什么或者怎么回事。他只是双臂交叉，上下打量着诺亚。"
    i neufro "子弹还在里面吗？"
    no ann "除非它神奇地消失了。"
    i smu "它们通常不会这样。"
    no "真他妈的。"
    i neu "好在你没有取出子弹，否则我可能会在来这里的时候发现你已经失血而死。"
    no hea "对...对..."
    no "那...我们该怎么办？"
    i "你家里有急救箱吗？"
    no hur "有...在厨房里。"
    "伊万又消失了一会儿，然后重新出现。诺亚趁机坐起来一点，呻吟着感受到了胳膊上的疼痛。"
    "伊万跪在诺亚身边，撕开遮挡的衣服，仔细观察那个子弹孔。"
    i "还不错。"
    "快速地，伊万把一小块纱布塞进了伤口，那里已经大部分停止了流血。诺亚皱了皱眉，但这并没有阻止伊万的动作。"
    "之后，他用另一块纱布盖住了纱布填充的伤口，并用胶带固定住。"
    "他轻轻地按了下去，施加了轻微的压力。"
    i neufro "看起来并不太糟。这应该能止住出血，直到你能，你知道的，去真正的医院。"
    i "我猜你给我发消息肯定有原因。"
    no "...我很着急。"
    i "你这样子是不会急着去任何地方的。"
    i neu "你这只胳膊几个月内都不会恢复正常了。"
    no ann "..."
    no fro "你怎么知道这么多？"
    "伊万耸了耸肩。"
    i hap "常识。"
    no "这绝对不是常识。闯入、干扰信号、处理枪伤伤口..."
    no "这不是普通人能做的事。"
    i "不过对你来说还挺有用的，对吧？"
    no ann "看来是这样。"
    "每个字都很费力地说出来。他靠在枕头上，后脑勺抵着墙。"
    no hur "你对梦之类的东西了解很多，对吧？"
    i neu "我知道够多了。"
    no "..."
    no "有没有办法把...把里面的东西带出来？"
    i neufro "你说的{i}东西{/i}，是指人吗。"
    no ann "我...是的。"
    no sad "罗莎米...应该能离开，但是其他人呢？"
    i neu "..."
    i sad "那个家伙？"
    "他的话语中隐藏着一种复杂的情感。这是诺亚从未从伊万那里听到过的，他也无法理解。毕竟他现在太痛苦了。"
    i "我...完全不知道。他没有真正的身体可以回来，所以谁知道他要是想离开会发生什么。"
    no sad "对...对，当然。"
    no hur "妈的，我的大脑感觉太模糊了..."
    no ann "我只是想...想给他看点东西..."
    i neu "为什么不在梦里给他看呢？"
    no neu "在梦里...我想这也不是个坏主意。"
    i hap "我可是个满脑子好主意的人。"
    no ann "听起来很对。"
    no "总之...我需要个帮忙。"
    "伊万挑起一边眉毛。"
    i neu"我已经帮过你一次忙了，来到这里。"
    "诺亚继续说下去，无视伊万的话。"
    no "...我需要...我觉得我再也撑不住了..."
    no "你能留在这里直到我醒来吗？"
    i neu "我又不是你的护士。"
    no "如果凯恩急匆匆地来了，就叫醒我，告诉我，好吗？"
    "这似乎引起了伊万的兴趣。他露出了一个歪斜的笑容。"
    i smu "你不想让他知道这件事，对吧？"
    no fro "..."
    nothought "对，我不想。他只会更担心..."
    no "这...很复杂。"
    i "{i}复杂{/i}这个词听起来很有趣。"
    i "好吧，我会留下来。"
    i "只是因为我喜欢看到他走进来然后看到我的表情。"
    no ann "你真是个混蛋。"
    "伊万又耸了耸肩，这次他露出了一丝微笑。"
    "他伸手向门口走去——没有再说一个字，就从视线中消失了。"

    nothought "真是个怪人...我一定是疯了，才会相信他不会在我睡觉的时候杀了我..."
    "诺亚的眼皮变得沉重——它们迫切地想要合上。周围的黑暗感觉很安全，很温暖，尽管有些孤独。他的头慢慢靠在墙上，完全放松了受伤的胳膊。"
    "它仍然非常疼痛，但与他当时脑海中的其他一切相比，这只是一个小问题。"
    "独自思考了一会儿，他做出了一个决定。"
    "不久前，他还认为感受痛苦比什么都好。"
    "也许在某种程度上这仍然是真的——感受什么都没有是如此空虚、空洞。"
    "但是现在，诺亚不想感到空虚、空洞、悲伤或痛苦..."
    "他只想感受到有重要的人在他身边的那种满足感。"
    "他的手指触碰到了嘴唇，那里仿佛还残留着乌鸦的痕迹。他们没有亲吻，不，但已经足够接近了..."
    nothought "我真的要吻他吗...？"
    stop music fadeout 3.0
    "怀着这个想法，他陷入了一个不安的睡眠。"

    ### flashback ##########################################################################

    scene bg bedroom day with Fade(1.0, 1.0, 1.0)
    play sound alarmclock
    "诺亚的眼睛在闹钟尖啸的声音中猛地睁开。他慢慢坐起来，伸展了一下肩膀，然后跳下了床。"
    play music herehecomes fadein 4.0
    "洗脸刷牙后，他穿上制服，滑进鞋子里。"
    "他忍不住在镜子里看到自己的倒影——想起昨晚的事，脸颊通红。那时，只有天上的星星见证了奥古斯特吻他的样子。"
    noteen shy "我该怎么面对他..."
    "他把脸埋在手掌里呻吟着，很清楚自己别无选择——即使今天逃学，这种情况也不能永远持续下去。"
    "最终，他必须面对自己和奥古斯特确实接吻了，并且双方都同意交往的事实。"
    noteen shy "怎么谈恋爱呢...我该怎么做..."
    "每一个想法都让他脸上的热度增加，直到双颊滚烫。"
    "幸好，他有解决的办法。"
    "诺亚再次拿出手机，回复了凯恩发来的一条愚蠢的表情包，然后切换到他信赖的网络搜索。"
    "谈恋爱的时候应该做些什么？\'"
    "然而，搜索结果只让一切变得更糟。他叹了口气，把手机塞进口袋，然后离开了房间。"

    scene bg livingroom day with Fade(1.0, 1.0, 1.0)

    m "终于起床了，是吗？"
    noteen neu "...是的。我现在就走。"
    m "等一下—"
    "诺亚的妈妈从厨房冲了出来，速度快得让他忍不住一缩。"
    m "我刚和你爸爸聊过——你知道他公司的CEO有一个和你差不多大的女儿吗？"
    noteen neu "呃...我不知道。这和我有什么关系...？"
    m "注意你的语气，小子。我们在考虑介绍你们认识。"
    m "我很确定她远远超出你的水平，但是——"
    noteen sho "啊？"
    noteen ang "我不感兴趣。"
    m "亲爱的，别这样。如果你给他留下好印象，对你爸爸的事业很有帮助。"
    noteen ang "帮他升职不是我的工作。他自己解决吧。"
    m "诺亚...！"
    ash mock "呸..."
    m "你在这里啊，艾许。请告诉你哥哥要更有礼貌一些。"
    ash neu "那你可以介绍我来代替他啊——"
    m "哦，艾许，别说傻话。"
    "诺亚趁机离开了。他快速转身打开前门，无视身后母亲的抗议。"

    scene mountains day:
        size(1920, 1080)

    $all_moves(camera_check_points={u'z': [(314, 0, u'linear')]})
    show kaineteen n hap at slightright
    show noahteen n ang at slightleft
    with Fade(1.0, 1.0, 1.0)

    k "看看是谁来了。"
    no "要不是我妈非要给我介绍相亲对象，我也不会耽搁这么久。"
    show kaineteen n sur with dis
    k "{i}什么{/i}？"
    no "你听见了。"
    k "我听见了，但你是什么意思？"
    no "她想让我认识我爸老板的女儿，或者什么的..."
    show kaineteen n hap with dis
    k "伙计，你真的要被安排相亲了。"
    show noahteen n sho with dis
    no "我才不会！"
    k "你会的！你会陷入一段毫无感情的婚姻，只为了地位...嘿，如果你无聊的话，我不介意做你的情人。"
    no "什——我不会结婚，更不会让你做我的情人。"
    "凯恩笑着，用胳膊肘戳了戳诺亚的肋骨。"
    show kaineteen n hap with dis
    k "我可以穿小女仆装，这样会不会有帮助？"
    show noahteen n pou with dis
    no "你快让我吐了，住手吧。"
    k "哦，真遗憾。你就是不好玩。"
    show noahteen n sad with dis
    no "我...我只想为了爱情结婚。即使家人断绝我的经济来源，我也不会听他们的安排。"
    k "哇，你真是个浪漫主义者啊。"
    show noahteen n pou with dis
    no "闭嘴吧，伙计。"
    "他们继续往山下走去——看来奥古斯特今天早上已经先走了，这让诺亚感到庆幸。"
    show kaineteen n fro with dis
    k "我真希望我也能像你一样勇敢地反抗父母...他们想让我去金融或法律之类的工作，真恶心。"
    "诺亚的目光沿着熟悉的小路向下，跟着曲线的弧度。白天看起来完全不同。"
    nothought "我们昨晚就是在这里走下来的...然后...然后我们接吻了..."
    k "他们就是不在乎我不想被塞进某个无聊的政府工作里，一辈子腐烂下去..."
    nothought "我们真的接吻了。天啊，我们真的...真的，真的，真的接吻了..."
    k "这个世界上还有那么多事等着去做。我不想变成他们那样，在一个和其他所有办公室一模一样的地方腐烂..."
    nothought "现在我是他的...他是我的...男朋友？"
    show kaineteen n neu with dis
    k "伙计，你有在听吗？"
    show noahteen n sur with dis
    no "啊？"
    k "输家说什么。"
    show noahteen n neu with dis
    no "什么...？"
    show kaineteen n hap with dis
    k "哼。"
    no "..."
    no "抱歉，我只是...在想一些事情..."
    k "你在想什么？"
    no "哦，没什么，别担心。"
    k "这让我更加好奇了。快告诉我吧。"
    show noahteen n pou with dis
    no "没什么好说的！"
    k "你只有在隐藏什么的时候才会露出那副蠢样。"
    no "..."
    show noahteen n neu with dis
    no "...你—你不能告诉任何人，好吗？"
    show noahteen n sca with dis
    no "不能告诉学校里的任何人，更不能告诉我的家人..."
    k "为什么我要告诉任何人？你可以相信我。你知道的。"
    k "要不要拉钩发誓？"
    no "天啊，也许我不应该告诉你。"
    show noahteen n pou with dis
    no "..."
    show noahteen n poublu with dis
    no "昨晚，我和奥古斯特亲吻了。"
    show kaineteen n sur with dis
    k "........"
    no "........"
    k "............"
    show noahteen n neublu with dis
    no "凯—凯恩...？"
    k "我..."
    show kaineteen n sho with dis
    k "这是...一件好事，对吗？这就是...你想要的？"
    no "是啊..."
    k "..."
    show kaineteen n neu with dis
    k "我为你感到高兴，诺亚。"
    show noahteen n sad with dis
    no "你不...觉得我很奇怪吗？"
    show kaineteen n hap with dis
    k "哦，你确实很奇怪，但这和这件事无关。"
    show kaineteen n neu with dis
    k "真的...我为你感到高兴。奥古斯特很棒。"
    show noahteen n neublu with dis
    no "是...是的..."
    "虽然他笑了，但两人之间的气氛确实很尴尬。凯恩在说话时移开了视线。"
    "过了一段时间，两人之间再也没有说话，他们到达了山脚下—那里的岩石地面变成了普通的街道。"

    scene bg town day with Fade(1.0, 1.0, 1.0):
        subpixel True xpos 0.75 ypos 1.09 xanchor 0.5 yanchor 1.0 zoom 1.54 rotate None

    "路边停着几辆汽车，其他汽车则在街道上来来往往—尽管在这么早的时候，交通并不太多。"
    "这是一个安静的小镇，诺亚常常对此感到好奇。他的父母本可以住在任何地方，为什么选择这里呢？"
    "不过，如果他只有一件事要感谢他们，那就是他们决定住在这里。这让他遇到了他最好的朋友凯恩，现在还遇到了奥古斯特。"
    show kaineteen n neu at slightright:
        subpixel True xpos 0.51 ypos 1.0 xanchor 0.8 yanchor 1.0 rotate None
    show noahteen n neublu at slightleft:
        subpixel True xpos 0.08 ypos 1.0 xanchor 0.2 yanchor 1.0 rotate None
    with dissolve
    k "嘿，诺亚..."
    show noahteen n neu with dis
    no "嗯？"
    show kaineteen n fro with dis
    k "这和你父母不喜欢奥古斯特有关吗？"
    show noahteen n sad with dis
    no "是的，很遗憾..."
    k "所以...这一切...已经持续了一段时间了？"
    no "我...我想从一开始就是这样的？"
    k "..."
    show kaineteen n sad with dis
    k "好吧，谢谢你告诉我。不过你早就应该告诉我了。"
    no "我不知道你会有什么反应...如果你只是...讨厌我..."
    k "我怎么可能讨厌你？"
    k "你比谁都了解我。"
    show kaineteen n neu with dis
    k "即使你讨厌我，即使你骂我让我离开你，我也会在你身边。"
    show noahteen n neu with dis
    no "你真是个粘人精。"
    show kaineteen n hap with dis
    k "只是有一点。"
    show noahteen n neublu with dis
    no "谢谢你，凯恩..."
    k "没什么好谢的。来吧，我们最好进去了。"
    "两人走向校门，一个橙发男孩站在那里。当他们的目光相遇时，他向诺亚挥手，这差点让诺亚退缩了。"
    show noahteen n neu with dis
    nothought "糟糕...在发生了和奥古斯特的事情之后，我完全忘记了他..."
    "一股恐惧感在他的胃里沉淀下来，他拼命想着任何避开卢卡的办法—但是没有办法。诺亚和凯恩正要走过去，卢卡却突然跳到了他们面前。"
    l smi "诺亚！"
    l smi "哦，还有你的朋友！你的名字是什么来着...凯尔？"
    show kaineteen n fro with dis
    k "凯恩。"
    l smi "凯恩！对，就是这个名字。"
    l smi "你朋友的生日过得怎么样~？"
    "诺亚把目光移向地面。"
    show noahteen n sad with dis
    no "是、是的..."
    l smi "太棒了！我迫不及待想听听发生了什么！"
    l hap "嘿，放学后我们要不要一起出去玩？"
    no "..."
    k "..."
    k "我们得走了，不然要迟到了。你也该进去了。"
    l smi "别让我耽误你们。再见，诺亚！"
    "他夸张地挥着手，凯恩抓住诺亚的胳膊，把他带进了教室。"

    scene bg classroom day with Fade(1.0, 1.0, 1.0)

    kteen fro "那是怎么回事？"
    noteen sad "什么怎么回事？"
    kteen "那个孩子。你完全僵住了。"
    kteen "发生什么事了吗？"
    noteen "..."
    nothought "我不想让他担心...这是我自己的问题要处理..."
    noteen pou "没什么大不了的。只是一些...艺术方面的事情。"
    kteen sad  "如果有什么大事，你会告诉我的，对吗？"
    noteen sad "当然会。"
    kteen "好吧..."


    scene bg classroom day with dis:
        subpixel True xpos 0.5 ypos 1.29 xanchor 0.5 yanchor 1.0 zoom 1.71 rotate None
        parallel:
            xpos 0.47
            ease 24.28 xpos 0.89

    "坐在办公桌前的奥古斯特正靠在椅子上。他面向窗外，看着山上的树木在风中来回摇摆。"
    "当他转过身面对诺亚时，仿佛一切都慢了下来。他灿烂地微笑，仅仅这一个小动作就点亮了整个房间。"
    "诺亚机械地抬起手，勉强算是打了个招呼。"
    "就像个机器人，但脸颊通红，他走到自己的桌子前坐了下来。"
    "不到三十秒，一张纸就砸中了他的后脑勺。他低头看到纸条落在地上，赶紧捡了起来。"

    show popout
    show note5:
        xalign 0.53 yalign 0.3
    with dissolve

    "你真是太明显了，笨蛋。\'"
    noteen shy "..."
    "诺亚转过身怒视着凯恩，后者只是咧嘴笑了。"
    nothought "天哪，告诉他真是个严重的错误，不是吗..."
    hide popout
    hide note5
    with dissolve
    "上课铃很快就响了，但对诺亚来说这节课并不有趣。当坐在身边的奥古斯特——就是昨晚亲吻过他的那个奥古斯特时，他怎么可能对英语感兴趣呢？"
    "他用铅笔在纸上乱涂乱画，在原本干净的页面上留下一些随意的黑线。"
    "罗丝小姐单调的朗读声似乎渐渐远去。"
    nothought "我还能看到那双嘴唇...吻上我的..."
    nothought "啊，这就是我一直在想的！滚开，愚蠢的想法！滚开！"
    "诺亚用余光观察着奥古斯特，既渴望与他对视，又害怕与他对视。"
    "他的心砰砰直跳，胃部也不舒服地紧缩；他试图通过在纸张边缘涂鸦来分散注意力，但发现这毫无帮助。"
    "那节课仿佛永远也结束不了——当铃声终于响起时，诺亚飞快地站起身，以连凯恩都没反应过来的速度离开了教室。"

    scene bg school corridor with Fade(1.0, 1.0, 1.0)

    noteen shy "哈...我真是个懦夫..."
    noteen shy "我现在该对他说什么..."
    nothought "我只是要躲一会儿...很快就会面对他的...一定会的..."
    "当然，他并不确定自己能在哪里躲避奥古斯特，但他的双脚似乎带着他朝某个方向走去，给了他一个主意。"
    nothought "屋顶...我听说有人有时会偷偷溜到那里去，对吧？"
    nothought "我想奥古斯特应该不会去那里找我。"
    nothought "对不起，奥古斯特..."
    show bg with hpunch
    ur sur "哇——"
    "诺亚终于抬头看了看地面，正好撞到了一个人。她向后退了一步，勉强稳住了身子，没有摔倒。"
    "她皱着眉头看着诺亚。她的头发又长又粉色——诺亚很惊讶学校居然会允许这样。"
    "她个子很小很纤细，确实很引人注目，但脸上的皱眉看起来有些不合适。"
    ur ann "小心点。"
    noteen sho "哦，呃...对不起，我不是故意的—"
    "她径直走了过去，完全无视了他的话。她留下的只有淡淡的花香味。"
    noteen sho "..."
    nothought "随便吧。"

    scene bg terrace day with Fade(1.0, 1.0, 1.0)

    "当诺亚推开通往屋顶的门时，蔚蓝的天空展现在他眼前。"
    "这是一幅美丽的景象：视野所及之处天空清澈，四周环绕的群山也是如此。"
    "遍布山坡的绿树在微风中轻轻摇摆，诺亚能想象它们叶子沙沙作响的声音。"
    "到目前为止还没有其他人来到屋顶——这也很合理，因为诺亚是急匆匆地跑上来的。"
    "他叹了口气，靠着墙壁坐了下来，完全忽视了周围的座椅。"
    nothought "他们为什么要在这里放座椅，如果我们不应该来这里..."
    "除了太多的时间和空间让他思考之外，什么也没有。诺亚打开笔记本，从口袋里拿出一支铅笔。"
    nothought "我能画些什么...让我的思绪从一切中解脱..."
    "漫不经心地，他从眼前的景象开始画起。那些占据地平线的巍峨群山，就像一头巨兽。他又画了几笔，然后停下来。"
    nothought "我...我要把这个给卢卡..."
    nothought "我不会让任何事情发生在奥古斯特身上...我绝不会让任何事情发生在他身上。"
    nothought "唉，我真希望从来没去过那个愚蠢的美术社。"
    scene bg terrace day with dissolve:
        subpixel True xpos 0.5 ypos 1.08 xanchor 0.5 yanchor 1.0 zoom 1.29 rotate None
        parallel:
            xpos 0.59
            ease 1.22 xpos 0.64
    "随着吱呀作响的门发出声音，他停下了动作。"



    show noahteen m sho at slightleft
    show august m glasses sho at slightright
    with dissolve

    a "找到你了！"
    no "哦...奥古斯特。"
    nothought "我还以为会是老师呢。这算好还是坏..."
    show august m neu with dis
    a "你为什么那么快就跑掉了？"
    "奥古斯特朝诺亚走了几步，然后在他身边坐了下来。他们的肩膀相碰，诺亚能感受到一股强烈的热量。"
    show noahteen m poublu with dis
    no "我...我没有跑掉。"
    a "你肯定是跑掉了。"
    no "..."
    no "我只是...想呼吸点新鲜空气。"
    a "你明明是在躲着我。"
    show noahteen m sho with dis
    no "不是！我—"
    show august m hap with dis
    a "你就是在躲着我！"
    "他笑了——那是一种轻松愉快的笑声，只是让诺亚为躲避这个如此...完美的人而感到内疚。"
    nothought "完美..."
    show august m pou with dis
    a "你真的不想和我在一起吗？"
    "奥古斯特撅起嘴，这种表情似乎更多是在戏弄，而不是别的什么——不过诺亚是注意不到的。他立即慌乱地试图解释自己。"
    no "这不是..."
    show noahteen m shy with dis
    no "我真的很想和你在一起，我只是..."
    "诺亚的眼睛盯着地面。"
    no "我很紧张..."
    "奥古斯特把头靠在诺亚的肩膀上，这让他全身都紧张了起来。"
    show august m hap with dis
    a "为什么？"
    no "我—我...我...我...！"
    show august m hapblu with dis
    a "好吧，好吧，我不会再逗你了，我保证！"
    "他又笑了，像是一阵完美的春风。尽管脸颊发烫，诺亚还是忍不住也笑了。"
    show august m shy with dis
    a "说实话...我对今天这么紧张，昨晚都没睡好。"
    a "我理解。"
    no "什么—你看起来总是那么冷静自持...我怎么也想不到。"
    show august m hapblu with dis
    a "我真希望我也能一直这么冷静自持！"
    "奥古斯特温和地笑着，把头靠在墙上，望向天空。几朵云悠闲地在广阔的蓝天上飘荡，阳光洒在两人身上。"
    a "你觉得云朵看起来很舒服，不是吗？"
    no "我从来没有这么想过。"
    "诺亚的眼睛跟随着奥古斯特的目光，他终于长出了一口气。"
    show august m shy with dis
    a "我知道它们不是，但看起来好像很蓬松...就像我可以在上面小睡一会儿，然后整个下午都飘飘欲仙。"
    "奥古斯特的头再次靠在诺亚的肩膀上。这次，他没有装作生气或者逗弄这个黑发男孩。他只是静静地靠着。"
    a "...这样也很舒服。"
    show august m hapblu with dis
    a "等等，也许这样更好。"
    nothought "他...他靠在我的肩膀上...他离我这么近...天啊，他离我这么近..."
    "他的肩膀比实际上要重得多，诺亚的心脏在胸膛里砰砰直跳，他祈祷奥古斯特听不到。"
    a "...谢谢你昨天送我的生日礼物，诺亚。我很喜欢。"
    a "爸爸也很喜欢。"
    show noahteen m neublu with dis
    no "这...这没什么..."
    no "我很高兴你喜欢。"
    show august m shy with dis
    a "还有，谢谢你吻我。"
    no "...!"
    show noahteen m poublu with dis
    no "嘿...！"
    show august m hapblu with dis
    a "嘿嘿。"
    a "对不起，我说过我不会再逗你了，是不是？"
    no "..."
    no "如果是你的话，我不介意。"
    "诺亚小声嘟囔着，但奥古斯特还是笑了出来。"
    a "你在这里做什么？"
    show noahteen m neu with dis
    no "主要是在写写画画。"
    show august m hap with dis
    a "我能看看吗？"
    "诺亚把素描本递给奥古斯特，后者接过来仔细观看。他惊讶地在诺亚的画作和眼前的景色之间来回看着。"
    show august m sho with dis
    a "这太漂亮了，诺亚。这不是什么简单的涂鸦！"
    show noahteen m pou with dis
    no "你这么觉得吗？也没什么特别的..."
    show august m hap with dis
    a "你做的一切都很特别。"
    a "你一定下了很大功夫才能画得这么好，对吗？"
    no "我想是吧..."
    a "我也想试试画画。"
    show august m pou with dis
    a "不过这可能有点无聊...先是因为爸爸学摄影，现在又因为你学画画，好像我自己找不到爱好。"
    show noahteen m sad with dis
    no "我觉得你尝试各种新事物很酷。我只会做这种事情。"
    a "如果我也擅长某件事，我想我也会全身心投入吧。"
    show august m shy with dis
    a "我能问你一个问题吗？"
    "紧张感笼罩了诺亚。"
    show noahteen m shy with dis
    no "当然。"
    a "明天放学后，你想一起做点什么吗？"
    no "明天？是的，我想—我是说，我很乐意。"
    show august m hapblu with dis
    a "也许我们可以去看电影？有一部新电影我很想看。"
    no "这是...我是说，我只是问，这是不是...呃..."
    a "一个约会？"
    no "....."
    a "如果你愿意的话。"
    show noahteen m sho with dis
    no "好的！"
    show noahteen m shy with dis
    no "嗯...我是说，好的，很酷。"
    "不知何时，他们的手找到了彼此。手指交织在一起，紧紧相握，靠在墙上。他们沉默地凝视着对方。谁也没有说话，谁也没有动；他们只是静静地看着时间一点点流逝，仿佛想要永远保留下这一刻的每一个细节。"
    "这感觉就像时间停止了—诺亚几乎希望它真的停下来了。他希望能永远和奥古斯特，还有那片广阔的蓝天，一起停留在这一刻。"
    show black with eye_shut
    "渐渐地，两个男孩靠近，直到额头相抵。当奥古斯特轻轻闭上眼睛时，诺亚也跟着闭上了。"

    "然后，在两个男孩意识到发生了什么之前，他们的嘴唇相遇了。"
    play sound schoolbell
    hide black with eye_open
    show august m sur with dis
    show noahteen m sca with dis
    aan "啊！"
    "随着铃声清晰地响起，他们迅速分开了。"
    show august m shy with dis
    a "我——我想我们应该走了！"
    show noahteen m shy with dis
    no "我们应该走！"
    stop music fadeout 3.0
    "这对人无法直视对方，他们退回到下面的走廊里。"

    scene bg school corridor with Fade(1.0, 1.0, 1.0)

    show luka n smirk at farleft
    show kaineteen n fro at cenleft
    show noahteen n neu at cenright
    show august n sho glasses at farright
    with dissolve
    play music coma fadein 4.0
    l "这越来越有趣了，不是吗？"
    k "在我让你闭嘴之前，你最好闭嘴——"
    show noahteen n sho with dis
    no "凯恩？"
    "当奥古斯特和诺亚走进通往他们教室的走廊时，他们发现走廊里已经完全空了，除了角落里站着的两个人。"
    "凯恩紧紧抓住卢卡的衣领，几乎要把他勒死，同时愤怒地咆哮着。"
    "但当他听到诺亚关切的声音时，他的头猛地转过来，脸上露出惊讶的表情。"
    show kaineteen n sho with dis
    k "诺亚，奥古斯特..."
    show august n sur with dis
    a "一切都好吗...？"
    k "...没什么。别担心。"
    "凯恩终于松开了卢卡的衣领，这让卢卡发出了夸张的叹息。"
    show luka n sad with dis
    l "你真是个坏蛋，凯恩。我只是想聊聊天！"
    l "我简直不敢{i}相信{/i}你会这么残忍！"
    l "我到底做了什么让你这样对我？"
    show kaineteen n fro with dis
    k "...切。"
    "他抽泣着，擦去眼角的眼泪。"
    show august n sho with dis
    a "好了，好了..."
    show august n neu with dis
    "奥古斯特走上前去，脸上带着一丝和解的微笑。"
    a "这肯定只是一个误会。"
    a "我敢打赌，凯恩并不是想伤害你或争论——他其实非常善良。"
    l "他可一点也不{i}表现得{/i}善良。他简直是个彻头彻尾的混蛋。"
    l "我好害怕...！"
    l "我没想到他会这么讨厌..."
    "卢卡擦去眼角的几滴眼泪，然后微笑起来。"
    show luka n smi with dis
    l "不过{i}你{/i}看起来挺不错的！"
    l "嗯..."
    l "你是奥古斯特吗？"
    show august n sho with dis
    a "哦，是的，我就是。你是...？"
    l "我是卢卡！我是诺亚的朋友..."
    show luka n hap with dis
    l "我想我也是凯恩的敌人，嘿嘿。"
    l "很高兴认识你！"
    l "嘿。你知道吗-"
    show noahteen n sca with dis
    no "..."
    nothought "我得赶紧把我们带走——"
    "在卢卡能对这三人说更多之前，凯恩抓住他们两个的胳膊，开始把他们往教室走去。"
    hide august
    hide noahteen
    hide kaineteen
    hide luka
    with dissolve
    l sad "啊，真可惜！你不想留下来聊聊吗？"
    "卢卡撅起嘴。"
    l sad "真遗憾..."
    l neu "不过我想铃声已经响了，嘿嘿。"
    l hap "我可不想让你们迟到上课，所以我就放你们走吧。"
    l smi "再见，你们三个！"
    noteen sho "嗯..."
    "诺亚终于挣脱了凯恩的抓握，然后疑惑地看着他。"
    noteen sho "那到底是怎么回事？"
    kteen fro "没什么。无关紧要。"
    kteen fro "我们待会再谈。"
    kteen fro "我们先去上课吧。"
    "看到凯恩竟然会为某事而恼火，这还是一件罕见的事。但在那一刻，他看起来非常愤怒。"

    scene bg classroom day with Fade(1.0, 1.0, 1.0)

    "整个剩下的一天，凯恩的表情都没有变过，这只让诺亚更加困惑。"
    nothought "到底发生了什么？卢卡又在打什么主意...？"
    stop music fadeout 3.0
    "不过，即使是卢卡也无法打击诺亚此时的好心情。与奥古斯特约会的想法让他感到内心激动不已。"
    "如果诺亚必须说运气是真是假，他会说它绝对是真的——而且他生来就没有一点运气。"
    play music unsaid fadein 3.0
    "如果某件事有50%%的几率发生，他总是会输。如果他的人生是一个棋盘游戏，那么诺亚在第一次坐下来玩之前就已经破产了。"
    "但现在，他觉得这一切都很好——如果能换来与人如奥古斯特在一起，他愿意放弃一生的运气。"

    scene bg mountains day with Fade(1.0, 2.0, 1.0)

    "这三人沉默地走着。"
    "凯恩似乎不想谈论刚才发生的事，而奥古斯特和诺亚也不想问。"

    scene bg town day with Fade(1.0, 1.0, 1.0):
        subpixel True xpos -0.02 ypos 1.52 xanchor 0.5 yanchor 1.0 zoom 2.11 rotate None

    a neu "...再见，伙计们。"
    a hap "祝你周末愉快，凯恩！"
    kteen sad "是啊...是啊，你们也是。"
    "凯恩先离开了。诺亚和奥古斯特注视着他离去的背影，脸上写满了担忧。"
    a sad "我很担心他。"
    noteen sad "我也是..."
    a sad "而且我觉得在发生了那些事之后，让他独自离开并不合适...我要去追上他！"
    noteen sho "等等，我可以—"
    a hap "没事的！我明天见你，诺亚！"
    "奥古斯特在诺亚来得及跟上之前就急忙追上了凯恩。"
    nothought "你到底怎么了，凯恩...？"

    scene bg livingroom day with Fade(1.0, 1.0, 1.0)
    stop music fadeout 3.0
    m "你终于回来了，亲爱的。我想和你谈谈。"
    nothought "天哪，这应该会很有趣。"
    play music shift fadein 4.0
    m "既然你现在没有家教，而且我知道你有重要的考试要来，艾许已经提出要帮你复习了。"
    noteen neu "....."
    noteen sca "我可以拒绝吗？"
    m "你应该对你哥哥说{i}谢谢{/i}。"
    m "他甚至还邀请了他的朋友来帮忙。"
    nothought "帮忙。当然了，更像是他带来了帮手来骚扰我。"
    noteen sad "...好吧。"
    m "要多点感激之心，诺亚。"
    noteen sad "是啊，没错..."
    "诺亚走到自己的卧室，发现门已经微微开着，感到既惊讶又警惕。"

    scene bg bedroom day with Fade(1.0, 1.0, 1.0)
    $ camera_reset()

    $all_moves(camera_check_points={u'z': [(255, 0, u'linear')]})
    show noahteen n neu at slightright
    show asher n mock at slightleft
    with dissolve

    ash "看看是谁来了。"
    "艾许坐在诺亚的桌子旁，桌上摆着几本教科书和他自己的笔记本。看起来他更像是在自己学习。"
    show noahteen n sho with dis
    no "你碰过我的东西吗？"
    "诺亚立刻皱起了眉头，但艾许只是轻蔑地回了一声。"
    ash "我碰了你的地板。你的桌子。有什么问题吗？"
    no "你知道我不是指这个。"
    show asher n smi with dis
    ash "我为什么要碰你的东西？"
    show noahteen n ang with dis
    no "很好的问题-我也很想知道，因为你{i}前几天把我的美术书扔进河里{/i}。"
    "艾许得意地笑了。"
    ash "那是个意外，记得吗？"
    show noahteen n sad with dis
    no "随便吧。"
    "诺亚走到床边坐下，发现有人躺在上面，脸上盖着一本书，正在轻轻打鼾。"
    nothought "这就是那个朋友？看起来他可没在认真学习..."
    show asher n neu with dis
    ash "鲁本，醒醒。"
    "打鼾声还在继续。"
    ash "鲁本。"
    "还在继续。"
    $all_moves(camera_check_points={u'z': [(255, 0, None), (109, 1.89, u'ease')]})
    ash "鲁本，我不小心弄坏了你借我的那本书的书脊—"
    show reuben n sur at slightleft:
        subpixel True xpos 0.26 ypos 1.0 xanchor 0.2 yanchor 1.0 rotate None
    with dissolve

    show asher n neu at left
    with move

    reu "你{i}什么？{/i}"
    "他立刻坐了起来，盖在脸上的书掉到了腿上。"
    reu "那是我最喜欢的书..."
    show asher n smi with dis
    ash "开玩笑的。"
    show reuben n ann with dis
    reu "..."
    reu "你真是个混蛋。"
    "说完这些，他又躺了下来，拿起了书。"
    show noahteen n neu with dis
    no "这是我的床..."
    show reuben n neu with dis
    reu "很舒服。谢谢。"
    reu "你一定就是诺亚了。"
    no "你们不是应该来帮我复习吗？"
    show asher n neu with dis
    ash "我坐在这里只是为了让妈妈高兴，但我不会帮你的忙。"
    ash "我自己还有工作要做。"
    no "那他呢...？"
    show asher n mock with dis
    ash "很明显，他在看书。"
    show reuben n sur with dis
    reu "你应该去帮帮他，艾许。"
    show asher n fro with dis
    ash "他不需要我的帮助。他是那种天赋异禀的孩子，从来不需要复习。"
    show noahteen n sho with dis
    no "我一直在复习啊..."
    reu "....."
    reu "你们可以一起合作。"
    show asher n mock with dis
    ash "或者他可以替{i}我{/i}做作业，这样你就会高兴了。"
    show reuben n fro with dis
    reu "不会。别偷懒。"
    show asher n smi with dis
    ash "偷懒。对，这话从你嘴里说出来真有意思。"
    show reuben n smi with dis
    reu "我不是偷懒。我只是慢慢来而已。"
    no "....."
    "诺亚尴尬地站在自己房间里，像个陌生人一样，看着另外两个人像一对夫妻一样争论不休。"
    play sound knock
    "他短暂地想是否应该离开，去凯恩家，但突然响起的一声响亮的敲门声让他停住了脚步。"
    m "学习进展怎么样？"
    show asher n neu with dis
    ash "很好，妈妈。你不用来检查我们-我会确保诺亚这次好好学习的。"
    show noahteen n ang with dis
    no "我一直在学习。我不{i}需要{/i}家教。"
    m "仍然不知感恩，我看出来了。好吧，我给你带了一些零食来帮助你。"
    "鲁本比诺亚想象中更快地从床上跳了起来。到目前为止，他似乎更像是一只树懒而不是别的什么。"
    "他带着微笑从母亲手中接过食物，放到了桌子上。"
    reu "谢谢您，女士。这会很有帮助的。"
    m "也不要让他们拖你的后腿，鲁本。亲爱的，没有父母的你一定要做很多额外的学习。"
    show reuben n neu with dis
    reu "..."
    show asher n fro with dis
    ash "妈妈。"
    m "怎么了？我只是在说啊！"
    ash "我们很忙，好吗？"
    m "艾许——"
    ash "我们为什么不去买些饮料配这些零食呢？"
    hide asher with dissolve


    "艾许跳了起来，把母亲赶出了房间，回头向鲁本投去了歉意的一瞥。"
    show noahteen n sad with dis
    "随之而来的沉默比应付艾许烦人的声音还要糟糕。"
    "诺亚在原地来回踱步，不安地想着独自和一个陌生人在一起，更不用说那个人还是艾许的朋友了。"
    show noahteen n neu with dis
    no "对不起，是我妈妈。"
    "鲁本耸了耸肩，又拿起了书。"
    reu "她说得不错。"
    nothought "我怎么才能摆脱这种处境呢..."
    nothought "没有地方可逃..."
    "没有看到逃避这个问题的办法，诺亚只是把背包放下，拿出作业本和素描本，坐在桌子旁。"
    "他偷偷看了看艾许留下的摊开的教科书。"
    nothought "妈妈确实想让他当医生或者别的什么吧？"
    nothought "这看起来很难..."
    reu "你不觉得这看起来像是另一种语言吗？"
    "鲁本的声音从诺亚的床上传了过来。他仍然没有从手中的书上移开视线，这本书是在艾许和他妈妈离开房间后他重新拿起的。"
    no "有点...看起来很难。"
    reu "如果你整个过程都在讨厌它，那我看不出读书有什么意义。"
    reu "而且艾许肯定也讨厌这些书。"
    no "他...告诉你了吗？"
    reu "我只是能感觉到。"
    nothought "你怎么能从你的书里感知到周围发生的事情呢？"
    "诺亚翻阅着素描本，尽量用自己的画作来分散注意力。他今天早些时候画的那幅学校周围的山脉是最近几天他画的最后一件作品。"
    "他确实一直很分心。"
    nothought "如果我把这个整理好...也许我可以试着画一幅画...然后我可以把它送给卢卡。"
    nothought "呃，我不想给他任何东西...但是..."
    nothought "我不能让他伤害奥古斯特..."
    show reuben n sur with dis
    reu "你画的这个吗？"
    show noahteen n sur with dis
    no "哇！"
    "诺亚吓了一跳，像受惊的小鹿一样在原地跳了起来，被鲁本突然的声音吓到了。"
    "他终于从床上起来，坐在了诺亚的身边，俯视着他的素描。"
    reu "对不起，我不是故意吓到你的。"
    reu "但这是你画的吗？"
    show noahteen n neu with dis
    no "啊...是的。"
    reu "我能看看吗？"
    "诺亚犹豫地把本子递给鲁本，有好几个原因。"
    "作为艾许的朋友，很难说他会对此做出什么反应——而且上次他把本子给别人的时候，他犯了一个错误，给了卢卡足够的材料来勒索他。"
    "鲁本翻阅着页面，眉头几乎皱起来，专注地看着。他在某些图像上停留了很长时间，在另一些图像上也停留了很久。"
    "最终，他把本子还给了诺亚。"
    show reuben n smi with dis
    reu "你真的很擅长。"
    no "谢谢..."
    reu "艾许告诉我你在绘画方面很出色，但我没想到你这么厉害。"
    show noahteen n sho with dis
    no "他说我擅长绘画...？"
    reu "是的。他有时会提到你。"
    show noahteen n sca with dis
    "诺亚皱了皱眉。这从来都不是什么好事。"
    show reuben n sur with dis
    reu "不是说坏话。关于你的绘画，或者你的学习...很多事情。"
    no "哼..."
    no "这可不像他。"
    show reuben n neu with dis
    reu "你什么意思？"
    no "艾许从来{i}没有{/i}什么好话说我。"
    show noahteen n ang with dis
    no "如果他有，那肯定是在撒谎。"
    no "他把我以前的所有绘画书都扔进了河里，就是为了好玩。他侮辱我，骚扰我，破坏我的东西..."
    no "他总是对我指手画脚——谈论我的学习，谈论我的艺术——所以我一点也不相信他会对你说什么好话。"
    "诺亚停下来哼了一声，立刻后悔自己刚才说的话。"
    show noahteen n sca with dis
    no "我是说——"
    show reuben n fro with dis
    reu "..."
    show reuben n neu with dis
    reu "这是真的吗？他真的都这样做了？"
    no "是的。他讨厌我。"
    reu "..."
    reu "所以他对我撒了谎。"
    "鲁本的脸上完全没有表情，平静地回答诺亚。不知为什么，尽管艾许对他的态度很差，但他突然感到有些内疚。"
    show noahteen n sho with dis
    no "呃...我不知道。我只知道他不喜欢我。"
    reu "..."
    reu "对不起。关于你的艺术书的事。"
    reu "这不太好。"
    show noahteen n neu with dis
    no "...是的，谢谢。"

    show asher n neu at left
    with dissolve

    play sound doorclick
    "房间的门又开了，艾许拿着两杯饮料回来了。他把它们放在桌子上，把其中一个杯子稍微推近了鲁本。"
    reu "..."
    reu "你没给诺亚拿一杯吗？"
    ash "我不是他的私人仆人。他自己去拿喝的吧。"
    reu "..."
    reu "对不起，我得走了。"
    show asher n sur with dis
    ash "什么？我以为你会留下来——"
    reu "我会给你发短信的。"
    "鲁本收拾好书包，背上背包，迅速离开了房间。"
    hide reuben with dissolve
    show asher n sur at slightleft
    show noahteen n neu at slightright
    with move

    ash "等等，鲁本——"
    show asher n fro with dis
    ash "你做了什么？"
    "艾许眯起眼睛，眉头紧锁，怒视着诺亚。"
    no "为什么是我的错？我什么都没做。"
    ash "啊，随便吧。"
    "艾许抓起所有的书，冲出了门，追着鲁本跑去。"
    hide asher with dissolve
    show noahteen n neu at center with move
    no "..."
    no "他们怎么了..."


    scene bg bedroom night
    show rain:
        zoom 0.8
    show bedroomnight_overlay

    $all_moves(camera_check_points={u'y': [(665, 0, u'ease')], u'x': [(2082, 0, u'ease'), (-5854, 25.68, u'ease')], u'z': [(942, 0, u'ease')]})
    with dis
    "外面，太阳刚刚落山；透过窗户照进来的余晖现在已经完全消失了。诺亚的目光转向对面的窗户，百叶窗已经拉上了。"
    "好像在某个时候开始下雨了。水滴有节奏地敲打着他的窗户。"
    "虽然还不算很晚，但诺亚感觉自己很想立刻睡觉，即使这意味着要错过晚餐。他只想让明天快点到来。"
    "他从来没有谈过恋爱——甚至在奥古斯特之前，他也从未对别人有过什么特别的感觉。"
    "除了奥古斯特，没有别人曾引起过他的注意或让他有兴趣去追求。"
    "他坐在床上，紧紧抱着一个枕头，思考着最近发生的一切。"
    nothought "奥古斯特和我现在...在约会了..."
    nothought "还有卢卡的事..."
    nothought "还有...那些梦..."
    "在过去几天发生的所有事情中，他还没有时间真正坐下来思考发生了什么。"
    nothought "我进入了别人的梦境。一个梦。"
    nothought "怎么会？为什么？"
    nothought "难道我有超能力或什么的吗？"
    stop music fadeout 3.0
    "咚。咚。咚。"
    noteen sur "...?"
    "诺亚竖起耳朵，听到窗户传来轻轻的敲打声。他跳起来，快速但安静地打开了窗户。"
    nothought "奥古斯特...？"
    "但出现在窗外的不是他期望和预料中的奥古斯特，而是另一个人。"
    play music autumn fadein 4.0
    noteen sur "...凯恩？"
    noteen "你在那里做什么？"
    kteen sad "...这是个长故事。"
    kteen sad "我只是想问，呃..."
    kteen sad "我可以...进来吗？"
    noteen neu "当然可以。"
    kteen sad "...谢谢。"

    scene bg bedroom night
    show rain:
        zoom 0.8
    show bedroomnight_overlay
    show kaineteen n sad at slightright
    $ camera_reset()
    $all_moves(camera_check_points={u'z': [(365, 0, u'linear')]})
    show noahteen n neu at slightleft
    with dissolve

    "诺亚让开身子，让凯恩爬进窗户。他轻松地爬上了房子旁边的树，诺亚不禁有些嫉妒。"
    "他带进来了一些水，看起来完全湿透了。"
    nothought "难道他整晚都在外面淋雨吗？"
    show kaineteen n sad with dis
    k "希望没有把地毯弄得太湿..."
    no "没关系。你觉得我现在在乎地毯吗？"
    k "也许你不在乎，但你妈妈会..."
    no "我可以编造一些借口。"
    show noahteen n sad with dis
    no "我猜你不想让你妈妈知道你来这里，所以没有从正门进来？"
    k "你猜得对。"
    k "我现在...不太想和任何人说话。"
    no "除了我以外？"
    k "你很特别。"
    no "好的..."
    "听到这些话，诺亚感到胃里有一种奇怪的跳动——一种让他困惑的跳动。没有理由为此感到高兴，但不知为何他还是这样感觉了。"
    show noahteen n sho with dis
    no "不过说真的，发生什么事了？你看起来...很糟糕。"
    show kaineteen n pou with dis
    k "好吧，谢谢。"
    "凯恩轻声笑了。"
    k "我知道我总能依靠你来振奋我。"
    show noahteen n neu with dis
    no "随时都在。"
    show kaineteen n sad with dis
    k "....我今晚能在这里住下吗？拜托？"
    "凯恩的声音听起来很勉强——勉强而绝望。"
    no "...好吧。当然你可以在这里住下。"
    k "谢谢。"
    no "...我猜你不想让我去给你拿我妈的备用床垫。"
    k "不...不要告诉任何人我在这里...拜托..."
    show noahteen n sad with dis
    no "..."
    nothought "发生什么事了...？"
    nothought "他在学校的时候就很奇怪，现在更奇怪了..."
    show noahteen n neu with dis
    no "好吧...好吧，当然。"
    "诺亚关上窗户，把它牢牢锁上。"
    show kaineteen n neu with dis
    k "我会睡在地板上。没问题的。"
    show noahteen n sho with dis
    no "什么？别傻了。你可以用我的床。"
    show kaineteen n sad with dis
    k "..."
    k "这真的可以吗？"
    show noahteen n neu with dis
    no "为什么不可以？"
    k "嗯，就是...你知道的。"
    k "你现在{i}正在{/i}和别人约会。"
    no "那又怎样？"
    show noahteen n sho with dis
    no "这不会改变我们之间的任何事。你仍然是我最好的朋友。"
    show noahteen n neu with dis
    no "我相信奥古斯特会理解的。"
    k "你不觉得他是个很容易吃醋的人吗？"
    no "如果他是这样，我也不会这么喜欢他。"
    show kaineteen n fro with dis
    k "...是啊。这说得很有道理。"
    show kaineteen n neu with dis
    k "那么，如果你不介意的话..."

    hide noahteen
    hide kaineteen
    with dissolve
    "没有再说一个字，凯恩爬进了诺亚的床，留下这个黑发男孩困惑地站在房间里。"

    scene bg bedroom night2
    show rain:
        zoom 0.8
    show bedroomnight2_overlay
    $all_moves(camera_check_points={u'y': [(2769, 0, u'ease')], u'x': [(168, 0, u'ease'), (-6000, 24.59, u'ease')], u'z': [(1066, 0, u'ease')]})
    with dissolve
    "不确定在这种情况下该做什么，诺亚关掉了灯，爬进床里，面朝天花板。他们两个都没有说话一段时间。"
    "凯恩静静地躺在那里，双臂环抱着膝盖。诺亚不知道他是否已经睡着了。"
    "就在他快要睡着的时候，身边的黑暗中传来一个轻声的声音。"
    kteen sad "嘿，诺亚..."
    kteen "即使我是个坏人，你也会做我的朋友吗？"
    noteen sur "什么...？"
    "诺亚看不到凯恩的表情——他背对着自己——但他的声音听起来...很勉强。就像他正在勉强维持住。"
    noteen "你不是个坏人，凯恩。"
    kteen "..."
    noteen neu "但是，即使你是，我也会一直做你的朋友，不管发生什么。"
    nothought "我想问问他关于卢卡的事...但这样做只会承认卢卡对我有什么把柄..."
    kteen "你有没有觉得..."
    kteen "你在这个世界上完全孤独？"
    "诺亚深吸了一口气，感受到凯恩话语的重量。"
    noteen sad "有时候，我想是吧..."
    noteen neu "但是我们还有彼此，不是吗？"
    kteen "是啊...是啊，我想是这样..."
    kteen "我只是..."
    kteen "我不知道如果没有你，我该怎么办，诺亚。"
    noteen "好吧，我不会离开的。"
    noteen "希望你也不会离开？"
    "沉重的寂静充满了空气，只有他们的呼吸声和偶尔的床单沙沙声打破了这种寂静。"
    "窗户上雨点的敲打声充满了房间，这种熟悉的声音让人感到安慰。"
    "诺亚转头看着凯恩，后者已经在看着他。他的眼睛里既有悲伤，又有一种诺亚无法确定的情绪。"
    noteen "凯恩...？发生什么事了吗？"
    kteen "..."
    "诺亚等待着回应，但没有得到。凯恩的呼吸平稳均匀，眼睛也移开了。"
    noteen "你现在不想说也没关系。我不想逼迫你..."
    noteen "但是你知道，我{i}一直{/i}在这里支持你。"
    kteen "...谢谢你，诺亚。"
    "诺亚点了点头，感到庆幸凯恩没有完全把自己关在外面。"
    nothought "我发誓我们以前什么都会告诉对方。"
    nothought "看看我们现在的样子。"
    nothought "我们都有秘密，而且我们都知道。"
    "雨声不断敲打着窗户，现在还伴随着远处雷声的隆隆。房间里很黑暗，只有偶尔的闪电照亮了这个空间。"
    "诺亚无法确切地说出发生了什么变化，但他感觉他们之间正在产生距离。好像凯恩在自己周围建起了一堵墙，而诺亚不知道如何拆除它。他想帮助他的朋友，但不知道如何接近他。"
    nothought "但我能说什么呢？我也有很多没告诉你的事。也许我才是那个筑起墙壁的人。"
    kteen "...我父母要离婚了。"
    noteen sur "什么...？"
    noteen "我很抱歉，凯恩。我没有意识到..."
    kteen "我也没有，直到今天。这事发生得太突然了。"
    kteen "就在前几天，一切还..."
    kteen "好吧。并不算好-我爸爸已经{i}很久{/i}不在家了-但我妈妈和我还是相处得还不错。"
    kteen "我们还好..."
    kteen "但是...我爸爸出轨了。把我妈妈扔在一边，就像她什么都不是。"
    noteen "哦，操。这真是..."
    noteen sad "太他妈糟糕了。"
    kteen "我妈妈知道后简直崩溃了，但我爸爸..."
    kteen "他甚至都没试图找借口。他对此冷淡得让人有些..."
    kteen "我不知道。"
    kteen "令人不安。"
    kteen "就好像他根本不在乎。"
    kteen "而我妈妈..."
    "凯恩深吸了一口气，诺亚不用问他妈妈是怎么接受这个消息的。"
    kteen "...我想我妈妈可能会留下这栋房子。"
    kteen "我爸爸听起来对打官司没什么兴趣。他够有钱，可能也不用太担心这个。"
    kteen "我不会觉得奇怪，如果他搬走了。"
    noteen "...我明白了。"
    noteen neu "那你呢？"
    kteen "...当然，我会留在这里。"
    kteen "我不想离开你。"
    kteen "只是..."
    kteen "这整件事让我开始思考..."
    kteen "爱情真的值得吗？"
    kteen "爱情到底存在不存在..."
    kteen "还是人们只是在装模作样：假装\"爱\"有什么意义，其实它什么都不是？" #edit this line it looks weird
    kteen "我知道我妈妈爱我..."
    kteen "...她也很崇拜我爸爸。"
    kteen "但我不认为他也同样崇拜她。也许在他们年轻的时候，他是这样的..."
    kteen "但那已经是很久以前的事了。"
    kteen "他已经走开了，但我妈妈..."
    kteen "她从未放下。"
    kteen "到头来，{i}这{/i}就是所谓的爱情吗？"
    kteen "就是等待你最在乎的人抛弃你？"
    "诺亚感到喉咙发紧。他从来不擅长处理这种对话或情况-他不知道该说什么来让一切变好。"
    "尽管他很清楚，他说什么都无法让一切变好。"
    noteen sad "我认为...爱情可能很复杂，但是..."
    noteen "如果你找到了合适的人，那它就是真实的。"
    noteen sad "你不能因为它可能有一天会结束就放弃它。"
    "凯恩看着诺亚，在他的脸上寻找着什么。诺亚无法判断那是接受还是怀疑，但他希望自己能够说服他的朋友。"
    kteen "但如果它已经结束了，你还在抓着一些不存在的东西呢？"
    noteen "那也许是时候放手，向前看了。"
    noteen "我...我真的很抱歉你的父母，但是..."
    noteen neu "也许他们这样会更快乐？"
    kteen "..."
    kteen "是的...是的，我知道你说得对。"
    kteen "对不起。我只是...我想，我很害怕。"
    kteen "我害怕...独自一个人。"
    kteen "这事发生了，然后...其他很多事情也发生了，而且..."
    kteen "感觉就像我被活埋了，独自一个人。"
    noteen "我理解..."
    noteen "但你并不孤单。"
    noteen "我永远都在这里。"
    "凯恩的声音在最后回应时变得很轻。"
    kteen "我希望如此。"
    "雨水继续敲打着窗户玻璃，房间里弥漫着沉重的寂静。"
    "诺亚不确定还能说些什么——但很快凯恩就翻了个身，不愿再多说一个字，诺亚也决定做同样的事。"
    "当他的意识渐渐远去时，远处隆隆的雷声在房间里回荡，这是对凯恩话语的沉重意味以及未来不确定性的一种阴郁提醒。"
    stop music fadeout 3.0
    scene bg bedroom day with Fade(1.0, 2.0, 1.0):
        subpixel True xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.72 rotate None
        parallel:
            xpos 0.5
            ease 22.03 xpos 0.84

    noteen neu "嗯..."
    play music thiscloud fadein 4.0
    "从窗户照进来的温和光线最终唤醒了沉睡中的诺亚。他翻了个身，查看手机——早上8点。"
    nothought "天哪，我真的很累..."
    noteen neu "早上好，凯恩。"
    "沉默随之而来。"
    noteen neu "凯恩？"
    "诺亚翻过身去，发现身边的床位空空如也。"
    nothought "哦，看来他已经离开了...我睡过头了。"
    nothought "不过，通常他都会把我叫醒的..."
    nothought "好吧，我最好赶快起床，不然就要迟到上学了..."


    scene bg bedroom day with dissolve:
        subpixel True xpos 0.24 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.71 rotate None
        parallel:
            ypos 0.98
            ease 12.97 ypos 1.33

    "诺亚伸了个懒腰从床上跳下来，对错过送别凯恩的时刻感到一丝内疚。前一晚的对话在他脑海中回放。"
    nothought "没事的...我到学校后会去看看他。"
    "他迅速穿上校服，冲出了房间。如果他够快的话，就不会迟到。"

    scene bg livingroom day with Fade(1.0, 1.0, 1.0)

    m "你在这里啊，诺亚。"
    noteen neu "对不起，我得走了——"
    m "还记得我们昨天谈过的那件事吗？"
    noteen sca "我要迟到了！"
    "诺亚把背包甩到肩上，手握住门把手。"
    m "放学后——"
    noteen sca "再见！"

    scene bg mountains day with swipe
    pause 0.5
    scene bg town day with swipe
    pause 0.5
    scene bg classroom day with swipe



    noteen sca "..."
    "诺亚在上课铃声响起时刚刚到达学校。他环视教室，每个座位都坐满了人，除了他自己的座位...以及凯恩的。"
    "他在罗丝小姐出现之前迅速走到奥古斯特的桌前。"
    noteen neu "你有看到凯恩吗？"
    "奥古斯特摇了摇头。"
    a neu "他没来..."
    a sad "你觉得出了什么事吗？"
    noteen sad "我不知道...他昨晚还在我家，但在我醒来之前就离开了..."
    "奥古斯特的脸上满是担忧。"
    a sad "我们要不要推迟一下之前打算做的事？我们可以去看看他怎么样。"
    nothought "也许他只是需要一些时间...也许是在处理家里的事情..."
    noteen neu "不...不，我想他只是需要一些空间。我觉得他可能在处理家庭问题。"
    a sadsmi "好吧...我还是给他发个短信吧。"
    a neu "对了，我中午要去眼科医生那里——所以今天放学后我们不能一起回家。但我们晚点还是会在家附近碰头！"
    "诺亚点了点头。尽管他对约会感到兴奋，但内心却不由自主地涌起了焦虑。"
    "究竟是为什么，他也说不清。"
    "总有种不太对劲的感觉。"
    noteen neu "....奥古斯特？"
    a neu "嗯？"
    noteen sad "..."
    noteen neu "...考试快到了。你想一起复习吗？"
    "奥古斯特脸上露出了笑容。"
    a hap "对啊！"

    scene bg classroom day with Fade(1.0, 1.0, 1.0):
        subpixel True xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.87 rotate None
        parallel:
            xpos 0.9
            ease 24.51 xpos 0.04

    "时间飞快地过去了。诺亚一直望着窗外，看着太阳升起又落下，但他的思绪却一直飘忽不定。"
    "奥古斯特中午离开了，很快放学铃声响起，诺亚只能独自回家。"
    "没有凯恩和奥古斯特的陪伴，让他内心感到一种空虚。他一直是个独来独往的人——在遇到凯恩之前，他连一个朋友都没有，但这并不影响他。"
    "但现在，这种寂静让他感到格外空虚。"
    stop music fadeout 3.0
    "他收拾好书本，装进背包，然后背起背包离开了教室。"

    scene bg mountains rain
    show rain
    with Fade(1.0, 1.0, 1.0)
    play music2 raining fadein 3.0
    play music reflections fadein 3.0
    "某个时候一场暴风雨席卷而来，雨水把通往家的山路变成了一片泥泞。诺亚小心翼翼地一步一步爬上陡峭的山路。"
    "狂风呼啸，雷声隆隆，在树林中回荡成一曲震耳欲聋的合唱。"
    nothought "之前还是晴天的..."
    "诺亚既感到寒冷，又感到内心的不安。这种不安感从前一天看到凯恩和卢卡在一起时就一直存在。"
    "但他还是坚持往前走，决心在彻底淋湿之前回到家。"
    "当他越爬越高，暴风雨也越来越猛烈。狂风呼啸，雨点打在他的脸上和衣服上。闪电划过，短暂地照亮了前方的道路。"

    scene bg town day rain:
        subpixel True xpos 0.91 ypos 1.34 xanchor 0.5 yanchor 1.0 zoom 1.91 rotate None
    show rain
    with Fade(1.0, 1.0, 1.0)

    "终于，他到达了家门口，气喘吁吁，浑身湿透。他用冰冷的手指摸索着钥匙，终于打开了门，走进了屋内。"
    "温暖的房子包围了他，他长舒了一口气。"
    "但这种温暖并没有持续太久。"

    stop music2 fadeout 3.0
    scene bg livingroom day with Fade(1.0, 1.0, 1.0)

    m "你终于回来了，诺亚——你把地板都弄湿了！快去拿条毛巾，然后赶快下来。"
    "诺亚的目光转向坐在客厅里的母亲，她一条腿交叠在另一条腿上，父亲坐在她旁边。"
    "除了他们，客厅里还坐着其他四个人，其中两个是他从未见过的——一个留着短发、穿着整洁西装的成年男子，以及一个穿着及膝黑色连衣裙的女士。"
    "但让他感到胃部下沉的是他认出的两个人。卢卡转过身无声地挥手，嘴角挂着一个让诺亚想起蛇的微笑。坐在他旁边的是一个有着长长粉色头发的女孩——诺亚在学校里认识她。"
    m "诺亚，别呆呆地站在那里...亲爱的，我去和他说几句话。"
    "她从那群人中脱身，迅速抓住诺亚的胳膊，把他拽进了卧室。"

    scene bg bedroom night
    show rain
    show bedroomnight_overlay
    with Fade(1.0, 1.0, 1.0)

    noteen sur "发生什么事了——他们是谁...？"
    m "那个，诺亚，就是你父亲的老板和他的家人。快，擦干自己，我们回到楼下去。"
    "诺亚从口袋里掏出手机，看了看时间。他很快就要和奥古斯特见面了。"
    noteen sur "不，我...我要和凯恩出去，我不能—"
    m "这很重要。你哪里也不能去。"
    noteen ang "我要去！我已经安排好和他见面了—"
    "他的母亲从他手里抢过手机，塞进了自己的口袋。"
    noteen ang "嘿！"
    m "并不是所有事情都是关于你的。这次，请为你的家人做点努力。"
    noteen ang "把它还给我...！"
    m "不。如果你在他们走之前在楼下表现好，你就可以拿回手机。"
    noteen ang "至少让我先发个短信...！"
    m "不。"
    m "如果你想在我们结束之前离开，那就忘了以后见到凯恩吧。你明白吗？"
    noteen ang "....."
    "她转身离开了房间，留下愤怒的诺亚在擦干自己的衣服。"
    nothought "没事。没关系。我相信他们很快就会走，那时我就可以出去了。"
    "虽然还有些湿润，但已经不像之前那么湿透了，诺亚走出卧室，关上门，走进了客厅。"

    scene bg livingroom day

    show noahteen n neu at left:
        xpos 0.14 ypos 1.0 yanchor 1.0
    show luka n smi at center:
        subpixel True xpos 0.71 ypos 1.0 xanchor 0.5 yanchor 1.0 rotate None
    show rosamie n neu at right
    with Fade(1.0, 1.0, 1.0)

    fb "我必须说——你们两个的房子真漂亮。我很impressed。"
    fb "啊，这一定就是诺亚了。"
    "父母严厉的眼神迫使他挤出了一个笑容。"
    show noahteen n hap with dis
    no "...嗨。很高兴认识你。"
    show luka n hap with dis
    l "耶，诺亚！我好高兴见到你。"
    show noahteen n neu with dis
    no "....."
    fb "哦？你们两个认识吗？"
    l "我们实际上是非常好的朋友。对吗，诺亚？"
    show noahteen n sad with dis
    no "...是的。最好的朋友。"
    f "希望我们的诺亚没有给你们添什么麻烦。"
    no "嘿-"
    l "实际上，他帮了我们好多忙！"
    show luka n smi with dis
    l "多亏了他，我进步了好多。哇，他什么都很擅长！"
    nothought "如果他提到那个愚蠢的艺术俱乐部，我就杀了他。"
    "卢卡眼中闪烁着一丝狡黠，显然他知道诺亚不想让家人知道这件事。诺亚紧紧地闭上了嘴。"
    nothought "看来他们没有强迫艾许来。为什么偏偏是我？"
    fb "哈！太好了。看来你的儿子和你一样有奉献精神和动力！"
    "两个男人大笑起来，他们的妻子在一旁咯咯地笑着。"
    nothought "这一切都感觉如此虚假。全都是假的。"
    nothought "爸爸想要晋升，他的老板知道这就是全部的目的...这一切都只是戏剧表演。"
    m "但我想诺亚和罗莎米还没有正式认识，是吗...？"
    "他的母亲看向他。"
    no "...没有，我想没有。"
    nothought "除了在学校里偶遇过她..."
    "罗莎米向他投来一个与上次见面时截然不同的微笑。"
    show rosamie n smi with dis
    r "很高兴认识你，诺亚。我在学校里见过你，但我们不在同一个班。"
    "她的声音丝滑柔和，衣服一丝不苟。她的妆容完美无缺，每一缕头发都恰到好处。"
    "总之，称她为\'完美\'可能也不为过。"
    nothought "我很惊讶他们会让她染发。"
    fb "我听说过你的优异成绩，诺亚。我很impressed。你打算在高中毕业后做什么？"
    "他不需要看向父母，就能感受到他们刺人的目光。"
    nothought "我只想要回我的手机..."
    no "我...打算上大学，学习商科或法律。"
    nothought "天哪，我想不出有什么比这更糟糕的了。"
    fb "很好。我相信你无论选择哪个都会做得很出色。"
    fb "你只需要放弃那个艺术，你就会成为一个很不错的对象了，对吧？"
    show noahteen n sca with dis
    no "..."
    show luka n hap with dis
    show rosamie n ann with dis
    "卢卡对他露出了一个得意的笑容，而罗莎米似乎也暂时放下了伪装，翻了个白眼。其他成年人都大笑起来，好像他说了一个最好笑的笑话。"
    show rosamie n neu with dis
    nothought "在你们眼里，我只是个笑话..."
    "从厨房传来一阵铃声，诺亚的母亲立即站了起来。"
    m "火鸡好了——我们准备开饭吧？"
    m "诺亚，你能带罗莎米参观一下房子吗，我去摆桌子？"
    no "..."
    r "那太好了，谢谢。"
    "她完美地对诺亚微笑。她的一切都像是那样——精确而完美。"
    nothought "为什么偏偏是我..."
    no "...好的。"
    "诺亚望向窗外。太阳已经快速穿过风雨交加的天空，与奥古斯特会面的时间也即将到来。"
    nothought "该死，我真希望我能告诉他...我不想让他在暴风雨中等待..."
    nothought "再等一会儿...然后我就可以去了..."
    hide luka
    hide noahteen
    hide rosamie
    with dissolve
    "卢卡撅着嘴看着这对情侣离开，诺亚对这个罗莎米并不太确定，但至少把卢卡留下是件好事。"
    "她微笑着跟在他身后，他向她展示了房子里的各个房间。她不时进行一些闲聊，但在父母耳朵范围内，她只说了一些恭维的话。"
    noteen sad "我想我可以带你参观我的房间..."
    m "诺亚，把门留开！"
    noteen sca "..........."


    scene bg bedroom night
    show rain
    show bedroomnight_overlay
    show noahteen n sad at slightleft
    show rosamie n neu at slightright
    with Fade(1.0, 1.0, 1.0)

    no "...这就是我的房间，我想。不过我不太明白你为什么会想看它。"
    show rosamie n ann with dis
    r "因为我{i}不{/i}想看它。"
    "她翻了个白眼。"
    show noahteen n sho with dis
    no "那个善良女孩的表演怎么了？"
    show rosamie n neu with dis
    r "别自作多情了。我来这里是因为我爸爸要我来——仅此而已。"
    r "我对和你结婚没有兴趣。"
    show noahteen n neu with dis
    no "好，因为我也不想和你结婚。"
    "诺亚坐在办公桌前的椅子上，转了一圈，而罗莎米则坐在他床边的边缘，叹了口气，把头埋在手里。"
    show rosamie n neu with dis
    r "我们要不要做个交易？"
    no "交易？"
    r "你妈妈强迫你来这里，对吗？"
    show noahteen n sca with dis
    no "这么明显吗？"
    show rosamie n smi with dis
    r "非常明显。"
    r "那就装作我们在约会吧。"
    show noahteen n sur with dis
    no "什么...不，为什么要这样做—"
    show rosamie n neu with dis
    r "这样可以让你的父母放你一马。"
    show rosamie n ann with dis
    r "我打算在年底离开这个愚蠢的乡下小镇，但如果我的父母现在切断我的经济来源，我就无法做到。"
    r "所以我们为什么不互帮互助呢？"
    no "..."
    r "你已经有约会对象了，对吗？"
    show noahteen n sho with dis
    no "我...是的。"
    r "你可以用我作为掩护，去见他们。"
    nothought "嗯...我想这也不是个坏主意...不过我当然要告诉奥古斯特这件事..."
    show noahteen n neu with dis
    no "那你呢？你也有约会对象吗？"
    r "...没有。不过我喜欢一个人。"
    no "为什么要费这么大劲？为什么不直接告诉他们你想和他结婚呢？"
    show rosamie n ann with dis
    r "因为{i}他{/i}不是个男人，白痴。"
    show noahteen n sho with dis
    "诺亚惊讶地眨了几次眼睛。"
    show rosamie n neu with dis
    r "现在你知道我的秘密了。你能相信我吗？"
    show noahteen n sur with dis
    no "..."
    show noahteen n sad with dis
    no "好吧。行，我们达成交易。"
    "雨和风拍打着窗户，太阳开始从天空中下降。"
    show noahteen n neu with dis
    no "那就帮我掩护一下。我需要离开这里，去从我妈妈那里拿我的手机。"
    r "....."
    r "好吧。但你欠我一个人情，明白吗？这可不容易。"
    show noahteen n hap with dis
    no "交易成。"
    r "待在这里。我有个主意。"

    scene bg livingroom day with Fade(1.0, 1.0, 1.0)

    m "你在这里啊。你参观得开心吗？诺亚呢？"
    r smi "非常棒，夫人。诺亚真的是个很好的主人。他实际上是去休息了——他说他不太舒服。"
    m "哦？那我希望他待你很好。"
    r smi "实际上，如果您不介意的话，我真的很想给诺亚我的电话号码，但他说他没有手机..."
    fb "哈哈哈。这就是我的罗莎米——总是个前瞻性的思考者！"
    m "当然！那我能拜托你把这个带给诺亚吗？"
    "罗莎米微笑着，脸上带着天使般的神情。"
    r smi "我会去给他，并确保他没事。我应该给他带些食物吗？"
    m "罗莎米，亲爱的，你真的会成为一个完美的妻子。这个，你可以拿去给他。"
    "拿着一盘食物和诺亚的手机，罗莎米转身离开了这群人，脸上带着得意的笑容。"
    "但在她离开房间之前，卢卡挡在了她的面前。"
    l ann "你在撒谎。"
    r ann "让开，loser。"
    l ann "我会告诉妈妈的。"
    r smi "我不知道你在说什么。"
    l smirk "如果你不想我这么做，那就告诉诺亚，他欠我一些明天要完成的艺术作品。"
    r ann "..."
    "罗莎米嗤之以鼻，然后不耐烦地绕过卢卡。"

    scene bg bedroom night
    show rain
    show bedroomnight_overlay
    with Fade(1.0, 1.0, 1.0)

    "罗莎米把手机在诺亚面前晃了晃，然后把它扔进了他的手里。他惊讶地看着它。"
    r smi "你现在可以感谢我了。"
    noteen sho "我想我更害怕你而不是其他任何事物..."
    r smi "很好。"
    r neu "我也给你安排了今晚的掩护。不过你可能不想从正门出去。"
    r neu "哦，我还把我的号码存进去了。以防你需要我帮忙掩护你。"
    r neu "只是别忘了你的那部分交易。"
    noteen neu "我不会忘的。"
    r neu "很好。"
    "诺亚立刻找到了奥古斯特的联系方式，打了一条消息，道歉并解释了发生的事情。"
    "他迅速补充说，既然天气这么糟糕，他们可以改天出去。"
    r ann "哦，卢卡让我告诉你一些事情。"
    "诺亚僵住的事实没有逃过罗莎米的眼睛。"
    r neu "所以，他对你有什么把柄，嗯？"
    noteen sca "我..."
    noteen sca "是的，不幸的是。"
    nothought "她告诉了我关于她自己的事...我想我可以相信她。"
    noteen sca "..."
    noteen sca "我...有一个男朋友。"
    "她的眼睛立刻眯了起来。"
    r sad "他是个小蛇。很抱歉。"
    r ann "他说要明天带艺术品来，不知道是什么意思。"
    noteen sad "呃...好吧，行。"
    "每一次没有收到回复的短信，诺亚都感到越来越焦虑。无法再坐着等下去，诺亚打开了窗户，风雨拍打在他的脸上。"
    r neu "你可能需要带把伞。"
    noteen neu "我不知道就算带把伞也能有什么帮助..."
    "不过，诺亚还是拿起了背包和一把伞，从窗户走了出去。"
    r neu "祝你好运。"


    scene bg mountains night:
        subpixel True xpos 0.52 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.48 rotate None
        parallel:
            ypos 1.48
            ease 24.79 ypos 1.07
    show rain
    with Fade(1.0, 1.0, 1.0)

    play music2 raining fadein 3.0

    "自从他离开学校后，暴风雨只是越来越严重，风声像一群女妖在嚎叫。"
    "他几乎什么也看不清，湿冷的感觉再次渗入了他的衣服。"
    "伞在风中只坚持了几分钟就被吹坏了，变得毫无用处。"
    "诺亚叹了口气，把它扔到一边，知道现在再修也没用了。"
    nothought "我等会儿再来拿它..."
    "他艰难地沿着陡峭的山路走下去，脚下湿滑的岩石让他一再打滑。他小心翼翼，但还是忍不住想到自己正在做的事有多危险。"
    "不过也没什么选择-奥古斯特还是没有回复，而他们原定的见面时间已经过去至少一个小时了。如果他在这暴风雨中等着..."
    "诺亚继续向前，脚下的水流让本就滑溜的路更加危险。他几次差点摔倒，但还是设法保持了平衡。"
    "暴风雨的轰鸣淹没了所有其他声音，让他什么也听不到，只有呼啸的风声。"
    nothought "奥古斯特，你在哪里..."
    "当他继续沿着小路前进时，他不由得感到一种不安。"
    "他独自一人在暴风雨中，除了呼啸的风雨声外什么也没有。暴风雨的黑暗让他只能看到眼前的环境，寒冷的湿气让他不住发抖。"
    "当他到达山路底部时，他的心沉了下去。"
    nothought "我一定是错过了他...或者他已经回家睡觉了？我应该先去他家看看的..."
    "即使在暴风雨中，溢出的河水声也能被听到，当诺亚转身望向黑暗时，他不禁打了个寒战。"
    "他大声呼唤奥古斯特的名字，但声音被暴风雨的喧嚣淹没了。"
    "诺亚再次检查手机，但仍然没有任何回复。"
    noteen sca "..."
    "诺亚沿着山路重新走了上去，心中充满了担忧。"
    "他睁大眼睛，四处搜寻奥古斯特的踪迹。雨势已经小了一些，但风却依然很猛烈，吹乱了他的头发。"
    "黑暗笼罩了他，仿佛要把他吞噬殆尽。"
    "他一直把这座山视为家。它是温馨的，充满生机和光明的。"
    "但此刻，它更像是一座充满无尽隧道的墓地，你会永远迷失其中。"
    "不久，他已经艰难地走回了山顶-无论他看哪里，都找不到奥古斯特的踪迹。"
    "他凝视着山下。"
    nothought "我应该...我应该再检查一遍吗？"
    noteen sca "..."
    nothought "不...不，我确定他已经回家了。我只是太担心了。"
    "即使这样告诉自己，他还是感到内心深处有一种不安。"
    "确保没有人在偷看，他爬回了窗户，浑身湿冷。"


    scene bg bedroom night
    show rain
    show bedroomnight_overlay
    with Fade(1.0, 1.0, 1.0)

    "诺亚盯着对面的房间。窗帘紧闭，灯也关着。"
    nothought "看来他已经睡着了..."
    nothought "我明天一定要好好向他道歉..."
    "他打了个寒战，爬上床睡着了，临睡前给奥古斯特发了最后一条道歉。"
    stop music fadeout 3.0
    stop music2 fadeout 3.0


    scene black with dissolve
    "他的梦一开始很安静。"
    "但后来并非如此。"
    "他看到有双手伸向他...一场风暴...有人在呼唤他的名字..."
    "有人...独自一人...痛苦万分..."
    "然后他醒了过来。"


    scene bg bedroom day:
        subpixel True xpos 0.74 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.49 rotate None
    $ camera_reset()
    with Fade(1.0, 2.0, 1.0)

    "诺亚睁开眼睛，猛地坐了起来，心跳如鼓。"
    play music someonessign fadein 4.0
    "不知为何，他感到胃里一阵恶心—就像要站在一个班级前做报告一样焦虑。"
    "他看了看时钟。"
    "还只有早上6点30分。"
    "迫切想摆脱这种奇怪的感觉，无法再睡下去，他跳下床，穿好衣服，走到了客厅。"

    scene bg livingroom day with Fade(1.0, 1.0, 1.0)

    "他的母亲正忙着在厨房，他的父亲坐在那里喝着咖啡准备上班。连艾许也坐在沙发上，无聊地在手机上滑着社交网站。"
    "一切都很安静。"
    "太安静了。"
    noteen neu "早上好..."
    "诺亚的父亲把报纸举得更高，完全无视了他。而艾许则尴尬地转过头，清了清嗓子，然后离开了房间。"
    m "早上好，亲爱的。"
    m "要吃早餐吗？"
    noteen neu "呃...是的，谢谢。"
    "诺亚终于想起了前一晚的事，掏出了手机。"
    "没有从奥古斯特那里收到任何回复，但他有近十个来自凯恩的未接来电。"
    nothought "也许他还没有醒来..."
    "不久，诺亚面前摆上了一盘丰盛的早餐。他慢慢吃着，虽然平时他都会跳过早餐，但今天他特别饿。"
    "胃里的那种不安感就像一块重物压在他身上，他无法摆脱。他一直盯着手机，希望能收到奥古斯特的消息，但仍然没有任何回复。"
    m "吃饭的时候不要玩手机，诺亚。这很没有礼貌。"
    noteen sad "...对不起，我的错。"
    noteen sad "我在等一个朋友的短信...他一直没有回复我，我很担心..."
    "诺亚的母亲皱了皱眉，然后转身继续做饭。"
    nothought "什么...？"
    m "学校怎么样？你不是快要期末考试了吗？"
    noteen neu "还好..."
    noteen sca "关于我的朋友—"
    m "凯恩怎么样？他还好吗？"
    noteen sho "他...他还好。"
    noteen neu "妈妈，你—"
    m "这么晚了？天哪，我得走了—"
    noteen sur "妈妈！"
    m "..."
    noteen sca "你知道什么吗？"
    m "亲爱的，现在就专心学习吧。等你期末考试结束后我再告诉你—"
    noteen sca "告诉我什么？！你知道奥古斯特的什么事？！"
    m "..."
    f "..."
    m "我们告诉过你不要再和他来往了，诺亚。这都是你自己的错。"
    noteen sur "..."
    "他的母亲叹了口气，坐在厨房桌前，盯着她的茶杯。"
    m "昨天晚上很晚，奥古斯特的父亲来找你了。我们让他走了，因为你当时身体不舒服。"
    noteen sur "你应该叫醒我！他想要什么？"
    stop music
    play sound heart fadein 0.5
    show bg livingroom day at transform_invert:
        size (1920, 1080)
        easein 0.25 zoom 1.1
        easeout 0.25 zoom 1.0
    m "奥古斯特昨天出了车祸，可能撑不下去了。"
    scene  bg livingroom day with dis
    play music traintodarkness fadein 4.0
    "诺亚感觉好像地面在他脚下裂开了。世界的颜色渐渐褪去，他把叉子掉到盘子上，睁大眼睛望向母亲。"
    noteen sca "什么...？"
    noteen sca "不...不，你在撒谎！你在撒谎只是为了阻止我去见他...！"
    m "我没有撒谎，诺亚。"
    noteen sca "你...一定是在骗我..."
    noteen sca "我要去看他！你必须现在就带我去看他！"
    "诺亚抓起手机，迅速拨通了凯恩的号码。但电话直接转到了语音信箱。"
    m "今天不行。你父亲要上班，我要和朋友出去。"
    noteen ang "你在说什么鬼话？"
    noteen ang "奥古斯特正躺在医院里，而你们只顾着自己！"
    f "跟你母亲说话要注意语气。"
    noteen ang "不！我不会！"
    noteen ang "你们两个只顾自己和你们那愚蠢的形象！我...我恨你们两个...我恨你们两个到死..."
    noteen ang "有一天，当你们两个死去的时候，我希望你们完全孤独...别指望我会在那里。"

    "诺亚冲出了大门，用力摔上门，泪水顺着脸颊流下。"
    play sound slam
    scene bg town day with hpunch:
        subpixel True xpos 0.78 ypos 1.49 xanchor 0.5 yanchor 1.0 zoom 1.59 rotate None
    "天空晴朗—风暴已经过去了。"
    ash neu "..."
    noteen ang "走开。我现在不想理你。"
    ash neu "你要去哪里？"
    noteen ang "去医院。不管你告诉妈妈不，我都要去。"
    "艾许举起手指，上面挂着一串银色钥匙扣，那是父亲新车的钥匙。"
    ash neu "要不要搭个车？"
    noteen sho "......"
    noteen sho "你只是想骗我。"
    "艾许移开了视线。这一次，他脸上露出了严肃的表情。"
    ash neu "我他妈不在乎你。但这不意味着我会在你的朋友躺在医院病床上的时候想要骗你。"
    "他耸了耸肩。"
    ash neu "你也会为我这么做的。"
    ash fro "...我希望如此。"
    noteen sho "...爸爸会很生气的。"
    ash mock "呃，反正我很快就要回校了。"
    "两兄弟滑进了车里，诺亚擦拭着脸上的泪水，但这并没有什么帮助。"

    scene bg sky day with dissolve
    "车程一路沉默。"
    "艾许对诺亚没什么好说的，诺亚对艾许也是如此，但他心里还是感激的，只是从未表达出来。"
    "很快，耸立的医院就出现在远处，艾许在街道旁停下了车。"
    ash sad "..."
    ash sad "不管怎样，我希望他没事。"
    noteen sca "谢谢..."
    noteen sad "...希望爸爸不会杀了你。"
    "他歪着嘴笑了笑，然后重新上路，朝来时的方向开去。"
    "诺亚开始跑起来。"
    "他像是生命依赖于此般跑着。他像是这是最后一次机会般跑着。他像是要去拯救奥古斯特般跑着。"

    scene bg hospital with Fade(1.0, 1.0, 1.0)

    "医院的走廊里人来人往，穿着手术服和白大褂的人匆忙穿梭。诺亚觉得自己像是在做梦，周围的一切都模糊不清，只有心中的绝望清晰可见。"
    "等候室里，人们坐在那里咳嗽和喘息。两名接待员坐在前台后。诺亚上气不接下气地冲到前台，接待员们担心地看着他。"
    noteen sca "我来了...我来看奥古斯特..."
    rec "奥古斯特...？"
    "另一名接待员把年轻女士拉到一边，悄悄地对她说了些什么，然后她转过身来对诺亚说话。"
    rec "对不起，你是家属吗？"
    noteen sca "不...不是，我是—"
    rec "现在只允许家属进入。"
    noteen sca "但是...但是他是..."



    j cry "诺亚..."
    "诺亚转过头，看到了贾斯帕——奥古斯特的父亲。"
    "他从未听过如此充满痛苦的声音，也从未见过如此肿胀和布满泪痕的脸。"
    "他一言不发。也许他不需要说什么。"
    "贾斯帕只是伸手拥抱住了诺亚。"
    "当诺亚终于开口时，他的声音微弱，听起来像是另一个人。"
    show augustdad n cry glasses at slightright
    show noahteen n hea at slightleft
    with dissolve
    no "告诉我这不是真的..."
    no "告诉我这都是谎言..."
    "奥古斯特的父亲没有回答。他的头垂落到诺亚的肩膀上，轻声啜泣着。"
    j "奥古斯特...奥古斯特...他是那么爱你。"
    "如果没有那双环抱着他的大臂，诺亚恐怕早已跪倒在地。"
    "诺亚不是个虔诚的人，但他发现自己在祈祷。祈祷这只是另一个梦境，当他醒来时这场噩梦就会消失。"
    "奥古斯特会在那里，像阳光般微笑。"
    "但这是现实，诺亚开始明白现实是残酷和无情的。"
    "诺亚无法再问任何问题，也无法听到更多细节。他只是呆立在那里，时间仿佛静止，无法理解发生了什么。"
    "过了好一会儿，贾斯帕缓缓松开了对诺亚的拥抱，用红肿的眼睛看着他。"
    j "你可以..."
    j "你可以去看他，如果你想的话，但是..."
    j "我...我觉得保留你心中的他的形象会更好。"
    show kaineteen n sad at left behind noahteen
    with dissolve


    k "诺亚..."
    no "凯恩？"
    "凯恩低头看着地面。他看起来和奥古斯特的父亲一样疲惫——看来他们昨晚都没睡好。"
    k "我试着...我试着给你打电话...但是手机没电了..."
    k "没人能联系到你。"
    k "你妈妈不让我进去...昨晚和今天早上都不让任何人进去看你..."
    rec "先生，我们能和您谈谈吗？"
    j "当然...当然，好的。"
    hide augustdad

    $all_moves(camera_check_points={u'y': [(-1199, 0, u'ease')], u'x': [(-2814, 0, u'ease'), (-6000, 14.66, u'ease')], u'z': [(789, 0, u'ease')]})
    with dissolve
    "诺亚面对着凯恩。两个男孩都不知道该说些什么来让一切重新好起来。"
    no "发生了什么...？"
    "凯恩皱着眉头，脸上满是痛苦。"
    k "昨晚的暴风雨...奥古斯特不知为何在外面..."
    k "路很滑，很黑...河水泛滥..."
    no "....."
    no "这..."
    no "这都是我的错..."
    hide noahteen
    hide kaineteen
    with hpunch
    "诺亚跌坐在地上。"
    "滴答，滴答，滴答。"
    "某处传来了时钟的滴答声。时间在前进，不管诺亚是否愿意。"
    "他存在的时间，但奥古斯特却不在了。"
    "他让奥古斯特在医院的病床上死去，而他自己却在家里安睡的时间。"
    "凯恩单膝跪下，但不管他想对诺亚说什么，都被深渊吞噬了。"
    "罪疚感像绑在脚踝上一样压在他身上。他正在后悔和罪疚的汪洋中无法自拔。"
    "他不配逃脱。"
    "在他做过的事情之后。"
    noteen hea "应该是我。"
    kteen hea  "诺亚，听我说！"
    noteen "我...我应该死去...不是他..."
    stop music fadeout 3.0
    noteen "不是像他这样的人..."


    scene black with Fade(1.0, 3.0, 1.0)

    "房间里一片寂静。"
    play music coma fadein 4.0
    "诺亚已经习惯了这种寂静。"
    "每天早上，他母亲都会敲他的门，然后就是寂静。晚上，她会求他吃点东西，然后又是寂静。"
    "诺亚盯着墙壁。"
    "这和其他任何时候都没有什么不同。"
    "但他却仔细地研究着它。"
    "他什么也感受不到，却又感受到一切。"
    "他麻木而空虚，却充满了比他以前感受过的任何痛苦都要更糟的痛苦。"
    "他在窒息，但同时又活着，呼吸着。"
    "他看到了奥古斯特的笑容。"
    "他听到了奥古斯特的笑声。"
    "他感受到了奥古斯特的存在，但每当他转过头去看那个男孩时，他都不在那里。"
    "诺亚的手机放在床头柜上，电量耗尽了。"
    "他不在乎给它充电。"
    "他唯一想说话的人已经不在了，他也厌烦了凯恩的短信。"
    play sound knock
    "有人敲响了他的门，是他的母亲出现了。"
    scene bg bedroom night2 with dissolve
    m "求你了，诺亚，你得吃点东西。已经好几天了...这还不够吗？"
    "诺亚没有回答。他只是茫然地盯着墙壁，沉浸在自己的思绪中。"
    m "我给你带了些食物—"
    noteen sad "出去。"
    m "诺亚—"
    noteen ang "我说出去。"
    noteen ang "我不要你的食物。我不想看到你的脸。我想一个人待着。"
    noteen ang "赶快去死吧。我希望你们都死掉。"
    noteen hea "我希望我也能死掉..."
    m "..."
    m "那就去做吧。"
    m "你整天把自己关在这个房子里，你觉得邻居会怎么想？"
    m "我们告诉过你不要和那个男孩做朋友，但你还是违背了我们，看看现在发生了什么。"
    noteen hea "..."
    noteen hea "出去。"
    m "...有个朋友来看你。"
    noteen hea "我不care。我不想见他们。"
    "诺亚的母亲重重地叹了口气，好像在说\"你反应过度了\"。他只是无视了她，继续盯着墙壁。"
    "过了一会儿，她走了，取而代之的是一个染着粉色头发的年轻女子。"

    show noahteen n dark sad at slightleft:
        subpixel True xpos 0.27 ypos 1.0 xanchor 0.2 yanchor 1.0 rotate None
    show rosamie n dark sad at slightright:
        subpixel True xpos 0.73 ypos 1.0 xanchor 0.8 yanchor 1.0 rotate None
    $ camera_reset()

    $all_moves(camera_check_points={u'x': [(1330, 0, u'ease'), (29, 3.89, u'ease')], u'z': [(606, 0, u'ease')]})
    with dissolve

    r "..."
    r "很抱歉没有事先告诉你就来了。"
    no ".........."
    r "我听说发生了什么事。"
    r "我想说对不起，但你可能已经听够了。"
    no "..........."
    "罗莎米坐在诺亚的床尾。她肩上挂着一个沉重的大包。"
    show rosamie n neu with dis
    r "我只是想亲自跟你说再见。"
    r "我们也不算太熟，我只是觉得你和我很像。"
    show rosamie n sad with dis
    r "你可能是这个该死的小镇上我唯一能相处的人了。"
    no "你要去哪里？"
    "诺亚的声音几乎只剩下嘶哑。"
    show rosamie n neu with dis
    r "可能是。"
    r "我能对你诚实吗？尽管你可能不会喜欢我要说的。"
    "诺亚点了点头。"
    "诚实听起来也不坏。"
    r "你应该趁还来得及赶快离开这个小镇。"
    show rosamie n ann with dis
    r "卢卡那个小混蛋在学校到处散布关于你的流言，大家都在谈论你和...奥古斯特。"
    r "不想冒犯，但你的父母真是一团糟。"
    "仅仅听到他的名字就让他的身体感到一阵剧痛。"
    no "我还能去哪里呢..."
    "罗莎米耸了耸肩。"
    show rosamie n sad with dis
    r "我不知道。不过，任何地方都比这里好。"
    "月亮已经出现在诺亚的窗外，给罗莎米带来了温和的光芒。她看起来有些像个公主——一个可以为诺亚带来全新梦想的公主。"
    "罗莎米凝视着月光，然后看了看手表，站了起来。"
    show rosamie n neu with dis
    r "如果我父母问起，就说我从这里回家了，好吗？"
    no "...好。我会...帮你掩护的。"
    show rosamie n smi with dis
    r "...谢谢你，诺亚。"
    r "不管怎样，我很享受我们短暂的友谊，即使我们可能永远不会再见面。"
    r "祝你好运。"

    hide noahteen
    hide rosamie
    with dissolve

    "下一刻，她就消失了。"
    nothought "人们是如此容易消失，不是吗？"
    nothought "一刻他们就在你身边，下一刻他们就像雾一样消失了。"
    nothought "一个人是如此...脆弱。"
    nothought "我想把一切都给你...现在感觉一切都只是幻觉，一个在时间中消失的短暂时刻..."
    "房间里很安静，但仍然似乎回荡着奥古斯特的存在消失的回声。他曾在这个房间里画画和大笑，就在不久前...现在他已经走了。"
    "感觉就好像当他走了的时候，他也带走了诺亚的一部分。"
    "窗户传来一声敲击，吓了诺亚一跳。"
    "他朝声音的方向看去，内心充满了难以置信。"
    "他跳了起来，冲到窗前打开了窗户。"
    nothought "奥古斯特...！"
    "但是，当然，奥古斯特并不在那里。"
    j sad "诺亚..."
    j sad "很抱歉这样突然闯进来。"
    noteen sad "啊..."
    "奥古斯特的父亲贾斯帕爬进了房间。他的眼睛凹陷，眼圈很深。"

    show augustdad n dark sad glasses at slightleft
    show noahteen n dark sad at slightright

    $all_moves(camera_check_points={u'z': [(95, 0, u'linear')]})
    with dissolve

    "诺亚一直认为这个男人很有条理，但现在他完全不是那样。"
    j "奥古斯特以前经常偷偷出来见你，对吗？"
    show noahteen n sur with dis
    no "你...知道...？"
    j "当然。"
    no "对不起—"
    show augustdad n hap with dis
    j "没什么好道歉的。"
    j "这是青春期的一部分。而且你让他很快乐，所以...我也很高兴。"
    show noahteen n sad with dis
    no "....."
    show augustdad n sad with dis
    j "我想来跟你说再见。"
    no "再...见...？"
    j "在...葬礼之后，我要搬走了。这是个美丽的小镇，但自从他离开后，一切都变得黯淡了。"
    j "我不认为我还能在这里待下去。"
    no "哦..."
    j "我想给你这些。"
    "他手里拿着一个小小的粉色花盆。一株小苗正从泥土中茁壮生长。"
    "下面是一个小纸盒。"
    j "奥古斯特比你想象的还要更喜欢这个...他希望你能继续照顾它。"
    no "我...我不能接受..."
    nothought "如果我接受了...那就意味着...我接受了他真的走了...我做不到..."
    j "拜托，诺亚。"
    "他犹豫地伸出手接过花盆。它在他手中感觉很冰冷，毫无生气。"
    j "我不相信你的父母会真的把它给你...所以我想亲自给你。"
    j "好好照顾它，好吗？"
    no "我...我会的..."
    "然后他递给他那个小盒子。"
    j "里面是奥古斯特保留的一些照片。各种各样的东西。"
    "贾斯帕从口袋里掏出一张折叠的纸，小心地放在诺亚的桌子上。"
    j "这是我的电话号码。如果你需要任何帮助——任何事情——都可以给我打电话，好吗？"
    j "你是个了不起的人，诺亚，你将来一定会做出很棒的成就。你的价值不是由你的家人对你的看法决定的。"
    j "记住这一点，好吗？"
    j "如果你需要有人相信你，那个人就是我。"
    hide noahteen
    hide augustdad
    with dissolve
    "诺亚不知道什么时候，两个人的脸颊上都流下了无声的泪水。"
    "他们无言地拥抱在一起，诺亚感觉自己彻底失去了奥古斯特的最后一部分。"
    "贾斯帕退后，悲伤地笑了笑，然后朝窗户走去。"
    nothought "他知道吗？他知道奥古斯特那天晚上出去是因为我吗...？"
    "内疚感让他感到身体不适。当他试图向奥古斯特的父亲解释时，胃里翻江倒海。"
    noteen hea "先生—贾斯帕...我..."
    noteen "这是我的...这是我的错—"
    "他只是摇了摇头，然后离开了。"

    "再次，诺亚独自一人。"
    "完全、彻底地独自一人。"
    "这种感觉让他窒息。他感觉到四面楚歌——不仅仅是墙壁，而是一切。学校、父母、期望，甚至凯恩……一切都在向他逼近，没有任何出路。"
    "他只想去一个没有人认识他的地方。"
    "把时间都花在他的艺术上，独自一人。如果一幅画就是他唯一的朋友，那也没什么不好的。"
    "他的目光扫视了一遍房间。"
    "他完美的房间。"
    "没有什么值得带走的。这个房间里的东西对他来说都无关紧要。"
    "他的艺术品。奥古斯特的植物。奥古斯特的画作。"
    "其他一切都可以留在这个地狱里腐烂，连同这个城镇里的所有人。"
    "他立即行动起来。"
    "诺亚把书包倒过来，把不再需要的东西全部倒出来。取而代之的是他的素描本，以及奥古斯特在这个房间里画的那幅画，小心翼翼地折叠起来。"
    "一个装着笔、铅笔和画笔的笔袋，以及一些颜料，也被放了进去。他还拿了一张上面写着贾斯帕电话号码的纸，以防万一。"
    "他轻轻打开门，向外张望。房子里一片黑暗。他的父母可能已经睡着了。"
    "背着书包，小心翼翼地拿着那盆植物，他走进了客厅。"

    scene bg livingroom night with Fade(1.0, 1.0, 1.0)

    nothought "一些食物……以防万一……"
    "他打开橱柜，拿了几罐和几包不会变质的东西，还装满了一瓶水。"
    nothought "最后是钱。"
    "他冲到了前门。他父亲通常把钱包放在挂在工作后回来时的外套口袋里。他在那些口袋里摸索了一番，终于拿出了一个普通的黑色皮夹。"
    nothought "是的...！"
    nothought "信用卡、借记卡……这些就够了。"
    "他抓了几张卡，还有500美元的现金。"
    nothought "我会去镇上取现金，然后不再使用这些卡……他们找不到我的……"
    "诺亚小心翼翼地把钱包放了回去。他们肯定会很快发现，但多拖延一点时间就能让他离开这个地狱更远一些。"
    "他最后看了一眼父母的房子。"
    "它真的很漂亮。"
    "美丽而虚荣，美丽而空虚。"
    "当他走向前门时，他最后的想法是，他不会怀念这里。"

    scene bg mountains night with Fade(1.0, 1.0, 1.0)

    "他跑了。"
    "尽管山路很滑，地形也很崎岖，但他还是跑了。"
    "每走一步，他都感觉自己能呼吸得更顺畅一些。"
    "这座山几乎一片漆黑——作为一个偏远的地方，连一盏灯都没有，看不清下一步该往哪里走。"
    "但他还是跑着。"
    "他不知道自己究竟要去哪里，也不知道会做什么，他只知道自己再也待不下去了。"
    "就像罗莎米和贾斯帕一样。他们都知道自己待不下去这个城镇，诺亚也一样。"
    "他只想独自一人，能够重新呼吸自由。"
    "当诺亚的脚踩到一根暴露的树根时，他突然想到，这是不是也是奥古斯特的感受。"
    "当他飞了起来，紧紧抱着奥古斯特的植物，想要保护它时，他惊讶于自己竟然如此冷静。"
    nothought "如果我死了……如果我死了，也许我们就能再次相见……"
    nothought "那样的话，你可以尽情恨我。你可以告诉我，你永远不会原谅我离开你一个人在这里。"
    nothought "只要我能再次见到你，我不在乎你是否恨我。只要我能再次看到那个让我想起阳光的笑容。"
    "他做好了迎接撞击的准备，但意外的是，从黑暗中传来了一个熟悉的声音。"
    ur sur "有人在吗？诺亚？"

    window hide
    show black with dis2
    show transition movie onlayer overlay
    pause 3.0
    window show
    stop music fadeout 4.0

    "他摔倒了。"
    "他感觉自己坠落了很久，双眼紧闭，不知道自己是否已经死了。"
    "他等待着撞击——骨头断裂的感觉，血液流到大地上的感觉，但取而代之的是迎面而来的狂风。"
    "他睁开了眼睛。"
    "一切都黑暗，除了远处的一盏灯，正越来越近，因为他越落越深。"

    scene bg empty dream with Fade(1.0, 1.0, 1.0):
        subpixel True xpos 0.7 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.53 rotate None

    "直到他终于不再紧张地等待撞击，他才落到地上。他滚了一圈，更担心怀里脆弱的植物而不是自己的身体。"
    noteen sca "哎呀..."
    "慌乱中，他跳了起来，但松了一口气，看到植物并没有受损。"
    play music someonessign fadein 4.0
    noteen sur "这是梦吗？"
    noteen sho "这里看起来好空旷……"
    noteen sho "有人在这里吗？"
    "他的声音在这个干净、空旷的空间里回荡。这里似乎只存在着枯死的树木和一张摇摆的长凳。"
    "他犹豫地走近，试了试，然后坐了下来。"
    "这里很安静。"
    "异常安静。"
    "而这种安静让他感到很高兴。"
    "没有人能告诉他该做什么。他可以永远呆在这里，在虚无中慢慢消失。"
    noteen sad "也许{i}那个{/i}世界才是梦……"
    noteen sad "而这才是真实的世界……"
    noteen sad "奥古斯特，你在吗？"
    noteen sad "求你了...求你能在这里吗？"
    noteen hea "我不想一个人...我愿意放弃一切再次见到你..."
    noteen hea "如果能让我重拾你，我根本不在乎是否再见到其他人..."
    "他的话语后是一片沉寂。"
    noteen hea "我只是...不想一个人..."
    "他把腿蜷缩在身下，双臂环抱住自己。"
    u "那个诺亚...我们为他做了这么多，看看他现在成了什么样子。" #??? (Ghostly voices from here)
    noteen sca "啊？"
    "诺亚抬头环顾四周，但是没有人。声音似乎来自四面八方，却又无处可寻。"
    u "看看他是如何逃避自己的问题。真是个懦夫。"
    noteen sca "不是..."
    u "他一直都很软弱。连自己的情绪都无法承受。"
    u "看看他，只因为一个人死去就如此痛苦。有什么好在乎的？"
    noteen sad "不...！"
    u "他一直都是个负担..."
    noteen sad "住口，求你了..."
    noteen sad "请，让我一个人静静..."
    u "他是个失败者。永远也不会有什么成就。"
    "诺亚双手捂住耳朵，拼命想要淹没那些既熟悉又陌生的声音。"
    u "要不是因为他，奥古斯特还会活着...我的儿子..."
    noteen hea "对不起...我真的很抱歉..."
    noteen hea "我很抱歉我曾经存在过...本该是我..."
    u "现在他又逃避一切。去寻找幸福，却留下一路毁坏和死亡。"
    noteen hea "奥古斯特...！求你帮帮我..."

    show noahteen n hea at slightleft
    show crow n sad at slightright
    $ camera_reset()

    $all_moves(camera_check_points={u'y': [(2433, 0, u'ease'), (-2515, 16.31, u'ease')], u'x': [(5356, 0, u'ease')], u'z': [(1030, 0, u'ease')]})
    with dissolve

    uc "嘘，没事的。"
    show crow n sadsmi with dis
    uc "我在这里。"
    "所有的声音都突然停了下来，渐渐消失在虚无之中。取而代之的是一个温和安抚的声音。"
    "诺亚甚至不敢抬头看他的救助者。他太害怕了—害怕那个人不是他期待的那个人。"
    hide noahteen with dis
    noteen hea "奥...奥古斯特...？"
    uc "...我会成为你所需要的任何人。"
    uc "你不需要听他们的。"
    uc "过去是痛苦的...但你值得拥有幸福。也许不会是今天或明天，但总有一天你会找到它。"
    uc "不要责备自己。"
    noteen "奥...奥..."
    "他哽咽啜泣，说话断断续续。"
    noteen "我只想要他回来...我只想和他互换位置...求你了...求你了..."
    uc "活下去，诺亚。活下去，重新学会存在。"
    noteen "我做不到..."
    uc "你可以的。"
    uc "逃避并不一定就是懦弱。留下也不一定就是勇敢。"
    uc "你所能做的就是在当下做对自己最好的事。"
    noteen "..."
    uc "是时候该走了，诺亚。"
    uc "小心点，好吗？别摔倒，记得看好路。"
    noteen "别离开我—"

    scene black with dissolve

    "但已经太迟了。当诺亚终于抬头时，那神秘的身影已经消失，他再次坠入黑暗之中。"
    "那陌生人的声音对他来说有些熟悉—温暖如晨曦。"
    "他再次紧紧抱住那盆植物。"
    "它也突然感觉更加温暖了。"
    "温暖如阳光。"

    stop music fadeout 4.0
    jump crow_chapter3

    ########################### CROW CHAPTER 2 END #########################################
