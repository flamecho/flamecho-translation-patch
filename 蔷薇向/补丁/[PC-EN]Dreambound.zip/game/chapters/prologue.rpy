label prologue_start:

    scene black
    with dissolve
    "《Dreambound》的部分可以完全以文本或点击方式进行游戏，并包含谜题。你想怎么玩？（注意：这无法更改）。"
    menu:
        "《Dreambound》是为了以点击谜题的方式进行游戏而设计的，逃脱部分在这种格式下表现最佳。不过，如果你不喜欢谜题或者你的电脑运行不畅，我建议切换到仅文本模式。"

        "仅文本":
            $ game_type_ver = "VN"
        "点击谜题":
            $ game_type_ver = "puzzle"



    scene bg funeral
    with Fade(2.0, 1.0, 2.0)

    "那是一个星期五的下午2：37。"
    play music younonai fadein 3.0

    "在这个特定的日子，这个特定的时刻……"


    show bg funeral with dis:
        subpixel True xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 2.11 rotate None
        parallel:
            xpos 0.65
            easein 8.0 xpos 0.51
    "一场葬礼正在举行。"
    u "他太年轻了。真不幸……"
    "未来还有很多个星期五。还有很多个时刻，时钟会再次指向2：37。"
    "时间会继续流逝，无论一个人是否在这里。"
    u "如此多的才华被浪费。"
    "活着意味着什么？"
    "而死去又意味着什么？"
    u "他的家人一定很绝望。"
    "存在意味着什么？"
    "而这种存在的恐惧何时才能结束？"
    u "........"
    "一个棕发的男孩独自坐在角落里。"
    "对他来说，那口棺材看起来小得太过分了。"
    "小得无法容纳如此庞大的灵魂。"
    "小得无法承载整个存在，和它所有的历史。"
    u "诺亚..."
    "明天，其他人将继续生活。"
    "明天，其他人将会忘记。"
    "如果不是明天，那就是后天。总有一天，所有人都会忘记。"
    "棕发的男孩紧紧抱住自己的胸口。"
    "他不会忘记。"
    "但即使是他也无法说服自己相信这些话。"
    "在离死者十英尺远的地方，口口声声说些空话是多么容易。"
    u "我很抱歉..."
    "那是一个星期五的下午2：37。"
    stop music fadeout 3.0
    "而在这个星期五，这场葬礼为两个人而办。"

    scene black with dissolve
    pause 2.0
    call screen opening_movie()

    pause 1.0
    call screen prologue_chapter_screen

    scene gallery_1 with Fade(1.0, 1.0, 1.0)
    play music falsestart fadein 3.0
    "孤独地，困在他的监狱中，那个男人坐着，背部弯曲，手臂抬起。"
    "手中握着一支画笔。"
    "在他眼中，这或许是一种武器，一种工具。"

    "从中，生命应该在一个部分虚构、部分真实的世界的每个角落蓬勃生长。"
    "海浪拍打着白色的海岸。夜空在自己身上反射，星海在旋涡般的潮流中闪烁。一切都平静，却又不然。"
    "但是，正如所说的，那世界并不存在。无法存在。它永远不会存在。它无法由这只手创造。"
    "那个男人将画笔举向空白的画布。空白，像许多其他的画布一样。"
    "是白天，还是夜晚？他不知道。毕竟，光不属于这样的地方。"
    "它从未属于过。"
    "他闭上眼睛，等待它的出现。"
    "某种东西。"
    "任何东西。"
    "一个幻象，一个杰作，一个缪斯，一个能激发他创造力的幻影……任何东西。"
    "但什么也没有来到他面前。"
    "什么都没有来，毫无例外，毫无例外。"
    "他在那不可思议明亮的白色画布上每一笔都是对他灵魂的污点。一个本该是纯净的肮脏印记。"
    "在他的手中，他所能创造的只有孤独。"
    "没有什么属于。"
    "再也不会有任何东西属于，因为他已经破碎。"
    "时间就这样流逝，毫不留情。一个永恒的时刻过去，或者说感觉像是，时钟缓缓滴答。"
    "滴答，滴答。"
    "无尽。"
    "但对一个没有时间可给予的人来说，时间又算什么呢？"
    "他的手在颤抖。他无法强迫自己去画，但他也无法放下手。"
    $ renpy.transition(dissolve)
    $all_moves(camera_check_points={u'y': [(-522, 0, u'linear')], u'x': [(956, 0, u'linear'), (-943, 1.41, u'linear')], u'z': [(500, 0, u'linear')]})
    "在他紧闭的眼睛背后，他抵挡着意识边缘的疲惫感。"
    "也许一个梦能帮助他创作。"
    "也许如果他只是让自己沉浸在那星光闪烁的海洋中，灵感就会降临。"
    "或者也许这会把他带离这个世界，最终带给他宁静。"
    "然而他睁开了眼睛，否认了这个想法。"
    "绝对不能那样。"
    "绝对不能是梦。"
    "这是恐惧吗？仇恨？厌恶？"
    "不。这是更多。远比这更多。"
    "这不是低级的情感。这是更深、更阴险的东西。"
    "人类的心智已经扭曲到无法辨认。他们的存在完全变得邪恶。"
    "白天，他们戴着面具来隐藏自己的意图。但在夜晚，在他们的梦中，面具会掉落。"
    "曾经纯洁而明亮的东西现在已经腐化得无法修复。"



    $ gametype = "NVL"
    $ charleft = "???"
    $ charright = "???"



    #TODO Placeholder sprites
    $cs_left = "mother"
    $cs_right = "father"

    unvl "诺亚……你必须立刻停止这一切。你不能靠这些……无论这些涂鸦意味着什么。想想人们会怎么说我……关于我们！"
    unvl "你为什么不能像你哥哥那样？"

    unvl "是时候长大了。你不再是孩子了。快把你所有愚蠢的小书都扔掉，放弃这一切。"
    notnvl "不……不……这就是……这就是我所有的一切……"
    notnvl "我剩下的全部……"
    unvl "这一切都是{sc=3}他的{/sc}错……看看{sc=3}他{/sc}对我们的儿子做了什么……"
    notnvl "拜托，我需要一些东西……"
    notnvl "只要一件事……让我拥有……只要一件……"
    show gallery_1 with hpunch
    $ renpy.transition(dissolve)
    $cs_left = None
    $cs_right = None
    $ charleft = ""
    $ charright = ""
    nvl clear


    nv "一封信静静地躺在桌上，未拆封。"
    nv "他缺乏勇气去打开它，太害怕去读那些将改变他生活的字句。"
    nv "他的手指颤抖着，逐渐靠近，直到那有质感的信封轻轻触碰到他的指尖。"
    nv "它感觉像生命。它感觉像未来。它感觉像能把他从他所陷入的深渊中拉出来的唯一东西，慢慢地被活埋。"
    nv "他一口气打开了信封。"
    nv "字句在纸上铺展开来，排列得井井有条。"
    nv "他突然感觉自己失去了阅读的能力。"
    nv "在那微弱的光线下，他还是试着去读。"
    nvl clear

    notnvl "亲爱的诺亚，"
    notnvl "我很高兴地通知你，你已被选中获得铜湾艺术卓越大学奖学金。"
    notnvl "每年，只有一名学生在全州范围内通过作品集展示、面试和前任教师的推荐被选中获得此奖学金。"
    notnvl "铜湾艺术卓越大学奖学金为你在我们学校的学习提供全额学费。"
    notnvl "请注意，获得此奖学金的学生必须全日制注册，并保持3.5的平均绩点，以继续获得奖学金。"
    notnvl "再次祝贺你获得这一伟大荣誉的选拔。我们期待在校园见到你。"
    nvl clear
    nv "在他眼前，信件化为尘埃，随风飘散，进入那个虚构的世界。"
    nvl clear


    $ gametype = "ADV"

    "过去的记忆如匕首般向他袭来。它们刺穿了他的肉体，但这已经无所谓了。"
    "他已经习惯了。"
    "事实上，他有时会想他现在是否享受这种感觉。"
    "疼痛在他全身蔓延，但至少他终于能感觉到一些东西。"
    "他的画笔，仍然沾着颜料，静静地停在画布上。"
    stop music fadeout 2.0
    "他抵抗着打哈欠的冲动，用空闲的手揉了揉眼睛。"

    scene bg paint day with Fade(1.0, 1.0, 1.0)

    play music audio.ringing fadein 1.0
    "一阵铃声在黑暗中响起，回荡在这无灵的房子里。"
    "没有人来接听。除了……"
    show noah n dim fro at center with dissolve
    no "走开……"
    "铃声不断响起，响个不停。"
    stop music fadeout 1.0
    "然后它停了。"
    play music audio.ringing fadein 1.0
    "直到它再次响起。"
    show noah n dim hur with hpunch
    no "走开……！"
    "诺亚捂住头，疼痛因那刺耳的声音而加剧。"
    "他想要忽视它。"
    "比什么都重要，他不想接电话。"
    "但来电者很固执，而诺亚很容易烦躁。"
    "他从凳子上站起，画笔掉落在地上，发出咔嗒声，颜料飞溅在木地板上。"
    "只是增加了已经在增长的收藏。此时，他的房子上溅上的油漆比任何画布上都要多。"
    "他慢慢走向手机，每一步都很谨慎。"
    show noah n fro with dis
    "这款手机很旧。是他从青少年时期就一直使用的那款。"
    "他看着亮起的屏幕上的号码，但他不认识。"
    "然而，铃声依然在响。"
    nothought "我应该把这个该死的东西关掉……"
    "他盯着屏幕，光线刺痛了他的眼睛。"
    stop music fadeout 2.0
    "但不知为何，他还是拿起了手机。"
    play music sunset fadein 3.0
    u "...诺亚？是你吗？"
    no"........."
    no "你想要什么？你是怎么得到这个号码的？"
    u "是我……你的爸爸。我们能谈谈吗？"
    no "我接了电话，不是吗？你想要什么？"
    u "拜托，已经很久了……"
    no"你想要什么？！"
    u "你……你母亲刚刚去世。请，求你……至少来参加葬礼……"
    "诺亚把手机从耳边拿开，手指滑过屏幕。它静默了，另一方再也不知道发生了什么。"
    "他毫不犹豫地关掉手机，把它扔进了垃圾桶。"
    show noah n neu with dis
    no"所以她死了。"
    "他的声音没有任何情感。这个事实让他快乐还是悲伤，没人能看得出来。"
    hide noah
    show bg paint day:
        xpos 0.52 ypos 1.27 xanchor 0.5 yanchor 1.0 zoom 1.65
    with dissolve
    "他走回画架旁。上面是一块仍然空白的画布，等待着被赋予生命。"
    show bg with hpunch
    "他把它扔到地上，与其他被遗弃的“杰作”堆在一起，然后用脚狠狠踩下去，把它们踩成两半。"
    "一个接一个，他无声地把它们砸成碎片。没有一句话或呐喊从他嘴里溢出。"
    "只有无声的愤怒。"
    "不是对他母亲的去世。"
    "只是针对他自己。"
    "结束了，但并没有感到更满足，他跌坐在地上，蜷缩成一团。"
    stop music fadeout 5.0
    "他的眼睑越来越重，直到最后他找到了睡眠。"

    scene black with Fade(1.0, 1.0, 1.0)

    "但即使是睡眠也并不安宁。"

    scene bg paint day with Fade(1.0, 1.0, 1.0)

    "诺亚被门锁转动的声音惊醒，然后是门缓缓打开的声音。"
    play music coma fadein 3.0
    "脚步声开始时缓慢，随后加快，直接朝他走来。"
    "但他没有退缩，也没有转身去看是谁。"
    nothought "如果有人想杀了我，就让他们来吧。如果他们想偷走这些东西，随便。我不在乎了。"
    nothought "我不在乎……就让我死吧……"

    show kaine n dim sur at center with dissolve
    k "诺亚？！你在地上做什么？！你还好吗？"
    "诺亚应该意识到那是谁，但他却感到失望。"
    nothought "如果是来杀我的人就好了。"
    no neu "走开。我在休息。"
    k "你有一个很好的卧室，就在隔壁。来吧，让我帮你上床。"
    no fro "我不想去。快走吧。"
    show kaine n sad with dis
    k "........."
    k "让我至少给你拿点水。来吧。"
    "凯恩伸出手给诺亚，诺亚茫然地盯着那只手。"
    "凯恩和他一直以来一样。善良、可靠、勤奋。"
    "有魅力、幽默、受欢迎……"
    "一切他所不具备的。"
    "他叹了口气，握住凯恩的手，让自己被引导到座位上。"
    "他从包里拿出一瓶水，显然是为了这次拜访而准备的。"
    nothought "生活得真不错。能买瓶装水的生活。"
    "诺亚喝了一口，感到凉意让他的喉咙稍微好受了一点。"
    nothought "我已经很久没喝东西了。我没注意到。"
    k "诺亚..."
    show kaine at slightleft with move
    show noah n dim neu at slightright with dissolve
    no "我给了你那把备用钥匙是为了紧急情况，你知道的。"
    k "我觉得这算是紧急情况，你觉得呢？"
    k "诺亚……这必须停止。"
    k "你需要寻求帮助，走出去，我不知道……事情需要改变。"
    k "你不能继续这样生活。"
    show noah n fro with dis
    "诺亚愤怒地从凯恩身边抽开，眉头紧皱。"
    no "不，什么都不需要改变。我就这样很好。"
    no "我没有请求你的帮助，所以别插手我的生活。"
    k "你不需要。"
    k "听着……这不是你的风格。你……以前不是这样的，你知道吗？"
    k "...他也不会希望你这样。你知道的。"
    show bg with hpunch
    no "...闭嘴。别提起他。"
    k "他也是我最好的朋友。我有权谈论他。"
    k "而且我确信这不是他希望你做的。"
    show noah n ann with dis
    "两人之间陷入沉默，彼此都转过头去，寻找该说些什么。"
    "他们之间有一个曾经不存在的空隙。"
    show kaine n neu with dis
    k "...你的画画得怎么样？"
    show noah n neu with dis
    no "在你看来它是什么样子？"
    "诺亚耸了耸肩，但当凯恩保持沉默时，他继续说道。"
    show noah n sad with dis
    no"我应该放弃。再也没有意义了。我无法画画。我只是在浪费时间。"
    show kaine n ser with dis
    k "...当然可以。我见过你画画。我知道你能做到。"
    show noah n ang with dis
    no "那为什么？！看看你周围...我为什么不能再做到？！"
    show kaine n sad with dis
    k "....."
    show noah n hur with dis
    no "...太晚了。一切都感觉...肮脏...没有值得捕捉的东西了..."
    no "我在追逐一个不存在的光。"
    k "但是看看，你周围有很多漂亮的画。"
    "诺亚在他们之间看了看。他们在他脑海中变得太丑，甚至不想再看一眼。"
    no "它们毫无价值。甚至不如毫无价值。"
    k ".........."
    show noah n sad with dis
    no "我想这就是结束的感觉。如果明天世界就结束，那该多好..."
    k "你知道...也许出去体验一些新事物会激发你的热情。认识新的人...我的意思是，认识新朋友对你会有好处。"
    no "没有意义。我会死在我的空白画布旁，最后我将拥有我唯一的杰作。"
    k "诺亚..."
    "凯恩似乎不知该说什么，找到了遥控器，打开了那台旧小电视。"
    "一位穿着得体的新闻主播毫无感情地读着新闻，让人怀疑她是否真的关心嘴里说出的话。"
    stop music fadeout 3.0
    tv "接下来，我们有一些来自现场的突发新闻。"
    play music nothing fadein 3.0
    tv "发现了一些尸体，上面有奇怪的花朵状标记，最初被认为是纹身。"
    tv "分析师表示，受害者身上没有墨水、颜料或烧伤痕迹，这使得调查停滞不前，直到他们能找出这些标记的含义。"
    no"进一步证明真正的艺术存在于死亡之中。"
    k "啊..."
    "凯恩从喉咙深处发出厌恶的声音，关掉了电视，似乎决定沉默更好。"
    k "...我再问你一次，好吗？请，让我帮你。"
    show noah n fro with dis
    no "我不想要你的帮助。我只想让你离我远点，别再来这里。"
    k "我们是朋友，诺亚。我不会离开的。"
    no "我不想要任何朋友。"
    no "我不配有朋友。"
    nothought "我不想让唯一对我重要的人也背叛我。你最好现在就离开。"
    k "我不会离开的。我保证。"
    no "我告诉你离开，而不是留下。"
    "凯恩似乎听到信号，站起身，从他的皮包里拿出另一瓶水。"
    "他一步步走近，直到站在一盆植物面前，这是整个房子里唯一剩下的生命。"
    "他慢慢地给它浇水，陷入沉思。"
    k "确保你照顾好这个，好吗？我不能每天都来。"
    no "我是..."
    k "很好。"
    "浇完水，凯恩走向门口，打开了门。诺亚遮住了眼睛，躲避阳光。"
    k "我只想看到你回到以前的自己，好吗？我想帮助你。"
    no "他不存在。"
    hide kaine
    hide noah
    with dissolve
    "他轻轻地关上了门。"
    "他又一次孤单。"
    nothought "我更喜欢这样..."
    "诺亚从凳子上站起来，随着房间的旋转而摇晃。他的头仍然在痛，肚子里感到一阵深深的饥饿。"
    nothought "我上次吃东西是什么时候..."
    "他站立不稳，慢慢走进厨房。"

    scene bg kitchen with Fade(1.0, 1.0, 1.0)
    "诺亚的厨房一如既往地空荡荡。他真的从未使用过。大多数时候，他会点外卖，或者更好，干脆不吃。"
    "他的资金有限，他总是把画材放在其他任何东西之上。"
    "诺亚伸手打开一个橱柜，心里明白里面是空的，这时他闻到了什么。"
    "食物。"
    "他的眼睛发现桌子上放着一个容器，上面有一张小纸条。他拿起它。"
    "上面写着‘享用。我很快会带些杂货过来。凯恩。’"
    "他犹豫了一下是否该接受，但最终他的肚子战胜了他的固执，他独自坐在餐桌前吃了起来。"
    "当他坐着时，他思考着。"
    "他真的讨厌思考。"
    nothought "他是多么轻易地来去自如...而我却被困在这里，像一个活埋的尸体。"
    nothought "但这又有什么呢？我已经不在乎了。那阳光，我已经多年未见……它适合他，不适合我。"
    nothought "我的“朋友”，我的“家人”……全都是假的。"
    nothought "扭曲，腐化……"
    nothought "……就像我一样。没有什么是纯粹的。没有。"
    nothought   "除了……"
    "他把叉子送到嘴边，慢慢地啃着凯恩带来的家常菜。"
    nothought "仍然是个好厨师……他最近真的一切都很好。"


    stop music fadeout 1.0
    play sound heart fadein 0.5
    show kitchen invert at flashinvert:
        size (1920, 1080)
        easein 0.25 zoom 1.1
        easeout 0.25 zoom 1.0

    "突然，他僵住了，一种恐惧在他心中蔓延。他的头痛得厉害，胃也翻腾起来。"
    "然后他倒下了。"
    "他的叉子掉在桌子上，被遗弃。"
    stop music fadeout 5.0

    window hide
    show black with dis2
    show transition movie onlayer overlay
    pause 3.0
    window show
    "世界在他周围旋转，直到消失。旋转，旋转，充满了他身体的那种熟悉的恐惧。"
    "他紧闭双眼，默默祈求这一切停止。"
    "他不想待在这里。他想回家。"
    "但当他偷偷睁开紧闭的眼睛时，他的家早已不在。"
    "他的周围依然模糊不清，身体感觉像是被撕扯着，仿佛随时会被撕成碎片。"
    "但他并没有。"
    "他对此感觉非常熟悉。"
    play music drone fadein 4.0
    scene bg bleak dream at Chromatic(offset=10) with hpunch:
        zoom 1.2 xalign 0.5 yalign 0.5
    "伴随着一声沉闷的撞击，他跌落在地，完全没有反映出他已经掉落了多久。"
    "当他再次睁开眼睛时，看到四周都是黑暗。不是人类的黑暗，而是一种更深的黑暗。"
    "某种阴险的东西，某种威胁。"
    "一个无人归属的地方。"
    "诺亚迅速站起身，检查自己。没有受伤。"
    "他的目光在阴暗、荒凉的景观中游移。没有什么引起他的注意，没有人等着他。"
    nothought "这不是通常的样子……发生了什么？"
    nothought "我想回家……求你……我只想回家……"
    "但他清楚自己需要做什么。"
    "他的脚步缓慢而小心，然后在绝望中加快，寻找能将他从这个噩梦中解救的人。"
    "他走啊走，走了又走，直到脚底起了深深的水泡。"
    "然而他仍然在走，因为他不想面对其他的选择。"
    "身后，什么都没有。面前，什么都没有。如果他在打转，他也不会知道。"
    "当他终于看到一些东西时，他的脚步停了下来。"
    "或者……某个人。"
    "一个男人，蜷缩成一团，坐在远处。"
    "黑暗包围着他，威胁着要吞噬他的本质。"
    "那男人抬起头来。他的眼神空洞，充满了悲伤。"
    "他们的目光交汇。"

    nothought "……我的父亲？"
    nothought "我为什么会被带到这里？怎么会？"
    "他的思绪飞速运转，试图找出任何理由，任何借口。"
    "那男人向他呼喊，但他的话在阴影中消失，再也无法听见。"
    "诺亚仍然僵住，无法决定是该靠近他，还是逃跑。"
    "他的心在叫他逃跑。尽量与他保持距离。"
    "但他的脑海中看到了他唯一的出路。"
    "在他做出决定之前，一团黑雾开始从一个看不见的地方卷来。"
    "它旋转着，扭曲着，直到有人从中走出。"
    "另一个人，被阴影包围。他的步伐缓慢，却不小心。或许是故意的。"
    "带着目的。"
    "他朝着蜷缩的男人走去，脚步沉重。"
    "突然，那男人的声音传到了诺亚的耳中。"
    f "诺亚……诺亚……我想要我的儿子……求你……把我的儿子还给我……"
    "那阴影中的男人抬起手臂。在他的手中，似乎有一把枪。"
    play sound gun fadein 0.5
    scene bg bleak dream at Chromatic(offset=10) with hpunch:
        zoom 1.2 xalign 0.5 yalign 0.5

    "砰。"
    "没有犹豫，没有停顿。"
    "只是一个穿透头部的单一枪声。"
    "蜷缩的男人倒在地上，他的身体在雾中蒸发。"
    "世界在他们周围震动。阴影的山峦轰然倒塌。"
    "整个世界在瞬间威胁着要消失。"
    "诺亚的目光四处游移，寻找逃生的地方，直到他最终再次看向那个持枪的男人。"
    "当世界在他周围崩溃时，他发誓那个阴影中的身影也正盯着他。"

    play sound glasssmash fadeout 0.5
    show black with shatterdissolve
    "一种空洞、永恒的黑暗。"
    "为什么黑暗总是被视为寒冷呢？"
    "如果说有什么的话，诺亚感觉自己被一种强烈的热量包围着。太过强烈，令人窒息。"
    "他觉得随时可能会燃烧起来。"
    "但即使他希望如此，也没有发生什么。"
    "某种柔软的东西缠绕在他的肩膀上，紧紧地抱着他。他本该感到害怕，但这种压力反而让人感到温暖。"

    scene bg paint night
    show noah n dark ann
    with Fade(1.0, 1.0, 1.0)

    "当他再次睁开眼睛时，他正坐着。"
    "诺亚坐在他的画架前，手悬在画布上。"
    "他的手沾满了颜料，颜料在他的皮肤上干裂。"
    "环绕他的黑暗在他逃离的地方后，突然感觉轻盈。"
    show noah n dark sur with dis
    "诺亚惊讶地停下，目光紧盯着他的画布。"
    "上面是一幅纯粹的黑暗画作。"
    "一个梦的倒影。"
    no "怎么..."
    nothought "这怎么可能……？我……不在这里……"
    "起初，他想知道怎么会这样。"
    "然后是为什么。"
    "在他的思绪停留在一个没有答案的答案上之前。"
    no "这..."
    no "完美..."
    "在某个时刻，画笔从他的手中掉落，落在了地板上。只是色彩海洋中的另一道飞溅。"
    "他无法移开视线。他不会。因为这就是他一直在等待的一切。"
    no "就是这里..."
    "他跳起来，把画从原处拿起，小心翼翼地放到一旁。"
    nothought "谁会想到……我所厌恶的东西会创造出我迄今为止最好的作品……"
    nothought "而这一切只需要……"
    nothought "只需要……"
    stop music fadeout 6.0
    nothought "一个梦。"
    "他重新坐回凳子上，向前倾，陷入沉思。"

    scene black with dissolve

    scene bg classroom day:
        xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.71
    show kaineteen m neu at slightleft

    show noahteen m neu at slightright
    with Fade(1.0, 1.0, 1.0)

    play music rural fadein 2.0
    k "我爸爸让我整晚玩。你得试试。"
    show noahteen m pou with dis
    no"就好像我父母会让我逃学去玩游戏一样。你真是赢得了父母的乐透。"
    show kaineteen m hap with dis
    k"你可以说你在学习，然后留在我家。"
    show noahteen m sur with dis
    no"哦，真的吗？我愿意。"
    "凯恩趴在诺亚的桌子上，像往常一样聊天和大笑。"
    "诺亚懒洋洋地坐着，脚踢着桌腿，毫不在意是否会打扰到房间里的其他人。"
    "这是一个学期开始几个月后的清晨。诺亚已经适应了他的日常——和凯恩一起走去学校，聊天直到铃声响起，然后浪费一天的时间，直到可以回家。"
    "当然，事情并不止于此。学习、辅导、来自父母的压力……但总的来说，没有什么能让他感到不安。"
    "他很舒适，但也很无聊。"
    k"嘿，我听到了一些有趣的事情。"
    show noahteen m neu with dis
    no "怎么了？"
    k"显然有人要转到我们的班级。"
    no "什么？在这个时候？不可能，他们根本赶不上进度。"
    show kaineteen m pou with dis
    k"不，真的。我爸爸这么说的——"
    no "而你的爸爸在董事会。是的，是的，你每次都这么说。"
    k"你觉得会是个可爱的女孩吗？"
    show noahteen m hap with dis
    no "太可爱了，肯定不适合你。"
    show kaineteen m hap with dis
    k"哎呀，我的心。没关系，你是我唯一需要的。"
    "凯恩眨了眨眼，故作娇嗲的声音让诺亚不由得后退。"
    show noahteen m sca with dis
    no "呃。希望是个男孩，这样我就可以交个新朋友。我觉得我的朋友有点问题。"
    k"你可以试试。还有谁能忍受你呢？"
    "步，步，步。"
    "门打开了，有人小心翼翼地走到教室前面，站在桌子后面。"
    "他们的老师，弗洛伊德先生，站在教室前，拍了拍手。"
    hide noahteen
    hide kaineteen
    with dissolve
    show mf m smi at center with dissolve
    mrf"好了，坐好。我今天有一些激动人心的消息。"
    "班级里喧闹不已，学生们按照指示做着。兴奋的气氛在教室里蔓延。"
    mrf"如你们中的一些人可能听说的，我们今天有一位新同学加入我们的班级。"
    mrf"他刚从州外搬来，所以如果他在任何事情上迷路了，请务必帮助他。"
    nothought "所以，是个男孩。看来凯恩在这方面错了。"
    "诺亚把肘部靠在桌子上，头埋在手中。"
    "不知为何，他对此并不感兴趣。"
    mrf"无论如何，我让他自我介绍。你可以进来了。"


    "停顿。"
    "没有人开门。"
    "不过几分钟。慢慢地，门大开了，进来了一个人。"
    "诺亚坐直了身子，目光锁定在那个进入的男孩身上。"

    show gallery_2 with Fade(1.0, 1.0, 1.0)
    "金色的头发，深邃的绿色眼睛。"

#    window hide dissolve
    #call screen poem_drag with dissolve
    #window show dissolve
#    "[poem1], [poem2], [poem3], [poem4], [poem5], [poem6]"

    "他不再犹豫，带着诺亚见过的最灿烂的笑容走到班级前面。"
    u "我感觉我现在已经把这些介绍背得滚瓜烂熟了……"
    a "很高兴见到你们。我叫奥古斯特，刚和我爸爸搬到这里。其实，我们每隔几个月就会搬一次，所以我已经上过大约……七所学校了。"
    "几位学生惊讶地倒吸一口气，紧紧盯着他所说的每一个字。"
    "他的言辞听起来并不像是经过精心排练的演讲，而是自然流畅、平静自如，丝毫没有紧张的迹象。"
    "看起来他确实习惯于这样的介绍。"
    a "不过，我希望我们能在这里待久一点……至少有足够的时间来了解你们。"

    cl1 "奥古斯特是个好名字……"
    cl2 "我以为像这样的名字会是个女孩……"
    a "哈哈哈……"
    cl1 "你爸爸是做什么的？"
    a "他是一名摄影师，所以总是旅行和搬家。我本可以选择和我祖父母住在一起，但我决定跟着他。"
    cl2 "哇……太酷了……"
    cl1 "我希望我也能旅行这么多……"
    a "嗯……还有什么可以说的呢……我喜欢日落和在海滩上散步……"
    "教室里爆发出一阵笑声，但诺亚连笑都笑不出来。"
    "那个男孩身上有种吸引力，抓住了他的目光，并牢牢锁住。"
    "他害怕如果自己稍微动一下，那个男孩就会消失。"
    "于是他默默地盯着。"
    mrf smi"好了好了，够了，别再像约会应用那样介绍了。确保你们都热情欢迎奥古斯特，并在之后带他四处转转，好吗？"
    mrf neu "去找个座位。那里有个空位……在诺亚旁边。"
    no "......."

    scene bg classroom day with Fade(1.0, 1.0, 1.0)
    "诺亚微微挥手，奥古斯特也回以同样的动作，然后坐下。"
    "接下来课堂上说了什么，诺亚并不知道。他在手指间转动着铅笔，作业本被抛在一边。"
    "他的肘部靠在桌子上，偷偷瞥向奥古斯特的侧脸。时不时地，奥古斯特会动一下，让诺亚吓得跳开，迅速移开视线。"
    nothought "嗯，他的侧脸……几乎很漂亮……"
    "他继续盯着那个男孩。"
    nothought "其实，根本不止是几乎。真的很漂亮。"
    a hap "...."
    "想到这里，奥古斯特的眼睛终于与诺亚的目光相遇。诺亚愣住了，不知道是该迅速移开视线假装没在看，还是微笑着自然地表现。"
    "最终，奥古斯特为他做出了决定。他灿烂地微笑，同时歪了歪头。诺亚尴尬地回以微笑，然后移开视线，心跳加速。"
    show popout

    show note1:
        xalign 0.5 yalign 0.3
    with dissolve
    "仅仅过了几秒钟，一张折叠的纸条滑到了他的桌子上。诺亚惊讶地看着它，然后又看向奥古斯特，后者只是用手指对着嘴唇做了个“嘘”的动作。"
    nothought "他在笑脸上画了个鼻子……"
    show note2 with dissolve:
        xalign 0.5 yalign 0.3
    "他在纸的另一面小心翼翼地写下了回信，不确定该说些什么。"
    nothought "我为什么也要这样做……真无聊……"
    hide note1
    hide note2
    hide popout
    with dissolve
    "当弗洛伊德老师转过身时，诺亚迅速把纸团揉成一团，扔向奥古斯特，后者仔细地将揉皱的纸团展开，阅读了信息。"
    "看完后，奥古斯特把肘部撑在桌子上，手托着下巴，模仿诺亚的姿势，朝他微笑。"
    "诺亚的脑海一片空白，接下来的课程在模糊中度过，直到午餐铃声突然响起。"
    "直到凯恩站在他的桌子上，手在他脸前挥动，他才从恍惚中回过神来。"



    scene bg classroom day:
        xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.71
    show kaineteen m sur at slightright

    show noahteen m neu at slightleft
    with dissolve

    k "你好，诺亚，地球呼叫你？你在吗？"
    show noahteen m shy with dis
    no "呃……对……是时候休息了吗？"
    show kaineteen m sad with dis
    k "嗯，是的，弗洛伊德老师叫了你两次，你一句话都没说。你还好吗？"
    no "我……我很好，只是……有点恍惚。"
    show kaineteen m neu with dis
    k "你觉得新来的怎么样？"
    show noahteen m sur with dis
    no "什么？！"
    "诺亚的脸颊因突如其来的问题而感到热。"
    show noahteen m shy with dis
    no "为什么？"
    k "我不知道，只是在聊天。他看起来不错。"
    no "……笑容也很好。"
    k "对……那么，我想我们也应该去跟他打个招呼。现在去吗？"
    no "不！我是说……我相信他现在身边有很多其他人……不想打扰他。"
    "教室里已经空了。其他人都已经离开，要么去吃饭，要么和朋友聊天。"
    "显然，奥古斯特被其他同学拉去参观了。"
    k "是啊，看起来他有点难以接近。那就晚点再说吧。想去吃点东西吗？"
    show noahteen m neu with dis
    no "我带了食物，所以我可能就在这里吃。"
    show kaineteen m sur with dis
    k "哇，你要分享吗？"
    show noahteen m pou with dis
    no "别傻了。你的午餐比我的好得多。"
    show kaineteen m hap with dis
    k "我能说什么呢？我算是个主厨。"
    show noahteen m hap with dis
    "诺亚笑着回应，然后拿出了他的午餐盒。里面有一个三明治和一些其他的小吃。"
    "与凯恩为自己做的奢华餐点相比，这简直微不足道。"
    no "其实，你可以给我一些你的食物。"
    k "你知道我总是乐意和你分享。"
    "凯恩给了诺亚一个温暖的微笑。他可能会开玩笑，但诺亚知道凯恩可能会为他做任何事。"
    stop music fadeout 4.0
    show noahteen m sur
    show kaineteen m sho
    with dis
    "门突然响了并打开。诺亚放下三明治，转身，正好看到有人朝他走来。"
    "就是之前的那个男孩。"
    play music herehecomes fadein 3.0
    nothought "奥古斯特。"
    no "....."
    "他安静地坐在自己的桌子旁，专心做自己的事。"
    "凯恩看向他，然后又回头看向诺亚，示意他开口。"
    show noahteen m neublu with dis
    no"...呃...."
    no"你...还好吗？"
    a neu "哦，只是有点累...我想我可以在这里躲一会儿..."
    no "我...我叫诺亚...我想你大概已经知道了...这是凯恩...呃...你想和我们一起吃午餐吗？"
    a sur "真的可以吗？"
    show kaineteen m hap with dis
    k "当然。人越多越热闹。"
    show kaineteen at right
    show noahteen at left
    with move
    show august m hap glasses at center with dissolve
    "奥古斯特转过椅子，露出了那抹灿烂的微笑。"
    k "你被那些女孩到处拖着吗？"
    show august m pou with dis
    a"我觉得她们给我展示了学校的每一个角落...我对此很开心，别误会！只是有点累。"
    no "...."
    no "顺便说一下，我...喜欢你的介绍。"
    nothought "真是个愚蠢的说法...天啊，我真无聊。"
    show august m hap with dis
    a "啊...真的？"
    "他轻笑了一下，然后低下了头。"
    a"老实说，我有点紧张...在新面前谈论自己很难..."
    a"我其实并不那么有趣，所以我总是得鼓起勇气去做。"
    k "你确实打破了僵局。我能看得出来，你会在这里融入得很好。"
    a "谢谢。我真的希望如此！"
    "他的声音温柔而平静，周围散发着明亮的气息。"
    k"我要去买饮料。你们两个想要什么吗？"
    no"就要平常的。你想让我一起去吗？"
    k "不，您可以在这里等。奥古斯特？"
    a "哦！嗯...那我也要平常的，可以吗？"
    "诺亚能感受到那温柔的微笑，贯穿了他的全身。"
    k "明白了。"
    hide kaineteen with dissolve
    show noahteen at slightleft
    show august at slightright
    with move
    "凯恩离开了房间，突然变得安静。诺亚不自觉地敲着手指，思考着该说些什么。有什么可以填补他们之间的沉默。"
    a "嘘...顺便问一下，平常的是什么？"
    no "就可乐。"
    a "呼...我本想显得酷一点，但如果是咖啡的话，我就会让自己出丑了..."
    no "...."
    no "啊..是的..."
    "诺亚的手指敲打着他面前的书，寻找着可以谈论的话题。"
    nothought "学校...太无聊了...他之前住的地方...我敢打赌大家已经问过他了..."
    show august m neu with dis
    a "那是什么？"
    "奥古斯特指着诺亚手指下的书，眼中充满了好奇。"
    no "哦..那个...只是一些愚蠢的东西，别担心。"
    show august m hap with dis
    a "现在我真的很感兴趣！我可以看看吗？"
    no "......."
    no "你...真的想看？"
    a "如果你愿意的话。"
    show noahteen m shy with dis
    no "...我只是...有点尴尬..."
    a "没关系。我觉得每个人对自己做的事情都会感到尴尬，因为那对你来说意义重大。"
    "感到害羞的他，把素描本递给了他。"
    show august m sur with dis
    a "........."
    "里面有大量的画作、素描和涂鸦，记录了诺亚曾经关注过的任何事物。"
    "这一次，他很高兴自己那天没有画任何东西，免得奥古斯特看到自己画的肖像。"
    a "你...画了这些？"
    show noahteen m sad with dis
    no "是的...对不起，我说它很愚蠢..."
    a "这些太棒了！它们太美了！"
    show noahteen m sur with dis
    no "....."
    no "不...不...它们只是..."
    show august m hap with dis
    a"你有这么多才华..."
    "他的眼中充满了惊奇，诺亚忍不住认真回应。"
    show noahteen m shy with dis
    no "我...其实想成为一名艺术家...我知道这听起来很傻，但..."
    a "太棒了..."
    a "你真的很棒。我能看出来你会成为一位出色的艺术家。"
    a "你有没有尝试过画画？"
    no "哦，我没有...我可以把这些素描本藏在家里，但我觉得如果我带一个画架进来，我的家人可能会注意到。"
    show august m pou with dis
    a "那有什么关系呢？"
    no "他们并不太喜欢我做艺术。"
    a "......."
    a "我觉得你画画会很棒。你的画作真美。"
    a "不过我画画真的很糟糕...还有素描...以及几乎所有与艺术相关的事情。"
    show noahteen m neublu with dis
    no "嗯...也许我们可以一起试试..."
    "诺亚脱口而出他脑海中浮现的第一个想法，随即就后悔了。"
    "然而，他还是认真地回应了。"
    show august m hap with dis
    a "那听起来真的很有趣。我会接受这个提议。"
    "诺亚发现自己很难回应这种真诚，因为他不习惯有人对他感兴趣。"
    show noahteen at left
    show august at center
    with move
    show kaineteen m pou at right with dissolve
    "门又打开了，凯恩走了进来。他的目光从奥古斯特温暖的微笑转向诺亚脸颊上的红晕，然后皱起了眉头。"
    show kaineteen m hap with dis
    "将这些放在一边，他又笑了笑，把饮料放在诺亚的桌子上。"
    k"拿到了。享用吧。"
    a"谢谢...下次我会付钱的，我保证。"
    k"没问题，别担心。反正我们可以强迫诺亚付钱。"
    show noahteen m pou with dis
    no "嘿-"
    k "所以...你刚搬到这里，对吧？你家在哪里？"
    show august m neu with dis
    a "离这里不远。我想是菲尔丁大道...我还在适应街道名称。"
    show noahteen m sur
    show kaineteen m sho
    with dis
    "诺亚和凯恩互相看了一眼，惊讶地眨了眨眼。"
    no "42号？"
    show august m sho with dis
    a "你怎么知道的？"
    no "....."
    no "那是...我家隔壁的地方。"
    k "住在那里的人几周前确实搬走了。"
    show august m hap with dis
    a "我完全不知道！看来我们在学校和家里都是邻居了。"
    show noahteen m neu
    show kaineteen m neu
    with dis
    no "嗯...也许我们可以一起回家？我的意思是，如果你不忙的话..."
    a "是的，我喜欢这样。我是说，这可能是更安全的选择，否则我可能会迷路。"
    a "我爸爸总是告诉我，如果把一个人放在森林中间，给他一个坏掉的指南针和一半的地图，他们找到出去的路的机会也比我大。"
    stop music fadeout 4.0
    hide august
    hide noahteen
    hide kaineteen
    scene bg classroom day
    with dissolve
    "铃声再次响起，标志着午餐结束。奥古斯特回到他的桌子上，而凯恩则收拾他的东西。"
    a sho "哦..."
    "在他旁边，奥古斯特翻找着他的书堆，然后皱起了眉头。"

    play music rural fadein 2.0
    a "我想我把数学课本落在家里了。"
    "弗洛伊德老师笑了，随意地挥了挥手。"
    mrf smi "今天你可以和诺亚分享。下次记得带来。"
    a hap "是的，老师！"
    "奥古斯特小心翼翼地把他的桌子和椅子拖得更靠近诺亚，直到两人肩并肩坐着。"
    mrf emb "好了，大家打开课本到第...哦，天啊，为什么我上次把它留在这里..."
    cl1 "快说，弗洛伊德老师！"
    mrf sad "哈...打开课本到第69页，我们将继续之前的三角函数课程。"
    "班上的一些孩子窃笑和咯咯笑。通常，诺亚至少会朝凯恩投去一个微笑，但这次他完全呆住了。"
    "奥古斯特把头靠近诺亚，他的金发垂在眼镜前。他小心翼翼地把松散的发丝推到耳后，仔细阅读课本。"
    "弗洛伊德老师的声音渐渐远去，诺亚对三角形的注意力开始动摇。"
    "当奥古斯特低声嘟囔着什么时，他才猛然回过神来。"
    a pou "数学可能会让我死去..."
    noteen neu "你不知道怎么做这个吗？"
    a sad "别笑，但我通常只{i}勉强{/i}通过我的数学考试。"
    a sca "我保证我在其他科目上更好..."
    noteen "那你想一起做这些吗？"
    "诺亚用铅笔的末端敲打着课本上的题目。"
    a hap "真的？谢谢你，诺亚。"
    "{i}诺亚{/i}。不知为何，这个名字在他嘴边说出来时听起来刚刚好。"
    "诺亚艰难地吞咽了一下，终于把目光从金发男孩身上移开。"
    nothought "我需要集中注意力。"
    a pou "那么...如果我们有邻边和斜边..."
    "奥古斯特低头看着他的作业本，那里他抄下了题目并开始解答。"
    noteen "那么..."
    "诺亚伸手过去，想在奥古斯特整齐的字迹旁边写点什么。诺亚几乎没能阻止自己在他们的手指相触时缩回手。"
    a hap "哦...哦，这比我学的方式更有道理了。谢谢你，诺亚。我想我明白了。"
    noteen neublu "...没问题。"
    "诺亚收回了手，尴尬地摆弄着他的铅笔。"
    "接下来的一整天和开始时一样——完全模糊不清。"
    "不知为何，诺亚脑海中挥之不去的是那抹微笑，但同时，这个念头又让他感到紧张。"
    nothought "我现在怎么了……"
    "随着时间一秒一秒地过去，直到铃声响起，标志着他们可以回家，诺亚的心中如同蝴蝶般翩翩起舞。"
    "他皱着眉头，紧张地用铅笔敲打着桌子。"
    nothought "这太傻了。我向来不应该对任何事情感到紧张。他不过是个普通的男孩而已。又不是和女孩一起回家。"
    "在他旁边，奥古斯特并没有注意到诺亚的举动。与他不同，奥古斯特实际上一直在认真完成任务。"
    mrf smi "你有什么想说的吗，还是你只是为了好玩而不停地敲打铅笔，诺亚？"
    "弗洛伊德老师的声音轻松愉快，诺亚立刻知道他只是在开玩笑，但他的脸还是红得像苹果。"
    noteen shy "不……没什么，弗洛伊德老师。"
    "当铃声终于响起，标志着下课时，奥古斯特立刻被人群包围。他在他们之间挣扎着，把自己的桌子移回原位。"
    "凯恩笑着走回诺亚的桌子，瞥了一眼那拥挤的人群。"

    scene bg classroom day:
        xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.71
    show kaineteen m neu at slightright

    show noahteen m neu at slightleft
    with dissolve

    k "他看起来有点害羞和安静，但即使被人群包围，他似乎也没事，对吧？"
    "在那群人中间，奥古斯特微笑着聊天，仿佛这很自然。"
    no "是啊..."
    cl1 "那么，我们为什么不在城市里转转呢？我可以带你四处看看！"
    a hap "哦，实际上，我需要回家收拾东西。下次吧！"
    cl1 "啊，那我们一起回家怎么样？"
    a "谢谢，但我其实是和诺亚一起回家的。原来我们是邻居。"
    show noahteen m sad with dis
    cl1 "哎呀，我真羡慕。你可不想和他待太久，你对他太好了！他有点混蛋。"
    a pou "....."
    "诺亚听到这句话愣住了。确实，他和其他同学并没有特别亲近，但他没有理由和他们成为朋友。"
    "他有凯恩。"
    a "谢谢你的夸奖，但我觉得他可能比我更好！而且，我觉得在背后说别人不好是不礼貌的。"
    a hap "总之，我得走了，谢谢你之前带我转转！"
    show kaineteen at right
    show noahteen at left
    with move
    show august m hap glasses at center with dissolve
    "奥古斯特挥手告别，然后走到诺亚的桌子旁与凯恩汇合。"
    k "那我们走吧？"
    a "你住得也很近吗？"
    k "其实就在马路对面。"
    a "太神奇了！这就像命运，遇见你们两个。"
    show noahteen m neublu with dis
    no "是啊……对，命运……"
    stop music fadeout 5.0
    "诺亚从座位上站起，收拾好自己的东西，把画册放进背包里。所有东西都整齐地收好后，他们离开了学校。"


    scene bg town day with Fade(1.0, 1.0, 1.0):
        xpos 0.69 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.43
    play music shift fadein 5.0
    "外面的空气依然温暖，阳光照在他们的脸上。晚春的气息随着微风轻轻飘荡。"
    "每一步都感觉像是费了很大的力气。诺亚握着自己的胸口，想知道自己是否开始生病了。"
    nothought "需要点什么来打破僵局……凯恩看起来不会说话……想想，脑子，想想……"

    show noahteen n neu at center
    show august n neu glasses at threeleft
    show kaineteen n hap at threeright
    with dissolve

    no "那么，嗯……你喜欢什么？"

    "诺亚站在凯恩和奥古斯特之间，但他的注意力全部集中在新来的身上。"
    show august n pou with dis
    a"我觉得我没有特别有趣的爱好……"
    show august n hap with dis
    a"你的爱好可酷多了。"
    show noahteen n shy with dis
    no"............."
    a"我们搬家太多了，我从来没有加入过任何社团……但我喜欢阅读和拍照。"
    no"那很好。我也喜欢阅读。"
    show kaineteen n sho with dis
    k"从什么时候开始的？"
    show noahteen n pou with dis
    no"一直以来，凯恩。"
    k"我记不清上次见你拿书是什么时候了。"
    no"你知道的，我在你看到我的时候之外还有生活。"
    k"什么，真的？"
    "他假装震惊，但诺亚只是翻了个白眼，转向正在笑他们的奥古斯特。"
    a"你们两个真是好朋友啊，嗯？"
    no"我可能是唯一一个能忍受他的人。"
    show kaineteen n pou with dis
    k"呃，我觉得是相反。"
    show noahteen n ang with dis
    no"也许我们应该不带你一起回家。"
    show kaineteen n hap with dis
    k"呃，反正我们都朝同一个方向走。那样会有点尴尬。"
    show noahteen n hap with dis
    no"随便。反正我确实喜欢阅读，这很酷。"
    no"你也喜欢拍照吗？"
    a"是的，我爸爸一直在教我一点。"
    no"酷……"
    k"我没想到你也这么喜欢摄影，诺亚。"
    show noahteen n neu with dis
    no"你能不能闭嘴？"
    a"哈哈……说实话，我远没有我爸爸那么好……"
    a"总之，只有谈论我有点尴尬……你呢，凯恩？"
    show kaineteen n sho with dis
    k"我？呃……"
    show noahteen n hap with dis
    no"他唯一的兴趣就是美食和自己的外貌。"
    k"嘿！"
    no"告诉我我错了。"
    show kaineteen n shy with dis
    k"……我喜欢做饭，使用保湿霜并不代表我对自己痴迷。"
    no"谁用保湿霜？！"
    show august n neu with dis
    a"别担心，我也用。"
    show noahteen n neu with dis
    no"......."
    no"好吧，我想这也没那么糟……也许我应该试试。"
    show kaineteen n pou with dis
    k"........."
    a"你已经有这么清晰的皮肤了。你真幸运。"
    show noahteen n shy with dis
    no"不……不，我觉得你的皮肤更好。"
    show kaineteen n hap with dis
    k"哦，我们可以给奥古斯特指路。"
    "凯恩微笑着打断了谈话。"
    show noahteen n neu with dis
    no"哦，对，好主意。"
    show august n sho with dis
    a"捷径？"
    k"给你展示更简单，但……如果你在前面左转，有一条穿过山的捷径，可以通往诺亚的房子后面……还有你现在的房子。"
    a"真的吗？太神奇了。"
    no"虽然没短多少，但……我想还是挺漂亮的。"
    k"你什么时候觉得大自然漂亮了？"
    show noahteen n pou with dis
    no"这跟你没关系。"
    stop music fadeout 4.0
    "他们笑着转入绿意盎然的地方，远离了文明的喧嚣。"

    scene bg mountains day with Fade(1.0, 1.0, 1.0)
    play music uplifting fadein 4.0
    "随着交通声渐渐消退，野外的声音也开始在三人周围安静下来。"
    "奥古斯特睁大眼睛，惊奇地四处张望。"
    show noahteen n neu at center
    show august n sho glasses at threeleft
    show kaineteen n hap at threeright
    with dissolve
    a"真美……"
    a "这真是个美丽的小镇……"
    no "我敢肯定你住过比这里更酷的地方……这里什么都没有发生，什么都没有改变。"
    show august n neu with dis
    a "嗯……我住过很多地方，但……没有像这样的。我真羡慕你每天都能看到这个……"
    no "..."
    show noahteen n neublu with dis
    no "那……我们可以再一起走这条路……如果你愿意的话……"
    show kaineteen n neu with dis
    k "如果我们都走同一条路，那就没什么选择了。"
    hide kaineteen with dissolve
    show august at slightleft
    show noahteen at slightright
    with move
    "凯恩插入了谈话，迈出几步走在了另外两人前面。"
    "地面不平，曾经铺成小路的石头被大自然打破并重新占领。诺亚和凯恩一生都在这片地形上行走。"
    "而奥古斯特则小心翼翼地观察着地面，提防着任何可能绊倒他的东西。"
    no "地面有点不平，所以要小心。"
    no "嗯……如果你需要帮忙——"
    show august n sur with dis
    show bg with hpunch
    a "哇！"
    show noahteen n sur with dis
    "在诺亚还没说完之前，奥古斯特就被一根从地面上突出的树根绊倒了。他向前摔去，正好朝着边缘。"
    show bg mountains day:
        xpos 0.67 ypos 1.48 xanchor 0.5 yanchor 1.0 zoom 1.75

    show august m sur at slightleft
    show noahteen m sur at slightright
    with dissolve
    "诺亚以闪电般的速度抓住奥古斯特的手，迅速将他拉回小路上。"
    no "你没事吧？！"
    a "哇，真是太险了……！我没事，我完全没事，我应该注意我走的路。"
    show august m hap with dis
    a "谢谢你，诺亚。要不是你我该怎么办？"
    show noahteen m shy with dis
    no "……没什么大不了的……只是要更小心点……"
    a "我会……尽量的。"
    "诺亚低头看着他手握着奥古斯特的地方。"
    "感觉温暖。"
    "温暖而令人安心。"
    "他眨了几下眼睛，盯着他们连接的地方。"
    a "...?"
    no "哦……抱歉，我……有点分心了……"
    "诺亚迅速抽回手，揉了揉脖子后面。"
    "凯恩转过身继续往前走。奥古斯特脸上始终挂着微笑，急忙追上。"
    a "快点，诺亚，别被落下了！"
    scene bg mountains day
    show noahteen n shy at center
    show august n hap glasses at threeleft
    show kaineteen n neu at threeright
    with dissolve

    k "我们快到了。你看到那条河了吗？"
    show august n sho with dis
    a "哇，还有一条河？"
    k "一旦你到达河边，你就知道快到家了。看那边，树间有个地方？"
    a "这真的是一条捷径……"
    k "夏天的时候，你也可以在那里游泳。"
    show august n hap with dis
    a "如果我夏天在这里，那我们就一起去。"

    scene bg town day with Fade(1.0, 1.0, 1.0):
        xpos 0.5 ypos 1.36 xanchor 0.28 yanchor 1.0 zoom 1.95
    "最后他们在各自的房子前停下。凯恩挥手告别，安静地离开，这让诺亚觉得不太像他。"
    "诺亚想说些什么，但他想不出该说什么。"
    noteen neu "好吧……明天见。"
    a shy "嗯..."
    a shy "你明天想一起走去学校吗？"
    noteen "哦...嗯...好啊，那会很...酷。"
    "奥古斯特又对他微笑，温柔而甜美。"
    a hap"我很高兴。明天见，诺亚。"
    "诺亚发现自己被锁在原地，看着奥古斯特走回他的家。"
    "过了几分钟，他才意识到自己回过神来，走进了家里。"

    scene bg livingroom day
    show noahteen n neu at center
    with Fade(1.0, 1.0, 1.0)
    m "欢迎回家，亲爱的。你今天在学校过得好吗？"
    no "还不错。"
    m"让我快速看看你的笔记。只是想确保你在做功课。"
    show noahteen n pou with dis
    no "我做了。你不需要检查它们。我反正把它们留在学校了。"
    m"那明天把它们带回家，明白吗？"
    no "为什么？"
    f "听你妈妈的话。"
    "他的父亲从沙发上哼了一声，仍然穿着一天辛苦工作的西装。诺亚知道他无法和他们中的任何一个争辩。"
    no "好吧，随便。你注意到隔壁新搬来的人了吗？"
    "他们都愣住了，仿佛提到了一个不舒服的话题。"
    m "...是的，不幸的是。"
    show noahteen n neu with dis
    no "其实我班上有个新男孩。我们一起走回家。"
    stop music fadeout 2.0
    m "诺亚...你不应该和那种人交往。"
    no "什么？为什么？"
    m "........"
    play music sunset fadein 4.0
    f "听你妈妈的话。"
    show noahteen n pou with dis
    no "但为什么？他看起来很好。"
    m "亲爱的，你只需要看看他们就会意识到...嗯，他们在这里并不完全合适，对吧？"
    no "...?"
    m "怎么说呢...他们家里没有女人。我担心他们自己有点过于女性化，如果父亲是个例的话。"
    m "和那种人交往对我们...对你来说不是个好主意。"
    no "我不知道你想说什么。"
    f "...那个男孩的父亲昨天出现在我们家门口。我不知道像他这样的人是怎么能在这里买得起房子的，但显然他们不属于这里。摄影，哼。他应该找一份真正的工作。"
    m "没错...他们看起来没有钱在这里，所以我们把他赶走了。我不想在邻居面前丢脸。"
    show noahteen n ang with dis
    no "他来打招呼，你就把他赶走了？"
    m "亲爱的，你不需要这么说。"
    no "..."
    f "如果儿子和父亲一样，那你就要远离他们。有些地方不太对劲。如果他们两个中的任何一个是同性恋，我也不会感到惊讶，你明白吗？"
    "诺亚对他们的话皱起了眉头。"
    no  "但是—"
    f "没有但是。"
    no "啊！"
    "生气的诺亚冲出了房间。"

    play sound slam fadeout 0.2
    scene bg bedroom day with hpunch
    show noahteen n ang with dissolve
    no "天啊，他们让我如此愤怒..！"
    "诺亚把背包扔在地上，拿出了他的素描本。满心愤怒，他懒散地在空白的页面上涂抹着线条。"
    nothought "他们为什么要如此在意别人的看法...也许我应该去向他们道歉..."
    nothought "啊..."
    "不知为何，有一句话在他脑海中挥之不去。"
    nothought "他们认为奥古斯特...会喜欢男孩？我的意思是，他看起来并不像会...他们甚至没有见过他。"
    show noahteen n neu with dis
    nothought "但是...如果他真的喜欢，那又有什么关系呢。"
    nothought "我想知道他是否真的喜欢..."
    "他的思绪不断循环，旋转着，直到铅笔在纸上用力划过，最终铅芯断了。"

    python:
        achievement.grant("Prologue_Complete")
        achievement.sync()

    stop music fadeout 3.0
    jump chapter1





    #
