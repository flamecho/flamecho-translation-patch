################################
## MOUSE CURSOR NOTES
## In Images, define each cursor image
## The name for each should match whatever iteminhand can be set to
## In Inventory, clicking at item should change iteminhand to the right image (thus changing the HOVER cursor to the same) and should change default cursor
## In each imagebutton, if iteminhand == None, use the original hover cursor, otherwise use whatever iteminhand is set to

default snap1_playeranswer = ""
default snap2_playeranswer = ""
default snap3_playeranswer = ""
default snap4_playeranswer = ""
default snap5_playeranswer = ""
default snap6_playeranswer = ""
default snap7_playeranswer = ""
default snap8_playeranswer = ""
default snap9_playeranswer = ""
default snap10_playeranswer = ""
default snap11_playeranswer = ""
default snap12_playeranswer = ""
default snap13_playeranswer = ""


default chaptertwo_10 = False
default chaptertwo_11 = False
default chaptertwo_12 = False
default chaptertwo_13 = False
default chaptertwo_14 = False
default chaptertwo_15 = False
default chaptertwo_16 = False
default chaptertwo_17 = False
default chaptertwo_18 = False
default chaptertwo_19 = False

default chaptertwo_20 = False
default chaptertwo_21 = False
default chaptertwo_22 = False
default chaptertwo_23 = False
default chaptertwo_24 = False
default chaptertwo_25 = False
default chaptertwo_26 = False
default chaptertwo_27 = False
default chaptertwo_28 = False
default chaptertwo_29 = False

default chaptertwo_30 = False
default chaptertwo_31 = False
default chaptertwo_32 = False
default chaptertwo_33 = False
default chaptertwo_34 = False
default chaptertwo_35 = False
default chaptertwo_36 = False
default chaptertwo_37 = False
default chaptertwo_38 = False
default chaptertwo_39 = False

default chaptertwo_40 = False
default chaptertwo_41 = False
default chaptertwo_42 = False
default chaptertwo_43 = False
default chaptertwo_44 = False
default chaptertwo_45 = False
default chaptertwo_46 = False
default chaptertwo_47 = False
default chaptertwo_48 = False
default chaptertwo_49 = False

default chaptertwo_50 = False
default chaptertwo_51 = False
default chaptertwo_52 = False
default chaptertwo_53 = False
default chaptertwo_54 = False
default chaptertwo_55 = False
default chaptertwo_56 = False
default chaptertwo_57 = False
default chaptertwo_58 = False
default chaptertwo_59 = False

default chaptertwo_60 = False
default chaptertwo_61 = False
default chaptertwo_62 = False
default chaptertwo_63 = False
default chaptertwo_64 = False
default chaptertwo_65 = False
default chaptertwo_66 = False
default chaptertwo_67 = False
default chaptertwo_68 = False
default chaptertwo_69 = False

default chaptertwo_70 = False
default chaptertwo_71 = False
default chaptertwo_72 = False
default chaptertwo_73 = False
default chaptertwo_74 = False
default chaptertwo_75 = False
default chaptertwo_76 = False
default chaptertwo_77 = False
default chaptertwo_78 = False
default chaptertwo_79 = False

default chaptertwo_80 = False
default chaptertwo_81 = False
default chaptertwo_82 = False
default chaptertwo_83 = False
default chaptertwo_84 = False
default chaptertwo_85 = False
default chaptertwo_86 = False
default chaptertwo_87 = False
default chaptertwo_88 = False
default chaptertwo_89 = False

default chaptertwo_90 = False
default chaptertwo_91 = False
default chaptertwo_92 = False
default chaptertwo_93 = False
default chaptertwo_94 = False
default chaptertwo_95 = False
default chaptertwo_96 = False
default chaptertwo_97 = False
default chaptertwo_98 = False
default chaptertwo_99 = False

default chaptertwo_100 = False
default chaptertwo_101 = False
default chaptertwo_102 = False
default chaptertwo_103 = False
default chaptertwo_104 = False
default chaptertwo_105 = False
default chaptertwo_106 = False
default chaptertwo_107 = False
default chaptertwo_108 = False
default chaptertwo_109 = False

###### For puzzle photo
init -5:
    $ current_photo_zoompiece1 = 0.5
    $ current_photo_zoompiece2 = 0.5
    $ current_photo_zoompiece3 = 0.5
    $ current_photo_zoompiece4 = 0.5
    $ current_photo_zoompiece5 = 0.5
    $ current_photo_zoompiece6 = 0.5
    $ current_photo_zoompiece7 = 0.5
    $ current_photo_zoompiece8 = 0.5
    $ current_photo_zoompiece9 = 0.5
    $ current_photo_zoompiece10 = 0.5
    $ current_photo_zoompiece11 = 0.5
    $ current_photo_zoompiece12 = 0.5
    $ current_photo_zoompiece13 = 0.5

image piece13a = At("images/puzzles/chapter_2/puzzle pieces/piece13.png", photomode_zoom(1.0))
image piece13b = At("images/puzzles/chapter_2/puzzle pieces/piece13.png", photomode_zoom(0.5))
image piece12a = At("images/puzzles/chapter_2/puzzle pieces/piece12.png", photomode_zoom(1.0))
image piece12b = At("images/puzzles/chapter_2/puzzle pieces/piece12.png", photomode_zoom(0.5))
image piece11a = At("images/puzzles/chapter_2/puzzle pieces/piece11.png", photomode_zoom(1.0))
image piece11b = At("images/puzzles/chapter_2/puzzle pieces/piece11.png", photomode_zoom(0.5))
image piece10a = At("images/puzzles/chapter_2/puzzle pieces/piece10.png", photomode_zoom(1.0))
image piece10b = At("images/puzzles/chapter_2/puzzle pieces/piece10.png", photomode_zoom(0.5))
image piece9a = At("images/puzzles/chapter_2/puzzle pieces/piece9.png", photomode_zoom(1.0))
image piece9b = At("images/puzzles/chapter_2/puzzle pieces/piece9.png", photomode_zoom(0.5))
image piece8a = At("images/puzzles/chapter_2/puzzle pieces/piece8.png", photomode_zoom(1.0))
image piece8b = At("images/puzzles/chapter_2/puzzle pieces/piece8.png", photomode_zoom(0.5))
image piece7a = At("images/puzzles/chapter_2/puzzle pieces/piece7.png", photomode_zoom(1.0))
image piece7b = At("images/puzzles/chapter_2/puzzle pieces/piece7.png", photomode_zoom(0.5))
image piece6a = At("images/puzzles/chapter_2/puzzle pieces/piece6.png", photomode_zoom(1.0))
image piece6b = At("images/puzzles/chapter_2/puzzle pieces/piece6.png", photomode_zoom(0.5))
image piece5a = At("images/puzzles/chapter_2/puzzle pieces/piece5.png", photomode_zoom(1.0))
image piece5b = At("images/puzzles/chapter_2/puzzle pieces/piece5.png", photomode_zoom(0.5))
image piece4a = At("images/puzzles/chapter_2/puzzle pieces/piece4.png", photomode_zoom(1.0))
image piece4b = At("images/puzzles/chapter_2/puzzle pieces/piece4.png", photomode_zoom(0.5))
image piece3a = At("images/puzzles/chapter_2/puzzle pieces/piece3.png", photomode_zoom(1.0))
image piece3b = At("images/puzzles/chapter_2/puzzle pieces/piece3.png", photomode_zoom(0.5))
image piece2a = At("images/puzzles/chapter_2/puzzle pieces/piece2.png", photomode_zoom(1.0))
image piece2b = At("images/puzzles/chapter_2/puzzle pieces/piece2.png", photomode_zoom(0.5))
image piece1a = At("images/puzzles/chapter_2/puzzle pieces/piece1.png", photomode_zoom(1.0))
image piece1b = At("images/puzzles/chapter_2/puzzle pieces/piece1.png", photomode_zoom(0.5))


transform photomode_zoom(z):
    zoom z


init:
    $ iteminhand = "None" # Start with nothing in hand
    $ default_mouse = "default"

    # People first clicked trackers
    $ person1_firstclicked = False
    $ person2_firstclicked = False
    $ person3_firstclicked = False #reuben
    $ person4_firstclicked = False
    $ person5_firstclicked = False #daisy
    $ person6_firstclicked = False #asher


    $ asher_talkedtoreuben = False # Check if player has asked Reuben to make up with Asher
    $ toldasher_talkedtorueben = False # Check is player has told Asher what Reuben said
    $ reuben_whatareyoureading = False # Checks if the player asked what Reuben was reading/learned that Asher dropped out of school
    $ asher_dropoutofschool1 = False # Checks if player asked Asher if he dropped out of school (know Reuben)
    $ asher_dropoutofschool2 = False # Checks if player insisted Asher dropped out of school (from Professor Pearson)
    $ asher_askeddaisy = False # Checks if the player asked Asher if he knows Daisy's number
    $ daisy_solvedphone = False # Checks if the player has solved Daisy's phone code
    $ daisy_asherreuben = False # Checks if the player asked Daisy about Asher and Reuben fighting
    $ reuben_solveddiary = False # Checks if the player has unlocked Reuben's diary
    $ daisy_photopieces = False # Checks if the player received the photo pieces from Daisy
    $ asher_photopieces = False # Checks if the player received the photo pieces from Asher
    $ asher_askedrent = False # Checks if the player has asked Asher why he isn't paying rent
    $ elijah_photocomplete = False # Checks if the player has put Elijah's photo back together
    $ PP_askedfailed = False # Checks if the player has asked (and failed) to find out Professor Pearson's entertainment issue
    $ PP_askedsucc = False #  Checks if the player has asked (and succeeded to find out Professor Pearson's entertainment issue
    $ PP_talkedtoasher = False # Checks if the player has told PP that they told Asher to retake the class
    $ elijah_givebackpiece = False # Checks if the player has given the photo piece back to Elijah
    $ elijah_givetape = False # Checks if the player gave the tape to Elijah
    $ PP_showedpaper = False # Checks to see if player showed the paper to PP and then closed the minigame
    $ youngnoah_august = False # Checks if the player asked the younger Noah about August
    $ asher_messageplayer = ""
    $ asher_messagercorrect = ["...under the starry sky on a warm summer night", "under the starry sky on a warm summer night"]
    $ daisy_messageplayer = ""
    $ daisy_messagercorrect = ["dreambound"]
    $ asherpaper_pp_tracker = False # Checks if the player showed PP some random items for dialogue

    # Item pick up tracker
    $ pen = False
    $ tape = False
    $ photopiece_singular = False
    $ asherpaper_1 = False
    $ asherpaper_2 = False
    $ photopieces = False

    $ photopiece_counter = 0

    $ ashermessagehint = 1
    $ reubendiaryhint = 1
    $ elijahhint = 1
    $ pphint = 1
    $ daisyhint = 1

image person1 = "images/bgs/escape2/person1_idle.png"
image person2 = "images/bgs/escape2/person2_idle.png"
image person3 = "images/bgs/escape2/person3_idle.png"
image person4 = "images/bgs/escape2/person4_idle.png"
image person5 = "images/bgs/escape2/person5_idle.png"
image person6 = "images/bgs/escape2/person6_idle.png"
image bg heavenescape = "images/bgs/escape2/heaven escape.png"

label chapter2escape:
    $menu = nvl_menu
    $ quick_menu = False
    window hide dissolve
    $ chapter = 2 # set the chapter at the start of each chapter
    #$_skipping = False TODO: turn this back off after
    $ iteminhand = "None"

label chapter2escaperepeat:
    nvl clear
    scene bg heavenescape onlayer farback:
        zoom 0.7 yalign 0.5 xalign 0.7

    show person1 onlayer farback:
        zoom 1.1 yalign 0.5 xalign 0.6
    show person2 onlayer farback:
        zoom 1.1 yalign 0.5 xalign 0.6
    show person3 onlayer farback:
        zoom 1.1 yalign 0.5 xalign 0.6
    show person4 onlayer farback:
        zoom 1.1 yalign 0.5 xalign 0.6
    show person5 onlayer farback:
        zoom 1.1 yalign 0.5 xalign 0.6
    show person6 onlayer farback:
        zoom 1.1 yalign 0.5 xalign 0.6

    with dissolve

    $ renpy.transition(dissolve)
    $ renpy.call_screen("heavenescape", _layer="farback") # calls the escape room segment


screen heavenescape:
    on "show" action Show("inventoryshow", dissolve)
    on "hide" action Hide("inventoryshow", dissolve)


############# PERSON 6 | ASHER
    vbox yalign 0.5 xalign 0.6:
        imagebutton auto "images/bgs/escape2/person6_%s.png":
            if person6_firstclicked == False:
                action [SetVariable("person6_firstclicked", True), Jump("person6_firstscene")] tooltip "艾许"
            elif person6_firstclicked == True and iteminhand == "None": # If Asher has been spoken to before and there's no item in hand - JUMP TO ASHER HUB
                action [Jump("person6_hub")] tooltip "艾许"
            elif iteminhand == "pen":
                action [Jump("person6_pen")] tooltip "艾许"
            elif iteminhand == "photopieces" and person4_firstclicked and not asher_photopieces:
                action [Jump("person6_photopieces")] tooltip "艾许"
            elif iteminhand == "photopieces" and not person4_firstclicked:
                action [Jump("person6_photopieces2")] tooltip "艾许"
            elif iteminhand == "photopieces" and asher_photopieces:
                action [Jump("person6_photopieces3")] tooltip "艾许"
            elif iteminhand == "tape":
                action [Jump("person6_tape")] tooltip "艾许"
            elif iteminhand == "photopiece_singular":
                action [Jump("person6_photopiecesingular")] tooltip "艾许"
            elif iteminhand == "asherpaper_1": # Show half note to Asher (again, he's going to like this)
                action [Jump("person6_note1")] tooltip "艾许"
            elif iteminhand == "asherpaper_2": # Show full paper to Asher
                action [Jump("person6_note2")] tooltip "艾许"

            if iteminhand == "None":
                mouse "imagemap"
            else:
                mouse "[iteminhand]"

            focus_mask True at bgzoom

############# PERSON 5 | DAISY
    vbox yalign 0.5 xalign 0.6:
        imagebutton auto "images/bgs/escape2/person5_%s.png":
            if person5_firstclicked == False:
                action [SetVariable("person5_firstclicked", True), Jump("person5_firstscene")] tooltip "???"
            elif person5_firstclicked == True and iteminhand == "None": # If Daisy has been spoken to before and there's no item in hand - JUMP TO Daisy HUB
                action [Jump("person5_hub")] tooltip "黛西"
            elif iteminhand == "pen":
                action [Jump("person5_pen")] tooltip "黛西"
            elif iteminhand == "tape":
                action [Jump("person5_tape")] tooltip "黛西"
            elif iteminhand == "photopieces" and person4_firstclicked and not daisy_photopieces: # Photopieces in hand, person 4 spoken to (learned about gathering photos) and haven't received Daisy's pieces
                action [Jump("person5_photopieces")] tooltip "黛西"
            elif iteminhand == "photopieces" and not person4_firstclicked:
                action [Jump("person5_photopieces2")] tooltip "黛西"
            elif iteminhand == "photopieces" and daisy_photopieces:
                action [Jump("person5_photopieces3")] tooltip "黛西"
            elif iteminhand == "photopiece_singular":
                action [Jump("person5_photopiecessingular")] tooltip "黛西"
            elif iteminhand == "asherpaper_2" and "daisy_solvedphone":
                action [Jump("person5_phonesolved")] tooltip "黛西"
            elif iteminhand == "asherpaper_1" or "asherpaper_2" and not "daisy_solvedphone":
                action [Jump("person5_asherpaper")] tooltip "黛西"



            if iteminhand == "None":
                mouse "imagemap"
            else:
                mouse "[iteminhand]"

            focus_mask True at bgzoom


############# PERSON 4 | ASHER LANDLORD ELIJAH
    vbox yalign 0.5 xalign 0.6:
        imagebutton auto "images/bgs/escape2/person4_%s.png":
            if person4_firstclicked == False:
                action [SetVariable("person4_firstclicked", True), Jump("person4_firstscene")] tooltip "???"
            elif person4_firstclicked and iteminhand == "None": # Spoken to before, jump to hub with nothing in han
                action [Jump("person4_hub")] tooltip "以利亚"
            elif iteminhand == "tape":
                action [Jump("person4_tape")] tooltip "以利亚"
            elif iteminhand == "pen":
                action [Jump("person4_pen")] tooltip "以利亚"
            elif iteminhand == "photopiece_singular" and tape:
                action [Jump("person4_photopiecesingularcomplete")] tooltip "以利亚"

            elif iteminhand == "photopiece_singular":
                action [Jump("person4_photopiecesingular")] tooltip "以利亚"

            elif iteminhand == "photopieces":
                action [Jump("person4_photopieces")] tooltip "以利亚"
            elif iteminhand == "asherpaper_1" or "asherpaper_2":
                action [Jump("person4_asherpaper")] tooltip "以利亚"




            if iteminhand == "None":
                mouse "imagemap"
            else:
                mouse "[iteminhand]"

            focus_mask True at bgzoom


############# PERSON 3 | REUBEN
    vbox yalign 0.5 xalign 0.6:
        imagebutton auto "images/bgs/escape2/person3_%s.png":
            if person3_firstclicked == False:
                action [SetVariable("person3_firstclicked", True), Jump("person3_firstscene")]
                if person6_firstclicked == False:
                    tooltip "???"
                else:
                    tooltip "鲁本"

            elif person3_firstclicked == True and iteminhand == "None": # If Reuben has been spoken to before and there's no item in hand - JUMP TO Reuben HUB
                action [Jump("person3_hub")] tooltip "鲁本"
            elif iteminhand == "tape": # Show tape to Reuben
                action [Jump("person3_tape")] tooltip "鲁本"
            elif iteminhand == "pen":
                action [Jump("person3_pen")] tooltip "鲁本"
            elif iteminhand == "asherpaper_1": # Show half note to Reuben
                action [Jump("person3_note1")] tooltip "鲁本"
            elif iteminhand == "asherpaper_2": # Show full note to Reuben
                action [Jump("person3_note2")] tooltip "鲁本"
            elif iteminhand == "photopiece_singular": # Show photopiece with quote on back
                action [Jump("person3_photopiecesingular")] tooltip "鲁本"
            elif iteminhand == "photopieces": # Show photopieces (any)
                action [Jump("person3_photopieces")] tooltip "鲁本"

            if iteminhand == "None":
                mouse "imagemap"
            else:
                mouse "[iteminhand]"

            focus_mask True at bgzoom


############# PERSON 2 | Professor Pearson
    vbox yalign 0.5 xalign 0.6:
        imagebutton auto "images/bgs/escape2/person2_%s.png":
            if person2_firstclicked == False:
                action [SetVariable("person2_firstclicked", True), Jump("person2_firstscene")] tooltip "???"
            elif person2_firstclicked == True and iteminhand == "None": # If PP has been spoken to before and there's no item in hand - JUMP TO PP HUB
                action [Jump("person2_hub")] tooltip "皮尔森教授"
            elif iteminhand == "tape": # Show tape
                action [Jump("person2_tape")] tooltip "皮尔森教授"
            elif iteminhand == "pen":
                action [Jump("person2_pen")] tooltip "皮尔森教授"
            elif iteminhand == "photopieces": # Show photopieces (any)
                action [Jump("person2_photopieces")] tooltip "皮尔森教授"
            elif iteminhand == "photopiece_singular" and tape: # Show photopiece with quote on back after completing the word search puzzle for PP
                action [Jump("person2_photopiecesingular_after")] tooltip "皮尔森教授"
            elif iteminhand == "photopiece_singular" and not PP_talkedtoasher: # Show photopiece with quote on back BEFORE telling the Professor they spoke to Asher
                action [Jump("person2_photopiecesingular_fail")] tooltip "皮尔森教授"
            elif iteminhand == "photopiece_singular" and PP_talkedtoasher: # Show photopiece with quote on back AFTER telling the Professor they spoke to Asher
                action [Jump("person2_photopiecesingular_succ")] tooltip "皮尔森教授"
            elif iteminhand == "asherpaper_2" or "asherpaper_1":
                action [Jump("person2_asherpaper")] tooltip "皮尔森教授"

            if iteminhand == "None":
                mouse "imagemap"
            else:
                mouse "[iteminhand]"

            focus_mask True at bgzoom

    $ tooltip = GetTooltip()

    if tooltip:
        vbox:
            add "gui/Custom/Information/name.png"
            yalign 0.9 xalign 0.5
        vbox:
            text "[tooltip]" size 40 color "#FFFFFF"
            yalign 0.88 xalign 0.5


############# PERSON 1 | Young Noah
    vbox yalign 0.5 xalign 0.6:
        imagebutton auto "images/bgs/escape2/person1_%s.png":
            if person1_firstclicked == False:
                action [SetVariable("person1_firstclicked", True), Jump("person1_firstscene")] tooltip "???"
            elif person1_firstclicked == True and iteminhand == "None": # If Noah has been spoken to before and there's no item in hand - JUMP TO NOAH HUB
                action [Jump("person1_hub")] tooltip "诺亚(？)"
            elif iteminhand == "photopieces": # Show photopieces (any):
                action [Jump("person1_photopieces")] tooltip "诺亚(？)"
            elif iteminhand == "tape": # Show tape
                action [Jump("person1_tape")] tooltip "诺亚(？)"
            elif iteminhand == "pen":
                action [Jump("person1_pen")] tooltip "诺亚(？)"
            elif iteminhand == "photopiece_singular":
                action [Jump("person1_photopiecesingular")] tooltip "诺亚(？)"
            elif iteminhand == "asherpaper_2" or "asherpaper_1":
                action [Jump("person1_asherpaper")] tooltip "诺亚(？)"


            if iteminhand == "None":
                mouse "imagemap"
            else:
                mouse "[iteminhand]"

            focus_mask True at bgzoom

    $ tooltip = GetTooltip()

    if tooltip:
        vbox:
            add "gui/Custom/Information/name.png"
            yalign 0.9 xalign 0.5
        vbox:
            text "[tooltip]" size 40 color "#FFFFFF"
            yalign 0.88 xalign 0.5

##### SCENES

######## Person 6 | Asher ##############
label person6_firstscene:
    hide heavenescape

    $ gametype = "NVL"
    $ charleft = "诺亚"
    $ charright = "艾许"

    $cs_left = "noah n ann"
    $cs_right = "asher n neu"


    $ nvl_show(Dissolve(1))
    nv "站在队伍前面第六个的是艾许，双臂交叉，脚在地上不耐烦地敲打着。"
    nv "当他看到诺亚和克劳再次走近他时，他只是翻了个白眼，转过头去。"
    nonvl "..."
    $ charright = "克劳"
    $ cs_right = "crow n neu"
    cnvl "对不起，我们能问你几个问题吗？"
    $ charright = "艾许"
    $ cs_right = "asher n mock"
    anvl "滚开。"
    $cs_left = "noah n fro"
    nonvl "别那样对他说话，混蛋。"
    anvl "为什么不行？"
    anvl "我想怎么做就怎么做。"
    anvl "如果你有什么问题，随便{i}滚开{/i}吧。"
    $ charright = "克劳"
    $ cs_right = "crow n sur"
    cnvl "拜托，我们只是想帮助你。如果你能..."
    $ charright = "艾许"
    $ cs_right = "asher n mock"
    anvl "我才不要从{i}他{/i}那里接受{i}任何东西{/i}。"
    $ cs_right = "asher n fro"
    anvl "你毁了我的生活。"
    $cs_left = "noah n sur"
    nonvl "对不起？"
    $cs_left = "noah n ang"
    nonvl "我毁了你的生活？"
    nonvl "你让我每一天都过得生不如死，却没有任何理由！"
    anvl "对，对，对，完全没有任何理由。"
    anvl "更多的特权废话。"
    nonvl "我完全不知道你在说什么...！"
    $ charright = "克劳"
    $ cs_right = "crow n sur"
    cnvl "让我们都冷静下来，好吗？"
    cnvl "艾许。你想通过那些大门，不是吗？"
    $ charright = "艾许"
    $ cs_right = "asher n fro"
    anvl "再次冷静地说，这不是{i}他妈的很明显的事情{/i}吗？"
    $ charright = "克劳"
    $ cs_right = "crow n sad"
    cnvl "我们会让这条队伍继续前进，但你必须配合我们——至少一点点，好吗？"
    $ charright = "艾许"
    $ cs_right = "asher n fro"
    anvl "..."
    $ cs_right = "asher n neu"
    anvl "如果你们不先帮助我，我是不会帮忙的。"
    nonvl "我们帮你通过那些愚蠢的大门就是在{i}帮助你{/i}。"
    nv "他耸了耸肩，又交叉起双臂，拒绝动弹。"
    $cs_left = "noah n ann"
    nonvl "好吧，随便。你到底想要什么？"
    nonvl "除了我们正在为你做的其他事情之外。"
    nv "他点了点头，示意了队伍前面几个位置，那里站着一个头发凌乱的男人。从背后看，诺亚认不出他是谁。"
    anvl "让他来跟我说话。"
    if person3_firstclicked:
        nonvl "...鲁本？"
        $ charright = "艾许"
        $ cs_right = "asher n sad"
        anvl "你已经见过他了？"
        nonvl "是的。"

    else:
        $ charright = "克劳"
        $ cs_right = "crow n sur"
        cnvl "他是谁？"
        $ charright = "艾许"
        $ cs_right = "asher n sad"
        anvl "..."
        anvl "鲁本。"
        nonvl "鲁本...？"
        nonvl "等等，是你上学时的那个鲁本？你最好的朋友？"

    nonvl "看来你们已经不再是朋友了，看来你的性格就是这样。"
    $ charright = "克劳"
    $ cs_right = "crow n sur"
    cnvl "...你有什么特别想让我们对他说的吗？"
    $ charright = "艾许"
    $ cs_right = "asher n sad"
    anvl "...{i}在温暖的夏夜下，在星空之下{/i}。"
    $ charright = "克劳"
    $ cs_right = "crow n neu"
    cnvl "真是神秘兮兮的。"
    $ charright = "艾许"
    $ cs_right = "asher n sad"
    anvl "他会明白的。"
    nonvl "..."
    $cs_left = "noah n neu"
    nonvl "你自己去跟他说吧。"
    anvl "那我就要失去我的位置了。"
    nonvl "我可以帮你保住。"
    anvl "...."
    $ charright = "克劳"
    $ cs_right = "crow n hap"
    cnvl "嗯..."
    cnvl "没关系，我们可以试试。"
    cnvl "只要你答应之后会帮助我们。"
    $ charright = "艾许"
    $ cs_right = "asher n sad"
    anvl "...好吧，随便你。"
    $ charright = "克劳"
    $ cs_right = "crow n neu"
    nv "说完这些，克劳和诺亚走到了一边，远离了艾许的耳朵。"
    $cs_left = "noah n ann"
    nonvl "他不配得到我们的帮助。"
    cnvl "我知道。"
    cnvl "但我们还是会帮他，对吗？"
    nonvl "也没什么选择..."
    cnvl "有很多选择。"
    $ cs_right = "crow n hap"
    cnvl "你选择去帮助。也许在你内心深处，你还希望能在这里找到你哥哥的人性。"
    nonvl "..."
    nonvl "那你呢？"
    $ cs_right = "crow n sur"
    cnvl "你什么意思？"
    nonvl "你为什么在这里？你为什么要帮忙？"
    nonvl "你从中得到了什么？"
    $ cs_right = "crow n hap"
    nv "那个金发男子用手指轻轻地抚摸着嘴唇，露出了一个温和的微笑，显然没有打算给出任何真正的解释。"
    cnvl "..."
    cnvl "我只是想减轻你的负担，哪怕只是一点点。"
    cnvl "这就是我所要求的全部。"
    nonvl "..."


    nvl clear

    $ nvl_hide(Dissolve(0.6))
    jump chapter2escaperepeat

label person6_hub: ###### ASHER HUB
    hide heavenescape

    $ gametype = "NVL"
    $ charleft = "诺亚"
    $ charright = "艾许"

    $cs_left = "noah n ann"
    $cs_right = "asher n neu"


    if asher_dropoutofschool2:
        nv "艾许揉了揉后颈，当诺亚走近时。"
        nv "他似乎想说些什么，但最终还是闭上了嘴。"

    elif toldasher_talkedtorueben:
        nv "艾许双臂交叉，深深地皱着眉头，一直盯着鲁本，等待着。"
        $cs_right = "asher n fro"
        anvl "你想要什么？"
    else:
        nv "艾许仍然站在之前那对人离开的地方。"
        nv "和之前一样，他双臂交叉，脚在云层上无声地轻轻敲打。"

    menu asher_hub:
        "你让我对鲁本说什么来着？" if not asher_talkedtoreuben:
            nonvl "你让我对鲁本说什么来着？"
            $cs_right = "asher n fro"
            $ charright = "艾许"
            anvl "你是认真的吗？"
            nonvl "我忘记了，好吗？"
            nv "艾许摇了摇头，好像真的不敢相信自己听到的。"
            $cs_right = "asher n sad"
            anvl "{i}在温暖的夏夜下，在星空之下。{/i}"
            anvl "这次试着记住吧。"
            nonvl "好吧，随便..."
            nvl clear
            jump asher_hub

        "我跟鲁本说话了" if asher_talkedtoreuben and not toldasher_talkedtorueben:
            $ toldasher_talkedtorueben = True
            $cs_left = "noah n neu"
            nonvl "我跟鲁本说话了。"
            $ charright = "艾许"
            $cs_right = "asher n sur"
            anvl "他说了什么？！"
            nv "这一次，艾许看起来既慌张又伤心。这完全不是诺亚想象中的他的样子。"
            nonvl "...他说他稍后会来找你。"
            $cs_right = "asher n sad"
            anvl "...好，很好..."
            nonvl "那你做了什么？"
            $cs_right = "asher n fro"
            anvl "这不关你的事。"
            nonvl "如果你让我做你的跑腿小弟，那就是我的事了。"
            anvl "..."
            $cs_right = "asher n sad"
            anvl "...我对他那些最重要的事情很刻薄。"
            $cs_left = "noah n sho"
            nonvl "不...你，刻薄？这一点也不像你。"
            $cs_right = "asher n fro"
            anvl "滚开。"
            anvl "我什么都不会告诉你。"
            $ charright = "克劳"
            $cs_right = "crow n neu"
            cnvl "但是既然我们帮了你，你现在会帮我们了，对吗？"
            $ charright = "艾许"
            $cs_right = "asher n sad"
            anvl "好吧，随便你。"
            anvl "给，拿着这个。"
            $cs_left = "noah n neu"
            $ asherpaper_1 = True
            nonvl "...一半张纸？哇，谢谢。"
            $cs_right = "asher n mock"
            anvl "用你的眼睛看看吧。"
            anvl "我以为那些艺术界大腕擅长这种事。"
            $cs_left = "noah n fro"
            nonvl "艺术界大腕？"
            nonvl "别开玩笑了。要是你在我身边，我怎么可能在艺术界有所成就。"
            $cs_right = "asher n fro"
            anvl "要是我在你身边？"
            anvl "什么，所以我弟弟的死是我的错？"
            $cs_left = "noah n ang"
            nonvl "闭嘴...！"
            nonvl "不要...不要你敢...不要你敢提到他...！"
            anvl "那就别装作我才是你搞砸一切的罪魁祸首。"
            nonvl "....."
            $cs_left = "noah n fro"
            nonvl "我恨你。我恨你恨得要命。"
            anvl "这种感觉是互相的。"
            nonvl "我从来没对你做过什么...！"
            $cs_right = "asher n ang"
            anvl "你有我从未拥有的一切机会...！"
            anvl "你得到的一切都是锦上添花，但你从未珍惜过！"
            anvl "你可以学习任何你想学的，你能买到任何你需要的，你得到的一切都是现成的！"
            nonvl "你和我有什么区别...？"
            $cs_right = "asher n fro"
            anvl "....."
            anvl "自己想办法吧。我不想管了。"
            nonvl "你...！"
            $ charright = "克劳"
            $cs_right = "crow n sad"
            cnvl "诺亚。"
            $cs_left = "noah n ann"
            nonvl "..."
            nv "克劳把手放在诺亚的手上。这个动作立刻平息了这个男人的情绪。"
            nonvl "...好吧。"
            nvl clear
            jump asher_hub

        "你是不是辍学了？" if reuben_whatareyoureading and not asher_dropoutofschool1:
            $ asher_dropoutofschool1 = True
            $cs_left = "noah n sho"
            nonvl "你是不是真的辍学了？"
            $ charright = "艾许"
            $cs_right = "asher n sur"
            anvl "..."
            anvl "什...什么？"
            anvl "我？辍学？我可不像你。"
            anvl "谁告诉你的？"
            nonvl "鲁本。"
            $cs_right = "asher n fro"
            anvl "...他只是编造谎言来报复我。"
            $cs_left = "noah n ann"
            nonvl "是吗..."
            anvl "我不是失败者...我不像你..."
            nvl clear
            jump asher_hub

        "黛西的电话号码是多少？" if person5_firstclicked and not asher_askeddaisy and not daisy_solvedphone:
            $ asher_askeddaisy = True
            $cs_left = "noah n neu"
            nonvl "嘿，黛西的电话号码是多少？"
            $ charright = "艾许"
            $cs_right = "asher n sur"
            anvl "什么？"
            anvl "你怎么认识黛西的...？"
            $cs_left = "noah n hap"
            nonvl "这不关你的事。"
            $cs_right = "asher n fro"
            anvl "那你为什么要告诉我？！"
            anvl "我不会把她的号码告诉任何人的。"
            nonvl "我敢打赌你连她的号码都记不住。"
            anvl "我当然记得！"
            nonvl "证明给我看。"
            anvl "啊！"
            nonvl "难怪她和你分手。"
            $cs_right = "asher n ang"
            anvl "你这个小...."
            nv "克劳站在两兄弟之间，阻止了阿什尔举起的拳头。"
            $ charright = "克劳"
            $cs_right = "crow n sho"
            cnvl "好了好了，我们别打架，好吗？"
            $ charright = "艾许"
            $cs_right = "asher n mock"
            anvl "哼。"
            $cs_left = "noah n fro"
            anvl "我本来想让你滚回你的坟墓里，不过你在这里也很合理。"
            nv "阿什尔对克劳咧嘴一笑，克劳只是摇了摇头。"
            $ charright = "克劳"
            $cs_right = "crow n sho"
            cnvl "你不需要攻击别人来掩盖你自己的不安全感。"
            $ charright = "艾许"
            $cs_right = "asher n sad"
            anvl "随便吧。"
            nvl clear
            jump asher_hub

        "你为什么没有交房租？" if person4_firstclicked and not asher_askedrent:
            $ asher_askedrent = True
            $cs_left = "noah n neu"
            nonvl "有什么原因你一直没交房租吗？"
            $ charright = "艾许"
            $ cs_right = "asher n sur"
            anvl "我...我一直在交啊！"
            nonvl "真的吗？你的房东说你一直没交。"
            anvl "妈的，他来了...？"
            nv "诺亚双臂交叉，等待着回答。"
            $ cs_right = "asher n fro"
            anvl "这关你什么事？"
            anvl "钱很紧张，每个人都会遇到这种情况。"
            nonvl "我以为爸爸妈妈会...会一直替你付房租。"
            $ cs_right = "asher n smi"
            nv "阿什尔脸上露出一丝得意的笑容。"
            anvl "你怎么会这么天真？"
            anvl "自从你出现在我面前，我就几乎被完全排斥在外了。"
            $cs_left = "noah n sho"
            nonvl "...什么？"
            nonvl "他们所做的就是把我和你比较——告诉我我有多不如你！"
            $cs_left = "noah n sho"
            nonvl "他们为什么会..."
            $ cs_right = "asher n sad"
            nv "艾许耸了耸肩。他没有找到诺亚想要的答案。"
            nv "他们两个都永远不会有。"
            nvl clear
            jump asher_hub

        "你真的退学了" if asher_dropoutofschool1 and not asher_dropoutofschool2 and person2_firstclicked:
            $ asher_dropoutofschool2 = True
            $ charleft = "诺亚"
            $ charright = "艾许"

            $cs_left = "noah n ann"
            $cs_right = "asher n fro"
            anvl "天啊，你还在这里吗？"
            nonvl "很遗憾。"
            nonvl "相信我，我也不想再待在这里了。"
            anvl "那就快点回到你的...不管你在做什么。"
            anvl "涂鸦？"
            nonvl "..."
            nonvl "有什么不对吗？"
            anvl "..."
            $cs_right = "asher n sad"
            anvl "...没什么。"
            nv "艾许看向一边，深深地叹了口气。"
            $cs_left = "noah n neu"
            nonvl "...我和某个教授谈过。"
            anvl "这一天越来越糟糕了..."
            nonvl "她说你挂了她的课。这让我觉得你确实退学了。"
            $cs_right = "asher n fro"
            anvl "好吧，行！"
            anvl "随便吧！是的，我退学了。谁在乎？"
            anvl "你现在满意了吗？"
            $cs_left = "noah n sho"
            nonvl "为什么这会让我高兴？"
            anvl "你是在告诉我，你不高兴看到你讨厌的人失败吗？"
            $cs_left = "noah n ann"
            nonvl "..."
            notnvl "...不知为什么，我没有。"
            nonvl "...她希望你重修这门课。"
            anvl "就为了让她再次把我挂掉？绝对不行。"
            nonvl "不，她真的希望你重修。我想她相信你。"
            $cs_right = "asher n sad"
            anvl "..."
            anvl "...真是个好笑的笑话。"
            nonvl "...发生了什么？"
            anvl "哈。"
            anvl "我也不知道。"
            anvl "不像你，你可以随意进入任何一个课堂并取得优异成绩，我必须拼命工作才能获得好成绩。"
            nv "他的声音里带着嫉妒。"
            anvl "日夜学习...努力维持一种毫不费力的样子..."
            anvl "然后突然间我被切断了，我在做三份兼职工作，我没有时间...我做不到..."
            anvl "我无法跟上..."
            nonvl "...你本可以寻求帮助。我相信—"
            $cs_right = "asher n fro"
            anvl "不！不..."
            anvl "不...我想要证明...证明我可以独立完成..."
            anvl "然后我看到了你...在一切事物上都表现出色...有时间去做你的艺术，和你的朋友在一起，这..."
            nonvl "...让你生气了。"
            $cs_right = "asher n sad"
            anvl "让我想要看到你受苦。"
            $cs_left = "noah n sho"
            nonvl "哎呀。"
            anvl "这就伤害了鲁本...你知道，家人对他很重要？"
            anvl "所以我现在是无朋友，无女朋友，退学了，付不起房租。"
            anvl "现在还要处理两个该死的葬礼。"
            $cs_left = "noah n ann"
            nonvl "我..."
            nonvl "我不知道该说什么。"
            anvl "没有什么可说的。这就是我的生活。"
            anvl "我会...处理好的。"
            nonvl "...我应该去清理我的房间。"
            $cs_right = "asher n smi"
            anvl "这样就不用你来处理我的所有东西了。"
            $cs_left = "noah n hap"
            nv "艾许露出一个虚弱的微笑，诺亚也回以微笑。"
            nv "他们是否能重拾友谊，谁也说不准，但在那一刻，他们似乎重拾了多年前失去的对彼此的理解。"
            nvl clear
            jump asher_hub

        "够了":
            nvl clear

            $ nvl_hide(Dissolve(0.6))
            jump chapter2escaperepeat



label person6_note1:
    $ gametype = "ADV"
    window show dissolve
    hide heavenescape
    "诺亚举起纸张，向艾许展示。"
    ash fro "....."
    ash"什么？"
    no neu "呃...我想你可能想再看看。"
    no ann "...再次。"
    ash"你的脑子有问题吗？"
    ash"滚开。"

    window hide dissolve
    jump chapter2escaperepeat

    #ghjifrgj jgrtjigrgjirgrjirgjirjiggjirgjirgrj b  $ gametype = "PENIS PENIS PNEIS PE NIS PENIS PENIS PENIS PENS PENIS PENS PENS AHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH Gabrielle Margaret Russell"
label person6_note2:
    $ gametype = "ADV"
    window show dissolve
    hide heavenescape
    "诺亚举起现在完成的纸张，向艾许展示。"
    no neu "我修好了。"
    ash fro "你想要什么，奖牌吗？"
    "诺亚耸了耸肩。他通常不喜欢激怒别人，但让艾许恼火还是有一种满足感。"
    "即使只是在梦中。"
    no "当然，我很乐意。"
    "艾许皱着眉头，显然没有打算给诺亚任何奖牌。"
    window hide dissolve
    jump chapter2escaperepeat

label person6_photopieces:
    $ gametype = "ADV"
    window show dissolve
    hide heavenescape
    no neu "你有这些吗？"
    ash fro "什么？"
    if toldasher_talkedtorueben:
        $ asher_photopieces = True
        ash sad "..."
        "艾许从口袋里掏出一些皱巴巴的东西，递给了诺亚。"
        $ photopiece_counter += 1
        ash "原来你收集垃圾啊。"
    else:
        ash fro "除非你帮我去找鲁本，否则我是不会给你任何东西的。"
    window hide dissolve
    jump chapter2escaperepeat

label person6_photopieces2:
    $ gametype = "ADV"
    window show dissolve
    hide heavenescape
    "艾许独自站着，不时把目光投向鲁本。"
    "在诺亚看来，他就像一张被撕碎的照片。"
    window hide dissolve
    jump chapter2escaperepeat

label person6_photopieces3:
    $ gametype = "ADV"
    window show dissolve
    hide heavenescape
    no neu "...谢谢你给我这些。你本可以拒绝的。"
    ash sad "是啊，好吧..."
    ash "你帮了我。即使你是个被宠坏的小鬼...我很感激。"
    no sho "天哪，这差不多算是一句赞美了。"
    ash smi "别得寸进尺。"
    window hide dissolve
    jump chapter2escaperepeat

label person6_photopiecesingular:
    $ gametype = "ADV"
    window show dissolve
    hide heavenescape
    no sca "去问他有什么意义吗？"
    c neu "嗯...我想任何线索都值得去追查。"
    no "他真的不是—"
    ash neu "你们两个在那里吵什么呢？"
    no "..."
    no "你见过这个吗？"
    ash fro "什么？别浪费我的时间。"
    no ann "我就说嘛，他对诗歌不太感兴趣。"
    ash "对不起？"
    ash "我可是很喜欢诗歌的！"
    no "哦，那你认识这个吗？"
    ash "..."
    ash sad "不是..."
    window hide dissolve
    jump chapter2escaperepeat

label person6_tape:
    $ gametype = "ADV"
    window show dissolve
    hide heavenescape
    "有那么一瞬间，诺亚考虑过用胶带封住艾许的嘴，但最终还是放弃了。"
    nothought "就算这样，他也还是停不下来。"
    ash fro "...什么？"
    window hide dissolve
    jump chapter2escaperepeat

label person6_pen:
    $ gametype = "ADV"
    window show dissolve
    hide heavenescape
    no neu "需要笔来做什么吗？"
    ash sur "呃...比如说什么？"
    no ann "一些...与笔有关的任务...？"
    ash "..."
    window hide dissolve
    jump chapter2escaperepeat


######## Person 5 | Daisy ##############
label person5_firstscene:
    hide heavenescape
    $ gametype = "NVL"
    $ charleft = "诺亚"
    $ charright = "克劳"

    $cs_left = "noah n neu"
    $cs_right = "crow n neu"

    $ nvl_show(Dissolve(1))
    nv "一个有着金发和蓝眼睛的年轻女子直接站在艾许面前。她的眼神清澈而深邃。"
    cnvl "小姐，打扰一下？"
    $ charright = "???"
    $ cs_right = "daisy n neu"

    unvl "..."
    unvl "...什么事？"
    nv "那个女子双臂抱在胸前，挑起一边眉毛。她似乎并不太想聊天。"
    nv "诺亚完全不认识她。不管她是谁，都不是艾许和诺亚的共同朋友。"
    unvl "不管什么事，快说吧。我们没有全天的时间。"

    $ charright = "克劳"
    $ cs_right = "crow n hap"
    cnvl "哦，因为你很快就能通过这条队伍了吗？"
    $ charright = "???"
    $ cs_right = "daisy n fro"
    unvl "不，因为那个笨蛋艾许很快就会醒过来，我就会消失了。"
    $ charright = "克劳"
    $ cs_right = "crow n sho"
    $cs_left = "noah n sho"
    cnvl "..."
    nonvl "..."
    nonvl "你，呃...意识到这一点了吗？"
    $ charright = "???"
    $ cs_right = "daisy n neu"
    unvl "嗯，这很明显。我其实并不真实，所以这一定是个梦。如果我不是真实的，而这又是个梦，那我也就不是真正的我了。"
    $ charright = "克劳"
    $ cs_right = "crow n sho"
    cnvl "这还是头一次。"
    nonvl "但是...你竟然能意识到自己不是真实的..."
    nv "那个女子耸了耸肩，似乎不太想多说。"
    $ charright = "???"
    $ cs_right = "daisy n neu"
    unvl "正如我说的，我们没有全天的时间。你想要什么？"
    nonvl "对，既然你知道这是个梦...我们正试图让这条队伍快点走。"
    unvl "嗯哼。"
    nonvl "有什么我们可以为你做的吗？来帮忙？"
    unvl "为我做...？"
    unvl "导演好像说过这件事..."
    $ charright = "克劳"
    $ cs_right = "crow n sho"
    cnvl "导演？"
    $ charright = "???"
    $ cs_right = "daisy n neu"
    unvl "你不需要担心他。"
    unvl "该死的，要是我能在停止存在之前记住这些就好了..."
    nv "她在云朵上敲了敲脚，陷入了沉思。"
    $ cs_right = "daisy n sur"
    unvl "也许你们可以为我做点什么。"
    $ charright = "克劳"
    $ cs_right = "crow n hap"
    cnvl "是什么？我们很乐意帮忙。"
    $ charright = "???"
    $ cs_right = "daisy n neu"
    unvl "你。"
    unvl "等你回到现实世界后，我想让你给我打电话，告诉我这里发生的一切。"
    $ charright = "克劳"
    $ cs_right = "crow n sho"
    cnvl "呃...？"
    cnvl "非常抱歉，小姐...？"
    $ charright = "黛西"
    $ cs_right = "daisy n neu"
    dnvl "黛西。"
    $ charright = "克劳"
    $ cs_right = "crow n sadsmi"
    cnvl "黛西小姐。这是..."
    nv "克劳做了一个想要帮忙的表情，但是..."
    nonvl "...我可以自己来。"
    $ cs_left = "noah n ann"
    nonvl "但是...你不会觉得我疯了吗...？"
    $ charright = "黛西"
    $ cs_right = "daisy n neu"
    dnvl "不会。我在这个领域工作，所以我会相信你。"
    nonvl "那你能给我你的电话号码吗？"
    $ cs_right = "daisy n sur"
    dnvl "当然—"
    $ cs_right = "daisy n hur"
    dnvl "当然..."
    dnvl "我...不知道。"
    $ cs_right = "daisy n fro"
    dnvl "该死的艾许...我不知道是因为他从来都记不住..."
    nv "她在口袋里摸索着，脸上带着惊讶的表情，掏出了一部手机。"
    $ cs_right = "daisy n sur"
    dnvl "算了，他是个天才。"
    $ cs_right = "daisy n hur"
    dnvl "但是解锁码是什么..."
    $ cs_left = "noah n sca"
    nonvl "嗯..."
    nonvl "对了，你和我哥哥是什么关系？"
    $ cs_right = "daisy n sho"
    dnvl "你哥哥...？"
    dnvl "你一定是诺亚。我都没意识到。"
    dnvl "艾许是...曾经是我的男朋友，我想。我们没有交往很久。"
    nonvl "...我哥哥有什么事情是顺利的吗？"
    dnvl "说实话，他是个可怜的小混蛋，因为害怕自己而对别人发脾气。"
    $ cs_right = "daisy n smi"
    dnvl "我想说对他温和点，但你想怎么样都行，我已经不在乎他了。"
    $ charright = "克劳"
    $ cs_right = "crow n sho"
    cnvl "哎呀..."
    nonvl "是吗..."
    nonvl "所以...我们需要解锁你的手机。有什么想法吗？"
    $ charright = "黛西"
    $ cs_right = "daisy n neu"
    dnvl "你可以试着问艾许要我的号码，但我不指望他会告诉你。"
    $ charright = "克劳"
    $ cs_right = "crow n neu"
    cnvl "我们会试试的，很快就回来！"
    nv "当两人走开时，克劳首先停下了脚步，懒洋洋地环顾四周。"
    $ cs_left = "noah n sho"
    nonvl "她怎么知道自己不是真的？"
    $ cs_right = "crow n sho"
    cnvl "这很奇怪，不是吗？我从未见过这样的人。"
    nonvl "而且她说她也在这个领域工作。不管那是什么意思。"
    cnvl "..."
    $ cs_right = "crow n sad"
    cnvl "小心点她，好吗？"
    cnvl "如果你决定之后给她打电话的话。"
    nonvl "为什么？"
    cnvl "她很聪明...我担心她的知识会带来什么后果。"
    cnvl "我不是说不要联系她...只是要谨慎，好吗？"
    nv "不知为什么，从那张脸和那个声音传来，诺亚不由自主地把这个警告记在心里。"
    $ cs_left = "noah n neu"
    nonvl "我会小心的。我保证。"

    nvl clear

    $ nvl_hide(Dissolve(0.6))
    jump chapter2escaperepeat

label person5_hub:
    hide heavenescape

    $ gametype = "NVL"
    $ charleft = "诺亚"
    $ charright = "黛西"

    $cs_left = "noah n neu"
    $cs_right = "daisy n neu"
    nv "黛西面向前方，完全无视身后的男人。"
    nv "当诺亚走近时，她微微一笑。"

    menu daisy_hub:
        "鲁本和艾许之间发生了什么？" if person3_firstclicked and person6_firstclicked and not daisy_asherreuben:
            hide heavenescape
            $ daisy_asherreuben = True
            $ gametype = "NVL"
            $ charleft = "诺亚"
            $ charright = "黛西"

            $cs_left = "noah n neu"
            $cs_right = "daisy n neu"
            nonvl "我可以问你一个问题吗？"
            dnvl "你可以问，但这不意味着我会知道答案...或者愿意告诉你。"
            nonvl "你认识鲁本吗？"
            dnvl "鲁本？有点印象。"
            dnvl "我只在很短暂的时候见过他，但艾许基本上把我和鲁本分开了。"
            $cs_right = "daisy n hur"
            dnvl "所谓分开，就是如果鲁本需要什么，艾许随时都会放下手头的一切。"
            $cs_left = "noah n sho"
            nonvl "这...完全不像我哥哥的作风。"
            dnvl "那个男人只对一个人有软肋，而那个人从来不是我。"
            nonvl "那你知道他们之间发生了什么吗？他们现在都不愿意说话。"
            nv "黛西耸了耸肩。"
            $cs_right = "daisy n neu"
            dnvl "不知道。不管发生了什么，对鲁本来说一定很重要。"
            nvl clear
            jump daisy_hub

        "让我看看你的手机" if not daisy_solvedphone:
            hide heavenescape
            $ gametype = "NVL"
            $ charleft = "诺亚"
            $ charright = "黛西"
            $cs_left = "noah n neu"
            $cs_right = "daisy n neu"
            nonvl "我想我知道密码是什么。"
            nonvl "你能给我看看你的手机吗？"
            dnvl "随你便。"
            nvl hide dissolve
            call screen daisychapter2_phone with dissolve

        "我能再看一遍那个应用程序吗？" if daisy_solvedphone and not reuben_solveddiary:
            hide heavenescape
            $ gametype = "NVL"
            $ charleft = "诺亚"
            $ charright = "黛西"
            $cs_left = "noah n neu"
            $cs_right = "daisy n neu"

            nonvl "抱歉，我能再看一遍那个应用程序吗？"
            dnvl "好的，给你。"
            nv "黛西再次在手机上打开了那个应用程序。它闪烁着红色、红色、绿色、黄色。"
            nonvl "谢谢。我这次一定不会忘记了。"
            nvl clear
            jump daisy_hub



        "够了":
            nvl clear

            $ nvl_hide(Dissolve(0.6))
            jump chapter2escaperepeat

label person5_asherpaper:
    $ gametype = "ADV"
    window show dissolve
    hide heavenescape
    no neu "嗨，黛西。"
    d neu"里面有什么？"
    no neu "我找到了这个..."
    d "..."
    d sho "你从哪里弄到的？"
    no "艾许给我的。"
    d neu "嗯..."
    d neu"我觉得这可能就是我们要找的东西。"
    c sho"是吗？"
    if not asherpaper_2:
        d "不过看起来它的一半都丢失了。"
    window hide dissolve
    jump chapter2escaperepeat

label person5_phonesolved:
    $ gametype = "ADV"
    window show dissolve
    hide heavenescape
    no neu "嗨，黛西..."
    no "这就是我用来破解你手机锁码的东西。"
    d sur "哦，这是一个密码。"
    no sho "你认识它吗？"
    "黛西点了点头。"
    d smi "我年轻的时候曾经为了乐趣学习过一点密码学。"
    d sho "哇，我没想到艾许还记得这件事。"
    no "什么...？"
    d neu "如果不是他告诉我，我也不会知道。"
    no ann "哦...好点子。"
    window hide dissolve
    jump chapter2escaperepeat

screen daisychapter2_phone:
    add "input_chap2"

    textbutton "Confirm":
        xalign 0.60 yalign 0.65
        text_color "#ffffff"
        text_hover_color "#dcad2b"

        if daisy_messageplayer.lower().strip() in daisy_messagercorrect:
            action [Hide("daisychapter2_phone", dissolve), Jump("daisy_message_correct")]
        else:
            action [Hide("daisychapter2_phone", dissolve), Jump("daisy_message_incorrect")]


    textbutton "Hint":
        xalign 0.39 yalign 0.65
        text_color "#fafafa"
        text_hover_color "#ecb92e"
        if daisyhint == 1:
            action [SetVariable("daisyhint", daisyhint + 1), Show("daisyhint1", dissolve)]
        elif daisyhint == 2:
            action [SetVariable("daisyhint", daisyhint + 1), Show("daisyhint2", dissolve)]
        elif daisyhint == 3:
            action Show("daisyhint3", dissolve)


    vbox:
        xalign 0.5 yalign 0.5

        hbox:
            box_wrap True
            xalign 0.5 yalign 0.5
            xsize 250
            input:
                default ""
                value VariableInputValue('daisy_messageplayer')
                pixel_width 620
                style "input_style"

screen daisyhint1:
    modal True

    add "images/Various/black overlay.png"
    add "gui/popup.png" xalign 0.5 yalign 0.5
    text "Hint" xalign 0.5 yalign 0.34 color "#fefefe" size 50
    textbutton "x" action [Hide("daisyhint1", dissolve)]:
        text_color "#ffffff"
        text_hover_color "#dcad2b"
        xalign 0.68
        yalign 0.28
    vbox:
        xanchor 0.0
        spacing 20.0
        xpos 700
        ypos 450
        text "使用从艾许和鲁本那里得到的\'便条\'来破解密码。"
        text "再次点击提示按钮可获得另一个提示。"

screen daisyhint2:
    modal True

    add "images/Various/black overlay.png"
    add "gui/popup.png" xalign 0.5 yalign 0.5
    text "Hint" xalign 0.5 yalign 0.34 color "#fefefe" size 50
    textbutton "x" action [Hide("daisyhint2", dissolve)]:
        text_color "#ffffff"
        text_hover_color "#dcad2b"
        xalign 0.68
        yalign 0.28
    vbox:
        xanchor 0.0
        spacing 20.0
        xpos 700
        ypos 450
        text "你需要的密码在便条的底部。\n使用上面的密码来破解，每个字母向前移动5个位置。"
        text "再次点击提示按钮可获得答案。"

screen daisyhint3:
    modal True

    add "images/Various/black overlay.png"
    add "gui/popup.png" xalign 0.5 yalign 0.5
    text "Hint" xalign 0.5 yalign 0.34 color "#fefefe" size 50
    textbutton "x" action [Hide("daisyhint3", dissolve)]:
        text_color "#ffffff"
        text_hover_color "#dcad2b"
        xalign 0.68
        yalign 0.28
    vbox:
        xanchor 0.0
        spacing 20.0
        xpos 700
        ypos 450
        text "密码是： DREAMBOUND"


label daisy_message_incorrect:
    play sound "audio/sfx/wrong.ogg"
    $cs_left = "noah n ann"
    nonvl "该死..."
    $cs_right = "daisy n neu"
    dnvl "看来你还没有完全破解出来。"
    dnvl "要我来试试吗？"
    nonvl "不，不，我自己来..."
    nvl clear
    jump daisy_hub

label daisy_message_correct:
    $ daisy_solvedphone = True
    $ gametype = "NVL"
    $ charleft = "诺亚"
    $ charright = "克劳"
    $cs_left = "noah n hap"
    $cs_right = "crow n sho"
    nonvl "搞定了！"
    $cs_right = "crow n hap"
    cnvl "干得好，诺亚。我就知道你能做到。"
    $cs_left = "noah n shy"
    nv "诺亚的脸颊泛起了淡淡的粉红色，他避开了克劳的目光。"
    nonvl "这...这没什么大不了的..."
    cnvl "当然很了不起。你做得很好，庆祝一下也没什么不好的。开心一点吧。"
    nonvl "是...是啊..."
    $ charright = "黛西"
    $ cs_right = "daisy n neu"
    dnvl "你们两个调情完了吗？"
    $ charright = "克劳"
    $ cs_right = "crow n sur"
    cnvl "调情？我只是—"
    $ charright = "黛西"
    $ cs_right = "daisy n neu"
    dnvl "在调情。"
    $ cs_right = "daisy n smi"
    dnvl "终于，我的号码！记住这个吧。"
    nv "黛西把手机屏幕转向诺亚，上面显示着一串长长的数字。"
    $cs_left = "noah n sca"
    nonvl "呃，我的记忆力可不太好..."
    dnvl "现在正是改善自己的好时机。"
    dnvl "哦，这是什么..."
    $ charright = "克劳"
    $ cs_right = "crow n sho"
    cnvl "里面有什么？"
    nv "黛西皱着眉头看着手机，一脸困惑。"
    $ charright = "黛西"
    $ cs_right = "daisy n neu"
    dnvl "手机上只有一个应用程序。看。"
    nv "黛西点击了主屏幕上的应用程序，它就启动了。"
    nv "它闪烁着红色、红色、绿色、黄色，然后重复。"
    $ charright = "克劳"
    $ cs_right = "crow n sho"
    cnvl "哦，它只是闪烁着颜色。它是该这样做的吗？"
    $ charright = "黛西"
    $ cs_right = "daisy n neu"
    dnvl "我也不知道。"
    dnvl "也许它会派上用场。"
    $cs_left = "noah n ann"
    nonvl "也许吧。在梦境中，没有什么是毫无用处的。"
    dnvl "总之，我会等着你的消息。"
    dnvl "好吧，我不会真的给你发消息，因为我不是真正的我，所以我也不会记得这件事，但是..."
    dnvl "你明白我的意思。"
    nv "克劳担忧地看了诺亚一眼，然后摇了摇头。"
    nonvl "我会尽快联系你。"
    $ cs_right = "daisy n smi"
    nv "一个笑容在黛西的脸上绽放，照亮了她的容颜。不知为什么，它让诺亚想起了奥古斯特。"
    dnvl "谢谢你，诺亚和...？"
    $ charright = "克劳"
    $cs_right = "crow n hap"
    cnvl "你可以叫我克劳。"
    $ charright = "黛西"
    $ cs_right = "daisy n sho"
    dnvl "克劳啊..."
    dnvl "不知为什么，你让我想起了别人。"
    $ charright = "克劳"
    $cs_right = "crow n sho"
    cnvl "..."
    $cs_right = "crow n sadsmi"
    cnvl "我经常听到这种话。大概是一张很普通的脸吧。"
    $cs_left = "noah n sad"
    nonvl "..."
    $ charright = "黛西"
    $ cs_right = "daisy n smi"
    dnvl "总之，感谢你的帮助。祝你顺利离开这里，一切顺利。"
    $cs_left = "noah n sho"
    nonvl "谢谢，呃...你也是？"
    $ charright = "克劳"
    $cs_right = "crow n sadsmi"
    nv"克劳首先转身离开，诺亚也很快跟了上去。"
    nv"他的目光迷失了，双眼空洞，伸手抓住了心脏的位置。"
    cnvl "奇怪。"
    nonvl "里面有什么？"
    nonvl "你还好吗？"
    cnvl "我..."
    cnvl "我会没事的。"
    cnvl "一种奇怪的重量压在我的胸口，我无法解释..."
    cnvl "确实很奇怪..."
    nv "在那一刻，他似乎是一个完全不同的人...但下一刻，他又对诺亚微笑，好像什么都没发生。"
    $cs_right = "crow n hap"
    cnvl "那我们继续吧。"
    nvl clear

    $ nvl_hide(Dissolve(0.6))
    jump chapter2escaperepeat

label person5_photopieces:
    $ gametype = "ADV"
    window show dissolve
    hide heavenescape
    no neu "你有没有在周围看到过这样的碎片？"
    "诺亚拿出了那张撕碎的照片，还缺少很多碎片。"
    d sur "...哦。"
    if daisy_solvedphone:
        $ daisy_photopieces = True
        d neu "好吧，你帮了我...给你。"
        $ photopiece_counter += 1
        "黛西从口袋里掏出了一些看起来相似的照片碎片。"

    else:
        d neu"等我们解决了手机的问题后再问我吧。"

    window hide dissolve
    jump chapter2escaperepeat

label person5_photopieces2:
    $ gametype = "ADV"
    window show dissolve
    hide heavenescape
    no ann "我想知道这些碎片有什么用..."
    c neu "嗯，有一种方法可以找出来。我相信这里肯定有人对它感兴趣。"
    window hide dissolve
    jump chapter2escaperepeat

label person5_photopieces3:
    $ gametype = "ADV"
    window show dissolve
    hide heavenescape
    "拿着那些被丢弃的撕碎照片的碎片，诺亚望向那无尽的云海。"
    "他将每一个细节、每一条曲线、每一处阴影都牢牢地记在了心里。"
    window hide dissolve
    jump chapter2escaperepeat

label person5_photopiecessingular:
    $ gametype = "ADV"
    window show dissolve
    hide heavenescape
    d neu "你这里有什么？"
    no neu"实际上，我是想问你有没有见过这个。"
    "黛西的眼睛扫过那些字，但她的目光中没有任何认出的迹象。"
    d "很抱歉，我不太喜欢...诗歌，我猜？"
    d "也许可以问问艾许，他一直都对这种东西感兴趣。"
    no sho "...艾许？诗歌...？"
    window hide dissolve
    jump chapter2escaperepeat

label person5_tape:
    $ gametype = "ADV"
    window show dissolve
    hide heavenescape
    d neu "你们两个还在磨磨蹭蹭的吗？"
    no sho "呃..."
    d "有趣，尽管这个世界可能即将毁灭，你也跟着一起，但你仍然觉得有必要跟每个人说话。"
    d "你肯定知道这个录像带对我没什么用，但你还是觉得有必要给我看。"
    d "为什么会这样？"
    no "我...也不知道。"
    window hide dissolve
    jump chapter2escaperepeat

label person5_pen:
    $ gametype = "ADV"
    window show dissolve
    hide heavenescape
    d neu "现在又是一支笔了吗？"
    d neu "为了一件这么小的东西而四处奔波，确实很有意思。"
    no sca "你说得对..."
    window hide dissolve
    jump chapter2escaperepeat

######## Person 4 | Elijah ##############
label person4_firstscene:
    hide heavenescape

    $ gametype = "NVL"
    $ charleft = "诺亚"
    $ charright = "克劳"
    $ cs_left = "noah n neu"
    $ cs_right = "crow n neu"
    $ nvl_show(Dissolve(1))

    nv "一位年长的绅士站在队伍前面几个位置，双手随意地插在口袋里，吹着一首轻快悠扬的曲子。"
    nv "当克劳和诺亚走近时，他们才发现这个人的形态并不很强烈...他就像一个影子，没有明确的特征。"
    $ cs_left = "noah n sho"

    if not person2_firstclicked:
        nonvl "为什么他会这样...？"
        $ cs_right = "crow n sho"
        cnvl "我想艾许对他并没有太多的依恋...要创造出完全栩栩如生的人物，需要梦境创造者相当强大的精神力量。"
        cnvl "所以有时候人物就会变成这样。"
        nonvl "..."
        $ cs_left = "noah n ann"
        nonvl "我想这和现实世界也没什么不同。"
        nonvl "在街上你会遇到多少人，却从未记住或再想起过？"
        $ cs_left = "noah n neu"
        nonvl "我们可以跟他说话吗？"
        cnvl "应该可以。"
    else:
        nv "就像皮尔森教授一样，他的形态并不坚实，而是流动的。他就像一个随时都会被吹散的影子。"

    nonvl "呃，打扰一下..."
    nv "这个阴影般的男子转向诺亚，他的口哨声戛然而止。"
    unvl "嘿，不要插队。我们都得等自己的轮到。"
    cnvl "哦，不，我们不是来插队的。"
    $ cs_right = "crow n hap"
    cnvl "相反，我们是来帮你更快通过那个大门的。"
    unvl "哦..."
    unvl "你们两个真是太好了。在这个世界上，你们这样诚实正直的年轻人已经不多见了！"
    $ cs_left = "noah n hur"
    nonvl "好的..."
    cnvl "我是诺亚，这是克劳。我没有听到你的名字？"
    $ cs_left = "noah n ann"
    envl "我叫以利亚。"
    $ cs_right = "crow n neu"
    cnvl "以利亚，很高兴认识你。你在这里做什么？"
    nv "这个男人停下来思考了一会儿。他似乎也不太清楚自己为什么会在这里。"
    envl "嗯。我也不知道。"
    envl "我正在和我那个不愿意支付他该死的房租的房客通电话，然后我就在这里了..."
    nonvl "你的房客？"
    envl "一个叫艾许的年轻人。"
    $ cs_left = "noah n sho"
    nonvl "...."
    nonvl "艾许没有支付房租...？"
    nonvl "这不像他的作风..."
    envl "你认识他？"
    nonvl "他是...不幸的是我的弟弟。"
    envl "也许你可以提醒他，我不是什么慈善机构，他已经拖欠了过去六个月的房租。"
    notnvl "什么...我以为是我们的父母在支付他的账单？"
    cnvl "我们可以告诉他。"
    $ cs_left = "noah n ann"
    nonvl "并希望问问他为什么..."

    if photopieces:
        envl "嘿，你手里拿的是什么？"
        $ cs_left = "noah n sho"
        nonvl "这些...？"
        nv "诺亚把撕碎的照片碎片递给以利亚，后者惊讶地睁大了眼睛。"
        envl "这...我一直在找这些！我正试图把这张照片拼凑起来..."
        $ cs_right = "crow n sur"
        cnvl "真的吗？"
        $ cs_right = "crow n hap"
        cnvl "那么，也许我们可以帮你找到其余的碎片。"
        $ cs_left = "noah n neu"
        nonvl "作为交换，如果我们需要的话，你可以帮助我们。"
        envl "你们两个人真是一个团队，是不是？成交。"
    else:
        envl "顺便问一下，你有没有看到什么纸屑呢？"
        envl "我正在拼凑一张旧照片，结果被风吹走了..."
        $ cs_left = "noah n neu"
        nonvl "照片？不，我想没有..."
        $ cs_right = "crow n hap"
        cnvl "但如果你想的话，我们可以帮你留意一下！"
        envl "那真是太感谢了。"

    cnvl "那我们很快就回来！"

    nvl clear

    $ nvl_hide(Dissolve(0.6))
    jump chapter2escaperepeat

label person4_hub:
    hide heavenescape

    $ gametype = "NVL"
    $ charleft = "诺亚"
    $ charright = "克劳"

    $cs_left = "noah n neu"
    $cs_right = "crow n neu"

    nv "名叫以利亚的男人面朝前方站着，完全没有意识到就在他身后不远处站着艾许。"
    nv "似乎他甚至看不到他。"

    menu elijah_hub:
        "让我们试着把照片拼凑起来" if photopiece_counter == 3 and not elijah_photocomplete:
            nonvl "我想我已经准备好尝试拼凑你的照片了。"
            nv "以利亚看着诺亚和克劳，他的期望在脸上一目了然。"
            nvl hide dissolve
            call screen chapter2_photo with dissolve


        "够了":
            nvl clear

            $ nvl_hide(Dissolve(0.6))
            jump chapter2escaperepeat

label person4_photopieces:
    $ gametype = "ADV"
    window show dissolve
    hide heavenescape

    if photopiece_counter  <3:
        no neu "以利亚，我找到了这些。"
        e "不错，不错..."
        e "不过你还缺少几张碎片。"
        c hap "我们很快就会找到剩下的碎片！"
    elif photopiece_counter == 3:
        "诺亚把照片碎片递给以利亚，后者仔细地检查着每一片。"
        e "天哪...你们两个做到了！"
        e "你能帮我把它拼凑起来吗？"
        c hap "我们可以试试！"
    window hide dissolve
    jump chapter2escaperepeat

label person4_asherpaper:
    $ gametype = "ADV"
    window show dissolve
    hide heavenescape
    "诺亚紧紧握住手中的纸张，望向艾许所谓天堂的金色大门。"
    "虚无似乎一直延伸到视线所及的远方。"
    no ann "讽刺..."
    window hide dissolve
    jump chapter2escaperepeat

init python:
    def update_photo_size(drags):
        if drags[0].drag_name == "1":
            store.current_photo_zoompiece13 = 1.0
        elif drags[0].drag_name == "2":
            store.current_photo_zoompiece12 = 1.0
        elif drags[0].drag_name == "3":
            store.current_photo_zoompiece11 = 1.0
        elif drags[0].drag_name == "4":
            store.current_photo_zoompiece10 = 1.0
        elif drags[0].drag_name == "5":
            store.current_photo_zoompiece9 = 1.0
        elif drags[0].drag_name == "6":
            store.current_photo_zoompiece8 = 1.0
        elif drags[0].drag_name == "7":
            store.current_photo_zoompiece7 = 1.0
        elif drags[0].drag_name == "8":
            store.current_photo_zoompiece6 = 1.0
        elif drags[0].drag_name == "9":
            store.current_photo_zoompiece5 = 1.0
        elif drags[0].drag_name == "10":
            store.current_photo_zoompiece4 = 1.0
        elif drags[0].drag_name == "11":
            store.current_photo_zoompiece2 = 1.0
        elif drags[0].drag_name == "12":
            store.current_photo_zoompiece3 = 1.0
        elif drags[0].drag_name == "13":
            store.current_photo_zoompiece1 = 1.0
        renpy.restart_interaction()

    def photo_dragged(drags, drop):
        if not drop:
            return

        if drop.drag_name == "photo_spot1":
            if snap1_playeranswer == "1":
                return
            else:
                store.snap1_playeranswer = drags[0].drag_name
                return

        elif drop.drag_name == "photo_spot2":
            if snap2_playeranswer == "2":
                return
            else:
                store.snap2_playeranswer = drags[0].drag_name
                return

        elif drop.drag_name == "photo_spot3":
            if snap3_playeranswer == "3":
                return
            else:
                store.snap3_playeranswer = drags[0].drag_name
                return

        elif drop.drag_name == "photo_spot4":
            if snap4_playeranswer == "4":
                return
            else:
                store.snap4_playeranswer = drags[0].drag_name
                return

        elif drop.drag_name == "photo_spot5":
            if snap5_playeranswer == "5":
                return
            else:
                store.snap5_playeranswer = drags[0].drag_name
                return

        elif drop.drag_name == "photo_spot6":
            if snap6_playeranswer == "6":
                return
            else:
                store.snap6_playeranswer= drags[0].drag_name
                return

        elif drop.drag_name == "photo_spot7":
            if snap7_playeranswer == "7":
                return
            else:
                store.snap7_playeranswer= drags[0].drag_name
                return

        elif drop.drag_name == "photo_spot8":
            if snap8_playeranswer == "8":
                return
            else:
                store.snap8_playeranswer= drags[0].drag_name
                return
        elif drop.drag_name == "photo_spot9":
            if snap9_playeranswer == "9":
                return
            else:
                store.snap9_playeranswer= drags[0].drag_name
                return
        elif drop.drag_name == "photo_spot10":
            if snap10_playeranswer == "10":
                return
            else:
                store.snap10_playeranswer= drags[0].drag_name
                return
        elif drop.drag_name == "photo_spot11":
            if snap11_playeranswer == "11":
                return
            else:
                store.snap11_playeranswer= drags[0].drag_name
                return
        elif drop.drag_name == "photo_spot12":
            if snap12_playeranswer == "12":
                return
            else:
                store.snap12_playeranswer= drags[0].drag_name
                return
        elif drop.drag_name == "photo_spot13":
            if snap13_playeranswer == "13":
                return
            else:
                store.snap13_playeranswer= drags[0].drag_name
                return

        elif drop.drag_name == "inventory" or "inventory2":
            if drags[0].drag_name == "1":
                store.current_photo_zoompiece13 = 0.5 # Set the size to small when in inventory
            elif drags[0].drag_name == "2":
                store.current_photo_zoompiece12 = 0.5 # Set the size to small when in inventory
            elif drags[0].drag_name == "3":
                store.current_photo_zoompiece11 = 0.5 # Set the size to small when in inventory
            elif drags[0].drag_name == "4":
                store.current_photo_zoompiece10 = 0.5 # Set the size to small when in inventory
            elif drags[0].drag_name == "5":
                store.current_photo_zoompiece9 = 0.5 # Set the size to small when in inventory
            elif drags[0].drag_name == "6":
                store.current_photo_zoompiece8 = 0.5 # Set the size to small when in inventory
            elif drags[0].drag_name == "7":
                store.current_photo_zoompiece7 = 0.5 # Set the size to small when in inventory
            elif drags[0].drag_name == "8":
                store.current_photo_zoompiece6 = 0.5 # Set the size to small when in inventory
            elif drags[0].drag_name == "9":
                store.current_photo_zoompiece5 = 0.5 # Set the size to small when in inventory
            elif drags[0].drag_name == "10":
                store.current_photo_zoompiece4 = 0.5 # Set the size to small when in inventory
            elif drags[0].drag_name == "11":
                store.current_photo_zoompiece2 = 0.5 # Set the size to small when in inventory
            elif drags[0].drag_name == "12":
                store.current_photo_zoompiece3 = 0.5 # Set the size to small when in inventory
            elif drags[0].drag_name == "13":
                store.current_photo_zoompiece1 = 0.5 # Set the size to small when in inventory
            renpy.restart_interaction()
            return

screen chapter2_photo:
    modal True
    add "images/puzzles/overlay.png"
    add "images/puzzles/frame.png"
    add "images/puzzles/chapter_2/puzzle pieces/guide.png"


    textbutton "Close" action [Hide("chapter2_photo", dissolve), Jump("chapter2escaperepeat")]:
        xalign 0.93 yalign 0.95
        text_color "#ffffff"
        text_hover_color "#dcad2b"
    textbutton "Finished" action [Hide("chapter2_photo", dissolve), Jump("chapter2photo_checker")]:
        xalign 0.80 yalign 0.95
        text_color "#ffffff"
        text_hover_color "#dcad2b"
    textbutton "Hint":
        xalign 0.86 yalign 0.95
        text_color "#fafafa"
        text_hover_color "#ecb92e"
        if elijahhint == 1:
            action [SetVariable("elijahhint", elijahhint + 1), Show("elijahhint1", dissolve)]
        elif elijahhint == 2:
            action Show("elijahhint2", dissolve)


    draggroup:
        drag : ### INVENTORY ON RIGHT
            drag_name "inventory"
            draggable False
            child "images/puzzles/chapter_2/puzzle pieces/inventory.png"
            focus_mask True
            xpos 1465 ypos 70
        drag : ### INVENTORY ON LEFT
            drag_name "inventory2"
            draggable False
            child "images/puzzles/chapter_2/puzzle pieces/inventory.png"
            focus_mask True
            xpos 380 ypos 70
        drag:
            drag_name "1"
            if current_photo_zoompiece13 == 0.5:
                child "piece13b"
            elif current_photo_zoompiece13 == 1.0:
                child "piece13a"
            dragged photo_dragged
            droppable False
            xalign 0.84 yalign 0.13
            focus_mask True
            activated update_photo_size
        drag:
            drag_name "2"
            if current_photo_zoompiece12 == 0.5:
                child "piece12b"
            elif current_photo_zoompiece12 == 1.0:
                child "piece12a"
            dragged photo_dragged
            droppable False
            xalign 0.91 yalign 0.72
            focus_mask True
            activated update_photo_size

        drag:
            drag_name "3"
            if current_photo_zoompiece11 == 0.5:
                child "piece11b"
            elif current_photo_zoompiece11 == 1.0:
                child "piece11a"
            dragged photo_dragged
            droppable False
            xalign 0.17 yalign 0.75
            focus_mask True
            activated update_photo_size
        drag:
            drag_name "4"
            if current_photo_zoompiece10 == 0.5:
                child "piece10b"
            elif current_photo_zoompiece10 == 1.0:
                child "piece10a"
            dragged photo_dragged
            droppable False
            xalign 0.22 yalign 0.12
            focus_mask True
            activated update_photo_size

        drag:
            drag_name "5"
            if current_photo_zoompiece9 == 0.5:
                child "piece9b"
            elif current_photo_zoompiece9 == 1.0:
                child "piece9a"
            dragged photo_dragged
            droppable False
            xalign 0.14 yalign 0.12
            focus_mask True
            activated update_photo_size
        drag:
            drag_name "6"
            if current_photo_zoompiece8 == 0.5:
                child "piece8b"
            elif current_photo_zoompiece8 == 1.0:
                child "piece8a"
            dragged photo_dragged
            droppable False
            xalign 0.94 yalign 0.13
            focus_mask True
            activated update_photo_size
        drag:
            drag_name "7"
            if current_photo_zoompiece7 == 0.5:
                child "piece7b"
            elif current_photo_zoompiece7 == 1.0:
                child "piece7a"
            dragged photo_dragged
            droppable False
            xalign 0.86 yalign 0.35
            focus_mask True
            activated update_photo_size
        drag:
            drag_name "8"
            if current_photo_zoompiece6 == 0.5:
                child "piece6b"
            elif current_photo_zoompiece6 == 1.0:
                child "piece6a"
            dragged photo_dragged
            droppable False
            xalign 0.92 yalign 0.51
            focus_mask True
            activated update_photo_size
        drag:
            drag_name "9"
            if current_photo_zoompiece5 == 0.5:
                child "piece5b"
            elif current_photo_zoompiece5 == 1.0:
                child "piece5a"
            dragged photo_dragged
            droppable False
            xalign 0.14 yalign 0.45
            focus_mask True
            activated update_photo_size

        drag:
            drag_name "10"
            if current_photo_zoompiece4 == 0.5:
                child "piece4b"
            elif current_photo_zoompiece4 == 1.0:
                child "piece4a"
            dragged photo_dragged
            droppable False
            xalign 0.17 yalign 0.3
            focus_mask True
            activated update_photo_size
        drag:
            drag_name "11"
            if current_photo_zoompiece2 == 0.5:
                child "piece2b"
            elif current_photo_zoompiece2 == 1.0:
                child "piece2a"
            dragged photo_dragged
            droppable False
            xalign 0.15 yalign 0.61
            focus_mask True
            activated update_photo_size
        drag:
            drag_name "12"
            if current_photo_zoompiece3 == 0.5:
                child "piece3b"
            elif current_photo_zoompiece3 == 1.0:
                child "piece3a"
            dragged photo_dragged
            droppable False
            xalign 0.94 yalign 0.34
            focus_mask True
            activated update_photo_size
        drag:
            drag_name "13"
            if current_photo_zoompiece1 == 0.5:
                child "piece1b"
            elif current_photo_zoompiece1 == 1.0:
                child "piece1a"
            dragged photo_dragged
            droppable False
            xalign 0.22 yalign 0.52
            focus_mask True
            activated update_photo_size


        ########### SPOTS YOU CAN DRAG ITEMS TO ####################
        drag:
            drag_name "photo_spot1"
            draggable False
            child "images/puzzles/chapter_2/puzzle pieces/piece13overlay.png"
            focus_mask True
            xpos 580 ypos 141
        drag:
            drag_name "photo_spot2"
            draggable False
            child "images/puzzles/chapter_2/puzzle pieces/piece12overlay.png"
            focus_mask True
            xpos 580 ypos 447
        drag:
            drag_name "photo_spot3"
            draggable False
            child "images/puzzles/chapter_2/puzzle pieces/piece11overlay.png"
            focus_mask True
            xpos 618 ypos 108
        drag:
            drag_name "photo_spot4"
            draggable False
            child "images/puzzles/chapter_2/puzzle pieces/piece10overlay.png"
            focus_mask True
            xpos 656 ypos 260
        drag:
            drag_name "photo_spot5"
            draggable False
            child "images/puzzles/chapter_2/puzzle pieces/piece9overlay.png"
            focus_mask True
            xpos 795 ypos 522
        drag:
            drag_name "photo_spot6"
            draggable False
            child "images/puzzles/chapter_2/puzzle pieces/piece8overlay.png"
            focus_mask True
            xpos 856 ypos 142
        drag:
            drag_name "photo_spot7"
            draggable False
            child "images/puzzles/chapter_2/puzzle pieces/piece7overlay.png"
            focus_mask True
            xpos 868 ypos 432
        drag:
            drag_name "photo_spot8"
            draggable False
            child "images/puzzles/chapter_2/puzzle pieces/piece6overlay.png"
            focus_mask True
            xpos 918 ypos 593
        drag:
            drag_name "photo_spot9"
            draggable False
            child "images/puzzles/chapter_2/puzzle pieces/piece5overlay.png"
            focus_mask True
            xpos 1001 ypos 121
        drag:
            drag_name "photo_spot10"
            draggable False
            child "images/puzzles/chapter_2/puzzle pieces/piece4overlay.png"
            focus_mask True
            xpos 1049 ypos 247
        drag:
            drag_name "photo_spot11"
            draggable False
            child "images/puzzles/chapter_2/puzzle pieces/piece2overlay.png"
            focus_mask True
            xpos 1052 ypos 455
        drag:
            drag_name "photo_spot12"
            draggable False
            child "images/puzzles/chapter_2/puzzle pieces/piece3overlay.png"
            focus_mask True
            xpos 1260 ypos 140
        drag:
            drag_name "photo_spot13"
            draggable False
            child "images/puzzles/chapter_2/puzzle pieces/piece1overlay.png"
            focus_mask True
            xpos 1205 ypos 471

screen elijahhint1:
    modal True

    add "images/Various/black overlay.png"
    add "gui/popup.png" xalign 0.5 yalign 0.5
    text "Hint" xalign 0.5 yalign 0.34 color "#fefefe" size 50
    textbutton "x" action [Hide("elijahhint1", dissolve)]:
        text_color "#ffffff"
        text_hover_color "#dcad2b"
        xalign 0.68
        yalign 0.28
    vbox:
        xanchor 0.0
        spacing 20.0
        xpos 700
        ypos 450
        text "从外围碎片开始，逐步向内完成整个图像。"
        text "再次点击提示按钮可获得答案。"

screen elijahhint2:
    modal True

    add "images/Various/black overlay.png"
    add "gui/popup.png" xalign 0.5 yalign 0.5
    text "Hint" xalign 0.5 yalign 0.34 color "#fefefe" size 50
    textbutton "x" action [Hide("elijahhint2", dissolve)]:
        text_color "#ffffff"
        text_hover_color "#dcad2b"
        xalign 0.68
        yalign 0.28
    vbox:
        xanchor 0.0
        spacing 20.0
        xpos 700
        ypos 450
        text "将拼图碎片放置在白线内，按照以下配置："
    add "images/puzzles/chapter_2/hintpuzzle.png" zoom 0.4 align 0.5, 0.65
label chapter2photo_checker:
    if snap1_playeranswer == "1" and snap2_playeranswer == "2" and snap3_playeranswer == "3" and snap4_playeranswer == "4" and snap5_playeranswer == "5" and snap6_playeranswer == "6" and snap7_playeranswer == "7" and snap8_playeranswer == "8"and snap9_playeranswer == "9" and snap10_playeranswer == "10" and snap11_playeranswer == "11" and snap12_playeranswer == "12" and snap13_playeranswer == "13":

        jump     c
    else:
        $ current_photo_zoompiece1 = 0.5
        $ current_photo_zoompiece2 = 0.5
        $ current_photo_zoompiece3 = 0.5
        $ current_photo_zoompiece4 = 0.5
        $ current_photo_zoompiece5 = 0.5
        $ current_photo_zoompiece6 = 0.5
        $ current_photo_zoompiece7 = 0.5
        $ current_photo_zoompiece8 = 0.5
        $ current_photo_zoompiece9 = 0.5
        $ current_photo_zoompiece10 = 0.5
        $ current_photo_zoompiece11 = 0.5
        $ current_photo_zoompiece12 = 0.5
        $ current_photo_zoompiece13 = 0.5

        $cs_left = "noah n ann"
        nonvl "该死。让我再试一次..."
        call screen chapter2_photo

label     c :
    $ gametype = "NVL"
    $ charleft = "诺亚"
    $ charright = "克劳"

    $cs_left = "noah n neu"
    $cs_right = "crow n hap"
    envl "天哪，你们两个真是做到了！"
    nv "虽然他的形态很难看清，但连诺亚也能看出以利亚脸上洋溢着宽阔而深邃的笑容。"
    envl "你们两个真的不知道这对我意味着什么..."
    $cs_left = "noah n sho"
    nonvl "等等，这是..."
    envl "这是一个小山城，我第一次遇到我妻子的地方。那是哪一年来着...嗯..."
    nv "以利亚把手举到下巴上，抚摸着另外两个人看不见的胡子。"
    envl "1975年？1976年？"
    envl "啊！1978年，我现在想起来了...天，时间真的过得太快了。"
    $cs_right = "crow n sho"
    $cs_left = "noah n sho"
    envl "你们两个应该珍惜彼此的时光，明白吗？"
    nonvl "..."
    $cs_right = "crow n sad"
    cnvl "..."
    $cs_left = "noah n sad"
    nonvl "是的...我确实很珍惜..."
    envl "总之，我应该记下日期..."

    if person1_firstclicked:
        $ cs_left = "noah n sur"
        nonvl "你有笔吗？"
        envl "当然，不然我怎么进来呢？"
        $ cs_right = "crow n sho"
        cnvl "我们能借用一下吗？就一分钟？"
        envl "嗯，嗯..."
        envl "这样吧，如果你能给我找些胶带来固定这个东西，防止它再次被吹走，那你就可以拿笔了。"
        $ cs_right = "crow n hap"
        cnvl "听起来是个公平的交易！"
        $ cs_left = "noah n ann"
        nonvl "我在天堂里怎么找到胶带呢..."
    else:
        nv "以利亚从口袋里掏出一支简单的圆珠笔。"
        envl "该死，我需要一些东西来把它固定住，否则它又会被吹走..."
        $ cs_right = "crow n sho"
        cnvl "嗯...也许有胶带？"
        envl "那就太好了，但如果我离开这个位置，我就永远也进不去了..."
        $ cs_left = "noah n sca"
        nonvl "...."
        nonvl "好吧，好吧，我们会给你找到胶带的。"

    nv "当克劳和诺亚转身离开时，一些皱巴巴的东西落到了云层下面。"
    nv "诺亚蹲下来把它捡了起来。"
    $ cs_left = "noah n ann"
    nonvl "看，你已经把它掉下去了...？"
    nv "诺亚低头看着那张皱巴巴的纸条。"
    $ cs_left = "noah n sho"
    nv "上面用潦草的笔触写着字。"
    nv "{i}不要干涉，否则你的\'朋友\'会像上次一样消失。{/i}"
    nonvl "..."
    nv "诺亚的心沉到了胃里，盯着眼前的字句。"
    nv "这张纸条本身就像一幅画布。就像最精美的绘画。"
    nv "只是几个字就把他带回到了过去，回到了一个他至今仍能感受到的巨大损失中，并将那种痛苦放大了十倍。"
    $ cs_right = "crow n sho"
    cnvl "你在下面还好吗，诺亚？"
    $ cs_right = "crow n hap"
    nv "诺亚抬头看向克劳灿烂的笑容。他似乎完全没有任何烦恼。"
    $ cs_left = "noah n ann"
    nv "出于某种原因，这正是诺亚想要保护的。"
    $ cs_left = "noah n neu"
    nonvl "没什么。只是一些垃圾。"
    nv "他把它塞进口袋里，站了起来，尽管内心痛苦，还是对克劳轻轻一笑。"
    envl "嗯，背面还有一些涂鸦..."
    envl "{i}在梦境的领域，心灵展翅高飞，漂浮在一个奇妙的世界里，一个纯粹愉悦的梦境。{/i}"
    envl "这是谁写的？"
    $ cs_right = "crow n sho"
    cnvl "..."
    cnvl "实际上，我们能再借一下吗？我觉得它可能会派上用场。"
    envl "好吧，你帮了我...好吧，给你。"
    nv "以利亚伸出一角照片，诺亚又拿了回来。果然，背面有一句奇怪的诗句。"
    $ elijah_photocomplete = True
    $ photopiece_singular = True
    nv "这些话让他感到一阵刺痛，仿佛直戳心脏。"
    nv "多年前的自己..."
    nvl clear

    $ nvl_hide(Dissolve(0.6))
    jump chapter2escaperepeat

label person4_photopiecesingular:
    $ gametype = "ADV"
    window show dissolve
    hide heavenescape
    no ann "这是什么意思..."
    c hap "这很美丽，不是吗？"
    "诺亚再次盯着那些字。"
    no sca "...是吗？"
    c sadsmi "孤独也有一种美。离开熟悉的道路，迷失在梦境中，这种孤独也有一种美。"
    nothought "也许这些话不是在描述我，而是在描述你..."
    window hide dissolve
    jump chapter2escaperepeat


label person4_photopiecesingularcomplete:
    $ gametype = "ADV"
    window show dissolve
    hide heavenescape
    no neu "好吧，你可以拿回去了。"
    e "你们回来了！找到我需要的胶带了吗？"
    no ann "不知为什么，是的。在这样的地方，谁会随身携带胶带，这真是个谜。"
    e "那就快点，把它给我！"
    $ default_mouse = "default"
    $ iteminhand = "None"
    $ elijah_givebackpiece = True
    window hide dissolve
    jump chapter2escaperepeat

label person4_tape:
    $ gametype = "ADV"
    window show dissolve
    hide heavenescape
    $ default_mouse = "default"
    $ iteminhand = "None"
    no neu "给你，你的胶带。"
    c neu "你不应该再丢失你的照片了。"
    e "谢谢你们两个..."
    e "这是你应得的。"
    no sho "一支...钢笔。"

    if person1_firstclicked:
        c hap"终于。看来我们终于可以完成这件事了。"
    else:
        c hap "我相信我们会找到有人能用到它的。"

    no neu "...谢谢你，以利亚。祝你在那里玩得开心。"
    "诺亚朝着大门点了点头。"
    e "哦，我会的。我会把这张照片给我妻子看，我们会一起回忆往事。啊，她已经在里面等我很久了。"
    no sho "..."
    no ann "听起来很好。"
    e "你在里面有人在等你吗？"
    no "我..."
    "诺亚的目光从大门转向克劳。"
    e "这种痛苦是永远无法完全愈合的。不要勉强自己谈论它。"
    "以利亚拍了拍诺亚的肩膀。"
    e "我希望你能找到你想要的。"
    c sad "..."
    $ elijah_givetape = True
    $ elijah_givebackpiece = True
    $ pen = True
    window hide dissolve
    jump chapter2escaperepeat

label person4_pen:
    $ gametype = "ADV"
    window show dissolve
    hide heavenescape

    c hap "以利亚能把这个给我们真是太好了。"
    no ann "是啊..."
    no "...你觉得他有什么选择吗？"
    c sur "你什么意思？"
    no "这只是...艾许的梦境。事情需要按照一定的顺序发展。"
    c "嗯...这是个有趣的想法。"
    c neu "但是你出现在这里又是怎么回事呢？这不是梦境的一部分。如果没有你在这里，它可能会朝完全不同的方向发展。"
    no neu "你呢？"
    "克劳沉思了片刻。"
    c hap "我只是一个观察者。"
    window hide dissolve
    jump chapter2escaperepeat
######## Person 3 | Reuben ##############
label person3_firstscene:
    hide heavenescape

    $ gametype = "NVL"
    $ charleft = "诺亚"
    $ charright = "克劳"

    $cs_left = "noah n neu"
    $cs_right = "crow n neu"


    $ nvl_show(Dissolve(1))
    nv "在队伍前面只有几个人的地方，站着一个留着长长的乱蓬蓬黑发的年轻人，他把头发扎成了一个凌乱的马尾。"
    nv "他踮起脚尖，越过别人的肩膀看看是什么阻碍了前进，但他似乎并不太在意这个延误。"
    nv "当他意识到短时间内是不会前进了，他从看似空气中抽出一本书，开始安静地翻阅。"
    $cs_right = "crow n hap"
    cnvl "真是个勤奋的人，即使在这样的地方。"


    if person6_firstclicked == False:
        nonvl "...我知道有一个人可以随时随地拿起一本书。"
        $ cs_right = "crow n sur"
        cnvl "哦？是你认识的人吗？"
        $ cs_left = "noah n ann"
        nonvl "我想是的。"
        nonvl "...鲁本？"
        nv "那个男人转过身来，眼睛在寻找呼唤他名字的来源，很快就锁定在了诺亚身上。片刻之后，他又把目光移开了。"
        notnvl "...他看起来确实很真实...但他只是这个梦境的一部分，是我哥哥想象出来的概念。"
        notnvl "不过，和他聊聊可能会有用。"

    else:
        $ cs_left = "noah n sho"
        nonvl "是鲁本..."
        $ cs_left = "noah n ann"
        nonvl "至少是我哥哥思维中创造的鲁本版本。"
        $cs_right = "crow n hap"
        cnvl "这个概念很有趣，不是吗？"
        cnvl "在这里，他非常活着...他会动，会呼吸，会思考，但他在你的世界里也是活着的。"
        nonvl "这算是真正的生活吗？"
        cnvl "你告诉我，你觉得你真的活在梦境之外吗？"
        $ cs_left = "noah n sho"
        nonvl "..."
        $cs_right = "crow n neu"
        cnvl "不管是不是真正的他，你哥哥还是想和他和解...而且他可能有办法让这条队伍前进。"
        cnvl "那我们就去和他聊聊吧？"

    $cs_right = "crow n sho"
    cnvl "你了解他吗？我完全不认识他。"
    $ cs_left = "noah n ann"
    nonvl "...有点。"
    nonvl "他是，或者曾经是，我哥哥最好的朋友。不过他很少来我家。"
    nonvl "我觉得...我父母不太喜欢他。"
    $cs_right = "crow n sadsmi"
    cnvl "他们喜欢谁呢？"
    $ cs_left = "noah n sho"
    nonvl "..."
    cnvl "..."
    cnvl "抱歉，我越界了。"
    $ cs_left = "noah n ann"
    nonvl "不，你说得对。"
    nonvl "他们是...曾经是那种充满仇恨和偏见的人，没有人能让他们满意。不是别人，也不是我。"
    nonvl "总之..."
    nonvl "我们去和他聊聊吧。"
    nv "两人慢慢地穿过蓬松的云朵，来到鲁本的身边。即使诺亚清了清嗓子想引起他的注意，他也没有从书本上移开目光。"

    $ cs_left = "noah n neu"
    nonvl "...鲁本？"
    nv "终于，他的眼睛离开了书页。"


    $ charright = "鲁本"
    $ cs_right = "reuben n neu"

    rnvl "..."
    rnvl "...你是谁？"
    $ cs_left = "noah n ann"
    nonvl "诺亚。"
    rnvl "诺亚..."
    nv "他的脑海中似乎有了一丝灵光。"
    $ cs_right = "reuben n sur"
    rnvl "艾许的弟弟？"
    $ cs_left = "noah n sca"
    nonvl "嗯，去掉\'弟弟\'这个部分...对。"
    $ cs_right = "reuben n neu"
    rnvl "你长大了好多。我都认不出你了..."
    nonvl "岁月确实会让人变化。"
    nonvl "总之，你在这里做什么？"
    notnvl "真是个愚蠢的问题...他没有任何真正的理由在这里。他甚至根本就不在这里。"
    nv "鲁本的目光落在前方的金色大门上，他的眼神里充满了悲伤和愤怒，这是诺亚无法完全理解的。"

    $ cs_right = "reuben n fro"
    rnvl "我来看我的母亲。"
    $ cs_left = "noah n sho"
    nonvl "你的...母亲？"
    nv "他耸了耸肩，似乎不想多谈。"
    $ cs_right = "reuben n neu"
    rnvl "我想是吧。"
    nv "他的目光又回到手中仍然翻开的书上。"
    nv "他很乐意让克劳和诺亚就这样静静地站在他身边。"
    nv "看到他们被忽视了，两人稍微走开了一点距离。"

    $ charright = "克劳"
    $ cs_right = "crow n sho"
    cnvl "他确实很喜欢读书。"
    $ cs_left = "noah n ann"
    nonvl "这是我唯一知道的关于他的事。"
    $ cs_right = "crow n hap"
    cnvl "也许我们可以利用这一点。"
    nv "诺亚忍不住微笑了。这听起来几乎就像是奥古斯特会说的话。"

    nvl clear

    $ nvl_hide(Dissolve(0.6))
    jump chapter2escaperepeat

label person3_hub:
    hide heavenescape
    $ gametype = "NVL"
    $ charleft = "诺亚"
    $ charright = "鲁本"

    $cs_left = "noah n neu"
    $cs_right = "reuben n neu"

    nv "鲁本仍然站在队伍的第三位，安静地读着他的书。"
    nv "自从诺亚上次看到他以来，他已经翻过了至少另外30页。"

    menu reuben_hub:
        "我有一个消息要传达" if person6_firstclicked and not asher_talkedtoreuben:
            nonvl "我被要求给你传达一个消息。"
            nv "最后，鲁本从书中抬起头来。"
            $ charright = "鲁本"
            $cs_right = "reuben n neu"
            rnvl "里面有什么？"
            $ cs_left = "noah n ann"
            nonvl "这是...来自艾许的。"
            nv "尽管到目前为止这个男人一直相对无情，但这个名字似乎让他偏过头去。"
            $cs_right = "reuben n sur"
            rnvl "..."
            rnvl "他想要什么？"
            nonvl "他说..."
            nvl hide dissolve
            call screen chapter2_input with dissolve

        "你在读什么？" if not reuben_whatareyoureading:
            $ reuben_whatareyoureading = True
            $ cs_left = "noah n neu"
            nonvl "嘿，鲁本..."
            $ charright = "鲁本"
            $cs_right = "reuben n neu"
            rnvl "嗯？"
            nv "他从书中抬起头来。"
            nonvl "你在读什么？"
            nv "他又低下头看书。"
            rnvl "一本书。"
            $ cs_left = "noah n hur"
            nonvl "..."
            $ charright = "克劳"
            $cs_right = "crow n hap"
            cnvl "讲的是什么？"
            cnvl "我从来没有读过书。"
            $ charright = "鲁本"
            $cs_right = "reuben n neu"
            rnvl "..."
            $cs_right = "reuben n smi"
            rnvl "这是关于一个孤儿离开家乡，挑战命运的故事。"
            $ charright = "克劳"
            $cs_right = "crow n hap"
            cnvl "听起来很有趣。你经常读书吗？"
            nv "鲁本点了点头，仍然专注于阅读。"
            $ cs_left = "noah n sca"
            nonvl "你在大学学习文学吗？"
            nonvl "我好像记得你...很久以前说过你想学文学。"
            $ charright = "鲁本"
            $cs_right = "reuben n neu"
            rnvl "不，我只是喜欢读书。我15岁的时候就辍学了。"
            $ charright = "克劳"
            $cs_right = "crow n sur"
            cnvl "有什么特别的原因吗？"
            $ charright = "鲁本"
            $cs_right = "reuben n sur"
            rnvl "...为了帮助我的弟弟吧，我们两个人一起长大。"
            rnvl "我能做的最少就是帮助他实现目标。"
            $ cs_left = "noah n ann"
            nonvl "哈。我的弟弟宁死也不会为了支持我而辍学。"
            $cs_right = "reuben n neu"
            rnvl "不过他还是辍学了。"
            $ cs_left = "noah n sho"
            nonvl "他...什么？"
            nv "他又耸了耸肩，眼睛仍然盯着眼前页面上的文字。"
            rnvl "如果你想知道的话，可以问问他。"
            nvl clear
            jump reuben_hub

        "等等，你用什么做书签了？" if asherpaper_1 and not asherpaper_2:
            $ asherpaper_2 = True
            $ cs_left = "noah n sho"
            nv "诺亚的眼睛落在鲁本的书上...特别是他用来做书签的东西。"
            nonvl "等等，那是什么？"
            $ charright = "鲁本"
            $ cs_right = "reuben n neu"
            rnvl "...?"
            rnvl "一本书..."
            nonvl "不，我是说...好吧，是的，它是..."
            nonvl "书签！"
            $ cs_right = "reuben n sur"
            rnvl "哦，这个啊？"
            rnvl "只是我随手找到的一片纸..."
            nonvl "你看到的和我看到的一样吗？"
            $ charright = "克劳"
            $ cs_right = "crow n sho"
            cnvl "是的...这肯定是艾许给你的那张纸的另一半。"
            nonvl "...我们能要回来吗？"
            $ charright = "鲁本"
            $ cs_right = "reuben n sur"
            rnvl "什么...但是..."
            rnvl "我会丢失页码的..."
            $ cs_left = "noah n ann"
            nonvl "呃...拜托了？"
            nonvl "就把角落折起来。"
            $ cs_right = "reuben n ann"
            nv "鲁本露出了一种几乎像是厌恶的表情，看着诺亚。"
            rnvl "折...折角落？然后损坏书本？"
            nonvl "拜托...我们真的需要它..."
            rnvl "..."
            rnvl "好吧...如果你答应帮我做点事。"
            $ cs_left = "noah n sho"
            nonvl "你居然会在我帮你之前给我东西？"
            nonvl "这还是头一次。"
            rnvl "...因为我相信你。"
            nonvl "你...相信我？"
            $ cs_right = "reuben n neu"
            rnvl "你一直都是个好孩子。"
            rnvl "而且你还得忍受艾许。"
            nv "诺亚不由自主地向后退了一步，感到很惊讶。"
            nonvl "谢...谢谢？"
            $ charright = "克劳"
            $ cs_right = "crow n hap"
            cnvl "那我们能帮你做什么呢？"
            $ charright = "鲁本"
            $ cs_right = "reuben n neu"
            rnvl "我找到了这个..."
            nv "鲁本举起一本无名的皮面书。侧面有一个锁。"
            nv "这个锁似乎是根据颜色来打开，而不是数字。"
            rnvl "它和我的书放在一起。我想把它打开。"
            $ charright = "克劳"
            $ cs_right = "crow n sho"
            cnvl "里面有什么？"
            $ charright = "鲁本"
            $ cs_right = "reuben n neu"
            rnvl "我想这是一本日记。"
            $ charright = "克劳"
            $ cs_right = "crow n sho"
            cnvl "什么是日记？"
            nonvl "...?"
            $ cs_left = "noah n neu"
            nonvl "呃...一本你可以写下你的感受、发生的事情之类的东西。"
            $ charright = "克劳"
            $ cs_right = "crow n hap"
            cnvl "哦！听起来不错。"
            $ charright = "鲁本"
            $ cs_right = "reuben n ann"
            rnvl "我想它...属于我母亲的..."
            rnvl "也许一切都会有意义...也许有一个好的理由..."
            nvl clear
            jump reuben_hub

        "我能看看那本日记吗？" if asherpaper_2 and not reuben_solveddiary:
            $ charleft = "诺亚"
            $ charright = "鲁本"

            $cs_left = "noah n neu"
            $cs_right = "reuben n neu"

            nonvl "你能给我看看你找到的那本日记吗？"
            $cs_right = "reuben n sur"
            nonvl "我想我知道密码是什么。"
            nv "鲁本小心翼翼地合上了他的书，看起来有些感兴趣。"
            nv "...检查了一下页码以记住它，没有用书签。"
            rnvl "给你。"
            nvl hide dissolve
            call screen reuben_diary with dissolve


        "够了":
            nvl clear

            $ nvl_hide(Dissolve(0.6))
            jump chapter2escaperepeat

default chapter2_button1 = 1
default chapter2_button2 = 1
default chapter2_button3 = 1
default chapter2_button4 = 1

screen reuben_diary:
    add "images/puzzles/overlay.png"
    add "images/puzzles/frame.png"

    textbutton "Close" action [Hide("reuben_diary", dissolve), Jump("chapter2escaperepeat")]:
        text_color "#ffffff"
        text_hover_color "#dcad2b"
        xalign 0.93 yalign 0.1

    textbutton "Hint":
        xalign 0.87 yalign 0.1
        text_color "#fafafa"
        text_hover_color "#ecb92e"
        if reubendiaryhint == 1:
            action [SetVariable("reubendiaryhint", reubendiaryhint + 1), Show("reubendiaryhint1", dissolve)]
        elif reubendiaryhint == 2:
            action Show("reubendiaryhint2", dissolve)


    hbox:
        align 0.65, 0.4
        spacing -50
        if chapter2_button1 == 1: ########## button 1
            imagebutton:
                idle "images/puzzles/chapter_2/button_blue.png"
                hover "images/puzzles/chapter_2/button_blue.png"
                action  [Play("sound", "audio/sfx/click.ogg"), SetVariable("chapter2_button1", chapter2_button1 + 1), Jump("chapter2_diarychecker")]
        elif chapter2_button1 == 2: ########## button 1
            imagebutton:
                idle "images/puzzles/chapter_2/button_green.png"
                hover "images/puzzles/chapter_2/button_green.png"
                action  [Play("sound", "audio/sfx/click.ogg"), SetVariable("chapter2_button1", chapter2_button1 + 1), Jump("chapter2_diarychecker")]
        elif chapter2_button1 == 3: ########## button 1
            imagebutton:
                idle "images/puzzles/chapter_2/button_red.png"
                hover "images/puzzles/chapter_2/button_red.png"
                action  [Play("sound", "audio/sfx/click.ogg"), SetVariable("chapter2_button1", chapter2_button1 + 1), Jump("chapter2_diarychecker")]
        elif chapter2_button1 == 4: ########## button 1
            imagebutton:
                idle "images/puzzles/chapter_2/button_yellow.png"
                hover "images/puzzles/chapter_2/button_yellow.png"
                action  [Play("sound", "audio/sfx/click.ogg"), SetVariable("chapter2_button1", 1), Jump("chapter2_diarychecker")]

        if chapter2_button2 == 1: ########## button 2
            imagebutton:
                idle "images/puzzles/chapter_2/button_blue.png"
                hover "images/puzzles/chapter_2/button_blue.png"
                action  [Play("sound", "audio/sfx/click.ogg"), SetVariable("chapter2_button2", chapter2_button2 + 1), Jump("chapter2_diarychecker")]
        elif chapter2_button2 == 2: ########## button 2
            imagebutton:
                idle "images/puzzles/chapter_2/button_green.png"
                hover "images/puzzles/chapter_2/button_green.png"
                action  [Play("sound", "audio/sfx/click.ogg"), SetVariable("chapter2_button2", chapter2_button2 + 1), Jump("chapter2_diarychecker")]
        elif chapter2_button2 == 3: ########## button 2
            imagebutton:
                idle "images/puzzles/chapter_2/button_red.png"
                hover "images/puzzles/chapter_2/button_red.png"
                action  [Play("sound", "audio/sfx/click.ogg"), SetVariable("chapter2_button2", chapter2_button2 + 1), Jump("chapter2_diarychecker")]
        elif chapter2_button2 == 4: ########## button 2
            imagebutton:
                idle "images/puzzles/chapter_2/button_yellow.png"
                hover "images/puzzles/chapter_2/button_yellow.png"
                action  [Play("sound", "audio/sfx/click.ogg"), SetVariable("chapter2_button2", 1), Jump("chapter2_diarychecker")]

        if chapter2_button3 == 1: ########## button 3
            imagebutton:
                idle "images/puzzles/chapter_2/button_blue.png"
                hover "images/puzzles/chapter_2/button_blue.png"
                action  [Play("sound", "audio/sfx/click.ogg"), SetVariable("chapter2_button3", chapter2_button3 + 1), Jump("chapter2_diarychecker")]
        elif chapter2_button3 == 2: ########## button 3
            imagebutton:
                idle "images/puzzles/chapter_2/button_green.png"
                hover "images/puzzles/chapter_2/button_green.png"
                action  [Play("sound", "audio/sfx/click.ogg"), SetVariable("chapter2_button3", chapter2_button3 + 1), Jump("chapter2_diarychecker")]
        elif chapter2_button3 == 3: ########## button 3
            imagebutton:
                idle "images/puzzles/chapter_2/button_red.png"
                hover "images/puzzles/chapter_2/button_red.png"
                action  [Play("sound", "audio/sfx/click.ogg"), SetVariable("chapter2_button3", chapter2_button3 + 1), Jump("chapter2_diarychecker")]
        elif chapter2_button3 == 4: ########## button 3
            imagebutton:
                idle "images/puzzles/chapter_2/button_yellow.png"
                hover "images/puzzles/chapter_2/button_yellow.png"
                action  [Play("sound", "audio/sfx/click.ogg"), SetVariable("chapter2_button3", 1), Jump("chapter2_diarychecker")]

        if chapter2_button4 == 1: ########## button 4
            imagebutton:
                idle "images/puzzles/chapter_2/button_blue.png"
                hover "images/puzzles/chapter_2/button_blue.png"
                action  [Play("sound", "audio/sfx/click.ogg"), SetVariable("chapter2_button4", chapter2_button4 + 1), Jump("chapter2_diarychecker")]
        elif chapter2_button4 == 2: ########## button 4
            imagebutton:
                idle "images/puzzles/chapter_2/button_green.png"
                hover "images/puzzles/chapter_2/button_green.png"
                action  [Play("sound", "audio/sfx/click.ogg"), SetVariable("chapter2_button4", chapter2_button4 + 1), Jump("chapter2_diarychecker")]
        elif chapter2_button4 == 3: ########## button 4
            imagebutton:
                idle "images/puzzles/chapter_2/button_red.png"
                hover "images/puzzles/chapter_2/button_red.png"
                action  [Play("sound", "audio/sfx/click.ogg"), SetVariable("chapter2_button4", chapter2_button4 + 1), Jump("chapter2_diarychecker")]
        elif chapter2_button4 == 4: ########## button 4
            imagebutton:
                idle "images/puzzles/chapter_2/button_yellow.png"
                hover "images/puzzles/chapter_2/button_yellow.png"
                action  [Play("sound", "audio/sfx/click.ogg"), SetVariable("chapter2_button4", 1), Jump("chapter2_diarychecker")]

screen reubendiaryhint1:
    modal True

    add "images/Various/black overlay.png"
    add "gui/popup.png" xalign 0.5 yalign 0.5
    text "Hint" xalign 0.5 yalign 0.34 color "#fefefe" size 50
    textbutton "x" action [Hide("reubendiaryhint1", dissolve)]:
        text_color "#ffffff"
        text_hover_color "#dcad2b"
        xalign 0.68
        yalign 0.28
    vbox:
        xanchor 0.0
        spacing 20.0
        xpos 700
        ypos 450
        text "再次与黛西交谈，找出密码是什么。"
        text "再次点击提示按钮可获得答案。"

screen reubendiaryhint2:
    modal True

    add "images/Various/black overlay.png"
    add "gui/popup.png" xalign 0.5 yalign 0.5
    text "Hint" xalign 0.5 yalign 0.34 color "#fefefe" size 50
    textbutton "x" action [Hide("reubendiaryhint2", dissolve)]:
        text_color "#ffffff"
        text_hover_color "#dcad2b"
        xalign 0.68
        yalign 0.28
    vbox:
        xanchor 0.0
        spacing 20.0
        xpos 700
        ypos 450
        text "密码是：红色、红色、绿色、黄色。"

label chapter2_diarychecker:
    if chapter2_button1 == 3 and chapter2_button2 == 3 and chapter2_button3 == 2 and chapter2_button4 == 4:
        jump chapter2_diarycomplete
    else:
        call screen reuben_diary

label chapter2_diarycomplete:
    $ reuben_solveddiary = True
    $ charright = "鲁本"
    $cs_right = "reuben n neu"

    nv "随着一声咔嗒，锁打开了。鲁本惊讶地看着它，好像他并没有真的指望它会打开。"
    $ charright = "克劳"
    $cs_right = "crow n neu"
    cnvl "你为什么不打开它？"
    $ charright = "鲁本"
    $cs_right = "reuben n neu"
    rnvl "..."
    nv "似乎有些担心，他慢慢地打开了封面，把它背对着小组。"
    $cs_right = "reuben n sur"
    nv "他的眼睛瞪大了一会儿，然后惊讶的表情消失了。"
    $cs_right = "reuben n ann"
    rnvl "...里面是空的。当然是空的。"
    rnvl "我不知道我期待会发生什么。"
    $ charright = "克劳"
    $cs_right = "crow n sho"
    cnvl "页面中间有什么东西吗？"
    $ charright = "鲁本"
    $cs_right = "reuben n ann"
    rnvl "一些...撕碎的照片。"
    rnvl "给你。"
    nv "鲁本把它递给诺亚。"
    $ cs_left = "noah n sho"
    nonvl "你确定吗？不过，它可能是你母亲的东西..."
    rnvl "...."
    rnvl "不是。她不会给我留下任何东西。"
    rnvl "请拿着它。"
    nv "诺亚小心翼翼地接过碎片，鲁本又回到了他的书上。"
    $cs_right = "reuben n neu"
    rnvl "...谢谢你，诺亚。"
    $ cs_left = "noah n ann"
    nonvl "没什么大不了的。"
    $ cs_left = "noah n ann"
    nonvl "嘿，你还住在...家乡吗？"
    rnvl "我怀疑我永远也不会离开那个小镇。"
    nonvl "我明白..."
    notnvl "这没有任何意义...这甚至不是他..."
    nonvl "如果...如果我有一天回到那里..."
    rnvl "你可以来拜访我，如果你愿意的话。"
    nonvl "...谢谢，我会考虑的。"
    $cs_right = "reuben n smi"
    nv "当诺亚和克劳转身离开时，鲁本露出了一个罕见的微笑，手中还拿着那些照片碎片。"
    $ charright = "克劳"
    $cs_right = "crow n neu"
    cnvl "...鲁本是个善良的人。"
    nonvl "是啊...他是怎么忍受我哥哥的，我永远也不会知道。"
    cnvl "你会去看他吗？"
    nonvl "...."
    $ cs_left = "noah n neu"
    nonvl "也许...也许有一天我回去的时候..."
    nv "克劳笑了，他的脸像太阳一样明亮。"
    $cs_right = "crow n hap"
    cnvl "我很高兴听到这个。"


    $ photopieces = True
    $ photopiece_counter += 1
    nvl clear
    jump reuben_hub
label asher_message_correct:
    nonvl "{i}在温暖的夏夜下，在星空之下。{/i}"
    $cs_right = "reuben n sur"
    rnvl "..."
    rnvl "他觉得这样做就能让一切都好起来吗？"
    rnvl "我想，既然是他，他肯定会这么想..."
    $cs_right = "reuben n neu"
    rnvl "好吧，告诉他我很快就会去找他谈谈。"
    $cs_left = "noah n sho"
    nonvl "...你们为什么吵架？"
    nv "鲁本直视着诺亚的眼睛。"
    rnvl "主要是你。"
    $cs_left = "noah n sur"
    nonvl "我...？"
    nonvl "为什么？"
    rnvl "重要吗？我在看书...我们可以后来再谈。"
    $cs_left = "noah n ann"
    nonvl "不，不，对你来说没有\'后来\'了。你只是..."
    $ charright = "克劳"
    $ cs_right = "crow n sad"
    cnvl "..."
    nonvl "...好吧。是的，我们可以后来再谈。"
    nonvl "快点把书看完。"
    $ charright = "鲁本"
    $ cs_right = "reuben n neu"
    rnvl "好的，但这是一个系列的第一本，我这里有全12本。"
    $cs_left = "noah n hur"
    nonvl "好的..."

    $ asher_talkedtoreuben = True
    nvl clear
    jump reuben_hub
label asher_message_incorrect:
    rnvl "什么？这是什么意思？"
    $ cs_left = "noah n sho"
    nonvl "抱歉，我...我好像忘了...我一会儿就回来。"
    nvl clear
    jump reuben_hub

label person3_note1:
    $ gametype = "ADV"
    window show dissolve
    hide heavenescape
    reu neu "你为什么要给我看这个？"
    no ann "呃...只是看看你是否认识它..."
    reu "..."
    reu "看起来就是一张纸。"
    c hap "真有见地..."
    window hide dissolve
    jump chapter2escaperepeat

label person3_note2:
    $ gametype = "ADV"
    window show dissolve
    hide heavenescape
    no neu "谢谢你给我另一半。看，它完整了。"
    "鲁本从书中抬起头，漠不关心地看着。"
    reu neu "很好。"
    "然后继续阅读。"
    window hide dissolve
    jump chapter2escaperepeat

style input_style:
    color "#ecb92e"
image input_chap2 = "images/puzzles/chapter_2/input.png"
screen chapter2_input:
    add "input_chap2"

    textbutton "Confirm":
        xalign 0.60 yalign 0.65
        text_color "#fafafa"
        text_hover_color "#ecb92e"

        if asher_messageplayer.lower().strip() in asher_messagercorrect:
            action [Hide("chapter2_input", dissolve), Jump("asher_message_correct")]
        else:
            action [Hide("chapter2_input", dissolve), Jump("asher_message_incorrect")]

    textbutton "Hint":
        xalign 0.39 yalign 0.65
        text_color "#fafafa"
        text_hover_color "#ecb92e"
        if ashermessagehint == 1:
            action [SetVariable("ashermessagehint", ashermessagehint + 1), Show("ashermessagehint1", dissolve)]
        elif ashermessagehint == 2:
            action Show("ashermessagehint2", dissolve)



    vbox:
        xalign 0.5 yalign 0.5

        hbox:
            box_wrap True
            xalign 0.5 yalign 0.5
            xsize 250
            input:
                default ""
                value VariableInputValue('asher_messageplayer')
                pixel_width 620
                style "input_style"

screen ashermessagehint1:
    modal True

    add "images/Various/black overlay.png"
    add "gui/popup.png" xalign 0.5 yalign 0.5
    text "Hint" xalign 0.5 yalign 0.34 color "#fefefe" size 50
    textbutton "x" action [Hide("ashermessagehint1", dissolve)]:
        text_color "#ffffff"
        text_hover_color "#dcad2b"
        xalign 0.68
        yalign 0.28
    vbox:
        xanchor 0.0
        spacing 20.0
        xpos 700
        ypos 450
        text "再次与艾许交谈，了解消息的内容。"
        text "再次点击提示按钮可获得答案。"

screen ashermessagehint2:
    modal True

    add "images/Various/black overlay.png"
    add "gui/popup.png" xalign 0.5 yalign 0.5
    text "Hint" xalign 0.5 yalign 0.34 color "#fefefe" size 50
    textbutton "x" action [Hide("ashermessagehint2", dissolve)]:
        text_color "#ffffff"
        text_hover_color "#dcad2b"
        xalign 0.68
        yalign 0.28
    vbox:
        xanchor 0.0
        spacing 20.0
        xpos 700
        ypos 450
        text "Type the following: \nunder the starry sky on a warm summer night"

label person3_photopieces:
    $ gametype = "ADV"
    window show dissolve
    hide heavenescape
    "诺亚低头看着手中的照片碎片。"
    "过去的碎片，如同一种挥之不去的幽灵，永远定格在时间中，永远无法触及。"
    "但诺亚只想要更多的碎片。更多过去的碎片。更多属于自己过去的碎片。"
    window hide dissolve
    jump chapter2escaperepeat

label person3_photopiecesingular:
    $ gametype = "ADV"
    window show dissolve
    hide heavenescape
    no neu "咳咳，鲁本..."
    reu neu "..."
    c sho "鲁本？"
    reu neu "..."
    "直到诺亚在鲁本低垂的眼睛前挥手，他才终于注意到有人在跟他说话。他合上了书。"
    reu "怎么了...？"
    c neu "我们很抱歉打扰到你的阅读...但我们有个问题。"
    no neu "这个，对你有什么意义吗？"
    reu sur "..."
    reu neu "诗歌？我不知道你对这个感兴趣。"
    no sca "呃，这不是我写的。"
    reu neu "哦。"
    reu smi"很漂亮。看起来像是艾许会喜欢的东西。"
    reu neu "但是，我从未见过它。"
    window hide dissolve
    jump chapter2escaperepeat

label person3_tape:
    $ gametype = "ADV"
    window show dissolve
    hide heavenescape
    no ann "我想你可能不需要胶带。也许是用来修补书籍的？"
    reu sur "一个{i}什么{/i}？"
    reu sur "我从不撕书。"
    c sho "从来没有？"
    reu "从来没有。它们是我的珍宝。"
    window hide dissolve
    jump chapter2escaperepeat

label person3_pen:
    $ gametype = "ADV"
    window show dissolve
    hide heavenescape
    no neu "...你有没有考虑过自己写作？"
    reu sur "写作？"
    reu "...有一点。"
    reu "我想我只是害怕，我写出来的东西不会像我喜欢的那些故事一样好。"
    c neu "这种对自己与所爱的事物进行比较的恐惧，是很人性化的。"
    c "但你内心的故事是百分之百属于你自己的，这就使它们值得被讲述。"
    c hap "我...谢谢你。"
    reu sur "..."
    reu emb "我...谢谢你。"
    window hide dissolve
    jump chapter2escaperepeat

######## Person 2 | Prof Pearson ##############
label person2_firstscene:
    hide heavenescape

    $ gametype = "NVL"
    $ charleft = "诺亚"
    $ charright = "克劳"

    $ cs_left = "noah n neu"
    $ cs_right = "crow n neu"


    $ nvl_show(Dissolve(1))
    nv"在队伍前面的第二个人，一个穿着套装、戴眼镜的女士发出了一声哼声，望着门外的那个人。"

    if person4_firstclicked:
        nv "就像以利亚一样，她的形态似乎在波动。她从几乎看不见到更加实体化，但她的面貌并不清晰。"
    else:
        $ cs_left = "noah n sho"
        nonvl "她为什么会这样...？"
        $ cs_right = "crow n sho"
        cnvl "我想艾许对她并没有太多依恋...要创造出完全栩栩如生的人需要梦境主人强大的精神力量。"
        cnvl "所以有时候人物就会变成这样。"
        nonvl "..."
        $ cs_left = "noah n ann"
        nonvl "我想这和现实世界也没什么不同。"
        nonvl "在街上你会遇到多少人，却从未记住或再想起过？"
        $ cs_left = "noah n neu"
        nonvl "我们可以跟她说话吗？"
        $ cs_right = "crow n neu"
        cnvl "应该可以。"

    nonvl "对不起，小姐—"
    $ cs_left = "noah n sho"
    unvl "小姐？你刚才叫我小姐？"
    pnvl "请叫我皮尔森教授，要有些尊重。"
    $ cs_right = "crow n sho"
    cnvl "呃..."
    $ cs_left = "noah n ann"
    nonvl "...."
    notnvl "天哪，这肯定会很有趣，不是吗？"
    $ cs_left = "noah n sca"
    nonvl "...好吧。我的错。"
    pnvl "你的错什么？"
    nonvl "呃..."
    nonvl "对不起，我想我们开始得不太好...皮尔森教授。"
    pnvl "至少你那有限的智力还记得我的名字。"
    notnvl "你两秒钟前才告诉我的...！"
    pnvl "有什么我可以帮到你们的吗？"
    $ cs_right = "crow n neu"
    cnvl "实际上，我们也想问你同样的问题。"
    pnvl "我？需要别人的帮助？"
    nonvl "但你和其他人一样，也被困在这里。"
    pnvl "这不是我的错。不像某些人。"
    nv "她狠狠地瞪着站在她前面的那个人。"
    cnvl "如果我们告诉你，有了你的帮助，我们就能让这条队伍动起来呢？"
    pnvl "我会说你把我当成了傻瓜。"
    $ cs_left = "noah n ann"
    nonvl "不，真的，这就是我们正在做的..."
    nv "突然间，教授向前倾身，把她那阴影般的眼镜推得更高了。"
    pnvl "我觉得我认识你。你是我的学生吗？"
    $ cs_left = "noah n sho"
    nonvl "呃...不，对不起，我想不是。"
    nv "一个灵光一闪在诺亚的脑海中。"
    nonvl "等等，除非你是说...艾许？他是我的弟弟。"
    pnvl "艾许...艾许...是的，我记得他。"
    pnvl "他头脑聪明，却缺乏专注。用更简单的话说，他做事都是敷衍了事。"
    nonvl "但是...他一直都是个超级学霸。"
    pnvl "超级学霸？不，他挂掉了我的课。"
    $ cs_left = "noah n sur"
    nonvl "他{i}什么{/i}？"

    if reuben_whatareyoureading:
        notnvl "鲁本说艾许真的退学了，看来他说的是实话..."

    nv "她的声音似乎有一瞬间的动摇，变得更柔和了。"
    pnvl "...这真是太遗憾了，因为他的学习天赋确实...很出色。"
    nonvl "那么...为什么？"
    nv "她耸了耸肩。"
    pnvl "我只能对此做出假设。也许他是个天赋异禀的孩子，一直依靠这种优势，直到它逐渐消失了，又或者他太忙于其他事情而无暇顾及学习。"
    pnvl "无论如何，我都无法给他及格。"
    pnvl "...即使我想这么做。"
    $ cs_left = "noah n ann"
    nonvl "我明白..."
    pnvl "但那都是过去的事了。我曾试图劝他重新上这门课，但我相信他太羞愧而不愿这么做。"
    pnvl "骄傲确实是人类的一大弱点。"
    pnvl "不过这已经不重要了。除非你能解决我的娱乐问题，否则我想我也帮不了你什么。"
    $ cs_right = "crow n sho"
    cnvl "你的娱乐问题？"
    pnvl "这与你无关。快走吧。"
    nv "她双臂交叉在胸前，几乎是带着鄙夷的神情望着这对人。"
    nv "看到这个迹象，这对人决定离开教授。"
    cnvl "看来我们需要说服她告诉我们她需要什么帮助。"
    cnvl "有什么想法吗？"
    $ cs_left = "noah n sca"
    nonvl "嗯..."
    nonvl "她似乎有点喜欢我哥哥。有点吧。也许。"
    nonvl "说实话，我不确定她是否喜欢任何人，但值得一试。"
    nonvl "跟艾许谈谈他的学习...这肯定不会有什么好结果..."

    nvl clear

    $ nvl_hide(Dissolve(0.6))
    jump chapter2escaperepeat

label person2_hub:
    hide heavenescape
    $ gametype = "NVL"
    $ charleft = "诺亚"
    $ charright = "克劳"

    $cs_left = "noah n neu"
    $cs_right = "crow n neu"

    nv "皮尔森教授完全无视了诺亚和克劳的存在。"
    nv "即使克劳尴尬地清了清嗓子想引起她的注意，她的眼睛也没有看向他们。"

    menu PP_hub:
        "一个...娱乐问题？" if not asher_dropoutofschool2 and not PP_askedfailed:
            $ PP_askedfailed = True
            nonvl "对不起，女士—"
            $cs_left = "noah n sca"
            nonvl "呃，皮尔森教授。"
            nonvl "您能告诉我们您的...娱乐问题吗？"
            pnvl "不。请去找别人烦吧。"
            nvl clear
            jump PP_hub
        "我跟艾许谈过了" if asher_dropoutofschool2 and not PP_talkedtoasher:
            $ PP_talkedtoasher = True
            $ charleft = "诺亚"
            $ charright = "克劳"
            $cs_left = "noah n neu"
            $cs_right = "crow n neu"

            if asherpaper_pp_tracker:
                pnvl "如果你们是来给我看一些随机的东西，那就请去烦别人吧。"
                $cs_left = "noah n ann"
                nonvl "不，不是那样的..."

            $cs_left = "noah n ann"
            nonvl "我跟艾许谈过了。"
            $cs_left = "noah n neu"
            nonvl "我告诉他应该重修您的课。"
            pnvl "哦。"
            pnvl "这真是出乎意料。"
            nonvl "他似乎担心您会再次不及格他。"
            pnvl "如果他不努力学习，那是的。"
            pnvl "但如果他努力了，我很乐意让他及格。"
            pnvl "上天保佑，我们需要更多重视知识的人。"
            pnvl "谢谢...？"
            nonvl "我叫诺亚，这是克劳。"
            pnvl "好的，我很感谢你们的行动。我期待着看到他再次尝试。"
            nvl clear
            jump PP_hub

        "那么，娱乐问题？" if PP_talkedtoasher and not PP_askedsucc:
            $ PP_askedsucc = True
            $ charleft = "诺亚"
            $ charright = "克劳"
            $cs_left = "noah n neu"
            $cs_right = "crow n neu"
            nonvl "那么—"
            pnvl "好吧，好吧，你们已经够执着的了。行吧。"
            pnvl "确实有件事你们可以帮我。"
            pnvl "我不会浪费你们的时间来冗长地解释。我父亲是一位多产的作家，在他去世前留给我一本他的个人作品集。"
            pnvl "那时我才七岁。他在文字中创造了谜题和难题，这样在他离世后我还能拥有他的一部分。"
            nv "教授叹了口气，显得很烦恼。"
            pnvl "但是今天，他的一些话被风吹走了。"
            pnvl "如果你们能帮我找到它们，那我确实会尽我所能帮助你们。"
            $cs_right = "crow n hap"
            cnvl "...这真是一件多么美好的事情，留给挚爱的人。毕竟，什么比来自心底的话语更珍贵呢？"
            nvl clear
            jump PP_hub

        "够了":
            nvl clear

            $ nvl_hide(Dissolve(0.6))
            jump chapter2escaperepeat

label person2_photopieces:
    $ gametype = "ADV"
    window show dissolve
    hide heavenescape
    pp "请把你们的纸片自己留着吧。"
    nothought "她连看都不看一眼..."
    window hide dissolve
    jump chapter2escaperepeat

label person2_photopiecesingular_fail:
    $ gametype = "ADV"
    window show dissolve
    hide heavenescape
    no neu "教授—"
    pp "不管是什么，我都不感兴趣。"
    window hide dissolve
    jump chapter2escaperepeat

label person2_asherpaper:
    $ gametype = "ADV"
    window show dissolve
    hide heavenescape
    $ asherpaper_pp_tracker = True
    pp "这就是你所做的全部吗？"
    pp "到处拿着小纸片给人看？"
    c hap "有时候我们也有其他东西！"
    pp "真不错。"
    window hide dissolve
    jump chapter2escaperepeat

label person2_photopiecesingular_succ:
    $ gametype = "ADV"
    window show dissolve
    hide heavenescape
    $ default_mouse = "default"
    $ iteminhand = "None"

    if not PP_showedpaper:
        $ PP_showedpaper = True
        no neu "这就是你要找的东西吗？"
        "诺亚把伊莱亚借给他的那张照片碎片递了出去。"
        "背面写着一句话。这句话似乎立刻引起了教授的注意。"
        pp "是的！"
        pp "嗯...是的，是的，这就是它。谢谢。"
        "她小心翼翼地打开一本装订好的日记，然后又把它合上，那张纸片还在里面。"
        no sca "哦，呃...我们实际上必须把它还回去。有人把它借给了我。"
        pp "嗯，好吧。"
        pp "我想我会允许的。"
        pp "给你。"
        "她把日记递给诺亚，诺亚挑起眉毛接过来。"
        no sho "呃...？"
        pp "如果你想要它回来，那就解开它。"
        no sca "对...当然..."
        c hap "我想你应该早就料到会是这样的。"
    else:
        no neu "我能再看一眼那个谜题吗？"
        pp "随你便。"
    window hide
    call screen chapter2_wordsearch with dissolve

screen chapter2_wordsearch:
    modal True
    add "images/puzzles/overlay.png"
    add "images/puzzles/frame.png"
    add "images/puzzles/chapter_2/wordsearch_hint.png"

    imagemap:
        ground "images/puzzles/chapter_2/wordsearch_base.png"
        idle "images/puzzles/chapter_2/wordsearch_base.png"
        hover "images/puzzles/chapter_2/wordsearch_hover.png"
        selected_idle "images/puzzles/chapter_2/wordsearch_hover.png"
        selected_hover "images/puzzles/chapter_2/wordsearch_hover.png"

        # column one
        hotspot (858, 90, 69, 73) action ToggleVariable("chaptertwo_10", True, False)
        hotspot (858, 165, 69, 73) action ToggleVariable("chaptertwo_11", True, False)
        hotspot (858, 241, 69, 73) action ToggleVariable("chaptertwo_12", True, False)
        hotspot (858, 321, 69, 73) action ToggleVariable("chaptertwo_13", True, False)
        hotspot (858, 397, 69, 73) action ToggleVariable("chaptertwo_14", True, False)
        hotspot (858, 475, 69, 73) action ToggleVariable("chaptertwo_15", True, False)
        hotspot (858, 551, 69, 73) action ToggleVariable("chaptertwo_16", True, False)
        hotspot (858, 626, 69, 73) action ToggleVariable("chaptertwo_17", True, False)
        hotspot (858, 705, 69, 73) action ToggleVariable("chaptertwo_18", True, False)
        hotspot (858, 780, 69, 73) action ToggleVariable("chaptertwo_19", True, False)

        # column two
        hotspot (937, 90, 69, 73) action ToggleVariable("chaptertwo_20", True, False)
        hotspot (937, 165, 69, 73) action ToggleVariable("chaptertwo_21", True, False)
        hotspot (937, 241, 69, 73) action ToggleVariable("chaptertwo_22", True, False)
        hotspot (937, 321, 69, 73) action ToggleVariable("chaptertwo_23", True, False)
        hotspot (937, 397, 69, 73) action ToggleVariable("chaptertwo_24", True, False)
        hotspot (937, 475, 69, 73) action ToggleVariable("chaptertwo_25", True, False)
        hotspot (937, 551, 69, 73) action ToggleVariable("chaptertwo_26", True, False)
        hotspot (937, 626, 69, 73) action ToggleVariable("chaptertwo_27", True, False)
        hotspot (937, 705, 69, 73) action ToggleVariable("chaptertwo_28", True, False)
        hotspot (937, 780, 69, 73) action ToggleVariable("chaptertwo_29", True, False)

        # column three
        hotspot (1012, 90, 69, 73) action ToggleVariable("chaptertwo_30", True, False)
        hotspot (1012, 165, 69, 73) action ToggleVariable("chaptertwo_31", True, False)
        hotspot (1012, 241, 69, 73) action ToggleVariable("chaptertwo_32", True, False)
        hotspot (1012, 321, 69, 73) action ToggleVariable("chaptertwo_33", True, False)
        hotspot (1012, 397, 69, 73) action ToggleVariable("chaptertwo_34", True, False)
        hotspot (1012, 475, 69, 73) action ToggleVariable("chaptertwo_35", True, False)
        hotspot (1012, 551, 69, 73) action ToggleVariable("chaptertwo_36", True, False)
        hotspot (1012, 626, 69, 73) action ToggleVariable("chaptertwo_37", True, False)
        hotspot (1012, 705, 69, 73) action ToggleVariable("chaptertwo_38", True, False)
        hotspot (1012, 780, 69, 73) action ToggleVariable("chaptertwo_39", True, False)

        # column four
        hotspot (1088, 90, 69, 73) action ToggleVariable("chaptertwo_40", True, False)
        hotspot (1088, 165, 69, 73) action ToggleVariable("chaptertwo_41", True, False)
        hotspot (1088, 241, 69, 73) action ToggleVariable("chaptertwo_42", True, False)
        hotspot (1088, 321, 69, 73) action ToggleVariable("chaptertwo_43", True, False)
        hotspot (1088, 397, 69, 73) action ToggleVariable("chaptertwo_44", True, False)
        hotspot (1088, 475, 69, 73) action ToggleVariable("chaptertwo_45", True, False)
        hotspot (1088, 551, 69, 73) action ToggleVariable("chaptertwo_46", True, False)
        hotspot (1088, 626, 69, 73) action ToggleVariable("chaptertwo_47", True, False)
        hotspot (1088, 705, 69, 73) action ToggleVariable("chaptertwo_48", True, False)
        hotspot (1088, 780, 69, 73) action ToggleVariable("chaptertwo_49", True, False)

        # column five
        hotspot (1169, 90, 69, 73) action ToggleVariable("chaptertwo_50", True, False)
        hotspot (1169, 165, 69, 73) action ToggleVariable("chaptertwo_51", True, False)
        hotspot (1169, 241, 69, 73) action ToggleVariable("chaptertwo_52", True, False)
        hotspot (1169, 321, 69, 73) action ToggleVariable("chaptertwo_53", True, False)
        hotspot (1169, 397, 69, 73) action ToggleVariable("chaptertwo_54", True, False)
        hotspot (1169, 475, 69, 73) action ToggleVariable("chaptertwo_55", True, False)
        hotspot (1169, 551, 69, 73) action ToggleVariable("chaptertwo_56", True, False)
        hotspot (1169, 626, 69, 73) action ToggleVariable("chaptertwo_57", True, False)
        hotspot (1169, 705, 69, 73) action ToggleVariable("chaptertwo_58", True, False)
        hotspot (1169, 780, 69, 73) action ToggleVariable("chaptertwo_59", True, False)

        # column six
        hotspot (1248, 90, 69, 73) action ToggleVariable("chaptertwo_60", True, False)
        hotspot (1248, 165, 69, 73) action ToggleVariable("chaptertwo_61", True, False)
        hotspot (1248, 241, 69, 73) action ToggleVariable("chaptertwo_62", True, False)
        hotspot (1248, 321, 69, 73) action ToggleVariable("chaptertwo_63", True, False)
        hotspot (1248, 397, 69, 73) action ToggleVariable("chaptertwo_64", True, False)
        hotspot (1248, 475, 69, 73) action ToggleVariable("chaptertwo_65", True, False)
        hotspot (1248, 551, 69, 73) action ToggleVariable("chaptertwo_66", True, False)
        hotspot (1248, 626, 69, 73) action ToggleVariable("chaptertwo_67", True, False)
        hotspot (1248, 705, 69, 73) action ToggleVariable("chaptertwo_68", True, False)
        hotspot (1248, 780, 69, 73) action ToggleVariable("chaptertwo_69", True, False)

        # column seven
        hotspot (1324, 90, 69, 73) action ToggleVariable("chaptertwo_70", True, False)
        hotspot (1324, 165, 69, 73) action ToggleVariable("chaptertwo_71", True, False)
        hotspot (1324, 241, 69, 73) action ToggleVariable("chaptertwo_72", True, False)
        hotspot (1324, 321, 69, 73) action ToggleVariable("chaptertwo_73", True, False)
        hotspot (1324, 397, 69, 73) action ToggleVariable("chaptertwo_74", True, False)
        hotspot (1324, 475, 69, 73) action ToggleVariable("chaptertwo_75", True, False)
        hotspot (1324, 551, 69, 73) action ToggleVariable("chaptertwo_76", True, False)
        hotspot (1324, 626, 69, 73) action ToggleVariable("chaptertwo_77", True, False)
        hotspot (1324, 705, 69, 73) action ToggleVariable("chaptertwo_78", True, False)
        hotspot (1324, 780, 69, 73) action ToggleVariable("chaptertwo_79", True, False)

        # column eight
        hotspot (1404, 90, 69, 73) action ToggleVariable("chaptertwo_80", True, False)
        hotspot (1404, 165, 69, 73) action ToggleVariable("chaptertwo_81", True, False)
        hotspot (1404, 241, 69, 73) action ToggleVariable("chaptertwo_82", True, False)
        hotspot (1404, 321, 69, 73) action ToggleVariable("chaptertwo_83", True, False)
        hotspot (1404, 397, 69, 73) action ToggleVariable("chaptertwo_84", True, False)
        hotspot (1404, 475, 69, 73) action ToggleVariable("chaptertwo_85", True, False)
        hotspot (1404, 551, 69, 73) action ToggleVariable("chaptertwo_86", True, False)
        hotspot (1404, 626, 69, 73) action ToggleVariable("chaptertwo_87", True, False)
        hotspot (1404, 705, 69, 73) action ToggleVariable("chaptertwo_88", True, False)
        hotspot (1404, 780, 69, 73) action ToggleVariable("chaptertwo_89", True, False)

        # column nine
        hotspot (1482, 90, 69, 73) action ToggleVariable("chaptertwo_90", True, False)
        hotspot (1482, 165, 69, 73) action ToggleVariable("chaptertwo_91", True, False)
        hotspot (1482, 241, 69, 73) action ToggleVariable("chaptertwo_92", True, False)
        hotspot (1482, 321, 69, 73) action ToggleVariable("chaptertwo_93", True, False)
        hotspot (1482, 397, 69, 73) action ToggleVariable("chaptertwo_94", True, False)
        hotspot (1482, 475, 69, 73) action ToggleVariable("chaptertwo_95", True, False)
        hotspot (1482, 551, 69, 73) action ToggleVariable("chaptertwo_96", True, False)
        hotspot (1482, 626, 69, 73) action ToggleVariable("chaptertwo_97", True, False)
        hotspot (1482, 705, 69, 73) action ToggleVariable("chaptertwo_98", True, False)
        hotspot (1482, 780, 69, 73) action ToggleVariable("chaptertwo_99", True, False)

        # column ten
        hotspot (1560, 90, 69, 73) action ToggleVariable("chaptertwo_100", True, False)
        hotspot (1560, 165, 69, 73) action ToggleVariable("chaptertwo_101", True, False)
        hotspot (1560, 241, 69, 73) action ToggleVariable("chaptertwo_102", True, False)
        hotspot (1560, 321, 69, 73) action ToggleVariable("chaptertwo_103", True, False)
        hotspot (1560, 397, 69, 73) action ToggleVariable("chaptertwo_104", True, False)
        hotspot (1560, 475, 69, 73) action ToggleVariable("chaptertwo_105", True, False)
        hotspot (1560, 551, 69, 73) action ToggleVariable("chaptertwo_106", True, False)
        hotspot (1560, 626, 69, 73) action ToggleVariable("chaptertwo_107", True, False)
        hotspot (1560, 705, 69, 73) action ToggleVariable("chaptertwo_108", True, False)
        hotspot (1560, 780, 69, 73) action ToggleVariable("chaptertwo_109", True, False)





    textbutton "Close" action [Hide("chapter2_wordsearch", dissolve), Jump("chapter2wordsearch_close")]:
        xalign 0.93 yalign 0.95
        text_color "#ffffff"
        text_hover_color "#dcad2b"
    textbutton "Finished" action [Hide("chapter2_wordsearch", dissolve), Jump("chapter2wordsearch_checker")]:
        xalign 0.80 yalign 0.95
        text_color "#ffffff"
        text_hover_color "#dcad2b"
    textbutton "Hint":
        xalign 0.86 yalign 0.95
        text_color "#fafafa"
        text_hover_color "#ecb92e"
        if pphint == 1:
            action [SetVariable("pphint", pphint + 1), Show("pphint1", dissolve)]
        elif pphint == 2:
            action Show("pphint2", dissolve)

screen pphint1:
    modal True

    add "images/Various/black overlay.png"
    add "gui/popup.png" xalign 0.5 yalign 0.5
    text "Hint" xalign 0.5 yalign 0.34 color "#fefefe" size 50
    textbutton "x" action [Hide("pphint1", dissolve)]:
        text_color "#ffffff"
        text_hover_color "#dcad2b"
        xalign 0.68
        yalign 0.28
    vbox:
        xanchor 0.0
        spacing 20.0
        xpos 700
        ypos 450
        text "寻找高亮显示的单词\n点击它们继续。"
        text "再次点击提示按钮可获得答案。"

screen pphint2:
    modal True

    add "images/Various/black overlay.png"
    add "gui/popup.png" xalign 0.5 yalign 0.5
    text "Hint" xalign 0.5 yalign 0.34 color "#fefefe" size 50
    textbutton "x" action [Hide("pphint2", dissolve)]:
        text_color "#ffffff"
        text_hover_color "#dcad2b"
        xalign 0.68
        yalign 0.28
    add "images/puzzles/chapter_2/wordsearchhint.png" zoom 0.52 align 0.5, 0.58

label chapter2wordsearch_close:
    $ gametype = "ADV"
    window show dissolve
    hide heavenescape
    no sca "让我再想一会儿，好吗？"
    "教授微笑着。"
    pp "我从来没说过我父亲的话很简单，对吗？"
    window hide dissolve
    jump chapter2escaperepeat

label chapter2wordsearch_checker:
    if chaptertwo_12 and chaptertwo_18 and chaptertwo_23 and chaptertwo_28 and chaptertwo_34 and chaptertwo_37 and chaptertwo_38 and chaptertwo_45 and chaptertwo_46 and chaptertwo_48 and chaptertwo_55 and chaptertwo_56 and chaptertwo_58 and chaptertwo_64 and chaptertwo_67 and chaptertwo_68 and chaptertwo_71 and chaptertwo_72 and chaptertwo_73 and chaptertwo_74 and chaptertwo_75 and chaptertwo_78 and chaptertwo_82 and chaptertwo_93 and chaptertwo_94 and chaptertwo_95 and chaptertwo_96 and chaptertwo_97 and chaptertwo_98:
        jump chapter2wordsearch_complete
    else:
        window show
        no ann "该死。"
        pp "我不是想给你施加压力，但我父亲是为一个七岁的孩子设计的。"
        no "..."
        window hide
        call screen chapter2_wordsearch with dissolve


label chapter2wordsearch_complete:
    $ gametype = "ADV"
    window show dissolve
    hide heavenescape
    pp "你怎么看？"
    no sho "我...怎么看？"
    "她双臂交叉在胸前，不愿多说。"
    c sadsmi "即使在悲伤中，也有希望的火花。"
    "教授对克劳微笑。至少看起来是这样。"
    pp "怎么说？"
    c "虽然失去的痛苦可能难以形容，但你父亲的话语却成为了一种永恒的遗产，一生的存在。"
    c "我想这多次给了你力量。"
    pp "面对失去是一个个人的旅程，但最终重要的是将注意力从悲伤转移到感恩你们在一起的时光，以及他留下的回忆。"
    no ann "..."
    pp "除此之外，你对我来说很有用，我必须承认。"
    pp "那么，我能为你做些什么呢？"
    no neu "嗯...这可能是一个长镜头，但你碰巧有胶带吗？"
    pp "胶带？"
    c sho "我知道这有点奇怪，但是—"
    pp "如果你问其他人，他们肯定会嘲笑你。事实上，我也可能会笑。"
    pp "只是因为我确实有你要找的东西。给你。"
    no sho "这...真让人意外。"
    pp "给你。不用还回来。"
    pp "我不确定这到底会让你离解决这个难题更近一步，但我相信押注在你身上是安全的。"
    pp "祝你好运。"
    no ann "...谢谢。还有，呃...对艾许手下留情。"
    pp "没门。"
    $ tape = True

    window hide dissolve
    jump chapter2escaperepeat

label person2_photopiecesingular_after:
    $ gametype = "ADV"
    window show dissolve
    hide heavenescape
    pp "感谢你把他的话还给我。"
    pp "我永远不会忘记。"
    nothought "除了，你会忘记的..."
    nothought "这不是真正的你。甚至不是你的梦境版本。"
    nothought "你是艾许的大脑创造出来的。"
    nothought "你对我说的一切都是由他想出来的。你父亲的话，你希望艾许再试一次..."
    "诺亚的眉头皱了起来，尽管他心里知道真相，但他的心还在动摇。"
    window hide dissolve
    jump chapter2escaperepeat

label person2_tape:
    $ gametype = "ADV"
    window show dissolve
    hide heavenescape
    pp "如果你只是浪费时间到处展示我的礼物，那就还给我。"
    no sca "对不起..."
    window hide dissolve
    jump chapter2escaperepeat

label person2_pen:
    $ gametype = "ADV"
    window show dissolve
    hide heavenescape
    no neu "你需要笔吗？"
    pp "我？不，我需要它干什么？"
    no sca "呃，我不知道..."
    pp "那你为什么要问？请用点常识。"
    window hide dissolve
    jump chapter2escaperepeat


######## Person 1 | Young Noah ##############
label person1_firstscene:
    hide heavenescape
    $ gametype = "NVL"
    $ charleft = "诺亚"
    $ charright = "克劳"
    $ cs_left = "noah n neu"
    $ cs_right = "crow n neu"
    nonvl "我想知道到底是什么在拖延一切..."
    $ cs_right = "crow n sho"
    cnvl "我不知道，但这么长的队伍一定是有什么大事发生了...我们为什么不去问问呢？"
    nv "从背后看，队伍前面的人看起来很年轻，大概不到十七岁，有着短暗色头发。他面向前方，正在与门口的那个男人争论。"
    nonvl "对不起，我—"
    $ cs_left = "noah n sho"
    nonvl "..."
    $ charright = "诺亚？"
    $ cs_right = "noahteen n neu"
    ynvl "..."
    $ charright = "克劳"
    $ cs_right = "crow n sho"
    cnvl "哦。"
    $ charright = "诺亚？"
    $ cs_right = "noahteen n sur"
    ynvl "...奥古斯特？"
    $ charright = "克劳"
    $ cs_right = "crow n sho"
    cnvl "我..."
    nv "克劳看了诺亚一会儿，然后把目光转回到那个年轻人身上。"
    $ charright = "克劳"
    $ cs_right = "crow n sho"
    cnvl "这还是头一次..."
    cnvl "你可以叫我奥古斯特，如果你愿意的话。"
    $ charright = "诺亚？"
    $ cs_right = "noahteen n sur"
    ynvl "什么...发生了什么事？你的眼镜呢？你的衣服...怎么回事？"
    $ charright = "克劳"
    $ cs_right = "crow n sho"
    cnvl "嗯..."
    $ cs_right = "crow n hap"
    nv"克劳用一根手指放在嘴唇上做了个\"嘘\"的手势，然后冲他眨了眨眼睛。"
    cnvl "这是个秘密。"
    nv "仅仅是这样一个简单的动作，年轻的诺亚的脸就红透了，他不安地拽着衣服的边缘。"
    nv "但当他的目光落在诺亚身上时，他皱起了眉头。"
    $ charright = "诺亚？"
    $ cs_right = "noahteen n ang"
    ynvl "你在看什么？"
    $ cs_left = "noah n sca"
    nonvl "啊？我什么都没说啊。"
    ynvl "我有说你说了什么吗？我说的是你在看什么。笨蛋。"
    nonvl "你这个小...."
    $ charright = "克劳"
    $ cs_right = "crow n sho"
    cnvl "哇，哇，哇，我们别吵架好吗？"
    cnvl "诺亚—"
    noahsnvl "什么？"
    $ charright = "诺亚？"
    $ cs_right = "noahteen n sur"
    ynvl "啊？你也叫诺亚？"
    $ cs_left = "noah n fro"
    nonvl "你好好用用你的眼睛—"
    nv "在他说完之前，克劳拽了拽诺亚的袖子，然后凑到他耳边小声说。"
    $ charright = "克劳"
    $ cs_right = "crow n neu"
    cnvl "我觉得告诉他你是谁也没什么意义。"
    cnvl "那只会让他困扰。"
    $ cs_left = "noah n ann"
    nonvl "他不是真的！我...我才是诺亚..."
    cnvl "你是真的，而他不是你，这是事实。"
    cnvl "但你们不管是谁，他都是你曾经的样子的反映。你不觉得应该对自己多点宽容吗？"
    nonvl "宽容..."
    cnvl "如果你愿意，我可以去跟他说说。"
    nonvl "...."
    $ cs_left = "noah n ann"
    nonvl "好吧。我...他可能会更愿意听你说。"
    nonvl "...我真的那么烦人吗...？"
    $ cs_right = "crow n hap"
    nv "克劳笑了，那是一声轻快的笑声。"
    cnvl "这个诺亚只是阿什尔想象中的你。别太放在心上。"
    nonvl "好的..."
    $ charleft = "诺亚？"
    $ cs_left = "noahteen n pou"
    ynvl "你们两个在小声说什么呢...？"
    ynvl "奥古斯特...？"
    cnvl "我们只是在说我想帮你一把。"
    $ cs_left = "noahteen n neublu"
    ynvl "为...为我...？"
    cnvl "你愿意吗？"
    ynvl "当...当然..."
    $ cs_right = "crow n neu"
    cnvl "我想帮你通过这些大门。你知道是什么阻止了你吗？"
    nv "年轻的诺亚皱起眉头，怒视着门口的那个男人。"
    $ cs_left = "noahteen n pou"
    ynvl "这个混蛋就是不让我通过，明明我带来了所有的证件！"
    gnvl"你漏签了，在页面的右下角。"
    ynvl "为什么那么重要？！"

    nv "那个守卫转过身去，不想再继续讨论下去。"
    $ charleft = "诺亚"
    $ cs_left = "noah n ann"
    nonvl "那你为什么不去签一下呢？"
    $ charleft = "诺亚？"
    $ cs_left = "noahteen n pou"
    ynvl "呃，很显然我没带笔。"
    $ charleft = "诺亚"
    $ cs_left = "noah n neu"
    nonvl "艺术家不都是随身带笔的吗？"
    $ charleft = "诺亚？"
    $ cs_left = "noahteen n sur"
    ynvl "你怎么知道我是艺术家的？"
    $ charleft = "诺亚"
    $ cs_left = "noah n ann"
    nonvl "只是个猜测。"
    $ charleft = "诺亚？"
    $ cs_left = "noahteen n pou"
    ynvl "好吧...不管了，我就是没带。"
    $ cs_right = "crow n hap"
    cnvl "那我们去帮你拿一支笔好吗？"
    $ cs_left = "noahteen n neublu"
    ynvl "好...好的。"
    nv "根据他说话的对象不同，他的脾气似乎完全不同。"
    nv "这一点没有逃过诺亚的眼睛。"
    cnvl "那我们很快就回来。你在这里等着，好吗？"
    $ cs_left = "noahteen n sur"
    ynvl "等等...！"
    cnvl "嗯...？"
    $ cs_left = "noahteen n poublu"
    ynvl "别...别走..."
    ynvl "我有件事想告诉你。"
    $ cs_right = "crow n sho"
    cnvl "..."
    nv "克劳眨了眨眼睛，不确定该如何回应。"
    cnvl "噢，诺亚..."
    $ cs_right = "crow n hap"
    cnvl "...你可以等会儿再告诉我，不是吗？总有下次的机会。"
    cnvl "所以请耐心点，好吗？"
    ynvl "好...好的..."
    cnvl "乖孩子。我们很快就回来。"
    nv "他们走开时，诺亚仍然看起来有什么想对克劳说。"
    $ charleft = "诺亚"
    $ cs_left = "noah n ann"
    nonvl "..."
    nonvl "...想告诉我的事，嗯..."


    nvl clear

    $ nvl_hide(Dissolve(0.6))
    jump chapter2escaperepeat

label person1_hub:
    hide heavenescape
    $ gametype = "NVL"
    $ charleft = "诺亚"
    $ charright = "克劳"
    $ cs_left = "noah n neu"
    $ cs_right = "crow n neu"

    nv"年轻的诺亚仍站在队伍前面，怒视着门后的那个男人，直到他的目光落在克劳身上。"
    ynvl "奥古斯特..."

    menu youngnoah_hub:

        "关于奥古斯特..." if not youngnoah_august:
            $ youngnoah_august = True
            $ cs_left = "noah n ann"
            nonvl "...你知道，你可能没机会告诉奥古斯特那件你想说的事了。"
            $ charright = "诺亚(？)"
            $ cs_right = "noahteen n ang"
            ynvl "...什么？"
            nonvl "我...我不是想刻薄..."
            nonvl "我只是想说...在你...再也没机会之前，你应该做所有你认为有永远的时间去做的事。"
            ynvl "比如？"
            nonvl "..."
            nonvl "...比如画他。告诉他你珍惜他。告诉你的父母去你妈的，尽可能多地去见他..."
            $ cs_right = "noahteen n sur"
            ynvl "怎么..."
            $ cs_left = "noah n sho"
            nonvl "我..."
            nonvl "咳...我...呃，我从...从奥古斯特那里听说了你。"
            $ cs_right = "noahteen n pou"
            ynvl "哦。"
            nonvl "我只是想说...珍惜你拥有的，趁你还拥有的时候。"
            $ charright = "克劳"
            $ cs_right = "crow n sho"
            cnvl "..."
            nvl clear
            jump youngnoah_hub




        "够了":
            nvl clear

            $ nvl_hide(Dissolve(0.6))
            jump chapter2escaperepeat

label person1_photopieces:
    $ gametype = "ADV"
    window show dissolve
    hide heavenescape
    yn sur "这是你拍的吗？"
    c sho "我？我为什么会有..."
    c "啊..."
    c hap "这实际上是别人的照片。我们正试图帮一个善良的人把它拼凑起来。"
    c "你有没有看到其他碎片在附近？"
    yn neu "呃...没有，对不起。"
    yn hap"但我会留意的！"
    "他们几乎能看到年轻的诺亚的尾巴在摇摆。"
    window hide dissolve
    jump chapter2escaperepeat

label person1_tape:
    $ gametype = "ADV"
    window show dissolve
    hide heavenescape
    no ann "你会以为在后世里会有更少的文具，对吧..."
    c neu "人类的思维真是有趣得不可思议。人大脑能想出的东西...简直是无穷无尽。"
    no "但艾许还是选择了胶带和钢笔。"

    window hide dissolve
    jump chapter2escaperepeat

label person1_pen:
    $ gametype = "ADV"
    window show dissolve
    hide heavenescape
    $ default_mouse = "default"
    $ iteminhand = "None"
    c hap "诺亚—给你，一支钢笔。"
    yn sur "你真的给我拿来了..."
    c "当然。我会为你做任何事。永远。"
    yn neublu "..."
    no shy "..."
    yn "...谢...谢谢你..."
    "当他用钢笔在纸上写下第一笔时，他停下来回头看向那对。"
    yn "...你们两个是从未来来的吗？"
    c sho "啊..."
    nothought "不如说你是过去的遗物。"
    yn "你...你就是我，对吗？"
    no ann "...看来是这样。"
    yn poublu "那...那就是说，奥古斯特和我..."
    "他满怀希望地来回看着诺亚和\'奥古斯特\'。"
    nothought "对自己好一点，嗯..."
    no "...是的。"
    yn "那...我就是...一名全职艺术家...？"
    no "嗯...算是吧。"
    yn hap "太棒了..."
    nothought "别太兴奋。"
    "他小心翼翼地完成了签字，把文件递给了门后的那个男人，后者检查了一遍，简单点了点头，打开了大门。"
    "洁白的金属没有发出任何吱呀声，静悄悄地打开了，年轻的诺亚转过身，对克劳笑了笑，然后走了进去。"
    yn "我会成为值得你的人的，我保证！"
    c hap "我的小诺亚，你一直都是这个世界上最值得的人。祝你好运。"
    "他走进大门，消失在闪烁的光芒中。其他人也跟着他一起渐渐消失在大门里。"
    "皮尔森教授难得露出了微笑，鲁本继续看书，以利亚紧紧抱着他的照片，黛西举起手做了个\'记得打电话给我\'的手势，最后艾许站在了大门前。"
    ash neu "...."
    ash sad "谢谢你，诺亚。"
    "艾许看了看诺亚递给他的护身符，只是摇了摇头。"
    "就这样，一切都开始崩塌了。"
    $ persistent.chapter2_escapecomplete = True

    $ renpy.transition(dissolve)
    $ ui.layer("farback") # NEED THIS AFTER AN ESCAPE ROOM TO CLEAR THE SCREEN
    $ ui.clear()
    $ ui.close()

    stop music fadeout 5.0
    jump chapter2_escape_complete

label person1_photopiecesingular:
    $ gametype = "ADV"
    window show dissolve
    hide heavenescape
    nothought "{i}在梦境的领域，思维翱翔，漂浮在奇妙的世界，纯粹欢愉的梦境{/i}，嗯？"
    "但当他看向克劳时，看到他真诚地为诺亚尽力，他想，也许，这个梦境确实是奇妙的。"
    window hide dissolve
    jump chapter2escaperepeat

label person1_asherpaper:
    $ gametype = "ADV"
    window show dissolve
    hide heavenescape
    c hap "你小时候真可爱。"
    no shy "可、可爱...？！"
    c "你的眼睛充满希望，你的笑容很有感染力。"
    no "我...我不是..."
    c "不过，你现在也很可爱。所以不要担心。"
    no "....."
    window hide dissolve
    jump chapter2escaperepeat


label chapter2_escape_VN_version:
    scene bg heavenescape:
        zoom 0.7 yalign 0.5 xalign 0.7

    show person1:
        zoom 1.1 yalign 0.5 xalign 0.6
    show person2:
        zoom 1.1 yalign 0.5 xalign 0.6
    show person3:
        zoom 1.1 yalign 0.5 xalign 0.6
    show person4:
        zoom 1.1 yalign 0.5 xalign 0.6
    show person5:
        zoom 1.1 yalign 0.5 xalign 0.6
    show person6:
        zoom 1.1 yalign 0.5 xalign 0.6

    with dissolve
    "诺亚和克劳看着排在大门外的长长的人群。虽然队伍向后延伸了不少，但他们只能集中注意力在前面的几个人身上。"
    "诺亚重新走近艾许。"

    $ gametype = "NVL"
    $ charleft = "诺亚"
    $ charright = "艾许"

    $cs_left = "noah n ann"
    $cs_right = "asher n neu"


    $ nvl_show(Dissolve(1))
    nv "站在队伍前面第六个的是艾许，双臂交叉，脚在地上不耐烦地敲打着。"
    nv "当他看到诺亚和克劳再次走近他时，他只是翻了个白眼，转过头去。"
    nonvl "..."
    $ charright = "克劳"
    $ cs_right = "crow n neu"
    cnvl "对不起，我们能问你几个问题吗？"
    $ charright = "艾许"
    $ cs_right = "asher n mock"
    anvl "滚开。"
    $cs_left = "noah n fro"
    nonvl "别那样对他说话，混蛋。"
    anvl "为什么不行？"
    anvl "我想怎么做就怎么做。"
    anvl "如果你有什么问题，随便{i}滚开{/i}吧。"
    $ charright = "克劳"
    $ cs_right = "crow n sur"
    cnvl "拜托，我们只是想帮助你。如果你能..."
    $ charright = "艾许"
    $ cs_right = "asher n mock"
    anvl "我才不要从{i}他{/i}那里接受{i}任何东西{/i}。"
    $ cs_right = "asher n fro"
    anvl "你毁了我的生活。"
    $cs_left = "noah n sur"
    nonvl "对不起？"
    $cs_left = "noah n ang"
    nonvl "我毁了你的生活？"
    nonvl "你让我每一天都过得生不如死，却没有任何理由！"
    anvl "对，对，对，完全没有任何理由。"
    anvl "更多的特权废话。"
    nonvl "我完全不知道你在说什么...！"
    $ charright = "克劳"
    $ cs_right = "crow n sur"
    cnvl "让我们都冷静下来，好吗？"
    cnvl "艾许。你想通过那些大门，不是吗？"
    $ charright = "艾许"
    $ cs_right = "asher n fro"
    anvl "再次冷静地说，这不是{i}他妈的很明显的事情{/i}吗？"
    $ charright = "克劳"
    $ cs_right = "crow n sad"
    cnvl "我们会让这条队伍继续前进，但你必须配合我们——至少一点点，好吗？"
    $ charright = "艾许"
    $ cs_right = "asher n fro"
    anvl "..."
    $ cs_right = "asher n neu"
    anvl "如果你们不先帮助我，我是不会帮忙的。"
    nonvl "我们帮你通过那些愚蠢的大门就是在{i}帮助你{/i}。"
    nv "他耸了耸肩，又交叉起双臂，拒绝动弹。"
    $cs_left = "noah n ann"
    nonvl "好吧，随便。你到底想要什么？"
    nonvl "除了我们正在为你做的其他事情之外。"
    nv "他点了点头，示意了队伍前面几个位置，那里站着一个头发凌乱的男人。从背后看，诺亚认不出他是谁。"
    anvl "让他来跟我说话。"

    $ charright = "克劳"
    $ cs_right = "crow n sur"
    cnvl "他是谁？"
    $ charright = "艾许"
    $ cs_right = "asher n sad"
    anvl "..."
    anvl "鲁本。"
    nonvl "鲁本...？"
    nonvl "等等，是你上学时的那个鲁本？你最好的朋友？"

    nonvl "看来你们已经不再是朋友了，看来你的性格就是这样。"
    $ charright = "克劳"
    $ cs_right = "crow n sur"
    cnvl "...你有什么特别想让我们对他说的吗？"
    $ charright = "艾许"
    $ cs_right = "asher n sad"
    anvl "...{i}在温暖的夏夜下，在星空之下{/i}。"
    $ charright = "克劳"
    $ cs_right = "crow n neu"
    cnvl "真是神秘兮兮的。"
    $ charright = "艾许"
    $ cs_right = "asher n sad"
    anvl "他会明白的。"
    nonvl "..."
    $cs_left = "noah n neu"
    nonvl "你自己去跟他说吧。"
    anvl "那我就要失去我的位置了。"
    nonvl "我可以帮你保住。"
    anvl "...."
    $ charright = "克劳"
    $ cs_right = "crow n hap"
    cnvl "嗯..."
    cnvl "没关系，我们可以试试。"
    cnvl "只要你答应之后会帮助我们。"
    $ charright = "艾许"
    $ cs_right = "asher n sad"
    anvl "...好吧，随便你。"
    $ charright = "克劳"
    $ cs_right = "crow n neu"
    nv "说完这些，克劳和诺亚走到了一边，远离了艾许的耳朵。"
    $cs_left = "noah n ann"
    nonvl "他不配得到我们的帮助。"
    cnvl "我知道。"
    cnvl "但我们还是会帮他，对吗？"
    nonvl "也没什么选择..."
    cnvl "有很多选择。"
    $ cs_right = "crow n hap"
    cnvl "你选择去帮助。也许在你内心深处，你还希望能在这里找到你哥哥的人性。"
    nonvl "..."
    nonvl "那你呢？"
    $ cs_right = "crow n sur"
    cnvl "你什么意思？"
    nonvl "你为什么在这里？你为什么要帮忙？"
    nonvl "你从中得到了什么？"
    $ cs_right = "crow n hap"
    nv "那个金发男子用手指轻轻地抚摸着嘴唇，露出了一个温和的微笑，显然没有打算给出任何真正的解释。"
    cnvl "..."
    cnvl "我只是想减轻你的负担，哪怕只是一点点。"
    cnvl "这就是我所要求的全部。"
    nonvl "..."


    $ gametype = "ADV"
    nvl clear

    "两人走过几个人，直到诺亚看到一个熟悉的人。"
    "诺亚暂时忽略了其他人-他会在适当的时候去找他们，但现在，他有一个消息要传达。"



    $ gametype = "NVL"
    $ charleft = "诺亚"
    $ charright = "克劳"

    $cs_left = "noah n neu"
    $cs_right = "crow n neu"


    $ nvl_show(Dissolve(1))
    nv "在队伍前面只有几个人的地方，站着一个留着长长的乱蓬蓬黑发的年轻人，他把头发扎成了一个凌乱的马尾。"
    nv "他踮起脚尖，越过别人的肩膀看看是什么阻碍了前进，但他似乎并不太在意这个延误。"
    nv "当他意识到短时间内是不会前进了，他从看似空气中抽出一本书，开始安静地翻阅。"
    $cs_right = "crow n hap"
    cnvl "真是个勤奋的人，即使在这样的地方。"

    $ cs_left = "noah n sho"
    nonvl "是鲁本..."
    $ cs_left = "noah n ann"
    nonvl "至少是我哥哥思维中创造的鲁本版本。"
    $cs_right = "crow n hap"
    cnvl "这个概念很有趣，不是吗？"
    cnvl "在这里，他非常活着...他会动，会呼吸，会思考，但他在你的世界里也是活着的。"
    nonvl "这算是真正的生活吗？"
    cnvl "你告诉我，你觉得你真的活在梦境之外吗？"
    $ cs_left = "noah n sho"
    nonvl "..."
    $cs_right = "crow n neu"
    cnvl "不管是不是真正的他，你哥哥还是想和他和解...而且他可能有办法让这条队伍前进。"
    cnvl "那我们就去和他聊聊吧？"

    $cs_right = "crow n sho"
    cnvl "你了解他吗？我完全不认识他。"
    $ cs_left = "noah n ann"
    nonvl "...有点。"
    nonvl "他是，或者曾经是，我哥哥最好的朋友。不过他很少来我家。"
    nonvl "我觉得...我父母不太喜欢他。"
    $cs_right = "crow n sadsmi"
    cnvl "他们喜欢谁呢？"
    $ cs_left = "noah n sho"
    nonvl "..."
    cnvl "..."
    cnvl "抱歉，我越界了。"
    $ cs_left = "noah n ann"
    nonvl "不，你说得对。"
    nonvl "他们是...曾经是那种充满仇恨和偏见的人，没有人能让他们满意。不是别人，也不是我。"
    nonvl "总之..."
    nonvl "我们去和他聊聊吧。"
    nv "两人慢慢地穿过蓬松的云朵，来到鲁本的身边。即使诺亚清了清嗓子想引起他的注意，他也没有从书本上移开目光。"

    $ cs_left = "noah n neu"
    nonvl "...鲁本？"
    nv "终于，他的眼睛离开了书页。"


    $ charright = "鲁本"
    $ cs_right = "reuben n neu"

    rnvl "..."
    rnvl "...你是谁？"
    $ cs_left = "noah n ann"
    nonvl "诺亚。"
    rnvl "诺亚..."
    nv "他的脑海中似乎有了一丝灵光。"
    $ cs_right = "reuben n sur"
    rnvl "艾许的弟弟？"
    $ cs_left = "noah n sca"
    nonvl "嗯，去掉\'弟弟\'这个部分...对。"
    $ cs_right = "reuben n neu"
    rnvl "你长大了好多。我都认不出你了..."
    nonvl "岁月确实会让人变化。"
    nonvl "总之，你在这里做什么？"
    notnvl "真是个愚蠢的问题...他没有任何真正的理由在这里。他甚至根本就不在这里。"
    nv "鲁本的目光落在前方的金色大门上，他的眼神里充满了悲伤和愤怒，这是诺亚无法完全理解的。"

    $ cs_right = "reuben n fro"
    rnvl "我来看我的母亲。"
    $ cs_left = "noah n sho"
    nonvl "你的...母亲？"
    nv "他耸了耸肩，似乎不想多谈。"
    $ cs_right = "reuben n neu"
    rnvl "我想是吧。"
    nv "他的目光又回到手中仍然翻开的书上。"
    nv "他很乐意让克劳和诺亚就这样静静地站在他身边。"
    nonvl "我被要求给你传达一个消息。"
    nv "最后，鲁本从书中抬起头来。"
    $ charright = "鲁本"
    $cs_right = "reuben n neu"
    rnvl "里面有什么？"
    $ cs_left = "noah n ann"
    nonvl "这是...来自艾许的。"
    nv "尽管到目前为止这个男人一直相对无情，但这个名字似乎让他偏过头去。"
    $cs_right = "reuben n sur"
    rnvl "..."
    rnvl "他想要什么？"
    nonvl "他说..."

    nonvl "{i}在温暖的夏夜下，在星空之下。{/i}"
    $cs_right = "reuben n sur"
    rnvl "..."
    rnvl "他觉得这样做就能让一切都好起来吗？"
    rnvl "我想，既然是他，他肯定会这么想..."
    $cs_right = "reuben n neu"
    rnvl "好吧，告诉他我很快就会去找他谈谈。"
    $cs_left = "noah n sho"
    nonvl "...你们为什么吵架？"
    nv "鲁本直视着诺亚的眼睛。"
    rnvl "主要是你。"
    $cs_left = "noah n sur"
    nonvl "我...？"
    nonvl "为什么？"
    rnvl "重要吗？我在看书...我们可以后来再谈。"
    $cs_left = "noah n ann"
    nonvl "不，不，对你来说没有\'后来\'了。你只是..."
    $ charright = "克劳"
    $ cs_right = "crow n sad"
    cnvl "..."
    nonvl "...好吧。是的，我们可以后来再谈。"
    nonvl "快点把书看完。"
    $ charright = "鲁本"
    $ cs_right = "reuben n neu"
    rnvl "好的，但这是一个系列的第一本，我这里有全12本。"
    $cs_left = "noah n hur"
    nonvl "好的..."
    $ cs_left = "noah n neu"
    nonvl "你在看什么？"
    nv "他又低下头看书。"
    rnvl "一本书。"
    $ cs_left = "noah n hur"
    nonvl "..."
    $ charright = "克劳"
    $cs_right = "crow n hap"
    cnvl "讲的是什么？"
    cnvl "我从来没有读过书。"
    $ charright = "鲁本"
    $cs_right = "reuben n neu"
    rnvl "..."
    $cs_right = "reuben n smi"
    rnvl "这是关于一个孤儿离开家乡，挑战命运的故事。"
    $ charright = "克劳"
    $cs_right = "crow n hap"
    cnvl "听起来很有趣。你经常读书吗？"
    nv "鲁本点了点头，仍然专注于阅读。"
    $ cs_left = "noah n sca"
    nonvl "你在大学学习文学吗？"
    nonvl "我好像记得你...很久以前说过你想学文学。"
    $ charright = "鲁本"
    $cs_right = "reuben n neu"
    rnvl "不，我只是喜欢读书。我15岁的时候就辍学了。"
    $ charright = "克劳"
    $cs_right = "crow n sur"
    cnvl "有什么特别的原因吗？"
    $ charright = "鲁本"
    $cs_right = "reuben n sur"
    rnvl "...为了帮助我的弟弟吧，我们两个人一起长大。"
    rnvl "我能做的最少就是帮助他实现目标。"
    $ cs_left = "noah n ann"
    nonvl "哈。我的弟弟宁死也不会为了支持我而辍学。"
    $cs_right = "reuben n neu"
    rnvl "不过他还是辍学了。"
    $ cs_left = "noah n sho"
    nonvl "他...什么？"
    nv "他又耸了耸肩，眼睛仍然盯着眼前页面上的文字。"
    rnvl "如果你想知道的话，可以问问他。"


    $ gametype = "ADV"
    nvl clear
    "两人又走回到艾许身边。"
    "当他们再次接近艾许时，诺亚的脑海中掠过许多思绪。"


    $ gametype = "NVL"
    $ charright = "艾许"
    $cs_right = "asher n sur"


    $cs_left = "noah n neu"
    nonvl "我跟鲁本说话了。"
    anvl "他说了什么？！"
    nv "这一次，艾许看起来既慌张又伤心。这完全不是诺亚想象中的他的样子。"
    nonvl "...他说他稍后会来找你。"
    $cs_right = "asher n sad"
    anvl "...好，很好..."
    nonvl "那你做了什么？"
    $cs_right = "asher n fro"
    anvl "这不关你的事。"
    nonvl "如果你让我做你的跑腿小弟，那就是我的事了。"
    anvl "..."
    $cs_right = "asher n sad"
    anvl "...我对他那些最重要的事情很刻薄。"
    $cs_left = "noah n sho"
    nonvl "不...你，刻薄？这一点也不像你。"
    $cs_right = "asher n fro"
    anvl "滚开。"
    anvl "我什么都不会告诉你。"
    $ charright = "克劳"
    $cs_right = "crow n neu"
    cnvl "但是既然我们帮了你，你现在会帮我们了，对吗？"
    $ charright = "艾许"
    $cs_right = "asher n sad"
    anvl "好吧，随便你。"
    anvl "给，拿着这个。"
    $cs_left = "noah n neu"
    nonvl "...一半张纸？哇，谢谢。"
    $cs_right = "asher n mock"
    anvl "用你的眼睛看看吧。"
    anvl "我以为那些艺术界大腕擅长这种事。"
    $cs_left = "noah n fro"
    nonvl "艺术界大腕？"
    nonvl "别开玩笑了。要是你在我身边，我怎么可能在艺术界有所成就。"
    $cs_right = "asher n fro"
    anvl "要是我在你身边？"
    anvl "什么，所以我弟弟的死是我的错？"
    $cs_left = "noah n ang"
    nonvl "闭嘴...！"
    nonvl "不要...不要你敢...不要你敢提到他...！"
    anvl "那就别装作我才是你搞砸一切的罪魁祸首。"
    nonvl "....."
    $cs_left = "noah n fro"
    nonvl "我恨你。我恨你恨得要命。"
    anvl "这种感觉是互相的。"
    nonvl "我从来没对你做过什么...！"
    $cs_right = "asher n ang"
    anvl "你有我从未拥有的一切机会...！"
    anvl "你得到的一切都是锦上添花，但你从未珍惜过！"
    anvl "你可以学习任何你想学的，你能买到任何你需要的，你得到的一切都是现成的！"
    nonvl "你和我有什么区别...？"
    $cs_right = "asher n fro"
    anvl "....."
    anvl "自己想办法吧。我不想管了。"
    nonvl "你...！"
    $ charright = "克劳"
    $cs_right = "crow n sad"
    cnvl "诺亚。"
    $cs_left = "noah n ann"
    nonvl "..."
    nv "克劳把手放在诺亚的手上。这个动作立刻平息了这个男人的情绪。"
    nonvl "...好吧。"
    nonvl "等等，还有件事我想问他。"
    $cs_left = "noah n sho"
    nonvl "你是不是真的辍学了？"
    $ charright = "艾许"
    $cs_right = "asher n sur"
    anvl "..."
    anvl "什...什么？"
    anvl "我？辍学？我可不像你。"
    anvl "谁告诉你的？"
    nonvl "鲁本。"
    $cs_right = "asher n fro"
    anvl "...他只是编造谎言来报复我。"
    $cs_left = "noah n ann"
    nonvl "是吗..."
    anvl "我不是失败者...我不像你..."

    $ gametype = "ADV"
    nvl clear
    "诺亚低头看着艾许给他的那张纸。"
    "看起来只有一半，而且看起来像是胡言乱语。"

    show popout
    show note1examine:
        yalign 0.27
        xalign 0.52
    with dissolve

    "诺亚盯着它看了很长时间，但无法理解它的意思。"

    c sur "这是一个谜题！"

    no hur "我很糟糕的解谜。"

    c hap "对于一个擅长解谜的人来说，我觉得你已经做得很好了。"

    no ann "感觉并不是这样。"

    hide popout
    hide note1examine
    with dissolve
    "两人又走到鲁本身边时，诺亚注意到了什么。"
    "一张奇怪的纸被用作书签。"



    $ gametype = "NVL"
    $ charleft = "诺亚"
    $ charright = "鲁本"

    $cs_left = "noah n neu"
    $cs_right = "reuben n neu"


    $ cs_left = "noah n sho"
    nonvl "等等，那是什么？"
    $ charright = "鲁本"
    $ cs_right = "reuben n neu"
    rnvl "...?"
    rnvl "一本书..."
    nonvl "不，我是说...好吧，是的，它是..."
    nonvl "书签！"
    $ cs_right = "reuben n sur"
    rnvl "哦，这个啊？"
    rnvl "只是我随手找到的一片纸..."
    nonvl "你看到的和我看到的一样吗？"
    $ charright = "克劳"
    $ cs_right = "crow n sho"
    cnvl "是的...这肯定是艾许给你的那张纸的另一半。"
    nonvl "...我们能要回来吗？"
    $ charright = "鲁本"
    $ cs_right = "reuben n sur"
    rnvl "什么...但是..."
    rnvl "我会丢失页码的..."
    $ cs_left = "noah n ann"
    nonvl "呃...拜托了？"
    nonvl "就把角落折起来。"
    $ cs_right = "reuben n ann"
    nv "鲁本露出了一种几乎像是厌恶的表情，看着诺亚。"
    rnvl "折...折角落？然后损坏书本？"
    nonvl "拜托...我们真的需要它..."
    rnvl "..."
    rnvl "好吧...如果你答应帮我做点事。"
    $ cs_left = "noah n sho"
    nonvl "你居然会在我帮你之前给我东西？"
    nonvl "这还是头一次。"
    rnvl "...因为我相信你。"
    nonvl "你...相信我？"
    $ cs_right = "reuben n neu"
    rnvl "你一直都是个好孩子。"
    rnvl "而且你还得忍受艾许。"
    nv "诺亚不由自主地向后退了一步，感到很惊讶。"
    nonvl "谢...谢谢？"
    $ charright = "克劳"
    $ cs_right = "crow n hap"
    cnvl "那我们能帮你做什么呢？"
    $ charright = "鲁本"
    $ cs_right = "reuben n neu"
    rnvl "我找到了这个..."
    nv "鲁本举起一本无名的皮面书。侧面有一个锁。"
    nv "这个锁似乎是根据颜色来打开，而不是数字。"
    rnvl "它和我的书放在一起。我想把它打开。"
    $ charright = "克劳"
    $ cs_right = "crow n sho"
    cnvl "里面有什么？"
    $ charright = "鲁本"
    $ cs_right = "reuben n neu"
    rnvl "我想这是一本日记。"
    $ charright = "克劳"
    $ cs_right = "crow n sho"
    cnvl "什么是日记？"
    nonvl "...?"
    $ cs_left = "noah n neu"
    nonvl "呃...一本你可以写下你的感受、发生的事情之类的东西。"
    $ charright = "克劳"
    $ cs_right = "crow n hap"
    cnvl "哦！听起来不错。"
    $ charright = "鲁本"
    $ cs_right = "reuben n ann"
    rnvl "我想它...属于我母亲的..."
    rnvl "也许一切都会有意义...也许有一个好的理由..."

    $ gametype = "ADV"
    nvl clear
    "两人离开鲁本，然后拿出那两张纸。"

    show popout
    show note2examine:
        yalign 0.27
        xalign 0.52
    with dissolve

    no neu "嗯..."
    no "这是..."
    c hap "一个密码！"
    no hap "我们都有同样的想法。"
    "他们互相微笑，然后诺亚摇了摇头。"
    no neu "...上面写着..."
    no "Dreambound?"
    no "我完全不知道那是什么意思。"

    hide popout
    hide note2examine
    with dissolve
    "当两人转身离开鲁本时，诺亚与一名女士对上了眼神-她就站在艾许前面。"
    "诺亚不认识她，但决定还是必须走过去跟她打招呼。"


    $ gametype = "NVL"
    $ charleft = "诺亚"
    $ charright = "克劳"

    $cs_left = "noah n neu"
    $cs_right = "crow n neu"

    cnvl "小姐，打扰一下？"
    $ charright = "???"
    $ cs_right = "daisy n neu"

    unvl "..."
    unvl "...什么事？"
    nv "那个女子双臂抱在胸前，挑起一边眉毛。她似乎并不太想聊天。"
    nv "诺亚完全不认识她。不管她是谁，都不是艾许和诺亚的共同朋友。"
    unvl "不管什么事，快说吧。我们没有全天的时间。"

    $ charright = "克劳"
    $ cs_right = "crow n hap"
    cnvl "哦，因为你很快就能通过这条队伍了吗？"
    $ charright = "???"
    $ cs_right = "daisy n fro"
    unvl "不，因为那个笨蛋艾许很快就会醒过来，我就会消失了。"
    $ charright = "克劳"
    $ cs_right = "crow n sho"
    $cs_left = "noah n sho"
    cnvl "..."
    nonvl "..."
    nonvl "你，呃...意识到这一点了吗？"
    $ charright = "???"
    $ cs_right = "daisy n neu"
    unvl "嗯，这很明显。我其实并不真实，所以这一定是个梦。如果我不是真实的，而这又是个梦，那我也就不是真正的我了。"
    $ charright = "克劳"
    $ cs_right = "crow n sho"
    cnvl "这还是头一次。"
    nonvl "但是...你竟然能意识到自己不是真实的..."
    nv "那个女子耸了耸肩，似乎不太想多说。"
    $ charright = "???"
    $ cs_right = "daisy n neu"
    unvl "正如我说的，我们没有全天的时间。你想要什么？"
    nonvl "对，既然你知道这是个梦...我们正试图让这条队伍快点走。"
    unvl "嗯哼。"
    nonvl "有什么我们可以为你做的吗？来帮忙？"
    unvl "为我做...？"
    unvl "导演好像说过这件事..."
    $ charright = "克劳"
    $ cs_right = "crow n sho"
    cnvl "导演？"
    $ charright = "???"
    $ cs_right = "daisy n neu"
    unvl "你不需要担心他。"
    unvl "该死的，要是我能在停止存在之前记住这些就好了..."
    nv "她在云朵上敲了敲脚，陷入了沉思。"
    $ cs_right = "daisy n sur"
    unvl "也许你们可以为我做点什么。"
    $ charright = "克劳"
    $ cs_right = "crow n hap"
    cnvl "是什么？我们很乐意帮忙。"
    $ charright = "???"
    $ cs_right = "daisy n neu"
    unvl "你。"
    unvl "等你回到现实世界后，我想让你给我打电话，告诉我这里发生的一切。"
    $ charright = "克劳"
    $ cs_right = "crow n sho"
    cnvl "呃...？"
    cnvl "非常抱歉，小姐...？"
    $ charright = "黛西"
    $ cs_right = "daisy n neu"
    dnvl "黛西。"
    $ charright = "克劳"
    $ cs_right = "crow n sadsmi"
    cnvl "黛西小姐。这是..."
    nv "克劳做了一个想要帮忙的表情，但是..."
    nonvl "...我可以自己来。"
    $ cs_left = "noah n ann"
    nonvl "但是...你不会觉得我疯了吗...？"
    $ charright = "黛西"
    $ cs_right = "daisy n neu"
    dnvl "不会。我在这个领域工作，所以我会相信你。"
    nonvl "那你能给我你的电话号码吗？"
    $ cs_right = "daisy n sur"
    dnvl "当然—"
    $ cs_right = "daisy n hur"
    dnvl "当然..."
    dnvl "我...不知道。"
    $ cs_right = "daisy n fro"
    dnvl "该死的艾许...我不知道是因为他从来都记不住..."
    nv "她在口袋里摸索着，脸上带着惊讶的表情，掏出了一部手机。"
    $ cs_right = "daisy n sur"
    dnvl "算了，他是个天才。"
    $ cs_right = "daisy n hur"
    dnvl "但是解锁码是什么..."
    $ cs_left = "noah n sca"
    nonvl "嗯..."
    nonvl "对了，你和我哥哥是什么关系？"
    $ cs_right = "daisy n sho"
    dnvl "你哥哥...？"
    dnvl "你一定是诺亚。我都没意识到。"
    dnvl "艾许是...曾经是我的男朋友，我想。我们没有交往很久。"
    nonvl "...我哥哥有什么事情是顺利的吗？"
    dnvl "说实话，他是个可怜的小混蛋，因为害怕自己而对别人发脾气。"
    $ cs_right = "daisy n smi"
    dnvl "我想说对他温和点，但你想怎么样都行，我已经不在乎他了。"
    $ charright = "克劳"
    $ cs_right = "crow n sho"
    cnvl "哎呀..."
    nonvl "是吗..."
    nonvl "所以...我们需要解锁你的手机。有什么想法吗？"
    $ charright = "黛西"
    $ cs_right = "daisy n neu"
    dnvl "你可以试着问艾许要我的号码，但我不指望他会告诉你。"
    nv"克劳把诺亚拉到一边，因为这段对话自然而然地结束了。"

    $ charright = "克劳"
    $ cs_right = "crow n neu"
    $ cs_left = "noah n sho"
    nonvl "她怎么知道自己不是真的？"
    $ cs_right = "crow n sho"
    cnvl "这很奇怪，不是吗？我从未见过这样的人。"
    nonvl "而且她说她也在这个领域工作。不管那是什么意思。"
    cnvl "..."
    $ cs_right = "crow n sad"
    cnvl "小心点她，好吗？"
    cnvl "如果你决定之后给她打电话的话。"
    nonvl "为什么？"
    cnvl "她很聪明...我担心她的知识会带来什么后果。"
    cnvl "我不是说不要联系她...只是要谨慎，好吗？"
    nv "不知为什么，从那张脸和那个声音传来，诺亚不由自主地把这个警告记在心里。"
    $ cs_left = "noah n neu"
    nonvl "我会小心的。我保证。"
    nonvl "总之，我在想..."
    nonvl "我知道梦通常看起来很随机，但实际上并非如此。"
    cnvl "混乱中总有秩序。"
    nonvl "你觉得那个密码的答案可能是她的手机密码吗？"

    $ cs_right = "crow n sho"
    cnvl "梦境绑定？可能是。我们试试看吧？"

    nv "诺亚轻轻拍了拍黛西的肩膀。"

    nonvl "我想我知道密码是什么。"
    nonvl "你能给我看看你的手机吗？"
    dnvl "随你便。"


    $ charleft = "诺亚"
    $ charright = "克劳"
    $cs_left = "noah n hap"
    $cs_right = "crow n sho"
    nv "诺亚输入了密码\'DREAMBOUND\'，预计它不会起作用..."
    nv "但是，只发出一声蜂鸣，他就进去了。"
    nonvl "搞定了！"
    $cs_right = "crow n hap"
    cnvl "干得好，诺亚。我就知道你能做到。"
    $cs_left = "noah n shy"
    nv "诺亚的脸颊泛起了淡淡的粉红色，他避开了克劳的目光。"
    nonvl "这...这没什么大不了的..."
    cnvl "当然很了不起。你做得很好，庆祝一下也没什么不好的。开心一点吧。"
    nonvl "是...是啊..."
    $ charright = "黛西"
    $ cs_right = "daisy n neu"
    dnvl "你们两个调情完了吗？"
    $ charright = "克劳"
    $ cs_right = "crow n sur"
    cnvl "调情？我只是—"
    $ charright = "黛西"
    $ cs_right = "daisy n neu"
    dnvl "在调情。"
    $ cs_right = "daisy n smi"
    dnvl "终于，我的号码！记住这个吧。"
    nv "黛西把手机屏幕转向诺亚，上面显示着一串长长的数字。"
    $cs_left = "noah n sca"
    nonvl "呃，我的记忆力可不太好..."
    dnvl "现在正是改善自己的好时机。"
    dnvl "哦，这是什么..."
    $ charright = "克劳"
    $ cs_right = "crow n sho"
    cnvl "里面有什么？"
    nv "黛西皱着眉头看着手机，一脸困惑。"
    $ charright = "黛西"
    $ cs_right = "daisy n neu"
    dnvl "手机上只有一个应用程序。看。"
    nv "黛西点击了主屏幕上的应用程序，它就启动了。"
    nv "它闪烁着红色、红色、绿色、黄色，然后重复。"
    $ charright = "克劳"
    $ cs_right = "crow n sho"
    cnvl "哦，它只是闪烁着颜色。它是该这样做的吗？"
    $ charright = "黛西"
    $ cs_right = "daisy n neu"
    dnvl "我也不知道。"
    dnvl "也许它会派上用场。"
    $cs_left = "noah n ann"
    nonvl "也许吧。在梦境中，没有什么是毫无用处的。"
    dnvl "总之，我会等着你的消息。"
    dnvl "好吧，我不会真的给你发消息，因为我不是真正的我，所以我也不会记得这件事，但是..."
    dnvl "你明白我的意思。"
    nv "克劳担忧地看了诺亚一眼，然后摇了摇头。"
    nonvl "我会尽快联系你。"
    $ cs_right = "daisy n smi"
    nv "一个笑容在黛西的脸上绽放，照亮了她的容颜。不知为什么，它让诺亚想起了奥古斯特。"
    dnvl "谢谢你，诺亚和...？"
    $ charright = "克劳"
    $cs_right = "crow n hap"
    cnvl "你可以叫我克劳。"
    $ charright = "黛西"
    $ cs_right = "daisy n sho"
    dnvl "克劳啊..."
    dnvl "不知为什么，你让我想起了别人。"
    $ charright = "克劳"
    $cs_right = "crow n sho"
    cnvl "..."
    $cs_right = "crow n sadsmi"
    cnvl "我经常听到这种话。大概是一张很普通的脸吧。"
    $cs_left = "noah n sad"
    nonvl "..."
    $ charright = "黛西"
    $ cs_right = "daisy n smi"
    dnvl "总之，感谢你的帮助。祝你顺利离开这里，一切顺利。"
    $cs_left = "noah n sho"
    nonvl "谢谢，呃...你也是？"
    $ charright = "克劳"
    $cs_right = "crow n sadsmi"
    nv"克劳首先转身离开，诺亚也很快跟了上去。"
    nv"他的目光迷失了，双眼空洞，伸手抓住了心脏的位置。"
    cnvl "奇怪。"
    nonvl "里面有什么？"
    nonvl "你还好吗？"
    cnvl "我..."
    cnvl "我会没事的。"
    cnvl "一种奇怪的重量压在我的胸口，我无法解释..."
    cnvl "确实很奇怪..."
    nv "在那一刻，他似乎是一个完全不同的人...但下一刻，他又对诺亚微笑，好像什么都没发生。"
    $cs_right = "crow n hap"
    cnvl "那么我们继续吧？那些颜色一定就是鲁本在找的。"

    $ gametype = "ADV"
    nvl clear

    "鲁本仍然被困在队伍中，但他似乎对这件事并不太在意。"
    "他完全被手中的书所吸引。"

    $ gametype = "NVL"
    $ charleft = "诺亚"
    $ charright = "鲁本"

    $cs_left = "noah n neu"
    $cs_right = "reuben n neu"


    nonvl "你能给我看看你找到的那本日记吗？"
    $cs_right = "reuben n sur"
    nonvl "我想我知道密码是什么。"
    nv "鲁本小心翼翼地合上了他的书，看起来有些感兴趣。"
    nv "...检查了一下页码以记住它，没有用书签。"
    rnvl "给你。"
    nv "诺亚迅速重复了他在黛西手机上看到的密码。"
    nv "随着一声咔嗒，锁打开了。鲁本惊讶地看着它，好像他并没有真的指望它会打开。"
    $ charright = "克劳"
    $cs_right = "crow n neu"
    cnvl "你为什么不打开它？"
    $ charright = "鲁本"
    $cs_right = "reuben n neu"
    rnvl "..."
    nv "似乎有些担心，他慢慢地打开了封面，把它背对着小组。"
    $cs_right = "reuben n sur"
    nv "他的眼睛瞪大了一会儿，然后惊讶的表情消失了。"
    $cs_right = "reuben n ann"
    rnvl "...里面是空的。当然是空的。"
    rnvl "我不知道我期待会发生什么。"
    $ charright = "克劳"
    $cs_right = "crow n sho"
    cnvl "页面中间有什么东西吗？"
    $ charright = "鲁本"
    $cs_right = "reuben n ann"
    rnvl "一些...撕碎的照片。"
    rnvl "给你。"
    nv "鲁本把它递给诺亚。"
    $ cs_left = "noah n sho"
    nonvl "你确定吗？不过，它可能是你母亲的东西..."
    rnvl "...."
    rnvl "不是。她不会给我留下任何东西。"
    rnvl "请拿着它。"
    nv "诺亚小心翼翼地接过碎片，鲁本又回到了他的书上。"
    $cs_right = "reuben n neu"
    rnvl "...谢谢你，诺亚。"
    $ cs_left = "noah n ann"
    nonvl "没什么大不了的。"
    $ cs_left = "noah n ann"
    nonvl "嘿，你还住在...家乡吗？"
    rnvl "我怀疑我永远也不会离开那个小镇。"
    nonvl "我明白..."
    notnvl "这没有任何意义...这甚至不是他..."
    nonvl "如果...如果我有一天回到那里..."
    rnvl "你可以来拜访我，如果你愿意的话。"
    nonvl "...谢谢，我会考虑的。"
    $cs_right = "reuben n smi"
    nv "当诺亚和克劳转身离开时，鲁本露出了一个罕见的微笑，手中还拿着那些照片碎片。"
    $ charright = "克劳"
    $cs_right = "crow n neu"
    cnvl "...鲁本是个善良的人。"
    nonvl "是啊...他是怎么忍受我哥哥的，我永远也不会知道。"
    cnvl "你会去看他吗？"
    nonvl "...."
    $ cs_left = "noah n neu"
    nonvl "也许...也许有一天我回去的时候..."
    nv "克劳笑了，他的脸像太阳一样明亮。"
    $cs_right = "crow n hap"
    cnvl "我很高兴听到这个。"

    $ gametype = "ADV"
    nvl clear
    no ann "我想...是时候去跟其他人说说话了..."
    no "为什么艾许要梦到这么多人..."
    c sho "比我想象的还要累人。"
    no sho "什么？"
    c "跟人说话！"
    c "毕竟，我只习惯跟你说话。"
    no ann "..."
    c neu "总之，来吧。我们还不能放弃。"

    $ gametype = "NVL"
    $ charleft = "诺亚"
    $ charright = "克劳"
    $ cs_left = "noah n neu"
    $ cs_right = "crow n neu"
    $ nvl_show(Dissolve(1))

    nv "一位年长的绅士站在队伍前面几个位置，双手随意地插在口袋里，吹着一首轻快悠扬的曲子。"
    nv "当克劳和诺亚走近时，他们才发现这个人的形态并不很强烈...他就像一个影子，没有明确的特征。"
    $ cs_left = "noah n sho"

    nonvl "为什么他会这样...？"
    $ cs_right = "crow n sho"
    cnvl "我想艾许对他并没有太多的依恋...要创造出完全栩栩如生的人物，需要梦境创造者相当强大的精神力量。"
    cnvl "所以有时候人物就会变成这样。"
    nonvl "..."
    $ cs_left = "noah n ann"
    nonvl "我想这和现实世界也没什么不同。"
    nonvl "在街上你会遇到多少人，却从未记住或再想起过？"
    $ cs_left = "noah n neu"
    nonvl "我们可以跟他说话吗？"
    cnvl "应该可以。"

    nonvl "呃，打扰一下..."
    nv "这个阴影般的男子转向诺亚，他的口哨声戛然而止。"
    unvl "嘿，不要插队。我们都得等自己的轮到。"
    cnvl "哦，不，我们不是来插队的。"
    $ cs_right = "crow n hap"
    cnvl "相反，我们是来帮你更快通过那个大门的。"
    unvl "哦..."
    unvl "你们两个真是太好了。在这个世界上，你们这样诚实正直的年轻人已经不多见了！"
    $ cs_left = "noah n hur"
    nonvl "好的..."
    cnvl "我是诺亚，这是克劳。我没有听到你的名字？"
    $ cs_left = "noah n ann"
    envl "我叫以利亚。"
    $ cs_right = "crow n neu"
    cnvl "以利亚，很高兴认识你。你在这里做什么？"
    nv "这个男人停下来思考了一会儿。他似乎也不太清楚自己为什么会在这里。"
    envl "嗯。我也不知道。"
    envl "我正在和我那个不愿意支付他该死的房租的房客通电话，然后我就在这里了..."
    nonvl "你的房客？"
    envl "一个叫艾许的年轻人。"
    $ cs_left = "noah n sho"
    nonvl "...."
    nonvl "艾许没有支付房租...？"
    nonvl "这不像他的作风..."
    envl "你认识他？"
    nonvl "他是...不幸的是我的弟弟。"
    envl "也许你可以提醒他，我不是什么慈善机构，他已经拖欠了过去六个月的房租。"
    notnvl "什么...我以为是我们的父母在支付他的账单？"
    cnvl "我们可以告诉他。"
    $ cs_left = "noah n ann"
    nonvl "并希望问问他为什么..."

    envl "嘿，你手里拿的是什么？"
    $ cs_left = "noah n sho"
    nonvl "这些...？"
    nv "诺亚把撕碎的照片碎片递给以利亚，后者惊讶地睁大了眼睛。"
    envl "这...我一直在找这些！我正试图把这张照片拼凑起来..."
    $ cs_right = "crow n sur"
    cnvl "真的吗？"
    $ cs_right = "crow n hap"
    cnvl "那么，也许我们可以帮你找到其余的碎片。"
    $ cs_left = "noah n neu"
    nonvl "作为交换，如果我们需要的话，你可以帮助我们。"
    envl "你们两个人真是一个团队，是不是？成交。"
    cnvl "那我们很快就回来！"

    $ gametype = "ADV"
    nvl clear

    no ann "我想我们应该看看艾许、鲁本或黛西有没有这些东西。"
    c neu "让我来吧。你看起来很累，诺亚。休息一会儿吧。"
    "诺亚坐在云边休息了一会儿，看着克劳忙碌。"
    "他不禁对这个金发男子感到惊叹。"
    "他确实很像奥古斯特。他说话时的笑容是一样的。"
    "几分钟后，克劳带着一大堆照片碎片回来了。"
    c hap "成功了！"
    no neu "谢谢你，克劳...我们去看看这些够不够吧？"
    c "好主意。"


    $ gametype = "NVL"
    $ charleft = "诺亚"
    $ charright = "克劳"

    $cs_left = "noah n neu"
    $cs_right = "crow n neu"

    nonvl "我想我已经准备好尝试拼凑你的照片了。"
    nv "以利亚看着诺亚和克劳，他的期望在脸上一目了然。"

    nv "诺亚小心翼翼地摆放好那些旧照片的碎片，像拼图一样推来推去。"
    nv "幸运的是，只有大约九件，所以这是一个非常简单的拼图，很快就完成了。"
    $cs_left = "noah n neu"
    $cs_right = "crow n hap"
    envl "天哪，你们两个真是做到了！"
    nv "虽然他的形态很难看清，但连诺亚也能看出以利亚脸上洋溢着宽阔而深邃的笑容。"
    envl "你们两个真的不知道这对我意味着什么..."
    $cs_left = "noah n sho"
    nonvl "等等，这是..."
    envl "这是一个小山城，我第一次遇到我妻子的地方。那是哪一年来着...嗯..."
    nv "以利亚把手举到下巴上，抚摸着另外两个人看不见的胡子。"
    envl "1975年？1976年？"
    envl "啊！1978年，我现在想起来了...天，时间真的过得太快了。"
    $cs_right = "crow n sho"
    $cs_left = "noah n sho"
    envl "你们两个应该珍惜彼此的时光，明白吗？"
    nonvl "..."
    $cs_right = "crow n sad"
    cnvl "..."
    $cs_left = "noah n sad"
    nonvl "是的...我确实很珍惜..."
    envl "总之，我应该记下日期..."


    nv "以利亚从口袋里掏出一支简单的圆珠笔。"
    envl "该死，我需要一些东西来把它固定住，否则它又会被吹走..."
    $ cs_right = "crow n sho"
    cnvl "嗯...也许有胶带？"
    envl "那就太好了，但如果我离开这个位置，我就永远也进不去了..."
    $ cs_left = "noah n sca"
    nonvl "...."
    nonvl "好吧，好吧，我们会给你找到胶带的。"

    nv "当克劳和诺亚转身离开时，一些皱巴巴的东西落到了云层下面。"
    nv "诺亚蹲下来把它捡了起来。"
    $ cs_left = "noah n ann"
    nonvl "看，你已经把它掉下去了...？"
    nv "诺亚低头看着那张皱巴巴的纸条。"
    $ cs_left = "noah n sho"
    nv "上面用潦草的笔触写着字。"
    nv "{i}不要干涉，否则你的\'朋友\'会像上次一样消失。{/i}"
    nonvl "..."
    nv "诺亚的心沉到了胃里，盯着眼前的字句。"
    nv "这张纸条本身就像一幅画布。就像最精美的绘画。"
    nv "只是几个字就把他带回到了过去，回到了一个他至今仍能感受到的巨大损失中，并将那种痛苦放大了十倍。"
    $ cs_right = "crow n sho"
    cnvl "你在下面还好吗，诺亚？"
    $ cs_right = "crow n hap"
    nv "诺亚抬头看向克劳灿烂的笑容。他似乎完全没有任何烦恼。"
    $ cs_left = "noah n ann"
    nv "出于某种原因，这正是诺亚想要保护的。"
    $ cs_left = "noah n neu"
    nonvl "没什么。只是一些垃圾。"
    nv "他把它塞进口袋里，站了起来，尽管内心痛苦，还是对克劳轻轻一笑。"
    envl "嗯，背面还有一些涂鸦..."
    envl "{i}在梦境的领域，心灵展翅高飞，漂浮在一个奇妙的世界里，一个纯粹愉悦的梦境。{/i}"
    envl "这是谁写的？"
    $ cs_right = "crow n sho"
    cnvl "..."
    cnvl "实际上，我们能再借一下吗？我觉得它可能会派上用场。"
    envl "好吧，你帮了我...好吧，给你。"
    nv "以利亚伸出一角照片，诺亚又拿了回来。果然，背面有一句奇怪的诗句。"
    nv "这些话让他感到一阵刺痛，仿佛直戳心脏。"
    nv "多年前的自己..."



    $ gametype = "ADV"
    nvl clear

    c neu "还剩下两个人。希望帮助他们两个能让这条线动起来。"
    no neu "是啊..."


    $ gametype = "NVL"
    $ charleft = "诺亚"
    $ charright = "克劳"

    $ cs_left = "noah n neu"
    $ cs_right = "crow n neu"

    nv"在队伍前面的第二个人，一个穿着套装、戴眼镜的女士发出了一声哼声，望着门外的那个人。"


    nv "就像以利亚一样，她的形态似乎在波动。她从几乎看不见到更加实体化，但她的面貌并不清晰。"

    nonvl "对不起，小姐—"
    $ cs_left = "noah n sho"
    unvl "小姐？你刚才叫我小姐？"
    pnvl "请叫我皮尔森教授，要有些尊重。"
    $ cs_right = "crow n sho"
    cnvl "呃..."
    $ cs_left = "noah n ann"
    nonvl "...."
    notnvl "天哪，这肯定会很有趣，不是吗？"
    $ cs_left = "noah n sca"
    nonvl "...好吧。我的错。"
    pnvl "你的错什么？"
    nonvl "呃..."
    nonvl "对不起，我想我们开始得不太好...皮尔森教授。"
    pnvl "至少你那有限的智力还记得我的名字。"
    notnvl "你两秒钟前才告诉我的...！"
    pnvl "有什么我可以帮到你们的吗？"
    $ cs_right = "crow n neu"
    cnvl "实际上，我们也想问你同样的问题。"
    pnvl "我？需要别人的帮助？"
    nonvl "但你和其他人一样，也被困在这里。"
    pnvl "这不是我的错。不像某些人。"
    nv "她狠狠地瞪着站在她前面的那个人。"
    cnvl "如果我们告诉你，有了你的帮助，我们就能让这条队伍动起来呢？"
    pnvl "我会说你把我当成了傻瓜。"
    $ cs_left = "noah n ann"
    nonvl "不，真的，这就是我们正在做的..."
    nv "突然间，教授向前倾身，把她那阴影般的眼镜推得更高了。"
    pnvl "我觉得我认识你。你是我的学生吗？"
    $ cs_left = "noah n sho"
    nonvl "呃...不，对不起，我想不是。"
    nv "一个灵光一闪在诺亚的脑海中。"
    nonvl "等等，除非你是说...艾许？他是我的弟弟。"
    pnvl "艾许...艾许...是的，我记得他。"
    pnvl "他头脑聪明，却缺乏专注。用更简单的话说，他做事都是敷衍了事。"
    nonvl "但是...他一直都是个超级学霸。"
    pnvl "超级学霸？不，他挂掉了我的课。"
    $ cs_left = "noah n sur"
    nonvl "他{i}什么{/i}？"
    notnvl "鲁本说艾许真的退学了，看来他说的是实话..."

    nv "她的声音似乎有一瞬间的动摇，变得更柔和了。"
    pnvl "...这真是太遗憾了，因为他的学习天赋确实...很出色。"
    nonvl "那么...为什么？"
    nv "她耸了耸肩。"
    pnvl "我只能对此做出假设。也许他是个天赋异禀的孩子，一直依靠这种优势，直到它逐渐消失了，又或者他太忙于其他事情而无暇顾及学习。"
    pnvl "无论如何，我都无法给他及格。"
    pnvl "...即使我想这么做。"
    $ cs_left = "noah n ann"
    nonvl "我明白..."
    pnvl "但那都是过去的事了。我曾试图劝他重新上这门课，但我相信他太羞愧而不愿这么做。"
    pnvl "骄傲确实是人类的一大弱点。"
    pnvl "不过这已经不重要了。除非你能解决我的娱乐问题，否则我想我也帮不了你什么。"
    $ cs_right = "crow n sho"
    cnvl "你的娱乐问题？"
    pnvl "这与你无关。快走吧。"
    nv "她双臂交叉在胸前，几乎是带着鄙夷的神情望着这对人。"
    nv "看到这个迹象，这对人决定离开教授。"
    cnvl "看来我们需要说服她告诉我们她需要什么帮助。"
    cnvl "有什么想法吗？"
    $ cs_left = "noah n sca"
    nonvl "嗯..."
    nonvl "她似乎有点喜欢我哥哥。有点吧。也许。"
    nonvl "说实话，我不确定她是否喜欢任何人，但值得一试。"
    nonvl "跟艾许谈谈他的学习...这肯定不会有什么好结果..."

    nv "诺亚和克劳找到了回到艾许的路。"

    $ charleft = "诺亚"
    $ charright = "艾许"

    $cs_left = "noah n ann"
    $cs_right = "asher n fro"
    anvl "天啊，你还在这里吗？"
    nonvl "很遗憾。"
    nonvl "相信我，我也不想再待在这里了。"
    anvl "那就快点回到你的...不管你在做什么。"
    anvl "涂鸦？"
    nonvl "..."
    nonvl "有什么不对吗？"
    anvl "..."
    $cs_right = "asher n sad"
    anvl "...没什么。"
    nv "艾许看向一边，深深地叹了口气。"
    $cs_left = "noah n neu"
    nonvl "...我和某个教授谈过。"
    anvl "这一天越来越糟糕了..."
    nonvl "她说你挂了她的课。这让我觉得你确实退学了。"
    $cs_right = "asher n fro"
    anvl "好吧，行！"
    anvl "随便吧！是的，我退学了。谁在乎？"
    anvl "你现在满意了吗？"
    $cs_left = "noah n sho"
    nonvl "为什么这会让我高兴？"
    anvl "你是在告诉我，你不高兴看到你讨厌的人失败吗？"
    $cs_left = "noah n ann"
    nonvl "..."
    notnvl "...不知为什么，我没有。"
    nonvl "...她希望你重修这门课。"
    anvl "就为了让她再次把我挂掉？绝对不行。"
    nonvl "不，她真的希望你重修。我想她相信你。"
    $cs_right = "asher n sad"
    anvl "..."
    anvl "...真是个好笑的笑话。"
    nonvl "...发生了什么？"
    anvl "哈。"
    anvl "我也不知道。"
    anvl "不像你，你可以随意进入任何一个课堂并取得优异成绩，我必须拼命工作才能获得好成绩。"
    nv "他的声音里带着嫉妒。"
    anvl "日夜学习...努力维持一种毫不费力的样子..."
    anvl "然后突然间我被切断了，我在做三份兼职工作，我没有时间...我做不到..."
    anvl "我无法跟上..."
    nonvl "...你本可以寻求帮助。我相信—"
    $cs_right = "asher n fro"
    anvl "不！不..."
    anvl "不...我想要证明...证明我可以独立完成..."
    anvl "然后我看到了你...在一切事物上都表现出色...有时间去做你的艺术，和你的朋友在一起，这..."
    nonvl "...让你生气了。"
    $cs_right = "asher n sad"
    anvl "让我想要看到你受苦。"
    $cs_left = "noah n sho"
    nonvl "哎呀。"
    anvl "这就伤害了鲁本...你知道，家人对他很重要？"
    anvl "所以我现在是无朋友，无女朋友，退学了，付不起房租。"
    anvl "现在还要处理两个该死的葬礼。"
    $cs_left = "noah n ann"
    nonvl "我..."
    nonvl "我不知道该说什么。"
    anvl "没有什么可说的。这就是我的生活。"
    anvl "我会...处理好的。"
    nonvl "...我应该去清理我的房间。"
    $cs_right = "asher n smi"
    anvl "这样就不用你来处理我的所有东西了。"
    $cs_left = "noah n hap"
    nv "艾许露出一个虚弱的微笑，诺亚也回以微笑。"
    nv "他们是否能重拾友谊，谁也说不准，但在那一刻，他们似乎重拾了多年前失去的对彼此的理解。"

    $ gametype = "ADV"
    nvl clear

    c neu "你怎么样，诺亚？"
    no neu "..."
    no "还好吧。累了，但是..."
    no "也许艾许内心也有善意。某种程度上。深深地埋藏着。"
    c sho "..."
    c hap "我很高兴你能看到人性中的善意，诺亚。"
    c neu "但要小心别受伤。"
    c "我们再去找教授谈谈吧，好吗？"

    $ gametype = "NVL"
    $ charleft = "诺亚"
    $ charright = "克劳"
    $cs_left = "noah n neu"
    $cs_right = "crow n neu"

    $cs_left = "noah n ann"
    nonvl "我跟艾许谈过了。"
    $cs_left = "noah n neu"
    nonvl "我告诉他应该重修您的课。"
    pnvl "哦。"
    pnvl "这真是出乎意料。"
    nonvl "他似乎担心您会再次不及格他。"
    pnvl "如果他不努力学习，那是的。"
    pnvl "但如果他努力了，我很乐意让他及格。"
    pnvl "上天保佑，我们需要更多重视知识的人。"
    pnvl "谢谢...？"
    nonvl "我叫诺亚，这是克劳。"
    pnvl "好的，我很感谢你们的行动。我期待着看到他再次尝试。"

    nonvl "那么—"
    pnvl "好吧，好吧，你们已经够执着的了。行吧。"
    pnvl "确实有件事你们可以帮我。"
    pnvl "我不会浪费你们的时间来冗长地解释。我父亲是一位多产的作家，在他去世前留给我一本他的个人作品集。"
    pnvl "那时我才七岁。他在文字中创造了谜题和难题，这样在他离世后我还能拥有他的一部分。"
    nv "教授叹了口气，显得很烦恼。"
    pnvl "但是今天，他的一些话被风吹走了。"
    pnvl "如果你们能帮我找到它们，那我确实会尽我所能帮助你们。"
    $cs_right = "crow n hap"
    cnvl "...这真是一件多么美好的事情，留给挚爱的人。毕竟，什么比来自心底的话语更珍贵呢？"
    nonvl "啊。我想我有合适的东西。"
    nv "诺亚拿出了伊莱亚给他的小纸条。"
    nonvl "这就是它吗？"
    nv "她接过纸条，仔细看了看上面的字。"
    nv "即使被阴影遮挡，诺亚也能看到她脸上微微的笑意。"
    nonvl "我，呃，确实要把它还回去。"
    pnvl "没关系。"
    pnvl "再次看到他的字就够了。给你，拿回去吧。"

    $ gametype = "ADV"
    nvl clear

    pp "那么，我能为你做些什么呢？"
    no neu "嗯...这可能是一个长镜头，但你碰巧有胶带吗？"
    pp "胶带？"
    c sho "我知道这有点奇怪，但是—"
    pp "如果你问其他人，他们肯定会嘲笑你。事实上，我也可能会笑。"
    pp "只是因为我确实有你要找的东西。给你。"
    no sho "这...真让人意外。"
    pp "给你。不用还回来。"
    pp "我不确定这到底会让你离解决这个难题更近一步，但我相信押注在你身上是安全的。"
    pp "祝你好运。"
    no ann "...谢谢。还有，呃...对艾许手下留情。"
    pp "没门。"


    $ gametype = "ADV"
    nvl clear
    "诺亚迅速把录音带带回给了伊莱亚。"
    no neu "给你，你的胶带。"
    c neu "你不应该再丢失你的照片了。"
    e "谢谢你们两个..."
    e "这是你应得的。"
    no sho "一支...钢笔。"

    c hap "我相信我们会找到有人能用到它的。"

    no neu "...谢谢你，以利亚。祝你在那里玩得开心。"
    "诺亚朝着大门点了点头。"
    e "哦，我会的。我会把这张照片给我妻子看，我们会一起回忆往事。啊，她已经在里面等我很久了。"
    no sho "..."
    no ann "听起来很好。"
    e "你在里面有人在等你吗？"
    no "我..."
    "诺亚的目光从大门转向克劳。"
    e "这种痛苦是永远无法完全愈合的。不要勉强自己谈论它。"
    "以利亚拍了拍诺亚的肩膀。"
    e "我希望你能找到你想要的。"
    c sad "..."
    no sad "..."
    c "...还剩一个人。"
    no "...是啊。赶快把它完成吧。"


    $ gametype = "NVL"
    $ charleft = "诺亚"
    $ charright = "克劳"
    $ cs_left = "noah n neu"
    $ cs_right = "crow n neu"

    nonvl "是时候看看到底是谁在拖延了。"
    $ cs_right = "crow n sho"
    cnvl "这么长的队伍一定是有什么大事。"
    nv "从背后看，队伍前面的人看起来很年轻，大概不到十七岁，有着短暗色头发。他面向前方，正在与门口的那个男人争论。"
    nonvl "对不起，我—"
    $ cs_left = "noah n sho"
    nonvl "..."
    $ charright = "诺亚？"
    $ cs_right = "noahteen n neu"
    ynvl "..."
    $ charright = "克劳"
    $ cs_right = "crow n sho"
    cnvl "哦。"
    $ charright = "诺亚？"
    $ cs_right = "noahteen n sur"
    ynvl "...奥古斯特？"
    $ charright = "克劳"
    $ cs_right = "crow n sho"
    cnvl "我..."
    nv "克劳看了诺亚一会儿，然后把目光转回到那个年轻人身上。"
    $ charright = "克劳"
    $ cs_right = "crow n sho"
    cnvl "这还是头一次..."
    cnvl "你可以叫我奥古斯特，如果你愿意的话。"
    $ charright = "诺亚？"
    $ cs_right = "noahteen n sur"
    ynvl "什么...发生了什么事？你的眼镜呢？你的衣服...怎么回事？"
    $ charright = "克劳"
    $ cs_right = "crow n sho"
    cnvl "嗯..."
    $ cs_right = "crow n hap"
    nv"克劳用一根手指放在嘴唇上做了个\"嘘\"的手势，然后冲他眨了眨眼睛。"
    cnvl "这是个秘密。"
    nv "仅仅是这样一个简单的动作，年轻的诺亚的脸就红透了，他不安地拽着衣服的边缘。"
    nv "但当他的目光落在诺亚身上时，他皱起了眉头。"
    $ charright = "诺亚？"
    $ cs_right = "noahteen n ang"
    ynvl "你在看什么？"
    $ cs_left = "noah n sca"
    nonvl "啊？我什么都没说啊。"
    ynvl "我有说你说了什么吗？我说的是你在看什么。笨蛋。"
    nonvl "你这个小...."
    $ charright = "克劳"
    $ cs_right = "crow n sho"
    cnvl "哇，哇，哇，我们别吵架好吗？"
    cnvl "诺亚—"
    noahsnvl "什么？"
    $ charright = "诺亚？"
    $ cs_right = "noahteen n sur"
    ynvl "啊？你也叫诺亚？"
    $ cs_left = "noah n fro"
    nonvl "你好好用用你的眼睛—"
    nv "在他说完之前，克劳拽了拽诺亚的袖子，然后凑到他耳边小声说。"
    $ charright = "克劳"
    $ cs_right = "crow n neu"
    cnvl "我觉得告诉他你是谁也没什么意义。"
    cnvl "那只会让他困扰。"
    $ cs_left = "noah n ann"
    nonvl "他不是真的！我...我才是诺亚..."
    cnvl "你是真的，而他不是你，这是事实。"
    cnvl "但你们不管是谁，他都是你曾经的样子的反映。你不觉得应该对自己多点宽容吗？"
    nonvl "宽容..."
    cnvl "如果你愿意，我可以去跟他说说。"
    nonvl "...."
    $ cs_left = "noah n ann"
    nonvl "好吧。我...他可能会更愿意听你说。"
    nonvl "...我真的那么烦人吗...？"
    $ cs_right = "crow n hap"
    nv "克劳笑了，那是一声轻快的笑声。"
    cnvl "这个诺亚只是阿什尔想象中的你。别太放在心上。"
    nonvl "好的..."
    $ charleft = "诺亚？"
    $ cs_left = "noahteen n pou"
    ynvl "你们两个在小声说什么呢...？"
    ynvl "奥古斯特...？"
    cnvl "我们只是在说我想帮你一把。"
    $ cs_left = "noahteen n neublu"
    ynvl "为...为我...？"
    cnvl "你愿意吗？"
    ynvl "当...当然..."
    $ cs_right = "crow n neu"
    cnvl "我想帮你通过这些大门。你知道是什么阻止了你吗？"
    nv "年轻的诺亚皱起眉头，怒视着门口的那个男人。"
    $ cs_left = "noahteen n pou"
    ynvl "这个混蛋就是不让我通过，明明我带来了所有的证件！"
    gnvl"你漏签了，在页面的右下角。"
    ynvl "为什么那么重要？！"

    nv "那个守卫转过身去，不想再继续讨论下去。"
    $ charleft = "诺亚"
    $ cs_left = "noah n ann"
    nonvl "那你为什么不去签一下呢？"
    $ charleft = "诺亚？"
    $ cs_left = "noahteen n pou"
    ynvl "呃，很显然我没带笔。"
    $ charleft = "诺亚"
    $ cs_left = "noah n neu"
    nonvl "艺术家不都是随身带笔的吗？"
    $ charleft = "诺亚？"
    $ cs_left = "noahteen n sur"
    ynvl "你怎么知道我是艺术家的？"
    $ charleft = "诺亚"
    $ cs_left = "noah n ann"
    nonvl "只是个猜测。"
    $ charleft = "诺亚？"
    $ cs_left = "noahteen n pou"
    ynvl "好吧...不管了，我就是没带。"
    $ cs_right = "crow n hap"
    cnvl "那么，你想让我们给你一个吗？"
    $ cs_left = "noahteen n neublu"
    ynvl "好...好的。"
    nv "根据他说话的对象不同，他的脾气似乎完全不同。"
    nv "这一点没有逃过诺亚的眼睛。"
    nv "克劳转过身面对诺亚。"
    $ cs_left = "noahteen n sur"
    ynvl "等等...！"
    cnvl "嗯...？"
    $ cs_left = "noahteen n poublu"
    ynvl "别...别走..."
    ynvl "我有件事想告诉你。"
    $ cs_right = "crow n sho"
    cnvl "..."
    nv "克劳眨了眨眼睛，不确定该如何回应。"
    cnvl "噢，诺亚..."
    $ cs_right = "crow n hap"
    cnvl "...你可以等会儿再告诉我，不是吗？总有下次的机会。"
    cnvl "所以请耐心点，好吗？"
    ynvl "好...好的..."
    nv "对诺亚来说，这话有些难以接受。"
    nv "并不是每次都有下一次。"

    $ cs_left = "noah n ann"
    nonvl "...你知道，你可能没机会告诉奥古斯特那件你想说的事了。"
    $ charright = "诺亚(？)"
    $ cs_right = "noahteen n ang"
    ynvl "...什么？"
    nonvl "我...我不是想刻薄..."
    nonvl "我只是想说...在你...再也没机会之前，你应该做所有你认为有永远的时间去做的事。"
    ynvl "比如？"
    nonvl "..."
    nonvl "...比如画他。告诉他你珍惜他。告诉你的父母去你妈的，尽可能多地去见他..."
    $ cs_right = "noahteen n sur"
    ynvl "怎么..."
    $ cs_left = "noah n sho"
    nonvl "我..."
    nonvl "咳...我...呃，我从...从奥古斯特那里听说了你。"
    $ cs_right = "noahteen n pou"
    ynvl "哦。"
    nonvl "我只是想说...珍惜你拥有的，趁你还拥有的时候。"
    $ charright = "克劳"
    $ cs_right = "crow n sho"
    cnvl "..."

    $ gametype = "ADV"
    "克劳凑近诺亚的耳边悄声说道。"
    c sho "没想到会在这里遇到你。"
    c "或者说，第二个你。"
    c "我们要不要给他笔，就此结束？"
    no ann "我想是时候了..."
    no "是的，让我们结束这一切吧。"

    c hap "诺亚—给你，一支钢笔。"
    yn sur "你真的给我拿来了..."
    c "当然。我会为你做任何事。永远。"
    yn neublu "..."
    no shy "..."
    yn "...谢...谢谢你..."
    "当他用钢笔在纸上写下第一笔时，他停下来回头看向那对。"
    yn "...你们两个是从未来来的吗？"
    c sho "啊..."
    nothought "不如说你是过去的遗物。"
    yn "你...你就是我，对吗？"
    no ann "...看来是这样。"
    yn poublu "那...那就是说，奥古斯特和我..."
    "他满怀希望地来回看着诺亚和\'奥古斯特\'。"
    nothought "对自己好一点，嗯..."
    no "...是的。"
    yn "那...我就是...一名全职艺术家...？"
    no "嗯...算是吧。"
    yn hap "太棒了..."
    nothought "别太兴奋。"
    "他小心翼翼地完成了签字，把文件递给了门后的那个男人，后者检查了一遍，简单点了点头，打开了大门。"
    "洁白的金属没有发出任何吱呀声，静悄悄地打开了，年轻的诺亚转过身，对克劳笑了笑，然后走了进去。"
    yn "我会成为值得你的人的，我保证！"
    c hap "我的小诺亚，你一直都是这个世界上最值得的人。祝你好运。"
    "他走进大门，消失在闪烁的光芒中。其他人也跟着他一起渐渐消失在大门里。"
    "皮尔森教授难得露出了微笑，鲁本继续看书，以利亚紧紧抱着他的照片，黛西举起手做了个\'记得打电话给我\'的手势，最后艾许站在了大门前。"
    ash neu "...."
    ash sad "谢谢你，诺亚。"
    "艾许看了看诺亚递给他的护身符，只是摇了摇头。"
    "就这样，一切都开始崩塌了。"
    $ persistent.chapter2_escapecomplete = True


    stop music fadeout 5.0
    jump chapter2_escape_complete
