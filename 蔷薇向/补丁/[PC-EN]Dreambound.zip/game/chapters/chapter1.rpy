label chapter1:
    window auto
    scene black with dissolve
    pause 0.5

    call screen chapter1_chapter_screen
    scene bg paint day with Fade(1.0, 1.0, 1.0)
    "独自一人。"
    play music coma fadein 3.0
    "这是一个无法逃脱的事实。"
    "他是不可爱的。令人厌恶的。不受欢迎的。"
    "他做什么都无法摆脱这一点。"
    "无论他去哪里，那些充满仇恨的眼神都会追随着他。它们的目光会将他生生烧死。"
    "他们的话语会像刀子一样刺穿他，直达他的内心深处。他的本质会变得黑暗，然后崩溃成虚无。"
    "\'你活该\'他们会说。"
    "如果你听我们的，就不会发生这种事\'他们会尖叫。"
    "为什么你就是不能正常一点？\'会有人这样喊。"
    "即使在这里，远离那些话语的触及，他也仍能感受到它们。在他的胸膛里。在他的脑海中。在他的心里。"
    "{i}你永远都会孤独。{/i}"
    "{i}永远。没有人会爱你。没有人能忍受你。{/i}"
    "{i}所以就蜷缩起来死吧。{/i}"
    "{i}死吧。{/i}"
    "{i}就这么死吧。{/i}"

    "诺亚缓缓睁开眼睛。他仍然坐在画架前。上面是一块全新的、还未被涂抹的画布。"
    "他的目光转向前一晚出现的那幅画作。"
    "一场噩梦。令人作呕、扭曲。一个永远无法爱自己儿子的父亲的映射。一个{i}永远无法{/i}爱自己儿子的父亲。"
    "它很美。"
    "它就是他一直所渴望的一切。"
    "他从座位上站起来，伸展了酸痛的双肩。多年弯腰工作，他的骨头发出咯吱声。"
    "心不在焉地，他拿起遥控器打开了电视。"
    "背景噪音。用来填补他内心空虚的白噪音。"
    "但不知为什么，他的目光被屏幕吸引了。"
    tv "我们现在获准分享出现在死者尸体上的奇怪标记的图像。"

    "在屏幕上，一个男人双眼紧闭，再也无法睁开。"
    "藤蔓缠绕在他的手臂上，一直延伸到他的喉咙，最后生长到他的脸上。它们集中在男人额头中央的一朵花上。"
    nothought "死亡之美。"
    tv "这名男子昨晚在家中被发现。此前，他的妻子也被发现处于同样的状态。"
    tv "警方仍在调查是否涉及犯罪。"
    "镜头拉远，显示了男子整张脸。"
    "诺亚僵住了。"
    "他的目光从画作转向屏幕。"
    "那是他的父亲，毫无疑问。"
    "没有多想，诺亚跳了起来，走到电视机前。他紧紧抓住它，寻找着某种答案。"
    "他为父亲的离世感到难过吗？"
    "不。"
    nothought "但昨晚我看到的..."
    tv "到目前为止，警方还没有透露任何线索。我们会随着案件的进展持续为您更新消息。"
    nothought "这是可能的吗？他是因为昨天发生的事而死的吗？"
    nothought "但那不是真正的他...只是梦中的一个阴影..."
    "这些话在他脑海中盘旋，威胁要吞噬他。一个接一个的问题浮现出来，但他想不出一个答案。"
    "他觉得自己快要疯了。"
    nothought "我需要和谁谈谈。任何人。"
    nothought "但谁会理解？谁会在乎？"
    "毕竟，他一个人都没有。"
    no sad "凯恩..."
    "诺亚皱了皱眉头。他做了那么多推开他的事，做了那么多让他离开的事，现在却需要他。"
    no "我的手机放哪儿了..."
    "他上下搜寻，最后想起把它放在了垃圾桶里。叹了口气，他伸手进去找到了它。"
    "他打开了手机。"
    "父亲打来了11个未接来电。"
    "他删除了通话记录，改为拨打凯恩的号码。"
    play sound beep fadeout 0.5
    phone "您的服务已被中断。请访问我们的—"
    no fro "该死的！"
    show bg with hpunch
    "诺亚迅速挂断电话，然后狠狠地把手机摔在地上。"
    "账单。永远都是账单。他存下的钱快要用完了。"
    no sad "该死的凯恩，你为什么在我需要你的时候不在这里。"
    nothought "...他大概在工作吧。当然是这样。"
    "诺亚的目光转向了前门。"
    "有那么一瞬间，他在想。"
    "他想知道如果自己有一份工作，有一个关心他的家庭，有同事和朋友，有一个生活，也许还有一个恋人和宠物，生活会是什么样子。"
    "在他意识到之前，他的手已经放在了门把手上。他的手心出汗，呼吸也变得不稳。"
    no "我不害怕...这不可怕...我只是..."
    nothought "讨厌。"
    "起初，他并不害怕。他退缩是因为他讨厌它。讨厌其他人。讨厌他们虚假的幸福。"
    "讨厌他们拥有他失去的未来。"
    "他知道他们都是骗子。骗子。背信弃义的人。"
    "但现在已经太久了。他上次走在阳光下是多少年前的事了？"
    "太多了。"
    stop music fadeout 2.0
    "尽管如此，他还是转动了门把手，走进了明亮的光线。"

    scene bg sky day with Fade(1.0, 1.0, 1.0)
    "一片幸福的海市蜃楼在诺亚面前展开。阳光洒在他的脸上。远处，一朵乌云滚滚而来。"
    "他用手遮住眼睛，不习惯这么强烈的光线。"
    play music nothing fadein 3.0
    "他以为这会让他感到很好。在这么长时间之后，阳光再次照在脸上。"
    scene bg streets day with dissolve
    "但并没有。这对他来说是一种浪费。"
    "诺亚低着头走在人行道上，小心翼翼地避免与任何人对视。"
    "他走啊走，每一步都离他的家和他的舒适区越来越远，让他的心跳得越来越快。"
    nothought "我...我想我知道凯恩工作的地方。我应该知道怎么去。"
    "他的脚步依然不安。"
    "一群青少年冲下了小路。他屏住呼吸等他们经过，等着他们对他说些什么。"
    "直到他们走远，他才能再次呼吸。"
    "他走啊走，又走了一些，仅仅为了确保自己，又走得更远了。这时他确信自己一直在兜圈子。"
    "每一条街道，每一家商店，每一栋房子都看起来都一样。"
    "他以为自己知道凯恩工作的地方，但事实并非如此。"
    "原来他对凯恩的了解已经很少了。"
    show bg streets day with hpunch:
        xpos 0.73 ypos 1.04 xanchor 0.5 yanchor 1.0 zoom 1.49
    "被眼前的景象和声音淹没，他蹲下身来，用双臂遮住了脸。"
    show bg streets rain:
        xpos 0.73 ypos 1.04 xanchor 0.5 yanchor 1.0 zoom 1.49
    show rain # TODO NEW RAIN GRAPHICS
    with dissolve
    "就在这一刻，天空开始下雨。诺亚犹豫是继续待在原地还是去找个遮蔽处，但最终他的腿却动不了。它们替他做出了决定。"
    nothought "我真是个白痴...该死，为什么我要离开...如果我只是等待，他最终会来的..."
    nothought "这一切都只是个愚蠢的巧合。我父母的死，我父亲额头上的标记...这一切都毫无意义。"
    nothought "如果凯恩看到我现在的样子，他一定会嘲笑我的。"
    "一群商人走过他身边，聊天大笑。诺亚不由自主地移开了视线，为自己感到羞愧。"
    bus1 "看看他...你觉得他是无家可归的吗？"
    bus2 "要么就是个吸毒的。最好远离他。"
    "他们嘲笑他。"
    "他以为自己已经习惯了这些话。"
    "但它们仍然让他感到痛苦。"
    "诺亚及时抬头，与他希望见到的那个人对上了眼神。"
    k sur "........"
    no sur "........."
    k "...你们先走吧。"
    bus1 "凯恩要去买毒品了。祝你们好运，伙计。"

    scene gallery_6 with Fade(1.0, 1.0, 1.0)
    "凯恩无视了其他人，小跑到诺亚仍然蹲在人行道上的地方。他迅速倾斜伞面，为诺亚遮挡住雨。"
    k "诺亚，你在这里做什么？出什么事了？"
    no "凯恩...我是...我在找你..."
    k "你应该打电话的！真巧你正好路过..."
    no "我的手机没电了...没交话费..."
    k "对...抱歉，我应该猜到的。"
    no "...我的父母去世了。"
    k ".........."
    k "什么？"
    "凯恩的脸上写满了无法用言语表达的情绪。"
    k "诺亚，我很遗憾。我知道...你们的关系并不好，但是..."
    k "你现在的感受是什么？"
    no "........."
    no "对他们的死亡？什么感受也没有。"
    k "...即使你恨他们，我相信你现在也不会毫无感觉。"
    no "我甚至无法说我恨他们。已经太久了。它只是...熄灭了。"
    no "我再也没有力气去恨他们了。"
    k "诺亚..."
    "凯恩皱着眉头，扶助诺亚站了起来，拍掉他衣服上的灰尘。"

    scene bg streets rain
    show kaine n dim sad at slightleft
    show noah n dim sad at slightright
    show rain
    with Fade(1.0, 1.0, 1.0)
    k "让我送你回家吧。我们边走边聊，好吗？"
    "诺亚点了点头，不确定从何说起。"

    no "...这不仅仅是关于他们去世的事，还有..."
    no "他们是如何去世的。"
    show noah n ann with dis
    no "这可能听起来很疯狂，但是—"
    stop music fadeout 5.0
    hide noah
    hide kaine
    with w12
    "世界在他们周围崩塌。"
    "当他们消失时，另一个人走进了他们刚刚所在的地方。"
    show ivan n dim neu at center behind rain with dissolve
    u "....................."



    window hide
    show black with dis2
    show transition movie onlayer overlay
    pause 3.0
    window show
    "坠落，坠落。"
    "诺亚内心深处那种熟悉的感觉。"
    "他讨厌那种感觉。"
    "就在他以为自己会永远困在那个中间状态时，他突然停了下来。"

    scene bg fantasy
    show kaine n sur at slightleft
    show noah n sur at slightright
    with hpunch
    "一望无际的田野。这个景观虽然完全是自然的，但看起来却不太一样。"
    play music cold fadein 5.0
    "诺亚从草地上站了起来。在他旁边，凯恩也做了同样的动作。"
    k "这是什么..."
    k "我们在哪里？"
    "凯恩睁大眼睛，环顾着这片景观，寻找任何他能认出的东西。当然，他什么也找不到，因为这不是他以前来过的地方。"
    "这与凯恩所知的现实完全不同。"
    no "这是—"
    show bg with hpunch
    "在诺亚能开始解释之前，他的双臂突然被从身侧扯开，粗暴地推到背后。"
    "传来两声咔嗒声，他的双手被铐在了背后。"
    guard "擅自进入王国这么深的地方？！"
    guard "我们最好把他们直接扔进监狱。如果国王知道了，他会非常生气的！"
    k "呃...监狱？国王？我想你们误会了，我们只是—"
    guard "闭嘴！"
    "一名卫兵推了他一把，导致凯恩踉跄了一下。诺亚注意到，凯恩的双手也被铐在了背后。"
    k "我们不是...我们不是从这里来的，这是个误会！"
    guard "闭嘴，害虫！"
    k "诺亚，快解释！"
    show noah n sad with dis
    no "这是...这是..."
    no "我们...在某个人的梦境里。"
    k "...你吃了什么奇怪的东西吗？"
    no "听着，我知道这听起来很疯狂，但请看看你周围的环境。你真的觉得我在撒谎吗？"
    no "你以为我现在有精力骗你吗？"
    k "......."
    k "是你...把我们带到这里来的吗？"
    show noah n fro with dis
    no "不！不，不是我，这就是我感到困惑的地方！"
    no "我不想在这里。我也不会选择来到这里！但最近...最近我一直被无意识地拽进梦境！"
    no "这以前从未发生过..."
    k ".........."
    hide kaine
    hide noah
    with dissolve
    "凯恩的脸早已失去了血色。卫兵们继续前进，把他们推向城堡。"
    "他们无视了这些穿着奇怪衣服的人的话，认为他们显然是疯了。"

    k sur "那么...你说的\'这以前从未发生过\'是什么意思？"
    no ann "........."
    no "从我们上高中开始，我...我就能这样做了。进入梦境。"
    k "怎么会？为什么？！"
    no "我不知道...我完全不清楚..."
    k sad "为什么你没有告诉我？"
    no "为什么我必须告诉你所有的事情？"
    "凯恩转过头去，被他的话语伤害了。"
    k "....我们怎么离开？"
    no "....."
    no "我...只有当做梦的人愿意让我们离开时，我们才能离开..."
    k "那我们该怎么办？如果他们不愿意让我们离开会怎么样？！"
    no "...那他们就会醒来，而我们...我不知道。也许会死吧。"
    k sur "........"
    no "这也不是最糟糕的事情..."
    k ser "诺亚。我不会死在这样的地方。"
    no neu "那我们最好弄清楚是谁的梦。"
    k ang "也许如果我的手没被铐住的话，我就能弄清楚了。嘿，放开我们！"
    guard "......."
    "卫兵们把凯恩和诺亚押进了城堡，两人一直在与他们的囚禁者抗争。"

    scene black with Fade(1.0, 1.0, 1.0)
    "走廊曲折蜿蜒，充满黑暗和陈腐的空气。"
    "他们的脚步声在空荡荡的空间里回响，在一排排铁栏杆之间走着。"
    "诺亚从一个牢房望向另一个牢房。"
    "在有些牢房里，囚犯在阴影中徘徊，注视着他们的动作。"
    "在其他牢房里，如果囚犯还没死，诺亚也会感到很惊讶。他们的皮肤挂在骨头上，太瘦弱以至于无法维持生命。"
    "他们静静地躺在牢房里，一动不动。"
    k sad "诺亚，这感觉不像是在做梦。这感觉很真实。"
    no ann "因为我们真的在这里。我们的身体已经不在现实世界了。"
    k "..........."
    "卫兵终于停下了脚步，拽着凯恩和诺亚的手铐。金属勒进他们的手腕，留下深深的红痕，让人感到疼痛。"
    guard "去吧，在那里腐烂吧。"
    "手铐从他们的手腕上落下，发出咔嗒一声，他们的背部被一个钝器猛地推了一下。诺亚猜测那是剑柄。"
    "他们踉跄着向前，落进了一个牢房。铁栏杆很快被砰地一声关上，门也被钥匙锁上了。"

    scene bg prisonroom full with Fade(1.0, 1.0, 1.0)

    k ang "嘿！我们难道不能有个审判什么的吗？！"
    k "别无视我！嘿，回来啊——"
    k "糟糕..."
    "在他们身后，钥匙被挂在一个够不到的钩子上。"
    "就像是在嘲笑他们的自由。"
    k sad "妈的...诺亚，这可不妙。"
    no fro "你说得对。"
    "诺亚环视牢房，直到视线落在了某个东西上。"
    play sound heart fadeout 2.0
    show bg:
        easein 0.25 zoom 1.1
        easeout 0.25 zoom 1.0
    "不，不是某个东西。是某个人。"
    "一个男人靠在石墙上，被锁链束缚着无法动弹。"
    "诺亚全身的细胞都冻结了。"
    nothought "不是他。为什么偏偏是他？"
    "凯恩的目光跟随着诺亚的，最终落在了那个男人身上。"
    k sur "那个人是...弗洛伊德先生吗？"
    no sca "看起来就是他。"
    k "所以...这是...他的梦境？"
    no "可能是。"
    k ".........."
    k sad "你想让我...？"
    no ann "...我来处理。"
    k "等等。在我们中任何一个人采取行动之前，我们能聊聊吗？"
    no "当然，因为我们有的是时间。"
    k"就一分钟。拜托了。"
    "诺亚抱起双臂，等待着问题的开始。"
    k "我们为什么会突然被拽进这里？"
    no "我也不知道。就像我说的，这从未发生过。以前每次都是自愿的。"
    no "这就更奇怪了..."
    k "昨天发生了什么？"
    no "......."
    "诺亚在心里权衡了一下，不知道是否应该告诉凯恩实情。最终，他决定说实话。"
    no neu "多年前我就不再进入梦境了。但昨天，就像现在一样，我被拽进了一个梦境。那是...我父亲的梦境，我想。"
    no ann "我看到他被射杀了。然后今天早上，他就死了。"
    k sur "...什么？"
    "他睁大了眼睛。"
    k "它们...有关联吗？"
    no "我不知道。也许吧。"
    nothought"那些出现的标记...梦境中的死亡..."
    no "...这就是我想和你谈的。总之，让我们想办法离开这里吧，好吗？"
    "凯恩点了点头。"
    "诺亚一步一步地慢慢靠近那个男人，最终那个男人从地上抬起头，死死地盯着诺亚。"
    mrf sad "...诺亚...？"
    "诺亚一抖。"
    "在所有人中，他最不希望见到这个男人。"
    no neu "弗洛伊德先生，我们得把你救出去。"
    mrf "...出去？不...不能离开...不会离开...太害怕了。"
    no neu "没什么好害怕的。这只是个梦境。你有能力随意改变它。来吧，我们走吧。"
    mrf "不...！我做不到！"
    no fro "........."
    no ann"好吧。你害怕什么？"
    mrf sca "那个阴影人...他有一把枪..."
    "警铃在诺亚脑海中响起。他回头看向凯恩，后者已经皱起了眉头。"
    no "没人会伤害你的。"
    "他颤抖得好像随时都会哭出来。"
    "诺亚叹了口气。"
    nothought "看来我得用强硬的方式了。"
    no neu "那让我来帮你吧。"
    mrf sad "你...愿意帮我？在发生了那些事之后？"
    no "是的。你就待在那里，我来想办法把你解开。然后我们一起走。"
    mrf "等等..诺亚...我想道歉——"
    "诺亚背过身去，对话的走向毫无兴趣。"
    nothought "我用不着你的道歉。如果由我决定，我会让你留在这里腐烂，但凯恩不应该遭受同样的命运。"
    nothought "把他解开，把门打开。这应该很有趣。"
    k sad "我们该怎么做？"
    no neu "我们把他弄出去，然后我们就能离开了。"
    k "你说得太容易了。"
    no ann "哦，这可不容易。我们也很着急。如果他醒过来的话..."
    k ser "对...我们四处看看吧。"

    if persistent.chapter1_escapecomplete == True:
        menu:
            "跳过谜题部分":
                jump chapter1_escape_complete
            "进入谜题部分":
                pass

    if game_type_ver == "VN":
        jump chapter1_escape_VN_version
    else:
        pass

    window hide

    show escape movie onlayer overlay
    pause 5.0
    scene black with dissolve #add this before escape room so the hide after works

    jump chapter1escape


label chapter1_escape_complete:
    window auto

    $ gametype = "ADV"

    scene bg prisonroom full with Fade(1.0, 1.0, 1.0)




    play music chasing fadein 4.0
    play sound earthquake fadein 1.0

    scene bg prisonroom full at Shake((0.5, 1.0, 0.5, 1.0), 75.0, dist=2)
    "与此同时，周围的世界开始崩塌。墙壁倒塌，地板开裂，牢房摇晃，仿佛要从现实中撕裂开来。"
    "弗洛伊德先生看起来像是在向诺亚伸出手。他张开嘴，但没有发出任何声音就消失了。"
    "诺亚抓住了凯恩的手。"
    no sca "快跑！我们必须走！"
    k sur "发生什么事了？！"
    no "这个梦境正在崩塌！我们没多长时间了，我们必须赶快出去！"
    "两人手牵手，穿过曲折的走廊，寻找能拯救他们的光明，周围的世界在隆隆作响。"
    "轰鸣声在整栋建筑物里回荡，大到他们能感受到它在内心深处。"
    "凯恩的手在诺亚手中感到汗湿。诺亚相信自己的手也是如此。"
    "他的腿在燃烧——肌肉在尖叫，乞求解脱。上次他这样狂奔是什么时候来着？"
    nothought "大概是...在那之后..."
    k "那里，就是门...！"
    "他们冲出门外，刚好看到整个城堡轰然倒塌，然后被吸进了虚无。"

    scene bg fantasy with hpunch

    "外面的世界看起来和他们刚来时差不多，但很快就不会了。"
    "很快它也会崩塌消失。"
    "一个短暂的梦境，永远无法真正存在。"
    k sca "哈...哈..."
    no ann "该死..."
    no "走吧！"
    k sur "我们怎么才能离开这里？！"
    no "如果...如果我们回到我们来的地方...应该会有办法！"
    "两人转身准备离开。"
    stop music fadeout 2.0
    "但有人挡在他们面前。"

    $all_moves(camera_check_points={u'y': [(2119, 0, u'linear'), (-1301, 10.0, u'linear')], u'x': [(599, 0, u'linear')], u'z': [(876, 0, u'linear')]})
    show crow n neu at center
    show bg fantasy blur

    with dissolve
    play music moment fadein 2.0
    "一个金发绿眼的男人。"
    no sur "..........."
    k sur "..............."
    "两人都呆住了。"
    "他们张大嘴巴，惊讶得仿佛眼睛随时会从头上蹦出来。"
    "那个男人温和地微笑着。一种像向日葵般盛开的甜美笑容。只有一个人会有这样的笑容。"
    no sad "...奥古斯特...？"
    show crow n sad with dis
    "他用悲伤的眼神看着诺亚。"
    u "...诺亚。"
    "诺亚脑海中涌现出一百万个问题。一百万件他想说的话。一百万件他想做的事。"
    "但他的嘴巴就是不配合。他一个字也说不出来。"
    "他在脑海中演练过多少次这种情况？他准备过多少次演讲，如果有一天再次见到奥古斯特？"
    "眼角渗出了泪水。"
    "凯恩继续盯着，一脸困惑。"
    k "他是谁...怎么回事..."
    nothought "他是梦境的一部分吗？弗洛伊德先生很了解他，所以这也不足为奇..."
    nothought "但是...他看起来如此...完整...如此...真实..."
    k "...你是谁？"
    show crow n neu with dis
    c "我叫克劳。"
    no hea "你是谁...你是...？"
    "他等待着那些他渴望已久的话语。"
    "让他成为真实的，让他成为奥古斯特。"
    c "我只是一个无家可归的人。"
    c "你们两个最好赶快离开，在这个世界消失之前。"
    show crow n hap with dis
    "名叫克劳的男孩温和地对他们微笑。这是诺亚再熟悉不过的温柔笑容。"
    "他想冲回去问他那一百万个问题。"
    "但取而代之的是一只手拉住了他。"
    "凯恩。"
    $ camera_reset()
    hide crow
    show bg fantasy
    with dissolve

    k sad "诺亚...我们必须走了。"
    no "但是...他..."
    "当诺亚回头看时，他已经不见了。"
    "在世界崩塌之前，凯恩和诺亚逃了出来。"

    window hide
    show black with dis2
    show transition movie onlayer overlay
    pause 3.0
    window show
    stop music fadeout 5.0
    "那种坠落的感觉。那种深深扎根于胃里的恐惧。"
    "然后他回来了。"
    "回到家，回到一个他独自一人的现实。"

    scene bg paint night with Fade(1.0, 1.0, 1.0)
    "当诺亚睁开眼睛时，他再次回到了自己的房子，坐在画架前。上面是一幅未完成的画作。"
    "绿色的田野扭曲成了某种阴险的东西。某种超出理性的东西。"
    play music coma fadein 5.0
    no sad "............"
    "他再次举起了画笔。"
    "这一次，每一笔都来得很轻松。就好像他正把自己的灵魂倾泻在画布上一样。每一滴颜料都反映了他自己。"
    "这种轻松感已经很久没有出现了。"
    "但他的思绪飘到了别处。"
    nothought "克劳。"
    nothought "如果凯恩没有——我们本可以——"
    nothought "我本可以问你那一百万个问题。我本可以……再次感受到你……"
    nothought "即使我们只能聊一会儿，那也足够了……"
    nothought "是你吗？他看起来就像你。他的笑容让我想起了你的笑容。"
    nothought "克劳……还有奥古斯特。"
    nothought "求你了……"

    play sound knock fadein 0.5
    "前门传来敲门声。"
    "出于某种原因，诺亚从画作中站了起来，打开了门。这是过去他会简单忽略的事情。"
    "也许他的思绪太过占据了他，以至于他没有考虑自己在做什么。"
    "也许当他打开那扇门时，他内心深处的某个地方希望能看到一个带着春天般笑容和森林般深邃眼睛的某个人。"
    "但站在门外的人是一个诺亚从未见过的男人。"
    "那个白发男人推开诺亚，闯进了他的房子。诺亚呆立在原地，震惊地看着这个男人。"

    scene gallery_7 with Fade(1.0, 1.0, 1.0)
    "他踢翻了角落里一张被遗忘的沙发上的几块画布，然后坐了下来，把自己安置了进去。"
    "仅仅一会儿后，他拿起遥控器打开了电视，把腿搭在一幅被遗弃的画作上。"

    no "..................."
    nothought "什么鬼？"
    no "你他妈在干什么？滚出去，否则我要报警了。"
    u "你的电话服务被切断了。"
    "他的声音平板而直白。"
    no "你怎么会知道这个？！"
    u "我在你的垃圾桶里看到了停机通知。"
    "诺亚关上门，带着不安走近那个男人。"
    nothought "谁他妈会直接闯进别人的房子，坐在沙发上打开电视？到底发生了什么？！"
    no "好吧，混蛋，你是谁？"
    i "伊万。"
    "诺亚终于好好看了看这个\"伊万\"。他的头发完全漂白成了白色，眼睛也是不同的颜色。"
    "他的衣服很奇怪，好像他更适合在T台上而不是在这一片混乱中。"
    "不过，他完全没有问题就把自己安置了下来。他靠在沙发上，对诺亚完全不感兴趣。"
    "他的眼睛盯着电视，表情无聊。"
    nothought "到底发生了什么？！"
    "最后，诺亚注意到了。"
    "从他的手臂和脖子上延伸出来的标记。"
    "他之前在那台电视上见过这种标记，不止一次。"
    no ".........."
    no "你想从我这里得到什么？"
    i "我今晚就住在这里。我没有其他地方可去。"
    no "回答我的问题！"
    i "你有什么问题吗？我说我今晚就住在这里。"
    no "但为什么？！"
    i "因为我对你产生了兴趣。"
    i "总之，我累了。卧室在哪里？"
    "没有思考，诺亚指向了一扇门。"
    scene bg paint night with Fade(1.0, 1.0, 1.0)
    i neu "谢谢。你可以睡沙发。"
    "伊万从座位上站起来，整理了一下衣服，然后走进了卧室。"
    "诺亚呆立在原地，不知道刚刚发生了什么。"
    "摇摇头，他又拿起画笔继续画了起来。"
    stop music fadeout 3.0
    nothought "我待会再处理他……我不能失去这份灵感……"



    scene bg classroom day with Fade(1.0, 1.0, 1.0)
    play music rural fadein 2.0
    "咔嗒，咔嗒，咔嗒。"
    "铅笔尖慢慢敲击着桌面，他的眼睛集中在那个金发男孩的侧脸上。"
    "一周前，奥古斯特搬进了他们的班级。围绕着他的初始热潮已经平息下来，他也很容易就融入了其他人。"
    "他天生就有魅力，善良，聪明……总之，他可以和任何人成为朋友。"
    "然而整个星期，他们放学后一起走回家。在休息时间里，他们一起吃午饭。"
    "有什么让诺亚的思绪一直集中在他身上。他的声音，他的笑容，他对任何事物都如此感兴趣，不管是谁在说话。"
    "他是如何认为诺亚如此出色。他会紧紧抓住诺亚的每一个字，并将其视为最宝贵的财富。"
    "不管诺亚是否意识到，他都完全着迷了。"
    mrf neu "诺亚，你有什么需要吗？"
    noteen shy"啊...没有，弗洛伊德先生，我很抱歉。"
    "他放下铅笔，为再次在众人面前被点名而感到尴尬。在奥古斯特到来之前，他一直努力融入背景，尽可能被忽视。"
    "这似乎并不奏效。全班都在嘲笑他，除了奥古斯特和凯恩。"
    "他把头埋在作业本里，脸颊通红。任何事情都好，只要能逃离他们的笑声。"
    "但他很清楚，如果换成别人，他也会笑的。"
    mrf smi "这就是本周的全部内容了，同学们。没有作业，因为我现在心情特别好。如果你发现自己有额外的时间，请务必自学。"
    "铃声响了，大家开始离开教室。凯恩一瘸一拐地走到诺亚的桌子旁，脸上带着一丝歪斜的笑容。"


    show bg classroom day:
        xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.71
    show kaineteen m hap at slightleft
    show noahteen m neu at slightright
    with dissolve
    k "不错的敲击声。"
    show noahteen m poublu with dis
    no "闭嘴。我只是在思考。"
    k "思考什么？"
    no "...当然是上课的事。"
    k "对啊。哈姆雷特确实很有趣。"
    "诺亚翻了个白眼，但还是回以笑声。"
    k "总之，你想不想在回家的路上顺便去游戏厅？听说他们有新的游戏机。"
    show noahteen m sca with dis
    no "...呃，我真希望。我父母给我安排了新的家教，所以我必须直接回家。"
    show kaineteen m pou with dis
    k "真扫兴。那好吧，我自己去玩吧。"
    show noahteen m hap with dis
    no "混蛋。"
    show noahteen at right
    show kaineteen at center
    with move
    show august m hap glasses at left with dissolve
    "像春天的花雨一样，奥古斯特走到凯恩身边。"
    "那张温和、善良的笑容依旧在脸上。"
    a "我们能在回家的路上顺便去商店吗？我想买些新的胶卷。"
    k "诺亚太忙了，要去上家教。"
    show noahteen m neublu with dis
    no "哦，我有足够的时间。"
    k "什么？"
    no "那不会花太多时间...我们可以改天再去游戏厅。"
    k "好吧...那我也一起去。"
    no "我还以为你要去玩游戏呢。"
    show august m sho with dis
    a "哦，如果你很忙的话，我可以自己去—"
    show noahteen m sur with dis
    no "不！我是说...呃，我其实也没那么忙，所以我可以一起去。"
    "诺亚从桌子上站起来，拿起背包。"
    "不知为什么，凯恩看起来很失望。不过，诺亚却无法把目光从奥古斯特身上移开。"
    "三人离开了教室。"

    scene bg school stairs with Fade(1.0, 1.0, 1.0)
    "在走下楼梯时，奥古斯特突然停下脚步。"
    a sur "哦...我想我把相机落在桌子上了...你们两个先走吧，我不想让你们等太久，耽误了家教。"
    a "我们下次再一起走。"
    "奥古斯特向诺亚和凯恩挥手告别，然后消失在楼梯间。"
    "凯恩转身准备离开，只是在注意到诺亚没有跟上时停了下来。"
    kteen neu "他说让我们先走，你快走吧。"
    stop music fadeout 4.0
    noteen neublu"...你先走吧，我等会儿。"
    kteen sad "...那我也等会儿。"
    noteen "没关系，你不是想去游戏厅吗。"
    kteen ".........."
    "一种诺亚无法理解的表情掠过凯恩英俊的面庞，然后他耸了耸肩。"
    "他转身走下楼梯，但又回头看向诺亚。"
    kteen "是啊...我想和你一起去。那明天见吧。"
    "他消失在楼梯间，留下独自等待的诺亚。"
    "他紧张地敲着脚，清了清嗓子。"
    "他的双手出汗了，不知为什么，他突然希望凯恩能留下来。"
    nothought "我到底该对他说些什么...凯恩一直都在..."

    play music moment fadein 2.0
    $all_moves(camera_check_points={u'y': [(2100, 0, u'linear'), (-300, 10.0, u'linear')], u'x': [(599, 0, u'linear')], u'z': [(876, 0, u'linear')]})
    show august n shy at center
    show bg school stairs blur
    with dissolve

    a "哦..."
    "在他上方几级台阶处，奥古斯特惊讶地停下脚步。他手里拿着一台小型粉色相机和眼镜。"
    "淡淡的红晕浮现在他苍白的皮肤上。诺亚拼命寻找着任何可以说的话，但却一个字也说不出来。"
    show august n shy glasses with dis
    "奥古斯特擦拭完眼镜，然后重新戴上，好像要确认眼前的景象是真实的。"
    a "...你本来可以先走的。不用等我。"
    noteen "没什么大不了的...我也想一起走。"
    show august n hapblu glasses with dis
    "奥古斯特的惊讶变成了微笑。"
    noteen shy "呃...你知道，因为我们还没有太多机会了解彼此..."
    a "我很乐意。那我们现在就走吧？在我让你更迟到之前。"
    "奥古斯特从诺亚身边擦肩而过，带头走在前面。一股淡淡的花香随他而来。"
    stop music fadeout 3.0
    "两人并肩离开了学校。"

    $ camera_reset()
    scene bg town day:
        xpos 0.87 ypos 1.26 xanchor 0.5 yanchor 1.0 zoom 1.75
    show noahteen n neu at slightleft
    show august n neu glasses at slightright
    with Fade(1.0, 1.0, 1.0)
    "微风轻轻吹拂，几乎感觉不到，却温柔地拂动着奥古斯特的头发。"
    play music uplifting fadein 3.0
    "这不是诺亚刻意去注意的，而是他无法自已地注意到。"
    "起初，他们沉默地走着。并不尴尬，但诺亚还是在脑海中搜索着任何可以说的话。"
    "任何能让他听起来很酷、很有趣，或是奥古斯特会想要成为朋友的人。"
    no "所以...你喜欢这个学校吗？"
    nothought "为什么会这样...我听起来太蠢了..."
    a "...是的，我很喜欢。大家对我都很好。我也很喜欢弗洛伊德先生，他很有趣。"
    no "是啊..."
    no "你说你经常搬家，对吗？"
    a "我爸爸的工作需要经常出差，所以我从未在一个地方待超过一年。说实话，我也不确定我们会在这里待多久。"
    show noahteen n hap with dis
    stop music fadeout 2.0
    no "你妈妈一定很讨厌这样。"
    show august n sho with dis

    a "...."
    show august n sadsmi with dis
    play music unsaid fadein 4.0
    a "我相信她会的，但她其实很久以前就去世了。"
    show noahteen n sca with dis
    no "............."
    nothought "我做了什么..."
    show noahteen n sad with dis
    no "我很抱歉，我不是有意的—"
    a "别担心，你怎么可能知道。没关系的。"
    no "...她是个什么样的人？"
    a "嗯..."
    show august n sad with dis
    a "我爸爸说她和我很像，但我不太确定。她是在生我的时候去世的。"
    no "..........."
    nothought "我越说越糟糕了..."
    nothought "诺亚，为什么..."
    show august n neu with dis
    a "对不起，我让气氛变得有些沉重了，是吗？我以前从未告诉过别人。"
    no "不...没关系，我不介意我们谈论什么。我只是喜欢和你聊天。"
    show august n shy with dis
    a ".........."
    a "我也很喜欢和你聊天。"
    show noahteen n neublu with dis
    no "..........."
    "阳光照在他们的脸上，温暖了他们的内心。"
    "每一步都仿佛在诺亚体内回响。"
    show august n hap with dis
    a "那么，你能猜出我为什么叫奥古斯特吗？"
    no "嗯..."
    no "嗯...你是八月出生的吗？"
    "他咧嘴笑得很灿烂，比阳光还要耀眼。"
    a "我就是八月出生的奥古斯特。"
    no "真可爱。"
    a "我不知道算不算可爱...也许我父母只是随便选了个他们想到的第一个名字。"
    "诺亚摇了摇头。"
    no "很适合你。你就像个八月出生的奥古斯特。"
    show august n sho with dis
    a "...."
    show august n hapblu with dis
    a "谢谢你，诺亚。"
    a "哦，这就是我想进去的商店。你要进去还是在这里等我？"
    "诺亚抬头看了看那家商店。橱窗里摆满了各种形状和尺寸的相机。"
    no "我在这里等你。"
    a "好的，我会快点的！"
    no "没关系，你慢慢来。"
    hide august
    hide noahteen
    with dissolve
    "奥古斯特一进商店，诺亚就靠在墙上，不停地撞着脑袋。"
    nothought "我为什么要说那些...如果他现在讨厌我怎么办？"
    nothought "每次和他说话，感觉就像有人在控制我的舌头。我怎么了？"
    nothought "和凯恩在一起就从来不会这样，或者和其他同学在一起也不会。"
    nothought "就是他。"
    nothought "就是他。"
    "叹了口气，诺亚低头看了看手机，发现已经有三个未接来电是从他妈妈那里打来的。"
    "但当他的目光从手机屏幕转移到能从相机店的橱窗里看到的奥古斯特身上时，选择就很明确了。"
    "他把手机塞回口袋，就在奥古斯特从商店里走出来的时候站直了身子，清了清嗓子。"
    noteen neu"你买了什么？"
    a hap "我需要给相机买些新的胶卷。看，就是这些。"
    "奥古斯特从袋子里拿出了胶卷。诺亚从来不太对摄影感兴趣，但现在它似乎是世界上最有趣的事物。"
    noteen neublu "对...你说你喜欢拍照。我记得。"
    a "我很喜欢。我没有什么高级的相机，只有一台即时相机，但是..."
    a "它让我能保留下我去过的所有地方的记忆。这让我很高兴。只要有这些照片，我就不会忘记任何事。"
    "再次并肩而行，诺亚和奥古斯特继续沿着街道前进。"
    a "我们走捷径吧？"
    nothought "从这里到那里，捷径其实并不比原路更短...但是..."
    nothought "他喜欢那条路，不是吗？"

    show bg town day with dissolve:
        xpos -0.37 ypos 1.61 xanchor 0.5 yanchor 1.0 zoom 2.88
    noteen "是啊...我们应该能从这里穿过去。"
    "诺亚爬上了挡在面前的矮砖墙，然后转过身来，向奥古斯特伸出了手。"
    "奥古斯特毫不犹豫地握住了那只手。诺亚轻松地把他拉了上来，站在他身边。"
    "诺亚的手只是短暂地停留了一下。"
    stop music fadeout 4.0
    "但那短暂的一刻已经足够了。"

    scene bg mountains day
    show noahteen m neu at slightleft
    show august m neu glasses at slightright

    with Fade(1.0, 1.0, 1.0)
    "不远处的河流在午后阳光下温和地流淌着，两个男孩一起沿着山路走了上去。"
    play music uplifting fadein 4.0
    "这是一种令人安心的声音，但诺亚却感到心神不宁。他们接触的地方仿佛还在发烫，心跳声在耳边回响。"
    a "诺亚？"
    show noahteen m sho with hpunch
    no "啊！？"
    show august m hap with dis
    a "是什么让你这么害怕？"
    show noahteen m shy with dis
    no "哦，对不起，我有点...陷入了自己的思绪。你刚才说什么？"
    a "我只是想感谢你能和我一起来。我知道你很忙...你真的不必这样。"
    a "说实话，我很想让你来。所以我欠你一个人情。"
    no "......."
    show noahteen m poublu with dis
    no "你不欠我什么..."
    nothought "其实..."
    no "那么有时候让我看看你的照片吧。"
    show august m sho with dis
    a "我的...照片？它们没什么特别的—"
    no "拜托？"
    a "........"
    show august m hap with dis
    a "那也让我看看你的更多画作吧。"
    no "但是—"
    a "我觉得这是很公平的交易！"
    no "好吧..."
    "前面，他们已经能看到自己房子的背影了。他们快步爬上最后几级台阶。"
    a "再次感谢你，诺亚。我玩得很开心。明天见？"
    no "没什么，真的...对，明天见。"
    "诺亚的声音很小，很羞怯。他的内心在呼喊着让自己不要这么胆怯，直接问出想问的话。"
    "但不知为何，他仍然在一种前所未有的困难中挣扎着。"
    show noahteen m shy with dis
    no "等等！"
    show august m sho with dis
    a "...?"
    no "呃，我...呃...我只是想知道，你能不能，你知道的..."
    no "...我能要你的电话号码吗？"
    a "....."
    nothought "该死。"
    show august m hapblu with dis
    a "当然可以！我其实也想要你的号码，但忘记了。"
    "他们掏出手机，诺亚无视了手机上越来越多的未接来电，然后交换了号码。"
    "诺亚盯着手机屏幕上的号码，仿佛不敢相信它们是真的。"
    a "明天见，诺亚。"
    hide noahteen
    hide august
    with dissolve
    "回到家的每一步都像是在云端行走。他紧紧抱着手机，心跳得比平时快得多。"
    nothought "我是不是有什么问题？"
    stop music fadeout 3.0

    scene bg livingroom day
    show noahteen n neu at center
    with Fade(1.0, 1.0, 1.0)
    m "诺亚！你到底去哪里了？！"
    play music shift fadein 3.0
    show noahteen n sca with dis
    nothought "该死。"
    no "...我得去商店买一本新的练习册。我已经用完上一本了。"
    "他母亲紧紧抓着项链，指节都发白了。"
    m "........"
    m "那你应该告诉我。你知道你的新家教今天要来。"
    no "对不起，妈妈。"
    show noahteen n sur with dis
    "一个男人从沙发上站了起来，这个男人诺亚一眼就认出来了。"

    show noahteen at slightleft with move
    show mf n sur at slightright with dissolve
    no "弗洛伊德先生？！"
    mrf "嗨，诺亚。抱歉，这可能让你感到意外....我以为你知道。"
    "他尴尬地揉着后颈，目光飘向诺亚的母亲。"
    no "不，我当然不知道！为什么没有人告诉我？"
    m "亲爱的，不要在客人面前让我难堂。回你的房间去学习，好吗？"
    show mf n neu with dis
    mrf "我们就在今晚好好商量一下我将帮你做些什么。听起来怎么样？"
    show noahteen n sho with dis
    no "...好的。"
    m "我稍后会给你送些点心。诺亚，请务必集中注意力，不要浪费弗洛伊德先生的时间，明白吗？"
    show noahteen n sad with dis
    no ".........."
    no "嗯嗯，知道了。"

    scene bg bedroom night with Fade(1.0, 1.0, 1.0)
    "诺亚为老师打开门，等他进去后就重重地关上了。他母亲以后可能会因此责骂他，但此时此刻他并不在乎。"
    "叹了口气，诺亚坐在桌子一侧的地板上，而弗洛伊德先生坐在另一侧。"
    "片刻之后，寂静降临，然后弗洛伊德先生再次开口。"
    show noahteen m sad at slightleft
    show bg bedroom night:
        xpos 0.26 ypos 1.12 xanchor 0.5 yanchor 1.0 zoom 2.03
    show mf m sur at slightright
    with dissolve
    mrf "对不起，诺亚，我真的以为你知道。总之，这可以很随意，我在这里不是你的老师。"
    no "你还是我的老师。"
    mrf "好吧，我确实是，但这还是不一样！"
    show noahteen m hap with dis
    "诺亚忍不住对他的慌乱露出了微笑，一声轻笑从嘴里溢出，他终于放松下来。"
    no "好吧。我可以叫你的名字吗？"
    show mf m smi with dis
    mrf "哇，我们别这么急。"
    "弗洛伊德先生拿出了一个笔记本和铅笔。"
    show mf m neu with dis
    mrf "我通常会问你在哪里遇到困难，但我们都知道你没有任何困难，我也不确定你为什么需要一个家教。"
    no "如果我没有家教，我妈妈可能会爆炸。"
    mrf "原来如此...那么为什么我不教你一些更高级的科目呢？它们对你上大学很有用。"
    "诺亚瞥了一眼他的艺术书。"
    show noahteen m neu with dis
    no "...听起来不错。"
    mrf "那么有什么特别感兴趣的话题吗？还是你想让我来决定？"
    "诺亚耸了耸肩。"
    show mf m smi with dis
    mrf "好的，我们首先可以从数学和科学开始，明天我会制定一个合适的学习计划。怎么样？"
    no "好的。"
    no "或者我们可以看电影或玩游戏？"
    mrf "当然，如果你想让我被解雇。"
    no "那就最好别，不然我又会被分配一个烦人的家教，就像上次一样。"
    show mf m neu with dis
    mrf "烦人？"

    show noahteen m hap with dis
    no "他自己的问题都回答错了，不喜欢我纠正他，然后就哭着告诉我妈妈然后辞职了。"
    mrf "我都快佩服了。"
    show mf m smi with dis
    mrf "那我们来玩个游戏吧？如果你能抓到我犯错的地方，那节课就可以玩游戏代替学习。"
    no "好啊。"
    hide noahteen
    hide placeholdersprite
    $all_moves(camera_check_points={u'z': [(-300, 0, u'linear')]})
    scene bg bedroom night:
        subpixel True xpos 0.26 ypos 1.12 xanchor 0.5 yanchor 1.0 zoom 2.03 rotate None
        parallel:
            xpos 0.88
            linear 30.0 xpos 0.1
    with dissolve

    "尽管诺亚努力尝试，但整个晚上他都没能在任何方面超越他的老师。"
    "诺亚一直很聪明，但弗洛伊德先生对他所教的东西了如指掌，就像是第二天性一样。"
    "当他终于完成了最后一个问题时，从稍微打开的窗户吹进来一阵微风。"
    show noahteen m neu at slightleft
    show bg bedroom night:
        xpos 0.26 ypos 1.12 xanchor 0.5 yanchor 1.0 zoom 2.03
    show mf m smi at slightright
    with dissolve
    mrf "今天做得很好。诺亚，你真的很有前途，你是个聪明的孩子。"
    show noahteen m pou with dis
    no "天啊，你难道从来不犯错吗？"
    mrf "我犯过很多错误。我相信将来也会继续犯错。"
    mrf "不过要抓到我犯错可不容易。"
    "弗洛伊德先生眨了眨眼睛，同时合上了教科书。"
    no "但你这么聪明，为什么会成为一名老师呢？"
    mrf "什么，当老师就不够好吗？"
    no "呃...我不是那个意思-"
    mrf "我在开玩笑，我在开玩笑。"
    show mf m neu with dis
    mrf "有个对我很重要的人告诉我我会很擅长这个。我年轻的时候没有什么特别想做的，所以就听从了他们的建议。"
    mrf "结果发现我真的很喜欢这份工作。"
    show noahteen m hap with dis
    no "女朋友吗？"
    mrf "差不多吧。"
    mrf "总之，时间不早了。我们明天再继续-怎么样？"
    no "我不知道\'好\'不好，但是-"
    show mf m smi with dis
    "弗洛伊德先生大笑出声。"
    mrf "我从没意识到你是个这么麻烦的孩子。"
    "他站起身，拿起自己的包，然后对诺亚微笑。"
    stop music fadeout 4.0
    no "我送你到门口吧。"

    scene bg livingroom night with Fade(1.0, 1.0, 1.0)
    m "已经完了？"
    play music moment fadein 3.0
    noteen pou "都9点了..."
    mrf smi "你应该为你的儿子感到非常自豪。他头脑清晰。"
    noteen poublu "嗯..."
    m "我当然为他感到自豪！他是我的骄傲和喜悦！"
    noteen sad "......"
    mrf "明天见，诺亚。今天做得很好。"
    "他随意挥了挥手，离开了房子。"
    noteen "我要去睡觉了。晚安。"
    m "晚安。哦，诺亚，你哥哥很快就要从学校旅行回来了。"
    noteen sad "...好的。"


    scene bg bedroom night with Fade(1.0, 1.0, 1.0)
    "房间已经很黑了。不知为什么，这是诺亚最喜欢的时候。"
    "这个时候，没有人会打扰他，质问他，或者对他大吼大叫。他可以独自思考。"
    "而今天，他的思绪特别混乱。"
    "通常他会利用这个机会画画，但不知为什么，他无法集中注意力。"
    "无法让自己的铅笔落在纸上。"
    "这对他来说是很奇怪的情况。在其他任何时候，这都是他发泄情绪，让自己感觉好一点的方式。"
    "但今晚他的思绪一团乱麻，无法理清。"
    "他解锁手机，盯着通讯录。奥古斯特的名字从其他所有人中脱颖而出。"
    "他的手指悬停在消息按钮上，但他无法按下它。"
    "叹了口气，他的手又落回到床上。"
    "在窗外，雨水噼里啪啦地落到地面上。他闭上眼睛，听着那声音，然后又拿起手机。"
    "首先，他搜索了一个短语。"
    "为什么我会对某人感到紧张？\'"
    "答案并不确切。"
    nothought "更具体一些..."
    "为什么当我看到他时，我会感到既恶心又兴奋？\'"
    "在搜索结果页上，有一个特定的词引起了他的注意。"
    "这个词让他眨了眨眼，既感到惊讶又感到认同。"
    stop music fadeout 3.0
    "在睡着之前，他搜索了一个最后的短语..."
    "喜欢一个人是什么感觉？\'"

    scene bg classroom day with Fade(1.0, 1.0, 1.0)
    play music herehecomes fadein 4.0
    mrf smi "我现在要把你们的模拟考试卷发回去了。我为你们取得的进步感到非常自豪...无论是在学业上还是其他方面。"
    mrf "你们也应该为自己感到自豪！"
    "弗洛伊德先生在桌子之间走动，把批改好的考试卷面朝下放下。"
    "不知为什么，诺亚感到很紧张。"
    "他通常不会对这种事感到紧张。毕竟，他一直都做得很好。"
    "但是让新的辅导员和老师都感到满意，让他的肚子里开始有蝴蝶飞舞。"
    "弗洛伊德先生的脚步声在安静的教室里回响。诺亚看着那些已经收到成绩的人的脸。"
    "有些人看起来很高兴，有些人看起来很失望。"
    nothought "我想知道我的脸会是什么样子在他们眼中..."
    "弗洛伊德先生的脚步声停在了诺亚的桌子前。当他抬头与老师的眼神相遇时，老师朝他眨了眨眼，然后把试卷放下，继续在教室里走动。"
    "深吸一口气，诺亚翻过了试卷。"
    "98."
    nothought "我...得了98分？这...比平常高得多..."
    mrf "应该是所有人了。给自己一个掌声，好好放松一下周末吧。你们都应该得到这个。"

    scene bg classroom day:
        xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.71
    show kaineteen m hap at slightleft
    show noahteen m neu at slightright
    with dissolve
    "就在他讲完课的时候，铃声响了。凯恩快步走到诺亚身边，脸上挂着灿烂的笑容。"
    kteen "快说，你考得怎么样？"
    noteen "不行，你先给我看。"
    kteen "哼，没问题。看看这个。"
    "带着\'试试看能不能超过我\'的笑容，凯恩重重地把模拟考试卷扔到诺亚的桌子上。红笔圈出的成绩是94分。"
    show noahteen m sur with dis
    noteen "哇，太棒了。"
    kteen "没关系，你不用嫉妒的。"
    show noahteen m hap with dis
    noteen "哦，我没有。"
    "带着相似的笑容，诺亚把自己的试卷推向凯恩。"
    show kaineteen m sur with dis
    kteen "{i}什么？！{/i}"
    kteen "弗洛伊德先生一定是弄错了。弗洛伊德先生，请回来！"
    "凯恩假装要追赶他们的老师，而老师只是笑着挥手让他走开，忙着收拾自己的东西。"
    show noahteen m poublu with dis
    noteen "还给我！"
    kteen "你怎么可能考到98分？"

    show kaineteen at left
    show noahteen at right
    with move
    show august m sur glasses at center with dissolve
    a "98分？诺亚，这太棒了！"
    "在这一片喧闹中，奥古斯特悄悄地走了过来，脸上带着惊讶的表情。当他出现时，凯恩稍微紧张了一些。"
    show noahteen m shy with dis
    noteen "哦，呃...谢谢。"
    kteen "他可能是作弊的。"
    show noahteen m ang with dis
    noteen "我没有！"
    noteen "只是我有了一个新的辅导员！"
    a "哦！我记得你提到过。他一定很厉害。"
    show noahteen m neublu with dis
    noteen "...是的，他很厉害。"
    kteen "我不敢相信...我的连胜记录被毁了..."
    show noahteen m hap with dis
    no "闭嘴吧。之前你能赢我只是因为我不在乎。"
    show kaineteen m sad with dis
    k "呜呜呜..."
    no "别大声说\'呜呜呜\'。那听起来太蠢了。"
    show kaineteen m hap
    show august m hap
    with dis
    "凯恩和诺亚都笑了。"
    a "我们应该庆祝一下！"
    show noahteen m neublu with dis
    no "你不用这样...这也不算什么大事。"
    a "我想庆祝！98分真的很了不起！你应该为自己感到自豪。"
    no "你考得怎么样？"
    a "嗯..."
    a "我得了75分。不如你们两个。"
    no "...但那也很了不起了，你知道吗。你...真的很了不起。"
    show kaineteen m pou with dis
    k "......."
    show kaineteen m hap with dis
    k "咳...你们两个这个周末要不要来我家玩？我有新的游戏。"
    show august m sho with dis
    "奥古斯特眨了眨眼睛，显然感到很惊讶。"
    a "我？"
    k "嗯，是的，庆祝是你的主意。"
    a "我只是以为你..."
    show august m hap with dis
    a "...是的，我觉得那会很有趣。"
    show noahteen m hap with dis
    no "...好吧，我们就这么做吧。"
    show august m shy with dis
    a "....."
    a "实际上，呃..."
    "出人意料的是，奥古斯特有些结巴，好像对他即将要问的事有些紧张，但他很快就摆脱了这种情绪，恢复了往常的自信。"
    a "你们为什么不来我家？我爸爸一直让我把朋友介绍给他。"
    show noahteen m sho with dis
    no "............"
    nothought "奥古斯特的...家？"
    nothought "奥古斯特的...卧室...？"
    k "对我来说没问题。诺亚呢？"
    nothought "在奥古斯特家，在奥古斯特的卧室过夜...？"
    k "诺亚，回到现实来。嘿，别发呆了。"
    show august m hap with dis
    a "如果你不想去也没关系。"
    show noahteen m neublu with dis
    no "不，我想去！我真的很想去！"
    show kaineteen m neu with dis
    k "........"
    no "总之，我现在得回家了，我的...家庭教师又要来了。"
    k "总有一天你会有时间再来玩的。"
    no "是啊，随便吧。"
    a "那我们一起回家吧。我今天没别的事做。"
    "当三人走向门口时，弗洛伊德先生喊道。"
    mrf smi "干得好，诺亚。待会见。"
    "诺亚回应以微笑和挥手。"
    show noahteen m hap with dis
    #stop music fadeout 3.0
    no "待会见！"

    scene bg town day:
        xpos 0.87 ypos 1.26 xanchor 0.5 yanchor 1.0 zoom 1.75
    show kaineteen n sur at slightright
    show noahteen n neu at slightleft
    show august n neu glasses at center
    with Fade(1.0, 1.0, 1.0)
    k "那是怎么回事？"
    no "什么怎么回事？"
    show kaineteen n hap with dis
    k "{i}待会见！{/i}"
    no "哦，弗洛伊德先生是我的家庭教师。"
    k "啊，原来如此...事情开始有意思了..."
    show noahteen n pou with dis
    no "你什么意思？"
    "凯恩耸了耸肩。"
    k "我只是说，你的高分开始有道理了。因为你们两个是朋友。"
    no "闭嘴吧。那是我自己赢得的。你只是嫉妒而已。"
    no "反正他比我之前的家庭教师强多了。"
    show august n sho with dis
    a "我好像从来没有家庭教师。我还以为那只存在于电影里。"
    show kaineteen n pou with dis
    k "那你算是幸运了。我从七岁开始就一直有家庭教师了。"
    a "哇..."
    no "我换过几个..."
    show noahteen n neublu with dis
    no "呃...如果你需要帮助的话，我可以当你的家庭教师...如果你愿意的话。"
    show kaineteen n hap with dis
    k "你当家庭教师？我看你的98分已经上头了。"
    show noahteen n poublu with dis
    no "闭嘴..."
    show august n hapblu with dis
    a "谢谢你，诺亚。我想我会接受你的提议。考试上有几个地方我不太懂。"
    show noahteen n neublu with dis
    no "...没问题。"
    show kaineteen n neu with dis
    k "顺便说一句，我听说你哥哥快回来了。"
    show noahteen n sca with dis
    no "天啊，别提了..."
    show august n pou with dis
    a "你有个哥哥？"
    no "是的...他比我大一点。"
    show august n sad with dis
    a "看起来你们相处得不太好。"
    no "他是家里的宠儿，而我是失败者。"
    show august n sur with dis
    a "失败者？别说傻话。"
    a "你成绩一直很好。老师都很喜欢你。你的艺术天赋也很出色..."
    no "他从高中开始就每科都考100分，还当过两个运动队的队长，还当过学生会主席..."
    show noahteen n neu with dis
    no "你怎么知道这些的？"
    k "前几天你妈妈和我妈妈聊天的时候，我从她那里听到的。"
    show noahteen n sad with dis
    no "当然，她一定是要炫耀一下她最喜欢的孩子要回来了。让我在他走之前在你家住几个星期吧。"
    show kaineteen n sad with dis
    k "尽管你妈妈很喜欢我，但如果我们这么做，我想她肯定会杀了我们两个。"
    no "我妈妈比我妈妈还喜欢你。我相信你要求她任何事她都会答应。"
    show august n neu with dis
    a "你随时都可以来我家住。"
    show noahteen n sho with dis
    no "真的吗？"
    show kaineteen n sad with dis
    k "嘿-"
    show noahteen n shy with dis
    no "我不想打扰你..."
    show august n hap with dis
    a "你从来不会是个麻烦，你随时都受欢迎来我家。"
    no "谢谢..."
    "不久之后，他们就到家了，诺亚感到很失望。"
    nothought "我想和他多待一会儿...要是今晚没有补习就好了..."
    stop music fadeout 3.0
    nothought "呃，虽然我们已经在同一个班级待了一段时间了，但感觉我们几乎没有机会在一起玩耍..."

    scene bg livingroom day with Fade(1.0, 1.0, 1.0)

    "怀着这样的想法，他做好了迎接等待他的事物的准备。"
    "在他甚至还没有走进门之前，他就能听到他们的声音。他们没有把话语保持在低声下气的语调，而是决定即使有人偶然听到，他们也不在乎。"
    m "我觉得这个新的家教很适合他。"
    play music sunset fadein 5.0
    f "如果他能说服他最终放弃那种女孩子的爱好，那我就不在乎是谁了。"
    m "也许他的哥哥也能给他一些启发。"
    show noahteen n neu at center with dissolve
    no "我回来了。"
    "他有意打断了他们的谈话，即使他们的话语深深地刺痛了他，他也选择忽视。"
    nothought "画画有什么不对吗？"
    no "我有东西要给你看。给你。"
    "诺亚从包里掏出试卷，递给了他的母亲，她惊讶地倒吸了一口气。"
    m "诺亚...！你是不是抄袭了别人的试卷？！"
    show noahteen n sho with dis
    no "什么？不是。"
    f "你是不是作弊了？"
    show noahteen n sad with dis
    no "不是..."
    m "这真的是你的？"
    no "是啊...？"
    f "不错嘛...几乎和艾许一样好。"
    no "........"
    no "好的。我下次会努力的。"
    m "别担心，亲爱的，他下次一定会做得更好。"
    "在无声的叹息中，诺亚感到自己的精神状态低落了下来。他把试卷收回到背包里。"
    no "...我要去我房间里等家教老师了。"
    m "好孩子。我稍后会给你送些零食过去。"

    scene bg bedroom day with Fade(1.0, 1.0, 1.0)

    "与其为家教做准备，诺亚发现自己从书架上取下了旧的素描本。"
    "他的眼睛在页面上游移，看着过去几年里他倾注了全部心血的一切。"

    show bg bedroom day:
        xpos 0.38 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.42
    show noahteen n sad at center
    with dissolve
    nothought "...我想我只是很糟糕。为什么我永远都不够好？"
    nothought "...至少奥古斯特觉得这很酷..."
    "大约第一百次，诺亚盯着手机上奥古斯特的联系方式，但最终还是决定不给他发短信。"
    stop music fadeout 3.0
    nothought "反正我也没什么可说的..."
    show noahteen at slightleft with move
    show mf n smi at slightright with dissolve
    mrf "我来了！诺亚，你应该为自己最近的那次考试感到自豪。你一直都很出色...不，是非常出色，而且你已经进步得更远了。"
    play music unsaid fadein 4.0
    no"多亏了你。"
    "弗洛伊德先生关上门，摇了摇头。"
    mrf "不，这是因为你付出了努力。"
    "他把教科书放在桌子上，然后瞥了一眼诺亚手里的素描本。"
    show mf n neu with dis
    mrf "这是什么？"
    no "哦...没什么..."
    mrf "这是你的艺术作品吗？"
    "诺亚做好了准备。"
    "他等待着从每一个家教那里听到的同样的话语，就像是有着严格剧本的机器人。"
    "这些剧本，从某种程度上来说，也来自他的父母...每一次都是如此。"
    "{i}{b}你应该放弃那个。那只是浪费时间。你应该专心学习。{/b}{/i}"
    show mf n smi with dis
    mrf "...你有这么多才能。我都不知道你会画画。"

    show noahteen n sho with dis
    no "......?"
    no "你...不会让我停下来吗？"

    show mf n sur with dis
    mrf "当然不会！"
    show mf n smi with dis

    "他笑着坐了下来。"

    mrf "但与你不同，我连一个简单的小人都画不好，所以在这方面我帮不了你什么忙。我们现在开始吧，我能帮你的是什么？"

    "诺亚感到心中有一种从未有过的轻松。"
    nothought "他...站在我这边...？"
    "弗洛伊德先生打开了其中一本数学教科书，等待诺亚加入他。"
    show noahteen n neu with dis
    "他坐在桌子的另一边，拿出了练习册。方程式和计算就像一种陌生的语言，印在页面上。"

    mrf "我想我们现在可以转到新的科目了。你已经掌握了我之前教过的内容。"

    "诺亚点了点头，但他的眼睛又回到了手机上。"
    nothought "我以为他现在应该已经给我发消息了...也许他不想..."
    nothought "或者他想让我先发消息...？"
    show noahteen n sad with dis
    nothought "或者...也许他只是没什么可说的。毕竟我们并不太亲密，每天在学校里也能见到面。"
    nothought "或许..."

    show mf n neu with dis
    mrf "诺亚？"
    nothought "也许他其实不想给我他的号码，而我让他感到不自在了？"
    nothought "互相发消息会不会太奇怪了？"
    mrf "喂，诺亚，你在听吗？"
    "弗洛伊德先生在诺亚面前挥了挥手，把他从思绪中拉了回来。"
    show noahteen n sho with dis
    no "哦...对不起，我在听。"
    mrf "你当然不在听。"
    "他的导师合上了教科书，认真地看着他。"
    mrf "你在想什么？"
    no "对不起，弗洛伊德先生，我现在会集中注意力的。"
    "诺亚伸手想把教科书翻回到老师正在讲的那一页。"
    "但不幸的是，弗洛伊德先生比他反应更快。他温和地把手放在书上，阻止了诺亚打开它，然后摇了摇头。"
    mrf"有些事比功课更重要。"
    mrf"很多事都是如此。"
    show mf n smi with dis
    mrf"不要告诉别人我对你说过这话。否则没人会再做作业了。"
    show noahteen n sad with dis
    no "........"
    nothought "真的可以吗？...他会觉得我很奇怪的，对吧？"
    nothought "但是...我觉得我可以信任他..."
    no "嗯..."
    no "实际上，我一直在想一件事。不过我不想让你笑话我。"
    mrf "说吧，我不会笑的。"
    no "........"
    show noahteen n neublu with dis
    no "喜欢一个人是什么感觉？"
    show mf n neu with dis
    mrf "喜欢一个人？"
    no "就是...你知道的，喜欢一个人。就像...爱情什么的..."
    show mf n smi with dis
    "弗洛伊德先生确实笑了一秒钟，然后注意到诺亚脸上认真的表情。"
    show mf n sur with dis
    mrf "好吧，你是认真的..."
    mrf "你是个健康的青少年男孩...我以为你早就知道这个了。"
    show mf n neu with dis
    mrf "呃，让我想想...我可没准备好回答这个问题..."
    "他尴尬地清了清嗓子。"
    show mf n emb with dis
    mrf "所以，呃，你是说从身体上来说吗？"
    no "是的。你是怎么知道的？"
    mrf "让我回想一下当年的自己...我想我以前对我喜欢的人会感到很尴尬。有蝴蝶在肚子里飞，想和他们说话，盯着他们看..."
    mrf "回想起来，这听起来有点变态..."
    mrf "...是班上的某个人吗？你不用告诉我。"
    "诺亚无声地点了点头。"
    mrf "索菲亚？还是亚丽亚？"
    no "..............."
    no "呃...喜欢一个和我一样的人，这样做...有错吗？"
    show mf n neu with dis
    mrf "和你一样的人？"
    stop music fadeout 3.0
    show noahteen n sad with dis
    no "是奥古斯特。"
    show mf n sur with dis
    "他突然的回答后，一片沉默。"
    mrf "......"
    "他眨了眨眼，对诺亚的回答感到惊讶。"
    show mf n neu with dis
    play music uplifting fadein 5.0
    mrf "...当然没有错。"
    show noahteen n sho with dis
    no "真的吗？"
    mrf "是的。你不用担心。"
    "一种温暖的感觉在诺亚的胸膛里蔓延开来。被认可了。"
    nothought "没关系。我很好。我很正常。"
    show mf n smi with dis
    mrf "这一直在困扰你，对吧？别担心，我不会告诉任何人的。"
    "弗洛伊德先生自然地重新打开了教科书，转回到课程中。"
    mrf "那么，我们刚才讲到哪里了..."
    show noahteen n neu with dis
    "诺亚拿起铅笔认真地听着，他的思绪突然像窗外渐渐变成温和橙色的天空一样清晰。"

    mrf "对，高等微积分。每个人最喜欢的科目。"
    mrf "你很快就会掌握的。"
    no "你怎么记得这么多？"
    mrf "你会相信我如果我说我是因为太喜欢数学，所以在空闲时间都在学习它吗？"
    no "呕。"
    mrf "连老师也不会那么痴迷。除了也许是米斯—"
    show mf n sho with dis
    mrf "等等，我不应该说这个。我真的不应该说这个。"
    show noahteen n hap with dis
    no "来吧，现在我很好奇了。"
    mrf "我会保密的。"
    show noahteen n pou with dis
    no "好吧。那你是怎么记住这些的？"
    show mf n neu with dis
    mrf "事实上，我并不是全部都记得。我觉得不管学什么，这都是一样的。你学会了，然后忘记了，再重新学习..."
    no "听起来太无聊了。谁会想一遍又一遍地重新学习一些自己不感兴趣的东西，只为了教给别人呢？"
    mrf "我想是我吧。能够传授知识让人感到很满足。"
    mrf "也许有一天你会明白的。"
    show noahteen n sca with dis
    no "我会是一个糟糕的老师。"
    show mf n smi with dis
    mrf "那么就当艺术老师吧？"
    show noahteen n poublu with dis
    no "不...我还远远不够好。"
    mrf "我很不同意，但不管你是否想这么做，我都能看出你在艺术上会有很大成就。继续努力，好吗？"
    "弗洛伊德先生一边愉快地聊天，一边在诺亚的练习册上圈出一个公式。"
    nothought "他能同时做高等微积分和闲聊，真是了不起。"
    show noahteen n neu with dis
    no "你有喜欢的人吗？"
    show mf n sur with dis
    mrf "什么？你从哪里想到的？"
    no "我只是好奇。你不是说有个特别的人告诉你要当老师吗？"
    mrf "原来你在上课的时候还是有在听的。我还以为你一直在桌子上敲敲打打。"
    show noahteen n pou with dis
    no "嗯..."
    show mf n sad with dis
    mrf "...我是的。"
    show noahteen n neu with dis
    no "你是？"
    mrf "啊——"
    mrf "那个人已经不在了。从那之后我就没太对谁感兴趣过。"
    show noahteen n sad with dis
    no "哦...我很抱歉..."
    show mf n sho with dis
    mrf "什么？"
    mrf "哦，不是-"
    mrf "他们没死，只是结婚了。"
    show mf n sad with dis
    mrf "我去参加了他们的婚礼，真的很漂亮。不过我想我还是有点伤心。"
    show noahteen n neu with dis
    no "你有没有试过电影里那种做法？"
    show mf n sho with dis
    mrf "反对？！我宁愿死也不会真的这么做。"
    mrf "这又是另一个教训。在机会消失之前要敢于尝试冒险的做法。"
    no "至少她的婚纱很漂亮吧？"
    show mf n sad with dis
    mrf "....."
    mrf "他看起来比以前更幸福了..."
    mrf "对了，她的婚纱也很漂亮。"
    no "...?"

    scene bg bedroom night with Fade(1.0, 1.0, 1.0)
    "不知不觉中，太阳已经沉到了地平线深处，只有月光从房间后面的大窗户里照进来。"
    "弗洛伊德先生叹了口气，合上了课本，望着窗外，好像在等待着有人神奇地出现。"
    "但没有人出现，他转过身面对诺亚。"
    mrf neu "今天就到这里吧，不过我们好像聊得比学习还多。"
    mrf smi "别告诉别人，好吗？我需要这笔额外的钱。"
    noteen hap "我就知道你不是出于善意才来的。"
    "弗洛伊德先生笑了起来，诺亚也跟着笑了，两个人一起走向门口。"


    scene bg livingroom night with Fade(1.0, 1.0, 1.0)
    mrf smi "今天做得很好，诺亚。明天见。"
    m "看来你们终于完事了。很好。"
    m "我有话要跟你说，可以吗？"
    mrf neu "当然可以，女士。"
    stop music fadeout 3.0
    m "诺亚，你可以回房间了。"
    noteen sho "...？为什么？"
    m "成年人需要谈谈。快去吧。"
    noteen sad "好的。晚安。明天见，弗洛伊德先生。"



    scene bg bedroom night with Fade(1.0, 1.0, 1.0)
    "诺亚悄悄关上了门，试图忽略母亲那种漠视的态度。在桌子上还摆着辅导课的各种书籍。"
    "但他的思绪并不在学习上。"
    play music moment fadein 4.0
    nothought "他说这没关系...我喜欢...奥古斯特。"
    nothought "对，我喜欢他。就是这样。"

    show bg bedroom night with dissolve:
        xpos 0.77 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.62
    "诺亚躺在被子里，闭上了眼睛。门外传来低声交谈的声音，但他听不清具体在说什么。"
    "不过不管他们在谈什么，此时此刻对他来说都无关紧要。重要的是，他终于被接纳了。"
    "终于找到了自己的位置。"
    stop music fadeout 3.0
    "怀着这样的想法，他闭上了眼睛。"


    scene bg bedroom day with Fade(1.0, 3.0, 1.0)
    "早晨来得太快了。诺亚整夜都在辗转反侧，思考老师的话以及对隔壁男孩的感情。"
    "他刚刚勉强睡着，眼睛就突然睁开了。不知为什么，外面照进来的阳光今天格外明亮。"
    play music thiscloud fadein 4.0
    "这可不是个好兆头。"
    "诺亚伸手去拿手机，打开一看，时间已经是早上8：25了。"
    nothought "什么...我的闹钟怎么没响！铃声马上就要响了...！"
    "两分钟后，他已经穿戴整齐，准备出门。他快速在镜子前整理了一下头发，就几乎是飞奔出了门。"

    scene bg livingroom day
    show noahteen n sur
    with Fade(1.0, 1.0, 1.0)
    no "妈，你为什么不叫我起床-"
    "厨房和客厅里一个人也没有。通常这个时候至少他的母亲还会在家，但现在看来她不在。"
    show noahteen n ang with dis
    no "啊..."
    "没时间再浪费在她们去哪里上，诺亚从门边拿起背包，穿上鞋子，就冲了出去。"

    scene bg mountains day with Fade(1.0, 1.0, 1.0)
    "匆忙中，诺亚绕过房子，沿着通往山下的那条长满杂草但很熟悉的小路跑了下去。"
    show noahteen n sca with dissolve
    nothought "如果我逃跑，我就不会太晚了...我希望..."
    "通常，他要么等着奥古斯特和凯恩，要么看到他们已经在等他了。这次，他没有料到会看到他们中的任何一个。"
    show noahteen n sho with dis
    "也许这就是为什么当前面树叶中闪耀着一缕金发时，他停下了脚步。"
    nothought "等等...奥古斯特...？！"
    nothought "我不是...天啊，我还没准备好见到他..."
    nothought "我应该回头走吗？"
    nothought "呃，但是他一直在等我..."
    a sur "诺亚？"
    "一个声音从绿叶后面传来。绿色的眼睛几乎与之相匹配，先是惊讶，然后是快乐。"
    show noahteen at slightleft with move
    show august n hap glasses at slightright with dissolve
    a "诺亚，是你！"
    no "你...你在这里做什么...？"
    a "我在等你，这样我们就可以一起去上学。"
    no "但是...但是现在你要迟到了！"

    a "我不介意稍微迟到一点。"
    no "如果我生病了或者今天不去呢？"
    a "嗯，我正在考虑去敲你的门，但我不想让你着急。"
    show noahteen n neublu with dis
    no "....."
    no "谢谢..."
    no "凯恩没有等你吗？"
    show august n sho with dis
    a "哦，他想亲自把你从床上拽出来，但他说他父亲今天让他不要迟到，不知道为什么。"
    nothought "真奇怪。"
    show august n neu with dis
    "肩并肩，两人开始加快下山的脚步，小心翼翼地不让自己滑倒。"
    "在那一刻，上学迟到已经是最不重要的事情了。"
    "诺亚的所有感官都被奥古斯特占据了。他的眼睛，充满了奥古斯特的面容，就像阳光洒在一片花丛上。他的鼻子，充满了奥古斯特洗发水的味道，仍然飘散在他略微潮湿的头发上。"
    "他的耳朵，过于敏感地感知到了奥古斯特的呼吸声、脚步声和脚下滚落的石块声。"
    "每次他们的肩膀擦过，诺亚都想尽快逃离。"
    "五感中唯一缺失的就是味道。"

    nothought "味道..一种..."
    show noahteen n shy with dis
    nothought "天啊，我在想什么..."
    "诺亚感到脸颊发烫。他从未在生命中如此想过另一个人，现在突然间这似乎是他唯一能想到的。"
    a "你睡过头了吗？"

    show noahteen n sho with dis
    no "啊？！"
    "当奥古斯特开口说话时，诺亚差点跳了起来。"
    no "哦，我，呃..."
    show noahteen n sad with dis
    no "我睡得不太好。我想我也忘了设闹钟。"
    a "我讨厌这种事情发生。"
    no "通常我妈妈会在我睡过头的时候叫我起床，但今天早上她不在家。"
    "奥古斯特拿出手机查看时间。"
    a "看起来我们也不会太迟到。"
    a "不过既然已经迟到了，我们干脆逃课去玩吧。"
    show noahteen n sho with dis
    no ".........."
    show august n hap with dis
    a "我在开玩笑，我在开玩笑！"
    show noahteen n shy with dis
    nothought "哦。"
    no "...对我来说这听起来也不坏..."

    a "我想我爸爸要哭了，如果我逃课的话。"
    no "真的吗？"
    a "是的。他就是这样的人。"
    "前方，绿色的景色渐渐让位于混凝土。不知为什么，这让诺亚感到一种悲伤。"
    "在这里，只有他们两个人，这是一个别人无法触及、无法破坏的地方。但在外面，世界还在继续。"
    no "我希望我们能就这样待在这里。"
    a "嗯？"
    show noahteen n sho with dis
    no "没、没什么！没事的。来吧，我们应该快点了！"

    scene bg town day with Fade(1.0, 1.0, 1.0)
    pause 2.0
    scene bg classroom day with Fade(1.0, 1.0, 1.0)

    "两个男孩跑进校门。一个看守校门的老师只是摇了摇头，看着他们走进去。"
    noteen sad "天啊，他们现在一定会觉得我是个坏影响..."

    a hap "被你影响也不算太坏！"
    stop music fadeout 3.0
    p "咳咳。"
    "两个人一边聊天一边走进教室，差点忘记自己迟到了。"
    "教室里一片寂静，所有的目光都集中在这两个男孩身上。"
    play music sunset fadein 4.0
    p "你，去坐下。"
    a sur "我？"
    p "是的，你。"
    a "...好的。"

    "奥古斯特独自走到座位上，留下诺亚尴尬地站在门口。"
    "坐在前排桌子上的不是他们的老师，而是校长。"
    p "诺亚，我猜对了吧？"
    noteen sho "呃，是的。我很抱歉我们迟到了，这都是我的错——"
    p "我们稍后再处理你的迟到问题。现在，请跟我来。"
    "诺亚站稳了脚跟。"
    noteen sad"为什么？"
    p "我以为你的父母已经和你谈过了..."
    noteen sad"......"
    "当诺亚没有动弹时，校长只是叹了口气，耸了耸肩，然后再次开口。"
    p "从今天开始，你要换班了。"
    noteen sur "什么？！为什么？！"
    p "因为你的父母要求这样做。好了，别在这里闹场面了。"
    noteen "但是...但是..."
    p "从今天开始，你会在3-1班上课。来吧，我给你介绍一下。"
    p "同学们，弗洛伊德先生很快就会到。在他到来之前，请自习。"

    scene bg school corridor with Fade(1.0, 1.0, 1.0)


    noteen sad "先生，我觉得这里可能有个误会。"
    p "你就是诺亚，对吗？"
    noteen "是的..."
    p "你的父母要求——不，应该说是要求更恰当。"
    p "他们要求你立即调班。你母亲今天早上亲自来过。"
    p "为什么你没有被告知，我也不知道。"
    "诺亚感到自己泄了气。"
    nothought "是妈妈做的这件事...？为什么？"
    noteen "我...我真的要换班吗？"
    p "很遗憾，我无能为力。你的家人是主要的赞助商——"
    "不管他之后说了什么，诺亚都无法再继续听下去。"
    nothought "一切都是钱的问题，不是吗？有足够的钱，你就可以随意破坏别人的生活。"
    nothought "我恨她。我恨他们。"
    "两人在一扇与上一个教室一模一样的门前停下，然后走了进去。"

    scene bg classroom day with Fade(1.0, 1.0, 1.0)

    "再次，当他进入教室时，全班的目光都集中在他身上——不过这次，面孔要更陌生一些。"
    "一个留着短橙色头发、眼睛很黑的年轻女子朝他微笑。她很快走到他身边。"
    miss "你一定就是诺亚了。请坐下吧。你可以叫我罗丝小姐。"
    miss "我知道你可能是被迫调到这里的，所以我不会强迫你站在全班面前自我介绍。好吗？"
    noteen sad "好吧..."
    "她微笑着。她的眼神似乎很同情，但诺亚愤怒地移开了视线。"
    noteen "..........."
    "诺亚无声地坐在指定的桌子前，眉头紧锁。"

    nothought "到底发生了什么？！为什么他们要这样对我？！"
    nothought "这太不公平了..."
    nothought "这太不公平了...！"

    miss "........."

    "完成任务后，校长点了点头，离开了教室。"
    "诺亚闭上嘴，合上了作业本，笔也放在一边，没有使用。他凝视着远处的山峰。"
    nothought "我们应该就待在那里。逃课，像你说的那样出去玩。"
    nothought "一切都糟透了。除了你，其他一切都糟透了。"
    "罗丝小姐的声音在背景中响起，但诺亚没有理会。"
    "他的目光从山峰转回到桌子上。他打开作业本，里面整洁地记满了昨天的笔记。"
    "他拿起笔在旁边的页面上狠狠地画了一条线，然后又画了一条，再画一条，在洁白的页面上留下了一片乌黑的墨迹。"
    "不知不觉，午餐铃声响了，教室里只剩下诺亚一个人。"
    noteen sho "...."
    stop music fadeout 3.0
    "他从桌子上跳起来，冲出了教室，寻找着一个特定的人。"

    scene bg school stairs with Fade(1.0, 1.0, 1.0)
    noteen ang "嘿！"
    play music nothing fadein 4.0
    "诺亚终于找到了他。弗洛伊德先生独自走下楼梯，手里紧紧抱着当天的教材。"
    "当诺亚冲下楼梯向他扑过去时，他手里的书和纸张都掉落在地。"
    noteen "到底发生了什么？！"
    mrf sca "......."
    "他无言地弯下身去捡起掉落的物品，但诺亚很快向他走了过去。"
    noteen "我说，到底发生了什么？！为什么我被调班了？！"
    mrf sad "...是你的父母提出的要求。"
    noteen "但为什么？！"
    mrf "...我错了。你不应该听我的建议。"
    noteen "你什么意思？"
    "弗洛伊德先生停顿了一下，脸上流露出矛盾的神情。他的话语缓慢而拖沓，好像在艰难地说出这些话。"
    mrf "...关于奥古斯特的建议，你应该忽略它。"
    noteen sho "所以你是在告诉我，我的感受是错的，是吗？"
    mrf "........"
    mrf sca "对不起，诺亚，但请不要再跟我说话，否则我们俩都会有麻烦。"
    "他收拾好纸张，继续下楼，留下愤怒的诺亚独自一人。"
    noteen ang "该死！"
    show bg with hpunch
    "他不同寻常地猛击墙壁，充满了愤怒。"
    nothought "我只是想和奥古斯特在同一个班级...这太不公平了..."
    kteen sur "诺亚！"
    noteen sad "嗯..."
    kteen "发生什么事了？！今天早上那些事是怎么回事？"
    noteen "很好的问题。今天早上校长把我带到了罗丝小姐的班级，但没有人告诉我发生了什么！"
    noteen  "他们只是一直说...说我的父母让我搬家了...！但为什么？！"
    "凯恩的眉头越皱越深，他平时调皮的表情被一种更加严肃的表情取代了。"
    kteen fro "他们不能这么做。"
    noteen sad "显然他们可以。再一次，他们只是想毁掉我的生活。"
    kteen sad "........."
    kteen "我很抱歉..."
    noteen "...至少他们没有突然把我转到另一所学校。我想情况可能会更糟。"
    kteen "但这仍然不公平。"
    kteen fro "...好吧，那我今天就去坐罗丝小姐的班，反正我们都可以随意调动。"
    noteen "别这样，你只会惹麻烦。"
    kteen "那又怎样？他们能怎么样？"
    noteen "这不值得。我会试着解决这个问题。"
    kteen sad "...你想让我告诉奥古斯特吗？"
    noteen "还不行...也许我能想办法解决这个问题..."
    noteen "我现在要回家了，所以放学后你不用等我了。"
    kteen "这不会让你陷入更多麻烦吗？"
    noteen ang "可能会，但我并不在乎。"
    kteen "好吧...那我明天见。我也会想办法帮忙..."
    "凯恩向诺亚挥了挥手，然后回到了走廊上。充满愤怒的诺亚冲下楼梯，冲出了校门，无视了身后老师的呼唤。"

    scene bg livingroom day with Fade(1.0, 1.0, 1.0)
    noteen ang "到底发生了什么？！"
    m "你为什么这么早回家？课还没下完呢！"
    noteen "你为什么让我转到另一个班级？！"
    m "诺亚，我对你很失望。有很多原因。"
    m "把手机给我，现在。"
    noteen sho "什么？为什么？"
    m "现在。"
    "沮丧的他从包里抓出手机，正好看到屏幕亮了，上面显示的是他一直在等待的那个名字。"
    "奥古斯特。"
    "但为时已晚。她从他手中抢过手机，他还来不及阻止。"
    noteen "等等，让我看看那条短信！"
    "她低头看了看屏幕，然后叹了口气，关掉了手机。"
    m "你不能再拿这个了。从现在开始，你最好只集中精力在学习上。我不想再看到你胡闹。"
    noteen "什么..？"
    m "回家路上不许再有其他停留，绝对不许再和{i}奥古斯特{/i}混在一起。"
    noteen "........"
    nothought "我不...我不明白..."
    noteen ang "你为什么让我转班？！为什么无缘无故地惩罚我？！"
    m "去你的房间。"
    noteen "那我的辅导课呢？"
    m "我们解雇了你的家庭教师。我很快会给你找一个新的。"
    stop music fadeout 4.0
    "眼泪快要溢出，他愤怒地回到房间，重重地关上了门，回响在整个房子里。"

    scene bg bedroom day with Fade(1.0, 1.0, 1.0)
    play music unsaid fadein 4.0
    noteen sad "那个混蛋...他一定把所有的事都告诉她了，对吧..."
    nothought "当他们单独谈话的时候...他把我对他说的所有话都告诉了她...他告诉我我很正常，但他却把一切都告诉了他们...！"
    nothought "我不应该相信他...该死..."
    noteen "他告诉我我很正常..."
    noteen "混蛋..."
    "诺亚倒在床上，把满是泪水的脸埋进满满的枕头里。他甚至没有脱掉鞋子。"
    noteen"这太不公平了..."
    noteen"为什么每个人都想毁掉我的生活..."
    nothought "我只是想和他在同一个班级..."

    scene black with Fade(1.0, 1.0, 1.0)
    "不知何时，他的眼睛开始感到沉重，他陷入了一个终于止住了眼泪的睡眠中。"
    "而世界继续在他身边运转。"
    "凯恩对自己无法帮助感到沮丧，而奥古斯特则在想是否给诺亚发信息太主动了，尤其是在被忽视的情况下。"

    scene bg bedroom night with Fade(1.0, 1.0, 1.0)
    "当诺亚再次睁开眼睛时，房间已经很黑了。"
    "他的眼睛感到很肿，皮肤也很紧绷。他从床上坐起来，打开了一盏台灯。"
    "在房间对面的镜子里，他看到了自己的倒影。"
    nothought "我看起来糟透了..."
    nothought "也许...我应该试试奥古斯特说的那个办法..."
    "他离开房间，手里拿着他母亲的各种产品。"
    nothought "这些到底是干什么的呢...."
    nothought "我想奥古斯特使用这些东西也不足为奇。他的皮肤看起来真的很柔软光滑。我要是摸一摸的话..."
    nothought "我想...感觉应该会很好..."
    "他拿起几个不同大小的瓶子。"
    nothought "爽肤水、洁面乳、精华液、眼霜..."
    nothought "这些都是什么..."
    "最后，他在这堆瓶子中找到了他要找的那个。"
    nothought "清爽型保湿乳...也许这个会有帮助。"
    "尴尬地，他在脸上涂抹着，等待着奇迹的发生。"
    nothought "嗯...我觉得感觉确实清爽了一些。这些东西真是太贵了。"
    "他叹了口气，把瓶子扔到地上，然后倒在床上。"
    nothought "当然，他终于给我发消息了，结果我的手机被她拿走了。当然了。这是我一直在等待的事情。"
    nothought "也许我应该去找他聊聊...不然他会以为我在忽视他。"
    "站起来，他把手放在门把手上，试图转动它。"
    "锁住了。"
    nothought "什么...？我刚刚才离开。"
    nothought "他们是认真的要把我锁在这里吗？"
    nothought "我想在半夜离开可能不是个好主意...但是呼吸点新鲜空气也不错..."
    "想到这里，他拉开窗户，却突然冻住了。"
    "在对面的窗户里，他看到了他。"
    "奥古斯特。"
    "一副耳机戴在他耳朵上，从他紧闭的窗户后传来他轻轻的哼唱声。"
    nothought "他...他的卧室...就在我对面...？我怎么没有注意到？！"
    "他屏住呼吸，仿佛在等待着什么事情的发生，等待着有人再次夺走这一切，但什么也没有发生。"
    "他在房间里寻找着什么可以扔的东西。"
    nothought "铅笔...希望不要伤到他的窗户或者打到他。"
    "砰。砰。砰。"
    "他一个接一个地扔着。不太用力，以免引起他家里人的注意，但他希望能够足够引起奥古斯特的注意。"
    "不久，他看到奥古斯特摘下耳机，朝窗户看了过来。他那双大大的绿眼睛里满是惊讶。"
    "他冲向窗户打开它，一支铅笔从头顶飞过，落进了他的房间。"
    "诺亚迅速从窗户滑了出来，坐在窗台上。奥古斯特也效仿他，做了同样的动作。"


    scene gallery_3 with Fade(1.0, 1.0, 1.0):
        subpixel True xpos 0.4 ypos 1.85 xanchor 0.5 yanchor 1.0 zoom 2.59 rotate None
        parallel:
            xpos 0.9
            easein 25.0 xpos -0.07
    a "诺亚！"
    no "嘘，否则会被人发现的。"
    "他小声回答，把手指放在嘴唇上。奥古斯特会意地点了点头，好像完全明白发生了什么。"
    no "我完全不知道我的卧室就在你对面..."
    "诺亚敢发誓，他看到奥古斯特的脸颊上泛起了一丝粉红。"
    scene gallery_3 with dissolve
    a "...我前几天就注意到了。我以为你已经知道了。"
    nothought "...我换衣服的时候都会拉上窗帘的，不是吗...？"
    no "我怎么会没有注意到..."
    no "嗯...我很抱歉没有回你的消息。我没能看到，因为我妈妈把我的手机拿走了...她说我不能拿回来。"
    a "什么？！为什么？！"
    no"......"

    nothought "我不能告诉他我对弗洛伊德先生说的那些话..."
    no "我...向弗洛伊德先生倾诉了一些私人问题，他给了我一些建议...但后来他还是把所有的事情都告诉了我的父母..."
    no "现在一切都乱套了...他们让我换了班，没收了我的手机，而且..."
    nothought "他们说我不允许再和你说话了..."
    no "...一切都乱成一团了。对不起，我应该早点告诉你的..."
    a "...没关系的。别担心那条消息，也不是你的错。"
    no "...我想和你在同一个班级。"
    a "......."
    a "和我...？"
    no "呃...我是说..."
    no "...我喜欢和你在一起。"
    no "当然，也包括凯恩..."
    a "...我也希望我们能在同一个班级。"
    a "对不起，我不想让你感到更糟糕。"
    no "........"
    a "那我也换班吧。"
    no "什么？！"
    no "你是认真的吗？"
    a "好吧，我会问问我爸爸能不能安排一下...不过无论如何，我们还是可以经常见面的，对吧？"
    no "你不用这样做...我相信你在班上还有其他朋友，不只是我一个。"
    "奥古斯特摇了摇头，露出了他标志性的笑容。"
    a "我想把时间都花在和你在一起。"
    no "但是...你..."
    nothought "你觉得我很烦人吗？"
    "就像奥古斯特能读懂他的心思一样，他温和地朝诺亚微笑。"
    a "你..."
    "他停顿了一下。"
    a "你和凯恩让我知道什么是真正的朋友。我不想失去那种感觉。"
    no "哦...对了，凯恩。"
    "诺亚尴尬地挠了挠后脑勺，对自己草率下定论感到恼怒。"
    a "我也会告诉他这个计划。"
    no "是啊...这个主意不错。"
    a "......"
    "突然间，奥古斯特变得很安静，他透过黑暗凝视着诺亚。"
    "诺亚像个雕像一样一动不动，在他审视的目光下完全僵住了。"
    no "什...什么？"
    a "你用了保湿霜吗？"
    no "啊..."
    no "嗯...我只是想试试，因为你说它很好用..."
    "诺亚不好意思地移开视线，正好看到一道闪光。"

    scene gallery_4 with flash:
        xpos 0.93 ypos 1.44 xanchor 0.5 yanchor 1.0 zoom 2.01
    no "...?"
    "在奥古斯特的手里，一台粉色的相机。他从镜头后面微笑着，打印出一张照片。"
    "一张诺亚的照片。"


    scene gallery_4 with dissolve:
        subpixel True xpos 0.03 ypos 1.48 xanchor 0.5 yanchor 1.0 zoom 2.01 rotate None

    no "你刚刚...？"

    scene gallery_4 with dissolve
    a "我用的是我们一起买的胶卷。看，就是这张。"
    no "什么...你应该把它扔掉，你不需要我的照片。"

    scene gallery_4point5 with dissolve
    a "没门！我想把它挂在我房间里。"
    no "如果你要这么做，那我们就一起拍一张吧。"
    a "我们可以这么做！但我还是想保留这张。"
    no "这有点尴尬..."
    a "真的吗？我很喜欢。每当我感到孤单的时候，看看我的照片就会让我感到更快乐。"
    no "........"
    no "你...你可以直接来找我啊..."
    "从他身后传来了开锁的声音。诺亚感到内心充满了恐惧，赶紧跳回到窗户里。"
    no "我想我妈妈回来了...我得走了，晚安！"
    a "晚安，诺亚。睡个好觉。"

    scene bg bedroom night with Fade(1.0, 1.0, 1.0)
    "诺亚刚刚躲回被子里，卧室的门就被打开了。"

    "他的心脏还在剧烈跳动，几乎要疼痛了。"
    nothought "是因为我差点被抓到吗？"
    nothought "不...是因为...我很喜欢奥古斯特。"
    nothought "我喜欢他。"
    m "你在床上？我本来想给你送晚餐。"
    noteen sad  "我不饿。"
    m "好吧...明天放学后直接回家，明白吗？"
    noteen ".........."
    noteen "我这个周末可以去朋友家吗？"
    "诺亚的母亲双臂交叉，显然对他的问题不太满意。"
    m "哪个朋友？"
    nothought "她知道。如果我说是凯恩，我只会陷入更多麻烦..."
    noteen "...奥古斯特。凯恩也会一起去。"
    m "不行。你不允许去他家，而且你也被禁足了。晚安，诺亚。"
    "她在诺亚来得及回应之前就关上了门。"
    noteen "......."
    noteen "晚安，妈妈..."
    "一个人，永远孤单。"
    "但在他的窗外..."
    stop music fadeout 3.0
    "有一个让他感到不再孤单的人。"

    python:
        achievement.grant("Chapter1_Complete")
        achievement.sync()


    jump chapter2_start



### Demo only ########
    #window hide dissolve
    #scene black with Fade(1.0, 1.0, 1.0)
    #call screen credits_end
################################


# label after_credits: remove Kickstarter references after kickstarter ends
#
#     scene mainmenu_upscaled with flash:
#         subpixel True xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 rotate None
#         parallel:
#             xpos 0.52
#             easeout 2.05 xpos 0.51
#         parallel:
#             rotate -17
#             easeout 2.05 rotate 0
#         parallel:
#             zoom 0.41
#             easeout 2.05 zoom 0.19
#         parallel:
#             ypos 3.54
#             easeout 2.05 ypos 1.79
#
#     pause 1.0
#     show kickstarter with flash
#     $ persistent.show_kickstarter = True
#
#     stop music fadeout 5.0
#     $ renpy.pause ()
#
#     return





























    #
