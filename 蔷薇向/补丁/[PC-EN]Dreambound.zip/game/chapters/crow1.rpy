label crow_chapter1:
    window auto
    scene black with dissolve
    pause 1.0

    call screen crow1_chapter_screen
    scene bg paint day with Fade(1.0, 1.0, 1.0):
        subpixel True xpos 0.5 ypos 1.01 xanchor 0.5 yanchor 1.0 zoom 1.59 rotate None
        parallel:
            xpos 0.72
            ease 15.0 xpos 0.22
    "水泥地面上永远沾满了油漆，冰凉的触感贴在诺亚的手掌上。他跪下，翻找着箱子，翻动着散落的纸张。"
    play music nothing fadein 3.0
    nothought "在哪里...在哪里..."
    "纸箱被推到一边，罐装油漆被扔到一旁。"
    nothought "也许只是因为太久了。也许我已经忘记了..."
    "终于，他颤抖的手指拿出了他一直在寻找的东西。一本大书，封面上曾经挂着微笑的面孔。诺亚早已涂抹掉了他们的表情，他们永远嘲笑着他无法拥有的东西。"
    "本应该是他人生中第二到最后一本年鉴，但却成了他最后一本。他从未想要它，也从未翻开过。他太害怕了，但凯恩还是给了他。"
    "不知为什么，这些页面感觉格外沉重。"
    play sound flip volume 1.75
    queue sound "<silence 0.5>"
    queue sound flip volume 1.55
    queue sound "<silence 0.5>"
    queue sound flip volume 1.75
    "翻，翻，翻。他的心跳与每一页的翻动同步。"
    play sound heart2 volume 1.25
    queue sound heart2
    queue sound heart2 volume 1.25
    "砰，砰，砰。书页的翻动速度追赶上了他的心跳。"
    "直到最后，一个很久以前的人回望着他。"
    "一个他不认识的人。"
    "他眯起眼睛，凑近仔细看。"
    "他应该是熟悉的，但却像是在看一面脏兮兮、扭曲的镜子。"
    nothought "...这就是我。"
    "在他身边，凯恩带着标志性的宽容、魅力四射的笑容。事实上，他从那些日子起就没怎么变过。"
    "摇了摇头，他把目光从这破碎的自我形象上移开，扫视着其他照片。"
    "多年来他没见过或想起的人，或好或坏地出现在页面上。"
    "但无论他如何搜寻，他要找的那个人都不在那里。"
    nothought "一定是在他搬进这个班之前的...我忘记了..."
    "他叹了一口气，沉重得像是铅一般，漫不经心地翻阅着剩下的页面，直到他一个激灵。"
    "一个带着善意微笑和温暖眼神的男孩回望着他。他橙色的头发乱蓬蓬的，一如既往，让人立刻就想信任他。"
    "他的眉毛抽搐了一下。"
    "下面的字母有时看起来像是用血写的，下一刻又变成了正常的墨水。"
    nothought "卢卡。"
    play sound bookclose volume 1.8
    window show
    "他重重地合上了这本书，扔到一边。"

    scene bg paint day

    $all_moves(camera_check_points={u'y': [(-600, 0, u'linear')], u'z': [(555, 0, u'linear')]})
    show ivan n dim neu at slightleft
    show noah n dim neu at slightright

    with dissolve
    i "你在做什么？"
    show noah n dim ann with dis
    no "原来你还活着。"
    "伊万，不知何时已经在房间角落的旧沙发上舒适地坐了下来，耸了耸肩。"
    i "我通常都是。至少现在是。"
    no "我在找某个人的照片。"
    nothought "我们从未一起拍过照片，是吗？"
    nothought "我试着画你。我试着给你画一幅画。但是都不是你。都无法捕捉到你的本质。"
    nothought "回想起来，我的记忆太模糊，无法正确记住你的面容。这不是很悲伤吗？"
    nothought "如果不是我，谁来记住你呢？"
    nothought "难道我也和其他人一样，一旦你离开我的视线就会忘记你吗？"
    "伊万的声音打断了诺亚的思绪。"
    i "找不到吗？"

    no "事实上，我从来没有拍过。"
    show noah n dim neu with dis
    no "嘿，你昨天在梦里有没有看到一个金发男子？"
    "伊万耸了耸肩。"
    show ivan n dim neufro with dis
    i "我不知道。我可没特意留意。世界上金发男子多得是。"
    nothought "希望他没事..."
    "诺亚漫步回到昨晚完成的那幅画前。他的手指再次抚摸着画面的凹凸表面。"
    "不经意间，他的手指找到了他与那个与他记忆中的奥古斯特一模一样的男子并肩而坐的地方。"
    "他感受到了扫过的微风，柔软的云层。他感受到了那双绿色的眼睛一直注视着他，永远带着微笑。"
    i "我还以为你不会画画呢？"
    show noah n dim sca with dis
    no "...我确实不会。"
    no "或者说，我以前不会。"
    show ivan n dim neu with dis
    i "哦，看来你应该多在梦里待着了。"
    i "看起来你的小问题解决了。"

    $all_moves(camera_check_points={u'y': [(-600, 0, None), (0, 3.58, u'ease')], u'z': [(555, 0, None), (21, 3.58, u'ease')]})
    "伊万拿起遥控器打开了电视。一位新闻记者庄重的声音传进了房间。"



    tv "今天凌晨5点45分左右，在西公园又发现了一具尸体。警方已经封锁了现场。"

    "诺亚僵住了。"
    nothought "西公园。离我家不远..."
    "他小心翼翼地坐到伊万身边，目不转睛地盯着屏幕。"
    nothought "艾许？"
    "出于某种无法解释的原因，一种深深的恐惧感在他的胃里沉淀下来。"
    nothought "那个护身符呢？对了，他从来没拿过，是吗？"
    tv "死者已被家人确认为23岁的塞巴斯蒂安·卡特。塞巴斯蒂安是昨天晚上最后一次被人看到。"
    tv "警方发表声明称，死者身上有与之前发现的尸体相同的标记。"
    show noah n dim sho with dis
    no ".........."
    i "你认识他吗？"
    no "他...他和我上同一所高中。我有点...认识他迷恋的那个女孩。"
    show ivan n dim hap with dis
    i "你抢了他的女朋友？我还以为你不会这样呢。"
    show noah n dim sca with dis
    no "不！天哪，绝对不是。她...完全不是我的菜...我是说，我喜欢她，但不是那种喜欢。"
    no "他们其实并没有在交往，他只是...痴迷于她或者什么的。呃，我不想再想这件事了。"

    $menu = adv_menu
    menu:
        "电视画面变成了那些神秘标记的艺术复制品。诺亚偷瞄了一眼伊万。"
        "问他标记的意义":
            $ CrowPoints += 1
            no "这些标记代表什么意思？"
            show ivan n dim neu with dis
            i "你为什么问我？"
            show noah n dim fro with dis
            no "别装傻。"
            i "但如果我不是在装呢？"
            no "你是不是每个问题都要回答一个问题？"
            show ivan n dim hap with dis
            i "说得好。或者说，说得好。"
            show ivan n dim neu with dis
            i "好吧，反正也不是什么秘密。这些标记意味着他们是在梦中被杀害的。"


        "不问他":
            "诺亚的话卡在喉咙里，他凝视着伊万。"
            show ivan n dim neu with dis
            i "你有什么问题就直接问吧，你一直盯着我看让我很烦。"
            show noah n dim fro with dis
            no "......"
            i "你想知道这些标记的事情，对吗？"
            "他朝着屏幕点了点头，就像在问他想吃什么午餐一样随意自然。"
            i "这些标记意味着他们是在梦中被杀害的。"

    show noah n dim fro with dis
    no "...你怎么知道的？"
    show ivan n dim neu with dis
    i "我就是知道。这不是常识吗？我还以为大家都知道呢。"
    no "不，这不是常识。为什么...为什么会在身上留下这种标记呢？"
    i "很好的问题。"
    no "..."
    i "........"
    show noah n dim sca with dis
    no "那答案是...？"
    i "我也不知道。"
    i "我并不是知识的载体。"
    show noah n dim hur with dis
    no "是啊，我早就意识到这一点了..."

    nothought "克劳说这是梦境对人体的副作用...所以我想这至少证实了伊万的说法。"
    nothought "梦境中有人在杀人。"
    nothought "...一个\'死神\'。"
    "诺亚小心地盯着伊万。"
    nothought "如果在梦中杀人能给他们留下标记，那么杀手也会得到这些标记吗？"
    show noah n dim neu with dis
    no "...所以你知道有人被谋杀了。"
    i "看来是这样。"
    "伊万点了点头，喝着从某个黑暗角落里拿出来的一盒果汁。"
    no "你为什么没有采取任何行动？"
    i "你到底想让我做什么？每天都有人死去。这不是我的问题。"
    show noah n dim ann with dis
    no "......."
    nothought "这不是我的问题..."
    nothought "这是我的问题吗？"
    nothought "我的母亲...我的父亲...塞巴斯蒂安...弗洛伊德先生很害怕...艾许也可能会以同样的方式死去..."
    nothought "...."
    show noah n dim sho with dis
    no "他们都..."
    show ivan n dim neufro with dis
    i "...?"
    no "他们都和我有关..."
    "诺亚用手捂住嘴，介于震惊和厌恶之间。"
    show ivan n dim neu with dis
    i "哈...那么，{i}你{/i}打算采取行动吗？你看起来不像是英雄类型。"
    show noah n dim ann with dis
    no ".........."
    no "...自从这一切开始以来，我就能画画了。"
    show ivan n dim hap with dis
    "伊万露出了一个罕见的微笑。"
    i "你真是个自私的混蛋。我很欣赏这一点。"
    show noah n dim sca with dis
    no "嗯..."
    i "我不是在评判你。事实上，我突然发现你变得更有趣了。"
    nothought "如果我调查这件事...我还会再见到你吗，克劳？"
    no "呃...那么我可能别无选择，只能认真调查这件事..."
    show noah n dim ann with dis
    no "只是为了看到...他。克劳..."
    show ivan n dim neu with dis
    i "谁？"
    no "...我之前提到过的那个金发男子。我昨晚遇到了他。他说他叫克劳。他看起来像..."
    no "他看起来像我很久以前认识的一个人。"
    i "另一个和我们一样的人？哇，巴德-迈因霍夫现象真的存在啊。"
    no "我不知道……"
    no "我不知道他是不是梦境的一部分...他看起来太真实了，但是他...他..."
    nothought "他死了...所以怎么可能..."
    i "好吧，他要么是真的，要么不是。没有中间状态。"
    nothought "对...我只需要弄清楚他是真是假。如果...如果奥古斯特真的可能是..."
    play sound dooropen fadein 0.2
    "突然传来一阵窸窣声，紧接着是诺亚公寓门打开的吱呀声。"


    "一张满是担忧的脸出现在黑暗中。看到诺亚时，他的表情开始变得柔和，但当看到伊万时又变得阴沉。"
    show noah n dim sho with dis
    no "凯恩..."
    k sad "你没有收到我的消息吗？我一直很担心你。"
    show noah n dim ann with dis
    no "哦。"
    "诺亚掏出手机，迅速打开。有七个未接来电，还有更多来自凯恩的短信。"
    k "对不起，我不是有意闯进来的，我只是...当你没有回复的时候..."
    "他眼下有着黑眼圈，这清楚地表明了他有多担心。一丝内疚感在诺亚的胃里沉淀下来，但他很快就摆脱了。"
    no "...对不起。我最近有点忙。"
    k "忙什么？"
    "凯恩的目光从伊万转向了那幅仍然完成的画作。颜料早已干透。"
    "他长叹一声，把包放在地上，朝诺亚走去。"
    k fro "..."
    "他放松了紧握的拳头，轻轻抓住诺亚的胳膊，把他从沙发上拉到了厨房里。"
    $ camera_reset()

    scene bg noahbedroom night
    show noah n dark ann at slightright
    show kaine n dark sad at slightleft
    with Fade(1.0, 1.0, 1.0)


    k "诺亚。我不知道到底发生了什么，但我知道你参与其中太危险了。"
    k "拜托。为了我，不要这样做。"
    no "我明白。我知道自己在做什么，好吗？你不需要担心我。"
    show kaine n dark fro with dis
    k "但我确实担心！我会一直担心的！"
    show kaine n dark sad with dis
    k "我不想再失去你了。"
    show noah n dark hur with dis
    no "...没有选择。"
    k "当然有选择...你现在就在做选择。"
    no "....."
    show noah n dark ann with dis
    no "我想我是在做选择。这感觉并不太糟...终于做出了选择。"
    no "你看到我的画作了，对吗？它们是..."
    k "它们真的很美。我很高兴你又开始正常地画画了，但...一定还有其他办法。"
    no "没有了。这就是我的答案。"
    k "它们不如你的生命重要。"
    show noah n dark fro with dis
    no "也许在你看来不重要。"
    k "......."
    show ivan n dark neu at farright with dissolve
    i "你们在争论什么？"
    show kaine n dark fro with dis
    k "这不关你的事。我们正在进行一个私人对话。"
    k "你似乎经常插手与你无关的事情，是吗？"

    no "这和他一样也和你有关。"
    "凯恩烦躁地揉着太阳穴。"
    k "你为什么这么在乎？"
    show noah n dark ann with dis
    no "...我不知道。你想让我说什么？我的良心战胜了我？我没有答案。"
    no "我所知道的是，与我有关的人正在死去，而调查这件事让我重新开始创作。这就是我所需要的。"
    no "艺术就是我所需要的。"
    show kaine n dark sur with dis
    k "...与你有关？"
    no "自己去查查。这是真的。我的妈妈、爸爸，还有学校的塞巴斯蒂安...弗洛伊德先生很害怕，我觉得艾许也被盯上了。"
    k "........."
    show kaine n dark sad with dis
    k "好吧，好吧，我理解你想重新开始创作。但我不明白你为什么会在乎他们是死是活。"
    show noah n dark sho with dis
    no "什么？"
    k "难道你不想让他们死，因为他们对你做的事情？"
    no "....."
    show noah n dark ann with dis
    no "我不知道。也许很久以前我是这么想的。也许我现在还是这么想。也许我根本不在乎..."
    no "但是..."
    show ivan n dark hap with dis
    i "拜托，你不需要给这件事赋予什么深层意义。你想创作，调查正在帮助你创作。做你自私的自己吧。"
    show kaine n dark fro with dis
    k "没人让你插手。"
    show ivan n dark neu with dis
    no "...我想再见到奥古斯特。"
    show kaine n dark sad with dis
    k "诺亚，奥古斯特..."
    "凯恩大声叹了口气，小心翼翼地避开即将说出口的话。"
    k "不管那个人是谁...都不是奥古斯特。奥古斯特已经不在了。你知道的。"
    show noah n dark sad with dis
    no "你见过他，你听到过他的声音。怎么可能不是他？"
    k "我不知道……"
    no "那就帮我找到他。"
    k "我怎么做到？"
    no "你...你的工作...难道你不能访问各种记录和数据库吗？"
    no "难道就没有什么你能做的吗？如果你调查一下他的情况，也许他并没有真的..."
    k "如果我想保住工作的话。诺亚，你知道我愿意为你做任何事，但这不会让他回来...这很不安全。"
    k "请忘记这一切吧。我自己会试着帮你重新创作。我们可以解决这个问题。"
    show noah n dark fro with dis
    no "不。如果你不帮我，那我就自己想办法。"
    k "来吧，我们出去吃点东西，好好谈谈这件事。"
    no "我不想去。"
    i "你为什么这么反对他进入梦境？"
    show kaine n dark fro with dis
    k "诺亚说这很危险。就算我也能看出这一点...更不用提可能有个杀手在阴影里徘徊。"
    show kaine n dark sad with dis
    k "我不想再失去任何人。"
    show ivan n dark neufro with dis
    i "再失去任何人？"
    no "这无关紧要。"
    i "啊。"
    i "所以，你在梦里遇到的这个克劳看起来像是已经死了的奥古斯特？"
    show ivan n dark neu with dis
    i "这开始变得有趣了。"
    show kaine n dark fro with dis
    k "有趣？"
    "凯恩的声音低沉而严肃。"
    k "这不是可以开玩笑的事情。"
    show noah n dark ann with dis
    no "请离开。"
    show kaine n dark sad with dis
    k "诺亚—"
    show noah n dark fro with dis
    no "现在。"
    k ".........."
    k "好吧...如果这就是你想要的。不过我只是想帮你。"
    no "而且我从来没有要求过你的帮助。"
    k "也许你没有..."

    hide kaine

    $all_moves(camera_check_points={u'y': [(-870, 0, u'linear'), (-2149, 5.19, u'ease')], u'x': [(6800, 0, u'ease')], u'z': [(1074, 0, u'ease')]})
    with dissolve
    play sound doorclick fadeout 0.1
    "说完这些话，他松开了诺亚的手腕，迅速离开了房间，脸上带着痛苦的表情。几分钟后，诺亚和伊万听到了前门被锁上的声音。"
    i "所以，你想知道这个克劳是不是你的朋友奥古斯特？"
    show noah n dark ann with dis
    "诺亚无声地点了点头。"
    i "那么奥古斯特呢？"
    no "六年前去世了。"
    show ivan n dark neufro with dis
    i "嗯哼。有什么办法可以确认一下吗？你亲自见过他吗？"
    no "什么？不...我没有进过医院病房。是他...他爸爸告诉我的..."
    no "他在家乡有一个坟墓...据说是这样。我当时没有在场..."
    "伊万露出了一个歪斜的笑容。"
    show ivan n dark hap with dis
    i "除了盗墓，一定还有其他办法来确认他是否真的在那里。"
    stop music fadeout 4.0
    no "凯恩在政府的安全部门工作，但他不愿意帮忙。你听到了。我不太想让他丢掉工作，但是..."
    play music thiscloud fadein 4.0
    i "那为什么不闯进他的办公室呢？"
    show noah n dark sur with dis
    no "什么？闯入政府大楼？你疯了吗？"
    i "为什么不行？"
    no "你不可能是认真的。"

    i "我和你一样认真，所以...告诉我，你有多想了解克劳？"
    show noah n dark ann with dis
    no "我不可能去搜索一个叫克劳的人。"
    show ivan n dark neu with dis
    i "不，但你可以查查奥古斯特。看看他是否真的像你想的那样消失了...或者是否还有其他隐藏的信息。政府喜欢隐藏一些东西。"
    no "....."
    i "如果出了什么事，你可以直接跳进梦境。没人会知道。"
    no "我开始觉得你可能会对我产生不好的影响。"
    show ivan n dark hap with dis
    i "才刚刚开始？"
    "某个时候，伊万把一堆沾满油漆的脏衣服推到一边，坐在柜台上，终于与诺亚四目相对。他从柜台上跳下来，嘴角带着一丝得意的笑容。"
    i "那就走吧。"
    show noah n dark sho with dis
    no "现在就走？"
    show ivan n dark neu with dis
    i "你还有别的地方要去吗？"
    no "...让我去拿点东西。"


    scene bg paint night
    with Fade(1.0, 1.0, 1.0)
    $ camera_reset()


    "再次，诺亚在一堆书籍和绘画用品中翻找，寻找他需要的物品。"
    nothought "以防万一...以防我再次见到他。"
    "终于，他找到了。一本旧日记，封面是磨损的皮革。里面是他高中时期做的一些水彩素描。"
    "它还只填满了一半。多年来他都没有碰过它。无法碰。"
    "他把它塞进一个小斜挎包里，还有一支便宜的机械铅笔，然后迅速把包带在肩上。"
    i neu "那是什么？"
    no neu "没什么重要的。我们走吧。"
    "伊万没有再说其他话。相反，他穿过堆满绘画用品的房间，朝前门走去。"
    "诺亚僵住了。"

    scene bg paint night with dissolve:
        subpixel True xpos 0.5 ypos 1.86 xanchor 0.5 yanchor 1.0 zoom 2.39 rotate None
        parallel:
            xpos 0.96
            ease 4.2 xpos 1.19
    "在视线的角落里，一小块绿色静静地坐着，似乎在呼唤着他。"
    "他转过身，打开凯恩之前留下的一瓶矿泉水，给那株植物浇水。"
    "它似乎立刻就精神了起来。"
    "满意地，诺亚转身跟上伊万，但还是忍不住回头看了看自己最新的画作。"

    scene bg sky night with Fade(1.0, 1.0, 1.0)
    "夜晚阴冷清凉。诺亚把轻薄的外套拉得更紧，但仍然无法取暖。"
    "当他打量伊万时，他感到更加寒冷。伊万身上那件全息夹克还松松地挂在一边肩膀上，几乎是骄傲地展示着他手臂上的标记。诺亚努力抑制住自己的好奇心，因为他很清楚这个男人不会回答他关于这些的问题。"
    "他已经试着直接和委婉地问过了...但这是伊万不愿意透露的。"
    "诺亚叹了口气。"
    nothought "我真是个白痴，半夜跟着这个家伙。"
    "漆黑的云层在头顶飘过，使本就昏暗的街道更加阴沉。这是诺亚已经很久没有见过的景象了。"
    "年轻的时候，他常常独自在夜晚出去，在家附近的山里漫步。"
    "在那些时候，周围的空气似乎静止不动，好像在等待着什么。吹过树梢的微风好像在他耳边低语着秘密。"
    "最后，天空上方似乎包含着无穷无尽。"
    "广阔。无边无际。当他独自在夜色中站在那片天空下时，他感到满足。"
    "诺亚抬头望向天空。星星很少，与他以前看到的相比黯淡许多。"
    nothought "我不知道上次仰望星空是什么时候了。"
    nothought "看来世界在我离开的时候一直在转动。"

    scene bg streets night:
        subpixel True xpos 0.98 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 2.07 rotate None
    show ivan n dark neu at slightleft
    show noah n dark neu at slightright

    with Fade(1.0, 1.0, 1.0)
    i "如果你一直盯着天空，你就会绊倒在什么东西上。"
    show noah n dark ann with dis
    no "你管我什么事？"
    i "我没有管你的意思，只是个观察而已。"
    no "随便吧..."
    "伊万走在诺亚前面，他身上那件金属色的外套在昏暗的街灯下几乎在发光。"
    no "你知道路吗？我都没告诉你他工作的地方。"
    i "就是沃德街那栋楼。"
    no "....."
    show ivan n dark hap with dis
    i "你不想问我怎么知道的吗？"
    no "不，我觉得我不想知道..."
    show noah n dark hur with dis
    no "但它不在一楼，我们怎么进去？"
    "伊万从口袋里拿出一只手，在手指上转着什么东西。"
    "一个钥匙扣，上面挂着一张ID卡和一把钥匙。诺亚凑近看了看。"
    show noah n dark sho with dis
    no "...怎么回事？"
    show ivan n dark neu with dis
    i "他在把你拉进厨房的时候，傻乎乎地把包落在我这里了。"
    no "所以你就抢劫了他？"
    i "是的。"
    no "我想这次会派上用场...你经常这么做吗？"
    i "嗯哼。"
    show noah n dark ann with dis

    menu:
        no "好的..."
        "你为什么要帮我？":
            $ CrowPoints += 1
            no "你为什么要帮我？"
            i "...."
            show noah n dark fro with dis
            no "嘿，我问你个问题。"
            show ivan n dark neufro with dis
            i "我知道。我只是在想你是不是个白痴。"
            no "什么？"
            show ivan n dark neu with dis
            i "我已经告诉过你了。你引起了我的兴趣。没别的了。"
            show noah n dark ann with dis
            no "你要和我一起闯入一栋政府大楼。那里肯定有比单纯的兴趣更多的东西。"
            no "一定是这样。普通人是不会做这种事的。"
            "伊万耸了耸肩，同时翻了个白眼。"
            i "有什么新鲜的吗？"
            show noah n dark sca with dis
            no "你疯了。"
            i "也许吧。谁在乎。"
            no "...谢谢。我一个人做不到。"
            "伊万脸上罕见的一丝笑意又回来了。"
            show ivan n dark hap with dis
            i "真他妈的。"

        "保持安静":
            "诺亚紧紧地闭上了嘴。他还不确定是否完全可以信任这个男人。"

    "他们走得越远，两旁的建筑物就越高，因为他们已经进入了商业区。除了对面路上一个摇摇晃晃的醉汉，街上没有人走动。"
    show noah n dark ann with dis
    "诺亚皱了皱眉头，移开了视线。最好是忽视这样的人，不要引起他们的注意。"
    show ivan n dark neu with dis
    i "这就是你的底线？你的道德观还真是奇怪。"
    no "你也一样。你有什么道德观吗？你从任何人那里偷东西，对谋杀也毫不在乎。"
    show ivan n dark hap with dis
    i "为什么要用道德观呢？我发现它们只会妨碍我们完成任务。"
    no "你总是这么冷漠吗？我开始担心你自己就是个连环杀手了。"
    "伊万又耸了耸肩，进一步证实了诺亚的观点。"
    show ivan n dark neu with dis
    i "也许吧。"
    "突然，伊万停下了脚步，抬头望去。一栋高楼耸立在天空中，像一个金属污点一样。"
    "它似乎就要撕裂天空了...但当然，它并没有。它只是静静地坐在那里，阴森而令人不安，好像在等待着他们。"
    "诺亚艰难地吞了口唾沫。"
    show noah n dark sho with dis
    no "就是这里了。"
    stop music fadeout 3.0
    i "入口处有3个摄像头。大厅里可能还有2个。电梯里有1个...都是无线的。"
    "伊万自言自语地嘟囔着，显然在认真思考。"


    i "走吧。"
    play music coma fadein 3.0
    no "等等，那些摄像头怎么办？"
    i "我来处理。跟着我。"
    "伊万的脚步并不匆忙，动作冷静从容。"
    "就像他的整个性格一样。"
    "他走上前，从夹克里掏出一个手机大小的东西。"
    "但这显然不是手机。取而代之的是，顶部伸出了4根天线。仔细观察，诺亚觉得它更像是一个手持无线电设备。"
    show noah n dark ann with dis
    no "那是什么？"
    "伊万没有理会诺亚的话，开始慢慢地转动设备侧面的旋钮。"
    "他的手停了下来。"
    "他盯着监控摄像头，好像能看到里面的情况。似乎对结果满意，他走出阴影，沿着台阶走向入口，完全暴露在摄像头下。"
    no "...无线电干扰器？你确实做过不止一次了。"
    play sound beep volume 0.2
    "诺亚加快脚步，与这个白发男人并肩而行。当他们到达入口时，伊万扫描了凯恩的门禁卡，门禁卡发出三声轻微的蜂鸣声，大门随之缓缓打开。"


    scene bg office lobby night with Fade(1.0, 1.0, 1.0)



    "大厅宽敞而寂静。他们的脚步声在空旷的空间里回响，诺亚更加意识到自己的脚步声有多大。"
    "前方是电梯。伊万手持着干扰器，他们直奔而去。"

    i neu "几楼？"
    no sho "我不知道..."
    "诺亚回想起凯恩之前的每一次来访。每次他都坐在诺亚身边聊天，尽管诺亚从未回应。"
    "凯恩告诉过他多少他从未听到的事情？他有多长时间没有在听了？"
    "为什么现在他才终于能够听见了？"
    no ann "...应该是11楼，但具体是哪个房间我不知道。"
    i neu "到了再说。"
    play sound elevatording volume 0.8
    "随着叮的一声，电梯门打开了。伊万和诺亚站在两侧，查看里面是否有人，结果发现里面是空的。"
    "心跳加速，诺亚走进电梯，按下了11楼的按钮。伊万站在他身边，面无表情。"
    scene black with dissolve
    play sound elevator fadein 0.5

    "电梯缓缓上升。唯一的声音就是电机运转的轻微嗡鸣声，听起来比实际更大。"
    play sound elevatording volume 0.8

    show bg office hall night with dissolve
    "当电梯门再次打开时，他们面对的是一条昏暗的走廊。大厅和电梯里的寂静似乎延伸到了整栋大楼。"
    "无声无息地，伊万首先走出了电梯。他向左看了看，又向右看了看，最后决定直走。"
    "两人轮流探视黑暗的办公室，寻找可能是凯恩房间的迹象。"
    u "该死，我没想到会花这么长时间。要不要去吃点东西？"
    u "当然好啊。你知道，你比凯恩有趣多了。"
    u "他每天下班后都会立刻走人，即使我们还有deadline。"
    u "可能是有个女朋友在等他。混蛋。"
    show bg with hpunch
    "两个声音大笑起来。诺亚甚至来不及僵住，伊万就抓住他的衬衫，把他拽回到一个敞开的储藏室里。"
    play sound elevatording volume 0.8
    "脚步声从他们身边经过，电梯门打开的叮当声回响在储藏室里。"
    "他们等了好久，直到伊万走了出来。"
    i neu "我们去那个房间试试。"
    "他朝那两个人来的地方点了点头。"
    i "他们似乎认识你的朋友。"
    no ann "...."
    i smu "看来他并不那么受欢迎。那种迷人的绅士作派并不适用于所有人。"
    no fro "...那些混蛋。"
    i neu "你对他也没好到哪里去。"
    no ann "当然我对他很好！我们...我们是朋友。"
    i "好吧。我不是在评判，只是在做个观察。"
    "伊万用刷卡打开了门，门立刻发出咔哒一声解锁了。"

    scene bg office night with Fade(1.0, 1.0, 1.0)
    "房间里有几张空着的办公桌，看起来已经被它们的主人遗弃了一整晚。诺亚快步走到桌子之间，寻找任何可能属于凯恩的电脑。"
    "大窗户微微敞开，让一阵微风吹进房间，吹凉了诺亚的身体。他再次看向伊万，不知道他是否也感到寒冷。"
    "诺亚停下了脚步。"
    "在房间角落的一张桌子上，他注意到了一个杯子。上面写着\"世界上最好的厨师\"，这让他立刻认出了它。"
    no ann "我在高中的时候给他买的这个...我没想到他还保留着..."
    i hap "找到了。让我们看看电脑里有什么。"
    "诺亚坐在桌子前，而伊万站在他身后，凑近屏幕向里窥探。"
    "屏幕上先是出现了一个标志，然后淡去，显示出一个登录界面。用户名\"Kaine782\"已经填好，光标正在密码框里闪烁，等待输入。"
    i neu "...."
    no hur "该死..."
    i neufro "你是说你来这里的时候连他的密码都不知道？"
    no "我怎么会知道我需要它？！"
    i "............."
    no ann "你不能想办法吗？黑进去或者别的什么？"
    i neu "我不会用电脑..."
    no sho "什么？"
    i neufro "我说的哪一部分让你困惑了？需要我慢慢重复吗？"
    no "你有手机，有无线电干扰器，你就在电脑这一关上打住？"
    i "手机是我偷的，干扰器是别人给的。没人给我电脑。"
    no ann "这是我听过最奇怪的事了。我都不知道你对技术是熟悉还是不熟悉。"
    "伊万只是耸了耸肩，显然他不打算在短时间内解释这个问题。"
    no "好吧...好吧，让我想想..."
    no "会是什么呢..."
    "诺亚无意识地敲着桌子，回忆起他和凯恩曾经形影不离的日子。"

    no "也许是他最喜欢的电影...或者歌曲..."
    "但诺亚的手指并没有在键盘上移动。他的大脑一片空白。"
    i neu "你们两个是朋友，对吗？"
    no sca "...我不知道。"
    no hur "该死...我不知道..."
    i "别想得太复杂了。试试你脑子里的任何东西。"
    no ann "....."
    "小心翼翼地，他做出了第一次猜测。"
    "错误。"
    "第二次和第三次猜测来得更快了。"
    "全都错了。"
    "屏幕上弹出了一个提示框。再尝试三次，电脑就会被锁定。"
    "他的第四次和第五次猜测都白费了。"
    "他的心在耳边怦怦直跳，他输入了最后一次猜测。这是对他们曾经的友谊的最后一搏。"
    "130805."
    "锁屏界面消失，进入了桌面。一个记事本打开着，似乎是一个购物清单，浏览器里还有几个标签页打开着。"
    i neu "是什么？"
    no neu "这不关你的事。"



    menu KainesComputer:
        "诺亚的目光扫过屏幕。"

        "看看购物清单" if not kainescomputer_list:
            "诺亚的目光集中在购物清单上。看起来很简单。"
            "诺亚依次读出了清单上的内容：蘑菇、茴香、菲达奶酪、苹果、鼠尾草、青柠、萝卜。这些食材组合有些奇怪，但又很像凯恩的风格。他总能从任何东西中做出美味的东西。"
            i neu "他的口味真奇怪。"
            $ kainescomputer_counter += 1
            $ kainescomputer_list = True
            if kainescomputer_counter == 2:
                jump Crow1_Continue
            else:
                jump KainesComputer

        "看看浏览器" if not kainescomputer_browser:
            "凯恩的浏览器里还打开着三个标签页。起初诺亚没有发现任何值得注意的地方，甚至考虑直接关掉它们，但一句话引起了他的注意。"
            "其中一个标签页打开的是\"植物护理101\"，另一个是\"如何照顾他人\"。诺亚的目光从屏幕上移开，一丝内疚感爬上了他的皮肤。"
            i neu "奇怪的爱好。"
            no ann "你也谈不上有多好。"
            $ kainescomputer_counter += 1
            $ kainescomputer_browser = True
            if kainescomputer_counter == 2:
                jump Crow1_Continue
            else:
                jump KainesComputer

label Crow1_Continue:
    no neu "好吧，忘记其他的东西吧...让我们看看..."
    "诺亚迅速浏览了凯恩的书签。幸运的是，都是工作相关的，所以不会太长。"
    nothought "全国出生死亡登记处。"
    i hap "你要知道，你即将从轻罪变成重罪。"
    no ann "我不在乎会发生什么。"
    i neu "不用担心，我仍会给你一个放弃现实的机会。"
    "诺亚点击了链接，这使他自动以凯恩的身份登录到了系统。一个空白框等待他输入一个名字。"
    no "...以防万一..."
    "他的话语很轻，几乎是耳语。即使对于他自己，他也不知道这是为伊万还是为自己说的。"

    "他悄悄地输入了\"克劳\"这个名字。当然，正如他们两个所知道和预料的那样，没有人出现。"
    "然而，现在诺亚只剩下一个选择，而这个选择已经在他的心和脑中啃噬。"
    "去搜索这个人就是接受他所发现的。"
    nothought "奥古斯特·里弗斯。"
    "出现了几个结果，但诺亚很容易就分辨出哪一个是他的奥古斯特。那个他熟悉得很的奥古斯特。"
    "他的条目开始于诺亚已经知道的信息。他的名字、出生日期和地点、血型...."
    "诺亚继续向下滚动，搜索着信息。"
    "死因：疾病。"
    "埋葬地点：无。火化状态：无。"
    no sho "这...这说不通啊..."
    i neufro "哦？事情变得更有趣了。"
    no "他并不是因为—"
    stop music fadeout 3.0
    u "说真的，难道非得等到明天吗？"
    u "不，我必须把那个电子表格转发给老板，否则他明天早上就要把我的头砍下来..."
    no sca "妈的..."
    i neufro"........"
    "伊万猛地合上了笔记本电脑的盖子，在诺亚来得及思考之前就把他拽了起来。外面，两个声音越来越近。"
    play music chasing fadein 2.0
    i sca "跳。"
    no "什么？"
    i ang "我说跳。"
    no sur "{i}什么？{/i}"
    i "跳，不要尖叫！"
    "伊万紧紧抓住诺亚的衣领，把大窗户推得更开，为这个男人腾出足够的空间，让他把腿悬在外面。"
    "当他看到诺亚没有加入他时，伊万咂了咂舌头，用足够的力量滑过边缘，将诺亚从他安全站立的地方推了出去。"

    play sound whoosh
    queue sound wind volume 0.7
    scene bg sky night:
        subpixel True xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 rotate None
        parallel:
            zoom 1.0
            ease 0.4 zoom 1.3
        parallel:
            ypos 1.0
            ease 0.4 ypos 1.13

    show speedlines:
        alpha 1.0
        pause 0.3
        linear 0.1 alpha 0.0
    with hpunch

    no sur "你他妈在干什么？！"
    "他的话被从凯恩办公室自由落体的巨大风声淹没了。他感到想要尖叫，但声音却卡在了喉咙里。"
    "地面越来越近，这是多年来他第一次想到一件事。"
    nothought "我不想死...还不是时候...！"
    scene black with eye_shut
    "他紧闭双眼，用手臂遮住了脸。"
    stop music fadeout 3.0
    nothought "克劳...！"


    "突然，那种下坠的感觉被另一种感觉取代了。被拉进一个完全不同的现实的感觉。"
    "这种感觉并不算愉快，但在从十一层楼坠落到混凝土地面之后，它感觉更像是...回家。"

    scene bg classroom night with eye_open
    "当他再次睁开眼睛时，他感到呼吸一窒，这种感觉与从大楼坠落完全不同。"
    play music moment fadein 3.0
    "这是一个他既亲爱又憎恨的地方。他在这里度过了多年的生活。"
    "教室里很黑暗，外面的夜空布满了他已经遗忘存在的星星。他小心翼翼地迈出一步，好像在测试这个世界是否会随着他的动作而崩解，然后又迈出了更多步伐。"

    scene bg classroom night with dis:
        subpixel True xpos 0.5 ypos 1.32 xanchor 0.5 yanchor 1.0 zoom 1.73 rotate None
        parallel:
            xpos 0.65
            ease 7.21 xpos 0.9
    "他以极快的速度走到窗边，向外望去。同样的山脉和天空映入眼帘。"
    "这种感觉很奇怪。它给他带来了温和的怀旧。对一个永远无法回归的时光的向往。"
    "在他身后，门突然以一种熟悉的方式开始发出响声，就像每次有人进入时一样。"
    "他慢慢转过身，心已经在喉咙里。"
    "一个金发绿眼的男孩站在门口，手还搭在门框上。"
    "他眨了眨眼睛，看着诺亚，好像不太确定他在看谁，然后恍然大悟。"


    $all_moves(camera_check_points={u'y': [(1651, 0, u'ease'), (-1089, 5.0, u'ease')], u'x': [(21, 0, u'ease')], u'z': [(723, 0, u'ease')]})

    show august m dark sho glasses
    a "诺亚...？"

    "他知道这是一个梦。他知道这不是真的。但此时此刻，他所知道的并不重要。"
    "这是他多年来一直想见、祈求、恳求见到的人...在这里，就好像他从未离开过一样。"
    "这不是奥古斯特。"
    "但此时此刻，他就是。"
    "眼泪慢慢地流了下来，很快就成了一股洪流。奥古斯特，仍然看起来和之前一样震惊，迅速走上前，紧紧地抱住了诺亚。"

    a "你...你就是诺亚，对吗？"

    "他的声音和当时一模一样。"

    no sad "我好想你...我太想你了..."

    show august m dark hap with dis
    a "不用想我，傻瓜。我就在这里。"
    no hur "对不起...奥古斯特，我应该...一定有什么办法..."
    a "嘘，没事的。我不知道发生了什么，但一切都会好起来的。"
    a "即使很困难，我相信你。"
    no sad "........"
    show august m dark sho glasses with dis
    a "你长高了吗？"


    no "我...."
    no "你应该...你应该得到..."

    show august m dark sadsmi with dis
    a "看起来你一直在烦恼着什么，是吗？"

    no hur "...这么说也不为过。"

    show august m dark hap with dis
    a "如果你想谈谈的话，我随时都在。"
    a "我不会离开的！"

    "他的话像刀子一样刺进了诺亚的心里。"

    nothought "你不会一直在这里的。我真希望这是真的..."

    a "但如果你不想谈的话，我也理解。"
    a "我只希望你能幸福，诺亚。你应该得到这一切。"
    no sad "...."
    no "我好害怕失去你。"

    show august m dark sho glasses with dis
    a "...失去我？"
    show august m dark pou glasses with dis
    a "我刚刚告诉过你，我不会离开的！"

    "他撅起嘴，但当一声轻笑浮现时，他放弃了。"

    show august m dark hap with dis
    a "即使我突然消失了，那也没关系。"
    a "一切都会结束，诺亚。有些事情会比其他事情更早结束。但这并不意味着经历它们就没有意义。"
    a "不管我在不在，我希望你能回忆起我们在一起的时光，感到快乐。"

    no sad "我还不够强大。"

    a "在我看来，你已经很强大了。"
    no "...告诉我你原谅我。拜托。"
    show august m dark sho glasses with dis
    "这是一个自私的请求，但诺亚并不在乎。他只想得到原谅。他只想摆脱压在心上的罪疚感。"

    a "...."
    no hur "拜托...也许那样的话，我就能..."
    a "诺亚，我会永远—"
    kteen neu "奥古斯特！快点，已经很晚了。"
    kteen hap "再待下去，管理员就要拿扫帚赶我们出去了！"
    noteen poublu "凯恩...给他一点时间，拜托..."
    "仍然敞开的门框里，突然出现了另外两个人影。他们停下脚步，被眼前的场景冻住了。"
    kteen sho "谁...？"
    a "哦，凯恩，诺亚..."
    a "看来我们都陷入了一个有趣的处境，是吗..."
    "诺亚凝视着自己年轻的面孔。"
    nothought "我在他眼中是什么样子的呢。"
    nothought "一个可怜的失败者...一个失意的艺术家。一个彻头彻尾的废物。"
    no sad "........"


    $all_moves(camera_check_points={u'y': [(-1089, 0, None), (-307, 1.08, u'ease')], u'z': [(723, 0, None), (336, 1.08, u'ease')]})

    "诺亚从奥古斯特身边退开，用袖子擦了擦鼻子。"

    "他最想做的就是待在奥古斯特身边-不管他是真实的还是虚幻的，他都想和他说话。"
    "但当他看到自己年轻的样子，看到凯恩，他意识到自己已经不属于这里了。"
    "凯恩周围的世界开始崩裂。"
    kteen "那个...他是诺亚，但你也是..."

    play sound earthquake fadein 1.0
    scene bg classroom night at Shake((0.5, 1.0, 0.5, 1.0), 75.0, dist=2)


    "从大地深处传来一阵隆隆声，现实开始破碎。诺亚伸出手去够奥古斯特，但他似乎正在一秒比一秒远离。"
    no hea "奥古斯特...等等，奥古斯特...！"
    no "我不想再次失去你！求你，跟我一起走吧...！"

    "世界越来越快地消失在虚无之中，但他现在已经不在乎了。"
    "在教室彻底消失在虚空之前，诺亚发誓看到奥古斯特也在向他伸出手。"
    "他感到自己在坠落。刚才还坚实的地面现在已经不复存在。诺亚认命地接受了自己的命运。"
    nothought "如果我必须死，至少我还能再次见到他的面孔。"
    stop music fadeout 2.0
    c sur "诺亚！"

    play sound glasssmash fadeout 0.5
    show black with shatterdissolve
    $ camera_reset()
    pause 3.0

    scene bg empty dream with Fade(1.0, 1.0, 1.0):
        subpixel True xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.44 rotate None
        parallel:
            xpos 0.29
            ease 15.57 xpos 0.71
    "诺亚周围的世界从黑色变成了一片苍白和荒凉。他的坠落被两只手臂拦住，将他紧紧抱在怀里。"


    scene gallery_9_1 with Fade(1.0, 1.0, 1.0)

    c "哈...哈..."
    play music unsaid fadein 4.0
    c "诺亚，你没事吧？"
    "克劳跌倒在地，仍然紧紧抱着诺亚，就像抓住最后的希望一样。"
    "虽然他能感觉到自己已经不在教室里了，但诺亚还不确定自己身在何处。他的视线因为还没有停下的眼泪而模糊不清。"
    "一切看起来都是如此...明亮。无边无际。空虚。"
    c "你在想什么？这样做会把自己害死的。如果我不在，你就...你就..."
    c "我告诉过你要好好享受，但是你必须更加小心谨慎。"
    "克劳满是恐慌的脸庞在看到诺亚不停流泪时变得柔和下来。"
    "他紧紧抱住诺亚的双臂也放松下来，轻轻松开。"
    scene gallery_9_2 with dissolve
    "克劳温柔地抚摸着诺亚脸上的头发。"

    no "奥古斯特..."
    c ".........."
    c "没事的，我在这里。"
    no "真的吗？你真的是他吗？"
    c "如果...这就是你的愿望。"
    no "如果这是真的，那就是我的愿望。"
    c "...."
    c "即使真相在这里也可能是主观的，诺亚。我会成为你需要我成为的任何人。"
    "克劳轻轻地叹了口气。"
    c "...你在这里做什么？"
    "诺亚擦了擦眼睛，深吸了一口气。"
    no "...我..."
    no "这是个很长的故事。"
    c "我有的是时间。"
    no "..."
    no "我会简单地说..."
    no "我闯入了一栋政府大楼，然后从十一楼的窗户跳了出去，然后...就到了那个梦境里。"
    "克劳惊讶地眨了眨眼睛。"
    c "你...什么？"
    no "我知道这听起来很疯狂...我只是..."
    nothought "想知道你是不是真的奥古斯特。如果这是可能的。"
    no "...我只是...想了解更多关于那些死亡的事。"
    c "啊，原来如此...这真是太危险了，诺亚。我不知道你竟然能做出这种事。"
    c "我都快佩服了。"
    no "我们...到底在哪里？"
    c "这里是...我想你可以把它当作梦境之间的深渊。它没有特定的位置。"
    no "这样的地方真的存在？"
    c "是的，但你不应该试图来到这里。这里可能很危险。"
    no "那你为什么在这里？"
    c "我想我是在等待。"
    no "等什么？"
    c "这一部分我还没完全想清楚。"
    no "但是...如果这是梦境之间的地方，那就意味着..."
    no "你是真的？"
    "克劳的笑容只是一瞬间的失落，然后他轻声笑了。"
    c "我会成为你需要我成为的任何人。"

    scene bg empty dream:
        xpos 0.84 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.84
    show crow m sadsmi at slightright
    show noah m ann at slightleft

    with Fade(1.0, 1.0, 1.0)

    "克劳举起手，示意诺亚也这样做。他们的手掌轻轻地贴在一起。"
    c "感觉温暖吗？"
    show noah m sho with dis
    no "我...好像是的。"
    c "很好。那就足够了，不是吗？"
    no "........"
    show crow m sho with dis
    c "我胸中有一种奇怪的感觉..."
    show crow m shysur with dis
    "克劳有些羞涩地把手收了回去。"
    c "你真的应该走了。就像我说的，不要自己来这里。我不想你也迷失在其他灵魂之中。"
    show noah m sca with dis
    no "你什么意思？"
    show crow m sad with dis
    c "嗯..."
    "他似乎不太想告诉诺亚这件事，但还是继续说了下去。"

    c "在梦中死去的人会被困在这里，可能永远也出不去。他们没有继续前进的特权。"
    no "这听起来太可怕了。"
    c "是的。这就是为什么你不应该来这里。"
    no "但是你呢？这对你来说也很危险，对吗？"
    c "也许我已经是迷失在这片海洋中的一个灵魂了。我也不太确定。"
    show crow m neu with dis
    c "但你不必为我担心。只要你平安，我就永远都好。"
    no "...."
    "不知为什么，诺亚脑海中浮现出克劳独自坐在这片虚无之中等待的画面。他感到心中一阵抽痛。"
    show noah m neu with dis
    no "我想让你帮我。"
    show crow m sho with dis
    c "原谅我？"
    no "我想要阻止那些谋杀案。"
    c "你...想要阻止它们？为什么？"
    show noah m ann with dis
    no "也许我们在这方面很相似。我也不太确定。"
    no "我只知道，我过去的一些人正接连死去。有人一直在问我，为什么你在乎？为什么你想要帮忙？"
    no "我已经说过很多次我不知道，但我就是想这么做。"
    c "...."
    c "这些死亡让你感到难过吗？"
    c "或者这个问题的答案也是\'我不知道\'？"
    show crow m hap with dis
    "诺亚点了点头，一种如阳光般的笑容在克劳脸上绽放开来。"
    c "你长大了很多，诺亚。"
    no "....?"
    c "我可以问你一个问题吗，诺亚？"
    no "当然，我会尽我所能。"
    c "再次来到这里，似乎让你重拾绘画的兴趣了，是吗？"
    show noah m sho with dis
    no "你怎么会...？"
    c "只是一种预感。"
    c "与我们第一次见面相比，你似乎..."
    show crow m neu with dis
    c "现在活力满满了。"
    show noah m ann with dis
    no "...没错。在那之后...自从..."
    no "我多年来都无法正常地绘画，但现在每次来到这里，我都能畅快地创作。"
    "克劳若有所思地点了点头。"
    c "出于自私的原因去做善事也没什么不好的。"
    c "那么...我会帮助你的。无论我能做些什么。"
    show noah m sho with dis
    no "真的吗？"
    c "当然。如果我能对你有所帮助，那我就很高兴。"
    no "那么...如果我们使用你的护身符，我们就能提前保护那些可能受到攻击的人，对吗？"
    c "没错。"
    no "...好吧。我需要一些时间来想一想可能会成为目标的人。"
    no "有没有..."
    show noah m ann with dis
    no "有没有什么方式我可以联系你，告诉你我的发现？"
    nothought "电话号码、电子邮箱，或者任何地方，我想在现实中见到你。"
    c "不用担心。当你进入他们的梦境时，我会在那里。"
    "突然，克劳回过头，好像能看到诺亚看不到的东西。"
    show crow m sadsmi with dis
    c "是时候让你离开了，诺亚。请相信我，当你需要我的时候，我会在那里。"
    show noah m sho with dis
    no "等一下—"
    "诺亚抓住了他的书包。里面放着他的旧素描本和一支铅笔，等待他取出。"
    no "我想要—"
    show crow m hap with dis
    c "再见，诺亚。呼唤我，我会在你身边。下次再见。"

    window hide
    show black with dis2
    show transition movie onlayer overlay
    pause 3.0
    window show
    stop music fadeout 4.0

    "诺亚周围的世界瞬间消失了，他向后倒去，陷入了虚无。他感觉内心在下落中发生了变化，这种感觉在那天变得越来越熟悉。"
    "他一直在下落，直到不再下落。"

    scene bg paint day with hpunch
    "他重重地摔在水泥地上，画具和画布四处飞散。他发出一声大呻吟，背部传来阵阵疼痛。"
    play music youneverhaveto fadein 3.0
    no hur "妈的..."
    "但他的怒气并没有持续太久。他的目光落回到画布上，然后从书包里取出了他那已经磨损的素描本。"
    no ann "我可以做到的...这次，我确定我能做到..."
    "他的铅笔飞快地移动着，思绪也随之飞快地运转，勾勒出烙印在他脑海中的面容。"
    "每一笔都很顺畅，不久他就欣赏着自己的杰作。"

    show popout
    show crow_drawing_popup
    with dissolve
    no sho "奥古斯特..."
    no ann "奥古斯特？不，这是...克劳。"
    "这幅画让他心跳加速，但当他看着它时，他并没有看到奥古斯特。"
    "他看到的是一个截然不同，却又似曾相识的人。"
    hide popout
    hide crow_drawing_popup
    with dissolve
    "小心翼翼地，他把本子放下，摇摇晃晃地走向沙发。突然间，这一切发生的事情都压垮了他，他瘫倒在沙发上。"
    "电视还开着，就像伊万离开时一样。"

    nothought "...这次他到哪里去了？"
    nothought "他真是疯了。他从窗户跳下，就像什么都不是一样。"
    "电视上正在播放早间新闻。诺亚用手捂住头，感觉已经隐隐作痛的头疼变得更加严重。"
    nothought "难怪我这么累。上次好好睡觉是什么时候？我什么时候能好好睡一觉？"
    nothought "但是没时间了..我需要...我需要制定一个计划...这样我就能再次见到克劳。"
    nothought "谁成为了目标？我的母亲、我的父亲...弗洛伊德先生和塞巴斯蒂安。艾许也是。"
    nothought "天啊，我太累了..."
    tv "转到其他新闻，官方对这个在网上迅速走红的视频感到困惑。让我们来看看。"
    no ann "你能不能闭嘴？我正在思考—"
    "屏幕上，一部抖动的手机摄像头记录下了远处一栋高楼。在里面，可以看到两个人从窗户坠落，然后消失不见。"
    tv "警方已经封锁了现场，正在对大楼内的工作人员进行询问。到目前为止，还没有发现任何尸体。"
    tv "如果您有任何信息，可以匿名致电—"
    "诺亚迅速按下遥控器上的电源按钮，屏幕变黑了。"
    no hur "啊..."
    no ann "就好像事情还不够糟糕似的。"
    no "凯恩要杀了我。他真的会杀了我。我应该...我应该先给他打个电话。"
    play sound knock
    "在他有机会完成这个想法之前，诺亚家的前门传来了一阵响亮的敲门声。"
    no sho "...或者不是。"
    "已经筋疲力尽的诺亚迅速打开了前门，但站在门口的人并不是他所预料的。"
    "不是凯恩，也不是伊万。甚至连克劳也不是，尽管那会很令人惊讶。"
    stop music fadeout 2.0
    no sho "弗...弗洛伊德先生？"


    $camera_move(0, -877, 445, 0, duration=0)
    show mf n dim sur glasses at slightleft
    show noah n dim sho at slightright

    with dissolve

    mrf "诺亚。"
    "他立刻试图把门关上，但还是让那个男人把脚伸了进来。"
    show noah n dim ann with dis
    play music nothing fadein 3.0
    no "我没什么好跟你说的。请离开。"
    show mf n dim sad with dis
    mrf "等等，拜托，就等一下。"
    no "........"
    mrf "我们能聊聊吗？"
    "诺亚不确定地透过黑暗盯着他。"
    "他脸上的表情让诺亚犹豫了。不确定地，他打开门让那个男人进来。他看到一片凌乱，只是摇了摇头，好像并不在意。"
    show mf n dim smi with dis
    mrf "你...长大了不少，是吧？"
    show mf n dim sho with dis
    mrf "我是说，这是意料之中的事，但是...嗯...抱歉，我不太擅长这个..."
    show noah n dim fro with dis
    no "...你来这里干什么？你想要什么？"
    show mf n dim sad with dis
    mrf "...你不会回我的短信。"
    no "没错。"
    no "我压根就没用手机给你发过信息。"
    mrf "原来是这样..."
    "诺亚的老师望着房间里散落的半成品画作。"
    show mf n dim neu with dis
    mrf "你一直在画画。"
    no "偶尔会。"
    show mf n dim sad with dis
    mrf "我...听说了当年的奥古斯特的事，我—"
    show noah n dim ann with dis
    no "你能告诉我你为什么来这里吗？你是怎么找到我的？"
    mrf "...我试着给那个发短信的号码打电话，但没有人接。然后我试着查找你，但是找不到你的任何信息..."
    no "怎么样？"
    mrf "我设法找到了你的哥哥。他还住在你们以前的地方。他告诉我你大致去了哪里，所以我一直在...四处打听你的下落。"
    nothought "好吧...我还得回他的短信呢..."
    show noah n dim sca with dis
    no "好吧。这解释了你是怎么找到我的，但如果你是来道歉的，就省省吧。"
    no "我不想听你的空话。"
    mrf "...前几天我梦到你了。奇怪的是，我发誓...你看起来就像现在这样，而不是我最后一次见到你的样子。"
    "诺亚抱起双臂，嘴唇紧闭。"
    show mf n dim neu with dis
    mrf "我不是来道歉的，不如说是来...解释的。"
    no "........"
    "诺亚保持沉默。不知为什么，这些话对他来说比道歉更有意义。"
    "解释。这就是他想要的。为什么？为什么他会那么做？"
    mrf "你还和你父母保持联系吗？"
    no "他们都死了。"
    show mf n dim sur with dis
    mrf "什么？！"
    mrf "我...我很抱歉...发生了什么？"
    show noah n dim neu with dis
    "诺亚耸了耸肩。"
    no "你有看新闻吗？他们也卷入了那件事。"
    show mf n dim sad with dis
    mrf "天哪，诺亚...我不知道..."
    show noah n dim ann with dis
    no "我对此并不悲伤，所以不需要装出一副伤心的样子。"
    mrf "当然不需要。"
    "他的老师深吸了一口气。他看起来和诺亚上次见到他时差不多-同样的善良眼神和宽阔的肩膀。他有一种让人可信赖的气质。"
    "这才是问题所在。"
    mrf "当时发生的一切...你我之间的事，都是一个巨大的误解。我们两个都被利用，被对方推翻。"
    show noah n dim fro with dis
    no "你是被我母亲雇来装作和我亲密，好把我说的一切告诉她的。我哪里理解错了？"
    show mf n dim sur with dis
    mrf "那...根本不是这么回事。"
    mrf "当你告诉我你对奥古斯特的感情时，我从未打算告诉任何人。怎么可能？你信任我告诉了我，我也不会做出任何会让你的生活变得更困难的事，在你准备好之前告诉任何人。"
    show mf n dim sad with dis
    mrf "而且有你那样的父母...我认为让他们知道也不安全。为什么你要因为一个简单的迷恋而受到惩罚呢？"
    show noah n dim hur with dis
    no "......"
    show noah n dim fro with dis
    no "那么他们是怎么知道的？通过读心术吗？"
    mrf "我不知道。当我那天晚上离开你，在我们最后一次辅导课后，你母亲把我拉到一边，狠狠地打了我一耳光，比我以前受过的任何打击都要重，然后解雇了我。"
    show noah n dim sho with dis
    no "什么？"
    mrf "直到现在我也不知道发生了什么，但不知何故她听到了我们说的一切。不知是你房间被监听还是她每次我们在一起的时候都贴着门听，我都不知道。"
    show noah n dim ann with dis
    no "...操...这听起来就像她会做的事..."
    mrf "她威胁说如果我再跟你说话，就会向学校董事会举报我。所以我不得不那样做。"
    mrf "...但解释就到此为止了。现在我必须道歉，不管这对你是否有意义..."
    mrf "我把事业看得比学生的安全更重要。你需要我的支持，但我却是个懦夫。"
    mrf "对不起，诺亚。我永远也无法弥补。"

    no "........"
    "如果他不那么疲惫的话，也许他会再次哭泣。但现在，他只能发出一声嘶哑的呻吟。"
    no "你当时为什么不告诉我？"
    show mf n dim sadopen with dis
    mrf "我很抱歉..."
    mrf "这没有任何解释。我是害怕，我辜负了你。对不起。"
    show noah n dim fro with dis
    no "....."
    show noah n dim ann with dis
    no "我想也不是你的错。"
    no "...那我现在该怪谁呢？"
    "这个问题并不是针对任何人的。事实上，他意识到自己是几分钟后才大声说出来的。"
    show mf n dim sad with dis
    mrf "...我把你一个人留下，没有人支持你。我当时不够强大。你可以随意责备我。"
    no "…谢谢你，弗洛伊德先生。我很感激你告诉我真相。"
    mrf "...."
    mrf "我很抱歉奥古斯特的事。我知道他对你来说很重要。"
    "诺亚漫不经心地看向他画的克劳的素描。"
    mrf "他是个…奇妙的孩子。一个似乎很喜欢你的奇妙的孩子。"
    "诺亚沉默地回应——回答就是接受。接受他永远离开了。"


    menu:
        mrf "你快乐吗，诺亚？"

        "是的":
            show noah n dim sca with dis
            no "...快乐可能是个过于夸张的说法，但我...正在努力。"
            show noah n dim ann with dis
            no "我正在努力找到一种新的正常生活。我正在努力找回一些我失去的东西。我正在努力...和人在一起..."
            show mf n dim neu with dis
            mrf "我为你感到骄傲，诺亚。尽管这可能微不足道，但你...你已经走了这么远。"
            show noah n dim neu with dis
            no "我并不觉得是这样。"
            no "感觉更像是我已经被困在同一个地方多年了。"
            show mf n dim smi with dis
            mrf "但你一直在画画。你一直保持着你父母不想让你拥有的那个特别的东西。"
            show mf n dim neu with dis
            mrf "我希望你能找到真正的幸福，诺亚。我知道这听起来有些陈词滥调，但我确实相信有时候...坏事会导致好事。"
            mrf "这些就是我希望你能得到的。"


        "不":
            show noah n dim sad with dis
            no "我什么都没有。"

            no "我在这个朋友给我的愚蠢的房子里浪费了多年的生命。我无法画画。我与世界隔绝。"
            show noah n dim hur with dis
            no "我失去了我觉得是一切的东西。"
            show noah n dim sad with dis
            no "我怎么可能现在就快乐呢？"
            show mf n dim sadopen with dis
            mrf "...走向好转的第一步就是认识到需要改变。"
            mrf "我听出你已经认识到了这一点。"
            show noah n dim ann with dis
            no "...."
            no "我在努力。"
            no "自私地。"
            mrf "有时候自私也没什么不好的。"

    show noah n dim ann with dis
    no "...谢谢你，弗洛伊德先生。"
    mrf "我不想占用你更多的时间-但是拜托，诺亚，如果你需要任何帮助，随时给我发消息。"
    mrf "我保证我会在那里。让我弥补我的错误。"
    mrf "如果你需要我，我会在这里。"
    "他的手搭在门把手上。"
    no "...弗洛伊德先生？"
    no "我..."
    no "...很高兴见到你。"
    hide noah
    hide mf
    with dissolve
    play sound doorclick
    "他微笑着点了点头，然后转身离开。门在男人身后轻轻关上。"
    nothought "我现在应该怪谁呢？"
    nothought "我该拿这些仇恨怎么办？"
    nothought "奥古斯特，你会怎么做？"
    no ann "哈哈...."
    "诺亚嘲笑般地笑了笑。"

    nothought "他会一如既往地接受一切，不是吗？在这样的时候，他会告诉我保持乐观，对吗？"
    "诺亚的眼皮开始下垂。那天发生的一切终于追上了他。"
    stop music fadeout 6.0
    "他甚至没有力气从沙发上移到卧室。他的眼皮最终合上，背部陷入了破旧的沙发。弹簧压迫着他，但他似乎并不在意。"

    scene bg classroom night
    show noahteen m dark neu at slightleft
    show august m dark sur glasses at slightright
    with Fade(1.0, 3.0, 1.0)


    a "诺亚？诺亚，你醒着吗？"
    noteen "嗯..."
    play music moment fadein 4.0
    a "快点，该走了。看看外面已经这么黑了！"
    noteen "...我睡着了吗？"
    show august m dark neu with dis
    a "你睡得很沉。"
    show noahteen m dark sho with dis
    noteen "........."
    "诺亚环顾四周。"
    "对，教室。"
    "一切都如常。"
    show noahteen m dark neu with dis
    noteen "凯恩在哪里？"
    show august m dark hap with dis
    a "他在外面等着。"
    noteen "...."
    noteen "我...."
    "诺亚的目光扫过这个场景。"
    nothought "对...一切都如常。"
    show noahteen m dark sad with dis
    noteen "我感觉就像...刚刚做了一个很糟糕的梦。"
    show august m dark sho with dis
    a "你也是吗？"
    show noahteen m dark sho with dis
    noteen "...?"
    show august m dark pou with dis
    a "这里还有另一个人...然后他消失了...凯恩告诉我我一定是在想象。"
    show noahteen m dark sur with dis
    noteen ".........."
    noteen "哦...."
    show noahteen m dark sad with dis
    noteen "好的..."
    "诺亚的目光重新落在窗外的星星上。"
    "他记得。"
    noteen "..........."
    show august m dark sad with dis
    a "有什么不对吗？"
    show noahteen m dark neu with dis
    noteen "...没什么。"
    noteen "很高兴再次见到你，奥古斯特。"
    show noahteen m dark shy with dis
    noteen "这...让我想起了第一次。当我看到你的梦境时。"
    show august m dark sho with dis
    a "....?"
    show august m dark hap with dis
    a "我也很高兴见到你，但你随时都可以见到我，傻瓜。"
    show noahteen m dark sad with dis
    noteen "我真希望能这样。"
    "奥古斯特做了个鬼脸，表示他真的不明白，但他还是很高兴。"
    "诺亚的胸口一阵刺痛，但这次他并没有感到那么迷失。"
    show noahteen m dark neu with dis
    noteen "最近发生了很多事。"
    a "哦？"
    "奥古斯特拉过一把椅子坐到诺亚的桌前，脸上带着感兴趣的表情。"
    noteen "...我最近见到凯恩的次数变多了。"
    a "那真好。他是你如此好的朋友，这让我很高兴。"
    show noahteen m dark pou with dis
    noteen "连弗洛伊德先生也来过我家。"
    show august m dark sur with dis
    a "弗洛伊德先生？真的吗？"
    noteen "是的。我们解决了问题。那只是一个大误会。"
    noteen "当时我没有意识到，但现在我明白了。"
    show august m dark hap with dis
    a "我很高兴。你在努力工作，诺亚。"
    show noahteen m dark neu with dis
    noteen "我也认识了一些新朋友。"
    a "你能告诉我他们的事吗？"
    noteen "...可能会很无聊。"
    a "我喜欢听你的声音。"

    no "........."

    nothought "我上次做梦是什么时候？上次梦到你是什么时候？"
    nothought "引导你相信这是真实的，我是不是太自私了？"
    nothought "我是不是太痴迷于此了？"
    nothought "这不过是我的梦境。你不过是我梦中的人。"
    "某个人的话语在诺亚的脑海中回荡。"
    c "{i}什么才算是真正的人？{/i}"
    nothought "我..."
    nothought "我不知道……"
    c "{i}我现在就存在于此，这就足够了。{/i}"
    nothought "...这就足够了。此刻就足够了。"

    no "...好像有人搬来和我一起住了。"
    show august m dark sur with dis
    a "搬来和你一起住？什么时候的事？"
    no "就是突然发生的...违背我的意愿。他叫伊万。他有点奇怪...有闯入和偷窃的习惯...但是..."
    no "...再次有人陪伴真好。"
    a "我们...我们应该报警吗？"
    "诺亚只是摇了摇头。"

    show noahteen m dark hap with dis
    no "没事的。他其实也没那么糟糕，不过可能是个杀人犯，我也不太确定。"
    show august m dark sca with dis
    a "你现在让我更担心了！"
    no "对不起。"
    no "我还认识了另一个人。"
    a "希望他会更好相处一些。"
    show noahteen m dark neublu with dis
    no "...他让我很多地方都想起了你。"
    show august m dark hap with dis
    a "像我？那他一定很了不起了！"
    "奥古斯特笑了，显然是在开玩笑。"
    show noahteen m dark poublu with dis
    no "...是的。他确实很了不起。就像你一样。"
    a "...你看起来很快乐，诺亚。我很高兴。"
    no "我怎么能不高兴呢..."
    "诺亚的目光落在奥古斯特身上。"
    "或者说，落在他认为奥古斯特应该在的地方。他眨了眨眼睛。"

    scene black with eye_shut_fast
    pause 0.2

    scene bg classroom night
    show noahteen m dark poublu at slightleft
    show crow m dark neu at slightright
    with eye_open_fast

    "但那里站着另一个人影。"
    show noahteen m dark sur with dis
    no "........."
    c "有什么不对吗？"
    no "不，我..."

    scene black with eye_shut_fast
    pause 0.2

    scene bg classroom night
    show noahteen m dark sur at slightleft
    show august m dark sho glasses at slightright
    with eye_open_fast
    "诺亚摇了摇头，重新看向奥古斯特。奥古斯特仍然坐在那里，脸上带着担心的表情。"
    no "我以为我看到了..."
    no "...."
    show august m dark hap with dis
    a "只是我而已。"
    show noahteen m dark neu with dis
    no "对，对，是你..."
    a "总之，你知道我很喜欢和你聊天，诺亚，但也许我们可以边走边聊？凯恩还在等我们。"
    show noahteen m dark sad with dis
    no "..."
    show noahteen m dark sca with dis
    "诺亚看着奥古斯特。他仔细端详着他的面容，将每一个细节都牢牢记在心中。"
    "这就是他所认识的奥古斯特。但这不是他的奥古斯特。"
    "这终究只是一个梦境而已。"
    no "你先走吧，好吗？"
    show august m dark pou with dis
    a "为什么？"
    no "....."
    show noahteen m dark sad with dis
    no "我无法跟随你的脚步。即使我想要。"
    a "....."
    a "好吧，但记得你有我的号码，好吗？"
    show august m dark hap with dis
    a "你只需要呼唤我，我就会在这里。你知道的，对吗？"
    "那些熟悉的话语在房间里回响，房间似乎在瞬间扩大和收缩。"
    hide noahteen
    hide august
    with dissolve
    "周围的一切开始渐渐变黑，诺亚的意识开始苏醒。"
    nothought "呼唤我，你就会在那里？"
    nothought "那醒来之后呢？我的话真的能把你带回来吗？"
    nothought "这么简单吗？"
    nothought "那么，我就呼唤你的名字..."
    noteen neu "奥..."
    noteen sad "奥..."
    noteen "克劳。"

    show crow m dark neu
    $all_moves(camera_check_points={u'x': [(5291, 0, u'ease'), (774, 5.04, u'ease')], u'z': [(738, 0, u'ease')]})
    with dissolve

    "在那片黑暗的中心，站着一个单独的身影。"
    c "我在这里。"
    c "一切都会好起来的。"
    noteen sur "你真的来了..."
    c "我不是说过吗？"
    show crow m dark hap with dis
    c "不过，比我预期的要早一些，我不得不承认。"
    "克劳轻笑了一声，脸上洋溢着光彩。"
    noteen sho "...."
    "无言地，诺亚伸出双臂拥抱了那个金发男子。他能感受到一个真实的人的体温。"

    $all_moves(camera_check_points={u'z': [(738, 0, None), (876, 0.2, u'ease')]})
    show crow m dark sho with dis
    c "啊...！"
    c "你还好吗？"
    "诺亚点了点头，克劳也回抱住了他。"
    show crow m dark sadsmi with dis
    c "是时候让你醒来了，诺亚。"


    $all_moves(camera_check_points={u'y': [(-877, 0, None), (-359, 3.0, u'ease')], u'z': [(876, 0, None), (270, 3.0, u'ease')]})

    c "你最近一直在做很多梦。我不得不承认，看到你这么频繁地出现让我很自私地感到高兴-但我希望你也能好好休息。"
    noteen sad "...."
    noteen "太难了。每天醒来都在挣扎...实在是太难了..."
    noteen "也许留在这里会更好..."
    noteen "像你告诉我的那样，在云端飘荡..."
    noteen "我想变得更好，但我也只想...停下来。"
    show crow m dark neu with dis
    c "......."
    c "但你比那更强大，不是吗？"
    "诺亚发现自己不由自主地点了点头。"
    show crow m dark sadsmi with dis
    c "当然...如果..."
    c "...如果..."


    menu:
        c "...算了。"
        "问他":
            $ CrowPoints += 1
            noteen "如果什么？"
            c "这是一个我不会强加于你的自私的请求。"
            noteen neu "........"
            noteen "什么地方有错在自私？"
            c "......."
            c "我会很高兴如果你能在梦中多花些时间。仅此而已。"
            noteen sho "那么-"
            c "但我会更高兴看到你继续活下去。你还没有完成你的杰作呢，对吗？"
            noteen sad "...好的。"
            c "那么现在，继续挣扎。挣扎到你自由为止。"


        "放弃":
            "诺亚不禁注意到克劳的手指在他背上抽搐和掐进。"
            "但不知为什么，他无法问出那是什么。"
            "最后，他决定回抱得更紧一些。"


    show crow m dark neu with dis
    c "好了，是时候醒来了。一切都会好起来的。"
    noteen "好吧..."
    noteen neu "...我很快就会再见到你，好吗？"
    show crow m dark hap with dis
    stop music fadeout 3.0
    c "随时随地。"

    scene bg paint day
    $ camera_reset()

    with Fade(1.0, 3.0, 1.0)

    no sho "......"
    i neu "做噩梦了？"
    no sur"啊！"

    show ivan n dim neu at slightleft
    show noah n dim sur at slightright
    with dissolve

    $all_moves(camera_check_points={u'z': [(0, 0, None), (489, 1.19, u'ease')]})
    play music herehecomes fadein 3.0
    i "不用大喊大叫。"
    show noah n dim ann with dis
    no "你他妈是从哪里冒出来的？"
    "诺亚从沙发上坐了起来，感到肌肉酸痛。他伸展时，肩膀发出了响亮的咔嗒声。"
    i "前门。你忘了锁门。"
    no "对，好吧..."
    no "很高兴看到你没事。"
    i "从什么时候开始你会关心我是否安好了？"
    show noah n dim fro with dis
    no "好吧，我不在乎。你为什么耽搁这么久？"
    show ivan n dim frosmi with dis
    i "有一些警犬和警察追捕的事情。别担心。"
    show noah n dim sho with dis
    no "....."
    show noah n dim ann with dis
    no "我...我就不问了。至少希望你没有把任何人带回来。"
    show ivan n dim neu with dis
    i "别担心，这不是我第一次这样做了。"
    no "这只会让我更担心。"
    i "你得到你需要的信息了吗？"
    show noah n dim neu with dis
    no "没有，并没有。"
    show ivan n dim neufro with dis
    i "很好。我很高兴我们没有白白闯入一栋政府大楼，从十一楼跳下来。"
    no "是你逼我这么做的，不是我自己想的。"
    show ivan n dim neu with dis
    i "好吧。你饿了吗？"
    no "快饿死了。"
    "伊万从他那巨大的口袋里掏出各种看起来不太健康的零食。"
    show ivan n dim sca with dis
    no "....."
    show ivan n dim frosmi with dis
    i "至少没有空手而归。"
    no "哈...随便吧，把那个给我。"

    "时间在两人吃零食的声音中悄悄流逝。"
    no "现在几点了？"
    show ivan n dim neu with dis
    i "我不知道，大概4点吧。"
    show noah n dim sca with dis
    no "我感觉好像忘记了什么事情..."
    show noah n dim sho with dis
    no "..."
    show noah n dim hur with dis
    no "啊...该死。凯恩。"
    i "他和这有什么关系？"
    no "呃，操...一切都乱成一团了..."
    show ivan n dim neufro with dis
    i "你打算解释清楚还是自己喃喃自语？"
    no "你和我今天早上出现在新闻上了。"
    show ivan n dim neu with dis
    i "那我什么时候能领到版税支票？"
    show noah n dim sca with dis
    no "我们被拍到从凯恩的办公室里掉下来。警察到处在找我们。"
    no "很快他们就会发现我们用了凯恩的卡——"
    play sound ringing
    "铃铃铃。"


    no ".....操。"

    hide noah
    hide ivan
    with dissolve

    $all_moves(camera_check_points={u'z': [(489, 0, None), (43, 2.19, u'linear')]})
    "诺亚不情愿地从沙发上跳起来，接起了电话。"
    no sca "我睡着的时候手机响了吗？"
    i neu "是的。"
    no "响了几次？"
    i "我不知道，大概七次左右？我没数。"
    no hur "我完蛋了。你为什么不叫醒我？算了，不重要了。"
    no ann "你好？"
    stop music fadeout 4.0
    k ang "你他妈到底在哪里？！"
    "凯恩的声音介于尖叫和耳语之间，好像他现在不应该打电话。"
    play music nothing fadein 3.0
    no "呃...睡觉。听着，我想我知道这是关于什么的——"
    k fro "哦，我很确定你知道。我真的不敢相信你会这样。"
    k "你在家吗？"
    no "是啊..."
    k "待在那里别动。我马上过去，我们出去谈谈。"
    no "...好吧。"
    "电话那头陷入了沉默。"
    i "听起来进展不太顺利。"
    no "他要杀了我。"
    i "真的吗？我觉得他对你还是挺喜欢的。"
    no "我会很惊讶如果他现在还没有恨我了。"
    "前门在10分钟内被打开。进来的人眼睛通红，眉头紧锁。"

    show kaine n dim fro at slightleft
    show ivan n dim neu at farright
    show noah n dim ann at slightright
    with dissolve



    no "凯恩，我——"
    k "我整天都在接受警察的审问，你知道吗？"
    no "......."
    show noah n dim sad with dis
    no "我——"
    show kaine n dim sad with dis
    k "还被我的老板骂了一顿。我可能会被解雇。"
    no "我—"
    k "我只能坐在那里承受一切。我能说什么呢？我最好的朋友做的？"
    k "我最好的朋友偷了我的ID卡，闯入一栋政府大楼，然后对我的电脑做了不知道什么事？"
    k "最糟糕的是，他还从我的窗户跳了下去，然后消失了。"

    i "如果有帮助的话，偷东西的人是我。"
    i "你可以把我交给警察，如果你想的话。对我来说没什么区别。"
    show kaine n dim fro with dis
    k "不，这没有帮助。你在这里的事实本身也没有帮助。"
    show noah n dim hur with dis
    no "我只是...凯恩，听着，我想要..."
    k "想要什么？毁掉我的生活？"
    k "你一直想要的就是让我离开你...这是你让我真的滚蛋的方式吗？"
    show noah n dim sad with dis
    no "不，我..."
    i "如果我要猜的话，我会说他想要证明这个\'奥古斯特\'真的死了。"
    show kaine n dim sad with dis
    k "...这是真的吗？"
    no "克劳是—"
    show kaine n dim fro with dis
    k "不是奥古斯特。他不是真的。"
    show noah n dim sca with dis
    no "你和我一样清楚地看到了他！"
    show kaine n dim sad with dis
    k "诺亚，这太疯狂了！我们都知道他已经死了！"
    k "我是在他的葬礼上独自留下的那个人，在你消失之后！我是在我们的教室里，在他死后没有人留下的那个人！"
    k "他已经不在了。你为什么不能接受这个事实？"
    no "....."
    show noah n dim sad with dis
    no "因为...因为如果我们错了呢？"
    no "你的系统对他的详细信息都有错误...他们说他死于疾病，而且没有葬礼。如果他被困在那里，无法逃脱呢？"
    k "没有系统是完美的，诺亚。这些都是需要修正的细节。我亲眼看到了他的坟墓。你为什么会如此执着于一个幻想？"
    "凯恩叹了口气，揉了揉太阳穴。"
    show kaine n dim fro with dis
    k "听着，我不是来吵架的。我们出去吧。"
    show noah n dim ann with dis
    no "好吧..."
    i "我没有更好的事情可做了。我会跟着你去。"
    k "我没有邀请你，所以请不要自己邀请自己。"
    show ivan n dim ann with dis
    i "好吧。我猜我会在合理的距离后面跟着你走同一个方向。"
    k "..........."
    hide kaine
    hide noah
    hide ivan
    with dissolve
    "凯恩先走了。不知为什么，门在他身后关上的声音让诺亚感到内疚。"
    stop music fadeout 3.0
    "他站起来，拍掉衣服上的碎屑，然后跟在那个男人后面。"

    scene bg streets night with Fade(1.0, 1.0, 1.0)

    "外面，太阳已经在城市上落下了。整整一天都白白浪费掉了，再也无法挽回。"
    play music shift fadein 3.0
    "诺亚很快就追上了凯恩，后者看到伊万也跟来了，并没有说什么。"
    no ann "...我现在真的没钱去吃饭。"
    k sad "你知道，当你和我在一起的时候，你不需要担心这个。"
    "再次，凯恩温柔的话语让诺亚的心中充满了内疚。"
    nothought "我在做什么..."
    no "我不是想让你惹上麻烦的..."
    k "我们先吃饭，然后再谈。"
    i neu "你打算买什么给我们吃？"
    k fro "我不打算给你们买任何东西。"
    i "但是我也没有钱。"
    k "那就在外面等着。"
    no "...我会给你买点东西。"
    k sad "........"
    k "好吧，好吧，随便了，不过我们得去一个便宜的地方，因为我可能很快就要失业了。"
    "凯恩停在一家破旧、陈旧的餐厅前，抬头看着招牌。"
    no sho "呃...也许这不是个好主意..."
    k neu "这里就行了。进来吧。"
    no hur "啊..."
    "他没有留下争论的余地。伊万和诺亚跟在他身后进去了，诺亚低着头，伊万昂着头。"

    scene bg diner night with Fade(1.0, 1.0, 1.0)
    own "喂！你们两个！"
    no ann "啊，糟了..."
    k sur "里面有什么？"
    no "这是...一个长故事。"
    i neu "..."
    i ann "哈。"
    i sad "女士，我们进来是为了道歉，并支付我们欠下的钱。"
    own "你以为这样就能让一切都好起来了吗？！"
    i "我们亲爱的朋友在一次事故中住院了，我们不得不赶到他身边。现在他终于出院了，这是我们的第一站。"
    i "我最诚挚的歉意。我能想象这给你带来了压力，所以我们会付双倍。"
    own "哦...哦，原来是这样的原因..."
    own "好吧，但不要再让这种事发生了，明白吗？"
    i smu "当然不会了。凯恩，我亲爱的朋友，你来付钱吧？"
    k fro "什么...？你来付不就行—"
    "伊万轻轻地用肘部撞了撞那个男人，后者在他和餐厅老板之间来回看着。"
    k sad "...好吧，好吧。那么，要多少钱？"
    own "如果是双倍的话...80美元。"
    k ".........."
    "凯恩不情愿地付了钱，然后瞪了伊万一眼。"
    i hap "我们走了。下次见。"

    scene bg streets night with Fade(1.0, 1.0, 1.0)
    k sur "那是什么鬼东西？！"
    no ann "前几天发生了一点小问题，有人逃避付账。"
    k sad "........."
    k "我觉得这些天你都变得陌生了。"
    "这些话深深刺痛了诺亚，但他无法回应。"
    "凯恩坐在路边，双手捂住脸，深深叹了口气。诺亚悄悄坐在他身边，伊万站在后面。"
    stop music fadeout 4.0
    show noah m dim ann at slightright:
        subpixel True xpos 0.84 ypos 1.0 xanchor 0.8 yanchor 1.0 rotate None
    show kaine m dim sad at slightleft:
        xpos 0.14 ypos 1.0 xanchor 0.2 yanchor 1.0
    with dissolve
    k "我已经不明白发生了什么。"
    play music sunset fadein 3.0
    no "我也不明白。"
    k "我们之间出了什么问题？"
    no "..."
    no "可能是我的问题。"
    k "不，不是你的错。你经历了很多，我理解。我只是想支持你，但是..."
    show kaine m dim ser with dis
    k "告诉我，你为什么那么做？"
    no "...."
    show noah m dim sad with dis
    no "因为..."
    no "我...."
    show noah m dim hur with dis
    no "...克劳。为了他。我只是想确认，看看奥古斯特是不是..."
    show noah m dim ann with dis
    no "如果有可能是他的话..."
    show kaine m dim sad with dis
    k "诺亚，我...我知道..."
    k "我知道你想让他回来。我也知道那个世界感觉很真实。但是..."
    k "那不可能是他。"
    show noah m dim sad with dis
    no "但如果真的是他，我再次把他一个人留在那里怎么办？"
    k "......"
    show kaine m dim ser with dis
    k "那我就证明他们不是同一个人。"
    no "你打算怎么做？"
    show kaine m dim sad with dis
    k "你要回去那些梦境，对吗？"
    no "...我必须去。有人..."
    k "我知道。"
    k "我也知道，不管我说什么，你还是会去。你一直都这样。"
    show kaine m dim ser with dis
    k "我会和你一起去，但你必须答应我，一旦我们证明克劳不是奥古斯特，你就放弃寻找他的事情。"
    show noah m dim sho with dis
    no "........."
    show noah m dim ann with dis
    no "好吧。"
    show kaine m dim sad with dis
    k "很好。"
    no "...."
    no "你的工作怎么办？"
    k "我会和老板商量。你先躲起来一段时间，好吗？不要再从楼上跳下来了。"


    no "我会尽力的。"
    show noah m dim neu with dis
    no "我很抱歉。我知道这句话对你来说不值什么。"
    k "诺亚，你是我..."
    k "我最好的朋友。这从未改变，也不会改变。你的道歉就是我想要的。"
    show kaine m dim hap with dis
    k "好吧，我也希望你能放弃这个梦境的事情，但我知道你很固执。"
    show noah m dim ann with dis
    no "是啊，你一直都最了解我..."
    show kaine m dim neu with dis
    k "我尽力了。"
    k "总之...我猜你可能有人选在心里。"
    no "我...有个想法。"
    no "卢卡。"
    show kaine m dim sur with dis
    k "卢卡？"
    k "说实话，那家伙是个混蛋。不仅仅是个混蛋。我不确定如果他不在这个世界上，会不会更好。"
    k "你为什么在乎？"
    show noah m dim neu with dis
    no "我已经放弃寻找答案了。"
    i neu "我们要去哪里？"
    show kaine m dim fro with dis
    k "谁说你也被邀请了？"
    no "我猜可能会有下一个目标人选...如果不是下一个，也许将来某个时候。一个我上学时认识的人。"
    i "只要能让我离开这里，我就没意见。"
    k "你像个臭虫一样跟着。"
    i "我也可以这么说你。"
    k "我觉得你对诺亚的利益并不真心。"
    i "你怎么想是你的事。"
    k "那你是说你{i}确实{/i}在乎诺亚的利益？"
    i "我没这么说。"
    i smu "我只在乎自己的利益。每个人都是如此。你可以自欺欺人地说你不是，那是你的事。"
    show kaine m dim sad with dis
    k "..."
    k "那你为什么{i}要{/i}跟着他？"
    "伊万只是耸了耸肩，没有告诉凯恩他其他的想法。"
    k "...."
    show noah m dim ann with dis
    no "那你们两个就在这里争论吧，我要走了..."
    i "和他呆在这里？我很好，谢谢。"
    hide noah
    hide kaine
    hide ivan
    with dissolve
    "诺亚转身走进一条阴暗的小巷。"
    "伊万紧跟在他后面，留下凯恩一个人站在街上，片刻后也追了上去。"
    "看着他们的背影，凯恩看到了两个截然不同的人，不禁露出了一丝微笑，那是对逝去时光的一种奇怪的怀念。"

    window hide
    show black with dis2
    show transition movie onlayer overlay
    pause 3.0
    window show
    stop music fadeout 4.0

    "当凯恩走进小巷时，地面在三人脚下突然塌陷了。"
    "伊万似乎对这种感觉过于习惯了。他双腿交叉着倒下，轻松地向后翻滚。"
    "与此同时，凯恩紧紧抱住诺亚，脸色阴沉，双眼紧闭。"
    nothought "他从来就不擅长应付高处，是吗？"

    scene bg stage dark with hpunch

    no hur "呃..！"
    play music drone fadein 3.0
    "诺亚重重地摔在地上。当他坐起来睁开眼睛时，终于发现房间一片漆黑。"
    no ann "凯恩？伊万？"
    "他的问题只有沉默回应。"
    no sad "...伙计们？有人在吗？"
    "诺亚的眼睛在黑暗中四处搜寻，拼命想看清点什么。"
    "远处传来窸窣声。木头上的脚步声。几乎无声的轻笑。"
    "他握紧又松开拳头。"
    nothought "我不想再一个人了。我不想再一个人了。"
    no "...克劳...！"
    "那是脸颊上轻柔的风，手上温和的抚摸，吹散了黑暗带来的焦虑的微风。"
    "这就是他知道他在那里的方式。"
    c neu "我在这里。"
    c "别再担心了，因为我在这里。"
    "仍然坐在只能是地面的东西上，诺亚伸手去抓那个金发男子。最后，他抓住了他的衣袖，紧紧抓住。"
    "但仅仅一刻之后，克劳就离开了。诺亚感到失望，但当克劳握住他的手时，这种感觉很快就消失了。"
    c "什么..."
    c sho "你现在身在何处？"
    c "你总是会出现在奇怪的地方，不是吗？"


    no ann "我...我不知道...我不知道在哪里..."
    "克劳一下子把诺亚拉了起来。手还握在一起，诺亚终于感到放松了下来。"
    "但相反，克劳的声音开始染上了担忧。"
    c sca "我很高兴你没事。"
    c "但我们必须走了。来吧。"
    "克劳开始跑起来。只凭着两人相连的小空间在黑暗中前进，诺亚跟在他身后。"
    no sho "怎么了？为什么我们必须离开？"
    c "这个梦有问题。它...扭曲了，不安全。"
    no sur "等等——另外两个人和我一起来的...！"
    c sho "其他人？"
    no "凯恩和伊万。"
    c sad "凯恩..."
    "他的声音里有认出的意味。"
    "克劳在黑暗中搜寻，好像他的眼睛比诺亚的看得更清楚。"
    c sca "他们在哪里...我不明白你们是怎么分开的..."
    c "你们三个为什么都来这里？"
    no ann "我..."
    no "这个人...我以为...他们可能会成为下一个目标，所以..."
    no "他们想来帮忙..."
    "这个认知像卡车一样撞击了诺亚。"
    no sho "如果这里很危险...你不应该来。我...我不想让你陷入危险。"
    c neu "诺亚，那从来都不是一个选择。"
    no "为什么...？"
    c hap "你呼唤我，我就会永远在这里回应你。无论时间还是空间，只要你需要我，我就会在这里。"
    no ann "........"
    "诺亚艰难地吞了口唾沫。"
    "这些话刺透了他。"
    stop music fadeout 3.0
    no sad "奥—"

    scene bg stage:
        xpos 0.5 ypos 1.16 xanchor 0.5 yanchor 1.0 zoom 1.38
    play sound spotlight

    no sho"什么？"
    "一束聚光灯突然照亮了黑暗，照亮了房间和大舞台。"
    no sur "凯恩！伊万！"
    "在中间，看起来同样迷茫和困惑的，正是伊万和凯恩。"


    $all_moves(camera_check_points={u'y': [(2667, 0.0, u'ease'), (-1133, 4.19, u'ease')], u'x': [(548, 0.0, u'ease')], u'z': [(862, 0.0, u'ease')]})
    show luka m neu
    with dissolve
    play music youneverhaveto fadein 4.0
    l "咳咳咳。这东西开了吗？"
    "一个声音从四面八方响起。"
    show luka m smi with dis
    l "女士们，先生们，男孩们和女孩们！欢迎来到—"
    "一个第三个男人出现在舞台上，带着一个终生在剧院工作的人的所有戏剧性。"
    show luka m hap with dis
    l "嗯，我还没想好给它起个名字，但谁在乎呢！"
    "诺亚握紧了克劳的手，全身都僵住了。"
    c sho "卢卡..."
    "他的声音里充满了诺亚无法忽视的认识，他的目光转向了他。克劳只是向他微笑回应。"

    "他的微笑看起来非常孤独。"
    l "喂喂！诺亚！我在跟你说话，你知道吗？"
    k ang "嘿，混蛋，放了我们！"
    i sur "你...."
    show luka m smi with dis
    l "哎呀，是我最喜欢的表弟！你最近怎么样？"
    i "....."
    i sca "我不认识你。"
    "伊万的目光从这个矮个子男人身上移开，但他的眉头有些抽搐。"
    nothought "他们...是亲戚？还是卢卡又在捉弄我？"
    nothought "我永远分不清他什么时候在说谎，什么时候在说实话..."
    show luka m hap with dis
    l "总之，总之，我跑题了！今晚我为我们的观众准备了一个有趣的节目——一个真实的谋杀案！你可不常见到这种东西吧？"
    no "这是什么..."
    l "没错，各位。今晚结束时，这里会有一个人死掉！哦，我很好奇会是谁？！"
    "卢卡笑着向看不见的观众挥手，然后他的目光锁定在克劳身上。"
    show luka m sur with dis
    l "哦，我们好像在哪里见过...啊，你是奥古斯特对吧！真是我的失误。"
    "克劳皱了皱眉头，但没有否认。"
    show luka m sad with dis
    l "你不是已经死了吗？太遗憾了！"
    show luka m hap with dis
    l "嘿，这并不意味着有人能逃脱死亡！那太容易了！"
    "在低声下气的声音中，诺亚听到了他的话。"
    c sad "...我现在在这里了。而且我就是我。"
    c "这不够吗？"
    "他的声音在最后渐渐消失，好像连他自己也无法回答这个问题。"
    "卢卡从舞台上大笑，完全不担心克劳自言自语的事。"
    show luka m smi with dis
    l "死活不重要，戏还是要继续！"
    no ang "伊万，凯恩，远离他！"
    k ang "我很乐意，但是—"
    i "看来我们被困在这里了。我的腿动不了。"
    l "别担心。凯恩和我亲爱的伊万只是要暂时做我的木偶。"
    no "我们不是来玩你那些愚蠢游戏的...我们是来帮你的，虽然我不知道为什么，你这个疯子。"
    show luka m sur with dis
    l "帮我？你们？"
    show luka m pou with dis
    l "哦，诺亚，你已经给了我足够的帮助了。如果你再给我帮助，我怎么活得下去？"
    no "在高中的时候你好像过得很好啊！"
    show luka m hap with dis
    "卢卡又大笑起来，很是愉悦。"
    l "我很想和你们聊下去，但我有一个节目要组织！很快就回来！"
    hide luka with dissolve
    "在一阵烟雾中，卢卡消失了。凯恩和伊万喘息着咳嗽，但还是站在原地，不管他们愿不愿意。"

    show crow n sad at slightleft
    show noah n ann at slightright
    with dis

    $all_moves(camera_check_points={u'y': [(-1133, 0, None), (-600, 3.22, u'linear')], u'x': [(548, 0, None), (197, 3.22, u'linear')], u'z': [(862, 0, None), (138, 3.22, u'linear')]})
    c "...."
    c "你还好吗？"
    c "这很困难。"
    no "我必须..."
    show noah n hur with dis
    no "我们该怎么办？我们...我们怎么才能把护身符给他，然后离开，如果他什么都不想要呢？"
    c "...他确实有一件想要的东西，就是让我们观看他的节目。"
    show noah n ann with dis
    no "啊...我们真的要这样做吗？"
    no "他说会有人...死掉。"
    show noah n sad with dis
    no "伊万和凯恩...你们...我不能..."
    no "我不能...失去你们..."
    "克劳从诺亚手中抽回了自己的手。突然失去温暖，诺亚敏锐地感觉到了。"
    "克劳走到通往剧院的大双门前，但无论他怎么摇晃，都打不开。"
    show crow n neu with dis
    c "...是的，看来我们真的必须参与进去。但我不会让任何人死。诺亚，只要我在，你什么事都不会发生。"
    no "..."
    show crow n hap with dis
    c "这是我的承诺。"
    "伊万和凯恩的声音从舞台上传来。"



    scene bg stage:
        subpixel True xpos 0.51 ypos 1.31 xanchor 0.5 yanchor 1.0 zoom 1.86 rotate None

    i neu "...我可不太喜欢戏剧。我真的要参与进去吗？"
    k fro "我也不想站在这里。你有什么计划能把我们从舞台上弄下来吗？"
    i smu "没有。我以为你是个聪明人？为什么不用你的大脑想点办法？"
    k "...."
    no ann "...我们会努力寻找离开这里的办法。你们两个，呃..."
    no "练习一下表演吧。"

    scene bg stage:
        subpixel True xpos 0.5 ypos 1.08 xanchor 0.5 yanchor 1.0 zoom 1.32 rotate None
    show crow n sadsmi at slightleft
    show noah n ann at slightright
    with dissolve
    "其他两人继续争论着，而诺亚转回头看向克劳。"
    no "一定有什么我们遗漏的地方。"
    c "...我也希望是这样。"
    show crow n sho with dis
    c "但是...有一些地方确实很奇怪，所以也许..."
    show noah n neu with dis
    no "奇怪？"
    c "...."

    c "感觉...这个梦境不是由一个人主导的。好像有...两个人在主导它。"
    show noah n sho with dis
    no "两个人？但是，怎么会..."
    c "{i}怎么{/i}才是真正的问题...也许如果我们能找到第二个人，就能在发生什么坏事之前结束这个梦境。"
    c "我不会让任何事情发生在你身上，我也会尽我所能保护你的朋友，但是..."
    show crow n sad with dis
    c "在梦境中，任何事情都可能发生。虽然我是梦境的支持者，但我也必须强调这种情况的危险性..."
    show noah n sca with dis
    no "我们在哪里能找到这个人？"
    c "你猜也好不过我...感觉就像...这个梦境周围有一种屏障，在保护着什么...或者把什么困在里面？"
    "回到舞台上，凯恩和伊万怒目而视。如果他们的腿没有固定住，诺亚认为他们可能真的会打架。"
    no "呃...我们先去看看那两个人吧..."
    no "这也让你有机会认识一下伊万..."
    nothought "看看他手臂上的那些标记，也许你能找到什么线索。"
    show crow n hap with dis
    c "我相信你的朋友一定很棒。"
    no "说他是朋友有点勉强..."
    hide noah
    hide crow


    scene bg stage:
        xpos 0.49 ypos 1.17 xanchor 0.5 yanchor 1.0 zoom 1.56

    with dissolve
    "诺亚和克劳走过一排又一排空荡荡的座位，走向舞台。这么大的剧院竟然如此空旷，就像观众在表演中间突然消失，再也没有回来一样。"

    "这真是个了不起的地方——诺亚能想象在这样的舞台上会上演多么精彩的演出。"
    "但现在他们却被困在一个高中时代勒索过他的男孩的梦境里。"
    nothought "太棒了。"
    k fro "哈。我没必须向你解释。你不过是个小偷。"
    i smu "小偷？是啊，没错。但我可不是什么小角色。"
    c sur "好了好了，不要打架。"
    c "我们应该集中精力一起摆脱这种处境。这就是朋友应该做的，对吧？"
    k sad "这里只有一个人我会称之为朋友。"
    "凯恩皱着眉头，把视线从克劳身上移开。他拼命试图移动双腿，但完全动不了。"


    "而伊万则双臂交叉站着，试图装作无所谓的样子。直到他仔细看到克劳，脸上的表情才有所变化。"
    i neufro "......"
    i sur "阳...光？"
    "诺亚顺着他的视线看过去...他盯着克劳。"
    c sho "....?"
    c "对不起，我恐怕不是你在找的那个人。"
    i "但是，你是..."
    i sad "你..."
    "伊万皱起眉头，一脸困惑。"
    nothought "他是不是认识克劳？为什么？"
    i "你不认识我吗？"
    "克劳轻轻叹了口气，但随即又露出了微笑。"
    c sadsmi "对不起。"
    i "...."
    i neu "我的错。大概是光线的错觉吧。"
    "他转过身去，双臂仍然交叉。"
    i sca "原来就是为了这个人才闹出那么大动静。有意思。"
    no sho "什么？没有什么动静啊。"
    "伊万挑起一边眉毛。"
    i neu "要不是为了找出更多关于某人的事，你会闯进政府大楼吗？"
    no ann "喂——！"
    c sur "哦，原来是为了这个原因。"
    no "我们...现在能不谈这个吗？拜托。"
    no neu "你们两个...认识吗？"
    i sca "...."
    c sad "...."
    i neu "没有。我想他只是长得有那么一张脸。"
    c "人们似乎总是这么说我..."
    no ann "好吧...克劳，这是伊万，反之亦然。"
    c hap "很高兴认识你，伊万。谢谢你做诺亚的朋友。"
    i "是啊，我们可是最好的朋友。"
    i "克劳是个有趣的名字。"
    c sur "是吗？"
    i neufro "这确实不是一个普通的名字。事实上，也算不上是个名字。"
    c hap "我想也是！"
    "克劳一如既往地用迷人的微笑掩饰自己不想谈论的事情。而伊万则面无表情地盯着他。"
    k ser "你倒是好意思说我不正常...照照镜子吧。"
    i neu "你为什么一直在说我的样子？"
    i "难道你对我有什么执念？"
    k sur "执念？对你？天啊，我宁愿死。"
    i smu "那就请便。这样对我来说会轻松很多。"
    k fro "..."
    no ann"咳咳..."


    no "更重要的是...你认识卢卡吗？他似乎认识你。"
    i neu "那又怎样？"
    no "你们是亲戚？"
    i "我不知道你在说什么。我从来没见过那个人。"
    "他耸了耸肩。"
    no sca "好的..."
    k neu "说到底，卢卡是个混蛋，你也是。这很合理。"
    i smu "对，因为世界上所有的\'混蛋\'都是亲戚，真是太聪明了。"
    no ann "天啊，你们两个能不能停止争吵，就两秒钟？！"
    k sur "...."
    k sad "对不起。"
    k neu "不过，他为什么会这样呢？"
    no neu "什么样的？"
    k "他只是个孩子。他一点也没变。"
    c neu "嗯...人们会以各种方式梦见自己。无论是现在的样子，还是年轻时的样子..."
    c "也许这就是他认为的\'巅峰\'。"
    k ser "你对梦境了解得真多。"
    c "也就那么回事。"
    c "足以相信这里还隐藏着另一个人。"



    i neu "另一个人？"
    c "更准确地说，是另一个梦者。"
    i sca "这是不可能的。"
    "克劳点了点头。"
    c sad "我通常会同意你的观点，但是..."
    "从舞台一侧，一个粉发女孩悄然走上舞台，她的脚步在空荡荡的房间里显得又轻又重。"
    c sur "...."
    c "我相信我们找到了第二个梦者。"
    i sur "...罗莎米？"
    k sur "等等...罗莎米？"
    "所有人的目光都转向那个女孩。"
    "她很年轻——不超过十七岁。诺亚的眼睛立刻睁大，认出了她。"
    k "但是...罗莎米六年前就失踪了...和你一样的时候..."
    no sho "...."
    nothought "没错，她告诉我她要逃走..."
    no "没人...找到她吗？"
    k sad "没有，她失踪了，再也没有人听到她的消息。你很容易找到，但她...却不是。"
    k "有些人以为你们两个一起逃走了。"
    no sca "什么？"
    k ser "看来并非如此。"
    no ann "当然不是。我们只是勉强算得上朋友..."


    "罗莎米停在舞台的另一侧，望着这群人，神情震惊，双腿像是被钉在原地，就像伊万和凯恩一样。"
    no "我去和她谈谈吧..."

    $all_moves(camera_check_points={u'y': [(0, 0, u'linear')], u'x': [(190, 0, u'linear')], u'z': [(504, 0, u'linear')]})
    show noah n ann at slightright
    show rosamie n sad at slightleft
    with dissolve
    r "...."
    r "诺亚？"
    no "...不知怎的，是的。"
    show rosamie n hur with dis
    r "你...变了。我几乎认不出你了。"
    no "而你一点也没变。"
    show rosamie n sur with dis
    r "你...也认出我了？"
    show noah n neu with dis
    no "当然。你就是罗莎米，对吗...？"
    show rosamie n cry with dis
    "眼泪在她眼中涌起，但她用袖子擦拭掉，皱起了眉头。"
    r "你...是真的？"
    no "呃，我最后一次检查的时候还是。"
    show rosamie n sad with dis
    r "但是...你为什么看起来这么老了？"
    show noah n sca with dis
    no "六年不见一个人，这就是会发生的事。我更想知道，为什么你会对此感到惊讶...以及这是否与你一点也没变有关。"
    no "我很感兴趣。"
    show rosamie n hur with dis
    r "......"
    r "对不起，你刚才说什么？"
    r "六...年？"
    show noah n sho with dis
    no "....."
    no "凯恩说你失踪了。你逃走了，对吗？"
    r "不是六年前！那只是...就在前几天..."
    no "...."
    no "你在这里做什么？"
    show rosamie n sad with dis
    r "我...我只是在帮我哥哥...不过我并不想这样做。我没有选择。"
    r "更重要的是，我很高兴能遇到认识我的人..."
    show noah n ann with dis
    no "在此之前呢？"
    r "在各处漂泊。我...以为我已经死了。"
    r "我死了吗？"
    nothought "你死了吗？这是个好问题..."
    no "我真希望我能告诉你。"
    no "也许克劳或伊万会知道更多..."

    show rosamie n sur with dis
    r "伊万也在这里？"
    no "...."
    nothought "他们真的都是亲戚。我怎么从来没听说过伊万，却认识卢卡和罗莎米？"
    no "好了，来和其他人谈谈吧，我相信我们一定能解决这个问题—"
    l hap "女士们先生们，请就座。表演即将开始！"
    show rosamie n sad with dis
    r "对不起，我必须走了—"
    show noah n sho with dis
    no "等等，拿着这个！"
    "罗莎米看着诺亚伸出的手。手里拿着克劳给他的一个护身符。"
    "她小心翼翼地接过它，这种小心翼翼的样子是诺亚过去从未见过的罗莎米。不管她在过去六年里经历了什么，都一定改变了她。"
    hide noah
    hide rosamie
    with dissolve


    l hap "看来你遇到了我亲爱的妹妹...或者说是我的助手？"
    "随着一个响指，罗莎米转身离开了舞台。"
    show luka m hap with dissolve
    l "哦，观众看起来有点稀少...不过这无关紧要！"
    l "既然你们四个都决定光临我的舞台...那么，为什么不换个故事，让我们一起重温一些有趣的回忆呢！"
    k fro "或者你可以停止发疯，让我们离开。"
    show luka m sad with dis
    l "哪有那么多乐趣？"
    show luka m smi with dis
    l "来吧，分享秘密是最有趣的事情了，我知道很多秘密！"
    l "关于凯恩的秘密，关于诺亚的秘密，关于伊万的秘密...有太多等待被分享的秘密..."
    show luka m hap with dis
    l "哦，别用那种眼神看我。你们当然都有秘密！秘密才是这个世界的运转之源。你能有多相信站在你身边的人？"
    no ang "快告诉我们你想要什么。"
    show luka m smirk with dis
    l "你。"
    l "戴着那张脸的人。"
    c sur "我...？"
    show luka m pou with dis
    l "我不知道你有什么秘密。这可不好玩！"
    c "..."
    show luka m hap with dis
    l "但我有办法解决这个问题！"
    "随着另一声响指，罗莎米从舞台幕后重新出现，直接走到克劳身边。她小心翼翼地用手指点了点他的额头。"
    "克劳的脸因疼痛而扭曲，双腿也支撑不住倒了下去。他紧抓着自己的头，却没有发出一声呼救。"
    no ang "克劳...！"
    c hea "没事的...没事的..."
    r sad "...对不起。"
    no sho "你做了什么...？！"
    r "..."
    l "哦哦。哈哈哈。哇，真是太多汁的秘密了。"
    l "有太多可选择的了...我该怎么选呢？"
    show luka m smirk with dis
    l "啊...不如就选这个吧。一个悲伤的故事...呜呜呜...我都能感觉到眼泪在打转了。"
    "他用袖子擦拭着脸，擦去了假泪。"
    stop music fadeout 4.0
    l "好了，让我们从头开始！"

    play sound spotlight
    scene black with hpunch
    $ camera_reset()

    "房间一下子陷入一片漆黑，所有的灯光都同时熄灭了。诺亚的思维感到迷糊，被铅块压得沉重。他的意识时断时续，挣扎着保持自我。"
    "突然，他感到非常孤独。比多年来任何时候都更加孤独。"
    "就在这一刻，他不再是自己。"


    scene bg empty dream

    $all_moves(camera_check_points={u'y': [(2097, 0, u'ease')], u'x': [(5261, 0, u'ease'), (-5160, 30.45, u'ease')], u'z': [(818, 0, u'ease')]})

    with Fade(1.0, 1.0, 1.0)
    play music sunset fadein 3.0

    "在时间和空间之外，善恶之外，生死之外的领域，一个无名的存在诞生了——完全孤独。"
    "他漂浮在一片无尽的虚无之中，感觉就像阳光照在皮肤上一样温暖；尽管他没有什么可比较的。"
    "他没有命运。没有目的。他世界中唯一的真理就是他的孤独。"
    "但他并不感到孤单。"
    "他也不害怕，因为在这里恐惧也不存在。"
    "他既没有喜悦也没有悲伤，因为这些对他来说都是无意义的概念。没有悲伤何来喜悦，没有喜悦何来悲伤？"
    "唯一的真理就是等待。等待某些事情的发生。等待某个人的出现。等待自己的目的被明确。"
    "在漂浮中，他思考了许多事情。他的存在。周围的世界。虚无。"
    "他在脑海中构建了许多精心设计的世界和场景，但它们最终都像被潮水冲刷的沙堡一样消失了。"
    "而有时，他会被另一种感觉所击中——怀旧——当这些场景在他闭上的眼睛后重现。"
    "那些他从未见过的地方的记忆。那些他从未谋面的生灵的记忆。"
    "他观看着梦境中色彩和形状的变化，但其他什么都没有改变。有时他感觉自己被困在一个永恒循环中，注定要一遍又一遍地重复同样的模式。"
    "但他依然保持平静。"
    "如果这就是他的存在，那也无所谓。他会没事的，因为他一直都很好。"
    "因为对于像他这样的存在，短暂的感受和情感都已经超越了他。他满足于仅仅存在、观察和等待。"
    "于是他在梦境的无尽海洋中安详地等待着，等待着永恒。"

    scene black with dissolve
    $ camera_reset()

    l sad "哦，多么悲伤的存在啊...我很好奇接下来会发生什么？"
    l "我可不敢让我亲爱的观众久等...那么，我们继续吧？"

    c hea "不...不...不要..."
    c "不要再来了..."
    c "求你了……"

    scene bg empty dream

    $all_moves(camera_check_points={u'y': [(3200, 0, u'ease'), (-3677, 27.0, u'ease')], u'z': [(1001, 0, u'ease')]})
    with Fade(1.0, 1.0, 1.0)
    "\'克劳\'。"
    "随着目的的发现，他的名字也随之揭晓。这是他自己第一次选择的东西。"
    "\'克劳\'。"
    "\'奥古斯特\'。"
    "\'克劳\'。"
    "\'奥古斯特\'。"
    "这是他孤独存在的象征。这是他渴望保护珍视之物的象征。"
    "他从阴影中小心翼翼地看护着他们。但是，他与人类互动得越多，他内心深处那股恐惧的种子就越长越大。"
    "他体验到了从未想象过的东西：孤独。"
    "他一直都是独自一人。他一直都是孤独的。但现在，他内心深处的孤独感变得沉重起来。"
    "心中的痛楚如同挥之不去的咀嚼般折磨着他。"
    "还有更多。"
    "恐惧。害怕失去自我。害怕未知，害怕虚无。"
    "害怕失去他想要保护的那个人，尽管他对那个人来说不过是一个无足轻重的小角色，只是他们生活中的一小部分。这是他深深意识到的事实。"
    "他的记忆，如果可以这么称呼的话——当他在无尽的海洋中漂浮时，在心中浮现的场景——开始折磨着他。"
    "关于一个和他长得一模一样的男孩的记忆。他永远无法达到的记忆。"
    "这些记忆只给他带来更多的虚无感。"
    "他一次次地试图摆脱这些感受，但它们一直挥之不去。"
    "于是他等待。"
    "但他有太多的时间。太多太多的时间。时间去思考，时间去沉思，时间去担忧，时间去焦虑。"
    "等待的时间越长，他越意识到自己正在发生变化。变成什么，他不知道，但他正在发生变化。"
    "作为一个人类的脆弱，却没有成为人类的好处。"
    "去爱、去恨、去崇敬、去信任、去恐惧、去痛苦的能力...他不知道如何调和曾经的克劳和现在的克劳。"
    "于是他决定抛弃这些感受。"
    "他唯一需要做的就是保护最重要的那个人。"
    "即使在等待的时刻，他会想象自己是别人，一个能够以他从未体验过的方式感受和体验周围世界的人。"
    scene black with dissolve
    "他会想象自己是奥古斯特。"

    $ camera_reset()
    scene bg stage
    show luka n hap at slightright
    show crow n hea at slightleft

    $all_moves(camera_check_points={u'z': [(548, 0, u'linear')]})
    with Fade(1.0, 1.0, 1.0)


    c "住手...！"
    c "住手...不要再说了..."
    show luka n sad with dis
    l "可怜的克劳啊。在一个他没有选择的存在中挣扎，一个只会给他带来痛苦的目标..."
    no sho "...."
    c "这不是...这不是真的..."
    c "我...我很满足！我很快乐！"
    c "我..."
    c "我也存在..."
    show luka n smirk with dis
    l "当然，如果这样让你感觉好些，你可以告诉自己那些都是假的。"
    c "别听他的...那不是真的..."
    c "我...我很好。我一直都很好。我完全，完全，很好！"
    no sad "克劳..."
    "克劳仍然瘫坐在舞台的地板上，在罗莎米触碰他时倒下的地方。他的眼睛睁得很大，双手握成拳头。"
    "他就像在边缘处崩溃了一样——只差一根线就要完全解体。"
    show luka n hap with dis
    l "多么美妙的故事。要是我们有时间再来一次就好了！"
    l "于是，这个迷失的小乌鸦的故事的帷幕开始落下。但在此之前—"


    play sound spotlight
    scene bg stage dark with hpunch:
        zoom 1.03 subpixel True xpos -0.06 ypos None xanchor None yanchor None rotate None
    $ camera_reset()

    l hap "最后的转折。"
    stop music
    play sound gun

    no sur "克劳...！"
    "房间里一片寂静。"
    "太安静了。"

    scene bg stage:
        zoom 1.03 subpixel True xpos -0.06 ypos None xanchor None yanchor None rotate None
    play sound spotlight

    play music demonunderwater fadein 4.0
    "聚光灯最后一次照在舞台上。"
    "照亮了一具尸体。"
    "卢卡，面朝下躺在自己的血泊中。罗莎米惊恐地冲向他，但已经太迟了。"

    scene bg stage at Shake((0.5, 1.0, 0.5, 1.0), 75.0, dist=2):
        zoom 1.03 subpixel True xpos -0.06 ypos None xanchor None yanchor None rotate None
    "周围的世界开始摇晃。"



    k sur "......"
    i sur "我...他..."
    i sca "嗯...这确实是一个最后的转折。"
    no sho "伊万，带凯恩走！"
    "伊万点点头，尽管显然不太喜欢这个主意，还是抓住了凯恩。他伸手向诺亚，但诺亚只是回头看向克劳。"
    k ang "诺亚，别傻了！我们得走了！"
    no ann "...我马上就来。我保证。"
    nothought "他一直都是独自一人...？"
    nothought "那么...我现在不能把他一个人留下！"
    k "他不是奥古斯特—！"
    "两人消失了。"
    "诺亚抓住了克劳的肩膀。"
    no sad "克劳，我—"
    c hea "你得走...诺亚，请离开。你必须..."
    no hur "我不会丢下你一个人！"
    no sad "请跟我回去..."
    c "求你了……"
    c "就走吧..."
    no ann "跟我一起走！"
    c "我不能...！"
    no "那我就在这里陪着你。"
    "克劳摇摇头，眼睛仍然盯着地面。他不愿抬头看诺亚。"

    c sad "你不能。"
    c "没有人能。"
    no sad "我会的！"
    c "回家吧，诺亚。回到你属于的地方。"
    no "..."
    no "只要你答应在那里见我。"
    c sho "什么...？"
    no sad "如果他说的不是真的...明天早上10点，在洛菲尔德街有一家餐厅。拜托了。"
    c sad "我—"
    r cry "不...不...我要...我要再次独自一人了..."
    "罗莎米的独自一人的声音从她倒在卢卡身边的地方传了出来。"
    no sho "罗莎米，跟我—"

    scene black with hpunch
    "但是没有时间了。从来就没有足够的时间。梦境在这群人周围崩塌了—但在此之前，他看到克劳伸手去抓罗莎米。"
    "诺亚倒下了。时间和空间似乎在他周围拉长，一切都变成了黑暗。"
    "在无尽的虚空中，诺亚发誓他仍然能听到克劳的声音在回响。"
    "当他不想回答问题时，他几乎无声的轻笑。"
    "当他恳求卢卡停下时，他的声音颤抖，似乎比以前小得多。"
    "他温和而安慰的声音，无论诺亚身在何处，都让他感到安全。"
    "{i}只要我在，就不会发生任何事。这是我的承诺。{/i}"
    "出于某种原因，诺亚相信这些话是真的。"

    scene bg streets night with hpunch:
        subpixel True xpos 0.82 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.82 rotate None

    "诺亚重重地摔在水泥地上。幸运的是，没有人似乎在场目睹他的突然出现。"

    no hur "呃...我的背..."
    no ann "我在哪里..."
    no "对了...我在外面的时候..."
    no "凯恩，伊万...你们在哪里..."

    stop music fadeout 3.0

    "另外两个人都不见了。"
    "拾起他受伤的自尊心和稍微酸痛的背部，诺亚站起身来，环顾四周，确保没有人看到他，然后走出街灯下。"
    "夜晚凉爽，他把外套裹在自己身上。"
    play music sadmorning fadein 5.0
    "他的脚步在寂静的街道上回响。唯一的其他声音是远处交通的嗡鸣，但即使在这个深夜，那也很少。"
    "诺亚一直喜欢独处。即使在一切变成一团乱麻之前，他也喜欢那些他可以关上卧室门，戴上耳机，只是画画的时光。"
    "不知为什么，现在就像是他童年时的那些时刻。他感觉自己是这个世界上唯一的人，他的手不安地动了动—渴望创作，素描，绘画。"
    "主题并不重要。他只知道他必须创造。"
    "怀着这个想法，他的脚步加快了，很快就站在公寓大门前。"


    scene bg paint night with Fade(1.0, 1.0, 1.0)
    no ann "克劳..."
    nothought "卢卡说的一切...是真的吗？"
    nothought "为什么你一直都是独自一人？"
    nothought "这为什么让我感到如此...空虚？"
    no "...看来卢卡也死了。"
    no "但是罗莎米..."
    "诺亚皱起眉头，揉着太阳穴。"
    nothought "什么都说不通。如果她六年前失踪了...她是否被困在那里了？"
    nothought "我必须找到她..."
    "诺亚打开电视，但这个时间点播放的只有一些奇怪的另类音乐频道。"
    "不知为什么，音乐帮助他平静下来。"
    "他凝视着画布。这次它是空白的。它在等待他。"
    "他的脑海里充满了灵感。"
    "他坐在画架前，手中的画笔对准那片刺眼的白色画布。"
    "他想要描绘那个梦境。"
    "舞台上，观众们抛洒着玫瑰花。一个宏大的场景。"
    "但是相反，他画了别的东西。"
    "一个金发绿眼的男人，周围长满了花朵。一个会让夏日黯然失色的温暖微笑。"
    "一只孤独的乌鸦的故事。"
    no sho "是你...克劳。"
    nothought "为什么在认出卢卡后你看起来那么伤心？"
    nothought "如果你不是奥古斯特，你怎么会认出他？"
    nothought "你真的还活着吗？为什么不联系我？"
    no sad "如果他...如果他明天出现了，那就是真的。真的是他。"
    "但是尽管他这么说，诺亚的思绪一直回到克劳孤独悲伤的微笑上。回到卢卡挑衅他时，他眼中那遥远的神情。"
    no hur "...我想我需要睡觉了。"
    stop music fadeout 5.0
    "被疲惫感淹没，诺亚拿起凯恩留下的半瓶水给他的植物浇水，然后几乎是爬回卧室，倒在床上，度过了又一个不安宁的夜晚。"

    scene black with eye_shut

    scene bg august bedroomnight mattress:
        subpixel True xpos 0.82 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.76 rotate None

    show noahteen m dim hap at slightleft:
        subpixel True xpos 0.09 ypos 1.0 xanchor 0.2 yanchor 1.0 rotate None
    show kaineteen m dim neu at slightright:
        subpixel True xpos 0.88 ypos 1.0 xanchor 0.8 yanchor 1.0 rotate None
    show august m dim glasses hap

    with Fade(1.0, 3.0, 1.0)

    "三人坐在奥古斯特父亲拉进房间的床垫上，一直玩到深夜，完全不在乎第二天上学的事。"
    play music thiscloud fadein 5.0
    "奥古斯特的父亲在某个时候探头进房间，给他们带来了几个披萨，并眨了眨眼睛告诉他们不要太晚睡，然后自己也去睡觉了。"

    no "嘿，奥古斯特。我刚刚在想..."
    "诺亚放下一片披萨，手指上沾着油脂，好奇地看着奥古斯特。"
    no "你爸爸竟然对这一切都没有意见：让我们熬夜，我是说，甚至给我们带披萨...这真是疯狂。"
    no "我的父母{i}绝对{/i}不会让我在上学日晚上超过午夜睡觉。"
    no "不过他看起来很随和-而且他和你说话也不像个家长。"
    show august m sur with dis
    a "你不这么觉得吗？"
    no "至少他的说话方式和{i}我{/i}父母不一样。"
    show noahteen m dim sad with dis
    no "他们总是在教训我，但你爸爸..."
    no "很难解释，但感觉他和你说话就像平等的朋友。"
    a "...嗯，我爸爸信任我。他知道不需要命令我。"
    a "他说我头脑还算清晰，可以自己做决定..."
    a "不过我觉得他对我有点太多信心了，呵呵。"
    no "我不这么觉得。他就像..."
    no "如果我能选择父母，我希望他们能像你爸爸一样。"
    no "他真的太酷了。"
    show august m neu with dis
    a "他真是太棒了，不是吗？"
    "奥古斯特回以亲切的微笑：这种微笑足以让学校里一半的女孩倾倒。"
    show august m hap with dis
    a "他就是...我所向往的一切。"
    show kaineteen m dim hap with dis
    kteen "我以为我父母已经很随意了..."
    kteen "...但你爸爸更加悠闲。"
    show noahteen m dim sca with dis
    no "他确实如此。我真羡慕。"
    no "但愿我也能这么说我的家人..."
    show noahteen m dim sad
    show august m dim sad
    with dis
    a "诺亚..."


    # DO EXPRESSION THROUGH THIS PART
    a "我知道你经历了很多，但没关系。"
    a "我们永远是你的家人！"
    a "对吧，凯恩？"
    kteen "家...家人？"
    kteen "我...我也不反对，我想..."
    kteen "但具体怎么做呢？"
    a "嗯，天哪..."
    a "我只是随口说的，因为听起来很酷..."
    a "但我还没仔细考虑过我们具体的角色。"
    a "你{i}肯定{/i}会是妈妈。"
    kteen "什么？你是认真的吗？"
    a "当然！你是我们中做饭最好的，而且总是在教训我们。"
    a "如果没有你时刻督促我，我的成绩可能会更糟。"
    kteen "哼..."
    "凯恩皱起了眉头。"
    kteen "我不知道这算是赞美还是什么。"
    kteen "感觉你在说我是个唠叨的人..."
    a "以最好的方式！"
    kteen "我不太确定..."
    kteen "不过，无所谓。我想我会接受的。"
    kteen "我不介意当妈妈朋友-但你呢，奥古斯特？"
    a "自然，我就当诺亚的弟弟！"
    kteen "你不想当爸爸吗？"
    a "我觉得我还太年轻，还不到组建家庭的时候！"
    kteen "...对，这说得很有道理..."
    kteen "..."
    kteen "..."
    kteen "喂！我也可以对自己说同样的话！"
    kteen "我虽然比你高，但也不比你大多少！"
    a "呵呵...哈哈..."
    kteen "我们到底在说什么啊？"
    kteen "这太傻了。"
    a "也许是，但有时候傻一点也没什么不好的。生活已经够严肃了！"
    a "你怎么看，诺亚？"
    noteen "..."
    "一直保持沉默的诺亚，在奥古斯特和凯恩之间来回看着。"
    "他眨了眨眼睛。"
    "然后，用看起来有些湿润的眼睛说..."
    noteen "你们..."
    noteen "我...我..."
    kteen "...?"
    a "你们真的那么讨厌和我成为亲人吗？！"
    noteen "不，不是这样的..."




    show noahteen m dim sad with dis
    no "你们两个，我...有时我觉得...他们认为我是个错误...有时我也同意他们的观点..."
    show noahteen m dim hea with dis
    no "但你们两个让我觉得这并不是那么真实..."
    show august m dim sur:
        parallel:
            xpos 0.5
            linear 0.15 xpos 0.55
            linear 0.15 xpos 0.58
        parallel:
            ypos 1.0
            linear 0.15 ypos 0.94
            linear 0.15 ypos 1.0
    show kaineteen m dim sur:
        parallel:
            xpos 0.88
            linear 0.15 xpos 0.93
            linear 0.15 xpos 0.96
        parallel:
            ypos 1.0
            linear 0.15 ypos 0.94
            linear 0.15 ypos 1.0

    "诺亚的眼睛湿润了，奥古斯特和凯恩都迅速后退，感到惊讶。"
    "不知为什么，在最近发生的一切之后...他们的话触动了诺亚内心深处。"
    no "我...我—"
    "泪水顺着他的脸颊流下。"
    no "你们真是太好了..."
    no "天哪，我一定是累了或者什么的。请装作这件事从未发生过..."
    k "我想我可以从我的愿望清单上划掉\'看到诺亚哭泣\'了。"

    show noahteen m dim pou with dis
    no "闭嘴。"
    show august m sho with dis
    a "......"
    a "我不想抢风头，但是..."

    a "我也..."

    show august m sadsmi with dis
    a "很感谢你们两个。"
    a "我的意思是..."
    a "因为我父亲的工作，我一直在到处搬家，所以..."
    a "嗯。"
    a "你们是我有过的第一个真正的朋友。"

    show noahteen m dim neu with dis
    no "奥古斯特..."
    show kaineteen m dim neu with dis
    k "好吧，我想大家都有些疲惫了。我们为什么不准备睡觉呢？"
    no "好主意。"
    "脸红红的，诺亚擦去脸上几滴落下的泪水。"
    show august m neu with dis
    a "让我想想..."
    a "我们为什么不用这张床垫呢？这样我们就可以继续看会儿电视了。"
    no "我们三个人都？"
    show august m hap with dis
    a "对啊！这就是真正的睡衣派对了。"
    a "应该不会太挤的。"
    k "我要这边。"
    a "那我就在这里吧。"
    "诺亚盯着留给他的那个空位。正好在凯恩和奥古斯特中间。"
    show noahteen m dim shy with dis
    no "......"
    nothought "我...我...我不能...我不能睡在他旁边...！"
    show noahteen m dim poublu with dis
    no "我，呃...呃..."
    no "...好吧...我猜我只能在中间了..."

    scene bg august bedroomnight mattress2 with dissolve:
        subpixel True xpos 0.5 ypos 1.06 xanchor 0.5 yanchor 1.0 zoom 1.8 rotate None
    "三人在床垫上安顿下来。奥古斯特把电视切换到播放一部电影，奥古斯特和凯恩立刻被迷住了。"
    "但另一方面，诺亚发现自己完全无法集中注意力。"
    "就在他手臂的距离之内，就是那个让他着迷的男孩，他忍不住过度关注着对方的每一个动作、每一次呼吸、每一声轻微的笑声。"
    "不久，他们就听到了凯恩逐渐进入睡眠的轻柔声音。"
    "奥古斯特对诺亚微笑，几乎照亮了黑暗的房间。"
    a hap "我们来睡觉吧，好吗？"
    noteen shy "...是的。"
    stop music fadeout 5.0
    "在月光下，诺亚面朝着奥古斯特的背部躺着。此刻，那背影显得是如此渺小，如此脆弱。"
    "仿佛只要伸出手，他就会消失不见。"
    "但当诺亚翻来覆去，过于意识到身边另一个人的热度时，他做出了一个违背自己更好判断的决定。"
    "最终还是伸出了手。"

    "他的手指小心翼翼地触碰到那个金发男孩的手掌，轻轻地，以免吵醒他。"


    scene gallery_8 with Fade(1.0, 1.0, 1.0):
        subpixel True xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.54 rotate None
        parallel:
            ypos 1.04
            ease 5.0 ypos 1.17

    play music mountainhut fadein 4.0
    a "还没睡着吗？"
    "奥古斯特翻过身来，显然自己也还没睡着。"
    no "啊！"
    "诺亚僵住了，他的手仍然贴着对方。"
    scene gallery_8 with dissolve
    no "我...我...我还不太困..."
    a "我也是。"
    "他的心脏在耳边砰砰直跳。一个持续不断的响声。"
    no "......"
    no "我...我可以问你一个问题吗？"
    a "当然可以。你可以问我任何事。"


    scene gallery_8 with dis:
        subpixel True xpos 0.5 ypos 1.72 xanchor 0.5 yanchor 1.0 zoom 1.65 rotate None
        parallel:
            xpos 0.59
            ease 15.1 xpos 0.74

    no "你...呃...呃..."
    no "我的意思是—"
    no "我想问的是...呃...如果你，也许..."
    no "喜欢男孩子？"
    no "呃...我的意思是，如果你是的话，我...我会很支持你的，而且这和我父母无关。"
    no "我只是...在好奇..."

    scene gallery_8 with dis:
        subpixel True xpos 0.74 ypos 1.72 xanchor 0.5 yanchor 1.0 zoom 1.65 rotate None
        parallel:
            xpos 0.26
            ease 15.04 xpos 0.07
    a "...."
    "奥古斯特看起来很惊讶，眨了眨眼睛，然后脸红了。"
    "房间里一片寂静。"
    nothought "糟糕，我...我为什么要..."
    scene gallery_8 with dissolve
    a "...也许吧。我从来没有真正考虑过这个问题。"
    "他的眼睛重新看向诺亚。"
    a "你呢？"
    no "什么？！不...不，当然不是—我是说，我是..？"
    no "呃...我...也许—我不知道..."
    a "我—"
    "在他们两个身后，凯恩动了动，在原地翻了个身。"
    scene bg august bedroomnight mattress2 with hpunch:
        subpixel True xpos 0.5 ypos 1.06 xanchor 0.5 yanchor 1.0 zoom 1.8 rotate None
    "两个男孩跳了起来，立刻转过身背对彼此。诺亚紧紧闭上了眼睛。"
    nothought "该死，我..."
    nothought "我本可以...我感觉到...想伸手去...吻他..."
    "他的脸仍然红得发烫，他希望另外两个男孩听不到他的心跳有多快。"
    nothought "我希望我...能读懂他的心思...知道他对我的想法..."
    "当诺亚渐渐睡着时，他偷偷看向已经沉沉睡去的奥古斯特。"
    nothought "也许如果我能偷偷看看他的梦境..."
    stop music fadeout 4.0
    "但在他的意识真正沉入无尽的海洋之前，床垫从他身下塌陷下去，他摔了下去。"

    window hide
    show black with dis2
    show transition movie onlayer overlay
    pause 3.0
    window show
    stop music fadeout 4.0

    "周围的世界旋转不停。狂风拍打在他的脸上，淹没了他的尖叫声。"
    noteen sur "啊啊啊啊啊啊啊啊啊啊啊啊啊—！"
    noteen "什么...啊啊啊...！"
    "他什么也看不见。他什么也听不到。他试图四处抓握，想抓住什么来拯救自己，但都是徒劳。"
    "什么也没有。"
    "在这片虚无中，他坠落着。"

    scene bg classroom night with hpunch
    "他重重地摔在地上。"
    noteen sca "啊..."
    play music shift fadein 5.0
    noteen "什么...到底发生了什么..."
    "当诺亚睁开眼睛时，他看到了一个熟悉的景象。"
    noteen "我为什么...会在这里？"
    noteen "我不是刚刚还在床上吗？天啊，我的头好痛..."

    scene bg classroom night with dis:
        subpixel True xpos 0.5 ypos 1.48 xanchor 0.5 yanchor 1.0 zoom 2.29 rotate None
        parallel:
            xpos -0.04
            ease 15.89 xpos 0.3
    "从走廊里，诺亚听到了脚步声逼近。警惕起来，他及时躲到了老师的桌子后面，看到有人走进了房间。"
    "一个金发绿眼的男孩。"
    "就在诺亚准备站起来呼唤那个男孩之前，另一个人走进了房间。"
    nothought "什么—"
    "诺亚。"
    "另一个诺亚走进房间，走向坐在桌前寻找什么的奥古斯特。"
    "那个诺亚悄悄对奥古斯特说了些什么，然后伸手握住了他的手。"
    noteen ang "嘿—！你以为你在干什么—"
    noteen sur "...做什么..."
    "诺亚从藏身处跳了出来。奥古斯特睁大眼睛，在两个诺亚之间来回看着，然后站在他身边的那个诺亚消失了。"
    a sho "诺亚？"
    noteen "谁，什么...我..."
    noteen "我们...我们在哪里...？到底发生了什么？"
    a sur "你是怎么回到那里的..."
    a hap "我是说，我们在学校啊，诺亚！这应该很明显了。"
    noteen "但我们是怎么到这里来的？我们不是刚刚还在床上吗！"
    a pou "嗯..."
    "奥古斯特撅起嘴，深思着。"
    a neu "我...不知道。"
    noteen "那么...那个...另一个人是谁？"
    a hap "嗯...你？说实话，我现在也和你一样困惑！"
    "他笑了，似乎一点也不为这种困惑的情况感到压力。他接受了一切，就好像这只是一个梦，他的大脑在让一切看起来完全自然。"
    a hap "诺亚，我能问你一个问题吗？"
    "奥古斯特快步走向诺亚，脸上挂着他标志性的笑容。"
    a shy "我可以抱抱你吗？"
    noteen neublu "什...什么..."
    noteen "当...当然可以...如果你想的话..."
    "奥古斯特满怀喜悦地把双臂环抱住黑发男孩，嘟囔着说了些什么。"
    a "这一定是另一个梦，对吧？"
    noteen "梦...？"
    a sadsmi "一定是。这些梦境中的另一个。"


    "诺亚掐了自己一下，疼痛告诉他他并没有睡着。"
    "这时，诺亚注意到了一些事情。"

    scene bg classroom night with dis:
        subpixel True xpos 0.3 ypos 1.62 xanchor 0.5 yanchor 1.0 zoom 2.29 rotate None
        parallel:
            xpos 0.78
            ease 15.88 xpos 1.22
    "窗外，时间仿佛静止了。什么都没有动，也什么都不存在。"
    "只有奥古斯特、诺亚和学校。"
    a sadsmi "这就是我所能希望的一切。"
    "周围的世界开始崩塌，化为虚无，但奥古斯特似乎并不为此感到烦恼。"
    "他最后紧紧抱了诺亚一下，然后世界陷入了黑暗。"


    window hide
    show black with dis2
    show transition movie onlayer overlay
    pause 3.0
    window show

    "有什么东西拉扯着诺亚的意识，指引着他。拉着他...但是拉向何处？"
    "无论他的目的地是何方，他所能做的就是紧闭双眼，坠落在那片虚无之中，心跳比以往任何时候都要快...出于多种原因。"


    scene bg august bedroom day with hpunch

    "片刻后，他的背部撞到了床垫上。"
    "凯恩跳到他身边，睁大双眼。"
    kteen sur "你在干什么，这么早就跳来跳去的？"
    noteen sho "...跳来跳去？我—"
    kteen pou "你刚才去哪里了？"
    noteen "我...什么时候？我不在这里吗？"
    kteen "是啊。我早些时候醒来，你不在我身边。"
    "诺亚的思绪飞快地转动着。"
    noteen sad "哦....我只是去了趟洗手间，我想。"
    kteen "你可真是花了不少时间。"
    noteen sho "闭嘴。我也没有离开太久。"
    noteen "咳，呃...奥古斯特在...我不在的时候在这里吗？"
    kteen "是啊...这是他的房子...你为什么表现得这么奇怪？"
    nothought "昨晚到底发生了什么？"
    "诺亚焦急的眼神转向奥古斯特，后者终于开始苏醒。"


    a neu2 "早上好。"
    "奥古斯特从困惑的诺亚转向迷惑的凯恩，又回到诺亚身上。"
    a sur2 "我...错过了什么吗？"
    "诺亚在奥古斯特的脸上搜寻着什么。任何东西。任何对昨晚发生的事有所认知的迹象。"
    nothought "等等...那真的只是个梦吗？"
    nothought "奥古斯特的...梦？"
    nothought "怎么会？"
    a "我脸上有什么东西吗？或者，呃，我是不是睡过头了？"
    kteen neu "不，不，诺亚和我只是在聊一些事情。"
    kteen "不过我们最好起床，不然就要迟到上学了。"




    noteen sho "是、是的。"


    "三个男孩迅速准备好上学，尽管他们都感到很疲惫。特别是诺亚，他感觉自己根本没睡着。"

    nothought "我睡着了吗？那到底是什么？"

    scene bg august bedroom day:
        subpixel True xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 0.6 rotate None
    show august n neu glasses at slightright
    show kaineteen n neu at slightleft
    show noahteen n neu at center
    with dissolve
    j neu "早上好，孩子们。你们饿吗？"

    a "饿死了！"


    j hap "那很好，因为我做了煎饼。"
    j sur "哦，奥古斯特，你决定好明天要做什么了吗？"
    show august n shy with dis
    "奥古斯特有些害羞地移开了视线。"
    a "我们能在家里吃个晚餐吗？"


    "他爸爸笑着揉了揉他的头发。"

    j hap"你想要什么都行，小子。"
    j "但是要敢于提出自己的要求。你知道的。"

    show noahteen n pou with dis
    noteen "明天是什么日子？"

    a "哦，没什么特别的。"

    j sur "我敢说你的生日可是很特别的！"

    show noahteen n sur with dis
    show kaineteen n sur with dis

    kteen "........"
    noteen "........"

    noteen "明天是你的生日？！你为什么没告诉我们？！"


    kteen "伙计，这可是大事一件！"

    a "我...通常不会在生日那天做什么特别的事，所以我也没觉得它有多重要。"
    a "总之，我去把煎饼端上来，好吗？"

    hide august with dissolve
    "奥古斯特和他爸爸离开了房间，留下诺亚和凯恩独自思考。"
    show kaineteen n neu with dis
    kteen "所以，我们达成共识了，对吧？"
    show noahteen n neu with dis
    noteen "是的，放学后我们去挑个礼物？"
    show kaineteen n hap with dis
    kteen "好计划。你和我合作得真不错，对吧？"
    show noahteen n poublu with dis
    noteen "伙计，你说得好像在谈恋爱一样！"
    kteen "谁说不是呢，嗯？"
    kteen "天哪，我只是开玩笑！合伙犯罪，这样说好点吗？"
    noteen "我本来想说我想象不出你会犯罪，但你确实看起来像那种逃税的百万富翁。"
    kteen "好吧，那我有什么可以努力的了。"
    show august n hap glasses at slightright with dissolve
    a "我拿来煎饼了！"


    "他手里端着三个盘子，上面堆满了煎饼。每个煎饼都覆盖着新鲜水果和奶油。"

    show kaineteen n sur with dis
    kteen "哇，它们看起来太棒了。你们每天早上都这样吃吗？"


    a "从来没有。我想我爸爸是想给你们俩留下好印象。"

    kteen "他确实做到了。"

    "当诺亚吃着饭时，关于昨晚发生的事情的思绪渐渐淡去了。"

    nothought "这个我之后再担心。现在我只需要专注于给奥古斯特买什么生日礼物..."


    ######### emma started here sorry for all the future mistakes <3 #############################

    scene bg mountains day with Fade(1.0, 1.0, 1.0)

    "阳光照耀在诺亚、凯恩和奥古斯特身上，树枝在他们头顶伸展开来。"
    "这群人稳步下山，再次前往学校。"
    a shy "....."
    noteen shy "........"
    kteen pou "........"
    kteen "呃...发生什么事了吗？"
    aan "................."
    noteen "没...没什么事。"
    a shy "只是有点累。"
    kteen neu "好的..."
    kteen neu "我们昨晚确实熬夜了。我妈妈绝对不会让我这么做的，更别提我爸爸了。"
    noteen "是啊..."
    stop music fadeout 3.0
    "在一片尴尬的沉默中，这群人继续下山。"

    scene bg classroom day with Fade(1.0, 1.0, 1.0)

    "somehow这三人竟然比平时还早到了学校。诺亚坐在自己的桌子前，打了个哈欠，拿出了素描本。"
    play music herehecomes fadein 3.0
    "他心不在焉地在空白页上涂鸦。"
    "对诺亚来说，一张空白页是无比强大的。它代表着一个只有他能影响的现实空虚。这是无数无限可能的开端，都源自他的大脑。"
    "他相信这种心态会永远保持下去。"
    nothought "他...站在这里...然后走过来，然后他—"
    "在他意识到自己在做什么之前，他已经开始勾勒出前一晚可能发生的某个场景。"
    miss "你在做什么，诺亚？"
    noteen sur "啊！"
    noteen sur "没...没什么，罗丝小姐。"
    miss "这是你画的吗？"
    noteen neu "...只是个涂鸦。没什么大不了的。"
    "她睁大了眼睛，然后眨了几下眼睛，好像在努力恢复一些镇定。"
    miss "你什么时候开始学习艺术的？"
    noteen neu "我没有学过。这只是自学的。"
    miss "真了不起..."
    miss "诺亚，你有没有考虑过进入美术专业？"
    noteen sho "呃...就是在大学里吗？"
    miss "没错。"
    miss "我相信你不仅有能力，而且还有更多。"
    noteen pou "..."
    noteen sad "嗯...我的父母...希望我去金融方面。"
    miss "你父母的想法很好，但是..."
    miss "你{i}自己{/i}想要什么？"
    noteen sho "...你真的觉得我可以吗？"
    "她沉思地点了点头。"
    miss "我负责学校的课外美术社团。诺亚，如果你真的想争取奖学金，那就来加入我们吧。"
    noteen sho "呃...我今天有点忙..."
    miss "那你就快点过来自我介绍一下怎么样？"
    noteen sho "...好吧。"
    stop music fadeout 3.0
    miss "好的。那么，我想是时候开始上课了。"


    scene bg classroom day with Fade(1.0, 1.0, 1.0):
        subpixel True xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.8 rotate None
        parallel:
            xpos 0.24
            ease 11.0 xpos 0.56

    "第一节课似乎一下子就过去了，很快奥古斯特和凯恩就把椅子拉到诺亚的桌边吃午饭。"
    play music rural fadein 3.0
    a neu "罗丝小姐今天早上找你有什么事？"
    "诺亚突然发现很难直视奥古斯特的眼睛。"
    noteen pou "...没什么大不了的。她想邀请我参加她的课外美术社团...之类的。"
    noteen pou "...还说了什么争取奖学金的事。"
    a sur "什么—诺亚，这太棒了！"
    a hap "你真的很值得。你的艺术作品是我最喜欢的。"
    noteen shy "..."
    "一只胳膊搂住了诺亚的肩膀，然后拍了拍他的胸口。"
    kteen hap "我买了些饮料。你有想我吗？"
    noteen pou "就像我会想念任何其他过于膨胀、自负到没有个人空间概念的家伙一样。"
    kteen hap "来吧，你和我之间不需要什么个人空间。"
    "笑着，凯恩揉乱了诺亚的头发，在桌子上放下了三瓶饮料。"
    a hap "老样子。"
    "奥古斯特笑了。"
    kteen hap "对，如果你想要别的，那就太遗憾了。"
    a hap "这太棒了。嘿，诺亚，你也要告诉凯恩！"
    kteen neu "发生什么事了吗？"
    noteen pou "没什么大不了的..."
    noteen neu "罗丝小姐只是想让我加入她的美术社团，并争取奖学金。"
    kteen sho "每次你说没什么大不了的，它都很大不了。"
    kteen sho "也许你需要重新学习什么是大不了的事。"
    noteen hap "上帝，闭嘴吧。"
    noteen sad "我妈妈要是知道的话会杀了我的。"
    kteen neu "我会帮你掩护的。也许我还能说服她雇我当你的家教。"
    noteen neu "你想得美。"
    kteen hap "我不知道，她肯定被我的魅力迷住了。"
    "诺亚翻了个白眼，奥古斯特咯咯笑了。"
    a hap "你的未来肯定在艺术方面，诺亚。不要让任何人告诉你相反的话。"
    kteen hap "对，对。"
    kteen neu "哦，你今天下午还好{i}帮我做作业{/i}吗？"
    noteen neu "..."
    nothought "对，现在。"
    noteen neu "是的。不过我先要去俱乐部自我介绍一下。"
    noteen neu "放学后15分钟内我们就可以开始了。"
    kteen hap "好的。我会在教室里等你完成。"
    a neu "我今天必须先走。我告诉爸爸我会帮他干活。"
    kteen hap "很好。"
    a sho "嗯？"
    kteen hap "没什么，没什么。转告他们我们对昨晚的感谢。"
    noteen hap "还有那些美味的煎饼..."
    a hap "我会的！"
    noteen pou "现在我饿了..."
    a sho "哦，对了，我爸给了我一些钱，所以我可以从自助餐厅给你们两个买午餐！"
    noteen sho "哦，你不用—"
    a hap "他坚持要我这么做！我也是。"
    kteen hap "好吧，我可不会拒绝免费的食物。"

    scene bg school corridor

    show noahteen n neu at center
    show august n hap glasses at slightleft
    show kaineteen n neu at slightright

    $all_moves(camera_check_points={u'y': [(7, 0, u'linear')], u'x': [(453, 0, u'linear')], u'z': [(423, 0, u'linear')]})
    with Fade(1.0, 1.0, 1.0)

    k "希望好的东西还没卖完。"
    no "我都不记得上次去自助餐厅是什么时候了。"
    k "你们想吃什么？"
    a "嗯..."
    no "也许..."
    show noahteen n hap with dis
    aan "蛋糕！"
    show kaineteen n sur with dis
    k "........"
    show kaineteen n hap with dis
    k "哈哈哈...！"
    k "你们...你们两个...同时说出来了...哈哈...！"
    show noahteen n shy with dis
    no "........"
    show august n shy with dis
    a "............."
    show noahteen n pou with dis
    no "嘿-"
    show bg with hpunch
    "在凯恩调侃的语气中，诺亚还没来得及回应，就有人狠狠撞了他的肩膀。"
    ul hap "哎呀，我的错！"
    show noahteen n neu with dis
    no "....没事。"
    "那个男孩继续走了，甚至都没回头看一眼。"
    show kaineteen n fro with dis
    k "他怎么了？"
    no "...我想那只是个意外。"
    show august n sur with dis
    a "哦不..."
    k "嗯？"
    "这群人停在了自助餐厅门前。里面几乎什么都卖完了...冰箱中央只剩下一块蛋糕。"
    no "....."
    a "........"
    show kaineteen n neu with dis
    k "我建议来一场生死决斗？"
    no "...你可以—"
    show august n hap with dis
    a "我们一起分吧？"
    no "....."
    show noahteen n shy with dis
    no "一...一起？"
    k "分享通常就是这个意思。"
    no "....好吧。"
    a "那你呢，凯恩？你也要来一块吗？"
    k "不了，我就买个三明治吧。我不太喜欢吃甜的东西。"
    show noahteen n neu with dis
    no "但你总是会自己烤东西来分享。"
    show kaineteen n hap with dis
    k "是啊，因为你们喜欢。"
    a "我这就去买，马上回来！"

    $all_moves(camera_check_points={u'y': [(7, 0, None), (-1747, 2.89, u'ease')], u'x': [(453, 0, None), (2820, 2.89, u'ease')], u'z': [(423, 0, None), (876, 2.89, u'ease')]})
    hide august with dissolve

    "奥古斯特留下两个男孩独自站在走廊里。"
    show noahteen n pou with dis
    no "你不用特意为我烤东西的。我没意识到。"
    show kaineteen n neu with dis
    k "为什么不呢？我喜欢烘焙，也喜欢看到你们享受我做的东西。"

    no "不过..."
    no "我欠你一个人情。或者，嗯，不止一个..."
    show kaineteen n hap with dis
    k "我是说，如果算起来的话，肯定有5个...10个...20个..."
    no "好了！好了。我知道了。"
    "凯恩大笑起来，那声音如此洪亮，足以让任何人都露出微笑。"
    k "你不欠我什么。"
    k "只要看到你开心就足够了。"
    show noahteen n neu with dis
    no "..."
    no "嗯...谢谢。我确实...很喜欢。"
    show kaineteen n sad with dis
    k "...."
    show kaineteen n shy with dis
    k "...诺亚，说实话，我有件事想告诉你—"


    $all_moves(camera_check_points={u'y': [(-1747, 0, None), (-271, 2.28, u'ease')], u'x': [(2820, 0, None), (686, 2.28, u'ease')], u'z': [(876, 0, None), (438, 2.28, u'ease')]})
    show august n hap glasses at slightleft with dissolve


    a "我回来了！"
    show kaineteen n sur with dis
    k "啊——！"
    show august n sho with dis
    a "哦，对不起，我打扰到你们了吗？"
    no "你们想告诉我什么？"
    k "....."
    "凯恩在诺亚和奥古斯特之间来回看着，揉着后颈。"
    show kaineteen n pou with dis
    k "没什么。我们可以稍后再谈。"
    no "好的。我们要不要回到教室里吃？那里看起来挺拥挤的。"
    show august n hap with dis
    a "对我来说很好。"

    scene bg classroom day
    $ camera_reset()


    $all_moves(camera_check_points={u'x': [(5181, 0, u'ease'), (-5014, 45.64, u'ease')], u'z': [(679, 0, u'ease')]})
    with Fade(1.0, 1.0, 1.0)

    a sho "我问过他们有没有另一个盘子或者什么的，但是没有...所以我们得分享，这样可以吗？"
    a hap "哦，不过别担心，我拿了两把叉子！"
    noteen neublu "...对我来说没问题。"
    "奥古斯特和诺亚坐在对面，而凯恩坐在一边。他安静地咬着三明治。"
    "蛋糕片放在桌子中间。诺亚紧握着叉子，额头上几乎渗出了汗珠。"
    nothought "我...是直接咬一口吗？还是等他先来？他会不会觉得恶心..."
    nothought "分享食物...不是有点...太亲密了吗？"
    nothought "他会不会觉得我很奇怪？不，等等，这是他的主意..."
    nothought "除非他只是建议这样做是因为觉得不好意思？他其实想让我说不要？"
    "与此同时，奥古斯特已经用叉子舀了一块放进嘴里。他笑得很开心。"
    a "啊，太好吃了。诺亚，你也要尝尝！"
    nothought "他一定只是在客气。呃，我应该说让他自己吃完。"
    nothought "特别是在...昨晚之后..."
    "好像厌烦等待，奥古斯特从诺亚紧握的拳头里拿走叉子，又舀了一块蛋糕，递到他面前。"
    a "还记得你以前对我做的吗？张嘴说\'啊\'。"
    noteen shy "........"
    noteen "...啊...啊..."
    "奥古斯特小心翼翼地把叉子放进他嘴里，脸上露出满足的表情。诺亚脸颊已经红得很深，慢慢咀嚼着。"
    a "好吃吧？再吃点吧！不然我一个人把它全吃完了，你连第二口都吃不到。"
    "诺亚从奥古斯特手里接过叉子，后者已经在挖第二块了。尽管还有些紧张，但诺亚还是抓住这个机会开始自己吃起来。"
    "一块接一块地吃完，只剩下最后一小块。诺亚带着微笑朝奥古斯特点了点头。"
    noteen "都给你。"
    "不需要再说什么了。他立刻吃掉了那最后一块。"
    kteen neu"你的甜食爱好和诺亚一样。"
    a "你和我真的很像。"
    "奥古斯特嘴角有一点奶油。"
    "诺亚伸出手，用拇指擦掉了那里的奶油。"
    noteen hap "你嘴角有奶油。给你。"
    noteen sho "我—"
    stop music fadeout 3.0
    "他把拇指放到嘴唇上，舔掉了奶油。"
    noteen shy "我...我，我...我...给你的..."
    "奥古斯特眨了几次眼睛，难以置信。"
    noteen "我...呃..."
    play music thiscloud fadein 4.0
    noteen "我得...我马上回来！"
    "他跳起来冲出了教室。"


    "至少，这是他想做的，但就在他要从里面打开门的时候，门从外面被打开了。"
    "罗丝小姐走了进来，正好赶上铃声响起，准备继续上课。"
    miss "你要去哪里，诺亚？"
    "诺亚睁大了眼睛，慌乱地看着已经脸红到深不可测的奥古斯特，还有罗丝小姐。"
    noteen shy "...没有，罗丝小姐。"
    "奥古斯特的手指轻轻划过嘴唇，然后站起身，背对着诺亚，回到了自己的座位。"
    "凯恩也已经悄悄回到了自己的座位。"
    "满怀羞愧，诺亚重新坐回了自己的座位。"
    "当老师悦耳的声音在教室里回荡，谈论着文字和诗歌时，诺亚的眼睛慢慢落回到了奥古斯特身上。"
    "他金色的头发，随着从敞开的窗户吹进的风微微飘动。"
    "他绿色的眼睛，专注地聆听着每一个字。"
    "他修长的手指，静静地搭在桌子上。"
    miss "所以，你们每个人都要写一首自己的诗。不要担心它是否完美-我更感兴趣的是窥探你们的内心。"
    "许多学生发出了呻吟声。"
    nothought "写诗..."
    miss "写你想写的任何东西！你们将有剩余的课时来准备。"
    "诺亚的铅笔在纸上敲击着。数学、科学、历史，他发现自己至少在大多数科目上都还不错。"
    "但是诗歌？那是另一回事。"
    nothought "啊..."
    "他看向凯恩和奥古斯特，发现他们两个都已经忙于自己的事情了。"
    nothought "窥探我的灵魂，嗯..."


    window show
    menu:
        nothought "该如何开始呢..."

        "自从我们第一次相遇":
            $ poem_1 = "自从我们第一次相遇"
        "从一开始就":
            $ poem_1 = "从一开始就"

    menu:
        nothought "然后..." #placeholder text

        "你带来了光明照进我的黑暗":
            $ poem_2 = "你带来了光明照进我的黑暗"
        "我的眼睛忍不住追随着你":
            $ poem_2 = "我的眼睛忍不住追随着你"

    menu:
        nothought "还有..." #placeholder text

        "而且我的心一直没有平静下来":
            $ poem_3 = "而且我的心一直没有平静下来"
        "我觉得这种感觉永远不会改变":
            $ poem_3 = "我觉得这种感觉永远不会改变"

    menu:
        nothought "然后..." #placeholder text

        "在梦中，我看到了你":
            $ poem_4 = "在梦中，我看到了你"
        "在梦中，我感受到了你":
            $ poem_4 = "在梦中，我感受到了你"

    menu:
        nothought "还有..." #placeholder text

        "你在月光下苍白的肌肤":
            $ poem_5 = "你在月光下苍白的肌肤"
        "你温柔而亲昵的触碰":
            $ poem_5 = "你温柔而亲昵的触碰"

    menu:
        nothought "最后..." #placeholder text

        "然后，我属于你了":
            $ poem_6 = "然后，我属于你了"
        "然后，我沉浸在你的怀抱中":
            $ poem_6 = "然后，我沉浸在你的怀抱中"

    "诺亚凝视着他的诗歌。这确实出自内心，但他也觉得朗读起来很害羞。"
    miss "好了，我想我们今天就到这里。"
    nothought "该死的..."
    miss "现在，有谁自愿在全班面前朗读吗？没有吗？来吧，没什么好害羞的。"
    miss "好吧，那我就随机选人。"
    miss "诺亚？"
    noteen sur "哈—？"
    noteen sur "我...我真的要吗？"
    miss "是的，是的，总得有人先开始。快点，站到这里来。"
    "手抖得厉害，诺亚紧紧抱住手中的诗稿。"
    nothought "为什么偏偏是我..."
    "但除了从窗户跳出去，他也没有其他逃脱的办法，于是诺亚踉踉跄跄地走到了讲台前。"
    noteen neu "嗯..."

    noteen shy "[poem_1]..." #check this doesnt have double on each poem line""
    noteen shy "[poem_2]..."
    noteen shy "[poem_3]..."
    noteen shy "[poem_4]..."
    noteen shy "[poem_5]..."
    noteen shy "[poem_6]."

    a shy "....."
    miss "多么出色的诗作，诺亚。这是写给某个特别的人的吗？"
    noteen shy "不...不是..."
    miss "回座位吧。还有谁想下一个上来朗读？"
    "诺亚小心翼翼地从本子上撕下那张诗稿，折好后放进了口袋。"
    "教室里一片寂静，但在罗丝小姐随机选人之前，一只手举了起来。"
    a shy "...我来吧，罗丝小姐。"
    miss "太好了！"
    "这个金发男孩走到讲台前时，看起来有些紧张。"
    a shy "在梦中，我看到你出\"，"
    a shy "在一个如此熟悉而亲切的地方。"
    a shy "皎洁的月光高悬于天，"
    a shy "仿佛从高处施加了魔法。"
    a shy "周围的世界寂静无声，"
    a shy "仿佛在等待魔法的流泻。"
    a pou "但突然，一切都消失了，"
    a pou "留下一种失落的感觉。"
    a shy "但当我转头看向身边，"
    a shy "你就在那里，躺在我身边。"
    a shy "在那一刻，我确信，"
    a shy "我们的联系将永远持续。"
    miss "多么动人啊，奥古斯特。你的词语真是太出色了！"
    miss "好了，我想我们今天还有时间再让几个人上来朗读。"
    "在接下来的课堂上，奥古斯特的诗句在诺亚的脑海中盘旋不休。"
    "当铃声终于响起时，诺亚从思绪中清醒过来。"
    "当其他学生涌出教室时，诺亚站在那里，紧紧抱着自己的素描本。"
    "就在他准备离开时，有人轻轻握住了他的手。"
    noteen neu "....."
    a shy "....."
    a sur "啊，对不起—"
    "奥古斯特迅速松开了手。"
    a neu "我只是想说祝你好运。但凭借你的才华和努力，你根本不需要任何运气。"
    noteen shy "...谢谢。"
    noteen pou "我...我宁愿你还是祝我好运..."
    a hap "祝你好运，诺亚。你一定能做到。"

    scene bg school corridor with Fade(1.0, 1.0, 1.0)

    "当其他学生急匆匆地从他身边经过，迫不及待地离开时，诺亚却逆流而上，试图到达那间在下课后属于美术社的房间。"
    "他站在门口，突然感到有些局促不安。"
    miss "诺亚！你果然来了。"
    noteen neu "...是的。"
    miss "请进，请进！"
    "罗丝小姐打开了门，诺亚踏进了门槛。"

    scene bg art with Fade(1.0, 1.0, 1.0):
        subpixel True xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.3 rotate None
        parallel:
            xpos 0.43
            ease 12.74 xpos 0.64

    cl1 "欢迎！"
    cl2 "罗丝小姐竟然真的找到了新人？不可能。"
    cl3 "我还以为她在开玩笑呢。欢迎！你叫什么名字？"
    "一群高年级的学生围住了诺亚，立刻热情地欢迎他。"
    noteen neu "哦...我叫诺亚。"
    cl1 "很高兴认识你，诺亚！"
    cl2 "是啊，有新鲜血液加入真是太好了。"
    miss "诺亚，你为什么不坐下来休息一会儿？"
    noteen neu "呃...我只有十五分钟的时间...但好吧。"
    "诺亚坐在一个空座位上，旁边是一个有着浅橙色头发的男孩。这个神秘的男孩立刻转向诺亚，脸上带着友善的微笑。"
    ul smi "诺亚！"
    noteen sho "嗯...？"
    l smi "你是二年级的学生吧？我叫卢卡，是一年级的。"
    l smi "我能看看你的作品吗？"
    "他立刻伸出手，等着诺亚把素描本递过去。"
    nothought "这里的人真是太直接了..."
    noteen neu "好的。那我也能看看你的作品吗？"
    l smi "好的，给你~"
    l hap "哇哦，诺亚，你简直就是天才！"
    "诺亚翻阅着卢卡的素描本。里面有静物素描和肖像画，技能水平参差不齐，都不太出色。"
    "不过，诺亚还是忍不住对他表示了赞美。"
    noteen neu "哈哈...不，我也没那么厉害。你也很棒。"
    l hap "但你明显比我强多了。我能感觉到我们会成为很好的朋友。"
    l smi "嘿，你是不是被从班上踢出来了？"
    noteen sur "..."
    noteen neu "人们都在说这个？"
    l smi "是啊！大家都在谈论你。"
    noteen sad "..."
    noteen neu "我没有被踢出去，只是换了个班级。"
    l smi "哦，这样啊。嘿，你为什么只待15分钟？"
    noteen shy "我要去买一个重要的人的生日礼物。"
    l smi "你喜欢的人？"
    noteen shy "什么？呃...我不知道。"
    l hap "没关系，没关系，你的秘密我会保守的~"
    noteen shy "没有什么秘密..."
    l hap "嘿嘿，当然没有。"
    l smi "嘿，我们应该合作做一件作品！这样真的会帮我进步很多，你知道吗。哇，我真是太幸运能遇到这么厉害的前辈了..."
    noteen neu "我真的没什么特别的...但我不介意帮助你..."
    "其他学生忙着自己的事情—画画、绘画、雕塑—但每个人都在某个时候来到诺亚身边，谈论他的作品。"
    "不知为什么，这让诺亚感到格外害羞。他并不习惯有人关注他，更不用说关注他通常独自保留的作品了。"
    "卢卡一直粘在他身边。他似乎在社团里很受欢迎。他有一种让人忍不住喜欢上他的个性。"
    l sur "哦，你知道吗？已经过去半个小时了？你不是要走吗？"
    noteen sho "啊，糟糕。对不起罗丝小姐，我得赶紧走了！"
    miss "感谢你来，诺亚。我们期待下次你能再来。"
    "诺亚把卢卡的素描本扔在桌子上，冲出了门，完全忘记了自己还留在卢卡手里的素描本。"

    scene bg classroom sunset with Fade(1.0, 1.0, 1.0)

    noteen sca "哈...哈...对不起，我—"
    kteen sho "哇，慢点，慢点。"
    noteen sca "我迟到了...对不起..."
    kteen neu "没关系。我不介意等你。"
    kteen neu "而且我已经提前完成了明天的作业。我觉得这算是一个胜利。"
    kteen hap "至少我比你做得好。"
    noteen pou "哈...闭嘴吧。"
    "诺亚笑了，终于有机会在从学校另一头狂奔过来后喘口气。"
    "太阳已经开始下山，教室里洒满了橙色的光芒。"
    kteen sad "....."
    kteen neu "好吧，我们该走了，免得商店关门。"
    noteen neu "...是的，我们走吧。"

    scene bg town night with Fade(1.0, 1.0, 1.0):
        subpixel True xpos 0.67 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.52 rotate None

    "当两个男孩走到城里时，夕阳的橙色光芒已经变成了黑夜。并肩而行的两人聊着各种话题。"
    "一如既往。"

    show kaineteen n dim hap at slightleft
    show noahteen n dim neu at slightright
    with dissolve

    k "艺术社怎么样？你现在要成为一个自负的艺术小子了吗？"
    show noahteen n dim pou with dis
    no "总比你现在这个样子强。"
    no "没什么，还行。大家看起来都挺友好的。"
    show kaineteen n dim neu with dis
    k "很好。对了，你有什么想送给奥古斯特的主意吗？"
    show noahteen n dim sca with dis
    no "呃...我以为你会有主意。"
    show kaineteen n dim sho with dis
    k "拜托，我以为你会知道。"
    show kaineteen n dim neu with dis
    k "嗯...我可能会给他买一个新游戏什么的。他好像很喜欢我昨晚带到他家的那些。"
    show kaineteen n dim sad with dis
    k "你自己想个主意吧。我觉得他会更喜欢那样的。"
    "凯恩的表情闪烁了一下，然后又恢复了笑容。"
    show kaineteen n dim hap with dis
    k "给他一些感人的东西，让他记住。"
    "凯恩很快就冲进了附近的游戏店，然后又很快地拿着一个袋子出来了。诺亚在商店橱窗前来回徘徊，试图想出应该买什么。"
    show noahteen n dim pou with dis
    nothought "他会喜欢什么？"
    nothought "什么样的东西会很特别？"
    show noahteen n dim sho with dis
    no "哦..."
    k "有主意了吗？"
    show noahteen n dim neu with dis
    no "是的...等等，我看到了什么。"

    scene bg town night with dissolve:
        subpixel True xpos 0.5 ypos 1.51 xanchor 0.5 yanchor 1.0 zoom 2.16 rotate None
        parallel:
            xpos 0.5
            ease 8.25 xpos 1.06

    "诺亚冲进了商店。在窗边，独自一个人坐着的，是一盆粉色的小植物。"
    noteen sho "........"
    noteen "太完美了..."
    noteen shy "它很小，很可爱...就像他一样。"


    scene bg town night:
        subpixel True xpos 0.67 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.52 rotate None
    show kaineteen n dim hap at slightleft
    show noahteen n dim shy at slightright
    with dissolve


    "当他拿着袋子走出商店时，凯恩探头看了进去。"
    show kaineteen n dim sur with dis
    k "一盆植物？你是要给奥古斯特买礼物还是给你妈买？"
    show noahteen n dim pou with dis
    no "闭嘴。它很可爱..."
    show kaineteen n dim hap with dis
    k "我只是开玩笑，我开玩笑的。我相信他会喜欢的。"
    k "即使我的礼物更酷。"
    stop music fadeout 3.0

    show luka n dim smi at right with dissolve

    l "哟，诺亚！嘿，诺亚！"
    play music sunset fadein 4.0
    "卢卡，就像他的腿里装满了弹簧一样，蹦蹦跳跳地跑到了诺亚身边。凯恩双臂交叉，脸上带着严肃的表情。"
    show kaineteen n dim fro with dis
    k "他想要什么..."
    show noahteen n dim neu with dis
    no "...没事。我们都在罗丝小姐的艺术社。"
    show luka n hap with dis
    l "我真幸运，这么快就能再次见到你。哦，这是给某个特别的人的神秘礼物吗？"
    k "...我们的朋友明天过生日，所以我们来挑选一些礼物。"
    l "哇，她真幸运。我也希望有这么体贴的朋友。"
    k "他。"
    show luka n smi with dis
    l "哦？他？"
    l "我的错。我以为是女孩。我相信他一定会喜欢这些。"
    l "我迫不及待想看看你给我买的礼物，诺亚~！"
    show noahteen n dim sca with dis
    no "...好的。"
    show luka n hap with dis
    l "总之，我得赶快回家，免得我妈开始担心。我听说我表哥今天也要来。"
    l "再见，诺亚~！"
    no "再见。"
    "卢卡弯下身子，捡起一张小小的折叠纸，脸上带着笑容，然后消失在街道上。"

    hide luka with dissolve

    k "........"
    k "那孩子就像一阵龙卷风。"
    no "你说得对..."
    no "我们回家吧。我想在放学后再给奥古斯特这个...我不想整天拿着它。"
    show kaineteen n dim neu with dis
    stop music fadeout 3.0
    k "好主意。"

    scene bg mountains night with Fade(1.0, 1.0, 1.0):
        subpixel True xpos 0.5 ypos 1.0 xanchor 0.5 yanchor 1.0 zoom 1.53 rotate None
        parallel:
            ypos 1.0
            ease 19.75 ypos 1.52

    kteen neu "我可以问你一个问题吗？"
    play music moment fadein 4.0
    noteen hap "你就直接问吧，别问能不能问。"
    kteen sad "你觉得五年后你会在做什么？"
    noteen sho "这有点突然。"
    kteen fro "我最近一直在想这个问题。高中很快就要结束了..."
    kteen neu "那你的计划是什么，大名鼎鼎的艺术家先生？"
    noteen pou "闭嘴。"
    noteen "我不知道。我只要能在一个离这里很远的小城市里，有一间小公寓就足够了，那样我就可以..."
    noteen neu "创作吧，我想。不用有人在我背后盯着。"
    kteen hap "在大城市里有一间工作室公寓，在世界各地办展览，是的，我能想象得到。"
    noteen sad "你少点讽刺就好多了。"
    kteen "我是认真的！"
    noteen pou "是啊，我相信你。那你自己的计划是什么？"
    kteen neu "我也不知道。"
    noteen sur "你不能让我难堪，自己却什么都不说！"
    kteen "嗯..."
    kteen hap "我想我会住在你隔壁，做你的宅男好朋友。为你做饭打扫，而你靠你的艺术赚钱。"
    noteen hap "混蛋。"
    "凯恩咧嘴笑了。"
    kteen "我想这就是你的回答了。"
    noteen "很好。"

    scene bg town night with Fade(1.0, 1.0, 1.0):
        subpixel True xpos 0.5 ypos 2.64 xanchor 0.5 yanchor 1.0 zoom 2.72 rotate None

    kteen hap "晚安，诺亚。"
    noteen hap "晚安。明天见。"


    scene bg livingroom night with Fade(1.0, 1.0, 1.0)
    m "诺亚！你到哪里去了？！"
    noteen neu "别着急。我只是和老师多上了一节课。"
    m "哦..."
    m "你至少应该告诉我一声！外面黑着呢，我很担心...！"
    noteen sad "...对不起。下次我会发短信告诉你。"
    m "你手里拿的是什么？"
    noteen sho "没什么。我很累，所以要去睡觉了。"
    stop music fadeout 3.0
    m "诺亚—"

    scene bg bedroom night with hpunch:
        subpixel True xpos -0.06 ypos 1.45 xanchor 0.5 yanchor 1.0 zoom 2.16 rotate None
    play sound slam

    "他赶紧把那株植物藏在衣柜里，连他那个爱管闲事的母亲也找不到。"
    noteen sad "天啊，我好累..."
    "诺亚把手伸进背包里，在找他的素描本。"
    noteen sur "....."
    noteen sur "糟糕...我把它留在卢卡那里了..."
    noteen sur "我们碰面的时候，他为什么没告诉我？"
    nothought "看来他也忘记了..."
    noteen neu "我明天得去拿回来..."
    play sound knock
    noteen sur "........?"
    play music letmedown fadein 4.0
    scene bg bedroom night with dissolve
    "从窗户传来敲击声。诺亚小心翼翼地走过去，拉开窗帘。"
    "正好看到奥古斯特灿烂的笑容。他敲了敲窗户，然后指了指窗户把手。"
    "诺亚打开滑动门，奥古斯特悄悄地走进房间。"

    show noahteen n dim sur at slightleft
    show august n dim hap glasses at slightright
    $ camera_reset()
    $all_moves(camera_check_points={u'x': [(3551, 0, u'ease'), (29, 14.28, u'ease')], u'z': [(577, 0, u'ease')]})
    with dissolve

    no "你—你在干什么—"
    show august n dim sho with dis
    a "嘘！"
    "诺亚压低声音说道。"
    no "你在干什么—"
    show august n dim hap with dis
    a "我想我们可以兑现那个承诺。"
    no "承诺...？"
    "奥古斯特从背后拿出一大堆绘画用品，脸上挂着灿烂的笑容。"
    no "你...都买了？"
    a "是的。这样我们就可以一起做了。我觉得你会很擅长。"
    a "...说实话，我想既然你已经加入了那个艺术社，你迟早也会开始画画的..."
    a "但我想成为你的第一个。"
    show noahteen n dim shy with dis
    no "................"
    show august n dim sho with dis
    a "画画的第一个。第一个和你一起画画的人！"
    show august n dim shy with dis
    a "啊..."
    no "我也是。"
    "诺亚看了看两栋房子之间的缝隙。"
    show noahteen n dim sho with dis
    no "你是认真的跳过来的吗？"
    show august n dim neu with dis
    a "别告诉我爸爸，他可能会吓得心脏病发作。"
    no "要是你半夜敲我窗户我也会吓得心脏病发作..."
    show august n dim sho with dis
    a "我该走吗？我们可以改天再做。"
    no "不！不，我真的很想和你一起做。"
    show noahteen n dim shy with dis
    no "画画。我真的很想和你一起画画。"
    "诺亚结结巴巴地回答，突然希望自己有时间好好准备一下这种情况。"
    "奥古斯特。在他的房间。在晚上。独处。"
    "他咽了口唾沫。"
    show august n dim hap with dis
    a "那就开始吧！我以前也画过画，但是...我相信你会是我的老师。"
    "他把画具摆在诺亚的桌子上，把诺亚拉下来让他坐在自己对面。"
    a "让我们来画什么呢..."
    a "不如我们试着画花吧？应该很简单，对吧？"
    show noahteen n dim neu with dis
    no "什么样的花？"
    a "让我们互相惊喜吧。"
    "奥古斯特没再说什么，拿起画笔开始在空白的纸上涂抹。"
    "诺亚拿起了一支画笔。"
    "笔在手中的重量感觉很好，很自然，就像它属于这里一样。"
    nothought "一朵像你一样明亮的花。"
    nothought "这很简单。"
    "诺亚稳稳地把画笔贴在纸上，画出了一些绿色、黄色和棕色的粗线条。"
    "不知为什么，这对他来说很容易。他内心感到一种兴奋，仿佛找到了什么真正珍贵的东西。"
    "都多亏了奥古斯特。"
    show august n dim sho with dis
    a "啊..."
    a "天啊..."
    no "我完成了。"
    a "你先展示你的。"
    "诺亚把纸翻过来。上面画着一些美丽的向日葵，在风中轻轻摇曳。"
    show august n dim sur with dis
    a "哇....诺亚，这太棒了！"
    show noahteen n dim hap with dis
    no "它们看起来就像你。"
    show august n dim sho with dis
    a "什么...？像我？"
    a "这就是...你眼中的我？"
    no "是、是的..."
    show august n dim pou with dis
    a "嗯...我真希望我的作品也能像你一样出色，但是...呃..."
    a "看到你的作品后，我已经不好意思展示我的了！"
    show noahteen n dim neu with dis
    no "拜托？我想看看。"
    a "我不行...你太厉害了..."
    show noahteen n dim pou with dis
    no "....."
    a "好吧...但我警告过你了，好吗？"
    "奥古斯特带着尴尬的表情把纸推给诺亚。上面画着一些黑色和红色的斑点，即使眯着眼睛看也不像花。"
    show noahteen n dim neu with dis
    no "....."
    show august n dim shy with dis
    a "........"
    a "别笑。"
    show noahteen n dim hap with dis
    no "哈...哈哈哈...."
    a "我就说你一定比我画得好多了！"
    no "不...不，这很完美。我很喜欢。"
    no "我真的，真的很喜欢。"
    a "哈...那你觉得绘画怎么样？"
    no "这就是我一直想要的。"
    show august n dim hap with dis
    a "那下次我们一起画怎么样？"
    "奥古斯特站起来伸了个懒腰，然后坐在诺亚的床边。诺亚也做了同样的动作，坐在他旁边。"
    no "我很乐意。"
    show august n dim pou with dis
    a "我会努力在下次更好的。"
    no "你现在已经很棒了。"
    a "我不这么认为。"


    show august n dim pou -glasses with dis
    "奥古斯特从脸上摘下眼镜，擦掉了粘在镜片上的一点颜料。"
    show noahteen dim neublu with dis
    no "你...真的很..."
    stop music
    play sound knock

    $all_moves(camera_check_points={u'z': [(577, 0, None), (394, 0.2, u'linear')]})
    show noahteen dim sca with dis
    show august dim sur with dis
    m "诺亚？你在里面睡着了吗？"

    aan "..............."


    m "我进来了。请确保你衣着整洁。"
    hide noahteen
    hide august

    $all_moves(camera_check_points={u'y': [(3084, 0, u'ease')], u'x': [(29, 0, None), (-5540, 12.78, u'ease')], u'z': [(898, 0, u'ease')]})
    with dissolve
    play music unsaid fadein 4.0
    "当门把手响动时，诺亚想到了唯一的办法。他拉着奥古斯特一起倒在床上，把两人都盖在被子里。"
    "在被子下，他们的呼吸交织在一起，融为一体。"
    "门只打开了一条缝，足以让诺亚的母亲探头进来，看到诺亚确实\"睡着\"了。"
    m "...你真的睡着了。"
    play sound doorclick
    "她转身关上了门。"
    noteen shy "....."
    a shy "............"
    noteen "我...很抱歉，我只是—"
    a "没关系。"
    noteen "....."
    noteen "我们明天晚上能一起出去吗？"
    noteen "等你和你爸爸的事情处理完之后。"
    a "...是的。"
    noteen "我...我想她已经走了，我们可以—"
    a "我们...我们可以再这样待一会儿。"
    a "如果你愿意的话。"
    noteen "...是的。"
    noteen "嗯..."
    noteen "我可以问你一个奇怪的问题吗？"
    a "当然可以。"
    noteen "你有没有梦到过我？"
    a "梦到...我？"
    a sho "呃...嗯...那个..."
    noteen "你不用回答—"
    a shy "也许...一两次吧。"
    a "这...可以吗？"
    noteen "是啊..."
    noteen "我不介意..."
    u "奥古斯特？"


    a sur "那是...我爸爸，所以我得走了！"
    noteen neublu "啊，那画画的事—"


    $camera_move(-760, 1447, 716, 0, duration=0)
    with dissolve
    "他立刻从窗户跳了出去，一下子回到了自己的房间。"
    noteen neu "那些画..."
    noteen neu "我...最好把它们藏起来..."
    "诺亚从床上站了起来。旁边还留着奥古斯特刚才躺过的印痕。"
    "那里还很温暖。"
    "他把那些已经干了的画作和画具都藏进了衣柜，旁边就是他为明天准备的那盆植物。"
    "诺亚抬头看了看时钟。"
    "凌晨12：10。"
    nothought "啊，糟糕，我应该说生日快乐的。"
    "诺亚及时把头伸出窗外，正好看到奥古斯特的父亲离开房间。他深邃的绿色眼睛带着笑意转向诺亚。"
    "在放下百叶窗之前，他用口型对他说了\"生日快乐\"。"
    noteen neu "他确实梦见了我...我确信不疑。"
    noteen neu "那么..."
    noteen neu "如果我再次尝试...会发生什么呢？"
    "诺亚咽了口唾沫，回头看向自己的床。"
    nothought "如果妈妈发现我不在这里..."
    "怀着这个想法，他开始执行自己的计划。他把多余的枕头塞进被子里，做出一个足够像人的隆起。"
    nothought "这样就行了。"
    "这个黑发男孩背靠窗户滑下，直到坐下。他羞涩地闭上眼睛。"
    nothought "我想看看奥古斯特会怎么想。我想看看他的梦。我想进入他的梦。"
    nothought "我想和奥古斯特在一起。我想看看奥古斯特对我的想法。"
    stop music fadeout 3.0
    nothought "让我进入他的梦—"

    window hide
    show black with dis2
    show transition movie onlayer overlay
    pause 3.0
    window show
    play music traintodarkness fadein 3.0
    "空气从他胸中逸出，他艰难地喘息着，因为地面从他脚下消失，诺亚被抛入无尽的虚空。"
    "他四处挥舞着双臂，寻找。寻找什么，任何可以抓住的东西。"
    "但什么也没有。"
    "只有黑暗。"
    "他紧闭双眼，思考着。"
    "关于那个金发绿眼的男孩。"
    "最后，他落到了地面。"
    $ camera_reset()

    scene bg town night with hpunch:
        subpixel True xpos 0.92 ypos 1.19 xanchor 0.5 yanchor 1.0 zoom 1.92 rotate None
    play sound fall2
    noteen sca "啊啊啊啊啊啊啊啊啊啊啊啊—！"
    noteen sur "哈...哈...我在哪里？"
    noteen neu "外面？"
    "街道死一般寂静。诺亚从口袋里掏出手机，但时间不停地变化，几小时在几秒内就过去了。"
    "他掐了掐自己。"
    noteen sad "哎呀..."
    noteen neu "我真的在这里..."
    "在他的眼前，诺亚目睹了一个场景的发生。"
    "凯恩和一个与自己非常不同，却又完全一样的诺亚，离开了一栋房子，穿过马路，然后绕回到奥古斯特的房子，然后进去了。"
    noteen sur "这是...昨晚的事吗？那就是他在做梦吗？"
    noteen neu "那么..."
    nothought "我得弄清楚到底发生了什么。"
    "诺亚回头看向自己的房子。"
    nothought "我要学学奥古斯特的做法。如果这是个梦的话...我的父母应该不会在那里，对吧？"

    scene bg livingroom night with Fade(1.0, 1.0, 1.0)
    play sound static
    "房子里某个地方传来电视机的声音。除此之外，整个房子里一片寂静。"
    "直到一个声音响了起来。"
    m "他要让我们的儿子变得{i}奇怪{/i}。哦，亲爱的，我该怎么办呢..."
    "那个男人安慰着那个女人，把胳膊搭在她的肩膀上。"
    f "我们只需要把他除掉。把他除掉。"
    f "把他除掉。"
    m "把他除掉。"
    m "把他除掉。"
    m "把他除掉。"
    m "把他除掉。"
    m "是的，把他除掉。"
    "诺亚悄悄地靠近。靠近电视机，靠近父母的声音。"
    play sound mechbreak
    "突然，他们两个的头都以180度的角度扭了过来，盯着他，然后脱离了脖子。"
    noteen sca "....."
    "电视机里的杂音停了下来。"
    "诺亚走近那些尸体，但不是他预料中的肉体，而是由金属制成的。"
    noteen sca "....."
    noteen sca "这就是...奥古斯特对我父母的看法吗？"
    nothought "没时间管这个了。我得去见奥古斯特。"
    stop music fadeout 3.0
    "留下父母破碎的尸体，诺亚飞快地跑上楼梯，回到了自己的房间。"

    scene bg bedroom night with Fade(1.0, 1.0, 1.0)

    "他的卧室和他离开时一模一样，只有一个细节不同。"
    "在他的桌子上，有一幅画。上面是一幅肖像画。"
    "他拿起来仔细看着。"
    play music moment fadein 3.0
    "一幅自己的肖像画。周围是黑色和红色的花朵。"
    nothought "这就是他上次来的时候想要画的吗？"
    nothought "这就是你对我的看法啊..."
    scene bg bedroom night with dis:
        subpixel True xpos 0.5 ypos 1.69 xanchor 0.5 yanchor 1.0 zoom 2.28 rotate None
        parallel:
            xpos 1.06
            ease 13.35 xpos 0.6
    "诺亚望向通往阳台的滑动门。"
    nothought "他就在那边。"

    "他小心翼翼地打开滑动门，只打开到能挤进去的程度。在另一边，窗帘也只打开了一点点，足以让他往里窥视。"

    scene bg sky night with Fade(1.0, 1.0, 1.0)

    "小心翼翼地，他从一个阳台跳到另一个阳台，勉强避免了摔下去。"
    "卧室里，一幕戏开始上演。"
    "「诺亚」抓住奥古斯特，认真地盯着他。"
    noteen shy "这是..."
    dno "......"
    dno "我...我可以问你一个问题吗？"
    da "当然可以。你可以问我任何事。"
    dno "你...呃...嗯.."
    dno "我的意思是—"
    dno "我想问的是...呃...如果你，也许..."
    dno "喜欢男孩子？"
    dno "呃...我的意思是，如果你是的话，我...我会很支持你的，而且这和我父母无关。"
    dno "我只是...在好奇..."
    da "..."
    da "是的。我喜欢你。"
    dno "....."
    dno "我...我也是...我喜欢你。"
    "就在两个男孩越靠越近，嘴唇只有几英寸之遥时，诺亚突然惊跳起来，失去平衡，从阳台上摔了下去。"

    scene black with hpunch

    "但他并没有摔到地上，周围的世界变成了黑暗，他再次坠入了那个虚无之中。"
    "他感觉自己既像是一瞬间，又像是永恒般地坠落，直到背部终于撞到了一些柔软的东西。"
    stop music fadeout 3.0

    scene bg bedroom day with Fade(1.0, 1.0, 1.0)

    play sound alarmclock

    noteen sho "........."
    noteen "早上...已经..."
    "他卧室的门打开了，他的母亲皱着眉头看着他。"
    play music thiscloud fadein 3.0
    m "快起床了，诺亚。你的闹钟已经响了20分钟了。"
    noteen sur "........"
    noteen sur "糟糕，我要迟到了...！"
    m "诺亚！注意你的语言！"
    m "天哪，至少你哥哥不是那么个...脏话连篇的家伙。"
    play sound doorclick
    "她一边摇着头表示失望，一边关上了门。"
    "诺亚从床上跳起来，刷牙穿衣，然后急匆匆地下楼，走出房子，沿着山路赶往与朋友们的集合地点。"

    scene bg mountains day with Fade(1.0, 1.0, 1.0)

    noteen sad "啊啊啊...我真的很抱歉...！"
    kteen hap "看看谁终于决定光临我们了。"
    kteen hap "睡得好吗？"
    nothought "一点也不好..."
    noteen neu "哈...哈...是啊，当然..."
    noteen hap "生日快乐，奥古斯特。"
    a hap "嘿嘿，谢谢你，诺亚。你可不像是会睡懒觉的人。"
    nothought "你们都不会相信我昨晚真正在做什么。"
    noteen neu "...是啊。我的错。"
    kteen neu "我们最好快点，不然就要迟到了。"

    scene bg classroom day with Fade(1.0, 1.0, 1.0)

    "这一天过得有些模糊，转眼就到了该离开的时候。"
    "一到下课铃响，全班同学就围住了奥古斯特，祝他生日快乐。"
    kteen neu "准备走了吗？"
    noteen neu "...我得先去艺术社。我昨天把素描本落在那里了。"
    noteen neu "你们先走吧，我会跟上的。"
    kteen neu "好的。那待会见。"

    scene bg art with Fade(1.0, 1.0, 1.0)

    miss "卢卡，这太棒了！你应该为自己感到骄傲。"
    l hap "啊哈哈，罗丝小姐，你太过奖了~"
    noteen neu "发生什么事了？"
    miss "看看这个，诺亚。卢卡说你给了他很大的启发，所以他昨天就回去画了这幅画。"
    miss "进步真是太棒了。我就知道有你在这里，大家都会被激励着进步的。"
    stop music
    play sound heart
    noteen sho "......"
    nothought "那是..."
    play music traintodarkness fadein 3.0
    "卢卡露出一个勉强的笑容，然后把胳膊搭在诺亚的肩膀上。"
    l smi "我真的很崇拜你，诺亚。"
    miss "继续努力，你一定会进步得更多的，卢卡。"
    "罗丝小姐因为某些事离开了房间，留下卢卡和诺亚独处。"
    "诺亚挣脱开卢卡，怒视着他。"
    noteen ang "这到底是怎么回事？！"
    l smirk "奥古斯特喜欢他的礼物吗？"
    noteen sur "..........."
    noteen sho "我...我完全不知道你在说什么。"
    l smirk "哦？我被告知，你买礼物的那个人，就是这首诗的主角。"
    "卢卡从口袋里掏出一张折叠的纸。"
    "诺亚僵住了。"
    l smirk "[poem_1]..."
    l smirk "[poem_2]..."
    noteen sur "闭嘴...！"
    l smirk "不喜欢自己的作品吗？"
    l smirk "总之，我真的很抱歉借用你的画给罗丝小姐看..."
    l smirk "但你不想让所有人知道你对奥古斯特有意思，对吧？"
    l smirk "嘿，我不在乎你喜欢谁，但我相信你不希望所有人都知道吧？"
    noteen sho "......."
    l sad "奥古斯特不是六个月前才搬来的吗？天啊...如果大家知道了你们两个的事，可能会给他带来很大麻烦..."
    l hap "你也不想让他{i}再次{/i}转学吧？"
    noteen ang "你...你错了...！"
    "一直挂在卢卡脸上的笑容立刻消失了，取而代之的是一个嘲讽的表情。"
    l ann "要么你继续为我画画，要么我就告诉所有人关于你的事。全校的人都会知道。你的家人也会知道。"
    l ann "如果你不想让这种事发生，就乖乖闭嘴，为我画下一幅杰作，明白吗？"
    "他的笑容，虽然和之前一样虚假，但还是回到了他的脸上。"
    l hap "给你，你的画册~"
    l smi "这就是你在找的东西，对吗？"
    "诺亚从他手中抢过来，冲出了房间。"

    scene bg school corridor with Fade(1.0, 1.0, 1.0)

    "他的愤怒沸腾了，溢出无处可去。走廊已经空了，死一般的寂静。"
    "诺亚紧紧抓着他的素描本。"
    nothought "混蛋...！"
    nothought "我不在乎...我不在乎发生什么事，但是奥古斯特...！"
    window hide


    scene bg town sunset with swipe
    pause 1.0
    scene bg mountains night with swipe
    pause 1.0
    scene bg bedroom night with swipe
    window show

    noteen ang "去他妈的那个家伙！"
    noteen ang "该死的...操...妈的..."
    noteen sho "一切都...崩溃了..."
    "诺亚迅速走到衣柜前，拿出他为奥古斯特隐藏的礼物。旁边是他们前一晚做的两幅画。"
    "诺亚的思绪回到了他在奥古斯特梦中看到的肖像画。"
    noteen sad "......."
    noteen sad "好吧...这很好...我就为他画画..."
    "他把素描本扔到桌子上，打开一个空白页，握着铅笔。"
    "他随意涂鸦着这样那样的东西，心却飘到了一个卢卡无法触及的地方。"
    "不知不觉，时钟已经指向了晚上11点。"
    stop music fadeout 3.0
    noteen neu "希望他还没睡。"
    "诺亚小心翼翼地打开了阳台门。对面房间的百叶窗已经拉上了。"
    "不过，他还是轻松地跳了过去，敲了敲窗户，把礼物藏在背后的袋子里。"
    "只过了一会儿，一个像太阳一样灿烂的笑容的男孩就打开了门。"

    scene bg sky night with dissolve
    play music autumn fadein 3.0
    a hap "诺亚..."
    noteen neublu "生日快乐，奥古斯特。"
    noteen "...我在想...要不要一起去河边？我们可以在那里待一会儿。"
    a shy "好啊，我很乐意。不过你的父母会同意吗...？"
    noteen "嗯，不会，但我在想我们可以就..."
    "他低头看了看两栋房子之间的缝隙。"
    noteen "也不是很远。"
    "奥古斯特笑了起来。"
    a hap "我们真的要偷偷溜出去了！"
    noteen "是的。"
    "诺亚先跳了下去，然后伸手接住了跟着跳下来的奥古斯特。"

    scene bg mountains night with Fade(1.0, 1.0, 1.0)


    a shy "夜晚的这里确实看起来很不一样。"
    "萤火虫在黑夜中闪烁，飘浮在两人周围。"
    noteen hap "小心别滑倒了。"
    a hap "来吧，我比刚来的时候强多了！"
    noteen neublu"..."
    noteen "你和你爸爸吃晚饭怎么样？"
    a "很好。我不想要任何礼物，但他还是给我买了东西。"

    noteen hap "听起来不错。"
    noteen "啊，就从这里。"

    scene bg river night
    show august n dim hap glasses at slightright:
        xpos 0.69 ypos 1.0 xanchor 0.8 yanchor 1.0
    show noahteen n dim neublu at slightleft:
        xpos 0.28 ypos 1.0 xanchor 0.2 yanchor 1.0

    $all_moves(camera_check_points={u'z': [(577, 0, u'linear')]})
    with Fade(1.0, 1.0, 1.0)

    "诺亚先坐了下来，盯着缓缓流动的河水。奥古斯特很快也加入了他，两人并肩而坐。"
    "天空中星星点点，数也数不清，但奥古斯特还是仰望着天空，试图数数。"
    a "太美了..."
    a "这是我住过的最美丽的地方。如果没有你，我也看不到这些。"
    show noahteen n dim shy with dis
    no "这不是真的..."
    no "...搬来搬去一定很辛苦吧。"
    show august n dim sadsmi with dis
    a "是的。"
    no "我，呃...希望你能一直留在这里，说实话。"
    no "也许这很自私，我不知道。但是，我...喜欢你在这里。"
    show august n dim shy with dis
    a "我也是。我真的...想留下来。"
    a "我爸爸也喜欢这里。我想我们不会再搬家了。"
    a "所以...我们两个可以在一起更多时间。"
    no "这...这太好了。"
    no "咳咳..."
    show noahteen n dim shy with dis
    no "我...给你买了点东西。生日快乐。"
    "诺亚紧张地递过纸袋。"
    show august n dim sho with dis
    a "什么—你不用这样..."
    "奥古斯特小心翼翼地打开了袋子。"
    no "...呃，也许你不会喜欢，如果你不喜欢也没关系！"
    no "你不必收下。如果太蠢的话，我可以拿回去换个别的—"
    show august n dim cry with dis
    "奥古斯特发出了一声抽泣。"
    no "啊—啊...没事，我可以—"
    a "...你为我挑选的？"
    show august n dim hap with dis
    a "我爱它。诺亚，我太爱它了。"
    show noahteen n dim neublu with dis
    no "哦...哦。"
    a "谢谢你。真的。"
    a "这是...你真的考虑过要送我什么，对吗？你一直都这么体贴。"
    "诺亚抓了抓头，不确定该如何回答。"
    "奥古斯特擦掉眼角聚集的泪水，自己也拿出了一样东西。"
    "一台粉色相机。"
    a "我可以拍张照片吗？拍你。为了纪念这一刻。"
    show noahteen n dim shy with dis
    no "好...好的。"
    no "呃，实际上...我们能一起拍一张照片吗？"
    a "是的！"
    "奥古斯特把相机反过来拿，靠近诺亚，脸上带着微笑，尽管眼睛还有些红。"
    "咔嚓一声，一张照片开始打印出来。"
    "诺亚的心跳漏了一拍，他们离得这么近。他靠在草地上，望着天空。"
    no "你应该和我一起看星星。"
    show august n dim shy with dis
    a "........"
    "奥古斯特凝视着诺亚，面容柔和但坚定。"
    a "你脸上有东西。闭上眼睛，我来帮你弄掉。"
    show noahteen n dim neu with dis
    no "哦，好的。"
    "诺亚立即闭上了眼睛。"



    scene gallery_14 with Fade(1.0, 1.0, 1.0)

    "这短短的一瞬间就是奥古斯特所需要的。"
    "诺亚睁开眼睛，感到一种柔软的东西贴在了他的嘴唇上，吓了一跳。"
    "在星星在他们周围跳动，河流永无止境地流淌着时，奥古斯特吻了诺亚。"
    "诺亚像个雕像一样一动不动，最终放松下来，回吻了奥古斯特。"
    "他们的初吻。"
    "这是诺亚在内心深处一直想象的场景。"
    "但实际情况与他梦中的不同。更加柔软，更加温暖。"
    "他的心脏随时都可能跳出胸膛。"
    "但他仍然回吻了奥古斯特。"
    nothought "这不是梦...对吗？"

    scene gallery_15 with dissolve

    no "........."
    a "......"
    a "我喜欢你，诺亚。我真的很喜欢你。非常喜欢。"
    a "谢谢你的礼物。"
    no "我...我..."
    no "我也很喜欢你。"
    a "...真的吗？"
    "奥古斯特惊讶地盯着诺亚的脸。"
    a "我简直不敢相信。能这样俯视着你，感觉就像在做梦。"
    no "...也许我真的在做梦。"
    a "但愿不是。"
    a "...你知道，一开始我还以为你讨厌我。"
    no "什么？！我怎么可能...！？"
    a "哈哈哈...我也不知道。我甚至想不出为什么会这么想。"
    no "我怎么可能讨厌你，当你是这么...这么..."
    no "...就是你。"
    a "...."
    a "诺亚，你..."
    a "你...你愿意...和我交往吗？"
    no "................."
    no "呃...好的。"
    a "我也是。"
    no "你有没有，呃...像，和两个男生..."
    "奥古斯特摇了摇头。"
    a "你偷走了我的初吻。"
    no "喂...是你自己偷的啊...！"
    "奥古斯特只是笑了笑，紧张的表情终于放松下来。"
    a "这真的是有史以来最棒的生日。"
    "诺亚越过奥古斯特的肩膀，望向天空。"
    no "我能告诉你一件听起来很疯狂的事情吗？"
    a "一直都有。"
    no "........."



    scene bg river night
    $ camera_reset()

    $camera_move(0, 0, 599, 0, duration=0)
    show noahteen n dim shy at slightleft:
        xpos 0.28 ypos 1.0 xanchor 0.2 yanchor 1.0

    show august n dim shy glasses at slightright:
        xpos 0.69 ypos 1.0 xanchor 0.8 yanchor 1.0
    with Fade(1.0, 1.0, 1.0)

    no "昨晚我进入了你的梦境。"
    show august n dim sho with dis
    a ".......？你在说什么？"
    show noahteen n dim neu with dis
    no "我想...我好像...能进入别人的梦境？"
    a "...真的吗？"
    show noahteen n dim sho with dis
    no "等等，你相信我？"
    a "好吧，我觉得你没有理由对我撒谎。"
    show august n dim neu with dis
    a "不过，这听起来还是有点...嗯，疯狂。"
    no "我知道。我可以...嗯，我可以证明。"
    show noahteen n dim neu with dis
    no "...昨晚，你梦到了..."
    show noahteen n dim shy with dis
    no "呃...我们在你的房间里...然后我们..."
    "奥古斯特惊讶地眨了眨眼睛。"
    show august n dim sur with dis
    a "你...看到了？"
    show august n dim shy with dis
    a "啊啊啊啊啊！"
    show noahteen n dim sho with dis
    no "我简直不敢相信你现在竟然相信我。"
    a "从什么时候开始的？"
    show noahteen n dim neu with dis
    no "这只发生过两次。第一次...是在我去你家的时候..."
    no "我们在学校，然后..."
    show august n dim sur with dis
    a "好吧！好吧，我记得..."
    show august n dim shy with dis
    a "我还以为我对自己的感情很谨慎呢..."
    a "你可以...随时都这样做吗？"
    no "我不知道。"
    show august n dim sho with dis
    a "我们现在就试试吧？"
    show noahteen n dim sho with dis
    no "现在就试？！"
    show august n dim hap with dis
    a "对啊！"
    no "但是...如果很危险怎么办？"
    a "别担心，我会保护你的。"
    a "就像乌鸦守护它的宝藏一样。"
    show noahteen n dim pou with dis
    no "嗯..."
    no "我不是什么宝藏..."
    a "我不同意。来吧，我们应该试试！"
    no "那...我们应该去哪里？"
    show august n dim neu with dis
    a "不如去我爸爸的梦境？"
    show noahteen n dim neu with dis
    no "那...我们就试试吧。"
    "两人小心翼翼地牵起了手，诺亚闭上眼睛集中精神，直到感受到那熟悉的拉扯感。"
    "就像一根拉扯着、催促着他靠近的线。"
    "说服他，推动他放弃他所谓的现实世界，沉浸进另一个梦境。"
    "他们终于坠落了。"



    window hide
    show black with dis2
    hide august
    hide noahteen
    show transition movie onlayer overlay
    pause 3.0
    window show

    a sur "啊啊啊啊——！"
    a sur "诺、诺亚，发生什么事了？！"
    noteen sca "应该、应该很快就会停下来的...！"
    "他们的手还紧紧相握，两人旋转着坠入黑暗之中，直到周围再也没有黑暗。"

    scene bg augusthome
    $ camera_reset()

    $all_moves(camera_check_points={u'z': [(380, 0, u'linear')]})
    show noahteen n sho at slightleft
    show august n sur glasses at slightright
    with Fade(1.0, 1.0, 1.0)

    no "啊..."
    a "啊！"
    a "哎哟...你没告诉我会有坠落啊..."
    show noahteen n sad with dis
    no "对不起..."
    show noahteen n neu with dis
    no "不过我们现在到底在哪里呢？"
    "奥古斯特终于环顾四周，深吸了一口气。"
    show august n sho with dis
    a "这里是..."
    a "这是..."

    $all_moves(camera_check_points={u'z': [(380, 0, None), (65, 2.37, u'ease')]})

    show noahteen n neu at left
    show august n sho at center
    with move
    show augustdad n hap glasses at right with dis
    j "奥古斯特！你也带来了诺亚！"
    a "...父亲。"
    "奥古斯特的父亲从一扇敞开的门走进厨房，脸上挂着他一贯的微笑。"
    j "快来坐吧！我给生日小子和他的特别之人留了位置。"
    a "......."
    no "毕竟今天是你的生日。"
    "诺亚和奥古斯特在餐桌旁落座。房子虽然不大，但诺亚一进来就有种宾至如归的感觉。"
    "就像奥古斯特和他的父亲一样，这里也有种温暖的感觉。"
    no "你知道我们现在在哪里吗？"
    a "...这是我童年的家。在我们开始四处漂泊之前。已经很久没来了..."
    show august n sadsmi with dis
    a "感觉太真实了..."
    no "..."
    no "是啊，确实如此。"
    j "你们两个就在这里等着，我马上回来。"
    hide augustdad with dissolve

    $all_moves(camera_check_points={u'y': [(0, 0, None), (-490, 1.77, u'ease')], u'x': [(0, 0, None), (-3523, 1.77, u'ease')], u'z': [(65, 0, None), (570, 1.77, u'ease')]})
    "奥古斯特的父亲又回到了刚才走出的那个方向。"
    "奥古斯特抚摸着木制的桌面，然后掐了一下自己。"
    show august n sho with dis
    a "我们真的在这里。"
    no "很奇怪，对吧？"
    a "这太...太棒了。"
    show august n hap with dis
    a "你一直都很了不起，所以我一点也不觉得惊讶。"
    show noahteen n shy with dis
    no "这不是真的..."
    no "我也不知道为什么会突然发生这种事。"
    show august n sca with dis
    a "啊..."
    show noahteen n sho with dis
    no "奥古斯特？"
    "奥古斯特把手放在头上思考了一会儿，然后摇了摇头。"
    a "没事的。我只是头有点疼。它会好起来的。"
    j hap "生日快乐给你，生日快乐给你，生日快乐亲爱的奥古斯特..."
    "突然，一个声音从两个男孩身后唱了出来。他们惊讶地转过身，正好看到..."
    amom "生日快乐~！"
    show august n sur with dis
    a "......"
    show august n sho with dis
    a "妈...妈妈....？"
    amom "独一无二的她！生日快乐，小家伙。"
    "她的声音平稳而冷静，很像奥古斯特。她翠绿的眼睛与他的完全一样。"
    "仅仅这几句话，眼泪就开始从奥古斯特的眼中涌出。"
    show august n cry with dis
    a "我...我..."
    a "你，我..."
    amom "好了好了。怎么了？不想吃蛋糕吗？"
    "她说着，奥古斯特的父亲在桌子中间放下了一个大蛋糕。"
    show august n sadsmi with dis
    a "不，我...我是...太完美了..."
    "他从座位上跳起来，迅速地把双臂环抱住那个女人。奥古斯特轻轻地抱着她，好像害怕她会碎成碎片一样。"
    a "我一直...一直想见到你..."
    amom "你在说什么呢，亲爱的？我永远都在这里陪着你。"
    "她笑了，声音轻快而飘逸。"
    amom "即使有一天我不在了，我也会永远在这里。"
    "她退后一步，把手掌贴在他的胸口，正对着他的心脏。"
    amom "永远。好吗？"
    a "是的...是的，永远。"
    j hap "在我们引发烟雾报警器之前，快吹灭这些蜡烛吧。"
    "不情愿地，奥古斯特终于放开了母亲，重新坐回椅子上。"
    amom "别忘了许愿。"
    a "是的。"
    a "我会许愿的..."
    "他闭上眼睛，泪水仍然顺着脸颊流下，沉默地许下了愿望。"
    "最后，他睁开眼睛，吹灭了蜡烛。"
    show august n sur with dis
    "火焰一熄灭，周围的世界就开始崩塌。奥古斯特害怕地在诺亚和母亲之间看来看去。"
    show noahteen n neu with dis
    no "我想...我想是时候走了..."
    show august n sad with dis
    a "..."
    a "是的。"
    show august n sadsmi with dis
    a "我爱你，妈妈。"
    amom "我也永远爱你。"
    amom "照顾好他，诺亚，好吗？"

    scene black with Fade(1.0, 1.0, 1.0)

    "两人坠落，奥古斯特母亲的话语是这个小小世界最后的存在。"
    "在坠落的过程中，奥古斯特的声音穿过黑暗。"
    a sadsmi "你觉得那就是她真正的样子吗？"

    scene bg river night with hpunch
    play sound bodyhit
    noteen sca "啊..."
    noteen sca "说真的，为什么会这么痛..."
    "诺亚接住了奥古斯特。不知为什么，他没有移动，而是轻轻拍着他的背。"
    noteen  neu "...那就是你爸爸记忆中的她。我想那就是她真正的样子。"
    a sadsmi "......"
    a sadsmi "谢谢你，诺亚。这是我过过最棒的生日了。"
    "奥古斯特带着红肿的眼睛对他微笑。"
    a hap "我会永远记住这一天。"
    noteen shy "..."
    noteen shy "我也是。不过我们最好还是回去，免得有人发现。"
    stop music fadeout 5.0
    "在黑暗中，远离窥探的眼睛，在只属于两人的世界里，诺亚和奥古斯特的手指轻轻地交织在一起，走回了里面。"


    jump crow_chapter2

    ########## end crow 1 ########################################




















#
