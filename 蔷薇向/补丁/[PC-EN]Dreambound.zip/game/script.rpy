define quotepre = _("\"")
define quotesuf = _("\"")

default persistent.show_kickstarter = False #TODO remove Kickstarter references after kickstarter ends

default gametype = "ADV"

init python:
  def eyewarp(x):
    return x**1.33
  eye_open = ImageDissolve("Various/eye.png", 1.0, ramplen=128, reverse=False, time_warp=eyewarp)
  eye_shut = ImageDissolve("Various/eye.png", 1.0, ramplen=128, reverse=True, time_warp=eyewarp)

  eye_open_fast = ImageDissolve("Various/eye.png", 0.3, ramplen=128, reverse=False, time_warp=eyewarp)
  eye_shut_fast = ImageDissolve("Various/eye.png", 0.3, ramplen=128, reverse=True, time_warp=eyewarp)

$ config.nvl_adv_transition = dissolve
$ config.adv_nvl_transition = dissolve
define build.include_i686 = False
define adv_menu = menu

#####
default persistent.chapter1_escapecomplete = False
default persistent.chapter2_escapecomplete = False

default game_type_ver = "puzzle" # puzzle or VN to determine if they play the escape segments

# Achievements
init python:
    achievement.register("Prologue_Complete")
    achievement.register("Chapter1_Complete")
    achievement.register("Chapter2_Complete")
    achievement.register("Crow_BadEnd")
    achievement.register("Crow_NeutralEnd")
    achievement.register("Crow_GoodEnd")
    achievement.register("Ivan_BadEnd1")
    achievement.register("Ivan_BadEnd2")
    achievement.register("Ivan_NeutralEnd")
    achievement.register("Ivan_GoodEnd")
    achievement.register("Kaine_BadEnd")
    achievement.register("Kaine_NeutralEnd")
    achievement.register("Kaine_GoodEnd")





##### Poem Counters
default poem1 = "test"
default poem2 = "test"
default poem3 = "test"
default poem4 = "test"
default poem5 = "test"
default poem6 = "test"

default counter_poem = 0
default snap1 = False
default snap2 = False
default snap3 = False
default snap4 = False
default snap5 = False
default snap6 = False

# Character relationship route points
default IvanRoute = 0
default KaineRoute = 0
default CrowRoute = 0

## Route Points
default CrowPoints = 0
default IvanPoints = 0
default KainePoints = 0

default ending = ""

# Choice variables
default chapter2_crowname = True
default chapter2_crowdoing = True
default chapter2_crowivan = True
default chapter2_crowcounter = 0

#Crow route variables
default crow_goodend = 0
default kainescomputer_counter = 0
default kainescomputer_list = False
default kainescomputer_browser = False

default poem_1 = ""
default poem_2 = ""
default poem_3 = ""
default poem_4 = ""
default poem_5 = ""
default poem_6 = ""

#Ivan Route Variables
default prisonerquestion = False
default anybodyelsequestion = False

default daisyquestion = False
default ivanquestion = False
default photoquestion = False
default ivan2_questionasked = False


default persistent.any_ending = False
# Normal
# Major Characters
define narrator =Character(None, ctc="ctc_blink")
define no = Character(_('诺亚'), image="noah", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e") # Noah
define noteen = Character(_('诺亚'), image="noahteen", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e") # Noah teen for side images
define nothought = Character(None, what_italic=True, ctc="ctc_blink") # Noah thoughts
define k = Character(_('凯恩'), image="kaine", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define kteen = Character(_('凯恩'), image="kaineteen", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define a = Character(_('奥古斯特'), image="august", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define c = Character(_('克劳'), image="crow", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define n = Character(None,centered, what_cps=40, window_background=None, what_xsize=1250, what_line_spacing=20)
define u = Character(_('???'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define i = Character(_('伊万'), image="ivan",  what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define iteen = Character(_('伊万'), image="ivanteen",  what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define ua = Character(_('???'), image="august", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define ithought = Character(None, what_italic=True, ctc="ctc_blink") # Ivan thoughts
define sun = Character(_('阳光'), image="august", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define dno = Character(_('\"诺亚\"'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define da = Character(_('\"奥古斯特\"'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")


# Minor Characters
define cl1 = Character(_('同学1'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define cl2 = Character(_('同学2'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define mrf = Character(_('弗洛伊德先生'), image="mrf",what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define tv = Character(_('电视'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define f = Character(_('父亲'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define m = Character(_('母亲'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define phone  = Character(_('电话'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define bus1 = Character(_('穿西装的商人'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define bus2 = Character(_('戴眼镜的商人'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define guard = Character(_('守卫'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define p = Character(_('校长'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define miss = Character(_('罗丝小姐'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define w = Character(_('服务员'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define gg = Character(_('守门人'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define ash = Character(_('艾许'), image="asher", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define reu = Character(_('鲁本'), image="reuben", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define d = Character(_('黛西'), image="daisy", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define e = Character(_('以利亚'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define pp = Character(_('皮尔森教授'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define yn = Character(_('年轻的诺亚'), image="noahteen", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define j = Character(_('贾斯帕'), image="augustdad",  what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define l = Character(_('卢卡'), image="luka",  what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define r = Character(_('罗莎米'), image="rosamie",  what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define ivanm = Character(_('妈妈'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define un = Character(_('叔叔'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define au = Character(_('姑姑'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define aim = Character(_('艾米'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define own = Character(_('经理'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define vi = Character(_('薇薇安'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define w1 = Character(_('工人1'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define w2 = Character(_('工人2'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define asp = Character(_('阿斯彭'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define asmom = Character(_("阿斯彭的妈妈"), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define asdad = Character(_("阿斯彭的爸爸"), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define oldm = Character(_('老人'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define ian = Character(_('伊万 & 诺亚'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define door = Character(_('门'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define aan = Character(_('奥古斯特 & 诺亚'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define ul = Character(_('???'), image="luka", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define cl3 = Character(_('同学3'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define am = Character(_('语音信箱'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define amom = Character(_("奥古斯特的妈妈"), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define dun = Character(_('???'), image="daisy", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define maf = Character(_('父亲 & 母亲'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define iam = Character(_('伊万 & 诺亚'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define s = Character(_('黑影'), image="shadow", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define ur = Character(_('???'), image="rosamie", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define fb = Character(_("父亲的老板"), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define rec = Character(_('接待员'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define uc = Character(_('???'), image="crow", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define bw = Character(_("老板的妻子"), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define pv = Character(_('幻影的声音'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define fp = Character(_('第一个幻影'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define sp = Character(_('第二个幻影'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define tp = Character(_('第三个幻影'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define pr = Character(_('决心幻影'), size=40, what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define kf = Character(_("凯恩的父亲"), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define km = Character(_("凯恩的母亲"), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define bv = Character(_('喘息的声音'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define fv = Character(_('熟悉的声音'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define kf1 = Character(_("凯恩的朋友"), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define kf2 = Character(_("凯恩的其他朋友"), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define sv = Character(_('颤抖的声音'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define ms = Character(_('男学生'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define cv = Character(_('关切的声音'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define sv = Character(_('轻柔的声音'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define mf = Character(_('神秘的身影'), image="shadow", what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define dw = Character(_('失望的女人'), size=40, what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")
define voi = Character(_('声音'), what_prefix='[quotepre!t]', what_suffix='[quotesuf!t]', ctc="ctc_blink", color="#ecb92e")

# NVL
# Major Characters
define nonvl = Character(None, kind=nvl, what_prefix="诺亚: \"", what_suffix='[quotesuf!t]', what_color="#FFFFFF", ctc="ctc_blink") # Noah NVL
define notnvl = Character(None, kind=nvl, what_italic=True, ctc="ctc_blink") # Noah's thoughts in NVL
define knvl = Character(None, kind=nvl, what_prefix="凯恩: \"",  what_suffix='[quotesuf!t]', what_color="#FFFFFF", ctc="ctc_blink")
define nv =  Character(None, kind=nvl, what_color="#FFFFFF", ctc="ctc_blink")
define unvl = Character(None, kind=nvl, what_prefix="???: \"",  what_suffix='[quotesuf!t]', what_color="#FFFFFF", ctc="ctc_blink") # ??? in NVL
define cnvl = Character(None, kind=nvl, what_prefix="克劳: \"", what_suffix='[quotesuf!t]', what_color="#FFFFFF", ctc="ctc_blink") # Crow NVL

# Minor Characters
define gnvl = Character(None, kind=nvl, what_prefix="守卫: \"", what_suffix='[quotesuf!t]', what_color="#FFFFFF", ctc="ctc_blink")
define mrwnvl = Character(None, kind=nvl, what_prefix="弗洛伊德先生: \"", what_suffix='[quotesuf!t]', what_color="#FFFFFF", ctc="ctc_blink")
define anvl = Character(None, kind=nvl, what_prefix="艾许: \"", what_suffix='[quotesuf!t]', what_color="#FFFFFF", ctc="ctc_blink")
define rnvl = Character(None, kind=nvl, what_prefix="鲁本: \"", what_suffix='[quotesuf!t]', what_color="#FFFFFF", ctc="ctc_blink")
define dnvl = Character(None, kind=nvl, what_prefix="黛西: \"", what_suffix='[quotesuf!t]', what_color="#FFFFFF", ctc="ctc_blink")
define envl = Character(None, kind=nvl, what_prefix="以利亚: \"", what_suffix='[quotesuf!t]', what_color="#FFFFFF", ctc="ctc_blink")
define pnvl = Character(None, kind=nvl, what_prefix="皮尔森教授: \"", what_suffix='[quotesuf!t]', what_color="#FFFFFF", ctc="ctc_blink")
define ynvl = Character(None, kind=nvl, what_prefix="年轻的诺亚: \"", what_suffix='[quotesuf!t]', what_color="#FFFFFF", ctc="ctc_blink")
define noahsnvl = Character(None, kind=nvl, what_prefix="诺亚们: \"", what_suffix='[quotesuf!t]', what_color="#FFFFFF", ctc="ctc_blink")
define dnvl = Character(None, kind=nvl, what_prefix="黛西: \"", what_suffix='[quotesuf!t]', what_color="#FFFFFF", ctc="ctc_blink")
define jnvl = Character(None, kind=nvl, what_prefix="贾斯帕: \"", what_suffix='[quotesuf!t]', what_color="#FFFFFF", ctc="ctc_blink")

define flash = Fade(.25, 0.5, .75, color="#fff")

init python:
    renpy.music.register_channel("sound2", "sfx", False)
    renpy.music.register_channel("music2", "music", True)



label splashscreen:
    $ renpy.movie_cutscene("splashscreen.webm")
    return



label start:
    stop music fadeout 3.0

    # # TO REMOVE LATER
    # menu:
    #     "Crow's Route":
    #         jump crow_chapter1
    #
    #     "Ivan's Route":
    #         jump ivan_chapter1
    #
    #     "Kaine's Route":
    #         jump kaine_chapter1
    #     "Start from the beginning":
    #         pass
    #
    # #########

    jump prologue_start


label after_load:
    $ _side_image_attributes = None
