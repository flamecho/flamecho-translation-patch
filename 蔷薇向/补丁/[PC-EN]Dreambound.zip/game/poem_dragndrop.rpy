
init python:

    def poem_dragged(drags, drop):
        global snap1
        global snap2
        global snap3
        global snap4
        global snap5
        global snap6
        global counter_poem

        if not drop:
            return
        drags[0].snap(drop.x,drop.y)

        if drop.drag_name == "Poem_spot1":
            store.poem1 = drags[0].drag_name
            if snap1 == False:
                snap1 = True
                counter_poem = counter_poem + 1
                renpy.restart_interaction()
            return

        elif drop.drag_name == "Poem_spot2":
            store.poem2 = drags[0].drag_name
            if snap2 == False:
                snap2 = True
                counter_poem = counter_poem + 1
                renpy.restart_interaction()
            return

        elif drop.drag_name == "Poem_spot3":
            if snap3 == False:
                snap3 = True
                counter_poem = counter_poem + 1
                renpy.restart_interaction()
            store.poem3 = drags[0].drag_name
            return

        elif drop.drag_name == "Poem_spot4":
            store.poem4 = drags[0].drag_name
            if snap4 == False:
                snap4 = True
                counter_poem = counter_poem + 1
                renpy.restart_interaction()
            return

        elif drop.drag_name == "Poem_spot5":
            store.poem5 = drags[0].drag_name
            if snap5 == False:
                snap5 = True
                counter_poem = counter_poem + 1
                renpy.restart_interaction()
            return

        elif drop.drag_name == "Poem_spot6":
            if snap6 == False:
                snap6 = True
                counter_poem = counter_poem + 1
                renpy.restart_interaction()
            store.poem6 = drags[0].drag_name
            return




screen poem_drag:

    modal True

    add "gui/poem/background.png"

    showif counter_poem == 6:
        imagebutton auto "gui/Custom/History/history_%s.png" action Return() xalign 0.2 yalign 0.06

    draggroup:
        drag:
            drag_name "自从我们第一次见面"
            child "gui/poem/line.png"
            dragged poem_dragged
            droppable False
            xalign 0.2 yalign 0.7

        drag:
            drag_name "从一开始"
            child "gui/poem/line3.png"
            dragged poem_dragged
            droppable False
            xalign 0.2 yalign 0.75

        drag:
            drag_name "你把光带入了我的黑暗"
            child "gui/poem/line2.png"
            dragged poem_dragged
            droppable False
            xalign 0.8 yalign 0.7

        drag:
            drag_name "我的眼睛不由自主地跟随你"
            child "gui/poem/line4.png"
            dragged poem_dragged
            droppable False
            xalign 0.2 yalign 0.8

        drag:
            drag_name "我的心始终无法平静"
            child "gui/poem/line5.png"
            dragged poem_dragged
            droppable False
            xalign 0.8 yalign 0.75

        drag:
            drag_name "我想这永远不会改变"
            child "gui/poem/line6.png"
            dragged poem_dragged
            droppable False
            xalign 0.2 yalign 0.85

        drag:
            drag_name "在梦中，我看到了你"
            child "gui/poem/line7.png"
            dragged poem_dragged
            droppable False
            xalign 0.8 yalign 0.8

        drag:
            drag_name "在梦中，我感受到了你"
            child "gui/poem/line8.png"
            dragged poem_dragged
            droppable False
            xalign 0.2 yalign 0.9

        drag:
            drag_name "你的肌肤，在月光下显得苍白"
            child "gui/poem/line9.png"
            dragged poem_dragged
            droppable False
            xalign 0.8 yalign 0.85

        drag:
            drag_name "你的触碰，温柔而亲昵"
            child "gui/poem/line10.png"
            dragged poem_dragged
            droppable False
            xalign 0.8 yalign 0.9

        drag:
            drag_name "然后，我属于你"
            child "gui/poem/line11.png"
            dragged poem_dragged
            droppable False
            xalign 0.2 yalign 0.95

        drag:
            drag_name "然后，我陷入了你的怀抱"
            child "gui/poem/line12.png"
            dragged poem_dragged
            droppable False
            xalign 0.8 yalign 0.95





############# SPOTS YOU CAN DRAG ITEMS TO ####################

        drag:
            drag_name "Poem_spot1"
            child "gui/poem/drop_spot.png"
            draggable False
            xpos 650 ypos 103

        drag:
            drag_name "Poem_spot2"
            child "gui/poem/drop_spot.png"
            draggable False
            xpos 650 ypos 195

        drag:
            drag_name "Poem_spot3"
            child "gui/poem/drop_spot.png"
            draggable False
            xpos 650 ypos 286

        drag:
            drag_name "Poem_spot4"
            child "gui/poem/drop_spot.png"
            draggable False
            xpos 650 ypos 377

        drag:
            drag_name "Poem_spot5"
            child "gui/poem/drop_spot.png"
            draggable False
            xpos 650 ypos 469


        drag:
            drag_name "Poem_spot6"
            child "gui/poem/drop_spot.png"
            draggable False
            xpos 650 ypos 560

















            #
