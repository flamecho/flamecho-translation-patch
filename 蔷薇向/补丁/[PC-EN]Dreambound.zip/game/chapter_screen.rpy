transform character_overlay_ATL:
    ypos 200 alpha 0.0
    easein 2.0 ypos 0 alpha 1.0

transform title_overlay_ATL:
    xpos -100 alpha 0.0
    easein 1.0 xpos 0 alpha 1.0

transform title_text1:
    xalign 0.29 yalign 0.645
    xpos 500 alpha 0.0
    easein 2.0 xpos 400 alpha 1.0

style title_text_style:
    size 80
    color "#f1bd2f"

transform subtitle_text1:
    xalign 0.29 yalign 0.745
    xpos 570 alpha 0.0
    easein 2.0 xpos 470 alpha 1.0

style subtitle_text_style:
    size 40

transform slow_fade:
    alpha 0.0
    linear 2.0 alpha 1.0

# Chapter 1
transform title_text2:
    xalign 0.29 yalign 0.645
    xpos 550 alpha 0.0
    easein 2.0 xpos 450 alpha 1.0

transform subtitle_text2:
    xalign 0.29 yalign 0.745
    xpos 570 alpha 0.0
    easein 2.0 xpos 470 alpha 1.0


# Crow 1

transform subtitle_text3:
    xalign 0.29 yalign 0.745
    xpos 450 alpha 0.0
    easein 2.0 xpos 350 alpha 1.0

# Ivan 1
transform subtitle_text4:
    xalign 0.29 yalign 0.745
    xpos 480 alpha 0.0
    easein 2.0 xpos 380 alpha 1.0

    #Ivan 2

transform subtitle_text5:
    xalign 0.29 yalign 0.745
    xpos 550 alpha 0.0
    easein 2.0 xpos 450 alpha 1.0

screen prologue_chapter_screen():
    modal True
    timer 3.5 action [Hide("prologue_chapter_screen", dissolve), Return()]
    add "bg paint day" at slow_fade
    add "chapter_overlay" at slow_fade
    add "character_overlay" at character_overlay_ATL
    add "noah_chapter" at character_overlay_ATL
    add "title_overlay" at title_overlay_ATL

    text "序章" at title_text1 style "title_text_style"
    text "那个多年前死去的我" at subtitle_text1 style "subtitle_text_style"

screen chapter1_chapter_screen():
    modal True
    timer 3.5 action [Hide("chapter1_chapter_screen", dissolve), Return()]
    add "bg streets night" at slow_fade
    add "chapter_overlay" at slow_fade
    add "character_overlay" at character_overlay_ATL
    add "noah_chapter" at character_overlay_ATL
    add "title_overlay" at title_overlay_ATL

    text "第1章" at title_text2 style "title_text_style"
    text "披着金色薄纱的王国" at subtitle_text2 style "subtitle_text_style"

screen chapter2_chapter_screen():
    modal True
    timer 3.5 action [Hide("chapter2_chapter_screen", dissolve), Return()]
    add "bg noahbedroom night" at slow_fade
    add "chapter_overlay" at slow_fade
    add "character_overlay" at character_overlay_ATL
    add "ivan_chapter" at character_overlay_ATL
    add "title_overlay" at title_overlay_ATL

    text "第2章" at title_text2 style "title_text_style"
    text "早已忘却的过去之梦" at subtitle_text2 style "subtitle_text_style"

screen crow1_chapter_screen():
    modal True
    timer 3.5 action [Hide("crow1_chapter_screen", dissolve), Return()]
    add "bg empty dream" at slow_fade
    add "chapter_overlay" at slow_fade
    add "character_overlay" at character_overlay_ATL
    add "crow_chapter" at character_overlay_ATL
    add "title_overlay" at title_overlay_ATL

    text "第3章" at title_text2 style "title_text_style"
    text "黑暗的预兆" at subtitle_text3 style "subtitle_text_style"

screen crow2_chapter_screen():
    modal True
    timer 3.5 action [Hide("crow2_chapter_screen", dissolve), Return()]
    add "bg paint day" at slow_fade
    add "chapter_overlay" at slow_fade
    add "character_overlay" at character_overlay_ATL
    add "crow_chapter" at character_overlay_ATL
    add "title_overlay" at title_overlay_ATL

    text "第4章" at title_text2 style "title_text_style"
    text "乌鸦的密谋" at subtitle_text4 style "subtitle_text_style"


screen crow3_chapter_screen():
    modal True
    timer 3.5 action [Hide("crow3_chapter_screen", dissolve), Return()]
    add "bg mountains night" at slow_fade
    add "rain" at slow_fade
    add "chapter_overlay" at slow_fade
    add "character_overlay" at character_overlay_ATL
    add "crow_chapter" at character_overlay_ATL
    add "title_overlay" at title_overlay_ATL

    text "第5章" at title_text2 style "title_text_style"
    text "无尽的循环" at subtitle_text4 style "subtitle_text_style" # change positioning

screen ivan1_chapter_screen ():
    modal True
    timer 3.5 action [Hide("ivan1_chapter_screen", dissolve), Return()]
    add "bg ivan bedroom night" at slow_fade
    add "chapter_overlay" at slow_fade
    add "character_overlay" at character_overlay_ATL
    add "ivan_chapter" at character_overlay_ATL
    add "title_overlay" at title_overlay_ATL

    text "第3章" at title_text2 style "title_text_style"
    text "在黑暗中寻觅" at subtitle_text4 style "subtitle_text_style"

screen ivan2_chapter_screen ():
    modal True
    timer 3.5 action [Hide("ivan2_chapter_screen", dissolve), Return()]
    add "bg facility night" at slow_fade
    add "chapter_overlay" at slow_fade
    add "character_overlay" at character_overlay_ATL
    add "ivan_chapter" at character_overlay_ATL
    add "title_overlay" at title_overlay_ATL

    text "第4章" at title_text2 style "title_text_style"
    text "独自绽放的花" at subtitle_text5 style "subtitle_text_style"


screen ivan3_chapter_screen ():
    modal True
    timer 3.5 action [Hide("ivan3_chapter_screen", dissolve), Return()]
    add "bg river night" at slow_fade
    add "chapter_overlay" at slow_fade
    add "character_overlay" at character_overlay_ATL
    add "ivan_chapter" at character_overlay_ATL
    add "title_overlay" at title_overlay_ATL

    text "第5章" at title_text2 style "title_text_style"
    text "遗忘的过去，破碎的未来" at subtitle_text5 style "subtitle_text_style"


screen kaine1_chapter_screen ():
    modal True
    timer 3.5 action [Hide("kaine1_chapter_screen", dissolve), Return()]
    add "bg town night" at slow_fade
    add "chapter_overlay" at slow_fade
    add "character_overlay" at character_overlay_ATL
    add "kaine_chapter" at character_overlay_ATL
    add "title_overlay" at title_overlay_ATL

    text "第3章" at title_text2 style "title_text_style"
    text "坠落，坠落" at subtitle_text3 style "subtitle_text_style"

screen kaine2_chapter_screen ():
    modal True
    timer 3.5 action [Hide("kaine2_chapter_screen", dissolve), Return()]
    add "bg kaine dining night" at slow_fade
    add "chapter_overlay" at slow_fade
    add "character_overlay" at character_overlay_ATL
    add "kaine_chapter" at character_overlay_ATL
    add "title_overlay" at title_overlay_ATL

    text "第4章" at title_text2 style "title_text_style"
    text "欢迎回家" at subtitle_text4 style "subtitle_text_style"


screen kaine3_chapter_screen ():
    modal True
    timer 3.5 action [Hide("kaine2_chapter_screen", dissolve), Return()]
    add "bg river night" at slow_fade
    add "chapter_overlay" at slow_fade
    add "character_overlay" at character_overlay_ATL
    add "kaine_chapter" at character_overlay_ATL
    add "title_overlay" at title_overlay_ATL

    text "第5章" at title_text2 style "title_text_style"
    text "庄严的真理" at subtitle_text4 style "subtitle_text_style"
