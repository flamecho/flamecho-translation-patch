transform config_effect:
    #xpos 1035 ypos -66
    #easein 0.7 xpos 1035 ypos 37
    xpos 1323 ypos 204
    parallel:
        easein 0.3 rotate 5
        easein 0.3 rotate -5
        repeat
transform ypop:
    on show:
        yalign 0.5 yzoom 0.0
        easein 0.5 yzoom 1.0
    on hide:
        yzoom 1.0
        ease 0.5 yzoom 0.0
transform config_effect2:
    #xpos 1035 ypos -66
    #easein 0.7 xpos 1035 ypos 37
    xpos 1323 ypos 204
    parallel:
        easein 0.3 rotate 15
        easein 0.3 rotate -15
        repeat
    parallel:
        zoom 1.0
        easein 0.2 zoom 1.3
        easein 0.2 zoom 1.0
        repeat
label datingintro:
    hide screen cal
    $ daterp = 40
    $ turnsleft = 2
    $ datingplace = "sklh"
    $ datingname = "塞恩"
    $ skinshiparea = ""
    scene arrow_fort_crowd with fade
    $ config.rollback_enabled = False
    $ renpy.block_rollback()
    jump startdate

screen dating_info():

    frame xysize 1481, 743:
        align (.5,.2)
        padding (10,10,50,10)
        label _("描述") style "description_label" yanchor 24
        if selected_item is not None:
            $ thisitem = set_item(selected_item)
            text thisitem[3] offset (14,6) #info text
        elif selling:
            text _("选择要出售的物品。") offset (14,6) #color "#8b8b8b"
        else:
            text _("选择一个物品以阅读其描述。") offset (14,6) #color "#8b8b8b"
screen datingsystemmain():
    if not hidedatingsystemcommand:
        use datingsystemcommand
    if lovely:
        add "doki" at config_effect2
        timer 1.0 action [SetVariable("lovely", False)]
        #on "show" action [Play("sound", "audio/success.mp3")]
    else:
        if hate:
            add "crap" at config_effect2
            timer 1.0 action [SetVariable("hate", False)]
        elif daterp >= 70 and not hate:
            add "datingsystem/happy.png" at config_effect
        elif daterp >= 50 and not hate:
            add "datingsystem/smile.png" at config_effect
        elif daterp >= 30 and not hate:
            add "datingsystem/normal.png" at config_effect
        else:
            add "datingsystem/ugh.png" at config_effect


    if turnsleft == 3:
        add "datingsystem/2.png" xalign 0.0 yalign 0.0
    if turnsleft == 2:
        add "datingsystem/1.png" xalign 0.0 yalign 0.0
    elif turnsleft == 1:
        add "datingsystem/0.png" xalign 0.0 yalign 0.0
    elif turnsleft == 0:
        add "datingsystem/0.png" xalign 0.0 yalign 0.0

screen datingsystemcommand():


    imagebutton:
        idle "datingsystem/gift_idle.png"
        hover "gifthover"
        #insensitive "datingsystem/no_gift.png"
        xpos 350
        ypos 169
        hovered [ Play ("test_one", "type.wav")]
        action [Jump('giftcommand')]
    imagebutton:
        idle "datingsystem/touch_idle.png"
        hover "touchhover"
        xpos 490
        ypos 169
        hovered [ Play ("test_one", "type.wav")]
        action Jump('skinship')
        #mouse skin
    imagebutton:
        idle "datingsystem/talk_idle.png"
        hover "talkhover"
        xpos 427
        ypos 250
        hovered [ Play ("test_one", "type.wav")]
        action Jump('talkcommand')
#################TALK COMMAND##################################
label talkcommand:
    $ hidedatingsystemcommand = True
    if "day_0" not in my_events:
        $ turnsleft -= 1
        if datingname == "塞恩":
            call talkThane from _call_talkThane
        elif datingname == "奎尔":
            call talkQuill from _call_talkQuill
        elif datingname == "阿什姆":
            call talkTom from _call_talkTom
        else:
            call talkLyall from _call_talkLyall
        jump startdate
    else:
        menu:
            "君主制" if "monarchy" in topics:
                $ gift = "monarchy"
                $ turnsleft -= 1
                if datingname == "塞恩":
                    call talkThane from _call_talkThane_1
                elif datingname == "奎尔":
                    call talkQuill from _call_talkQuill_1
                elif datingname == "阿什姆":
                    call talkTom from _call_talkTom_1
                else:
                    call talkLyall from _call_talkLyall_1
                jump startdate
            "灵魂伴侣" if "soulmates" in topics:
                $ gift = "soulmates"
                $ turnsleft -= 1
                if datingname == "塞恩":
                    call talkThane from _call_talkThane_2
                elif datingname == "奎尔":
                    call talkQuill from _call_talkQuill_2
                elif datingname == "阿什姆":
                    call talkTom from _call_talkTom_2
                else:
                    call talkLyall from _call_talkLyall_2
                jump startdate
            "英克威尔家族的戏剧性事件" if "inkwell" in topics and datingname == "奎尔":
                $ turnsleft -= 1
                $ gift = "inkwell"
                call talkQuill from _call_talkQuill_3
                jump startdate
            "英克威尔家族的基因" if "genetics" in topics and not datingname == "莱尔":
                $ turnsleft -= 1
                $ gift = "genetics"
                if datingname == "塞恩":
                    call talkThane from _call_talkThane_3
                elif datingname == "奎尔":
                    call talkQuill from _call_talkQuill_4
                elif datingname == "阿什姆":
                    call talkTom from _call_talkTom_3
                else:
                    call talkLyall from _call_talkLyall_3
                jump startdate
            "低语球" if "shriek" in topics and datingname == "阿什姆":
                $ turnsleft -= 1
                $ gift = "shriek"
                call talkTom from _call_talkTom_4
                jump startdate
            "血月" if "bloodmoon" in topics:
                $ turnsleft -= 1
                $ gift = "bloodmoon"
                if datingname == "塞恩":
                    call talkThane from _call_talkThane_4
                elif datingname == "奎尔":
                    call talkQuill from _call_talkQuill_5
                elif datingname == "阿什姆":
                    call talkTom from _call_talkTom_5
                else:
                    call talkLyall from _call_talkLyall_4
                jump startdate
            "你妈" if "whore" in topics:
                $ turnsleft -= 1
                if datingname == "阿什姆":
                    if "date5_done" in tom_events:
                        $ gift = "mom"
                    elif "date3_done" not in tom_events:
                        $ gift = "mom"
                    else:
                        $ gift = "tabu"
                else:
                    $ gift = "mom"
                if datingname == "塞恩":
                    call talkThane from _call_talkThane_5
                elif datingname == "奎尔":
                    call talkQuill from _call_talkQuill_6
                elif datingname == "阿什姆":
                    call talkTom from _call_talkTom_6
                else:
                    call talkLyall from _call_talkLyall_5
                jump startdate
            "水蛭" if "leech" in topics:
                $ turnsleft -= 1
                $ gift = "leech"
                if datingname == "塞恩":
                    call talkThane from _call_talkThane_6
                elif datingname == "奎尔":
                    call talkQuill from _call_talkQuill_7
                elif datingname == "阿什姆":
                    call talkTom from _call_talkTom_7
                else:
                    call talkLyall from _call_talkLyall_6
                jump startdate
            "噬梦者" if "ctulhu" in topics:
                $ turnsleft -= 1
                $ gift = "ctulhu"
                if datingname == "塞恩":
                    call talkThane from _call_talkThane_7
                elif datingname == "奎尔":
                    call talkQuill from _call_talkQuill_8
                elif datingname == "阿什姆":
                    call talkTom from _call_talkTom_8
                else:
                    call talkLyall from _call_talkLyall_7
                jump startdate
            "水母" if "jelly" in topics:
                $ turnsleft -= 1
                $ gift = "jelly"
                if datingname == "塞恩":
                    call talkThane from _call_talkThane_8
                elif datingname == "奎尔":
                    call talkQuill from _call_talkQuill_9
                elif datingname == "阿什姆":
                    call talkTom from _call_talkTom_9
                else:
                    call talkLyall from _call_talkLyall_8
                jump startdate
            "黑暗诅咒" if "curses" in topics:
                $ turnsleft -= 1
                $ gift = "curses"
                if datingname == "塞恩":
                    call talkThane from _call_talkThane_9
                elif datingname == "奎尔":
                    call talkQuill from _call_talkQuill_10
                elif datingname == "阿什姆":
                    call talkTom from _call_talkTom_10
                else:
                    call talkLyall from _call_talkLyall_9
                jump startdate
            "怪异梦境" if "dreams" in topics:
                $ turnsleft -= 1
                $ gift = "dreams"
                if datingname == "塞恩":
                    call talkThane from _call_talkThane_10
                elif datingname == "奎尔":
                    call talkQuill from _call_talkQuill_11
                elif datingname == "阿什姆":
                    call talkTom from _call_talkTom_11
                else:
                    call talkLyall from _call_talkLyall_10
                jump startdate
            "你的好奇心" if "curios" in topics and not datingname == "莱尔":
                $ turnsleft -= 1
                $ gift = "curios"
                if datingname == "塞恩":
                    call talkThane from _call_talkThane_11
                elif datingname == "奎尔":
                    call talkQuill from _call_talkQuill_12
                elif datingname == "阿什姆":
                    call talkTom from _call_talkTom_12
                else:
                    call talkLyall from _call_talkLyall_11
                jump startdate
            "重写" if "rewrite" in topics and not datingname == "莱尔":
                $ turnsleft -= 1
                $ gift = "rewrite"
                if datingname == "塞恩":
                    call talkThane from _call_talkThane_12
                elif datingname == "奎尔":
                    call talkQuill from _call_talkQuill_13
                elif datingname == "阿什姆":
                    call talkTom from _call_talkTom_13
                else:
                    call talkLyall from _call_talkLyall_12
                jump startdate
            "海妖" if "sirens" in topics:
                $ turnsleft -= 1
                $ gift = "sirens"
                if datingname == "塞恩":
                    call talkThane from _call_talkThane_13
                elif datingname == "奎尔":
                    call talkQuill from _call_talkQuill_14
                elif datingname == "阿什姆":
                    call talkTom from _call_talkTom_14
                else:
                    call talkLyall from _call_talkLyall_13
                jump startdate
            "神之墓" if "tomb" in topics and datingname == "莱尔":
                $ turnsleft -= 1
                $ gift = "tomb"
                call talkLyall from _call_talkLyall_14
                jump startdate
            "算了。":
                jump startdate


label talkThane:
    
    if "day_0" not in my_events:
        $ num = renpy.random.randint(1, 3)
        if num == 1:
            $ daterp += 5
            play sound "audio/success.mp3"
            $ lovely = True
            show red amused at charcenter
            red "我的暑假过得怎么样？哦，和往常一样。独自在宿舍里度过了几周。不过没关系。"
            red datar "总之，别让我悬而未决，来击个掌吧！"
        elif num == 2:
            show red grin at charcenter
            $ daterp += 5
            play sound "audio/success.mp3"
            $ lovely = True
            red "你见过阿什姆了吗？他在假期里又长高了。"
            red sayang "说实话，我还是觉得你们两个分手很可惜。但我猜这也没办法，对吧？"
            red datar "总之，别让我悬而未决，来击个掌吧！"
        else:
            show red amused at charcenter
            $ daterp += 10
            play sound "audio/success.mp3"
            $ lovely = True
            red "在奎尔家度过暑假一定很有趣。毕竟英克威尔庄园是值得一看的。"
            red datar "总之，别让我悬而未决，来击个掌吧！"
    else:
        if gift == "monarchy":
            play sound "audio/crack.mp3"
            $ hate = True
            $ daterp -= 10
            red kzl frusta "吸血鬼王国？怎么突然对这个感兴趣了？"
            if calendar.weekday == "Sat" or calendar.weekday == "Sun":
                show side_p ha at pic
            else:
                show side_p se at pic
            mc "哦，你知道的，只是好奇而已。"
            hide side_p
            red -frusta "嗯，除了他们大多是独裁的皇室外，没什么特别的可说的。"
            red kzl sigh "他们都会为了在生活中出人头地而互相残杀。"
            red ew -sigh "我们会去入侵其他国家以扩张领土，并通过达拉仪式创造更多后代。"
            red kzl frusta "然后大多数人会抱怨我们没有足够的人类来满足我们的进食需求。"
            red lelah sigh "这很愚蠢。"
            red wry -sigh "我很高兴卡斯特里和伊格尼亚设法与他们签订了和平条约。如果没有这个条约，我想人类现在可能已经灭绝了。"
        elif gift == "soulmates":
            $ daterp -= 15
            play sound "audio/crack.mp3"
            $ hate = True
            red sad sigh "啊，你是在取笑我没有灵魂伴侣吗？"
            if calendar.weekday == "Sat" or calendar.weekday == "Sun":
                show side_p fr at pic
            else:
                show side_p f at pic
            mc "嗯？"
            hide side_p
            red -sigh"我是说，我知道大多数吸血鬼都有灵魂伴侣印记，我也不确定为什么我没有。"
            red ngeles "妈妈过去常说这是一种祝福，因为我不用担心那种吸引力。"
            red awkward "你知道，就是那种\'这血闻起来如此诱人，我简直愿意杀人只为尝一口\'的感觉。"
            red wry apa "但是，这还是让我怀疑自己是不是有什么问题。或者我的命中注定之人是不是还太年轻，甚至还没出生。"
            red lelah -apa "我知道亚历克谢王子对他的灵魂印记非常偏执。"
            if "vamp_visit" not in red_events:
                red ow sigh "我不知道它是否已经显现，但如果他的灵魂伴侣是凡人，而且他们建立了联结，那么亚历克谢就不能从其他人那里吸血了。"
                red mock -sigh "然后当他的伴侣死亡时，他也会死去，因为吸血鬼最长只能在没有血液的情况下存活约3个月。"
                red sad "没有不朽的独裁者想要这样，所以我听说他计划去猎杀他的灵魂伴侣以防止建立联结的可能。"
            else:
                red lelah "难怪他们在追捕他的命中注定之人。可怜的家伙，我希望血骑士找不到他们。"
            if calendar.weekday == "Sat" or calendar.weekday == "Sun":
                show side_p fr at pic
            else:
                show side_p f at pic
            mc "为什么不直接无视他们的灵魂伴侣呢？"
            hide side_p
            red perih sweat frusta "说起来容易做起来难。"
            red ew -sweat "就像我说的，灵魂伴侣的吸引力是无法抗拒的。血液对你歌唱，因为那是你将品尝到的最神圣的血液。"
            red  wry -frusta "我妈妈说她几乎无法抗拒她的灵魂伴侣。"
            red ngeles sigh "信不信由你，她的灵魂伴侣是一个人鱼。虽然我妈妈不惧怕死亡，但她觉得这对那个人鱼男不公平。"
            red sad -sigh "让他冒险进入她陌生而危险的世界。"
            red sayang "所以她放走了人鱼，选择了我的父亲。并不是说他们不相爱。我想他们是幸福的。至少我希望如此。"
            show red datar
        
        elif gift == "genetics":
            $ daterp += 5
            play sound "audio/success.mp3"
            $ lovely = True
            red kaget apa "英克威尔家族的基因？哦是的，你这么一说，他们确实都有些相似。"
            red awkward -apa "苍白的皮肤和绿色的眼睛。更有名的英克威尔家族成员还都有白发。"
            red grit sweat "嗯。这其实有点令人毛骨悚然，几乎就像是被计划或制造出来的一样。"
            red frown -sweat apa "但这还不是最奇怪的。你知道吗，除了奎尔和佩纳，大多数英克威尔家族成员都喜欢嗑药？"
            if calendar.weekday == "Sat" or calendar.weekday == "Sun":
                show side_p fr at pic
            else:
                show side_p f at pic
            mc "药物？"
            hide side_p
            red huh -apa "我是说，我觉得那是药物。我在各种任务中见过奎尔的一些堂兄弟。大多数人一感到不适或疲劳就会准备好注射器。"
            red ew "我很确定那是某种增强药物之类的。"
            red bingung "不过我不确定奎尔是否知道这件事，不知为何他从未和他的堂兄弟一起执行任务。"
            red wry "也许英克威尔家族不希望家族成员一起执行任务，因为他们会过于分心而无法完成任务？"

        elif gift == "bloodmoon":
            $ daterp += 20
            play sound "audio/success.mp3"
            $ lovely = True
            red grin blush bunga "啊。我和奎尔还有阿什姆一起观看血月的时候玩得很开心！"
            red -blush -bunga "阿什姆给了我们很多血液药剂，还为我们准备了很多小吃！"
            red wry sigh "不过，奎尔一直在滔滔不绝地讲述星象学的趣闻。"
            show red datar -sigh
        elif gift == "mom":
            play sound "audio/crack.mp3"
            $ hate = True
            $ daterp -= 55
            red ew sweat frusta "啊，那是个敏感话题。我宁愿不谈这个。"
            show red frown -sweat -frusta
        elif gift == "leech":
            $ daterp -= 15
            play sound "audio/crack.mp3"
            $ hate = True
            red kzl frusta "唉，我讨厌那些造出那个侮辱性词语的白痴。"
            red frown -frusta "我想它最初出现在奇奇亚，是狼人们造出来的。"
            red wry "我是说，我们确实叫他们杂种狗，所以我猜这也算公平。"
        elif gift == "ctulhu":
            $ daterp -= 35
            play sound "audio/crack.mp3"
            $ hate = True
            red ew frusta "哦，在沃特克有一对非常有名的噬梦者组合。"
            red -frusta "奥利凡德和奥利维亚。他们拥有奥利凡德的噩梦商场。"
            red sad sigh "专门经营噩梦药剂或无梦饮料。"
            red kzl frusta "我讨厌他们。他们和阿列克谢很亲近。每当他们来参观宫殿，血袋就会开始自杀。"
            red lelah "这都是因为他们的邪神之血，它会导致人类产生幻觉并失去理智。"
            red frown sigh "我还听说它对巫师和狼人也有同样的效果，但他们聪明到足以远离。"
            red bingung -sigh "吸血鬼似乎对他们的精神操控免疫，而仙子似乎会因此而兴奋。"
            red frown "真奇怪。"
        elif gift == "jelly":
            $ daterp += 15
            play sound "audio/success.mp3"
            $ lovely = True
            red amused "我曾试图抓住一只水母，可惜它们在24小时后就消失了。"
        elif gift == "curses":
            $ daterp -= 5
            play sound "audio/crack.mp3"
            $ hate = True
            red bingung apa "三大黑暗诅咒？是迪特里希教过我们吗？我忘了。"
            show red wry -apa
        elif gift == "dreams":
            $ daterp += 5
            play sound "audio/success.mp3"
            $ lovely = True
            red amused "哦伙计，我曾经做过一个奇怪的梦。我是一名警官，穿着内衣作为伪装。"
            red cowo blush cling "你知道，就是那种卧底的事，而且一切看起来都很先进和奢华。"
            if calendar.weekday == "Sat" or calendar.weekday == "Sun":
                show side_p ha at pic
            else:
                show side_p se at pic
            mc "也许是另一个平行宇宙？"
            hide side_p
            red grin -blush -cling "哈哈，也许吧，但我宁愿有一个不是彻底娘炮的我，你懂吗？"
        elif gift == "curios":
            $ daterp += 5
            play sound "audio/success.mp3"
            $ lovely = True
            red bingung apa "嗯，你的好奇心是吧？"
            if "mey_kill" not in my_events:
                red frown -apa "我是说，是啊，你这么一说，你确实是那种为了满足好奇心而惹上各种麻烦的类型，对吧？"
                red cowo "就像那次你去地牢，差点害我们都被杀，因为波比小姐当时正处于狼人形态。"
                red awkward "或者那次你偷偷溜进教师休息室，就因为你想看看那个地方。"
                red sayang "我想奎尔对此有最多的话要说。"
            else:
                red sayang -apa "我猜你是指另一个你？"
                red cowo "是的，[povname]就是\'好奇心害死猫\'这句话的真实写照。"
                if not girl2:
                    red sayang "那个混蛋会为了满足[dia2]自己的好奇心而让我们陷入各种麻烦。"
                else:
                    red sayang "那个混蛋会为了满足[dia]自己的好奇心而让我们陷入各种麻烦。"
            show red datar

        elif gift == "rewrite":
            $ daterp -= 45
            play sound "audio/crack.mp3"
            $ hate = True
            red sad"重写符文...等等，是不是你曾经在我身上画过的那个RR形状的符文？"
            if "mey_kill" not in my_events:
                red kaget shock "等等，那你重写了什么？！"
                if calendar.weekday == "Sat" or calendar.weekday == "Sun":
                    show side_p fr at pic
                else:
                    show side_p f at pic
                mc "这正是我想要弄清楚的！"
                show red huh -shock
                mc "那么，你亲身经历过吗？"
                hide side_p
                red kaget "是-是的，你说那是为了帮助我睡眠。"
            
            else:
                if calendar.weekday == "Sat" or calendar.weekday == "Sun":
                    show side_p fr at pic
                else:
                    show side_p f at pic
                mc "你是指[povname]？"
                hide side_p
                red kaget "对！"
            red ow frusta "该死，难怪我之后感觉那么恍惚！"
            show red sad -frusta
        elif gift == "sirens":
            $ daterp -= 15
            play sound "audio/crack.mp3"
            $ hate = True
            red kzl "哦，我曾去过一次海妖动物园。那真是太悲伤了。"
            red lelah sweat sigh "很奇怪，因为他们都是人形。就像再次看到血袋一样。"
            red sad -sweat -sigh "至少当他们变成鸟儿时，看起来不那么突兀。"
            red frown "有时你能看到一只雄性的，但那是极其罕见的。"
            red wry "我想奎尔的叔叔养了一只宠物海妖。不过我不确定是男是女。"
        else:
            $ daterp += 5
            play sound "audio/success.mp3"
            $ lovely = True
            show red datar at charcenter
            red ow frusta "我希望秋天能凉快点，这热浪快把我折腾死了。"
            red datar -frusta "也许我可以找些精灵血来当防晒霜用。"
    window hide
    return

label talkQuill:
    if num == 1:
        $ daterp += 15
        play sound "audio/success.mp3"
        $ lovely = True
        quil talk apa "我是怎么保持头发如此光泽亮丽的？"
        quil wink cling "哦，这是家族秘密，亲爱的，恐怕你得娶我才能知道。"
        show quil smile -cling
        play sound "audio/success.mp3"
        if calendar.weekday == "Sat" or calendar.weekday == "Sun":
            show side_p fr at pic
        else:
            show side_p f at pic
        mc "算了吧。"
        hide side_p
    elif num == 2:
        $ daterp += 20
        play sound "audio/success.mp3"
        $ lovely = True
        quil tantrum sigh "这学期我似乎不太受欢迎。"
        quil datar -sigh "也许我需要改变形象了。"
    elif gift == "monarchy":
        $ daterp += 15
        play sound "audio/success.mp3"
        $ lovely = True
        quil sulk "嗯。老实说，我从未真正考虑过吸血鬼。我们生活在不同的大陆，而且我们有和平条约。"
        quil datar "只要他们不多管闲事，我不觉得我们不能和平相处。"
        quil fluster frusta "虽然他们确实有些奇怪的传统，比如杀死自己的灵魂伴侣。"
        show quil datar -frusta
    elif gift == "soulmates":
        $ daterp += 35
        play sound "audio/success.mp3"
        $ lovely = True
        quil sad apa "说实话，我觉得人类没有天生的灵魂伴侣这点简直令人作呕，你不这么认为吗？"
        quil laugh spark "我一直幻想着某个骑着白马的男人或女人把我从家里带走，称我为他们的伴侣。"
        quil wink cling "在夕阳下逃跑，而我父亲诅咒我们俩并派出搜索队。"
        quil malu -cling "但也许我看的言情小说太多了。"
    elif gift == "inkwell":
        $ daterp += 30
        play sound "audio/success.mp3"
        $ lovely = True
        quil err sweat frusta "哦，我真受不了我家的家庭关系。"
        quil wry -sweat -frusta "你知道吗，我其实有8个叔叔阿姨，但我只见过其中一两个？"
        quil rajuk "这都是因为我父亲。他是长子，所以他认为我应该成为继承人。"
        quil mock sweat sigh "大多数人都同意，但后来我变成了...嗯，现在这样。"
        quil laugh -sweat -sigh "别误会。外表上，我是完美的，一个标准的英克威尔家族成员。"
        quil ow sweat frusta "可惜我的性格让人不敢恭维。"
        quil hister -sweat -frusta "我讨厌实地工作，宁愿在旁边看着别人为我做脏活。"
        quil talk blush spark "然而佩纳恰恰相反。他缺乏所有英克威尔家族的标志性基因，但他是个完美的猎巫人！"
        quil avoid -blush -spark "我家族里有一半人站在他那边，知道在他的领导下生意会蒸蒸日上。"
        quil sad sigh "不过，我还是想知道为什么我父亲如此执着于让我当继承人。"
        show quil datar -sigh

    elif gift == "genetics" and "date4_done" not in quil_events:
        $ daterp += 20
        play sound "audio/success.mp3"
        $ lovely = True
        quil wink cling "是因为我迷人的外表吗？"
        quil hister -cling "我很想说是我父母赐予我这样的容貌，但奇怪的是，我父母都没有我这标志性的白发。"
        quil talk "不过我祖父有。而且，我的堂兄弟们在注射了他们的\'维生素\'后也开始长出白发。"
        quil tantrum sigh "我正试图深入调查这件事。看起来有点奇怪。"
        quil groan frusta "我曾向佩纳寻求帮助，但他似乎很想把我蒙在鼓里。"
        quil wry sigh "你知道吗，我堂兄佩纳是我唯一经常交谈的堂兄弟？他也是我开始使用眼影的原因。"
        quil malu blush bunga "我觉得那看起来很酷。"
        quil hister both -bunga "我发现在奇奇亚，这些颜色意味着我不介意在上面或下面。"
        quil wry "因为一些狼人用这种颜色来表示他们在发情或交配期寻找伴侣。"
        quil hister "这就是为什么波比小姐对我的外表如此感兴趣。"
        quil talk -both apa "你们有这样的习俗吗？"
        if calendar.weekday == "Sat" or calendar.weekday == "Sun":
            show side_p fr at pic
        else:
            show side_p f at pic
        mc "算是吧？我是说它们有不同的用途，但有骄傲旗。你可以通过这些大致判断一个人的性取向。"
        hide side_p
        quil laugh blush bunga "哦，像真正的国旗一样？多么有节日气氛啊！"
        show quil datar -blush -bunga
    elif gift == "bloodmoon":
        $ daterp += 40
        play sound "audio/success.mp3"
        $ lovely = True
        quil laugh blush bloom "哦亲爱的，我真希望你当时在场！"
        quil talk "我和男孩们度过了一段美好的时光，看着夜空被染成红色。"
        quil hister "亲爱的阿什姆甚至为我们准备了小吃，他真是个伪装的天使。"
        quil talk "我确保刻了一些好运符文，为我们即将到来的几个月祈福。"
        quil wry sigh "虽然我想塞恩说得对，这可能只是无稽之谈，因为它们现在并没有真正起作用，不是吗？"
        show quil datar -blush -sigh
    elif gift == "mom":
        $ daterp -= 10
        play sound "audio/crack.mp3"
        $ hate = True
        quil ow sweat frusta "我母亲？嗯，抱歉亲爱的，但母亲问题更像是你的事，而不是我的。"
        quil sulk sigh "如果我完全诚实的话，我恐怕甚至不怎么见到我的母亲，除了偶尔的季节性拜访。"    
        show quil sad -sweat -sigh
    elif gift == "leech":
        $ daterp -= 10
        play sound "audio/crack.mp3"
        $ hate = True
        quil ejek cling "天啊，我从没想到你是个种族主义者。"
        show quil kzl frusta
        if calendar.weekday == "Sat" or calendar.weekday == "Sun":
            show side_p fr at pic
        else:
            show side_p f at pic
        mc "我不是，而且说实话，你根本没在\'钉\'我，一点都没有。"
        hide side_p
        quil heh apa "你确定吗？是说\'钉\'的那部分，不是种族主义那部分。"
        show quil hister -apa
        if calendar.weekday == "Sat" or calendar.weekday == "Sun":
            show side_p fr at pic
        else:
            show side_p f at pic
        mc "确实如此。"
        hide side_p
    elif gift == "ctulhu":
        $ daterp -= 15
        play sound "audio/crack.mp3"
        $ hate = True
        quil rajuk sigh "我听说新的恐怖异形已经出现了。"
        quil err frusta "说实话，噬梦者真是可怕的生物。"
        if calendar.weekday == "Sat" or calendar.weekday == "Sun":
            show side_p fr at pic
        else:
            show side_p f at pic
        mc "怎么说？"
        hide side_p
        quil sulk -frusta "它们预示着末日的来临。每一个噬梦者的出现都恰好在一场灾难性事件发生之前。"
        quil sad "奥利维亚和奥利万德就是在死亡地带战争爆发前从克罗汉姆海岸出现的。"
        quil grit frusta "它们基本上就是死亡和混乱的化身。"
        quil sulk "既然一个名叫范的新噬梦者已经出现，这意味着地平线上将会有一场新的血腥事件。"
        quil sad -frusta "问题是，会在哪里发生？"
    elif gift == "jelly":
        $ daterp += 15
        play sound "audio/success.mp3"
        $ lovely = True
        quil laugh blush bunga "我小时候喜欢捕捉水母。菲亚和我经常把它当成比赛。"
        quil talk -blush sigh "多亏了她的那个[kk]，她总是赢。"
        quil malu -sigh "[povname]总是会以某种方式作弊。那孩子为了[dia]姐姐什么都愿意做。"
        quil datar "不管公平与否。"
    elif gift == "curses":
        $ daterp -= 15
        play sound "audio/crack.mp3"
        $ hate = True
        quil fluster sweat "哦，是的，三大黑暗诅咒。我一直渴望亲眼看到它们对巫师的影响。"
        quil tantrum -sweat "我曾经在一个人类身上见过，他立即流血致死。"
        quil kzl "说实话，那场面相当可怕。"
    elif gift == "dreams":
        $ daterp += 20
        play sound "audio/success.mp3"
        $ lovely = True
        quil talk shock "既然你提到了，我确实做过一两个关于自己的奇怪梦，但梦里我留着长发。"
        quil smile bunga "我比现在更迷人，身材匀称高挑，长发飘逸。你会误以为我是个仙子。"
        quil amused sigh "可惜我不认为那是来自你们的世界。我手里拿着的工具感觉要先进得多。"
        quil talk -sigh "有发光的东西从这个棒状工具里冒出来。"
        if calendar.weekday == "Sat" or calendar.weekday == "Sun":
            show side_p fr at pic
        else:
            show side_p f at pic
        mc "激光？"
        hide side_p
        quil wry apa "什么是激光？不过也许是吧。"
        show quil datar -apa
    elif gift == "curios":
        $ daterp += 10
        play sound "audio/success.mp3"
        $ lovely = True
        quil ejek cling "哦，别让我说起[povname]那猫一样的好奇心。"
        quil amused sigh "我以前觉得这很有趣。一个人怎么能对[dia]周围的事物得出这么多奇怪的结论。"
        quil hister -sigh "不过我想这也正是我们最初陷入这种混乱的原因。"
        show quil datar -sigh
    
    elif gift == "rewrite":
        $ daterp -= 35
        play sound "audio/crack.mp3"
        $ hate = True
        quil groan frusta "啊，所以菲亚告诉你了，是吗？嗯。"
        if calendar.weekday == "Sat" or calendar.weekday == "Sun":
            show side_p fr at pic
        else:
            show side_p f at pic
        mc "你似乎不太高兴我知道这件事。"
        hide side_p
        quil sad sigh "我确实不高兴。[povname]用非常不稳定的方法制作了这个符文。"
        quil ow -sigh "混合了符文墨水、海妖血和仙子血。"
        quil kzl "它能让人完全改写某人的过去。"
        quil sulk "老实说，我经常担心我亲爱的朋友会用它来对付我。"
        quil sad "以一种我永远无法反驳的方式欺骗我。"
    elif gift == "sirens":
        $ daterp += 15
        play sound "audio/success.mp3"
        $ lovely = True
        quil laugh bunga "菲亚喜欢海妖。我理解这种情感。"
        quil talk blush -bunga "它们比任何其他神话生物都更迷人。"
        quil amused -blush "即使当雄性变成女妖时，它们也有一种特殊的威严。"
        quil datar "我叔叔养了一只宠物海妖。她脖子和脚踝上戴着项圈，防止她逃跑。"
        quil tantrum "当她以人形出现时，这景象有点情色，但作为鸟时，就不那么粗俗了。"
        quil smile apa "你知道吗，有些海妖看起来像天使，因为它们的翅膀长在背上而不是手臂上？"
        quil talk -apa "如此神圣的生物，可惜它们因羽毛而被猎杀。"
        show quil datar
    else:
        $ daterp += 25
        play sound "audio/success.mp3"
        $ lovely = True
        quil laugh blush bunga "我堂弟佩纳是我唯一经常联系的表亲。他是我开始使用眼影的原因。"
        quil talk -bunga "我觉得那看起来很酷。"
        quil hister both "我发现在奇奇亚，这些颜色意味着我不介意在上面或下面。"
        quil talk -both "因为一些狼人用这种颜色来表示他们在发情或交配期寻找伴侣。"
        quil datar "这就是为什么波比小姐对我的眼睛如此感兴趣。"

    
    window hide
    return

label talkTom:
    if num == 1:
        $ daterp += 5
        play sound "audio/success.mp3"
        $ lovely = True
        tom amused cling "现在天气越来越冷了。我迫不及待地想要冬天到来。"
        tom calm apa "你知道吗，在塞维德，冬天是由一位冰雪仙子创造的？"
        tom pfft -apa "我在访问时见过她一两次，是位可爱的女士，尽管有点冒失。"
    elif num == 2:
        $ daterp += 5
        play sound "audio/success.mp3"
        $ lovely = True
        tom ejek cling "射箭队这个赛季表现不错，这次我们可能真的有机会参加比赛了。"
        show tom smile -cling
    elif gift == "monarchy":
        $ daterp += -5
        play sound "audio/crack.mp3"
        $ hate = True
        tom capek blow "坦白说，我觉得吸血鬼国王令人厌恶。掠夺地区，绑架儿童当血袋..."
        tom kzl -blow "我相信一旦我们消灭了巫师，战争的矛头就会转向他们。"
        tom capek frusta "这可能也是他们执意要建立如此庞大军队的原因。"
        show tom frown -frusta 
    elif gift == "soulmates":
        $ daterp += 25
        play sound "audio/success.mp3"
        $ lovely = True
        tom giggle both "我曾经尝试酿造一种药水，想看看谁是我的灵魂伴侣。"
        tom pfft -both "当我喝下它时，我确实看到了周围的线，但是...它们全都连接到了你、红和奎尔身上。"
        tom nyesal blow "我可能是个精灵，但我不认为我能够处理多角恋关系。"
        show tom frown -blow

    elif gift == "genetics":
        $ daterp -= 20
        play sound "audio/crack.mp3"
        $ hate = True
        tom ew frusta "你为什么问这个？你对他有兴趣吗？"
        tom capek "我得告诉你，奎尔不适合你。他体质虚弱，而且太过轻浮。"
        tom ha blow "你最好找别人。"
        show tom kzl -blow
    elif gift == "shriek":
        $ daterp -= 5
        play sound "audio/crack.mp3"
        $ hate = True
        tom frown apa "校长办公室里的低语球？是的，我知道它。"
        tom kzl frusta "你知道他能拥有这样一个球的唯一方法是猎杀女妖吗？"
        tom ha -frusta "当雄性海妖成年时，他们有机会变成女妖，这种鸟类能预测死亡但无法干预。"
        tom nyesal "他们感到沮丧，发出尖锐的尖叫来表达痛苦。"
        tom frown "一些符文可以捕捉这些尖叫和预言，将那些女妖的灵魂封入球中。"
    elif gift == "bloodmoon":
        $ daterp -= 30
        play sound "audio/crack.mp3"
        $ hate = True
        if "mey_kill" in my_events:
            tom nyesal frusta "我和男孩们一起观看了血月。如果我知道[povname]正在与某人建立联系，那么我就会——"    
        else:
            tom nyesal frusta "我和男孩们一起观看了血月。如果我知道你正在与某人建立联系，那么我就会——"
        tom ha blow "唉..."
        show tom frown -blow
    elif gift == "mom":
        $ daterp += 15
        play sound "audio/success.mp3"
        $ lovely = True
        tom calm bunga "母亲很好，她的孕期很顺利。"
        tom giggle -bunga "父亲宠爱她，买下她想要的一切，甚至是一些奇怪的东西，比如活鲭鱼或生蜂巢。"
        tom wry "我喜欢蜂蜜，但是蜂巢在牙齿上的感觉...我不太喜欢。"
    elif gift == "leech":
        $ daterp -= 5
        play sound "audio/crack.mp3"
        $ hate = True
        tom ha blow "我曾经称呼过一些吸血鬼为水蛭。当然，那是在认识塞恩之前。"
        tom capek -blow "我年轻的时候，我的精灵特征更明显。这吸引了一些年长吸血鬼不太受欢迎的注意。"
    elif gift == "ctulhu":
        $ daterp += 5
        play sound "audio/success.mp3"
        $ lovely = True
        tom eh "我总是觉得噬梦者令人不安，因为他们可以变形并改变整个身体。"
        tom pfft "不过，有些人对他们有特殊癖好。"
    elif gift == "jelly":
        $ daterp -= 10
        play sound "audio/crack.mp3"
        $ hate = True
        tom sad blow "我曾经被那些水母蜇过。那感觉不太好。"
        show tom frown -blow
    elif gift == "curses":
        $ daterp += 25
        play sound "audio/success.mp3"
        $ lovely = True
        tom amused cling "黑暗符文很有趣，你不觉得吗？"
        tom pfft -cling "他们说这些符文都来自一个巫师，塞斯。变化巫师。"
        tom calm "显然，这个人想要推动人类进入进化的下一个阶段。"
        tom smile "幸运的是，即使是巫师也不能完全无视自然法则。"
    elif gift == "dreams":
        $ daterp += 20
        play sound "audio/success.mp3"
        $ lovely = True
        tom pfft apa "平行宇宙？我不太了解。但我曾经做过一个奇怪的梦。"
        tom calm -apa "我年纪大了，似乎在给某人做手术。只是工具与我们这里的完全不同。"
        tom smile "我一直在说\'清场\'，同时用两个方形拍子电击那个人。"
    elif gift == "curios":
        $ daterp += 15
        play sound "audio/success.mp3"
        $ lovely = True
        if "mey_kill" in my_events:
            tom giggle blow "哦是的，[povname]有探索未知的倾向。"
            tom pfft -blow "有时候危险得很。我们差点因[dia]之手而死的次数多得不好笑。"
        else:
            tom calm "哦是的，你有探索未知的倾向。"
            tom pfft "有时候危险得很。感觉你有时在拿我们做实验，就为了看看我们会有什么反应。"
    
    elif gift == "rewrite":
        $ daterp -= 15
        play sound "audio/crack.mp3"
        $ hate = True
        if "mey_kill" in my_events:
            tom ew frusta "啊。那个符文。[povname]曾经用它给我一个逃避的机会。"
        else:
            tom whine frusta "啊。那个符文。你曾经用它给我一个逃避的机会。"
        if calendar.weekday == "Sat" or calendar.weekday == "Sun":
            show side_p fr at pic
        else:
            show side_p f at pic
        mc "逃避？"
        hide side_p
        tom sigh blow "忘记我们之间的一切，无论好坏。"
        if "mey_kill" in my_events:
            tom sad -blow "也许[kamu]想要让我免受心痛，但我无法想象这是健康的做法。"
            tom whine "失去所有关于[povname]的记忆很可能会摧毁我的心智。太多空白点了。"
            tom nyesal "我很惊讶[kamu]居然考虑过这个，真的。"
        else:
            tom ha apa "也许你想要让我免受心痛，但我无法想象这是健康的做法。"
            tom sad -apa "把你从画面中移除就像我失去了一半的记忆。"
    elif gift == "sirens":
        $ daterp += 5
        play sound "audio/success.mp3"
        $ lovely = True
        tom giggle blush bloom "我喜欢海妖。他们是美丽、温和的生物。"
        tom sad -blush blow "他们实际上和我们一样聪明，只是没人费心去尝试与他们交流。"
        tom ha -blow "我拒绝称他们为野蛮人，更恰当的说法是他们无忧无虑。"
        tom smile "你知道他们通过唱歌来选择女王吗？最好的歌手得以统治整个群体。"
    elif gift == "tabu":
        $ daterp -= 10
        play sound "audio/crack.mp3"
        $ hate = True
        tom capek frusta "我现在不想谈论那个。"
        show tom frown -frusta
    else:
        $ daterp -= 10
        play sound "audio/crack.mp3"
        $ hate = True
        tom capek frusta "我和我的射箭队友相处得不太好。我想把这归咎于种族主义，但我希望他们有更高的素质。"
        show tom frown -frusta

    
    window hide
    return


label talkLyall:
    if gift == "monarchy":
        buff keluh sweat "吸血鬼王室？恐怕我对此知之甚少。"
        buff sad -sweat "不过，我听到班上的女生们说她们不想被塞恩咬脖子。"

    elif gift == "soulmates":
        $ daterp += 10
        play sound "audio/success.mp3"
        $ lovely = True
        buff hister blush "啊，我真的希望我在某处有个灵魂伴侣。"
        buff wry "我知道狼人和吸血鬼更容易发现他们的灵魂伴侣，但我真的相信我们每个人都有命中注定的爱人。"
        buff datar -blush "即使他们不是我们生命中注定的挚爱，只是陪伴我们走过一半的路程，也是值得的。"
    
    elif gift == "shriek":
        $ daterp -= 15
        play sound "audio/crack.mp3"
        $ hate = True
        buff keluh sweat "校长办公室里有一个窃窃私语球？我不知道。"
        buff sad -sweat "女妖和海妖比人们认为的更像人类，但每个人都把它们当作动物对待。"
        buff kzl "我知道有些人只是为了娱乐而猎杀它们，但我没想到校长也是这样的人。"
        buff keluh "即使是我父亲也尊重它们。有一次，我看到他照料一只受伤的海妖直到康复。"
        buff frown "她的一只翅膀被剪断了，父亲为她做了一个临时的翅膀。"
        buff datar "我想那是我少有的尊重那个男人的时刻之一。"
    elif gift == "bloodmoon":
        $ daterp += 10
        play sound "audio/success.mp3"
        $ lovely = True
        buff laugh "我喜欢和大家一起观看血月。伊尔夫和我爬上了我们能找到的最高的山丘，在那里露营了整整一夜。"
        show buff datar
    elif gift == "mom":
        $ daterp -= 5
        play sound "audio/crack.mp3"
        $ hate = True
        buff keluh sweat "啊，恐怕我对母亲的记忆不多。"
        buff wry -sweat "不过我知道她很美，伊尔夫说她来自东方。"
        buff sad "但除此之外，嗯...我想我得问问伊瓦尔。"
    elif gift == "leech":
        $ daterp += 15
        play sound "audio/success.mp3"
        $ lovely = True
        buff talk apa "水蛭？哦，是的，我和派克钓鱼时找到过几条。"
        buff laugh -apa "它们在制作魔药时很有用，迪特里希先生有时会亲自向我购买。"
        buff datar "不过我不确定他用它们做什么。"
    elif gift == "ctulhu":
        $ daterp += 35
        play sound "audio/success.mp3"
        $ lovely = True
        buff laugh shock "啊！你说的是奥利凡德先生吗？"
        if calendar.weekday == "Sat" or calendar.weekday == "Sun":
            show side_p fr at pic
        else:
            show side_p f at pic
        mc "你见过他？"
        hide side_p
        buff wry -shock "在我钓鱼的时候见过一两次。当他从章鱼变形成一个成年男子时，我惊讶极了！"
        buff talk "他很有趣，有时还会帮忙引诱一些稀有的鱼。"
        buff datar "不过他不会在派克周围出现，我不知道他是不是害羞。"
    elif gift == "jelly":
        buff sad "伊瓦尔和我的兄弟姐妹并不真正庆祝水母节。"
        buff keluh "我不确定为什么，但每年那个时候到来时，伊瓦尔总是把自己锁在棚子里。"
        buff kzl "不过我并不在乎。"
    elif gift == "curses":
        $ daterp -= 15
        play sound "audio/crack.mp3"
        $ hate = True
        buff keluh "伊尔夫和我的妹妹吉吉曾经警告我不要学习那些诅咒。"
        buff sad "说这是为我好。我知道作为混血儿，我们有50%%的几率在符文中存活。"
        buff kzl frusta "但我不会冒这样的风险。"
        show buff sad -frusta
    elif gift == "dreams":
        $ daterp += 30
        play sound "audio/success.mp3"
        $ lovely = True
        buff laugh blush bloom "[povname]，哦，你也相信平行宇宙吗？"
        buff talk "我哥哥曾经说他梦见我们都幸福地生活在一起。"
        buff wry sigh "头脑清醒，肚子里装满了我们母亲做的食物，暖洋洋的。"
        buff talk -blush -sigh "想象这样的现实存在，真是美好。"
        
    
    elif gift == "sirens":
        $ daterp += 5
        play sound "audio/success.mp3"
        $ lovely = True
        if "kid_coret" in fia_events:
            buff keluh sweat "我希望欧文安全。如果他被吸血鬼抓住了，我会崩溃的。"
            show buff sad -sweat
        else:
            buff wry "我一直想看看海妖的鸟形态。"
            buff sad "有传言说欧文是海妖，但我不这么认为。"
            buff frown "不存在哑巴海妖，对吧？"
    elif gift == "tomb":
        if "io4" in my_events:
            buff keluh "我曾经以为从湖里听到的声音只是我的想象。"
            buff sad "我想我应该更相信自己的直觉。"
        else:
            buff sad "我知道这听起来可能很疯狂，但有些夜晚我能听到我们房间里的雕像在哭泣。"
            buff keluh "要么就是湖面闪烁着奇怪的绿光。"
            buff sad "好像它在以某种方式呼唤我。"

    else:
        buff huh "嗯？对-对不起。我对那个不太了解。"
        buff frown "我融入社会才只有一年左右。"

    window hide
    return
##################GIFT COMMAND###############################
default gift = ""
label giftcommand:
    $ hidedatingsystemcommand = True
    if datingplace != "sklh" or devil.acara > 0:
        show pboy s at horzappear
    else:
        show pboy at horzappear
    menu:
        "Quill" if check_inv_for(quill_items) and datingname == "奎尔":
            hide pboy
            $ turnsleft -= 1
            $ gift = "Quill"
            $ InvItem(*item_quill).toss(1)
            hide side_p
            call giftQuill from _call_giftQuill_0
            jump startdate
        "手铐" if check_inv_for(handcuff_items) and datingname == "奎尔":
            hide pboy
            $ turnsleft -= 1
            $ gift = "手铐"
            $ InvItem(*item_handcuffs).toss(1)
            hide side_p
            call giftQuill from _call_giftQuill_2
            jump startdate
        "洛基之霜" if check_inv_for(up_items) and datingname == "奎尔":
            hide pboy
            $ turnsleft -= 1
            $ gift = "洛基霜"
            $ InvItem(*item_up).toss(1)
            hide side_p
            call giftQuill from _call_giftQuill_3
            jump startdate
        "活死人" if check_inv_for(ghost_items) and datingname == "奎尔":
            hide pboy
            $ turnsleft -= 1
            $ gift = "幽灵"
            $ InvItem(*item_ghost).toss(1)
            hide side_p
            call giftQuill from _call_giftQuill_4
            jump startdate
        
        "血液" if check_inv_for(blood_items) and datingname == "塞恩":
            menu:
                "独角兽血" if check_inv_for(blud_items) and datingname == "塞恩":
                    hide pboy
                    $ turnsleft -= 1
                    $ gift = "血液"
                    $ InvItem(*item_blood).toss(1)
                    $ daterp += 45
                    call giftThane from _call_giftThane_5
                    jump startdate
                "海妖之血" if check_inv_for(sir_items) and datingname == "塞恩":
                    hide pboy
                    $ turnsleft -= 1
                    $ gift = "血液"
                    $ InvItem(*item_siren).toss(1)
                    $ daterp += 35
                    hide side_p
                    call giftThane from _call_giftThane_6
                    jump startdate
                "混血" if check_inv_for(plas_items) and datingname == "塞恩":
                    hide pboy
                    $ turnsleft -= 1
                    $ gift = "血液"
                    $ InvItem(*item_plasma).toss(1)
                    $ daterp += 25
                    hide side_p
                    call giftThane from _call_giftThane_7
                    jump startdate
        "讽刺小说" if check_inv_for(sat_items) and datingname == "塞恩":
            hide pboy
            $ turnsleft -= 1
            $ gift = "讽刺"
            $ InvItem(*item_satire).toss(1)
            hide side_p
            call giftThane from _call_giftThane_0
            jump startdate
        "血棒糖" if check_inv_for(pop_items) and datingname == "塞恩":
            hide pboy
            $ turnsleft -= 1
            $ gift = "血棒糖"
            $ InvItem(*item_pop).toss(1)
            hide side_p
            call giftThane from _call_giftThane_1
            jump startdate
        "维他命" if check_inv_for(vit_items) and datingname == "塞恩":
            hide pboy
            $ turnsleft -= 1
            $ gift = "维他命"
            $ InvItem(*item_vita).toss(1)
            hide side_p
            call giftThane from _call_giftThane_2
            jump startdate
        "蛋糕" if check_inv_for(cake_items) and datingname == "莱尔":
            hide pboy
            $ turnsleft -= 1
            $ gift = "蛋糕"
            $ InvItem(*item_cake).toss(1)
            hide side_p
            call giftLyall from _call_giftLyall_0
            jump startdate
        "猫粮" if check_inv_for(cat_items) and datingname == "莱尔":
            hide pboy
            $ turnsleft -= 1
            $ gift = "猫粮"
            $ InvItem(*item_catfood).toss(1)
            hide side_p
            call giftLyall from _call_giftLyall_15
            jump startdate
        "面包" if check_inv_for(bread_items) and datingname == "莱尔":
            hide pboy
            $ turnsleft -= 1
            $ gift = "面包"
            $ InvItem(*item_bread).toss(1)
            hide side_p
            call giftLyall from _call_giftLyall_2
            jump startdate
        "糖果" if check_inv_for(sucker_item):
            hide pboy
            $ turnsleft -= 1
            $ gift = "糖果"
            $ InvItem(*item_sucker).toss(1)
            hide girl_s
            hide boy_s
            hide side_p
            if datingname == "塞恩":

                call giftThane from _call_giftThane_3
            elif datingname == "奎尔":
                call giftQuill from _call_giftQuill_5
            elif datingname == "阿什姆":
                call giftTom from _call_giftTom_5
            else:
                call giftLyall from _call_giftLyall_3
            jump startdate
        "热可可" if check_inv_for(coco_items) and datingname == "莱尔":
            hide pboy
            $ turnsleft -= 1
            $ gift = "可可"
            $ InvItem(*item_coco).toss(1)
            hide side_p
            call giftLyall from _call_giftLyall_4
            jump startdate
        "蜂蜜" if check_inv_for(honey_items) and datingname == "阿什姆":
            hide pboy
            $ turnsleft -= 1
            $ gift = "蜂蜜"
            $ InvItem(*item_honey).toss(1)
            hide side_p
            call giftTom from _call_giftTom_0
            jump startdate
        "葡萄酒" if check_inv_for(wine_items) and datingname == "阿什姆":
            hide pboy
            $ turnsleft -= 1
            $ gift = "葡萄酒"
            $ InvItem(*item_wine).toss(1)
            hide side_p
            call giftTom from _call_giftTom_15
            jump startdate
        "神秘书籍" if check_inv_for(myst_items) and datingname == "阿什姆":
            hide pboy
            $ turnsleft -= 1
            $ gift = "书"
            $ InvItem(*item_turq).toss(1)
            hide side_p
            call giftTom from _call_giftTom_2
            jump startdate
        "蜂蜜棒棒糖" if check_inv_for(car_items) and datingname == "阿什姆":
            hide pboy
            $ turnsleft -= 1
            $ gift = "蜂蜜棒棒糖"
            $ InvItem(*item_caramel).toss(1)
            hide side_p
            call giftTom from _call_giftTom_3
            jump startdate
        "面包" if check_inv_for(bread_items) and datingname == "阿什姆":
            hide pboy
            $ turnsleft -= 1
            $ gift = "面包"
            $ InvItem(*item_bread).toss(1)
            hide side_p
            call giftTom from _call_giftTom_4
            jump startdate
        "Lint" if "day_0" not in my_events:
            hide pboy
            $ turnsleft -= 1
            hide girl_s
            hide boy_s
            if datingname == "塞恩":
                call giftThane from _call_giftThane_4
            elif datingname == "奎尔":
                call giftQuill from _call_giftQuill_1
            elif datingname == "阿什姆":
                call giftTom from _call_giftTom_1
            else:
                call giftLyall from _call_giftLyall_1
            jump startdate
        
        "算了":
            hide pboy
            jump startdate
label giftThane:
    if gift == "糖果":
        if "day_0" not in my_events:
            show red kaget apa at charcenter
            red "这是什么？糖果吗？"
            if girl:
                show p_side sm at pic
            else:
                show side_p h at pic

            mc "纪念品。"
            if girl:
                hide p_side
            else:
                hide side_p
            red amused sweat -apa "嗯。你还记得作为吸血鬼，我除了血以外什么都尝不出来，对吧？"
            mc "（等等，吸血鬼？！）"
            red happy -sweat "不过，我猜在沃特克帝国之外很难买到血棒糖。"
            $ mrh.likes = "血棒糖，血（以及所有相关变体）。"
            $ daterp += 10
            $ mrh.points += 5
        else:
            red amused "糖果？当然，我会收下的。原来只要不是蜂蜜棒棒糖，我还是喜欢甜食的！"
            $ daterp += 10
        play sound "audio/success.mp3"
        $ lovely = True
        red laugh blush bunga "心意最重要。谢谢！"
        show red datar -bunga -blush
        
    elif gift == "血液":
        play sound "audio/success.mp3"
        $ lovely = True
        show red cowo at charcenter
        red hister blush bloom "血？哇，太感谢了！"
        red wry -blush -bloom "你最棒了[povname]！"
    elif gift == "血棒糖":
        $ daterp += 20
        play sound "audio/success.mp3"
        $ lovely = True
        show red laugh at charcenter
        red blush bunga "血棒糖！哇，我小时候最喜欢这个了！"
        red datar -blush "非常感谢！"
    elif gift == "讽刺":
        $ daterp += 10
        play sound "audio/success.mp3"
        $ lovely = True
        show red amused at charcenter
        red "哦，我一直想看看这个，非常感谢！"
    elif gift == "维他命":
        $ daterp += 15
        play sound "audio/success.mp3"
        $ lovely = True
        show red cowo at charcenter
        red "啊，这个我总是用得上。"
        red wry "在外出执行任务时我需要保持最佳状态！"
        red grin "谢谢！"
    else:
        show red sad sweat at charcenter
        $ daterp -= 20
        play sound "audio/crack.mp3"
        $ hate = True
        red "哈哈，很有趣，[nickname]。"
        show red datar -sweat
    window hide
    jump startdate





# QUILL
label giftQuill:
    if gift == "Quill":
        $ daterp += 5
        play sound "audio/success.mp3"
        $ lovely = True
        quil hister sigh "给奎尔一支羽毛笔，你一定为自己感到非常自豪吧。"
        show quil datar -sigh
    elif gift == "卷轴":
        $ daterp += 10
        play sound "audio/success.mp3"
        $ lovely = True
        quil "呃，你真的要给我这个吗？认真的？！"
        quil "我是说，亲爱的，我已经有很多这样的东西了，但是你给我的话，嗯..."
        quil "你并不富裕，对吧？所以谢谢你。"
    elif gift == "手铐":
        $ daterp += 5
        play sound "audio/success.mp3"
        $ lovely = True
        quil laugh shock "啊，我以前经常收到这些。主要是用来做实验，然后用在其他学生身上。"
        quil amused cling "当然是在战斗中，你以为我会在哪里用它们？如果他们不能战斗，我就不会输！"
        quil malu sigh "虽然有些老师会误会。是他们的思想龌龊，不是我。"
        show quil smile -sigh
    elif gift == "洛基霜":
        $ daterp += 10
        play sound "audio/success.mp3"
        $ lovely = True
        quil laugh blush bloom "哦，我太喜欢这个了！谢谢你！"
        quil talk -bloom "而且是如此高质量的洛基之霜！亲爱的，你很有天赋，谁能想到呢？"
        show quil datar -blush
    elif gift == "幽灵":
        $ daterp += 10
        play sound "audio/success.mp3"
        $ lovely = True
        quil smile "这在我需要偷偷溜出去的夜晚肯定会派上用场，谢谢你！"
    else:
        $ daterp -= 45
        play sound "audio/crack.mp3"
        $ hate = True
        quil err sweat "哦，呃...谢谢？"
        quil datar -sweat "虽然我没什么用处。"
    window hide
    jump startdate

# ARSHEM
label giftTom:
    if gift == "蜂蜜":
        $ daterp += 3
        play sound "audio/success.mp3"
        $ lovely = True
        tom giggle blush bunga "这是精灵能要求的最好的食物之一，谢谢你！"
        show tom smile -blush -bunga
    elif gift == "葡萄酒":
        $ daterp += 4
        play sound "audio/success.mp3"
        $ lovely = True
        tom calm "哦，谢谢。"
    elif gift == "书":
        $ daterp += 2
        play sound "audio/success.mp3"
        $ lovely = True
        tom pfft "哦，我想我已经有这个了，不过多一份备份总是好的。"
        tom calm "谢谢你。"
    elif gift == "蜂蜜棒棒糖":
        $ daterp += 10
        play sound "audio/success.mp3"
        $ lovely = True
        tom giggle blush bunga "这是你自己做的吗？太感谢了！"
        show tom smile -blush -bunga
    elif gift == "烘焙食品":
        $ daterp += 8
        play sound "audio/success.mp3"
        $ lovely = True
        tom calm blush bloom "没有什么比新鲜出炉的糕点更令人感到舒心的了，对吧？"
        tom amused cling "这是你自己做的吗？提醒我要回报你哦！"
        show tom smile -blush -cling
    else:
        tom calm "哦，谢谢。心意最重要。"
    window hide
    jump startdate

#Lyall
label giftLyall:
    if gift == "蛋糕":
        $ daterp += 5
        play sound "audio/success.mp3"
        $ lovely = True
        buff laugh "这是你烤的吗？哇！[povname]，你太有才了！"
    elif gift == "猫粮":
        $ daterp += 8
        play sound "audio/success.mp3"
        $ lovely = True
        buff laugh blush bloom "你要把这个给我吗？谢谢！"
        buff talk -blush -bloom "我喜欢猫，真希望学校能让我们养一只。"
    elif gift == "面包":
        $ daterp += 5
        play sound "audio/success.mp3"
        $ lovely = True
        buff laugh blush "没有什么比新鲜出炉的面包更好的了，对吧？"
        buff talk -blush "我还是对你的厨艺感到惊叹不已！"
    elif gift == "糖果":
        $ daterp += 1
        play sound "audio/success.mp3"
        $ lovely = True
        buff laugh blush bloom "哦，莱纳尔的孩子们最喜欢这个了！"
        buff datar -blush apa "[povname]，你介意我和他们分享吗？"
        if calendar.weekday == "Sat" or calendar.weekday == "Sun":
            show side_p ha at pic
        else:
            show side_p se at pic
        mc "当然，我相信孩子们会很感激的！"
        hide side_p
        show buff -apa
    elif gift == "可可":
        $ daterp += 10
        play sound "audio/success.mp3"
        $ lovely = True
        buff hister blush bunga "哦，这是我的最爱，你怎么知道的？"
        if calendar.weekday == "Sat" or calendar.weekday == "Sun":
            show side_p ha at pic
        else:
            show side_p se at pic
        mc "我想在你辛苦钓了一天鱼后，你会喜欢吃点暖和的东西。"
        hide side_p
        buff talk -blush -bunga "这正是我需要的，谢谢你[povname]！"
    else:
        $ daterp += 5
        play sound "audio/success.mp3"
        $ lovely = True
        buff laugh "哦，谢谢！哇，免费得到东西真是太棒了，不是吗？"
    window hide
    jump startdate
###################SKINSHIP#################################
label skinship:
    $ config.skipping = None

    $ hidedatingsystemcommand = True
    if datingname == "塞恩":
        show screen skinshipThane
        pause
        call skinshipThaneresponse from _call_skinshipThaneresponse
    elif datingname == "奎尔":
        show screen skinshipQuill
        pause
        call skinshipQuillresponse from _call_skinshipQuillresponse
    elif datingname == "阿什姆":
        show screen skinshipTom
        pause
        call skinshipTomresponse from _call_skinshipTomresponse
    else:
        show screen skinshipLyall
        pause
        call skinshipLyallresponse from _call_skinshipLyallresponse
    $ turnsleft -= 1
    jump startdate

label startdate:
    $ hidedatingsystemcommand = False
    $ num = 0
    $ skinshiprespond = 0
    $ skinshiparea = ""
    if datingname == "塞恩":
        if datingplace == "sklh":
            if daterp >= 70:
                show red happy at charcenter
            elif daterp >= 50:
                show red amused at charcenter
            elif daterp >= 30:
                show red datar at charcenter
            else:
                show red frown at charcenter
        else:
            if daterp >= 70:
                show red bebas happy at charcenter
            elif daterp >= 50:
                show red bebas amused at charcenter
            elif daterp >= 30:
                show red bebas datar at charcenter
            else:
                show red bebas frown at charcenter
    elif datingname == "奎尔":
        if datingplace == "sklh":
            if daterp >= 70:
                show quil laugh at charcenter
            elif daterp >= 50:
                show quil amused at charcenter
            elif daterp >= 30:
                show quil datar at charcenter
            else:
                show quil sulk at charcenter
        else:
            if daterp >= 70:
                show quil libur laugh at charcenter
            elif daterp >= 50:
                show quil libur amused at charcenter
            elif daterp >= 30:
                show quil libur datar at charcenter
            else:
                show quil libur sulk at charcenter
    elif datingname == "阿什姆":
        if datingplace == "sklh":
            if daterp >= 50:
                show tom amused at charcenter
            elif daterp >= 30:
                show tom smile at charcenter
            elif daterp >= 5:
                show tom smile at charcenter
            else:
                show tom capek at charcenter
        else:
            if daterp >= 50:
                show tom go amused at charcenter
            elif daterp >= 30:
                show tom go smile at charcenter
            elif daterp >= 5:
                show tom go smile at charcenter
            else:
                show tom go capek at charcenter
    else:
        if datingplace == "sklh":
            if daterp >= 70:
                show buff laugh at charcenter
            elif daterp >= 50:
                show buff datar at charcenter
            elif daterp >= 30:
                show buff frown at charcenter
            else:
                show buff wry at charcenter
        else:
            if daterp >= 70:
                show buff bebas laugh at charcenter
            elif daterp >= 50:
                show buff bebas datar at charcenter
            elif daterp >= 30:
                show buff bebas frown at charcenter
            else:
                show buff bebas wry at charcenter
    if turnsleft >= 3:
        $ turnsleft = 3    
    elif turnsleft==0:

        $ hidedatingsystemcommand = True
        if "day_0" not in my_events:
            jump finishdate
        else:
            jump finishdate2
    show screen datingsystemmain
    pause
    jump startdate

label finishdate2:
    if looping:
        return
    hide screen datingsystemcommand
    hide screen datingsystemmain
    if datingname == "塞恩":
        if datingplace == "sushi1":
            if daterp >=70:
                $ mrh.points += 10
            elif daterp >=50 and daterp <70:
                $ mrh.points += 5
            elif daterp <30 and daterp >=20:
                $ mrh.points -= 5
                if mrh.points <0:
                    $ mrh.points = 0
            elif daterp <20:
                $ mrh.points -= 10
                if mrh.points <0:
                    $ mrh.points = 0
            else:
                $ mrh.points += 1
            $ quick_menu = True
            $ renpy.block_rollback()
            $ config.rollback_enabled = True
            show screen cal
            jump reddate_1_closing
                
        else:
            if daterp >=70:
                "美妙的约会，与塞恩的好感度增加了10点。"
                $ mrh.points += 10
                $ mrh.likes = "血液，血棒糖，糖果，讽刺小说，维他命。"
                $ mrh.dislikes = "触摸头发，深入交谈，谈论吸血鬼。"
            elif daterp >=50 and daterp <70:
                "不错的约会，与塞恩的好感度增加了5点。"
                $ mrh.points += 5
            elif daterp <30 and daterp >=20:
                "糟糕的约会，与塞恩的好感度减少了5点。"
                $ mrh.dislikes = "触摸头发，深入交谈，谈论吸血鬼。"
                $ mrh.points -= 5
                if mrh.points <0:
                    $ mrh.points = 0
            elif daterp <20:
                "糟糕透顶的约会，与塞恩的好感度减少了10点。"
                $ mrh.dislikes = "触摸头发，深入交谈，谈论吸血鬼。"
                $ mrh.points -= 10
                if mrh.points <0:
                    $ mrh.points = 0
            else:
                "平淡的约会，与塞恩的好感度增加了1点。"
                $ mrh.points += 1
            scene bg_black with w20
            scene lor_mlm with w20
            $ quick_menu = True
            $ renpy.block_rollback()
            $ config.rollback_enabled = True
            show screen cal
            if night:
                jump jaga_jaga
            else:
                play music "MUSIC/MusMus-BGM-082.mp3"
                jump ur_room
           
    elif datingname == "奎尔": #higher threshold for good date
        if daterp >=80:
            "美妙的约会，与[datingname]的好感度增加了10点。"
            $ bff.points += 10
            $ bff.likes = "交谈，手铐，羽毛笔，洛基之霜，活死人"
            $ bff.dislikes = "触摸，糖果或烘焙食品。"
        elif daterp >=60 and daterp <80:
            "不错的约会，与[datingname]的好感度增加了5点。"
            $ bff.points += 5
        elif daterp <40 and daterp >=30:
            "糟糕的约会，与[datingname]的好感度减少了5点。"
            $ bff.dislikes = "触摸，糖果或烘焙食品。"
            $ bff.points -= 5
            if bff.points <0:
                $ bff.points = 0
        elif daterp <30:
            "糟糕透顶的约会，与[datingname]的好感度减少了10点。"
            $ bff.dislikes = "触摸，糖果或烘焙食品。"
            $ bff.points -= 10
            if bff.points <0:
                $ bff.points = 0
        else:
            "平淡的约会，与[datingname]的好感度增加了1点。"
            $ bff.points += 1
    elif datingname == "阿什姆": #low threshold for good date
        if daterp >=50:
            "美妙的约会，与[datingname]的好感度增加了10点。"
            $ ibu.likes = "触摸，葡萄酒，蜂蜜，蜂蜜棒棒糖，面包，悬疑小说。"
            $ ibu.dislikes = "谈论过去，谈论他的俱乐部。"
            $ ibu.points += 10
        elif daterp >=20 and daterp <50:
            "不错的约会，与[datingname]的好感度增加了5点。"
            $ ibu.points += 5
        elif daterp <10 and daterp >=5:
            "糟糕的约会，与[datingname]的好感度减少了5点。"
            $ ibu.points -= 5
            $ ibu.dislikes = "谈论过去，谈论他的俱乐部。"
            if ibu.points <0:
                $ ibu.points = 0
        elif daterp <5:
            "糟糕透顶的约会，与[datingname]的好感度减少了10点。"
            $ ibu.points -= 10
            $ ibu.dislikes = "谈论过去，谈论他的俱乐部。"
            if ibu.points <0:
                $ ibu.points = 0
        else:
            "平淡的约会，与[datingname]的好感度增加了1点。"
            $ ibu.points += 1
        
    else:
        if daterp >=70: #no bad date
            "美妙的约会，与[datingname]的好感度增加了10点。"
            $ putri.points += 10
            $ putri.likes = "所有甜点和烘焙食品，触摸。"
            $ putri.dislikes = "无。"
        elif daterp >=50 and daterp <70:
            "不错的约会，与[datingname]的好感度增加了5点。"
            $ putri.points += 5
        elif daterp <30 and daterp >=20:
            "糟糕的约会，但[datingname]似乎并不太在意。"
            $ putri.points += 1
        elif daterp <20:
            "糟糕的约会，但[datingname]似乎并不介意。你尽力了。"
        else:
            "平淡的约会，与[datingname]的好感度增加了2点。"
            $ putri.points += 2
    scene bg_black with w20
    scene lor_mlm with w20
    $ quick_menu = True
    $ renpy.block_rollback()
    $ config.rollback_enabled = True
    show screen cal
    if night:
        jump jaga_jaga
    else:
        play music "MUSIC/MusMus-BGM-082.mp3"
        jump ur_room
label finishdate:
    if looping:
        return
    hide screen datingsystemmain
    hide screen datingsystemcommand
    scene arrow_fort_crowd with fade
    call finishdatingThane from _call_finishdatingThane
    $ devil.acara = 0
    jump ganti_baju


label finishdatingThane:
    if looping:
        return
    if daterp>=70:
        show screen cal
        show red laugh blush at charcenter
        $ mrh.points += 5
        red "好吧，你最好去换衣服。"
        red sad sweat "维尔科娃女士最近对校服的要求比平时更严格了。她看到我穿便服时差点把我的头砍下来。"
        red ew -sweat "那个女人真的需要找个爱好。"
        red happy "总之，课堂上见！"
        $ renpy.block_rollback()
    else:
        show screen cal
        show red bingung sweat at charcenter
        "无论你做了什么，似乎都没能让那个男人满意。"
        red "[nickname]，你还好吗？你看起来有点不一样。更加..."
        red chin sad "我不知道，心不在焉？你该不会又在喝酒吧？"
        if girl:
            show p_side gl at pic
        else:
            show side_p h at pic

        mc "（啊，看来在这个世界里，我还是有酗酒问题。很高兴知道有些事情永远不会改变，我想。）"
        if girl:
            hide p_side
        else:
            hide side_p
        show red frown at kiri with move
        show quil libur laugh cling at right with moveinright:
            yoffset 200
        quil "[nickname]只是有点累而已。我们昨晚过得很艰难，对吧，亲爱的[nickname]？"
        show quil smile -cling
        red kaget sweat shock "等等，\'艰难的夜晚\'？你们该不会..."
        quil libur talk blush spark "[povname]真的是太不可思议了，我能理解为什么阿什姆——"
        show quil smile -spark
        red ew both frusta "等等，不，不不！我不想知道！"
        red sayang sweat sigh "如果你们真的上床了，嗯...恭喜你，奎尔。我猜这就把我和阿什姆列入你的目标名单了，是吧？"
        if girl:
            show p_side y at pic
        else:
            show side_p k at pic
        mc "等等，什么——？"
        if girl:
            hide p_side
        else:
            hide side_p
        red awkward -sweat -sigh "不过，我希望这值得。当阿什姆发现时，他会杀了你的。"
        quil sad -blush cling "怎么，你要告发我吗，红发？在我们经历了这么多之后？"
        show quil datar -blush -cling
        red wry "呵。我不会，但这什么时候阻止过他发现事情的真相呢？"
        show quil libur cringe sweat
        red cowo cling "我会为你祈祷的，不过！"
        show quil datar -sweat
        red datar point -cling "总之，你们俩最好在上课前去换衣服。"
        red happy "回头见！"
        quil smile "再见。"
        $ renpy.block_rollback()
    return


default skinshiparea = ""
default skinshiprespond = 0
#THANE
screen skinshipThane():
    modal True
    if datingplace == "sklh":
        imagebutton:
            xpos 581
            ypos 650
            idle "hand"
            hover "hand"
            hovered [ Play ("test_one", "type.wav")]
            action [ Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "hand"), Hide("skinshipThane"), Return()]
            focus_mask True
            mouse "search"
        imagebutton:
            xpos 952
            ypos 26
            idle "hair"
            hover "hair"
            hovered [ Play ("test_one", "type.wav")]
            action [ Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "hair"), Hide("skinshipThane"), Return()]
            focus_mask True
            mouse "search"
        imagebutton:
            xpos 832
            ypos 289
            idle "red_bahu"
            hover "red_bahu"
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "arms"), Hide("skinshipThane"), Return()]
            focus_mask True
            mouse "search"
        imagebutton:
            xpos 1207
            ypos 309
            idle "bahu_kanan"
            hover "bahu_kanan"
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "arms"), Hide("skinshipThane"), Return()]
            focus_mask True
            mouse "search"
        imagebutton:
            xpos 1008
            ypos 556
            idle "stomach"
            hover "stomach"
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "stomach"), Hide("skinshipThane"), Return()]
            focus_mask True
            mouse "search"
        imagebutton:
            xpos 1017
            ypos 317
            idle "chest"
            hover "chest"
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "chest"), Hide("skinshipThane"), Return()]
            focus_mask True
            mouse "search"
        imagebutton:
            xpos 1109
            ypos 678
            idle "crotch"
            hover "crotch"
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "crotch"), Hide("skinshipThane"), Return()]
            focus_mask None
            mouse "search"
        imagebutton:
            xpos 818
            ypos 561
            idle "elbow"
            hover "elbow"
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "elbow"), Hide("skinshipThane"), Return()]
            focus_mask None
            mouse "search"
    else:
        imagebutton:
            xpos 1010
            ypos 695
            idle "red_hand"
            hover "red_hand"
            hovered [ Play ("test_one", "type.wav")]
            action [ Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "hand"), Hide("skinshipThane"), Return()]
            focus_mask True
            mouse "search"
        imagebutton:
            xpos 951
            ypos 26
            idle "hair"
            hover "hair"
            hovered [ Play ("test_one", "type.wav")]
            action [ Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "hair"), Hide("skinshipThane"), Return()]
            focus_mask True
            mouse "search"
        imagebutton:
            xpos 1010
            ypos 151
            idle "red_cheek"
            hover "red_cheek"
            hovered [ Play ("test_one", "type.wav")]
            action [ Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "cheek"), Hide("skinshipThane"), Return()]
            focus_mask None
            mouse "search"
        imagebutton:
            xpos 883
            ypos 368
            idle "red_bahu2"
            hover "red_bahu2"
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "arms"), Hide("skinshipThane"), Return()]
            focus_mask True
            mouse "search"
        imagebutton:
            xpos 1211
            ypos 596
            idle "red_stomach"
            hover "red_stomach"
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "stomach"), Hide("skinshipThane"), Return()]
            focus_mask True
            mouse "search"
        imagebutton:
            xpos 1025
            ypos 316
            idle "red_chest"
            hover "red_chest"
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "chest"), Hide("skinshipThane"), Return()]
            focus_mask True
            mouse "search"
        imagebutton:
            xpos 1131
            ypos 735
            idle "red_crotch"
            hover "red_crotch"
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "crotch"), Hide("skinshipThane"), Return()]
            focus_mask None
            mouse "search"
#QUILL
screen skinshipQuill():
    modal True
    if datingplace == "sklh":
        imagebutton:
            xpos 930
            ypos 16
            idle "qhair"
            hover "qhair"
            hovered [ Play ("test_one", "type.wav")]
            action [ Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "hair"), Hide("skinshipQuill"), Return()]
            focus_mask True
            mouse "search"
        imagebutton:
            xpos 976
            ypos 164
            idle "qcheek"
            hover "qcheek"
            hovered [ Play ("test_one", "type.wav")]
            action [ Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "cheek"), Hide("skinshipQuill"), Return()]
            focus_mask None
            mouse "search"
        imagebutton:
            xpos 793
            ypos 800
            idle "qhand"
            hover "qhand"
            hovered [ Play ("test_one", "type.wav")]
            action [ Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "hand"), Hide("skinshipQuill"), Return()]
            focus_mask True
            mouse "search"
        imagebutton:
            xpos 794 #798
            ypos 271 #279
            idle "qbahukiri"
            hover "qbahukiri"
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "arms"), Hide("skinshipQuill"), Return()]
            focus_mask True
            mouse "search"
        imagebutton:
            xpos 1183
            ypos 279
            idle "qbahukanan"
            hover "qbahukanan"
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "arms"), Hide("skinshipQuill"), Return()]
            focus_mask True
            mouse "search"
        imagebutton:
            xpos 979
            ypos 293
            idle "qchest"
            hover "qchest"
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "chest"), Hide("skinshipQuill"), Return()]
            focus_mask True
            mouse "search"
        imagebutton:
            xpos 968
            ypos 498
            idle "qstomach"
            hover "qstomach"
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "stomach"), Hide("skinshipQuill"), Return()]
            focus_mask True
            mouse "search"
        
        imagebutton:
            xpos 1014
            ypos 661
            idle "qcrotch"
            hover "qcrotch"
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "crotch"), Hide("skinshipQuill"), Return()]
            focus_mask None
            mouse "search"
        
    else:
        imagebutton:
            xpos 930
            ypos 16
            idle "qhair"
            hover "qhair"
            hovered [ Play ("test_one", "type.wav")]
            action [ Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "hair"), Hide("skinshipQuill"), Return()]
            focus_mask True
            mouse "search"
        imagebutton:
            xpos 976
            ypos 164
            idle "qcheek"
            hover "qcheek"
            hovered [ Play ("test_one", "type.wav")]
            action [ Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "cheek"), Hide("skinshipQuill"), Return()]
            focus_mask None
            mouse "search"
        imagebutton:
            xpos 793
            ypos 800
            idle "bq_hand"
            hover "bq_hand"
            hovered [ Play ("test_one", "type.wav")]
            action [ Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "hand"), Hide("skinshipQuill"), Return()]
            focus_mask True
            mouse "search"
        imagebutton:
            xpos 794 #798
            ypos 271 #279
            idle "bq_bahukiri"
            hover "bq_bahukiri"
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "arms"), Hide("skinshipQuill"), Return()]
            focus_mask True
            mouse "search"
        imagebutton:
            xpos 1183
            ypos 279
            idle "bq_bahukanan"
            hover "bq_bahukanan"
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "arms"), Hide("skinshipQuill"), Return()]
            focus_mask True
            mouse "search"
        imagebutton:
            xpos 979
            ypos 293
            idle "bq_chest"
            hover "bq_chest"
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "chest"), Hide("skinshipQuill"), Return()]
            focus_mask True
            mouse "search"
        imagebutton:
            xpos 968
            ypos 498
            idle "bq_stomach"
            hover "bq_stomach"
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "stomach"), Hide("skinshipQuill"), Return()]
            focus_mask True
            mouse "search"
        
        imagebutton:
            xpos 1014
            ypos 661
            idle "bq_crotch"
            hover "bq_crotch"
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "crotch"), Hide("skinshipQuill"), Return()]
            focus_mask None
            mouse "search"
#ARSHEM
screen skinshipTom():
    modal True
    if datingplace == "sklh":
        imagebutton:
            xpos 853
            ypos 18
            idle "thair"
            hover "thair"
            hovered [ Play ("test_one", "type.wav")]
            action [ Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "hair"), Hide("skinshipTom"), Return()]
            focus_mask True
            mouse "search"
        imagebutton:
            xpos 909
            ypos 162
            idle "tcheek"
            hover "tcheek"
            hovered [ Play ("test_one", "type.wav")]
            action [ Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "cheek"), Hide("skinshipTom"), Return()]
            focus_mask None
            mouse "search"
        imagebutton:
            xpos 877
            ypos 315
            idle "tchest"
            hover "tchest"
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "chest"), Hide("skinshipTom"), Return()]
            focus_mask True
            mouse "search"
        imagebutton:
            xpos 788
            ypos 315
            idle "tbahukiri"
            hover "tbahukiri"
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "arms"), Hide("skinshipTom"), Return()]
            focus_mask True
            mouse "search"
        imagebutton:
            xpos 1111
            ypos 230
            idle "tbahukanan"
            hover "tbahukanan"
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "arms"), Hide("skinshipTom"), Return()]
            focus_mask True
            mouse "search"
        imagebutton:
            xpos 725
            ypos 608
            idle "thand"
            hover "thand"
            hovered [ Play ("test_one", "type.wav")]
            action [ Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "hand"), Hide("skinshipTom"), Return()]
            focus_mask True
            mouse "search"
        imagebutton:
            xpos 1166
            ypos 792
            idle "thandka"
            hover "thandka"
            hovered [ Play ("test_one", "type.wav")]
            action [ Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "hand"), Hide("skinshipTom"), Return()]
            focus_mask True
            mouse "search"
        
        imagebutton:
            xpos 861
            ypos 546
            idle "tstomach"
            hover "tstomach"
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "stomach"), Hide("skinshipTom"), Return()]
            focus_mask True
            mouse "search"
        
        imagebutton:
            xpos 829
            ypos 668
            idle "tcrotch"
            hover "tcrotch"
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "crotch"), Hide("skinshipTom"), Return()]
            focus_mask None
            mouse "search"
        
    else:
        imagebutton:
            xpos 853
            ypos 18
            idle "thair"
            hover "thair"
            hovered [ Play ("test_one", "type.wav")]
            action [ Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "hair"), Hide("skinshipTom"), Return()]
            focus_mask True
            mouse "search"
        imagebutton:
            xpos 909
            ypos 162
            idle "tcheek"
            hover "tcheek"
            hovered [ Play ("test_one", "type.wav")]
            action [ Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "cheek"), Hide("skinshipTom"), Return()]
            focus_mask None
            mouse "search"
        imagebutton:
            xpos 877
            ypos 315
            idle "bt_chest"
            hover "bt_chest"
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "chest"), Hide("skinshipTom"), Return()]
            focus_mask True
            mouse "search"
        imagebutton:
            xpos 788
            ypos 315
            idle "bt_bahukiri"
            hover "bt_bahukiri"
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "arms"), Hide("skinshipTom"), Return()]
            focus_mask True
            mouse "search"
        imagebutton:
            xpos 1111
            ypos 230
            idle "bt_bahukanan"
            hover "bt_bahukanan"
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "arms"), Hide("skinshipTom"), Return()]
            focus_mask True
            mouse "search"
        imagebutton:
            xpos 725
            ypos 608
            idle "bt_hand"
            hover "bt_hand"
            hovered [ Play ("test_one", "type.wav")]
            action [ Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "hand"), Hide("skinshipTom"), Return()]
            focus_mask True
            mouse "search"
        imagebutton:
            xpos 1166
            ypos 792
            idle "bt_handka"
            hover "bt_handka"
            hovered [ Play ("test_one", "type.wav")]
            action [ Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "hand"), Hide("skinshipTom"), Return()]
            focus_mask True
            mouse "search"
        
        imagebutton:
            xpos 861
            ypos 546
            idle "bt_stomach"
            hover "bt_stomach"
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "stomach"), Hide("skinshipTom"), Return()]
            focus_mask True
            mouse "search"
        
        imagebutton:
            xpos 829
            ypos 668
            idle "bt_crotch"
            hover "bt_crotch"
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "crotch"), Hide("skinshipTom"), Return()]
            focus_mask None
            mouse "search"
#LYALL
screen skinshipLyall():
    modal True
    if datingplace == "sklh":
        imagebutton:
            xpos 928
            ypos 19
            idle "lhair"
            hover "lhair"
            hovered [ Play ("test_one", "type.wav")]
            action [ Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "hair"), Hide("skinshipLyall"), Return()]
            focus_mask True
            mouse "search"
        imagebutton:
            xpos 951
            ypos 158
            idle "lcheek"
            hover "lcheek"
            hovered [ Play ("test_one", "type.wav")]
            action [ Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "cheek"), Hide("skinshipLyall"), Return()]
            focus_mask None
            mouse "search"
        imagebutton:
            xpos 907
            ypos 328
            idle "lchest"
            hover "lchest"
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "chest"), Hide("skinshipLyall"), Return()]
            focus_mask True
            mouse "search"
        imagebutton:
            xpos 799
            ypos 331
            idle "lbahukiri"
            hover "lbahukiri"
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "arms"), Hide("skinshipLyall"), Return()]
            focus_mask True
            mouse "search"
        imagebutton:
            xpos 1159
            ypos 271
            idle "lbahukanan"
            hover "lbahukanan"
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "arms"), Hide("skinshipLyall"), Return()]
            focus_mask True
            mouse "search"
        imagebutton:
            xpos 858
            ypos 569
            idle "lhand"
            hover "lhand"
            hovered [ Play ("test_one", "type.wav")]
            action [ Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "hand"), Hide("skinshipLyall"), Return()]
            focus_mask True
            mouse "search"
        
        
        imagebutton:
            xpos 906
            ypos 494
            idle "lstomach"
            hover "lstomach"
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "stomach"), Hide("skinshipLyall"), Return()]
            focus_mask True
            mouse "search"
        
        imagebutton:
            xpos 924
            ypos 749
            idle "lcrotch"
            hover "lcrotch"
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "crotch"), Hide("skinshipLyall"), Return()]
            focus_mask None
            mouse "search"
        
    else:
        imagebutton:
            xpos 928
            ypos 19
            idle "lhair"
            hover "lhair"
            hovered [ Play ("test_one", "type.wav")]
            action [ Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "hair"), Hide("skinshipLyall"), Return()]
            focus_mask True
            mouse "search"
        imagebutton:
            xpos 951
            ypos 158
            idle "lcheek"
            hover "lcheek"
            hovered [ Play ("test_one", "type.wav")]
            action [ Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "cheek"), Hide("skinshipLyall"), Return()]
            focus_mask None
            mouse "search"
        imagebutton:
            xpos 907
            ypos 328
            idle "bl_chest"
            hover "bl_chest"
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "chest"), Hide("skinshipLyall"), Return()]
            focus_mask True
            mouse "search"
        imagebutton:
            xpos 799
            ypos 331
            idle "bl_bahukiri"
            hover "bl_bahukiri"
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "arms"), Hide("skinshipLyall"), Return()]
            focus_mask True
            mouse "search"
        imagebutton:
            xpos 1159
            ypos 271
            idle "bl_bahukanan"
            hover "bl_bahukanan"
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "arms"), Hide("skinshipLyall"), Return()]
            focus_mask True
            mouse "search"
        imagebutton:
            xpos 858
            ypos 569
            idle "bl_hand"
            hover "bl_hand"
            hovered [ Play ("test_one", "type.wav")]
            action [ Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "hand"), Hide("skinshipLyall"), Return()]
            focus_mask True
            mouse "search"
        
        
        imagebutton:
            xpos 906
            ypos 494
            idle "bl_stomach"
            hover "bl_stomach"
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "stomach"), Hide("skinshipLyall"), Return()]
            focus_mask True
            mouse "search"
        
        imagebutton:
            xpos 924
            ypos 749
            idle "bl_crotch"
            hover "bl_crotch"
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), SetVariable("skinshiparea", "crotch"), Hide("skinshipLyall"), Return()]
            focus_mask None
            mouse "search"
##
transform skinshiptransform:
    xpos 552 ypos 476
    on show:
        parallel:
            zoom 1.0
            linear 0.2 zoom 1.5
            linear 0.2 zoom 1.0
            repeat
        parallel:
            linear 0.1 rotate 5
            linear 0.1 rotate -5
            repeat
    on hide:
        linear .1 alpha 0.0
screen loveresponse():
    zorder 100
    add "datingsystem/doki.png" at skinshiptransform
    timer 1.0 action Hide('loveresponse')
    on "show" action [Play("sound", "audio/success.mp3")]

screen dislikeresponse():
    zorder 100
    add "datingsystem/heart_break.png" at skinshiptransform
    timer 1.0 action Hide('dislikeresponse')
    on "show" action Play("sound", "audio/crack.mp3")

##RESPONSE SKIN
label skinshipThaneresponse:
    hide screen skinshipThane
    $ skinshiprespond = renpy.random.randint(1, 3)
    if skinshiparea == "crotch":
        play sound "audio/crack.mp3"
        $ hate = True
        #show screen dislikeresponse
        if skinshiprespond == 1:
            $ daterp -= 5
            show red ew sweat at charcenter
            red "喂，喂！你在摸哪里？！"
            show red ew -sweat
        elif skinshiprespond == 2:
            show red bingung sweat at charcenter
            $ daterp -= 10
            red "注意界限，伙计！"
            show red bingung -sweat
        elif skinshiprespond == 3:
            show red kaget sweat at charcenter
            $ daterp -= 5
            red "怎么，你是在嫉妒还是怎么的？"
            show red kaget -sweat
    elif skinshiparea == "hair":
        play sound "audio/crack.mp3"
        $ hate = True
        #show screen dislikeresponse
        if skinshiprespond == 1:
            $ daterp -= 15
            show red growl frusta at charcenter
            red "喂，小心我的头发！"
            show red growl -frusta
        elif skinshiprespond == 2:
            show red frown sweat at charcenter
            $ daterp -= 5
            red "我的头发？怎么了？"
        elif skinshiprespond == 3:
            show red kzl frusta at charcenter
            $ daterp -= 10
            red "得了吧伙计，你知道我讨厌头发被弄乱！"
            show red kzl -frusta
    elif skinshiparea == "hand":
        #show screen loveresponse
        play sound "audio/success.mp3"
        $ lovely = True
        if skinshiprespond == 1:
            $ daterp += 5
            show red amused at charcenter
            red "击掌？什么？哦，你是在担心我的旧伤吗？"
            red wry "别担心，我的旧符文腐蚀已经痊愈了。毕竟是新学期了。"
        elif skinshiprespond == 2:
            $ daterp += 10
            show red kaget at charcenter
            red "击掌？什么？哦，你是在担心我的旧伤吗？"
            red amused "我会没事的，五个手指都还在。目前为止。"
        elif skinshiprespond == 3:

            $ daterp += 5
            show red amused at charcenter
            red "击掌？什么？哦，你是在担心我的旧伤吗？"
            red wry "你知道吸血鬼恢复得更快，对吧？你应该更担心你自己。"
    elif skinshiparea == "cheek":
        #show screen loveresponse
        play sound "audio/success.mp3"
        $ lovely = True
        if skinshiprespond == 1:
            $ daterp += 5
            show red amused at charcenter
            red "哦，你的手很暖和。"
            red wry "感觉不错。"
        elif skinshiprespond == 2:
            $ daterp += 10
            show red awkward at charcenter
            red "我的皮肤很光滑，不是吗？"
            red amused "这是因为我用的精灵防晒霜，虽然我拒绝使用那些顶级品牌的。"
            red "它们会让你闪耀得像个该死的迪斯科球。"
        elif skinshiprespond == 3:
            $ daterp += 5
            show red amused at charcenter
            red "嘿，别掐我！我不是菲亚！"
    elif skinshiparea == "arms":
        #show screen loveresponse
        if skinshiprespond == 1:
            play sound "audio/success.mp3"
            $ lovely = True
            $ daterp += 5
            show red wry at charcenter
            red "嗯？别闹了，快停下！"
        elif skinshiprespond == 2:
            $ daterp += 15
            play sound "audio/success.mp3"
            $ lovely = True
            show red wry at charcenter
            red "嘿，那很痒！"
        elif skinshiprespond == 3:
            play sound "audio/crack.mp3"
            $ hate = True
            $ daterp -= 15
            show red huh at charcenter
            red "哎哟，你刚才是掐我了吗？！"
    elif skinshiparea == "chest":
        #show screen loveresponse
        if skinshiprespond == 1:
            play sound "audio/crack.mp3"
            $ hate = True
            $ daterp -= 5
            show red amused at charcenter
            red "伙计...你为什么像奎尔那样摸我？"
            red "说真的，快停下。"
        elif skinshiprespond == 2:
            $ daterp += 10
            play sound "audio/success.mp3"
            $ lovely = True
            show red grin at charcenter
            red "不错吧？上次狩猎后我壮实了一点。"
        elif skinshiprespond == 3:
            play sound "audio/success.mp3"
            $ lovely = True
            $ daterp += 5
            show red amused at charcenter
            red "喜欢你看到的吗？"
    elif skinshiparea == "stomach":
        if skinshiprespond == 3:
            play sound "audio/success.mp3"
            $ lovely = True
            $ daterp += 5
            show red wry at charcenter
            red "我没有变胖，如果这是你在检查的话。"
        elif skinshiprespond == 2:
            $ daterp -= 10
            play sound "audio/crack.mp3"
            $ hate = True
            show red kzl at charcenter
            red "嘿，你为什么掐我？！"
        elif skinshiprespond == 1:
            play sound "audio/success.mp3"
            $ lovely = True
            $ daterp += 5
            show red awkward at charcenter
            red "嘿，那很痒！"
    elif skinshiparea == "elbow":
        if "day3" not in quil_events:
            show red cowo blush
            $ daterp += 70
            mc "你的手肘碰撞发出了很大的声响。"
            red "对，这就是我想要的！"
            $ hidedatingsystemcommand = True
            jump finishdate
        else:
            play sound "audio/success.mp3"
            $ lovely = True
            $ daterp += 5
            show red awkward at charcenter
            red "嘿，那很痒！"
    window hide
    return

#QUILL
label skinshipQuillresponse:
    hide screen skinshipQuill
    $ skinshiprespond = renpy.random.randint(1, 3)
    if skinshiparea == "crotch":
        play sound "audio/crack.mp3"
        $ hate = True
        #show screen dislikeresponse
        if skinshiprespond == 1:
            $ daterp -= 15
            show quil err sweat at charcenter
            quil shock "亲爱的，我可能是个美味，但请保持一些自制力！"
            show quil kzl -sweat -shock
        elif skinshiprespond == 2:
            show quil malu sweat frusta at charcenter
            $ daterp -= 10
            quil "好吧，我明白了，哈哈，我是个处男性感偶像，但是还是..." 
            quil kzl -sweat -frusta "说实话亲爱的，你不能因为我的形象就获得骚扰我的许可！"
        else:
            show quil ejek cling at charcenter
            $ daterp -= 5
            quil "嫉妒你没有这样的资本？"
            quil sulk sigh "管好你的手，亲爱的。"
            show quil frown -sigh
    elif skinshiparea == "hair":
        play sound "audio/success.mp3"
        $ lovely = True
        $ daterp += 20
        if skinshiprespond == 1:
            show quil laugh blush at charcenter
            quil bunga "美丽，对吧？蜂蜜和阿莫迪亚果，效果奇佳！"
            show quil datar -blush -bunga
        elif skinshiprespond == 2:
            show quil hister blush at charcenter
            quil bunga "要让我的头发达到如此完美真是不容易。"
            quil talk -blush -bunga "我想只有菲亚的头发能与如此美丽相媲美了。"
        else:
            show quil laugh at charcenter
            quil "又软又蓬松，对吧？来吧，把你的手指穿过去，好好享受。"
            quil talk "尽情享受没什么可羞耻的。"
    elif skinshiparea == "hand":
        #show screen loveresponse
        play sound "audio/success.mp3"
        $ lovely = True
        $ daterp += 10
        if skinshiprespond == 1:
            show quil amused at charcenter
            quil "想要拥抱吗？恐怕你只能满足于握我的手了，亲爱的？"
        elif skinshiprespond == 2:
            show quil laugh at charcenter
            quil "丝滑光滑。保湿霜对皮肤真是奇效，不是吗？"
            quil talk "虽然你的手实际上比大多数人的要柔软得多。也许是基因的缘故。"
        else:
            show quil amused at charcenter
            if girl:
                quil "你的手比我的小，真是可爱。"
            else:
                quil "如此大的手，你的手又长又有男子气概，这几乎是不公平的。"
                quil malu sigh "而我却被困在我的小婴儿手里。"
                show quil datar -sigh
    elif skinshiparea == "cheek":
        #show screen loveresponse
        play sound "audio/crack.mp3"
        $ hate = True
        $ daterp -= 25
        if skinshiprespond == 1:
            show quil err at charcenter
            quil sweat frusta "小心点！这个底妆花了我好几个小时！"
            show quil frown -sweat -frusta
        elif skinshiprespond == 2:
            show quil rajuk at charcenter
            quil sigh "有些男孩取笑我化妆。"
            quil ejek cling "没教养的蠢猪。"
            show quil datar -cling
        else:
            show quil amused at charcenter
            quil "亲爱的，虽然我很感谢你的关注，但这张脸是\'可看不可摸\'的展品。"
    elif skinshiparea == "arms":
        #show screen loveresponse
        play sound "audio/crack.mp3"
        $ hate = True
        $ daterp -= 5
        if skinshiprespond == 1:
            show quil err at charcenter
            quil "我相信其他男孩会欣赏你的触摸，[povname]..."
            quil sulk "但就我个人而言，我相信有一种叫做个人空间的东西。"
        elif skinshiprespond == 2:
            show quil sad at charcenter
            quil "不幸的是，我从来没有像塞恩或阿什姆那样形成鼓起肌肉的体型。"
            quil datar "我的脸才是卖点，而不是我的身体。"
        else:
            show quil tantrum at charcenter
            quil "轻点，你刚才是掐我吗？！"
    elif skinshiparea == "chest":
        #show screen loveresponse
        play sound "audio/success.mp3"
        $ lovely = True
        $ daterp += 5
        if skinshiprespond == 1:    
            show quil ejek at charcenter
            quil "嗯，通常我不喜欢这么亲密的触碰。"
            quil wry sigh "但我想，在你忍受了我让你经历的一切之后，这是我至少能做的。"
            show quil -sigh
        elif skinshiprespond == 2:
            show quil laugh at charcenter
            quil "我正试图让我的胸部看起来更大。"
            quil malu both "与塞恩和阿什姆相比，我开始对自己看起来如此瘦弱感到有点尴尬。"
            show quil datar -both

        else:
            show quil laugh at charcenter
            quil "亲爱的，你觉得我的锻炼计划终于有效果了吗？"
            quil talk "谢谢，我努力工作终于让自己变得这么强壮。"
    elif skinshiparea == "stomach":
        play sound "audio/crack.mp3"
        
        if skinshiprespond == 3:
            $ hate = True
            $ daterp -= 5
            show quil malu both at charcenter
            quil "亲爱的，我很感谢你的关注，但你不觉得这有点太直接了吗？"
            show quil datar -both
        elif skinshiprespond == 2:
            $ hate = True
            $ daterp -= 5
            show quil wry at charcenter
            quil "亲爱的，如果你在找腹肌，那很遗憾你找错人了。"
            quil laugh "瘦长却迷人是我的审美。"
            quil talk "如果你在找魁梧或壮实的，那你就找错树了。"
            show quil datar 
        else:
            play sound "audio/success.mp3"
            $ lovely = True
            $ daterp += 5
            show quil laugh blush at charcenter
            quil "我们不可能都有像你那样的腹肌，[povname]。"
            quil datar -blush "至少我有这张脸！"
    else:
        show quil rajuk sweat at charcenter
        quil "哎哟！轻点..."
        show quil frown -sweat
    window hide
    return

#Tom
label skinshipTomresponse:
    hide screen skinshipTom
    $ skinshiprespond = renpy.random.randint(1, 3)
    if skinshiparea == "crotch":
        play sound "audio/success.mp3"
        $ lovely = True
        $ daterp += 20
        #show screen dislikeresponse
        if skinshiprespond == 1:
            show tom amused at charcenter
            tom cling "我是说，如果你不说，我也不会提起，亲爱的。"
            show tom calm -cling
        elif skinshiprespond == 2:
            show tom ejek at charcenter
            tom cling "感觉有点兴奋，是吗？我很乐意帮忙，亲爱的。"
            show tom smile -cling
        else:
            show tom amused at charcenter
            tom "我们可以跳过前戏，直接去个私密的地方？"
            tom calm "我只是随口一说。"
    elif skinshiparea == "hair":
        play sound "audio/success.mp3"
        $ lovely = True
        $ daterp += 10
        if skinshiprespond == 1:
            show tom amused blush at charcenter
            tom "你喜欢吗？我花了几个小时才让自己看起来体面。"
            if calendar.weekday == "Sat" or calendar.weekday == "Sun":
                show side_p fr at pic
            else:
                show side_p f at pic
            mc "我喜欢，但即使你是秃头，有那张脸也依然很有魅力。"
            hide side_p
            tom giggle blush "啊，我想你把自己和我搞混了，[povname]。"
            tom smile -blush "只有你的美是永恒的。"
        elif skinshiprespond == 2:
            show tom calm at charcenter
            tom "尽情触摸吧。毕竟，这是我的王冠荣耀。"
        else:
            show tom smile at charcenter
            tom "你知道吗，我可以帮你剪头发。"
            tom calm "实际上我用剪刀很有天赋。"
            tom smile cling "而且当对象像你这么美丽时，就更容易了！"
            show tom -cling
    elif skinshiparea == "hand":
        #show screen loveresponse
        play sound "audio/success.mp3"
        $ lovely = True
        $ daterp += 20
        if skinshiprespond == 1:
            show tom calm at charcenter
            tom "嗯？你想牵手吗？"
            tom wry "好冷。来，让我帮你暖和起来。"

        elif skinshiprespond == 2:
            show tom wry at charcenter
            tom "[povname]，你的手冰凉。"
            tom amused cling "如果你愿意，我可以把它们夹在我的大腿之间暖和。"
            tom smile -cling "不过我想紧紧握住它们也可以。"
        else:
            show tom smile at charcenter
            tom "如果你愿意，我可以亲吻你的手来让它们保持温暖。"
            tom calm "那会更有效率。"
    elif skinshiparea == "cheek":
        #show screen loveresponse
        play sound "audio/success.mp3"
        $ lovely = True
        $ daterp += 10
        if skinshiprespond == 1:
            show tom calm at charcenter
            tom apa "嗯？"
            "你把手做成半碗状，阿什姆立即把下巴放在你的手掌中。"
            tom wry both "你为什么笑？我做错什么了吗？"
            show tom smile -both
        elif skinshiprespond == 2:
            show tom smile at charcenter
            "你用手比了一个心形，阿什姆把脸从洞里伸了出来，让你感到惊讶。"
            tom wry "我以为你想要那样。"
            tom calm "我还能怎么回应呢？"
        else:
            show tom calm at charcenter
            "你伸出手，掌心朝上。"
            "阿什姆立即用脸颊蹭了蹭你的手。"
            tom smile "你在呼唤我吗，[povname]？"
    elif skinshiparea == "arms":
        #show screen loveresponse
        play sound "audio/crack.mp3"
        $ hate = True
        $ daterp -= 5
        if skinshiprespond == 1:
            show tom capek shock at charcenter
            tom sweat "呃，抱歉，那里有点酸痛。"
            tom smile -sweat -shock "请暂时不要碰那里。"
        elif skinshiprespond == 2:
            show tom nyesal at charcenter
            tom "我的手臂因为射箭练习而酸痛。"
            tom sad "这是很好的锻炼，但也许我做得有点过头了。"
        else:
            show tom sad at charcenter
            tom "抱歉，你能不碰那里吗？我还因为射箭练习而酸痛。"
    elif skinshiparea == "chest":
        #show screen loveresponse
        play sound "audio/success.mp3"
        $ lovely = True
        $ daterp += 30
        if skinshiprespond == 1:    
            show tom calm blush at charcenter
            tom "你想摸哪里就摸哪里。"
            if "tom_conf" in tom_events:
                tom smile "不知为何，你的触摸让我平静下来。感觉...很安心。"
                show tom -blush
            else:
                tom cruel cling "没有什么是你没摸过的。"
                show tom smile -blush -cling
        elif skinshiprespond == 2:
            show tom smile at charcenter
            tom "你能感觉到我的心跳吗？"
            if "tom_conf" in tom_events:
                tom calm "注意到你的触摸是如何让它平静下来的。"
                
            else:
                tom giggle "注意到你是如何让我兴奋的。"

        else:
            show tom calm at charcenter
            tom "我喜欢你摸我那里。"
    elif skinshiparea == "stomach":
        play sound "audio/crack.mp3"
        $ daterp -= 15
        $ hate = True
        if skinshiprespond == 3:
            show tom sad sweat at charcenter
            tom "啊，我不太喜欢被摸那里。"
            tom capek -sweat "我不是狗，别揉我的肚子！"
        elif skinshiprespond == 2:
            show tom capek at charcenter
            tom "不知为什么，被揉肚子总让我感觉有点被贬低。"
            show tom frown
        else:
            show tom sad at charcenter
            tom "我不是小狗，别那样揉我的肚子！"
            show tom frown 
    else:
        play sound "audio/success.mp3"
        $ lovely = True
        $ daterp += 5
        show tom smile at charcenter
        tom "有什么问题吗？"
    window hide
    return

#Lyall
label skinshipLyallresponse:
    hide screen skinshipLyall
    $ skinshiprespond = renpy.random.randint(1, 3)
    if skinshiparea == "crotch":
        play sound "audio/success.mp3"
        $ lovely = True
        $ daterp += 5
        #show screen dislikeresponse
        if skinshiprespond == 1:
            show buff wry at charcenter
            buff "我的大腿？它们还好。"
            buff datar "维尔科娃女士说，如果我决定离开伊格尼亚，我有机会成为田径明星。"
            
        elif skinshiprespond == 2:
            show buff laugh at charcenter
            buff "派克说我的腿很有力，孩子们和我有时会一起在水里比赛。"

        else:
            show buff wry at charcenter
            buff "我的腿？阿什姆先生说它们相当令人印象深刻。"
            buff "我们甚至一起进行了一场比赛。"
            buff laugh "我不确定他是否让着我，但我很高兴他没有低估我。"
    elif skinshiparea == "hair":
        play sound "audio/success.mp3"
        $ lovely = True
        $ daterp += 20
        if skinshiprespond == 1:
            show buff hister blush at charcenter
            buff shock "哦！"
            buff datar bloom "感觉很好。"
            show buff -blush -bloom
        elif skinshiprespond == 2:
            show buff lega at charcenter
            buff blush "摸头？小心点，你能从那里够到我吗？"
            buff hister blush bunga "等-等一下，我跪下来让你摸。"
            show buff datar -blush -bunga
        else:
            show buff laugh at charcenter
            buff "啊哈，我现在知道为什么猫喜欢被摸头了。"
            show buff datar
    elif skinshiparea == "hand":
        #show screen loveresponse
        play sound "audio/success.mp3"
        $ lovely = True
        $ daterp += 15
        if skinshiprespond == 1:
            show buff wry blush at charcenter
            buff shock "哦！"
            buff hister apa "你的手很温暖。"
            show buff datar -blush -apa
        elif skinshiprespond == 2:
            show buff laugh at charcenter
            buff "派克说，以我钓鱼的频率，我很快就会有一双渔夫的手了。"
            buff datar "我很期待！"
        else:
            show buff laugh blush bloom at charcenter
            buff "你的手真小，真软，[povname]。"
            buff datar -blush -bloom "很可爱。"
    elif skinshiparea == "cheek":
        #show screen loveresponse
        play sound "audio/success.mp3"
        $ lovely = True
        $ daterp += 10
        if skinshiprespond == 1:
            show buff laugh at charcenter
            buff "我觉得自从来到这里，我好像胖了一点。"
            buff datar "不过我不介意，学校提供的美食这么多，很难不增重。"
            
        elif skinshiprespond == 2:
            show buff laugh at charcenter
            buff "你的脸这么瘦，[povname]，你吃得好吗？"
            buff sad both shock "啊！我不是有什么不好的意思。"
            buff laugh -both -shock "我只是惊讶于你能在学校提供这么多食物的情况下保持不增重！"
        else:
            show buff laugh at charcenter
            buff "以前只有伊尔夫会这样触摸我。"
            buff talk "这种感觉总是这么好吗？"
            show buff datar
    elif skinshiparea == "arms":
        #show screen loveresponse
        play sound "audio/success.mp3"
        $ lovely = True
        $ daterp += 10
        if skinshiprespond == 1:
            show buff hister at charcenter
            buff both "我正在试图说服学校提供更大号的衬衫。"
            buff wry  -both "我不确定我的衣柜能否撑到毕业。"
            buff datar "我总是在手臂和胸部区域撕破衬衫。"
        else:
            show buff laugh at charcenter
            buff "袖子有点紧，但至少比起扣子的情况要好一些。"
            buff sad "胸部周围的扣子总是崩开，所以我再也不扣它们了。"
    elif skinshiparea == "chest":
        #show screen loveresponse
        if skinshiprespond == 1:    
            show buff hister at charcenter
            buff both "有时候当我去戈莫拉时，年长的女士们会试图遮住我的胸部或重新缝上我的扣子。"
            buff wry "有一次，她刚缝好的纽扣突然弹了出来，正好打在她的眼睛上。"
            buff laugh -both "不过，她只是笑了笑。"
        elif skinshiprespond == 2:
            show buff laugh at charcenter
            buff "嗯？你想试试帮我缝纽扣吗？来吧。"
            buff wry "不过我得警告你，很多人都试过，但都失败了。"

        else:
            show buff laugh at charcenter
            buff "我试着缝纽扣，但没有成功。"
            buff datar "哦，好吧。"
    elif skinshiparea == "stomach":
        play sound "audio/success.mp3"
        $ lovely = True
        $ daterp += 20
        if skinshiprespond == 3:
            show buff laugh at charcenter
            buff "啊哈哈，好痒！"
        elif skinshiprespond == 2:
            show buff wry at charcenter
            buff blush "我想我现在明白为什么狗狗喜欢被摸肚子了。"
            buff hister both "啊，我猜这听起来有点奇怪，是吧？"
            show buff datar -both
        else:
            show buff hister at charcenter
            buff "啊哈，你是在嫉妒吗？这些腹肌可不是天生的。"
            buff wry "好吧，严格来说它们确实是天生的，因为我生来就有，但是呃——嗯。你明白我的意思。"
    else:
        play sound "audio/success.mp3"
        $ lovely = True
        $ daterp += 5
        show buff datar at charcenter
        buff "诶——诶？[povname]，你需要什么吗？"
    window hide
    return
