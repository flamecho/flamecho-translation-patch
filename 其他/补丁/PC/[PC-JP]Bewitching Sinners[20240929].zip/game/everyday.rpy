
label morning:
    stop music
    $ calendar.next() 
    $ night = False
    $ evening = False
    $ afternoon = False
    $ morning = True
    if curiosity <0:
        $ curiosity = 0
    elif curiosity >100:
        $ curiosity = 100
    if honesty <0:
        $ honesty = 0
    elif honesty >100:
        $ honesty = 100
    if kindness <0:
        $ kindness = 0
    elif kindness >100:
        $ kindness = 100 
    if ibu.points <0:
        $ ibu.points = 0
    elif ibu.points > 100:
        $ ibu.points = 100
    if mrh.points <0:
        $ mrh.points = 0
    elif mrh.points > 100:
        $ mrh.points = 100
    if putri.points <0:
        $ putri.points = 0
    elif putri.points > 100:
        $ putri.points = 100
    if bff.points <0:
        $ bff.points = 0
    elif bff.points > 100:
        $ bff.points = 100
    if calendar.day == 18 and calendar.month == '/05': #KAMIS
        play sound "sound/effects/cloth.mp3"
        scene bed_pagi with dissolve
        show side_p he at pic
        mc "人类和巫师试图成为神的坟墓？她在说什么？"
        hide side_p
        play sound "audio/success.mp3"
        $ topics.append("tomb")
        "新话题：{color=#FF1500}神之墓。{/color}"
        "也许图书馆有相关资料？"
        play sound "sound/effects/278160__sirrealist2__vibrate.mp3"
        show side_p he at pic
        mc "嗯？这么早谁会给我发短信？"
        hide side_p
        stop sound
        $ my_events.append("day4")
        play music "MUSIC/MusMus-BGM-024.mp3"
        
        $ interlocutor = "Quill"
        $ del_all_msg()
        hide window
        show hp at move_messenger2
        pause 1.0
        $ show_messenger()
        $ msg ("可怕的日子终于来临了。", who=1, status='online')
        $ msg ("又怎么了，你这个戏精？")
        $ msg ("维尔科娃女士的防御课。我们三个都一起上这节课。", who=1)
        $ msg ("我知道她会让你和阿什姆搭档，然后\'给全班做示范\'。", who=1)
        $ msg ("她总是这样。", who=1)
        $ msg ("我会给你发你需要用来生存的符文图片。", who=1)
        if not check_inv_for(ink_items):
            $ msg ("但我现在身上没带墨水。")
            $ msg ("看在科尔的份上，给你！", who=1)
            "奎尔通过你的手机给你发了一小瓶墨水。你仍然觉得这种做法很奇怪。"

        $ msg ("每个符文都有不同的用途。", who=1)
        $ msg ("我们今天在射箭场学习，所以我猜我们要进行远程战斗。", who=1)
        $ msg ("对你来说是件好事，除非你真的打过拳击？", who=1)
        $ msg ("", choices={0:{'jump':'fist_yes', 'name':"我打过，一两次吧。"}, 1:{'jump':'bar_live', 'name':"相信我，我知道怎么打架。酒吧斗殴可是相当激烈的。"},2:{'jump':'fist_nope', 'name':"没有，但是……"}})
    elif calendar.day == 19 and calendar.month == '/05': #JUMAT
        scene bed_pagi with dissolve
        $ red_events.append("jumat")
        play music "MUSIC/MusMus-BGM-006.mp3"
        if "blood1" in active_quests and "help_study" not in tom_events:
            $ active_quests.remove("blood1")
            "你听到你的手机在嗡嗡作响。"
            "你以为是奎尔，但结果是塞恩。"
            "他告诉你他已经从阿什姆那里得到了一瓶血液，所以现在不需要你的了。"
            "他让你把它留到以后用。"
            show side_p f at pic
            mc "好吧，至少少了一件要担心的事。"
            hide side_p
            show screen completedtask("任务失败！")
            "当你从床上起来时，你听到门上传来轻轻的敲门声。"
        play sound "sound/effects/window_knock.mp3"
        tom "[povname]?"
        show side_p f at pic
        mc "阿什姆？请进。"
        hide side_p
        scene kmr_pagi with dissolve
        show tom chill frown at right with moveinright:
            yoffset 190
        if girl:
            show palmierproxy chill frown at left with moveinleft:
                yoffset 40
        else:
            show palmierproxy chill frown at left with moveinleft:
                yoffset 100
        tom apa "菲亚和你在一起吗？"
        mc confused tanya "没有。怎么了？"
        show palmierproxy frown shock
        tom talk sigh blow "我需要和她谈谈，但我在她房间里找不到她。"
        mc scratch apa tanya "嗯？"
        tom frown apa "你知道她去哪里了吗？"
        mc chill kzl frusta "等等，你去了她的房间？为什么？"
        tom hip ha -apa "那是私事。"
        mc grit "我是她的[kk]。你还在她房间里做了什么？你和她单独在一起吗？"
        show palmierproxy confused sigh
        tom pfft talk "如果你担心的是这个，我没有对她做任何不恰当的事。"
        tom calm blow "别担心，你仍然是我最喜欢的贝克，[povname]。"
        tom wry cling "……顺便说一句，你今天看起来很漂亮。"
        show palmierproxy frown -sigh
        show pboy at horzappear
        menu:
            "谢谢，我想？":
                hide pboy
                show tom hip kzl sweat
                mc pissed frusta "谢谢，但别转移话题。"
                mc grit sigh "下次未经我允许，不要进入我妹妹的房间。"
                mc kzl -sigh"她是个成年人，但她仍然是我的小妹妹！"
                tom capek blow "我记住了。"
                "阿什姆带着怒容离开了你的房间。"
            "出去。":
                hide pboy
                $ ibu.points -= 2
                if ibu.points <0:
                    $ ibu.points = 0
                $ kindness -= 10
                if kindness < 0:
                    $ kindness = 0
                mc kzl "从我房间出去，阿什姆。也别靠近我妹妹的房间！"
                tom sigh blow hip "如你所愿。"
            "只是今天？":
                hide pboy
                $ honesty += 5
                $ ibu.points += 2
                show palmierproxy kind blush tanya
                tom scold smile bunga "你知道在我眼里你总是很好看，亲爱的。"
                mc huh sigh "好了，罗密欧。你现在可以出去了。"
                tom pfft "亲爱的，别问那些你不想听到答案的问题。课堂上见。"
        play sound "sound/effects/door.mp3"
        scene kmr_pagi with dissolve
        show side_p f at pic
        mc "嗯，我在想菲亚可能在哪里。如果她和我认识的菲亚一样的话，那她早上准备起来应该要花很长时间。"
        show side_p s
        mc "她是不是有早课？"
        hide side_p
        "你担心地决定出门去找菲亚。她可能还在宿舍某个地方，对吧？"
        $ morning = True
        $ night = False
        $ evening = False
        scene bg_black with w20
        jump fia_wc
    elif calendar.day == 20 and calendar.month == '/05': #SAbtu W1
        play sound "sound/effects/knock.mp3"
        $ tom_events.append("sabtu")
        scene kmr_pagi with dissolve
        "当你洗完澡时，听到门外传来一阵响亮的敲门声。"
        play music "MUSIC/MusMus-BGM-032.mp3"
        play sound "sound/effects/door.mp3"
        show side_p fr at pic
        mc "是谁？"
        hide side_p
        show tom go frown at right with moveinright:
            yoffset 190
        if girl:
            show palmierproxy jln frown at left with moveinleft:
                yoffset 40
        else:
            show palmierproxy jln frown at left with moveinleft:
                yoffset 100
        mc tanya "阿什姆？"
        show palmierproxy confused shock
        tom wry apa "你今天愿意和我出去吗？"
        show tom smile -apa
        mc wry -shock "什么？"
        tom amused "通往戈莫拉的大门已经打开了。我希望你能考虑和我一起度过今天。"
        tom wry blush "约会。"
        show pboy s at horzappear
        menu:
            "很乐意。":
                hide pboy
                tom lega blow "我很高兴。"
                $ ibu.points += 20
                show tom smile -blow
                "阿什姆微笑着环顾了一下房间。他注意到莱尔正在床上学习。"
                hide palmierproxy with dissolve
                show buff bebas eh shock at left with moveinleft:
                    yoffset 770
                    xzoom -1.0
                tom pfft -blush -blow "莱尔，虽然你的勤奋值得称赞，但你也应该给自己一些休息时间。"
                buff hister -shock "哦，呃，阿什姆先生，你好。"
                show buff wry
                tom calm "你好。这周过得怎么样？"
                tom ejek cling "记住，如果有人对你耍什么花招，你随时可以来找我。"
                tom pfft "说到纪律，我发现酷刑比向老师报告更有效。"
                buff laugh blush "哈哈，阿什姆先生真幽默。"
                show buff datar
                show tom calm
                show side_p mal at pic
                mc "（哦，我觉得那不是在开玩笑，莱尔。）"
                show side_p ha
                mc "那么，呃，你要带我去哪里？因为我这周的预算有点紧张。"
                hide side_p
                tom amused cling "别担心，亲爱的，我会照顾你的。你不会缺任何东西。"
                stop music
                scene bg_black with w20
                jump arshy_date1



            "不如算了吧？":
                hide pboy
                $ ibu.points -= 10
                if ibu.points <0:
                    $ ibu.points = 0
                show tom kzl -blush shock
                mc deject sigh "听着阿什姆，你是个帅哥，但是不行。现在还太早，我受不了这种事。"
                show tom sad -shock
                mc hister sweat -sigh "再说了，我们是前任，就这样吧，好吗？"
                mc panik "（我已经很难维持我的伪装了。）"
                mc rajuk sigh "（我不确定我能否在和一个眼睛像紫水晶一样的漂亮男孩约会的同时继续保持这种表演。）"
                show palmierproxy frown -sigh
                "当你试图关门时，阿什姆抓住门把手，强行把门重新打开。"
                tom sigh blow"我在试图赢得你的心，[povname]。"
                if "sucker3" not in completed_quests:
                    tom pfft cling "但如果必要的话，我不介意偷走它。"
                    tom smile -cling "你还欠我一个人情，记得我们的那个赌约吗？"
                    mc apa tanya "你要把它用在这上面？有点浪费，不是吗？"
                    show palmierproxy confused -tanya
                    tom lega blow "能有机会和你共度一整天，这怎么会是浪费呢，亲爱的。"
                    show tom smile
                    mc malu sigh blush "...好吧。但你得付钱。"
                    tom giggle bunga "当然。"
                    stop music
                    scene bg_black with w20
                    jump arshy_date1
                else:
                    show tom sad -blow
                    mc sad "（而且我不是你的[povname]。）"
                    mc side "（阿什姆可能是个善于操纵、两面三刀的混蛋，但我知道他全心全意地爱着[povname]。）"
                    mc ow sweat "（我不能利用他的这份爱，那样做是不对的。）"
                    mc hister "听着，现在可能看起来很残酷，但我发誓我是在帮你，好吗阿什姆？"
                    show palmierproxy sad shock
                    tom sigh frusta "什么样的帮助需要你把我推开？"
                    show tom sad -frusta
                    mc side -shock "那种能让你的心不会比现在更碎的帮助。"
                    tom frown blow "...好吧，谢谢你迁就我。原谅我的打扰，[povname]。"
                    mc wry "再见。"
                    play sound "sound/effects/door.mp3"
                    scene kmr_pagi with dissolve
                    show side_p sdh at pic
                    mc "哈啊..."
                    hide side_p
                    "莱尔听到你的叹息，走近你。"
                    show buff bebas eh apa at center with dissolve:
                        yoffset 770
                    buff "我知道这不关我的事，但是..."
                    buff keluh -apa "他似乎真的很喜欢你，你知道吗？阿什姆先生。"
                    buff lega "而且他对我一直很好，这说明了很多关于他的事，考虑到其他人是怎么对待我的。"
                    show side_p sdh at pic
                    mc "这很复杂，莱尔。就像，你根本不知道事情的全貌。"
                    hide side_p
                    buff frown "我明白了。如果我越界了，我很抱歉。"
                    show side_p fr at pic
                    mc "没关系。顺便说一句..."
                    hide side_p
                    show pboy s at horzappear
                    menu pag_cek:
                        "你想出去玩吗？":
                            hide pboy
                            buff huh sweat shock "和我一起？"
                            show buff frown -shock 
                            show side_p ha at pic
                            mc "是啊，你不用看起来那么震惊。"
                            hide side_p
                            buff wry -sweat "哦，啊...嗯，我不能。"
                            buff hister "我今天要整天和派克一起工作。还要在孤儿院帮助玛格丽特。"
                            if "buff_kerja" in buff_events:
                                show side_p fr at pic
                                mc "玛格丽特？"
                                hide side_p
                            elif not "met_pike" in my_events:
                                show side_p fr at pic
                                mc "派克是谁？"
                                hide side_p
                                $ buff_events.append("buff_kerja")
                                buff talk "他是来自莱纳尔的渔夫，莱纳尔是这里南边的一个小渔村。"
                                buff wry "他有时会在这里钓鱼。我偶然遇到他，他邀请我去给他做兼职。"
                                buff laugh "他人很好。"
                                buff datar "实际上，莱纳尔的每个人都很好。没有人对我的眼睛发表评论。"
                                buff "那是一个与世隔绝的岛屿，所以他们对巫师的了解不如大多数人那么多。"
                                show side_p fr at pic
                                mc "我明白了，那玛格丽特呢？"
                                hide side_p

                            else:
                                $ buff_events.append("buff_kerja")
                                show side_p he at pic
                                mc "等等，你认识派克？"
                                hide side_p
                                buff hister "是的，我偶然遇到他，他邀请我去给他做兼职。"
                                show side_p se at pic
                                mc "哦。那玛格丽特是谁？"
                                hide side_p
                            buff datar "派克的大女儿。她在莱纳尔的孤儿院工作。"
                            buff sad "那里有很多孩子，但资源很少。"
                            buff wry "孩子们在小岛上没什么事可做，所以我去和他们玩。"
                            buff laugh "我还帮忙喂养和清洁年幼的孩子。"
                            show side_p ha at pic
                            mc "哇，看起来你融入得很好嘛！"
                            hide side_p
                            buff touched "是的。孩子们和村民们并不真正了解巫师或伊瓦尔。"
                            buff lega "他们让我感觉...很正常。"
                            show side_p ha at pic
                            mc "听到这个我很高兴。那么，玩得开心。"
                            hide side_p
                            show buff lega 
                            "莱尔点点头，走出了房间。"
                            
                        "今天有什么计划吗？":
                            hide pboy
                            buff laugh "哦，我今天要整天和派克一起工作。还要在孤儿院帮助玛格丽特。"
                            if "buff_kerja" in buff_events:
                                show side_p fr at pic
                                mc "玛格丽特？"
                                hide side_p
                            elif not "met_pike" in my_events:
                                show side_p fr at pic
                                mc "派克是谁？"
                                hide side_p
                                $ buff_events.append("buff_kerja")
                                buff talk "他是来自莱纳尔的渔夫，莱纳尔是这里南边的一个小渔村。"
                                buff wry "他有时会在这里钓鱼。我偶然遇到他，他邀请我去给他做兼职。"
                                buff laugh "他人很好。"
                                buff datar "实际上，莱纳尔的每个人都很好。没有人对我的眼睛发表评论。"
                                buff "那是一个与世隔绝的岛屿，所以他们对巫师的了解不如大多数人那么多。"
                                show side_p fr at pic
                                mc "我明白了，那玛格丽特呢？"
                                hide side_p

                            else:
                                $ buff_events.append("buff_kerja")
                                show side_p fr at pic
                                mc "等等，你认识派克？"
                                hide side_p
                                buff hister "是的，我偶然遇到他。他邀请我去给他做兼职。"
                                show side_p se at pic
                                mc "哦。那玛格丽特是谁？"
                                hide side_p
                            buff datar "派克的大女儿。她在莱纳尔的孤儿院工作。"
                            buff sad "那里有很多孩子，但资源很少。"
                            buff wry "孩子们在小岛上没什么事可做，所以我去和他们玩。"
                            buff laugh "我还帮忙喂养和清洁年幼的孩子。"
                            show side_p ha at pic
                            mc "哇，看起来你融入得很好嘛！"
                            hide side_p
                            buff touched "是的。孩子们和村民们并不真正了解巫师或伊瓦尔。"
                            buff lega "他们让我感觉...很正常。"
                            show side_p ha at pic
                            mc "听到这个我很高兴。那么，玩得开心。"
                            hide side_p
                            show buff lega 
                            "莱尔点点头，走出了房间。"
                            
                        "{s}给信{/s}" if not check_inv_for(ylf_items):
                            jump pag_cek
                        "给信" if check_inv_for(ylf_items):
                            hide pboy
                            play sound "sound/effects/crumple.mp3"
                            show side_p ha at pic
                            mc "我有东西要给你。"
                            hide side_p
                            buff apa "是-是吗？"
                            show side_p ha at pic
                            mc "一封来自伊尔夫的信。"
                            hide side_p
                            buff eh sweat shock "一封来自伊尔夫的信，怎么可能？！"
                            show side_p ha at pic
                            mc "我在梦中又遇到了伊瓦尔，在伊瓦尔抓到我之前设法和伊尔夫说了话。"
                            mc "他让我把这个给你。"
                            hide side_p
                            buff laugh blush bloom "这...这太棒了！谢谢你，谢谢你！"
                            play sound "sound/effects/cloth.mp3"
                            "莱尔毫无预警地把你拉进一个紧紧的熊抱中。"
                            if girl:
                                "你的脸正好贴在他柔软却结实的胸膛上。"
                            else:
                                "他的头发擦过你的脸颊。你能闻到他身上松木香水的味道。"
                            show side_p ha at pic
                            mc "哇-哇，冷静点伙计！我喜欢背部按摩，但是——"
                            hide side_p
                            buff sad shock "哦，我非常抱歉！"
                            $ putri.points += 30
                            buff wry sigh "谢谢你，我是真心的。"
                            buff datar -sigh "嗯，我现在要私下阅读这封信。再次感谢你，[povname]。"
                            buff wry "看来我之前误会你了。"
                            buff hister "如果你有空的话，愿意和我一起去派克的村子吗？"
                            buff datar "哦，当然只有在你愿意的情况下！"
                            show side_p ha at pic
                            mc "我很乐意。"
                            hide side_p
                            buff laugh bunga "很好。"
                            buff wry "再见[povname]！"
                            $ buff_events.append("surat")
                            $ InvItem(*item_ylf).toss(1)
                scene kmr_pagi with dissolve
                play sound "sound/effects/door.mp3"
                "你看了看手机，发现没有来自奎尔的消息，这意味着今天你要独自行动了。"
                "你决定去戈莫拉看看那里到底是什么样子。"
                stop music
                scene bg_black with w20
                play music "MUSIC/MusMus-BGM-142.mp3"
                scene town_peta with w20
                jump town_map
                    
    elif calendar.day == 21 and calendar.month == '/05': #Minggu
        play sound "sound/effects/cloth.mp3"
        pause 1.0
        scene bed_pagi with eye_open
        "今天是个重要的日子。你决定和奎尔一起做准备，等到日落时分。"
        $ morning = False
        $ afternoon = False
        $ evening = True
        $ night = False
        scene bg_black with w20
        jump meet_meyza
    elif calendar.day == 22 and calendar.month == '/05': #Senin W2
        play sound "sound/effects/cloth.mp3"
        pause 1.0
        scene bed_pagi with eye_open
        "你查看了手机，现在还是清晨。你赶上了未读的短信，得知男孩们今晚会聚在一起，提前做好了计划。"
        play music "MUSIC/MusMus-BGM-112.mp3"
        $ password = ""
        if "diari1" in active_quests:
            "除此之外，你在你的替身的手机上进行的小探索让你发现了一个看起来像日记应用的东西。"
            "它需要输入密码。"
            if "password" in my_events:
                play sound "sfx/btn16.mp3"
                "你输入了\'Licorice\'，文件夹立即打开了，显示出三条日志记录。"
                "每一条都需要另一个密码才能阅读。"
                "你决定先试着阅读最早的日志条目。密码提示是\'梅扎给你的昵称，不带空格\'。"
                python:
                    password = renpy.input("密码是什么？（区分大小写）", length=16)
                    password = password.strip()
                if password == "LittleDemon":
                    play sound "sfx/btn16.mp3"
                    "日记内容如下..."
                    $ NPC = "日记"
                    npc "阿什姆昨天向我求婚了。他的时机真是再糟糕不过了。"
                    npc "我们躺在床上，我像往常一样在做爱后抚摸他的头发，他选择在那个时候脱口而出说他想娶我。"
                    npc "诚然，他承认这是个意外，但还是尴尬得要命。尤其是因为我早就知道他要这么做了。"
                    npc "我在他的内衣柜里发现了刻有字的戒指。老实说，就连塞恩都能把这两件事联系起来。"
                    npc "...我应该心存感激的。与我认识的大多数男人相比，阿什姆是最出色的。当然，他的混血基因在某些人看来可能有问题，但我从来不在乎这些事。"
                    npc "那么，为什么我不开心呢？相反，我感到...内疚。也许菲亚说得对，我终于在这么多年后长出了一颗心。"
                    npc "我想即使我想接受他的求婚，现在也不能了。"
                    npc "\'嗯，我差点杀了他，所以我可以永远奴役他\'这样的灵魂伴侣相遇故事现在听起来一点也不浪漫，不是吗？"
                    npc "我为此责怪科尔。她，还有那些善良和宽恕的言论。真的有点太过了。或者也许是我在她的墓穴里待得太久了。"
                    npc "那里的每个人是不是都被施了魔法变成无私的殉道者？圣科尔和她背负的所有罪孽。"
                    npc "我有一部分希望她像梅扎一样。容易上当，痴迷，易于理解。但当然，她必须是完全相反的。"
                    npc "说到梅扎，她一直让我去她的俱乐部。如果她不那么精神病的话，当然可以。但即使是我也能认出一个疯狂的跟踪狂。"
                    npc "她曾经叫我小恶魔。我同意这一点。我是个恶魔...但我想一个天使已经来帮助我忏悔了。"
                    "日记到此结束。"
                    show side_p f at pic
                    mc "为什么听起来[povname]好像见过科尔？这不可能，对吧？"
                    mc "科尔是个神，或者至少被当作神来崇拜，而且迪特里希说她已经死了一段时间了。那么[povname]怎么可能和他们交谈呢？"
                    mc "除非是在更精神层面上的\'交谈\'，但我觉得也不是这样。还有我一直听说的这个墓穴在哪里？"
                    hide side_p
                    

                    

                else:
                    play sound "sound/effects/278160__sirrealist2__vibrate.mp3"
                    "你的手机震动了一下，删除了所有的日志条目。显然，一次已经是太多的错误了。"
                    stop sound
                    $ active_quests.remove("diari1")
                    show screen completedtask("任务失败")
                    show side_p s at pic
                    mc "该死！"
                    hide side_p


            else:
                "你要猜吗？如果失败可能会被锁定。"
                show pboy at horzappear
                menu:
                    "猜":
                        hide pboy
                        python:
                            password = renpy.input("密码是什么？（区分大小写）", length=16)
                            password = password.strip()
                            
                        if password == "Licorice":
                            play sound "sfx/btn16.mp3"
                            $ my_events.append("password")
                            "你输入了\'Licorice\'，文件夹立即打开了，显示出三条日志记录。"
                            "每一条都需要另一个密码才能阅读。"
                            "你决定先试着阅读最早的日志条目。密码提示是\'梅扎给你的昵称，不带空格\'。"
                            
                            python:
                                password = renpy.input("密码是什么？（区分大小写）", length=16)
                                password = password.strip()
                            if password == "LittleDemon":
                                $ my_events.append("diary_read_1")
                                play sound "sfx/btn16.mp3"
                                "日记内容如下..."
                                $ NPC = "日记"
                                npc "阿什姆昨天向我求婚了。他的时机真是再糟糕不过了。"
                                npc "我们躺在床上，我像往常一样在做爱后抚摸他的头发，他选择在那个时候脱口而出说他想娶我。"
                                npc "诚然，他承认这是个意外，但还是尴尬得要命。尤其是因为我早就知道他要这么做了。"
                                npc "我在他的内衣抽屉里发现了刻有字的戒指。就连塞恩都能把这两件事联系起来。"
                                npc "...我应该高兴的。与我认识的大多数男人相比，阿什姆是最出色的。当然，他的混血基因在某些人看来可能有问题，但我从来不在乎这些事。"
                                npc "那么，为什么我不开心呢？相反，我感到...内疚。也许菲亚说得对，我终于在这么多年后长出了一颗心。"
                                npc "我想即使我想接受他的求婚，现在也不能了。"
                                npc "\'嗯，我差点杀了他，所以我可以永远奴役他\'这样的灵魂伴侣相遇故事现在听起来一点也不浪漫，不是吗？"
                                npc "我为此责怪科尔。她，还有那些善良和宽恕的言论。真的有点太过了。或者也许是我在她的墓穴里待得太久了。"
                                npc "那里的每个人是不是都被施了魔法变成无私的殉道者？圣科尔和她背负的所有罪孽。"
                                npc "我有一部分希望她像梅扎一样。容易上当，痴迷，易于理解。但当然，她必须是完全相反的。"
                                npc "说到梅扎，她一直让我去她的俱乐部。如果她不那么精神病的话，当然可以。但即使是我也能认出一个疯狂的跟踪狂。"
                                npc "她曾经叫我小恶魔。我同意这一点。我是个恶魔...但我想一个天使已经来帮助我忏悔了。"
                                "日记到此结束。"
                                show side_p f at pic
                                mc "为什么听起来[povname]好像见过科尔？这不可能，对吧？"
                                mc "科尔是个神，或者至少被当作神来崇拜，而且迪特里希说她已经死了一段时间了。那么[povname]怎么可能和他们交谈呢？"
                                mc "除非是在更精神层面上的\'交谈\'，但我觉得也不是这样。还有我一直听说的这个墓穴在哪里？"
                                hide side_p
                                

                                

                            else:
                                play sound "sound/effects/278160__sirrealist2__vibrate.mp3"
                                "你的手机震动了一下，删除了所有的日志条目。显然，一次已经是太多的错误了。"
                                stop sound
                                $ active_quests.remove("diari1")
                                show screen completedtask("任务失败")
                                show side_p s at pic
                                mc "该死！"
                                hide side_p
                            
                        else:
                            play sound "sound/effects/278160__sirrealist2__vibrate.mp3"
                            "你的手机震动了一下，删除了所有的日志条目。显然，一次已经是太多的错误了。"
                            stop sound
                            $ active_quests.remove("diari1")
                            show screen completedtask("任务失败")
                            show side_p s at pic
                            mc "该死！"
                            hide side_p
                    "算了。":
                        hide pboy
                        "你决定先试着找到密码，一定有人知道。"
                        "也许是个同学？"
            "带着比答案更多的问题，你决定为这一天做准备。"
        else:
            "你决定慢慢地为这一天做准备。"
        $ NPC = "???"
        "不仅是为了上课，也是为了面对阿什姆。这场闹剧已经持续得够久了，你打算告诉他真相。"
        "不仅是关于你，也是关于[povname]所做的。他至少应该得到那样的对待。"
        "你只是希望他不会对你发火。"
        scene bg_black with w20
        scene kls_potion with w20
        jump poppy1
    elif calendar.day == 23 and calendar.month == '/05': #Selasa W2
        play sound "sound/effects/cloth.mp3"
        scene bed_pagi with dissolve
        $ interlocutor = "Quill"
        $ del_all_msg()
        hide window
        show hp at move_messenger2
        pause 1.0
        $ show_messenger()
        $ msg ("我这边一切都准备好了。", who=1, status='online')
        $ msg ("希望你也会准备好。", who=1)
        $ msg ("我需要做什么准备吗？")
        $ msg ("今晚早点回宿舍就行。我会帮忙画好所有必要的符文。", who=1)
        $ msg ("除此之外，尽量享受今天吧。", who=1)
        $ msg ("谁知道呢？这可能是你的最后一天了。", who=1)
        $ hide_messenger()
        hide hp
        show hp2 at move_messenger3
        pause 1.0
        show side_p f at pic
        mc "享受自己，是吗？你说起来倒容易。"
        hide side_p
        show buff skul frown at center with dissolve:
            yoffset 770
        play sound "sound/effects/walk.mp3"
        buff eh apa "[povname]，你说什么了吗？"
        show buff frown -apa
        stop sound
        play music "MUSIC/MusMus-BGM-016.mp3"
        show side_p a at pic
        mc "哦，莱尔，你还在这啊。今天没课吗？"
        hide side_p
        buff talk "我运气不错，今天全是晚上的课。战斗和天文学。"
        show buff wry
        show side_p he at pic
        mc "嗯。"
        hide side_p
        show pboy at horzappear
        menu:
            "想一起出去玩吗？" if "rooted" not in buff_events:
                hide pboy
                buff keluh shock "你想和我...一起出去玩？"
                show buff frown
                show side_p a at pic
                mc "不用那么惊讶。"
                show side_p s
                mc "（在今晚之前我可以放松一下。面对梅扎...我不知道会发生什么。）"
                hide side_p
                buff lega blush sigh "嗯，我想我可以。不过只能到午饭时间。我答应了要帮派克准备水母节。"
                buff wry -sigh "显然镇上想从他的村子里获得所有的食物供应。"
                show side_p a at pic
                mc "我们不会耽误太久的。来吧！"
                hide side_p
                buff hister both shock "啊，等等！"
                play sound "sound/effects/cloth.mp3"
                hide buff with dissolve
                "你把莱尔拉出了门。也许和你一起度过一些时光能帮助他放松一下。"
                scene bg_black with w20
                jump lyall_cafe_date
            "想给托马斯浇水吗？" if "rooted" in buff_events:
                hide pboy
                buff confused sweat shock "哦，我...好啊。"
                show buff frown -sweat
                show side_p a at pic
                mc "真热情啊。"
                hide side_p
                buff scold frusta "好吧，抱歉，但你给我的第一印象并不是最好的。"
                buff kzl sigh "不过，我还是会去...只是为了确保你正确地给他浇水。"
                show side_p s at pic
                mc "我知道怎么给植物浇水。"
                hide side_p
                buff apa "你知道怎么浇水才不会淹没他的眼睛和耳朵吗？"
                show side_p m at pic
                mc "算了，我确实不知道怎么给植物浇水。他有眼睛和耳朵吗？？？"
                hide side_p
                buff keluh sigh "不是人类那种典型的方式，但...好吧，我会给你展示我的意思。"
                scene bg_black with w20
                jump buff_flower_bully
            "玩得开心。":
                hide pboy
                buff wry "我会的，派克和我今天会帮助镇上准备水母节。"
                buff hister blush bloom "应该会很有趣！"
                buff talk "再见，[povname]。"
                show side_p a at pic
                mc "回头见。"
                hide side_p
                $ NPC = "???"
                $ morning = False
                $ afternoon = True
                $ evening = False
                $ night = False
                scene bg_black with w20
                if "bunga_bego" in buff_events:
                    if "beku" in quil_events:
                        scene map_infected_f with w20    
                    else:
                        scene map_infected with w20    
                else:
                    if "beku" in quil_events:
                        scene map_frozen with w20
                    else:
                        scene map_all with w20
                jump world_map
    elif calendar.day == 24 and calendar.month == '/05': #Rabu W2
        if "ker_bar" in buff_events:
            play sound "sound/effects/cloth.mp3"
            scene bed_pagi with dissolve
            show buff eh at center with dissolve:
                yoffset 770
            buff apa "[povname]，你醒了吗？"
            show side_p f at pic
            mc "啊，是的。抱歉莱尔，我们现在应该去码头吗？"
            hide side_p
            buff wry blush sigh "呃，你可能想先擦掉脸上的口水，整理一下。"
            show side_p s at pic
            mc "哦..."
            show side_p m 
            mc "（糟糕，我一定比我想象的更累。）"
            hide side_p
            buff amused -blush -sigh "没关系。我还要先向维尔科娃女士提交一份报告。"
            buff laugh apa "待会儿码头见？"
            show side_p f at pic
            mc "好的。"
            hide side_p
            show buff datar -apa
            "莱尔坚定地点了点头，朝门口走去，而你则匆忙冲向浴室——希望能让自己看起来稍微体面一点迎接新的一天。"
            scene bg_black with w20
        scene tgh_pagi with w20
        play sound "sound/effects/walk.mp3"
        play music "MUSIC/MusMus-BGM-077.mp3"
        show quil skul at left with dissolve:
            yoffset 200
        show tom hip capek at right with dissolve:
            yoffset 190
        "在下楼去公共休息室的路上，你看到阿什姆正在和奎尔交谈。"
        stop sound
        quil err frusta "得了吧，阿什姆，我又不是故意要瞒着你！"
        tom scold kzl apa "你是不是被骗子麦克火药魔药控制了？"
        quil sad sweat "呃，没有...？"
        tom ew frusta "有人威胁你要保守真正的[povname]的秘密吗？"
        quil sulk sigh "……不。"
        tom hip capek blow "所以你确实是出于自己的意愿向我隐瞒了，奎尔。"
        show quil -sweat sad -sigh
        tom kzl -blow "如果你不介意的话，我现在必须去为阿贾克斯的父亲弄到一只狼人爪。"
        quil bingung "为什么？"
        tom chill "我打算向阿贾克斯坦白我所做的一切。"
        tom ha "当然，他不会太高兴，但只要我带来诅咒的解药，应该能让事情变得顺利一些。"
        quil err sweat "虽然我很欣赏你突然表现出的骑士精神，但你知道他不可能就这样算了，对吧？"
        quil kzl -sweat "一旦你坦白了，没有哪个大臣或政界要人会再庇护你。"
        tom capek frusta "坦白说，我从来就不想涉足政治。那是[povname]的梦想，不是我的。"
        tom sad blow "考虑到现在发生的一切，嗯……"
        quil sad sweat "哈……我明白了。我不会阻止你什么的，但是……亲爱的，你要小心。"
        quil flashy panik both "我可不希望阿贾克斯在这个周末的水母节之前把你的脸打得青一块紫一块的。"
        show quil sad -both
        tom hip capek -blow "……再见，英克威尔家的继承人。"
        hide tom with dissolve
        play sound "sound/effects/walk.mp3"
        quil skul sulk sigh"哈。"
        if girl:
            show palmierproxy chill wry at right with dissolve:
                xzoom -1.0
                yoffset 40
        else:
            show palmierproxy chill wry at right with dissolve:
                yoffset 100
        mc "他会回心转意的。"
        hide side_p
        quil tantrum frusta "哦，是你啊。你不知道偷听是不礼貌的吗？"
        mc huh tanya "你不知道你正站在宿舍的正中间吗？"
        show palmierproxy wry -tanya
        quil cringe sigh "说得对。"
        show quil frown -sigh
        mc apa "他还在躲着你吗？"
        quil sulk sweat frusta "我，塞恩，毫无疑问还有你，当然。"
        quil kzl -sweat "你知道吗，我把这一切都怪罪于你。你不知道诚实是被高估了的吗？"
        mc rajuk "奎尔，让他直接从我们这里知道总比从别人那里知道要好。"
        mc frown "我是说，塞恩还好。"
        quil rajuk sigh "是的，但他不是我认识了6年的那个爱耍手段的精灵。"
        mc confused tanya "说起来，那个红头发的家伙到底去哪了？"
        if "map1" in completed_quests:
            show quil frown shock
            show palmierproxy frown shock
            $ NPC = "???"
            stop music
            play sound "sound/effects/punch.mp3"
            npc "你这个吸血的水蛭！" with vpunch
            show quil kzl
            mc kzl sweat "我想这回答了你的问题。"
            play sound "sound/effects/tile.mp3"
            scene bg_black with circleirisin
            scene atas_sore with circleirisout
            stop sound
            jump rasis_vamp
        else:
            quil frown -sigh "我想他在和菲亚一起学习。你可能会在图书馆找到他。"
            mc apa -tanya "我明白了。他现在怎么样？"
            quil panik "至少比阿什姆好。他是个坚强的傻瓜，那家伙。"
            quil wry "我相信他已经决定把所有的挫折感都转移到通过魔药学考试上了。"
            mc frown "我明白了。你不帮他学习吗？"
            quil cringe "帮塞恩学习？我可能是个创造奇迹的人，但我也有极限。"
            show pboy at horzappear
            menu keru_bar:
                "{s}和奎尔一起闲逛{/s}"if "ker_bar" in buff_events:
                    jump keru_bar
                "{s}和奎尔一起去看塞恩{/s}"if "ker_bar" in buff_events:
                    jump keru_bar
                "和奎尔一起去看塞恩"if "ker_bar" not in buff_events:
                    hide pboy
                    mc hister "怎么，伟大的奎尔不敢接受挑战吗？"
                    quil groan frusta "原谅我不想浪费我的脑细胞。"
                    show quil frown -shock
                    mc wry "来吧，把它看作是你用你的陪伴来祝福他们。"
                    quil amused sigh "好吧，我想拒绝他们这种待遇确实有点残忍。"
                    mc smile "对吧？而且在你让他经历了那么多糟心事之后，你确实欠他不少。现在来吧！"
                    play sound "sound/effects/walk.mp3"
                    stop music
                    scene bg_black with w20
                    jump trio_hang
                    
                "和奎尔一起闲逛"if "ker_bar" not in buff_events:
                    hide pboy
                    mc happy tanya "我想你是的。不过，你今天有空吗？想一起出去玩吗？"
                    show palmierproxy kind -tanya
                    quil mock "和你一起出去玩？嗯。好吧，我想还有更糟糕的打发时间的方式。"
                    show quil hister
                    mc wry "哇，真是充满热情啊。"
                    quil datar "话说回来，你到底有什么想法？"
                    mc kind "嗯。你钓鱼吗？"
                    quil fluster sweat frusta "不。"
                    show quil frown shock
                    mc happy bloom "我来教你。"
                    quil err apa "什么？！"
                    stop music
                    play sound "sound/effects/walk.mp3"
                    
                    jump quil_fish
                "{s}你应该去。{/s}" if "ker_bar" not in buff_events:
                    jump keru_bar
                "你应该去。" if "ker_bar" in buff_events:
                    hide pboy
                    mc wry tanya "你还是应该去帮忙，为塞恩经历的那些糟心事做些补偿。"
                    quil sulk sigh "我想你说得对。"
                    quil frown -sigh "你呢？对魔药感兴趣吗？"
                    mc kind -tanya "不，我和莱尔有约。"
                    quil ejek cling "莱尔？"
                    show quil frown shock
                    mc wry "钓鱼。"
                    quil err frusta "哦，真俗气。那么，之后别忘了洗干净。"
                    quil kzl sigh "我可不想闻到你身上还留着鱼腥味。"
                    mc mock sigh"哦闭嘴吧，你这个自命不凡的混蛋！"
                    "你气呼呼地离开奎尔，朝码头走去，莱尔会在那里等你。"
                    stop music
                    play sound "sound/effects/walk.mp3"
                    scene bg_black with w20
                    jump lyal_ker_bar
                "{s}可以理解。（离开）{/s}" if "ker_bar" in buff_events:
                    jump keru_bar
                "可以理解。（离开）" if "ker_bar" not in buff_events:
                    hide pboy
                    mc smile "我明白了。那么，我先走了，回头见。"
                    quil flashy wink cling "再见！"
                    $ NPC = "???"
                    $ morning = False
                    $ afternoon = True
                    $ evening = False
                    $ night = False
                    stop music
                    play sound "sound/effects/walk.mp3"
                    scene bg_black with w20
                    if "bunga_bego" in buff_events:
                        if "beku" in quil_events:
                            scene map_infected_f with w20    
                        else:
                            scene map_infected with w20    
                    else:
                        if "beku" in quil_events:
                            scene map_frozen with w20
                        else:
                            scene map_all with w20
                    jump world_map

        
            
    elif calendar.day == 25 and calendar.month == '/05': #Kamis W2
        pause 1.0
        scene bed_pagi with eye_open
        play sound "sound/effects/window_knock.mp3"
        "你被敲门声惊醒了。"
        fia "[povname]，你醒了吗？要一起吃早餐吗？"
        show side_p f at pic
        mc "啊，好啊！稍等一下！"
        hide side_p
        scene bg_black with w20
        scene kantin with w20
        play music "MUSIC/MusMus-BGM-064.mp3"
        show croissant kerja at center with dissolve:
            yoffset 500
        "环顾食堂，奎尔和塞恩在他们常坐的位置。只有阿什姆不在，他反而坐在阿贾克斯和他朋友们旁边。"
        if "daddy1" in completed_quests:
            show croissant laugh
            "当你把注意力转回自己的桌子时，你注意到普莉姆在收到父亲的信后似乎更开心了。"
            show croissant smile
            "虽然可能不是她想听到的内容，但至少她得到了一个交代。"
            "在你能谈论其他事情之前，菲亚直接跳进来问了你一直在担心的问题。"
        elif "daddy1" in active_quests:
            if check_inv_for(slip_items):
                python:
                    InvItem(*item_slip).toss(1)
                    active_quests.remove("daddy1")
                    completed_quests.insert(0, "daddy1")
                "走到自己的桌子前，你立即把普莉姆父亲的信交给了她。读完后，她感激得泪流满面。"
                "你有点内疚，因为直到现在才想起给她，不过话说回来，她确实很难找到。"
                show screen completedtask("任务完成！")
            else:
                "你问起她父亲的事，但普莉姆完全拒绝回答，只说她的家人正在应对。"
                $ active_quests.remove("daddy1")
                show screen completedtask("任务失败！")
            "气氛变得有点尴尬，但幸好菲亚缺乏圆滑的性格很快就解决了这个问题。"
        else:
            if "prim_onlyfans" in my_events:
                "普莉姆一直在谈论你的OnlyPhans想法对她来说效果很好。她已经有了足够多的支持者来维持她家族的上流社会地位。"
                "她已经招募了几十个其他女孩来帮助她。"
                mc "（我不知道我是该感到自豪还是担心。）"
                "幸好菲亚对这些事情不感兴趣。相反，她对你的问题更感兴趣。"
        fia gross apa "那么...你和阿什姆之间是怎么回事？"    
        jump breky_ajax 
    elif calendar.day == 27 and calendar.month == '/05': #Sabtu W2
        $ morning = False
        $ afternoon = True
        scene bg_black with eye_shut
        play music "MUSIC/MusMus-BGM-007.mp3"
        pause 1.0
        scene bed_pagi with eye_open
        show croissant dance at center with dissolve:
            yoffset 500
        fia err frusta "嘿，[kk]，别告诉我你还在睡觉！"
        play sound "sound/effects/slap.mp3"
        queue sound "sound/effects/bump.mp3"
        fia annoyed ang"[povname]!!!" with vpunch
        show croissant at right with move
        if girl:
            show palmierproxy jln grit at left with dissolve:
                yoffset 40
        else:
            show palmierproxy jln grit at left with dissolve:
                yoffset 100
        mc shock "哇！"
        mc apa tanya "...菲亚？"
        fia cringe frusta "已经中午了，节日马上就要开始了！"
        mc frown shock"嗯？"
        mc rajuk sweat -shock "（我真的睡了那么久吗？这以前从未发生过。）"
        mc sad "抱歉..."
        if 'nari' in buff_events:
            mc hister -sweat "昨晚我帮莱尔上了一些舞蹈课。我想是把自己累坏了。"
            fia mmh apa "诶？你和那个一年级生？"
            mc happy "他找到了约会对象，想练习一下，显然他以前从未跳过舞。"
            fia frown "哈，所以有人勇敢到邀请那个巫师出去了？"
            fia jijik sweat frusta "你确定这不是个陷阱吗？你知道我们一半的同学要么是反社会人格要么就是混蛋，对吧？"
            show croissant kzl -frusta
            mc wry sigh "我注意到了，但肯定也有一些好人存在，对吧？"
            fia kerja -sweat "嗯，好吧，我想是的。他的胸肌太耀眼了，我理解为什么有些人会感兴趣。"
            mc kzl shock "菲亚！"
            fia pain blush sigh "怎么了？我只是在看而已，很难不看到，因为它们正好在我的眼睛高度！"
        else:
            mc hister "只是一直感到疲倦。"
            mc rajuk "（仔细想想，我上次睡个好觉是什么时候？几乎每天我都会因为一些奇怪的事件或者巫师入侵我的梦境而醒来。）"
            fia sad apa "你不是生病了吧？"
            mc happy "我没事..."
            mc huh "（我想是这样。）"
            show palmierproxy kind
            fia gross sigh "如果你这么说的话。如果你真的生病了，一定要告诉我，好吗？我知道你生病时有多爱表现，所以如果需要的话，我会留在这里陪你。"
            fia wry "舞会可以等。"
            mc happy blush "不，真的没事。而且，你已经打扮好了，你看起来很漂亮，妹妹。"
            fia laugh blush bloom "对吧？我花了整个上午才把头发弄好！"
        show palmierproxy kind blush
        fia pity blush bunga "总之，餐厅已经关门了，但我给你带了些食物！"
        fia happy -blush "快吃吧，洗个澡，然后我来帮你穿衣服。"
        show palmierproxy frown -blush shock
        if not girl:
            if "jelly" in fia_events:
                mc panik sweat "哦，关于那个...我好像把我的衣服借给莱尔了。"
                fia mad sweat shock "你什么？！"
                fia mmh frusta"但是...但是那件衣服是我特意为你挑的！"
                show croissant sad
                mc sad sigh "我知道，但他那时一副可怜巴巴的样子，我就觉得他没有其他衣服穿很可怜，所以——"
                fia mock -sweat shock "等等，等等，慢着！[kk]，你什么时候开始会同情别人了？"
                fia pain cling "你是谁，你把[povname]怎么了？"
                show croissant kerja -cling
                show palmierproxy side
                "从她的语气中，你能听出她是在开玩笑，但你还是忍不住撇了撇嘴。"
                "你感觉你的秘密就要在你体内爆发了。"
                fia gross apa "你还好吗？你看起来好像便秘了。"
                mc ow frusta "因为我确实便秘了。不过话说回来，你生气了吗？我是说，关于我把衣服借给莱尔的事。"
                show palmierproxy sad -sweat -frusta
                fia mmh sigh "嗯。不是生气，只是有点失望吧。"
                fia pity -sigh "但你难得这么好心一次，所以没关系。爸爸总是说我们需要多分享，对吧？"
                mc wry "对！"
                fia sad apa "不过，你有备用的衣服吗？你不能穿平常的衣服去。大家都已经盛装打扮了。就连塞恩也是，虽然他的衣着又有点不太合适。"
                fia frown -apa "但他是个外国人，所以我想我不该对他要求太高。"
                fia "那么...你的备用衣服是什么？"
                mc laugh "我可以穿去年的衣服。"
                fia jijik shock "认真的吗？...好吧，但我得提醒你，这次我可不会帮你挡开那些熟女和变态了。"
                mc sad tanya "什么？为什么，难道那件衣服很糟糕吗？"
                show palmierproxy frown shock
                show croissant pain sigh
                "菲亚没有说话，但她打开了你的衣柜，露出了一件只能用罪恶来形容的衣服。"
                mc pissed frusta "...我不会穿那个的。"
                fia mock cling "要么穿这个，要么就光着身子去。"
                show croissant annoyed -cling
                mc sad frusta "老实说，相比这件令人发指的衣服，光着身子似乎更合适。"
                mc huh -frusta "我的天啊，我去年真的穿过这个吗？"
                fia sad sigh "你应该事先考虑到这一点的！"
                fia err -sigh "不过嘿，我来这里之前好像看到莱尔在花园里鬼鬼祟祟的。"
                fia malu "他在为他的约会对象摘花，如果你想要回你的衣服的话。"
                mc ew "...他在笑吗？"
                fia gross frusta "是啊。让我想起了那个恐怖的天线宝宝，他笑得比太阳还亮。我差点被闪瞎了。"
                mc kzl frusta "该死！哈...我没事的。"
                mc confused sweat sigh "帮我把束带和项圈戴上？"
                fia ejek sigh "我会帮你的，但我们得快点，好吗？我想在黄昏之前到那里！"
            else:
                fia mock cling "你确实为节日买了新衣服，对吧？"
                mc avoid sweat "呃...关于那个..."
                mc ha "重复使用和回收利用不是更好吗？"
                fia sad sweat apa "等等，你想穿你的旧衣服？"
                fia jijik sigh "我是说你可以穿，但是..."
                fia mock -sweat cling "好吧，别说我没警告你。如果那些熟女又围着你转，可不是我的错。"
            
        else:
            mc apa sweat tanya "我不是大[kk]吗？为什么你反而在帮我？"
            fia cringe frusta "[nickname]，你在时尚方面的品味糟糕透顶，化妆技术更是糟糕。"
            fia annoyed "当你看起来很糟糕时，我也会看起来很糟糕，所以..."
            show palmierproxy frown -sweat -tanya
            "菲亚翻找你的衣柜，拿出一件闪闪发光的红色派对裙和配套的饰品。"
            fia laugh cling "况且，去年你帮了我，这次轮到我了。"
            fia pain -cling "快点，我想在黄昏前到那里！"
        scene bg_black with w20
        "说完，菲亚帮你穿上衣服……你们在黄昏前并没有完成。"
        $ night = True
        $ evening = False
        $ afternoon = False
        $ morning = False
        jump festival_time 
    elif calendar.day == 28 and calendar.month == '/05': #Minggu W2
        pause 1.0
        scene bed_pagi with eye_open
        if "ama_fia" in fia_events:
            jump pagi_fia
        else:
            jump fia_komplen
    elif "ghosts" in my_events and "ghost_time" not in my_events:
        pause 1.0
        scene bed_alter with eye_open
        $ night = True
        $ evening = False
        $ afternoon = False
        $ morning = False
        jump ghost_time
    elif calendar.day == 29 and calendar.month == '/05': #Senin W3
        pause 1.0
        scene bed_alter with eye_open
        $ night = True
        $ evening = False
        $ afternoon = False
        $ morning = False
        jump ghost_time
    elif calendar.day == 30 and calendar.month == '/05': #Selasa W3
        pause 1.0
        scene bed_pagi with eye_open
        $ quil_events.append("ink_sms")
        "你醒来时发现奎尔的消息正在轰炸你的手机。"
        $ interlocutor = "Quill"
        $ del_all_msg()
        hide window
        show hp at move_messenger2
        pause 1.0
        $ show_messenger()
        if "date2_done" not in quil_events:
        
            $ msg ("我对雕像的血液做了一些测试，你会对我的发现感到惊讶的。", who=1, status='online')
            $ msg ("如果你感兴趣的话，来喷泉附近见我吧！", who=1)
        
        else:
            $ msg ("关于墨水或巫师血液的问题，我还没有收到佩纳或我父亲的任何消息。", who=1, status='online')
            $ msg ("他们可能需要几天时间才会注意到我。", who=1)
            $ msg ("也许如果学校发生什么大事，他们就会开始说话了。", who=1)
            $ msg ("如果他们回复了，我会告诉你的。", who=1)
        $ hide_messenger()
        hide hp
        show hp2 at move_messenger3
        pause 1.0
        $ NPC = "???"
        $ night = False
        $ evening = False
        $ afternoon = True
        $ morning = False
        scene bg_black with w20
        if "bunga_bego" in buff_events:
            if "beku" in quil_events:
                scene map_infected_f with w20    
            else:
                scene map_infected with w20    
        else:
            if "beku" in quil_events:
                scene map_frozen with w20
            else:
                scene map_all with w20
        jump world_map
    
    elif calendar.day >= 17 and calendar.month == '/06': #Sat  W5
        jump perpisahan    
    elif "mc_bangkit" in my_events and "hari_b" not in fia_events: #Day after Leynar
        scene bed_pagi with eye_open
        $ fia_events.append("hari_b")
        play music "MUSIC/MusMus-BGM-092.mp3"
        "难得一次，你醒来时感到神清气爽，没有头痛，没有疼痛。"
        "没有巫师在你的梦中造访。只是一个美好的夜晚睡眠……"
        "很快就被走廊里学生们的恐慌和喧闹声打断了。"
        $ NPC = "男孩"
        npc "你听说莱纳尔发生的事了吗？"
        $ NPC = "女孩"
        npc "我想那里发生了巫师之间的战斗，有美丽巫师和变化巫师的痕迹！"
        $ NPC = "男孩"
        npc "我知道，太疯狂了！"
        npc "你觉得那很疯狂？我爸爸在教会工作。他说他们正在考虑解散所有的猎巫学校！"
        $ NPC = "女孩"
        npc "什么？为什么？"
        $ NPC = "男孩"
        npc "显然有人已经消灭了所有的纯血巫师。另外，墨水和湖泊也出现了一些问题？"
        npc "这一切真的很令人困惑。"
        $ NPC = "女孩"
        npc "所以巫师时代结束了？"
        $ NPC = "男孩"
        npc "我……我想是的。"
        $ NPC = "女孩"
        npc "我的意思是，别误会，我很高兴但是……这对我们意味着什么？"
        show side_p f at pic
        mc "（确实如此。）"
        hide side_p 
        "看来教会忙于清理工作。你想知道为什么没有人把巫师的死亡与你联系起来，但你决定暂时感恩就好。"
        "你不妨在告别之前充分利用你的空闲时间。"
        show side_p se at pic
        if "companion" not in my_events:
            mc "也许我应该多花些时间和那些家伙在一起，在离开之前真正了解他们。"
        else:
            mc "也许我应该多探索校园。看看现在所有巫师都死了，有什么变化。"
            mc "我是说，现在消息肯定已经传开了，对吧？"
        hide side_p
        "当你前往浴室准备开始新的一天时，你看到门上贴着一张纸条。"
        "用莱尔的笔迹写着\'去码头了，希望能见到派克。\'"
        show side_p s at pic
        if "pike_betray" in buff_events:
            mc "啊，派克。我真不敢相信在被出卖之后他还想和他有任何关系。"
            mc "也许我应该去码头确保他没事。"
        else:
            mc "我希望派克没事。我在村子里没看到他，但也许这是件好事。"
            mc "也许他幸免于变化巫师造成的所有混乱。"
        show side_p f
        mc "（无论如何，我想我应该趁能在这里的时候好好享受。也许看看所有这些巫师事件的后果。）"
        hide side_p
        $ night = False
        $ evening = False
        $ afternoon = True
        $ morning = False
        $ NPC = "???"
        scene bg_black with w20
        if "bunga_bego" in buff_events:
            if "beku" in quil_events:
                scene map_infected_f with w20    
            else:
                scene map_infected with w20    
        else:
            if "beku" in quil_events:
                scene map_frozen with w20
            else:
                scene map_all with w20
        jump world_map
    elif calendar.day >= 7 and calendar.month == '/06'and "anak_hilang" not in fia_events: #Tuesday  W4
        jump hedwin_announce
    elif calendar.day == 1 and calendar.month == '/06': #Thursday  W3
        pause 1.0
        
        if "bond" in fia_events and "cure_me" not in red_events:
            jump fia_bond
        else:
            scene bed_pagi with eye_open
            "你被手机持续的哔哔声吵醒。打开Phrase，你被一个未知号码发来的大量短信淹没。"
            play music "MUSIC/MusMus-BGM-112.mp3"
            $ interlocutor = "Unknown"
            $ del_all_msg()
            hide window
            show hp at move_messenger2
            pause 1.0
            $ show_messenger()
            $ msg ("羽毛告诉我，一个小贝克杀死了我的同类之一。", who=1, status='online')
            $ msg ("近一个世纪以来，终于有一个猎人值得我花时间了。", who=1)
            $ msg ("我还以为梅扎吸的那些香烟会先要了她的命呢。", who=1)
            $ msg ("你在猎杀我们吗，小贝克？如果是的话，我等着你来到我的门前。", who=1)
            $ msg ("小贝克坐在湖中央。", who=1)
            $ msg ("小孩子们死在他们的身后。从今天起，直到我们相遇……", who=1)
            $ msg ("……无辜的孩子们将在我的掌控之中。当我们最终在明亮的神圣月光下相遇时……", who=1)
            $ msg ("……我一定会确保他们一点也不剩。", who=1)
            $ msg ("来吧，小贝克。来，你不想玩吗？", who=1)
            $ msg ("还是你要让这个变化巫师失望而归？", who=1)
            $ msg ("", choices={0:{'jump':'whodis', 'name':"这是谁？"}, 1:{'jump':'seth_txt', 'name':"你是……塞斯吗？"}})
    else:
        play sound "sound/effects/cloth.mp3"
        pause 1.0
        scene bed_pagi with eye_open
        if "mc_bangkit" in my_events:
            "你醒来时感到神清气爽。"    
        else:
            "你醒来时头疼，但决定暂时忽略它。"
            "当你穿好衣服时，头痛减轻了，你开始了一天的生活。"
        $ NPC = "???"
        play music "MUSIC/MusMus-BGM-035.mp3"
        scene bg_black with w20
        $ night = False
        $ evening = False
        $ afternoon = True
        $ morning = False
        $ NPC = "???"
        if "bunga_bego" in buff_events:
            if "beku" in quil_events:
                scene map_infected_f with w20    
            else:
                scene map_infected with w20    
        else:
            if "beku" in quil_events:
                scene map_frozen with w20
            else:
                scene map_all with w20
        jump world_map
label seth_txt:
    $ msg ("你是……塞斯吗？")
    $ msg ("塞斯是我的名字，杀戮是我的游戏。你会阻止我还是会失败？", who=1)
    $ msg ("我会在高悬的苍白月光下注视着你。", who=1)
    $ hide_messenger()
    hide hp
    show hp2 at move_messenger3
    pause 1.0
    show side_p s at pic
    mc "（……这世上真的没有安宁吗？我刚以为可以稍微放松一下。）"
    show side_p m
    mc "（我最好告诉其他人这件事。）"
    hide side_p
    jump breki_seth
label whodis:
    $ msg ("这是谁？")
    $ msg ("如果你必须问，那你就已经落后了。我们月光下再见。", who=1)
    $ hide_messenger()
    hide hp
    show hp2 at move_messenger3
    pause 1.0
    mc "（……这世上真的没有安宁吗？我刚以为可以稍微放松一下。）"
    mc "（我最好告诉其他人这件事。）"
    jump breki_seth

label breki_seth:
    scene bg_black with w20
    play music "MUSIC/MusMus-BGM-064.mp3"
    scene kantin with w20
    show quil skul frown at center with dissolve:
        yoffset 200
    show tom hip at right with dissolve:
        yoffset 190
    show red chin frown at left with dissolve:
        yoffset 330
        xpos -200
    quil err apa "变化女巫联系你了？"
    show quil rajuk -apa
    red bingung apa "通过短信？你确定不是恶作剧吗？"
    show red frown -apa
    show side_p f at pic
    mc "我是说，有可能是。"
    hide side_p
    tom talk ha "我们可以追踪号码。奎尔，这不是你们家族的专长吗？"
    quil frown "我们可以。让我看看你的手机，我看看能做些什么。"
    show side_p f at pic
    mc "好的，还有嗯……一切都还好吗？"
    hide side_p
    tom frown "嗯，奎尔和我拜访了幻想女巫。至少她很温顺。"
    show side_p f at pic
    mc "真的吗？所以你认为她说的是实话？"
    hide side_p
    quil rajuk "不是全部，但至少重要的部分是。我们可以比信任梅扎更信任她，这是肯定的。"
    quil frown "不过，她坚持要对你和她之间的交易保密。"
    quil amused "虽然我猜这对她来说不是什么小恩小惠。说实话，在种族屠杀和小偷小摸的尺度上，她的要求有多邪恶？"
    show tom ha
    show side_p s at pic
    mc "综合考虑的话，大概是5吧，但是，嗯，这很复杂。话说回来，塞恩，你还好吗？"
    hide side_p
    
    if "cure" in red_events:
        if "cure_me" in red_events:
            red cowo blush bunga "我感觉好极了！我感觉棒极了，从未如此不渴！"
            quil talk apa "没有想要伤害或割开任何人喉咙的冲动吗？"
            red amused sigh "我是说，至少不是出于渴望。"
            tom chill calm blow "我很高兴，看来我们避免了一场灾难。"
            show side_p a at pic
            mc "你觉得这能持续多久？"
            hide side_p
            show quil smile bunga
            show tom pfft -blow
            red ngeles sweat frusta "别乌鸦嘴！"
            $ NPC = "???"
            scene bg_black with w20
            $ night = False
            $ evening = False
            $ afternoon = True
            $ morning = False
            $ NPC = "???"
            if "bunga_bego" in buff_events:
                if "beku" in quil_events:
                    scene map_infected_f with w20    
                else:
                    scene map_infected with w20    
            else:
                if "beku" in quil_events:
                    scene map_frozen with w20
                else:
                    scene map_all with w20
            jump world_map
        else:
            red point sayang "我能控制住。阿什姆和奎尔在给我提供食物。"
            show red ngeles shock
            quil heh sigh "我们就像他的糖爹，只是我们没有得到任何甜头作为回报。"
            quil flashy wink cling "至少目前是这样。"
            show tom giggle blow
            show quil skul blush hister -cling
            red so both frusta "好吧，至少你在这件事上玩得开心，奎尔。"
            show quil datar -blush
            tom smile -blow "我们管理塞恩的情况还不错。我和一个射箭的女孩聊过。她奶奶是个吸血鬼。"
            show side_p f at pic
            mc "哦对，我和那个女孩聊过。你觉得会有用吗？"
            hide side_p
            tom hip frown "可能会。这不是一种简单的药水，可能需要几天时间。"
            tom ha blow "而且我们需要你的血。用其他人的血不行。"
        
    else:
        $ red_events.append("cure")
        $ known_recipes.append("item_obat")
        tom scold frown "她说我们可以用独角兽血、海妖血和人类血的混合物来控制塞恩的渴望。"
        tom hip ha blow "只要我们用你的血就行。"
    show pboy at horzappear
    menu:
        "抽我的血吧！":
            hide pboy
            $ mrh.points += 5
            $ kindness += 10
            $ honesty -= 10
            $ curiosity -= 10
            
            show quil heh sigh
            show red kaget blush shock
            tom hip nyesal sweat frusta "你毫不犹豫的态度有时让我担心。"
            show tom chill frown -sweat -frusta 
            red blush wry sigh "是啊伙计，我是说我很高兴，但冷静点。"
            show red datar -sigh
            show side_p f at pic
            mc "但这会有帮助的！"
            hide side_p
            quil sulk frusta "我们还是得先熬制。混合独角兽血和海妖血有点……至少可以说是不稳定的。"
            


        "这安全吗？":
            hide pboy
            $ honesty += 10
            $ curiosity += 5
            $ kindness -= 10
            if kindness < 0:
                $ kindness = 0
            show red -frusta
            quil sulk frusta "不完全安全。混合独角兽血和海妖血有点……至少可以说是不稳定的。"
    show side_p he at pic
    mc "不稳定并不意味着不可能。"
    hide side_p
    quil mock sigh "好吧，我很高兴你这么乐观，因为你才是那个要熬制它的人。"
    show quil datar -sigh
    show side_p m at pic
    mc "嗯？"
    hide side_p
    tom scold frown -blow "我们认为这样最好。给你。"
    if gold >=300:
        $ gold += 100
        "阿什姆给了你100金币。"
    else:
        $ gold += 300
        "阿什姆给了你300金币。"
    tom frown "我不记得迪特里希商店里那些血瓶的确切价格，但这些钱应该够了。"
    tom pfft "如果不够，我相信你现在应该能补上剩下的。"
    show side_p s at pic
    mc "你确定要我来制作这个吗？"
    hide side_p
    quil panik "哦，相信我，如果可以的话，阿什姆或我早就自己动手了，但是..."
    show quil datar
    red sayang both "我想你会更愿意自己来做，因为我们需要在混合物中加入你的血液。"
    show red wry -both
    show side_p a at pic
    mc "谢谢...我想？"
    hide side_p
    quil flashy heh cling "你一制作好我们就会直接来找你，所以...快点动手吧。"
    show quil datar -cling
    red awkward both "或者等你准备好了，呃...但请在大祭司到来之前完成，好吗？"
    show side_p he at pic
    mc "我会的。但是...如果这不起作用怎么办？"
    hide side_p
    tom frown blow "那么结合就是我们唯一的机会了。不过我们还有几天时间。"
    quil skul datar "先制作这个，希望能有好结果。说不定到那时我也能得到更多关于塞斯巫师的信息。"
    show side_p he at pic
    mc "是的，这说得通。好吧，呃...继续藏好你的獠牙，塞恩！"
    show side_p a
    show red bingung sweat shock
    show quil hister shock
    show tom giggle shock
    mc "干得好，爸爸们！"
    hide side_p
    show tom pfft blush
    show quil heh blush
    "你友好地拍了拍阿什姆和奎尔的肩膀，对塞恩眨了眨眼。"
    show quil smile bunga
    show tom calm bunga
    red ew both frusta "啊，我能咬你一口让你闭嘴吗，拜托？"
    $ NPC = "???"
    scene bg_black with w20
    $ night = False
    $ evening = False
    $ afternoon = True
    $ morning = False
        
    if "bunga_bego" in buff_events:
        if "beku" in quil_events:
            scene map_infected_f with w20    
        else:
            scene map_infected with w20    
    else:
        if "beku" in quil_events:
            scene map_frozen with w20
        else:
            scene map_all with w20
    jump world_map

label bar_live:
    python:
        msg ("相信我，我知道怎么打架。酒吧斗殴可是相当激烈的。")
        msg ("酒吧斗殴？多么低俗。", who=1)
        honesty += 10
    jump blow_ink
label fist_nope:
    python:
        msg("没有，但是……")
        msg ("我就知道。你看起来也不像那种类型，太软弱了。", who=1)
        my_events.append("cupu")
        kindness += 5
    jump blow_ink
label fist_yes:
    $ kindness -= 10
    if kindness < 0:
        $ kindness = 0
    python:
        
        msg("我打过，一两次吧。")
        msg ("哦。请告诉我。", who=1)
        msg ("那是在初中的时候。很蠢。")
        msg ("我喜欢蠢人和他们疯狂的行为。", who=1)
        msg ("告诉我更多???", who=1)
    if not girl:
        python:
            msg ("那家伙以为我在抢他的女朋友。")
            msg ("显然我不够gay，不足以被当成gay蜜。")
            msg ("就像，哎呀，对不起。")
            msg ("我忘了带上我那写着\'我是个狂热同性恋\'的霓虹粉标志。")
            msg ("嗯，有趣。这对你来说正常吗？人们会问你的性取向？", who=1)
            msg ("啊？好吧，我是说，我想是的。你从来没有遇到过一两次恐同的辱骂吗？")
            msg ("与其说是性别，我们更担心的是物种问题。", who=1)
            msg ("无论是同性还是异性，没人会在意。", who=1)
            msg ("但某些物种，比如吸血鬼和精灵，人鱼和海妖，或者当然，就像我们这种情况...", who=1)
            msg ("...一个巫师和一个人类，那通常就是另一回事了。", who=1)
            msg ("哦，所以你们是种族主义者？")
            msg ("如果种族指的是物种，那么是的。", who=1)
    else:
        python:
            msg ("有些混蛋觉得把菲亚的训练内衣挂在旗杆上很有趣。")
            msg ("她发育得早，所以总是受到男孩们不必要的注视。")
            msg ("我揍了那个罪魁祸首，结果演变成了一场大打出手。")
            msg ("我差点被开除，但这绝对值得！")
            msg ("我相信。", who=1)
            msg ("不过，为什么菲亚不自己打架呢？", who=1)
            msg ("她不是那种人。不是我认识的菲亚。她很温柔善良。是的，她有时候可能有点孩子气。")
            msg ("但那也没关系。")
            msg ("那就和我认识的菲亚完全相反了。", who=1)
            msg ("只是性格上相反，其他方面都一样。如果完全一样的话，我想我可能会情绪崩溃。")
            msg ("哦不，现在可不能这样，现在还太早了！", who=1)

    jump blow_ink
label blow_ink:
    python:
        msg ("话说回来，你画好符文了吗？", who=1)
        msg ("我怎么画？你还没给我发照片呢！")
        msg ("说得对。我现在闭嘴。", who=1)
        msg ("不过别担心，待会儿我会在射箭场亲临指导的。", who=1)
    $ hide_messenger()
    hide hp
    show hp2 at move_messenger3
    pause 1.0
    "奎尔给你发了一张各种符文的图片。"
    "你小心地在指关节上画上这些符文，然后轻轻吹气，确保这次它们能够正确干燥。"
    "等你完成后，你注意到下一节课要到午饭后才开始。"
    show side_p f at pic
    mc "不知道该做些什么来打发时间。"
    hide side_p
    $ night = False
    $ evening = False
    $ afternoon = True
    $ morning = False
    $ NPC = "???"
    scene bg_black with w20
    if "bunga_bego" in buff_events:
        if "beku" in quil_events:
            scene map_infected_f with w20    
        else:
            scene map_infected with w20    
    else:
        if "beku" in quil_events:
            scene map_frozen with w20
        else:
            scene map_all with w20
    jump world_map
label kls_diet: #JUmat
    scene bg_black with w20
    scene kls_crowd with w20
    play music "MUSIC/MusMus-BGM-062.mp3"
    show priest charm at center with dissolve:
        yoffset 200
    "今天你有黑魔法符文课。迪特里希先生上课时挂着他惯常的假笑。"
    if "die_deal" in my_events and not "deal_die" in my_events:
        show priest sly cling
        "然而，他时不时地会偷偷瞥你一眼。"
        show priest charm -cling
        "不知道他想要什么。"
    
    if "die_deal" in my_events and not "deal_die" in my_events:
        scene bg_black with w20
        scene kls with w20
        show priest charm at center with dissolve:
            yoffset 200
        dog laugh bloom "[povname]，能和你谈谈吗，就一会儿？"
        show priest charm 
        $ my_events.append("deal_die")
        "下课时，迪特里希用迷人的声音和温暖的微笑向你招手。"
        "这景象让你心生恐惧。肯定有什么不对劲。"
        show side_p f at pic
        mc "...你想要什么，迪特里希？"
        hide side_p
        dog grin -bloom "我看到你偷听了老师们的小赌局。"
        dog sly cling "我想你可以让自己变得有用一次。"
        dog wry apa "做个乖孩子，来场表演，好吗？"
        show side_p he at pic
        mc "什么？"
        hide side_p
        dog bleh sigh "和英克威尔那小子约会，不用认真，只是假装就行。"
        dog grin -sigh "这对你来说不是更好吗？不用那么多老师盯着你的一举一动。"
        show side_p w at pic
        mc "那你打算怎么奖励我呢，还是...？"
        hide side_p
        dog laugh cling "我赢得的一部分。这似乎很公平。不过，我需要完全的胜利证明。"
        dog grin -cling "你和那个自负的小子公开接吻就足够了。"
        show pboy at horzappear
        menu:
            "我有兴趣。":
                hide pboy
                dog sigh "很好。我还需要照片证据。凯普勒可不是个容易说服的人。"
                show priest ramah -sigh
                show side_p se at pic
                mc "成交。"
                hide side_p
                $ add_new_quest("kissu1")
                python:
                    if len(new_quests) > 0: #if we have new quests
                        for i in new_quests:
                            active_quests.insert(0, i) #add to top of the quest list
                        new_quests = [] #now reset the new quest list, since they all got added
                show screen completedtask("新任务！")
                dog wry "明智的决定。"


            "我不会那么做的。":
                hide pboy
                show priest kzl shock
                show side_p m at pic
                mc "我不会那样玩弄奎尔的感情。"
                hide side_p
                dog bleh frusta "啧。你真是个圣人，是吧？好吧，随你的便。"
        dog side "我要说的就这些。你现在可以走了，我对你没有其他用处了。"
        hide priest with dissolve
        $ morning = False
        $ afternoon = True
        "你离开了他的课堂，继续你的一天。"
    else:
        "你听完后继续你的一天。"
    scene bg_black with w20
    $ night = False
    $ evening = False
    $ afternoon = True
    $ morning = False
    $ NPC = "???"
    if "bunga_bego" in buff_events:
        if "beku" in quil_events:
            scene map_infected_f with w20    
        else:
            scene map_infected with w20    
    else:
        if "beku" in quil_events:
            scene map_frozen with w20
        else:
            scene map_all with w20
    jump world_map

label breky_ajax:
    show croissant at right with move
    if girl:
        show palmierproxy chill malu at left with dissolve:
            yoffset 40
    else:
        show palmierproxy chill malu at left with dissolve:
            yoffset 100
    mc panik sweat "我不知道你在说什么。"
    show palmierproxy side 
    fia mock cling "是啊，奎尔比泰特姆跳舞的钢管还直。"
    show croissant kzl shock
    $ NPC = "普莉姆"
    show prim_ yell at pic
    npc "菲亚！"
    hide prim_
    fia pain sigh "哦，这只是个玩笑，普莉姆。"
    fia err -sigh "所以说，快说吧。你们俩怎么回事？其实是你们所有人，因为我知道这次不只是你和阿什姆表现得尴尬。"
    fia kzl sigh "阿什姆一直在到处忏悔他的罪过，道歉得好像世界末日要来了似的。"
    mc scratch apa tanya "这不是好事吗？他在修复关系。"
    fia sad -sigh "倒不如说是在破坏关系。我们都会说谎、欺骗和利用彼此，[kk]。"
    fia cringe sweat "但我们不会当着他们的面承认，那简直就是在等死！"
    show croissant flinch mad -sweat shock
    show palmierproxy chill kzl shock
    $ NPC = "阿贾克斯"
    stop music
    play sound "sound/effects/bang.mp3"
    show npc_1_m at pic
    npc "你做了什么？！" with vpunch
    hide npc_1_m
    play music "MUSIC/whisper.mp3"
    scene kantin with dissolve
    show tom hip kzl at center with dissolve:
        yoffset 190
    "从房间中央，你可以看到阿什姆正在和阿贾克斯交谈。"
    "不过，说是交谈有点牵强，更像是阿什姆被大声斥责和吐口水，而不是一场真正的文明对话。"
    "你瞥了一眼教师桌，希望他们中的任何一个能出面干预，但显然他们今天都不在。真是可以预料。"
    play music "MUSIC/Action-Rhythm-4.mp3"
    show npc_1_m at pic
    npc "你诅咒了我父亲？"
    hide npc_1_m
    tom scold whine sweat "是的，但我这里有解药。所以如果我们能放下这件事，然后——"
    show tom sad 
    show npc_1_m at pic
    npc "怎么可能放下，你这个恶心的混血种。我看在你继父的份上给了你机会。"
    npc "但我想那也洗不掉你那个婊子母亲的教导。"
    hide npc_1_m
    show tom talk ew -sweat shock
    show side_p m at pic
    mc "（哇哦，好了，这太过分了！）"
    hide side_p
    show pboy at horzappear
    menu:
        "走近他们":
            hide pboy
            $ kindness += 5
            "在你能站起来之前，菲亚把你拉回了座位。"
            show croissant flinch mad at right with dissolve:
                yoffset 500
            fia kzl frusta "不。让那些白痴自己解决这事。"
            show quil flashy kzl at left with moveinleft:
                yoffset 200
            quil "阿贾克斯，冷静下来！"
            fia err sigh "看到了吗？都是些蠢货。"
            show npc_1_m at pic
            npc "这与你无关，奎尔！"
            hide npc_1_m
            hide quil with dissolve
            hide croissant with dissolve
        "向他们喊话":
            hide pboy
            $ curiosity -= 10
            $ kindness -= 5
            $ kindness -= 10
            if kindness < 0:
                $ kindness = 0
            show side_p m at pic
            mc "他已经道歉了，阿贾克斯！"
            hide side_p
            show npc_1_m at pic
            npc "这与你无关，[povname]！"
            hide npc_1_m
    show tom hip capek sweat blow
    "你可以看到阿什姆的眉头因愤怒而紧皱，但他还是深吸了一口气，试图放下这件事。"
    tom kzl -sweat -blow "阿贾克斯。我知道我的行为不当，但是——" 
    show tom eh sweat shock
    show npc_1_m at pic
    npc "我会让你知道什么叫不当！"
    hide npc_1_m
    show tom talk capek blood frusta
    stop music
    play sound "sound/effects/wush.mp3"
    queue sound "sound/effects/stab.mp3"
    "他手腕一挥，一道魔法切入了阿什姆的肩膀。他的血溅得到处都是，弄脏了自己的饭菜和周围的人。" with vpunch
    hide tom with dissolve
    play sound "sound/effects/swosh.mp3"
    "但事情并没有就此结束。那道魔法镰刀正朝你直冲而来。"
    play sound "sound/effects/shield.mp3"
    scene kantin with flashbulb
    "你做好了承受疼痛的准备，但在任何事情发生之前，你感到一阵来自菲亚的风"
    "用她自己的魔法偏转了那道攻击。"
    show croissant flinch mad frusta at center with dissolve:
        yoffset 500
    fia kzl "不准。碰。我的[kk]！"
    play sound "sound/effects/shield.mp3"
    show kantin behind croissant with dissolve:
        subpixel True
        zoom 1.2 xpos 0.5 ypos 0.5 xanchor 0.5 yanchor 0.5 
        alignaround (.45, .45)
        linear 20 yalign 0.45 xalign 0.45 clockwise circles 1.2
        #repeat
    "整个食堂因菲亚的强制力而陷入一片寂静。有些人仅仅因为这个命令就弯下了腰。"
    "她对那个符文的使用越来越得心应手了。"
    show kantin with dissolve:
        subpixel True
        truecenter zoom 1.0
        xalign 0.0 yalign 0.0
    fia mad -frusta "阿贾克斯！！！"
    $ fia_events.append("ajax")
    play sound "sound/effects/slap.mp3"
    fia kzl "向[povname]道歉，现在！！！" with vpunch
    show npc_1_m at pic
    npc "是-是的，我-我很抱歉！"
    hide npc_1_m
    fia gross frusta "还有你，阿什姆！"
    show croissant at right with move
    show tom hip kzl blood at left with dissolve:
        yoffset 190
        xzoom -1.0
    fia mad sigh "我不知道你他妈的出了什么问题，但别把我的[kk]牵扯进来！"
    fia kzl -sigh "否则我向科尔发誓，我会挖出你的眼睛，把它们寄给你的家人让所有人都看到。"
    if "come_clean" not in tom_events:
        tom scold cruel cling "...你比世界上任何人都更爱你的[kk]，不是吗，菲亚？"
        fia jijik apa "嗯？这和现在的事有什么关系？"
        show croissant mad -apa
        tom ejek blow "如果我告诉你，你珍爱的[kk]——"
        show tom talk frown -blow
        show red point hister sweat at center with dissolve:
            yoffset 330
        red "哇哦，伙计！"
        show croissant def frown shock
        play sound "sound/effects/blood.mp3"
        tom kzl shock "呃！" with vpunch
        show tom capek frusta
        "塞恩拍打了阿什姆的开放伤口，让他完全闭嘴了。"
        show croissant mad sigh
        red awkward "看起来很疼啊。来吧，我带你去医务室！"
        tom ew -frusta "把你的手拿开！"
        play sound "sound/effects/slap.mp3"
        show red ngeles shock
    else:
        tom "...我很抱歉。我自己去医务室。"
        show red point sad sweat at center with dissolve:
            yoffset 330
        red ngeles "等等，来吧伙计。让我带你去——"
        show red sad 
        play sound "sound/effects/blood.mp3"
        tom sad shock"呃！" with vpunch
        "塞恩把手靠近阿什姆的伤口，轻轻擦过血迹。几乎像是故意的。"
    stop music
    scene kantin with dissolve
    play music "MUSIC/whisper.mp3"
    play sound "sound/effects/tile.mp3"
    "阿什姆甩开了塞恩的手。血滴从塞恩的指尖滴落。"
    "阿什姆大步离开了房间。"
    play sound "sound/effects/door.mp3"
    "你看到莱尔紧随其后。这让你稍微放心了一点，因为如果现在有人能让阿什姆冷静下来，那可能就是他了。"
    "当所有人的注意力都被吸引到门口时，你忍不住盯着塞恩..."
    "...他正贪婪地舔舐着手指上的血，眼睛闪烁着红宝石般的光芒。"
    stop music
    play sound "sound/effects/cloth.mp3"
    show croissant flinch sad at center with dissolve:
        yoffset 500
    fia apa "...你还好吗，[nickname]？"
    play music "MUSIC/MusMus-BGM-146.mp3"
    show croissant at right with move
    if girl:
        show palmierproxy chill frown at left with dissolve:
            yoffset 40
    else:
        show palmierproxy chill frown at left with dissolve:
            yoffset 100
    "你的注意力回到了菲亚身上，她温柔地向你招手。她先前尖锐而命令的语气现在变成了关切的语调。"
    mc smile sweat "呃...还好。"
    show croissant kerja sigh 
    mc huh "（我现在明白为什么奎尔一直说如果菲亚发现我的事会杀了他了。）"
    show palmierproxy frown -sweat
    $ NPC = "普莉姆"
    show prim_ frown at pic
    npc "你刚才看到塞恩舔他的手指了吗？"
    hide prim_
    fia def mmh sweat apa "他舔了吗？我太专注于阿什姆了。"
    show croissant frown -sweat shock
    show prim_ frown at pic
    npc "他确实舔了，我看到了！我知道他是吸血鬼，但他以前从未如此公开地炫耀他的牙齿。"
    hide prim_
    fia gross frusta "他可能只是饿了，塞恩总是过分克制自己。"
    mc scratch confused tanya "是吗？"
    show palmierproxy sad -tanya
    fia flinch jijik sigh "真的吗？你是他的朋友，[povname]。少关心点，好吗？说实话。"
    fia def sad -sigh "他是你唯一的好朋友。比起你那三人组的其他人，他还不算太坏。"
    show croissant frown 
    show prim_ smile at pic
    npc "哦，说到三人组，我听说艾希德娜这个周末要带两个约会对象去参加节日活动。"
    npc "真是个幸运的女孩。"
    hide prim_
    fia gross "那并不意味着什么。我是说，我要带奎尔去。"
    show croissant frown
    show prim_ smile at pic
    npc "说得对。但你知道这个节日以前是一个求爱节吗？男孩们炫耀自己，跳舞来向女孩们证明自己的价值。"
    npc "我的祖父母就是在那个活动后灵魂相连的。这很浪漫。"
    hide prim_
    show palmierproxy malu 
    fia hister sweat "是啊，不过现在，金钱比舞步更有说服力，普莉姆。"
    show croissant hmph -sweat sigh
    show prim_ smile at pic
    npc "哈哈，这话没错！"
    hide prim_
    show palmierproxy chill kind bunga
    show croissant laugh bloom
    "说完这些，女孩们继续她们平常的闲聊，主要是关于这个周末的节日。"
    "你还不太确定这个节日具体是什么，但你希望它能足够分散你的注意力，让你暂时忘记围绕在你身边的所有戏剧性事件。"
    $ night = False
    $ evening = False
    $ afternoon = True
    $ morning = False
    $ NPC = "???"
    scene bg_black with w20
    if "bunga_bego" in buff_events:
        if "beku" in quil_events:
            scene map_infected_f with w20    
        else:
            scene map_infected with w20    
    else:
        if "beku" in quil_events:
            scene map_frozen with w20
        else:
            scene map_all with w20
    jump world_map


label pagi_fia:
    show side_p fr at pic
    play sound "sound/effects/cloth.mp3"
    mc "菲亚，菲亚，醒醒。"
    play music "MUSIC/MusMus-BGM-102.mp3"
    hide side_p
    show croissant sad shock at center with dissolve:
        yoffset 500
    fia "嗯？"
    show side_p fr at pic
    mc "我们睡过头了，要错过早餐了。"
    hide side_p
    fia pity sigh "再给我五分钟。再说了，今天是星期天，周末我只有晚上的课。"
    hide croissant with dissolve
    "说完，她又蜷缩回毯子里，像个茧一样。你很清楚，这绝不会只有五分钟。"
    "你的菲亚也有早起的困难。"
    show side_p mal at pic
    mc "嘿，快起来吧。"
    hide side_p
    "当你试图摇醒她时，你注意到房间里少了些什么，或者更确切地说，少了某个人。"
    "主要是那个你称之为室友的高大壮实的男人。"
    show side_p g at pic
    mc "（嗯，仔细想想，莱尔昨晚回房间了吗？）"
    hide side_p
    if "come_clean" in tom_events:
        "你希望他没有遇到什么不好的事，考虑到你昨晚无意中听到的他和阿什姆的对话。"
        show side_p g at pic
        mc "（我最好稍后去看看那两个人。）"
        hide side_p
    stop music
    play sound "sound/effects/door.mp3"
    show nun proud at right with dissolve:
        yoffset 100
    "就在你还没来得及完成这个想法时，维尔科娃女士大步走进了房间——没有敲门或其他任何预兆。"
    "她就这样大摇大摆地走了进来，仿佛这里是她的地盘，下巴像往常一样高高扬起。"
    nun "[povname]·贝克？"
    show croissant mmh shock at left with dissolve:
        xzoom -1.0
        yoffset 500
    fia err sweat -shock"啊，什么——维尔科娃女士？！"
    show croissant sad 
    nun hand sigh "哦，菲亚也在这里。很好，这样可以加快速度。"
    nun -sigh "校长要求你们两个立即到场。现在就来。"
    mc "为什么——"
    show croissant flinch gross shock
    nun cross frusta"我说了快来！"
    nun "这很紧急..."
    jump princip_fia

label fia_komplen:
    show buff frown apa at center with dissolve:
        yoffset 770
    buff "你要去吃早餐吗，[povname]？"
    show side_p ha at pic
    mc "哦，等一会儿，你先去吧。"
    hide side_p
    buff talk "好的，那我先走了。我今天有早课。"
    play sound "sound/effects/door.mp3"
    hide buff with dissolve
    show side_p fr at pic
    if "ketemu_buli" in buff_events:
        
        mc "（很高兴他恢复得这么快。我几乎看不到他身上有任何瘀伤。不知道这是不是因为他的巫师血统。）"
    else:
        mc "（不知道莱尔昨晚去干什么了。我记不清他什么时候回来睡觉的。）"
    hide side_p
    play sound "sound/effects/bang.mp3"
    queue sound "sound/effects/bang.mp3"
    queue sound "sound/effects/door.mp3"
    "门上传来的剧烈敲击声打断了你的思绪。菲亚冲进房间，看起来比平常更加愤怒。"
    show croissant flinch sad at center with dissolve:
        yoffset 500
    fia gross apa "你昨晚去哪儿了？"
    show croissant at right with move
    if girl:
        show palmierproxy jln sad at left with dissolve:
            yoffset 40
    else:
        show palmierproxy jln sad at left with dissolve:
            yoffset 100
    mc tanya "嗯？"
    play sound "sound/effects/punch.mp3"
    play music "MUSIC/MusMus-BGM-013.mp3"
    show palmierproxy ow sweat shock  with vpunch
    "菲亚猛地打了你的肚子一下，力道不足以让你倒下，但足以让你暂时失去行动能力。"
    show palmierproxy sad -shock
    fia jijik frusta "我说你昨晚去哪儿了？！我到处找你都找不到，我..."
    fia mmh sigh "我需要你！"
    if "blud_dres" not in fia_events:
        mc sad tanya "菲亚...？"
        show palmierproxy frown shock
        show croissant def sad with move:
            xalign 0.2
        play sound "sound/effects/cloth.mp3"
        "毫无预警地，菲亚扑进你的怀里，紧紧抱住你的腰，就像抓住了救命稻草。"
        fia def mmh sigh "昨晚我被泼了一身鱼血。"
        mc pissed -shock "什么？！你没事吧？"
        fia jijik sweat frusta "没事才怪！鱼血浸透了我全身，头发里，眼睛里，连衣服都湿透了。"
        fia sad sigh "我需要我的[kk]。但你不在那里。"
    else:
        fia def kzl frusta "...你为什么不和我一起来？你看到发生了什么。为什么你把我留给奎尔？"
    mc ow frusta "哦，菲亚。我真的很抱歉。"
    if "ketemu_buli" in buff_events:
        mc side sigh "我昨晚和阿什姆还有莱尔在一起。阿贾克斯和他的朋友们试图伤害莱尔。"
        fia sad shock "你说的伤害是什么意思？"
        mc kzl frusta "他试图刺伤我们，他已经把莱尔打得有点惨了。"
        fia gross apa"哦，该死。这倒是个好借口。不过你还好吗？他有伤到你吗？"
        mc wry sigh "我没事。"
        fia wry -sweat sigh "那就好。看来我们昨晚都遇到了麻烦。"
        mc sad -sigh "是啊。不过，我很抱歉没能在你身边。"
        fia malu "没关系，我想。普莉姆帮我处理了大部分事情。"
        
    else:
        mc rajuk "我很担心塞恩。他...昨晚不太对劲。"
        mc side frusta "我担心他可能会伤害到别人。"
        fia jijik apa "那么，他伤害到别人了吗？"
        mc sad sigh "没有，但他几乎无法控制自己。我担心他可能会咬到什么人。"
        show palmierproxy frown -sigh
        fia mmh -sweat sigh "嗯...好吧，我想那可能会很糟糕。他确实表现得很奇怪，不是吗？"
        fia wry -sigh "他通常能控制住自己的欲望。"
    
    fia err frusta "哈...我从未如此丢脸过。"
    fia mad sigh "幸运的是，合唱团的一个孩子说塔图姆是幕后黑手。"
    if "fish_blud" in buff_events:
        fia sad -sigh "就像你说的那样。"
    else:
        mc kzl tanya "塔图姆？"
        fia kzl frusta "一定还在为我当她的替补而耿耿于怀，那个该死的婊子。"
    fia jijik frusta "哦，等我抓到她！我要——"
    stop music
    play sound "sound/effects/door.mp3"
    show croissant at center with move
    show nun proud at right with dissolve:
        yoffset 100
    nun "[povname]·贝克。"
    show croissant flinch frown shock
    "在菲亚说完她的话之前，维尔科娃女士大步走进了房间——甚至没有敲门。"
    "她就这样大摇大摆地走了进来，仿佛这里是她的地盘。像往常一样下巴高高扬起。"
    fia def gross sweat apa "维尔科娃女士？"
    show croissant sad -apa
    nun hand sigh "哦，菲亚也在这里。很好，这样可以加快速度。"
    nun -sigh "你应该换上校服，[povname]。校长要求你们两个都到场。现在就来。"
    mc sad -tanya "为什么——"
    show croissant flinch gross shock
    nun cross frusta"我说了快来！"
    nun "这很紧急..."
    jump princip_fia



label princip_fia:
    play sound "sound/effects/walk.mp3"
    scene map_classes1 with w33
    stop sound
    show tom hip frown at left with dissolve:
        xzoom -1.0
        yoffset 190
    show buff sad sweat at right with dissolve:
        yoffset 770
    if not "ketemu_buli" in buff_events:
        
        show side_p f at pic
        mc "阿什姆？莱尔？你们在这里做什么？"
        hide side_p
        tom chill ha blow "我想和你们两个被叫来的原因一样。"
        tom capek frusta "校长想知道我们昨晚在哪里。"
        tom scold kzl blow "这里的莱尔昨晚卷入了一场相当激烈的打斗。"
        show side_p s at pic
        mc "什么？你没事吧？"
        hide side_p
        buff hister "我没事。阿什姆先生在事态变得严重之前介入了。"
        show side_p s at pic
        mc "你们说的是什么意思——"
        hide side_p
    else:
        show side_p f at pic
        mc "阿什姆？莱尔？你们在这里做什么？"
        hide side_p
        tom scold kzl blow "校长想了解一些昨晚的细节。别担心，我已经解释清楚了。"
        show side_p f at pic
        mc "但如果你们是为此被叫来的，那为什么我——"
        hide side_p
    show nun cross frusta at center with dissolve:
        yoffset 100
    nun "别再磨蹭了。进去吧。"
    play sound "sound/effects/door.mp3"
    scene hm_desk with dissolve
    play music "MUSIC/MusMus-BGM-146.mp3"
    show hm wry at center with dissolve:
        yoffset 190
    "在你能问更多细节之前，维尔科娃女士就把你和菲亚推进了校长办公室。"
    show croissant mad frusta at right with moveinright:
        yoffset 500
    if girl:
        show palmierproxy frown at left with moveinleft:
            yoffset 40
    else:
        show palmierproxy frown at left with moveinleft:
            yoffset 100
    hm talk "啊，贝克兄妹。谢谢你们来。"
    show hm scowl shock
    show palmierproxy sad shock
    fia gross sigh "我们好像没得选择，先生。"
    mc kzl frusta "菲亚！"
    show palmierproxy rajuk sweat -frusta
    hm bet sigh "哈哈，是的，我想你们确实没得选，小家伙们。"
    hm mock cling "既然你这么直率，我想我也应该以同样的方式回应。"
    hm complain -cling "塔图姆小姐、洛克先生和汉普舍先生今天早上被发现遭到殴打并失血过多。"
    show palmierproxy sad -sweat shock
    fia flinch sad sweat shock "等等，什么？！"
    hm sad sigh "三人的脖子上都有严重的割伤，几乎失血致死。他们能活下来简直是个奇迹。"
    hm bingung -sigh "这要多亏了镇上的居民。目击者说他们在凌晨2点发现他们躺在自己的血泊中。"
    hm wry "我能问问你们两个在那个时候在做什么吗？因为似乎没有人记得在节日附近看到过你们。"
    if "ama_fia" in fia_events:
        mc kzl -sweat sigh "她和我在一起。你为什么要问这个？"
        fia def gross -sweat apa "你认为我们和这件事有关？"
    else:
        if "ketemu_buli" in buff_events:
            mc rajuk sigh "我和阿什姆还有莱尔在一起。"
            hm scowl sigh "啊，阿贾克斯事件。那也是个问题，不过是另一个时候要讨论的问题。"
        else:
            mc frown -shock "我和塞恩在一起。"
            hm sad "那晚他的状态如何？"
            fia def jijik -sweat frusta "听着，老头。如果你想把这事栽赃给塞恩，就因为他是个吸血鬼，那我就要举报你是个种族主义的偏执狂，他——"
            hm laugh sigh "冷静点，小贝克。原谅我，我并不是想指责你。"
            fia mad sigh "嗯，你的措辞似乎暗示了其他意思。"
        fia gross apa "别再闲聊了，好吗，教授？你认为我们是这件事的幕后黑手，对吧？"
    hm amused sigh "恐怕是的，小家伙。"
    show palmierproxy frown shock
    hm yell -sigh "我很清楚你和塔图姆之间的敌意。事实上，其他学生向我报告说，昨晚你的裙子事件就是她搞的鬼。"
    show palmierproxy kzl -shock
    show hm scowl
    fia kzl apa "那又怎样？你认为我会立即报复，在血还从我的头发滴到眼睛上的时候？"
    show croissant mad -apa
    hm mock cling "所以你本来是想报复的。或者至少你在考虑这么做。"
    show hm scowl -cling
    fia gross sigh "当然我会报复。你把我当成什么了？一个体面的年轻淑女吗？"
    fia annoyed -sigh "但是先生，有件事我比报复更在意，那就是我的头发。"
    fia mock cling "我没有碰塔图姆或她的跟班。我的[kk]可以为我作证。"
    show palmierproxy sad
    show croissant mad -cling
    hm frown "你的[kk]远不是一个可靠的证人。"
    hm confused apa "事实上，谁能说[kamu]没有替你报仇呢？"
    show pboy at horzappear
    menu:
        "我没有这么做。":
            hide pboy
            $ curiosity -= 10
            $ honesty += 10
            $ kindness -= 5
            $ kindness -= 10
            if kindness < 0:
                $ kindness = 0
            hm scowl sigh "嗯。好吧，我也没指望你会承认什么。"
            
        "你可以对我使用真言药水。":
            hide pboy
            $ curiosity += 10
            $ honesty += 20
            $ kindness -= 5
            $ kindness -= 10
            if kindness < 0:
                $ kindness = 0
            fia sad frusta "啊？？？不行！你不能同意使用吐真剂。看在科尔的份上，你对那玩意儿有致命的过敏反应！"
            mc apa tanya "是吗？"
            hm scowl sigh "啊对，我记得你一年级时的那次事件。真是可怕。"
            mc panik -tanya "（而且非常方便。）"
            show palmierproxy frown 

        "他们会没事吗？":
            hide pboy
            $ kindness += 10
            $ honesty -= 10
            hm sad sigh "他们需要在医院休养一两周，但会康复的。"
            hm frown -sigh "我们的学生比大多数人更有韧性。"
            if "curhat_dance" in red_events:
                mc confused tanya "你确定他们是被割伤而不是被咬伤的，对吧？这就是为什么他们失血那么多？"
                hm bet cling "你是在暗示什么吗，[povname]？"
                mc ew -tanya"（昨晚的塞恩...他把一切都控制住了，对吧？）"
                mc deject "...没有，先生。"
    show palmierproxy frown
    fia mad frusta "就这些吗，先生？我的意思是，在我看来，你现在只是在胡乱猜测。"
    fia mock cling "可能是因为你不能问塔图姆本人吧？"
    hm yell frusta "不。不幸的是，塔图姆小姐和她的朋友们仍然处于昏迷状态。"
    show hm scowl sigh
    fia jijik sigh "我就知道。听着，塔图姆和我相处不好，没错。但那更多是她的问题，而不是我的。"
    fia annoyed -sigh "因果报应就是个婊子，她得到了应得的，仅此而已。"
    mc sad frusta "菲亚..."
    fia gross apa "什么？"
    mc side sweat "（我是说，她说得没错，但她的陈述也不能让她看起来很好。）"
    show palmierproxy frown -sweat -frusta
    fia annoyed "总之，我们结束了，对吧？所以..."
    show croissant flinch kzl shock
    hm yell frusta "[povname]可以离开了，是的。但是你，年轻的女士，需要上一堂礼仪课。"
    hm mock cling "维尔科娃女士和我很乐意提供。也许在你上早课之前，需要快速学习一下我们学院的核心价值观。"
    show hm smile sigh
    fia sad "什么我——？"
    hm talk cling "坐下，菲亚，拜托。你说得越多，这事就越拖长。"
    show hm smile -cling
    fia def jijik frusta "...哈。"
    show croissant sad sigh
    mc scratch confused tanya "要我留下来吗？"
    show croissant frown shock
    "菲亚温柔地对你笑了笑，但即使是她也对这个建议挑了挑眉。"
    fia wry -sweat sigh "走吧...我习惯了，小抱怨鬼。"
    mc chill wry sigh "好的。再见，菲亚。"
    fia hister -sigh "再见。"
    stop music
    play sound "sound/effects/door.mp3"
    queue sound "sound/effects/walk.mp3"
    jump done_inter
    
label done_inter:
    scene map_classes1 with w33
    show tom hip frown at center with dissolve:
        yoffset 190
    tom "审问结束了？"
    stop sound
    play music "MUSIC/MusMus-BGM-117.mp3"
    show tom at right with move
    if girl:
        show palmierproxy frown shock at left with moveinleft:
            yoffset 40
    else:
        show palmierproxy frown shock at left with moveinleft:
            yoffset 100
    mc "阿什姆！"
    "阿什姆在门口迎接你，他的背靠在你对面的墙上。"
    if "come_clean" in tom_events:
        tom talk apa "我在等你。他想要什么？菲亚在哪里？"
        mc side frusta "还在里面，这...这很复杂。"
        tom smile -apa "边吃早餐边给我解释一下？"
        mc wry -frusta "当然，就我们两个人？"
        tom ha frusta "……不。我想我应该道歉。"
        tom sigh blow "至少对红说。对奎尔也是，不过得等他先道歉。"
        show tom pfft -blow
        mc hister sigh "祝你好运。"
        tom giggle "哼，你说得对，我还不如等着猪会飞呢。"
        tom amused apa "不过，我确实想念他们。帮我打破僵局好吗？"
        mc kind cling "乐意之至。"

    else:
        tom ha apa "菲亚在哪里？"
        mc rajuk sigh "还在里面。"
        tom sad "有什么严重的事吗？"
        mc confused "我不知道，而且你为什么问这个？我以为你在无视我。"
        tom nyesal frusta "为此我向你道歉。昨晚发生了一些事，让我……嗯，让我意识到我其实没有理由生你的气。"
        tom sad blow "你只是在按奎尔的要求行事，而且你显然不是自愿卷入这一切的。"
        tom wry apa "我很抱歉，[povname]，真的。我们算是熟人了吗？"
        "阿什姆向你伸出手，显然希望你能握住。"
        mc malu tanya "大多数人不是都会要求成为朋友，而不是熟人吗？"
        tom amused cling "哎呀[povname]，你可真直接。我们才认识一周左右。时间会告诉我们这段关系能持续多久。"
        mc mock cling "你可真是个油嘴滑舌的家伙，是不是？"
        show tom pfft -cling
        show palmierproxy smile -cling
        "你握住阿什姆的手摇了摇，他似乎对你的回应很满意。"
        mc huh "所以只有我值得你道歉，还是——"
        show palmierproxy wry
        tom sigh blow "好吧，我想这也不错。重新建立我与其他人的友谊……如果你愿意帮我的话。"
        mc wry "我会的。边吃早餐边聊如何？"
        tom wry -blow "你读懂了我的心思。"
    tom ha -apa "哦，不过我们先把这些制服换下来吧。我可不想整个周末都穿着这些。"
    stop music
    play sound "sound/effects/walk.mp3"
    jump sarapan

label sarapan:
    stop sound
    $ tom_events.append("tom_conf")
    $ tom_events.remove("sulk")
    scene kantin with w33
    play music "MUSIC/MusMus-BGM-022.mp3"
    show tom go sad at center with dissolve:
        yoffset 190
    show red bebas sad behind tom at left with moveinleft:
        yoffset 330
    show quil libur sulk at right with moveinright:
        yoffset 200
    "餐桌上弥漫着沉重的期待气氛，奎尔和塞恩都不耐烦地盯着阿什姆。"
    "他们的目光如此专注，仿佛把阿什姆冻在了原地，不知道该说什么。"
    "更糟的是，他们双手托腮盯着他，就像在摆造型拍什么该死的魅力写真似的。"
    show tom capek both
    "阿什姆的耳朵红得像甜菜根，脸上的红晕因为所有这些不必要的关注而蔓延开来。"
    show pboy s at horzappear
    menu:
        "盯着他":
            $ ibu.points -= 15
            if ibu.points <0:
                    $ ibu.points = 0
            hide pboy
            show tom eh shock
            "出于好奇，你决定跟随他们的做法，盯着阿什姆。他整个人都变得通红。"
            tom nyesal frusta"……我要走了。"
            show tom whine shock
            show side_p sdh at pic
            mc "等等，不要！不！快点道歉吧！"
            hide side_p
            tom capek frusta "如果你们能别再这样窥视我的灵魂，我就道歉。"
            tom sigh blush blow "这太尴尬了。"
            quil wry sweat "抱歉，我只是不知道从何说起。"
            quil cringe "不过我想\'我错了\'或\'对不起\'应该可以。虽然不知道这是否有意义。"
            tom ha sweat -blow "确实没有……至少在[povname]醒来之前没有。"
            tom amused -sweat blow "在那之前我们别自相残杀，好吗？"
            "阿什姆伸出手想要握手。"
            play sound "sound/effects/cloth.mp3"
            show quil hister blush bunga with move:
                xalign 0.75
            tom sad shock"哎呀！" 
            "奎尔把这当成了拥抱的邀请。不过阿什姆似乎并不介意。"
            show tom giggle blush bunga

        "开始说话":
            $ ibu.points += 5
            hide pboy
            show side_p fr at pic
            mc "那么——"
            hide side_p
            quil ow sweat "我非常抱歉！"
            play sound "sound/effects/cloth.mp3"
            show quil sad with move:
                xalign 0.75
            "奎尔开始不停地鞠躬，握了握阿什姆的手，然后把他拉进一个拥抱。"
            show tom frown blush shock
    quil sulk sweat frusta "我真的不是有意对你和红撒谎的，只是……我真的搞砸了，我害怕你们两个会有什么反应，所以——"
    tom pfft -blush blow "好了，好了。不过如果你再不放开我，我就要收回我的道歉了。"
    tom giggle -blow "你知道的，我可是要维护自己的声誉。"
    show tom smile
    show quil hister -sweat bunga at right with move
    "奎尔从阿什姆身上挪开，擦去了眼泪。"
    red hister both apa "……我能得到一个拥抱吗？我是说，和这两个人比起来，我什么错都没有，可你还是把我晾在一边了。"
    show tom frown shock
    tom wry -shock"抱歉。"
    show red sayang shock
    "阿什姆用有力的手拍了拍塞恩的肩膀。塞恩张开双臂将阿什姆拉入一个紧紧的熊抱中。"
    play sound "sound/effects/cloth.mp3"
    show tom giggle blush bunga
    show red hister blush bunga
    "他把阿什姆举离地面一两次。阿什姆设法继续拍着他的背。"
    tom pfft blow -blush "看来我们有些糟糕的朋友，不是吗，红头发？"
    red wry -blush sigh "你说得对。不过，我们还是要拼命去救[povname]，并为奎尔那家伙的罪行擦屁股，对吧？"
    tom calm -blow "看来是这样。"
    quil wry bloom "哈……我爱你们这群家伙。"
    show quil hister blush
    show red cowo blush bloom
    show tom giggle blush bunga
    "这一次你感到格格不入。你假装成他们的[povname]已经很久了，以至于忘记了自己是个局外人。"
    "你是他们长久而古怪友谊中的新成员。你几乎想逃开去找菲亚，但奎尔似乎注意到了你的不适，于是将手臂搭在你的肩膀上。"
    quil mock cling "还有你，[povname]，你这个无可救药的傻瓜。你还没死真是个奇迹。"
    quil wink spark "不过，我永远感激你的配合。要是你能让我在更……亲密的场合表达我的感激之情就好了。"
    "你收回前言，去他妈的这群怪胎。"
    show side_p ha at pic
    mc "尽管试试看啊，处男。"
    hide side_p
    show quil ow both frusta
    "当你低声说出这些话时，奎尔小心翼翼地后退了一步。他很注意不去触碰你的敏感神经，如果有的话。"
    show quil tantrum sweat sigh
    red cowo apa "顺便问一下，\'伙伴行动\'的计划是什么？"
    show red datar -blush -apa
    tom ha sweat apa "我们是这么称呼它的吗？"
    show tom sad -apa
    red amused sigh "我本想叫它\'睡美人行动\'，但奎尔说他是我们小组里最漂亮的那个。"
    tom pfft blow "得了吧，奎尔，我们都知道事实并非如此。"
    quil heh -sweat -sigh "人总是可以做梦的嘛。"
    show pboy s at horzappear
    menu:
        "我觉得你很帅，奎尔。":
            $ bff.points += 1
            hide pboy
            quil wink cling "看到了吗？"
            red ew sweat frusta "看来你和我们的[povname]在择偶品味上都很糟糕啊。"
            tom kzl shock"嘿！"
            red hister -sweat sigh "这是事实，不是吗？"
            quil heh -cling "确实如此。现在言归正传，我们该如何拯救我们亲爱的[povname]呢？"
        "但我才是最漂亮的。":
            hide pboy
            tom pfft blow "我看[povname]在所有世界里的自信都是一致的。"
            quil heh "好吧亲爱的，你是一件绝妙的艺术品。现在，我们该如何拯救那个我们称之为朋友的混蛋呢？"
    tom sad apa "别告诉我你没有计划。"
    show tom kzl shock
    show red wry sigh
    quil panik sweat "好吧我不说，我只是在拖延时间，而我们的朋友正在慢慢消逝，醒来后可能会也可能不会有脑部问题，但是——"
    red huh sweat apa "所以你没有追踪到其他巫师？"
    show red frown -sweat -apa
    show tom frown -shock
    if "help_me" in my_events:
        quil groan frusta "没有，我也没能从迪特里希那里得到什么线索。那个贪婪的混蛋现在似乎对他的俱乐部更感兴趣。那个混蛋。"
        quil rajuk sigh "不过我猜莱利是安全的，至少还有这点。"
    else:
        quil groan frusta "没有，我也没能从迪特里希那里得到什么线索。那个贪婪的混蛋现在忙着接管梅扎的俱乐部，因为现在那里无人经营。"
    show quil frown -sweat shock
    show side_p fr at pic
    mc "嗯，其实我可能有个线索。"
    hide side_p
    tom ha -sweat apa "真的吗？"
    show side_p fr at pic
    mc "有一个我一直在见的巫师，全身穿着黑衣。"
    show side_p sdh
    mc "她说了些关于一个人类和巫师试图成为神的墓穴。"
    show side_p fr
    mc "那个地方的内部全是白色石灰岩，看起来像是一座地下教堂的内部，被水淹没了。有什么想法吗？"
    hide side_p
    tom frown -sweat -apa "你说一座被淹没的教堂？"
    red mls "文斯的水之教堂？"
    quil rajuk apa "那里全是黑色的。嗯。问题是，里面有王座吗？"
    show side_p sdh at pic
    mc "王座？没有，只有中央有一根柱子，上面放着一顶王冠。"
    hide side_p
    quil sad sigh "那就排除了雷霍德塔。"
    red huh apa "……你确定那水只是普通的水，不是血，对吧？"
    show side_p fr at pic
    mc "血？不，是清澈的。可能是水、圣水或者海水。我不确定。"
    hide side_p
    red sayang sigh "好吧，至少不是阿列克谢的巢穴。那地方我可是敬谢不敏。"
    tom kzl apa "他的巢穴周围是一池血？"
    red ow sweat frusta "四个，全都围绕着他的床。"
    show red wry -frusta
    tom capek blow "真俗气。"
    show tom frown -blow
    if "blud_redi" not in red_events and "curhat_dance" not in red_events:
        show side_p sdh at pic
        mc "说到血，塞恩，昨晚你身上发生了什么？"
        hide side_p
        red ngeles apa "什么？你是什么意思？"
        show red -apa
        if "blud_redi" in red_events:
            quil grit frusta "哦，我一直想问你这件事，雷德。昨晚你到底怎么了？"
            tom ha apa "我错过了什么吗？"
            show tom kzl -apa
            quil rajuk sigh "塞恩...我相信他试图咬菲亚。"
            red ow sweat shock "不是那样的，我..."
            red perih frusta "我只是饿了，好吗，但现在我没事了。"
            red sayang -frusta"不会再发生了！"
            if "cuhat_dance" in red_events:
                show side_p sdh at pic
                mc "但是塞恩，昨晚当我们——"
                hide side_p
                red hister "我说了我没事啦。只是，饿得发怒，你懂的？"
                quil sulk sweat sigh "雷德，有\'我很好\'，\'我感觉糟糕\'，然后是\'我没事\'。说真的，如果有什么我们需要知道的——"
                show quil bingung 
                red lelah -sweat frusta "听着，我们有更多需要担心的事情，好吗？比如我们现在正处于昏迷状态的亲爱的朋友。"
                red wry -frusta "让我们把注意力集中回那上面，好吗？"
                show red so 
                show tom sad 
                show side_p sdh at pic
                mc "...好吧，如果你这么说的话。"
                hide side_p
        else:
            show side_p sdh at pic
            mc "关于你的血液问题？"
            hide side_p 
            red kaget apa "等等，你是在说发生在塔图姆身上的事吗？"    
            show red huh -apa
            show side_p fr at pic
            mc "你知道那件事？"
            hide side_p
            tom ha blow "整个学校都知道，多亏了我们那个爱说闲话的图书管理员。"
            show side_p sdh at pic
            mc "当然。"
            hide side_p
            red lelah frusta "如果你是想说那是我干的，那你就错了。那天晚上还有其他几个吸血鬼，他们中的任何一个都可能做了这事。"
            show red so sigh
            show side_p fr at pic
            mc "等等，所以你确实认为是吸血鬼干的？"
            hide side_p
            red kzl -sigh "...无可奉告。总之我们不应该把注意力集中在[povname]身上吗？"
        show red frown -sweat shock
        show quil frown -sweat shock
        tom frown -blow "实际上，我可能知道[povname]在说什么。"
        tom ha "或者至少知道谁能给我们指明正确的方向。你说的是人类试图成为神的地方，对吗？"
        show side_p fr at pic
        mc "是的？"
        hide side_p
        tom amused cling "海德温。"
        show side_p fr at pic
        mc "什么？"
        hide side_p
        tom frown -cling "我以前听过这句话。是海德温女士说的。"
    else:
        quil err apa "...等等，在你的梦中，那个巫师说了\'人类试图成为神的坟墓\'这句话？"
        show side_p fr at pic
        mc "是的？"
        hide side_p
        quil rajuk -apa "海德温不是在她的一次布道中说过类似的话吗？"
        red huh apa "是吗？我从来不听。"
        tom frown shock "哦，我现在想起来了。她在讨论我们学校的创始人之后提到过这个。"
    tom ha blow "她说这所学校要么是被祝福的，要么是被诅咒的。它可能是从一位神的灰烬中崛起，或者是从一位神的谋杀中诞生的。"
    if "talk_hen" in my_events:
        show side_p fr at pic
        mc "我之前确实和海德温女士谈过这个。"
        mc "她说这只是她听说的，她不知道我们学校下面是否真的有什么东西。"
        hide side_p
        tom kzl "她是在真言药剂的作用下告诉你的吗？"
        show side_p fr at pic
        mc "呃，不是，但是...嘿，你不能为了得到答案就给我们的老师下药！"
        hide side_p
        tom ejek cling "好吧，我不会。奎尔，你来做。"
        quil wink cling "没问题。"
        show side_p k at pic
        mc "喂！"
        hide side_p
        red ow frusta "得了吧伙计们，这件事我同意[povname]的看法。再说，海德温也不是最可靠的情报来源。"
        red sad sigh "你不得不承认她说的有些事情有点..."
        tom capek "是的，我们都知道海德温女士的古怪之处，但她说的一些事情确实带有一些历史和科学依据。"
        tom frown "这可能就是其中之一。"
        quil datar -cling "我会去图书馆做更多研究。"
    else:
        quil heh sigh "那我们就去问她吧。她有时可能有点自负，但她说的一些事情确实带有一些历史或科学依据。"    
        tom frown -blow "我会在图书馆做更多研究。"
    show tom pfft shock 
    red mls frusta "所以我们能做的就是四处打听和做研究？呃，这有点...无聊。"
    quil cringe sigh "我是说，上周我们差点被一个巫师消灭了。这对你来说还不够刺激吗，雷德？"
    red ngeles frusta "嗯，是的，但你和我都被打晕了。阿什姆和[povname]才是真正决斗的人。"
    red ew "我以为至少会有更多，我不知道，更刺激的事情？"
    show red sad -frusta
    show tom frown -shock
    quil wink cling "如果你真的那么喜欢刺激，我知道有件事能满足你的渴望。"
    show red wry -sweat
    tom ew sweat frusta "看在科尔的份上，奎尔，我们告诉过你群交不是——"
    show tom kzl
    show red frown
    quil heh sigh "我是说我们可以接受一个任务。我可不是24小时都在发情，谢谢。我又不是兔子。"
    quil datar -sigh "你们没看到那个幽灵任务吗？"
    show side_p fr at pic
    mc "...什么？别告诉我你们这里也有幽灵？"
    hide side_p
    quil rajuk "没有，但问题就在这里。宿舍里的一些孩子看到我们房间里的科尔雕像在流血。"
    quil datar "他们说这只会发生在凌晨3点，而且必须先说三遍\'engela vis tera\'。"
    tom ha blow "为什么恶魔总是对数字三如此执着？"
    show side_p fr at pic
    mc "在我的世界里，凌晨3点被称为巫师时间。也许是巫师干的？engele vis...那个什么意思？"
    hide side_p
    red cowo cling "你的天使之血。嗯，听起来很有趣，想去看看吗？"
    tom kzl frusta "我们为什么要去？这简直是浪费时间。"
    quil malu apa "阿什姆，你该不会是害怕了吧？"
    tom ha both "那是..."
    show side_p ha at pic
    mc "怎么？阿什姆，你害怕幽灵吗？"
    hide side_p
    tom capek frusta "我可是面对过凶猛的狼人和可怕的巫师。别说笑了！"
    red grin -cling "那就去看看吧。反正你的房间是空的。"
    tom whine sweat shock "不行！如果你们这么做，那幽灵就会——"
    show side_p fr at pic
    mc "（哦，原来他{i}真的{/i}害怕。）"
    hide side_p
    show tom capek frusta
    show red hister
    show quil hister sigh
    if "sucker3" in completed_quests and "bye_boner" not in quil_events:
        show side_p ha at pic
        mc "我是说，阿什姆，你欠我一个人情。还记得我们的小赌约吗。"
        hide side_p
        tom ha apa "你居然把它浪费在这种事上？？？"
        show tom sad -apa
        show side_p ha at pic
        mc "我是说，你不会是害怕了吧？"
        hide side_p
        tom sigh blow "...好吧，随你们便。"
    else:
        red cowo "来吧伙计，这会很有趣的。再说了，我相信什么事都不会发生。就当是你对我的补偿吧。"
        red sayang "因为你知道我不该受到你对奎尔和[povname]那样的对待。"
        tom sigh blow "...好吧。"
    quil wink cling "太棒了，那我们凌晨3点在阿什姆的房间见！"
    tom whine frusta "...我怎么又和你们和好了？"
    show tom sad 
    red hister blush "物以类聚，阿什姆。恐怕你甩不掉我们了，伙计。"
    play sound "sound/effects/cloth.mp3"
    show red cowo bloom
    show quil hister blush bloom
    show tom capek both blow
    "塞恩拍了拍阿什姆的前臂，用一种坚定却有些尴尬的方式搂住了他的脖子。"
    show tom calm blush bunga
    "尽管他嗤之以鼻，但你能看到阿什姆嘴角微微上扬，露出一丝淡淡的笑容。"
    show tom pfft
    "奎尔拍了拍他的头发，他的笑容更灿烂了。"
    scene bg_black with w20
    "你在想今晚是否真的能看到幽灵。"
    $ my_events.append("ghosts")
    $ night = False
    $ evening = False
    $ afternoon = True
    $ morning = False
    $ NPC = "???"
    if "bunga_bego" in buff_events:
        if "beku" in quil_events:
            scene map_infected_f with w20    
        else:
            scene map_infected with w20    
    else:
        if "beku" in quil_events:
            scene map_frozen with w20
        else:
            scene map_all with w20
    jump world_map

label ghost_time:
    pause 1.0
    scene bed_alter with eye_open
    $ my_events.append("ghost_time")
    play sound "sound/effects/cloth.mp3"
    "你在凌晨2:30左右醒来，确保动作非常缓慢，不想吵醒莱尔。"
    show buff frown at center with dissolve:
        yoffset 770
    "然而，令你惊讶的是，他已经醒了，正从床的另一边盯着你。"
    buff eh apa "呃，[povname]？"
    show buff frown -apa
    show side_p f at pic
    mc "哦，莱尔，我吵醒你了吗？" 
    hide side_p
    buff wry sigh "不，不，不是那样的。你待会要去阿什姆的房间，对吧？"
    show side_p he at pic
    mc "哦，你怎么知道的？"
    hide side_p
    buff hister sweat -sigh "阿什姆想让我一起去。他让我穿上制服，以防万一。"
    show side_p f at pic
    mc "以防什么呢？"
    hide side_p
    buff frown "老实说，我也不太确定，但他说我能提供很好的保护。"
    show side_p s at pic
    mc "保护？"
    hide side_p
    buff wry sigh "我和你一样困惑，但我不忍心拒绝。"
    show side_p a at pic
    play sound "sound/effects/door.mp3"
    mc "我明白了，人多热闹。那就一起来吧！"
    play sound "sound/effects/walk.mp3"
    hide side_p    
    play music "MUSIC/MusMus-BGM-016.mp3"
    scene kmr_malam with w33
    show buff frown at right with dissolve:
        yoffset 770
    show tom hip capek at center with dissolve:
        xzoom -1.0
        yoffset 190
    show quil datar at left with dissolve:
        yoffset 200
    "当你和莱尔进入阿什姆的房间时，奎尔和阿什姆迎接了你们。塞恩还是不见踪影。"
    show side_p f at pic
    mc "塞恩在哪里？"
    hide side_p
    tom scold pfft sweat "也许他还在睡觉。好吧，最好不要打扰他。我们都回自己的房间去吧——"
    show tom sad
    quil heh cling "别想蒙混过关，宝贝。离3点还有半个小时左右，他会来的。"
    tom sigh blow"哈。"
    show tom nyesal -blow
    show side_p a at pic
    mc "老实说，我没想到你会是那种害怕幽灵的人，阿什姆。"
    hide side_p
    tom ha frusta "我告诉过你我不怕。"
    quil amused cling "嗯。顺便说一下，是莱尔对吧？听说阿什姆把你拉进这件事里了。"
    show buff sad sweat shock
    quil hister bloom "我能不能说，我从未见过如此波澜壮阔的胸肌？"
    quil sly cling "告诉我，你以前和其他男人在一起过吗？如果没有，我很乐意做你的导师。"
    show side_p he at pic
    mc "（是啊，没错。）"
    hide side_p
    buff keluh -shock "啊？什么？我，呃..."
    show buff sad 
    play sound "sound/effects/bump.mp3"
    tom kzl frusta "奎尔，住口。"
    quil sulk sigh "啧。"
    show tom -frusta
    show quil frown -sigh
    show side_p a at pic
    mc "别在意奎尔，莱尔。他叫得比咬人厉害。"
    show side_p f 
    mc "塞恩到底在哪里，我们要不要叫醒他？"
    hide side_p
    hide buff with dissolve
    show red speck ngeles sweat at right with dissolve:
        xzoom -1.0
        yoffset 330
    play sound "sound/effects/doorslam.mp3"
    red "对不起，我来晚了！"
    show red wry
    show tom frown -sweat shock
    show quil frown shock 
    "正说着，塞恩冲进了房间，他的制服上还溅着些许血迹。"
    "你注意到他的眼睛周围仍有一圈红色。"
    show side_p s at pic
    mc "（他一直在进食吗？）"
    hide side_p
    quil bingung apa "你去哪里了？"
    red sayang "猎杀老鼠，你知道的，老规矩。"
    quil ow sweat frusta "呃，你衬衫上是老鼠的汁液吗？离我五英尺远，你这个野蛮人！"
    red hister "哦，对不起。"
    show red mock -sweat
    "他用手套擦掉了血迹，舔掉了多余的部分。"
    show side_p f at pic
    mc "（那太不卫生了。他真的那么饿吗？）"
    hide side_p
    "在你能问出口之前，塞恩打断了你。"
    red wry "那么，想试试吗？"
    quil frown sigh "还没到三点呢。"
    red sayang "差不多了。"
    show side_p f at pic
    mc "你为什么这么着急？"
    hide side_p
    red hister sweat "哦，只是太累了。哈哈，今晚一直在猎杀，都没睡觉。"
    show side_p f at pic
    mc "嗯。"
    hide side_p
    tom capek frusta "好吧，我也想尽快结束今晚的事，所以..."
    tom whine blow "莱尔，你来做吧。"
    hide red with dissolve
    show quil frown
    show buff eh sweat at right with dissolve:
        yoffset 770
    buff apa "嗯？"
    show buff sad -apa
    show tom sad with move:
        xalign 0.56
    "阿什姆退到莱尔身后，他的身形完全被莱尔高大的体格遮住了。"
    tom "你是半个巫师。这一定使你不那么容易受到攻击。如果这个鬼魂真的是个巫师的话。"
    quil kzl frusta "嘿，别独占莱尔，我也想被一个高大强壮的男人保护！"
    show quil hister blush -frusta with move:
        xalign 0.66
    "奎尔紧紧抱住莱尔的前臂，像抱着抱枕一样缠在他身上。"
    buff keluh both "我呃，嗯..."
    "看到莱尔慌乱的样子，你决定..."
    show buff sad
    show pboy at horzappear
    menu:
        "也抱住他":
            hide pboy
            play sound "sound/effects/cloth.mp3"
            show buff keluh both shock
            "喜欢看到他脸颊上泛起的红晕，你抓住他空闲的手臂，用双臂环绕住它。"
            "莱尔变得更加慌乱，因为他的两只手臂都被缠住了，而阿什姆则把头靠在他宽阔的后背上。"
            buff keluh both shock"什么？！我，呃，啊——"
            scene kmr_malam with dissolve
            show red speck ew at center with dissolve:
                yoffset 330
            red frusta "看在科尔的份上。我可没时间干这个！"

        "说出咒语":
            hide pboy
            show side_p f at pic
            mc "Engele，virde，呃，接下来是什么来着？"
            hide side_p
            scene kmr_malam with dissolve
            show red speck ew at center with dissolve:
                yoffset 330
            red frusta "哦科尔啊，让我来吧。"
    stop music
    play music "MUSIC/whisper.mp3"
    red so sigh "Engela vis tera。"
    scene altar_bunga with fade:
        truecenter zoom 0.5
        easein 20 truecenter zoom 1.5
    "起初什么也没发生。然而，阿什姆更紧地抱住了莱尔，以防万一。"
    show side_r skul kzl at pic
    red "Engela vis tera。"
    hide side_r
    play sound "sound/effects/nangis.mp3"
    
    "现在可以听到轻微的啜泣声。一阵寒意顺着你的脊背窜下，因为你没有准备好听到这种声音。"
    show side_p s at pic
    mc "这是什么...？"
    hide side_p
    show side_t skul sad at pic
    tom "哦，科尔！"
    hide side_t
    show side_b skul sad  at pic
    buff "等等，阿什姆先生，你抱得太紧了！"
    hide side_b
    show side_r skul frown at pic
    red "...Engela vis tera。"
    hide side_r
    play sound "sound/effects/splat.wav"
    scene ink_cry with rain1
    stop sound
    "黑色的液体从雕像的眼睛里流下。随着黑色液体在雕像脚下汇聚，啜泣声变得更大了。"
    show side_r skul kzl at pic
    red "我的天啊！"
    hide side_r
    show side_q skul kzl at pic
    quil "那是……墨水吗？"
    hide side_q
    stop music
    scene kmr_malam with fade
    show red speck frown at left with dissolve:
        yoffset 330
    show quil frown at right with dissolve:
        yoffset 200
    "塞恩和奎尔似乎对这种奇怪的液体产生了兴趣。他们走近雕像，奎尔甚至用手帕取了一些样本。"
    show tom chill sad sweat at center with dissolve:
        yoffset 190
    "两人似乎对这一事件毫不在意。然而，阿什姆却完全呆住了。他的眼睛一动不动地盯着眼前的景象。"
    show side_p f at pic
    mc "阿什姆？阿什姆！"
    hide side_p
    play sound "sound/effects/cloth.mp3"
    tom nyesal "..."
    play sound "sound/effects/crash.mp3"
    play music "MUSIC/MusMus-BGM-146.mp3"
    hide tom with vpunch
    "毫无预警地，阿什姆晕倒在地，他的头重重地撞在大理石地板上。"
    show buff keluh sweat shock at center with dissolve:
        yoffset 770
    buff sad -shock "阿什姆先生！！！"
    quil rajuk sigh "哦，他比我想象的还要胆小。"
    red ngeles sweat "我现在有点感到内疚。你觉得他会没事吗？"
    quil hister -sigh "他不会有事的。"
    show red sayang -sweat
    show pboy at horzappear
    menu:
        "你们两个也太淡定了。":
            hide pboy
            $ kindness += 15
            $ curiosity -= 15
            red awkward apa "是吗？啊，我想我是在期待更刺激的事情。比如说一个完整的幽灵出现之类的。"
            show red wry -apa
            quil bingung cling "我对这种奇怪的物质更感兴趣。它到底是什么？"
            buff keluh frusta "现在是讨论这个的时候吗？我们不应该把他送到医务室吗？"
            
        "奎尔，你取样是要做什么？":
            hide pboy
            $ curiosity += 5
            quil panik sweat "哦，只是做个测试，亲爱的。你不用担心。"
            show side_p s at pic
            show quil hister -sweat
            mc "（这意味着你应该非常担心。）"
            hide side_p
            buff keluh apa "呃，我们该怎么处理阿什姆？要把他送到医务室吗？"
            
            
        "塞恩，你刚才去哪里了？":
            hide pboy
            $ honesty += 5
            red wry sweat "哦，嗯，你知道的，就像我说的，在楼下。捕捉老鼠。"
            show side_p f at pic
            mc "一个人？"
            hide side_p
            $ red_events.append("nanya_vilkov")
            red sayang "维尔科娃今晚很忙。在她房间里找不到她。"
            quil heh "可能在和凯普勒先生幽会吧。我很确定他们是一对。"
            red amused "她和凯普勒？嗯，我能想象得到。"
            buff keluh apa "现在是讨论这个的时候吗？我们不应该把他送到医务室吗？"
            
    show buff frown -sweat shock
    quil amused sigh "就把他放在床上吧，他会没事的。只是受到了惊吓而已。"
    red sayang sigh "他会没事的！"
    show side_p f at pic
    mc "你们两个真是糟糕的朋友。"
    hide side_p
    play sound "sound/effects/cloth.mp3"
    hide buff with dissolve
    "尽管如此，莱尔还是把阿什姆抱到了床上。他拍了拍枕头，轻轻地给阿什姆盖上被子。"
    show side_p f at pic
    mc "（至少莱尔还有点人性。我想如果我在这里待得太久，可能也会变得像这两个混蛋一样麻木不仁。）"
    hide side_p
    red cowo -sigh "总之，这很有趣。看来传言是真的啊。"
    show side_p f at pic
    mc "是啊，但这意味着什么呢？"
    hide side_p
    red amused "这重要吗？我是说，这所学校里有很多奇怪的东西。不管怎样，哈欠……我累了，我得走了。"
    hide red with dissolve
    play sound "sound/effects/doorslam.mp3"
    "塞恩匆忙离开了房间，砰的一声关上了门。"
    show quil frown at center with move
    show side_p s at pic
    mc "是不是只有我觉得，他的哈欠假得要命？"
    hide side_p
    quil cringe cling "只是你的错觉。可能是妄想症吧。"
    show quil frown -cling
    "奎尔从口袋里掏出一个小空瓶，收集了更多雕像流出的黑色液体。"
    show side_p f at pic
    mc "你在做什么？"
    hide side_p
    quil rajuk sigh "研究。我……我一直在回想佩纳说的话。"
    quil sad -sigh "关于我的家族并不像表面上看起来那么诚实。"
    if "date2_done" in quil_events:
        quil sad -sigh "现在我知道巫师的血液被用在我的疫苗里，嗯……我在想它还能用在什么地方。"
    show side_p f at pic
    mc "这就是你想要巫师血液的原因吗？"
    hide side_p
    quil frown "是的。"
    show quil at right with move
    show buff frown at left with dissolve:
        xzoom -1.0
        yoffset 770
    buff apa "事实上，奎尔先生，我一直在想这个问题。我的血可以吗？因为我是混血。"
    quil flashy laugh shock "哦，你是在主动提供吗？"
    buff datar -apa "是的。"
    quil amused "嗯。我会给你丰厚的报酬以换取你的合作，但说实话，我最需要的是纯种巫师的血液。"
    quil wink -sweat cling "这就是为什么我对你抱有很高期望，[povname]。"
    buff scold apa "[kamu]在哪里能找到纯种巫师呢？"
    show buff frown -apa
    show side_p m at pic
    mc "这正是我一直在问的问题。"
    hide side_p
    quil skul sly -cling "哦，我相信你会想出办法的。同时，莱尔，你能和我一起去洗手间吗？"
    quil wry "我需要给你扎一下，我不想血溅得到处都是。"
    buff keluh sweat "...就我们两个人吗？"
    quil flashy laugh spark "别担心，我会管好我的手的。除非你改变主意，想让我...教育你？"
    buff keluh both sigh "...有人告诉过你，你有点变态吗？"
    show buff wry -sigh
    show quil err both shock
    "说着，莱尔矜持地捂住了胸口。"
    show side_p a at pic
    mc "哈哈哈哈！"
    hide side_p
    show quil skul rajuk 
    "你忍不住大笑起来。奎尔的脸变得通红，他没有准备好应对这样的评论。"
    quil sad -both frusta "我道歉。我不会那样碰你，也不会再做任何评论了。"
    quil "现在，我能取一点你的血样吗？我会付给你100金币。"
    buff sinis -both cling "150."
    quil ejek cling "125."
    buff talk -cling "成交。"
    show quil sly -cling
    show side_p f at pic
    mc "那我就先走了。看到血我会觉得恶心。"
    show side_p a
    mc "别担心，莱尔，如果你20分钟内没回到我们的房间，我就组织搜救队。"
    hide side_p
    quil err sweat frusta "真没礼貌。"
    buff hister sigh "谢谢。"
    stop music
    play sound "sound/effects/door.mp3"
    
    if "map1" not in completed_quests:
        scene lorong_night with vpunch
        play sound "sound/effects/crash.mp3"
        play music "MUSIC/Action-Rhythm-4.mp3"
        "你刚走出阿什姆的房间，粗壮的手指就抓住了你的肩膀，一个粗暴的推搡将你按在了墙上。" with vpunch
        show side_p s at pic
        mc "哎哟！搞什么鬼？！"
        hide side_p
        $ NPC = "温斯顿"
        if "winston" in my_events or "w_flag" in red_events:    
            npc "你在玩什么把戏？"
            show side_p f at pic
            mc "温斯顿？"
            hide side_p
            npc "你和那个吸血鬼在密谋什么，嗯？我知道塔图姆和她的朋友们住院就是因为他。"
            show side_p s at pic
            mc "我不知道你在说什么。"
            hide side_p
        else:
            npc "塞恩在哪里？！"
            show side_p m at pic
            mc "什么？你他妈是谁？"
            hide side_p
            npc "这不重要。塞恩在哪里？"
            show side_p m at pic
            mc "关你什么事？"
            hide side_p
            npc "你难道不好奇塔图姆和她所有的朋友是怎么被吸干血的吗？"
            show side_p f at pic
            mc "他们被割伤了。"
            hide side_p
            npc "手腕和脖子上，很方便，对吧？"
            npc "我告诉你，这是吸血鬼袭击，准确地说是你的吸血鬼干的！"
        show side_p m at pic
        mc "你有什么证据吗，还是只是在胡说八道？"
        hide side_p
        npc "哦，别装傻了，我看到他在食堂里舔掉手指上的血。"
        npc "还有他的眼睛，比平常更红了。我告诉你，他失控了，我们谁都不安全了！"
        show pboy at horzappear
        menu:
            "你打算怎么办？":
                hide pboy
                npc "我要揭露那个吸血鬼的真面目，让大家知道他就是个害虫。我要向老师举报他，如果有必要的话，我会亲自用木桩刺穿他的心脏。"
                show side_p m at pic
                mc "你疯了！"
                hide side_p
                npc "是吗？在节日期间，我和塞恩失去联系的时候，正好是塔图姆和她的朋友们失踪的时候。"
                npc "巧合？我可不这么认为！而且，我知道塔图姆对你妹妹的仇恨。菲亚和塞恩很亲密。"
                npc "谁说这不是一场激情犯罪呢？"

            "为塞恩掩护。":
                hide pboy
                show side_p s at pic
                mc "如果是他袭击了塔图姆，他现在就不会去猎捕老鼠了。再说，还有其他嫌疑人，你知道吗？"
                hide side_p
        show side_p f at pic
        mc "如果是塞恩干的，应该会留下咬痕。"
        hide side_p
        npc "但那样就太明显了，不是吗？他可能只是划伤了她的脖子，然后吸掉多余的血液。"
        show side_p he at pic
        mc "（该死，这倒是真的。）"
        show side_p m
        mc "塞恩没那么聪明。"
        hide side_p
        npc "如果你仅仅因为他成绩差就认为他没有这个能力，那你比他更愚蠢。"
        "温斯顿又粗暴地推了你一下，松开了抓住你的手。他转身朝宿舍入口走去。"
        npc "总有一天，他体内的野兽会露出马脚。到时候我会准备好的。你等着瞧吧。"
        play sound "sound/effects/doorslam.mp3"
        "他匆忙离开了宿舍，重重地关上了门。"
        show side_p m at pic
        mc "疯子混蛋..."
        
        if "winston" in my_events or "w_flag" in red_events:    
            show side_p s
            mc "（我应该向老师举报他。他还涂污了图书馆的地图，而且他的极端主义对其他学生来说很不安全。）"
            show side_p m
            mc "（最好向凯普勒先生举报，了结此事。）"
            hide side_p
        if "map1" in active_quests and "map1" not in completed_quests:
            if check_inv_for(culp_items):
                $ InvItem(*item_culprit).toss(1)
            python:
                gold += 25
                active_quests.remove("map1")
                completed_quests.insert(0, "map1")
            show screen completedtask("任务完成！")
            "你向凯普勒先生提交了陈述，希望他能给予相应的惩罚。最好是开除。"
        stop music
        play sound "sound/effects/door.mp3"
        scene bed_alter with dissolve
        "你回到了自己的房间，几分钟后莱尔也回来了。"
        "他似乎注意到了你的争执，问你的外套怎么了，但你敷衍了过去——不想让他担心。"
        "你今晚只想好好睡一觉，希望这次你能享受这份奢侈。"
        scene bg_black with w20
        $ night = False
        $ evening = False
        $ afternoon = False
        $ morning = True
        scene kantin with w20
        play music "MUSIC/MusMus-BGM-035.mp3"
        show buff wry at center with dissolve:
            yoffset 770
        "这一次你和莱尔终于能够好好睡一觉了。你们两个一起走向食堂。"
        if "rooted" in buff_events:
            show buff talk 
            "自从那次花的事件之后，莱尔对你的态度稍微温和了一些，但他仍然不太愿意和你一起吃饭。"
            show buff hister
            "他还需要更多时间来适应。"
            show buff datar
            show quil amused bunga at left with dissolve:
                yoffset 200
            show tom talk capek frusta at right with dissolve:
                yoffset 190
            "与此同时，你可以看到奎尔又在惹阿什姆生气了——取笑他那次相当丢脸的晕倒事件。"
            quil heh cling "我的大人，您确定您身体状况足以和我们坐在一起吗？可不想让您感到头晕目眩。"
            tom scold ejek cling "我还是可以诅咒你的蛋蛋掉下来，奎尔。"
            show tom kzl blow
            quil flashy wink spark "哦，你经常想着我的下体吗？我受宠若惊，但恐怕你会因为太兴奋而晕倒。"
            show quil skul hister -spark
            show pboy at horzappear
            menu:
                "让奎尔继续":
                    hide pboy
                    $ honesty += 10
                    $ kindness -= 10
                    if kindness < 0:
                        $ kindness = 0
                    hide buff with dissolve
                    show red chin amused at center with dissolve:
                        yoffset 330
                    red sigh "得了吧，奎尔。我们都有自己的弱点。"
                    tom calm -blow "谢谢。"
                    show tom kzl shock
                    red calm cling "这不是阿什姆的错，他只是有着一只刚出生的小猫咪那样的勇气。"
                    show red cowo bunga
                    show quil hister bunga
                    tom hip capek frusta "..."
                "Intervene":
                    hide pboy
                    $ kindness += 5
                    show side_p f at pic
                    mc "嘿阿什姆，想知道一个秘密吗？你看这个奎尔——"
                    hide side_p
                    quil grit frusta "你敢！"
                    hide buff with dissolve
                    show red sad shock at center with dissolve:
                       yoffset 330 
                    show side_p a at pic
                    mc "那就闭嘴。"
                    hide side_p
                    quil sulk sigh "你真没意思！"
                    red wry -shock "我是不是错过了什么？"
        else:
            show quil amused bunga at left with dissolve:
                yoffset 200
            show tom talk frown at right with dissolve:
                yoffset 190
            "你也设法说服他和你们一起吃早餐。"
            show quil sly cling
            "当莱尔坐在你和阿什姆旁边时，你们收到了很多注目，但奎尔很快就通过做一些下流的嘴部动作吸引了注意力。"
            show tom hip capek frusta
            "阿什姆摇了摇头，似乎对这一切感到恼火。"
            show quil rajuk shock
            buff lega apa "我应该换个位置吗？"
            show buff wry -apa
            tom chill calm blow "别胡说。让其他人去说吧。"
            show tom amused -blow
            quil wink cling "他们是嫉妒，莱尔。我们不常欢迎其他人加入我们这个小四人组。"
            buff frown sigh "但是...我比你们都年轻，我应该和同龄人坐在一起。"
            tom pfft "然后让他们欺负你？留下来，我坚持。科尔知道昨晚我那丢脸的行为后我欠你的。"
            show side_p f at pic
            mc "你本可以直接承认你吓得屁滚尿流，阿什姆。这样会不那么戏剧化。"
            hide side_p
            quil heh -cling "啊，但戏剧性不正是其中的亮点吗？"
            buff hister sweat "你们很有趣，但我还是觉得我应该去和同龄人坐在一起。谢谢。"
            hide buff with dissolve
            play sound "sound/effects/walk.mp3"
            show quil rajuk shock
            show tom ha shock
            "莱尔从桌边站起来离开了。"
            stop sound
            show side_p s at pic
            mc "等等，莱尔——！"
            hide side_p
        stop music
        scene kantin with dissolve
        play sound "sound/effects/glass_tap.mp3"
        show hm scowl at center with dissolve:
            yoffset 190
        "在你能缓解局势之前，校长敲了敲他的酒杯，呼唤学生们的注意力。"
        "学生们立即安静下来，遵从他的命令。"
        stop sound
        hm confused sigh "同学们，我恐怕要宣布一个令人悲伤的消息。"
        hm yell frusta "你们的一位同学，温斯顿·希思，今天早上被发现昏迷不醒，他的喉咙和手腕被割开了。"
        hm sad -frusta "与两天前发现的塔图姆小姐、洛克先生和汉普舍先生身上的伤害相同。"
        play music "MUSIC/whisper.mp3"
        "学生们开始互相交谈，显然被某种连环杀手的想法所困扰。"
        show side_p f at pic
        mc "（虽然我想当没有人被发现死亡时，你还不能称之为连环杀手...至少目前还不能。）"
        hide side_p
        hm complain "为了确保你们的安全，学校现在将实施强制性宵禁。"
        hm scowl "你们所有人都必须在晚上8点前回到宿舍。"
        hm "老师们将每6小时左右进行一次定期检查，必要时会进入房间。"
        hm yell "我们意识到这个程序有多么侵犯隐私。然而，在抓到罪犯之前，最好采取必要的预防措施。"
        hm scowl "如果你们中有人有投诉，请暂时忍耐，如果你真的必须表达，请到我的办公室来。"
        hm frown sigh "就这样。"
        hide hm with dissolve
        "学生们爆发出一阵激烈的争论声，大多数人都在抱怨缺乏隐私。"
        "你当然能理解他们的沮丧，但更重要的是..."
        "你更担心塞恩。塞恩，那个温斯顿憎恨至极的人。塞恩，昨晚温斯顿正在追踪的人。"
        "他真的回到了自己的房间，还是他遇到了温斯顿然后——"
        play music "MUSIC/MusMus-BGM-059.mp3"
        show red mls at center with dissolve:
            yoffset 330
        red lelah frusta "你知道，如果你有什么要说的，可以直接说出来。"
        show red mls 
        show side_p s at pic
        mc "啊。我在盯着看吗？"
        hide side_p
        red kzl sigh "直入我的灵魂。"
        red so -sigh "...如果你想知道的话，校长已经面试过我了。"
        show red at left with move
        show tom scold kzl at center with dissolve:
            yoffset 190
        tom ha apa "是吗？你告诉他你去哪里了吗？"
        show tom hip frown shock
        red mock cling "是的，我还告诉他你那小小的晕倒事件。"
        tom capek frusta "..."
        show quil bingung at right with dissolve:
            yoffset 200
        quil apa "他是怎么反应的？"
        quil amused -apa "我是说对你的反应，不是对阿什姆的。"
        red kzl frusta "他起初不相信我，但维尔科娃老师为我掩护，说我们一起去捕鼠了。"
        show red so -frusta
        if "nanya_vilkov" in red_events:
            show side_p f at pic
            show tom kzl chill shock
            mc "（等等，他不是说...）"
            hide side_p
            tom ha apa "但你昨晚并不是和维尔科娃老师在一起，你说你是独自狩猎的。"
            show tom frown -apa
            red ew sigh "没错。不过，她认为如果我这么说会显得不那么可疑。"
            quil sulk "这谎言并不怎么令人信服。如果我是他，我还是会怀疑你。"
            red sayang -sigh "哦，他确实怀疑。但现在他除了盯着我和维尔科娃之外，也做不了什么。"
        else:
            show side_p f at pic
            mc "你真的去了吗？"
            hide side_p
            red sad sigh "不是和她一起。"
            quil frown "但她还是为你掩护了？"
            red ew frusta "这重要吗？我们俩都是最明显的嫌疑人，我们是这里唯一的吸血鬼。"
            red sayang -frusta "我们这些\'吸血虫\'得互相照应。"
        tom sigh blow "如果你需要什么就告诉我们，我们的校长想严厉的时候可是相当严厉的。"
        show tom wry -blow
        red wry "我知道。"
        show side_p f at pic 
        mc "等等，就这样？你们两个就这么相信他？"
        hide side_p
        quil flashy heh "亲爱的，我知道这对你来说可能有点突然，但是...这可是塞恩。这个人连兔子都不会伤害。"
        tom hip amused "更不用说他明显缺乏脑细胞。"
        red chin kzl frusta "嘿！"
        tom scold calm "如果是塞恩干的，他会直接咬下去，留下明显的放纵证据。"
        tom pfft "维尔科娃或者可能是波比会是更好的嫌疑人。"
        show side_p f at pic
        mc "波比？"
        hide side_p
        tom hip whine "狼人生气的时候是相当可怕的。"
        show tom frown 
        show pboy at horzappear
        menu:
            "你们就这么信任他吗？":
                hide pboy
                $ honesty += 10
                $ kindness -= 5
                quil wink cling "当然。"
                tom amused cling "是的。"
                quil skul panik sigh "因为说实话，他实在是太无能了，不可能犯下谋杀。"
                tom pfft blow "还有，他善良得有点过头了。"
                red huh sigh "我不知道该感谢还是该生气。"
                show side_p f at pic
                mc "嗯。我想你们俩说得对。太无能了。"
                hide side_p
                red perih shock "喂！"

            "好吧...":
                hide pboy
                $ honesty -= 10
                show tom pfft
                show quil hister
                show side_p f at pic
                mc "我想你说得对。"
                hide side_p
                red ew shock "真是自信啊！"
                red perih frusta "你们知道我就在这里吧？"

        "你勉强挤出一个微笑，但似乎无法抑制心中这沉重的压力。"
        "尽管他咧嘴大笑，你还是能感觉到塞恩真的有些不同了。"
        "一种你造成的不祥的变化。你和你的血。"
        $ NPC = "???"
        $ night = False
        $ evening = False
        $ afternoon = True
        $ morning = False
        scene bg_black with w20
        if "bunga_bego" in buff_events:
            if "beku" in quil_events:
                scene map_infected_f with w20    
            else:
                scene map_infected with w20    
        else:
            if "beku" in quil_events:
                scene map_frozen with w20
            else:
                scene map_all with w20
        jump world_map

    else:        
        stop music
        play sound "sound/effects/door.mp3"
        scene bed_alter with dissolve
        "你打着哈欠回到了自己的房间。不久之后，莱尔也进入了房间。"
        "希望你们两个今晚能好好睡一觉。"
        scene bg_black with w20
        $ night = False
        $ evening = False
        $ afternoon = False
        $ morning = True
        scene bed_pagi with dissolve
        play sound "sound/effects/knock.mp3"
        show buff sad at center with dissolve:
            yoffset 770
        buff keluh sweat apa "嗯。这次又是什么事？"
        show buff sad -apa
        "一阵粗暴的敲门声粗鲁地把你和莱尔吵醒了。考虑到昨天的惊吓，你实在不太想开门。"
        play sound "sound/effects/knock.mp3"
        show side_p m at pic
        mc "说真的，到底是谁啊？除非有人死了，否则我不会开门的！"
        hide side_p
        $ NPC = "普莉姆"
        play sound "sound/effects/door.mp3"
        show prim_ sad at pic
        npc "[povname]！是我，普莉姆。是菲亚，他们昨晚在花园里发现她失血过多！"
        hide prim_
        show side_p m at pic
        mc "什么？！"
        hide side_p
        play sound "sound/effects/cloth.mp3"
        queue sound "sound/effects/tile.mp3"
        "你跳下床，立即和普莉姆一起跑向医务室。"        
        scene uks with w33
        if girl:
            show palmierproxy sad sweat at right with moveinright:
                yoffset 40
        else:
            show palmierproxy sad sweat at right with moveinright:
                yoffset 100
        mc "菲亚！"
        play sound "sound/effects/doorslam.mp3"
        play music "MUSIC/MusMus-BGM-077.mp3"
        show croissant frown at left with dissolve:
            xzoom -1.0
            yoffset 500
        "当你看到菲亚坐在其中一张床上，背靠着墙时，你尖叫了起来。"
        "海德温站在她身边，往她嘴里倒了一瓶水。"
        fia wry shock "[povname]!"
        "你跑向她，拨开她脖子周围的东西，露出一圈白色的绷带，上面略微染上了粉红色的色调。"
        mc ow frusta "你的脖子。"
        show palmierproxy side
        fia malu sigh "没事的。海德温已经给我一些维他命和补血药剂了。"
        fia mmh frusta "不过，我还是得在床上休息几天。"
        mc ow tanya "我明白了。你能告诉我发生了什么吗？"
        fia sad -frusta "关于那个..."
        show palmierproxy kzl shock
        play sound "sound/effects/walk.mp3"
        show hedwin frown at center with dissolve:
            yoffset 200
        hed "恐怕她对袭击者没有任何记忆。"
        stop sound
        mc side -apa "为什么？是符文的原因吗？"
        hed sad "那个...或者是精神控制。"
        mc rajuk "精神控制？"
        hed mad "吸血鬼有时能控制他们的受害者，让他们忘记或违背自己的意愿做事。"
        hed sad "通常来说，吸血鬼越老，精神控制能力就越强。"
        mc pissed shock "海德温女士，抱歉，但你是在暗示——"
        show palmierproxy sad -shock
        hed mad frusta "我不是在暗示，我是在明确地说，要么是维尔科娃，要么是塞恩对此负责。"
        hed -frusta "你们不能说这个想法没有在你们脑海中闪过。"
        mc sad frusta "这个，嗯..."
        show palmierproxy -sweat frown shock
        fia kzl frusta "塞恩是个好人！看在科尔的份上，他只吃老鼠。这就说明他多么不想伤害任何人。"
        hed mad sigh "有时候，怪物会在你最意想不到的时候扑上来。"
        hed sad -sigh "任何吸血鬼都可能失去理智，屈服于他们最原始的本能。"
        hed frown "不过说实话，我更怀疑维尔科娃。她还戴着面具是有原因的。"
        hed "没有面具她就无法抵抗血液的气味。也许她终于屈服了？"
        fia gross "我...老实说，我不认为是他们中的任何一个。我想我只是因为失血过多而失去了记忆。"
        fia sad sigh "我相信记忆会慢慢恢复的。"
        hed sad "...希望如此。不管是谁，我希望他们还能被拯救。"
        hed tantang cling "现在好好休息吧，年轻的贝克。如果你需要什么来缓解疼痛，尽管告诉我。我有很多种药物，如果你明白我的意思的话。"
        show hedwin smile -cling
        mc panik tanya "毒品？"
        show palmierproxy sad sweat shock
        "不，你并不是有意说出口的。不过，海德温女士对你的诚实露出了笑容。"
        show palmierproxy frown -shock
        hed konsul "是的，麻醉剂。很强力，但很有趣。"
        $ fia_events.append("drained")
        fia hister sigh "呵呵。知道了，海德温女士，我会的。"
        play sound "sound/effects/doorslam.mp3"
        queue sound "sound/effects/walk.mp3"
        hide hedwin with dissolve
        "海德温女士一离开，菲亚就把你拉得更近，在你耳边低语。"
        play sound "sound/effects/cloth.mp3"
        show palmierproxy sad shock at center with move
        fia flinch err sweat frusta "哦，我的科尔啊，一定是塞恩干的！"
        mc kzl shock "什么？"
        fia cringe sigh "我发誓！"
        if "blud_redi" in red_events:
            fia mad -sigh "你看到他了。那天晚上在节日上。他试图舔我，谁会那样做？！"
            mc scratch sad -shock "我...嗯，也许他是饿了？我是说，你当时从头到脚都浸透了血。"
            fia cringe "是啊，但塞恩以前从未被诱惑过！"
            fia sad "这就是为什么我问他这件事，而他变得很有防备。"
        else:
            fia sad -sigh "我是说，很难不注意到，你知道吗？他以前对每个人都很冷淡。当然，他很友好，但仅此而已。现在，他看人的眼神就像在看会走路的食品推车。"
            fia cringe "尤其是你，[povname]。他看着你的样子...我不知道他是想要你，还是想吞噬你。"
            mc scratch huh -shock "你确定你不是过度分析了吗？"
            fia sad "我没有！听着，我昨晚问过他了，好吗？"

        fia kzl frusta "他的翅膀和爪子突然冒了出来，在我脖子上划了一下。不足以致命，但绝对足以让任何人惊慌失措。"
        mc rajuk tanya "为什么你没有把这些都告诉海德温女士？"
        show palmierproxy sad -sweat shock
        fia gross sigh "因为他明显出了问题，[nickname]！"
        fia sad -sigh "他很可怕，但我不认为他真的想伤害我。当他划伤我时，他立即舔了舔自己的手指，但然后..."
        mc chill apa -shock "然后？"
        fia def mmh "...然后他哭了，并给我包扎。他低着头，不停地向我道歉。"
        mc sad tanya "这是什么时候的事？"
        show palmierproxy kzl -tanya
        fia cringe "我大约午夜时分去了他的房间。我想趁他室友睡着时更好地谈谈。"
        fia kzl "我们在花园里散步，就是在那里发生的。他吓坏了，让我流血了一会儿，但他回来了。"
        fia sad "我昏过去了，等我醒来时，我就在这里，老师们正俯视着我。"
        mc pissed -sweat frusta "他他妈的把你丢下了？！"
        fia wry sigh "嘿，至少他回来了，我没有流血致死！"
        fia sad -sigh "他本可以把我吸干，但他没有...他很害怕。"
        mc kzl "这不是借口！等我抓到他——呃，他现在在哪里？！"
        fia gross "我不知道。也许在校长办公室？我想所有老师都在追查他。"
        show pboy at horzappear
        menu:
            "你应该坦白。":
                hide pboy
                $ mrh.points -= 25
                if mrh.points <0:
                    $ mrh.points = 0
                mc side sigh "我觉得你应该坦白，说出关于塞恩的真相。"
                fia jijik shock "然后让他被开除？！不行！"
                fia sad -shock "这应该是他的最后一年。我不能毁了他，而且我..."
                mc side tanya "你怎么了？"
                fia "..."
                show palmierproxy frown shock
                fia malu blush "我喜欢塞恩，好吗？在你所谓的朋友中，他是唯一一个像样的人。"
                show palmierproxy sad -shock
                fia hister "他对我很好，在魔药课上还说我聪明。"
                fia gross sweat frusta "我不能这样对待那个狗狗眼的塞恩，绝对不行！"
            "我们该怎么办？":
                hide pboy
                $ mrh.points -= 10
                if mrh.points <0:
                    $ mrh.points = 0
                
            "（这是我的责任吗？）":
                hide pboy
                $ mrh.points += 5
                mc ow frusta "（是因为他在梅扎的巢穴里喝了我的血吗？）"
                mc grit "（我才是这一切的真正原因吗？如果我间接伤害了菲亚，那我宁愿——）"
                show palmierproxy frown -sweat shock
                fia gross apa "你还好吗，[kk]？"
                mc wry both tanya "...我不是应该问你这个问题吗？"
                show palmierproxy sad -tanya
                fia err sigh "是啊，但你没问，而且...你看起来好像快崩溃了。"
                play sound "sound/effects/cloth.mp3"
                show palmierproxy frown -both shock
                show croissant flinch hmph
                "菲亚的手指与你的交织在一起。你忍不住握紧她的手，害怕松开。"
                mc side sigh "（我知道她不是我的亲生妹妹，但是...她的笑声，她的手...我想我无法承受她再次死在我面前。）"
        mc chill sad tanya "那我们该怎么办？我怀疑塞恩不会那么容易就坦白。"
        fia frown -sweat sigh "我们暂时盯着他吧。确保他不会做什么蠢事。"
        fia -sigh "现在应该很容易，因为老师们说由于最近的袭击事件，他们要实行宵禁。"
        mc frown -tanya "你从哪里听说的？"
        fia def hmph "今天早上，校长来的时候。我假装还在睡觉，偷听到了一切。"
        fia mmh "好消息是，他不再怀疑我们了，这是一件好事。但他确实怀疑维尔科娃和塞恩。" 
        fia frown "他说要和他们谈谈，现在可能已经谈过了。"
        mc sad "我明白了。那你今晚要留在这里吗？"
        fia sad "是的，我失血过多，所以海德温说要留我观察。"
        mc side "嗯。我待会儿也会来看你的。"
        show palmierproxy rajuk shock
        fia flinch jijik "不行！"
        show palmierproxy frown -shock
        fia wry sigh "你去找塞恩，跟他讲道理。我会没事的，我发誓！"
        mc side "...好吧。"
        show palmierproxy sigh
        show croissant hister bunga
        "你揉了揉菲亚的头发，然后走出房间。无论塞恩在哪里，你都一定要好好教训他一顿。"
        $ NPC = "???"
        $ night = False
        $ evening = False
        $ afternoon = True
        $ morning = False
        scene bg_black with w20
        if "bunga_bego" in buff_events:
            if "beku" in quil_events:
                scene map_infected_f with w20    
            else:
                scene map_infected with w20    
        else:
            if "beku" in quil_events:
                scene map_frozen with w20
            else:
                scene map_all with w20
        jump world_map

label curfew_day:
    stop music
    stop sound
    scene bg_black with w20
    scene lorong_night with w20 
    play sound "sound/effects/walk.mp3"
    show priest laugh at center with dissolve:
        yoffset 200
    dog "宵禁时间到了，孩子们，所有人都回自己的房间。"
    show priest evil
    "迪特里希和其他几位老师可以看到在四处巡视，催促学生们回到各自的房间，引起了众多抗议。"
    hide priest with dissolve
    play sound "sound/effects/doorslam.mp3"
    play music "MUSIC/MusMus-BGM-049.mp3"
    scene kmr_malam with dissolve
    show buff skul frown at right with dissolve:
        yoffset 770
    if girl:
        show palmierproxy chill frown at left with dissolve:
            yoffset 40
    else:
        show palmierproxy chill frown at left with dissolve:
            yoffset 100        
    buff keluh sweat frusta "你觉得这个宵禁会持续多久？"
    show buff sad sigh
    mc deject sigh "希望不会太久，你看到校长办公室前的队伍了吗？完全是一片混乱。"
    mc side -sigh "（况且，我想我已经知道罪魁祸首了。可能是某个新近迷上了血液的红发家伙？）"
    buff eh apa "[povname]?"
    show buff frown -apa
    mc wry sweat "啊，是吗？"
    buff frown "我问你想不想先洗澡，因为我想用淋浴，但是..."
    mc smile  "哦，好的，好的，你先去吧。"
    hide buff with dissolve
    play sound "sound/effects/walk.mp3"
    show palmierproxy side sweat frusta at center with move
    "当莱尔走向浴室时，你忍不住在房间里来回踱步，试图压抑内心的不安。"
    stop sound
    show palmierproxy kzl shock
    "当你将注意力转向窗外的景色时，你看到有什么东西从你楼上的房间窗户跳了出来。"
    hide palmierproxy with dissolve
    "眯着眼仔细看，你意识到那是塞恩。他变成了有翼的形态，正从四楼偷偷溜出去。"
    "你壮着胆子打开窗户。你在三楼，但有一根树枝你可能跳得到。"
    "也许如果你能助跑一下？"
    show pboy at horzappear
    menu:
        "助跑":
            hide pboy
            show side_p f at pic
            mc "莱尔，我出去了。帮我掩护一下，好吗？"
            play sound "sound/effects/tile.mp3"
            hide side_p
            buff "什么？"
            stop music
            play sound "sound/effects/door.mp3"
            show buff skul keluh at center with dissolve:
                yoffset 770
            buff sweat shock "等等，[povname]！！！"
            $ my_events.append("luka")
            play sound "sound/effects/crash.mp3"
            scene court_night with vpunch
            "当你从窗户跑出去时，你听到莱尔的尖叫声。你的腿被窗框卡住了，导致你重重地摔在了草坪上。"
            show side_p m at pic
            mc "哇啊啊啊！！！"
            hide side_p
            play sound "sound/effects/leaves.mp3"
            "幸好灌木丛缓冲了你的坠落，尽管你能感觉到手上一阵刺痛，一道长长的伤口撕裂了你的手套——鲜血染红了你的手。"
            stop sound
            show side_b skul sad at pic
            buff "你没事吧？！"
            hide side_b
            show side_p s at pic
            mc "我没事！"
            hide side_p
            "你大声回应道，莱尔从窗户探出头来。"
            show side_p he at pic 
            mc "听着，我有些事情必须去做，好吗？帮我掩护一下！"
            hide side_p
            show side_b skul sad at pic
            buff "什么？等等，[povname]！"
            hide side_b
            play sound "sound/effects/tile.mp3"
            "你在莱尔说出下一句话之前就跑开了，生怕他会让你恢复理智。"

        "正常跳下，但要小心":
            hide pboy
            "你在想什么？像个特技演员一样从窗户跑出去？"
            "你只需要沿着窗台走下去，然后跨到树枝上。你的腿应该够长。"
            show side_p he at pic
            mc "莱尔，我出去了。帮我掩护一下，好吗？"
            hide side_p
            "当你听到莱尔打开浴室门的声音时，你尖叫起来。"
            play sound "sound/effects/door.mp3"
            buff "什么？"
            "当他走近窗户时，你已经在路上了，正跨到树上。"
            "莱尔从窗户和你说话，身上只围了一条毛巾遮住重要部位。"
            show buff swim frown at center with dissolve:
                yoffset 770
            buff eh sweat "[povname]，你在干什么？如果被老师抓到怎么办？"
            show buff sad -sweat
            show side_p f at pic
            mc "那我就假装我喝醉了。"
            show side_p s 
            mc "听着，这对我很重要，好吗，莱尔？就帮我掩护一下，好吗？"
            hide side_p
            buff huh frusta "...好吧。"
            show side_p w at pic
            mc "谢谢！"
            hide side_p
            buff frown sigh"小心点！"
            stop music
            scene court_night with fade
            play sound "sound/effects/tile.mp3"
            "你爬下树，朝着最后看到塞恩的方向跑去。"
    stop sound
    show side_p s at pic
    mc "（别做傻事，塞恩。）"
    hide side_p
    "当你在校园里漫步时，你看到一些老师在四处游荡，他们的黑色教会服装差点让你心脏病发作。"
    "但当你看到一个红发的身影朝码头方向走去时，你冷静了下来。"
    scene pier_night with fade
    "在确保塞恩已经走下楼梯足够远后，你慢慢地跟在他后面，确保你的脚步轻到听不见。"
    play sound "sound/effects/flame.mp3"
    "当你越来越靠近时，你使用火符文召唤出一小团火焰，照亮了周围的区域。"
    show side_p s at pic
    mc "...塞恩？"
    hide side_p
    play music "MUSIC/wrath.mp3"
    galleryunlock fishes
    show fishes with dissolve:
        truecenter zoom 1.0
        easein 1.0 truecenter zoom 0.7
    "你看到塞恩浑身是血，周围有几十条鱼和乌龟，全都被剖开肚子，血液流尽。"
    "他的脸颊上突出着獠牙。他朝你咆哮。"
    red "...[povname]?"
    hide fishes with dissolve
    show red speck growl frusta at center with dissolve:
        yoffset 330
    red sweat "你不该来这里！我不能，我现在不是我自己！"
    show red ew at left with move
    if girl:
        show palmierproxy chill sad shock sweat at right with moveinright:
            yoffset 40
    else:
        show palmierproxy chill sad shock sweat at right with moveinright:
            yoffset 100
    if "luka" in my_events:
        show red datar blush shock at center with move
        red hister shock "等等，你在流血吗？该死！该死！我能舔你的伤口吗？求你让我舔一下！"
        show red kaget sweat shock
        mc frusta "不，塞恩，住手！"
    if "drained" in fia_events:
        mc grit frusta "塞恩，你是泰特姆和菲亚遇袭事件的幕后黑手，对吗？"
        
    else:
        mc grit frusta "塞恩，你是泰特姆和温斯顿遇袭事件的幕后黑手，对吗？"
    red perih shock "那是个意外！我发誓我不是故意的。我...我失去了控制。"
    if kindness >= 50:
        mc side sigh "我知道。但是，我们还是需要想办法控制它。我能做些什么？"
    else:
        mc kzl "你在想什么？！"
        show red sad shock
        red growl frusta "我根本没在想！你什么都不懂！"
    red perih sigh "我...我不知道该怎么办，[povname]。自从我喝了你的血之后，我似乎就无法控制自己了。"
    red ew frusta "我满脑子都是血。尤其是你的血，我一直在喝，一直在喝，但没有一种血能比得上你的血。"
    if "drained" in fia_events:
        red ngeles "我不是故意要伤害菲亚的，但她一直在逼我！"
    else:
        red ngeles "我不是故意要伤害温斯顿的，但他一直在逼我！"
    red perih "泰特姆和她的朋友们也是，我不是故意要吸干他们的血。我只是想尝一尝，就一小口。我..."
    red sad sigh "我没有选择生来就是这样。成为一个吸血的怪物。我一点都不想要这样！"
    show pboy at horzappear
    menu pilih:
        "没关系的。（拥抱他）" if kindness >= 50:
            hide pboy
            red "不行！"
            $ mrh.points -= 10
            if mrh.points <0:
                    $ mrh.points = 0
            show red ew at left with move
            show palmierproxy side shock at center with move
            "在你能用双臂环抱他之前，塞恩后退了一步。"
            stop music
            play sound "sound/effects/bump.mp3"
            red kaget shock "哇！"
            show palmierproxy sad shock
            play sound "sound/effects/splash.wav"
            scene bg_black with rain1
            "这一步导致他失去了平衡。你试图把他拉回来，但他的体重太重了。"
            "你们俩都跌入了冰冷的水中。"
        "{s}没关系的。（拥抱他）{/s}" if kindness < 50:
            jump pilih
        "然而这就是你的本质。" if honesty >= 50:
            hide pboy
            show palmierproxy sweat malu sigh
            red mock sigh "呵。我难道不知道吗？有人告诉过你，你在安慰人方面真是糟糕透顶吗？"
            $ mrh.points -= 20
            if mrh.points <0:
                    $ mrh.points = 0
            mc sad -sigh "也许维尔科娃能帮忙？或者用魔药？"
            red huh frusta "我试过了。维尔科娃在帮我掩饰，但她知道有些不对劲。"
            red ngeles sweat sigh "就好像我的身体会排斥除了你的血液之外的任何血液。"
            red sad -sigh "仿佛它想让我们建立联系。"
            show red mls with move:
                xalign 0.75
            show palmierproxy pissed sweat shock
            play sound "sound/effects/cloth.mp3"
            if "luka" in my_events:
                "塞恩拉起你受伤的手，舔掉了上面的血滴。"
            else:
                "塞恩抓住你的脖子，你们的脸只相距几英寸。"
                "你们的鼻尖相触，你几乎能尝到他嘴里的金属味。"
            mc ew frusta "塞恩，不要！"
            red mock -sweat cling "你现在看清我了吗，[povname]？"
            red kzl frusta "看清我这个怪物了吗？"
            mc ow "（我觉得他现在神志不太清醒。）"
            mc sad sigh "我们去找老师吧，塞恩。"
            red mock cling "不。"
            scene pier_night with dissolve
            play sound "sound/effects/cloth.mp3"
            "塞恩紧紧抓住你的双腕，将你拉近，张大嘴巴，露出尖牙。"
            show side_p m at pic
            mc "我说了不要！"
            hide side_p
            stop music
            play sound "sound/effects/bump.mp3"
            scene bg_black with rain1
            play sound "sound/effects/splash.wav"
        "{s}然而这就是你的本质。{/s}" if honesty < 50:
            jump pilih
        "再多给你一些我的血会有帮助吗？":
            hide pboy
            show red mock with move:
                xalign 0.75
            show palmierproxy sad both shock
            play sound "sound/effects/cloth.mp3"
            red blush "哦，[povname]，你这些话对我的影响太大了..."
            "塞恩靠近你，将你的头发拨到耳后，露出你苍白的脖子。"
            show palmierproxy kzl -shock
            red cowo cling "我会品尝每一滴。"
            mc grit sweat frusta"退后！" with vpunch
            play sound "sound/effects/bump.mp3"
            show red at left with move
            red ew sweat shock "啊！"
            play sound "sound/effects/splash.wav"
            scene pier_night with vpunch
            "你的求生本能立即发挥作用，你猛地将他推开，把塞恩推进了水里。"
            show side_p s at pic
            mc "...塞恩？"
            hide side_p
            "十秒过去了，然后是一分钟，水面上仍然没有冒出气泡。"
            show side_p he at pic
            mc "塞恩！"
            show side_p s
            mc "（糟糕，他溺水了吗？！）"
            hide side_p
            stop music
            play sound "sound/effects/splash.wav"
            scene bg_black with rain1
            "担心最坏的情况，你跳入水中，希望还不算太晚。"
            
    "冷，冷，冷。你只感到寒冷，随着你下潜得越深，水温似乎越来越低。"
    "一股强劲的水流将你卷入水下暗流。你试图反抗，想游回水面呼吸，但有什么东西不断将你拉向更深处。"
    "不久之后，你所能看到的只有一片漆黑，再也没有力气与命运抗衡。"
    $ NPC = "???"
    npc "[nickname]...醒醒...[kk]？"
    scene apt with eye_open
    play sound "sound/effects/cloth.mp3"
    show croissant bebas wry blush at center with dissolve:
        yoffset 500
    if girl:
        show palmierproxy jln sad at left with dissolve:
            yoffset 40
    else:
        show palmierproxy jln sad at left with dissolve:
            yoffset 100
    mc shock "菲亚？"
    show palmierproxy sweat -shock
    fia hister "对不起。你又在沙发上睡着了，我不想让你再错过任何一顿饭。"
    fia hmph apa "今天在金杰斯的轮班很辛苦吗？"
    mc ow frusta "菲亚？什么...发生了什么？"
    mc side -frusta "（这一切都是梦吗？等等，金杰斯？）"
    mc "（但是当我开始在金杰斯工作时，菲亚已经——）"
    play music "MUSIC/MusMus-CT-NAVAO-32.mp3"
    show palmierproxy frown -sweat shock
    fia happy "我今天做了你最喜欢的菜，罗宋汤配干型雷司令！我觉得这是我能为你做的最起码的事，因为你帮我练习了试镜。"
    fia laugh bloom "顺便说一下，我成功了！我的第一个电视节目工作。虽然只是\'乘客3号\'，但也算是个开始，对吧？"
    fia "我现在终于可以支付一半的房租了！"
    mc malu -shock "啊，是啊，哈哈。"
    mc sad "（这到底是怎么回事？这个菲亚...她是我的菲亚。不是那个尖酸刻薄的女王，而是我曾经用奶瓶喂养的那个天真活泼的傻瓜。）"
    mc happy blush "你...你真的是她，对吗？我的妹妹？"
    fia hmph apa "嗯？当然是我啊。还在做梦吗，[nickname]？"
    fia laugh -apa "总之，快来坐下吧，饭菜要凉了！"
    mc malu sweat sigh"（做梦？啊，可能就是这样。那时候，这就是我一直想要的。）"
    mc "（和妹妹一起生活，看着她努力追求自己的大突破。）"
    mc "（我一直更喜欢她做的饭。妈妈从来不在家，所以我们俩只能自己想办法。）"
    mc "（烘焙是我的强项，但家常菜是她的拿手好戏。）"
    mc "（我一直都喜欢她做的罗宋汤，即使在她还没有加入任何酒精之前。）"
    fia sad both apa "[nickname]，怎么了？你不来吃饭吗？"
    mc sad frusta "我真希望可以，菲亚，但是不行。因为这不是真的。"
    stop music
    mc ew sigh "因为你已经死了。"
    show palmierproxy frown -sweat shock
    fia hister blush "...那又怎样？"
    mc confused -shock "那又怎样？"
    fia happy sigh "即使不是真的，你就不能开心地享受吗？"
    fia kerja -sigh "即使只是幻想也不行吗？"
    show pboy s at horzappear
    menu:
        "我想我可以。":
            hide pboy
            play music "MUSIC/MusMus-CT-NAVAO-32.mp3"
            show palmierproxy malu blush 
            fia laugh bloom "这就对了，现在过来吧！"
            fia happy "告诉我工作的一切！"
            show croissant kerja 
            mc hister bunga "嗯，我..."
            "你花了好几个小时和菲亚一起吃饭聊天。"
            scene apt with dissolve
            "在看电视的时候，你接到了老板的电话，告诉你获得了一直想要的大升职。"
            "你妈妈打电话告诉你她为你感到骄傲。看着你的银行账户，你意识到终于有足够的钱买房子了。"
            #berubah
            scene io_end1 with flashbulb
            galleryunlock io_end1
            "第二天，你和菲亚去看房子。天气多云，不冷不热。"
            "一切都很完美。完美的一天，完美的生活。"
            "你为什么要离开呢？"
            "你在这里很幸福。"
            stop music
            hide screen cal
            $ quick_menu = False
            scene io_end2 with wet
            galleryunlock io_end2
            "这不就是最重要的吗？"
            #berubah
            scene bg_black with w33
            show text "伊欧的幸福结局：幻想梦境" with dissolve
            $ achievement.grant("Achievement02_Io")
            init:
                $ achievement.register("Achievement02_Io")
                $ achievement.sync()
            $ achievement.sync()
            $ renpy.pause()
            jump bad_end_game
        "不。":
            hide pboy
            mc side sigh "不...我不能。我不配拥有这些。"
    fia sad "每个人都值得幸福，[kk]。如果你愿意，你可以留在这里。留在这里，安详地实现你余下的梦想。"
    fia wry "但是...我会尊重你的决定，亲爱的带着死亡气息的访客。"
    scene apt with dissolve
    play sound "sound/effects/change.mp3"
    show Io no frown at center with flashbulb:
        #yoffset 80
        zoom 0.9
    "闪耀的星星取代了菲亚黑暗的目光。你感觉那双眼睛仿佛能看透你。"
    show side_p k at pic
    mc "你！你-你是谁？"
    show side_p g with vpunch
    play sound "sound/effects/bump.mp3"
    mc "啊！"
    hide side_p
    play sound "sound/effects/splash.wav"
    scene bg_black with rain1
    "随着一推，你感觉地面将你整个吞没。把你拉进一个深邃黑暗的深渊。"
    if girl:
        galleryunlock pul_f
        show io_poolf at left with wet
        pause 1.0
        show io_pool2f at right with moveintop:
            yalign 0.0
    else:
        galleryunlock pul_m
        show io_pool1 at left with wet
        pause 1.0
        show io_pool2 at right with moveintop:
            yalign 0.0
        pause 1.0
        show io_pool3 at right with moveinright:
            yalign 0.0
    pause 2.0
    show io_pool4 at right with moveinbottom:
        yalign 1.0    
    "你醒来时发现自己在一池不动的尸体中，所有尸体都漂浮在一种厚重的黑色物质中，你只能想象那是焦油或凝固的血液。"
    mc "这，这是什么？！"
    "你挣扎着站起来，擦掉身上的物质。你高到能够触到底部，水面到你的胸口。"
    red "[povname]?"
    red "[povname]!"
    mc "塞恩！"
    "你看到塞恩在对面的另一个池子里，那里同样漂浮着尸体，但颜色没那么黑。他那边的池子更像是灰色调。"
    play music "MUSIC/MusMus-BGM-CP05.mp3"
    scene io_lair_ink with dissolve
    show red sad sweat at center with dissolve:
        yoffset 330
    "他爬出池子，大步走向你，帮你从水中出来。"
    red ngeles "发生了什么，我们在哪里？"
    show red kzl shock at left with move
    show Io snek frown at right with moveinright:
        xzoom -1.0
        #yoffset 80
        zoom 0.9
    io "这是人类和巫师试图成为神的坟墓。教会最邪恶的秘密。内部圣所。"
    show side_p s at pic
    mc "你..."
    hide side_p
    "你梦中的巫师重新出现，她的黑色长裙拖在地上。"
    play sound "sound/effects/hiss.mp3"
    "她的蛇紧紧缠绕在她身上，对着你嘶嘶作响。"
    io smile "我们又见面了，小家伙。我一直在想你什么时候会出现。"
    red lelah -shock "[povname]，退后！"
    scene io_lair_ink with dissolve
    galleryunlock smack
    show smack_base at left with moveinleft
    play sound "sound/effects/woosh.mp3"
    show smack_ball:
        parallel:
            truecenter zoom 0.0
            linear 0.5 truecenter zoom 1.0
        parallel:
            subpixel True pos (720, 230)
            easein 1.0 subpixel True pos (700, 200)
        easein 1.0 xpos 1442 ypos -403
    pause 1.0
    play sound "sound/effects/shield.mp3"
    show smack_takol at right behind smack_ball with moveinright:
        yalign 1.0
    "塞恩向她发射了一个影子般的投射物。"
    "巫师像拍苍蝇一样轻松地挥开了它，显然对这突如其来的攻击毫不在意。"
    scene io_lair_ink with dissolve
    show Io snek frown at right with dissolve:
        xzoom -1.0
        zoom 0.9
    show red ew shock at left with dissolve:
        yoffset 330
    io frown "你不可能击中我，被污染的人。我能看到你的未来、过去和现在。"
    show red sad -shock
    io smile "哦，多么悲惨的现在啊。被你无法控制的欲望逼疯。我为你感到遗憾，被污染的人。"
    show side_p f at pic
    mc "女士，说真的，你到底是谁或者是什么？！"
    hide side_p
    $ NPC = "伊欧"
    io "我的朋友叫我伊欧。不过，我相信你们人类更熟悉我的称号——幻想女巫。"
    red kaget shock "你是纯血。"
    show red chin huh -sweat -shock
    io frown "是的。这是事实，然而，就像你一样，我并不希望得到这样的命运。这只是星辰认为适合我的。"
    show side_p f at pic
    mc "你在学校下面做什么？这些尸体是怎么回事？"
    hide side_p
    io apa "死了？也许你应该仔细看看。"
    show Io smile -apa
    show red frown
    "其中一具尸体漂得更近了，轻轻地靠在了水池边缘。"
    "你看着他的身体，注意到……他在微笑，看起来很开心。他的身体似乎很放松，脸上挂着一抹无忧无虑的笑容。"
    "他的胸膛有规律地起伏着，显然还在呼吸。"
    show side_p s at pic
    mc "他们在睡觉？"
    hide side_p
    show red kaget sweat shock
    io "全部一百二十七个人都是。"
    show red sad -shock
    io "他们在梦中尽情沉浸于自己想要的幻想中。"
    red kaget -sweat "这就是你名字的由来吗？"
    show red frown 
    io frown sigh "是的，还有其他原因。很久以前，他们称我为伊欧，七大洋之母。虽然遗憾的是，我再也不能在我心爱的海洋中自由漫游了。"
    io -sigh "现在我在这里度过余生，帮助那些不再想成为生者的迷失灵魂。"
    io "他们跳入我的水中，将生死大事掌握在自己手中。"
    io smile "就像你做的那样，被污染的人。"
    red ow sweat frusta "什么？不，我没有……那只是个意外。"
    show red shock
    io "一个你希望以甜美的死亡之乐作为终结的意外。"
    red sad sigh "..."
    show side_p s at pic
    mc "塞恩……"
    hide side_p
    red huh frusta "……当我们在那里溺水时，确实有这个想法闪过。我觉得那可能是最好的结局。我不想再伤害任何人了。"
    show red sad shock
    show side_p s at pic
    mc "我们可以治愈这个，也许如果我们建立一个联系——！"
    hide side_p
    red grit -sweat frusta "不！你会永远被我困住的，[povname]！我不能让你这么做，你有自己的世界和家人要回去！"
    io frown sigh "确实，这位带着死亡气息的访客不是你能留下的。但还有另一种方法可以压制野兽。"
    red ngeles sweat apa "怎么做？"
    show red sad -sweat shock
    io smile -sigh "来吧。跳入我的水中，我会让你在平静中度过余生的永恒。"
    io "在你自己创造的梦境中。一个你可以成为任何你想成为的人的幻想世界，包括成为人类。一个普通的、无害的人类。"
    red ew apa "……会疼吗？"
    show red sad shock
    show red -shock
    show side_p m at pic
    mc "塞恩！不，别上当。"
    show side_p he 
    mc "我是说，我们几乎不了解她！"
    hide side_p
    io smile "我愿意回答你们可能有的任何问题。包括你们心中最迫切的那个……"
    io frown "你们可能会问，这是什么地方？"
    io "这些漂浮着尸体的黑色水池。嗯，它们是血。"
    red ngeles sweat shock "什么？！所以他们真的死了？"
    show red sad -shock
    io "让我澄清一下，这是科尔的血。不过，我相信你们猎人称之为符文墨水。"
    show side_p he at pic
    mc "……什么？"
    hide side_p
    io "这些尸体是我的杰作。我不知道把这些孩子放在哪里最合适。"
    io "这真是件悲哀的事，自杀造成的死亡比瘟疫还多。多年来填满的水池比我预想的要多。"
    red ew frusta "等等，等等，停一下，女士！你说这些黑色的水池是符文墨水？而且是科尔的血？！"
    io frown sigh "是的。这是教会最黑暗的罪恶。科尔从未死去。她被困在这里。像奶牛一样被榨取。"
    play sound "sound/effects/walk.mp3"
    show mahkota with dissolve
    galleryunlock mahkota
    io -sigh "唯一的区别是她被赐予了一顶王冠。"
    show red kaget shock
    stop music
    play sound "sound/effects/cloth.mp3"
    show blud_overlay with vpunch
    play sound "sound/effects/splat.wav"
    "伊欧将王冠放在你的头上，当它落在你的头皮上时，它的带子立即收紧了。"
    "仿佛有百万根倒刺直接刺穿了你。"
    show side_p s at pic
    mc "啊啊啊！" with vpunch
    hide side_p
    show side_r skul sad at pic
    red "[povname]!!!"
    hide side_r
    "你因疼痛而弯下腰，跪倒在地。伊欧将王冠从你头上取下，放回垫子上。"
    hide mahkota with dissolve
    hide blud_overlay with dissolve
    show red ngeles sweat frusta
    io smile sigh "很痛苦，对吧？这只是科尔几个世纪以来经历的痛苦的一小部分。"
    io "被困在这里，唯一的目的就是满足你们人类对力量永不满足的渴求。"
    io frown -sigh "别担心，你不是科尔，所以王冠没有榨干你的血。"
    io "对她来说，这美丽的王冠变成了荆棘之冠，生长并缠绕在她的手掌和手腕上……"
    play music "MUSIC/MusMus-BGM-CP05.mp3" fadein 5.0
    io "……刺入她的血管，让更多的血流出来。"
    show red sad sigh
    play sound "sound/effects/cloth.mp3"
    "你平静下来，站了起来，塞恩保护性地将你搂在怀里。"
    show side_p m at pic
    mc "什么……搞什么鬼？！你是说我们一直在用的墨水其实是她的血？"
    hide side_p
    red ow "不可能！那他们周围的墨水工厂呢？"
    show red kaget shock
    io "都是谎言，都是教会编造的。所有的墨水都来自这里。就在她的学校下面。"
    show red sad -shock
    io "这些水连接着许多运河。你们所谓的生产工厂根本不生产，只是负责分配。"
    io "否则为什么会出现墨水短缺？她已经不在了，只留下两个浅浅的血池。"
    show pboy at horzappear
    menu:
        "这确实解释了很多。":
            hide pboy
            $ honesty += 10
            $ curiosity -=20
            "伊欧听到你的话后轻笑起来。"
            show red huh
            io smile sigh "如此简单。要是你的对应者也这么容易看透就好了。"
            io frown frusta "或许那样的话，我就不会给自己施加这个诅咒了。"
        "还有谁知道这件事？":
            hide pboy
            show red kaget shock
            io frown sigh "你们的校长知道，还有在他之前的每一任校长。"
            red bingung apa "那老师们呢？"
            show red huh -apa
            io -sigh "不。"
            red huh "你怎么确定的？" 
            io "我的眼睛能看到一切。犹大之星让我能窥视每个人的灵魂。"
            io "他们的未来，他们的过去。我唯一的遗憾是没有早点给自己施加这个诅咒。"
            io "如果我早点这么做，也许科尔就能幸免于难了。"
            

        "所以...是[povname]的错。" if "diary_read_2" in my_events:
            hide pboy
            $ kindness += 5
            red kaget shock "嗯？"
            show side_p m at pic
            mc "我的分身与科尔建立了联系，偷走了你的神。现在这个世界正因此而受苦。"
            hide side_p
            red ngeles sigh "不，这不可能，[povname]..."
            show red sad -sigh
            io smile "与其说是受苦，我倒认为这只是事物的本质。"
            io frown frusta "这个位面上没有人配得上成为神。就连科尔也不行。"
            io sigh "她只是个愚蠢的女人，太...太善良了。"
            io smile -sigh "但我们都有自己的诅咒。她的血，现在还有我的眼睛。"

    red point grit shock "诅咒？"
    show red sad frusta
    io smile sigh "一切都会在适当的时候解释清楚的。"
    show side_p he at pic
    mc "你们巫师总是这么神秘兮兮的吗？"
    hide side_p
    io -sigh "否则你们人类无法承受真相。"
    io frown "我已经等待这一天好几个月了。这一天将决定这个世界的命运。"
    show side_p m at pic
    mc "什么？"
    hide side_p
    show Io smile
    "你想让她详细解释，但她只是报以温柔的微笑作为回应。"
    io "一切都会解释清楚的，小家伙们，不过要分开解释。"
    show red kaget shock
    io cling "毕竟，我不认为应该在其他人面前公开讨论关于我心脏的赌注。"
    show red sad -shock
    show side_p s at pic
    mc "你知道？"
    hide side_p
    io frown -cling "这双眼睛能看到一切。每种可能性，每个结果，未来、过去和现在。"
    show red chin huh
    io smile "你将带来我的死亡。但这将是我自己选择的，即使最后决定权在你手中，[povname]。"
    io "你想要我的心脏，对吧？为了唤醒弑神者。"
    io "你那命运多舛的分身。我对此并无异议，让我的心脏被挖出来唤醒一个全新的灵魂。"
    io "然而，我确实希望能得到一些回报。这是我只会在我们两个单独相处时讨论的事。"
    red ew frusta "我是说，我可以离开？如果我知道怎么离开的话..."
    show red sigh
    io "耐心点，被污染的人。我很快就会把你们两个从我的领域中释放出去。"
    io "不过，你们的梦境，那就是另一回事了。"
    io "回到地面上去吧，[povname]，塞恩。回去后把这些带上。"
    show Io no frown
    show red frown -sweat shock
    play sound "sound/effects/crumple.mp3"
    "伊欧掰断了她蛇的一根肋骨，分别给了你和塞恩各一片。那条蛇看起来并没有因此受到什么伤害。"
    show red huh -shock
    io smile "这是让你们记住我的纪念品，也是在梦中与我联系的方式。"
    io "只有在那里，我才会畅所欲言。既是为了我心脏的代价..."
    show red frown 
    "她的眼睛闪烁着看向你，她的蛇在此时发出嘶嘶声。"
    show Io frown with move:
        xalign 0.4
    show red ngeles sweat shock
    io smile "...也是为了你渴望的平静亡灵生活。"
    show red sad -sweat -shock
    "伊欧说着，擦去了塞恩下巴上的血迹。"
    io "现在，回到地上世界去过你们的日子吧。我会耐心等待你们两个的决定。"
    show red point bingung apa
    show red kaget shock
    play sound "sound/effects/bump.mp3"
    hide red with moveoutleft
    show Io sigh at center with move
    show side_p he at pic
    mc "什么？哇哦——！" with vpunch
    hide side_p
    
    stop music
    play sound "sound/effects/splash.wav"
    scene pier_night with rain1
    "直到伊欧用力推了你一把，你才意识到自己已经靠近了水边，你和塞恩都被推回了水中。"
    "你屏住呼吸，再次感受到水流的拉力，将你往水下拖去。"
    show red ngeles sweat frusta at center with dissolve:
        yoffset 330
    red "呼！[povname]，你没事吧？"
    show red at right with move
    if girl:
        show palmierproxy chill sad at left with moveinleft:
            yoffset 40
    else:
        show palmierproxy chill sad at left with moveinleft:
            yoffset 100
    mc ow sweat frusta "哈！"
    play sound "sound/effects/splash.wav"
    queue sound "sound/effects/cloth.mp3"
    "当你挣扎着想要保持漂浮时，塞恩帮助了你。他扶着你，把你拉到木制平台上。"
    "塞恩盛宴的残骸依然留在那里。"
    "他还算有礼貌地把那些东西推回水里，然后把你拉上来坐下。你的双脚悬在水面上。"
    play music "MUSIC/MusMus-BGM-077.mp3"
    mc hister sigh "哈啊……好吧，看来我们找到下一个巫师了。"
    red bingung frusta "你怎么能对这事这么冷静？"
    show red sad sigh
    mc panik -sigh "我并不冷静。但老实说，这个世界上已经没什么能让我感到惊讶的了。"
    show red frown shock
    show palmierproxy frown -sweat
    play sound "sound/effects/crumple.mp3"
    "你在口袋里翻找，找到了伊欧给你的那小块骨头。"
    "你注意到塞恩也做了同样的动作，他轻抚着那块骨头，仿佛那是什么珍贵的东西。"
    show pboy at horzappear
    menu:
        "……别死，塞恩。":
            hide pboy
            $ mrh.points += 5
            mc side frusta "别死，塞恩。"
            red ew frusta "啊……哦……是啊。如果你担心的是这个，我并没有主动寻死的想法。"
            red sayang sigh "我只是想……嗯，如果我反正都要死的话，那可能这样最好。对其他人来说更好。"
            if "drained" in fia_events:
                red sad sweat -sigh "尤其是菲亚，我——该死，她现在是不是恨我？"
                mc wry sigh"不。但我觉得你该道个歉。"
                red sad "嗯。"
            red sweat ngeles frusta "我真的不是有意伤害任何人的。"
            mc deject sigh "我知道。"

        "我们应该告诉其他人。":
            hide pboy
            red ew sweat frusta "……连我的……咬人问题也要说吗？"
            mc wry sweat "是的，连那个也要说。谁知道呢，也许奎尔有治疗的方法。"
            mc hister "我们应该保持开放态度。"
            show palmierproxy frown -sweat shock
            red ngeles sigh "但如果……如果我吓跑他们怎么办？"
            show red sad shock
            mc scratch ha sigh "奎尔把[povname]弄昏迷了，阿什姆也不是什么圣人。得了吧，我不认为这会吓到他们。"

            if "drained" in fia_events:
                mc chill malu -sigh "就连菲亚都原谅你了。"
                red kaget shock "她原谅我了？"
                mc mean cling "是的。不过如果你再咬她一次，你我就得好好谈谈了，伙计。"
                show palmierproxy kind -cling
                red wry apa "我明白。我……我能见她吗？"
                "塞恩抬头用恳求的表情看着你。你立刻明白了菲亚所说的他那狗狗眼的意思。"
                show red cowo blush -apa
                "你本能地拍了拍他的肩膀，因为你很清楚他不喜欢别人碰他的头发。"
                mc happy "是的，她会喜欢的。"
                mc kind "我也会喜欢的。"
                show red wry sigh
            else:
                red wry sigh "是啊，我想是这样。所以，运气好的话，也许他们会更关注巫师的事。"
                mc panik -sigh "希望如此。"
    mc happy -sigh "好吧，我想我们该回去了。"
    show palmierproxy confused shock
    red ngeles sweat shock"啊，等等！"
    show red wry -shock at center with move
    play sound "sound/effects/cloth.mp3"
    "就在你准备起身离开时，塞恩拉住了你的右手，他的手指与你的交织在一起，抬头用恳求的眼神看着你。"
    red ngeles "对不起，但你能再陪我一会儿吗？我……"
    red huh both sigh "我还不想一个人待着。"
    mc frown -shock"好吧。"
    show red wry sigh
    "你留在他身边，坐着让他握着你的手。"
    red sad sweat frusta"我真的不是有意伤害任何人的。"
    show palmierproxy side sigh
    "他低声喃喃自语，声音轻得你几乎听不见。"
    mc wry -sigh"我知道。"
    show pboy at horzappear
    menu:
        "握紧他的手":
            hide pboy
            show palmierproxy malu blush with move:
                xalign 0.35
            red wry blush sigh "啊。"
            
            "当你加重了握力，塞恩深深地叹了口气，仿佛他很高兴你理解了此刻他正需要什么。"
            "一些能让他回到现实的东西。"
            $ kindness += 10
            $ curiosity -= 5
            $ mrh.points += 5
        "缓解气氛":
            hide pboy
            $ curiosity += 5
            $ kindness -= 10
            $ kindness -= 10
            if kindness < 0:
                $ kindness = 0
            mc kind tanya "那么，你是怎么抓到那么多鱼的？"
            red wry blush sigh "嗯？哦，我是个不错的渔夫。我妈妈以前常带我出去猎捕各种东西。包括鱼。"
            mc smile -tanya "那很好。我妈妈不太喜欢钓鱼。她觉得这对鱼不公平。"
            mc scratch panik frusta "不过她只对非肉食性的鱼感到愧疚。"
            red hister -sigh "我能理解。就我个人而言，如果我是条鱼，我想成为小丑鱼。海葵看起来超级蓬松。"
            mc chill happy -frusta "嗯，我想我会想成为一条水滴鱼。"
            red bingung -blush apa "水滴鱼是什么？"
            show red datar -apa
            mc smile "哦，它们是……"
            "你们花了一些时间谈论鱼。虽然这可能不是塞恩所期待的，但他似乎很感谢你试图让他开心起来的努力。"
    stop music
    scene bg_black with w20
    "当你偷偷溜回房间准备休息时，天已经快亮了。你在床上辗转反侧，想知道伊欧会多快入侵你的梦境。"
    "那么多问题，却只有寥寥无几的答案。你尽力让自己嗡嗡作响的大脑平静下来，希望今晚能再次看到伊欧的脸。"
    scene io_altar with eye_open
    if girl:
        show palmierproxy chill frown at right with moveinright:
            yoffset 40
    else:
        show palmierproxy chill frown at right with moveinright:
            yoffset 100
    mc scratch confused "伊欧...？"
    play sound "sound/effects/walk.mp3"
    show ivar ejek at left with moveinleft:
        yoffset 150
    iv ancam "恐怕不是她。"
    play music "MUSIC/MusMus-BGM-112.mp3"
    show ivar ejek
    mc chill pissed frusta "哦，是你啊。"
    show palmierproxy confused -frusta
    iv amused apa "哼。我几乎能尝到你的失望。你本可以假装见到我很高兴。哪怕只是为了礼貌。"
    show ivar -apa
    mc grit sigh "才不呢！上次你刺伤了我的眼睛！"
    show palmierproxy kzl -sigh
    iv ejek sigh "公平。"
    show bg_park behind palmierproxy with wet
    show palmierproxy frown shock
    "伊瓦尔一转身，整个景观就变回了他的花园。"
    "只是这次你已经离开了他常待的露台，来到了他领地左上角的废墟处。"
    "你已经盯着这里看了一段时间了。感觉它格格不入。"
    iv kzl "那是因为它确实如此。这是一座古老神庙的遗迹。当时水手们从四面八方前来，希望得到她的帮助。"
    iv flirt -sigh "却不知她是个巫师。"
    show ivar amused 
    mc confused "你说的是伊欧吗？"
    $ my_events.append("io0")
    iv frown sigh "是的，虽然我更喜欢称她为母亲。"
    mc sad sweat shock "母亲？！你是她的儿子？！"
    show palmierproxy -shock
    iv "不是血缘上的，而是心灵上的。她从我还是个婴儿时就抚养我长大。"
    iv amused "虽然没有血缘关系，但我相信莱尔对海洋的亲和力来自于我的母亲。"
    iv ejek sigh "我毫不怀疑他很快就会超越他那个不称职的导师派克。"
    show palmierproxy frown 
    show pboy at horzappear
    menu:
        "你一直在监视莱尔？":
            hide pboy
            iv kzl frusta "当然。无论他多么希望否认，我仍然是他的父亲。"
            $ curiosity -= 20
            $ honesty += 10
        "你为什么要让莱尔离开？":
            hide pboy
            $ curiosity += 15
            $ honesty += 5
            iv ejek cling "你凭什么认为是我让他离开的，而不是他从我的监视下逃脱的？"
            mc pissed frusta "如果你现在能在某个高级反巫师学院里监视他，那么当他在你自己的地盘上时，你肯定也能监视他。"
            iv amused sigh "嗯，聪明又美丽，你真是少见。"
            iv ancam cling "让我想把你也加入我的花园。"
            mc grit sigh "尽管来吧，我会变成一朵尸花，把这里熏得臭气熏天。"

        "我以为你恨你的儿子们。":
            hide pboy
            $ honesty += 20
            $ curiosity -= 20
            iv kzl sigh "恰恰相反，我爱他们比你知道的更深。"
            mc rajuk frusta "如果你的爱意味着把他们变成无思想的花园管家，那我真不敢想象你对你的妻子们做了什么。"
            show palmierproxy kzl -frusta
            iv amused "你大胆假设我所有的后代都是合法的。"
            mc confused sigh "你看起来不像是\'婚外情\'的类型。"
            iv awk sigh "你说得对...我确实不是。"
    mc pissed frusta "你到底想要什么，伊瓦尔？别再拐弯抹角了！"
    if "ketemu_buli" in buff_events:
        iv kzl frusta "真是急性子。"
        iv frown -frusta "..."
        show palmierproxy frown shock
        iv awk "我想感谢你在面对阿贾克斯时为我儿子挺身而出。"
        iv frown sigh "孩子们对那些与众不同的人可能会非常残忍。"
        mc deject sweat "哦..."
        mc "（我没想到会是这样。）"
        show pboy at horzappear
        menu bungbung:
            "没有奖励吗？":
                hide pboy
                mc mock -sweat cling "你知道，如果你真的想感谢我，你可以把你的心给我？"
                iv kzl frusta "哼，狂妄自大。我还没有感激到那种程度，小水仙。"
                mc apa tanya "水仙？"
                iv awk cling "很适合你。"
                mc wry sigh "因为我金发小个子？我是说相对于你来说小。"
                iv flirt -cling "这只是其中之一。"
                show ivar amused
                mc kind -sigh "那莱尔是什么花呢？"
                iv frown "我不知道，没有哪种花适合他。他很特别。"


            "他拯救了自己。" if "bunga_time" in buff_events:
                hide pboy
                mc confused tanya "我以为你只会把你的力量传给你的女儿们。"
                show palmierproxy frown -tanya
                iv frown sigh "我不会。与普遍的看法相反，我平等地爱着我的每个孩子。"
                iv kzl frusta "然而，我的儿子们在某个年龄后会变得...过于依恋。因此，为了我们双方的安全，把他们变成花朵反而更好。"
                show ivar frown -frusta
                mc "但你没有对莱尔这么做。"
                mc apa tanya "...为什么？"
                show palmierproxy kzl -tanya
                iv ancam "哎呀，你可真爱打听啊？"
            "{s}他自救了{/s}。" if "bunga_time" not in buff_events:
                jump bungbung
        iv amused sigh "你只需要知道，我很感激你收留了他。"
        iv smirk -sigh "我确实有东西要给你，以表达我的谢意。"
        iv frown "关于下一个巫师的警告。"
        iv "塞斯，或者更准确地说，是变化巫师。"
        iv kzl "他盯上你了。要小心，因为塞斯不会固守单一形态，经常随心所欲地更换身体。"
        iv "注意你的周围环境，尤其是那些有奇怪眼睛的人。"
        mc huh sweat tanya "哦...谢谢？你为什么要帮我？"
        show palmierproxy frown shock
        iv kzl frusta "我不是在帮你。我是在帮我自己。他对我做过许多残暴的事。"
        iv sigh "说我们相处不好，这简直是轻描淡写。"
        mc confused -shock "好吧，你们互相憎恨，为什么？"
        show palmierproxy side shock
        iv frusta "他杀了我的一个女儿。"
        mc ew -shock "哦。"
        show pboy at horzappear
        menu:
            "有正当理由吗？":
                hide pboy
                $ kindness -= 20
                $ curiosity += 20
                $ honesty += 5
                show palmierproxy sad 
                iv kzl sigh "那是在1692年，我隐藏在人类中间的时候...他追求我的一个女儿，布里奇特。"
                iv frusta "他向她求婚。她拒绝了。他就给她戴上了枷锁，并揭发她是个巫师。"
                iv "镇上的人随后活活剥了她的皮，在镇广场上当着所有人的面烧死了她。"
                iv sigh "所以不，这不是什么正当理由。"
                show ivar frown -sigh
                mc sad "哦。"
                mc side frusta "（天啊，[povname]，你真是个混蛋。我发誓，有时候感觉好像有人在控制你做出糟糕的决定或什么的。）"


            "保持沉默":
                hide pboy
                $ kindness += 10
                $ honesty -= 15

        show palmierproxy sad sigh
        iv kzl frusta "我试图以牙还牙，但只成功挖出了他的一只眼睛。"
        iv sigh "我们现在陷入了僵局，都不再处于巅峰状态。"
        iv frown "他在躲避我，我也在躲避他。但这并不意味着他不会向你现身，尤其是现在你已经见过了伊欧。"
        iv ejek cling "你现在已经陷得太深了，小水仙。不如在你深入的同时好好利用你。"
        mc kzl -sweat shock "所以你是在利用我。"
        show palmierproxy -shock
        iv ancam -cling "现在是的。这都怪你太能干了，[povname]。"
        mc rajuk sigh "哼。"
    elif "nari" in buff_events:
        iv smirk sigh "我想要感谢你。"
        mc frown tanya "感谢我？"
        iv amused -sigh"因为你教我儿子跳舞。"
        mc confused shock "等等，你知道这件事？"
        iv smirk "我知道很多事，包括跳舞。如果不是因为...现在的情况，我本来会亲自教他的。"
        mc ha sigh "你是说他吓得要死不敢接近你？"
        show palmierproxy wry -sigh
        iv awk cling "这个，还有其他原因。你跳得不错。你的优雅让我想起了我的女儿们。"
        if not girl:
            iv kzl sigh "尽管你的身体更偏向男性。"
            mc panik "是啊，我没有那样的胸部。"
        else:
            iv amused -cling "你有着和她一样金色的头发和美貌。你真的让我想起了她。"
            mc panik "除了胸部。"
        show palmierproxy sad sweat shock
        iv kzl frusta "你觉得我，作为她的父亲，会在意她身体的那部分吗？"
        "他似乎被你的话冒犯到了。很高兴知道即使在这个混乱的世界里，乱伦也不是什么好事。"
        mc ha -shock "嗯，我希望不是。"
        iv sigh "确实不是。"
        mc mean "嗯。我猜你从未有过父女共舞的经历，对吧？因为你没有出席婚礼。"
        iv frown -sigh "我在那里，从外面的茉莉花瓣中观察。我目睹了婚礼仪式和她的死亡。"
        mc scratch avoid "哦。"
        iv kzl sigh "是的，\'哦\'。"
        iv frown -sigh "不管怎么说，她很美，虽然我希望是我能够陪她走过红毯。"
        iv "而不是某个陌生人，我敢肯定她雇来的只是为了装样子。"
        mc wry -sweat sigh "嗯，听起来你对此很不爽啊。"
        iv kzl frusta "如果你是指恼火、烦恼，那么是的。很苦涩。"
        iv ancam cling "苦涩到我宁愿接受一个替代品，即使它毫无意义。"
        mc chill apa shock "嗯？"
        show palmierproxy frown 
        show ivar amused apa
        "伊瓦尔走近你，向你伸出手。在背景中，你注意到一阵轻柔的嗡嗡声。"
        "这嗡嗡声之后是悠扬的音乐，你确信是从背景中的一些喇叭花里传出来的。"
        mc side sweat tanya "你是在...邀请我跳舞吗？"
        iv smirk cling "我是在请你假装。一支父女舞。"
        iv awk -cling "就当是你在安慰一个为失去孩子而悲伤的老人吧。"
        show palmierproxy frown -tanya
        show pboy at horzappear
        menu:
            "握住他的手":
                hide pboy
                $ curiosity += 10
                $ honesty -= 15
                mc ow frusta "...别把我变成花。"
                iv amused cling "我保证不会。"
                show palmierproxy sad -frusta
                "你勉强地握住了他的手。"
                show palmierproxy frown shock with move:
                    xalign 0.7
                show ivar amused -cling with move:
                    xalign 0.3
                "他轻轻地将你拉入怀中，一只手与你的手交缠。另一只手高高地放在你的背上——就在你的肩胛骨之间。"
                show palmierproxy malu blush -shock
                "他轻松地带领着，一开始很慢，仿佛在试探。"
                "很快你就沉浸其中，沉醉于音乐和他强有力的心跳声中。"
                show palmierproxy kzl both shock
                show ivar ejek cling
                "就在你刚刚感到舒适时，他smirked了。他大胆地旋转和扭动你，甚至将你举了起来。"
                "他用强壮的手臂环绕着你的腰，将你高高举起。"
                mc pissed frusta "喂！"
                iv amused sigh "这都怪你太轻盈了。你应该多吃点。"
                mc apa "我吃得够多了，现在把我放下来！停下！"
                iv flirt cling "如你所愿。"
                play sound "sound/effects/bump.mp3"
                mc sad sweat shock"哇啊！" with vpunch
                play sound "sound/effects/cloth.mp3"
                if girl:
                    galleryunlock lap_ce
                    show lap_ce with dissolve:
                        truecenter zoom 1.0
                        easein 2.0 truecenter zoom 0.5
                else:
                    galleryunlock lap1
                    show lap1 with dissolve:
                        truecenter zoom 1.0
                        easein 2.0 truecenter zoom 0.5
                "显然，\"把你放下来\"的意思是他旋转着坐到一张椅子上，同时把你拉到他的大腿上。"
                "你以前也曾处于这种姿势，实际上很多次。不过，与你交往过的大多数男人不同，他没有把手放在你的腰部或臀部。"
                "相反，他的手高高地放在你的上背部，仿佛在防止你向后倒。"
                "他空闲的手没有在你的大腿上游走，而是落在你的膝盖上。然后他把手放在下巴上，歪着头，好像在思考。"
                "这个姿势有点让你想起了你还相信圣诞老人的日子，你坐在圣诞老人的腿上，许愿要礼物。"
                "或者像你小时候父亲让你坐在他膝盖上颠簸的样子。这有点贬低人。"
                
                if not girl:
                    galleryunlock lap2
                    show lap2 with dissolve:
                        truecenter zoom 0.5
                    hide lap1
                else:
                    galleryunlock lap_ce2
                    show lap_ce2 with dissolve:
                        truecenter zoom 0.5
                mc "这个姿势对于父女来说是不是有点太亲密了，你不觉得吗？"
                if not girl:
                    show lap2:
                        easein 1.0 zoom 0.8 yalign 0.0 xalign 0.5
                else:
                    show lap_ce2:
                        easein 1.0 zoom 0.8 yalign 0.0 xalign 0.5   
                iv "我只是让你在我们跳舞时假装。当你让我停下时，嗯，就没必要继续这场戏了。"
                mc "请告诉我你平常不会让儿子的朋友像这样跨坐在你腿上。"
                iv "你是第一个。"
                mc "{i}真是荣幸！{/i}"
                "你翻了个白眼，希望他能明白暗示。这似乎只是让他更加兴致勃勃。"
                if not girl:
                    hide lap2 with dissolve
                else:
                    hide lap_ce2 with dissolve

            "拒绝":
                hide pboy
                $ curiosity -= 10
                $ honesty += 15
                mc pissed sweat frusta "不。"
                iv ejek cling "害怕吗？"
                mc side sigh "是的。我无法摆脱你试图操纵我的感觉。"
                mc confused -sigh "美丽的人很擅长这个。"
                iv flirt "说的是你自己吗？你也是许多人眼中的美人。"
                mc mock -sweat cling "哦，我知道。但就像我说的，很难不信任一张漂亮的脸，所以我必须保持警惕。"
                mc judes sigh "尤其是在像你这样的人面前。"
                iv smirk -cling "我很感谢你的赞美。"
        
    else:
        iv frown sigh "...我想你了。"
        mc apa sweat shock "嗯？"
        iv kzl -sigh "这里很孤独。几十年来我都没有好好地聊过天了。"
        iv "我的儿子们无法进行对话，我的女儿们从不来看我。她们只是出去然后不幸早逝。"
        iv frown sigh "...有时候很孤独。"
        mc mock -sweat cling "是啊，那是谁的错？我不是你的情感泻药。"
        mc "显然你一定是个情感constipated的父亲，才会让你的孩子们如此恨你。"
        iv kzl frusta "你非得这么粗俗吗？讨厌的小崽子。"
        mc smile bunga "你说你想我。"
        iv sigh "我改变主意了。"
        iv frown -sigh "孤独远比你的厚颜无耻要好得多。"
    iv ancam cling "我现在就送你回去。别担心，这次我不会刺瞎你的眼睛。"
    mc huh sweat sigh "哦，{i}太好了...{/i}"
    show palmierproxy sad shock
    iv smirk "割开你的喉咙效果要好得多。"
    mc ew -shock "啊？！"
    stop music
    scene bg_black with wet
    play sound "sound/effects/splat.wav"
    $ calendar.next() #31 Mei
    $ night = False
    $ evening = False
    $ afternoon = False
    $ morning = True
    pause 1.0
    scene bed_pagi with eye_open
    play sound "sound/effects/cloth.mp3"
    show side_p m at pic
    mc "啊啊！" with vpunch
    hide side_p
    "你咳嗽着惊醒，焦急地摸着自己的脖子，直到确认没有血迹才平静下来。"
    show side_p he at pic
    mc "该死的，伊瓦尔..."
    hide side_p
    "你小声咕哝着，然后去洗了个澡，出门吃早餐。"
    "你希望塞恩在遇到巫师方面比你运气好得多。"
    $ my_events.append("io_curfew") # LABEL FOR MEEt
    scene bg_black with w20
    $ NPC = "???"
    jump io_sarap

label io_sarap:
    scene overcast with w20
    play music "MUSIC/MusMus-BGM-101.mp3"
    show quil flashy sulk frusta at center with dissolve:
        yoffset 200
    quil grit sweat "不，绝对不可能！"
    show quil kzl
    "一看到奎尔在食堂里的白发，你和塞恩立即把他和阿什姆拉了出去。"
    "奎尔设法为你们抓了几片面包，"
    "当你们开始在侧花园里谈话时，远离任何可能偷听的耳朵，你和阿什姆对此表示感谢，因为你们的肚子正在咕咕叫。"
    show red chin bingung apa at left behind quil with moveinleft:
        yoffset 330
    red "你说的是哪一部分，是我在背后发动攻击？还是我们学校下面有一个纯血巫师？"
    red "还是科尔的血液一直都是符文墨水？"
    show red huh -apa
    show tom hip capek frusta at right with moveinright:
        yoffset 190
    tom sweat "显然是全部！"
    quil err sigh "哦，科尔...我才离开你几分钟，[povname]，就发生了这种事？"
    show quil skul rajuk sigh
    show side_p he at pic
    mc "别怪我！"
    hide side_p
    tom scold kzl -sweat blow "看来你就是个麻烦磁铁。不过，这对我们来说倒是有利。你说这个巫师没有敌意？"
    show side_p w at pic
    mc "我是说，除了那些漂浮的身体，总的来说她还挺冷静的。"
    hide side_p
    quil amused -sigh "也许应该由我和阿什姆来判断。很难相信在她的领域里漂浮着尸体却没有恶意。"
    red frown "他们没事，我还能听到他们血管里的血液在跳动。他们还活着。"
    tom talk ew -blow "勉强算是活着。谁会想在梦境中度过余生呢？"
    show tom kzl 
    red point ew frusta "你不知道她的梦境有多真实！她昨晚给我看了，那些梦境美丽而真实。"
    quil rajuk -sweat sigh "那只是幻想。就像她的名字一样。"
    show red kaget shock
    tom hip whine apa "...你该不会真的在考虑把自己淹没在她的水中吧？"
    red sad sweat -shock "什么，不，不！{w}不！"
    quil sad sigh "你是在试图说服我们还是说服你自己？"
    red wry "两者都有？"
    show quil sulk
    show tom sad frusta
    show side_p s at pic
    mc "塞恩……"
    hide side_p
    red perih frusta "你们不明白！"
    show tom kzl shock
    show quil grit shock
    red ew "今天早上我咬了皮尔斯，我的室友。"
    quil ow frusta "塞恩！"
    red ngeles "只是轻轻咬了一下，但他跑去了护士办公室。用不了多久老师们就会开除我，或者更糟..."
    red perih "阿列克谢王子可能亲自来惩罚我。我们和伊格尼亚之间有和平条约。我的行为违反了那些协议。"
    red ngeles sigh "他可以杀了我，或者更糟..."
    show tom capek -frusta
    quil kzl sigh "肯定有解决这一切的办法。吸血鬼在灵魂绑定后不是就不会渴求其他人的血了吗？"
    show quil sulk
    "奎尔瞥了你一眼，尽管带着愧疚的表情。"
    show pboy at horzappear
    menu:
        "不可能！":
            hide pboy
            $ mrh.points -= 5
            if mrh.points <0:
                    $ mrh.points = 0
            quil err frusta "我只是说，你们两个最近关系很亲密。"
            tom scold sigh blow "我们不会强迫任何人绑定！"
            $ kindness -= 10
        "你为什么不这么做？":
            hide pboy
            $ honesty += 5
            quil amused cling "他渴望的是你。在他眼里，我只是小点心，而你才是正餐。"
            red ew frusta "我不会和你们任何人绑定！"
            tom scold ew frusta "够了，你们两个。现在谈绑定还为时过早！"
            
        "露出脖子（绑定）":
            hide pboy
            $ mrh.points += 15
            show side_p he at pic
            mc "我是说，如果真的那么糟糕的话..."
            hide side_p
            show red both ew shock
            show quil sad sweat shock
            show tom frown sweat shock
            play sound "sound/effects/vamp.mp3"
            "塞恩的獠牙立即伸了出来，划破了他的下唇。"
            show quil kzl -sweat -shock
            show tom kzl -shock
            red sad "该死！"
            red perih frusta "你不能这么做，[povname]！"
            red so sigh "...我-我想要通过爱来建立联系，而不是通过强迫！"
            tom talk frown -sweat blow "你应该这样想。"
    tom chill eh blow "听着，如果建立联系是唯一的选择，那我们到时候再说，但在那之前，我会看看能用血液药剂做些什么。"
    show tom frown -blow
    red wry blush sigh "谢谢你，阿什姆。"
    tom ha sweat frusta "先别谢我。我感觉从现在开始事情只会变得更糟。"
    quil mock apa "你这么认为？我们甚至还没谈到就在我们眼皮底下的巫师呢。"
    show quil frown -apa
    show tom frown -sweat -frusta
    show red frown -blush -sigh
    show side_p c at pic
    mc "把她交给我吧，我觉得她至少是友好的或无害的。"
    hide side_p
    quil bingung sigh "我们会自己判断的。这听起来太方便了。哪个巫师会心甘情愿地交出自己的心脏？"
    tom eh "也许是一个快要死的巫师。"
    show tom frown
    show side_p he at pic
    mc "快要死？你认为她是因为年老而死吗？"
    hide side_p
    quil rajuk -sigh "不，纯血巫师是不朽的，尽管某些咒语可能会消耗他们的寿命。也许她使用了一个特别恶毒的咒语。"
    tom scold ha "唯一的问题是为了什么。"
    quil heh "我会调查一下，关于伊欧和她的眼睛，看看有没有符合她描述的情况。我还有自己的研究要深入。"
    quil sly "也许它们以某种方式纠缠在一起。"
    tom hip frown "我会在药剂室。如果你需要什么就来找我。"
    red sad "我会..."
    $ red_events.append("bite_day") ###MARK FOR GOSSIP
    if "drained" in fia_events:
        red sayang "我去看看菲亚，看她是否还好。"
        red hister apa "[povname]，跟我一起去吗？"
        show side_p m at pic
        mc "（嗯。如果我跟塞恩一起去，我可能就无法在校园里四处走动或者了解奎尔和阿什姆在做什么了。）"
        show side_p s 
        mc "（不过，我也不想让他一个人。）"
        hide side_p
        show pboy at horzappear
        menu:
            "去":
                hide pboy
                show side_p w at pic
                mc "我跟你一起去。"
                hide side_p
                red wry sigh "谢谢。"
                jump maaf_fia
            "拒绝":
                hide pboy
                show side_p s at pic
                mc "抱歉塞恩，但我觉得你需要自己去向她道歉。"
                hide side_p
                red sad sweat sigh "哈...这很公平。祝我好运？"
                quil flashy heh cling "愿恶魔不要把你活剥了。"
                show side_p m at pic
                mc "喂。你说的可是我妹妹！"
                hide side_p
                quil sly -cling "不是你妹妹。"
                show side_p he at pic
                mc "嗯。"
                $ night = False
                $ evening = False
                $ afternoon = True
                $ morning = False
                hide side_p
                $ NPC = "???"
                $ fia_events.append("bond")
                scene bg_black with w20
                if "bunga_bego" in buff_events:
                    if "beku" in quil_events:
                        scene map_infected_f with w20    
                    else:
                        scene map_infected with w20    
                else:
                    if "beku" in quil_events:
                        scene map_frozen with w20
                    else:
                        scene map_all with w20
                jump world_map

    else:
        red ew sweat sigh "我去看看维尔科娃女士。我需要确保沃特克还没有联系她。"
        tom ha apa "你去吧。如果你需要什么就告诉我们，塞恩。我是说任何事。"
        show tom wry -apa
        red sayang -sweat -sigh "我会的。"
        $ NPC = "???"
        $ night = False
        $ evening = False
        $ afternoon = True
        $ morning = False
        $ fia_events.append("bond")
        scene bg_black with w20
        if "bunga_bego" in buff_events:
            if "beku" in quil_events:
                scene map_infected_f with w20    
            else:
                scene map_infected with w20    
        else:
            if "beku" in quil_events:
                scene map_frozen with w20
            else:
                scene map_all with w20
        jump world_map

###KELILING THANE
    
label maaf_fia:
    play sound "sound/effects/walk.mp3"
    stop music
    scene uks with w33
    stop sound
    show red chin sad sweat at left with moveinleft:
        yoffset 330
    show croissant frown def at right with moveinright:
        yoffset 500
    play sound "sound/effects/door.mp3"
    red ew frusta "菲亚..."
    show red kaget shock
    play music "MUSIC/MusMus-BGM-047.mp3"
    fia flinch pity "你最好带些食物来，和你舌尖上挂着的那份道歉一起。"
    "你对此窃笑了一下。她放下手机，凝视着塞恩的灵魂深处，整个过程显得那么漫不经心。"
    red ngeles -shock "等等，你不生气吗？"
    show red sad
    fia mock cling "我得到了两天不用上学的机会，而你把塔图姆送进了医院。真希望你能拍张那婊子受苦的照片，不过除此之外，我们没问题。"
    red ew frusta "但是...我咬了你。"
    show red sad -frusta
    fia def sad sigh "而你因此哭得像个婴儿。这是个意外，虽然我怀疑在你咬了你的室友之后，任何老师都不会相信这一点。"
    show side_p s at pic
    mc "哦，所以你听说了？"
    hide side_p
    fia gross frusta "谁没听说？他真是个戏精，声称看到了光明和科尔本人。"
    red perih frusta "哈。太好了。"
    show red shock
    fia mock cling "你觉得现在给他洗脑是不是太晚了？也许可以诱导他相信这一切都是一场梦？"
    show side_p he at pic
    mc "我们能不能至少有一天不谈论对同学做可怕的事？"
    hide side_p
    show croissant frown shock
    show red frown -sweat shock 
    stop music
    play sound "sound/effects/door.mp3"
    show nun cross sigh at center with dissolve:
        yoffset 100
    nun "洗脑本来是个好主意，但恐怕现在太晚了。"
    red ngeles -shock "维尔科娃女士！我很抱歉，我不—"
    play music "MUSIC/Action-Rhythm-4.mp3"
    nun hand -sigh "省下你的借口吧，塞恩。你会需要它们的。"
    fia err apa "你这是什么意思？"
    show croissant frown -apa
    nun cross frusta "血骑士的大祭司今早联系了我。塞恩的行为已经传到了首都。"
    red ew sweat frusta "这么快？"
    show red sad
    show croissant sad
    nun sigh "这不是关于你在这里的过错。是塔图姆小姐和她的同学们报告的。镇上的医生认为一旦他们恢复意识就应该立即通知当局。"
    nun proud -sigh "大祭司将于6月7日到达。我们希望能尽可能低调地解决这件事。"
    red ngeles shock "大祭司？来这里？！"
    show red sad -shock
    nun frusta "塞恩，你不能说你没有预料到这一点。"
    red ew "...我本希望塔图姆和其他人能再昏迷一段时间。"
    red bingung apa "那么我会怎么样？"
    show red ew shock
    nun sigh "从她暗示的来看，死亡。或者更糟...血液污染。"
    red ngeles -shock"不行！"
    show red sad -shock
    fia err sweat "血液污染？"
    nun hand -sigh "他会被喂食仙子和独角兽的血，直到失去人性。将他变成一个邪血者。"
    fia sad "邪血者不是那些野蛮的蝙蝠状野兽吗？我以为它们是真正的动物，而不是吸血鬼！"
    nun cross frusta "失去理智的吸血鬼和野兽没什么区别，菲亚。可悲的是，沃特克利用这一点，把他们当作对付狼人的武器。"
    play sound "sound/effects/growl.mp3"
    show vamp_rawr0 with fade
    show vamp_rawr1 with moveinright
    galleryunlock vamp_rawr
    pause 1.0
    show sipit 
    red "我不会变成邪血者的！我母亲牺牲了她的人性来保护我，不是为了让我经历同样的命运！"
    "塞恩爆发了，他的皮肤上开始出现几张嘴。他的眼睛变得血红，流下血泪。这景象让你不寒而栗。"
    "你出于恐惧本能地用身体护住了菲亚。"
    hide sipit
    hide vamp_rawr1
    hide vamp_rawr0 with dissolve
    show croissant flinch cringe
    red kaget shock "啊——！"
    show red sad frusta
    "塞恩试图让自己平静下来，成功收回了所有的獠牙和嘴巴。他的眼睛恢复了平常的棕色。"
    nun proud sigh "给点时间，你甚至不需要被污染就能变成邪血者。"
    nun shock -sigh "你正在失控，塞恩。"
    red sad "...我知道。"
    red sigh "我会回房间，今晚把自己锁起来。"
    nun cross "不。"
    red kaget "不行？"
    show red huh
    nun sigh "沉溺于自怜只会让你的状况恶化。"
    nun -sigh "你应该去和朋友们在一起。在人群中你更有可能控制住自己，而不是独处。"
    show croissant def frown -sweat shock
    nun hand "如果你想的话，可以带上菲亚，她已经出院了。只要待在人群中，就不会再发生咬人的事。"
    red bingung frusta "我不知道，如果我再伤害到别人怎么办？"
    fia jijik -shock "我不会让你这么做的！我们会盯着你的。对吧，[povname]？"
    show pboy at horzappear
    menu:
        "你自己看着办吧，伙计！":
            hide pboy
            fia kzl frusta"[povname]!"
            $ kindness -= 20
            $ mrh.points -= 10
            if mrh.points <0:
                    $ mrh.points = 0
            red sayang sigh "不，[nickname]说得对，菲亚。这是我必须承担的负担。"
            fia mmh -frusta "胡说八道！一定有我们能做的事，对吧，维尔科娃女士？"
        "当然！":
            hide pboy
            $ mrh.points += 10
            $ kindness += 10
            show side_p he at pic
            mc "没错。我们再和奎尔还有阿什姆谈谈，看看有什么选择。"
            show side_p s 
            mc "我们不会放弃你的，塞恩！"
            hide side_p
            red wry sigh"谢谢。"
        "我非得这么做吗？（开玩笑）":
            hide pboy
            fia mmh frusta "[povname]!"
            $ kindness -= 10
            show croissant sad -frusta
            show side_p w at pic
            mc "我开玩笑的，开玩笑的！"
            show side_p 
            mc "但你们究竟指望我们做什么呢？"
            hide side_p
    nun cross sigh "建立羁绊是你最好的选择。除非你们找到了另一种抑制塞恩对血液渴望的方法。"
    fia mad "我们会去图书馆看看有没有什么办法。"
    red frown -sweat "我们应该和奎尔还有阿什姆谈谈，他们也需要知道这件事。"
    fia frown "对！"
    stop music
    play sound "sound/effects/tile.mp3"
    jump tomquilmeet

label tomquilmeet:
    scene fort_upper with w33
    stop sound

    show tom chill nyesal at center with dissolve:
        xalign 0.55
        yoffset 190
    show quil skul sad at right with dissolve:
        yoffset 200
    show red chin sad at left with dissolve:
        yoffset 330
    show croissant def frown at left with dissolve:
        yoffset 500
        xzoom -1.0
        xalign 0.0
    "你给阿什姆和奎尔打了电话，在屋顶上举行聚会，这样就没人能偷听了。"
    play music "MUSIC/MusMus-BGM-059.mp3"
    tom capek frusta "[povname]，麻烦就像瘟疫一样跟着你。"
    quil bingung apa "说真的。亲爱的，我们才刚聊过一个小时，为什么每一秒都有更多的厄运降临？"
    fia mad frusta "别抱怨了，开始动用你那聪明的大脑。我们需要帮助塞恩摆脱这个困境。"
    quil heh -apa "哦，这是在夸我吗？一定是世界末日到了。"
    fia gross "等你告诉我们如何拯救塞恩，我会给你更大的赞美。"
    fia flinch cringe sigh "或者如果建立羁绊是唯一的办法，那么是谁来做。"
    red point ew frusta "我不会强迫你们任何人与我建立羁绊。"
    show red huh -frusta
    show side_p s at pic
    mc "你没有强迫我们，我们是自愿的。我想我们大多数人都愿意。"
    hide side_p
    "你忍不住瞥了一眼阿什姆和奎尔，他们都转过头去。"
    tom whine blow "哈啊...塞恩，我关心你，但你知道仙子和吸血鬼之间的羁绊通常会有什么结果。"
    show tom sad -blow
    quil sulk sigh "如果我们建立羁绊，我父亲和整个英克威尔家族都会盯上我们的。"
    quil hister sweat -sigh "我是说，在正常情况下我会接受的——我终于可以避免被安排婚姻的恐惧了。"
    quil bingung "但是我有些事情必须要做，所以..."
    fia def sad sigh "所以基本上，[kk]和我是你唯一的选择。"
    tom talk ha "如果说到建立联系的话。我们还有时间。"
    fia cringe "是吗？也许我们应该直接...把这事解决了。"
    fia err apa "我是说，你和我都不在乎最后和谁在一起，对吧，[povname]？"
    show pboy at horzappear
    menu:
        "我来做吧。":
            hide pboy
            show croissant frown shock
            show side_p f at pic
            mc "我来做吧。这样对大家都好。"
            hide side_p
            show quil wry
            show red sad 
            $ mrh.points += 5
            "你看了看你的朋友们，希望他们能理解。不需要你脱口而出你不是真正的[povname]这个事实。"
            show tom calm blow 
            "阿尔森似乎是最快理解的人。他点头表示同意。"
            red chin ew frusta "不，我的意思是，我很感谢你的提议。但我认为我们还是应该先找找其他办法！"
            show red sad -frusta
        "你应该去做。":
            hide pboy
            show side_p f at pic
            show croissant frown -apa
            mc "我觉得你应该去做。如果你觉得可以的话。"
            $ mrh.points -= 15
            if mrh.points <0:
                    $ mrh.points = 0
            hide side_p
            quil grit frusta "等等，等等，别急。不行！"
            quil groan sigh "菲亚，你可以找到比一个被流放的脑子里装满屎的吸血鬼好得多的人！"
            fia flinch cringe shock "现在别说了，奎尔！"
            red ngeles sigh "他说得有道理，而且被侮辱的人是我，菲亚。"
            red wry -sigh "你值得比花一生和我这样的人在一起好得多的人。"
            show red kaget both shock
            show tom shock
            show quil shock
            fia def mmh blush frusta "...即使是我想要这样呢？"
            show side_p he at pic
            mc "嗯？"
            show side_p m
            mc "（等等，那个脸红...）"
            show side_p f
            mc "你喜欢他？！"
            hide side_p
            fia pity -frusta "...也许吧？"
            tom amused blow "好吧，这确实改变了情况。"
            quil sulk sweat frusta "说真的，是他？！"
            show quil frown shock
            show tom frown -blow
            red ew frusta "伙计们，我就在这儿呢。"
            red mls -both sigh "不过，很高兴有朋友们为我打气。当然了。"
            show red huh -sigh
            quil mock -shock "啊，对不起。这有点让人震惊。"
            fia sad apa "...[povname]，你生气了吗？"
            show side_p f at pic
            mc "嗯？"
            hide side_p
            fia gross both -apa "如果我约会...好吧，在这种情况下是嫁给你的朋友？"
            show pboy at horzappear
            menu:
                "如果你确定的话。":
                    hide pboy
                    show croissant frown -both shock
                    show side_p f at pic
                    mc "你已经够大了，可以做出自己的选择。"
                    show side_p c
                    mc "况且，塞恩不是个坏选择。不过如果你选择奎尔的话——"
                    hide side_p
                    fia flinch jijik sweat frusta "呃。我是有标准的。"
                    quil sly -sweat cling "我也是。"
                    show croissant def wry sigh
                    show quil -cling
                "塞恩？":
                    hide pboy
                    red wry sigh "我是说。我会永远感激的。"
                    red sayang -sigh "我会尽我所能给她最好的生活。"
                    show side_p f at pic
                    mc "...那这就是我所能要求的全部了。"
                    show side_p s
                    mc "虽然妈妈可能会有不同看法。"
                    hide side_p
                    fia pain -both apa "那谁去告诉她，你吗？"
                    show side_p c at pic
                    mc "不。"
                    hide side_p
                    fia wry sigh "所以我们没问题。等到必须面对妈妈的时候再说。"
                "仔细想想...":
                    hide pboy
                    show croissant frown sweat shock
                    show side_p s at pic
                    mc "不。对不起，我...我想我不能让你这么做，菲亚。"
                    mc "不能这样。"
                    show croissant sad -shock
                    show side_p f
                    mc "我会是那个与塞恩建立联系的人。"
                    show side_p he
                    show croissant frown
                    show side_p c at pic
                    mc "而且，为什么我感觉你更像是把他当朋友而不是男朋友？"
                    hide side_p
                    fia flinch gross sigh "嗯...因为确实如此。"
                    fia mmh frusta "我本希望你看不透我，但你太了解我了。"
                    fia def wry -sweat sigh "对不起，塞恩。你是个不错的人，但你不是我喜欢的类型。"
                    red sayang sigh "没关系，我很感谢你试图帮忙。"
                    show red frown -sigh
            
            tom capek blow "等等，也许我们操之过急了。"
            tom frown -blow "我们还有时间。最好不要着急。"
        "让我们先找找其他办法。":
            hide pboy
            $ mrh.points += 5
            tom ha blow "我同意。我们还有些时间。最好不要着急。"
    show quil frown -sweat
    show red frown -sweat
    fia mmh sweat shock "但是截止日期——！"
    tom ha blow "还有大约一周的时间。这些事不应该草率决定。"
    show croissant sad sigh
    tom frown -blow "这样吧，如果到6月5日我们还没找到其他办法，那我们就执行结合计划。"
    tom kzl cling "但在那之前，塞恩，你要克制自己。必要的话就把自己绑在床上。"
    quil smile cling "你可以借用我的手铐。"
    red amused sweat sigh "谢谢，不过我没事。不过我可能会在你房间里睡，阿什姆，这样你可以盯着我。"
    tom hip ha sweat frusta "什么，我是你妈吗？"
    show tom capek -sweat
    show quil malu bunga
    show red hister -sweat bunga
    show croissant -sweat hmph -sigh
    "没人说什么。从眼角余光中，你看到奎尔和塞恩都在笑，好像他们想说\"是的\"。"
    show pboy at horzappear
    menu:
        "需要帮忙吗，妈妈？":
            hide pboy
            $ ibu.points += 5
            show side_p w at pic
            mc "我是说，我可以和你一起守夜。"
            hide side_p
            show tom wry shock
            show red amused sigh
            quil tantrum blush frusta"哦，现在我也想去了。我不想被排除在外！"
        "或者我可以和你一起睡。":
            hide pboy
            show side_p w at pic
            mc "我是说如果你愿意的话，我可以在你房间里和你一起睡。"
            hide side_p
            show quil frown -bunga
            show tom kzl -frusta
            red hister both -bunga "啊哈。不，不是你，[povname]。"
            red wry sigh "如果你和我过夜的话，我可能……可能会做的不仅仅是吸你的血。"
    show tom ha blow
    show quil frown shock
    show red frown sweat shock
    fia gross sigh "老实说，你们都应该睡在同一个房间里。阿什姆或塞恩的房间，因为你们俩现在都没有室友。"
    show red -sweat -shock
    show quil -shock
    fia frown -sigh "你们可以轮流确保塞恩不会梦游，或者说咬人游，随你们怎么称呼。"
    if girl2:
        fia annoyed cling "只是别碰我的[kk]！"
        show croissant hmph -cling
        quil flashy wink cling "当然。我们绝不会不尊重一位女士，菲亚。你把我们当成什么人了？"
        show quil skul smile -cling
    show side_p f at pic
    mc "实际上，这是个好主意。"
    hide side_p
    fia kerja bunga "当然是好主意。我的主意都很好。"
    tom scold amused cling "那就这么定了。今晚我们在我房间集合。自带枕头和毯子。"
    $ red_events.append("sleepover")
    stop music
    scene bg_black with w20
    "你决定回自己房间准备今晚的睡衣派对。"
    jump sleepover

label sleepover:
    $ morning = False
    $ afternoon = False
    $ night = True
    scene kmr_malam with w20
    play music "MUSIC/MusMus-BGM-062.mp3"
    show quil flashy wink cling at center with dissolve:
        yoffset 200
    quil "那么你们男孩中谁有幸和我分享床铺呢？"
    show quil laugh bunga
    show tom chill ha at right with moveinright:
        yoffset 190 
    show red chin ew sweat frusta at left behind quil with moveinleft:
        yoffset 330
    "奎尔说着，摸了摸阿什姆空着的床位。阿什姆和塞恩都挑眉看着他。"
    show quil skul bingung -bunga
    red point huh -sweat sigh "不是我。"
    tom kzl blow "我的房间，我自己的床。"
    show pboy at horzappear
    menu:
        "不是我。":
            hide pboy
            $ mrh.points += 5
            play sound "sound/effects/pillow.mp3"
            "奎尔朝你扔了个枕头。"
            show side_p m at pic
            mc "哎哟！"
            hide side_p
            quil rajuk sigh "好吧。随你们便，爱睡地板就睡地板。"
            show quil bingung -sigh
            show tom pfft -sigh
            red calm cling "或者我们可以让你睡地板。"
            
        "石头剪刀布？":
            hide pboy
            $ ibu.points += 5
            quil hister blush "既然你们都想分享我？"
            quil wink "每个人都有份。"
            show red amused -sigh
            tom scold ejek cling "输的人和奎尔分享床铺？"
            show side_p f at pic
            mc "为什么不让输的人睡地板呢？"
            hide side_p
            red calm cling "或者直接让奎尔睡地板。"
            quil err frusta "哦，哈哈！"
            show quil rajuk sigh
        "我是牺牲品。":
            hide pboy
            $ bff.points += 5
            show side_p w at pic
            mc "看来我是牺牲品了。"
            hide side_p
            show quil flashy laugh blush bloom
            play sound "sound/effects/cloth.mp3"
            "奎尔伸开双臂，欢迎你进入他的怀抱。"
            quil ejek -blush cling "来吧，我的小羊羔，来我怀里迎接你的命运。"
            play sound "sound/effects/pillow.mp3"
            show quil skul hister shock
            "你用枕头拍了他一下，只因为这一切太荒谬了。"
    show side_p c at pic
    mc "嗯。你知道，我们其实可以为此打一架。"
    show red datar shock
    show tom hip smile shock
    show quil frown shock
    show side_p c at pic
    mc "我是说为了谁睡地板。"
    show side_p w
    mc "你们有扑克牌吗？"
    hide side_p
    show quil -shock
    show red -shock
    tom talk amused cling "事实上是两副。"
    show side_p se at pic
    mc "太好了。"
    hide side_p
    "你收集了这些纸牌，很高兴看到它们就像你世界里的普通扑克牌一样。"
    "你可以用这个。"
    red cowo blush bunga "哦，玩游戏吗？我加入！"
    tom calm -cling "有意思。"
    tom ejek cling "输家睡地板？"
    quil err sweat frusta "我一定要玩吗？我不能当奖品吗？"
    show quil sulk sigh
    show side_p m at pic
    mc "不行！"
    show quil frown -sweat -sigh
    show tom calm -cling
    show side_p he 
    mc "现在玩什么呢..."
    $ my_events.append("nginap")
    hide side_p
    show pboy at horzappear
    menu:
        "脱衣扑克":
            hide pboy
            "想要为你所遭受的一切苦难讨回一点小小的报复，你决定稍微戏弄一下这些男孩。"
            "从来没有人在扑克牌上赢过你。"
            show side_p c at pic
            mc "你们有人玩过脱衣扑克吗？"
            hide side_p
            show tom ejek cling
            show red mock -blush cling
            quil sly cling "哦，你打赌我们玩过。"
            "不知为何，这似乎点燃了奎尔内心的某些东西。他眼中闪烁着恶作剧的光芒。比平常更甚。"
            "所有的男孩现在都围坐在桌旁，收集和洗牌。"
            tom pfft apa "你确定要这么做吗，[povname]？"
            show tom ejek cling
            "阿什姆掰了掰指关节，现在露出了他标志性的得意笑容。"
            red hister -cling "我是说，如果你们都愿意的话，我没问题。"
            if girl or girl2:
                red chin sad sweat "但是..."
                show side_p c at pic
                mc "但是什么？害怕了？"
                hide side_p
                red wry -sweat sigh "不是那样。你真的没问题在三个奇怪的男人面前裸体吗？"
                red point sayang -sigh "我是说，我知道[povname]会的，但是..."
                show side_p c at pic
                mc "哦，塞恩，你真贴心，但是什么让你如此确定我需要脱衣服呢？"
                hide side_p
                red grin bloom "哦，你要输定了！"
            else:
                red grin bunga "准备好被打得落花流水吧！"
            scene bg_black with circleirisin
            scene kmr_malam with circleirisout
            show quil nude kzl sweat frusta at center with dissolve:
                yoffset 200
    
            show tom nude sad sweat frusta at right with moveinright:
                yoffset 190 
            show red nude ew sweat frusta at left with moveinleft:
                yoffset 330
            show side_p c at pic
            mc "有问题吗，阿什姆？"
            hide side_p
            tom "……不。"
            "几个小时过去了。奎尔、塞恩和阿什姆现在只剩下内裤了，而你仍然衣着完整。"
            "他们三个看起来有些沮丧和尴尬，因为你一件衣服都没有输掉。"
            quil groan "[povname]从来没有这么厉害过！"
            if kln:
                tom sigh blow "不，[kamu]没有。"
            else:
                tom sigh blow "不，[kamu]不是。"
            red ngeles sigh "...我能不能请求保留我的尊严，继续穿着裤子，拜托了？"
            show side_p se at pic
            mc "好吧。我想我已经欺负你们三个够久了。"
            hide side_p
            red hister blush -sigh "感谢科尔！"
            play sound "sound/effects/cloth.mp3"
            scene kmr_malam with dissolve
            "男孩们开始收拾衣服，羞愧地重新穿上。"
            show quil tantrum sweat frusta at center with dissolve:
                yoffset 200
    
            show tom hip capek sweat blow at right with moveinright:
                yoffset 190 
            show red chin ew sweat frusta at left with moveinleft:
                yoffset 330
            quil "哼。我本可以赢的！再来一局！"
            show quil kzl -sweat -frusta
            show red point wry -sweat sigh
            tom sigh both frusta "不。我不会再做那样的事了，太丢脸了。"
            show tom ha -both -frusta
            show side_p m at pic
            mc "等等，那是不是意味着我可以决定谁睡地板？"
            hide side_p
            tom talk amused "这个荣誉是你的。你可以独占整张床。"
            quil smile "除非你想改变一下，和别人分享你的床。"
            show side_p f at pic
            mc "嗯。"
            hide side_p
            show pboy at horzappear
            menu:
                "和...分享我的床":
                    hide pboy
                    show pboy at horzappear
                    menu:
                        "塞恩。":
                            hide pboy
                            red kaget both shock"嗯？"
                            show red frown -shock
                            show side_p w at pic
                            mc "我是说，我们在监视你。如果你和某人分享床会更容易。"
                            hide side_p
                            quil flashy wink cling "那我猜我们要分享了，阿什小宝贝。已经多久了？"
                            tom capek both frusta "还不够久，把你的手拿开，奎尔！"
                            quil laugh blush bloom "啊哈哈！"
                            stop music
                            play sound "sound/effects/cloth.mp3"
                            scene bed_alter with fade
                            "当塞恩加入你的床时，你可以看到阿什姆和奎尔背对背躺着。"
                            "显然对这种安排感到不舒服。"
                            "虽然他们不是唯一感到不舒服的人。显然塞恩正睡在地板上，避开你。"
                            show side_p s at pic
                            mc "塞恩？"
                            play music "MUSIC/MusMus-BGM-077.mp3"
                            hide side_p
                            show red chin sayang both at center with dissolve:
                                yoffset 330
                            red "嗯。别担心，我在这里很好，[povname]。"
                            show side_p s at pic
                            mc "但是..."
                            hide side_p
                            red mls sigh "听着，我知道你是好意，但我现在正咬着嘴唇，就是为了不被诱惑去咬你，所以拜托..."
                            red ew frusta "别诱惑我，[povname]。我可没有那么坚强。"
                            show side_p s at pic
                            mc "...我不会的。"
                            hide side_p
                            show red kaget shock
                            "尽管如此，你还是为塞恩的困境感到难过，于是把你的毯子盖在了他身上。希望这至少能让他保暖。"
                            red wry sigh "...谢谢。"
                            show side_p se at pic
                            mc "晚安，塞恩。"
                            hide side_p
                            red sayang blush -sigh "晚安。"
                        "奎尔。":
                            hide pboy
                            show tom sad shock
                            show red amused sigh
                            quil sly shock "看到了吗？？？"
                            quil flashy laugh blush bloom "我才是奖品！"
                            tom talk calm blow "这就是为什么奎尔有那么大的自我，[povname]。我们把他宠坏了。"
                            show red hister -sigh
                            "尽管阿什姆深深地叹了口气，但他似乎对这种安排很满意。"
                            play sound "sound/effects/cloth.mp3"
                            stop music
                            scene bed_alter with fade
                            "当塞恩加入他的床时，你可以看到阿什姆像抱着长枕一样，用四肢锁住了他。"
                            show tom chill frown at right with dissolve:
                                yoffset 190
                            show red point sad both at left with dissolve:
                                yoffset 330
                            play music "MUSIC/MusMus-BGM-077.mp3" fadein 1.0
                            red bingung apa "呃，阿什姆？"
                            show red huh -apa
                            tom ha "不然我怎么确保你不会梦游呢？"
                            red sayang "我是说，你可能会听到的。不过没关系，我不介意依偎在一起。"
                            red awkward "这绝对不是同性恋。"
                            red sayang "只是两个兄弟在温暖的床上依偎在一起，零距离接触因为他们不是同性恋！"
                            "塞恩唱着歌，这曲调让你想起了一个古老的网络梗。"
                            tom capek frusta "睡觉吧，塞恩。"
                            red wry sigh "啊，是的，抱歉兄弟。晚安，奎尔，[povname]！"
                            show side_p se at pic
                            mc "晚安。"
                            hide side_p
                            scene bed_alter with dissolve
                            
                            show quil skul frown at center with dissolve:
                                yoffset 200
                            quil apa "嘿。你醒着吗，[povname]？"
                            show side_p c at pic
                            mc "不，因为人们睡觉的时候都会耳语。"
                            hide side_p
                            quil err frusta "哈哈。"
                            quil rajuk blush sigh "...顺便说一句，谢谢。"
                            show side_p f at pic
                            mc "嗯？"
                            hide side_p
                            quil malu -sigh "除了小时候和[povname]还有菲亚，我从来没有和别人一起睡过。"
                            quil sulk frusta "我担心自己会太紧张，影响我的美容觉。"
                            quil flashy hister bloom "所以，谢谢你。你真是体贴。"
                            show side_p f at pic 
                            mc "（哦，我没想到这一点。）"
                            show side_p w 
                            mc "（猜想对他这样的人来说确实会很尴尬。）"
                            show side_p se
                            mc "嗯。别客气。晚安，奎尔。"
                            hide side_p
                            quil smile sigh "晚安。"
                        "阿什姆。":
                            hide pboy
                            tom hip frown both shock "哦？你确定吗？"
                            show side_p f at pic
                            mc "你不想吗？"
                            hide side_p
                            tom talk ha -shock "恰恰相反，但你是客人。为了你的舒适，我不介意睡在地板上。"
                            show side_p se at pic
                            mc "阿什姆，没关系的。现在穿好衣服上床睡觉吧。"
                            hide side_p
                            tom hip calm blush bloom "...好吧。"
                            stop music
                            play sound "sound/effects/cloth.mp3"
                            scene bed_alter with dissolve
                            play music "MUSIC/MusMus-BGM-077.mp3" fadein 2.0
                            "睡了几个小时后，你感觉到有什么沉重的东西搭在你的腹部。"
                            show tom chill calm blush bloom at center with dissolve:
                                yoffset 190
                            show side_p w at pic
                            mc "阿什姆。"
                            hide side_p
                            tom whine both shock "哦，抱歉。我睡觉时喜欢依偎。我不是故意——"
                            show pboy at horzappear
                            menu:
                                "搂住他":
                                    hide pboy
                                    $ kindness += 5
                                    $ honesty -= 5
                                    show side_p w at pic
                                    show tom frown shock
                                    mc "想换个角色当大勺子吗？"
                                    hide side_p
                                    tom ha -shock "什么？我...那太好了。"
                                    show side_p se at pic
                                    mc "嘿嘿，过来。"
                                    hide side_p
                                    play sound "sound/effects/cloth.mp3"
                                    "你用双臂环抱住阿什姆，感受到他沉浸在你的怀抱中。"
                                    tom talk giggle blush bunga "哦。这感觉真好。比我想象的还要好。"
                                    

                                "被搂住":
                                    hide pboy
                                    $ honesty += 5
                                    show side_p w at pic
                                    mc "我不介意。我喜欢当小勺子。"
                                    hide side_p
                                    play sound "sound/effects/cloth.mp3"
                                    tom chill wry blush blow "真的吗？我，呃...谢谢你。"
                                    "阿什姆收紧了环抱着你的手臂，像温暖的毯子一样覆盖在你身上。"

                                    
                                "把他推开":
                                    hide pboy
                                    $ ibu.points -= 15
                                    if ibu.points <0:
                                        $ ibu.points = 0
                                    $ kindness -= 15
                                    show side_p f at pic
                                    mc "抱歉，你能往后挪一点吗？"
                                    hide side_p
                                    tom hip sigh blow "好的，我很抱歉。"
                            show side_p se at pic
                            mc "嗯。晚安，阿什姆。"
                            hide side_p
                            tom wry blush blow "晚安，[povname]。"
                "睡在地板上是...":
                    menu:
                        "塞恩。":
                            hide pboy
                            red sayang sigh "有道理。毕竟我才是需要被看管的人。"
                            red cowo bunga "好了，大家晚安！"
                            tom talk pfft blow "先穿上厚一点的衣服，你会需要的。"
                        "奎尔。":
                            hide pboy
                            show red wry
                            show tom wry
                            quil fluster sweat shock "我？！为什么是我？！你伤害了我，[povname]！"
                            show quil sulk -shock
                            show side_p se at pic
                            mc "奎尔，拿些枕头就睡吧。"
                            mc "不用这么戏精。"
                            hide side_p
                            quil kzl frusta "哼！"
                        "阿什姆。":
                            hide pboy
                            tom talk whine sweat frusta "...但这是我的房间。"
                            show side_p c at pic
                            mc "而这是我的胜利。"
                            hide side_p
                            tom sigh blow "哈啊...好吧，遵命，我的主人。"
        "钓鱼游戏":
            hide pboy
            scene kmr_malam with dissolve
            "尽管不是你的强项，你还是决定玩一局钓鱼游戏。"
            "可惜，你输了，不得不在地板上睡了一晚。"
    stop music
    scene bg_black with eye_shut
    if "io0" in my_events and "io4" not in my_events:
        jump io_dream_check
    else:
        jump jaga_jaga
            
label fia_bond:
    play sound "sound/effects/knock.mp3"
    scene kmr_pagi with vpunch
    show croissant flinch mmh sweat at center with dissolve:
        yoffset 500
    "你听到门外传来一阵响亮的敲门声。当你打开门时，看到菲亚低着头，紧紧抓着她的裙子。"
    if girl:
        show palmierproxy chill confused at left with moveinleft:
            yoffset 40
    else:
        show palmierproxy chill confused at left with moveinleft:
            yoffset 100
    show croissant at right with move
    mc sweat tanya "菲亚？"
    fia cringe frusta "...拜托。请不要生气。"
    mc scratch sad -tanya "什么？我为什么要生气？"
    fia sad sigh "塞恩和我...我们灵魂绑定了。"
    mc ow shock "什么？！"
    play sound "sound/effects/tile.mp3"
    scene teras_siang with w33
    play music "MUSIC/MusMus-BGM-077.mp3"
    stop sound
    "你跟随菲亚来到露台外。显然她已经把你们四人组的所有人都召集在了那里。"
    show tom hip kzl sweat at center with dissolve:
        xalign 0.55
        yoffset 190
    show quil skul kzl at right with dissolve:
        xzoom -1.0
        yoffset 200
    show red chin sad sweat at left with dissolve:
        yoffset 330
    show croissant def sad at center with dissolve:
        yoffset 500
        xzoom -1.0
        xalign 0.45
    quil groan sweat frusta "你们两个绑定了？！"
    show quil kzl
    fia cringe sigh "这是最好的选择！"
    show side_p m at pic
    mc "解释一下！"
    hide side_p
    red ngeles sigh "塔图姆在医院醒来了。医生向沃特克的大祭司报告了我的行为。"
    red sad -sigh "当我去见维尔科娃女士时，沃特克议会已经给她发了一封信。"
    red "说我可以选择要么与某人灵魂绑定，这样我就只能吸他们的血，要么被转化为邪血者。"
    red bingung "我选择了绑定，而菲亚..."
    show red sad 
    fia gross -sigh "我当时在维尔科娃女士附近，正在服禁闭。我无意中听到了，就决定采取行动。"
    show croissant sad
    show side_p m at pic
    mc "所以等等，你们两个是..."
    hide side_p
    fia mmh "灵魂绑定，结婚了。随你怎么说吧。"
    "菲亚深吸一口气，闭上眼睛，双臂像十字架上的耶稣一样伸向两侧。"
    fia flinch gross frusta "我现在准备好接受惩罚了。尽管惩罚我吧，[kk]！"
    show pboy at horzappear
    menu:
        "立刻解除这个绑定！":
            hide pboy
            red ew chin sigh "没那么容易，[povname]。"
            fia def err sigh "你知道灵魂绑定是永久的。"
            show side_p s at pic
            mc "但是..."
            hide side_p
            show pboy at horzappear
            menu:
                "我以为你喜欢我，塞恩！":
                    hide pboy
                    red kaget shock "呃？"
                    show red sad -shock
                    fia mmh frusta "等等，你们两个是一对吗？你从没说过。"
                    show side_p s at pic
                    mc "嗯，我们还不是，但是..."
                    hide side_p
                    fia sad sigh "我很抱歉。如果这有什么意义的话，这只是为了让塞恩不会吸其他人的血。"
                    fia flinch jijik -sigh "我们没有上床或其他什么。那太恶心了。"
                    fia gross sigh "不是冒犯你的意思，塞恩。"
                    red sayang "没关系，我知道你是无性恋和无浪漫恋。"
                    fia def sad -sigh "你仍然可以和他保持关系，只是不要建立灵魂绑定。"


                "你才19岁！":
                    hide pboy
                    fia mmh sigh "我知道。但我发誓这纯粹是柏拉图式的。"
                    fia sad -sigh "这只是为了让塞恩不会从其他人那里吸血。"
                    fia "你知道我是无性恋和无浪漫感情的人。这种联结对我们来说很合适。"
                    fia hister "我不需要订婚，塞恩也不会杀人，所以..."
        "这是什么意思？":
            hide pboy
            red sad sigh "这意味着我只能从菲亚那里吸血。"
            fia def mmh frusta "我们算是结婚了，嗯，某种程度上。我们对彼此并没有任何感觉。"
            fia flinch jijik "这纯粹是柏拉图式的。你知道被追求或发生性行为的想法让我感到厌恶。"
            fia def sad sigh "如果塞恩喜欢上谁，他可以和那个人过自己的生活，只要他每周来我这里吸血就行。"
            tom hip ha apa "菲亚，你真的没问题吗？"
            show tom -apa
            fia frown -sigh "我没有打算嫁给任何人。除非我有发言权。"
            fia wry "如果妈妈问起，嗯...我相信[povname]会支持我的。"
            fia hister "我是成年人了，这是我自己的决定。"
            show croissant wry 
            show side_p m at pic
            mc "你才19岁。年龄增长并不意味着你已经成熟了！"
            hide side_p


        "我为你感到高兴！":
            hide pboy
            show red kaget shock
            show red frown -shock
            fia cringe shock "等等，你不生气吗？"
            show side_p se at pic
            mc "我为什么要高兴？"
            hide side_p
            fia sad frusta "真的吗？我以为你可能会那样喜欢他。"
            show side_p w at pic
            mc "不，我心里有别人。"
            hide side_p
            fia hister both bunga "哦。那...那就好。"
            show croissant jijik sweat shock
            quil flashy groan frusta "才怪！"
    quil kzl sigh "这太荒唐了。你本可以先跟我们商量的！"
    fia jijik frusta "不，我只欠我[kk]一个解释。其他人都滚蛋吧。"
    quil sulk frusta "我不是在说你，菲亚。我是在说红，还有他决定与\'我们的\'[povname]的妹妹建立联结。"
    red sad sigh "..."
    show side_p s at pic
    mc "（他指的是真正的[povname]，不是我。）"
    hide side_p
    fia gross apa "而我在这里请求我[kk]的祝福。你想要什么？"
    tom scold sigh sweat blow "这很复杂，菲亚。你能...你能给我们一点时间吗，拜托？"
    tom ha -blow "单独谈谈。"
    fia flinch jijik shock "什么？认真的吗？！拜托，别这样，唠叨鬼！"
    show side_p s at pic
    mc "就一会儿，菲亚，拜托了。"
    hide side_p
    fia mmh sigh "哈啊...好吧。"
    hide croissant with dissolve 
    stop music
    play sound "sound/effects/doorslam.mp3"
    show tom at center with move:
        yoffset 190
    "菲亚一离开房间，奎尔就锁上了门，在门上画了一个符文。"
    quil tantrum -sweat sigh "隐私符文，以防万一。"
    tom kzl -sweat cling "嗯。那么现在。"
    show red point ew both shock with vpunch
    play sound "sound/effects/slap.mp3"
    show quil bingung shock
    "阿什姆狠狠地拍了一下塞恩的屁股，发出响亮的声音。"
    tom scold ew frusta "你他妈在想什么？！"
    play music "MUSIC/MusMus-BGM-089.mp3"
    show tom kzl 
    red perih frusta "噢！你刚才打我屁股了？！"
    if kln:
        quil grit frusta "这比[povname]醒来后会对你做的事好多了。"
    else:
        quil grit frusta "这比[povname]醒来后会对你做的事好多了。"
    quil tantrum sigh "你他妈到底怎么回事？！"
    red ngeles frusta "我当时慌了，好吗？而菲亚刚好在那里！"
    red ew "你没看信吗，他们想用我自己的母亲把我变成一个邪血者！"
    show quil sweat sad shock
    show tom kzl sweat shock
    red ngeles "我现在已经失去理智、变成怪物的母亲！你觉得我该受这种罪吗？！"
    tom ha blow "哈啊...当然不该。但如果你先跟我们商量，我们本可以找到更好的办法。"
    red sad sigh "菲亚很坚持，而且她说得对。这对我们来说很合适。"
    red -sigh "我又没有恋人什么的，而且你知道菲亚不想嫁给什么无聊的贵族。"
    quil flashy groan frusta "是啊，但她才19岁！19岁不该做这种人生选择！"
    quil grit sigh "你为什么不更生气？！"
    show side_p s at pic
    mc "我想...因为我是个局外人？"
    show side_p he 
    mc "我的意思是，我生气塞恩把菲亚置于那种境地吗？是的。但这是他们的选择。"
    show side_p m
    mc "他们是成年人，勉强算是，但仍然是成年人。"
    hide side_p
    quil sulk -sweat sigh "哈。"
    tom chill whine frusta "[povname]说得对。我们没有权利生气。"
    tom sigh blow "我们的[povname]可能会杀了他，但我们得稍后再处理这个问题。"
    tom ha apa "现在，还有更重要的事情。塞恩，你在这个[povname]身边感觉如何？"
    tom kzl -apa "有什么渴望吗？"
    red wry sigh "没有。一点也没有。以前，每当我看到[povname]，我就想直接咬下去，尽情饮血，但现在..."
    red hister -sigh "...什么感觉都没有。我感觉又能控制自己了。恢复理智了。"
    tom hip calm -sweat blow "很好。"
    quil bingung apa "那菲亚呢，你对她有什么...冲动吗？"
    red chin ew both frusta "我不想上她。再说，我觉得她和这个[povname]如果我那样做的话会杀了我。"
    show red sad sweat shock
    show tom ha shock
    show quil frown shock
    play sound "sound/effects/crumple.mp3"
    "你不自觉地开始掰手指关节。你真的不想让他上你妹妹。"
    red sayang apa "看到了吗？"
    show quil kzl -shock
    show tom calm -shock
    red point awkward blush -apa "啊，不过我确实对她有种占有欲或保护欲。"
    red "这很好，如果塔图姆康复后再欺负她，我会把她打得满地找牙。"
    red sayang -blush sigh "问题解决了。现在我们可以专注于湖底的巫师了。"
    quil tantrum sigh "嗯。这倒是一种看法。"
    tom talk ha apa "说到这个，我们真的应该亲自去见见这个巫师。"
    tom hip capek frusta "你和这里的[povname]并不是最好的品格判断者。"
    red hister -sigh "我是说，我没问题。只要你们不介意可能会溺水的风险。"
    red amused apa "你来吗[povname]，还是我应该自己带他们去？"
    show red -apa
    show side_p f at pic
    mc "不。你们先去吧。"
    mc "我需要去看看菲亚。"
    hide side_p
    tom chill ha blow "你应该去。我觉得她不太喜欢被赶出房间。"
    tom sad -blow "她在这一切中表现出的平静有点反常。"
    quil sulk sweat sigh "我也这么认为。"
    show side_p f at pic
    mc "我知道。我去问问她对这件事的真实感受。你们先去吧。"
    hide side_p
    stop music
    scene bg_black with w20
    "你们四个分道扬镳，你出去寻找菲亚。"
    jump fia_cur2
label fia_cur2:
    play sound "sound/effects/walk.mp3"
    scene atas_pagi with w20
    show croissant def sad at right with dissolve:
        yoffset 500
    if girl:
        show palmierproxy chill sad at left with dissolve:
            yoffset 40
    else:
        show palmierproxy chill sad at left with dissolve:
            yoffset 100
    fia flinch err apa "那么..."
    stop sound
    show croissant sad sigh
    play music "MUSIC/MusMus-BGM-092.mp3"
    "菲亚和你用忧郁的目光相互对视，仿佛在猜测谁该先开口。"
    show pboy at horzappear
    menu:
        "所以你结婚了。":
            hide pboy
            fia def pity "呵。只是灵魂上的结合。等等，不对。我想现在我说出来，这听起来确实挺沉重的，是吧？"
            mc scratch side sigh "菲亚，你真的能接受这个吗？"
            if "soulmates" in topics:
                mc sad -sigh "我是说，我读过关于灵魂伴侣的资料。吸血鬼和人类往往比与精灵更般配，但是..."
                fia mmh sweat frusta "是啊。但你从没想过我会有灵魂伴侣，对吧？"
                fia sad sigh "对不起。我知道我们曾经约定过。"
                    
            else:
                fia sad sigh "我是说，不完全是。我有一部分希望你能直接重写我的记忆，帮我平静下来。"
                if "rewrite" not in topics:
                    mc chill sad tanya "重写你的记忆？"
                    fia sad sigh -sweat "你知道的，就是你制作的那个记忆重写符文？"
                    fia err frusta "我知道你用它在亨利的女朋友死后帮他重写记忆，防止他自杀。"
                    fia wry sigh "也许你可以用它来重写我的遗憾，让我认为这一切都是明智的决定？"
                else:
                    fia sad sigh "另外，如果你要重写我的记忆，你应该现在就做。"    
                    mc side sigh "啊，不。我不会那么做的。"
                        
                fia cringe frusta "不过，我很抱歉打破了我们的约定。"
        "你幸福吗？":
            hide pboy
            fia hmph sigh "我是说。我不后悔。我喜欢塞恩。我希望他活下去。"
            fia sad apa "但你还好吗？"
            fia cringe frusta "我打破了我们的约定。"     
    mc chill apa tanya "约定？"
    show palmierproxy sad -tanya
    fia flinch jijik frusta "等等，别告诉我你忘了。我当时可是吓坏了！"
    fia gross "你以为我为什么在生闷气？"
    mc ow shock "嗯？你为什么生气？"
    fia def mmh sigh "我们约定要形成灵魂羁绊的！"
    show pboy at horzappear
    menu:
        "我喜欢乱伦？！":
            hide pboy
            fia jijik sweat shock "什么？！不是！"
        "你需要接受心理治疗！":
            hide pboy
            mc side sigh "菲亚，我知道除了普莉姆和我之外你没有其他朋友，但是乱伦关系是..."
            mc ow sweat frusta "天啊，这个世界有菲尔博士吗？你需要接受心理治疗。去牧场找找自我吧。"
            fia jijik sweat shock "不是那种灵魂羁绊！"
             
    fia flinch gross frusta "天啊。我又不是杰瑞表哥。"
    fia sad -sweat sigh "我指的是兄妹之间的灵魂羁绊！"
    fia def frown "你说你想尝试建立一个，因为当妈妈开始安排我的婚事时你很沮丧。"
    fia ejek cling"你想要我们建立一种柏拉图式的灵魂羁绊。这样，即使我和配偶建立了灵魂羁绊，你仍然是我的第一位。"
    show croissant kerja -cling
    mc panik sweat "（嗯，这听起来一点也不病态和令人毛骨悚然！）"
    mc ow frusta "你对此没意见吗？"
    fia pain sigh "我是说，我觉得你只是不想被排除在外。"
    fia "你知道我是无浪漫无性恋，所以我猜你只是担心我做一些我不想做的事。"
    fia flinch gross sweat frusta "爱情...真恶心。"
    mc grit "你几岁啊，9岁吗？"
    mc side sigh "（我真不懂这对兄妹。我和他们相处得越久，就越发现我根本不是[povname]！）"
    mc sad -sigh"（但是...）"
    mc frown -sweat "好吧，如果你担心的是这个，我并不生气。我觉得这样更好。"
    mc scratch malu both "如果我们建立那种灵魂羁绊，我们会变得过于相互依赖。"
    show palmierproxy chill wry -both
    fia def pity -sweat sigh "我想是吧。如果这能让你感到安慰的话，我一点也不享受和塞恩的灵魂羁绊！"
    mc confused tanya "哦？感觉如何？"
    show palmierproxy frown -tanya
    fia gross frusta "我们交换了血液。现在我们建立了羁绊，我能感受到他的情绪了。其实也没什么特别的。"
    fia hmph sigh "他要么开心要么饿。他是狗吗？"
    mc happy -sigh "他确实有点像小狗的性格，不是吗？"
    fia hister -sigh "是啊？我无法想象妈妈会说什么。"
    fia wry sigh "幸运的是，我们还有6个月的时间才需要回家。也许到时候我能把他打磨成一个绅士。"
    mc huh frusta "我表示怀疑。"
    fia annoyed cling "哦，得了吧，他也没那么没希望。我可能会遇到更糟的，比如奎尔。"
    if "tunangan" in quil_events:
        fia gross sweat frusta "哦对了，你知道吗？有传言说你和奎尔订婚了？"
        mc scratch malu both shock "呃..."
        fia annoyed cling "你们没有，对吧？"
        mc eiden frusta "嗯..."
        fia flinch kzl ang "等等，你为什么犹豫？！回答我！"
        stop music
        scene bg_black with w20
        "你们接下来的时间都在讨论奎尔和你们的假订婚。"
        "幸运的是，菲亚认为你们两个扯平了，因为她在没有征求你意见的情况下就建立了羁绊。"
    else:
        show palmierproxy chill frown sweat shock
        fia sad apa "说到奎尔，他最近对收集符文墨水似乎很着迷。你注意到现在出现短缺了吗？"
        stop music
        scene bg_black with w20
        "你和菲亚接下来的时间都在讨论墨水短缺的问题，以及如何应对你们的母亲。"
        "希望到那时你能回到自己的世界。"
    "你和菲亚度过了剩下的时间，然后回到了自己的房间。"
    scene lor_mlm with w20
    play music "MUSIC/MusMus-BGM-082.mp3"
    jump ur_room