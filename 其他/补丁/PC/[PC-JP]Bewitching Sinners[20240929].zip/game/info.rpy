init:
    $ a = Character(None, color = "#f5cd28", ctc="my_ctc",ctc_position="nestled",window_background="text_box_atas", window_top_padding=25, what_xpos= 100, window_left_margin = 0.33, what_ypos=10, window_right_padding = 700, window_yalign = 0.1, who_ypos=5)
    $ b = Character(None, color = "#f5cd28", ctc="my_ctc",ctc_position="nestled",window_background="text_box_bawah", window_top_padding=50, what_xpos= 105, window_left_margin = 0.33, what_ypos=8, window_right_padding = 700, window_yalign = 0.6, who_ypos=160, who_xpos=120)
    $ bka = Character(None, color = "#f5cd28", ctc="my_ctc",ctc_position="nestled",window_background="text_box_bawah_kanan", window_top_padding=60, what_xpos= 100, window_left_margin = 0.33, what_ypos=0, window_right_padding = 700, window_yalign = 0.6, who_ypos=5)
    $ aki = Character(None, color = "#f5cd28", ctc="my_ctc",ctc_position="nestled",window_background="text_box_atas_kiri", window_top_padding=25, what_xpos= 110, window_left_margin = 0.33, what_ypos=10, window_right_padding = 680, window_yalign = 0.1, who_ypos=5)
    $ t = Character(None, color = "#f5cd28", ctc="my_ctc",ctc_position="nestled",window_background="text_box_atas", window_top_padding=20, what_xpos= 90, window_left_margin = 0.05, what_ypos=17, window_right_padding = 1220, window_yalign = 0.2, who_ypos=60)
    $ tt = Character(None, color = "#f5cd28", ctc="my_ctc",ctc_position="nestled",window_background="text_box_bawah", window_top_padding=55, what_xpos= 90, window_left_margin = 0.54, what_ypos=13, window_right_padding = 280, window_yalign = 0.6, who_ypos=60)
    #$ t_ka = Character(None, color = "#f5cd28", window_background="text_box_atas_kiri", window_top_padding=35, what_xpos= 90, window_left_margin = 0.6, what_ypos=13, window_right_padding = 200, window_yalign = 0.1, who_ypos=60)
    $ mc2 = Character("Croissant", color = "#f5cd28",ctc="my_ctc",ctc_position="nestled", window_background="gui/tes2.png", window_top_padding=115, what_xpos= 120, window_left_margin = 453, what_ypos=30,window_right_padding = 690, window_yalign = 0.86, who_ypos=5)

define teach = Character('???', callback=name_callback, cb_name='stag', image='teach')
define stag = Character('凯普勒', callback=name_callback, cb_name='stag', image='teach')
define nun = Character('维尔科娃', callback=name_callback, cb_name='nun', image='nun')
define pr = Character('普鲁什卡', callback=name_callback, cb_name='pr', image='bee')
define quil = Character('奎尔', callback=name_callback, cb_name='quil', image='quil')
define tom = Character('阿什姆', callback=name_callback, cb_name='tom', image='tom')
define red = Character('塞恩', callback=name_callback, cb_name='red', image='red')
define lyal = Character('莱尔', callback=name_callback, cb_name='lyal', image='buff')
define buff = Character('莱尔', callback=name_callback, cb_name='buff', image='buff')
define iv = Character('伊瓦尔', callback=name_callback, cb_name='iv', image='ivar')
define io = Character("伊欧", callback=name_callback, cb_name='io', image='Io')
define mc = Character('[povname]', callback=name_callback, cb_name='mc', image='palmier')
define femc = Character('[povname]', callback=name_callback, cb_name='femc', image='femc')
define fia = Character('菲亚', callback=name_callback, cb_name='fia', image='croissant')
define dog = Character('迪特里希', callback=name_callback, cb_name='dog', image='priest')
define hm = Character('威廉', callback=name_callback, cb_name='hm', image='hm')
define hed = Character('海德温', callback=name_callback, cb_name='hedwin', image='hedwin')
define py = Character('波比', callback=name_callback, cb_name='py', image='poppy')
define caf = Character('梅莉', callback=name_callback, cb_name='caf', image='caf')
define mey = Character('梅扎', callback=name_callback, cb_name='mey', image='mey')
define npw = Character('莱利', callback=name_callback, cb_name='npw', image='waiter')
define pena = Character('佩纳', callback=name_callback, cb_name='pena', image='pena')
define har = Character('欧文', callback=name_callback, cb_name='har', image='har')
define ech = Character('艾希德娜', callback=name_callback, cb_name='ech', image='ech')
define npc = DynamicCharacter("NPC")
define bp = Character("廷塔")
define bp = Character('廷塔', callback=name_callback, cb_name='bpk', image='bpk')
define kor = Character('科尔', callback=name_callback, cb_name='kor', image='kor')
define seth = Character('塞斯', callback=name_callback, cb_name='seth', image='seth')
define mk = Character('[povname]', callback=name_callback, cb_name='mc', image='kid')
#MOUSE
define config.mouse = { }
define config.mouse['default'] = [ ( "images/mouse.png", 0, 0) ]
define config.mouse['search'] = [ ( "images/search.png", 0, 0) ]


image text_box_bawah = "gui/box.png" #653-509
image text_box_tengah = "gui/dialogue2.png" #643_759
image text_box_atas = "gui/dialogue2.png"
image text_box_bawah_kanan:
    im.Flip("gui/box.png", horizontal= True)
image text_box_atas_kiri:
    im.Flip("gui/dialogue2.png", horizontal = True)

image my_ctc:
    "gui/ctc.png"
    alpha 0.5
    easein 0.5 alpha 1.0
    easein 0.5 alpha 0.0
    repeat

init python:
    def eyewarp(x):
        return x**1.33
    import math
    class AnimatedMask(renpy.Displayable):

        def __init__(self, child, mask, maskb, oc, op, moving=True, speed=1.0, frequency=1.0, amount=0.5, **properties):
            super(AnimatedMask, self).__init__(**properties)

            self.child = renpy.displayable(child)
            self.mask = renpy.displayable(mask)
            self.maskb = renpy.displayable(maskb)
            self.oc = oc
            self.op = op
            self.null = None
            self.size = None
            self.moving = moving
            self.speed = speed
            self.amount = amount
            self.frequency = frequency

        def render(self, width, height, st, at):

            cr = renpy.render(self.child, width, height, st, at)
            mr = renpy.render(self.mask, width, height, st, at)
            mb = renpy.Render(width, height)


            if self.moving:
                mb.place(self.mask, ((-st * 50) % (width * 2)) - (width * 2), 0)
                mb.place(self.maskb, -width / 2, 0)
            else:
                mb.place(self.mask, 0, 0)
                mb.place(self.maskb, 0, 0)



            cw, ch = cr.get_size()
            mw, mh = mr.get_size()

            w = min(cw, mw)
            h = min(ch, mh)
            size = (w, h)

            if self.size != size:
                self.null = Null(w, h)

            nr = renpy.render(self.null, width, height, st, at)

            rv = renpy.Render(w, h, opaque=False)

            rv.operation = renpy.display.render.IMAGEDISSOLVE
            rv.operation_alpha = 1.0
            rv.operation_complete = self.oc + math.pow(math.sin(st * self.speed / 8), 64 * self.frequency) * self.amount
            rv.operation_parameter = self.op

            rv.blit(mb, (0, 0), focus=False, main=False)
            rv.blit(nr, (0, 0), focus=False, main=False)
            rv.blit(cr, (0, 0))

            renpy.redraw(self, 0)
            return rv

    def monika_alpha(trans, st, at):
        trans.alpha = math.pow(math.sin(st / 8), 64) * 1.4
        return 0
init:
    $ circleirisout = ImageDissolve("id_circleiris.png", 0.5, 8)
    $ eye_open = ImageDissolve("eye.png", .5, ramplen=128, reverse = False, time_warp =eyewarp)
    $ eye_shut = ImageDissolve("eye.png", .5, ramplen=128, reverse = True, time_warp =eyewarp)
    $ circleirisin = ImageDissolve("id_circleiris.png", 0.5, 8, reverse=True)

    ####CHARACTER SYSTEM

init python:
   # declares a class called 'char'
   default_var = '???'
   class char:
       #--------------------------VV--------if you want to change how much points they start with
       def __init__(self, points=0,placeholder =0,dates=0, acara=0, dislikes = default_var, likes = default_var, age = default_var, desc = default_var,  name=default_var, pic='none',hint=default_var ): #<-- this line sets all the defaults; the only one you'll probably use
           self.points = points
           self.placeholder = placeholder
           self.dates = dates
           self.dislikes = dislikes
           self.likes = likes
           self.desc = desc
           self.age = age
           self.acara = acara
           self.name = name
           self.pic = pic
           self.hint = hint
           #You can add more areas if you want, just put self. and whatever it is you need

       def add_points(self, amount):
           self.points += amount
           if self.points > 100:
               self.points =  100
       def normalizePoints(self):
           if self.points >  100:
               self.points =  100
           if self.points < 0:
               self.points = 0
       def add_placeholder(self, amount):
           self.points += amount
           if self.placeholder > 10:
               self.placeholder = 10
       def normalizePlaceholder(self):
           if self.placeholder > 10:
               self.placeholder = 10
           if self.placeholder < 0:
               self.placeholder = 0


       def add_dates(self, amount):
           self.dates += amount
           if self.dates > 10:
               self.dates = 10
       def normalizeDates(self):
           if self.dates > 10:
               self.dates = 10
           if self.dates < 0:
               self.dates = 0

       def add_acara(self, amount):
           self.acara += amount
           if self.acara > 10:
               self.acara = 10
       def normalizeEvents(self):
           if self.acara > 10:
               self.acara = 10
           if self.acara < 0:
               self.acara = 0
init python:
   def limit_stats():
           try:
            
               if mrh.points < 0: #Red head
                   mrh.points = 0
               elif mrh.points > 100:
                   mrh.points = 100
               if bff.points < 0: # Quill
                   bff.points = 0
               elif bff.points > 100:
                   bff.points = 100
               if ibu.points < 0: #Tom
                   ibu.points = 0
               elif ibu.points > 100:
                   ibu.points = 100
               if putri.points < 0: #Buff
                   putri.points = 0
               elif putri.points > 100:
                   putri.points = 100
               if bocah.points < 0: #horns
                   bocah.points = 0
               elif bocah.points > 100:
                   bocah.points = 100
               if devil.points < 0: #duit
                   devil.points = 0
               elif devil.points > 100:
                   devil.points = 100
               if tinder.points < 0: #vampir
                   tinder.points = 0
               elif tinder.points > 100:
                   tinder.points = 100
               if main.points < 0: #MC
                   main.points = 0
               elif main.points > 100:
                   main.points = 100
               if curiosity <0:
                    curiosity = 0
               elif curiosity >100:
                    curiosity = 100
               if honesty <0:
                    honesty = 0
               elif honesty >100:
                    honesty = 100
               if kindness <0:
                    kindness = 0
               elif kindness >100:
                    kindness = 100 
           except:
               pass

   config.python_callbacks.append(limit_stats)
screen char_popup_main():
    frame xysize 1190, 312:
        xpos 466 ypos 732
        padding (50,50)

        label _("角色详情") style "description_label" yanchor 69
        null height 50
        vbox:
            text "姓名 : 帕尔米耶·贝克" style "smaller_text"
            #text name style 'note_txt'
            #text age style 'note_txt'
            text "好奇 :"+" [curiosity]" +"/100" style "smaller_text"
            bar value curiosity range pointsMax right_bar "gui/bar_empty.png" left_bar "gui/bar_full.png" xmaximum 380
            null height 2
            text "诚实 :"+" [honesty]" +"/100" style "smaller_text"
            bar value honesty range pointsMax right_bar "gui/bar_empty.png" left_bar "gui/bar_full.png"  xmaximum 380
            null height 2
            text "友善 :"+" [kindness]" +"/100" style "smaller_text"
            bar value kindness range pointsMax right_bar "gui/bar_empty.png" left_bar "gui/bar_full.png" xmaximum 380
            null height 2
screen ibu_bar():
    use char_popup()
    bar value ibu.points range pointsMax right_bar "gui/bar_empty-heart.png" left_bar "gui/bar_full-heart.png" xpos 1512 ypos 749 xmaximum 114
screen bff_bar():
    use char_popup()
    bar value bff.points range pointsMax right_bar "gui/bar_empty-heart.png" left_bar "gui/bar_full-heart.png" xpos 1512 ypos 749 xmaximum 114
screen mrh_bar():
    use char_popup()
    bar value mrh.points range pointsMax right_bar "gui/bar_empty-heart.png" left_bar "gui/bar_full-heart.png" xpos 1512 ypos 749 xmaximum 114
screen putri_bar():
    use char_popup()
    bar value putri.points range pointsMax right_bar "gui/bar_empty-heart.png" left_bar "gui/bar_full-heart.png" xpos 1512 ypos 749 xmaximum 114
screen char_popup():
    zorder 100
    for i in allchars:
            $ char = i
            #use navigation
            if viewing == char.name:
                $ name = "姓名： " + char.name
                $ age = "(" + char.age + ")"
                $ likes = "喜欢： " + char.likes
                $ dislikes = "讨厌： " + char.dislikes
                $ desk = char.desc
                $ hint = "提示： " + char.hint
                #$ suka = "Affection Points: " + "[char.points]" +"/100"
    frame xysize 1190, 312:
        xpos 466 ypos 732
        padding (50,50)

        label _("角色详情") style "description_label" yanchor 69
        null height 50
        vbox:
            hbox :
                text name style "smaller_text"
            null height 5
            null height 5
            #text name style 'note_txt'
            #text age style 'note_txt'
            text desk style "smaller_text"
            null height 5
            text likes style "smaller_text"
            null height 5
            text dislikes style "smaller_text"
            null height 5
            text hint style "smaller_text"
            #text suka style "smaller_text"
    #frame background None:
    #    area (158, 783, 513, 145)
    #    #style_group "charstyle"
    #    vbox:
    #        text "[ibu.name], age : [ibu.age]. [ibu.desc]" style 'note_txt'
    #timer 1.5 action Hide("inventory_popup")
style char_outer_frame:
    xpos 0.1 ypos 0.8
    padding (40,20)
init -2:

    ## STYLES ##
    style charstyle_frame:
        xalign 0.5
        yalign 0.5

    style charstyle_label_text:
        size 24

    style charstyle_label:
        xalign 0.5
screen chara_info():
    tag menu
    add "back.jpg"
    use navigation2
    add "gui/cast.png"
    use gold_count()
    if girl:
        imagebutton:
            idle "gui/main_ce.png"
            hover "gui/main_ce_hover.png"
            xpos 916
            ypos 196
            action NullAction()
            hovered [ Play ("test_one", "type.wav"), Show("char_popup_main")]
            unhovered Hide("char_popup_main")
    else:
        imagebutton:
            idle "gui/main_co.png"
            hover "gui/main_co_hover.png"
            xpos 916
            ypos 196
            action NullAction()
            hovered [ Play ("test_one", "type.wav"), Show("char_popup_main")]
            unhovered Hide("char_popup_main")

    imagebutton:
        idle "gui/ibu.png"
        hover "gui/ibu_hover.png"
        xpos 559
        ypos 195
        action NullAction()
        hovered [ Play ("test_one", "type.wav"), SetVariable("viewing", ibu.name), Show("ibu_bar")]
        unhovered [Hide("ibu_bar")]
    imagebutton:
        idle "gui/bff.png"
        hover "gui/bff_hover.png"
        xpos 738
        ypos 374
        action NullAction()
        hovered [ Play ("test_one", "type.wav"), SetVariable("viewing", bff.name), Show("bff_bar")]
        unhovered Hide("bff_bar")
    imagebutton:
        idle "gui/mrh.png"
        hover "gui/mrh_hover.png"
        xpos 1094
        ypos 374
        action NullAction()
        hovered [ Play ("test_one", "type.wav"), SetVariable("viewing", mrh.name), Show("mrh_bar")]
        unhovered Hide("mrh_bar")
    imagebutton:
        idle "gui/putri.png"
        hover "gui/putri_hover.png"
        xpos 1272
        ypos 196
        action NullAction()
        hovered [ Play ("test_one", "type.wav"), SetVariable("viewing", putri.name), Show("putri_bar")]
        unhovered Hide("putri_bar")
    textbutton _("返回") yalign .98 action Return() style "return_button"
