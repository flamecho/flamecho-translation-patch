﻿##############################################################################
## Sample script
image black = Solid('#000')
image bg shop = Solid("#ffbedb")
image bg lab = Solid("#c3beff")
screen cal():
    if morning:
        add "waktu pagi" xalign 0.0 yalign 0.0
        #text "Morning" xpos 130 ypos 60
    elif afternoon:
        add "waktu siang" xalign 0.0 yalign 0.0
        #text "Afternoon" xpos 130 ypos 60
    elif evening:
        add "waktu sore" xalign 0.0 yalign 0.0
        #text "Evening" xpos 130 ypos 60
    elif night:
        add "waktu malam" xalign 0.0 yalign 0.0
        #text "Night" xpos 130 ypos 60
    vbox xpos 130  ypos 16:
        hbox:
            text ( "%s" %calendar.weekday)
            text ","
        hbox:
            text ( "%d" %calendar.day)
            null
            text ( "%s" %calendar.month)


default povname = "帕尔米耶"
default nickname = "帕尔米"
default palmiergender = "m"
image palmierproxy = LayeredImageProxy("[palmiergender]palmier")
image side_p = LayeredImageProxy("side_[palmiergender]")
image pboy = LayeredImageProxy("[palmiergender]boy")

label start:
    # Waktu
    $ calendar = Calendar(15, 5, 2022, 2024)
    $ morning = False
    $ afternoon = True
    $ evening = False
    $ night = False
    #DATING
    $ lovely = False
    $ hate = False
    $ daterp = 30
    $ turnsleft = 2
    $ dia2 = ""
    $ kamu = ""
    $ dia = ""
    $ povname = "帕尔米耶"
    $ nickname = "你"
    $ kk = ""
    $ datingplace = ""
    $ datingname = ""
    $ skinshiparea = ""
    $ gift = ""
    $ looping = False
    #Shot
    $ nShot = 0
    #gender
    $ girl = False
    $ girl2 = False
    $ kln = False
    $ NPC = "???"
    #stats
    $ points = 0
    $ pointsMax = 100
    $ viewing = ""
    $ curiosity = 0
    $ honesty = 0
    $ kindness = 0
    #CHAR
    $ mrh = char(
        name="塞恩·维拉什科夫",
        pic= 'None',
        age = '20',
        desc = "[povname]的朋友（？）。对你来说看起来足够友好，尽管他有时露出牙齿笑得有点过分。",
        likes = "???",
        dislikes = "???",
        hint = "了解沃特克吸血鬼以推进他的路线。击败幻想巫师以完全解锁他的路线。"
        )
    $ bff = char(
        name="奎尔·英克威尔",
        age = '19',
        pic= 'None',
        points = 5,
        desc = "把你卷入这一切麻烦的混蛋。",
        likes = "婊子们、兄弟们和非二元性别的荡妇们，???",
        dislikes = "???",
        hint = "在唤醒你的分身之前揭开英克威尔家族的戏剧性事件，以推进他的路线。"
        )
    $ ibu = char(
        name="阿什姆·涅弗斯",
        points = 10,
        pic= 'None',
        age = "21",
        desc = "据说是你\"内部圈子\"的领导者。",
        likes = "???",
        dislikes = "???",
        hint = "管理他的痴迷以推进他的路线。击败贪婪巫师以完全解锁他的路线。"
        )
    $ putri = char(
        name="莱尔·凯森",
        pic= 'None',
        age = "18",
        desc = "你的室友和学弟。尽管体型很大，但他在你面前似乎相当胆小。不知道为什么。",
        likes = "???",
        dislikes = "???",
        hint = "击败变化巫师以完全解锁他的路线，与伊瓦尔对质他的儿子们。"
        )
    $ bocah = char(
        name="教师",
        pic= 'None'
        )
    $ devil = char(
        name="猎犬",
        desc = '你在地球上的指定监督者。',
        pic= 'None'
        )
    $ tinder = char(
        name="维什纳",
        pic= 'None'
        )
    $ main = char(
        name="[povname]",
        desc = "你自己，目前正试图在这个奇怪的巫师世界中找到方向。",
        pic= 'None'
        )
    $ allchars = [mrh, bff, devil, tinder, main, ibu, putri, bocah]
    ## copy this block into your own game
    python:
        gold = 0 #starting amount
        inv = []
        seen_items = []
        reward = 0

        # crafting
        known_recipes = []
        seen_recipes = []
        made_recipes = []
        newitem = ""

        # shop inventory
        market = []

        # quests
        new_quests = []
        active_quests = []
        completed_quests = []

        #events
        fia_events = []
        red_events = []
        quil_events =[]
        tom_events = []
        my_events = []
        buff_events = []
        topics = []
    ###
    # add a quest that only activates if you have money
    #if new_quest("sugar1") and gold>0:
    #    $ new_quests.append("sugar1")

    # activate all new quests
    #python:
    #    if len(new_quests) > 0: #if we have new quests
    #        for i in new_quests:
    #            active_quests.insert(0, i) #add to top of the quest list
    #        new_quests = [] #now reset the new quest list, since they all got added
    ## CRAFT/SHOP SETUP
    $ known_recipes = ["item_sucker","item_cake"]

    ## INVENTORY SETUP
    $ InvItem(*item_sucker).pickup(1)

    #$ InvItem(*item_sugar).toss(1)
    # $ InvItem(*item_beet).pickup(200)
    #if check_ingredients(InvItem(*item_sucker)): --> Check item
    ###########SMS


    $ unfreeze()

    $ messages = [] # list of all messages

    $ message_time = False # if True - get current time / or [hours, minutes] / or False
    $ in_history = False# add messages to history
    $ choice_number = True # default 1. choice1 / 2. choice2 / etc. / or False
    $ click_to_continue = False # if False - live mode messages
    $ time_to_send_pm = 1.0 # time to send picture message
    $ time_to_send_am = 1.0 # time to send audio message
    $ under_messenger = False # set False if you don't need a darker background under messenger

    $ typewriter = False # if False - you instantly send a message
    $ typewriter_speed = 2 # how fast you type

    $ interlocutor = "Azrael" # interlocutor's name
    $ interlocutor_online = True # interlocutor status
    $ interlocutor_typing = True # if False - interlocutor instantly sends a message
    $ interlocutor_extra_time = 0.5 # extra writing time
    $ interlocutor_typing_speed = 0.01 # default speed 0.1 * number of letters
    # add a quest with no unlock conditions
    $ topics.append("dreams")
    #window hide

    jump piko

label piko:

    window hide
    $ achievement.grant("Achievement01_Start")
    init:
        $ achievement.register("Achievement01_Start")
        $ achievement.sync()
    $ achievement.sync()
    show halo
    show ring_twirl behind halo
    show bg_tes behind ring_twirl:
        truecenter zoom 0.5
        ease 5.5 truecenter zoom 0.77
    show org:
        truecenter zoom 0.5
        ease 5.5 truecenter zoom 0.77
    $ renpy.pause(6.0,hard = True)
    show choose with moveintop:
        xalign 0.5 yalign 0.02
        zoom 0.3
    $ renpy.pause(1.5,hard = True)
    hide org
    show tangga:
        truecenter zoom 0.77
    call screen chara_select
    $ renpy.pause()
label cewe:
    $ girl = True
    $ kamu = "她"
    $ dia = "她"
    $ dia2 = "她"
    $ kk = "姐姐"
    hide screen chara_select
    $ palmiergender = "f"
    image palmierproxy = LayeredImageProxy("[palmiergender]palmier")
    image pboy = LayeredImageProxy("[palmiergender]boy")
    image side_p = LayeredImageProxy("side_[palmiergender]")
    scene bg_black with flashbulb
    play music "MUSIC/PerituneMaterial_Pray_Organ_loop.mp3" fadein 4.0
    $ quick_menu = False
    play sound "sound/effects/api.mp3"
    show n1_g at left with moveinleft
    show n2_g at right behind n1_g with moveinright
    $ renpy.pause()
    galleryunlock bolmat
    scene bg_black with fade
    play sound "sound/effects/squell.mp3"
    show o1 at left with moveinleft
    show o2 at left with moveinbottom
    play sound "sound/effects/api.mp3"
    show o3 at right with moveinright
    $ renpy.pause()
    galleryunlock say_tlg
    scene bg_black with fade
    play sound "sound/effects/roar.mp3"
    scene o5 with fade:
        yalign 1.0
        linear 2.5 yalign 0.0
    pause 1.5
    galleryunlock o5
    play sound "sound/effects/splat.wav"
    scene o6 with flashbulb
    galleryunlock o6
    $ renpy.pause()
    scene bg_black with dissolve
    pause 0.5
    stop music
    play sound "sound/effects/woosh.mp3"
    queue sound "sound/effects/clap.mp3"
    scene p1_girl with wet
    galleryunlock p1_girl
    $ renpy.pause()
    play sound "sound/effects/walk.mp3"
    scene bg_white with dissolve
    show p2_girl at left with moveintop
    galleryunlock p2g
    $ renpy.pause()
    show p3_girl at right with moveinright
    $ renpy.pause()
    scene bg_white with dissolve
    show p4_girl at left with moveinleft
    show p5_girl at right with moveinright
    $ renpy.pause()
    galleryunlock p4g
    scene p8 with flashbulb:
        yalign 1.0
        linear 10.0 yalign 0.0
    show mc_sh at pic
    mc "总之，你是打算就站在那里，还是下来给我治疗？"
    hide mc_sh
    show q_party at pic
    quil "那你准备给我什么回报，一个吻吗？"
    hide q_party
    show mc_sh at pic
    mc "...我宁愿死也不会吻你，奎尔。"
    hide mc_sh
    stop music
    pause 2.0
    scene bg_white with flashbulb
    jump night
label cowo:
    $ girl = False
    $ kamu = "他"
    $ dia = "他"
    $ dia2 = "他"
    $ kk = "哥哥"
    scene bg_white with flashbulb
    pause 1.0
    hide screen chara_select
    $ palmiergender = "m"
    image palmierproxy = LayeredImageProxy("[palmiergender]palmier")
    image pboy = LayeredImageProxy("[palmiergender]boy")
    image side_p = LayeredImageProxy("side_[palmiergender]")
    play music "MUSIC/rest.mp3" fadein 4.0
    $ quick_menu = False
    scene a1 with flashbulb:
        yalign 0.0
        linear 14.0 yalign 1.0
    $ renpy.pause()
    galleryunlock a1
    scene a2 with dissolve
    $ renpy.pause()
    galleryunlock a2
    galleryunlock bb1_3
    scene bg_white with flashbulb
    show b1 at left with dissolve
    $ renpy.pause()
    show b2 at left behind b1 with dissolve
    $ renpy.pause()
    show b3 behind b2 with dissolve
    show b4 with dissolve
    $ renpy.pause()
    scene bg_white with dissolve
    show b6 at right with moveinright
    $ NPC = "新娘"
    npc "亲爱的，当我向你表白时，我说你是我的初恋。"
    show b5 at left with moveinleft
    galleryunlock confess_b
    npc "而你回答说，尽管我不是你的第一个...但我会是你的最后一个。"
    $ NPC = "新娘"
    stop music fadeout 1.0
    scene bg_black with fade
    play sound "sound/effects/slap.mp3"
    show b7 at left with moveinleft
    play music "MUSIC/whisper.mp3"
    $ renpy.pause()
    show b8 at right with dissolve
    $ renpy.pause()
    galleryunlock lies
    scene bg_black with fade
    show c1 at left with dissolve
    play sound "sound/effects/slashkut.wav"
    stop music
    show c2 at right with dissolve
    galleryunlock penggal
    play music "sound/effects/panic.mp3"
    $ renpy.pause()
    show c3 at center:
        truecenter zoom 0.0
        linear 1.0 truecenter zoom 1.0
    $ renpy.pause()
    play sound "sound/effects/woosh.mp3"
    scene c4 with fade:
        yalign 1.0
        linear 10.0 yalign 0.0
    galleryunlock c4
    npc "啊，这就要走了吗？"
    npc "我们甚至还没切蛋糕呢..."
    scene bg_black with fade
    play sound "sound/effects/shield.mp3"
    play music "MUSIC/not_drill.mp3"
    show d1 at right with moveinright
    $ renpy.pause()
    play sound "sound/effects/wush.mp3"
    show d2 at left with moveinleft
    $ renpy.pause()
    play sound "sound/effects/swosh.mp3"
    show d3 at center with vpunch
    galleryunlock kebalik
    $ renpy.pause()
    show d4 with dissolve:
        yalign 1.0
        linear 1.0 yalign 0.0
    pause 0.5
    galleryunlock d4
    play sound "sound/effects/bump.mp3"
    show d5 with dissolve:
        yalign 0.0
        linear 8.5 yalign 1.0
    galleryunlock d5
    $ renpy.pause()
    scene bg_black with dissolve
    play sound "sound/effects/cicadas.mp3"
    show e1 at left with moveinbottom
    show e2 at left with moveintop
    show e3 at right with moveinright
    $ renpy.pause()
    galleryunlock kupu_priest
    scene bg_black with fade
    play sound "sound/effects/swosh.mp3"
    show f1 at left with moveintop
    play sound "sound/effects/woosh.mp3"
    show f2 at right with moveinright
    $ renpy.pause()
    galleryunlock green_kick
    scene bg_black with fade
    play sound "sound/effects/punch.mp3"
    show f3 with vpunch:
        truecenter zoom 2.0
        linear 0.5 zoom 1.0
    $ renpy.pause()
    galleryunlock f3
    scene bg_black with fade
    play sound "sound/effects/splash.wav"
    show g1 at left with dissolve
    show g2 with moveinright:
        xalign 1.0 yalign 0.0
    show g3 with moveinbottom:
        xalign 1.0 yalign 1.0
    $ renpy.pause()
    galleryunlock jebur
    scene bg_black with fade
    show h1 at left with moveinleft
    $ renpy.pause()
    play sound "sound/effects/wush.mp3"
    show h2 with moveintop:
        xalign 1.0 yalign 0.0
    $ renpy.pause()
    show h3 with moveinbottom:
        xalign 1.0 yalign 1.0
    $ renpy.pause()
    galleryunlock kampret
    scene bg_black with fade
    play sound "sound/effects/soundscalpel-com__water-splash.wav"
    show i1 at left with moveinleft
    show i2 with moveinbottom:
        xalign 1.0 yalign 1.0
    show i3 with moveintop:
        xalign 1.0 yalign 0.0
    $ renpy.pause()
    galleryunlock nagaair
    scene bg_black with fade
    show j1 at left with moveinleft
    show j2 at right behind j1 with moveinright
    $ renpy.pause()
    galleryunlock gelam
    scene bg_black with fade
    show k1 with moveintop:
        xalign 0.0 yalign 0.0
    show k2 with moveinleft:
        xalign 0.0 yalign 1.0
    $ renpy.pause()
    stop music
    play music "MUSIC/PerituneMaterial_Pray_Organ_loop.mp3" fadein 4.0
    #play sound "sound/effects/piano.mp3"
    show k3 with moveinbottom:
        xalign 0.0 yalign 1.0
    queue sound "sound/effects/stab.mp3"
    show k4 at right with dissolve
    $ renpy.pause()
    galleryunlock holy
    scene bg_black with fade
    play sound "sound/effects/slashkut.wav"
    queue sound "sound/effects/squell.mp3"
    show l1 at left with vpunch
    $ renpy.pause()
    play sound "sound/effects/splash.wav"
    show l2 at right with moveinright
    $ renpy.pause()
    galleryunlock dar_note
    scene bg_black with fade
    show m1 at left with dissolve
    $ renpy.pause()
    play sound "sound/effects/woosh.mp3"
    show m2 with moveintop:
        xalign 1.0 yalign 0.0
    show m4:
        xalign 1.0 yalign 0.0
    play sound "sound/effects/monster_scream.mp3"
    show m3 behind m4 with moveinbottom:
        xalign 1.0 yalign 1.0
    $ renpy.pause()
    galleryunlock git_leng
    scene bg_black with fade
    play sound "sound/effects/api.mp3"
    show n1 at left with moveinleft
    $ renpy.pause()
    show n2 at right behind n1 with moveinright
    $ renpy.pause()
    galleryunlock bolmat
    scene bg_black with fade
    play sound "sound/effects/burning.mp3"
    show o1 at left with moveinleft
    queue sound "sound/effects/api.mp3"
    show o2 at left with moveinbottom
    show o3 at right with moveinright
    $ renpy.pause()
    galleryunlock say_tlg
    scene bg_black with fade
    show o4 with moveintop:
        xalign 0.0 yalign 0.0
    show o4_1 with moveinbottom:
        xalign 0.0 yalign 1.0
    show o4_2 at right with moveinright
    $ renpy.pause()
    galleryunlock met_nikah
    play sound "sound/effects/roar.mp3"
    stop music
    scene o5 with fade:
        yalign 1.0
        linear 2.5 yalign 0.0
    pause 1.5
    stop music
    play sound "sound/effects/splat.wav"
    scene o6 with flashbulb
    $ renpy.pause()
    galleryunlock o6
    scene bg_black with dissolve
    pause 0.5
    play sound "sound/effects/woosh.mp3"
    scene p1 with wet
    $ renpy.pause()
    galleryunlock p1
    play sound "sound/effects/walk.mp3"
    scene bg_white with dissolve
    show p2 at left with moveintop
    $ renpy.pause()
    galleryunlock p2m
    play sound "sound/effects/cloth.mp3"
    show p3 at right with moveinright
    $ renpy.pause()
    show p3 at left with move
    show p4 at right with moveinright
    $ renpy.pause()
    galleryunlock baju_gud
    scene bg_white with dissolve
    show p5 at left with moveinleft
    $ renpy.pause()
    show p6 at right with moveinright
    $ renpy.pause()
    galleryunlock white_space
    scene p7 with dissolve
    galleryunlock p7
    $ renpy.pause()
    scene p8 with flashbulb:
        yalign 1.0
        linear 7.0 yalign 0.0
    mc "我宁愿死，奎尔。"
    pause 2.0
    scene bg_white with flashbulb

    jump night

##CRAFTING
label start_crafting:
    scene craft
    if "item_bread" not in known_recipes:
        if check_inv_for(recipe_items):
            $ known_recipes.extend(["item_bread","item_coco","item_caramel"])
            $ known_recipes.append("item_catfood")
        else:
            pass
    call screen recipes() with Dissolve(.2)

label craft_success:
    show screen reward(newitem.image)
    play sound "ding.mp3"
    "制作了{color=#d48}[newitem.name!t]{/color}！"
    hide screen reward
    
    if "blood1" in active_quests:

        if check_inv_for(blood_items):
            show side_p se at pic
            mc "好了，这应该足够给塞恩了。现在我只需要把它交给他。"
            hide side_p
        else:
            pass
    else:
        if check_inv_for(cure_items) and "cure_me" not in red_events and "io4" not in my_events and "bond" not in fia_events:
            jump red_cure
        elif check_inv_for(ctul_items) and "ctulpot" not in fia_events:
            "克苏鲁的呼唤药剂在你手中歌唱。"
            "触摸时感觉温暖，粘稠的金色药剂中闪烁着奇异的光芒。"
            $ fia_events.append("ctulpot")
            if calendar.weekday == "Sat" or calendar.weekday == "Sun":
                show pboy s at horzappear
            else:
                show pboy at horzappear
            menu:
                "要喝吗？":
                    hide pboy
                    if "ctul1" in active_quests and check_inv_for(ctul_items):
                        python:
                            InvItem(*item_vita2).toss(1)
                            active_quests.remove("ctul1")
                            completed_quests.insert(0, "ctul1")
                        show screen completedtask("任务完成！")
                    "你喝下了药剂，脑海中开始闪现各种景象，就像在放电影一样。"
                    if "diari1" in completed_quests:
                        if girl:
                            scene hugf_end with flashbulb
                        else:
                            scene hugm_end with flashbulb
                        "你看到[povname]开心地拥抱着菲亚在[dia]怀里——[dia]的眼睛是引人注目的银色，瞳孔像猫一样细长。"
                        "所有朋友都在为你们庆祝。"
                    elif "iv_curhat" in fia_events:
                        if girl:
                            scene ivar_fend with flashbulb:
                                truecenter zoom 0.7
                        else:
                            scene ivar_end with flashbulb:
                                truecenter zoom 0.5
                        "你看到自己的身影……在亲吻自己？似乎是在一片广阔的花园里。"
                    else:
                        if girl:
                            scene seth_fend with flashbulb:
                                truecenter zoom 0.5
                        else:
                            scene seth_mend with flashbulb:
                                truecenter zoom 0.5
                        "你看到自己被你的分身压在身下，他们手中握着一颗发光的白色宝石。"
                    show side_p s at pic
                    mc "嗯。这是怎么回事？"    
                    hide side_p
                    scene map_potion with flashbulb
                    "你眨了眨眼，幻象从你的脑海中消失了。"
                    call screen potion_map    
                "不了":
                    hide pboy
                    scene map_potion
                    call screen potion_map 
        else:
            pass


    if calendar.weekday == "Sat" or calendar.weekday == "Sun":
        show pboy s at horzappear
    else:
        show pboy at horzappear
    menu:
        "制作别的。":
            hide pboy
            jump start_crafting
        "继续探索。":
            hide pboy
            jump map_potion

label night:
    play sound "sound/effects/cloth.mp3"
    if girl:
        galleryunlock sofa_cewe
        scene sofa_cewe with flashbulb:
            zoom 2.0
            linear 2.5 zoom 1.0
    else:
        galleryunlock sofa_cowo
        scene sofa_cowo with flashbulb:
            zoom 2.0
            linear 2.5 zoom 1.0
    mc "一个梦？"
    #play music "MUSIC/MusMus-BGM-084.mp3"
    scene apt with dissolve
    show screen cal
    $ quick_menu = True
    play sound "sound/effects/278160__sirrealist2__vibrate.mp3"
    if girl:
        show p_side fr at pic
    else:
        show side_p fr at pic
    mc "我的手机..."
    stop sound
    if girl:
        hide p_side
    else:
        hide side_p
    $ interlocutor = "Phrase Service Center"
    $ del_all_msg()
    window hide
    show hp at move_messenger2
    pause 1.0
    $ show_messenger()
    "点击继续查看消息"
    $ msg ("登录错误！", who=1, status='online')
    $ click_to_continue = True
    $ msg ("很抱歉，但似乎您在另一台设备上同时登录了。", who=1, status='online')
    $ msg ("请告诉我们您的详细信息，以便我们授予您访问账户的权限。", who=1, status='online')
    $ click_to_continue = False
    $ msg ("首先，您的名字是帕尔米耶吗？", who=1, status='online')
    $ msg ("（在下方选择您的回复）")
    $ click_to_continue = True
    $ msg ("", choices={0:{'jump':'iya', 'name':"是的。"}, 1:{'jump':'input_name', 'name':"不是。"}})
label lanjut_txt:
    $ msg ("您的代词是？", who=1, status='online')
    $ msg ("", choices={0:{'jump':'she', 'name':"她/她的"}, 1:{'jump':'he', 'name':"他/他的"}, 2:{'jump':'they', 'name':"他们/他们的"}})
label lanjut_txt2:
    $ msg ("最后，您的账户安全问题。您妹妹的全名是什么？", who=1, status='online')
    $ msg ("菲亚·阿马里斯·贝克。")
    $ msg ("我们已验证您的账户。感谢您的耐心等待！", who=1, status='online')
    $ hide_messenger()
    $ interlocutor = "Mum"
    $ del_all_msg()
    show phone:
        xalign .5 yalign 1.5

    hide phone
    $ show_messenger()

    $ msg ("生日快乐！", who=1, status='online')
    $ msg ("看看我在菲亚的旧手机里找到了什么。", who=1)

    if girl:
        if girl2 or kln:
            $ msg (None, who=1, audio="raven2", audio_bar=1)
        else:
            $ msg (None, who=1, audio="raven", audio_bar=1)
    else:
        if girl2:
            $ msg (None, who=1, audio="raven2", audio_bar=1)
        else:
            $ msg (None, who=1, audio="raven", audio_bar=1)
    $ msg ("很可爱，对吧？我记得你以前每次收到她发的那些消息时都会生气。", who=1)
    $ msg ("打赌你现在很想念它们。", who=1)
    $ msg (None, who=1, pic="raven")
    $ msg ("你今天去看她了吗？", who=1)
    $ msg ("去了")
    $ msg ("谢谢你，亲爱的。", who=1)
    $ msg ("我知道这感觉很复杂。你的生日和她去世是同一天，但尽量不要太过纠结。", who=1)
    $ msg ("再说一次，亲爱的，这不是你的错。你是喝醉了，但那个卡车司机也是。", who=1)
    $ msg ("总之，我今晚做了你最喜欢的菜。一会儿见，好吗？爱你！", who=1)
    $ msg ("", choices={0:{'jump':'faith', 'name':"我也爱你。"}, 1:{'jump':'thx', 'name':"K"}})
label she:
    $ kamu = "她"
    $ dia = "她"
    $ dia2 = "她"
    $ kk = "姐姐"
    $ msg ("她/她的")
    $ girl2 = True
    jump lanjut_txt2
label he:
    $ kamu = "他"
    $ dia = "他"
    $ dia2 = "他"
    $ kk = "哥哥"
    $ msg ("他/他的")
    jump lanjut_txt2
label they:
    $ kamu = "they"
    $ dia = "their"
    $ dia2 = "them"
    $ kln = True
    $ msg ("他们/他们的")
    jump lanjut_txt2
label iya:
    $ msg ("是的")
    $ povname = "帕尔米耶"
    $ nickname = "帕尔米"
    jump lanjut_txt
label input_name:
    $ msg ("不是")
    
    python:
        povname = renpy.input("你的名字是什么？ (少于八个字)", length=8)
        povname = povname.strip()
        nickname = povname.strip()
        if not povname:
            povname = "帕尔米耶"
            nickname = "帕尔米"
    $ msg ("我的名字是[povname]")
    $ msg ("账户已更新。", who=1)
    jump lanjut_txt
label faith:
    python:
        msg ("我也爱你，妈妈。")
    $ hide_messenger()
    hide hp
    show hp2 at move_messenger3
    pause 1.0
    scene apt with dissolve


    jump sucked_in
label thx:
    python:
        msg ("K.")
    $ hide_messenger()
    hide hp
    show hp2 at move_messenger3
    pause 1.0
    scene apt with dissolve


    jump sucked_in

label sucked_in:
    if girl:
        show p_side fr at pic
    else:
        show side_p fr at pic
    mc "对了。我今晚应该去妈妈那里。该死，已经14:30了？最好赶紧收拾一下。"
    if girl:
        hide p_side
    else:
        hide side_p
    play sound "sound/effects/walk.mp3"
    "带着剧烈的头痛，你蹒跚地走向浴室。"
    scene wc with dissolve
    play sound "sound/effects/door.mp3"
    "你知道出去喝酒是个糟糕的决定。通常你能很好地抵抗这种诱惑。"
    "但你的生日总是一个挑战，而且不止一个方面。"
    if girl:
        show p_side gl at pic
    else:
        show side_p g at pic
    mc "..."
    if girl:
        hide p_side
    else:
        hide side_p
    play sound "sound/effects/sink.mp3"
    "洗脸的时候，你开始恢复理智，试图回忆昨晚发生了什么。"
    "然而无论你如何努力，那个梦却一直在你脑海中浮现。"
    if girl:
        show p_side gl at pic
    else:
        show side_p sdh at pic
    mc "多么奇怪的梦...它是如此生动。几乎就像...就像..."
    if girl:
        hide p_side
    else:
        hide side_p
    scene bg_black with fade
    play sound "sound/effects/glitch3.mp3"
    show glitch_aja onlayer front
    if girl:
        show qg with dissolve
        galleryunlock qg
    else:
        show q1 with dissolve
        galleryunlock q1
    mc "一段记忆？"
    play music "sound/effects/jantung.mp3"
    scene bg_black with fade
    hide glitch_aja onlayer front
    show hands at center with dissolve
    play sound "sound/effects/summon.mp3"
    if girl:
        show p_side y at pic
    else:
        show side_p k at pic
    mc"什么鬼？！"
    if girl:
        hide p_side at pic
    else:
        hide side_p at pic
    "手开始从镜子里伸出来，抓住你的衬衫，你的头发。"
    "抓挠着它们能抓到的你身上的每一个部位。"
    scene bg_black with vpunch
    play sound "sound/effects/cloth.mp3"
    "然后，是疼痛。你感觉自己好像被拉进了一个狭小的钥匙孔。你闭上眼睛，希望这只是另一个梦。"
    jump meeting_quil
label meeting_quil:
    stop music
    play sound "sound/effects/woosh.mp3"
    if not girl:
        galleryunlock witch_entrace
        scene witch_entrace with flashbulb:
            truecenter zoom 2.0
            easein 1.0 truecenter zoom 0.5
    else:
        galleryunlock witch_entrace_g
        scene witch_entrace_g with flashbulb:
            truecenter zoom 2.0
            easein 1.0 truecenter zoom 0.5
    $ renpy.pause()
    scene seat with vpunch
    galleryunlock seat
    play sound "sound/effects/bump.mp3"
    "你一头栽倒在坚硬的木地板上。头上的重重一击迫使你睁开了眼睛。"
    "睁眼后，你看到一个面色苍白的身影俯视着你，脸上带着狡黠的笑容。"
    quil "嗯，你看看，成功了。"
    scene qpt with dissolve
    show quil libur amused at center with dissolve:
        yoffset 200
    play music "MUSIC/MusMus-BGM-089.mp3"

    if girl:
        show p_side y at pic
    else:
        show side_p k at pic

    mc "什么？！你——你他妈是谁？！"
    if girl:
        hide p_side at pic
    else:
        hide side_p at pic
    quil datar "嗯，声音一样，身高也一样。你比[povname]壮实一点，不过我可以轻易地把这归因于锻炼。"
    quil kzl "不过你眼中那丝希望的光芒..."
    quil laugh bunga "好吧，我相信那很快就会消失的。总的来说，你还行。亲爱的科尔，难道有什么是我做不到的吗？"
    if girl:
        show p_side fr at pic
    else:
        show side_p fr at pic
    mc "[povname]？等等，你怎么知道我的名字？"
    if girl:
        hide p_side at pic
    else:
        hide side_p at pic
    quil avoid -bunga "实际上是[dia]的名字。"
    if girl:
        scene mayat_g with dissolve
        galleryunlock mayat_g
    else:
        scene mayat with dissolve
        galleryunlock mayat
    show side_q bebas at pic
    quil "不过我猜你们两个是同一个人。"
    hide side_q
    "你瞥了一眼地板，看到一个失去意识的身体。那张脸与你的惊人相似。"
    if girl:
        show p_side gl at pic
    else:
        show side_p sdh at pic
    mc "（等等，那是...我？）"
    if girl:
        show p_side y at pic
    else:
        show side_p k at pic
    mc "啊啊啊啊！" with vpunch
    scene qpt with dissolve
    show quil libur err at center with dissolve:
        yoffset 200
    if not girl2:
        quil frusta "哦，不用这么夸张。[povname]还活着，勉强，但总归是活着。你看，[dia2]被一个巫师诅咒了。"
    else:
        quil frusta "哦，不用这么夸张。[povname]还活着，勉强，但总归是活着。你看，[dia]被一个巫师诅咒了。"
    quil tantrum sigh "一个彻头彻尾的恶毒新娘。不得不烧两次才能杀死她，但这就是伊瓦尔的女儿们。"
    if girl:
        show p_side gl at pic
    else:
        show side_p sdh at pic
    mc "巫师？等等，你...你就是我梦中的那个人。"
    if girl:
        hide p_side at pic
    else:
        hide side_p at pic
    mc "（我还在做梦吗？）"
    quil talk shock "哦，所以这是真的。来自其他领域的我们的替身确实在睡梦中与我们相连，有趣。"
    quil heh cling "我想知道我的另一个自己睡过多少人，嗯..."
    quil smile apa "告诉我，在你的世界里有魔法吗？还是你是那些不幸的只能依靠\'聪明才智\'的人之一？"
    if girl:
        show p_side gl at pic
    else:
        show side_p g at pic
    mc "魔法？像波利哈特那样？"
    if girl:
        hide p_side at pic
    else:
        hide side_p at pic
    quil mock sigh "我猜那就是没有了。真遗憾。好吧，我相信我可以在路上向你解释。"
    scene qpt with vpunch

    play sound "sound/effects/cloth.mp3"
    if girl:
        show pulled1_g with moveinleft:
            xalign 0.0 yalign 1.0
    else:
        show pulled1 with moveinleft:
            xalign 0.0 yalign 1.0
    mc "等等，什么？！"
    if girl:
        galleryunlock nafas_f
        show pulled2_g with moveinbottom:
            xalign 0.0 yalign 1.0
    else:
        galleryunlock nafas_m
        show pulled2 with moveinbottom:
            xalign 0.0 yalign 1.0
    stop music
    quil "屏住呼吸。"
    play sound "sound/effects/splash.wav"
    if girl:
        show pulled3_g with rain1:
            xalign 1.0 yalign 1.0
    else:
        show pulled3 with rain1:
            xalign 1.0 yalign 1.0
    $ renpy.pause()
    if not girl:
        scene walk with rain1
        galleryunlock walk
    else:
        scene lake with rain1
    play music "MUSIC/MusMus-BGM-108.mp3"
    if girl:
        show p_side gl at pic
    mc "刚才发生了什么？！你是怎么——？"
    if girl:
        hide p_side
    show side_q bebas at pic
    quil "你总是这么善于表达吗？我想就像[povname]一样，你也不是一个健谈的人。不过至少那个人能说出完整的句子。"
    quil "现在跟上来。"
    hide side_q
    scene climb with dissolve
    play sound "sound/effects/tile.mp3"
    "说完，那个白发男子就跑上了一段令人生畏的楼梯。"
    "想要得到答案，你本能地跟了上去。"
    if girl:
        show girl_s at horzappear
    else:
        show boy_s at horzappear

    menu:
        "我能说出完整的句子！":
            hide girl_s
            hide boy_s
            show side_q bebas at pic
            quil "哎呀，真不错！看来你并不是完全的白痴嘛。"
            hide side_q
            if girl:
                show p_side y at pic
            else:
                play sound "sound/effects/walk.mp3"
                scene complain with dissolve
                galleryunlock complain
            mc "听着，混蛋！你能不能慢点，告诉我到底发生了什么？"
        "告诉我到底发生了什么！":
            hide girl_s
            hide boy_s
            show side_q bebas frown at pic
            quil "你是不是不能边走边听？"
            quil "你知道吗，我正准备解释呢。"
            hide side_q bebas frown
            if girl:
                show p_side y at pic
            else:
                play sound "sound/effects/walk.mp3"
                scene complain with dissolve
            mc "那就开始说吧，混蛋！"
    scene climb with dissolve
    show quil libur kzl at center with dissolve:
        yoffset 200
    quil frusta "首先，我的名字是奎尔·英克威尔，谢谢。"
    quil tantrum -frusta sweat "总之，长话短说，这是一次出错的巫师悬赏任务。"
    quil frown "一开始看起来很简单。新郎的母亲不想让她的儿子娶一个巫师。"
    if girl:
        quil "所以我们乔装打扮，闯入婚礼..."
    else:
        quil "[povname]租了一套牧师的服装，我们贿赂了真正的牧师离开..."
    quil sad frusta "...我们以为我们赢了，但那个巫师还有几个花招。"
    quil sulk sweat -frusta "事情出了岔子，现在我最好的朋友因此陷入了昏迷。"
    if girl2:
        quil bingung -sweat sigh "所以现在我需要找到方法让[dia]在人们发现之前从昏迷中醒来。"
    else:
        quil bingung -sweat sigh "所以现在我需要找到方法让[dia2]在人们发现之前从昏迷中醒来。"
    if girl:
        show p_side y at pic
    else:
        show side_p k at pic
    mc "那我在这里是因为？"
    if girl:
        hide p_side
    else:
        hide side_p
    if girl2:
        quil frown -sweat -sigh "来替[dia]顶替。[nickname]和我正处于见习猎巫人的最后一年。老师们可以原谅几次缺课，当然。"
    else:
        quil frown -sweat -sigh "来替[dia2]顶替。[nickname]和我正处于见习猎巫人的最后一年。老师们可以原谅几次缺课，当然。"
    quil sulk sweat "但这种复杂的诅咒？在我找到解药之前，他们会起疑心的。"
    quil cringe -sweat "[povname]现在变成植物人了，[kamu]真的不能上课了，对吧？"
    if girl:
        show p_side fr at pic
    else:
        show side_p fr at pic
    if girl2:
        mc "猎巫人？但在我的梦里，我，我是说[kamu]，不是在[dia]的身边有一个巫师吗？"
    else:
        mc "猎巫人？但在我的梦里，我，我是说[kamu]，不是在[dia2]身边有一个巫师吗？"
    if girl:
        hide p_side
    else:
        hide side_p
    quil frown "哦，你是说那个黑色恶魔般的巫师。就是[kamu]用来烧死新娘怪的那个。"
    if girl:
        quil bingung sigh "没错，那是[dia]的灵魂伴侣契约。那个白痴决定把[dia]的灵魂永远绑定在一个巫师身上，认为这是个好主意。"
    else:
        quil bingung sigh "没错，那是[dia]的灵魂伴侣契约。那个混蛋决定把[dia]灵魂永远绑定在一个巫师身上，认为这是个好主意。"

    if girl:
        show p_side gl at pic
    else:
        show side_p g at pic
    mc "灵魂绑定？"
    if girl:
        hide p_side
    else:
        hide side_p
    quil cringe apa "什么？你们不是要把灵魂与配偶绑定直到死亡将你们分开吗？不然你怎么保证他们的忠诚？"
    if girl:
        show p_side fr at pic
    else:
        show side_p fr at pic
    mc "我不知道，信任？"
    if girl:
        hide p_side
    else:
        hide side_p
    quil ow sweat -apa "呃。真是...古板。"
    play sound "sound/effects/walk.mp3"
    if girl:
        galleryunlock pigeon_g
        scene pigeon_g with dissolve
    else:
        galleryunlock pigeon
        scene pigeon with dissolve
    show side_q bebas at pic
    if girl2:
        quil "好吧，重点是我的[povname]不知怎么设法诱惑了一个巫师与[dia]绑定。"
        show side_q frown
        quil "令人印象深刻，当然，聪明？不太聪明。现在[kamu]因此陷入了昏迷。"
    else:
        quil "好吧，重点是我的[povname]不知怎么设法诱惑了一个巫师与[dia2]绑定。"
        show side_q frown
        quil "令人印象深刻，当然。聪明？不太聪明。现在[povname]因此陷入了昏迷。"
    hide side_q frown
    if girl:
        show p_side fr at pic
    else:
        show side_p h at pic
    mc "等等，所以[dia]的绑定是[dia]昏迷的原因？"
    scene climb2 with dissolve
    show quil libur frown at center with dissolve:
        yoffset 200
    quil "嗯...你在梦中看到的最后一件事是什么？"
    if girl:
        show p_side fr at pic
        mc "好像是关于治疗的事？"
    else:
        show side_p h at pic
        if girl2:
            mc "你叫[dia]爸爸？"
        else:
            mc "你叫[dia2]爸爸？"
    if girl:
        hide p_side
    else:
        hide side_p
    if girl:
        quil rajuk sigh "啊，是的。那个巫师伏击了我们。原来她还没有完全死去。"
        quil sad sweat -sigh "[povname]被一个法术击中了。是我从未见过的法术。"
        quil frown -sweat "基本上，它封印了[dia]的巫师契约。[dia]的一半灵魂现在不知所踪。"
        quil amused "所以我需要想办法解决这一切，而你要代替[povname]。"
    else:
        quil rajuk sigh "啊，是的。可惜[povname]对我的提议不太感兴趣。而且[kamu]烧死的那个巫师，她并没有我们想象的那么死。"
        quil sad sweat -sigh "她用一个法术击中了[povname]。是我从未见过的法术。"
        quil frown -sweat "基本上，它封印了[dia]的巫师契约。[dia]的一半灵魂现在不知所踪。"
        quil amused"所以我需要想办法解决这一切，而你要代替[povname]。"
    if girl:
        show p_side y at pic
    else:
        show side_p k at pic
    mc "代替？我他妈的几乎都不知道发生了什么。你还指望我施魔法和猎杀巫师？！"
    if girl:
        hide p_side
    else:
        hide side_p
    quil mock "即使是一只刻有科尔符文的猴子也能施魔法。别担心。"
    quil smile cling "大多数巫师并不像你在梦中看到的那个那么敌对。"
    if girl:
        show girl_s at horzappear
    else:
        show boy_s at horzappear
    menu:
        "这对我有什么好处？":
            hide girl_s
            hide boy_s
            if girl:
                show p_side y at pic
            else:
                show side_p k at pic
            mc "这要求太多了，前景却很少。"
            if girl:
                hide p_side
            else:
                hide side_p
            quil sly "哦，亲爱的，补偿是非常值得的。我选择你是有原因的，你知道吗？"
            quil talk -cling "毕竟，你想念你的妹妹，不是吗？"
            if girl:
                show p_side gl at pic
            else:
                show side_p sdh at pic
            mc "妹妹？等等，菲亚？她在这里？！她还活着？！"
            if girl:
                hide p_side
            else:
                hide side_p
            galleryunlock welcome
            scene welcome with flashbulb:
                truecenter zoom 1.0
                easein 0.5 truecenter zoom 0.5
            quil laugh "你会看到的。不过在此期间..."

        "我觉得不行。":
            hide girl_s
            hide boy_s
            quil bingung shock "不行？"
            if girl:
                show p_side y at pic
            else:
                show side_p k at pic
            show quil frown -shock
            mc "不行！听着，就我所知，这可能只是我做的一个噩梦！"
            mc "我以前出现过更糟糕的幻觉。一个任性的小白脸\'猎巫人\'并不是我这个滥用药物的大脑能想出的最奇怪的东西。"
            if girl:
                hide p_side
            else:
                hide side_p
            quil amused apa "你认为这一切都是一场梦？"
            if girl:
                show p_side y at pic
            else:
                show side_p k at pic
            mc "一定是的！"
            if girl:
                hide p_side
            else:
                hide side_p
            quil sly -apa "嗯，不是冒犯，亲爱的。"
            scene welcome with flashbulb:
                truecenter zoom 1.0
                easein 0.5 truecenter zoom 0.5
            quil laugh "但我不认为你的大脑有足够的创造力能想象出这一切。"


    scene map_all2 with flashbulb:
        truecenter zoom 2.0
        linear 1.0 truecenter zoom 1.0
    quil "欢迎来到伊格尼亚的猎巫人学院。"
    pause 2.0
    scene port with dissolve
    show quil libur laugh at center with dissolve:
        yoffset 200
    quil datar -bunga "她很迷人，不是吗？我相信你会在自己的时间里慢慢了解她的。"
    quil talk "现在不是目瞪口呆的时候。我们不能迟到，这是本学期的第一堂课。"
    quil smile "如果说[nickname]有什么优点的话，那就是[dia]的守时！"
    play sound "sound/effects/walk.mp3"
    scene arrow_fort_crowd with dissolve
    "当你跟随奎尔时，你不禁注意到射箭场上有一群女孩在兴高采烈地尖叫。"
    play sound "sound/effects/flame.mp3"
    galleryunlock fans
    scene fans with dissolve:
        truecenter zoom 1.0
        easein 1.0 truecenter zoom 0.5
    $ renpy.pause()
    play sound "sound/effects/api.mp3"
    if girl:
        scene fans1_ce with dissolve
        galleryunlock fans1_ce
    else:
        scene fans1_co with dissolve
        galleryunlock fans1_co
    $ renpy.pause()
    play sound "sound/effects/explode.mp3"
    galleryunlock fans2
    scene fans2 with flashbulb:
        truecenter zoom 2.0
        easein 1.0 truecenter zoom 1.0
    pause 1.5
    show side_p fr at pic
    mc "（哇！我可不想做那个要清理这一切的人。）"
    hide side_p
    scene archery_crowd with dissolve
    show tom hip at center with dissolve:
        yoffset 200
    show side_p fr at pic
    mc "（等等，那个家伙在盯着我看吗？）"
    hide side_p
    if girl:
        show girl_s at horzappear
    else:
        show boy_s at horzappear
    menu:
        "眨眼。":
            hide girl_s
            hide boy_s
            #malu
            $ flip_off = False
            $ wink = True
            $ibu.points += 5
            show tom eh both shock
            show side_p ha at pic
            mc "（哦，他脸红了。）"
            hide side_p
            show tom pfft blush -shock
            pause 1.0
        "无视。":
            hide girl_s
            hide boy_s
            $ flip_off = False
            $ wink = False
            show tom chill kzl sweat shock
            show side_p fr at pic
            mc "（他似乎很恼火。\"我\"认识他吗？）"
            hide side_p
            show tom chill capek -sweat blow
            pause 1.0

        "竖中指。":
            hide girl_s
            hide boy_s
            $ flip_off = True
            $ wink = False
            show tom chill ew sweat shock
            show side_p k at pic
            mc "（哦，他生气了。）"
            hide side_p
            show tom hip capek  frusta
            pause 1.0

    stop music
    scene arrow_fort_crowd with dissolve
    play sound "sound/effects/walk.mp3"
    red "奎尔，[nickname]！" with vpunch
    "你听到远处有人在呼唤你。奎尔停在你面前，低声咕哝着。"
    show quil libur groan frusta at center with dissolve:
        yoffset 200
    quil "该死的多管闲事的蠢狗。"
    play music "MUSIC/MusMus-BGM-098.mp3"
    show red at left with moveinleft:
        yoffset 330
    show quil laugh -frusta at right with move:
        yoffset 200
    quil  "塞恩！我的朋友，你好啊？"
    show quil datar
    "奎尔挂上一副假笑，一个开朗的红发男子向你们招手。"
    show red amused at left:
        yoffset 330
    if girl2:
        red "奎尔，[nickname]，怎么样？你们一起度过的暑假如何？"
    else:
        red "奎尔，[nickname]，怎么样兄弟？你们一起度过的暑假如何？"
    red laugh "[nickname]，英克威尔庄园那些势利小人有没有给你找麻烦？"
    "你注意到那个男人急切地等待着你的回答。只是你甚至不确定自己能给出什么样的回答。"
    if girl:
        show p_side gl at pic
    else:
        show side_p g at pic
    mc "啊嗯...嗯，你知道的。"
    if girl:
        hide p_side
    else:
        hide side_p
    quil heh "我的家人非常热情好客，非常感谢。"
    show quil datar
    red wry "哈哈，意思是你父母几乎不在家，整个庄园都归你们了？"
    quil wink cling "自然如此。"
    show quil datar -cling
    red grin "经典。哦对了，[nickname]！这是我们这学期第一次见面，所以你知道，按照传统..."
    hide quil datarwith dissolve
    show red cowo at center with move:
        yoffset 330
    red laugh "...来击个掌吧！"
    if girl:
        show p_side gl at pic
    else:
        show side_p h at pic
    mc "（呃...什么？）"
    if girl:
        hide p_side
    else:
        hide side_p
    red "来吧，别害羞！"
    show tut with dissolve:
        yalign 0.3 xalign 0.5
    $ renpy.pause()
    hide tut with dissolve
    $ devil.acara += 1
    $ quick_menu = False
    jump datingintro

label ganti_baju:
    $ quick_menu = True
    $ renpy.block_rollback()
    $ config.rollback_enabled = True
    play sound "sound/effects/walk.mp3"
    show screen cal
    scene arrow_fort_crowd with dissolve
    show quil libur datar at center:
        yoffset 200
    if daterp >= 70:
        quil "很好地配合演出了。"
    else:
        quil sad sweat sigh "差点就露馅了。"
    quil amused -sweat -sigh "幸好塞尼宝贝不是最聪明的那个。"
    quil sulk "不过，如果是阿什姆的话，嗯...我会发短信给你详细说明我们的友谊。"
    quil frown "这应该能加快进度。给。"
    "奎尔递给你一部手机，与你自己的没什么不同。"
    "颜色相同，大小相同，唯一的区别是这部手机没那么破旧。"
    quil talk "这是[nickname]的手机。"
    if girl:
        show p_side fr at pic
    else:
        show side_p fr at pic
    mc "我有自己的手机。呃，等等...糟糕，我一定是把它落在客厅里了。"
    mc "（妈妈...）"
    if girl:
        hide p_side
    else:
        hide side_p
    quil smile "这更是你该拿[nickname]的手机的理由。"
    if girl:
        show p_side y at pic
    else:
        show side_p k at pic
    mc "..."
    if girl:
        hide p_side
    else:
        hide side_p
    "你勉强接过手机，希望能以某种方式再次联系上你的母亲。"
    quil talk "好了，跟我来吧。让我们给你换上校服。"
    scene kmr_pagi with dissolve
    stop music
    play sound "sound/effects/door.mp3"

    show quil libur datar at center with dissolve:
        yoffset 200
    play music "MUSIC/MusMus-BGM-116.mp3"
    quil rajuk sigh "很好，你的室友不在这里。"
    if girl:
        show p_side fr at pic
    else:
        show side_p fr at pic
    mc "等等，室友？"
    if girl:
        hide p_side
    else:
        hide side_p
    quil datar  -sigh "我们总是被分配一个低年级的室友。"
    quil heh "今年你分到了一个一年级新生，但我猜你很幸运，他们现在不在这里。"
    quil datar "你的衣服在衣柜里，可能会有点紧，但凑合着穿吧。"
    quil smile "我也要去换衣服，然后来接你。"
    if girl:
        show girl_s at horzappear
    else:
        show boy_s at horzappear
    menu:
        "我能从中得到什么好处？":
            hide girl_s
            hide boy_s
            quil wink cling "哦，别担心，我一定会给你发送奖励的。"
        "我还是觉得这一切只是一场梦。":
            hide girl_s
            hide boy_s
            quil mock "总比噩梦好。不过既然你这么不相信，我一定会给你发送奖励的。"

    scene kmr_pagi with dissolve
    play sound "sound/effects/walk.mp3"
    if girl:
        show p_side gl at pic
    else:
        show side_p g at pic
    mc "奖励？"
    if girl:
        hide p_side
    else:
        hide side_p
    play sound "sound/effects/doorslam.mp3"
    "他离开前没有给你进一步的解释。"
    if girl:
        show p_side y at pic
    else:
        show side_p k at pic
    mc "该死！"
    if girl:
        show p_side gl 
    else:
        show side_p g 
    mc "（好吧...我想我还是换衣服吧。）"
    if girl:
        hide p_side
    else:
        hide side_p
    "换衣服时，你注意到你的衣服散发着酒气。你昨晚不该喝那么多的。"
    play sound "sound/effects/cloth.mp3"
    "扣上扣子时，你注意到这件衣服确实很贴身，但并不是你穿过的最糟糕的东西。"
    if not girl:
        show palmier chill kind at center with dissolve:
            yoffset 100
    else:
        show femc skul smile at center with dissolve:
            yoffset 40
    mc "哦，还不错。我看起来很好，真的突出了我的腰部和胸部——"
    play sound "sound/effects/door.mp3"
    scene lyal_intro with flashbulb
    galleryunlock lyal_intro
    pause 1.0
    buff "..."
    "一个看起来很壮实的年轻男子从浴室里走了出来。"
    if girl:
        show p_side s at pic
        femc "（哇，他的胸比我的还大。）"
    else:
        "和他相比，你基本上就是个..."
        show side_p s at pic
        mc "...我是个土豆。一个瘦弱、干瘪、腐烂的土豆。"
    scene kmr_pagi with dissolve
    if not girl:
        show palmier chill confused at left with dissolve:
            yoffset 100
    else:
        show femc skul malu at left with dissolve:
            yoffset 40
    show buff confused sweat at right with dissolve:
        yoffset 770
    buff "呃，打扰一下。你是我的室友吗？"
    show buff sad
    if not girl:
        show palmier frown
    else:
        show femc frown
    if girl:
        show girl at horzappear
    else:
        show boy at horzappear
    menu:
        "看来是的。":
            hide girl
            hide boy
            if girl:
                femc talk "我叫[povname]，你呢？"
            else:
                mc smile"我叫[povname]，你呢？"
        "你是一年级新生？":
            hide girl
            hide boy
            buff keluh "啊，嗯...是的。怎么了？我的制服穿错了吗？"
            show buff sad
            if girl:
                femc panik sweat "你真的能穿进你的制服吗？"
                show femc bisnis -sweat
            else:
                mc eiden sweat "你真的能穿进你的制服吗？"
                show palmier malu -sweat
            buff frown -sweat sigh "不，呃，它太小了。这是我唯一能穿上它的方式，"
            if girl:
                femc smile "我猜也是。顺便说一下，我叫[povname]。"
            else:
                mc kind "我猜也是。顺便说一下，我叫[povname]。"
        "看看那些奶子！":
            hide girl
            hide boy
            buff eh apa "对不起，你说什么？"
            if girl:
                show buff frown -sweat -apa
                femc fluster blush "啊，抱歉。我是想说你看起来很棒。我叫[povname]。"
                femc bisnis -blush "（没想到会不小心说出口...）"
            else:
                show palmier scratch ha sweat shock
                show buff frown -sweat -apa
                mc scratch ha sweat "啊，抱歉。我是想说你看起来很棒。我叫[povname]。"
                mc "（没想到会不小心说出口...）"
                show palmier chill frown -sweat -shock
    buff keluh -sweat -sigh "哦，嗯，莱尔。莱尔·凯森。"
    if girl:
        femc complain apa "你一直都在浴室里吗？"
        show femc frown -apa
    else:
        mc deject scratch tanya "你一直都在浴室里吗？"
        show palmier chill frown -tanya
    buff sad sweat "是-是的，我在努力穿上制服，不想让任何人闯进来。"
    if girl:
        buff keluh blush "我没想到你会是个女孩，我以为他们只有同性宿舍。"
        show buff sad
        if not girl2:
            femc laugh sweat "实际上，尽管我的外表如此，我并不真的使用\'她/她的\'这样的代词，所以..."
            show buff eh -blush shock
            show femc bisnis
            buff keluh -shock "哦，好的。那我想我们没问题了。"
            show buff sad
        else:
            femc side sweat "（伙计，我和你一样困惑。）"
            femc grin "啊哈，是啊。也许你可以去和管理员谈谈这个问题。"
            buff sad -sweat "哦，好-好的。"
    buff keluh "呃，对不起，但是，你是[povname]·贝克，对吧？就是那个[povname]·贝克？"
    if girl:
        femc talk -sweat "是的...？"
        femc smile "（我的名字在这里有什么特别的含义吗？）"
    else:
        mc smile "是的...？"
        mc kind "（我的名字在这里有什么特别的含义吗？）"
    stop music
    buff sad "...哦，嗯，那么请，别杀我。"
    if girl:
        femc pain sweat shock "什么？"
    else:
        mc apa sweat shock "什么？"
    buff kzl sweat sigh "这不是我的错。我是说，我的血统。"
    if girl:
        femc complain apa"你的血统？"
    else:
        mc scratch sad tanya "你的血统？"
    scene kmr_pagi with dissolve
    show eye with dissolve
    "你直视着莱尔的眼睛。他的眼睛在光线下闪烁着如同明亮琥珀的光芒。"
    scene kmr_pagi with dissolve
    show buff sad at center with dissolve:
        yoffset 770
    if girl:
        show p_side f at pic
    else:
        show side_p f at pic
    mc "你的眼睛..."
    if girl:
        hide p_side
    else:
        hide side_p
    if girl:
        show girl at horzappear
    else:
        show boy at horzappear
    menu:
        "它们很美。":
            hide girl
            hide boy
            $ putri.points += 10
        "多么奇特的颜色。":
            hide girl
            hide boy
    buff confused sweat shock "什-什么？不！它们是——我-我得走了！"
    play sound "sound/effects/doorslam.mp3"
    scene kmr_pagi with vpunch
    "莱尔冲出了房间。"
    "是你说了什么吗？就在你思考的时候，奎尔给你发来了大量消息。"
    play music "MUSIC/MusMus-BGM-089.mp3"
    $ interlocutor = "Quill"
    $ del_all_msg()
    hide window
    show hp at move_messenger2
    pause 1.0
    $ show_messenger()
    $ click_to_continue = True
    $ msg ("好，快速回顾一下！", who=1, status='online')
    $ msg ("首先是[povname]的背景。", who=1)
    if girl:
        $ msg ("贝克家族拥有这片土地上最大的面包连锁店，而[povname]是大多数贵族眼中的新贵。", who=1)
        $ msg ("[povname]今年21岁，与这位巫师有契约关系。[kamu]曾经秘密约会了一两个月，然后决定在身心上永远结合。", who=1)
        $ msg (None, who=1, pic="crow")
    else:
        $ msg ("贝克家族拥有这片土地上最大的面包连锁店，而[povname]是大多数贵族眼中的新贵。", who=1)
        $ msg ("外表上，[povname]是个迷人的家伙。", who=1)
        $ msg (None, who=1, pic="bread")
        if girl2:
            $ msg ("每天早上看起来都像快死了，但我不得不说，[dia]的那种\'我受够了这些狗屁\'的表情真的很适合[dia]", who=1)
        else:
            $ msg ("每天早上看起来都像快死了，但我不得不说，[dia]的那种\'我受够了这些狗屁\'的表情真的很适合[dia2]", who=1)
        $ msg ("[povname]今年21岁，与这位巫师有契约关系。[kamu]曾经秘密约会了一两个月，然后决定在身心上永远结合。", who=1)
        $ msg (None, who=1, pic="crow")
    $ msg ("那个巫师到底是谁，她们不在巫师形态时长什么样？我不知道。", who=1)
    $ msg ("我自己也是在他们建立联系后才发现这个大秘密的", who=1)
    $ msg ("总之，[povname]有三个亲密的朋友", who=1)
    $ msg (None, who=1, pic="selfie")
    $ msg ("首先是我本人。奎尔·英克威尔，最大的猎巫组织\'乌鸦\'的继承人。", who=1)
    $ msg ("我从幼儿园就认识[nickname]了，我们的家族参加同样的聚会。虽然我承认，我的家族名声比[nickname]的更加显赫。", who=1)
    $ msg (None, who=1, pic="red_foto")
    $ msg ("接下来是塞恩·维拉什科夫。", who =1)
    $ msg ("除了我们的格斗老师维尔科娃女士外，他是学院里唯一的吸血鬼。", who=1)
    $ msg ("塞恩可能不是最聪明的，但在战斗中他绝对是你想要站在你这边的人。由于他的吸血鬼血统，科尔符文对他的反应有些不同。", who=1)
    $ msg ("科尔符文？你是说我梦中[povname]手上的图案？")
    $ msg ("没错。这些符号使我们能够施展类似于巫师的魔法。虽然能力较弱。", who=1)
    $ msg ("总之，吸血鬼有自己的教会和信仰，塞恩可以说是个局外人。但他的情况...很复杂。", who=1)
    $ msg (None, who=1, pic="selfie_tom")
    $ msg ("当然，还有阿什姆·涅弗斯。", who=1)
    $ msg ("我们班上的佼佼者，\'踩我吧老爹\'之王，也是你的前男友。", who=1)
    $ msg ("我的前任？我们为什么分手？")
    $ msg ("用[povname]自己的话说就是\'我不需要弱者\'。我猜[kamu]找到了比阿什姆更强大的人，很可能就是[kamu]开始约会的那个巫师。", who=1)
    $ msg ("哎呀。")
    $ msg ("\'哎呀\'都算是轻描淡写了。阿什姆当时崩溃了", who=1)
    $ msg ("如果我没记错的话，你们从初中就开始约会了。他本打算在毕业后向[nickname]提出灵魂绑定。", who=1)
    $ msg ("老实说，看着他放下好男孩的伪装，在校园里闷闷不乐的样子挺有意思的。", who=1)
    $ msg ("他一直在试图赢回你。说实话，这很可悲。不过看着挺有趣的。", who=1)
    $ msg ("还有其他问题吗？", who=1)
    $ my_events.append("intro_all")
    $ msg ("", choices={0:{'jump':'meet', 'name':"我们是怎么成为朋友的？"}, 1:{'jump':'sissy', 'name':"那我的奖励呢？"}})
label meet:
    python:
        msg ("我们是怎么成为朋友的？")
    $ msg ("嗯，对我来说，我猜你是被我的魅力迷住了。", who=1)
    $ msg ("阿什姆，我相信你们两个是在沙龙家族庄园的派对上认识的。因为某次生死经历而建立了联系之类的", who=1)
    $ msg ("这不重要。", who=1)
    $ msg ("如果你是问我们四个人是如何相处的，那么，你可以把这归咎于留堂。", who=1)
    $ msg (None, who=1, pic="sit")
    $ msg ("在菲亚的第一年，我们在抗议，要求允许女生在校园里穿短裙。", who=1)
    $ msg ("最后我们的抗议适得其反，禁止了女生和男生穿短裙。因为显然它们同样\'刺激\'。", who=1)
    $ msg ("但从那里开始，一段美好的友谊诞生了。", who=1)
    $ msg ("等等，那张照片里...那是菲亚，对吧？她在这里吗？！")
    $ msg ("当然。毕竟她就是你的奖励。", who=1)
    $ hide_messenger()
    hide hp
    show hp2 at move_messenger3
    pause 1.0
    scene kmr_pagi


    jump bro_knock

label sissy:
    python:
        msg ("那我的奖励呢？")
    $ msg ("我已经让她过去找你了，尽量别太激动。", who=1)
    $ hide_messenger()
    hide hp
    show hp2 at move_messenger3
    pause 1.0
    scene kmr_pagi


    jump bro_knock

label bro_knock:
    stop music
    play sound "sound/effects/window_knock.mp3"
    queue sound "sound/effects/door.mp3"
    show croissant at center with dissolve:
        yoffset 500
    fia "[nickname]，你在这里吗？"
    show croissant at right with move
    if girl:
        show femc skul panik at left with moveinleft:
            yoffset 40
        femc fluster shock "菲亚？！"
        show femc pain -shock
    else:
        show palmier sad at left with moveinleft:
            yoffset 100
        mc shock "菲亚？！"
    play music "MUSIC/MusMus-BGM-032.mp3"
    "你眨了眨眼，惊呆了。菲亚，你已故的妹妹就在这里，活生生的，走动着，呼吸着，{i}活着。{/i}"
    if girl:
        show femc wry with move:
            xalign 0.3
    else:
        show palmier smile -shock with move:
            xalign 0.3
    show croissant with move:
        xalign 0.6
    "你立即将菲亚拉入一个紧紧的、几乎要压碎骨头的拥抱中。"
    play sound "sound/effects/cloth.mp3"
    fia flinch gross sweat shock"哇哦！"
    if girl:
        femc laugh blush bunga "菲亚，菲亚！看看你，你在这里，你真的在这里！"
    else:
        mc happy blush bunga "菲亚，菲亚！看看你，你在这里，你真的在这里！"
    if not girl:
        mc hister bloom "你已经长成一个如此美丽的女人了！"
        fia err apa "...[nickname]。"
        play sound "sound/effects/bump.mp3"

    else:
        play sound "sound/effects/bump.mp3"
        fia mmh "我还能在哪里？呃，你快把我压扁了！"
    scene kmr_pagi
    if girl:
        show p_side s at pic
    else:
        show side_p s at pic
    mc "哎哟！" with vpunch
    if girl:
        hide p_side
    else:
        hide side_p
    show croissant flinch kzl frusta at center with dissolve:
        yoffset 500
    $ my_events.append("day_0")
    fia "你又嗑药了吗？这就是为什么那个英克威尔混蛋让我来找你？"
    fia gross sigh "我就知道母亲不该让你在他的庄园度过整个夏天！"
    fia def mad sweat -sigh "好吧，你嗑了什么？蘑菇？大麻？还是说，如果你这个夏天特别受虐的话，可能是致命魔药？"
    show croissant gross at right with move:
        yoffset 500
    if girl:
        show femc skul wry at left with moveinleft:
            yoffset 40
    else:
        show palmier kind at left with moveinleft:
            yoffset 100
    mc "我没嗑药！我只是..."
    if girl:
        femc grin blush "我只是真的很高兴见到你。你长大了。"
    else:
        mc happy blush "我只是真的很高兴见到你。你长大了。"
    fia laugh blush bloom "哦，你注意到了！两厘米，妈妈说只是头发的原因，但其实不是。我很清楚。"
    if girl:
        femc wry2 "是的，是的，你当然清楚。"
        femc senyum bunga"（菲亚一直对她的头发很讲究。她称之为她的皇冠荣耀。）"
    else:
        mc hister "是的，是的，你当然清楚。"
        mc kind bunga "（菲亚一直对她的头发很讲究。她称之为她的皇冠荣耀。）"
    fia flinch cringe sweat apa "呃，你为什么那样笑？"
    if girl:
        femc malu "哪样？我就不能开心一下吗？"
        show femc wry2 -blush -bunga
    else:
        mc malu "哪样？我就不能开心一下吗？"
        show palmier kind -blush -bunga
    fia mock def sigh -sweat "你从来不会开心，闷闷不乐先生。如果不是你的瞳孔，我还以为你又复吸开始嗑欣快剂了。"
    fia frown -sigh "不过你的皮肤看起来太健康了，不像是那样。简直健康得过分。"
    fia wry "哇，你什么时候开始照顾自己了？还是说这是那个英克威尔的功劳？"
    if girl:
        femc laugh sweat "呃...你可以这么说。"
    else:
        mc scratch avoid sweat "呃...你可以这么说。"
    fia ejek cling "那个被高估的荡夫怎么样了？"
    if girl:
        femc complain apa "荡夫？"
        show femc frown -apa
    else:
        mc confused tanya"荡夫？"
        show palmier frown -tanya
    fia pain sigh "哦，得了吧，闷闷不乐先生。连老师们都说他是个荡夫。好吧，他们是神父，我猜这就是他们会做的事，但还是。"
    fia annoyed -sigh "只要告诉我他没碰你的任何洞，我就不用去阉了那家伙。"
    if girl:
        femc fake -sweat -apa "呃，别担心。我很安全。"
        femc guilt sweat "（我想是吧？）"
        show femc frown -sweat
    else:
        mc chill huh -sweat -tanya "呃，别担心。我很安全。"
        mc panik sweat "（我想是吧？）"
        show palmier frown -sweat
    fia happy "很好。过去两天你没给我发短信，我有点担心，怕他说服你去嗨了什么的。"
    fia malu sigh "但你看起来还好。我猜你是认真的，说要振作起来。"
    fia laugh blush bunga "我很高兴。"
    scene kmr_pagi with dissolve
    play sound "sound/effects/cloth.mp3"
    "菲亚紧紧地拥抱了你，甚至她的香水味道也和你妹妹生前用的很像。"
    "你隐约听到她喃喃地说，\'我想你了\'。"
    "你细细品味这一刻，回忆起童年的美好时光。"
    if girl:
        play sound "sfx/ow_f.mp3"
    else:
        play sound "sfx/umph.mp3"
    "然后她狠狠地朝你肚子来了一拳。" with vpunch
    show croissant at center with dissolve:
        yoffset 500
    fia kerja "既然你没事，我们该去上课了。今天我有艾德娜女士的整体符文和魔药课。"
    fia smile "你在我这个年纪的时候上过她的课，对吧？有什么我该知道的吗？"
    show side_q skul smile at pic
    stop music
    play sound "sound/effects/door.mp3"
    quil "首先，她不喜欢那些爱拍马屁的万事通。"
    hide side_q
    show croissant mad at right with move:
        yoffset 500
    fia flinch jijik sweat "奎尔！" with vpunch
    play music "MUSIC/MusMus-BGM-102.mp3"
    show quil skul smile at left with moveinleft:
        yoffset 200
    quil ejek cling "菲亚。我听你母亲说你今年夏天没收到任何求婚者的信。看来还是个冷冰冰的处女啊。"
    fia annoyed ang "总比当个人尽可夫的荡夫强！"
    show croissant def mad sweat -ang
    quil flashy wink spark "至少我是受欢迎的，亲爱的。"
    quil sly cling "如果你把一半用在头发上的精力用在脸上，也许真能吸引到什么人。"
    quil mock sigh "虽然机会渺茫，但至少是个开始。"
    show quil sly -sigh
    fia gross -sweat frusta "呃！去死吧，奎尔。"
    show croissant mad -frusta
    play sound "sound/effects/shield.mp3"
    show kmr_pagi with flashbulb:
        subpixel True
        zoom 1.2 xpos 0.5 ypos 0.5 xanchor 0.5 yanchor 0.5 
        alignaround (.45, .45)
        linear 20 yalign 0.45 xalign 0.45 clockwise circles 1.2
        #repeat
    show quil rajuk shock
    if girl:
        show p_side s at pic
    else:
        show side_p s at pic
    mc "（怎么回事？）"
    if girl:
        hide p_side
    else:
        hide side_p
    show quil frown -shock
    "你感到房间在旋转。有种力量迫使你跪下，但你设法抵抗住了。"
    show kmr_pagi behind quil with dissolve:
        subpixel True
        truecenter zoom 1.0
        xalign 0.0 yalign 0.0
    quil skul cringe frusta "真的吗，菲亚？就因为你现在是三年级生了，并不意味着你可以随意使用符文魔法。"
    quil flashy laugh -frusta "还有个小提示。菲尔拉符文刻在喉咙后面效果最好，而不是脖子上。"
    show quil flashy datar with move:
        xalign 0.5
    quil "来，让我给你示范一下——"
    fia flinch kzl shock"别碰我！"
    show croissant jijik -shock
    play sound "sound/effects/door.mp3"
    hide croissant with moveoutright
    show quil tantrum -frusta
    "仿佛对奎尔的存在感到厌恶，菲亚迅速离开了房间。"
    show quil skul frown -sweat with move:
        xalign 0.0
    if girl:
        show femc skul grit sweat at right with dissolve:
            yoffset 40
    else:
        show palmier scratch apa sweat at right with dissolve:
            yoffset 100
    mc "那他妈是怎么回事？"
    if girl:
        show femc frown -sweat
    else:
        show palmier chill frown -sweat
    quil skul rajuk sigh "菲尔拉。这是一种能用施法者的声音催眠他人的符文。"
    quil talk -sigh "我很惊讶你能坚持住。"
    quil smile "也许你确实拥有[povname]的一些能力。"
    quil amused apa "无论如何，我想她的存在是你留下来的充分理由吧？"
    if girl:
        femc pain -sweat sigh "...但那还不是我的妹妹。"
    else:
        mc deject -sweat sigh "...但那还不是我的妹妹。"
    quil rajuk -apa "哦？"
    if girl:
        femc fluster -sigh "我妹妹不会说那么多脏话，也从不打人。但是...我还是会留下来。"
        femc yell frusta "你他妈早就知道只要她在这里我就会留下来，对吧？"
        show femc kzl -frusta
    else:
        mc chill frown -sigh "我妹妹不会说那么多脏话，也从不打人。但是...我还是会留下来。"
        mc rajuk frusta "你他妈早就知道只要她在这里我就会留下来，对吧？"
    quil flashy laugh cling "当然。我告诉过你我选择你是有原因的。"
    quil sly sigh "你是唯一一个失去妹妹而不是相反的[povname]。"
    if girl:
        femc yell shock "等等，什么？！"
        show femc panik sweat -shock
    else:
        mc grit shock "等等，什么？"
        show palmier confused sweat -shock
    quil skul panik sweat -sigh "没什么，没什么！"
    if girl:
        show femc kzl
    quil talk -sweat "总之，我已经把你的课程表发到你的手机上了。你的第一节课是迪特里希先生的黑暗符文课。"
    if girl:
        show femc frown
    quil datar "我的符文图形学课就在你隔壁。来吧，我带你去。"
    scene bg_black with w20
    jump sblm_kelas
label sblm_kelas:
    play music "MUSIC/MusMus-BGM-024.mp3"
    scene map_classes_crowd with w20
    show quil skul frown at center with dissolve:
        yoffset 200
    quil "别做笔记。"
    quil heh "更好的是，一坐下就睡觉。[nickname]以[dia]在课堂上的昏昏欲睡而闻名。"
    show quil frown at right with move:
        yoffset 200
    if girl:
        show femc panik shock sweat at left with moveinleft:
            yoffset 40
        femc yell -shock "等等，你就这样把我丢在这里，还指望我能融入进去？如果老师问我问题怎么办？！"
        show femc guilt -sweat
    else:
        show palmier confused shock sweat at left with moveinleft:
            yoffset 100
        mc -shock "等等，你就这样把我丢在这里，还指望我能融入进去？如果老师问我问题怎么办？！"
        show palmier kzl -sweat
    quil talk "他不会的，别担心。直到明天你都不会和阿什姆或塞恩一起上课，所以你可以稍微放松一下。"
    quil sly "记住：懒惰、冷漠、走到哪里都带着一种悲伤和沮丧的气息。这就是[povname]的全部。"
    if girl:
        femc bisnis sweat "呃...好吧。"
        femc guilt frusta "（在现实生活中我有那么阴郁吗？）"
        play sound "sound/effects/door.mp3"
        show femc frown -sweat -frusta
    else:
        mc rajuk sweat "呃...好吧。"
        mc apa tanya "（在现实生活中我有那么阴郁吗？）"
        play sound "sound/effects/door.mp3"
        show palmier frown -tanya
    "奎尔班上的老师似乎注意到了我们的谈话。"
    teach "今天要加入我们吗，奎尔？"
    quil flashy laugh "我绝不会错过的，先生。"
    if not girl:
        show palmier pissed frusta
    quil wink cling "再见，亲爱的！"
    scene map_classes_crowd with dissolve
    play sound "sound/effects/walk.mp3"
    if girl:
        show femc pain frusta at center with dissolve:
            yoffset 40
    else:
        show palmier pissed frusta at center with dissolve:
            yoffset 100
    "奎尔向你飞吻。你忍不住厌恶地畏缩了一下。"
    if girl:
        show femc fluster2 -frusta
    else:
        show palmier rajuk -frusta
    mc "（虽然我不想配合，但我现在有点进退两难，所以还是按他说的做吧。）"
    if girl:
        show femc frown
    else:
        show palmier frown
    mc "（希望我不会引起太多注意。）"
    stop music
    scene bg_black with w20
    scene kls_crowd with w20
    play music "MUSIC/MusMus-BGM-062.mp3"
    show priest charm at center with dissolve:
        yoffset 200
    dog "有三种诅咒符文你永远不应该尝试刻在皮肤上。谁能告诉我为什么？"
    dog chill "布莱恩小姐？"
    $ NPC = "布莱恩"
    npc "当符文完全形成的那一刻，你的器官就会腐烂。只有纯血巫师才能承受这种压力。"
    dog laugh "非常好。等价交换，这是科尔符文的基础。威廉校长建议我甚至不要向你们展示这些符文。"
    dog evil "但根据我的经验，有备无患总比贸然闯入未知世界要好。再说，只要你们不说，我也不会说。"
    dog hister "只是答应我不要在你们的前任身上使用这些，好吗？"
    show side_p he at pic
    mc "（这位神父似乎和学生们相处得很好。他看起来也太年轻了点，还是说在这个世界里情况不一样？）"
    show side_p s 
    show priest sly cling
    mc "（糟糕，他正盯着我看！）"
    hide side_p
    if girl:
        show girl at horzappear
    else:
        show boy at horzappear
    menu:
        "在课堂上睡觉。":
            hide girl
            hide boy
            "你假装睡觉，但最后真的睡着了。"
        "继续听课。":
            hide girl
            hide boy
            if girl:
                show p_side f at pic
            else:
                show side_p f at pic
            mc "（冷静点，[nickname]。保持冷静。）"
            if girl:
                hide p_side
            else:
                hide side_p
            dog chill -cling "塞勒姆之眼，"
            dog charm "赫卡特之蔷薇，"
            dog sly "以及犹大之星。"
            dog hister "现在，我不会告诉你它们各自的具体作用。"
            dog laugh "但我相信如果你在图书馆的禁书区转转，最终会找到几卷包含你所需全部信息的黑暗卷轴。"
            if "curses" not in topics:
                $ topics.append("curses")
                play sound "audio/success.mp3"
                "新话题：{color=#FF1500}黑暗诅咒。{/color}"
            dog chill "现在让我们来谈谈一些较为温和、不那么刺激的诅咒..."
            "你继续听着，但最终因为难以跟上而打起了瞌睡。"
    stop music
    scene bg_black with eye_shut
    if girl:
        if girl2 or kln:
            dog "贝克小姐？[povname]·贝克小姐？"
        else:
            dog "贝克先生？[povname]·贝克先生？"
    else:
        if girl2:
            dog "贝克小姐？[povname]·贝克小姐？"
        else:
            dog "贝克先生？[povname]·贝克先生？"
    scene kls with eye_open
    show priest charm at center with dissolve:
        yoffset 200
    if girl:
        show p_side s at pic
    else:
        show side_p s at pic
    play sound "sound/effects/cloth.mp3"
    mc "啊！" with vpunch
    if girl:
        hide p_side
    else:
        hide side_p
    dog ramah "恐怕课已经结束了。"
    if girl:
        show p_side s at pic
    else:
        show side_p s at pic
    mc "哦，呃，对不起——"
    if girl:
        hide p_side
    else:
        hide side_p
    dog chill "没关系。只要你能通过我的考试，在我的课上睡觉我也不介意。"
    dog ramah "我知道学校最后一年有实地猎巫训练，会让人感到疲惫。"
    dog evil "但还是要保持精神，好吗？"
    if girl:
        show p_side se at pic
    else:
        show side_p se at pic
    mc "好-好的。"
    if girl:
        hide p_side
    else:
        hide side_p
    dog chill "对了，你的朋友在门口等你。你不应该让他久等。"
    if girl:
        show p_side f at pic
    else:
        show side_p f at pic
    mc "哦，对。"
    play sound "sound/effects/walk.mp3"
    if girl:
        hide p_side
    else:
        hide side_p
    hide priest with dissolve
    show side_p he at pic
    mc "（我猜奎尔是来带我去下一节课的？）"
    hide side_p
    stop music
    scene bg_black with fade
    play sound "sound/effects/door.mp3"
    jump meet_Arshem

label meet_Arshem:
    scene map_classes1 with vpunch
    play sound "sound/effects/bump.mp3"
    if girl:
        show p_side m at pic
    else:
        show side_p m at pic
    mc "搞什么鬼——？！"
    play music "MUSIC/MusMus-BGM-054.mp3"
    if girl:
        hide p_side
        galleryunlock wall_g
        scene wall_g with fade:
            yalign 1.0
            easein 3.0 yalign 0.0
    else:
        hide side_p
        galleryunlock wall
        scene wall with fade:
            yalign 1.0
            easein 3.0 yalign 0.0
    "你刚走出教室，就被一双有力的手按在了墙上。抬头一看，一双闪烁的紫色眼睛正直视着你的灵魂。"
    "冷静下来后，你注意到那双引人注目的眼睛属于一个同样引人注目的年轻男子。"
    "你的胃里开始有蝴蝶飞舞的感觉。这是吸引力，还是你内心更原始的逃跑本能，尚不清楚。"
    scene map_classes1 with dissolve
    if girl:
        show femc panik at left with dissolve:
            yoffset 40
    else:
        show palmier confused at left with dissolve:
            yoffset 100
    show tom chill frown at right with dissolve:
        yoffset 190
    if girl:
        show girl at horzappear
    else:
        show boy at horzappear
    menu:
        "我能帮你吗？":
            hide girl
            hide boy
            if girl:
                show femc frown
            tom scold "你能。问题是，你愿意吗？"
            if flip_off:
                tom talk kzl "今天早上你对我竖中指。\'既往不咎\'这句话你忘了吗，[nickname]？"
                if girl:
                    femc side sweat "（啊...好吧，那是在我知道你是\'我的\'前任之前，所以...）"
                else:
                    mc scratch panik sweat "（啊...好吧，那是在我知道你是\'我的\'前任之前，所以...）"

            elif wink:
                tom talk smile "不过你今天早上似乎心情不错。"
                tom scold kzl "问题是为什么？"
                if girl:
                    femc malu sweat "啊，难道我就不能和前任稍微调情一下吗？就当是为了怀旧？"
                    femc laugh "（我他妈在说什么？）"
                else:
                    mc malu scratch sweat "啊，难道我就不能和前任稍微调情一下吗？就当是为了怀旧？"
                    mc eiden "（我他妈在说什么？）"


        "嗨，帅哥！":
            hide girl
            hide boy
            if not girl:
                show palmier kind
            else:
                show femc wry
            tom hip ha blow "...你嗑药了吗？"
            if girl:
                femc sad sweat "啊？"
            else:
                mc huh sweat "啊？"
            tom chill frown -blow "据我所知，你只有喝醉的时候才会说实话。"
            if girl:
                femc sarkas -sweat "所以我夸你是在说实话，而不是奉承？"
                show femc kzl
            else:
                mc ha -sweat "所以我夸你是在说实话，而不是奉承？"
            tom talk cruel "我的魅力是无可争议的事实，你不觉得吗？"
            if girl:
                femc fluster2 sweat "（我明白为什么他是前任了。）"
            else:
                mc panik sweat "（我明白为什么他是前任了。）"
        "把他推开":
            hide girl
            hide boy
            if girl:
                femc mean "阿什姆，难道没人教过你要尊重个人空间吗？"
                femc fluster2 sweat "（该死，他是阿什姆，对吧？还是塞恩？）"
            else:
                mc mock "阿什姆，难道没人教过你要尊重个人空间吗？"
                mc pissed sweat "（该死，他是阿什姆，对吧？还是塞恩？）"
            tom hip frown "你以前从不介意这个。"
            tom scold kzl "...你去哪儿了，[nickname]？"
    if girl:
        show femc frown -sweat
    else:
        show palmier frown -sweat
    tom hip capek "你失联好几天了。"
    tom talk frown "菲亚很担心。"
    if girl:
        show girl at horzappear
    else:
        show boy at horzappear
    menu:
        "菲亚还是你？":
            hide girl
            hide boy
            if not girl:
                show palmier chill
            else:
                show femc frown -sweat
            tom chill capek sweat "我们俩都很担心。她讨厌奎尔，而且从我今天看到他拉着你的手的样子来看，我开始同意她的看法了。"
            if girl:
                femc sarkas cling "吃醋了？"
                show femc frown shock
            else:
                mc mean cling "吃醋了？"
                show palmier frown shock
            tom talk kzl blow -sweat "显然是的。"
            if girl:
                femc laugh both -shock "哦-哦。"
            else:
                mc avoid both -shock "哦-哦。"
            $ ibu.likes = "你（[povname]）。"
            if girl:
                femc malu both "（哇，我没想到他会这么直白。他还对我有感觉吗？）"
                femc bisnis sweat "我们是{i}前任{/i}，对吧？"
                show femc wry2 -sweat
            else:
                mc side both "（哇，我没想到他会这么直白。他还对我有感觉吗？）"
                mc ha sweat "我们是{i}前任{/i}，对吧？"
                show palmier confused -sweat
            tom hip capek -blow frusta "你说得很清楚。但你也说过，我可以保留我的感情，想保留多久就多久。"
            tom talk pfft cling "而你很清楚，没有人比你更让我想要。"
            if girl:
                femc laugh both "是、是这样吗？啊哈哈哈..."
            else:
                mc scratch hister both "是、是这样吗？啊哈哈哈..."
                show palmier ha
            mc "（天哪，这家伙真是个麻烦，不是吗？）"
            tom scold frown -cling "..."
        "差不多吧。":
            hide girl
            hide boy
            if girl:
                show femc frown
            else:
                show palmier chill
            tom hip capek blow "真是无礼。"
            if girl:
                femc kzl "什么？"
            else:
                mc kzl "什么？"
            tom scold kzl -blow "你平时可不是这么活泼的。讽刺倒是有，但是... 活泼开朗？不会。而且..."
        "和奎尔在一起。":
            hide girl
            hide boy
            if not girl:
                show palmier chill
            else:
                show femc frown -sweat
            tom hip kzl blow "哼，奎尔。我还是不明白你为什么选择和他一起度过整个夏天。"
            tom scold ha frusta "你们两个没有... 睡在一起吧？"
            if girl:
                femc sarkas apa "如果我们睡了呢？"
                show femc panik shock
            else:
                mc mean tanya "如果我们睡了呢？"
                show palmier apa shock
            tom talk capek shock "对不起，我得去杀个人——"
            if girl:
                femc sad sweat -shock "等、等等！我们什么都没做，好吗？"
                femc guilt "（至少\'我\'没有。）"
                femc yell -sweat "再说，即使我做了，那也不关你的事。我们已经分手了，记得吗？！"
                show femc frown
            else:
                mc ow sweat -shock "等、等等！我们什么都没做，好吗？"
                mc panik "（至少\'我\'没有。）"
                mc ha "再说，即使我做了，那也不关你的事。我们已经分手了，记得吗？！"
            tom chill frown -shock "你说得很清楚。但你也说过，我可以保留我的感情，想保留多久就多久。"
            tom talk kzl "而你很清楚，没有人比你更让我想要。"
            if girl:
                femc laugh both "是、是这样吗？啊哈哈哈..."
                femc fluster2 frusta "（天哪，我不知道该如何反应。这家伙有点激动。）"
            else:
                mc smile both "是、是这样吗？啊哈哈哈..."
                mc ow scratch "（天哪，我不知道该如何反应。这家伙有点激动。）"
            tom scold frown "..."
    if girl:
        show femc frown sweat -frusta
    else:
        show palmier chill frown sweat
    tom "你看起来不一样了。你知道吗？"
    if girl:
        femc talk apa"哦、哦？"
        show femc frown -sweat -apa
    else:
        mc scratch confused -sweat tanya "哦？"
    tom chill frown "更健康了。看起来休息得很好。"
    show tom talk smile with move:
        xalign 0.2
        yoffset 190
    if girl:
        show femc grit shock:
            yoffset 40
    else:
        show palmier chill ow both shock:
            yoffset 100
    play sound "sound/effects/cloth.mp3"
    tom amused "你在我眼里一直都很美，但现在..."
    scene map_classes1 with dissolve
    play sound "sound/effects/walk.mp3"
    show priest ramah at left with moveinleft:
        yoffset 200
        xzoom -1.0
    if girl:
        show femc side both with dissolve:
            xalign 0.75
            yoffset 87
    else:
        show palmier side both with dissolve:
            xalign 0.75
            yoffset 30
    show tom talk frown -cling at right with dissolve:
        yoffset 190
    stop music
    dog "咳咳。"
    show tom hip
    $ ibu.desc = "据说是你\'核心圈子\'的领导。看起来对你有点占有欲。"
    if girl:
        show femc frown -both shock at center with move:
            yoffset 30
    else:
        show palmier frown -both shock at center with move:
            yoffset 100
    dog chill "很抱歉打断你们两个的时刻，但你们不是应该去上课了吗？"
    tom wry spark "哦，迪特里希先生。很抱歉让您看到这样的场景。"
    if girl:
        show femc sad -shock
        mc "啊？"
    else:
        show palmier scratch confused -shock
        mc tanya "啊？"
    show tom calm -spark
    if girl:
        femc frown "（这个人就像按下了开关。刚才还一脸怒容和锐利的眼神？）"
    else:
        mc -tanya "（这个人就像按下了开关。刚才还一脸怒容和锐利的眼神？）"
    show tom smile cling
    mc "（现在却是温暖的微笑和柔和的声音。这就是奎尔提到的乖孩子伪装吗？）"
    dog glad "没关系。我理解年轻人的爱情和随之而来的激烈荷尔蒙，哈哈。"
    dog charm "不过，你们最好现在就出发。"
    show tom frown -cling
    if girl:
        show femc laugh both shock
    else:
        show palmier chill hister both shock
    mc "对。那么，我可不想迟到！"
    if girl:
        hide femc with moveoutleft
    else:
        hide palmier with moveoutleft
    stop music
    play sound "sound/effects/tile.mp3"
    scene out_court_crowd with dissolve
    "你朝着与阿什姆相反的方向匆匆离开了。"
    show side_p he at pic
    mc "（现在最好避开他。至少在我能很好地掌握这个其他[povname]的性格之前。）"
    hide side_p
    if girl:
        show p_side s at pic
    else:
        show side_p s at pic
    mc "所以，我的下一节课是... 啊，等等，糟了！我的手机，是不是掉在教室里了？我最好去看看。"
    play sound "sound/effects/walk.mp3"
    scene papan with dissolve
    "当你走回教室时，你注意到门微微敞开，一个惊慌失措的声音从房间里传出来。"
    $ NPC = "学生"
    show npc2_2 at pic
    npc "先生，这一定是个错误！" with vpunch
    hide npc2_2 at pic
    mc "（嗯？迪特里希先生还在和学生谈话吗？）"
    play music "MUSIC/MusMus-BGM-049.mp3"
    show priest side at center with dissolve:
        yoffset 200
    dog "我不会犯错，塔图姆小姐，尤其是在涉及金钱的事情上。"
    $ NPC = "塔图姆"
    if girl:
        show p_side s at pic
    else:
        show side_p s at pic
    mc "（等等，什么？！）"
    if girl:
        hide p_side
    else:
        hide side_p
    dog grin "你知道我们的交易。你给我钱，我就确保不会让你这个可怜虫挂科。这就是我的条件。"
    show npc2 at pic
    npc "我无法支付你，因为这比我们约定的金额高得多！"
    hide npc2
    dog side "时代在变，年轻的塔图姆。通货膨胀，物价上涨，你懂的。"
    dog grin "当然，我也可以把我们谈过的那些照片发给你父母？"
    dog "我敢说你家人会觉得你的卧室活动... 至少很有趣。"
    show npc2_2 at pic
    npc "等、等等！我相信我们可以想出办法，只要——只要再给我一些时间！"
    hide npc2_2
    dog side "时间就是金钱，塔图姆小姐。但我很仁慈，所以... 你有24小时的时间给我汇款。"
    show npc2_2 at pic
    npc "24小时？！这——"
    hide npc2_2
    dog grin "或者... 如果我没记错的话，你家继承了一枚稀有的赫莱因诅咒戒指。我相信那在我的店里能卖个好价钱，不是吗？"
    show npc2 at pic
    npc "你要我偷它？但那是——"
    hide npc2
    dog bleh "我的意思是，我可以让你挂科，或者让我的猎犬召唤物把你的肾脏撕出来卖掉。你自己选吧。"
    show npc2_2 at pic
    npc "不！我是说，不！我会做的！谢、谢谢您的仁慈，先生。"
    hide npc2_2
    dog grin "不用客气。哦，还有，塔图姆小姐..."
    show npc2 at pic
    npc "是？"
    hide npc2
    dog evil "如果你想用赝品骗我，我的猎犬会把你的胸撕下来。明白了吗？"
    show npc2_2 at pic
    npc "明、明白了！"
    hide npc2_2
    play sound "sound/effects/tile.mp3"
    scene map_classes1 with dissolve
    "塔图姆匆忙从上面的出口溜走了。你也应该在——"
    stop music
    play sound "sound/effects/growl.mp3"
    if girl:
        galleryunlock wolves_f
        show wolves_f at center:
            truecenter zoom 0.0
            linear 1.0 truecenter zoom 1.0
    else:
        galleryunlock wolves
        show wolves at center:
            truecenter zoom 0.0
            linear 1.0 truecenter zoom 1.0
    $ renpy.pause()
    "就在你想逃走之前，迪特里希先生打了个响指。"
    "一群狼从他的指尖冒出，瞬间将你包围。起初，你以为它们只是幻觉。"
    "但是，感受到锋利的獠牙和爪子擦过你的腿，足以让你打消这种一厢情愿的想法。"
    scene papan with dissolve
    show priest side at center with dissolve:
        yoffset 200
    play music "MUSIC/Action-Rhythm-4.mp3"
    dog grin "偷听可是很不礼貌的，年轻的[povname]。"
    if girl:
        show p_side m at pic
    else:
        show side_p m at pic
    mc "你知道我在这里？！"
    if girl:
        hide p_side
    else:
        hide side_p
    dog evil "我知道很多事，[povname]。那些你拼命想隐藏的事。"
    dog grin "我一直在等待何时该在你面前卸下伪装。"
    dog sly "坦白说，我原本计划在你22岁生日获得家族遗产后{i}再{/i}逼你就范。"
    dog charm "这是我的退休计划。不过没关系，毕竟没有什么比当下更重要。"
    if girl:
        show p_side f at pic
    else:
        show side_p f at pic
    mc "你的退休计划？"
    if girl:
        hide p_side
    else:
        hide side_p
    dog evil "我知道你的秘密。"
    scene papan with vpunch
    play sound "sound/effects/punch.mp3"
    dog "你的巫师契约！"
    stop music
    play sound "sound/effects/cloth.mp3"
    "他用力拉下你的手套，露出你赤裸的双手。然而，他似乎对看到的东西并不满意。"
    show priest side at center with dissolve:
        yoffset 200
    dog pissed "什么？"
    dog sad "它在哪里？！它他妈的在哪里？！"
    dog pissed "我的退休计划！我的钱……你是……"
    dog side "你不是[povname]，对吧？"
    if girl:
        show p_side s at pic
    else:
        show side_p s at pic
    mc "我当然是，我还能是谁？"
    if girl:
        hide p_side
    else:
        hide side_p
    dog pissed "不，你不是。我了解[povname]就像了解自己的手背一样。你的眼睛，充满希望和喜悦。"
    dog "完全不像[povname]那种毫无生气的眼神！[povname]在哪里？！我的退休计划在哪里？！"
    if girl:
        show p_side m at pic
    else:
        show side_p m at pic
    mc "喂！冷静，冷静！听着，我和你一样一头雾水。奎尔——"
    if girl:
        hide p_side
    else:
        hide side_p
    dog bleh "当然，奎尔。那个该死的婊子！"
    dog kzl "你跟我来！"
    play sound "sound/effects/tile.mp3"
    scene bg_black with fade
    scene map_classes with dissolve
    show quil skul smile at left with moveinleft:
        yoffset 200
    show priest side at right with moveinright:
        yoffset 200
    stop sound
    quil flashy laugh "哦，[povname]和迪特里希先生。怎么了？有什么我能帮忙的吗？"
    show quil datar
    dog kzl "[povname]在哪里，奎尔？"
    quil skul amused apa "先生？"
    if girl:
        dog bleh "[povname]，真正的那个。你和你那四人组这次又搞了什么鬼？"
    else:
        dog bleh "[povname]，真正的那个。你和你那四个娘娘腔这次又搞了什么鬼？"
    quil panik sweat -apa "先生，恕我直言，[povname]就在这里——"
    show quil frown
    dog pissed "我知道巫师契约的事，你这小兔崽子。这个人手上没有印记！"
    if girl2:
        quil grit frusta "唉……我就知道你发现了[dia]。"
    else:
        quil grit frusta "唉……我就知道你发现了[dia2]。"
    quil tantrum sweat sigh "不过我想如果有人能帮忙的话，那就是你了。跟我来。"
    if girl:
        scene mayat_g with dissolve
    else:
        scene mayat with dissolve
    "你和奎尔护送迪特里希先生回到真正的[povname]的身边。他自己做了一些检查，然后深深叹了口气，靠了回去。"
    scene qpt with dissolve
    play music "MUSIC/MusMus-BGM-084.mp3"
    show quil skul rajuk at left with moveinleft:
        yoffset 200
    show priest pissed at right with moveinright:
        yoffset 200
    dog "昏迷……而且不是普通的昏迷，是完全的灵魂封印昏迷。哈……是哪个巫师干的？"
    quil frown sweat "维拉。伊瓦尔的一个女儿。"
    dog side frusta "当然是她。在那群混蛋中，你偏偏惹上了最厉害的那个，是不是？"
    dog kzl -frusta "那么，维拉死了吗？"
    quil flashy sly -sweat cling "当然，我们——"
    show quil skul sad shock
    dog bleh "别自鸣得意，你这个白痴！你他妈刚杀了这片土地上最强大的大巫师的女儿！你他妈脑子有问题吗？！"
    quil panik sweat -shock "说实话，问题多着呢。但恕我直言，要么是她，要么是我们。"
    show quil sulk frusta
    dog sad sigh "哈……"
    show quil frown -frusta
    if girl:
        show girl at horzappear
    else:
        show boy at horzappear
    menu:
        "真的有那么糟糕吗？":
            hide girl
            hide boy
            dog bleh -sigh "上次伊瓦尔发怒时，他毁灭了一整个国家。糟糕都是轻描淡写了！"
            dog sad frusta "在所有大巫师中，为什么偏偏是他？！"
            show priest side -frusta
            if girl:
                show p_side s at pic
            else:
                show side_p s at pic
            mc "大巫师们？"
            if girl:
                hide p_side
            else:
                hide side_p
        "大巫师？":
            hide girl
            hide boy



        "我什么都不知道。":
            hide girl
            hide boy
            dog side -sigh "显然。你甚至能使用科尔符文吗？她的祝福墨水对你有反应吗？"
            quil bingung sweat "我们还没试过，但我不觉得有什么问题。"
            show quil rajuk -sweat
            dog sad frusta "亲爱的科尔..."
            show priest sad -frusta
            if girl:
                show p_side f at pic
            else:
                show side_p f at pic
            mc "我一直听到关于科尔的事，她是谁？"
            if girl:
                hide p_side
            else:
                hide side_p
            dog side "她是所有魔法的母亲。我们的救世主。"
            dog sad "她是一位怜悯人类的巫师，教导我们魔法来抵御那些敌对的巫师。"
            dog kzl "当我们在手上画她的符文时，就能使用魔法。不过这确实有一些后果。"
            dog "人类的身体无法像巫师那样承受魔法。长期使用会导致身体衰败。从指尖开始。"
            dog side "如果科尔还活着，她可能已经完善了没有副作用的符文。可惜的是，她在几个世纪前被大巫师们杀死了。"
            if girl:
                show p_side s at pic
            else:
                show side_p s at pic
            mc "大巫师们？"
            if girl:
                hide p_side
            else:
                hide side_p
    dog side -sigh "统治某些领域的纯血巫师。目前这片土地上有四位在世的大巫师。"
    show greed at left with moveintop
    dog "贪婪巫师、"
    show greed2 at left with moveinbottom
    extend "变化巫师、"
    show greed3 at right with moveintop
    extend "幻想巫师、"
    show greed4 at right with moveinbottom
    extend "以及美丽巫师——厌男者伊瓦尔。"
    hide greed2
    hide greed3
    hide greed4
    hide greed with dissolve
    dog "以美貌和脾气闻名的伊瓦尔曾经将三百万人变成了一片永不凋零的花田。"
    if girl:
        show p_side f at pic
    else:
        show side_p f at pic
    mc "花？"
    if girl:
        hide p_side
    else:
        hide side_p
    dog pissed sigh "听起来很平和，对吧？但并非如此。"
    dog side -sigh "那是种折磨。枝条刺穿你的器官，荆棘从内到外刺伤你..."
    dog kzl "...那些被他变成花的人，他们仍然活着。当你摘下那些花时，它们会流血。"
    dog pissed "它们会哭泣。即使在最干燥的季节，它们的花瓣也湿润着露水。"
    dog side "研究人员发现它们仍能感受到饥饿、疼痛和口渴。它们保留了所有的感官和记忆。然而它们无法满足任何需求。"
    dog "每次你碾碎它们，试图给予它们仁慈——它们会流血，然后重新生长。一种被诅咒的不朽。"
    dog pissed "而你杀了他的女儿。"
    if girl:
        show p_side m at pic
    else:
        show side_p m at pic
    mc "如果他那么坏，为什么你们不去猎杀他？你们不是猎巫人吗？"
    if girl:
        hide p_side
    else:
        hide side_p
    dog side sigh "不是我们没试过。你以为是什么引发了死亡地带战争？"
    dog kzl frusta "我们有那么多人死在试图杀死他们的过程中。最后他们赢了，现在科尔才知道他们在做什么，在科尔知道的什么地方！"
    dog bleh -frusta "我会和任何有高额赏金的巫师战斗，但大巫师们？绝对不行！"
    dog pissed frusta "尤其是伊瓦尔！"
    quil flashy ejek -sweat frusta "是的，是的，他是个非常可怕但又非常性感的男人。那么，你知道怎么治好[nickname]吗？"
    show priest kzl -frusta
    show quil frown -frusta
    if girl2:
        dog sad "我知道，但这是无望的。据我所知，只有一种方法可以治愈[dia]。以心换心。"
    else:
        dog sad "我知道，但这是无望的。据我所知，只有一种方法可以治愈[dia2]。以心换心。"
    if girl:
        show p_side f at pic
    else:
        show side_p f at pic
    mc "什么？"
    if girl:
        hide p_side
    else:
        hide side_p
    quil skul bingung sweat apa "你是说，巫师的心脏？有这样的仪式吗？为什么我以前从未听说过？"
    show quil rajuk -apa
    dog side "只有最黑暗的诅咒卷轴才有任何记录。幸运的是，我的店里正好有售。"
    dog grin cling "当然，是要付费的。"
    quil flashy ejek -sweat cling "开个价吧。钱对我来说无所谓。"
    show quil amused -cling
    dog pissed frusta "不愧是现存最富有的家族。该死的被宠坏的英克威尔小鬼！"
    show quil rajuk
    dog sad sigh "哈...我本来很期待能勒索你的。"
    dog side -sigh "首先，我本该勒索[povname]，然后是你。因为我知道你他妈的一定会参与进来，然后我终于可以放下我作为圣洁牧师的伪装。"
    dog sad "我本可以退休的。在南维斯卡的沙滩上，在美女的环绕之中。"
    quil amused sigh "帮我弄到一颗巫师的心脏，我可能就能让你实现这个梦想，老头。"
    dog side "傻瓜，不是随便哪个巫师的心脏！被诅咒的仪式使用四换一规则。而且必须是等价交换！"
    if girl2:
        dog pissed "我知道这个混蛋设法与一个纯血巫师建立了联系。所以如果你想唤醒[dia]，你需要4颗同样强大的纯血巫师的心脏。"
    else:
        dog pissed "我知道这个混蛋设法与一个纯血巫师建立了联系。所以如果你想唤醒[dia2]，你需要4颗同样强大的纯血巫师的心脏。"
    if girl:
        show p_side s at pic
    else:
        show side_p s at pic
    mc "四颗心脏，但那意味着..."
    if girl:
        hide p_side
    else:
        hide side_p
    quil skul sulk -sigh "...所有的大巫师。包括伊瓦尔的。哦，天哪..."
    quil flashy hister blush bunga "...多有趣啊！我终于有理由亲自去见那个传奇性感偶像了！"
    show side_p he at pic
    mc "（搞什么鬼？）"
    hide side_p
    quil flashy wink cling -blush "好吧，就把所有可能有帮助的卷轴都卖给我，然后算一下我的账单，好吗，迪特里希先生？请快点，我马上就要上课了。"
    dog grin "哈！你真以为你能打败四大巫师，你这个小鬼？连我们的校长都无法击败伊瓦尔。"
    if girl:
        dog kzl "你和你的朋友们根本没有机会。尤其是现在你们的四人组变成了三人组。"
    else:
        dog kzl "你和你那群娘娘腔的四人组根本没有机会。尤其是现在你们已经只剩下三个人了。"
    quil flashy laugh spark "我会想办法的。再说了，我可是英克威尔家族的人，记得吗？创造奇迹是我们的专长。"
    show quil smile -spark
    dog grin "呵，随你便。这是你自己的葬礼。在你不幸身亡之前，我很乐意卖给你任何你需要的材料。"
    dog charm "我甚至会帮你找到关于那些巫师的情报。就当是对我最忠实顾客的特殊服务吧。"
    if girl:
        show p_side m at pic
    else:
        show side_p m at pic
    mc "等等，你真的要这么做？认真的吗？"
    if girl:
        hide p_side
    else:
        hide side_p
    quil wry sigh "如果这是唯一能把[nickname]带回来的方法，那么是的。再说，我不能让菲亚失去她的[kk]。"
    quil cringe sweat -sigh "那个女人已经够讨厌我的了。我无法想象如果她珍贵的[povname]死了，我会遭遇什么。"
    show quil panik skul
    if girl:
        show p_side s at pic
    else:
        show side_p s at pic
    mc "哦，对了。菲亚……"
    
    stop music
    if girl2:
        mc "（没错。这个菲亚还有她的[kk]，但如果她失去了[dia]的话那……）"
    else:
        mc "（没错。这个菲亚还有她的[kk]，但如果她失去了[dia2]的话那……）"
    if girl:
        show p_side s 
    else:
        show side_p s 
    mc "……那她就会责备自己。陷入无休止的\'如果当初\'的循环中。"
    if girl:
        hide p_side
    else:
        hide side_p
    quil amused -sweat apa "嗯？你说什么了吗？"
    if girl:
        show girl at horzappear
    else:
        show boy at horzappear
    show quil frown -apa
    menu:
        "让我来帮忙吧！":
            hide girl
            hide boy
            if girl:
                show p_side m at pic
            else:
                show side_p m at pic
            mc "我想帮忙！"
            if girl:
                show p_side s
            else:
                show side_p s
            mc "让我帮菲亚和她真正的[kk]重聚吧！"
        "我不会让她经历我的命运。":
            hide girl
            hide boy
            if girl:
                show p_side s at pic
            else:
                show side_p s at pic
            mc "当我失去妹妹时，我……我曾想过去陪她。她的死是我的错。"
            if girl:
                show p_side m
            else:
                show side_p m
            mc "然而，活下来的人是我。我总是在想，如果情况反过来会怎样。"
            if girl:
                show p_side s
            else:
                show side_p s
            mc "但是……我不想让她经历相反的情况！我想看到一个我们两个人作为兄妹并肩生活的世界！"
    if girl:
        show p_side m
    else:
        show side_p m
    mc "如果我必须在手上画符文或者失去一条手臂来对抗那些巫师，那就这样吧！"
    mc "让我赎罪吧！让我为这个世界的菲亚做这件事！"
    if girl:
        show p_side s
    else:
        show side_p s
    mc "……如果我不尝试的话，我想我无法原谅自己。"
    if girl:
        hide p_side
    else:
        hide side_p
    quil skul amused cling "呵。你们两个真的很像。你和你那令人难以忍受的妹妹情结。"
    play music "MUSIC/MusMus-BGM-146.mp3"
    quil talk -cling "但别担心，亲爱的。反正我本来就打算以这样或那样的方式让你参与进来。"
    quil frown apa "不过，你确定吗？老实说，我以为你会满足于简单地取代她的[povname]的位置。"
    show quil frown -apa
    if girl:
        show p_side m at pic
    else:
        show side_p m at pic
    mc "当然不是！"
    if girl:
        show p_side s
    else:
        show side_p s
    mc "（我不配享受那种奢侈。）"
    if girl:
        show p_side m
    else:
        show side_p m
    mc "再说，妈妈正在家里为我做我最喜欢的饭菜。一旦[povname]醒来，你就会把我送回我的世界，对吧？"
    if girl:
        hide p_side
    else:
        hide side_p

    quil flashy wry sigh "当然。这个世界不需要两个你。一个已经太多了。"
    show quil rajuk -sigh
    dog side "如果是我的话，我会假装享受这一切。但我忘了常识是一种祝福，所以……"
    dog charm "……很高兴认识你，假[povname]。如果你需要什么，我相信我的商店可以提供。"
    play sound "sound/effects/walk.mp3"
    hide priest with moveoutright
    if girl:
        show femc side apa at right with moveinright:
            yoffset 40
    else:
        show palmier apa tanya at right with moveinright:
            yoffset 100

    mc "商店？"
    stop sound
    if girl:
        show femc frown -apa
    else:
        show palmier frown -tanya
    quil skul tantrum frusta "黑市。说实话，他是校园里唯一愿意卖东西给我的人。"
    quil sly sigh "校园里大多数商贩都不再接受我的钱了。"
    if girl:
        femc panik sweat "什么，为什么？"
        show femc frown -sweat
    else:
        mc rajuk scratch "什么，为什么？"
        show palmier chill sad sweat
    quil flashy laugh cling "你想知道吗？不过这倒是提醒了我，你现在是自由的，对吧？既然迪特里希先生让你逃课了。"
    if not girl:
        show palmier frown -sweat
    quil talk apa "亲爱的，你能帮我去买两瓶符文墨水吗？"
    show quil datar -apa
    $ add_new_quest("sugar1")
    python:
        if len(new_quests) > 0: #if we have new quests
            for i in new_quests:
                active_quests.insert(0, i) #add to top of the quest list
            new_quests = [] #now reset the new quest list, since they all got added
    if not girl:
        mc scratch side tanya "符文墨水？"
        show palmier chill frown -tanya
    quil wink -tanya "主门附近的商店有卖，这些钱应该足够了。"
    $ gold +=10
    "获得了10金币！"
    if girl:
        femc sarkas "只有10金币，你不是很富有吗？"
        show femc kzl frusta
    else:
        mc huh sweat "只有10金币，你不是很富有吗？"
        show palmier confused -sweat
    quil skul ejek cling "你不知道财富和吝啬是形影不离的吗？"
    if girl:
        show femc frown -frusta
    quil laugh -cling "去吧，顺便探索一下校园。"
    quil talk "我会在{color=#ff0000}宿舍二楼的走廊{/color}等你，或者你也可以直接通过手机上的任务应用提交材料。"
    if girl:
        femc complain shock "等等，你可以通过手机发送实物？"
    else:
        mc apa shock "等等，你可以通过手机发送实物？"
    quil mock apa "你不能吗？天啊，你生活在一个多么落后的世界啊。"
    if girl:
        show femc kzl sweat frusta
    else:
        show palmier kzl sweat frusta
    quil panik sigh "我为你感到遗憾。"
    if girl:
        show femc frown -frusta
    else:
        show palmier frown -frusta
    quil flashy wink cling "总之，今晚见。记住，宿舍二楼的走廊，别让我等太久！"
    play sound "sound/effects/walk.mp3"
    hide quil with moveoutleft
    if girl:
        femc guilt -sweat sigh "（……真是个爱使唤人的家伙，不是吗？）"
    else:
        mc ew -sweat sigh "（……真是个爱使唤人的家伙，不是吗？）"
    $ NPC = "???"
    scene bg_black with w20
    stop sound
    if "bunga_bego" in buff_events:
        if "beku" in quil_events:
            scene map_infected_f with w20
        else:
            scene map_infected with w20
    else:
        if "beku" in quil_events:
            scene map_frozen with w20
        else:
            scene map_all with w20
    jump world_map

label inky:
    $ afternoon = False
    $ evening = True
    play music "MUSIC/MusMus-BGM-004.mp3"
    scene bg_black with w20
    scene lorong_night with w20
    show quil flashy talk at center with dissolve:
        yoffset 200
    quil "晚上好。我一直在等你。"
    if "sugar1" not in completed_quests:
        quil skul heh apa "你拿到我需要的东西了吗？"
        show quil sly -apa
        if girl:
            show girl at horzappear
        else:
            show boy at horzappear
        menu:
            "给予墨水" if check_inv_for(ink_items):
                hide girl
                hide boy
                python:
                    InvItem(*item_lead).toss(1)
                    active_quests.remove("sugar1")
                    completed_quests.insert(0, "sugar1")
                show screen completedtask("任务完成！")
                quil hister "哎呀，谢谢你！"
                quil wink flashy cling "这是给你亲自送来的小费。"
                show quil smile -cling
                show quil
                $ gold += 10
                $ InvItem(*item_cook).pickup(1)
                if check_inv_for(recipe_items):
                    $ known_recipes.extend(["item_bread","item_coco","item_caramel"])
                    $ known_recipes.append("item_catfood")
                if girl:
                    show p_side f at pic
                else:
                    show side_p f at pic
                mc "这是什么？"
                if girl:
                    hide p_side
                else:
                    hide side_p
                quil skul amused "一个烹饪卷轴，应该能教你所有关于基础烹饪配方的知识。"
                quil laugh "[nickname]以前喜欢烹饪，我想你也会一样。"
                show quil datar
                if girl:
                    show p_side f at pic
                else:
                    show side_p f at pic
                mc "嗯，其实我确实喜欢。谢谢。话说你要墨水做什么？"
                if girl:
                    hide p_side
                else:
                    hide side_p
                quil panik sweat "哦，你知道的...做实验。"
                quil flashy talk -sweat"哦，还有这个。你需要一个属于自己的。符文最好是自己画的才有效。"
                if girl:
                    show p_side m at pic
                else:
                    show side_p m at pic
                mc "等等，我也需要用它们吗？"
                if girl:
                    hide p_side
                else:
                    hide side_p
                #$ InvItem(*item_lead).pickup(1)
                quil laugh "是的，今晚你需要它来画自己的保护符文。"
                show quil smile

            "不给他":
                hide girl
                hide boy
                if girl:
                    show p_side f at pic
                else:
                    show side_p f at pic
                mc "还没有。"
                if girl:
                    hide p_side
                else:
                    hide side_p
                $ active_quests.remove("sugar1")
                show screen completedtask("任务失败")
                quil err frusta "嗯，不太擅长遵守指示，是吗？不过[nickname]也是这样。我应该找红色的。"
                
                quil frown skul sigh "不过，这里有些剩余的墨水给你。不过只够画一个符文。"
                if girl:
                    show p_side f at pic
                else:
                    show side_p f at pic
                mc "嗯？什么，所以你要墨水是给我的？"
                if girl:
                    hide p_side
                else:
                    hide side_p
                quil mock -sigh "我确实要了两份，本来是我们每人一份的。"
                quil laugh "你今晚需要它来画自己的保护符文。"
                show quil smile
    else:
        quil skul laugh "谢谢你的墨水。"
        quil talk "这是你的份。"
        mc "我的份？"
        $ InvItem(*item_lead).pickup(1)
        quil smile "你今晚需要它来画保护符文。"
    if girl:
        show p_side f at pic
    else:
        show side_p f at pic
    mc "保护符文？"
    if girl:
        hide p_side
    else:
        hide side_p
    quil mock sigh "隐私是一种奢侈品，即使在我们的梦中也是如此。在自己身上画这个符文，除非你想让巫师今晚造访你的梦境。"
    quil kzl shock "只要照着我在这里画的复制就行。另外，千万不要在拇指上画。"
    if girl:
        show p_side f at pic
    else:
        show side_p f at pic
    mc "为什么？"
    if girl:
        hide p_side
    else:
        hide side_p
    quil sulk sweat -shock "符文腐蚀。过度使用符文会使手部腐烂。失去其他任何手指都没关系，只要你至少还有一根手指加上拇指就行。"
    quil frown -sweat "但是如果没有拇指...嗯，事情就会变得相当困难。"
    "奎尔递给你一支蘸水笔和一些墨水。"
    "你试着在自己的手上模仿他无名指上的符号。"
    quil laugh "很好，当你自己画符文时，它们总是更强大。"
    quil flashy wink cling "好了，我要走了。我床柱上绑着一个健壮的年轻人，我一定会好好利用他的纯真的。"
    show quil smile bunga
    if girl:
        show p_side m at pic
    else:
        show side_p m at pic
    mc "太多信息了，伙计！" with vpunch
    if girl:
        hide p_side
    else:
        hide side_p
    hide quil with moveoutright
    play sound "sound/effects/walk.mp3"
    stop music
    "当奎尔走开时，你注意到你把自己的符文弄花了。真的用蘸水笔？"
    if girl:
        show femc fluster2 sweat frusta at center with dissolve:
            yoffset 40
    else:
        show palmier scratch apa sweat frusta at center with dissolve:
            yoffset 100
    mc "（哦，糟糕。不过，这应该无关紧要，对吧？）"
    if girl:
        femc frown sigh -sweat"（我想我应该回房间休息了。今天真是累人的一天。）"
        femc side sweat apa "（我的房间在哪里来着？）"
    else:
        mc deject -sweat sigh "（我想我应该回房间休息了。今天真是累人的一天。）"
        mc side chill sweat tanya "（我的房间在哪里来着？）"
    play music "MUSIC/MusMus-BGM-082.mp3"
    scene lorong_night with dissolve
    $ evening = False
    $ night = True
    jump mlm_map
label ketemu_thane_malam :
    if "day3" not in quil_events:
        stop music
        play sound "sound/effects/door.mp3"
        queue sound "sound/effects/bump.mp3"
        scene lor_dark with dissolve
        show nun cross shock at center with dissolve:
            yoffset 100
        if girl:
            show femc skul complain shock at right with moveinright:
                yoffset 40
        else:
            show palmier chill apa shock at right with moveinright:
                yoffset 100
        mc "啊啊啊啊啊！！！" with vpunch
        show red point kaget sweat shock at left with moveinleft:
            yoffset 330
        red "啊！" with hpunch
        show nun stun -shock
        if girl:
            show femc skul fluster2 sweat
        else:
            show palmier scratch ow sweat
        red chin ew frusta "看在科尔的份上，你吓死我了，伙计！"
        play music "MUSIC/MusMus-BGM-098.mp3"
        if girl:
            show girl at horzappear
        else:
            show boy at horzappear
        show nun cross
        menu:
            "你在干什么？！":
                hide girl
                hide boy
                if girl:
                    femc grit frusta "是你吓到我了。你在干什么？"
                    femc kzl -sweat apa "这是谁，或者说这是什么？"
                else:
                    mc grit tanya "是你吓到我了。你在干什么？"
                    mc rajuk -sweat -tanya "这是谁，或者说这是什么？"
                nun hand frusta "你刚才是叫我\'什么\'吗，[povname]·贝克？扣五分。"
                if girl:
                    femc side sweat shock "（哦等等，这是个老师？）"
                    femc wry apa "抱歉，呃...你们两个到底在干什么？"
                    hide femc with moveoutright
                else:
                    mc confused chill sweat tanya "（哦等等，这是个老师？）"
                    mc ha -tanya "抱歉，呃...你们两个到底在干什么？"
                    hide palmier with moveoutright


            "你能看到那个白色的东西，对吧？！":
                hide girl
                hide boy
                red bingung sweat apa "维尔科娃女士？当然能，你在说什么？"
                show red frown -apa
                if girl:
                    femc side sweat shock "（哦等等，那是个人？）"
                    femc wry apa "我是说...算了，你们两个在这里做什么？"
                    hide femc with moveoutright
                else:
                    mc rajuk sweat tanya "（哦等等，那是个人？）"
                    mc smile -tanya "我是说...算了，你们两个在这里做什么？"
                    hide palmier with moveoutright
        show nun cross -frusta at right with move
        nun "正在潜伏猎物。"
        if girl:
            show p_side f at pic
        else:
            show side_p f at pic
        mc "猎物？"
        if girl:
            hide p_side
        else:
            hide side_p
        red point wry sigh -sweat "老鼠。你知道的，就像我之前告诉你的，为了血液？我知道这有点恶心。但还能怎么办呢？"
        show red frown -sigh
        nun proud frusta "这很丢脸，不是吗？两个吸血鬼不得不依靠害虫？"
        nun cross sigh "但是，唉，学院并不那么宽容，更何况血液价格还在不断上涨。"
        nun proud apa "说到害虫，你为什么在这里？"
        nun -apa "这是禁区，我不记得今天有安排任何晚间战斗课。那么，你为什么在这里鬼鬼祟祟的？"
        if girl:
            show p_side s at pic
        else:
            show side_p s at pic
        mc "啊，嗯..."
        mc "...我想帮忙？"
        if girl:
            hide p_side
        else:
            hide side_p
        red bingung chin apa "帮忙？"
        show red frown -apa
        if girl:
            show p_side se at pic
        else:
            show side_p se at pic
        mc "是的，塞恩。我知道你在这个血液问题上很挣扎，所以我..."
        if girl:
            hide p_side
        else:
            hide side_p
        if girl:
            show girl at horzappear
        else:
            show boy at horzappear

        menu:
            "想分享我的血液？":
                hide girl
                hide boy
                red point kaget shock "什么？你在开玩笑吗？"
                show red frown -shock
                nun apa "你是说你要让他吸食你的血液，[povname]？"
                nun stun -apa "你真是太慷慨了。你想要什么作为回报？"
                if girl:
                    show p_side se at pic
                else:
                    show side_p se at pic
                mc "嗯...带我去我的房间，不问任何问题？"
                if girl:
                    hide p_side
                else:
                    hide side_p
                red chin ew sweat frusta "...你真的没问题吗，[nickname]？比如说，你清醒吗？"
                show red sad -sweat -frusta
                nun proud apa "对于这么便宜的报酬，我猜这是一次性的恩惠？"
                if girl:
                    show p_side f at pic
                else:
                    show side_p f at pic
                mc "呃，是的，就是一次性的。"
                if girl:
                    hide p_side
                else:
                    hide side_p
                red ngeles shock "哦，我本来希望能定期捐献的，但是..."
                red point hister bunga "...我在说什么？我接受！谢谢你，[nickname]！"
                red grin blush "Bon appetit~（法语：用餐愉快）"
                $ red_events.append("red_malam")
                if girl:
                    show p_side s at pic
                else:
                    show side_p s at pic
                mc "等等，你现在就要做？！"
                if girl:
                    hide p_side
                else:
                    hide side_p
                stop music
                scene lor_dark with fade
                if girl:
                    play sound "sound/effects/cloth.mp3"
                    galleryunlock nibble_f
                    show bite1_ce at left with moveinleft
                    $ renpy.pause(1.0,hard = True)
                    show bite2_ce with moveintop:
                        xalign 1.0 yalign 0.0
                    $ renpy.pause(1.0,hard = True)
                    play sound "sound/effects/vamp.mp3"
                    show bite3 with moveinright:
                        xalign 1.0 yalign 0.0
                    $ renpy.pause(1.0,hard = True)

                else:
                    galleryunlock nibble_m
                    play sound "sound/effects/cloth.mp3"
                    show bite1 at left with moveinleft
                    $ renpy.pause(1.0,hard = True)
                    show bite2 with moveintop:
                        xalign 1.0 yalign 0.0
                    $ renpy.pause(1.0,hard = True)
                    play sound "sound/effects/vamp.mp3"
                    show bite3_co with moveinright:
                        xalign 1.0 yalign 0.0
                    $ renpy.pause(1.0,hard = True)
                play music "sound/effects/jantung.mp3"
                show bite4 with moveinbottom:
                    xalign 1.0 yalign 1.0
                $ renpy.pause()
                if girl:
                    show p_side s at pic
                else:
                    show side_p m at pic

                mc "啊！"
                if girl:
                    hide p_side
                else:
                    hide side_p
                "你能感觉到血液从你的静脉中被抽走，伴随着隐隐的疼痛，血管正在萎缩。"
                mc "（好疼！）"
                if girl:
                    show p_side m at pic
                else:
                    show side_p m at pic
                mc "喂，塞恩！冷静点！"
                if girl:
                    hide p_side
                else:
                    hide side_p
                nun "我同意。够了，塞恩。"
                "但塞恩没有停下，相反，他的咬合更深了，他的眼睛闪烁着明亮的红宝石色光芒——"
                nun "塞恩，停下！停下！"
                stop music
                play sound "sound/effects/vamp.mp3"
                scene lor_dark with vpunch
                show red point ngeles sweat shock at center with dissolve:
                    yoffset 330
                red "啊！"
                red perih -shock "该死，该死，该死！我太抱歉了！我不知道我怎么了，这种事从来没发生过！"
                red ow apa "[nickname]，你还好吗？"
                show red sad -apa
                if girl:
                    show p_side s at pic
                else:
                    show side_p s at pic
                mc "我有点头晕，但是...呃！"
                if girl:
                    hide p_side
                else:
                    hide side_p
                show nun proud shock at right with moveinright:
                    yoffset 100
                show red ow at left with move
                nun "贫血。你吸得太多了，塞恩！"
                red shock ngeles "糟糕。我抱你回房间，好吗？坚持住！"
                nun frusta "轻点，塞恩！"
                red growl frusta "我知道。"
                scene bg_black with eye_shut
                play sound "sound/effects/cloth.mp3"
                queue sound "sound/effects/tile.mp3"
                "塞恩抱着你回到了你的床上。即使在昏睡中，你仍能感觉到自己的血滴从他的下巴上滴落。"
                hide screen cal
                stop sound
                jump dreamscape



            "给你弄到一小瓶血了？":
                hide girl
                hide boy
                red point cowo blush shock "哦，真的吗？谢谢你，伙计。在哪里？"
                if check_inv_for(blood_items):
                    show side_p w at pic
                    if check_inv_for(plas_items):
                        $ InvItem(*item_plasma).toss(1)
                    elif check_inv_for(sir_items):
                        $ InvItem(*item_siren).toss(1)
                    else:
                        $ InvItem(*item_blood).toss(1)
                    mc "在这里，不过它在我口袋里放了一会儿了。没问题吧？"
                    hide side_p
                    red laugh blush bloom "这太好了！你是我的救星[nickname]，哇噢！！！"
                    red amused "我以后会补偿你的，好吗？你想去哪家餐厅都行。我请客！"
                    python:
                        red_events.append("date_1")
                        mrh.points += 10
                    nun cross sigh "那么，我想我会继续巡视场地。晚安，你们两个。"
                    hide nun with moveoutright
                    show red at center with move
                    red cowo "晚安！我们也该睡觉了，[nickname]。时间不早了。"
                    scene bg_black with w20
                    play sound "sound/effects/walk.mp3"
                    "和塞恩一起走了一段路后，他最终带你回到了你的房间，让你好好休息。"
                    hide screen cal
                    stop music
                    jump dreamscape
                else:
                    if girl:
                        show p_side s at pic
                    else:
                        show side_p s at pic
                    mc "哦，呃，我一定是把它落在我房间里了。我，呃，明天给你，好吗？"
                    if girl:
                        hide p_side
                    else:
                        hide side_p
                    red amused -blush -shock "哦，好的，谢谢。看来今晚我可以早点睡了，是吧，维尔科娃女士？"
                    nun cross "我想是的。我会继续我的巡逻值班。晚安，你们两个。"
                    hide nun with moveoutright
                    show red at center with move
                    red laugh blush bunga "哇！说实话，你帮了我大忙，[nickname]。一小瓶血应该够我用一周了！"
                    show side_p se at pic
                    mc "哈哈，是啊。没问题，伙计。"
                    show side_p s
                    mc "（该死，现在我觉得有义务帮忙。我要去哪里找一小瓶血呢？）"
                    hide side_p
                    stop music
                    $ add_new_quest("blood1")
                    python:
                        if len(new_quests) > 0: #if we have new quests
                            for i in new_quests:
                                active_quests.insert(0, i) #add to top of the quest list
                            new_quests = [] #now reset the new quest list, since they all got added
                    show screen completedtask("新任务！")
                    scene bg_black with w20
                    play sound "sound/effects/walk.mp3"
                    "和塞恩一起走了一段路后，他最终带你回到了你的房间，让你好好休息。"
                    hide screen cal
                    jump dreamscape
    else:
        scene underground_night with dissolve
        "它被锁上了。"
        jump under_map

label dreamscape:
    show screen cal
    scene garden with flashbulb
    if girl:
        show femc skul sad sweat apa at center with dissolve:
            yoffset 40
    else:
        show palmier chill confused sweat tanya at center with dissolve:
            yoffset 100
    mc "啊？"
    if girl:
        femc fluster -apa "我在哪里？"
    else:
        mc side -tanya "我在哪里？"
    if girl:
        show femc frown shock -sweat at right with move
    else:
        show palmier kzl shock -sweat at right with move
    play sound "sound/effects/walk.mp3"
    iv "我在想是哪个无知的傻瓜今晚忘了他们的符文。"
    play music "MUSIC/MusMus-BGM-112.mp3"
    show ivar ejek at left with moveinleft:
        yoffset 150
    iv "我多么幸运能得到杀害我女儿凶手的光临。"
    show ivar smirk
    if girl:
        femc panik sweat -shock"凶手？等等，你是？"
    else:
        mc sad -shock sweat"凶手？等等，你是？"
    iv awk "美丽巫师。"
    if girl:
        femc complain shock "你是厌男者伊瓦尔！"
        show femc sad -shock
    else:
        mc ow shock "你是厌男者伊瓦尔！"
        show palmier apa -shock
    iv ancam cling "哈。我那臭名昭著的笔名。"
    iv kzl frusta "我一直讨厌那个名字。"
    show ivar frown -frusta
    if girl:
        femc fluster sigh "听着，我不想惹麻烦，好吗？我没有杀你的女儿，我发誓！"
        show femc pain shock
    else:
        mc ew sigh "听着，我不想惹麻烦，好吗？我没有杀你的女儿，我发誓！"
        show palmier confused shock
    iv kzl sigh "我知道。你只是恰好和那个杀人凶手长得一样。"
    if girl:
        show femc sad -sweat -shock

    else:
        show palmier kzl -sweat -shock
    iv frown -sigh "问题是，你知道你的替身是如何变成现在这个样子的吗？真实的故事，而不是那个堕落的英克威尔告诉你的版本？"
    if girl:
        femc sad apa "什么？"
    else:
        mc scratch apa tanya "什么？"
    iv ejek cling "你想知道吗？"
    scene flower_guards with dissolve
    galleryunlock flower_guards
    "两个头上长着花的男性身影抬着你梦中的新郎。那个即将出轨的丈夫。"
    iv "你只听过奎尔的一面之词。也许这个证人能更好地阐明这个场景。"
    iv "虽然我担心你不会从他嘴里得到多少诚实的话。"
    scene mayit_top
    show mayit_back behind mayit_top
    play sound "sound/effects/grow.wav"
    show mayit behind mayit_top:
        xpos 0 ypos -250
        ease 2.0 ypos 203
    $ renpy.pause(2.0,hard = True)
    $ NPC = "新郎"
    npc "不，不，求你了！"
    npc "啊！啊啊啊啊啊！！！"
    scene garden with dissolve
    play sound "sound/effects/vine.wav"
    show potty at center with dissolve:
        zoom 0.45
    "花朵从那个男人头部的每个部位不断生长，直到一整束花完全取代了他的头。"
    "如果不是因为血，你会觉得它很美。"
    hide potty with dissolve
    show ivar smirk at left with dissolve:
        yoffset 150

    if girl:
        show femc grit sweat shock at right with dissolve:
            yoffset 40
    else:
        show palmier chill grit sweat shock at right with dissolve:
            yoffset 100
    mc "呃-！" with vpunch
    if girl:
        show femc fluster2 -shock
        "你全身上下的每一根神经都在尖叫着让你逃跑，然而你的肌肉却冻结在原地，把你钉在座位上。"
        show femc sad
    else:
        show palmier side -shock
        "你全身上下的每一根神经都在尖叫着让你逃跑，然而你的肌肉却冻结在原地，把你钉在座位上。"
        show palmier confused
    iv ancam "但幸运的是，还有其他办法。"
    show ivar smirk flow with dissolve
    "伊瓦尔伸手到那个男人的新\'头部\'，摘下了一朵红玫瑰。瞬间，新鲜的血液开始从茎部渗出。"
    scene garden with dissolve
    if girl:
        show f_0 with moveinleft:
            xpos 0 ypos 0
        show o_top:
            xpos 0 ypos 0
        show f_rose behind o_top with moveinleft:
            xpos 109 ypos 19
        iv "给你。"
        show f_1 with moveinright:
            xalign 1.0
        mc "那是什么？"
        show i_f_top
        show f_hand behind i_f_top:
            xpos 1638 ypos 100
            easein 1.0 xpos 1458 ypos 265
        iv "一份欢迎礼物。"
        iv "讽刺，不是吗？我的魔法如何将最丑陋的灵魂变成最诱人的花朵？"
        galleryunlock i_f
        show f_2 with dissolve:
            xalign 1.0 yalign 0.0
        $ renpy.pause()
    else:
        show m_0 with moveinleft:
            xpos 0 ypos 0
        show o_top:
            xpos 0 ypos 0
        show m_rose behind o_top:
            xpos -654 ypos -504
            easein 1.0 xpos 109 ypos 116
        iv "给你。"
        galleryunlock i_m
        show m_1 with moveinright:
            xalign 1.0
        mc "那是什么？"
        show i_m_top
        show m_hand behind i_m_top:
            xpos 493 ypos 84
            easein 1.0 xpos 727 ypos 238
        iv "一份欢迎礼物。"
        iv "讽刺，不是吗？我的魔法如何将最丑陋的灵魂变成最诱人的花朵？"
        play sound "sound/effects/stab.mp3"
        show m_2 with vpunch:
            xalign 1.0 yalign 0.0
        mc "啊！"
        $ renpy.pause()
    scene garden with dissolve
    show ivar ejek at left with dissolve:
        yoffset 150
    if girl:
        show femc sad sweat at right with dissolve:
            yoffset 40
        iv "美丽。"
        show femc kzl
    else:
        show palmier chill pissed sweat frusta  at right with dissolve:
            yoffset 100
        iv ancam "干杯。为我们有史以来第一位来自异世界的访客。"
        show palmier apa -frusta
    iv awk "我不得不说，你真是个美人。"
    if not girl:
        show palmier rajuk shock
        iv kzl sigh "如果不是因为你的男子气概的话。"
        if girl2:
            mc kzl "我和其他女孩一样都是女人。非常感谢。"
            iv kzl sigh "我道歉。尽管你的形态仍然让我感到厌恶。"
        mc huh -sweat sigh "这话出自一个{i}男性{/i}美丽巫师之口。"
        show palmier mean -sigh
        iv frown -sigh "徒有虚名的奉承。幸运的是，一个人不需要有吸引力就能欣赏美。"
        mc grit frusta "别说废话了。你想要什么？"
    else:
        femc yell frusta "别说废话了。你想要什么？"
    iv ejek "任何冷静理智的父亲都想要的东西。"
    iv ancam cling "我女儿凶手的头颅，用银盘呈上。"
    show ivar smirk -cling
    if girl:
        femc kzl -sweat -frusta "复仇。"
    else:
        mc kzl -sweat -frusta"复仇。"
    iv frown sigh "是的，但不是针对你，你只是个游客。被那些迷人罪人的魅力蒙蔽了双眼的人。"
    if girl:
        show girl at horzappear
    else:
        show boy at horzappear
    menu:
        "难道你们不是罪人吗？":
            hide girl
            hide boy
            iv ejek cling "自欺欺人地认为自己是好人这边的英雄，这是人之常情。"
            iv frown sigh "你可能认为我是可恶的那个，但他们才是对我的同类进行种族屠杀的人。"
        "难道你们不是那些迷人的人吗？":
            hide girl
            hide boy
            iv frown sigh "也许在外表上是，但仅此而已。"
            iv smirk -sigh "我们相当无辜，或者至少，我们说服自己是无辜的。"
    if girl:
        femc yell sigh "一个家伙的脑袋刚刚在我面前他妈的爆炸了。我很确定你才是这里的反派。"
        show femc kzl -sigh
    else:
        mc kzl frusta "一个家伙的脑袋刚刚在我面前他妈的爆炸了。我很确定你才是这里的反派。"
        show palmier frown -frusta
    iv kzl frusta "即使他是那个伤了我女儿心的人？即使在他把她推向反对我之后，甚至没有体面地尊重她的忠诚？"
    show ivar frown sigh
    if girl:
        femc guilt sweat "..."
    else:
        mc side sweat "..."
    iv frown -frusta "事情总有另一面，[povname]。问题是，你是否好奇到想去追寻它们？"
    iv awk apa "告诉我，你是那种宁愿躲在无知的幸福中的人，还是那种无论真相多么丑陋都愿意接受的人？"
    if girl:
        show girl at horzappear
    else:
        show boy at horzappear
    menu:
        "无知是福。":
            $ main.points += 1
            hide girl
            hide boy
            $ curiosity -= 10
            if "truth" in my_events:
                $ my_events.remove("truth")
            if girl:
                femc yell -sweat sigh "有时候不知道更好。我不需要知道细节。有时候这样更好。"
                show femc kzl -sigh
            else:
                mc kzl -sweat sigh "有时候不知道更好。我不需要知道细节。有时候这样更好。"
            iv ancam -apa "魔鬼藏在细节里，他们是这么说的。就我个人而言，我更愿意回应恶魔的召唤。"
            show ivar ejek
        "我宁愿知道真相。":
            $ curiosity += 10
            $ main.points -= 1
            if "truth" not in my_events:
                $ my_events.append("truth")
            hide girl
            hide boy
            if girl:
                femc frown -sweat sigh "我想了解全貌。"
            else:
                mc frown -sweat sigh "我想了解全貌。"
            iv ejek cling "明智的选择。一个常常令人失望的选择，但无论如何都是明智的。"
            show ivar ejek -cling
    if girl:
        femc side apa "你为什么问我这个？"
        show femc frown -apa
    else:
        mc scratch apa tanya "你为什么问我这个？"
        show palmier chill frown -tanya
    iv frown "为了看看你会如何行动。那朵玫瑰里藏着通向你真相的钥匙，你的分身状态的真正原因。"
    iv smirk "捏碎它，你就会找到答案。"
    if girl:
        femc sad apa "这\'玫瑰\'到底是什么？"
    else:
        mc rajuk tanya "这\'玫瑰\'到底是什么？"
    if girl:
        show femc pain sweat shock
    else:
        show palmier ew sweat shock
    iv flirt "当然是那个人的一片脑组织。"
    show ivar smirk
    if girl:
        femc guilt frusta "（\'当然\'。他说得好像我才是这里的怪人一样。）"
        femc yell -frusta apa "我怎么能确定我看到的会是真相，而不是另一个谎言？"
        show femc kzl -apa
    else:
        mc huh frusta "（\'当然\'。他说得好像我才是这里的怪人一样。）"
        mc mock -frusta tanya "我怎么能确定我看到的会是真相，而不是另一个谎言？"
        show palmier kzl -tanya
    iv kzl sigh "如果说有什么比我的女儿们更珍视的，那就是我的诚信。我不说谎，孩子。"
    iv ejek -sigh "我很残忍，毫不道歉。如果这能让我高兴，我会杀死、残害和折磨你以及所有你在乎的人。"
    iv smirk "但我发誓我永远，永远不会对你撒谎。"
    iv frown sigh "你能说你那位穿蓝衣服的新相识也是如此吗？"
    if girl:
        femc grit -sweat "...你为什么要告诉我这些？"
        show femc kzl
    else:
        mc pissed -sweat "...你为什么要告诉我这些？"
        show palmier kzl
    iv ejek -sigh "因为我想给你一个选择。就像我说的，我是个冷静理智的人。"
    iv kzl frusta "你对这个世界一无所知。除了那些骗子喂给你的东西，你什么都不知道。"
    iv smirk -frusta "我给你完整的画面，或者至少给你机会去看到它，这才公平。"
    iv frown sigh "不过，如果这不能阻止你追捕我的同类，那就随它去吧。"
    if girl:
        femc sarkas sigh "什么，所以你的感情不延伸到其他大巫师身上？"
        show femc kzl -sigh
    else:
        mc mean tanya "什么，所以你的感情不延伸到其他大巫师身上？"
        show palmier kzl -tanya
    iv kzl -sigh "幸运的是，我们这些巫师更喜欢独自工作。这在这个世界上是一种被低估的祝福。"
    iv frown "好了，我该说的都说完了。"
    iv ejek "所以，我看不出我们为什么还要继续忍受彼此的陪伴。"
    if girl:
        show femc frown shock
        femc "你是在赶我走吗？"
        iv smirk "暂时是的。"
        iv frown sigh "如果你在寻找我的同类，我建议你从贪婪巫师开始。"
        iv awk cling "梅扎的表演在每年的这个时候总是令人叹为观止。"
        femc complain apa "梅扎？"
        show femc sad -apa
        stop music
        scene bg_black with eye_shut
    else:
        scene garden with dissolve
        play sound "sound/effects/vine.wav"
        show vine1 at left with moveinbottom
        mc "什么——？！"
        show vine2 at left with moveintop
        iv "如果你在寻找我的同类，我建议你从贪婪巫师开始。"
        show vine3 at right with moveinright
        galleryunlock m_vine
        iv "梅扎的表演在每年的这个时候总是令人叹为观止。"
        mc "嗯，嗯嗯！"
        stop music
        scene bg_black with eye_shut
    jump bangun
label bangun:
    $ renpy.pause(3.0,hard = True)
    play sound "sound/effects/cloth.mp3"
    $ calendar.next() #SELASA 16
    $ night = False
    $ morning = True
    show screen cal
    if girl:
        pause 1.0
        scene bed_pagi with eye_open
        show p_side s at pic
        mc "...梅扎是谁？"
        
        mc "（这一切只是一场梦吗...嗯？）"
        hide p_side
        scene bangun_f with flashbulb
        galleryunlock bangun_f
    else:
        scene bed_pagi with eye_open
        show side_p m at pic
        mc "啊啊啊！！！" with vpunch
        show side_p s
        mc "（原来只是一场梦...嗯？）"
        scene bangun with flashbulb
        galleryunlock bangun
    mc "该死。"
    scene kmr_pagi with dissolve
    play sound "sound/effects/walk.mp3"
    show buff confused sweat apa at center with dissolve:
        yoffset 770
    buff "呃，[povname]？"
    show buff frown -apa
    stop music
    play music "MUSIC/MusMus-BGM-047.mp3"
    $ add_new_quest("sucker3")
    python:
        if len(new_quests) > 0: #if we have new quests
            for i in new_quests:
                active_quests.insert(0, i) #add to top of the quest list
            new_quests = [] #now reset the new quest list, since they all got added
    show buff frown -sweat at right with move
    if girl:
        show femc skul laugh sweat at left with moveinleft:
            yoffset 40
        femc "啊！是的，莱尔，怎么了？"
    else:
        show palmier scratch hister sweat at left with moveinleft:
            yoffset 100

        mc "啊！是的，莱尔，怎么了？"
    if girl:
        show femc frown -sweat shock
    else:
        show palmier chill frown -sweat shock
    buff eh -sweat "你的一个朋友在门口等你。他在提醒你去餐厅和他一起吃早餐。"
    show buff sad
    if girl:
        femc wry sweat -shock "哦，好的。我一会儿就出去。呃...你要一起来吗？"
        show femc wry2 -sweat
    else:
        mc laugh sweat -shock  "哦，好的。我一会儿就出去。呃...你要一起来吗？"
        show palmier side -sweat
    buff scold sweat shock "哦不，我...我呃，不太适应人多的场合。"
    show buff sad -shock
    if girl:
        femc sad sweat "哦。"
    else:
        mc sad "哦。"

    if girl:
        show femc frown -sweat
        if girl2:
            buff keluh sigh "总之，我和管理员谈过了。他们说无法解决房间的问题。"
            buff sad -sigh "但是，我保证会给你空间。如果你需要用浴室，需要在房间里换衣服或其他什么的，我会呃...我会躲到被子下面去！"
            buff confused -sweat "你不会注意到我在这里的。"
            femc laugh "好的，呃，谢谢。"
            show femc frown
        buff keluh "那么...再见。"
        hide buff with moveoutright
    else:
        show palmier frown
        buff keluh frusta "那么...再见。"
        hide buff with moveoutright
    scene kmr_pagi with dissolve
    play sound "sound/effects/knock.mp3"
    if "red_malam" in red_events:
        red "[nickname]，你起来了吗？昨晚没事吧？我给你带了些维他命饮料！"
        $ InvItem(*item_vita).pickup(1)
        if girl:
            show p_side m at pic
        else:
            show side_p m at pic
        mc "我没事。别进来，我在换衣服！"
        if girl:
            hide p_side
        else:
            hide side_p
    else:
        quil "哦[nickname]亲爱的，起床啦，鸡蛋和培根等着呢！"
        quil "来吧，我已经饿坏了。"
        if girl:
            show p_side f at pic
        else:
            show side_p f at pic
        mc "等一下，我在换衣服！"
        if girl:
            hide p_side
        else:
            hide side_p
        quil "哦，我可以帮忙哦~"
        if girl:
            show p_side m at pic
        else:
            show side_p m at pic
        mc "不要！别进来，你这个色鬼！"
        if girl:
            hide p_side
        else:
            hide side_p
    scene drawer0 with dissolve
    play sound "sound/effects/drawer.mp3"
    "你把玫瑰放进了写字台的抽屉里。"
    scene drawer1 with dissolve
    if girl:
        show p_side f at pic
    else:
        show side_p f at pic
    mc "（我待会儿再处理那个。）"
    if girl:
        hide p_side
    else:
        hide side_p
    stop music
    scene bg_black with w20
    
    play music "MUSIC/MusMus-BGM-049.mp3"
    scene kantin with w20
    show tom chill smile at center with dissolve:
        yoffset 190
    if "red_malam" in red_events:
        "塞恩给了你一瓶维他命饮料，让你在早餐后喝。他似乎对昨晚让你晕倒感到非常内疚。"
        "你感谢了他，然后走向阿什姆和奎尔。当你走近时，你注意到另一个学生正在和阿什姆聊天。"
    else:
        "当你走近阿什姆和塞恩时，你看到另一个学生正在和阿什姆聊天。"
    $ NPC = "学生"
    show npc_1 at pic
    npc "阿什姆，再次感谢你昨天的帮助。如果有什么我能做的来报答你..."
    hide npc_1
    $ NPC = "阿贾克斯"
    tom calm spark "别说这些，阿贾克斯，我只是在帮助一个需要帮助的朋友。"
    show npc_1_1 at pic
    npc "但是，如果有什么我能做的，任何事——"
    hide npc_1_1
    tom smile cling "好吧，确实有件事。你父亲在部里工作，对吧？你能否帮我把这个转交给他？"
    show npc_1 at pic
    npc "一封信？是关于什么的？"
    hide npc_1
    tom amused -cling "只是我想到的一个商业提案。"
    tom lega blow "我怀疑他是否会理会一个本科生的想法，但谁知道呢？也许你的一句好话能说服他。"
    show npc_1_1 at pic
    show tom smile -blow
    npc "哦，当然！我会确保他读到的。别担心！"
    hide npc_1_1
    "那个年轻人匆匆跑向他自己的朋友群。"
    show tom chill frown at right with move

    if "red_malam" in red_events:
        show quil skul laugh cling at left with moveinleft:
            yoffset 200
        quil "那么，信里写了什么？"
        show quil amused -cling
        tom cruel cling "这只是我的一个建议。在我毕业后把我收在他的羽翼下。"
        quil ejek apa"哦？你用了什么邪恶的诅咒符文来说服他的？还是只是老套的勒索？"
        show quil sly -apa
        tom giggle blow "别无礼，奎尔。你知道勒索永远只是备用计划。"
        show tom amused cling
        quil mock sigh "哼。你还利用他的儿子来传递诅咒。我发誓，阿什姆，你为了在生活中出人头地真是无所不用其极。"
        show quil smile -sigh
        tom ha -cling "这完全是公平竞争。我们中有些人可没有遗产可以依靠，奎尔。"
    else:
        show red point grin apa behind tom at left with moveinleft:
            yoffset 330
        red "那封信是怎么回事？"
        show red datar -apa
        tom cruel cling "这只是我的一个建议。在我毕业后把我收在他的羽翼下。"
        red amused "你？得了吧，你知道只有贵族才能被录用进部里。除非……哦，你做了什么事，对吧？"
        red mock apa "这次你用了什么？勒索？诅咒符文？"
        tom amused blow "别无礼，塞恩。你知道勒索对我来说太脆弱了。"
        red sayang sigh "可怜的倒霉蛋，你居然利用了他的儿子。"
        show red datar -sigh
        tom wry -blow "我可不能为他的天真负责。"
    scene kantin with dissolve
    if girl:
        show p_side m at pic
    else:
        show side_p m at pic
    mc "……你做了什么，阿什姆？"
    if girl:
        hide p_side
    else:
        hide side_p
    show tom chill frown at center with dissolve:
        yoffset 190

    tom kzl apa "[povname]。你迟到了。为什么？"
    if girl:
        show girl at horzappear
    else:
        show boy at horzappear
    show tom kzl -apa
    menu pagi1:
        "{s}{color=#be6f1c}睡不着。{/color}{/s}" if not "quil_hump" in quil_events:

            jump pagi1
        "睡不着。" if "quil_hump" in quil_events:
            hide girl
            hide boy
            if girl:
                show p_side m at pic
            else:
                show side_p m at pic
            mc "是啊，奎尔的呻吟声在走廊里回荡，我真的睡不着。"
            if girl:
                hide p_side
            else:
                hide side_p
            show red point awkward shock behind tom at left with moveinleft:
                yoffset 330
            red "哦，原来那声音是这个！我就觉得听着耳熟！"
            show red datar -shock
            show quil flashy wink cling at right with moveinright:
                #xzoom -1.0
                yoffset 200
            quil "这叫\'日常锻炼\'，我的朋友们。"
            quil laugh spark "这是一个健康的习惯，我打算把它传授给你那位英俊的室友，[nickname]。"
            show quil datar -spark
        "{s}{color=#be6f1c}问塞恩{/color}{/s}" if not "red_malam" in red_events:
            jump pagi1
        "问塞恩" if "red_malam" in red_events:
            hide girl
            hide boy
            show red point ngeles sweat frusta behind tom at left with moveinleft:

                yoffset 330
            red "我真的很抱歉，[nickname]。我发誓这是个意外。"
            show red sad -frusta
            tom scold apa "什么是意外？"
            red so -sweat sigh "我可能……昨晚吸了[nickname]的血，吸得有点多。"
            play sound "sound/effects/bang.mp3"
            tom ew hip shock "你做了什么？！" with vpunch
            show tom kzl -shock
            show red kaget shock
            "阿什姆猛拍桌子，他的刀危险地落在塞恩的右手旁边。"
            red ow sweat frusta "天啊，你差点用那玩意儿刺到我的手！"
            show red sad -frusta
            tom scold ew frusta"你喝了{i}[dia]{/i}的血？"
            play sound "sound/effects/cloth.mp3"
            show tom scold kzl -frusta with move:
                xalign 0.38
            red perih shock "嘿，是[povname]建议的！"
            show red sad -shock
            if girl:
                show p_side f at pic
            else:
                show side_p f at pic
            mc "确实是我，我想帮忙解决……你知道的，他的血液问题。"
            if girl:
                show p_side m
            else:
                show side_p m
            mc "怎么，我难道还得为自己的身体征求你的许可吗？"
            if girl:
                hide p_side
            else:
                hide side_p
            show red sad -sweat
            tom capek sweat frusta "..."
            show quil flashy panik sigh at right with moveinright:
                xzoom -1.0
                yoffset 200
            show tom kzl shock
            quil "给你个建议，亲爱的。不管你多想说是，理智和逻辑的回答都是不。"
            show red frown
            show tom kzl frusta hip with move:
                xalign 0.5
            tom capek blow "奎尔……闭嘴。"
            show tom ha -blow -sweat
            quil hister bunga "我只是想帮忙，亲爱的阿什。"
            show tom frown shock
            if girl2:
                quil sly cling "怎么，你想让[dia]被[dia2]那个肌肉发达的室友抢走吗？"
            else:
                quil sly cling "怎么，你想让[dia2]被[dia]那个肌肉发达的室友抢走吗？"
            show tom frown -shock
        "继续追问。":
            hide girl
            hide boy
            "奎尔在你还没来得及说出另一个字之前就打断了你。"
            show tom kzl shock
            show quil flashy wink spark at right with moveinright:
                xzoom -1.0
                yoffset 200
            quil "[nickname]一定是被[dia]的新室友迷住了。你见过那家伙吗？"
            show tom ha -shock
            quil ejek cling "他至少有7英寸。"
            show quil sly -cling
            show red point amused sigh behind tom at left with moveinleft:
                yoffset 330
            show tom capek sweat
            red "哼。那有点夸张了。"
            quil wink cling "这正是我所希望的。"
            quil heh blush bunga "奎尔开始淫荡地深喉一根香肠，同时发出一些呻吟声。"
            show tom sigh blow
            show quil hister -bunga
            show red chin ew sweat frusta
            if girl:
                show p_side s at pic
            else:
                show side_p s at pic
            mc "真的吗，奎尔？就在我的沙拉面前？"
            $ my_events.append("salad")
            if girl:
                hide p_side
            else:
                hide side_p
            show red point so -sweat
            show quil sly -blush
            show tom frown -sweat -blow
    quil talk apa "顺便问一下，那个肌肉男在哪里？"
    if girl:
        show p_side f at pic
    else:
        show side_p f at pic
    mc "在我们房间，他说他不喜欢人多。"
    if girl:
        hide p_side
    else:
        hide side_p

    tom ha "注意力。"
    show quil skul err apa
    red chin kaget shock "啊？"
    show quil rajuk -apa
    show red huh -shock
    tom frown blow "他不喜欢的是注意力。当每个人都盯着你看的时候，很难安静地吃饭。"
    show red frown
    show quil frown
    tom kzl frusta "你见过他的眼睛。除非我是唯一一个真正花时间去了解我们新来者的人。"
    tom frown -frusta "一年级新生光是看到他就吓得躲在课桌后面。"
    quil flashy tantrum sweat shock "哦，对了。它们是金色的，对吧？"
    show quil frown -shock
    red bingung apa "金色的？"
    show red frown -apa
    tom kzl "像伊瓦尔的那样。"
    show mat_cing with w33
    galleryunlock mat_cing
    mc "（啊！）"
    show mat_cing2 with wet
    hide mat_cing
    mc "（金色的眼睛。）"
    hide mat_cing2 with w33
    red point ngeles sweat shock "什么，你是在说我想的那个意思吗？你认为那是他的一个孩子？"
    show red -shock
    tom ew blow "你知道还有谁有像他那样的金色眼睛吗？"
    show tom kzl -blow
    quil laugh cling "完全不知道。不过这倒是解释了为什么我觉得他如此有趣。"
    show quil amused -cling
    show red frown
    tom frown "他的女儿是粉色和蓝色的眼睛，儿子是金色的。"
    red grit sweat "他不是会杀死自己的儿子吗？我是说，有些人甚至声称他会吃掉他们。"
    show quil rajuk
    show red huh -sweat
    tom blow "传说是这么说的。只有他的女儿继承他的魔法。我相信他的儿子们是在照料他的花园。"
    show tom kzl -blow
    red kaget shock "你是说当肥料？！"
    show red kaget -shock
    quil heh -sweat sigh "哈！如果他们幸运的话。传闻说他把他们当作玩物。"
    show quil sly -sigh
    show flower_guards2 with w33
    mc "（等等，那是不是意味着那些花仆人就是他的儿子？）"
    hide flower_guards2 with w33
    red bingung apa "所以你是说这个新来的是个逃跑的？他不会记录吗？"
    red ew -apa "我是说，一个人能有多少孩子啊？"
    show red frown
    quil wink cling "数量达到数百，他的滥交程度堪比我。"
    red chin ew sweat frusta "说实话，奎尔，这更多地说明了你的问题，而不是他的。"
    show red sad -sweat -frusta
    show quil amused sigh
    tom frown apa "[nickname]，你有什么要补充的吗？"
    if girl:
        show p_side f at pic
    else:
        show side_p f at pic
    mc "啊？"
    show quil skul frown -sigh
    show red frown
    if girl:
        hide p_side
    else:
        hide side_p
    tom chill -apa "你是他的室友。"
    if girl:
        show girl at horzappear
    else:
        show boy at horzappear
    menu:
        "他看起来很温和。":
            hide girl
            hide boy
            show tom frown
            if girl:
                show p_side f at pic
            else:
                show side_p f at pic
            mc "他看起来...很温和。他的眼睛里有一种天真的神情。"
            if girl:
                hide p_side
            else:
                hide side_p
            tom cruel cling "容易受骗？"
            if girl:
                show p_side m at pic
            else:
                show side_p m at pic
            mc "啊？"
            if girl:
                hide p_side
            else:
                hide side_p
            tom chill pfft -cling "如果他容易被影响，他会成为我们四人组的一个很好的补充。"
            tom ew blow "我们的小组需要更多的体力而不是头脑。你和奎尔最近越来越难相处了。"
            show tom capek -blow
            show red hister
            quil flashy mock sigh "这意味着大爸爸想要一个新的小奴隶来屈从于他的意志。"
            show quil smile -sigh
            show red amused
            tom kzl frusta "我欣赏控制和服从。这没什么不对的。"
            tom ha blow "况且，他需要有人。我知道那种因为外表而被排斥的感觉。"
            show red frown
            show quil skul rajuk
            show tom frown -blow
            mc "（嗯？）"
            $ interlocutor = "Quill"
            $ del_all_msg()
            hide window
            show hp at move_messenger2
            pause 1.0
            $ show_messenger()
            $ msg ("阿什姆的眼睛。紫色的眼睛是仙子和森林精灵的专属。", who=1, status='online')
            $ msg ("他妈妈是个仙子，但他是个名副其实的私生子，所以这家伙有恋父情结。", who=1)
            $ msg ("现在要有点策略，停顿一下再抬头看。", who=1)
            $ hide_messenger()
            hide hp
            show hp2 at move_messenger3
            pause 1.0
            $ ibu.desc = "据说是你\'核心圈子\'的领导。看起来对你有点占有欲。有仙子血统。"

        "他看起来很害怕。":
            hide girl
            hide boy
            if girl:
                show p_side s at pic
            else:
                show side_p s at pic
            show tom frown -apa
            mc "我们第一次见面时，他请求我不要杀他。我不明白为什么。"
            if girl:
                hide p_side
            else:
                hide side_p
            red point mock apa "真的吗？我们年级最顶尖的猎巫人竟然不明白为什么一个半巫师吓得屁滚尿流？"
            show quil amused
            show red amused -apa
            if girl:
                show p_side f at pic
            else:
                show side_p f at pic
            mc "阿什姆不是最厉害的吗？"
            if girl:
                hide p_side
            else:
                hide side_p
            tom chill calm "从学术角度来说，是的。不过在实地工作中，你比我更有名，亲爱的。"
            show tom smile
            red cowo shock "顺便说一下，这让我想起来了。你和奎尔不是接了个赏金任务吗？我在名单上看到了你们的名字。"
            show red datar -shock
            quil flashy panik sweat sigh "哦，那个小任务？我们实在懒得做，半途就放弃了。"
            show quil smile -sigh
            tom frown apa "嗯。是这样吗？"
            show quil datar -sweat
            show tom kzl -apa
    red chin datar apa "哦对了，有人看到那个关于猫的请求吗？"
    show quil frown
    if girl:
        show p_side s at pic
    else:
        show side_p s at pic
    mc "猫？"
    if girl:
        hide p_side
    else:
        hide side_p
    tom hip eh "有人没遵守学校规定，带着他们的宠物来了。"
    show tom frown
    red point laugh blush bunga "对，就是那个。听说他们给能找到那小家伙的人一大笔奖励。有兴趣吗？"
    show quil skul rajuk
    tom ew frusta "我没时间玩捉虫游戏。"
    show tom capek -frusta
    quil flashy ejek cling "我可能会去做，就为了能把那东西塞到菲亚脸上。"
    show red amused -blush -bunga
    if girl:
        show p_side m at pic
    else:
        show side_p m at pic
    show quil sly -cling
    mc "菲亚对猫过敏！"
    if girl:
        hide p_side
    else:
        hide side_p
    quil laugh bloom "没错！"
    if girl:
        show p_side m at pic
    else:
        show side_p m at pic
    mc "..."
    mc "好吧，我打赌我能在你们所有人之前找到它！"
    show quil amused
    show red datar
    if girl:
        hide p_side
    else:
        hide side_p
    show red datar shock
    show quil skul amused shock
    tom scold amused cling "哦？你打算提供什么？"
    show red amused -shock
    show quil sly -shock
    if girl:
        show p_side s at pic
    else:
        show side_p s at pic
    mc "啊？"
    if girl:
        hide p_side
    else:
        hide side_p
    tom chill pfft blow "这是个赌注。你不会指望我们没有任何奖励就参与吧？"
    if girl:
        show p_side s at pic
    else:
        show side_p s at pic
    mc "嗯...你们想要什么？"
    if girl:
        hide p_side
    else:
        hide side_p
    show tom ejek cling
    show quil skul panik sigh
    show red point wry sigh
    mc "（哦，我不喜欢那个笑容。一点也不。）"
    show quil amused -sigh
    tom hip smile -cling "恩惠。胜利者可以命令其他人做任何他们选择的事情。"
    quil flashy talk shock blush "任何——"
    show quil ow sweat frusta
    tom capek blow "当然，性方面的恩惠是不允许的。"
    show red amused shock
    show tom kzl
    quil skul sulk sigh "..."
    red laugh blush bunga "为什么不行？我一点前都有空。算我一个！"
    show red datar -blush -bunga
    quil cringe -sweat "算了吧。没有好处，就不干活。"
    show quil datar -sigh
    tom smile scold cling "那你呢，[povname]？敢不敢说到做到？"
    if girl:
        show p_side m at pic
    else:
        show side_p m at pic
    mc "因为如果我不玩，你就不会玩，对吧？"
    if girl:
        hide p_side
    else:
        hide side_p
    tom amused -cling "不。但我相信我能找到办法说服你加入我们，不管你愿不愿意。"
    if girl:
        show p_side m at pic
    else:
        show side_p m at pic
    mc "哼。好吧。我参加。"
    if girl:
        hide p_side
    else:
        hide side_p
    show side_p he at pic
    mc "（也许这样你就能最终放过我了。）"
    hide side_p
    show tom calm chill
    show red happy -chill
    show quil wry sigh
    if girl:
        tom "那就这么定了。"
    else:
        tom "那就这么定了。愿最优秀的人获胜。"
    scene bg_black with fade
    "于是，寻找那只神出鬼没的猫的行动开始了。"
    $ morning = False
    $ afternoon = True
    $ NPC = "???"
    scene map_all with dissolve
    jump world_map


label conclusion:
    scene bg_black with w20
    pause 2.0
    if "sucker3" in completed_quests:
        jump win
    else:
        jump lose
label lose:
    $ afternoon = False
    $ evening = True
    scene tgh_mlm_crowd with w20
    play music "MUSIC/MusMus-BGM-035.mp3"
    show red chin datar at center with moveinleft:
        yoffset 330
    play sound "sound/effects/walk.mp3"
    red happy apa "嘿，[nickname]，找猫有进展吗？"
    if "sucker3" in active_quests:
        $ active_quests.remove("sucker3")
        show screen completedtask("任务失败")
    if girl:
        show p_side f at pic
    else:
        show side_p f at pic
    mc "没有。还没有。"
    if girl:
        hide p_side
    else:
        hide side_p
    show red kaget shock at left with move
    show tom talk smile at right with moveinright:
        yoffset 190
    tom cling "不用了。今晚我是胜利者。"
    if girl:
        show p_side m at pic
    else:
        show side_p m at pic
    mc "果然如此。怎么，你期待我们匍匐跪拜？称你为主人？"
    if girl:
        hide p_side
    else:
        hide side_p
    show red frown
    tom ha -cling "嗯，虽然我很喜欢看你跪着，但不用。我相信我的胜利在这学期晚些时候会派上用场的。"
    red lelah frusta "什么，所以你就打算一直悬在我们头上？"
    show red huh -frusta
    tom amused apa "你不会这么做吗？"
    show tom smile -apa
    if girl:
        show p_side f at pic
    else:
        show side_p f at pic
    mc "随便吧。对了，奎尔在哪？"
    if girl:
        hide p_side
    else:
        hide side_p
    stop music
    play sound "sfx/sex.mp3"
    show tom capek sweat frusta
    red amused blush point sigh "这回答了你的问题吗？"
    jump begone

label win:
    $ afternoon = False
    $ evening = True
    scene tgh_mlm_crowd with w20
    play music "MUSIC/MusMus-BGM-035.mp3"
    if girl:
        show femc skul laugh blush bloom at center with dissolve:
            yoffset 100
    else:
        show palmier chill hister blush bloom at center with dissolve:
            yoffset 100
    mc "猜猜谁找到猫咪啦~！"
    if girl:
        show femc smile -bloom
    else:
        show palmier kind -bloom
    show red chin kaget shock at left with moveinleft:
        yoffset 330
    red "哦，你做到了？太好了！我还以为是阿什姆呢。"
    show red point happy -shock
    show tom talk capek at right with moveinright:
        yoffset 190
    tom frusta "不，显然猫和我相处得不太好。那个毛茸茸的怪物一直对我嘶嘶叫。"
    show tom hip frown -frusta
    if girl:
        femc mean cling "没错！所以这意味着你们两个必须听我的命令！"
    else:
        mc happy bunga "没错！所以这意味着你们两个必须听我的命令！"
    red point hister sigh "好吧，好吧！您有什么吩咐，我的主人？"
    tom chill smile blow "记住，每人只有一个恩惠。一个。"
    if girl:
        femc grin -blush -cling "我知道，我可以在任何时候使用它，对吧？没有例外？"
    else:
        mc mock -blush cling "我知道，我可以在任何时候使用它，对吧？没有例外？"
    show red amused shock
    tom ha frusta "嗯，我们没有规定时间限制，所以当然可以。"
    if girl:
        femc wry sigh "那我就把我的恩惠留着，直到我需要的时候再用。"
    else:
        mc laugh -cling "那我就把我的恩惠留着，直到我需要的时候再用。"
    show red kaget
    show tom lega blow
    red grit apa "什么，所以你就打算一直悬在我们头上？"
    show red huh frusta
    if girl:
        show femc frown -sigh
        femc "我不想浪费它。"
    else:
        mc scratch malu "好吧，我不想浪费它。"
        show palmier chill frown
    tom amused cling "明智的选择。我也会这么做。"
    show tom smile -cling
    show red frown -frusta
    stop music
    play sound "sfx/sex.mp3"
    show tom kzl shock
    show red bingung shock
    if girl:
        hide femc with dissolve
    else:
        hide palmier with dissolve

    "在你能说出其他话之前，一声非常热情的呻吟打断了你的句子。"
    jump begone
label begone:
    play music "MUSIC/MusMus-BGM-099.mp3"
    if girl:
        show p_side f at pic
    else:
        show side_p f at pic
    mc "那是什么声音？"
    if girl:
        hide p_side
    else:
        hide side_p
    show tom hip capek sweat frusta
    red chin hister both sigh "另一个奎尔正在上的新生。"
    red kaget -both apa "听声音，我猜这次他是在上面。我还以为他喜欢被人戴假阳具呢。"
    if girl:
        show p_side m at pic
    else:
        show side_p m at pic
    show red sayang blush sigh
    mc "喂，我真的不需要知道这些！"
    show red wry -sigh
    if girl:
        hide p_side
    else:
        hide side_p
    tom scold frown blow -sweat "我们也不想知道，但奎尔对这些事情并不怎么保密。"
    show red amused -blush shock
    tom ejek cling "说实话，我一直在计划在他的饮料里混入一剂强效的\'欲望终结者\'。我可以享受6个月的安静时光。"
    show red datar -shock
    if girl:
        show girl at horzappear
    else:
        show boy at horzappear
    menu:
        "那就去做吧。":
            hide girl
            hide boy
            show tom frown shock
            if "sucker3" in completed_quests:
                tom pfft apa "这是你的恩惠吗？"
            else:
                tom pfft apa "哦，这是你的恩惠吗，[nickname]？你知道我会用这个对付你的，对吧？"
            $ quil_events.append("bye_boner")
            if girl:
                show p_side f at pic
            else:
                show side_p f at pic
            mc "只要能让他闭嘴，当然可以。"
            if girl:
                hide p_side
            else:
                hide side_p
            show red datar -shock
            tom calm cling chill "那就当它完成了。"
            red point cowo blush bunga "哦！我会喜欢这个的！"
            show tom wry blow
            if girl:
                show p_side se at pic
            else:
                show side_p se at pic
            mc "好吧，我想我现在要暂时屏蔽掉房间里的声音了。晚安。"
            if girl:
                hide p_side
            else:
                hide side_p
            red grin shock "再见，[nickname]！"
            tom calm -blow "晚安。"
            stop music
            play sound "sound/effects/walk.mp3"
            scene bg_black with circleirisin

        "你还没有，因为？":
            hide girl
            hide boy
            tom sigh hip blow "为了一个恶作剧而花时间酿造太浪费了。"
            show tom frown shock
            if girl:
                show p_side f at pic
            else:
                show side_p f at pic
            mc "嗯，我有时间。你能教我怎么制作吗？"
            if girl:
                hide p_side
            else:
                hide side_p
            tom scold wry apa "哦？"
            show tom smile -apa
            red point grin apa "哈哈，想要亲自解决问题吗？"
            show red amused -apa
            if girl:
                show p_side f at pic
            else:
                show side_p f at pic
            mc "总得有人来做。"
            if girl:
                hide p_side
            else:
                hide side_p
            show red cowo blush
            tom calm blow "还有谁比你更合适呢？这是我的荣幸，[nickname]。"
            scene bg_black with circleirisin
            "这是一种相当复杂的药水，但步骤和烹饪没什么不同。"
            play sound "audio/success.mp3"
            "你现在已经学会了\'欲火熄灭\'药水的配方！"
            $ known_recipes.append("item_boner")
            stop music
    jump jigs_up

label jigs_up:
    $ evening = False
    $ night = True
    play sound "sound/effects/door.mp3"
    scene kmr_malam with circleirisout
    if girl:
        show femc skul fake cling at center with dissolve:
            yoffset 40
    else:
        show palmier chill happy cling at center with dissolve:
            yoffset 100
    mc "莱尔，你在吗？"
    if girl:
        femc sad sigh "（……太好了，他不在。）"
        show femc side -sigh
    else:
        mc apa sigh "（……太好了，他不在。）"
        show palmier deject -sigh
    scene study_mlm with dissolve
    play sound "sound/effects/drawer.mp3"
    "你打开抽屉，摆弄着伊瓦尔给你的玫瑰。"
    play music "MUSIC/MusMus-BGM-112.mp3"
    if girl:
        galleryunlock crush_f_1
        scene crush_f_1 with fade
    else:
        galleryunlock crush_m_1
        scene crush_m_1 with fade
        "摘下手套后，你注意到尽管外表如此，花瓣的触感更像是人类的皮肤而非植物。"
    if girl:
        show p_side f at pic
    else:
        show side_p f at pic
    mc "它还在流血。如果迪特里希先生说的关于这些花的话是真的，那么即使在这种形态下它们仍能感受到疼痛。"
    if girl:
        show p_side s
    else:
        show side_p s
    mc "我真的那么想知道真相吗？"
    if girl:
        hide p_side
    else:
        hide side_p
    if girl:
        show girl at horzappear
    else:
        show boy at horzappear
    menu:
        "捏碎它":
            $ main.points -= 1
            hide girl
            hide boy
            if girl:
                show p_side s at pic
            else:
                show side_p s at pic
            mc "就这样吧。"
            if girl:
                hide p_side
            else:
                hide side_p
            play sound "sound/effects/crumple.mp3"
            $ my_events.append("crush_bung")
            if girl:
                scene crush_f_2 with vpunch
                galleryunlock crush_f_2
            else:
                scene crush_m_2 with vpunch
                galleryunlock crush_m_2
            "鲜血淹没了你的手。"
            play sound "sound/effects/grow.wav"
            if girl:
                scene crush_f_3 with dissolve
                galleryunlock crush_f_3
            else:
                scene crush_m_3 with dissolve
                galleryunlock crush_m_3
            "当你捏碎花朵的瞬间，一个新的花蕾绽放了。颜色比之前的玫瑰更加鲜艳。"
            if girl:
                show p_side s at pic
            else:
                show side_p s at pic
            mc "它很美。可惜我想你会不同意吧？如果我伤到你了，我很抱歉。"
            if girl:
                hide p_side
            else:
                hide side_p
            scene study_mlm with dissolve
            if girl:
                show p_side f at pic
            else:
                show side_p f at pic
            mc "不过我没有感觉有什么不同，难道伊瓦尔说谎了——"
            stop music
            play sound "sound/effects/summon.mp3"
            if girl:
                show p_side s
            else:
                show side_p s
            mc "啊！！！" with vpunch
            if girl:
                hide p_side
            else:
                hide side_p
            play music "sound/effects/jantung.mp3"
            "你刚说出这些话，一阵剧烈的疼痛就刺穿了你的头部。"
            scene map_kamar with dissolve
            play sound "sound/effects/cloth.mp3"
            "你摇摇晃晃地走到床边，让黑暗吞噬了你。"

        "不去管它":
            hide girl
            hide boy
            if girl:
                show p_side f at pic
            else:
                show side_p f at pic
            mc "我不应该相信一个杀人犯的话。"
            scene study_mlm with dissolve
            play sound "sound/effects/drawer.mp3"
            "你把花放回抽屉里。"
            if girl:
                show p_side se at pic
            else:
                show side_p se at pic
            mc "明天我就把你种到外面去，也许那能给你带来一些安宁。"
            mc "现在，我该去睡觉了。"
            if girl:
                hide p_side
            else:
                hide side_p
            scene map_kamar with dissolve
            play sound "sound/effects/cloth.mp3"
            "你摇摇晃晃地走到床边，让黑暗吞噬了你。"
    scene bg_black with wet
    hide screen cal
    pause 3.0
    play music "MUSIC/MusMus-BGM-110.mp3"
    if not girl:
        galleryunlock m_21
        play sound "sound/effects/walk.mp3"
        show 2_1 at left with moveinleft
        $ renpy.pause()
        show 2_2 at right with moveinright
        $ renpy.pause()
        show 2_3 with flashbulb:
            yalign 1.0
            linear 10.0 yalign 0.0
        $ renpy.pause()
        scene bg_black with dissolve
        show 2_4 at left with moveinleft
        $ renpy.pause()
        show 2_5 at right with moveinright
        $ renpy.pause()
        galleryunlock butt_pinch
        scene bg_black with dissolve
        show dua_6 at left with moveinleft
        $ renpy.pause()
        galleryunlock kill_me
        show 2_7 at right behind dua_6 with moveinright
        $ renpy.pause()
        scene bg_black with dissolve
        show 2_8 with flashbulb:
            yalign 0.0 xalign 0.5
            easeout 7.0 yalign 1.0
        pause 6.0
        scene bg_white with flashbulb
        pause 1.0
    else:
        galleryunlock 2_1_g
        scene 2_1_g with dissolve:
            yalign 0.0
            linear 7.0 yalign 0.9
        show mc_sh2 at pic
        mc "奎尔……住手，你不能这么做！"
        hide mc_sh2
        show q_party at pic
        quil "做什么？难道你看不出来我是在试图帮助你，我的朋友？"
        quil "让我们把那个寄生的巫师从你身上除掉，嗯？"
        hide q_party
        show mc_sh2 at pic
        mc "不，住手，你会杀了我的！"
        hide mc_sh2
        scene bg_black with fade
        show 2_2_g at left with moveinleft
        $ renpy.pause()
        show 2_3_g at right with moveinright
        $ renpy.pause()
    stop music fadeout 2.0
    galleryunlock g_last
    scene bg_black with wet
    show screen cal
    play sound "sound/effects/jantung.mp3"
    scene atap with vpunch
    if girl:
        show p_side m at pic
    else:
        show side_p m at pic
    mc "哈！"
    if girl:
        show p_side s
    else:
        show side_p s

    mc "奎尔……奎尔骗了我。"
    $ bff.points = 0
    stop sound
    if girl:
        hide p_side
    else:
        hide side_p
    play sound "sound/effects/punch.mp3"
    scene bed_alter with vpunch
    if girl:
        show p_side m at pic
    else:
        show side_p m at pic
    mc "呃！"
    scene atap with vpunch
    play music "MUSIC/PerituneMaterial_Piano_Sad2.mp3"
    play sound "sound/effects/cloth.mp3"
    "当你坐起来时，一双有力的手掐住了你的脖子，将你重新按回床上。"
    show final1 at center with dissolve
    galleryunlock final1
    "你抬头看到奎尔，他眼中闪烁着狂野的神色。"
    quil "你发现了，是吗？"
    if girl:
        show p_side s at pic
    else:
        show side_p s at pic
    mc "什么——"
    if girl:
        hide p_side
    else:
        hide side_p
    quil "我想你们这些[povname]都是这样的。"
    show final2 at center with dissolve
    galleryunlock final2
    quil "太过好奇，以至于害了自己。"
    if girl:
        show p_side s at pic
    else:
        show side_p s at pic
    mc "唔——！"
    play sound "sound/effects/cloth.mp3"
    hide side_p
    hide p_side
    quil "别担心，我不会杀你的。我只会在你身上放一个小小的记忆符文，让你忘记我那微不足道的失误。"
    scene bed_alter with dissolve
    if girl:
        show palmierproxy chill grit at left with dissolve:
            yoffset 40
    else:
        show palmierproxy chill grit at left with dissolve:
            yoffset 100
    show quil skul frown at right with dissolve:
        yoffset 200
    $ mc = Character('[povname]', callback=name_callback, cb_name='mc', image='palmierproxy')
    mc shock "你把朋友弄成昏迷状态，还说是微不足道的失误？！"
    quil tantrum sigh "只是一个小小的挫折而已。"
    show quil bingung frusta
    mc kzl frusta "是吗？那如果你的符文再次失效，我最后落得和你的[povname]一样的下场怎么办？！"
    quil err sweat -frusta "..."
    show quil sulk sigh 
    "他终于露出了困扰的表情，不再展现平常那副自负的态度。"
    show pboy at horzappear
    menu:
        "用头撞他":
            hide pboy
            $ honesty += 20
            $ kindness -= 10
            $ quil_events.append("punch")
            show quil -sweat grit shock with vpunch
            show palmierproxy grit -frusta with vpunch
            stop music
            play sound "sound/effects/thump.wav"
            "趁奎尔犹豫的时候，你抓住他的衣领，{i}狠狠地{/i}用头撞向他"
            quil sweat tantrum frusta "噢！搞什么鬼？！"
            play sound "sound/effects/punch.mp3"
            "但这还不是全部。你终于做了自从这个瘦弱的混蛋把你召唤到这个世界以来就想做的事。"
            scene bed_alter with vpunch
            "你抓住他的一把头发，朝他的下巴挥出一拳。"
            "奎尔踉跄着从你身上退开，让你得以从床上起来。"
            show quil sad at right with dissolve:
                yoffset 200
            quil ow sweat shock "哇！哇！暂停，暂停！别打脸！别打脸！"
            quil sulk frusta "事实上根本别打我，妈的太疼了！"
            if girl:
                show palmierproxy mock at left with dissolve:
                    yoffset 40
            else:
                show palmierproxy mock at left with dissolve:
                    yoffset 100
            if girl:
                mc "活该！"
            else:
                mc cling "怎么了，奎尔？以前从没打过架吗？"
            show palmierproxy mean -cling
            quil grit "没有！我们有符文魔法是有原因的。当我可以用..."
            show palmierproxy kzl
            quil err -frusta "严格来说还是用手——手指，你知道我的意思。该死——！"
            quil sulk sigh "我的下巴真的很疼。"
            mc frusta "哦，是吗？对不起，我只是想阻止你杀了我，奎尔！"
            quil bingung apa -sweat "我不是想杀你！只是想抹去你的一些记忆。"
            mc grit -frusta "这不是一回事吗！"
            show quil sad shock

        "试图与他讲道理":
            hide pboy
            $ kindness += 20
            $ curiosity += 5
            mc sad frusta "听着，如果你想让我配合，你就得开始说实话。"
            mc confused sigh "真正地说！不是那些含糊其辞的抱怨或你那些尴尬的长篇大论。"
            stop music
    quil sulk -sweat sigh "哈啊..."
    show palmierproxy kzl
    play music "MUSIC/MusMus-BGM-025.mp3"
    quil sad -sigh "看起来很糟糕，我知道看起来很糟糕。但我发誓我所做的一切都是为了[nickname]。"
    quil "[nickname]的契约，嗯...不太对劲。我看得出[nickname]没有适应这个契约。"
    show palmierproxy apa shock
    quil frown "我以为[nickname]表现奇怪是因为[dia]分手了。"
    show palmierproxy frown -shock
    quil rajuk "起初我以为[kamu]只是因为结束得不好而感到难过，但是...酗酒、抽烟，[dia]的眼睛下面的那些黑眼圈。"
    quil sulk sweat "[povname]，[kamu]...在我庄园度假时[kamu]甚至开始咳血。"
    quil sad "只是血不是红色的，而是黑色的。纯黑色...几乎像墨水一样。"
    show palmierproxy ow shock sweat
    quil sigh "一个人类根本无法维持纯血巫师的契约。当巫师建立契约时，他们共享一个身体。"
    show palmierproxy sad -shock -sweat
    quil sulk frusta -sweat "主导者保持他们的形态，而另一个则成为他们的影子。如果一切顺利，影子会保持同步。"
    quil err -frusta "但有一天晚上，我看到[povname]在叫[dia]的妈妈。"
    if girl:
        galleryunlock demon_f
        show demon_f with fade:
            truecenter zoom 1.5
            easein 2.0 truecenter zoom 0.5
    else:
        galleryunlock demon
        show demon with fade:
            truecenter zoom 1.5
            easein 2.0 truecenter zoom 0.5
    if girl2:
        quil "我能看到两个影子，都在争夺主导权。[povname]的影子被[dia2]那个恶魔巫师掐住了脖子。"
    else:
        quil "我能看到两个影子，都在争夺主导权。[povname]的影子被[dia]那个恶魔巫师掐住了脖子。"
    if girl:
        hide demon_f with dissolve
    else:
        hide demon with dissolve
    if girl2:
        mc grit sweat "所以他们的契约正在杀死[dia]。"
    else:
        mc grit sweat "所以他们的契约正在杀死[dia2]。"
    show palmierproxy confused
    quil mock sweat "是的。我试图帮忙，研究了我家族图书馆里所有能找到的符文。但看来我的自负终于让我栽了跟头。"
    quil sulk sigh "我搞砸了，而且搞得很厉害。这就是全部经过。"
    show quil sad -sigh
    mc scratch side sigh "你知道，你本可以事先把这些都说出来的。你不必对我玩刺客那一套。"
    show palmierproxy frown chill -sweat
    quil flashy cringe -sweat cling "哦，相信我，这不是故意的，亲爱的。"
    quil mock sigh "事实上，你才是导致我在这里的罪魁祸首。"
    mc eiden tanya scratch"我？"
    show palmierproxy avoid shock 
    quil ejek skul apa "你昨天是不是搞砸了你的梦境保护符文？"
    mc ha sweat -shock "呃...可能是吧。怎么了？"
    show palmierproxy apa chill
    if "crush_bung" in my_events:
        quil rajuk sigh "莱尔看到伊瓦尔的花掉在地上。那个魁梧如熊的男人差点心脏病发作，冲出了房间。"
        quil talk -sigh "幸运的是，他在通知其他人之前先遇到了我。"
        mc panik shock "（哦，我一定是在昏倒后把伊瓦尔的花掉在地上了。）"
        
    else:
        quil rajuk sigh "莱尔回到你的房间，听到从你的书桌抽屉里传来啜泣声。"
        quil sad frusta "他发现了伊瓦尔的玫瑰，陷入了完全的恐慌，冲出了房间。"
        quil frown -frusta "幸运的是，他在通知其他人之前先遇到了我。"
        mc side "（哦，可怜的莱尔。我没想到他会发现那朵玫瑰。）"
    show quil datar
    mc sad tanya -sweat "他现在在哪里，他还好吗？"
    show palmierproxy frown -tanya
    quil laugh cling "我相信阿什姆正在安抚他。别担心。尽管阿什姆总是说些尖锐的话，但他确实是我们这群人中的\'妈妈\'。"
    show quil datar -cling
    mc confused tanya "莱尔不会泄露关于那朵花的事吧？"
    show palmierproxy frown -tanya
    quil wink flashy spark "哦，我确保莱尔暂时会保守秘密。"
    quil skul groan frusta "顺便说一句，别以为你能转移我的注意力。你还没告诉我你是怎么得到那朵花的。"
    mc huh sweat scratch "（是你自己跑题的。）"
    if "punch" in quil_events:
        mc ew frusta "听着，那天晚上我弄脏了我的符文，好吗？伊瓦尔进入了我的梦境，送给我那朵花来揭露你的秘密。"
        show palmierproxy frown shock -sweat
        quil bingung apa "我的秘密？"
        mc rajuk chill -shock "那朵玫瑰...是新郎的记忆。你知道的，那个巫师婚礼上的新郎。"
        quil rajuk sigh "哦，那个出轨的新郎。我都忘了他。你是说他死了？"
        show quil kzl shock
        mc sad "伊瓦尔把他变成了一个花仆。"
        quil sulk sweat -shock "可怜的家伙，虽然不能说他不是自作自受。不过，这解释了为什么莱尔会吓坏了。"
        quil kzl -sweat apa "他还说了我什么别的吗？"
        mc confused sweat frusta "他说你们都是罪人，我不应该相信你们。老实说，我现在有点明白他的观点了。"
        quil laugh flashy spark "可以理解。但我向你发誓，我不会伤害你的...至少现在不会。"
        mc avoid sigh "哦，这话说得{i}真是{/i}让人安心啊，奎尔。"
        show palmierproxy wry
        quil ow sweat frusta skul "好吧，你至少可以相信我不会再在你睡觉时袭击你了。哦科尔，我想你打断了我的下巴。"
        mc eiden sigh "你还能说话，所以很遗憾并没有。不过让我看看。"
        show palmierproxy wry -sweat -sigh at center with move
        show quil bingung shock
        mc apa shock sweat "哇，确实挺红的，是吧？开始有点肿了。我不是故意打得{i}那么{/i}重的。"
        quil panik both frusta "呃...你非得凑那么近检查吗？"
        stop music
        mc sad tanya -sweat "嗯？嗯，是啊。不然我怎么能..."
        show malu with dissolve
        galleryunlock malu
        play sound "sound/effects/cloth.mp3"
        mc "（哦...）"
        mc "（他脸红得厉害。）"
        "奎尔的脸红到了耳朵，你甚至能听到他急促的心跳声。"
        mc "（我以为像他这样的花花公子不会被这种事影响。）"
        mc "（可他现在连看我的眼睛都做不到。这有点...可爱。）"
        hide malu with dissolve
        show pboy at horzappear
        menu:
            "把他拉得更近":
                hide pboy
                show quil err shock 
                show palmierproxy hister bunga with move:
                    xalign 0.6
                mc "你知道这里挺黑的，我真的需要看得更仔细些。"
                quil sulk -shock "更-更近？！"
                show quil sad with move:
                    xalign 1.0
                show palmierproxy smile with move:
                    xalign 0.8
                quil frusta "你不觉得够了吗？！说真的，住手[povname]！[povname]！！！"
                show palmierproxy apa sweat shock
                quil fluster "啊啊啊啊啊啊！！！"
                play sound "sound/effects/bump.mp3"
                scene bed_alter with vpunch
                "伴随着一声尖叫，奎尔用尽全力用额头撞向你。"
                show side_q skul kzl at pic
                quil "我说够了，你这个变态！"
                hide side_q
                "然后他冲出了门。"
                play sound "sound/effects/doorslam.mp3"
                show side_p a at pic
                mc "（我想我做得太过了。不过现在已经无法否认了...）"
                hide side_p
                show palmierproxy happy blush bloom at center with dissolve:
                    yoffset 100
            "嘲笑他的反应":
                hide pboy
                stop music
                mc wry tanya "有什么问题吗？你不是应该习惯这种事了吗？"
                show palmierproxy -tanya
                if not girl:
                    mc eiden sigh "我在梦里可是亲眼看到你坐在[nickname]身上捏[dia]屁股。"
                    show palmierproxy frown shock
                    quil ow both "那不一样！我认识[nickname]的时候[kamu]还尿床呢，你又不是我的[povname]！"
                quil sulk sweat shock "啊！"
                show quil wry -shock 
                "似乎刚刚意识到自己的奇怪行为，他清了清嗓子，冷静了下来。"
                quil flashy talk "我是说...气氛不对而已。你是不是把我们之间的紧张气氛误解成性张力了？"
                quil wink -sweat "我知道待在我这样的性感偶像身边很难，但是..."
                mc confused sweat "（这种反应，我以前见过。）"
                mc "（就像菲亚在她所有朋友都开始约会时，撒谎说自己有个\'外国男朋友\'那样。）"
                mc rajuk -sweat"（不会吧。别告诉我他是...）"
                show quil sad shock
                mc frown tanya "奎尔，你真的做过爱吗？就是那种全套的？"
                quil skul avoid both "什么？我当然做过。你问任何人——我显然是——"
                quil err "...我得走了！"
                play sound "sound/effects/doorslam.mp3"
                scene bed_alter with vpunch
                "你几乎能看到奎尔的鞋子因为逃离房间的速度太快而扬起阵阵尘土。"
                show palmierproxy malu sigh at center with dissolve:
                    yoffset 100
                mc "（好吧...现在已经无法否认了。）"
                show palmierproxy happy blush bloom

    else:
        mc kzl sweat frusta "我很乐意告诉你这件事，但首先..."
        stop music
        play sound "sound/effects/cloth.mp3"
        if girl:
            show squeeze_cew with dissolve
            galleryunlock squeeze_cew
            mc "你能放开我了吗？"
        else:
            show squeeze:
                yalign 1.0
                linear 1.0 yalign 0.0
            galleryunlock squeeze

            mc "你能从我身上下来了吗？你压得我骨盆都要碎了。"
            mc "（我是很高兴他解释清楚了，但他没必要一直坐在我身上啊。）"
        quil "啊！"
        quil "你-你为什么那样摸我？！"
        mc "呃...让你下来啊？"
        quil "让我下来？？？你说的\'让我下来\'是什么意思，你这个变态？！"
        mc "（啊？明明是你自己想歪了吧。）"
        mc "我是说从我身上下来！"
        mc "（而且他这反应是怎么回事？他不是应该在床上很\'有经验\'吗？）"
        mc "（你以为他会习惯这种事的。除非...）"
        play music "MUSIC/MusMus-BGM-006.mp3"
        show pboy at horzappear
        menu:
            "继续逗他":
                hide pboy
                mc "（也许我可以……）"
                
                mc "奎尔，你想让我帮你解决吗？"
                quil "什-什么？！"
                if girl:
                    hide squeeze_cew with dissolve
                else:
                    hide squeeze with dissolve
                show palmierproxy mean at center with move
                mc mock blush cling "（……让他也尝尝自己的苦头。）"
                show quil ow both shock
                mc kind spark "如果你想的话，我可以帮你……"
                play sound "sound/effects/bang.mp3"
                show quil panik -shock
                show palmierproxy sad sweat shock 
                "奎尔立即从你身上跳开，滚到了地板上。"
                mc ow sweat tanya "哎呀！你没事吧？"
                show palmierproxy huh -tanya
                quil sulk both "不-不，我-我！！！"
                #bump sound
                quil ow "啊啊啊啊啊啊！！！"
                play sound "sound/effects/bump.mp3"
                scene bed_alter with vpunch
                "伴随着一声尖叫，奎尔用尽全力用额头撞向你。"
                show side_q skul kzl at pic
                quil "别靠近我，你这个变态！"
                hide side_q
                "说完就跑出了门。"
                play sound "sound/effects/doorslam.mp3"
                show palmierproxy malu sigh at center with dissolve:
                    yoffset 100
                mc "（我想我做得太过了，不过现在已经无法否认了。）"
                show palmierproxy hister blush bloom

            "直接问他":
                hide pboy
                if girl:
                    hide squeeze_cew with dissolve
                else:
                    hide squeeze with dissolve
                show quil sad shock
                mc confused tanya "有什么问题吗？你不是应该习惯这种事了吗？"
                show palmierproxy -tanya
                if not girl:
                    mc wry sweat sigh "我在梦里可是亲眼看到你坐在[nickname]身上捏[dia]屁股。"
                    show palmierproxy frown -sigh -sweat
                    quil ow both frusta "那不一样！我认识[nickname]的时候[kamu]还尿床呢，你又不是我的[povname]！"
                quil sulk sweat shock "啊！"
                show quil wry -shock 
                "似乎刚刚意识到自己的奇怪行为，他清了清嗓子，冷静了下来。"
                quil flashy talk "我是说...气氛不对而已。你是不是把我们之间的紧张气氛误解成性张力了？"
                quil wink -sweat "我知道待在我这样的性感偶像身边很难，但是..."
                mc confused sweat "（这种反应，我以前见过。）"
                mc "（就像菲亚在她所有朋友都开始约会时，撒谎说自己有个\'外国男朋友\'那样。）"
                mc rajuk -sweat "（不会吧。别告诉我他是...）"
                show quil sad shock
                mc frown chill tanya "奎尔，你真的做过爱吗？就是那种全套的？"
                quil skul avoid both "什么？我当然做过。你问任何人——我显然是——"
                quil err frusta "...我得走了！"
                play sound "sound/effects/doorslam.mp3"
                scene bed_alter with vpunch
                "你几乎能看到奎尔的鞋子因为逃离房间的速度太快而扬起阵阵尘土。"
                show palmierproxy malu sigh at center with dissolve:
                    yoffset 100
                mc "（好吧...现在已经无法否认了。）"
                show palmierproxy happy blush bloom
    mc hister "奎尔是个处男。哦，这下有意思了！"
    stop music
    jump pagi_3
label pagi_3:
    scene bg_black with w20
    $ calendar.next() #RABU W1 17
    $ night = False
    $ morning = True
    play music "MUSIC/MusMus-BGM-007.mp3"
    scene kantin with w20
    $ quil_events.append("day3")
    if girl:
        show palmierproxy smile at left with dissolve:
            yoffset 40
    else:
        show palmierproxy smile at left with dissolve:
            yoffset 100
    mc happy blush "奎尔，把盐递给我好吗？"
    show palmierproxy smile
    show quil flashy talk cling at right behind palmierproxy with dissolve:
        yoffset 200
    quil "当然，亲爱的[nickname]。"
    show quil avoid sweat -cling
    show palmierproxy kind
    "尽管表现如常，奎尔在递盐时还是警惕地看着你。"
    show quil ow shock
    show palmierproxy hister bloom with move:
        xalign 0.65
    "在递盐的过程中，你故意轻轻擦过他的手，深情地抚摸着。"
    quil skul heh -sweat apa "今天很喜欢动手动脚啊，[nickname]？终于被我的魅力征服了？"
    show quil bingung shock
    mc mean -blush cling "如果是这样呢？也许我昨晚终于看到了{i}真实的{/i}你，奎尔。"
    show quil tantrum both frusta
    "奎尔转过头去，看起来很恼火。"
    mc hister bunga  "（被人这样对待的感觉不好受吧？）"
    scene kantin with dissolve
    show red chin bingung sweat at left with dissolve:
        yoffset 330
    show tom hip ew sweat frusta at right with dissolve:
        yoffset 190
    "与此同时，塞恩和阿什姆目瞪口呆地盯着你。塞恩一脸困惑，阿什姆则怒火中烧。"
    show tom ha 
    red hister both apa "那么，呃……你们俩看起来相处得不错。"
    show red amused sweat -apa
    tom capek blow -sweat "好得让人难以忍受。"
    show tom kzl frusta
    show red huh 
    show side_p se at pic
    mc "哦，我只是对我这个{i}放荡的{/i}童年好友友好一点而已。"
    mc "老兄，你到底和多少人上过床？几百个？"
    mc "能给我列举几个名字吗？"
    hide side_p
    show quil flashy wink sweat at center with dissolve:
        yoffset 200
    quil "哦，嗯，我是说，实在太多了，我——"
    show quil ow shock
    show side_p w at pic
    mc "连一个名字都说不出来，真的吗奎尔？一个都没有？"
    hide side_p
    quil sly -shock "浪漫不是我的强项，[nickname]。快速来一发就行了，但说实话，我们能换个话题吗？"
    quil cringe sigh -sweat "我的性生活可不是早餐时该讨论的合适话题。"
    if "salad" in my_events:
        red mock point cling "昨天你拿着香肠的时候可没觉得不合适。"
        quil skul avoid sweat frusta "那是不同的情况，塞恩。"
    show quil frown -sweat shock
    show red kaget sweat shock
    play sound "sound/effects/bang.mp3"
    tom scold ew -frusta "够了！"
    show red frown -shock
    show quil frown -shock
    tom capek blow "与其讨论奎尔糟糕的床上礼仪，[nickname]，你不觉得我们有更重要的事要谈吗？"
    show side_p he at pic
    mc "啊？"
    hide side_p
    show red point -sweat
    show quil skul
    tom talk frown apa "昨晚莱尔到底怎么了？"
    tom sad -apa "他完全慌了神，却不肯解释原因。"
    show side_p s at pic
    mc "哦，嗯……他有时会做关于他父亲的噩梦。我想昨晚的梦特别强烈。"
    hide side_p
    tom ha apa "我明白了。真的就这样吗？"
    show side_p he at pic
    mc "（糟糕，他是不是察觉到了什么？）"
    hide side_p
    show tom frown
    show pboy at horzappear
    menu:
        "你为什么这么在意？":
            hide pboy
            show red bingung shock
            show quil amused shock
            tom eh blow "他和我一样是混血儿，这就是原因。虽然种族不同，但仍然如此。"
            show quil datar -shock
            show red wry -shock
            tom capek -blow "而且我们的背景相似，尽管我至少有幸不认识我的父亲。"
            tom amused cling "我觉得让他在我的庇护下是最有利的。对我们双方都有好处。"
            show tom kzl -cling
            red chin mock cling "伙计，你直说你关心那家伙，想当他妈妈不就得了，反正你一向如此。"
            show tom capek
            red cowo bunga point "我是说，你昨晚还给他烤了新鲜的饼干。你甚至还做了热可可，上面还撒了烤过的小棉花糖。"
            show tom eh both shock
            show quil malu sweat 
            red hister "更别提你还穿着那件粉色围裙，上面写着\'喂饱我，告诉我我很漂亮\'，就为了逗他笑——"
            $ ibu.points += 5
            show tom amused -both -shock
        "对塞恩无声地说\"救命\"":
            hide pboy
            $ mrh.points += 5
            show quil amused
            show tom kzl -apa
            red amused sigh "算了吧，伙计，如果[nickname]说他们只知道这些，那就到此为止吧。"
            show tom eh shock
            red wry -sigh "说真的，你就不能像昨晚那样吗？"
            show tom kzl both
            red cowo bunga "你知道吗，我看到你在厨房里，穿着那件粉色围裙，为孩子烤饼干、做热可可。"
            show tom capek frusta
            red grin cling "为什么不换个方式，向我们展示一下你那母性的一面呢——"
            show tom amused -both -frusta
           
        "瞥了奎尔一眼":
            hide pboy
            show quil flashy sly cling
            show red sad
            "奎尔无声地说了句\'去吃屎\'，然后继续狼吞虎咽地吃着他的土豆饼。"
            show quil skul laugh bloom
            show side_p m at pic
            mc "（该死的小气处男。）"
            hide side_p
            show red wry shock
            "幸好塞恩似乎注意到了你需要帮助。"
            show tom kzl -apa
            red amused sigh "算了吧，伙计，如果[nickname]说他们只知道这些，那就到此为止吧。"
            show tom eh shock
            red wry -sigh"说真的，你就不能像昨晚那样吗？"
            show quil amused shock
            show tom kzl both
            show quil malu sigh
            red cowo bunga "你知道吗，我看到你在厨房里，穿着那件粉色围裙，为孩子烤饼干、做热可可。"
            show tom capek frusta
            show quil hister -sigh
            red grin cling "为什么不换个方式，向我们展示一下你那母性的一面呢——"
            show tom amused -both -frusta
    play sound "sound/effects/bang.mp3"
    red perih shock "哦！"
    show quil hister blush sigh
    "阿什姆踢了塞恩的小腿一脚，桌子下传来一声响亮的撞击声。"
    show quil datar -sigh
    show tom pfft
    red ngeles frusta "又来？伙计，学着接受赞美吧！"
    show red ew sweat 
    
    stop music
    scene kantin with dissolve
    "当你咯咯笑着时，你听到有人反复敲击玻璃杯，呼唤你们的注意。"
    play sound "sound/effects/walk.mp3"
    show hm talk at center with dissolve:
        yoffset 190
    hm "同学们，请允许我占用你们一点时间。"
    show hm smile
    play music "MUSIC/MusMus-BGM-059.mp3"
    "一位高大、威严的男子从教师用餐区站了起来。他一定是校长。"
    hm talk "咳咳。欢迎新老同学们来到伊格尼亚猎巫人学院，开始新的学期。"
    hm amused "作为校长，我知道我这学期的问候来得有些晚。不过，我一直在为教会履行职责，就像你们将来也会做的那样。"
    hm laugh "如你们所知，没有比为国效力更崇高的职责了。这是一项并非所有人都敢于承担的责任。"
    hm talk "因此，我要感谢你们所有人。感谢你们的服务、时间和牺牲。"
    hm mock "愿你们能培养自己的技能，以实现科尔夫人的梦想……一个没有她同类的世界。"
    hm talk "索拉里斯·艾格纳！"
    show hm smile
    $ NPC = "学生们"
    npc "索拉里斯·艾格纳！"
    $ NPC = "???"
    hide hm with dissolve
    show side_p he at pic
    mc "..."
    show side_p s
    mc "（我完全不知道刚才发生了什么。）"
    hide side_p
    "说了很多，但理解的却很少。你立即在桌子下给奎尔发了条私信。"
    $ interlocutor = "Quill"
    $ del_all_msg()
    hide window
    show hp at move_messenger2
    pause 1.0
    $ show_messenger()
    $ click_to_continue = True
    $ msg ("索拉里斯·艾格纳是什么意思？")
    $ msg ("杀死所有巫师。据传闻，这是科尔在死前试图创造的一个咒语。", who=1)
    $ msg ("所以他演讲中才有\'没有她同类的世界的梦想\'这一部分。", who=1)
    $ msg ("如果你问我的话，这有点过分了。所以，你对兄弟姐妹又爱又恨，谁不是呢？", who=1)
    $ msg ("你不是很虔诚，对吧？")
    $ msg ("我们大多数人都不是。很多人成为猎巫人不是为了服务教会，而是因为这是我们这种人能得到的薪酬最高的工作。", who=1)
    $ msg ("要么这样，要么就去沃特克成为吸血鬼的牲畜。就我个人而言，我宁愿猎杀巫师，也不愿成为那些人形蚊子24/7的血袋。", who=1)
    $ msg ("好吧，你这么说的话……")
    $ hide_messenger()
    hide hp
    show hp2 at move_messenger3
    pause 1.0
    
    if "shriek" in topics:
        show hm smile at center with dissolve :
            yoffset 190
        hm amused "哦，还有一件事。这是对我的新生们的警告，也是对其他可能需要的人的警告。"
        hm complain "在我的办公室里，有一个叫做\'女妖之悲\'的东西。那是一个包含着女妖在她们不幸死亡前的哭声的球体。"
        hm bingung "如果你们中有人进入我的办公室，碰触了那个球体，而不知道那是什么……"
        hm ketawa "……请立即来找我，因为那些听到这些哭声的人会在72小时内遭受最痛苦和最可怕的死亡。"
        hm laugh "你们可能会问有多痛苦？哈哈，嗯……"
        if girl:
            hm mock sweat "……你的子宫会脱垂，肠子会从你的菊花里掉出来。"
            hm yell -sweat sigh "说真的，你会度过一段非常不愉快的时光。"
        else:
            hm mock sweat "……你的蛋蛋会爆炸，肠子会从你的菊花里脱垂出来。"
            hm yell -sweat sigh "说真的，你会度过一段非常不愉快的时光。"
        hm laugh -sigh "但如果你来找我，我有一根受过祝福的海妖羽毛，可以治愈你并洗清你的罪孽。"
        hm talk "就这样，我的学生们。对于那个偷偷溜进我办公室的可怜迷途之人，愿科尔与你同在。"
        show hm bet
        mc "..."
        hide hm with dissolve
        show side_p s at pic
        if girl:
            if girl2:
                mc "（子宫脱垂？！）"
            else:
                mc "（他说什么？！）"
        else:
            if not girl2:
                mc "（我的蛋蛋会爆炸？！）"
            else:
                mc "（他说什么？！）"
        hide side_p
        show red hister at left with moveinleft:
            yoffset 330
        red "听到了吗，[nickname]？我想知道是哪个白痴敢碰威廉校长的东西？"
        show tom hip pfft at right with dissolve:
            yoffset 190
        show red bingung shock
        tom "哦，我想[kamu]听到了，塞恩。"
        show red sad -shock
        tom wry scold blow "[nickname]，你想让我带你去见威廉校长吗？"
        show pboy at horzappear
        menu:
            "是的，拜托了！":
                hide pboy
                red hister blush "等等，[nickname]你是认真的吗？！我的天啊！"
                show side_q skul smile at pic
                quil "哇，你真是个白痴！"
                hide side_q
                tom ew frusta "哦，你们两个闭嘴。我相信[povname]这么做一定有原因。"
                show red wry -blush
                tom chill wry blow "别理他们。来吧，我们走，[nickname]。"
                $ ibu.points += 10
                scene bg_black with w20
                jump tom_to_office
            "装傻":
                hide pboy
                show side_p he at pic
                show red datar 
                mc "我不知道你在说什么。"
                show side_p s
                mc "（该死，该死，该死！哦，操！）"
                hide side_p
                tom hip sigh blow "...好吧。"
                show tom frown -blow
                show side_p s at pic
                mc "（该死，该死，该死。这事过后你肯定要去校长办公室了！）"
                hide side_p
                stop music
                scene bg_black with w20
                play sound "sound/effects/walk.mp3"
                jump solo_to_office

    else:
        show red chin kaget at left with moveinleft:
            yoffset 330
        red apa "我在想教会给他派了什么任务。"
        show tom talk frown at right with dissolve:
            yoffset 190
        tom blow "我猜是又有关于纯血巫师的线索。"
        show red cowo -apa bloom
        show tom hip lega bunga
        "就这样，你们简单聊了些琐事，然后你就去上下一节课了。"
        hide tom with moveoutright
        show red point grin at center with move
        "看了看手机上的课程表，你注意到下一节课是草药疗法。"
        "转眼间，塞恩搭着你的肩膀带你去上课。"
        scene bg_black with w20
        play sound "sound/effects/walk.mp3"
        stop music
        jump red_herb
label solo_to_office:
    scene map_classes1 with w20
    "鼓足勇气后，你前往威廉校长的办公室。"
    "你希望他的治疗方法不会太痛苦。"
    play sound "sound/effects/window_knock.mp3"
    hm "是的？"
    show side_p s at pic
    mc "我是[povname]贝克，呃...我就是那个碰了你地球仪的白痴。"
    hide side_p
    hm "哦！是的，请进。"
    play sound "sound/effects/door.mp3"
    show hm_room with dissolve
    "当你进入房间时，你注意到自从你上次闯入后，这里发生了变化。"
    "房间看起来更明亮了，而你碰过的那个球体看起来比以前更加诡异。"
    "是因为校长回来了吗？"
    scene hm_desk with dissolve
    play music "MUSIC/MusMus-BGM-064.mp3"
    show hm wry at center with dissolve:
        yoffset 190
    hm "你好，年轻的贝克。"
    hm confused sweat sigh "我必须说我对你很失望，[povname]。难道你母亲没教过你不要碰不属于你的东西吗？"
    show side_p s at pic
    mc "对不起。"
    hide side_p
    hm ketawa -sweat "好吧，既然已经发生了。请伸出你的手。"
    show hm amused
    if girl:
        show siren_feather_f with flashbulb
    else:
        show siren_feather with flashbulb
    "你按照指示伸出了手。校长将一根羽毛放在你的手掌上。"
    if girl:
        show siren_feather2_f with dissolve
    else:
        show siren_feather2 with dissolve
    "几秒钟内，你又听到了那些耳语。一种黑色物质开始从你的皮肤渗出。" 
    if girl:
        show siren_feather3_f with dissolve
    else:
        show siren_feather3 with dissolve
    "羽毛吸收了所有的黑色物质，变成全黑色，然后化为灰烬。"
    scene hm_desk with dissolve
    show hm wry at center with dissolve:
        yoffset 190
    hm "事情已经完成了，孩子，你感觉如何？"
    show side_p s at pic
    mc "其实有点晕。哦——！"
    stop music
    play sound "sound/effects/crash.mp3"
    scene bg_black with vpunch
    pause 1.0
    scene hm_couch with eye_open
    "你醒来时发现自己躺在房间里一张豪华沙发上。抬头看，你能看到天花板上的符号。它微微发光。"
    scene hm_couch2 with dissolve
    show hm frown at center with dissolve:
        yoffset 190
    play sound "sound/effects/cloth.mp3"
    "在你右边，你看到校长正在脱下你的手套。"
    show side_p m at pic
    mc "先生？"
    play music "MUSIC/MusMus-BGM-101.mp3"
    hide side_p 
    hm sad "哦，对不起，孩子。"
    show hm frown
    "他把你的手套重新戴上。"
    hm confused sigh "在你上次猎巫任务后，目击者称你身上有巫师契约印记。"
    hm yell -sigh "我只是想确认一下情况。你知道，对于猎巫人来说，与巫师缔结契约是要处以死刑的。"
    show hm scowl
    show side_p s at pic
    mc "啊...是的。"
    hide side_p
    mc "（天哪，[povname]真有胆量。不过，我还是在想[kamu]为什么要冒这样的风险。）"
    show side_p he at pic
    mc "那么，那个女妖悲伤诅咒是骗我来这里的幌子，还是...？"
    hide side_p
    hm ketawa"哦不，那是千真万确的。我可不会为了一个幌子浪费我的祝福海妖羽毛。"
    show hm amused
    mc "海妖羽毛？"
    show hm smile
    hm "据说有些海妖是伪装成天使的样子，拥有治愈任何伤口或诅咒的能力，甚至能让死者复活。"
    hm laugh "当然，天使的部分只是个神话，因为它们有翅膀和半人的外表。不过治愈的部分是真的。"
    hm mock "虽然并非所有海妖都拥有这种力量。大多数海妖只能提供轻微的娱乐，用她们甜美的声音吸引人。"
    show hm frown shock
    show side_p f at pic
    mc "我明白了，看来您很喜欢海妖，先生。"
    show side_p he
    mc "（或者说是对它们有种令人毛骨悚然的痴迷。但我觉得他可能不喜欢这种诚实。）"
    hide side_p
    hm confused sigh "嗯。我不知道喜欢是否恰当，但我确实很好奇，是的。"
    hm amused -sigh "它们充其量只是身份的象征，我的一个朋友买了几个作为他庄园的仆人。胆小的东西。"
    hm talk "不过很漂亮。"
    show hm amused
    show side_p f at pic
    mc "（仆人？像奴隶一样？我是说，我猜这里可能还存在这种事，但是天哪，这个世界的道德标准似乎相当低。）"
    mc "（不过，我最好还是问问奎尔关于这个。）"
    hide side_p
    $ topics.append("sirens")
    hm talk "总之，你现在已经痊愈了。鉴于你完美的记录，这次我不会惩罚你。"
    hm laugh "不过下次请敲门，[povname]。如果你需要什么，我随时都在。"
    show hm wry
    show side_p w at pic
    mc "当然，先生。"
    stop music
    scene map_classes1 with dissolve
    show side_p f at pic
    play sound "sound/effects/door.mp3"
    mc "（他看起来至少还不错。我想这可能比预想的要好。）"
    show side_p he
    mc "（现在我今天早上的课是什么来着？草药疗法，对吧？希望我没迟到。）"
    hide side_p
    play sound "sound/effects/walk.mp3"
    scene bangku_kls with fade
    show red point cowo bloom at center with dissolve:
        yoffset 330
    "当你走进下一堂课时，你看到塞恩朝你咧嘴一笑，炫耀着他的尖牙。"
    jump red_herb



label red_herb:
    scene bg_black with w20
    play music "MUSIC/MusMus-BGM-124.mp3"
    scene bangku_papan with w20
    show hedwin talk at center with dissolve:
        yoffset 200
    hed "首先，我们把蘑菇切片，然后加入魔法粉，只需一小撮就够了。圣水，只需一滴。当然，还要把大麻磨碎。"
    hed tantang "把它们全都混在一起……"
    hed smile cling "好了，这就是魔法蘑菇！非常适合在家里度过一个有趣的周末，或者用来麻痹失去四肢的痛苦。"
    hed talk bunga "啊……真是甜美的香味。我想尝一小小小口应该没问题吧……"
    $ NPC = "学生"
    npc "咳咳，海德温女士，您还在上课呢。"
    $ NPC = "???"
    hed mad shock "哦，天哪，原谅我！咳咳。"
    hed konsul -shock "现在你们都可以自己尝试了，孩子们。不过请适度使用大麻。恐怕我们学校今年的资金有点不足。"
    hed talk bloom "祝你们好运，快点快点！"
    scene bangku_kls with dissolve
    "学生们齐声应和，拿起刀开始切配料。"
    "你跟着做，阅读海德温女士在黑板上写的说明。"
    play sound "audio/success.mp3"
    "学会了新配方，魔法蘑菇！"
    $ known_recipes.append("item_mm")
    show red chin sayang at center with dissolve:
        yoffset 330
    show side_p w at pic
    mc "海德温女士刚才是不是想在课堂上嗨起来？"
    hide side_p
    red amused apa "你说得好像这是第一次发生似的。"
    red so sigh "我发誓，那个女人在战争中失去的不仅仅是四肢。"
    red awkward -sigh "不能怪她。像她那样的战士难免会留下一些心理创伤。"
    red calm "即使在沃特克，人们也在传唱\'蓝焰海德温\'的歌谣。"
    show side_p f at pic
    mc "猎巫人在沃特克很有名吗？"
    hide side_p
    red kaget "不是特别有名，但海德温女士本人相当出名。"
    red point happy "当维尔科娃女士还在莫尔斯学院工作时，有一个叫做学院运动会的活动，学校之间在各种技能和战斗形式上进行比赛。"
    red amused "维尔科娃女士告诉我，她误把海德温女士当成了一只流浪的水蛭，试图让她永远安息。"
    red awkward sigh "作为回报，海德温女士差点把维尔科娃女士烧成灰烬。不过维尔科娃女士还是道歉了，因为她是老师，而海德温女士是来访的学生。"
    show red datar -sigh
    if "leech" not in topics:
        show side_p f at pic
        mc "水蛭？"
        hide side_p
        red ngeles sweat sigh "失去理智的吸血鬼，被鲜血驱使疯狂。"
        play sound "audio/success.mp3"
        $ topics.append("leech")
        "新话题：{color=#FF1500}水蛭。{/color}"
        show red sad -sweat -sigh
    show pboy at horzappear
    menu:
        "你和维尔科娃听起来很亲近。":
            hide pboy
            red cowo blush bunga "哦，她就像我的母亲。她是我生命中第二重要的人！"
            show pboy at horzappear
            menu:
                "我是第一吗？":
                    hide pboy
                    red chin amused -blush sigh "噗。你？"
                    show red mock -sigh
                    show side_p s at pic
                    mc "（哎哟。）"
                    show side_p he
                    mc "没必要这么刻薄吧。"
                    hide side_p
                    red awkward both "哦，不，不！我不是那个意思。只是你这么说让我措手不及，伙计。"
                    red sayang -both "嗯，如果你在我一年级的时候问我这个问题，我可能会说是的。"
                    red mock point cling "我以前暗恋过你，你知道吗？"
                    show red hister blush -cling
                    show side_p a at pic
                    mc "等等，真的吗？"
                    hide side_p
                    if girl:
                        red wry "是啊，我觉得你挺可爱的。"
                    else:
                        if not girl2:
                            red happy "是的。直到今天，我还是觉得你是我见过的最漂亮的男人。比校园里的任何女孩都漂亮。"
                        else:
                            red grin "是啊，我觉得你挺可爱的。"
                    red ew sigh -blush "但后来我知道你和阿什姆在一起了，还有你和奎尔之间那种奇怪的友谊……"
                    if girl:
                        red amused "另外，不要生气，但你有时候确实有点像个婊子。"
                    else:
                        red amused "另外，不要生气，你有时候确实有点像个混蛋。"
                    red wry -sigh "我们之间现在已经有太多的历史了。"
                    show red datar -sigh
                    show side_p se at pic
                    mc "嗯，那么假设，如果我的外表还是现在这样，但我的整个性格和背景都完全不同。"
                    show side_p a
                    mc "你会给我们一个机会吗？"
                    hide side_p
                    red chin laugh "哦，百分之一千会的，没错！"
                    $ red_events.append('nicked')
                    red point sweat perih shock "该死，嗷——！" with vpunch


                "谁是第一个？":
                    hide pboy
                    red chin sayang "我的亲生母亲。如果不是她，我甚至不会存在。"
                    show side_p se at pic
                    mc "我明白了。她现在怎么样？"
                    hide side_p
                    red kaget apa "我的母亲？"
                    show red frown -apa
                    show side_p w at pic
                    mc "对。"
                    hide side_p
                    red lelah sweat sigh "她...我想，吃得还不错。"
                    show red mls -sweat -sigh
                    show side_p s at pic
                    mc "（这种说法真奇怪。他母亲是个敏感话题吗？）"
                    hide side_p
                    red point sweat perih shock "该死，嗷——！" with vpunch
            stop music
            play sound "sound/effects/stab.mp3"
            "你转过头，注意到塞恩不小心用切菜刀割伤了自己。"
            "深色且粒状的血液开始从他的手指渗出。"
            red ow sigh "哦，没事，它会自己愈合的——"

        "你能告诉我更多关于吸血鬼的事吗？":
            hide pboy
            show side_p f at pic
            mc "我知道吸血鬼痴迷于血液，但为什么海德温女士会被误认为是其中之一？"
            hide side_p
            red bingung "吸血鬼穿着与伊格尼亚修女相似的服装。失去人性的吸血鬼，嗯，看起来很可疑。"
            show red sad
            show side_p s at pic
            mc "可疑？"
            hide side_p
            red ngeles sigh "他们的身体变成了类似蝙蝠人的生物。想象一下延长的四肢和爪子，皮肤脱落——变成黑色的鳞片状皮肤。"
            red sweat ow frusta "看起来相当...令人作呕。他们通常穿着全黑的修女服，戴着白色的全脸面具。"
            show side_p f at pic
            mc "像维尔科娃女士那样的？"
            hide side_p
            red bingung chin -frusta "不。那是一种与维尔科娃所戴的不同的面具。她的面具是血骑士专属的。"
            show side_p s at pic
            mc "血骑士？"
            hide side_p
            red lelah -sweat sigh "帝国的皇家卫队。"
            red frown -sigh "但这偏离了话题。总之，这些面具据说能阻挡诱人的血腥味。"
            show side_p f at pic
            mc "不过，你没有戴面具。"
            hide side_p
            red amused "我对血液的兴趣没有大多数吸血鬼那么浓厚。血腥味对我影响不大。"
            $ red_events.append("curhat_leech")
            if "red_malam" in red_events:
                red bingung both "好吧，至少在现在之前是这样的。"
                show side_p f at pic
                mc "嗯？"
                hide side_p
                show red sad 
                "你看到塞恩避开了你的目光。你能看到他脸颊上泛起淡淡的红晕。"
                red ew point frusta "别以为我在说什么奇怪的话。"
                red so sigh "但自从我喝过你的血以后，我似乎就无法停止思考你的血液。"
                red ngeles both -sigh "即使是现在，你对我来说也闻起来如此美好，[nickname]。"
            else:
                show side_p se at pic
                mc "连我的血也是？"
                hide side_p
                red amused "你的？嗯，我想它确实比平常闻起来更甜美。"
                red ngeles both "等等，实际上...该死！为什么你闻起来这么香？"
            show hedwin konsul at right with moveinright:
                xzoom -1.0
                yoffset 200
            show red at left with move:
                yoffset 330
            hed bunga "哦天哪，我看到的是性张力吗？"
            red ow sweat shock "什么？！海德温女士，我们——哎哟！"
            show hedwin mad shock
            show red perih frusta
            stop music
            play sound "sound/effects/stab.mp3"
            "由于惊慌失措，他不小心又用切菜刀割伤了自己。"
            "深色且粒状的血液开始从他的手指渗出。"
            hed sad frusta "哦不，我很抱歉！我只是在开玩笑。让我去拿个创可贴！"
            hide hedwin with moveoutright
            show red at center with move
            red ngeles -frusta "什么？不，小姐，它会自己愈合的——"
    "看着从塞恩手指上滴落的血液似乎触发了你的某些回忆。"
    "回到你和菲亚过去在花园里玩耍的时候，她几乎总是会被你母亲的玫瑰刺伤手指。"
    show red kaget both shock
    play sound "sound/effects/cloth.mp3"
    "你没多想，本能地吮吸起塞恩的手指。"
    red grit "搞什么鬼？！"
    show side_p s at pic
    mc "（...我不该这么做的。他不是菲亚，你这个白痴！也许我该把它当作玩笑一笑而过？啊，但是等等...）"
    show side_p he
    mc "（他的血尝起来有点像...灰烬？）"
    hide side_p
    "与普通的血液不同，他的血液尝起来...陈旧？质地类似于灰烬。"
    red ngeles sweat frusta "不，[nickname]！"
    show red sad
    play sound "sound/effects/bump.mp3"
    "塞恩推开你，立即从你嘴里抽回了他的手指。"
    red growl -frusta "你在做什么？！吐出来，现在就把我的血吐出来！"
    "然后他用戴着手套的手指粗暴地刮擦你的舌头。"
    show side_p s at pic
    if girl:
        play sound "sfx/ow_f.mp3"
    else:
        play sound "sfx/umph.mp3"
    mc "呸！塞恩，你在——？！"
    hide side_p
    $ red_events.append("exchange")
    red ow "闭嘴，用这个漱口！" with vpunch
    "塞恩把一杯圣水塞到你嘴边，恳求你用它漱口。"
    red kzl "漱口！你都吐干净了吗？伸出舌头来！"
    show side_p m at pic
    mc "我没事！我只是想帮忙而已！"
    hide side_p
    red ngeles "伤口已经自己愈合了，我不需要帮助！你忘了我是什么了吗？"
    red perih frusta "我们会灵魂绑定的！"
    show side_p he at pic
    mc "啊？"
    play music "MUSIC/MusMus-BGM-099.mp3"
    hide side_p
    red bingung sigh "说实话，[povname]，你上课有在听讲吗？"
    if "red_malam" in red_events:
        red perih -sigh "吸血鬼通过血液交换来灵魂绑定，而我已经喝过你的血了。"
        red ngeles "如果你喝了我的血，我们就会灵魂绑定了！"

    else:
        red mls frusta "吸血鬼通过血液交换来灵魂绑定。没错，我还没喝过你的血，但是依然如此。"
        red ngeles -frusta "如果我喝了你的血，你也喝了我的血，我们就会灵魂绑定了！"

    red ew -sweat "说真的，你嗑药了吗？"
    show side_p he at pic
    mc "（可能是空气中的大麻吧。）"
    show side_p s
    mc "对不起。我不是故意的。"
    hide side_p
    red kaget sigh "我知道。但是...[povname]，你真的太鲁莽了。"
    red ow sweat frusta "如果阿什姆发现了并杀了我怎么办？"
    show red frown -sweat shock
    show side_p s at pic
    mc "等等，这就是你担心的？"
    hide side_p
    red chin both awkward -shock "嗯，关于我们绑定的事也是，但是...我不知道。在我们四人组中，我宁愿和你在一起，而不是其他人。"
    show red sayang -both
    show side_p a at pic
    mc "嗯。"
    hide side_p
    show pboy at horzappear
    menu:
        "我也是。":
            hide pboy
            $ mrh.points += 10
            red awkward shock "等等，真的吗？"
            red calm sigh "嗯，谢谢。"
            red ew frusta "不过这并不意味着我真的会和你灵魂绑定！"
            show red sayang -frusta
            show side_p w at pic
            mc "我知道，我知道。"
            hide side_p


        "我宁愿选奎尔。":
            hide pboy
            $ bff.points += 5
            show side_p se at pic
            mc "他很有钱。"
            hide side_p
            red hister bunga "哈哈，这点我无法反驳。"
        "我宁愿选阿什姆。":
            hide pboy
            $ ibu.points += 5
            red cowo shock "哦，这是不是意味着你们两个要复合了？我真心希望如此。"
            show red amused -shock
            show side_p se at pic
            mc "走着瞧吧。"
            hide side_p
        "我会选莱尔。":
            hide pboy
            $ putri.points += 5
            red bingung sweat apa "那个新来的？嗯...我对此持保留态度。"
            red amused sigh -sweat "话说回来，[povname]，你对男人的品味真奇怪。"
    "说完，你继续制作魔法蘑菇。你成功为自己制作了一份。"
    $ InvItem(*item_mm).pickup(1)
    "课程结束后，塞恩匆忙赶往下一节课。你的下一节课要到3点才开始，所以现在可能是找奎尔或莱尔的好时机。"
    show side_p s at pic 
    mc "（我真的应该和那两个人谈谈，尤其是莱尔。）"
    show side_p a 
    mc "（与我迄今为止遇到的其他人相比，莱尔似乎是其中最理智的一个。虽然对这个世界来说，他可能有点太纯洁和温柔了。）"
    mc "（希望我能找到他，而不用回宿舍。）"
    hide side_p
    $ NPC = "???"
    scene bg_black with w20
    stop music
    play sound "sound/effects/walk.mp3"
    $ morning = False
    $ evening = False
    $ afternoon = True
    
    jump lyall_hide

label lyall_hide:
    scene out_court with w20
    show buff frown at center with dissolve:
        yoffset 770
    "就在你走出建筑物时，你看到莱尔手里拿着一朵熟悉的花。"
    show side_p m at pic
    mc "莱尔！"
    hide side_p
    show buff keluh shock sweat 
    pause 1.0
    hide buff with moveoutleft
    "莱尔看了你一眼就跑开了，你立即追了上去。"
    scene tmn_ujung with dissolve
    play sound "sound/effects/tile.mp3"
    "你一路追着莱尔来到了花园。在他再次试图逃跑之前，你..."
    show pboy at horzappear
    menu:
        "扑倒他":
            hide pboy
            play sound "sound/effects/bump.mp3"
            show buff huh both apa at center with dissolve:
                yoffset 770
            buff "...你为什么抱着我？"
            show buff frown sweat -apa at right with move
            if girl:
                show palmierproxy scratch huh frusta sweat at left with moveinleft:
                    yoffset 40
            else:
                show palmierproxy scratch huh frusta sweat at left with moveinleft:
                    yoffset 100
            mc "其实我是想扑倒你。"
            mc rajuk sigh "（我一时忘了你有多壮实，不过至少他停止逃跑了。）"
            mc sad -sweat tanya "莱尔，你拿着那朵花到底要干什么？"
            buff scold "把它送到海里去。"
            show buff sad -sweat
            mc chill confused tanya "什么？"
            show palmierproxy frown -tanya
            play music "MUSIC/MusMus-BGM-077.mp3"
            buff keluh sigh"在陆地上，这个可怜的人永远不会得到安宁，但在海里……至少他会停止痛苦的哭泣。"
            show buff sad -sigh
            mc apa tanya "哭泣？等等，你能听到他们吗？"
            show palmierproxy frown shock
            "莱尔轻轻点了点头。"
            show palmierproxy sad -shock
            buff confused "隐约能听到。他们经常喃喃自语和哭泣。有时候很难理解他们在说什么。"
            buff sad "这个人一直在为背叛他的未婚妻维拉而道歉，维拉是我……我的姐姐。"
            buff scold sigh "我知道他做错了，但没有哪种罪过应该受到这样的惩罚。我只是想让他的灵魂得到一些安宁。"
            show buff frown shock
            mc scratch deject tanya "这是不是意味着海水能杀死他们？"
            show palmierproxy frown -tanya -sweat
            buff keluh sigh"不。他们仍然被诅咒永生，但不会再长出新的花苞。"
            buff frown -sigh "我不知道为什么，但海水能让他们保持完整。而且哭泣通常会慢慢停止。"
            mc chill frown tanya "我明白了。听起来你以前处理过这种情况。"
            buff keluh frusta "我的哥哥们在他们……在花苞长出来之前告诉我的。"
            show buff sad
            mc side sweat -tanya "啊……"
            mc ow -sweat "我很抱歉。"
            show palmierproxy sad
            buff keluh sigh "我也很抱歉。"
            buff huh apa "……托马斯说你在梦中见过我父亲。"
            mc confused tanya "托马斯？"
            buff eh -apa "这朵\'花\'的名字。托马斯说你和我父亲谈论过维拉？"
            buff sad "他说你是杀死她的人？"
            mc grit sweat -tanya "（糟糕。）"
            mc ew frusta "说实话，她先杀了别人。在她自己的婚礼上的一位客人，而我，呃，你生气吗？"
            show palmierproxy frown shock -sweat
            buff lega "不。实际上，我很高兴。我还记得维拉多次伤害伊尔夫，她罪有应得。"
            show buff wry
            mc confused -shock "伊尔夫？"
            buff keluh sigh "我的兄弟，他……是帮助我逃跑的人。"
            if "big_bro" not in topics:
                play sound "audio/success.mp3"
                $ topics.append("big_bro")
                "新话题：{color=#FF1500}伊瓦尔的儿子们{/color}"
            mc sad "哦。"
            buff huh -sigh "你见过他吗，伊尔夫？他现在是一束红玫瑰。他还好吗？"
            buff kzl "花瓣上没有渗血吗？没有眼泪？"
            mc sad "……没有。没有眼泪。"
            mc side "（至少我看不到。但还是不要加上这个细节。）"
            show palmierproxy frown
            buff lega blush sigh "很好。"
            $ putri.points += 5
            buff keluh -blush frusta "……我很抱歉翻动你的东西，但我想让托马斯安息。"
            buff sad apa "你能让我这么做吗，拜托了？"
            show buff huh shock
            mc kind sigh "当然可以。事实上，我想我认识一个可以帮忙的人。"
            jump buff_meet_pike

        "绊倒他":
            hide pboy
            play sound "sound/effects/bump.mp3"
            show side_b skul sad at pic
            buff scold shock sweat "呃，不要！" with vpunch
            hide side_b
            $ buff_events.append("rooted")
            play sound "sound/effects/grow.wav"
            scene plant with dissolve
            "玫瑰掉落，它的茎和刺立即延长，扎根于地面。"
            "瞬间，它就与这片土地融为一体，仿佛一直都在那里。"
            scene tmn_ujung with dissolve
            show buff keluh sweat shock at center with dissolve:
                yoffset 770
            buff "它扎根了。"
            if girl:
                show palmierproxy scratch apa sweat at left with moveinleft:
                    yoffset 40
            else:
                show palmierproxy scratch apa sweat at left with moveinleft:
                    yoffset 100
            show buff sad at right with move
            mc "这朵花刚刚自己种下了吗？发生了什么？"
            show palmierproxy sad shock
            buff scold -sweat frusta "它扎根了！它扎根了！你做了什么？！"
            buff keluh frusta "对不起！我非常抱歉！"
            mc chill confused -shock "抱歉？为什么？"
            show palmierproxy ow shock
            buff scold frusta "我不是在向你道歉！我是在向他道歉！！！"
            show palmierproxy frown -shock
            buff huh shock"啊！"
            show buff sad -shock
            "莱尔看起来对自己对你提高嗓门感到震惊。"
            buff keluh sigh "我不是故意要喊的，我——！"
            show pboy at horzappear
            menu:
                "\'他\'是谁？":
                    hide pboy
                    buff sad -sigh "托马斯。"
                    $ putri.points -= 5
                    if putri.points <0:
                        $ ibu.points = 0
                    mc apa tanya "啊？"
                    show palmierproxy frown -tanya
                    play music "MUSIC/MusMus-BGM-077.mp3"
                    buff keluh sigh "那朵\'花\'，他的名字是托马斯。"
                    show buff sad -sigh
                    jump tancap
                "我活该。":
                    hide pboy
                    $ putri.points += 5
                    mc sad frusta "不，别道歉。我活该。"
                    show palmierproxy frown -sweat shock
                    if "crush_bung" in my_events:
                        buff kzl frusta "……是的。是的，你做到了。"
                        show palmierproxy sad -shock
                        buff scold "你知道，你其实不必压碎他的。不管是不是花，他仍然是人。"
                        buff keluh sigh "他能感受到……一切。"
                        show buff sad -sigh
                        mc side "伊瓦尔说这是我了解真相的唯一方法。"
                        buff huh apa "真相？"
                        show buff kzl -apa
                        mc avoid "呃……没什么你需要知道的，莱尔。"
                        mc deject sigh "这只是我必须处理的事情。"
                        show palmierproxy frown -sigh
                        buff sad -sweat "..."
                        buff keluh"托马斯告诉我你在梦中遇到了我父亲。"
                        mc apa tanya"啊？"
                        show palmierproxy frown shock
                        play music "MUSIC/MusMus-BGM-077.mp3"
                        buff scold sigh "那朵花，他的名字是托马斯。"
                        show palmierproxy side -shock
                        show buff frown -sigh
                        jump tancap
                    else:
                        buff sad sweat sigh "如果你压碎了他的花瓣，你可能会知道，但你没有。"
                        buff lega blush -sigh "你知道吗？他为此感谢你。感谢你饶恕了他。"
                        show buff touched
                        mc happy tanya "哦，那么……不客气，呃……花？"
                        show palmierproxy frown shock
                        buff wry sigh "托马斯。"
                        mc apa tanya "啊？"
                        show palmierproxy frown -tanya
                        play music "MUSIC/MusMus-BGM-077.mp3"
                        buff talk -sigh "那朵\'花\'，他的名字是托马斯。"
                        show buff touched
                        jump tancap



                "对我咒骂吧。" if "crush_bung" in my_events:
                    hide pboy
                    buff huh shock sweat "什-什么？"
                    show buff sad -shock
                    mc deject sigh "我怀疑这不是你唯一想对我大喊的。来吧，把你的感受发泄出来。"
                    show palmierproxy frown -sigh
                    buff kzl "..."
                    buff scold "你这个混蛋。"
                    mc kind tanya "那是什么？"
                    show palmierproxy -tanya
                    buff scold "你这个混蛋！你这个残忍无情的混蛋！"
                    buff "你这个彻头彻尾的疯子！"
                    buff "你怎么能那样压碎他？不管是不是花，他仍然是人！他能感受到一切！"
                    buff kzl "我简直不敢相信你。你这个可恶的东西，就像我那疯狂的父亲，我……我……"
                    buff scold frusta "哈啊！" with vpunch
                    mc wry sigh "……感觉好些了吗？"
                    $ putri.points += 15
                    $ buff_events.append("curhat")
                    buff sad sigh "是-是的。"
                    buff keluh -sigh "对不起。我……我并不是真心那么说的。"
                    mc scratch ha sigh "不，你是真心的。别担心，我也觉得自己是个超级混蛋。"
                    mc side -sigh "我不应该那么轻易就屈服。你要知道，我压碎他只是因为伊瓦尔告诉我这会有帮助。"
                    show palmierproxy frown shock
                    buff frown sigh "托马斯。"
                    mc confused -shock"啊？"
                    show palmierproxy frown chill
                    play music "MUSIC/MusMus-BGM-077.mp3"
                    buff frown -sigh "那朵\'花\'，他的名字是托马斯。"
                    jump tancap
label tancap:
    
    mc apa tanya "等等，你能听到他们说话？"
    show palmierproxy frown shock
    "莱尔轻轻点了点头。"
    show palmierproxy -shock
    buff sad -sigh "隐约能听到。他们经常喃喃自语和哭泣。有时候很难理解他们在说什么。"
    buff keluh "这个人一直在为背叛他的未婚妻维拉而道歉，维拉是我……我的姐姐。"
    buff scold "他做错了，但没有罪过应该受到这样的惩罚。"
    buff huh sigh "我本想把他带到海边，让他安息。"
    show buff frown -sigh
    mc apa tanya "安息？那是不是意味着海水会杀死他们？"
    show palmierproxy frown -tanya
    buff keluh sigh "不。他们仍然被诅咒永生，但不会产生那么多花蕾。"
    buff wry -sigh "我不知道为什么，但海水能让他们保持完整。而且哭泣声会慢慢停止。"
    mc rajuk sweat "我明白了。听起来你以前处理过这种情况。"
    show palmierproxy frown
    buff keluh sigh "我的哥哥们在……在花蕾长出来之前告诉我的。"
    show buff sad -sigh
    mc ow "啊……"
    show palmierproxy sad 
    buff scold -sweat frusta "现在已经太晚了，扎根的花朵无法移动。"
    buff keluh sigh "就像死亡地带里的所有花一样，他现在被困在原地了。"
    show buff sad -sigh
    "莱尔跪下来，轻轻抚摸着那朵花，就像在抚摸一只猫一样。"
    buff keluh "对不起。我会每天来给你浇水的。我保证。"
    if "crush_bung" in my_events and not "curhat" in buff_events:
        show buff kzl
        "莱尔转向你，怒视着你。"
        buff scold "你最好也照顾好他。这是你起码该做的！"
        mc side sigh "I know."
    show palmierproxy kzl shock
    "说完，莱尔转身走开了。然而，他停顿了一下，瞥了你一眼。"
    buff scold frusta "奎尔先生说你弄脏了你的梦之符文，意外遇到了伊瓦尔，所以这次我就不追究了。"
    buff kzl sigh "但是记住我的话，[povname]。如果我再看到你身上有我父亲的花，我就会告诉老师们你的事。"
    mc sad sigh "这将是最后一次，我保证。"
    buff frown -sigh "..."
    show buff huh sweat shock
    pause 1.0
    hide buff with moveoutright
    show palmierproxy confused -sweat shock
    "莱尔最后看了你一眼，然后好像被自己的话吓到了一样，他跑开了。姿势很不优雅。夹着尾巴逃走了。"
    show palmierproxy deject sigh at center with move
    mc sigh "哦，莱尔，你刚才表现得很好。"
    mc huh frusta "勇气并不是那个人的强项。"
    show palmierproxy hister scratch sigh
    if "sucker3" in completed_quests:
        if girl2:
            mc "但至少他不再叫我\'夫人\'了。"
        else:
            mc "但至少他不再叫我\'先生\'了。"
    mc kind -sigh "我还需要和他好好谈谈，但目前这样就行了。"
    mc mock cling "现在去找奎尔..."
    $ NPC = "???"
    scene bg_black with w20
    if "bunga_bego" in buff_events:
        if "beku" in quil_events:
            scene map_infected_f with w20
        else:
            scene map_infected with w20
    else:
        if "beku" in quil_events:
            scene map_frozen with w20
        else:
            scene map_all with w20
    jump world_map


label buff_meet_pike:
    scene fishing with fade
    show side_p se at pic
    mc "派克！"
    hide side_p
    $ NPC = "派克"
    play music "MUSIC/MusMus-BGM-064.mp3"
    show side_pike_s at pic
    npc "哦，[povname]，很高兴见到你小家伙，哇哦！"
    npc "这位魁梧的小伙子是谁啊？小伙子，你会钓鱼吗？我在海上可以用得上你的力气。打赌你能徒手抓金枪鱼。"
    hide side_pike_s
    show buff huh apa at center with dissolve:
        yoffset 770
    buff "金枪鱼？"
    show buff sad -apa
    show side_p se at pic
    mc "派克，这是莱尔。莱尔，这是派克。"
    mc "派克是莱纳尔的渔民，那是当地的渔村。"
    show side_p w
    mc "派克，抱歉麻烦你，但你能把这朵花送到海上吗？"
    hide side_p
    buff eh apa "为什么是他？"
    show buff huh -apa
    show side_p f at pic
    mc "嗯，如果我们在这里放生，它可能会漂回校园。把托马斯送得更远一些不是更好吗？"
    hide side_p
    buff keluh sweat shock "哦，说得对，我没想到这一点。"
    show buff frown -shock
    show side_pike_s at pic
    npc "你想让我把这朵花送到海上，小家伙？当然可以，反正我正准备出海呢。"
    npc "今天这片水域鱼不太上钩。"
    npc "这是你们的习俗吗？不过这花挺漂亮的，我从没见过这样的。"
    hide side_pike_s
    buff eh apa -sweat "你不知道这朵花的含义吗？"
    show buff huh -apa
    show side_pike_s at pic
    npc "呐，花不太对我的胃口。"
    npc "还有小伙子，我必须说你有一双非常漂亮的眼睛，太美了！"
    hide side_pike_s
    buff confused apa "...我的眼睛，它们不会让你感到困扰吗？"
    show side_pike_f at pic
    npc "为什么会呢？"
    hide side_pike_f
    buff wry blush bunga "..."
    show buff -blush frown shock
    show side_pike_s at pic
    npc "另外，我可不是在开玩笑，小子，我在村里可以用得上你这样的人。我正在变老，时不时需要帮忙把渔获带回家。"
    hide side_pike_s
    show buff huh -shock
    show side_pike_s at pic
    npc "你可以在课后来帮忙，把渔获带回家，清理鱼... 我会给你丰厚的报酬的！"
    hide side_pike_s
    buff amused "...带我一起去放生那朵花，然后我就答应。"
    show buff datar sigh 
    show side_pike_s at pic
    npc "成交！那我们现在就出发吧？你不介意我在莱纳尔稍作停留吧？"
    hide side_pike_s
    buff talk -sigh "啊，好吧，没问题。"
    show side_pike_s at pic
    npc "扬帆起航！"
    hide side_pike_s
    show buff datar blush
    "当派克准备他的船时，莱尔转向你，难得地露出了温暖的微笑。"
    buff hister bloom "那我就出发了。"
    show pboy at horzappear
    menu:
        "替我向托马斯道别！":
            hide pboy
            show side_p se at pic
            mc "替我向托马斯道别！"
            hide side_p
            $ kindness += 5
            buff talk "我会的。"
        "拍拍他的头。":
            hide pboy
            $ putri.points += 5
            $ kindness +=  10
            $ putri.likes = "身体接触，摸头，鱼"
            show buff confused shock
            "莱尔坐在船上，你现在可以从码头上拍他的头了。"
            buff laugh bunga"啊！"
            show buff wry
            show side_p se at pic
            mc "试着玩得开心点，好吗？替我向托马斯道别。"
            hide side_p
            buff hister "好的，呃...谢谢你。"
    scene fishing with dissolve
    show side_pike_s at pic
    npc "好了，我们出发了，再见小家伙！"
    hide side_pike_s
    $ buff_events.append("buff_kerja")
    "你看着莱尔和派克驶向大海。"
    show side_p w at pic
    mc "一件事解决了，现在去找奎尔。"
    hide side_p
    $ NPC = "???"
    scene bg_black with w20
    if "bunga_bego" in buff_events:
        if "beku" in quil_events:
            scene map_infected_f with w20
        else:
            scene map_infected with w20
    else:
        if "beku" in quil_events:
            scene map_frozen with w20
        else:
            scene map_all with w20
    jump world_map


label bersih_mc:
    scene bg_black with w20
    play music "MUSIC/MusMus-BGM-059.mp3"
    scene kmr_apt with w20
    "那个请求原来是要给[povname]洗澡并换掉那些脏衣服。"
    "你希望奎尔在这里帮忙，但他有课。"
    show side_p f at pic
    if girl:
        if girl2:
            mc "我猜他出于尊重，不想为了[dia]自己而给[dia]换衣服。"
        else:
            mc "我猜他出于尊重，不想为了[dia]自己而给[dia2]换衣服。"

    else:
        if not girl2:
            mc "他们都是男人，所以我不知道有什么大问题。哦，算了。"
        else:
            mc "我猜他出于尊重，不想为了[povname]而这么做。"
    hide side_p
    "你一层层地脱下你的分身的衣服。感觉很不真实，就像在菲亚去世后的早期看着自己的倒影。"
    "洗[dia]的脸时，你注意到[povname]化了妆来掩饰[dia]憔悴的面容。"
    show side_p s at pic
    mc "这个[povname]一定是真的放弃了一切。黑眼圈，凹陷的脸颊，我甚至能感觉到[dia]的肋骨凸出来。"
    show side_p he 
    mc "我想知道是什么把你逼到这个地步的，[povname]。"
    show side_p s
    mc "我知道菲亚去世时我的状态很糟糕。整天沉溺于性、酒精和派对中。"
    mc "尽管如此，我的朋友和家人从未让情况变得这么糟。难道没有人来帮助你吗？"
    show side_p f
    mc "嗯？"
    hide side_p
    if girl:
        "当你怜悯地看着你的分身的身体时，你注意到有什么东西从[dia]的胸罩里露了出来。"
    else:
        "当你怜悯地看着你的分身的身体时，你注意到有什么东西从[dia]的腰带上露了出来。"
    scene letteri with dissolve
    galleryunlock letteri
    play sound "sound/effects/cloth.mp3"
    show side_p m at pic
    mc "一封信？"
    hide side_p
    "你打开了这封神秘的信，看到上面写着\'仅供你本人阅读\'。"
    "瞬间，信的内容变成了一整页手写的信，收信人正是你本人。"
    scene kmr_apt with dissolve
    "信上写道..."
    $ NPC = "信"
    npc "我唯一的人类朋友，你好吗？我给你父亲发了邀请，希望你不介意。"
    npc "这是我能想到的唯一能再次引起你注意的方法。别担心，我没有像其他信那样给它施加魔法。"
    npc "我知道你那懦弱的父亲没有妻子的允许是不敢来我的...\'不正经的场所\'的。"
    npc "尽管如此，我还是希望你能来。我渴望你，渴望你的黑暗，你邪恶的贪婪。满怀爱意，梅扎。"
    "当你读完后，空气中弥漫着一股浓郁的茉莉花香。"
    "你毫不犹豫地掏出手机，开始给你父亲发消息。"
    $ NPC = "???"
    jump night2

label discuss_meyza:
    $ night = True
    $ evening = False
    $ afternoon = False
    $ morning = False
    scene teras_mlm with circleirisout
    play music "MUSIC/MusMus-BGM-146.mp3"
    show quil skul frown at center with dissolve:
        yoffset 200
    quil rajuk sigh "我明白了。看来[povname]认识梅扎。或者看起来是这样。"
    show side_p s at pic
    mc "你知道这件事吗？"
    hide side_p
    quil err frusta "当然不知道。但[povname]有交奇怪朋友的天赋。"
    quil sulk sigh "包括我在内。嗯，不过...我们现在有办法进入贪婪女巫的巢穴了。"
    show quil frown -sigh
    show side_p f at pic
    mc "是啊，计划是什么？"
    hide side_p
    
    quil talk "嗯，首先我需要让阿什姆和塞恩参与进来。"
    show side_p he at pic
    mc "所以你要坦白告诉他们我的事？"
    hide side_p
    quil laugh cling "什么？天啊，当然不是！不过，我可以伪造一份悬赏，让阿什姆和塞恩参与进来。"
    quil amused sigh "我得花些金子和血来让它看起来可信，但不会有什么大问题。"
    show quil datar -sigh
    show pboy at horzappear
    menu:
        "为什么不找你的家人呢？":
            hide pboy
            show quil bingung 
            show side_p he at pic
            mc "据我所知，你的家人都是猎巫人，对吧？为什么不让他们参与进来？"
            hide side_p
            quil err "嗯。我还是不要了，我和我的家人...关系很复杂。"
            quil sulk sigh "更不用说我们不知道要面对什么。我从未进入过她的领域。"


        "你应该坦白。":
            hide pboy
            quil kzl frusta "我不会那么做的。阿什姆会惊慌失措，塞恩会感到困惑，而菲亚..."
            quil ow sigh "听着，逗她可能是我最喜欢的消遣，但我讨厌看到那个女孩哭。"
            show quil sad -sigh
            show side_p w at pic
            mc "我明白了，你是在试图保护她。"
            hide side_p
            quil mock sigh "也是在保护我自己。我还是觉得如果她发现了，她会杀了我。"
    quil flashy wink cling "交给我吧，亲爱的。我们四个人一起去她的领域。"
    quil heh -cling "你知道吗，有趣的是，\'梅扎的欲望之屋\'在贵族中其实相当有名。至少在那些比较放荡的贵族中是这样。"
    quil rajuk "大多数人认为它是一家脱衣舞俱乐部，但对于他们实际做什么，或者位于哪里，都只有模糊的了解。"
    quil frown "似乎没有人能真正回忆起那个地方。我一直以为只是他们喝醉了，但我想一定有一种让人遗忘的魔法。"
    quil sly cling "一个就在贵族眼皮底下的女巫。或者为他们工作，嗯，嗯。"
    show quil frown shock
    show side_p f at pic
    mc "你似乎对此并不太在意。"
    hide side_p
    quil skul rajuk sigh "嗯，我一直有所怀疑。"
    quil cringe -sigh "不是特指贪婪女巫，而是怀疑贵族们使用不太道德的手段来互相超越。"
    quil ejek "看到所谓的精英阶层中经常发生\'意外\'死亡，很难不怀疑有什么见不得人的勾当。"
    quil tantrum apa "但想到他们会牵涉到一个女巫，天啊...他们真的会堕落到这种地步吗？"
    quil talk cling "不过我想这就是我们要弄清楚的。是时候做好准备了。"
    quil laugh -cling "如果一切按计划进行，我们应该在周日出发。我会确保及时通知你的，亲爱的。"
    quil flashy wink spark "晚安。"
    quil amused sigh "哦，这次别把你的符文弄花了？"
    show pboy at horzappear
    menu smudge:
        "晚安。":
            hide pboy
            if "date1_flag" in red_events:
                quil datar -sigh "再见！"
                hide quil with dissolve
                stop music
                play sound "sound/effects/door.mp3"
                show side_p f at pic
                mc "好吧，那么。我最好在塞恩来接我之前换好衣服。不知道他会带我去哪里。"
                hide side_p
                scene bg_black with w20
                jump red_date1_skul
            else:
                if "mini_ketemu" in red_events or "blood1" in completed_quests:
                    quil talk shock "哦，最后一件事。"
                    quil wry -shock "塞恩在公共休息室找你。"
                    quil amused sigh "也许你应该看看他想要什么。"
                quil datar -sigh "再见！"
                scene lor_mlm with dissolve
                play music "MUSIC/MusMus-BGM-082.mp3"

                play sound "sound/effects/door.mp3"
                jump map_kmr_ane
        "{s}等等，你不想一起出去玩吗？{/s}" if "date1_flag" in red_events:
            
            jump smudge
        "等等，你不想一起出去玩吗？" if not "date1_flag" in red_events:
            hide pboy
            quil mock apa "你说什么？"
            show quil kzl shock
            show side_p se at pic
            mc "现在我知道你是个胆小的处男，我觉得你变得更能忍受了。"
            hide side_p
            quil groan both frusta "呃，你不会就这么算了吧？"
            show quil frown -both shock
            show side_p w at pic
            mc "不会。不过话说回来，你是这里唯一知道我真实身份的人。"
            show side_p se
            mc "我可以和一个能让我卸下面具的人一起放松一下。"
            hide side_p
            quil heh apa "...你是在说，你想请我吃饭喝酒？"
            show pboy at horzappear
            menu:
                "不，只是一起出去玩。":
                    hide pboy
                    quil rajuk sigh "哦。那么，不行。"
                    quil wry -sigh "我太忙了，没时间做那种事。"
                    if "mini_ketemu" in red_events or "blood1" in completed_quests:
                        quil laugh "不过，如果你那么渴望陪伴，我刚才在走廊上看到塞恩了。"
                        quil talk "也许你可以和他一起消除孤独感。"
                    else:
                        quil talk "也许你和塞恩会有更好的运气，我想我看到他在休息室附近鬼鬼祟祟的。"
                    stop music
                    jump map_kmr_ane
                "当然...？":
                    hide pboy
                    show quil datar shock
                    show side_p f at pic
                    mc "如果那是你想要的，当然可以。"
                    show side_p w
                    mc "但是你要知道，我没有现金。所以如果我们要去什么高档地方，费用得你来付。"
                    hide side_p
                    if girl2:
                        quil flashy wink cling "当然了。我绝不会让一位女士在第一次约会时付钱。"

                    else:
                        quil heh cling "哦，拜托。工作日我们又不能去什么\'我的层次\'的地方。"
                    quil malu blush -cling"..."
                    quil talk "给我一点时间换衣服。今天是上学的日子，所以我们不能去戈莫拉，但是..."
                    quil hister bloom "我知道我们可以去的地方。"
                    stop music
                    jump quil_date1

label combat_kls:
    scene bg_black with w20
    play music "MUSIC/MusMus-BGM-136.mp3"
    scene latian with w20
    show nun proud at center with dissolve:
        yoffset 100
    nun sigh "安静下来，孩子们。吵闹只会让你们失去分数。"
    nun cross -sigh "现在，今天我们将重点学习冰和火的投射符文。"
    nun "每个学生在施放远程法术时要保持10米的距离。"
    nun hand apa "请严格使用冰和火符文法术。有人能告诉我为什么吗？"
    "阿什姆和奎尔都举起了手。"
    nun cross -apa"英克威尔？"
    show quil flashy talk at left with moveinleft:
        yoffset 200
    quil cling "水系投射物在超过7米的距离时无法保持形态。"
    quil heh "同时，风和影符文是为远程战斗设计的，所以在这个练习中使用它们会太容易。"
    show quil kzl shock
    show tom scold amused cling at right with moveinright:
        yoffset 190
    tom "维尔科娃女士，我可以补充一点吗？"
    show quil frown -shock
    nun "请说。"
    tom hip pfft -cling "我认为水系投射物可以保持形态，但只有在纯血巫师的手中才能做到。"
    nun proud "你们两个都回答正确，各得5分。内弗斯，你额外得5分。"
    show quil groan frusta
    "你能听到奎尔在那里嘟囔。"
    quil tantrum "切。老师的宠儿。"
    tom talk giggle bunga "别那么小气，奎尔。"
    hide quil with dissolve
    hide tom with dissolve
    nun cross sigh "咳咳。现在，你们中的一个将严格使用火，另一个将使用冰。"
    nun hand -sigh "这个练习的主要目标是尽可能地维持你的投射物的形态。"
    nun "当然，同时还要击中你的对手。"
    nun cross "避开所有要害部位，战斗在3次命中或对手被制服时结束。"
    nun proud "现在，让我们开始吧。"
    nun "阿什姆·内弗斯和[povname]·贝克，你们两个上学期是我的最高分获得者。"
    nun "所以你们两个先上。内弗斯，你用冰。贝克，你用火。"
    nun "别磨蹭了，快点。"
    "阿什姆自信地大步走过场地，而你则不情愿地从长凳上站起来，走到你的位置。"
    "奎尔向你竖起大拇指，但他同时用嘴型说\'你要完蛋了\'。"
    show side_p he at pic
    mc "（{i}真是支持啊。{/i}天哪，他有时候真是个混蛋。）"
    hide side_p
    galleryunlock ice4
    scene ice1 with flashbulb 
    nun hand "听我口令。1，2，开始！"
    show ice2 with circlewipe
    play sound "sound/effects/freeze.mp3"
    show ice_swords with dissolve
    "你可以看到冰锥开始在阿什姆周围形成，塑造成各种漂浮的匕首。"
    "阿什姆毫不犹豫地向你投掷出那些锋利的匕首。"
    scene latian with vpunch
    play sound "sound/effects/glass.wav"
    show side_p m at pic
    mc "哇哦！"
    hide side_p
    play sound "sound/effects/stab.mp3"
    "你翻滚躲开，但其中一把擦伤了你的腿。你的夹克上又多了一道划痕，但没有划破皮肤。"
    show nun hand at center with dissolve:
        yoffset 100
    nun shock "这是第一处伤口，阿什姆得一分！"
    hide nun with dissolve
    show tom hip amused bunga at center with dissolve:
        yoffset 190
    "阿什姆脸上挂着得意的笑容，似乎早料到你会滚开，并相应地调整了瞄准。"
    show side_p m at pic
    mc "（不知为何，他那笑容真的开始惹恼我了。）"
    hide side_p
    play sound "sound/effects/freeze.mp3"
    queue sound "sound/effects/shing.ogg"
    if girl:
        galleryunlock ice_fem
        scene ice_fem with flashbulb:
            yalign 1.0
            easein 1.0 yalign 0.0
            easeout 2.0 yalign 0.5
    else:
        galleryunlock ice_claw
        scene ice_claw with flashbulb:
            yalign 1.0
            easein 1.0 yalign 0.0
            easeout 2.0 yalign 0.5
    "你还没来得及思考，脚下的草地突然发光，冰刺从中迸射而出。"
    mc "哦！"
    play sound "sound/effects/stab.mp3"
    "你本能地往后缩，但一块冰刺还是划伤了你的手腕。"
    mc "（到这个地步，我已经分不清他是在和我切磋还是真的想杀了我！）"
    scene latian with dissolve
    show nun cross at center with dissolve:
        yoffset 100
    nun apa "这是第二处伤口。今天状态不佳啊，[povname]？"
    hide nun with dissolve
    show tom scold ejek apa at center with dissolve:
        yoffset 190
    tom "需要休息一下吗，[povname]？要不要我站在这里让你免费打一下，好让你追上比分？"
    show tom pfft -apa
    show side_p m at pic
    mc "（哦，够了！）"
    hide side_p
    stop music
    if girl:
        scene rawrf with flashbulb    
        galleryunlock rawrf
    else:
        scene rawr1 with flashbulb
        galleryunlock rawr1
    mc "好啊，我接受你的提议。"
    play sound "sound/effects/change.mp3"
    "不知道这招管不管用，但是..."
    mc "...火？"
    play sound "sound/effects/woosh.mp3"
    queue sound "sound/effects/roar.mp3"
    scene rawr_base with flashbulb
    galleryunlock rawr_base
    "一团明亮的蓝色火焰从你的手中凭空出现。当火焰以老虎的形态爆发而出时，你的指尖开始刺痛。"
    "火焰老虎扭动着身体，朝阿什姆扑去。"
    scene rawr_api with flashbulb
    galleryunlock rawr_api
    play sound "sound/effects/api.mp3"
    tom "该死！！！" with vpunch
    "阿什姆似乎慌了神，也朝你甩出了自己的火焰。"
    "他的凤凰直冲你的烈焰虎而去。"
    play sound "sound/effects/explode.mp3"
    galleryunlock rawr_bum
    scene rawr_bum with flashbulb:
        truecenter zoom 1.0
        easein 1.0 truecenter zoom 0.5
    "你们的火焰相撞。你的蓝色火焰吞没了他的。你能感受到脸上辐射的热量。"
    "然而，这些热量与你指尖的灼烧感相比根本不算什么。"
    scene latian with dissolve
    show side_p s at pic
    mc "（啊，为什么我的手指这么痛？）"
    hide side_p
    show nun proud shock at center with dissolve:
        yoffset 100
    play sound "sound/effects/clap.mp3"
    nun "蓝色火焰？！太不可思议了！"
    nun -shock "自从海德温失去四肢以来，我就再也没见过蓝色火焰了！"
    nun bloom "[povname]得10分！"
    nun shock "真是太惊人了，[povname]，你——啊！"
    nun cross frusta"你的手！"
    hide nun with dissolve
    show tom talk frown at center with dissolve:
        yoffset 190
    tom eh shock sweat "符文坏死！"
    $ my_events.append("necrosis")
    show tom sad 
    pause 0.5
    play sound "sound/effects/tile.mp3"
    hide tom with moveoutleft
    "阿什姆跑过场地，伸手抓住你的手，迅速脱下你的手套。"
    play sound "sound/effects/cloth.mp3"
    if girl:
        show ice_hand with dissolve
        galleryunlock ice_hand
    else:
        show ice_hand2 with dissolve
        galleryunlock ice_hand2
    "看着自己的手，你注意到它已经变成了青黑色。疼痛还能忍受，但你似乎无法随心所欲地移动手指了。"
    scene latian with dissolve
    show tom talk sad at center with dissolve:
        yoffset 190
    tom apa "你能动手指吗？"
    show side_p s at pic
    mc "我...不能。"
    hide side_p
    tom sweat frusta "情况不妙。我们得赶紧送你去医务室。"
    show tom at right with move
    show nun hand at left with moveinleft:
        yoffset 100
    tom kzl apa "维尔科娃女士？"
    nun hand "是的，我已经联系了海德温。快点，在它蔓延到[dia]的手腕之前。"
    tom frown -apa hip "当然。"
    hide nun with dissolve
    show tom talk at center with move
    play sound "sound/effects/cloth.mp3"
    "阿什姆将你抱起，像抱新娘一样抱着你。"
    show side_p s at pic
    mc "什么？喂——！"
    hide side_p
    play sound "sound/effects/tile.mp3"
    tom ha blow"这样更快，别废话了。"
    hide tom with moveoutleft
    stop sound
    scene uks with fade
    play sound "sound/effects/splash.wav"
    play music "MUSIC/MusMus-BGM-013.mp3"
    "在医务室里，海德温女士先用圣水浇在你的手上，然后将你的手放入一碗看似纯液态黄金的液体中。"
    show hedwin smile at center with dissolve:
        yoffset 200
    hed konsul "美人鱼和独角兽的血，混合了伤寒草和凤凰叶。"
    hed talk"这是一种残酷但非常有效的疗法。你很幸运，迪特里希先生似乎总是有一些独角兽血液储备。"
    show pboy at horzappear
    menu:
        "我会失去我的手吗？":
            hide pboy
            hed konsul "不会。坏死还没有蔓延到你的手腕，所以你没事。"
            hed wry "我已经很久没有处理过这样的伤势了。"
            hed talk "让我们别养成这种习惯，好吗？"
        "你很擅长这个。":
            hide pboy
            hed konsul "在克罗汉姆失去所有四肢后，我曾是一名战地医生。"
            hed talk "我必须表现得好，否则更多人会和我遭遇同样的命运。"
            hed smile "最终，我们可能输掉了战争，但我仍然和我照顾过的猎人们保持联系。"
            hed talk "我认为这对我来说已经是足够的胜利了。"
    show hedwin smile
    "当海德温女士说话时，你注意到液体开始变黑。漆黑如焦油。"
    play sound "sound/effects/splash.wav"
    hed frown "好了，你现在可以把手拿出来了。"
    "你拿出手，发现上面布满了小伤口，尽管黑色和蓝色的痕迹都消失了。"
    show tom talk ha sweat apa at right with moveinright:
        yoffset 190
    show hedwin at left with move
    tom "为什么还是这样伤痕累累？"
    "你终于听到阿什姆开口说话了。他一直坐在你旁边，在你在这里的整个过程中都握着你的左手。"
    "似乎更多是为了他自己的安慰而不是你的。你让他这么做，理解他需要这种安慰。"
    hed konsul sigh "可能会更糟。当我患上符文坏死症时，我亲眼看着我的整根手指在我面前分解。露出了骨头和所有内部结构。"
    tom sigh frusta "这并不能帮上忙，海德温女士。"
    show tom sad -frusta
    hed sad -sigh "啊，抱歉。我现在不该说这个，对吧？"
    hed talk "伤口最终会愈合的。我建议你至少三天内不要在手上画符文。"
    hed konsul "我会给维尔科娃女士留个便条，让她在这期间免除你的任何战斗训练。"
    show hedwin frown
    tom sad apa "就这样？我还能做些什么吗？"
    hed evil cling "你可以放开[dia]的手。继续那样握着，[kamu]的左手可能也需要治疗了。"
    show hedwin wry -cling 
    show tom hip frown shock -sweat
    "阿什姆听到这话似乎很尴尬，立刻松开你的手，好像它着火了一样。"
    show pboy at horzappear
    menu:
        "自由啦！":
            hide pboy
            $ ibu.points -= 5
            if ibu.points <0:
                $ ibu.points = 0
            $ honesty += 15
            hide boy
            show side_p w at pic
            mc "啊，我又能感觉到我的手了！"
            hide side_p
            tom sigh both frusta "我握得并没有那么紧。"
            show tom capek -both
        "握住他的手":
            hide pboy
            $ ibu.points += 5
            $ tom_events.append("held")
            show tom frown blush shock
            play sound "sound/effects/cloth.mp3"
            "你决定伸手握住阿什姆的手，同样紧紧地握着，以此来安抚他。"
            show side_p w at pic
            mc "嘿，没事的，我很高兴你在这里。"
            hide side_p
            tom smile blow "我也很高兴我在这里。"
            show tom scold lega -blush -blow
        "感谢他":
            hide pboy
            $ kindness += 15
            show tom wry blush
            show side_p se at pic
            mc "嘿，没事的。谢谢你安慰我。"
            hide side_p
            show tom frown -blush -shock
    hed konsul bunga "啊哈哈。你们两个真可爱啊？那么，我现在要走了。"
    hed talk -bunga "如果你需要我，我会像往常一样在教堂。"
    tom lega blow "谢谢你，海德温女士。"
    play sound "sound/effects/door.mp3"
    hide hedwin with dissolve
    if girl:
        show palmierproxy chill frown at left with moveinleft:
            yoffset 40
    else:
        show palmierproxy chill frown at left with moveinleft:
            yoffset 100
    show tom smile -blow 
    "当她离开时，你听到阿什姆长长地呼出一口气。"
    tom giggle cling "哈啊...你真是不可思议，你知道吗，[povname]？"
    show tom wry -cling 
    mc scratch apa sweat sigh "你把差点失去一只手称为\'不可思议\'？"
    tom talk pfft "我是说你的蓝色火焰。这是个秘密，但我已经尝试召唤那种火焰好几个月了。"
    tom hip sigh frusta "我最多只能召唤出凤凰火焰。而你却像什么都不是一样施展了那个咒语。"
    tom frown apa "几乎就像是意外一样。"
    mc avoid frusta "（因为确实是意外！）"
    show palmierproxy chill frown both shock
    tom scold lega blush blow "你真是不可思议。我不知道我是否能赶上你。"
    show tom smile -blow
    show pboy at horzappear
    menu:
        "你其实不必非要赶上我。":
            $ ibu.points += 5
            hide pboy
            show tom frown -blush shock
            mc kind -both sigh "我是说...我们都有自己的长处和短处。"
            mc happy blush bunga "我并不比你高或低。我们是平等的，每个人进步的速度都不一样。"
            show palmierproxy frown -blush shock
            tom hip sad apa "我们真的是平等的吗？"
            tom sigh blow sweat "每次我试图赶上你，你就跑到我前面好几英里。"
            show tom frown shock
            mc mock cling "好吧，也许如果你不去诅咒部里的官员和操纵其他学生，你就能跟上我的步伐了。"
            tom eh sweat -shock "我做那些事只是因为——"
            show tom frown -sweat shock
            play sound "sound/effects/knock.mp3"
            "一阵响亮的敲门声打断了阿什姆的思路。"
            scene uks with dissolve
            stop music
            play sound "sound/effects/door.mp3"
            show red chin bingung at left with moveinleft:
                yoffset 330
            show quil datar at right with moveinright:
                yoffset 200
            red "[nickname]，阿什姆，你们还好吗？！"
        "再多夸夸我！":
            hide pboy
            show palmierproxy smile blush bunga
            tom talk amused cling "哈哈。你比里斯的所有海妖都更美丽，比西奥德的任何学者都更聪明。"
            tom calm spark "比卡斯特里的任何贵族都更狡黠优雅。当上天创造你时，天使们都来观看——"
            show tom wry blush -spark
            mc avoid both frusta "好了好了，我明白了，罗密欧！"
            mc scratch ha sigh "天啊，你总是随时准备好这些恭维话，是不是？"
            tom pfft "这些不仅仅是恭维。这些都是事实！"
            tom lega bloom "你简直是我见过的最神圣的存在。"
            mc apa both frusta "好了，别说了，你现在让我觉得很尴尬。"
            mc malu sigh"（天哪，如果我们还没开始约会他就这样了，我简直无法想象以前他是什么样子。）"
            hide side_p
            show tom frown -blush shock
            scene uks with dissolve
            stop music
            play sound "sound/effects/door.mp3"
            show red chin bingung at left with moveinleft:
                yoffset 330
            show quil datar at right with moveinright:
                yoffset 200
            red "[nickname]，阿什姆，你们还好吗？！"


        "你是完美的。":
            hide pboy
            show tom frown both shock
            show palmierproxy smile blush sigh
            tom sad talk -both apa "...你说什么？"
            mc happy cling"我说你就这样很完美。虽然有点爱操纵人心，有点两面派，但是..."
            mc scratch ha both frusta "...我开始明白这里的每个人都是混蛋，不管以什么方式..."
            tom hip ha frusta "..."
            show tom sad sweat hip blow
            show palmierproxy confused sweat shock
            "阿什姆僵硬地坐着，凝视着你的眼睛，嘴唇紧绷，深深地皱着眉头。"
            mc rajuk tanya "我说错什么了吗？"
            show palmierproxy chill sad shock
            tom nyesal frusta "不，只是...如果我\'完美\'，那你为什么要离开我？"
            tom scold sad sweat apa "你还想要什么？"
            show tom sad -sweat -apa
            mc side -shock"哦，我——"
            $ ibu.points += 20
            if "perfect" not in tom_events:
                $ tom_events.append("perfect")
                
            tom sigh blow "我所做的一切，都是为了你。我的成绩，我的外表，我的个性...这些都是为了给你应得的完美生活。"
            tom whine frusta "然后你离开了我，说我软弱，可替代——就像某种玩具一样。"
            tom hip nyesal -frusta "我不...我不明白是什么改变了。"
            show tom sad
            show pboy at horzappear
            menu:
                "\'我有问题。\'（顺着说）":
                    hide pboy
                    mc side frusta "（我知道，这个问题严格来说不该我回答，但是...我知道有那么多问题得不到回答是什么感觉。）"
                    mc sad -sweat sigh "（也许如果我告诉他他需要听到的话，他就能慢慢放下？）"
                    show tom frown -sweat shock
                    mc wry -sigh "从来就不是你的问题，是我的问题。我...我生活中发生了一些事，我不想让你或其他任何人卷入其中。"
                    mc ow "我最终为了你好而把你推开，说了那些刻薄的话让你能够继续前进，但是..."
                    mc sad sigh "...即使到现在，我还是为此感到内疚。对不起，阿什姆。"
                    tom calm -shock"..."
                    show palmierproxy kind -sigh
                    tom giggle "谢谢你告诉我这些。我不知道是什么改变了，但你在这个夏天变得非常开放和健谈，[povname]。"
                    tom pfft blow "我很高兴。"
                    tom wry talk -blow "我知道你之前说过不，但如果你能重新考虑一下..."
                    tom smile blush "我很荣幸能再次成为你的男朋友，[nickname]。"
                    show tom -blush
                    mc frown both shock "阿什姆，我——"
                    

                "坦白你的身份。":
                    hide pboy
                    mc sad sweat sigh "阿什姆，有件事你需要知道。现在的我和以前的我，嗯..."
                    mc scratch ow frusta "我该怎么解释呢——"
                    if "come_clean" not in tom_events:
                        $ tom_events.append("come_clean")
            scene uks with dissolve
            stop music
            play sound "sound/effects/door.mp3"
            show red chin bingung at left with moveinleft:
                yoffset 330
            show quil datar at right with moveinright:
                yoffset 200
            red "[nickname]，阿什姆，你们还好吗？！"
            "就在你准备解释的时候，塞恩突然冲进了门。"
    show red datar point shock
    show tom eh hip frusta at center behind red with dissolve:
        yoffset 190
    tom "红色的，你在这里做什么？"
    show tom kzl -frusta
    show red amused -shock
    play music "MUSIC/MusMus-BGM-016.mp3"
    quil flashy heh cling "打扰一下？我也在这里。没有\'嗨，奎尔\'，或者\'谢谢你来\'吗？"
    show quil laugh -cling
    show red wry sigh
    show tom capek frusta
    show side_p f at pic
    mc "你们两个在这里做什么？"
    hide side_p
    show tom -frusta
    quil mock sigh "亲爱的，你在这里待了这么久。看到你受伤，我差点心脏病发作。"
    quil ow frusta "这比塞恩上学期的伤还要严重，他当时差点失去两根手指！"
    show quil wry -frusta
    red ngeles sweat sigh "是啊，我们实在忍不住了，伙计，到底怎么回事？"
    show red frown shock
    show quil amused
    if "held" in tom_events:
        "塞恩瞥了一眼你们的手，注意到它们仍然像恋人在床上的四肢一样纠缠在一起。"
    red chin awkward -shock blush "哦，呃，除非我们打扰到什么了？"
    show red sayang
    quil wink cling "*喘气*，在医务室的床上干坏事？天哪，阿什姆，我还以为你是个绅士呢。"
    show red frown shock
    play sound "sound/effects/pillow.mp3"
    quil skul ow shock sweat "呸！"
    show red calm -shock
    show tom kzl frusta
    show quil err -shock
    "阿什姆把一个枕头直接扔到了奎尔夸张的、假装震惊的脸上。"
    tom capek "奎尔，你能不能别总是说个不停？"
    show tom kzl shock
    show quil cringe shock 
    play sound "sound/effects/pillow.mp3"
    red cowo bunga point "哦，是要打枕头仗吗？来啊！"
    play sound "sound/effects/pillow.mp3"
    tom talk ew shock "不，你这个白痴！啊——！"
    
    "塞恩从椅子上抓起一个靠垫，正好打在阿什姆的脸上。"
    show tom kzl frusta
    show quil flashy wink -sweat cling
    play sound "sound/effects/pillow.mp3"
    queue sound "sound/effects/pillow.mp3"
    "奎尔紧随其后，从另一张床上抓起枕头，把两个枕头都扔向了你。"
    scene uks with dissolve    
    show side_p se at pic
    mc "哦，开始了！"
    hide side_p
    play sound "sound/effects/pillow_war.mp3"
    queue sound "sound/effects/pillow_war.mp3"
    if girl:
        galleryunlock murder_f
        show murder_f at center with dissolve:
            yalign 0.1 
    else:
        galleryunlock murder
        show murder at center with dissolve:
            yalign 0.1 
    hide side_p
    "你不确定自己去医务室的旅程是如何演变成一场全面的枕头大战的，但无论如何你都很高兴它发生了。"
    scene uks with dissolve
    stop sound
    show tom scold sigh frusta at center with dissolve:
        yoffset 190
    tom "你们这些无礼的小鬼冷静下来了吗？"
    show tom ha
    show red point cowo at left with moveinleft:
        yoffset 330
    show quil skul wry at right with moveinright:
        yoffset 200
    red bunga blush "哦，得了吧，阿什，你也玩得很开心。"
    tom lega blush bunga "...我不知道你在说什么。"
    
    red chin sayang -blush sigh "嗯，当然了。"
    show tom frown -blush -bunga
    red bingung apa "顺便问一下，海德温怎么说，[nickname]？你没事吧？"
    show side_p f at pic 
    mc "我右手三天内不能使用符文，但应该没什么大碍。"
    hide side_p
    quil fluster sweat frusta "三天？那我们一起的任务怎么办？"
    stop music
    tom eh shock "你们有任务？"
    show tom frown -shock 
    show red frown -apa
    quil panik -sweat sigh "悬赏一个叫梅扎的巫师。她的人头值五十万。"
    show quil datar -sigh
    show side_p f at pic
    play music "MUSIC/MusMus-BGM-049.mp3"
    mc "（哦，他是这个意思啊。他真是个机会主义者，不是吗？）"
    hide side_p
    red point kaget shock "五十万？！你认真的吗？！"
    show red frown
    tom ha apa "那可是一大笔钱。"
    tom kzl blow "这通常意味着有很大的风险或条件。"
    show tom frown -blow
    quil flashy wink cling "别担心，是后者。我想这个巫师和贵族有关系，你知道梅扎的欲望之屋吗？"
    show quil smile -cling
    red bingung apa"什么屋？从没听说过。"
    show red frown -apa
    tom eh scold apa "那不是只有百分之一的人才能玩的妓院吗？即使在贵族和高层中也是高度排他的。"
    tom capek hip blow "排他性强到没人会透露它的位置。"
    show tom frown -blow
    quil skul talk "好吧，有人发现它可能不只是个肮脏的秘密，而更像是个巫师的秘密。"
    quil wry "客户想让我和[povname]去侦查一下那个地方，打打头阵。"
    tom kzl frusta "那你们究竟要怎么进去？"
    show tom frown
    quil laugh "客户给[povname]发了邀请函，应该能让我们进去。"
    quil flashy wink cling "但是，考虑到[povname]的伤势，我们真的需要一些后援。你们这些可爱的男孩想来个夜间外出吗？"
    quil hister spark "50万分4还是12.5万。"
    show quil skul smile -spark
    tom kzl cling "奎尔，你到底在哪里接到这个悬赏的？我没在任务板上看到。"
    show tom ha -cling
    quil avoid "刚刚才发布的，你查查看。"
    show quil datar
    tom frown "..."
    "尽管持怀疑态度，阿什姆还是滑动了手机。读完帖子后，他的脸绷紧了。"
    tom kzl sweat frusta "描述很模糊。看起来连客户自己都不确定是不是巫师。"
    show tom frown -sweat -frusta
    quil mock "是啊，只是推测。如果不是巫师，报酬就只有一千，不过还是不错的活儿。"
    show quil datar
    red ew apa "这就说得通了。你确定这不是俱乐部自己在猎巫人圈子里做营销吗？"
    show red huh -apa
    quil hister "嗯，即使是这样，这也是进入世界上最神秘的夜总会的机会。听起来很有趣，不是吗？"
    tom capek blow "狂妄不适合你，奎尔。没人会在没有充分了解风险和恐惧的情况下发布50万的悬赏。"
    show tom kzl -blow
    quil heh sigh "是啊，[povname]和我已经决定去了。所以你可以跟着来，或者在这里等着之后唱颂我的胜利。"
    show quil datar -sigh
    red cowo blush "我加入，我可以用这笔钱买些血。"
    quil hister spark "阿什？"
    tom capek talk frusta sweat "如果[povname]带着那样的伤还要去，那我最好也一起去。"
    show tom frown -sweat
    quil flashy wink cling "那就这么定了。我们周日晚上7点整在阿什姆的房间集合！"
    show quil datar -cling
    tom ew apa "为什么一定要用我的房间？"
    show tom kzl -apa
    quil sly sigh "因为，和我们其他人不同，你的房间是单人间。我们都知道你不知怎么说服那个可怜的一年级新生退学了。"
    show quil wry -sigh 
    tom capek blow"他烦到我了。而且我对没有家族姓氏的猎人没兴趣。"
    red chin awkward sigh "这就是为什么你有追随者而不是朋友，阿什姆。"
    show red hister cling 
    show tom kzl frusta
    quil hister blush bloom "除了我们三个。你爱死我们了，对吧，爸爸？"
    tom lega blow "住口。"
    show quil amused -bloom
    show red happy -cling
    "尽管一开始看起来很恼火，阿什姆还是露出了一丝微笑。我意识到关于他的一件事是..."
    show tom smile -blow
    show side_p f at pic
    mc "（...他无疑是个操纵人心的混蛋。但他确实对你们这个四人小团体，还有莱尔，似乎有特殊的偏爱。）"
    mc "（这很...）"
    hide side_p
    show pboy at horzappear
    menu:
        "让你感到困惑。":
            hide pboy
            $ curiosity += 5
            "他对你们像对待皇室成员，但对其他人却像对待棋盘上的卒子。"
            "你担心有一天你也会成为他的卒子之一。"
        "可以接受。":
            hide pboy
            $ kindness += 10
            "不同的世界，不同的道德标准。虽然在你的世界里，你不能说阿什姆是善良的，但按照这个世界的标准，他算是善良的。"
            "只要他不把你当作他小游戏中的棋子，你就能接受他现在的态度。"

        "令人不安。":
            hide pboy
            $ honesty += 5
            $ ibu.points -= 15
            if ibu.points <0:
                $ ibu.points = 0
            "这个人对待他人就像是他小小棋局中的棋子。"
            "你不知道这是他的天性还是后天养成的。"
    
    red grin point "你来吗，[povname]？"
    show red calm
    show side_p f at pic
    mc "啊？"
    hide side_p
    tom wry "晚餐。你应该吃点东西然后直接去睡觉。"
    show side_p w at pic
    mc "好的，妈妈。"
    $ my_events.append("day4_end")
    hide side_p
    show red hister blush
    show quil malu sigh 
    tom capek both frusta hip "你也这样..."
    stop music
    scene bg_black with w20
    "你和男孩们一起吃了晚餐，然后直接去睡觉了。"
    jump morning

label poppy1:
    play music "MUSIC/MusMus-BGM-064.mp3"
    show poppy base laugh at center with dissolve
    py "欢迎各位，今天我们将制作水仙之怒。我知道这对你们来说是一种相当高级的魔药，但你们都通过了魔药学101，所以我相信你们能够应付。"
    py hair fake"[povname]，亲爱的。你能解释一下这种魔药到底有什么作用吗？"
    show side_p s at pic
    mc "（糟糕。）"
    hide side_p
    show pboy at horzappear
    menu: 
        "让你讨厌自己？":
            hide pboy
            show poppy base wry
            "虽然显然是错误的答案，但你确实听到了一两声笑声，主要来自女生。"
            py awkward "嗯，是的，虽然这可能是一个显著的副作用，但恐怕这不是我想要的答案。"
        "让你变成自恋狂？":
            hide pboy
            $ NPC = "Student"
            npc "你不需要帮助就能做到这一点。"
            py base suspicious "安静，孩子们！我在这个班级里有严格的禁止欺凌政策！"
            py cry "话虽如此，我对你很失望，[povname]。扣五分，因为事先没有阅读。"
        "完全不知道。":
            hide pboy
            py base cry "哦天哪，一点都不知道吗？"
            show poppy sad
            show side_p s at pic
            mc "是的，女士。"
            hide side_p
            py kaget "真遗憾。扣五分，因为事先没有阅读。"
    py laugh "水仙之怒是一种能让你创造出自己的物理复制品的魔药。可以说是一种克隆魔药。"
    py fake "然而，效果只会持续几个小时，而且复制品的性格总是与你相反。"
    py wry "因此，它在间谍活动中很糟糕，但在战斗中经常作为诱饵非常有用。"
    py kaget "这种魔药特别不稳定，因为使用的材料已经被施加了魔法。"
    if "help_me" in my_events:
        py laugh "通常这些材料很难获得，不过，迪特里希先生很慷慨地为这节课提供了一面完整的魔法镜子。"
        py fake "所以一定要记得之后感谢他。"
        "阿什姆听到这句话后用手肘轻推了你一下。他俯身在你耳边低语。"
        hide poppy with dissolve
        show tom scold frown at center with dissolve:
            yoffset 190
        tom apa "你觉得这种魔药和迪特里希先生的计划有关吗？"
        show tom hip -apa
        hide tom with dissolve
        show side_p f at pic
        mc "肯定有关。我觉得那个人不会无缘无故给她这么贵重的东西。"
        hide side_p
        show poppy base laugh at center with dissolve
    else:
        py laugh "通常这些材料很难获得。不过，我的兄弟科夫为我找到了一些。"
    py awkward "由于这些材料非常稀缺，请你们在制作时要慢慢来，不要闲聊。请专注于手头的任务。"
    "在一个学生递给你一袋玻璃碎片后，阿什姆立即从你手中接过袋子，同时轻轻抚摸了一下你的手。"
    hide poppy with dissolve
    show tom talk wry at center with dissolve:
            yoffset 190
    tom "小心点，别割伤了。" 
    show tom frown
    show side_p f at pic
    mc "好的。顺便说一句，阿什姆——"
    hide side_p
    if "bye_boner" in quil_events:
        tom scold ejek cling "哦，说到魔药，我今天早上在奎尔的饮料里混了一些\'告别勃起\'。"
        show tom pfft -cling
        show side_p f at pic
        mc "等等，什么？"
        hide side_p
        tom talk smile "你知道的，你的请求。"
        show side_p s at pic 
        mc "（该死，我忘了取消这个请求！）"
        show side_p w
        mc "啊哈哈，有效果吗？"
        hide side_p
        tom amused "还不确定，我们只能等着看结果了，不是吗？"
        tom frown blow "老实说，我这么做更多是为了让他能专注于我们和梅扎的任务，而不是因为你的请求。"
        tom hip calm -blow "我觉得让他停止做爱一天，专注于我们需要的魔药制作，对我们更有利。"
        show side_p w at pic
        mc "哦，所以魔药的效果只会持续一天？"
        hide side_p
        tom ejek "实际上，我设法让它持续了一年。"
        show tom giggle
        show side_p m at pic
        mc "整整一年？！"
        hide side_p
        show poppy hair kzl at left with moveinleft
        py suspicious "[povname]！请保持安静！"
        show side_p s at pic
        mc "对不起，波比小姐！"
        hide poppy with moveoutleft
        show side_p he at pic
        mc "等等，你说它会持续一年是什么意思？"
        hide side_p
        tom talk pfft "菲亚和我一起帮忙酿制的，你知道她有多喜欢捉弄奎尔。"
        tom giggle bunga "她把剂量加倍了，所以基本上我们得到了我们想要的整整一年的安静。想象一下，整整一年都不会从奎尔的房间里传出呻吟声。"
        show tom hip smile 
        show side_p w at pic
        mc "哈哈，是啊..."
        show side_p s
        mc "（奎尔会杀了我的。）"
        hide side_p
        tom amused -bunga "话说回来，你刚才想聊什么来着？"
    hide tom with dissolve
    show poppy hair sad at center with dissolve
    py kzl "别说话，拜托！专注于你们的魔药，各位！"
    show side_p s at pic
    mc "哈啊.."
    hide side_p
    $ NPC = "???"
    "也许我可以下课后和他谈谈。"
    scene bg_black with w20
    scene map_classes1 with w20
    show tom chill frown at center with dissolve:
        yoffset 190
    show side_p f at pic
    mc "等等，阿什姆。有空吗？"
    hide side_p
    if "slep1" not in active_quests:
        tom wry "为了你？"
        tom calm blow "随时都有。"
        tom amused apa "去你房间还是我房间？"
        show tom smile -apa
        show side_p f at pic
        mc "你的房间。我们去你的房间吧。"
        hide side_p
        tom amused blush bunga "好的。"
        scene bg_black with w20
        jump coba_confess
    else:
        tom scold sad sweat "对不起，不行。"
        tom frown -sweat "我得去莱纳尔买一条天使鱼，趁他们还没关门。"
        tom "这是制作隐形符文墨水的重要成分。"
        if "slep1" not in completed_quests:
            if check_inv_for(angel_items):
                python:
                    active_quests.remove("slep1")
                    completed_quests.insert(0, "slep1")
                show screen completedtask("任务完成！")
                $ gold += 500
            
                $ InvItem(*item_angel).toss(1)
        

                show side_p s at pic
                mc "我这里已经有一条天使鱼了，所以请听我说！"
                mc "这很重要。"
                hide side_p
                tom eh apa "...好吧。在这里说可以吗，还是我们应该换个地方？"
                show tom hip frown -apa
                show side_p f at pic
                mc "你的房间。我们去你的房间吧。"
                hide side_p
                tom "好的。"
                scene bg_black with w20
                jump coba_confess
            else:
                $ active_quests.remove("slep1")
                show screen completedtask("任务失败")
                show side_p s at pic
                mc "（哼，我想我没什么可争辩的。如果我想和他谈话，我应该事先准备好一条天使鱼的。）"
                show side_p he
                mc "好吧，但是等梅扎完事后，我们谈谈，好吗？这很重要。"
                hide side_p
                tom scold lega "一定。"
                $ NPC = "???"
                scene bg_black with w20
                if "bunga_bego" in buff_events:
                    if "beku" in quil_events:
                        scene map_infected_f with w20
                    else:
                        scene map_infected with w20
                else:
                    if "beku" in quil_events:
                        scene map_frozen with w20
                    else:
                        scene map_all with w20
                jump world_map
        else:
            show side_p s at pic
            mc "我已经给你弄到一条天使鱼了，所以请听我说！"
            mc "这很重要。"
            hide side_p
            tom eh apa "...好吧。在这里说可以吗，还是我们应该换个地方？"
            show tom hip frown -apa
            show side_p f at pic
            mc "你的房间。我们去你的房间吧。"
            hide side_p
            tom "好的。"
            scene bg_black with w20
            jump coba_confess

label coba_confess:
    scene kmr_sore with w20
    play music "MUSIC/MusMus-BGM-047.mp3"
    show tom scold amused at right with moveinright:
        yoffset 190
    tom apa "要来杯加蜂蜜的茶吗？"
    if girl:
        show palmierproxy frown at left with moveinleft:
            yoffset 40
    else:
        show palmierproxy frown at left with moveinleft:
            yoffset 100
    "阿什姆一关上卧室门就问道。你注意到空气中弥漫着浓郁的茉莉花茶香，他的桌子上还放着一个温热的茶壶。"
    show tom smile -apa
    mc apa scratch tanya "它怎么还在冒着热气？"
    show palmierproxy frown -tanya
    tom talk lega "保温符文，我画在壶底下了。虽然不如冰箱上的制冷符文那么有效，但总比冷茶强。"
    tom smile "要来一杯吗？"
    mc chill ew sweat frusta "不，呃...我更想快点说完。你最好坐下。"
    show tom hip ha
    "阿什姆听到你的要求挑了挑眉，但还是照做了，选择坐在窗台边。"
    tom frown apa "我在听。"
    show tom -apa
    mc scratch confused -frusta "（好吧，我该怎么说呢？）"
    if "come_clean" not in tom_events:
        $ tom_events.append("come_clean")
    show pboy at horzappear
    menu :
        "慢慢引入话题":
            hide pboy
            mc chill ha "阿什姆，你相信平行宇宙吗？"
            tom whine apa "...平行宇宙？"
            show tom ha sweat -apa
            mc eiden "你知道，就是存在着一个完全不同的世界，与你的世界相映照。"
            mc hister "在另一个地方有另一个你，也许过着完全不同的生活，但一切都同时发生。"
            mc scratch huh frusta "其他世界？"
            mc panik "（哇，连我自己都觉得这听起来很疯狂。也许这行不通。）"
            show palmierproxy chill frown shock
            tom frown -sweat "...就像《爱丽丝梦游仙境》那样？" 
            mc laugh blush -shock "对！实际上就是这样！"
            mc happy "想象一下，有另一个世界，那里塞恩是红心皇后，你是三月兔，奎尔是白兔！"
            show palmierproxy frown -blush
            tom scold kzl frusta "...我就不能当白国王吗？我能理解为什么你把奎尔比作兔子，但是我？"
            show tom frown -frusta
            mc huh frusta sweat "这不是重点，不过可以。"
            mc happy -sweat -frusta "你是白国王，我是白皇后，我们都在仙境里过得很开心，但还有另一个我是爱丽丝。"
            show palmierproxy smile 
            tom ha apa "另一个你？"
            show tom -apa
            mc confused cling "是的。另一个我，因为奎尔来到了仙境。他带我到了兔子洞，然后，我就来到这里了！"
            "你挥舞着双臂，手舞足蹈地试图解释这个世界就是你的\'仙境\'。"
            tom eh sweat apa "...你就来到这里了？"
            show tom sad -apa
            mc sad "在仙境里！这个...这个充满巫师的世界不是我的世界，这是仙境！"
            show tom ha shock
            mc ow frusta "我不是你的白皇后，我只是一个长得和白皇后一模一样的爱丽丝！"
            tom sigh blow "...好吧。"
            tom ew apa "[povname]，你是在告诉我你现在正嗑着迷幻药吗？或者也许是在经历爱丽丝梦游仙境综合症？"
            tom ha -sweat "也许感觉自己比平常更小或更大？"
            mc apa sweat frusta "不！你没在听我说——！"



        "去他的！":
            hide pboy
            mc chill pissed sigh "去他的！"
            mc kzl -sigh "我不是你的[povname]！"
            show tom frown shock
            "阿什姆盯着你看了一分钟，然后两分钟..."
            tom sigh blow sweat "...你又要和我分手吗？除非——否则我觉得没这个必要。"
            show tom ha shock
            mc sad sweat frusta "不是！"
            mc ow "我的意思是，我真的不是你的[povname]！我是来自另一个世界的平行版本。"
            tom hip kzl apa "你说什么？"
            mc kzl -frusta "多元宇宙，其他维度，你们看过漫威和他们的所有电影吗？我是说，你们这里一定有漫威吧，对吧？"
            tom ha frusta "大理石....你是说地砖？"
            mc ow frusta "不是！我，呃...奎尔做了一些疯狂的恶魔召唤仪式，把我传送到这个世界，让我替代你们那个陷入昏迷的[povname]，然后——"
            show tom sad shock
            "阿什姆脸上带着担忧的表情，站起来捧住你的脸，让你安静下来。"
            tom whine blow "亲爱的，我知道你之前让我不要这么做，但是...我要不要给你母亲打个电话？我相信心理医生可以帮你克服你的成瘾问题。"
            tom sigh -blow "也许参加一次戒酒互助会？"
            show tom ha 
            mc grit frusta "我没醉！"
            mc ew "听着，如果你跟我来，跳进湖里..."
    show palmierproxy confused -sweat shock
    tom sad "嘘..."
    tom capek blow "菲亚警告过我这种情况，担心你会复发，重新沾上毒品。"
    tom eh -blow "来，我把我心理医生的号码发给你，[povname]。她会帮助你的。"
    show tom ha 
    mc apa tanya "我不需要——等等，你去看心理医生了？"
    show tom amused -sweat
    show palmierproxy frown -tanya
    "阿什姆对你的问题耸了耸肩。"
    tom talk frown -sweat "寻求帮助没什么可耻的。"
    tom nyesal "我们的分手让我陷入了困境。我认为寻求专业帮助是明智的。"
    tom frown "肖夫人是位很有耐心的女士，她会帮你重新站起来的。"
    mc confused "哦，嗯，好吧...呃，如果你不介意我问的话，你为什么去看心理医生？"
    tom hip sigh sweat blow "为什么？嗯，你甩掉我的方式相当残酷，尤其是当你把我母亲的戒指扔回给我时的那些评论。"
    tom capek frusta "我知道相比你家族的财富，这算不了什么，但我期望你能更尊重一些，因为你完全了解我母亲的背景。"
    tom ha -frusta "她本可以卖掉那枚戒指来维持生计，但她保留了它，因为那是我们家族的传家宝。"
    tom frown sweat "我以为你会喜欢它，因为它让我想起你自己的坚韧。美丽而坚强。"
    tom sigh blow "但我想你误解了这一切，称它为丑陋。"
    mc scratch apa sweat "（该死，我真是个婊子。）"
    mc huh "哦-哦..."
    show palmierproxy sad shock
    tom capek frusta "然后你把我赶出了你的房间，当时我还赤身裸体，试图解释。"
    tom sad -sweat "把我的东西从窗户扔出去，说你的生活中已经有了另一个人。"
    mc ha -shock "哦..."
    tom kzl "当我敲门想谈谈时，你告诉老师我在骚扰你。"
    tom sigh blow "所以我不得不赤身裸体在校长办公室接受留堂处罚。"
    mc chill ow "...哦。"
    tom kzl frusta "这也是我如此憎恨威廉的部分原因：那种羞辱。他本可以让我穿上衣服的。"
    mc panik "（哇....什么鬼？）"
    mc side tanya "即使经历了这一切，你还爱我吗？"
    show palmierproxy frown shock
    tom amused blow "肖夫人也说过同样的话，称之为依赖问题。或者，我比我想象的更受虐狂，但是..."
    tom calm -blow "我选择相信并非如此。你的行为伤害性如此强，几乎感觉是故意的。"
    mc confused -sweat tanya "故意的？"
    show palmierproxy frown -tanya
    tom scold frown "就像你做了所有那些伤害性的事情，是为了让我真正地放下。"
    tom amused "这对我来说是个残酷的方式，用来放弃对你残存的任何感情。"
    tom pfft "从那天你在校长办公室外提供的衣服，以及一周后你寄给我母亲的秘密道歉信来看——我想我的猜测并没有偏离太远。"
    tom smile "你甚至还用了那句话，\'如此精致的戒指应该由内外都美丽的人来佩戴。\'"
    tom hip lega "这真是太...{i}像你了{/i}。残酷，却又善良。"
    show tom smile
    mc huh sweat sigh "哇...你这个可怜的妄想狂。"
    show palmierproxy malu -sweat -sigh
    tom ejek cling"我更喜欢用\'坚韧\'这个词。"
    show tom smile -cling
    mc scratch eiden both "（这简直是疯了。这是什么样的痴情傻瓜啊？）"
    mc rajuk frusta "（就连菲亚那些老掉牙的爱情小说里的男主角都没有这么忠诚。）"
    mc ew sigh "...我放弃了。"
    show palmierproxy chill frown -both -sigh
    tom ha apa "什么？"
    mc huh frusta "我想我无法向你解释我的处境。至少现在不行，但我已经尝试过了。"
    mc malu sweat sigh "我的良心暂时只能满足于此了。"
    "说完这些，你深深地叹了口气，痛苦地摇了摇头。"
    mc wry -sigh "我去给你的心理医生打个电话，阿什姆，谢谢。不过呃，在那之前，我们还需要为梅扎准备什么吗？"
    show palmierproxy chill frown -sweat
    tom talk frown -apa "应该就这些了，只要其他人都尽自己的一份力。"
    tom hip smile blow "来吧，我们应该去魔药课帮奎尔熬制药水。科尔知道塞恩不会帮忙的。"
    "你花了剩下的时间帮助阿什姆和其他人处理墨水，每当阿什姆向你闪现那痴情的微笑时，你就会叹气。"
    scene bg_black with w20
    stop music
    jump morning

label bad_end_game:
    scene bg_black with dissolve
    $ quick_menu = False
    show text "Credits: \nArt and script made by Miss Xero. \n Ren'py Engine 8.2. \nSound Effects from Freesound \nMusic from Peritune, MusMus, and Stock Media provided by moarnmusic - Pond5 \nFree-to-use framework codes from sDextra, Wattson, and NomnomNami \nIcon assets from Matt Firth (shikashipx) and game-icons.net." with dissolve
    $ renpy.pause()
    scene patron_list1 with dissolve
    $ renpy.pause()
    scene patron_list2 with dissolve
    $ renpy.pause()
    scene patron_list3 with dissolve
    $ renpy.pause()
    $ MainMenu(confirm=False)()

label end_game:
    hide screen cal
    $ quick_menu = False
    scene bg_black with dissolve
    show text "感谢您的游玩！" with dissolve
    $ renpy.pause()
    scene bg_black with dissolve
    show text "Credits: \nArt and script by Miss Xero. \n Ren'py Engine 8.2. \nSound Effects from Freesound \nMusic from Peritune, MusMus, and Stock Media provided by moarnmusic - Pond5 \nFree-to-use framework codes from sDextra, Wattson, and NomnomNami \nIcon assets from Matt Firth (shikashipx) and game-icons.net." with dissolve
    $ renpy.pause()
    scene patron_list1 with dissolve
    $ renpy.pause()
    scene patron_list2 with dissolve
    $ renpy.pause()
    scene patron_list3 with dissolve
    $ renpy.pause()
    $ MainMenu(confirm=False)()
