﻿##############################################################################
# Calendar
#
# Keeps track of the day, month, year, leap year, and lunar calendar.
# Thanks to xela from the lemmasoft forums!

init python:
    class Calendar(object):
        '''Provides time-related information.
        Cheers to Rudi for mooncalendar calculations.
        '''
        def __init__(self, day=1, month=1, year=1, leapyear=False):
            """
            Expects day/month/year as they are numbered in normal calender.
            If you wish to add leapyear, specify a number of the first Leap year to come.
            """
            self.day = day
            self._month = month - 1
            self.year = year
            if not leapyear:
                self.leapyear = self.year + 4
            else:
                self.leapyear = leapyear

            self.daycount_from_gamestart = 0

            self.days = ["Mon", "Tues", "Wed", "Thurs", "Fri", "Sat", "Sun"]
            self.month_names = ['/01', '/02', '/03', '/04', '/05', '/06', '/07',
                                               '/08', '/09', '/10', '/11', '/12']
            self.days_count = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]


        @property
        def game_day(self):
            """
            Returns amount of days player has spent in game.
            Counts first day as day 1.
            """
            return self.daycount_from_gamestart + 1

        @property
        def game_week(self):
            '''Returns the number of weeks, starting at 1 for the first week.
            '''
            weekidx = self.daycount_from_gamestart / len(self.days)
            return weekidx + 1

        @property
        def weekday(self):
            '''Returns the name of the current day according to daycount.'''
            daylistidx = self.daycount_from_gamestart % len(self.days)
            return self.days[daylistidx]

        @property
        def month_number(self):
            return self._month + 1

        @property
        def month(self):
            return self.month_names[self._month]


        @property
        def last_day_of_the_month(self):
            if self.leapyear == self.year and self._month == 1:
                return self.day == self.days_count[self._month] + 1
            else:
                return self.day == self.days_count[self._month]

        @property
        def string(self):
            return "(%s) - %s %d %d"%(self.weekday, self.month, self.day, self.year)

        def next(self, days=1):
            """
            Next day counter.
            Now supports skipping.
            """
            self.daycount_from_gamestart += days
            while days:
                self.day += 1
                days -= 1
                if self.leapyear == self.year and self._month == 1:
                    if self.day > self.days_count[self._month] + 1:
                        self._month += 1
                        self.day = 1
                        self.leapyear += 4
                elif self.day > self.days_count[self._month]:
                    self._month += 1
                    self.day = 1
                    if self._month > 11:
                        self._month = 0
                        self.year += 1
