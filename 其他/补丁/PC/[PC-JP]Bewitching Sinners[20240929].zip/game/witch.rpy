label night2:
    show screen cal
    $ quick_menu = True
    $ interlocutor = "Dad"
    $ del_all_msg()
    window hide
    show hp at move_messenger2
    pause 1.0
    $ show_messenger()
    $ msg ("爸爸，你收到一个叫梅扎的女人寄来的信了吗？")
    $ msg ("哦，你好，[povname]！真是个惊喜。", who=1, status='online')
    $ msg ("是的，我收到了。我之前没有告诉你吗？", who=1)
    $ msg ("没有！")
    $ msg ("哦，好吧……这是一份邀请函，上面只写着\'梅扎的欲望之屋\'。收件人是贝克一家。", who=1)
    $ msg ("当然，我不会理会这种邀请的。", who=1)
    $ msg ("我听说那是类似于妓院的地方，以酒吧作为幌子。", who=1)
    $ msg ("一个让富人和精英们能够释放他们最深、最黑暗欲望的地方。", who=1)
    $ msg ("不用说，我不想去那种地方。我不想让你妈妈担心。", who=1)
    $ msg ("但是，你年轻又单身，所以……你有兴趣去探查一下那个地方吗？", who=1)
    $ msg ("我知道你声称\'对富人过敏\'，但是和上流社会打交道也无妨。", who=1)
    $ msg ("即使这种聚会的场所至少可以说是相当可疑。", who=1)
    $ msg ("我去看看吧。你能把信寄给我吗？")
    $ msg ("当然可以。", who=1)
    $ msg ("谢谢。")
    $ hide_messenger()
    hide hp
    show hp2 at move_messenger3
    pause 1.0
    scene kmr_apt with dissolve
    "一封信被送到了你的物品栏。信上有浓郁的茉莉花香。里面，你看到一张印有酒吧名称的金色门票和一张带有指示的便条。"
    "烧掉这封信以获得入场资格。让火焰带你进入我的领域。"
    show side_p he at pic
    if girl2:
        mc "梅扎是伊瓦尔提到的名字。看来[povname]认识她，这个巫师甚至称[dia]为朋友。"
    else:
        mc "梅扎是伊瓦尔提到的名字。看来[povname]认识她，这个巫师甚至称[dia2]为朋友。"
    show side_p m
    mc "到底是怎么回事？我最好问问奎尔。"
    hide side_p
    stop music
    scene bg_black with circleirisin
    jump discuss_meyza


label meet_meyza:
    scene kmr_malam with w20
    $ my_events.append("met_mey")
    play music "MUSIC/MusMus-BGM-146.mp3"
    "今晚就是行动之夜。如约定，你在阿什姆的房间集合，准备在贪婪巫师的领域内与她对峙。"
    show quil libur sulk sweat at center with dissolve:
        yoffset 200
    "奎尔明显很紧张，尽力保持镇定。"
    show quil at right with move
    show tom go frown at center with dissolve:
        yoffset 190
    show red bebas datar at left with dissolve:
        yoffset 330
    "阿什姆似乎注意到了他举止的变化，但没有进一步追问。"
    tom apa"大家都准备好了吗？"
    show tom -apa
    red lelah sigh "嗯，要画不少符文。我知道这是按照海报要求的，但是……"
    show red amused -sigh
    quil talk -sweat "也许他们更希望我们宁可安全也不要抱歉。"
    show quil datar
    red huh "我想是的。顺便说一下，这只是快速进出，对吧？"
    red awkward "希望我们能快点完成。我还没做符文图形学的作业呢。"
    tom ha apa "你为什么没有早点完成？"
    red hister sweat sigh "我试过了，但不知怎的时间就这样过去了。"
    show red kaget shock
    show quil sad shock
    tom cruel cling "你是不是看《命中注定的血缘》看忘了？"
    show tom amused -cling
    red perih frusta "嘘，嘘！别在奎尔面前说！"
    quil grit frusta "我就在这儿呢！还有，你们看《命中注定的血缘》没叫我？你们怎么能这样！"
    red sayang bloom "对不起，但真的很好看！贝拉咬了雅各布，然后——"
    show quil bingung sigh
    show red wry -bloom
    tom kzl frusta "我们可以稍后再讨论肥皂剧！"
    tom frown blow "专注于任务。快速进出，侦察区域。"
    tom -blow "对吧，奎尔？"
    quil talk -sigh "对，就是这样。"
    tom smile "很好。现在，[nickname]。你来做这个荣幸吗？"
    scene kmr_malam with flashbulb
    stop music
    play sound "sound/effects/api.mp3"
    "你用你的分身的打火机点燃了梅扎的邀请函。"
    "火焰迅速蔓延，开始吞噬你的全身。"
    show side_p k at pic 
    mc "他妈的怎么回事——？！"
    hide side_p 
    scene bg_black with w20
    "你等待着任何疼痛的迹象，但它从未出现。相反，你看到火焰变成黑色，将你拉入你自己的影子中。"
    scene mey_door with w20
    play sound "sound/effects/bump.mp3" 
    show side_p h at pic
    mc "什么？我们……我们在哪里？"with vpunch
    hide side_p
    play sound "sound/effects/walk.mp3"
    show waiter laugh at center with dissolve:
        yoffset 200
    play music "MUSIC/MusMus-BGM-064.mp3"
    npw "欢迎来到梅扎的欲望之屋！"
    show waiter smile
    "一位看起来快乐但诡异的女服务员在门口迎接你们。她的眼睛似乎在大量流血。"
    npw laugh "请出示你们的门票和手指！"
    show waiter smile at right with move
    show tom go frown apa at left with moveinleft:
        yoffset 190
    tom "手指？"
    show tom kzl shock 
    npw laugh "这是一项预防措施。你们身上不能有任何符文！哎呀，我能感觉到那里有墨水。得把它去掉。姑娘们，我需要一些帮助，拜托！"
    scene mey_door with dissolve
    play sound "sound/effects/cloth.mp3"
    "另外四名失明的女服务员出来检查我们每个人。"
    play sound "sound/effects/splash.wav"
    "女侍将水倒在你的手上，洗去了所有的符文墨水。她还抚摸到你的手肘，试图在你的皮肤上找到任何符文。"
    show waiter laugh at center with dissolve:
        yoffset 200
    npw "哦，我是不是在你的前臂上摸到了一个符文？真狡猾，真狡猾！"
    "英克威尔对女侍发现他的秘密感到恼火。令人惊讶的是，尽管这些女孩看起来是盲人，却能如此轻易地找到墨水。"
    npw smile apa "[povname]·贝克，是吗？我们一直在等你。真遗憾你的家人不能一起来。"
    show waiter -apa at right with move
    if girl:
        show palmierproxy jln wry at left with dissolve:
            yoffset 40
    else:
        show palmierproxy jln wry at left with dissolve:
            yoffset 100
    mc "我很抱歉，但你知道，生意优先。"
    mc hister sweat "我希望你不介意我带朋友来代替。"
    show palmierproxy wry
    npw pout sigh "嗯，说实话，这有点出乎意料。尤其是你带了一个英克威尔来这件事。"
    show waiter smile cling
    show quil libur tantrum sweat shock at center with dissolve:
        yoffset 200
    "女侍转头看向英克威尔，紧张地笑了笑。"
    show palmierproxy confused tanya
    mc "（她是怎么看到他的，还是说她用其他方式感知到他的？）"
    show palmierproxy frown
    show quil frown -shock -sweat
    npw smile -cling "不过这对我的女主人来说不是什么难事。进来吧，进来吧！"
    scene alley with dissolve
    play sound "sound/effects/door.mp3"
    show waiter smile at center with dissolve:
        yoffset 200
    "女侍打开门，露出一条昏暗的走廊。"
    npw laugh apa "你们都在伊格尼亚学习，对吧？我能闻到你们身上湖里百合花蕾的香味。"
    show waiter smile -apa
    show red bebas frown at left with moveinleft:
        yoffset 330
    red kaget apa "你说得对。哇，你能闻到吗？"
    show red frown -apa
    "女侍指了指她烧伤的脸。"
    npw laugh cling "失去一种感官，获得另一种。在这里工作的话，这是必须的。"
    show waiter smile -cling 
    show quil libur frown at right with moveinright:
        yoffset 200
    quil ow sweat frusta "亲爱的，烧掉半张脸似乎是相当大的牺牲，你就这么答应了？"
    show quil sad shock
    show red kaget shock
    npw laugh "呃，钱值得。"
    show red huh -shock
    show quil sulk -shock -sweat
    npw smile apa "说到钱，迪特里希先生还在那里教书吗？"
    red ngeles apa "等等，你上过我们学校？"
    show red sad -apa
    npw laugh -apa "嗯，我叫莱利。我大约三年前毕业的。"
    show waiter smile 
    quil err apa "可你现在却在这里，为一个巫师工作？"
    show quil frown -apa
    npw laugh "我知道，对吧？我有我的理由。梅扎夫人向我展示了真相。"
    npw pout "伊格尼亚的每个人都是伪君子。我们所有人都以某种方式从巫师那里获益。贵族比其他人更甚。"
    npw smile "我们这里的大多数客人都是通过与梅扎打交道而发家的。说实话，这很可悲。"
    npw laugh "当然，贝克家族是个例外。他们的肮脏勾当完全是靠自己的双手完成的！"
    show side_p mal at pic
    mc "啊哈哈..."
    show side_p g 
    mc "（我不知道该如何看待这件事。）"
    hide side_p
    scene booth_view with dissolve
    "莱利带你们进入建筑深处。你现在能听到人们交谈的声音，玻璃瓶碰撞的声音。"
    "空气中弥漫着刺鼻的烟草味道冲击着你的鼻子。"
    "这地方挤满了客人，所有人都盯着空荡荡的舞台，仿佛在等待上帝或\'科尔\'降临，向所有人现身。"
    "莱利带你们到房间角落的私人包厢。这是一个完美的位置，让你可以观察整个区域。"
    show waiter smile at center with dissolve:
        yoffset 200
    npw laugh "总之，这是你们的包厢和饮品菜单。"
    npw "需要什么就喊一声。如果你想离开，只需把撕开的票根重新拼在一起。玩得开心~！"
    scene tamu with dissolve
    "莱利离开了，让你观察外面的情况。"
    "环顾四周，你可以看到其他客人焦急地在座位上坐立不安。"
    "他们看起来都很有趣，有些人是你所预料的：黑领结..."
    "...戴着精美珍珠项链和名牌包的女士们，但仔细看..."
    "你注意到大多数女性的美甲看起来已经剥落且过时了。"
    "而大多数男性都面颊凹陷，头发凌乱，眼神狂野疯狂。"
    "幸运的是，你不是唯一注意到这一点的人。"
    scene booth with dissolve
    show tom go kzl cling at center with dissolve:
        yoffset 190
    tom "有些不对劲。"
    show tom capek frusta
    show red bebas ew at left with moveinleft:
        yoffset 330
    red sigh "是啊，菜单上没有血。"
    show red frown shock
    tom ha blow "不，塞恩。我是说客人们。我认识一些这些精英。林德尔大师，汉普斯维奇夫人。"
    tom kzl -blow "奎尔，那些不是正在申请破产的贵族吗？"
    show quil libur tantrum at right with moveinright:
        yoffset 200
    quil sigh "没错。而且他们不是唯一的。我认出那边的老西比尔。听说他最近试图把他最小的儿子卖给赫斯吸血鬼。"
    show quil frown
    red growl frusta "等等，你是说当血袋？他们为什么要这么做？！"
    show red kaget shock
    show tom frown 
    quil bingung apa"问题就在这里，传言说他找了个年轻情妇，把他的钱包吸干了。但我猜现在我们知道真正的原因了。"
    stop music
    play sound "sound/effects/doorslam.mp3"
    queue sound "sound/effects/woosh.mp3"
    galleryunlock appear_1
    scene appear_1 with fade:
        truecenter zoom 1.0
        easeout 1.5 truecenter zoom 0.5
    play sound "sound/effects/portal.wav"
    galleryunlock appear_2
    "当你们八卦时，灯光暗了下来，一阵风吹开了门。风聚集在一个地方，形成了一团诡异的黑烟。"
    scene appear_2 with dissolve:
        truecenter zoom 0.5
    
    play sound "sound/effects/woosh.mp3"
    "从烟雾中出现了一个魅力四射的身影，你只能猜测这就是你要找的人。"
    show side_p k at pic
    mc "梅扎..."
    hide side_p
    play sound "sound/effects/crowd.mp3"
    mey "欢迎各位尊贵的客人，来到这世界上最伟大的表演！"
    play music "MUSIC/bar_song.mp3" fadein 1.0
    "随着她的出场，观众们疯狂了，有些人掏出钱包，直接把金币扔到舞台上。"
    "工作人员似乎已经习以为常，他们有条不紊地四处奔跑，在金币落到舞台上的明星身上之前就把它们接住了。"
    
    
    scene booth with dissolve
    show tom go kzl at center with dissolve:
        yoffset 190
    tom "这就解释了破产的原因。"
    show quil libur bingung at right with dissolve:
        yoffset 200
    quil "她的力量一定是在影响人们的心智。"
    quil groan frusta "好吧，这让事情变得有点棘手了。"
    show quil sad sigh
    show red bebas sad at left with dissolve:
        yoffset 330
    red ow sweat frusta "糟糕，我们既没带任何药水，身上也没有符文！"
    
    show red ngeles shock -sweat
    tom capek blow "试着保持头脑清醒。把注意力集中在其他事情上。"
    show tom smile cling
    show red mls frusta
    show quil amused -sigh sweat
    "阿什姆将目光集中在你身上。"
    quil heh -sweat sigh "是啊，这并不是盯着[povname]看的借口，但你随意，阿什姆。"
    show tom ha sweat -cling
    show quil sulk -sigh
    red perih -frusta "想想裸体的老奶奶，想想裸体的老奶奶！"
    galleryunlock sing
    scene sing with dissolve
    "当男孩们陷入自己的焦虑中时，你慢慢地将注意力重新集中在梅扎身上。"
    "后面的乐器开始自动演奏，梅扎也开始唱起她那令人着迷的旋律。"
    "她唱得越多，客人们就越陶醉。奎尔和塞恩也不例外，他们的眼中很快就流露出痴迷的神情。"
    scene booth with dissolve
    show quil libur rajuk at right with dissolve:
        yoffset 200
    quil blush bunga "我...我要靠近点看看，为了研究。"
    show red bebas wry blush bunga at left with dissolve:
        yoffset 330
    red "对，我也是。"
    scene booth with dissolve
    show side_p k at pic
    mc "等等，塞恩，奎尔！"
    hide side_p
    "就在你准备跟随朋友们时，阿什姆拉住了你的手。"
    show tom go kzl blow at center with dissolve:
        yoffset 190
    tom "别鲁莽行事。现在采取行动只会弊大于利。至少等这首歌唱完。"
    show tom frown shock
    show side_p h at pic
    mc "...我想你说得对。等等，你怎么没受影响？"
    hide side_p
    tom ha -shock "你也没受影响。"
    show side_p fr at pic
    mc "啊！"
    show side_p g
    mc "（没错，我确实觉得她的声音很迷人，但是...没什么特别的。也许是因为我来自另一个世界？）"
    show side_p fr
    mc "我不确定为什么，她的声音很好听，但仅此而已。"
    hide side_p
    tom lega "我同意。老实说，我觉得你的歌声更加迷人。"
    show side_p h at pic
    mc "呃...什么？"
    hide side_p
    if girl:
        scene look_feme with dissolve
        galleryunlock look_feme
    else:
        scene look with dissolve
        galleryunlock look
    tom "你以前有时会唱歌哄我睡觉，记得吗？"
    tom "是的，虽然经常跑调，你还有根据心情改变旋律的习惯，但是..."
    tom "那是只有我知道的你的一面。奎尔甚至不知道你会唱歌。这是我们的小秘密。"
    tom "我很喜欢。"
    mc "阿什姆..."
    show pboy s at horzappear
    menu:
        "爱情既聋又盲！":
            hide pboy
            scene booth with dissolve
            show tom go kzl shock at center with dissolve:
                yoffset 190 
            show side_p g at pic
            mc "你这个可怜的陷入爱河的人。我知道爱情是盲目的，但我从没想过它还是聋的！"
            hide side_p
            tom pfft blow "嘿，你也夸奖过我那糟糕透顶的舞蹈。承认吧[nickname]，你曾经也对我一见钟情。"
            tom calm -blow "而现在我正在努力重新点燃那份火花。"
            show side_p g at pic
            mc "..."
            hide side_p
            "你不禁因他的话而脸红。他确实有点俗气，但你之前的那些风流韵事中，没有一个人能像他这样坦诚地表达自己的感受。"
            "这一次，你对这个世界的[povname]感到有些嫉妒。"
            scene booth with dissolve
            play sound "sound/effects/crowd.mp3"
            "就在你准备给阿什姆一个适当的回应时，一阵热烈的掌声打断了你。"
        "你值得更好的人。":
            hide pboy
            scene booth with dissolve
            show tom go frown shock at center with dissolve:
                yoffset 190 
            show side_p fr at pic
            mc "你似乎已经把生活安排得井井有条，我觉得你值得比一个正在戒酒的人更好的对象。"
            hide side_p
            $ ibu.points  += 10
            tom wry blow "是你给了\'妓女的儿子\'一个机会。你可能迷失了方向，但我们总能找到回家的路。"
            tom lega -blow "在你出现之前，我是个名副其实的混蛋小孩。我之所以能把生活安排得井井有条，全都是因为你。"
            tom pfft "我的学习，我的行为，甚至我对部长职位的兴趣，都是因为你。"
            show side_p k at pic
            mc "啊？"
            hide side_p
            tom smile "是你说过想成为一位部长的灵魂伴侣。这就是为什么我一直如此努力。"
            tom blush wry "我的学业成绩，我的计划，我所营造的外表，都是为了确保我们日后的地位..."
            tom calm "每一个选择，每一步我所走的路，都是为了你。"
            show tom smile -blush
            show side_p sdh at pic
            mc "这..."
            show side_p g 
            mc "（如果这是一篇Wuttpad同人小说，我会说这很浪漫，但为了一个人做出所有的决定...）"
            show side_p k
            mc "你对我着了魔。"
            hide side_p
            tom pfft -blush blow "你现在才注意到吗？"
            show tom -blow 
            scene booth with dissolve
            play sound "sound/effects/crowd.mp3"
            "你还没来得及继续说，一阵热烈的掌声突然打断了你。"
            $ tom_events.append("obsessed")

        "我不是...":
            hide pboy
            scene booth with dissolve
            show tom go frown at center with dissolve:
                yoffset 190 
            show side_p sdh at pic
            mc "阿什姆，有件事你应该知道，我不是——"
            hide side_p
            scene booth with dissolve
            "你想坦白你的身份。你不是他的[povname]，他应该知道这一点。"
            scene booth with dissolve
            play sound "sound/effects/crowd.mp3"
            "但在你能继续说下去之前，一阵热烈的掌声突然打断了你。"
            $ tom_events.append("come_clean")
    
    play sound "sound/effects/crowd.mp3"
    scene tamu with dissolve
    show red bebas hister blush at left with dissolve:
        yoffset 330
    show quil libur laugh blush at right with dissolve:
        yoffset 200
    "你看着塞恩和奎尔对着巫师大声欢呼。"
    red bloom "我爱你！！！"
    quil hister bloom "我爱你，梅扎！"
    scene booth with dissolve
    show tom go kzl sweat at center with dissolve:
        yoffset 190
    tom "我们得在他们完全失去理智之前把那两个人带出去。"
    show side_p k at pic
    mc "好的。"
    hide side_p
    stop music fadeout 1.0
    scene tamu with dissolve
    play sound "sound/effects/tile.mp3"
    show mey smile at center with dissolve:
        yoffset 100
    "当你和阿什姆朝塞恩和奎尔跑去时，另一个高大的身影向他们靠近。"
    "显然梅扎看到你和阿什姆的表现与其他客人不同，决定提前结束她的表演。"
    mey talk "年轻的英克威尔继承人，享受这场表演吗？"
    play music "MUSIC/MusMus-BGM-101.mp3"
    show mey smile
    show red bebas wry blush at left behind mey with dissolve :
        yoffset 330
    show quil libur laugh blush at right with dissolve:
        yoffset 200
    quil mock bunga "当然，我会...我会再来的。你能再唱一遍吗，拜托？拜托？"
    show quil hister -bunga
    "奎尔的声音颤抖着，似乎陷入了无助的恍惚状态，被梅扎的存在迷住了。"
    mey talk "啊哈哈！抱歉，恐怕今晚我只唱一首歌。"
    mey smile cling "不过，我偶尔会为我们最忠实的顾客表演特别节目。"
    show red kaget shock
    show quil talk shock
    mey spark "我相信我们的酒保能为你展示我们更豪华的饮品——"
    quil hister bloom "我马上回来！"
    red ow frusta sweat"奎尔，等等，让我也给她点点东西！"
    scene tamu with dissolve
    "看到奎尔反常的行为，巫师似乎放松了一些，她的手稍微松开了面具。"
    show mey smile at left with dissolve:
        yoffset 100
    show tom go frown at right with dissolve:
        yoffset 190
    "然后她转向你，面具对着你。"
    mey talk "我一直想和你们两个谈谈。看起来，你们俩都没有享受这场表演。"
    show tom calm 
    show mey smile
    "阿什姆露出了他标志性的假笑。"
    tom wry spark "我向您保证，夫人，您的表演非常精彩。如果我们的表情没有反映出来，我们深表歉意。"
    show tom smile -spark
    mey talk "哈哈哈，虽然我很感谢你的恭维，但我很确定你的注意力在别处。"
    if girl:
        show look2_feme with dissolve    
    else:
        show look2 with dissolve
    mc "（没错。不像塞恩和奎尔整首歌都被梅扎迷住了，阿什姆一直深情地盯着我看。）"
    if girl:
        hide look2_feme with dissolve    
    else:
        hide look2 with dissolve
    mey talk "我承认你们的反应让我很感兴趣。我从未失去过观众的注意力。"
    mey crazy "如果你允许的话，我想为你们做一场特别的表演。一场只能在贵宾室进行的表演。"
    mey smile "算是为我上一场表演做补偿。我可不想让客人不满意地离开。"
    tom frown "..."
    "阿什姆看着我，似乎在寻求我的同意。我点了点头，因为我想看看梅扎的俱乐部到底是怎么回事。"
    show side_p mal at pic
    mc "我会和你一起去。"
    hide side_p
    mey frown "啊，抱歉[povname]，我的邀请只针对你这位可爱的朋友。"
    mey "我为你准备了别的东西。"
    "莱利向你招手，等待你接受她的邀请。"
    mey talk "你可能得等到我和阿什姆的事情结束，但别担心，我会确保你玩得开心的。"
    "你挑了挑眉毛看着阿什姆，问他是否同意。"
    "幸运的是，他似乎和你一样好奇，朝你点了点头，让你配合演出。"
    tom wry "[povname]，我没问题的。让一位女士等待是不礼貌的。"
    show tom calm
    show side_p fr at pic
    mc "好吧。带路吧，莱利。"
    scene tamu with dissolve
    show waiter laugh at center with dissolve:
        yoffset 200
    npw "请跟我来！" 
    scene mey_vip with dissolve
    play sound "sound/effects/door.mp3"
    show waiter at center with dissolve:
        yoffset 200
    "女侍者带你来到靠近主入口的一个更隐蔽的房间。空气中弥漫着淡淡的茉莉花香。"
    npw laugh apa "在等待的时候需要喝点什么吗？"
    show waiter -apa
    show side_p fr at pic
    mc "不用了，谢谢。"
    show side_p g
    mc "（我必须保持警惕。）"
    hide side_p
    npw smile "你确定吗？我们有很多美味的鸡尾酒。也许我可以给你看看菜单？"
    show side_p k at pic
    mc "（女士，我真的在尽最大努力不掉队啊！）"
    show side_p h
    mc "不用了，我..."
    hide side_p
    npw laugh "你绝对确定吗？"
    show pboy s at horzappear
    menu:
        "我看看。":
            hide pboy
            "看着她的手，你注意到她的手指在颤抖。"
            "她的声音和表情没有变化。依然是之前那个乐观的女服务员，但她的肢体语言..."
            show side_p fr at pic
            mc "当然。让我看看你有什么。"
            hide side_p
            show waiter pout shock
            "女孩急忙拿出一张菜单卡，塞到你的腿上。"
            npw laugh -shock "今晚我们的特色是\'月光约会\'。我们还有品尝拼盘。"
            show menuw with dissolve
            "她偷偷塞给你一张纸条，你这才明白她的坚持。"
            scene mey_vip with dissolve
            show waiter at center with dissolve:
                yoffset 200
            npw laugh "你想要哪一个？"
            show waiter smile
            "你装作若无其事地从女孩手中接过纸条。当你把纸条放进后口袋时，她似乎平静下来了。"
            show side_p ha at pic
            mc "\'月光约会\'听起来不错。"
            hide side_p
            npw laugh "太棒了，我马上回来！"
            hide waiter with dissolve
            play sound "sound/effects/doorslam.mp3"
            "莱利匆忙离开了房间。"
            $ my_events.append("help_me")


        "好的！":
            hide pboy
            npw pout "...好吧。"
            hide waiter with dissolve
            "女服务员带着沮丧的表情离开了。"
            show side_p k at pic
            mc "真是个爱推销的服务员。"
            hide side_p
            if "help_me" in my_events:
                $ my_events.remove("help_me")
    stop music
    play sound "sound/effects/door.mp3"
    show mey smile at center with dissolve:
        yoffset 100
    "你本想四处看看，但就在你离开座位时，梅扎进入了房间。"
    show side_p sdh at pic
    mc "（她知道我想偷偷溜走吗？）"
    hide side_p
    play sound "sound/effects/cloth.mp3"
    "你重新坐下，担心这个女人会对你的行为发表评论。"
    play music "MUSIC/MusMus-BGM-025.mp3"
    mey talk "惊讶吗？我想我应该先来打个招呼。"
    "她直接坐在你身边，轻轻握住你的手，就像见到老朋友一样。"
    mey crazy "啊，小贝克继承人，我们又见面了。"
    show pboy s at horzappear
    menu:
        "顺着她的话说":
            hide pboy
            show side_p mal at pic
            mc "好久不见了，是吧？"
            hide side_p
            mey talk "你长大了，小\'德拉克马屠龙者\'。"

        "如实回应":
            hide pboy
            show side_p fr at pic
            mc "我们以前见过吗？"
            hide side_p
            mey talk "哦，别装傻了，[povname]。"
            mey smile"哎呀，你长得真高啊，小\'德拉克马屠龙者\'。"
    mey talk "这么多年过去了，人们还这么叫你吗？"
    mey crazy "哦，要是他们知道真相就好了。我的小恶魔。"
    show side_p h at pic
    mc "什么真相？"
    hide side_p
    mey "究竟是什么真相呢。"
    "她是不是把我的困惑误解成了友好的玩笑？这两个人到底有多亲密？"
    mey fear "另外，我为邀请你父亲来感到抱歉。我知道我不应该联系他，但我忍不住。"
    mey frown "你一次又一次地无视我的邀请函。我都快绝望了。"
    mey smile "我太高兴你终于来满足我的愿望了。我一直对你很着迷。你和那个阿什姆男孩。"
    mey crazy "看到他那样贪婪地盯着你，真是令人陶醉。就好像他想把你整个吞下去一样。"
    mey talk "我几乎嫉妒他对你如此强烈的渴望。但我想这一直是你的计划吧。"
    mey smile "让一个男人完全屈服于你的意志，让他忠诚且只想要你。"
    mey "你把他培养得很好。"
    show pboy s at horzappear
    menu:
        "我没有培养任何人。":
            hide pboy
            show side_p h at pic
            mc "你说的培养是什么意思？我们是同龄人。"
            hide side_p
            mey scowl "嗯？是的，我想\'培养\'这个词听起来确实有点令人不快，不是吗？那你更喜欢\'训练\'这个词吗？"
            mey talk "无论如何，你不需要在我面前装无辜。"
        "什么计划？":
            hide pboy
            show side_p sdh at pic
            mc "什么计划？我不知道你在说什么。"
            hide side_p
            mey talk "啊哈哈，哦[povname]。你不需要在我面前装傻。"
    mey crazy cling "我很久很久以前就知道你那扭曲黑暗的内心了。"
    stop music
    play sound "sound/effects/summon.mp3"
    scene bg_black with wet
    
    "黑烟从梅扎的指尖冒出，形成了一面黑色的镜子，看起来像是一个电视屏幕。"
    play sound "sound/effects/summon.mp3"
    scene gerla with wet
    "在镜面上，你可以看到似乎是一个豪华的家，还有一张你很久没见过的面孔。"
    if girl:
        show kidf at center with dissolve
    else:
        show kid at center with dissolve
    "毫无疑问，你眼前看到的是……另一个你。只不过年轻得多，非常年轻。"
    "从你仍然抱着那个忠实的噩梦伙伴来判断，你猜这段记忆至少是十年前的事了。"
    
    if girl:
        $ mk = Character('[povname]', callback=name_callback, cb_name='mk', image='kidf')
    else:
        $ mk = Character('[povname]', callback=name_callback, cb_name='mk', image='kid')
    show side_p g at pic
    
    mc "那是……我吗？"
    hide side_p
    mey "那是我们相遇的那天。啊……我记得就像昨天发生的一样。"
    play music "MUSIC/MusMus-BGM-112.mp3"
    if girl:
        show kidf at right with move
    else:
        show kid at right with move
    show mey talk at left with dissolve:
        yoffset 100
    mey "小家伙，你不该在床上吗？"
    if girl:
        $ mk = Character('[povname]', callback=name_callback, cb_name='mc', image='kidf')
    else:
        $ mk = Character('[povname]', callback=name_callback, cb_name='mc', image='kid')
    mk tanya "你是个巫师。你在沙罗姆庄园里做什么？"
    mey smile "我在这里工作。格拉·沙罗姆夫人遇到了麻烦，而我是唯一能帮她摆脱困境的人。"
    mey talk "当然，是有代价的。互惠互利。"
    mey smile "那你呢，小贝克？"
    mk frusta "提莫西邀请我来过夜。他没告诉我他会打呼噜。"
    mey talk "啊，提莫西，格拉那群不听话的孩子中最小的一个。你们两个关系很好吗？"
    mk talk sigh "我讨厌他。他不过是个含着金汤匙出生的被宠坏的小鬼。"
    if girl:
        show kidf pout -sigh
    else:
        show kid pout -sigh
    mey frown "是这样吗？"
    mk talk frusta "你知道他进入了维鲁德学院吗？这太不公平了！他们接受他只是因为他是贵族。如果不是因为他，我就能……哼。"
    if girl:
        show kidf pout
    else:
        show kid pout
    mey talk "确实该哼。你知道吗，你是个很奇怪的孩子？在一个巫师面前抱怨你幼稚的学业竞争。"
    mey smile "你不怕我把你吃掉吗？"
    mey crazy cling "大多数孩子都会拼命逃跑的。"
    mk sigh "我和\'大多数孩子\'不一样。"
    mk talk tanya "……你说你在做互惠互利的事情？那我能请求一个吗？"
    mey frown -cling "哦？"
    stop music
    mk smile cling "你能……帮我杀了提莫西吗？"
    show side_p k at pic
    mc "（什么……？）"
    hide side_p
    play music "MUSIC/PerituneMaterial_Piano_Sad2.mp3"
    mk talk sigh "不要无聊快速的死法，要慢慢折磨他。"
    mk pout -sigh "溺死怎么样？我听说那是最痛苦的死法之一，对吧？"
    mey talk "哎呀，事态升级得真快。这么小的孩子提出这么大的请求。那我为此付出的代价能得到什么呢，嗯？"
    show mey smile
    mk talk tanya "我的灵魂？你们巫师喜欢这个，不是吗？"
    if girl:
        show kidf pout -tanya
    else:
        show kid pout -tanya
    mey crazy "哈哈哈哈！我们不是恶魔，小贝克继承人。除了一些轻微的娱乐，我对灵魂没什么用处。"
    show mey smile
    mk smile "那么，关注度怎么样？你喜欢那个，不是吗？"
    mey frown "哦？"
    mk pout sigh"如果你想隐藏，就不会那样穿衣服。"
    mey smile"哪样穿衣服？"
    mk smile cling "像个关注婊。妈妈喜欢这么称呼那些贵族。你穿得像他们。"
    mk talk sigh "就像那些在妈妈自己的派对上试图抢风头的俗气女士们。"
    mk smile shock "哦，我知道了！我们何不把他的死变成一场表演呢？"
    mk -shock "格拉夫人下周会在这里举办派对。你可以躲在花园的喷泉里。我会把孩子们引到那里，然后你就抓住我和其他人。"
    mk pout "我会挣扎并救下几个孩子，然后你给我一个选择，让我在救这个男孩或那个男孩之间做决定，然后我会让提莫西死掉。"
    mk smile "我会被宣布为英雄，证明应该进入维鲁德的人是我，而不是他！"
    mk "更不用说，格拉夫人会因为让一个巫师在她的庄园里游荡而责备自己。"
    mk "她会悲伤欲绝，内疚不已，同时你展示的力量会成为所有客人谈论的话题。"
    mk tanya "这不是很有趣吗？人们会惊叹于你的力量？看着那个愚蠢的婊子在绝望中崩溃？"
    if girl:
        show kidf pout -tanya
    else:
        show kid pout -tanya
    mey scowl frusta "……你知道吗，你那句\'关注婊\'的评论很无礼。"
    mey smile sigh "无礼……但一针见血，而且我确实喜欢一场好戏。"
    mey frown cling "不过我得稍微伪装一下，因为我不能让伟大的贪婪巫师被一个小孩打败。"
    mey talk -cling "也许扮演德拉克玛巫师吧，我已经很久没有戴上她的面具了。"
    show mey smile
    mk talk sigh "只要能完成就行，你想怎么做都可以。哦，还有一件事。"
    mey scowl sigh "还有更多？我的天，你真是个贪心的孩子。"
    mk -sigh "我保证不会给你添麻烦的。"
    mey frown -sigh "好吧，那就说出来吧。"
    mk smile "我要留下的孩子，我希望是尼弗斯家族的男孩，阿什姆·尼弗斯。他是半精灵，有紫色的眼睛，你不会认错的。"
    mey smile "你选择他有什么特别的原因吗？"
    mk pout "他母亲是嫁入这个家族的。在贵族眼里，他就像我一样是个无名小卒。但除此之外，他聪明、强壮、勤奋。"
    mk "他有点态度问题，但有了正确的引导，他可以成就伟业。"
    mk smile "我想要他的忠诚，他的生命，他的未来。一个只会想着我和我需求的盲目仆人。"
    mey crazy cling "你想拥有他。"
    play sound "sound/effects/gigle.mp3"
    mk snicker "而他会让我这么做的。"
    show mey smile -cling
    scene bg_black with wet
    play sound "sound/effects/summon.mp3"
    scene mey_vip with dissolve
    "烟雾散去，你咬紧牙关，尽力不让自己的厌恶显露出来。"
    show side_p sdh at pic
    mc "（那是什么？就像一个恶魔在说话。一个戴着我面具的恶魔。）"
    hide side_p
    show mey smile at center with dissolve:
        yoffset 190
    mey crazy bloom "我想我从未感谢过你那场表演。从那以后，我发现我爱的是戏剧，而不是金钱。"
    mey talk "你是我这个小天堂的灵感来源。一个富人来此赴死的地方。"
    mey smile "愚蠢的人类，为了在生活中出人头地而互相诅咒，甚至没有勇气为此负责。"
    mey crazy "一旦我或我的客户选中了受害者，他们就会一直来这里，直到他们再无可给。"
    mey talk "直到他们变成骨头，放弃吃饭和睡觉，只为了有机会再听我唱一次歌。"
    mey smile "今晚我克制住了自己，担心你会受到我歌声的影响，但你甚至没有动摇。"
    mey "你没有，那个被你迷惑得全心全意爱上你的男人也没有。"
    mey crazy "我真的不相信巫师是由恶魔诞生的说法，但如果我们是...你肯定是伪装的魔鬼，[povname]。"
    show mey smile -bloom
    "梅扎期待地看着你，似乎在等待你的认可。"
    show pboy s at horzappear
    menu:
        "抚摸她的头发":
            hide pboy
            mey crazy bunga"啊啊啊..."
            "她发出纯粹幸福的叹息。我不知道她在\"我\"身上看到了什么？"
        "装作无知":
            hide pboy
            if "sus_mey" not in my_events:
                $ my_events.append("sus_mey")
            mey fear shock "哦，那太冒昧了吗？对不起。"
            mey talk bunga "你对我来说太迷人了，[povname]。我的小恶魔。"
            if "nick" not in topics:
                $ topics.append("nick")
    mey smile -bunga "我现在必须走了。别担心，我只是想检查一下你劳动的成果。看看他对你的贪婪有多深。"
    mey talk "再来看我吧，[povname]。你随时都可以来这里，免费的。"
    show side_p fr at pic
    mc "...谢谢。哦对了，梅扎？"
    hide side_p
    mey smile apa "嗯？"
    show side_p g at pic
    mc "（如果我请求保护阿什姆或者塞恩和奎尔的安全会不会显得可疑？\'[povname]\'会说什么呢？）"
    hide side_p
    show pboy s at horzappear
    menu:
        "保护奎尔和塞恩":
            hide pboy
            show side_p k at pic
            mc "别碰奎尔或塞恩。"
            hide side_p
            mey frown -apa"...当然。"
            scene mey_vip with dissolve
            play sound "sound/effects/doorslam.mp3"
            "她的笑容消失了，语气也变了。她离开房间时，用力关上了门。"
            show side_p g at pic
            mc "我有点得寸进尺了。"
            hide side_p
            if "sus_mey" not in my_events:
                $ my_events.append("sus_mey")
            "说完，我赶紧去找奎尔和塞恩，担心最坏的情况发生。"


        "保护阿什姆":
            hide pboy
            show side_p k at pic
            mc "阿什姆是我的，由我来摧毁。"
            show side_p g
            mc "（这听起来太做作和尴尬了，但应该管用吧？希望听起来像是[povname]会说的话。）"
            hide side_p
            mey crazy -apa "啊哈哈哈，当然！当然！"
            scene mey_vip with dissolve
            play sound "sound/effects/doorslam.mp3"
            if "sus_mey" in my_events:
                $ my_events.remove("sus_mey")
            "说完，她离开了房间，留下你一个人。"
            if "help_me" in my_events:
                "你没有等待饮料，急忙离开房间去寻找塞恩和奎尔。"
            else:
                "你没有等太久就离开房间去寻找你的朋友们。"
    stop music
    play sound "sound/effects/walk.mp3"
    play music "MUSIC/MusMus-BGM-059.mp3"
    jump bar_explore

label meyza_fight:
    scene alley_empty with w20
    play sound "sound/effects/walk.mp3"
    "当你进入梅扎的俱乐部时，你立即感觉到有些不对劲。"
    "没有一个服务员来迎接你，周围也没有任何客人。"
    show quil libur kzl at right with dissolve:
        yoffset 200
    quil err sweat frusta "这不对劲。"
    show quil sulk
    show red bebas frown at left with dissolve:
        yoffset 330
    red huh sweat"我们应该——"
    play sound "sound/effects/slashkut.wav"
    play music "MUSIC/wrath.mp3"
    scene thane_quill_stab with vpunch
    galleryunlock thane_quill_stab
    red "啊啊啊！！！"
    quil "呃啊！"
    mc "塞恩！"
    tom "奎尔！"
    "黑色的锁链凭空出现，刺穿了奎尔和塞恩，然后将他们拖入未知的黑暗深渊，"
    "彻底消失了。"
    scene map_bar with dissolve
    play sound "sound/effects/woosh.mp3"
    "你还没来得及反应，烟雾就将你拉到了舞台中央。"
    show mey smile at center with dissolve:
        yoffset 100
    "在那里，你看到梅扎和她的手下围绕着舞台。"
    if "help_me" in my_events:
        show mey at left with move
        show waiter pout at right with dissolve:
            yoffset 200
        "手下中有莱利，她的手腕和脚踝都被同样的黑色涌动的烟雾捆绑着。"
        show side_p k at pic
        mc "莱利！"
        hide side_p
        mey crazy "啊，[povname]，没有跟我打招呼吗？"
        play sound "sound/effects/punch.mp3"
        hide waiter with vpunch
        "梅扎狠狠地打了莱利一拳，把她打晕了过去，黑烟像一个临时的尸袋一样包裹着她的身体。"
        play sound "sound/effects/cloth.mp3"
        "你可以看到她在里面扭动，拼命地喘息。"
        show mey talk at center with move
        if "sus_mey" not in my_events:
            mey "我知道我没有按你的要求保护你的其他朋友，但你真的要这样惩罚我吗？"
            show mey smile
            "她嘲讽的语气在房间里回荡，她的嘴里吐出的无不是毒液。"
            "她很生气，非常生气。"
        else:
            mey crazy "不过话说回来，我想你现在已经不是我认识的那个[povname]了，对吧？"
            mey pissed frusta"我的小恶魔绝不会这样背叛我！"
            show mey frown -frusta
        mey pissed "用我自己的手下来算计我？你怎么敢，[povname]！"
        jump mey_help_efek
    else:
        if "sus_mey" not in my_events:
            mey crazy "我没想到你会出现。上次你表现得那么奇怪，[povname]。"
            mey talk "但也许我的担心是多余的。"
        else:
            mey talk "[povname]亲爱的，很高兴见到你。"
        show side_p g at pic
        mc "梅扎，这是怎么回事？你对奎尔和塞恩做了什么？"
        hide side_p
        mey crazy "别担心，我只是把他们放进了我的影子里。"
        mey talk "我觉得我们三个人最好不要有任何窥探的眼睛和耳朵来谈谈。"
        mey smile "我本想也对付阿什姆，但我记得你在我们上次见面时对我的要求。"
        mey crazy apa "我做得不错吧？"
        show mey smile -apa at left with move
        show tom go ha at right with moveinright:
            yoffset 190
        tom apa "见面？这是怎么回事？你想要什么？"
        show tom kzl -apa
        mey talk -apa"我不想从你那里得到什么，但我想从[povname]那里得到一切。你看，我有个提议要给你，[povname]。"
        show side_p k at pic
        mc "一个提议？"
        hide side_p
        mey crazy "成为我的人，与我灵魂相连。永远合二为一，直到时间的尽头。"
        show tom ew sweat shock
        show side_p k at pic
        mc "对不起，你说什么？"
        hide side_p
        show tom kzl -shock
        mey talk bunga "我知道这很突然，但当我再次见到你时，[povname]，我就再也无法抑制我的感情了。"
        mey crazy "我想要你。你的全部。你将成为这个完全堕落之地的黄金中心。"
        show mey pissed shock
        tom ew -sweat frusta "[kamu]不可能同意的。"
        show tom kzl -frusta
        mey talk -shock "也许吧，但即使你拒绝，我相信我也能说服你。"
        mey crazy apa "问你只是我的礼貌。把它当作一种courtesy吧。你更愿意我像[povname]对你做的那样对你吗，阿什姆？"
        show mey smile
        tom sad apa "什么？"
        show tom ha -apa
        show side_p k at pic
        mc "等等，梅扎，不要！"
        show side_p sdh
        mc "（他应该从我这里听到真相！）"
        show side_p k
        mc "嗯嗯！"
        hide side_p
        "几秒钟内，你感觉到你的嘴唇变紧了，互相拉扯着。"
        "低头看了看并摸了摸你的脸后，你发现你的嘴唇甚至不见了，取而代之的是一个光滑的表面。"
        "她用魔法把它变没了吗？！"
        mey crazy apa "你不好奇[povname]在德拉克马尔女巫攻击你那天是如何准备充分的吗？"
        mey -apa "你有没有想过为什么那个巫师没有留下灰烬残骸？"
        show mey smile
        tom whine sweat "是...喷泉的水把它冲走了！"
        show tom kzl
        mey talk bunga "是的，大多数人都会这么认为。再一次，这个小恶魔想到了另一个精妙的细节。"
        if girl2:
            mey smile "赞美[povname]，真的没有人能比得上[dia]。"
        else:    
            mey smile "赞美[povname]，真的没有人能比得上[dia2]。"
        tom sad "不...那...那不可能！"
        mey crazy cling "如果是[povname]告诉你的，你会相信吗？"
        show mey smile -cling
        show side_p k at pic
        mc "呜啊！"
        hide side_p
        "你感觉到你的嘴又能张开了，你反复咂嘴，只是为了确保它们还在那里。"
        tom whine apa "...[povname]，这是真的吗？"
        show tom sad -apa
        show side_p sdh at pic
        mc "...我很抱歉，阿什姆。"
        show tom sad shock
        hide side_p
        tom nyesal frusta "那...我不能...什么？"
        show tom sad -sweat -frusta
        mey crazy bunga"看到了吗[povname]？如果我是他，我就不会像那样结结巴巴的。"
        mey smile "我会很高兴你计划得如此周到，为了让我留在你的生活中。"
        show mey -bunga
        show side_p k at pic
        mc "你疯了。"
        hide side_p
        mey crazy "也许吧。但你也是。别否认。"
        mey "我们注定要在一起，[povname]。你是因为阿什姆而犹豫吗？因为我可以为你解决这个问题。"
        mey smile cling "阿什姆...你爱我，对吧？"
        play sound "sound/effects/shield.mp3"
        show map_bar behind tom with dissolve:
            subpixel True
            zoom 1.2 xpos 0.5 ypos 0.5 xanchor 0.5 yanchor 0.5 
            alignaround (.45, .45)
            linear 20 yalign 0.45 xalign 0.45 clockwise circles 1.2
            #repeat
        show tom kzl shock
        show side_p k at pic
        mc "呃！"
        show tom sad -shock
        hide side_p
        show side_p g at pic
        mc "（这种感觉...强制。这和菲亚使用的催眠声音一样，只是强大得多...多得多！）"
        mc "（她在对阿什姆使用吗？）"
        if "antidote" not in tom_events:
            show side_p k
            mc "（糟糕，我没有给阿什姆那种药水，他现在会屈服于她的声音吗？！）"
        else:
            show side_p k
            mc "（他应该能够抵抗住，对吧？他确实喝了佩纳给我们的那种难喝的药水。）"
        hide side_p
        show map_bar behind tom with dissolve:
            subpixel True
            truecenter zoom 1.0
            xalign 0.0 yalign 0.0
        tom frown"..."
        tom giggle blush "没错，梅扎，我爱你胜过一切。"
        show tom pfft
        show side_p k at pic
        mc "（该死！）"
        show side_p sdh
        mc "等等，阿什姆——"
        hide side_p
        mey crazy apa "比[povname]还要爱吗？"
        show mey smile -apa
        tom whine -blush apa "...[povname]是谁？"
        show tom ha -apa
        show side_p k at pic
        mc "（糟糕，他真的失去理智了！）"
        hide side_p
        mey crazy cling "如果是这样的话，那么你会...为我而死吗？"
        show side_p k at pic
        mc "死？！梅扎，你在做什么？"
        hide side_p
        mey scowl frusta "对不起，我知道你说过不要碰他，但我忍不住。"
        mey pissed -frusta "他真碍眼。如果你不能接受一个人的黑暗面，又怎么能说爱他呢？"
        mey crazy cling "[povname]，我比他好多了！"
        show mey -cling
        "梅扎紧紧抓住你的手，将它贴在她的胸前。她抬头看着你，期待地等待你的回答。"
        show pboy s at horzappear
        menu:
            "你说得对。（顺着她说）":
                hide pboy
                show tom smile blush 
                show side_p mal at pic 
                mc "你说得对，梅扎。我很抱歉花了这么长时间才注意到你。"
                hide side_p
                mey crazy bloom "哦[povname]，我就知道你会理解的。"
                show side_p ha at pic
                mc "是的...我非常清楚地理解了..."
                hide side_p
                play sound "sound/effects/api.mp3"
                galleryunlock fire_mey2
                scene fire_mey2 with flashbulb
                mey "啊啊啊啊啊！"
                "你轻轻一挥手，火焰就将梅扎包围在一个炽热的拥抱中。"
                "然而，你的胜利是短暂的，因为火焰很快就消散了。"
                play sound "sound/effects/shield.mp3"
                if girl:
                    galleryunlock thorns_f
                    scene thorns_f with fade:
                        subpixel True
                        truecenter zoom 2.0
                        easein 1.0 truecenter zoom 1.0

                else:
                    galleryunlock thorns_m
                    scene thorns_m with fade:
                        subpixel True
                        truecenter zoom 2.0
                        easein 1.0 truecenter zoom 1.0
                "黑色的阴影吞噬了火焰，梅扎向你施放了她的魔法。"
                mey "[povname]！"
                mey "你怎么敢这样欺骗我！！！"
                mc "呃！"
                "当你的背重重地撞在房间后面时，数十根黑色尖刺在你周围形成，将你困在原地。"
                scene bar_mess with dissolve
                show mey pissed at center with dissolve:
                    yoffset 100
                "梅扎怒气冲冲地向你走来。显然，你还没有死只是因为她对你还有其他计划。"
                mey "你怎么能这样？我爱你！我把我的灵魂献给了你！"
                mey scowl "我希望你能自愿来到我身边，但如果这要求太高的话..."
                mey "...那我很乐意撕下你的四肢，强行把你带走！"
                mey crazy "也许塞斯可以来——"
                stop music
                play sound "sound/effects/sword.mp3"
                galleryunlock clean_cut
                scene clean_cut with flashbulb:
                    truecenter zoom 1.0
                    easeout 2.0 truecenter zoom 0.5
                tom "你话太多了。"
                mey "你——"
                mey "怎么..."
                "阿什姆的冰剑一刀干净利落，梅扎的头颅飞了出去。"
                scene ded_base with dissolve
                play sound "sound/effects/crumble.mp3"
                "她的身体剩余部分轰然倒地。"
                "她的身体没有流血，反而开始变成似乎是纯金的固体，像破碎的雕像一样裂开。"
                play sound "sound/effects/jantung.mp3"
                show ded_gem with dissolve:
                    ypos 72
                    linear 1.0 ypos 0
                pause 1.0
                show ded_top with dissolve
                "一颗蓝色宝石从她胸口的裂缝中升起。"
                show side_p g at pic
                mc "（那是...她的心脏吗？）"
                hide side_p
                scene ded_base with dissolve
                stop sound
                "你几乎没有多想，就抓住了那块石头，将它抱在怀里，然后安全地放进了口袋。"
                "幸运的是，地板上的尖锐黑刺随着梅扎的死亡一起消散了，让你可以自由活动。"
                
                
            "让阿什姆清醒过来":
                hide pboy
                scene bar_mess with dissolve
                if girl:
                    galleryunlock arkis_f
                    show arkis_f with flashbulb
                else:
                    galleryunlock arkis
                    show arkis1 at left with moveinleft
                play sound "sound/effects/cloth.mp3"
                "你挣脱了梅扎的控制，双手捧住阿什姆冰冷的脸颊。"
                if not girl:
                    show arkis2 at right with moveintop:
                        yalign 0.0
                show side_p sdh at pic
                mc "阿什姆，回到我身边来。"
                hide side_p
                "你不假思索地在阿什姆的嘴唇上狠狠地吻了一下。当你把舌头伸进去时，他的眼睛睁得大大的。"
                if not girl:
                    show arkis3 at right with moveinbottom:
                        yalign 1.0
                "震惊并没有持续多久，他推开了你，用手背擦了擦嘴唇。"
                play sound "sound/effects/cloth.mp3"
                scene bar_mess with dissolve
                show mey pissed at left with dissolve:
                    yoffset 100
                show tom go ha at right with dissolve:
                    yoffset 190
                tom ha frusta"...你...你是谁？"
                show tom kzl -frusta
                show side_p g at pic
                mc "不..."
                hide side_p
                mey crazy "啊哈！啊哈哈哈~！"
                mey talk "看到了吗[povname]，他不爱你。但我爱你，没有任何咒语能让我忘记你！"
                mey crazy "来吧阿什姆，自杀吧！如果需要的话，用我的刀。"
                "一把黑色、带刺的阴影之刃在梅扎手中形成。她把它递给阿什姆，显然希望他能快点动手。"
                tom lega "如你所愿。"
                scene bg_black with eye_shut
                "你闭上了眼睛，不忍心看到那个年轻人的死亡。你等待着血液溅到你的脸上。"
                "然而，血滴并没有来。相反，你听到身后传来一声响亮的惨叫。"
                "直接从梅扎的嘴里发出。"
                stop music 
                play sound "sound/effects/sword.mp3"
                galleryunlock clean_cut
                scene clean_cut with eye_open:
                    truecenter zoom 1.0
                    easeout 2.0 truecenter zoom 0.5
                mey "...怎么...你—"
                "一刀干净利落，梅扎的头颅飞了出去。"
                scene ded_base with dissolve
                play sound "sound/effects/crumble.mp3"
                "她的身体剩余部分轰然倒地。"
                "她的身体没有流血，反而开始变成似乎是纯金的固体，像破碎的雕像一样裂开。"
                play sound "sound/effects/jantung.mp3"
                show ded_gem with dissolve:
                    ypos 72
                    linear 1.0 ypos 0
                pause 1.0
                show ded_top with dissolve
                "一颗蓝色宝石从她胸口的裂缝中升起。"
                show side_p g at pic
                mc "（那是...她的心脏吗？）"
                stop sound
                "你几乎没有多想，就抓住了那块石头，紧紧抱在怀里，然后塞进了口袋。"
                hide side_p
        scene bar_mess with dissolve
        galleryunlock ded
        show tom go kzl at center with dissolve:
            yoffset 190
        "如果你的行为有什么奇怪之处，阿什姆并没有说什么。他仍然盯着梅扎在地板上滚动的头颅。"
        show tom sigh blow
        "几分钟过去了，阿什姆才深深地叹了口气，转身终于面对你。"
        show tom frown -blow
        "这几乎比面对梅扎本人更让人紧张。"
        tom whine "我们应该去看看奎尔和塞恩。看看他们是否回到休息室了。"
        "没料到他如此冷漠，你抓住了他的手腕。"
        show tom ha shock
        show side_p g at pic
        mc "等等，你不想知道真相吗？还有...还有关于\'我\'的更多事情你需要知道。"
        hide side_p
        tom sad frusta "我知道。但在那之前，我们需要救奎尔和塞恩。我—"
        show tom sweat kzl shock
        play sound "sound/effects/cough.wav"
        red "*咳嗽*...*咳嗽*...救...救命！*"
        scene bar_mess with dissolve
        play sound "sound/effects/tile.mp3"
        "听到塞恩虚弱的声音，你和阿什姆立即朝休息室跑去，一刻也不敢耽搁。"
        jump red_dying

label mey_help_efek:
    mey crazy "你和其他人一样。你们这种人的自以为是没有止境！"
    scene bar_mess with flashbulb
    play sound "sound/effects/bomb.wav"
    queue sound "sound/effects/shield.mp3"
    "梅扎一个接一个地施展法术，将你和阿什姆逼到了角落。"
    "阿什姆试图反击一两次，但他的法术像什么都不是一样被梅扎弹开了。"
    scene bar_mess with vpunch
    play sound "sound/effects/api.mp3"
    "即使是他的凤凰之焰也无法触及她，她像拍苍蝇一样轻易地将其拍开。"
    galleryunlock grab
    scene grab with fade:
        subpixel True
        truecenter zoom 1.0
        easein 1.0 truecenter zoom .5
    mey "真是无礼！"
    "梅扎很快就报复了。"
    "一只巨大的手在阿什姆身后形成。它缠绕着他的身体，将他带入了深邃的黑暗深渊。"
    scene bar_mess with vpunch
    play sound "sound/effects/kunyah.mp3"
    show side_p k at pic
    mc "阿什姆，啊—！"
    play sound "sound/effects/cloth.mp3"
    hide side_p
    if girl:
        scene choke_cut_ditric with dissolve
        galleryunlock choke_cut_ditric
    else:
        scene choke_cut_ditricj with dissolve
        galleryunlock choke_cut_ditricj
    "你还没来得及反应，梅扎已经掐住了你的脖子。"
    "她单手将你举起，仿佛你是一个没有重量的玩偶。"
    mey "我不喜欢叛徒，[povname]。你真的以为小莱利的计划会奏效吗？"
    mey "那个牧师根本不是我的对手。"
    show side_p g at pic
    mc "（该死，她抓到迪特里希了吗？！）"
    hide side_p
    mey "你很快就会和你的朋友们团聚。但首先，让我先好好玩弄你一会儿。"
    mey "我很好奇在我彻底击垮你之前，你能承受多少我的魔法。"
    show pboy s at horzappear
    menu icebay:
        "反击":
            hide pboy
            play sound "sound/effects/punch.mp3"
            queue sound "sound/effects/glass.wav"
            queue sound "sound/effects/shield.mp3"
            "你踢她，甚至试图向她施法，但她只是对你微弱的尝试轻蔑地笑了笑。"
            "你的法术毫无效果，你的踢打也是如此。一道屏障似乎形成在她周围，轻易地挡开了这些攻击。"
            scene bar_mess with dissolve
            show mey crazy at center with dissolve:
                yoffset 100
            mey cling "啊哈哈哈。真是活力四射啊。留着点力气吧，亲爱的。我一直喜欢精力充沛的床伴。"
            stop music
            play sound "sound/effects/sword.mp3"
            galleryunlock diet_cut
            scene diet_cut with flashbulb
            dog "把你的手从我的学生身上拿开，你这个该死的老女人。"
            mey "怎...怎么可能..."
            "一刀干净利落，梅扎的头颅飞了出去。"
            scene ded_base with dissolve
            play sound "sound/effects/crumble.mp3"
            "她的身体剩余部分轰然倒地。"
            "她的身体没有流血，反而开始变成似乎是纯金的固体，像破碎的雕像一样裂开。"
            play sound "sound/effects/jantung.mp3"
            show ded_gem with dissolve:
                ypos 72
                linear 1.0 ypos 0
            pause 1.0
            show ded_top with dissolve
            "一颗蓝色宝石从她胸口的裂缝中升起。"
            stop sound
            scene bar_mess with dissolve
            show priest side at center with dissolve:
                yoffset 190
            dog "你会想要那个的，小鬼。那是她的心脏。"
            dog grin cling "除非你改变主意了？我很乐意从你那里抢走它。那东西在黑市上价值连城。"
            show priest kzl -cling
            "你急忙抓住那块石头，安全地放进了口袋里。"
            show side_p k at pic
            play music "MUSIC/MusMus-BGM-049.mp3"
            mc "迪特里希？！你还活着？"
            hide side_p
            dog charm "水仙之怒。我来这里之前喝了那种药水。她杀死的是一个克隆体，不是我。"
            show priest kzl shock
            show side_p sdh at pic
            mc "阿什姆和其他人呢？！"
            hide side_p
            show priest at right with move
            play sound "sound/effects/bump.mp3"
            show tom go sad at left with vpunch:
                xzoom -1.0
                yoffset 190
                
            "仿佛是为了呼应你的话，阿什姆突然从虚空中出现，脸朝下重重地摔在地板上。"
            show side_p g at pic
            mc "阿什姆！"
            hide side_p
            tom ew sweat "我没事。我们需要去找奎尔和塞恩。"
            show tom kzl
            dog side sigh "去吧，我需要照顾莱利。如果需要什么就喊我。"
            

        "使用火焰引燃器" if check_inv_for(item_starter):
            hide pboy
            $ InvItem(*item_starter).toss(1)
            play sound "sound/effects/api.mp3"
            galleryunlock fire_mey
            scene fire_mey with flashbulb:
                subpixel True
                truecenter zoom 2.0
                easein 1.0 truecenter zoom 1.0
            "你伸手到口袋里，掏出火焰引燃器朝她扔去——同时还附带了一个火球以确保效果。"
            "火焰迅速吞噬了梅扎，将她包裹在炽热的烈焰中。"
            mey "你是想把我烧死吗？"
            mey "你把我当成什么二流巫师了？"
            scene bar_mess with fade
            "梅扎轻轻一挥，就把火焰扑灭了。火势消散，浓烟迅速充满了整个房间。"
            "...浓烟足以让某个贪婪的牧师偷偷溜过去。"
            stop music
            play sound "sound/effects/sword.mp3"
            galleryunlock diet_cut
            scene diet_cut with flashbulb
            dog "干得好，假[povname]。"
            mey "怎...怎么可能..."
            "一刀干净利落，梅扎的头颅飞了出去。"
            scene ded_base with dissolve
            play sound "sound/effects/crumble.mp3"
            "她的身体剩余部分轰然倒地。"
            "她的身体没有流血，反而开始变成似乎是纯金的固体，像破碎的雕像一样裂开。"
            play sound "sound/effects/jantung.mp3"
            show ded_gem with dissolve:
                ypos 72
                linear 1.0 ypos 0
            pause 1.0
            show ded_top with dissolve
            "一颗蓝色宝石从她胸口的裂缝中升起。"
            stop sound
            scene bar_mess with dissolve
            show priest side at center with dissolve:
                yoffset 190
            dog "你会想要那个的，小鬼。那是她的心脏。"
            dog grin cling "除非你改变主意了？那东西在黑市上可值一大笔钱。"
            show priest kzl -cling
            "你急忙抓住那块石头，安全地放进了口袋里。"
            show side_p k at pic
            play music "MUSIC/MusMus-BGM-049.mp3"
            mc "迪特里希？！你还活着？"
            hide side_p
            dog side "水仙之怒。我来这里之前喝了那种药水。她杀死的是一个克隆体，不是我。"
            dog charm "看来你也做好了准备。那是相当强效的引火剂。"
            show priest kzl shock
            show side_p sdh at pic
            mc "赞美的话待会再说。阿什姆他们怎么样了？！"
            hide side_p
            show priest at right with move
            play sound "sound/effects/bump.mp3"
            show tom go sad at left with vpunch:
                xzoom -1.0
                yoffset 190
            "仿佛是为了呼应你的话，阿什姆突然从虚空中出现，脸朝下重重地摔在地板上。"
            show side_p g at pic
            mc "阿什姆！"
            hide side_p
            tom ew sweat "我没事。我们需要去找奎尔和塞恩。"
            show tom kzl
            dog side sigh "去吧，我需要照顾莱利。如果需要什么就喊我。"
            
        "{s}使用引火剂{/s}" if not check_inv_for(item_starter):
            
            jump icebay 

        "诱惑她":
            hide pboy
            stop music 
            scene bar_mess with fade
            "在绝望中，你决定尝试一些完全不同的方法。"
            show mey scowl shock at center with dissolve:
                yoffset 100
            play sound "sound/effects/cloth.mp3"
            "你用空闲的手抚摸她的脸颊，然后向下滑动，抚摸她的胸部。"
            mey "...[povname]？"
            show side_p mal at pic
            mc "如果你想放纵自己，只需开口就行，你知道的吧？"
            show side_p ha 
            mc "我很乐意给你你需要的。"
            hide side_p
            mey smile bloom "[povname]...哦，[povname]！"
            mey crazy cling "你真以为我会上当吗？"
            play sound "sound/effects/stab.mp3"
            hide screen cal
            scene bg_black with wet
            "黑影吞噬了你，将你整个吞没。你搞砸了，梅扎看穿了你甜言蜜语的伪装。"
            "在黑暗中，你能听到她深沉的笑声在空气中震动。"
            mey "别担心。我会给你应得的。"
            "..."
            play music "MUSIC/bar_song.mp3" fadein 1.0
            "在那黑暗的深渊中，一首接一首的歌曲开始播放。没有光，没有触感，只有梅扎的歌声在她漆黑的深处给予你慰藉。"
            "起初你抗拒她的歌声，那令人恼火的死亡之音。"
            "随着分钟、小时，也许是几十年过去，你不禁开始渴望它。" 
            "在这个空虚的黑暗深渊中，它是你仍然活着的唯一迹象。一首甜美的海妖之歌充斥着你的感官。"
            "最终，你像她之前所有的受害者一样屈服了..."
            jump mey_bad_end
            


    jump red_dying
    
label mey_bad_end:
    show text "三个月后..." with dissolve
    $ renpy.pause()
    play sound "sound/effects/door.mp3"
    scene mey_vip with dissolve
    show mey smile at center with dissolve:
        yoffset 100
    mey "顾客，[povname]。"
    $ NPC = "客人"
    npc "梅扎，你确定我可以这么做吗？任何我想做的事？"
    mey talk bunga "当然，这里毕竟是梅扎的欲望之屋。"
    mey crazy cling "而且，你很享受不是吗，[povname]？"
    if girl:
        galleryunlock meyza_endf
        scene meyza_endf with fade:
            yalign 1.0
            easein 4.5 yalign 0.0
    else:
        galleryunlock meyza_endm
        scene meyza_endm with fade:
            yalign 1.0
            easein 4.5 yalign 0.0
    mc "当然，女主人。来吧，亲爱的顾客..."
    mc "...释放你的欲望吧。"
    scene bg_black with wet
    $ achievement.grant("Achievement06_Meyza")
    init:
        $ achievement.register("Achievement06_Meyza")
        $ achievement.sync()
    $ achievement.sync()
    show text "梅扎的幸福结局：欲望之屋" with dissolve
    $ renpy.pause()
    jump bad_end_game

label red_dying:
    stop music 
    scene alley_empty with dissolve
    show tom go whine shock at center with dissolve:
        yoffset 190
    tom "塞恩！"
    hide tom with dissolve
    play sound "sound/effects/tile.mp3"
    "没有什么能让你为眼前的景象做好准备。"
    stop sound
    "塞恩浑身是血地躺在地上，奎尔在他身边，被自己的血呛得喘不过气。"
    "阿什姆把奎尔的头抬到自己的膝盖上，看着他时而清醒时而昏迷。"
    show tom go whine sweat at center with dissolve:
        yoffset 190
    tom "奎尔，坚持住。"
    show tom sad
    show quil blood sulk at right with dissolve:
        yoffset 190
    show red blood perih sweat at left with dissolve:
        yoffset 330
    quil sweat "治-治疗药水在我左边口袋里。"
    "阿什姆点点头，搜索奎尔的口袋，然后把液体倒进他的喉咙。"
    tom ew frusta "这样的伤势，只够一个人用的。"
    tom whine blow"[povname]，你需要给塞恩新鲜的血液。他的身体会自己处理剩下的！"
    show tom sad -blow
    show side_p k at pic
    mc "好的！"
    hide side_p
    scene alley_empty with dissolve
    play sound "sound/effects/stab.mp3"
    "你一边形成一个粗糙的冰刃，一边割开自己的手腕。"
    "温热的鲜血流到塞恩的嘴唇上。在本能的驱使下，塞恩很快就有了反应，抓住你的手腕轻轻吮吸。"
    if girl:
        galleryunlock bite_meyza
        scene bite_meyza with wet
    else:
        galleryunlock bite_meyzam
        scene bite_meyzam with wet
    play sound "sound/effects/vamp.mp3"
    "几秒钟内，他身上的伤口开始愈合，只留下粘稠的血迹。"
    play music "sound/effects/jantung.mp3"
    show side_p k at pic
    mc "塞恩！就是这样，你会没事的！"
    mc "我...呃！！！"
    hide side_p
    "塞恩越是恢复力量，就越是沉浸在你的血液中。"
    "他把你推倒，将你压在地板上。当他收回嘴唇时，他舔了舔锋利的獠牙，凶狠地瞪着你。"
    "他将注意力转移到你的脖子上，毫不羞耻地舔舐着，然后悬在你上方。"
    "用他那双锐利的红眼睛盯着你。"
    red "更多..."
    show side_p g at pic 
    mc "（等等，有些地方...不对劲...）"
    hide side_p
    stop music
    scene alley_empty with dissolve
    show quil blood sweat tantrum frusta at center with vpunch:
        yoffset 200
    play sound "sound/effects/punch.mp3"
    queue sound "sound/effects/bump.mp3"
    quil "说真的。管好你的裤子，塞恩！"
    show quil kzl -sweat sigh
    play music "MUSIC/MusMus-BGM-146.mp3"
    "奎尔狠狠地一拳将塞恩从你身上打了下去。"
    "这药剂一定效果惊人，因为如果不是血迹的话，你根本看不出这个男人几分钟前还奄奄一息地躺在地上。"
    show side_p ha at pic
    mc "奎尔，你没事了！"
    hide side_p
    quil tantrum frusta "亲爱的，我差点死掉还毁了我最喜欢的衬衫，我远远算不上没事。"
    quil ejek sigh "但如果你是指还活着能动，那么是的，当然。你还好吗，红眼？"
    show tom go capek blow at right with dissolve:
        yoffset 190
    show red blood ow both frusta at left with dissolve:
        yoffset 330
    show tom frown -blow
    red "妈的，我忘了你的拳头有多硬了。哈啊...我没事。话说回来，我们赢了吗？那个巫师呢？"
    show red sad sweat
    quil wry -sigh "阿什姆和[povname]解决了她。"
    show red datar shock
    red laugh blush cling "太好了！"
    red ngeles sweat -cling "抱歉，[povname]。我不知道为什么，但你的血现在尝起来味道不一样了。"
    show side_p sdh at pic
    mc "事实上，我可能知道确切的原因。"
    hide side_p
    show quil sad shock
    red kaget -sweat apa "啊？"
    show red frown -apa
    quil sweat err -shock "等等，[povname]——"
    show tom sad 
    show side_p fr at pic
    mc "不，奎尔，他们必须知道！"
    show side_p sdh
    mc "尤其是你，阿什姆。你应该知道真相。"
    hide side_p
    tom capek "..."
    tom sigh blow "不要遗漏任何细节。"
    jump tea_time

label tea_time:
    $ my_events.append("mey_kill")
    $ tom_events.append("sulk")
    scene bg_black with w20
    play music "MUSIC/MusMus-BGM-013.mp3"
    scene kmr_apt with w20
    "经过你的再三恳求，奎尔终于带领大家来到真正的[povname]面前。"
    if "help_me" in my_events:
        "迪特里希在安顿好莱利后也跟了过来。梅扎酒吧的其他服务员和员工似乎已经逃离了现场。"
    "当你告诉阿什姆一切后，他惊呆了。不仅是关于你的身份，还有梅扎与[povname]的交易。"
    "他看起来就像你刚刚杀了他妈妈一样。也许这个比喻并不夸张。"
    "[povname]是他的一切，而你在眨眼间就毁掉了这一切。"
    show red blood sad at left with dissolve:
        yoffset 330
    red ow sweat apa "所以...[povname]并没有死，对吧？只是昏迷了？"
    show red sad -apa
    show quil blood bingung sigh at right with dissolve:
        yoffset 200
    quil "你接受得比我想象的要好，塞恩。"
    red huh -sweat sigh "是啊，好吧，你不应该担心我。"
    red ngeles apa"我知道你现在不好，但你还\'还好\'吗，阿什姆？"
    show red sad -apa
    show quil sulk -sigh at center with move
    show tom go sad at right with moveinright:
        yoffset 190
    tom nyesal frusta "...不。我怎么可能还好？"
    tom sigh blow "这是...我无法——"
    tom amused frusta "而我只是...啊哈！啊哈哈哈！"
    show tom sigh sweat blow
    "当一个人哭完后一秒钟就笑起来时，你就知道情况有多糟糕了。"
    "如果阿什姆完全崩溃了，好吧，你也不能怪他。"
    show pboy s at horzappear
    menu:
        "呼唤他":
            hide pboy
            show side_p sdh at pic
            mc "阿什姆——"
            hide side_p
            play sound "sound/effects/slap.mp3"
            tom ew -sweat frusta "不！"
            show red kaget shock
            show quil ow shock
            "阿什姆像甩开什么可憎之物一样打开了你的手。他这么做时，脸上露出愤怒的表情。" with vpunch
            show red sweat sad -shock
            if girl2:
                quil sulk "阿什姆，求你了...不要把怒火发泄在[dia]身上。"
            else:
                quil sulk "阿什姆，求你了...不要把怒火发泄在[dia2]身上。"
            quil fluster sweat frusta "如果你需要发泄对象的话，那就冲我来吧——"
            play sound "sound/effects/punch.mp3"
            quil err shock "呃！" with hpunch
            show tom kzl -frusta
            show red kaget shock
            "阿什姆在奎尔还没说完就一拳打在了他的肚子上。" 
            show red huh -shock
            quil fluster frusta "哇，没想到你{i}真的{/i}会对我发泄。不过好吧，我活该。"
            show quil sulk -frusta
            red kzl -sweat sigh "你觉得呢？"
            if "come_clean" in tom_events:    
                tom capek blow "...对不起，[povname]。我不是有意那样拒绝你的。"
                tom sad -blow "我知道你试图坦白，但我还是...这太过了。"
                $ ibu.points -= 10
                if ibu.points <0:
                    $ ibu.points = 0
            else:
                show quil sad shock
                show red sad shock
                tom kzl "你可能是主谋，奎尔，但这个入侵者也并非无辜。"
                show red huh -shock
                show quil sulk sigh
                tom ejek "你是不是很享受我的关注？我那可怜的追求你的尝试？"
                tom cruel blow "看到一个如此绝望地爱着你，像忠诚的奴隶一样跟随你的人，一定很有趣吧。"
                show side_p sdh at pic
                mc "不是这样的——我不是想要——"
                hide side_p
                tom ew frusta "别说了。我无法应对这个。无论是你还是真正的[povname]。"
                $ ibu.points = 0
                tom ew "我生命中所有那些年，都消逝了。"
                tom whine blow "我利用的那些人，到头来又是为了什么？"
                show tom kzl -blow
                quil ow -sigh "阿什姆，求你——"
                show quil sulk
            tom capek frusta "奎尔，我现在无法应对这个。"
            tom kzl blow "我...我需要一些独处的时间。"


        "给他一些空间":
            hide pboy
            if "come_clean" in tom_events:   
                $ ibu.points -= 5
                if ibu.points <0:
                    $ ibu.points = 0
            else:
                $ ibu.points = 0
                tom capek sweat frusta "你本可以说些什么的，你知道吗？另一个[povname]？"
                show side_p sdh at pic
                mc "我..."
                hide side_p
                tom amused -sweat cling "这很有趣吗？看着我崇拜你走过的每一寸土地？"
                tom cruel -cling "像个无望的小狗一样试图赢得你的青睐？"
                show side_p k at pic
                mc "我...不，这不是——！"
                hide side_p
                tom ew "别说了。现在解释已经太晚了。"
            quil groan sigh"阿什姆，求你——"
            show quil sad shock
            tom capek frusta "奎尔，我现在无法应对这个。"
            tom kzl blow "我...我需要一些独处的时间。"
    tom sad sweat frusta "我必须走了。"
    play sound "sound/effects/tile.mp3"
    hide tom with moveoutright
    show quil at right with move
    quil ow frusta "阿什姆，等等！"
    stop sound
    red ngeles "别，奎尔。他现在有权生气。"
    show quil sad shock
    red so -sweat sigh "让他主动来找你吧。"
    quil sulk sigh "我想是的。你也要离我而去吗？"
    red ew apa "我？不会。我的意思是我确实对你很生气。"
    red hister cling "但如果我走了，那我就看不到[nickname]在我揍[dia]那张蠢脸时的反应了，所以..."
    show red amused -cling 
    quil wry -sweat sigh "呵。你总是知道该说什么，红头发。"
    red cowo "嗯。我会陪着你的，伙计，我们很快就能让这个混蛋恢复过来。"
    if "help_me" in my_events:
        show red frown shock
        show quil frown shock
        show priest bleh at center with dissolve:
            yoffset 190
        dog "虽然我很享受这种多愁善感的爱情盛宴，但我们能继续正事了吗？"
        dog side sigh "莱利和我还有其他事情要处理。"
        if girl2:
            dog kzl -sigh"你有那颗心脏，对吧，[povname]？把它放在[dia]身上，看看会发生什么。"
        else:
            dog kzl -sigh"你有那颗心脏，对吧，[povname]？把它放在[dia2]身上，看看会发生什么。"
    
    else:
        show quil frown shock
        red bingung apa "说到这个，你们谁拿着那颗心脏？"
        show quil datar -shock
        if girl2:
            red cowo -apa "让我们把它放在[dia]身上，看看会发生什么。"
        else:
            red cowo -apa "让我们把它放在[dia2]身上，看看会发生什么。"
    show side_p fr at pic
    mc "好的。"
    hide side_p
    if girl:
        galleryunlock bobo_f
        show bobo_f with dissolve
    else:
        galleryunlock bobo
        show bobo with dissolve
    play sound "sound/effects/jelly.mp3"
    show bobo_meyza with moveinright:
        xpos 1062 ypos 234
    "当你轻轻地将宝石放在你的分身胸口时，宝石开始发出温暖的光芒，然后完全嵌入了[povname]的身体。"
    hide bobo_meyza with flashbulb
    "你可以看到[povname]的眼睛开始抽动。他们慢慢地、轻微地睁开了眼睛。"
    "奎尔的脸上洋溢着如释重负的表情，以为一颗心脏就足够了。然而，当你的分身在再次闭上眼睛之前只说了一个词时，这种希望就破灭了。"
    mc "...救命。"
    stop sound
    if girl:
        hide bobo_f with dissolve
    else:
        hide bobo with dissolve
    if "help_me" in my_events:
        dog side sigh "好吧，有进展就是进展。"
        show priest kzl -sigh
        quil hister sigh "至少我们知道它起作用了。"
    show quil wry -sigh
    red ew sweat frusta "该死，这个混蛋真知道怎么拨动你的心弦。"
    red wry -sweat sigh "听到这个之后我甚至都不能生气了。"
    quil rajuk "我们还需要三颗心脏才能让[povname]完全恢复。"
    show quil frown
    red huh sigh "说起来容易做起来难。我们甚至不知道其他巫师在哪里。"
    if "help_me" in my_events:
        dog charm "我会四处寻找线索的。"
        dog grin cling "就当是对你救了莱利并把俱乐部留给我的感谢吧。"
        show priest chill -cling
        show side_p k at pic
        mc "我不记得有把俱乐部留给你。"
        hide side_p
        red ow apa "伙计，你不会真的要接管那个地方吧？"
        show red frown shock
        dog laugh cling "当然要接管，塞恩。还有什么比吃富人更好的退休保障呢？"
        show red wry sigh
        dog grin -cling "当然，我得改变营销策略。也许改成一个地下酒吧，不再有歌唱表演，但可能会有一支乐队..."
        quil frown apa "所以你要离开校园了？"
        dog side sigh "当然不会。我不在的时候莱利会管理那个地方。她完全有能力做到。"
        dog charm -sigh "她可以使用俱乐部的全部资金。应该足够我们两个人用了。"
        show priest chill
        show side_p fr at pic
        mc "对你来说，钱真的就是一切，是吗？"
        hide side_p
        dog grin cling "当然。金钱能买到幸福，别让人告诉你不是这样。"
        dog laugh -cling "那么，如果你不介意的话，我还有生意要做。"
        hide priest with dissolve
    else:
        quil hister "我们会想办法的。我们已经杀死了一个，这已经是个不错的开始了。"
    quil datar sigh "现在我想除了回宿舍好好洗个澡之外，也没什么可做的了。"
    red perih sweat frusta "说得对，伙计。我迫不及待想把这些血洗掉了。"
    red bingung sigh "希望我的室友不会吓坏。"
    red cowo -sweat -sigh "你很幸运，[povname]，你毫发无损。"
    show side_p ha at pic
    mc "除了几处淤青和手腕上的伤口，是的。"
    hide side_p
    red amused shock "哦，说到这个，把你的手给我一下。"
    show side_p g at pic
    mc "...为什么？"
    hide side_p
    red happy -shock"我保证不会咬你的。照做就是了。"
    "你勉强地把手腕伸向塞恩的嘴唇。"
    "他的舌头一舔，伤口瞬间愈合了。"
    red mock blush "太...太甜了。"
    show quil kzl shock
    show red perih sweat shock
    play sound "sound/effects/slap.mp3"
    queue sound "sound/effects/slap.mp3"
    "奎尔抓起床头柜上的一本卷起的杂志，拍了一下塞恩的头。"
    quil grit frusta "冷静点，小子。别那样看着[povname]，好像[povname]是一顿会走路的自助餐似的！"
    show quil kzl -frusta
    red hister both -shock "抱歉，一定是因为你的\'异族\'血液的缘故。"
    show red blush 
    quil groan sigh "是啊，尽量别表现得那么明显。哦，还有，这话不用说，但别把[povname]的情况告诉其他人。"
    quil kzl -sigh "尤其是菲亚。"
    red hister "哦，别担心，我不会告诉任何人的。尤其是她。我还想让你活着呢，奎尔。"
    red amused cling "不过我有点想知道她会对你做什么。活剥了你？割掉你的蛋蛋？把你切成小块然后做成肉馅饼？"
    show red cowo -cling
    show quil frown shock
    show side_p ha at pic
    mc "肉馅饼倒是挺有意思的。菲亚和我都喜欢做饭，而馅饼是她的拿手好菜，所以..."
    hide side_p
    red sayang "是啊，她可能会把你切成几块。变态们肯定会希望得到你的屁股或者小鸡—"
    quil sulk sweat frusta "呃，别说了！我甚至不想想象！"
    stop music
    scene bg_black with w20
    "戏弄了奎尔一会儿后，你们都回到宿舍准备好好洗个澡。"
    jump lyall_arsh

label lyall_arsh:
    $ buff_events.append("pike_injur")
    scene kmr_malam with dissolve
    play sound "sound/effects/door.mp3"
    show buff skul kzl at center with dissolve:
        yoffset 770
    "不幸的是，当你进入房间时，你很快就发现洗澡得等一等了。"
    show buff at right with move
    play music "MUSIC/MusMus-BGM-054.mp3"
    if girl:
        show palmierproxy jln apa at left with moveinleft:
            yoffset 40
    else:
        show palmierproxy jln apa at left with moveinleft:
            yoffset 100
    mc tanya "莱尔？"
    hide side_p
    if "rooted" in buff_events:
        mc frown -tanya "你这个时候还醒着干什么？"
        buff confused frusta "我在照看那朵玫瑰。它长得很快。我听到它的哭声就睡不着。"
        show buff kzl sigh
        mc side sweat "哦...抱歉。"
        show palmierproxy frown -sweat
        buff scold apa "话说，你去哪儿了？我在校园里哪儿都找不到你。"
        show buff kzl -apa
        mc rajuk sweat"那是...私事。"
        show palmierproxy ow -sweat shock
        buff scold frusta "你没做什么坏事吧？我需要向校长报告你吗？"
        show buff kzl -frusta
        mc sad sigh "别这样。你看，我身上没有花。"
        if "help_me" in my_events:
            mc smile sweat "我在为迪特里希先生做一项任务。"
            show palmierproxy wry -sweat
            buff eh sweat shock "哦，我明白了。那么，抱歉刚才怀疑你。"
            show buff frown -sweat -shock
            mc eiden tanya "嗯，你的态度变得真快，你知道吗？我搞不清你是喜欢我还是讨厌我。"
            show palmierproxy wry -tanya 
            buff huh sigh "说实话，我自己也不知道。我还没决定。"
            buff keluh -sigh "你真是个难以捉摸的人，[povname]。"
            show buff sad 
            mc panik both "你还不知道一半呢。"
            show palmierproxy smile
            buff keluh sigh "嗯。那么，晚安[povname]。"
        else:
            mc panik sweat "我只是...和阿什姆吵了一架。你知道，就是那些前任之间的破事。"
            buff keluh sweat shock "哦，呃，我很抱歉。"
            buff sad -sweat apa "他还好吗？"
            mc huh tanya "你不担心我吗？"
            show palmierproxy frown -sweat shock
            buff lega sigh "不是冒犯，但是...在我看来，阿什姆爱你比你爱他多得多，[povname]。"
            show buff wry -sigh
            mc avoid sweat frusta "连你都看得出来，是吗？"
            mc smile -sweat tanya "莱尔，你曾经有过恋人吗？"
            buff scold shock "我？当然没有。除了我的兄弟们，我没机会和任何人说话。"
            buff sad sweat sigh "有时候会和姐妹们说话，但她们通常只是来嘲笑我的。"
            mc ha "伊瓦尔不是个公平的父亲，对吧？"
            show palmierproxy frown shock
            buff confused -sweat frusta "不，他不是。虽然..."
            buff sad sigh "...嗯，我确实看到他在把伊尔夫变成花的时候哭了。"
            mc deject tanya "哦？"
            show palmierproxy frown -tanya
            buff scold apa "我知道这很奇怪，但他一直在喃喃自语，说如果有选择的话他不想这么做。"
            buff huh sigh "我从来不明白他的意思。他明明有选择，只是忽视了而已。"
            buff lega sweat "总-总之，时间不早了。我不想用我的人生故事烦你。晚安[povname]。"
        mc laugh "晚安。"


    else:
        mc ha tanya"你这个时候还醒着干什么？"
        show palmierproxy frown sweat shock
        buff keluh sigh "其实我一直在等你。"
        mc "等我？"
        buff frown -sigh "水母节快到了，派克让我去戈莫拉帮忙。"
        buff "从派克的村子运送鱼和其他货物到镇上广场。"
        buff sad sweat frusta "我本来不介意，但后来事情开始失控了。"
        mc confused -sweat tanya"嗯？"
        buff kzl sigh "一个屠夫注意到了我的眼睛，试图用肉刀刺我。"
        mc grit sweat shock "什么？！"
        buff sad "别担心，没有伤到我。但是派克却..."
        show buff -sigh
        mc ow sweat tanya "哦，他没事吧？他没死吧？"
        show palmierproxy sad -tanya
        buff keluh -sweat shock "没有，没有！但他的捕鱼手臂受伤了。需要戴吊带一两周。"
        if "desa" not in buff_events:
        
            buff sad sigh "我试图说服他喝药水加快恢复，但他不愿意。"
            buff frown -sigh"所以...这就是我需要你帮忙的地方。你明天能帮我把货物从戈莫拉运到莱纳尔吗？"
            buff keluh sweat frusta "我知道你不欠我什么，但我已经答应了派克我会帮忙，而且他已经付了钱，所以——"
            show pboy s at horzappear
            menu:
                "帮助莱尔":
                    hide pboy
                    $ buff_events.append("ker_bar")
                    $ putri.points += 5
                    $ kindness += 10
                    show buff lega blush shock
                    mc laugh blush bunga "当然。如果你在镇上面对人群时也需要帮助，尽管告诉我。"
                    mc mock -blush cling "事实上，就把镇上的人交给我处理吧，好吗？"
                    show palmierproxy smile -cling
                    buff laugh blush bunga "那太好了，谢谢你。"

                "拒绝":
                    hide pboy
                    $ putri.points -= 15
                    if putri.points <0:
                        $ ibu.points = 0
                    $ kindness -= 10
                    show buff sad shock
                    mc ew sweat frusta "抱歉莱尔，但我觉得现在不是最好的时机。我现在有其他事情要忙。"
                    buff wry sweat sigh "哦，我明白了。没关系。我相信我能应付。呃...晚安。"
                    mc smile -sweat -frusta "晚安。"
                    
                    
                "有偿帮助":
                    hide pboy
                    $ buff_events.append("ker_bar")
                    $ honesty += 10
                    mc happy -sweat cling "给点现金，然后我们再谈。"
                    buff wry sigh "现金？哦，你是说金币。当然。派克为这整个活动每天付给我100金币。给你50金币一天可以吗？"
                    $ gold += 50
                    play sound "ding.mp3"
                    "莱尔给了你50金币。"
                    mc smile -cling "谢谢！别担心，我保证我会去的。"
                    show buff datar -sweat -sigh
                    "莱尔点了点头，尽管他的笑容看起来有点勉强。"
        else:
            buff sad sigh "我只是觉得你应该知道，也许你可以帮我减轻派克的工作。"
            buff wry -sigh "比如陪我去莱纳尔之类的。"
            buff keluh both shock "啊，但只有在你有空的情况下，我不想麻烦你！"
            show buff sad -both -shock
            mc kind -sweat "当然，伙计。嘿，如果有什么的话，这给了我们更多时间一起玩，对吧？"
            buff wry blush bunga "...是啊。"
            buff laugh sigh "好了，我想说的就是这些。晚安，[povname]。"
        scene kmr_malam with dissolve
        "莱尔去睡觉后，你慢慢地泡在浴缸里。你希望下一个要面对的巫师不会像梅扎那么糟糕。"
    stop music
    scene bg_black with w20
    jump morning


label io_dream:
    scene io_lair with wet
    if girl:
        show palmierproxy scratch confused sweat at center with dissolve:
            yoffset 40
    else:    
        show palmierproxy scratch confused sweat at center with dissolve:
            yoffset 100
    mc "什么？我在哪里？"
    $ my_events.append("io_dream")
    $ NPC = "???"
    mc chill rajuk tanya "我以为忘记我的符文意味着要拜访伊瓦尔，但这是另一个巫师的梦境吗？"
    scene io_altar with dissolve
    play sound "sound/effects/walk.mp3"
    play music "MUSIC/MusMus-BGM-CP05.mp3"
    show Io no frown at center with dissolve:
        yoffset 80
    "你环顾四周，看到一个女人坐在水边，似乎对你的存在毫无察觉。"
    io smile "你带来礼物了吗，阿佩普？"
    show Io snek flow smile with dissolve
    "起初你以为她是在对你说话，但很快你注意到一个白色的轮廓从你身边滑过，缠绕在那个女人的身上。"
    "现在它在她的肩膀上，你终于注意到那个滑动的轮廓是一条蛇，只是缺少了皮肤和...嗯，其他一切。"
    "一朵熟悉的红玫瑰被塞在它的嘴里，然后它把玫瑰咳到了女人的手中。"
    io frown sigh "啊。又是亲爱的伊瓦尔的造物。哭喊着求饶。"
    if "rooted" not in buff_events:
        io -sigh "你说这个是水送给我的？托马斯，是吗？嗯。"
        io "看来伊瓦尔的势力终于延伸到学校了。"
    else:
        io -sigh "这又是从死亡区域来的吗？天啊，我们有很多清理工作要做，不是吗？"
    io smile "嘘，小家伙，无论你哭得多么凄惨，也无法唤来死亡的甜蜜拥抱。"
    play sound "sound/effects/jelly.mp3"
    scene ubur1 with dissolve
    galleryunlock ubur1
    io "虽然我无法实现你的愿望，但我会尽力安抚你的灵魂。"
    "慢慢地，玫瑰被光芒包围，然后完全变成了另一种东西。"
    play sound "sound/effects/change.mp3"
    scene ubur with flashbulb
    galleryunlock ubur
    show side_p he at pic
    mc "一只水母？"
    hide side_p
    io "做个好梦，小家伙。"
    scene io_altar with dissolve
    play sound "sound/effects/jelly.mp3"
    "你看着水母从她手中飞出，平静地飘过天花板。"
    "这就是这个世界里会飞的水母的来源吗？"
    show Io snek frown at center with dissolve:
        yoffset 80
    io "……我这位带着死亡气息的访客也想要我的拥抱吗？"
    stop sound
    show Io at left with move
    if girl:
        show palmierproxy scratch confused shock sweat at right with moveinright:
            yoffset 40
    else:
        show palmierproxy scratch confused shock sweat at right with moveinright:
            yoffset 100
    mc "啊？！等等，你是在跟我说话吗？"
    show palmierproxy chill rajuk -shock
    "那位女子停顿了一下，然后对你温暖地微笑。"
    show palmierproxy frown -sweat
    io smile "死亡的气息像第二层皮肤一样紧贴着你，但这是一种不同的死亡。一种来自异世界的死亡。"
    io frown "你是那个意外的勇士。那个将成为我们终结的无辜局外人。"
    show palmierproxy apa 
    "当她走近你时，你能更仔细地看清这位女士的眼睛。"
    show palmierproxy frown 
    show peek with dissolve
    "她的眼睛里没有瞳孔和虹膜，更像是……"
    show side_p f at pic
    mc "……星星。"
    hide side_p
    hide peek with dissolve
    "巫师对你着迷的表情微笑着。"
    io smile"这并非我们真正相遇的时刻，小家伙。你还有我的一位同族要杀。"
    scene io_lair with dissolve
    play sound "sound/effects/walk.mp3"
    "巫师转身走到房间中央。"
    show Io snek frown at center with dissolve:
        yoffset 80
    io "在那之前，我会在这里等待你的到来，在最亵渎的秘密中。"
    io smile "在一个人类和巫师试图成为神的坟墓里。"
    show side_p s at pic
    mc "你在说什么？"
    hide side_p
    io "这就要靠你自己去发现了，小家伙。再见。"
    stop music
    scene bg_black with eye_shut
    io "是时候回到你的噩梦中去了。"
    jump morning

label iv_second:
    scene rose_arch with flashbulb
    play sound "sound/effects/walk.mp3"
    show side_p he at pic
    mc "喂？伊瓦尔？"
    hide side_p
    $ my_events.append("iv_dream2")
    play music "MUSIC/MusMus-BGM-112.mp3"
    show rosy at center with dissolve:
        zoom 0.45
    "你看到的不是伊瓦尔，而是他的一个仆人向你鞠躬。一束红玫瑰。"
    show rosy at right with move
    if girl:
        show palmierproxy chill apa sweat at left with moveinleft:
            yoffset 40
    else:
        show palmierproxy chill apa sweat at left with moveinleft:
            yoffset 100
    mc "（这是莱尔的兄弟之一，对吧？）"
    mc deject"（不知道在伊瓦尔不知情的情况下和他交谈是否安全。）"
    show pboy at horzappear
    menu ylf_q:
        "问伊瓦尔在哪里":
            hide pboy
            mc kind -sweat "我，呃，我没想到能和你说话。伊瓦尔在哪里？"
            npc "..."
            show palmierproxy frown tanya
            "玫瑰头的男子停顿了一下，然后指向一个小花园棚屋的方向。"
            mc scratch confused sweat "在那里？嗯，谢谢。"
            scene green_drawer with dissolve
            "你走进棚屋，决定四处看看。"
            jump map_shed
        "在他眼前挥手":
            hide pboy
            mc sad tanya "你能看见我吗？"
            show palmierproxy pissed shock
            "那个仆人抓住你的手腕，把你拖到附近的一个棚屋。"
            mc grit -shock "嘿，等等——！"
            scene greenhouse with dissolve
            jump iv_met2
        "你是伊尔夫吗？" if "big_bro" in topics:
            hide pboy
            show rosy with move:
                xalign 0.3
            "玫瑰使劲地点了点头。"
            show rosy with hpunch
            show palmierproxy frown shock
            play sound "sound/effects/cloth.mp3"
            "他紧握着你的手，似乎在等你继续说下去。"
            mc huh sweat tanya "我猜这是在说\"是\"？"
            mc happy -sweat -tanya "我叫[povname]。我是你兄弟的室友。莱尔·基森这个名字你有印象吗？"
            show rosy with vpunch
            show palmierproxy confused 
            "玫瑰再次点头。然而，这次他的花瓣上沾满了露水。"
            play sound "sound/effects/crumple.mp3"
            "然后他从口袋里掏出一封折叠的信，塞进你的手里。"
            show palmierproxy frown tanya
            "你看到信的收件人是\"幸存者们\"——猜测他指的是他的兄弟莱尔，于是把信放进了口袋。"
            iv "请再来些茶。"
            show palmierproxy sad shock
            $ InvItem(*item_ylf).pickup(1)
            $ newitem = InvItem(*set_item("item_ylf"))
            play sound "sfx/btn16.mp3"
            show screen reward(newitem.image)
            "获得了{color=#d48}伊尔夫的信{/color}！"
            hide screen reward
            hide rosy with moveoutright
            play sound "sound/effects/tile.mp3"
            "伊尔夫歪着头看你，示意你去找伊瓦尔，然后跑开了，可能是去拿茶。"
            stop sound
            scene rose_arch with dissolve
            "当你把信安全地放进夹克里时，你听到伊瓦尔又从附近的花园棚屋里呼唤你。"
            show side_p he at pic
            mc "（最好对伊瓦尔保守伊尔夫的信的秘密。）"
            hide side_p
            scene greenhouse with dissolve
            jump iv_met2
        "{s}你是伊尔夫吗？{/s}" if "big_bro" not in topics:
            
            jump ylf_q
label iv_met2:
    show ivar kzl flow at right with dissolve:
        yoffset 150
    if girl:
        show palmierproxy chill frown sweat at left with moveinleft:
            yoffset 40
    else:
        show palmierproxy chill frown sweat at left with moveinleft:
            yoffset 100
    iv "又是你。你想要什么？"
    if not girl:
        iv frown sigh "我不是说过我们不需要再忍受彼此的存在了吗？"
        iv ancam cling "还是说你是那种喜欢受虐的堕落类型？"
        show ivar ejek -cling
        mc side frusta "我不是受虐狂。"
        mc kzl tanya "听着，我只是来问几个问题。所以如果你能暂时忍住伤害我的冲动几分钟，我会非常感激的。"
        show palmierproxy frown -tanya
        iv frown sigh "那就快点。虽然你很漂亮，但我觉得我忍不了太久。"

    else:
        mc rajuk tanya "你听起来不太高兴见到我。"
        show palmierproxy frown -tanya
        iv frown sigh "我不喜欢打扰我喝茶时间的访客。不管他们有多漂亮。"
    if "mey_kill" not in my_events:
        mc confused "我找到了我需要的信。梅扎的信。"
        jump omg_letter
    else:
        mc kzl sigh "我们杀了梅扎。"
        iv frown sigh "我听说了。"
        mc apa tanya "你似乎对这个消息并不太在意。"
        show palmierproxy frown -sigh
        iv flirt cling "因为我确实不在意。梅扎总是对漂亮的脸蛋有弱点。"
        iv -cling "而你异常美丽。"
        mc kzl frusta "你一点都不在乎吗？"
        iv amused sigh "我既在乎又不在乎。我承认这改变了我对你的看法。"
        mc confused -frusta "哦？"
        iv -sigh "之前，你只是个旁观者，环境的受害者。"
        iv ancam cling "现在你和我们其他人一样，都是罪人。"
        mc side frusta"她本来会杀了我的。"
        iv kzl sigh "我很怀疑。她爱你。我是说[povname]。她不会杀你的。"
        iv flirt cling "只会永远把你囚禁起来，当作一个奖品，如果你愿意这么说的话。"
        mc grit frusta "想要拥有某人并不是爱。"
        iv frown sigh "确实，但这是她唯一知道的爱。"
        iv ancam cling "恭喜你的第一次杀戮，年轻的罪人。我很好奇你还会犯下什么其他重罪。"
        iv amused sigh "但首先，让我惩罚你的第一宗大罪。"
        scene bg_black with vpunch
        play sound "sound/effects/stab.mp3"
        mc "啊！！！"
        "伊瓦尔把他的玫瑰扔向你的眼睛，玫瑰茎刺穿了你的眼睛。"
        "你痛苦地尖叫着，伊瓦尔的轻笑声在你耳边回荡。"
        play sound "sound/effects/cloth.mp3"
        scene bed_alter with eye_open
        show side_p m at pic
        mc "哈啊！！！" with vpunch
        show side_p s
        mc "该死。我的眼睛..."
        hide side_p
        "你在镜子里检查，当发现你的眼睛完好无损时，你松了一口气。"
        "看了看手机，你意识到现在还是午夜。你试图重新入睡，这次画上了梦境符文，以确保不会有不速之客来访。"
        scene bg_black with eye_shut
        jump morning

    

label map_shed:
    "进入小屋后，你感到足够大胆，开始四处查看。在抽屉里搜索时，你发现了一幅古老的插图。"
    "画中描绘了一个美丽的年轻男孩。金发，配上金色的眼睛。"
    "围绕着他的人们都在崇拜他，并向他抛洒花瓣。"
    "角落里有小小的涂鸦，组成了\'丰饶之巫\'这个短语。"
    if girl:
        show palmierproxy scratch apa sweat at left with moveinleft:
            yoffset 40
    else:
        show palmierproxy scratch apa sweat at left with moveinleft:
            yoffset 100
    mc "这是...伊瓦尔吗？"
    show palmierproxy ow shock 
    show ivar kzl frusta at right with dissolve:
        yoffset 150
    iv "你不应该偷偷翻看别人的东西。"
    iv frown sigh "还是说在你的世界里没有教过这一点？"
    "伊瓦尔从背后突然出现，一把抢走了那幅画。"
    show palmierproxy chill frown -shock -sweat
    show pboy at horzappear
    menu:
        "你小时候很可爱。":
            hide pboy
            show palmierproxy mean 
            iv kzl frusta "你的意见对我来说毫无意义。"
            show palmierproxy kind

        "丰饶之巫？":
            hide pboy
            iv amused -sigh "一个死去的名字，来自我的\'辉煌\'岁月。"
            mc deject tanya "辉煌岁月？"
            iv frown sigh "当我也被奉为神明的时候。一个繁荣和丰饶之神。"
            mc eiden -tanya "好吧，至少这个名字比\'厌男者伊瓦尔\'要好。"
            mc confused tanya "发生了什么变化？"
            iv kzl -sigh "那不关你的事。那都是过去的事了。"
            mc huh frusta "你不是说过\'我会一直对你诚实\'吗？"
            show palmierproxy sad sigh 
            iv frown "诚实并不意味着直言不讳。我有权保有自己的隐私。"
            mc "（一个漏洞，我在想还有什么其他的漏洞。）"
            mc "（他似乎有些慌乱。我不知道那张照片有什么特别重要的。也许我应该查一下他的那个别名。）"
    iv flirt apa"现在，你这次不请自来有什么特别的原因吗？"
    if not girl:
        iv ejek cling "还是说你有死亡的愿望？"
    else:
        iv ejek cling "或者你只是想念我的陪伴？"
    
    if "met_mey" not in my_events:
        mc deject sigh "我找到了我需要的信。梅扎的信。"
        jump omg_letter
    else:
        mc kzl sigh "我们杀了梅扎。"
        iv frown sigh "我听说了。"
        mc apa tanya "你似乎对这个消息并不太在意。"
        show palmierproxy frown -sigh
        iv flirt cling "因为我确实不在意。梅扎总是对漂亮的脸蛋有弱点。"
        iv -cling "而你异常美丽。"
        mc kzl frusta "你一点都不在乎吗？"
        iv amused sigh"我既在乎又不在乎。我承认这改变了我对你的看法。"
        mc confused -frusta "哦？"
        iv -sigh "之前，你只是个旁观者，环境的受害者。"
        iv ancam cling "现在你和我们其他人一样，都是罪人。"
        mc side frusta "她本来会杀了我的。"
        iv kzl sigh "我很怀疑。她爱你。我是说[povname]。她不会杀你的。"
        iv flirt cling "只会永远把你囚禁起来，当作一个奖品，如果你愿意这么说的话。"
        mc grit frusta "想要拥有某人并不是爱。"
        iv frown sigh "确实，但这是她唯一知道的爱。"
        iv ancam cling "恭喜你的第一次杀戮，年轻的罪人。我很好奇你还会犯下什么其他重罪。"
        scene bg_black with eye_shut
        jump morning
label omg_letter:
    mc apa tanya "我希望你能告诉我更多关于她的事。她的弱点，她的优势。"
    iv ancam -cling "哈！你们人类总是如此贪婪。"
    iv amused -sigh "仅仅因为我指明了方向，并不意味着我会帮你屠杀我的同类。"
    show palmierproxy confused shock
    iv smirk sigh "我只是把你引向她，希望你会死在那里。"
    show palmierproxy sad -shock
    iv frown -sigh "梅扎一直都很喜怒无常。她应该会很快结束你的生命。"
    mc kzl "我以为你说过你和其他巫师相处不来。"
    iv kzl frusta "我说的是我们无法合作。我从未声称我恨他们。"
    iv frown sigh "我们的分道扬镳是友好的。当有许多人时，就无法扮演上帝。我们永远无法在任何事情上达成一致。"
    iv -sigh "如果你来这里寻求指导，那么你浪费了我们两个人的时间。"
    iv flirt cling "现在就离开，除非你想以一种更...永久的方式留下。也许你的头会绽放成一朵美丽的黄牡丹。"
    show ivar smirk flow bloom
    "伊瓦尔的手抽搐了一下，一朵玫瑰在他手中绽放。"
    mc ha sweat frusta "谢谢，但不用了。我还挺喜欢保持头部完整的。"
    show ivar frown -bloom
    mc panik tanya "那么，呃，我该怎么离开？"
    iv ancam cling "在梦中死亡是最快的选择。我会享受这个过程的。"
    mc ow shock "什么——？"
    stop music
    scene bg_black with vpunch
    play sound "sound/effects/stab.mp3"
    mc "啊！！！"
    "伊瓦尔把他的玫瑰扔向你的眼睛，玫瑰茎刺穿了你的眼睛。"
    "你痛苦地尖叫着，伊瓦尔的轻笑声在你耳边回荡。"
    play sound "sound/effects/cloth.mp3"
    scene bed_alter with eye_open
    show side_p m at pic
    mc "哈啊！！！" with vpunch
    show side_p s
    mc "该死。我的眼睛..."
    hide side_p
    "你在镜子里检查，当发现你的眼睛完好无损时，你松了一口气。"
    "看了看手机，你意识到现在还是午夜。你试图重新入睡，这次画上了梦境符文，以确保不会有不速之客来访。"
    scene bg_black with eye_shut
    jump morning

#MEMORI_TIME
label io_dream_check:
    $ mk = Character('[povname]', callback=name_callback, cb_name='mk', image='palmierproxy')
    $ NPC = "Io"
    if "io1" not in my_events:
        jump memori1
    elif "io2" not in my_events:
        jump memori2
    elif "io3" not in my_events:
        jump memori3
    elif "io4" not in my_events:
        if "seth_drem" not in my_events:
            jump seth_drem
        else:
            jump memori4
    else:
        jump morning
label seth_drem:
    stop music 
    $ morning = False
    $ afternoon = False
    $ evening = False
    $ night = True
    scene bg_black with eye_shut
    scene church with eye_open:
        truecenter zoom 0.5
    "你睁开眼睛，发现自己回到了教堂，就是[povname]杀死伊瓦尔女儿的那个教堂。"
    show side_p he at pic
    $ my_events.append("seth_drem")
    mc "她的名字是什么来着？"
    hide side_p
    if girl:
        show palmierproxy dobel flirt mseth at center with dissolve:
            yoffset 40
    else:
        show palmierproxy dobel flirt mseth at center with dissolve:
            yoffset 100
    mc "维拉。"
    play music "MUSIC/MusMus-BGM-112.mp3"
    show side_p s at pic
    mc "...[povname]？"
    hide side_p
    mc mock cling"不完全是。"
    "眼睛，它们有些不同。一只是你标志性的灰色眼睛，另一只是浑浊的棕色。几乎像蛇一样。"
    mc judes frusta "蛇？得了吧，你不会是在把我比作阿佩普吧？"
    mc flirt cling "你不能拿创造物与其创造者相比，这根本不公平。"
    show side_p he at pic
    mc "他的创造者？你...你是谁？你是巫师吗？"
    hide side_p
    mc mock -cling "嗯...我更喜欢被称为神。"
    mc kind sigh "但为了简单起见，你可以叫我塞斯，变化巫师。"
    mc mock cling "你带来了多么了不起的变化啊，宠物。"
    hide palmierproxy
    show quil flashy sly at center with flashbulb:
        yoffset 200
    "塞斯绕着你转圈，开始改变形态，从奎尔，"
    hide quil
    show tom hip ejek at center with flashbulb:
        yoffset 190
    extend "到阿什姆，"
    hide tom
    show red chin mock at center with flashbulb:
        yoffset 330
    extend "塞恩，"
    hide red
    show croissant bebas ejek at center with flashbulb:
        yoffset 500
    extend "然后是菲亚。"
    "...你的菲亚。"
    if girl:
        show palmierproxy jln grit at left with dissolve:
            yoffset 40
    else:
        show palmierproxy jln grit at left with dissolve:
            yoffset 100
    mc "立刻变回去，现在！"
    show croissant pain apa at right with move
    fia "为什么？我让你感到不舒服了吗，小宠物？"
    show croissant ejek cling
    show palmierproxy sad sweat shock
    play sound "sound/effects/shing.ogg"
    "凭空出现了一把冰匕首在菲亚手中。它直指她的喉咙。"
    mc ow frusta"不，别——！"
    fia kerja apa "我问你一个问题。我让你感到不舒服了吗，宠物？"
    mc side -frusta "是...是的。"
    fia laugh blush bunga "很好。"
    "菲亚笑了。那是你曾经每天都能看到的温柔笑容。"
    show blud_overlay with vpunch
    play sound "sound/effects/splat.wav"
    show palmierproxy grit shock
    hide croissant with vpunch
    show palmierproxy at center with move
    "但很快，那笑容变成了痛苦的表情，她将冰匕首刺入自己的胸膛，然后无生气地倒在地上。"
    play sound "sound/effects/crash.mp3"
    queue sound "sound/effects/cloth.mp3"
    mc ow frusta "不！不！不！！不！！！菲亚！！！" 
    scene church with dissolve:
        truecenter zoom 0.5
    "你双膝一软，跪倒在地。"
    "你知道这是一场梦，但你还是哭了——紧紧抱着她失去生命的身体，感受着她的尸体逐渐变冷。"
    show side_p sdh at pic
    mc "为什么？！你为什么要给我看这个？！"
    hide side_p
    "一阵沉默过后，菲亚的身体再次站了起来，脸上带着扭曲的笑容。"
    play sound "sound/effects/cloth.mp3"
    show croissant bebas laugh at center with dissolve:
        yoffset 500
    fia ejek cling "因为这很有趣，而且我现在还在友好相处。"
    fia laugh blush bunga "把这当作是一次排练吧，宠物。为我们最终相遇做准备。"
    fia "当然，得等我让你找到我的时候。"
    show side_p k at pic
    mc "别再说这些莫名其妙的话了。露出你的真面目，懦夫！"
    hide side_p
    fia cringe sigh "但那样你就会知道我真实的样子了，我们可不能让这种事发生。那会破坏乐趣的！"
    fia ejek cling "滴答滴答，小宠物。你最好快点行动了。我会等着你的。"
    hide croissant
    show priest charm at center with dissolve:
        yoffset 200
    fia "也许在学校，"
    hide priest
    show har at center with dissolve
    extend "也许在莱纳尔，"
    hide har
    show caf smile at center with dissolve
    extend "也许在戈莫拉。"
    hide caf
    show croissant bebas laugh at center with dissolve:
        yoffset 500
    fia hister bunga "别给我打电话，我会联系你的！"
    fia hmph "但首先，你得偷走那个老海巫婆的心。然后...然后我们就能玩点真正有趣的了。"
    fia ejek cling "滴答，滴答！"
    stop music
    scene bg_black with eye_shut
    scene bed_alter with vpunch
    play sound "sound/effects/cloth.mp3"
    show side_p k at pic
    mc "啊啊啊！"
    hide side_p
    "你在凌晨两点惊醒，被单被汗水浸透，头发凌乱地贴在脸上。"
    show side_p k at pic
    mc "我绝不会让他接近菲亚。永远不会！"
    hide side_p
    "你给奎尔发短信说明了发生的事，令人惊讶的是他还醒着。"
    "他安抚了你，并说他和其他人会试着调查塞斯的事。同时，你应该在莱纳尔保持警惕。"
    "经过大约一个小时的疯狂短信交流后，你慢慢平静下来，试图重新入睡。"
    "你需要保持警惕，开始注意你在和谁交谈。"
    "他们可能就是塞斯。"
    scene bg_black with eye_shut
    jump morning
label memori1:
    stop music 
    $ morning = False
    $ afternoon = False
    $ evening = False
    $ night = True
    scene bg_black with eye_shut
    scene altar_b4 with wet
    show side_p he at pic
    mc "伊欧？伊瓦尔？"
    show side_p m
    mc "伊瓦尔，如果这又是你的把戏，我发誓——"
    hide side_p
    play sound "sound/effects/walk.mp3"
    if not girl:
        show palmierproxy chill frown mata at center with dissolve:
            yoffset 100
    else:
        show palmierproxy chill frown mata at center with dissolve:
            yoffset 40
    mc "你是谁？"
    show side_p he at pic 
    mc "什么..."
    show side_p s
    mc "（那是...我自己？）"
    show side_p m
    mc "这是什么把戏？"
    hide side_p
    hide palmierproxy with dissolve
    "就在你接近自己的时候，你的分身直接穿过了你，仿佛你根本不存在一样。"
    show side_p m at pic
    mc "啊？！"
    hide side_p
    if not girl:
        show palmierproxy chill judes mata at center with dissolve:
            yoffset 100
    else:
        show palmierproxy chill judes mata at center with dissolve:
            yoffset 40
    mc tanya "我说你是谁..."
    mc mock cling"...女巫？"
    galleryunlock kor_enter
    show kor_enter with fade:
        xalign 0.5 yalign 1.0
        linear 5.0 xalign 0.5 yalign 0.0
        pause 1.0
        easein 3.0 truecenter zoom 0.5
    play music "MUSIC/MusMus-BGM-112.mp3"
    "你转过身，看到了她，一个黑发女人，全身缠绕着荆棘。"
    "眼睛被浸满鲜血的绷带蒙住。"
    "黑色的、如焦油般的血液从每一处伤口滴落，包括她的手掌，那里被细细的金色荆棘刺穿。"
    "她的伤口很旧，但血液依然新鲜。血河涌入水中，稀释成墨水般的颜色。"
    show side_p s at pic
    mc "不会吧！那是——"
    hide side_p
    kor "科尔。你们的人称我为科尔。"
    show palmierproxy judes -cling at left with move
    hide kor_enter with dissolve
    show kor blud laugh at right with dissolve:
        #yoffset 80
        zoom 0.9
    kor "但如果你愿意，你可以称呼我为——"
    show kor frown
    show Io snek mata kzl at center with dissolve:
        #yoffset 80
        zoom 0.9
    io growl "不！我的女主人，请不要给这个卑劣的罪人您真名的祝福！"
    show palmierproxy kzl shock
    kor bite "伊欧..."
    show palmierproxy judes -shock
    io frusta "原谅我的语气，我的女主人。然而，我并没有允许这个人通过到这个地方。"
    show side_p f at pic
    mc "（伊欧？她的眼睛不一样了。虽然还是很奇怪，但绝对没有她现在的眼睛那么复杂。）"
    show side_p s
    mc "（这是一段回忆吗？）"
    hide side_p
    mc frown tanya "是你的魔法充满了我们的水域吗？"
    kor smile "你能感觉到？我的天，这真是一个罕见的天赋。"
    io growl frusta "孩子，你的存在在这里不受欢迎。你并不渴望死亡，你不应该能够进入我们的神圣领域。"
    mc sad sigh "我跟踪了某人。希瑟。看到她从桥上跳进水里。我知道她有烦恼，但是..."
    show palmierproxy frown shock
    kor laugh "你试图阻止她吗？"
    mc wry -shock "当然，我不想让她死。她有如此大的潜力。也许如果我再努力一点，那么——"
    kor smile "多么崇高的理由啊……可惜是个谎言。"
    mc sad tanya"谎言？"
    show palmierproxy apa shock
    kor "你只是想看看她是否真的会跳下去，不是吗，黑暗之人？当她跳下去却没有浮上来时，你变得好奇了。"
    io kzl sigh "与此同时，我的水域是开放的，所以它把你引到了这里。"
    mc deject mata "……这里有很长一段学生自杀的历史，但从未找到他们的尸体。"
    mc judes sigh "还有传言说我们学校下面有一座坟墓。不用天才也能把这些联系起来。"
    show palmierproxy -sigh
    kor frown "所以你只是看着，而不是去帮助你的朋友？"
    mc mean  "我尊重她的选择。如果她真的死了，那是她想要的。如果她没死，在这里找到了更好的东西，那对她来说也不错。"
    kor smile "真是冷漠。"
    if girl2:
        "你的分身耸了耸肩。这不是第一次有人对[dia]说这些话了。"
    else:
        "你的分身耸了耸肩。这不是第一次有人对[dia2]说这些话了。"
    mc judes frusta "我不太在乎别人。"
    show palmierproxy -frusta
    kor laugh "好吧，至少她在这里会更快乐。"
    "科尔指向其中一个浑浊的水池。"
    "一个长着金色长发的女孩可以看到在水中漂浮，带着泪水微笑。"
    "她的银项链上显示着\'Heather\'的名字，其中的H被严重刮花了。"
    kor smile "在她自己创造的天堂中做梦。"
    mc flirt tanya "那么那个女人就是幻想巫师了？"
    io growl frusta "你不配知道我的名字。"
    kor frown "伊欧，别这样。"
    io kzl sigh"……你可以叫我伊欧，不速之客。暂时如此。"
    play sound "sound/effects/walk.mp3"
    hide Io with dissolve
    kor laugh "说了这么多名字，但没有一个是你的。你叫什么名字，美人？"
    mc sigh "[povname]。[povname] 贝克。"
    kor smile "和那个喜欢在码头唱歌的金发女孩有关系吗？就是那个头发形状像牛角面包的女孩？"
    mc -mata blush smile -sigh "……我的妹妹。"
    show palmierproxy mata judes -blush shock
    kor "哎呀，真温柔。我还以为你不太在乎别人呢。"
    mc deject sigh "她是个例外。"
    mc flirt cling "她永远是我的例外。"
    show palmierproxy frown shock
    kor laugh "你想要什么，小家伙？"
    show palmierproxy -blush -shock
    kor "你来这里不是偶然，这次相遇也不是没有计划的。我能从你的心里看出来。"
    kor smile "尽管它如此灰暗混浊。"
    mc deject "..."
    mc mock mata "我想来这里勾引你。巫师总是会以这样或那样的方式被我的魅力所吸引。"
    show palmierproxy kind
    kor smile "是的，那些心灵被玷污的巫师。但可惜我的黑暗无法穿透进去。"
    kor laugh "和你的很相似。你有一个崇高的理由，小家伙。这我看得出来，但它不会奏效。"
    mc malu "我不知道你在说什么。"
    show palmierproxy frown shock
    kor smile "不，你知道。你认为集结巫师们会有助于结束我们之间的战争。"
    kor "我们和猎人，狼人和吸血鬼，海妖和仙子对抗整个世界……"
    kor frown "你已经集结了不少人了。梅扎，塞斯的混血儿，阿莱斯。阿格里奇双胞胎，我那些叛逆的门徒。"
    kor smile"你一直很忙啊，小家伙。"
    mc deject sigh "是啊，我妹妹总说我在需要的时候可以很有魅力。"
    mc mock cling "但如果我想的话，我也可以很强硬。"
    play sound "sound/effects/api.mp3"
    if not girl:
        show api_io with flashbulb
        galleryunlock api_io
    else:
        show api_cew with flashbulb
        galleryunlock api_cew
    mc "对不起了。"
    "你能感受到[povname]魔法的灼烧。"
    "你不断尖叫，感受着一切的强烈。"
    $ renpy.pause(2.0,hard = True)
    stop music
    scene io_lair_ink with flashbulb
    play sound "sound/effects/walk.mp3"
    show Io snek frown at center with dissolve:
        #yoffset 80
        zoom 0.9
    io "很痛苦，不是吗？"
    stop sound
    show side_p s at pic
    mc "伊欧！"
    hide side_p
    play music "MUSIC/MusMus-BGM-CP05.mp3" fadein 10
    "你抬起头，星光闪烁的眼睛与你的目光相遇。"
    show Io at left with move
    if not girl:
        show palmierproxy chill apa at right with dissolve:
            yoffset 100
    else:
        show palmierproxy chill apa at right with dissolve:
            yoffset 40
    mc sweat tanya"那是什么？"
    show palmierproxy kzl -tanya
    io "一段记忆。科尔和弑神者第一次相遇的记忆。你的分身是个强大的存在。"
    io kzl sigh "如果不是符文腐蚀开始发作，差点就把整个神殿都拆了。"
    io smile -sigh "当然，如果科尔和我决定反击，战斗会更快结束。然而，她坚持要我们采取防守态势。"
    io frown "我认为向你展示你的分身的记忆会是明智之举，这样你就能确切地知道你要复活的是什么样的人。"
    show palmierproxy frown -sweat
    show pboy at horzappear
    menu:
        "一个疯狂的人？":
            hide pboy
            if not kln:
                io sigh"这也是我的第一印象，不过[kamu]随着时间的推移会变得更好。"
            else:
                io sigh"这也是我的第一印象，不过[kamu]随着时间的推移会变得更好。"

        "一个性感的人？":
            hide pboy
            io smile sigh "嗯。如此自恋。至少我知道你不像你的另一个自己那样讨厌自己。"
        "一个高尚的人？":
            hide pboy
            $ main.points += 5
            io smile sigh "哼，已经开始分享[dia]的观点了？嗯，你们几乎是一样的。"
    io frown -sigh "这就是我每晚要给你的东西。一段记忆。"
    io "作为回报，你可以问我问题。关于你的分身、其他巫师、科尔的问题..."
    io smile "我希望这一切最终会对我有利。你会同意拥有我心脏的条件。"
    mc scratch rajuk "那是什么？"
    show palmierproxy chill sweat grit shock
    io frown "谋杀。"
    mc sad -shock "什么？"
    io growl "你的校长，我要他受苦。在我手中受苦。"
    io smile "把他推进我的水中，我会让他在无尽的噩梦中度过余生。"
    mc ow tanya "校长？为什么？"
    show palmierproxy frown shock
    io frown "必须有人为教会的罪行负责。他们为了你们珍贵的墨水榨干了她。"
    io "与科尔所面临的恐怖相比，他的痛苦将是仁慈的。"
    mc side sigh "我不是杀人犯。"
    show palmierproxy frown -sigh
    io "你不是，他不会死。他会睡着。"
    mc panik frusta "在纯粹的痛苦中。"
    mc ow -frusta "如果我不遵从呢？"
    show palmierproxy sad
    io smile "那么至少冻结这些水域，好吗亲爱的？这样就没人能再使用这可怕的王冠了。"
    mc sad tanya "等等，你还会给我你的心脏？"
    play sound "sound/effects/crumple.mp3"
    show palmierproxy sad shock
    if "geng_io" in my_events:
        io smile crack "就像我说的，我快死了，小家伙。"
    else:
        io smile crack "我快死了，小家伙。"
    "恰在此时，伊欧的脸上出现了一道裂缝。仿佛是为了证明她没有说谎。"
    io frown sigh "这双眼睛，犹大之星太强大了——即使对我们纯血来说也是如此。"
    io sad -sigh "一切都是徒劳的。是的，它们让我看到了每一个结果，每一个过去，每一个未来的可能性，但我仍然无法理解..."
    mc rajuk -sweat tanya "理解什么？"
    show palmierproxy frown -tanya
    io frown sigh "为什么科尔会牵起你分身的手。为什么他们在血月下结合。"
    if "diary_read_2" not in my_events:
        mc ow shock "等等，所以与[povname]结合的巫师真的是科尔？"
        show palmierproxy sad -shock
        io smile "难以置信，不是吗？"
    io -sigh "她在各方面都比[povname]聪明，但她还是落入了[dia]的掌控之中。"
    io sad frusta "我想也许我们两个人通过你看到这些记忆，能够理解这些事情。"
    io smile sigh "也许那样，我就能得到安宁。"
    mc ow sweat "我明白了。所以这就是为什么你如此温顺。你已经快死了。"
    show palmierproxy sad -sweat
    show pboy at horzappear
    menu:
        "不过，我不会杀任何人！":
            hide pboy
            io "花点时间重新考虑一下。"
        "我现在就必须做出决定吗？":
            hide pboy
            io "不。"
        "放下吧，女人！":
            hide pboy
            mc rajuk frusta "说实话，你不应该就放松下来享受余生吗？如果我是你，我会去完成我的遗愿清单。"
            mc kzl sigh "谋杀并不在我的清单上，所以..."
            show palmierproxy sad -sigh
            io smile cling "我已经活了一千多年。没有什么能压抑我的欲望。"
            io frown sigh "复仇会给我带来平静。"
            mc ow -sigh "你确定吗？"
            show palmierproxy sad
            io smile -sigh "是的。"
    io smile "我再给你三天时间做出选择。"
    io "每个夜晚，我都会带着一段记忆出现在你的梦中。作为回报，每晚你可以问我一个问题。"
    io "如果那时你仍决定不满足我的愿望，那就冻结这片水域，让我随之消亡。"
    io "只有那样，我的心才会在你的触及之内。"
    mc scratch huh "我是说，我也可以等到你死后再偷走你的心。"
    show palmierproxy chill -sweat ow shock
    io smile apa "你会那么做吗？"
    mc scratch ew frusta "...不会。"
    mc confused sweat"（该死，我妈把我教育得太好了！）"
    mc chill ow -frusta "不过...我是说那老头虽然有点种族主义，但还不至于该遭受永恒折磨的程度。"
    mc side "（我想...）"
    show palmierproxy sad 
    io sigh "这是你的选择。"
    mc sad tanya "但是为什么呢？你不能自己把他拉进水里，或者像个威严的水仙女一样跑到岸上吗？"
    io frown -sigh "你可能感觉不到，但这些墙壁上布满了血之符文，将我困在这里。"
    io "我知道解除符文的方法，但需要一个自愿的人类作为祭品。"
    io kzl "科尔的血和我的血都没有效果。我不能强迫我的子民，我不会在他们沉睡时那样利用他们。"
    mc rajuk sigh "我明白了。"
    io frown "当然，选择权在你。就像我给你朋友的选择一样。是活出真实的自己，还是跳入我的怀抱。"
    mc grit shock "所以你真的告诉塞恩去自杀？"
    show palmierproxy kzl -shock
    io smile cling "不，我问他是否想要活出自己的梦想。"
    mc sad sigh "字面意思。"
    io -cling "是的。不过说实话，我怀疑他会接受。"
    io "他说他担心一旦他离开后，你会怎么样。"
    io "他说他想看到这一切的结局。直到你回到你自己的世界。"
    mc wry blush tanya "他真的这么说？"
    show palmierproxy frown -tanya
    io "你有很好的朋友，[povname]。珍惜这份友谊吧。"
    mc malu "嗯。"
    io frown "现在，你还有什么问题要问我吗？"
    show palmierproxy frown
    show pboy at horzappear
    menu:
        "我的选择会有什么后果？":
            hide pboy
            io smile sigh "两种选择都很可怕。各有各的可怕之处。"
            mc sweat huh frusta "哇哦。你本可以说得委婉一点的，你知道吗？"
            show palmierproxy rajuk sigh
            io frown -sigh "我想你不会喜欢谎言。"
            mc apa -sweat tanya "那么，哪个选择更糟糕？"
            show palmierproxy frown -tanya
            io smile "那个不以你的校长落入我的水中为结局的选择。"
            mc panik frusta "嗯，这对你来说很方便，不是吗？哈..."
            show palmierproxy sad sweat sigh


        "你之前称我为勇士。":
            hide pboy
            mc apa tanya "当我们第一次见面时，你称我为意外的勇士，那个会带来你的毁灭的人。"
            mc sad -tanya "这只是意味着你的死亡，还是一切的终结？"
            io smile "这我无法说明，虽然你可能两者都是。这取决于你从现在开始选择的道路。"
            mc huh sweat frusta "哦，太好了。所以是我，我就是问题所在，是我。"
            show palmierproxy -sweat frown -frusta
            io "如果这能给你些安慰的话，你的故事总会有一个美好的结局。问题是对谁来说是美好的。"
            mc apa sweat sigh "又是这些神秘莫测的回答。这真的一点帮助都没有，女士！"
        
        "伊瓦尔真的是你的儿子吗？":
            hide pboy
            io smile "啊是的，他昨晚出人意料地拜访了你..."
            io "他是。虽然我们没有血缘关系。但在最重要的地方，在我心里，他仍是我的儿子。"
            io "他是个善良的人，尽管有些愤世嫉俗。"
            mc judes sweat sigh "他杀人并把他们变成僵尸花。"
            io frown sigh"事情比那更复杂。而且他只杀那些与他作对的人。"
            io -sigh "即使是死亡地带...那也是为了最好的结果。现在结束总比让战争持续造成更多损失要好。"
            io "虽然你可能认为这只是一个内疚母亲的偏见观点。"
            mc apa sweat tanya "内疚的母亲？"
            show palmierproxy sad -tanya
            io kzl frusta "我无法保护他...在最重要的地方。"
            io sad sigh "我辜负了他。"
            show Io sad -sigh
    io frown "天快亮了。我不该再留你在这里了。"
    io smile "暂别了，我带着死亡气息的访客。愿你能做出正确的决定。"
    mc scratch ew frusta "真的有正确的决定吗？"
    show palmierproxy frown -sweat -frusta
    io "...不，只有你必须承担的决定。"
    stop music
    scene bg_black with eye_shut
    pause 1.0
    $ my_events.append("io1")
    scene bed_alter with eye_open
    show side_p m at pic
    play sound "sound/effects/cloth.mp3"
    mc "啊啊！" with vpunch
    hide side_p
    if "nginap" in my_events:
        "你环顾四周，发现塞恩和其他人仍在安睡。"
        show side_p s at pic
        mc "至少他们能睡个好觉。"
        hide side_p
        scene atap with dissolve
        play sound "sound/effects/cloth.mp3"
        "你重新躺下，凝视着天花板。"
        
    else:
        "你又回到了自己的床上。现在仍是午夜。你的脑海里充斥着必须做出的种种选择，令你头晕目眩。"
    show side_p s at pic
    mc "（我不适合当主角，我就不能只谈恋爱过自己的生活吗？）"
    hide side_p
    if not "nginap" in my_events:
        "你深深叹了口气，重新倒回床上，感到疲惫不堪。"
        show buff skul at center with dissolve:
            yoffset 770
        play music "MUSIC/MusMus-BGM-102.mp3"
        buff keluh apa"你还好吗，[povname]？"
        show buff sweat sad -apa
        show side_p f at pic
        mc "啊，嗯。抱歉，我吵醒你了吗？"
        hide side_p
        buff talk -sweat "没关系。我知道你因塞恩的事情承受了很大压力，呃..."
        buff datar "如果你需要放松一下，可以和我一起去钓鱼。"
        buff "我经常在港口附近，如果你需要什么就来找我。"
        show side_p a at pic
        mc "啊，好的，我可能会去。谢谢你，莱尔。"
        hide side_p
        buff wry blush sigh "当然。我只是想帮忙。"
        buff laugh -sigh "晚安，[povname]。"
        show buff datar
        show side_p a at pic
        mc "晚安。"
        hide side_p
        play sound "sound/effects/cloth.mp3"
        hide buff with dissolve
        "莱尔又睡着了。"
    else:
        pass
    show side_p f at pic
    mc "（哈...最好试着休息一下，希望不会再有巫师造访我的梦境。）"
    hide side_p
    scene bg_black with eye_shut
    jump morning


label memori2:
    stop music 
    scene bg_black with eye_shut
    $ morning = False
    $ afternoon = False
    $ evening = False
    $ night = True
    play music "MUSIC/MusMus-BGM-112.mp3"
    scene altar_b4 with wet
    show kor blud laugh at right with dissolve:
        #yoffset 80
        zoom 0.9
    kor "所以你回来了。我没想到你会回来，尤其是在你可怜的失败之后。"
    if girl:
        show palmierproxy chill mata judes at left with dissolve:
            yoffset 40
    else:
        show palmierproxy chill mata judes at left with dissolve:
            yoffset 100
    mc frusta "...为什么你没有反击？"
    kor smile "暴力从来不能解决问题。"
    mc ew sigh "历史证明并非如此。"
    show palmierproxy frown -sigh
    kor frown "我们不是仍在互相交战吗？一个种族杀戮另一个？"
    kor "每天都有数百名精灵、海妖、狼人和吸血鬼被杀。巫师也是，仅仅因为存在和生活。"
    mc kzl "...我知道。这就是为什么我试图改变这一切。这个世界不适合我的妹妹。"
    mc side sigh "我不想有一天发现她死了，只因为一场毫无意义的种族战争。"
    show palmierproxy judes -sigh
    kor smile "然而你仍然寻求力量。"
    kor "如果你真的设法掌握了我的力量，你会用它做什么？"
    mc flirt cling "创立我自己的宗教。一个有我自己制定的规则，他们必须无条件服从的宗教。"
    mk mock -cling "这些规则将使人类和巫师都受益。一个强制和平的宗教。"
    mc mean "我希望它能扩展到吸血鬼和其他种族。在一个统治下的和平。"
    show palmierproxy frown shock
    kor frown "但这不是真正的和平。如果他们不能自主决定，就不是真正的和平。"
    mc judes tanya "这重要吗？"
    kor smile "人类的自主性是宝贵的。你不能简单地下令就期望他们服从。"
    mc flirt cling "哦，但我可以。或者至少在你们巫师的帮助下，我可以。"
    kor frown "你说的是变化巫师塞斯。"
    mc frown -cling "想想看。人类拥有所有的能力，但没有他们自私的欲望或贪婪。"
    mc mean "无思想的东西都在等待命令，一个空虚的容器，没有任何自由意志。"
    kor "他们并不空虚。他们完全意识到自己的需求和周围环境！"
    mc kind "这就是伊欧的作用所在。幻想巫师可以平衡他们的绝望，让他们处于一个永恒的、他们自己选择的梦境中。"
    kor laugh "你对此考虑得很周到。"
    mc flirt "我倾向于计划得太远。我妹妹认为这令人不安。但大部分都是为了她。"
    kor smile "你有一种相当不健康的执念。大多数兄弟姐妹不会像你这样想彼此。"
    mc grit frusta"我没有迷恋她，如果你在暗示这种恶心的事情的话！"
    mc "我永远不会那样玷污她。没有人配得上她。"
    mc side sigh "尤其是我。"
    kor smile "很高兴知道你还有一些道德观念。尽管它可能有些扭曲。"
    kor laugh "现在，告诉我，我在你的宏伟计划中扮演什么角色？"
    mc flirt cling "你是这一切背后的支柱。"
    mc happy -cling "是整个计划的骨干。你的血液赋予了人类魔法。想象一下它能如何增强其他巫师的能力？"
    show palmierproxy frown shock
    kor smile "很有创意...也很疯狂。"
    show palmierproxy judes -shock
    kor frown "我对成为你这样一个天真的、正在崛起的独裁者的一部分毫无兴趣。"
    kor smile "我不会实现你的和平梦想，小家伙。无论你真正的意图多么高尚。"
    kor frown "我曾试图单凭力量来平息我们之间的战争。看看我现在的下场。"
    kor "被囚禁在我自己的学院下，每个毛孔都在流血，我能感觉到荆棘正在压碎我。"
    kor smile "你凭什么认为你能逃脱同样的命运？"
    mc deject "..."
    kor laugh "用爱而不是鲜血来结束这场战争吧，小家伙。"
    mc rajuk sigh"我不理解爱。我没有能力去爱。我有医生开具的证明。"
    kor smile "但你爱你的妹妹。"
    mc judes -sigh"她不一样。"
    kor laugh "...而且你爱阿什姆。就是我看到你和他在一起的那个男孩。我能从你的眼神中看出来。"
    mc side sweat sigh "...我不配得到他的爱。"
    kor smile "确实不配。但你仍然拥有它。"
    kor "也许你能在内心找到对世界展现类似仁慈行为的能力。"
    stop music 
    scene io_lair_ink with flashbulb
    show side_p f at pic
    mc "嗯。"
    hide side_p
    play music "MUSIC/MusMus-BGM-CP05.mp3"
    show Io snek smile crack at left with dissolve:
        #yoffset 80
        zoom 0.9
    if girl:
        show palmierproxy chill apa at right with dissolve:
            yoffset 40
    else:
        show palmierproxy chill apa at right with dissolve:
            yoffset 100
    io apa "你在想什么？"
    show pboy at horzappear
    menu:
        "我真的那么妹控吗？":
            hide pboy
            show palmierproxy confused
            io -apa "你感到尴尬了吗？其实看到这一幕很可爱。"
            io "兄弟姐妹通常不会像这两个人那样如此深爱对方。"
            io "当然，他们仍然会像其他兄弟姐妹一样争吵和打闹，但你能看出他们全心全意地爱着对方。"
            mc malu sigh "确实如此。"
            "你的一部分迫不及待地想要重聚这对兄妹。但你的另一部分却感到嫉妒，因为你知道你永远不会拥有他们所拥有的。"
            "不再是了。"
        "我变得软弱了。":
            hide pboy
            show palmierproxy sad
            io -apa "是啊。但这是装出来的，还是真实的？"
            io frown "这是我永远无法确定的关于你的一点。"
    mc scratch deject sweat tanya "我很高兴我并不是一个彻头彻尾的混蛋。但是，你有关于科尔以及她是如何被困在这里的任何记忆吗？"
    mc confused sigh "我的意思是，我可能需要杀一个人。我需要知道他是否罪有应得。"
    show palmierproxy chill frown -sigh
    io frown "是这样吗？那么明天，我会让你看到你需要看到的东西。"
    show palmierproxy -sweat
    io "在此期间，你还有什么想问我的吗？"
    show pboy at horzappear
    menu:
        "没有了。":
            hide pboy
            $ curiosity -= 60
            mc deject "今晚不问了。"
            io smile apa "终于失去好奇心了？"
            mc ha sweat "有点吧。我只想尽快结束这一切。"
            io frown -apa "嗯。"
        "为什么巫师和人类会战斗？":
            hide pboy
            $ curiosity += 10
            io frown "恐惧。"
            io "人类因为巫师的魔法而恐惧他们。而巫师则害怕人类会对我们做什么，因为我们是少数群体。"
            io "现在更是如此。"
            mc huh sweat tanya "就这样？"
            show palmierproxy frown -tanya
            io smile "恐惧往往是最好的动力。不是因为它的意图，而是因为它的强度。"
            io frown "恐惧，和偏见的仇恨。为什么要同化，当你可以统治？"
            io "对大多数人来说，毁灭并重新创造比找到一个中间立场更容易。"
            io "他们选择不去了解和理解我们，所以他们害怕我们。"
        "那条蛇是怎么回事？":
            hide pboy
            $ curiosity += 5
            io smile cling "他的名字叫阿佩普。"
            io -cling"他是我的使魔，也是塞斯在我们还能相互容忍的时候送给我的礼物。"
            io "他觉得看到一条不死的蛇四处游荡很有趣。它仍有蛇的基本需求，却无法在肋骨里储存食物。"
            mc ew frusta "那太残忍了。"
            show palmierproxy frown -frusta
            io "我知道，所以我给他施了魔法，让他总是感到饱足。塞斯不喜欢我这么做。"
            io smile apa "你想抱抱他吗？"
            show pboy at horzappear
            menu:
                "操，不要！":
                    hide pboy
                    $ honesty += 20
                    $ curiosity -= 15
                    show palmierproxy sad shock
                    play sound "sound/effects/hiss.mp3"
                    "阿佩普朝你发出剧烈的嘶嘶声，似乎被拒绝冒犯了。"
                    stop sound
                    io sad -apa "安静点，阿佩普，这个人类不懂事。"
                    show palmierproxy frown -shock
                "当然好啊！":
                    hide pboy
                    $ kindness += 20
                    show Io no -apa
                    show palmierproxy laugh shock
                    play sound "sound/effects/hiss.mp3"
                    "阿佩普滑到你的肩膀上，即使没有舌头也发出嘶嘶声。"
                    show palmierproxy kind blush bunga
                    "他的头轻轻蹭着你的头，几乎是在亲昵。"
                    show palmierproxy hister
                    io "他喜欢你。"
                    show palmierproxy kind -bunga
                    play sound "sound/effects/cloth.mp3"
                    show Io snek with dissolve
                    "伊欧召唤阿佩普回来，他盘绕在她身上，紧贴着她的曲线。"
    "伊欧转头看向水池。"
    "她推开一个漂得太靠近边缘的男人的身体，那人轻轻地咯咯笑着。"
    mc confused tanya "一旦你离开，这里的人会怎么样？"
    io frown "那取决于你的行动。"
    io "如果你冻结这些水，他们就会随之死去。一种寒冷但平和的死亡。"
    mc side -tanya "如果我把校长推到你的领域呢？"
    io "那么他们将永远沉睡。我确保我的魔法会持续有效。"
    io "但如果失效了，有些人可能会浮回水面，继续他们的生活。"
    mc ow sweat frusta "这安全吗？我是说，我知道你把这些人都置于静止状态，但这些人有多老了？"
    show palmierproxy frown -sweat -frusta
    io "我这里最老的人已经132岁了。他在发现妻子被狼人撕碎后跳了下来。"
    mc huh sweat "该死。"
    io "确实该死。"
    mc pissed frusta "这已经不仅仅是杀死一个人的问题了，对吧？你基本上是让我决定所有这些人的命运！"
    io smile "如果这能给你些安慰的话，没有人比你更适合做出这个决定了。"
    mc ow sigh "这一点帮助都没有！"
    show palmierproxy sad -sweat -sigh
    io frown "也许吧。但至少你知道你是最适合做出这种决定的人。"
    io "我现在要送你回到生者世界了。再见，我带着死亡气息的访客。"
    scene bg_black with eye_shut
    $ my_events.append("io2")
    jump morning

label memori3:
    $ morning = False
    $ afternoon = False
    $ evening = False
    $ night = True
    play music "MUSIC/agnus.mp3"
    scene bg_black with eye_shut
    scene io_lair with wet
    show kor def biasa smile at center with dissolve:
        #yoffset 80
        zoom 0.9
    $ NPC = "牧师"
    npc "万岁科尔，万岁科尔！"
    show side_p f at pic
    mc "这是怎么回事？"
    hide side_p
    "这段记忆与其他的不同，更加古老。石灰岩看起来似乎更干净，水也像你第一次在梦中见到伊欧时那样清澈。"
    "可以看到十位牧师和修女围绕着科尔和伊欧，脸上都带着灿烂的笑容，跪拜崇敬。"
    kor sad "请别这样客气了。我只是尽了作为邻居的责任。"
    $ NPC = "牧师"
    show npc_p at pic
    npc "您救了我们，我的女士！您和伊欧女士。"
    hide npc_p
    show kor at right with move
    show Io snek mata smile at left with dissolve:
        #yoffset 80
        zoom 0.9
    io "我只是在此服侍我的女士。"
    kor frown "伊欧，拜托。"
    $ NPC = "牧师"
    show kor biasa
    show npc_p at pic
    npc "我的女士，我们建造了这个地方来保护您。保护您和伊欧女士，这样其他巫师就不能伤害您了。"
    npc "您背叛了自己的同类，将您的血赐予我们，让我们能够对抗您的同族！"
    npc "请吧，我的女士，赐福我们卑微的存在，成为我们的女王！"
    hide npc_p
    kor sad smile "永远不要说自己低人一等。我们都是平等的。"
    show npc_p at pic
    npc "我的女士，即使是平等的，我们也想拥戴您为我们的女王。成为伊格尼亚和所有子民的统治者！"
    hide npc_p
    kor frown "统治者？不，我不能，你们不是被统治的臣民。请随意地生活吧。"
    show npc_p at pic
    npc "但这就是我们的愿望，我们的女士！让我们美丽的女王随心所欲地统治我们。"
    npc "能保护您，就如您保护了我们一样，这将是我们的荣幸！"
    hide npc_p
    "那个男人将科尔的王冠举到她面前，跪下，科尔犹豫地伸出她纤长的手接近王冠。"
    kor bite"我..."
    io frown "科尔，也许这是最好的选择。这些人类...他们太弱小了，无法自己统治。"
    "伊欧轻声低语，轻轻拉着科尔的手臂。"
    kor smile"……好吧。我会成为你们的女王。"
    show kor_stab with fade
    galleryunlock kor_stab
    "当王冠刚刚被戴在科尔头上时，它突然收紧并变成了一顶细细的金色荆棘冠。"
    "荆棘蠕动着刺穿了她的头骨。"
    play sound "sound/effects/splat.wav"
    kor "啊！啊啊啊啊啊啊！！！！"
    $ NPC = "Io"
    io "科尔！这——这是什么意思？！"
    $ NPC = "牧师"
    npc "完成血之符文！！！"
    $ NPC = "Io"
    io growl "什么？发生了什么？！"
    play sound "sound/effects/shield.mp3" 
    scene io_lair with vpunch
    queue sound "sound/effects/burning.mp3"
    "一道屏障在伊欧和其他人类之间形成，人类们退向出口，而伊欧用魔法猛击屏障。" with vpunch
    play sound "sound/effects/explode.mp3"
    queue sound "sound/effects/api.mp3"
    "炸弹、投射物、火焰、地震和洪水，没有一样能穿透屏障，祭司们趁机逃离。" with hpunch
    show desperate with fade
    galleryunlock desperate
    "科尔躺在地上，痛苦地扭动着，血从她的伤口滴落，从头到脚浸透了她的身体，然后流入她周围的水池中。"
    kor "为什么……为什么？！"
    $ NPC = "牧师"
    npc "您的血是珍贵的，我的女士。它赐予我们神的力量。"
    npc "然而，我们知道最好只相信自己的同类。叛徒永远是叛徒，科尔女士。"
    npc "伊欧的儿子伊瓦尔就是证明。他曾经是我们的神，现在却成了我们的厄运。"
    $ NPC = "Io"
    io "我的儿子只是被误导了，他——"
    $ NPC = "牧师"
    npc "闭嘴！我们不会再被你愚弄了，绝不！"
    kor "但我爱你们！你们所有人——！我为你们背叛了我的族人，承担了你们所有的罪孽！"
    show desperate_up
    show desperate_back behind desperate_up with dissolve
    show desperate_mid behind desperate_up:
        xalign 1.0
    npc "我们感谢您，我的女士，所以现在请您再多承担一些。您的痛苦将成为我们的喜悦，我们的崛起，对抗所有曾经轻视我们的人。"
    play sound "sound/effects/walk.mp3"
    show desperate_mid with dissolve:
        truecenter zoom 1.2
        parallel:
            linear 5.0 xpos 0.0
        parallel:
            yoffset 10
            linear 0.5 yoffset 0
            linear 0.5 yoffset 10
            repeat

    npc "我们会为您祈祷，科尔女士。"
    scene desperate_back2
    play sound "sound/effects/doorslam.mp3"
    npc "为您，也向您祈祷。愿您宽恕我们的罪过。"
    show desperate with dissolve
    kor "不！不要把我们丢在这里！不要啊！！！"
    scene bg_black with wet
    stop sound
    stop music
    play music "MUSIC/heart.mp3"
    scene altar_b4 with wet
    if not girl:
        show palmierproxy chill mata judes at left with dissolve:
            yoffset 100
    else:
        show palmierproxy chill mata judes at left with dissolve:
            yoffset 40
    show kor blud smile at right with dissolve:
        #yoffset 80
        zoom 0.9
    $ mk = Character('[povname]', callback=name_callback, cb_name='mc', image='palmierproxy')
    mk "他们抛弃了你。以最残酷的方式伤害了你……可你还是爱他们？人类？"
    "记忆回到了\'你\'和科尔。我猜科尔向[povname]展示了那段记忆？"
    kor frown "人类是脆弱的。他们那样做是出于恐惧。"
    mk pissed "你真是个多愁善感的人。"
    kor smile "我浑身上下都在流血。"
    mk huh tanya "我该对此笑吗？"
    show palmierproxy frown shock
    kor laugh "你的嘴角抽动了一下。"
    mk malu sigh"……你一定是看错了。伊欧在哪里？"
    kor frown "在附近。恐怕她不太喜欢你。"
    mk judes -sigh "这感觉是相互的。"
    kor smile "为什么你说\'他们\'而不是\'我们\'？你认为自己不是人类吗？"
    mk rajuk sweat "我母亲有时候叫我恶魔。当她生气的时候。"
    mk judes -sweat sigh "巫师们也这么叫我。"
    kor laugh "其他人曾经也叫我恶魔。在我们巫师首次出现的时候。"
    kor "他们说我们继承了恶魔的意志。说我们出卖灵魂才变成现在这样。我绝不会为任何事出卖我的灵魂。"
    kor smile "但是有什么在我体内觉醒了，于是我就变成了现在这样。"
    mk frown mata tanya "恶魔的后裔？"
    kor frown"一个人类，拥有……非凡的天赋。被地狱祝福。管他同意不同意。"
    mk deject -tanya "你不是人类。"
    kor smile"我曾经是。至少以前是。我喜欢认为我现在仍然是。我的朋友们也这么认为。"
    mk grit frusta "什么朋友？伊欧？"
    show palmierproxy confused shock
    kor laugh "还有你。"
    mk deject -shock"..."
    kor smile "你呢？你的朋友们不好奇这几个月你去哪里了吗？"
    mk judes sigh "这不是我第一次失踪了。"
    mk mock -sigh "如果真的发生什么事，他们会翻遍天涯海角来找我。"
    kor laugh "真自信。你一定很信任你的朋友。"
    mk mean cling "不如说我相信自己。我把他们训练得足够好，而且我想讨人喜欢的时候还挺\'讨人喜欢\'的。"
    kor smile "我听说过。我经常听到你的同学们在码头边对你赞不绝口。"
    mk deject sigh "哦，我那些平庸无味的同学？别理他们。他们只不过是一群笨手笨脚的蠢货。"
    kor "说得真刻薄。"
    mk judes -sigh "这就是事实。"
    mk "只要你长得漂亮、聪明或者地位高，在那上面装模作样很容易。"
    mk "只要融入群体，随大流而行。这样做，他们就不会对你另眼相看。"
    mk confused "人类是可以预测的。巫师虽然反复无常，但却坦率直白。"
    mk wry "他们——你们，不介意我某些扭曲的想法。我喜欢你们这种人，喜欢你们那扭曲的道德观。"
    kor frown "嗯，可惜你们中的大多数人并不认同这种看法。"
    mk deject sigh "我从来不理解上面那些人的偏见。"
    mk judes -sigh "你们巫师虽然容易发怒，但除此之外，除非被激怒，你们并不会真的发作。"
    kor "然而你们仍然猎杀我们。"
    mk frown "只有在他们应得的时候。如果他们杀了人，那我还是得尽我的职责。我虽然冷漠反社会，但我有自己的道德准则。"
    mk rajuk "这也要看他们杀的是谁。如果他们杀的是随便什么人，那当然要追究。但如果是强奸犯、恋童癖或杀人犯，那么……我能帮上什么忙呢？"
    mk judes sigh "人类和你们一样情绪化。唯一的区别是他们的自私。人类渴望证明自己的\'价值\'。"
    mk deject -sigh "他们不顾他人，只想在世界上留下自己的印记，真是些自负的蠢货。"
    kor laugh "难道这不正是让你们如此有趣的地方吗？你们的野心和缺陷？"
    mk frown "不。人类的自主性是一种诅咒。他们就像一群需要被圈养的同类相食的羊。"
    kor smile "你认为自己是合适的牧羊人吗？"
    mk deject sigh "不。我从未说过必须在我的统治下。"
    mk frown -sigh "如果吸血鬼能够以一种法则统治世界，那就这样吧。只要能带来和平。"
    kor laugh "哼。你知道吗，你真是个悲观的孩子。"
    mk mock cling "我知道。别担心，我不会向大多数人展示我这一面，只有我妹妹知道。"
    mk kind -cling "现在你也知道了。"
    kor smile "告诉我为什么，小家伙。"
    mk deject sigh "因为，尽管你心软，但我能感受到这一切的真诚。我感到...被爱。"
    mk side sweat frusta "而且我不...我不认为我能操纵你。你不应该受到那样的对待，尤其是在你经历了这么多之后。"
    kor "同理心。"
    mk grit -frusta "同理心？我...我不喜欢这种感觉，我——"
    "[povname]的眼中开始涌出泪水。这泪水似乎连[kamu]都没有预料到。"
    mk ow "我在哭吗？为你哭？"
    play sound "sound/effects/cloth.mp3"
    show kor at center with move
    kor laugh "过来，小家伙。我相信你终于长出了一颗心。"
    stop music
    scene bg_black with wet
    scene io_lair_ink with flashbulb
    play music "MUSIC/MusMus-BGM-CP05.mp3"
    if girl:
        show palmierproxy chill sad sigh at right with dissolve:
            xzoom -1.0
            yoffset 40
    else:
        show palmierproxy chill sad sigh at right with dissolve:
            yoffset 100
    show Io snek crack frown at left with dissolve:
        #yoffset 80
        zoom 0.9
    $ NPC = "Io"
    io "我仍然怀疑你的真诚。我是说另一个你。"
    show pboy at horzappear
    menu:
        "你的眼睛告诉你什么？":
            hide pboy
            if "palmi_flag" in my_events:
                $ my_events.remove("palmi_flag")
            io "[kamu]是出于好意，然而..."
            mc confused tanya"你不相信吗？"
        "我认为我是真诚的。":
            hide pboy
            io "也许吧。"
            $ my_events.append("palmi_flag")
            
        "有点可疑。":
            hide pboy
            if "palmi_flag" in my_events:
                $ my_events.remove("palmi_flag")
            mc huh frusta"我觉得有点可疑。"
            mc confused tanya "那时他们认识多久了？"
            io "几个月。我不能用每一段记忆来烦你。只有重要的那些。"
    
    io frown frusta "另一个你真是个奇怪的人。"
    io "太多的二元性。善意的初衷，残酷的执行。"
    io "我的眼睛无法分辨真实的意图，因为你的另一个自我确实相信[kamu]并无恶意。"
    io "也许你的朋友们会对此有更多见解。能为你的另一个自我提供一些洞察。"
    play sound "sound/effects/crumple.mp3"
    show palmierproxy shock
    io shatter kzl -frusta"*咳嗽...*咳嗽..." with vpunch
    mc ow tanya "你还好吗？"
    show palmierproxy sad -tanya
    io smile sigh "我很好，对一个垂死的女人来说已经很好了。结束即将来临。明天你就必须做出决定了。"
    io "我唯一的愿望是你不会后悔自己的选择。"
    mc ew sweat frusta "嗯，我希望我能更了解自己。在这一切中\'我\'到底在想什么。"
    mc sad -sweat sigh "我现在明白你为什么想让校长离开了。"
    mc frown -sigh "我知道这件事发生在他上任之前，但他仍然没有采取任何行动来纠正它。"
    mc pissed frusta "他们对科尔所做的事...真是卑鄙。"
    io sad -sigh "我知道。然而科尔还是原谅了他们。她就是这么坚强。"
    io "比我能做到的要坚强得多。"
    mc frown tanya "嘿，我能问你点事吗？"
    io frown "什么事？"
    if "curses" in topics:
        mc confused -tanya "你的眼睛是三个黑暗诅咒符文之一，对吧？"
        mc "另外两个符文有什么作用？"
        io smile "塞勒姆之眼让你能窥探人们的思想。"
        io "你可以看到他们在想什么，而不是听到。"
        io "它还让你能窥视他们的日常生活。"
        mc apa tanya "它和你的诅咒有什么不同？"
        show palmierproxy frown -tanya
        io frown"塞勒姆之眼的目的是侵犯他人的隐私。它们无法像犹大之星那样预测未来或看到每种可能性。"
        io "与此同时，赫卡特之蔷薇是一个不稳定的符文。据说，它能让你超越肉体形态而存在。"
        io "只要用你的血在别处刻下符文，你就可以将意识转移到其中。"
        io "一些巫师认为他们可以通过这个符文永生。"
        io "然而它相当反复无常。成功率很低，而且用处不大，因为你无法将它刻在另一个身体上。"
        io "你只能将它刻在自己的器官上或无生命的物体上。"
        io kzl frusta "塞斯过去常在低级巫师身上做实验，强迫他的门徒在自己的手上刻下符文。"
        io sigh"然后再切下他们的四肢，连接到另一具身体上，看看符文是否能继续发挥作用。"
        mc rajuk "成功了吗？"  
        show palmierproxy frown
        io frown -sigh "确实成功了。然而，他们会永远处于痛苦中，因为无法理解自己是谁。"
        io "一个身体里有两个意识。他们会争夺控制权，通常最后都会死亡，不是这种方式就是那种方式。"
        io "要么死于塞斯之手，要么死于自己的绝望。"
        mc sweat kzl "哎呀。听起来塞斯有些问题啊。"
        io kzl "确实如此。科尔恨他。他不过是个孩子气的男人，一直在寻找下一种虐待狂式的娱乐方式。"
        mc frown -sweat "塞斯现在在哪里？"
      
    else:
        mc sad tanya "你和科尔到底是什么关系？"
        io smile "也许是姐妹？或者是柏拉图式的伴侣？谁知道呢。"
        io "科尔和我是少数几个喜欢人类的巫师。我们因此在几个世纪里建立了深厚的感情。"
        io frown "当伊瓦尔进入我的生活时，我们确实有一段时间疏远了。"
        io "尽管如此，我们还是像抚养自己的孩子一样抚养了他。虽然最后，他和我也同样疏远了。"
        mc frown -tanya "我明白了。所以你们是一对。"
        io "生活伴侣，但我不会说我们是一对。我们从未结合。"
        io "也许这就是为什么我对她的背叛如此耿耿于怀。"
        io "我在她身边度过了几个世纪，然而结合的想法从未在她脑海中出现过。"
        io "可是一个年轻的少年却设法说服了她。"
        io "我确实把她的行为放在心上。我以为这双被诅咒的眼睛能帮我理解她。"
        io "但它只让我比以前更加困惑。"
        mc confused "你真的能用那双眼睛看到一切吗？"
        io "一切，甚至包括可能不会发生的事。"
        mc frown "那你能告诉我塞斯在哪里吗？"
    mc "他可能是我的下一个目标。"
    io frown apa "是他，不是伊瓦尔？"
    mc side sweat sigh "我不忍心问你关于伊瓦尔的事。"
    mc ow frusta "我是说，我在试图杀死他，某种程度上。而且他是你的儿子..."
    "伊欧的嘴角浮现出一丝淡淡的微笑。"
    io smile -apa"这就是你的仁慈吗？我该感谢你吗？"
    mc panik sigh "我宁愿你不要这么做。"
    show palmierproxy frown -sweat shock
    io frown "嗯。不过很遗憾，我不确定你能在哪里找到塞斯。"
    show palmierproxy sad -frown -shock
    io "这双眼睛能看到你生命中每一个可能的结果。"
    io "目前有650,386种你与塞斯相遇的场景。"
    io "每种可能性都差不多。没有哪一种占据绝对优势。"
    io "不过我可以说，在每种场景中，你战胜他的几率是20%%。"
    mc huh sweat "只有20%%吗？？？"
    show palmierproxy kzl 
    io kzl sigh "他很凶残，小家伙。而且他不像梅扎和伊瓦尔那样容易被闲聊或漂亮脸蛋所动摇。"
    io sad -sigh "当你遇到他时，你终于会与一个纯血统的巫师进行一场正式的战斗。"
    io "我希望你为此做好准备。"
    io frown "现在请原谅我，我想我该休息了。"
    io smile "直到我们最后一次见面，我带着死亡气息的访客。晚安。"
    mc wry -sweat "...晚安。"
    stop music
    scene bg_black with eye_shut
    $ my_events.append("io3")
    $ NPC = "???"
    jump morning

label memori4: #4 June Sunday
    scene bg_black with eye_shut
    $ morning = False
    $ afternoon = False
    $ evening = False
    $ night = True
    play music "MUSIC/heart.mp3"
    scene altar_b4 with wet
    show kor blud bite at right with dissolve:
        #yoffset 80
        zoom 0.9
    kor "啊啊...啊。"
    if girl:
        show palmierproxy chill mata ow at left with dissolve:
            yoffset 40
    else:
        show palmierproxy chill mata ow at left with dissolve:
            yoffset 100
    mc sweat "拜托，科尔夫人。就接受我的提议吧。你不必继续这样生活！"
    kor "不。我还是...唉，你不知道你在要求什么，小家伙！"
    mc sad "看起来你当初也不知道。这就是你试图拯救人类时所设想的吗？！"
    kor "成为\'神\'总是要付出代价的。虽然我承认，呃，这不是我预想中的代价。"
    mc ew sigh "你对人类想得太好了。"
    kor laugh "哼。你开始听起来像伊瓦尔了。"
    kor frown "他也警告过我不要走这条路。然而，我没有理会他，以为他是因为过去的经历而有偏见。"
    mc confused tanya "伊瓦尔？"
    kor smile "美丽巫师。"
    mc frown -sweat -mata shock "你是说厌男症伊瓦尔。"
    kor laugh "这个名字真不合适。你知道他以前被称为丰饶之巫吗？"
    kor smile "我更喜欢那个名字。"
    mc pissed mata frusta "是啊，不过他现在的名字似乎很适合他。"
    kor frown "只有无知的人才这么认为。他并不是讨厌男人，他只是谨慎。而且有充分的理由。"
    mc kzl sigh "他在死亡地带战争中毁灭了两个国家，还把男人变成了会走路的花束。这算什么合理的理由？"
    kor "一个痛苦而情感化的理由。请不要这样责怪伊瓦尔。"
    kor "...在他还是个孩子的时候，他曾经只需打个响指就能消除饥荒。为需要的人种出各种水果和蔬菜。"
    kor "人们很感激，建立神庙和荣誉雕像来崇拜他。一切都很好，但可悲的是...伊瓦尔太美了。"
    mc confused -sigh "美不是好事吗？"
    kor bite "不是当它让人发疯的时候。"
    kor "不是当它导致人们玷污他的时候。"
    mc sad "玷污他？"
    kor frown "那些男人被他的美貌迷惑了。他们做了一些事。一些我宁愿不说的事。"
    kor bite"当我和伊欧找到他时...已经太晚了。在他的恳求落在聋耳上之后，他终于受够了，制作了他的第一束花。"
    kor frown "随着他的成长，他对男人的厌恶慢慢痊愈，尤其是在他的儿子出生之后。"
    kor "但这种幸福是短暂的，因为他的儿子成年后也被伊瓦尔的美貌所迷惑。"
    kor "就在那时，伊瓦尔发现了他的诅咒。男人总是会无法抗拒他，即使是他自己的骨肉。"
    kor "慢慢地，他们会对他着迷，被欲望驱使得发疯。"
    kor "他们就是无法控制自己，这是他的魅力。即使使用最强大的幻灭咒语，远走他乡..."
    kor "他们仍然能找到他，伊瓦尔不得不再次经历抵抗自己儿子们的恐怖。"
    kor "那时他知道他必须做出选择。要么杀死自己的儿子们，要么把他们变成自己的不朽奴隶。"
    kor "他选择了后者。"
    mc ew tanya "为什么？"
    kor smile "因为这就是他爱的方式。他无法忍心杀死自己的亲人，但他也无法和他们在一起。"
    mc kzl frusta "而拥有一个无头的娃娃是他的妥协？"
    kor "正如我所说，伊瓦尔是个难以理解的人。"
    kor laugh "如果他选择完全不要孩子会更容易。但伊瓦尔...爱着爱情。"
    kor smile "他想要一个属于自己的家庭，一个可以拥抱的妻子，一个可以送上婚礼祭坛的女儿，一个可以培养成男子汉的儿子。"
    kor frown "...即使他们在这件事上没有选择权。"
    kor "他做的每件事都有理由。即使是死亡地带战争，伊欧听说那更多是你们人类所为，而不是他的错。"
    kor "在他们用他女儿的头颅嘲弄他之后，伊瓦尔只是想要战争停止。"
    kor "他可能做得过分了，决定杀死该地区的所有非巫师，但你不能说他没有完成任务。"
    mc sad sigh "那么，你呢？"
    kor "等我？"
    mc side -sigh"你教人类魔法，让他们能够抵御巫师。这确实是个崇高的理由。"
    mc pissed frusta "但现在那些人类把你困在这里，只为了像挤奶牛一样榨取你的墨水。"
    mc sad -frusta "如果你能原谅伊瓦尔过去的杀戮狂潮，难道不应该也让自己做同样的事吗？"
    mc ow "他们背叛了你的信任，你以牙还牙也是公平的。"
    show palmierproxy sad
    kor bite "...我不像伊瓦尔。我看到每个人身上的善意。我承认人有改变的能力，我不像他那样怀恨在心，我——"
    mc kzl sigh "你不是神，科尔。你只是被描绘成神而已。"
    mc judes -sigh "你也不是救世主，你只是一个美化了的牺牲品。别再拯救别人了，换个方式拯救自己吧。让自己快乐起来。"
    kor smile "小家伙，你什么时候开始关心我的幸福了？你不是只对我的力量感兴趣吗？"
    mc ew frusta "我确实是，但现在不仅仅是这样了。在这里和你交谈，听你讲述你的故事..."
    mc sad -frusta "...我不相信因果报应，也不相信好人一定有好报，但是肯定..."
    mc ow "你肯定应该得到更好的！我可以帮你获得自由，血月下有一个结合仪式可以——！"
    kor frown "更好？你真的认为把自己与你结合是更好的选择吗？放弃我的肉体，成为你的影子直到时间的尽头？"
    mc kzl frusta "好吧，至少你不会永远被困在这个潮湿的监狱里。来吧，跟我走，科尔！"
    mc sad sigh "让我们结合吧。这时候我甚至不会使用你的力量。只是...只是让我帮助你，拜托了。"
    kor "...我会考虑的。"
    scene io_altar_ink with flashbulb
    show Io no frown shatter at left with dissolve:
        #yoffset 80
        zoom 0.9
    io sad "几天后，科尔进行了结合。就在这里...在血红色月亮的注视下。"
    play music "MUSIC/PerituneMaterial_Piano_Sad2.mp3"
    "伊欧凝视着祭坛附近的天窗，她的眼睛看起来比平常更暗淡。"
    play sound "sound/effects/crumple.mp3"
    io devas"然后他们把我留在这里，孤...孤单一人。"
    if girl:
        show palmierproxy jln side at right with dissolve:
            yoffset 40
    else:
        show palmierproxy jln side at right with dissolve:
            yoffset 100
    mc "伊欧..."
    io growl frusta "是[dia]的自私影响了科尔吗？还是[dia]的花言巧语？或许是[dia]的年轻？"
    io sad sigh "为什么...为什么她要离开我？"
    "泪水从她的眼中落下，那泪水像星尘一样，滴落进她漆黑的裂缝中。"
    mc ow sweat frusta "伊欧——"
    $ my_events.append("io4")
    if "diary_read_2" not in my_events:
        "你的头脑一片混乱。另一个你，与科尔结合，这个世界的\'神\'。"
        
    else:
        "你知道这一点，[povname]的日记清楚地表明他们结合了，但是..."
        "...读到它和亲眼见证它的真实性是两回事。"
    "科尔离开这个地方，让伊格尼亚陷入墨水短缺的困境。伊欧被独自留下...[povname]陷入昏迷。"
    "一个选择导致了如此多的绝望。这一切太难以接受，以至于你几乎无法做出反应。"
    "你能说什么呢？你愿意付出一切来安慰伊欧...但她想要拥抱的不是你的言语或触摸。"
    show palmierproxy sad -frusta
    io frown shock "啊，我很抱歉。现在这已经不重要了。那都是过去的事了。"
    io smile -shock "现在重要的是未来。你做出决定了吗？"
    io "记住，一旦你做出选择，你就必须躺在你铺好的床上，正面迎接你的决定。"
    io "从这一刻起，一切都将改变。那么，小家伙，你的选择是什么？"
    show pboy s at horzappear
    menu:
        "我会推校长。":
            hide pboy
            io smile "那我就缩短这个梦境吧。"
            io "请把他推进我的水中。别担心，他不会死的。我会确保这一点。"
            mc side sweat "我是否必须杀死你才能得到你的心脏，或者...我不知道，帮助你？"
            show palmierproxy sad 
            io frown "不。这是我要完成的复仇。你只需要看着就行了。"
            io "一旦他进入我的水中，我的心脏就会升到你的手掌中。"
            mc ow "然后你就会死去。"
            io smile "然后我就会死去，但我的遗产会永远与我的人民同在。永远存在于他们的梦中。"
            mc sad -sweat sigh "这确实是一种看待它的方式。在你死之前，你还有什么想让我为你做的吗？"
            io "你已经做得够多了。不过，如果你能安慰我的儿子，我会很感激的。"
            io "伊瓦尔会比他表现出来的更加伤心。你知道吗，他喜欢你。"
            io frown "我担心我的儿子没有多少朋友可以寻求安慰。"
            mc huh -sigh "哦，我真不知道为什么。"
            show palmierproxy wry
            io smile "呵呵。他也喜欢你的这种讽刺。即使他口头上说不是。"
            io "再见了，我亲爱的带着死亡气息的访客。你是，也永远会是，我最喜欢的人类。"
            play sound "sound/effects/bump.mp3"
            show palmierproxy ow sweat shock with vpunch
            "伊欧轻轻一推，把你推入水中，将你从梦中惊醒。"
            stop music
            play sound "sound/effects/splash.wav"
            scene bg_black with rain1
            scene bed_pagi with eye_open
            play sound "sound/effects/cloth.mp3"
            $ calendar.next() #5th June, mon
            $ night = False
            $ evening = False
            $ afternoon = False
            $ morning = True
            show side_p s at pic
            mc "啊啊！"
            hide side_p
            play sound "sound/effects/tile.mp3"
            "你一刻也不耽误，立即跑到其他男孩的房间——告诉他们你的决定。"
            stop sound
            jump ritual_end
        "我要冻结湖面。":
            hide pboy
            io sad "...可惜。但值得尊重。"
            io smile"给。"
            $ my_events.append("ice_rune")
            "伊欧将手指浸入墨水般的水中，在你的手掌上画了一个符文。"
            mc apa sweat tanya "这是什么？"
            show palmierproxy frown -sweat -tanya
            io frown"一个冰符文。比洛基之霜还要强大。"
            io "你的朋友，那个英克威尔家的男孩，应该有足够的天赋来施展它。"
            mc confused "我不能施展它吗？"
            show palmierproxy ow sweat shock
            io smile "除非你想失去一条手臂。"
            show palmierproxy sad -sweat -shock
            io "你的体质和这里的其他人类不一样。"
            io "让那个张扬的家伙来施展这个吧。"
            io "这会很...有趣。"
            mc side sweat sigh "你的死亡和这里所有其他人的死亡都会很有趣？"
            io "死亡只是另一场伟大的冒险。"
            mc rajuk frusta "不，不是这样的。在我冻结湖面之前这些人能醒来吗？我不能杀了他们，伊欧！"
            mc ew sigh "我真的不能..."
            stop music
            io frown "...很好。"
            mc frown -sweat shock"啊？"
            stop music
            play sound "sound/effects/glass.wav"
            show hati_io with flashbulb
            galleryunlock hati_io
            "伊欧用力一拉，取出了她的心脏。她的胸腔裂开，露出了一颗与梅扎的相似的宝石。"
            io "拿着它..."
            show side_p k at pic
            mc "伊欧？！"
            hide side_p
            play sound "sound/effects/crash.mp3"
            play music "sound/effects/wind.mp3"
            scene death_io with flashbulb
            galleryunlock death_io
            "伊欧倒在地上，她的身体像梅扎一样裂成两半。她的身体碎成了黑色大理石的碎片。"
            "随着她的身体不断碎裂，越来越多的小水母从缝隙中涌出。"
            io "我本想和我的子民一起死去。但我知道你太善良了，做不到这一点。"
            io "我已经解除了对下面水域的魔法。一旦这个梦结束，他们就应该醒来并浮到水面上。"
            mc "等等，伊欧，这不是我想要的，嘿——！"
            io "你是个善良的灵魂，小家伙。我希望你已经准备好面对善良带来的后果。"
            mc "伊欧？伊欧？！"
            scene io_altar_ink with fade
            play sound "sound/effects/crumble.mp3"
            "伊欧无力地抚摸了一下你的脸颊，然后她的手垂落在一旁，身体的残骸化为尘土。"
            "当你看到她的灰烬在空中旋转时，你不禁感到自己刚刚犯下了一个不可原谅的罪行。"
            stop music
            scene bg_black with eye_shut
            "杀死一位神的罪行。"
            play sound "sound/effects/cloth.mp3"
            scene bed_pagi with eye_open
            $ calendar.next() #5th June, mon
            $ night = False
            $ evening = False
            $ afternoon = False
            $ morning = True
            show side_p m at pic
            mc "伊欧？！" with vpunch
            hide side_p
            "你大叫一声醒来，浑身被汗水浸透。"
            if girl:
                galleryunlock tangan_hati_f
                show tangan_hati_f with dissolve
            else:
                galleryunlock tangan_hati_m
                show tangan_hati_m with dissolve
            play sound "sound/effects/jelly.mp3"
            "你看着自己的手，发现梦中那颗明亮的绿色宝石就在那里。"
            show side_p s at pic
            mc "伊欧..."
            hide side_p
            play sound "sound/effects/cloth.mp3"
            "你用手指紧紧握住宝石，泪水顺着脸颊流下。"
            "你感到的是内疚吗？还是失去伙伴的感觉？也许两者都有。"
            play sound "sound/effects/knock.mp3"
            scene kmr_pagi with dissolve
            show side_q skul kzl at pic
            quil "[povname]！莱尔！快开门！"
            hide side_q
            play sound "sound/effects/unlock.mp3"
            show buff eh sweat shock at right with moveinright:
                yoffset 770
            if girl:
                show palmierproxy sad at center with dissolve:
                    yoffset 40
            else:
                show palmierproxy apa at center with dissolve:
                    yoffset 100
            show quil skul kzl sweat at left with moveinleft:
                yoffset 200
            buff -shock"奎尔先生？！"
            quil ow "湖里有人在漂浮！"
            show buff scold shock
            mc ow sweat shock "该死！"
            play sound "sound/effects/tile.mp3"
            jump lake_end

label lake_end:
    scene bg_black with w20
    scene lake with w20
    stop sound
    play music "MUSIC/MusMus-BGM-075.mp3"
    "学生们围在湖边，数百人开始从湖底浮出水面。"
    "有些人在老师的搀扶下咳出水来，挣扎着想要上岸。"
    $ NPC = "奇怪的人"
    npc "这是什么地方？现在是哪一年？！"
    show hm scowl at center with dissolve:
        xzoom -1.0
        yoffset 190
    hm frusta "请冷静下来，先生。"
    $ NPC = "渔夫"
    npc "你手里那些方方的东西是什么？巫术！巫术！"
    "其他人也可以看到对着学生们大声尖叫，并打掉他们的手机。"
    $ NPC = "学生"
    npc "不，不，不！我想回去睡觉，让我回去睡觉！"
    hide hm with dissolve
    "而有些人似乎更意识到自己处于梦境状态。"
    "值得注意的是，大多数湖中居民穿着与你相似的制服。"
    "只是颜色更深的蓝色，看起来明显更加过时。"
    show quil skul frown at center with dissolve:
        yoffset 200
    show tom hip kzl at right with dissolve:
        yoffset 190
    show red chin sad at left with dissolve:
        yoffset 330
    quil rajuk sigh "那么亲爱的，这就是你要坦白的地方，还是我们得从你嘴里撬出来？"
    show side_p s at pic
    mc "你为什么这么确定我和这件事有关？"
    hide side_p
    tom scold ha blow "首先，你脸上刻着的罪恶感。"
    red wry "听着，伙计，不管是什么，我们不会怪你，但我们需要知道这到底是怎么回事。"
    "你把奎尔拉到一边，阿什姆和塞恩都挡在你们前面。"
    show quil frown shock
    show tom eh shock
    show red kaget shock
    show side_p s at pic
    mc "我...我请求艾欧重新考虑，她给了我她的心，但湖里的人现在都醒了。"
    show tom sad -shock
    hide side_p
    show quil sad -shock
    red point sad sigh "这就解释了混乱的原因。"
    show tom capek frusta
    $ NPC = "奇怪的人"
    scene lake with dissolve
    npc "我亲爱的朋友，你能告诉我渔村在哪里吗？我儿子在等我。"
    show priest kzl at center with dissolve:
        yoffset 200
    dog evil apa "先生，您能告诉我现在是哪一年吗？"
    show priest kzl shock
    npc "为什么，现在是1940年。你问这个问题很奇怪。"
    dog pissed frusta "哈...今晚的文书工作会很可怕。"
    show priest kzl at right with move
    show hm scowl at left with moveinleft:
        xzoom -1.0
        yoffset 190
    dog sad sigh "我们该怎么办，先生？"
    hm yell sigh "我需要向教会报告这件事。如果这里的人真的是他们认为的那些人，那么..."
    hm scowl -sigh"...迪特里希，尽可能多地储备墨水。"
    dog ramah apa "抱歉？我很乐意这么做，但我不确定我是否有能力进行这样的努力。"
    show priest pissed shock
    hm yell sigh "别装了。我知道你的副业，你和那些可疑人士的关系。"
    show priest side -shock
    hm scowl -sigh "我是在告诉你利用那些非法关系，囤积所有你能找到的墨水。"
    dog sad apa "先生，到底发生了什么？"
    hm confused sigh "一个时代的终结，迪特里希。一个时代的终结。"
    play sound "sound/effects/walk.mp3"
    scene lake with dissolve
    "说完，威廉校长穿过人群大步走去。"
    stop sound
    "他的手杖在鹅卵石地面上发出响亮的敲击声，他尽力朝学校大门冲去。"
    show quil skul frown at center with dissolve:
        yoffset 200
    show tom hip kzl at right with dissolve:
        yoffset 190
    show red sad at left with dissolve:
        yoffset 330
    tom sigh blow "他可能是去向教会报告艾欧的死讯。"
    show tom sad sweat -blow
    quil tantrum sigh "还有有人发现了教会的秘密这件事。"
    show quil -sigh
    red ngeles sweat apa "这不是很糟糕吗？真的很糟糕？我们不应该尽快藏起艾欧的心脏吗？"
    show red sad 
    show side_p f at pic
    mc "我也是这么想的。来吧，让我们把它放进[povname]身体里！"
    hide side_p
    stop music
    play sound "sound/effects/walk.mp3"
    jump second_heart
label ritual_end:
    scene bg_black with w20
    play music "MUSIC/MusMus-BGM-136.mp3"
    scene jmbtn with w20
    show quil skul frown at right with dissolve:
        yoffset 200
    show tom chill frown at center with dissolve:
        yoffset 190
    show red wry at left with dissolve:
        yoffset 330
    quil wry sigh "终于到了这一步。"
    show tom sigh blow
    quil flashy wink cling "我们终于要以友谊的名义谋杀某人了。"
    red chin both hister "从好的方面来看，至少我们知道我们的友谊能经得起时间的考验。"
    show red point wry -both
    tom amused cling "是的。没有什么比谋杀更能巩固友谊了，不是吗？"
    show tom pfft -cling
    show side_p s at pic
    mc "我分不清你们是在说实话还是在讽刺。"
    hide side_p
    quil heh sigh "哦不，亲爱的，我们完全投入其中。什么样的友谊会因为仅仅夺走一条生命就破裂呢？"
    quil skul laugh bunga "亲爱的，如果你还没找到愿意为你杀人的人，那就是你的问题了！"
    show tom calm
    show red grin 
    "大家同时点头，你不知道自己是警惕还是嫉妒他们之间的联系。"
    tom ejek cling "最好的朋友是那些愿意为你焚烧世界的人，而不是试图和你讲道理的人。"
    show quil sly
    show red mock
    show tom pfft -cling
    show side_p s at pic
    mc "同意不同意见。另外，你们能不能别再说谋杀这个词了？我们并不是真的要杀人，只是..."
    hide side_p
    red sayang apa "把他推进水里？"
    quil mock sigh "强迫他在无尽的噩梦中度过整个不朽的生命？"
    tom scold calm "好了，好了。把它想象成我们给这个人应得的提前退休，感谢他所做的所有服务。"
    show quil frown -sigh
    show red sad -apa
    tom hip kzl blow "比如放干一个女人的血并囚禁她数个世纪，更不用说支持非法的海妖狩猎和标本制作。"
    show side_p s at pic
    mc "是啊，这样行。我需要这个，哈..."
    show side_p f
    mc "那么，呃，我们要怎么做呢？"
    hide side_p
    quil talk "很高兴你问了，我已经计划了三种情况，\'直接\'、\'偷偷摸摸\'和\'混乱\'。"
    quil smile cling "你来选吧。"
    show pboy at horzappear
    menu:
        "直接点？":
            hide pboy
            red chin calm "我们可以坦白说找到了伊欧的巢穴，引诱他来和我们谈谈，然后把他推进湖里。"
            tom scold eh "缺点是如果他决定亲自让我们闭嘴。他虽然老了，但我们的校长可是知道如何打架的。"
            show tom ha
            quil hister bloom "就我个人而言，我觉得这可能会很有趣。想象一下整个过程的戏剧性！"
            quil flashy wink cling "如果他反击的话，这就不算谋杀了，可以看作是自卫。"
            show side_p f at pic
            mc "嗯，这倒是一种看法。"
            hide side_p
            show quil skul datar -cling
        "偷偷摸摸？":
            hide pboy
            tom scold frown "在他的晚餐里下药。等他熟睡后，我们就把他拖到湖边，一了百了。"
            show side_p f at pic
            mc "我们怎么进他的房间？"
            hide side_p
            tom amused cling "迪特里希。"
            tom chill smile blow "虽然不便宜，但能搞定这事。"
            show side_p f at pic
            mc "听起来还不错。有什么缺点吗？"
            hide side_p
            quil sulk frusta "嗯，这样就不好玩了，不是吗？"
            quil groan"如果我要谋杀一个不是巫师的人，我希望能有更多的排场。"
            red hister sweat "不过这其实不算真正的谋杀，只是...谋杀的从犯，有这种说法吗？"
            show red wry -sweat
            tom nyesal "我想你要找的词是\'共犯\'。而且不，奎尔，犯罪应该是不引人注目的。"
            tom ha -blow "这不是什么晚餐和表演。"
            quil sulk sigh "但那太无聊了！"
            show quil frown -sigh
        "混乱万岁，宝贝！":
            hide pboy
            quil wink cling "为什么要搞这么多花里胡哨的？"
            quil laugh -cling "我说我们应该好好利用他对海妖的痴迷。"
            quil mock "让我们用渔村里有海妖出没的消息来引诱他，然后在我们航行时把他推进水里。"
            quil err apa "我们可以用那个英俊的木偶师的照片。他叫什么名字来着？"
            tom hip frown "欧文。"
            show side_p f at pic
            mc "所以他是个海妖。"
            hide side_p
            tom ha "我们三个还在争论这个。他有那个长相，但声音不像。"
            red bingung apa "而声音恰恰是定义海妖的唯一特征。如果他没有那种声音，那他就不是真的，兄弟，就这么简单。"
            show red frown -apa
            quil tantrum sigh "我还是觉得他长得太漂亮了，不像人类。我拒绝承认一个普通人能那么迷人！"
            show side_p s at pic
            mc "我们偏题了。我们在这里策划谋杀呢，别再想那些帅哥了！"
            hide side_p
            show quil frown -sigh
    show tom hip frown
    show red frown
    show side_p s at pic
    mc "嗯。不管我们做什么，我只希望他不会受伤。"
    mc "我知道他理应受到惩罚，因为他对科尔的遭遇置之不理，让她受苦，但是——"
    hide side_p
    scene jmbtn with dissolve
    stop music
    if "nina3" in completed_quests:
        play sound "sound/effects/punch.mp3"
        py "[povname]·维卡莫尔·贝克！" with vpunch
        $ fia_events.append("rampage")
        show poppy base fear at center with dissolve:
            zoom 0.9
            xzoom 0.97
        "从波比嘴里听到你的全名只能意味着一件事。"
        "死亡。"
        play music "MUSIC/wrath.mp3"
        "你转过身，看到波比凶狠的目光直指你，而其他教授，包括校长本人，正在一片混乱中追赶她。"
        py hee "你...你！"
        py fear"你就是给我家族带来如此痛苦的人！你毁了我哥哥的生活！"
        if girl:
            show palmierproxy scratch ha sweat at left with moveinleft:
                yoffset 40
        else:
            show palmierproxy scratch ha sweat at left with moveinleft:
                yoffset 100
        mc "严格来说，我只是提供了工具。我并不是给科夫喝下魔药的人！"
        show palmierproxy ew 
        show red ngeles sweat shock at right with moveinright:
            yoffset 330
            xzoom -1.0
        red "等等，你就是科夫被下药事件的幕后黑手？！"
        $ mrh.points -= 20
        if mrh.points < 0:
            $ mrh.points = 0
        mc chill sad frusta "我没想到会这么严重。"
        red growl frusta "你以为会发生什么？！那可是爱情魔药！"
        mc ow frusta "我不思考！我以为我们已经确定这一点了。这双死鱼眼下什么都没发生！"
        hide red
        hide palmierproxy with vpunch
        py hee "闭嘴！你以为我哥哥的心智是你的游戏吗？"
        py fear "我——"
        queue sound "sound/effects/monster_scream.mp3"
        scene wolf with flashbulb:
            truecenter zoom 1.0
            easein 1.0 truecenter zoom 0.67
        py "我要杀了你！"
        "大量围观者排在波比身后。在人群中，教授们正疯狂地朝着那个女孩挤过去。"
        "校长也在其中。他捏响了指关节，仿佛在为一场持久战做准备。"
        hed "波比，别这样！"
        galleryunlock wolf
        hm "冷静点，波比！"
        dog "...我的薪水可不够应付这种破事。"
        queue sound "sound/effects/whip.mp3"
        scene wolf_whip with flashbulb:
            truecenter zoom 0.67
        "黑色的鞭子从校长的指尖冒出，束缚住了狼人。"
        galleryunlock wolf_whip
        "威廉校长扑向波比，伸手抓向她的头，试图用手中的注射器制服她。"
        hm "波比，原谅我，这是为你好！"
        play sound "sound/effects/crumble.mp3"
        show kepsek_fall with vpunch
        galleryunlock kepsek_fall
        "惊慌失措的波比咆哮着将校长甩开，把他扔下了桥。"
        "校长尖叫着落入水中，随后传来一声巨大的水花声。"
        play sound "sound/effects/splash.wav"
        hm "啊啊啊！"
        show side_p s at pic
        mc "好吧，至少解决了一个问题。"
        hide side_p
        play sound "sound/effects/roar.mp3"
        scene wolf with dissolve:
            truecenter zoom 0.67
        show side_t skul kzl at pic
        tom "而这里还有另一个问题正朝我们冲来，小心！"
        hide side_t
        "波比挣脱了束缚，向你冲来。她全速奔跑时，沉重的脚步声在鹅卵石地面上回荡。"
        "奎尔和阿什姆都用符文形成了一道屏障，但它很快就在冲击下破碎了。"
        "他们俩都被推到一边，撞在墙上，而塞恩展开蝙蝠翅膀，把你拉到安全的地方。"
        "波比咆哮着，将她的怒火倾泻在阿什姆和奎尔身上。"
        play sound "sound/effects/growl.mp3"
        "看到你的朋友陷入困境，你..."
        show pboy at horzappear
        menu:
            "使用你的符文":
                hide pboy
                $ kindness -= 5
                "你瞄准波比，希望用一圈火焰困住她。"
                play sound "sound/effects/api.mp3"
                scene wolf_burn with flashbulb:
                    truecenter zoom 0.67
                "紧接着，一道高大的蓝色火墙升起，将波比与阿什姆和奎尔隔开。"
                
            "引诱她！":
                hide pboy
                $ kindness += 5
                show side_p m at pic
                mc "嘿，你想要的是我！来抓我啊，你这只大吉娃娃！"
                hide side_p
                show side_r skul kzl at pic
                play sound "sound/effects/wush.mp3"
                red "你在干什么？！哇哦！" with vpunch
                hide side_r
                play sound "sound/effects/api.mp3"
                scene wolf_burn with flashbulb:
                    truecenter zoom 0.67
                "波比的手向你和塞恩挥来。然而，在她能进一步接近你之前，一道高大的蓝色火墙升起。"
                "阻止她靠近。"
        show side_t skul sad at pic
        galleryunlock wolf_burn
        tom "[povname]，住手！你会再次伤到你的手！"
        hide side_t
        show side_p s at pic
        mc "不是我！"
        hide side_p
        scene jmbtn_rusak with fade
        show hedwin sad at center with dissolve:
            yoffset 200
        "有人比你先施展了符文。看向一旁，你看到海德温女士在她的额头上画了一个火焰符文。"
        play sound "sound/effects/splash.wav"
        "她额头上的符文像蓝色火焰一样明亮，随后变成了一个水球，完全包裹住了正在狼形态挣扎的波比。"
        hed mad "波比。现在停下。想想你其他的家人！"
        hed sad "你真的想让你的兄弟姐妹看到你成为一个杀人犯吗？你的侄子侄女们呢？"
        hed "你知道科普杰的法律在这里不适用。如果你伤害这个学生，我们会杀了你作为惩罚！"
        hed "想想你的母亲！没有父母应该在如此短的时间内埋葬他们的孩子！"
        stop music
        play sound "sound/effects/roar.mp3"
        "伴随着一声巨大的咆哮，波比变回了人形，而水球越变越小..."
        play sound "sound/effects/cloth.mp3"
        "...最后完全蒸发。波比被拖到迪特里希身边，他用她的衣服盖住她的背部以保护她的隐私。"
        play sound "sound/effects/nangis.mp3"
        show poppy base kosong at left with dissolve:
            zoom 0.9
            xzoom 0.97
        py "*抽泣*... *抽泣*。"
        show priest sad at right with dissolve:
            yoffset 200
        "波比蜷缩成一团，啜泣着，让她娇小的身躯被迪特里希的怀抱吞没。"
        py cry "这不公平，[kamu]毁了他的生活。这太不公平了。"
        dog glad sigh "我知道。另外，在我衬衫上哭泣是要付费的。最少10个金币，我刚刚才把它干洗过。"
        stop sound
        "尽管内心绝望，波比却真的笑了出来——迪特里希的回答让她措手不及。"
        py wry "你真是个混蛋，迪特里希。"
        dog wry "我知道。"
        show hedwin wry
        "对波比的微笑感到满意，迪特里希随后转向海德温，后者歪了歪头。"
        dog side apa "海兹，你能搞定吧？你还清醒吗？"
        hed wry sigh "清醒得足够应付。我来处理这事，迪特里希。去让她休息吧。"
        dog sad -apa "{i}睡眠{/i}"
        play sound "sound/effects/shield.mp3"
        scene jmbtn_rusak with flashbulb
        "只说了一个词，波比就陷入了沉睡。当迪特里希站起来抱着她离开时，她的头靠在他的胸前。"
        play sound "sound/effects/cloth.mp3"
        show side_p f at pic
        play music "MUSIC/MusMus-BGM-059.mp3"
        mc "菲拉？"
        hide side_p
        show hedwin konsul sigh at center with dissolve:
            yoffset 200
        hed "是的，相当有用的符文，不是吗？现在，请下来吧，塞恩，[povname]。"
        show red kaget shock at left with moveinleft:
            yoffset 330
        red "哦，对。"
        show red sad sigh
        play sound "sound/effects/wush.mp3"
        "塞恩飞下来，轻轻地把你放回地面，然后将翅膀收回背部。骨头发出响亮的咔嗒声收了回去。"
        show quil sad at right with moveinright:
            yoffset 200
        hed sad apa "阿什姆，奎尔，你们两个没事吧？"
        quil ow sweat frusta "我觉得我的屁股摔断了。"
        show side_t skul sad at pic
        tom "别那么戏精，奎尔。我们没事，几瓶治疗药膏就能解决。"
        hide side_t
        hed wry apa "很好。你呢，[povname]？"
        show side_p s at pic
        mc "我——"
        hide side_p
        play sound "sound/effects/slap.mp3"
        show quil fluster -sweat shock
        show red kaget sweat shock
        "海德温女士扇了你一巴掌。她冰冷的金属手背重重地打在你的脸颊上，你痛得直皱眉。"
        show quil sulk sweat -shock
        show red huh sigh
        hed mad frusta "这是因为你和阿斯莫迪亚胡闹，拆散了一个家庭！"
        show red sad -sigh
        "在你来得及道歉之前，海德温抚摸了你的头顶，并拍掉了你肩上的灰尘。"
        play sound "sound/effects/cloth.mp3"
        hed wry sigh "而这是因为你不得不应付一个本该更懂事的成年狼人。"
        show side_p s at pic
        mc "哦，呃，谢谢？"
        hide side_p
        hed evil apa "这是个问句吗？我想我应该得到一个正式的\'谢谢\'。我刚刚使用了一个符文，尽管我明显缺少所有必要的肢体来做到这一点。"
        show side_p s at pic
        mc "对，谢谢您，海德温女士。我是真心的。另外，说实话，当我把那瓶药水交给尼娜时，我真的没多想，我——"
        hide side_p
        hed sad sigh "你是个白痴，但我们已经确认过这一点了。可能是喝了太多恐怖酒的缘故。"
        hed konsul "亲爱的，你真的需要更好地爱自己。不过我猜这话从我这样的人嘴里说出来有点讽刺。"
        quil bingung apa "海德温女士，我们真诚地为所有的混乱道歉。另外，波比女士会怎么样？"
        show quil sad -sweat -apa
        hed sad frusta "恐怕我们不得不解雇她，并将她遣返回科普耶，因为伊格尼亚对狼人的法律相当明确。"
        hed sigh "除非是出于自卫，否则任何狼人都不允许变形。更糟糕的是，你还是个学生，因此被视为伊格尼亚的孩子。"
        hed -sigh "这意味着你受到教会的保护，不能受到伤害。尤其是来自老师的伤害。"
        hed "尽管阿斯莫迪亚是一种非常有争议的药水，但酿造或销售它并不违法。"
        hed "所以我认为波比仍然是错的，即使她有充分的理由。"
        show pboy at horzappear
        menu :
            "为波比开脱":
                hide pboy
                show side_p s at pic
                mc "我们就不能假装是我先发制人或者别的什么吗？说波比这么做是出于自卫？"
                hide side_p
                hed konsul "你真是太善良了，但你真的相信她下次不会再试图谋杀你吗？"
                hed tantang apa "[povname]，你现在是嗑高了吗？因为哪个神智正常的人会相信他们虚假的善举会被视为善意？"
                show side_p s at pic
                mc "这不是假的。"
                hide side_p
                hed mad sigh "如果你真的善良，你就会无视尼娜的请求。不，这不是善良。这是你试图平息自己的内疚。"
                red grit sweat "哇...海德温女士，这话真伤人。"
                show red huh sigh
                hed wry -sigh "这就是事实。"
            "向波比道歉？":
                hide pboy
                show side_p s at pic
                mc "我至少还能去跟她谈谈吗？道个歉？"
                hide side_p
                quil mock frusta "哦，天真的孩子，你真的认为她现在想见你吗？"
                show quil sulk sigh
                show side_p s at pic
                mc "...不想？"
                hide side_p
                red chin sweat perih frusta "不行，伙计！而且，我可不想再看到那种场面。那些獠牙和爪子实在太吓人了！"
                hed wry "你的朋友们说得对。如果你想道歉，那就离她远点，[povname]。你已经做得够多了。"
        show red frown -sweat shock
        show quil frown -sweat shock
        hed konsul sigh "你们应该回宿舍去。威廉校长和我会处理这件事。"
        hed talk -sigh "我相信他现在正游向岸边。"
        show red huh sigh
        show quil sulk -shock
        show side_t skul frown at pic
        tom "事实上，海德温女士，我好像没看到校长从水里出来。"
        hide side_t
        hed mad shock "...什么？"
        stop music
        scene jmbtn_rusak with fade
        play sound "sound/effects/tile.mp3"
        "海德温女士迅速俯身看向桥下，寻找校长的踪影。当她没有看到任何生命迹象时，她低声咒骂了一句，然后跑回大门。"
        hed "凯普勒，联系教会！我们遇到麻烦了！"
        stop sound
        scene ati0 with dissolve
        play sound "sound/effects/woosh.mp3"
        show ati1
        play music "sound/effects/jelly.mp3"
        show ati_2 behind ati1 with moveinbottom:
            xalign 0.5
            alpha 0.0 yalign 0.0
            easein 5.0 alpha 1.0 yalign 5.0
            easein 1.0 alpha 0.0
            repeat
        show ati_3 behind ati_2 with moveinbottom:
            xalign 0.5
            alpha 0.0 yalign 0.0
            easein 7.0 alpha 1.0 yalign 5.0
            easein 1.0 alpha 0.0
            repeat    
        "海德温女士一离开视线，你就看到两只水母携带着一颗绿色宝石漂浮过来。它们把宝石放在了你的手掌中。"
        if girl:
            show ati1_f with moveinbottom
        else:
            show ati1_m with moveinbottom
        show side_r skul sad at pic
        red "那是——"
        hide side_r
        show side_t skul frown at pic
        tom "巫师之心。"
        hide side_t
        show side_r skul frown at pic
        red "该死。我们得在有人看到那东西之前赶紧去找[povname]。我能听到学生们朝这边跑来的声音。"
        hide side_q

    else:
        $ NPC = "???"
        play sound "sound/effects/punch.mp3"
        if "boner1" in completed_quests:
            npc "[povname]·维卡莫尔·贝克！"
            "当有人用尽全力喊出你的全名，声音中充满了明显的愤怒时，这只能意味着一件事..."
            "死亡。"
            
        else:
            npc "奎尔·英克威尔！"
        play music "MUSIC/wrath.mp3"
        "你看到两个男孩从大门出来，朝你跑来。"
        quil skul bingung apa "伊米尔，...还有西尔根？"
        show quil frown -apa at center with dissolve:
            yoffset 200
        show red point kzl at left with dissolve:
            yoffset 330
        show tom hip kzl at right with dissolve:
            yoffset 190
        red chin awkward sweat apa "哦，该死。他们现在又陷入什么糟糕的三角恋了？"
        show red huh -sweat shock
        $ NPC = "伊米尔"
        if "boner1" in completed_quests:
            show quil err sweat shock
            show tom chill kzl shock
            npc "[povname]，你为什么就不能别管闲事，嗯？！"
            npc "消欲药，认真的吗？！"
            mc "（糟糕，我行为的后果来了！）"
            mc "呃，嘿，别怪传信的人！我只是想赚点快钱而已！"
            npc "毁了我的老二！"
            quil fluster frusta "你做了什么？！"
            show quil tantrum sigh
            show tom sigh blow
            show red growl sweat
            mc "我可能帮他们的前任弄到了一些\'勃起终结者\'，然后给他们下药了？"
            $ NPC = "西尔贡"
            npc "别再无视我们了！"
        elif "bye_boner" in quil_events:
            npc "奎尔，你在那杯饮料里放了什么？我硬不起来了！"
            quil sad sweat apa "啊？你在说什么呀？"
            npc "你告诉我啊。自从你给我那杯橙汁后，我就再也硬不起来了！"
            tom chill ha apa "等等，奎尔，你和伊米尔分享了饮料？"
            npc "是啊，就是那天你和我一起吃早餐的时候。我给伊米尔拿了杯橙汁，怎么了？"
            tom scold sigh blow "嗯，这就解释得通了。"
            tom hip nyesal sweat frusta "我在你的饮料里下了\'勃起终结者\'。"
            quil err sweat shock "你干了什么？！"
            show side_p s at pic
            mc "严格来说这是我的错，我确实有点让他这么做的。这是为了我们的赌约。"
            hide side_p
            quil kzl -sweat frusta "[povname]！"
            $ NPC = "西尔贡"
            npc "别再无视我们了！"
        else:
            npc "你上了我妹妹？！"
            quil err sweat apa "啊？"
            show tom hip ha
            show red sad 
            npc "吉吉！你上了她？！"
            quil panik shock"我没有——哦，等等，是的！"
            show side_p f at pic
            mc "（哦，吉吉不就是他在教堂里聊天的那个女孩的名字吗？）"
            mc "（就是那个想通过\'上\'奎尔来解除婚约的女孩。）"
            hide side_p
            npc "你怎敢夺走她的贞操？你知道我父亲把她许配给卡斯特里了！"
            npc "她的纯洁永远被玷污了！"
            quil mock -sweat sigh "哦，别跟我说什么贞操。你不就是被西尔贡操屁股吗！"
            quil sly cling "你只是因为你家族享受不到她的嫁妆而生气罢了！"
            quil ejek -cling "我是说，大家都知道这里的西尔贡一文不名。"
            quil amused "你为什么不对自己诚实点，接受你是个私生子的事实呢？这对你来说会少些尴尬，亲爱的！"
            $ NPC = "西尔贡"
            npc "够了！"
        play music "sound/effects/twister.mp3" fadeout 2
        scene bridge_koleps_no with flashbulb
        galleryunlock bridge_koleps_no
        show side_q skul kzl at pic
        quil "哇哦！"
        hide side_q
        "西尔贡向你们发射了一道龙卷风，一股巨大的绿色风暴，把你和其他人吹到了桥边。"
        "你拼命抓住栏杆，感觉风力把你往上提，几乎要把你从栏杆上剥离。"
        $ NPC = "伊米尔"
        npc "宝贝，我觉得你可能做得有点过头了！"
        $ NPC = "西尔贡"
        npc "哦糟糕，我没想让它变得那么大！"
        show bridge_koleps with dissolve
        galleryunlock bridge_koleps
        npc "啊啊啊！"
        "当你和你的朋友们努力抓住不放时，你看到西尔贡和伊米尔被风卷起，抛入下方的水中。"
        "然而在西尔贡离开后，龙卷风变得更加猛烈，甚至掀起了一些较轻的杆子和整个桥段。"
        show side_p s at pic
        mc "谁来做点什么啊！！！"
        hide side_p
        quil "怎么做？！如果我们松手使用符文，就会被吞噬而死！"
        scene jmbtn_rusak with flashbulb
        show hm complain sweat at center with dissolve:
            yoffset 190
        hm "坚持住，孩子们！"
        show hm scowl -sweat
        "你看到校长拄着拐杖一瘸一拐地走向桥边。他打了个响指，龙卷风旋转着变成了一个球。"
        "慢慢变小，最后完全被吞入他的手中，消失在空气中。"
        stop music
        play sound "sound/effects/woosh.mp3"
        hm bingung "大家都没事吧？"
        show hm complain shock
        play sound "sound/effects/crumble.mp3"
        extend "啊——！" with vpunch
        scene kepsek_fall with dissolve
        galleryunlock kepsek_fall
        "校长一瘸一拐地朝你走来，但当他走向你时，桥的一部分在他脚下坍塌了。"
        show side_p m at pic
        mc "该死！抓住我的手！"
        hide side_p
        "你向他伸出手，但差之毫厘。他从裂缝中掉了下去，直接落入水中。"
        "他一碰到水面，就能看到一道明亮的绿光。"
        scene ati0 with dissolve
        play sound "sound/effects/woosh.mp3"
        show ati1
        play music "sound/effects/jelly.mp3"
        show ati_2 behind ati1 with moveinbottom:
            xalign 0.5
            alpha 0.0 yalign 0.0
            easein 5.0 alpha 1.0 yalign 5.0
            easein 1.0 alpha 0.0
            repeat
        show ati_3 behind ati_2 with dissolve:
            xalign 0.5
            alpha 0.0 yalign 0.0
            easein 7.0 alpha 1.0 yalign 5.0
            easein 1.0 alpha 0.0
            repeat    
        "就在气泡消散时，一颗绿色的翡翠浮出了水面。"
        if girl:
            show ati1_f with moveinbottom
        else:
            show ati1_m with moveinbottom
        "它越来越亮，最后安居在你右手的掌心里。"
        stop music
        scene jmbtn_rusak with dissolve
        show quil skul err sweat at right with dissolve:
            yoffset 200
        show tom hip ha sweat at center with dissolve:
            yoffset 190
        show red chin huh sweat at left with dissolve:
            yoffset 330
        play music "MUSIC/MusMus-BGM-059.mp3"
        red point bingung -sweat sigh "我知道我这样说会下地狱，但该死的，这真是太方便了。"
        show red sad -sigh
        tom scold calm -sweat blow "也许这就是因果报应，为了他抓走的所有海妖。"
        quil cringe -sweat sigh "哦是的，阿希，你尽管表现得不那么关心吧。我相信没有哪个老师会注意到你明显的幸灾乐祸。"
        show quil sly -sigh
        tom ha apa "你是说你不觉得我们不用杀人而感到宽慰吗？"
        quil talk -sigh "当然我觉得宽慰，但是说实话，策划谋杀还挺有意思的。我一直想知道我能不能逃脱惩罚。"
        show quil smile
        tom amused blow "我记下了。亲爱的奎尔，以后有机会我一定会找你的。"
        show red amused
        show side_p he at pic
        mc "是啊，我还是分不清你们是在开玩笑还是认真的。"
        hide side_p
        play sound "sound/effects/walk.mp3"
        red chin huh sweat shock "他们是在开玩笑。另外我们应该尽快把那东西藏起来，伙计们。麻烦来了。"
        show quil kzl shock
        show tom hip kzl shock
        play sound "sound/effects/cloth.mp3"
        scene jmbtn_rusak with dissolve
        "你把宝石粗鲁地塞进了口袋里。"
        show hedwin mad at center with dissolve:
            yoffset 200
        hed "孩子们，这是怎么回事？"
        show side_q skul sad at pic
        quil "这都是西尔贡的错，女士。是他施放了那该死的符文。"
        hide side_q
        "奎尔指向正在游向岸边的伊米尔和西尔贡。"
        show side_p w at pic
        mc "（至少他们安全了。）"
        hide side_p
        hed sad sigh "让我猜猜，又是情侣吵架？说真的，那两个男孩。不过至少梅洛迪没有牵扯进来。"
        hed konsul "校长也和他们在一起吗？恐怕我的眼睛不如从前了。"
        show side_t skul sad at pic
        tom "事实上，海德温女士，我好像没看到校长浮出水面。"
        hide side_t
        hed mad shock "...什么？"
        "海德温女士迅速俯身桥上，寻找校长的踪影。当她没有看到任何生命迹象时，她低声咒骂了一句，然后慌忙跑回大门。"
        play sound "sound/effects/tile.mp3"
        hed sad -shock "凯普勒，联系教会！我们遇到麻烦了！"
        hide hedwin with dissolve
        show tom scold kzl at center with dissolve:
            yoffset 190
        tom "老师们现在可能会巡查湖边。"
        show tom hip 
    scene jmbtn_rusak with dissolve
    show quil kzl at right with dissolve:
        yoffset 200
    show red point kzl at left with moveinleft:
        yoffset 330
    quil sigh "那我们快走吧。这场闹剧之后，课程应该会暂停。学生们会涌向校园各处。"
    red lelah sigh "那我们还等什么？走吧！"
    scene jmbtn_rusak with dissolve:
        subpixel True
        parallel:
            truecenter zoom 1.0
            easein 8.0 truecenter zoom 3.0
        parallel:
            easein 0.2 yoffset 12
            easein 0.2 yoffset 0
            repeat
    stop music
    play sound "sound/effects/tile.mp3"
    "你穿过一群学生，他们询问你发生了什么事。"
    "在老师们反应过来之前，奎尔施放了一个风之符文，我们推开人群跑向码头。"
    jump second_heart


label second_heart:
    scene bg_black with w20
    scene kmr_apt with w20
    stop sound
    play music "MUSIC/MusMus-BGM-077.mp3"
    show tom chill nyesal at center with dissolve:
        xalign 0.55
        yoffset 190
    show quil skul wry at right with dissolve:
        yoffset 200
    show red chin calm at left with dissolve:
        yoffset 330
    "当你来到你的分身面前时，你可以看到阿什姆脸上写满了深深的悲伤。"
    show tom sad 
    "他不知所措地摆弄着双手。"
    "当他的目光落在[povname]身上时，他往日所有的自信和傲慢似乎都消失了。"
    tom talk ha apa "你确定这会有用吗？"
    quil bingung sigh "不确定。但上次它产生了效果，现在这就足够了。"
    red awkward apa "...我知道这可能只是我在胡说八道，但你们有没有试过老掉牙的真爱之吻之类的？"
    quil panik frusta "塞恩，我知道你很天真，但即使是你也应该意识到这听起来有多荒谬。"
    show quil frown shock
    show red point kaget shock
    tom sigh sigh blow "同意，而且...我不认为我们中的任何一个是[dia]的真爱。"
    show tom ha -blow
    show red huh -shock
    quil amused apa "哦？"
    "奎尔挑了挑眉毛，显然没有料到阿什姆会这么回答。"
    show quil datar -shock
    tom scold eh apa "什么？"
    if "date3_done" in tom_events or ibu.points>= 50:
        tom ha frusta "即使我曾是[dia]的真爱，我想我现在也不再回应那些感情了。"
        show tom frown blow
    else:
        tom hip capek blow "我怀疑我是否赢得了[dia]的爱。"    
        show tom frown -blow
    show red amused
    show quil sulk 
    show side_p he at pic
    mc "好吧，没必要再讨论这个了。"
    hide side_p
    show pboy at horzappear
    menu:
        "自己插入宝石":
            hide pboy
            $ kindness -= 10   

        "让阿什姆插入宝石":
            hide pboy
            $ ibu.points += 5
            show side_p se at pic
            mc "阿什姆，上次[povname]醒来的时候你不在这里，对吧？"
            hide side_p
            tom scold ha sweat "哦，是的。我记得那时我离开了。"
            show tom frown -sweat shock
            show side_p se at pic
            mc "这次你想要亲自来吗？"
            hide side_p
            tom chill pfft blow "...其实我想。"
            $ tom_events.append('masukin')
    stop music
    scene kmr_apt with flashbulb
    play sound "sound/effects/jelly.mp3"
    "你从口袋里掏出宝石，它发出明亮的绿光。"
    "你能听到轻柔的心跳声，宝石温暖地脉动着。"
    if "masukin" in tom_events:
        "阿什姆轻轻地将宝石捧在手心，然后悬在[povname]的上方。"
    "宝石的光芒照亮了整个房间，然后完全溶解进你分身的胸膛。"
    "与第一颗宝石不同，这颗宝石的效果是立竿见影的。"
    play sound "sound/effects/cloth.mp3"
    if girl:
        show palmierproxy dobel rajuk mata at center with dissolve:
            yoffset 40
    else:
        show palmierproxy dobel rajuk mata at center with dissolve:
            yoffset 100
    "你的分身坐了起来，[kamu]尴尬地环顾四周。"
    play music "MUSIC/MusMus-BGM-092.mp3"
    show palmierproxy judes 
    show quil skul sad at left with dissolve:
        
        yoffset 200
    show red point sad sweat at right with dissolve:
        xzoom -1.0
        yoffset 330
    quil sulk apa "[povname]？"
    "奎尔满怀希望地问道，而阿什姆和塞恩都还处于震惊状态——从床边退后了一步。"
    show quil wry blush shock
    show red cowo blush shock
    mc malu sigh "奎尔，你看起来糟透了。"
    show palmierproxy flirt -sigh
    red hister bunga "等等，[povname]，你真的没事吗？"
    mc happy mblush "塞恩。你是不是刚刚做过爱？你看起来难得不错。气色很好。"
    hide quil
    hide red with dissolve
    show tom talk ha sweat at right with moveinright:
        xalign 0.55
        yoffset 190
    show palmierproxy sad -mblush shock at left with move
    tom chill whine -sweat apa "[povname]？"
    show tom sad -sweat
    mc ow sweat frusta "阿什姆...我很抱歉。"
    show tom hip eh sweat shock
    play sound "sound/effects/crash.mp3"
    hide palmierproxy with vpunch
    show tom sad -shock at center with move
    "还没等你说出一个字，你的分身就重重地倒回床上，发出一声巨响。"
    "身体虽然瘫软，但[dia]的胸膛仍在有规律地起伏，呼吸平稳。"
    tom whine frusta "[povname]?! [nickname]!"
    show tom sad -frusta
    "阿什姆摇晃着你的分身的肩膀，但[kamu]又陷入了深深的沉睡。"
    show quil skul ejek cling at left with dissolve:
        
        yoffset 200
    show quil sly -cling
    show red point laugh at right with dissolve:
        xzoom -1.0
        yoffset 330
    quil talk "我们还需要更多的心脏。只差两个了。"
    show quil smile
    red grin "好吧，我们已经走到这一步了。不如继续下去，对吧？"
    tom hip frown -sweat cling"我们必须这么做。"
    "阿什姆现在冷静下来了，他将头发往后梳，把注意力转向奎尔。"
    show red datar
    tom kzl apa "奎尔，你对最后两个纯血种了解多少？"
    quil hister bunga "一个辣得要命，另一个是个精神病。"
    tom ew frusta "奎尔。"
    show tom kzl
    quil mock apa "怎么了？你问了，我就回答。我是天才，不是全知全能。"
    show quil datar -apa
    red amused apa "也许我们应该等等看。我是说，上次不是也成功了吗？"
    show red bingung -apa
    if "ice_rune" in my_events:
        tom scold sigh blow "...现在我们学校的水里可是漂浮着尸体呢。"
        show tom kzl -blow
        red so apa "是啊，活着的尸体。可能更糟的是，他们可能已经死了。"
        tom hip ha frusta "原谅我，如果我在这里追求的不仅仅是最低限度的话。"
        show tom chill frown -frusta
        show red frown -apa
        show quil frown
        show side_p he at pic
        mc "说到最低限度，奎尔，你能用这个符文冻结湖面吗？"
        show side_p s
        mc "这是伊欧的...幻想女巫的最后心愿。"
        show side_p w
        mc "她已经为我们交出了她的宝石，我想这是我们至少能做的。"
        hide side_p
        quil bingung shock "哦。我从未见过这个符文。她是特意指名要我来做吗？"
        show quil frown -shock
        show side_p f at pic
        mc "是的，她说你是最有资格做这件事的人。"
        hide side_p
        quil rajuk "我明白了。这是一个冰符文，但在印记上有额外的笔画。"
        show side_p se at pic
        mc "那么这意味着你能做到吗？"
        hide side_p
        quil heh sigh "...给我两天时间研究一下，我们再看看。"
        show quil kzl shock
        show tom ha 
        show red huh
        show side_p m at pic
        mc "两天?!"
        hide side_p
        red chin ew frusta "伙计，那已经是破纪录的速度了。如果你让我来做这个，可能要花上几周时间。"
        show red bingung sigh
        tom capek blow "是的，况且，现在突然在湖里做什么也太仓促了。"
        tom sad -blow "现在那里已经很拥挤了。真是一团糟。"
        quil amused "教会刚刚发布公告说他们会尽可能提供帮助。"
        tom talk cruel cling "这在政治上的意思就是\'你们得靠自己了\'。"
        show tom kzl frusta
        show red lelah sigh
        quil hister sigh "差不多就是这样。"
        red point ngeles sweat -sigh "不过我为那些回来的人感到难过。有个人回来后发现他的家人都死了。"
        show red sad -sweat
        quil err sweat "比起那个丈夫已经组建新家庭的女孩来说，他还算幸运。"
        tom scold ha blow "他们需要所有能得到的帮助。尤其是那些与渔村有关的人。"
        tom hip sad -blow "如果你有时间的话，我建议你去拜访莱纳尔，看看你能提供什么帮助。学校能做的只有这么多。"
        quil laugh -sweat cling "别担心，妈妈。我已经在帮忙做义工了，在施粥厨房帮忙。要一起来吗，[povname]？"
        show quil amused
        show tom wry -sweat
        show red frown 
        if "bond" not in fia_events and "cure_me" not in red_events:
            stop music
            play sound "sound/effects/walk.mp3"
            scene kmr_apt with dissolve
            show red wry blush at center with dissolve:
                yoffset 330
            "在你能回答之前，塞恩替你回答了，他站在你和奎尔之间。"
            stop sound
            jump cicil_red

        else:
            show side_p a at pic
            mc "稍后吧，我...我有个人想先去见。"
            hide side_p
            scene bg_black with eye_shut
            jump ivar_grieve


    else:
        tom hip capek sweat frusta "我不想把我们朋友的生存交给命运。"
        tom talk ha -sweat apa "你和伊瓦尔已经聊过一两次了，对吧，[povname]？"
        tom frown -apa "有什么线索能知道他藏在哪里吗？"
        show side_p he at pic
        mc "我是说，那是个花园，还有伊欧旧时崇拜场所的遗迹。"
        hide side_p
        quil rajuk "还是太模糊了，但他似乎经常出现在你的梦里。"
        quil talk apa "也许我们可以使用入梦符文，闯入[povname]的思维。"
        show tom scold cruel 
        show red huh 
        show quil smile -apa
        show side_p m at pic
        mc "等等，什么?! 他妈的不行！还有..."
        hide side_p
        red kaget apa "还有什么？"
        show red bingung -apa
        show side_p s at pic
        mc "你们能不能暂时别管伊瓦尔？我知道这家伙不是什么圣人，但是..."
        show tom hip sad shock
        show red chin mls
        show quil sulk
        mc "伊欧是他的母亲，她刚刚去世。我们能不能给他一个喘息的机会？"
        hide side_p
        show tom ha blow
        red ew sweat frusta "你想给伊瓦尔一个喘息的机会？那个消灭了两个国家，杀死了超过一百万人的人？"
        show side_p w at pic
        mc "...是的？"
        hide side_p
        red point ngeles sweat sigh "[povname]，我知道你心软，但是——"
        show tom sad -blow
        show quil sad
        show side_p s at pic
        mc "拜托！就一天好吗？伊欧心甘情愿地付出了她的心，也许伊瓦尔也会这样做！"
        hide side_p
        tom whine frusta "虽然我不知道你和伊欧之间到底发生了什么，[povname]。"
        tom sad blow "但我知道伊瓦尔和幻想女巫完全不同。"
        show side_p s at pic
        mc "我知道，我也知道这家伙可能给大家带来了很多痛苦。"
        mc "但他刚刚失去了母亲。你们都有不健康的妈妈或爸爸情结，难道你们不能更有同情心吗？"
        hide side_p
        red growl -sweat frusta "...该死，伙计，你非得这么说吗？"
        quil err sweat apa "我讨厌你提出有道理的论点。你建议我们怎么做？"
        show quil bingung -sweat -apa
        show side_p f at pic
        show tom hip capek frusta
        mc "什么都不做！就暂时别去调查他。拜托，就给他一天时间哀悼吧。"
        hide side_p
        show red point sad -sweat sigh
        tom talk ew -frusta "...一天的哀悼时间。"
        show side_p a at pic
        mc "这就是我的全部请求。现在如果你们不介意的话..."
        hide side_p
        if "bond" not in fia_events and "cure_me" not in red_events:
            show tom frown shock
            show quil frown shock
            stop music
            play sound "sound/effects/punch.mp3"
            red kaget shock "等等！"
            scene kmr_apt with dissolve
            "塞恩抓住了你的手腕，吓了你一跳。"
            show red wry blush at center with dissolve:
                yoffset 330
            jump cicil_red

        else:
            show side_p se at pic
            mc "我要去小睡一会儿。"
            hide side_p
            scene bg_black with eye_shut
            $ night = True
            $ morning = False
            $ afternoon = False
            jump ivar_grieve

label cicil_red:
    play music "MUSIC/MusMus-BGM-008.mp3" fadein 5
    red ngeles "事实上，[povname]，随着吸血鬼来访的日子越来越近..."
    red awkward apa "而且我们还没找到其他治疗我\'病症\'的方法。我在想你是否最终决定要和我建立联结？"
    show red happy 
    if girl:
        show palmierproxy chill sad at right with dissolve:
            yoffset 40
    else:
        show palmierproxy scratch ew at right with dissolve:
            yoffset 100
    show red at left with move
    mc ha both "哦，呃..."
    show palmierproxy confused 
    show side_t skul frown at pic
    tom "做你认为合适的选择吧。我们会给你们一些私人空间。"
    hide side_t
    show side_q skul sad at pic
    quil "什么？！但我想看——哎哟！"
    hide side_q
    play sound "sound/effects/punch.mp3"
    queue sound "sound/effects/doorslam.mp3"
    "阿什姆抓住奎尔的耳朵，把他拖走了。"
    "几分钟过去了，你和塞恩都不知道该看向哪里，避开彼此的目光。"
    "塞恩的脸颊上浮现出深红色的红晕。"
    mc chill apa -both tanya "如果我们建立联结，那是不是意味着你会和我一起去我的世界？"
    show palmierproxy frown shock
    red wry sigh "当然。你知道，我可不会轻视这种联结。"
    red hister bunga "我会成为你的挚爱，而你将成为我的，只属于我一个人的。"
    show red wry
    mc side sweat "（哦，看来这意味着与其他人建立联结立即就被排除了。嗯。）"
    show palmierproxy wry -sweat -shock
    red awkward sigh "我本希望我们的联结是出于，嗯，不那么糟糕的原因，但即便如此..."
    show red wry at center with move
    show palmierproxy frown both shock
    red mock -sigh "如果你愿意给我这个荣幸，让我们在身心上永远结合..."
    show palmierproxy kind -shock
    red laugh bloom "...那么我发誓，直到我们的灵魂回归极乐世界或地狱，我都会让你成为这个世界和你的世界里最幸福的人。"
    mc deject sweat tanya "如果我说不呢？"
    show red wry -blush sigh
    show palmierproxy frown -tanya
    red "那我就需要你的许可去牵菲亚的手了。"
    red awkward -sigh "虽然我可能会把她当成妹妹而不是伴侣。"
    red sayang "你妹妹很可爱，但我就是无法那样看待她。抱歉。"
    show red datar
    mc frown -sweat sigh "我明白了。那么..."
    show pboy at horzappear
    menu:
        "让菲亚幸福，好吗？":
            hide pboy
            $ mrh.points -= 30
            if mrh.points < 0:
                $ mrh.points = 0
            red ow sweat apa "你确定吗？"
            show red chin sad sigh
            show palmierproxy confused sweat -sigh
            "塞恩的脸上闪过一丝失望的神色。"
            "你不明白为什么，因为你并不觉得你们有那么亲近。"
            show palmierproxy deject -sweat
            if "date2_done" in red_events:
                "你们只是一起出去玩过几次，仅此而已。"
            elif "date2_done" not in red_events and "date1_done" in red_events:                        
                "你们只约会过一次，如果那也能称得上约会的话。"
            else:
                "你几乎没有和这个男人相处过。"
            "然而菲亚和他似乎相处得很好。毫无疑问，她比你更适合做塞恩的伴侣。"
            mc happy "我觉得你和菲亚相处得比你和我更好。而且和她在一起，你就不必搬到一个全新的世界了。"
            mc smile "这是更实际的选择。"
            show palmierproxy kind
            red point amused sigh "我是说，你说得有道理。我也知道菲亚也愿意，我们现在是好朋友了。至少，我是这么认为的。"
            red cowo blush -sigh "她很有趣，虽然有时候有点难以预料。"
            show red point wry
            mc happy tanya "我知道，但这也是为什么我愿意让你和她建立联结。你会保护她的，对吧？"
            mc wry -tanya "确保她能顺利完成所有疯狂的事情。"
            red mock sigh "我喜欢你基本上是在为她的行为开脱，而不是阻止它。"
            "你对那句话耸了耸肩。"
            mc malu sigh "我觉得我在这个世界上的理智正在慢慢崩溃。菲亚的刻薄在这里似乎感觉是合理的。"
            mc ha -sigh "在拉斯维加斯发生的事，就留在拉斯维加斯吧，我猜。"
            show palmierproxy kind
            red point laugh cling "我不知道这句话是什么意思，但好吧。重点是，我保证我会保护她的，兄弟。"
            red amused apa "我现在应该去找她了。你要回校园吗？"
            mc smile "是的。我反正也需要回宿舍小睡一会儿。"
            red huh apa "小睡一会儿？"
            show red amused -apa
            $ fia_events.append("bond")
            $ fia_events.append("bond_new")
            mc laugh bloom "对。我有个人需要见。"
            $ night = True
            $ morning = False
            $ afternoon = False
            scene bg_black with w20
            jump ivar_grieve
        "接受契约":
            hide pboy
            mc malu blush sigh "我宁愿你选择我，而不是她。"
            red hister blush bloom "哦，感谢科尔！我还担心你会拒绝呢。"
            show red mock at center with move
            show palmierproxy kind shock
            "塞恩与你十指相扣。他脸上浮现出一丝羞涩的微笑，然后倾身吻了你。"
            "你任由他吻你。这个吻柔软而温柔，与他的尖牙碰到你的牙齿形成了鲜明对比。"
            "他舔舐并轻咬你的下唇，手指在你的发间舞动，将你更深地压入这个吻中。"
            "当你们分开时，你几乎能听到他心跳的歌唱，他的眼睛再次变成了深红色。"
            "只是这一次，你看到的不是饥饿。而是纯粹的、毫不掩饰的欲望。"
            mc malu tanya "就这样吗？"
            red chin calm sigh "契约？不，那只是我...想吻你而已。"
            red hister -sigh "至于契约，嗯，我们最好移步到我的房间去。"
            show palmierproxy huh both shock
            red amused "我想奎尔不会喜欢他的房子被血和...其他体液弄脏的。"
            show palmierproxy wry blush sigh
            show red kaget shock
            "一提到其他体液，你的脸就热了起来，但塞恩很快解释道。"
            red ow both frusta "我是指汗水，也许还有口水，因为你的血让我分泌很多唾液。我不是指...你懂的。"
            show red wry sigh
            mc malu -sigh "嗯。"
            scene kmr_apt with dissolve
            "你点点头，握住塞恩的手，让他带你去他的房间，耳朵变得通红。他的脸几乎和他的眼睛一样红。"
            "在走向塞恩房间的路上，你承认如果塞恩今晚不只吸你的血，你也不会介意。"
            "但也许那只是你的欲望在作祟，毕竟你已经很久没有和别人亲密接触了。"
            show side_p w at pic
            mc "（如果事情真的升温了，我想我不会太介意的。）"
            hide side_p
            play sound "sound/effects/walk.mp3"
            #scene bg_black with w33
            jump red_bonding_mc
label red_bonding_mc:
    $ night = True
    $ morning = False
    $ afternoon = False
    scene bed_mlm with w33
    if mrh.points < 50:
        $ mrh.points = 50
    else:
        $ mrh.points += 20
    stop sound
    show red chin mock both at center with dissolve:
        yoffset 330
    "进入塞恩的房间时，他显得有些坐立不安。你们俩都知道今晚将会发生什么。"
    show red wry blush
    if girl:
        show palmierproxy chill malu blush at left with dissolve:
            yoffset 40
    else:
        show palmierproxy chill malu blush at left with dissolve:
            yoffset 100
    "也许他比你更清楚，但无论如何。今晚将是你们的\'新婚之夜\'。"
    show palmierproxy ow both frusta
    show red kaget sweat shock
    "直到现在你才意识到这有多么疯狂。"
    show red point sad at center with move
    mc side sweat"（我即将把我的灵魂永远地与一个来自另一个世界的吸血鬼绑定。）"
    mc ow"（我他妈在干什么？！）"
    red wry blush apa"[povname]。"
    show palmierproxy sad -sweat shock
    "塞恩将你的一缕头发别到耳后，他的手指微微颤抖。"
    red sayang both sigh "如果你不想做，我们可以不做。我能听到你的心跳加速了。"
    mc ha sweat sigh "塞恩...我觉得你露出尖牙、下巴还流着口水的样子，说这话可一点都不酷。"
    red chin ngeles shock"Ah!"
    "塞恩擦掉口水，脸红着转过头去。"
    red huh frusta "对不起。我...紧张这个词都不足以形容我现在的感受。"
    mc scratch hister both -sigh "嘿，没关系。相信我，我也紧张得要命。但我不会说谎，我对此也有点兴奋。"
    show red wry -shock
    mc malu blush sigh "毕竟不是每天都能灵魂契约的，对吧？"
    red sayang blush sigh "是的。对我们这个种族来说，这是一生只有一次的事。"
    mc confused tanya"没有离婚程序之类的吗？我们会永远在一起？"
    show palmierproxy chill sad blush shock
    red mock cling "直到时间的尽头，永远如此。"
    "塞恩亲吻你的手掌，然后用舌头舔舐。"
    mc hister blush bunga "嗯。有点痒。"
    red sayang -cling "就只是这样吗？看来我在诱惑你方面做得不够好啊，哈哈。"
    show palmierproxy wry sigh
    scene bed_mlm with dissolve
    play sound "sound/effects/cloth.mp3"
    "塞恩笑了，脸颊泛起红晕，他轻轻脱下你的校服外套，一颗一颗地解开你的扣子。"
    "露出你修长白皙的脖颈，然后在上面轻轻一吻。"
    "你的心脏因期待而加速跳动。"
    show side_p se at pic
    mc "你现在要咬我了吗？"
    hide side_p
    show side_r skul smile at pic
    red "还不是时候。你能躺在床上吗？我觉得那样你会更舒服。"
    if not girl:
        red "请趴下。"
        hide side_r
        show side_p c at pic
        mc "这不是我第一次听到这种话了。"
        hide side_p
        play sound "sound/effects/cloth.mp3"
        "你按照指示，翘起臀部，塞恩在你身后调整位置。"
        show side_r skul smile at pic
        red "[povname]，你真是太棒了。简直完美。"
        hide side_r
        show side_p se at pic
        mc "这也不是我第一次听到这种话了。"
        hide side_p
        "一秒过去了，然后又是一秒。你听到塞恩在脱衣服，而你则把目光集中在床头板上，太紧张不敢直视塞恩的眼睛。"
        "然后你感觉到他修长的手指沿着你的脊柱滑下，最后停在你的腰带上方。"
        play sound "sound/effects/vamp.mp3"
        scene cowo_anu_glow with dissolve:
            truecenter zoom 1.0
            easein 2.0 truecenter zoom 0.67
        mc "...塞恩？哈！"


    else:
        play sound "sound/effects/cloth.mp3"
        show side_p se at pic
        mc "像这样吗？"
        hide side_p
        "你靠在床头板上，塞恩对你的姿势点头表示赞许。"
        show side_r skul sad at pic
        red "如果疼就告诉我。"
        hide side_r
        play sound "sound/effects/vamp.mp3"
        galleryunlock cewe_rednu
        scene cewe_rednu with dissolve:
            truecenter zoom 1.0
            easein 2.0 truecenter zoom 0.67
        mc "哈！"
    
    if not girl:
        "塞恩紧紧抱着你，你感觉到温热的血滴顺着脖子流下。"
    else:
        "塞恩看到你脸红了，嘴唇微张，开始因疼痛和快感而呻吟，他得意地笑了。"
    "在你能说出另一个字之前，塞恩咬破了自己的舌头，直到深红色的血液在他的嘴唇上汇聚。"
    "然后他吻了你——不，是吞噬了你。强烈的金属味充满了你的口腔。"
    "他把你的头向后仰，你吞下了那带着铜锈味和灰烬味的液体。"
    red "...我能感觉到你。"
    "他低语道，就在你也感觉到他的时候。你的心跳在他的手掌下跳动，塞恩的欲望和自制，他的紧张。"
    mc "我能感觉到你。你的情绪，你的心跳。"
    red "我们现在永远连接在一起了。"
    mc "塞恩..."
    if not girl:
        "塞恩松开了握着你的手，开始远离你。"
        "一种内疚感开始在你心中升起，这种内疚感来自于你的吸血鬼伴侣，而不是你自己。"
        mc "停下。"
        red "[nickname]？"
        mc "我能感觉到你内心升起的内疚。"
        red "那是...我觉得我在利用你，而且——"
        mc "我一点也不后悔，一点也不。你也没有在利用我，虽然..."
        galleryunlock cowo_anu_glow
        show cowo_anu_glow:
            subpixel True
            truecenter zoom 0.67
            easein 1.0 zoom 1.4 yalign 1.0 xalign 0.6
        play sound "sound/effects/cloth.mp3"
        red "唔！"
        "随着塞恩的内疚消退，另一种感觉开始在你体内积聚。"
        "一种你曾经有过的熟悉感觉。一种自从几周前来到这里就一直无法缓解的渴望。"
        play sound "sound/effects/cloth.mp3"
        "当你故意扭动臀部，反复摩擦塞恩的胯部时，他呻吟起来。"
        red "哈啊...[povname]，你在做什么——？！"
        galleryunlock cowo_anu_glow2
        show cowo_anu_glow2:
            subpixel True
            zoom 1.4 yalign 1.0 xalign 0.6
            easein 1.0 truecenter zoom 0.67
            
        mc "你知道，我不介意你用我，至少用其他方式。"
        red "[povname]，你不知道你在要求什么。刚建立联结就做爱...我会毁了你的。"
        mc "很好。"
        "你再次靠近，感觉到有什么东西开始顶着你，正好戳到你的——"
        show cowo_anu_glow2:
            subpixel True
            truecenter zoom 0.67
        mc "...毁了我吧，塞恩。"
        "塞恩笑了，一种发自内心的、嘲弄的笑声，你能感觉到他体内有什么东西崩断了。"
        red "哈啊。你真是个鲁莽的家伙，[povname]。"
        red "我他妈的就喜欢你这一点。"
        play sound "sound/effects/vamp.mp3"
        mc "啊！" with vpunch
        scene bed_mlm with dissolve
        "当塞恩再次咬你时，你畏缩了一下，然后他粗暴地把你推到床上，一边咕哝着一边脱掉了所有衣服。"
        show cowo_bite1 at right with moveinright
        "塞恩一把就把你的衣服撕成碎片，你只能瞪大眼睛看着他开始舔舐你的咬痕。"
        show cowo_bite2 at left with moveinleft
        galleryunlock sex_redm
        "疼痛的碎片穿透快感的浪潮。"
        mc "好疼！"
        red "你喜欢吗？"
        mc "你...你已经知道答案了。"
        red "是的，但我想听你说。即使我们的联结已经填补了空白，我仍然想听到你的声音。"
        red "听听你有多想要我。"
        play sound "sound/effects/vamp.mp3"
        mc "唔！"
        red "别忍着。你的呻吟，你的啜泣，你的欲望和需求...我想全部听到。"
        red "如果你想射，就得用你那张漂亮的嘴求我。"
        "你对他的话感到尴尬。他一直都是这么强势的情人吗？"
        "除了你自己的感受，你还能感觉到塞恩内心正在滋长的新情绪，满足和喜悦。"
        mc "你在享受这个。你有贬低癖吗？你这个施虐狂。"
        red "你应该能感觉到答案。又不是说你不喜欢。"
        red "现在..."
        mc "嗯嗯。"
        "他把你拉得更近，猛地将你的臀部紧贴在一起。"
        "双腿交缠，手臂环绕着腰部和脖颈。呻吟声充满了房间，你们纠缠的四肢覆盖了床的每一寸。"
        red "哦，那是个不错的声音。让我们看看今晚你还能发出什么其他声音。"
    else:
        "塞恩松开了握着你的手，开始远离你。"
        "一种内疚感开始在你心中升起，这种内疚感来自于你的吸血鬼伴侣，而不是你自己。"
        mc "停下。"
        red "[nickname]？"
        mc "我能感觉到你内心升起的内疚。"
        red "那是...我感觉我在利用你，伤害你，我——"
        mc "你没有伤害我。这是我想要的。"
        mc "况且...你能感受到我的情绪，不是吗？你难道感觉不到还有其他东西在驱使我吗？"
        "随着塞恩的愧疚消退，另一种情绪开始在你内心滋长。"
        "一种你曾经有过的熟悉感觉。一种自从几周前来到这里就一直无法缓解的渴望。"
        red "哦...你确定吗？"
        mc "我已经两周多没做爱了。是的，我确定。"
        red "啊哈哈。我一直喜欢你的直率。你和另一个[povname]都是。"
        mc "你真的要在我面前谈论另一个我吗？"
        red "啊，是啊。我猜我应该为此道歉，是吧？"
        mc "嗯。还要补偿我，你知道的，永远与你绑定在一起。"
        scene bed_mlm with dissolve
        "塞恩把你推到床上，脱掉所有衣服，而你则重新振作起来。"
        show cowo_bite1 at right with moveinright
        red "嗯。别担心。"
        show cowo_bite_alter at left with moveinleft
        galleryunlock sex_red
        red "今晚我有很多方法可以补偿你。"
    scene bed_alter with dissolve
    "你和塞恩度过了剩下的夜晚，你们的快感融为一体——相互放大。"
    "当你渐渐入睡时，他微笑的脸庞是你看到的最后一幕。" 
    stop music
    scene bg_black with fade
    "缓慢而稳定的呼吸安抚着你，你沉入了熟悉的黑暗深渊。"
    $ red_events.append("bonding_me")
    $ my_events.append("companion")
    $ mrh.hint = "塞恩在这次游戏中成为了你的恋人。他会跟随你到你的世界。"
    $ red_events.append("companion")
    jump ivar_grieve

label ivar_grieve: #5 June, Mon
    stop music
    stop sound
    scene gazebo with wet
    $ fia_events.append("mingle")
    if "bonding_me" in red_events:
        show ivar ancam at center with dissolve:
            yoffset 150
        iv "玩得开心吗？"
        play music "MUSIC/MusMus-BGM-112.mp3"
        show ivar kzl 
        "伊瓦尔盯着你，眼中充满愤怒。他看起来随时准备把你生吞活剥。"
        "你想问自己做错了什么，但当你向右瞥了一眼，你看到了。"
        "一个浅浅的坟墓，一只微弱发光的小水母正朝那里飘去。"
        if girl:
            show palmierproxy chill ew sweat at right with dissolve:
                yoffset 40
        else:
            show palmierproxy chill ew sweat at right with dissolve:
                yoffset 100
    else:
        if girl:
            show palmierproxy chill ew at center with dissolve:
                yoffset 40
        else:
            show palmierproxy chill ew at center with dissolve:
                yoffset 100
        mc sweat apa "...伊瓦尔？"
        play music "MUSIC/MusMus-BGM-112.mp3"
        show palmierproxy sad -apa at right with move
        "一躺到床上，你就用被子裹住自己，希望睡眠能迅速带你到伊瓦尔那里。"
        "他是个混蛋，但他刚刚失去了母亲。而且从技术上讲，这是你造成的。你不禁对此感到有些内疚。"
        show ivar kzl at left with dissolve:
            yoffset 150
        "当你看到伊瓦尔在花园的一角挖着浅浅的坟墓，一只微弱发光的小水母正朝那里飘去时，你的内疚感更强了..."
    "在毫无仪式感地沉入洞中之前，仿佛接受了自己的命运。"
    "一滴眼泪顺着伊瓦尔的脸颊滑落，你唯一能想到的是..."
    mc ow sweat frusta "该死。"
    show palmierproxy ew -frusta
    iv kzl sigh "来看你的杰作了？你很自豪吗？你们中的一个杀了我的女儿，而你，杀了我的母亲。"
    iv ancam -sigh "天啊，你们这些可恶的东西犯下了多么可怕的罪行。"
    play sound "sound/effects/grow.wav"
    show palmierproxy ow shock
    "他对你嘶声说道，双手抽搐，藤蔓开始在他脚下蜿蜒。"
    "看到这一切，你..."
    show pboy at horzappear
    menu:
        "道歉":
            hide pboy
            show ivar kzl
            mc sad frusta"对不起！"
            $ honesty += 10
            $ kindness += 30
            play sound "sound/effects/cloth.mp3"
            scene gazebo with dissolve
            "你毫不犹豫地低下头，痛苦地说道。"
            "你无法想象失去女儿或母亲会是什么感觉。"
            "但你失去过一个姐妹。你对那个卡车司机的愤怒。"
            "以及对自己让这一切发生的深深自责——"
            "那种愤怒和内疚...足以杀死一个人。但也许正因为你曾经感受过那种噬心的绝望..."
            "...你不想让伊瓦尔独自承受这一切。"
            play sound "sound/effects/walk.mp3"
            "伊瓦尔一言不发，但你能听到他大步朝你走来。"
        "赶紧逃跑":
            hide pboy
            $ kindness -= 30
            play sound "sound/effects/vine.wav"
            "在你还没来得及逃跑之前，藤蔓从你脚下冒出，缠绕住你的脚踝，将你拉向伊瓦尔的怀抱。"
    scene bg_black with eye_shut
    "当伊瓦尔用他修长灵巧的手指环绕你的脖子时，你闭上了眼睛——担心最坏的情况发生。"
    stop sound
    "但你预料中的颈部压力并未出现。相反，柔软的手指抚摸着你的脸颊，擦去了你恐惧的泪水。"
    iv "谢谢你。"
    show side_p s at pic
    mc "啊？"
    hide side_p
    scene gazebo with eye_open
    if girl:
        show palmierproxy chill sad sweat at right with dissolve:
            yoffset 40
    else:
        show palmierproxy chill sad sweat at right with dissolve:
            yoffset 100
    show ivar frown sigh at left with dissolve:
        yoffset 150
    iv "犹大之星一定折磨过她。没有人应该无所不知。"
    if "ice_rune" not in my_events:
        iv amused -sigh "至少她在你实现她最后的愿望时离世。"
    else:
        iv -sigh "虽然你没有实现她复仇的愿望，但至少你陪伴了她。"
    iv frown frusta "这比我这个亲生儿子所能做的还要多。"
    iv kzl -frusta "她牢房里的符文太过复杂。太过难以破解。"
    mc confused tanya "原来你知道。你有试过把她救出来吗？"
    show palmierproxy sad -tanya
    iv frown sigh "试过很多次。无论是在梦境中，还是在现实世界。"
    iv kzl -sigh "那些老祭司太过谨慎。没有巫师能进去，也没有巫师能出来。"
    iv frown "也许这是命中注定。最终，我们都无法在对方最需要的时候陪伴彼此。"
    mc deject -sweat "我为你的损失感到遗憾。还有，呃...这个坟墓是为她准备的吗？"
    iv ejek cling "是的。这个生物是她的一部分。因为某人没有想到把她的心脏带给我。"
    show ivar frown -cling
    mc pissed sweat frusta "我以为你没有生我的气！"
    show palmierproxy sad sigh
    show palmierproxy ew sweat
    iv amused "我从未这么说过。我可以同时感到感激和愤怒。"
    iv flirt cling "事实上，我之前想过很多创意十足的方式来折磨你。"
    iv ejek -cling "比如说，让荆棘从你的鼻孔和耳朵里钻出来。"
    iv ancam "或者让长满倒刺的卷须从你的胃里爬出来，穿透你的食道。"
    play sound "sound/effects/cloth.mp3"
    show ivar frown with move:
        xalign 0.7
    show palmierproxy sad shock
    "听到这些，你后退了一步，但伊瓦尔抓住你的手腕，让你留在原地。"
    show palmierproxy confused -shock
    iv amused "但你自愿来这里安慰我，这样的善举应该得到奖励。"
    iv kzl sigh "尤其是我的亲人们无法给我带来类似的慰藉。"
    show palmierproxy deject -sweat
    "你环顾四周，看到伊瓦尔的儿子们都在忙着自己的事，照料花园或端茶。"
    show rosy at left with dissolve:
        zoom 0.45
    "不过有些人似乎羞怯地看着你和伊瓦尔。"
    show pboy at horzappear
    menu:
        "靠近他们":
            hide pboy
            play sound "sound/effects/punch.mp3"
            show ivar kzl
            $ curiosity += 5
            show palmierproxy ow -sweat shock with vpunch
            "你试图靠近其中一个，但伊瓦尔抓住你不放。"
            "拉扯你的手腕，轻轻扭转。"
            mc ew sweat "疼。"
            iv ancam cling "那就别逼我伤害你。"
            iv kzl sigh "别靠近我的儿子们。我这么说是为你好。"
            mc apa tanya "你说为我好是什么意思？"
            show palmierproxy kzl -tanya
            
        "招呼他们过来":
            hide pboy
            mc deject tanya "他们不应该在你身边吗？你埋葬的可是他们的祖母。"
            iv kzl "你不会明白的。"
            mc sad sweat "理解什么？"
            iv frown sigh  "..."
        "莱尔呢？":
            hide pboy
            $ kindness += 10
            iv amused sigh "莱尔...嗯。是的，我多么希望他能认识他的祖母。"
            iv frown -sigh "至少他应该有机会认识她。"
            iv kzl "不像其他人。我想他会懂得欣赏她。"
            mc sad tanya "你说\'不像其他人\'是什么意思？"
    show palmierproxy kzl -tanya
    show ivar kzl -sigh at center with move 
    iv "你知道吗，我能听到他们的声音。我的孩子们，还有所有那些被我困在花朵牢笼里的人。"
    iv ancam flow cling "他们的一些想法，嗯...你何不亲自听听看？"
    mc apa tanya"什么——？"
    scene gazebo with dissolve
    play sound "sound/effects/summon.mp3"
    if girl:
        show wantf1 at left with moveinleft
    else:
        show wantm1 at left with moveinleft
    "一朵花在伊瓦尔的手上绽放。他把它别在你的耳后。然后，你就能听到了。"
    show want2 at right with moveinright:
        yalign 0.0
    "周围所有人形花卉生物的邪恶、可耻的想法。"
    $ NPC = "伊瓦尔的儿子们"
    if girl:
        show wantf3 at right with moveinbottom:
            yalign 1.0
        galleryunlock want_render_f
    else:
        show wantm3 at right with moveinbottom:
            yalign 1.0
        galleryunlock want_render_male
    npc "我想触摸他。"
    npc "我想玷污他。"
    npc "父亲，让我来安慰你。让我抱抱你。"
    npc "我需要抱抱你！！！"
    $ NPC = "???"
    scene gazebo with dissolve
    "你能听到，伊瓦尔的儿子们那些想要玷污自己父亲的堕落低语。"
    show side_p s at pic
    mc "这，这是怎么回事？！"
    hide side_p
    "当你感到胆汁上涌时，你不禁畏缩。一股厌恶感淹没了你，因为你感受到他们那不健康的痴迷几乎要把周围的空气都挤走了。"
    show crying_iv with dissolve
    galleryunlock crying_iv
    iv "恶心，不是吗？"
    iv "这就是我整天听到的。我自己的儿子们想要触碰我，把他们的种子洒在我的孔窍上。"
    iv "他们对祖母没有眼泪，没有同情，没有悲伤。只有下流的欲望。"
    iv "我应该杀了他们，把他们折磨到再也无法做出如此堕落的事。"
    iv "...但我怎么能？我甚至在第一次就做不到。"
    scene rep with wet
    galleryunlock rep
    "记忆开始充斥你的视线，一个留着长波浪发的年轻伊瓦尔的画面浮现。"
    "泪水打湿了他的脸颊，他被另一个男孩般的金发美人压在身下。"
    "一个年轻人，他的眼睛与莱尔和伊瓦尔都惊人地相似。另一个儿子。"
    play sound "sound/effects/vine.wav"
    scene rep_bloom with flashbulb
    galleryunlock rep_bloom
    "一个儿子，他的脸很快扭曲成一束苍白的花朵，当伊瓦尔颤抖着向他伸出手时。"
    "仿佛对自己的决定充满疑虑，即使他显然有理由自卫。"
    "双腿几乎弯到耳朵，一只不受欢迎的手在他赤裸的胸膛上游走。"
    scene crying_iv with wet
    iv "如果我在他们把我按在床上，试图对我为所欲为时都无法杀死他们..."
    iv "...你凭什么认为我现在能杀死他们，当他们基本上毫无力量的时候？"
    show side_p s at pic
    mc "伊瓦尔..."
    hide side_p
    scene gazebo with dissolve
    if girl:
        show palmierproxy chill ew sweat at right with dissolve:
            yoffset 40
    else:
        show palmierproxy chill ew sweat at right with dissolve:
            yoffset 100
    show ivar frown at left with dissolve:
        yoffset 150
    "你的眼中涌出泪水。伊瓦尔的记忆和感受淹没了你。不知何故，你能感受到他的绝望，他的愤怒，他的疑惑。"
    show palmierproxy sad -sweat
    iv kzl sigh "我从未要求生来如此。引诱男人，尤其是我自己的亲人。"
    iv -sigh "我从未渴望权力，永生，甚至不需要美貌。"
    iv frown sigh "我所想要的只是一个家庭。一个可以牵着走过红毯的女儿，一个可以在他从男孩成长为男人时指导的儿子。"
    iv -sigh "一个会成为祖母的母亲，被吵闹的孙辈们环绕。然而这一切不过是遥不可及的幻想。"
    mc deject sigh "伊瓦尔..."
    show pboy at horzappear
    menu:
        "请求拥抱的许可":
            hide pboy
            $ kindness += 20
            mc sad tanya "我可以拥抱你吗？"
            if not girl:
                mc scratch side -tanya "我是说..."
                if girl2:
                    mc sad "我知道我看起来更偏向男性，但是..."
                else:
                    mc sad "...你会觉得舒服吗？"    
            else:
                if not girl2 and not kln:
                    mc sad -tanya "我知道我看起来更偏向女性，但是..."
                else:
                    mc sad -tanya "我是说，你现在真的想被触碰吗？"    
            iv amused "...过来吧。"
            play sound "sound/effects/cloth.mp3"
            show palmierproxy chill wry -tanya at center with move
            if not girl:
                if girl2:
                    iv ejek "尽管你的体型不同寻常，但你仍然是我抱过的最美丽的女人之一。"
                    iv awk"别让任何人告诉你不是这样。"
                    mc smile blush sigh "我以为你讨厌我的样子。"
                    show palmierproxy kind -blush -sigh
                    iv amused "不再是了。我已经习惯了。"
                elif kln:
                    iv amused "你很温暖。你闻起来像阳光。"
                    iv "也许你更像是一朵向日葵，而不是牡丹。"
                    mc wry sigh "请在抱着我的时候不要再谈论把我变成花了。"
                else:
                    iv amused "你是第一个我同意这样触碰我的男人。"
                    mc kind blush "...我感到荣幸。"
                    iv ejek "我也是。这感觉很好。结实。你让我想起我的长子。"
                    iv amused "也许这就是为什么我对你如此宽容。因为你的外表和你那奇怪的善良心。"
                    mc hister sigh "谢谢。{w}不过，我不是基佬。"
                    show palmierproxy kind -blush -sigh
                    iv kzl frusta "现在气氛全没了。你这个可怕的、不懂察言观色的孩子。"
            else:
                if girl2:
                    iv amused "你是我抱过的最美丽的女人之一。"
                    mc kind "...我感到荣幸。"
                    iv "我也是。你让我想起莉莉，我的大女儿。她像你一样直率和坚强。"
                else:
                    iv amused "你很温暖。你闻起来像阳光。"
                    iv "也许你更像是一朵向日葵，而不是牡丹。"
                    mc ha sweat frusta "请在抱着我的时候不要再谈论把我变成花了。"
                    show palmierproxy kind -sweat -frusta
            show palmierproxy kind blush bunga at right with move
            show ivar amused sigh
            "大约两分钟后，伊瓦尔松开了你。"
            "他取下插在你耳朵上的花，它在他的手中化为尘土。"


        "拍拍他的背":
            hide pboy
            iv ancam frusta "别碰我。"
            show ivar kzl
            mc ew sweat frusta "好的。我...我很抱歉。"
            show ivar kzl sigh
            show palmierproxy sad -frusta
            "伊瓦尔叹了口气点点头，他看起来很沮丧，疲惫不堪，但也很高兴你尊重他的界限。"
        "你还有莱尔。":
            hide pboy
            $ honesty += 5
            iv amused sigh "我知道。当我看到他成年后仍然害怕我时，我非常高兴。"
            iv awk sigh "这给了我希望，事情会改变，这可恶的诅咒终将消失。"
    mc chill apa sweat tanya "等等，这就是你对你的儿子们如此残忍的原因吗？这样他们就不会...你懂的。"
    show palmierproxy sad -sweat -tanya
    "伊瓦尔对你的领悟点了点头。他的确认让你感到胃部翻腾。"
    iv frown sigh "我尽我所能地控制他们。"
    iv kzl -sigh "我从来没有勇气堕掉我的孩子，无论是儿子还是女儿。"
    iv frown "我做了必须做的事来阻止我的儿子们接近我。然而，只有莱尔似乎保持了那种恐惧直到成年。"
    iv "伊尔夫也动摇过，但他也失败了。不过他对莱尔的爱仍然纯洁真挚。"
    iv "然而，莱尔是我希望的灯塔。如果你愿意，可以称他为我的金童。"
    iv "仅仅提到我的名字就会引起恐惧和厌恶，震撼他的内心。大多数父亲会感到被侮辱。"
    iv smirk "然而这只给我带来无比的喜悦。"
    mc deject -sweat tanya "这是否意味着你的诅咒正在消退？"
    show palmierproxy frown -tanya
    iv flirt bunga "要么是这样，要么就是我在变老。我的魔力在减弱。这两种情况我都满意。"
    show ivar amused 
    mc side tanya "那么莱尔，他对这些一无所知？"
    iv kzl sigh "是的。我确保了这一点。"
    iv frown -sigh "我封锁了他的一些能力。他能听到我的一些造物的思想，但不是全部。"
    show palmierproxy sad -tanya
    iv "我仍然赋予他听到他兄弟们和一些低等造物思想的能力。"
    iv "但他永远不会听到他兄弟们的放荡行为，那些从他们最基本的本能中渗出的病态。"
    iv "不。让他自欺欺人地以为有善良的兄弟和一个暴虐的父亲吧。"
    iv "这总比有占有欲的\'情人\'试图除掉他们的竞争对手要好。"
    mc ew sweat frusta "你从未真的..."
    iv kzl frusta "在他们中的任何一个能以那种方式玷污自己之前，我就把他们变成了花。"
    show ivar frown -frusta
    mc scratch apa sweat tanya "但为什么是花束？"
    show palmierproxy chill sad -sweat shock
    iv sigh "我的长子小时候喜欢制作花束。这是我首先想到的。"
    show ivar -sigh
    mc ew frusta "我很抱歉。"
    if "curses" in topics and "ketemu_buli" in buff_events:
        $ fia_events.append('iv_curhat')
        iv ancam "我也是。但我们都不需要道歉。我已经多次试图杀你了。"
        iv amused "引你到梅扎那里，我们的梦境吸走你的生命力。"
        mc grit sweat shock "等等，什么？"
        iv smirk "更不用说我那宏大的计划，如果你真的设法杀死我们所有人，我会占据你的分身的身体。"
        iv flirt cling "考虑到所有因素，这种可能性比不可能更大。"
        mc ow tanya "嗯？等等，最后那部分是什么意思？！"
        iv frown sigh "你的学校教过你最黑暗的黑暗符文，不是吗？这是赫卡特之玫瑰。"
        show palmierproxy sad -tanya
        "伊瓦尔指着他的胸口，那里可以看到一个大大的红玫瑰纹身嵌在他的皮肤上。"
        iv smirk -sigh "只要这个符文刻在我的皮肤上，即使是死亡也不会伤害我。只要我的心脏完好无损，我就会继续活着。"
        iv ejek "梅扎死后，我考虑过帮助你，只是为了在最后背叛你。"
        iv ancam "在你收集了所有其他人的心脏之后，占据你的另一个版本的身体。"
        show ivar awk
        mc pissed -sweat frusta "你这个混蛋！"
        show palmierproxy kzl 
        iv amused "我的父母在怀上我的时候是结了婚的，谢谢你。"
        iv frown sigh "而且，我不再打算占据另一个你的身体了。"
        if not kln:
            iv -sigh "如果[kamu]的精神屏障很弱，我可能仍然能够这么做。"
            
        else:
            iv -sigh "如果[kamu]的精神屏障很弱，我可能仍然能够这么做。"
        iv awk "但我不会违背[dia]的意愿这么做。"
        mc rajuk -sweat sigh "是啊，没错。"
        show palmierproxy kzl -sigh
        iv smirk "这是真的。"
        iv awk "即使我真的好像接管了，我也会尊重你另一个自我的愿望。"
        iv amused "为这个世界带来和谐与统一。一个菲亚和你的朋友们可以和平生活的世界。"
        iv cling "我向你保证。"
        mc side frusta "我不确定是否能相信这一点。"
        show palmierproxy sad -frusta
        iv amused sigh "你爱信不信，但我至今还没有对你说过谎。"
        iv smirk -sigh "也许省略了一些细节，但从未撒谎。"
        iv flirt cling "这比你那些猎巫人朋友们所做的要诚实得多。"
        show ivar smirk -cling
        mc scratch apa sweat frusta "（嗯，他说得没错。）"
    else:
        iv amused -sigh "我也是。"
    show palmierproxy chill deject -sweat sigh 
    "一阵尴尬的沉默在你们两人之间蔓延。伊瓦尔趁此时间将水母埋葬在它最后的安息之地。"
    "他用小铲子轻轻地将泥土覆盖在这个生物上。一株幼苗标记着完成的坟墓。"
    iv smirk "我不会在这个上面使用魔法。我想看它以自己的节奏生长。"
    iv amused "过着简单、自然的生活。这是我们巫师中很少有人能做到的。"
    "你对此点了点头。有点同情他。隔壁的草总是更绿。"
    mc happy blush -sigh "我想她会喜欢这样。"
    show palmierproxy smile 
    iv awk "我也希望如此。"
    iv smirk "...谢谢你今天陪在我身边。"
    mc kind -blush "这是我能做的最起码的事。"
    iv frown"也许在你的世界里是这样。但在这里，你的善意是只有天使才能做到的。"
    iv amused flow "善意应该得到回报。"
    show palmierproxy frown shock
    "一朵红玫瑰在伊瓦尔的手掌上绽放。"
    "他把它递给你，你感觉这朵花与他之前的花不同。"
    "更加...有生气。"
    iv frown sigh -flow "如果你遇到麻烦，把所有花瓣都撕掉。我会立即来援助你。"
    mc confused tanya "你的援助？"
    show palmierproxy sad -tanya
    iv kzl frusta"塞斯在戏弄你。我几乎能闻到他在你身上留下的气息。他就在附近。"
    iv kzl sigh "我怀疑你那群漂亮男孩能否应付得了他。"
    show pboy at horzappear
    menu:
        "所以你会来救我？":
            hide pboy
            $ curiosity += 10
            $ honesty -= 10
            iv frown -sigh "我会帮助你。这是否足以让你从塞斯手中脱身，我不确定。"
            mc huh sweat tanya "你不是全能的巫师吗？"
            show palmierproxy kzl shock
            iv kzl frusta "我是。但他也是。"
            iv "我们上次的战斗以平局告终。给我们双方都留下了永久的伤害。"
            iv sigh "谁知道下次我们相遇会发生什么。"
            mc side tanya "嗯。你真的很警惕这个塞斯啊，是吧？"
            iv smirk -sigh "你也应该警惕。但也许你与我们这类人打交道的傻运让你变得自负了。"
            mc smile -sweat -tanya "到目前为止还挺管用的，不是吗？"
        "如果我出卖你呢？":
            hide pboy
            $ honesty += 10
            $ kindness -= 10
            mc mock -sweat cling "你大胆地假设我不会把这个交给我的朋友们或教会。"
            mc mean -cling "如果我可以用这个在任何地方召唤你，我就可以把你引入陷阱。"
            show palmierproxy wry
            iv ancam frusta "仅仅因为你能召唤我，并不意味着我会像狗一样听你的话。"
            iv kzl sigh "我会在多大程度上帮助你完全是我自己的决定。这包括我是否真的会出现在你身边。"
            if kindness >= 60:
                iv smirk -sigh"不过，有什么告诉我，你不会背叛我的信任。"
                iv amused"你太善良了，不会那样做。"
                mc side sweat frusta "我母亲是个严厉的女人，但她把我教育得很好。至少在这种情况下，这是个坏事。"
                show palmierproxy wry -sweat -frusta
                iv smirk "我觉得她把你教育得很好。"
            else:
                iv kzl sigh "然而，如果你背叛我的信任，我会毫不犹豫地打断你身上一半的骨头。"
                mc apa tanya "只有一半？"
                show palmierproxy sad shock
                iv smirk cling "你知道吗，人体超过一半的骨头都在手和脚上？"
                iv kzl -cling "打断你身上的每一根骨头，嗯...那实在是太费事了。"
                show palmierproxy huh sweat
                iv ancam "但是一半，对我来说轻而易举。"
                mc ha frusta "你知道吗，如果你是想说服我你站在我这边，你做得真是糟糕透顶。"
    show ivar smirk
    show palmierproxy side sweat sigh
    "你把花塞进后裤兜里。你仍然没有完全信任伊瓦尔。"
    show palmierproxy frown -sweat -sigh
    "但你很清楚不能忽视任何可能得到的帮助，即使是来自另一个巫师。"
    mc deject sigh "我还是觉得你应该有一天告诉莱尔关于他祖母的事。"
    show palmierproxy frown -sigh
    iv amused "也许有一天会的。但不是今天。今天我只是很高兴又一天被他憎恨着。"
    mc kind "总有一天他会明白的。"
    iv frown "我表示怀疑，但目前我已经满足了。"
    iv smirk "我很高兴看到他在这个过程中交到了一些好朋友。"
    show ivar amused
    "他说最后一句话时直直地盯着你。"
    if honesty >= 50:
        show palmierproxy wry 
        "你调皮地转过头，假装你身后有人。"
        "然后你指着自己，装作一无所知的样子。"
        mc happy tanya "你是在跟我说话吗？"
        iv kzl frusta "说真的。我为什么还要费心呢？"
        mc smile bunga "我开玩笑的，开玩笑的。这让你笑了，不是吗？"
        iv smirk sigh "...也许吧。"
    else:
        show ivar smirk sigh
        show palmierproxy side sweat frusta
        "他的目光让你有点慌乱，所以你迅速转过头避开他的眼睛。"
        "如果你的行为让他失望了，他确保没有在脸上表现出来。"
    show palmierproxy frown -sweat shock
    iv frown -sigh "我现在就送你回到现实世界。"
    if "ice_rune" in my_events:
        iv amused "你还有一个湖要冻结呢。"
        mc side sweat frusta "是啊，又一个令人沮丧的任务要从我的清单上划掉了。"
        mc sad tanya "你觉得那些人会没事吗？"
        iv frown sigh "谁知道呢。只有他们自己才能决定自己的命运。不过，虽然可能不值一提，但我并不谴责你的选择。"
        iv amused -sigh "我相信你做了正确的事。"
        show palmierproxy wry blush -tanya
        "你听到这话羞怯地笑了。虽然这可能不意味着什么，但你还是忍不住从他的认可中找到了安慰。"
        mc mock -blush tanya "那么，让我们赶紧结束这个吧。这次你打算怎么叫醒我？"
        mc mean cling "残害我，掐死我？"
        iv flirt cling "这么渴望暴力，还是说你是那种享受痛苦的类型？"
        mc malu sigh"更像是我只想赶快结束这一部分。"
        iv amused "我明白了。那么，我想今天我们可以跳过粗暴的部分。"
        play sound "sound/effects/punch.mp3"
        mc ow sweat shock "怎么，唔——！" with vpunch
    elif "bonding_me" in red_events:
        iv flirt cling "我相信你和红发有很多话要说。"
        mc kzl sweat frusta "等等，别告诉我你一直在看着我们——！"
        stop music
        play sound "sound/effects/punch.mp3"

    else:
        iv smirk cling "有空再来拜访我。"
        mc avoid sweat frusta "如果每次我试图醒来都不用死的话，我会的。"
        show palmierproxy wry -sweat -frusta
        iv ancam cling "嗯。也许今天我们可以跳过粗暴的部分。"
        stop music
        play sound "sound/effects/punch.mp3"
        mc ow sweat shock "怎么，唔——！" with vpunch
    
    scene bg_black with eye_shut
    "他用力推了一下你的额头，你的身体瘫软下来，坠入黑暗的深渊。"
    $ calendar.next() # 5 June
    scene bed_pagi with eye_open
    "这次你醒来时没有感到疼痛。没有你通常与伊瓦尔的拜访联系在一起的恐惧和惊慌。"
    if "bonding_me" in red_events:
        play music "MUSIC/MusMus-BGM-097.mp3"
        show red nude sayang blush at center with dissolve:
            yoffset 330
        "虽然你确实感到有点热，因为一个熟悉的红发身影可以看到正深情地注视着你。"
        "轻轻地抚开你脸上散落的发丝。"
        show pboy at horzappear
        menu:
            "早上好。":
                hide pboy
                red laugh bloom "早上好。睡得好吗？"
                red happy "你睡觉的时候我帮你擦洗了身体，还给你准备了一些维他命饮料，以防你需要。"
                red wry "早餐还没准备好，但如果你想在床上待着，我可以下去给你拿点东西。煎饼？吐司？汤？"
                red ngeles both frusta "哦，我还给你准备了洗澡水。不是说我觉得你很脏或什么的，但是——"
                show red sad -both shock
                show side_p nf at pic
                mc "塞恩。"
                hide side_p
                red bingung apa"啊？"
                show red wry blush
                show side_p nm at pic
                mc "闭嘴。"
                hide side_p
                show red hister bloom
                "你把塞恩拉过来，给了他一个早安吻。你仍能感受到他的情感在你体内流淌。"
                "他先是惊慌，然后慢慢放松下来投入这个吻中，当你把他抱在怀里时，那种感觉很快变成了喜悦。慢慢地，轻柔地，相互爱抚和轻咬。"
                "他已经准备好面对拒绝和后悔。但不是这个。"
            "你看着我睡觉了吗？":
                hide pboy
                red ngeles both frusta "抱歉。这很诡异吗？"
                $ honesty += 10
                $ kindness -= 10
                if kindness < 0:
                    $ kindness = 0
                show side_p ns at pic
                mc "有一点点。"
                hide side_p
                red perih "对不起。"
                show red sad 
                "你能感觉到胃在翻腾，扭曲成一种不舒服的感觉，类似于内疚。"
                "然而，这种内疚感似乎并不是你自己的。也许是塞恩的。"
                "从现在开始就会这样吗？你们的情感永远交织在一起？"
                red ow apa "...你后悔了吗？与我建立联结。你的情绪...很混乱。"
                show red sad frusta
                show side_p ns at pic
                mc "不！我不后悔，我只是...这太多需要消化的了。"
                hide side_p
                "你担心你那拙劣的解释只会进一步阻碍塞恩。然而，他似乎更容易理解你的感受。"
                "你不擅长表达，但他可能能感觉到此刻你并没有后悔。"
                "目前这就足够了。"
            "亲吻他":
                hide pboy
                show red laugh blush bloom
                "你在他的嘴唇上轻轻一吻。你仍能在他身上尝到自己的味道。"
                if not girl:
                    "你的\'精华\'，混合着浓烈的金属血腥味。"
                else:
                    "那强烈的金属血腥味。"
                show side_p nm at pic
                mc "哇。我尝起来真糟糕。"
                hide side_p
                red mock cling "我觉得你尝起来美妙极了。不止一个方面。"
                show red cowo bloom
                "他脸上挂着一个宽大的调皮笑容，然后倾身再次亲吻。"
        show red amused blush sigh
        show side_p n at pic
        mc "感觉好些了吗？"
        hide side_p
        red cowo bunga "好多了。我感觉又能控制自己了，\'像个人类\'。至少接近了。"
        red hister "我永远无法充分感谢你，[povname]。我欠你一条命。"
        show side_p nm at pic
        mc "我很高兴我们在沃特克的官员来之前就建立了联结。"
        hide side_p
        red ew sweat frusta "...关于那个，听着，我不想吓到你，但是..."
        show red sad sigh
        show side_p ns at pic
        stop music
        mc "什么？"
        hide side_p
        red kzl -sweat sigh "转身看看窗外。"
        scene bed_pagi with dissolve
        "你穿上衬衫以保持体面，然后打开床边的窗户。抬头一看，你看到了。"
        play sound "sound/effects/woosh.mp3"
        galleryunlock bats
        show bats with flashbulb:
            yalign 1.0
            easein 5.0 yalign 0.0
            easeout 5.0 yalign 0.85
        queue sound "sound/effects/roar.mp3"
        "五条，不，几十条龙形生物正在降落到校园。"
        "其中三条有骑手，骑手身着白色和金色。他们与你的战斗教师有些相似。"
        show side_p s at pic
        mc "邪血族？"
        hide side_p
        show side_r skul sad at pic
        red "还有大祭司本人。他们来得真早。"
        hide side_r
        show side_p s at pic
        mc "该死。"
        hide side_p
        "看到这一幕，你的胃一阵抽搐，担心最坏的情况。然而另一种情绪悄然而至。"
        "一种渴望和深深的悲伤。这让你困惑了一会儿，直到你想起那些生物中有一个是塞恩的母亲。"
        show side_p s at pic
        mc "塞恩..."
        hide side_p
        "塞恩只是点点头。他可能能感受到你涌来的同情之情。"
        show side_r skul sad at pic
        red "是啊...糟糕。"
        hide side_r
        jump vamp_dtg
    else:
        play music "MUSIC/MusMus-BGM-101.mp3"
        show buff frown sweat at center with dissolve:
            yoffset 770
        "尽管你对这个高大魁梧的棕发男子俯视着你感到有些慌乱。"
        "你目瞪口呆地看着莱尔，他正轻轻地擦去你额头上的汗水。"
        if not girl:
            show palmierproxy chill confused at left with moveinleft:
                yoffset 100
        else:
            show palmierproxy chill confused at left with moveinleft:
                yoffset 40
        show buff at right with move
        mc tanya "莱尔？"
        show palmierproxy frown -tanya
        buff keluh frusta "你在睡梦中辗转反侧。"
        buff sad sigh "我担心你发烧了或者怎么了。"
        mc hister sweat "哦。谢谢，我没事，只是做了个噩梦。"
        show palmierproxy kind sweat
        buff lega -sweat -sigh "哦。好吧，如果你感觉不太舒服，今天就在家休息吧。"
        buff keluh frusta "我想接下来三天的课程都取消了，以应对当前的危机。"
        buff sad -frusta"不过还没有正式通知。"
        if "ice_rune" in my_events:
            mc sad tanya "我明白了。派克和村子里的人怎么应对这一切的？"
            buff scold sweat frusta "情况不太好。外面一片混乱。"
            buff keluh sigh "莱纳尔的居民不知道该如何处理这整个事件。"
            buff sad -sigh "许多被认为已经死亡的亲人现在回来了。"
            buff huh "这引发了一些奇怪的问题，比如监护权争夺和失踪人口。"
            mc scratch apa tanya "失踪人口？"
            buff keluh "主要是孩子和我们这个年龄的人。逃走去和湖里的人在一起。"
            show palmierproxy chill sad -tanya
            buff "早已去世的父母，现在又活了。命运多舛的恋人，现在获得了第二次机会。"
            buff kzl frusta "那边就像一出巨大的肥皂剧。"
            show pboy at horzappear
            menu juju:
                "{s}我喜欢肥皂剧！{/s}" if honesty < 50:
                    
                    jump juju
                "我喜欢肥皂剧！" if honesty >= 50:
                    hide pboy
                    mc hister blush bloom "我喜欢肥皂剧！" 
                    buff sinis sweat apa "这不是我预期的反应，但很高兴知道。"
                    buff amused -sweat shock "等等，不，实际上这太棒了！"
                    show palmierproxy frown -blush shock
                    buff datar -shock "我正在考虑请你帮忙照顾村民。"

            
                "我能帮忙吗？":
                    hide pboy
                    buff wry sigh "我希望你会这么说。"
            buff laugh blush apa "也许我们可以帮助一些父母与失踪的孩子团聚。"
            buff wry -blush -apa "或者帮助解决一些家庭问题。我知道我们这样有点多管闲事，但是..."
            mc happy blush bunga "没关系，我相信派克也会感谢这些帮助的。"
            if "desa" in buff_events:
                mc wry -blush tanya "他和玛格丽特对此情况如何？"
                buff confused sigh "派克比大多数人都冷静，但玛格丽特，玛格丽特应对得不太好。"
            else:
                mc wry -blush tanya "他对这种情况怎么应对？"
                buff confused sigh "不太好，他的女儿玛格丽特负责当地的孤儿院，情况已经从坏变得更糟了。"
            buff keluh sweat frusta "许多孤儿和一些新居民一起逃跑了。我说的是那些来自湖里的人。"
            buff frown -sweat sigh "她还不确定该如何处理这些事。总之，我们应该在早餐后去那里。"
            mc happy blush tanya "好主意。这次你会和我一起吗？我是说，和我还有那些男孩们一起坐。"
            mc kind -blush -tanya "也许你可以请他们也来帮忙。"
            buff wry -sigh "哦，这是个好主意。当然可以。"
            
        else:
            buff sad sweat sigh "现在还没有最终定论。"
            buff keluh -sweat -sigh "但我想海德温女士暂时被任命为临时校长。"
            buff frown "除非教会指派其他人来担任这个职务。"
            buff amused "就我个人而言，我认为她会做得很好。只要她不在工作时嗨起来就行。"
            mc hister blush "对此我表示赞同。"
            buff keluh sigh "除了校长之外，还有其他问题。"
            mc deject tanya "哦？"
            show palmierproxy chill frown -tanya
            buff keluh -sigh"村里有几个孩子失踪了。"
            buff sad "主要是从孤儿院，但现在其他家庭的孩子也失踪了。"
            mc grit sweat "什么？都是同一时间失踪的吗？"
            show palmierproxy confused 
            buff keluh sweat frusta "不，这种情况已经持续一段时间了，但一开始只是孤儿院里年龄较大的孩子。"
            buff sad sigh "玛格丽特说这种情况有时会发生，孩子们想要独立生活。他们通常会在几周后回来。"
            buff frown -sigh "但后来其他家庭的年幼孩子也失踪了，所以人们终于开始担心起来。"
            mc side "我明白了。没有人帮忙吗？"
            buff kzl frusta "嗯，我确实向校长寻求过帮助，他说会向教会转达。现在他走了..."
            mc ow sweat frusta "（该死，这又是我行为的后果。）"
            mc scratch ha -frusta "呃，也许我和那些男孩们可以帮忙。至少我们可以四处打听，也许能帮忙解开这个谜团。"
            buff wry blush sigh "是啊。实际上，我很希望你们能这么做。"
            mc chill kind -sweat "好的。我们去吃早餐时问问他们，好吗？"
        "你和莱尔一起前往餐厅共进早餐。"
        jump hedwin_announce
label hedwin_announce:
    stop music
    #scene bg_black with w33
    scene kantin with w33
    play music "MUSIC/whisper.mp3"
    "餐厅里到处都是学生们的喧闹声。"
    if "ice_rune" in my_events:
        $ NPC = "???"
        "大多数人都在谈论从湖里回来的人，虽然你也能听到其他人在讨论威廉大师匆忙前往伊格尼亚首都的事。"
        npc "你觉得他们会解雇他吗？"
        $ NPC = "男孩"
        npc "谁，教会吗？我是说，我不明白为什么。没人真正知道那些人为什么会在我们的水域里。"
        $ NPC = "女孩"
        npc "我听说他们都被一个巫师的咒语控制了！还是个纯血统的。可能是幻想巫师。"
        npc "你觉得她是不是一直藏在我们的水域里？"
        show side_p s at pic
        mc "（看来他们还不知道墨水和学校下面的密室的事。也许这样最好。）"
        mc "（我无法想象当这里的每个人都知道他们珍贵的符文墨水来源时会引发什么样的混乱。）"
        hide side_p
    else:
        "对校长突然失踪和被推测死亡感到担忧。"
        $ NPC = "???"
        npc "他不可能死了，对吧？至少不会以这种方式。"
        $ NPC = "女孩"
        npc "我知道。每个人都以为他会死在战斗中，或者至少死于旧伤。"
        npc "溺水，我是说，我知道他用拐杖，但是..."
    stop music
    play sound "sound/effects/clap.mp3"
    show hedwin mad at center with dissolve:
        yoffset 250
        zoom 1.05
    hed "同学们，请注意！"
    "海德温女士喊道，声音中带着明显的颤抖。她的声音沙哑而不稳，仿佛整夜都在哭泣。"
    if "ice_rune" in my_events:
        hed sad "正如你们所知，昨天我们有一些...来自下面的意外访客。"
        hed "一些我们以为已经不在人世的市民和老同学。或者至少我们是这么认为的。呃..."
        hed "由于这个突如其来的...奇迹，我们敬爱的威廉校长被召唤到伊格尼亚首都，正在与教会商讨未来的计划。"
        hed "在他离开期间，他把学校交给了我负责。科尔知道为什么，但我现在就在这里，作为你们的代理校长。"
        hed konsul frusta "科尔保佑我。"
        
    else:
        hed sad "我很遗憾地宣布，我们校长的下落仍然不明。"
        hed "教会的代表从昨晚开始进行调查，今天还在继续。"
        hed "你们仍然可以在湖边自由活动，但要小心不要打扰他们。"
        hed "同时，在另行通知之前，我被任命为临时校长。"
        hed konsul frusta "为什么他们选择了我，真的只有科尔知道。"
    show hedwin frown sigh
    "海德温女士当着全体学生的面一口气吞下了六粒药丸。"
    play sound "sound/effects/bang.mp3"
    "迪特里希大声踢了踢她的小腿，清了清嗓子，仿佛在说\'注意行为\'。"
    hed wry -sigh "哦，是的，咳咳..."
    hed talk "由于当前情况，接下来的3天内课程将被取消。"
    hed wry"不过这并不意味着没有工作要做。"
    if "ice_rune" in my_events:
        hed konsul "那些有兴趣在莱纳尔或戈莫拉帮忙的人可以去，我相信每个人都会感激的。"
        hed wry "如你们所知，从湖中归来的人已经引起了不小的骚动。"
        hed "对在这里重新上课的归来学生们没有冒犯的意思。"
        hed evil "我是说，你们带来的麻烦比你们的价值还大，但这不是你们的错。"
        hed sigh "只是，嗯，你们知道吗，你们会带来大量的文书工作。"
        show hedwin frown shock 
        show priest laugh at right with moveinright:
            yoffset 200
        play sound "sound/effects/chair.mp3"
        dog frusta "海德温。要我替你继续演讲吗？"
        show priest ramah 
        hed wry sigh "哦不，迪特里希。我没事，药效终于开始发挥作用了。"
        show priest sad sigh
        $ renpy.pause()
        hide priest with moveoutright
        hed tantang -sigh "总之。我们现在处于可怕的时期。虽然这可能是末日，但让我们尽量充分利用它吧！"
        hed konsul "帮助我们的邻居正是伊格尼亚教义的核心。"
        hed "所以，任何想要志愿帮助归来者的人，请向凯普勒先生报到。"
        hed talk "我会确保给所有参与帮助的人提高成绩，如果你们决定帮忙的话，我还会取消你们所有的留堂处罚。"
        hed sad "尤其是在莱纳尔。那里现在一片混乱，甚至已经不是那种好看的混乱了！"
        hed evil "咳咳。就这些了，请继续你们的日常活动吧！"
    else:
        hed wry "任何愿意帮助寻找我们校长的人都非常受欢迎。"
        hed sad "另外，附近的渔村发生了几起绑架案。我知道处理失踪儿童不在我们的管辖范围内。"
        hed "然而，由于教会仍在忙于搜索湖泊和寻找我们的校长，我建议你们以其他方式帮助村庄。"
        hed talk "为我们最近的邻居提供安慰和宽恕。"
        hed evil "就这些了。请继续你们的日常活动。"
    hide hedwin with dissolve
    play music "MUSIC/whisper.mp3"
    play sound "sound/effects/chair.mp3"
    "海德温女士坐了下来，学生们立即爆发出热烈的讨论。"
    show red chin kzl frusta at left with moveinleft:
        yoffset 330
        xpos -100
    show tom chill nyesal blow at center with dissolve:
        yoffset 190
        xzoom -1.0
    show quil skul sad frusta at right with moveinright:
        yoffset 200
    red lelah apa "她看起来很紧张，是吧？"
    tom scold ha -blow "如果我们突然被分配到她的位置，可能也会这样。"
    quil err sweat frusta "嗯，至少我会尝试不靠药物来应对。"
    quil amused sigh "不过，至少她基本上给了我们自由行动的许可。"
    quil sly cling "这应该对我们很有帮助，对吧，莱尔？"
    show buff wry blush at center behind tom with dissolve:
        yoffset 770
        xalign 0.65
    show tom hip smile with move:
        xalign 0.35
    "莱尔看着你点了点头，微笑着。"
    buff laugh apa "那么，你们三个会帮我在村子里吗？"
    show buff wry
    tom talk capek frusta "当然。老实说，教会没有更早介入真是遗憾。"
    red growl frusta "真的吗？你真的对此感到惊讶？"
    show red mock sigh
    "塞恩暗示的是伊格尼亚教会曾将科尔和伊欧囚禁了数个世纪。"
    tom chill pfft blow "我明白了。"
    buff confused sweat apa "我是不是错过了什么？"
    show buff huh -apa
    quil hister bunga "啊，没有。没什么是你和你那结实的胸肌需要担心的，莱尔。"
    show buff wry -sweat
    quil flashy wink -sweat cling "现在，我们去莱纳尔吧？"
    stop music
    play sound "sound/effects/walk.mp3"
    scene bg_black with w20
    $ NPC = "???"
    $ morning = False
    $ afternoon = True
    $ evening = False
    $ night = False
    jump missing_kids

label vamp_dtg:
    $ morning = False
    $ afternoon = True
    $ evening = False
    $ night = False
    stop music
    #scene bg_black with w33
    scene tengah with w33
    play music "MUSIC/whisper.mp3"
    "当长着翅膀的邪血族降落时，人群聚集在院子里。"
    "老师们围绕着学生，在长着獠牙的访客周围形成一道屏障，维尔科娃女士朝着中心跑去。"
    show nun cross frusta at center with dissolve:
        yoffset 100
    nun "普鲁什卡大祭司。我们今天没想到您会来。"
    stop music
    show nun sigh at left with move 
    play music "MUSIC/MusMus-BGM-110.mp3"
    show bee amused apa at center with dissolve
    pr talk "维尔科娃，是你吗？没有血腥味在你皮肤上，我几乎认不出你来了。"
    pr tantang cling "哎呀，你们这里有多么可爱的牲畜啊。都是年轻鲜嫩的，正好可以享用。"
    pr smile -cling "我无法想象你要多么努力才能忍住不直接咬下去。"
    "高阶吸血鬼祭司开始嗅闻空气，然后猛地转过头，将注意力集中在其中一名学生身上。"
    pr tantang "你。我相信我最近品尝过你父亲的血。味道如此甜美。绝对是我的最爱之一。"
    "普鲁什卡开始伸手去抓普莉姆，而后者则害怕地往后退。"
    if "prim_dad_meet" in my_events:
        "提到普莉姆的父亲让你有点震惊，因为你一直希望他能逃脱吸血鬼的魔爪。"
        show side_p s at pic
        mc "（看来运气并不站在我们这边。）"
        hide side_p
    pr smile bunga "漂亮的小东西。我敢肯定你的血液同样甜美。你愿意亲爱的替代他吗？"
    "普鲁什卡的眼睛开始发光，普莉姆开始心不在焉地走进她的触及范围。"
    play sound "sound/effects/cloth.mp3"
    "然而，就在她即将抓住普莉姆的手时，凯普勒猛地将普莉姆拉到了自己身边。"
    "这一举动使普莉姆从吸血鬼祭司施加的恍惚状态中清醒过来。"
    show bee kzl shock
    nun proud -sigh "别碰我的学生。这是违法的！"
    pr tantang cling "哦，但我以为你对这些法律很宽松呢。毕竟，你允许一个学生绕过它们。"
    nun cross frusta "不是那样的。那是个意外！"
    pr talk apa "一个导致三名学生住院的意外。现在那个小麻烦制造者在哪里？"
    pr tantang sigh "塞恩，亲爱的，你不该现身了吗？"
    pr smile -sigh "毕竟，我甚至不辞辛苦地把你母亲带来了。"
    show bee2 at right with moveinright:
        zoom 0.97
    "普鲁什卡的一个手下摆弄着一个红色的金属球，类似于一个香炉球。"
    "你从那东西上闻不到任何明显的气味，但里面的东西似乎对她身后的翼族生物有影响。"
    galleryunlock emak_rawr
    show emak_rawr with dissolve:
        yalign 0.0 
        easein 6.0 yalign 1.0
    play sound "sound/effects/roar.mp3"
    "一只特别小但看起来凶猛的龙似乎被那个球完全迷住了，回应着它甜美的诱惑。"
    "这景象让你胃里翻腾，心中涌起一阵悲伤，但你并不确切知道为什么。"
    "直到你看到塞恩朝那野兽走去，你才明白这不是你自己的情绪，而是塞恩的。"
    "当塞恩小心翼翼地接近那野兽并用泪眼凝视着它时，一种令人心碎的内疚、悲伤和绝望感充满了你的内心。"
    red "嗨，妈妈。"
    $ NPC = "???"
    npc "那是他的母亲？"
    $ NPC = "女孩"
    npc "天啊，那是个邪血族！"
    $ NPC = "男孩"
    npc "塞恩也会被转化吗？"
    "你听到其他学生互相窃窃私语，而塞恩似乎对此毫不在意，完全沉浸在他母亲压倒性的存在中。"
    "普鲁什卡和其他吸血鬼窃笑着，塞恩的母亲似乎对普鲁什卡手中的球更感兴趣，而不是自己的儿子。"
    hide emak_rawr with dissolve
    pr tantang apa "啊，你听到了吗，特玛？他还叫你妈妈。"
    pr smile cling "让我们把他拉回现实吧，好吗？"
    hide bee2 with moveoutright
    play sound "sound/effects/splat.wav"
    "普鲁什卡把球扔进野兽的嘴里。野兽开始剧烈变形，骨头开始断裂，翅膀猛烈收缩。"
    scene tengah with dissolve
    
    play sound "sound/effects/cloth.mp3"
    "当龙\'吸血鬼\'开始呈现人形时，两个穿白袍的吸血鬼给这个生物披上了修女的长袍。"
    show emak_red at right with dissolve:
        zoom 0.48
        yalign 0.0
    show red point ngeles sweat shock at left with dissolve:
        yoffset 330
    "最后，一个苗条、高得离谱的红发女人出现在眼前。她有太多的嘴和太多的獠牙，不能被视为人类或吸血鬼。"
    "然而，你仍然可以看出她和塞恩之间的相似之处。即使在这种对人形的嘲弄状态下，她仍然明显是塞恩的母亲。"
    red perih frusta "Kuh!"
    "这景象显然对塞恩来说太过分了，他猛地转过头去，完全避开了这一幕。"
    "泪水开始从他的脸颊上流下。他几乎无法控制自己。"
    show bee amused apa at center with dissolve
    pr "无法忍受看到自己的母亲吗？你真是个糟糕的儿子。"
    pr tantang cling "在她为你做了这么多之后，牺牲了自己的人性只为了让你免于死亡的甜蜜之吻。"
    pr smile -cling "告诉我，哦迷途的羔羊，这值得吗？"
    hide emak_red with dissolve
    show pboy at horzappear
    menu:
        "介入":
            hide pboy
            play sound "sound/effects/bump.mp3"
            if girl:
                show palmierproxy chill grit at right with dissolve:
                    yoffset 40
            else:
                show palmierproxy chill grit at right with dissolve:
                    yoffset 100
            "你不再有耐心袖手旁观，大步穿过人群，用双手环抱住塞恩的腰。"
            show bee kzl shock
            show red chin ngeles with move:
                xalign 0.0
            show palmierproxy kzl with move:
                xalign 0.3
            red sad sweat shock "什么？"
            "然后你轻轻吻了塞恩的脸颊，用手掌遮住他的眼睛，挡住他的视线。"
            hide red with moveoutleft
            show palmierproxy grit at right with move
            mc frusta "够了！你们这些古老的老太婆要欺负我的灵魂伴侣到什么时候？！看来成熟真的不是随年龄增长而来的。"
            show bee kzl -shock

        "对普鲁什卡使用符文":
            hide pboy
            play sound "sound/effects/api.mp3"
            show red chin kaget sweat shock with flashbulb
            show bee mad shock
            "受够了他们的欺凌，你打了个响指，普鲁什卡的斗篷很快就着火了。"
            show red mock -sweat sigh
            "蓝色火焰惊吓了大祭司。她的两个跟班慌忙扑灭火焰。"
            "塞恩认出了你的蓝色火焰，看到大祭司失态，他的心中充满喜悦。"
            stop sound
            show red kzl frusta
            pr kzl frusta "你——！你竟敢这样攻击我？！"
            show red kaget sweat shock
            show side_p m at pic
            mc "不，但我做到了。"
            hide side_p
            show bee kzl shock
            hide red with moveoutleft
            if girl:
                show palmierproxy chill grit at right with dissolve:
                    yoffset 40
            else:
                show palmierproxy chill grit at right with dissolve:
                    yoffset 100
            "你不再有耐心袖手旁观，大步穿过人群，用双手环抱住塞恩的腰。"
            "吸血鬼官员们显然被你的举动吓了一跳。他们轻蔑地打量着你，心中盘算着。"
            show bee mad -shock 
            mc kzl frusta "什么？你真以为我会在你欺负我的灵魂伴侣时袖手旁观吗？"
        "通过你们的联结安抚塞恩":
            hide pboy
            show red sad sweat 
            "你试图通过你们的联结传递安抚的平静波动，缓解塞恩急促的心跳。"
            play sound "sound/effects/api.mp3"
            show red chin kaget sweat shock with flashbulb
            show bee mad shock
            "然而不幸的是，你的注意力被大祭司斗篷上突然燃起的火焰打断了。"
            show red mock -sweat bunga
            "这吓到了大祭司，她的两个跟班慌忙扑灭火焰。"
            "塞恩看到奎尔和阿什姆都在转动手指，装作若无其事地吹着口哨，不禁微笑起来。"
            show red kzl frusta
            show bee kzl frusta
            pr "你——！你会为此付出代价的！我一定会好好欣赏你失去理智的样子，就像你母亲那样！"
            hide red with moveoutleft
            if girl:
                show palmierproxy chill grit at right with dissolve:
                    yoffset 40
            else:
                show palmierproxy chill grit at right with dissolve:
                    yoffset 100
            show bee frown shock
            mc "你有什么权力这么做？"
            "你不再有耐心袖手旁观，大步穿过人群，用双手环抱住塞恩的腰。"
            "吸血鬼官员们显然被你的举动吓了一跳。他们轻蔑地打量着你，心中盘算着。"
            mc kzl frusta "据我所知，你之所以急于把他变成邪血者，唯一的原因是因为他没有伴侣。"
            mc "好吧，他现在有伴侣了……是我。"
            show bee kzl -shock
    show bee smile
    show palmierproxy deject -sweat sigh
    pr smile apa "你……你是他的伴侣？"
    mc judes sigh "如果我是呢？"
    pr tantang -apa "新结合的，对吧？我还能闻到你们……交合的残留气息。"
    pr amused bunga "还有你那奇异迷人的血液。哦，那是什么味道？你闻起来简直太诱人了！"
    show bee with move:
        xalign 0.6
    show palmierproxy frown sweat shock
    show red point growl at center behind palmierproxy with moveinright:
        yoffset 330
    show bee mad shock at left with move
    play sound "sound/effects/bump.mp3"
    show palmierproxy mean -sweat cling
    
    red frusta "离我的伴侣远点！"
    show bee kzl frusta
    "当普鲁什卡对你的血液表现出明显的兴趣时，塞恩咆哮起来。他露出獠牙，普鲁什卡也嘶嘶作响以示回应。"
    scene tengah with dissolve
    "不过当塞恩用他修长的手臂挡在你面前，在你和他的吸血鬼同伴之间筑起一道墙时，她还是退后了一步。"
    show nun hand at left with dissolve:
        yoffset 100
    show bee kzl frusta at right with dissolve
    "维尔科娃女士抓住这个犹豫的机会，试图进行外交斡旋。她向前迈了一步，站在塞恩和普鲁什卡之间。"
    nun sigh "塞恩已经与另一个人结合了。他再也不能从其他人身上吸血，只能依靠他的结合伴侣。"
    show bee mad 
    nun cross frusta "你说过，只要他能满足这些条件，帝国就会放他走。现在条件已经达成了。"
    nun "不会有血液污染，也不会把塞恩变成邪血者。带上你的邪血者离开吧。"
    "普鲁什卡皱眉，但她站稳脚跟，挺直腰板俯视着维尔科娃。"
    pr tantang sigh "失去獠牙的血骑士竟然还这么有胆量。但是……那确实是王子的条件。"
    pr smile -sigh "与你不同，我们会毫无差错地履行他的诺言。"
    pr talk "塞恩·维拉什科夫，我们仁慈的王子再次给了你一次缓刑。"
    pr amused "记住不要辜负他的仁慈。我希望你意识到自己有多幸运，孩子。"
    pr smile "我们现在就离开。"
    show red point bingung sweat shock at center with dissolve:
        yoffset 330
    red "等等，就这样？你们就这么离开了？不打算用你们的邪血者入侵校园什么的吗？"
    show red huh apa
    pr amused sigh "别自作多情了。这支邪血者舰队不是为你准备的，年轻的塞恩。"
    pr tantang -sigh "这是为我们王子的意中人准备的。"
    show bee smile 
    show red chin sad sweat shock
    nun hand apa "他的意中人？"
    "普鲁什卡完全无视了维尔科娃，但其中一位血骑士似乎急于回答，她转身面对维尔科娃。"
    $ NPC = "骑士"
    show side_y at pic
    npc "阿列克谢王子的灵魂伴侣印记已经显现。他的意中人似乎是精灵或海妖，一旦发现就要当场处决。"
    npc "我们绝不能冒险让他们相遇。必须保护我们王子的不朽。"
    hide side_y
    pr kzl frusta "我不记得允许你说话，伊兹玛。"
    $ NPC = "伊兹玛"
    show side_y at pic
    npc "啊！抱歉，我的主人。"
    hide side_y
    pr mad sigh "哼。"
    nun cross frusta "所以帝国派你们来大开杀戒。典型作风。"
    pr tantang cling "请随意加入我们，维尔科娃。从我所见，你们这个小小的猎巫学校已经命不久矣。"
    if "ice_rune" in my_events:
        pr amused -cling "我听说你们的校长目前正陷入与教会的纷争中。"
        pr smile "用不了多久，这个地方就会被永远关闭。"
        nun proud -frusta "除非我死。"
        pr tantang cling "那可以安排。"
        show side_y at pic
        npc "我的主人，再次抱歉，但我们不是应该前往我们的目标吗？"
        hide side_y
        pr kzl sigh "啧。可悲的是，我们确实有个截止日期要赶。"
        scene tengah with dissolve
        show red point ngeles sweat frusta at left with moveinleft:
            yoffset 330
        show emak_red at right with dissolve:
            zoom 0.48
            yalign 0.0
        "普鲁什卡转过身来，她的斗篷随风飘动，同时猛地拉扯着塞恩母亲的锁链。"
        play sound "sound/effects/splat.wav"
        "塞恩的母亲惊叫一声，随即变回了她的龙形。"
        hide emak_red with dissolve
        "再一次，你的胃因这景象而扭曲，感受到自己的不适和塞恩的情绪。"
        show red growl
        "塞恩咬紧嘴唇，攥紧拳头，怒火席卷而来，这愤怒更多地指向他自己和这种无助的处境。"
        scene tengah with dissolve
        show nun cross at left with dissolve:
            yoffset 100
        show bee smile at right with dissolve
        pr cling "直到我们下次相见，前指挥官维尔科娃。"
        pr tantang -cling "随意与我们分享一些你归来的湖中居民吧。"
        pr amused "帝国总是需要新的血袋。"
    else:
        pr tantang apa "你们的校长不幸早逝了，不是吗？"
        pr mad -apa "真遗憾。我一直在想他尝起来是什么味道。"
        pr smile "尽管他年老体弱，但几十年前他为我们杀死了绝望女巫。"
    nun hand sigh "再见，高级祭司普鲁什卡。维兹塔格·维尔·隆。"
    pr smile cling "维尔·隆·达尔斯，维尔科娃...小塞恩。"
    show bee kzl shock
    show red point growl frusta at center with dissolve:
        yoffset 330
    red "去吃屎吧，婊子。兹纳尔·赫克萨！"
    show red ow sweat shock
    pr tantang sigh "你用那张嘴亲你妈妈吗？"
    show red sad frusta
    scene tengah with dissolve
    stop music
    play sound "sound/effects/woosh.mp3"
    "普鲁什卡最后露出一抹冷笑，飞向天空。"
    "强风吹拂着你的脸，邪血族向他们的下一个目的地前进。"
    play sound "sound/effects/walk.mp3"
    "当维尔科娃解散学生群众时，阿什姆和奎尔都朝你和塞恩走来。"
    show red point so sweat frusta at center with dissolve:
        yoffset 330
    stop sound
    show tom chill sad sweat at right with moveinright:
        yoffset 190
    show quil sulk at left with moveinleft:
        yoffset 200
    play music "MUSIC/MusMus-BGM-146.mp3"
    quil err apa "我知道你现在不太好，但你还撑得住吗，塞恩？"
    show quil sad -apa
    red chin ngeles sigh "...我会没事的。"
    show red chin wry -sigh
    tom scold whine blow "很好。如果你需要什么，尽管告诉我们。无论如何我们都会在这里支持你。"
    show tom wry -blow
    show quil amused 
    red happy -sweat sigh "我知道。谢谢你们关心我。尤其是你，[povname]。我真的很高兴你在这里。"
    show red amused blush -sigh
    show side_p se at pic
    mc "嘿，这就是朋友该做的，对吧？"
    hide side_p
    quil hister blush bunga "啊，这听起来还是那么不真实。我们的小塞恩已经长大了，还抢走了阿什姆的真爱！"
    show red hister both sigh
    show tom hip capek sweat frusta
    quil flashy wink cling"这简直就是个超级电灯泡啊！"
    tom ew scold "这个[povname]不是我们认识的那个[povname]，奎尔。而且，你非得这么粗俗吗？你引以为傲的英克威尔家族的教养呢？"
    quil ejek -blush sigh "哦，这就是我在展现一些教养，阿什小宝贝！"
    quil laugh spark "如果我真的要堕落，我就会问被——操是什么感觉——"
    show red kaget both shock
    show tom eh both shock
    show quil skul amused -spark
    show side_p c at pic
    mc "好啦好啦，我要打断你了，你这个小魔鬼。"
    hide side_p
    show tom capek frusta
    show red wry blush -shock
    if "ice_rune" in my_events:
        show tom amused -both blow
        show red amused 
        show quil fluster sweat shock
        show side_p a at pic
        mc "你还有个冰系符文要掌握呢，所以专注于那个，好吗？"
        hide side_p
        quil sulk frusta "哈啊...我还以为你会忘记这件事呢。"
    else:
        show side_p a at pic
        mc "不过说实话，那场性爱进入了我的前十名。"
        hide side_p
        red cowo blush bunga "太好了。"
        show quil hister blush
        show tom lega blow
        red kaget sweat shock "等等，你说只是前十是什么意思？！"
        show red kzl both frusta
        show tom pfft blush -blow
    "气氛轻松了下来，你被留下来独自度过这一天的剩余时间。"
    "也许你可以四处打听一下，看看学校里其他人对这整个吸血鬼事件有什么看法。"
    $ red_events.append('vamp_visit')
    $ NPC = "???"
    scene bg_black with w20
    if "bunga_bego" in buff_events:
        if "beku" in quil_events:
            scene map_infected_f with w20
        else:
            scene map_infected with w20
    else:
        if "beku" in quil_events:
            scene map_frozen with w20
        else:
            scene map_all with w20
    jump world_map

label missing_kids: #5 or 6 June #Mon or Tues
    scene desa_center with w20
    play music "MUSIC/MusMus-BGM-008.mp3"
    $ fia_events.append("anak_hilang")
    "当你到达村庄时，你注意到一切都乱成一团。"
    if "ice_rune" in my_events:
        play sound "sound/effects/glass.wav"
        "村民们互相喊叫，以前的居民试图进入他们的旧房子，而这些房子现在已经被不同的租户或远亲占据。"
        "旧情人们试图应对他们的伴侣离开他们另寻新欢的事实。"
        "家庭成员们争吵着，因为父亲们出去买牛奶却一直没有回来，直到现在。"
        $ NPC = "???"
        npc "你说你出去买牛奶。哪家商店离这里有15年远？"
        $ NPC = "一位父亲"
        npc "亚历杭德罗，我知道我不是个好父亲，但是——"
        $ NPC = "吉莫西"
        npc "现在是吉莫西了。我的新家人，那些抚养我长大的人，叫我吉莫西。"
        $ NPC = "一位父亲"
        npc "哦。你不会真的喜欢这个名字吧？"
        $ NPC = "吉莫西"
        npc "我就是喜欢，现在给我滚出我的门廊！"
    else:
        play sound "sound/effects/glass.wav"
        "母亲和父亲因为丢失孩子而互相指责。"
        $ NPC = "???"
        npc "你应该看着他的！什么样的母亲会跟丢自己的儿子？！"
        $ NPC = "一位母亲"
        npc "你竟敢评判我。你根本就不是他生活中的一部分！"
        $ NPC = "一位父亲"
        npc "我一直在努力保证冰箱里有食物，让我们的家人能吃饱！我尽了自己的责任，你呢？！"
    $ NPC = "???"
    play sound "sound/effects/bang.mp3"
    "盘子和其他餐具从你身边呼啸而过，你左右闪避。"
    "现在每家似乎都有自己的问题，每个人显然都很苦恼。"
    "然而，有一位女士引起了你的注意。她正在一群年轻孩子周围哭泣。"
    "其中一些孩子你有些眼熟。"
    $ NPC = "孩子"
    npc "我们该怎么办，小姐？史蒂夫失明了，如果他掉进水里淹死了怎么办？"
    if "ice_rune" in my_events:
        npc "他能像那些奇怪的新来者一样浮上来吗？"
        $ NPC = "玛格丽特"
        show side_marg at pic
        npc "我...我不知道。莉莉娅，请不要这样想。"
    else:
        $ NPC = "玛格丽特"
        show side_marg at pic
        npc "不，别这么说，莉莉娅。我相信史蒂夫会没事的。"
    npc "希望他还和西西在一起。"
    hide side_marg 
    show buff sad sweat at center with dissolve:
        yoffset 770
    buff confused apa"玛格丽特？"
    play sound "sound/effects/tile.mp3"
    show side_marg at pic
    npc "莱尔！"
    hide side_marg 
    show buff sad shock
    stop sound
    "莱尔朝玛格丽特跑去。玛格丽特在他怀里抽泣，而你、奎尔、塞恩和阿什姆都尴尬地站在后面..."
    "尽可能友好地对孩子们微笑。显然你做得不太好，因为一个孩子目瞪口呆地尖叫起来。"
    $ NPC = "莉莉娅"
    npc "这些可怕的男人是谁？！"
    show quil flashy heh at left with moveinleft:
        yoffset 200
    quil cling "可怕？你不是想说高贵吗？"
    show buff lega blush
    show quil skul malu both shock
    $ NPC = "???"
    npc "哦，他只是个有钱的混蛋。"
    show buff wry -blush
    "一个年龄稍大的孩子一听到奎尔的口音就立刻插嘴道。"
    $ NPC = "男孩"
    show quil frown sweat sigh
    npc "嘘，莱斯利！他们是来帮忙的。"
    npc "...对吧？"
    show tom talk smile at right with moveinright:
        yoffset 190
    tom cling "抱歉打扰了，女士。我们来自巫师猎人学院。"
    tom pfft apa "莱尔说这里有失踪儿童的案例？"
    show tom smile -apa
    $ NPC = "玛格丽特"
    show tom chill frown
    show buff sad 
    show quil bingung -sigh
    show side_marg at pic
    npc "哦，是的。起初，我以为他们只是离家出走。年龄大一点的孩子有时会叛逆，搞出点动静。"
    npc "他们会逃离孤儿院来证明自己或试图引起注意，但通常一两周后就会回来。"
    npc "然而这次，年纪小的孩子几乎每隔一晚就凭空消失。"
    npc "昨晚我们有五个孩子失踪了。"
    
    if "ice_rune" in my_events:
        npc "起初，我以为可能是某个回来的人带走了他们。"
        npc "你知道，父母或亲戚。但史蒂夫已经没有任何亲人了。他的父母都死于精灵恶作剧事件。"
        npc "我亲自埋葬了他们。"
        hide side_marg
        if curiosity >= 50:
            show side_p s at pic
            mc "精灵恶作剧？"
            hide side_p
            "你低声耳语，奎尔凑过来对你轻声回答。"
            quil groan sweat frusta "无聊的精灵随机赐予路人飞行能力。受害者会飞上天空，窒息，在半空中死亡，然后从数百公里高空坠落回地面。"
            show quil sad -sweat sigh
            show side_p s at pic
            mc "我后悔问了。"
            show side_p m
            mc "（为什么这里的一切都想为了好玩而杀人？）"
            hide side_p
    else:
        npc "包括史蒂夫，我们最小的孩子。他是个盲童，一直很乖巧。我不知道是什么原因会让他逃跑。"
        hide side_marg
    $ NPC = "???"
    buff scold sweat apa "有什么线索吗？"
    show buff huh -apa
    $ NPC = "玛格丽特" 
    show side_marg at pic
    npc "嗯，欧文一直受到最大的怀疑。"
    npc "我们一直很欢迎他，但由于他是外来者，而且经常和孩子们在一起，人们开始对他产生警惕。"
    npc "孩子们，现在有相当一部分失踪了。"
    npc "但也不是说有人能让他\'开口\'。"
    hide side_marg
    quil flashy wink blush spark "交给我们吧，女士。我相信一个简单的菲拉符文就能解决问题。"
    show quil datar -blush -spark
    buff eh apa "等等，你们可以用魔法让他说话？"
    show buff sad -sweat -apa
    tom scold ha blow "不完全是。更准确地说，我们会让他把所知道的一切写下来并解释清楚。"
    show tom frown -blow
    npc "所以你们也认为他是嫌疑人？"
    quil skul amused sigh "我们对这个人几乎一无所知，无法做出任何推断。但他确实是一条线索，女士。"
    quil talk -sigh "我们现在还不想指责任何人。只是在寻找一个开始调查的切入点。"
    show quil smile
    show buff frown 
    show side_r skul sad at pic
    red "那家伙到底在哪儿？"
    hide side_r
    show side_marg at pic
    npc "也许在老教堂附近的山上？他有时会去那里寻找草药。"
    hide side_marg
    tom hip kzl "听起来很有可能。"
    show buff wry
    show tom calm
    quil flashy sly cling "来吧，让我们试着弄清楚这件事。"
    stop music
    play sound "sound/effects/tile.mp3"
    #scene bg_black with w33
    scene burung with w33
    stop sound
    play music "MUSIC/MusMus-BGM-084.mp3"
    show croissant frown at center with dissolve:
        yoffset 500
    show har frown at left with dissolve:
        xzoom -1.0
    "你们所有人都前往山上，发现欧文身边有菲亚和普莉姆。"
    "你立即担心地朝她跑去。这次她又惹上什么麻烦了？"
    show side_p m at pic
    mc "菲亚？普莉姆？"
    hide side_p
    fia flinch err sweat apa"[povname]？你在这里做什么？"
    show har kzl frusta
    show quil skul mock apa at right with moveinright:
        yoffset 200
    show croissant jijik shock
    quil "我们不是应该问你这个问题吗？还是说与神秘的老男人约会是你日常生活中经常发生的事？"
    show quil sly sigh
    fia kzl frusta "怎么可能！"
    show quil -sigh
    if "bond" in fia_events:
        fia jijik -sweat sigh "再说了，我已经有灵魂伴侣了，记得吗？"
        show croissant mad -sigh   
    else:
        fia flinch gross sweat frusta "我可不像你，谢谢，我不会和任何会呼吸的东西上床！"
    fia def sweat cringe frusta "我是自愿来村里帮忙的。我只是想做个好伊格尼亚人。"
    show quil amused
    fia annoyed -sweat -frusta "...另外，如果我来帮忙就不用留校察看了，不过这不是重点。"
    $ NPC = "普莉姆"
    show prim_ sad at pic 
    npc "我们只是来帮忙的。真难想象这里的人们正经历着什么。"
    show prim_ frown
    npc "贫穷，再加上这些糟心事？天哪。我也很穷，光是为钱发愁就已经让我无法正常生活了。"
    hide prim_
    show quil err sweat
    fia flinch err sweat "普莉姆，你还有10万存款和股票呢。"
    show croissant def hmph -sweat sigh
    show prim_ yell at pic
    npc "没错！我离一贫如洗只差一个金币了！"
    show prim_ frown
    npc "不管怎样，我们发现欧文被一群老绅士围攻，他们认为他是失踪儿童案件的幕后黑手。"
    npc "菲亚对他们使用了菲尔拉符文，他们就走开了。"
    hide prim_
    quil err frusta "还在滥用那个符文，是吧？"
    show quil kzl sigh
    fia kzl -sweat frusta "怎么了？总比我把这地方烧成灰好吧！"
    show quil -sigh
    show croissant frown sweat shock
    quil ejek -sweat cling "也许吧。不过，你确定你不是在帮助罪犯吗？为什么你如此确信欧文是无辜的？"
    show quil sly -cling
    show croissant flinch cringe frusta
    "听到这话，菲亚和普莉姆交换了一个眼神，一滴汗珠顺着她的脸颊滑下，她避开了奎尔的目光。"
    show pboy at horzappear
    menu istri:
        "继续追问":
            hide pboy
            $ kindness -= 10
            show croissant sad shock
            show side_p m at pic
            mc "菲亚，你知道些什么？"
            hide side_p
            fia def kerja both bunga"什么？"
            show quil amused
            show side_p c at pic
            mc "来吧，我知道你在隐瞒什么。你真的想和我玩这个游戏吗？1..."
            hide side_p
            fia mmh sweat frusta "真的吗？我已经不是9岁的小孩了。"
            show croissant kzl
            show side_p m at pic 
            mc "2..."
            hide side_p
            fia mmh sigh "啊，好吧！"
        "问塞恩" if "bond" in fia_events:
            hide pboy
            $ kindness -= 20
            show croissant gross both shock
            show quil hister 
            show side_p a at pic
            mc "塞恩，我妹妹现在感觉如何，焦虑，内疚，还是紧张？"
            show side_p c
            mc "你能通过你们的灵魂联结读取她的想法吗？"
            hide side_p
            show side_r skul smile at pic
            red mock cling "嗯..."
            hide side_r
            fia flinch cringe sweat frusta "你别回答！呃，这不公平，臭脾气！"
            show side_p c at pic
            mc "嘿，我们可以用简单的方式，也可以用困难的方式。来吧。"
            hide side_p
            fia jijik sigh "啊，好吧！"
        "{s}问塞恩{/s}" if "bond" not in fia_events:
            
            jump istri
        "直接问欧文":
            hide pboy
            $ honesty += 10
            $ curiosity -= 10
            show side_p w at pic 
            mc "那么，欧文，最近绑架过什么孩子吗？"
            hide side_p
            show har frown shock
            fia jijik sweat frusta "真委婉啊。"
            show side_b skul sad at pic
            buff "请不要这么无礼，[povname]。"
            show side_b skul smile
            buff "呃，对不起，欧文先生。但是，这里的孩子失踪是不是因为你？"
            hide side_b
            show croissant def sad -sweat -frusta
            show har smile sigh
            "再一次，你没有发现你的问题和莱尔的有什么不同，但莱尔的举止似乎让欧文觉得有点好笑。"
            "欧文对莱尔的胆怯露出了微笑。你不禁想知道，如果面对一个真正的凶手，莱尔是否还能保持这种礼貌。"
            fia kzl frusta "别为难他了。他没做错什么！"
            quil amused apa "你怎么知道的？"
            show quil frown -apa
            fia def mmh sweat frusta "我..."
            if "bond" in fia_events:
                show side_r skul smile at pic
                red "没事的，菲菲。不用紧张。"
                hide side_r
                show side_p se at pic
                mc "（菲菲？看来他们关系很亲密。）"
                hide side_p
                fia kzl -sweat "呃，别那么叫我，也别说出我的情绪！"
                fia sad -frusta "但好吧..."
            else:
                show side_p s at pic
                mc "拜托，菲亚？"
                hide side_p
                fia sad -sweat sigh "啊... 你知道你每次撅嘴我都没辙..."
    show croissant -sigh at center with move
    show har sad sigh
    "菲亚和普莉姆都转头看向欧文。他点了点头，表示理解即将发生的事。"
    fia gross sweat sigh "抱歉，欧文。"
    fia mmh sweat -sigh "这位欧文是亚历克谢王子的灵魂伴侣。"
    show red chin kzl at right behind croissant with dissolve:
        yoffset 330
        xalign 0.15
    red shock "什么？！就是那个亚历克谢？吸血鬼王子，那个吸血混蛋亚历克谢？！"
    show red ew frusta
    fia gross sigh "独一无二的那个。"
    show quil sad sweat shock
    if "bond" in fia_events:
        show red sad shock
        fia kzl frusta "还有，控制一下你的情绪，它们快让我窒息了！"
        show red ew frusta
    if 'vamp_visit' in red_events:
        show side_p s at pic
        mc "你就是那些血骑士追捕的人。是你让那些邪血飞到这里来的原因。"
        hide side_p
        show har sad sigh
        "欧文羞怯地对这句话点了点头。"
        show croissant sad sigh
        show red chin kaget shock
        har talk -sigh "对于我造成的所有麻烦，我很抱歉。"
        
    else:
        show croissant sad sigh
        show red chin kaget shock
        har talk -sigh "对于所有的保密行为，我很抱歉。"
    red bingung sweat apa "等等，你会说话？！"
    show red sad -apa
    show croissant frown -sweat -sigh
    har smile sigh "我还会唱歌呢。不过任何塞壬都会。毕竟，我们以声音著称。"
    show tom chill frown at right behind croissant with moveinright:
        xalign 0.7
        yoffset 190
    tom eh apa "所以你是塞壬，不是巫师。"
    show tom frown -apa
    show croissant mad -sweat
    show red mls -sweat sigh
    quil talk -sweat bunga "哎呀，那你是自由塞壬吗？这是我第一次看到没有戴宝石项圈就到处游荡的塞壬。"
    show quil sad shock
    tom capek frusta "奎尔！要有点尊重。"
    show red frown -sigh
    show tom ha -frusta
    show quil tantrum -shock
    har talk sigh "没关系。是的，我是\'自由塞壬\'，主要是因为我一生都在假装自己是个哑巴。"
    show side_p s at pic
    mc "等等，所以你以前从未说过话？"
    hide side_p
    har kzl frusta "我说过，但只在我信任的人面前说。你们都不属于那个类别。"
    har mad sigh "不过，这位菲亚小姐在使用菲拉符文方面有非凡的造诣。她强迫我说话。"
    fia flinch cringe sweat "在你们用那种眼神看我之前，我只是想知道菲拉符文{i}能否{/i}让他说话。"
    fia gross sigh "我没想到他真的会说。"
    har kzl frusta "如果是那样的话，也许你就不该大喊出来，我引用一下，\'把你所有的秘密都说出来，贱人。\'"
    fia sad -sigh "...再说一次，我非常抱歉。"
    red huh sweat apa "等等，你救了他，然后又欺负他？"
    if "bonded" in fia_events:
        show croissant mmh both sigh
        show red kaget -sweat shock
        "一拍过去，然后又是一拍。菲亚的苦相加深了，而塞恩感到一阵震动。菲亚的内疚可能已经传染到他身上了。"
        red hister  -shock "没关系，菲菲。至少你为此感到抱歉。"
        show croissant wry blush -sigh
        show red cowo blush
        quil amused sigh "看看你们两个在建立感情，我猜你们两个确实很般配。"
    else:
        show prim_ frown at pic
        npc "别太苛刻地评判她。你知道菲亚有时候可以有多刻薄。"
        hide prim_
        fia pity sweat "我正在努力改正。"
    show quil frown -sigh
    show croissant sad sweat -sigh
    show red datar sweat -apa
    tom ew blow "不管怎样，你是塞壬，还是吸血鬼王子的意中人。这让你成为了一个相当大的目标。"
    show tom ha -blow
    red ngeles frusta "我同意。灵魂伴侣的吸引力很难抗拒。如果他们结合，那么亚历克谢的不朽就会被限制在欧文的凡人寿命内。"
    red huh -sweat sigh "难怪他想除掉你。"
    har kzl sigh "我知道。我一直在寻找一种草药来制作能切断灵魂伴侣联系的药水，但我在哪里都找不到那种稀有的花。"
    har talk -sigh "现在我已经没有时间了。"
    show side_p s at pic
    mc "你说没有时间是什么意思？"
    hide side_p
    har kzl "吸血鬼紧追不舍，我已经看到邪血在这个地方四处飞行。"
    har sad frusta "还有村民们对我的蔑视问题。"
    show buff sad at center behind red with dissolve:
        yoffset 770
    buff keluh sweat "对此我很抱歉。他们对我很友好。我想他们只是害怕。"
    show buff sad
    har smile sigh "没人喜欢外来者。"
    har talk -sigh "不过，这不是你需要赎的罪。尤其是你。我相信你自己也经历过不少歧视。"
    play sound "sound/effects/woosh.mp3"
    galleryunlock birb
    scene birb with flashbulb:
        truecenter zoom 1.0
        easein 2.0 truecenter zoom 0.6
    "欧文的手臂变形成一对发光的天使般的翅膀。羽毛从他的脖子和脸部周围生长出来，他变成了某种鸟类。"
    show side_q skul frown at pic
    galleryunlock birb2
    quil "那些翅膀...你是被祝福的？！"
    hide side_q
    har "这是我必须继续躲藏的又一个原因。"
    if "ice_rune" not in my_events:
        show side_t skul frown at pic
        tom "你很幸运校长还没有得到你的消息，否则他会把你的头挂在壁炉上方。"
        hide side_t
        har "哦，我毫不怀疑。你们的前任校长是一个臭名昭著的塞壬猎人。"
        har "他猎杀了很多我的同类，无论老少。"
    else:
        show side_t skul frown at pic
        tom "我得说，你最好在我们的校长发现你之前离开，除非你想尝试被挂在壁炉上方。"
        hide side_t
    "你忍不住走近眼前这个奇怪的生物，抚摸着他的翅膀，它们在你的触摸下似乎变得更加明亮。"
    "当你的手指触碰到他柔软的、像鹅一样的羽毛时，你所有剩余的伤口和疤痕立即消失了。"
    if kindness >= 80:
        "欧文向你露出温柔的微笑，让你继续探索他的翅膀。"
        har "尽情地触摸吧。我的羽毛能治愈所有内外伤。"
        har "你待会儿需要保持最佳状态。"
        show side_p he at pic
        mc "待会儿？"
        hide side_p
        har "这里的情况不对劲。村民中有一个巫师。"
        show side_b skul sad at pic
        buff "巫师？是他们导致了孩子们的失踪吗？"
        hide side_b
        har "是的。"
        show side_q skul sad at pic
        quil "这是个大胆的宣言。你心里有怀疑的对象吗，还是这只是推测？"
        hide side_q
        har "我确实一直在关注一个人。不过也许我下定论有点早。"
    else:
        "欧文厌恶地把翅膀从你身边拍开。"
        if "bonding_me" in red_events:
            "你看到塞恩模仿着你的表情，你的巨大失望感传递了过去。"
        "欧文瞪着你，那眼神几乎在说\'我能看透你真正的残酷\'。"
        har "不要越过我的界限。塞壬的羽毛是珍贵的东西。我不会让你有幸如此亲密地触碰它。"
        fia "就一丁点儿也不行吗？"
        play sound "sound/effects/slap.mp3"
        "菲亚偷偷靠近欧文，结果被他的大翅膀拍在了脸上。"
        har "难道没人教过你礼貌吗，小姑娘？你比这里的孩子们还糟糕。"
        show side_b skul sad at pic
        buff "说到这个，欧文先生，你知道他们在哪里吗？或者谁可能是幕后黑手？"
        hide side_b
        har "我不知道他们的下落，但我心里确实有个嫌疑人。或者说至少曾经有一个。"
    show side_p s at pic
    mc "你怀疑谁？"
    hide side_p
    har "起初我怀疑是那个盲眼的孩子史蒂夫。我知道巫师的眼睛很奇怪，他把眼睛遮起来实在太方便了。"
    har "但后来我看到他和其他孩子一起与一个高大的身影交谈，然后完全消失了。"
    har "他在被带走前还在啜泣。"
    show side_p f at pic
    mc "高大的身影有点模糊。是男人还是女人？"
    hide side_p
    har "那是深夜，我看不清他们的脸。但他们很瘦，而且是白色的。"
    show side_p he at pic
    mc "白色的？"
    hide side_p
    har "字面意义上的全白。看起来苍白，如雪一般。然而，又很空灵。几乎像个天使，或者是天使的仿制品。"
    har "我认为那晚带走史蒂夫的人应该就是这一切的罪魁祸首。"
    har "当然，攻击我的村民们并不相信我的说法。显然，我已经不受欢迎了。"
    "欧文展开翅膀，跃入空中。"
    "一阵风吹到你脸上，你看到欧文威严的身影悬浮在天空中。"
    har "我要离开了。这里的情况变得太糟糕了，不合我的口味。"
    scene birb2 with dissolve:
        truecenter zoom 0.6
    har "祝你好运，莱尔。我一直很喜欢你的身材，尤其是当你浑身是汗的时候。"
    stop music
    play sound "sound/effects/birds.mp3"
    scene burung with dissolve
    "欧文眨了眨眼，莱尔像个害羞的少女一样本能地遮住了胸口。"
    "你们所有人都呆呆地看着欧文划破天空，几乎像是直接飞向了太阳。"
    show tom talk frown at center with dissolve:
        yoffset 190
    show red chin bingung at left with moveinleft:
        xalign 0.0
        yoffset 330
    show quil frown at right with moveinright:
        yoffset 200
    red ow sweat apa "...他不会真的直接飞向太阳吧？"
    show quil bingung sweat
    tom hip ha sweat "再等一会儿..."
    show tom lega -sweat blow
    show red -sweat wry sigh
    show quil hister -sweat sigh
    "担心会看到欧文变成烤鸡，你们的目光一直紧盯着他。"
    "当欧文向侧面飘去，朝海岸方向飞离校园时，你们都松了一口气。"
    red point grin -sigh "他很厉害。"
    play music "MUSIC/MusMus-BGM-146.mp3"
    show tom with move:
        xalign 0.6
    show croissant def smile at left with dissolve:
        yoffset 500
        xalign 0.4
        xzoom -1.0
    fia kerja sigh "好了，我很高兴这事结束了。"
    show croissant smile -sigh
    show prim_ smile at pic 
    npc "我们现在回去吗，还是你想再和镇上的居民聊聊？"
    hide prim_
    show pboy at horzappear
    menu:
        "建议女孩们离开":
            hide pboy
            show side_p f at pic
            show croissant mad sweat shock
            mc "你们两个应该走了。如果这里有巫师，我们会很快解决的。"
            show side_p m
            mc "你们两个太年轻了，不该卷入这场战斗。"
            hide side_p
            show tom frown -blow
            show quil frown -sigh
            red cowo cling "[nickname]说得对。把这件事交给你们的前辈处理，好吗？"
            show red huh -cling
            fia kzl -sweat frusta "不行。莱尔比我小一岁，他都在这里。"
            fia err sigh "我现在已经太投入了，而且我在校园里无聊得要死。"
            fia annoyed cling "你那句\'永远不要逃避危险的刺激\'呢？"
            show croissant sad sweat shock
            show side_p s at pic
            mc "那就去戈莫拉帮助那里的人吧。拜托了，菲亚，就听我一次。"
            hide side_p
            fia gross frusta "哈啊...好吧。"
            "菲亚从你身边走过，虽然她稍微侧了侧头，偷偷瞥了你一眼。"
            show tom ha shock
            show quil sad shock
            show red ngeles shock
            fia kzl -sweat frusta "你变了，唠叨鬼。有时候，感觉你像是完全变了个人。你到底怎么了？"
            show red sad -shock
            show quil sulk -shock
            show tom capek -shock
            "无法回答，你避开她的目光，咬着嘴唇，让她离开。"
            fia cringe sigh "真的吗？你在无视我？感觉你根本不像我的[kk]了。"
            play sound "sound/effects/walk.mp3"
            hide croissant with moveoutright
            "你的眼中涌出泪水，虽然你不确定为什么。她说得没错，你不是她的[kk]，至少不是真正的[kk]。"
            "你已经多次提醒自己这个事实，尽管你时不时会动摇。"
            "你并不愚蠢，你知道你不能自欺欺人地认为她就是你的菲亚。她的存在只是你妹妹的一个虚幻影像，仅此而已。"
            "但是，你还是产生了依恋，知道真相并不能让接受变得更容易。"
            show red chin with move:
                xalign 0.25
            show buff sad at left behind tom with moveinleft:
                yoffset 770
                xzoom -1.0
            buff keluh sweat apa "[povname]，你还好吗？如果你想的话可以回校园。"
            show buff wry -sweat sigh
            show tom pfft 
            show red amused
            show quil smile
            "莱尔递给你一块手帕。一如既往的绅士。"
            show side_p se at pic
            mc "谢谢，但我没事。"
            hide side_p
            $ fia_events.append('diusir')
            show quil hister blush bunga
            show tom calm bloom
            show red laugh blush bunga
            "塞恩拍了拍你的肩膀，阿什姆揉了揉你的头发，奎尔揉着你的肩膀试图给你安慰。"
            "你不知道是该感激还是该烦恼于你收到的所有关注。"
            show buff datar -sigh
            show red amused -bunga
            tom amused cling "我们要快速完成这次旅行。我们应该分头行动，尽可能多地询问当地人关于这个神秘人物的事。"
            show tom frown -cling
            quil sulk sweat frusta "哦，那么，我就负责这个区域吧。我的脚都酸了，在不得不走回去之前我是不会再往下走的，绝对不会！"
            show quil datar -sweat -frusta
        "你应该四处打听":
            hide pboy
            show side_p f at pic
            mc "我打算问问这里的其他村民，看看我们能不能找到那个神秘人物的线索。"
            hide side_p
            tom scold ha sweat blow "艾尔文的描述太模糊了，基本上就是描述了这里每个普通成年人。"
            red ow sweat frusta "或者是个很高的青少年，不能排除青少年。"
            show red huh sigh
            show tom frown -blow
            quil cringe sweat frusta "这让我们的搜索范围更广了。天啊...多有趣啊。"
            show quil bingung -sweat sigh
            show buff frown at left behind tom with dissolve:
                yoffset 770
                xzoom -1.0
                xalign 0.35
            buff apa "也许我们可以分头行动来减轻负担？"
            show buff frown -apa
            fia malu -sweat sigh "看来这个肌肉男还挺有脑子的嘛。我和普莉姆会负责山丘区，反正我们已经在这里了。"
            fia frown apa "奎尔？"
            show croissant mad -apa
            show tom pfft -sweat
            show red amused -sweat -sigh
            quil hister -sigh "哦，嗯，我坚信运动实际上对你没有好处，这都只是安慰剂效应，所以我会去和那边的人聊聊。"
            "奎尔指着小溪对面的一排房子。"
            show croissant frown
    tom talk smile "塞恩和我会在购物区打听。我和那里的一些人很熟，我相信塞恩是这里屠夫的常客。"
    show quil datar 
    red laugh blush bunga "你说对了。有时他们甚至会免费给我一整罐麋鹿血！"
    show red datar -bunga
    buff touched sigh "我去码头。村民们很友善，但有些渔民对外来人不太欢迎，最好由我来处理。"
    tom hip ha apa "你不也是外来人吗？"
    show tom frown -apa
    buff keluh -sigh "是的，但派克带我熟悉过这里。他们会接受我的。如果不接受...嗯，我已经习惯被排斥了。"
    show buff datar -sigh
    show side_p he at pic
    mc "派克去哪了？"
    hide side_p
    buff keluh apa "可能在码头吧？他就是那种通过埋头工作来逃避问题的类型。"
    show buff sad -apa
    show side_p f at pic
    mc "哦，这样啊。那么，呃，我猜就剩下孤儿院了？我和孩子们相处得不错。"
    show side_p se
    mc "我相信我能让他们开口。"
    hide side_p
    tom amused cling "6点在村广场集合？"
    show buff datar
    show red cowo
    show quil smile
    show side_p se at pic
    mc "听起来不错。"
    hide side_p
    play sound "sound/effects/walk.mp3"
    "你们各自分头探索村庄。"
    jump vil_map
label vil_map:
    stop sound
    scene orphanage with w33
    "当你到达孤儿院时，立即被孩子们跑来跑去、互相玩耍的欢快喧闹声迎接。"
    show side_p w at pic
    mc "至少他们还保持着积极的精神。"
    hide side_p
    $ NPC = "???"
    npc "嘿，你不是莱尔的朋友吗？你来这里做什么？"
    "两个年轻的孩子，可能不超过五岁，走到你面前拉着你的裤子。"
    show side_p se at pic
    mc "哦，是的，我是莱尔的朋友。我叫[povname]。"
    mc "我只是来问问史蒂夫的事。你们知道他去哪了吗？"
    hide side_p
    npc "史蒂夫？玛格...玛格...玛吉阿姨说他去散步了。不过是很长的散步。"
    show side_p he at pic
    mc "（嗯，这个孩子几乎说不完整句子。我可能得问问年龄大一点的孩子。他们可能在里面。）"
    mc "好的，那么，我要去问问其他人，好吗？你们不介意我进去吧？"
    hide side_p
    npc "不介意！玛吉说每个人都欢迎来孤儿院！"
    show side_p se at pic
    mc "每个人都可以随意进出孤儿院吗？"
    hide side_p
    npc "是啊。玛吉从不锁门。有时候半夜里就会有孩子被领养走。"
    npc "乌尔法就是这样被领养的。"
    show side_p he at pic
    mc "（嗯，难怪这里的孩子们总是不见踪影。不上锁？还有半夜领养？这太奇怪了。）"
    stop music
    play sound "sound/effects/door.mp3"
    mc "（现在最好不要想太多。他们还这么小，说的话可能不太可靠。）"
    hide side_p
    "你决定进去采访这些孩子。"
    scene orphanage_tamu with dissolve
    play music "MUSIC/MusMus-BGM-117.mp3"
    $ NPC = "???"
    jump vil_map2
    
label vil_kelar: 
    stop music   
    play sound "sound/effects/walk.mp3"
    scene bg_black with w20
    scene desa_center with w20
    "当你走回村子中心时，看到一群哭泣的父母正在询问他们失踪的孩子的下落。"
    stop sound
    play music "MUSIC/whisper.mp3"
    $ NPC = "女人"
    npc "有莎莎的消息吗？"
    $ NPC = "男人"
    npc "没有。我现在很担心，她会不会掉进水里了？"
    $ NPC = "女人"
    npc "就算掉进去了，她也会游泳。不过现在还是把湖封锁起来比较安全。"
    if "ice_rune" in my_events:
        show side_p he at pic
        mc "（好吧，至少我不用担心人们会因为我冻结湖面而生气。）"
        show side_p w
        mc "（也许我们这样做反而是在帮这个地方的忙。）"
        hide side_p
        show side_q skul smile at pic
        stop music
        quil "沉浸在你那漂亮的小脑袋里了，亲爱的？"
        hide side_q
    else:
        $ NPC = "???"
        npc "我想那不会成问题。我听说那所猎巫学校的校长在湖里溺死了。"
        npc "他们可能很快就会封锁湖泊了。"    
        $ NPC = "女人"
        npc "哼，我们花了几个月的时间试图让教会介入。只有当麻烦找上他们自己的门槛时，他们才终于采取行动。"
        npc "典型。"
        show side_q skul smile at pic
        stop music
        quil "偷听可真是个有趣的消遣，不是吗，亲爱的？"
        hide side_q
    $ NPC = "???"
    show quil amused at center with dissolve:
        yoffset 200
    show side_p m at pic
    mc "奎尔！"
    hide side_p
    play music "MUSIC/MusMus-BGM-102.mp3"
    quil flashy wink cling "想我了吗？你的小调查进行得怎么样？"
    quil skul groan sweat frusta "我的调查完全搞砸了。显然我有点不够敏感，可能惹恼了山上的几个村民。"
    quil hister -sweat spark "如果你看到有人拿着干草叉，最好赶紧跑。"
    show quil malu sweat -spark
    show side_p m at pic
    mc "什么？！你做了什么？！"
    hide side_p
    show red chin sad at left with moveinleft:
        yoffset 330
        xpos -100
    red lelah sweat sigh "别对奎尔太生气，我觉得这里的当地人现在不太欢迎外人。"
    red ew -sweat frusta "我和一群老鼠交朋友都比这容易。"
    show side_p s at pic
    mc "你不是吃老鼠的吗？"
    hide side_p
    red ngeles sigh "没错！这就是重点。阿什姆运气好一些，呃，算是吧。"
    show red amused -sigh
    show tom hip capek frusta at right with moveinright:
        yoffset 190
    tom scold kzl sweat "有人问我这张漂亮脸蛋是不是在出售。哼。"
    tom sigh blow "不过至少我设法让他们透露了一些信息。"
    show quil kzl -sweat shock
    show red huh apa
    tom kzl -sweat -blow "所有受害者的年龄都在8-12岁之间。而且似乎他们大多都看过欧文的木偶戏。"
    tom frown "这就是为什么他被认为是主要嫌疑人。然而，年长的商人指出，在欧文到来之前就已经有孩子失踪了。"
    tom whine "主要是那些被认为是离家出走的孤儿。其他很多嫌疑人都是商人，因为，嗯..."
    show red ew -apa
    show quil sulk -shock
    tom hip nyesal frusta "...沃特克帝国的影响力甚至延伸到了这里，年轻无辜的血袋是上等美味。"
    tom sad blow "伊格尼亚严格禁止这种行为，但是，有些吸血鬼的恶行真是无法无天。"
    tom ha -blow "塞恩，没有冒犯你的意思。"
    red ngeles frusta "没关系。况且就连我也对他们的行为感到厌恶。"
    red ew "我试图嗅出他们的气味，以防有人身上特别血腥，但结果只是让我找到了一整架羊肉。"
    show red hister -sweat -frusta
    show quil amused -sweat sigh
    tom capek frusta "因为你把鼻子凑上去闻，我们不得不买下那些羊肉，不过，我想彻底一点总是好的。"
    show tom ha -frusta
    if "diusir" not in fia_events:
        show red frown 
        show croissant def gross at center with dissolve:
            yoffset 500
            xzoom -1.0
            xalign 0.3
        fia sad sigh "普莉姆和我也遇到了同样的死胡同。不过我们确实发现了一些可能是有趣线索的东西。"
        fia pity sweat -sigh "诚然，我们确实和一个发放硬得像石头一样的糖果的老太婆聊了聊，就像典型的童话故事里的反派。"
        fia mmh -sweat apa "但除了她可怕的长相，她其实很和蔼。她提到了一些奇怪的事。"
        fia sad -apa "她说她的孙子曾经失踪了大约两周，但后来回来了，却不记得他去了哪里或是谁带走了他。"
        fia frown "他唯一记得的是在墓地里和其他孩子玩耍，然后...就什么都不记得了。"
    else:
        show tom nyesal
        red ngeles sigh "所以基本上对我们来说也是个死胡同。"
        show tom frown
        red frown -sigh "啊，我们还采访了一些在墓地玩耍的孩子。不过他们对一群陌生人没什么好说的。"
    show quil frown -sigh
    show side_p he at pic
    mc "等等，孩子们在墓地里玩？"
    hide side_p
    show quil with move:
        xalign 0.45
    show buff sad at right behind quil with dissolve:
        yoffset 770
        xalign 0.8
    buff keluh sigh "在这附近，孩子们没有太多地方可以玩耍。"
    show buff frown -sigh
    tom ha apa "真是阴森恐怖。那你呢，[povname]？"
    show side_p he at pic
    mc "我觉得我们中间有个巫师，可能是变化巫师。"
    mc "但我不确定那个巫师是否真的在这里。"
    show tom frown -apa
    show red huh
    show quil bingung
    show side_p f
    mc "看来所有孩子都在梦中看到了一个白色的身影。他们可能把一个巫师误认为是玩伴，但是……"
    show side_p s
    mc "除了画一些保护性的梦境符文外，我不知道我们该如何阻止或追踪这个巫师。"
    hide side_p
    tom whine "但你已经画了保护符文了吗？"
    show tom lega blow
    show side_p f at pic
    mc "是的。"
    hide side_p
    tom frown apa "那就是个开始。莱尔，渔民们有说什么值得注意的事吗？"
    show tom ha -apa
    buff confused sigh "不。"
    if "ice_rune" in my_events:
        buff keluh -sigh "每个人都还在为他们的亲人出现在湖边而紧张不安。"
        buff sad "就连派克也闭口不谈了。他应对这一切的情况并不像我想象的那么好。你看，一些渔民在湖里失去了他们的孩子。"
        buff scold sweat frusta "大多数孩子都回来了，活着而且健康。我是说，在湖里悬浮多年后，他们的状态已经算是不错了。"
        buff sad sigh "我猜派克有点嫉妒。所有这些孩子都与家人团聚了，但他的孩子没有。"
    else:
        buff keluh sweat frusta "虽然我真的不能问太多。看起来教会的人在调查中不小心从湖里挖出了一些旧尸体。"
        buff sad sigh "其中一具显然是派克的儿子，而且……我实在没有勇气再追问下去。"
    quil bingung apa "派克是那个喜欢在码头钓鱼的人，对吧？我不知道他失去了一个儿子。"
    show quil sad -apa
    show red sad
    show tom sad
    buff keluh -sweat -sigh "他不怎么谈论这件事。那是多年前的事了，溺水事件。他说是一个巫师把他儿子引入水中的。"
    show pboy at horzappear
    menu:
        "是幻想巫师吗？":
            hide pboy
            buff scold "我不认为他知道是哪个巫师干的，但他记得看到了蛇一样的眼睛。这就是他所知道的全部。"
            show buff sad 
            show side_p he at pic
            mc "（蛇一样的？好吧，至少不是伊欧。）"
            hide side_p
            buff sad -sweat sigh "可怜的派克。"
        "派克现在在哪里？":
            hide pboy
            show side_p w at pic
            mc "派克在哪里？也许我应该去和他谈谈，让他振作起来。"
            hide side_p
            buff confused -sweat -sigh "哦，他又出海了。说保持忙碌更好。"
            buff touched "但我相信你明天还能和他谈谈，他还会在我们学校附近钓鱼。"
            buff sad frusta "你知道，尽管发生了这一切。"
    quil fluster sweat frusta "这一周相当阴郁，不是吗？对我来说太多恐惧了。"
    if "ice_rune" in  my_events:
        show tom calm -sweat
        show red amused
        show buff apa
        quil talk -sweat sigh "但至少这场灾难让每个人都避开了湖泊，所以我们不必费心去清理它了。"
        if "diusir" not in fia_events:
            fia cringe apa "为什么你需要人们避开湖泊？"
            quil flashy wink cling "哦，菲亚，你总是这么爱管闲事，不是吗？但如果你这么好奇，为什么不亲自来看看呢。带上普莉姆和你的泳衣。"
            quil smile bunga "会很有趣的。"
            show quil sly
            show side_p he at pic
            mc "奎尔——！呃，别听他的，菲亚。"
            hide side_p
            fia frown "嗯。格兰布斯也参与你计划的事情了吗，奎尔？"
            quil smile apa "也许吧。你为什么不来看看呢？"
            fia kerja cling "好吧，那我会去的。"
            
        else:
            show tom amused
            show red hister
            quil hister -sweat apa "顺便说一句，莱尔，明天请来码头加入我们。"
            buff keluh apa "嗯？为什么？"
            quil flashy wink cling"来了就知道了。我保证会让你不虚此行的。"
        quil heh sigh "哦，以防万一，带件毛衣吧。我想明天会有点冷。"
        show quil skul smile -sigh
    else:
        buff sad frusta "我知道，我希望至少能为孩子们做点什么。"
        quil talk -sweat cling "嗯，实际上我想我可以帮上忙。"
        buff confused apa "嗯？"
        show buff sad shock
        show quil smile blush -cling
        "奎尔用手臂环住莱尔的二头肌，在他耳边低语。"
        buff laugh bunga "那个——哦！你能做到吗？"
        $ quil_events.append("ide_quil")
        quil flashy wink cling "亲爱的，我可是英克威尔。创造奇迹是我的专长！"
        tom kzl frusta "奎尔……你又在打什么主意？"
        show red amused
        quil smile bunga "亲爱的，明天就来码头吧。带上你的泳衣。"
    stop music
    scene bg_black with w20
    play sound "sound/effects/walk.mp3"
    "你们都回到宿舍，同时好奇奎尔又在策划什么。"
    jump beach_night

label beach_night:
    $ morning = False
    $ afternoon = False
    $ evening = True
    $ night = False
    scene kmr_malam with w20
    play sound "sound/effects/door.mp3"
    show buff kzl frusta at center with dissolve:
        yoffset 770
    play music "MUSIC/MusMus-BGM-101.mp3"
    "当你们回到宿舍时，莱尔和你并肩走到你的房间。"
    "他似乎心不在焉，不停地摆弄着双手。"
    show pboy at horzappear
    menu buff_curcol:
        "你在想什么？":
            hide pboy
            if girl:
                show palmierproxy chill wry at left with moveinleft:
                    yoffset 40
            else:
                show palmierproxy chill wry at left with moveinleft:
                    yoffset 100
            $ putri.points += 5
            show buff sad at right with move
            buff keluh sigh "哦，嗯，其实没什么。"
            buff confused -sigh "只是，嗯……我最近一直在思考。关于我的父亲，关于我是巫师混血儿，还有关于伊格尼亚的一切。"
            buff sad apa "你认为我们能和睦相处吗？"
            buff frown -apa "不仅仅是巫师和人类，还有吸血鬼和精灵，海妖和人鱼？猎人和狼人？"
            show pboy at horzappear
            menu:
                "每个人都有一点点种族主义。":
                    hide pboy
                    mc hister "你知道吗，我在戏剧社时期学过一首歌。"
                    mc scratch ha sweat"每个人都有一点点种族主义。随着年龄增长，我不禁觉得这是最真实的陈述了。"
                    show palmierproxy chill frown -sweat shock
                    buff scold frusta "所以基本上你是在说不行。"
                    show buff sad -frusta
                    mc wry -shock "我是说我们都互相憎恨，但这并不意味着我们必须真的互相杀戮。"
                    show buff frown
                    mc malu sweat sigh "我们仍然可以相处，但像所有刻薄女孩那样在背后谈论对方。"
                    mc flirt -sweat -sigh "我觉得这比我在这里看到的所有糟糕事情都要好一些。"
                    mc smile "现实的目标。"
                    buff amused "循序渐进。我想这是有道理的。"
                "当然！":
                    hide pboy
                    mc mock cling "你只需要一个共同的敌人。没有什么比一个试图征服世界的邪恶反派更能团结世界了。"
                    show palmierproxy kind -cling
                    buff hister blush "哈哈。我觉得你看太多戏剧了，[povname]。"
                    buff lega -blush sigh "但我明白你的意思。这听起来可能不太好，但老实说，我很高兴还有一些纯血巫师存在。"
                    buff amused -sigh "人们对他们的恐惧使得各地之间的敌意处于僵持状态。"
                    buff datar "我不确定一旦他们全被消灭，这些地方会有多安全。不过我也不希望巫师获胜，至少不是那些坏巫师。"
                    
                "不":
                    hide pboy
                    $ putri.points += 5
                    buff scold sweat "但是——"
                    mc pissed frusta"不。"
                    buff keluh "要不——"
                    show buff sad -sweat shock
                    mc side sigh "就是不行，莱尔。这里流了太多血。你最好逃离这个国家和这个世界。"
                    show palmierproxy frown -sigh
                    buff huh sigh "好吧，我想你说得对。"
                    show buff frown -sigh
                    mc wry tanya "如果我有办法做到，你愿意和我一起走吗？"
                    if "pinky" in buff_events:
                        buff laugh blush bloom "你已经答应过了，记得吗？拉钩上吊！"
                        mc hister -tanya "没错！拉钩上吊！"
                        mc kind "等我把这里的事情处理好，我们就走，好吗？"
                        buff wry -blush sigh "我不太确定那是什么意思...但好吧。"
                    else:
                        buff amused sigh "...我想是的。反正我在这里也没什么可留恋的，不是吗？"
            buff lega sigh "我希望有另一个世界可以让我逃离。"
            show buff datar -sigh
            mc happy "嗯，再等等，也许就会有了。"  
            show palmierproxy kind
            buff huh apa "嗯？"
            mc ha sweat "没什么，莱尔。"
            mc smile -sweat "总之，我们应该休息一下。不管奎尔为我们准备了什么灾难，我们都需要休息！"
        "温暖他的手":
            hide pboy
            if girl:
                show palmierproxy chill wry at left with moveinleft:
                    yoffset 40
            else:
                show palmierproxy chill wry at left with moveinleft:
                    yoffset 100
            mc wry tanya "你冷吗？"
            show palmierproxy kind -tanya
            buff eh both shock "啊，不！等等！"
            play sound "sound/effects/vine.wav"
            show buff sad at right with move
            if girl:
                show kamar_bungag with flashbulb
                galleryunlock kamar_bungag
            else:
                show kamar_bungam with flashbulb
                galleryunlock kamar_bungam
            "当你的手指与莱尔的手指交织在一起时，美丽的小向日葵在你的手中绽放。"
            "你欣赏着它的美丽，直到它凋谢，花瓣变成了暗淡的棕色。"
            if girl:
                hide kamar_bungag with dissolve
            else:
                hide kamar_bungam with dissolve
            show buff keluh sweat frusta
            show palmierproxy frown shock
            
            if "bunga_time" in buff_events:
                mc happy blush shock "那真美。"
                buff sad -frusta "我很抱歉！有时候我紧张的时候会长出花！"
                
            else:
                mc kzl sweat shock "哇！你从没告诉过我你能做到这一点！"
                mc scratch deject -shock "（但至少现在我知道伊瓦尔没有撒谎，他的孩子们确实继承了他的能力，不分性别。）"
                show palmierproxy chill frown -sweat shock
                buff sad "对不起！我真的很抱歉！它们是无害的，我发誓，我不像我父亲！"
                buff keluh sigh "它们只是在我紧张的时候会冒出来而已！"
                show buff sad -sigh
            show pboy at horzappear
            menu:
                "安抚他":
                    hide pboy
                    mc ha sweat "嘿，没关系！它们又不会吓到我。"
                    buff confused apa "等等，它们...它们不会吗？"
                    show buff sad -apa
                    mc laugh blush bloom "不会。它们只是花而已。如果非要说的话，我觉得它们很漂亮。"
                    show palmierproxy kind
                    buff wry -sweat sigh "哦，那就好。"
                    buff touched -sigh "可惜没有多少人像你这么开明。"
                "请他再做一次":
                    hide pboy
                    $ putri.points += 5
                    mc happy blush tanya "你能再做一次吗？"
                    show palmierproxy kind -tanya
                    buff huh apa "什么？"
                    mc laugh bloom "长出花朵？你能再做一次吗？"
                    buff confused both apa "我...当然可以。你不害怕吗？"
                    if kindness>= 50:
                        show buff wry -both shock
                        mc huh -blush -apa "我为什么会害怕？"
                        show palmierproxy kind
                    elif curiosity >= 50:
                        show buff frown -both shock
                        mc malu -blush sigh "说实话，我更多的是好奇而不是害怕。"
                        show palmierproxy kind -sigh
                    else:
                        show buff wry -both shock
                        mc huh -blush tanya "不是吗？"
                        mc smile -tanya "来吧，迁就我一下？"
                    mc happy "变出一朵你认为最能代表我的花。"
                    buff confused apa "最能代表你？我...我其实并不太了解花语，不过..."
                    show buff wry blush sigh
                    show palmierproxy kind shock
                    "一朵明亮的黄色花朵从莱尔的手中绽放。"
                    show palmierproxy malu blush -shock
                    buff laugh bunga "我一直觉得小苍兰很适合你。它和你的头发很相配。"
                    "看起来他确实对此有所思考。莱尔瞥了一眼你的耳朵，显得有些羞涩。"
                    "你稍微歪了歪头，示意他把花别在耳朵上。"
                    show buff wry 
                    show palmierproxy kind
                    "他微笑着将花轻轻地别在你的耳后，轻轻拂过几缕散乱的发丝。"
                    buff laugh sigh "这真的很适合你。你看起来很美。"
                    mc smile -blush sigh "我希望无论有没有这朵花，我都很美。"
                    buff huh sweat -sigh "这...嗯。"
                    show palmierproxy confused -blush tanya at center with move
                    buff keluh frusta "抱歉，我还是很惊讶你对这一切并不感到困扰。"
                    buff wry -sweat sigh "我想这是第一次有人如此欣喜地看到我父亲的花。"
                    show pboy at horzappear
                    menu:
                        "你应该多展示一下！":
                            hide pboy
                            mc happy sigh "也许你只是还没有向合适的人展示你的能力。"
                            mc laugh -sigh "我相信莱纳尔的人们可以利用你的能力。"
                            mc kind tanya "也许你可以让村民们看到除了秋天的树木之外的东西。"
                            buff lega -sigh "事实上，我曾经在孩子们面前尝试过一次。"
                            show palmierproxy sad shock
                            buff kzl frusta "我们种了一些橘子，我用魔法帮助它生长。一开始很成功，但第二天就死了。"
                            show palmierproxy frown -shock
                            buff keluh sigh "我想我可能没有我父亲那么强大。"
                            buff laugh -sigh "不过至少孩子们开心了一阵子，树长得相当大。"
                            show palmierproxy kind 
                            buff wry "我想那是那里的一些孩子第一次看到带绿叶的东西。"
                        "这些是你的能力，不是伊瓦尔的！":
                            hide pboy
                            $ putri.points += 10
                            show palmierproxy wry -blush sigh at center with move
                            buff hister both sigh "哦。我想我以前从未这样看待过。大多数人只会看一眼这些花就跑开。"
                            show palmierproxy kind -sigh
                            buff wry blush bunga "你不一样。你似乎毫不在意。"
                            buff laugh "我不知道这是好事，还是你只是个怪人。但无论如何我都很高兴。"
                            buff datar sigh "我希望其他人也能像你一样开明。"
                            show buff datar -sigh
                            

                "一笑置之":
                    hide pboy
                    mc deject sigh "你为什么对一堆花这么在意？"
                    show palmierproxy confused -sigh
                    buff eh sweat shock "\'只是一堆花\'？"
                    buff keluh -shock "你...你根本不在乎它们，对吧？它们技术上是伊瓦尔的——"
                    mc mock cling "是啊，但伊瓦尔又不在这里，不是吗？"
                    show palmierproxy mean -cling
                    buff wry -sweat sigh "我...我想是的。"
                    show palmierproxy confused sweat shock
                    buff hister blush bloom "哈...哈哈！"
                    mc wry -sweat -shock "你在笑什么？"
                    buff talk -sigh "抱歉。只是...我刚刚意识到我其实没什么好害怕的，对吧？"
                    buff amused "我父亲实际上离这里有数百万英里远。"
            show palmierproxy frown sweat shock
            buff keluh sweat frusta "顺便说一句，对于我如此心不在焉，我很抱歉。我一直在想，嗯——"
            buff sad sigh "在想码头上水手们说的话。"
            mc confused -sweat tanya "哦？他们说了什么？"
            show palmierproxy sad -tanya
            buff lega -sweat -sigh "他们称我为局外人。虽然相比人们对我的其他称呼，这已经算是温和的了，但还是..."
            buff hister "有一两周的时间，我以为我终于找到了属于自己的地方。以为成为莱纳尔的渔夫可能就是我命中注定的。"
            buff keluh sweat frusta "看来并非如此。"
            buff sad sigh "我希望外面还有另一个世界，我可以逃到那里去。一个没有巫师、猎人和所有随之而来的戏剧性事件的世界。"
            mc wry sigh "嗯，再等等，也许就会有了。"  
            buff huh -sweat apa "嗯？"
            mc smile -sigh "没什么，莱尔。"
            mc happy sigh "总之，我们应该休息一下。不管奎尔为我们准备了什么灾难，我们都需要休息！"
            show palmierproxy kind -sigh
        "等待他继续说":
            hide pboy
            if girl:
                show palmierproxy chill confused at left with moveinleft:
                    yoffset 40
            else:
                show palmierproxy chill confused at left with moveinleft:
                    yoffset 100
            show buff sad at right with move
            buff keluh sweat frusta "...你认为有些人天生就注定无法归属吗？"
            show buff sad -frusta
            mc sad sweat tanya "码头上的渔民说了什么吗？"
            buff lega sigh "这么明显吗？"
            mc side frusta "有点。你比平常更坐立不安了。"
            show palmierproxy sad -frusta
            buff sad frusta "没什么不好的。"
            buff keluh sigh "他们称我为局外人。虽然相比人们对我的其他称呼，这已经算是温和的了，但还是..."
            buff sad -sigh "有一两周的时间，我以为我终于找到了属于自己的地方。以为成为莱纳尔的渔夫可能就是我命中注定的。"
            buff keluh -sweat frusta"我想不是吧。我真的能找到属于自己的地方吗？"
            mc ow sweat frusta "莱尔——"
            show palmierproxy sad -sweat -frusta
            buff hister sweat shock "啊，抱歉。我其实并不期待得到这个问题的答案，呃..."
            buff wry -sweat sigh "我们现在该去睡觉了。"
            if "ide_quil" in quil_events:
                buff hister -sigh "如果奎尔真的要实施他的计划，我们需要休息。"
                mc confused tanya "你不打算告诉我那是什么吗？"
                show palmierproxy sad -tanya
                buff laugh blush bunga "这是个秘密，但别担心。我相信你会喜欢的。"
            else:
                mc wry sigh "确实如此。在奎尔又把我们卷入他的另一个奇怪计划之前，我们需要尽可能多地休息。"
        "奎尔问了什么？" if "ide_quil" in quil_events:
            hide pboy
            if girl:
                show palmierproxy chill wry at left with moveinleft:
                    yoffset 40
            else:
                show palmierproxy chill wry at left with moveinleft:
                    yoffset 100
            show buff frown at right with move
            buff laugh blush bunga "哦，别担心那个。这是个惊喜。"
            buff talk -bunga "是个好惊喜！"
            mc ow sweat tanya "如果是好事，那你为什么这么坐立不安？"
            show palmierproxy sad frusta
            buff wry sweat sigh "哦，没什么。只是在想码头边渔民说的一些事。"
            mc confused tanya "哦？他们说了什么？"
            show palmierproxy sad shock
            buff keluh -sigh "他们称我为局外人。虽然相比人们对我的其他称呼，这已经算是温和的了，但还是..."
            buff sad frusta "有一两周的时间，我以为我终于找到了属于自己的地方。以为成为莱纳尔的渔夫可能就是我命中注定的。"
            buff keluh sigh "我想不是吧。也许我永远都不会有一个属于自己的地方。"
            show buff sad -sigh
            mc side sweat frusta "莱尔——"
            show palmierproxy sad -sweat -frusta
            buff hister sweat sigh "啊，抱歉。我其实并不期待得到这个问题的答案，[povname]，呃..."
            buff wry -sweat -sigh "我们现在该去睡觉了。"
            if "ide_quil" in quil_events:
                buff talk "如果奎尔真的要实施他的计划，我们需要休息。"
                mc confused tanya "你不打算告诉我那是什么吗？"
                show palmierproxy sad frusta
                buff laugh blush bloom "这是个秘密，但别担心。我相信你会喜欢的。"
            else:
                mc smile blush "确实如此。在奎尔又把我们卷入他的另一个奇怪计划之前，我们需要尽可能多地休息。"
        "{s}奎尔问了什么？{/s}" if "ide_quil" not in quil_events:
            
            jump buff_curcol
    stop music
    scene bg_black with w20
    play sound "sound/effects/cloth.mp3"
    "你上床睡觉，很快就睡着了。"
    jump beach_day

label beach_day:
    $ morning = False
    $ afternoon = True
    $ evening = False
    $ night = False
    scene lake with w20
    $ calendar.next() #6th June or 7th #Tues or Wed
    play music "MUSIC/MusMus-BGM-139.mp3" fadeout 5
    show quil swim amused at center with dissolve:
        yoffset 200 
    quil laugh blush bloom "这不是我最喜欢的贝克吗！"
    "第二天，你立即和莱尔一起前往码头。"
    if "ice_rune" in my_events:
        galleryunlock pantai
        scene pantai with flashbulb:
            subpixel True
            truecenter zoom 1.0
            easein 1.5 truecenter zoom 0.5
        "男孩们都穿着泳装，在湖边戏水，不知怎的设法漂浮在水中，使得水只到他们的腰部。"
    else:
        galleryunlock pantai_kid
        scene pantai_kid with flashbulb:
            subpixel True
            truecenter zoom 1.0
            easein 1.5 truecenter zoom 0.5
        "你没想到会看到奎尔穿着一条紧身泳裤，带着一个大粉色火烈鸟游泳圈，周围还围着几十个小孩，但你确实看到了这一幕。"
    "菲亚和普莉姆可以在后面看到，他们在水中嬉戏，仿佛施了魔法一般，周围开始形成小小的顽皮浪花。"
    if "ice_rune" not in my_events:
        "莱纳尔的孩子们也加入了这场欢乐。有些人在玩骑马打仗，其他人则为了抢沙滩球而争斗。"
    quil "来加入我们的乐趣吧，亲爱的，水简直太棒了！"
    show side_p n at pic
    mc "这是怎么回事？为什么会有浪花？！你们怎么都能漂浮在水面上？"
    hide side_p
    red "奎尔和阿什姆给湖施了魔法，这里基本上就是我们私人的小海滩！哇呼！"
    red "来吧，莱尔，振作起来！"
    buff "哎哟！"
    play sound "sound/effects/bump.mp3"
    scene lake with vpunch
    show buff swim huh shock at center with dissolve:
        yoffset 770
    show red swim laugh blush bunga at left with moveinleft:
        yoffset 330
    show croissant swim laugh blush bloom at right with moveinright:
        yoffset 500
    "塞恩把一个沙滩球直接砸在莱尔脸上。他大笑着，和菲亚一起催促莱尔和他们一起玩排球。"
    show red grin 
    fia mock -blush cling "来吧，大块头，女生对男生。还是说你害怕和一个只有你一半大小的女孩比赛？"
    buff lega apa "什么...？"
    $ NPC = "普莉姆"
    show prim_ smile at pic
    npc "这是沙滩日！来玩得开心点，我们发誓会少用点符文...好吧，至少暂时是这样！"
    hide prim_
    show buff eh shock
    show side_p n at pic
    mc "去吧，莱尔，玩得开心。"
    hide side_p
    buff laugh blush bunga "我...好吧。"
    $ fia_events.append("pantai_day")
    if "ice_rune" in my_events:
        scene pantai with dissolve:
            truecenter zoom 0.5
    else:
        scene pantai_kid with dissolve:
            truecenter zoom 0.5
    "莱尔跑向正在准备比赛的菲亚和塞恩。"
    if "bond" in fia_events:
        "你微笑着，看到菲亚和塞恩明显通过他们的灵魂联结放大了他们的快乐。"
        "灵魂联结对他们来说似乎进行得很顺利。"
    elif "bonding_me" in red_events:
        "一阵刺痛沿着你的脊椎升起，你能感受到塞恩的喜悦在体内流淌。他刚刚在第一次扣球就得分了。"
    else:
        "塞恩的尖牙在阳光下闪耀，他刚刚在第一次扣球就得分了。"
    scene lake with dissolve
    show tom swim amused at center with dissolve:
        yoffset 190
    tom pfft apa "要来点椰子吗，亲爱的[povname]？"
    "阿什姆端着饮料走了过来。当你看向一旁时，你可以看到码头上摆放着各种各样的饮料。"
    tom calm blow "我想我们应该趁能用的时候好好利用这个湖。"
    if "ice_rune" in my_events:
        tom smile -blow "我们仍然会按计划冻结它，但在那之前，为什么不好好享受一下呢？"
    else:
        tom amused -blow "莱纳尔的孩子们需要一些乐趣。"
    show pboy at horzappear
    menu:
        "这很冒险。":
            hide pboy
            show side_p nf at pic
            mc "老师们没说什么吗？"
            hide side_p
            tom whine sweat blow "没有。我想没有威廉在身边，他们还在像无头苍蝇一样乱转。"
            tom ha frusta "不是说海德温做得不好，只是她，嗯……不太适合这个角色。"
            tom pfft -sweat -frusta "而且技术上来说，我确实得到了凯普勒的许可。他只是说如果我们的小海滩日有什么有趣的事发生，我需要向他汇报。"
            show tom calm 
            show side_p nm at pic
            mc "他当然会这么说。"
            hide side_p
            tom wry "我们最好给他一些可以谈论的东西。你为什么不去好好享受一下呢？"
            tom calm "如果有谁应该得到属于自己的时间，那就是你。"
            show tom smile
            show pboy at horzappear
            menu:
                "我正在享受呢。":
                    hide pboy
                    show side_p n at pic
                    mc "我正在享受呢。我有一杯饮料，还有一个有魅力的男人就坐在我旁边。"
                    mc "我还需要什么呢？"
                    hide side_p
                    jump tom_pantai
                "好吧，我去了。":
                    hide pboy
                    show side_p n at pic
                    mc "我想我会的。再见阿什姆，别喝得太醉，好吗？"
                    hide side_p
                    tom amused blow "我绝不会的！"
                    show tom pfft -blow

        "这感觉真好。":
            hide pboy
            tom calm bunga "是啊，不是吗？奎尔的主意并不总是最好的，但这次他做得不错。"
            tom whine frusta "我几乎要高兴了，如果不是因为他的三角泳裤小得令人不快的话。"
            show tom sad 
            show side_p nm at pic
            mc "如果我是你，我会感恩的。至少他没有裸体！"
            hide side_p
            tom ejek cling "哦，但是这一天还很年轻，不是吗？"
            tom pfft blow "不过，说够了奎尔可能裸体的话题。你应该去享受一下，玩得开心点。"
            show tom smile -blow
            show pboy at horzappear
            menu:
                "我正在享受呢。":
                    hide pboy
                    show side_p n at pic
                    mc "我正在享受呢。我有一杯饮料，还有一个有魅力的男人就坐在我旁边。"
                    mc "我还需要什么呢？"
                    hide side_p
                    jump tom_pantai
                "好吧，我去了。":
                    hide pboy
                    show side_p n at pic
                    mc "我想我会的。再见阿什姆，别喝得太醉，好吗？"
                    hide side_p
                    tom amused blow "我绝不会的！"
                    show tom smile -blow
        "你看起来很好。":
            hide pboy
            $ ibu.points += 10
            tom ejek cling "是吗？"
            show tom pfft -cling
            show side_p n at pic
            mc "是的，你穿得少一些看起来很好。"
            show side_p ns 
            mc "啊，等等，我不是那个意思！"
            hide side_p
            tom calm blush bunga "哈哈。我也可以对你说同样的话。"
            tom amused cling "虽然在我眼里你总是完美的。"
            show tom pfft -cling
            if "bonding_me" in red_events:
                show side_p n at pic
                if girl:
                    if girl2 or kln:
                        mc "哈！阿什姆，你在和一个已婚女人调情吗？多么丑闻啊！"
                    else:
                        mc "哈！阿什姆，你在和一个已婚男人调情吗？多么丑闻啊！"
                else:
                    if girl2:
                        mc "哈！阿什姆，你在和一个已婚女人调情吗？多么丑闻啊！"
                    else:
                        mc "哈！阿什姆，你在和一个已婚男人调情吗？多么丑闻啊！"    
                hide side_p
                tom amused cling "我只是在陈述事实，亲爱的[nickname]。"
                tom calm blush bloom "当如此惊艳的艺术品就呈现在我面前时，不去欣赏是不可能的。"
            else:
                tom calm blush bloom "是的，我指的不仅仅是[povname]。"
            tom amused cling "有时我在想，科尔她是不是创造了你就是为了毁掉我。"
            show tom eh both shock
            $ renpy.pause()
            tom sad frusta "……好吧，我可能喝了太多的PinaColada。请忽略我刚才说的话。"
            show tom capek
            show pboy at horzappear
            menu:
                "不，我不会忽略的。":
                    hide pboy
                    show tom sad 
                    show side_p nm at pic
                    mc "不，我不会忽略的。已经很久没有男人对我如此倾倒了。"
                    show tom pfft blow
                    show side_p n
                    mc "尤其是一个如此赏心悦目的人。但我会为你省去尴尬，现在就离开。"
                    hide side_p
                "这就是为什么我要保持清醒！":
                    hide pboy
                    show tom wry blow
                    show side_p n at pic
                    mc "哈哈！别担心，在我的酗酒时期，我说过和做过更糟糕的事。"
                    hide side_p
                    tom ejek -both cling "哦？请讲讲看。"
                    show tom eh both shock
                    show side_p nm at pic
                    mc "好吧。嗯，我曾经一晚上给五十个男人口交。不过，并不是全都到最后。"
                    hide side_p
                    show tom sad sweat frusta
                    play sound "sound/effects/plate.mp3"
                    "阿什姆吐出了他的饮料，咳嗽着开始拍打胸口寻求缓解。"
                    tom eh apa "对不起，但是，五十个？！"
                    tom giggle -sweat -apa "那真是……令人印象深刻。你是怎么数的？"
                    show tom wry 
                    show side_p nm at pic
                    mc "那就是那种派对，他们会在你的大腿或其他地方写上数字，然后嗯……"
                    show side_p n
                    mc "我按顺序来的。"
                    hide side_p
                    tom eh both shock "哦，我……哦。"
                    show tom wry blow
                    show side_p n at pic
                    mc "哈哈，没想到你会这么震惊。"
                    hide side_p
                    tom giggle -blow "我只是感到惊讶，我想。"
                    tom pfft blush "虽然狂欢派对在精灵族中很常见，但我从未有兴趣参与其中。"
                    show side_p nm at pic
                    mc "这确实不适合每个人。那是在菲亚去世几周后。我想尝试一些事情，任何事情来填补我心中的空洞。"
                    show side_p ns 
                    mc "那很有趣，但我应该知道如此字面意义地填补它是不会有用的。"
                    hide side_p
                    tom sigh -blush blow "嗯。我想我理解。当[povname]甩了我之后，我基本上直接跳进了任何愿意接纳我的人的怀抱。"
                    tom pfft -blow "它暂时缓解了痛苦，但绝对不是一种治愈。"
                    show side_p n at pic
                    mc "嘿，人生就是在不断学习中成长，对吧？"
                    hide side_p
                    tom smile "没错。"    
                    tom pfft "总之，别管我了。你应该去和其他人一起，趁现在好好享受这片水域。"
                "别担心，我会的。":
                    hide pboy
                    tom amused blush blow "谢谢你。"
                    tom pfft -blush -blow "现在请别管我。你应该去和其他人一起，趁现在好好享受这片水域。"
                    tom wry "如果有谁应该得到属于自己的时间，那就是你。"
                    show pboy at horzappear
                    menu:
                        "我正在享受呢。":
                            hide pboy
                            show side_p n at pic
                            mc "我正在享受呢。我有一杯饮料，还有一个有魅力的男人就坐在我旁边。"
                            show side_p nm
                            mc "我还需要什么呢？"
                            hide side_p
                            jump tom_pantai
                        "好吧，我去了。":
                            hide pboy
                            show side_p n at pic
                            mc "我想我会的。再见阿什姆，别喝得太醉，好吗？"
                            hide side_p
                            tom giggle "我绝不会的！"
    scene lake with dissolve
    jump pantai_bunch

label pantai_bunch:
    "你涉水穿过湖面，环顾四周，思考着自己的选择。"
    "在湖的一侧，你看到菲亚和普莉姆难得没有在玩她们的符文。相反，她们正在堆雪人。"
    "或者说，是水人。她们把水塑造成各种各样的生物形状。"
    play sound "sound/effects/splash.wav"
    "你朝她们划去。菲亚的一个水人突然爆裂成一群漂浮的泡泡。"
    show croissant swim kerja blush bloom at center with dissolve:
        yoffset 500
    fia laugh "啊哈哈哈！"
    fia happy shock "嘿，唠叨鬼，想和我一起做些水人吗？"
    show croissant kerja -shock
    show side_p n at pic
    mc "我只是看看。你和普莉姆似乎玩得很开心。"
    hide side_p
    fia pain sigh "是啊。奎尔难得有个不错的主意。在回莱纳尔之前，我可以稍微休息一下。"
    show croissant kerja -sigh
    show side_p nf at pic
    mc "哦，你要回那里去？"
    hide side_p
    show prim_ smile at pic
    $ NPC = "菲亚"
    npc "菲亚和我正在帮助一位老太太，斯泰西·假名。"
    hide prim_
    show side_p ns at pic
    mc "（...好吧，这听起来一点也不可疑。）"
    show side_p nf 
    mc "听着，这可能会让你感到震惊，因为你不像我这样是个经验丰富的猎人，但是斯泰西·假名这个名字听起来有点..."
    hide side_p
    fia pity apa "假？"
    fia happy -apa "我知道，我一开始也不相信她，但显然她有一个家谱，整整十代假名家族。"
    if povname == "帕尔米耶":
        fia mock -blush cling "况且，你有什么资格说别人？你的名字就是一种糕点的名字！"
    else:
        fia laugh -blush "但她是一位人人都认识的无害甜心老太太，而且她做的饼干是最棒的，所以别对我进入你那小小的过度保护[kk]模式，好吗？"
    show side_p nf at pic
    mc "你们到底在帮她做什么？"
    hide side_p
    fia mmh sweat sigh "给岛上的人分发饼干，还有听她回忆往事。她在40多岁的时候失去了一个儿子。"
    if "ice_rune" in my_events:
        fia sad -sigh "我猜她希望他会和其他湖中居民一起出现，但运气不佳。"
    else:
        fia sad -sigh "她的孙子也失踪了，我们四处打听，但没人知道任何线索。"
    show side_p n at pic
    mc "我明白了。好吧，菲亚，你要小心，好吗？别相信那个村子里的任何人。"
    hide side_p
    fia pain sweat frusta "我知道我知道。天啊...不用这么多疑。" 
    fia hmph -sweat sigh "我会没事的，唠叨鬼，普莉姆和我能照顾好彼此。"
    show croissant smile -sigh
    show prim_ smile at pic
    npc "没错！"
    hide prim_
    show side_p n at pic
    mc "好吧，那就这样。总之，玩得开心，我要去看看其他人在做什么，好吗？"
    hide side_p
    fia laugh blush bloom "随你便。普莉姆，比赛谁先到码头？"
    show prim_ smile at pic
    npc "来啊！"
    hide prim_
    hide croissant with dissolve
    "菲亚赢了，她先到达码头。阿什姆拿着毛巾和饮料迎接这两位年轻女士。她们坐在水边聊天。"
    show buff swim laugh blush bloom at center with dissolve:
        yoffset 770
    show red swim frown sigh at left with moveinleft:
        yoffset 330
    show quil swim laugh blush spark at right with moveinright:
        yoffset 200
    if "ice_rune" not in my_events:
        "与此同时，莱尔正在和孩子们玩捉迷藏游戏。"
    else:
        "与此同时，莱尔展示了他作为水獭的天赋，仰面朝天睡在水面上，同时在肚子上平衡着一个喝了一半的椰子。"
    "塞恩似乎陷入了沉思，凝视着水面，而奎尔则懒洋洋地躺在他的粉色火烈鸟形状的浮床上。"
    show pboy at horzappear
    menu:
        "加入莱尔":
            hide pboy
            jump lyall_pantai
        "加入塞恩":
            hide pboy
            jump red_pantai
        "加入奎尔":
            hide pboy
            jump putih_pantai
       
label putih_pantai:
    scene lake with dissolve
    "你朝奎尔走去，他划着浮床向你靠近，以一种相当不雅的方式伸展着双腿。"
    show quil swim laugh blush spark at center with dissolve:
        yoffset 200
    quil amused -blush cling "要不要加入我？"
    show pboy at horzappear
    menu:
        "跳上他的浮床":
            hide pboy
            show quil fluster both shock
            show side_p n at pic
            mc "我想我会的。"
            hide side_p
            play sound "sound/effects/splash.wav"
            if not girl:
                galleryunlock stres
                show stres with dissolve:
                    truecenter zoom 1.0
                    easein 2.0 truecenter zoom 0.5
            "你跳上了他的浮床，把他固定在原地，你们的四肢在这么小的空间里纠缠在一起。"
            "他的脸颊变得比他的粉色火烈鸟浮床还要粉红，瞪大眼睛盯着你俯视的身影。"
            quil sulk both frusta "这——这不是我的本意！"
            mc mock blush cling "真的吗？可是邀请我的人是你啊。"
            if "ice_rune" not in my_events:
                quil ow sigh "啊哈，是的，但这实在不太得体，周围还有孩子呢！"
            mc laugh bunga "我只是和我的朋友一起坐在浮圈上而已。"
            mc mock cling "又不是我在骑你。"
            mc kind -blush -cling "除非这就是你那大脑袋里想象的东西。"
            play sound "sound/effects/bump.mp3"

            quil sulk frusta "呃，我知道了，快下去！"
            
            if not girl:
                hide stres with dissolve
            
            show quil wry blush -frusta

        "旋转他的浮圈":
            hide pboy
            quil grit sweat frusta "等等，太快了！"
            show quil sulk 
            "你开始旋转、旋转、再旋转奎尔的浮圈，而他试图挣脱。"
            "当他抓住你的手时，你停了下来，他紧紧抓着你，就像抓住了救生艇。"
            quil fluster "我知道了，快停下，不然我就把早餐全吐你身上！"
    show quil sad sweat sigh
    show side_p n at pic
    mc "啊哈哈。对不起，对不起，逗你玩总是那么有趣，奎尔！"
    hide side_p
    if "tunangan" in quil_events:
        quil kzl frusta "道歉不接受。"
        quil talk -sweat cling "不过，我知道你可以做点什么来弥补我。"
        show side_p nf at pic
        mc "请别告诉我又是另一个人情。每次和你说话我都觉得自己在和魔鬼打交道。"
        hide side_p
        quil laugh blush spark "只是一个简单的请求，亲爱的，有人甚至可能认为这是一种荣幸。"
        quil wink -blush cling "不是每天都有机会见到我的父母。"
        show quil wry -cling
        show side_p nf at pic
        mc "你的父母？哦...哦，糟糕。"
        hide side_p
        quil hister "不过这是好的那种糟糕。我们订婚的消息终于传到了我父母的耳朵里。"
        quil panik sigh "他们想见见那个偷走他们独子的人。"
        show quil datar -sigh
        show side_p nf at pic
        mc "呃。他们不是已经\'认识\'我了吗？我是说，你们两个是青梅竹马。"
        hide side_p
        quil sly "是的，但那是以前。那时他们只把你看作某个暴发户平民，而不是即将加入英克威尔贵族家族的人！"
        show quil amused
        show side_p ns at pic
        mc "那么他们什么时候期望我们拜访？"
        hide side_p
        quil laugh bunga "只要你有空就行，亲爱的。希望是明天，假设我们不会再遇到任何巫师的麻烦。"
        quil amused apa "我想我们终于应该休息一下了，你不这么认为吗？"
        $ quil_events.append("tun_talk")
    else:
        quil mock blush sigh "嗯，好吧，既然是你的要求，我想我可以同意。"
        show quil datar -blush 
        if "date2_done" not in quil_events:
            quil wink cling "不过如果你心情好的话，你也可以为我做个人情。"
            show side_p nf at pic
            mc "人情？"
            hide side_p
            quil hister bunga "我可能在这里那里散布了一些消息，可能会误导我的父母认为我们要订婚了。"
            show quil panik sweat -bunga
            show side_p nf at pic
            mc "你干了什么？！"
            hide side_p
            $ quil_events.append("date2_done")
            $ quil_events.append("tun_talk")
            quil wink -sweat cling "哦，别那么震惊，亲爱的。这可是我啊。事实上，你现在应该预料到更多混乱才对。"
            quil hister -cling "不管怎样，我父母现在想见你。了解一下那个试图爬进英克威尔家族的孩子。"
            show quil datar
            show side_p nf at pic
            mc "唉，那么他们什么时候期望我们拜访？"
            hide side_p
            quil mock "只要你有空就行，亲爱的。希望是明天，假设我们不会再遇到任何巫师的麻烦。"
            quil smile sigh "我想我们终于应该休息一下了，你不这么认为吗？"
        else:
            quil wink cling "你真幸运，我这么喜欢你。"
            show side_p ns at pic
            mc "我不认为这是幸运，更像是不幸吧。"
            hide side_p
            quil tantrum sweat frusta "真没礼貌。我还正准备夸你今天看起来多么迷人呢。你的损失。"
    quil talk blush cling "现在，我希望你能享受我的这片小天堂。"
    quil malu sweat sigh "我本想开个传送门到卡斯特里，但恐怕现在没多少符文墨水了。"
    show quil frown -sweat -sigh
    show side_p nf at pic
    mc "哦，我猜情况会变得更糟，是吧？现在艾欧走了。"
    hide side_p
    if "Ice_rune" in my_events:
        quil panik sweat frusta "当然。我无法想象一旦我们冻结湖面会发生什么样的混乱。"
        quil fluster "但这是她的请求，我想要尊重她的死。我不禁感到有点责任。"
        quil frown sigh -sweat "你知道，最近我觉得巫师们更多是被误解而不是危险。但我想这可能是一种亵渎的想法。"
        show pboy at horzappear
        menu:
            "不，这不是。":
                hide pboy
                show side_p nf at pic
                mc "我不这么认为。事实上，我觉得你按照艾欧的要求冻结湖面是在做正确的事。"
                hide side_p
                quil panik both shock "啊哈，谢谢你这么说。我...我需要这样的鼓励。"
                quil sulk sweat frusta "冻结湖面意味着结束墨水供应。我不确定没有符文魔法支撑，伊格尼亚会发生什么。"
                quil err sigh "魔法一直是我们的卖点，是我们不被沃特克帝国欺负的原因。"
                quil sulk -sigh "但如果我们的魔法被玷污了，我们为了自己的利益牺牲了科尔的幸福，那么...也许我们从一开始就不配拥有魔法。"
                quil hister blush "啊，听听我，变得多愁善感了。怀疑我的选择是没有意义的。我们现在能做的就是继续前进，继续生活。"
                quil talk -blush sigh "无论结果如何。"
                show quil smile -sigh
                show side_p n at pic
                mc "我知道。但还是要谢谢你这么做，奎尔。你比我想象的要勇敢和善良得多。"
                hide side_p
                quil wink spark "我知道。我还聪明，而且魅力无法抗拒。很多人忘记了无法抗拒这一点。"
                show side_p nm at pic
                mc "哈哈，好吧，好吧。是的，你是个聪明又让人无法抗拒的小恶魔，奎尔。"
                hide side_p
                quil laugh blush bloom "谢谢，现在再给我一句恭维的话，我们就可以结束了。"
                show side_p nf at pic
                mc "再来一句？靠，我觉得我的脑力已经不够用了。"
                quil amused -blush sigh "哼。厚脸皮。"
            "她们仍然很危险。":
                hide pboy
                quil heh cling "也许吧，但显然我们也是。"
                quil tantrum sweat frusta "谁能想到，仅仅是修女和神父，还是那些温顺的人，竟然能奴役一位真正的神。"
                quil sad sigh "我的意思是，我开始觉得巫师们比我想象的更容易被误解。"
                show side_p nf at pic
                mc "也许吧。你知道吗，奎尔，你比我想象的要善良得多。"
                hide side_p
                quil wink -sweat spark "你忘了迷人、聪明和美丽，不过这次我就不计较了。"
        
    else:
        quil fluster sweat frusta "她的死无关紧要。随着科尔的离去，墨水无论如何都会用尽。"
        quil panik -sweat sigh "我不该低估[povname]和[dia]的诱惑技巧。我还是不敢相信[kamu]与一位真正的神建立了联系。"
        quil smile -sigh "我几乎要嫉妒了。"
    show quil laugh blush bloom
    if "ice_rune" in my_events:
        quil "但是说够了这个。我们还有其他事情要做，不是吗？"
        quil talk -blush cling "我想是时候进入正题了。"
        jump quil_beku
    else:
        quil "但是说够了这个。"
        quil amused -blush sigh "恐怕我们无忧无虑的夏日时光已经结束了。"
        jump hed_nangkap
label lyall_pantai:
    scene lake with dissolve
    show buff swim blush bloom at center with dissolve:
        yoffset 770
    if "ice_rune" in my_events:
        "莱尔平静地漂浮在水中，仰面朝天。他脸上挂着灿烂的笑容。"
        show pboy at horzappear
        menu:
            "享受独处的时光吗？":
                hide pboy
                show buff wry shock
                show side_p n at pic
                mc "享受你的\'独处时光\'吗？"
                hide side_p
                buff laugh bunga "是的，我从未注意到天空是如此蓝。"
                buff datar -blush sigh "真美。"
                show side_p n at pic
                show buff eh both shock
                mc "几乎和你金色的眼睛一样美。"
                hide side_p
                buff hister -shock "哦，呃...谢谢。"
                show buff touched -blush
            "漂到他身边":
                hide pboy
                $ putri.points += 5
                "你尽可能保持安静，仰面漂浮，慢慢向他靠近。"
                if putri.points >= 30:
                    buff wry sigh "很舒服，不是吗？水在轻抚我的头皮，天气也很完美。"
                    show side_p n at pic
                    mc "确实如此。有时当我在这样的开阔水域游泳时，我喜欢想象自己是某个豪华大宅的主人，有一个巨大的游泳池作为浴缸。"
                    hide side_p
                    buff amused -blush apa "那不是意味着现在你的浴缸里有一群陌生人吗？"
                    show buff touched -apa
                    show side_p n at pic
                    mc "哦，对，嗯...共享洗澡水对环境有好处，只要没有人在里面拉屎就行。"
                    hide side_p
                    buff hister blush "哈哈，[povname]，你有时候真奇怪。"
                    show buff touched -blush
                else:
                    play sound "sound/effects/splash.wav"
                    buff eh sweat shock"哇！不要！" with vpunch
                    show buff kzl frusta
                    "莱尔慌乱地挥舞着手臂，溅起水花。你的出现似乎惊扰了他。"
                    show buff frown -sweat shock
                    show side_p nf at pic
                    mc "嘿，嘿，冷静点。只是我而已。"
                    hide side_p
                    buff touched both sigh"哦，[povname]，抱歉，我以为你是条海蛇之类的。"
                    show buff wry -both -sigh
                    show side_p nm at pic
                    mc "我是说，在水里我确实看起来像一块苍白的湿纸巾，所以我能理解。"
                    hide side_p
                    buff hister "啊哈。"
                    show buff wry
            "把他当作浮板":
                hide pboy
                $ putri.points += 10
                show buff eh both shock
                play sound "sound/effects/splash.wav"
                show side_p n at pic
                mc "跳！"
                hide side_p
                buff keluh sweat frusta"Ah!"
                "你跳到莱尔的肚子上，把他当作你私人的浮板。"
                show buff hister blush bloom
                "出人意料的是，他对你荒唐的行为笑了起来。"
                if putri.points < 30:
                    "由于你们两个并不是特别亲密，你本以为他肯定会把你推开。"
                buff amused apa "玩得开心吗？"
                show buff datar -apa
                show side_p n at pic
                mc "我的浮板又强壮又结实，能够抵御即将到来的巨浪！"
                show side_p nm
                mc "我当然玩得很开心！"
                hide side_p
                show buff hister bunga with vpunch
                play sound "sound/effects/splash.wav"
                "莱尔笑了笑，然后潜入水中，把你也拉了下去。"
                show side_p nf at pic
                mc "啊！"
                hide side_p
                if girl:
                    show botai_ce with rain1:
                        truecenter zoom 1.0
                        easein 2.0 truecenter zoom 0.5
                    galleryunlock botai_ce
                "你们在水中对视了一瞬。他金色的虹膜在发光，也许这是他巫师血统的另一个独特特征。"
                "他扶着你的腰帮你重新浮上水面。他似乎很高兴你陪他玩。"
                if girl:
                    hide botai_ce with rain1
                buff wry -blush sigh "我很高兴你没有弃船而逃。"
                show side_p n at pic
                mc "抛弃如此英俊的船只？我怎么可能这么做！"
                hide side_p
                "当他咯咯笑时，你夸张地叹了口气。"
    else:
        buff talk -blush apa"马可！"
        $ NPC = "孩子"
        npc "波罗！"
        buff laugh -apa "马可！"
        "你看到莱尔闭着眼睛，在孩子们玩马可波罗游戏时追逐他们。"
        show pboy at horzappear
        menu:
            "偷偷抱住莱尔":
                hide pboy
                
                buff keluh sweat shock"哇哦！"
                play sound "sound/effects/splash.wav"
                if girl:
                    show botai_ce with rain1:
                        truecenter zoom 1.0
                        easein 2.0 truecenter zoom 0.5
                    galleryunlock botai_ce
                if putri.points >= 50:
                    
                    "当你紧紧搂住他的腰时，莱尔向后倒去。他回头惊讶地看着你，但对你突如其来的袭击笑了起来。"
                    buff hister sigh"[povname]！你吓到我了！"
                    buff amused blush apa "你知道如果你想来玩的话，可以直接加入的！"
                    show buff wry -apa
                    show side_p n at pic
                    mc "是啊，但那样你就不会感到惊讶了，不是吗？"
                    hide side_p
                else:
                    "当你紧紧搂住他的腰时，莱尔向后倒去。他回头惊讶地看着你，似乎对你突如其来的袭击感到恼火。"
                    buff keluh sweat frusta "哦，是你啊。"
                    show buff frown -sweat sigh
                    show side_p nf at pic
                    mc "你本可以在打招呼时表现得更热情一点，但是没错，嗨，是我。"
                    hide side_p
                hide botai_ce with dissolve
            "在他耳边低语":
                hide pboy
                show buff eh both shock
                show side_p nf at pic
                mc "波罗。"
                hide side_p
                buff keluh sweat frusta "啊啊啊！"
                play sound "sound/effects/splash.wav"
                "莱尔尖叫着，手舞足蹈地扑通一声栽进了水里。当你再次看到他时，他的脸变得通红。"
                buff keluh sweat shock"[povname]！"
                show side_p nm at pic
                mc "没想到我的声音对你有这么大的影响。"
                hide side_p
                buff wry both sigh"我...唔。"
                "他似乎被你直白的调情弄得很尴尬。很少有人对他表现出这样的亲昵。"
                show buff datar blush -sigh

            "波罗！":
                hide pboy
                buff laugh blush bunga "抓到你了！"
                play sound "sound/effects/bump.mp3"
                "莱尔循着你的声音，可能以为你是其中一个孩子。他把你拉进一个紧紧的熊抱中。"
                if girl:
                    buff eh -blush apa "等等，你怎么这么瘦？"
                else:
                    buff eh -blush apa "等等，这是谁？你们这些孩子什么时候变得这么强壮了？"
                show side_p n at pic
                mc "谢谢，我经常锻炼。"
                hide side_p
                buff keluh sweat shock "哇哦！"
                play sound "sound/effects/splash.wav"
                "莱尔震惊地把手举到空中，当他终于意识到自己抱着的究竟是谁时，脸涨得通红。"
                buff hister both frusta"[povname]！非常抱歉！我以为你是其中一个孩子。"
                show pboy at horzappear
                menu:
                    "我很喜欢。":
                        hide pboy
                        show buff wry blush sigh
                        show side_p n at pic
                        mc "不，不。我应该感谢你才对。一个强壮的大男人刚刚给了我一个舒服的拥抱。我还能要求什么呢？"
                        hide side_p
                        if putri.points >= 50:
                            buff hister -sigh "啊哈。嗯...抱你也很舒服。"
                            show buff datar -blush
                        else:
                            buff talk both sigh "好吧，现在我觉得你欠我一个道歉。"
                            show buff datar -blush -sigh
                            show side_p n at pic
                            mc "啊，我为欣赏你惊人的身材而道歉，您这位肌肉发达的殿下。"
                            hide side_p
                            buff hister "哈哈，好吧，也许不是那种道歉！"
                            show buff wry
                    "玩得开心吗？":
                        hide pboy
                        buff hister blush sigh "是啊，是啊。我已经很久没有这样放松过了。"
                        buff talk -sigh "我以前从未在海里玩过，感觉很不错。好吧，严格来说这是一个湖泊，但差不多了。"
                        show buff wry -blush
                        show side_p nf at pic
                        mc "等等，你从未在海里玩过？"
                        hide side_p
                        buff amused "没有，我在莱纳尔玩过几次，但那是与这个湖相连的。所以再说一次，那不是海洋。"
                        show side_p n at pic
                        mc "嗯。提醒我下次带你去那里。你需要感受沙子钻进你的脚趾间，爬上你的短裤，才能获得完整的海滩体验！"
                        hide side_p
                        buff amused sigh "沙子进入短裤似乎很不方便。"
                        show buff datar -sigh
                        show side_p n at pic
                        mc "确实如此，但那才是完整的海滩体验。还有海浪。阿什姆和奎尔在这里制造的\'浪\'可不够格！"
                        hide side_p
                        buff laugh "哈哈。那我很期待。"
                        show buff datar
    if "ide_quil" in quil_events:
        show buff wry blush -sigh
        show side_p nm at pic
        mc "我没想到奎尔会这么做。我猜这家伙偶尔也能有个好主意。"
        show side_p n
        mc "我有时候不明白他那漂亮的小脑袋里在想什么。他做事通常要么是0要么是100。"
        hide side_p
        buff hister -blush bunga "他确实有点强势，但看起来相当温柔。当奎尔请我帮忙时，我很惊讶，但我同样很高兴他提出了这个建议。"
        show buff datar 
        show side_p n at pic
        mc "你说得对。"
        hide side_p
    else:
        show side_p nm at pic
        mc "我很高兴我们有机会做这件事。"
        hide side_p
    show buff wry blush sigh
    show side_p n at pic
    mc "在经历了每周一次的生死遭遇后，我确实需要一个小小的休息。"
    hide side_p
    buff talk -blush -sigh "我理解你，虽然我想我的经历没有你的那么危险。"
    buff amused "这话可是出自一个杀人成性、种族屠杀狂魔的儿子之口。"
    show buff datar
    show side_p nf at pic
    mc "嗯，种族灭绝的疯子，是吗？"
    hide side_p
    show pboy at horzappear
    menu:
        "为伊瓦尔辩护":
            hide pboy
            $ putri.points -= 50
            if putri.points <= 0:
                $ putri.points = 0
            show buff kzl sweat shock
            show side_p nf at pic
            mc "也许你下定论太快了。"
            hide side_p
            buff scold frusta "抱歉？我想有两个荒芜的国家会完全不同意你刚才的说法。"
            show buff kzl
            show side_p nf at pic
            mc "我知道，但是——"
            mc "我对死亡地带战争知之甚少，但似乎猎人们也并没有完全遵守规则。"
            mc "到底是什么引发了战争？"
            hide side_p
            buff keluh sigh "嗯，说法不一，但普遍接受的理论是，他们把大部分剩余的纯血族逼到了绝境，因此伊瓦尔为了撤退而毁灭了那片土地，但是..."
            show side_p nf at pic
            mc "但是？"
            hide side_p
            buff confused frusta "我...我确实听说他们用我一个姐妹的头颅作为诱饵，想引我父亲采取行动。他们把她的头颅插在长矛上，像旗帜一样使用。"
            buff keluh "拉米亚，她...她是我姐妹中最好战的一个。她喜欢打架，也喜欢在猎人中挑起麻烦。"
            buff sad -sweat sigh "但是...但这并不意味着她应该被那样展示。嗯。"
            show side_p nf at pic
            mc "看到了吗？我的意思是，我不知道，我想如果我看到有人炫耀我死去姐妹的头颅，我也会发疯的，但这只是我的想法。"
            hide side_p
            buff scold sweat frusta "问题不仅仅在于战争。还在于他对待我、伊尔夫和我所有兄弟的方式！他把我们当成垃圾，当成他花朵的养料。"
            buff "他玩弄我们的心智，让我们吃饱穿暖，但随后又砍下我们的头颅，把我们变成他永恒的奴隶。这一切为了什么？！"
            buff kzl sigh "他甚至不看我们一眼，只是偶尔瞥我们一眼，总是带着那种轻蔑的怒容。我收到的第一个拥抱是来自伊尔夫的！"
            buff scold frusta "我从父亲那里得到的所有\'爱的\'触碰，不是打在我脸上的巴掌，就是他用手背打得我嘴唇青肿。"
            buff "我的姐妹们把我们当玩物，同时沐浴在父亲的宠爱中。我在他们脚下卑躬屈膝，只希望能得到他们的残羹剩饭！"
            buff "别告诉我他做的是某种扭曲的爱！你不像我那样了解他！"
            buff "活在恐惧中18年，害怕成为下一个被他亲手斩首的倒霉儿子！"
            buff "如果他是个有爱心的\'父亲\'，那他就应该做得更好！"
            show buff kzl -frusta
            "你没有带上伊瓦尔给你的花，但不知为何，你感到心中有一丝颤动。"
            "仿佛听到伊瓦尔用悲伤庄严的声音低语，\'我知道\'。"
            "你不禁想知道。这只是你的想象，还是他在你身上留下了魔法的痕迹？"

        "同意莱尔的观点":
            hide pboy
            show buff wry sigh
            show side_p nf at pic
            mc "我无法反驳。我真的很高兴你能够摆脱那种处境，莱尔。"
            hide side_p
            buff keluh sweat -sigh "我也是。有时我仍然感到恐惧。害怕伊瓦尔找到我，一击就杀死我。"
            buff sad frusta "有时我想，也许被饶恕是他一直以来的计划，只是为了折磨我的心智。这样当他看到我眼中生命的光芒消逝时，会更加甜美。"
            show buff sigh
            show side_p nf at pic
            mc "我想你并不想知道那个问题的答案。"
            hide side_p
            buff frown -sigh "是的，你说得对，我不想知道。"

    buff keluh sweat frusta "啊，抱歉，我又让情绪控制了自己。"
    show buff sad -frusta
    show side_p nm at pic
    mc "没关系，释放情绪是健康的。看看奎尔和他的厚脸皮就知道了！"
    hide side_p
    buff hister blush sigh "啊哈哈。好吧，这一点我无法反驳。"
    show buff eh sweat shock at right with move
    show quil swim wink cling at left with moveinleft:
        yoffset 200
    quil "亲爱的，如果你们要夸奖我，至少当着我的面说吧。"
    show quil amused -cling
    "奎尔一边唱着歌，一边向你们飘来。"
    quil ejek "顺便说一句，我很不想破坏你们这小小的亲密时刻。"
    if "ice_rune" in my_events:
        quil amused "但我想是时候去参加主要活动了。"
        jump quil_beku
    else:
        quil malu sigh "但我相信我们这无忧无虑的夏日时光已经结束了。"
        jump hed_nangkap
label tom_pantai:
    if "date4_done" in tom_events:
        if "bonding_me" in red_events:
            tom amused blush cling "小心点，我可不想让塞恩误会。"
            tom calm -blush blow "顺便说一句，我为你们感到高兴。你们两个很适合彼此。"
            tom pfft -blow "一段令人羡慕的关系。"
            show side_p n at pic
            mc "谢谢。不过，你和你的[povname]之间可能还有机会。"
            hide side_p
            tom sigh sweat frusta "也许吧，但我很怀疑。在发现[dia]所有的谎言之后，嗯...我不确定该相信什么了。"
            tom whine blow "[nickname]真是能言善辩。我不确定[dia]的恭维是真心的，还是只是另一种操纵我的方式。"
            show tom sad -blow
            show side_p nf at pic 
            mc "谎言中总是包含一些真相。"
            hide side_p
            tom lega -sweat blow "...我希望如此。"
            show tom frown -blow
            show side_p nm at pic
            mc "但是出于好奇，[dia]最喜欢的搭讪台词是什么？"
            hide side_p
            tom amused cling "嗯。有一个我很喜欢，虽然我现在不确定它是否是真的了。"
            show tom pfft -cling
            show side_p nf at pic
            mc "哦？"
            hide side_p
            tom calm "只是简单的三个字。"
            tom amused cling "\'我爱你\'。"
            tom pfft -cling "[povname]可能正在外面剖开巫师的肚子，或者砍下某个可怜的半身人巫师的脑袋。"
            tom sigh blow "但只要我听到那三个甜蜜的词，我就会永远回到[dia]的怀抱。"
            tom sad sweat frusta "那些我甚至不确定是否还有任何意义的词。也许它们从来就没有意义。"
            show pboy at horzappear
            menu:
                "让我们来看看吧。":
                    hide pboy
                    show tom giggle -sweat -frusta
                    show side_p nf at pic
                    mc "别担心，我保证我们会把那个混蛋叫醒的。然后你就可以亲自问他了。"
                    hide side_p
                    tom amused cling "我期待着那一天的到来。"
                "我不这么认为。":
                    hide pboy
                    show tom pfft -sweat shock
                    show side_p nf at pic
                    mc "你知道，失去你这样的人是[dia]的损失。阿什姆，你值得更好的。"
                    hide side_p
                    tom calm blow "我知道。谢谢你让我意识到这一点。"
            show tom kzl sweat shock at right with move
            show quil swim laugh at left with moveinleft:
                yoffset 200
            quil "哦，亲爱的，我真不想破坏这么感人的时刻。"
            show tom ha -sweat -shock
            if "ice_rune" in my_events:
                quil amused "但我想是时候去参加主要活动了。"
                jump quil_beku
            else:
                quil malu sigh "但我相信我们这无忧无虑的夏日时光已经结束了。"
                jump hed_nangkap
        elif "nembak_cuy" in tom_events:
            tom pfft blush apa "嗯，你说你不介意我们成为独家关系时，你不是在开玩笑，对吧？"
            show side_p n at pic
            mc "我告诉过你我不是在开玩笑。"
            hide side_p
            tom giggle both blow "这一切似乎太不真实了。我想我有时还是把你错当成[povname]了。"
            tom amused blush -blow "[povname]很会说话，总是知道该说什么来激怒我，让[dia]如愿以偿。"
            tom calm cling "不过我自己也有几招绝活。"
            show pboy at horzappear
            menu:
                "愿意分享一下吗？":
                    hide pboy
                    tom pfft -blush apa "在钓我夸你吗？我还以为你永远不会问呢。"
                    show tom calm -apa
                    "阿什姆清了清嗓子，握住了你的右手。"
                    tom smile cling "我愿意用世界上所有的金子和珍宝来换取握住你的手的机会。"
                    show side_p nm at pic
                    mc "嗯，有点一般啊。而且，你已经在握着我的手了。还是免费的！还有什么别的吗？"
                    hide side_p
                    tom calm blow "哈哈，你真是个难伺候的顾客，不是吗？好吧，那让我再试一次。"
                    tom amused cling "如果我每想到你一次就能得到一朵玫瑰，我拥有的花园就会让美丽女巫的花园相形见绌。"
                    show side_p n at pic
                    mc "不错，不错。但这些话你可以对任何人说。你有什么专门用来对我说的吗？"
                    hide side_p
                    tom pfft apa "专门对你说的？嗯..."
                    show tom calm -apa
                    "阿什姆将他的手掌贴在你的手上，然后与你十指相扣。一个紧密而令人安心的握持。"
                    tom wry blush "十年来，我以为我知道爱和忠诚是什么感觉。"
                    tom calm "直到遇见你，我才发现我之前只是浅尝辄止。"
                    show side_p nf at pic
                    mc "...和我在一起？"
                    hide side_p
                    tom pfft blow "别担心。我不会用\'我爱你\'吓到你的，至少现在不会。"
                    tom calm -blow "但我知道我喜欢这样。我喜欢我们。无论你允许这成为什么。我知道时间短暂，有一天你必须回到你自己的世界。"
                    tom amused cling "但在那之前，我恳求能拥有你的荣幸，作为回报，你也将拥有我。哪怕我们偷来的时光如此短暂。"
                    show tom smile -cling
                    show side_p nm at pic
                    mc "..."
                    hide side_p
                    show pboy at horzappear
                    menu:
                        "和我一起来我的世界吧。":
                            hide pboy
                            show tom eh both shock
                            show side_p nm at pic
                            mc "和我一起来我的世界吧？"
                            show side_p nf
                            show tom wry blush blow
                            mc "我是说，我知道要放下这里的一切很难，但如果你能...如果你愿意。那么也许我们还有未来。"
                            hide side_p
                            tom giggle -blow "如果说这个想法从未在我脑海中出现过，那我就是在撒谎..."
                            if "date4_done" in tom_events:
                                tom sad -blush blow "尤其是在得知我父亲的事之后。如果他真的来自你的世界，那么...也许我能以某种方式找到他。"
                                show tom wry -blow
                                show side_p n at pic
                                mc "对吧？而且我发誓我的世界里的人要友善得多。"
                                show side_p nf
                                mc "我是说，种族主义者仍然存在，但更多的是关于肤色的问题，现在我说出来听起来更蠢了，但是..."
                                show side_p n 
                                mc "重点是，没人会在意你是否是精灵。事实上，我打赌如果人们发现了，他们会爱上你的，所以——"
                                hide side_p
                                tom calm blush blow "哼。别担心。我只在乎一个人的爱。你的爱。"
                            else:
                                tom sad sweat frusta "但我在这里还有家人。我的妈妈...我会考虑的。"
                                show tom wry blush -frusta
                                show side_p n at pic
                                mc "请一定要考虑。我...我想我离不开你就无法离开这个地方。我需要你。"
                                hide side_p
                        "我很乐意。":
                            hide pboy
                            tom wry blush cling "我也是。比任何事都重要。"
                        "天哪，你真肉麻！":
                            hide pboy
                            tom pfft blush blow "亲爱的，是你先问的。而且，当这是真心话的时候，它真的算肉麻吗？"
                    show tom calm blush bloom
                    "阿什姆捧起你的脸颊，倾身向前准备亲吻。"
                    show tom eh both shock
                    show quil swim amused cling at left with moveinleft:
                        yoffset 200
                    "这个吻被你那白发朋友和他那讨厌的粉色火烈鸟泳圈粗鲁地打断了。"
                    show tom kzl sweat frusta at right with move

                "你最喜欢什么？":
                    hide pboy
                    tom pfft blush apa "我最喜欢什么？哦，这很简单。"
                    tom calm -blush -apa "三个神奇的小词。"
                    tom smile cling "\'我爱你\'。"
                    tom giggle sweat blow "[povname]可能正在外面剖开巫师的肚子，或者砍下某个可怜的半身人巫师的脑袋。"
                    tom wry -blow "但只要我听到那三个甜蜜的词，我就会永远回到[dia]的怀抱。"
                    tom sad frusta "那些我甚至不确定是否还有任何意义的词。也许它们从来就没有意义。"
                    show pboy at horzappear
                    menu:
                        "让我们来看看吧。":
                            hide pboy
                            show tom wry -sweat blow
                            show side_p n at pic
                            mc "别担心，我保证我们会把那个混蛋叫醒的。然后你就可以亲自问他了。"
                            hide side_p
                            tom calm blush blow "我期待着那一天的到来。"
                            show tom pfft -blow
                        "我不这么认为。":
                            hide pboy
                            show tom pfft blush shock
                            show side_p n at pic
                            mc "你知道，失去你这样的人是[dia]的损失。阿什姆，你值得更好的。"
                            hide side_p
                            tom calm blow "我知道。谢谢你让我意识到这一点。"
            show tom kzl sweat shock
            show quil swim laugh at left with moveinleft:
                yoffset 200
            quil "哦，亲爱的，我真不想破坏这么感人的时刻。"
            show tom ha -sweat -shock at right with move
            if "ice_rune" in my_events:
                quil amused "但我想是时候去参加主要活动了。"
                jump quil_beku
            else:
                quil malu sigh "但我相信我们这无忧无虑的夏日时光已经结束了。"
                jump hed_nangkap
        else:
            jump tom_beach_idel
    else:
        jump tom_beach_idel
label tom_beach_idel:
    tom ejek blush cling "小心点，如果我不了解情况的话，我会以为你在跟我调情呢。"
    show tom wry -cling
    show pboy at horzappear
    menu clingkuh:
        "{s}那如果我真的在调情呢？{/s}" if "companion" in my_events and "companion" not in tom_events:
            
            jump clingkuh
        "那如果我真的在调情呢？" if "companion" not in my_events or "companion" in tom_events:
            hide pboy
            $ ibu.points += 5
            tom eh both shock "哦！呃，我——"
            tom giggle blush bloom "我很乐意。"
            show side_p n at pic
            mc "只是别把我当成[povname]的替代品，好吗？"
            hide side_p
            tom wry blow "别担心。你远非如此。我甚至为自己没有更早注意到这些差异而感到愚蠢。"
            tom calm bunga "你善良、诚实。这些都是[povname]所不具备的。"
            tom capek sweat frusta "每次[kamu]说\'我爱你\'的时候，这些都蒙蔽了我的双眼。"
            tom sigh blow "十年来，我以为我知道爱情和忠诚是什么感觉。"
            tom pfft blush -blow "直到遇见你，我才发现我之前只是浅尝辄止。"
            show side_p nf at pic
            mc "...和我在一起？"
            hide side_p
            tom calm bunga "别担心，我不会用\'我爱你\'吓到你的，至少现在不会。"
            tom pfft "但我知道我喜欢这样。我喜欢我们。无论你允许这成为什么。我知道时间短暂，有一天你必须回到你自己的世界。"
            tom amused "但在那之前，让我拥有你，你也拥有我。即使我们偷来的时光可能很短暂。"
            show tom wry
            show side_p nf at pic
            mc "..."
            hide side_p
            show pboy at horzappear
            menu pili_b_tom:
                "{s}跟我一起来我的世界吧。{/s}" if "date4_done" in tom_events:
                    
                    jump pili_b_tom
                "和我一起来我的世界吧。" if "date4_done" in tom_events:
                    hide pboy
                    $ ibu.points += 5
                    show tom eh both shock
                    show side_p nm at pic
                    mc "和我一起来我的世界吧？"
                    show tom wry blush blow
                    show side_p nf
                    mc "我是说，我知道要放下这里的一切很难，但如果你能...如果你愿意。那么也许我们还有未来。"
                    hide side_p
                    tom giggle blush bunga "如果说这个想法从未在我脑海中出现过，那我就是在撒谎..."
                    if "date4_done" in tom_events:
                        tom wry -blush blow "特别是在艾希德娜说了那些关于我父亲的话之后。如果他真的来自你的世界，那么...也许我能以某种方式找到他。"
                        show side_p n at pic
                        mc "对吧？我发誓我的世界里的人要友善得多。我是说，种族主义者仍然存在，但更多的是关于肤色的问题。"
                        mc "现在我说出来后听起来更蠢了，但是..."
                        show side_p nf 
                        mc "重点是，没人会在意你是否是精灵。事实上，我打赌如果人们发现了，他们会爱上你的，所以——"
                        hide side_p
                        tom calm blush bloom "哼。别担心。我只在乎一个人的爱。你的爱。"
                    tom pfft blow "但我在这里还有家人。我的妈妈...我会考虑的。"
                    show tom wry -blow
                    show side_p n at pic
                    mc "请继续。"
                    hide side_p
                    show tom eh both shock 
                    show quil swim mock at left with moveinleft:
                        yoffset 200
                "我很乐意。":
                    hide pboy
                    tom giggle blush bloom "我也是。比任何事都重要。"
                    show tom eh both shock 
                    show quil swim mock at left with moveinleft:
                        yoffset 200
                "天哪，你真肉麻！":
                    hide pboy
                    $ ibu.points -= 5
                    tom pfft -blush blow "亲爱的，是你先问的。而且，当这是真心话的时候，它真的算肉麻吗？"
            show tom wry blush bunga
            "阿什姆捧起你的脸颊，倾身向前准备亲吻。"
            show tom eh both shock 
            show quil swim mock at left with moveinleft:
                yoffset 200
            "一个被你那白发朋友和他那讨厌的粉色火烈鸟游泳圈粗鲁打断的吻！"
        "哦，我可不想那样！":
            hide pboy
            $ ibu.points -= 10
            if "companion" in my_events:
                tom pfft blush blow "最好不要让你的伴侣吃醋。"
            else:
                tom pfft blush blow "啊哈。不，你不会的。"
            tom giggle -blow "不过，如果你真的那样做了，我会感到荣幸的。任何男人能得到你都是幸运的，[povname]。"
            tom wry "我只是感激能有机会被称为朋友。"
            show side_p n at pic
            mc "这——嗯，谢谢。"
            hide side_p
            show tom eh both shock 
            show quil swim mock at left with moveinleft:
                yoffset 200
    show tom kzl sweat frusta at right with move
    quil wink cling "哦，亲爱的，我真不想破坏这么感人的时刻。"
    if "ice_rune" in my_events:
        quil sly -cling "但我想是时候去参加主要活动了。"
        jump quil_beku
    else:
        quil laugh -cling "但我相信我们这无忧无虑的夏日时光已经结束了。"
        jump hed_nangkap
label red_pantai:
    scene lake with dissolve
    show red swim mls sigh at center with dissolve:
        yoffset 330
    "你涉水走向塞恩，他仍然沉浸在思绪中。他的背上布满了交错的伤疤。"
    if "bonding_me" in red_events:
        "这是你在之前亲密时刻中没有注意到的。"
    "小小的白色凸起玷污了他原本完美的蜜色皮肤。"
    show red kaget sweat shock
    show side_p nm at pic
    mc "...在想什么心事吗？"
    hide side_p
    red hister both sigh "[povname]！哦，你吓到我了！"
    if "bonding_me" in red_events:
        red wry apa "没想到有了这种联系还会这样。为什么我没有感觉到你？"
        show side_p nf at pic
        show red kaget sweat shock
        mc "可能是因为你感觉像一个黑暗的深渊。"
        show red sad frusta
        mc "你还好吗？你的情绪似乎...嗯，麻木。"
        hide side_p
    else:
        show red frown -sigh
    show side_p nf at pic
    mc "你在想什么？"
    hide side_p
    if "vamp_visit" in red_events:
        red ew both frusta "啊...其实很蠢，没什么你需要担心的。"
        show red sad sweat shock
        show side_p nf at pic
        mc "可我还是在这里担心，所以..."
        hide side_p
        red ew frusta "是啊，我在想我妈妈的事。"
        if "date_cekup" in red_events:
            red grit "我知道上次我说不想谈这个。但这并不意味着我已经停止想她了。"     
        red ngeles sigh "她仍然被帝国控制着，被那个傲慢的大祭司玩弄于股掌之间。"
        red mls -sweat -sigh "我知道我应该放手。血液污染的过程是不可逆的，她将永远是个邪血者，但是，我——"
        red ngeles frusta "我内心的一部分希望你能见到她。真正的她。不是那个被污染的形态。"
        red sayang -frusta "我想她会喜欢你的。"
        red wry sigh "妈妈总说麻烦制造者才是最好的伙伴。"
        show pboy at horzappear
        menu:
            "跟我说说她吧。":
                hide pboy
                $ mrh.points += 10
                red ngeles sweat apa "我妈妈？嗯...真的没什么好说的。"
                if "pile" in red_events:
                    red hister -sweat sigh "我已经告诉你重要的部分了。"
                    red bingung apa "你还想知道什么？"
                show red sad -sweat sigh
                show side_p nf at pic
                mc "我不知道。她是什么样的人，你们之间有什么特别的事，你们母子之间的亲密时刻？"
                hide side_p
                red mock cling "嗯。她很强大，而且出奇的专制。几个世纪的指挥官生涯让她变成了这样。"
                red hister blush -cling "她曾经称我为她的小奇迹，因为她从未计划要生我。"
                red wry -blush sigh "她之前经历过几次流产，从未期望能再次怀孕。但后来有一天，我爸带她去维也纳旅馆来了一次浪漫约会，然后嘣！"
                red amused -sigh "我就是这样长大的。她教会了我如何战斗，如何握剑，如何保护弱小，以及如何在不失去自我的情况下向帝国低头。"
                red laugh "与此同时，我父亲是典型的战利品丈夫，一个英俊的男人！"
                red huh sweat sigh "至少在我的记忆中是这样。他在我四岁时就去世了。"
                show side_p nf at pic
                mc "对不起。"
                hide side_p
                red hister -sigh "没关系，他是自然死亡的。"
                red ew frusta "意思是国王想要他上床，他拒绝了，所以一根木桩穿透了他的心脏。"
                show side_p nf at pic
                mc "哦，塞恩。"
                hide side_p
                red ngeles sigh "别用那种眼神看我。至少比我母亲经历的要好。"
                show red sad -sigh
                if "pile" not in red_events:
                    $ red_events.append("pile")
                    red "你看，我本应成为阿列克谢王子的私人血骑士。"
                    red lelah "他很在意外表，而且比我小几岁，所以他亲自挑选了我。"
                    red sad sweat "我想让我妈妈感到骄傲，所以我答应了。但他没告诉我，为了继续下去，我必须吸干一个无辜陌生人的血。"
                    red wry "他让我杀一个6岁的孩子，你能想象吗？一个该死的扎着猪尾辫、满脸雀斑、大蓝眼睛的6岁小女孩。"
                    red ngeles "就在她母亲面前，那个母亲是他内部圈子里偶尔传阅的一个受宠的O型阳性血袋。"
                    red ew "我曾经看着那个女人在被一个吸血鬼扔给另一个时还顺从地微笑。从不抱怨，甚至没有一丝蔑视的迹象。"
                    red ngeles "但当他们带来她的女儿让我杀死时...她尖叫了，那是一种令人心碎的、源于本能的叫声。"
                    red sad sigh "...我做不到，而我的母亲为此付出了代价。"
                    red -sigh "违抗君主命令的惩罚是死刑，但她抗议并讨价还价，换取了流放。"
                    red ngeles "代价是她的人性。"
                red ew sweat frusta "有时我后悔拒绝了阿列克谢。如果我有勇气去杀人，至少我的母亲会——"
                show red frown -sweat shock
                show side_p n at pic
                mc "别这么说。你通过成为她培养的那个人来尊重你的母亲。一个善良温和的人，笑起来露出太多牙齿。"
                hide side_p
                red cowo blush bunga "嘿，我为这些牙齿感到骄傲，这可是伊格尼亚最好的一口珍珠白！"
                show side_p n at pic
                mc "我相信。"
                hide side_p
                red hister sigh "呵呵。"
                red happy -sigh "谢谢你，[povname]。我已经很久没有决定回忆过去了。能回忆起美好的部分真好..."
                show red amused
                show side_p n at pic
                mc "我喜欢相信痛苦中总有一些乐趣，或者至少有些东西你可以试着去享受。"
                hide side_p
                red grin both apa "现在你听起来像个受虐狂。"
                show red wry -both -apa
                show side_p n at pic
                mc "我确实有一点。但重点是，你不应该只关注你的痛苦。过去塑造了现在的你。"
                mc "我不知道你怎么想，但我喜欢你现在成为的这个人。"
                hide side_p
                red calm blush sigh "...我想这是有人对我说过的最好的话了。"
                show red datar bloom
                "你紧紧握住塞恩的手，你们的手指相互交织。"
                "在你的触碰下，他放松了下来，他的恐惧和后悔似乎消散了。"
                "也许他所需要的只是有人告诉他，他做了正确的事。"
            "有治愈的方法吗？":
                hide pboy
                red ew sweat frusta "没有。血液污染是不可逆的。就连绝望女巫也试图逆转这个过程。"
                red lelah sigh "但那只是一个彻底的失败。实际上，我有点为那个巫师感到难过。"
                red huh -sigh "他爱上了莫洛纳公爵夫人，她因释放年轻的血袋而被变成了邪血者。"
                red kzl "他无法接受。开始一个接一个地杀死公爵和贵族。同时一直在寻找治愈他爱人的方法。"
                red mls sigh "最后，威廉校长击败了他。至少这是我妈妈告诉我的。"
                red ngeles -sigh"那时我曾经崇拜猎巫人。当时，持有杀戮执照的修女和牧师听起来很酷。"
                red ew frusta "现在，就不那么觉得了。"
                red hister -sweat sigh "但我还是会选择成为一个猎人，而不是血骑士。"
                if "pile" not in red_events:
                    $ red_events.append("pile")
                    red sad -sigh "你看，我本应成为阿列克谢王子的私人血骑士。"
                    red lelah "他很在意外表，而且比我小几岁，所以他亲自挑选了我。"
                    red sad sweat "我想让我妈妈感到骄傲，所以我答应了。但他没告诉我，为了继续下去，我必须吸干一个无辜陌生人的血。"
                    red wry "他让我杀一个6岁的孩子，你能想象吗？一个该死的扎着猪尾辫、满脸雀斑、大蓝眼睛的6岁小女孩。"
                    red ngeles "就在她母亲面前，那个母亲是他内部圈子里偶尔传阅的一个受宠的O型阳性血袋。"
                    red ew "我曾经看着那个女人在被一个吸血鬼扔给另一个时还顺从地微笑。从不抱怨，甚至没有一丝蔑视的迹象。"
                    red ngeles "但当他们带来她的女儿让我杀死时...她尖叫了，那是一种令人心碎的、源于本能的叫声。"
                    red sad sigh "...我做不到，而我的母亲为此付出了代价。"
                    red -sigh "违抗君主命令的惩罚是死刑，但她抗议并讨价还价，换取了流放。"
                    red ngeles "代价是她的人性。"
                show red frown -sweat shock
                show side_p n at pic
                mc "我相信你妈妈为你放过那个女孩而感到骄傲。为你没有成为血骑士而骄傲。"
                hide side_p
                red laugh blush bunga "我也这么认为。"
                "你紧紧握住塞恩的手，你们的手指相互交织。"
                "在你的触碰下，他放松了下来，他的恐惧和后悔慢慢消散了。"
                "也许他所需要的只是有人告诉他，他做了正确的事。"
            "也许你会在我的世界里找到她。":
                hide pboy
                show red frown -sweat shock
                show side_p n at pic
                mc "我知道这不一样，但当我们回到我的世界时，那里应该也有一个你妈妈的版本。"
                mc "再说一遍，我知道这不一样，但是，如果我们真的找到她，你想一起喝杯咖啡聊聊天吗？"
                hide side_p
                red amused apa "所以你是说，回到你的世界后，你想做的第一件事就是找到某个中年妇女，和她一起吃午餐？"
                show red wry -apa
                show side_p n at pic
                mc "她不只是某个随机的中年妇女。她是你的妈妈。好吧，至少是她的一个版本。"
                mc "我认为这仍然意味着什么。至少，你可以再次见到你的妈妈。作为一个无聊的普通人类。"
                hide side_p
                red laugh blush bloom "无聊听起来不错。那个计划，再次见到我的妈妈，我真的很喜欢这个想法。"
                show red sayang 
                show side_p n at pic
                mc "那我们一定会一起找到她的。"
                hide side_p
                show red wry shock
                "你紧紧握住塞恩的手，你们的手指相互交织。"
                show red hister bunga
                "你能感受到塞恩的幸福通过你们的羁绊辐射出来，他看着你的眼睛，笑容越来越灿烂。"
                "他在你的唇上轻轻地印下一个温柔的吻。他的嘴唇可能感觉冰冷，但他的热情在你体内燃烧。"
                red sayang -bunga "一起。"
        show red sad sweat shock
        show quil swim wink cling at left with moveinleft:
            yoffset 200
        quil "哦，亲爱的，我真不想破坏这么感人的时刻。"
        show red huh -shock at right with move
        if "ice_rune" in my_events:
            quil sly cling "但我想是时候去参加主要活动了。"
            jump quil_beku
        else:
            quil amused sigh "但我相信我们这无忧无虑的夏日时光已经结束了。"
            jump hed_nangkap
    else:
        red ew sweat frusta "别笑，但是...我妈妈。"
        show red sad sigh
        show side_p nf at pic
        mc "你妈妈？"
        hide side_p
        if "bond" in fia_events:
            red hister both -sigh "现在我和菲亚建立了羁绊，嗯，我希望能把她介绍给我妈妈。我想她会喜欢菲亚的。"
            red mock -both cling "一个真正的烈女，不像宫廷里那些无聊的超级女性化的淑女。"
            red ew sweat frusta "但后来我想起来，嗯...我不能这样做，对吧？她是个邪血族。"
        else:
            red sad sigh "现在我摆脱了你血液的吸引，我意识到失去控制是多么糟糕的感觉。"
            red ngeles -sigh "屈服于内心的野兽...如果可以的话，我也想让我妈妈摆脱同样的命运，但是..."
            red ew sweat frusta"...但她是个邪血族。我不确定是否有办法拯救她。"
        red lelah sigh "她不记得我了。科尔，她甚至不记得自己的名字。"
        show red sad -sigh
        if "bond" in fia_events:
            show side_p nf at pic
            mc "哦...好吧——"
            hide side_p
            show pboy at horzappear
            menu:
                "我相信她会赞同的。":
                    hide pboy
                    red hister blush sigh "我也这么认为。"
                    show red wry -sigh
                "有治愈的方法吗？":
                    hide pboy
                    red ew sweat frusta "没有。血液污染是不可逆的。就连绝望女巫也试图逆转这个过程。"
                    red kzl sigh "但那只是一个彻底的失败。实际上，我有点为那个巫师感到难过。"
                    red ngeles -sigh "他爱上了莫洛纳公爵夫人，她因释放年轻的血袋而被变成了邪血者。"
                    red sad "他无法接受。开始一个接一个地杀死公爵和贵族。同时一直在寻找治愈他爱人的方法。"
                    red wry -sweat "最后，威廉校长击败了他。至少这是我妈妈告诉我的。"
                    red hister both "那时候我很崇拜猎巫人。当时，有杀人执照的修女和牧师听起来很酷。"
                    red ngeles sweat frusta "现在，就不那么觉得了。"
                    red amused -sweat -sigh "但我还是会选择成为一个猎人，而不是血骑士。"
                    if "pile" not in red_events:
                        $ red_events.append("pile")
                        red "你看，我本应成为阿列克谢王子的私人血骑士。"
                        red lelah "他很在意外表，而且比我小几岁，所以他亲自挑选了我。"
                        red sad sweat "我想让我妈妈感到骄傲，所以我答应了。但他没告诉我，为了继续下去，我必须吸干一个无辜陌生人的血。"
                        red wry "他让我杀一个6岁的孩子，你能想象吗？一个该死的扎着猪尾辫、满脸雀斑、大蓝眼睛的6岁小女孩。"
                        red ngeles "就在她母亲面前，那个母亲是他内部圈子里偶尔传阅的一个受宠的O型阳性血袋。"
                        red ew "我曾经看着那个女人顺从地微笑，从一个吸血鬼传到另一个吸血鬼手中。从不抱怨，甚至没有一丝轻蔑的迹象。"
                        red ngeles "但当他们带来她的女儿让我杀死时...她尖叫了，那是一种令人心碎的、源于本能的叫声。"
                        red sad sigh "...我做不到，而我的母亲为此付出了代价。"
                        red -sigh "违抗君主命令的惩罚是死刑，但她抗议并讨价还价，换取了流放。"
                        red ngeles "代价是她的人性。"
                    show red wry -sweat shock
                    show side_p n at pic
                    mc "我相信你妈妈为你放过那个女孩而感到骄傲。为你没有成为血骑士而骄傲。"
                    hide side_p
                    red laugh blush bunga "我也这么认为。"
                "你再见过她吗？":
                    hide pboy
                    red ngeles sweat frusta "没有。再也没有。自从她长出利爪，基本上变成一条4米长的龙之后就再也没见过。"
                    red ew "庆幸你从未见过邪血族吧。当然，一开始他们看起来很威严，在那里展开巨大的翅膀飞翔。"
                    red sad sigh "然后你想起他们曾经是人。或者至少，嗯，是我这种人。"
        else:
            show side_p nf at pic
            mc "你会找到办法的，塞恩。你会找到治愈她的方法。"
            hide side_p
            red wry sigh "你觉得呢？"
            show side_p nf at pic
            mc "我知道。"
            hide side_p
            red cowo blush -sigh "谢谢，兄弟。当你这么说的时候，不知怎的感觉是真的。"
            red wry -blush "可能是因为你自己一直在尝试不可能的事情。"
        red sayang both sigh "不过，今天的消沉已经够了。抱歉搞砸了气氛。"
        red grin -both -sigh "这样的日子应该充满欢乐和笑声，当然还要加上一点酒精！"
        "塞恩抓起附近的沙滩球，直接扔向你的胸口。"
        red mock cling "来吧，让我们玩点有趣的，[povname]。让我们看看你是否比那边的软男孩莱尔打得更好。"
        show side_p n at pic
        mc "来啊！"
        hide side_p
        show red kaget shock
        "你和塞恩打了一下午排球，直到奎尔大声打断了你们。"
        show quil swim laugh at left with moveinleft:
            yoffset 200
        show red amused -shock at right with move
        quil heh "哦亲爱的，我真不想破坏你们的乐趣。"
        if "ice_rune" in my_events:       
            quil amused sigh "但我想是时候去参加主要活动了。"
            jump quil_beku
        else:
            quil wry sigh "但我相信我们这无忧无虑的夏日时光已经结束了。"
            jump hed_nangkap
label hed_nangkap:
    play sound "sound/effects/walk.mp3"
    scene lake with dissolve
    show hedwin mad frusta at center with dissolve:
        yoffset 200
    "奎尔指向码头上瞪着你们的海德温女士。她的额头上闪烁着一个明亮的黄色符文，你认出那是\'闪电之神\'。"
    stop sound
    show hedwin evil cling
    if "ice_rune" in my_events:
        hed "男孩们，菲亚，普莉姆，你们有三秒钟的时间，否则我就要电击这些水域和里面的一切。"
    else:
        hed "男孩们，菲亚，普莉姆，年轻无辜的莱纳尔孩子们，你们有三秒钟的时间，否则我就要电击这些水域和里面的一切。"
    show red swim huh at right with moveinright:
        yoffset 330
        xzoom -1.0
    red ngeles sweat shock "哇，哇！海德温女士，你不是认真的吧？！"
    hed mad frusta "1..."
    show tom swim ha frusta at left with moveinleft:
        yoffset 190
        xzoom -1.0
    tom "我想她终于崩溃了。"
    hed "2..."
    show red sad sweat shock
    show tom eh sweat shock
    hed evil cling "所有人立刻离开水面，快！"
    stop music fadeout 2.0
    play sound "sound/effects/glitch3.mp3"
    scene lake with flashbulb
    "你们都从湖里清退出来，海德温确实释放了符文的力量。"
    "天哪，这些老师真的让你们时刻保持警惕。"
    stop music
    scene bg_black with w20
    "你回到宿舍，结束了这一天。"
    jump morning
label quil_beku:
    $ quil_events.append("beku")
    scene lake with dissolve
    play sound "sound/effects/splash.wav"
    show red swim grin blush cling at center with moveinright:
        yoffset 330
        xzoom -1.0
    play sound "sound/effects/punch.mp3"
    red "举起手来！" 
    show side_p nf at pic
    mc "啊？" with vpunch
    hide side_p
    hide red with moveoutleft
    play sound "sound/effects/swosh.mp3"
    "塞恩的翅膀弹出，把你从水中抬起，同时阿什姆的双手掀起一阵风，将莱尔举到空中。"
    "阿什姆把腿抬到水面上，而普莉姆和菲亚仍然在齐腰深的水中。"
    show croissant swim smile at center with dissolve:
        yoffset 500
    fia happy apa "主要活动？你是什么意思——"
    play sound "sound/effects/freeze.mp3"
    queue sound "sound/effects/jelly.mp3"
    fia jijik sweat shock"啊啊啊！" with vpunch
    galleryunlock whale_close
    scene whale_close with flashbulb:
        yalign 1.0
        easeout 5.0 yalign 0.1
    "奎尔把他的小浮圈转到湖中央，指尖闪烁着明亮的蓝光。"
    "当奎尔摆出姿势时，温度骤降。他抬起一条腿，一只巨大的冰鲸从水中跃出，将湖面冻结成冰。"
    show whale_close:
        yalign 0.1
        easeout 5.0 yalign 0.95
    quil "该死，真的没有我做不到的事，是吧？"
    fia "奎尔，你这个混蛋！"
    $ NPC = "普莉姆"
    npc "我好冷！"
    $ NPC = "???"
    "菲亚和普莉姆都尖叫起来。还没等她们反应过来，就被困在了冰里。"
    show side_p ns at pic
    mc "（所以这就是为什么奎尔要让菲亚来加入的原因。）"
    show side_p nf
    mc "这一点都不好笑，立刻把我妹妹放出来！"
    hide side_p
    scene lake with dissolve
    show tom swim amused bunga at center with dissolve:
        yoffset 190
    show red swim laugh blush bloom at left with dissolve:
        yoffset 330
    tom giggle "其实有点好笑。"
    red hister "完全同意。"
    show tom pfft blow
    if "bond" in fia_events:
        
        red wry sigh "虽然我没想到寒冷也会通过契约传递。坚持住，老婆，我这就来救你。"
        show croissant swim jijik frusta at right with dissolve:
            yoffset 500
        play sound "sound/effects/glass.wav"
        fia gross "别那么叫我！啊！" with vpunch
    else:
        red wry sigh "不过我确实为她们感到难过。等等。"
        play sound "sound/effects/glass.wav"
        show croissant swim jijik frusta at right with dissolve:
            yoffset 500
        fia gross "Ah!" with vpunch
    hide red with dissolve 
    hide tom with dissolve
    play sound "sound/effects/bomb.wav"
    "塞恩召唤出一把火焰刀，切开菲亚周围的冰，帮她从水中出来，而阿什姆则在帮助普莉姆。"
    stop sound
    "在他们处理女孩们的情况时，你注意到湖泊内外已经完全冻结，没有任何水残留——变成了一整块冰。"
    "莱尔不得不过来帮忙，从女孩们的腿上凿冰，而菲亚则紧紧抱着你取暖。"
    show quil swim laugh blush bloom at left with dissolve:
        yoffset 200
    quil mock "哦，我没想到这个符文会这么有效。"
    show quil hister
    fia kzl sweat ang "我发誓，奎尔，这事过后我要杀了你！"
    quil panik sweat cling "我想这就是我该离开的信号了。"
    quil wink blush spark "再见了，我亲爱的们！"
    play sound "sound/effects/tile.mp3"
    hide quil with moveoutleft
    show croissant mad at center with move
    "奎尔腰间套着他的粉色火烈鸟游泳圈，跑上了楼梯。"
    fia frusta "给我回来！！！" with vpunch
    stop sound
    hide croissant with dissolve
    "菲亚一获得自由就扑向奎尔，开始了无情的追逐。"
    show side_q skul smile at pic
    quil "不要啊！救命，我是个落难少女！你们这些大块头男人在哪里啊？！"
    hide side_q
    show buff swim wry sweat at center with dissolve:
        yoffset 770
    buff amused -sweat sigh "为什么我觉得他好像很享受她的愤怒？"
    show side_p n at pic
    mc "天啊，我希望不是，但老实说，这解释了很多事。"
    hide side_p
    buff confused sweat apa "但是奎尔先生为什么要冻结湖面呢？"
    show side_p nf at pic
    mc "哦，呃..."
    if kindness >= 50:
        show side_p nm 
        show buff frown -sweat shock
        mc "这只是为了防止孩子们跑到湖边。我们不知道发生了什么，可能有人把孩子们从岛上绑架走了。"
        hide side_p
        buff talk apa "哦，是老师们让你这么做的吗？"
        show buff datar -apa
        show side_p nf at pic
        mc "是的？"
        hide side_p
        show tom swim frown at right with moveinright:
            yoffset 190
    elif honesty >= 50:
        show side_p n
        mc "哦，幻想女巫想让我冻结湖面，作为交换，我基本上要杀了她。"
        hide side_p
        buff laugh blush "哈哈。很有趣，[povname]。"
        show buff wry sigh
        show tom swim frown at right with moveinright:
            yoffset 190
        tom pfft sweat "啊哈哈，是的...{i}很有趣{/i}。"
        show tom sad blow
    else:
        hide side_p
        show tom swim frown at right with moveinright:
            yoffset 190
        tom ejek cling "只是海德温女士的要求，当然是为了莱纳尔和我们同学的安全。"
        show tom pfft sweat -cling
        buff wry sigh "哦，好吧...那就这样吧。"
    show red swim ew at left with moveinleft:
        yoffset 330
    show tom frown -sweat shock
    red sweat frusta "不过我们最好在老师们来之前离开。我不知道你怎么想，但我已经厌倦了被人吼了。"
    show red sad 
    show buff frown -sweat -sigh
    tom ha blow"同意。来吧，我们最好在其他人发现之前离开。"
    scene bg_black with w20
    $ NPC = "???"
    "你整理好自己，继续你的一天。"
    if "bunga_bego" in buff_events:
        if "beku" in quil_events:
            scene map_infected_f with w20    
        else:
            scene map_infected with w20    
    else:
        if "beku" in quil_events:
            scene map_frozen with w20
        else:
            scene map_all with w20
    jump world_map
label seth_fight:
    $ fia_events.append("culik")
    play music "MUSIC/Action-Rhythm-5.mp3"
    scene ley_night with w33
    "当它进入你的视线时，你注意到莱纳尔有些不对劲。"
    "所有的灯都熄灭了，空气中弥漫着一种不自然的寂静。仿佛整个岛屿都陷入了沉睡。"
    play sound "sound/effects/tile.mp3"
    if "beku" in quil_events:
        "你和莱尔在冰面上跑得更快了，担心最坏的情况发生。"
    else:
        "你和莱尔跑得更快了，担心最坏的情况发生。"
    scene der_night with fade
    show buff kzl sweat shock at right with dissolve:
        yoffset 770
    if girl:
        show palmierproxy chill ow sweat frusta at left with dissolve:
            yoffset 40
    else:
        show palmierproxy chill ow sweat frusta at left with dissolve:
            yoffset 100
    stop sound
    "当你们冲过码头时，数百具瘫软的身体映入眼帘。"
    show palmierproxy side
    show buff sad frusta
    "你环顾四周，发现一个渔夫僵硬地躺在码头上，一动不动。你小心翼翼地触碰他。幸运的是，你能感觉到他的脉搏。"
    "他还在呼吸，尽管很微弱。然而，他的眼睛里没有生命的迹象。他到底怎么了？"
    $ NPC = "派克"
    show side_pike_f at pic
    npc "莱尔！"
    hide side_pike_f
    show buff keluh shock
    show palmierproxy kzl shock
    "你听到派克颤抖的声音，他在岛上更远的地方向你挥手。你和莱尔迅速追了上去。"
    show buff sad -shock
    show palmierproxy -kzl
    show side_pike_f at pic
    npc "莱尔，快来帮忙！跟我来！"
    hide side_pike_f
    play sound "sound/effects/tile.mp3"
    "你尽最大努力跟上派克，无视周围看起来像死人一样的身体。"
    scene kuburan with fade
    show buff kzl sweat shock at right with dissolve:
        yoffset 770
    if girl:
        show palmierproxy chill ow sweat frusta at left with dissolve:
            yoffset 40
    else:
        show palmierproxy chill ow sweat frusta at left with dissolve:
            yoffset 100
    buff scold apa "派克，到底发生什么了？！"
    show buff kzl -apa
    show side_pike_f at pic
    npc "我不知道。玛格丽特和孩子们，整个岛上的人，都醒不过来！"
    hide side_pike_f
    stop sound
    buff confused apa "冷静点，派克，你这是什么意思？"
    show buff sad -apa
    show side_pike_f at pic
    npc "我是说他们都一动不动，我...我不知道发生了什么！"
    npc "这是怎么回事，是不是，是不是巫师干的？！是巫师做的吗？"
    npc "噢，诸神在上！"
    hide side_pike_f
    show pboy at horzappear
    menu:
        "让他清醒过来":
            hide pboy
            show buff scold shock 
            stop music
            play sound "sound/effects/slap.mp3"
            mc apa frusta "清醒过来！" with vpunch
            show buff kzl -shock
            "你用力扇了他一巴掌，想让他冷静下来。"
            show palmierproxy grit shock
            show buff sad shock
            "你本以为他会生气或震惊，或者有其他各种反应。"
            "但你没想到的是，他竟然笑了。"
            show side_pike_s at pic
            npc "嗯，这可不太友好。"
            hide side_pike_s
            play sound "sound/effects/cloth.mp3"
            buff keluh "那双眼睛——[povname]，快退后！！！" with vpunch
            play sound "sound/effects/bum.mp3"
            play music "MUSIC/wrath.mp3"
            galleryunlock bsb03
            scene bsb03 with flashbulb:
                truecenter zoom 1.0
                easein 1.0 truecenter zoom 0.5
            "一股强烈的冲击波在你面前爆发。你能感觉到衣服被狂风撕裂，身体被推向后方"
            "你感到脚下的泥土开裂移动，树干和树枝纷纷断裂。" 
            play sound "sound/effects/splat.wav"
            "温热的鲜血溅到你脸上。只是此刻浸湿你衣服的并不是你的血。"
            show side_b skul sad at pic
            buff "[povname]，你没事吧？"
            hide side_b
            "从莱尔稳定的声音判断，也不是他的血。"
            if not girl:
                galleryunlock ivar_saveus
                show ivar_saveus with fade:
                    yalign 1.0
                    easein 2.0 yalign 0.0
            else:
                scene kuburan with dissolve    
                show ivar kzl at center with dissolve:
                    yoffset 150
            "然后，你周围的烟雾散去，露出了一个高大身影熟悉的宽阔肩膀，上面有着正在愈合的红色伤疤。"
            iv "你真是个麻烦精，不是吗[povname]？"
            show side_b skul sad at pic
            buff "...爸爸？"
            hide side_b
            show side_p s at pic
            mc "伊瓦尔！"
            hide side_p
            scene kuburan with dissolve
            show seth cray at right with dissolve:
                yoffset 150
            show ivar kzl at left with dissolve:
                yoffset 150
            seth "哦，真好啊，这不是活生生的艺术品本人吗。那个能让任何男人跪倒的致命男人。"
            seth happy "那个挖出我一只眼睛还敢反抗我的无礼小子！厌男的伊瓦尔。"
            iv sigh "塞斯。"
            iv frown frusta "你在这里躲藏了多久？"
            seth grin cling "够久了。我很享受和这里的居民玩过家家。你知道我操纵他们的记忆或控制他们的身体有多容易吗？"
            seth datar -cling "老实说，这太可悲了。但我玩得很开心，尤其是和你那个最小的儿子。"
            seth cray "我真期待看到他意识到所有美好回忆都只是空洞谎言时的绝望表情。"
            "塞斯说话时，他的身体从一种形态变成另一种形态。派克、史蒂夫、那个失明的孩子、玛格丽特，然后是他自己。"
            "或者说你认为是他自己的样子。白发，皮肤更加苍白。一只爬行动物般的绿眼睛，另一只眼睛和伊瓦尔的女儿们的眼睛相似。"
            "那是你几周前看到你的替身杀死的那位女士的同一只眼睛。"
            seth grin "我真希望能保留他的一只金色眼睛。拥有一整套就好了。左眼来自你的女儿，右眼来自你的儿子。"
            seth cray cling "这将是你作为父亲无能的提醒。"
            scene bg_black with w33
            galleryunlock ikatan
            show skeliiv at left with moveinleft
            "伊瓦尔咆哮着，他的伤口瞬间愈合。锋利如刀的藤蔓朝塞斯涌去。"
            "塞斯打了个响指，藤蔓全都腐烂了，化作骨灰般的枯枝落在地上。"
            show skeliiv2 at right with moveinbottom
            "骷髅在原地组装起来，骨白色的手从地下爬出，将伊瓦尔固定在原地。"
            show skeliiv3 at right with moveinright
            seth "好了，好了，是你先挖出我的眼睛的，小王子。我给自己找个替代品也是公平的。"
            scene kuburan with dissolve
            show seth cray at right with dissolve:
                yoffset 150
            show ivar kzl at left with dissolve:
                yoffset 150
            iv kzl shock "你杀了我的女儿！"
            show ivar frown frusta
            seth kzl sigh "细节，细节。我给了她我的时间和爱的荣耀。"
            seth pissed frusta "而那个贱人竟然有胆量说不。你知道我不能接受这个，对吧？"
            seth grin apa "她叫什么名字来着？布里安娜，布里？"
            iv kzl "布里奇特！但这不是你杀的唯一一个，那只眼睛...是塔尼娅的，对吧？"
            seth cray -apa "哦，对了。丰满的布里奇特，还有家族中美丽的艺术家塔尼娅。你真是个关心孩子的好父亲。"
            play sound "sound/effects/clap.mp3"
            seth datar "我可从来认不出自己的后代的眼睛，干得好。"
            scene bg_black with w33
            play sound "sound/effects/wush.mp3"
            galleryunlock leapith
            show leapiv at left with moveinleft 
            show leapseth at right with moveinright
            "当塞斯做出嘲讽的鼓掌动作时，伊瓦尔周围的骨头碎裂了，他朝塞斯跃去。"
            "塞斯也以同样的方式回应，全速冲向伊瓦尔。"
            "这已经不再是巫师和猎巫人之间的战斗了。"
            play sound "sound/effects/explode.mp3"
            galleryunlock blowup_magic
            scene blowup_magic with flashbulb:
                truecenter zoom 2.0
                easein 1.0 truecenter zoom 1.0
            "这是\"神\"与\"神\"之间的战斗。"
            scene kuburan with fade
            show side_p m at pic
            mc "当然，最后一个巫师必须是个白得发亮的男人。典型。"
            hide side_p
            show buff kzl sweat at center with dissolve:
                yoffset 770
            buff keluh frusta "我们该怎么办？我...我觉得我们不能介入其中。"
            buff scold "也许我们应该离开这里——{w}"
            play sound "sound/effects/stab.mp3"
            show blud_overlay with vpunch
            buff keluh shock "啊啊啊啊！"
            scene kuburan with dissolve
            show croissant flinch sad sweat at center with dissolve:
                yoffset 500
            "莱尔被你自己的妹妹从背后刺伤了。"
            galleryunlock brotangkap
            show buffchain at left with moveinleft
            $ renpy.pause()
            play sound "sound/effects/sword.mp3"
            show buffchain2 at right with moveinright
            $ renpy.pause()
            "在你能够援助莱尔之前，黑色的锁链开始缠绕住莱尔，将他举离地面。"     
            scene kuburan with dissolve
            show croissant flinch sad sweat at center with dissolve:
                yoffset 500
            fia gross "快跑，格兰布斯！我控制不住自己了，快跑！"
            play music "MUSIC/not_drill.mp3"
            play sound "sound/effects/tile.mp3"
            
        "询问菲亚在哪里":
            hide pboy
            mc ow sigh "慌张对解决问题没有帮助。你叫莱尔来是有原因的，就告诉我们紧急情况，然后我们继续行动吧。"
            show palmierproxy sad -sigh
            show buff sad sigh
            "派克沉重地哼了一声，疯狂地点头。"
            show side_pike_f at pic
            show palmierproxy ow sweat shock
            show buff scold shock
            npc "对-对。玛格丽特，玛格丽特出问题了。我看到她拿着刀带着孩子们来这里！"
            npc "一把刀！而且不仅如此。还有你的妹妹，我想我也看到你妹妹和她在一起！"
            hide side_pike_f
            mc grit "菲亚？！"
            stop music
            play sound "sound/effects/tile.mp3"
            scene kuburan with fade
            "你环顾四周，试图找到你的妹妹。墓地只是一个荒凉绝望的地方。这里安静、凄凉，没有生命的迹象。"
            show dead_fia with dissolve
            galleryunlock dead_fia
            "但随后你发现了一缕熟悉的金发，一个沉睡的美人躺在敞开的棺材里。"
            stop sound
            show side_p s at pic
            mc "菲亚？！"
            hide side_p
            play music "MUSIC/wrath.mp3"
            "你冲向你妹妹沉睡的身影，几乎是跳了过去。你紧紧抓住木板，双手颤抖。"
            "这一幕唤起了你长久以来埋藏的所有可怕回忆。"
            scene kuburan with dissolve
            if girl:
                show palmierproxy chill sad sweat frusta sweat at left with moveinleft:
                    yoffset 40
            else:
                show palmierproxy chill sad sweat frusta sweat at left with moveinleft:
                    yoffset 100
            show buff sad at right with moveinright:
                yoffset 770
            mc ow shock "菲亚？！菲亚？！不，不，不！不要再来一次！我不能，不能再来一次！"
            show palmierproxy side frusta
            buff scold apa "派克，怎么回事？玛格丽特在哪里？"
            show buff sad shock
            "派克后退了一步，泪眼婆娑地寻找着什么。一个高大的黑影穿过雕像走来，似乎有什么人在注视着你。"
            show side_pike_f at pic
            npc "我已经按你说的做了，现在履行你的承诺！让我再见我儿子一面！"
            hide side_pike_f
            buff keluh frusta "什么？！派克，你做了什么？！"
            show kid_blind at center with dissolve
            $ NPC = "史蒂夫"
            npc "他为了他的儿子出卖了你。"
            show palmierproxy kzl shock
            show buff scold shock
            "你看到史蒂夫从阴影中走出来，脸上刻着一个宽大的笑容，他的形态不断变换。"
            hide kid_blind with flashbulb
            show buff sad 
            show seth cray at center with dissolve:
                yoffset 150
            "站在你面前的是世界上最白的人。头发和皮肤白得像雪，只有他的异色瞳给他带来一丝色彩和生气。"
            show palmierproxy apa frusta
            show buff confused frusta
            "他俯视着你，而你仍在菲亚昏迷的身体前啜泣。"
            show palmierproxy kzl -sweat -frusta
            buff scold -sweat -frusta "那双眼睛，你，你是什么？你有我妹妹的眼睛。但怎么可能？"
            seth grin cling "补偿。你父亲曾经挖出我的眼睛，我拿他女儿的眼睛作为替代，这很公平。"
            seth happy -cling "我本希望也能拿走你的眼睛凑成一对。你真是个容易上当的人，不是吗？"
            seth cray "你如此渴望任何形式的爱。"
            seth "满足于最低限度的感情。"
            seth kzl frusta "我本想多玩弄你一会儿，但不幸的是这个小岛已经引起了太多注意。"
            show seth grin -frusta
            show palmierproxy ow sweat
            buff keluh sweat shock "什么？！不！我和这里村民的羁绊是——"
            show buff sad -shock
            seth cray cling "羁绊？！哦，真是可笑。你真的以为这些人类在乎你吗？以为他们会接纳你为自己人吗？"
            seth grin -cling "你怎么能天真到这种地步？！"
            buff scold frusta "你在撒谎！派克，玛格丽特——！"
            show buff keluh shock
            show palmierproxy kzl shock
            seth "{i}哦，孩子，你应该留在莱纳尔。我相信小伙子小姑娘们会很高兴有你在的！{/i}"
            show palmierproxy sad -shock
            show buff eh -shock
            "塞斯唱歌般地说道，他的声音完全是派克的翻版。"
            show buff kzl
            "你可以看到莱尔的心因此碎了一点。他犹豫了，无法分辨他是在和真正的派克还是塞斯说话。"
            seth grin sigh "我给你的每一点善意，你感受到的每一分爱意，都是谎言。全都只是为了给这场甜蜜的背叛增添一些趣味！"
            buff scold frusta "我...我不相信你！"
            seth cray cling "哦，真的吗？那么，也许你可以改变他的想法，派克。"
            play sound "sound/effects/stab.mp3"
            show side_pike_f at pic
            $ NPC = "派克"
            npc "请原谅我！"
            hide side_pike_f
            buff keluh shock sweat "派克，呃！！！" with vpunch
            $ buff_events.append("pike_betray")
            show blud_overlay with vpunch
            "就在莱尔准备转身时，派克刺中了他的腹部。莱尔踉跄了一下，而派克空洞地盯着他，毫无愧疚之意。"
            "派克扔下刀，像个被线操纵的木偶一样慢慢走向塞斯。"
            hide blud_overlay with dissolve
            show buff kzl sweat frusta
            mc ow shock "莱尔！"
            seth grin sigh "你看，这个小岛是我私人的玩偶屋。"
            seth cray -sigh "每个人都在我的指挥下。这些木偶并不知道是我在操纵他们的线。"
            seth datar "有趣的小玩具，可以玩弄，可以打碎..."
            show side_pike_f at pic
            play sound "sound/effects/splat.wav"
            show blud_overlay with vpunch
            npc "嗯！"
            hide side_pike_f
            hide blud_overlay with dissolve
            show buff eh shock
            show palmierproxy side shock
            seth cray cling "...随心所欲。"
            "塞斯拿起刀转了转。一个巧妙的手法，然后他将刀深深刺入派克的身体。"
            buff keluh shock "派克——！"
            show palmierproxy sad -shock
            show buff sad -shock
            seth grin -cling "我在这里躲藏得很开心。引诱新的玩偶来到岛上，处理掉任何无聊的玩偶。"
            seth pissed sigh "你知道吗，那些孩子特别烦人？"
            seth cray -sigh "我必须以某种方式摆脱他们。血祭仪式是最有用的。"
            seth grin "要么就是把新鲜的血袋送给沃特克。他们总是喜欢新鲜的食物。"
            play music "MUSIC/not_drill.mp3"
            play sound "sound/effects/api.mp3"
            if not girl:
                galleryunlock buletflame
                scene buletflame with dissolve
            else:
                galleryunlock buletflamef
                scene buletflamef with dissolve
            buff "我——我不会让你逃脱的！"
            scene bg_black with w33
            show imut at left with moveintop:
                yalign 0.0
            $ renpy.pause()
            play sound "sound/effects/swosh.mp3"
            show imut2 at left with moveinbottom:
                yalign 1.0
            play sound "sound/effects/punch.mp3"
            show imut3 at right with moveinright
            $ renpy.pause()
            galleryunlock imuti
            scene bg_black with dissolve
            show mainnak at left with moveinleft
            $ renpy.pause()
            if girl:
                galleryunlock mainanakf
                show mainnakf at right with moveinright:
                    yalign 0.0
            else:
                galleryunlock mainanakm
                show mainnakm at right with moveinright:
                    yalign 0.0
            $ renpy.pause()
            show mainnakg at right with moveinbottom:
                    yalign 1.0
            scene bg_black with dissolve
            play sound "sound/effects/woosh.mp3"
            if girl:
                galleryunlock tusukmataf
                show stabieyef at left with moveinleft
            else:
                galleryunlock tusukmatam
                show stabieyem at left with moveinleft
            show stabieye at right with moveintop:
                yalign 0.0
            play sound "sound/effects/swosh.mp3"
            show stabieye2 at right with moveinright:
                yalign 1.0
            seth "你亲爱的爸爸就在这里。"
            show side_p s at pic
            mc "伊瓦尔..."
            hide side_p
            "你没注意到伊瓦尔究竟是什么时候从他给你的花中冲出来的，但无论如何，你很高兴他在这里。"
            "你跌跌撞撞地向他跑去，希望他能唤醒沉睡中的菲亚。"
            "然而你被打断了，因为塞斯向你发起攻击，莱尔挡在你面前抵挡攻击，但被塞斯的锁链束缚住了。"
            scene bg_black with fade
            galleryunlock brotangkap
            show buffchain at left with moveinleft
            $ renpy.pause()
            play sound "sound/effects/woosh.mp3"
            show buffchain2 at right with moveinright
            $ renpy.pause()
            scene bg_black with fade
            if girl:
                show knifefiaf at left with moveinleft
            else:
                show knifefiam at left with moveinleft
            if girl:
                show knifefia2f at left behind knifefiaf with moveintop:
                    yalign 0.0
            else:
                show knifefia2m at left behind knifefiam with moveintop:
                    yalign 0.0
            play sound "sound/effects/sword.mp3"
            if girl:
                galleryunlock knifefia3f
                scene knifefia3f at left with flashbulb
            else:
                galleryunlock knifefia3m
                scene knifefia3m at left with flashbulb
                    
            mc "菲亚？！"
            fia "不，我……[kk]……快跑！"
            scene bg_black with fade
            play sound "sound/effects/punch.mp3"
            if girl:
                galleryunlock tenpisf
                show kickknifef at left with vpunch
            else:
                galleryunlock tenpism
                show kickknifem at left with vpunch
            play sound "sound/effects/flame.mp3"
            show kickknife2 at right with moveintop:
                yalign 0.0
            fia "快跑！我无法控制自己的身体！"
            play sound "sound/effects/api.mp3"
            if girl:
                show kickknife3f at right with moveinbottom
            else:
                show kickknife3m at right with moveinbottom
            $ renpy.pause()
            scene kuburan with dissolve
            show seth cray at right with dissolve:
                yoffset 150
            show ivar kzl frusta at left with dissolve:
                yoffset 150
            iv "塞斯已经控制了她！杀了她，她已经没救了！"
            
            seth cling "好了好了，伊瓦尔，别让这些小家伙分散你的注意力，把眼睛放在我身上。"
            scene bg_black with w33
            play sound "sound/effects/woosh.mp3"
            galleryunlock leapith
            show leapiv at left with moveinleft
            show leapseth at right with moveinright
            seth "我们来玩点有趣的吧，老朋友？"
            play sound "sound/effects/explode.mp3"
            galleryunlock blowup_magic
            scene blowup_magic with flashbulb:
                truecenter zoom 2.0
                easein 1.0 truecenter zoom 1.0
            $ renpy.pause()
    scene ger_night with w33
    show side_p m at pic
    play sound "sound/effects/crumble.mp3"
    mc "（岛屿在震动，他们真的在撕裂这座岛，这里不安全！）"
    hide side_p
    show croissant flinch jijik at center with dissolve:
        yoffset 500
    fia sweat shock "停——停下！！！"
    play sound "sound/effects/shield.mp3"
    show ger_night behind croissant with dissolve:
        subpixel True
        zoom 1.2 xpos 0.5 ypos 0.5 xanchor 0.5 yanchor 0.5 
        alignaround (.45, .45)
        linear 20 yalign 0.45 xalign 0.45 clockwise circles 1.2
        #repeat
    show side_p s at pic
    mc "（菲尔拉？！）"
    show side_p m
    mc "（我……我动不了！）"
    hide side_p
    show ger_night:
        linear 1.0 truecenter zoom 1.0
    play sound "sound/effects/flame.mp3"
    "菲亚哭泣着，她的手臂泛着红光，火焰符文闪耀着，她将攻击对准了你。"
    fia sad frusta "不！停下，[kk]快躲开或者打晕我，拜托了！"
    show side_p s at pic
    mc "不！！！我——我不会伤害你的！"
    hide side_p
    fia "我也不想伤害你，所以拜托了，我的身体……听我的话！"
    scene bg_black with fade
    play sound "sound/effects/api.mp3"
    galleryunlock bakardiri
    show bakardiri at center with dissolve
    fia "啊啊啊啊啊啊！！！"
    show side_p s at pic
    mc "菲亚！！！"
    hide side_p
    "不想伤害你，菲亚将火焰引向了自己。"
    "你跳上前去，抓住她的手臂，试图用你的符文冷却她的烧伤。"
    play sound "sound/effects/freeze.mp3"
    if girl:
        galleryunlock dingsf
        scene dingsf with flashbulb
    else:
        galleryunlock dingsm
        scene dingsm with flashbulb
    fia "好冷！！！"
    "但是力量太强了。"
    show side_p s at pic
    mc "（冰正在冻结她的全身！）"
    mc "不！停下！这不是我想要的！"
    hide side_p
    fia "不，[kk]这……这样很好。"
    fia "这样我就不会伤害你了。"
    show side_p s at pic
    mc "但是——"
    hide side_p
    scene bg_black with fade
    
    show iceshould at left with moveinleft
    fia "没关系的。我们只需要等到救援到来，对吧？"
    fia "该死，真冷。你真的在那个符文上下了全力，是吗，小抱怨鬼？"
    play sound "sound/effects/cloth.mp3"
    if girl:
        galleryunlock kehangatanf
        show iceshouldf at right with moveinright
    else:
        galleryunlock kehangatanm
        show iceshouldm at right with moveinright
    mc "菲亚！菲亚！！！"
    scene ger_night with flashbulb
    
    if girl:
        show palmierproxy grit sweat at center with dissolve:
            yoffset 40
    else:
        show palmierproxy grit sweat at center with dissolve:
            yoffset 100
    mc "我必须试着融化这些冰……"
    play sound "sound/effects/bomb.wav"
    mc sad "（拜托，别把她全身烧伤！）"
    mc ow shock "菲亚？菲亚？！"
    "冰融化了，但菲亚仍然昏迷不醒。她的心跳越来越慢，你能感觉到她正在慢慢消逝。"
    mc sad frusta "我需要帮助。伊瓦尔或塞斯，随便谁，只要——我需要帮助！"
    hide palmierproxy with dissolve
    play sound "sound/effects/tile.mp3"
    "你离开了菲亚，冲向现在唯一能帮助她的人，那两个\'神\'。"
    jump pilihan_seth

label pilihan_seth:
    play music "MUSIC/Hitman.mp3"
    galleryunlock insky
    scene insky with fade:
        subpixel True
        truecenter zoom 2.0
        easein 2.0 truecenter zoom 1.0
    play sound "sound/effects/explode.mp3"
    queue sound "sound/effects/bum.mp3"
    "树木碎裂，山丘崩塌，你脚下的地面裂开，塞斯和伊瓦尔继续着他们的猛烈攻击。"
    "他们的力量似乎势均力敌。伊瓦尔种出的任何东西，塞斯都能用一次触碰使其枯萎。"
    "同样，无论塞斯折断哪块骨头，切断哪个身体部位，伊瓦尔都能立即治愈，他的美貌依旧完美无瑕。"
    show side_p m at pic
    mc "（这样谁也赢不了，我需要改变局势。）"
    hide side_p
    show pboy at horzappear
    menu seth_kill:
        "使用伊欧的冰符文" if "beku" in quil_events:
            hide pboy
            show side_p m at pic
            mc "（我记得伊欧的冰符文，如果我试着画出来，也许我能施展它。）"            
            show side_p s
            mc "（我可能会失去一两根手指，但这值得冒险。我必须试一试！）"
            hide side_p
            jump bekuin_duo
            
        "{s}使用伊欧的冰符文{/s}" if "beku" not in quil_events:  
            
            jump seth_kill
        "使用洛基的寒霜" if check_inv_for(up_items):
            hide pboy
            show side_p m at pic
            mc "（这可能对他们没有太大伤害，但洛基的寒霜可以为我们争取一些时间。这种药水应该能暂时冻结伊瓦尔的花。）"
            mc "（虽然我不认为这会对塞斯造成太大伤害。但也许这是好事，也许他会把我视为盟友，然后释放菲亚。）"
            show side_p s
            mc "（我必须试一试！）"
            hide side_p
            jump bekuin_iv
        "{s}使用洛基之霜{/s}" if not check_inv_for(up_items):
            
            jump seth_kill
        "冲进去，先诅咒！":
            hide pboy
            show side_p s at pic
            mc "（我现在没有太多选择。）"
            show side_p m
            mc "（我只需要冲进去，瞄准射击。）"
            hide side_p
            jump charge_seth
        "试着交谈":
            hide pboy
            scene kuburan with fade
            "失去手的恐惧战胜了你。你举起双手靠近他们，试图看起来无害。"
            if girl:
                scene blufemf with flashbulb
            else:
                scene blufemm with flashbulb
            show side_p m at pic
            mc "停下！我说停下，一定有办法——"
            hide side_p
            seth "闭嘴！"
            play sound "sound/effects/slashkut.wav"
            show bg_black with wet
            "一个月亮形状的咒语朝你飞来。你几乎没有时间反应，它就深深地嵌入了你的脖子。"
            buff "[povname]！！！"
            iv "不..."
            play sound "sound/effects/splash.wav"
            stop music
            "你的头滚落在地，莱尔和伊瓦尔因你的死亡而愤怒地尖叫。"
            "你死了，因为你愚蠢地认为可以与巫师谈判。也许在之前所有幸运的遭遇之后，你低估了他们。"
            "也许这一直就是你的命运。无论如何，现在一切都结束了。巫师们的命运、菲亚和你朋友们的命运，一切都悬而未决。"
            "安息吧，[povname]。你应得的。"
            jump bad_end_game
label bekuin_iv:
    scene bg_black with fade
    galleryunlock vinpip
    play sound "sound/effects/vine.wav"
    show vineseth at left with moveinleft
    "你朝战斗冲去。伊瓦尔的藤蔓缠绕着塞斯，形成了某种茧状物。"
    show vineseth2 at right with moveinright
    "同时，白骨和黑色卷须缠绕着伊瓦尔，束缚着他。他们的魔法瞄准了对方的脖子。你听到了痛苦的断裂声。"
    show side_p s at pic
    mc "（如果我冻住伊瓦尔，那么我就可以和塞斯谈谈，也许能让他解除对菲亚的控制。）"
    show side_p m
    mc "（但如果我冻住塞斯，伊瓦尔就会占上风并杀死他。但这对所有被塞斯控制的人意味着什么呢？）"
    hide side_p
    "他们都受了重伤。照这个速度，他们会同时死去。现在是最后的机会了。"
    show pboy at horzappear
    menu:
        "帮助塞斯":
            hide pboy
            galleryunlock popsicle
            show icebledar with dissolve:
                truecenter zoom 2.0
                easein 1.0 truecenter zoom 1.0
            "你将药水扔向伊瓦尔的脚下。药瓶破碎，冰冷的银色雾气开始蔓延，冻结了伊瓦尔和他的花朵。塞斯轻松地从脆弱的茧中挣脱出来。"
            play sound "sound/effects/glass.wav"
            show icebledar2 with moveinbottom:
                xalign 0.35
            iv "你！你在做什么？！不！"
            play sound "sound/effects/freeze.mp3"
            "伊瓦尔的整个身体被冰封住，塞斯将注意力转向了你。"
            scene kuburan with fade
            if girl:
                show palmierproxy chill kzl sweat at right with dissolve:
                    yoffset 40
            else:
                show palmierproxy chill kzl sweat at right with dissolve:
                    yoffset 100
            show seth grin at left with dissolve:
                yoffset 150
                xzoom -1.0
            seth cray cling "哦，哦，哦……你决定改变立场了吗，宠物？还是你想从我这里得到什么？"
            mc pissed frusta "我该如何解救菲亚？"
            show palmierproxy apa shock
            seth bete sigh "菲亚？你为什么那么在乎那个女孩？"
            seth datar -sigh "你又不是她真正的[kk]。只是一个妄想的、野心勃勃的猎巫人的劣质版本。"
            seth grin "你知道吗，我其实听说过你的另一个自己？那是在[kamu]试图招募阿莱斯的时候。我的小意外。"
            seth cray "你确定要唤醒一个有如此远大抱负的人吗？你基本上是在给另一个自大狂以神的力量。"
            show seth datar
            mc kzl sigh "别转移话题，告诉我如何治愈她！"
            seth cray "啊哈哈！没有办法治愈她，宠物。没有我的死亡，就不会有结束！"
            show palmierproxy ow shock
            seth "而你刚刚给了我上风！"
            show bg_black with wet
            galleryunlock kemayu
            show sethded2 at center with dissolve
            play sound "sound/effects/glass.wav"
            "塞斯用一记强有力的拳击打碎了伊瓦尔被冻结的面容。伊瓦尔的身体崩塌了，一颗粉色的宝石从他的遗骸中升起。那是他的心脏。"
            hide sethded2 with wet
            hide bg_black with dissolve
            mc pissed shock"No!"
            show palmierproxy side -shock
            stop music
            play sound "sound/effects/woosh.mp3"
            queue sound "sound/effects/summon.mp3"
            hide palmierproxy with vpunch
            show seth datar at center with move
            seth cray cling "你选择错了，宠物。但别担心。"
            scene bg_black with wet
            "你的影子背叛了你。黑色的卷须从下方升起，将你囚禁在一个幽灵般的球体中。"
            seth "我一定会好好享受你那张美丽的脸蛋的。"
            jump seth_bad_end
        "帮助伊瓦尔":
            hide pboy
            play sound "sound/effects/glass.wav"
            queue sound "sound/effects/freeze.mp3"
            galleryunlock popsicle
            show icebledar with dissolve:
                truecenter zoom 2.0
                easein 1.0 truecenter zoom 1.0
            "你将药水扔向塞斯的脚下。药瓶破碎，冰冷的银色雾气开始蔓延，冻结了他和他的阴影卷须。"
            "伊瓦尔打碎了束缚他的骨头。他脖子上的伤口立即愈合，缠绕在塞斯周围的荆棘收紧了。"
            scene bg_black with wet
            show sethded at center with dissolve
            seth "啊哈哈哈！我想这是你的胜利，漂亮的小伊瓦尔。我迫不及待要与你分享新的容器了！"
            seth "让我们看看谁会赢，好吗？"
            stop music
            play sound "sound/effects/glass.wav"
            if girl:
                scene gem_sbasef with dissolve
                galleryunlock gem_sflatf
            else:
                scene gem_sbase with dissolve
                galleryunlock gem_sflat
            show gem_stop 
            show seth_hati behind gem_stop with moveintop:
                xpos 523 ypos 10
                linear 1.0 ypos -40
                linear 1.0 ypos 10
                repeat
            "塞斯微笑着，他的脖子断成两截。他的头滚到一边，然后他的宝石完全显露出来。"
            "一颗比太阳还亮的黄色宝石，上面悬浮着一个奇怪的符文。"
            scene kuburan with fade
            show ivar kzl flow at left with dissolve:
                yoffset 150
            iv "你会想保留那个的。"
            if girl:
                show palmierproxy chill sad sweat at right with dissolve:
                    yoffset 40
                    xzoom -1.0
            else:
                show palmierproxy chill sad sweat sigh at right with dissolve:
                    yoffset 100
            show pboy at horzappear
            menu nanya_rune:
                "为什么有一个符文标记？" if 'iv_curhat' in fia_events:
                    hide pboy
                    mc apa frusta "一个符文标记，就像你的纹身。别告诉我他也有赫卡特之蔷薇？！"
                    show palmierproxy kzl
                    iv kzl frusta "他确实有。这可能就是为什么他没有多少抵抗。死亡从来就不是问题。"
                    mc side tanya "现在会发生什么？这是否意味着他可以附身[povname]？"
                    show palmierproxy sad -tanya
                    iv frown sigh "我不会让他得逞的。如果你先插入我的宝石，那么我应该就能保护你的另一个自我免受塞斯的影响。"
                    mc ew tanya "你的宝石……那意味着我还是得杀你，对吧？"
                    show palmierproxy sad
                    iv awk apa "这不就是你从一开始的任务吗？杀死所有纯血巫师，唤醒[povname]。"
                    mc ew frusta "嗯，是的，但我现在不确定我能杀得了你。我对你太了解了。"
                    iv amused sigh "那就庆幸你不用这么做了。"
                    play music "MUSIC/heart.mp3"
                    show buff kzl sweat frusta at center with dissolve:
                        yoffset 770
                    show palmierproxy grit shock
                    "伊瓦尔转身面对他的儿子，后者仍然呆立在混乱之中。塞斯和伊瓦尔法术的混乱残余包围着他。"
                    show palmierproxy ow -shock
                    show buff sigh 
                    iv ancam cling "我相信你会很乐意亲自动手的，对吧，莱尔？"
                    show ivar ejek -cling
                    buff scold -sweat -sigh "……你好，父亲。"
                "{s}为什么会有符文标记？{/s}" if 'iv_curhat' not in fia_events:
                    
                    jump nanya_rune
                "不，谢谢？":
                    hide pboy
                    iv kzl sigh "谢谢你救了我，你是个英雄。满意了吗？"
                    show ivar ejek -sigh
                    mc huh -sweat sigh "嗯，用这种语气可不行。"
                    mc wry -sigh "不过我很高兴你安全了，老头子。"
                    iv ejek -sigh "是啊。至少你们中有一个人见到我很高兴。"
                    show palmierproxy ew sweat shock
                    play music "MUSIC/heart.mp3"
                    show buff kzl sweat frusta at center with dissolve:
                        yoffset 770
                    iv ancam cling "可惜，我怀疑我儿子并不这么想。"
                    show ivar smirk -cling
                    show palmierproxy kzl -shock
                    "伊瓦尔转身面对他的儿子，后者仍然呆立在混乱之中。塞斯和伊瓦尔法术的混乱残余包围着他。"
                    iv "你好，莱尔。"
                    buff keluh sigh "……父亲。"
                    show buff kzl -sigh
                "他刚才在说什么？":
                    hide pboy
                    iv kzl sigh "别理他，他只是想激怒你。"
                    iv frown apa "你哪里受伤了吗？你妹妹在哪里？"
                    mc side sweat frusta "啊！我把她留在后面了，我不得不把她打晕。现在会怎么样，她会没事吗？"
                    show palmierproxy sad sigh
                    iv -apa "随着塞斯的死亡，受他影响的人应该能摆脱他的魔法了。"
                    iv amused "虽然可能不是全部。我无法想象他控制整个岛屿多长时间了，但菲亚……她应该没事。"
                    show palmierproxy ew shock
                    play music "MUSIC/heart.mp3"
                    show buff kzl sweat frusta at center with dissolve:
                        yoffset 770
                    iv ejek "现在请原谅，我得去和我儿子谈谈。"
                    "伊瓦尔转身面对他的儿子，后者仍然呆立在混乱之中。塞斯和伊瓦尔法术的混乱残余包围着他。"
                    iv ancam cling "你好，莱尔。"
                    show ivar smirk -cling
                    buff scold sigh "……父亲。"
            show palmierproxy kzl sweat shock
            buff scold -sweat frusta "[povname]，你一直在和我父亲联系吗？你是在为他工作？！"
            show buff kzl
            show palmierproxy side -shock
            iv kzl sigh "拜托，如果我要和猎巫人合作，我至少会雇佣一个有能力的人。"
            iv frown -sigh "这只是……一种临时合作。两个人为了相似的目标而努力。"
            buff scold apa "那是什么？"
            show buff kzl sweat -apa 
            show palmierproxy sad sigh
            iv flirt cling "复仇。"
            show palmierproxy ew -sigh
            iv kzl -cling "为布里奇特报仇，为他偷走的眼睛报仇。"
            show buff eh shock
            show palmierproxy ow -sweat shock
            iv ancam cling "这也是为了消灭所有纯血巫师的合作。包括我自己。"
            show palmierproxy kzl -shock
            buff scold frusta "什么？"
            iv smirk sigh "巫师的时代已经结束了，莱尔。"
            iv kzl frusta "我厌倦了被人恐惧。厌倦了躲藏。我已经为你妹妹报了仇，活了将近一千年。"
            iv ancam cling "巫师的时代到此为止。"
            buff confused "等等，什么？你是真的在告诉我你已经放弃了？你终于寻求死亡了？！"
            show palmierproxy side shock
            show ivar smirk -cling
            buff scold -frusta "胡说八道！"with vpunch
            buff keluh "你到底在玩什么把戏？！你想要什么？！"
            "莱尔用他的符文召唤出一把冰刃。他刺向伊瓦尔的下巴，后者一动不动地站在那里。当刀刃开始流血时，伊瓦尔实际上在嘲笑。"
            buff kzl -sweat sigh "你在玩什么把戏？你不可能这么轻易就放弃生命。除非你有后备计划！"
            iv frown "没有计划，没有阴谋。只是一个老人希望快速死去。"
            buff scold apa "但那个死亡能持续多久呢？"
            show ivar amused sigh
            "伊瓦尔的嘴角抽搐了一下。"
            show buff kzl -apa
            if 'iv_curhat' in fia_events:
                "也许他很高兴看到莱尔眼中如此强烈的仇恨。就连你也几乎认不出那个曾经温柔驯服的棕发少年了。"          
            else:
                "这是对儿子仇恨的愉悦？还是刚刚被揭穿秘密的人那种暴露的抽搐？"
            iv ancam -sigh "那金色的眼睛里充满了如此多的仇恨。"
            iv amused "我为你感到骄傲，莱尔。你善良，勤奋，我太喜欢你是如此地憎恨我了。"
            show ivar amused with move:
                xalign 0.3
            show buff sad sweat shock with move:
                xalign 0.6
            play sound "sound/effects/cloth.mp3"
            "伊瓦尔抚摸着莱尔的脸颊，"
            play sound "sound/effects/slap.mp3"
            show ivar kzl at left with move
            show buff kzl at center with move
            extend "显然，这一触碰太过了。"
            buff scold frusta "别碰我！！！"
            scene choke_dad with hpunch
            galleryunlock choke_dad
            play sound "sound/effects/slashkut.wav"
            "莱尔一刀接一刀地将自己的荆棘之刃刺入父亲的皮肤。"
            "伊瓦尔的脖子周围出现了裂痕，最后莱尔决定亲手结束父亲的生命。"
            play sound "sound/effects/woosh.mp3"
            scene choke_dad2 with flashbulb
            galleryunlock choke_dad2
            "当他收紧掐住父亲喉咙的手时，花瓣开始在风中飞舞。"
            "直到数十朵花在伊瓦尔瘫软的身体旁盛开。"
            jump emo_ivar_buff
        "让他们互相残杀吧":
            hide pboy
            scene bg_black with fade
            show sethded at left with moveinleft
            "你选择置身事外，决定相信塞斯的魔法会随着他的死亡而消散。"
            stop music
            show sethded2 at right with moveinright
            play sound "sound/effects/glass.wav"
            "你看着伊瓦尔和塞斯的头颅从肩膀上滚落。伊瓦尔的尸体绽放出一片花海，而塞斯的尸体则融化成一滩黑色的焦油和骨头。"
            if girl:
                galleryunlock gem_both
                scene jem_bothf with fade
            else:
                galleryunlock gem_both2m
                scene jem_bothm with fade
            "从他们的尸体中，升起了两颗宝石。两颗宝石都比你之前收集到的其他宝石更加闪耀。它们都刻有一个奇怪的印记。一个符文。"
            scene kuburan with dissolve
            if girl:
                show palmierproxy sad at center with dissolve:
                    yoffset 40
                    xzoom -1.0
            else:
                show palmierproxy sad at center with dissolve:
                    yoffset 100
            
            if 'iv_curhat' in fia_events:
                mc pissed sweat frusta "赫卡特之玫瑰。"
                mc side tanya "这是不是意味着塞斯也可以占据[povname]的身体？"
                mc kzl -tanya "该死，我该怎么办？有没有办法移除这个符文？"
                mc sad "但已经过去一个月了。如果[povname]因为昏迷太久而遭受脑损伤怎么办？"
                show croissant flinch jijik sweat at right with dissolve:
                    yoffset 500
                fia cringe apa "...你说的脑损伤是什么意思？"
            else:
                mc wry sigh"终于结束了。有了这些宝石，我终于可以唤醒[povname]了！我可以回家了。"
                mc malu -sigh"菲亚可以重新拥有她的[kk]了。她不会察觉到有什么不同——"
                show croissant flinch jijik sweat at right with dissolve:
                    yoffset 500
                fia cringe apa"...你说的让我的[kk]回来是什么意思？"
            play music "MUSIC/heart.mp3"
            show palmierproxy ow sweat shock at left with move
            mc "菲亚！"
            show croissant at center with move
            show buff sad sweat at right with moveinright:
                yoffset 770
            "你转身看到菲亚和莱尔站在你身后，两人都以各自的方式显得震惊。"
            "莱尔的目光没有离开伊瓦尔的尸体。他显得震惊和困惑。"
            buff keluh apa "他真的死了吗？我的父亲？"
            show buff sad -apa
            mc side sigh "是的。差不多吧，呃——"
            show palmierproxy kzl shock
            fia jijik "把那些宝石给我！" 
            play sound "sound/effects/shield.mp3"
            show kuburan behind croissant with dissolve:
                subpixel True
                zoom 1.2 xpos 0.5 ypos 0.5 xanchor 0.5 yanchor 0.5 
                alignaround (.45, .45)
                linear 20 yalign 0.45 xalign 0.45 clockwise circles 1.2
                #repeat
            "菲亚的命令刺穿了你的头脑。菲拉符文在你耳中回响。你无法抗拒，将宝石递给了她。"
            show kuburan:
                subpixel True
                truecenter zoom 1.0
                xalign 0.5 yalign 0.5
            show palmierproxy sad with move:
                xalign 0.2
            "一瞬间的清醒闪过，你试图夺回宝石，但菲亚更快。她立即抓住了它们，挫败了你微弱的尝试。"
            play sound "sound/effects/bump.mp3" 
            show croissant kzl with vpunch
            show palmierproxy ow at left with move
            fia gross frusta "不！在你告诉我发生了什么，以及你说的唤醒[povname]是什么意思之前，你别想拿回这些宝石！"
            fia sad apa "你不是[povname]吗？！我的[kk]，[povname]？"
            show croissant -apa
            show palmierproxy side sweat sigh
            show buff eh shock
            mc scratch ew frusta "我...不是。"
            show palmierproxy ow -frusta
            show buff kzl -shock
            fia cringe shock "什么？！你是谁？这到底是怎么回事？"
            fia jijik -shock "解释清楚！"
            "她愤怒地尖叫。幸运的是，这次你能够抵抗菲拉的力量，你对此心存感激。你深吸一口气，下定决心向她揭示一切。"
            "而你确实打算告诉她所有事情。"
            mc sad sigh "我会解释的，但我们先离开这里，好吗？如果我能亲自展示给你看，而不仅仅是口头解释，会更容易理解。"
            jump fia_reuni_marah
label seth_bad_end:
    stop music
    scene bg_black with w20
    scene kotput with w20
    play music "MUSIC/PerituneMaterial_Piano_Sad2.mp3"
    $ NPC = "观众"
    npc "再来一个，再来一个！"
    npc "多么精彩的表演啊。我从未在莫洛纳见过如此美丽的舞蹈。"
    show seth datar at center with dissolve:
        yoffset 150
    seth happy "谢谢您，夫人，这是伊格尼亚文化的舞蹈，在这片土地上很少见。"
    $ NPC = "女士"
    npc "伊格尼亚？哎呀，那片土地不是已经被一个巫师彻底摧毁了吗？我以为没有幸存者了。"
    seth datar "确实没有。如您所见，这只是一个人偶。一个木偶。"
    npc "哦！如此精湛的工艺！是你自己制作的吗？"
    seth grin "是的，这是我最新的发明。"
    if girl:
        scene seth_fdance with flashbulb
        galleryunlock seth_fdance
    else:
        scene seth_mdance with flashbulb
        galleryunlock seth_mdance
    seth cray "我的[povname]。"
    scene bg_black with wet
    show text "塞斯的第二个幸福结局：可爱的人偶" with dissolve
    $ renpy.pause()
    show bg_black with dissolve
    jump bad_end_game
label charge_seth:
    scene kuburan with dissolve
    play sound "sound/effects/explode.mp3"
    queue sound "sound/effects/crumble.mp3"
    "当你朝巫师们冲去时，你感到有什么东西在推着你后退。他们法术的残影在空气中回荡，形成了一层阻力。"
    "你脚下的大地裂开了。你勉强躲过了掉入裂缝的命运。"
    "然而，两个巫师都没有受到影响。他们似乎并不在意自己给周围环境造成的破坏比给对手造成的伤害更大。"
    show seth cray at right with dissolve:
        yoffset 150
    show ivar kzl at left with dissolve:
        yoffset 150
    show side_p s at pic
    mc "（他们会毁掉整个岛屿的！我得想办法扭转局势。）"
    mc "（该死，我甚至无法靠近。）"
    hide side_p
    galleryunlock belati
    scene belati with dissolve
    show side_p s at pic
    mc "（...但也许我不需要靠近。）"
    hide side_p
    scene bg_black with fade
    galleryunlock menekan
    show krobok at left with moveinleft
    play sound "sound/effects/crash.mp3"
    queue sound "sound/effects/punch.mp3"
    seth "已经累了吗？不过话说回来，我也不该对一个只有外表和花朵才能的小子抱太大期望。"
    play sound "sound/effects/glass.wav"
    show krobok2 at right with moveinright
    seth "这就是你的末日了，伊瓦尔。"
    scene kuburan with vpunch
    play sound "sound/effects/slashkut.wav"
    queue sound "sound/effects/crumble.mp3"
    show seth retak at center with dissolve:
        yoffset 150
    seth "操！！！"
    "你朝塞斯的左眼扔了一块石头，足以让那颗被偷走的眼球脱落。"
    "它湿漉漉地掉在地上。空荡荡的眼窝迅速愈合并闭合，仿佛什么都没发生过。"
    show side_p w at pic
    mc "呃！哎呀？"
    hide side_p
    seth gils "哦，我并不生气，宠物。事实上，我相信在我对你那美丽的身体进行实验之后，一定会记住这一刻。"
    play sound "sound/effects/crash.mp3"
    galleryunlock menyekik
    scene chokehold with dissolve
    iv "做梦去吧。"
    play sound "sound/effects/glass.wav"
    show chokehold2 at right with moveinright
    seth "啊啊啊！！！"
    scene bg_black with fade
    galleryunlock gurbung
    show gugur1 at left with moveinleft
    stop music
    play sound "sound/effects/vine.wav"
    show gugur behind gugur1 with dissolve
    "花朵从塞斯的头骨中绽放，绽放出各种各样的颜色。环绕塞斯的火圈消散了，莱尔重重地摔在地上。"
    if girl:
        scene gem_sbasef with dissolve
        galleryunlock gem_sflatf
    else:
        scene gem_sbase with dissolve
        galleryunlock gem_sflat
    show gem_stop 
    play sound "sound/effects/jelly.mp3"
    show seth_hati behind gem_stop with moveintop:
        xpos 523 ypos 10
        linear 1.0 ypos -40
        linear 1.0 ypos 10
        repeat
    "一块巨大的黄色石头从塞斯的遗骸中升起。伊瓦尔把宝石递给了你。"
    "你可以看到这颗宝石周围有一种奇怪的光芒，还有一个奇怪的符号保护着它。"
    show side_p m at pic
    mc "为什么这一个不一样？"
    hide side_p
    scene kuburan with dissolve
    show ivar kzl at left with dissolve:
        yoffset 150
    if girl:
        show palmierproxy kzl at right with dissolve:
            yoffset 40
            xzoom -1.0
    else:
        show palmierproxy kzl at right with dissolve:
            yoffset 100
    if 'iv_curhat' in fia_events:
        iv sigh "赫卡特玫瑰符文。他也在自己的心脏上放了一个。"
        mc scratch apa sweat tanya "什么？这不是很糟糕吗？"
        show palmierproxy chill sad
        iv frown -sigh "只要你先放入我的宝石就没问题。我应该能够保护你的另一个自我免受塞斯的影响。"
    else:
        show palmierproxy sad sweat shock
        iv kzl sigh "我不知道。也许他以某种方式玷污了自己的心脏。"
        show palmierproxy -shock
        iv frown -sigh "你应该先把我的心放进[povname]体内，以防万一。"
        iv "无论他做了什么，我应该能够保护你的另一个自我免受塞斯的影响。"
    play music "MUSIC/heart.mp3"
    show buff kzl sweat at center with dissolve:
        yoffset 770
    show palmierproxy ew sweat shock
    show ivar smirk
    "当你把宝石放进口袋时，你看到莱尔犹豫不决地向你走来。"
    "他的背弯曲着，显得很小。他似乎在鼓起勇气接近你们两个。"
    show palmierproxy side -shock
    buff keluh apa "...父亲？"
    show buff sad -apa
    iv ancam "你好，儿子。"
    show ivar amused
    show palmierproxy frown shock
    "仅仅如此，莱尔就后退了一步，准备逃跑。这一幕似乎让伊瓦尔觉得有趣。他对莱尔温柔地笑了笑。"
    "这是你从未见过的景象。"
    show palmierproxy sad -shock
    buff keluh frusta "[povname]，我们必须走了！伊瓦尔...他会杀死我们所有人的。"
    show buff kzl shock
    iv flirt cling "我看你仍然厌恶我，仅仅看到我就会颤抖。"
    iv amused -cling "很好。"
    buff keluh apa "...很好？"
    buff kzl frusta "什么？你到底在玩什么把戏？"
    show pboy at horzappear
    menu:
        "说服莱尔听伊瓦尔解释":
            hide pboy
            mc deject sigh "听他解释一下吧，莱尔。事情不是你想的那样！"
            show palmierproxy ow shock
            iv kzl sigh "不，不是那样的，但是...我也不想分担我的知识带来的负担。"
            iv awk -sigh "我不会向你解释一切，但请记住这一点。"
            iv amused "我为你感到骄傲。我为你成为的那个人感到骄傲。我只是想保护你。"
            iv kzl "或者，我以为我是在保护你。也许在这方面我也让你失望了，但无论如何，我很抱歉。"
            buff scold "你在向我道歉？在我看到你杀死我所有的兄弟之后，在你年轻时对我的态度之后？在如此的蔑视之后？！"
            buff sigh "不。我永远不会原谅你。我恨你！"
            show buff kzl -sigh
            mc ew frusta "...莱尔。如果你只是听他说一秒钟，那么——"
            show palmierproxy sad shock
            show ivar kzl sigh
            "伊瓦尔摇了摇头，给了你一个警告的眼神。他不想让他的儿子知道。他也不需要知道。"
            "当伊瓦尔转动匕首，使刀刃朝向自己，而刀柄在莱尔的可及范围内时，你忍住了没说话。"
            iv ancam cling "那就用那份恨意在这里结束一切吧。杀了我，莱尔。"
            iv smirk -cling "随着我的死亡，巫师的统治将不复存在。"
        "置身事外":
            hide pboy
            pass
        "那么...天气不错，是吧？":
            hide pboy
            iv kzl sigh "你有没有想过假装成一个说话前会思考的人？"
            mc confused sigh "你有没有想过假装成一个会和自己儿子说话的父亲？"
            buff scold frusta "你们两个在说什么？！"
    
    show palmierproxy sad shock
    buff kzl apa "这是什么把戏？"
    show buff -apa
    show palmierproxy side -shock
    iv frown sigh "没有诡计，没有谎言。只是一个虐待自己孩子并犯下最令人发指罪行的老人。"
    iv kzl -sigh "结束我吧，莱尔。随着我的死亡，你所有的兄弟都将获得自由。他们将不再过着奴役的生活。"
    iv amused sigh "他们终于可以安息了。"
    buff scold sigh "骗子，我了解你。"
    buff kzl -sigh "你是我所知道的最卑鄙的巫师。我不相信你的\'真相\'。"
    buff sad "总是有一个隐藏的谎言。"
    iv ancam cling "那就帮我个忙，结束我吧。"
    show palmierproxy confused
    buff kzl sigh "不。" 
    show buff -sigh
    iv amused apa "哦，这是什么？对你老爸的怜悯吗？"
    show ivar smirk -apa
    buff scold "别自作多情了。我只是不想让你得到满足感。"
    show buff sad shock
    show palmierproxy kzl shock
    iv flirt cling "我明白了。那我就再活几个世纪，把我的花园遍布这片土地。从你的学校开始。"
    iv ancam -cling "我想知道[povname]会变成什么美丽的花朵。"
    mc ow sweat shock "伊瓦尔——！"
    play sound "sound/effects/grow.wav"
    "伊瓦尔夸张地歪了歪头。你能感觉到有什么东西在你嘴里蠕动。"
    if not girl:
        play sound "sound/effects/cough.wav"
        galleryunlock peomy_m
        show peomy_m with dissolve
    else:
        play sound "sfx/ow_f.mp3"
        galleryunlock peomy_f
        show peomy_f with dissolve
    "一朵粉色牡丹在你舌下绽放，堵塞了你的呼吸道。"
    "你咳出了它，但更多的花瓣在你口中生长。"
    stop sound
    if not girl:
        hide peomy_m with dissolve
    else:
        hide peomy_f with dissolve
    mc ew frusta "（他在激怒他。我知道他必须死，但至少可以让他安详地死去！）"
    mc sad -frusta "别这样，莱尔——！"
    show palmierproxy kzl shock
    show ivar flirt shock
    buff kzl frusta -sweat "你——！"
    buff scold -frusta "我恨你！！！"
    scene choke_dad with wet
    galleryunlock choke_dad
    play sound "sound/effects/slashkut.wav"
    "莱尔抓起匕首，开始疯狂地刺向伊瓦尔的脖子，直到裂缝开始出现。"
    "当一缕红玫瑰从他口中渗出时，伊瓦尔微笑着，莱尔扔下刀，用自己的双手结束了伊瓦尔的生命。"
    scene choke_dad2 with flashbulb
    galleryunlock choke_dad2
    play sound "sound/effects/woosh.mp3"
    "当他紧紧掐住伊瓦尔漂亮的脖子时，花瓣开始在风中飞舞。"
    "直到数十朵花在伊瓦尔瘫软的身体旁盛开。"
    jump emo_ivar_buff
label emo_ivar_buff:
    "当伊瓦尔最小的儿子给予最后一击时，你能听到一声微弱的\"我爱你\"。"
    "你听到一声熟悉的破裂声，就像在伊欧和梅扎死亡时一样。然而这次，没有出现大理石雕像。"
    stop music
    play sound "sound/effects/wind.mp3"
    "取而代之的是，数十朵花朵像庆祝的花束一样绽放，覆盖了曾被称为美丽巫师的存在。"
    scene kuburan with fade
    show buff keluh at left with dissolve:
        yoffset 770
        xzoom -1.0
    buff "呜咽...呜咽..."
    if girl:
        show palmierproxy side sweat at center with dissolve:
            yoffset 40
            xzoom -1.0
    else:    
        show palmierproxy side sweat at center with dissolve:
            yoffset 100
    $ buff_events.append('bunuh_ivar')
    "莱尔啜泣着，一波释然和或许是悲伤的情绪涌上心头。"
    "你知道为什么伊瓦尔保守他的秘密。但是，当这个魁梧的年轻人寻求你的安慰，将你紧紧抱住时，你还是难以接受。"
    "他哭泣着，而你轻轻抚摸他的背。希望能找到方法缓解他的痛苦。"
    play sound "sound/effects/jelly.mp3"
    if girl:
        scene gem_ibasef with dissolve
        galleryunlock gem_iflatf
    else:
        scene gem_ibase with dissolve
        galleryunlock gem_iflat
    show gem_itop 
    show ivar_hati behind gem_itop with moveintop:
        xpos 16 ypos 58
        linear 1.5 ypos 0
        linear 1.5 ypos 58
        repeat
    "一颗粉色的心形钻石从伊瓦尔的遗体中升起。你趁莱尔不注意时将它收进口袋，但有人却看到了你的举动。"
    scene kuburan with fade
    if girl:
        show palmierproxy side sweat at right with dissolve:
            yoffset 40
            xzoom -1.0
    else:    
        show palmierproxy side sweat at right with dissolve:
            yoffset 100
    show buff keluh at left with dissolve:
        yoffset 770
        xzoom -1.0
    stop sound fadeout 1.0
    play music "MUSIC/PerituneMaterial_Piano_Sad2.mp3"
    show croissant flinch sad at center with dissolve:
        yoffset 500
    fia cringe sweat apa "那是什么？"
    mc ew sweat shock "菲亚！"
    show palmierproxy sad -shock
    show buff sad 
    "菲亚一瘸一拐地走向你。她的伤口自行愈合了。你在她摔倒前接住了她，将她安全地抱在怀里。"
    fia err -apa "刚才那颗宝石是什么？他死了吗？到底发生了什么？"
    mc side sigh "是的，他死了。至于其他问题，嗯..."
    "你的思绪又回到了伊瓦尔身上，想到他如何将一切隐藏在黑暗中。以及这只给莱尔带来了更多的悲伤。"
    "莱尔永远不会知道他所有痛苦的原因。"
    "你忍不住将这与你对菲亚所做的事情进行比较，以及她多么应该知道真相。"
    "她应该知道她真正的[kk]。"
    fia mmh apa "咕噜咕噜，你又忘记怎么说话了吗？怎么了？"
    mc ow sigh "啊，对了。关于那个...菲亚，有件事你应该知道。"
    jump fia_reuni_kalem
label bekuin_duo:
    "当你朝巫师们冲去时，你感到有什么东西在推着你后退。他们法术的残影在空气中回荡，形成了一层阻力。"
    "你脚下的土地崩塌了。你勉强躲过了掉入裂缝的命运。"
    "然而，两个巫师都没有受到影响。他们对自己给周围环境造成的破坏比对各自的对手造成的破坏更大这一事实毫不在意。"
    scene bg_black with fade
    play sound "sound/effects/slashkut.wav"
    show klaw at left with moveintop:
        yalign 0.0
    show klaw2 at left with moveinbottom:
        yalign 1.0
    "他们攻击和格挡，试图占据上风。"
    if girl:
        galleryunlock bekbekf
        show klawf at right with moveinright
    else:
        galleryunlock bekbekm
        show klawm at right with moveinright
    "你决定扭转局势。当你施展伊欧给你的冰符文时，你能感觉到手在燃烧。"
    "你的身体并不适合这种魔法。当你产生施法意图的那一刻，符文就已经开始使你的手指坏死。"
    "尽管如此，这可能是你重新控制局势或一击杀死两个巫师的唯一方法。你要施展符文吗？"
    show pboy at horzappear
    menu:
        "施展它":
            hide pboy
            play sound "sound/effects/shield.mp3"
            queue sound "sound/effects/freeze.mp3"
            galleryunlock popsicle
            scene icebledar with flashbulb
            "咬紧牙关，你释放了符文。你的手变成了一团丑陋的黑色肿块，无力地垂着——然而，却没有痛感。"
            "你感觉不到任何东西，也无法移动它。至少，你终于引起了面前两位神的注意。"
            "这是一个值得的牺牲。"
            show icebledar1 at right with moveintop
            seth "哈！"
            play sound "sound/effects/glass.wav"
            show icebledar2 at left with moveinbottom
            iv "唔！"
            "伊瓦尔和塞斯在他们字面意义上掐住对方喉咙的那一刻被冻结了。这是一幅值得欣赏的雕塑。"
            scene kuburan with dissolve
            show seth grin at right with dissolve:
                yoffset 150
            show ivar kzl at left with dissolve:
                yoffset 150
            seth sigh "好吧，这场面有点尴尬。"
            seth bete frusta "伊欧的冰符文。我一直在想什么时候能再次见到它。"
            iv kzl frusta "[povname]，你在做什么？！立刻放开我！"
            if girl:
                show palmierproxy apa sweat at center with dissolve:
                    yoffset 40
            else:    
                show palmierproxy apa sweat at center with dissolve:
                    yoffset 100
            mc confused sigh "听着，我只需要你们中的一个治愈菲亚，好吗？还有你，塞斯，你最好现在就解除对我妹妹的咒语！"
            seth grin cling "如此漂亮的嘴唇，却说出这么凶狠的话。我现在明白为什么梅扎、伊欧和伊瓦尔都爱上了你。"
            seth "如果我早点认识你，我会很乐意偷走你那张美丽的脸。"
            mc pissed frusta "我知道我很辣，谢谢。现在他妈的放了我妹妹！"
            seth cray cling "啊哈哈哈！你以为我会让我的任何玩具逃脱吗？她是我的！"
            iv frown sigh "直接杀了我们两个吧，[povname]。杀了我们，拿走我们的心脏，一旦塞斯死了，咒语应该就会解除。"
            iv -sigh "不仅是菲亚身上的咒语，这里所有村民都会获得自由。"
            mc side sweat -frusta "等等，杀了你？！但是——"
            scene kuburan with dissolve
            show buff sad sweat at center with dissolve:
                yoffset 770
            "你转头看向莱尔，他仍被束缚在空中，无法挣脱施加在他身上的咒语。"
            "你内心的一部分曾希望莱尔能了解伊瓦尔，理解他为什么会做出那些事。"
            hide buff with dissolve
            show seth grin at right with dissolve:
                yoffset 150
            show ivar kzl at left with dissolve:
                yoffset 150
            if girl:
                show palmierproxy ew sweat at center with dissolve:
                    yoffset 40
            else:    
                show palmierproxy ew sweat at center with dissolve:
                    yoffset 100
            iv "别对我感情用事。这就是我想要的。这也是你从一开始就打算做的！"
            seth datar sigh "如此渴望死亡。请不要相信他这么做是出于善意！"
            show palmierproxy confused shock
            seth cray -sigh "你知道他为什么如此渴望拥抱死亡吗，美人？他有没有告诉过你他胸前的纹身是什么意思？"
            if 'iv_curhat' in fia_events:
                mc kzl frusta "它意味着他可以在死后控制[povname]的身体。是的，他告诉过我。"
                mc side sigh "但他不会这么做的，他承诺过！"
                seth bete apa "你相信他？真的吗？"
                mc kzl -sigh "他至今还没有对我撒谎。"
                seth cray -apa "哦。他是不是告诉你他比那些猎巫人更值得信任，说他绝不是个骗子？"
                seth grin "拜托，宠物，你可不是第一个被他那罪恶的舌头诱惑的人。"
                seth datar "说到罪恶，你知道有一种方法可以看穿他的谎言吗？"
                seth "这只是我在我们...关系还不错的时候从他的基因中发现的一个小技巧。"    
            else:
                mc sad tanya "不知道？但这和——有什么关系？"
                seth cray cling "你想知道吗？你知道，我当时和其他人玩得很开心。"
                seth grin -cling "伊欧的蛇，科尔的血，伊瓦尔的舌头。没什么大不了的，只是我在我们...关系还不错的时候从他的基因中发现的一个小技巧。"
                mc pissed frusta "你在胡说八道什么？"
                show palmierproxy kzl shock
                seth cray cling "为什么不自己去发现呢？"
            show palmierproxy frown shock
            seth grin sigh "尝尝他的舌头，你就能在脑海中看到他所有的谎言。"
            show palmierproxy sad -shock
            seth cray cling "亲自看看他到底有多诚实。"
            iv kzl shock "不！别听他的，只要你杀了塞斯，菲亚就会没事的！"
            iv frusta "不要——"
            iv sigh"请不要侵犯我。你知道我已经受够了这种事。"
            show pboy at horzappear
            menu:
                "亲吻他":
                    hide pboy
                    "你本想说不，但你的本性占了上风。"
                    "你一直是个好奇的人，也许太好奇了。总是把鼻子伸到不该伸的地方。"
                    "他们说好奇心会害死猫，但如果能知道真相，你会欣然冒这个险。"
                    jump kissu_iv
                "相信伊瓦尔":
                    hide pboy
                    "他的恳求触动了你的心弦。你知道更好、更安全的做法是了解全局。"
                    "检查他的话是否属实可能会很有帮助，但你内心的一部分已经喜欢上了伊瓦尔。"
                    "你不再把他看作一个嗜杀的怪物，而是一个被误解的人。被他的天赋折磨着。"
                    "到目前为止，他对你一直很诚实。你相信他不会食言。"
                    mc pissed frusta "我不会那样对他的。只要告诉我如何治愈菲亚，我就饶你一命。"
                    seth cray cling "治愈她？没有治愈的方法。我的统治是绝对的。唯一能让她获得自由的方法就是杀了我，宠物。"
                    mc kzl -frusta "（他似乎并不因为这个选择而恼怒。实际上，他看起来...很兴奋。为什么？）"
                    iv kzl shock "不会吧...你是不是——"
                    jump perc_iv
        "不要施法":
            hide pboy
            if girl:
                galleryunlock blufemf
                scene blufemf with flashbulb
            else:
                galleryunlock blufemm
                scene blufemm with flashbulb
            "失去手的恐惧战胜了你。你举起双手走近他们，试图显得无害。"
            mc ow frusta "停下！我说停下，一定有办法——"
            seth bete frusta "闭嘴！"
            play sound "sound/effects/slashkut.wav"
            show bg_black with wet
            "那是一个月亮形状的咒语。美丽动人。你还没来得及欣赏它，它就深深地嵌入了你的脖子。"
            play sound "sound/effects/splash.wav"
            stop music
            buff "[povname]！！！"
            iv "不..."
            "你的头滚落在地，莱尔和伊瓦尔因你的死亡而愤怒地尖叫。"
            "你死了，因为你愚蠢地以为可以和巫师谈判。也许在之前所有幸运的遭遇之后，你低估了他们。"
            "也许这就是你注定的命运。无论如何，一切都结束了。巫师们的命运、菲亚和你朋友们的命运，一切都悬而未决。"
            "安息吧，[povname]。你应得的。"
            jump bad_end_game
label perc_iv:
    show palmierproxy sad shock
    show ivar kzl shock
    show seth tat cray sigh with flashbulb
    "塞斯的左脸发光了。一个纹身显现出来，和你在伊瓦尔胸前看到的一样。"
    seth grin cling "赫卡特之蔷薇是个变幻莫测的东西。如果做错了，你就会被困在自己的思维中，而身体会蒸发。"
    seth datar -cling "但如果做对了，嗯...只要我的心脏还活着，我就能永生。我将能够控制任何庇护我心脏的宿主。"
    seth cray "这包括你的另一个自我。"
    if 'iv_curhat' in fia_events:
        mc pissed frusta "我知道。伊瓦尔已经告诉我了！"
        show palmierproxy kzl -frusta
        seth datar sigh "是吗？好吧，我想你们的关系比我想象的要深厚。"
        seth cray apa "不过，你为什么这么确定他不会附身你的另一个自我？"   
    else:
        $ fia_events.append('iv_curhat')
        seth grin cling "我打赌他隐瞒了这个有趣的小事实，对吧？"
        mc ew -shock"我——"
        iv kzl sigh "我发誓我不会附身[povname]！"
        mc ow frusta "但你为什么之前没告诉我这个？"
        iv kzl"..."
        mc pissed -frusta "怎么？你想不出谎言所以选择保持沉默？"
        iv frusta "[povname]，我从来没有对你撒过谎！"
        iv frown sigh "只是省略了真相而已。"
        show ivar -sigh
    seth pissed frusta "得了吧，你在这里的经历难道没教会你什么吗？你永远不能相信一个巫师。"
    mc apa tanya "你知道，这也包括你自己。"
    show palmierproxy kzl -tanya
    seth cray cling "我知道，但我站在胜利的一方。我不需要被信任。只需要被服从。"
    seth frown sigh "况且，你为什么非要卷入这一切呢？你只是个局外人。"
    seth grin -sigh "我一直在观察你。你只是那个自负的英克威尔小子带来清理他自己烂摊子的复制品。"
    jump bargaining
label kissu_iv:
    iv kzl frusta "不！不！"
    play sound "sound/effects/cloth.mp3"
    if girl:
        show ivar_kissf with fade
        galleryunlock ivar_kissf
    else:
        show ivar_kissm with fade
        galleryunlock ivar_kissm
    "你吻了他，尽管他试图把头扭开。你固定住他的位置，将嘴唇贴上他的。"
    "起初你什么也感觉不到，只尝到了他的舌头，不知为何让你想起了菊花和蜂蜜的味道。"
    "但随后你听到了，清晰无比。"
    iv "（我就快成功了。就快要清除这片土地上的害虫了。它们将成为我私人花园的养料。）"
    if girl:
        hide ivar_kissf with vpunch
    else:
        hide ivar_kissm with vpunch
    play sound "sound/effects/punch.mp3"
    mc pissed shock "你撒谎了！！！" 
    $ fia_events.append('iv_kissed')
    play sound "sound/effects/cloth.mp3"
    show ivar sigh
    show seth cray cling
    "你尖叫着结束了这个吻。伊瓦尔咆哮着朝你吐口水，仿佛对舌头上残留的你的味道感到厌恶。"
    mc ew frusta "你说你只是要放手的！"
    iv kzl frusta "我花了几个世纪，几个世纪！像猎物一样被追捕，我的孩子们一个接一个被杀害...甚至不得不看着他们的尸体被公开游街示众！"
    iv "我应该得到复仇，我应该得到更好的！"
    show ivar kzl -frusta
    seth bete sigh "你看到我这100年来经历的了吗？我早该多年前就把那张嘴缝上。"
    mc ow "我信任你！那天在花园里，当我们埋葬伊欧的时候...对你来说那毫无意义吗？！"
    iv frown sigh "我那时说的是实话，分享了我的过去。那不是谎言。但听到这些，你难道不能对我有一点同情吗？"
    iv -sigh "我从未要求生来就是这样。对这个世界来说，重新开始将是一种祝福。"
    mc pissed "重新开始？！你在考虑把所有人都变成花！"
    iv ancam cling "然后重新开始，死亡将带来生命，新的生命。无论那可能是什么。"
    seth datar "这就是了。真实的、诚实的真相。"
    seth grin cling "你知道你不能相信他，宠物。实际上，你也不能相信我们两个。"
    seth cray -cling "但你可以与胜利的一方做交易。"
    show seth tat with dissolve
    show ivar kzl shock
    show palmierproxy frown shock
    "塞斯的左眼发光了。一个图案开始出现在他的脸颊上。那是和伊瓦尔胸口上一样的纹身。"
    mc pissed -shock "你也是？"
    show ivar -shock
    seth datar sigh "当然。我们巫师总是做好准备。现在，我不会说谎，我无意放过你的分身。"
    seth cray cling "我不会的。我会在你把我放进去的那一刻就接管[dia]的身体。"
    seth grin -cling "但在我短暂的死亡之后，菲亚将获得自由。而在我升华之后，我会确保她过上幸福的生活。"
    seth datar "这不是你的战斗。毕竟，这不是你的世界。你只是那个自负的英克威尔小子带来清理他自己烂摊子的复制品。"
    jump bargaining
label bargaining:
    $ fia_events.append('barganing')
    seth cray cling "杀了我们两个，先把我的心放进容器的身体里。当你的另一个自我醒来时，我向你保证我会毫发无损地送你回到你的世界。"
    seth datar -cling "我甚至会让你带着你的一个爱人回去。你不需要知道这里的恐怖，你可以简单地在无知的幸福中逃离。"
    show ivar kzl shock
    seth happy "做出你的选择吧，宠物。"
    show palmierproxy rajuk -sweat sigh
    show pboy at horzappear
    menu gomb:
        "同意塞斯的提议":
            hide pboy
            show palmierproxy kzl sigh
            $ fia_events.append("seth_khianat")
            seth cray cling "明智的选择。"
            iv kzl frusta "叛徒！"
            seth grin -cling "伊瓦尔，从你嘴里说出来真是讽刺。"
            seth happy "现在，挥动你的武器吧，宠物。只需一小击，一切就结束了。"
            scene bg_black with fade
            stop music
            play sound "sound/effects/sword.mp3"
            galleryunlock kemayu
            show sethded at left with moveinleft
            show sethded2 at right with moveinright
            "你用仅剩的一点力气在左手凝聚出一把冰刃，然后挥了下去。"
            play sound "sound/effects/jelly.mp3"
            if girl:
                scene jem_bothf with flashbulb
                galleryunlock gem_both
            else:
                scene jem_bothm with flashbulb
                galleryunlock gem_both2m
            "他们的头颅滚落在地，不久后两颗明亮的宝石悬浮在他们的脖子上方。"
            play sound "sound/effects/crash.mp3" 
            "在你身后，你听到一声巨响，束缚莱尔的咒语被打破了。"
            stop music
            scene kuburan with fade
            show buff sad sweat at center with dissolve:
                yoffset 770
            buff keluh "我简直不敢相信，你做到了。你杀死了那些巫师。但代价是什么？"
            if girl:
                show palmierproxy side sweat at left with dissolve:
                    yoffset 40
                    
            else:    
                show palmierproxy side sweat at left with dissolve:
                    yoffset 100
            show buff kzl at right with move
            mc ow "莱尔——"
            buff scold frusta "你，你不会真的要这么做吧？你会把那些宝石扔掉的，对吧？"
            mc side sigh "我——"
            
            play sound "sound/effects/woosh.mp3"
            show buff kzl shock
            show croissant flinch mad at center with vpunch:
                yoffset 500
            "你还没来得及回答，就感到一阵风把你和莱尔推了回去。然后你看到菲亚抓住了两颗宝石。"
            mc ow shock "菲亚！"
            "菲亚将它们紧紧地抱在胸前，仿佛它们是世界上最珍贵的宝藏。"
        "杀死他们两个，之后再做决定":
            hide pboy
            mc pissed sigh "我会杀了你们。你们两个。"
            $ fia_events.append("pasrahin")
            mc wry -sigh "但我不会和你做交易。我相信我的另一个自己。"
            mc mean "[povname]会摆脱你的影响，[kamu]会胜利的。"
            show ivar amused sigh
            show palmierproxy kzl 
            seth cray cling "啊哈哈哈。我们拭目以待吧，宠物？"
            scene bg_black with fade
            stop music
            play sound "sound/effects/sword.mp3"
            galleryunlock kemayu
            show sethded at left with moveinleft
            show sethded2 at right with moveinright
            "你用仅剩的一点力气在左手凝聚出一把冰刃，然后挥了下去。"
            play sound "sound/effects/jelly.mp3"
            if girl:
                scene jem_bothf with flashbulb
            else:
                scene jem_bothm with flashbulb
            "他们的头颅滚落在地，不久后两颗明亮的宝石悬浮在他们的脖子上方。"
            play sound "sound/effects/crash.mp3" 
            "在你身后，你听到一声巨响，束缚莱尔的咒语被打破了。"
            stop music
            scene kuburan with fade
            show buff sad sweat at center with dissolve:
                yoffset 770
            buff keluh "我简直不敢相信，你做到了。你杀死了那些巫师。但代价是什么？"
            if girl:
                show palmierproxy side sweat at left with dissolve:
                    yoffset 40
                    
            else:    
                show palmierproxy side sweat at left with dissolve:
                    yoffset 100
            show buff kzl at right with move
            play music "MUSIC/heart.mp3"
            mc ow "莱尔——"
            buff sad apa "你，你不会真的要这么做吧？你会把那些宝石扔掉的，对吧？"
            mc deject sigh "不。我要再次唤醒[povname]。我告诉自己我不会让菲亚遭受我的命运。"
            mc kzl -sigh "我不会让她失去她的[kk]，我不会。"
            show croissant wry at center with dissolve:
                yoffset 500
            fia happy blush "...谢谢你。"
            mc hister blush shock "菲亚！"
            show buff sad shock
            play sound "sound/effects/cloth.mp3"
            show palmierproxy smile bunga
            show croissant hister bloom
            "你看到菲亚一瘸一拐地向你走来。受伤了，但还活着。如此鲜活。"
            play sound "sound/effects/jelly.mp3"
            if girl:
                show jem_bothf with flashbulb
            else:
                show jem_bothm with flashbulb
            "她扑进你的怀里。伊瓦尔和塞斯的心脏在你们之间跳动。"
            "他们的宝石明显与你之前拥有的不同，更加...有生气。"
            if girl:
                hide jem_bothf with dissolve
            else:
                hide jem_bothm with dissolve
            show buff sad -sweat sigh
            mc malu sigh "你没事。"
            fia annoyed sweat sigh "我是说，我不会说手臂上有二度烧伤是没事，但...我会没事的。"
            fia wry -sigh "海德温的治疗药水就能治好。"
            fia mmh apa "你知道吗，我听到了一切？你不是我真正的[kk]，对吧？"
            if not girl2:
                mc side sweat sigh "不，我...我不是这里的人。我是[dia2]的另一个版本。"
            else:
                mc side sweat sigh "不，我...我不是这里的人。我是[dia]的另一个版本。"
            mc ha "这很复杂。"
            show palmierproxy frown shock
            fia sad sigh "无论如何，试着向我解释一下？还有，我能拿着那些宝石吗？"
            fia gross -sigh "不是我不信任你，但...为了一些安心？"
            show croissant wry -sweat 
            mc malu sigh "当然。给你。"
            show palmierproxy kind -sweat -sigh
            "菲亚小心翼翼地将它们抱在怀里，然后安全地藏在她的裙子里。"
            fia pity sigh "谢谢。我们现在能去看看我的[kk]吗？还有那个造成这一切的罪魁祸首？"
            mc scratch ha sweat "啊，好的。只是，别杀奎尔，好吗？"
            show palmierproxy kind -sweat sigh
            fia mock cling "我不能保证。"
            jump fia_reuni_kalem
        "{s}相信伊瓦尔{/s}" if "iv_kissed" in fia_events:
            
            jump gomb
        "相信伊瓦尔" if "iv_kissed" not in fia_events:
            hide pboy
            $ fia_events.append("trust_ivar")
            mc pissed frusta "也许我很天真，但我相信伊瓦尔。"
            mc deject -sweat sigh "我相信当关键时刻到来时，他会做出正确的选择。"
            mc mean -sigh "他会在我另一个自己的身体里保持温顺。"
            seth bete sigh "你这个傻瓜。"
            iv amused sigh "...谢谢你。当时机到来时，先把我的宝石插入[povname]的身体。"
            iv awk -sigh "如果塞斯还想夺取控制权，我应该能占上风。"
            seth pissed frusta "你这个傻瓜！你害死我们所有人了！我发誓，我不会让你——"
            scene bg_black with vpunch
            play sound "sound/effects/shing.ogg"
            galleryunlock kemayu
            show sethded at left with moveinleft
            show sethded2 at right with moveinright
            "他还没说完，你就在手中凝聚出一把冰刃，砍下了他们的头。"
            play sound "sound/effects/jelly.mp3"
            if girl:
                scene jem_bothf with flashbulb
            else:
                scene jem_bothm with flashbulb
            "他们的头颅滚落在地，不久后两颗明亮的宝石悬浮在他们的脖子上方。"
            play sound "sound/effects/crash.mp3" 
            "在你身后，你听到一声巨响，束缚莱尔的咒语被打破了。"
            stop music
            scene kuburan with fade
            show buff sad sweat at center with dissolve:
                yoffset 770
            buff keluh "我简直不敢相信，你做到了。你杀死了那些巫师。但代价是什么？"
            if girl:
                show palmierproxy side sweat at left with dissolve:
                    yoffset 40
                    
            else:    
                show palmierproxy side sweat at left with dissolve:
                    yoffset 100
            show buff kzl at right with move
            mc ow "莱尔——"
            buff scold frusta "你，你不会真的要这么做吧？"
            buff keluh sigh "不要低估我父亲！他在玩弄你！你会把那些宝石扔掉的，对吧？"
            mc side sigh "我——"
            play sound "sound/effects/woosh.mp3"
            show buff kzl shock
            play music "MUSIC/PerituneMaterial_Piano_Sad2.mp3"
            show croissant flinch mad at center with vpunch:
                yoffset 500
            "你还没来得及回答，就感到一阵风把你和莱尔推了回去。然后你看到菲亚抓住了两颗宝石。"
            mc ow shock "菲亚！"
            "菲亚将它们紧紧地抱在胸前，仿佛它们是世界上最珍贵的宝藏。"
        "离开":
            hide pboy
            mc pissed frusta "不，你知道吗？我受够了！我不想再参与这件事了！"
            mc kzl sigh "我要回学校去，我要告诉教授们我身上真正发生了什么。"
            mc -sigh "我会找到回家的方法，我不会让你们任何人控制[povname]！"
            seth bete sigh "你让我失望，宠物。但我不该对一个连想都没想过要保护[dia]的人抱有任何期望。"
            seth cray cling "亲爱的菲亚，替我杀了他好吗？"
            mc ow shock"什么——"
            show ivar kzl shock
            $ fia_events.append("walk_away")
            scene kuburan with dissolve
            play sound "sound/effects/tile.mp3"
            show croissant flinch kzl at center with dissolve:
                yoffset 500
            "从眼角余光中，你看到菲亚朝你跑来，手里握着一把闪着寒光的冰刀。"
            scene bg_black with eye_shut
            play sound "sound/effects/shing.ogg"
            "你闭上眼睛，以为这就是最后的时刻了。你杀了你的姐妹，如果你的死亡是由她的另一个版本造成的，那也是公平的。"
            play sound "sound/effects/slashkut.wav"
            "但死亡的冰冷触感并没有降临。当你睁开眼睛时，你的心跳比以往任何时候都要响亮。"
            play sound "sound/effects/glass.wav"
            galleryunlock kemayu
            show sethded at left with moveinleft
            show sethded2 at right with moveinright
            stop music
            "塞斯和伊瓦尔。世界上最后两个纯血巫师，菲亚砍下了他们两个的头颅。"
            "一瞬间，那些宝石立即飞到了你的手掌中，比你见过的任何宝石都要闪耀。"
            play sound "sound/effects/jelly.mp3"
            if girl:
                scene jem_bothf with flashbulb
            else:
                scene jem_bothm with flashbulb
            "然而，你对它们的赞叹很快被打断了，因为菲亚一把抢走了这些宝物，紧紧地护在胸前。"
            scene kuburan with fade
            play music "MUSIC/PerituneMaterial_Piano_Sad2.mp3"
            show croissant flinch mad at center with dissolve:
                yoffset 500
            show buff sad sweat at right with dissolve:
                yoffset 770
            buff scold apa "[povname]，菲亚，你们没事吧？！"
            show buff sad -apa
            if girl:
                show palmierproxy sad sweat at left with dissolve:
                    yoffset 40
            else:    
                show palmierproxy sad sweat at left with dissolve:
                    yoffset 100
            "莱尔终于挣脱了锁链。他跑向你，用一瓶药水治疗了你。"
            "你的手因伊欧的符文还在疼痛，但情况正在好转，你不用担心会很快失去一根手指。"
            "你感谢了莱尔，然后慢慢地走向菲亚。她显然对你很警惕。"
    mc pissed frusta "菲亚，把宝石给我。"
    show palmierproxy ow shock
    fia kzl sigh "为什么？这样你就可以把它们扔掉吗？"
    show palmierproxy side -shock
    fia cringe frusta "我都听到了！你骗了我！你根本不是我的[kk]。我的[kk]，我的咕噜怎么了？！"
    fia jijik -frusta "带我去见我的[kk]！现在！"
    mc ow sigh "我...好...好吧。"
    jump fia_reuni_marah
label fia_reuni_marah:
    $ fia_events.append("fia_marah")
    stop music
    scene bg_black with w20
    scene kmr_apt with w20
    if girl:
        show palmierproxy ow sweat at left with dissolve:
            yoffset 40
    else:    
        show palmierproxy ow sweat at left with dissolve:
            yoffset 100
    play sound "sound/effects/cloth.mp3"   
    mc frusta "啊！" with vpunch
    if "companion" in red_events:
        show red chin sad at right with moveinright:
            yoffset 330
            xzoom -1.0
        red ow sweat shock "对不起，我会温柔点的。"
        show red sad -shock
        show palmierproxy sad sigh
        "你向所有人讲述了发生的事情。阿什姆、塞恩和奎尔立即赶到了[povname]身边。"
        "菲亚一见到奎尔就打了他一拳。阿什姆尽力制住她，而塞恩则忙着查看你的伤势。"
        if mrh.points >= 80:
            red ngeles sigh "我的灵魂，我很抱歉没能保护你。"
        red sad frusta "我应该和你在一起的。我简直不敢相信你独自杀死了两个纯血巫师。"
        mc deject -sweat sigh "其实是他们互相杀死的。"    
    else:
        show tom talk sad at right with moveinright:
            yoffset 190
        tom whine sweat frusta "抱歉。再等一下就结束了。"
        show tom sad blow
        "你向所有人讲述了发生的事情。阿什姆、塞恩和奎尔立即赶到了[povname]身边。"
        "菲亚一见到奎尔就打了他一拳。塞恩尽力制住她，而阿什姆则忙着查看你的伤势。"
        tom capek frusta "我很抱歉我们没能及时赶到。我无法想象你面对两个纯血巫师的感受。"
        show tom sad -frusta
        mc wry -sweat sigh "嘿，我活下来了，不是吗？"
    mc deject -sigh "况且..."
    mc ow frusta "他们都没有菲亚现在这么残暴。"
    play sound "sound/effects/crash.mp3"
    scene kmr_apt with vpunch
    show croissant flinch jijik at center with dissolve:
        yoffset 500
    fia kzl sweat frusta "我要杀了你！我发誓我要杀了你。"
    play music "MUSIC/MusMus-BGM-084.mp3"
    show tom kzl sweat blow at right with moveinright:
        yoffset 190
    tom "控制住自己，菲亚，杀了他对唤醒你的[kk]没有任何帮助！"
    show red ow sweat at left with moveinleft:
        yoffset 330
    red bingung "冷静点，女人，冷静点！我们已经有了所有的心脏，[povname]会没事的！"
    show red ew shock
    show tom sad -blow
    fia mad sigh "但如果我们没有那些心脏呢，嗯？！如果[kamu]死了呢？！"
    fia mmh -sigh "奎尔，你没有权利对我隐瞒这些事！"
    hide red with dissolve
    show quil err sweat frusta at left with moveinleft:
        yoffset 200
    quil sulk sigh "我知道，但你不能怪我隐瞒它们。你差点杀了我！"
    fia kzl frusta "就像你差点杀了我的[kk]一样！"
    quil fluster frusta "好吧，公平。所以我们扯平了，对吧？"
    fia mad sigh "哦，我们离扯平还远着呢，远着呢！"
    show quil sad sigh
    "菲亚的手开始发光，准备再次投掷符文。"
    show croissant mmh shock
    hide tom with dissolve
    show buff kzl sweat frusta at right behind croissant with moveinright:
        yoffset 770
    play sound "sound/effects/punch.mp3"
    show croissant with move:
        xalign 0.65
    "然而，莱尔介入了，用他强壮的手臂把她困住。"
    fia jijik frusta "什么？！放开我，放开我！"
    buff keluh sigh "对不起，菲亚小姐，但我保证一旦你冷静下来我就放开你，好吗？"
    fia mad "我怎么能——放开我，你——呃！好吧！"
    fia annoyed -sweat sigh "我冷静了。现在放开我！"
    buff wry apa "你不会伤害奎尔，拉钩保证？"
    fia err -sigh "啊...拉钩保证，你这个大泰迪熊。我发誓。"
    play sound "sound/effects/cloth.mp3"
    show buff kzl shock
    show croissant mock cling with move:
        xalign 0.4
    play sound "sfx/umph.mp3"
    "莱尔刚把菲亚放下，她就冲上去一拳打在奎尔的裆部。" with vpunch
    show croissant jijik frusta
    quil groan shock "哎哟，操！！！"
    buff keluh -shock "但是...你拉钩保证了。"
    show quil tantrum frusta
    show buff sad
    fia jijik frusta "我撒谎了。你应该感恩只有这一下，不像这混蛋对我说的上百个谎言！"
    hide buff with dissolve
    if girl:
        show palmierproxy side sweat at right with dissolve:
            yoffset 40
    else:
        show palmierproxy side sweat at right with dissolve:
            yoffset 100
    "菲亚直指着你，你不禁觉得她的愤怒是有道理的。"
    show palmierproxy sad sigh
    fia cringe shock "...等等，别那样看着我。别站在那里用我[kk]的狗狗眼看我！这太不公平了！"
    show croissant sad frusta at center with move
    mc ew frusta "我很抱歉，菲亚。我知道我应该告诉你的，但我就是不能，我...我想保护你。"
    mc sad sigh "在某种程度上也是为了保护奎尔。我是说，我想你刚刚毁掉了他生育的所有机会。"
    fia jijik frusta "那又怎样？没有英克威尔家族的人，这个地方会好得多。"
    fia err -frusta "但是...我想我能理解你的意思。"
    fia sad sigh "不管怎样，谢谢你杀死了所有其他的巫师。你不是一个坏[kk]，[povname]。"
    show palmierproxy wry -sweat sigh
    show quil wry -sweat sigh
    "你对此露出了微笑，希望你的菲亚至少也能欣赏有你这样的兄弟姐妹。"
    fia jijik "但你仍然不是我的[povname]，所以让开！"
    scene kmr_apt with dissolve
    play sound "sound/effects/walk.mp3"
    "菲亚走到你另一个自我的身体旁。她把两颗宝石放在[dia]沉睡的身体上。"
    show quil wry at left with dissolve:
        yoffset 200
    show tom sad at right with dissolve:
        yoffset 190
    show croissant flinch mad sweat frusta at center with dissolve:
        yoffset 500
    quil hister sigh "就是这样了。[povname]终于要醒来了。"
    tom lega blow "是的，我们做到了。当然，之后肯定会有一些复杂的情况，但是...不管发生什么，我们都会让我们的[povname]回来。"
    quil sulk apa "我猜你不会让我来做这个荣耀的事情，对吧，菲亚？"
    show tom sad -blow
    show quil err shock
    fia kzl -frusta "No!" with vpunch
    show quil sulk -shock
    show pboy at horzappear
    menu last_choice:
        "说服菲亚重新考虑" if 'pasrahin' not in fia_events:
            hide pboy
            fia sad "你怎么敢！这是我的[kk]！"
            fia kzl "就因为你的妹妹死了，并不意味着我们也要步你的后尘！"
            if "walk_away" in fia_events:
                fia jijik frusta "你在岛上试图离开。别以为你现在可以钻空子！"
            elif "pasrahin" in fia_events:
                fia mmh frusta "你在岛上相信了我的[kk]。什么改变了？"
            elif "trust_ivar" in fia_events or "seth_khianat" in fia_events:
                fia kzl frusta "你试图把我的[kk]卖给一个巫师，就像某种可以随意丢弃的廉价饰品！"
            else:
                fia mad apa "如果你有机会纠正你的错误，让你的菲亚复活，你不会这么做吗？"
                show side_p m at pic
                mc "毫不犹豫..."
                hide side_p
                fia jijik frusta "哦，现在你倒是诚实了。你这个伪君子。"
            fia mad sigh "我已经做出了决定。就站在后面让我做我必须做的事吧！"
            stop music
            play sound "sound/effects/bump.mp3"
            if girl:
                show bobo_f with vpunch
            else:
                show bobo with vpunch
            play sound "sound/effects/jelly.mp3"
            show bobo_seth with moveinright:
                xpos 881 ypos 261
            "菲亚猛地将两颗宝石按入她[kk]的胸膛。"
            hide bobo_seth with flashbulb
            play sound "sound/effects/woosh.mp3"
            "刺眼的光芒让你睁不开眼，你能感觉到一股强烈的风扑面而来。"
            scene kmr_apt with fade
            if girl:
                show palmierproxy dobel frown mata at center with dissolve:
                    yoffset 40
            else:
                show palmierproxy dobel frown mata at center with dissolve:
                    yoffset 100
            "当你睁开眼睛时，你看到了一张庄严的面孔。一双银色的眼睛俯视着你。你的另一个自我终于醒来了。"
            $ fia_events.append('even_take_over')
            jump mc_bangkit
        "{s}说服菲亚重新考虑{/s}" if 'pasrahin' in fia_events:
            
            jump last_choice
        "{s}告诉她先放入伊瓦尔的宝石{/s}" if 'pasrahin' in fia_events or "iv_kissed" in fia_events:
            
            jump last_choice
        "告诉她先放入伊瓦尔的宝石" if 'pasrahin' not in fia_events and "iv_kissed" not in fia_events:
            if 'bargaining' in fia_events or 'iv_curhat' in fia_events:
                hide pboy
                show quil grit sweat shock
                show tom kzl sweat shock
                show croissant mad sweat shock
                show side_b skul kzl at pic 
                buff "什么？！不可能！"
                hide side_b
                tom kzl -shock "[povname]，现在不是开玩笑的时候。"
                show tom capek frusta
                show quil kzl -shock
                show side_p s at pic
                mc "为了安全起见，他总比塞斯好——！"
                hide side_p
                fia kzl frusta "我不会让任何人使用我[kk]的身体！我的[kk]会胜利的，[kamu]会醒来的。"
                fia cringe sigh "作为我的[kk]，而不是其他人。你会看到的！"
                show croissant mad -sigh
                if "trust_ivar" in fia_events:
                    show side_p s at pic
                    mc "但我相信伊瓦尔，菲亚！他是个好人！"
                    show side_p m
                    mc "他只是被误解了，就像你的[kk]一样，拜托。"
                    mc "你知道如果我们同时放入两颗宝石，塞斯或伊瓦尔控制他们身体的机会是五五开。"
                    show side_p s 
                    mc "但如果你先放入伊瓦尔的，那么他就根本不会占据你[kk]的身体！他承诺过他不会的！"
                    hide side_p
                    hide tom with dissolve
                    show buff kzl sweat at right with moveinright:
                        yoffset 770
                    buff keluh frusta "看在科尔的份上，这是一个毁灭了两个国家的人！"
                    show quil tantrum 
                    buff scold "这个杀死了所有儿子并把他们变成花仆的人。不要先放入伊瓦尔的宝石！"
                    show buff kzl 
                    fia gross apa "...奎尔？"
                    quil sulk sweat sigh "我已经剥夺了你一次选择的机会，菲亚。这次由你来决定。"
                    fia sad "..."
                    play sound "sound/effects/cloth.mp3"
                    show quil fluster shock
                    show buff eh shock
                    show croissant err sigh 
                    "出乎你的意料，菲亚听从了你的建议，先放入了伊瓦尔的宝石。它闪烁了一下，然后消失在[povname]的胸膛里。"
                    buff scold frusta "该死！"
                    stop music
                    if girl:
                        show bobo_f with dissolve
                    else:
                        show bobo with dissolve
                    "[povname]的手指抽动了一下，这是菲亚放入最后一颗宝石的信号。最后一颗心脏将唤醒你的另一个自我。"
                    show seth_hati1 with moveinright:
                        zoom 0.4
                        xpos 1029 ypos 282
                    play sound "sound/effects/vine.wav"
                    hide seth_hati1 with flashbulb
                    "当塞斯的宝石消失的那一刻，你感到地面震动，数百朵花盛开了。"
                    scene kmr_apt with fade
                    if girl:
                        show palmierproxy dobel frown mata at center with dissolve:
                            yoffset 40
                    else:
                        show palmierproxy dobel frown mata at center with dissolve:
                            yoffset 100
                    "你的另一个自我终于醒来了。"
                    $ fia_events.append('ivar_take_over')
                    jump mc_bangkit
                elif "seth_khianat" in fia_events:
                    fia jijik frusta "我不知道你在这里玩什么把戏。就在几个小时前，你还试图把我[kk]的身体卖给塞斯。"
                    fia kzl sigh "但我想我不应该对你这样的骗子抱有太多期望。"
                    fia err -sigh "我相信我的[kk]。格兰布尔斯总会回到我身边。不像你，你算什么[kk]。"
                    fia sad sigh "我为你的菲亚感到遗憾。她应该得到更好的。"
                    quil grit shock "菲亚，住手！"
                    fia mad -sigh "哼！"
                    show tom sad blow
                    show quil sulk sigh
                    "当塞恩和阿什姆都拍拍你的背以示安慰时，你保持沉默。"
                    "她的话伤人，直刺你的心脏，你甚至无法反驳任何一句。"
                    stop music
                    play sound "sound/effects/bump.mp3"
                    if girl:
                        show bobo_f with vpunch
                    else:
                        show bobo with vpunch
                    play sound "sound/effects/jelly.mp3"
                    show bobo_seth with moveinright:
                        xpos 881 ypos 261
                    "菲亚猛地将两颗宝石按入她[kk]的胸膛。"
                    hide bobo_seth with flashbulb
                    play sound "sound/effects/woosh.mp3"
                    "刺眼的光芒让你目眩，你能听到风声呼啸而来。"
                    scene kmr_apt with fade
                    if girl:
                        show palmierproxy dobel frown mata at center with dissolve:
                            yoffset 40
                    else:
                        show palmierproxy dobel frown mata at center with dissolve:
                            yoffset 100
                    "当你睁开眼睛时，你看到了一张庄严的面孔。一双银色的眼睛俯视着你。你的另一个自我终于醒来了。"
                    $ fia_events.append('seth_take_over')
                    jump mc_bangkit
                else:
                    stop music
                    play sound "sound/effects/bump.mp3"
                    if girl:
                        show bobo_f with vpunch
                    else:
                        show bobo with vpunch
                    play sound "sound/effects/jelly.mp3"
                    show bobo_seth with moveinright:
                        xpos 881 ypos 261
                    "菲亚猛地将两颗宝石按入她[kk]的胸膛。"
                    hide bobo_seth with flashbulb
                    play sound "sound/effects/woosh.mp3"
                    "刺眼的光芒让你目眩，你能听到风声呼啸而来。"
                    scene kmr_apt with fade
                    if girl:
                        show palmierproxy dobel frown mata at center with dissolve:
                            yoffset 40
                    else:
                        show palmierproxy dobel frown mata at center with dissolve:
                            yoffset 100
                    "当你睁开眼睛时，你看到了一张庄严的面孔。一双银色的眼睛俯视着你。你的另一个自我终于醒来了。"
                    $ fia_events.append('even_take_over')
                    jump mc_bangkit
            else:
                quil err apa "为什么？同时放入两颗宝石不是更好吗？"
                show quil tantrum -apa
                show tom sad blow
                fia kzl frusta "我不听你的，[povname]。我不再相信你了！"
                stop music
                play sound "sound/effects/bump.mp3"
                if girl:
                    show bobo_f with vpunch
                else:
                    show bobo with vpunch
                play sound "sound/effects/jelly.mp3"
                show bobo_seth with moveinright:
                    xpos 881 ypos 261
                "菲亚猛地将两颗宝石按入她[kk]的胸膛。"
                hide bobo_seth with flashbulb
                play sound "sound/effects/woosh.mp3"
                "刺眼的光芒让你目眩，你能听到风声呼啸而来。"
                scene kmr_apt with fade
                if girl:
                    show palmierproxy dobel frown mata at center with dissolve:
                        yoffset 40
                else:
                    show palmierproxy dobel frown mata at center with dissolve:
                        yoffset 100
                "当你睁开眼睛时，你看到了一张庄严的面孔。一双银色的眼睛俯视着你。你的另一个自我终于醒来了。"
                $ fia_events.append('even_take_over')
                jump mc_bangkit
        "同时插入那些宝石！":
            hide pboy
            fia cringe sweat sigh "我知道。"
            if "bargaining" in fia_events:
                fia sad frusta "我都听到了。我知道有风险，我的[kk]可能醒来后就不再是我的[povname]了。"
                fia wry -sweat sigh "有可能其中一个巫师会取而代之占据[dia]的身体。但是，我仍然相信我的[kk]。"
                fia mock cling "[povname]会醒来的，我敢打赌[kamu]醒来后会立即开始抱怨这一切的混乱。你等着瞧吧！"
                if "walk_away":
                    fia kzl -sweat frusta "不过你根本不在乎，[povname]，你不是说你已经放弃了吗？"
                    show side_p s at pic
                    mc "什么？不，我没有说过！"
                    hide side_p
                    fia cringe "你说过，在岛上的时候。如果你要撒谎，至少也要用点心。"
                    fia mad sigh "不过我想我不该对你有什么不同的期待。你这个骗子。"
                    fia kzl -sigh "你最好祈祷这能成功，否则我真想让你和我的[kk]遭受同样的命运。"
                    quil sulk sigh "菲亚，这一定会成功的，我确信。"
                    show quil sad -sigh
                    fia jijik sigh "最好如此。"
                elif "trust_ivar" in fia_events or "seth_khianat" in fia_events:
                    fia kzl -sweat frusta "有趣，我不记得你在岛上时试图保持中立。"
                    fia jijik "事实上，我听到的恰恰相反。"
                    fia kzl"不过我想我不该对你有什么不同的期待。你这个骗子。"
                    fia mad sigh "你最好祈祷这能成功，否则我真想让你和我的[kk]遭受同样的命运。"
                    quil sulk sigh "菲亚，这一定会成功的，我确信。"
                    show quil sad -sigh
                else:
                    fia sad -sweat -sigh "这一定会成功的，必须成功！"
            else:
                fia -sweat sad -sigh "我只希望这能成功。"
            fia cringe frusta "希望所有这些新的巫师力量不会冲昏[dia]的头脑。"
            quil groan frusta "嗯，这是个好观点。我从未想过这个细节。"
            show quil sad sigh
            fia gross apa "等等，什么？！"
            play sound "sound/effects/bump.mp3"
            if girl:
                show bobo_f with vpunch
            else:
                show bobo with vpunch
            stop music
            play sound "sound/effects/glass.wav"
            show bobo_seth with moveinright:
                xpos 881 ypos 261
            "菲亚惊呼一声，不小心将两颗宝石掉落在[povname]的胸口上。"
            play sound "sound/effects/jelly.mp3"
            hide bobo_seth with dissolve
            "你不确定它们是否同时进入了[dia]的身体。"
            scene kmr_apt with flashbulb
            "宝石融合成一体后迸发出火花，随即被吸收进[povname]的身体。"
            if girl:
                show palmierproxy dobel frown mata at center with dissolve:
                    yoffset 40
            else:
                show palmierproxy dobel frown mata at center with dissolve:
                    yoffset 100
            "房间里充满了白色雾气，[dia]的身体越来越亮，刺得你睁不开眼，直到你与一张熟悉的面孔四目相对。"
            "那是你自己的脸，只是更顽皮，更狡猾，更...危险。"
            $ fia_events.append('even_take_over')
            jump mc_bangkit
        "观察事态发展":
            hide pboy
            stop music
            if girl:
                show bobo_f with vpunch
            else:
                show bobo with vpunch
            "菲亚小心翼翼地靠近她[kk]的身体，稍微整理了一下[dia]的头发..."
            play sound "sound/effects/jelly.mp3"
            show bobo_seth with moveinright:
                xpos 881 ypos 261
            "...然后将最后两颗心形宝石放在[dia]的胸口上。"
            scene kmr_apt with flashbulb
            if girl:
                show palmierproxy dobel frown mata at center with dissolve:
                    yoffset 40
            else:
                show palmierproxy dobel frown mata at center with dissolve:
                    yoffset 100
            "房间里充满了白色雾气，[dia]的身体越来越亮，刺得你睁不开眼，直到你与一张熟悉的面孔四目相对。"
            "那是你自己的脸，只是更顽皮，更狡猾，更...危险。"
            $ fia_events.append('even_take_over')
            jump mc_bangkit
label fia_reuni_kalem:
    stop music
    scene bg_black with w20
    scene kmr_apt with w20
    play music "MUSIC/MusMus-BGM-013.mp3"
    show croissant frown at center with dissolve:
        yoffset 500
    fia gross sweat sigh "让我理清楚。"
    fia frown -sigh "我真正的[kk]已经昏迷一个月了，奎尔从另一个世界召唤了你来收拾他的烂摊子。"
    fia err "这包括杀死我们土地上四个最危险的巫师，你使用与你身体不兼容的符文..."
    fia sad "基本上被奎尔和其他两个邪恶三人组的把戏耍得团团转，而且还没有报酬？"
    fia flinch cringe frusta "奎尔，你要么是世界上最有魅力的操纵者，要么就是找到了所有存在中最可悲的傻瓜。"
    show quil wry at left with moveinleft:
        yoffset 200
    quil hister sigh "我本想说声谢谢，但我相信可悲的是后者。"
    show croissant def wry -sweat sigh
    show quil malu -sigh
    if girl:
        show palmierproxy kzl sweat at right with dissolve:
            yoffset 40
    else:
        show palmierproxy huh sweat at right with dissolve:
            yoffset 100
    mc "嘿！"
    show palmierproxy rajuk sigh
    show croissant kerja -sweat -sigh
    show quil mock  
    "你把一切都告诉了菲亚。"
    "从你的真实身份，到她[kk]身上发生的事，以及从你到来到现在发生的所有事情。"
    "在此期间，塞恩为你包扎伤口，而阿什姆则处理莱尔的伤。"
    if 'iv_curhat' in fia_events:
        "你也把一切都告诉了莱尔，还加上了你与他父亲相处的细节，以及他将所有儿子变形的原因。"
        "值得称赞的是，莱尔没有退缩。他只是茫然地盯着你，试图理解这一切。"
    mc eiden frusta "我本希望能得到更多同情，或者至少一声谢谢。"
    show palmierproxy malu -sweat -frusta
    fia pain frusta "哦，相信我，一声谢谢远远不够表达你经历的所有狗屎。"
    show palmierproxy kind 
    fia pity sigh "但我确实很感激，你知道的。你本可以随时放弃。"
    show palmierproxy mean sigh
    show quil groan sweat shock
    fia mock cling "奎尔其实比看起来要弱得多。我敢说只要踢他一脚蛋蛋就足以逼他送你回家。"
    show quil wry -sweat sigh
    show palmierproxy smile blush -sigh
    fia hister blush sigh "但你没有，你坚持下来了。在你的路上杀死了四个\'神\'。谢谢你。"
    show palmierproxy ha sweat
    show quil err sweat shock
    fia kzl -blush ang "还有，你们这些混蛋真该为没有早点让我参与进来而感到羞耻！"
    hide palmierproxy with dissolve
    show tom sad at right with moveinright:
        yoffset 190
    show quil sulk behind croissant with move:
        xalign 0.3
    show red chin ew at left with moveinleft:
        yoffset 330
        xpos -200
    show croissant with move:
        xalign 0.7
    "菲亚瞪着除了莱尔以外的所有男孩。那三个不正经的家伙都羞愧地低下了头，不自在地扭动着身体以避开菲亚犀利的目光。"
    tom capek sweat frusta "说实话，在第一次巫师事件之前我们都不知道这件事。而且我确实想告诉你，你不是唯一一个感到被背叛的人。"
    show tom ha blow
    fia def cringe -sweat -ang "我是说，我理解你们为什么什么都没说。"
    if "bond" in fia_events:
        show red kaget shock
        fia sad frusta "我预料到奎尔会保密，但塞恩？？？"
        show red ew -shock
        fia kzl ang "我们他妈的是灵魂伴侣，塞恩！这不是你对待真正灵魂伴侣的方式！"
        red ow frusta "对不起。我真的很想在我们建立联系后告诉你，但我很害怕！"
        fia jijik apa "害怕什么？？？"
        red ngeles -frusta "害怕你杀了奎尔，把他切成小块。"
        show red sad
        fia err sweat -apa "我是说...好吧，有道理。"
        quil fluster sweat shock "等等，你真的会杀了我？！"
        fia laugh -sweat cling "哦，我会阉了你，把你肢解，然后杀了你，奎尔！而且我还会很享受这个过程。"
        show croissant pain sigh
        quil groan frusta "现在你还奇怪我为什么什么都不告诉你吗？"
        show quil sad sigh
        fia kzl frusta "好吧，你是对的。恭喜你或者随便什么吧。不过我还是觉得你隐瞒这件事是个混蛋行为！"
    else:
        show quil sulk sweat
        show red sad 
        show tom sad 
        fia jijik frusta "但是奎尔？？？"
        fia gross sigh "我知道我们互相刻薄。"
        fia sad -sigh "但我确实把你当作我家人的一部分。[nickname]把你当兄弟，我也是。"
        fia cringe "我对你刻薄只是因为我是个占有欲强的婊子，而且[povname]和我对关系的理解并不是最健康的..."
        fia wry "但我确实关心你。我本可以帮你处理这件事，陪在你身边。"
        fia pity sigh "这对你来说一定也很艰难，对吧？我敢打赌，你每天晚上都因为内疚而哭着入睡。"
        show quil sad sigh
        "奎尔盯着菲亚看了一会儿，然后他的眼睛变红了，湿润了。"
        quil fluster frusta "哦亲爱的，我甚至找不到词来解释我有多么压力山大。"
        show red kaget shock
        show tom ha shock
        play sound "sound/effects/cloth.mp3"
        scene kmr_apt with dissolve
        show quil flashy ow sweat at left with dissolve:
            xalign 0.3
            xzoom -1.0
            yoffset 200
        show croissant sad sweat at right with dissolve:
            yoffset 500
            xalign 0.6
        "奎尔跳过房间，紧紧地抱住了菲亚。菲亚出乎意料地回抱了他。"
        quil groan frusta "我因为害怕失去[povname]而失去了多少美容觉啊。我是说，我甚至都不敢看自己！"
        quil sulk sigh "我甚至匆忙化妆导致皮肤开始出现问题！我可是有着瓷器般的皮肤和完美的五步护肤程序的人啊！"
        fia pity -sweat sigh "好了好了。"
        show side_t skul kzl at pic
        tom "...你知道[povname]是为了解决这种情况而付出最多的人，对吧？"
        hide side_t
        show side_r skul smile at pic
        red "嘘。让这家伙先享受这一刻吧。这会是值得的。"
        hide side_r
        fia wry -sigh "啊，你这可怜的家伙。"
        show quil hister blush bunga
        "菲亚抚摸着奎尔的背，揉乱了他的头发。然后，当奎尔终于平静下来，脸上刚开始露出笑容的时候..."
        play sound "sfx/umph.mp3"
        show croissant mock cling
        show quil ow sweat shock
        "...菲亚狠狠地踢了他的裆部。{i}非常用力。{/i}"
        quil groan frusta "啊！"
        fia annoyed bloom "好像我在乎似的，奎尔。"
        show side_r skul smile at pic
        red "我说过这会是值得的。"
        hide side_r
        quil err "好吧，我可能活该。但是菲亚，讲点道理！家族珠宝？！"
        show quil kzl sigh
        fia hmph sigh "哦闭嘴吧！以你的喜好，我让人怀孕的机会都比你大！"
    scene kmr_apt with dissolve
    show buff sad at center with dissolve:
        yoffset 770
    buff confused apa "呃，不是要打断你们...但你们不觉得我们应该等[povname]醒来后再继续这个讨论吗？"
    show buff sad -apa
    show tom hip frown at right with moveinright:
        yoffset 190
    tom scold kzl blow "终于有人说点有道理的话了。"
    tom ha -blow"菲亚，虽然你完全有权利摧毁我们这个可怕的朋友奎尔，但我同意现在是时候唤醒可怜的[povname]了。"
    show croissant flinch err at left with moveinleft:
        yoffset 500
        xzoom -1.0
    fia mmh sweat "对。我希望这能奏效。"
    play sound "sound/effects/walk.mp3"
    scene kmr_apt with dissolve
    "菲亚站起来，走向你的分身的身体。两颗宝石都在她手中。"
    stop sound
    if girl:
        show bobo_f with dissolve
    else:
        show bobo with dissolve
    "菲亚小心翼翼地靠近她[kk]的身体，稍微整理了一下[dia]的头发..."
    play sound "sound/effects/jelly.mp3"
    show bobo_seth with moveinright:
        xpos 881 ypos 261
    "...然后将最后两颗心形宝石放在[dia]的胸口上。"
    stop music
    play sound "sound/effects/woosh.mp3"
    scene kmr_apt with flashbulb
    if girl:
        show palmierproxy dobel frown mata at center with dissolve:
            yoffset 40
    else:
        show palmierproxy dobel frown mata at center with dissolve:
            yoffset 100
    "房间里充满了白色雾气，[dia]的身体越来越亮，刺得你睁不开眼，直到你与一张熟悉的面孔四目相对。"
    "那是你自己的脸，只是更顽皮，更狡猾，更...危险。"
    $ fia_events.append('even_take_over')
    jump mc_bangkit

label mc_bangkit:
    play music "MUSIC/agnus.mp3" fadein 4.0
    if girl:
        galleryunlock f_awaken
        scene f_awaken with flashbulb:
            truecenter zoom 1.0
            easein 1.5 truecenter zoom 0.5
    else:
        galleryunlock m_awaken
        scene m_awaken with flashbulb:
            truecenter zoom 1.0
            easein 1.5 truecenter zoom 0.5
    $ my_events.append("mc_bangkit")
    play sound "sound/effects/cloth.mp3"
    mk "所以...你终于打败了我们所有的同类。"
    show side_p m at pic
    mc "我们？"
    show side_p s 
    if not girl2:
        mc "（别告诉我...伊瓦尔或塞斯真的成功附身在[dia2]上了？！）"
    else:
        mc "（别告诉我...伊瓦尔或塞斯真的成功附身在[dia]上了？！）"
    hide side_p
    show side_q skul sad at pic
    quil "[povname]...？"
    hide side_q
    show side_r skul kzl at pic
    red "哦，见鬼！"
    hide side_r
    show side_t skul sad at pic
    tom "不！等等，红发，那可能还是我们的[povname]！"
    hide side_t
    scene kmr_apt with dissolve
    show croissant flinch sad sweat at right with dissolve:
        yoffset 500
    if girl:
        show palmierproxy dobel judes mata at left with dissolve:
            yoffset 40
    else:
        show palmierproxy dobel judes mata at left with dissolve:
            yoffset 100
    fia cringe "咕哝！[povname]...拜托，你是在开玩笑，对吧？一定是的！"
    fia mmh "你不是巫师，你是我的[kk]！"
    if "diari1" in completed_quests:
        $ fia_events.append("mc_win")
        mc wry "...一个杀死了神的[kk]。一个注定毁灭我们所知世界的人。"
        mc flirt cling "也许我应该彻底毁掉这个世界，然后重新创造一个。"
        fia sad shock "不，[kk]，请不要！"
        show side_q skul sad at pic
        quil "等等，里面真的不是[povname]吗？我们...我们该怎么办？"
        hide side_q
        "看到[povname]那个样子...你内心的某些东西崩溃了，你的理智，你的耐心，你所有的努力都付诸东流..."
        if girl2:
            "这不可能是真的。不...你根本无法接受。你要把菲亚的[kk]带回来，即使你必须先从[dia]那里打出来。"
        else:
            "这不可能是真的。不...你根本无法接受。你要把菲亚的[kk]带回来，即使你必须先从[dia2]那里打出来。"
        stop music
        play sound "sound/effects/slap.mp3"
        show croissant mmh shock with vpunch
        show palmierproxy frown shock
        show side_p m at pic
        mc "哦，见鬼！" 
        hide side_p
        image palmierproxy2 = LayeredImageProxy("[palmiergender]palmier")
        $ mk = Character('[povname]', callback=name_callback, cb_name='mc', image='palmierproxy')
        $ mc = Character('[povname]', callback=name_callback, cb_name='mc', image='palmierproxy2')
        if girl:
            show palmierproxy dobel frown mata shock at left:
                yoffset 40
        else:
            show palmierproxy dobel frown mata shock at left:
                yoffset 100
        if girl:
            show palmierproxy2 chill pissed at center with dissolve:
                yoffset 40
        else:
            show palmierproxy2 chill pissed at center with dissolve:
                yoffset 100
        mc frusta "你知道，我读过你的日记。我知道尽管你看起来扭曲和精神变态，但你确实在乎！"
        mc side sweat sigh "你在乎菲亚，在乎阿什姆，在乎奎尔和塞恩。我知道你后悔当初对科尔所做的选择。"
        mc pissed frusta "我知道你可能只是渴望和我们打一架，好让我们结束你的生命，这是你为你对科尔所做的事赎罪的方式。"
        mc kzl sigh "好吧，我不会让你这么做的，你这个愚蠢的混蛋！因为我以前也有过这种感觉，我曾经去俱乐部喝得烂醉，希望自己能以最糟糕的方式被车撞死！"
        mc ew -sigh "因为我恨自己！恨我对我妹妹，我的菲亚所做的事！"
        mc ow "也许你因为对科尔所做的事而恨自己，但你不能用这种方式惩罚自己！不能在我经历了这么多狗屁事之后！"
        mc pissed frusta "我他妈杀了四个人来复活你！为了让你和你的菲亚重聚！"
        mc confused -sweat sigh "所以别再装模作样了。接受这第二次生命的机会，忏悔吧，在你妹妹哭之前赶紧去拥抱她，该死的！"
        mk deject -shock "..."
        show croissant wry -sweat shock
        show palmierproxy2 wry shock 
        mk apa sigh "我真的这么混蛋吗？我不可能比这个疯子更糟糕吧，是吗？"
        play music "MUSIC/MusMus-BGM-077.mp3"
        show palmierproxy smile blush sigh
        show palmierproxy2 flirt -shock
        fia pain -shock "哦，你绝对更糟糕，[povname]！糟糕多了！"
        hide palmierproxy2 with dissolve
        fia hister bunga "咕哝！"
        play sound "sound/effects/cloth.mp3"
        show palmierproxy wry mblush -sigh behind croissant with move:
            xalign 0.35
        show croissant laugh blush bloom with move:
            xalign 0.5
        "[povname]降落时，菲亚跑进了她[kk]的怀抱。喜悦的泪水顺着菲亚的脸颊流下，[povname]紧紧抱着她，用温柔的眼神抚摸着[dia]妹妹的刘海。"
        mk flirt bunga "嘿，小麻烦精。"
        fia pain "爱发牢骚的扫兴鬼！"
        mk mock "唠叨的女妖！"
        $ mc = Character('[povname]', callback=name_callback, cb_name='mc', image='palmierproxy')
        $ mk = Character('[povname]', callback=name_callback, cb_name='mc', image='palmierproxy2')
    elif "seth_khianat" in fia_events or "seth_take_over" in fia_events:
        mk mock cling "不再是了..."
        show croissant jijik sweat frusta
        $ fia_events.append("seth_win")
        show side_q skul sad at pic
        quil "不——"
        hide side_q
        mk frown -cling "..."
        show croissant sad shock
        stop music
        mk happy cling "开玩笑的！"
        show palmierproxy smile blush -cling
        fia sad shock "什么——"
        play music "MUSIC/MusMus-BGM-077.mp3" fadein 1.0
        mk flirt bunga "嘿，小麻烦精。"
        fia hister blush bunga "咕哝！"
        show palmierproxy wry mblush -sigh behind croissant with move:
            xalign 0.35
        show croissant laugh blush bloom with move:
            xalign 0.5
        "[povname]降落时，菲亚跑进了她[kk]的怀抱。喜悦的泪水顺着菲亚的脸颊流下，[povname]紧紧抱着她，用温柔的眼神抚摸着[dia]妹妹的刘海。"
    else:
        mk flirt cling "是的，你美丽的[kk]。我一直都喜欢金发。"
        show croissant cringe shock
        mk kind -cling "看来我不用改名字了。"
        $ fia_events.append("ivar_win")
        show side_b skul kzl at pic
        buff "那是伊瓦尔！我们必须现在就杀了他们！！！"
        hide side_b
        fia sad frusta "不！！！"
        mk frown -cling "..."
        stop music
        show croissant sad shock
        mk happy cling "开玩笑的！"
        show palmierproxy smile blush -cling
        fia sad shock "什么——"
        play music "MUSIC/MusMus-BGM-077.mp3" fadein 1.0
        mk flirt bunga "嘿，小麻烦精。"
        fia hister blush bunga "咕哝！"
        show palmierproxy wry mblush -sigh behind croissant with move:
            xalign 0.35
        show croissant laugh blush bloom with move:
            xalign 0.5
        "[povname]降落时，菲亚跑进了她[kk]的怀抱。喜悦的泪水顺着菲亚的脸颊流下，[povname]紧紧抱着她，用温柔的眼神抚摸着[dia]妹妹的刘海。"
    hide croissant with dissolve
    show palmierproxy kind shock at center with move
    show red hister blush at left with moveinleft:
        yoffset 330
    show quil flashy hister blush at right with moveinright:
        yoffset 200
        xalign 0.8
    if girl2:
        red grin bunga "是[dia]！是[povname]！"
    else:
        red grin bunga "是[dia2]！是[povname]！"
    show red laugh
    quil mock bunga "[povname]！是你！真的是你！"
    show quil laugh
    "塞恩和奎尔紧随其后，跑过来拥抱[povname]。"
    show quil sad sweat shock
    show palmierproxy ew mata frusta 
    "有那么一瞬间，[povname]躲开了奎尔的触碰，可能是想起自己实际上是被这个人杀死的。"
    show palmierproxy wry sigh
    show quil hister blush bloom
    "然而，当奎尔开始哭泣时，[kamu]让这个苍白的男人进入了[dia]的怀抱，拍着他的背，让他在[dia]的胸口抽泣。"
    mk mock -sigh "我们说清楚，我还在为你杀了我而生气，知道吗？"
    show palmierproxy mean 
    quil mock "我知道，我知道！但我不在乎，你活着，你活着！"
    show quil hister
    mk smile sigh "好了，哭出来吧，你这个大哭包！"    
    "看到这感人的一幕，你的眼睛湿润了，但你注意到还有一个人缺席。"
    scene kmr_apt with dissolve
    show tom hip sad at right with dissolve:
        yoffset 190
    if girl:
        show palmierproxy dobel sad at left with dissolve:
            yoffset 40
    else:
        show palmierproxy dobel sad at left with dissolve:
            yoffset 100
    tom ha sweat blow "...[povname]。"
    mc ew mata "阿什姆..."
    mc ow sweat frusta "我——对不起甚至不足以弥补我欠你的，我——"
    
    show tom chill calm blow with move:
        xalign 0.25
    show palmierproxy frown -sweat shock
    play sound "sound/effects/bump.mp3"
    "阿什姆冲上前去，在[povname]还没来得及说完话之前就拥抱了[kamu]。"
    tom lega blush -blow "...我很高兴你醒了。"
    mc malu mblush sigh "我也是。我——谢谢你。"
    tom pfft bunga "不过你肯定要补偿我。我不会轻易原谅你的这种轻视。"
    mc happy blush bloom "我可不会打赌，\'我的主人\'！"
    play sound "sound/effects/cloth.mp3"
    if girl:
        scene hugf_end with dissolve
        galleryunlock hugf_end
    else:
        scene hugm_end with dissolve
        galleryunlock hugm_end
    "随着一个大型集体拥抱...你得到了它。你的幸福结局。或者至少是你的一个版本的幸福结局。"
    "你几乎感觉自己像是在打扰这幸福的景象。就好像你已经完成了任务，现在必须回到你自己无聊的生活中。"
    "但这也不会太糟糕。"
    scene kmr_apt with dissolve
    if "companion" in my_events:
        "至少你有了一个会陪你来的新男朋友。"
    else:
        "至少你创造了一些难忘的回忆。"
    show quil flashy laugh blush bloom at center with dissolve:
        yoffset 200
    quil talk -blush shock "亲爱的，为什么一脸愁容？你知道我们非常欢迎你加入这个小小的爱情盛宴。"
    quil hister blush bloom "过来。"
    play sound "sound/effects/cloth.mp3"
    "奎尔把你拉进了团队。拥抱自己的感觉很奇怪。"
    if girl:
        show palmierproxy dobel flirt mata at left with dissolve:
            yoffset 40
    else:
        show palmierproxy dobel flirt mata at left with dissolve:
            yoffset 100
    show croissant kerja blush bunga at right with dissolve:
        yoffset 500
    "然而你就在这里，凝视着一抹熟悉的灰色。"
    mc smile blush sigh "谢谢你，我。我从未想到会有一个陌生人来帮助我。"
    show side_p se at pic
    mc "不过，我们真的是陌生人吗？我是说，你是我，我是你。诚然，我不像你那样是个渴望权力的疯子，但是..."
    hide side_p
    show quil amused sigh
    mc mock mata cling "哼，我也不像你那样是个容易上当的乖乖女，但我们现在就在这里。"
    show croissant wry sigh
    mc smile -mata -cling "真心感谢你。我相信你的妹妹会为你感到骄傲的。"
    if "fia_marah" in fia_events:
        fia gross -blush frusta "我是说，我不这么认为。"
        show croissant annoyed sigh
        mc panik sigh "菲亚，别这样。我们可以待会再说[dia]的坏话。"
        show croissant ejek -sigh
        show palmierproxy flirt -sigh
        show side_p m at pic
        mc "你知道我能听到你们说话，对吧？"
        hide side_p
        mc mock cling "是的。"
        show palmierproxy flirt -cling
        show side_p he at pic
        mc "（我现在后悔复活这个人了。）"
        show side_p a
        mc "（但是，我还是完成了我的目标。现在该怎么办？）"
        hide side_p
    else:
        fia happy blush bunga"我知道我会的。"
        show croissant kerja
        "你对此露出了微笑。你已经完成了在这个世界的使命。"
        "但这确实引出了一个问题，接下来该怎么办？"
    show quil wry -sigh
    show croissant smile sigh
    show palmierproxy kind mata sigh
    show pboy at horzappear
    menu:
        "回家？":
            hide pboy
            show side_p se at pic
            mc "嗯，看来我在这里的工作已经完成了。[povname]醒了，菲亚也和她的[kk]重聚了。"
            show side_p w
            mc "我想是时候让你送我回家了，奎尔。"
            hide side_p
            quil skul mock apa "现在？亲爱的，你肯定可以等到周末的！"
            quil talk -apa "毕竟，我们建立的羁绊值得一个正式的告别。"
            quil flashy wink spark "为什么，我可不会接受任何低于盛大宴会的告别！"
            if "companion" in my_events:
                if "companion" in tom_events:
                    hide croissant with dissolve
                    show tom hip kzl sweat shock at right with dissolve:
                        yoffset 190
                    quil panik sweat cling "况且，像阿什姆这样的妈宝男肯定需要好好道别。"
                    show quil smile -sigh
                    tom capek frusta "嘘！"
                    tom wry -sweat blow "但是没错，我确实想好好地向我的母亲道别。这是理所应当的。"
                elif "companion" in quil_events:
                    quil heh apa "再说，我还没开始打包呢。亲爱的，你知道我需要带多少金子吗？"
                    quil laugh "五十吨够吗？"
                    show quil amused -apa
                    show side_p he at pic
                    mc "等等，你有五十吨金子？"
                    hide side_p
                    quil err sweat frusta "当然。你把我当成什么了？穷光蛋吗？"
                    show quil datar -sweat -frusta
                elif "companion" in red_events or "bonding_me" in red_events:
                    hide croissant with dissolve
                    show quil datar -spark
                    show red chin amused at right with dissolve:
                        yoffset 330
                        xzoom -1.0
                    red cowo cling "我是说我可以用点时间。"
                    red wry sigh "不仅是为了道别，还要为我的猫准备一些东西。"
                    red sayang -sigh "希望维尔科娃能照顾它。"
                else:
                    hide croissant with dissolve
                    show quil datar -spark
                    show buff wry at right with dissolve:
                        yoffset 770
                    buff amused sigh "嗯...我也想要一些时间。"
                    show quil err sweat
                    buff sad sweat frusta "主要是为了休息，也许还要去看看莱纳尔。虽然现在那里对我来说已经没有多少意义了，但是..."
                    show quil rajuk -sweat
                    buff scold sigh "我还是想知道到底有多少是谎言。"
                    show buff frown -sigh
            else:
                show side_p se at pic
                mc "嗯，经历了这么多麻烦，我确实可以来场盛大的派对。"
                hide side_p
                mk rajuk mata frusta "你经历了这么多糟心事，值得休息一年。"
                mk kind sigh "但我想一场派对也只能勉强凑合了。"
            mk apa mata tanya "顺便说一句，奎尔，你打算带我去找吃的还是怎么着？"
            
        "庆祝？":
            hide pboy
            show side_p w at pic
            mc "那么，呃...我们要庆祝一下吗？"
            hide side_p
            show croissant hister sweat 
            show palmierproxy malu both
            quil panik both frusta "我是说，一整座岛的无辜村民被撕成碎片，而且从你的故事来看，莱尔在莱纳尔结交的所有朋友都是谎言..."
            quil heh -both cling "但你知道，幸灾乐祸嘛，人总能从他人的痛苦中找到快乐。"
            show quil laugh sigh
            show palmierproxy flirt mata -sigh
            hide croissant with dissolve
            show tom scold capek sweat frusta at right with dissolve:
                yoffset 190
            tom sigh blow "我想奎尔的意思是\'不\'，因为你、菲亚和莱尔显然需要好好休息一下。"
            tom pfft -blow "不过也许可以改期。也许可以和我们的..."
            tom whine frusta "好吧，我不想这么说，但我想我们可以把它和为你举办的告别派对一起办，[povname]。"
            show tom sad
            show quil sulk sigh
            show palmierproxy deject mata -sigh
            show side_p m at pic
            mc "哦，哦对。"
            hide side_p
            if "companion" in my_events:
                if "companion" in tom_events:
                    tom pfft -sweat blow "我是说，当然你不会和我分开，亲爱的，但是和其他人嘛，好吧..."
                    tom talk amused cling "我认为我们在一起的时光需要一个适当的告别。"
                elif "companion" in quil_events:
                    quil laugh blush bunga "哦，别看起来这么沮丧，亲爱的。我们还会在一起的。"
                    quil malu sigh "不过，我想要一些时间来正式向其他人告别。"
                    quil flashy wink cling "对于这种场合，一个盛大的晚会是最起码的。"
                elif "companion" in red_events or "bonding_me" in red_events:
                    hide palmierproxy with dissolve
                    show red chin amused at left with dissolve:
                        yoffset 330
                    red wry blush sigh "嘿，没关系。我会和你在一起的。我是说，因为我们已经建立了联系，所以我必须这样做，但是..."
                    red cowo -sigh "不管有没有联系，我都迫不及待想和你一起探索你的世界。"
                    hide red with dissolve
                    if girl:
                        show palmierproxy dobel rajuk mata at left with dissolve:
                            yoffset 40
                    else:
                        show palmierproxy dobel rajuk mata at left with dissolve:
                            yoffset 100
                else:
                    hide palmierproxy with dissolve
                    show buff wry sigh at left with dissolve:
                        yoffset 770
                    buff touched apa "啊...所以你一直在谈论的家真的是另一个世界，[povname]？"
                    show side_p he at pic
                    mc "是的，莱尔，这样可以吗？"
                    hide side_p
                    buff hister both sigh "可以？[nickname]，我刚刚失去了唯一让我有些许依恋的地方。"
                    if "pike_betray" in buff_events:
                        buff scold sweat frusta "更不用说派克试图把我卖给变化女巫了。"
                    buff hister blush bunga "在你的世界开始新的生活，一个没有魔法、女巫，或者脑海中不断出现死亡念头的世界，听起来绝对很美好。"
                    hide buff with dissolve
                    if girl:
                        show palmierproxy dobel rajuk mata at left with dissolve:
                            yoffset 40
                    else:
                        show palmierproxy dobel rajuk mata at left with dissolve:
                            yoffset 100
                    
            else:
                quil heh blush apa "我是说，你也可以留下来。"
                show side_p se at pic
                mc "啊，不要误会，虽然我很喜欢你们所有人，但我仍然认为这个世界不适合我。"
                show side_p w
                mc "况且，奎尔，你不是说世界不需要两个[povname]吗？"
                hide side_p
                quil malu sigh "我想是的，不过...我会想念你的，亲爱的。"
            mc confused sigh "这不是很甜蜜吗？如果我现在胃里有东西的话，我肯定会把你们这感人的场面全吐出来。"
    hide quil with dissolve
    show croissant def frown at center with dissolve:
        yoffset 500            
    fia happy shock "哦，我会给你拿点东西的[kk]，你就在这里等着。"
    hide croissant with dissolve
    show palmierproxy kzl at center with move
    mc ew sweat frusta "我可以自己吃，菲亚。哦，该死——！"
    play sound "sound/effects/bump.mp3"
    scene kmr_apt with vpunch
    if not girl2:
        "[povname]的腿开始颤抖，因为[dia]的肌肉已经萎缩了大约一个月。阿什姆在最后一秒抓住了[dia2]，并把[dia]的胳膊搭在他的肩膀上。"
    else:
        "[povname]的腿开始颤抖，因为[dia]的肌肉已经萎缩了大约一个月。阿什姆在最后一秒抓住了[dia]，并把[dia]的胳膊搭在他的肩膀上。"
    if girl:
        show palmierproxy dobel kzl mata frusta at center with dissolve:
            yoffset 40
    else:
        show palmierproxy dobel kzl mata frusta at center with dissolve:
            yoffset 100
    show tom scold ha sweat at right with dissolve:
        yoffset 190
    tom capek blow "你已经躺在床上将近一个月了。"
    tom sad -blow "你的身体需要适应。慢慢来，[povname]。"
    show side_p w at pic
    mc "是的，别担心。我可以留下来假装是你，直到你恢复力气。"
    hide side_p
    show tom chill pfft -sweat
    mc deject sigh "哈...你总是这么善良吗？别这样，这让我觉得我也必须对你好。"
    show tom giggle
    show side_p a at pic
    mc "我是说，这会是一个不错的改变。况且，我这整个月都是这样表现的。"
    show side_p se
    mc "我在这里的表现方式和我在学校里的表现方式完全一样。"
    hide side_p
    mc pissed frusta "该死，现在每个人都认为我是个圣人了，是吗？"
    show croissant def wry at left with dissolve:
        yoffset 500
        xzoom -1.0
    fia hister sigh "轻描淡写地说是这样。" 
    show side_q skul smile at pic
    quil "确实是个软弱的人。"
    hide side_q
    show side_r skul smile at pic
    red "一个真诚善良的闪亮骑士。"
    hide side_r
    mk deject sweat frusta "科尔...我完蛋了。"
    show palmierproxy wry mata sigh
    fia pain sigh "我相信你一踏上校园就会彻底摧毁你新获得的慷慨声誉，爱抱怨的家伙。"
    fia sad sweat apa "不过，与此同时，你不是应该休息吗，莱尔？另一个[povname]？"
    show tom sad sweat shock
    show side_b skul sad at pic
    buff "啊，对。我...我刚才想去看看莱纳尔，但我猜这不是个好主意，是吗？"
    hide side_b
    tom ha blow "再等一天吧。老师们已经联系了教会，居民们似乎正在得到他们需要的帮助。"
    show tom -blow
    fia flinch cringe sigh "是的，我记得塞斯死后村民们醒来的情景。我是说，他们虽然昏昏沉沉、困惑不解，但这是个开始。"
    fia err sigh "不过，我不确定你的朋友派克怎么样了。"
    show side_b skul sad at pic
    buff "..."
    hide side_b
    tom -sweat wry "我相信他没事的，莱尔。现在休息吧，你们两个。明天你们俩可以开始做你们需要做的事。"
    hide palmierproxy with dissolve
    show quil flashy datar at center with dissolve:
        yoffset 190
    show croissant def wry -sweat shock
    show tom hip pfft shock
    quil wink cling "然后在周末，我们都要参加一个盛大的派对！"
    show tom giggle
    quil panik sweat -cling "嗯，虽然在这么短的时间内我能准备的不会太盛大和奢华，但你知道的。"
    quil ejek -sweat cling "现在去休息吧，否则我就用活死人药水把你们两个都浇透！"
    show quil amused -cling
    show side_p se at pic
    mc "好的，好的，晚安各位。"
    hide side_p
    play sound "sound/effects/walk.mp3"
    #scene bg_black with w33
    scene lor_mlm with w33
    "当你和莱尔走回宿舍时，你的思绪不禁开始游走。"
    stop sound
    if girl:
        show palmierproxy scratch sad at center with dissolve:
            yoffset 40
    else:
        show palmierproxy scratch at center with dissolve:
            yoffset 100
    mc sweat "（我想我不再需要符文来保护自己免受巫师入侵梦境了，是吗？）"
    mc chill side sigh "（不会再有科尔、艾欧或伊瓦尔的梦了...）"
    if "iv_curhat" in fia_events and "iv_kissed" not in fia_events:
        mc ow frusta "（...为什么我对此感到如此悲伤？）"
        show buff sad at right with dissolve:
            yoffset 770
        buff keluh sweat apa "你还好吗，[nickname]？"
        show buff sad sigh
        mc confused tanya "啊？"
        show bg_black with fade
        if girl:
            galleryunlock crying_f
            show crying_f with dissolve
        else:
            galleryunlock crying
            show crying with dissolve
        buff "你在哭。"
        hide bg_black 
        if girl:
            hide crying_f with dissolve
        else:
            hide crying with dissolve
        mc side frusta "哦，我...我想我只是会想念我的一个朋友。"
        show palmierproxy sad at left with move
        buff confused -sigh "哦。"
        buff sad apa "抱歉，是我认识的人吗？"
        mc wry -sweat sigh "是的，是我希望你能更亲近的人。不过别在意了。"
        show buff wry -apa
        mc happy -sigh "我们睡觉吧。一个美好、安静、无梦的睡眠。"
        show palmierproxy smile
    else:
        mc wry -sweat -sigh "（没有巫师，没有危险。）"
        mc smile bunga "（...只是一个美好、安静、无梦的睡眠。）"
    stop music
    scene bg_black with eye_shut
    jump morning

###PERPISAHAN DAY
label perpisahan: #SAT w4
    scene bed_pagi with w20
    show red bebas datar at center with dissolve:
        yoffset 330
    red cowo blush bloom "早上好！" with vpunch
    play sound "sound/effects/poppers.mp3"
    show side_p g at pic
    mc "哎呀！"
    hide side_p
    show red grin
    "你被塞恩欢快的喊声和在耳边响起的爆竹声惊醒。声音太大了。"
    play sound "sound/effects/cloth.mp3"
    play music "MUSIC/MusMus-BGM-103.mp3"
    "五彩纸屑全力喷到你脸上。你吐出嘴里闪闪发光的碎屑。"
    show tom go giggle bunga at right with moveinright:
        yoffset 190
    show quil libur laugh blush bunga at left with moveinleft:
        yoffset 200
    show side_p h at pic
    mc "呸！呸！怎么回事？！"
    hide side_p
    show tom pfft
    quil talk cling "这是你的欢送会，傻瓜！你不会以为我们会克制吧？"
    quil amused -cling "得了，[povname]，你现在肯定应该更了解我们了！"
    tom amused "我们在奎尔的公寓里为你准备了一整场派对。"
    tom pfft blow "我们本想把庆祝活动搬到别处，但我们的[povname]现在还太虚弱，不能去任何地方。"
    red laugh "没错，但这并不意味着我们没有尽全力。我们准备了蛋糕、饮料、当然还有酒精和非酒精饮料、冰淇淋、血液——"
    show red happy
    show side_p mal at pic
    mc "就为了那一个参加的吸血鬼？"
    hide side_p
    red mock cling "没错！"
    show red cowo -cling
    quil laugh spark "除此之外，你今天还会得到皇家待遇！"
    show side_p h at pic
    mc "皇家待遇？"
    hide side_p
    quil malu apa "哦，莱尔~"
    scene bed_pagi with dissolve
    show buff bebas datar blush at center with dissolve:
        yoffset 770
    buff talk both sigh "嗨，呃...抱歉，[povname]。"
    play sound "sound/effects/cloth.mp3"
    show buff laugh blush bunga with vpunch
    show side_p k at pic
    mc "哇哦！"
    hide side_p
    show buff huh 
    "莱尔把你抱了起来，像公主一样抱在怀里。"
    show side_p g at pic
    mc "怎么回事？！放我下来！"
    hide side_p
    buff hister "但是...你今天是我们的公主。"
    play sound "sound/effects/walk.mp3"
    scene stairs with w33
    "无论你如何挣扎和抱怨，莱尔和其他男孩们都把你抱向码头，完全无视周围学生的目光。"
    "他们用雨伞遮挡你，这并没有让情况变得不那么可疑——"
    play sound "sound/effects/poppers.mp3"
    extend "用无限供应的爆竹震耳欲聋地吵闹，用夸张的扇子给你降温。"
    show side_p k at pic 
    mc "公主也可以自己走路的！你们打算这样抱着我穿过整个校园吗？！放我下来！！！"
    hide side_p
    show red bebas laugh blush at left with dissolve:
        yoffset 330
        xpos -200
    show tom go giggle blush at right with dissolve:
        yoffset 190
    show quil libur laugh blush at center with dissolve:
        yoffset 200
    red grin bunga "向我们的救世主[povname]致敬！"
    show red hister 
    tom amused bloom "勇敢美丽的[povname]！"
    quil talk spark "无畏又绝妙的[povname]！"
    show quil hister
    show side_p mal at pic
    mc "你们这些家伙..."
    hide side_p
    "被抱着穿过整个校园，还被人欢呼，这很尴尬吗？是的。"
    "你会希望换种方式吗？不会。"
    "当男孩们不让你逃脱这种奇怪又尴尬的皇家仪式时，你既享受又因尴尬而畏缩。"
    "当你们穿过校园时，旁观者开始盯着你看，并指指点点。"
    $ NPC = "???"
    npc "怎么回事？游行吗？"
    $ NPC = "女孩"
    npc "我觉得他们在组建邪教，崇拜[povname]。我就知道那四个人有点疯狂。"
    $ NPC = "???"
    show side_p h at pic
    mc "呃，也许你们应该放我下来。你们知道所有人都在盯着看，对吧？！"
    hide side_p
    red amused apa "那又怎样？"
    show red grin
    quil mock cling "让他们看吧，亲爱的。把它当作你用你的绝世美貌在赐福他们。"
    show quil laugh bunga
    tom ejek cling "[povname]，谁在乎他们怎么想？你打败了所有的巫师，你应该被崇拜。至少一天。"
    show tom calm -blow
    red hister cling "是啊，你以前有很多追求者，现在就放松享受这一刻吧，兄弟。"
    show quil hister spark with move:
        xalign 0.25
    show buff bebas datar behind red at center with dissolve:
        yoffset 770
        xalign 0.6

    show side_p g at pic
    mc "莱尔？"
    hide side_p
    buff laugh blush bloom "我是说，他们说得没错，[povname]。所以请别再扭来扭去了。放松，靠在我怀里吧。"
    show side_p mal at pic
    mc "天哪..."
    show side_p g
    mc "（天啊，这太尴尬了！但是...）"
    show side_p ha
    mc "（...我真的会想念这些傻瓜的。）"
    hide side_p
    scene qpt with dissolve
    if girl:
        show palmierproxy jln happy blush at center with dissolve:
            yoffset 40
    else:
        show palmierproxy jln happy blush at center with dissolve:
            yoffset 100
    "一进入通往奎尔公寓的传送门，你就被各种饮品选择和一座高耸的海鲜塔迎接。"
    mc hister bloom "我的天，你们为我准备了这些？！甚至还有象拔蚌，我一直想尝试象拔蚌！哇，那是芒果拉西吗？我妈妈以前经常做这个。"
    mc happy tanya "你们怎么知道的？"
    show palmierproxy kind at left with move
    $ mk = Character('[povname](?)', callback=name_callback, cb_name='mc', image='palmierproxy2')
    if girl:
        show palmierproxy2 dobel flirt msmoke at right with dissolve:
            yoffset 40
    else:
        show palmierproxy2 dobel flirt msmoke at right with dissolve:
            yoffset 100
    mk judes sigh "我当然知道。毕竟你就是我。"
    mc happy shock "哦，你终于动起来了，[povname]。"
    show palmierproxy confused -shock
    mk deject -sigh "嗯。"
    mc ha tanya "抱歉，你刚才说什么？"
    show palmierproxy frown -tanya
    mk kzl sigh "嗯。"
    show croissant annoyed sweat at center with dissolve:
        yoffset 500
    if not girl2:
        fia mmh frusta "现在你明白为什么我叫[dia2]唠叨鬼了吧。"
    else:
        fia gross frusta "现在你明白为什么我叫[dia]唠叨鬼了吧。"
    show croissant hister blush sigh
    mc smile sigh "啊，有道理。"
    show palmierproxy kind -sigh
    mk pissed frusta "哼。我简直不敢相信居然有一个这么开朗健谈的我。"
    mk confused -frusta "菲亚，我几乎要被你没有更早发现区别而感到冒犯了。"
    show palmierproxy judes 
    fia flinch err frusta "你们两个看起来一模一样！当然，这个看起来更丰满些，但我以为你是在康复中！"
    show croissant def wry -frusta
    mk deject "哼。"
    show pboy s at horzappear
    menu:
        "回以咕哝":
            hide pboy
            show croissant hmph blush sigh
            show palmierproxy mean cling
            "你交叉双臂，挺起胸膛，然后大声咕哝着..."
            mc mock -cling "嗯。"
            mk rajuk frusta "哼。"
            mc smile "嗯。"
            show croissant hister -sigh
            mk kzl sigh "哼。"
            hide croissant with dissolve
            show quil libur amused at center with dissolve:
                yoffset 200
            quil malu sigh "好了，你们两个够了，别再发出这些呻吟和原始人般的咕哝声了。"
            quil laugh blush bloom "来吧，我可是花了大价钱准备这些东西！"
            quil amused "吃喝的时候再呻吟吧，而不是为了...不管这是什么。"
        "没有副作用吗？":
            hide pboy
            mc kind sigh "我猜咕哝是件好事，对吧。我还担心伊瓦尔或塞斯对你下手了呢。"
            if "mc_win" in fia_events:
                mk mean cling "看来运气站在我们两个这边。"
            else:
                mk kzl sigh "你会更喜欢那样吗？你知道，我还能看到他们的记忆。"
                mc frown tanya "哦？"
                show palmierproxy side sweat shock
                mk flirt cling "是的，你和伊瓦尔关系很亲密，不是吗？"
                mc confused sigh "也许吧，但是，嗯...现在这已经无关紧要了，不是吗？"
                show palmierproxy frown -sigh
                mk judes -cling "我想是的。"
                if "truth" in my_events:
                    mk flirt tanya "顺便问一下，在经历了这一切之后，你还是那种愿意接受真相的类型吗？"
                    
                else:
                    mk frown tanya "顺便问一下，在经历了这一切之后，你还认为无知是福吗？"
                mc ha sweat "哦，你看到我在我们第一个梦里和伊瓦尔的小对话了吗？"
                mc happy -sweat "我是说...是的，我想是的。你为什么这么问？"
                show palmierproxy kind 
                mk flirt -tanya "没什么特别的原因。"
            hide croissant with dissolve
            show quil libur amused at center with dissolve:
                yoffset 200
            quil talk bloom "好了，你们两个，少聊天多吃饭。我花了大价钱准备这些食物，却没听到足够的赞美。"    
            quil hister blush "我需要满足我的虚荣心！"
    show side_r bebas smile at pic
    show quil amused shock
    red "闭嘴吃你的饭，奎尔！"
    hide side_r
    play sound "sound/effects/plate.mp3"
    quil malu both shock "唔唔！" with vpunch
    scene qpt with dissolve
    "塞恩给他喂了一口苹果派。这似乎让他安静了一会儿，开始品尝嘴里的食物。"
    play sound "sound/effects/cough.wav"
    "至少在塞恩强行喂他另一口之前是这样的，之后他开始呛住了。"
    show tom go kzl sweat frusta at center with dissolve:
        yoffset 190
    "幸好阿什姆及时对他施行了海姆立克急救法，否则情况可能会更糟。"
    show quil libur err sweat frusta at left with dissolve:
        yoffset 200
    tom sad "呼吸，奎尔，喝点这个！"
    quil hister blush shock "呼！谢谢，妈妈。"
    tom sigh blow "说真的，你们两个..."
    show tom capek -blow
    if "companion" in my_events:
        if girl:
            show palmierproxy2 dobel judes msmoke at right with dissolve:
                yoffset 40
        else:
            show palmierproxy2 dobel judes msmoke at right with dissolve:
                yoffset 100
        if "companion" in quil_events:
            
            mk rajuk frusta "我还是不敢相信你要带那个小鬼一起走。"
            show side_p ha at pic
            mc "啊哈哈，嫉妒了？"
            hide side_p
            mk flirt sigh "有一点吧，他是我最好的朋友。但据我所听说的，你对他产生了很好的影响。"
            mk wry tanya "你让他摆脱了家族的束缚。我还听说你炸毁了他父亲的宅邸？"
            show side_p mal at pic
            mc "啊，那完全是他自己的责任，跟我无关。"
            hide side_p
            mk flirt sigh "听起来很像他的作风，那小鬼从来就不懂得\'低调\'这个词。"
            mk malu -sigh "不过，至少有他在身边就永远不会感到无聊，我相信他会给你带来无尽的乐趣。"
            show side_p ha at pic
            mc "我知道。"
            hide side_p
            mk happy "替我照顾好他，好吗？我会想念那个小捣蛋鬼的。"
            show palmierproxy2 flirt 
            show side_p ha at pic
            mc "我会的。"
            hide side_p
        elif "companion" in tom_events:
            mk malu sigh "他总是那么可靠，不是吗？我的闪亮盔甲骑士。"
            show side_p ha at pic
            mc "那个错过的人？"
            hide side_p
            mk side frusta "更像是我虐待和利用过的人，却还厚颜无耻地爱着。"
            mk wry -frusta "...我很高兴他找到了你。"
            mk judes sigh "你知道吗，他一直在喋喋不休地谈论你？每次来看我，他总是说[povname]这个[povname]那个。"
            mk confused -sigh "我从未如此厌烦听到自己的名字。"
            show side_p ha at pic
            mc "如果我不了解情况的话，我会说你是在嫉妒。"
            hide side_p
            mk kzl frusta "我确实嫉妒。但我没有资格这样。我曾是一个有毒的、控制欲强的爱人。"
            mk sad sigh "我把他当成一个物品。一个占有物，而不是一个人，我为此道歉。"
            show side_p g at pic
            mc "需要道歉的对象不是我。"
            hide side_p
            mk wry -sigh "别担心，我也对他说过很多次了。但我觉得你也需要听到这些。"
            mk happy "替我好好照顾他，好吗？"
            show side_p ha at pic
            mc "我会的。我们会互相照顾。"
            hide side_p
            mk mean sigh "哼，你们真是令人作呕的甜蜜。"
            show palmierproxy2 kind  -sigh
        elif "companion" in red_events:
            mk judes frusta "我还是不敢相信你和红头发建立了联系。"
            show side_p h at pic
            mc "为什么我不会呢？"
            hide side_p
            mk mock cling "我以为咬人这一点会让你却步，但谁知道呢，也许你在床上比我更变态。"
            show palmierproxy2 judes -cling
            show side_p mal at pic
            mc "他很温柔体贴。"
            hide side_p
            mk deject sigh "你忘了他鲁莽和愚钝的一面。"
            if "diari1" in completed_quests:
                show side_p h at pic
                mc "不是你说过你喜欢男人这样吗？"
                hide side_p
                mk confused tanya "我是不是写过愚蠢是一个特点还是什么的？"
                show side_p ha at pic
                mc "是的。"
                hide side_p
                mk wry sigh "是啊，那天我肯定是嗨了。"
                mk frown -sigh "真不敢相信我的朋友们那时候还能容忍我的胡闹。"
            else:
                mk wry sigh "...我会想念他的。"
            mk happy tanya "替我好好照顾他，好吗？"
            show palmierproxy2 kind -tanya
            show side_p ha at pic
            mc "我会的，我们会互相照顾。"
            hide side_p
        else:
            mk confused tanya "所以...你和那个新来的家伙，是吗？"
            mk kzl -tanya "我不能说我很了解他。不过，你信任伊瓦尔的一个后代？"
            show side_p ha at pic
            mc "我信任他。他和他父亲完全不同。他温柔、体贴。"
            hide side_p
            if "ivar_win" in fia_events:
                mk flirt "我相信他是的。"
                mk deject "不过，尽管体型很大，他看起来还是很天真和胆小。"
                mk kind "好好照顾他，好吗？"
                show side_p ha at pic
                mc "我会的。"
                hide side_p
            else:
                mk judes frusta "哼。"
                show side_p h at pic
                mc "那声咕哝是在说\'是的，我相信你\'还是...？"
                hide side_p
                mk frown sigh "我无法评论任何事，我对那个人一无所知。"
                mk kind -sigh "如果他能让你幸福，那就是最重要的。"
                mk malu "况且，我庆幸你爱上的是他而不是我的朋友们。"
                mk kind "我无法想象如果你带走奎尔、阿什姆或塞恩，我会有什么感觉。"
                mk side sigh "尤其是在我还需要和他们和解的时候。"
                show side_p ha at pic
                mc "说实话，我觉得他们只是高兴你还活着并且安好。你有很好的朋友，[povname]。"
                hide side_p 
                mk kind -sigh "我知道。我可能需要花一辈子的时间来报答他们。"
                show side_p ha at pic
                mc "我相信你会的。"
                hide side_p
    else:
        if girl:
            show palmierproxy2 dobel judes msmoke at right with dissolve:
                yoffset 40
        else:
            show palmierproxy2 dobel judes msmoke at right with dissolve:
                yoffset 100
        mk malu sigh "他们真是些可笑的傻瓜，不是吗？"
        show side_p ha at pic
        mc "是拯救了你这个混蛋的傻瓜。"    
        hide side_p
        mk side frusta "没错，傻瓜。我...我不配得到他们的善意。"
        mk "我简直不敢相信，在我对科尔和蒂莫西做了那些事之后，他们还接纳我..."
        show palmierproxy2 sad
        show side_p h at pic
        mc "我同意你不配得到他们的原谅或忠诚。"
        mc "你能保有菲亚的爱或掌握神的力量也是不公平的。"
        show side_p ha
        mc "但你已经拥有了这些，所以现在你的任务就是不要浪费它们。"
        hide side_p
        show palmierproxy2 flirt sigh
        "你的另一个自己对此点头，[kamu]似乎陷入了沉思，脸上露出微笑。" 
        mk wry -sigh "我不会的。我会补偿科尔、那些男孩们、菲亚和格拉夫人。再次感谢你，[povname]，真的。"
        if "mc_win" not in fia_events:
            mk flirt "你不知道你做了什么，真的。"
    scene qpt with dissolve
    "你度过了余下的一天，尽情享用美食。龙虾、鱿鱼、你曾有幸品尝过的最好的牛排。"
    "一切都很完美，尤其是陪伴。"
    play sound "sound/effects/glass_tap.mp3"
    show quil libur datar at center with dissolve:
        yoffset 200
    quil talk bloom "好了各位，请大家都看着我。我要提一个迟来的祝酒词！"
    "奎尔反复敲击着他的香槟杯，呼唤着大家的注意力。"
    quil panik sweat frusta "大约一个月前，我犯了个大错，让我最好的朋友陷入了昏迷。"
    quil hister sigh "然后我召唤了[dia]的另一个自我，希望[kamu]能帮助我找到治愈的方法。"
    if "companion" in quil_events:
        quil talk blush bloom "我没想到的是，我遇到了我一生的挚爱和伊格尼亚的救星。"
    else:
        quil hister blush bloom "我没想到的是，我遇到了伊格尼亚的救星和我见过的最善良的人。"
    quil mock "[povname]，你是我见过的最美丽的人，无论是内在还是外在。"
    quil hister both sigh "我知道我在这里没有让事情变得容易，但你始终坚持自己的目标。"
    quil talk blush -sigh "帮助菲亚与她的[kk]重聚，帮助她重新编织你和你妹妹未能实现的羁绊。"
    quil datar sigh "不仅如此，你还让我们摆脱了纯血巫师的恐怖统治，为此，我们感谢你。"
    quil laugh bloom "我们永远欠你的情。伊格尼亚的未来，无论是什么样子，都是因为你而成为可能。"
    quil talk cling "敬[povname]！"
    play sound "sound/effects/ding.mp3"
    show quil laugh bunga
    $ NPC = "所有人"
    npc "敬[povname]！"
    $ NPC = "???"
    "其他人喝了一口饮料，而你因为所有的关注而脸红了。"
    scene qpt with dissolve
    if "companion" in quil_events:
        show quil libur datar at left with dissolve:
            yoffset 200
        "奎尔走过来，在你的脸颊上亲了一下。"
        quil talk blush bunga "我爱你，[povname]。永远。"
        show quil wry
        if girl:
            show palmierproxy jln kind at right with dissolve:
                yoffset 40
        else:
            show palmierproxy jln kind at right with dissolve:
                yoffset 100
        mc "我也爱你。"
        quil panik sigh "我迫不及待想要探索你的世界，[povname]！"
        show quil datar -sigh
        mc eiden sweat sigh "呵，别急着谢我。我的世界也不是没有问题。"
        show palmierproxy kind blush -sigh
        quil amused apa "比巫师想要杀你还糟糕吗？"
        mc ha "嗯...倒也不是。"
        show palmierproxy kind -apa
        quil sly cling "那我们就没问题了。再说了，没有钱解决不了的问题。如果钱不是解决方案，我相信我们的爱情就是。"
        quil laugh -cling "无论你的世界等待我们的是什么，我们都会一起面对，对吧？"
        show quil datar
        mc smile bunga "是的，一起。"
        quil laugh bloom "一起。"
    elif "companion" in red_events:
        show red bebas grin at left with dissolve:
            yoffset 330
        if girl:
            show palmierproxy jln malu blush at right with dissolve:
                yoffset 40
        else:
            show palmierproxy jln malu blush at right with dissolve:
                yoffset 100
        "塞恩似乎感受到了你温暖模糊的感觉，他的手指与你的交缠在一起，同时偷偷在你的脸颊上轻啄了一下。"
        red laugh blush bunga"你是个英雄，[povname]。"
        red hister "不仅是伊格尼亚的英雄，对我来说也是。"
        red sayang sigh "我无法想象没有你的生活会是什么样子，[povname]。"
        show red datar -sigh
        mc hister bloom "塞恩..."
        "你感受到一波爱意和欲望通过你们的羁绊冲刷着你。这个男人崇拜你走过的每一寸土地。"
        "如此之深，以至于他愿意放弃自己的世界，与你重新开始。"
        red amused apa "这真的要发生了，对吗？我们要一起开始新的生活。"
        red cowo cling "我迫不及待想要探索你的世界，[povname]！"
        mc ha sweat frusta "呵，别急着谢我。我的世界也不是没有问题。"
        show palmierproxy wry blush shock
        red amused -cling "也许吧。但我们会一起面对，不是吗？"
        mc smile sigh "是的...一起。"
        red laugh bloom "永远在一起。"
        show quil libur datar at center with dissolve:
            yoffset 200
    elif "companion" in tom_events:
        show tom go smile at left with dissolve:
            yoffset 190
            xzoom -1.0
        if girl:
            show palmierproxy jln kind at right with dissolve:
                yoffset 40
        else:
            show palmierproxy jln kind at right with dissolve:
                yoffset 100
        "阿什姆整理了你的头发，轻轻地吻了你的脸颊，他的手牢牢地放在你的腰上，保护着你。"
        tom pfft apa "这么多关注让你感到不适吗，亲爱的？"
        mc malu sigh "我是说，确实有点多。但话说回来，这可是奎尔啊。"
        tom giggle -apa "是的，含蓄确实不是他的强项，对吧？"
        mc sad tanya "不是。还有，呃...你真的没问题离开这个地方，离开你的朋友们吗？"
        tom pfft blow "他们理解，我母亲也给了我祝福。她甚至给了我一张我父亲的照片。"
        tom wry -blow "虽然我不确定仅凭这个和他的名字是否足以找到他。"
        show palmierproxy frown shock
        "阿什姆给你看了一张他父亲的照片，照片里他抱着婴儿时期的阿什姆。"
        "他看起来和阿什姆一模一样，只是年纪大一些，头发中有白色的条纹。"
        mc wry -shock "我们会找到他的。总有办法。"
        tom amused "不用着急，我们有时间适应并找到他。"
        tom pfft "更重要的是，我们有时间属于我们自己。我迫不及待想要和你开始新的生活，[povname]。"
        tom lega blow "谢谢你选择了我，亲爱的"
        mc ha sweat "呵，别急着谢我。我的世界也不是没有问题。"
        show palmierproxy wry blush shock
        tom pfft blush apa "也许吧，但我们会一起面对，不是吗？"
        show tom smile -apa
        mc smile sigh "是的...一起。"
        tom calm bloom "一起。"
        show quil libur datar at center with dissolve:
            yoffset 200
    elif "companion" in buff_events:
        show buff bebas blush at left with dissolve:
            yoffset 770
            xzoom -1.0
        if girl:
            show palmierproxy jln kind at right with dissolve:
                yoffset 40
        else:
            show palmierproxy jln kind at right with dissolve:
                yoffset 100
        buff lega apa "紧张吗？"
        show buff datar -apa 
        mc happy sigh "你问这个很有趣，通常你才是那个在某处像树叶一样发抖的人。"
        buff hister "我无法反驳这一点，但现在情况不同了，对吧？"
        buff amused "我自由了。现在可以做任何我想做的事。"
        buff wry sigh "可以和你重新开始。"
        show palmierproxy malu blush shock
        "莱尔在倾身亲吻之前，握住了你的双手。"
        "你沉浸其中，品味着他的唇瓣，同时他发出一声深深的叹息。"
        buff laugh blush bloom "我迫不及待想要和你开始新的生活。"
        show palmierproxy smile -shock
        show quil libur datar at center with dissolve:
            yoffset 200
    else:
        show croissant hmph at left with dissolve:
            yoffset 500
            xzoom -1.0
        if girl:
            show palmierproxy jln kind at right with dissolve:
                yoffset 40
        else:
            show palmierproxy jln kind at right with dissolve:
                yoffset 100
        fia apa "你现在不会害羞了吧？如果你是我的[kk]，[kamu]最喜欢的就是让人们歌颂[dia]的赞美。"
        if not kln:
            mc ha sigh "恐怕我没有[kamu]那么自恋。"
        else:
            mc ha sigh "恐怕我没有[kamu]那么自恋。"
        show palmierproxy wry -sigh
        fia laugh sigh "不，谢天谢地没有。"
        if "fia_marah" in fia_events:
            show palmierproxy frown shock
            fia cringe sweat -sigh "顺便说一句，我很抱歉。"
            fia "为我当初你第一次告诉我关于[povname]的事时的反应。"
            show palmierproxy wry -shock
            fia sad frusta "你不该受到那样的对待。"
            mc hister sigh "没关系的。"
            show palmierproxy wry -sigh
            fia flinch gross "不，这不对。如果不是因为你，我的[kk]现在就不会在这里。"
            fia def sad sigh "嗯，[kamu]会\'在这里\'，但至少不会走来走去抱怨了。"
            fia laugh blush bloom "所以谢谢你。你的菲亚很幸运有你这样的[kk]。"
            
        else:
            fia laugh blush bloom "你知道吗，我会想念你的。你是个好[kk]。也许不是我的，但仍然..."
            mc malu tanya "也许尽管我们在不同的世界，我们还是可以交谈？"
            show palmierproxy sad sigh
            fia malu both sigh "我表示怀疑。现在没有足够的符文墨水了，但是...也许在我们的梦中可以。"
            show croissant wry blush -sigh
            mc kind -sigh "也许吧。"
            mc malu tanya "顺便问一下，你有梦见过菲亚吗？我的菲亚？"
            show palmierproxy wry -tanya
            fia sad sweat "我不知道。我从来没有涉足过解梦这一领域。"
            fia hmph blush "但是，我还是认为你的妹妹很幸运有你这样的[kk]，[povname]。"
            fia laugh bloom "真的。"
        mc happy blush bunga "...谢谢你。"
        show quil libur datar at center with dissolve:
            yoffset 200
    show palmierproxy frown sweat shock
    stop music
    play sound "sound/effects/walk.mp3"
    quil "好了，[povname]，你准备好走了吗？"
    play sound "sound/effects/portal.wav"
    scene qpt with flashbulb
    "你看向面前的窗户，它不再通向学校。现在，你可以看到它通向你的公寓。"
    "你的手机躺在地板上，屏幕仍然亮着，你可以隐约看到时间和日期。"
    "仍然是你的生日，也许距离你母亲给你发短信只过了一个小时。"
    play music "MUSIC/MusMus-BGM-008.mp3"
    show tom go ha at center with dissolve:
        yoffset 190
    show quil libur datar at right with dissolve:
        yoffset 200
    show red bebas frown at left with dissolve:
        yoffset 330
    show side_p k at pic
    mc "这怎么可能？"
    hide side_p
    quil mock sigh "我想我们两个世界的时间运转方式不同。你们世界的几个小时似乎相当于我们世界的几周。至少说这很方便。"
    quil tantrum -sigh "你应该趁现在进去，我担心没有足够的墨水来维持这个传送门太久。"
    if "companion" in quil_events:
        show tom sad sweat
        red ngeles sweat shock "等等，那是不是意味着在这之后我们就再也见不到对方了？"
        show red ow frusta
        quil hister sweat apa "是的。至少从我这边来说是这样，但谁知道呢，也许伊格尼亚会找到符文墨水的替代品。"
        show red sad sigh
        quil sly -sweat cling "也许你能维持魔法的运转。"
        tom calm -sweat blow "也许吧。但在那之前，过来，奎尔，[povname]。"
        show tom pfft -blow
        show red wry -sweat -sigh
    elif "companion" in red_events:
        red ngeles sweat shock "等等，那是不是意味着在这之后我们就再也见不到对方了？"
        quil wink cling "我不会说永远不可能。毕竟你面对的是奎尔·英克威尔，我相信我能找到符文墨水的替代品，也许需要十年或二十年。"
        show tom sad frusta
        show quil wry -cling
        red ew frusta "哦..."
        show red sad sigh
        quil fluster sweat frusta "别难过啊，红头发。你知道这一天终会到来的。"
        red perih both frusta "我知道，但是...这仍然是一个巨大的打击，我...我会想念你们的。"
        show red sad sigh
        tom sad blow "过来。"
    elif "companion" in tom_events:
        tom pfft apa "我想现在问你们是否会来拜访已经太晚了吧？"
        quil sulk sweat frusta "你知道我们没有足够的符文墨水来做这件事。这可能...这可能是我们最后一次见面了。"
        tom nyesal blow "...我知道。"
        show red perih sweat shock
        "塞恩开始啜泣，再也无法掩饰自己的情绪。"
        red sad both frusta "哦伙计，我不行了，我不敢相信这就是告别！"
        quil fluster both frusta "别哭！妈妈...妈妈不会希望我们哭的。"
        show tom wry -blow
        "奎尔也开始放声大哭，甚至[povname]也泪流满面，紧紧抓住菲亚的手臂，仿佛那是生命线。"
        tom giggle -sweat blow "过来，你们这些傻瓜。"
    elif "companion" in buff_events:
        show tom sad with move:
            xalign 0.4
        show buff bebas sad behind tom with dissolve:
            yalign 0.0
            xalign 0.8
        buff keluh sweat frusta "我猜你们都不能来拜访，是吗？"
        tom nyesal blow "墨水供应太少了，莱尔。这...这可能是我们最后一次见面了。"
        buff sad sigh "哦-哦。"
        tom wry -sweat -blow "嘿，没事的，过来。"
    else:
        show side_p g at pic
        mc "那么，我猜这就是再见了，是吗？"
        hide side_p
        quil wry both sigh "哦，别这么伤心，[povname]，我肯定会在你的梦中出现的。"
        tom wry blow "我们一定会找到方法再次相遇的，我保证。"
        red hister blush cling "是啊伙计，在这期间，你为什么不试试在你的世界里找到我们的版本呢？我相信我们会很有趣的！"
        show tom wry with move:
            xalign 0.4
        show buff bebas wry behind tom with dissolve:
            yalign 0.0
            xalign 0.8
        buff touched sigh "是的，请一定要这样做，[povname]。在此期间，我们会在这里...想念你。"
        quil fluster both shock "等等，别这么说，我刚刚才把妆化好！我可不能哭花了我的眼影！"
    play sound "sound/effects/cloth.mp3"
    scene qpt with dissolve
    "你毫不犹豫地把所有人拉进了一个集体拥抱。也许这是你们最后一次能够一起分享的拥抱。"
    "菲亚和[povname]眼含泪水加入了进来。你几乎无法抑制自己的泪水。"
    "你的一部分想要留下。但更大的一部分知道这行不通。你不适合这个世界。这里的暴力，扭曲的道德。"
    "不，你需要回家。"
    show tom go smile at center with dissolve:
        xalign 0.55
        yoffset 190
    show quil libur wry at right with dissolve:
        xzoom -1.0
        yoffset 200
    show red bebas laugh blush at left with dissolve:
        yoffset 330
    show croissant def hister at center with dissolve:
        yoffset 500
        xzoom -1.0
        xalign 0.45
    show buff bebas wry behind tom with dissolve:
        xalign 0.3
        xzoom -1.0
        yalign 0.0
    mc "谢谢大家，我会想念你们的。再见！"
    $ NPC = "所有人"
    npc "再见！"
    "你挥手告别，珍惜每一个过去的瞬间，记住每一张脸，希望有朝一日能再次见到他们。"
    stop music
    play sound "sound/effects/woosh.mp3"
    if "truth" in my_events and "mc_win" not in fia_events:
        scene qpt with flashbulb
        show croissant wry at center with dissolve:
            yoffset 500
        fia hister both sigh "哈，真不敢相信我哭了。"
        fia hmph blush apa "好吧，那我猜我们应该收拾一下，对吧，[povname]？"
        fia flinch cringe sweat shock "[povname]？"
        scene bg_black with wet
        fia "为什么你的眼睛变成——"
    else:
        scene bg_black with w20
    if "companion" in my_events:
        $ NPC = "???"
        npc "[povname]，[povname]！"
        scene apt with w33
        play sound "sound/effects/crash.mp3"
        if girl:
            show palmierproxy jln grit at center with dissolve:
                yoffset 40
        else:
            show palmierproxy jln grit at center with dissolve:
                yoffset 100
        mc shock "哈！" with vpunch
        play music "MUSIC/MusMus-BGM-032.mp3"
        if "companion" in quil_events:
            show palmierproxy sweat sad at left with move
            show quil libur ow sweat frusta at center with dissolve:
                xzoom -1.0
                yoffset 200
            quil "你没事吧？你晕过去了。"
            show quil sulk sigh at right with move
            mc frown shock "我，我没事..."
            mc wry -sweat tanya "我们到了吗，我们回家了吗？"
            show palmierproxy hister blush bloom
            quil talk blush cling "是的，亲爱的，回家了。"
            quil laugh spark"这真是个好家啊，亲爱的。如此之高。你没告诉我你很富有。"
            quil amused apa "你这座高楼里有多少间卧室？上百间？"
            mc ha sweat -bloom "哈哈，恐怕只有这一间。这是一套公寓。"
            quil bingung -blush "公寓？还有，当你昏迷的时候，我刚才听到一种非常可怕的呼啸声。"
            quil groan "不仅如此，我还看到远处有一只被金属包裹的鸟？"
            show quil kzl -apa
            mc happy "哦，那是飞机。"
            quil bingung sweat apa "...飞机？"
            mc hister sweat tanya "你知道的，就像汽车或船，但它是在空中飞行的？"
            quil err sweat shock "什么？！这是什么巫师的魔法？！"
            mc kind sigh "不是魔法，只是...科技，但我猜伊格尼亚过于依赖符文，以至于你无法理解那是什么，对吧？"
            quil fluster -shock "等等，你是说你们这些人自己建造了这一切，而没有使用符文魔法？"
            quil laugh blush bunga "太了不起了！"
            mc malu blush sigh "啊哈哈，我不会说得那么夸张，但无论如何，宝贝，我会在路上解释一切的，现在我们真的应该去见我母亲了。"
            mc wry -sigh "如果我错过了自己的生日派对，我无法想象她会有多担心。"
            show quil frown -blush shock
        elif "companion" in red_events:
            show palmierproxy sad sweat at left with move
            show red bebas sad sweat frusta at center with dissolve:
                xzoom -1.0
                yoffset 330
            red ew apa "你还好吗，[povname]？你刚才晕过去了。"
            show red sad at right with move
            mc ha "我想我会没事的。"
            mc happy -sweat shock "嗯，真不敢相信我回家了。"
            red laugh blush bloom "是啊，我们的家。"
            mc malu blush sigh "我们的家。"
            red happy "我能在这里到处闻到你的气味，很好闻...让人平静。"
            show red amused 
            mc eiden sweat frusta "我知道这是一种赞美，但我觉得你在我母亲面前应该避免这样说话。"
            show palmierproxy kind -sweat -frusta
            red laugh blush bloom "哦对了，你说今天是你的生日，对吧？生日快乐[povname]。"
            mc laugh bunga "谢谢。我有种感觉，今天会是个好日子。"
            mc happy cling "准备好见我妈妈了吗？"
            show palmierproxy kind -cling
            red amused sigh "我已经准备好了。"
            show red frown -blush shock
        elif "companion" in tom_events:
            show palmierproxy sad sweat at left with move
            show tom go sad sweat frusta at center with dissolve:
                yoffset 190
            tom whine apa "回到我身边，亲爱的，你刚才去哪里了？"
            show tom sad -apa at right with move
            mc side sweat frusta "我一定是撞到头了或者怎么的。"
            tom sad blow "你需要休息吗？"
            mc wry -sweat sigh "不，我终于回家了，我需要见我妈妈。"
            tom wry -sweat -blow "好吧，但别勉强自己，亲爱的。"
            tom calm blush bloom "另外，你有一个可爱的家。"
            tom amused cling "而且位置很高，有多少间卧室？"
            show tom smile -cling
            mc laugh both bunga "哈哈，恐怕只有这一间。这是一套公寓。"
            tom ha sweat apa "公寓？"
            mc kind blush sigh "共享住房。"
            tom kzl apa "我明白了，下面那些响亮的喇叭声是什么？"
            mc hister tanya "哦，那些是汽车，我们用它们来四处走动。你们的世界没有吗？"
            show palmierproxy kind -tanya
            tom ha -apa "我们有火车和船，我相信沃特克刚刚制造了一艘飞船，但是没有，没有...汽车或者你们称之为的东西。"
            tom calm -sweat "我们通常使用符文来传送。"
            show tom smile
            mc happy blush bloom "别担心，我很快就会解释一切。在你见过我妈妈之后。"
            show palmierproxy malu 
            tom amused cling "当然。我期待着魅力四射地赢得我未来的岳父母。"
            show tom frown -blush shock
        else:
            show palmierproxy sad sweat at left with move
            show buff bebas sad sweat frusta at center with dissolve:
                xzoom 1.0
                yoffset 770
            buff keluh apa "[povname]，你还好吗？你刚才没有回应我说的任何话。"    
            show buff sad -apa at right with move
            mc side sweat frusta "我没事。可能是撞到头了。"
            buff keluh "你需要休息吗？我可以抱你到床上去？"
            show buff sad 
            mc hister blush sigh "不，我终于回家了，我需要见我妈妈！"
            buff touched sigh "好的。如果有什么不对劲，一定要告诉我，好吗？"
            mc kind tanya"我会的。但是你呢，莱尔？感觉有什么不同吗？"
            buff laugh blush bloom "不，一点也没有。而且我仍然能感觉到我的魔法。"
            play sound "sound/effects/grow.wav"
            "莱尔在手中变出一朵玫瑰，只是为了证明这一点。"
            show palmierproxy frown -blush shock
            show buff frown -blush shock
            "然而它凋谢得比平常更快。"
            play sound "sound/effects/grow.wav"
            buff sad sweat frusta "嗯，我想它没有以前那么强大了。"
            mc happy blush tanya "也许这是件好事。肯定会帮助你低调一段时间。"
            mc hister both -tanya "我还不确定人们会如何对待魔法这件事。"
            show buff wry blush
            mc kind blush "我不想让他们开始对你趋之若鹜，然后我不得不和一群疯狂的粉丝争夺你。"
            "莱尔对此微笑，仅仅是他的魔法可能会受欢迎的想法就让他很开心。"
            buff hister apa "你觉得我会有粉丝吗？"
            mc happy bloom"我是说，人们认为魔术师很性感，更何况是真正性感的魔术师。"
            mc laugh "现在我想把你留给我自己。"
            show palmierproxy smile
            buff lega -apa "我也想那样...但我不介意见见你的家人。"
            show buff datar
            mc kind cling "我很高兴你这么说。我们应该去我妈妈那里了。"
            mc hister bloom "不能错过我自己的生日派对。"
            show buff frown -blush shock
        play sound "sound/effects/door_bell.mp3"
        mc apa sweat tanya "嗯？那是门铃声。等等，别告诉我妈妈决定来看我？"
        play sound "sound/effects/door_bell.mp3"
        mc happy -sweat -tanya "来了！"
    else:
        scene apt with flashbulb
        play sound "sound/effects/crash.mp3"
        if girl:
            show palmierproxy jln grit at center with dissolve:
                yoffset 40
        else:
            show palmierproxy jln grit at center with dissolve:
                yoffset 100
        show palmierproxy side sweat sigh
        "一种苦乐参半的感觉在你的胃里翻腾。"
        "你的一部分为终于回家而高兴。然而另一部分却不禁感到...孤独。"
        mc sad frusta"（我再也见不到那些家伙了，是吗？）"
        show palmierproxy confused shock
        play sound "sound/effects/door_bell.mp3"
        "当你躺在公寓的地板上，强忍着泪水时，门铃响了——打断了你漫游的思绪。"
        mc frown tanya "（等等，那是我妈妈吗？！）"
        mc happy blush bloom "来了！"
    scene apt with dissolve
    play sound "sound/effects/door.mp3"
    "当你打开门时，你看到了一排熟悉的面孔。"
    if "companion" in my_events:
        "确切地说，是三个。"
        if "companion" in quil_events:
            show red bebas datar at left with dissolve:
                yoffset 330
                xoffset -200
            show tom go smile at right with dissolve:
                yoffset 190
            show buff bebas datar at center with dissolve:
                yoffset 770
            red cowo blush "你好啊，邻居！我们是隔壁的新男孩。"
            red grin cling "来握个手吧！"
            "\'塞恩\'，或者说你这个版本的塞恩抓住你的手，开始热情地握手，整个过程中都咧嘴笑着。"
            show side_p k at pic
            mc "我...呃，我..."
            hide side_p
            show buff confused with move:
                xalign 0.6
            show quil libur bingung shock at left with dissolve:
                yoffset 200
                xalign 0.2
                
            quil err sweat shock "塞恩？！"
            show quil wry -sweat sigh
            red awkward apa "天哪！这猜得太准了，伙计。你是那种塔罗牌占卜师还是什么的？"
            tom ha frusta "我还要告诉你多少次？塔罗牌占卜不是真的，塞恩。"
            red amused -apa "但这家伙刚刚猜出了我的名字。"
            tom wry blow "运气好罢了。"
            red wry apa "是啊，不过塞恩这个名字现在并不常见，不是吗？"
            buff laugh sweat "咳咳，总之，你好。我叫莱尔，我们刚搬到隔壁公寓。"
            tom amused cling "阿什姆。"
            red happy -apa "塞恩，不过你已经知道了，对吧？我还是很好奇你是怎么猜到的。"
            show tom smile -cling
        elif "companion" in red_events:
            show buff bebas datar at left with dissolve:
                yoffset 770
                xzoom -1.0
            show tom go smile at right with dissolve:
                yoffset 190
            show quil libur datar at center with dissolve:
                yoffset 200
            quil wink spark "哎呀，你好啊，邻居。哦，看到你们两位真是让人眼前一亮啊？"
            tom wry blow "真的吗，奎尔？这就开始调戏邻居了？你就不知道害臊吗？"
            show quil bingung -spark with move:
                xalign 0.55
            show red bebas frown sweat shock at center behind buff with dissolve:
                yoffset 330
                xalign 0.2
            red ngeles -shock "等等，奎尔？！"
            quil wink cling "没错，就是我！我知道这名字有点奇怪，你可以把它想象成羽毛笔的意思。"
            quil talk sigh "另外，如果我让你感到不舒服了，我很抱歉。有时候我的嘴巴不受控制。"
            show red wry -sweat 
            show quil datar -sigh
            buff hister "这可真是实话。总之，你好啊。我们刚搬到隔壁，想着应该来介绍一下自己。"
            buff datar "我是莱尔。"
            tom amused cling "阿什姆。"
            quil laugh "奎尔，不过你已经知道了。"
            show tom smile -cling
        elif "companion" in tom_events:
            show buff bebas datar at left with dissolve:
                yoffset 770
                xzoom -1.0
            show red bebas datar at right with dissolve:
                yoffset 330
                xzoom -1.0
            show quil libur datar at center behind buff with dissolve:
                yoffset 200
            quil wink spark "哎呀，你好啊，邻居。哦，看到你们两位真是让人眼前一亮啊？"
            red amused apa "真的吗，奎尔？你就不能等我们至少说声\'嗨\'再开始吗？"
            show quil bingung -spark with move:
                xalign 0.55
            show tom go eh sweat shock at center with dissolve:
                yoffset 190
                xalign 0.37
                xzoom -1.0
            tom "奎尔？！"
            show tom wry -sweat -shock
            quil wink cling "没错，就是我！让我猜猜，你们两个是一对儿，已婚？也许在找第三个人组成三人行？"
            buff kzl frusta "嘘。你就不能安静一秒钟吗？"
            buff hister sweat sigh "咳咳，总之，你好。我们是你的新邻居。我们刚搬到隔壁公寓。"
            buff amused -sigh "我是莱尔。"
            red laugh -apa "塞恩。"
            quil laugh -cling "奎尔，不过你已经知道了。"
        else:
            show red bebas datar at left with dissolve:
                yoffset 330
                xoffset -200
            show tom go smile at right with dissolve:
                yoffset 190
                
            show quil libur datar at center with dissolve:
                yoffset 200
            quil wink spark "哎呀，你好啊，邻居。哦，看到你们两位真是让人眼前一亮啊？"
            tom capek frusta "真的吗，奎尔？这就开始调戏邻居了？你就不知道害臊吗？"
            show tom frown shock
            show quil bingung -spark with move:
                xalign 0.35
            show buff bebas eh sweat shock at left behind red with dissolve:
                yoffset 770
                xalign 0.65
            buff "阿什姆先生？"
            show buff wry -sweat -shock
            tom ha apa "哦，我们见过吗？你怎么知道我的名字？" 
            red calm cling "等等，别告诉我，你是塔罗牌占卜师之类的吧，伙计？因为我也喜欢塔罗牌占卜，你知道吗？"
            show red amused -cling
            tom sigh blow "嘘！没人想知道你的塔罗牌占卜，塞恩。"
            tom pfft -blow "咳咳。总之，我们刚搬到隔壁，决定来介绍一下自己。"
            tom calm "阿什姆。"
            red laugh "塞恩。"
            quil laugh "奎尔，不过你已经知道了。"
    else:
        show red bebas datar at left with dissolve:
            yoffset 330
        show tom go smile at right with dissolve:
            yoffset 190
                
        show quil libur datar at center with dissolve:
            yoffset 200
            xalign 0.25
        show buff bebas datar at center behind red with dissolve:
            yoffset 770
            xalign 0.8
        "准确地说，是四个人。"
        quil laugh spark "哎呀，你好啊，邻居。哦，看到你真是让人眼前一亮啊？"
        tom capek frusta "真的吗，奎尔？这就开始调戏邻居了？你就不知道害臊吗？"
        buff scold sigh "你还记得上次发生了什么吗？控制一下自己吧！"
        show side_p h at pic
        mc "奎尔，莱尔，阿什姆？！"
        hide side_p
        tom pfft apa "哦，我们见过吗？你怎么知道我的名字？" 
        red laugh apa "等等，别告诉我，你是塔罗牌占卜师之类的吧，伙计？因为我也喜欢塔罗牌占卜，你知道吗？"
        tom ha blow "嘘！没人想知道你的塔罗牌占卜，塞恩。"
        tom smile -blow "咳咳。对不起，我们刚搬到隔壁，决定来介绍一下自己。"
        tom amused "阿什姆。"
        red grin -apa "塞恩。"
        quil wink -spark "奎尔。"
        buff hister -sigh "莱尔，不过你已经知道了，不知怎么的？"
    show side_p h at pic
    mc "哦，嗯，你们刚好有那种面相，你知道吗，就是...你们的名字和面相很匹配。"    
    show side_p ha
    mc "总之，我是[povname]。"
    hide side_p
    if "companion" in my_events:
        show side_p mal at pic
        mc "这是我的伴侣..."
        hide side_p
        if "companion" in quil_events:
            quil laugh blush cling "奎尔。"
            tom pfft cling "很高兴认识你。"
            tom smile -cling "希望我们没有打扰到你。我们只是在四处转转，认识一下这里的每个人。"
        elif "companion" in red_events:
            red laugh blush cling "塞恩。"
            tom pfft cling "很高兴认识你。"
            tom smile -cling "希望我们没有打扰到你。我们只是在四处转转，认识一下这里的每个人。"
        elif "companion" in tom_events:
            tom amused cling "阿什姆。"
            quil amused sigh "多么可爱的一对啊。"
            quil laugh -sigh "希望我们没有打扰到你。我们只是在四处转转，认识一下这里的人。"
        else:
            buff "莱尔。"
            tom pfft cling "很高兴认识你。"
            tom smile -cling "希望我们没有打扰到你。我们只是在四处转转，认识一下这里的每个人。"
    else:
        tom amused cling "很高兴认识你。"
        buff laugh "希望我们没有打扰到你。我们只是在四处转转，认识一下这里的每个人。"
        show tom -cling
    show side_p ha at pic
    mc "哦，不，没关系。其实真的很酷。"
    if "companion" in my_events:
        show side_p mal
        mc "嗯，我知道这可能有点突然，但你们愿意和我们一起参加一个派对吗？"
        hide side_p
        if "companion" in quil_events:
            quil talk spark "是的，拜托了，我们很希望你们能来！"
        elif "companion" in red_events:
            red amused apa "拜托了！"
        elif "companion" in tom_events:
            quil amused apa "派对？"
            tom smile cling "其实只是一个小型聚会，但我们真的很希望你们能加入我们。"
        else:
            buff hister bunga "是啊，我...我们真的很希望你们能和我们一起来！"
    else:
        show side_p mal at pic
        mc "嗯，我知道这可能有点突然，但你们愿意和我一起参加一个派对吗？"
        hide side_p
    show side_p ha at pic
    mc "这不是什么大型派对，只是我的生日...我妈妈总是在她家举办这种小型聚会，她总是准备太多食物。"
    mc "但那些食物真的很好吃，是最棒的。现在我有点跑题了，所以嗯...重点是，这是我的生日，我有一个小型派对，有免费食物，你们想来庆祝吗？"
    hide side_p
    if "companion" in my_events:
        if "companion" in quil_events:
            show red frown apa
            show tom ha apa
            show buff confused apa
            
        elif "companion" in red_events:
            show quil frown apa
            show tom ha apa
            show buff confused apa
            show red -apa
        elif "companion" in tom_events:
            show red frown apa
            show quil frown apa
            show buff confused apa
        else:
            show red frown apa
            show tom ha apa
            show quil bingung apa
    else:
        show red frown apa
        show tom ha apa
        show buff confused apa
        show quil bingung apa
    "那些男孩们都互相看着对方，也许是因为这种情况太过荒谬，以至于他们无法真正理解从你嘴里说出的这些胡言乱语。"
    show side_p g at pic
    mc "（天哪，他们都觉得我很奇怪，不是吗？该死。）"
    hide side_p
    if "companion" not in quil_events:#pasangan =/= Quill
        quil err frusta "让我理清一下。你在邀请我们，一群你刚认识的陌生人，去你家庆祝你的生日？"
        show quil datar -frusta
    else:#pasangan = Quill
        red sad frusta "让我理清一下。你在邀请我们，一群你刚认识的陌生人，去你家庆祝你的生日？"
        show red amused -frusta
    show side_p h at pic
    mc "...是的？"
    hide side_p
    if "companion" in quil_events: # pasangan = Quill
        red laugh blush bloom "好啊！谢谢你的邀请，伙计！你真的不介意我们这样冒昧地去吗？"
        show tom pfft -apa
        show buff datar -apa
        show red datar -bloom
        show side_p ha at pic
        mc "哦，没关系，完全没问题。"
        hide side_p
        red cowo "好吧。至少让我们开车送你去吧。我们有一辆小型面包车，应该能容下我们所有人。"
        show red datar -blush
        show side_p ha at pic
        mc "一辆小型面包车？"
        hide side_p
    elif "companion" in tom_events: #pasangan = Arshem
        quil talk sigh "亲爱的，我不知道你是处于什么悲惨和绝望的孤独状态，迫使你这么做，"
        quil laugh bunga "但不管是什么...我喜欢。"
        show red amused -apa
        show buff datar -apa
        show side_p ha at pic
        mc "呃，谢谢？"
        hide side_p
        quil heh cling "哦，我喜欢你。我们一定会相处得很好的。"
        show quil datar -cling
        buff wry sigh "请别理会奎尔。他的意思是...我们很感谢你的邀请，非常乐意去。"
        buff laugh -sigh "我们开车还是你开车？"
        show side_p ha at pic
        mc "你有什么样的车？"
        hide side_p
    else:#pasangan = Thane/Lyall
        if "companion" in red_events:
            show buff amused -apa
            show tom pfft -apa
        else:
            show red amused -apa
            show tom pfft -apa
        quil talk sigh "亲爱的，我不知道你是处于什么悲惨和绝望的孤独状态，迫使你这么做，"
        quil laugh bunga "但不管是什么...我喜欢。"
        show side_p ha at pic
        mc "呃，谢谢？"
        hide side_p
        quil heh cling "哦，我喜欢你。我们一定会相处得很好的。"
        show quil datar -cling
        tom giggle blow "请别理会我这个话多的朋友。他真正的意思是...我们很感谢你的邀请，非常乐意去。"
        tom pfft -blow "我们开车还是你开车？"
        show side_p ha at pic
        mc "你有什么样的车？"
        hide side_p
        
    if "companion" not in buff_events: #pasangan =/= Lyall
        buff amused -sweat sigh"一辆白色小型面包车，在你问之前，不，它不是用来做什么见不得人的事的。"
        show buff wry -sigh
    else: #pasangan = Lyall
        tom giggle blow"一辆白色小型面包车，在你问之前，不，它不是用来做什么见不得人的事的。"
        show tom amused -blow
    show side_p ha at pic
    mc "嗯，你有没有想过说这话反而让你听起来更可疑了？"
    hide side_p
    if "companion" not in red_events: #pasangan =/= Thane
        red laugh apa "看吧，我说什么来着？白色小型面包车就是个危险信号，伙计。"
        red amused -apa "还有，你真的不介意我们空手去你父母家吗？不是烧烤派对之类的吧？"
        show side_p ha at pic
        mc "不，不是烧烤派对或其他什么，只是个生日派对。"
        hide side_p
    else:#pasangan = Thane
        quil heh sigh "相信我，我已经试图说服他们换车好几年了！"
        show quil amused -sigh
    if "companion" not in quil_events: #pasangan =/= Quill
        quil laugh "对了，生日快乐！"
        quil wink cling "你总是通过带一群男人回家来庆祝生日吗？"
        show quil amused -cling
        show side_p ha at pic
        mc "有时候是。"
        hide side_p
        show quil frown shock
        "你对奎尔的调情眨了眨眼。与另一个世界的奎尔不同，他没有脸红，但他确实笑了。那是一种响亮而爽朗的笑声。"
        quil mock cling "哦，我真的很喜欢这个人。"
        quil sly -cling "我们一定会相处得很好的，你和我。"
        if "companion" in my_events:
            if "companion" in quil_events:
                show quil laugh bunga
            elif "companion" in tom_events:
                show tom calm bunga
            elif "companion" in red_events:
                show red laugh bunga
            else:
                show buff laugh bunga
            "你的伴侣对这句话咧嘴一笑，显然很期待你们将建立的友谊。"
            "他握住了你的手，急切地想再次与他长期朋友的另一个版本成为朋友。"
            show side_p ha at pic
            mc "是啊。我们也这么认为。"
            
        else:
            show side_p ha at pic
            mc "是啊。我也这么认为。"
        hide side_p
    else: #pasangan = Quill
        tom amused blow "对了，生日快乐。抱歉我们手头没有礼物。"
        if "companion" in my_events:
            show side_p mal at pic
            mc "哦，别担心。"
            hide side_p
            if "companion" in quil_events:
                show quil laugh bunga
            elif "companion" in tom_events:
                show tom calm bunga
            elif "companion" in red_events:
                show red laugh bunga
            else:
                show buff laugh bunga
            "你握住了伴侣的手，急切地想了解这个不久前你分别的朋友们的另一个版本。"
            show side_p ha at pic
            mc "你们已经给了我们最好的礼物了！"
            hide side_p
        else:
            show side_p ha at pic
            mc "哦，别担心。你已经给了我最好的礼物了！"
            hide side_p
    stop music
    scene bg_black with w20
    if "truth" in my_events:
        if "mc_win" in fia_events:
            show text "你的幸福结局：真正的平和" with dissolve
            $ achievement.grant("Achievement03_MC")
            init:
                $ achievement.register("Achievement03_MC")
                $ achievement.sync()
            $ achievement.sync()
            $ renpy.pause()
            show bg_black with dissolve
            jump ivar_furry
            
            
        else:
            jump after_all_this
            
    else:
        
        show text "你的幸福结局：无知是福" with dissolve
        
        $ renpy.pause()
        show bg_black with dissolve
        jump end_game
label ivar_furry:
    scene qpt with w33
    play music "MUSIC/MusMus-BGM-073.mp3" fadein 1.0
    if girl:
        show palmierproxy dobel rajuk msmoke at center with dissolve:
            yoffset 40
    else:
        show palmierproxy dobel rajuk msmoke at center with dissolve:
            yoffset 100
    mc "哼..."
    show palmierproxy at right with move
    show croissant pain at left with moveinleft:
        yoffset 500
        xzoom -1.0
    show palmierproxy frown shock
    fia apa "想什么呢？"
    show croissant wry -apa
    show palmierproxy deject sigh
    "你的另一个自己已经回到了他们的世界。这感觉很不真实。"
    "你的思绪游离，思考着你新的...身体室友。"
    show palmierproxy confused frusta
    show croissant mmh sweat shock
    "看着你所有的朋友们醉倒在沙发上安静地躺着，你不禁感到这一切是多么的不公平。"
    "他们在放松，而你身体里的巫师却在受苦。"
    "要是有办法让他们也能...快乐就好了。"
    show palmierproxy kzl sweat shock
    fia mad -sweat frusta "喂，愁眉苦脸的，在听吗？"
    mc judes msmoke tanya "啊？"
    fia hmph apa "我问你有没有力气帮我打扫卫生？"
    mc side sweat sigh "哦，抱歉菲亚，我...我..."
    mc ow mata frusta "我只是忍不住觉得这个结果很不公平。"
    fia flinch cringe sweat shock "啊？"
    mc sad sigh "我们长期以来一直恐吓巫师，而现在他们失去了一切。"
    mc rajuk -sigh "我知道双方都不是无辜的，但现在我的身体里寄宿着这些巫师..."
    mc frown frusta "我看到的只有折磨和审判的记忆。难道她们不也应该得到一个幸福的结局吗？"
    show palmierproxy frown shock
    fia def smile -sweat apa "嗯，我是说，如果你对此感到沮丧，你不能给她们找个新的宿主吗？"
    fia laugh -apa "比如来自另一个世界的她们自己的版本。就像另一个你一样？"
    mc rajuk tanya "嗯，既然你提到了...我大概可以做到，对吧？"
    mc flirt cling "嗯。我应该能够打开通往其他世界的传送门。也许那里有一个伊瓦尔保留了所有孩子的版本，你知道吗？"
    fia happy cling "也许吧？只有一种方法可以知道！"
    mc happy "...让我们先从伊瓦尔开始。"
    play music "sound/effects/portal.wav"
    scene qpt with dissolve
    "利用梅扎的维度旅行能力和伊欧的神性，你能够确定哪个版本的伊瓦尔会让你的伊瓦尔最幸福。"
    "你轻轻一挥手，传送门打开了，显现出..."
    galleryunlock ivar_woof
    scene ivar_woof with flashbulb:
        truecenter zoom 1.5
        easein 2.0 truecenter zoom 0.5
    "...一个兽人？"
    iv "哦天哪，我本以为今晚只有一个发情期的伴侣呢。"
    iv "好吧，我相信我有足够的体力来取悦你们两个。"
    fia "什么鬼？！这就是最幸福的伊瓦尔版本吗？真是个变态！"
    fia "快，在其他人醒来之前关闭传送门，格兰布斯！"
    mc "..."
    fia "...格兰布斯？"
    mc "菲亚，你能给我一两个小时和这个男人独处的时间吗？"
    fia "...认真的吗？"
    stop music
    scene bg_black with fade
    jump end_game







label after_all_this:
    hide screen cal
    show text "三个月后..." with dissolve
    $ renpy.pause()
    
    scene apt with w20
    play music "MUSIC/MusMus-BGM-CP03.mp3"
    if "companion" not in my_events:
        show red bebas datar at left with dissolve:
            yoffset 330
            xoffset -200
        show tom go smile at right with dissolve:
            yoffset 190
                
        show quil libur datar at center with dissolve:
            yoffset 200
            xalign 0.25
        show buff bebas datar at center behind red with dissolve:
            yoffset 770
            xalign 0.65
        quil groan frusta "直接杀了那婊子，把剑拔出来就行了。"
        red ow frusta "伙计，我不可能拿到那把剑的。我的属性太低了。你才是野蛮人，我可没有通过那个力量检定的能力。"
        buff wry sigh "还有一个问题是如何接近那把剑，除非只有我能看到这里的亡灵大军？"
        tom ha blow "用潜行技能，施放黑暗术，你应该就能直接走过所有人了。"
        buff keluh sweat apa "但是黑暗术不是也会让我们看不见吗？"
        show red amused -frusta
        show quil hister -frusta
        show tom calm -blow
        show buff datar -sweat -apa
        "听着朋友们争论，你不禁微笑起来。你们已经玩D&D很长时间了。"
        "你很高兴地发现奎尔仍然和另一个版本的他一样是个混乱的小精灵。"
        "阿什姆依然是个严肃的老妈子，塞恩仍然是个快乐的小狗狗，现在还带着可爱的澳大利亚口音。"
        "莱尔也依然是你所熟知和喜爱的那个甜心，不过你很高兴地发现，这个版本的他比你离开的那个莱尔更加自信。"
        show side_p ha at pic
        mc "我施放油腻术然后炸掉周围的敌人怎么样？"
        hide side_p
        tom pfft apa "聪明，但你可能也会损坏那把剑。"
        show side_p g at pic
        mc "那把剑不是地狱系的吗？它应该是耐火的。"
        hide side_p
        quil bingung apa "是吗？"
        tom capek frusta "嗯，也许我们今天该结束了。已经凌晨3点了。"
        red kaget sweat shock "我的天，你说得对。"
        show red amused -sweat sigh
        show tom pfft -frusta
        show quil wry -apa
        show side_p ha at pic
        mc "凌晨3点从来不会有好事发生。我们去睡觉吧，伙计们。"
        hide side_p
        buff laugh bunga "好的。再次感谢你邀请我们来，[povname]。"
        quil wink cling "是啊，说真的，我们应该在我们的房间之间开个洞。弄成一个超大的单元。"
        tom giggle blow "然后被房东赶出去？不，谢谢。"
        tom smile -blow "晚安，[povname]！"
        show side_p ha at pic
        mc "晚安！"
        hide side_p
        stop music
        play sound "sound/effects/doorslam.mp3"
        scene apt with dissolve
        "你幸福地叹了口气，倒在沙发上。最近，你在这里睡觉的时间比在自己房间里多得多。"
        "希望能在梦中瞥见另一边朋友们的影子。"
        if girl:
            show palmierproxy jln side sweat at center with dissolve:
                yoffset 40
        else:
            show palmierproxy jln side sweat at center with dissolve:
                yoffset 100
        mc frusta "（我不应该这么想念他们，从技术上讲，他们就在这里。就在隔壁。）"
        mc sigh "（不过，我还是在想你们在那边过得怎么样，塞恩、奎尔、阿什姆、莱尔，当然还有菲亚。）"
        mc sad -sigh "（我想念你们。）"
        play sound "sound/effects/cloth.mp3"
        scene bg_black with eye_shut
        "你调暗了灯光，闭上眼睛，希望能看到一个你知道可能永远无法触及的世界。"
        "但随后你真的看到了。只是它并不完全如你记忆中的那样。然后你有一种不安的感觉，好像有什么东西在注视着你。"
        "某种不祥的东西。"
    else:
        if "companion" in quil_events:
            scene bali with w20
        else:
            scene apt with w20
        if girl:
            show palmierproxy jln kind at center with dissolve:
                yoffset 40
        else:
            show palmierproxy jln kind at center with dissolve:
                yoffset 100
        mc happy blush bunga "我回来了！"
        show palmierproxy at left with move
        if "companion" in quil_events:
            show quil libur datar at right with dissolve:
                yoffset 200
            quil laugh blush bloom "欢迎回来，亲爱的！"
            "奎尔用一个令人安心的拥抱和一个温柔的唇吻迎接了你。"
            "你融化在他的怀抱中，漫长的一天工作终于似乎变得值得了。"    
            "不过，称之为\'工作\'有点勉强，因为你整天都在冲浪和购物。"
            "奎尔的金钱让你过上了更奢华的生活。你不再像从前那样在办公桌前辛苦工作，朝九晚五。"
            "相反，你在巴厘岛冲浪，在潮湿的街道上漫步，寻找新的美食尝试。"
            "这一切都由你那古怪而富有的男朋友买单。"
            mc malu sigh "我从未想过我会过上包养的生活，但现在我就是这样。"
            quil wink cling "你值得。亲爱的，你值得生活能给予的所有财富。说到这个，我一直在考虑在日本生活一年。"
            quil talk apa "你觉得怎么样？"
            mc wry -sigh "你是说新鲜的寿司和奇怪的咖啡馆？我同意。但也许至少等到十二月吧。我还想趁机多探索一下这个岛屿。"
            quil laugh bunga "随你的意。亲爱的，这个世界是我们共同享受的。"
            show quil hister at center with move
            show palmierproxy malu shock
            if girl:
                galleryunlock quil_endf
                show quil_endf with flashbulb:
                    truecenter zoom 2.0
                    easein 2.0 truecenter zoom 1.0
            else:
                galleryunlock quil_endm
                show quil_endm with flashbulb:
                    truecenter zoom 2.0
                    easein 2.0 truecenter zoom 1.0
            "奎尔又一次深深地吻了你。他调皮地轻咬你的脖子，舔去流到你胸前的汗水。"
            mc hister -shock "嗯，奎尔，停下，我很脏！我一整天都在出汗。"
            quil sly cling "那又怎样？我可以用舌头清理你。舔掉粘在你罪恶身体上的每一滴汗珠。"
            mc happy tanya "哈哈，你现在变得相当色情了，不是吗？"
            quil smile -cling "那是谁的错呢？"
            mc hister -tanya "啊哈哈！"
            "奎尔把你带到床上，慢慢地享受你的每一部分，一点一点地。"
            "当他探索你的每一寸肌肤时，你的喘息和呻吟被海浪声淹没，他信守承诺，用舌头描绘你的身体。"
            quil "我爱你，[povname]。"
            mc "我也爱你。"
        elif "companion" in red_events:
            show red bebas datar at right with dissolve:
                yoffset 330
                xzoom -1.0
            red amused apa "嘿宝贝，今天工作很辛苦吗？"
            mc wry sigh "你知道答案的。我的感受又通过灵魂纽带泄露了吗？对不起。"
            red hister sigh "确实泄露了，但没关系。感受到你在另一边实际上帮助我集中精力度过了这一天。汤普森先生又从天花板爬了进来。"
            mc avoid frusta "又来？"
            show palmierproxy kind -frusta
            "你回到自己的世界已经三个月了。起初，你担心塞恩无法适应，"
            "担心他会想家，后悔跟你一起离开。"
            "但当你看到塞恩的妈妈——这个世界版本的他妈妈，在附近的养老院工作时，你所有的担忧都消除了。"
            "塞恩很快就和这位女士建立了联系，申请在同一个地方工作，并迅速成为了院民们的最爱。"
            "这份工作很适合他，塞恩显然很享受这份工作，因为它让他保持忙碌。"
            red wry -sigh "是的，我实际上用了我的翅膀把他弄了下来。"
            mc confused sweat shock "Thane!"
            red laugh sigh "别担心，没人看见，也没人相信汤普森先生说的话！"
            red grin -sigh "妈妈——我是说，布拉德肖夫人对我处理情况的方式很满意。甚至给了我一些松饼。"
            mc happy -sweat tanya "你有给我留些松饼吗？"
            red perih sweat frusta "哦，哦糟糕！对不起，我没想到你会想要！"
            mc laugh blush bunga "哈哈！我只是开玩笑的。它们尝起来像你妈妈做的松饼吗？"
            red cowo blush bloom "是的，除了没有血。"
            mc smile sigh "很好，如果有血的话我会担心的！"
            red mock cling "说到血，你能不能...我是说，如果你不是太累的话。"
            show red laugh bloom
            mc mean cling "...过来。"
            if girl:
                galleryunlock red_pf_end
                show red_pf_end with flashbulb:
                    truecenter zoom 2.0
                    easein 2.0 truecenter zoom 1.0
            else:
                galleryunlock red_pm_end
                show red_pm_end with flashbulb:
                    truecenter zoom 2.0
                    easein 2.0 truecenter zoom 1.0
            "你跳进塞恩的怀抱，他把你抱到卧室。"
            "你的双腿缠绕在他的腰间，他咬住你的脖子，吸吮你的血液。"
            "这已经成为一种例行公事了。进食，做爱，然后整晚相拥入眠。"
            "不过今天你可能会跳过做爱的部分。"
            "塞恩似乎并不介意，你能感觉到他通过灵魂纽带发出的哼声。完全理解你的想法和需求。"
            "拥有灵魂纽带感觉很奇妙。与你之前的任何关系都不同，你不需要说出你的担忧或情感。"
            "你们彼此理解，就好像你是他的延伸，反之亦然。起初你觉得这可能会很侵犯隐私。"
            "但现在，你无法想象没有它会是什么样子，失去他就像失去一肢。"
            red "这种感觉是相互的，我的灵魂。"
            "塞恩一边说着，一边把你放下，从背后抱住你。"
            mc "哦，你能听到吗？"
            red "一点点。有时你的想法会通过灵魂纽带泄露出来。不过我很高兴，这意味着我们的纽带越来越强了。"
            red "就像我们日益增长的爱情的证明。"
            "塞恩把你的头发别到耳后，将你塞进被窝。你很累，而塞恩一边玩弄你的头发一边发出的安抚哼声并没有帮你保持清醒。"
            mc "我好困。"
            red "我知道，睡一会儿吧。我会在晚餐时叫醒你的。"
            mc "嗯。好的。谢谢你。"
        elif "companion" in tom_events:
            show tom go pfft at right with dissolve:
                yoffset 190
            tom apa "亲爱的，工作怎么样？"
            mc side frusta "糟透了！"
            show palmierproxy frown shock
            tom amused cling "嗯。那我来得正是时候。我来给你洗头，给你做一个你从未体验过的最棒的头皮按摩如何..."
            tom calm -cling "...然后把你抱到床上，给你按摩后背，最后把你裹成一个小小的玉米卷，同时我会点上我精选的香薰蜡烛。"
            mc wry blush sigh "嗯，我爱你。"
            tom wry blush bloom "我也爱你。"
            "和阿什姆在一起的生活很简单。他体贴、宠爱你，把你惯坏了。"
            "他说到做到，找了一份与花卉和园艺有关的工作。不过，你确实没想到他会成为一名调香师。"
            "他目前正在当地的调香学校学习，参加为期六年的课程，同时在当地的花店兼职，还做一些零工。"
            "当他不工作或学习时，他会在网上论坛和聊天室里寻找他父亲的线索。目前还没有头绪，但你们依然抱有希望。"
            "这确实是一项昂贵的努力，但幸运的是他带来了所有的积蓄，所以你们俩暂时都不用担心钱的问题。"
            "老实说，你非常乐意为他的事业出一份力，尤其是考虑到他在家里帮了那么多忙。"
            "做饭、打扫、洗衣服...他把家务活做得如此轻松自如，真是令人惊叹。"
            "你也确保让他知道你的感激之情，通过礼物、赞美，当然还有床上的表现。"
            show palmierproxy malu -sigh
            "虽然有时候很难分清在那方面谁在奖励谁。谁能想到只需要一次穿越到另一个世界的旅程就能找到你的理想型呢？"
            tom pfft apa "想什么呢？"
            "他问道，这时你才意识到自从他把你放到床上细心按摩你的背部以来，你一句话都没说。"
            mc happy blush bunga "没什么，我只是在想有你真是太幸运了，阿什姆。"
            tom calm blow "我也是，亲爱的。"
            if girl:
                galleryunlock arsh_end_f
                show arsh_end_f with flashbulb:
                    truecenter zoom 1.0
                    easein 2.0 truecenter zoom 0.5
            else:
                galleryunlock arsh_end_m
                show arsh_end_m with flashbulb:
                    truecenter zoom 1.0
                    easein 2.0 truecenter zoom 0.5
            "他低语道，同时按摩到了一个特别敏感的地方。"
            mc "嗯。你要是继续这样，我可能会睡着的，你知道吗？"
            tom "那就睡吧。我保证很快就会加入你。就在我处理完你这个讨厌的结之后。"
            mc "啊哈哈，你总是这么追求完美，是不是？"
            tom "你就是爱我这一点。"
            mc "是的。*哈欠...我想我要睡觉了。"
            "阿什姆吻了吻你的额头，拨开你的刘海。然后他继续执着于他的任务，要消除你身上所有的结，按摩着所有恰到好处的地方。"
            "是否有可能因为太过放松而死去？如果真的有可能，你也不介意以这种方式离开。"
            "死在你深爱的男朋友那魔法般的双手下。"
            tom "做个好梦。"
            
        else:
            show buff bebas laugh at right with dissolve:
                yoffset 770
            buff apa "[povname]！工作怎么样？"
            show buff datar -apa
            mc ha sigh "嗯，你知道的，可怕的加里又在吓人了。不过，他快退休了，所以..."
            show palmierproxy mean cling
            show buff laugh blush bunga
            play sound "sound/effects/grow.wav"
            "你朝莱尔竖起中指，同时大大地张开双腿，微微蹲下。"
            show palmierproxy wry blush shock
            "他对你的动作笑了笑，然后递给你一束花。"
            show palmierproxy kind -shock
            "这些花在你手中只存在了几分钟就枯萎了。"
            mc wry tanya "现在只能持续几分钟了，是吗？"
            buff amused sigh "最多五分钟，但它们很美。"
            mc kind -tanya "一直都很美。不过，你想念它吗？"
            buff hister -sigh "我那杀人犯父亲的魔法？呸，才不呢！"
            buff amused"实际上，我很期待它们完全消失的那一天。"
            buff laugh sigh "虽然我猜到时候我就得花真金白银买真花了。"
            mc hister blush bloom "啊哈哈。我更愿意用一顿美餐和一些温存时光来代替。"
            buff sinis cling "还有亲吻呢？"
            show buff datar -cling
            mc laugh "嗯，你提出了一个艰难的交易，但是..."
            buff laugh blush bunga "啊哈哈哈，过来。"
            play sound "sound/effects/cloth.mp3"
            if girl:
                galleryunlock lyall_endf
                show lyall_endf with flashbulb:
                    truecenter zoom 2.0
                    easein 2.0 truecenter zoom 1.0
            else:
                galleryunlock lyall_end
                show lyall_end with flashbulb:
                    truecenter zoom 2.0
                    easein 2.0 truecenter zoom 1.0
            "莱尔把你拉入怀中，将你抱起，同时你们的嘴唇相接。他探索着你口中的每一个角落。"
            "爱上莱尔很容易，他是个体贴的爱人，温柔又关心人。然而，如果你恰到好处地挑逗他，一个新的面貌就会出现，更加狂野，更加大胆。"
            "莱尔把你抱到床上，用他的嘴唇膜拜你的全身。他亲吻你的每一寸肌肤，引出你最甜美的叹息。"
            "你揉乱了他的头发，注意到上面还粘着几片叶子。"
            "可能是来自他工作的葡萄园。给他找份工作很容易，有人说他有魔法般的触碰。"
            "要是他们知道这些触碰有多么神奇就好了。"
            mc "嗯。"
            buff "你还好吗？你看起来心不在焉。"
            mc "只是累了而已。今天是漫长的一天。"
            buff "我明白了。"
            "他又亲了一下你的肚子，然后在床上挪到你身边。"
            "你有一部分为失去而感到悲伤，但另一部分却感激他今晚的理解。"
            "你现在需要的是一个睡眠伙伴，而不是另一个无眠的性爱之夜。"
            "他抚摸着你的头发，轻轻地用手指梳理，哄你入睡。"
            buff "你该去睡觉了。"
            mc "是啊，我累了...对不起。"
            buff "别这样，我们总可以在早上找乐子，不是吗？"
            mc "我会记住你的话的。"
            buff "哈哈，我就希望你会这么说。晚安，[povname]。"
            mc "晚安..."
        stop music
        scene bg_black with eye_shut
        "没过多久，睡意就席卷而来，黑暗将你拖入梦乡。"
        "只是这个梦远不如你清醒时的世界那么平静。"
        "有什么东西在睡梦中惊扰了你。一种不祥的东西。"
        "一个你可能会后悔得到的答案。"
    if "ivar_win" in fia_events:
        jump ivar_tamat
    else:
        jump seth_tamat
label seth_tamat:
    play sound "sound/effects/cloth.mp3"
    play music "MUSIC/agnus.mp3" fadein 4.0
    scene kantin with eye_open
    if girl:
        show palmierproxy jln sad at center with dissolve:
            yoffset 40
    else:
        show palmierproxy jln sad at center with dissolve:
            yoffset 100
    mc pissed sweat shock "什么——？！我怎么又回到这里了？！"
    show palmierproxy confused -shock
    "一个熟悉的空间迎接了你，这是你在许多个早晨反复造访过的地方。"
    "伊格尼亚的巫师猎人学院的食堂。不过，有些地方不太一样。"
    "你注意到所有的学生都在茫然地盯着前方，对着他们的餐食点头。"
    "他们低着头，对你的爆发没有任何反应。老师们坐在座位上，同样面无表情。"
    show seth_eyes with dissolve
    galleryunlock seth_eyes
    "迪特里希茫然地盯着他的餐食，而凯普勒则弯着脖子，在座位上蜷缩着。"
    "海德温似乎是最糟糕的。她眼中那种光芒现在完全被一种空洞的凝视所取代。"
    hide seth_eyes with dissolve
    if girl:
        show palmierproxy2 dobel flirt mseth at right with dissolve:
            yoffset 40
    else:
        show palmierproxy2 dobel flirt mseth at right with dissolve:
            yoffset 100
    show palmierproxy sad sweat shock at left with move
    mk mock cling "你好，[povname]。"
    mc ow shock "[povname]？！"
    mk malu sigh "你看，我觉得用同一个名字会相当混乱。"
    mk mean -sigh "如果你愿意的话，我更希望你能叫我的真名。"
    show palmierproxy pissed frusta
    "那双眼睛...一只野兽般的，一只是你自己的。你立刻就知道谁才是真正掌控你那个形态的人。"
    mc kzl "塞斯..."
    $ mk = Character('塞斯', callback=name_callback, cb_name='mc', image='palmierproxy2')
    mk mock cling "叮，叮，叮！请大家为这只令人惊叹的小兔子鼓掌。"
    play sound "sound/effects/clap.mp3"
    show palmierproxy kzl shock
    "所有的学生和老师都开始鼓掌，甚至包括海德温。她的尸体鼓掌速度如此之快，以至于她腐烂的四肢都飞了出去。"
    "你对这景象感到畏缩，然后朝塞斯跑去，希望能给他一拳，但他只是用魔法将你定在半空中。"
    mk flirt tanya "你好啊，美人？你看起来很生气。什么在困扰你？"
    show palmierproxy ow frusta
    mc "你做了什么？！"
    mk mock sigh "哦。我做了[povname]想要的。和平。"
    mk flirt -sigh "我告诉你，起初我确实觉得控制每个人成为我的小玩物这个想法很新奇。"
    mk "不是说我以前从未考虑过，只是这会耗费我太多精力，你知道吗？"
    mk happy bunga "但是有了其他巫师为这具身体提供能量，嗯...现在这就不再是个问题了，对吧？"
    mk mock cling "你的[povname]是个意志如此薄弱的小宠物。"
    mk wry sigh "一旦我的赫卡特玫瑰符文激活，我的胜利就是确定的了。我很惊讶你没有注意到我心脏上那个巨大的发光符文。"
    mk mock cling "除非你决定冒险，尽管那个印记在向你警告。你这个傻瓜。"
    show palmierproxy sad frusta
    mc "菲亚...菲亚在哪里？！"
    mk flirt sigh "哦，她很安全。不是吗，我的女孩？"
    show palmierproxy side shock
    mc "什，什么——？"
    "他扭转了你僵硬的身体。你无法移动，因为他的魔法控制着你。"
    "你的身体漂浮在半空中，像个发条玩具一样旋转。"
    show fia_deth with dissolve
    galleryunlock fia_deth
    fia "...[kk]。"
    "你看到菲亚朝你走来，眼神空洞，嘴巴微张。唯一的生命迹象是她的眼睛，泪水盈眶，与她扭曲的微笑形成鲜明对比。"
    mk "亲爱的，你愿意跳舞吗？你知道我有多喜欢看你四处移动。"
    "菲亚点点头，然后旋转着做了个单脚旋转。"
    "低头看去，你可以看到血液从她的鞋子里渗出，在地板上汇成一滩。"
    hide fia_deth with dissolve
    mk mean cling "她不是很可爱吗？有时我会让她连续跳舞好几天，她不介意。至少，我没听她抱怨过。"
    show palmierproxy ow frusta
    mc "不！停下！这是什么？！你为什么要给我看这个？"
    mk judes tanya "嗯。也许是一份礼物？或者是一个警告？关于即将降临到你们世界的命运。"
    show palmierproxy kzl shock
    mc "什么？你不是...你不是想要跨越过来吧？！"
    mk malu sigh "不。至少现在还不是。恐怕这具身体与科尔的血液不相容。我不像她那样能自由地流出墨水。"
    mk judes -sigh "即使是一滴墨水从我的伤口流出，也要花上几个月的时间。"
    mk frown "也许是不匹配吧。"
    mk confused "不过，我在想..."
    play sound "sound/effects/bump.mp3"
    if girl:
        galleryunlock seth_fend
        scene seth_fend with dissolve:
            truecenter zoom 1.0
            easein 1.0 truecenter zoom 0.5
        "塞斯将你的身体高高举起，狠狠地摔在附近的桌子上。"
        "你感到盘子碎片扎进背部时不禁畏缩了一下。"
    else:
        galleryunlock seth_mend
        scene seth_mend with dissolve:
            truecenter zoom 1.0
            easein 1.0 truecenter zoom 0.5
        "塞斯将你的身体高高举起，狠狠地摔在附近的墙上。"
    mc "啊啊啊！！！"
    mk "我在想你的身体会不会有所不同。你是亲爱的[povname]的另一个版本。也许你的身体也能承受科尔的联结并茁壮成长。"
    mk "你怎么说，宠物？愿意参与一个小小的...实验吗？"
    mc "不，不，不！放开我！放开我！"
    play sound "sound/effects/splat.wav"
    mc "啊啊啊啊！！！" with vpunch
    window hide 
    $ renpy.pause()
    scene bg_black with wet
    show text "塞斯的幸福结局：私人游乐场" with dissolve
    $ achievement.grant("Achievement04_Seth")
    init:
        $ achievement.register("Achievement04_Seth")
        $ achievement.sync()
    $ achievement.sync()
    $ renpy.pause()
    show bg_black with dissolve
    $ mk = Character('[povname]', callback=name_callback, cb_name='mc', image='palmierproxy2')
    jump bad_end_game
label ivar_tamat:
    play sound "sound/effects/cloth.mp3"
    scene dande with eye_open
    if girl:
        show palmierproxy jln sad at center with dissolve:
            yoffset 40
    else:
        show palmierproxy jln sad at center with dissolve:
            yoffset 100
    mc pissed sweat tanya "我...我在哪里？"
    "你试图理解周围环境时，视野中尽是一望无际的花海。"
    show palmierproxy sad shock
    "这景象既熟悉又陌生。"
    if girl:
        galleryunlock darah_brosf
        show darah_brosf with dissolve
    else:
        galleryunlock darah_bros
        show darah_bros with dissolve
    "直到你踏入无尽的花海，踩到一颗熟悉的蓝宝石，你才意识到自己一直在踩着什么。"
    show side_p k at pic
    mc "不！不！不！不！"
    play music "MUSIC/PerituneMaterial_Piano_Sad2.mp3"
    hide side_p
    play sound "sound/effects/vine.wav"
    "你闭上眼睛，但你仍能听到哭泣声，乞求死亡的声音。"
    "血液从带露的花瓣中渗出的湿润声响。"
    if girl:
        hide darah_brosf with dissolve
    else:
        hide darah_bros with dissolve
    if girl:
        show palmierproxy2 dobel flirt mivar at right with dissolve:
            yoffset 40
            xzoom -1.0
    else:
        show palmierproxy2 dobel flirt mivar at right with dissolve:
            yoffset 100
    mk cling "美丽，不是吗？"
    show palmierproxy sad sweat shock at left with move
    mc ow "[povname]！"
    "你看到你的分身，你的另一个自我，站在这扭曲天堂的中心。"
    "[dia]嘴角浮现出一丝微笑，[kamu]摘下一朵花，将它变成了别的东西。"
    mk happy tanya "我从未问过你最喜欢的花是什么，对吧？"
    mk judes "萨蒂纳斯？菊花？百合？"
    mk flirt -tanya "不过，我觉得罂粟花最适合你。"
    "当[povname]说话时，[dia]手中的花朵随着他的话语变化。最后变成了一朵粉色的罂粟花，他轻轻地将它别在你的耳后。"
    mc pissed frusta "[povname]，你——你做了什么？！"
    mk mock tanya "得了吧，孩子，你必须用那个假名称呼我吗？"
    show palmierproxy confused shock
    "你记得那种居高临下的语气，那种似乎嘲笑所有被他注视的人的轻蔑眼神。"
    mc ow frusta "伊瓦尔？"
    $ mk = Character('伊瓦尔', callback=name_callback, cb_name='mc', image='palmierproxy2')
    mk happy sigh "你好，我的朋友。"
    show palmierproxy2 flirt -sigh
    "这个[povname]可能仍然保持着你的形态，但那金色的眼睛是无法错认的。"
    if "iv_kissed" in fia_events:
        mc ew "我...我以为[povname]已经控制住你了。"
        mk mock "哦，[kamu]确实奋力抵抗过。可惜还是不够。"
        mk mean sigh "不过我确实通过对[dia]的同伴施以仁慈来尊重[dia]的努力。"
    elif "iv_curhat" in fia_events and "iv_kissed" not in fia_events:
        mc pissed shock "我...我信任你！你说过你会让他们活下去的！"
        "伊瓦尔对你的爆发嗤之以鼻，他低下头蹲下身来与你平视。"
        mk mock tanya "我难道没有信守承诺吗？我说过我会让你的朋友们生活在一个充满和平与和谐的地方。"
        mk mean -tanya "环顾四周吧，孩子。花朵盛开，鸟儿啁啾，微风拂过你的发丝。"
        mk flirt "你看到有战争吗？有歧视吗？没有。和平终于降临到这片土地上了。"
        mk mock "不再有巫师、人类、吸血鬼、精灵或任何其他愚蠢的害虫之间的争吵，诅咒这个被遗弃的地方。"
        mk flirt cling "只有无尽的花海，让世界在其中治愈。"
        mc ew frusta "我的朋友们——！菲亚！"
        show palmierproxy sad shock
        mk kind -cling "你的朋友们都还活着，一切安好，就像我说过的那样。事实上，他们会比你活得更久。"
        mk flirt "这是一种不朽的祝福生活，没有痛苦，因为我甚至主动麻痹了他们的感官。你可以把这看作是我的仁慈。"
        
    else: 
        mc pissed shock "怎、怎么可能？！"
        mk wry sigh "赫卡特之蔷薇，我胸前的符文。"
        mk flirt -sigh "一旦你把我的心脏放到你的[povname]上，一切就结束了。我掌控了一切。"   
        mk mock "符文真正生根需要一段时间。"
        mk "为了保存我的意识而不是[povname]的，但它最终完成了任务。"
        mk mean cling "当然，如果没有你，[povname]，我是不可能做到这一切的。"
        mc ow frusta "你——你骗了我！你利用了我！"
        mk judes sigh "我确实利用了你。但我没有说谎。"
        mk mock cling "我承诺过会确保你朋友们的安全，给予他们平和的生活。"
        mk flirt -cling "还有什么比无害的花海和永生更能带来平和呢？"
        mk "我甚至主动麻痹了他们的痛觉。你可以把这看作是我的仁慈。"

    mc pissed frusta "仁慈？！"
    show palmierproxy sad shock
    play sound "sound/effects/grow.wav"
    "你听到身后传来沙沙声。"
    show palmierproxy2 flirt cling
    "伊瓦尔扭转了你的头。你被迫看着熟悉的身影从地面升起。"
    if "companion" in my_events:
        scene dande with dissolve
        if "companion" in quil_events:
            show tom_flower at right with dissolve:
                zoom 0.44
                yoffset 190
            show red_flower at left with dissolve:
                zoom 0.48
                yoffset 330
            show side_p g at pic
            mc "阿什姆...塞恩。"    
            hide side_p
        elif "companion" in tom_events:
            show quil_flower at right with dissolve:
                zoom 0.42
                yoffset 190
            show red_flower at left with dissolve:
                zoom 0.48
                yoffset 330
            show side_p g at pic
            mc "奎尔...塞恩。"    
            hide side_p
        elif "companion" in red_events:
            show tom_flower at right with dissolve:
                zoom 0.44
                yoffset 190
            show quil_flower at left with dissolve:
                zoom 0.42
                yoffset 200
            show side_p g at pic
            mc "奎尔...阿什姆。"
            hide side_p
        else:
            show tom_flower at right with dissolve:
                zoom 0.44
                yoffset 190
            show red_flower at left with dissolve:
                zoom 0.48
                yoffset 330
            show quil_flower at center with dissolve:
                zoom 0.42
                yoffset 200
            show side_p g at pic
            mc "奎尔...阿什姆...塞恩。"
            hide side_p
    else:
        scene dande with dissolve
        show tom_flower at right with dissolve:
            zoom 0.44
            yoffset 190
        show red_flower at left with dissolve:
            zoom 0.48
            yoffset 330
        show quil_flower at center with dissolve:
            zoom 0.42
            yoffset 200
        show side_p g at pic
        mc "奎尔...阿什姆...塞恩。"
        hide side_p
    scene dande with dissolve
    show croissant flinch flower at center with dissolve:
        yoffset 500
    show side_p k at pic
    mc "菲亚！！！" with vpunch
    hide side_p
    fia apa "那个声音...是你吗，[kk]？"
    if girl:
        show palmierproxy jln pissed at left with dissolve:
            yoffset 40
    else:
        show palmierproxy jln pissed at left with dissolve:
            yoffset 100
    if girl:
        show palmierproxy2 dobel flirt mivar at right with dissolve:
            yoffset 40
            xzoom -1.0
    else:
        show palmierproxy2 dobel flirt mivar at right with dissolve:
            yoffset 100
    mc ow sweat frusta "什么——"
    mk malu sigh "我特意让你妹妹的感官麻痹得最彻底。"
    mk flirt -sigh "别担心，她对那些从眼窝里长出的花蕾毫无感觉。"
    mk mock cling "在她的脑海里，这一切只是一个傻傻的小梦而已。"
    mc ew tanya "为什么...为什么你要让我看这些？"
    mk mean cling "你不是说想知道真相吗？"
    mk flirt -cling "无论它有多可怕。"
    "你啜泣着，似乎无法强迫自己移动，思考。所有这些花朵，所有这些不死的身体。"
    mc ow frusta "这...这都是我的错！这是一场噩梦！"
    mk sigh "不，孩子，这是你的奖赏。这是我对你的感激，对所有巫师的救世主的感激。"
    mk happy cling "这是一份礼物。这是我们友谊和你明智选择的结果。"
    mc pissed shock "住手，你疯了！我不想再听了！醒来！醒来！"
    if girl:
        galleryunlock ivar_fend
        scene ivar_fend with flashbulb:
            truecenter zoom 1.0
            easein 2.0 truecenter zoom 0.75
    else:
        galleryunlock ivar_end
        scene ivar_end with flashbulb:
            truecenter zoom 1.0
            easein 2.0 truecenter zoom 0.5
    mk "哦，孩子，即使你醒来，也改变不了这片土地的命运。但如果这能让你心安，试着这样想吧。"
    mk "一个人的噩梦，只是另一个人的天堂。"
    $ mk = Character('[povname]', callback=name_callback, cb_name='mc', image='palmierproxy2')
    scene bg_black with wet
    show text "伊瓦尔的幸福结局：巫师的天堂" with dissolve
    $ achievement.grant("Achievement05_Ivar")
    init:
        $ achievement.register("Achievement05_Ivar")
        $ achievement.sync()
    $ achievement.sync()
    $ renpy.pause()
    show bg_black with dissolve
    jump bad_end_game