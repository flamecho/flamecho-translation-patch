
##############################################################################
## Currency display

# if your game doesn't use money, set this to False
define uses_gold = True

screen gold_count():

    frame xsize 200:
        align (.98,.04) padding (10,10)
        has hbox
        xfill True

        label _("金币")
        #add "money icon"

        text "{}" .format(gold) xalign 1.0 font "GradoGradooNF.ttf"

##############################################################################
## Inventory Screens

default selected_item = None

screen item_description(selling=False):

    frame xysize 1200, 56:
        align (.55,.86)
        padding (10,10,50,10)
        label _("描述") style "description_label" yanchor 24
        if selected_item is not None:
            $ thisitem = set_item(selected_item)
            text thisitem[3] offset (14,6) #info text
        elif selling:
            text _("选择一个物品售卖。") offset (14,6) #color "#8b8b8b"
        else:
            text _("选择一个物品以阅读描述。") offset (14,6) #color "#8b8b8b"

screen inventory(collection, selling=False):
    tag menu
    modal True
    
    if not selling:
        add "back.jpg"
        use navigation2
    else:
        add "book"
        use cal
        
    #for page navigation
    default first = 0
    default last = invgrid_x*invgrid_y
    default page = 1

    default sorted = False
    on "show" action SetVariable("selected_item", None)

    if uses_gold:
        use gold_count()

    # screen title
    

    style_prefix "inventory"

    # items
    use invgrid(collection, page, first, last)

    # page navigation
    hbox:
        xpos 692
        yalign .4
        spacing 532
        textbutton "<" ysize 256:
            sensitive first>0
            action [ Play ("test_one", "page.wav"),SetScreenVariable("first", first-invgrid_x*invgrid_y), SetScreenVariable("last", last-invgrid_x*invgrid_y),
            SetScreenVariable("page",page-1) ]
            hovered [ Play ("test_one", "type.wav")] #Jump("activequest")

        textbutton ">" ysize 256:
            sensitive len(collection)>last
            action [ Play ("test_one", "page.wav"),SetScreenVariable("first", first+invgrid_x*invgrid_y), SetScreenVariable("last", last+invgrid_x*invgrid_y),
            SetScreenVariable("page",page+1) ]
            hovered [ Play ("test_one", "type.wav")] #Jump("activequest")

    # sorting
    hbox:
        xpos 730
        yalign .15
        spacing 4
        style_prefix "sort"
        textbutton _("排序：") text_color "#feca20"
        if not sorted:
            imagebutton idle "gui/name_idle.png" hover "gui/name_hover.png" selected_idle "gui/name_s_hover.png" selected_hover "gui/name_s_hover.png" xpos 0 ypos 0 action [Function(collection.sort, key=sortbyname),Play ("test_one", "page.wav"), SetScreenVariable("sorted", True)] hovered [ Play ("test_one", "type.wav")] #Jump("activequest")
        else:
            imagebutton idle "gui/name_idle.png" hover "gui/name_hover.png" selected_idle "gui/name_s_hover.png" selected_hover "gui/name_s_hover.png" xpos 0 ypos 0 action [Function(collection.sort, key=sortbyname, reverse=True),Play ("test_one", "page.wav"), SetScreenVariable("sorted", False)] hovered [ Play ("test_one", "type.wav")] #Jump("activequest")
        if not sorted:
            imagebutton idle "gui/sort_idle.png" hover "gui/sort_hover.png" selected_idle "gui/sort_s_hover.png" selected_hover "gui/sort_s_hover.png" xpos 0 ypos 0 action [Function(collection.sort, key=sortbyprice), Play ("test_one", "page.wav"),SetScreenVariable("sorted", True)] hovered [ Play ("test_one", "type.wav")] #Jump("activequest")
        else:
            imagebutton idle "gui/sort_idle.png" hover "gui/sort_hover.png" selected_idle "gui/sort_s_hover.png" selected_hover "gui/sort_s_hover.png" xpos 0 ypos 0 action [Function(collection.sort, key=sortbyprice, reverse=True),Play ("test_one", "page.wav"), SetScreenVariable("sorted", False)] hovered [ Play ("test_one", "type.wav")] #Jump("activequest")
        #textbutton _("名称"):
        #    if not sorted:
        #        action [Function(collection.sort, key=sortbyname), SetScreenVariable("sorted", True)]
        #    else:
        #        action [Function(collection.sort, key=sortbyname, reverse=True), SetScreenVariable("sorted", False)]
        #####IMAGE
        
        ##############
        #if uses_gold:
        #    textbutton _("价格"):
        #        if not sorted:
        #            action [Function(collection.sort, key=sortbyprice), SetScreenVariable("sorted", True)]
        #        else:
        #            action [Function(collection.sort, key=sortbyprice, reverse=True), SetScreenVariable("sorted", False)]

        ## INSERT SORTING CATEGORIES HERE ##

    # item details, appears once you click an item
    if selected_item is not None:
        $ thisitem = InvItem(*set_item(selected_item))
        if selling:
            frame xysize 1270, 180:
                align (.6,.95)
                padding (10,10,50,10)
                label _("物品详细") style "description_label" yanchor 24
                label thisitem.name xalign 0.17 yalign 0.23
                vbox pos (30, 20):
                    #spacing 5

                    hbox ysize 96:
                        add thisitem.image at zoomx(1.5)

                        hbox xsize 900:
                            yalign 0.1 xfill False

                            text "x {}" .format(collection.count(thisitem.id)) xalign 0 font "GradoGradooNF.ttf"
                            
                            if uses_gold and thisitem.value > 0:
                                hbox xsize 100:
                                    xalign 0.9
                                    text _("价格：") font "GradoGradooNF.ttf"
                                    text " {}" .format(int(thisitem.value/2)) font "GradoGradooNF.ttf"
                    
                    hbox xsize 1260:
                        align (.5,.0)
                        label thisitem.info style "smaller_text"
                ## !! IMPORTANT !! you need the buying screen from shop-screens.rpy for these buttons to work!
                vbox:
                    align (.9,.2)
                    style_group "sort"
                    if selling and thisitem.id in jual_ikan2:
                        textbutton _("售出") action ShowTransient("buying", whichitem=thisitem, howmuch=thisitem.value, selling=True)
                    #else:
                    #    textbutton _("TOSS") action ShowTransient("buying", whichitem=thisitem, howmuch=0)
                # shop-free alternative toss button:
                    #textbutton _("TOSS") action [Function(thisitem.toss, 1), SetVariable("selected_item", None)]
        else:
            frame xysize 1302, 200:
                xalign .6 yalign 0.98
                padding (10,10)

                label _("物品详细") style "description_label" yanchor 24

                vbox pos (30, 20):
                    spacing 5

                    hbox ysize 96:
                        add thisitem.image at zoomx(2)

                        hbox xsize 260:
                            yalign 1.0 xfill True
                            text "x {}" .format(collection.count(thisitem.id)) xalign 0 font "GradoGradooNF.ttf"

                            if uses_gold and thisitem.value > 0:
                                hbox xsize 100:
                                    xalign 0.5
                                    text _("价格：") font "GradoGradooNF.ttf"
                                    text " {}" .format(int(thisitem.value/2)) font "GradoGradooNF.ttf"
                    if not selling:
                        hbox xsize 1260:
                            label thisitem.info style "smaller_text"

           
    if selling:
        label _("市场") style "special_label" align (.4,.075)
    else:
        #label _("背包") style "special_label" yanchor 31
        label _("背包") style "special_label" align (.4,.075)
    #use item_description(selling) #berubah

    textbutton _("返回") action Return() style "return_button" yalign .98 hovered [ Play ("test_one", "type.wav")] #Jump("activequest")


style description_label_text:
    size gui.notify_text_size
    color "#feca20"
    outlines [(2,"#401a07",0,0)]
    bold True
style inventory_button:
    idle_background "#1B243B"
    hover_background "#73747F"
    xpadding 12
style inventory_button_text:
    idle_color "#f9c41f"
    hover_color "#f9c41f"

style sort_button is inventory_button
style sort_button_text:
    idle_color "#f9c41f"

##############################################################################
## Inventory Grid

# change your icon size here
define itemslot_xysize = (52,52)

# default grid shows 50 items
# you can change the number of rows and columns here
define invgrid_x = 10
define invgrid_y = 10

screen invgrid(collection, page, first, last, selling=False):

    frame:
        style "invgrid_frame"
        #label _("背包") style "special_label" yanchor 31

        # display the item's name when hovering
        $ tooltip = GetTooltip()
        if tooltip:
            label "[tooltip!t]" pos (40,20) yalign .96

        grid invgrid_x invgrid_y:
            align (.5,.5)
            # item buttons
            for item in collection[first:last]:
                if selected_item is not None:
                    $ thisitem = InvItem(*set_item(selected_item))

                button xysize itemslot_xysize:
                    style "itemslot_button"
                    add set_item(item)[1] #shows item image
                    tooltip set_item(item)[0] #shows item name

                    if selected_item==item:
                        if selling:
                            action ShowTransient("buying", whichitem=thisitem, howmuch=thisitem.value)
                        else:
                            action NullAction()
                    else:
                        action SetVariable("selected_item", item)
                    hovered [ Play ("test_one", "type.wav")] #Jump("activequest")
            #fill in the rest of the grid with blank squares
            for i in range(len(collection[first:last]), invgrid_x*invgrid_y):
                frame:
                    style "slot"

        text _("第 [page] 页") color gui.idle_color align (.96,.96) font "GradoGradooNF.ttf"

style invo_frame2:
    xysize (658,740)
    align (.6,.3)
    xoffset -80
style invgrid_frame:
    xysize (658,740)
    align (.6,.3)
    xoffset -80
style slot:
    background "empty_item"
    xysize itemslot_xysize
    xalign .5
style itemslot_button:
    background "[prefix_]item"
    padding (2,2)
    margin (0,0)
    size_group "inv"
    focus_mask True
style hist_text:
    color "#FFFEB6"
    outlines [(2,"#5D310C",0,0)]
style item_text:
    color "#FFF"
    outlines [(3,"#c36c96",0,0)]
    hover_outlines [(3,"#D5207A",0,0)]
style item_button_text:
    idle_color "#e9c62e"
style item_button:
    xsize 540
    ysize 52
    idle_background "#ffffee"
    hover_background "#1d2e56"

screen reward(itemdrop, get=True):
    zorder 100

    vbox at reward_appear:
        align (.5,.28)
        frame:
            add itemdrop at zoomx(2)
        if get:
            text "GET!" xalign .5 size 36

transform reward_appear:
    on show:
        alpha 0 yanchor -20
        easein_circ .5 alpha 1.0 yanchor 0
    on hide:
        linear .2 alpha 0.0 yanchor 10

transform zoomx(x):
    zoom x
    nearest True

##############################################################################
## styles used for multiple screens

style special_label_text:
    size gui.special_label_text_size
    bold True
    color "#003366"
    outlines [(3,"#f9c41f",2,2),(2,"#FFFF90",0,0)]
style special_small_label_text:
    bold True
    outlines [(3,"#f9c41f",2,2),(2,"#FFFF90",0,0)]
    color "#003366"
style special_small_frame:
    background None
    xfill True

style offset_return_button:
    idle_background Frame("gui/button/choice_idle_background.png",100,5)
    hover_background Frame("gui/button/choice_hover_background.png",100,5)
    padding (100,5)
    xsize 340
    xoffset -80
style offset_return_button_text is choice_button_text:
    xalign 0

style go_button:
    idle_background "#1B243B"
    hover_background "#73747F"
    insensitive_background "#1B243B"
    xysize (500, 100)
    align (.76,.9)
style go_button_text:
    size gui.special_label_text_size
    bold True
    xalign .5
    idle_color "#feca20"
    hover_color "#feca20"
    hover_outlines [(3,"#5c3604",1,1)]

style making_frame:
    xysize (500, 400)
    align (.45,.5)
    padding (30,30)
style making_button is go_button:
    xysize (400, 100)
    align (.5,.5)
style making_button_text is go_button_text


## move this to gui.rpy if you want
init -2:
    define gui.special_label_text_size = 32
##
