##############################################################################
# Quest class

init -2 python:
    class QuestItem(store.object):
        def __init__(self, name, id, client, icon, info, info2, item, count, reward=0): #list new properties up here, too!
            self.name = name #quest name
            self.id = id #string to be used as a codename
        #!! IMPORTANT !! don't change the order of anything above this line!
            self.client = client #quest-giver
            self.icon = icon #quest-giver face
            self.info = info #initial description
            self.info2 = info2 #completed description
            self.item = item #required item
            self.count = count #required amount
            ## INSERT REQUIRED PROPERTIES HERE ##
            self.reward = InvItem(*set_item(item)).value*count #earn money for completing it
            ## INSERT OPTIONAL PROPERTIES HERE ##

        ## QUEST FUNCTIONS

        # exchange quest item for gold, move quest from active list to completed
        def turn_in(self):
            global gold

            amount = self.count
            while amount>0:
                inv.remove(self.item)
                amount -= 1

            gold += self.reward

            active_quests.remove(self.id)
            completed_quests.insert(0, self.id)

        # checks if you have the required items to complete the quest
        def has_items(self):
            if inv.count(self.item) >= self.count:
                return True
            return False

##############################################################################
# more functions! (not part of QuestItem)

    # turn the quest tuple into the quest object
    def set_quest(self):

        for i in all_quests:
            if self==i[1]:
                return i

    # checks whether quest has been added/fulfilled before or not
    def new_quest(self):
        if self not in completed_quests:
            if self in active_quests:
                return False
            else:
                return True
        return False

    #add only when it's new
    def add_new_quest(self):
        if new_quest(self):
            new_quests.append(self)

##############################################################################
# QUEST DEFINITIONS

define q_sugar1 = (_("给英克威尔的墨水"), "sugar1", _("奎尔"), "icon genoise",
    _("需要一些补给，给我带两瓶符文墨水。\n\n奖励：4金币"),
    _("谢谢你，亲爱的。我一定会好好利用它，无论是在卧室内外<3。"),
    "item_lead", 2 )

define q_sucker3 = (_("猫咪走失！"), "sucker3", _("没收到通知"), "icon genoise",
    _("我的猫丢了！请，请，请帮帮忙！我需要有人在神父或修女发现之前找到她。我不知道我们不允许带宠物！\n\n奖励：100金币"),
    _("非常感谢！我一定会在神父发现之前把她送回父母那里！"),
    "item_cat", 1 )

define q_blood1 = (_("需要血液！"), "blood1", _("我"), "icon syrupfan",
    _("我需要为塞恩找些血，也许图书馆或迪特里希先生那里有。\n\n奖励：50金币"),
    _("谢谢你！如果你有空的话，我们去个好地方吧，我请客！"),
    "item_plasma", 1 )

define q_coco1 = (_("需要睡眠！"), "coco1", _("失眠者"), "icon syrupfan",
    _("我需要一些热可可来治疗我的失眠症！\n\n奖励：10金币"),
    _("终于睡着了，谢谢你！"),
    "item_coco", 1 )

define q_letter1 = (_("错误的告白！"), "letter1", _("陷入爱河"), "icon syrupfan",
    _("我因为打赌向校长办公室发了一封情书，请在他读到之前取回来！\n\n奖励：5金币"),
    _("好险啊，非常感谢你！我简直不敢相信你及时拿回来了！"),
    "item_letter", 1 )
define q_diari1 = (_("了解自己"), "diari1", _("我"), "icon genoise",
    _("你应该在手机上阅读你的分身的日记，以更好地了解他们。不过你首先需要知道密码，也许你应该四处打听一下。"),
    _("阅读只是让我产生了更多的问题而不是答案。尽管如此，我确实感觉我更了解我的分身了。"),
    "item_diary", 1 )

define q_kissu1 = (_("亲吻奎尔。"), "kissu1", _("迪特里希"), "icon syrupfan",
    _("迪特里希要求你和奎尔接吻的照片，用于他的赌局。问题是，你要怎么拿到呢？\n\n奖励：250金币"),
    _("干得好！英克威尔小子看起来不太高兴，但那是你的问题，不是我的。"),
    "item_poto", 1 )

define q_daddy1 = (_("普里姆爸爸"), "daddy1", _("普里姆"), "icon syrupfan",
    _("我觉得普里姆的父亲范德拉尔可能与梅扎有某种关系。我应该试着在俱乐部里找他。也许我能把他带回家。\n\n奖励：20金币"),
    _("谢谢你！我不知道我该作何感想...希望这能给我一些解脱。"),
    "item_slip", 1 )

define q_nina1 = (_("带着爱"), "nina1", _("妮娜"), "icon syrupfan",
    _("妮娜想让我把她的情书送给当地的花店男孩。希望他们能成功。\n\n奖励：5金币"),
    _("哦，我迫不及待想看到他的回复！"),
    "item_reply", 1 )
define q_nina2 = (_("甜蜜的悲伤"), "nina2", _("科夫"), "icon syrupfan",
    _("我想用自制蛋糕温柔地拒绝妮娜。可惜，我不太会烘焙。你能帮我做吗？\n\n奖励：16金币"),
    _("谢谢你的帮助，我会亲自去见她。她值得这样的对待。"),
    "item_cake", 1 )
define q_nina3 = (_("瓶装爱情"), "nina3", _("妮娜"), "icon genoise",
    _("如果科夫不想要我，那我就让他想要我！\n\n奖励：90金币"),
    _("我们现在在一起了！一切都很美好。有空来看看我们吧！"),
    "item_asmo", 1 )

define q_pic5 = (_("猫咪照片"), "pic5", _("维尔科娃"), "icon syrupfan",
    _("试着给你找到的猫咪一条鱼，然后为维尔科娃女士拍张照片。\n\n奖励：1800金币"),
    _("你有一个不错的收藏。我一定会好好欣赏的。"),
    "item_picat", 6 )

define q_stag1 = (_("猎鹿"), "stag1", _("怪人"), "icon genoise",
    _("咖啡馆里的怪人一直在嘟囔着渡鸦鹿的毛发。凯普勒是一只渡鸦鹿。也许你可以想办法弄到他的毛发。\n\n奖励：400金币"),
    _("我一定会为你的服务支付报酬。非常感谢。"),
    "item_hair", 1 )

define q_map1 = (_("寻找罪魁祸首"), "map1", _("开普勒"), "icon genoise",
    _("找出在地图上涂鸦的人。从他们的涂鸦中，你可以猜到这个人对吸血鬼并不友好。\n\n奖励：25金币"),
    _("伊格尼亚女巫学院不是种族主义者和仇视吸血鬼的杂种待的地方。我会适当惩罚这个年轻人。"),
    "item_culprit", 1 )

define q_ctul1 = (_("回应克苏鲁"), "ctul1", _("瘾君子学生"), "icon genoise",
    _("一个瘾君子想要满足他的瘾头。你本不打算给他，但这种药水本身可能会让你看到这整个穿越维度的破事最后会发生什么。为什么不至少尝一口呢？"),
    _("你的存在无论如何都会终结这个世界。也许从一开始就不要参与进来才是最好的。"),
    "item_vita2", 1 )

define q_boner1 = (_("欲望消失！"), "boner1", _("梅洛蒂"), "icon syrupfan",
    _("梅洛蒂对她的分手感到非常苦涩。一剂\"欲望消除剂\"可能会有帮助...或者类似的东西。\n\n奖励：60金币"),
    _("希望伊米尔和西尔贡的爱情生活没有受到梅洛蒂的恶作剧太大影响。有空的时候为什么不问问开普勒先生最新情况呢？"),
    "item_boner", 1 )

define q_fish2 = (_("寻找尼莫"), "fish2", _("马林"), "icon syrupfan",
    _("需要为马林的魔药作业抓两条小丑鱼。\n\n奖励：120金币"),
    _("再次感谢你的帮助，你真是个钓鱼高手！"),
    "item_clown", 2 )
define q_vits1 = (_("嗑药！"), "vits1", _("奇奇亚小子"), "icon syrupfan",
    _("我需要一些维他命补充剂来应对与奇奇亚狼队的大赛。这些肌肉需要蛋白质！\n\n奖励：40金币"),
    _("你的服务永远不会被遗忘！我的身体处于巅峰状态，胜利现在是必然的。"),
    "item_vita", 1 )

define q_cd1 = (_("羞耻之路"), "cd1", _("教堂男子"), "icon syrupfan",
    _("一个男人想要拿回他一夜情对象的内裤。你可以帮他拿回来，或者把它们交给女孩们随意处置。\n\n奖励：0金币，但你可能会得到一件物品作为替代。"),
    _("你希望最后一切都能圆满解决。如果你把内裤还给他，他已经在教堂准备了一份奖励给你。"),
    "item_cd", 1 )

define q_ice1 = (_("模仿冰之王子"), "ice1", _("英格丽"), "icon genoise",
    _("给英格丽弄一块冰晶，这样她就可以开始试验一种叫做\"洛基之霜\"的药水。\n\n奖励：99金币"),
    _("谢谢你的冰晶。然而，制成的药水还不够冷。人鱼之泪可能是完美的解决方案。几天后再来吧。"),
    "item_ice", 1 )

define q_fire1 = (_("让火焰燃起！"), "fire1", _("吉尼维"), "icon genoise",
    _("在血骑士抓到我之前，我宁愿把整个学校烧掉！\n\n奖励：300金币"),
    _("我会把这个随身携带，别担心，烟花表演开始前我会给你发短信的！"),
    "item_starter", 1 )

define q_sleep1 = (_("夜间漫游"), "no_sleep1", _("杰米"), "icon syrupfan",
    _("另一个学生可能对你正在调查的那座墓有线索。帮忙可能是个好主意。\n\n奖励：150金币"),
    _("那个人说他还是睡着了，不小心掉进了水里，但这似乎正是你需要做的，以获得进入墓穴的机会。没有朋友陪同可能会很危险。"),
    "item_oren", 1 )

define q_ink1 = (_("墨水替代品"), "octo3", _("莱斯利"), "icon genoise",
    _("由于墨水短缺，我在考虑制作墨水替代品。我需要3只章鱼来进行实验。\n\n奖励：300金币"),
    _("失败了，但我可能有了新的发现。"),
    "item_octo", 3 )
define q_ink2 = (_("墨水替代品2"), "angel2", _("莱斯利"), "icon genoise",
    _("再次尝试制作墨水替代品，这次我要用天使鱼试试。\n\n奖励：1000金币"),
    _("又失败了，但如果你把这些原料和普通墨水混合，它们会制成更高质量的墨水。"),
    "item_angel", 2 )
define q_ghost1 = (_("过敏消除！"), "ghost1", _("过敏症"), "icon syrupfan",
    _("活死人药水应该能帮助我缓解花粉过敏！请给我带一瓶来！\n\n奖励：65金币"),
    _("我又能呼吸了！谢谢你！"),
    "item_ghost", 1 )
define q_slep1 = (_("为阿什姆召唤天使！"), "slep1", _("你"), "icon genoise",
    _("阿什姆需要一条神仙鱼来制作隐形墨水。如果你能为他提供一条，他可能会有时间陪你。"),
    _("虽然你无法说服阿什姆，但他确实为那条神仙鱼给了你500金币。"),
    "item_angel", 1 )
define q_permen1 = (_("坚持下去"), "candy1", _("教徒"), "icon syrupfan",
    _("奎尔和这个学生想为海德温制作一些甜点来安抚她。\n\n奖励：50金币"),
    _("海德温女士看起来平静了些，奎尔似乎很高兴你帮忙。"),
    "item_sucker", 5 )
define q_truth1 = (_("海德温的谎言"), "truth1", _("神秘男子"), "icon syrupfan",
    _("有人怀疑海德温女士的布道是否真实，最好是制作一剂真言药水来查明真相。\n\n奖励：200金币"),
    _("尽管喝了药水，海德温女士的布道内容依然如故。她说的是实话，或者至少她自己相信那是真的。"),
    "item_truth", 1 )
define q_madyu1 = (_("开普勒的种子"), "madyu1", _("学生"), "icon syrupfan",
    _("一个学生需要从开普勒先生那里获得一些高质量的伤寒种子。如果你给他蜂蜜或者好的八卦，他可能会帮助你。\n\n奖励：8金币"),
    _("谢谢你的帮助。这肯定能帮我通过这门课！"),
    "item_beet", 1 )
########################
##############################################################################
# QUEST LIST

# (works the same as itemlist)
define all_quests = [
    q_sugar1,
    q_sucker3,
    q_blood1,
    q_coco1,
    q_letter1,
    q_diari1,
    q_kissu1,
    q_daddy1,
    q_nina1,
    q_nina2,
    q_nina3,
    q_stag1,
    q_map1,
    q_pic5,
    q_ctul1,
    q_boner1,
    q_fish2,
    q_vits1,
    q_ice1,
    q_fire1,
    q_sleep1,
    q_ink1,
    q_ink2,
    q_cd1,
    q_ghost1,
    q_slep1,
    q_permen1,
    q_truth1,
    q_madyu1
    ]
