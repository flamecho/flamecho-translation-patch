init offset = -1

################################################################################
## QUESTS

screen quests(page=0):
    tag menu
    add "back.jpg"
    use navigation2
    use gold_count()
    #selects the first quest in the list
    if len(active_quests) > 0 and page==0:
        default quest = QuestItem(*set_quest(active_quests[0]))
    elif page==1:
        default quest = QuestItem(*set_quest(completed_quests[0]))
    else:
        default quest = None

    frame:
        style "quest_outer_frame"
        has vbox
        style_prefix "quest"
        label _("任务") style "special_label" #yanchor 50

        null height 10

        hbox:
        ##QUEST SIDEBAR
            vbox:
                hbox xysize (380,40):
                    # navigate quest lists
                    imagebutton idle "gui/active_idle.png" hover "gui/active_hover.png" selected_idle "gui/active_s_hover.png" selected_hover "gui/active_s_hover.png" xpos 0 ypos 0 action [Play ("test_one", "page.wav"),ShowMenu('quests', page=0)] selected page==0 hovered [ Play ("test_one", "type.wav")] #Jump("activequest")
                    #textbutton _("Active") xsize 190 action Jump("activequest") selected page==0
                    imagebutton idle "gui/complete_idle.png" hover "gui/complete_hover.png" insensitive "gui/complete_insensitive.png" selected_idle "gui/complete_s_hover.png" selected_hover "gui/complete_s_hover.png" xpos 0 ypos 0 action [Play ("test_one", "page.wav"),ShowMenu('quests', page =1)] hovered [ Play ("test_one", "type.wav")] selected page==1 sensitive len(completed_quests) > 0
                    #textbutton _("Complete") xsize 190 action Jump("completedquest") selected page==1 sensitive len(completed_quests) > 0

                frame xysize 400, 450:
                    # quest list

                    vpgrid style_prefix "quest":
                        cols 1 mousewheel True draggable True scrollbars "vertical"
                        pagekeys True
                        yfill True

                        # make an empty button if there are no quests in the list
                        if quest is None:
                            button

                        # active quest buttons
                        if page==0:
                            for i in active_quests:
                                $ thisquest = QuestItem(*set_quest(i))
                                button:
                                    action SetScreenVariable("quest", thisquest)
                                    selected quest.id==thisquest.id
                                    selected_foreground "quest_selected" # marker for the currently selected quest
                                    if thisquest.has_items():
                                        foreground "quest_hasitems" # marker for if you can complete it

                                    text thisquest.name xoffset 24
                        # completed quest buttons
                        else:
                            for i in completed_quests:
                                $ thisquest = QuestItem(*set_quest(i))
                                button:
                                    action SetScreenVariable("quest", thisquest)
                                    selected quest.id==thisquest.id
                                    selected_foreground "quest_selected"
                                    text thisquest.name xoffset 24
                                    # all the same except without the hasitems marker

        ##INFO PAGE
            frame:
                style "quest_content_frame"

                if quest is None:
                    if len(completed_quests) > 0:
                        text _("已完成全部任务！") yalign .1
                    else:
                        text _("暂无新任务！") yalign .1
                else:
                    use questinfo(quest, page)

    #use gold_count()

    # you can change the style at the bottom of item-screens.rpy

    textbutton _("返回") yalign .98 action Return() style "return_button" hovered [ Play ("test_one", "type.wav")] #Jump("activequest")

##copy of craft styles
style quest_outer_frame:
    align (.65,.5)
    padding (40,20)
style quest_detail_frame:
    background None
    ysize 150
    xpadding 18
style quest_content_frame:
    background None
    xsize 700
    ysize 560
    ymargin 10
    padding (30,24)
##

## copy of recipe styles
style quest_button:
    xfill True
    ysize 48
    padding (0,0)
    idle_background "#1B243B"
    hover_background "#73747F"
    selected_idle_background "#FFFFDE"
    selected_hover_background "#73747F"
style quest_text:
    xoffset 48
    yalign .5
    color "#F9C41F"
    outlines [(2,"#4A2A0F")]
style quest_label_text:
    bold True
    size 36
    color "#FFD23E"


style smaller_text:
    size 24
    color "#FFD23E"
style quest_small_label_text:
    size gui.notify_text_size
    color "#FFD23E"
##
style quest_button_text:
    bold True
    xalign .5

style questitem_button is itemslot_button
style questitem_text:
    yalign .5
    size 24
    color "#FFD23E"
    outlines [(2,"#4A2A0F")]

screen questinfo(quest, page):

    # show a little stamp for completed quests
    if page==1:
        add "completedquest" align (.9,.9)
    vbox:
        spacing 8
        # quest name and character icon
        frame:
            style_group "special_small"
            has hbox
            add quest.icon

            null width 10
            label quest.name yalign .5

        # flavor text
        frame:
            xfill True
            has vbox
            label _("    笔记：") style "quest_small_label"
            frame:
                style_prefix "quest_detail"
                if page==0:
                    text quest.info style "smaller_text"
                else:
                    text quest.info2 style "smaller_text"

                text "- [quest.client!t]" style "smaller_text" align (.9,.9)

        # quest details
        hbox:
            xfill True
            vbox:
                if page==0:
                    label _("需求：") style "craft_small_label"
                else:
                    label _("提交：") style "craft_small_label"
                hbox:
                    xalign .5
                    style_prefix "questitem"
                    spacing 5

                    $ tooltip = GetTooltip()
                    $ whichitem = InvItem(*set_item(quest.item))

                    button:
                        add whichitem.image
                        tooltip inv.count(whichitem.id)
                        action NullAction()
                        sensitive page==0
                        activate_sound None

                    if tooltip or tooltip==0:
                        text _("持有： [tooltip]")
                    else:
                        text whichitem.name font "GradoGradooNF.ttf"
                        text " x [quest.count]" font "GradoGradooNF.ttf"

            #if page==0:
            #    vbox:
            #        xalign 1.0
            #        xsize 180
            #        label _("Reward:") style "craft_small_label"
            #        hbox:
            #            ysize 52 #match item slot
            #            text "[quest.reward] " size 24 font "GradoGradooNF.ttf"
            #            text _("Gold") size 24 font "GradoGradooNF.ttf"

    # for active quests
    if page==0:
        imagebutton:
            idle "gui/turn_idle.png"
            hover "gui/turn_hover.png"
            insensitive "gui/turn_insensitive.png"
            sensitive quest.has_items()
            xpos 250 ypos 360
            action [ Function(quest.turn_in), Play ("test_one", "page.wav"),
            Show("completedtask", message=_("任务完成！")),
            ShowMenu('quests', page =1)] selected page==1
        #textbutton _("Turn In"):
        #    style "go_button"
        #    sensitive quest.has_items()
        #    action [ Function(quest.turn_in),
        #    Show("completedtask", message=_("任务完成！")),
        #    Jump("completedquest") ]

################################################################################
## Quest complete notif

screen completedtask(message):
    zorder 99
    on "show" action Play("sound", "sfx/btn16.mp3") ##add a cute sound!

    frame:
        ysize 20 yalign .5
        background Solid("#ffff90") #change line color here #445d8a
        at lineappear
    hbox:
        align (.5,.5)
        add Text(message, slow=True, slow_cps=30, size=50, color="#f5cd28", outlines=[(6,"#fff",0,0),(3, "#803f09",0,0)])
        # change text properties here^

    # hide screen after a second
    timer 1.2 action Hide("completedtask", transition=Dissolve(.5))

transform lineappear:
    yzoom 0
    easein .25 yzoom 1.4
    easeout .15 yzoom 1.0
    pause 1.2
    easeout .3 yzoom 0

transform horzappear:
    xalign 0.15 yalign 1.0
    on show:
        xzoom 0
        easein .15 xzoom 1.0
    on hide:
        xzoom 1.0
        easeout .15 xzoom 0.0
