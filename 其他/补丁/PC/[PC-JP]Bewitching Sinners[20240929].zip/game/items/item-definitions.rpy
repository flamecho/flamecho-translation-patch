##############################################################################
# InvItem class

init -2 python:
    class InvItem(store.object):
        def __init__(self, name, image, value, info, id, cost=[]): #if you add any properties, list them up here, too!
            self.name = name #item name (as seen by the player)
            self.image = image #item art
            self.value = int(value) #market price
            self.info = info #item description
            self.id = id #string to be used as a codename
        #!! IMPORTANT !! don't change the order of anything above this line!
            ## INSERT REQUIRED PROPERTIES HERE ##
            self.cost = cost #list of ingredients, only necessary for craftable items
            ## INSERT OPTIONAL PROPERTIES HERE ##

    ## INVITEM FUNCTIONS

        # add item to the list of seen items
        def see(self):
            if self.id not in seen_items:
                seen_items.append(self.id)

        # add crafting recipe to the list of seen recipes
        def see_recipe(self):
            if self.id not in seen_recipes:
                seen_recipes.append(self.id)

        # see the item and add it to your inventory
        def pickup(self, amount=1):
            self.see()
            while amount>0:
                inv.append(self.id)
                amount -= 1

        # discard the item from your inventory
        def toss(self, amount):
            while amount>0:
                inv.remove(self.id)
                amount -= 1

        # exchange gold for an item
        def buy(self, amount):
            global gold

            self.see()

            gold -= self.value*amount
            while amount>0:
                inv.append(self.id)
                amount -=1

        # exchange an item for gold
        def sell(self, amount):
            global gold

            gold += int(self.value*amount/2)
            self.toss(amount)

        # craft an item
        def make(self, amount):

            self.see()

            while amount>0:
                for i in self.cost:
                    inv.remove(i)
                inv.append(self.id)
                made_recipes.append(self.id)
                amount -=1

        #for shop screen--checks that you can afford to buy 1 of any item
        def check_price(self):
            if self.value <= gold:
                return True
            return False

##############################################################################
# more functions! (not part of InvItem)

    # turns the item tuple into the item object
    def set_item(self):

        for i in itemlist:
            if self==i[4]: #checks the id--this is why you can't change the order!!
                return i

    #inventory sorting
    def sortbyname(i):
        thisitem = InvItem(*set_item(i))
        return thisitem.name

    def sortbyprice(i):
        thisitem = InvItem(*set_item(i))
        return thisitem.value

    # for crafting-screens.rpy--checks that you are able to craft at least 1 of the item
    def check_ingredients(craftitem):

        check = 0
        for i in craftitem.cost:
            if inv.count(i) > 0:
                check += 1

        if check == len(craftitem.cost):
            return True

        return False

    # used to check if you have battle items in battle-screens.rpy--but you can make other lists to check for too!
    def check_inv_for(itemtype):
        for i in itemtype:
            if inv.count(i) > 0:
                return True

##############################################################################
# ITEM DEFINITIONS

# INGREDIENTS
define item_water = (_("圣水"), "item water", 2,
    _("炼金术和制作药水的基本成分。"), "item_water")

define item_paper = (_("纸"), "item paper", 1,
    _("就是普通的纸。"), "item_paper")

define item_sugar = (_("糖"), "item sugar", 3,
    _("吃太多对牙齿不好。"), "item_sugar")

define item_beet = (_("台风"), "item beet", 8,
    _("质地奇特的水果（？）"), "item_beet")

define item_beetK = (_("开普勒台风"), "item beet", 8,
    _("开普勒的台风种子。"), "item_beetK")

define item_bones = (_("骨头"), "item bones", 120,
    _("看起来像人骨……他从哪里弄来的？"), "item_bones")

define item_blood = (_("独角兽之血"), "item blood", 250,
    _("独角兽之血。只有邪恶之人才敢饮用。"), "item_blood")

define item_human = (_("人血"), "item human", 100,
    _("你的血，O型阳性。"), "item_human")

define item_siren = (_("海妖之血"), "item siren", 180,
    _("海妖之血，吸血鬼的美味。"), "item_siren")

define item_light = (_("诅咒之书"), "item light_book", 250,
    _("诅咒和药水之书。有些温和，有些则不然。"), "item_light")

define item_dark = (_("悲伤之书"), "item dark_book", 550,
    _("不可饶恕的诅咒和药水之书。极其罕见。"), "item_dark")

define item_root = (_("死亡之根"), "item root", 10,
    _("一种常用于药水的有毒根茎。"), "item_root")

define item_vicus = (_("恐惧之草"), "item vicus", 5,
    _("恐惧之草，吸入其气味可能导致严重抑郁。"), "item_vicus")

define item_culprit = (_("罪犯"), "item culprit", 25,
    _("你要找的人。"), "item_culprit")

define item_weed = (_("大麻"), "item weed", 420,
    _("点燃它。"), "item_weed")

define item_ctulhu = (_("奇怪的遗物"), "item ctulhu", 2000,
    _("克苏鲁遗物。会导致严重幻觉或死亡，通常两者兼有。"), "item_ctulhu")

define item_oli = (_("奥利的遗物"), "item ctulhu", 5000,
    _("奥利凡德的遗物。能听到微弱的嗡嗡声。"), "item_oli")
define item_fang = (_("狼牙"), "item fang", 550,
    _("残忍地从幼年狼人身上提取。"), "item_fang")

define item_slip = (_("道歉信"), "item slip", 20,
    _("普里姆父亲的道歉信。"), "item_slip")

define item_poto = (_("亲吻照片"), "item poto", 250,
    _("你和奎尔亲吻的照片。"), "item_poto")

define item_green = (_("磷"), "item green", 10,
    _("高度易燃，常用于药水制作。"), "item_green")

define item_blue = (_("魔法粉末"), "item blue", 10,
    _("从仙子和森林精灵那里偷来的魔法粉末。"), "item_blue")

define item_bait = (_("鱼饵"), "item bait", 2,
    _("用于钓鱼的鱼饵。"), "item_bait")

define item_lead = (_("符文墨水"), "item lead", 2,
    _("混合了圣水的墨水，用于书写符文。"), "item_lead")

define item_fire = (_("凤凰叶"), "item fireleaf", 55,
    _("龙蛋最好的隔热材料。"), "item_fire")

define item_love = (_("爱情果实"), "item love", 69,
    _("欲望药剂的主要原料。"), "item_love")

define item_ice = (_("冰晶"), "item ice", 99,
    _("直接接触会导致冻伤。"), "item_ice")

define item_mushroom = (_("蘑菇"), "item mushroom", 20,
    _("森林中常见的野生蘑菇。"), "item_mushroom")

define item_mirror = (_("魔法镜"), "item mirror", 680,
    _("如同纳西索斯，凝视它的人会慢慢陷入疯狂。"), "item_mirror")

define item_yeast = (_("酵母"), "item scrub", 2,
    _("烤面包必需的原料。"), "item_yeast")

define item_egg = (_("鸡蛋"), "item egg", 4,
    _("先有鸡还是先有蛋？"), "item_egg")

define item_milk = (_("牛奶"), "item milk", 2,
    _("这是什么种类的奶？"), "item_milk")

define item_hair = (_("凯普勒的头发"), "item hair", 400,
    _("凯普勒的一缕头发。"), "item_hair")

define item_cocoa = (_("可可粉"), "item cocoa", 2,
    _("不加糖的话相当苦。"), "item_cocoa")

define item_wine = (_("葡萄酒"), "item wine", 40,
    _("来自邻村的葡萄酒。"), "item_wine")

define item_honey = (_("蜂蜜"), "item honey", 5,
    _("非常粘稠。给奎尔的注意事项：不要用于性行为！"), "item_honey")

define item_ham = (_("火腿"), "item ham", 6,
    _("从野猪身上猎获的。"), "item_ham")

define item_meat = (_("牛肉（？）"), "item meat", 3,
    _("当地肉类。是什么肉？我们不确定。"), "item_meat")

define item_fish = (_("蓝鲱鱼"), "item fish", 8,
    _("有一股强烈的刺鼻气味。"), "item_fish")

define item_eel = (_("鳗鱼"), "item eel", 40,
    _("又长又滑。"), "item_eel")

define item_clown = (_("小丑鱼"), "item clown", 60,
    _("是马林还是尼莫？"), "item_clown")

define item_jelly = (_("水母"), "item jelly", 300,
    _("它周围有一种奇怪的光芒？"), "item_jelly")

define item_octo = (_("章鱼"), "item octo", 100,
    _("小心避开它的吸盘。"), "item_octo")

define item_angel = (_("神仙鱼"), "item angel", 500,
    _("并不那么神圣。"), "item_angel")

define item_turtle = (_("海龟"), "item turtle", 40,
    _("一只圆滚滚的小海龟。"), "item_turtle")

define item_gem = (_("火焰宝石"), "item gem",777,
    _("轻触就能烧伤你"), "item_gem")

define item_ash = (_("先祖骨灰"), "item ash", 2,
    _("某人先祖的骨灰。"), "item_ash")

define item_quill = (_("羽毛笔"), "item quill", 1,
    _("他们真该在这里引进钢笔了。"), "item_quill")

define item_satire = (_("讽刺小说"), "item satire", 2,
    _("只适合那些不容易被冒犯的人。"), "item_satire")

define item_heat = (_("色情杂志"), "item heat", 3,
    _("绝对不适合工作场所！"), "item_heat")

define item_turq = (_("神秘之书"), "item turq", 5,
    _("神秘之处在于没人知道这本书到底讲的是什么。"), "item_turq")

define item_cook = (_("烹饪卷轴101"), "item cook", 5,
    _("食谱包括：猫粮、热可可、蜂蜜棒糖和面包。"), "item_cook")

define item_anc = (_("古老卷轴"), "item ancient", 1500,
    _("科尔亲笔书写的原始法术卷轴。"), "item_anc")

define item_bless = (_("祝福卷轴"), "item bless", 111,
    _("优质墨水和引火物的配方。"), "item_bless")

define item_handcuffs = (_("手铐"), "item cuffs", 18,
    _("给奎尔的便条：请不要再把你的性伴侣留在这些里面了。"), "item_handcuffs")

define item_cat = (_("走失的猫"), "item cat", 100,
    _("某人丢失的猫。"), "item_cat")

define item_picat = (_("猫咪照片"), "item cat", 300,
    _("一张猫的照片。"), "item_picat")

define item_diary = (_("\'你的\'日记"), "item diary", 0,
    _("你需要一个密码才能查看其内容。"), "item_diary")

define item_cd = (_("某人的内裤"), "item cd", 0,
    _("至少是干净的？"), "item_cd")

define item_kor = (_("血腥科尔"), "item kor", 2,
    _("佩纳制作的解药，味道糟糕。"), "item_kor")

define item_letter = (_("情书"), "item letter", 5,
    _("一封写得很糟糕的情书。"), "item_letter")

define item_reply = (_("回信"), "item letter", 5,
    _("一封善意的拒绝信。"), "item_reply")

define item_ylf = (_("伊尔夫的信"), "item letter", 5,
    _("伊尔夫的来信，你应该把它交给莱尔。"), "item_ylf")

define item_pin = (_("发夹"), "item pin", 1,
    _("一个小巧尖锐的剑形发夹。"), "item_pin")
# CRAFTABLE
define item_boner = (_("消欲剂"), "item boner", 60,
    _("在兴奋时会引起不适，并产生受害者裸体祖母的幻觉。"), "item_boner",
    ["item_ash", "item_yeast","item_fire"])

define item_cake = (_("蛋糕"), "item cake", 16,
    _("让他们吃蛋糕吧！"), "item_cake",
    ["item_sugar", "item_egg","item_milk"])

define item_starter = (_("引火物"), "item starter",300,
    _("引火物，常用于战斗或煽动全国性叛乱。"), "item_starter",
    ["item_fire", "item_gem","item_green"])

define item_bread = (_("面包"), "item bread", 18,
    _("新鲜出炉！"), "item_bread",
    ["item_yeast", "item_egg","item_milk"])

define item_coco = (_("热可可"), "item coco", 10,
    _("冬天喝最棒了。"), "item_coco",
    ["item_cocoa", "item_milk"])

define item_caramel = (_("蜂蜜棒糖"), "item caramel", 14,
    _("非常甜。光是看着就足以让你牙疼。"), "item_caramel",
    ["item_honey", "item_sugar"])

define item_catfood = (_("猫粮"), "item sucker", 22,
    _("由各种肉类制成的猫粮。"), "item_catfood",
    ["item_ham", "item_fish", "item_eel"])

define item_sucker = (_("普通糖果"), "item candy", 10,
    _("甜甜的糖果！"), "item_sucker",
    ["item_sugar", "item_paper"])

define item_plasma = (_("混合血液"), "item plasma", 50,
    _("人血还是动物血？最好别知道。"), "item_plasma",
    ["item_turtle", "item_meat", "item_ham"])

define item_obat = (_("血液治疗剂"), "item plasma", 500,
    _("可能治愈塞恩对你血液的痴迷。高度不稳定，别忘了加入你的血液！"), "item_obat",
    ["item_siren", "item_blood"])

define item_pop = (_("血液棒棒糖"), "item pop", 32,
    _("一团血液冻结成的小块岩糖。"), "item_pop",
    ["item_plasma", "item_sugar","item_water"])

define item_mm = (_("魔法蘑菇"), "item magic", 500,
    _("如果你在野外发现类似的东西并吃了它们，那么愿科尔保佑你。"), "item_mm",
    ["item_mushroom", "item_blue","item_weed"])

define item_cuffs = (_("魔法手铐"), "item cuff", 50,
    _("只有使用者的性伴侣才能取下它们。非常适合边缘控制。"), "item_cuffs",
    ["item_lead", "item_quill","item_handcuffs"])

define item_asmo = (_("阿斯莫迪亚"), "item fren", 90,
    _("阿斯莫迪亚，也被称为欲望药剂。以1963年被击败的欲望女巫命名。"), "item_asmo",
    ["item_love", "item_mm","item_honey"])

define item_oren = (_("不眠之夜"), "item oren", 150,
    _("如其名所示，你可能一周都睡不着觉。使用需自担风险。"), "item_oren",
    ["item_clown", "item_vicus","item_fire"])

define item_vita = (_("活力提升剂"), "item vita", 40,
    _("在床上、运动中、面对生死危险时的增强剂——无论哪种情况先来！"), "item_vita",
    ["item_sugar", "item_blue","item_milk"])

define item_vita2 = (_("克苏鲁的呼唤"), "item vita", 0,
    _("外观与活力提升相似，但实际上是一种令人幻觉连连的毒品。"), "item_vita2",
    ["item_weed", "item_ctulhu","item_fang"])

define item_ghost = (_("活死人"), "item ghost", 65,
    _("药剂效果持续6小时。用于性爱游戏可能导致69年监禁。"), "item_ghost",
    ["item_ash", "item_root","item_bones"])

define item_truth = (_("真言之饮"), "item truth", 200,
    _("真言之饮。自1848年以来一直引发尴尬和令人难堪的对话。"), "item_truth",
    ["item_wine","item_jelly","item_green"])

define item_ink = (_("优质墨水"), "item ink", 30,
    _("经过祝福的墨水，混合了各种成分以进一步增强其效力。"), "item_ink",
    ["item_lead", "item_angel", "item_octo"])

define item_up = (_("洛基之霜"), "item up", 330,
    _("一种强化版冰冻药剂。与优质墨水混合可用作科尔符文。"), "item_up",
    ["item_ice", "item_blue", "item_ink"])
##############################################################################
# ITEM LISTS

# ALL ITEMS (every single one!!)
define itemlist = [
    item_water,
    item_paper,
    item_beet,
    item_beetK,
    item_sugar,
    item_bones,
    item_oli,
    item_blood,
    item_human,
    item_siren,
    item_root,
    item_dark,
    item_light,
    item_vicus,
    item_weed,
    item_culprit,
    item_ctulhu,
    item_fang,
    item_green,
    item_blue,
    item_fire,
    item_love,
    item_ice,
    item_mushroom,
    item_mirror,
    item_yeast,
    item_kor,
    item_egg,
    item_milk,
    item_cocoa,
    item_wine,
    item_honey,
    item_diary,
    item_ham,
    item_meat,
    item_fish,
    item_eel,
    item_jelly,
    item_octo,
    item_slip,
    item_hair,
    item_poto,
    item_clown,
    item_turtle,
    item_angel,
    item_cake,
    item_bread,
    item_coco,
    item_ash,
    item_caramel,
    item_sucker,
    item_catfood,
    item_plasma,
    item_mm,
    item_gem,
    item_asmo,
    item_oren,
    item_vita,
    item_vita2,
    item_ghost,
    item_truth,
    item_starter,
    item_bait,
    item_lead,
    item_letter,
    item_reply,
    item_ylf,
    item_up,
    item_ink,
    item_quill,
    item_satire,
    item_heat,
    item_turq,
    item_anc,
    item_bless,
    item_cuffs,
    item_handcuffs,
    item_cook,
    item_cat,
    item_picat,
    item_boner,
    item_pop,
    item_pin,
    item_cd,
    item_obat
    ]

# all items that can be crafted
define allrecipes = [
    "item_cake",
    "item_bread",
    "item_coco",
    "item_mm",
    "item_caramel",
    "item_sucker",
    "item_catfood",
    "item_plasma",
    "item_asmo",
    "item_oren",
    "item_vita",
    "item_vita2",
    "item_ghost",
    "item_starter",
    "item_up",
    "item_truth",
    "item_ink",
    "item_cuffs",
    "item_boner",
    "item_pop",
    "item_obat"
    ]

# all items that can be used in battle
define battle_items = [
    "item_sucker",
    "item_cake",
    "item_bread",
    "item_coco",
    "item_caramel",
    "item_plasma",
    "item_ink",
    "item_catfood"
    ]
define plas_items = [
    "item_plasma"]
define blud_items = [
    "item_blood"]
define sir_items = [
    "item_siren"]
define cure_items = [
    "item_obat"]
define blood_items = [
    "item_plasma",
    "item_blood",
    "item_siren"
    ]

##FISH
define anc_items = [
    "item_bless"
]
define jual_ikan = [
    "item_clown",
    "item_angel",
    "item_jelly",
    "item_eel",
    "item_fish",
    "item_octo",
    "item_turtle"

]
define clown_items = [
    "item_clown"
    ]
define angel_items = [
    "item_angel"
    ]
define jelly_items = [
    "item_jelly"]
define culp_items = [
    "item_culprit"]
define eel_items = [
    "item_eel"
    ]
define fish_items = [
    "item_fish"
    ]
define octo_items = [
    "item_octo"
    ]
define recipe_items = [
    "item_cook"
    ]
define cd_items = [
    "item_cd"
    ]
define loot_items = [
    "item_pin"
    ]
define vit_items = [
    "item_vita"
    ]
define up_items = [
    "item_up"
    ]
define coco_items = [
    "item_coco"
    ]

define honey_items = [
    "item_honey"
    ]
define car_items = [
    "item_caramel"
    ]
define bread_items = [
    "item_bread"
    ]
define wine_items = [
    "item_wine"
    ]
define ctul_items = [
    "item_vita2"
    ]
define quill_items = [
    "item_quill"
    ]

define letter_items = [
    "item_letter"
    ]
define ink_items = [
    "item_lead"
    ]
define bait_items = [
    "item_bait"
    ]
define sucker_item = [
    "item_sucker"
    ]
define cat_items = [
    "item_catfood"
    ]
define luv_items = [
    "item_asmo"
    ]
define ylf_items = [
    "item_ylf"
    ]
define slip_items = [
    "item_slip"
    ]
define cuff_items = [
    "item_cuffs"
    ]
define handcuff_items = [
    "item_handcuffs"
    ]


define cake_items = [
    "item_cake"
    ]
define sat_items = [
    "item_satire"
    ]
define myst_items = [
    "item_turq"
    ]
define pop_items = [
    "item_pop"
    ]

define truth_items = [
    "item_truth"
    ]

define ghost_items = [
    "item_ghost"
    ]
## INSERT NEW RECIPE LISTS HERE ##

# for recipes screen
define recipelists = [ allrecipes, battle_items ]
define recipelist_names = [ _("All"), _("Gifts") ]
