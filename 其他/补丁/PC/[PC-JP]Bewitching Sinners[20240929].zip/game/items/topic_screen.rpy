##############################################################################
# Topic class

init python:
    class topik(store.object):
        def __init__(self, name, id, info): #if you add any properties, list them up here, too!
            self.name = name #item name (as seen by the player)
            self.id = id #string to be used as a codename
            self.info = info #item description



    ## INVITEM FUNCTIONS
    def set_topik(self):

        for i in topiklists:
            if self==i[1]: #checks the id--this is why you can't change the order!!
                return i

###SCREEN
screen topik_buku():
    tag menu
    modal True
    add "back.jpg"
    use navigation2
    use gold_count()
    style_prefix "craft"

    default page = 0
    default whichtopik = topik(*set_topik(topics[0]))

    frame:
        style "quest_outer_frame"
        has vbox
        label _("已知话题") style "special_label"

        null height 20

        hbox:
        ##RECIPE SIDEBAR
            vbox:
                #label _("Recipes")
                null height 10
                # recipe buttons
                frame:
                    xysize (400, 540)
                    use topiklist(whichtopik)

            null width 10

        ##RECIPE PAGE
            frame:
                style "craft_content_frame"
                use topikinfo(whichtopik)

    # you can change the style at the bottom of item-screens.rpy
    textbutton _("返回") action Return() style "return_button" yalign .98 hovered [ Play ("test_one", "type.wav")] #Jump("activequest")
screen topikinfo(whichtopik):
    # page to show item details of selected recipe
    vbox spacing 8:
        frame:
            style_group "special_small"
            has hbox
            xfill True
            label whichtopik.name


        #$ tooltip = GetTooltip()

        frame:
            background None
            xfill True
            has vbox
            #label _("Description:") style "craft_small_label"
            frame:
                background None
                text whichtopik.info style "making_text"
screen topiklist(whichtopik):
    # the actual list!
    vpgrid style_prefix "recipe":
        cols 1 yfill True
        draggable True mousewheel True pagekeys True
        scrollbars "vertical"

        for i in topics:
            if i in topics:
                $ thistopik = topik(*set_topik(i))

                # craftable items you know
                button:
                    action [ Play ("test_one", "type.wav"),SetScreenVariable("whichtopik", thistopik)]
                    selected whichtopik.id==thistopik.id
                    hovered [ Play ("test_one", "type.wav")] #Jump("activequest")
                    # adds marker for new recipes
                    add "bullet"
                    text thistopik.name

            # hide names of recipes you don't know
            else:
                button:
                    text _("????") color "#a7a7a7"

#####DAFTAR TOPIK
define t_monarchy = (_("吸血鬼王国"), "monarchy",
    _("从图书馆的涂鸦中看出。似乎有人对吸血鬼王国不太满意，为什么呢？"))
define t_soulmates = (_("灵魂伴侣"), "soulmates",
    _("这个世界似乎有灵魂绑定和灵魂伴侣系统。图书馆似乎没有提到人类对灵魂绑定有特别的偏好，也没有提到任何灵魂伴侣的复杂性。"))
define t_inkwell = (_("英克威尔家族的戏剧性事件"), "inkwell",
    _("人们似乎在大肆议论英克威尔家族的戏剧性事件。其中最主要的是奎尔的滥交行为和他的堂兄试图篡夺他作为继承人的地位。"))
define t_genetics = (_("英克威尔家族的基因"), "genetics",
    _("奎尔提到，他家族理想的基因构成是白发绿眼，而有缺陷的特征则是黑发异色瞳。我觉得我应该更深入地调查这个问题。"))
define t_shriek = (_("低语球"), "shriek",
    _("你在校长办公室触摸过的一个球体。不知道这是不是一个不祥之兆。"))
define t_bloodmoon = (_("血月"), "bloodmoon",
    _("从波比女士的课堂笔记中，你学到了这段话：血月将所有人团结在一起，即使是那些永远不应该被干扰的人。"))
define t_whore = (_("阿什姆的母亲"), "whore",
    _("其他孩子似乎在说阿什姆母亲的坏话。大多数人称她为妓女，为什么？"))
define t_leech = (_("水蛭"), "leech",
    _("失去理智的吸血鬼，对血液着迷。也许塞恩可以更详细地解释这个。"))
define t_jelly = (_("水母"), "jelly",
    _("在这个世界里，水母似乎会飞向天空。有人说这是人鱼与心爱的水手联系的方式。也有人说这是海巫在引诱她们的受害者。"))
define t_drakmar = (_("德拉克马尔女巫"), "drakmar",
    _("一个触发了你与阿什姆友谊的巫师，但代价是什么？"))
define t_choir = (_("合唱团"), "choir",
    _("菲亚在合唱团里不受欢迎，有些人因为她参与其中而完全避开合唱团。"))
define t_ctulhu = (_("噬梦者"), "ctulhu",
    _("在赫斯莫尔斯学院就读的双胞胎邪神恐怖。出于某种原因，这里的学生害怕他们。话说回来，如果他们是克苏鲁式的存在，我想我也会害怕的。"))
define t_curses = (_("黑暗诅咒"), "curses",
    _("只有巫师才能使用的诅咒符文，因为人类无法承受仅仅将它们刻在皮肤上的压力。这三个符文分别是塞勒姆之眼、赫卡特之蔷薇和犹大之星。"))
define t_dreams = (_("奇怪的梦"), "dreams",
    _("多么奇怪的梦啊。感觉像是一段记忆。有人说梦其实是我们在睡梦中窥视另一个版本的自己。不知道这是否有什么依据。"))
define t_curio = (_("你的好奇心"), "curios",
    _("好奇心害死猫。问题是，它是否也杀死了你的分身？在这个世界里，你的好奇心引起了多少次麻烦？"))
define t_bro = (_("伊瓦尔的儿子们"), "big_bro",
    _("伊瓦尔对儿子们的偏爱一定有原因。你想知道是什么导致了他对儿子们的蔑视。"))
define t_tomb = (_("神的坟墓"), "tomb",
    _("有一个关于人类和巫师试图成为神的坟墓的传说。也许图书馆或凯普勒先生能给你一些线索。"))
define t_rewrite = (_("重写"), "rewrite",
    _("似乎另一个你过去有重写记忆的倾向。你想知道他们做得有多随意。"))
define t_sirens = (_("海妖"), "sirens",
    _("显然，这里的海妖被当作猎物追捕，或被富人用作漂亮的奴隶。据说海妖有彩虹色的眼睛。"))
define t_nick = (_("昵称"), "nick",
    _("梅扎称你为她的\'小恶魔\'。也许这与你有某种关联。无论如何，仅仅是这个昵称就让你不寒而栗。"))
define t_knight = (_("血骑士"), "blood_knight",
    _("为吸血鬼国王服务的骑士。显然，塞恩的母亲在变成邪血之前就是其中之一。他们全身穿白色，与全身穿黑色的邪血和修女形成对比。"))

#######LISTING TOpik
define topiklists = [
    t_monarchy,
    t_soulmates,
    t_inkwell,
    t_genetics,
    t_shriek,
    t_bloodmoon,
    t_whore,
    t_leech,
    t_jelly,
    t_drakmar,
    t_choir,
    t_ctulhu,
    t_curses,
    t_dreams,
    t_curio,
    t_bro,
    t_tomb,
    t_rewrite,
    t_sirens,
    t_nick,
    t_knight]
