####ARSHEM DATE
label tom_date_check:
    if "date1_done" not in tom_events and "sabtu" in tom_events:
        scene bg_black with w20
        jump arshy_date1
    elif "date1_done" in tom_events and "filler" not in tom_events:
        jump arshy_filler
    elif "date3_done" not in tom_events:
        if "date2_done" in tom_events or "mingle" in fia_events:
            if ibu.points >= 40:
                jump arshy_date3
            else: 
                if datingplace == "Archery":
                    scene overcast with dissolve
                    $ datingplace = "sklh"
                elif datingplace == "Court":
                    scene court_up with dissolve
                    $ datingplace = "sklh"
                else:
                    scene mancur with dissolve
                    $ datingplace = "bebas"
                hide screen cal
                $ quick_menu = False
                $ daterp = 40
                $ turnsleft = 3
                $ skinshiparea = ""
                $ config.rollback_enabled = False
                $ renpy.block_rollback()
                $ datingname = "阿什姆"
                jump startdate
        else:
            if datingplace == "Archery":
                scene overcast with dissolve
                $ datingplace = "sklh"
            elif datingplace == "Court":
                scene court_up with dissolve
                $ datingplace = "sklh"
            else:
                scene mancur with dissolve
                $ datingplace = "bebas"
            hide screen cal
            $ quick_menu = False
            $ daterp = 40
            $ turnsleft = 3
            $ skinshiparea = ""
            $ config.rollback_enabled = False
            $ renpy.block_rollback()
            $ datingname = "阿什姆"
            jump startdate
    elif "date5_done" not in tom_events and "date4_done" in tom_events and ibu.points>=90:
        jump arshy_date5
    else:
        if datingplace == "Archery":
            scene overcast with dissolve
            $ datingplace = "sklh"
        elif datingplace == "Court":
            scene court_up with dissolve
            $ datingplace = "sklh"
        else:
            scene mancur with dissolve
            $ datingplace = "bebas"
        hide screen cal
        $ quick_menu = False
        $ daterp = 40
        $ turnsleft = 3
        $ skinshiparea = ""
        $ config.rollback_enabled = False
        $ renpy.block_rollback()
        $ datingname = "阿什姆"
        jump startdate
        
label tom_bye:
    scene archery_crowd with fade
    play music "MUSIC/MusMus-BGM-022.mp3"
    $ tom_events.append("tom_pisah")
    $ NPC = "???"
    npc "什么？！"
    show tom chill ha sweat frusta at center with dissolve:
        yoffset 190
    "你看到阿什姆正在安排其他射箭俱乐部成员排队。他们坐在场边，有些骚动。"
    npc "你说要退出是什么意思？"
    tom scold -sweat sigh blow "就是字面意思。从明天开始，我不再是你们的射箭俱乐部队长了。这个角色将由吉姆接任。"
    show tom hip frown -blow
    npc "吉姆？！就算把靶子挂在他额头前面绑着，他也打不中！"
    npc "为什么是他？"
    tom scold ejek cling "因为他诚实。他不像你一样同时周旋于五个女朋友之间，泰勒。"
    $ NPC = "泰勒"
    npc "什-什么？"
    tom talk kzl blow "他当然也不会像你一样叫我妈妈是妓女，卡尔。有趣的是，你贬低这个职业，但你似乎很支持这个行业。"
    npc "你怎么知道——"
    tom hip ejek cling "哦，我掌握了你们所有人的把柄。每一个人。我把它们都记在这本书里。"
    if "filler" in tom_events:
        "阿什姆拿出了他的勒索圣经，就是你之前看到他使用的那本。"
    tom talk cruel -cling "看到这本书了吗？它包含了你们藏在床底下的每一个肮脏秘密。我是说每一个。"
    "人群中有一只手臂猛地举了起来。"
    tom capek frusta "是的，卡兹，这包括你那些奇怪的癖好。但有些话题不适合在礼貌的场合讨论。"
    tom ha blow "继续说。你们中有些人可能会想知道为什么我会有这本书。嗯，我曾经认为它可以保护我。如果你愿意这么说的话，是为了提高我的地位。"
    tom hip nyesal -blow "因为显然，对你们来说，我的血统比我的个性、外表或智力更重要，"
    tom  "你们才会给我像对待其他人一样的基本尊重。"
    tom kzl "是的，我是混血儿，是的，我曾经努力想要凌驾于你们所有人之上。因为你们中的一些人确实认为我是低等的，不是因为我的母亲，就是因为我的血统。"
    tom whine "是的，我确实为了获得优势而诅咒了阿贾克斯的父亲，是的，我对你们中的许多人撒了谎。戴上了你们所知道的阿什姆·涅弗斯的面具。"
    tom sad "正是因为这些暴行...我必须辞职。"
    show tom hip frown 
    play sound "sound/effects/bum.mp3"
    "阿什姆烧毁了手中的书。看着它被明亮的红色火焰吞噬，加上突如其来的坦白，这场面相当壮观。" with flashbulb
    stop sound
    tom talk whine frusta "...我很抱歉。"
    tom sad sweat "那时候，我很难想象过上普通的生活。"
    tom hip nyesal blow "我一直认为我需要成为你们中最优秀的，随心所欲地利用你们。向我的继父证明我配得上涅弗斯家族的姓氏。"
    tom sad -blow "不管用什么手段，不惜任何代价。"
    tom chill wry -sweat "最近我意识到我并不需要那些。我过简单的生活并没有什么错，这种生活可能不会与财富或名声交织在一起。"
    tom amused blow "但正因为如此，我现在知道我不适合做你们的队长。老实说，你们大多数人也不适合。"
    tom calm -blow "但吉姆适合，他是个好人。也许是我们中唯一正直的人。"
    show tom wry 
    $ NPC = "吉姆"
    npc "...谢谢，阿什姆。"
    tom hip smile "不用谢，吉姆。同时，我也将完全退出射箭队。"
    tom giggle blush bunga "因为我有一些私事要处理。在接下来的日子里，我想把所有时间都留给某个人。"
    show tom smile 
    "那一刻，阿什姆偷偷瞥了你一眼，嘴角微微上扬，露出一个温柔的微笑。"
    if "companion" not in tom_events:
        "你意识到他说的朋友可能就是你。也许他想在你离开前的几天里多花些时间和你在一起。"
    else:
        show side_p se at pic
        mc "（他这么做是为了我。可能也是为了他们，因为他很快就要离开这个世界了。）"
        show side_p w 
        mc "（在我们离开之前，他正在处理所有未完成的事。）"
        hide side_p
    tom chill pfft -blush blow "就这样。谢谢大家。另外，我是认真的。卡尔，泰勒，振作起来。"
    tom ejek -blow "玩弄这么多人的心...你们最终会孤独终老的。"
    show tom pfft 
    $ NPC = "泰勒"
    npc "好吧...队长。"
    $ NPC = "卡尔"
    npc "是的，抱歉，队长。"
    $ NPC = "???"
    tom calm blow "现在只是阿什姆了。"
    show tom talk smile at right with move
    if girl:
        show palmierproxy chill wry at left with dissolve:
            yoffset 40
    else:
        show palmierproxy chill wry at left with dissolve:
            yoffset 100
    "阿什姆走过来，亲吻你的手作为问候。"
    tom pfft apa "你好，亲爱的。你喜欢这场表演吗？"
    if "companion" not in tom_events:
        mc malu blush tanya "你做这一切都是为了我吗？"
        tom pfft blow "是，也不是。我发现自己不再适合当队长了。而且我确实想腾出时间来帮助准备奎尔，这样你就可以——"
        mc kind "我就可以什么？"
        show palmierproxy frown -tanya
        tom giggle blush -blow "咳咳，没什么。"
        mc happy bunga "来吧，告诉我。你在打什么主意？"
        tom amused cling "这是个惊喜，亲爱的，最好不要破坏乐趣。"
        tom calm bunga "重点是，我决定现在轻松一点。专注于我的学习，也许在当地农场找个学徒工作。"
        mc frown tanya "你，当农民？"
        show palmierproxy kind -tanya
        tom pfft blow "我确实说过我喜欢植物，如果不当农民，那么也许可以当个花匠。"
        tom hip giggle -blow "现在我的父母已经让我摆脱了继承人的重担，过普通生活也没什么不好。"
        tom smile bunga "我感觉我终于可以开始过自己的生活了，而不是一个接一个地完成任务。"
        tom chill calm "不用再承受成为[povname]理想伴侣的压力，也不用再维护尼弗斯家族的名声。"
        mc smile bloom "我很高兴你终于看到事情的光明面了。"
        
    else:
        mc happy bunga "那真是一番精彩的演讲。"
        tom hip pfft blow "可能这是我最后一次能这样炫耀我的\'权威\'了。"
        tom talk amused apa "除非你们的世界有射箭俱乐部。"
        mc wry sigh "我们确实有，但他们用的是真正的弓箭，不是火和闪电。"
        tom pfft -apa "嗯，有点无聊，不是吗？"
        mc kind -sigh "和这里相比，是的。没有魔法，恐怕你会发现我的世界里有很多无聊的东西。"
        tom calm blush bunga "但我相信我们仍然会创造许多魔法般的回忆。"
    tom chill pfft apa "说到这个，我听说梅莉创造了一系列新的茶品。你想和我一起来品尝一下吗？我请客。"
    mc laugh blush bunga "开玩笑吗？我当然愿意！"
    scene book with w33
    "阿什姆给你买了一整套茶叶混合，作为你回家的纪念品。"
    "你不确定自己是否舍得喝它，但还是很感激他的心意。"
    $ NPC = "???"
    scene bg_black with w20
    stop sound
    jump jaga_jaga




label arshy_date5:
    stop music
    scene bg_black with w20
    $ tom_events.append("date5_done")
    scene angels with w20
    play music "MUSIC/MusMus-BGM-006.mp3"
    if calendar.weekday == "Sat" or calendar.weekday == "Sun":
        "你和阿什姆一起度过了整整一天，在校园咖啡馆聊天，在喷泉旁玩耍。"
        "尝试并未成功地潜入校长办公室，之后他带你去了公园。"
        
    else:
        "你和阿什姆一起度过了整整一天，在校园咖啡馆聊天，在喷泉旁玩耍。"
        "尝试并未成功地潜入校长办公室，之后你们偷偷溜到了公园。"
    show tom go sad frusta at center with dissolve:
        yoffset 190
    "他似乎心事重重，整天都显得很紧张，但你不太确定原因。"
    show tom wry -frusta at right with move
    if girl:
        show palmierproxy jln kind at left with dissolve:
            yoffset 40
    else:
        show palmierproxy jln kind at left with dissolve:
            yoffset 100
    tom pfft apa "你知道这些天使雕像背后的故事吗？"
    mc malu sigh "不知道，但我猜你要告诉我了。"
    show palmierproxy kind -sigh
    tom calm -apa "它们是科尔的守护者的描绘。据说她以前有八个修女跟随她四处履行帮助人类的职责。"
    show palmierproxy frown shock
    tom pfft blush "传说在这里形成灵魂羁绊的人会得到科尔本人的祝福，并在极乐世界受到庆祝。"
    show palmierproxy malu -shock
    tom sad frusta "当然，现在我们知道了关于科尔的真相，我怀疑她会给我们祝福。"
    tom smile blow "不过，这里仍然是一个受欢迎的浪漫地点。"
    show pboy s at horzappear
    menu tun_tom:
        "你要求婚吗？" if "nembak_cuy" in tom_events:
            hide pboy
            show palmierproxy ha blush shock
            tom ejek cling "拜托，[povname]，如果我要求婚的话，至少会有快闪族、空中标语和游行乐队。"
            show tom pfft -cling
            mc avoid both "太夸张了。"
            show palmierproxy kind blush sigh
            tom giggle blush bunga "只有最好的才配得上你，亲爱的。"
            tom pfft blow "但不是...我带你来这里是为了求好运。"
        "{s}你要求婚吗？{/s}" if "nembak_cuy" not in tom_events:    
            
            jump tun_tom
        "等等。":
            hide pboy
            tom calm blush bunga "我以为这个地方会给我带来好运，帮助我完成今天的计划。"
        "这是一个告白吗？":
            hide pboy
            if "nembak_cuy" in tom_events:
                $ tom_events.append('spoil_me')
                show palmierproxy confused shock
                tom whine sweat apa "我亲爱的，难道我还没有清楚地表达我对你的爱吗？"
                show palmierproxy wry both -shock
                tom calm blush bunga "嗯，也许我应该开始每天早上用鲜花轰炸你，每天晚上送你珠宝。"
                tom amused cling "或者我应该在每节课后不停地赞美你，标记你。这也能阻止其他追求者。"
                mc avoid frusta "拜托，别这样。"
                show palmierproxy wry blush sigh
                tom pfft bunga "太晚了。显然我还没有充分证明我的忠诚。我们不能这样，对吧？"
                show palmierproxy malu -sigh
                show tom calm with move:
                    xalign 0.3
                "阿什姆吻了你的脸颊，仿佛在确认他的决定。"
                show tom pfft at center with move
                tom amused cling "请期待我源源不断的礼物和赞美。我迫不及待要把你宠坏。"
                mc hister "我猜我不该对你期望太少，是吗？所以这就是你今天想对我说的？"
                show palmierproxy kind 
                tom calm blow "不完全是。"
                
            else:
                tom pfft blow "不是。好吧，确实是，但不是那种浪漫的。"
    tom giggle blush bloom "我想感谢你，[povname]。"
    mc confused sweat tanya "感谢我？"
    show palmierproxy frown -sweat -tanya
    tom pfft "感谢你在我闷闷不乐、整理思绪时对我的耐心。"
    tom smile "感谢你告诉我[povname]的谎言。感谢你问我想要什么，而不是对我评头论足。"
    tom giggle blow "感谢你接受真实的我。"
    tom ha sweat frusta "多年来，我一直以为我需要以某种方式行事才能得到爱。"
    tom capek "聪明、整洁，完美的化身。"
    tom whine "我不像奎尔那样出身高贵，也没有塞恩那样的少年魅力，或者[povname]那种奇特的吸引力。"
    tom sigh blow "有人接受真实的我，这种想法对我来说似乎如此陌生。"
    tom kzl frusta "见鬼，就连[povname]和我约会也只是为了[kamu]能按[dia]的需要塑造我。"
    tom lega blush blow "但你从未对我有任何期望。你只是让我做我自己，我永远无法充分感谢你这一点。"
    show tom smile -blush -blow
    mc happy blush bunga "不用谢，但我怀疑我不是唯一一个。"
    show palmierproxy frown -blush shock
    tom pfft "嗯，这倒是真的。我...我和我的父母谈过了，你知道吗？"
    show palmierproxy kind blush -shock
    tom -blush wry "和他们两个都谈了。父亲为让我感到不被需要而道歉。"
    tom lega blow "至于我母亲，别提了，她几乎用眼泪淹没了整个家。"
    tom pfft -blow "原来他们比我想象的更爱我。他们注意到我为维护尼弗斯家族形象付出了多少努力。"
    tom giggle "我多么努力地想要变得\'完美\'。不管那意味着什么。"
    tom sad blow "我父亲以为我这么做是因为我不是他亲生的孩子，承受不住压力。"
    tom wry -blow "所以他和我妈妈决定彻底摆脱这个负担，把头衔给了我的小弟弟。"
    tom lega "希望我现在有自由去...可以说是开辟自己的道路。"
    show tom pfft 
    mc wry sigh "基本上他们的出发点是好的，但执行得不好？"
    tom calm blow "没错。不过我很高兴我们把事情说清楚了。"
    if "nembak_cuy" in tom_events and "companion" not in my_events:
        tom pfft -blow "我不想在离开这个世界时没有好好和母亲道别。"
        mc sad tanya "道别？"
        show tom wry with move:
            xalign 0.3 
        "当你停下脚步时，阿什姆笑了。他利用这个时机向前倾身，让你们的额头相触。"
        show palmierproxy frown shock
        tom calm blush bunga "我想和你在一起，[povname]。在这个世界，和你的世界。"
        tom smile cling "无论你去哪里，我都会跟随。"
        $ my_events.append("companion")
        $ tom_events.append("companion")
        $ ibu.hint = "在这次游戏中，阿什姆成为了你的恋人。他会跟随你到你的世界。"
        mc ow sweat frusta "但你会抛下一切，你的家人，你的朋友——！"
        show palmierproxy shock
        tom pfft blow "我的家人给了我祝福，我也和奎尔和塞恩谈过了。"
        tom giggle -blow "他们不太高兴，但他们知道我有多么痴情。我可以有多热烈和固执。"
        tom smile -blow "虽然他们一直纠缠不休，但他们理解这对我意味着什么。"
        show palmierproxy malu blush -shock
        tom calm "你对我意味着什么。"
        tom smile "我爱你，[povname]，我想和你在一起。如果必要的话，我会追随你到世界尽头。"
        tom calm "因为没有你的世界毫无意义。"
        mc wry "阿什姆..."
        tom pfft apa"况且，我不会完全与家人分离。我在那边还有个父亲，不是吗？"
        mc wry sigh "我想是的，但是...我还是不敢相信你为我做这些，阿什姆。"
        mc side both tanya "我很高兴，但如果我们最后搞砸了世界，维度，或者别的什么怎么办？"
        tom amused cling "嗯，也许只是我的想法，但为了我们的爱撕裂世界听起来挺浪漫的，不是吗？"
        show tom giggle -cling
        mc hister blush sigh "哼。我讨厌自己无法反驳。"
        show palmierproxy malu -sigh
        tom pfft blow "很好。我可以省去我准备好的说服论点，转而用我们的时间做些更……亲密的事。"
        show pboy s at horzappear
        menu:
            "让他带路":
                hide pboy
                show tom ejek cling
                show palmierproxy wry shock
                play sound "sound/effects/cloth.mp3"
                "阿什姆毫不迟疑地将你按在附近的墙上。" with vpunch
                if girl:
                    show kiss_wallf with flashbulb
                    galleryunlock kiss_wallf
                else:
                    show kiss_wall with flashbulb
                    galleryunlock kiss_wall
                "不知怎的，这让你想起了你们第一次见面的情景。"
                mc "把我按在最近的平面上是你的惯用伎俩吗？"
                tom "重复一下经典桥段没什么不好，亲爱的。不过我还有很多其他的花招。"
                mc "啊！"
                "当他调皮地轻咬你的脉搏点时，你的呼吸变得急促。另一个充满占有欲的啃咬在你身上留下了印记，让你的双手不由自主地抓住他的头发。"
                "阿什姆愉悦地哼了一声，同时用舌头划过你的锁骨。你越用力拉扯他的头发，他似乎就越兴奋。"
                "当他如此热烈地吻你时，你的脑海中已经无法产生任何连贯的思绪。你可能会因为狂喜而晕厥。"
                "直到你们听到一声熟悉的、震惊的尖叫，你们两个才意识到应该把纠缠在一起的四肢挪到别处去。"
                if girl:
                    hide kiss_wallf with dissolve
                else:
                    hide kiss_wall with dissolve
                show tom eh both shock
                show palmierproxy confused both shock
                $ NPC = "孩子"
                npc "妈妈！又是那两个吸脸的变态！"
                $ NPC = "某位妈妈"
                npc "该死！你们为什么不找个房间？！杰米，捂住眼睛！"
                show tom giggle blush blow
                mc ha sigh "呃……抱歉？"
                tom pfft apa "确实抱歉。不过她说得有道理。我们回我房间继续，好吗？"
                show tom bunga
                mc happy bunga "带路吧。"
                stop music
                scene bg_black with w20
                "你和阿什姆回到他的房间度过了一个亲密的下午。"
                "这个男人爱你的方式，就像他对待所有其他事情一样。"
                "专横、热烈、略带痴迷……而你也不希望他有任何改变。"
                "不幸的是，你的同学们似乎并不赞同。你很快就收到了噪音投诉，被迫回到自己的房间。"
                scene lor_mlm with dissolve
                play music "MUSIC/MusMus-BGM-082.mp3"
                jump ur_room

            "像是牵手？":
                hide pboy
                tom pfft blush blow "嗯。我在想的是更像性爱。"
                tom giggle bunga"……不过牵手听起来也不错。"
                mc happy bloom "很好。我们慢慢来，好吗？想再多逛逛吗？"
                mc smile "我听说有家新的甜品店即将开业。"
                tom smile "带路吧。"
                stop music
                scene bg_black with w20
                "你和阿什姆在镇上探索了一整天，然后回到了宿舍。"
                scene lor_mlm with dissolve
                play music "MUSIC/MusMus-BGM-082.mp3"
                jump ur_room

            "把他按在墙上":
                hide pboy
                if girl:
                    show smooshf with flashbulb
                    galleryunlock smooshf
                else:
                    show smoosh with flashbulb
                    galleryunlock smoosh
                "在阿什姆采取行动之前，你直接把他按在了附近的墙上。他的眼睛睁大了，显然没有预料到这一点。"
                "然而，当他握住你的手时，他的目光很快变得柔和起来。"
                if girl:
                    show smoosh2f with dissolve
                    galleryunlock smoosh2f
                    hide smooshf
                else:
                    show smoosh2 with dissolve
                    galleryunlock smoosh2
                    hide smoosh
                tom "很急切，是吗？"
                mc "我觉得这和我们第一次见面时形成了一个不错的对比。"
                tom "啊，我还记得那个画面。你脸红扭捏的样子真可爱。"
                mc "彼此彼此。让我很想看看你哭泣时有多漂亮。"
                tom "嗯，我还以为我会是那个让你因狂喜而哭泣的人呢。"
                "阿什姆飞快地偷了你一个吻，然后用他那调皮的眼神看着你。"
                if girl:
                    hide smoosh2f with dissolve
                else:
                    hide smoosh2 with dissolve
                tom amused cling "我打赌我能在你之前让你达到那个状态。"
                mc mock cling "来啊！"
                stop music
                scene bg_black with w20
                "你和阿什姆回到他的房间度过了一个亲密的下午。"
                "这个男人爱你的方式，就像他对待所有其他事情一样。"
                "专横、热烈、略带痴迷……而你也不希望他有任何改变。"
                "不幸的是，你的同学们似乎并不赞同。你很快就收到了噪音投诉，被迫回到自己的房间。"
                scene lor_mlm with w20
                play music "MUSIC/MusMus-BGM-082.mp3"
                jump ur_room


    else:
        tom amused cling "我迫不及待想回家见我弟弟了。"
        tom giggle -cling "我打赌他比菲亚可爱十倍。"
        mc ha sigh "我是说，我希望如此。否则，他就是一个丑baby了。"
        show palmierproxy happy -sigh
        tom pfft shock "别侮辱我弟弟。只有我能这么做！"
        show tom smile blow
        mc happy bunga "说得像个真正的哥哥。"
        stop music
        scene bg_black with w20
        "你们度过了剩下的时间，争论谁的兄弟姐妹更可爱，然后回到了宿舍。"
        scene lor_mlm with w20
        play music "MUSIC/MusMus-BGM-082.mp3"
        jump ur_room

label arshy_date4:
    $ tom_events.append("date4_done")
    stop music
    play music "MUSIC/MusMus-BGM-013.mp3"
    tom frown sweat shock"[povname]！"
    "这一次，是阿什姆主动来找你。他眼中有一种你通常不会在公共场合看到的慌乱神情。"
    show tom sad at right with move
    if calendar.weekday == "Sat" or calendar.weekday == "Sun":
        if girl:
            show palmierproxy jln frown at left with dissolve:
                yoffset 40
        else:
            show palmierproxy jln frown at left with dissolve:
                yoffset 100
    else:
        if girl:
            show palmierproxy chill sad at left with dissolve:
                yoffset 40
        else:
            show palmierproxy chill sad at left with dissolve:
                yoffset 100
    mc confused tanya "发生什么事了？"
    if "slander" in tom_events:
        tom whine apa "还记得我们给我继父发的那条恶毒短信吗？"
        show tom sad -apa
        mc sad -tanya "就是我们花了一整天编写的那条？是啊，怎么了？"
    else:
        tom nyesal frusta "嗯，你看，在我们在我房间里小聚之后，我感到相当恼火，于是决定对我继父进行一番长篇大论的抱怨。"
        mc ha sweat tanya "哦，结果如何？"
    show palmierproxy frown sweat shock
    tom ha blow "他回复了。注意，我已经做好了迎接战争、咒骂、被剥夺继承权或被送回塞维德的准备。"
    tom kzl -blow "然而，我没想到的是，他居然联系上了一个认识我父亲的精灵。"
    mc pissed -shock "...什么？"
    show palmierproxy confused 
    if calendar.weekday == "Sat" or calendar.weekday == "Sun":
        tom sad blow "镇上有个认识我父亲的精灵。她同意在这里见我。"
    else:
        tom sad blow "镇上有个认识我父亲的精灵。她同意在欢乐之夜酒吧见我。"
    mc deject tanya "一个精灵？是谁？"
    show palmierproxy sad -tanya
    tom ha -blow "不清楚，我继父没有具体说明。不管是谁，他已经安排了我们的见面，我现在需要一个朋友。"
    tom nyesal frusta "我知道这很突然，但我现在需要你陪我，拜托了。我...我觉得我无法独自面对她。"
    show tom wry -sweat shock
    mc kind -sweat sigh "我在这里。"
    if calendar.weekday == "Sat" or calendar.weekday == "Sun":
        tom lega blow "谢谢你。"
    else:
        tom smile blow "谢谢你。来吧，我们应该换衣服然后偷偷溜出去。"
    stop music
    play music "MUSIC/MusMus-BGM-025.mp3"
    $ morning = False
    $ afternoon = True
    $ evening = False
    $ night = False
    scene merry_bar with w33
    "你和阿什姆一起前往欢乐之夜酒吧。一路上，阿什姆一直没有松开你的手。"
    show tom go ha at right with moveinright:
        yoffset 190
    if girl:
        show palmierproxy jln sad at left with moveinleft:
            yoffset 40
    else:
        show palmierproxy jln sad at left with moveinleft:
            yoffset 100
    show tom nyesal sweat frusta
    mc sad sweat "（这是我第一次看到他如此紧张。希望一切顺利。）"
    play sound "sfx/bell.mp3"
    show ech frown at center with dissolve:
        xzoom -1.0
    ech amused shock "哦，你们来了！"
    show tom kzl sweat shock
    show palmierproxy frown sweat shock
    "一位身材纤细、美丽动人的银发女子向你和阿什姆挥手，她的紫色眼睛闪闪发光。"
    "仅仅是看到她，似乎就触发了阿什姆内心的某些东西，他开始低声咒骂。"
    show ech frown -sweat -shock
    tom capek frusta "当然，非得是三巨头之一的女儿。哈..."
    tom kzl -sweat blow "问候您，艾希德娜女士。"
    ech tease sigh "我听到你那恼火的呻吟了，你知道吗。不过既然我们不在塞维德，我就不计较了。"
    ech smile -sigh "总之，别那么拘谨，放松一下。来，坐下。"
    show merry_cafe behind tom with dissolve
    show ech tease
    show tom capek frusta
    show palmierproxy confused sweat tanya
    play sound "sound/effects/jelly.mp3"
    "在你还没来得及走向那位女士时，你感到有什么东西拽着你的影子，强迫你的双脚朝那位女士走去，你顺从地坐了下来。"
    show palmierproxy sad -tanya
    show tom kzl sweat shock
    "你注意到自己的姿势比平常更加僵硬，而阿什姆却能以更放松的方式行动。"
    tom sweat frusta "别用你的尘埃戏弄我们！而且为什么到处都是，这不是很危险吗？"
    ech smile sigh "没有你想象的那么危险。再说，这地方对我的品味来说太平淡了。"
    ech grit frusta "哪家酒吧不卖苦艾酒？为什么这里没有冰毒或羟考酮出售？"
    tom capek blow "人类对阿片类药物和兴奋剂的耐受性较低，这包括你到处散播的精灵尘埃！"
    show tom kzl -blow
    ech tease sigh "啧。你们人类真是脆弱。你们的生活如此无聊。"
    ech kzl -sigh "这里的每个人看起来都让人不舒服，难道没人听说过护肤这回事吗？呃！"
    "她将目光从阿什姆身上移开，然后看向你，脸上露出了一丝微笑。"
    show palmierproxy confused sweat shock
    ech smile cling "虽然这位绝对能让泰坦妮娅相形见绌。哇，你真是让人赏心悦目啊？"
    show palmierproxy side -shock
    play sound "sound/effects/jelly.mp3"
    show tom kzl shock with flashbulb
    "你能感觉到手臂上有一阵刺痛，银色和金色的尘埃开始围绕着你旋转。"
    "与此同时，艾希德娜的眼睛闪烁着明亮的紫色光芒，像飞蛾扑火一样让你着迷。"
    show pboy s at horzappear
    menu personali:
        "试图摆脱它":
            hide pboy
            "你试图摆脱她对你的控制，想象着伊瓦尔的金色眼睛，而不是她的淡紫色眼睛。"
            mc ow frusta "住手！不管你在做什么，我不喜欢！"
            ech frown shock "哦！你能挣脱。嗯，这倒是新鲜。"
        "{s}看看她想要什么{/s}" if curiosity < 50:
            
            jump personali
        "看看她想要什么" if curiosity >= 50:
            hide pboy
            $ ibu.points -= 5
            if ibu.points < 0:
                $ ibu.points = 0
            tom kzl frusta"不！"
            ech grit shock"哎哟！"
            "阿什姆踢了那个女人的小腿，显然对她对你使用的小把戏感到恼火。"
        "{s}踩她的鞋{/s}" if kindness > 10:
            
            jump personali
        "踩她的鞋" if kindness <= 10:
            hide pboy
            $ ibu.points += 5
            show tom ejek cling
            show palmierproxy mean cling
            play sound "sound/effects/bump.mp3"
            ech grit frusta"哎哟！两只脚都踩？认真的吗？！"
            "你和阿什姆似乎有同样的想法，你看到他也踩了她的脚。"
            "她呻吟着抬起双脚，轻轻拍了拍。"
    tom kzl sweat frusta "住手，埃克德娜！这不是塞维德或西奥德，你不能随便勾引一个人上床！"
    show palmierproxy confused sweat sigh
    ech grit frusta "我本来想邀请你一起加入的！"
    tom capek blow "我不感兴趣。至少不会和你。"
    ech tease sigh "哼。好吧，那就直接谈正事？阿什姆，你从来就不懂得享受。"
    tom sad -sweat -blow "而你从不认真对待任何事。如果你知道我父亲的事，为什么不提前告诉我？"
    show palmierproxy frown -sweat -sigh
    ech amused -sigh "哦，我对你老爸一无所知，我只是个传信的。"
    "埃克德娜在口袋里翻找，掏出一封看起来相当陈旧且皱巴巴的信。"
    ech tease cling "涅弗斯大人坚持要我把这个交给你。你知道要找到一个还记得那个混蛋的人有多难吗？"
    ech kzl sigh "不得不跑到菲格米森林附近的一个废弃房子里，从一具腐烂的尸体上找到这个。要不是我母亲欠他人情，我发誓。"
    tom ha apa "是我继父坚持要这样做的？"
    ech tease cling "当然。另外，别以为我没注意到你说的是继父而不是父亲。家里有矛盾？"
    tom capek frusta "这不关你的事。"
    ech smile sigh "随便吧。重点是，我已经完成了我的任务，现在我可以自由地去寻欢作乐了。我相信这附近能找到一个像样的换偶酒吧。"
    tom ha -frusta "随你的便。"
    "阿什姆叹了口气，站起来朝门口走去。你跟在他后面，但很快发现埃克德娜刚做过美甲的手指缠上了你的前臂。"
    ech tease cling "你知道...我可以用得上一个熟悉这个地方的人。有人能带我好好逛逛？最好是在夜生活区。"
    mc grit frusta "说真的，女士，我——"
    play sound "sound/effects/cloth.mp3"
    if girl:
        galleryunlock fjeles
        show fjeles with dissolve
    else:
        galleryunlock back_hug
        show back_hug with dissolve:
            truecenter zoom 1.0
            easein 2.0 truecenter zoom 0.5
    tom "滚。开。"
    "就在你准备甩开她的手时，阿什姆迅速用手臂环住了你的。"
    "他把你从她身边拉开，保护性地搂住你的腰。他几乎是对埃克德娜咆哮着。"
    "他的呼吸在你耳边轻拂。他显然对整个交谈感到恼火。与此同时，你发现自己不知所措。"
    "不知道该如何应对这突如其来的占有欲表现。"
    if kln:
        tom "你看不出[kamu]不感兴趣吗？"
    else:
        tom "你看不出[kamu]不感兴趣吗？"
    if not girl and not girl2:
        tom "去找别的鸡巴吸吧，埃克德娜。"
    else:
        tom "赶紧滚蛋。"
    if girl:
        hide fjeles with dissolve
    else:
        hide back_hug with dissolve
    show palmierproxy confused both sigh
    ech grit frusta "呃。你们人类怎么都这么执着于一夫一妻制？阿什姆，你是半精灵，难道不知道分享才是美德吗？"
    if not girl2:
        tom kzl frusta "我永远不会分享[povname]，永远不会。你休想碰[dia2]！[povname]是我的！"
    else:
        tom kzl frusta "我永远不会分享[povname]，永远不会。你休想碰[dia]！[povname]是我的！"
    ech tease cling "随便吧。我只是想让你知道，你可以找到比阿什姆更好的，知道吗？"
    ech smile -cling "有空给我打电话。"
    show ech grit shock
    play sound "sound/effects/freeze.mp3"
    tom capek blow "出去！"
    show ech kzl frusta
    show tom sad -blow
    "在埃克德娜准备写下她的号码之前，阿什姆冻住了她角尖。"
    hide ech with dissolve
    play sound "sound/effects/doorslam.mp3"
    "这似乎触及了她的底线，她甩掉角上的冰，怒气冲冲地冲出门去——气得发抖。"
    show tom sigh blow at center with move
    show palmierproxy sad sweat shock
    tom lega -sweat -blow "...你没事，你在这里，你是我的。"
    show palmierproxy confused -shock
    "埃克德娜走后，阿什姆终于稍微放松了一些。"
    "然而，他环绕你腰部和脖子的手却似乎收得更紧了，而不是放松。"
    show pboy s at horzappear
    menu:
        "谢谢。":
            hide pboy
            $ ibu.points += 5
            show tom eh both shock
            mc malu both sigh "谢谢。另外，这里变得有点热了，是吧？"

        "我是你的？？？":
            hide pboy
            show tom eh both shock
            show palmierproxy kzl sweat sigh
            $ ibu.points -= 5
            if ibu.points < 0:
                $ ibu.points = 0
            pass
        "她很性感！":
            hide pboy
            $ ibu.points -= 10
            if ibu.points < 0:
                $ ibu.points = 0
            tom kzl sweat frusta "她很恶心！她可能是你喜欢的类型，但我知道你应该得到比那个荡妇好得多的人！"
            mc avoid sweat sigh "也许吧，但至少她可能知道什么是界限。"
    show palmierproxy wry sweat sigh
    tom whine both frusta "啊！原谅我！"
    show tom sad sweat blow at right with move
    show palmierproxy frown -sweat -sigh
    "阿什姆松开了对你的控制，他的脸涨得通红，显然是一时冲动。"
    tom capek frusta "我没经过思考就做出了反应。当然，你是你自己的人，不是\'我的\'，但是..."
    tom whine "我只是脱口而出，因为我不想让她就那样把你抢走！"
    tom sad "当然，如果你想的话，你可以去追她——"
    tom kzl blow "不，请不要去追她！她是个可怕的女人，没有一丝忠诚。我不想让你遇到那种情况，而且——"
    mc ha sweat "（他慌了。看来他并不是有意说出\'你是我的\'这句话。至少他还有自知之明。）"
    mc side sigh "（不过，他称我为\'他的\'……也许我应该澄清一些事情。）"
    mc frown -sweat -sigh "阿什姆。"
    tom sad shock "是-是的？"
    show pboy s at horzappear
    menu chu_tom:
        "{s}用一个吻让他闭嘴{/s}" if "companion" in my_events:
            
            jump chu_tom
        "用一个吻让他闭嘴" if "companion" not in my_events:
            hide pboy
            $ ibu.points += 15
            show palmierproxy mock at center with move
            tom frown both shock "唔！"
            mc happy blush bloom "别说了。"
            show palmierproxy kind blush sigh
            tom giggle blush bloom "我……好的。你能再让我闭嘴一次吗？"
            mc happy bunga "乐意之至。"
            show palmierproxy smile with move:
                xalign 0.67
            show tom wry shock
            "你再次轻轻吻了阿什姆的嘴唇，这次更加温柔。"
            tom calm bunga "再来一次……"
            mc kind "嗯……"
            tom giggle "再来一次……"
            "阿什姆越陷越深地投入这个吻中，仿佛一个濒临窒息的人渴求空气般吮吸着你。"
            "直到你用舌头轻轻扫过他的下唇，他才终于放慢了节奏，悠闲地吻着你。"
            "他的手向上抚摸，捧住你的脸，手指穿过你金色的发丝。"
            "老实说，如果不是因为时间和地点不合适，你本可以更进一步。"
            $ NPC = "孩子"
            show palmierproxy sad both shock
            show tom eh both shock
            npc "妈妈，他们为什么在吸对方的脸？"
            $ NPC = "某位妈妈"
            show palmierproxy malu blush bunga at center with move
            show tom giggle blush -shock
            npc "别看，亲爱的，又是那些该死的发情的猎巫人！"
            tom pfft blow"哦，咳咳。"
            "你们俩控制住了自己，那位评判的母亲明显给了你们一个鄙视的眼神。"
            mc happy tanya "改天再说？"
            tom smile apa "当然。不过[povname]，这是不是我想的那个意思？"
            mc confused -tanya"嗯？"
            tom wry "那个吻，对我们来说究竟意味着什么？"
            $ tom_events.append("nembak_cuy")
            if "oral" in tom_events:
                show tom giggle both shock
                if girl:
                    mc avoid both sigh "阿什姆……你可是给我口了整整两个小时。"
                else:
                    if not girl2:
                        mc avoid both sigh "阿什姆，你可是含着我的老二整整两个小时。"
                    else:
                        mc avoid both sigh "阿什姆……你可是给我口了整整两个小时。"
            show tom pfft blush blow
            mc wry blush tanya "还能有什么别的意思？"
            mc smile -tanya "阿什姆，我很喜欢你。我知道我们的处境很复杂，我们将会身处两个不同的世界。"
            mc happy bunga "但我仍然想要探索这些，探索这一切，探索我们之间的关系。"
            tom smile apa "所以你确实想要一个\'我们\'。"
            mc smile "是的。"
            tom lega blow "哦，感谢科尔。"
            tom giggle -blow "我知道我试图表现得尽可能成熟，但说实话，如果你说不，我真不知道自己会做出什么。"
            tom smile "尤其是现在我有了……不管这是什么。"
            
        
        "我不是你的。":
            hide pboy
            $ ibu.points -= 25
            if ibu.points < 0:
                $ ibu.points = 0
            tom sad both frusta "哦，当然不是。我……我很抱歉。"
            if "intim" in tom_events:
                tom sigh blow "……我以为我们之间有更深的关系，但也许在界限和关系方面我还有很多要学习的。"
            
            else:
                mc deject sweat sigh "别那样看着我。只是我们之间的事情太复杂了，还有另一个[povname]。"
                mc ow frusta "这一切太混乱，太过了。"
                show palmierproxy wry sigh
                tom sad frusta "不，我理解。确实很复杂，不是吗？"
            show palmierproxy wry blush sigh
            tom lega blush blow "无论如何，我很高兴能成为你的朋友，[povname]。"
            tom wry -blow "如果这是我能拥有的全部，那么我们就只能是朋友了。"
            mc happy bunga "当然。我们永远是朋友，阿什姆。"
            tom pfft -blush -blow "很好。因为不管这是什么，我确实需要一个朋友。"
    show palmierproxy confused sweat shock
    show tom sad sweat blow
    play sound "sound/effects/crumple.mp3"
    "阿什姆摆弄着手中那封皱巴巴的信。"
    "这封信来自他所谓的、疏远的父亲。看着他的表情，你不确定他是想打开它还是把它撕成两半。"
    mc frown -sweat tanya "你要打开它，对吧？"
    show palmierproxy confused -tanya
    tom wry -blow "当然。这就是我们来这里的目的，不是吗？为了得到一些答案。"
    tom nyesal frusta "呵。如果我说我害怕了，是不是很可悲？"
    tom sad blow "我感觉我已经失去了一个父亲，如果我再失去另一个怎么办？"
    show tom frown -sweat shock
    mc smile sigh "那我会在这里。你的\'爸爸问题小组\'其他成员也会在，奎尔、塞恩、莱尔，我们都会在这里支持你。"
    show tom calm -shock
    mc ha sweat -sigh "另外，我觉得你应该对你的继父宽容一些。"
    show tom sad
    mc side -sweat "我知道他直接跳过你作为潜在继承人是很糟糕的行为，但我觉得他现在正试图弥补你，对吧？"
    mc wry sigh "谁知道呢？也许他只是从未想要取代你真正的父亲。"
    tom pfft "也许吧。让我们看看他是否值得如此尊重，好吗？"
    show tom sad sweat blow
    show palmierproxy confused -sigh
    "阿什姆用力一拉，打开了信封，取出了信。你试图尊重他的隐私，在他没有要求之前不偷看。"
    show tom frown -sweat shock
    "但你还是瞥见了一两眼。\'对不起\'和\'别无选择\'似乎是这封信的主题。"
    mc eiden sweat frusta "如果这是那种\'出去买牛奶\'的爸爸，我发誓——"
    show palmierproxy frown -sweat shock
    tom sigh blow "不是的。"
    stop music
    tom ha -blow "这是...我想我爸爸是来自你的世界。"
    mc ow shock"啊？！"
    show palmierproxy confused tanya
    tom frown "给你。"
    show palmierproxy frown shock
    "阿什姆把信递给了你。你简直不敢相信你所读到的内容。"
    show tom sad
    show palmierproxy sad
    play music "MUSIC/heart.mp3"
    $ NPC = "信"
    npc "我亲爱的小阿什姆，我不知道你什么时候会读到这封信。也许永远不会。但我愿意相信你会读到。"
    npc "当我第一次来到你的世界时，一切都相当突然。也许你不会相信我的话，但我是从另一个世界被召唤到这里的。"
    npc "一个魔法不存在的世界。一个仙子、美人鱼、海妖和巫师都只是儿童童话的世界。"
    npc "一个充满悲惨阴郁的人的世界，他们总是过分抱怨天气，英国伦敦。"
    npc "当然，假设你从赫克斯那里收到这封信，我把信托付给他，那么我相信你已经对我习惯打交道的那些人有了印象。"
    npc "另外，请不要因为赫克斯的血统而对他有偏见。他可能是半巫师，出生于塞斯，但他比看起来要善良得多。"
    npc "我们正在执行一项任务。是关于帮助巫师们找到他们的领袖科尔。出于某种原因，他们的符文魔法在我手中似乎更强大。"
    npc "我一直在帮助他抵御猎人（不要相信他们！）。"
    npc "那些猎人是一群顽固的家伙，差点失去一条腿。不得不在医院待了整整一个月。"
    npc "那是可怕的时期，但至少那次事件让我遇到了你的母亲。"
    npc "我仍然记得那天，就像昨天一样，你的母亲坐在她的床上，就在我的对面——向我展示了我见过的最美丽的笑容。"
    npc "你知道我们一开始相处得并不好吗？我相信她觉得我很吓人。"
    npc "话说回来，我可能盯着看得太久了，但你能怪我吗？"
    npc "她太美了。幸运的是，她给了我另一次机会，而那次机会就有了你。"
    npc "我们的小男孩。如果我现在不在你身边，我很抱歉。但赫克斯说他无法再维持他的传送门太久了。"
    npc "他没想到这个任务会持续数月之久，更不用说整整一年了。"
    npc "几天后传送门就会关闭，我将会像突然到来一样突然被抛出这个世界。"
    npc "我考虑过带你和你的母亲一起走，但赫克斯明确表示他施放的传送门不会让任何其他生物通过。"
    npc "这是他为了让我们的世界保持分离而采取的安全措施。"
    npc "我试过用小虫子和假人测试，但它们一接触就立即爆炸了。"
    npc "我不敢冒险让你和你的母亲遭受这样的危险。"
    npc "所以，我必须离开。请知道，我愿意放弃一切来留下。"
    npc "我恳求赫克斯想办法，为我们两个打开传送门。他只说他会尽力而为。"
    npc "我希望他能成功，希望你能有不只是一封信来了解你的老爸。"
    npc "我爱你，儿子。我发誓我会想办法回到你身边的。我保证。永远是你的爸爸，大卫·希尔斯。"
    $ NPC = "???"
    mc confused shock "伦敦。他是来自我的世界！"
    show palmierproxy frown -shock
    tom ha frusta "我也这么想。也许是不同的城市，但你们两个描述的世界非常相似。"
    mc happy blush bunga "是啊。我是说，他在一个完全不同的大陆，但我们确实来自同一个世界。阿什姆，这太重要了！"
    mc smile "你父亲并没有离开你！至少不是故意的。"
    tom wry blow "我知道。赫克斯可能就是艾希德娜发现的尸体。也许那个巫师躲起来了。"
    tom sad apa "不过我不知道我继父是如何策划这整件事的。我母亲知道吗？"
    mc kind -bunga "只有一个方法可以知道，对吧？你应该和他们谈谈。真正地谈谈。"
    tom wry blow "我会的。我很快就给他们打电话。"
    "阿什姆拿回了他的信，小心翼翼地将它整齐地收好，仿佛那是世界上最珍贵的东西。"
    tom giggle -blow "谢谢你，[povname]。真的很感谢。"
    mc happy tanya "随时效劳。告诉我结果如何，好吗？"
    tom wry blush blow "我会的，而且，也许我们可以...不，没什么。"
    if "nembak_cuy" in tom_events:
        tom amused cling "我稍后会给你一个惊喜。"
        tom smile -cling "现在，让我送你回家吧，亲爱的。今天是个多事之日。"
    else:
        tom pfft -blow "我们应该在梅莉开始散布关于我们的谣言之前回去。"
        "阿什姆刚说完，你就从眼角看到两个顾客正在和梅莉八卦。"
        $ NPC = "???"
        scene merry_over with dissolve
        show caf chill at center with dissolve
        npc "嘿，梅莉，你觉得那两个人之间有什么吗？"
        show caf talk cling
        caf "哦，肯定有。你知道吗，有人在打赌这两个人最后会在一起。想加入吗？"
        show side_p ha at pic
        mc "啊，好吧。现在说这个太晚了。"
        hide side_p
        show side_t bebas frown at pic
        tom "说真的。这里没人管好自己的事。"
        hide side_t
    stop music
    play sound "sound/effects/cloth.mp3"
    scene merry_bar with dissolve
    "阿什姆拉着你的手，带你回到你的房间。"
    show side_p g at pic
    mc "（我希望他和家人的事情能有个好结果。）"
    hide side_p
    scene lor_mlm with fade
    play music "MUSIC/MusMus-BGM-082.mp3"
    jump ur_room
       
label arshy_date3:
    tom calm apa "这里的事情终于平静下来了，不是吗？"
   
    if girl:
        show palmierproxy chill frown at left with dissolve:
            yoffset 40
    else:
        show palmierproxy chill frown at left with dissolve:
            yoffset 100
    show tom pfft at right with move
    mc happy sigh "我想是的。至少目前如此。"
    show palmierproxy wry -sigh
    tom sad sweat frusta "别乌鸦嘴。我还在做噩梦，梦到这里的所有骚动。"
    show palmierproxy frown 
    tom sigh blow "我很惊讶我父母还没有让我退学。不过，也许他们太专注于他们的新生儿子了。"
    mc hister bunga "哦，你有了一个小弟弟？恭喜！"
    tom nyesal blow "啊，是的。这种事通常需要庆祝，不是吗？"
    show palmierproxy sweat shock
    "你注意到他似乎对有了新弟弟这件事并不太高兴。"
    "事实上，他看起来非常痛苦。"
    mc side -shock "发生什么事了吗？你看起来对整个情况并不太兴奋。"
    tom ha -blow "当然，我很高兴我母亲顺利生产，我有了新的兄弟，但是..."
    tom sigh blow "...这至少可以说是很复杂。"
    mc wry tanya "想谈谈吗？"
    tom wry -blow "如果你有时间的话。"
    mc smile -tanya "当然！就在这里？"
    tom ha blow "不，不是这里。跟我来。"
    stop music
    scene kmr_sore with w33
    $ morning = False
    $ afternoon = True
    $ evening = False
    $ night = False
    play music "MUSIC/MusMus-BGM-054.mp3"
    if girl:
        show palmierproxy chill frown at left with dissolve:
            yoffset 40
    else:
        show palmierproxy chill frown at left with dissolve:
            yoffset 100
    show tom chill frown at right with dissolve:
        yoffset 190
    "阿什姆带你来到他的房间，这个地方你现在已经很熟悉了，但是...不知怎的，你和他单独在这里的事实让你相当紧张。"
    tom talk smile "请，让自己舒服点。"
    show pboy at horzappear
    menu:
        "在床上伸展开来":
            hide pboy
            $ tom_events.append('onkasur')
            show bed_pagi behind palmierproxy with dissolve
            show tom wry both shock
            show palmierproxy smile bunga
            play sound "sound/effects/cloth.mp3"
            "你毫不羞耻地把整个身体摊开在床上，让自己舒服地躺着，同时拍了拍你旁边的位置。"
            show tom giggle blush bunga
            "阿什姆对你的行为窃笑，但他确实躺在了你旁边，你们俩一起仰望着他床上的天花板。"
            tom pfft apa "你经常在别人的床上如此自在吗？"
            show tom wry -apa
            mc happy sigh "嘿，你说让我舒服点。我只是在遵循指示。"
            mc smile -sigh "而且..."
            mc kind "我觉得你心里的事不是站着或坐着就能说清楚的。"
            mc happy "所以来吧，舒舒服服地向[nickname]倾诉你的心事。"

        "站着":
            hide pboy 
            $ ibu.points -= 5
            if ibu.points < 0:
                $ ibu.points = 0
            mc deject sigh "我想我还是站着吧，谢谢。"
            "你选择靠在旁边的栏杆上。"
            tom frown blow"随你便。"
            "阿什姆耸了耸肩。跟随你的lead，他也靠在栏杆上，双手交叉。"
            show tom -blow
            mc confused "那么，你在想什么？"
    show palmierproxy sad sweat shock
    tom capek sweat frusta "我的父母已经宣布我的弟弟为涅弗斯家族的继承人。"
    mc ew -shock "哦-哦。"
    $ tom_events.append("date3_done")
    show pboy at horzappear
    menu:
        "我很抱歉。":
            hide pboy
            tom whine -sweat blow "没关系。我预料到了，但还是有点刺痛。"
            mc wry sigh "意思是，非常刺痛。"
            tom giggle sweat frusta "啊哈哈。是啊。比我想象的还要痛。"
            
        "你不是预料到了吗？":
            hide pboy
            $ ibu.points -= 20
            if ibu.points < 0:
                $ ibu.points = 0
            show palmierproxy sad sigh
            tom whine frusta "我想是吧，但我内心的一部分还是希望，嗯...我的继父至少能承认我是他的儿子。"
            mc confused tanya"我是说，他并没有完全剥夺你的继承权，对吧？"
            tom capek "嗯，是没有，但这仍然是一个可怕的侮辱。通过宣布我弟弟是新的继承人，这几乎就像是在否认我的存在。"
            tom sad blow "他甚至不把我当作他的长子。"
            tom kzl frusta "但是...啊，我为什么要用这种话来烦你呢？"
            tom capek "你既不了解这种情况的严重性，也不了解我们的习俗。"
            show tom ha shock
            mc side sigh "我只是想说，嗯，如果他们还在支持你，那就说明他们还是在乎你的，对吧？"
            tom sad frusta "我生活中需要的不是他们的经济支持，我想要的是...我以为我想要的是..."
            tom sigh blow "算了。抱歉占用了你的时间，[povname]。"
            mc kzl shock "等等，别走—！"
            tom kzl frusta "不，我...我应该跟奎尔谈谈，或者等[povname]醒来。"
            tom sigh blow "我不该对你期望那么多。"
            tom wry -blow "对不起，但是你能让我一个人待会儿吗？"
            tom nyesal frusta "我...我需要一些独处的时间。"
            mc side sigh "好-好的。"
            show tom sad -frusta
            scene lor_mlm with w33
            "你离开了阿什姆的房间，回到了自己的房间。"
            play music "MUSIC/MusMus-BGM-082.mp3"
            jump ur_room
        "我们要杀了他吗？（开玩笑？）":
            hide pboy
            $ ibu.points += 5
            tom pfft sweat blow "小心点，如果你用错了语气，我会以为你是另一个[povname]。"
            mc apa sweat tanya "请告诉我你的[povname]不会杀婴儿！"
            tom giggle -sweat -blow "嗯，我不能确定。"
            show palmierproxy kzl shock
            "他的语气是开玩笑的，但你有一瞬间觉得他真的有一部分无法明确回答这个问题。"
            tom pfft blow "别那样看着我。信不信由你，[povname]很擅长照顾孩子，尤其是婴儿。"
            tom giggle -blow "...[povname]还有一个不太隐晦的繁衍癖好。但我想你现在可能不想知道这个。"
            mc side frusta "不，我不想。所以让我们回到你和你的问题上来，好吗？"
            mc sad -frusta "你现在感觉怎么样？"
            tom sad sweat blow "不如我希望的那么好。"
    show palmierproxy frown shock
    tom capek sweat frusta "我是说，我应该预料到的。尼弗斯家族是贵族。"
    show palmierproxy sad -shock
    tom sad -sweat -frusta "我们的地位不如英克威尔家族高，也不如贝克家族富有，但我父亲仍然有一个家族名声要维护。"
    tom nyesal "他的亲生骨肉继承一切是很自然的，但是..."
    tom sad "我曾希望他的善意，那些他称呼我为\'儿子\'和\'小王子\'的时光，真的意味着什么。"
    tom kzl frusta "那不仅仅是漂亮话或者敷衍。"
    tom sigh blow "我想，我再一次愚蠢地以为我的依恋不是单方面的。"
    tom ha -blow "我不该那么轻易地称他为\'父亲\'。"
    mc side sweat frusta "阿什姆..."
    show pboy at horzappear
    menu:
        "你仍然是他的儿子。":
            hide pboy
            mc confused tanya "你仍然是他的儿子，如果这对你来说那么重要，也许你可以和你妈妈谈谈？"
            show palmierproxy frown -tanya
            tom nyesal blow "我试过了，她说她理解我的感受，但她认为她无法改变他的想法。"
            tom sad -blow "我没有再追问。尽管他很爱她，我知道她仍然想要小心行事。"
            tom ha "害怕触碰我继父的底线，现在她已经给了他一个继承人。"

        "去他们的。":
            hide pboy
            $ ibu.points += 5
            mc grit frusta "你知道吗？去他们的！你妈妈和继父都是。他们不知道他们错过了什么！"
            show palmierproxy kzl sigh
            tom pfft blush blow "啊哈哈。谢谢你，我需要听到这个。"
        "拥抱他":
            hide pboy
            if 'onkasur' in tom_events:
                $ tom_events.append('boner_bed')
            $ ibu.points += 10
            play sound "sound/effects/cloth.mp3"
            show palmierproxy sad sigh with move:
                xalign 0.7
            "找不到合适的话说，你决定做此刻唯一能做的事。"
            "一个温暖而尴尬的，希望能给予安慰的拥抱。"
            tom chill eh both shock "哦..."
            mc ew frusta "对不起，我不知道该说什么。我不了解你们的世界或习俗。"
            show tom sad -shock
            mc sad sigh "我知道你父亲这样做很残忍，而你也一直在努力融入，证明自己的价值。"
            mc wry -sigh "更不用说你可能还因[povname]对你做的事而留下了心理创伤，但是...嗯，我在这里？"
            mc happy blush sigh "我不确定这是否意味着什么，但我就在这里。"
            tom giggle blush blow "实际上，这意味着很多。"
            show palmierproxy wry sweat
    tom sad sweat frusta "我知道渴望被接纳是很幼稚的想法。我很清楚，要在这个世界上有立足之地，我需要展示自己的价值。"
    tom capek blow "这就是为什么我如此在意自己的形象，为什么我如此渴望向世界展示我的能力。"
    tom kzl -blow "我以为我已经做到了，但却因为我来自谁的精子就被如此轻易地取代...这不公平，不是吗？"
    mc wry -sweat tanya "这确实糟透了。但也许这是一种祝福？我是说，至少现在你可以自由地做你想做的事了。"
    tom ha apa "嗯？"
    mc kind -tanya "我的意思是，你不再是继承人了，如果你觉得你父亲不承认你是他的儿子，那么你也没有必要再维护尼弗斯家族的名声了，对吧？"
    tom pfft -apa "我...我从未这样想过。我想你说得对，嗯。"
    show tom sad sweat shock
    mc kind tanya "对吧？阿什姆现在想做什么？"
    mc happy -tanya "不是作为尼弗斯家族继承人的阿什姆，不是班上最优秀的阿什姆，也不是[povname]的男朋友阿什姆。"
    mc smile "告诉我，作为你自己，你想做什么？"
    tom giggle -sweat blow "我，我想停止担心自己的形象或地位。我想研究花卉，也许更多地拥抱我的血统。"
    tom wry -blow "我想...对自己感到满意，不仅仅被成绩、财富或外表定义。只是...作为我自己。"
    tom pfft "半精灵阿什姆，达利亚的儿子，以及...不管我父亲是谁的儿子。"
    mc mock cling "那就去做吧。去他的学校，去他的其他人。"
    mc happy -cling "另外，你要知道，我从来没有因为你的外表、成绩或财富而评判你。"
    mc eiden sweat frusta "我只是被那种强烈的爱情轰炸吓到了，但除此之外，我觉得你是个很酷的人，虽然搭讪的话有点老套。"
    show palmierproxy side -sweat sigh
    tom giggle blush bunga "明白了。"
    tom smile "谢谢你，[povname]，我需要这样的鼓励。"
    mc hister bunga "随时效劳。"
    mc smile tanya "还有什么我能帮你的吗？"
    if 'boner_bed' in tom_events and "companion" not in my_events:
        tom giggle both blow "其实还有，我不知道你能不能感觉到，但是..."
        play sound "sound/effects/cloth.mp3"
        show palmierproxy both ow shock
        "随着下面的一些移动，你能感觉到有什么坚硬而抽动的东西刚刚蹭到了你的腿。"
        "一些...不太得体的东西。"
        tom pfft apa "如你所见，我现在相当\'兴奋\'。你能不能从我身上滚下去，免得我产生什么想法？"
        mc ew -shock "哦-哦！"
        show tom wry -apa
        show palmierproxy ha at center with move
        mc avoid "对-对不起！"
        "你从床上滚下来，大腿仍然蹭到他相当长的那个部位。"
        mc ow tanya "（天哪，他的到底有多长—）"
        show palmierproxy sad shock
        tom ejek blush cling "[povname]，如果你继续那样盯着看，我就要以为你想过来帮我解决这个问题了。"
        tom calm blow "除非你想欣赏这场表演，否则我觉得你最好离开。"
        show pboy at horzappear
        menu:
            "留下":
                hide pboy
                mc hister blush cling "我觉得我待在这里挺好的，谢谢。"
                show tom eh both shock
                "你内心的一部分知道离开是最好的决定。"
                show palmierproxy wry -cling
                show tom wry blush blow
                "但你身体的另一部分也已经好几周没有释放了，所以..."
                "阿什姆对此挑了挑眉。他歪着头，带着坏笑确认你的意图。"
                tom calm -blow"那好吧。"
                show palmierproxy frown both shock at left with move
                play sound "sound/effects/bump.mp3"
                show tom smile with move:
                    xalign 0.3
                "他把你拉到床上，你的头重重地砸在枕头上，他跨坐在你身上。"
                show palmierproxy malu blush -shock
                "他的双腿把你困在两侧。他轻松地脱下了裤子。"
                if girl:
                    show gcrotch with dissolve
                    galleryunlock gcrotch
                else:
                    show mcrotch with dissolve
                    galleryunlock mcrotch
                tom amused cling"请尽情欣赏这场表演。"
                show pboy at horzappear
                menu:
                    "伸手触碰他":
                        hide pboy
                        $ tom_events.append('oral')
                        "你想做的不仅仅是看，你想感受他皮肤的热度。"
                        play sound "sound/effects/cloth.mp3"
                        if girl:
                            show lickyf with vpunch
                            galleryunlock lickyf
                        else:
                            show licky with vpunch
                            galleryunlock licky
                        "他出人意料地拒绝了你这种快感，大声地拍开了你的手。"
                        if girl2:
                            tom "坏女孩，我邀请你来看，不是来摸的。"
                        else:
                            if kln:
                                tom "调皮。我邀请你来看，不是来摸的。"
                            else:
                                tom "坏男孩，我说了你只能看。我可没说你可以过来摸。"
                        tom "不过...也许如果你说\'请\'的话，我可能会被说服。"
                        show side_p s at pic
                        mc "请...？"
                        hide side_p
                        tom "请什么？亲爱的，恐怕我需要更多解释。"
                        show side_p s at pic
                        mc "请让我触碰你。"
                        hide side_p
                        tom "哎呀，多么有礼貌啊。"
                        tom "你不觉得良好的礼仪应该得到奖励吗？"
                        play sound "sound/effects/zipper.mp3"
                        scene bg_black with eye_shut
                        "..."
                    "看着我，放松":
                        hide pboy
                        "你向后靠去。阿什姆的目光始终没有离开你。然而，你对悬在你面前的其他东西更感兴趣。"
                        play sound "sound/effects/zipper.mp3"
                        scene bg_black with eye_shut
                        "..."
                "你和阿什姆共度了下午剩余的时光，缓解了一些积压的压力。"
                "几个小时后，用了许多纸巾，阿什姆护送你回到了宿舍。"
                "他的心情明显比之前轻松了许多。"
                $ night = True
                $ evening = False
                $ afternoon = False
                $ morning = False
                scene lor_mlm with w33
                if girl:
                    show palmierproxy chill kind at left with dissolve:
                        yoffset 40
                else:
                    show palmierproxy chill kind at left with dissolve:
                        yoffset 100
                show tom chill wry blush at right with dissolve:
                    yoffset 190
                mc happy blush tanya "享受你的贤者时间吗？"
                tom giggle blow "本来是的，直到你这么说..."
                tom pfft bunga "不过确实。我玩得很开心。你呢？"
                mc mock sigh "哦，我简直痛苦极了！你没听到我在你床上发出的那些呻吟声吗？"
                show palmierproxy kind bunga
                "你打趣道，希望他能注意到你语气中的讽刺。"
                tom giggle bloom "啊哈。说得好。"
                $ tom_events.append('intim')
                show palmierproxy frown shock
                tom pfft blow "不过，我希望你不要误会我的意思，[povname]。"
                tom calm -blow "你可能已经看出来了，我不是那种轻视感情的人。"
                show palmierproxy kind -shock
                tom wry "我不希望你认为你只是一个替代品，或者只是一次短暂的风流。你比那珍贵得多。"
                tom amused cling "这也是为什么今晚我没有更进一步，尽管我非常想这么做。"
                tom pfft blow "与你在一起，事情似乎有些倒退，不过我想这就是我们关系的本质，不是吗？"
                tom calm -blow "我仍然不敢相信，我们第一次见面时，我基本上是在向你宣告我永恒的爱。"
                mc hister bunga "哈哈，是啊，我们的关系确实有点混乱。但这不正是让它变得有趣的原因吗？"
                mc kind "我真的很期待看看接下来会发生什么。"
                tom wry bloom "我也是，但我希望从现在开始我们能慢慢来。我...我想更珍惜你。"
                show palmierproxy smile at center with move
                show palmierproxy malu 
                "他握住你的右手，凝视着你的眼睛，然后俯身轻轻在你的手背上印下一个吻。"
                "你忍不住脸红了。"
                if 'oral' in tom_events:
                    "尽管他之前已经用那双嘴唇亲吻过更亲密的地方。"
                else:
                    "尽管你们两个之前已经分享过更亲密的时刻。"
                tom calm blow "我现在还不敢要求你的心。我现在还不配。"
                tom wry -blow "但我确实希望了解你，[povname]。追求你，享受你的陪伴。"
                tom lega "只要你还没有选择别人，那么我的灵魂就任你探索。"
                mc hister both sigh "天啊，他又开始说那些甜言蜜语了！"
                tom amused cling "啊，我是不是应该收敛一点？我的热情对你来说太强烈了吗，亲爱的？"
                show tom wry bunga
                mc apa sweat frusta "该死！我又把心里话说出来了，是吗？"
                show palmierproxy wry sigh
                tom smile "是的，你经常这样你知道吗？我喜欢。这简直可爱极了。"
                mc malu blush -sigh "停下！我现在受不了你那充满爱意的眼神和语气！"
                tom calm "那我明天再夸你吧。" 
                tom smile blow "晚安，[nickname]。祝你好梦。"
                mc wry sigh "晚安，阿什姆。"
                hide palmierproxy with moveoutleft
                show tom giggle bloom with move:
                    xalign 0.55
                
                "你看着阿什姆倒退着走，脸上带着歪歪扭扭的笑容向你挥手..."
                stop music
                play sound "sound/effects/bump.mp3"
                queue sound "sound/effects/splash.wav"
                show teach horns shock at center with vpunch:
                    #yoffset 100
                    xalign 0.4
                    xzoom 0.9
                    yzoom 0.95
                show tom eh sweat shock
                "...然后撞上了凯普勒先生。一只手拿着一堆卷轴，另一只手拿着一杯咖啡。"
                "这是一场灾难的配方，他把所有东西都掉在了地上，深褐色的污渍染脏了刚拖过的地砖。" 
                show tom whine at right with move
                tom frusta "凯普勒先生！对不起，我-我可以修复这个！"
                show tom sad shock
                play sound "sound/effects/growl.mp3"
                stag evil cling "...阿什姆。{w}冯蒂尔。{w}涅弗斯。你要为此付出生命！"
                show tom nyesal frusta
                "你立即跑回了自己的宿舍。"
                stop music
                scene lor_mlm with dissolve
                show side_p w at pic
                mc "（很高兴认识你，阿什姆！）"
                hide side_p
                play music "MUSIC/MusMus-BGM-082.mp3"
                jump ur_room

            "离开":
                hide pboy
                mc ha sweat frusta "那么，我就不打扰你的...呃...情况了。再见！！！"
                play sound "sound/effects/tile.mp3"
                hide palmierproxy with moveoutleft
                show tom pfft blow at center with move
                "你离开房间的速度快得简直能在脚下扬起尘土。"
                "在关门之前，阿什姆露出了得意的笑容，似乎又在戏弄你。有那么一两秒，你以为他只是在和你开玩笑。"
                play sound "sound/effects/doorslam.mp3"
                stop music
                scene lor_mlm with dissolve
                "但是后来你听到的深沉呻吟声似乎证明你错了。"
                show side_p a at pic
                mc "（提醒自己，不要通过跨坐在一个男人的大腿上来安慰他！）"
                hide side_p
                "你走回自己的房间。路上其他学生一直在评论你的脸有多红。"
                "你决定把这归咎于发烧。"
                play music "MUSIC/MusMus-BGM-082.mp3"
                jump ur_room
    else:
        $ tom_events.append('slander')
        show palmierproxy eiden sweat shock
        tom ejek cling "是的，确实如此。告诉我，你觉得我给继父发一条长长的\'去你的\'短信是不是很小气和幼稚？"
        mc happy blush bloom "是的，而且是的，但成熟是被高估了的，我准备小气一回，所以..."
        "你和阿什姆度过了剩下的时间，策划着小小的报复。这一天过得非常值得。"
        stop music
        scene lor_mlm with w33
        play music "MUSIC/MusMus-BGM-082.mp3"
        jump ur_room
label arshy_filler:
    tom talk pfft apa "愿意和我一起去逛商店吗？"
    show side_p f at pic
    mc "为什么？有什么新东西吗？"
    hide side_p
    tom smile -apa "嗯，没有，但我相信他们正在烤面包，所以也算是有点新鲜事。"
    tom calm "而且，我知道你有多喜欢看人。"
    show side_p f at pic
    mc "哦，嗯。好啊。当然。"
    hide side_p
    stop music
    scene bg_black with circleirisin
    play music "MUSIC/MusMus-BGM-004.mp3"
    scene book with circleirisout
    $ NPC = "???"
    npc "你听说过肯普斯基小姐的事吗？"
    npc "啊，是的。她不是和一个大一新生搞在一起了吗？"
    npc "有人说那是爱情魔药的作用。"
    npc "这倒是很方便！"
    if girl:
        show palmierproxy scratch confused at left with moveinleft:
            yoffset 40
    else:
        show palmierproxy scratch confused at left with moveinleft:
            yoffset 100
    show tom frown at right with moveinright:
        yoffset 190
    mc ha sweat frusta "哇，每个人都这么明目张胆地谈论他们的风流韵事。"
    show palmierproxy chill confused -frusta
    tom pfft "人们喜欢八卦。这是最好的娱乐方式。"
    if "boner1" in completed_quests:
        show palmierproxy apa shock
        tom talk calm "你听说有人在伊米尔和西尔贡的饮料里放了\'告别勃起\'吗？"
        show palmierproxy frown -sweat
        tom amused cling "听说那对情侣为此大发雷霆。伊米尔以为自己阳痿了。"
        tom ejek -cling "说他要找出是谁对他做了这种事。"
        show tom smile 
        mc chill panik "哦，好吧，我对此一无所知。完全不知道。"
        tom chill pfft blow "你一边说着，一边可疑地啜饮着茶。"
        mc ew "好吧，我可能知道是谁放进饮料里的...还有谁提供了魔药，但我没有做这件事。"
        mc ha sweat "（至少不是放进饮料那部分。）"
        show palmierproxy frown -sweat
        tom smile "哈哈。没关系，没人因此责怪你，[povname]。"
        if "bye_boner" in quil_events:
            show palmierproxy ow shock
            tom amused cling "另外，你应该知道我已经在奎尔的茶里倒了\'告别勃起\'。"
            show palmierproxy eiden sweat -shock
            tom ha apa "虽然我不确定他是否喝了，因为有时我还是能听到他房间里传来呻吟声。"
            tom kzl blow "不过声音很轻，而且频率也减少了。也许我应该用更强的剂量。"
            mc kzl sweat "不！不，你真的不需要这么做！"
            mc scratch panik frusta "（该死，我忘了取消那个勃起魔药的效果！）"
            show palmierproxy chill wry -sweat -frusta
            tom ha -blow "嗯，好吧，如果你这么说的话。"
        
    else:
        tom smile cling "或者说是最好的勒索材料。"
        show tom -cling
    "说着，他拿出了一本笔记本。"
    mc confused tanya "那是什么？"
    tom scold calm blow "一本包含各种勒索材料的书。"
    mc apa -tanya "什么？"
    show palmierproxy kzl 
    tom pfft -blow "别担心，亲爱的，这本书里没有任何关于你、菲亚或红的内容。"
    tom ejek cling "我还留有一些关于奎尔的资料，但考虑到我们的历史，我相信你能理解。"
    mc side frusta "不，我不理解。你为什么会有一整本勒索材料的书？！"
    tom capek blow "为了生存。你以为我从这里毕业后怎么才能找到一份像样的工作？"
    mc ha tanya "通过努力工作？"
    if "tom_conf" not in tom_events:
        tom pfft -blow "哦，亲爱的，我很珍惜你的讽刺，尽管有时候它有点不合时宜。"

    else:
        tom pfft blow "我相信你是真心这么认为的。但在这里事情不是这样运作的。"
        show tom -blow
        mc rajuk -sweat sigh "你没有从阿贾克斯的事情中吸取教训吗？"
        tom amused cling "我吸取了。我不再诅咒别人了，现在转向更传统的勒索手段。"
        tom pfft -cling"至少目前是这样。"
        show palmierproxy frown -sigh
    show palmierproxy frown -tanya
    tom sad "每个人都知道猎巫人是一个短命的职业。"
    tom frown "高风险高报酬，但前提是你有目标。"
    tom "它适合刚开始，但不能成为你的最终目标。"
    tom amused "政治或吸血鬼所有的公司是最赚钱的。"
    tom ha "说到这个，你知道在塞维德或西奥德之外有多少公司全职雇佣精灵吗？"
    mc confused "所有公司？"
    tom kzl "三家。"
    tom sigh blow "主要是婚介服务和美容院。一些大学也对精灵开放随机职位。"
    tom wry -blow "但像凯普勒这样的图书管理员通常已经是最高职位了。"
    tom ew frusta "我为此责怪三巨头，那三位精灵领袖创造了一个国家，不过是卡斯特里贵族和吸血鬼的装饰华丽的欢愉之所。"
    tom kzl -frusta "精灵的工作就是安静地坐着，保持美丽，尽可能地取悦客人。"
    show pboy at horzappear
    menu:
        "像花魁一样？":
            hide pboy
            $ kindness -= 20
            $ honesty += 20
            $ ibu.points -= 10
            if ibu.points <0:
                    $ ibu.points = 0
            tom hip ejek blow "哼，至少你没用\'妓女\'这个词。"
            mc side sweat "对不起。"
            show palmierproxy sad - sweat
            tom talk calm -blow "没关系。我告诉过你，我母亲就是这样的。这只是她出生时的命运。"
        "像艺人一样？":
            hide pboy
            $ ibu.points += 10
            $ kindness += 5
            $ honesty -= 10
            tom chill ha "嗯，是的，有些精灵确实能达到那种地位。"
            tom frown "很多男女演员都是精灵，我想这也算是一种出路。"
            tom ew blow "但大多数最终成为陪护或夜晚的女郎。"
    tom capek frusta "精灵是美丽的生物，无论男女。虽然不如海妖漂亮，但依然美丽非凡。"
    tom pfft blow "在塞维德，我被称为丑陋的那种。"
    tom frown -blow "不过，在明亮的赌场灯光和霓虹妓院招牌中，我几乎什么都看不清。"
    mc deject -sweat tanya "听起来像拉斯维加斯。"
    tom ha apa "拉斯维加斯？"
    mc ha -tanya "哦，别在意。我的意思是听起来很无忧无虑。"
    show palmierproxy frown 
    tom scold capek "确实如此，它是所有国家中最\'放纵\'的。那里鼓励使用药物和一夫多妻制。"
    tom nyesal frusta "享乐主义者的天堂。"
    tom ha "大多数人对这种生活方式感到满意。只要保持美丽，被爱着，即使只是身体上的爱，他们也很开心。"
    tom frown -frusta "凯普勒和奈特女士是例外，尽管两人仍然保留着对浪漫八卦的偏好。"
    tom "不过，他们试图摆脱我们天生的享乐倾向。"
    mc wry "但你一点也不享乐。"
    tom talk pfft "我确实不是，对吧？我想我是大多数人所说的异类。连我自己的母亲都对我的成长感到惊讶。"
    tom giggle "不过她很高兴我逃脱了她的基因。"
    tom chill smile "我喜欢认为，我一定有个扫兴的父亲，以至于我所有应有的\'寻欢作乐的天性\'都消失了。"
    show pboy at horzappear
    $ tom_events.append("filler")
    menu:
        "你对你的父亲感到好奇吗？":
            hide pboy
            $ curiosity += 5
            $ kindness -= 5
            tom ha blow "我曾经好奇...但最近我就随它去了。"
            tom hip capek frusta "他伤了我母亲的心，这就是我需要知道的全部。"
            tom ha blow "有时候不知道你血管里流淌的是什么反而更好。"
            mc deject "嗯。我想这是对的。"
            tom calm "那么，我该走了。这之后我还有巫师历史课，我不想迟到。"
            tom talk pfft "谢谢你，[povname]，这次约会很愉快。它很...启发人心。"
            show pboy at horzappear
            menu:
                "这是\'无聊\'的礼貌说法吗？":
                    hide pboy
                    show palmierproxy wry
                    tom calm blush bloom "啊哈哈，不是。它很愉快。能够放慢脚步，放松下来真好。"
                "不用谢。":
                    hide pboy
                    mc malu blush "我也喜欢今天，感觉...很好。"
                    mc panik both "（难得没有谋杀或暴力。）"
                    show palmierproxy smile bunga
                    show tom calm 
                    "阿什姆向你微微点头。"
            tom chill pfft "我要走了。再见，[povname]。"
        "真遗憾。":
            hide pboy
            $ ibu.points -= 5
            if ibu.points <0:
                    $ ibu.points = 0
            mc happy "我想我会喜欢一个有趣的阿什姆。我知道你是团队中的\'妈妈\'，但有时候太过了。"
            show palmierproxy hister bunga
            tom sad sweat frusta "等等，你刚才是叫我\'妈妈\'吗？"
            mc kind "嗯，我是说，你有点像妈妈。没关系，每个朋友群都有一个人扮演这个角色。"
            mc panik "塞恩是婴儿，奎尔是青少年，你是妈妈，我想我是长者？"
            mc smile "我是说，我们两个都没有赢得什么，但事实就是如此。"
            tom pfft -sweat blow "嗯。我想这种动态确实很合适。你确实抱怨很多，就像个老人。"
            if "tom_conf" not in tom_events:
                tom calm "至少另一个你是这样。"
            else:
                show tom calm
                mc ha frusta "哎呀，谢谢啊。"
            tom talk smile cling "不过，我还是喜欢你。"
            show palmierproxy kind sigh
            tom pfft -cling "那么，我该走了。这之后我还有巫师历史课，我不想迟到。"
            tom calm "谢谢你，[povname]，这次约会很愉快。它很...启发人心。"
            show pboy at horzappear
            menu:
                "这是\'无聊\'的礼貌说法吗？":
                    hide pboy
                    tom giggle "啊哈哈，不是。它很愉快。能够放慢脚步，放松下来真好。"
                "不用谢。":
                    hide pboy
                    mc malu blush "我也喜欢今天，感觉...很好。"
                    mc panik both "（难得没有谋杀或暴力。）"
                    show palmierproxy smile bunga
                    show tom calm 
                    "阿什姆向你微微点头。"
            tom smile bunga"我要走了。再见，[povname]。"

        "我觉得你在虚张声势。":
            hide pboy
            tom "嗯？"
            $ ibu.points += 5
            $ honesty += 5
            mc kind "我是说，除了你的眼睛，你肯定还继承了你母亲的一些基因。"
            mc wry tanya "你内心里肯定有一部分不是爱抱怨的吧？"
            if "tom_conf" not in tom_events:
                tom hip amused cling "哦，但是，我很有趣，不是吗，[povname]？"
                show palmierproxy apa blush shock
                tom calm blow "你总是说我在床上多么狂野。"
            else:
                tom hip calm blow "哦，确实有，虽然我觉得你短期内看不到我那一面。"
                show palmierproxy apa blush shock
                tom amused cling "除非你愿意分享你的床。"
            mc scratch ha both frusta "哇，等等。冷静点。这不是我的本意。"
            show palmierproxy chill ew shock
            show tom with move:
                xalign 0.25
            tom smile cling "不是吗？我们精灵以性能力强而闻名。"
            tom ejek -cling "这也是我们血液里的东西。"
            "阿什姆笑着又喝了一口茶，然后凑到你耳边。"
            tom scold smile bunga"你想尝尝吗？"
            mc ew frusta"不，谢谢！"
            show tom hip giggle bloom at center with move
            show palmierproxy sad -frusta
            "你结结巴巴地从座位上站起来，感受到阿什姆看到你从椅子上逃开时的愉悦。"
            mc chill ha "好吧，嗯，我想我该走了。不能上课迟到。"
            tom pfft cling "回头见，[povname]。"
    scene bg_black with w20
    "当你回到宿舍时，已经是黄昏了。"
    $ evening = True
    $ morning = False
    $ afternoon = False
    stop music
    scene lor_mlm with w20
    play music "MUSIC/MusMus-BGM-082.mp3"
    jump ur_room
label arshy_date2:
    scene kls_potion with fade
    if calendar.weekday == "Sat" or calendar.weekday == "Sun":
        show tom go frown at center with dissolve:
            yoffset 190
    else:
        show tom chill frown at center with dissolve:
            yoffset 190
    tom nyesal frusta "嗯。"
    if calendar.weekday == "Sat" or calendar.weekday == "Sun":
        if girl:
            show palmierproxy jln confused at left with moveinleft:
                yoffset 40
        else:
            show palmierproxy jln confused at left with moveinleft:
                yoffset 100
    else:
        if girl:
            show palmierproxy chill confused at left with moveinleft:
                yoffset 40
        else:
            show palmierproxy chill confused at left with moveinleft:
                yoffset 100
    show tom frown shock at right with move
    mc "阿什姆？你一个人在这里做什么？"
    tom pfft -shock "哦。你好，[povname]。"
    if "bite_day" in red_events:
        tom "我在继续为红色进行研究。"
        tom sigh blow "虽然我很遗憾地告诉你，这是一项相当无果的研究。"
        if "cure_me" not in red_events and "item_obat" in known_recipes and "bonding_me" not in red_events:
            show pboy at horzappear
            menu:
                "提到治愈。":
                    hide pboy
                    mc kind blush "哦，实际上我可能有些东西可以帮上忙！"
                    tom wry shock "真的吗？亲爱的，你真的很了不起，不是吗？"
                    tom calm -shock "我有课要上，所以恐怕不能帮忙，但如果你需要什么就打电话给我。"
                    show tom smile
                    mc happy "好的，祝我好运！"
                    scene map_potion with dissolve
                    call screen potion_map 
                "和阿什姆一起度过时光。":
                    hide pboy
                    mc sad "我这边也没有好运。"
        else:
            mc sad "我明白了。"
            
    else:
        tom ha blow "只是在学习一些东西。我不得不承认，由于我的小小...发脾气，我的学习有些落后了。"
        mc hister "你是说你的情绪低落期？"
        show palmierproxy kind
        tom capek "我更喜欢称之为\'平静地沉思\'。"
        mc wry "嗯哼。"
    mc kind tanya "嘿，你需要休息一下吗？你的皱眉纹比平常更深了。"
    tom ha blow "嗯，我想休息一下是必要的。"
    tom smile -blow "你具体有什么想法？"
    mc happy -tanya "嗯，我希望你能有些主意。毕竟我只是个游客。"
    tom pfft cling "我明白了。有一个地方我们可以去。"
    scene bg_black with w20
    play music "MUSIC/MusMus-BGM-139.mp3"
    scene hill with w20
    if calendar.weekday == "Sat" or calendar.weekday == "Sun":
        show tom go smile at right with dissolve:
            yoffset 190
    else:
        show tom chill smile at right with dissolve:
            yoffset 190
    
    if calendar.weekday == "Sat" or calendar.weekday == "Sun":
        if girl:
            show palmierproxy jln confused at left with moveinleft:
                yoffset 40
        else:
            show palmierproxy jln confused at left with moveinleft:
                yoffset 100
    else:
        if girl:
            show palmierproxy chill confused at left with moveinleft:
                yoffset 40
        else:
            show palmierproxy chill confused at left with moveinleft:
                yoffset 100
    mc happy blush bloom "哇，这才叫风景呢！"
    show palmierproxy kind
    tom calm "令人惊叹，不是吗？"
    "阿什姆带你来到莱纳尔，直接到山顶上，靠近一座废弃的教堂。"
    tom smile "修女们让我们在这个村子里自由活动。不需要许可单。"
    tom frown "我相信她们以前经常来这座教堂。"
    tom sad blow "我曾经想知道谁会考虑在这样一个偏僻的地方建造教堂。"
    tom frown -blow "也许是一个有太多钱的贵族。这是一座美丽的建筑，可惜它昔日的荣光如今已被时光吞噬。"
    mc frown -blush tanya "为什么它被废弃了？"
    tom frown "这里的村民不相信女巫，即使是像科尔这样被提升为神的存在。"
    tom calm "不过，这仍然是一个很好的地方可以让人理清思绪。这里的寂静相当令人感到舒适。"
    tom ha "虽然有时我确实能听到从树林里传来的歌声。"
    $ tom_events.append("date2_done")
    mc confused -tanya "歌声？"
    tom frown "是的，一个男人的声音。没什么特别的才华，但不知怎的，我忍不住想去寻找它。可能是一只迷路的塞壬。"
    mc frown "塞壬？你怎么知道的？"
    tom pfft "我习惯了它们的吸引力。"
    tom calm "当我和母亲住在街头时，我曾与年轻的塞壬成为朋友。"
    tom smile "他们有时会给我们带来面包和水果。"
    mc apa tanya "等等，什么？我以为你母亲嫁入了一个富裕的家庭。"
    tom sad sweat blow "她确实嫁入了，但那是在我6岁之后。在那之前，我们要么在妓院里尽力生活，要么在街头艰难度日。"
    tom kzl -blow "我母亲的客户并不太喜欢我，我们经常被赶出去。"
    mc ew sweat -tanya "被赶出去？"
    show palmierproxy sad
    tom capek frusta "我无法忍受母亲被那样对待，有时我会咬她的客户，把他们吓跑。"
    show palmierproxy frown shock
    tom pfft -sweat blow "幸运的是，我母亲最终遇到了我的继父。他是个可爱的人，虽然有点无趣。"
    show palmierproxy frown -shock
    tom calm bunga "他把我母亲当成女王一样对待，把我当成亲生儿子。"
    tom ha both frusta "这其实有点尴尬，有时他叫我\'小王子\'，而且他几乎把我母亲走过的地方都当成圣地。"
    if calendar.weekday == "Sat" or calendar.weekday == "Sun":
        show pboy s at horzappear
    else:
        show pboy at horzappear
    menu:
        "一定是影响到你了！":
            hide pboy
            mc wry "这就是为什么你那样对待[povname]的原因吗？"
            tom pfft -both blow "嗯。既然你提到了，可能就是这个原因，不是吗？"
            tom giggle "我一定是认为那就是正确的爱的方式。"
            mc happy -sweat bunga "你是被爱着的。"
            tom pfft "现在是的。"
            show palmierproxy frown shock
            tom sad frusta "但是..."

        "听起来不错。":
            hide pboy
            tom sad frusta "确实如此，但我不想依赖他。"
    tom nyesal sweat frusta "如果我母亲失去了他的宠爱或者早逝怎么办？我不确定他的爱是否会延续到我身上。"
    mc deject -sigh "（啊，我猜这就是为什么他如此努力维护自己的形象和赢得青睐。）"
    if honesty>= 40 or kindness < 40:
        $ ibu.points += 5
        mc frown sigh "我是说，这种情况可能会发生。"
        mc side -sigh "（我想说这不会发生，但考虑到这个世界的道德标准...）"
        tom wry blow "我很感谢你的诚实。"
    else:
        $ ibu.points -= 5
        if ibu.points <0:
            $ ibu.points = 0
        mc panik "我怀疑你父亲会抛弃他称为\'小王子\'的儿子。"
        mc wry sigh "连我的父母都不这么叫我。"
        show palmierproxy kind -sigh
        tom wry blow "我想你说得对。"
    tom frown -blow "无论如何，即使我的继父一直陪在我身边，我也不想成为他的负担。"
    tom ha "是的，[povname]是我如此努力在生活中取得成功的主要原因，但还有其他因素。"
    mc happy tanya "听起来很复杂。你有没有想过，我不知道，让你的大脑停止思考？"
    tom sad "嗯？"
    mc smile -tanya "比如，只是享受当下，不去关心你的未来或者想象各种可能性。"
    mc kind "如果你不在乎金钱、声望和所有这些东西，你想成为什么？"
    tom giggle both "...别笑，但我想成为一名花店老板。"
    mc wry "花店老板？"
    tom ha frusta "是的，我知道这很刻板印象，不是吗？一个精灵被花朵和美丽的事物包围。"
    mc hister blush bloom "如果你能变成一个小精灵，那就太完美了。"
    mc flirt "你可以像小蜜蜂一样采集它们的蜂蜜！"
    tom capek frusta"只有纯血统的精灵才能改变体型。另外，别取笑我，我是在认真说的。"
    show palmierproxy kind -bloom 
    tom wry -both blow "我确实喜欢花朵。这就是为什么莱尔和我相处得这么好。我是说，除了我们都是混血儿之外，"
    tom frown -blow "他还是一个优秀的园丁，对植物了解很多。"
    tom ha "另一个值得考虑的职业可能是药剂大师，不过看着欧文，我开始对这个前景产生怀疑了。"
    if "desa" in buff_events or "naksir" in quil_events:
        mc confused -blush "哦，你也认识欧文吗？"
        tom "是的，我知道他在这里寻找一种植物来治愈他的失语症。"
        
    else:
        mc confused -blush"欧文？"
        tom "他是一位药剂大师，在这里寻找一种植物来治愈他的失语症。"
    tom smile "当他在这附近游荡时，我有时会试着和他交谈。"
    tom pfft "\'交谈\'是指他在他的记事本上写字，而我阅读内容。"
    tom sigh blow "显然他在卡斯特里有一家药剂店，但压力让他逃离了那里。"
    tom ha -blow "这就是为什么他在这里兼职做木偶戏。"
    tom frown "有趣的人。眼睛非常漂亮，我差点误以为他是海妖。"
    tom "但哑巴海妖是不可能存在的。"
    mc deject tanya "如果他是混血儿呢？"
    show palmierproxy frown -tanya
    tom ha "不，他的眼睛太有活力了。他是别的什么。"
    tom kzl cling "也许是巫师，但我不想妄下定论。"
    tom wry blow "总之，不要再谈论一个我几乎不认识的人了。这对约会来说不太合适。"
    mc apa both "这是一次约会吗？"
    tom sad frusta "不是吗？"
    if calendar.weekday == "Sat" or calendar.weekday == "Sun":
        show pboy s at horzappear
    else:
        show pboy at horzappear
    menu:
        "不是？":
            hide pboy
            $ honesty += 10
            $ ibu.points -= 20
            if ibu.points <0:
                $ ibu.points = 0
            mc malu sweat "我的意思是，我只是想出来玩玩。"
            show palmierproxy smile -sweat
            tom eh both shock "哦。那我误会了，我道歉。"
            tom wry -shock "我想我有时还是会把你和[povname]搞混。"
            show palmierproxy frown
            tom sad blow"来吧。那我在宵禁前送你回家。"
            stop music
            scene bg_black with w20
            "阿什姆把你送回了你的房间，他看起来有点失望。"
            "当你偷偷从门缝里瞥了一眼，你看到阿什姆从他的一个符文中拿出了一个野餐篮。"
            "他是在计划和你野餐吗？"
            $ evening = True
            $ morning = False
            $ afternoon = False
            scene lor_mlm with w20
            play music "MUSIC/MusMus-BGM-082.mp3"
            jump ur_room
            
        "是啊，但是...":
            hide pboy
            $ ibu.points += 10
            mc ha blush "我猜我以为你会带我去吃晚餐之类的。"
            tom amused cling "哦，相信我。我，我已经准备好了。"
            show palmierproxy frown shock
            play sound "sound/effects/woosh.mp3"
            "阿什姆从他的一个符文中拿出了一个大野餐篮。"
            stop sound
            tom pfft -cling "召唤符文。很适合藏这样的惊喜。"
            show palmierproxy smile shock
            tom smile cling "想来场野餐吗？"
            "你看进篮子里，看到了所有你喜欢的菜，惊讶于他竟然知道你喜欢什么。"
            "你和你的分身确实有相似的口味。"
            mc confused sweat tanya "哦等等，那是葡萄酒吗？"
            tom calm -cling "无酒精苹果酒。"
            mc hister blush bunga "那就太完美了。"
            tom giggle blush bloom "我的目标就是让你满意。"
            "你和阿什姆度过了剩下的时间，一起吃喝。"
            scene star_line with flashbulb:
                yalign 1.0 
                easein 3.0 yalign 0.0
            "当夜幕降临时，你们两个靠在一起看星星。"
            "带着满足的心情和饱腹感，他送你回到了你的房间。"
            stop music
            scene bg_black with w20
            $ evening = True
            $ morning = False
            $ afternoon = False
            scene lor_mlm with w20
            play music "MUSIC/MusMus-BGM-082.mp3"
            jump ur_room

        "这是个糟糕的选择。":
            hide pboy
            $ honesty += 10
            $ kindness -= 10
            $ ibu.points += 5
            show tom pfft blow
            mc ha both "我是说，我们至少可以去吃顿晚餐。"
            tom amused cling "哦，相信我。我，我已经准备好了。"
            show palmierproxy frown shock
            play sound "sound/effects/woosh.mp3"
            "阿什姆从他的一个符文中拿出了一个大野餐篮。"
            stop sound
            tom pfft -cling "召唤符文。很适合藏这样的惊喜。"
            show palmierproxy smile shock
            tom smile cling "想在星空下共进晚餐吗？"
            "你看进篮子里，看到了所有你喜欢的菜，惊讶于他竟然知道你喜欢什么。"
            "你和你的分身确实有相似的口味。"
            mc confused sweat tanya"哦等等，那是葡萄酒吗？"
            tom calm -cling "无酒精苹果酒。"
            mc hister blush bunga "那就太完美了。"
            tom giggle blush bloom "我的目标就是让你满意。"
            "你和阿什姆度过了剩下的时间，一起吃喝。"
            scene star_line with flashbulb:
                yalign 1.0 
                easein 3.0 yalign 0.0
            "当夜幕降临时，你们两个靠在一起看星星。"
            "带着满足的心情和饱腹感，他送你回到了你的房间。"
            stop music
            scene bg_black with w20
            $ evening = True
            $ morning = False
            $ afternoon = False
            scene lor_mlm with w20
            play music "MUSIC/MusMus-BGM-082.mp3"
            jump ur_room
label arshy_date1:
    scene merry_bar with w20
    play music "MUSIC/MusMus-BGM-007.mp3"
    if calendar.weekday == "Sat" or calendar.weekday == "Sun":
        "阿什姆带你来到戈莫拉，进入了一家时髦的酒吧。"
    else:
        "阿什姆和你偷偷溜出学校，来到了一家时髦的酒吧。"
    "整个建筑都弥漫着咖啡和各种甜点的香味。"
    show caf smile at center with dissolve
    caf "欢迎来到梅莉之夜酒吧！我是梅莉·奈特，有什么可以为您效劳的吗？"
    show caf at left with move
    show tom go smile at right with moveinright:
        yoffset 190
    caf chill shock "哦，阿什姆！很高兴再次见到你。"
    tom calm "早上好，梅莉。"
    tom pfft "请给我们安排一张双人桌。"
    caf talk -shock "这边请！"
    scene merry_over with dissolve
    "梅莉带你们到座位上，并递上了菜单。"
    "你注意到她身后有一辆服务推车，上面摆满了各种甜点和饮料。"
    show caf smile at left with dissolve
    show tom go smile at right with dissolve:
        yoffset 190
    caf talk apa "要茶还是咖啡？"
    tom calm "茶。"
    show tom smile
    show side_p ha at pic
    mc "我也一样。请给我茶。"
    hide side_p
    "当女服务员给你们倒茶时，她俯身小声说道。"
    caf chill bunga "市长和他的秘书有一腿，艾比太太被泳池男孩搞大了肚子，猎巫人加文打了一个两岁的孩子。"
    show caf smile cling
    show side_p ha at pic
    mc "哦，我不是那个意思，不过请继续说。"
    hide side_p
    show tom pfft
    tom smile "这是他们这里的一项服务。"
    caf chill bloom "在爆料之前先喝口热茶。"
    caf talk -bloom "亲爱的，还需要什么吗？"
    tom calm "伊格尼亚全套早餐。请多加些樱桃。"
    caf smile apa "亲爱的，您呢？"
    show pboy s at horzappear
    menu:
        "点一些昂贵的东西":
            $ ibu.points += 5
            hide pboy
            show side_p ha at pic
            mc "请给我贵族盛宴。"
            hide side_p
            hide pboy
            caf talk cling "哦，今天想吃点豪华的？没问题，亲爱的！"
            play sound "sound/effects/walk.mp3"
            hide caf with dissolve
            show tom pfft at center with move
            tom apa "在犒劳自己吗？"
            show side_p mal at pic
            mc "我值得这个。你说过我可以点任何我想要的。"
            hide side_p
            tom amused -apa "哦，亲爱的，别误会我的意思。我很高兴看到你的胃口有所改变。"
            tom pfft "上学期你吃得不太好，我很高兴看到情况有所好转。"

        "点一些价格适中的东西":
            hide pboy
            show side_p ha at pic
            mc "我要一份晨曦套餐。"
            hide side_p
            caf talk -apa "好的。马上就来。"
            hide caf with dissolve
            show tom frown at center with move
        "点一些便宜的东西":
            $ ibu.points -= 5
            if ibu.points <0:
                $ ibu.points = 0
            hide pboy
            show tom kzl shock
            show side_p fr at pic
            mc "只要帕尔米耶特餐就行，谢谢。"
            hide side_p
            show tom frown -shock
            caf talk -apa "马上就来！"
            hide caf with dissolve
            show tom frown at center with move
            tom sad apa "你不饿吗？"
            if povname == "帕尔米耶":
                show side_p ha at pic
                mc "我的胃在自己消化自己。所以我点了些\'我\'来填补它。"
                hide side_p
                tom pfft blow "有趣。不过说真的，你可以点任何你喜欢的。"
                show side_p g at pic
                mc "这就是我喜欢的。"
                hide side_p
                tom calm -blow "如果你确定的话。"
            else:
                show side_p fr at pic
                mc "我不太喜欢吃早餐。"
                hide side_p
                show tom sad 
                "阿什姆挑了挑眉毛看着你。"
                tom kzl apa "从什么时候开始的？"
                show side_p h at pic
                mc "（哦，[povname]以前不是这样的吗？）"
                show side_p g
                mc "只是今天没什么胃口而已，哈哈。"
                hide side_p
                tom frown -apa "...嗯。"
    show side_p sdh at pic
    mc "那么，呃，你和梅莉看起来很亲近。"
    hide side_p
    tom amused cling "我是不是听出了一丝嫉妒？"
    tom giggle -cling "别担心。梅莉已经结婚了，她之所以记得我只是因为我们有相同的血统。"
    tom pfft "不过，我承认我确实很喜欢这里。"
    tom smile "他们是在暑假期间刚开业的。去年夏天你去了奎尔那里，我发现自己大部分时间都在这里度过。"
    show side_p fr at pic
    mc "你没回家吗？"
    hide side_p
    tom pfft "我父母去度二胎蜜月了。"
    tom sigh blow "我宁愿待在空荡荡的宿舍，也不愿待在空荡荡的大宅里。"
    tom pfft -blow "况且，凯普勒陪着我。他这个时候也不能回塞维德。"
    show tom frown
    show side_p fr at pic
    mc "你要当哥哥了？"
    hide side_p
    tom ejek cling "糟糕透了，不是吗？我不知道母亲为什么会认为再生一个小恶魔是个好主意。"
    show tom calm bunga
    "他的话语尖锐，但谈起这事时却带着温柔的微笑。他其实很期待这件事。"
    show side_p ha at pic
    mc "以你们的年龄差距，人们可能会以为那是你的孩子。"
    hide side_p
    tom wry blow "别提醒我。"
    show tom smile -blow 
    show caf smile at left with dissolve
    play sound "sound/effects/plate.mp3"
    caf talk "对不起，这是您的订单。"
    hide caf with dissolve
    "你的餐点比阿什姆的先上来了。你本打算等他的餐点上来后再开始吃，但是……"
    play sound "sound/effects/lapar.mp3"
    "看来你的肚子另有打算。"
    show side_p sdh at pic
    mc "我……呃……"
    hide side_p
    tom giggle  "没关系，你可以先吃。"
    show tom blush smile bunga
    "你感激地点点头，开始享用你的餐点。"
    "味道和看起来一样好，但老实说，你等他的食物不仅仅是出于礼貌。"
    "而是为了避免在他那充满爱意的目光注视下进食。"
    show side_p k at pic
    mc "……你能不能别这样，拜托？"
    hide side_p
    show tom pfft -blush apa
    tom "别怎样？"
    show tom frown -apa
    show side_p h at pic
    mc "盯着我看。"
    hide side_p
    tom pfft "我只是在欣赏美景。再说，我一直都在看着你。"
    show side_p fr at pic
    mc "我注意到了。"
    show side_p g
    mc "听着，我就不能安静地吃顿饭吗？你让我紧张。"
    hide side_p
    tom ejek cling "哦？"
    tom calm apa "你是因为觉得不舒服而紧张？还是因为突然意识到你有多喜欢被我注视？"
    show tom pfft cling
    show side_p k at pic
    mc "（哦，这个油嘴滑舌的小——）"
    hide side_p
    show pboy s at horzappear
    menu:
        "我感到不舒服！":
            hide pboy
            tom whine frusta "我明白了。"
            $ ibu.points -= 15
            if ibu.points <0:
                $ ibu.points = 0
            tom sad blow "好吧，我们可不想那样，对吧？"
            show tom frown -blow
            "阿什姆掏出手机，开始给某人发短信，把全部注意力都集中在手机上。"
            show side_p fr at pic
            mc "你在给谁发短信？"
            hide side_p
            tom amused "阿贾克斯的父亲。看来我的那封小信起了作用。他提出在我毕业后给我一个部里的实习机会。"
            show side_p fr at pic
            mc "这是你凭实力得到的吗？"
            hide side_p
            tom cruel cling "我完全有资格胜任这份工作。不过我听说他们不得不解雇了别人来给我腾出位置。啊，好吧。"
            show tom pfft -cling
            show side_p h at pic
            mc "所以你并非凭实力得到的。"
            hide side_p
            tom capek frusta "被解雇的是基普·蒂格斯比，那个傲慢的卡斯特里家的银勺子少爷，没有众多塞壬奴隶的帮助，他早上连自己穿衣服都困难。"
            tom ejek cling "我想我比他更配得上这个职位，你不觉得吗，亲爱的？"
            show tom kzl sweat shock
            show side_p k at pic
            mc "我不是你的亲爱的。"
            show tom capek frusta
            show side_p g
            mc "（而且老实说，我对你刚才说的那个人一无所知，所以我现在闭嘴。）"
            show tom frown blow -sweat
            hide side_p

        "我可能会喜欢。":
            hide pboy
            $ ibu.points += 2
            tom giggle bloom "我是不是听到了诚实的声音？天啊……请多来一些。"
            show side_p g at pic
            mc "闭嘴。"
            hide side_p
            show tom pfft -bloom
        "我不会回答那个问题。":
            hide pboy
            show tom calm 
            $ ibu.points += 1
            tom pfft cling "这已经告诉我所有我需要知道的了。"
            show side_p mal at pic
            mc "..."
            hide side_p
    show tom frown shock
    play sound "sound/effects/plate.mp3"
    "当你继续享用你的餐点时，阿什姆的菜也上来了。"
    show tom pfft apa at right with move
    if girl:
        show palmierproxy jln kind at left with dissolve:
            yoffset 40
    else:    
        show palmierproxy jln kind at left with dissolve:
            yoffset 100
    show arshem_feed with flashbulb
    galleryunlock arshem_feed
    "你注视着他煎饼上大量的樱桃。注意到你的目光，他主动提出让你尝一口，显然希望你会接受。"
    show palmierproxy apa shock
    tom "别担心，我特意多点了樱桃。我知道你有多喜欢它们。"
    show pboy s at horzappear
    menu:
        "吃下去":
            $ ibu.points += 5
            hide pboy
            show tom lega -apa blush
            show palmierproxy smile bunga
            "你整个吞下了樱桃。"
            hide arshem_feed with dissolve
            show palmierproxy happy blush 
            "仿佛条件反射一般，你用舌头将樱桃梗打了个双结，这是你从高中学会这个技巧后养成的习惯。"
            show palmierproxy confused shock
            tom amused cling "小心点，[povname]。如果我不了解你的话，我会以为你在和我调情呢。"
            show tom -blush pfft -cling
            mc side both frusta "我没有。这只是我的一个习惯而已。"
            show palmierproxy frown -both -frusta
            tom smile "我知道。至少这个习惯比喝酒或抽烟要好得多。"


        "拒绝":
            hide arshem_feed with dissolve
            hide pboy
            $ ibu.points -= 10
            if ibu.points <0:
                $ ibu.points = 0
            show tom capek frusta
            mc wry sigh "不用了，谢谢。"
            show tom frown -frusta
            "尽管明显有些失望，阿什姆还是放下叉子，继续安静地用餐。"
    play sound "sound/effects/walk.mp3"
    show caf smile at center with dissolve
    "你还没吃完，梅莉就回来了，这次她手里拿着一小盘蜂蜜泡芙。"
    show palmierproxy confused tanya
    tom pfft apa "蜂蜜泡芙？但我没点这个啊。"
    show palmierproxy frown shock
    show tom calm -apa
    caf talk "我知道，这是店里请你的。今天是你生日，对吧？我在你的会员卡上看到了日期。"
    caf chill bloom "祝你21岁生日快乐！"
    show tom pfft blow
    show caf smile shock
    npc "不好意思，服务员？"
    caf talk -shock "哦，有人叫我了！"
    play sound "sound/effects/walk.mp3"
    hide caf with dissolve
    mc sweat apa frusta "等等，今天是你的生日？！"
    show palmierproxy side -frusta
    tom wry -blow "别担心，我知道你会忘记的。你上个月都差点忘了自己的生日。"
    mc apa tanya "我的生日是在四月？"
    show palmierproxy confused -tanya
    tom "这就是明证。"
    show palmierproxy rajuk -sweat
    mc "（所以分身并不意味着完全相同。不同的世界，不同的生日，可能还有不同的性格。）"
    show palmierproxy ow frusta
    mc "（有意思。等等，我现在不该关注这个！）"
    mc sad tanya "今天是你的生日，但你却在请我吃饭？"
    show palmierproxy frown shock
    tom calm spark "你的存在就是我能期望的最好礼物，[povname]。"
    tom pfft cling "奎尔或塞恩的任何礼物都无法相比。"
    show tom calm -cling
    mc ew both frusta "（唉，别这么说，现在你让我感觉更糟了。）"
    show palmierproxy sad sweat -frusta
    "你知道你并不是真正的[povname]，但现在并不是脱口而出的最佳时机，不是吗？"
    mc ha tanya "那么，有什么是你想让我做的吗？"
    show palmierproxy ow both shock
    tom amused cling "你可以娶我。"
    show tom giggle -cling
    mc panik -shock "呃...除此之外呢？"
    show palmierproxy wry sigh
    tom pfft "我是在开玩笑..."
    show tom calm bunga
    tom "...暂时是。"
    show palmierproxy both malu
    $ tom_events.append("date1_done")
    $ my_events.append("met_merry")
    show palmierproxy frown shock -both
    tom smile -bunga "但如果你坚持的话，嗯...我想得到你的允许留长发。"
    mc confused "什么？"
    show pboy s at horzappear
    menu:
        "你不喜欢你的头发吗？":
            hide pboy
            mc deject tanya "你不喜欢你现在的发型吗？"
            $ ibu.acara += 1
            show palmierproxy frown -tanya
            tom wry"我喜欢，是你选择了这个发型，所以我当然喜欢。但是——"
            mc apa frusta "所以你喜欢是因为我喜欢，而不是因为你自己喜欢？"
            show palmierproxy sad -frusta
            tom ha apa "这个，我...让你开心我就开心。"
            show tom frown shock
            mc side sweat sigh "但这不是我问的。"
            tom sigh blow "嗯...老实说，我确实觉得有时候维护起来有点麻烦。"
            mc frown -sigh -sweat "嗯。"
            show tom frown -blow
            "你想到了这一点，但你希望你是错的。阿什姆几乎就像一只金毛寻回犬。"
            "不是在他的举止上，而是在他的忠诚上。当然，忠诚的——我会服从你的每一个命令——男朋友听起来很可爱。"
            "但如果剥去所有的客套...那不就只是一个奴隶吗？"
            mc kind blush "你不需要得到许可去做你喜欢的事。如果你讨厌现在的发型，就改变它。"
            mc happy "去他妈的我怎么想。"
            show palmierproxy frown shock
            tom ha "..."
            mc hister sweat tanya "哦，抱歉，这话是不是太过了？"
            mc panik -tanya "（糟糕，我是不是脱离角色了？）"
            show palmierproxy frown -shock -sweat
            tom giggle "不，只是我...谢谢你。我想我需要听到这个。"
            tom pfft bunga "你变了，[povname]，是好的那种变化。"
            $ ibu.points += 10


        "你为什么需要我的许可？":
            $ ibu.acara += 1
            hide pboy
            tom ha frusta "你上次说不喜欢我留长发。"
            mc confused tanya "那又怎样？你仍然是你自己。做你想做的，阿什姆。"
            show palmierproxy kind -tanya
            tom smile -frusta "...明白了。"
        "但我喜欢你现在的发型。":
            $ ibu.points -= 20
            if ibu.points <0:
                $ ibu.points = 0
            hide pboy
            tom calm blow "我明白了。那么，我会确保保持现状。"
            show tom frown -blow
    scene merry_over with dissolve
    "令你惊讶的是，阿什姆真的没有再向你要求什么。用餐结束后，他只是吻了吻你的手，然后道别。"
    "他对\'你\'的依恋让你有些困惑。他确实有缺点，但你能感觉到他真的爱[povname]。爱得无可救药。"
    stop music
    scene city_wander with dissolve
    play sound "sound/effects/walk.mp3"
    "分别后，当你独自漫步在城市街道上时，你不禁想知道你的另一个自己是否也有同样的感受"
    "或者只是利用阿什姆的忠诚来谋取私利。"
    scene bg_black with w20
    if calendar.weekday == "Sat" or calendar.weekday == "Sun":
        play music "MUSIC/MusMus-BGM-142.mp3"
        scene town_peta with w20
        jump town_map
    else:
        scene lor_mlm with w20
        jump ur_room

label tom_to_office:
    scene hm_room with w20
    play music "MUSIC/MusMus-BGM-064.mp3"
    show tom chill frown at center with dissolve:
        xzoom -1.0
        yoffset 190
    tom smile apa "威廉校长？是阿什姆和[povname]。"
    show tom -apa at left with move
    show hm laugh shock at right with dissolve:
        yoffset 190
    hm "哦，阿什姆我的孩子，请进来！"
    scene hm_room with dissolve
    #berubah
    "当你进入房间时，你注意到自从你上次闯入以来，这里发生了变化。"
    "不知怎的，房间看起来更明亮了，而你曾触摸过的球体现在看起来比以前更加邪恶。"
    #berubah
    "是因为校长回来了吗？"
    scene hm_desk with dissolve
    show tom chill frown at left with dissolve:
        xzoom -1.0
        yoffset 190
    show hm confused apa at right with dissolve:
        yoffset 190
    hm "那么，你们两个中谁要坦白自己的罪过？"
    show hm frown -apa
    tom amused blow "很遗憾，是[povname]，校长。"
    show tom wry -blow
    hm sad "我明白了。年轻的[povname]Baker，一切还好吗？"
    show side_p he at pic
    mc "啊，什么？"
    hide side_p
    hm complain apa "你目瞪口呆。你还能控制自己的四肢吗，还是说那个女妖诅咒开始发作了？"
    show hm frown -apa
    show side_p s at pic
    mc "啊，希望不是。"
    hide side_p
    tom nyesal frusta "请原谅我朋友的愚蠢，校长。我相信[povname]有[dia]理由在您的办公室里窥探。"
    show tom ha -frusta
    show side_p w at pic
    mc "我需要为一个朋友拿点东西..."
    hide side_p
    hm wry sigh "好吧，让我们等把诅咒从你身上清除后再讨论这个问题，好吗？"
    hm talk -sigh "现在请伸出你的手。"
    stop music
    if girl:
        show siren_feather_f with flashbulb
    else:
        show siren_feather with flashbulb
    play sound "sound/effects/awal_anxiety.mp3"
    "你按照指示伸出了手。校长将一根羽毛放在你的手掌上。"
    if girl:
        show siren_feather2_f with dissolve
        hide siren_feather_f 
    else:
        show siren_feather2 with dissolve
        hide siren_feather 
    "几秒钟内，你又听到了那些耳语声。一种黑色物质开始从你的皮肤渗出。" 
    if girl:
        show siren_feather3_f with dissolve
        hide siren_feather2_f 
    else:
        show siren_feather3 with dissolve
        hide siren_feather2
    "羽毛吸收了所有的黑色物质，变成全黑色，然后化为灰烬。"
    if girl:
        hide siren_feather3_f with dissolve
    else:
        hide siren_feather3 with dissolve
    show tom frown
    hm ketawa "事情已经完成了。孩子，你感觉如何？"
    show hm wry
    show tom kzl shock
    show side_p s at pic
    play sound "sound/effects/bump.mp3"
    mc "其实有点晕。哦——！"
    hide side_p
    hide hm with dissolve
    show tom frown at center with move
    stop music
    play sound "sound/effects/cloth.mp3"
    tom pfft "别担心，我扶着你。"
    scene hm_couch with dissolve
    play music "MUSIC/MusMus-BGM-092.mp3"
    "阿什姆在你倒下之前接住了你，把你放在最近的沙发上。"
    "你想要抗议，但似乎无法集中力气这么做。"
    "当你躺下时，你看到天花板上布满了星座符号。"
    "你想知道这些符号现在作为符文是否有了更深的含义。"
    "当你陷入沉思时，阿什姆轻轻抚摸你的头发来安抚你。"
    "很明显，阿什姆非常了解你，因为他触碰到了你所有喜欢的地方。"
    scene hm_couch3 with dissolve
    show hm wry at right with dissolve:
        yoffset 190
    hm talk "来，吃块蜂蜜糖来缓解疼痛。"
    hm ketawa "我相信你也会喜欢的，阿什姆。请尝一块。"
    show hm smile
    show tom hip frown at left with dissolve:
        xzoom -1.0
        yoffset 190
    tom kzl "..."
    tom calm chill "不用了，谢谢您，先生。"
    if not girl:
        galleryunlock siren_feather
        galleryunlock siren_feather2
        galleryunlock siren_feather3
    else:
        galleryunlock siren_feather_f
        galleryunlock siren_feather2_f
        galleryunlock siren_feather3_f
    show tom frown
    "不知为何，阿什姆看起来有那么一瞬间很恼火。"
    show pboy at horzappear
    menu:
        "拿一块":
            hide pboy
            $ InvItem(*item_caramel).pickup(1)
        "重新躺下":
            hide pboy
            pass
    show side_p s at pic
    mc "刚才发生了什么？"
    hide side_p
    hm talk "祝福羽毛吸收了女妖诅咒并治愈了你。"
    show hm frown
    tom frown blow "原谅我的冒昧，先生，但您为什么会拥有这些神器？塞壬羽毛不是非法持有品吗？"
    tom ha -blow "而且女妖之悲被认为是一种黑暗神器，不是吗？"
    show tom frown 
    hm ketawa "是的，都是。年轻的阿什姆，你一如既往地细心。"
    hm bet "不幸的是，我对塞壬及其女妖对应物有点着迷，你看。"
    hm mock cling "它们都是人类和鸟类的混合体，能用歌声诱惑我们，但一种能造成即刻死亡，而另一种则能使我们免于这种命运。"
    hm laugh -cling "触发因素是什么？是什么让一个奇迹治愈塞壬变成了散播悲伤的女妖？"
    hm complain "还有一个事实是，有些塞壬根本无法治愈，只能迷惑听到它们歌声的人，让他们听命行事。"
    hm bingung sigh "我们不知道的还有很多，但时间却如此有限。"
    tom sad scold frusta"很有趣，先生，但我认为这并不是在校园里保存如此危险物品的理由。"
    show tom talk frown -frusta
    hm wry -sigh "只有当人肆无忌惮地触碰不属于自己的东西时才会变得危险。现在，年轻的Baker，你感觉好些了吗？"
    show side_p f at pic
    mc "嗯，我想是的。"
    hide side_p
    "你坐了起来。眩晕感现在已经消失了。"
    show pboy at horzappear
    menu:
        "询问关于地球仪的事":
            hide pboy
            show hm_sphere with dissolve
            show side_p s at pic
            mc "我觉得你需要在那个地球仪上贴个警告标签。"
            hide side_p
            hide hm_sphere with dissolve
            hm complain sigh "好吧，说实话，我的孩子，没有我的允许，任何人都不应该进入我的办公室。"
            hm sad -sigh "我很惊讶你没有听到那些低语。那应该是一个明显的警告，你不这么认为吗？"
            tom pfft blow "[povname]一直是个好奇心旺盛的人。他们就是忍不住要冲进未知的领域。"
            show tom talk giggle -blow
            hm ketawa "哦，是的，确实如此。"
            show side_p he at pic
            mc "（你们能不能别像我不在这里一样谈论我？）"
            hide side_p
            $ topics.append("curios")
            play sound "audio/success.mp3"
            "新话题：{color=#FF1500}你的好奇心。{/color}"
            $ curiosity += 20
            hm talk "好吧，那么这次小小的失误我就不追究了，因为你的好奇心差点占了上风，[povname]。"
            hm wry "但请在近期内不要再擅自闯入我的办公室。如果你需要什么，我随时都在。你只需要敲门就行了。"
            show side_p f at pic
            mc "当然，先生。"
            hide side_p

        "询问关于海妖的事。":
            hide pboy
            show side_p he at pic
            mc "那根羽毛，为什么它会变成灰尘？"
            hide side_p
            hm sad sigh "恐怕女妖的诅咒对它有限的治愈能力来说太强了。那根羽毛来自一只相当年轻的海妖，不是完全成熟的。"
            hm complain -sigh "我听说受祝福的海妖之歌几乎可以治愈任何东西，甚至可以重新长出四肢和整个人类大脑。"
            hm scowl "但它们如此稀有和难以捉摸，只有少数人成功追踪到它们。"
            hm confused "更不用说一些猎人会公然杀死它们来获取羽毛，因为这些羽毛在市场上能卖出高价。"
            show hm frown
            tom sad scold blow "而那些没有治愈能力的海妖则简单地被变成奴隶。"
            $ topics.append("sirens")
            play sound "audio/success.mp3"
            "新话题：{color=#FF1500}海妖。{/color}"
            show tom frown -blow
            hm wry "啊，是的，这也是。"
            hm mock "但是，唉，这就是自然规律。它们还能有什么用处呢？"
            show hm wry
            tom hip kzl "..."
            tom kzl frusta "我还是觉得这很不得体，先生。周围有这样的怪异之物。事实上，您的手杖不就是一只完全鸟形态的海妖的头骨吗？相当可怖。"
            hm laugh "那是假的，但我理解你的担忧。如果你担心的是这个，我对仙子没有任何兴趣。啊哈哈！"
            show hm smile
            show tom smile -frusta sweat
            "你可以看到阿什姆的嘴唇在抽搐，但他仍然试图摆出那副商业化的微笑。"
            tom -sweat amused "{i}有趣{/i}，先生。"
            show tom smile
            hm talk "好吧，那么这次小小的失误我就不追究了，因为你的好奇心差点占了上风，[povname]。"
            hm wry "但请在近期内不要再擅自闯入我的办公室。如果你需要什么，我随时都在。你只需要敲门就行了。"
            show side_p f at pic
            mc "好的。"
            hide side_p
        "离开":
            hide pboy
            show side_p s at pic
            mc "我只想离开。"
            hide side_p
            hm complain "可以理解。这次小小的失误我就不追究了，因为你的好奇心差点占了上风，[povname]。"
            hm wry "但请在近期内不要再擅自闯入我的办公室。如果你需要什么，我随时都在。你只需要敲门就行了。"
            show side_p f at pic
            mc "好的。"
            hide side_p
    scene map_classes1 with dissolve
    stop music
    play sound "sound/effects/doorslam.mp3"
    play music "MUSIC/MusMus-BGM-146.mp3"
    "当你走出校长室时，阿什姆开始小声嘀咕。"
    show tom scold capek frusta at center with dissolve:
        yoffset 190
    tom "种族主义的老顽固。"
    show tom kzl
    show pboy at horzappear
    menu rasis:
        "他看起来很友善。":
            hide pboy
            $ honesty += 5
            tom pfft blow "哼，说得好，[povname]。"
            show tom kzl shock
            show side_p he at pic
            mc "我不是在讽刺，怎么了？"
            hide side_p
            tom ha hip apa "你没听出他给我蜂蜜棒棒糖时的语气吗？"
            show side_p f at pic
            mc "你不喜欢蜂蜜棒棒糖？"
            hide side_p
            tom capek frusta "我是四分之一的仙子，当然我喜欢。但这并不意味着我希望他假定我喜欢它们！"
            show side_p w at pic
            mc "现在你就像个孩子一样。"
            hide side_p
            tom talk kzl -frusta "哦？你不觉得他那根崭新的海妖头骨手杖很令人不安吗？"
            if "sirens" in topics:
                show side_p he at pic
                mc "他说那是假的。"
                hide side_p
                tom ha apa "你相信他？"
            tom capek frusta "那根手杖不可能是假的。眼睛的颜色可能有点不对，但形状太准确了。"
            tom kzl -frusta "那东西一定是真的头骨，肯定是。"
            tom ew "我讨厌他假装那种温暖友善的微笑，那只是为了降低人们的警惕，让他们按他的意愿行事！"
            show tom capek
            show side_p w at pic
            mc "（看看是谁在说话。）"
            hide side_p
            tom ha frusta "至少我是故意这么做的。"
            show side_p se at pic
            mc "（哦，好吧，至少你有自知之明。）"
            hide side_p
            tom hip capek -frusta "他自然而然地这么做，就像呼吸一样容易。我不信任他。"
            play sound "sound/effects/walk.mp3"
            scene map_classes1 with dissolve
            "尽管突然间气氛变得紧张，阿什姆还是送你去上课，并坚持要你在进教室前喝点水。"


        "你也好不到哪去。" if "curios" in topics:
            hide pboy
            show tom hip sad shock
            tom whine talk sweat frusta "这就是你对我的看法吗，[povname]？"
            $ ibu.points = 0
            $ kindness -= 10
            show tom sad -frusta
            "他看起来真的被你的评论伤到了。他真的那么不喜欢校长吗？"
            show side_p m at pic
            mc "你们谈论我的时候，就好像我根本不在场一样。"
            hide side_p
            tom -sweat "我只是想为你掩护，缓解一下局面。"
            tom kzl scold "他现在看起来可能很随性，但我知道他生气时会是什么样子。我只是想保护你。"
            show side_p c at pic
            mc "好吧，谢谢，但我能照顾好自己。"
            hide side_p
            tom hip sigh blow "...明白了。"
            $ tom_events.append("brantem")
            play sound "sound/effects/walk.mp3"
            scene map_classes1 with dissolve
            "尽管突然间气氛变得紧张，阿什姆还是送你去上课，并坚持要你在进教室前喝点水。"


        "{s}你也好不到哪去。{/s}" if "curios" not in topics:
            
            jump rasis
        "是因为那个头骨的事吗？" if "sirens" in topics:
            $ curiosity += 5
            hide pboy
            tom talk kzl frusta "是所有的事。从他说话的方式到他提到那些海妖和女妖时，好像它们只是实验对象一样。"
            tom capek "我理解它们在等级上低于我们，仅仅因为它们被认为是\'野蛮人\'，但它们仍然是部分人类。"
            tom scold ha blow "他不应该那么粗鲁地谈论它们。"
            show side_p f at pic
            mc "确实如此。"
            show side_p s
            mc "（老实说，我也不太喜欢他刚才的说话方式，但我不确定\'[povname]\'会有什么反应。）"
            if not girl2:
                show side_p f
                mc "（我希望猎巫人[povname]有一本日记之类的东西，这样我就能更好地理解[dia2]了。）"
            else:
                show side_p f
                mc "（我希望猎巫人[povname]有一本日记之类的东西，这样我就能更好地理解[dia]了。）"
            show side_p w
            mc "嘿，呃，阿什姆。"
            hide side_p
            tom hip frown apa"怎么了？"
            show side_p se at pic
            mc "呃...我忘了，我们曾经交换过日记吗？"
            hide side_p
            tom pfft -apa "日记？你是说像我们在中学时你给我发的那些加密笔记吗？"
            show side_p w at pic
            mc "是-是啊，就像那样。嘿，告诉我，你最喜欢哪一个？"
            hide side_p
            tom frown shock "我最喜欢的？"
            tom talk lega bunga "嗯...我想是你说你很幸运有我，并且你不可能要求一只更忠诚的狗的那个。"
            show side_p s at pic
            mc "等等，我把你叫做狗？"
            show side_p m
            mc "而你对此没意见？！"
            hide side_p
            tom pfft -bunga "哦，如果是其他人说的话我会很讨厌，但我知道你并无恶意。"
            tom giggle "况且，我自己也把你叫做猫，记得吗？因为你很像猫，高冷，优雅。"
            show tom smile
            show side_p s at pic
            mc "（是啊。有什么告诉我，我说那话的意思和你理解的不太一样，伙计。）"
            show side_p he
            mc "那...你给我发的笔记呢？有什么令人难忘的吗？"
            hide side_p
            tom lega chill blow blush "就是我说我爱你，而你说你也喜欢我的那个。"
            tom pfft -blow "我记得我让你把一个字母改成\'o\'。"
            show side_p w at pic
            mc "我\'喜欢\'你？"
            hide side_p
            tom lega bloom "那时候我的拼写不是很好，但你帮我提高了很多。"
            show side_p he at pic
            mc "（哦。这个人陷得很深啊。阿什姆，你这个可怜的、绝望的浪漫主义者。）"
            show side_p s
            mc "（不过你的故事确实给了我一些可以寻找的线索。）"
            show side_p f
            mc "（也许我的替身在[dia]的手机里保存了笔记或日记？）"
            hide side_p
            "你翻看了你的手机，果然发现了一个叫做日记条目的文件夹。然而，它被密码锁住了。"
            show side_p f at pic
            mc "嘿阿什姆，我有没有可能告诉过你我手机的密码或类似的东西？"
            hide side_p
            tom frown -blush apa "嗯？你又忘记密码了吗？为什么不重置一下呢？"
            show side_p f at pic
            mc "它不让我重置，现在我无法访问我的日记文件夹了。"
            hide side_p
            tom -apa "哦，好吧，也许杰里米知道。我记得你们曾经为了文学作业交换过日记。"
            tom kzl "以杰里米的性格，他可能在花园或者商店附近。那个人有太多空闲时间了。"
            show side_p se at pic
            mc "好的，谢谢。"
            hide side_p
            tom giggle blush bunga "不客气。也许我们以后可以再次交换日记，就像以前一样。"
            
            $ add_new_quest("diari1")
            python:
                if len(new_quests) > 0: #if we have new quests
                    for i in new_quests:
                        active_quests.insert(0, i) #add to top of the quest list
                    new_quests = [] #now reset the new quest list, since they all got added
            show screen completedtask("新任务！")
            
            "当你陷入沉思时，阿什姆把你送到了你的下一堂课，然后他自己去上课了。在进教室之前，他还给了你一些水喝。"
            play sound "sound/effects/walk.mp3"
            scene map_classes1 with dissolve
            jump red_herb
        "{s}是因为那个头骨的事吗？{/s}" if "sirens" not in topics:
            
            jump rasis
    scene bangku_kls with fade
    show red point cowo bloom at center with dissolve:
        yoffset 330
    "当你走进下一堂课时，你看到塞恩朝你咧嘴笑着，炫耀他的尖牙。"
    stop music
    jump red_herb

#####QUILL EVENTS
label quil_date_check:
    if "date3_done" in quil_events and "date4_done" not in quil_events and "date3_fail" not in quil_events:
        jump quil_date4
    elif "mancing" not in quil_events and "date2_done" in quil_events:
        jump quil_fish
    elif bff.points >= 15 and "date1_done" in quil_events:
        if "date2_done" not in quil_events and "mey_kill" in my_events:
            jump quil_date2
        else:
            if "filler1" not in quil_events:
                jump quil_filler1
            else:
                if datingplace == "Church":
                    play music "MUSIC/MusMus-BGM-007.mp3"
                    scene climb with dissolve
                    $ datingplace = "sklh"
                elif datingplace == "Arena":
                    scene outer with dissolve
                    $ datingplace = "sklh"
                else:
                    scene cofi with dissolve
                    $ datingplace = "bebas"
                hide screen cal
                $ quick_menu = False
                $ daterp = 40
                $ turnsleft = 3
                $ skinshiparea = ""
                $ config.rollback_enabled = False
                $ renpy.block_rollback()
                $ datingname = "奎尔"
                jump startdate
                
    elif "date1_done" not in quil_events:
        jump quil_date1
    else:
        if datingplace == "Church":
            play music "MUSIC/MusMus-BGM-007.mp3"
            scene climb with dissolve
            $ datingplace = "sklh"
        elif datingplace == "Arena":
            scene outer with dissolve
            $ datingplace = "sklh"
        else:
            scene cofi with dissolve
            $ datingplace = "bebas"
        hide screen cal
        $ quick_menu = False
        $ daterp = 40
        $ turnsleft = 3
        $ skinshiparea = ""
        $ config.rollback_enabled = False
        $ renpy.block_rollback()
        $ datingname = "奎尔"
        jump startdate
        
label quil_parting:
    stop music
    play sound "sound/effects/walk.mp3"
    $ quil_events.append("quil_pisah")
    play music "MUSIC/MusMus-BGM-008.mp3"
    scene church with flashbulb:
        xalign 0.5 yalign 1.0
        easein 3.0 yalign 0.0
        easein 3.0 truecenter zoom 0.5
    "奎尔和你偷偷溜到了镇子郊外的一座教堂。你从梦中认出了这个地方。"
    stop sound
    if girl:
        show palmierproxy scratch apa at left with dissolve:
            yoffset 40
    else:
        show palmierproxy scratch apa at left with dissolve:
            yoffset 100
    show quil datar at right with dissolve:
        yoffset 200
    mc ha sweat tanya "这不就是你残忍杀害那个巫师并让[povname]陷入昏迷的地方吗？"
    show palmierproxy chill avoid -tanya
    quil ow frusta "呃，你本可以选择更好的措辞，你知道吗？"
    show palmierproxy wry -sweat
    quil flashy wink cling "也许可以说成...命运的第一步，我们在这里相遇。"
    show quil skul err shock
    mc panik sigh "不，你阻止了一场婚礼，把那个婊子烧成了灰，我可不会那么说。"
    show palmierproxy smile bunga
    quil sulk "唉，你有时候真难伺候。"
    if "companion" in quil_events:
        quil mock sigh "你很幸运我爱你！"
        show quil amused -sigh
        mc scratch sweat panik sigh "是吗？我觉得我只是将就了。或者这只是典型的斯德哥尔摩综合症。"
        show palmierproxy chill hister blush -sigh
        quil grit sweat frusta "[povname]！！！"
        show quil tantrum -sweat sigh
        mc happy bunga "开玩笑的，开玩笑的，我也爱你，奎尔。"
        show palmierproxy at center with move
        show quil wry blush sigh
        "你轻啄他的脸颊以示安慰，他的脸比番茄还红。"
        quil malu bloom "呃！"
        mc mean cling "（我永远不会厌倦这个。）"
        mc happy tanya "那么我们来这里到底要做什么？"
        quil heh -blush -sigh "嗯，我本来想发表一番演讲。"
    else:
        quil groan frusta "而我本想发表一番美好的离别演说，歌颂你的美德。"
    mc confused sweat tanya "演讲？"
    show palmierproxy frown -sweat shock
    quil talk blush cling "是的！"
    quil panik -cling "你知道，我对你并没有太多期待。"
    quil laugh "你来这里只是作为[povname]的替代品，不多也不少。"
    show palmierproxy malu blush sigh
    quil flashy hister cling "我没想到会爱上你的魅力、你的智慧和你的机智。"
    show palmierproxy wry -sigh
    quil amused sigh "更没想到会喜欢上你那令人恼火的救世主情结，只为了看到你的妹妹——虽然她并不是你真正的妹妹——开心。"
    quil laugh -sigh "为了看到菲亚幸福。"
    quil panik bloom "我没想到你会悄悄潜入我的心里。然而你做到了，而且轻而易举。"
    quil hister "你杀死了众神，"
    if "date4_done" in quil_events:
        show quil amused sigh
        extend "让我摆脱了家族的束缚，拯救了伊格尼亚的罪孽。"
    else:
        show quil talk sigh
        extend "解开了墨水的谜题，拯救了伊格尼亚的罪孽。"
    quil hister -sigh "你...你是个奇迹，[povname]。"
    show palmierproxy smile
    quil talk "我想要感谢你。感谢你对我的耐心，感谢你的配合，感谢你做的一切。"
    if "companion" in quil_events:
        quil sly "如果不是因为你，我想我不会有勇气反抗我的父亲。"
        quil panik both "当然，有些人可能会认为我逃到另一个世界是懦弱的表现，但是...我做得还不错，对吧？"
        quil laugh blush "我摧毁了我家族的遗产，佩纳会抹去我们祖先剩余的恶行。慢慢地但肯定地，我们会为我们的罪孽赎罪。"
        play sound "sound/effects/cloth.mp3"
        show quil datar behind palmierproxy with move:
            xalign 0.6
        show palmierproxy kind shock with move:
            xalign 0.4
        "奎尔握住你的手，将它拉到唇边亲吻。"
        play sound "sound/effects/walk.mp3"
        show church:
            parallel:
                truecenter zoom 0.5
                easein 4.0 truecenter zoom 1.0
            parallel:
                easein 0.4 yoffset 12
                easein 0.4 yoffset 0
                easein 0.4 yoffset 12
                easein 0.4 yoffset 0
                easein 0.4 yoffset 12
                easein 0.4 yoffset 0
        "然后他牵着你的手，沿着过道走向祭坛。"
        show palmierproxy wry -shock
        quil wry -blush sigh "再见了，科尔，再见了，伊格尼亚。再见了，你们这个充满奇迹，同时也充满痛苦和绝望的世界。"
        quil panik -sigh "我希望你们能原谅这个愚蠢男孩的罪过，我感谢你们赐予我心爱之人这个奇迹。"
        quil laugh bloom "感谢你赐予我的[povname]。"   
    else:
        quil laugh bloom "你是一个很棒的朋友，[povname]。我肯定会想念你，直到我生命的最后一天。"
    mc malu blush sigh "哦，奎尔。"
    if "companion" in quil_events:
        show quil smile
        show palmierproxy smile bunga
        "你拥抱了奎尔，你们两个沐浴在祭坛的庇护之下。"
        "感谢奎尔与你同行，为你永远离开他的世界。"
        mc happy "我爱你，奎尔。"
        quil talk "我也爱你。"
    else:
        mc hister bunga "我也会想念你的，你这个小捣蛋鬼。"
        show quil hister
    scene church with dissolve:
        truecenter zoom 1.0
    "你们两个在教堂里待了一会儿，向科尔表示敬意，然后回到了宿舍。"
    stop music
    play sound "sound/effects/walk.mp3"
    scene bg_black with w20
    $ NPC = "???"
    stop sound
    $ NPC = "???"
    scene bg_black with w20
    jump jaga_jaga
    

label quil_date4:
    $ quil_events.append("date4_done")
    "当奎尔告诉你他已经处理了他的家族问题时，你本以为会被带到一座着火的豪宅。"
    "或者是一个战场，奎尔在那里向他的父亲发起了决斗。"
    play music "MUSIC/MusMus-BGM-035.mp3"
    scene entry with w20
    if girl:
        show palmierproxy jln kind at right with moveinright:
            xzoom -1.0
            yoffset 40
    else:
        show palmierproxy jln kind at right with moveinright:
            yoffset 100
    show quil libur smile at left with moveinleft:
        yoffset 200
    "你没想到的是，梅扎的旧俱乐部现在由一个更加活泼开朗的莱利经营。"
    show waiter gold smile at center with dissolve:
        yoffset 200
    npw laugh bunga "[povname]，奎尔，欢迎光临！"
    mc hister shock "莱利！你没事真是太好了！"
    npw smile sigh "我当然没事，迪特里希先生照顾我们很好。"
    mc frown tanya "我们？"
    show palmierproxy kind -tanya
    show quil amused
    npw talk bunga "所有在这里工作的小伙子和姑娘们。我们现在有医疗保险了，还包括牙科！"
    if "help_me" in my_events:
        npw laugh cling "这一切都是因为你，[povname]！谢谢你帮助我！"
        mc malu blush sigh "不用客气，我只是很高兴看到你安全。"
    else:
        npw laugh cling "我很高兴迪特里希先生的贪婪本性没有改变。一旦你们打败了梅扎，我立即给他发了一封信，他马上就接管了这个地方。"
    npw smile -cling "总之，我能为你们两位准备些什么吗？是有什么特别的场合吗？当然，这次我请客。"
    npw talk sigh "但别告诉迪特里希！"
    quil laugh blush bunga "给我们一个惊喜吧，莱利，当然是不含酒精的。"
    npw smile cling "没问题，无酒精鸡尾酒马上就来！"
    play sound "sound/effects/walk.mp3"
    scene booth_view with dissolve
    "当莱利带你们去VIP包厢区时，你注意到俱乐部依然像以前一样拥挤，但这次人们实际上在互相交谈。"
    stop sound
    "而不只是把钱花在酒水上或者给梅扎。这次有一支真正的爵士乐队在演奏，你可以看到人们在中央舞台上跳舞。"
    if girl:
        show palmierproxy jln kind at right with moveinright:
            xzoom -1.0
            yoffset 40
    else:
        show palmierproxy jln kind at right with moveinright:
            yoffset 100
    show quil libur datar at left with moveinleft:
        yoffset 200
    quil sly cling "迪特里希把这里改造成了一种地下酒吧。在卡斯特里的客户中很受欢迎。"
    quil talk -cling "人们可以通过画一个特定的符文来进入这个地方，不再是只有邀请才能进入的情况。"
    quil laugh "它不那么独家了，但带来了一批新的客户。吸血鬼、精灵、狼人，应有尽有。"
    mc happy sigh "迪特里希一定很高兴，这里人满为患。"
    show palmierproxy kind -sigh
    quil panik sigh "哦，他确实很高兴。我很确定他很快就要退休了。我不知道我是该为那个贪婪的混蛋高兴还是恼火。"
    mc smile tanya "所以我们是来庆祝他退休的吗？"
    show palmierproxy wry -tanya
    quil ejek sigh "哦拜托，我才不会屈尊去庆祝那个人呢。"
    quil laugh blush bunga "不，我带你来这里，是因为——"
    $ NPC = "???"
    show quil groan sweat shock
    show palmierproxy confused sweat shock
    npc "奎尔·英克威尔！" with vpunch
    "一个矮小、浮夸的蓝发男子，涂着黑色指甲油，走过来搂住了奎尔的肩膀。"
    show quil tantrum frusta
    show palmierproxy wry -shock
    "当奎尔看清那个陌生人的脸时，厌恶的表情闪过他的脸庞。"
    quil sly -sweat cling "伊恩。真巧在这里见到你。我以为这地方会超出你的价格范围。"
    $ NPC = "伊恩"
    show quil err sweat shock
    show palmierproxy kzl shock
    npc "噗，哈哈哈哈，以前我会被冒犯到，伙计，但你不是刚被断绝关系吗？我听说你炸毁了你家人的一座豪宅。"
    npc "你终于崩溃了还是怎么的，奎尔？"
    mc apa tanya "等等。倒回去。奎尔，你炸了你父亲的家？！"
    show palmierproxy sad -tanya
    show quil sulk frusta
    npc "哦，他确实这么做了，而且他正式被那些英克威尔势利鬼断绝了关系。摆脱他们真是太好了，对吧，奎尔？"
    npc "嘿，听着伙计。如果你需要工作，我随时可以用一个新的女仆或水管工来清理我的垃圾，我只是说说而已。"
    stop music
    play sound "sound/effects/bang.mp3"
    show quil ejek -sweat cling
    show palmierproxy frown -sweat shock
    "奎尔从那个男人的手臂中挣脱出来，以一种方式扭转他的手臂，如果再用力一点肯定会折断那个人的手腕。"
    npc "哎哟，哎哟，哎哟！"
    quil laugh spark "谢谢你的提议，杰弗里，我一定会好好考虑的。" 
    show quil sly
    npc "我是开玩笑的，伙计，放手！放手！"
    show quil tantrum sigh
    show palmierproxy confused -shock
    "奎尔放开了他，那个人立即开始狂奔离开，另一只手捂着奎尔刚才抓住的地方。他痛苦地皱着脸。"
    mc apa sweat tanya "奎尔？"
    quil fluster sweat frusta "呃呃呃，这根本不是我想要这一天发展的方式！"
    play music "MUSIC/MusMus-BGM-092.mp3"
    quil sulk "我本打算带你跳舞，喝点饮料，然后告诉你我已经从家族中解放出来了——"
    mc eiden -tanya "通过把他们的房子烧成平地？"
    show palmierproxy confused 
    quil cringe sigh "我父母不在里面，只有所有的血液样本和研究资料。"
    quil laugh -sigh "我们也疏散了工作人员。"
    mc frown tanya "我们？"
    quil talk blush cling"我和佩纳，看？"
    show bom_q with flashbulb
    galleryunlock bom_q
    "奎尔俯身向你展示了一张照片，照片中奎尔和佩纳都比着剪刀手，对着镜头微笑。背景中一座豪宅正在随意地燃烧。"
    hide bom_q with dissolve
    mc ha both sigh "嗯，你们两个看起来玩得很开心。"
    quil ejek -blush cling "哦，确实如此，我得以向我父亲竖中指。那感觉简直令人兴奋！"
    mc eiden frusta "比烧毁一座房子还兴奋？你这个彻头彻尾的怪人。为什么你总是非零即百？"
    show palmierproxy malu -both sigh
    quil wink blush spark "为此感到自豪，亲爱的。做事情半途而废有什么意义？"
    mc happy tanya "所以你真的做到了？你清除了所有的血液样本？"
    show palmierproxy kind -tanya
    quil talk -blush sigh "是的，我永远摆脱了英克威尔这个姓氏。"
    quil panik sweat -sigh"我被家族断绝关系，一贫如洗。不过也不完全是，佩纳设法帮我保住了一大笔家族财富。"
    if "companion" not in my_events:
        quil laugh blush spark "我相信这笔钱对我们未来的事业会很有用。"
        mc apa tanya "我们的？"
        show palmierproxy frown shock
        quil wink cling "是的，我们的。亲爱的，你不会以为我会留在这里吧？"
        quil panik sweat -cling "尤其是在我刚刚给自己背上了一个闪着霓虹灯的通缉标记之后。"
        quil -sweat talk "不，我会和你一起逃到你的世界。用我的陪伴来恩赐你。"
        quil malu both "...如果你想要的话。"
        show quil err shock
        mc mock cling "等等，你居然给我选择的机会？！真是个奇迹般的日子！"
        show quil wry sigh
        show palmierproxy smile -cling
        "你打趣道，而奎尔对你的嘲弄语气报以一笑。"
        quil ow sweat frusta "我知道我一直都很...坚持我的请求。我真的很感谢你对这一切的耐心。"
        if "naksir" in quil_events:
            quil panik sigh "我知道我之前向你表白过，你说我可以保留我的感情，继续培养它们。"
            show palmierproxy frown shock
            quil sad -sigh "但我觉得你还没有明确地表达过你对我的感觉。"
            quil wry both apa "至少在长远来看是这样。[povname]，你想要我吗？像我想要你那样？"
            
        else:
            quil hister sigh "很少有人能像你这样容忍我。"
            quil wry both apa "我在想，嗯，你能不能再多忍受我一段时间。"
        show palmierproxy wry sweat sigh
        quil groan frusta "我知道我要求很多，有时候我有点让人难以招架..."
        quil sad sweat sigh "我用表现得像个自信过头的蠢货来弥补自己的无能，但是..."
        quil hister blush bunga "[povname]，当我和你在一起的时候，我感觉自己能创造真正的奇迹。"
        show palmierproxy malu blush -sigh
        quil talk spark "那些不可能的事，似乎不再遥不可及。它们都变得...仿佛触手可及。"
        quil smile sigh "那种感觉是世界上最美好的感觉。我希望能永远保持这种感觉。"
        quil datar -sigh "但这不是由我决定的。这需要两个人的共同努力。"
        quil talk apa "所以我在这里，[povname]，谦卑地请求能成为你的挚爱的荣幸，无论在这个世界还是你的世界？成为\'我们\'？"
        show palmierproxy frown both shock
        show pboy s at horzappear
        menu quil_pik:
            "{s}当然！{/s}"if "companion"in my_events:
                
                jump quil_pik
            "当然！"if "companion" not in my_events:
                hide pboy
                mc laugh blush bunga "当然！"
                $ bff.points = 100
                quil hister blush sigh "太好了，因为我为我们今晚准备了很多计划。我可不想让它们都白费。"
                mc mean cling "什么样的计划？"
                quil talk cling "首先是跳舞。你知道吗，当我看到你在节日上和塞恩跳舞时，我嫉妒得发狂。"
                quil laugh -cling "而且他的舞技糟糕透顶。让我来向你展示一个真正的伊格尼亚绅士是如何跳舞的。"
                mc apa shock "哇！"
                play sound "sound/effects/cloth.mp3"
                show map_bar behind palmierproxy
                show palmierproxy wry sigh
                show quil datar blush bunga
                "奎尔把你拉到舞池里，他的手很快就找到了放在你肩膀和腰上的位置。"
                "你不愿承认，但他确实很擅长，毫不费力地带着你旋转和下腰。"
                "当音乐变得缓慢时，你把头靠在他的肩窝里。"
                "你们的身体胸贴着胸，你享受着他平静的心跳声。"
                quil malu -bunga "我从未想过我会如此在乎一个人，就像我在乎你一样，[povname]。"
                quil hister "我知道这听起来很可怕，但我很高兴我把你召唤到我的世界。我很高兴能遇见你，了解你。"
                mc wry tanya "这不是意味着你很高兴差点谋杀了[povname]吗？"
                quil talk bloom "是的，因为那给了我认识你的荣幸。只要能和你在一起，我愿意重来一次，我的[povname]。"
                mc laugh blush bunga "你的[povname]。我有点喜欢这个称呼。我也期待更多的舞蹈。"
                quil malu -bloom "那我们可以尽情跳舞，不过，希望不是整晚都跳。"
                quil panik blush bunga "我...我今晚还有其他东西要给你。如果...如果你想要的话。"
                mc wry -blush tanya"嗯？"
                "你疑惑地歪着头，而奎尔脸上的红晕似乎更深了。"
                play sound "sound/effects/cloth.mp3"
                show quil wry -bunga at center with move
                show palmierproxy frown both shock
                if not girl and not girl2:
                    "他拉开你放在他肩上的手，然后把你的那只手慢慢往下滑。"
                    "一直滑到他的胯部。"
                    mc malu blush tanya "哦，你确定吗？"
                    quil malu blush "是的。"
                    mc happy tanya "你想让我...照顾你？"
                    show palmierproxy smile -tanya
                    quil hister blush bunga "是的，我已经清理过那里了，也做好了准备。我-我只是想象你填满我那里就已经高潮了，所以..."
                    quil wry -bunga "求你了，我需要你进入我。"
                else:
                    "他的手向下滑动，紧紧地抓住你的臀部。"
                    mc rajuk "我...哦。"
                    mc wry blush -shock "你想要...？"
                    quil hister blush sigh "我需要。我需要你。"
                    show pboy s at horzappear
                    menu:
                        "我可以用假阳具操你吗？":
                            hide pboy
                            quil malu both shock "啊！嗯...其实我都不介意。以防万一我已经做好准备了。"
                            quil hister -shock "我...我只是想象你在后面猛烈地进入我就来了，所以..."
                            quil malu blush "但我的意思是，只有在你愿意的情况下！我们可以按你喜欢的方式来，我..."
                            quil wry "我只是想要你。拜托了。"
                        "好的。":
                            hide pboy
                            pass
                mc happy blush bunga "去你的房间还是我的？"
                show quil hister blush bloom
                stop music
                scene bg_black with w33
                if not girl:
                    show quil_fina with flashbulb
                    galleryunlock quil_fina
                else:
                    scene bg_black with w33
                    show quil_fina_f at center with dissolve
                    galleryunlock quil_fina_f
                "你和奎尔度过了一段激情的时刻，然后回到了你的宿舍。"
                $ my_events.append("companion")
                $ bff.hint = "在这次游戏中，奎尔成为了你的恋人。他会跟随你到你的世界。"
                $ quil_events.append("companion")
                scene bg_black with eye_shut
                jump jaga_jaga
            "对不起...":
                hide pboy
                show palmierproxy side sweat sigh
                show quil sad sweat shock
                $ bff.points = 60
                mc ow frusta "奎尔，这很有趣，但是...我觉得我们无法在我的世界里继续我们的关系。"
                quil grit frusta "等等，你现在要和我分手？！"
                mc deject sigh "我是说，奎尔，我们太不同了，而且我们整个\'关系\'就只是我跟随你的引导——"
                quil kzl sigh "哦，所以这是我的错，是吗？！"
                mc ow frusta "好吧，某种程度上确实是，你为什么对我大喊大叫？！"
                quil groan frusta "啊啊啊！" with vpunch
                play sound "sound/effects/walk.mp3"
                "奎尔在你面前来回踱步了几秒钟。你可以看到莱利尴尬地站在房间角落，手里拿着饮料，不知道该什么时候进来。"
                "你试图眨眼求助，但随后你想起她是盲人，感到很愚蠢。奎尔似乎注意到了你快速的眨眼，稍微冷静了一些。"
                stop sound
                quil fluster -sweat sigh "你说得对。我处理得不好。我问了你一个问题，你给了我一个答案。"
                quil sulk frusta "这不是我希望的答案，但毕竟是个答案。所以，谢谢你，祝你一切顺利，[povname]。"
                quil cringe sigh "现在请原谅我，我要去找个角落沉浸在悲伤中，也许还能找个床伴度过今晚。"
                mc confused tanya "你不是处男吗？"
                show palmierproxy sad -tanya
                quil grit -sigh "是的，如果你一定要知道，我本打算今晚把我的第一次给你。但既然你拒绝了，那就是你的损失了。"
                quil cringe "我现在要走了，不，我没有生你的气。只是...有点失望。我们本可以一起玩得很开心的。"
                quil ejek "如果你要先回家，只需敲三下入口的门，它就会带你回学校。"
                quil sly cling "玩得开心，[povname]，晚安。"
                play sound "sound/effects/walk.mp3"
                hide quil with dissolve
                show palmierproxy apa sweat shock at center with move
                "正如他所说的那样，奎尔确实怒气冲冲地离开了，从莱利那里拿走了他的饮料，然后和他那晚看到的第一个看起来单身的人聊了起来。"
                stop sound
                "你被整个对话弄得目瞪口呆，即使当莱利把你的饮料放在你手中时，你的嘴巴仍然张得大大的。"
                show palmierproxy side frusta 
                "当你终于注意到手中冰凉的玻璃杯时，莱利好心地帮你合上了嘴。"
                show waiter gold smile at right with dissolve:
                    yoffset 200
                npw pout apa "那么，呃，你想来点烈酒吗？"
                mc ha sweat "我想保持清醒。"
                npw talk sigh "你确定吗？"
                mc pissed sigh "...一杯吧。"
                npw smile "马上就来！"
                stop music
                scene bg_black with w20
                "你喝了一两杯烈酒后就回家了。"
                "当你走向自己的房间时，你瞥见奎尔带了一位相当高大、黑皮肤且英俊的绅士回他的房间过夜。"
                "你决定彻底忘记这个晚上，以后也不再提起这件事。"
                
                jump jaga_jaga

    else:
        quil laugh blush bunga "我相信这对我未来的事业会很有帮助。"
        mc wry tanya "是哪些事业？"
        show palmierproxy -tanya
        quil wry sigh "我还不确定。恐怕我还没有计划那么远。让[povname]醒来并保持清醒仍然是我的主要任务。"
        quil laugh cling "还有，也许和你跳一支舞。"
        mc apa sweat shock "跳舞？"
        quil hister apa "我们在水母节的时候没有一起跳舞，对吧？"
        show palmierproxy malu -shock
        quil err sweat frusta "看到塞恩和你笨拙地跳舞真是一个可怕的景象。"
        show palmierproxy kind sigh
        quil sly blush cling "让我向你展示一下什么是真正的伊格尼亚舞蹈。我们开始吧？"
        show map_bar behind palmierproxy with dissolve
        show palmierproxy happy blush
        show quil laugh blush bunga
        "你微笑着握住奎尔的右手，整晚都在跳舞。"
        "你不愿承认，但他确实很擅长，轻松自如地带着你旋转和下腰。"
        "当音乐变得缓慢时，你将头靠在他的肩窝上，享受着他平静的心跳声。"
        show palmierproxy kind 
        quil talk -bunga "谢谢你[povname]，感谢你成为我的朋友，感谢你所做的一切。你真是这个世界的祝福。"
        stop music
        scene bg_black with w20
        "你和奎尔跳舞到深夜，然后回到自己的房间休息。"
        "今天是你度过的最美好的夜晚之一。"
        scene lor_mlm with w20
        jump ur_room


label quil_date3:
    $ quil_events.append("date3_done")
    quil talk apa "[povname]，有空吗？"
    show quil laugh -apa at right with move
    if girl:
        show palmierproxy frown at left with moveinleft:
            yoffset 40
    else:
        show palmierproxy frown at left with moveinleft:
            yoffset 100
    mc apa sweat tanya "那要看情况。这一秒钟是否有很大可能遇到某种致命危险？"
    if "tun_talk" in quil_events:
        quil ejek cling "不会，但有很大可能会造成情感创伤。"
        mc eiden frusta "这是你告诉我我们终于要见你父母的方式吗？"
        show palmierproxy kzl
        quil flashy wink spark "我就知道你那漂亮的脑袋里还是有[povname]的聪明才智的。"
        quil laugh -spark "是的。我父亲廷塔终于在他繁忙的日程中找到时间接待我们一天。"
        quil panik sweat sigh "当然，我们在这件事上并没有选择的余地，所以……"
        
    else:
        quil talk cling "亲爱的，恐怕我无法准确回答这个问题。这完全取决于你自己的能力。"
        mc kzl frusta "具体取决于什么？"
        quil flashy wink spark "取悦我的父亲，廷塔。"
        mc ow shock "你的父亲？"
        quil kzl sigh "我终于说服他接见我们。终于可以得到一些关于符文墨水、疫苗和巫师之血的答案。"
        mc grit sigh "\'接见\'？你说得好像要见国王似的。他可是你的父亲啊！"
        quil ow frusta "没错！我的父亲，他可能就相当于伊格尼亚的国王。英克威尔家族是仅次于教会的第二大势力。"
        quil skul tantrum sigh "你无法想象他有多忙。"
        mc sad tanya "忙到连见自己的儿子的时间都没有？"
        quil sad -sigh "确实如此。"
        quil ow frusta "听着，我不会用细节烦你，但我确实需要你，[povname]。"
        quil sulk sigh "我即将问他的事情可不是什么闲聊。我基本上是在问他是否为了让我们获取巫师之血并获得更多力量而捏造了巫师的危险性。"
        if not kln:
            quil err sweat frusta "这是亵渎！所以拜托了……我需要一个朋友，我需要我的[povname]，但[kamu]不在这里。所以拜托了！"
        else:
            quil err sweat frusta "这是亵渎！所以拜托了……我需要一个朋友，我需要我的[povname]，但[kamu]不能在这里。所以拜托了！"
        show pboy at horzappear
        menu:
            "不。":
                hide pboy
                show palmierproxy sad -sweat sigh
                quil sulk sigh "……好吧。"
                $ bff.points = 0
                $ quil_events.append("date3_fail")
                hide quil with dissolve
                hide palmierproxy with dissolve
                "奎尔一言不发地离开了。"
                "他的中指上似乎有一个符文在发光。他朝你弹了弹那根手指，然后消失在一个奇怪的烟雾和紫色阴影构成的传送门中。"
                $ NPC = "???"
                scene bg_black with w20
                if "bunga_bego" in buff_events:
                    if "beku" in quil_events:
                        scene map_infected_f with w20    
                    else:
                        scene map_infected with w20    
                else:
                    if "beku" in quil_events:
                        scene map_frozen with w20
                    else:
                        scene map_all with w20
                jump world_map

            "好的。":
                hide pboy
                mc side sigh "我真是个容易心软的人，对吧？好吧。"
                quil hister blush bunga "……谢谢你。"
                quil flashy talk cling "来吧"
    show palmierproxy confused sigh at center with move 
    "奎尔向你伸出手。每次他这样做时，你总觉得要么会被带到某个奇怪的地方，要么就是在与魔鬼做新的交易。"
    "尽管如此，显然你有一种救世主情结，而且对自己毫不在意，所以你还是握住了他的手。"
    mc frown -sweat tanya "我们还要穿过湖中的传送门吗？"
    quil amused -cling "这次不用。我父亲制造的传送门比那个要优雅一些。"
    stop music
    play sound "sound/effects/portal.wav"
    scene bg_black with wet
    "黑暗的阴影和烟雾笼罩了你的视线，然后将你整个吞没。"
    play sound "sound/effects/bump.mp3"
    "你感到脚下一阵拉扯，然后直接落入一个柔软舒适的地方，周围弥漫着香薰的甜美气息。" with vpunch
    bp "你现在可以睁开眼睛了。"
    scene ofis_quil with eye_open
    $ morning = False
    $ afternoon = True
    $ evening = False
    $ night = False
    show bpk at center with dissolve:
        yalign 0.0
    show quil skul at right with dissolve:
        yoffset 200
    if girl:
        show palmierproxy sad at left with moveinleft:
            yoffset 40
    else:
        show palmierproxy sad at left with moveinleft:
            yoffset 100
    quil sulk sweat sigh "父亲。"
    play music "MUSIC/MusMus-BGM-025.mp3"
    show quil sad -sigh
    "你面前站着一个高大瘦削的男人，他的特征与奎尔相似。同样的绿色眼睛，那种奇特的白色头发。"
    "然而，让你确定他们是亲属关系的，并不是奎尔称呼他为父亲或者他们的外表。"
    "而是他们看你的方式。那种对可怜的低等生物的轻蔑目光。"
    mc laugh sweat "先生。"
    show palmierproxy kind 
    bp smile "奎尔，[povname]。好久不见。"
    quil ejek -sweat cling "是的，当然，你知道如果你真的能抽出一些时间陪陪家人的话，那么——"
    show quil sad shock
    show palmierproxy sad shock
    bp "我们长话短说，好吗？"
    if "tun_talk" in quil_events:
        bp mock "[povname]。你和我儿子订婚了。"
        bp frown "为什么？"
        show quil sad -shock
        mc avoid tanya "……为什么？"
        show palmierproxy apa -tanya
        "那个男人歪着头，等待你进一步解释。当你没有说话时，他开始不耐烦地咂舌。"
        bp "快说啊。"
        show pboy at horzappear
        menu:
            "他让我这么做的？":
                hide pboy
                show palmierproxy scratch ha
                show quil err sweat frusta
                bp mock "哼。总是这么反复无常。那么我是否可以认为，这一切只不过是我儿子的又一个愚蠢游戏？"
                show quil sad -sweat sigh
                show palmierproxy chill side 
            "赞美奎尔":
                hide pboy
                $ bff.points += 5
                show quil laugh blush bloom
                mc laugh blush bunga "他很有天赋，聪明，长相也很养眼。他风趣幽默，和他聊天很有意思，我——"
                show palmierproxy grit sweat shock
                show quil sad shock
                bp smirk "而且金钱和声望也不是坏处，不是吗？"
                show quil kzl -shock
                mc mock -sweat cling "我已经很富有了，先生。"
                mc ha sweat -cling "（好吧，至少这里的贝克家族是这样。）"
                show palmierproxy kzl 
                bp mock "和金条相比，那些钱不过是九牛一毛。"
                bp frown "你真的想暗示你对我儿子有感觉吗？"
                bp "我不是傻瓜，[povname]。我一眼就能看出这是个诡计。"
                bp mock "奎尔，你不厌倦你的游戏吗？"  
        show quil sweat sigh
        show palmierproxy confused sigh
        bp frown "先是那些色情狂的胡言乱语，现在又来这一出。"
        bp "但有什么告诉我，这次你不只是为了惹恼我，对吗？"
        quil hister sweat spark "我向你保证，父亲，[povname]和我是真心相爱的。"
        show quil err shock
        show palmierproxy sad -sigh
        bp smirk "如果是这样，你们早就灵魂绑定了。"
        quil sly -sweat cling "是的，但是这里有个问题，父亲，[povname]想要生个孩子。"
        mc huh sweat shock "（啊？）"
        show palmierproxy confused frusta
        quil flashy talk -cling "然而，考虑到我小时候身体很虚弱，我不想把任何遗传缺陷传给我们的后代。"
        quil laugh apa "所以我今天来这里是想问你。我小时候注射的那些疫苗里到底是什么？"
        quil groan sweat sigh "因为我做了研究，发现其成分与符文墨水和巫师血液惊人地相似，所以——"
        show quil sad shock
        show palmierproxy frown -sweat -frusta
        bp frown "啊，原来这才是你真正想要的。"
    else:
        show palmierproxy confused sweat shock
        bp mock "你想知道伊格尼亚珍贵的符文墨水，以及它与你注射的疫苗有什么关系。"
        show palmierproxy frown -sweat -shock
        quil sad sweat apa "是的。告诉我，父亲，它们是同一种东西吗？你注入我血管的东西和符文墨水……它们都是巫师的血液，对吗？"
        bp frown "..."
    bp "在佩纳之后，你花了3个月23天4小时才意识到这一点。"
    bp mock "真令人失望。"
    quil grit sweat apa "佩纳？"
    show quil sad -apa
    show palmierproxy confused sweat
    bp frown "他也发现了我们家族的这个秘密，只不过他比你效率高得多。"
    bp "我本该因你的无能而惩罚你，但今天我心情不错，所以我会满足你的好奇心。"
    bp "是的，奎尔，我们从你出生起就一直给你注射巫师的血液。好了，满意了吗？"
    quil ow "为……为什么……？"
    bp smirk "当然是为了让我们变得更好。进化。"
    stop music
    play sound "sound/effects/walk.mp3"
    scene dur_quil1 with dissolve
    "奎尔的父亲从座位上站起来，走过房间。他示意你跟随他走向一扇带有安全锁的门。"
    show side_p f at pic
    mc "这是你存放所有钱的地方吗？"
    hide side_p
    play sound "sound/effects/fridge.mp3"
    scene dur_quil2 with dissolve
    bp "不，但并非所有的宝藏都以黄金来衡量。"
    play music "MUSIC/heart.mp3"
    scene vault_ink with fade
    "廷塔打开了门，你看到里面是一个渗着血的保险库。血从保管箱中滴落，从大金属门的铰链处渗出。"
    show quil ow sweat at center with dissolve:
        yoffset 200
    quil "父亲……你……你做了什么？"
    show quil sad at right with move
    if girl:
        show palmierproxy chill grit sweat at left with moveinleft:
            yoffset 40
    else:
        show palmierproxy chill grit at left with moveinleft:
            yoffset 100
    show bpk at center with dissolve:
        yalign 0.0
    bp mock "我把那些该死的巫师的血液派上了用场。"
    bp frown "在这些容器里，存放着我们猎杀的巫师的各种血液样本，纯净的或稀释的。"
    bp "某些身体部位被保存在你看到的那个大保险库后面。肢解的四肢和内脏器官，全都是为了人类的进步。"
    bp smirk "你以为你对符文墨水的精通是天生的吗？不，我的儿子。"
    bp mock "你的才能是我仁慈的结果。我们所有的研究都是为了让人类变得更好。摆脱对符文墨水的需求。"
    bp smile "成为比巫师和科尔本人更强大的存在。"
    mc kzl frusta "（天哪，这里的每个人都需要检查一下自己的自负。这些人到底怎么了？！）"
    show palmierproxy -frusta
    quil fluster shock "这太疯狂了，父亲！你是说我们一直在毫无理由地猎杀巫师吗？！"
    bp mock "我们有我们的理由，为了生存。"
    bp frown "如果我们不在人民心中灌输恐惧，如果我们不提醒他们巫师统治的威胁，那么我们早就灭亡了。"
    bp "你见过他们愤怒时的力量。我们不能让他们自由自在地游荡。"
    quil grit frusta "亲爱的父亲，我有个想法。我们本可以不去激怒他们，让他们安静地生活！"
    show quil kzl shock
    bp mock "别说了，奎尔，别这么天真。"
    bp frown "我相信你已经发现了符文墨水背后的真相。它的真正来源。"
    if "ice_rune" in my_events:
        bp "一个现在已经停止的来源，冻结成固体。"
    else:
        bp "一个据说多年来已经枯竭的来源。也许科尔终于死了，她的血被榨干了。"
    bp mock "伊格尼亚现在比以往任何时候都更需要我们，继续我们的研究，摆脱巫师和墨水的束缚。"
    bp smile "事已至此，血已流尽，现在再思考我们的损失已经没有用了。"
    bp frown "作为英克威尔家族的继承人，你应该履行你的职责，继续我的研究。只有你，而且只能是你。"
    bp "不是佩纳，也不是你其他任何任性的表亲。你必须这么做！"
    mc grit "你是个怪物！" with vpunch
    bp mock "从你口中说出来真有意思，[povname]·贝克。"
    mc confused shock "（这是什么意思？？？）"
    show palmierproxy sad -sweat -shock
    quil sulk frusta "...为什么是我？"
    bp frown "因为你是我的儿子，我的遗产。我不会让我的名字因失败而蒙羞。你将成为这个黑暗时期伊格尼亚的救世主。"
    bp smile "决定我们是衰落还是崛起的人。选择权在你手中，儿子。"
    quil frown -sweat -frusta"...好吧。"
    mc grit shock "好吧？！" with vpunch
    quil grit frusta "他说得有道理，[povname]。伊格尼亚靠符文墨水运转。没有它，社会就会崩溃，更多的恐怖将会降临。"
    quil tantrum sigh "我不喜欢这样，但...这样更安全。"
    show quil err sweat shock
    mc kzl frusta "你什么时候开始关心安全了？！你把我带到这里，鲁莽地试图猎杀巫师来唤醒——"
    bp frown "...唤醒？"
    show palmierproxy ew sigh
    "你突然闭上嘴，想起你还有人陪伴。你咬紧牙关，愤怒不已，但决定暂时控制住自己的怒火。"
    quil laugh -sweat sigh "这不是你需要关心的事，父亲。"
    bp smirk "很好。我猜我们的事情已经谈完了。"
    if "tun_talk" in quil_events:
        show palmierproxy kzl -sweat -sigh
        bp mock "放弃你那些愚蠢的爱情想法吧，奎尔。我已经为你的婚事物色好了人选。"
        bp frown "比这个篡位者血统好得多的人。"
        quil sulk sigh "是的，父亲。"
    bp smile "好孩子。我本来担心你会再次鲁莽行事，试图破坏我的计划，就像你之前多次做的那样。"
    bp smirk "但我看到你终于成熟了。我为你感到骄傲，儿子。"
    quil hister blush bunga "谢谢您，父亲。这对我意义重大。"
    "奎尔的父亲点点头，对奎尔露出了一个几乎察觉不到的微笑。而对你，他毫不掩饰地皱眉。"
    show palmierproxy grit shock
    "他厌恶地皱起眉头。"
    bp frown "你可以走了。我们会保持联系的，奎尔。"
    quil datar -blush sigh "是的。"
    stop music
    play sound "sound/effects/portal.wav"
    scene bg_black with wet
    "随着他打了个响指，你很快发现自己回到了学校。"
    scene kmr_malam with wet
    $ morning = False
    $ afternoon = False
    $ night = False
    $ evening = True
    play music "MUSIC/MusMus-BGM-013.mp3"
    stop sound
    "准确地说是奎尔的房间，从墙上挂着的各种他自己的照片可以判断出来。"
    show quil ow sweat at right with moveinright:
        yoffset 200
    if girl:
        show palmierproxy chill grit frusta at left with moveinleft:
            yoffset 40
    else:
        show palmierproxy chill grit frusta at left with moveinleft:
            yoffset 100
    "奎尔深深地叹了口气，脸上露出不适的表情，而你..."
    show pboy at horzappear
    menu:
        "爆发怒火":
            hide pboy
            $ bff.points -= 10
            if bff.points < 0:
                $ bff.points = 0 
            show palmierproxy kzl sigh
            play sound "sound/effects/punch.mp3"
            queue sound "sound/effects/bump.mp3"
            quil ow sweat shock"哎哟！" with vpunch
            "你猛地转身，狠狠地踢向他的裆部。奎尔弯下腰，痛苦地呻吟着倒在床上。"
            quil kzl apa "什么，这是为什么？！"
            mc grit frusta "因为你是个彻头彻尾的人渣！不，就连垃圾都会因为被拿来和你比较而感到被冒犯！"
            mc sad "我简直不敢相信你居然同意他的话！"
            quil err shock "我可以解释！"
            mc confused sigh "你能吗？！"
            quil fluster frusta "我能...等我恢复过来，呃。我感觉我的灵魂都要离开身体了。稍等。"
            mc pissed sigh "我要走了！"
            show palmierproxy confused shock
            play sound "sound/effects/cloth.mp3"
            show quil flashy sad at center with move
            quil ow "不，别走！"
        "要求解释":
            hide pboy
            $ bff.points += 5
            mc grit frusta "奎尔，你只有一次机会解释你刚才的行为，否则我会踢你的蛋蛋，踢得你恨不得自己被阉割。"
            quil flashy panik sweat shock "冷静点，亲爱的，我有解释，我发誓！"
        "生气地离开":
            hide pboy
            show palmierproxy pissed frusta
            play sound "sound/effects/cloth.mp3"
            show quil flashy sad shock at center with move
            quil err frusta "等等！"
            mc grit "放开我。"
            quil ow frusta "不！请等等，[povname]，我发誓我有解释！"
    quil sad sigh "求你，求你让我解释！"
    mc apa sigh "...给你一次机会。"
    play sound "sound/effects/drawer.mp3"
    "奎尔点了点头，急忙从抽屉里翻出一些符文墨水，在地板上画了一个大符文。"
    mc sad tanya "什么——？"
    play sound "sound/effects/woosh.mp3"
    scene kmr_malam with flashbulb
    "在你还没来得及问它的用途时，一个光罩就在你周围形成了，将你包裹在一个奇怪的无声房间里。"
    "吹过的风声、走廊上的脚步声、客厅里的窃窃私语，在光罩内都变得模糊不清。"
    show quil frown sigh at right with moveinright:
        yoffset 200
    if girl:
        show palmierproxy chill confused shock at left with moveinleft:
            yoffset 40
    else:
        show palmierproxy chill confused shock at left with moveinleft:
            yoffset 100
    show palmierproxy kzl -shock
    quil wry -sigh "\'迪亚姆\'。一个创造小型光屏障的符文，能够避开窥探的眼睛和耳朵。"
    quil tantrum "佩纳发现了这个符文，并告诉我我可能会需要它。现在我终于明白为什么了。"
    quil kzl sigh "首先，是的，我父亲完全疯了，其次，不，我不会遵从他的命令。"
    quil err sweat frusta "顺便说一句，非常感谢你的信任。"
    quil sulk sigh "第三，我很抱歉把你卷入这个麻烦中。"
    quil wry -sigh "我想我确实是个麻烦磁铁。"
    mc ow sweat tanya "等等，所以刚才那些都是在演戏？"
    show palmierproxy sad -tanya
    quil cringe -sweat frusta "是的！看来是个非常令人信服的演技。要么就是你比我想象的更容易上当受骗，[povname]。"
    show quil smile -frusta
    mc apa tanya "呼。好吧，所以你不会真的这么做？"
    show palmierproxy sad -tanya
    quil err sweat frusta "不会。科尔，不会的！我只是想要答案，佩纳说得很含糊。可能是想保护我不卷入大局。"
    quil rajuk "但现在我知道了真相，说实话我很生气。看来我们的生活都是一场谎言。"
    quil kzl "对巫师的恐惧只不过是教会为了获取权力而散布的宣传。"
    quil sad sigh "亲爱的科尔，想想我曾经多么以身为英克威尔为荣。"
    "奎尔叹了口气，坐在床边，眼中噙满了羞愧的泪水。"
    "不知道该说什么，你只是坐在他身边，将一只安慰的手放在他的肩膀上。"
    "他似乎很感激这个举动，深深地吸了一口气让自己平静下来。"
    mc side tanya "那么，现在怎么办？"
    show palmierproxy frown -sweat shock
    quil ejek -sweat cling "现在我需要制定一个计划。"
    mc apa sweat frusta "什么样的计划？"
    quil flashy hister spark "哦，别担心，只是那种可能会让我被家族驱逐，并永远流放出伊格尼亚的计划。"
    mc grit shock "什么？！"
    quil panik frusta "哦，没什么好担心的，亲爱的。是时候我自己收拾烂摊子，而不是把你卷进来了，不是吗？"
    mc sad frusta "不，说真的奎尔，我很担心。"
    quil wry sigh "别担心。我最终会没事的。不过还是谢谢你，谢谢你在这里，谢谢你和我一起来。真的。"
    quil talk -sigh "但这一次，这是我自己的烂摊子，只有我自己来收拾。"
    quil smile apa "明白吗？"
    mc side sigh "...好吧。"
    mc confused -sigh "但至少给我解释一件事。"
    quil datar -apa "嗯？"
    mc confused tanya "刚才，你父亲称我为怪物。为什么？"
    quil panik sigh "哦。那是因为他在付钱给贝克一家照顾我。"
    mc kzl -tanya "等等，倒回去，你说什么？"
    quil amused sigh "这里是伊格尼亚。跟上节奏，亲爱的。"
    quil talk -sigh "我小时候花了大量时间和贝克一家在一起。"
    quil laugh "在我父亲的想法里，没有家庭会心甘情愿地接受这种安排。"
    quil talk bunga "但就像给我父亲开了个玩笑，贝克夫人从一开始就告诉我了我父亲的交易，她还是很喜欢我的陪伴。"
    quil sly "你母亲是个很好的女人。她一边榨干我父亲的钱，一边还收留了一个流浪儿。我爱那个女人！"
    quil smile cling "当然，我父亲仍然认为你只是按照你父母的命令与我交朋友，而我们都知道[povname]只是被我迷住了。"
    mc ew frusta "嗯哼。抱歉，我想你刚刚让我的大脑短路了一秒。奎尔，你的世界真是个可怕的地方。"
    show palmierproxy sad sigh
    quil skul wry both -cling "也许吧。但这就是我出生的世界，我唯一能逃离的方式，嗯..."
    "奎尔盯着你的脸，仿佛在试图从中找到答案。"
    mc scratch apa tanya "什么？"
    show palmierproxy chill confused -tanya
    quil flashy laugh -both "没什么。也许改天吧。现在，请离开我的房间。"
    quil amused sigh "我需要安静来制定一个邪恶的计划，为了你的安全，我需要你离开这里。"
    mc ow frusta "只是答应我你不会做太蠢的事，好吗，奎尔？"
    quil wink cling "亲爱的，我完全不知道你在说什么！"
    play sound "sound/effects/door.mp3"
    scene lor_mlm with fade
    "奎尔带着一个不太令人安心的眨眼，把你赶出了他的房间。"
    play sound "sound/effects/doorslam.mp3"
    queue sound "sound/effects/walk.mp3"
    "当你走向自己的房间时，你内心的一部分想给妈妈发短信，看看她对英克威尔家族了解多少。"
    "然而，你的另一部分也害怕可能会发现的信息。"
    show side_p he at pic
    mc "（好奇心害死猫。）"
    show side_p s
    mc "（如果\'我妈妈\'也在利用奎尔呢？）"
    hide side_p
    show pboy at horzappear
    menu:
        "给妈妈发消息":
            hide pboy
            mc "（我必须知道。）"
            $ interlocutor = "Mum"
            $ del_all_msg()
            hide window
            show hp at move_messenger2
            pause 1.0
            $ show_messenger()
            $ msg ("妈妈？")
            $ msg ("[povname]！", who=1, status='online')
            $ msg ("你这么晚还没睡。", who=1)
            $ msg ("现在才9点半")
            $ msg ("没错，9点半就晚了！一切都好吗？你吃得好吗？我希望你睡眠充足。", who=1)
            $ msg ("我很好，妈妈，但我想问问。你有没有因为和英克威尔先生的交易而让我和奎尔成为朋友？")
            $ msg ("哦天哪，菲亚告诉我你可能复发了。我要把你接回来吗？你需要帮助吗？", who=1)
            $ msg ("不，妈妈！我很好，我很清醒，真的！只是我在一次任务中受了脑震荡，有些事情有点模糊。")
            $ msg ("什么？！", who=1)
            $ msg ("你在哪里？！", who=1)
            $ msg ("菲亚和你在一起吗？", who=1)
            $ msg ("你们两个都受伤了吗？！", who=1)
            $ msg ("不，妈妈，只有我。而且我很好，海德温女士照顾得很好。但是，我只是需要补充一些信息。")
            $ msg ("好吧。对不起，每次听到你或菲亚受伤，我总是有点害怕。", who=1)
            $ msg ("至于你的问题，简短的回答是不，当然不是！", who=1)
            $ msg ("我们之前讨论过这个，你和我都同意奎尔应该得到更好的。", who=1)
            $ msg ("我知道你有多在乎那个男孩，他基本上已经成为你的第二个兄弟姐妹了。", who=1)
            $ msg ("还有什么需要补充的吗，孩子？或者你有什么想告诉我的吗？", who=1)
            $ msg ("都很好，妈妈...")
            $ msg ("不，等等，其实不是！假设性地说。")
            $ msg ("假设性地说，如果我和一个巫师建立了联系，你会生我的气吗？")
            $ msg ("这是你告诉我你已经和某人建立联系的方式吗？因为如果你真的这么做了，你知道我会为你感到高兴，不管那是谁。", who=1)
            $ msg ("等等，真的吗？")
            $ msg ("孩子，当你12岁的时候，我向你介绍了伊格尼亚社会的阶级制度和社会阶层。", who=1)
            $ msg ("然后你告诉我，你要把这些制度彻底摧毁，建立自己的宗教，如果需要的话甚至不惜屠杀成千上万的人。", who=1)
            $ msg ("那时我意识到两件事。第一，我在养育一个恶魔之子。第二，我奇怪地仍然爱你胜过一切，如果能让你幸福，我愿意牺牲整个世界。", who=1)
            $ msg ("你的想法和行为很奇怪，孩子，但这没关系。", who=1)
            $ msg ("重要的是你照顾好自己的人，并且心怀最好的意图。", who=1)
            $ msg ("现在，我再问你一次，你和某人建立联系了吗？", who=1)
            $ msg ("不。")
            if "bond" in fia_events:
                $ msg ("菲亚也没有。")
                $ msg ("我当然希望她没有，我还在试图为她找个合适的对象呢！", who=1)
                $ msg ("顺便说一下，你还是很受欢迎的，你确定不想让我给你安排和理查德见面吗？因为你知道，他是个好人。聪明，有钱。我只是随口一提。", who=1)
                $ msg ("不要，妈妈。")
                $ msg ("好吧，如果你确定的话。", who=1)
            $ msg ("那么，就这些吗？你爸爸刚刚进来，又在抱怨他的背痛了。你知道是怎么回事。", who=1)
            $ msg ("就这些。谢谢妈妈。")
            $ msg ("爱你，亲爱的，去杀巫师吧，还有你们猎人做的其他事情！", who=1)
            $ hide_messenger()
            hide hp
            show hp2 at move_messenger3
            "你带着轻快的脚步走向自己的房间。很高兴知道这个世界的妈妈和你原来的妈妈很相似。"
            "她让你屠杀成千上万的人，这确实有点疯狂，但至少你得到了爱，而奎尔对她的信任也是正确的。"

        "忽略它":
            hide pboy
            "你决定现在最好还是把一些事情暂时搁置在黑暗中，然后前往你的房间。"
    stop music
    scene lor_mlm with fade
    play music "MUSIC/MusMus-BGM-082.mp3"
    jump ur_room
    
label quil_fish:
    stop music
    scene bg_black with w20
    $ quil_events.append("mancing")
    play music "MUSIC/MusMus-BGM-037.mp3"
    scene lake with w20
    if girl:
        show palmierproxy chill kind at left with dissolve:
            yoffset 40
    else:
        show palmierproxy chill kind at left with dissolve:
            yoffset 100
    show quil datar at right with dissolve:
        yoffset 200
    quil groan sweat frusta "唉，我真不敢相信你居然说服我来钓鱼。"
    mc happy tanya "来吧，难道你的[povname]从未邀请过你吗？我知道我会的。"
    show palmierproxy kind -tanya
    if not kln:
        quil fluster -sweat "哦，[kamu]有过，但我总觉得...不太得体。"
    else:
        quil fluster -sweat "哦，[kamu]有过，但我总觉得...不太得体。"
    mc confused tanya "什么，所以你从未为了酿造魔药而捕鱼吗？"
    show palmierproxy frown -tanya
    quil flashy wink cling "我总是付钱让别人帮我捕鱼。我知道很多魔药需要鱼的内脏、鳞片或其他不雅的身体部位。"
    quil skul groan sweat frusta "黏糊糊、恶心的小东西。更不用说在这种极其无聊的活动上浪费的时间了。"
    quil kzl sigh "站着一动不动几个小时就为了一口可怜的鱼，有什么有趣的？"
    quil err apa "你知道在你捕捉那些湿漉漉、软塌塌的东西的时间里，我能读多少本书吗？"
    mc mean cling "作为一个处男，你还真知道怎么把事情说得过于色情。"
    quil flashy wink -sweat spark "这是一种天赋。我知道，很少能遇到像我这样多才多艺的人。"
    mc ha -cling "嗯哼，想知道钓鱼是否也是你的天赋之一吗？"
    quil ow sweat frusta "好吧！我想迁就你是我能为我给你造成的麻烦做的最起码的事。"
    mc mock cling "哦，所以你意识到自己有多烦人。很好，他们说承认是康复的第一步。"
    show palmierproxy kind sigh
    quil groan sigh "钓鱼之旅不是应该安静平和吗？你会把鱼吓跑的。"
    show quil datar -sweat -sigh
    "奎尔说着，卷起裤腿，你们俩并排坐在码头边上。"
    "当奎尔终于安静下来时，你享受着双脚浸入水中的感觉。"
    "奎尔在风中吹拂着头发，阳光恰到好处地照在他身上，突出了他的颧骨，画面相当美好。"
    "他确实是一道赏心悦目的风景...只要他保持安静的话。"
    quil sly -sweat cling "所以事情会变得有趣吗？还是你打算像个变态一样盯着我的脸看一整天？"
    mc avoid sweat sigh "（...说得好。）"
    show palmierproxy kind -sweat -sigh
    show pboy at horzappear
    menu :
        "耐心点。":
            hide pboy
            $ bff.points -= 10
            if bff.points < 0:
                $ bff.points = 0
            mc deject sigh "耐心点。这需要一些时间。"
            show palmierproxy frown -sigh
            quil wry -cling "我知道，我记得[povname]以前常常偷偷溜走几个小时去某个地方钓鱼。"
            quil hister apa "你知道[kamu]曾经试图捕捉一条美人鱼吗？"
            quil talk -apa "菲亚小时候不相信美人鱼的存在，[povname]会花上几个小时和她争论这个问题。"
            quil amused "[povname]最后会花好几天钓鱼，希望能捕到一条美人鱼来证明她错了。"
        "谈论[povname]":
            hide pboy
            $ bff.points += 5
            mc kind tanya"所以你真的从未和[povname]一起去钓过鱼？"
            show palmierproxy -tanya
            quil rajuk "没有。当我们还是孩子的时候，[kamu]曾试图让我参加[dia]家的钓鱼旅行。"
            quil sad sigh "然而，那天遇到了雷暴，所以取消了。"
            quil wry -sigh "不过，我记得那晚我在[povname]家过夜了。"
            if girl2:
                quil panik sweat "我记得[dia]那时还害怕打雷，会把自己裹在毯子里躲进衣柜。"
                quil hister "我常常陪[dia]待在那里，我们会互相讲鬼故事。"
                mc eiden tanya "因为雷暴比床底下的怪物更可怕。"
                show palmierproxy kind -tanya
                show quil rajuk sigh
                "奎尔对此耸了耸肩。"
                quil amused -sigh "鬼魂不是真的，雷暴是。"
                mc confused "实际上，在你的世界里什么才是真实存在的？因为在我的世界里，吸血鬼、巫师和狼人肯定是不存在的。"
                quil talk -sweat "这是一个相当宽泛的问题。这里有美人鱼、海妖、小精灵...森林精灵。"
                quil hister "不过，美人鱼和海妖很少见。尤其是美人鱼。"
                quil amused apa "你知道吗，曾经有一段时间菲亚不相信美人鱼的存在？"
                quil talk -apa "[povname]会花上几个小时和她争论这个问题。"
                quil amused "[povname]最后会花好几天钓鱼，希望能捕到一条美人鱼来证明她错了。"
            else:
                quil sulk frusta "首都曾遭遇了一场台风，是有史以来最具破坏性的一次。"
                quil rajuk sigh "我父母当时甚至不在国内，所以我像往常一样住在[povname]家。"
                quil wry -sigh "菲亚和我躲在被子下，[povname]用[dia]的手臂保护着我们俩。"
                quil groan frusta "现在回想起来，[povname]其实也很害怕，我记得每当闪电照进房间时，[dia]的手指都在颤抖。"
                if not kln:
                    quil wry sigh "但[kamu]试图在[dia]妹妹面前表现得坚强，坚持了下来。"
                else:
                    quil wry sigh "但是[kamu]试图在[dia]妹妹面前表现得坚强，所以坚持了下来。"
                mc smile sigh "我也会这么做的。"
                mc malu -sigh "（事实上，我想我曾经也这样做过，那时候爸妈总是出差。）"
                quil mock -sigh "哦，我知道你会的。你们所有的版本都如此相似，这让我有点毛骨悚然。"
                quil amused sigh "但有时你们俩也会像典型的兄弟姐妹一样争吵。"
                quil laugh -sigh "我记得你们两个曾经为美人鱼争论。菲亚那时才7岁，所以她不太懂事。"
                quil talk "但那时，她不相信[povname]给她看的任何书籍或证据。"
                quil panik sigh "他们会为此争论好几个小时。最后[povname]就会气冲冲地跑去钓鱼。"
                quil amused -sigh "希望能捕捉到[dia]自己的美人鱼，只为了证明她错了。"
    quil smile "当然，这是非常不可能的，美人鱼是狡猾而聪明的生物。它们不会愚蠢到被一根简单的钓线捕获。"
    show palmierproxy kzl shock
    quil groan shock"哇！"
    stop music
    play sound "sound/effects/splash.wav"
    hide quil with vpunch
    show palmierproxy at center with move
    mc ow sweat shock "奎尔？！"
    "你还没来得及眨眼，奎尔就被拖入了水中。水面上冒出的气泡是他曾在那里的唯一痕迹。"
    if girl:
        scene drown_fem with rain1
        galleryunlock drown_fem
    else:
        scene drown_m with rain1
        galleryunlock drown_m
    "你还没来得及反应，就感到自己的钓竿被猛地拉了一下。然后你也被某种神秘的大鱼拖入了水中。"
    "至少你以为那是条鱼，直到你睁开眼睛，看到了你见过的最有趣的生物之一。"
    $ NPC = "美人鱼"
    npc "钓到什么有趣的东西了吗？"
    "一条美人鱼...你眼前所见，用她异常长的尾巴缠住你腰部的...是一条美人鱼。"
    "你在她的眼睛里迷失了一秒，然后意识到两件事。第一，你听到的声音是在你的脑海里，而不是从耳朵里传来的。第二..."
    mc "...奎尔他妈的去哪了？！"
    npc "哦，那个话多的家伙，他没事。我只是想让他安静一会儿。他总是这么爱说话吗？"
    show pboy at horzappear
    menu:
        "一直如此！":
            hide pboy
            $ bff.points -= 5
            if bff.points < 0:
                $ bff.points = 0
            $ honesty += 5
            $ kindness -= 15
            show side_p a at pic
            mc "（哦，别提了，我打赌他宁可拒绝金钱也要继续说话！）"
            hide side_p
            npc "那我为你们的友谊感到遗憾，不过也许这比有个几乎不回应的朋友要好。"
            npc "就像我认识的某个海妖。"
            show side_p f at pic
            mc "（谁？）"
            hide side_p
            show side_q skul sad at pic
            quil "[povname]！！！"
            hide side_q
        "他在哪里？！":
            hide pboy
            $ kindness += 5
            npc "可能已经浮到水面上了，就在我把你拉下水的时候，他逃脱了我的掌控。"
            show side_q skul sad at pic
            quil "[povname]！！！"
            hide side_q
            npc "看到了吗？"
    "你听到奎尔在对你大喊。美人鱼没有松开她抓住你腰部的手，把你拉到了水面。"
    play sound "sound/effects/splash.wav"
    play music "MUSIC/MusMus-BGM-006.mp3"
    scene mermaid with rain1
    galleryunlock mermaid
    "当她跃出水面并躺在你身边时，你大口喘着气。"
    "奎尔疯狂地把你拉起来，同时拍摄着美人鱼的照片，而美人鱼则恼怒地歪着头看着奎尔。"
    npc "人类，总是依赖你们那些奇怪的方盒子。"
    show side_q skul smile at pic
    quil "这叫手机，而且，你是美人鱼！我的天啊，真的是美人鱼！"
    hide side_q 
    npc "货真价实。"
    show side_q skul smile at pic
    quil "什么——我有好多问题。等等，我——"
    show side_q skul sad
    quil "等等，我忘了该怎么思考，我——！"
    hide side_q
    show side_p a at pic
    mc "奎尔，深呼吸。"
    hide side_p
    show side_q skul smile at pic
    quil "对，对。呃...你好！"
    hide side_q
    npc "你好。我很高兴我让你闭嘴了，你在这里话太多了。作为一个人类，你说得太多了。"
    npc "这很烦人。"
    show side_q skul smile at pic
    quil "我知道。我小时候缺乏关注，所以试图通过从陌生人那里获得关注来弥补。"
    quil "但是，等一下。你在这里做什么？我以为美人鱼从不游到这么接近水面的地方！"
    hide side_q
    npc "我们确实不会。但我可以说是个异类，因为我们通常也不会独自游荡。"
    show side_q skul smile at pic
    quil "啊，我正要问你这个。而且，你的尾巴非常长，我从未见过这样的！"
    quil "你们的生长没有一定的限制吗？我以为你们的尾巴最多只能长到两米，而且在臀鳃完全形成后就不会再生长了。"
    quil "事实上你有多个臀鳃，太神奇了！而且它们还会发光！哇！哇！"
    hide side_q
    "没过多久，奎尔就开始围着美人鱼转圈，让他的手在这个生物的身体上四处游走。"
    "她长长的黏滑尾巴，半透明的鳍，触手般的\'头发\'。"
    "美人鱼似乎并不介意，她看起来对奎尔被简化成一个兴奋的、词汇有限的小孩子感到很有趣。"
    show side_q skul smile at pic
    quil "太不可思议了，你的触手都能自己移动！它们在陆地上也是这样吗？"
    hide side_q
    npc "我不清楚，我在陆地上停留的时间从来不够长，无法了解这些。"
    show side_q skul smile at pic
    quil "所有的书籍和画作都无法相比。人鱼！我终于亲眼见到真正的人鱼了！"
    quil "我必须把这个告诉其他人！"
    hide side_q
    npc "这就是我该离开的信号了。"
    show side_q skul sad at pic
    quil "什么？离开？！但你不能走！我们还没有讨论你们的生殖系统，你们的卵子周期呢！"
    hide side_q
    show side_p w at pic
    mc "是啊，你最好赶紧逃走。哦，我是说游走。"
    hide side_p
    npc "呵呵，至少你还算可以忍受。"
    show side_q skul sad at pic
    quil "好吧，我明白了，我的好奇心让你感到烦扰，但至少告诉我你为什么来这里？拜托了？"
    hide side_q
    npc "...为了帮助一位天空的朋友打破他的枷锁。"
    show side_p s at pic
    mc "嗯？"
    hide side_p
    play sound "sound/effects/splash.wav"
    scene lake with wet
    if girl:
        show palmierproxy chill kind at left with dissolve:
            yoffset 40
    else:
        show palmierproxy chill kind at left with dissolve:
            yoffset 100
    show quil flashy sad sweat at right with dissolve:
        yoffset 200
    "在你能追问更多之前，人鱼跃入空中，然后扑通一声跳回水中。"
    "冲击力如此之大，以至于你和奎尔都被这一动作完全淋湿了。"
    quil ow frusta "不要啊！回来！"
    play sound "sound/effects/bump.mp3"
    show palmierproxy apa sweat shock with move:
        xalign 0.6
    "奎尔向前倾身，闷闷不乐，几乎想要游过去追她。你立即将奎尔拉入怀中。"
    "在他再次做出什么蠢事之前制止了他。"
    show quil skul sulk sigh
    mc ha sigh "奎尔，她走了，这就是钓鱼的本质。捕获然后释放。你捕获，然后释放。"
    mc happy -sweat bunga "作为你的第一次捕获，还不错。"
    quil ow frusta "呵，如果不是因为她的离开让我如此沮丧，我会笑出来的。看那magnificent的生物离去！"
    show palmierproxy wry 
    show quil wry sigh
    "当你拍拍他的头时，他又开始闷闷不乐。过了一会儿，你准备放开他。"
    play sound "sound/effects/cloth.mp3"
    show quil laugh blush bloom behind palmierproxy with move:
        xalign 0.7
    show palmierproxy frown both shock
    "然而你没想到奎尔反而加深了拥抱。"
    "将头埋在你的肩窝里。"
    show quil datar at right with move
    mc wry tanya "奎尔？"
    quil talk sigh "谢谢你。"
    mc huh -tanya "因为差点让你被人鱼攻击致死？"
    quil hister -sigh "因为帮我找到了一条人鱼，亲爱的。我从未想过我能活着见到它。"
    quil talk "你真是个创造奇迹的人，[povname]。"
    mc happy tanya "我还以为只有你才拥有那个头衔呢。"
    quil laugh blush bloom "只在魔法和符文方面。而你的奇迹...却是不同的。"
    mc ha sweat sigh "谢谢你，奎尔。顺便问一下，你不会恰好知道一个能让我们变干的符文吧？"
    quil flashy wink cling "事实上..."
    play sound "sound/effects/clap.mp3"
    show palmierproxy frown -sweat shock
    "奎尔拍了拍手，让你们俩都变干了。"
    show quil laugh bunga
    "显然有一系列\'家务符文\'可以帮助处理日常琐事之类的。"
    "你让奎尔一路上滔滔不绝地向你讲述这些，直到回到宿舍。"
    stop music
    scene bg_black with w20
    $ night = False
    $ evening = True
    $ afternoon = False
    $ morning = False
    scene lor_mlm with w20
    play music "MUSIC/MusMus-BGM-082.mp3"
    jump ur_room
label quil_filler1:
    stop music
    scene court_hi with w20
    if girl:
        show palmierproxy kind at left with dissolve:
            yoffset 40
    else:
        show palmierproxy kind at left with dissolve:
            yoffset 100
    show quil skul datar at right with dissolve:
        yoffset 200
    play music "MUSIC/MusMus-BGM-083.mp3"
    quil heh apa "你相信占卜吗？"
    $ quil_events.append("filler1")
    mc "占什么？"
    quil flashy wink cling "塔罗牌，水晶球，手相阅读？"
    show pboy at horzappear
    menu:
        "我是信徒！":
            hide pboy
            mc wry tanya "当然。我是说，魔法是真实存在的，那为什么占卜不行呢？"
            show palmierproxy happy -tanya
            quil err sweat frusta "魔法通过符文墨水和巫师得到了证实，占卜却没有。"
        "你是说胡说八道？":
            $ bff.points += 5
            hide pboy
            quil laugh blush bunga "哦，看来我们想法一致。"
    quil skul tantrum sweat sigh "我在波比的这门课上快要挂科了。我选它作为选修课是因为我以为会很容易拿A。"
    quil grit frusta "然而，我显然低估了这门课，哈..."
    quil sulk sigh "手相阅读是我最弱的科目。除了一堆皱纹，我从来不明白我应该看到什么。"
    
    mc "你想和我一起练习吗？"
    quil amused -sweat -sigh "嗯，好吧，我想也无妨。来，把你的手给我。"
    show palmierproxy wry with move:
        xalign 0.56
    mc tanya "看到什么了吗？"
    quil flashy bingung sigh "你出汗很多，需要多用点保湿霜，但是没有，什么都没看出来。"
    quil talk apa "你为什么不试试给我看手相呢？"
    show quil sly -apa
    show pboy at horzappear
    menu:
        "认真尝试":
            hide pboy
            $ bff.points += 5
            $ honesty += 10
            mc mean cling "好的。"
            "你开始认真检查奎尔的手掌，查看所有的线条和曲线。"
            mc frown -cling "嗯，你有一条长长的财运线，所以金钱很容易来到你身边，不过你在爱情方面似乎运气不佳。"
            quil heh apa "亲爱的，这不是很明显吗？你确定你不是在总结我的人生吗？"
            mc wry "你在爱情上运气不佳，尤其是在对待女性方面表现糟糕。"
            quil err frusta "再说一遍，我可以告诉你。我的初恋尤其不顺利。"
            mc confused tanya "哦？她是那个错过的人吗？"
            quil malu sigh "不完全是。那并不是多么深刻的爱情，虽然我想它已经转变成一种更像家人般的爱了。"
            quil tantrum frusta "可悲的是，这有点扭曲，因为每次我们见面，总是变成一场互相侮辱的战斗。"
            mc kzl shock "等等，你说的是菲亚吗？"
            quil smile -frusta "还能是谁？她是第一个让我心碎的女孩。诚然，我们那时只有9岁和10岁，但是..."
            mc apa -shock"所以，等等，你对她如此刻薄...只是为了引起注意？"
            quil amused sigh "是的，而且我非常幼稚和小气。"
            mc eiden "（好吧，至少你能承认这一点。）"
            show palmierproxy frown shock
            quil laugh -apa "亲爱的，这就是全部了吗，还是你只是在找借口握我的手？"
            mc huh sigh "你想得美。"
            show quil kzl shock at right with move
            quil tantrum frusta "哼，你应该说是的，那样会很可爱！"
        "戏弄他":
            $ bff.points += 5
            hide pboy
            show palmierproxy mean blush cling
            show quil sulk both shock
            "你决定挑逗地摩擦他的手掌，playfully地与他十指相扣。"
            quil err -shock "...这不是占卜。"
            mc smile cling "你似乎并不介意。"
            quil sulk frusta "别捉弄我了，这一点都不好笑！"
            mc mock bunga "是很好笑，你的脸都红了！"
            quil tantrum frusta "啊！"
            show quil sulk -frusta at right with move
            play sound "sound/effects/slap.mp3"
            "奎尔开始转过头去，反复拍打自己的脸。"
            quil ow frusta "还是红的吗？"
            mc hister bloom "更红了。"
            quil groan frusta "哦，该死！"
        "吓唬他":
            hide pboy
            $ bff.points -= 10
            $ honesty -= 10
            mc frown sigh "嗯，目前还没有什么明显的..."        
    show quil frown sweat shock
    mc mock cling "啊，但我确实看到你的生命线很短。你可能很快就会死。"
    quil grit sweat frusta "什么？！根本没有这么说！收回你的话！"
    mc flirt -cling "我是认真的。"
    if "io4" not in my_events:
        quil kzl sigh "不可能！我拒绝接受。我要去问波比小姐！"
        play sound "sound/effects/walk.mp3"
        scene bg_black with w20
        scene kls_potion with w20
        show poppy hair laugh at center with dissolve:
            zoom 0.9
            xzoom 0.97
        show quil sulk frusta at right with dissolve:
            yoffset 200
        if girl:
            show palmierproxy scratch wry sigh at left with dissolve:
                yoffset 40
        else:
            show palmierproxy scratch wry sigh at left with dissolve:
                yoffset 100
        "不知怎的，你最后被拖到了波比小姐的房间，她评论说奎尔确实有一条短生命线。"
        "这让那个男人更加沮丧，直到她说\"短\"仅仅意味着不到100岁，因为他是人类。"
        "这是可以理解的，考虑到维尔科娃和凯普勒都已经超过300岁了。"
        stop music
        scene bg_black with w20
        "尽管如此，你还是花了剩下的时间试图让奎尔振作起来，因为他认为自己会在30岁之前就死去。"
        "当你回到宿舍时，已经是黄昏了。"
    else:
        quil kzl sigh "不可能！我拒绝接受。我要去问海德温女士！"
        scene bg_black with w20
        "你试图询问海德温女士，但她最后却跑题了，开始谈论科尔。"
        "经过一场漫长的讲座后，你们俩决定回到宿舍休息。"
    
    $ evening = True
    $ morning = False
    $ afternoon = False
    scene lor_mlm with w20
    play music "MUSIC/MusMus-BGM-082.mp3"
    jump ur_room

label quil_date2:
    play music "MUSIC/MusMus-BGM-136.mp3"
    scene tengah with fade
    $ quil_events.append("date2_done")
    if girl:
        show palmierproxy scratch confused at left with moveinleft:
            yoffset 40
    else:
        show palmierproxy scratch confused at left with moveinleft:
            yoffset 100
    show quil flashy laugh at right with moveinright:
        yoffset 200
    
    quil spark "亲爱的，你怎么样？希望一切都好。"
    mc side sweat sigh "别说废话了。现在怎么了，奎尔？"
    quil sly cling "这么直接，好吧，如果你坚持的话。" 
    
    if "ghost_time" in my_events:
        quil tantrum sigh "还记得我从雕像和莱尔的血液中提取的墨水样本吗？"
        mc chill frown -sweat -sigh "怎么了？"
        quil skul rajuk frusta "这确实是符文墨水，虽然它与莱尔的血液并不是100%%匹配，但有一些相似之处。"
        quil frown -frusta "这与你和塞恩所说的科尔的血液一直都是符文墨水的说法相符。"
        quil tantrum sweat "但我发现了一些更令人担忧的事情。"
        mc confused tanya "继续说。"
    else:
        quil tantrum sigh "我想我的家人一直在给我注射巫师血液。"
        mc ow sweat shock "什么？！"
        show palmierproxy sad -shock

    if "date1_done" in quil_events:
        quil err -sigh "那些我小时候注射的药剂，就是我在我们第一次约会时告诉你的那些..."
        quil sad "...我想它们是巫师血液。"
    else:
        quil sad sigh "你看，我小时候经常注射疫苗，因为我不是一个很健康的孩子。"
    if "ghost_time" in my_events:
        quil err -sigh "出于一时兴起，我取样了剩余的疫苗之一，发现它们与莱尔的血液完全匹配。"
        mc ow sweat shock "什么？！"
        show palmierproxy sad -shock
        quil mock sweat sigh "这就是我最初的反应，当然，表达得更加得体一些。"
    else:
        quil sulk sigh "你看，事实证明英克威尔家的孩子们出生时都不健康。"
        quil tantrum -sigh "或者至少从我们接受的大量加强针来看是这样的。"
        quil frown -sigh "我想知道这是否与佩纳在梅扎那里的奇怪行为有关，结果我猜对了。"
        quil grit frusta "佩纳他...他发现所有英克威尔家的婴儿从出生起就持续被注射巫师血液。"
        mc ow sweat shock "但这...什么？！这毫无道理，我以为你们家族是猎杀巫师的！"
        show palmierproxy sad -shock
        quil mock sweat sigh "真会说废话啊，亲爱的。"
    show quil sulk -sigh
    mc kzl frusta "为什么你们家族要给你们注射巫师血液？"
    quil kzl sigh "这正是我试图弄清楚的。我问过佩纳，他承认很久以前就发现了这件事。"
    quil tantrum -sigh "但是，他还是告诉我这不是我应该插手的事，而应该让\'大人们\'来处理。"
    mc panik sigh "让我猜猜，你不打算那么做，对吧？"
    show palmierproxy rajuk -sweat -sigh
    quil flashy grit -sweat frusta "当然不会！我不能只站在这里装漂亮。我必须调查这件事，同时还要保持漂亮！"
    mc ha tanya "当然，那么你具体想让我做什么呢？"
    quil panik sweat -frusta "嗯，你看。我和我父母的关系并不是很好。"
    show palmierproxy confused -tanya
    quil hister "恋父情结在我们的朋友圈里很常见，我也不例外。"
    quil panik "自从春天以来，我就没有亲眼见过我父亲。"
    mc frown sigh "哦，好吧，那还不算太糟糕——"
    quil mock "...两年前的春天。"
    mc ew shock "哦。"
    show palmierproxy frown -shock
    quil laugh -sweat "所以，我一直在思考该怎么做才能让我亲爱的父亲终于注意到我，然后我就有了一个绝妙的主意。"
    quil wink cling "结婚！"
    mc scratch huh frusta "...你说什么？"
    show palmierproxy kzl -frusta
    quil ejek -sweat spark "订婚，婚约，自从14岁起我一生都在逃避的事情。"
    quil sly sigh "一个假订婚肯定能引起我父亲的注意。见见家长，就像你们平民说的那样。"
    quil smile cling "而且我们还没有灵魂绑定，这会让我父亲更加生气。他会问为什么我们没有让我们的联结永久化。"
    show pboy at horzappear
    menu:
        "我不会和你结婚的！":
            hide pboy
            $ honesty += 15
            $ kindness -=15
            mc pissed frusta "哦不，我不是要和你结婚！"
            mc grit sigh "去他的！"
            quil heh cling "真可爱，你居然以为你有发言权。但别担心，我并不是真的要和你结婚，只是..."
            quil wink -cling "...布置一下场景。"
            "不顾你的感受，奎尔开始单膝跪地。"
            show pboy at horzappear
            menu:
                "坚持":
                    hide pboy
                    $ bff.points = 0
                    play sound "sound/effects/bump.mp3"
                    "你把他推了起来，不想让这事继续下去。"
                    mc grit frusta "不就是不，奎尔！不准求婚！"
                    quil grit sweat frusta "...你真的刚才像训斥宠物一样训斥我吗？"
                    quil err -frusta "好吧，我想我不能强求\'爱情\'，即使只是为了更崇高的目的而假装的。"
                    quil tantrum sigh "你的损失，亲爱的，但别以为你还有第二次机会。"
                    quil sad frusta "我想我得找其他方法来面对我父亲了。"
                    hide quil with dissolve
                    play sound "sound/effects/walk.mp3"
                    "奎尔离开了。他看起来很失望，这一次他似乎没有沉浸在云里雾里。"
                    $ bff.hint = "恋爱路线被封锁。你决定不帮助奎尔，因此被封锁在他的恋爱路线之外。"
                    $ NPC = "???"
                    scene bg_black with w20
                    if "bunga_bego" in buff_events:
                        if "beku" in quil_events:
                            scene map_infected_f with w20    
                        else:
                            scene map_infected with w20    
                    else:
                        if "beku" in quil_events:
                            scene map_frozen with w20
                        else:
                            scene map_all with w20
                    jump world_map
                "让他求婚":
                    hide pboy
                    pass

        "单膝跪地":
            hide pboy
            $ kindness += 5
            $ bff.points += 5
            show palmierproxy wry blush sigh at center with move
            if girl2:
                quil skul err sweat shock "等等，你在做什么？"
                mc smile cling "求婚？我是说，还有什么地方比在这里，在所有人面前更适合求婚呢？"
                mc confused -cling "你想让你的家人相信我们的订婚，对吧？"
                quil tantrum sigh "是的，但你是个淑女。我不会让一位淑女单膝跪地求婚的。"
                quil groan frusta "而且...你也不了解我们世界的习俗。"
                quil flashy laugh -sweat cling "所以，咳咳，让我来做这个荣耀的事吧。"
                
            else:
                mc smile tanya "奎尔·英克威尔，你愿意给我成为你丈夫的荣耀吗？"
                quil err sweat apa "等等，就这样？这就是你们世界的人求婚的方式？太平民化了！"
                quil kzl frusta "不，不，这可不行。站起来。让我来做这个！"
                show quil flashy laugh -sweat cling


        "你不打算求婚吗？":
            hide pboy
            $ honesty += 5
            quil flashy heh cling "嗯，好吧，我想这群人对于公开求婚来说已经足够好了。"
    show palmierproxy frown blush shock
    $ quil_events.append("tunangan")
    "奎尔单膝跪地，轻轻握住了你的右手。"
    if girl:
        show tunangan_f with flashbulb
        galleryunlock tunangan_f
    else:
        show tunangan_m with flashbulb
        galleryunlock tunangan_m
    quil talk blush spark "从你的发梢到脚尖，我将爱你的每一寸，无论灵魂还是身体。"
    quil sly cling "即使我们的骨骼化为尘土，直到时间不再存在，我们的灵魂完全消融在极乐世界或深渊之中..."
    quil wry "...我永远不会停止成为你的人，而你也是我的——珍惜并拥有。"
    quil "去爱和关怀。只要你愿意，我的心和灵魂就是你的。"
    show side_p f at pic
    mc apa shock "（哇，所以即使死后也是如此？这里的婚姻看来更加坚定啊。）"
    hide side_p
    quil laugh -cling "...这时你应该说，\'我愿意\'。"
    show side_p w at pic
    mc scratch ha both "哦，呃。好的，当然。"
    hide side_p
    if girl:
        hide tunangan_f with dissolve
    else:
        hide tunangan_m with dissolve
    show palmierproxy chill wry -both sigh
    quil heh "哼，你总是这么善于表达吗？"
    quil laugh "不过我想这样就可以了。"
    "在你的无名指上深深一吻后，奎尔开始站起身来。"
    show quil skul datar -blush 
    show palmierproxy frown at left with move
    "你周围的人开始窃窃私语，显然被奎尔的盛大举动震惊了。"
    $ NPC = "???"
    npc "他们刚刚是不是——天哪，他们订婚了？"
    npc "我就知道他们互相喜欢！"
    quil sly cling "很好。消息应该会以这样或那样的方式传到我父亲那里。"
    quil flashy wink spark "当一个人求婚时，通常会进行灵魂绑定仪式。当然，我们这些放荡的人是不会那么做的。"
    quil wry -spark "我敢肯定他会气得发狂！不过可能要一两周他才会真正来找我们。"
    quil hister sigh "毕竟生意第一。哦，好吧，我相信邀请我们去他的庄园的邀请很快就会来的。"
    mc confused tanya "等等，你们不住在一起吗？"
    quil skul rajuk frusta"只有在冬天，即使那样我们能碰面都是个奇迹。"
    quil amused apa "我们各有各的小住处，你不是吗？"
    mc grit frusta "不是！好吧，我是说，现在是有了，但那是租的。我父母可没给我一个家让我闲逛。"
    show quil -apa
    mc side sigh "（这个该死的被宠坏的家伙。）"
    if "kissu1" in active_quests:
        mc frown -sigh "（啊！但我想这是完成迪特里希请求的最佳时机！）"
        show quil frown shock
        mc happy bunga "嘿奎尔，也许我们应该再添加些证据来说服你父亲。"
        quil err apa "你什么意思，公开求婚还不够吗？还有什么能比这更好的？"
        mc smile cling "一个吻？"
        show palmierproxy at center with move
        quil sulk both shock "我-呃-什么？！"
        mc hister bloom "一个吻，别告诉我你从来没有过？"
        quil tantrum frusta "我，嗯，还没有初吻有什么问题吗？我还年轻！"
        quil sulk sigh "还有很多时间可以...亲热！"
        mc huh tanya"\'亲热\'，真的吗？你打算用这个来说服你父亲我们订婚了？"
        show palmierproxy wry -tanya
        quil grit frusta "如果需要的话，我可以扮演放荡的荡妇，我已经这样做很久了！只是你嘛...你就是你。"
        quil sulk "别用[povname]的脸跟我调情，这不公平！"
        mc flirt cling "好吧，可惜这是我唯一的脸，所以你最好习惯它。"
        mc smile -cling "来吧，只是一个吻而已，就当是练习。"
        quil fluster sigh "我...好吧。快点结束这个。"
        mc happy blush cling "多么浪漫啊，现在过来。"
        if girl:
            show quil_f_fountain with flashbulb
            galleryunlock quil_f_fountain
        else:
            show kiss_quil with flashbulb
            galleryunlock kiss_quil
        quil "嗯！"
        "你用力一拉，双手环绕着奎尔的脖子，在他的唇上深深一吻。"
        "一开始很温柔，但随后为了确保效果你加深了这个吻，因为你记得你需要这该死的照片证据。"
        mc "（我需要拿出手机，除非已经有人在给我们拍照？）"
        "环顾四周，你确实看到普莉姆拿着她的手机，试图抓拍一张照片。"
        "你决定加大力度，不给奎尔注意到普莉姆的机会。"
        if not girl:
            show kiss_quil2 with dissolve
            galleryunlock kiss_quil2
            hide kiss_quil
        quil "哈，等等，我嗯！"
        "你变得大胆起来，用舌头探索奎尔的口腔，尽可能地品尝着他的味道。"
        "他尝起来像草莓和牛奶，与你通常亲吻的那些男孩形成了鲜明对比。"
        "他们的嘴通常充满酒精的辛辣或烟草的苦涩。"
        "这绝对是一个不错的变化。"
        if girl:
            hide quil_f_fountain with dissolve
        else:
            hide kiss_quil2 with dissolve
        play sound "sound/effects/crash.mp3"
        show palmierproxy frown shock
        quil sulk both frusta"时间...时间暂停，啊！" with vpunch
        "奎尔喘着气平躺在地上，双腿像果冻一样软弱无力。"
        mc confused sweat tanya "你还好吗？"
        quil wry blush bunga "嗯。"
        mc frown shock "（哦，他难得一次这么温顺。）"
        mc wry -sweat "奎尔？"
        show pboy at horzappear
        menu:
            "你真是个乖孩子。":
                hide pboy
                $ bff.points += 5
                quil hister bloom "嗯。再多夸夸我。"
                mc happy "你做得太棒了。"
                mc smile sigh "你知道，如果一个吻就能让你闭嘴，那我早就这么做了。"
            "抚摸他的头发":
                hide pboy
                quil malu "嗯嗯。"
                $ honesty += 5
                mc smile sigh "你知道，如果一个吻就能让你闭嘴，那我早就这么做了。"
            "轻拍他让他清醒过来":
                hide pboy
                $ bff.points -= 5
                if bff.points <0:
                    $ bff.points = 0
                $ kindness -= 5
                show quil sad both shock
                show palmierproxy frown 
                "你轻轻拍了拍他的脸颊，让他从恍惚中清醒过来。他羞涩地摇了摇头。"
                quil sulk "我...你的吻技真好，[povname]。"
                mc smile "我经常听人这么说。"
                mc happy sigh "如果一个吻就能让你闭嘴，那我早就这么做了。"
        quil grit both shock "我，什么？！哦，闭嘴！"
        play sound "sound/effects/punch.mp3"
        queue sound "sound/effects/cloth.mp3"
        "奎尔恢复了理智，站起来拍开了你的手。"
        show palmierproxy frown sweat shock
        "他的脸红得像甜菜根，可能没想到自己刚才会那样表现。"
        quil sulk "咳咳。好吧，这应该足够点燃火焰了。"
        quil flashy wink blush cling "当亲爱的老爸发脾气召唤我们去他那不太谦逊的住所时，我会给你打电话的。"
        quil talk -cling "希望到时我们能见到他，他会回答我的问题。"
        mc confused sigh "做这么多只是为了和你自己的父亲说话。"
        mc side frusta "我讨厌自己已经习惯了这种混乱，奎尔。"
        show palmierproxy frown -frusta
        quil laugh bloom "哦，我相信你最终会爱上我带来的所有混乱和疯狂的，[povname]！"
        quil heh sigh "你和我的[povname]并没有我想象的那么不同。"
        quil sly -blush cling "不管怎样，我很想给你更多有趣的感觉，但我还有课要上。"
        quil smile -cling "再见啦，我的爱！"
        mc malu sigh "再见。"
        scene tengah with dissolve
        "奎尔走后，你决定去追普莉姆。她非常乐意与你分享她的照片。"
        $ InvItem(*item_poto).pickup(1)
        "你把照片发给了迪特里希以完成任务，可惜普莉姆没那么容易放你走，开始单方面玩二十个问题游戏，一直到黄昏。"
        stop music
        scene bg_black with w20
        "当她终于结束时，你已经累得什么都不想做了，直接回宿舍去了。"
        if "kissu1" not in completed_quests:
            python:
                InvItem(*item_poto).toss(1)
                active_quests.remove("kissu1")
                completed_quests.insert(0, "kissu1")
                gold += 500
            show screen completedtask("任务完成！")
            "显然，你订婚的消息已经传到了迪特里希那里，他给了你一些额外的金币奖励。"
        else:
            pass
        $ evening = True
        $ morning = False
        $ afternoon = False
        scene lor_mlm with w20
        play music "MUSIC/MusMus-BGM-082.mp3"
        jump ur_room
    else:
        mc scratch huh frusta "你知道，我希望你别那么频繁地利用我。"
        mc chill deject sigh "或者至少为你造成的所有麻烦给我一些补偿。"
        quil bingung sweat sigh "嗯，好吧，既然你这么说，我想你说得有道理。"
        quil flashy smile -sweat cling "我带你去个地方怎么样？这次是个真正不错的地方？不只是为了欣赏风景。"
        mc mean "嗯，有多好？"
        quil talk -cling "那里很朴素，但食物简直是神级的，比我去过的任何七星级餐厅都要好。"
        quil laugh "而且不在城里，所以只要我们在宵禁前回来，修女们就会让我们去。"
        quil wink cling "当然，所有费用由我承担。这很公平。"
        mc smile "好，成交。带路吧。"
        play sound "sound/effects/cloth.mp3"
        show quil datar at center behind palmierproxy with move
        show palmierproxy -sigh with move:
            xalign 0.42
        "奎尔向你伸出手臂。你挽住他的手臂，跟着他走向他要带你去的地方。"
        scene bg_black with w20
        play music "MUSIC/MusMus-BGM-022.mp3"
        scene desa_center with w20
        "在所有地方中，你没想到会是海边的一家朴素餐厅。"
        if girl:
            show palmierproxy chill kind at left with moveinleft:
                yoffset 40
        else:
            show palmierproxy chill kind at left with moveinleft:
                yoffset 100
        show quil flashy laugh at right with moveinright:
            yoffset 200
        if "desa" in buff_events or "desa" in tom_events:
            "不过，这并不意味着你不喜欢去莱纳尔。"
            mc smile "哦，我没想到你会带我来这里。"
            quil skul amused "你以前来过这里吗？"
            if "desa" in buff_events:
                mc kind "是的，和莱尔一起来过。"
            else:
                mc kind "和阿什姆一起。"
            mc smile"但我从未光顾过这家餐厅。"
            quil laugh "你会喜欢的，这个村子有全伊格尼亚最好的火腿。"
            quil datar "来，让我点一份品尝拼盘。"
        else:
            mc kind "这是什么地方？"
            quil amused "阿尔贝因角落。虽然位于莱纳尔这个偏僻地方，但这里相当不错。"
            quil smile "莱纳尔是个渔村，他们有全伊格尼亚最好的火腿。讽刺的是，相比之下他们的鱼只能算一般。"
        show palmierproxy 
        "你点头喝了一口奎尔点的酒。只是浅尝一口，然后又回到了你的果汁。"
        if "anak_hilang" not in fia_events:
            "有时你真的希望自己没有戒酒。"
            
            scene desa_center with dissolve
            "当你试图享受饮料时，欢快的音乐在背景中响起，你不禁转头朝声音传来的方向看去。"
            show har at center with dissolve
            show kid1 with dissolve:
                xalign 0.3
                yalign 1.0
            show kid_blind with dissolve:
                xalign 0.7
                yalign 1.0
            "你看到一群孩子围着一个戴着大眼镜的引人注目的男人。"
            "那个男人举着玩具木偶，几十个孩子乖巧地坐在他周围。"
            if "desa" in buff_events or "desa" in tom_events:
                show side_p f at pic
                mc "（又是那个木偶戏啊？孩子们一定很喜欢他）"
                hide side_p
            else:
                show side_p f at pic
                mc "木偶戏？"
                hide side_p
                show side_q skul frown at pic
                quil "哦，是的，我听说过那个人。欧文。"
                quil "他是个来自卡斯特里的哑巴，正在这里寻找治疗他的病的草药。"
                hide side_q
                show side_p f at pic
                mc "有治愈他哑巴的方法吗？"
                hide side_p
                show side_q skul frown at pic
                quil "也许吧？卡斯特里是个有点奇特的城市。他们比其他地方先进得多。"
                quil "只有沃特克的浮空船能与之相媲美，但即便如此，在医学创新方面也没有人能与卡斯特里匹敌。"
                quil "我确实听说这个岛上有许多稀有植物，尽管这里比大多数地方都要贫瘠。"
                quil "由于某些原因，这个地方处于永恒的秋季状态，所以农作物在这里生长不良，肉类和鱼类是莱纳尔的主要蛋白质来源和收入来源。"
                show side_q skul smile
                quil "但我不该用我渊博的知识让你感到无聊。"
                hide side_q
            scene desa_center with dissolve
            if girl:
                show palmierproxy chill kind at left with moveinleft:
                    yoffset 40
            else:
                show palmierproxy chill kind at left with moveinleft:
                    yoffset 100
            show quil skul datar at right with moveinright:
                yoffset 200
            quil heh "[povname]，你想点什么？毕竟今天是属于你的日子。"
            quil smile "我不介意今天宠坏你。"
            mc scratch malu tanya "嗯，我能点整个菜单吗？"
            quil amused cling "如果你能吃完的话，当然可以。"
            mc chill smile -cling "实际上，我在想把它分享给孩子们。"
            show quil frown shock
            "你又瞥了一眼正在看木偶戏的孩子们，其中一些人穿着破烂的衣服。"
            "其中一个看起来特别瘦弱，几乎只剩皮包骨；那个眼睛上缠着绷带的失明孩子。"
            quil rajuk -shock "...你想和这里的孩子们分享你的食物？"
            mc happy blush "是啊。这没什么问题吧？我是说，你很富有。"
            quil smile bunga "啊哈哈。确实如此...好吧，既然如此，我们为什么要止步于此呢？让我们点一整个餐厅的食物，给每个人一顿丰盛的大餐吧！"
            "奎尔现在兴奋起来，他叫来服务员分享了他的要求。服务员睁大了眼睛，但很快脸上就挂上了温和的笑容，因为他理解了奎尔的意图。"
            scene desa_center with dissolve
            show kid1 at left with dissolve:
                xalign 0.25
                yalign 1.0
            show kid_blind with dissolve:
                xalign 0.8
                yalign 1.0
            show kid2 at center with dissolve:
                yalign 1.0
            "很快，一道又一道菜从厨房端出来，你们两个帮忙把食物端给孩子们，所有人都高兴地围在你们的桌子旁吃得饱饱的。"
            $ NPC = "孩子们"
            npc "哦，谢谢你，先生！这太好吃了！"
            $ NPC = "男孩"
            npc "等等，我也想尝一口！"
            "那个失明的孩子尖叫着，试图找出方向，而其他孩子贪婪地从他那里抢走食物。"
            "出于怜悯，你走向那个孩子，却被一个看起来与他很亲近的小女孩挡住了去路。"
            $ NPC = "女孩"
            npc "给，史蒂夫，我给你拿了一个盘子！"
            play sound "sound/effects/punch.mp3"
            npc "嘿！" with vpunch
            hide kid2 with dissolve
            show har kzl at center with dissolve
            "令你惊讶的是，木偶师从孩子手中抢走了盘子。然后他贪婪地狼吞虎咽起来。"
            $ NPC = "史蒂夫"
            npc "你...为什么？"
            hide kid_blind with dissolve
            hide kid1 with dissolve
            if girl:
                show palmierproxy chill kzl frusta at left with moveinleft:
                    yoffset 40
            else:
                show palmierproxy chill kzl frusta at left with moveinleft:
                    yoffset 100
            show quil flashy kzl frusta at right with moveinright:
                yoffset 200
            "失明的孩子开始哭泣。你和奎尔显然都被这一幕所困扰。什么样的成年人会欺负一个无助的孩子？"
            show har mad shock
            "奎尔大步冲向那个男人。"
            hide har with moveoutleft
            "欧文似乎注意到了奎尔的敌意，逃走了。"    
            quil skul tantrum sigh "啧。"
            mc pissed sigh "他到底是怎么回事？"
            quil bingung -sigh "我不知道。如果他饿了，直接开口问不就行了。"
            quil smile "孩子，你没事吧？来，这里有足够的食物给每个人。"
            "奎尔把一个盘子递给那个显然叫史蒂夫的盲眼男孩。"
            show kid_blind at center with dissolve
            show palmierproxy kind -sigh
            npc "谢谢你。"
            quil laugh blush"不用谢。"
            show quil datar 
            hide kid_blind with dissolve
            "奎尔转头看向你，伸出手引导你回到你们的桌子。"
            show palmierproxy smile blush
            quil flashy heh cling "现在这事解决了，要不要和我一起享用晚餐？这些慈善行为让我饿坏了。"
            stop music
            scene bg_black with w20
            scene lor_mlm with w20
            play music "MUSIC/MusMus-BGM-097.mp3"
            $ night = True
            $ morning = False
            $ afternoon = False
            "在享用了一顿丰盛的晚餐后，奎尔终于带你回到了宿舍，送你到你的房门口。"
            if girl:
                show palmierproxy chill kind at left with moveinleft:
                    yoffset 40
            else:
                show palmierproxy chill kind at left with moveinleft:
                    yoffset 100
            show quil skul datar at right with moveinright:
                yoffset 200
            quil hister spark "今天我玩得很开心。被人善待和崇拜，就像上帝一样，感觉相当不错。"
            mc scratch panik sweat sigh "我不知道上帝那部分是怎么回事，但这肯定比抓巫师强多了。"
            show palmierproxy smile -sweat -sigh
            quil heh blush sigh "嗯，我对此不太了解。不过，[povname]，你真是个很善良的人。"
            if "companion" in my_events:
                if "companion" in red_events:
                    quil hister -blush -sigh "塞恩有你真是太幸运了！"
                else:
                    quil hister -blush -sigh "我现在明白为什么你这么受欢迎了。"
                quil malu -sigh "如果我再快一点，也许我们就会..."
                quil heh sigh "不，别在意。我们该休息了，好吗？"
            else:
                quil malu -sigh "你如此善良...我可能真的爱上你了。"
                $ quil_events.append("naksir")
                show pboy at horzappear
                menu:
                    "尽管爱吧！":
                        hide pboy
                        $ bff.points += 5
                        mc chill happy "嗯，我们已经订婚了。"
                        mc smile "我是说，如果我们在这个过程中坠入爱河，那也是很公平的。"
                        quil sulk sweat sigh "嗯，我不知道是不是爱，但确实是一种迷恋。虽然有点复杂。"
                        quil sad -sweat -sigh "你不会一直留在这个世界吧，对吗？"
                        mc side "不会。嗯，我想是不会的。"
                        quil smile "不过，谢谢你今晚的陪伴。我度过了一个愉快的夜晚，"
                        mc happy "好的。晚安，奎尔。"
                        quil wry "晚安，亲爱的。"
                    "不。":
                        hide pboy
                        $ kindness -= 30
                        $ honesty += 20
                        $ bff.points -= 25
                        if bff.points <0:
                            $ bff.points = 0  
                        quil sad "不是？"
                        mc wry sigh "不。但这不是因为你，是我的问题。"
                        mc smile cling "你看，我有一种慢性病，叫做\'标准\'。"
                        show palmierproxy mock -cling
                        $ quil_events.remove("naksir")
                        quil grit both frusta "啊！我从没想到。看来你真的和[povname]一样。"
                    "谢谢，但是...":
                        hide pboy
                        $ bff.points -= 15
                        if bff.points <0:
                            $ bff.points = 0
                        show quil sad sweat shock
                        $ quil_events.remove("naksir")
                        mc side frusta "我很感激，但这有点复杂，不是吗，奎尔？"
                        mc sad sigh "我不会一直留在这个世界的。"
                        quil sulk sigh "啊，这倒是真的。但也许..."
                        quil smile -sigh "不，你说得对。别在意，谢谢你今晚的陪伴。我度过了一个愉快的夜晚。"
                        mc smile -sigh "好的。晚安，奎尔。"
                        quil wry -sweat "晚安，亲爱的。"

                    "亲吻他":
                        hide pboy
                        show palmierproxy kind blush at center with move
                        quil sulk both shock "唔！"
                        $ bff.points += 15
                        if girl:
                            show kiss_fem2 with flashbulb
                            galleryunlock kiss_fem2
                        else:
                            show kiss_quil_night with flashbulb
                            galleryunlock kiss_quil_night
                        "你大胆地在奎尔的嘴唇上轻啄了一下。效果立竿见影，他的脸瞬间变得通红，像个熟透的番茄。"
                        quil "这...这不公平。我本来想先吻你的！"
                        mc "哈哈，好吧，没人阻止你再吻我一次。"
                        quil "不，时机不对！我在脑子里都计划好了，要倾身过去轻轻吻你的脸颊。"
                        quil "然后你会脸红，我就跑回我的房间，然后——"
                        mc "奎尔..."
                        quil "嗯？"
                        mc "闭嘴。"
                        quil "嗯！"
                        if girl:
                            hide kiss_fem2 with dissolve
                        else:
                            hide kiss_quil_night with dissolve
                        "又一个吻，这次更深入。你舔了舔他的下唇，引得他明显地颤抖，同时收紧了环在你腰间的手。"
                        "他轻声呜咽，然后在你结束这个吻时深深地叹了口气。"
                        show palmierproxy at left with move
                        mc smile bloom "今天我玩得很开心，奎尔。"
                        quil malu blush bunga "...我也是。"
                        quil hister "虽然我没想到会有这么热烈的结尾。你是不是要把我毁了？"
                        mc flirt cling "哈哈，谁知道呢。也许如果你哪天想不再当处男的话。"
                        quil malu "嗯。好吧，我倒是不反对这个想法。"
                        "奎尔的脸更红了，但你能感觉到他在你怀里变得有些僵硬。他似乎在想些什么。"
                        quil wry sigh "但今晚不行。"
                        mc laugh sigh "不，今晚不行。不过我希望我们不必等到你父母家才能做。"
                        show palmierproxy kind -sigh
                        quil heh -blush -sigh "呃，你能想象吗？我和你像兔子一样疯狂，而我父亲就在隔壁？"
                        quil laugh "多么令人震惊啊！"
                        mc happy "哈哈。我希望你和你父亲能和解，奎尔。我希望这个巫师血统的问题不像你想的那么严重。"
                        show quil sly 
                        "奎尔点了点头，但明显缺乏热情。"
                        quil wry "只能这么希望了。"
                        quil malu blush "晚安，[povname]。"
                        mc smile "晚安。"
                play sound "sound/effects/walk.mp3"
                stop music
                scene lor_mlm with dissolve
                "奎尔回到了他的宿舍。你也该上床睡觉了。"
                stop sound
                play music "MUSIC/MusMus-BGM-082.mp3"
                jump ur_room
        else:
            scene bg_black with w20
            $ night = True
            $ morning = False
            $ afternoon = False
            "你们两个共进了一顿美好的晚餐，然后回到了宿舍。"
            stop sound
            scene lor_mlm with w20
            play music "MUSIC/MusMus-BGM-082.mp3"
            jump ur_room


label quill_event1:
    scene church_atas with fade
    play music "MUSIC/MusMus-BGM-035.mp3"
    show quil skul datar at center with dissolve:
        yoffset 200
    "四处寻找后，你看到奎尔正在和一个看起来很年轻的大一新生交谈。"
    $ NPC = "学生"
    $ quil_events.append('q1')
    npc "奎尔，你确定要这么做吗？"
    quil flashy wink cling "哦，相信我，吉吉。一旦消息传出我们已经做了那件事，你父亲肯定会取消你那烦人的婚约。"
    quil hister -cling "别担心，我一定会赞美你的技巧，同时还会保持绅士风度。这就是我的作风。"
    $ NPC = "吉吉"
    npc "好-好吧。不过，我还是无法表达我有多感谢你，奎尔，还有...你确定我们不需要..."
    quil heh sigh "什么，你是在主动提议吗？我的天，你可真大胆啊，小姐！"
    quil laugh -sigh "说实话，我认为你应该把你的贞操留给你爱的人。"
    quil wink spark "别浪费在我这样的花花公子身上。"
    npc "好吧。再次感谢你，奎尔！"
    quil smile"再见！"
    play sound "sound/effects/tile.mp3"
    "那个年轻女孩匆忙离开了。"
    stop sound
    show pboy at horzappear
    menu:
        "处男！！！":
            hide pboy
            $ bff.points -= 10
            if bff.points <0:
                $ bff.points = 0
            $ honesty += 10
            show quil grit sweat shock
            if "virgin" not in my_events:
                $ my_events.append("virgin")
            "奎尔震惊地看着你。你的声音在整个教堂里回荡。"
            show quil groan frusta
            "你甚至能听到下面传来一个熟悉的声音。"
            show npc_1 at pic
            $ NPC = "阿贾克斯"
            npc "是你吗，[povname]？一切都还好吗？"
            hide npc_1
            quil kzl "嘘！嘘！嘘！你可别敢回答他！"
            show pboy at horzappear
            menu:
                "咬他的手指":
                    hide pboy
                    if girl:
                        show lick_cew with dissolve
                        galleryunlock lick_cew
                    else:
                        show lick with dissolve
                        galleryunlock lick
                    quil "啊啊啊！"
                    show npc_1 at pic
                    npc "[povname]？"
                    hide npc_1
                    show quil skul sad blush shock
                    mc "只是一只老鼠，阿贾克斯！"
                    quil sulk frusta "你怎么能这样，呃。在所有的——哦，看在科尔的份上，跟我来！"
                    
                "保持安静":
                    hide pboy
                    quil "在所有事情中...呃，跟我来！"
                    



        "平静地回应他":
            hide pboy
            $ kindness += 10
            $ bff.points += 5
            if "virgin" in my_events:
                $ my_events.remove("virgin")
            show side_p f at pic
            mc "所以这就是为什么人们还相信你是个荡夫。"
            hide side_p
            quil skul kzl shock sweat "[nickname]？！你在这里做什么——"
            quil sulk frusta "呃，跟我来！"
    stop music
    play sound "sound/effects/doorslam.mp3"
    
    scene court_hi with dissolve
    "奎尔把你拖到外面的阳台上。幸好那里比平时人少。"
    show quil skul grit frusta at left with dissolve:
        yoffset 200
    
    if not girl:
        show palmierproxy chill mean at right with dissolve:
            yoffset 100
        play sound "sound/effects/slap.mp3"
        show quil kzl
        show palmierproxy pissed shock with vpunch
        "然后他脱下一只手套，用它打了你一巴掌。"
        mc ow frusta"哎哟！"
        mc scratch confused sweat -frusta "（天哪，就连他的巴掌都这么高贵。）"  
        show palmierproxy confused -sweat
    play music "MUSIC/MusMus-BGM-089.mp3"
    if "virgin" in my_events:
        if girl:
            show palmierproxy chill mean at right with dissolve:
                yoffset 40
        quil flashy ow frusta "你他妈的到底有什么毛病？！"
        show quil kzl -frusta
        mc chill mock cling "报复。"
        show palmierproxy smile 
    else:
        if girl:
            show palmierproxy chill mean at right with dissolve:
                yoffset 40
        quil grit frusta "你为什么在这里？！"
        mc wry sigh "你看，一个非常高贵又被宠坏的小白脸突然把我召唤来——"
        show palmierproxy hister -sigh
        quil tantrum sigh "哦，真成熟啊，[povname]。"
    show palmierproxy hister bloom
    show quil skul kzl frusta
    mc "你得让我找个方法扯平。考虑到你让我经历的那些狗屁事，这很公平。"
    show quil tantrum shock
    mc wry tanya "话说回来，你能告诉我为什么你要让全校都相信你是个大荡夫吗？"
    quil kzl frusta "你不会明白的。这对像你这样的局外人来说太复杂了，无法理解。"
    mc huh -tanya "然而这个局外人却发现了你的秘密。试试看吧，奎尔。"
    show palmierproxy malu
    quil sulk sweat sigh "哈啊..."
    quil frown -sigh -sweat "每个家族都需要一个继承人，而每个继承人都被期望履行延续家族血脉的职责。"
    quil groan frusta "婚姻、子女，你懂的。每个家族都希望他们的继承人能与最优秀的人结为伴侣。"
    show palmierproxy frown 
    quil sad sigh "但我...我不想那样。我想被人追求...被人用美酒佳肴款待。"
    
    quil malu bunga blush "最好是一个不怕哭泣，但在床上如野兽般狂野的男人或女人。"
    show palmierproxy confused 
    quil flashy cringe -blush "哦，我还想要一个盛大的快闪求婚！让[povname]、阿什姆和塞恩跟着撅着嘴，因为我的爱人强迫他们这么做。"
    show palmierproxy scratch avoid
    quil sly cling "哦，哦！我还想让这一切发生在学校的庭院里，让所有女人，尤其是菲亚，都能看到。"
    mc ha sweat frusta "（具体是挺具体的，不过好吧。）"
    mc chill deject -frusta -sweat "好吧，所以你想要被浪漫追求。我明白了，完全可以理解。但为什么要撒谎呢？"
    quil sad sigh "像我这样的贵族没有选择约会潜在配偶的自由。一旦我们的父母看中了某个求婚者，那就一切都定了。"
    quil skul panik -sigh sweat "但如果说这个继承人在贵族中名声不佳，那么他们就很难收到任何婚约了。"
    mc frown shock -sweat"哦，所以这就是你一直在做的事？让自己看起来很糟糕，这样就没有一个理智的父母会想把他们的孩子嫁给你？"
    quil flashy ejek cling -sweat "奎尔，那个滥交的浪荡子！"
    show palmierproxy huh frusta
    quil wink spark "当我走进一个房间时，这就是我想听到的全部。所有的求婚者，都因恐惧和厌恶而颤抖。"
    mc scratch ha "有点戏剧化，不是吗？肯定有更好的方法，比如说不？"
    show palmierproxy sad shock
    quil sulk skul sigh "那在你的世界里可能行得通，但在这里不行。尤其是对我父亲来说。他...他的话就是法律。"
    quil sad -sigh "我试过说不。有一次，我甚至试图装傻，降低我的成绩，让人们认为我是个无能的继承人..."
    quil tantrum frusta"...但这么做只是让我无法进入我想去的学校。而且我不会为了赶走求婚者而让自己变丑。"
    quil cringe sigh "我是绝望，不是疯狂。"
    mc scratch panik -shock sweat "（这还有待商榷。）"
    mc chill eiden -sweat tanya "那么...说不行不通，装傻毁了你的工作前景，所以你选择了当荡夫。"
    show palmierproxy kind sigh
    quil flashy wink cling "没错！"
    show pboy at horzappear
    menu:
        "为什么不放弃你的地位呢？":
            hide pboy
            mc apa frusta sweat "别告诉我是因为钱。"
            show palmierproxy malu -frusta -sweat
            quil skul groan -sweat frusta "我可不是迪特里希，谢谢。"
            quil frown sigh "我相信无论有没有爸爸的钱，我都能成为自己的主人。"
            quil ow frusta "问题是，我父亲不会让我的任何堂兄弟成为英克威尔家族的继承人。"
            quil tantrum sigh "尽管我一开始就对这个角色毫无兴趣。"
            quil sad sweat -sigh "我不适合成为一个乌鸦。我喜欢研究符文和学习魔法，但杀死巫师？"
            mc huh tanya "然而你现在却在一所猎巫学校里。"
            show palmierproxy wry -tanya
            quil kzl -sweat frusta "只是因为我父亲让我来上学。"
            quil sad -frusta "我还没疯掉的唯一原因是因为我喜欢研究符文。"
            quil heh "至于杀戮，嗯，[povname]做了最困难的部分。我在肉搏战方面毫无天赋。"
            quil tantrum sigh "但我父亲不这么认为。对他来说，我拥有\'完美\'英克威尔的所有特质，所以他真的很想让我领导乌鸦。"
            mc confused tanya "完美的英克威尔？"
            show palmierproxy apa -tanya
            quil flashy talk cling "我的符文天赋，我被墨水染色的白发，还有我的绿眼睛。这些都是英克威尔血统的理想特征。"
            quil sulk sigh "然而，一套好基因很难成为选择继承人的好理由。从才能上来说，我的堂弟佩纳是一个更合适的人选。"
            quil frown -sigh "我只是因为在房间里花了很多时间学习，而大家都以为我在乱搞，所以我才在符文方面很擅长。"
            quil cringe "另一方面，佩纳就像那种12岁却有22年工作经验的人。"
            mc malu tanya "就是那个在家庭聚会上你总是被拿来比较的堂弟？"
            show palmierproxy wry sigh -tanya
            quil malu sigh "一直如此。"
            quil kzl frusta "如果不是因为我父亲的干预和佩纳的肤色，我想我爷爷现在已经宣布他为继承人了。"
            show quil frown -frusta
            mc scratch confused tanya "肤色？"
            show palmierproxy chill frown -tanya
            quil rajuk sigh "他的墨黑色头发和异色瞳。这是我家族中反复出现的\'缺陷\'。不过我不确定为什么会这样。"
            show quil frown -sigh
            mc confused "有意思。"
            if "inkwell" not in topics:
                $ topics.append("inkwell")
                play sound "audio/success.mp3"
                "学会了新话题：{color=#FF1500}英克威尔家族的戏剧性事件。{/color}"
            else:
                mc rajuk "我明白了。你知道，我确实听到一些孩子在谈论你的家庭。没想到竟然这么复杂。"
                quil sad sigh "你根本无法想象。"
            if "genetics" not in topics:
                $ topics.append("genetics")
                play sound "audio/success.mp3"
                "学会了新话题：{color=#FF1500}英克威尔家族的基因。{/color}"


        "这还是不是个好主意！":
            hide pboy
            mc eiden tanya "为什么又没人注意到这个？还有你房间里的那些性爱声音呢？"
            mc confused -tanya "你是怎么做到的？"
            quil sad shock"哦天哪。你们的世界真的那么落后吗？"
            quil blush sulk -shock "如果是这样的话，这可能会让你感到震惊，但是……"
            show quil with move:
                xalign 0.65
            "奎尔凑近你的耳朵，仿佛要低声透露一个巨大的黑暗秘密。"
            quil panik "在我的世界里，有一个网站可以观看人们做爱的动态图像。"
            quil hister "它叫做色——"
            show quil groan -blush shock
            mc pissed frusta "我知道什么是色情片！顺便说一句，我也有视频和电影，别把我当成原始人一样跟我说话！"
            quil avoid cling "那就别表现得像个原始人！"
            show quil amused sigh at left with move
            mc rajuk sigh "（老实说，这个小鬼……）"
            mc sad shock "啊，等等！"
            mc apa tanya "所以这段时间你一直在房间里看音量很大的色情片？你的室友怎么办？"
            quil flashy wink cling "贿赂可以解决很多问题，亲爱的。我的室友不介意。至于那些色情片的声音，嗯……"
            quil skul hister sigh "呃。有时我会听着它入睡。我听过太多色情片了，它甚至不能再让我兴奋了。"
            if "bye_boner" in quil_events:
                mc scratch panik sweat shock "（糟糕，这让我想起来了，我应该取消和阿什姆的那个\'消除勃起\'恶作剧！）"
                show palmierproxy wry -sweat
            else:
                mc scratch hister sweat -tanya "看来你不需要那个\'消除勃起\'了。"
                quil bingung sweat apa "什么？"
                show quil rajuk -sweat
                mc scratch panik -tanya sweat "哦，没什么。"

    mc chill happy sigh "总之，你的秘密在我这里很安全。"
    if "virgin" in my_events:
        mc hister -sigh"我知道我之前在教堂差点害了你，但我实际上并不打算揭穿你。"
    mc malu -sigh "如果吓到你了，我很抱歉。我并不是在取笑你或什么的。"
    show quil frown shock
    mc wry "恰恰相反，我发现你这一面……很可爱。真的非常可爱。"
    show quil skul ow blush -shock 
    mc hister blush bloom "昨晚你惊慌失措的表情真的很可爱。让我有点想欺负你。"
    
    quil panik both bunga -shock "那个，呃……我……"
    quil groan sweat frusta "该死！"
    quil sad "我现在明白为什么[povname]这么受欢迎了。为什么你必须要有[dia]一模一样的脸？"
    quil frown -sweat sigh "既然你知道了我的秘密，我还有一个请求。"
    mc scratch apa sweat shock "又来？"
    quil ow frusta "哦，别露出那么恐怖的表情。"
    quil malu flashy -frusta "这个很简单，我保证。所以……"
    stop music
    jump bersih_mc

label quil_date1:
    scene bg_black with w20
    $ morning = False
    $ evening = False
    $ afternoon = False
    $ night = True
    scene out_night with w20
    play music "MUSIC/MusMus-BGM-097.mp3"
    if girl:
        show palmierproxy jln happy bloom at center with dissolve:
            yoffset 40
    else:
        show palmierproxy jln happy bloom at center with dissolve:
            yoffset 100
    mc "哇哦！"
    show palmierproxy kind at left with move
    show quil libur laugh at right with moveinright:
        yoffset 200
    quil amused cling "景色不错吧？"
    "奎尔挑了挑眉毛看着你。"
    show palmierproxy wry -bloom
    show pboy s at horzappear
    menu:
        "我是说星星。":
            hide pboy
            $ bff.points -= 15
            if bff.points <0:
                $ bff.points = 0
            show palmierproxy malu sigh
            quil heh frusta "我知道。但你应该夸我，否则就不像约会了！"
            mc happy tanya "那我呢？"
            show palmierproxy frown shock
            quil hister spark "你看起来绝对诱人，[povname]。星星根本无法相比！"
            quil wink cling "看到了吗？这不是让你感到特别了吗？"
            mc hister -shock "确实如此，谢谢你！"
            quil ow shock "等等，你还是不打算夸我吗？"
            show quil tantrum sigh
            mc malu blush bunga "（他真的很有趣，不是吗？）"
            show palmierproxy kind -blush
        "满足他的虚荣心":
            hide pboy
            $ bff.points += 5
            mc hister cling "你看起来一如既往地迷人，奎尔。"
            quil hister bunga "现在你明白了。"
        "你和星星都很美。":
            hide pboy
            mc happy cling "没错，你和这景色都令人惊叹。"
            quil mock sigh "哼，这回答真是乏味又安全。不过我就勉强接受吧。"
    show quil datar shock
    mc happy tanya "那么...这是你常带人约会的地方吗？"
    quil sulk sigh "不完全是。"
    show palmierproxy kind -tanya
    quil rajuk blush -sigh "如果你非要知道的话，其实你是我的第一次约会对象。"
    mc eiden sweat shock "哇哦。真的吗？？？"
    show palmierproxy wry -sweat -shock
    quil ow frusta "别用那种眼神看着我！在学习和猎巫之间，我几乎没有时间留给自己，更别说谈恋爱了！"
    show quil bingung sigh -blush
    mc hister -shock "嗯，这倒是真的。不过，看星星确实是个好主意。这里的星星特别明亮，不像我的世界。"
    quil heh cling "实际上，这并不是我们\'约会\'的主要内容。我在等一些东西。"
    quil rajuk -cling "只是不确定要等多久。"
    #berubah
    quil talk shock "哦，等等，来了！"
    #berubah
    jump kelp
    
label kelp:
    show palmierproxy frown shock
    $ quil_events.append("date1_done")
    galleryunlock kelpie
    show kelpie with dissolve:
        zoom 2.0
        xalign 1.0
        easein 2.0 xalign 0.0
    "在远处，你似乎听到了马蹄在湖面上奔跑的声音。等等，湖面？"
    "望向水面，你看到一匹淡绿色的马在水面上奔跑。它飘逸的绿色鬃毛在月光下闪耀。"
    show side_p ha at pic
    mc happy blush shock "哇！那是一匹马吗？"
    hide side_p
    hide kelpie with dissolve
    show palmierproxy kind -shock
    quil heh cling "精灵。"
    
    show quil sly -cling
    mc side tanya "精灵？"
    show palmierproxy frown -tanya
    quil cringe sigh "它是一个风之精灵。你还记得阿什姆施展火焰符文时出现的火之精灵吧？"
    quil smile -sigh "嗯，这个是风之精灵。在野外看到它们是很罕见的。"
    quil talk "当我们施展某些元素符文时，它们的形象有时会出现。"
    quil hister bunga "但那些根本无法与真实的精灵相比！"
    quil amused "这个地方是为数不多的几个还能看到元素精灵的地方之一。没人真正知道为什么。"
    show quil datar shock
    mc happy "你似乎对它们很了解。"
    quil talk -shock "确实如此。老实说，我本想更深入地研究它们，成为一名动物学家，而不是猎巫人。但是当然，家族不会允许的。"
    show quil amused
    mc huh -blush tanya "\'家族\'。你说起来好像你是黑手党的一员似的。"
    show palmierproxy frown shock
    quil sulk sigh "哦，相信我，有时候确实感觉就是这样。"
    quil cringe -sigh "而可怜的、脆弱的小我将来还得接管这个家族..."
    show quil amused 
    mc apa frusta sweat "脆弱个屁。我可是看到你把另一个[povname]揍得屁滚尿流。"
    show palmierproxy frown -sweat -frusta
    quil rajuk sigh "那只是因为[povname]已经精疲力尽了，而我袖子里藏了一堆符文。"
    quil wry -sigh "从身体上来说，我就是个娇弱的小花朵。"
    quil fluster frusta "在我更小的时候，每个月都得打增强针才能下床。"
    show quil frown -frusta
    mc confused shock "等等，真的吗？"
    show palmierproxy -shock
    quil hister "没错。每当我卧床不起时，[nickname]都会来陪我。"
    quil malu blush "[povname]会告诉我学校里的八卦，作为回报，我会喋喋不休地跟[dia]讲元素精灵之类的东西。"
    quil talk "到了水母季节，我们三个会试着抓它们从水里飞出来的时候。"
    mc confused tanya "你们三个？"
    show palmierproxy frown -tanya
    quil mock sigh -blush "[povname]、菲亚和我。虽然更准确地说，是菲亚和我在试着抓它们。"
    quil hister -sigh "[povname]只会用火焰符文开始射击它们。"
    mc ha sweat "...你有个好朋友啊。"
    show palmierproxy frown -sweat
    quil cringe sigh "[povname]确实有[dia]问题，但我向你保证，你永远找不到比[dia]更忠诚的朋友了。"
    if not kln:
        quil malu -sigh "一旦[kamu]在乎你，[kamu]就会用生命保护你。"
    else:
        quil malu -sigh "一旦[kamu]在乎你，[kamu]就会用生命保护你。"
    quil sad sweat frusta "...我只希望我不会太晚—嗯。"
    show palmierproxy sad shock
    "你看到奎尔突然沉默了，低头看着自己的脚，眼中泛起泪光。"
    show quil sad -frusta
    show palmierproxy -shock
    show pboy s at horzappear
    menu haha:
        "{s}拥抱奎尔{/s}" if kindness < 15:
            
            jump haha
        "拥抱奎尔" if kindness >= 15:
            #CG
            hide pboy
            $ bff.points += 10
            show palmierproxy wry with move :
                xalign 0.75
            play sound "sound/effects/cloth.mp3"
            quil frown both shock "谁允许你拥抱我的？"
            mc wry tanya "哦，奎尔大人，我能拥抱你吗？这样你就不会突然哭出来让我心碎了。"
            show palmierproxy kind sigh
            quil rajuk -shock "我不会哭的。再说，谁会拥抱一个曾经以为要谋杀自己的人？"
            mc kind cling "嗯，我的菲亚总说我原谅人太容易了。而且，你看起来需要一个拥抱。"
            quil sulk"..."
            mc wry sigh "嘿，没事的，[kamu]会醒过来的。我知道[kamu]一定会的。"
            mc happy cling "毕竟，你可是伟大的奎尔·英克威尔，不是吗？"
            quil sly cling -both "哼。当然。创造奇迹可是我的专长！"
            show quil hister blush bunga
            show palmierproxy happy bloom with move:
                xalign 0.6
            "奎尔似乎很感谢你的安慰，微笑着送你回到房间。"
        "伙计，那真是太糟糕了。":
            hide pboy
            $ bff.points -= 10
            if bff.points <0:
                $ bff.points = 0
            show palmierproxy malu sweat
            quil mock -sweat apa "哼，这就是你那可怜的安慰尝试吗？"
            quil hister -apa "就像我的[povname]一样，你也这么不善社交。哈哈！"
            mc mock -sweat "嘿，你在笑，不是吗？看来我的鼓励起作用了。"
            show palmierproxy kind 
            quil heh sigh "看，你也一样固执。真是没救了。"
            show quil laugh bunga 
            show palmierproxy laugh 
            "你又和奎尔聊了一会儿，然后回到了自己的房间。"
        "交谈并安慰他":
            hide pboy
            $ bff.points -= 5
            if bff.points <0:
                $ bff.points = 0
            mc sad sigh "嘿，记住，我是来帮忙的。无论你需要什么。"
            quil cringe -sweat "谢谢你。你真是太好了。"
            quil ow "好得令人作呕。有时候很难想象你和[povname]是同一个人。"
            quil heh sigh "但也许这就是分身的特点。我真好奇在你的世界里，我是个什么样的帅哥。"
            show quil datar -sigh
            if girl:
                if girl2 or kln:
                    mc kind tanya "谁知道呢？也许在那里你是个真正的女性杀手。那可真是个转折。"
                else:
                    mc kind tanya "谁知道呢？也许在那里你是个真正的男性磁铁。那可真是个转折。"
            else:
                if girl2:
                    mc kind tanya "谁知道呢？也许在那里你是个真正的女性杀手。那可真是个转折。"
                else:
                    mc kind tanya "谁知道呢？也许在那里你是个真正的男性磁铁。那可真是个转折。"
            show palmierproxy laugh -tanya
            quil groan frusta "哦，\'哈-哈\'。"
            show quil heh sigh
            show palmierproxy happy
            "你又和奎尔聊了一两个小时，然后回到了自己的房间。"
        "分散他的注意力" if "bloodmoon" in topics:
            hide pboy
            $ bff.points += 15
            if kln:
                mc wry sigh "我相信[kamu]没事的。"
            else:
                mc wry sigh "我相信[kamu]没事的。"
            mc confused tanya "顺便说一句，那是个超大的月亮。那是血月吗？"
            show palmierproxy frown -tanya
            quil hister shock -sweat "噗。哦，天哪，当然不是！当血月来临时，你一定会知道的。"
            quil sly cling "天空会被染成红色，狼群会发出永不停息的嚎叫。"
            quil talk -cling "事实上，最近的一次血月就发生在几个月前。我相信那就是[povname]与巫师建立联结的时候。"
            quil frown "在正常情况下，没有人类能够在与纯血巫师建立联结后存活下来。"
            quil cringe "我们的身体会在压力下崩溃。要么就是因为记忆过载而完全发疯。"
            show quil datar
            mc confused tanya "你说的记忆过载是什么意思？"
            show palmierproxy frown -tanya
            quil rajuk "就是字面意思。你能想象一下要一次性吸收至少一个世纪的记忆吗？"
            quil heh "大多数纯血巫师至少有200岁。我无法想象我们渺小的人类大脑如何能承受那么多记忆。"
            quil talk "血月一定在其中起了作用。这可能也解释了为什么[povname]成为了主导意识。"
            quil frown "因为在与非人类建立联结时，人类很少能成为主导方。"
            quil heh "老实说，我也对血月很好奇。然而，我甚至不知道从哪里开始查起。"
            quil sly cling "没有什么能比得上[povname]的灵魂联结。这简直是前所未有的。"
            show quil frown shock
            mc apa tanya "血月和普通的月亮有什么不同？它有什么作用？"
            show palmierproxy frown -tanya
            quil rajuk sigh "没人真正知道它到底有什么作用，但我知道在它的红色注视下会发生奇迹。"
            quil wry -sigh "符文的力量会增强十倍，狼人无法控制自己的变形，吸血鬼会陷入血液狂热——无法隐藏他们的獠牙。"
            quil hister "真的有很多变化。"
            quil heh cling "顺便说一句，你知道吗..."
            show quil laugh bunga
            show palmierproxy wry sweat
            "不久之后，奎尔开始漫谈起森林精灵、人鱼和血液仪式。"
            "你完全不知道他在说什么，但你还是点头附和着，看着奎尔渐渐放松下来。"
            show quil malu blush bunga
            show palmierproxy laugh bloom -sweat
            "当他送你回房间时，奎尔忍不住一路微笑。他说他期待着你们的下一次约会。"






        "{s}分散注意力{/s}"if "bloodmoon" not in topics:
            
            jump haha
    stop music
    scene bg_black with w20
    scene lor_mlm with w20
    jump ur_room

#######FIA_EVENTS#################
label fia_wc:
    scene lorong_pagi with w20
    play music "sound/effects/nangis.mp3"
    "当你在女生宿舍楼层寻找菲亚时，你听到从浴室传来微弱的啜泣声。"
    show side_p he at pic
    mc "等等，那是...菲亚吗？"
    hide side_p
    
    scene wc_dorm with dissolve
    play sound "sound/effects/walk.mp3"
    if girl:
        show palmierproxy chill confused at left with moveinleft:
            yoffset 40
    else:
        show palmierproxy chill confused at left with moveinleft:
            yoffset 100
    mc tanya"菲亚，你在这里吗？"
    show palmierproxy frown shock
    show croissant flinch err sweat at right with dissolve:
        yoffset 500
    $ NPC = "女孩"
    fia "[povname]？"
    stop music
    if not girl:
        show croissant def jijik shock
        npc "什么，你不能进来，你是男生！"
        "一个尖锐的声音在房间里响起。菲亚旁边还有另一个女孩，一个棕发女孩，蹲在一个和菲亚发色相同的女孩旁边。"
        if girl2:
            fia mad frusta "哦，[kamu]的小穴比我们所有人都好，维克。让[dia]进来！"
            
        else:
            fia mad frusta "婊子，他妈的让开，这男人是男同性恋！"
        fia "赶紧滚出去，普莉姆不需要你！"
        npc "哼！"
        mc sad -tanya "妹妹，你刚才在哭吗？"
    else:
        mc sad -tanya "我听到你在哭。"
    fia sad sigh "不是我。是普莉姆。"
    $ NPC = "普莉姆"
    show croissant frown -sigh -sweat
    show prim_ sad at pic
    npc "哦，菲亚，我该怎么办？我父亲，他怎么能这样对我们！"
    hide prim_
    "环顾四周，你注意到你的妹妹正在抚摸金发女孩的背。"
    "她蜷缩成胎儿的姿势，坐在浴室的地板上，菲亚蹲在她旁边，轻轻地以安抚的圆圈方式揉着她的背。"
    mc scratch confused tanya "怎么了？"
    show palmierproxy frown -tanya
    fia gross "普莉姆的父亲刚刚卖掉了他们的房子，离开了她的母亲，一分钱都没留给她们。"
    mc chill sad shock "什么，为什么？"
    show prim_ yell at pic
    npc "为什么啊啊啊啊？！"
    hide prim_
    show palmierproxy apa shock
    fia err frusta "这正是我们试图弄清楚的。"
    play music "MUSIC/MusMus-BGM-146.mp3"
    show palmierproxy confused -shock
    fia mock cling -sweat "我的理论很简单，她爸爸有个秘密家庭。另一套他更爱的妻子和孩子。"
    fia kerja apa "你怎么看，唠叨鬼？"
    show prim_ yell at pic
    npc "菲亚，我就在这儿呢！"
    hide prim_
    show croissant flinch mmh sweat shock
    fia sad frusta "哦，抱歉。没想到你会听到。但你知道我不擅长安慰人！"
    fia pity apa "呃...你想喝热可可吗？可以让你平静下来。"
    show croissant flinch gross shock
    show prim_ yell at pic
    npc "我对巧克力过敏！"
    hide prim_
    mc scratch ew sweat sigh "（哇。她真的很不擅长这个。）"
    show pboy at horzappear
    menu:
        "交给我吧。":
            hide pboy
            mc chill frown sigh "守住门，把这事交给我。"
            fia cringe shock "等等，你是要...但那不是太残忍了吗？"
            fia sad sigh "我知道你有时候脑子不太正常，但即使对你来说，这也太过分了，唠叨鬼。"
            mc confused tanya "（嗯？她在说什么？）"
            mc sad -tanya "我只是想和她谈谈。"
            fia def mmh frusta -sweat "对，\'谈谈\'。好吧...你总是最了解的。"
            fia sad sigh "我去守门。"
            play sound "sound/effects/walk.mp3"
            scene wc_dorm with dissolve
            $ my_events.append("grumbles")
            "那是怎么回事？你真应该问问她那些话是什么意思，但现在..."

        "去给她泡些茶。":
            hide pboy
            mc chill deject sigh "给她泡些柠檬茶，再给我拿些遮瑕膏和梳子。"
            show palmierproxy frown -sigh
            fia def sad apa -sweat "为什么要遮瑕膏和梳子？"
            show croissant frown shock
            mc eiden sigh "你不会想让全校都知道你在厕所里哭得眼睛都肿了吧？"
            show palmierproxy kind -sigh
            fia mmh sweat sigh "哦，我没想到这点。好的，马上回来。"
            play sound "sound/effects/walk.mp3"
            scene wc_dorm with dissolve
            "菲亚匆忙离开了房间。"
            "你真应该帮助那个女孩提高她的人际交往能力，但现在..."
    show prim_ sad at pic
    npc "呜哇啊啊！" with vpunch
    hide prim_
    "...你得应付一个正在抽泣的少女。"
    show side_p f at pic
    mc "是普莉姆，对吧？我叫[povname]。"
    show side_p w
    mc "我为我妹妹的态度道歉。如果你愿意，我可以倾听你的心事。"
    hide side_p
    show prim_ frown at pic
    npc "*抽泣*，*抽泣*...我只是不明白，我们明明很好！上周还是我父母的银婚纪念日。"
    show prim_ sad
    npc "我们举办了一个盛大的派对，他们甚至重新宣誓了！"
    show prim_ yell
    npc "但后来我叔叔带我爸出去过了个男人之夜，突然他就说他不再爱她了。"
    show prim_ sad
    npc "他说他找到了别人，要和那个人共度余生。为什么？！难道我叔叔给我爸介绍了个脱衣舞娘还是怎么的？"
    hide prim_
    show side_p s at pic
    mc "你确定是另一个女人吗？"
    hide side_p
    show prim_ yell at pic
    npc "还能是什么？我打赌她是个只想要我爸钱的妓女。我听说他甚至卖掉了他在卡斯特里的公司和土地。"
    npc "他就这样拿走所有的钱跑了，我不知道他在哪里！"
    show prim_ sad
    npc "你觉得他是不是卖掉所有资产，好和她在沃特克开始新生活？我该怎么办？"
    npc "我母亲这辈子从没工作过，我也对工作一无所知。我他妈的零花钱可是10万金币啊。"
    show prim_ yell
    npc "我现在要做体力劳动吗？我该怎么支付学费？"
    hide prim_
    show pboy at horzappear
    menu:
        "这对你来说是件好事。":
            hide pboy
            show side_p w at pic
            mc "我知道现在看起来可能很糟糕。但似乎到目前为止你过的是相当舒适的生活。"
            show side_p se
            mc "也许这是宇宙教导你如何变得独立、成为一个白手起家的女性的方式。"
            hide side_p
            show prim_ yell at pic
            npc "你是在告诉我你不想每月什么都不做就得到10万吗？！"
            npc "我想做任何我想做的事，并且被宠坏！"
            show prim_ sad
            npc "谁他妈想为钱工作啊？！呜哇哇！"
            hide prim_
            "是啊，这并不是我想要的发展方向。"
            show side_p w at pic
            mc "如果这能让你感觉好些的话，像你这么漂亮的女孩找个糖爹一点问题都没有。"
            hide side_p
            show prim_ frown at pic
            npc "糖爹？那是什么？"
            hide prim_
            show side_p f at pic
            mc "啊，这个嘛，有点像是..."
            hide side_p
            "当你解释糖宝贝和OnlyPhans的时候，你意识到这个世界还没有创造出这些东西。"
            "那个女孩兴奋起来，因为她觉得可以用你的建议来创业。"
            "...天啊，你都做了什么？"
            $ my_events.append("prim_onlyfans")

        "起诉你爸爸。":
            hide pboy
            show side_p f at pic
            mc "你还是他的孩子，所以他需要支付抚养费。你不能去法院处理这件事吗？"
            hide side_p
            show prim_ frown at pic
            npc "抚养...费？那是什么？"
            hide prim_
            show side_p s at pic
            mc "等等，你们没有抚养费？"
            hide side_p
            show prim_ frown at pic
            npc "从没听说过。"
            hide prim_
            show side_p he at pic
            mc "嗯，这是..."
            hide side_p
            "当你说话时，你意识到在这个世界里父母没有支付抚养费的义务。甚至把自己的孩子卖为奴隶在这个世界仍然是被允许的。"
            "你的话让普莉姆感到困惑，但似乎让她平静了一些。"
            "她停止了哭泣，难以置信地盯着你。"
            $ my_events.append("prim_sue")
        "找到那个女人。":
            hide pboy
            show prim_ frown at pic
            npc "什么？"
            hide prim_
            $ my_events.append("prim_true")
            show side_p he at pic
            mc "嗯，也许你可以找到他有关系的那个女人，告诉她去毁掉别的家庭。"
            show side_p f
            mc "你知道她的名字或者她在哪工作吗？"
            hide side_p
            show prim_ sad at pic
            npc "奇怪的是，我试着问我叔叔关于那个俱乐部的事，但我在哪里都找不到。不管是在伊格尼亚还是其他地方。"
            hide prim_
            show side_p f at pic
            mc "那个俱乐部叫什么名字？"
            hide side_p
            show prim_ frown at pic
            npc "梅扎的欲望之屋。"
            hide prim_
            show side_p s at pic
            mc "（哦。哦，糟糕。）"
            show side_p he
            mc "你父亲的名字是什么来着？你有他的照片吗？"
            hide side_p
            show prim_ frown at pic
            npc "嗯？好吧，他的名字是范德拉尔·费霍恩，给你看。"
            hide prim_
            "普莉姆在她的手机上给你看了她父亲的照片。他是个高大但肥胖的男人，有个明显的啤酒肚。"
            show side_p w at pic
            mc "谢谢。我想我可能知道在哪里能找到他。不过我还不太确定。"
            show side_p se 
            mc "如果我找到他，我一定会让他清醒过来的，好吗？"
            mc "会没事的，孩子。"
            hide side_p
            show prim_ smile at pic
            npc "*抽泣*，谢谢你。"
            hide prim_
            $ add_new_quest("daddy1")
            python:
                if len(new_quests) > 0: #if we have new quests
                    for i in new_quests:
                        active_quests.insert(0, i) #add to top of the quest list
                    new_quests = [] #now reset the new quest list, since they all got added
            show screen completedtask("新任务！")
    scene wc_dorm with dissolve
    if girl:
        show palmierproxy chill frown at left with moveinleft:
            yoffset 40
    else:
        show palmierproxy chill frown at left with moveinleft:
            yoffset 100
    
    if "grumbles" in my_events:
        show croissant err sweat at right with moveinright:
            yoffset 500
        "普莉姆离开后，菲亚不情愿地进入了房间。"
        fia sad "所以，搞定了吗？"
        mc confused sigh "我想是的。至少她不再抽泣了。"
        show palmierproxy frown -sigh
        fia kzl frusta "是啊，但你做了什么？比如...你重写了什么？"
        mc confused tanya "嗯？"
        fia sad sigh -sweat "你又用了那个符文，对吧？你制作的记忆重写符文？"
        mc sad shock "什么？不！我只是和她谈了谈。"
        show palmierproxy confused -shock
        fia frown shock "等等，所以你真的只是和她谈了谈？"
        fia mock cling "你，格兰布斯？？？你真的组织语言和她交谈了？"
        mc side frusta sweat "为什么每个人都认为我不能进行正常的对话？"
        show palmierproxy confused 
        fia hmph sigh "可能是因为在今年夏天发生奇迹之前，和你交谈意味着你只会用哼哼和咕哝来回应。"
        mc wry sigh "好吧，我发誓我只是和她谈了谈，好吗？我会对你撒谎吗？"
        fia frown -sigh "..."
        show palmierproxy frown -sigh
        fia laugh "不，我想不会。抱歉怀疑了你。"
        fia pity sigh "如果你说你没用它，那我就相信你的话。"
        show croissant smile -sigh
        if "rewrite" not in topics:
            play sound "audio/success.mp3"
            "新话题：{color=#FF1500}重写符文{/color}"
            $ topics.append("rewrite")
        mc huh tanya "我发誓我没有。而且，你本来是要让我洗脑你的朋友吗？"
        show palmierproxy confused 
        fia malu sweat "我是说，上次你这么做的时候，结果是最好的。方法虽然值得质疑，但他们现在很幸福，所以……"
        fia kerja blush "我相信你。"

        if not "diari1" in active_quests:
            mc scratch side sweat sigh"（但是，\"我\"值得这份信任吗？也许我应该查看一下我的手机，多了解一下我的分身。）"
            mc confused -sigh"（这里有些不对劲……）"
            $ add_new_quest("diari1")
            python:
                if len(new_quests) > 0: #if we have new quests
                    for i in new_quests:
                        active_quests.insert(0, i) #add to top of the quest list
                    new_quests = [] #now reset the new quest list, since they all got added
            show screen completedtask("新任务！")
        else:
            mc scratch side sweat sigh"（但是，\"我\"值得这份信任吗？）"
        jump kls_diet

    else:
        show croissant flinch frown at right with moveinright:
            yoffset 500
        "菲亚很快带回了你需要的一切。你梳理着那个女孩的头发，而菲亚则为她擦去眼泪，轻轻涂抹遮瑕膏。"
        "普莉姆现在平静下来了，她努力振作起来，露出了微笑。"
        show prim_ frown at pic
        npc "我看起来怎么样？"
        hide prim_
        fia def hmph cling "看起来就像你没有在洗手间里哭了整整一个小时一样。"
        show croissant smile -cling
        show prim_ smile at pic
        npc "还不错。"
        if "prim_true" in my_events:
            npc "嗯，真的很感谢你，[povname]。我没想到你会这么善良。"
            npc "你也是，菲亚。谢谢。"

        elif "prim_sue" in my_events:
            npc "嗯，谢谢你们两个。"
            npc "我不太明白你刚才说的话，[povname]，但我很感激你的好意。"
            npc "好了，现在再见。我可不想上课迟到。"
        else:
            npc "我一定会好好思考你刚才说的话，[povname]。我现在明白为什么人们说你是你们年级最聪明的学生之一了。"
            hide prim_
            mc scratch ha sweat "啊哈哈哈，是啊。"
            show palmierproxy chill kind -sweat
            show prim_ smile at pic
            npc "好了，现在再见。我可不想上课迟到。"
            hide prim_
    hide prim_
    fia laugh apa "好了，既然这件事解决了……午餐时见？"
    show croissant kerja -apa
    mc happy "好的。再见！"
    $ NPC = "???"
    stop music
    jump kls_diet

#######THANE EVENTS
label red_cure:
    hide screen potion_map
    scene kls_potion with fade
    stop music
    play sound "sound/effects/drip.wav"
    play music "MUSIC/MusMus-BGM-077.mp3"
    "当你把你的血滴到塞恩的潜在解药上时，发生了一些事情。一些糟糕的事情。"
    play sound "sound/effects/flame.mp3"
    queue sound "sound/effects/hiss.mp3"
    "血液变成黑色，药剂开始沸腾。你的手被灼热烫伤，尖叫着松开手，药剂掉在地上，发出嘶嘶声。"
    if girl:
        show palmierproxy scratch ow sweat at center with dissolve:
            yoffset 40
    else:
        show palmierproxy scratch ow sweat at center with dissolve:
            yoffset 100
    mc grit shock "啊啊！" with vpunch
    show red sad sweat at left with moveinleft:
        yoffset 330
    red ow frusta "[povname]！"
    show red sad
    mc sad tanya "塞恩？！"
    show palmierproxy confused -tanya
    show red sad sigh with move:
        xalign 0.2
    play sound "sound/effects/freeze.mp3"
    "塞恩不知从哪里冲进了房间。他立即抱住你的手，施展了一个冰符文，为你的手降温。"
    mc side tanya "塞恩，你……你在这里做什么？"
    show red sad at left with move
    show palmierproxy chill sad at right with move
    red perih frusta "别生气，但是……嗯，其实这些天我一直在跟踪你。"
    mc confused -sweat shock"啊？！"
    red ew "是你的血，好吗？我无法正常思考，它让我想要跟随你，既想保护你，又想伤害你。这——"
    red bingung sigh"这很复杂！"
    $ red_events.append("cure_me")
    mc side sigh"哈啊..."
    "你只能无奈地叹了口气，因为整个情况让你感到非常沮丧。奎尔说药剂不稳定时可不是在开玩笑，它差点把你的手烧掉。"
    mc scratch ha frusta "好吧，坏消息是，看来这个药剂失败了。"
    show red sad -sigh
    "塞恩羞怯地点了点头。"
    show palmierproxy sad shock
    red awkward "一定是因为你的血液简直不是这个世界的。"
    mc chill eiden tanya "你现在是在开玩笑吗？"
    show palmierproxy wry -sweat -tanya
    red sayang apa "我以为这能分散你对疼痛的注意力。有用吗？"
    show red amused -apa
    show pboy at horzappear
    menu:
        "有一点用。":
            hide pboy
            $ mrh.points += 5
            mc hister sigh blush "有一点用。我很高兴你在这种糟糕的情况下还能找到一些幽默感。"
            show palmierproxy kind -blush
            red cowo blush "我尽量吧。"
        "他妈的不行！":
            hide pboy
            $ mrh.points -= 5
            mc pissed frusta "不！你还在痴迷于我的血液，而我们除了建立联结之外还没找到解药，我们正在浪费时间！"
            red ew frusta "我知道……但是大喊大叫和闷闷不乐并不能帮上忙，对吧？"
            mc side sigh "哈啊..."
    mc sad sweat tanya "现在怎么办？"
    red chin ngeles sweat sigh "现在我想我们只能做出决定了。决定谁来和我建立联结，然后坚持下去。"
    red wry -sweat -sigh "在你进入牺牲小羊模式之前，我还是希望你能好好思考一下。"
    red happy "我们还有时间。好好利用它。"
    red point amused sigh "然后当真的没有其他选择的时候，嗯……那时我会亲自来问你的。"
    mc side sigh "好吧……好吧。"
    show palmierproxy -sweat shock
    red hister both apa "还有，你觉得我舔掉地上你沸腾的血液会很恶心吗？"
    mc pissed sweat frusta "塞恩！"
    $ NPC = "???"
    show palmierproxy confused -sweat shock
    show red kaget sweat shock
    show poppy hair wry at center with dissolve:
        zoom 0.9
        xzoom 0.97
    play sound "sound/effects/door.mp3"
    py "塞恩，那样很不卫生。"
    red ngeles -shock "波比小姐！"
    show red sad -sweat
    show palmierproxy confused -shock
    py cry "我无意中听到了你们的困境。请不要因为我偷听而对我有不好的看法。我只是想帮忙。"
    py awkward "你试图用魔药来满足塞恩的饥饿，对吧？一种由海妖之血和独角兽之血混合而成的魔药。"
    py confident "如果你在课堂上认真听讲的话，你可能会记得还有另一种与这两种相似的成分。"
    show red frown shock
    show palmierproxy tanya
    py wry "由于其较低的不稳定性，它经常被用作替代品。"
    play sound "sound/effects/cloth.mp3"
    "波比开始卷起袖子，露出她白皙纤细的手腕，同时另一只手从裙子口袋里掏出一个玻璃小瓶。"
    mc apa -tanya "那是用来做什么的？"
    show palmierproxy sad sweat shock
    show red point kaget shock
    show blud_overlay with vpunch
    play sound "sound/effects/bite.wav"
    show poppy base confident
    "你还没来得及问完，血腥味就侵入了你的鼻孔。波比咬住自己的手腕，将筋肉暴露出来，一直咬到骨头。"
    "粘稠的红色血液填满了小小的玻璃瓶。"
    hide blud_overlay with dissolve
    red perih frusta "波比小姐！搞什么鬼？！"
    show red huh
    if "bond" in fia_events:
        $ fia_events.remove("bond")
    py hmm "狼人之血。"
    py laugh "现在，亲爱的，轮到你的血了。只需要一滴就够了。"
    show palmierproxy ew sigh
    show poppy fake 
    play sound "sound/effects/drip.wav"
    "你震惊得说不出话来，割破手指，看着你的血与她的血混合在一起。"
    show palmierproxy frown -sweat shock
    show red kaget -sweat shock
    "它立即发出明亮的红光，然后变成了浓郁的蓝色。"
    show palmierproxy confused -shock
    py tease "好了。完美。喝吧，亲爱的，确保全部喝光。"
    show poppy fake
    show red bingung sigh
    play sound "sound/effects/plate.mp3"
    "塞恩似乎和你一样处于震惊状态，他怯怯地点了点头，拿起魔药一饮而尽。"
    show red kaget shock
    show palmierproxy frown
    py awkward "感觉如何，好些了吗？"
    show poppy fake
    red grin blush bunga "我...我感觉棒极了！"
    show palmierproxy malu sigh
    red cowo "我，我不再想扑向你了，[povname]。你闻起来很正常。波比小姐也是，你的血闻起来糟糕透了！这太棒了！"
    show palmierproxy kind -sigh
    red grit sweat shock "啊，抱歉，说你的血有味道是不是很无礼？"
    show red amused -sweat -shock
    py awkward "啊哈哈，不，不会。这正是我们想要的效果。看来你的血瘾已经稳定下来了。"
    py hair laugh "我很高兴。"
    if "nina3" in completed_quests:
        py wry "科夫告诉我你是他最喜欢的员工。"
        py awkward "他不会希望你像野兽一样被本能驱使。"
        py sad "科尔知道我们家族中已经有太多这样的人了。"
        red chin ngeles apa "啊，其实科夫有给你打过电话吗，小姐？我简直不敢相信那个人就这样离开了。"
        show red sad -apa
        show palmierproxy sad shock
        py cry "还是没有电话。老实说，我不知道妮娜把他带到哪里去了。"
        show palmierproxy ew sweat frusta
        py hee "我发誓我要杀了毁掉我哥哥生活的人。"
        py fear "你知道有什么线索吗？塞恩，你知道有谁可能给他送了爱情魔药吗？"
        red ew sigh "抱歉，不知道。"
        show red sad -sigh
        py wry "没关系，亲爱的。我本来也没抱太大希望。"
    else:
        py laugh "你知道吗，科夫很喜欢你。"
        py wry "我会很遗憾如果他不得不解雇他最信任的员工。"
    py awkward "好了，我该把这里清理干净了。对不起，刚才有点夸张，即使在人形状态下，狼人的肉体也相当坚不可摧。"
    py fake "我不想让你们磕坏牙齿，或者弄坏你们的刀，塞恩，[povname]。"
    red point laugh blush bloom "波比小姐，那真是太酷了！"
    mc sad sweat tanya "我们需要带你去医务室吗？"
    py confident "哦，一会儿就会痊愈的，只需要咬点骨头什么的，伤口就会自己愈合。"
    show palmierproxy confused -tanya
    py laugh "你们俩该走了，不用在这团糟中逗留。我很快就能清理干净。"
    red amused apa "不行！你为我流血了，小姐！我们至少应该帮忙清理，对吧[povname]？"
    if "nina3" in completed_quests:
        mc scratch ha sweat frusta"啊..."
        mc avoid "（糟糕，我本想在她发现是我策划了整个科夫事件之前溜走，但是——）"
        red chin ngeles "[povname]？"
        mc chill ha shock "对，没问题。"
    else:
        mc happy blush bunga "当然！"
    scene kls_potion with dissolve
    "你清理了地板，然后和塞恩度过了剩下的一天，之后回到了自己的房间。"
    $ mrh.points += 5
    scene lor_mlm with w33
    play music "MUSIC/MusMus-BGM-082.mp3"
    jump ur_room




label red_date_check:
    if "date1_done" not in red_events:
        if "io4" in my_events:
            $ red_events.append("date1_done")
            jump red_date2
        else:
            jump red_date1
    elif "mey_kill" in my_events and "date2_done" not in red_events and "io0" not in my_events and mrh.points >= 20:
        jump red_date2
    elif "date4_done" not in red_events and "date3_done" in red_events and mrh.points >= 80:
        jump red_date4
    elif "io4" in my_events and "date3_done" not in red_events and mrh.points >= 60:
        if calendar.weekday == "Sat" or calendar.weekday == "Sun":
            if datingplace == "Garden":
                scene fort_upper with dissolve
                $ datingplace = "sklh"
            elif datingplace == "Arena":
                scene fort_upper with dissolve
                $ datingplace = "sklh"
            elif datingplace == "Malam":
                scene teras_mlm with dissolve
                $ datingplace = "sklh"
            else:
                scene city_wander with dissolve
                $ datingplace = "bebas"
            hide screen cal
            $ quick_menu = False
            $ daterp = 30
            $ turnsleft = 3
            $ skinshiparea = ""
            $ config.rollback_enabled = False
            $ renpy.block_rollback()
            $ datingname = "塞恩"
            jump startdate
        else:
            jump red_date3
    else:
        if datingplace == "Garden":
            scene fort_upper with dissolve
            $ datingplace = "sklh"
        elif datingplace == "Arena":
            scene fort_upper with dissolve
            $ datingplace = "sklh"
        elif datingplace == "Malam":
            scene teras_mlm with dissolve
            $ datingplace = "sklh"
        else:
            scene city_wander with dissolve
            $ datingplace = "bebas"
        hide screen cal
        $ quick_menu = False
        $ daterp = 30
        $ turnsleft = 3
        $ skinshiparea = ""
        $ config.rollback_enabled = False
        $ renpy.block_rollback()
        $ datingname = "塞恩"
        jump startdate

label red_cekup:
    play music "MUSIC/MusMus-BGM-025.mp3"
    if calendar.weekday == "Sat" or calendar.weekday == "Sun":
        if girl:
            show palmierproxy jln sad at right with moveinright:
                yoffset 40
        else:
            show palmierproxy jln sad at right with moveinright:
                yoffset 100
    else:
        if girl:
            show palmierproxy chill sad at right with moveinright:
                yoffset 40
        else:
            show palmierproxy chill sad at right with moveinright:
                yoffset 100
    show red frown shock
    show red at left with move
    mc ow sweat tanya "塞恩，你还好吗？"
    red sayang sigh "我怎么会不好呢？"
    $ red_events.append("date_cekup")
    mc side frusta "我是说...你刚刚又见到了你的母亲。而且她变成那种形态，难道不是——"
    red mock -sigh "令人心理创伤？是啊..."
    red sad apa "但这又有什么新鲜的呢？"
    red ew sweat frusta "没事的，[povname]。我的意思是，我现在确实不太好，远远谈不上好。"
    red amused -sweat sigh "但我能再次见到妈妈。尽管她现在扭曲变形了，但她还活着，这...这就是我所能祈求的全部了，真的。"
    red mls sigh "我还能做什么呢？"
    show palmierproxy sad sigh
    "悲伤再次在你心中涌起，伴随着恐惧、挫折和愤怒。这些都是塞恩的情绪，不是你的。"
    "他这样隐藏情绪是不健康的。你感觉自己快要爆发了。"
    show palmierproxy side both frusta at center with move
    show red ngeles chin sweat shock
    "于是你真的爆发了，像个迷路的孩子一样抽泣着，把脸埋在塞恩的肩膀上。"
    red perih sweat shock "嘿-嘿！你还好吗？"
    show red sad -shock
    mc pissed frusta "你应该问问你自己这个问题，你这个笨蛋！"
    mc ow sweat "塞恩，我能感受到一切...你的悲伤，你的内疚，你的愤怒！"
    mc side sigh "求你了，你不必再隐藏了，至少不要对我隐藏！"
    red sayang -sweat sigh"...哦，[povname]。"
    "塞恩紧紧地抱住你，亲吻你的头发，你的泪水打湿了他的肩膀。"
    "你把头埋在他的胸膛里，他轻轻抚摸你的背安慰你。"
    red ew frusta "对不起。我现在不想谈这个。"
    red wry sigh "不是今天。但有一天当我准备好了，我会全部倾诉的，好吗？"
    mc pissed frusta "你就不能现在跟我说说吗？！"
    red ngeles -sigh "这没那么容易。我从来没有真正有过可以依靠的肩膀。或者在这种情况下，有人代我哭泣，但总有一天会的，[povname]。"
    red wry "总有一天。所以请别再哭了。"
    show red frown shock
    mc ow frusta "不。我是在替你哭，你这个傻乎乎的笨蛋！如果你不能哭出你的悲伤，那我来替你哭！"
    play sound "sound/effects/bump.mp3"
    hide red with moveoutleft
    hide palmierproxy with moveoutleft
    red "哎呀！"
    "你更紧地抱住塞恩的腰，哭得更大声了，你的抽泣声在周围回荡。"
    "塞恩只是微笑着，任由你完全释放，每一滴眼泪都带来通过你们之间联系传递的宽慰。"
    "塞恩吻去你的眼泪，喃喃地说着\"谢谢\"和\"我爱你\"，同时也流下了一滴泪。"
    stop music
    scene bg_black with w20
    scene lor_mlm with w20
    play music "MUSIC/MusMus-BGM-082.mp3"
    jump ur_room
label red_parting:
    $ red_events.append("red_pisah")
    stop music
    play music "MUSIC/MusMus-BGM-032.mp3"
    scene lake with w33
    "你和塞恩走下码头。"
    show red point happy at left with moveinleft:
        yoffset 330
    if girl:
        show palmierproxy chill kind at right with moveinright:
            yoffset 40
    else:
        show palmierproxy chill kind at right with moveinright:
            yoffset 100
    if "ice_rune" in my_events:
        "湖面依然坚固如初，空气中散发着刺骨的寒意。"
        
    else:
        "这是一个令人平静的景象。湖水一如既往地平静。"
    red chin awkward apa "你还记得那天晚上你在这里抓到我吗？"
    show palmierproxy side sweat
    red ew sweat frusta "像个疯子一样啃咬鱼，吸干它们的血。"
    if "luka" in my_events:
        red wry sigh "你当时也在流血。回想起来，我真的很庆幸我没有失去理智，把你吸干或做出什么过分的事。"
        red ngeles frusta "如果那样的事发生了，我想我无法原谅自己。"
    
    else:
        red huh sweat sigh "我到现在还不敢相信那之后你还愿意和我有任何关系。"
    mc happy blush tanya "嘿，我不是在这里吗？"
    mc mean cling "几颗尖牙和一些血可吓不跑我。"
    red hister blush sigh "我注意到了。你知道吗，[povname]，你真是太了不起了？"
    red point grin bunga "你打败了神！真正的神！"
    mc malu sigh "我是说，从技术上讲，他们是自取灭亡的。"
    red laugh "但是，你面对了所有纯血巫师，还活着讲述这个故事！"
    red mock sigh "我其实只是面对了伊欧，即便是她也令人印象深刻！"
    red chin amused apa "你知道她在她的梦境中向我展示了什么吗？我是说我们第一次来到她的巢穴的时候。"
    mc wry sigh "不知道，但我能猜到那有多诱人。她向我展示了一个有菲亚在的生活。"
    show palmierproxy side -sigh
    red huh -blush -apa "对我来说，那是一个有父母的生活。他们两个都在，而且我们也不是吸血鬼。"
    red hister "我们是人类，普通的、无害的人类。那天是我的毕业典礼。我的父母看起来从未如此自豪过。"
    red ngeles sigh "他们也永远不会有那样的机会了。要找到不留在那里的理由真的很难。"
    show palmierproxy frown shock
    red sayang -sigh "我想永远沉浸在那一刻。但后来我想起了你。"
    show palmierproxy wry blush -shock
    red hister blush "勇敢地追随我的你。"
    if 'curhat_dance' in red_events:
        red amused sigh "不仅一次，而是两次。"
    red datar bunga"你把我当作一个人看待，而不是一头野兽。"
    red laugh "真心感谢你。"
    red hister "如果不是因为你，我想我可能已经不在人世了。"
    if "companion" in red_events:
        red wry "我的伴侣，我的灵魂。我的爱。"
        mc malu bunga "塞恩..."
        red amused apa "你知道我给我母亲写信提到你了吗？" 
        show palmierproxy frown -blush -bunga
        red ew frusta "我知道这在技术上是浪费纸张。"
        red sad sigh "她甚至不识字，而且我把信寄到了我以前的家庭地址，那里现在可能只是一个空壳，但还是。"
        red sayang -sigh "我告诉她关于你的事，关于我们。那个救了我性命的人，我全心全意爱着的人。"
        show palmierproxy malu blush bunga
        red datar "那个我必须为之离开她的人。为了最终兑现她的牺牲。为了幸福地生活。"
        red happy "我迫不及待想要和你在你的世界开始新的生活，[povname]。"
        red laugh cling "我发誓我会让你幸福。"
        show red amused -cling
        mc happy bunga "我已经很幸福了。"
    else:
        red cowo cling "现在我有了这第二次机会。我不想浪费它。"
        show palmierproxy frown shock
        red amused -cling "我...我想我毕业后要回沃特克。"
        red wry "我...我想试着治愈我的妈妈。"
        #berubah
        mc deject tanya "什么？！你要回去？！你确定这是正确的决定吗？"
        show palmierproxy frown shock
        red cowo blush cling "不确定，但这是我最好的选择。"
        red wry sigh "别那样看着我！我们已经唤醒了[povname]，你也打败了纯血巫师。那些神。"
        red mock bunga "如果那都可能，那肯定还有机会，对吧？"
        red grin -bunga "即使机会很小，嗯，那也是个机会。"
        #berubah
        show pboy at horzappear
        menu:
            "别这么做！":
                hide pboy
                mc avoid sweat frusta "伙计，我为了唤醒[povname]差点死了五次。我不确定这对你来说会不会成功。"
                red hister both sigh "啊哈哈！嘿，这时候你应该给我一句激励的话，告诉我去做就是了！"
                mc ow frusta "这就是一句激励的话，\'千万别做！\'"
                red chin mock cling "啊哈哈，可惜，我已经下定决心了，[povname]。我会救她的。你等着瞧吧。"
                mc wry blush sigh "哼，好吧，我很期待你能证明我是错的，塞恩。"
            "是啊！":
                hide pboy
                mc smile blush sigh "我知道你会治好她的，塞恩。"
                mc happy -sigh "我相信你一定会的。"
        red cowo blush bloom "是啊。天啊，我真的会想念你的，[povname]。"
        mc smile blush bunga "我也是，塞恩。我也会想念你的。"
    "你和塞恩一起看了日落，然后回到宿舍。"
    $ NPC = "???"
    scene bg_black with w20
    jump jaga_jaga
    
label red_date4:
    stop music
    scene bg_black with w20
    $ red_events.append("date4_done")
    play music "MUSIC/MusMus-BGM-004.mp3"
    scene red_cur_siang with w20
    show red bebas cowo at left with moveinleft:
        yoffset 330
    if girl:
        show palmierproxy jln kind at right with moveinright:
            yoffset 40
    else:
        show palmierproxy jln kind at right with moveinright:
            yoffset 100
    if calendar.weekday == "Sat" or calendar.weekday == "Sun":
        "你和塞恩一起去了公园。"
    else:
        "你和塞恩像往常一样偷偷溜出去，去了公园。"
    if 'curhat_dance' in red_events:
        "仔细看了看那座狮子雕像，你注意到你以前来过这里。"
        "这就是你在水母节那天找到塞恩的地方。"
        red amused apa "回忆，对吧？"
    
    red awkward sigh "你知道吗，这是我最喜欢来生闷气的地方。"
    mc malu tanya "只是生闷气吗？"
    show palmierproxy frown -tanya
    red wry -sigh "嗯，生闷气，还有吃东西。"
    show palmierproxy confused sweat shock
    red hister bunga "这里的鸽子真的又肥又胖。有时候这里的人们让我杀一只吸血。"
    if honesty <= 50:
        mc ew -sweat frusta "呃。"
        red perih frusta "嘿，食物就是食物！总比老鼠强！"
        mc wry sigh "我猜鸽子就是天上的老鼠。"
        red amused -frusta "对吧？"
    else:
        mc ha sigh "哦，那...挺好的。"
        if "bonding_me" in red_events:
            red laugh "啊哈哈，谢谢你没说恶心。"
    show palmierproxy kind -sigh
    red amused sigh "不过，有一次我确实惹上麻烦了，我吃的一只鸽子原来是某个女孩的宠物。"
    red datar -sigh "幸运的是她还年轻，所以我只是指了另一只鸽子，她就放它走了。"
    red sayang "不过我确实感到有些内疚，所以有时会来这里喂它们。"
    "塞恩说着，拿出了一袋面包屑。"
    play sound "sound/effects/birds.mp3"
    "他把面包屑撒在周围，鸽子们开始朝你们这边聚集。"
    "几十只鸽子开始在你们脚下蜂拥而至。当面包屑都吃完后，它们开始啄塞恩，要求更多。"
    mc kind tanya "这些小家伙真是饿坏了，不是吗？"
    red laugh bunga "是啊。有时候我真的很无聊，就会把自己裹满面包屑躺在地上。"
    red amused "挺有意思的。"
    mc confused -tanya "那不会疼吗？"
    red amused sigh "我是说，我恢复得很快，所以没什么大不了的。"
    red wry -sigh "当然，如果是猫咪在我身边蹭来蹭去，我会更开心，但猫咪害怕吸血鬼。"
    red mock "它们把我们当成捕食者。因此，有一种天生的恐惧。"
    mc frown "我以为你有一只猫？"
    red hister both "我确实有。我爱那个小家伙，但这并不意味着它也爱我。"
    red laugh -both "我一直想养只猫，但在沃特克是禁止的。如果你在那里看到猫，肯定是食物。这有点悲哀。"
    red datar "所以当我离开沃特克时，我知道养只猫是我人生清单上的首要任务。"
    red amused sigh "可惜我不能把爪爪先生带到校园里。"
    mc confused "哦，你说的是你那只白猫，对吧？它现在在哪儿？"
    red happy -sigh "宠物收容所。我付钱让它在学期期间待在那里。虽然掏空了我的钱包，但这是值得的。"
    red wry "有时我会飞过去看望它。我想它了。"
    play sound "sound/effects/meow.mp3"
    show red kaget shock
    "就在塞恩絮絮叨叨地说着他的猫时，一只小橘猫走近塞恩，开始嗅他的手。"
    show palmierproxy malu blush sigh
    red cowo blush bloom "哦哦哦，看看这个小橘宝贝。嗨，小家伙！"
    show red kaget both shock
    "这只猫似乎很喜欢塞恩，它开始亲昵地舔他的手指，还蹭着他的手掌。"
    red laugh blush bloom "[povname]，你看到了吗？！你看到了吗？！从来没有猫对我这样过。它在舔我！"
    show palmierproxy smile -sigh
    red awkward "哦，感觉糟透了！你的舌头就像砂纸，但你太可爱了，所以我会让你继续！"
    red cowo "过来，宝贝。"
    show red kaget sweat shock
    show palmierproxy kzl sweat shock
    $ NPC = "女士"
    stop music
    play sound "sound/effects/punch.mp3"
    npc "不！快放下我的猫！" with vpunch
    show palmierproxy confused -shock
    show red sad -shock
    play music "MUSIC/MusMus-BGM-075.mp3"
    "就在塞恩开始把猫抱到膝上时，你看到一个四十多岁的女人朝你们冲了过来。"
    "她的脸因愤怒而通红，指节因用力而发白。她随时都可能爆发。"
    npc "普丽西拉，快离开那个肮脏的吸血鬼！"
    "那个女人从塞恩怀里抢过橘猫，紧紧地抱着它，以至于猫开始愤怒地挠人和嘶叫。"
    red lelah -sweat frusta "嘿，你不应该这么粗暴地对待她。"
    show red kzl
    npc "你管什么？我打赌你是想吸干她的血，对吧？！吸血鬼！吸血鬼！"
    npc "为什么我们还让吸血鬼进来？我要报警！"
    red ew "报警？！女士，我只是在这里做我自己的事！"
    show pboy s at horzappear
    menu:
        "别插手这事":
            hide pboy
            $ mrh.points -= 10
            $ red_events.append('cuekin')
            npc "我怎么能相信一个吸血鬼的话！"
            red growl frusta "别。再。叫。我。那个！"
            show palmierproxy pissed shock
            "塞恩咆哮着露出了獠牙。这一幕显然吓到了那个女人和猫，它们都畏缩了。"
            stop music
            play sound "sound/effects/squell.mp3"
            "那个女人尖叫着跑进了附近的一家书店。"
            red ew sweat "哈...我不该那样做的。"
            play music "MUSIC/MusMus-BGM-006.mp3"
            red sad sigh "现在她更害怕吸血鬼了。"
            mc confused sigh "她活该。"
            red wry -sweat -sigh "我想是吧。"
            mc happy blush tanya "不管怎样，别让她破坏了我们的心情。我们去商店找些猫粮吧。"
        "为塞恩辩护":
            $ mrh.points += 15
            hide pboy
            show red frown shock
            mc kzl frusta "听着，女士。我不知道你有什么问题，但我们什么都没对你的猫做！"
            show red mock -shock
            mc mock cling "而且，你真的想惹我们吗？我们可是靠杀人为生的。"
            npc "你-你杀巫师，不杀人！"
            mc mean tanya "那又如何？用的是同样的符文，可能还更省力。"
            npc "你-你...你疯了！"
            stop music
            play sound "sound/effects/tile.mp3"
            "那个女人在你还没来得及说出下一句话之前就跑掉了。"
            stop sound
            play music "MUSIC/MusMus-BGM-006.mp3"
            red hister both sigh "好吧，这也是一种处理方式。不过我不确定威胁是否是最好的办法。"
            show red amused -both -sigh
            mc deject sigh "呵。像她这样的人是不会听道理的。相信我，在我来的地方，我遇到过很多这样的人。"
            mc happy blush tanya "不管怎样，别让她破坏了我们的心情。我们去商店找些猫粮吧。"
        "打那个女人":
            hide pboy
            $ mrh.points += 20
            show palmierproxy confused sweat frusta
            npc "我不想听你说。等警察来了，你就完蛋了！"
            npc "啊！" with vpunch
            show palmierproxy grit -sweat
            stop music
            play sound "sound/effects/punch.mp3"
            show red kaget sweat shock
            "你一拳打中了那个女人的鼻子，把她击退了。就在她倒在地上的时候，她怀里的猫跳了出来。"
            play music "MUSIC/MusMus-BGM-006.mp3"
            red amused -sweat sigh "哇-哇哦，[povname]！"
            mc rajuk sigh "她在伤害那只猫。"
            red ngeles sweat shock "哦-哦，对。"
            show red sayang -sweat -shock
            show pboy s at horzappear
            menu:
                "还有你。":
                    hide pboy
                    mc wry tanya "当然还有你。你没事吧，塞恩？"
                    show palmierproxy -tanya
                    red wry blush "我没事。她确实惹恼了我，但你真的教训了她一顿。"
                    red amused -blush "不过我们可能不该在这里久留。"
                    
                "检查猫的情况":
                    hide pboy
                    $ mrh.points -= 10
                    red sayang sigh "它没事，只是有点受惊。"
                    red amused -sigh "如果有人这样把我的朋友打晕，我也会受惊的。"
                    red cowo blush bunga "没想到你还有这一手，[povname]。"
                    mc rajuk sigh "她活该。"
                    red grin "确实如此。不过，我觉得我们不应该在这里逗留太久。"
                    red amused -bunga "一个吸血鬼和一个昏迷的人。看起来不太妙。"
            mc happy blush tanya "对。我们去商店买些猫粮吧。"
    red bingung sweat apa"猫粮？"
    show red huh -apa
    mc smile -blush -tanya "怎么了？你看到那些鸟儿因为面包屑而围着你飞。难道你不觉得同样的原理也适用于猫吗？"
    red cowo blush bunga "哦-哦！你真是个天才！"
    play sound "sound/effects/meow.mp3"
    if girl:
        galleryunlock cat
        show cat with flashbulb
    else:
        galleryunlock cat_m
        show cat_m with flashbulb
    "你买了一些固体猫粮，开始在你周围撒。很快你就被猫咪们包围了。"
    "它们趴在你的肚子上，轻咬你的耳朵，在你脸前摇晃着尾巴。它们无处不在。"
    "塞恩看起来兴奋极了。"
    red "我在天堂！你们都那么蓬松可爱又圆润！啊啊啊！"
    mc "哈哈哈，冷静点，你会吓跑猫咪的。"
    red "对，对！对不起，我的错，小猫咪们。啊啊。我希望我们能一直这样。"
    mc "在我的世界里你可以。我们那里有猫咖和狗咖。"
    if girl:
        hide cat with flashbulb
    else:
        hide cat_m with flashbulb
    red huh apa "猫咖？"
    mc happy "只要你付钱，就可以在那里和猫玩一两个小时的咖啡馆。"
    show palmierproxy kind
    if "bonding_me" in red_events:
        red laugh bunga "哇啊！我等不及要去了！"
        red amused -blush -apa "你的世界听起来太棒了，[povname]！没有巫师，有猫咖，没有偏见。"
        mc ha sweat frusta "呃，最后一点别说得太绝对。偏见还是存在的，只不过是针对你的肤色，而不是你的物种。现在我听自己这么说，感觉更糟糕了。"
        show palmierproxy kind -sweat -frusta
        red cowo cling "哈哈。也许吧。不过，我们会互相照顾的，对吧？"
        if 'cuekin' in red_events:
            mc smile sigh "是啊，希望下次我不会再僵住。"
            red amused -cling "嘿，我敢肯定那位女士能感受到你凶狠的眼神。"
            mc malu -sigh "我希望如此。"
        else:
            red cowo cling "就像今天一样。"
            mc smile "是的。"
    else:
        red perih frusta "哦，伙计，你太幸运了！"
        red awkward sigh "天啊，我真希望我能去你的世界。"
        red laugh bunga "没有巫师，有猫咖，没有偏见。听起来简直完美。"
        mc ha sweat frusta "哦，相信我，我这是在美化事实。那里依然糟糕，只是以不同的方式糟糕。"
        mc confused sigh "谋杀不那么普遍，但社会性死亡，那才是真正的问题。"
        mc sad -sweat -sigh "人们取消别人的速度比你们杀死巫师还快。"
        red bingung sweat apa "取消？"
        mc wry "我待会儿再解释。"
        red amused blush sigh "嗯，每个世界都有其缺点。"
        if "bond" in fia_events:
            red cowo cling "我想菲亚和我只能在这里尽力而为了。"
            mc happy tanya "也许我们可以问问奎尔，传送门能否同时带上我们三个人？"
            show palmierproxy wry -tanya
            red amused -blush sigh "我很怀疑。即使对奎尔来说，维度旅行也是相当高深的东西。"
            red frown -sigh "而且我不确定菲亚会想这样，她所有的家人都在这里。"
            red happy "她是个非常重视家庭的人，你知道吗？"
            red datar "实际上，那四个贝克家的人都是如此。"
        else:
            red mock cling "我猜在你们的世界里，血液不容易获得，对吧？"
            mc wry sigh "哦，嗯，是的，我想是这样的。"
        red laugh sigh "别担心，我在伊格尼亚很开心。况且，我还有些事情要做。"
        mc kind tanya "哦？愿意分享一下吗？"
        red awkward -sigh "现在还不行，但也许以后可以，等[povname]醒来之后。"
        show red mock blush cling
        "塞恩陷入沉思，开始把脸埋进一只猫的肚子里。"
        show red perih sweat frusta
        show palmierproxy eiden sweat shock
        play sound "sound/effects/meow.mp3"
        "在塞恩终于放开那只猫之前，它的爪子拉掉了塞恩的一些头发。"
        mc ha -shock "（我想这是他第一次没有抱怨自己的头发被碰到。他一定非常喜欢猫。）"
    red mock blush cling "话说回来，你觉得我们能在老师发现之前偷偷带多少只猫进宿舍？"
    show palmierproxy malu both sigh
    show red laugh bunga
    "他一边问，一边开始一只接一只地把猫塞进自己的夹克里。"
    stop music
    scene bg_black with w20
    "结果答案是五只，他成功了一小会儿，直到猫咪们跳了出来，差点把迪特里希的脸抓花。"
    scene lor_mlm with w20
    play music "MUSIC/MusMus-BGM-082.mp3"
    jump ur_room


label red_date3:
    stop music
    scene bg_black with w20
    $ red_events.append("date3_done")
    scene book with w20
    show red chin datar at left with moveinleft:
        yoffset 330
    if girl:
        show palmierproxy chill kind at right with moveinright:
            yoffset 40
    else:
        show palmierproxy chill kind at right with moveinright:
            yoffset 100
    play music "MUSIC/MusMus-BGM-032.mp3"
    "塞恩带你去了书店，他左手堆着一摞书。"
    "你既印象深刻又非常困惑，不明白这个人突然为什么有了阅读的需求。"
    mc huh tanya "你在研究什么吗？我们不会有什么考试要来了吧？"
    red amused sigh "啊，不，别担心。这些只是个人研究的东西。"
    mc frown -tanya "研究？"
    play sound "sound/effects/pillow.mp3"
    show red kaget both shock
    "你从塞恩那高高的书堆中抽出一本。它的标题是\'吸血鬼契约：情趣还是真爱？\'"
    "就在你大声读到\"情趣\"那部分时，塞恩一把从你手中抢走了书。"
    show palmierproxy apa sweat shock
    red ew sweat frusta "嘘！不用说得那么大声。这是私事！"
    if "bonding_me" in red_events:
        "一丝怒火和一丝尴尬涌上心头。"
        "与此同时，塞恩的脸上露出了理解的表情，也许是感受到了你的无知。"
        mc confused tanya "这是关于我们的契约，对吧？我不应该参与其中吗？"
        red sad sigh "我是说，你说得没错。但我想看起来很酷，然后向你解释这些事情。"
        red perih -sigh "对自己的种族和文化知之甚少，这有点尴尬。"
    elif "bond" in fia_events:
        mc confused tanya "契约有什么问题吗？作为菲亚的[kk]，我不应该参与其中吗？"
        red kzl sigh "但你不是她真正的[kk]。而且，即使你是，菲亚和我之间的事只在我们之间！"
        red frown -sigh "我在试图更多地了解这个契约，了解它会如何随着时间影响我们。"
    else:
        mc ha sweat tanya "你该不会在我们不知情的情况下和谁建立了契约吧，塞恩？"
        show palmierproxy kind -sweat -tanya
        red mock -sweat cling"哈！你在开玩笑吗？学校里有一半的人还在害怕我呢。"
        red amused sigh "我肯定短期内不会和校园里的任何人建立契约的，伙计。"
        red ngeles -sigh "不过，总有一天我需要这么做。你和波比小姐的血液制成的药剂帮了忙，但我担心这不是一个永久的解决方案。"
        red wry "所以我在保持开放态度。"
    red hister both sigh "灵魂契约是私密的事情。你知道，就像你和父母谈论的那种关于鸟儿和蜜蜂的话题。" 
    show red amused -sigh
    mc avoid sweat frusta "那种让你想蜷缩起来死掉的尴尬性教育谈话？是的，我很熟悉。"
    show palmierproxy kind -sweat -frusta
    red wry -both -sigh "是啊，但我不熟悉。我不得不通过书本学习大部分这些东西。"
    red sad frusta "我知道基础知识，但不确定长期来看它是如何运作的。"
    red lelah sigh "灵魂契约不仅在不同物种之间有所不同，即使是同一种契约，其强度和复杂性也会有所差异。"
    red datar -sigh "我听说我们这个种族之间的一些灵魂契约可能会导致参与者交换记忆并共享视觉，而另一些则可能发展出心灵感应交流。"
    if calendar.weekday == "Sat" or calendar.weekday == "Sun":
        show pboy s at horzappear
    else:
        show pboy at horzappear
    menu red_jodoh:

        "试试心灵感应" if "bonding_me" in red_events:
            hide pboy
            $ mrh.points += 15
            show palmierproxy mean cling
            show red amused apa
            "你眯起眼睛，试图将你的思想传达给塞恩。"
            mc kind tanya "（你能听到我吗？）"
            red sayang sigh "我能听到，但那只是因为你又在用嘴型表达你的想法了。"
            mc pissed both frusta "该死！"
            red awkward blush bunga "别觉得尴尬。我喜欢你这样做。很可爱。"
            show palmierproxy malu -both -frusta

        "{s}尝试心灵感应{/s}" if "bonding_me" not in red_events:
            
            jump red_jodoh
        "尝试分享记忆" if "bonding_me" in red_events:
            hide pboy
            $ mrh.points += 5
            show palmierproxy kind tanya
            "你歪着头，试图分享一段记忆。"
            show red amused apa
            "塞恩也歪着头，模仿你的动作。你也跟着他。"
            show palmierproxy side sweat frusta
            show red ew sweat frusta
            "很快，你们两个就左右摇头，前后摆动，互相模仿。就像在玩哑剧游戏一样。"
            red sayang -sweat -frusta "我觉得我要头晕了。"
            mc wry -sweat -frusta "我也是，也许这不是个好主意。"
        "{s}尝试分享记忆{/s}" if "bonding_me" not in red_events:
            
            jump red_jodoh
        "你能吗？":
            hide pboy
            if "bond" in fia_events:
                red kzl frusta "分享情感似乎是我们能做到的极限了。你从没告诉我菲亚早上会有多暴躁。"
                red ew "现在，每天早上我醒来都会感到一阵强烈的愤怒。我感觉想揍一个两岁的孩子。"
                mc eiden tanya "专门针对两岁的孩子？"
                show palmierproxy wry -tanya
                show red wry sigh
                "塞恩耸了耸肩。"
                red amused -sigh "嘿伙计，她是你妹妹。你去问她吧。"
                red datar "不管怎样，我正在试图找到一种方法来屏蔽她。"
                red sad "有天晚上她敲我宿舍的门，因为她感觉....\'刺痒\'，但不明白那是什么。"
                red ew both frusta "我知道她是无性恋，但我从没想过我会向一个19岁的人解释性欲是什么感觉。"
                mc confused shock "等等，真的吗？"
                red hister sigh "是啊。为此熬了一整晚，还被她说要我别那么好色。"
                red wry -both -sigh "天啊，如果我知道怎么做到，生活就容易多了。"
                mc pissed -shock "我猜也是。不过你们没做什么吧，对吧？"
                show palmierproxy wry
                red amused "别担心。我告诉过你我把她当妹妹看，这一点现在依然没变。"
            else:
                "塞恩耸了耸肩。他可能无法回答这个问题，因为他还没有建立联结。"
                red amused "我不知道，但我希望这些书中的一本能回答这个问题。"
                

    play sound "sound/effects/bell.mp3"
    scene overlook with fade
    show red chin datar at left with moveinleft:
        yoffset 330
    if girl:
        show palmierproxy chill kind at right with moveinright:
            yoffset 40
    else:
        show palmierproxy chill kind at right with moveinright:
            yoffset 100
    "塞恩买完东西后，你们俩走到街上，闻到了诱人的培根香味。"
    mc happy tanya "天哪，闻起来真香，在煮什么呢？"
    red amused sigh "哦，那是我。"
    mc confused sweat shock "啊？！"
    show palmierproxy ow 
    show red wry sigh
    "你向右看，注意到塞恩的手上起了水泡，裸露的手腕上出现了红色斑点。"
    mc ew frusta "塞恩，你的手！"
    red mock -sigh "冷静。有时候会这样。热浪。"
    mc kzl "你让我怎么冷静？！你现在简直是在被烤熟！你有药水吗？"
    mc ew -frusta "我想杂货店有把伞！"
    red happy sigh "[povname]，我没事。"
    play sound "sound/effects/cloth.mp3"
    if girl:
        galleryunlock corner_fem
        show corner_fem with flashbulb
    else:
        galleryunlock red_corner
        show red_corner with flashbulb
    "塞恩把你们俩拉到阴凉处。几秒钟内，塞恩手上的水泡和烧伤痕迹开始消失。"
    red "看吧？一切都好。不过还是谢谢你担心我，你刚才的表情看起来好像要吓得拉裤子了！"
    if "bonding_me" in red_events:
        mc "我以为我丈夫要死了，我当然会吓坏，你这个混蛋！"
    elif "bond" in fia_events:
        mc "我以为我妹夫要死了，我当然会吓坏，你这个混蛋！"
    else:
        mc "下次能提前警告我一下吗？"
    mc "还有，你怎么不随身带把伞呢？这不会很痛吗？"
    red "你会习惯这种痛的。再说，我在沃特克经历过更糟的事。"
    if girl:
        hide corner_fem with dissolve
    else:
        hide red_corner with dissolve
    if "vamp_visit" in red_events:
        show palmierproxy sad shock
        show red sayang -sigh
        "一股强烈的痛苦感涌上心头。这是你曾经感受过的。"
        "就像塞恩与母亲重逢时那样。"
        show palmierproxy side sigh
        "这很奇怪。塞恩的感受从来都与他的表情不相符。"
        "现在你们俩建立了联结，你经常感受到他笑脸背后潜藏的深深忧郁之间的冲突。"
        "就好像他的笑容和维尔科娃女士以及其他血骑士戴的面具一样。"
        red amused apa "这话说得真有诗意，[povname]。你有没有想过去写作？"
        mc frown shock "等等，你能听到那个？！"
        red hister both sigh "你又在自言自语地说出你的想法了。"
        mc rajuk sigh "哦。"
        show palmierproxy sad -sigh
        red wry -both -sigh "无论如何，我会没事的。我已经接受了我母亲的状况。"
        red amused "没有太多可以做的，我接受这一点。最好的方式来纪念她的牺牲就是快乐幸福地生活。"
        red ew frusta "这并不容易，但我在努力。"
        red hister sigh "你知道为什么我总是笑得那么多吗？"
        mc side -sigh "因为...你很开心？"
        red amused -sigh "并不总是如此。显然阿什姆能分辨出其中的区别。"
        red datar "他说我只是用嘴在笑，而不是用眼睛。"
        red grin apa "你能看出来吗？"
        "塞恩向你露出了一个露齿的笑容。"
        show palmierproxy confused 
        "经过进一步观察，你觉得你明白了阿什姆的意思。"
        "那笑容没有到达他的眼睛。"
        red happy sigh "化妆让我看起来眼角有皱纹，但实际上并没有。"
        mc frown -sweat shock"你说得对。我以前从未注意到这一点。"
        show palmierproxy sad -shock
        red mock cling "很好。这正是我的目的。"
        red amused -cling "啊，但别担心。我没有阿什姆那么喜怒无常，也没有这个世界的[povname]那么忧郁。"
        red laugh blush bunga "而且自从你来了之后，我的脚步确实变得轻快了。"
        red wry -blush -bunga "只是，嗯..."
        red ew sweat frusta "流放生活...很艰难。"
        red lelah sigh "我仍然记得被放逐的情景，就像昨天发生的一样。"
        red sad -sigh "我赤身裸体，浑身伤痕累累，身上沾满了鞭打留下的血迹。"
        red ew frusta "伤口愈合了，但他们不让我清理血迹。我的母亲，现在已经成为了邪血族，用她的爪子把我抱起来，飞到了教堂门口。"
        red kzl "我被像垃圾一样扔在他们的门前，甚至在撞到他们的钢制门把手后，我的一颗獠牙都掉了出来。"
        red sad sigh "我自己灰色的血从下巴上滴落。我打赌我当时的样子一定很糟糕。"
        red wry -sigh "信不信由你，伊格尼亚是对不同种族最宽容的国家。除了我的家乡大陆，他们是唯一接受吸血鬼居民的地方。"
        red lelah "但即使作为国家的被监护人，我也能闻到他们的恐惧和偏见。学校里也是一样。一开始每个人都很害怕我。"
        red ew"我甚至不能呼吸，就有人吓得尖叫。当然，一开始这很有趣，但很快就变得无聊了。"
        red huh sigh "我是说，最初的几个月是我的问题，我想。我很生气，那种怨恨肯定表现在我的脸上。"
        red sad -sigh "接下来的几个月，我放松了下来，试着微笑。我不知道。我以为如果我假装快乐，也许有一天我真的会快乐起来。"
        red kzl "或者至少其他孩子不会再被吓得屁滚尿流。"
        mc confused "有效果吗？"
        red wry "有效果。人们不再小心翼翼地对待我，渐渐地开始主动接近我。"
        red mock -sweat cling "...不过有一个怪人很突出。"
        if not girl2:
            red laugh blush bunga "我从未从[dia2]身上闻到哪怕一丝恐惧的气味。"
        else:
            red laugh blush bunga "我从未从[dia]身上闻到哪怕一丝恐惧的气味。"
        mc wry -sweat tanya "[povname]？"
        show palmierproxy kind -tanya
        red cowo "没错。[povname]。你的两个版本都是，实际上。你和那个爱操纵人的混蛋。"
        red amused -blush -bunga "这就是为什么我一开始分不清你们。你们两个都不怕我。"
        red "你很慌乱，不知所措，但我从未闻到恐惧的气味。"
        mc ha tanya "真的吗？我是说，你从未怀疑过我这个可疑的家伙？"
        show palmierproxy frown -tanya
        red awkward "嗯，你确实行为可疑，但[kamu]每天也是如此。不过我确实注意到了一个巨大的区别。"
        red datar "你的笑容。当[povname]微笑时，就像月亮，反射太阳的光芒但不发出自己的光。一种反射。"
        red amused sigh "一个死气沉沉的东西，映照着周围的光明。"
        show palmierproxy malu blush shock
        red laugh blush bloom "当你微笑时，就像太阳。温暖，明亮..."
        show palmierproxy wry -blush -shock
        red awkward sigh "科尔，有时候我几乎能看到你身上冒出小花！"
        red calm -sigh "太美了。你...你很美。"
        red happy bunga "我很幸运能与你建立联结，[povname]。"
        mc malu blush bloom "塞恩..."
        "一种奇怪的情感混合在你心中翻腾。对塞恩过去的同情，为他没有让悲伤和愤怒战胜自己而感到骄傲。"
        "对当前处境的喜悦。因建立联结而感到平静，因为被...爱着。"
        red kaget both shock "哦，该死，对不起！我不经意间说了\'我爱你\'，是吗？"
        red ngeles frusta "我不是故意要这样吓到你的！太快了，是吗？"
        show red sad shock
        mc smile sigh "不，塞恩，永远不要为你的感受道歉。尤其是对我。"
        mc happy blush bunga "我不知道我现在对你的感觉是不是爱情。但我知道我喜欢你，塞恩。"
        mc kind "能和你成为灵魂伴侣，我很幸运。"
        red hister bloom "谢谢你，[povname]。这...这对我意义重大。"
        "当塞恩的额头靠在你的额头上时，你感到一种想要缩短你们之间距离的冲动。"
        "你向前倾身，希望偷一个吻。然而，在你这么做之前，你听到有人粗声粗气地清了清嗓子。"
        if calendar.weekday == "Sat" or calendar.weekday == "Sun":
            show palmierproxy apa both shock
            show red sad both shock
            show caf smile at center with dissolve
            caf talk "咳咳。"
            mc avoid tanya"哦，梅莉女士？"
            show palmierproxy sad shock
            show red wry -shock
            caf smile "抱歉，但你们俩能不能换个地方继续？"
            caf chill "恐怕你们用作避难所的这条小巷实际上是我家的入口。"
            red hister -both "哦，对不起，女士。"
            caf talk "没关系。祝你们玩得开心，两位！"
            red mock cling "哦，我们肯定会的。对吧，[povname]？"
            hide caf with dissolve    
        else:
            show palmierproxy apa both shock
            show red sad both shock
            $ NPC = "???"
            npc "咳咳。抱歉塞恩，[povname]，但我和太太觉得你们也许应该换个地方。"
            npc "比如说你的卧室？"
            mc ew both frusta "啊，抱歉！"
            red wry blush sigh "对不起，杰伊先生。我们...我们这就去我的房间。对吧，[povname]？"
        show palmierproxy ow both shock
        "一股强烈的欲望涌上你的下体，既有他的，也有你自己的。你几乎被这种强烈的感觉冲击得站立不稳。"
        mc malu sigh "是...是的。唔。"
        red mock cling "啊哈哈。来吧，[povname]。"
        show palmierproxy ow shock
        show red happy bunga at center with move
        "塞恩把你的胳膊搭在他的肩膀上，在你耳边危险地低语。"
        red mock cling "如果你现在就腿软了，那我们怎么坚持到日出呢？"
        mc kzl frusta "直到日出？！"
        stop music
        scene bg_black with w20
        "你们前往塞恩的房间，是的，他看起来像是一个有使命在身的人。那个使命显然是要确保你几天都无法行走。"
        "在某个时刻，你逃到了自己的房间，他只是笑着告诉你下次要锻炼你的耐力。"
        
    else:
        red ngeles sweat frusta "我告诉你，我经历过的那些破事。我都不知道我是怎么熬过来的，伙计。"
        mc ha sweat sigh "通常是靠酒精和友谊。这对我来说很有效，只不过我有的是一夜情而不是朋友。"
        red mock -sweat apa "是啊，那效果如何？" 
        mc wry sigh "不太好。真的不太好。"
        red hister -apa "哈哈，我猜也是。"
        red amused apa "实际上，你还有一些压抑的挫折感吗？"
        mc smile -sweat tanya "哦，当然有。怎么了？"
        red laugh blush bunga "来吧，我带你去我最喜欢的地方。"
        stop music
        #scene bg_black with w33
        play music "MUSIC/MusMus-CT-NAVAO-32.mp3"
        scene tinggi with w33
        "出于某种原因，塞恩带你来到了学校教堂的最高层，正对着庭院。"
        if calendar.weekday == "Sat" or calendar.weekday == "Sun":
            show red bebas datar at left with moveinleft:
                yoffset 330
            if girl:
                show palmierproxy jln kind at right with moveinright:
                    yoffset 40
            else:
                show palmierproxy jln kind at right with moveinright:
                    yoffset 100
        else:
            show red chin datar at left with moveinleft:
                yoffset 330
            if girl:
                show palmierproxy chill kind at right with moveinright:
                    yoffset 40
            else:
                show palmierproxy chill kind at right with moveinright:
                    yoffset 100
        red grin cling "你有没有试过尖叫宣泄链？"
        mc confused tanya "尖叫宣泄链？"
        show red datar -cling at center with move
        "塞恩点点头，然后靠在栏杆边缘，深吸一口气，大声喊道..."
        red grit frusta"去他妈的魔药课！！！" with vpunch
        show palmierproxy frown shock
        "塞恩的喊声一路回荡而下，在每一层楼之间反弹，震动甚至让窗户都颤抖起来。"
        "在你还没来得及问这到底是怎么回事时，你很快就听到了一个不那么男性化的声音的跟进尖叫。"
        $ NPC = "???"
        npc "去他妈的我可怜的屁股！！！"
        $ NPC = "大卫"
        npc "我讨厌大胸蠢妞！！！去你的珍！你这个婊子！"
        $ NPC = "珍"
        npc "他妈的！！！大卫你也去死吧！！"
        $ NPC = "???"
        npc "去他妈的衣服！让我们裸奔吧！！！"
        $ NPC = "学生们"
        npc "不要！！！"
        $ NPC = "???"
        show red laugh blush bloom
        mc wry tanya "这...这到底是怎么回事？"
        red mock cling "你以为这所学校里有人能把生活安排得井井有条吗？不，我们都有问题。"
        red hister -cling "我们需要大声地、通过回音室、在几十个人面前宣泄的问题。"
        red amused "你应该看看考试季的院子，这里每个人整天都在尖叫。"
        red datar "这也是凯普勒先生坚持保持图书馆为无崩溃区的另一个原因。"
        red happy apa "不过这里随便你。想试试吗？"
        mc mock cling "当然要！"
        show red datar at left with move
        show palmierproxy mean -cling at center with move
        "你深吸一口气，集中了你内心所有的愤怒。"
        play sound "sound/effects/bump.mp3"
        show palmierproxy pissed sweat shock with vpunch
        show red wry -blush shock
        "然后不小心用脚趾撞到了栏杆，结果你不是喊出愤怒，而是痛得大叫。"
        play sound "sound/effects/panic.mp3" fadeout 2.0
        mc ow frusta "啊啊啊啊啊！！！" with vpunch
        $ NPC = "学生们"
        npc "啊啊啊啊啊啊！！！！" with vpunch
        $ NPC = "???"
        red hister apa "哈哈哈。我猜这不是你想做的吧？"
        stop sound
        mc pissed "哎哟，哎哟，哎哟。不是...但也算有效吧。"
        red wry apa "感觉好些了吗？"
        mc laugh blush sigh "好多了。谢谢你带我来这里，塞恩。"
        red happy bunga "随时效劳。"
        stop music
        scene bg_black with w20
        "你们俩充分利用了这次尖叫会，然后回到了各自的房间。"
    scene lor_mlm with w20
    play music "MUSIC/MusMus-BGM-082.mp3"
    jump ur_room



label red_date2:
    stop music
    #scene bg_black with w33
    play music "MUSIC/MusMus-BGM-CP03.mp3"
    scene cofi with w33
    if calendar.weekday == "Sat" or calendar.weekday == "Sun":
        "塞恩带你去了附近的一家咖啡馆。"
    else:
        "塞恩带你去了咖啡馆，偷偷带你去了戈莫拉。"
    "你本不想点单，因为现在手头有点紧，但塞恩坚持要请客。"
    show red bebas datar at left with moveinleft:
        yoffset 330
    if girl:
        show palmierproxy jln kind at right with moveinright:
            yoffset 40
    else:
        show palmierproxy jln kind at right with moveinright:
            yoffset 100
    red laugh bloom "我是说，我们俩都很穷，但嘿，这更是我们要互相照顾的理由，对吧？"
    mc wry "真的吗？我是说，谢谢！别担心，我只想要一块草莓蛋糕。"
    red amused "没问题。另外，如果你想点别的也行。比如喝点什么？"
    mc smile tanya "要不来一壶茶一起喝？你能喝茶吗？"
    red happy -bloom "我是说，我其实不能完全消化它，但我喜欢它的香味。"
    mc confused -tanya "除了血，你还能消化其他东西吗？"
    red amused sigh "药水、酒精、水。"
    red datar -sigh "一些糖果，虽然我不是很喜欢甜食。"
    if "ajax" in fia_events:
        red wry "不过最近我越来越少渴望它们了，没有甜食能比得上血液。"
    else:
        red cowo "但我喜欢血味棒棒糖！虽然在沃特克和莫洛纳以外很难找到。"
    mc frown "对你来说血液是什么味道？金属味吗？"
    red wry "味道取决于人。通常我可以从他们的气味估计出他们会是什么味道。"
    red ew frusta "就像一个女孩可能是10分，但如果她的血闻起来有怪味，那你就知道这姑娘生活不太规律！"
    show red amused -frusta
    mc deject tanya "哦，所以这是关于饮食和生活方式的事？"
    red happy "某种程度上是，但还不止于此。年龄和血型也会影响。"
    mc kind -tanya "嗯。那你觉得我的血怎么样？"
    red mock blush cling "哦，你的血是无与伦比的，[nickname]。"
    "他说这话时眼神恍惚。"
    show red wry -cing at center with move
    show palmierproxy rajuk shock
    "在你来得及抗议之前，他轻轻拉过你的手，吻了你的手掌。尖锐的獠牙轻轻刺痛了你的拇指。"
    red amused sigh "有时我会不自觉地想着你的脖子有多美，或者我想一点一点地啃咬它，舔掉那些小小的血珠。"
    red mock -sigh "也许让血滴落到你的胸口，然后我用舌头从你的横膈膜一直舔到你的嘴唇..."
    red ow both shock "啊！对不起，这很吓人，是吧？！"
    show palmierproxy frown sweat
    "塞恩猛地退缩，似乎终于回过神来，在整个独白之后显得相当内疚。"
    show pboy s at horzappear
    menu:
        "有点。":
            hide pboy
            $ mrh.points -= 10
            if mrh.points < 0:
                $ mrh.points -= 0
            show palmierproxy side frusta
            red perih frusta "对不起，对不起！我发誓，我最近不知道我的大脑怎么了。"
            red ew "也许我需要更多的血。"
            red sad sigh "我...我很抱歉，我真的该走了！"
            hide red with moveoutleft
            show palmierproxy sad shock
            "塞恩逃离了现场，留下你一个人和一块吃了一半的草莓蛋糕。"
            show palmierproxy sad at center with move
            "每个人都盯着你看，你感觉自己好像错过了什么。"
            mc deject tanya "（...他没事吧？）"
            scene bg_black with w20
            "你吃完甜点后回到了宿舍。"
        "好热啊！":
            hide pboy
            $ mrh.points += 10
            show palmierproxy mean blush cling
            red kaget both shock "哦-哦。"
            red mock sigh "你有点怪异，不是吗，[povname]？我不是说这有什么不好。"
            red sayang -sigh "这有点..."
            mc malu tanya "性感？"
            red mock blush cling "性感。"
            mc kind tanya "你那敏锐的鼻子只能闻到血的味道吗？"
            red amused -tanya "不，我也能闻到情绪，虽然没有狼人那么擅长。"
            mc confused sweat shock "等等，你能闻到情绪？！但你从来都不会察言观色啊！"
            red hister sigh "啊哈。我能闻到情绪并不意味着我擅长处理它们。"
            red amused -sigh "有时我只是喜欢捉弄那些家伙，尤其是奎尔。那小子的情绪总是四处飘散。"
            mc happy -sweat tanya "哦，我明白了。那我呢，你从我身上能感觉到什么？"
            red datar apa "你？嗯，我觉得你闻起来很开心，里面还带着一丝好奇。"
            red mock -blush cling "好奇和...欲望。"
            mc frown shock "（他又用那种充满暗示的眼神盯着我了。）"
            show pboy s at horzappear
            menu:
                "回瞪":
                    hide pboy
                    $ mrh.points += 5
                    mc malu both sigh "（我分不清那眼神是想吃了我还是想上我。我想我可以试试看。）"
                    show palmierproxy flirt -both cling
                    show red kaget both shock
                    play sound "sound/effects/stab.mp3"
                    "你叉起一块草莓，开始以一种淫荡的方式舔舐它。"
                    show red ew both frusta
                    show palmierproxy frown shock
                    play sound "sound/effects/plate.mp3"
                    "这招起效了一会儿，直到你不小心把草莓掉在地上，大声哀叫起来。"
                    mc sad frusta "我的草莓！"
                    red ngeles shock "我给你再拿一个！"
                    play sound "sound/effects/chair.mp3"
                    "他大声说道，突然从座位上站了起来。他的椅子向后倒去，砰的一声砸在地砖上。"
                    show palmierproxy mean cling
                    "其他客人立即盯着他看，有些人感到恼火，有些人则感到困惑。"
                    red kaget both shock"啊..."
                    "突如其来的震耳欲聋的寂静似乎让塞恩从恍惚中清醒过来，他相当羞怯地坐了回去。"
                    red perih frusta "该死，你又在戏弄我，是不是？该死，别这样[povname]！"
                    mc hister blush bloom "啊哈哈！对不起，对不起！"


                "移开视线":
                    hide pboy
                    $ mrh.points -= 5
                    show palmierproxy both sigh
                    show red sad sweat shock
                    "你移开视线，开始用叉子刮擦牙齿，希望能让他失去兴趣。"
                    "这招奏效了。"
            mc smile tanya "顺便问一下，你和菲亚在魔药问题上有什么新突破吗？"
            red laugh blush bunga "哦，菲亚太棒了。我早该先找她帮忙的！谁知道她这么适合教学。"
            show palmierproxy wry blush sigh
            red awkward "我发誓我以为她会欺负我，但并没有！"
            red hister "好吧，有时候她确实会，但她会用糖果来补偿我，所以没关系！"
            scene bg_black with w20
            "你和塞恩聊了一天的闲话。你感觉和他的关系更亲近了一些。"


        "这很自然。":
            hide pboy
            $ mrh.points += 5
            mc ha sweat sigh "我的意思是，我也吃肉。所以我理解。至少你让你的猎物活着。"
            mc kind -sweat -sigh "我猜这对环境挺好的。"
            red amused blush sigh "啊哈，你真是思想开放啊，[povname]？"
            red laugh bunga "这有点好笑。"
            red awkward -blush "不过[povname]也是这样，所以我想我不应该感到惊讶。"
            mc side tanya "我们真的那么相似吗？"
            red amused sigh "我是说，除了你的道德指南针和笑容，是的。"
            mc frown -tanya "我的笑容？"
            red grin -sigh "啊，[povname]的笑容没有你那么灿烂。当[nickname]笑的时候，几乎难以察觉。"
            #berubah
            red cowo "而你呢，嗯，你的笑容有时比太阳还要明亮，尤其是当你眼角出现皱纹的时候。"
            #berubah
            red happy "很好看。"
            mc avoid sigh "我只是惊讶[povname]居然能笑得出来，在我的梦里[kamu]看起来那么愤怒。"
            show palmierproxy wry -sigh
            red mock sigh "我能理解。第一次看到[povname]笑我也吓了一跳。就是[dia]真正的笑。一个不带轻蔑的笑！"
            red laugh bunga "我们去钓鱼，然后[kamu]钓到了一条破纪录的蓝鲱鱼，接着我们..."
            scene bg_black with w20
            "你和塞恩聊了一天的闲话。你感觉和他的关系更亲近了一些。"

    $ red_events.append("date2_done")
    stop music
    scene lor_mlm with w20
    play music "MUSIC/MusMus-BGM-082.mp3"
    jump ur_room
label trio_hang:
    play music "MUSIC/MusMus-BGM-075.mp3"
    scene library with w20
    stop sound
    show red chin kzl at left with dissolve:
        yoffset 330
    show croissant flinch kzl at right with dissolve:
        yoffset 500
    "你走进图书馆，只见塔图姆和她的喽啰们正在围攻你的妹妹和塞恩。"
    $ NPC = "塔图姆"
    show npc2_m at pic
    npc "哦，这是什么情况？菲亚和本地的吸血鬼。我就知道你们两个会成为朋友。"
    hide npc2_m
    red calm cling "哦，现在我成了水蛭了？伙计，我只是拒绝了你一次约会，没必要为此耿耿于怀吧。"
    fia mock "别费心了，塞恩。跟这个疯婆子讲道理是没用的。"
    show croissant sad sweat shock
    show npc2_m at pic
    npc "我是婊子？这话从一个血妓嘴里说出来还真是讽刺啊！"
    hide npc2_m
    play sound "sound/effects/bang.mp3"
    red ew sweat frusta "你给我注意点！"
    show npc2_m at pic
    npc "说到痛处了，是吗？不然你们俩怎么会总是黏在一起？"
    hide npc2_m
    play sound "sound/effects/tile.mp3"
    "当\'妓女\'这个词从她嘴里说出来的那一刻，你立即抓起了能找到的最厚的书——准备狠狠地教训那个女人一顿。"
    play sound "sound/effects/api.mp3"
    "幸运的是，奎尔比你更快，他打了个响指，泰特姆的马尾辫尖端开始燃烧起来。"
    show croissant frown -sweat shock
    show red kaget shock
    show npc2 at pic
    npc "什么——？！啊啊啊！"
    hide npc2
    show quil flashy ejek cling at center with dissolve:
        yoffset 200
    quil "抱歉亲爱的，我觉得你需要改善一下形象。"
    quil heh -cling "你知道你的头发从后面看有多乱吗？把它烧掉简直是在帮你。"
    show npc2_m at pic
    npc "你！我会报复你的！"
    hide npc2_m
    stop music
    play sound "sound/effects/tile.mp3"
    "泰特姆和她的朋友们跑走了。"
    stop sound
    play music "MUSIC/MusMus-BGM-024.mp3"
    show red amused sigh
    fia def mad sigh "我本来能控制住局面的。"
    quil laugh spark "亲爱的，我这么做不是为了你。作为一个婊子，我为把关这个身份而自豪。"
    quil heh "你太过冷淡和纯洁，还不配得到这样的称号。"
    fia ejek cling "荡妇。"
    quil amused cling "贱人。"
    fia hmph blush sigh "泼妇……不过还是谢谢你。"
    quil smile -cling "随时效劳。"
    show red sayang
    show pboy at horzappear
    menu :
        "你们俩真奇怪。":
            hide pboy
            $ honesty += 10
            $ kindness -= 10
            red awkward sigh "可不是嘛。"
            
        "你真贴心，不是吗？":
            hide pboy
            $ honesty -= 10
            $ kindness += 10
            fia kerja -sigh "我很感激。但是，我本来可以自己解决她的。"
    red bingung apa "话说回来，泰特姆一直都这么贱吗？"
    show red frown -apa
    quil rajuk sigh "经济动荡常常会对人产生这样的影响。"
    fia frown -sigh "是啊，我们都知道她是贿赂进来的。听说她父母最近经济困难，可能是这个原因。"
    fia flinch gross sweat frusta "或者她还在为海德温女士选我做她的替补而耿耿于怀。"
    fia mad sigh "真是个戏精。"
    red ew frusta "可不是嘛。那个\'血妓\'的评论简直莫名其妙。"
    quil amused apa "嗯……真的吗？你们俩看起来关系挺亲密的。"
    red wry -frusta "只是辅导而已。菲亚是个很棒的老师。"
    fia def wry -sweat -sigh "这只是胡萝卜加大棒的方法，[kk]小时候经常对我用这招。"
    show side_p f at pic
    mc "我有吗？"
    hide side_p
    fia kerja "嗯哼。别以为我没看穿你的操纵手段。不过确实有效。"
    fia happy "话说回来，你们是来帮塞恩学习的吗？"
    show croissant hmph
    quil datar -apa "是的，不过看起来你已经掌控局面了。"
    red cowo blush bunga "没错。我终于知道什么是林施姆了！林施姆！"
    quil heh sigh "天哪！你在学一年级的魔药学？真是个创造奇迹的人。"
    fia err frusta "他还在进步中，好吗？"
    fia happy apa "不过既然你们来了，要不要做点有趣的事？"
    show croissant kerja -apa
    show side_p f at pic
    mc "比如什么？"
    hide side_p
    show red frown -blush shock
    show quil frown shock
    show croissant flinch ejek cling
    play sound "sound/effects/pillow.mp3"
    "菲亚拿出了一本粉色的日记本，上面到处都是墨水斑点。看起来像是一本日记。"
    fia mock "我不知道，也许把泰特姆的日记页散布在学校各处？"
    show quil malu sigh
    fia laugh apa "塞恩，你会飞，对吧？"
    red kaget -shock "等等，那是她的日记？你是怎么弄到的？"
    show red huh 
    fia mock cling "隐形药水加上最普通的撬锁技巧。"
    show pboy at horzappear
    menu:
        "来吧，干了！":
            hide pboy
            $ curiosity += 10
            $ kindness -= 20
            show side_p se at pic
            mc "以眼还眼。她活该。"
            hide side_p
            red bingung sweat frusta "嗯，我不太确定。"
            fia def kerja -cling "我给你酿些混血药剂。"
            red grin blush shock "成交！"
            show red cowo bunga
            quil heh cling "真是单纯。我想我可以帮忙。风符文应该能帮助她的日记页散得更开。"
            scene tengah with fade
            "下午晚些时候，你看到塔图姆的日记页散落在校园各处。"
            "当菲亚和塞恩一起飞行，散布塔图姆日记中的每一个秘密时，人们抓住从天而降的纸页。"
            "塔图姆对着菲亚声嘶力竭地尖叫，疯狂地收集着那些纸页。"
        "拿走日记":
            hide pboy
            $ curiosity -= 10
            $ kindness += 20
            fia flinch err sweat shock "嘿！"
            show side_p m at pic
            mc "得了，伙计们，没必要火上浇油。"
            hide side_p
            fia sad frusta "哼，[nickname]，你这学期一点都不好玩！"
            show red amused sigh
            show quil amused cling
            fia mock -sweat cling "还有，我要把它拿回来！"
            show croissant mock -cling
            show side_p c at pic
            mc "你试试看！"
            hide side_p
            scene library with dissolve
            "你花了剩下的时间躲避菲亚，她竭尽全力想要偷回塔图姆的日记。"


        "走开":
            hide pboy
            $ curiosity -= 20
            $ honesty += 10
            show side_p he at pic
            mc "你想做什么就做什么吧，但我不会参与其中。"
            hide side_p
            fia hmph sigh "切，你损失了。"
            fia laugh apa "塞恩，奎尔？我再加点血和亮片怎么样？"
            red cowo blush bunga "血？哇哦，不用多说了！"
            quil tantrum frusta "呃，你把我当小孩子吗？用亮片贿赂我。说真的，菲亚。"
            show quil rajuk shock
            fia malu cling "那么，即使是一套屁股开洞的警察制服你也不愿意吗？"
            quil laugh bunga "成交！"
            scene tengah with fade
            "下午晚些时候，你看到塔图姆的日记页散布在校园各处。"
            "当菲亚和塞恩一起飞行，散布塔图姆日记中的每一个秘密时，人们抓住从天而降的纸页。"
            "塔图姆对着菲亚声嘶力竭地尖叫，疯狂地收集着那些纸页。"
    stop music
    scene bg_black with w20
    scene lor_mlm with w20
    $ night = False
    $ evening = True
    $ afternoon = False
    $ morning = False
    play music "MUSIC/MusMus-BGM-082.mp3"
    jump ur_room
label water_dance:
    scene bg_black with w20
    play sound "sound/effects/splash.wav"
    play music "MUSIC/MusMus-BGM-078.mp3"
    scene lake with w20
    show red cowo blush bloom at center with dissolve:
        xzoom -1.0
        yoffset 330
    "塞恩把你拉到湖边。没有事先通知你，他立即跳入水中，"
    "把你也拉了进去。"
    show red datar at right with move
    if girl:
        show palmierproxy frown sweat shock at left with moveinleft:
            yoffset 40
    else:
        show palmierproxy frown sweat shock at left with moveinleft:
            yoffset 100
    "你闭上眼睛以为自己会浑身湿透，但随后你意识到自己仿佛正走在坚实的地面上。"
    "低头一看，你发现自己的鞋底正在冻结脚下的水面。"
    red amused sigh "别担心，我保护着你呢。我虽然不像奎尔那样是冰爆高手，但我对冰符文的控制比大多数人都要好。"
    mc confused -sweat tanya "冰爆？"
    red wry -sigh "啊。就像炸弹，但是用冰，奎尔很擅长这个。"
    red cowo "给他时间的话，我相信他能冻住整个湖面。"
    red sayang bunga "好了，不说奎尔了，过来跳舞吧！"
    mc frown shock "哇！"
    show red cowo
    show palmierproxy wry at center with move
    "塞恩开始拉着你，轻松自如地在水面上滑行。"
    scene kapal with dissolve
    if girl:
        show palmierproxy frown sweat shock at center with dissolve:
            yoffset 40
    else:
        show palmierproxy frown sweat shock at center with dissolve:
            yoffset 100
    show red cowo blush bloom at right with dissolve:
        xzoom -1.0
        yoffset 330
    mc malu sweat "（这就像溜冰。但我溜冰很烂！）"
    mc sad frusta "塞恩，慢点！"
    mc frown -sweat shock"啊！"
    play sound "sound/effects/crash.mp3"
    show red frown sweat shock
    galleryunlock ilahi
    show ilahi with flashbulb
    "就在你快要摔倒的时候，塞恩把你拉进了他的怀里。你能听到他微弱的心跳声。极其缓慢，但很稳定。"
    red "对不起，你没事吧？"
    mc "啊，我..."
    $ NPC = "???"
    stop music
    npc "你这混蛋！" with vpunch
    show side_p s at pic
    mc "嗯？"
    hide side_p
    hide ilahi with dissolve
    show palmierproxy sad sweat -shock
    show red bingung  
    "当你转向甲板时，你看到科尼尔眼含泪水，双手紧握成拳。"
    red frusta "科尼尔！"
    $ NPC = "科尼尔"
    npc "如果你想独占他，你应该直说的！"
    $ NPC = "???"
    red perih "等等，科尼尔！该死。我最好去解释一下。"
    mc sad sigh "我和你一起去。"
    red huh -sigh "真的吗？好吧。但要小心，我是说...他可能会有点发火。"
    scene bg_black with w20
    "结果\'有点\'的意思是他向你们发射了一场台风，你们不得不一路决斗才回到宿舍。"
    "幸运的是，塞恩设法制服了科尼尔，并让他恢复了理智。"
    "塞恩让科尼尔在他怀里哭泣，同时温柔地拒绝了他。"
    scene lor_mlm with w20
    $ red_events.append("ntr")
    $ night = False
    $ evening = True
    $ afternoon = False
    $ morning = False
    play music "MUSIC/MusMus-BGM-082.mp3"
    jump ur_room
label rasis_vamp:
    stop sound
    play music "MUSIC/MusMus-BGM-075.mp3"
    show red point ew sweat at center with dissolve:
        yoffset 330
    red frusta "温斯顿，你他妈在干什么？！"
    "温斯顿掐住塞恩的脖子，用右臂将他钉在墙上。"
    "在他的左手中，你可以看到一根闪亮的银桩。"
    "一群人围在他们周围，困惑地看着。"
    show side_p s at pic
    mc "（等等，他不是想杀死塞恩吧？！）"
    hide side_p
    show quil flashy kzl at right with moveinright:
        yoffset 200
    quil grit sweat frusta "温斯顿！这是什么意思？！"
    show quil shock
    $ NPC = "温斯顿"
    npc "离我远点，贱人！这与你无关！"
    if girl:
        show palmierproxy scratch frown at left with moveinleft:
            yoffset 40
    else:
        show palmierproxy scratch frown at left with moveinleft:
            yoffset 100
    mc apa sweat frusta "你正在掐我们的朋友。我觉得这确实与我们有很大关系。"
    npc "你——你就是向凯普勒举报我的人。我打赌是这个吸血鬼要求你这么做的！"
    npc "你对他们使用了强制力吗，吸血鬼？"
    red growl frusta "你在说什么？！滚开！"
    play sound "sound/effects/punch.mp3"
    queue sound "sound/effects/crash.mp3"
    show palmierproxy frown -sweat shock
    show quil skul frown -sweat shock
    "塞恩用力一脚将温斯顿踢开，他的背重重撞在身后的沙发上，将沙发掀翻。"
    npc "呃。你喝血了，是不是？！否则你怎么会有这么大的力气？！"
    npc "恶魔！我就知道，你会吸干我们所有人的！"
    red chin mock -sweat cling "哈！你以为我需要喝血才能把你打倒？不像你，我可从来没有跳过腿部训练日！"
    npc "你这个——！"
    play sound "sound/effects/bump.mp3"
    scene atas_sore with vpunch
    "温斯顿再次冲向塞恩，举着木桩扑了过来。"
    show priest side at center with dissolve:
        yoffset 200
    dog frusta "够了，你们两个！"
    play sound "sound/effects/swosh.mp3"
    queue sound "sound/effects/bump.mp3"
    "一阵强风将温斯顿狠狠地摔在远处的墙上。" with vpunch
    "你转过头，看到迪特里希悠然地走进房间。他不适地整理着衣领，叹了口气。"
    dog kzl sigh "温斯顿，你怎么还在这里？你已经被开除了，这所学校已经没有你的容身之处了。"
    npc "在我杀死这个吸血鬼之前，我是不会离开的！"
    dog bleh "够了！"
    play sound "sound/effects/unlock.mp3"
    queue sound "sound/effects/crash.mp3"
    "他再次打了个响指，黑色的锁链开始在温斯顿周围形成，迫使他停了下来。"
    "温斯顿在地板上像条蠕虫一样扭动，试图挣脱锁链。"
    dog sad apa "塞恩，你没事吧？"
    show priest -apa at right with move
    show red chin huh at left with dissolve:
        yoffset 330
    red sigh "我没事。"
    dog sad sigh "很好，我亲自护送温斯顿出去。这种行为是不可原谅的。"
    dog sly -sigh "其他人，请去上课吧。对于造成的骚动我很抱歉。现在没事了，这里没什么好看的。"
    "迪特里希说这话时露出了安慰的微笑，尽管你隐约听到他在拖走温斯顿时嘴里嘟囔着\"没用的废物\"。"
    "温斯顿一路尖叫，锁链在木质红木地板上发出哗啦哗啦的声响。"
    npc "我告诉你们他很危险，在他吸干你们所有人之前快逃——"
    queue sound "sound/effects/stab.mp3"
    npc "啊——！" with vpunch
    dog grin cling "哎呀。"
    show priest charm bunga
    "迪特里希轻笑着，地板上一根明显突出的钉子划破了温斯顿的下唇。"
    hide priest with dissolve
    play sound "sound/effects/walk.mp3"
    show red point kzl at center with move
    red "啧，真是个疯子。"
    stop sound
    if girl:
        show palmierproxy scratch sad sweat at left with moveinleft:
            yoffset 40
    else:
        show palmierproxy scratch sad sweat at left with moveinleft:
            yoffset 100
    show quil rajuk at right with moveinright:
        yoffset 200
    "塞恩一边整理衬衫一边嘟囔道。奎尔帮忙拍掉他肩上看不见的灰尘。"
    quil sad apa "你没事吧，红毛？"
    show palmierproxy chill confused
    red hister sigh "我没事。天啊，真是个疯子，对吧？"
    quil rajuk sweat sigh "他的父母被吸血鬼杀害了，别往心里去。"
    red bingung -sigh "我知道，温斯顿以前住在汉弗莱斯。"
    red sad "吸血鬼很久以前就袭击过那个地方。我理解他的怨恨，但是...这样做还是不酷。"
    show quil wry -sweat
    "当奎尔安慰塞恩时，你忍不住偷听周围的窃窃私语。"
    $ NPC = "学生"
    npc "哇，温斯顿疯了。"
    npc "是啊，但我是说，他说得也有道理。吸血鬼随时可能失控，而且塞恩的眼睛最近比平常更红！"
    npc "那又怎样？那什么都不能说明，别这么武断！"
    npc "是啊，温斯顿才是疯子，塞恩连只苍蝇都不会伤害！"
    mc deject "（看来大多数人并不赞同温斯顿的偏见。这很好。）"
    mc side sweat "（虽然我不得不承认。塞恩的棕色眼睛这些天确实比往常更偏向深红色。）"
    mc confused -sweat "（我不知道这是为什么？）"
    red datar apa "[povname]，我们要去吃早餐了，你来吗？"
    show quil datar -sigh
    if "ker_bar" in buff_events:
        mc chill smile "啊，稍后吧，我今天和莱尔有点事。"
        quil flashy heh cling "哦哦，和新来的小鲜肉亲密接触，是吗？我都嫉妒了。"
        mc huh "我是在帮他运送鱼为节日做准备。"
        show palmierproxy malu sigh
        quil tantrum sweat frusta "...算了，我恶心得发绿。呃，鱼！"
        show palmierproxy smile -sigh
        red cowo -apa "如果你抓到乌龟，给我留点血，好吗？"
        quil err "呃，别说了，我要吐了！"
        scene bg_black with w20
        "担心奎尔敏感的呕吐反应，你迅速前往码头。你希望莱尔没有等太久。"
        jump lyal_ker_bar
    mc happy sweat "啊，当然！"
    scene bg_black with w20
    "你和塞恩、奎尔一起吃了早餐，然后出门享受这一天的余下时光。"
    $ NPC = "???"
    if "bunga_bego" in buff_events:
        if "beku" in quil_events:
            scene map_infected_f with w20    
        else:
            scene map_infected with w20    
    else:
        if "beku" in quil_events:
            scene map_frozen with w20
        else:
            scene map_all with w20
    jump world_map


label red_date1:
    show red chin at center with dissolve:
        yoffset 330
    red cowo "哦，你想一起出去玩？就我们两个？当然可以。"
    if "mini_ketemu" in red_events:
        red sayang sigh "很高兴你接受了我的邀请。"

    elif "blood1" in completed_quests or "date_1" in red_events:
        red wry "反正我也想报答你给的血药，所以今晚的食物我请客。"

    elif "day4" in my_events or "help_study" in tom_events:
        red grin "既然阿什姆给了我一些混合血，我正好想去一个地方。"

    red point amused blush bunga "你应该换上更舒适的衣服，然后我们在这里碰头。"
    show side_p he at pic
    mc "你要带我去哪里？"
    hide side_p
    red cowo "嘿嘿，这是个惊喜！"
    jump red_gate_scene


label red_date1_skul:
    scene kmr_malam with w20
    play music "MUSIC/MusMus-BGM-082.mp3"
    if girl:
        show palmierproxy jln deject at center with dissolve:
            yoffset 40
        

    else:
        show palmierproxy jln deject at center with dissolve:
            yoffset 100
    mc "我不知道这样穿合适吗？"
    "塞恩没有告诉你今晚要去哪里，所以你只是穿上了看起来舒适的衣服。"
    "这并不是一件容易的事。[povname]的大多数衣服都是...至少可以说是有问题的。"
    if not girl:
        mc ew frusta "为什么我的衣柜里有这么多透明的衣服？这里的人不可能真的穿这种——"
        show palmierproxy
    else:
        mc ew frusta "一个人需要多少丁字裤啊？难道[povname]从未体验过穿舒适内衣的快乐吗？！"
    show palmierproxy frown at right with move
    play sound "sound/effects/door.mp3"
    show red bebas laugh bunga at left with moveinleft:
        yoffset 330
    red "准备好了吗，[nickname]？"
    show palmierproxy -sweat confused shock
    "塞恩突然闯进门来。他甚至懒得敲门。"
    show palmierproxy eiden both -shock
    "看着他的衣服...紧身上衣，在他的人鱼线处裁剪。"
    "是啊，也许你的衣柜也没那么糟糕。"
    if girl:
        mc laugh sweat "塞恩，这真的是你平常的穿衣风格吗？"
        show palmierproxy frown -sweat
        red frown apa "嗯？哦，是裤子的问题吗？我知道黑色紧身裤会更好，但我这学期没带我的靴子来。"
        red wry -apa "没有靴子的话看起来就不好看了。"
        mc sweat "是这样吗？啊哈哈哈。"
        mc malu -sweat "（这是不是意味着你的裤子本可以更紧？天啊，好像你的屁股还不够好看似的。）"
        mc happy "那么，呃...我们今晚要去哪里？"
        show palmierproxy kind
    else:
        mc huh sweat tanya "所以...这里的每个人都24/7穿得像色情明星一样，还是...？"
        show palmierproxy malu both -tanya
        red huh apa "嗯？你说什么了吗？"
        show red wry -apa
        mc ha sweat -both "什么？哦不，别...别在意我。"
        mc laugh -sweat "你的裤子不错。"
        red amused "哦，这个？我知道黑色紧身裤会更好，但我这学期没带我的靴子来。"
        red cowo cling "没有靴子的话看起来就不好看了。"
        show red datar -cling
        mc hister "是这样吗？啊哈哈哈。"
        mc smile sweat "（该死，这是不是意味着他的裤子本可以更紧？天啊，好像你的屁股还不够好看似的。）"
        mc happy -sweat "那么，呃...我们今晚要去哪里？"
        show palmierproxy kind
    red awkward sweat "嗯，那个...我不能在{i}这里{/i}告诉你。"
    scene bed_mlm with dissolve:
        xalign -1.0
    show buff datar at right with dissolve:
        yoffset 770
    "塞恩的目光飞快地瞥向躺在床上的莱尔。"
    show red bebas amused at left with dissolve:
        yoffset 330
    buff confused apa "哦，呃...别在意我。"
    show buff frown -apa
    red hister "伙计，你很难不被注意到。另外，我今晚要带这个人出去，好吗？"
    red ew cling "别等我们，也别告密，明白吗，小子？"
    show red amused 
    buff sad sweat sigh "...我不是小孩子。"
    show pboy s at horzappear
    menu:
        "向莱尔道晚安":
            $ putri.points += 5
            hide pboy
            show side_p ha at pic
            mc "晚安，莱尔。好好休息，好吗？"
            hide side_p
            buff wry -sweat -sigh "好的。"
        "告诉他不用等":
            hide pboy
            show side_p ha at pic
            mc "不用等我们，好吗？"
            hide side_p
            if bff.points <= 10:
                buff huh frusta "我本来就没打算等。"
                buff wry sigh -sweat "但是...注意安全。"
            else:
                buff wry blush -sigh "好的，但要小心，好吗？"
        "你想一起来吗？":
            hide pboy
            show red kaget shock
            buff confused sweat apa "你想让我和你们一起去？"
            show side_p ha at pic
            mc "我是说，人多才更热闹，对吧塞恩？"
            hide side_p
            red ew frusta sweat "什么？不，[nickname]，这真的不是——！"
            show red frown -frusta -sweat
            buff keluh -sweat sigh "没关系，我，呃...反正我还有些作业要做。"
            buff talk blush -sigh "你玩得开心，[povname]。"
            show side_p ha at pic
            mc "好吧。别等我了，好吗？"
            
            $ putri.points += 10
            show side_p ha 
            mc "晚安，莱尔！"
            hide side_p
            show red amused sigh
            buff laugh "晚安。"
    jump red_gate_scene
label red_gate_scene:
    scene bg_black with w20
    scene night_gate with w20
    play music "MUSIC/MusMus-BGM-098.mp3"
    "在塞恩坚持不懈的拉扯下，你被带到了校园大门。他撬开一扇锁着的门，你们爬上一段楼梯，来到大门的上方围墙。"
    show side_p k at pic with dissolve
    mc "塞恩，我们在这里做什么？"
    hide side_p
    show red bebas amused at center with dissolve:
        yoffset 330
    red cowo cling "确保没人在巡逻大门。"
    show red frown -cling
    "塞恩悄悄地侦察着桥梁。他这么做时，眼睛闪烁着明亮的红光。"
    red wry "很好。我们安全了。"
    scene night_gate with dissolve
    play sound "sound/effects/cloth.mp3"
    "塞恩拿出一瓶血药水，一口气喝完，然后脱下外套扔给你。"
    scene bat with dissolve
    galleryunlock bat
    red "好了，跳上来。"
    show side_p k at pic
    mc "哇！"
    hide side_p
    "蝙蝠般的翅膀从塞恩的背部伸出。他的眼睛闪烁着深红色的光芒，翅膀大得足以将你整个包裹。"
    "当你静止不动，被塞恩的新形态迷住时，你注意到他的眼睛开始四处扫视。很快，他的脸上露出了担忧的表情。"
    red "糟糕。我能闻到迪特里希的血腥味就在附近。我们得快走，快！"
    scene night_gate with dissolve
    show side_p sdh at pic
    mc "快？我不——等等！"
    play sound "sound/effects/woosh.mp3"
    scene star_line with flashbulb:
        yalign 1.0 
        easein 3.0 yalign 0.0
    show side_p k at pic
    mc "哇啊啊！！！"
    hide side_p
    "毫无预警地，塞恩将你抱在怀里，纵身跃入空中。"
    "你在他的怀里挣扎，尖叫声回荡在夜空中。"
    play sound "sound/effects/woosh.mp3"
    scene square_night with fade
    play sound "sound/effects/bump.mp3"
    "当你终于落地时，你忍不住狼狈地瘫倒在地上。你从未如此感激能触摸到碎石。"
    show side_p sdh at pic
    mc "大地。亲爱的大地。"
    hide side_p
    show red bebas amused apa at center with dissolve:
        yoffset 330
    if "mey_kill" not in my_events:
        red "哎呀，抱歉伙计。看来你还不习惯飞行，是吧？"
    else:
        red "伙计，你还好吗？这肯定不是你第一次飞行吧，对吧？"
        red sad "我是说，别告诉我你在你的世界里从未飞过。那太可悲了。"
    show red wry -apa
    if "mey_kill" not in my_events:
        show pboy s at horzappear
        menu:
            "其实当时我暗自很紧张。":
                hide pboy
                show red frown shock
                show side_p mal at pic
                mc "实际上，我一直都不喜欢飞行。这段时间我只是为了面子才假装没事。"
                show side_p g
                mc "（我有恐高症。不知道[povname]是否也有同感，但我绝对不想再经历一次。）"
                hide side_p
                red ngeles sweat -shock "等等，真的吗？哎呀，你怎么不早说？如果我知道的话，就不会带你飞来这里了。"
                show red sad -sweat
                show side_p ha at pic
                mc "没事。话说回来，呃...你的惊喜到底是什么？"
                hide side_p
                red laugh shock "哦，对了。来吧，我带你去看看我发现的新餐厅。"


            "装作很酷":
                hide pboy
                show side_p g at pic
                mc "哦，是啊，是啊。你知道，我只是...只是在地上放松。比如，哇，这里的石头工艺真漂亮，还有星星，是啊。"
                hide side_p
                $ mrh.points += 5
                show red amused apa
                "你躺在地上，像海星一样伸展开四肢，就在街道中央\'看星星\'。"
                "管塞恩或其他路人是否觉得你是个怪人呢。你需要感受大地，该死的。"
                red wry -apa"嗯。"
                "出乎意料的是，塞恩竟然也躺在了你旁边。显然周围的行人也没有打扰到他。"
                red laugh "你说得对，今晚的星星很美。"
                red awkward sweat "不过，我觉得我们不应该在繁忙的街道中央看星星。来吧，让我带你去看我的惊喜。"
                show side_p fr at pic
                mc "等等，那不是惊喜吗？"
                hide side_p
                red hister -sweat shock"哈哈，不是。我是说，你现在已经和我一起飞过很多次了。来吧，我带你去看看我发现的新餐厅。"
    else:
        show side_p fr at pic
        mc "那完全不一样！"
        hide side_p
        red hister blush "好吧，抱歉。来吧，我会补偿你的。"
    stop music
    jump redresto
label redresto:
    scene bg_black with w20
    scene izakaya with w20
    play music "MUSIC/MusMus-BGM-136.mp3"
    $ NPC = "工作人员"
    play sound "sfx/bell.mp3"
    npc "阿瓦雷因！"
    show red bebas grin bloom at center with dissolve:
        yoffset 330
    red "阿瓦里切！"
    show side_p fr at pic
    mc "一家寿司餐厅？"
    hide side_p
    red mock cling "不是普通的寿司餐厅！"
    red sayang -cling "这里的工作人员都是来自莫洛纳的吸血鬼。他们供应血棒棒糖、血酒、生肉寿司，应有尽有！"
    red amused "哦，当然，他们也供应正常的人类食物！"
    red laugh "我可不会让你只是来看着我吃东西。那太奇怪了。"
    if "mey_kill" in my_events or "help_study" in tom_events:
        red wry "这里的食物真的很好吃，而且物有所值，我发誓！"
    else:
        red amused "不过无论如何，今晚我请客。所以别担心账单，我来付！"
        red cowo blush "而且我终于可以和你一起吃饭了，这不是很好吗？"
        red grin "我终于不用再假装玩弄食物，看着你们在餐厅大快朵颐了。"
    show red amused -blush
    show pboy s at horzappear
    menu:
        "这太棒了，塞恩！":
            hide pboy
            $ mrh.points += 5
            red cowo blush bunga "对吧？对吧？？？我就知道你会喜欢的！"
            red -blush grin "来吧，我们坐下吧！"
        "你本可以早点带我来这里的。" if "mey_kill" not in my_events:
            hide pboy
            red amused apa "嗯。我真的可以吗？"
            show side_p fr at pic
            mc "这是什么意思？"
            hide side_p
            red sayang -apa "这意味着我以为你不太喜欢我。"
            show side_p fr at pic
            mc "啊？为什么会这样？"
            hide side_p
            red lelah frusta "我是说，拜托。我虽然迟钝，但还没有迟钝到那种程度。"
            red amused sigh "你总是和奎尔或阿什姆一起玩，但你从来没有邀请过我，就我们两个人。"
            red wry -sigh "但我理解。你认识阿什姆多久了？九年？"
            red datar "你认识奎尔的时间甚至比那更长。在你眼里，我就像个陌生人。"
            red sayang "我本想等你先主动，因为我知道你对自己的空间很在意。"
            if "blood1" in completed_quests:
                red cowo cling "但你给我做了那瓶血药水，这一定意味着你其实是喜欢我的，对吧？"
            elif "date_1" in red_events:
                red cowo cling "但你给了我一瓶血药水。这一定意味着你其实是喜欢我的，对吧？"
            else:
                red cowo "但你是主动邀请我出来的，所以你一定比我想象的更喜欢我，对吧？"
            show side_p ha at pic
            mc "嗯，当然。"
            show side_p g
            mc "（至少，\'我\'是这样的。）"
            hide side_p
            $ honesty += 5
            red datar -cling "嘿嘿，太好了！总之，来吧，别说了，我们去吃点东西吧！"

        "你确定要这样吗？" if "blood1" in completed_quests or "date_1" in red_events:
            hide pboy
            red kaget sweat apa"嗯？等等，你不喜欢这个地方吗？"
            show red sad -apa -sweat 
            $ mrh.points -= 10
            if mrh.points <0:
                    $ mrh.points = 0
            show side_p sdh at pic
            mc "不是这样的，我是说请我吃晚餐。"
            hide side_p
            red happy "哦！没关系，这是我至少能做的。"
            if "mey_kill" not in my_events:
                red amused sigh "我知道你比我富裕得多，但我也不是一贫如洗。"
            $ kindness += 5
            red wry -sigh "来吧，别说了。我们赶紧大吃一顿吧！"
    scene sushi_counter with dissolve
    "塞恩把你拉到了最近的空桌子前。"
    "当你在寿司吧台找到位置时，厨师向你们打招呼。"
    $ NPC = "厨师"
    npc "阿瓦雷因！"
    show red bebas laugh bloom at left with dissolve:
        yoffset 330
    red "阿瓦里切！"
    if not girl:
        show palmierproxy jln frown with dissolve:
            xalign 0.8
    else:
        show palmierproxy jln frown shock with dissolve:
            yoffset 90
            xalign 0.8
    show palmierproxy confused tanya
    npc "啊！泽尔科夫乌恩斯瓦亚，莫洛纳？"
    show red cowo shock
    red "沃特克，维斯特\'啊泽恩拉。泽尔科夫尼尔希拉德。"
    npc "阿里亚！维莱特阿姆？"
    show red hister -shock
    red "瓦斯蒂兹！"
    show red datar 
    "寿司厨师向你竖起大拇指，然后转身背对着你，伴随着响亮的切割声切鱿鱼。"
    mc wry sweat sigh "对不起，你说什么？"
    red wry -sigh "啊，抱歉。有时用母语说话感觉很好。"
    show palmierproxy frown -sigh -sweat
    mc kind "吸血鬼语？"
    red calm "哈哈，是的。"
    red sayang "虽然它的正式名称是奥斯库里语。只有莫洛纳和沃特克的人才会说这种语言。"
    red happy "在这里听到员工说这种语言真好。"
    red amused sigh "在学校，我只能和维尔科娃女士用这种方式交谈，你知道她有多健谈。"
    red hister -sigh "总之，我给你点了些鱿鱼寿司，因为我知道你会先点这个。"
    red grin "鱿鱼是你最喜欢的，对吧？尤其是炸鱿鱼圈。每次学校有这道菜，你总是第一个去拿。"
    show red datar
    mc deject "（我确实很喜欢鱿鱼，但是...）"
    show pboy s at horzappear
    menu:
        "我想吃点别的。":
            hide pboy
            mc wry "他们有芥末腌制的章鱼，我也想点那个。"
            show red cowo
            red "哦，没问题。包在我身上，我请客！维尔莱希克，奥克托维谢布！"
            show red datar
            npc "维恩！"

        "你呢？":
            hide pboy
            $ mrh.points += 5
            show palmierproxy kind
            red wry "哦，别担心，我马上就点。"
            red cowo blush -sigh "Verlaishic, juriesh zanah!"
            show red datar -blush
            npc "维恩！"
        "我有那么明显吗？" if "mey_kill" not in my_events:
            hide pboy
            show palmierproxy confused
            red calm "只是你的饮食习惯。不过，自从你分手后，这也改变了。"
            show palmierproxy frown shock
            red wry sigh "你知道吗，我其实一直在担心你。"
            show palmierproxy side -shock
            red bingung -sigh "你几乎不吃东西，午休时间都在抽烟。"
            red wry "幸好看起来你在奎尔那里又长胖了。而且，我一根烟都没看到，太棒了！"
            show palmierproxy frown 
            "在你说话的时候，厨师把你的寿司端了出来。"
            npc "Morlain！"
            red cowo "Zir！"
    show red datar
    mc happy tanya "你介意什么时候教教我吗？"
    show palmierproxy -tanya
    red wry sigh "奥斯库里语？当然，我很乐意！不过我得提醒你，在伊格尼亚这里用处不大。"
    red bingung -sigh "这个国家除了吸血鬼，没人会说，所以大概只有20人？顶多了？"
    show red frown
    mc apa "哇，只有这么少吗？"
    show palmierproxy frown
    red sayang "说实话，不是很多吸血鬼会冒险来到世界的这一边。阳光太多了。"
    red ew frusta "当然，我们已经进化到能够忍受它，但有时候还是太亮了，让人不舒服。"
    red wry -frusta "我时不时会从迪特里希先生那里买些精灵精华，以更好地抵御阳光。"
    show red frown shock
    mc side"真的吗？那你为什么搬到这里来？"
    show palmierproxy frown
    red mls frusta "哈哈哈！把它称为\'搬家\'有点夸张了，不是吗，[povname]？"
    red mock cling "不过，这是另一个时候的故事了。"
    red cowo shock "哦嘿，我的食物来了！"
    show red sayang bunga
    "塞恩避开了这个话题，把全部注意力都集中在了他的盘子上。"
    "塞恩刚才的话中有些东西引起了你的兴趣。"
    "塞恩是被迫搬到这里来的吗？"
    "如果你玩得好，他可能会对你稍微敞开心扉。"
    $ mrh.dates = 1
    $ quick_menu = False
    hide screen cal
    $ daterp = 30
    $ turnsleft = 3
    $ skinshiparea = ""
    $ config.rollback_enabled = False
    $ renpy.block_rollback()
    $ datingplace = "sushi1"
    $ datingname = "塞恩"
    scene sushi_counter with dissolve
    jump startdate
    


label reddate_1_closing:
    $ quick_menu = True
    $ renpy.block_rollback()
    $ config.rollback_enabled = True
    show screen cal
    scene sushi_counter with dissolve
    if not girl:
        show palmierproxy jln frown shock with dissolve:
            
            #yoffset 100
            xalign 0.8
    else:
        show palmierproxy jln frown shock with dissolve:
            yoffset 90
            xalign 0.8
    show red bebas so apa at left with dissolve:
        yoffset 330
    red "...你知道我明白你在做什么，对吧？"
    show red amused -apa
    mc malu tanya "嗯？"
    show palmierproxy frown -tanya
    red mock sigh "让我放松警惕，这样你就可以问我的过去。我告诉你，这是不可能的。"
    red sayang -sigh "不管你现在有多迷人。"
    mc "你觉得我迷人？"
    red amused "你确实迷人，在你需要的时候。通常是当你想要什么的时候。"
    red happy "这招可能对别人有用，但对我没用，[nickname]。所以就此打住吧，让我们好好享受剩下的夜晚，好吗？"
    mc sad "好吧。抱歉如果我让你感到不舒服了。"
    red amused sigh "没关系，当我决定成为你的朋友时，我就知道自己会遇到什么。"
    red cowo blush bunga "你和那两个怪人。"
    mc happy "嘿，能认出怪人的人本身就是怪人！"
    show red amused  
    show palmierproxy hister blush
    $ renpy.pause()
    scene sushi_counter with fade
    if "blood1" not in completed_quests and "date_1" not in red_events:
        if gold >= 10:
            if gold >= 50:
                $ gold -= 50
                "你保持轻松的氛围，吃寿司吃到塞恩不得不背着你出去。"
                jump vomit
            else:
                $ gold -= 10
                "你保持轻松的氛围，安静地吃着寿司。你没有再点别的东西，因为你没有钱这么做。"
                jump no_vomit
        else:
            "你很穷，所以没有再点别的东西。塞恩最后为你点的那盘买了单。"
            jump no_vomit
    else:
        "你保持轻松的氛围，吃寿司吃到塞恩不得不背着你出去。"
        jump vomit
label no_vomit:
    stop music
    play sound "sound/effects/wush.mp3"
    scene star_line with flashbulb:
        yalign 1.0 
        easein 3.0 yalign 0.0
    "不幸的是，除了和塞恩一起飞回学校，你别无他法。"
    $ red_events.append("date1_done")
    "在塞恩飞你回学校宿舍的整个过程中，你都闭着眼睛。"
    jump jaga_jaga
label vomit:
    stop music
    play sound "sound/effects/wush.mp3"
    scene star_line with flashbulb:
        yalign 1.0 
        easein 3.0 yalign 0.0
    "当他飞你回学校时，你强忍住想呕吐的冲动..."
    $ red_events.append("date1_done")
    "...没用。"
    show side_p sdh at pic
    mc "塞恩，我要——呕！"
    hide side_p
    scene bg_black with w20
    play sound "sound/effects/splash.wav"
    show side_r bebas sad at pic
    red "呀啊啊啊！"
    hide side_r
    "在你清理完之后，塞恩把你带回了你的房间。"
    jump jaga_jaga
    
    

########LYALL EVENTS
label buff_date_check:
    
    if "date1_done" not in buff_events and "anak_hilang" not in fia_events and "day4_end" in my_events:
        jump buff_date1
    elif "date2_done" not in buff_events and putri.points >= 30 and "festies" in my_events and "anak_hilang" not in fia_events:
        jump buff_date2
    elif "bunga_time" in buff_events and "date3_done" not in buff_events and putri.points >= 50:
        jump buff_date3
    
    else:
        #BERUBAH            
        
        if calendar.weekday == "Sat" or calendar.weekday == "Sun":
            scene jurney with dissolve
            $ datingplace = "bebas"
        elif datingplace == "Malam":
            scene teras_mlm with dissolve
            $ datingplace = "sklh"
        else:
            scene fishing with dissolve
            $ datingplace = "sklh"
        hide screen cal
        $ quick_menu = False
        $ daterp = 40
        $ turnsleft = 3
        $ skinshiparea = ""
        $ config.rollback_enabled = False
        $ renpy.block_rollback()
        $ datingname = "莱尔"
        jump startdate
        #berubah
label buff_date1:
    if "desa" not in buff_events:
        buff talk apa "你去过莱纳尔吗，[povname]？"
        show buff datar -apa at right with move
        if girl:
            show palmierproxy chill frown at left with moveinleft:
                yoffset 40
        else:
            show palmierproxy chill frown at left with moveinleft:
                yoffset 100
        if "date2_done" in tom_events or "date2_done" in quil_events:
            mc wry -tanya "去过几次。"
            buff amused "只有一对夫妇吗？"
        else:
            mc confused tanya "那个渔村？"
            mc frown -tanya "不，还没有。"
            buff sad "真的吗？尽管你在这里待了这么多年，却一次都没去过？"
        mc ew sweat "（哦对了，作为一个高年级学生，我想我不应该对那个地方感到陌生...）"
        mc scratch ha "哦，我不太喜欢在校园外闲逛。"
        show palmierproxy frown shock
        buff sad frusta "哦，呃...我猜你对我们去那里不感兴趣，是吗？"
        mc chill kind -sweat -shock "哦，你想带我去莱纳尔吗？"
        show buff datar blush -frusta
        "莱尔羞怯地点了点头。"
        if "buff_kerja" not in buff_events:
            $ buff_events.append("buff_kerja")
            buff talk "我不知道是否已经告诉过你，但我现在在为派克工作。"
        
        buff touched -blush "我需要帮派克运送一些货物进出城镇。我可以用得上帮手。"
        mc smile "哦，当然，我会帮忙的。不过别期望太多。我已经很久没有锻炼了。"
        buff amused sigh "没关系的。如果有什么的话，我很感谢有人陪伴。莱纳尔的人很友好，但年长的渔民们仍然用奇怪的眼光看我。"
        mc eiden tanya "等等，所以你只是需要一个朋友和你一起受罪？"
        buff sad sweat frusta "啊，好吧，当你这么说的时候..."
        "莱尔缩成一团，似乎在纠结是想要你的陪伴还是要让你免受不愉快的经历。"
        "尽管你很喜欢看他坐立不安的样子，你还是决定结束他的痛苦。"
        show buff wry -sweat shock
        mc happy blush bunga "嘿，我只是开玩笑的。带路吧，莱尔。"
        buff laugh blush bloom "好的，谢谢你。"
        "莱尔从码头上解开一艘小船，向你伸出手来帮你登上这艘小船。"
        stop music
        play music "MUSIC/MusMus-BGM-097.mp3"
        scene kapal with dissolve
        play sound "sound/effects/splash.wav"
        "你握住他的手，舒适地坐在船里。莱尔用力划船，桨划水的声音随着他的动作响起。"
        show buff datar at right with dissolve:
            yoffset 770
        if girl:
            show palmierproxy chill kind at left with dissolve:
                yoffset 40
        else:
            show palmierproxy chill kind at left with dissolve:
                yoffset 100
        if "date2_done" in tom_events or "date2_done" in quil_events:
            buff laugh "你尝过莱纳尔的猪肉吗？真的是美味极了。"
            buff datar blush bunga "他们的派也很棒！詹姆森太太做的香蕉奶油派是最好的。"
            mc confused tanya "詹姆森太太？有这样一家店吗。"
            show palmierproxy frown -tanya
            buff talk shock "哦，詹姆森太太并不拥有面包店之类的。"
            buff wry -blush -shock "她只是一位喜欢每周一分发派的老太太。"
            mc kind "嗯，我不知道这个。你一定和当地人很熟悉。"
        else:
            mc confused tanya "莱纳尔离这里有多远？"
            show palmierproxy kind -tanya
            buff datar -blush -bloom "只有几英里远。真的很近，但同时也很隔绝。"
            buff frown "那里的人...他们对巫师一无所知，但更害怕美人鱼和海妖。"
            buff "海妖有时会以鸟的形态飞过这个地区，美人鱼偶尔会出现在岸边，尽管它们从未靠得足够近以造成任何伤害。"
            buff hister "那里很美。从远处看，这个地方确实看起来相当荒凉。不知什么原因，植被似乎在那里生长得不太好。"
            buff wry "不过，他们的猪肉确实美味。"
            mc wry "你听起来像个当地人。"
        buff talk "派克带我四处转了很多。他正在村里等我们。他已经把大部分货物打包好了。"
        scene pulau with flashbulb
        buff laugh "看，我们快到了！"
        if "date2_done" in tom_events or "date2_done" in quil_events:
            pass
        else:
            "你转身看到前方的小岛，被山丘和郁郁葱葱的秋叶树环绕。"
            mc "真美啊。"
            buff "我知道。"
        scene labuh with dissolve
        "莱尔发出一声响亮的咕哝声，然后将船停靠在码头附近。如果不是一只温暖的手挡住了冲击，你的头几乎要撞到木制码头了。"
        $ NPC = "???"
        show marg at center with dissolve:
            yalign 1.0
        npc "小心点，莱尔！"
        "一位三十多岁的曲线优美的女性向你露出温暖的微笑。即使只是短暂的一瞥，你也能看出这个女人和派克有某种关系，可能是女儿或侄女。"
        if "ker_bar" in buff_events:
            "派克就在她身后，他的右臂被紧紧地固定在吊带里。"
        $ NPC = "玛格丽特"
        hide marg with dissolve
        show buff datar at right with dissolve:
                yoffset 770
        if girl:
            show palmierproxy chill kind at left with dissolve:
                yoffset 40
        else:
            show palmierproxy chill kind at left with dissolve:
                yoffset 100
        buff talk blush "你好，玛格丽特。"
        $ buff_events.append("desa")
        $ buff_events.append("date1_done")
        "莱尔害羞地向她打招呼，走出船，脸颊泛着粉红色与她握手。"
        mc scratch panik "（所以这就是他喜欢的类型？熟女？）"
        show palmierproxy chill frown shock
        npc "莱尔！孩子们都在问起你。他们想你了。"
        buff hister "啊，抱歉我最近没怎么去孤儿院。"
        buff datar "学校真的让我忙得不可开交。"
        npc "哦，当然亲爱的，别担心，教育第一嘛。"
        npc "不过，我很高兴知道你在村子外交到了朋友。"
        npc "小家伙，你叫什么名字？"
        buff talk -blush "哦。这是我的室友，[povname]。"
        show buff datar
        npc "玛格丽特。很高兴认识你，宝贝。莱尔的朋友就是我的朋友。"
        "她紧紧握住你的手，热情地握了握，然后带着浓厚的兴趣仔细检查你的手背。"
        npc "你的皮肤有点苍白，不是吗？亲爱的，你应该多晒晒太阳。"
        npc "如果你有空的话，我那群孩子会很乐意和你一起玩，让你多在阳光下活动活动。"
        buff "啊，孩子们今天怎么样？没有人跑掉吧？"
        mc "跑掉？"
        npc "哦，孤儿院的孩子们有时会失踪。但他们通常过一段时间就会回来。叛逆的青少年，你懂的。"
        mc "哦，这是经常发生的事吗？"
        $ NPC = "玛格丽特"
        npc "在莱纳尔这里是的。我亲自试过让教会介入，但他们从不听我们这个小岛上的人说话。"
        npc "我听说史密斯家运气好些，因为他们的女儿也失踪了，但她的朋友们认为她私奔了。"
        npc "14岁就私奔，这不是更可怕吗？天哪！"
        buff keluh sweat "凯拉，对吧？我也不觉得她是那种会私奔的类型。"
        buff "哦，虽然她的父母告诉我不要这么做，但我还是向校长求助了，可他只说会联系教会。"
        buff sad sigh "对不起。"
        npc "哦，不，你为什么要道歉呢？有时候事情就是这样发生的，亲爱的。"
        show buff wry -sweat
        npc "话说回来，[povname]，是吧？你试过亚麻籽油吗？它真的能加快晒黑的速度。"
        npc "你的皮肤会很快变得有活力的。"
        mc ow sweat shock "啊，不，你不需要那样做，哇——！"
        play sound "sound/effects/cloth.mp3"
        scene desa_center with dissolve
        "玛格丽特用力一拉，把你拽进了村子，莱尔跟在后面。"
        play sound "sound/effects/tile.mp3"
        $ NPC = "女孩"
        show kid1 at left with dissolve:
            yalign 1.0
        npc "快来，表演马上就要开始了！"
        show kid2 at right with dissolve:
            yalign 1.0
        npc "啊，等等我！"
        stop sound
        show har at center with dissolve
        "当你走近村庄时，你看到一群孩子围着一个矮小却引人注目的男人，他脸上戴着一副大眼镜。"
        "那个男人举着玩具木偶，几十个孩子乖巧地坐在他周围。"
        "欢快的音乐开始播放，一个女人的录音声音响起，为这个场景进行解说。"
        show side_p f at pic
        mc "木偶戏？"
        hide side_p
        $ NPC = "玛格丽特"
        npc "哦，是的！那是欧文。他在这里很受孩子们欢迎。"
        npc "他是个外来者，但他已经在我们村子里待了将近三个月了。"
        npc "他说他在这里寻找草药来治疗他的病症。"
        show side_p f at pic
        mc "病症？"
        hide side_p
        npc "这个可怜的小伙子是个哑巴。"
        show side_p f at pic
        mc "哦。有草药可以治好这个吗？"
        hide side_p
        npc "嗯，他是这么说的。他来自卡斯特里，所以他们的医学知识比我们先进得多。"
        npc "我决定不去质疑，反正我也不太懂这些。"
        $ NPC = "女孩"
        hide har with dissolve 
        show buff laugh bloom at center with dissolve:
            yoffset 770
        npc "哦，是莱尔！嘿，史蒂夫，是莱尔！"
        "当莱尔出现时，大多数孩子都离开了表演，转而围着莱尔，要求被抱起来。莱尔满足了他们的要求。"
        "他一个接一个地抱起他们，然后让三个小孩爬上他的肩膀和头顶。"
        "从眼角余光中，你可以看到欧文对这种情况很不高兴，因为他的表演只剩下一两个观众了。"
        "有一个孩子引起了你的注意，你可以看出他显然是个盲童，正用他朋友的手引导他走向人群。"
        $ NPC = "史蒂夫"
        hide kid1 with dissolve
        show kid_blind at left with dissolve:
            yalign 1.0
        npc "我听到莱尔在笑，他真的在这里吗？"
        $ NPC = "女孩"
        npc "是的，他在这里。而且他带来了一个朋友！蓝色的那个！"
        show side_p se at pic
        mc "（蓝色的，是因为制服吗？）"
        hide side_p
        scene desa_center with dissolve
        show kid1 at center with dissolve
        npc "蓝色！"
        "一个小孩指着你，同时伸出双臂向天空示意要被抱起来。"
        show buff kzl cling at right with dissolve:
            yoffset 770
        "莱尔警惕地看着你，好像他担心你会对孩子做什么。"
        show pboy at horzappear
        menu:
            "抱起孩子":
                hide pboy
                if girl:
                    show palmierproxy chill wry blush bunga at left with dissolve:
                        yoffset 40
                else:
                    show palmierproxy chill wry blush bunga at left with dissolve:
                        yoffset 100
                npc "耶！"
                $ kindness += 5
                $ honesty -= 10
                show buff laugh bunga
                hide kid1 with dissolve
                "当你上下颠着她时，孩子兴奋地尖叫起来。"
                mc hister "（这里的孩子们太没有防备心了。你知道吗，我可以轻易绑架你。）"
                buff wry sigh "在这里每个人都认识彼此，所以他们不知道要提防。"
                mc apa shock "哦..."
                mc scratch panik sweat -shock "（我把那部分说出声了吗？）"
                show palmierproxy chill kind -sweat
                "你给那个女孩快速转了一圈后，把她放回地上。她兴奋地笑着，然后加入其他孩子玩捉迷藏游戏。"
            "揉揉她的头发":
                hide pboy
                if girl:
                    show palmierproxy scratch wry at left with dissolve:
                        yoffset 40
                else:
                    show palmierproxy scratch wry at left with dissolve:
                        yoffset 100
                $ honesty += 15
                $ kindness -= 5
                mc "我恐怕没有莱尔那么强壮，孩子。"
                mc eiden sweat "我觉得我试着把你抱起来可能会拉伤肌肉。"
                show palmierproxy frown shock
                npc "哦...所以你又弱又老？"
                show buff wry sigh
                mc chill kzl sweat frusta "（这个调皮的小鬼—）"
                buff talk -sigh "我只是比大多数人强壮一些，西西。来，骑到我肩膀上吧。"
                $ NPC = "西西"
                npc "耶！"
                hide kid1 with dissolve
                show buff laugh blush bunga 
                show palmierproxy wry -sweat -frusta
                "莱尔抱起西西开始旋转。西西兴奋地笑着，然后莱尔把她和其他孩子一起放下。"
                $ NPC = "玛格丽特"
                npc "好了，够了，让大人们工作吧，好吗孩子们？"
                $ NPC = "孩子们"
                npc "好的，玛格丽特夫人！"
                "玛格丽特催促他们自己玩，他们散开玩起了捉迷藏。"
            "走开":
                hide pboy
                if girl:
                    show palmierproxy chill frown at left with dissolve:
                        yoffset 40
                else:
                    show palmierproxy chill frown at left with dissolve:
                        yoffset 100
                $ honesty += 5
                $ curiosity -= 5
                $ kindness -= 15
                mc deject sigh "（我不会跟陌生人的孩子胡闹。）"
                "当你无视她时，孩子哭了起来。显然她不习惯这样的冷漠。"
                buff talk "来，我抱你起来，西西。"
                show buff laugh blush bunga
                hide kid1 with dissolve
                "莱尔抱起西西开始旋转。西西兴奋地笑着，然后莱尔把她和其他孩子一起放下。"
                $ NPC = "玛格丽特"
                npc "好了，够了，让大人们工作吧，好吗孩子们？"
                $ NPC = "孩子们"
                npc "好的，玛格丽特夫人！"
                "玛格丽特催促他们自己玩，他们散开玩起了捉迷藏。"
        mc chill happy blush tanya "你在这里很受欢迎啊，是不是？"
        show buff wry blush shock
        "莱尔听到这话脸上露出了灿烂的笑容。"
        show buff hister bloom
        buff "这里的孩子们不知道巫师的事，他们不怕我的眼睛。"
        show palmierproxy frown
        buff wry sigh "我想这也是欧文留在这里的原因。虽然我不太确定他是什么。"
        buff eh -blush apa "他不是巫师，至少我不这么认为，但...也许他和我一样是个混血儿？"
        show buff frown -apa
        mc confused -tanya "欧文？那个木偶戏演员？"
        buff eh "是的，他的眼睛很特别。"
        show har at center with dissolve:
            yalign 1.0
        "你毫不掩饰地扭头看向欧文，注视着他的眼睛，发现它们有一种独特的彩虹色调。"
        show har confused apa
        "欧文注意到你的注视，歪了歪头，在他的书上写了一个大大的问号，然后展示给你看。"
        mc side both shock "啊对不起，我不是有意盯着看的！"
        play sound "sound/effects/walk.mp3"
        scene pasar with dissolve
        "你和莱尔尴尬地低下头，走向派克和玛格丽特等待的市场，向当地人打招呼。"
        show side_p f at pic
        mc "（我感觉我以前见过他的眼睛，但在哪里呢？）"
        hide side_p
        show buff frown at right with dissolve:
                yoffset 770
        if girl:
            show palmierproxy chill kzl shock at left with dissolve:
                yoffset 40
        else:
            show palmierproxy chill kzl shock at left with dissolve:
                yoffset 100
        play sound "sound/effects/bump.mp3"
        "当你陷入沉思时，莱尔开始一箱接一箱地把鱼递给你。"
        "你没料到会有这么重的负担，吓得往后缩了一下。"
        mc ow sweat frusta "哎哟！"
        buff keluh sweat apa "哦，抱歉，是不是太重了？"
        show pboy at horzappear
        menu:
            "你要把我累死了！":
                hide pboy
                $ honesty += 10
                $ curiosity -= 10
                buff sad shock "啊，抱歉！"
                show palmierproxy wry sigh
                "莱尔一个接一个地从你手中拿走重物。这些重量似乎并没有让他感到太困扰。"
                
            "不，我没事。（谎言）" if not girl:
                hide pboy
                $ honesty -= 10
                $ curiosity -= 10
                show palmierproxy smile
                buff eh "...你确定吗？"
                mc happy "哈！当然了。"
                mc panik sigh "（我是说，我得表现得很酷，如果我不至少搬一半他搬的东西，我看起来就像个彻底的懦夫！）"
                buff wry -sweat sigh "好吧，如果你需要帮助就告诉我。我知道我比大多数人都强壮。"
                mc smile frusta "我也一样，快走吧！继续前进！"
                play sound "sound/effects/crash.mp3"
                scene pasar with vpunch
                "你只走了四步就掉了一半的箱子，莱尔在它们落地前全都接住了。"
                "你道了歉。莱尔只是对这个意外笑了笑，从你手中拿走了几个箱子，你们俩并肩走回码头。"

            "我们不能用符文吗？！":
                hide pboy
                $ curiosity += 10
                mc ew frusta "我们没有任何符文可以帮忙吗？风符文怎么样？"
                buff datar -sweat shock "哦，实际上，我想我们可以让它起作用。"
                show palmierproxy frown shock
                show buff laugh
                "放下一两个桶后，莱尔开始在箱子上画风符文。"
                play sound "sound/effects/swosh.mp3"
                show buff wry sigh
                show palmierproxy kind blush -shock
                "箱子一个接一个地开始漂浮起来，这让你更容易把它们引导到船上。"
                mc hister bloom "我爱魔法。"
                buff laugh sigh "我也是……至少在好人手里的时候是这样。"
                show buff wry -sigh
                mc deject -blush -bloom "（啊，看来他还记得他的父亲。）"
        scene jurney with w33
        show buff datar at center with dissolve:
            yoffset 770
        "许多年轻男女都在盯着莱尔看，他走回码头的时候。"
        "也不能怪他们，他确实是一道养眼的风景。看着他的背影，你不禁觉得他更适合当个渔夫，而不是猎巫人。"
        "你想知道为什么他不干脆退学去和派克一起工作。"
        "说起来，莱尔是怎么进入你们学校的呢？"
        "关于你的室友，有太多你不知道的事情。有太多谜团等待揭开。"
        buff talk apa "准备好出发了吗？"
        show buff datar -apa
        "他的问题把你拉回现实。"
        if girl:
            show palmierproxy chill confused at left with dissolve:
                yoffset 40
        else:
            show palmierproxy chill confused at left with dissolve:
                yoffset 100
        show buff frown at right with move
        mc "啊……好的？"
        buff amused "听起来像个问句。你在想什么吗？"
        show buff datar
        mc deject "嗯……"
        show pboy at horzappear
        menu:
            "你为什么要当猎巫人？":
                hide pboy
                mc apa tanya "我是说，你为什么要进入这所学院……你是半巫师。"
                show palmierproxy confused
                buff sad sweat frusta "这其实不是我的选择。在逃离我父亲之后，我跑到了最近的城镇。"
                buff keluh sigh "那就是这里，伊格尼亚。镇上的人决定我应该通过成为猎巫人来证明我的忠诚。"
                buff frown -sweat -sigh "作为交换，他们会把我当作教会的孤儿来照顾。"
                mc kzl cling "我明白了，所以他们威胁你？"
                buff keluh sweat shock "不是那样——"
                mc rajuk tanya "他们给你其他选择了吗？"
                buff sad sigh "嗯，他们确实说我可以离开去卡斯特里，但他们可能会在那里把我当奴隶卖掉，所以——"
                mc kzl -tanya "所以他们威胁你。"
                buff keluh frusta "我学到了永远不要期待善意。尤其是如果你是个巫师的话。"
                show buff sad -frusta
                mc sad "但你也是半个人类。"

            "你属于这里。":
                hide pboy
                $ kindness += 5
                $ curiosity -= 10
                buff wry blush shock "派克也这么说。"
                buff talk -shock "我确实喜欢大海，还有园艺。虽然派克说在这片土地上做这些是没用的。"
                buff laugh bloom "不过，要是能有自己的一片土地或一条船，种植或捕捞自己的食物，那该多好啊。"
                mc happy "你确实给人一种迷人的农场男孩的感觉。很适合你。那么，是什么阻止了你？"
                show palmierproxy frown shock
                buff eh sweat apa "抱歉？"
                mc smile -shock "就退学然后成为一个农民，或者渔夫？"
                buff sad sigh "我不能，我向教会许下了承诺。"
                mc scratch confused "什么承诺？"
                buff eh -sigh "当我在这里寻求庇护时，教会告诉我，只要我通过成为猎巫人来证明我的忠诚，我就可以留下来。"
                buff frown -sweat "作为交换，他们会把我当作教会的孤儿来照顾。"
                mc apa sweat "所以你被困在这里了。"
                buff wry "至少还有四年。但没关系……只要我完成了我的部分，他们就会让我离开。"
                mc chill rajuk sigh "……你真的相信吗？"
                buff sad "嗯——"
                show palmierproxy kzl -sigh
                "莱尔之后沉默了。当然他不相信。即使是你也知道教会在骗他。"
                "在你看到这里发生的一切之后，你也能预料到这一点。"
        mc happy blush "你知道，在我来的地方，渔民和农民是非常抢手的。"
        mc smile "那里也没有巫师会来追捕你。"
        buff eh sweat shock "没有巫师？怎么可能？你住在沃特克吗？是因为这个原因吗？"
        mc scratch panik sweat "啊，不是。我住在……别的地方，但我现在还不能回去。"
        buff frown -sweat -shock "我明白了。"
        buff talk "我能和你一起去吗？"
        mc sad sweat shock "什么？"
        buff wry sigh "当你能回家的时候……我能去拜访你吗？"
        mc side -shock "哦..."
        mc frusta "（他能吗？我是说，奎尔和我甚至还没有讨论过送我回家的事。）"
        mc frown "（但是我的意思是，有洞就有路，对吧？只要通道打开，我大概就能带一个朋友。）"
        mc rajuk "（……对吧？）"
        mc chill smile -sweat -frusta "嗯……"
        show pboy at horzappear
        menu:
            "当然。":
                hide pboy
                buff hister blush apa"约定好了？"
                $ buff_events.append("pinky")
                show buff amused at center with move
                show palmierproxy apa sweat shock
                "莱尔伸出了小拇指，显然希望你能握住它。"
                "你勉强地与他拉钩。莱尔一边哼着一首熟悉的曲子，一边上下摇晃着你们的手指。"
                show palmierproxy wry sigh
                buff laugh bunga "今晚我的心敞开，尽管我的唇紧闭。"
                buff talk "承诺已经许下，真实响亮，我不会对你食言。"
                buff hister "现在这就是正式的约定了！"
                "满意地，他松开了你们的手指，笑容满面。"
                mc panik both"（啊...我的心。如此天真，如此纯洁！）"
                mc smile -sweat blush bloom"永远不要改变，莱尔。"
                buff datar -blush apa "嗯？"
                scene kapal with fade
                "心情好转的莱尔迅速划向戈莫拉，你们一路上聊着各自的钓鱼成就和分享烹饪食谱。"
                "你希望一旦这个巫师的事情结束，你真的可以带莱尔一起走。他是个好人，对这个世界来说太过温柔了。"

            "我觉得那是不可能的。":
                hide pboy
                show palmierproxy side sweat
                buff sad sweat frusta "哦，我明白了。" 
                scene kapal with fade
                "莱尔沮丧地缩回船上，专注于眼前的任务，划向戈莫拉。"
        scene riv_riv with w33
        "到达码头后，你们迅速将货物从船上搬到附近的当地人那里。"
        "一个当地人狠狠地瞪了莱尔一眼，但当你露出你那标志性的微笑时，他什么也没说。"
        "总的来说，运输进行得相当顺利，你们比预想的完成得更早。"
        "你回到宿舍，准备休息一晚。"
        stop music
        scene bg_black with w20
        play music "MUSIC/MusMus-BGM-082.mp3"
        scene lor_mlm with w20
        jump ur_room
    else:
        show buff datar at right with move
        if girl:
            show palmierproxy chill frown at left with moveinleft:
                yoffset 40
        else:
            show palmierproxy chill frown at left with moveinleft:
                yoffset 100
        buff frown apa "嗯，[povname]，你今天有多空闲？"
        mc kind tanya "我的意思是，我的日程完全开放，怎么了？"
        buff hister -apa "我在想，如果你不介意孩子的话，嗯...你愿意和我还有莱纳尔的孩子们一起玩吗？"
        if "cece" not in buff_events:
            buff amused "我知道这可能不是你喜欢的场合，但从我们上次访问的情况来看，孩子们似乎很喜欢你。"
        else:
            buff wry "你喜欢孩子吗？我知道你不太喜欢Cece，但是大一点的孩子呢？"
        show palmierproxy -tanya
        show pboy at horzappear
        menu:
            "我很乐意！":
                hide pboy
                mc laugh blush bunga "我喜欢孩子！我曾经也是个孩子。"
                buff hister blush sigh "啊哈，我也是。我很高兴你愿意参与，我相信他们会喜欢你的。"
                show palmierproxy kind -bunga 
                if girl:
                    buff wry -blush -sigh "也许青少年们这次也会加入我们。男孩们无法抗拒漂亮的脸蛋。"
                    mc mock -blush cling "你觉得我漂亮吗？"
                else:
                    buff wry -blush -sigh "也许青少年们这次也会加入我们。女孩们无法抗拒英俊的脸庞。"
                    mc mock -blush cling "你觉得我英俊吗？"
                show palmierproxy hister blush bunga
                buff lega blush bunga "...我想任何有眼睛的人都会这么认为的，[povname]。"
                buff keluh both shock "啊，嗯...总之我们应该出发去村子了！"
                show palmierproxy kind 
                buff laugh -shock "我答应过今天我们会在河边玩，嗯...来吧！"
                stop music
                scene bg_black with w20
                play music "MUSIC/MusMus-BGM-097.mp3"
                scene sungai with w20
                "一到莱纳尔，孩子们就用灿烂的笑容和伸出的小手迎接你们。"
                "当你们一起前往山中深处的河边时，他们显然对你的出现感到兴奋。"
                "水清凉透明，你和一群10岁的孩子开始玩起了捉迷藏游戏。"
                $ NPC = "女孩"
                npc "马可！"
                $ NPC = "史蒂夫"
                npc "波罗！"
                "那个失明的孩子，史蒂夫，似乎对这个游戏特别开心。也许是因为这一次他不是唯一一个被困在黑暗中的人。"
                show buff swim laugh blush bloom at center with dissolve:
                    yoffset 770
                "莱尔看起来也很享受。至于你，你只是在那里欣赏风景——"
                npc "波罗！"
                show side_p nm at pic
                mc "啊！"
                hide side_p
                "一个较大的孩子把你推倒，脸朝下栽进了河里。你的身体伴随着一声响亮的拍击声落入水中。"
                buff lega -blush apa "哈哈哈哈！你没事吧？哪里受伤了吗？"
                show side_p n at pic
                mc "只是我的自尊心受伤了。"
                hide side_p
                buff wry sigh "呵呵。过来。"
                play sound "sound/effects/splash.wav"
                "莱尔把你拉了起来，其他孩子们继续他们的游戏。"
                buff hister -sigh "对不起，孩子们有时候会有点调皮。"
                show side_p n at pic
                mc "我看得出来。不过这样挺好的，总比他们表现得胆小怯懦要好。"
                hide side_p
                buff laugh "我也这么认为。"
                $ putri.points += 5
                buff keluh sweat shock "哦，等等，停一下。你的脸颊上有个伤口，一定是被水里的小石子划到了。"
                show buff sad -shock
                "莱尔捧起你的脸，用拇指擦拭那个伤口。那只是一道浅浅的划痕，但他却像对待一个开放性伤口一样小心翼翼。"
                "他脸上写满了内疚，因为他并不想让你在这个欢乐的日子里受伤。"
                show pboy at horzappear
                menu:
                    "我要死了！":
                        hide pboy
                        show buff sad shock
                        "想要稍微利用一下这个机会，你决定发挥你戏剧社的背景。"
                        show side_p ns at pic
                        mc "我感觉头晕目眩。我是不是碰到了什么有毒的东西？哦，我看到光了！"
                        hide side_p
                        buff keluh frusta "等等，什么？！坚持住！"
                        show buff sad 
                        show side_p nf at pic
                        mc "哇！"
                        hide side_p
                        if girl:
                            galleryunlock cewe_gendong
                            show cewe_gendong with flashbulb:
                                truecenter zoom 2.0
                                easein 2.0 truecenter zoom 1.0
                        else:
                            galleryunlock cowo_gendong
                            show cowo_gendong with flashbulb:
                                truecenter zoom 2.0
                                easein 2.0 truecenter zoom 1.0
                        "莱尔毫不犹豫地将你抱起，像新娘一样抱在怀里，然后把你放在一块大石头上。"
                        buff keluh sigh "我不知道任何治疗符文，呃...我去找玛格丽特！你别动！"
                        hide buff with dissolve
                        play sound "sound/effects/tile.mp3"
                        "他大喊着跑下山坡，可能是去找玛格丽特。"
                        stop sound
                        show side_p ns at pic
                        mc "等等，我只是开玩笑——！该死..."
                        hide side_p
                        "你只能叹气，因为这种尴尬局面只能怪你自己。都怪你和你那些小把戏。"
                        if girl:
                            hide cewe_gendong with dissolve
                        else:
                            hide cowo_gendong with dissolve
                        

                    "这只是个小伤口而已！":
                        hide pboy
                        buff keluh sweat frusta "是啊，但有些石头可能有毒。等着，我去找玛格丽特！"
                        show side_p ns at pic
                        mc "等等，什——？"
                        hide side_p
                        hide buff with dissolve
                        play sound "sound/effects/tile.mp3"
                        "你惊讶地看着莱尔以破纪录的速度跑下山坡。"
                        "你感到有点傻，为了一个小伤口搞出这么大阵仗，但还是决定等着看接下来会发生什么。"
                        stop sound
                stop music
                "当你坐着等待时，你隐约听到身后传来轻柔的耳语声，与孩子们欢快的喧闹声形成鲜明对比。"
                play music "MUSIC/whisper.mp3"
                scene pathway with fade
                "出于好奇，你朝声音传来的方向走去，发现两位老太太正在附近的一处灌木丛后交谈。"
                $ NPC = "???"
                npc "他又来了，格蒂。那个混血儿。"
                $ NPC = "格蒂"
                npc "很好，我们需要他在这里。就像他希望我们做的那样。"
                $ NPC = "???"
                npc "他？"
                $ NPC = "格蒂"
                npc "我...等等，他是谁？我刚才在说什么？"
                $ NPC = "???"
                npc "我...我不知道，格蒂。我刚才在...我们在这里做什么？"
                show side_p ns at pic
                mc "（痴呆症？）"
                hide side_p
                stop music
                "真奇怪。一秒钟前你还以为这些老太太在策划谋杀什么的，下一秒她们似乎就对自己在这里做什么一无所知了。"
                "是痴呆症吗？"
                "就在你准备去帮助那对困惑的老太太时，你感觉到有一双小胖手抓住了你的大腿后侧。"
                play sound "sound/effects/bump.mp3"
                show kid_blind at center with vpunch
                "你立即惊跳起来，猛地回头，只见一个熟悉的小身影，大约只有你一半高。"
                $ NPC = "史蒂夫"
                play music "MUSIC/MusMus-BGM-CP04.mp3"
                npc "这...这是谁？\'马可\'在哪里？我逃出来了吗？"
                "感到松了一口气，知道这只是史蒂夫，可能因为只能依靠听觉而走得太远了——你决定带史蒂夫回到其他孩子那里。"
                show side_p n at pic
                mc "看来你走得太远了，伙计。来吧，我带你回到其他人那里。"
                hide side_p
                npc "哦，好的，这位又是谁？"
                show side_p n at pic
                mc "是[povname]。"
                hide side_p
                npc "哦，那个漂亮的人。我是说，至少他们都这么说。我，我其实看不出来。"
                npc "不过你的声音听起来很美。我能...我能摸摸你的脸吗？"
                show side_p n at pic
                mc "当然！"
                hide side_p
                "你蹲下身子，与史蒂夫平视，让他用手抚摸你的脸。他似乎在你的颧骨和嘴唇附近停留了一会儿。"
                npc "你的颧骨很高，头发又柔又滑。你一定很漂亮！"
                npc "但你受伤了吗？我觉得你有个伤口，还是说那是胎记？"
                show side_p n at pic
                mc "是个伤口。一个被莱尔绝对夸大其词的伤口。"
                hide side_p
                npc "哦，我听到的跑下山的声音是这么回事啊？我还以为可能是熊之类的。"
                show side_p n at pic
                mc "不是熊，只是莱尔。虽然考虑到他有多温柔体贴，我猜他也算是个泰迪熊了。"
                hide side_p
                hide kid_blind with dissolve
                show buff keluh sweat shock at center with dissolve:
                    yoffset 770
                buff "[povname]！你不该走动的！来，我把玛格丽特带来了，她应该能检查你的伤口。"
                show buff sad sigh
                $ NPC = "玛格丽特"
                show side_marg at pic
                npc "你是不是被特拉石划伤了？！那些石头有剧毒！"
                hide side_marg
                show side_p ns at pic
                mc "（等等，所以这里真的有毒石头？）"
                mc "呃...没有？"
                hide side_p
                scene sungai with fade
                "...看来你确实是被特拉石划伤了，因为你的脸颊上刚刚冒出了一些奇怪的绿色粘液。"
                "当莱尔催促孩子们离开河水以便他能找到并处理那些石头时，孩子们都在抱怨。"
                "你不知道在这整个过程中，你是被祝福还是被诅咒了。"
                "但考虑到你整天都能把头靠在莱尔的大腿上，而玛格丽特在处理你的伤口，你觉得这并不是今天可能发生的最糟糕的事。"                
            "对不起...":
                hide pboy
                $ putri.points = 0
                mc rajuk sigh "我喜欢孩子，但今天我真的没心情应付他们。"
                mc confused -sigh "（强颜欢笑，被一群小家伙包围...是的，今天不行。）"
                buff sad sweat frusta "哦，那太遗憾了。"
                buff keluh sigh "孩子们一直在问你的情况，想和你一起玩。"
                buff sad -sigh "我说我们可以一起在河里玩，但如果你不感兴趣的话，那就..."
                buff frown "实际上，我现在应该去莱纳尔了。不想让他们等太久。"
                mc happy "哦，好吧。下次再聊。"
                show palmierproxy kind 
                show buff sad sigh
                "莱尔对此耸了耸肩。很明显，他对你的回答感到失望，可能在考虑彻底切断你们的关系。"
                buff -sigh "也许吧。我们走着瞧。我...我宿舍见。"
                mc confused sweat "哦，好吧。"
                mc ew frusta "（该死。）"
        $ buff_events.append("date1_done")
        stop music
        scene bg_black with w20
        play music "MUSIC/MusMus-BGM-082.mp3"
        scene lor_mlm with w20
        jump ur_room

label buff_date2:
    stop music
    scene bg_black with w20
    play music "MUSIC/MusMus-BGM-139.mp3"
    scene bich with w20
    if calendar.weekday == "Sat" or calendar.weekday == "Sun":
        show buff bebas datar blush at right with dissolve:
            yoffset 770
        if girl:
            show palmierproxy jln kind at left with dissolve:
                yoffset 40
        else:
            show palmierproxy jln kind at left with dissolve:
                yoffset 100
    else:
        show buff datar blush at right with dissolve:
            yoffset 770
        if girl:
            show palmierproxy chill kind at left with dissolve:
                yoffset 40
        else:
            show palmierproxy chill kind at left with dissolve:
                yoffset 100
    "莱尔再次带你来到莱纳尔，这次是到码头对面的海滩。"
    mc happy blush bloom "我不知道这里有海滩。"
    show palmierproxy smile
    buff amused sigh "严格来说，这并不算是真正的海滩，因为它并不与海相连。"
    buff wry -sigh "这里的水域和我们学校周围的是同一片。伊欧之泪是伊格尼亚最大的湖泊之一，至少文恩是这么告诉我的。"
    mc rajuk tanya "文恩？"
    show palmierproxy frown -tanya
    buff datar -blush "他是当地的一个渔民。他说这是他最喜欢捕捉蓝鲱鱼的地方。"
    mc smile sigh "嗯。你真的融入当地人了，是吗？"
    buff wry "大部分是的。有些人还是有点不愿意和我交流，主要是年长的渔民，但我感觉随着我为他们工作的时间越长，他们对我的态度越来越好。"
    buff keluh "有些人认为我只有蛮力没有头脑，但我更希望被人根据我的技能而不是血统来评判。"
    mc ew frusta "啊，我猜学校里的孩子们还是不太接纳你，是吗？"
    show palmierproxy sad sweat -frusta
    if "ketemu_buli" in buff_events:
        buff keluh sweat frusta "是的，阿贾克斯和他的朋友们也没让事情变得容易。"
        show buff sad 
        mc rajuk -sweat shock "等等，他们还在骚扰你吗？因为如果是这样的话——"
        show palmierproxy kzl -shock
        buff eh shock "啊！不，不！他们保持距离，但时不时会用厌恶的眼神看我。"
        show buff sad -sweat -shock
        mc rajuk sigh "哦，别理那些白痴。"
        show palmierproxy -sigh
    else:
        buff sad sweat frusta "不，他们还是害怕。我不介意，我理解。"
        show buff -sweat -frusta
        mc confused sigh "我知道你是个很温柔的家伙，莱尔，但你不必理解，你没有做错任何事。"
        show palmierproxy -sigh
    mc wry blush "你完全无害，我怀疑你连只苍蝇都不会伤害。"
    buff amused both sigh "这...这话说得真好，[povname]。但我并不像你想象的那么无害。"
    if "bunga_time" in buff_events:
        buff keluh -both apa "你不记得我能做什么吗？"
        show buff sad shock
        mc hister sigh "你时不时会冒出一些花，那又怎样？"
        mc rajuk -blush tanya "除非你能种出其他植物，比如胡萝卜、土豆之类的？"
        show palmierproxy kind -tanya
        buff hister blush bunga "啊哈，不，恐怕只有花。"
        buff wry "你，你真的不介意，是吗？你一点也不害怕。"
        mc mean sigh "你就是你，莱尔。我才不在乎你父亲是谁呢。"
        mc happy -sigh "不过，我还是不相信你只能种出花。"
        mc smile "土豆在收获前会开花，对吧？也许经过一些训练，你就能开始长出块茎了。"
        buff laugh -bunga "就从我的手里变出土豆？那倒是个不错的把戏。"
        mc kind tanya "你试过吗？"
        buff amused both "呃，没有，但是——"
        mc laugh blush bloom "那我们就试试看吧！拜托？"
        buff hister blush sigh "好...好吧。"
    else:
        buff sad sweat -sigh "我...我想给你看点东西。"
        mc rajuk "...好的？"
    show buff sad sweat frusta
    show palmierproxy frown sweat shock
    "莱尔开始搓手，然后朝手掌吹气。"
    "你以为他冷了，就走过去，试图用自己的手包住他的手。"
    play sound "sound/effects/jelly.mp3"
    if girl:
        galleryunlock sun_f
        show sun_f with flashbulb
    else:
        galleryunlock sun_m
        show sun_m with flashbulb
    "当你的手包住他的手时，一种奇怪的光芒开始从他的手掌中散发出来。"
    buff "啊，不，等等！"
    play sound "sound/effects/grow.wav"
    if girl:
        galleryunlock sun_sadf
        show sun_sadf with flashbulb
    else:
        galleryunlock sun_sadm
        show sun_sadm with flashbulb
    "然后花朵绽放了。向日葵，比正常的要小，但完全健康，黄灿灿的……"
    "……几分钟后就枯萎了。"
    scene bich with fade
    if calendar.weekday == "Sat" or calendar.weekday == "Sun":
        show buff bebas sad at right with dissolve:
            yoffset 770
        if girl:
            show palmierproxy jln frown at left with dissolve:
                yoffset 40
        else:
            show palmierproxy jln frown at left with dissolve:
                yoffset 100
    else:
        show buff sad at right with dissolve:
            yoffset 770
        if girl:
            show palmierproxy chill frown at left with dissolve:
                yoffset 40
        else:
            show palmierproxy chill frown at left with dissolve:
                yoffset 100
    $ buff_events.append("date2_done")
    if "bunga_time" in buff_events:
        mc wry sigh "那不是土豆。"
        buff keluh sweat frusta "抱歉。我想我甚至不知道土豆花长什么样。"
        show buff sad -frusta
        mc laugh -sigh "别担心，我们下次可以再试——"
    else:
        mc shock "你能让花朵绽放……你能做到这个？"
        "莱尔羞怯地点了点头。"
        show palmierproxy sad -shock
        buff keluh sigh "与大众的看法相反，我父亲在魔法方面并不歧视我们。"
        buff sad -sigh "我的大多数兄弟在被转化之前都能长出几个自己的花蕾。"
        buff "但我们没有像姐妹们那样接受训练，也没有太多机会去探索我们的魔法。"
        buff keluh "而且我也不想要这些力量，我……我不想伤害任何人。"
        buff kzl frusta "但它们是我的一部分。来自我血统的诅咒。"
        $ buff_events.append('bunga_time')
        buff sad sigh "你……你现在讨厌我吗？我让你害怕吗？"
        show palmierproxy confused 
        show buff -sigh
        show pboy at horzappear
        menu:
            "我为什么要害怕呢？":
                hide pboy
                show buff frown sweat shock
                $ putri.points += 10
                mc wry sigh "莱尔，我为什么要讨厌你？"
                mc malu -sigh "仅仅因为你拥有你父亲的天赋并不意味着你就是他。"
                buff keluh apa "你……你真这么认为？你不害怕我会滥用这些花朵吗？"
                buff sad frusta "害怕我会像我的姐妹们对待她们所有的受害者那样伤害别人。"
                mc rajuk "你不是你的父亲，也不是你的姐妹。"
                mc happy "即使你们出身相同，也不意味着你们会走上相似的道路。"
                mc mean cling "看看菲亚和我，你觉得我们是同一种糟糕吗？不是。"
                mc laugh blush sigh "我们的父母同样伤害了我们，只是方式不同。"
                show palmierproxy kind -blush -sigh
                buff wry both sigh "啊……我……我想我明白了。"
                buff hister -both -sigh "你很坦率，不是吗[povname]？"
                mc eiden sweat "嗯，是的。"
                mc avoid sigh "（我的意思是，我只是在这里假装成另一个人，但是没错，在其他所有事情上我都百分之百诚实。）"
                mc wry -sweat -sigh "这让你感到困扰吗？我知道对有些人来说这可能有点过分。"
                buff datar blush "不，我……我喜欢这样。"
                buff amused "这意味着当你说你不害怕我时，你是诚实的。我……"
                buff laugh bloom "我很高兴向你展示了这个，[povname]。"
            "有一点。":
                hide pboy
                $ putri.points = 0
                show buff keluh sweat shock
                mc ew sweat frusta "（如果他能做伊瓦尔能做的事，有什么能阻止他变成那个人呢？）"
                show palmierproxy sad -frusta
                "你可以看到莱尔的身体因你的承认而颤抖，他的眼睛四处乱瞟，仿佛在寻找逃跑的方法。"
                buff sad frusta "我-我明白了。对不起！我不该向你展示那个的。"
                buff keluh "请-请不要告诉任何人，我——"
                buff sad sigh "忘了这件事吧！"
                hide buff with moveoutright
                show palmierproxy frown shock at center with move
                mc kzl frusta "莱尔！"
                "莱尔因为你的拒绝而恐惧地跑开了，他手掌中的花朵沮丧地落在沙滩上，然后消失在水中。"
                $ buff_events.append('reject')
                scene bg_black with w20
                play music "MUSIC/MusMus-BGM-082.mp3"
                jump ur_room


            "他妈的不行！":
                hide pboy
                $ putri.points += 20
                show buff eh sweat shock
                mc mock cling "当然不！"
                show buff touched blush -shock
                mc hister blush bloom "你还能制造什么？只是花朵吗？你能种出胡萝卜或土豆吗？"
                mc happy "土豆在收获前会开花，对吧？"
                buff wry sigh "哦嗯，是的，但我从未制造过食物，只有花……等等，这一点都不让你害怕吗？"
                mc wry sigh "为什么会害怕呢？我是说，你的才能是你自己的，不是吗？我知道你是从你父亲那里继承的，但是……你不是他，莱尔。"
                mc smile -sigh "它们是你的，莱尔，不是他的。"
                buff eh both shock "哦-哦。我以前从未这样想过。"
                mc laugh blush bloom "好吧，现在你有了，无论如何，试一试吧，我想知道你能不能产出一些土豆！"
                buff laugh blush bunga "啊哈，我会的。等一下——"
    stop music
    $ NPC = "???"
    play sound "sound/effects/punch.mp3"
    npc "巫师！" with vpunch
    show palmierproxy confused sweat shock
    show buff eh sweat shock
    "你听到附近灌木丛中传来一声喊叫。一个老人疲惫的声音夹杂着树叶的沙沙声。"
    show palmierproxy sad -shock
    "一个高大但看起来虚弱的老人从灌木丛中走了出来。"
    "他肩上扛着一根钓鱼竿，抓起它像长矛一样直指着你。"
    buff sad sigh "文恩先生！"
    $ NPC = "文恩"
    show buff kzl shock
    npc "我就知道，我就知道你们这种人在这里潜伏。一直以来，带走我们的孩子。你们要到什么时候才会满足满足...满..."
    show buff confused apa
    npc "...哦，对不起小伙子，我刚才说到哪里了？"
    show buff -apa
    play music "MUSIC/MusMus-BGM-099.mp3"
    mc confused sweat tanya"嗯？"
    "他的语气突然转变。刚才你还以为他要用钓鱼竿刺穿你。"
    show palmierproxy rajuk -tanya
    "但现在，他却像对自己的孙辈那样跟你打招呼。语气温和而热情。"
    buff keluh sweat "文恩先生，您还好吗？抱歉我没有事先告诉您就来了。"
    show buff sad 
    npc "哦，别说傻话了，小伙子。你随时都欢迎来这里。我们这些老家伙很幸运有你这样的好小伙子来帮忙。"
    npc "今天钓到什么好东西了吗？"
    buff wry -sweat sigh "今天什么都没钓到，文恩先生。我们只是在这里闲逛。"
    "文恩先生看了看你和莱尔，然后嘴角露出一丝顽皮的笑容。"
    npc "哦，原来是这样啊？那我想我该离开了。"
    npc "你钓到了个不错的对象啊，小子。虽然比不上我的老婆，但也是个不错的竞争者！"
    show palmierproxy malu both shock
    buff eh both shock "什么——？啊？！不，不是那样的！"
    show buff sad -shock
    show palmierproxy wry -both -shock
    npc "不，不用解释，我会让你们这些年轻人独处的。"
    npc "只要记得做好防护，还有沙子真的会钻进各种缝隙里。"
    npc "最好铺一块防水布。"
    show buff eh both shock
    mc laugh blush bloom "我们会的。"
    buff keluh frusta "啊？！"
    show buff sad sweat -frusta
    "不想再继续这个对话，你决定顺着老人的错误假设说下去。"
    "只是为了让他闭嘴，然后问一些更紧迫的问题。"
    mc apa sweat tanya "抱歉，文恩先生，您刚才说的关于巫师和孩子的事是什么？"
    if "anak_hilang" not in fia_events:
        mc rajuk -tanya "（这就是为什么这里有这么多失踪的孩子吗？他们中间有巫师吗？）"
    npc "嗯？哦，我一定是又在做白日梦了，别在意。"
    npc "恐怕这个老脑袋已经不像从前那样灵光了。"
    mc confused "但您知道巫师的事，对吧？"
    npc "当然。莱尔就是半个巫师，不是吗，孩子？不过这并不重要。"
    npc "在莱纳尔，每个人都受欢迎，尤其是年轻人。这里恐怕只有一群老家伙了。"
    mc ew sweat frusta "啊...是啊。"
    mc sad "（这很奇怪。是像之前那些爱说闲话的老太太说的痴呆症吗？）"
    mc confused -sweat sigh "（就好像有人按下了他的重置按钮一样。）"
    npc "有什么不对劲吗，孩子？你饿了吗？你知道我们今天在村子广场有烧烤活动。"
    #berubah
    if "anak_hilang" in fia_events:
        npc "莱纳尔经历了这么多可怕的事情后，需要一些振奋人心的活动。"
    #berubah
    npc "派克也带来了不少收获，我们很希望你能加入。"
    mc frown sweat shock "不，我不想打扰——"
    show palmierproxy side -shock
    buff laugh blush bunga "我们很乐意！"
    show palmierproxy confused 
    buff wry -blush sigh "哦，我是说，我很乐意。[povname]，你想回宿舍吗？"
    mc ew frusta "啊，嗯..."
    mc rajuk sigh "（这个老人有些让我毛骨悚然，但我知道派克是没问题的，所以...）"
    mc wry -sweat -sigh "为什么不呢，我们还有些时间，对吧，莱尔？"
    buff laugh blush bunga "没错！"
    play sound "sound/effects/walk.mp3"
    scene desa_center with w33
    "村子广场迎接你们的是烤火腿、培根和各种美味菜肴的香气。派克在那里，正朝你们挥手。"
    "当他注意到你们的存在时，其他村民也转过头来。"
    "有些人端着食物盘子走过来，有些人拍拍莱尔的肩膀表示欢迎。"
    "还有一些看起来脾气暴躁的老渔民，在与你对视时嗤之以鼻。"
    if calendar.weekday == "Sat" or calendar.weekday == "Sun":
        show buff bebas datar at right with dissolve:
            yoffset 770
        if girl:
            show palmierproxy jln frown at left with dissolve:
                yoffset 40
        else:
            show palmierproxy jln frown at left with dissolve:
                yoffset 100
    else:
        show buff datar at right with dissolve:
            yoffset 770
        if girl:
            show palmierproxy chill frown at left with dissolve:
                yoffset 40
        else:
            show palmierproxy chill frown at left with dissolve:
                yoffset 100
    mc rajuk sigh "（看来在这里我是个外人。）"
    $ NPC = "派克"
    show palmierproxy frown shock
    show side_pike_s at pic
    npc "你们来了，孩子们，我在想你们去哪儿了。玛格丽特，给这两个孩子切点火腿，好吗？"
    hide side_pike_s
    buff hister sigh "哦，没关系，我自己来就行。"
    show buff touched -sigh
    show palmierproxy -shock
    show side_pike_s at pic
    npc "小伙子，你很快就会轮到的，今晚负责火腿的是玛格丽特。"
    npc "如果你留下来，也许下个月的烧烤你就能当切肉的人了。"
    hide side_pike_s
    mc deject tanya "所以这是一个定期举行的活动？"
    show palmierproxy kind -tanya
    show side_pike_s at pic
    npc "当然。我们得庆祝大自然的恩赐。没什么比村里的烧烤更棒的了，对吧？"
    npc "这是个认识当地人的好方法，不过我猜你很快就会厌倦我们这些老古董了，是吧，莱尔？"
    hide side_pike_s
    buff laugh "别胡说，派克。如果有人会感到无聊，那也是他们对我感到无聊。"
    show buff datar -sigh
    show side_pike_s at pic
    npc "哦，当然不会。事实上，我们中有些人迫不及待地想看到你毕业后在这里定居。"
    npc "我的提议依然有效，你知道的。我随时都需要一个全职的船员。"
    hide side_pike_s
    buff amused "哦，我想我不能那样做，派克，但还是谢谢你。"
    show buff wry 
    show side_pike_s at pic
    npc "呸，我明白了。教会那套nonsense。不过，你随时都欢迎来这里。我知道玛格丽特也很幸运有你帮忙照看孩子们。"
    hide side_pike_s
    hide palmierproxy with dissolve
    show buff laugh blush bloom at center with move
    show kid1 at left with dissolve:
        yalign 1.0
        xalign 0.3
    show kid2 at right with dissolve:
        yalign 1.0
        xalign 0.7
    "你看着一群孩子蜂拥而上，抱住莱尔的大腿或试图爬上他的腰，要求他背他们。"
    "这与校园里其他学生对待他的方式形成了鲜明对比。"
    "莱尔笑着抱起一个年纪小的孩子，把他放在肩膀上。"
    "你看到这一幕不禁微笑，想象他在你的世界会是什么样子。他可能会成为一名幼儿园老师，或者是个渔夫。"
    "当他看到你盯着他时，他示意你过来拿个盘子。"
    "你决定无视周围老人们奇怪的窃窃私语，好好享受今晚的时光，玛格丽特递给你一块精美的火腿。"
    stop music
    scene bg_black with w20
    play music "MUSIC/MusMus-BGM-082.mp3"
    scene lor_mlm with w20
    jump ur_room

label buff_date3:
    stop music
    #scene bg_black with w33
    play music "MUSIC/MusMus-BGM-078.mp3"
    scene taman_inner with w33
    if calendar.weekday == "Sat" or calendar.weekday == "Sun":
        show buff bebas datar at right with dissolve:
            yoffset 770
        if girl:
            show palmierproxy jln frown at left with dissolve:
                yoffset 40
        else:
            show palmierproxy jln frown at left with dissolve:
                yoffset 100
    else:
        show buff datar at right with dissolve:
            yoffset 770
        if girl:
            show palmierproxy chill frown at left with dissolve:
                yoffset 40
        else:
            show palmierproxy chill frown at left with dissolve:
                yoffset 100
    "这一次，莱尔没有带你去莱纳尔。相反，他带你来到了学校的花园。"
    "他似乎很喜欢这里的植物，小心翼翼地一一除草和浇水。"
    mc happy tanya "这些植物都是你自己照料的吗？"
    show palmierproxy kind -tanya
    buff laugh "不是全部，但大部分是。有些是其他学生的作业。我受雇确保它们在学期结束前开花。"
    mc apa "嗯？什么，你只是在帮别人做作业？"
    buff touched sigh "差不多吧。这并不坏，孩子们付钱让我做这个，而且我喜欢植物。"
    mc malu sigh "（好吧，至少他能得到报酬。）"
    mc smile -sigh "有什么我能帮上忙的吗？虽然我对植物不太在行。我的拇指是黑色的。"
    buff hister blush "幸运的是，我的是绿色的。"
    show palmierproxy frown shock
    "他轻轻碰了碰你们的拇指。你们的指肚平平地贴在一起。"
    buff laugh bloom "现在它们应该能互相平衡了。"
    mc eiden blush bloom "（我的心啊！！！）"
    buff eh sweat apa "[povname]，你还好吗？"
    show buff eh -sweat -apa
    mc malu both sigh "我很好。"
    mc ha -sigh "（他真是个甜美纯真的孩子！）"
    mc happy blush bunga "那么，我猜你是想要帮忙，对吧？"
    buff lega "啊。如果你不想弄脏手也没关系。有人陪伴就很好了，你知道吗？"
    buff datar sigh "不过很有趣，我真的从没想过我会和你这么亲近。"
    mc confused -blush tanya"哦？"
    show palmierproxy frown -tanya
    buff scold sweat frusta "在我上第一堂课之前，你的名字就已经遍布任务板了。人们谈论着你手刃数十个巫师的事迹。"
    buff wry both sigh "我当时吓坏了，以为你会当场杀了我。但你出人意料地友善，比我的任何同学都要友善得多。"
    buff laugh blush bunga "我真的很感激能有你这样的室友。"
    show palmierproxy kind blush sigh
    show pboy at horzappear
    menu :
        "我也是。":
            hide pboy
            mc happy -sigh "莱尔，我也很高兴你是我的室友。"
            show buff datar -blush shock
            mc avoid sweat frusta "我想你是让我在这里对人性还有信心的唯一理由。"
            show buff wry -shock
            mc pissed "这里的学生都是混蛋，对吧？"
            buff sad sigh "我想他们必须如此。我不认为任何心软的人能在伊格尼亚长期生存。"
            buff datar -sigh "尽管教会在尽最大努力，但周围还是有很多敌对的巫师。"
            mc confused -sweat tanya "但也有好的巫师，对吧？"
            buff sad "我想是的。"
            buff scold sweat frusta "老实说，如果教会知道我有父亲的魔法，我确信他们也会追捕我。"
            buff keluh "我造成伤害的潜力超过了我行善的潜力。"
            show buff sad -sweat -frusta
            mc happy blush cling "你知道这不是真的。我是说，想象一下你能种出多少庄稼和花朵。"
            show palmierproxy kind -blush -cling
            buff lega sigh"花朵是可以的，但庄稼还是没有成功。"
            buff keluh sweat -sigh "不过，同样的潜力也可以用来形容我的父亲。"
            buff sad "有时我担心这不是我唯一继承的东西。"
            mc flirt bunga "嗯，你确实继承了他英俊的面容、宽阔的肩膀和引人注目的眼睛。"
            mc malu -bunga "但在内心，你完全是你自己。"
            buff datar blush sigh "嗯。谢谢你，[povname]。"
            mc kind "这是事实，不是恭维，你知道吗？另外，我该怎么除草呢？"
            show buff -blush -sigh

        "多夸夸我吧！":
            hide pboy
            show palmierproxy smile blush bunga
            show buff wry shock
            $ putri.points += 15
            buff lega both -shock "哦，呃...你很漂亮。可能是这里最美的学生之一。"
            buff datar -both "我听说很多其他学生在你走过时都在窃笑，你很受欢迎，[povname]。"
            buff hister blush "你也很有趣。虽然，你的幽默感有点与众不同。就好像你在假装是个局外人什么的。"
            buff datar -blush "对自己国家的文化如此无知。"
            mc avoid sweat frusta "是啊，这是...这是我喜欢做的一个小把戏。"
            mc ha -sweat -frusta "呃，总之，我该怎么除草呢？"
    show palmierproxy frown shock
    show buff frown shock
    if calendar.weekday == "Sat" or calendar.weekday == "Sun":
        show quil libur sly cling at center with dissolve: 
            yoffset 200
    else:
        show quil skul sly cling at center with dissolve:
            yoffset 200
    "当莱尔指导你如何正确地除掉一些更具食肉性的植物时，你看到奎尔带着调皮的眼神向你走来。"
    show buff confused -shock
    show palmierproxy confused -shock
    quil talk spark "哎呀呀，这不是我最喜欢的两个人吗。"
    buff talk sweat apa "呃，奎尔先生，你是在跟我说话吗？"
    show buff frown -sweat -apa
    quil laugh bunga "没错。奎尔先生。这正是为什么你是我最喜欢的，莱尔。"
    quil ejek cling "你知道吗，你是这里唯一一个如此尊重我的人？"
    show quil amused -cling
    mc mock cling "哎呀，我真想知道为什么！"
    show palmierproxy mean -cling
    quil heh -cling "这就是明证。"
    quil talk apa "不过你们两个优秀的标本在做什么呢？"
    show quil datar -apa
    buff wry sigh "哦，我们只是在给植物除草。我，呃，其他学生付钱让我维护他们的草药学作业。"
    quil ejek cling "天啊，莱尔，你简直是全能包啊，不是吗？强壮、英俊、手巧。"
    show palmierproxy ow sweat shock
    quil heh -cling "我亲爱的[povname]另一方面，恐怕那不是给食肉性通斯塔除草的正确方法，除非你想少一根手指。"
    show palmierproxy frown -sweat -shock
    quil laugh "来，让我示范一下怎么做。"
    show buff kzl sweat shock
    "当奎尔俯身指导你的手时，莱尔把你紧紧拉到自己身边，就像一个不想分享玩具的孩子。"
    buff scold -sweat frusta "不。"
    show quil err sweat shock
    if not girl2:
        buff sigh "我才是在教[dia2]。让我来做。"
    else:
        buff sigh "我才是在教[dia]。让我来做。"
    show quil tantrum -sweat sigh
    "奎尔耸了耸肩。他似乎对莱尔的举动有些不悦。然而，他掩饰得很好。"
    quil heh -sigh "那随你吧。暂时再见了，亲爱的。"
    show palmierproxy confused sigh
    show buff kzl frusta
    quil laugh cling "如果你真的被咬了一口，你知道在哪里找我。"
    show palmierproxy frown -sigh
    hide quil with dissolve
    buff sigh "哼。"
    $ buff_events.append("date3_done")
    "莱尔哼了一声，他的手仍然环绕着你的手。"
    show pboy at horzappear
    menu:
        "你可以放开我了。":
            hide pboy
            $ putri.points -= 15
            if putri.points <= 0:
                $ putri.points = 0
            mc malu both "呃，你现在可以放开我了。"
            buff eh both shock "啊！对，对不起，对不起！"
            mc hister -both "没关系，但你确实让我措手不及。我没想到你会那样抱我。"

        "靠近":
            hide pboy
            $ putri.points += 5
            show palmierproxy flirt at center with move
            mc happy cling "嗯，这感觉不错。"
            show buff eh both shock
            "你把自己安置在莱尔丰满的胸肌上。"
    buff keluh both frusta "哦，呃...对不起。不知为什么，我不想让他碰你。"
    mc wry both sigh "我理解，但我不禁想知道为什么...我没想到你会是那种嫉妒的类型。"
    show palmierproxy frown -both shock
    buff kzl sweat "我不是。至少我是这么认为的。我...我不喜欢别人打扰我们在一起的时间。"
    buff keluh "当你和我在一起时，我希望你只专注于我，不要在意其他人，如果这样很自私的话，我很抱歉。"
    show buff sad -sweat -frusta
    mc smile sigh "没关系。我妹妹也是这样的。"
    buff touched apa "你和你妹妹相处得很好，对吧，[povname]？"
    buff hister -apa "我看得出你们看对方的眼神。一半时间是出于沮丧，另一半时间则是纯粹的爱慕。"
    show buff datar
    mc mean cling "说实话，这就是看待兄弟姐妹的唯一方式。要么纯粹的愤怒，要么关心。"
    mc hister -cling "我相信你能理解，对吧，莱尔？"
    show palmierproxy kind 
    buff keluh sweat frusta "对我的兄弟们来说，当然。对我的姐妹们，就不太一样了。"
    show palmierproxy confused 
    buff wry -sweat sigh "老实说，我有点嫉妒你和菲亚的关系。看起来你们两个会为对方燃烧整个世界。"
    buff hister -sigh "有一个如此深爱你的人……一定很美好吧。"
    mc rajuk sweat tanya "我是说，你的兄弟们肯定爱你，不是吗？"
    show palmierproxy sad -sweat -tanya
    buff keluh sigh "当然。如果没有他们牺牲自己分散伊瓦尔的注意力，我就不可能从他的巢穴逃脱，但是……"
    buff scold frusta "我不知道，我所经历的爱总感觉像是被玷污了。"
    mc confused "被玷污？"
    buff kzl "也许是因为我在父亲身边待得太久了，但我总觉得我家里没有人知道如何去爱。"
    buff keluh "伊瓦尔有许多情人和妻子，都在年轻时生下我们后就死去了。这是一种近乎痴迷的爱。"
    buff sad sigh "我的姐妹们爱上了那些既迷恋她们又害怕她们的人类。"
    buff keluh -sigh "我的兄弟们……有些兄弟很奇怪。他们似乎以一种近乎受虐的方式渴望得到父亲的关注。"
    buff "他们知道他只会惩罚和伤害他们，但他们还是主动寻求他。我……我想我甚至不知道什么才是正常的爱。"
    buff sad sweat frusta "也许我永远也看不到。也许我已经太过破碎，无法体会到那种感觉了。"
    mc ew sweat sigh "莱尔……"
    show pboy at horzappear
    menu lyal_hug:
        "拥抱他":
            hide pboy
            $ putri.points += 5
            show buff eh both shock
            show palmierproxy sad sweat sigh with move:
                xalign 0.3
            mc wry -sweat -sigh "我不认为你是破碎的，莱尔，你和我们一样值得被爱。"
            "说着，你将他拉入怀中。"
            show buff wry blush sigh
            show palmierproxy ow both shock
            "他立即回抱住你，把你的脸埋在他的胸膛里。"
            mc avoid -shock "（这就是我要死的方式了。被男性胸肌窒息而亡。倒也不是个糟糕的死法。）"
            buff hister both apa "哦对不起，抱得太紧了，是吗？"
            show buff datar blush -apa
            mc wry -both "没关系。"
        "轻抚他的背":
            hide pboy
            show buff wry sigh
            show palmierproxy kind sigh
            $ putri.points += 5
            "你安慰地轻抚着莱尔的背。他的肩膀在你的触摸下似乎放松了下来。"
            "当他发出满足的叹息时，他转向你微笑着。"
        "你是，但是……" if honesty >= 50:
            hide pboy
            show buff frown shock
            mc ew sweat sigh "我是说，你对爱的看法可能有些偏差，我不会说谎。所以在这方面你可能有点问题。"
            mc kind -sweat -sigh "但是嘿，这样想吧，破碎的好处是你可以决定如何重新拼凑自己。"
            mc smile "你可以选择你想保留的和想丢弃的，这本身不就是一件美好的事情吗？"
            show buff wry sigh
            "莱尔因你的话语而微笑，感到安心。"
            $ putri.points += 10
        "{s}你是，但是……{/s}" if honesty < 50:
            jump lyal_hug
        "什么也不说":
            hide pboy
            $ putri.points -= 20
            if putri.points <= 0:
                $ putri.points = 0
            show buff sad sigh
            show palmierproxy side sweat sigh
            "在这种情况下你能说什么呢？"
            "说他一点也不破碎或有问题似乎是个太大的谎言。"
            scene bg_black with w20
            "你们在沉默中度过了剩下的时间，除草植物，然后回到宿舍。"
            scene lor_mlm with w20
            play music "MUSIC/MusMus-BGM-082.mp3"
            jump ur_room
    show palmierproxy frown sweat shock
    buff hister blush bunga "你真的很善良，[povname]。"
    mc ha sigh "嘿，在我来的地方，我这只是在做最基本的事情而已。"
    buff confused -blush apa "啊，你总是说\'在我来的地方\'，但我以为你是在伊格尼亚出生长大的。至少阿什姆先生是这么告诉我的。"
    show buff frown -apa
    mc avoid -sigh "哦，我……我是在边境附近出生的，所以还是在伊格尼亚，但是离得很远。我寒假的时候会去那里，那里很棒。非常棒。"
    show palmierproxy frown -sweat
    buff laugh apa "我明白了，那里的每个人都像你一样善良吗？"
    if "pinky" in buff_events:
        buff wry sigh "我知道你已经答应带我去那里，但是，我不知道……"
        buff amused -sigh "我现在真的很期待，[povname]。"
        
    else:
        buff wry sigh "如果是这样……你真幸运，[povname]。"
        buff amused -sigh "也许你在那里的时光是你与众不同的原因。"
    buff touched blush bunga "你……你真的很特别，我……我……"
    show buff with move:
        xalign 0.6     
    show palmierproxy confused shock flow
    show buff keluh sweat shock
    "莱尔越靠越近，突然一顶花冠在你头上绽放。"
    show palmierproxy hister blush bunga
    "如此喜庆多彩，你忍不住笑了起来。"
    buff sad both "啊！我很抱歉！我太兴奋了，我——！"
    mc kind blush -flow bloom "嘿，没关系，我很喜欢。我戴着好看吗？"
    buff wry blush bunga "你……你看起来绝对惊艳，[povname]。"
    "莱尔又盯着你看了一会儿，似乎迷失在你的眼睛里。"
    show buff sad both sigh with move:
        xalign 0.8
    show palmierproxy confused sweat shock
    "但在任何事情发生之前，他立即将头歪向一边，脸颊上持续泛着红晕。"
    show palmierproxy side -shock
    buff wry -sigh"嗯，天色已晚。你该回宿舍了，[povname]。"
    mc sad tanya "嗯？好吧，但我们不能一起回宿舍吗？"
    buff keluh sweat frusta "不，抱歉我...我想我需要时间...整理一下思绪。"
    buff hister -frusta "你先走吧。"
    mc side sigh "哦，好的，待会见，莱尔。"
    stop music
    play sound "sound/effects/walk.mp3"
    scene lor_mlm with w33
    "当你走回宿舍时，你能感觉到花瓣落在脸颊上，看到这一幕，你不禁感到一丝挥之不去的悲伤。"
    if calendar.weekday == "Sat" or calendar.weekday == "Sun":
        show side_p g at pic
    else:
        show side_p s at pic
    mc "（一旦我回到自己的世界，就再也看不到这种魔法了。）"
    if "pinky" in buff_events:
        mc "（如果我把一切都告诉莱尔，他还会想和我一起来吗？）"
    else:
        mc "（如果我告诉他真相，他会考虑跟我一起来我的世界吗？）"
    hide side_p
    play music "MUSIC/MusMus-BGM-082.mp3"
    stop sound
    jump ur_room


label buff_date4:
    stop music
    #scene bg_black with w33
    play music "MUSIC/MusMus-BGM-073.mp3"
    scene tepian with w33
    "莱尔再次带你去了莱纳尔，来到那座老教堂所在的山顶。"
    "这里的花朵正盛开着。相比之下，莱尔似乎紧张得不行，完全处于焦虑状态。一路上他都在坐立不安，慌乱不已。"
    if calendar.weekday == "Sat" or calendar.weekday == "Sun":
        show buff bebas frown sweat at right with dissolve:
            yoffset 770
        if girl:
            show palmierproxy jln frown at left with dissolve:
                yoffset 40
        else:
            show palmierproxy jln frown at left with dissolve:
                yoffset 100
    else:
        show buff frown sweat at right with dissolve:
            yoffset 770
        if girl:
            show palmierproxy chill frown at left with dissolve:
                yoffset 40
        else:
            show palmierproxy chill frown at left with dissolve:
                yoffset 100
    mc kind tanya "你还好吗，莱尔？你在想什么？"
    show palmierproxy frown shock
    buff keluh both shock "我喜欢你！"
    show buff sad -shock
    "他快速而真诚地脱口而出。你目瞪口呆，对这突如其来的表白感到惊讶。"
    mc apa sweat -shock "我...啊？什么？"
    buff touched blush sigh "我...我对你有感觉，[povname]。"
    buff hister -sigh "我喜欢你，不仅仅是朋友或我仰慕的学长。你...你是我的一切。"
    mc side "我...哦。"
    show palmierproxy sad
    buff keluh both "我知道这很突然。起初，我也不太确定自己的感觉。"
    buff sad "我知道，以我的过去，我可能把你的善意误解为爱情，或者把我对你的开放误解为更深的感情，但是..."
    buff wry "当我吃饭时，我总是想知道你今天吃了没有，当我睡觉时，我会看着房间对面，聆听你平静的呼吸声。"
    buff keluh sigh "当你和朋友出去然后带着伤痕回来时，我会担心。你无处不在，在我的心里，在我的脑海里。"
    buff wry -sigh "就在我床的对面。"
    buff confused apa "我...我喜欢你。但是，你呢？"
    show buff frown -apa
    if calendar.weekday == "Sat" or calendar.weekday == "Sun":
        show pboy s at horzappear
    else:
        show pboy at horzappear
    menu buff_conf:
        "对不起...":
            hide pboy
            $ buff_events.append("ditolak")
            $ putri.points -= 50
            show buff sad sweat shock
            mc ew frusta "对不起，莱尔，你说出这些话很勇敢，但我对你并没有那种感觉。"
            show palmierproxy sad sigh
            buff keluh frusta "我...我明白了。"
            buff wry sigh "至少谢谢你的诚实。"
            buff keluh apa "但是...是因为巫师的事吗？"
            show buff frown -apa
            mc side -sweat -sigh "真的不是。"
            if "companion" in my_events:
                mc wry both "我的生活中已经有了我珍惜的人，所以..."
                buff keluh sweat shock "哦。哦！我明白了。我很抱歉——"
                show buff sad -shock
                mc happy blush -bloth "嘿，别道歉。永远不要为诚实表达你的感受而道歉，好吗？"
                show palmierproxy kind -blush
                buff wry blush sigh "好的。"
                show buff -blush -sigh
            else:
                mc rajuk sweat sigh "我只是把你当作朋友而不是伴侣。而且，你比我妹妹还小。"
                mc sad -sweat tanya "你多大了来着，18岁？"
                show palmierproxy -tanya
                buff -sweat confused "我12月就满19岁了。"
                mc smile blush "那么我相信你会找到一个好人来庆祝的。"
                show palmierproxy sad sweat 
                buff keluh frusta "...但我希望那个人是你。"
                show buff sad sigh
                show palmierproxy kind -sweat at center with move
                "他喃喃自语。你只是微笑着把手放在他的肩膀上。"
            if "pinky" in buff_events:
                mc happy sigh "你是个好孩子，莱尔，你值得比我更好的人。"
                mc smile -sigh "一个会信守承诺的人。"
                buff sad sweat apa "那是什么意思？你是在说我们的约定吗？你不能带我去你的家乡吗？"
                mc side sweat "不。对不起，这...很复杂。"
                buff keluh -sweat -apa "我明白了。谢谢你告诉我，我想这可能是最好的结果。"
                show buff sad 
                mc smile -sweat sigh "也许吧。你会没事的，莱尔。我知道你会的。"
                show buff sinis both sigh
                "莱尔对你露出了一个小小的温柔微笑。虽然是勉强的，脆弱的，但也只能如此了。"

        "我不知道。":
            hide pboy
            $ putri.points -= 10
            mc ew sweat frusta "我...我不知道。"
            buff eh sweat shock "你...你不知道？"
            show buff sad -shock
            mc sad sigh "现在情况很复杂。在我处理一些...事情之前，我真的无法给你答复。"
            buff scold apa "事情？"
            mc ew frusta "（杀死你的父亲和最后一个纯血巫师。）"
            mc ha sigh "是啊，最后一年的事情，你懂的。我不能偏离我的学业。"
            show palmierproxy wry -sigh
            buff wry both -apa "哦，我想这是有道理的。但是...这是不是意味着，这不是拒绝？"
            mc kind blush tanya "这不是拒绝。你介意等一等，直到我处理完我的\'学业\'吗？"
            buff laugh blush sigh "我会一直等到时间的尽头。"
            show palmierproxy smile -tanya

        "{s}我也喜欢你。{/s}" if "companion" in my_events:
            jump buff_conf
        "我也喜欢你。" if "companion" not in my_events:
            hide pboy
            $ putri.points += 10
            show buff wry blush shock
            mc kind blush bunga "我也有同样的感觉。"
            show buff laugh bloom
            mc happy "也许没有那么强烈，但我知道我们之间是有感情的。"
            mc malu sigh "起初，我觉得你很可爱，也很单纯。在某些方面，我把你当作弟弟看待。不知怎的，这些感情逐渐发展成了别的东西。"
            show buff eh sweat shock
            mc ha sweat "但是要我们真的成为更亲密的关系，嗯...那又是另一回事了。"
            buff sad apa "你是什么意思？你不喜欢我吗？"
            mc side sigh "我喜欢，但我不确定你是否喜欢我。"
            mc ow frusta "（我是说真实的我。虽然至少我没有像对阿什姆那样对他撒那么大的谎，但还是...）"
            mc side "（我想在完成这里的事情之前，我无法与这个人建立关系。）"
            mc sad sigh "（但这也意味着要杀死伊瓦尔...）"
            buff scold frusta "你是什么意思？我当然喜欢你，[povname]。请不要告诉我应该如何感受。"
            show buff sad -frusta
            mc ow frusta "我没有，只是...你不了解真实的我。这就是我想说的全部。"
            mc sad sigh "我不是在说什么心理学上的\'啊，我的内在自我\'或者面具背后的真实面孔之类的废话。"
            mc confused -sigh "我真的是指有些事情我为了你的安全而对你隐瞒了。"
            mc wry both "但也许以后，当我完成我需要做的事情时，我会告诉你一切。"
            mc hister blush tanya "然后你可以告诉我你的感受，好吗？"
            show palmierproxy kind -tanya
            buff wry blush sigh "……好吧。"
    stop music
    scene hill with fade
    "你把头靠在他的肩膀上。你们两个静静地看着日落。"
    $ buff_events.append("date4_done")
    play music "MUSIC/MusMus-BGM-082.mp3"
    scene bg_black with fade
    scene lor_mlm with w33
    jump ur_room

label buff_date5:
    stop music
    #scene bg_black with w33
    scene overcast with w33
    if calendar.weekday == "Sat" or calendar.weekday == "Sun":
        show buff bebas frown at right with dissolve:
            yoffset 770
        if girl:
            show palmierproxy jln frown at left with dissolve:
                yoffset 40
        else:
            show palmierproxy jln frown at left with dissolve:
                yoffset 100
    else:
        show buff frown at right with dissolve:
            yoffset 770
        if girl:
            show palmierproxy chill frown at left with dissolve:
                yoffset 40
        else:
            show palmierproxy chill frown at left with dissolve:
                yoffset 100
    buff talk sweat "那么..."
    $ buff_events.append("date5_done")
    play music "MUSIC/MusMus-BGM-008.mp3"
    buff confused apa "你不是来自这个世界的，对吧[povname]？"
    buff wry -apa "我还是不敢相信，但这又解释了很多事情。"
    if "desa" in buff_events:
        buff keluh -sweat "每当你谈论你的家乡时，你指的是另一个世界，对吗？"
        mc kind sigh "是的。"
    else:
        buff huh frusta "我真不敢相信我竟然没有想到这一点。"
        mc ha sweat "嗯，说实话，告诉别人我是来自另一个世界的旅行者确实听起来相当离谱。"
        buff wry -sweat -frusta "轻描淡写地说，哇..."
    buff frown apa "那么，你世界里的菲亚，她已经不在了？"
    mc kind blush sigh "...不一定。她在这里，在我心里。"
    "你说着，指了指你的胸口，轻轻地拍了拍。"
    if 'iv_curhat' in fia_events:
        show buff sad sweat shock
        mc happy tanya "对你来说也是一样的，不是吗？关于你的父亲？"
        show palmierproxy sad sweat -tanya
        buff scold frusta "我...我真的不知道该怎么想。"
        buff keluh sigh "我不是说我不相信你的说法。事实上，关于我兄弟们的那部分确实能对得上。"
        buff kzl -sigh "但即使他有他的理由..."
        mc ew sigh "你无法原谅他对你所做的事。"
        show palmierproxy smile -sweat -sigh
        show buff sad -sweat
        "莱尔羞怯地点了点头。"
        "你微笑着，安慰地拍了拍他的背。"
        mc smile sigh "你不必原谅他。如果你做不到，那就做不到。"
        mc happy -sigh "我向你解释这些只是为了给你一个交代。"
        mc wry "重申你没有做错任何事。这一切都是伊瓦尔的错。"
        mc kind "无论他的意图如何，莱尔，你不应该受到他那样的对待。"
        buff wry sigh "……谢谢你。"
    else:
        show buff sad sweat frusta
        show palmierproxy confused sweat shock
        "莱尔警惕地盯着你。"
        buff keluh apa "你认为伊瓦尔还存在于另一个[povname]中吗？"
        buff kzl -apa "现在[kamu]拥有他的心脏？"
        mc hister -shock "我...我想是的，但是，他不会控制。这才是重要的部分。"
        show palmierproxy sad -sweat
        buff sad frusta "不过，这很危险。把这么多信任放在一个人身上。"
        mc wry tanya "怎么，你不信任我吗？"
        buff scold "我信任你，但不信任另一个你。"
        buff sad sigh "但[kamu]看起来人还不错。我只希望你做出了正确的选择，[povname]。"
        mc laugh blush sigh "我也是。不管怎样，我尽了最大努力，再次让那两个混乱的兄弟团聚了。"
        show buff wry -sweat
        mc kind -sigh "这足以让我得到解脱。"
    show palmierproxy confused sweat tanya
    buff hister both -sigh "说到解脱。"
    show palmierproxy frown -sweat shock
    if "date4_done" in buff_events and "ditolak" not in buff_events:
        buff talk apa "你终于有答案给我了吗，[povname]？"
        buff wry -apa "关于你对我的感觉？"
        mc ew -shock "哦...我..."
        if calendar.weekday == "Sat" or calendar.weekday == "Sun":
            show pboy s at horzappear
        else:
            show pboy at horzappear
        menu buf_temb:
            "我很抱歉。":
                hide pboy
                show buff sad sweat shock
                show palmierproxy sad sweat sigh
                if "companion" in my_events:
                    mc ow frusta "我已经有了爱的人。对不起，莱尔。"
                    buff hister sweat sigh "哦，没关系。我很高兴你找到了心上人，[povname]。"
                    buff wry -sweat -sigh "你和他们在一起很幸福，对吧？"
                    mc smile blush bunga "是的。"
                    buff laugh sigh "很好，那就是最重要的。"
                else:
                    buff keluh apa "哦。是因为我吗？我做错了什么吗？"
                    mc ow frusta "不！不...你没有做错什么，莱尔。这也不是因为你的血统，或者你做过的任何事。"
                    mc side sigh "只是我们不适合彼此，至少不适合成为伴侣。"
                    mc wry -sweat -sigh "这没关系。我们仍然是朋友和室友，你仍然是我认识的最好的人之一。"
                    mc smile blush "你总有一天会找到那个人的，莱尔，一个真正特别的人，会接受和欣赏你。"
                    buff wry -sweat sigh "你真这么认为？"
                    mc happy bunga "我确信如此。"
                "你对莱尔露出了一个令人安心的微笑，他开始放松下来。他有些羞怯地看着你。"
                show palmierproxy kind -bunga
                buff laugh blush sigh "你知道，我很难忘记你。"
                buff talk -sigh "除了阿什姆，你是我唯一真正的朋友。"
                mc smile -blush tanya "那不是真的。派克和莱纳尔的其他人呢？"
                buff keluh sweat frusta "莱纳尔是...莱纳尔全是谎言，[povname]。"
                show palmierproxy sad sweat shock
                jump asli_leynar
            "{s}我想要你。{/s}" if "companion" in my_events:
                jump buf_temb
            "我想要你。" if "companion" not in my_events:
                hide pboy
                $ buff_events.append("companion")
                $ my_events.append("companion")
                show buff wry blush shock
                mc happy blush bunga "我想要你，莱尔。我知道这不如\'我爱你\'那么强烈，甚至不如\'我喜欢你\'那么清晰。"
                mc malu sigh "但我知道我想更深入地探索我们之间的这种感觉。"
                mc kind -sigh "也许在我的世界里？"
                buff laugh blush bunga "你...你想让我和你一起去？"
                mc mock "我是说，除非你真的那么受虐。"
                mc hister "我认为这比留在一个每个人要么想烧死你要么想砍掉你脑袋的世界要好。但选择权在你。"
                show palmierproxy kind 
                buff talk -bunga "啊哈。你的论点很有说服力，[povname]。"
                buff hister "我很乐意和你一起去。"
                if "pinky" in buff_events:
                    buff wry "况且，你答应过的，记得吗？"
                    mc smile blush bunga "我记得。"
                show palmierproxy kind blush bunga at center with move
                show buff hister both shock 
                "莱尔微笑着深深地看着你的眼睛，然后倾身向前吻了你。"
                "这个吻柔软、温柔，带着些许干燥皲裂的嘴唇的摩擦，促使你湿润了他的下唇。"
                "莱尔叹了口气，加深了这个吻，吞下了你所有的小喘息和呻吟。"
                "几分钟过去后，你们分开了。他有点喘不过气来。"
                buff laugh blush bloom "那真是...我..."
                mc happy tanya "感觉好吗？"
                buff wry sigh"很好。"
                show palmierproxy kind -tanya 
                show buff wry blush bloom
                "当你倾身想要更多时，莱尔抓住你的肩膀将你固定在原地。"
                "这个动作让你有点吃惊，wondering你是否把他推得太远超出了他的舒适区。"
                mc laugh tanya"太过了吗？"
                buff talk "还不够。但不是在这里。我...我不想让其他人来看到你现在的样子。"
                buff sad frusta "你脸上的红晕和眼中的火焰...难道不应该只有我才能看到吗？"
                show palmierproxy hister sigh
                show buff wry -frusta
                "他相当占有欲地呜咽着。你咯咯笑了起来，没想到他会有这种孩子气的贪婪。"
                mc happy -sigh"当然。只有你。"
                show buff datar sigh
                "他点点头，也许对自己的话感到有些尴尬。"
                mc mock cling "我们回房间吧，好吗？"
                show buff eh both shock
                mc flirt -cling "在那里我们可以尽情探索彼此，直到心满意足。"
                show buff hister blush bunga
                "莱尔的脸上布满了强烈的红晕，但他还是点了点头。"
                $ morning = False
                $ evening = False
                $ afternoon = False
                $ night = True
                #scene bg_black with w33
                scene bed_mlm with w33
                "你们俩慢慢走向宿舍，享受着落日的余晖。莱尔没有松开你的手，紧紧地抓着它，仿佛那是他的生命线。"
                
                show buff wry blush swim at center with dissolve:
                    yoffset 770
                "当你们进入房间时，天已经黑了。"
                "不想浪费时间，你迅速脱掉了衣服和内衣，随意地扔在一旁，而莱尔则在床上俯身压在你身上。"
                "他用亲吻和爱痕标记着你的胸膛，然后喃喃地说..."
                buff keluh sigh "我...我从来没有做过这个。"
                show side_p n at pic 
                mc "我知道，别担心。我会引导你的。我知道什么能让我兴奋。"
                show side_p nm
                mc "真正的问题是，你喜欢什么？"
                hide side_p
                buff sad frusta "那个...我不，我从未..."
                show side_p n at pic 
                mc "嘿，没关系。放松，跟着我的引导来。你能为我做到这一点，对吧，莱尔？"
                hide side_p
                buff hister -frusta "我...是的。只要告诉我你想要什么。我会让你感觉很好的。"
                show buff sad both shock
                show side_p nf at pic 
                mc "错了。"
                hide side_p
                "听到这些话，他的瞳孔放大了，害怕自己已经以某种方式让你失望了。如此渴望取悦你。"
                show buff wry sigh
                show side_p n at pic 
                mc "真可爱。"
                hide side_p
                "你在他的嘴唇上轻轻地吻了一下，以示安慰。"
                show side_p nm at pic 
                mc "你应该说我们俩都会感觉很好。一起。性爱是两个人的舞蹈，不是独奏。"
                show side_p n
                mc "你想感觉好吗，莱尔？"
                hide side_p
                buff touched blush -sigh "比任何事都想。求你了，[povname]，我...我太想要你了。"
                if not girl:
                    galleryunlock l_sex_m
                    show l_sex_m with flashbulb
                    mc "你想要我怎么做？你想要我来占有你吗？"
                    mc "深深地进入你，在你的内壁中安居，直到你记住我的形状？"
                    mc "还是你想要进入我？填满我，直到我被撑得鼓起来？"
                    buff "科尔，什么都行。什么都行。"
                    mc "什么都行？那么...这确实给了我们很多选择。"
                    
                else:
                    galleryunlock l_sex_f
                    show l_sex_f with flashbulb
                    mc "我看得出来。看来你全身上下都很壮实，不是吗，莱尔？"
                    buff "唔。"
                    "当你紧紧握住他的勃起时，莱尔呻吟了一声。当他仰起头时，你抓住这个机会坐到了他的大腿上。"
                    "在两条肌肉发达的大腿之间安顿下来。"
                    mc "就是这样，放松下来。"
                mc "让我们彻底探索彼此，好吗？"
        stop music
        scene bg_black with w20                
        "..."
        "你和莱尔度过了一个激情的夜晚，然后躺在他的胸膛上好好休息。"
        "当你渐渐入睡时，你听到莱尔轻声呢喃着\"我爱你\"。"
        jump jaga_jaga
    else:
        jump asli_leynar
label asli_leynar:
    show palmierproxy confused -shock
    buff keluh sweat sigh "我...我今早和派克、玛格丽特还有孩子们谈过了。"
    buff -sigh "我去那里时发现教会正在疏散岛上的人。"
    buff scold "显然在伊瓦尔和塞斯的战斗之后，那里已经不适合居住了。"
    buff kzl "裂缝太多，岛屿正在下沉。很快它就会消失。"
    buff sad sigh "但我设法碰到了派克，他对我破口大骂。"
    mc side sigh"哦。"
    show palmierproxy sad -sigh
    buff keluh -sigh "他把一切都怪罪于我，玛格丽特也是。孩子们一看到我就哭了。"
    buff "他们现在都记起来了。巫师，他们岛上发生的悲剧。"
    buff scold sigh "显然塞斯篡改了他们的记忆和行为。"
    buff keluh -sigh "他们不想让我留在他们的岛上，也不想让他们的孩子跟我在一起。"
    buff sad "但这是塞斯强迫他们做的，他们无法控制。"
    mc ow sweat "哦，莱尔，我很抱歉。"
    buff wry -sweat sigh "别这样说...我...我早就料到会这样。一个没有人知道巫师存在的岛屿，这种事太美好了，不可能是真的。"
    buff scold -sigh "不过，他们找到了史蒂夫。他们在一个沟里找到了他，躺在一个仪式圈上。"
    buff sad "也许塞斯正准备把他变成一个真正的傀儡或某种奇怪的生物。"
    buff keluh "他浑身是血，饥肠辘辘，但他会活下来的。"
    buff wry "他向我伸出手，说让我去医院看望他。"
    show palmierproxy wry -sweat
    buff hister -sweat sigh "...这，这让情况变好了一些。意味着还有希望。"
    "听到这话，莱尔深深地叹了口气，肩膀和背部不再僵硬。"
    show buff wry -sigh
    "他脸上挂着温柔的微笑，那是一个充满渴望，最重要的是，充满希望的微笑。"
    mc smile blush "你会没事的，莱尔。我知道你一定会的。"
    buff laugh blush "谢谢你，[povname]。"
    buff datar sigh "不知为什么，当你这么说的时候...我真的相信这是真的。"
    #stop music
    "你和莱尔一起度过了一段时间，在校园里四处走动，欣赏风景，然后回到了宿舍。"
    $ NPC = "???"
    scene bg_black with w20
    stop sound
    $ NPC = "???"
    scene bg_black with w20
    jump jaga_jaga

label lyall_cafe_date:
    play music "MUSIC/MusMus-BGM-004.mp3"
    scene book with w20
    if gold >= 10:
        $ gold -= 10
    show buff sad sweat frusta at right with dissolve:
            yoffset 770
    if girl:
        show palmierproxy chill frown at left with dissolve:
            yoffset 40
    else:
        show palmierproxy chill frown at left with dissolve:
            yoffset 100
    "你在学校咖啡厅请莱尔吃了点东西。"
    "如果不是因为周围的环境，从他坐立不安的样子来看，你会以为你刚刚给他来了一轮酷刑。"
    show palmierproxy sad sigh
    "眼睛四处乱瞟，背部挺直，汗水顺着眉毛流下。他很害怕。"
    show pboy at horzappear
    menu:
        "安抚他":
            hide pboy
            $ putri.points += 5
            show buff sad shock
            mc laugh both bunga "嘿，没事的。我不会伤害你的。"
            "你用类似于安抚野生受惊动物的语气安慰他。"
            if "rooted" in buff_events:
                buff scold -sweat frusta "这有点难以相信。"
                show buff kzl sigh
                "他的意思是，在你对那该死的花做了那些事之后。"
                mc scratch avoid sweat "是啊，我已经吸取教训了，好吗？"
                show palmierproxy ha 
            else:
                buff keluh frusta "我的恐惧真的那么明显吗？"
                mc wry sweat sigh "亲爱的，你在发抖，就像一片叶子。一片非常大而且看起来肉嘟嘟的叶子。"
                buff sad sigh "哦..."
            mc smile blush bunga "给，我给你买了些茶，可以让你平静下来。"
            
        "提供食物":
            hide pboy
            show buff sad sweat shock
            $ putri.points += 5
            if putri.points < 0:
                $ putri.points = 0
            "你假装没有注意到这一点，继续按计划度过这一天。暂时从等待你的所有戏剧性事件中休息一下。"
            mc smile blush bunga "给，我给你买了些茶。"
    buff scold sweat frusta "...这是菊花茶，对吧？"
    mc ew sweat frusta "（糟糕，我不会不小心点了某种魔法活茶吧？这朵花是人还是普通的花？）"
    show buff wry -sweat sigh
    mc pissed "（我现在不会是在喝一个死人吧？！）"
    show palmierproxy chill deject -sweat shock
    buff hister blush bunga "啊哈哈。别担心，我喜欢菊花。"
    buff talk "这是我父亲唯一无法正确制作的花。"
    show buff datar -bunga
    mc scratch ha sweat tanya "哦，所以...我现在不是在喝活人，对吧？"
    show palmierproxy chill wry -sweat -tanya
    "莱尔对你的惊呼露出微笑，也许是被这句话的荒谬性逗乐了。"
    buff talk -blush "你没事的。呃，干杯。"
    show buff wry
    "莱尔和你碰了碰杯，你喝了一口饮料。"
    "味道有点甜，带着一丝苦味，而且热得几乎烫伤了你的舌头。"
    show palmierproxy frown
    buff talk "我的姐姐阿拉尼亚来访时常常会泡好茶。有时她会让我喝一口。即使只是为了不烫到她自己的舌头。"
    buff wry sigh "她是我姐妹中比较好的一个。虽然还是有点专横和娇生惯养，但比其他人更善良。"
    show palmierproxy side sweat sigh
    buff laugh bunga "她甚至会把剩菜给我。"
    show pboy at horzappear
    menu:
        "你应该得到更好的。":
            hide pboy
            show palmierproxy confused -sweat -sigh
            buff wry -blush sigh "至少我没有挨饿。"
            mc smile "这是肯定的。"
            buff huh sweat apa "等等，你是说我胖吗？"
            mc kzl sweat shock "什么——？哦，不，不是！"
            mc malu both -shock "我的意思是，那些肌肉不是一夜之间长出来的，对吧？"
            show buff wry -sweat -apa
            "莱尔低头看了看自己的胸膛和腹部，羞涩地笑了。"
            buff amused "实际上，它们确实是。也许这是作为伊瓦尔的儿子为数不多的好处之一。"
            buff wry "你生来就很美。"
            mc frown -both shock"哦。"
            show palmierproxy -shock
            "你本想说出你有多嫉妒这个事实，他就像某个完美制造的娃娃一样天生就美丽。"
            "但你忍住了，因为你知道他的美丽付出了怎样的代价。"
        "其他人呢？":
            hide pboy
            show palmierproxy confused -sweat -sigh
            mc "你到底有多少兄弟姐妹？"
            buff huh sweat apa "活着的那些？不是...那些花？"
            mc side sweat sigh "是的。"
            buff keluh -apa "有五个。"
            buff huh -sweat"伊尔夫、维拉、科斯莫、杰拉德和阿拉尼亚。"
            buff keluh "科斯莫和杰拉德在我8岁时被转化了。我与伊尔夫和维拉接触最多。"
            buff sad "阿拉尼亚没有和我们住在一起，她有自己的领地。但我想一个猎人抓到了她。"
            buff sigh "有一次我看到伊瓦尔在哭泣，紧握着她的旧信件。那天之后我再也没见过她。"
            show buff frown -sigh
            mc sad -sigh "哦。"
        "去拜访吗？":
            hide pboy
            show palmierproxy confused -sweat -sigh
            buff frown "我的姐妹们成年后被允许搬出去。"
            buff huh sweat sigh "有些人在那之前就逃走了。伊瓦尔对他的领地...很严格，很挑剔。"
            buff keluh -sigh "即使对于那些更受优待的人来说，也很难与他相处。"
            buff kzl "更糟的是，我的姐妹们并不像他那样憎恨男人。维拉尤其迷恋男孩。"
            buff scold "她逃走嫁给了一个人类，我不知道她在想什么。"
            buff sad "但我想现在这些都无关紧要了。"
            if "big_bro" in topics:
                mc rajuk tanya "我以为你不喜欢维拉。"
                show palmierproxy frown -tanya
                buff confused "我确实不喜欢。维拉和伊尔夫在伊瓦尔身边时经常打架，但我不知道为什么。"
                buff sad sigh "我是说，伊尔夫可能只是想得到伊瓦尔的注意，但维拉甚至不让他靠近我父亲。"
                mc confused "也许她是嫉妒？想要独占爸爸的注意力？"
                buff -sigh "也许吧。毕竟她是他最小的女儿。"
    mc side sweat frusta "（该死，这真是一次令人沮丧的外出，不是吗？）"
    mc ow "（我有问题，但还没到这种糟糕的程度。我不知道该如何缓解气氛。）"
    buff wry both sigh "你不必这样做。"
    show palmierproxy chill confused -sweat shock
    "他对你低语，向你投来一个同情的微笑。"
    buff talk -sigh "我是说，话题确实有点沉重，但是...我很高兴，你把我当成一个正常人对待。"
    buff laugh -both "我是说，我以前见过你说话，你对他们和对我一样爱管闲事和侵犯隐私。"
    mc panik sweat sigh "哇，所以你的意思是我对每个人都这么尴尬？很高兴知道这一点。"
    show palmierproxy wry -sweat -sigh
    buff hister both sigh "啊，我是好意。而且我在社交方面也不太擅长，所以呃...嗯，聊得不错。"
    buff wry blush bunga "你...你比我想象的要温和得多。"
    buff kzl -blush -bunga "关于你有很多传言，校园里头号巫师杀手。我以为你会对我更有偏见。"
    buff talk sigh "但相反，除了阿什姆先生外，你可能是唯一一个正常对待我的人。"
    if "rooted" in buff_events:
        buff scold sweat frusta "如果你没有伤害托马斯，我可能会更感激这一点。"
        mc scratch ha sweat frusta "你不会放过这件事，是吗？"
        buff sinis -sweat sigh "还没有，但是...我不知道，你正在慢慢弥补。"
        buff frown apa "对了，你今天给托马斯浇水了吗？"
        mc avoid sigh "呃，没有，但是——"
        show palmierproxy sad shock
        buff keluh sweat shock "什么？他一定很渴！来吧！"
        scene bg_black with w20
        "你和莱尔离开了咖啡馆。他向你展示了如何正确给托马斯浇水而不会淹死他。"
    else:
        buff laugh blush bunga"我很感激。"
        mc happy blush bloom "不客气。嘿，如果你想聊天或者闲逛，我的床就在你的对面。"
        buff wry sigh "我知道。"
        scene bg_black with w20
    stop music
    if calendar.day == 23 and calendar.month == '/05':
        jump map_dorm
    else:
        scene lor_mlm with w20
        play music "MUSIC/MusMus-BGM-082.mp3"
        jump ur_room
        
label buff_flower_bully:
    $ morning = False
    $ afternoon = True
    $ evening = False
    $ night = False
    play sound "sound/effects/grow.wav"
    play music "MUSIC/MusMus-BGM-089.mp3"
    scene tmn_ujung with w20
    if girl:
        show palmierproxy scratch apa sweat at left with moveinleft:
            yoffset 40
    else:
        show palmierproxy scratch apa sweat at left with moveinleft:
            yoffset 100
    show buff sad sweat at right with moveinright:
        yoffset 770
    mc tanya "它是不是...变大了？"
    show palmierproxy sad -tanya
    "当你发现伊瓦尔的花朵比你上次看到时至少长大了十倍时，你问道。"
    "它不再只是一朵玫瑰，而是长成了一丛齐膝高的灌木。"
    buff keluh frusta "确实如此。一定是有人摘了它，或者踩到了它吧？"
    show buff sad -frusta
    show pboy at horzappear
    menu:
        "我们应该移走它吗？":
            hide pboy
            "莱尔摇了摇头。"
            buff scold frusta "你不能移动我父亲的任何人类花朵。一旦生根，它们就永远不能离开最初的位置。"
            buff kzl sigh "你知道我为什么那么生气吗？"
            mc side sigh "啊..."
            show palmierproxy -sigh
            buff keluh frusta "我想我们应该向老师报告这件事。如果它继续长大，那么——"
            show buff sad

        "我们应该向老师报告。":
            hide pboy
            buff keluh frusta"我也这么认为。如果它继续长大，那么——"
            show buff sad
    
    show buff kzl shock
    show palmierproxy chill kzl shock
    $ NPC = "男孩"
    npc "我就知道是你在搞鬼！"
    "一个粗哑的声音从你身后传来。转身一看，你看到五个学生正怒视着你。"
    "他们都穿着一套类似菲亚的制服：黑色背心但没有手套，表明他们至少比你低两个年级。"
    $ NPC = "男孩"
    npc "我就知道那朵花长得太快了。那是人类之花，对吧？"
    npc "就像死亡地带里的那些！"
    buff eh -shock "我...是的，但是——"
    show buff sad
    $ NPC = "女孩"
    npc "我就知道！该死的巫师，是你创造了那朵花吗？"
    show pboy at horzappear
    menu:
        "是他做的。":
            hide pboy
            mc mock -sweat cling "是他做的，你们最好小心点，以免他把你们都变成花。"
            buff eh shock "[povname]，什么——"
            mc pissed -cling "嘘！"
            $ NPC = "男孩"
            npc "你——他真的是美丽巫师的儿子，对吧？！怪物！恶魔！"
            mc mock "给你个忠告，小子..."
            show palmierproxy mean cling
            "你偷偷摘下一片花瓣，吹向那个大声说话的人的脸上。"
            npc "啊啊啊！"
            mc smile -cling "...别惹一个杀人魔的儿子。"
            "花朵开始在那个人的衣服周围生长，他赶紧脱掉衣服，花瓣吞噬了衣物，然后又扎根回地面。"
            "那个人尖叫着和他所谓的朋友们一起逃走了。"
            mc mock cling "呵。胆小鬼。"
            "你转过身，希望看到莱尔脸上露出微笑和感激，但你得到的只是一声严厉的咆哮。"
            buff keluh frusta "你为什么要那么做？！你知道当你那样做的时候，你是在掏出他们的内脏，碾碎他们的骨头。为什么？"
            show buff kzl
            mc ow sweat shock "啊...我——"
            mc ew frusta "（我忘了这一点。）"
            $ putri.points = 0
            $ kindness = 0
            $ curiosity += 10
            $ honesty -= 20
            mc sad -frusta "对不起，我——"
            buff keluh sigh "离开！"
            mc side sigh "莱尔，我——"
            buff kzl frusta "我说了离开！"
            buff sad sigh "我自己来处理这件事。"
            mc sad sigh "我很抱歉。"
            mc ew frusta "（好吧，可以肯定地说我搞砸了这次机会。也许塞恩和奎尔想去哪里逛逛。）"
            $ NPC = "???"
            stop music
            scene bg_black with w20
            if "bunga_bego" in buff_events:
                if "beku" in quil_events:
                    scene map_infected_f with w20    
                else:
                    scene map_infected with w20    
            else:
                if "beku" in quil_events:
                    scene map_frozen with w20
                else:
                    scene map_all with w20
            jump world_map
        "是我做的。（为莱尔掩护）":
            hide pboy 
            show buff frown shock
            show palmierproxy confused -sweat cling
            $ NPC = "女孩"
            npc "等等，你不是菲亚的[kk]吗？[povname] 贝克？"
            mc mean tanya "如果我是呢？"
            npc "你不可能创造出那朵花。你不是巫师。"
            mc smile -tanya "但我可以把它带到这里来，从死亡地带移植过来。"
            npc "哼，如果是这样，那你比我听说的还要变态。"
            mc happy cling "我觉得这里种些玫瑰会更漂亮。"
            npc "天啊，你真的刚才说了那句话吗？！你这个疯子！你知道你做了什么吗？！"
            show palmierproxy kind -cling
            jump bego_bunga


        "我们发现了它":
            hide pboy
            show buff frown shock
            show palmierproxy frown -sweat sigh
            $ NPC = "男孩"
            npc "发现了？"
            mc deject -sigh "它就这么落在这里。我们和你一样不知道它为什么会在这里。"
            $ NPC = "女孩"
            npc "你指望我们相信这个？"
            show palmierproxy wry
            "你耸了耸肩，继续编造更多的谎言。"
            mc happy "风一定把花瓣吹到这里来了。就像蒲公英一样。"
            if honesty <= 30:
                $ NPC = "男孩"
                npc "..."
                npc "我是说，我猜这是可能发生的。"
                npc "不过，你们为什么没有向学校报告这件事？"
                mc smile "我们报告了。他们让我们继续监视。"
                npc "监视？"
                buff wry -shock "我们还不确定如何安全地移除这朵花。我的意思是，如果我们知道怎么做，那么死亡地带现在就不会还到处都是花了，不是吗？"
                "莱尔插话道，终于配合起来。"
                npc "嗯。我想这说得通。"
                npc "所以...你们两个只是在执行老师的指示。"
                mc happy cling "是的。如果你有任何疑问，可以随时去问海德温女士。如果她没有忙于布道的话。"
                show palmierproxy smile -cling
                npc "呸。我相信你们的话，不需要去找那个妄想症女人。"
                npc "...再见了，半巫师。"
                buff kzl frusta "再见..."
                "那群人走开时，莱尔朝你露出了一个灿烂的笑容。"
                buff lega -sweat sigh "谢谢你。你真是个好骗子。哦，我是在夸你。抱歉，这样说是不是很无礼？"
                show buff wry -sigh
                mc happy "不会，这是我今天听到的最好的赞美之一。"
                show buff datar 
                show palmierproxy kind
                "莱尔微笑着握住你的手，用手指画出一个水之符文。"
                buff amused "这是不会感到疼痛的浇水方法..."
                show buff hister bloom
                show palmierproxy malu bunga
                "你们手牵手一起给植物浇水。"
                "到中午时分完成后，你们决定分开，莱尔向你道谢——他终于对你热情起来了。"
                $ NPC = "???"
                scene bg_black with w20
                if "bunga_bego" in buff_events:
                    if "beku" in quil_events:
                        scene map_infected_f with w20    
                    else:
                        scene map_infected with w20    
                else:
                    if "beku" in quil_events:
                        scene map_frozen with w20
                    else:
                        scene map_all with w20
                jump world_map

            else:
                show palmierproxy smile sweat shock
                npc "你的眼睛在抽搐。你在撒谎。"
                mc side -shock "（该死，我的身体太诚实了！）"
                jump bego_bunga

label bego_bunga:
    stop music
    play sound "sound/effects/api.mp3"
    $ buff_events.append("bunga_bego")
    $ NPC = "男孩"
    npc "净化这个区域！" with vpunch
    mc kzl shock "等等，什么？！"
    buff keluh shock "小心！"
    play sound "sound/effects/explode.mp3"
    scene tmn_ujung with flashbulb
    "一个年轻学生的手中突然冒出一个狂暴的火球。莱尔扑倒你，躲开了那个射向你身后花朵的火球。"
    play sound "sound/effects/burning.mp3"
    $ NPC = "女孩"
    npc "白痴，你干嘛这么做？！"
    "一个学生大喊道，对朋友的突然行为感到愤怒。"
    $ NPC = "男孩"
    npc "我以为这样会有帮助？"
    $ NPC = "女孩"
    npc "你对这些花一无所知吗？！"
    "当他们争吵时，你注意到那朵花在火焰消退后正在迅速生长。"
    play sound "sound/effects/vine.wav"
    play music "sound/effects/panic.mp3"
    scene gendong with dissolve
    galleryunlock gendong
    "它不断生长，直到它的根系大小堪比一棵树。"
    buff "跑..."
    show side_p f at pic
    mc "什么？"
    play sound "sound/effects/tile.mp3"
    hide side_p
    buff "我说跑！"
    show side_p s at pic
    mc "嘿！"
    hide side_p
    stop sound
    "莱尔毫无预警地拉着你的手，枝条和荆棘疯狂生长，缠绕着整个区域，包括花园周围的一些学生。"
    buff "跑，如果你想活命的话。"
    "他平静地说道，而你周围的其他人都在尖叫，仿佛世界末日来临。"
    $ NPC = "学生们"
    npc "什么——啊啊啊！"
    npc "快跑！"
    stop music
    play sound "sound/effects/vine.wav"
    scene rose_panic with fade
    "现在所有人都在为自己的生命而奔跑。种植园不断生长，直到它的玫瑰缠绕在拱门上，完全阻挡了整个花园的入口。"
    "你之所以能逃脱，只是因为中途莱尔觉得你跑得太慢了，为了你的安全把你扛在肩上。"
    "一些学生就没那么幸运了。"
    "巨大的花墙没有留下任何入口。几个学生被藤蔓拉了进去，勉强避免被完全吞没在玫瑰海中。"
    play music "MUSIC/MusMus-BGM-049.mp3"
    show priest pissed at center with dissolve:
        yoffset 200
    dog frusta "这——这是怎么回事？！"
    
    if girl:
        show palmierproxy chill sad at left with dissolve:
            yoffset 40
    else:
        show palmierproxy chill sad at left with dissolve:
            yoffset 100
    show buff sad sweat at right with dissolve:
        yoffset 770
    mc side frusta "迪特里希。"
    dog kzl frusta "你——唉，为什么总是你？"
    buff keluh frusta "迪特里希先生，这不是我们干的。好吧，部分是我们的错，但是——"
    show buff eh shock
    show palmierproxy ow sweat shock
    dog bleh sigh "哦，闭嘴，不然我就割掉你的舌头！"
    buff sad -shock "我的...我的舌头？！"
    play sound "sound/effects/bump.mp3"
    mc kzl frusta "嘘！" with vpunch
    show palmierproxy confused sigh
    "你踢了迪特里希的小腿，因为他失态了。这些花的景象一定让他的伪装崩溃了。"
    dog glad -sigh "啊，原谅我，年轻人。恐怕这景象动摇了我的信念。"
    dog sad "我的意思是，你的舌头没事吧？还有你其他地方也没事吧？"
    buff wry "我，呃，是的。我没事。"
    show buff sad
    dog sly "你跑得真快，在藤蔓追赶你们时还能这样扛着[povname]。"
    dog side "你其他的同学就没那么幸运了。"
    dog sad apa "喂——？！里面的人都还好吗？"
    "迪特里希对着巨大的灌木丛大声喊道。里面传来了微弱的求救声——当他们听到迪特里希的呼喊时，还能看到一两个肢体在挥动。"
    dog side sigh "我们需要把他们救出来，最好不要再砍掉花的任何部分。"
    dog ramah "[povname]，帮我用风之符文移动这些叶子。"
    mc side -sigh "但是先生，我..."
    mc ow "...我这么做的话，手可能会流血。"
    "你低声说道，回想起上次使用符文的情景。"
    dog grin cling "我知道。"
    "迪特里希露出了他标志性的残酷笑容。"
    dog sly -cling "就当是对你给我们造成这么多麻烦的惩罚吧。"
    mc pissed frusta "嗯嗯。"
    buff keluh "呃，我会帮忙把我们找到的学生都拉出来的。"
    show buff frown 
    dog evil "那真是太感谢了，莱尔。我们开始吧。"
    scene rose_panic with dissolve
    play sound "sound/effects/slashkut.wav"
    queue sound "sound/effects/slashkut.wav"
    "学生们一个接一个地逃离了这片叶子构成的地狱。"
    "到了傍晚，你设法救出了大约十名学生，然后血开始从你的手套中渗出。"
    "你皱了皱眉，但试图对莱尔隐藏你的伤口。那些受惊的学生在被拉进这个男人强壮的臂膀时向他道谢。"
    $ NPC = "女孩"
    npc "谢谢你...呜呜...我以为我要死在里面了。"
    show priest glad at left with dissolve:
        xzoom -1.0
        yoffset 200
    if girl:
        show palmierproxy chill sad at right with dissolve:
            yoffset 40
    else:
        show palmierproxy chill sad at right with dissolve:
            yoffset 100
    
    dog "去医务室吧，孩子。我已经告诉海德温女士发生的事了。我相信她有东西可以让你们平静下来。"
    mc side tanya "...大麻？"
    show palmierproxy confused -tanya
    dog evil cling "啊哈，当然不是。他们需要更强力的东西来应对这种情况。"
    dog side frusta"最好是能让他们完全忘记的东西。[povname]，你让我们陷入了相当棘手的困境。"
    dog bleh "你很幸运，校长今天去教堂办事了，不过我还是得做那个可怜虫，写报告汇报这一切。"
    mc rajuk "我愿意接受任何惩罚。哪怕是开除。"
    mc ha "（我是说，如果我真的被开除了，至少我就不用再继续这个假扮学生的闹剧了——）"
    dog evil cling "哦。开除对你来说反而是件好事，是吗？"
    mc chill side frusta "该死。"
    dog sad sigh "我稍后再处理这件事。"
    if "help_me" in my_events:
        dog side -sigh "今晚我们要对付梅扎。最好专注于那个。"
        dog evil "希望你在真正的战场上表现得比在学校里好，[povname]。"
        mc kzl -sweat -frusta "我会的。"
        mc side "（我必须做到。）"
    dog laugh -sigh "不过现在，你应该去帮助那边的巫师混血儿。"
    hide priest with dissolve
    show palmierproxy at left with move
    show buff sad sweat at right with moveinright:
        yoffset 770
    "你瞥向左边，看到莱尔被一群女孩包围了。她们每个人都在恳求他把自己抱到医务室。"
    $ NPC = "女孩"
    npc "你能抱我吗？我觉得我的脚踝扭伤了。"
    $ NPC = "娘炮"
    npc "排队去，贱人，我的脚被压碎了！"
    $ NPC = "女孩"
    npc "才没有，只是肿了而已，你这个骗子！"
    buff hister "呃，你们两个能不能请——"
    buff sad sigh "[povname]，救命！"
    mc mean cling "我来帮你，兄弟。"
    show palmierproxy happy blush bunga
    show buff eh both shock
    "你露出最好的微笑，成功说服了一些学生自己走路，不再为谁能被莱尔结实的肌肉环抱而争吵。"
    play sound "sound/effects/walk.mp3"
    scene uks with fade
    "最后，只有两个女孩因为真的扭伤了脚踝而需要被抱到医务室。"
    "你不禁钦佩莱尔，他一只手抱着一个女孩，另一个则被背在背上。两个人在他怀里似乎都轻如鸿毛。"
    scene bg_black with circleirisin
    $ morning = False
    $ afternoon = False
    $ evening = True
    $ night = False
    scene tgh_mlm_crowd with circleirisout
    "当你回到宿舍时，学生们谈论的只有那件花朵事件，但你对这种闲言碎语毫无兴趣。"
    "因为你知道，今晚等待你的可能会是更糟糕的事。"
    show tom chill ha at center with dissolve:
        yoffset 190
    show quil skul amused at right with moveinright:
        yoffset 200
    show red point grin behind tom at left with moveinleft:
        yoffset 330
    red amused apa "听说你今天引发了末日。"
    show side_p he at pic
    show red sigh
    mc "人们都这么说吗？"
    hide side_p
    quil err frusta "伊瓦尔的花常常与死亡联系在一起。真是大惊小怪。老实说，我们只需要一个园丁就够了。"
    show quil bingung
    tom hip kzl blow "同意。没必要这么悲观和沮丧。不过我确实好奇你是怎么得到这种花的。"
    show side_p w at pic
    mc "哦，你知道的，到处都有。况且，我们今晚不是应该专注于其他事情吗？"
    hide side_p
    red chin ew sweat frusta "呃...所以我们还是要这么做，是吗？我本希望这场花朵骚动能改变你的主意。"
    show red wry sigh
    quil talk "塞恩，我们太固执和愚蠢了，不会那样做的。现在来吧。"
    show tom calm blow
    show red sayang -sweat
    quil flashy wink cling "我们有个巫师要杀。"
    stop music
    scene bg_black with w20
    jump meyza_fight

label buff_fish1:
    play music "MUSIC/MusMus-BGM-022.mp3"
    scene lake with dissolve
    $ buff_events.append("fishdate")
    show buff frown at right with dissolve:
        yoffset 770
    if girl:
        show palmierproxy chill happy at left with dissolve:
            yoffset 40
    else:
        show palmierproxy chill happy at left with dissolve:
            yoffset 100
    mc "莱尔！"
    show palmierproxy kind
    if "desa" in buff_events:
        buff amused shock "哦，[povname]。嗨，什么风把你吹来了？"
        show buff datar -shock
        if "rooted" in buff_events:
            mc wry "（哦，看来他在我们访问村庄后心情平和了不少。这很好。）"
    else:    
        if "rooted" in buff_events and "bunga_bego" not in buff_events:
            buff keluh frusta "[povname]。你在这里做什么？"
            buff kzl -frusta "你给花浇水了吗？"
            mc smile "我浇了！"
            mc panik "（如果我说没浇，你肯定不会让我靠近你的。）"
            show palmierproxy kind
            buff frown apa "那么，你来这里做什么？"
            mc "我要去钓些鱼。有个学生需要我帮忙抓两条小丑鱼。"
            buff kzl frusta "我明白了，那我就不打扰你了。"
            play sound "sound/effects/tile.mp3"
            hide buff with dissolve
            "莱尔没有多说什么就走开了，几乎是跑着上了楼梯。"
            show palmierproxy scratch confused sweat at center with move
            mc side "他真的那么讨厌我吗？我该怎么做才能让他对我有好感呢？"
            scene map_lake with dissolve
            $ NPC = "???"
            jump map_lake
        else:
            buff amused shock "哦，[povname]。你来这里做什么？"
    buff datar apa "钓鱼？"
    mc smile "是的。我要去钓些鱼。有个学生需要我帮忙抓两条小丑鱼。"
    buff eh sweat shock "哦，你在帮助一个学生，这...很善良啊。"
    show buff hister -sweat -shock
    mc kzl sweat frusta "别露出那么惊讶的表情！"
    if "bunga_bego" in buff_events:
        buff wry sigh "对不起。"
        buff talk -sigh "这个学生是不是那个在花事件之前经常在花园里闲逛的那个？"
        show buff datar
        mc deject -sweat -frusta "就是他。我不确定他现在在哪里。"
        buff frown "我想他有时会来这里，试图钓鱼但总是失败。鱼不喜欢他。"
        mc kind "哦，所以你现在能听懂鱼说话了？"
        buff laugh "有一点。"
    else:
        buff laugh sweat "抱歉，但这里大多数学生并不会主动伸出援手。"
        show buff datar -sweat
    buff datar apa "你擅长钓鱼吗？"
    mc hister "我还行。不过抓小丑鱼需要的运气比技巧多一些。"
    buff laugh -apa "没错，你想要我帮忙吗？"
    show buff datar
    mc ha tanya "嗯？我是说，当然可以。怎么，你是什么鱼语者吗？"
    show palmierproxy frown shock
    buff hister "差不多吧。"
    galleryunlock bup_lake
    show bup_lake with dissolve:
        truecenter zoom 2.0
        easein 2.0 truecenter zoom 1.0
    play sound "sound/effects/cloth.mp3"
    show side_p he at pic
    mc "嗯？等等，你为什么脱衣服？"
    hide side_p
    buff "我不喜欢用鱼竿钓鱼。"
    play sound "sound/effects/splash.wav"
    scene lake with rain1
    "说完，莱尔一头扎进了水里。"
    "他溅起的水花打湿了你的裤子，浸透了你的鞋子。"
    show side_p he at pic
    mc "什么——？！"
    hide side_p
    "几分钟过后，莱尔从水中冒出来，手里抓着两条扭动的小丑鱼。"
    buff "给你。"
    $ InvItem(*item_clown).pickup(2)
    "他把小丑鱼放在你手中后，重新穿上了衬衫。"
    show buff wry at right with dissolve:
        yoffset 770
    if girl:
        show palmierproxy chill happy at left with dissolve:
            yoffset 40
    else:
        show palmierproxy chill happy at left with dissolve:
            yoffset 100
    mc laugh shock "你刚才是直接潜水用手抓的吗？"
    show palmierproxy kind -shock
    buff laugh "它们已经很老了，它们说不介意被带到陆地上来。"
    mc confused tanya "你会说鱼语？"
    show palmierproxy frown -tanya
    buff datar sigh "有一点用。"
    show pboy at horzappear
    menu:
        "你是公主吗？":
            hide pboy
            $ putri.points += 5
            buff eh apa "什么？"
            mc hister "我是说，你母亲去世了，你有魔法般的双手。好吧，严格来说这里每个人都有，而且你还能和动物说话！"
            mc flirt cling "你就是个公主！"
            buff hister both -apa "我不太确定那是什么意思，但从你的笑容来看，我猜那是个赞美？"
            mc smile "没错！"
            
        "你就是个小美人鱼！":
            hide pboy
            $ putri.points += 2
            $ honesty += 5
            buff wry sigh "啊哈！我可不确定\'小\'这个词。"
            buff -sigh "而且，我觉得我们脚下的真正美人鱼会对此感到冒犯。"
            mc confused "下面真的有美人鱼？"
            buff laugh "有一两条，我看到它们游过。"
            buff datar "别担心，美人鱼除非被激怒，否则不会攻击人的。"
            

        "触摸他的胸膛":
            hide pboy
            $ curiosity += 5
            $ kindness -= 10
            play sound "sound/effects/cloth.mp3"
            show buff sad shock
            mc malu blush "你真的到处炫耀你的腹肌，是吧？"
            buff keluh sweat frusta "哦，请不要碰我。"
            mc side both shock "哦对，抱歉。"
            mc sad -both -shock "（不能骚扰这个肌肉男孩，明白了。）"
    mc smile "你似乎对这片水域很熟悉。"
    buff laugh blush -frusta "我喜欢这里，这片水域给人一种熟悉的感觉，就像老朋友，或者奶奶。"
    mc confused tanya "奶奶？"
    buff datar sigh "啊，听起来有点奇怪，是吧？我的意思是这片水域让我感觉像家一样……如果这样说得通的话。"
    if kindness >= 40:
        mc wry -tanya "一个你归属的地方。"
        buff laugh -sigh "没错。"
        $ putri.points += 5
    else:
        mc smile -tanya "不太明白，不过你能找到一个让你感觉像家的地方，我想这很不错。"
    
    mc happy bunga "好吧，总之谢谢你的小丑鱼，莱尔。我相信马丁会很感激的。"
    mc smile "（现在我不用任何鱼饵了。）"
    buff datar apa "当然。也许我们可以一起钓鱼？"
    show pboy at horzappear
    menu tlnjg:
        "裸体？" if honesty>=20:
            hide pboy
            $ putri.points += 5
            mc flirt cling "就像你钓鱼时那样？裸体？"
            buff wry both shock "啊，下次我们可以用鱼竿。那次是……我一时冲动。"
            mc hister -cling "我喜欢冲动。也许下次，我会加入你，不过要穿泳装。"
            buff laugh blush bunga "我很乐意。"
        "{s}裸体？{/s}" if honesty<20:
            
            jump tlnjg
        "我很乐意。":
            hide pboy
            mc hister sigh "我很乐意，不过最好不要弄湿。"
            buff wry blush sigh "啊，抱歉。下次我们用鱼竿吧。"
            $ putri.points -= 5
            if putri.points <0:
                $ ibu.points = 0
            mc "一言为定。"
        "还是算了吧？":
            hide pboy
            $ putri.points -= 10
            if putri.points <0:
                $ ibu.points = 0
            mc scratch side frusta "我宁愿不要半裸着跳进湖里，谢谢。"
            buff sad sweat sigh "啊，对-对。对不起。"
            show palmierproxy chill frown -frusta
    mc happy blush bloom "回头见，莱尔！"
    buff laugh blush bunga "再见。"
    scene bg_black with w20
    $ NPC = "???"
    if "bunga_bego" in buff_events:
        if "beku" in quil_events:
            scene map_infected_f with w20    
        else:
            scene map_infected with w20    
    else:
        if "beku" in quil_events:
            scene map_frozen with w20
        else:
            scene map_all with w20
    jump world_map

label lyal_ker_bar:
    play music "MUSIC/MusMus-BGM-022.mp3"
    if "ker_bar" in buff_events:
        scene lake with w20
        show buff datar at right with dissolve:
            yoffset 770
        if girl:
            show palmierproxy chill kind at left with dissolve:
                yoffset 40
        else:
            show palmierproxy chill kind at left with dissolve:
                yoffset 100
        buff laugh blush bloom "你来了。"
        mc happy blush "我当然会来。"
        show palmierproxy kind at center with move
        play sound "sound/effects/cloth.mp3"
        "你看到莱尔正在解开小船与码头的绳索，向你伸出手来帮你登上这艘小船。"
        scene kapal with dissolve
        play sound "sound/effects/splash.wav"
        "你握住他的手，舒适地坐进了船里。莱尔用力划桨，激起阵阵水花。"
        show buff datar at right with dissolve:
            yoffset 770
        if girl:
            show palmierproxy chill kind at left with dissolve:
                yoffset 40
        else:
            show palmierproxy chill kind at left with dissolve:
                yoffset 100
        mc confused tanya "莱纳尔离这里有多远？"
        show palmierproxy kind -tanya
        buff datar -blush -bloom "只有几英里远。真的很近，但同时也很隔绝。"
        buff frown "那里的人...他们对巫师一无所知，但更害怕美人鱼和海妖。"
        buff "塞壬有时会以鸟的形态飞过这片区域，美人鱼偶尔也会出现在岸边，不过从未靠近到足以造成任何伤害。"
        buff hister "这里很美。然而，从远处看，这地方确实显得有些死气沉沉。不知什么原因，植被似乎在这里生长得不太好。"
        buff wry "不过，他们的猪肉确实美味。"
        mc wry "你听起来像个当地人。"
        buff talk "派克带我四处转了转。他正在村子里等我们，大部分货物都已经打包好了。"
        buff laugh "看，我们快到了。"
        scene pulau with flashbulb
        "你转身看到前方的小岛，被山丘和郁郁葱葱的秋叶树环绕。"
        show side_p se at pic
        mc "真美啊。"
        hide side_p
        show side_b skul smile at pic
        buff "我知道。"
        hide side_b

    else:
        scene fishing with fade
        show buff datar at right with dissolve:
            yoffset 770
        if girl:
            show palmierproxy chill kind at left with dissolve:
                yoffset 40
        else:
            show palmierproxy chill kind at left with dissolve:
                yoffset 100
        if not "met_pike" in my_events:
            $ my_events.append("met_pike")
            "你看到莱尔和一个手臂吊着绷带的男人正在与一艘船搏斗。"
            "莱尔正在解开固定船只的绳结。码头上已经打开了几箱鱼，散落得相当随意。"
            "木屑散落一地，还有一些离水的鱼在其中挣扎喘息。"
            mc confused tanya "这里发生了什么？"
            show palmierproxy frown -tanya
            buff eh shock "[povname]，你在这里做什么？"
            show buff frown -shock
            npc "哦，这是你的朋友吗，小子？我还是第一次见到他们呢。"
            buff sad sweat sigh "我们是室友，但是……"
            show buff frown -sweat
            show palmierproxy eiden frusta
            "\'不是朋友\'大概是莱尔想要补充的。"
            npc "室友，是吗？嘿，小家伙，想赚几个金币吗？"
            mc kind -frusta "哦？你有什么想法？"
            $ gold += 50
        else:
            mc smile "派克？"
            "你看到派克和莱尔正在与船只搏斗，派克的手臂明显吊着一个很大的绷带。"
            "莱尔正在解开固定船只的绳结。码头上已经打开了几箱鱼，散落得相当随意。"
            "木屑散落一地，还有一些离水的鱼在其中挣扎喘息。"
            $ NPC = "派克"
            npc "哦，[povname]！来得正是时候，愿意帮老头子一个忙吗？"
            buff sad frusta "派克，我不认为[povname]是最好的——"
            mc happy bunga "你需要什么帮助？"
            show palmierproxy kind
            show buff eh shock
            "你插话道，希望莱尔对你的厌恶没有被注意到。"
            show buff sad -shock
        show side_pike_s at pic
        npc "我正试图把这里的一些鱼运走，和我的岛屿莱纳尔进行交易，然后回到戈莫拉为即将到来的节日供应一些货物。"
        npc "只是我几天前发生了一次意外，摔断了胳膊，所以恐怕帮不了莱尔多少忙。"
        hide side_pike_s
        buff keluh sigh "派克先生，我向你保证，我完全可以自己搬运这些鱼。"
        show side_pike_s at pic
        npc "小子，你可能有力气，但是一点技巧都没有。"
        npc "而你，孩子，看起来有一双适合做细致工作的手。看看那些蜘蛛般纤长的手指！"
        hide side_pike_s
        mc hister bloom "我就当这是夸奖了。当然，我会帮忙的！"
        mc mean cling "（这可能是我讨好莱尔的机会。）"
        show side_pike_s at pic
        npc "太好了！挪一挪，小子！"
        hide side_pike_s
        buff frown sigh "...好吧。"
        scene kapal with dissolve
        "莱尔不情愿地挪了挪，你抓起一两个箱子，挤进了船里。"
        "虽然空间很挤，但你还是设法让自己舒服地坐好，莱尔划着船离开码头，驶向开阔的水域。"
        show side_p se at pic
        mc "莱纳尔离这里有多远？"
        hide side_p
        show side_pike_s at pic
        npc "不远了，孩子。就几英里的路程。"
        npc "我很惊讶你自己还没去过那里。不过话说回来，我猜你们猎人有比参观一个破旧的渔村更重要的事要做。"
        npc "不过，我想你会喜欢那里的。我们那里有全伊格尼亚最好的猪肉，天气也很好。不冷不热。"
        npc "虽然我猜那里的景色可能会让你觉得无聊，到处都是那些刺激你感官的橙色秋叶。"
        hide side_pike_s
        show side_p f at pic
        mc "秋叶？现在不是还是夏天吗？"
        hide side_p
        show side_pike_s at pic
        npc "在我的村子里一直都是秋天，孩子。我也不知道为什么，但无论是冬天的寒冷还是春天的温暖都从未到达那里。"
        npc "有人说这是你们\'巫师的诅咒\'，但说实话，那里的大多数人并不在乎这些事。"
        npc "那里从来没有什么特别的事发生。尤其是那些神神叨叨的巫师勾当。"
        npc "哦，我们到了。"
        hide side_pike_s
        scene pulau with flashbulb
        "派克指着你身后，你转过头去。眼前的景象让你屏住了呼吸。你看到一个被山丘和茂密的秋叶环绕的宁静村庄。"
        show side_p se at pic
        mc "真美啊。"
        hide side_p
    scene labuh with dissolve
    "莱尔发出一声响亮的咕哝声，然后将船停靠在码头附近，如果不是一只温暖的手挡住了冲击，你的头差点撞到木质码头。"
    $ NPC = "???"
    show marg at center with dissolve:
        yalign 1.0
    npc "小心点，莱尔。"
    "一位三十多岁的曲线优美的女性向你露出温暖的微笑。即使只是短暂的一瞥，你也能看出这个女人和派克有某种关系，可能是女儿或侄女。"
    if "ker_bar" in buff_events:
        "派克就在她身后，他的右臂被紧紧地固定在吊带里。"
    $ NPC = "派克"
    show side_pike_s at pic
    npc "玛格斯，我看你总是这么照顾人啊。"
    hide side_pike_s
    $ NPC = "玛格丽特"
    npc "当然，爸爸！"
    hide marg with dissolve
    show buff datar at right with dissolve:
            yoffset 770
    if girl:
        show palmierproxy chill kind at left with dissolve:
            yoffset 40
    else:
        show palmierproxy chill kind at left with dissolve:
            yoffset 100
    buff talk blush "你好，玛格丽特。"
    $ buff_events.append("desa")
    "莱尔害羞地向她打招呼，走出船，脸颊泛着粉红色与她握手。"
    mc scratch panik "（所以这就是他喜欢的类型？熟女？）"
    show palmierproxy chill frown shock
    show side_marg at pic
    npc "莱尔！孩子们都在问起你。他们想你了。"
    hide side_marg
    buff hister "啊，抱歉我最近没怎么去孤儿院。最近为即将到来的节日忙得不可开交。"
    show buff datar 
    show side_marg at pic
    npc "别担心，我也很期待节日呢！"
    npc "你知道吗，我还记得他们以前把它叫做交配节。"
    npc "上次我和丈夫度过了一个非常有趣的日子，我迫不及待想看看这次会是什么样子！"
    hide side_marg
    mc ha tanya "抱歉，你能再说一遍那个交配节的事吗？"
    show palmierproxy confused sweat shock
    show side_marg at pic
    npc "哦，这个面色苍白的孩子是谁？亲爱的，你需要多晒晒太阳。"
    hide side_marg
    mc sad -shock "对不起，你说什么？"
    buff talk -blush "哦。这是我的室友，[povname]。"
    show buff datar
    mc smile -sweat "我是来帮忙筹备节日的。觉得莱尔和派克可能需要帮助。"
    $ NPC = "派克"
    show side_pike_f at pic
    npc "看来我的年纪真的大了，玛格斯。顺便问一下，孤儿院那边怎么样，没有孩子逃跑吧？"
    hide side_pike_f
    show buff sad
    $ NPC = "玛格丽特"
    show side_marg at pic
    npc "今天没有。谢天谢地，不过我想彼得斯夫妇提到汤姆失踪了，但你知道那个男孩可能只是在外面和哪个女孩卿卿我我呢。"
    hide side_marg
    mc apa sweat tanya "跑掉？"
    $ NPC = "派克"
    show side_pike_f at pic
    npc "哦，孤儿院的孩子们有时会失踪。但他们通常过一段时间就会回来。叛逆的青少年，你懂的。"
    hide side_pike_f
    mc confused -sweat -tanya"哦，这是经常发生的事吗？"
    $ NPC = "玛格丽特"
    show side_marg at pic
    npc "在莱纳尔这里是的。我亲自试过让教会介入，但他们从来不听我们这个小岛上的人说话。"
    npc "我听说史密斯家的运气好一些。他们的女儿也失踪了，但她的朋友们认为她私奔了。"
    npc "14岁就私奔，这不是更可怕吗？天哪！"
    hide side_marg
    buff keluh sweat "凯拉，对吧？我也不觉得她是那种会私奔的类型。"
    buff "哦，我知道她的父母让我不要这么做，但我还是向校长求助了，可他只说会联系教会。"
    buff sad sigh "对不起。"
    show side_marg at pic
    npc "哦，不，你为什么要道歉呢？有时候事情就是这样，亲爱的。总之，我们去拿那些箱子吧，好吗？"
    hide side_marg
    show buff wry -sweat
    show side_marg at pic
    npc "哦，我还会给你拿些亚麻籽油，[povname]，是这个名字吧？你会喜欢的，真的能帮助快速晒黑。"
    npc "你的皮肤会很快变得有活力的。"
    hide side_marg
    mc ow sweat shock "啊，不用麻烦了，哇——！"
    play sound "sound/effects/cloth.mp3"
    scene desa_center with dissolve
    "玛格丽特用力一拉，把你拽进了村子。莱尔和派克跟在后面。"
    play sound "sound/effects/tile.mp3"
    $ NPC = "女孩"
    show kid1 at left with dissolve:
        yalign 1.0
        xalign 0.2
    npc "快来，表演马上就要开始了！"
    show kid2 at right with dissolve:
        yalign 1.0
        xalign 0.8
    npc "啊，等等我！"
    stop sound
    show har at center with dissolve
    "当你走近村子时，你看到一群孩子围着一个矮小但引人注目的戴着大眼镜的男人。"
    "那个男人举着玩具木偶，几十个孩子乖巧地坐在他周围。"
    "欢快的音乐响起，一个女人的录音声开始叙述这个场景。"
    show side_p f at pic
    mc "木偶戏？"
    hide side_p
    $ NPC = "玛格丽特"
    show side_marg at pic
    npc "哦，是的！那是欧文。他在这里很受孩子们欢迎。"
    npc "他是个外来者，但他已经在我们村子里待了将近三个月了。"
    npc "他说他在这里寻找草药来治疗他的病症。"
    hide side_marg
    show side_p f at pic
    mc "病症？"
    hide side_p
    show side_marg at pic
    npc "这个可怜的小伙子是个哑巴。"
    hide side_marg
    show side_p f at pic
    mc "哦。有草药可以治好这个吗？"
    hide side_p
    show side_marg at pic
    npc "嗯，他是这么说的。他来自卡斯特里，所以他们的医学知识比我们先进得多。"
    npc "我决定不去质疑这一点，反正对我来说也没什么意义。"
    hide side_marg
    $ NPC = "女孩"
    hide har with dissolve 
    show buff laugh bloom at center with dissolve:
        yoffset 770
    npc "哦，是莱尔！嘿，史蒂夫，是莱尔！"
    "当莱尔出现时，大多数孩子都离开了表演，转而围着莱尔，要求被抱起来。莱尔满足了他们的要求。"
    "他一个接一个地抱起他们，然后让三个小孩爬上他的肩膀和头顶。"
    "从眼角余光中，你可以看到欧文对这种情况并不满意。他的表演只剩下一两个孩子在观看。"
    "有一个孩子引起了你的注意。你可以看出他显然是个盲童，正用他朋友的手引导他走向人群。"
    $ NPC = "史蒂夫"
    hide kid1 with dissolve
    show kid_blind at left with dissolve:
        yalign 1.0
        xalign 0.2
    npc "我听到莱尔在笑，他真的在这里吗？"
    $ NPC = "女孩"
    npc "是的，他在这里。而且他带来了一个朋友！蓝色的那个！"
    show side_p se at pic
    mc "（蓝色的，是因为制服吗？）"
    hide side_p
    scene desa_center with dissolve
    show kid1 at center with dissolve
    npc "蓝色！"
    "一个小孩指着你，同时伸出双臂向天空示意要被抱起来。"
    show buff kzl cling at right with dissolve:
        yoffset 770
    "莱尔警惕地盯着你，好像害怕你会对那个孩子做什么。"
    show pboy at horzappear
    menu:
        "抱起孩子":
            hide pboy
            if girl:
                show palmierproxy chill wry blush bunga at left with dissolve:
                    yoffset 40
            else:
                show palmierproxy chill wry blush bunga at left with dissolve:
                    yoffset 100
            npc "耶！"
            $ kindness += 5
            $ honesty -= 10
            show buff laugh bunga
            hide kid1 with dissolve
            "当你上下颠着她时，孩子兴奋地尖叫起来。"
            mc hister "（这里的孩子们太没有防备心了。你知道吗，我可以轻易绑架你。）"
            buff wry sigh "这附近的犯罪率真的很低，所以他们不太了解外面的情况。"
            mc apa shock "哦..."
            mc scratch panik sweat -shock "（我把那部分说出声了吗？）"
            show palmierproxy chill kind -sweat
            "你给那个女孩快速转了一圈后，把她放回地上。她兴奋地笑着，然后加入其他孩子玩捉迷藏游戏。"
        "揉揉她的头发":
            hide pboy
            if girl:
                show palmierproxy scratch wry at left with dissolve:
                    yoffset 40
            else:
                show palmierproxy scratch wry at left with dissolve:
                    yoffset 100
            $ honesty += 15
            $ kindness -= 5
            mc "我恐怕没有莱尔那么强壮，孩子。"
            mc eiden sweat "我觉得我试着把你抱起来可能会拉伤肌肉。"
            show palmierproxy frown shock
            npc "哦...所以你又弱又老？"
            show buff wry sigh
            mc chill kzl sweat frusta "（这个调皮的小鬼—）"
            buff talk -sigh "我只是比大多数人强壮一些，西西。来，骑到我肩膀上吧。"
            $ NPC = "西西"
            npc "耶！"
            hide kid1 with dissolve
            show buff laugh blush bunga 
            show palmierproxy wry -sweat -frusta
            "莱尔抱起西西开始旋转。西西兴奋地笑着，然后莱尔把她和其他孩子一起放下。"
            $ NPC = "派克"
            show side_pike_s at pic
            npc "好了，够了，让大人们工作吧，好吗孩子们？"
            hide side_pike_s
            $ NPC = "孩子们"
            npc "是的，派克先生！"
            "派克催促他们自己去玩，他们就散开去玩捉迷藏游戏了。"
        "走开":
            hide pboy
            if girl:
                show palmierproxy chill frown at left with dissolve:
                    yoffset 40
            else:
                show palmierproxy chill frown at left with dissolve:
                    yoffset 100
            $ honesty += 5
            $ curiosity -= 5
            $ buff_events.append("cece")
            $ kindness -= 15
            mc deject sigh "（我不会跟陌生人的孩子胡闹。）"
            "当你无视她时，孩子哭了起来。显然她不习惯这样的冷漠。"
            buff talk "来，我来抱你，西西。"
            show buff laugh blush bunga
            hide kid1 with dissolve
            "莱尔抱起西西开始旋转。西西兴奋地笑着，然后莱尔把她和其他孩子一起放下。"
            $ NPC = "派克"
            show side_pike_s at pic
            npc "好了，够了，让大人们工作吧，好吗孩子们？"
            hide side_pike_s
            $ NPC = "孩子们"
            npc "是的，派克先生！"
            "派克催促他们自己去玩，他们就散开去玩捉迷藏游戏了。"
    mc chill happy blush tanya "你在这里很受欢迎啊，是不是？"
    show buff wry blush shock
    "莱尔听到这话脸上露出了灿烂的笑容。"
    show buff hister bloom
    buff "这里的孩子们不知道巫师的事，所以他们不怕我的眼睛。"
    show palmierproxy frown
    buff wry sigh "我想这也是欧文留在这里的原因。虽然我不太确定他是什么。"
    buff eh -blush apa "他不是巫师，至少我不这么认为，但...也许他和我一样是个混血儿？"
    show buff frown -apa
    mc confused -tanya "欧文？那个木偶戏演员？"
    buff eh "是的，他的眼睛很特别。"
    show har at center with dissolve:
        yalign 1.0
    "你厚颜无耻地扭头看向欧文，盯着他的眼睛。你注意到他的眼睛有一种独特的彩虹色调。"
    show har confused apa
    "欧文注意到你的注视，歪了歪头，在他的书上写了一个大大的问号，然后展示给你看。"
    mc side both shock "啊对不起，我不是有意盯着看的！"
    play sound "sound/effects/walk.mp3"
    scene pasar with dissolve
    "你和莱尔尴尬地低下头，走向已经在等待的派克和玛格丽特所在的市场，向当地人打着招呼。"
    show side_p f at pic
    mc "（我感觉我以前见过他的眼睛，但在哪里呢？）"
    hide side_p
    show buff frown at right with dissolve:
            yoffset 770
    if girl:
        show palmierproxy chill kzl shock at left with dissolve:
            yoffset 40
    else:
        show palmierproxy chill kzl shock at left with dissolve:
            yoffset 100
    play sound "sound/effects/bump.mp3"
    "当你陷入沉思时，莱尔开始一箱接一箱地把鱼递给你。"
    "你没料到会有这么重的负担，吓得往后缩了一下。"
    mc ow sweat frusta "哎哟！"
    buff keluh sweat apa "哦，抱歉，是不是太重了？"
    show pboy at horzappear
    menu:
        "你要把我累死了！":
            hide pboy
            $ honesty += 10
            $ curiosity -= 10
            buff sad shock "啊，抱歉！"
            show palmierproxy wry sigh
            "莱尔一个接一个地从你手中拿走重物。这些重量似乎并没有让他感到太困扰。"
            
        "不，我没事。（谎言）" if not girl:
            hide pboy
            $ honesty -= 10
            $ curiosity -= 10
            show palmierproxy smile
            buff eh "...你确定吗？"
            mc happy "哈！当然了。"
            mc panik sigh "（我是说，我得表现得很酷，如果我不至少搬一半他搬的东西，我看起来就像个彻底的懦夫！）"
            buff wry -sweat sigh "好吧，如果你需要帮助就告诉我。我知道我比大多数人都强壮。"
            mc smile frusta "我也一样，快走吧！继续前进！"
            play sound "sound/effects/crash.mp3"
            scene pasar with vpunch
            "你才走了四步就掉了一半的箱子，莱尔在它们摔到地上之前全都接住了。"
            "你道了歉。莱尔只是对这个意外笑了笑，从你手中拿走了几个箱子，你们俩并肩走回码头。"

        "我们不能用符文吗？！":
            hide pboy
            $ curiosity += 5
            mc ew frusta "我们没有任何符文可以帮忙吗？风符文怎么样？"
            buff datar -sweat shock "哦，实际上，我想我们可以让它起作用。"
            show palmierproxy frown shock
            show buff laugh
            "放下一两个桶后，莱尔开始在箱子上画风符文。"
            play sound "sound/effects/swosh.mp3"
            show buff wry sigh
            show palmierproxy kind blush -shock
            "箱子一个接一个地开始漂浮起来，这让你更容易把它们引导到船上。"
            mc hister bloom "我爱魔法。"
            buff laugh sigh "我也是……至少在好人手里的时候是这样。"
            show buff wry -sigh
            mc deject -blush -bloom "（啊，看来他还记得他的父亲。）"
    scene jurney with w33
    show buff datar at center with dissolve:
        yoffset 770
    "当莱尔走回码头时，可以看到许多年轻男女都在偷看他。"
    "你也不能怪他们，他确实很吸引眼球。"
    "看着他的背影，你不禁觉得他更适合当一个渔夫，而不是猎巫人。"
    "你想知道为什么他不干脆退学去和派克一起工作。"
    "说起来，莱尔是怎么进入你们学校的呢？"
    "关于你的室友，有太多你不知道的事。有太多谜题等待揭开。"
    buff talk apa "准备好出发了吗？"
    show buff datar -apa
    "他的问题把你拉回现实。"
    if girl:
        show palmierproxy chill confused at left with dissolve:
            yoffset 40
    else:
        show palmierproxy chill confused at left with dissolve:
            yoffset 100
    show buff frown at right with move
    mc "啊……好的？"
    buff amused "听起来像个问句。你在想什么吗？"
    show buff datar
    mc deject "嗯……"
    show pboy at horzappear
    menu:
        "我想探索更多。":
            hide pboy
            $ curiosity += 5
            $ kindness -= 5
            show palmierproxy frown 
            buff frown sigh "哦，好吧，恐怕我们今天有点赶时间。"
            if putri.points >= 15:
                buff laugh -sigh "不过如果你愿意，我随时可以和你一起回来，带你四处看看。"
                mc wry "真的吗？我以为你不喜欢我？"
                if "rooted" in buff_events:
                    
                    buff wry "你其实还不错..."
                else:
                    buff sad sweat frusta "我从没那么说过。我只是有点害怕而已。害怕你会对我有什么反应..."
                    show palmierproxy wry shock
                    buff hister -sweat -frusta "但事实证明你一点也不可怕。奎尔才是真正可怕的那个。"
                    mc hister bloom "哈哈！我愿意付钱看你当着他的面说这话。拜托了？"
                    buff wry sigh "也许有一天吧。"
            else:
                buff frown -sigh "不过你随时都可以探索这个村子，他们的港口总是开放的。"
                mc smile "我可能需要一个向导..."
                buff kzl frusta "那就去问派克吧。"
                mc huh "但你可以做我的向导。"
                buff keluh sigh "我不想。"
                mc grit frusta "太过分了！"
                buff sad apa "...你为什么这么执着要和我做朋友？"
                buff kzl -apa "其他人都怕我。这很...可疑。"
                if "rooted" in buff_events:
                    buff frusta "尤其是在你做了那些事之后。"
                    mc ha sweat "我发誓我为那朵花感到抱歉，好吗？我该怎么做才能弥补过去？"
                    if "bunga_bego" in buff_events:
                        buff frown sigh "帮我想办法除掉它？虽然我怀疑我们能做到，看它长得那么大了。"
                else:
                    mc side sweat sigh "莱尔，我不是来伤害你的..."
                    buff sad sigh "我知道，但我还是忍不住有时会起疑心。抱歉。"   
            mc kind blush tanya "我打赌你已经探索过这里的每一个角落了。"
            show palmierproxy -tanya
            buff datar blush sigh "是的，至少大部分地方。很多建筑都是空的。尤其是山上的那座教堂。"
            buff eh -blush -sigh "这里的村民不信仰科尔。教堂的牌匾上写着这是艾欧教堂。"     
            buff frown "我父亲曾经跟我提过她。她是海洋女巫，或者说曾经是。"
            mc confused -blush "曾经是？"
            buff eh "传说教堂困住了她，现在她只能在梦中出现。这是个幻想。"
            buff sad sigh "这是我父亲说的，不过我...我不会太相信他。"
            mc frown "为什么？他经常对你撒谎吗？"
            buff frown -sigh "不完全是。更像是他隐瞒了重要的部分。"
            buff "他不说谎，但也不完全诚实。"
            mc confused "我明白了。"
            mc rajuk sweat "（下次见到伊瓦尔时我应该记住这一点。）"
            buff frown sigh "...我们到了。"
            scene labuh with dissolve
            "到达码头后，你们迅速将货物从船上搬到附近的当地人那里。"
            "一个当地人狠狠地瞪了莱尔一眼，但当你向他露出你标志性的微笑时，他什么也没说。"
            "总的来说，运输进行得相当顺利，你比预想的完成得更早。"
            "你回到宿舍，准备休息一晚。"
            stop music
            scene bg_black with w20
            scene lor_mlm with w20
            play music "MUSIC/MusMus-BGM-082.mp3"
            jump ur_room



        "你为什么要当猎巫人？":
            hide pboy
            mc apa tanya "你为什么要入学这所学院？我是说...你是个巫师混血。"
            show palmierproxy confused
            buff sad sweat frusta "这其实不是我的选择。在逃离我父亲之后，我跑到了最近的城镇。"
            buff keluh sigh "那就是这里，伊格尼亚。镇上的人决定我应该通过成为猎巫人来证明我的忠诚。"
            buff frown -sweat -sigh "作为交换，他们会把我当作教会的孤儿来照顾。"
            mc kzl cling "我明白了，所以他们威胁你？"
            buff keluh sweat shock "不是那样——"
            mc rajuk tanya "他们给你其他选择了吗？"
            buff sad sigh "嗯，他们确实说我可以离开去卡斯特里，但他们可能会在那里把我当奴隶卖掉，所以——"
            mc kzl -tanya "所以他们威胁你。"
            buff keluh frusta "我学到了永远不要期待善意。尤其是如果你是个巫师的话。"
            show buff sad -frusta
            mc sad "但你也是半个人类。"

        "你属于这里。":
            hide pboy
            $ kindness += 5
            $ curiosity -= 10
            buff wry blush shock "派克也这么说。"
            buff talk -shock "我确实喜欢大海，还有园艺。虽然派克说在这片土地上做这些是没用的。"
            buff laugh bloom "不过，要是能有自己的一片土地或一条船，种植或捕捞自己的食物，那该多好啊。"
            mc happy "你确实给人一种迷人的农场男孩的感觉。很适合你。那么，是什么阻止了你？"
            show palmierproxy frown shock
            buff eh sweat apa "抱歉？"
            mc smile -shock "就退学然后成为一个农民，或者渔夫？"
            buff sad sigh "我不能，我向教会许下了承诺。"
            mc scratch confused "什么承诺？"
            buff eh -sigh "当我在这里寻求庇护时，教会告诉我，只要我通过成为猎巫人来证明我的忠诚，我就可以留下来。"
            buff frown -sweat "作为交换，他们会把我当作教会的孤儿来照顾。"
            mc apa sweat "所以你被困在这里了。"
            buff wry "至少还有四年。但没关系……只要我完成了我的部分，他们就会让我离开。"
            mc chill rajuk sigh "……你真的相信吗？"
            buff sad "嗯——"
            show palmierproxy kzl -sigh
            "莱尔之后沉默了。当然他不相信。即使是你也知道教会在骗他。"
            "在你看到这里发生的一切之后，你也能预料到这一点。"
    mc happy blush "你知道，在我来的地方，渔民和农民是非常抢手的。"
    mc smile "那里也没有巫师会来追捕你。"
    buff eh sweat shock "没有巫师？怎么可能？你住在沃特克吗？是因为这个原因吗？"
    mc scratch panik sweat "啊，不是。我住在……别的地方，但我现在还不能回去。"
    buff frown -sweat -shock "我明白了。"
    buff talk "我能和你一起去吗？"
    mc sad sweat shock "什么？"
    buff wry sigh "当你能回家的时候……我能去拜访你吗？"
    mc side -shock "哦..."
    mc frusta "（他能吗？我是说，奎尔和我甚至还没有讨论过送我回家的事。）"
    mc frown "（但是我的意思是，有洞就有路，对吧？只要通道打开，我大概就能带一个朋友。）"
    mc rajuk "（……对吧？）"
    mc chill smile -sweat -frusta "嗯……"
    show pboy at horzappear
    menu:
        "当然。":
            hide pboy
            buff hister blush apa"约定好了？"
            $ buff_events.append("pinky")
            show buff amused at center with move
            show palmierproxy apa sweat shock
            "莱尔伸出了小拇指，显然希望你能握住它。"
            "你勉强地与他拉钩。莱尔一边哼着一首熟悉的曲子，一边上下摇晃着你们的手指。"
            show palmierproxy wry sigh
            buff laugh bunga "今晚我的心敞开，尽管我的唇紧闭。"
            buff talk "承诺已经许下，真实响亮，我不会对你食言。"
            buff hister "现在这就是正式的约定了！"
            "满意地，他松开了你们的手指，笑容满面。"
            mc panik both "（啊...我的心。如此天真，如此纯洁！）"
            mc smile -sweat blush bloom "永远别改变，莱尔。"
            buff datar -blush apa "嗯？"
            scene kapal with fade
            "心情好转的莱尔迅速划向戈莫拉，你们一路上聊着各自的钓鱼成就和分享烹饪食谱。"
            "你希望一旦这个巫师的事情结束，你真的可以带莱尔一起走。他是个好人，对这个世界来说太过温柔了。"

        "我觉得那是不可能的。":
            hide pboy
            show palmierproxy side sweat
            buff sad sweat frusta "哦，我明白了。" 
            scene kapal with fade
            "莱尔沮丧地缩回船里，划向戈莫拉。"
    scene riv_riv with w33
    "到达码头后，你们迅速将货物从船上搬到附近的当地人那里。"
    "一个当地人狠狠地瞪了莱尔一眼，但当你露出你那标志性的微笑时，他什么也没说。"
    "总的来说，运输进行得相当顺利，你比预想的完成得更早。"
    "你回到宿舍，准备休息一晚。"
    stop music
    scene bg_black with w20
    scene lor_mlm with w20
    play music "MUSIC/MusMus-BGM-082.mp3"
    jump ur_room

label buff_nyari_baju:
    play sound "sound/effects/door.mp3"
    play music "MUSIC/MusMus-BGM-097.mp3"
    scene kmr_malam with fade
    show buff sad at center with dissolve:
        yoffset 770
    "当你走进房间时，你惊讶地发现莱尔已经醒了，正在窗边的科尔祭坛附近来回踱步。"
    buff eh sweat shock "哦，[povname]。我...我一直在等你。"
    show buff frown -shock at right with move
    if girl:
        show palmierproxy chill kind at left with dissolve:
            yoffset 40
    else:
        show palmierproxy chill kind at left with dissolve:
            yoffset 100
    mc tanya "我看得出来，怎么了？你平常这个时候不会起床的。"
    if "surat" in buff_events:
        buff confused sigh "我知道。有件事我想问你，但是，呃，如果你不愿意的话也不用勉强——"
        buff sad -sigh "我是说，你已经在伊尔夫的事上帮了我很多，而且我——"
        mc huh -tanya "莱尔，请直说吧。"
        show palmierproxy kind
        if not girl:
            buff sad both apa "好的，呃，你有多余的衣服可以借给我吗？"
            mc scratch apa sweat "抱歉？"
            show palmierproxy chill frown shock
            buff kzl frusta "噗哇！"
            "莱尔深吸一口气，试图让自己冷静下来。他不安地摆弄着双手，互相摩擦着。"
            buff confused sigh "我是说...你有多余的衣服可以借给我吗？"
            show buff frown -sigh
        else:   
            buff wry both "你能教我跳舞吗？"
            
    else:
        buff sad sigh "我知道我们并不是很亲近..."
        if "rooted" in buff_events:
            buff keluh frusta "尤其是自从你种下托马斯之后。" 
            show buff kzl
            $ putri.points -= 20  
            if putri.points <0:
                $ ibu.points = 0  
            mc side sweat"（看来他是不会让我忘记这件事了，是吗？）"
            show palmierproxy frown -sweat
            if not girl:
                buff sad apa "但既然你欠我的，我在想你是否有多余的衣服可以借给我？"
            else:
                buff sad apa "但既然你欠我的，我在想你能否教我跳舞？"
        else:
            if putri.points >= 20:
                buff wry -sigh "但你看起来人还不错，所以..."
            if not girl:
                buff sad apa "我在想你是否有多余的衣服可以借给我？"
            else:
                buff sad apa "我在想你能否教我跳舞？"
    mc eiden sweat tanya "什么？"
    buff wry blush sigh "有个女孩邀请我去参加节日，我不想让她难堪。"
    if girl:
        buff sad sweat frusta "我从来没跳过舞，我担心会踩到她的脚趾...然后不小心把她踩死。"
        mc ha -tanya "你不可能踩到别人的脚就把人踩死的。"
        buff keluh -frusta"但我的脚真的很大。而且有个学生在格斗训练后的淋浴间说我哪里都很大，所以..."
        mc panik both "嗯，我觉得他不是那个意思。"
        mc smile -both "但我理解，你只是想确保你的约会对象玩得开心，对吧？"
        buff wry "是-是的。"
        mc kind "嗯。那位幸运的女士是谁呢？"
    else:
        buff sad frusta "我自己没有多少东西。我的制服和阿什姆和派克给我的衣服就是我所有的了。"
        mc scratch side sweat -tanya "哦..."
        if "jelly" in fia_events:
            mc smile "其实，菲亚确实给我买了一些节日用的新衣服，但是..."
            mc rajuk "（我是说，根据菲亚所说的，我可能确实有一套备用的节日服装，对吧？）"
            mc side frusta "（我不想让她生气，但我也不能就这样不管莱尔。希望她能理解。）"
            buff frown -blush apa "但是什么，[povname]？"
            mc chill smile sigh "但它们对我来说太大了，所以..."
        else:
            mc chill frown "嗯，我想我可能有些合适的，让我看看。"
            mc eiden sweat "（连我自己都不知道衣柜里有什么。）"
            mc happy shock "哦，这个可能合适！"
            show palmierproxy -shock
        mc happy -sweat "去试试吧，莱尔，虽然上衣可能会有点紧。"
        show palmierproxy smile -sweat -sigh
        buff eh shock "你说真的吗？"
        mc happy bloom "当然，尽管试吧！"
        buff talk blush apa "我现在可以试穿吗？"
        mc smile "当然，我是说，还有什么比——"
        mc malu both shock "（啊...）"
        hide buff with dissolve
        "莱尔开始在你面前脱衣服，露出他线条分明的背部。"
        show buff party laugh blush at right with dissolve:
            yoffset 770
        mc wry blush -shock "（他的身材真的与众不同，不是吗？）"
        buff bloom "很合身！谢谢你！"
        mc smile "你看起来很帅。你的约会对象一定会很高兴的，那位幸运的女士到底是谁呢？"
    if "ntr_talk" in buff_events:
        buff talk "艾琳，她和你同级，但她人很好。"
        mc rajuk "（嗯，真的吗？她差点就叫他混血儿了。）"
        buff hister "这里没有其他女孩跟我说过话。"
        if girl2 or girl:
            buff wry sigh "哦，当然除了你。"
    else:
        buff wry -bloom "我不知道，他们在我的桌子上留了张纸条。"    
        mc confused "一个秘密仰慕者？"
        buff hister "是的...知道班上有人想和我做朋友，感觉很好。"
        mc frown "纸条上写了什么？"
        buff talk "\'我喜欢你的眼睛，一个人来参加节日和我一起吧，我会在十二座科尔雕像附近等你。\'"
        show buff datar 
        mc scratch huh sweat "（嗯，为什么这听起来更像是威胁而不是约会？）"
    show pboy at horzappear
    menu:
        "为什么不跟我一起去呢？":
            hide pboy 
            show palmierproxy chill flirt blush cling
            buff eh sweat shock "诶？"
            mc smile -blush -cling "嗯，我没有约会对象。"
            if "rooted" in buff_events or putri.points <= 20:
                buff sad frusta "...我对此感到不舒服，[povname]。"
                if "rooted" in buff_events:
                    buff kzl sigh "尤其是在你对那朵花做了那样的事之后。"
                mc ew frusta "哎呀，好吧，我明白了。"
                mc frown sigh "（看来我需要更多地亲近他。）"
                if girl:
                    $ buff_events.append('nari')
                    mc kind tanya "但你还想和我一起练习吗？"
                    show palmierproxy -tanya
                    buff wry sigh "...好吧。"
                    galleryunlock femc_lyall
                    show femc_lyall with flashbulb:
                        truecenter zoom 1.0
                        easein 2.0 truecenter zoom 0.5
                    "你紧紧抱住莱尔，他的肌肉在你手下感觉结实，宛如一件完美的艺术品。"
                    "他的脸颊微微泛红，你能感觉到他的呼吸拂过你的脸。"
                    "你们俩跳舞直到午夜过半，然后你就去睡觉了。"
                else:
                    mc "那么，祝你约会愉快。"
                    buff "谢谢。你也是，希望你能和阿什姆先生解决问题。"
                    buff "他没有告诉我细节，但我希望你们无论如何能和好。"
                    mc "嗯。我也希望如此。"
                stop music
                scene bg_black with w20
                jump morning
            else:
                $ buff_events.append('nari')
                buff sad sweat sigh "你真是太好了，但是...我不想伤害阿什姆先生。你们俩现在似乎正处于一个复杂的时刻。"
                buff wry -sigh "我不想卷入其中。"
                mc chill pissed sweat frusta "阿什姆和我——"
                show palmierproxy frown -sweat shock
                buff laugh -sweat"但是...如果你想的话，我们可以在这里跳舞。"
                if girl:
                    buff wry sigh "我的意思是，不仅仅是为了练习。"
                    mc laugh "我很乐意。"
                    galleryunlock femc_lyall
                    show femc_lyall with flashbulb:
                        truecenter zoom 1.0
                        easein 2.0 truecenter zoom 0.5
                    "你紧紧抱住莱尔，他的肌肉在你手下感觉结实，宛如一件完美的艺术品。"
                    
                else:
                    buff sad sweat sigh "不过，我不是一个好的领舞。"
                    mc flirt cling "我可以帮你！"
                    galleryunlock lyall_malemc
                    show lyall_malemc with flashbulb:
                        truecenter zoom 1.0
                        easein 2.0 truecenter zoom 0.5
                    buff "哦！"
                    "你紧紧抱住莱尔，他的肌肉在你手下感觉结实，宛如一件完美的艺术品。"
                "他的脸颊微微泛红，你能感觉到他的呼吸拂过你的脸。"
                mc "紧张吗？"
                buff "是的。"
                mc "是因为我还是因为跳舞？"
                buff "两者都有..."
                buff "但主要是因为你，我想。你真漂亮，[povname]。"
                buff "尤其是你的眼睛。"
                mc "你的眼睛也不错，莱尔。别让任何人说你不好。"
                buff "..."
                buff "嗯。"
                mc "顺便说一下，阿什姆和我并不是一对。"
                buff "哦，嗯，知道了。"
                stop music
                scene bg_black with w20
                "你和莱尔跳舞跳了一整晚。一开始很尴尬，他的身材比你宽得多，步伐也很笨拙，那晚差点踩到你三次。"
                "但是，仍然很美好。感受到他每一个小动作时心跳加速，他轻柔的笑声，以及他的眼神终于柔和下来，不再带着恐惧——这感觉真好。"
                jump morning
                    



        "你确定要去吗？":
            hide pboy
            mc chill confused sweat sigh "看起来你对他们一无所知。"
            buff wry blush sigh "我确实不了解，但我也从未参加过节日。"
            buff sad sweat frusta "伊瓦尔从不让我们做园艺工作以外的事。我从不知道外面的世界会是什么样子。"
            buff wry -sweat -frusta "更不用说有人对我感兴趣到愿意带我去约会。这感觉...很好。"
            mc deject sigh "我只是想说，要小心。"
            buff laugh "我会的。"
            buff sad "哦，还有你妹妹菲亚……我觉得她也应该小心。"
            mc confused sweat shock "嗯？"
            buff keluh sweat "我无意中听到合唱团的一些女孩说，塔图姆小姐计划毁掉她的裙子？但我不确定——"
            show palmierproxy kzl shock
            play sound "sound/effects/cloth.mp3"
            show palmierproxy -shock
            show buff eh shock at center with move
            "你本能地抓住莱尔的衣领，紧紧攥住，他睁大眼睛看着你。他的脸离你只有几厘米远。"
            mc grit frusta "现在就把你知道的一切都告诉我！"
            buff sad apa "我，呃？好-好的！"
            stop music
            scene bg_black with w20
            "（显然塔图姆计划在舞会上恶作剧菲亚，好像是要往她身上泼鱼血？哼，休想在我眼皮底下得逞，贱人！）"
            $ fia_events.append("fish_blud")
            jump morning
        

#####FESTIVAL
label festival_time:
    play music "MUSIC/MusMus-BGM-103.mp3"
    play sound "sound/effects/tile.mp3"
    scene night_bridge with w20
    show croissant dance sad frusta at center with dissolve:
        yoffset 500
    fia "[povname]，快点！我们已经迟到了！"
    if girl:
        show palmierproxy pesta confused at left with moveinleft:
            yoffset 40
    else:
        show palmierproxy pesta confused at left with moveinleft:
            yoffset 100
    mc sigh "我已经跑得很快了，到底有什么急事？！"
    fia laugh bloom "我想看水母刚从水里飞出来的样子。"
    mc frown tanya "嗯？"
    show palmierproxy -tanya
    play sound "sound/effects/jelly.mp3"
    show jelly_sky with flashbulb:
        yalign 1.0
        easeout 15.0 yalign 0.0
    "你还没来得及让菲亚解释清楚，河里的水就开始发光了。"
    mc happy blush bunga "哇！"
    fia blush "正是时候！"
    $ my_events.append("festies")
    "成群的飞行水母开始升入空中，它们破水而出时在水面上留下微小的涟漪，飞向夜空。"    
    "一旦飞到空中，你就能看到它们聚集在一些镇民周围，主要是年轻的孩子和老人。"
    "一只水母靠近你，在你的手边盘旋，然后加入其他水母，自由地漂浮在空中。"
    show jelly_night behind croissant 
    hide jelly_sky with dissolve
    $ NPC = "孩子"
    npc "哇啊！我想抓一只！"
    "附近的一个孩子伸出双臂，追逐着飞行的水母。"
    "你更加注意周围的环境，意识到她并不是唯一在这里闲逛的孩子。"
    if "ker_bar" in buff_events:
        "派克村的几十个孩子也在那里，围着之前那个木偶戏演员。"
        "他的脸像往常一样面无表情，眼神渴望地望着夜空。"
    else:
        "大约有十几个孩子围着一个高个子英俊男人，他有着彩虹色的眼睛。"
        "他的脸上毫无表情，渴望地凝视着夜空。"
    fia hmph shock "哦，那些一定是莱纳尔的孩子们。"
    fia laugh sigh "没想到会在这里看到他们。一定是因为节日的缘故。"
    $ NPC = "女孩"
    npc "哦，那个是紫色的！"
    $ NPC = "男孩"
    npc "我真希望能看到发生了什么，真的那么漂亮吗？"
    "一个失明的男孩羞怯地问道，同时拉着他朋友的袖子。"
    if "desa" in buff_events:
        "你记得那个孩子，他在木偶表演时坐在最后面。"
        "与其说是看整场表演，不如说是在听。"
        mc avoid sigh "（一个失明的观众和一个哑巴表演者，真是糟糕的组合。）"    
        show palmierproxy kind -sigh
    $ NPC = "女孩"
    npc "哦，嗯，非常明亮，它们都在四处飞舞。"
    npc "它们就像嗯……嗯……"
    mc smile blush "……它们看起来像萤火虫。"
    show croissant frown -blush shock
    "你不自觉地补充道，反正他们也离得不够近，听不到你说的话。"
    "但菲亚听到了。她歪着头看着你。"
    fia sad apa "萤火虫？那是什么？"
    mc confused tanya "等等，你不知道萤火虫是什么？"
    fia pain -apa "不知道，除非你又在捉弄我。"
    mc panik sweat -tanya "啊，好吧——"
    "担心菲亚会察觉，你试图解释……" 
    play sound "sound/effects/cloth.mp3"
    scene bg_black with vpunch
    "但在你能解释之前，温暖的手立即遮住了你的眼睛。"
    $ NPC = "???"
    npc "猜猜是谁？"
    show pboy s at horzappear
    menu:
        "奎尔？":
            hide pboy
            red "想想更高、更可爱、更健壮，还有更多牙齿的人。"
            show side_p mal at pic 
            mc "塞恩！"
            hide side_p
            scene jelly_night with eye_open
            show red party cowo blush bloom at left with dissolve:
                yoffset 330
            show quil pesta datar at center with dissolve:
                yoffset 200
            show croissant dance mad frusta at right with dissolve:
                yoffset 500
            quil heh cling "对不起，红毛。我可以理解其他部分，但更可爱？我才是这个团队里唯一可爱的受。"
            show side_p fr at pic 
            show red amused -blush shock
            mc "奎尔，你的自知之明总是让我惊讶。"
            hide side_p

            
        "莱尔？":
            hide pboy
            red "嗯，想想更瘦一点，更有攻的气场。"
            show side_p mal at pic 
            mc "……塞恩？"
            hide side_p
            scene jelly_night with eye_open
            show red party cowo blush bloom at left with dissolve:
                yoffset 330
            show quil pesta datar at center with dissolve:
                yoffset 200
            show croissant dance mad frusta at right with dissolve:
                yoffset 500
            red "bingo！"
            show red amused -blush shock
            quil heh cling "你是说底能量吗，红？"
            red hister "你照过镜子吗？没人比你更底的了，奎尔。"
            quil panik -cling "说得对。"

        "阿什姆？":
            hide pboy
            red "啊...啊哈，抱歉，不是。"
            scene jelly_night with eye_open
            show red party wry both at left with dissolve:
                yoffset 330
            show quil pesta frown at center with dissolve:
                yoffset 200
            show croissant dance mad frusta at right with dissolve:
                yoffset 500
            show side_p mal at pic
            mc "塞恩！"
            hide side_p
            red perih sweat sigh "对不起，我以为这样会很有趣，没想到你会提到阿什姆。"
            show red sad -sweat -sigh
            show quil sulk sweat
            show side_p sdh at pic
            mc "他还是不跟你说话吗？"
            hide side_p
            quil wry -sweat sigh "我们俩都不。但是...今晚我们尽量不要纠结于此。"
            show quil datar -sigh
            
        "塞恩？":
            $ mrh.points += 5
            hide pboy
            scene jelly_night with eye_open
            show red party kaget shock at left with dissolve:
                yoffset 330
            show quil pesta frown at center with dissolve:
                yoffset 200
            show croissant dance mad frusta at right with dissolve:
                yoffset 500
            red "哦，不可能！"
            red wry -shock "是什么暴露了？"
            quil heh "可能是你那刺鼻的古龙水味道。那是什么味道？"
            red hister "大海的呼唤，它能吸引水母。"
            quil err frusta "你闻起来比海还咸。"
            red wry sigh "这就是重点！"
    show quil datar shock
    show red frown shock
    fia jijik sigh "喂？没有\'嗨，菲亚\'，或者\'你看起来真棒，菲亚\'吗？我就在这里，你知道吗？"
    red cowo bunga "哦！嗨，菲亚，我喜欢你的发型！"
    fia laugh blush bloom "这才像话嘛！谢谢，我花了好几个小时才弄好的。"
    show red sad shock
    quil ejek cling "是吗？那你的脸呢，也花时间打理了吗？还是今天特别丑？"
    show red sayang sweat 
    fia mock -blush cling "哦，今晚我一定会好好踩你的脚的，奎尔。"
    quil wink spark "我也是，亲爱的，我特意为你穿上了我最好的高跟鞋。"
    fia annoyed ang "哦，是吗？难怪你今天看起来比平时更像个妓女。"
    show quil ejek sigh
    show croissant mock cling 
    "你能感觉到你妹妹和奎尔身上散发出的杀气。"
    "如果这是你以前读过的那些敌人变情人的同人小说，你会称之为性张力。"
    "但了解这两个人，很明显这里面没有任何性的成分。这更像是一种幼稚的兄弟姐妹之间的竞争。"
    fia annoyed apa "那么，你打算像个绅士一样邀请我跳舞吗？"
    show croissant hmph 
    quil ejek cling "当然。来吧，让我向你展示我一直在训练的成果。"
    play sound "sound/effects/walk.mp3"
    hide croissant with dissolve
    hide quil with dissolve
    "说完，这对搭档手牵手走向戈莫拉的中心，途中几乎把对方推下桥去。"
    if girl:
        show palmierproxy pesta huh at right with moveinright:
            xzoom -1.0
            yoffset 40
    else:
        show palmierproxy pesta huh at right with moveinright:
            yoffset 100
    mc sigh "我不知道这两个人是要跳舞还是要谋杀对方。"
    red sayang sigh "可能两者都有一点。他们去年也是这样。我想他们很享受这种争斗。"
    red wry -sweat -sigh "好了，不说他们了，让我们来谈谈你吧！"
    mc confused -sigh "我？"
    red grin apa "这是你第一次参加水母节，对吧？有什么想问的吗？"
    show pboy s at horzappear
    menu uburi:
        "那些水母做了什么？":
            hide pboy
            red amused -apa "哦，它们在迁徙！至少我们是这么认为的。"
            red datar "实际上没人确切知道。"
            red cowo "传说这些水母其实是转世成水母的人类灵魂。"
            red amused "它们每年左右会从水里出来向家人告别。只是它们是水母，所以没人知道它们在说什么。"
            red sigh "还有人说这是一个巫师试图用水母美丽的光芒引诱人类。"
            red happy -sigh "不过大多数人更喜欢前一种说法。"
            show pboy s at horzappear
            jump uburi
        "这些服装是怎么回事？":
            hide pboy
            "环顾四周，你看到人群中几乎每个女孩都穿着红色，而大多数男性要么穿着有领子的衣服，要么穿着皮带。"
            "塞恩是个例外。他的服装似乎是对水母节更直白的诠释，布满了星星。"
            mc huh tanya "那么...这些皮革是怎么回事？"
            
            if not girl:
                mc malu sigh "我以为我的服装很糟糕，但看来我反而很合群。"
                red calm blush cling "我不这么认为。我是说，这还是有点过分。顺便说一句，你的腹肌不错。你的身材比[povname]好多了，这是肯定的。"
                "塞恩的目光越来越低。"
                show palmierproxy confused shock
                "他的目光似乎在你的胸部徘徊，尤其是在你露出的乳头上。"
                show pboy s at horzappear
                menu:
                    "眼睛看这里！":
                        hide pboy
                        show palmierproxy kzl frusta
                        red awkward -blush shock "哈哈，抱歉，抱歉！这就像是一个找不同的游戏。我在试图看出你和我的[povname]有什么不同。"
                        mc apa tanya "这么明显吗？"
                        show palmierproxy -tanya
                        red sayang -shock "脸上倒不明显，但身体绝对是。你简直就是一件艺术品，[povname]。"
                        mc malu both "谢谢？"
                        show palmierproxy kind -both
                    "欣赏这景色吗？":
                        hide pboy
                        show palmierproxy mean cling
                        red hister blush "如果我说是的话，你会生气吗？"
                        mc flirt cling "比水母还漂亮？"
                        red amused -blush "嗯，我不会说到那个程度，但也差不多了。"
                    "回头盯着他看":
                        hide pboy
                        show palmierproxy mean cling
                        "这游戏两个人都能玩。"
                        "你先仔细打量了他紧身裤，然后视线上移到他的侧面。"
                        "你可以清楚地看到他的一些肌肉，因为只有薄薄的带子遮挡你的视线，而且——"
                        red amused apa "喜欢你看到的吗，伙计？"
                        show palmierproxy frown shock
                        "说着，塞恩拨开了你脸上的一缕头发。那缕头发又落回了原处。"
                        "总是有那么一缕倔强的头发。"
                        show pboy s at horzappear
                        menu:
                            "没关系。":
                                hide pboy
                                show palmierproxy malu blush
                                red calm cling "你的也是。\'还不错\'，赏心悦目。"
                                show red laugh -blush -cling
                                "听到这话，你的脸热了起来。"
                                show red datar -blush
                                mc wry sigh "（先是阿什姆，现在又是他，这里的男孩子们夸人也太直白了。）"
                            "伊瓦尔更好。":
                                hide pboy
                                red awkward shock -blush "哈哈哈！你怎么知道的？"
                                red laugh -shock "不过我想光凭名字，我就比不上美丽女巫了！"
                mc confused sweat tanya "顺便说一下，你还没回答我的问题呢。"
                show palmierproxy frown -sweat -tanya
                red amused "哦，对了！基本上，在有水母之前，这个舞蹈节是一种求偶仪式。"
                mc eiden shock "求偶仪式？"
               

            else:
                red amused -apa "哦对了，我猜你不知道这个求偶仪式。"
                mc eiden shock "求偶仪式？"
            red laugh blush bloom "是的，基本上男人会为女孩跳舞，如果女士们喜欢她们所看到的，就会拉住男人的衣领，把他们带到床上。"
            red calm cling "可以说是给他们\'开苞\'。"
            red sayang -cling "然而，在死亡地带战争之后，开始出现飞行的水母，所以人们开始庆祝这个。"
            red hister both "基本上，教会认为这比整天做爱更文明，更容易接受。"
            red datar -both "但是服装已经深入人心，所以他们就保留了下来。"
            red calm -blush cling "然而，我不是这里的人，也不觉得给自己戴上项圈有什么意义，所以就选择了这种品味高雅的侧露！"
            show red cowo bunga
            mc ha both sigh "\'品味高雅\'。"
            show palmierproxy malu blush -sigh
            play sound "sound/effects/walk.mp3"
            jump red_dance

label red_dance:
    scene fountain_jelly with w33
    stop sound
    "当塞恩带你来到戈莫拉的中心时，你可以看到市民们正在尽情地跳舞。"
    "有些人组成了自己的队列舞，有些人成群结队，有些人成对……"
    play sound "sound/effects/bump.mp3"
    show step_shoe1 at right with moveinright:
        yalign 0.0
    quil "哎呀，我真笨。"
    play sound "sound/effects/punch.mp3"
    show step_shoe2 at left with moveinleft
        
    fia "我也是，我太笨拙了！"
    galleryunlock step_shoe
    scene fountain_jelly with dissolve
    "……有些人试图踩烂对方的脚。"
    "但在水母耀眼的光芒下，所有人显然都玩得很开心。"
    show red party laugh at center with dissolve:
        yoffset 330
    red bloom "这才对嘛！"
    show red at left with move
    if girl:
        show palmierproxy pesta sad at center with moveinright:
            xzoom -1.0
            yoffset 40
    else:
        show palmierproxy pesta sad at center with moveinright :
            xzoom -1.0
            yoffset 100
    mc shock "哇！"
    "还没等你抗议，塞恩就把你拉进了人群。"
    show palmierproxy frown blush -shock
    red calm cling "跟着我的节奏来。"
    "他在你耳边低语，同时抓住你的手臂，让你转了个圈。"
    "环顾四周，你开始模仿其他人，因为这显然有一定的模式。"
    "成对的舞者似乎试图以一种近乎暴力的动作将对方下压，仿佛这不是一个浪漫的姿势，而是一场战斗。"
    "唯一没有让你感到警惕的原因是周围人发自内心的笑声。"
    play sound "sound/effects/gigle.mp3"
    "有些人在试图以他们想要的方式下压舞伴时失败了，跌倒在地，发出歇斯底里的笑声。"
    play sound "sound/effects/swosh.mp3"
    if girl:
        galleryunlock fedan_thane
        show fedan_thane with dissolve:
            truecenter zoom 1.0
            easeout 1.0 truecenter zoom 0.5
    else:    
        galleryunlock mc_red
        show mc_red with dissolve:
            truecenter zoom 1.0
            easeout 1.0 truecenter zoom 0.5
    $ renpy.pause()
    red "这是一种展示支配地位的方式。"
    mc "哇！"
    "塞恩毫无预警地将你下压，他的手紧紧握住你的手。"
    "他的另一只手牢牢地扶在你的腰上，支撑着你，让你不至于摔倒。"
    if girl:
        hide fedan_thane with dissolve
    else:
        hide mc_red with dissolve
    show palmierproxy grit sweat
    red hister apa "惊讶吗？这在伊格尼亚被认为是一种传统舞蹈。"
    show palmierproxy wry sigh
    play sound "sound/effects/cloth.mp3"
    "塞恩将你扶起，让你重新站直，以更加舒缓的节奏继续跳舞。"
    red amused "在过去，一首歌中被下腰最多次的人，如果他们决定去一个更加……"
    show palmierproxy malu blush shock
    red mock cling "……私密的场所，就必须取悦对方。"
    show palmierproxy kind -shock
    red cowo -cling "当然，现在很少有人还遵循这个规矩了。如今，这只是为了好玩而已。"
    show pboy s at horzappear
    menu:
        "真可惜，我倒是不介意。":
            hide pboy
            show red kaget blush shock
            mc flirt cling "真可惜，我倒是不介意……我是说，取悦你。"
            red ow both frusta "你不能说这种话，[povname]。"
            red sayang blush -frusta "你在给我一些想法。"
            show pboy s at horzappear
            menu:
                "这正是我的计划。":
                    hide pboy
                    show red amused shock
                    $ mrh.points += 5
                    if "nicked" in red_events:
                        mc happy "那又怎样？你不是说过，如果我们没有过去的纠葛，你会给我们一个机会吗？"
                        show palmierproxy malu
                        red calm -shock "哈，所以这就是你在海德温女士的课上问我那个问题的原因！"
                    else:
                        red huh -shock "什么——哦！"
                        red kaget "哦..."
                    mc kind tanya "你不介意吗？"
                    show palmierproxy smile -tanya
                    red sayang sigh "一点也不介意，但是……你的气味让我很难集中注意力——"
                "逗你真是太有趣了！":
                    hide pboy
                    $ mrh.points -= 15
                    if mrh.points <0:
                        $ mrh.points = 0
                    red hister sigh "哈哈，别这样戏弄我！另一个你已经让我心痛得够呛了。"
                    red wry "我可不觉得自己能承受第二次被你伤透心！"
                    red sayang "尤其是当你的气味如此——"

        "让他下腰":
            hide pboy
            play sound "sound/effects/swosh.mp3"
            red kaget sweat shock"嘿！" with vpunch
            "你将全身的重量压在塞恩身上，立即让他下腰，以此回敬他。"
            play sound "sound/effects/crash.mp3"
            mc ow sweat shock"哎哟！"
            "然而，你似乎低估了他的体重。你失去了平衡，立即倒在了他身上。"
            show palmierproxy frown blush shock with move:
                xalign 0.45
            show red amused blush shock
            play music "sound/effects/jantung.mp3"
            "胸膛贴着胸膛，你能听到他的心跳，那急促而稳定的跳动只有你自己的心跳能超越。"
            red hister -shock "啊哈哈，好吧，这倒是出乎意料。"
            mc malu both -shock "你比看起来要重得多。"
            red wry sigh "是啊，最近我吃得多了不少。"
            stop sound
            "塞恩扶你起来，你拍了拍身上的灰尘。他尴尬地整理了一下头发，然后才完全恢复镇定。"
            red ngeles -sigh "这有点奇怪，但自从我喝了你的血之后，我——"
    if "come_clean" in tom_events:
        stop music
        play sound "sound/effects/cloth.mp3"
        if girl:
            galleryunlock fedan_arshem
            scene fedan_arshem with dissolve
        else:
            galleryunlock mc_arshem
            scene mc_arshem with dissolve
        tom "介意我插个队吗？"
        play music "MUSIC/MusMus-BGM-077.mp3"
        "塞恩还没说完，阿什姆就抓住你的腰，稍稍将你抬起，然后你们两个优雅地在人群中滑行，跳起了华尔兹。"
        red "阿什姆？！嘿，回来——！"
        "你们在人群中跳舞，阿什姆带着你来到一个更加僻静的地方。他的笑容始终挂在脸上，小心翼翼地保持着与你腰部的贴近。"
        "阿什姆以复杂的舞步带你来到一个公园。"
        scene statue_jelly with dissolve
        "你不再被嬉笑的舞者和喧闹的音乐包围。"
        "取而代之的是激情热吻的声音，来自那些不太注意隐蔽的情侣，他们在长椅上和附近的雕像旁亲热。"
        "阿什姆轻轻吻了一下你的手背，然后松开了你的腰，结束了你们短暂的舞蹈。"
        show tom party wry at right with dissolve:
            yoffset 190
        if girl:
            show palmierproxy pesta confused at left with moveinleft:
                yoffset 40
        else:
            show palmierproxy pesta confused at left with moveinleft:
                yoffset 100
        show pboy s at horzappear
        menu:
            "我正在做事呢。":
                hide pboy
                $ ibu.points -= 5
                if ibu.points <0:
                    $ ibu.points = 0
                tom ha blow "我知道。别担心，我只需要借用你一会儿，远离任何窥探的目光。"

            "所以，你又跟我说话了？":
                hide pboy
                tom calm "你想我了吗？"
                show pboy s at horzappear
                menu:
                    "比你想象的还要想。":
                        hide pboy
                        $ ibu.points += 5
                        tom wry blush blow "我也是这种感觉。"
                    "你是谁来着？":
                        hide pboy
                        $ ibu.points += 10
                        tom amused blow "哼，又是那种无礼的态度。"
                        tom pfft -blow "你比[povname]更加尖刻。"
                        tom smile "不过这并不是坏事。"

            "动作不错，舞林高手。":
                hide pboy
                $ ibu.points += 5
                tom pfft blow "你自己也不赖。"
        
        tom sad sweat frusta "我想为我……沉默寡言的行为道歉。"
        mc mean "你是说基本上24/7都在无视我？我几乎没注意到。"
        show palmierproxy kind 
        "你保持着讽刺的语气，希望阿什姆不会生气。"
        tom sigh blow "再次抱歉。我不是有意表现得如此疏远。然而，我的情绪占了上风。"
        tom sad -blow "我很愤怒。"
        mc ha "是啊，我也会对我自己和\'另一个我\'生气，所以——"
        show palmierproxy frown shock
        tom nyesal "不是对你...是对我自己。"
        mc apa tanya"...啊？"
        show palmierproxy sad -tanya
        tom whine blow "我认识[povname]已经将近十年了，但我还是被骗了。"
        if not girl2:
            tom sad -blow "当然，我有些怀疑。你的一些举止与[dia]不太一致"
        else:
            tom sad -blow "当然，我有些怀疑。你的一些举止与[dia2]不太一致"
        show palmierproxy shock
        tom nyesal -sweat "然而我还是保持沉默，同样被欺骗了，而且我...我喜欢上了你。"
        show palmierproxy malu blush -shock
        if ibu.acara > 0:
            tom pfft "我喜欢你在我询问发型时考虑我的喜好。"
            tom giggle "我喜欢你的反应如此真诚和诚实。"

        else:
            tom pfft "我喜欢你善良和真诚的样子。"
            tom giggle "我喜欢你即使在慌乱时也会微笑和大笑。"
        show palmierproxy sad sweat shock
        tom wry "...我以为我正在更深地爱上我的[povname]。"
        show palmierproxy frown -shock
        tom sigh blow "但事实证明我却对另一个人产生了感情。我感觉自己像是背叛了[povname]。"
        if girl2:
            tom sad frusta "就好像我才是背叛了[dia]的人。我讨厌自己为此感到更多的内疚，而不是对[kamu]所有的谎言感到愤怒。"
        else:
            tom sad frusta "就好像我才是背叛了[dia2]的人。我讨厌自己为此感到更多的内疚，而不是对[kamu]所有的谎言感到愤怒。"
        tom capek frusta "我为[povname]做了一切，却发现自己被操纵去这么做，这让我感到胃里翻江倒海。"
        if not girl2:
            tom whine blow "然而我仍然如此着迷，以至于我甚至无法将怒火指向[dia2]，反而把它发泄在你身上。我真是个傻瓜。"
        else:
            tom whine blow "然而我仍然如此着迷，以至于我甚至无法将怒火指向[dia]，反而把它发泄在你身上。我真是个傻瓜。"
        show tom sad shock
        mc sad sweat "嘿，别这样说。如果我是你，我也不知道该如何反应。我理解，你当时处于震惊中。"
        show palmierproxy wry -sweat
        tom sigh blow "震惊都是轻描淡写了。不过，我本可以处理得更好。"
        tom sad apa "对不起，[povname]。如果你不介意的话，你愿意给我们一个重新开始的机会吗？"
        tom wry -apa "我保证从现在开始会恰当地表现自己。作为...朋友。当然，如果你愿意我们成为朋友的话？"
        "阿什姆向你伸出手，提出一个开放的握手。你盯着它，思考着你的选择。"
        show pboy s at horzappear
        menu:
            "不再有陷入爱河的阿什姆了？！":
                hide pboy
                tom nyesal both frusta "请郑重发誓你会把那段记忆抹去。"
                tom ha "我还是不敢相信我向你，一个完全陌生的人，展示了那样的一面。"
                tom sigh blow "太丢脸了！"
                show tom frown shock
                mc happy bunga blush "嘿，我们已经不是陌生人了，对吧？我们是朋友！"
                mc hister "而且，我觉得那样很可爱！"
                tom capek frusta "我不是可爱，我是...迷人。"
                show tom pfft blush -frusta
                mc smile -blush "随你怎么说，阿什姆。"
            "我很乐意。":
                hide pboy
                show palmierproxy kind
                show tom lega blow
                "你握住了他的手，不禁赞叹它摸起来多么柔软。"
                "他一定经常保湿。"
                mc tanya "你会保湿吗？"
                show palmierproxy apa sweat shock
                tom pfft both blow "实际上，我觉得那只是汗。"
                mc ew frusta "呃！"
                show palmierproxy confused
                show tom giggle blush -blow
                "你立即缩回手，在阿什姆的背心上擦了擦。阿什姆只是对此哈哈大笑。"
                tom amused -blush "我开玩笑的。我用的是油和蜂蜜。"
                mc confused "总是用蜂蜜。"
                tom smile "当然，毕竟我是个蓬松的小精灵。"
                if not girl:
                    mc ha "你知道，在我来的地方，那个词可能有完全不同的意思——"
            "我叫[povname]。":
                hide pboy
                mc happy bunga "我叫[povname]。我是奎尔带来的那个倒霉蛋。"
                mc kind "我喜欢在海滩上长途散步，跳舞，基本上是个正在康复的酒鬼。"
                tom pfft blush bloom "阿什姆。我是个无可救药的浪漫主义者，最近刚结束了一段长期的有毒关系。"
                tom amused cling"我喜欢蜂蜜，红酒，而且我特别期待待会儿在战斗课上消灭奎尔。"
                show tom pfft -cling
                mc mean cling "我会记住这句话的！"
        show palmierproxy confused sweat tanya
        tom smile "哦，还有[povname]..."
        show tom kzl sweat shock
        show palmierproxy kzl shock
        stop music
        play sound "sound/effects/squell.mp3"
        "一声尖锐的叫声打断了阿什姆的话。你很容易就认出那是你妹妹的声音。"
        tom ew -sweat -shock "那是菲亚吗？"
        show tom kzl -shock
        mc pissed -shock "我想是的。"
        show palmierproxy kzl 
        
        play sound "sound/effects/walk.mp3"
        "两个你认识的合唱团男生从你身边走过。你不由自主地听到了他们的谈话。"
        $ NPC = "男生A"
        npc "天哪，塔图姆肯定是疯了吧？就因为菲亚是个替补？"
        $ NPC = "男生B"
        npc "女人啊，真是永远搞不懂她们在想什么。"
        $ NPC = "男生A"
        npc "我懂，对吧？而且今晚疯狂的不只她一个。"
        if "ntr_talk" in buff_events:
            npc "你看到艾琳·克莱默和那个新来的小子在一起了吗？和一个巫师卿卿我我的。"
            npc "打赌那个人渣肯定是给她洗脑了什么的。幸好艾杰克斯和他的伙伴们正在处理他。"
            npc "那会给他一两个教训的。"
        else:
            npc "你看到艾杰克斯把那个巫师揍得屁滚尿流了吗？"
            npc "就是那个莱尔小子，对吧？是啊，听说那个混蛋居然相信有人邀请他参加舞会。真是个傻瓜！"
        
        tom sweat shock "莱尔！"
        play sound "sound/effects/cloth.mp3"
        hide palmierproxy with dissolve
        show tom -sweat -shock at center with move
        npc "他妈的什么？！" with vpunch
        "阿什姆毫不犹豫地抓住了那些学生的衣领。" 
        tom ew frusta "艾杰克斯在哪里？"
        $ NPC = "男生A"
        npc "嗯？哦，是你啊。那个巫师是你男朋友还是什么？典型的，一个混血儿和自己的同类混在一起。"
        npc "如果我什么都不说，你打算怎么办，阿什姆？像诅咒艾杰克斯的父亲那样诅咒我吗？"
        npc "打赌你妈妈肯定也对你继父用了爱情魔药。要么就是她一定有一双魔法腿——"
        play sound "sound/effects/punch.mp3"
        hide tom with vpunch
        "在那个混蛋说出下一个音节之前，阿什姆就把他打晕了。幸好如此，你也正准备这么做。"
        "另一个学生似乎在这一幕前颤抖起来，脸色略微变白。"
        show tom party ew at center with dissolve:
            yoffset 190
        tom "说！"
        show tom kzl
        npc "我-我看到他们在码头下的桥下！别-别打我！"
        play sound "sound/effects/bump.mp3"
        "阿什姆反而用头撞了他一下。那人立刻就晕了过去。" with vpunch
        tom capek frusta "你应该去看看菲亚，奎尔应该还和她在一起。我去处理艾杰克斯。"
        show pboy s at horzappear
        menu:
            "好的！（去找菲亚）":
                hide pboy
                show side_p sdh at pic
                mc "谢谢！"
                hide side_p
                play sound "sound/effects/tile.mp3"
                jump fia_blood
            "不行！（去找莱尔）":
                hide pboy
                if girl:
                    show palmierproxy pesta confused at left with moveinleft:
                        yoffset 40
                else:
                    show palmierproxy pesta confused at left with moveinleft:
                        yoffset 100
                show tom sad at right with move
                mc pissed sigh "奎尔和菲亚在一起，塞恩应该也离她不远。我不会让你独自面对艾杰克斯的。"
                mc sad frusta "如果他像上次那样发飙怎么办？"
                tom ha "我能应付他。"
                mc grit "那他的朋友呢？你没有画任何符文。如果他们画了怎么办？"
                tom kzl "...好吧，你可以来，但如果情况不对，就离开。"
                show palmierproxy kzl
                "你点点头，你们两个朝码头跑去。"
                play sound "sound/effects/tile.mp3"
                scene bg_black with w20
                jump bullied_buff



    else:       
        stop music
        jump drama_unana


label bullied_buff:
    play music "MUSIC/MusMus-BGM-075.mp3"
    scene lake_jelly with w20
    show buff pblood keluh sweat at center with dissolve:
        yoffset 770
    $ buff_events.append('ketemu_buli')
    play sound "sound/effects/punch.mp3"
    queue sound "sound/effects/bump.mp3"
    queue sound "sound/effects/crash.mp3"
    show buff sad frusta
    if "ntr_talk" in buff_events:
        $ NPC = "艾琳"
        npc "住手！我说住手！"
        "当你们到达现场时，莱尔已经被打得很惨了。艾杰克斯用一把冰匕首割伤他，艾琳似乎处于震惊状态，而莱尔试图保护她。他用自己的身体挡在她前面。"
    else:
        "当你们到达现场时，莱尔已经被打得遍体鳞伤。艾杰克斯用一把冰匕首割伤他，而他的两个朋友则在一旁笑着看。"
    
    "由于艾杰克斯和他的朋友们还没有注意到你和阿什姆，你决定..."
    show buff at right with move
    show pboy s at horzappear
    menu:
        "揍艾杰克斯":
            hide pboy
            $ kindness -= 20
            if "cupu" in my_events:
                play sound "sound/effects/tile.mp3"
                "你冲向艾杰克斯，直接朝他的嘴巴挥出一拳。"
                "...至少这是本应发生的情况。只是再一次，你从未打过架，所以你只是挥拳却完全打空了。"
                play sound "sound/effects/crash.mp3"
                "你踉跄了一下，反而摔了个屁股墩。" with vpunch
                play sound "sound/effects/punch.mp3"
                queue sound "sound/effects/bump.mp3"
                "幸好，阿什姆替你掩护了，他一脚踢中艾杰克斯的下巴，让他向后摔倒，匕首掉落并碎成两半。"
                "艾杰克斯昏倒在混凝土地面上，其他人则惊讶地盯着这一幕。"
                $ NPC = "男生A"
                npc "他妈的怎么回事？"
                buff eh shock "[povname]？阿什姆？"
                show buff sad -shock
                show tom party kzl at left with dissolve:
                    xzoom -1.0
                    yoffset 190
                npc "你们两个是在袒护一个巫师吗？！"
                tom ew "我是在保护一个朋友。"
                
            else:
                play sound "sound/effects/punch.mp3"
                queue sound "sound/effects/bump.mp3"
                queue sound "sound/effects/crash.mp3"
                "这些年来你经历过不少打斗，你踢开了阿贾克斯的刀，然后用尽全力给了他一拳。" with vpunch
                "阿贾克斯踉跄着后退，昏了过去，他的朋友们都震惊地盯着你。"
                npc "他妈的怎么回事？"
                buff eh shock "[povname]？阿什姆？"
                show tom party kzl at left with dissolve:
                    xzoom -1.0
                    yoffset 190
                show buff sad -shock
                npc "你们两个在这里做什么？"
                

            tom kzl "如果你们两个还有一丝自保意识的话，你们现在就该立刻离开这里，夏亚，奈恩斯。"
            tom ejek cling "除非你们想让我给你们的母亲打电话，告诉她你们去年夏天做了什么？"
            $ NPC = "夏亚"
            npc "我是私下告诉你的，你不敢这么做！"
            tom cruel blow "恐怕你高估我了。你看，我对勒索可没有任何顾虑。"
            tom ejek -blow "唯一的缺点是，诅咒往往更有效。"
            $ NPC = "奈恩斯"
            npc "你...这事还没完！"
            show tom kzl blow
            stop music
            play sound "sound/effects/tile.mp3"
            "那些男孩离开了，抬着阿贾克斯昏迷的身体。"
            if girl:
                show palmierproxy pesta kzl at center with moveinleft:
                    yoffset 40
                    xzoom -1.0
            else:
                show palmierproxy pesta kzl at center with moveinright:
                    yoffset 100
                    xzoom -1.0
            mc sad tanya "莱尔，你没事吧？"
            show palmierproxy smile -tanya
            buff touched "我...没事。"
        "呼喊阿贾克斯":
            hide pboy
            
            if girl:
                show palmierproxy pesta kzl sweat at center with moveinleft:
                    yoffset 40
                    xzoom -1.0
            else:
                show palmierproxy pesta kzl sweat at center with moveinleft:
                    yoffset 100
                    xzoom -1.0
            show tom party kzl at left with moveinleft:
                xzoom -1.0
                yoffset 190
            mc grit frusta "住手，阿贾克斯！"
            show palmierproxy kzl
            $ honesty += 10
            $ NPC = "阿贾克斯"
            show npc_1_m at pic
            npc "[povname]，阿什姆？真典型。"
            npc "来救你的男朋友吗？到头来，垃圾总是和垃圾在一起，不是吗？"
            hide npc_1_m 
            "阿贾克斯用他的冰匕首指向阿什姆。"
            buff scold frusta "住手！阿什姆先生和这件事无关！"
            show buff sad shock
            show npc_1_m at pic
            npc "阿什姆先生？听听，伙计们。这个巫师称这个娘娘腔为\'先生\'。多么可爱啊，这就是你们俩在床上的玩法吗？"
            hide npc_1_m 
            tom ejek cling "我从不知道你对我的卧室活动如此感兴趣，阿贾克斯。如果你想要一段更亲密的友谊，你大可以直接开口。"
            show tom kzl shock
            show npc_1_m at pic
            npc "谁他妈会想和一个妓女的儿子上床？！哦等等，我猜你爸爸会，不是吗？"
            npc "我打赌这就是他欢迎你和你母亲进入他家的唯一原因。"
            npc "两个漂亮的小东西，可以操和玩弄——啊啊啊！！！"
            hide npc_1_m 
            show tom whine sweat shock
            show palmierproxy sad shock
            show buff kzl frusta
            stop music
            show tabok_bloom with flashbulb
            galleryunlock tabok_bloom
            play sound "sound/effects/vine.wav"
            "在阿贾克斯还没说完另一个字之前，花朵突然从他的手腕上冒了出来，他的匕首掉在地上，因为他再也没有拇指来握住它。"
            show tom sad -shock
            show palmierproxy ew -shock
            "你和阿什姆都被这一幕惊呆了，你们已经猜到是谁能做出这样的事。"
            "从你的眼角余光中，莱尔的金色眼睛在月光下似乎更加明亮。他那强烈的凝视无所不包，同时他在空中挥了挥手。"
            show tabok_wither with dissolve
            galleryunlock tabok_wither
            hide tabok_bloom
            "当莱尔挥手解除诅咒时，花朵消散了，阿贾克斯看起来并无大碍。"
            hide tabok_wither with dissolve
            buff scold -frusta "我说了，别把阿什姆先生牵扯进来，否则的话！" with vpunch
            $ NPC = "男生A"
            npc "巫师！巫师！"
            $ NPC = "男生B"
            npc "快跑，在他长出更多花蕾之前！这就像死亡地带重现了！"
            play sound "sound/effects/tile.mp3"
            show buff kzl sigh
            "那些欺凌者吓得逃跑了，而你和阿什姆则呆若木鸡。"
            stop sound
            show buff eh shock
            "回过神来，莱尔因为暴露了自己而害怕地扭动着，就像一个刚被抓到偷偷把手伸进饼干罐的孩子。"
            buff keluh "啊，我很抱歉！请不要告诉任何人！我已经让花朵枯萎了，他的手应该已经长回来了！我——"
            show buff sad -shock
            
            if "ntr_talk" in buff_events:
                show palmierproxy frown shock
                show tom ha shock
                $ NPC = "艾琳"
                npc "我会为你作证！"
                "艾琳大喊道，提醒你她还在场。阿什姆也完全忘记了这个女孩，直到她热情地对莱尔喊道。"
                buff lega "艾琳小姐..."
                show buff wry
                npc "如果阿贾克斯向老师们报告你，我就说他在撒谎，他只是嫉妒你和我在一起！"
                npc "大多数老师都喜欢我，而且我父母经常给学校捐款，他们肯定会听我的。我发誓你不用担心任何事，莱尔！"
                npc "我会保守你的秘密！所以别担心，好吗？你在这件事上是对的！"
                $ NPC = "???"
                play sound "sound/effects/tile.mp3"
                "艾琳又絮叨了一会儿，然后向你们三个点了点头，离开了现场。"
                stop sound
            show palmierproxy frown 
            tom nyesal "莱尔……"
            play music "MUSIC/MusMus-BGM-024.mp3"
            tom smile -sweat blow "干得好。"
            buff eh shock "你们不...害怕吗？"
            $ buff_events.append('bunga_time')
            show buff -shock
            show pboy s at horzappear
            menu:
                "有一点。":
                    hide pboy
                    $ honesty += 10
                    tom sad frusta"[povname]！"
                    show tom frown -frusta
                    buff wry -sigh "不，这很合理。我也很害怕。"
            

                "所以你也是个杀人园丁？":
                    hide pboy
                    $ kindness -= 10
                    buff scold frusta "我和他一点也不像！"
            
                "你能给我种朵玫瑰花吗？":
                    hide pboy
                    show palmierproxy malu -sweat
                    $ kindness += 10
                    $ putri.points += 5
                    show buff hister -shock
                    "莱尔对你孩子气的请求微笑了一下，但很快笑容就消失了。他低头沉思，意识到发生了什么。"
                    buff wry -sigh "我甚至不确定我是怎么做到的。"
            buff keluh -sigh "那...那是我第二次能够自己创造那些玫瑰。第一次是和伊尔夫意外发生的。"
            tom ha apa "伊尔夫？"
            buff sad -sigh "我的兄弟。我把他的一些头发变成了花环，但几个小时后它们就枯萎了。"
            buff kzl "不过，这是我第一次在人的四肢上使用它。我只是太生气了，不想让他们伤害你。"
            tom capek frusta "即使在他们群殴你之后？你太仁慈了，莱尔。"
            buff wry "我对此并不确定。"
            buff sad "我曾看到我父亲对我姐姐的男朋友使用过这个把戏。他会在他们的手腕上长出玫瑰，然后在完全替代手之前让它们消失。"
            buff keluh "四肢保住了，但仅仅是保住而已，因为从手腕往下基本上无法活动。"
            buff sad "我只想长出一两片花瓣，但我的愤怒占了上风。我希望阿贾克斯能原谅我。"
            mc apa frusta "伙计，他试图刺伤你。善良是好事，但不是在他们可能杀了你的时候！"
            show palmierproxy confused sigh
            tom kzl blow "同意。"
            tom wry -blow "无论如何，我们会为你掩护的，莱尔。如果阿贾克斯向老师报告这件事，我们的证词会证明事实并非如此。"
            buff lega "谢谢你。"
            if curiosity >= 30:
                show buff frown shock
                mc sad tanya "不过，我能问点事吗？"
                mc deject -tanya "我以为只有伊瓦尔的女儿们继承了他的魔法，那你为什么能..."
                buff keluh -shock "与大众的看法相反，我...我不认为我父亲会那样把我们与魔法分开。"
                buff sad "我的大多数兄弟在被转化之前都能长出几个自己的花蕾。"
                buff "但我们没有像姐妹们那样接受训练，也没有太多机会去探索我们的魔法。"
                buff keluh "而且我也不想要这些力量，我……我不想伤害任何人。"
                show buff sad 
                tom cruel "如果这能给你些安慰的话，你成功地为善使用了你的力量，莱尔。这是你应该为之骄傲的事。"
                buff lega "我...谢谢你。"
                show buff wry

            else:
                "你想让他进一步解释，但你决定忍住不问。"
                mc deject "（我今晚不该再追问他了。）"
            tom calm "好了，既然我们已经解决了这个问题，让我们带你去医务室吧。"
            tom ha blow "我真希望海德温女士这个时候没有嗑高。"
            mc eiden sweat "你有没有注意到我们的大多数老师都有点问题？"
            show palmierproxy ha
            show buff hister
            tom capek frusta "每天都在注意到。"
            stop music
            scene bg_black with w20
            "你带莱尔去了医务室，幸运的是海德温女士大部分时间是清醒的。然而，你仍能闻到空气中lingering的大麻味。"
            jump morning



        "让阿什姆带头":
            hide pboy
            play sound "sound/effects/crash.mp3"
            show tom party kzl at left with moveinleft:
                xzoom -1.0
                yoffset 190
            "阿什姆毫无预警地冲向阿贾克斯，一脚踢在他脸上，冰匕首从他手中飞出。" with vpunch
            "他的其他朋友立即围住阿什姆，但你决定介入干预。你踢了一两个人的裆部，让他们滚蛋。"
            "阿什姆很快解决了剩下的人，充分利用了他的长手长脚。"
            tom ew "滚。"
            show tom kzl
            "阿什姆的声音轻柔低沉，却比任何喊叫都更具威慑力。那些男孩立刻逃走了，一边咒骂着他，一边抬着阿贾克斯昏迷的身体离开。"
            show tom sad
            if girl:
                show palmierproxy pesta sad sweat at center with moveinleft:
                    yoffset 40
            else:
                show palmierproxy pesta sad sweat at center with moveinleft:
                    yoffset 100
            mc "你还好吗，莱尔？"
            buff wry "我...没事。"
            stop music
    play sound "sound/effects/cloth.mp3"
    buff hister "至少在重要的地方还好。"
    play music "MUSIC/MusMus-BGM-059.mp3"
    show buff sad
    mc ow "发生什么事了？"
    show palmierproxy sad
    if "ntr_talk" in buff_events:
        $ NPC = "艾琳"
        show tom kzl
        show palmierproxy frown
        npc "阿贾克斯和他的同伙在我们尽情跳舞时偷袭了我们。一群有偏见的野蛮人！"
        npc "我真的很抱歉他们对你做了那样的事，莱尔。他们无权这么做。"
        buff keluh apa "没关系，不过你还好吗？你没受伤吧？"
        show buff sad -apa
        npc "没有。科尔，你应该担心你自己。你看起来糟透了！比之前更糟！"
        tom sigh blow "艾琳，我知道你反应有点慢，但你真的认为对一个今晚为你的荣誉而战的人说这种话合适吗？"
        show tom ha
        npc "啊，抱歉！习惯使然。"
        npc "总之，别担心阿贾克斯和他的喽啰们。"
        npc "如果阿贾克斯向老师告状，我就说他在撒谎，他只是嫉妒你和我一起跳舞！"
        npc "大多数老师都喜欢我，而且我父母经常给学校捐款，他们肯定会听我的。我发誓你不用担心任何事，莱尔！"        
        $ NPC = "???"
        "艾琳又絮叨了一会儿，然后向你们三个点了点头，离开了现场。"


    else:
        buff keluh "有张纸条让我来这里。我以为可能有人想邀请我参加舞会，但太害羞不敢直接说。"
        buff sad sigh "结果却是个恶作剧。"
        mc grit frusta "阿贾克斯差点杀了你，那不是恶作剧！"
        show palmierproxy kzl -frusta
        tom ejek cling "同意。我现在后悔解除了他父亲的诅咒。要我再下一个吗？也许更强一点的。"
        show tom kzl
        buff keluh shock "什么？！不，不！他们做的事确实很糟糕，但是...我是说，报复只会让事情变得更糟，不是吗？"
        buff sad sigh "我只会保持低调，不去打扰任何人。"
        show pboy s at horzappear
        menu:
            "你一直都在这么做。":
                hide pboy
                mc side sigh "无意冒犯，但似乎大多数学生都因为你的...存在而感到困扰。"
                buff scold frusta "你能怪他们吗？这双眼睛，会让任何人不安。"
                tom capek frusta "莱尔，你父亲的罪过不该由你来承担。"
                show tom sad -frusta
                buff wry -sweat -frusta "我知道...谢谢你。"
            "长点胆量吧！":
                hide pboy
                mc pissed "长点胆量来配得上你的胸部吧！"
                buff eh apa "什么？"
                show buff sad -apa
                mc pissed frusta "莱尔，你是个好人，但说实话，这里的每个人都是混蛋。你不能让自己这样被人践踏。"
                mc grit "长出巨大的胆量来配得上你巨大的奶子，反击回去！！！"
                tom ha blow "咳咳，我想[povname]想说的是，温顺并不能缓解你的处境。"
                tom frown -blow "有时候以火攻火更好。我们学校的孩子们被教导看到巫师就要杀死。"
                tom sigh blow "可悲的是，他们中很少有人有能力思考自己行为的后果。"
                tom kzl -blow "所以...正如[povname]粗俗地说的那样，也许你应该考虑反击，尽管你不想这么做。"
                mc mean cling "他说得对。"
                show palmierproxy kind -cling
                show tom pfft 
                buff hister -sweat "啊哈。你真有趣，[povname]。"
                buff wry sigh "谢谢你们两个。"
                show buff -sigh
            "我们会保护你的！":
                hide pboy
                mc side "如果有人再欺负你，就联系我们，好吗？我们会立刻赶来！"
                tom ejek cling "带着诅咒和一切。"
                show tom pfft -cling
                mc ha "好吧，也许不会到那种程度，但你明白我的意思。"
                show palmierproxy kind -cling
                buff wry -sweat sigh "啊哈。我明白...谢谢你们。"
                show buff -sigh
    play sound "sound/effects/cloth.mp3"
    "你帮助拍掉了莱尔衣服上的所有灰尘，并擦去了他脸上的干血。"
    mc frown tanya "你想回宿舍吗？我们很乐意送你。"
    show palmierproxy -tanya
    show tom frown shock
    buff laugh "如果你们两个不介意的话，我其实想在这里再待一会儿。再看一会儿水母，听听它们的歌声。"
    show buff amused
    mc confused "歌声？"
    buff frown "哦，你们听不到吗？"
    tom ha -shock "听什么，莱尔？"
    buff frown "水母浮上水面是有原因的，你知道吗。这些水母，我觉得它们是在海上死去的灵魂。"
    buff talk "也许是因为我的血统，但我能听到它们在飞向天空时唱歌。"
    buff laugh "在永远离开这片土地之前，向他们所爱的人哼唱。"
    buff datar blush shock "哦，我听到它们来了！"
    stop music
    play sound "sound/effects/jelly.mp3"
    show jelly_sky with flashbulb:
        yalign 1.0
        easeout 15.0 yalign 0.0
    "正如莱尔所说，成千上万的水母开始浮出水面，飞向星空。"
    "当它们美丽的光芒与闪耀的宇宙融为一体时，莱尔的话开始在你的脑海中回响。"
    "如果莱尔是个巫师，他能像听到玫瑰一样听到这些水母，那么这是不是意味着所有这些生物都是..."
    show side_p sdh at pic
    mc "（...也许最好不要深究。）"
    hide side_p
    stop sound
    scene bg_black with w20
    jump morning


label fia_blood:
    scene fountain_jelly with w33
    $ fia_events.append("blud_dres")
    "你看到你的妹妹坐在鹅卵石地面上，整套衣服都浸透了血。"
    stop sound
    if girl:
        show palmierproxy pesta grit at center with moveinleft:
            yoffset 40
    else:
        show palmierproxy pesta grit at center with moveinleft:
            yoffset 100
    mc "菲亚！"
    play music "MUSIC/MusMus-BGM-084.mp3"
    show croissant dance2 sad sweat frusta at right with dissolve:
        yoffset 500
    show quil pesta sad sweat at left with dissolve:
        yoffset 200
    show palmierproxy ow sweat shock
    "你冲到菲亚身边，奎尔正尽力用他的衬衫擦去你妹妹脸上的血迹。"
    mc sad -shock "菲亚，发生什么事了？！"
    fia cringe -frusta "[povname]！我简直不敢相信有人...有人...*抽泣*"
    show croissant mmh 
    "你能听到菲亚在试图擦掉血迹时强忍着泪水。看到这一幕，你的心不禁有些碎。"
    quil tantrum "有人刚刚跑过，朝她泼了一桶血！"
    if "fish_blud" in fia_events:
        show quil sad shock
        show croissant shock
        mc pissed frusta "塔图姆！"
        fia kzl "什-什么？[povname]，你知道是谁对我做了这事？"
        show croissant sad frusta
        mc sigh "莱尔告诉我他无意中听到塔图姆计划毁掉你的裙子。"
        mc ow frusta "我忘了告诉你，我很抱歉！"
        show palmierproxy sad -frusta
        
        
    else:
        mc sad "你看到是谁了吗？"
        quil sulk sigh "没有，他们跑进人群里了。"
        fia mmh frusta "我的裙子！我的头发！为什么有人要这么做？！"
        mc ow "我们会找出那个混蛋的。除此之外，你没受伤吧？"
        show palmierproxy sad
        fia sad sigh "*抽泣*...不。但是我的裙子..."
        quil heh apa "如果我说这反而是种改进，你会生气吗？"
        show palmierproxy pissed shock
        fia kzl frusta "奎尔，我现在没心情听你耍嘴皮子！"
        show palmierproxy sad -shock
        quil sulk sigh "抱歉，亲爱的，我只是想让气氛轻松一点。"
    quil sad sigh "听着，既然已经发生了，我们就去把你清理干净吧，好吗？"
    fia cringe -frusta "*抽泣*...奎尔，你不会是策划了这一切吧？你没有参与其中，对吧？"
    quil err frusta "菲亚，如果我想捉弄你，我会做得更有品位。你知道我不喜欢羞辱别人。"
    quil amused -sweat sigh "我像讨厌姐妹一样讨厌你，但也像爱姐妹一样爱你。我绝不会这样伤害你。来吧，我们去把你弄干净。"
    fia sad sigh "*抽泣*。"
    stop music
    scene bg_black with w20
    jump morning_fia
label drama_unana:
    stop music
    scene fountain_jelly with vpunch
    play sound "sound/effects/squell.mp3"
    fia "啊啊啊！"
    $ fia_events.append("blud_dres")
    "菲亚的尖叫声打断了塞恩的话。你立即转头看向声音传来的方向，只见你的妹妹浑身被血浸透。"
    show croissant dance2 sad sweat frusta at right with dissolve:
        yoffset 500
    show quil pesta sad sweat at left with dissolve:
        yoffset 200
    if girl:
        show palmierproxy pesta grit at center with moveinleft:
            yoffset 40
    else:
        show palmierproxy pesta grit at center with moveinleft:
            yoffset 100
    mc "菲亚！"
    hide side_p
    play music "MUSIC/MusMus-BGM-084.mp3"
    "你和塞恩冲到菲亚身边，奎尔正用他的衬衫尽力擦拭你妹妹脸上的血迹。"
    mc sad -shock "菲亚，发生什么事了？！"
    fia cringe -frusta "[povname]！我简直不敢相信有人...有人...*抽泣*"
    show croissant mmh 
    "你能听到菲亚在试图擦掉血迹时强忍着泪水。看到这一幕，你的心不禁有些碎。"
    quil tantrum "有人刚刚跑过，朝她泼了一桶血！"
    if "fish_blud" in fia_events:
        show quil sad shock
        show croissant shock
        mc pissed frusta "塔图姆！"
        fia kzl "什-什么？[povname]，你知道是谁对我做了这事？"
        show croissant sad frusta
        mc sigh "莱尔告诉我他无意中听到塔图姆计划毁掉你的裙子。"
        mc ow frusta "我忘了告诉你，我很抱歉！"
        mc confused -frusta "哦，那个贱人！等等，这真的是血，不是油漆吗？"
        
        
    else:
        mc sad "你看到是谁了吗？"
        quil sulk sigh "没有，他们跑进人群里了。"
        fia mmh frusta "我的裙子！我的头发！为什么有人要这么做？！"
        mc ow "我们会找出那个混蛋的。除此之外，你没受伤吧？"
        show palmierproxy sad
        fia sad sigh "*抽泣*...不。但是我的裙子..."
        quil heh apa "如果我说这反而是种改进，你会生气吗？"
        show palmierproxy pissed shock
        show quil fluster shock
        fia kzl frusta "奎尔，我现在没心情听你耍嘴皮子！"
        quil sulk sigh "抱歉，亲爱的，我只是想让气氛轻松一点。"
        quil sad -sigh "也许只是红色油漆？"
    hide palmierproxy with dissolve
    show red party ngeles sweat at center with dissolve:
        yoffset 330
    red "这是血...准确地说是乌龟和鱼的血。"
    show red sad
    fia cringe frusta "呃！"
    red mls -sweat "..."
    quil err apa "塞恩，你还好吗？你的眼睛变红了。"
    show quil sad -apa
    show side_p sdh at pic
    mc "塞恩？"
    hide side_p
    show bite_lick1 with moveintop:
        yalign 0.0
    show bite_lick2 with moveinbottom:
        xalign 1.0
        yalign 1.0
    $ renpy.pause()
    galleryunlock bite_lick
    "你还没来得及反应，塞恩就向前倾身。他伸手抓住菲亚沾满血的手，然后贪婪地舔舐起来。"
    "他张大嘴巴，露出所有四颗犬齿，菲亚厌恶地迅速缩回了手。"
    hide bite_lick1 with dissolve
    hide bite_lick2 with dissolve
    show quil fluster shock
    fia jijik shock "你在干什么？！"
    red ngeles sweat "那个！我不是故意——"
    red perih frusta "该死！" with vpunch
    play sound "sound/effects/tile.mp3"
    hide red with dissolve
    "塞恩逃离了现场，你和周围的人都目瞪口呆地看着他。市民们畏缩着后退，仿佛一只野兽刚刚从他们身边跑过。"
    stop sound
    $ red_events.append('blud_redi')
    if girl:
        show palmierproxy pesta side at center with dissolve:
            yoffset 40
    else:
        show palmierproxy pesta side at center with dissolve:
            yoffset 100
    fia cringe frusta "那他妈是怎么回事？！"
    quil groan frusta "我不确定。老实说，红眼从未这样失控过。到底怎么回事？"
    show pboy s at horzappear
    menu:
        "是因为我吗？":
            hide pboy
            quil sad shock "你什么意思？"
            mc sad sigh "他说我闻起来很香。" 
            quil err apa "是\'哦，你闻起来很香，我想和你亲热\'的那种方式，还是\'我真的想吃了你\'的那种方式？"
            show quil sad -apa
            mc side sweat -sigh "后者。"
            if "map1" in completed_quests:
                quil sulk sigh "哦。好吧，这可不利于反驳温斯顿的说法，是吧？"
            else:
                quil sulk sigh "哦。好吧，这听起来相当不祥，不是吗？"
            fia kzl ang "我们能不能先别讨论这个，专注于把我弄干净？我感觉太恶心了！"
            show croissant sad -ang
            mc frown -sweat "好的。等一下.."
            if not girl:
                play sound "sound/effects/cloth.mp3"
                hide palmierproxy with dissolve
                show quil frown shock
                show croissant wry -sweat sigh
                "你脱下白衬衫，让菲亚用它擦掉一些血迹。"
                "如果更多人开始盯着你几乎赤裸的身体看，那又有什么关系呢？"
                "这总比看到你妹妹再次哭泣要好。"
                
            else:
                mc kzl "奎尔，把你的衬衫脱下来。"
                quil err shock"但是你会看到我的乳头。这个世界还没准备好欣赏如此杰作！"
                mc pissed frusta "我已经能看到你的乳头了。快点脱下来，用它遮住菲亚！"
                quil sulk sigh "哈...好吧。"
            stop music
            scene bg_black with w20
            "你们三个回到宿舍，你护送着妹妹远离任何窥探的目光。"
            
            "回到宿舍后，菲亚决定在你的房间里洗澡。"
            if "fish_blud" in fia_events:
                "发誓要让塔图姆为此付出代价。"
            else:
                "发誓要让做这件事的人得到应有的惩罚。"
            jump morning_fia
        "我们要去追他吗？":
            hide pboy
            show quil sad shock
            fia jijik shock "你们要丢下我吗？！"
            show croissant sad -shock
            show quil -shock
            "菲亚恳求道，她的手紧紧抓着你的衬衫，在上面留下了斑斑点点的红色污渍。"
            "她的嘴唇颤抖着，显然希望你留下来。"
            show pboy s at horzappear
            menu:
                "让她和奎尔在一起":
                    hide pboy
                    show quil sad shock
                    mc side sigh "菲亚，回宿舍洗个澡吧。奎尔会陪你去的。"
                    show quil -shock
                    fia cringe shock "什么？但你从来不会...这是怎么回事？"
                    show croissant sad -shock
                    mc sad -sigh "我只是在担心塞恩而已。"
                    fia cringe frusta "从什么时候开始你比担心我更担心他了？"
                    show palmierproxy side sweat sigh
                    "\'因为你不是我真正的妹妹\'是你想说的话，但你忍住了，因为你很清楚现在不是说这种话的时候。"
                    $ main.acara += 1
                    mc kzl frusta "你会没事的。我在担心塞恩，好吗？如果他失控咬了别人怎么办？"
                    mc confused sigh "奎尔，照顾好她，好吗？"
                    show croissant sad shock
                    show palmierproxy sad -sigh
                    quil sulk "好的。来吧，亲爱的。"
                    play sound "sound/effects/walk.mp3"
                    hide quil with dissolve
                    hide croissant with dissolve
                    "菲亚不情愿地站了起来，奎尔脱下衬衫盖在她身上。"
                    "菲亚最后给了你一个失望的眼神，然后低着头朝宿舍走去。"
                    scene fountain_jelly with dissolve
                    "你感到很难过，但你刚才说的关于塞恩的话是认真的。自从他喝了你的血后，就有些不对劲。"
                    play sound "sound/effects/tile.mp3"
                    stop music
                    "你跑开了，希望能在镇上某处追上塞恩。"

                    jump red_curhat_blud
                "当然不是！":
                    hide pboy
                    mc ow frusta "当然不是。我确实很担心，但现在你更重要。"
                    
                    if not girl:
                        hide palmierproxy with dissolve
                        play sound "sound/effects/cloth.mp3"
                        show quil frown shock
                        show croissant wry -sweat sigh
                        "你脱下白衬衫，让菲亚用它擦掉一些血迹。"
                        "如果更多人开始盯着你几乎赤裸的身体看，那又有什么关系呢？"
                        "这总比看到你妹妹再次哭泣要好。"
                
                    else:
                        mc kzl cling "奎尔，把你的衬衫脱下来。"
                        quil err shock "但你会看到我的乳头。这个世界还没准备好欣赏如此杰作！"
                        mc pissed frusta "我已经能看到你的乳头了。快点脱下来，用它遮住菲亚！"
                        quil sulk sigh "...好吧。"
                    stop music
                    scene bg_black with w20
                    "你们三个回到宿舍，你护送着妹妹远离任何窥探的目光。"
                    if "fish_blud" in fia_events:
                        "发誓要让塔图姆为此付出代价。"
                    else:
                        "发誓要让做这件事的人得到应有的惩罚。"

                    jump morning_fia
label morning_fia:
    scene bed_mlm with w20
    play sound "sound/effects/doorslam.mp3"
    $ fia_events.append("ama_fia")
    show croissant sad at center with dissolve:
        yoffset 500
    fia sigh "浴室随你用。"
    if girl:
        show palmierproxy pesta wry at left with dissolve:
            yoffset 40
    else:
        show palmierproxy pesta wry at left with dissolve:
            yoffset 100
    mc tanya "感觉好些了吗？"
    play music "MUSIC/MusMus-BGM-092.mp3"
    show palmierproxy sad sigh
    fia cringe frusta "干净了，但我还是感觉糟透了。"
    "你还穿着节日的服装。菲亚不知为何不想在自己的房间里洗澡。"
    "你很庆幸莱尔还没有回到房间。你觉得自己无法恰当地解释这一切。"
    "即使是像莱尔这样甜蜜善解人意的男孩也不行。"
    show croissant frown sigh at right with move
    play sound "sound/effects/cloth.mp3"
    "菲亚洗完澡后，头发还湿漉漉的，就扑通一声倒在你的床上。她躺下，望着天花板。"
    show croissant mmh sweat -sigh
    "她皱着眉头，似乎在深思着什么。"
    show pboy s at horzappear
    menu:
        "要我帮你梳头发吗？":
            hide pboy
            fia frown -sweat "今晚不用了...只要和我一起躺在这里就好。"
            mc deject -sigh "我还没洗澡。"
            fia sad "但你很干净。这样就够了，对吧？"
            mc sad sigh"..."
            "你让头靠在枕头上，就在她旁边盯着天花板——模仿她的姿势。"
            show palmierproxy frown shock
            fia mmh apa "今晚我可以和你一起睡在这里吗？"
            fia sad -apa "我不想一个人。"
            
        "你会把床弄湿的。":
            hide pboy
            fia mmh frusta "别担心，我会睡在湿的那边。"
            mc confused shock "你要睡在这里？"
            show palmierproxy sad -shock
            fia cringe frusta "我告诉过你我今晚不想一个人。"
    mc side sweat sigh "但你有室友啊。"
    fia mmh frusta "那不一样，你知道的！来嘛，每次你做那些奇怪的噩梦时，不都是偷偷钻进我的床吗！"
    mc wry sigh "好吧，但我得提醒你，莱尔打呼噜。"
    fia malu -sweat -frusta "你不打呼噜吗？不过还是谢谢你的提醒吧..."
    fia cringe frusta "不过这都无所谓，经历了这糟糕的一天，我估计也睡不着。"
    mc sad -sigh "我知道你已经太大了，但要不要我唱摇篮曲帮你入睡？"
    fia wry -frusta "呵，你真贴心，但今晚就算了，小抱怨精。"
    fia sad "我只是需要...需要...嗯。"
    "一滴眼泪顺着她的脸颊流下，你用拇指擦掉了它。你等着她平静下来。"
    fia sad sweat sigh "我花了好几个小时做那个花环，现在全都被血浸透了。"
    fia -sigh "为什么会这样？我什么都没做，只是在开心地玩耍，难得像个年轻人一样。"
    fia mad "哼...这里的每个人都想在背后捅你一刀。我讨厌这样。"
    fia gross "我是说，我确实有自己的问题，没错。我是个婊子，但有些底线我是不会逾越的。"
    fia mmh sigh "毁掉一个女孩精心打扮感觉美丽的日子就是其中之一。"
    "说到这里，她的眼睛开始湿润，强忍着泪水，鼻子也开始发酸。"
    "看到这一幕，你的心不禁揪了起来。"
    mc side -sigh "哦，菲亚。"
    show pboy s at horzappear
    menu:
        "我们会报仇的。":
            hide pboy
            if "fish_blud" in fia_events:
                mc pissed frusta "我发誓要让塔图姆付出代价！"
            else:                
                mc grit frusta "他们不会逃脱惩罚的。我发誓要找出那些罪魁祸首，让他们付出代价！"
            show croissant flinch hmph blush sigh
            "菲亚擦去眼泪，嘴角浮现出一丝愉悦的笑容。"
            "你心中的痛楚稍稍缓解，希望能很快在她脸上看到真挚的笑容。"
            fia hister bloom "我知道，这就是我喜欢你的地方。你是个反派。"
            mc huh tanya "这算是夸奖吗？"
            show palmierproxy frown -sweat shock
            $ kindness -= 20
            fia ejek cling "当然是！"
            show palmierproxy -shock
            fia laugh -cling "英雄会为了拯救世界而牺牲我，但反派会为了我而毁灭整个世界。"
            show palmierproxy kind -sweat
            show croissant smile at center with move
            "菲亚调整了姿势，不再躺在床上，而是蓬松了枕头，舒适地钻进了被子里。"
            "她蜷缩成一个茧，像守护世界上最珍贵的宝藏一样紧紧裹着整条被子。"
            "这个习惯让你想起了自己的妹妹，她以前经常偷偷溜进你的房间，恳求你保护她远离噩梦。"
            fia wry sigh "晚安。"
            mc smile "...晚安。"
            scene kmr_malam with dissolve
            "当你走向浴室时，不禁思考着妹妹的话。"
            "你不得不承认，你的替身可能确实更适合当个反派。问题是，站在哪一边呢？"


            
        "在我眼里你很漂亮。":
            hide pboy
            fia wry both sigh "是啊，但你是我的[kk]，这不算数。"
            fia cringe -both frusta "或者也许算数？我是说，妈妈总是说你比我漂亮，所以我也不知道。"
            mc deject sigh "她只是在逗你玩。她喜欢看你局促不安的样子。相信我，如果你出了什么事，她会后悔说过那些话的。"
            mc sad -sigh "（在我的世界里，她已经后悔了。）"
            fia mmh "*抽泣*...我想是吧。"
            if "fish_blud" in fia_events:
                fia kzl "我发誓，一看到塔图姆，我就要抓住她的头发，把她的脑袋往最近的墙上撞！"
                mc avoid "这确实是赢得打斗的有效方法，但你知道还有一种神奇的方法叫\'谈判解决\'。"
                mc kind "有时候以火攻火只会引起更大的火灾。"
                fia mad sigh "好吧，我会先谈判。"
                fia pain apa "但之后我可以把她点着火...？"
                mc mock cling "...只有在老师看不见的时候。"
                show palmierproxy happy bloom
                fia hister bloom "太好了！"
            else:                
                fia kzl frusta "我发誓要找出幕后黑手。"
                mc wry sigh "我知道你会的，但现在先睡吧。谁知道呢？也许明天醒来，这恶作剧就像个噩梦一样消失了。"
                fia cringe sigh "但愿如此！"
    "你洗漱完毕，上床睡觉了。"
    stop music
    scene bg_black with w20
    jump morning
            

label tom_buff_buli:
    $ buff_events.append('ketemu_buli')
    scene lake_jelly with w20
    show buff pblood keluh sweat at right with moveinright:
        yoffset 770
    show tom party kzl at left with dissolve:
        xzoom -1.0
        yoffset 190
    play sound "sound/effects/punch.mp3"
    queue sound "sound/effects/bump.mp3"
    queue sound "sound/effects/crash.mp3"
    show buff sad frusta
    play music "MUSIC/MusMus-BGM-075.mp3"
    "当你跑向码头时，听到一阵沉重的撞击声，好像有人在挨打。"
    "你以为是塞恩，急忙冲向声音的来源，但却发现阿什姆和莱尔被艾杰克斯和他的同伙包围着。"
    "艾杰克斯挥舞着他的冰匕首，朝阿什姆甩去。月光恰好照在匕首上，闪烁着寒光，锋利的一端指向两个高大的男人。"
    $ NPC = "阿贾克斯"
    show npc_1_m at pic
    npc "我要好好享受这一刻！"
    hide npc_1_m
    show pboy s at horzappear
    menu:
        "揍艾杰克斯":
            hide pboy
            $ kindness -= 20
            if "cupu" in my_events:
                show buff eh shock
                show tom ew shock
                play sound "sound/effects/tile.mp3"
                "你冲向艾杰克斯，直接朝他的嘴巴挥出一拳。"
                show buff sad
                "...至少这是本应发生的情况。只是再一次，你从未打过架，所以你只是挥拳却完全打空了。"
                show tom capek frusta
                play sound "sound/effects/crash.mp3"
                "你踉跄了一下，反而摔了个屁股墩。" with vpunch
                play sound "sound/effects/punch.mp3"
                queue sound "sound/effects/bump.mp3"
                show tom kzl -frusta
                show buff sad
                show buff eh shock
                "幸好，阿什姆替你掩护了，他一脚踢中艾杰克斯的下巴，让他向后摔倒，匕首掉落并碎成两半。"
                show buff wry sigh
                "艾杰克斯昏倒在混凝土地面上，其他人则惊讶地盯着这一幕。"
                $ NPC = "男生A"
                npc "他妈的怎么回事？"
                tom ew blow "走。"
                tom ejek cling "除非你们想让我给你们的母亲打电话，告诉她你们去年夏天做了什么？"
                $ NPC = "夏亚"
                npc "我是私下告诉你的，你不敢这么做！"
                tom cruel blow "恐怕你高估我了。你看，我可不介意使用勒索手段。"
                tom ejek -blow "唯一的缺点是，诅咒往往更有效。"
                $ NPC = "奈恩斯"
                stop music
                npc "你...这事还没完！"
                if girl:
                    show palmierproxy pesta confused at center with dissolve:
                        yoffset 40
                else:
                    show palmierproxy pesta confused at center with dissolve:
                        yoffset 100
                
                
                
                
            else:
                play sound "sound/effects/punch.mp3"
                queue sound "sound/effects/bump.mp3"
                queue sound "sound/effects/crash.mp3"
                "这些年来你经历过不少打斗，你踢开了阿贾克斯的刀，然后用尽全力给了他一拳。" with vpunch
                "阿贾克斯踉跄着后退，昏了过去，他的朋友们都震惊地盯着你。"
                npc "他妈的怎么回事？"
                show tom kzl shock
                buff eh shock"[povname]？"
                $ NPC = "男生A"
                npc "你在这里做什么？"
                show buff wry sigh
                if girl:
                    show palmierproxy pesta confused at center with dissolve:
                        yoffset 40
                else:
                    show palmierproxy pesta confused at center with dissolve:
                        yoffset 100
                mc kzl sigh "帮朋友一把。现在滚开，否则我就把你们打得满地找牙！"
                $ NPC = "男生B"
                npc "我...呃。我们走吧，奈恩斯。和[povname]打架不值得！"
            show tom kzl blow
            stop music
            play sound "sound/effects/tile.mp3"
            "那些男孩离开了，抬着阿贾克斯昏迷的身体。"
            mc side tanya "莱尔，阿什姆，你们没事吧？"
            show palmierproxy -tanya
            stop sound
            buff wry sigh "我...没事。"
            tom capek frusta "我没想到你会来帮忙。科尔是在考验我吗？"
            mc rajuk sigh "嘿，我还是你的朋友，你知道吗？是你一直在躲着我。"
            tom nyesal blow "我并不是在刻意躲你，只是——"
            show tom kzl shock
            buff keluh -sigh "呃，阿什姆先生，[povname]？看来你们俩有很多话要说，所以...我就先走了。"
            show tom capek -shock
            buff hister "谢谢你今晚的帮助。我很感激！"
            mc sad shock "等等，莱尔——"
        "呼喊阿贾克斯":
            hide pboy
            if girl:
                show palmierproxy pesta kzl sweat at center with moveinleft:
                    yoffset 40
            else:
                show palmierproxy pesta kzl sweat at center with moveinleft:
                    yoffset 100
            mc grit frusta "住手，阿贾克斯！"
            show palmierproxy kzl
            $ honesty += 10
            $ NPC = "阿贾克斯"
            show npc_1_m at pic
            $ honesty += 10
            npc "[povname]？"
            hide npc_1_m
            show tom shock
            show npc_1_m at pic
            npc "你是来救你男朋友的吗？"
            hide npc_1_m
            tom ew frusta "我拒绝被那样称呼。"
            show tom kzl
            show npc_1_m at pic
            npc "哎呀，天堂里出现麻烦了？好吧，那我就不会感到那么内疚了。"
            hide npc_1_m
            show tom sad shock
            "阿贾克斯挥舞着他的冰匕首，割伤了你的脸颊。你畏缩了一下，能感觉到指尖上沾着湿润的血液。"
            buff scold frusta "住手！"
            show npc_1_m at pic
            npc "啊啊啊！！！"
            hide npc_1_m 
            show tom whine sweat shock
            show palmierproxy sad shock
            show buff kzl frusta
            stop music
            show tabok_bloom with flashbulb
            play sound "sound/effects/vine.wav"
            "花朵开始从阿贾克斯的手腕处爆发而出。他的匕首掉落在地，因为他再也没有手来握住它了。"
            "你和阿什姆都被这一幕惊呆了，你们已经怀疑只有一个人能做出这样的事。"
            "从你的眼角余光中，莱尔金色的眼睛在月光下似乎更加明亮。他挥手时，那种强烈的凝视令人无法忽视。"
            show tabok_wither with dissolve
            hide tabok_bloom
            "他挥手解除了诅咒，花朵消散了，阿贾克斯也没有受到任何伤害。"
            buff scold sigh "别管我们！"
            $ NPC = "男生A"
            npc "巫师！巫师！"
            $ NPC = "男生B"
            hide tabok_wither with dissolve
            npc "快跑，在他召唤出更多花蕾之前！这就像死亡地带重演！"
            play sound "sound/effects/tile.mp3"
            show buff kzl -sigh
            "那些欺凌者吓得逃跑了，而你和阿什姆则呆若木鸡。"
            stop sound
            show buff eh shock
            "莱尔回过神来，对自己刚才所做的事感到害怕。就像一个刚被抓到偷偷把手伸进饼干罐的孩子。"
            buff keluh "啊，我很抱歉！请不要告诉任何人！我已经让花朵枯萎了，他的手应该已经长回来了！我——"
            show buff sad -shock
            show palmierproxy frown 
            tom nyesal "莱尔……"
            play music "MUSIC/MusMus-BGM-024.mp3"
            tom smile -sweat blow "干得好。"
            buff eh shock "你们不...害怕吗？"
            $ buff_events.append('bunga_time')
            show buff -shock
            show pboy s at horzappear
            menu:
                "有一点":
                    hide pboy
                    $ honesty += 10
                    tom sad frusta "[povname]！"
                    show tom frown -frusta
                    buff wry -sigh "不，这很合理。我也很害怕。"
            

                "所以你也是个杀人园丁？":
                    hide pboy
                    $ kindness -= 10
                    buff scold frusta "我和他一点也不像！"
            
                "你能给我种朵玫瑰花吗？":
                    hide pboy
                    show palmierproxy malu -sweat
                    $ kindness += 10
                    $ putri.points += 5
                    show buff hister
                    "莱尔对你孩子气的要求笑了笑，但笑容很快消失了。他意识到自己做了什么，变得沉重起来。"
                    buff wry -sigh "我甚至不确定我是怎么做到的。"
            buff keluh sigh "那...那是我第二次能够自己创造那些玫瑰。第一次是和伊尔夫意外发生的。"
            tom ha apa "伊尔夫？"
            buff sad -sigh "我的兄弟。我把他的一些头发变成了花环，但几个小时后它们就枯萎了。"
            buff kzl"不过，这是我第一次在人类肢体上使用它。我只是太生气了，不想让他们伤害你。"
            tom capek frusta "即使在他们群殴你之后？你太仁慈了，莱尔。"
            buff wry "我对此并不确定。"
            buff sad "我曾经看到我父亲对我姐姐的男朋友使用过这个技巧。他会让玫瑰从他们的手腕上长出来，然后在完全替代手之前让它们消失。"
            buff keluh "肢体保住了，但仅仅如此。从手腕往下基本上无法活动。"
            buff sad "我本来只想长出一两片花瓣，但我的愤怒占了上风。如果他告诉老师怎么办？"
            tom sad blow "那我们就为你打掩护，莱尔。如果阿贾克斯敢报告这件事，我们的证词会证明事实并非如此。"
            mc wry sigh "没错。那就是他的话对我们的话。"
            show tom wry -blow
            show palmierproxy kind -sigh
            buff lega "谢谢你。"
            if curiosity >= 30:
                show buff frown shock
                mc sad tanya "不过，我能问点事吗？"
                mc deject -tanya "我以为只有伊瓦尔的女儿们继承了他的魔法，那你为什么能..."
                buff keluh -shock "与大众的看法相反，我...我不认为我父亲会那样把我们与魔法分开。"
                buff sad "我的大多数兄弟在被转化之前都能长出几个自己的花蕾。"
                buff "但我们没有像姐妹们那样接受训练，也没有太多机会去探索我们的魔法。"
                buff keluh "而且我也不想要这些力量，我……我不想伤害任何人。"
                show buff sad 
                tom cruel "如果这能给你些安慰的话，你成功地为善使用了你的力量，莱尔。这是你应该为之骄傲的事。"
                buff lega "我...谢谢你。"
                show buff wry

            else:
                "你想让他进一步解释，但你决定忍住不问。"
                mc deject "（我今晚不该再追问他了。）"
            mc side "我们应该带你去医务室，检查一下你的伤口。"
            buff sad "我没事。况且呃...你们两个不是有话要说吗？对每个人来说都很尴尬，你知道吗？你们两个吵架的方式..."
            tom whine frusta "我们不是...嗯。你说得有道理。莱尔，你介意给我们一些私人空间吗？"
            show tom sad -frusta
            buff touched "乐意之至。呃，祝你们好运！"
            stop music
    play sound "sound/effects/tile.mp3"
    hide buff with dissolve
    show palmierproxy sad sigh at right with move
    "莱尔匆匆跑进夜色中，你甚至还没来得及解释任何事情。"
    "你几乎能看到他跑步时脚下扬起的尘土。"
    stop sound
    tom nyesal sweat blow"..."
    play music "MUSIC/MusMus-BGM-073.mp3"
    show pboy s at horzappear
    menu:
        "我们不能永远互相忽视！":
            hide pboy
            tom sad sweat frusta "我从来没打算这样！我只是...我需要一些时间来发泄一下。"
            tom kzl "原谅我如果我不特别喜欢被我的另一半和他们来自另一个世界的复制品一起欺骗！"
            tom whine blow "这只是——啊啊啊！"
            

        "什么也不说":
            hide pboy
            tom ha apa "沉浸在沉默中，是吗？"
            mc side sigh "我不知道该对你说什么，阿什姆。你想听什么？"
            tom capek frusta "为你的谎言道歉，为你一直欺骗我？你本可以说些什么的。"
            mc ow frusta "我想说的！奎尔告诉我不要说！为什么你生我的气而不是生他的气？"
            show palmierproxy frown shock
            tom ejek cling "哦，你无法想象我为那个人准备了什么计划，但你也远非无辜。你是他的同谋！"
            mc huh frusta "一个不情愿的同谋！你真的认为我在这里过得很愉快吗？"
            mc kzl -frusta "一个巫师差点杀了我！"
            tom whine blow "我知道！我知道我不应该因为这种困境而责怪你，但你和[povname]长得一模一样！"
            tom kzl -blow "完全相同的笑声，相同的脸，还有——啊啊啊！"

        "我说过我很抱歉。":
            hide pboy 
            tom capek frusta "我知道！"
            mc ow frusta "这还不够吗？"
            tom ha blow "那样会更容易，不是吗？"
            tom sad -blow "我知道你甚至不是真正的[povname]，但你还是对我撒谎了。"
            tom whine "而这整个情况就是如此——啊啊啊！"
    show palmierproxy sad sigh
    tom capek frusta "这一切都太令人沮丧了！"
    "阿什姆花了点时间冷静下来，把头埋在手里，长长地深深地叹了口气。"
    show palmierproxy frown -sigh
    tom frown -sweat -frusta "...为我突然的爆发道歉。"
    tom ha "我让情绪阻碍了我的思考。你不是这一切的幕后主使，只是奎尔肮脏游戏中的一个棋子。"
    tom capek "我为自己这几天的不得体行为道歉。你不是主要的肇事者，所以，我希望能和解。"
    show palmierproxy smile -sweat cling
    show tom eh both shock
    mc "现在再说一遍，但语气不要那么傲慢。"
    show palmierproxy wry -cling
    tom calm blow "你真让人难以忍受。我简直不敢相信我竟然没注意到你们两个之间的差异。你完全缺乏[povname]的品格。"
    tom whine -blow "但是没错，重点是我承认我是个混蛋。当然，考虑到你、奎尔和我的……给我出的难题，我认为我有充分的理由这么做。"
    tom sad "……被[povname]给我出的难题。"
    mc side -sweat sigh "我知道这很难相信，因为我的脸和[povname]一模一样，但是……我不是[povname]。我是阿什姆。"
    mc sad -sigh "我真的为假装成他而感到抱歉。"
    tom sigh blow "我知道。"
    tom wry -blow "我也很抱歉，把我的愤怒发泄在你身上。"
    mc hister tanya "……重新开始？"
    show tom frown shock
    "你伸出手想要和阿什姆握手。"
    show palmierproxy kind bloom
    show tom calm -both bloom 
    "他盯着你的手看了一秒，然后诚恳地握了上去。"
    tom smile "重新开始。"
    mc kind "那么你现在想回去吗？"
    tom ejek cling "待会儿吧，我正忙着思考惩罚奎尔的方法。死刑太仁慈了。"
    mc happy "啊哈哈，那么我想我就加入你吧。"
    tom ha apa "真的吗？"
    if "come_clean" not in tom_events:
        $ tom_events.append("come_clean")
    mc kind -bloom "是啊，我也想报仇。而且，这里的景色很不错……"
    show tom calm blush -apa
    scene jelly_sky with flashbulb:
        yalign 1.0
        easein 10.0 yalign 0.0
    "你和阿什姆度过了剩下的夜晚，看着星星，讨论着各种恶作剧来整奎尔。"
    stop music
    scene bg_black with w20
    jump morning

label red_curhat_blud:
    scene jelly_night with w33
    play sound "sound/effects/tile.mp3"
    "在寻找塞恩时，你会先检查哪个区域？"
    show pboy s at horzappear
    menu:
        "码头。":
            hide pboy
            scene bg_black with w20
            jump tom_buff_buli
        "酒吧附近。":
            hide pboy
            scene red_cur_night with fade
            "你最终发现塞恩独自坐在一张长凳上，双手捂着头。"
            stop sound
    play music "MUSIC/MusMus-BGM-077.mp3"
    show red party sad sweat frusta at center with dissolve:
        yoffset 330
    red "控制住自己。沙兹塔·海因。维斯纳·乌恩。"
    red perih "你不是野兽，不要让血液左右你。我不是邪血者。我不是……"
    show red ngeles shock
    if girl:
        show palmierproxy pesta side tanya at right with moveinright:
            xzoom -1.0
            yoffset 40
    else:
        show palmierproxy pesta side tanya at right with moveinright:
            yoffset 100
    mc "塞恩？"
    show palmierproxy sad -tanya
    $ red_events.append('curhat_dance')
    show red ow at left with move
    red frusta "退后！！！"
    "塞恩的尖叫让你僵在原地。你从未听过这个红发男子如此凶狠地喊叫。"
    mc ow sweat "怎么了，你还好吗？"
    red ngeles sigh "[povname]，你现在不该靠近我。我可能……我可能会咬你。"
    mc side "你渴了吗？我是说，如果你渴了的话——"
    red ew both frusta "你不明白。我不只是想咬你。我想用牙齿撕碎你的衣服，把它们撕成碎片。"
    if not girl:
        red calm cling "把你按在地上，让你热血沸腾，然后从你肿胀的……上吸干血液。"
    else:
        red calm cling "把你按在地上，让你热血沸腾，然后从你湿润的……上吸干血液。"
    show red ngeles shock
    mc ow both shock "哇，好吧！我明白了。我是吸血鬼的春梦对象。请在孩子们听到之前停下！"
    show red ew sweat frusta 
    show palmierproxy side sweat -shock
    "当你说这话时，你确实看到远处有一两个来自莱纳尔的孩子在跑来跑去。"
    "他们离得太远，听不到也看不清楚任何东西，但谁知道呢，你宁可安全一点。"
    red sad "对不起！对不起，我……该死！"
    show red perih -frusta
    show palmierproxy sad -sweat shock
    play sound "sound/effects/bite.mp3"
    "塞恩开始沮丧地咬自己的手，显然无法很好地应对这种情况。"
    "看到他如此绝望，你……"
    show pboy s at horzappear
    menu rawat:
        "继续靠近":
            hide pboy
            show palmierproxy confused -sweat cling at center with move
            show red ngeles shock
            "感到勇敢，又有点愚蠢，你决定大步走向塞恩，不顾他明显的抗议，直接坐在他旁边。"
            red ow both frusta "你在做什么？"
            show red sad shock
            mc side sigh "我不会让你独自承受这些！我曾经是个瘾君子，我知道那种感觉！"
            red growl -both frusta "瘾君子？不，这远不止如此，[povname]。这是我的掠食本能，我可能真的会杀了你！"
            show red sad shock
            mc kzl -sigh "但你不会的！"
            mc kind sweat "（……对吧？）"
            show palmierproxy mean -sweat cling
            red huh sigh "哈啊..."
            "你握住塞恩的手，而他深深地吸着气。"
            "在经过了似乎一个小时的沉默之后，他终于平静下来。他眼中的猩红色褪去，变成了明亮的棕色。"
            show red wry -sigh
        "给他一瓶药水" if check_inv_for(blood_items):
            hide pboy
            show red kzl sweat shock
            mc deject sigh "我这里还有一瓶备用的血液药水，给——"
            show palmierproxy confused sweat shock
            if check_inv_for(plas_items):
                $ InvItem(*item_plasma).toss(1)
            elif check_inv_for(sir_items):
                $ InvItem(*item_blood).toss(1)
            elif check_inv_for(sir_items):
                $ InvItem(*item_siren).toss(1)
            show red perih -shock
            play sound "sound/effects/plate.mp3"
            queue sound "sound/effects/drip.wav"
            "塞恩抓过药水，一口气喝光了。"
            show red wry -sweat sigh
            show palmierproxy malu -sweat -shock
            "现在平静下来了，塞恩的眼睛变回了棕色，他似乎终于冷静了下来。"
            show palmierproxy kind 
            red sayang -sigh "谢谢你，我……我需要这个。"
            $ red_events.append('obat')
        "{s}给他一瓶药水{/s}" if not check_inv_for(blood_items):
            
            jump rawat
    mc malu tanya "感觉好些了吗？"
    show palmierproxy kind -tanya
    red amused "差不多吧。"
    mc side "刚才那里发生了什么？"
    red ew frusta "本能。那血液……它在对我歌唱。"
    red ngeles "即使是现在，我还能听到你血液在血管中奔流的轰鸣声。这……很诱人。"
    red sad sigh "……ShaztaHein.VisnaUn。"
    mc confused "那是什么？"
    show palmierproxy frown
    red ngeles -sigh "这是我母亲过去常常用我们的母语念诵的一句话。大意是\'不要让野兽占上风。\'"
    show red sad
    mc ew "野兽？"
    show palmierproxy frown
    red huh "你可能还没见过，但吸血鬼其实有另一种形态，类似于狼人。"
    red kzl "想象一下无毛的蝙蝠，而不是毛茸茸的毛球。"
    mc ow "呃，听起来不太妙。"
    show palmierproxy sad
    red lelah sigh "我们也不喜欢。我们的骨骼会延长，多重尖锐的獠牙会从皮肤中突出，形成多组能正常运作的嘴。"
    red "我们的翅膀会完全暴露，尾骨会向外延伸，撕裂皮肤——形成一种无毛的尾巴。"
    red perih sweat frusta "这简直是噩梦。"
    show red kzl -sweat shock
    mc confused "那才是\'真正的\'你吗？"
    red ew frusta "……我知道你不是这里的人，所以这次我就不计较你的话了。"
    show palmierproxy side sweat shock
    red happy -sweat cling "但如果你再对我说这种话，我会把你吸干的。"
    show red mock -cling
    show palmierproxy sad -sweat -shock
    "尽管他脸上挂着笑容，但很明显他并不是在开玩笑。如果你再这样冒犯他，他可能真的会杀了你。"
    red kzl frusta "啊……抱歉，又是本能作祟。我不是想吓唬你。"
    mc hister sigh "没关系。我已经有点习惯这里的一切都可能会杀死我的想法了。"
    show palmierproxy wry -sigh
    red mock sigh "……呵。"
    red frown -sigh "……那种形态被称为我们的邪血形态。那是当我们沉醉于鲜血，变得如此失控以至于抛弃人性的时候。"
    red ew frusta "不再能够理性思考或说出可理解的话语，只是一个疯子试图获得下一次的满足。"
    show pboy s at horzappear
    menu:
        "你见过邪血形态吗？":
            hide pboy
            red lelah sweat sigh "见过很多。我……我妈妈就被变成了那样。"
            show red sad -sigh
            mc kzl sweat shock "什么？"
            show palmierproxy sad -shock
            red ew -sweat -sigh "这是对她犯下反叛皇室罪行的惩罚。"
            red sad "吸血鬼有一个不可动摇的等级制度。君主想要什么，他们就会得到什么，没有例外。"
            red ngeles "他们的血液比大多数人的更纯净。有些甚至能像操纵木偶一样控制其他吸血鬼。我年轻的时候，曾经觉得这很酷。"
            red lelah sigh "现在我比世界上任何东西都更害怕这种吸血鬼。"
            red huh -sigh "尤其是阿列克谢王子。我宁愿面对任何其他君主，甚至是尼尔国王。但不是他那该死的继承人阿列克谢。"
            mc confused "为什么？"
            $ red_events.append("pile")
            red ew frusta "是他下令惩罚我妈妈的。"
            red kzl sigh "我母亲曾是一位受人尊敬的血骑士。维尔科娃女士在成为老师之前也是君主的骑士。她在我妈妈变成那样之前就认识她——"
            "塞恩靠在长凳上，凝视着天空，似乎在努力寻找合适的词语来表达。"
            red sad -sigh "她在我妈妈变成那样之前就认识她。你看，我本应成为阿列克谢王子的私人血骑士。"
            red lelah "他很在意外表，而且他比我小几岁，所以他亲自挑选了我。"
            red sad sweat "我想让我妈妈感到骄傲，所以我答应了。但他没告诉我，为了继续下去，我必须吸干一个无辜陌生人的血。"
            red wry "他让我杀一个6岁的孩子，你能想象吗？一个该死的扎着辫子、脸上有雀斑、蓝眼睛大大的6岁女孩。"
            red ngeles "就在她母亲面前。那个女人是O型血，他有时会在他的核心圈子里传递。"
            red ew "我曾经看着那个女人顺从地微笑，在一个又一个吸血鬼之间传递。从不抱怨，甚至没有一句不满的话。"
            red ngeles "但当他们带来她的女儿让我杀死时……她尖叫了，那是一种发自内心、最原始本能的尖叫。"
            red sad sigh "……我做不到，而我的母亲为此付出了代价。"
            red -sigh "违抗君主命令的惩罚是死刑，但她抗议并讨价还价，换取了流放。"
            red ngeles "代价是她的人性。"
            red sayang sigh "邪血形态的力量只有狼人能与之匹敌。"
            red -sigh "吸血鬼们迫切需要他们来征服狼人，但你知道……这并不是一个特别受欢迎的职位。"
            "塞恩嗤笑一声，可怜地试图缓解紧张气氛，显然在回忆这一切时感到很困难。"
            mc side frusta "塞恩——"
            red ngeles frusta "我妈妈为了我变成了一个没有理智的嗜血怪物，而我现在正在努力抑制想要咬你的冲动。把你吸干。"
            red sad sigh "...回宿舍去吧，[povname]。我现在不能和你在一起。"

        "你是不是疯了？":
            hide pboy
            red hister sigh "啊哈哈哈！我不知道。也许吧？"
            red amused -sigh "我真的在努力不搞砸事情，伙计。而你的气味真的没有帮上忙。"
            red sad "你的血...它不一样。可能是因为你不是来自这个世界，但是，它真他妈的神圣。"
            if "obat" not in red_events:
                show palmierproxy sad sweat
                
                red calm "如果我能再咬一口就好了..."
                play sound "sound/effects/cloth.mp3"
                show palmierproxy sad shock at right with move
                show red with move:
                    xalign 0.7
                "塞恩靠近，他的呼吸热烈地喷在你的脖子上，他迅速舔了一下。"
                show palmierproxy ew sweat -shock
                "你等待着疼痛的到来。等待着他尖锐的獠牙刺破你皮肤的感觉，但它始终没有来。"
                show red perih sweat frusta
                play sound "sound/effects/bite.mp3"
                show palmierproxy frown shock
                "相反，灰色的血滴落在你身上，因为塞恩再次咬了自己的手。"
                show palmierproxy sad -shock
                show red at center with move
                red wry sigh "...回宿舍去吧，[povname]。我现在不能和你在一起。"
                show red kzl frusta
                "他在舔掉自己的血之前喃喃自语。"
            else:
                red sad sigh "...回宿舍去吧，[povname]。我现在不能和你在一起。"
                red -sigh "即使有那种药水，你的血对我来说还是太诱人了。"
    mc side sigh "好吧。"
    mc wry tanya "...你会没事的，对吧，塞恩？"
    red amused sigh "...我必须没事。"
    stop music
    scene bg_black with w33
    "你回到宿舍，洗了个长长的澡，然后倒回床上。"
    "努力驱散胃里不祥的恐惧感，你终于进入了深深的睡眠。"
    jump morning