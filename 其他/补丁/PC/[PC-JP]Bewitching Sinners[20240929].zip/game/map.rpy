#WORLD_MAP
screen dorm_bar():
    add "images/search.png" xpos 771 ypos 599
screen shops_bar():
    add "images/search.png" xpos 1225 ypos 227
screen lower_bar():
    add "images/search.png" xpos 1128 ypos 190
screen garden_bar():
    add "images/search.png" xpos 1089 ypos 730
screen side_bar():
    add "images/search.png" xpos 1160 ypos 603
screen arena_bar():
    add "images/search.png" xpos 1153 ypos 305
screen arrow_bar():
    add "images/search.png" xpos 825 ypos 203
screen spar_bar():
    add "images/search.png" xpos 1002 ypos 242
screen fish_bar():
    add "images/search.png" xpos 677 ypos 886
screen foun_bar():
    add "images/search.png" xpos 967 ypos 363
screen court_bar():
    add "images/search.png" xpos 759 ypos 345
screen church_bar():
    add "images/search.png" xpos 858 ypos 257
screen kls_bar():
    add "images/search.png" xpos 1074 ypos 398
screen lab_bar():
    add "images/search.png" xpos 605 ypos 401
screen pots_bar():
    add "images/search.png" xpos 1074 ypos 398
screen citi_bar():
    add "images/search.png" xpos 897 ypos 48
screen peta_all():
    tag menu

    
    
    if calendar.weekday == "Sat" or calendar.weekday == "Sun":
        imagebutton:
            idle "images/maps/main/dorm_lg.png"
            hover "images/maps/main/dorm_lg_hover.png"
            xpos 1487 ypos 116
            hovered [ Play ("test_one", "type.wav"), Show("dorm_bar")]
            action [Hide("dorm_bar"), Jump("map_dorm")]
            unhovered Hide("dorm_bar")
            focus_mask None
            #mouse "search"
        imagebutton:
            idle "images/maps/main/shops_lg.png"
            hover "images/maps/main/shops_lg_hover.png"
            xpos 1487 ypos 174
            hovered [ Play ("test_one", "type.wav"), Show("shops_bar")]
            action [Play ("music", "MUSIC/MusMus-BGM-056.mp3"),Play ("test_one", "walk.mp3"), Hide("shops_bar"),Jump("grocery")]
            unhovered Hide("shops_bar")
            focus_mask None
            #mouse "search"
        imagebutton:
            idle "images/maps/main/pots_lg.png"
            hover "images/maps/main/pots_lg_hover.png"
            xpos 1487 ypos 228
            hovered [ Play ("test_one", "type.wav"), Show("pots_bar")]
            action [Play ("music", "MUSIC/MusMus-BGM-049.mp3"),Play ("test_one", "walk.mp3"),Hide("pots_bar"), Jump("map_potion")]
            unhovered Hide("pots_bar")
            focus_mask None
            #mouse "search"
        imagebutton:
            idle "images/maps/main/kls_lg.png"
            hover "images/maps/main/kls_lg_hover.png"
            xpos 1487 ypos 285
            hovered [ Play ("test_one", "type.wav"), Show("kls_bar")]
            action [Play ("music", "MUSIC/MusMus-BGM-049.mp3"),Play ("test_one", "walk.mp3"), Hide("kls_bar"),Jump("kelas_0_up2")]
            unhovered Hide("kls_bar")
            focus_mask None
            #mouse "search"
        imagebutton:
            idle "images/maps/main/fish_lg.png"
            hover "images/maps/main/fish_lg_hover.png"
            xpos 1487 ypos 346
            hovered [ Play ("test_one", "type.wav"), Show("fish_bar")]
            action [Play ("music", "MUSIC/MusMus-BGM-109.mp3"),Play ("test_one", "walk.mp3"), Hide("fish_bar"),Jump("mancingin")]
            unhovered Hide("fish_bar")
            focus_mask None
            #mouse "search"
        imagebutton:
            idle "images/maps/main/citi_lg.png"
            hover "images/maps/main/citi_lg_hover.png"
            xpos 1487 ypos 403
            hovered [ Play ("test_one", "type.wav"), Show("citi_bar")]
            action [Play ("music", "MUSIC/MusMus-BGM-142.mp3"),Play ("test_one", "walk.mp3"),Hide("citi_bar"), Jump("town_map")]
            unhovered Hide("citi_bar")
            focus_mask None
            #mouse "search"
        
        
    else:
        imagebutton:
            idle "images/maps/main/dorm_lg.png"
            hover "images/maps/main/dorm_lg_hover.png"
            xpos 1487 ypos 116
            hovered [ Play ("test_one", "type.wav"), Show("dorm_bar")]
            action [Play ("music", "MUSIC/MusMus-BGM-082.mp3"),Play ("test_one", "walk.mp3"), Hide("dorm_bar"), Jump("map_dorm")]
            unhovered Hide("dorm_bar")
            focus_mask None
            #mouse "search"
        imagebutton:
            idle "images/maps/main/shops_lg.png"
            hover "images/maps/main/shops_lg_hover.png"
            xpos 1487 ypos 174
            hovered [ Play ("test_one", "type.wav"), Show("shops_bar")]
            action [Play ("music", "MUSIC/MusMus-BGM-056.mp3"),Play ("test_one", "walk.mp3"), Hide("shops_bar"),Jump("map_store")]
            unhovered Hide("shops_bar")
            focus_mask None
            #mouse "search"
        imagebutton:
            idle "images/maps/main/lower_lg.png"
            hover "images/maps/main/lower_lg_hover.png"
            xpos 1487 ypos 228
            hovered [ Play ("test_one", "type.wav"), Show("lower_bar")]
            action [Play ("music", "MUSIC/MusMus-BGM-124.mp3"),Play ("test_one", "walk.mp3"),Hide("lower_bar"), Jump("map_lower")]
            unhovered Hide("lower_bar")
            focus_mask None
            #mouse "search"
        imagebutton:
            idle "images/maps/main/upper_lg.png"
            hover "images/maps/main/upper_lg_hover.png"
            xpos 1487 ypos 285
            hovered [ Play ("test_one", "type.wav"), Show("garden_bar")]
            action [Play ("music", "MUSIC/MusMus-BGM-116.mp3"),Play ("test_one", "walk.mp3"), Hide("garden_bar"),Jump("map_garden")]
            unhovered Hide("garden_bar")
            focus_mask None
            #mouse "search"
        imagebutton:
            idle "images/maps/main/side_lg.png"
            hover "images/maps/main/side_lg_hover.png"
            xpos 1487 ypos 346
            hovered [ Play ("test_one", "type.wav"), Show("side_bar")]
            action [Play ("test_one", "walk.mp3"), Hide("side_bar"),Jump("small_garden")]
            unhovered Hide("side_bar")
            focus_mask None
            #mouse "search"
        imagebutton:
            idle "images/maps/main/arena_lg.png"
            hover "images/maps/main/arena_lg_hover.png"
            xpos 1487 ypos 403
            hovered [ Play ("test_one", "type.wav"), Show("arena_bar")]
            action [Play ("music", "MUSIC/MusMus-BGM-136.mp3"),Play ("test_one", "walk.mp3"), Hide("arena_bar"),Jump("map_arena")]
            unhovered Hide("arena_bar")
            focus_mask None
            #mouse "search"
        imagebutton:
            idle "images/maps/main/arrow_lg.png"
            hover "images/maps/main/arrow_lg_hover.png"
            xpos 1487 ypos 465
            hovered [ Play ("test_one", "type.wav"), Show("arrow_bar")]
            action [Play ("music", "MUSIC/MusMus-BGM-062.mp3"),Play ("test_one", "walk.mp3"), Hide("arrow_bar"),Jump("map_arrow")]
            unhovered Hide("arrow_bar")
            focus_mask None
            #mouse "search"
        imagebutton:
            idle "images/maps/main/spar_lg.png"
            hover "images/maps/main/spar_lg_hover.png"
            xpos 1487 ypos 528
            hovered [ Play ("test_one", "type.wav"), Show("spar_bar")]
            action [Play ("music", "MUSIC/MusMus-BGM-007.mp3"),Play ("test_one", "walk.mp3"), Hide("spar_bar"), Jump("map_tempur")]
            unhovered Hide("spar_bar")
            focus_mask None
            #mouse "search"
        imagebutton:
            idle "images/maps/main/fish_lg.png"
            hover "images/maps/main/fish_lg_hover.png"
            xpos 1487 ypos 588
            hovered [ Play ("test_one", "type.wav"), Show("fish_bar")]
            action [Play ("music", "MUSIC/MusMus-BGM-109.mp3"),Play ("test_one", "walk.mp3"), Hide("fish_bar"),Jump("map_lake")]
            unhovered Hide("fish_bar")
            focus_mask None
            #mouse "search"
        imagebutton:
            idle "images/maps/main/foun_lg.png"
            hover "images/maps/main/foun_lg_hover.png"
            xpos 1487 ypos 647
            hovered [ Play ("test_one", "type.wav"), Show("foun_bar")]
            action [Play ("music", "MUSIC/MusMus-BGM-108.mp3"),Play ("test_one", "walk.mp3"), Hide("foun_bar"),Jump("map_fountain")]
            unhovered Hide("foun_bar")
            focus_mask None
            #mouse "search"
        imagebutton:
            idle "images/maps/main/court_lg.png"
            hover "images/maps/main/court_lg_hover.png"
            xpos 1487 ypos 707
            hovered [ Play ("test_one", "type.wav"), Show("court_bar")]
            action [Play ("music", "MUSIC/MusMus-BGM-037.mp3"),Play ("test_one", "walk.mp3"), Hide("court_bar"),Jump("map_court")]
            unhovered Hide("court_bar")
            focus_mask None
            #mouse "search"
        imagebutton:
            idle "images/maps/main/church_lg.png"
            hover "images/maps/main/church_lg_hover.png"
            xpos 1487 ypos 762
            hovered [ Play ("test_one", "type.wav"), Show("church_bar")]
            action [Play ("music", "MUSIC/MusMus-BGM-117.mp3"),Play ("test_one", "walk.mp3"), Hide("church_bar"),Jump("map_church")]
            unhovered Hide("church_bar")
            focus_mask None
            #mouse "search"
        imagebutton:
            idle "images/maps/main/kls_lg.png"
            hover "images/maps/main/kls_lg_hover.png"
            xpos 1487 ypos 817
            hovered [ Play ("test_one", "type.wav"), Show("kls_bar")]
            action [Play ("music", "MUSIC/MusMus-BGM-049.mp3"),Play ("test_one", "walk.mp3"), Hide("kls_bar"),Jump("map_kelas")]
            unhovered Hide("kls_bar")
            focus_mask None
            #mouse "search"
        imagebutton:
            idle "images/maps/main/lab_lg.png"
            hover "images/maps/main/lab_lg_hover.png"
            xpos 1487 ypos 874
            hovered [ Play ("test_one", "type.wav"), Show("lab_bar")]
            action [Play ("music", "MUSIC/MusMus-BGM-078.mp3"), Play ("test_one", "walk.mp3"), Hide("lab_bar"),Jump("map_perpus")]
            unhovered Hide("lab_bar")
            focus_mask None
            #mouse "search"
        if "poppy" in my_events:
            
            imagebutton:
                idle "images/maps/main/pots_lg.png"
                hover "images/maps/main/pots_lg_hover.png"
                xpos 1487 ypos 928
                hovered [ Play ("test_one", "type.wav"), Show("pots_bar")]
                action [Play ("music", "MUSIC/MusMus-BGM-049.mp3"),Play ("test_one", "walk.mp3"),Hide("pots_bar"), Jump("map_potion")]
                unhovered Hide("pots_bar")
                focus_mask None
                #mouse "search"
    

label world_map:
    if curiosity <0:
        $ curiosity = 0
    elif curiosity >100:
        $ curiosity = 100
    if honesty <0:
        $ honesty = 0
    elif honesty >100:
        $ honesty = 100
    if kindness <0:
        $ kindness = 0
    elif kindness >100:
        $ kindness = 100 
    if "bunga_bego" in buff_events:
        if "beku" in quil_events:
            scene map_infected_f
        else:
            scene map_infected
    else:
        if "beku" in quil_events:
            scene map_frozen
        else:
            scene map_all
    $ NPC = "???"
    call screen peta_all

#GARDEN_SMALL
label small_garden:
    hide screen peta_all
    scene taman_inner with dissolve
    
    if "vamp_visit" in red_events and "madyu" not in my_events:
        $ NPC = "???"
        npc "我没想到邪血会长得那么大。"
        npc "它们把我的一整丛伤寒草都吹走了！我需要那些来完成草药学作业！"
        npc "嘿，你能帮我弄些伤寒草种子吗？"
        mc "你可以从迪特里希那里得到一些成熟的。"
        npc "哦，是的，但那些都很小。我需要仙子的祝福才能至少得个C。"
        npc "嘿，你似乎和凯普勒相处得不错。你能请凯普勒为我的伤寒草祝福吗？"
        mc "你凭什么认为我和凯普勒相处得好？"
        npc "嗯，他至少似乎能容忍你。自从我不小心毁坏了一本书的装订后，他就不让我靠近他了。"
        npc "那个人因为这事把我送进医院九个星期！但你还是在他的好感列表上。"
        npc "也许你可以用蜂蜜来勒索或贿赂他来帮助我？"
        mc "……我看看能做些什么。"
        $ my_events.append("madyu")
        $ add_new_quest("madyu1")
        $ NPC = "???"
        python:
            if len(new_quests) > 0: #if we have new quests
                for i in new_quests:
                    active_quests.insert(0, i) #add to top of the quest list
                new_quests = [] #now reset the new quest list, since they all got added
        show screen completedtask("新任务！")

    elif "bite_day" in red_events and "sass" not in my_events:
        "学生们聚集在花园周围，窃窃私语。"
        $ NPC = "???"
        $ my_events.append("sass")
        npc "你听说塞恩咬了他的室友吗？我就知道我们不该接受他那种人来这里！"
        npc "哦，女孩，我懂。就像，仙子、吸血鬼和混血根本就不属于伊格尼亚。这里是唯一的人类主导地区！"
        npc "为什么我们必须被所有那些其他种族玷污，这太恶心了！"
        npc "我今晚肯定要在我的房间里挂大蒜。"
        show pboy at horzappear
        menu:
            "置身事外":
                hide pboy
                $ kindness -= 10
                mc "（说话只会让事情变得更糟，反正我的话也不会比塞恩的朋友们的话更有分量。）"
            "为塞恩辩护":
                hide pboy
                $ kindness += 10
                $ honesty += 15
                show side_p he at pic
                mc "为什么要用大蒜？我敢肯定你两腿之间那玩意儿的臭味就足以吓跑任何吸血鬼了。"
                mc "亲爱的，你听说过洗澡吗？"
                hide side_p
                npc "啊！我从没有……！"
        if "bunga_bego" in buff_events:
            if "beku" in quil_events:
                scene map_infected_f with dissolve
            else:
                scene map_infected with dissolve
        else:
            if "beku" in quil_events:
                scene map_frozen with dissolve
            else:
                scene map_all with dissolve
        jump world_map

    elif "jeles" not in my_events and "day3" in quil_events:
        play sound "sound/effects/bump.mp3" 
        $ NPC = "梅洛蒂"
        npc "那些该死的混蛋！" with vpunch
        $ NPC = "舒拉"
        npc "哇，冷静点，梅洛蒂！"
        $ NPC = "梅洛蒂"
        npc "冷静？冷静？！他们在约会，舒拉！"
        $ NPC = "舒拉"
        npc "我是说，女孩，你不也在做同样的事吗？说真的，你在生什么气？"
        $ NPC = "梅洛蒂"
        npc "我想让他们为我争风吃醋，而不是最后爱上对方。伊米尔和西尔贡怎么能这样对我？！"
        $ NPC = "舒拉"
        npc "真的吗，贱人？你只是在自己的游戏中被耍了。保留点面子，承认失败吧。"
        $ NPC = "梅洛蒂"
        npc "不可能！你知道我要做什么吗？我要制作一些\'告别勃起\'药水，然后倒进他们的饮料里。"
        npc "让我们看看当性爱不再可能时，爱情能持续多久！"
        $ my_events.append("jeles")
        $ add_new_quest("boner1")
        $ NPC = "???"
        python:
            if len(new_quests) > 0: #if we have new quests
                for i in new_quests:
                    active_quests.insert(0, i) #add to top of the quest list
                new_quests = [] #now reset the new quest list, since they all got added
        show screen completedtask("新任务！")
    elif "sucker3" in active_quests and calendar.day == 16 and calendar.month == '/05' and "cat_talk" not in red_events:
        play music "MUSIC/MusMus-BGM-098.mp3"
        show red point grin apa at center with dissolve:
            yoffset 330
        red "哦，嗨[nickname]。找猫有进展吗？"
        show red datar -apa
        if girl:
            show p_side f at pic
        else:
            show side_p f at pic
        mc "还没有。"
        if girl:
            hide p_side
        else:
            hide side_p
        red ngeles sigh "我这边也一样。那只小家伙会在哪里呢？希望它没事。"
        red lelah frusta "说真的，主人太粗心了。我无法想象如果我把爵士爪爪带到学校会发生什么。"
        show red sad -frusta
        show side_p w at pic
        mc "（啊，我猜那就是奎尔发给我照片上的猫。这名字很适合它。）"
        hide side_p
        if girl:
            show p_side se at pic
        else:
            show side_p se at pic
        mc "好吧，祝你好运！"
        if girl:
            hide p_side
        else:
            hide side_p
        $ red_events.append("cat_talk")
        red cowo blush "你也是！"
    elif calendar.day == 15 and calendar.month == '/05' and not "fia1" in fia_events:
        play music "MUSIC/MusMus-BGM-007.mp3"
        show croissant frown at center with dissolve:
            yoffset 500
        if girl:
            show p_side se at pic
        else:
            show side_p se at pic
        mc "菲亚！"
        if girl:
            hide p_side
        else:
            hide side_p
        fia pain shock "哦，嗨，唠叨鬼。又逃课？"
        show croissant laugh bunga
        show side_p he at pic
        mc "没有。"
        show side_p s
        mc "（天哪，看来这个世界的[povname]不是什么好榜样。我应该改变这一点。）"
        show side_p f
        mc "你呢？"
        hide side_p
        fia mmh frusta "草药学课。亨姆斯沃斯先生让我说出校园里20种植物的名字。"
        fia gross apa "你觉得这片叶子是夜芽还是喷泉花？"
        show side_p w at pic
        mc "（我完全不知道你在说什么。）"
        show side_p f
        mc "呃，可能是夜芽吧。"
        hide side_p
        fia annoyed sigh "哼，草药学从来就不是你的强项。"
        show croissant smile apa
        if girl:
            show p_side f at pic
        else:
            show side_p f at pic
        mc "是啊，不是。还有，菲亚……"
        if girl:
            hide p_side
        else:
            hide side_p
        if girl:
            show girl at horzappear
        else:
            show pboy at horzappear
        menu chore:
            "{s}{color=#be6f1c}你和合唱团是怎么回事？{/color}{/s}" if "choir" not in topics:
                
                jump chore
            "你和合唱团是怎么回事？" if "choir" in topics:
                hide girl
                hide pboy
                fia flinch sweat err shock "合唱团？"
                if girl:
                    show p_side s at pic
                else:
                    show side_p s at pic
                mc "有些女生说因为你的缘故她们不打算加入，你能解释一下吗？"
                if girl:
                    hide p_side
                else:
                    hide side_p
                fia kzl frusta "真的吗？该死。你只是抓破了一个女孩的脸一次，现在所有人都觉得你是恶人了。"
                if girl:
                    show p_side m at pic
                else:
                    show side_p m at pic
                mc "什么？！"
                if girl:
                    hide p_side
                else:
                    hide side_p
                fia def mmh sigh "上个学期，珍娜和她那群来自合唱团的蠢货们试图在女厕所里围堵我。"
                fia mock -sweat cling "我对她使用了菲尔拉符文。说\'我知道我没你漂亮。打赌所有人都想要一张像你这样的脸。\'"
                fia pity sigh "接下来你知道的，她的女伴们试图抓破她的脸，想要据为己有。"
                show croissant smile -sigh
                if girl:
                    show p_side f at pic
                else:
                    show side_p f at pic
                mc "哇，那真是……"
                if girl:
                    hide p_side
                else:
                    hide side_p
                if girl:
                    show girl at horzappear
                else:
                    show pboy at horzappear
                menu:
                    "太聪明了。":
                        hide girl
                        hide pboy
                        fia laugh bunga "不是吗？现在她几乎不敢直视我的眼睛。"
                    "太残忍了。":
                        hide girl
                        hide pboy
                        $ kindness += 10
                        fia mock shock "呵，真的吗[nickname]？我打赌如果你在场的话，你也会做同样的事。"
                        show croissant kerja -shock
                        if girl:
                            show p_side s at pic
                        else:
                            show side_p s at pic
                        mc "我会保护你，当然，但不是那种方式。"
                        if girl:
                            hide p_side
                        else:
                            hide side_p
                        fia pain "哦，拜托！上次有个自以为是的蜂后想找我麻烦，你可是让她被开除了。"
                        fia annoyed cling "别在我面前装圣人，唠叨鬼。我太了解你了。"
                        show croissant smile -cling
                        show side_p s at pic
                        mc "（但这不是\'我\'，你也不是菲亚。尽管你们如此相似。）"
                        mc "（我不认为我的妹妹会这么残忍，还是说这个世界的道德标准比我的世界低？）"
                        hide side_p
                fia ejek "总之，我知道我不应该过度滥用菲尔拉符文，但这真的太有趣了！"
                fia pity sigh "况且，妈妈经常在她的商业伙伴身上使用它。我只是在效仿而已。"
                show croissant smile -sigh
                if girl:
                    show p_side f at pic
                else:
                    show side_p f at pic
                mc "嗯。"
                if girl:
                    hide p_side
                else:
                    hide side_p
                show side_p he at pic
                mc "（我想知道在这个世界里我的父母是什么样的。从菲亚刚才告诉我的来看，有点可疑啊。）"
                hide side_p
            "{s}{color=#be6f1c}告诉我关于德拉克马尔巫师的事？{/color}{/s}" if "drakmar" not in topics:
                
                jump chore
            "告诉我关于德拉克马尔巫师的事？" if "drakmar" in topics:
                hide girl
                hide pboy
                fia frown apa "嗯？你是说你12岁时\'击败\'的那个巫师？"
                fia gross -apa "你为此杀了人的那个？"
                if girl:
                    show p_side s at pic
                else:
                    show side_p s at pic
                mc "啊？！"
                if girl:
                    hide p_side
                else:
                    hide side_p
                fia cringe sweat "哦，抱歉。那太刻薄了。\'交换\'是你喜欢的说法，对吧？"
                fia kzl apa "你为什么突然问我这个？是格尔拉夫人又问你关于蒂莫西的事了吗？"
                fia sad sigh -sweat "你知道她不能因为她儿子的死责怪你。你和那些孩子们都是被伏击的！"
                fia mad -sigh "而且还是在她自己的庄园里被伏击！如果要怪罪谁的话，那应该是她没有把房子保护好。"
                fia mmh sweat sigh "你和蒂莫西一样都是受害者。虽然……我猜她还是对你选择了阿什姆而感到不快。"
                if girl:
                    show p_side f at pic
                else:
                    show side_p f at pic
                mc "我选择了阿什姆？"
                if girl:
                    hide p_side
                else:
                    hide side_p
                fia sad -sigh "是啊，记得吗？你说你救了一些孩子，但最后巫师给了你一个选择，让你决定想要保留哪个朋友。"
                fia frown -sweat "你从5岁就认识蒂莫西了，但你却选择了刚认识的阿什姆，为什么？那时你们才认识一两周吧？"
                fia flinch gross sweat "从那以后格尔拉就恨你入骨，而阿什姆几乎对你着了魔。说实话，这有点恶心。"
                show croissant def frown -sweat shock
                if girl:
                    show p_side f at pic
                else:
                    show side_p f at pic
                mc "你说我击败了巫师，是怎么做到的？"
                if girl:
                    hide p_side
                else:
                    hide side_p
                show croissant flinch err sweat apa
                mc "菲亚看着你，就好像你长出了第二个脑袋。"
                fia mad sigh "我不知道。你在那里，不是我。"
                fia def cringe "你只是在回家后告诉我发生了什么。说你做了一些坏事。"
                fia sad frusta "如果你的记忆这么模糊，也许你应该去问问阿什姆。"
                show croissant frown -sweat sigh
                $ fia_events.append("suspicion")
            "没什么。":
                hide girl
                hide pboy
                "你想不出什么有趣的话题可以问她。也许你应该多探索一下校园。"
                fia mad sweat apa "嗯？你表现得很奇怪[nickname]。比平常更奇怪。"
                show croissant frown -sweat sigh


        fia frown -sigh "总之，我得去上课了。"
        if "fia1" not in fia_events:
            $ fia_events.append("fia1")
        if "suspicion" in fia_events:
            fia kzl sweat "..."
            fia sad sigh "你真的没嗑药吧，[nickname]？你最近表现得太奇怪了。"
            if girl:
                show p_side f at pic
            else:
                show side_p f at pic
            mc "我没事。"
            if girl:
                show p_side s
                mc "（演戏真不是我的强项。）"
            else:
                show side_p s
                mc "（演戏真不是我的强项。）"
            if girl:
                hide p_side
            else:
                hide side_p
            fia frown -sweat frusta "好吧，如果你这么说的话。"

        else:
            fia malu "晚餐见？"
            if girl:
                show p_side se at pic
            else:
                show side_p se at pic
            mc "好的，待会儿见。"
            if girl:
                hide p_side
            else:
                hide side_p
            show croissant laugh
    else:
        mc "这里没什么有趣的东西。"
    $ NPC = "???"
    if "bunga_bego" in buff_events:
        if "beku" in quil_events:
            scene map_infected_f with dissolve
        else:
            scene map_infected with dissolve
    else:
        if "beku" in quil_events:
            scene map_frozen with dissolve
        else:
            scene map_all with dissolve
    jump world_map


#PERPUS
screen perpus_map():
    tag menu
    imagebutton:
        idle "images/maps/perpus/ex.png"
        hover "images/maps/perpus/ex.png"
        xpos 714 ypos 913
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("world_map")]
        focus_mask None
        mouse "search"
    
    if "newbuk" in fia_events:
        imagebutton:
            idle "images/maps/perpus/stagi.png"
            hover "images/maps/perpus/stagi_hover.png"
            xpos 1451 ypos 624
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("stagi_1")]
            focus_mask None
            mouse "search"
    if calendar.weekday == "Mon" or calendar.weekday == "Wed":
        
        imagebutton:
            idle "images/maps/perpus/table.png"
            hover "images/maps/perpus/table_hover.png"
            xpos 904 ypos 528
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("reading_1")]
            focus_mask None
            mouse "search"
        imagebutton:
            idle "images/maps/perpus/nerd.png"
            hover "images/maps/perpus/nerd_hover.png"
            xpos 1056 ypos 541
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("reading_7")]
            focus_mask None
            mouse "search"
    else:
       
        imagebutton:
            idle "images/maps/perpus/walk.png"
            hover "images/maps/perpus/walk_hover.png"
            xpos 695 ypos 376
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("reading_3")]
            focus_mask None
            mouse "search"
        imagebutton:
            idle "images/maps/perpus/lady.png"
            hover "images/maps/perpus/lady_hover.png"
            xpos 1545 ypos 692
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("reading_9")]
            focus_mask None
            mouse "search"
    imagebutton:
        idle "images/maps/perpus/book.png"
        hover "images/maps/perpus/book.png"
        xpos 1195 ypos 322
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("map_fia_perpus")]
        focus_mask None
        mouse "search"
    imagebutton:
        idle "images/maps/perpus/peta.png"
        hover "images/maps/perpus/peta.png"
        xpos 700 ypos 535
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("reading_8")]
        focus_mask None
        mouse "search"
    imagebutton:
        idle "images/maps/perpus/bonding.png"
        hover "images/maps/perpus/bonding.png"
        xpos 1203 ypos 505
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("reading_5")]
        focus_mask None
        mouse "search"
    imagebutton:
        idle "images/maps/perpus/diari.png"
        hover "images/maps/perpus/diari.png"
        xpos 628 ypos 378
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("reading_6")]
        focus_mask None
        mouse "search"
    if "met_librarian" in my_events:
        imagebutton:
            idle "images/maps/perpus/case.png"
            hover "images/maps/perpus/case.png"
            xpos 741 ypos 234
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("glass_case")]
            focus_mask None
            mouse "search"
    else:
        imagebutton:
            idle "images/maps/perpus/case.png"
            hover "images/maps/perpus/case.png"
            xpos 741 ypos 234
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("stag_meet")]
            focus_mask None
            mouse "search"
    if calendar.day == 18 and calendar.month == '/05': 
        #Kamis
        imagebutton:
            idle "images/maps/perpus/tom_red.png"
            hover "images/maps/perpus/tom_red.png"
            xpos 757 ypos 354
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("red_tom_study")]
            focus_mask None
            mouse "search"
    elif calendar.day == 19 and calendar.month == '/05': 
        #JUMAT
        imagebutton:
            idle "images/maps/perpus/pia_red.png"
            hover "images/maps/perpus/pia_red.png"
            xpos 764 ypos 355
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("fia_red")]
            focus_mask None
            mouse "search"
screen fia_map():
    tag menu
    use cal
    imagebutton:
        idle "images/maps/perpus/ex2.png"
        hover "images/maps/perpus/ex2.png"
        xpos 0 ypos 1
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("map_perpus")]
        focus_mask None
        mouse "search"
    if "sucker3" in active_quests and "cat" not in fia_events and "day3" not in quil_events:
        imagebutton:
            idle "images/maps/perpus/pia.png"
            hover "images/maps/perpus/pia.png"
            xpos 1092 ypos 382
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("kucing_fia")]
            focus_mask None
            mouse "search"
    else:
        imagebutton:
            idle "images/maps/perpus/vamp.png"
            hover "images/maps/perpus/vamp.png"
            xpos 1266 ypos 439
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("reading_2")]
            focus_mask None
            mouse "search"
    imagebutton:
        idle "images/maps/perpus/4.png"
        hover "images/maps/perpus/4.png"
        xpos 339 ypos 273
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("reading_4")]
        focus_mask None
        mouse "search"
    imagebutton:
        idle "images/maps/perpus/fash.png"
        hover "images/maps/perpus/fash_hover.png"
        xpos 696 ypos 167
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("fashion")]
        focus_mask None
        mouse "search"
label stagi_1:
    hide screen perpus_map
    scene library with dissolve
    show teach happy at center with dissolve:
        yoffset 100
    stag apa "需要什么吗？"
    show teach -apa
    show pboy at horzappear
    menu stag_pik:
        "{s}你的头发。{/s}" if "stag1" not in active_quests or "her" in fia_events:
            
            jump stag_pik
        "Your hair" if "stag1" in active_quests and "her" not in fia_events:
            hide pboy
            $ fia_events.append("her")
            stag horns "哦？请告诉我，为什么你想要我这样一个私人纪念品？"
            stag evil "如果这又是你的一个\'实验\'，[povname]，我可不干。"
            show side_p he at pic
            mc "实验？不，这是为了研究。城里有人提出了请求。"
            hide side_p
            stag grin cling "哦，让我猜猜，是不是某个肮脏咖啡馆里喃喃自语的无聊家伙想要一根鸦鹿的头发？"
            show side_p a at pic
            mc "我猜你们见过面？"
            hide side_p
            stag datar -cling "现在已经见过多次了，准确地说是五次。没有一次是我自愿的。"
            stag hoo "不知怎的，他脑子里认定我的头发能帮助解决墨水短缺的问题。"
            stag datar "简直是一派胡言。"
            if "peri" in fia_events:
                show side_p f at pic
                mc "真的是胡言吗？我是说，你们这个种族不是由变化巫师创造的吗？"
                mc "也许她的一些魔法精华流淌在你们的血液中，可以像墨水一样作为导体使用。"
                hide side_p
                stag sigh "哼。看来你做过功课。没错，鸦鹿确实是由变化巫师的干预而诞生的。"
                stag hoo -sigh "所以认为我们的DNA中流淌着一些他们的魔法也不是不可想象的。"
                stag datar "但是符文墨水并非来自血液或骨骼，而是魔法本身的生命力。"
                if "io1" in my_events:
                    show side_p a at pic
                    mc "如果我告诉你，我们珍贵的符文墨水其实就是血液呢？是我们亲爱的神明自身的血液。"
                    hide side_p
                    stag evil cling "那我会说你疯了。"
                    stag horns -cling "...疯狂，但也许并不像我原先认为的那样毫无根据。"
                    
                else:
                    show side_p he at pic
                    mc "没错，但是，你不好奇吗？"
                    show side_p a
                    mc "你不想成为第一批发现符文墨水替代品的人吗？"
                    hide side_p
                    stag horns"..."
                "凯普勒长久地盯着你看，然后拔下一根头发交给你。"
                stag frown sigh"别浪费了。"
                show side_p se at pic
                mc "谢谢！"
                mc "我还能问你一个问题吗？关于你的角？"
                hide side_p
                stag datar "它们怎么了？"
                show side_p s at pic
                mc "书上说你们的角会因死亡而茁壮成长...你每只角上有五个节段。"
                mc "这是不是意味着你杀了五个人？"
                hide side_p
                stag horns cling "是的。"
                show side_p he at pic
                mc "哇，你就这样承认了？"
                hide side_p
                stag frown sigh "我已经活了几个世纪，经历过六场战争，你这个爱管闲事的小鬼。"
                stag -sigh "考虑到我经历过的所有流血事件，只有五次死亡已经是一种祝福了。"
                show side_p s at pic
                mc "哦，你这么一说..."
                hide side_p
                stag happy "如果你想用你新获得的道德指南针来评判某人，也许你应该把注意力转向梅莉。"
                stag grin cling "那个女孩隐藏她那布满荆棘的角是有原因的。她的角展开后能填满整个房间。"
                stag datar -cling "但从她现在的外表，你永远看不出来，对吧？"
                show side_p he at pic
                mc "等等，什么？真的吗？"
                hide side_p
                stag sigh "这就是他们说的。当然，这只是个传言，但你知道我有多喜欢传言。"
                $ InvItem(*item_hair).pickup(1)
            else:
                show side_p he at pic
                mc "好吧，但是假设有人要你的头发，你会卖多少钱？"
                mc "比如说一罐蜂蜜，或者一块金子？"
                hide side_p
                play sound "sound/effects/growl.mp3"
                stag evil cling "要是你敢拔我一根头发，[povname]，我就把你的脑袋咬下来。"
                show side_p s at pic
                mc "明白了。"
                hide side_p
                if "stag1" in active_quests:
                    $ active_quests.remove("stag1")
                show screen completedtask("任务失败")

                
        "{s}你的种子。{/s}" if "madyu1" not in active_quests or "niji" in fia_events:
            
            jump stag_pik
        "你的种子。" if "madyu1" in active_quests and "niji" not in fia_events:
            hide pboy
            stag horns "..."
            $ fia_events.append("niji")
            stag happy sigh "[povname]，我很清楚你对精灵的迷恋，学校里的每个人都知道你的恋父/恋母情结..."
            stag frown frusta "但是向一个教职员工提出这样的要求，即使我只是个小角色...你是不是完全失去理智了？"
            show side_p m at pic
            mc "伤寒！我是说伤寒种子！吸血鬼把我为作业种的那株给炸了！"
            hide side_p
            stag shock "哦，嗯，咳咳，是的。我们就忘掉刚才那段对话吧，好吗？给你。"
            $ InvItem(*item_beet).pickup(1)
            stag frown sigh "另外，请帮我安慰一下塞恩。我知道看到他母亲那个样子，对他来说一定很难受。"
            mc "你为什么不自己去安慰他呢？"
            stag frown frusta "我和那孩子不亲近。你们学生对我来说只是观察对象。"
            stag sigh "不是我想要真正去互动的对象。"
            stag -sigh "虽然...塞恩是特别的。我知道维尔科娃有多在乎这个孩子。"
            stag "他实际上就是她的儿子。是她为了减轻自己的内疚而承担的责任..."
            stag "然而我了解那个女人，就像了解自己的手背一样。她的行动胜过言语。这就是沃特克的方式。"
            stag "仅凭言语什么也做不成，但我确实知道言语比大多数人认为的更有力量。"
            stag sigh "去安慰你心爱的人吧，[povname]。我也会去安慰我的。"
            show side_p he at pic
            mc "哦，所以你承认她是你心爱的人了！"
            hide side_p
            stag grin cling "...无可奉告。"
        
        "{s}你的秘密。{/s}" if "rahasia2" not in my_events:
            
            jump stag_pik
        "你的秘密。" if "rahasia2" in my_events:
            hide pboy
            show side_p a at pic
            mc "我看到你了，你知道吗？和维尔科娃在一起。你们两个相爱。"
            hide side_p
            stag grin cling "我不知道你在说什么。"
            show side_p a at pic
            mc "是吗？"
            hide side_p
            stag horns -cling "没有。"
            show side_p he at pic
            mc "得了吧。你可以评论别人的感情生活，但却不愿意诚实面对自己的？"
            hide side_p
            stag happy sigh "惊喜吧，[povname]，我是个伪君子。就像其他所有人一样。"
            stag frown -sigh "你为什么对我的感情生活感兴趣？有更有趣的事情。"
            stag grin cling "我百分之百确定迪特里希爱上了赫德温，如果那个男人有胆量采取行动的话。"
            stag -cling "还有波比对威廉的痴迷，我就不多说了。我还在惊讶整个教职员工没有搞一场大型狂欢呢。"
            show side_p m at pic
            mc "现在你只是在转移话题。"
            hide side_p
            stag hoo "哦，别让我说起那些师生恋。"
            stag happy "杰西和利亚姆教授，哦呵呵呵，哦，他大概8个月后就有很多要解释的了。"
            show side_p he at pic
            mc "等等，你说什么？"
            hide side_p
            stag horns cling "不过，我确实好奇那个孩子会长什么样。如果是红头发，那肯定是利亚姆的，但如果是棕色的话..."
            stag grin -cling "...嗯，我相信亨姆斯沃斯会是个好父亲。虽然他的其他年轻情人可能会嫉妒。"
            
            if "fia1" in fia_events:
                show side_p m at pic
                mc "亨姆斯沃斯，是菲亚的草药学老师？等等，这个人还对谁下手了？！"    
            else:
                stag "这让我想起来，菲亚不是在亨姆斯沃斯先生的班上吗？"
                show side_p m at pic
                mc "等等，什么？等一下，这个变态还对谁下手了？！"
            hide side_p
            stag evil cling "你很想知道吧？"
            play sound "sound/effects/walk.mp3"
            hide teach with moveoutleft
            show side_p m at pic
            mc "凯普勒！回来！"
            stop sound
            hide side_p
            "不知怎的，凯普勒骗你转移了话题。他承认他的一些谣言只是谣言。"
            "但这并没有让你对菲亚的担心减少，该死的！"
        "没什么。":
            hide pboy
            if "mc_bangkit" in my_events and "cur_p" not in fia_events:
                $ fia_events.append("cur_p")
                stag evil cling "顺便说一句...我听说你是导致莱纳尔毁灭的罪魁祸首。"
                show side_p s at pic
                mc "哦，我...嗯..."
                hide side_p
                stag happy sigh "以及所有巫师的毁灭。"
                stag datar -sigh "谢谢你。我不知道现在没有纯血种，我们的学校会变成什么样，但至少有了这个，维尔科娃和我可以安心了。"
                if "rahasia" in my_events:
                    show side_p se at pic
                    mc "终于承认了，嗯？"
                    hide side_p
                    stag hoo "你杀死了那些不死之身的人，真是个奇迹。"
                    stag datar "相比之下，和维尔科娃公开关系并不是什么不可能的事。"
                else:
                    show side_p se at pic
                    mc "你们两个是一对？"
                    hide side_p
                    stag datar sigh "总是这么迟钝。真不知道你是怎么打败所有巫师的。"
            else:
                pass
            
    scene library with dissolve
    jump map_perpus
label red_tom_study:
    #KAMIS
    hide screen perpus_map
    if "help_study" in tom_events:
        scene library with dissolve
        show red chin sad at left with dissolve:
            yoffset 330
        show tom talk frown at right with dissolve:
            yoffset 190
        red kaget shock "啊，已经这么晚了吗？"
        show red frown -shock
        tom kzl blow "再这样下去我们就要迟到了。"
        tom frown apa "你来吗，[povname]？"
        show side_p f at pic
        mc "哦，啊，当然。"
        hide side_p
        "你们三个决定一起去上课。"
        jump combat_kls
    else:
        scene library with dissolve
        show red chin sad at left with dissolve:
            yoffset 330
        show tom scold frown at right with dissolve:
            yoffset 190
        tom apa "要制作洛基之霜，你需要什么？"
        red ow sweat apa "冰晶、优质墨水，还有呃……磷？"
        tom sigh blow "魔法粉末。我们已经讨论过这个了，蓝色代表霜冻，绿色代表巨人之火。"
        show tom frown -blow
        if "item_up" not in known_recipes:
            play sound "audio/success.mp3"
            $ known_recipes.append("item_up")
            "你学过如何制作洛基之霜。"
        red perih sigh "我知道，伙计，但你不能指望我记住每一个该死的配方，对吧？"
        show red sad
        tom hip nyesal frusta "你不需要死记硬背，你应该在回答中运用逻辑。"
        tom talk frown -frusta "磷是高度易燃的，它在一个完全相反效果的药剂中没有任何用处。"
        red lelah sigh "我为什么非得知道这些东西？等我们毕业后，我们可以直接查阅药剂的成分！"
        tom capek "是的，但你现在还没毕业，不是吗？这是你第二次重修这门课了。"
        tom kzl frusta "如果你再失败，你就不能和我们一起毕业了。"
        red sad -sigh "..."
        show pboy at horzappear
        menu:
            "你做得很棒，塞恩！":
                hide pboy
                $ mrh.points += 5
                show tom frown shock
                red wry shock "哦，嗨[povname]。谢谢，至少我在努力。"
                show tom -shock
                red perih frusta -sweat "我简直不敢相信我已经两次没通过魔药学了。我现在和菲亚在同一个班，太尴尬了。"
                show red frown
                show side_p se at pic
                mc "没什么好尴尬的。况且，至少你在班上认识人。"
                mc "也许你和菲亚可以一起学习。"
                hide side_p

            "别为难他了，阿什姆！":
                $ ibu.points -= 5
                if ibu.points <0:
                    $ ibu.points = 0
                hide pboy
                tom ha shock "[povname]。你在这里做什么？"
                show side_p f at pic
                mc "我也可以问你同样的问题。"
                hide side_p
                tom sigh blow "我在确保塞恩通过他的魔药学课程。"
                show tom frown
                red perih frusta "我简直不敢相信我已经两次没通过了。我现在和菲亚在同一个班。太尴尬了。"
                show red sad
                show side_p se at pic
                mc "没什么好尴尬的。况且，至少你在班上认识人。"
                mc "也许你和菲亚可以一起学习。"
                hide side_p
            "拍拍塞恩的头发":
                hide pboy
                $ mrh.points -= 10
                if mrh.points <0:
                    $ mrh.points = 0
                show tom kzl shock
                red point growl -sweat frusta "嘿！别碰我的头发。你以为你是谁——"
                red kaget shock "哦，[povname]。"
                show red sad
                show side_p se at pic
                mc "觉得你需要点鼓励。"
                hide side_p
                red so frusta "哼，我又不是5岁。别把我当小孩子对待！"
                show tom sad hip sweat
                "塞恩似乎不太喜欢你拍他的头。另一方面，阿什姆渴望地看着你。"
                show pboy at horzappear
                menu:
                    "拍拍他的头":
                        hide pboy
                        show tom giggle bloom blush
                        "你走到桌子对面，拍了拍阿什姆的头。"
                        show red chin wry shock
                        show side_p se at pic
                        mc "好阿什姆，帮助你的朋友。"
                        hide side_p
                        tom calm "嗯。"
                        $ ibu.points += 10
                        show side_p se at pic
                        mc "那么，你们在做什么？"
                        hide side_p
                        tom ha -blush frusta "确保塞恩通过他的魔药学课程。"
                        red perih frusta "我简直不敢相信我已经两次没通过了。菲亚和我现在在同一个班。太尴尬了。"
                        show tom frown -frusta
                        show side_p se at pic
                        mc "没什么好尴尬的。况且，至少你在班上认识人。"
                        mc "也许你和菲亚可以一起学习。"
                        hide side_p

                    "表扬他。":
                        hide pboy
                        $ ibu.points += 5
                        show side_p se at pic
                        mc "你在帮他学习？你真贴心。"
                        hide side_p
                        tom sigh blow "更正一下，我{i}正在尝试{/i}帮他学习。"
                        tom kzl scold sweat frusta "我开始觉得这是徒劳的。"
                        show tom -sweat ha
                        red perih sweat frusta "别放弃我，伙计。如果你放弃了，我不知道还能找谁帮忙！"
                        tom sigh blow "我知道。这就是为什么我在这里尽我所能。"
                        tom kzl -blow "然而，你真的在考验我的耐心。"
                        show side_p f at pic
                        mc "也许你需要的不是一个老师，而是一个学习伙伴。你有没有问过菲亚和你一起学习？"
                        hide side_p



                    "你在做什么？":
                        hide pboy
                        show side_p f at pic
                        mc "那么，你们在做什么？"
                        hide side_p
                        tom ha frusta "确保塞恩通过他的魔药学课程。"
                        show tom frown blow
                        red perih frusta "我简直不敢相信我已经两次没通过了。菲亚和我现在在同一个班。太尴尬了。"
                        show side_p se at pic
                        mc "没什么好尴尬的。况且，至少你在班上认识人。"
                        mc "也许你和菲亚可以一起学习。"
                        hide side_p
        red sad sigh"我想我可以那样做。我只是讨厌学习，伙计。我宁愿去痛揍一些巫师，也不愿整天被关在图书馆里。"
        tom capek frusta "哈……我本不想依赖奖励，但是……"
        show tom kzl -frusta
        show red kaget shock
        "阿什姆拿出了一瓶红色药水。"
        red hister bunga "那个味道，是……混合血？！"
        show red point wry
        tom sigh blow "我为一个任务制作的。说来话长。"
        tom ejek cling "如果你能在今天下午之前记住五种药剂的配方，我就让你拿走这个，好吗？"
        red cowo cling "这才像话嘛！好，就这么定了！"
        scene library with dissolve
        "你离开了阿什姆和塞恩，让他们继续学习。"
        if "blood1" in active_quests:
            $ active_quests.remove("blood1")
            "由于阿什姆已经给了塞恩一瓶血药，你告诉塞恩你丢失了本应给他的那瓶药水。"
            "起初他很难过，但这确实激励了他更加努力学习。"
            show screen completedtask("任务失败")

        $ tom_events.append("help_study")
        jump map_perpus
label fia_red: #JUMAT W1
    hide screen perpus_map
    if "fia_red" in fia_events:
        "菲亚和塞恩还在学习，你应该让他们安静学习。"
        jump map_perpus
    else:
        scene library with dissolve
        show croissant flinch mmh apa at right with dissolve:
            yoffset 500
        show red point amused at left with dissolve:
            yoffset 330
        fia "你确定要我这么做吗？"
        show croissant sad sweat -apa
        red grin cling "这主意太棒了。快做吧！"
        fia pity "好吧..."
        fia def -sweat mock cling "塞恩·维拉什科夫从头到尾背诵中级魔药学，直到我说停为止！"
        play sound "sound/effects/shield.mp3"
        show library behind croissant with dissolve:
            subpixel True
            zoom 1.2 xpos 0.5 ypos 0.5 xanchor 0.5 yanchor 0.5 
            alignaround (.45, .45)
            linear 20 yalign 0.45 xalign 0.45 clockwise circles 1.2
            #repeat
        show croissant frown -cling
        "当你再次听到菲亚的强制命令时，房间开始旋转。不过这次对你的影响较小，可能是因为她的命令特别针对塞恩。"
        show library behind croissant with dissolve:
            subpixel True
            truecenter zoom 1.0
            xalign 0.5 yalign 0.5
        show red chin so shock
        "瞥了塞恩一眼，你看到他低着头，鼻子深深埋进书里。"
        "你试图叫他，但他完全不理会你，全神贯注地沉浸其中。"
        show side_p f at pic
        mc "你对他用了菲尔拉？"
        hide side_p
        fia wry sigh "是他要求的。别担心，我只会让他这样三个小时，然后我会让他停下来。"
        show side_p f at pic
        mc "他真的完全不会违抗你的命令吗？"
        hide side_p
        fia flinch sweat jijik frusta "是的。虽然我不愿承认，但奎尔建议在我喉咙后面刻上符文的方法确实有效。"
        fia sad -frusta "现在效果强多了，但我承认这确实给我的身体带来了很大的负担。"
        fia pity def apa "我正在寻找缓解的方法。[povname]，你能帮我吗？我需要帮忙拿一些在后面的书。"
        $ fia_events.append("fia_red")
        show side_p f at pic
        mc "（这可能是了解菲亚的好机会，也可以问问她关于我在这个世界学到的东西。）"
        show side_p w
        mc "（或者我可以留在这里捉弄一下塞恩。）"
        hide side_p
        show pboy at horzappear
        menu:
            "留在塞恩身边":
                hide pboy
                $ fia_events.append("buk_clean")
                show side_p f at pic
                mc "我想我要留在塞恩这里。确保他不是在装的。"
                hide side_p
                fia hmph sigh "我是说，我很确定我的符文是完美的，但好吧。那我去问凯普勒帮忙。"
                hide croissant with dissolve
                "菲亚离开去拿她的书了。"
                show red at center with move
                show side_p se at pic
                mc "塞恩，你在听我说话吗？喂喂？"
                hide side_p
                "你捏他的鼻子，弄乱他的头发，但这个吸血鬼完全没有反应。"
                "你感到顽皮起来，拿起最近的羽毛笔开始在他脸上画画。"
                scene library with dissolve
                show croissant frown at center with dissolve:
                    yoffset 500
                fia "我拿到我想要的所有书了，所以——"
                fia blush hister shock "哈哈哈哈哈！"
                if girl:
                    galleryunlock red_book
                    scene red_book with dissolve
                else:
                    galleryunlock red_bookm
                    scene red_bookm with dissolve
                "当你画完时，塞恩的脸上已经布满了涂鸦。菲亚忍不住大笑起来，还轻微地打了个鼻息。"
                "你以前觉得这些鼻息很烦人，但现在你觉得它们很可爱。"
                fia "哦，科尔啊，哦，哈哈哈。而且他还在那么认真地读书！"
                scene library with dissolve
                show teach horns cling at center with vpunch:
                    yoffset 100
                stag "嘘！"
                hide teach with dissolve
                show croissant flinch cringe sweat at center with dissolve:
                    yoffset 500
                fia "哦，对不起，凯普勒先生。"
                fia hister blush sigh "哼。你太可怕了，[povname]。"
                show side_p se at pic
                mc "多夸夸我。还有，你有什么要补充的吗？"
                hide side_p
                fia def ejek cling "挪开点。"
                if girl:
                    scene red_book with dissolve
                else:
                    scene red_bookm with dissolve
                "当你和菲亚画画时，你注意到塞恩开始朝你们这边瞟眼。"
                scene library with dissolve
                show croissant flinch cringe shock at right with dissolve:
                    yoffset 500
                show red point growl frusta sweat at left with dissolve:
                    yoffset 330
                red "什么，为什么我的脸...该死，你们两个！"
                fia pity sweat -apa "哎呀...？"
                show side_p se at pic
                mc "快跑！"
                hide side_p
                play sound "sound/effects/tile.mp3"
                hide croissant with moveoutright
                show red at center with move
                red ew frusta "给我回来！"
                scene library with dissolve
                "你们最后在图书馆里玩起了捉迷藏。"
                stop sound
                play sound "sound/effects/growl.mp3"
                show teach horns frusta at center with vpunch:
                    yoffset 100
                "当然，游戏没持续多久，凯普勒就来惩罚你们三个了。"
                "你们被迫整理书籍直到深夜。"
                scene bed_alter with dissolve
                $ morning = False
                $ evening = False
                $ afternoon = False
                $ night = True
                play sound "sound/effects/cloth.mp3"
                stop music
                "一完成，你就立即倒在床上睡着了。"
                scene bg_black with w20
                if "iv_dream2" not in my_events:
                    jump iv_second
                else:
                    jump morning




            "帮助菲亚":
                hide pboy
                show side_p se at pic
                mc "当然，你需要什么？"
                hide side_p
                fia laugh blush -apa"在这边。"
                $ fia_events.append("buk_cari")
                scene map_fia with dissolve
                show croissant hmph at center with dissolve:
                    yoffset 500
                fia happy "看到那边上面的那本书了吗？那本厚厚的绿色的，上面有个音符的。你能帮我拿一下吗？"
                if girl:
                    show buku with dissolve
                    galleryunlock buku
                else:
                    show buku_m with dissolve
                    galleryunlock buku_m
                $ renpy.pause()
                "你拿到了菲亚想要的书。之后，她开始递给你一堆书，一本一本地堆在你的手臂上。"
                "在这个过程中，你觉得这是个问她关于这个世界的问题的好机会。"
                show side_p se at pic
                mc "顺便说一下，菲亚..."
                hide side_p
                hide buku_m with dissolve
                hide buku with dissolve
                show croissant smile
                show pboy at horzappear
                menu buku_cari:
                    "{s}关于重写符文{/s}" if "rewrite" not in topics:
                        
                        jump buku_cari
                    "关于重写符文" if "rewrite" in topics:
                        hide pboy
                        
                        show side_p f at pic
                        mc "菲亚，你对我的重写符文有什么看法？"
                        hide side_p
                        fia flinch cringe sweat"老实说？它让我毛骨悚然。你基本上拥有重写一个人整个存在的力量。"
                        fia mmh sigh "我知道你说过它和菲拉的强制力没什么不同，但我不同意。"
                        fia sad -sigh "菲拉只是让目标陷入催眠状态，但他们仍保留自己的记忆和个性。"
                        fia gross frusta "而你，另一方面，创造了一个让你随心所欲的符文。"
                        fia sad -frusta "可以将他们塑造成你需要的任何样子。"
                        fia mock cling -sweat "如果我不了解情况的话，我会说你是在试图建立一个邪教。"
                        fia kzl frusta "哦，我还是不赞同你对亨利和丽佐所做的事！"
                        fia jijik sigh "我知道你在亨利的女朋友死后用了重写符文，让他不至于自杀。"
                        fia sad sweat frusta "但你有必要用我们的表妹来替代她吗？"
                        fia cringe -frusta "可怜的丽佐真的以为自己被爱着，还嫁给了那个家伙。"
                        fia sad "我现在还不知道见到他们时该如何反应。"
                        show croissant -sweat def frown
                        show side_p s at pic
                        mc "（好吧，这确实需要消化一下。我在想[povname]是否有日记之类的东西，这样我就能更多地了解这个重写符文。）"
                        if not "diari1" in active_quests and "diari1" not in completed_quests:
                            $ add_new_quest("diari1")
                            python:
                                if len(new_quests) > 0: #if we have new quests
                                    for i in new_quests:
                                        active_quests.insert(0, i) #add to top of the quest list
                                    new_quests = [] #now reset the new quest list, since they all got added
                            show screen completedtask("新任务！")
                        show side_p f
                        mc "我明白了。哦，还有..."
                        hide side_p
                        show pboy at horzappear
                        jump buku_cari
                    "{s}关于英克威尔家族的纷争{/s}" if "inkwell" not in topics:
                        
                        jump buku_cari
                    "关于英克威尔家族的纷争" if "inkwell" in topics:
                        hide pboy
                        
                        fia hmph apa "哦，是关于佩纳试图夺取奎尔作为乌鸦继承人的权利吗？"
                        fia annoyed -apa "是啊，我也对此感到厌烦了。那些爱管闲事的贵族们只谈论这个。"
                        fia gross sigh sweat "不过我倒是宁愿佩纳成为继承人。奎尔那个懦夫太软弱了，不适合这个位置。"
                        fia malu -sweat -sigh "我知道妈妈也希望佩纳成为继承人，因为他给你送了求爱信。"
                        show croissant shock
                        show side_p f at pic
                        mc "等等，他真的送了？"
                        hide side_p
                        fia hmph -shock "嗯哼。我知道你没注意到，因为你每天都会收到十几封这样的信，但妈妈还是保留了他的信。"
                        fia kzl frusta "这是你的人生。但老实说，我宁愿死也不想和英克威尔家族有任何关系。我绝对不要和奎尔有任何法律上的家庭关系，绝对不行！"
                        show croissant frown -frusta
                        show side_p f at pic
                        mc "我明白了。哦，还有..."
                        hide side_p
                        show pboy at horzappear
                        jump buku_cari
                    "{s}关于血月{/s}" if "bloodmoon" not in topics:
                        
                        jump buku_cari
                    "关于血月" if "bloodmoon" in topics:
                        hide pboy
                        
                        fia cringe apa "你不可能还在痴迷于那个吧。我以为你已经得到答案了？"
                        show side_p f at pic
                        mc "你这是什么意思？"
                        hide side_p
                        fia kzl sigh "嗯，你告诉我你在研究血月及其所有影响。"
                        fia mmh -sigh "说你需要它来获得额外学分之类的。"
                        fia frown "但是血月过去后，你突然就对此失去了兴趣。"
                        fia annoyed sweat "我只是以为你难得失败了一次，所以开始嗑药什么的。"
                        show croissant frown shock
                        show side_p f at pic
                        mc "等等，所以我是在血月之后才开始喝酒的？"
                        hide side_p
                        fia err frusta "这就是你的治疗方式吗，唠叨鬼？你问治疗师，希望他们能给你所有答案？"
                        show side_p s at pic
                        mc "拜托，就迁就我一下吧。"
                        hide side_p
                        fia cringe sigh "好吧。"
                        fia sad -sweat -sigh "是的，你是在血月之后开始喝酒的。巧合的是，那也是在你分手不久之后，所以我以为你是因为分手而难过。"
                        fia frown "但是，当我问你这件事时，你只是耸耸肩。而且从你现在和阿什姆的关系来看，似乎并没有对你造成太大影响。"
                        fia "但你来告诉我吧。"
                        show side_p f at pic
                        mc "我明白了。哦，还有..."
                        hide side_p
                        show pboy at horzappear
                        jump buku_cari
                    "{s}关于水母季{/s}" if "jelly" not in topics:
                        
                        jump buku_cari
                    "关于水母季" if "jelly" in topics:
                        hide pboy
                        
                        fia laugh blush bunga "哦对了，水母季下周就开始了，对吧？我等不及了！"
                        fia smile "我已经准备好我的礼服了。"
                        show side_p f at pic
                        mc "你的礼服？"
                        hide side_p
                        fia pain -blush apa "你知道的，就是为了镇上的水母节。"
                        fia laugh -apa "我当然会再次和奎尔跳舞。"
                        fia ejek cling "是时候报仇了！"
                        $ fia_events.append("dance_ask")
                        fia pity apa "你呢？要和谁一起去？"
                        show pboy at horzappear
                        menu:
                            "阿什姆。":
                                hide pboy
                                fia flinch cringe sweat shock "诶？真的吗？等等，你们要复合了？"
                                fia gross frusta "因为你要知道，我不赞同。"
                                fia def kzl -sweat "那混蛋对你太过执着了。这不健康。"

                            "塞恩。":
                                hide pboy
                                fia hmph sigh "那个吸血鬼？嗯，我觉得妈妈不会赞同，但那是你的葬礼。"
                            "莱尔。":
                                hide pboy
                                fia flinch sad sweat shock "那个新来的？你确定吗？"
                                fia cringe frusta "我觉得这不是个好主意。"
                                show side_p s at pic
                                mc "你也害怕他？"
                                hide side_p
                                fia sad sweat sigh "只是为了安全起见，这很合理。"
                                fia kzl -sigh "况且，我担心的不只是你，[povname]。"
                                fia def cringe "以我对你的了解，你会吃掉他的心还笑着谈论这件事。"
                            "没人。":
                                hide pboy
                                fia wry sigh "我就知道。"
                                fia laugh "不过，我会为你留一支舞。"
                                fia kzl frusta "这次可别再玩什么花哨的舞步了，我还没原谅你上次把我的头发弄乱！"
                        show croissant frown sigh -sweat
                        show croissant -sigh
                        show side_p f at pic
                        mc "我明白了。哦，还有..."
                        hide side_p
                        show pboy at horzappear
                        jump buku_cari
     
                    "你为什么讨厌奎尔？":
                        hide pboy
                        
                        show croissant flinch sweat mad shock
                        "菲亚难以置信地盯着你。"
                        fia sad frusta "讨厌这个词太轻了..."
                        fia def mock -sweat cling "...但还不够强烈！我鄙视奎尔！不，等等，我完全彻底地厌恶他！"
                        show croissant kerja -cling
                        show side_p he at pic
                        mc "你有必要这么夸张吗？为什么这么敌视他？"
                        hide side_p
                        fia kzl frusta "是他一直挑起争端。以我对他的了解，他就是喜欢看我难堪。"
                        fia mmh sigh "如果他还像以前那个体弱多病的孩子一样可爱害羞，那还不算太糟。"
                        fia mad frusta "但现在他长大了，变得光鲜亮丽又傲慢自大。和我们如此鄙视的那些贵族没什么两样。"
                        show croissant hmph -frusta
                        show side_p w at pic
                        mc "有道理。"
                        
                        if "dance_ask" in fia_events:
                            show side_p he
                            mc "不过，如果你讨厌他，为什么还要和他跳舞？"
                            hide side_p
                            fia mock cling "当然是为了踩他的脚啊。那不是舞会，是战场！"
                            show croissant kerja -cling
                            show side_p f at pic
                            mc "我明白了。哦，还有..."
                            hide side_p
                        else:
                            show side_p f 
                            mc "顺便说一句..."
                            hide side_p
                        show pboy at horzappear
                        jump buku_cari



                    "没什么。":
                        hide pboy
                        show croissant smile 
                        "在你帮菲亚整理完书籍后，菲亚继续给塞恩补课，而你决定再次探索校园。"
                        hide croissant with dissolve
                        jump map_perpus


label map_fia_perpus:
    scene map_fia
    call screen fia_map
label map_perpus:
    hide screen peta_all
    #play music "MUSIC/MusMus-BGM-078.mp3"
    
    
    if "day3" in quil_events and "newbuk" not in fia_events and "mey_kill" not in my_events:
        scene library with fade
        "你看到凯普勒正在指导一些学生把一堆书搬进图书馆。"
        show teach horns cling at center with dissolve:
            yoffset 100
        stag "到这里来，别碰玻璃！"
        show teach frown -cling
        show side_p f at pic
        mc "发生什么事了？"
        hide side_p
        stag happy "卡斯特里的尤特卡夫人刚刚捐赠了她图书馆的藏书。她说对于一个猎巫学院来说，关于巫师的书籍数量少得惊人。"
        play sound "sound/effects/growl.mp3"
        stag evil frusta "她还好心地替换了被一个学生涂污的地图。"
        stag "一旦我抓到那个学生，我发誓我要剖开他的肚子，吃掉他的心。"
        show side_p s at pic
        mc "不是...字面意思吧，对吧？"
        hide side_p
        stag cling "这个答案还有待商榷。"
        show teach frown shock
        show side_p he at pic
        mc "好吧，你这个疯子。为什么不让我来处理这个家伙呢？可能只是某个嫉妒吸血鬼的孩子而已。"
        hide side_p
        stag evil frusta "行吧。但如果你下周之前找不到他，我就要亲自动手了！"
        $ fia_events.append("newbuk")
        $ add_new_quest("map1")
        python:
            if len(new_quests) > 0: #if we have new quests
                for i in new_quests:
                    active_quests.insert(0, i) #add to top of the quest list
                new_quests = [] #now reset the new quest list, since they all got added
        show screen completedtask("新任务！")
        stag grin cling "我已经很久没吃过学生了。"
        play sound "sound/effects/walk.mp3"
        hide teach with dissolve
        show side_p he at pic
        mc "你说什么？能解释一下那——当然，他已经走了。"
        hide side_p
        
        scene map_lab
        call screen perpus_map
    elif calendar.day == 24 and calendar.month == '/05':
        jump trio_hang
    else:
        scene map_lab
        call screen perpus_map
label stag_meet:
    hide screen perpus_map
    scene scroll with dissolve
    play sound "sound/effects/punch.mp3"
    show teach evil at center with vpunch:
        yoffset 100
    teach "别碰玻璃！现在！"
    if girl:
        show p_side m at pic
    else:
        show side_p m at pic
    mc "哇-哇哦！"
    if girl:
        hide p_side
    else:
        hide side_p
    stag horns shock "哦，是你啊..."
    if girl:
        show girl at horzappear
    else:
        show pboy at horzappear
    menu:
        "我认识你吗？":
            hide girl
            hide pboy
            teach evil -shock "啊，看来又是那种日子，我明白了。杀死太多脑细胞了，是吗？"
            teach frown sigh "我不会感到惊讶，如果你连自己的名字都不知道。"
        "你是什么东西？！":
            hide girl
            hide pboy
            $ curiosity += 5
            teach evil sigh "又咬下了比你能咀嚼的更多的东西，是吗？你看到精灵都认不出来吗？"
            show side_p he at pic
            mc "（精灵？在我看来他更像是个恶魔。）"
            hide side_p
    teach frown -sigh "好吧，既然你现在无法回忆起任何事情。那么这是第11次了..."
    stag happy "...我是凯普勒先生。我是这里的图书管理员。"
    stag datar "在我的领地里，请不要聊天、吃东西、喝饮料，最重要的是..."
    play sound "sound/effects/growl.mp3"
    stag evil "...不要触摸玻璃展示柜！"
    stag "哦，还有，严禁将任何书籍带回宿舍或教室。这是校园政策。"
    stag happy "如果你买不起任何教科书，请咨询管理人员。"
    stag datar "还有什么问题吗？"
    if girl:
        show p_side f at pic
    else:
        show side_p f at pic
    mc "你为什么说第11次？"
    if girl:
        hide p_side
    else:
        hide side_p
    stag frown sigh "因为自从我第一次遇见你以来，由于你那破坏性的习惯，我不得不重新介绍自己11次了。"
    stag frusta "说真的！你为什么不和阿什姆和解呢？那时候你要好相处得多。"
    if girl:
        show p_side s at pic
    else:
        show side_p s at pic
    mc "等等，什么？"
    if girl:
        hide p_side
    else:
        hide side_p
    stag happy -frusta "你的酗酒和滥用药物。当阿什姆和你在一起的时候，你从不这样做。你们曾是完美的权力情侣。"
    stag datar cling "完美的身高差，两人都赏心悦目，黑发和金发的老套搭配！我确信灵魂伴侣就在眼前，但是没有！"
    stag frown sigh "真是浪费。"
    if girl:
        show p_side f at pic
    else:
        show side_p f at pic
    mc "呃，你总是这么关心学生的事务吗？"
    if girl:
        hide p_side
    else:
        hide side_p
    stag grin cling "当然！当你被青少年的焦虑和戏剧性包围时，谁还需要肥皂剧和言情小说呢？"
    stag happy spark "你听说了吗，梅洛蒂同时在和伊米尔和西尔贡约会？相当丑闻。我支持伊米尔。虽然西尔贡和伊米尔在一起会是——"

    "这个男人开始长篇大论地谈论起学生们的爱情生活。"

    if girl:
        show p_side f at pic
    else:
        show side_p f at pic
    mc "（啊。我觉得我应该趁现在撤退。）"
    if girl:
        hide p_side
    else:
        hide side_p
    scene map_lab with dissolve
    "你慢慢地从那个男人身边走开，继续你的路。"
    $ my_events.append("met_librarian")
    jump map_perpus
label fashion:
    hide screen fia_map
    hide screen perpus_map
    scene map_fia with dissolve
    if "mc_bangkit" in my_events:
        npc "莱纳尔发生的事真是可惜。我简直不敢相信我们隔壁就住着一个纯血巫师。"
        npc "我想知道教会是否知道这件事。"
    elif "beku" in quil_events:
        npc "是哪个混蛋把湖面冻住的，好像这里还不够冷似的？！"
    elif "io4" in my_events:
        if "ice_rune" in my_events:
            npc "我简直不敢相信我们的水下有这么多人，学校还隐藏着什么？！"
        else:
            npc "我不敢相信校长不在了。学校现在会怎么样？"
    elif "vamp_visit" in red_events:
        npc "天哪，近距离看到邪血族我差点吓得屁滚尿流！"
        npc "真不敢相信塞恩还叫那个野兽\'妈妈\'。给他点赞，他一定很爱她。"
    elif "bite_day" in red_events and "io2" not in my_events:
        npc "我听说塞恩咬了他的室友。你觉得塞恩会被开除，还是更糟？"
        show side_p s at pic
        mc "什么是\'更糟\'？"
        hide side_p
        npc "砍头、活活烧死，真的有很多创意的事情可能发生。"
        npc "沃特克和伊格尼亚的和平条约条款很清楚。除非双方达成共识，否则不得吸血。"
        npc "明显违反这些条款可能导致战争，如果沃特克人不采取适当的纪律措施的话。"
    elif "ajax" in fia_events:
        npc "听说阿什姆和阿贾克斯之间发生的事了吗。那场打斗闹大了，不是吗？但是该死，菲亚真是个火药桶，不是吗？"
        npc "难怪她没有朋友。"
    elif "bunga_bego" in buff_events:
        npc "有美丽巫师的花在周围，学校就不安全了。我告诉你，我们都会死的！"
    elif "day3" in quil_events:
        npc "沃特克有一个博物馆，里面有科尔的睡衣和一小瓶她的血液。"
        npc "他们说她的血液对吸血鬼来说是不可饮用的，因为它的稠度很奇怪。几乎像墨水一样。"
    else:
        npc "科尔，我讨厌这些制服。不是说科尔只穿一件睡袍就打败了100个巫师吗？为什么我们不能穿那个呢？"
    jump map_fia_perpus
label reading_1:
    hide screen perpus_map
    scene library with dissolve
    if "mc_bangkit" in my_events:
        npc "他们可能会把莱纳尔发生的事写进历史书。"
        npc "我听说那是一场巫师之战的结果，但是撕裂整个岛屿？"
        npc "你觉得是纯血种干的吗？"
    elif "beku" in quil_events:
        npc "我听说是奎尔冻住了湖面。了解他的人都知道，他可能又在耍我们了。"
        npc "不过我很惊讶没有人能解冻它。"
    elif "io4" in my_events:
        if "ice_rune" in my_events:
            npc "我的姐姐从湖里浮了上来...她两年前掉进湖里。"
            npc "真的是意外掉进去的，不是自杀...至少她是这么说的。"
            show side_p se at pic
            mc "也许你应该多关注她一下。"
            hide side_p
            npc "我应该这么做，对吧？"
        else:
            npc "我为校长的家人感到难过。我知道他没有妻子或孩子，但他的兄弟姐妹真的很关心他。"
    elif "bite_day" in red_events and "io2" not in my_events:
        npc "我已经读过伊格尼亚和沃特克的和平条约条款。"
        npc "如果塞恩真的违反了那些条款，吸食了一个不愿意的伊格尼亚人的血液，那么我们可能会开战。"
        npc "坦白说，如果我们因此开战，那对双方来说都相当愚蠢。因为一个年轻吸血鬼的错误而开战。"
    elif "ajax" in fia_events:
        npc "我简直不敢相信阿什姆有这样的伪装，我还曾经暗恋过他呢！"
    elif "bunga_bego" in buff_events:
        npc "我正在寻找杀死那些花的方法。这里一定有什么东西可以帮忙。"
    elif "day3" in quil_events and "festies" not in my_events:
        npc "水母节快到了。"
        npc "你知道吗，它以前被称为野兽与美人节？"
        npc "它曾经是一种求偶仪式，女孩们会戴玫瑰花，被称为\'美人\'，男孩们会戴皮项圈，被称为\'野兽\'。"
        npc "当一个女孩拉男孩的项圈，而男孩摘下她的花时，这意味着他们配对成功，将会结婚。"
    else:
        npc "这可能听起来很书呆子气，但我来这所学校就是因为它的图书馆。"
        npc "不仅如此，这里还很平等。大多数学院只允许贵族或富人入学。"
    scene map_lab with dissolve
    jump map_perpus
label reading_2:
    hide screen perpus_map
    hide screen fia_map
    if girl:
        show p_side f at pic
    else:
        show side_p f at pic
    mc "血液药剂和所有不要变成吸血鬼的理由。嗯，有趣。"
    if girl:
        hide p_side
    else:
        hide side_p

    if "item_plasma" not in known_recipes:
        play sound "audio/success.mp3"
        $ known_recipes.append("item_plasma")
        $ known_recipes.append("item_pop")
        mc "你学会了如何制作血棒糖和混合血液。"
    jump map_fia_perpus
label reading_3:
    hide screen perpus_map
    scene library with dissolve
    if "mc_bangkit" in my_events:
        npc "天哪，我简直不敢相信莱纳尔走了。看来我们再也吃不到好火腿了。"
    elif "beku" in quil_events:
        npc "我有点喜欢新的冰冻湖泊，在上面滑冰很不错，而且它似乎不会融化。"
    elif "io4" in my_events:
        if "ice_rune" in my_events:
            npc "我担心那些来自湖边的学生。他们看起来不是最稳定的一群人。"
        else:
            npc "我希望他们能尽快找到一个合适的人选来替代威廉先生。"
    elif "bite_day" in red_events and "io2" not in my_events:
        npc "你知道吗，有些人觉得吸血很性感？也许皮尔斯就是这样的。"
        npc "如果皮尔斯其实是同性恋，他和塞恩相爱，陷入一段秘密恋情，我也不会感到惊讶。"
        npc "但事情变糟了，皮尔斯最终玷污了塞恩的名声。或者哦，也许塞恩有另一个情人。"
        npc "如果皮尔斯不能得到塞恩，那么谁也别想得到。"
        show side_p f at pic
        mc "你看的同人小说太多了，伙计。"
        hide side_p
        npc "同人小说？我不知道那是什么。但如果你指的是言情小说，那么是的。"
        npc "我想我应该冷静下来。"
    elif "ajax" in fia_events:
        npc "嘿，伙计，你有多余的鳞片吗？"
        show side_p f at pic
        mc "抱歉，没有。"
        hide side_p
        npc "哦，好吧。顺便问一下，为什么在阿贾克斯事件发生时你保持沉默？"
        npc "难道不应该是你保护你妹妹，而不是反过来吗？"
        
    elif "bunga_bego" in buff_events:
        npc "我简直不敢相信死亡地带的花已经蔓延到这里了！我们该怎么办？！"
    else:
        npc "我不敢相信赫舍尔先生要求我们读这玩意儿120页。"
    scene map_lab with dissolve
    jump map_perpus
label reading_4:
    hide screen perpus_map
    hide screen fia_map
    if "day3" in quil_events:
        "这里有一本新书。《稀有与美丽指南》。"
        show pboy at horzappear
        menu buty:
            "阅读关于塞壬的内容。":
                hide pboy
                if "sirbuk" not in fia_events:
                    $ curiosity += 5
                    $ fia_events.append("sirbuk")
                npc "塞壬，在卡斯特里也被称为哈比，是美丽的人形鸟类混血生物，喜欢以鱼和浆果为食。"
                npc "它们常见于野外或极其富有的人的镀金笼子中——"
                npc "这些生物很少与人类接触，它们的羽毛和万花筒般的眼睛常常被人觊觎。"
                npc "由于它们的眼睛，它们经常被误认为是巫师。随之而来的屠杀常常导致宝贵的身体部位被浪费。"
                npc "95%%的塞壬是雌性，雄性通常在成年后会变成班西。他们的声音不再仅仅是迷人的。相反，他们带来的是死亡。"
                npc "班西的尖叫是致命的，通常能杀死即使是最强壮的狼人，因为狼人的听觉非常敏感。"
                npc "因此，在吸血鬼领地交易的塞壬大多是雄性，因为它们被视为宝贵的武器。"
                npc "不变成班西的雄性塞壬通常被认为是受到祝福的，它们的治疗能力无与伦比，超过任何巫师或其他具有类似治愈特性的种族。"
                show pboy at horzappear
                jump buty

            "阅读关于人鱼的内容。":
                hide pboy
                if "sirbuk" not in fia_events:
                    $ curiosity += 5
                    $ fia_events.append("sirbuk")
                
                npc "关于人鱼，我们知道的很少。它们是一个隐居的族群，似乎既不需要也不渴望与任何陆地居民交往。"
                npc "大多数人鱼曾经生活在现在被称为伊格尼亚巫师猎人学院的地方。以前，那里是一个普通的湖泊，叫做伊欧之泪。"
                npc "同名的伊欧是一位纯血的海洋巫师，也被航海者崇拜，因为她的祝福能保证他们的安全。"
                npc "据说人鱼曾经保护她的领域，直到伊欧带着丰饶巫师回到陆地。关于这方面的记录很少，因为这种崇拜可以追溯到1450年代。"
                npc "除此之外，关于人鱼的了解很少，因为它们很难捕捉或与之交谈。"
                show pboy at horzappear
                jump buty

            "阅读关于黑暗精灵的内容。":
                hide pboy
                if "peri" not in fia_events:
                    $ curiosity += 5
                    $ fia_events.append("peri")
                npc "黑暗精灵是由变化巫师干预精灵生物学而产生的变异体。"
                npc "一个普遍的理论认为，很久以前所有的黑暗精灵都受变化巫师的控制，以某种集体意识的方式运作。"
                npc "这种情况一直持续到巫师（据推测）死亡。"
                npc "与光明精灵不同，黑暗精灵可以吸食血液，他们的角会在造成死亡而不是欢乐后生长。"
                npc "黑暗精灵有鹿角或树枝状的角。而光明精灵通常有淡白色的角，头发上长着花冠。"
                npc "黑暗精灵也因其对暴力的渴望和易怒脾气而臭名昭著。"
                npc "乌鹿家族是最著名的精灵家族，同时展现了魅力和暴力这两个标志性特征。"
                npc "奇怪的是，光明和黑暗精灵似乎都喜欢干涉他人的爱情生活，并且普遍痴迷于浪漫。"
                show pboy at horzappear
                jump buty
            "合上书本":
                hide pboy
                jump map_fia_perpus           
    else:
        "你试图阅读它，但全都是用奇怪的符号写成的。"
    jump map_fia_perpus
label reading_8:
    hide screen perpus_map
    if "day3" not in quil_events:
        galleryunlock dood
        show dood with dissolve
        pause 1.0
        if girl:
            show p_side f at pic
        else:
            show side_p f at pic
        mc "一张带有涂鸦的地图。也许是国家派系？"
        mc "看起来有人对吸血鬼君主制不太满意。嗯。"
        if girl:
            hide p_side
        else:
            hide side_p
        if "monarchy" not in topics:
            $ topics.append("monarchy")
            play sound "audio/success.mp3"
            "学到了新话题：{color=#FF1500}吸血鬼王国。{/color}"
        hide dood with dissolve
    else:
        "一堆奇怪的卷轴，内容从吸血鬼历史到精灵纯洁度不等。"
        show pboy at horzappear
        menu:
            "阅读关于吸血鬼的内容":
                hide pboy
                "吸血鬼最早于1040年被发现，与达拉神庙的发现同时发生。"
                "达拉是一位纯血巫师，她的领域似乎是血液、腐朽和阴影。"
                "像变化巫师塞斯一样，只要血液流过他们的血管，达拉就能命令她的臣民。"
                "人们推测达拉和塞斯一起创造了吸血鬼，这又是一次为了缓解他们的无聊而进行的探索。"
                "像塞斯的大多数造物一样，吸血鬼暴力、易怒且贪婪。"
                "他们也很难自然受孕，不过似乎有仪式可以帮助解决这个问题。"
                "通过收集一定量的血液和骨头，然后使用达拉自己特别发明的符文..."
                "...吸血鬼可以创造自己的后代。然而，这些后代的纯度和力量会较弱，寿命也会大大缩短。"
                "你可以通过吸血鬼进食的频率和眼睛的颜色来判断他们的强弱。"
                "眼睛越红，他们就越强大。他们对进食的需求也会更加突出。"
                "普通的吸血鬼在闲暇时通常有棕色的眼睛，只有在进食后才会出现红色的眼睛。"
                "然而，更强大的吸血鬼总是有带金色斑点的猩红色眼睛，并且需要每2小时左右进食一次。"

                
            "阅读关于精灵的内容":
                hide pboy
                "虽然不是最有野心的社会，但精灵似乎对血统纯洁度有着奇怪的执着。"
                "你可以通过精灵眼睛的强度来判断他们的血统。"
                "所有精灵，即使只有四分之一的精灵血统，出生时都会有紫色的眼睛。"
                "除了眼睛，你还可以通过精灵的魔法能力来判断他们的纯度。"
                "只有纯血精灵才能产生精灵尘，并且经常炫耀高大、白色或银色的树枝状角。"
            "不看了。":
                hide pboy
                pass
    jump map_perpus
label reading_9:
    hide screen perpus_map
    if "mc_bangkit" in my_events:
        npc "我认为莱纳尔的毁灭是伊格尼亚最后的致命一击。"
        npc "这样的失误？我无法想象教会这次会保持沉默。"
    elif "beku" in quil_events:
        npc "有人竟然能冻结整个湖面，真是让人惊讶。赫德温简直气疯了。"
        npc "她已经连续几天试图用她的蓝色火焰解冻湖面。不过，看到她有了目标还是很不错的。"
    elif "io4" in my_events:
        if "ice_rune" in my_events:
            npc "[povname]，对吧？我是伊欧法术下的学生之一。"
            show side_p se at pic
            mc "哦。你现在怎么样？"
            hide side_p
            npc "我还好，正在重新适应现实。说实话，拥有我想要的一切的感觉很不错。"
            npc "但在我的眼角，幻象的某些部分会扭曲，提醒我这一切都只是一场梦。"
            npc "我想我现在准备好去追求真实的东西了。"
        else:
            npc "我在想他们是否会为威廉大师举行葬礼。"
    elif "vamp_visit" in red_events:
        "可以看到两个学生正在为某事争论。"
        npc "你说我不能勾引一个邪血？这是什么意思？！"
        npc "兄弟！那些东西会在眨眼间把你整个吞掉的。"
        npc "听着，我很兴奋，他们可以变形。"
        npc "别在这事上跟我开玩笑，让它来上我吧！"
    elif "bite_day" in red_events :
        npc "凯普勒似乎对塞恩是幕后黑手这件事感到非常沮丧。"
        npc "凯普勒和维尔科娃女士。"
    elif "ajax" in fia_events:
        npc "我就知道阿什姆太完美了！这样的男人只存在于小说中。"
    elif "bunga_bego" in buff_events:
        npc "为了一些花朵就如此恐慌，我说把它们冻住！"
    elif "sucker3" in active_quests and "cat" not in fia_events:
        npc "我想我刚才看到一只猫在追菲亚。她看起来对此并不太高兴。"
    else:
        npc "如果你需要什么，就去问凯普勒先生。如果你能找到他的话。"
        npc "尽管他有些古怪，但一旦你了解他，就会发现他是个不错的图书管理员。"
        npc "你也可以给他一些蜂蜜。仙子们喜欢蜂蜜。"
    jump map_perpus
label reading_7:
    hide screen perpus_map
    scene library with dissolve
    if "mc_bangkit" in my_events:
        npc "在他们关闭学校之前，我要尽可能多地偷些书。"
        npc "考虑到莱纳尔的整个风波，我怀疑教会会让这所学校继续下去。"
    elif "beku" in quil_events:
        npc "现在真的很冷，因为有个笨蛋把湖面冻住了。我希望他们在地狱中腐烂。"
    elif "io4" in my_events:
        if "ice_rune" in my_events:
            npc "我恨你。"
            show side_p f at pic
            mc "什么？"
            hide side_p
            npc "我是那些被你从艾欧的梦中唤醒的人之一。你杀了艾欧，我恨你。"
        else:
            npc "我给威廉校长的家里送了花。我知道他独自生活，但我觉得这么做是对的。"
    elif "vamp_visit" in red_events:
        npc "我羡慕血骑士的制服，他们看起来都很时尚。"
    elif "bite_day" in red_events:
        npc "吸血鬼本不该生活在人类之中，所以我对塞恩最终爆发并不感到惊讶。"
        npc "不过，他是个不错的家伙，所以我想我们放松了警惕。"
    elif "bunga_bego" in buff_events:
        npc "我对那些花并不太惊讶，这就是为什么我更喜欢待在室内。"
        npc "那些花不会到达这里吧，对吧？"
    else:
        npc "你读过《稀有与美丽指南》吗？"
        npc "这是一本关于海妖、美人鱼和仙子的书。听说我们的湖里以前有美人鱼。"
        npc "不知道它们现在在哪里？"
    scene map_lab with dissolve
    jump map_perpus
label reading_6:
    hide screen perpus_map
    show diary with dissolve
    if "day3" not in quil_events:
        $ NPC = "科尔的日记"
        npc "一张被玻璃封存的科尔夫人日记的羊皮纸。日记上写着..."
        npc "那些可怜的灵魂，在我的兄弟姐妹们手中痛苦地尖叫。"
        npc "为什么我们要如此折磨他们？难道我们已经如此脱离人性，以至于要以同类为食吗？"
        npc "我们曾经都是人类。直到那该死的疾病折磨我们所有人。现在他们称我们为巫师。"
        npc "但我从未选择这条路。那个选择被从我手中夺走了。"
        npc "只有绝望到极点的人才会自愿选择这条路。"
        npc "我为他们祈祷，那些可怜的人类。愿我的仁慈为他们指明道路。愿这成为和平的开端。"
    else:
        "科尔夫人日记的集合。"
        $ NPC = "科尔的日记"
        show pboy at horzappear
        menu:
            "Read parchment 2":
                hide pboy
                if "parch2" not in fia_events:
                    $ curiosity += 5
                    $ fia_events.append("parch2")
                npc "我今天又看到塞斯在拿人类做实验。哈迪斯让我别管。"
                npc "他说\'这是他作为神的权利\'。什么神？什么样的神会如此折磨他们的信徒？"
                npc "信仰的考验？多么不公平。如果我有朝一日成为\'神\'，我一定会确保祝福和保护我的子民。"
                npc "而不是把他们当成玩偶一样玩弄！"
                npc "如果有谁配得上成为神，那就是..."
                "名字被划掉了，但你仍然可以读到剩下的部分。"
                show side_p he at pic
                mc "奇怪。"
                hide side_p
                npc "...是一个优秀的年轻人。被爱着，美丽，如同天使。"
                npc "我祈祷他将永远被人类所爱和保护。就像他保护他们一样。"
                npc "...多么可爱的男孩。愿你永远不要改变。"
                
            "Read parchment 6":
                hide pboy
                if "parch6" not in fia_events:
                    $ curiosity += 5
                    $ fia_events.append("parch6")
                $ NPC = "科尔的日记"
                npc "血，血，到处都是无尽的血流。"
                npc "巫师和人类的血都有。其他人告诉我要选择一边。但我怎么能？"
                npc "我也曾经是人类。那时我的脸颊还没有被焦油般的污渍玷污。"
                npc "那是在这种疾病还没有在我身上显现的时候。塞斯一直称它为进化的一步，但我不敢苟同。"
                npc "这是一种疾病，一种邪恶而腐烂的疾病！"
                npc "然而...也许...如果我找到一种安全分享这种affliction的方法...？"
                "羊皮纸上的整行文字都被划掉了，变得难以辨认。"
                npc "这是一种让人类和巫师都能发现魔法的乐趣和烦恼的方式。"
                npc "一定有办法让我们化解分歧，一定有！"
                npc "如果没有...好吧，我现在不敢想那种情况。"
                npc "我所爱的人类，还是我自己的同类。我必须选择吗？要是真有\'神\'就好了。"
                npc "我能请求他们重写我的命运吗？"
            "阅读羊皮纸7？" if curiosity < 50: 
                hide pboy   
                show side_p f at pic
                mc "嗯，字迹不同而且太凌乱了。我想我读不了。"
                mc "除非我花上几个小时坐下来试图破译它。"
                mc "我没那么好奇。"
                hide side_p
            "阅读破损的羊皮纸":
                hide pboy
                mc "这似乎不是科尔夫人日记的一部分..."
                $ NPC = "羊皮纸"
                if "parchtat" not in fia_events:
                    $ curiosity += 5
                    $ fia_events.append("parchtat")
                npc "在所有巫师中，没有一个比丰饶巫师更美丽或更善良。"
                npc "一个金发金眼的小男孩。无论他去哪里，鲜花都会盛开。"
                npc "有他在，即使在干旱或灾难中，也能保证丰收。"
                npc "但是女人们讨厌他，年轻的男孩们也是。"
                npc "因为她们的丈夫和父亲会对这个男孩着迷，想要与他同床——甚至不惜使用武力。"
                npc "到目前为止还没有人敢对他动手，但我能从他们的眼中看出来。那种扭曲的欲望。"
                npc "他的母亲，海洋巫师，只能保护她的小男孩这么长时间。"
                npc "要是她对水手和其他人的爱能转移到她唯一的儿子身上就好了。"
                npc "我想知道一旦那些男人最终屈服于这个小男孩的美貌会发生什么？"
                npc "花朵还会在地上盛开，还是会在他们的尸体上绽放？"
                npc "无论如何，我决定自己和这个男孩玩玩。不会像我对科尔那样极端。"
                npc "但是...会是一些长远来看对我有帮助的事。我一直认为这个世界上最致命的武器就是一张漂亮的脸蛋。"
                npc "许多因被抛弃的恋人而引发的战争就是这一论断的证明。"
                npc "或者说，一张漂亮的嘴配上一条银舌头。他仍然可以说话，编织任何他喜欢的故事，但一尝就能识破他的谎言。"
                npc "当然，伊欧很生气。然而，当我提到有办法赢得科尔的青睐时，她的怒火立刻减弱了。"
                npc "这个愚蠢的陷入爱河的女人，我几乎为她称之为\'儿子\'的男孩感到可怜。孩子应该是母亲的首要考虑，而不是情人。"
                npc "但我有什么资格评判呢？"
                
            "阅读羊皮纸7？" if curiosity >= 50:
                hide pboy
                show side_p f at pic
                mc "嗯，字迹不同而且非常凌乱。"
                mc "这需要一些时间，但我想我能破译它。"
                mc "我很好奇这是关于什么的。"
                hide side_p
                $ NPC = "奇怪的日记"
                npc "烧伤、放血、冰冻、肢体肢解。这些对科尔都没有任何效果。"
                npc "第二天她愤怒地撕下了我的手臂，幸运的是我一直打算重新长出一只。"
                npc "当然，我也在自己身上测试了同样程度的伤害。没有造成永久性的改变。"
                npc "不过我注意到我的血管里并不流淌着血液。" 
                npc "梅扎和伊欧也是如此。新来的孩子有血，但是呈金色，带有小红宝石般的斑点。"
                npc "完全不像科尔那漆黑如深渊的血液。一旦被割伤，她的伤口似乎会像喷泉一样无休止地流血。"
                npc "只有通过伊欧和她的男孩施加强力的治疗符文才能停止。"
                npc "科尔是个迷人的生物。容易受伤，但不可能被杀死，因为即使斩首对她也没有影响。" 
                npc "一个真正的不朽者，不像我们其他人。"
                npc "我计划尽可能多地用她的血液做实验，以研究这种异常现象。"
                npc "与此同时，我的实验帮助我找出了我们这类人唯一可能的死因。斩首。"
                npc "一刀干净利落。我不知道为什么我们的后代没有继承同样的韧性？"
                npc "火对他们的同类太有效了。他们的血液是否以某种方式被污染了？类似于我创造的邪血者？"
                npc "他们的后代越是繁衍就越弱？"
                npc "真可惜。"
                npc "但至少我现在知道不再需要血缘后代了。"
                npc "学徒就足够了。"
                npc "伊欧的是迄今为止最吸引人的。一个漂亮的男孩，虽然对我的品味来说太女性化了。"
                npc "不过他的眼睛很迷人。我真想把它们挖出来做成项链。那琥珀色的色调真是可爱。"
                npc "他似乎是我们血脉中最年轻的。我们纯血的最后一个。"
                npc "真有趣，一种病毒竟能造成这一切。他们给它起的名字也如此不祥。"
                npc "大清算。真是胡说八道。"
                npc "那些身体适应了这种疾病的个体似乎发生了变异，以惊人的速度进化了他们的生物学特性。"
                npc "把我们变成了\'巫师\'。"
                npc "科尔似乎是零号病人，因为我没有发现在她之前有其他\'巫师\'的案例。"
                npc "然而她仍然相信她的affliction是由某种神圣的力量造成的。对她罪孽的惩罚。"
                npc "根本就不存在什么恶魔、天使或牙仙。"
                npc "啊等等，最后一部分可能是不对的，确实有些精灵部落用牙齿作为货币。"
                npc "不过……没有天使、恶魔或上帝。我们就是神，至少在人类眼中是这样。"
                npc "啊，我可怜的发展不足的同族。我不知道你们还能让我感兴趣多久？"




            "Read parchment 0":
                hide pboy
                $ NPC = "科尔的日记"
                npc "一张被玻璃封存的科尔夫人日记的羊皮纸。日记上写着..."
                npc "那些可怜的灵魂，在我的兄弟姐妹们手中痛苦地尖叫。"
                npc "为什么我们要如此折磨他们？难道我们已经如此脱离人性，以至于要以同类为食吗？"
                npc "我们曾经都是人类。直到那该死的疾病折磨我们所有人。现在他们称我们为巫师。"
                npc "但我从未选择这条路。那个选择被从我手中夺走了。"
                npc "只有绝望到极点的人才会自愿选择这条路。"
                npc "我为他们祈祷，那些可怜的人类。愿我的仁慈为他们指明道路。愿这成为和平的开端。"
    hide diary with dissolve
    $ NPC = "???"
    jump map_perpus
label reading_5:
    hide screen perpus_map
    scene library with dissolve
    $ NPC = "书"
    npc "灵魂绑定，以及为什么你在说\'我愿意\'之前应该三思！"
    npc "只有真正坚定的人才应该形成灵魂绑定的结合。"
    npc "一旦绑定，除非双方都死亡，否则这种结合无法被打破。"
    npc "那些害怕在伴侣去世后感到孤独的人应该寻求更临时和无根基的结合，比如婚姻。"
    npc "灵魂绑定的具体形式因种族而异。在巫师中，双方将合并成一个实体。一方将成为宿主，而另一方成为他们的影子。"
    npc "宿主将能够在需要时召唤该影子，使他们的伴侣暂时获得实体形态。"
    if "soulmates" not in topics:
        $ topics.append("soulmates")
        play sound "audio/success.mp3"
        "学会了新话题：{color=#FF1500}灵魂伴侣。{/color}"
    npc "关于吸血鬼、狼人和精灵的灵魂绑定，请分别参阅第15、18和20页。"
    if girl:
        show girl at horzappear
    else:
        show pboy at horzappear
    menu scrolling:
        "继续阅读第15页":
            hide girl
            hide pboy
            if "p15" not in fia_events:
                $ curiosity += 5
                $ fia_events.append("p15")
            npc "吸血鬼是唯一在皮肤上有明显灵魂印记的种族，使他们能通过视觉识别他们的灵魂伴侣。"
            npc "一旦他们到了适当的年龄，他们的身体上就会形成一个描绘他们灵魂伴侣的印记。他们命中注定的伴侣也会有类似的印记，不论他们是什么种族。"
            npc "如果他们的伴侣比该吸血鬼更早成年，那么他们的印记会先形成。许多人类因吸血鬼的敌对本性而害怕这个印记。"
            npc "绑定的吸血鬼只能吸食他们心爱之人的血液。所有其他形式的养分都会被吸血鬼的身体排斥。"
            npc "这就是为什么吸血鬼通常如此拼命地试图拒绝他们灵魂伴侣不可抗拒的吸引力。许多人宁愿保持他们的不朽。"
            npc "如果他们的伴侣早逝，那么该吸血鬼当然也会随之死去。独特的是，吸血鬼不会与自己的同类形成灵魂绑定。"
            npc "他们自身的血液很少，血管中流动的大多是灰烬。"
            play sound "audio/success.mp3"
            if girl:
                show girl at horzappear
            else:
                show pboy at horzappear
            jump scrolling
        "继续阅读第18页":
            hide girl
            hide pboy
            if "p18" not in fia_events:
                $ curiosity += 5
                $ fia_events.append("p18")
            npc "狼人通过气味建立联系。他们能本能地从几英里外闻到他们灵魂伴侣的气味。"
            npc "然后他们会咬他们伴侣的脖子，留下一个永久的咬痕，表示他们的忠诚。"
            npc "与吸血鬼相反，狼人总是会寻找他们的灵魂伴侣，并且天性想要孩子。"
            npc "他们有发情期和需要填补的某些角色，类似于真正的狼群。"
            if girl:
                show girl at horzappear
            else:
                show pboy at horzappear
            jump scrolling
        "继续阅读第20页":
            hide girl
            hide pboy
            if "p20" not in fia_events:
                $ curiosity += 5
                $ fia_events.append("p20")
            npc "精灵天性就是享乐主义者，这意味着他们会与任何他们喜欢的人或物交配。"
            npc "他们可以与多个伴侣建立联系，尽管如果他们的伴侣是单配偶制的本性，如狼人或吸血鬼，这可能会引起问题。"
            npc "因此，他们经常与人类建立联系，因为人类没有特定的本性，而是会适应他们的伴侣。"
            npc "精灵是浪漫和顽皮的，经常参与其他人的爱情生活，为了自己的娱乐而扮演丘比特的角色。"
            if girl:
                show girl at horzappear
            else:
                show pboy at horzappear
            jump scrolling

        "合上书本":
            hide pboy
            $ NPC = "???"        
    scene map_lab with dissolve
    jump map_perpus
label glass_case:
    hide screen perpus_map
    scene scroll with dissolve
    if girl:
        show p_side f at pic
    else:
        show side_p f at pic
    mc "是啊，我宁愿不再碰那个了。"
    if girl:
        hide p_side
    else:
        hide side_p
    scene map_lab with dissolve
    jump map_perpus
label kucing_fia:
    hide screen perpus_map
    hide screen fia_map
    scene map_fia with dissolve
    $ fia_events.append("cat")
    show croissant flinch cringe sweat at center with dissolve:
        yoffset 500
    fia "阿嚏！阿嚏！哦，离我远点！退后，你这毛茸茸的白色东西！"
    if girl:
        show p_side se at pic
    else:
        show side_p se at pic
    mc "菲亚！"
    if girl:
        hide p_side
    else:
        hide side_p
    show croissant sad shock
    play sound "sound/effects/meow.mp3"
    "你试图把猫抱在怀里，但它跑掉了。"
    fia jijik frusta "阿嚏！阿嚏！谁他妈的带了只猫来这里？他们不明白\'禁止宠物\'是什么意思吗？！"
    if girl:
        show p_side f at pic
    else:
        show side_p f at pic
    mc "给你。"
    if girl:
        hide p_side
    else:
        hide side_p
    show croissant frown -frusta
    "你从口袋里拿出一张纸巾递给菲亚。当菲亚还活着的时候，你总是随身带着纸巾。你猜这个[povname]也是一样。"
    fia gross sigh "谢谢。"
    show croissant frown -sweat -sigh
    if girl:
        show p_side f at pic
    else:
        show side_p f at pic
    mc "一个一年级新生没收到通知。我正试图在老师发现之前抓住它。"
    if girl:
        hide p_side
    else:
        hide side_p
    fia apa "你，为什么？"
    if girl:
        show p_side s at pic
    else:
        show side_p s at pic
    mc "和男生们打赌，很蠢。"
    if girl:
        hide p_side
    else:
        hide side_p
    fia def annoyed cling "嗯，奎尔也参与了这个赌局吗？"
    if girl:
        show girl at horzappear
    else:
        show pboy at horzappear
    menu:
        "是的。":
            hide girl
            hide pboy
            if honesty > 10:
                $ honesty -= 10
            fia kerja shock "那我就帮忙。"
            if girl:
                show p_side f at pic
            else:
                show side_p f at pic
            mc "什么，为什么？"
            if girl:
                hide p_side
            else:
                hide side_p
            fia pain sigh "这样他就会输，当然了。"
            fia laugh -sigh "艾德娜女士刚教了我们一些家常药剂和魔药。其中就有猫粮。"
            fia smile "我还有一些剩余的材料，但我需要鱼来制作。"
            if girl:
                show p_side f at pic
            else:
                show side_p f at pic
            mc "如果我给你弄些鱼，你能为我做吗？"
            if girl:
                hide p_side
            else:
                hide side_p
            fia cringe frusta "好——等等！算了。我马上要上课了，所以做不了。"
            fia laugh -frusta "但是给你这个。你应该能自己做出来。"
            show croissant smile
            $ InvItem(*item_ham).pickup(1)
            $ InvItem(*item_eel).pickup(1)
            "菲亚递给你一个看起来装着鳗鱼和火腿的罐子。"
            if "item_catfood" in known_recipes:
                fia happy "而且你已经知道配方了。"
            else:
                fia happy "如果你忘了怎么做，你需要一些火腿、鱼和鳗鱼。把它们一起磨碎，然后和水混合成糊状。"
                $ known_recipes.append("item_catfood")
            fia laugh "我相信艾德娜女士不会介意你短时间使用她教室里的坩埚的。"
            show croissant smile
            if girl:
                show p_side f at pic
            else:
                show side_p f at pic
            mc "对了，她的教室在哪里来着？"
            if girl:
                hide p_side
            else:
                hide side_p
            fia gross "还能在哪里？西翼，二楼，阿嚏！"
            fia cringe sweat frusta "阿嚏！呃...我最好去洗把脸。回头见，[nickname]。"
            scene map_fia with dissolve

        "没有。":
            hide girl
            hide pboy
            $ honesty += 5
            fia frown sigh "好吧，那祝你好运。"
            if girl:
                show p_side s at pic
            else:
                show side_p s at pic
            mc "就这样？不帮忙或者别的什么吗？"
            if girl:
                hide p_side
            else:
                hide side_p
            fia err apa "嗯，你可以做些猫粮，我猜？"
            if girl:
                show p_side f at pic
            else:
                show side_p f at pic
            mc "猫粮？"
            if girl:
                hide p_side
            else:
                hide side_p
            if "item_catfood" in known_recipes:
                fia frown -apa "是啊，你不是已经知道配方了吗？"
            else:
                fia frown -apa "你知道的，《烹饪卷轴101》里的那个配方？"
            fia laugh -apa "我相信艾德娜女士不会介意你短时间使用她教室里的坩埚的。"
            if girl:
                show p_side f at pic
            else:
                show side_p f at pic
            mc "对了，她的教室在哪里来着？"
            if girl:
                hide p_side
            else:
                hide side_p
            fia gross sweat "还能在哪里？西翼，二楼，阿嚏！"
            fia cringe frusta "阿嚏！呃，我最好去洗把脸。阿嚏！"
            scene map_fia with dissolve
    jump map_fia_perpus

#MAP_STORES
screen store_map():
    tag menu
    if calendar.weekday == "Sat" or calendar.weekday == "Sun":
        imagebutton:
            idle "images/maps/store/jmbtn.png"
            hover "images/maps/store/jmbtn.png"
            xpos 1683 ypos 733
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("music", "MUSIC/MusMus-BGM-142.mp3"),Play ("test_one", "walk.mp3"), Jump("town_map")]
            focus_mask None
            mouse "search"
    else:
        imagebutton:
            idle "images/maps/store/jmbtn.png"
            hover "images/maps/store/jmbtn.png"
            xpos 1683 ypos 733
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("jmbtn")]
            focus_mask None
            mouse "search"
    imagebutton:
        idle "images/maps/store/tokbuk.png"
        hover "images/maps/store/tokbuk.png"
        xpos 1107 ypos 363
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("alat_tulis")]
        focus_mask None
        mouse "search"
    imagebutton:
        idle "images/maps/store/bakery.png"
        hover "images/maps/store/bakery.png"
        xpos 837 ypos 276
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("grocery")]
        focus_mask None
        mouse "search"
    imagebutton:
        idle "images/maps/store/baker.png"
        hover "images/maps/store/baker_hover.png"
        xpos 802 ypos 363
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("penjaga")]
        focus_mask None
        mouse "search"
    imagebutton:
        idle "images/maps/store/ngobrol.png"
        hover "images/maps/store/ngobrol_hover.png"
        xpos 1545 ypos 385
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("girl_a")]
        focus_mask None
        mouse "search"
    imagebutton:
        idle "images/maps/store/nat.png"
        hover "images/maps/store/nat_hover.png"
        xpos 317 ypos 547
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("boy_c")]
        focus_mask None
        mouse "search"
    imagebutton:
        idle "images/maps/store/b.png"
        hover "images/maps/store/b_hover.png"
        xpos 508 ypos 431
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("girl_b")]
        focus_mask None
        mouse "search"
    imagebutton:
        idle "images/maps/store/tang.png"
        hover "images/maps/store/tang.png"
        xpos 649 ypos 501
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("map_well")]
        focus_mask True
        mouse "search"
    imagebutton:
        idle "images/maps/store/ex.png"
        hover "images/maps/store/ex.png"
        xpos 1531 ypos 109
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("map_lower")]
        focus_mask None
        mouse "search"
    if calendar.weekday == "Mon":
        imagebutton:
            idle "images/maps/store/d.png"
            hover "images/maps/store/d_hover.png"
            xpos 921 ypos 452
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("walk_d")]
            focus_mask None
            mouse "search"
    else:
        imagebutton:
            idle "images/maps/store/e.png"
            hover "images/maps/store/e_hover.png"
            xpos 557 ypos 763
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("walk_e")]
            focus_mask None
            mouse "search"


label map_store:
    hide screen peta_all
    hide screen store_map
    scene map_shops
    #play music "MUSIC/MusMus-BGM-056.mp3"
    if check_inv_for(recipe_items) and "item_catfood" not in known_recipes:
        $ known_recipes.extend(["item_bread","item_coco","item_caramel"])
        $ known_recipes.append("item_catfood")
    if check_inv_for(anc_items):
        if "item_starter" not in known_recipes:
            $ known_recipes.append("item_starter") 
        else:
            pass
        if "item_ink" not in known_recipes:
            $ known_recipes.append("item_ink") #notsure wanna keep here but sure
        else:
            pass
        
    call screen store_map
label penjaga:
    hide screen store_map
    if "mc_bangkit" in my_events:
        npc "莱纳尔都不在了...玛格丽特，派克，他们都是好人。我希望我们能保持联系。"
    elif "beku" in quil_events:
        npc "湖面结冰了，无法从莱纳尔运送任何货物，我不得不步行过去。差点扭伤脚踝。"
    elif "io4" in my_events:
        if "ice_rune" in my_events:
            npc "从湖边来的新人有点古怪，但我和太太尽量让他们感到受欢迎。"
        else:
            npc "可怜的威廉校长，愿他安息。"
    elif "vamp_visit" in red_events:
        npc "今天大蒜卖得像热蛋糕一样快。"
        npc "那些孩子们不知道大蒜对邪血族没有效果吗？"
        npc "当然，它们能赶走一些吸血鬼，但没人想靠近一个浑身大蒜味的孩子！太难闻了！"
    elif "bite_day" in red_events:
        npc "如果我在店里卖血，孩子们会更安心吗？"
        npc "我一直在和太太商量。塞恩是个好孩子，他有时会帮忙捕捉老鼠。"
        npc "从不要求任何回报。我们至少应该用血来支付他。"
        npc "如果他没被开除，那我一定会开始储备血液，而且卖得很便宜。"
        npc "这孩子值得这么多。"
    elif "bunga_bego" in buff_events:
        npc "孩子们都在担心那些花。"
        npc "只要它们不开始在他们体内生长，他们就没事。我想是这样。"
    elif "sucker3" in active_quests:
        npc "该死的猫！差点带走一整条鱼！"
    else:
        npc "需要什么吗？问问里面的太太。"
    npc "哦，顺便问一下，今天抓到什么了吗，孩子？如果抓到了，我愿意从你手里买一些。"
    $ jual_ikan2 = ["item_clown", "item_angel", "item_jelly", "item_eel", "item_fish", "item_octo", "item_turtle"]
    if check_inv_for(jual_ikan):
        play sound "sfx/bell.mp3"
        call screen inventory(inv, selling=True)
    else:
        show side_p f at pic
        mc "我现在不需要，但谢谢你告诉我这个！"
        hide side_p
    jump map_store
label grocery:
    if calendar.weekday == "Sat" or calendar.weekday == "Sun":
        hide screen peta_all
    else:
        hide screen store_map
    scene book with dissolve
    $ market = [ "item_water","item_sugar","item_yeast", "item_egg", "item_milk", "item_cocoa","item_wine",
    "item_honey", "item_ham", "item_meat","item_fish", "item_mushroom","item_bait"]
    play sound "sfx/bell.mp3"
    queue sound "sfx/welcome_fem.mp3"
    call screen shop(market)
    $ NPC = "???"
    if calendar.weekday == "Sat" or calendar.weekday == "Sun":
        
        if "bunga_bego" in buff_events:
            if "beku" in quil_events:
                scene map_infected_f with dissolve
            else:
                scene map_infected with dissolve
        else:
            if "beku" in quil_events:
                scene map_frozen with dissolve
            else:
                scene map_all with dissolve
        jump world_map
    else:
        jump map_store
label alat_tulis:
    hide screen store_map
    scene book with dissolve
    $ market = [ "item_paper", "item_quill", "item_heat", "item_turq","item_satire",
    "item_bless", "item_lead", "item_cook"]
    play sound "sfx/bell.mp3"
    queue sound "sfx/welcome_male.mp3"
    call screen shop(market)
    jump map_store
label girl_a:
    hide screen store_map
    $ NPC = "???"
    if "mc_bangkit" in my_events:
        npc "我本来期待在莱纳尔向女朋友求婚，但现在...嗯，我想天使雕像也行。"
    elif "beku" in quil_events:
        npc "冰冻湖面的人一定对符文有很高的亲和力。"
    elif "io4" in my_events:
        if "ice_rune" in my_events:
            npc "我在梦中仍能听到伊欧的声音。伊欧...伊欧...你为什么抛弃了我们？"
        else:
            npc "我希望这次能请个女校长。威廉还行，但他有点可疑。"
            npc "我家里养了一只海妖，他总是问一些奇怪的问题。"
    elif "vamp_visit" in red_events:
        npc "这个学期一切都不顺利。我在考虑搬回死亡地带。"
        npc "虽然那里前景不太好，但是..."
    elif "bite_day" in red_events:
        npc "你听说皮尔斯和塞恩的事了吗？"
        npc "兄弟，谁没听说啊？"
        npc "我听说吸血鬼王本人可能会来惩罚他！"
        npc "哦，太酷了，你觉得我们能看到他的战舰吗？那可是沃特克最大的飞船！"
    elif "ajax" in fia_events:
        npc "阿什姆和阿贾克斯打得挺凶的。不过，如果是我爸的话，我会做得更过分。"
    elif "bunga_bego" in buff_events:
        npc "我正试图说服我父亲把我带离这里，我可不想和那些花待在一起！"
    elif "sucker3" in active_quests:
        npc "天哪！刚才那是只猫吗？我以为我们不允许带宠物。"
    elif "q1" in quil_events:
        $ NPC = "女孩"
        npc "你觉得我有机会约阿什姆出去约会吗？"
        $ NPC = "男孩"
        npc "可能没戏，他太迷恋[povname]了，你没机会的。"
    else:
        npc "天啊，你刚才看到阿什姆了吗？是我的错觉还是他变得更帅了？"
        npc "是啊，不过我更喜欢塞恩。"
    $ NPC = "???"
    jump map_store
label girl_b:
    hide screen store_map
    $ NPC = "???"
    if "mc_bangkit" in my_events:
        npc "我想我真的要退学了。莱纳尔事件之后，我意识到我不适合这种猎巫行为。"
    elif "beku" in quil_events:
        npc "我在那个湖里抓螃蟹！该死，现在我所有的蟹笼都冻在里面了。"
    elif "io4" in my_events:
        if "ice_rune" in my_events:
            npc "我最好的朋友从湖里出来了。我们设法让她接受了心理咨询。"
            npc "希望她能尽快好起来。"
        else:
            npc "你知道吗，我开始觉得校长的死可能不是意外。"
            npc "这里发生了很多糟糕的事。问题是谁在背后搞鬼。"
    elif "vamp_visit" in red_events:
        npc "哼，一切都变糟了，不是吗？先是墨水短缺，现在又是这样。"
        npc "我还不如退学去当个血袋算了。"
    elif "bite_day" in red_events:
        npc "我妈妈告诉我她要让我退学。我是说，考虑到所有的袭击事件，我能理解，但还是..."
    elif "ajax" in fia_events:
        npc "不要啊，我英俊的阿什姆，你怎么变成这样的混蛋！"
    elif "bunga_bego" in buff_events:
        npc "啊啊，那是花瓣吗？把它从我身上弄走！"
        npc "那只是普通的花瓣。别大惊小怪的！"
    elif "sucker3" in active_quests:
        npc "我刚才看到那个金眼睛的家伙带着一只猫。那是真的猫吗？如果是使魔怎么办？！"
    elif "fire1" in active_quests and "fire1" not in completed_quests:
        npc "我有点担心吉尼维，她一直在说要烧毁学校。"
        npc "显然她很害怕她的家人会把她卖给吸血鬼，因为他们破产了。"
        npc "但她的父母不会做这种可怕的事，对吧？贵族对自己的亲人真的那么无情吗？"
    else:
        npc "我不敢相信他们让那个新来的家伙进来。他的眼睛是金色的，他肯定有问题！"
    jump map_store
label walk_d:
    hide screen store_map
    $ NPC = "???"
    if "mc_bangkit" in my_events:
        npc "莱纳尔的遭遇我并不惊讶，但我很惊讶之前没有人试图干预。"
        npc "这几乎就像教会故意放任那个岛一样。"
    elif "beku" in quil_events:
        npc "老实说，我想杀了冻结湖面的人，我再也不能钓鱼了！"
    elif "io4" in my_events:
        if "ice_rune" in my_events:
            npc "你听说奥林以前的灵魂伴侣从湖里复活了吗？他们之前就已经灵魂绑定了。"
            npc "奥林已经有了新男友，这太劲爆了！"
        else:
            npc "这不是学习的最佳学期。发生了这么多悲剧，我几乎无法集中注意力！"
    elif "vamp_visit" in red_events:
        npc "我很高兴帝国退缩了。那些家伙让我毛骨悚然！"
    elif "bite_day" in red_events:
        npc "你觉得塞恩真的对塔图姆和她的朋友们负责吗？"
        npc "我是说，我也不敢相信，但是考虑到阿什姆之前的爆发，现在又发生这种事...我觉得奎尔和他的朋友们不再值得信任了。"
    elif "ajax" in fia_events:
        npc "每个人似乎都纠结于阿什姆和阿贾克斯的争吵。说真的，别再纠结了。" 
    elif "bunga_bego" in buff_events:
        npc "那些花让每个人都紧张兮兮的。我不能怪他们，但是..."
    elif "day3" in quil_events:
        npc "最近卡斯特里的很多贵族都失踪了，不知道发生了什么。"
    else:
        npc "戈莫拉的商店更加多样化，但还有其他地方可以买到符文墨水。"
        npc "有人说这个地方以前是个符文墨水工厂，学校地下室里还留有一些生产工具。"
    jump map_store
label walk_e:
    hide screen store_map
    $ NPC = "???"
    if "mc_bangkit" in my_events:
        npc "对教会进行了调查。"
        npc "看来他们忽视了自己的职责，过于关注墨水短缺问题。"
        npc "我希望他们彻底解散教会。"

    elif "beku" in quil_events:
        npc "你试过在湖上滑冰吗？冰面真的很光滑！"
    elif "io4" in my_events:
        if "ice_rune" in my_events:
            npc "杰森和湖边的一个男孩搞上了。"
            npc "结果发现他们是表亲，隔了几代。真尴尬。"
        else:
            npc "我希望维尔科娃能成为我们的新校长。她很严格，但头脑很清醒。"
    elif "vamp_visit" in red_events:
        npc "用大蒜把自己裹起来！"
        show side_p f at pic
        mc "啊？"
        hide side_p
        npc "吸血鬼讨厌大蒜！现在就用大蒜擦遍全身！"
        "那个男人开始用大蒜擦脸，其他学生都目瞪口呆地看着他。"

    elif "bite_day" in red_events:
        npc "别被那些闲言碎语影响了，[povname]。"
        show side_p f at pic
        mc "啊？"
        hide side_p
        npc "我是说关于塞恩的事。"
        npc "我了解他，塞恩。他脑子里装的都是屎，而且太容易被骗了，这对他自己没好处。"
        npc "如果他有些咬人的问题，嗯，我们每个人都有自己的问题，对吧？"
        npc "如果他需要血液，就告诉我，好吗？我会帮他搞定的。"
    elif "bunga_bego" in buff_events:
        npc "希望教会能介入。不过我猜这也没什么用，毕竟死亡地带的情况也没有好转。"
    elif "day3" in quil_events:
        npc "有传言说有一群杀手在针对贵族，这就是为什么很多贵族失踪或破产的原因。"
        npc "不知道这是不是真的？"
    else:
        npc "我希望仙子们能帮忙猎巫。"
        npc "我知道吸血鬼更是他们关注的重点，但是还是..."
    jump map_store
label boy_c:
    hide screen store_map
    $ NPC = "???"
    if "diari1" in active_quests and "password" not in my_events:
        scene overlook with dissolve
        $ NPC = "杰瑞米"
        npc "嘿[povname]，你还记得我手机日记的密码吗？"
        show side_p f at pic
        mc "啊？我为什么会知道你的密码？"
        hide side_p
        npc "呃，因为我们为了文学作业交换过日记，记得吗？"
        show side_p f at pic
        mc "等等？所以你知道我日记的密码？"
        hide side_p
        npc "我知道主密码，是\'Licorice\'。但我不知道你每个日记条目的密码。"
        npc "话说回来，我的呢？你还记得我的吗？"
        show side_p w at pic
        mc "试试\'password\'。"
        hide side_p
        npc "不，不可能是...哦。哈哈，没错。谢谢你，[povname]。"
        show side_p he at pic
        mc "（既然我已经有了我日记的密码，我应该去我的房间读一读。）"
        hide side_p
        $ my_events.append("password")
        scene map_shops with dissolve
    elif "mc_bangkit" in my_events:
        npc "嘿[povname]。你知道吗，我看到你从莱纳尔出来。"
        npc "你到底在搞什么鬼，嗯？"
    elif "beku" in quil_events:
        npc "听说你和你那三个崇拜你的男人把湖面冻住了。"
        npc "别担心，我不会告诉任何人的。我也觉得这地方需要换换风景。"
    elif "io4" in my_events:
        if "ice_rune" in my_events:
            npc "呃...你为什么要把我从梦中叫醒？伊欧...你是我的救星。"
        else:
            npc "真难以相信威廉大师死了。我真以为他会死于巫师之手，而不是这样。"
    elif "vamp_visit" in red_events:
        npc "你觉得考试会因为最近的混乱而推迟吗？"
        npc "科尔，我希望如此！"
    elif "bite_day" in red_events:
        scene overlook with dissolve
        npc "皮尔斯正在利用他那小小的咬伤吸引注意力。"
        npc "那几乎只是轻轻咬了一下。然而他却把自己的遭遇与塔图姆和其他人发生的事联系起来。"
        npc "不可能是塞恩，那个人太善良了，做不出这种事。"
        npc "如果有人想杀人，我倒是会更多地怀疑你。"
        show side_p s at pic
        mc "我？"
        hide side_p
        npc "你这家伙挺可疑的，特别是你最近的行为变化如此之大。"
        scene map_shops with dissolve
    elif "ajax" in fia_events:
        npc "阿贾克斯的父亲是个好人。真不敢相信阿什姆会那样诅咒他。"
    elif "sucker3" in active_quests:
        npc "你刚才看到一只大老鼠了吗？"
        npc "我觉得那是只猫。"
        
    elif "password" in my_events:
        $ NPC = "杰瑞米"
        npc "天气越来越冷了。伊格尼亚的夏天真短。"
        $ NPC = "???"
    else:
        if "inkwell" not in topics:
            scene overlook with dissolve
            npc "今年夏天爸爸给我找了个求婚者。赫卡斯勋爵。"
            npc "呃，我认识他。我很抱歉，娜特。"
            $ NPC = "娜特"
            npc "哈...长子的责任，我想。"
            $ NPC = "???"
            npc "换个角度想，至少你没有和奎尔配对！"
            $ NPC = "娜特"
            npc "没错，我真为那个必须和他灵魂绑定的人感到遗憾。"
            $ NPC = "???"
            npc "我知道，对吧？那个人真是厚颜无耻！我听说他的堂兄可能会取代他成为继承人。"
            npc "不过我怀疑他父亲是否会允许这种事发生。"
            $ topics.append("inkwell")
            play sound "audio/success.mp3"
            "学到了新的谈话话题：{color=#FF1500}英克威尔家族的戏剧性事件。{/color}"
            scene map_shops with dissolve
        else:
            npc "你读过图书馆里科尔的日记吗？真是很有趣的读物。"
            npc "不过她的一些条目被删减了。我不知道为什么。"
        
    jump map_store

#well
screen well_map():
    tag menu
    if "sucker3" in active_quests:
        imagebutton:
            idle "images/maps/store/lya.png"
            hover "images/maps/store/lya.png"
            xpos 1018 ypos 414
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("cat_lyall")]
            focus_mask None
            mouse "search"
        imagebutton:
            idle "images/maps/store/spy1.png"
            hover "images/maps/store/spy1_hover.png"
            xpos 516 ypos 227
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("spy1")]
            focus_mask None
            mouse "search"
        imagebutton:
            idle "images/maps/store/spy2.png"
            hover "images/maps/store/spy2_hover.png"
            xpos 1523 ypos 117
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("spy2")]
            focus_mask None
            mouse "search"
    else:
        imagebutton:
            idle "images/maps/store/dry.png"
            hover "images/maps/store/dry.png"
            xpos 802 ypos 609
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("dry")]
            focus_mask None
            mouse "search"
        imagebutton:
            idle "images/maps/store/panto.png"
            hover "images/maps/store/panto.png"
            xpos 661 ypos 520
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("panto")]
            focus_mask None
            mouse "search"
    imagebutton:
        idle "images/maps/store/naik.png"
        hover "images/maps/store/naik.png"
        xpos 972 ypos 264
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("map_store")]
        focus_mask None
        mouse "search"
label map_well:
    hide screen store_map
    scene well
    call screen well_map
label panto:
    hide screen well_map
    mc "它被锁上了。"
    jump map_well
label dry:
    hide screen well_map
    mc "一口干涸的老井。"
    jump map_well
label spy1:
    hide screen well_map
    $ NPC = "???"
    npc "我在做什么？当然是在监视那个半巫师啊！"
    jump map_well
label spy2:
    hide screen well_map
    $ NPC = "???"
    npc "真不敢相信他们让一个巫师来这里。"
    jump map_well
label cat_lyall:
    hide screen well_map
    scene well with dissolve
    play music "MUSIC/MusMus-BGM-077.mp3"
    show buff laugh blush bloom at center with dissolve:
        yoffset 770
    "你看到莱尔在抚摸他脚边的猫。那只猫看起来很开心，当莱尔把它抱在怀里时，它发出了呼噜声。"
    if girl:
        show p_side f at pic
    else:
        show side_p f at pic
    mc "莱尔？"
    if girl:
        hide p_side
    else:
        hide side_p
    play sound "sound/effects/cloth.mp3"
    buff keluh sweat shock -bloom "[povname]！你-你在这里做什么？"
    show buff sad -shock
    "你分不清哪个更胆小，是莱尔还是那只猫。两个看起来都像是要吓得跳起来。"
    if check_inv_for(cat_items):
        if girl:
            show p_side s at pic
        else:
            show side_p s at pic
        mc "等等！别跑！我带了零食来。"
        if girl:
            show p_side f
        else:
            show side_p f
        mc "我是说给猫的，不是给你的。"
        if girl:
            hide p_side
        else:
            hide side_p
        "那只猫慢慢地靠近你，轻咬着那份气味浓烈的零食。你用夹克抓住了它，它立刻就依偎在你怀里。"
        $ InvItem(*item_catfood).toss(1)
        $ InvItem(*item_cat).pickup(1)
        if girl:
            show p_side f at pic
        else:
            show side_p f at pic
        play sound "sound/effects/meow.mp3"
        mc "抓到你了！你知道你的主人有多担心吗？"
        if girl:
            hide p_side
        else:
            hide side_p
        buff eh shock "哦，它已经有主人了吗？"
        show buff sad -shock
        if girl:
            show p_side f at pic
        else:
            show side_p f at pic
        mc "是啊，她一直在到处找它。怎么，你想留下它吗？"
        if girl:
            hide p_side
        else:
            hide side_p
        buff keluh -sweat sigh "我确实想。它……它不会逃跑。"
        show buff sad -sigh
        if girl:
            show p_side s at pic
        else:
            show side_p s at pic
        mc "哦。"
        if girl:
            hide p_side
        else:
            hide side_p
        if girl:
            show girl at horzappear
        else:
            show pboy at horzappear
        menu:
            "其他人对你还好吗？":
                hide girl
                hide pboy
                $ putri.points += 5
                buff keluh sigh "我不知道，他们似乎都害怕我。"
                buff sad frusta "我理解为什么，但是……我不是我父亲。"

            "被人畏惧总比自己畏惧别人好。":
                hide girl
                hide pboy
                $ putri.points -= 5
                if putri.points <0:
                    $ ibu.points = 0
                $ main.points += 1
                buff scold frusta "你听起来像我父亲。"
        show buff kzl -frusta
        if girl:
            show p_side f at pic
        else:
            show side_p f at pic
        mc "说到这个，厌男者伊瓦尔真的是你父亲吗？"
        if girl:
            hide p_side
        else:
            hide side_p
        show buff huh sweat sigh
        "莱尔勉强地点了点头。"
        buff keluh -sweat -sigh "阿什姆先生告诉我要把他当作一个精子捐献者，但是血缘关系是不会说谎的。"
        if girl:
            show p_side f at pic
        else:
            show side_p f at pic
        mc "你和阿什姆谈过？"
        if girl:
            hide p_side
        else:
            hide side_p
        buff lega blush shock "是的，他人很好。他把他的旧教科书给了我用，因为图书管理员不让我借任何书。"
        buff keluh sweat -shock "哦，呃，不是因为我是谁，而是因为他似乎有点神志不清……我是说那个图书管理员。"
        show buff frown -sweat
        show side_p he at pic
        if "met_librarian" in my_events:
            mc "（是啊，听起来很符合实际情况。）"
        else:
            mc "（真的吗？不知道那是什么样的图书管理员。）"
        hide side_p
        if girl:
            show p_side s at pic
        else:
            show side_p s at pic
        mc "你介意我问你是如何逃脱的吗？我是说，从你父亲那里。"
        if girl:
            hide p_side
        else:
            hide side_p
        if girl2:
            buff scold frusta"我确实介意。对不起，[povname]女士，但恕我直言……我不认识你。"
        else:
            buff scold frusta"我确实介意。对不起，[povname]先生，但恕我直言……我不认识你。"
        show buff frown sweat -frusta
        if girl:
            show p_side se at pic
            mc "好吧，你可以直接叫我[povname]。我们是室友，难道我们不能好好相处成为朋友吗？"
            hide p_side
        else:
            show side_p se at pic
            mc "好吧，你可以直接叫我[povname]。我们是室友，难道我们不能好好相处成为朋友吗？"
            hide side_p
        show buff confused shock
        "你向他伸出手，但他只是盯着看了一会儿，然后一言不发地跑开了。"
        play sound "sound/effects/tile.mp3"
        hide buff with moveoutright
        if girl:
            show p_side s at pic
        else:
            show side_p s at pic
        mc "天啊，他真的很像一只猫。"
        stop sound
        if girl:
            hide p_side
        else:
            hide side_p
        if "sucker3" not in completed_quests:
            python:
                InvItem(*item_cat).toss(1)
                active_quests.remove("sucker3")
                completed_quests.insert(0, "sucker3")
            show screen completedtask("任务完成！")
            "你立即去找猫的主人。她对你的帮助非常感激。"
            "你迫不及待地想去向阿什姆炫耀一番。"
            $ gold += 100
            
        else:
            "好了，你已经把猫还给了它真正的主人。现在最好回教室上课。"
        stop music
        jump conclusion


    else:
        play sound "sound/effects/meow.mp3"
        "不幸的是，那只猫比你想象的更胆小，它挣脱逃跑，不知道跑到哪里去了。"
        show buff keluh shock sweat
        if girl:
            show p_side s at pic
        else:
            show side_p s at pic
        mc "等等，等等，别——啊啊啊！"
        mc "该死！"
        if girl:
            hide p_side
        else:
            hide side_p
        hide buff with dissolve
        $ active_quests.remove("sucker3")
        "你立即跑去追它，莱尔看着猫离开，显得很伤心。"
        "你最终浪费了一整天试图追捕那只猫。结果发现你根本无法与它的猫科动物反应相匹敌。"
        show screen completedtask("任务失败")
        stop music
        jump conclusion
#Classes
screen kelas_map():
    tag menu
    if calendar.weekday == "Tues" or calendar.weekday == "Thurs":
        if "day3" in quil_events and calendar.day != 18:
            imagebutton:
                idle "images/maps/kls/kls_red.png"
                hover "images/maps/kls/kls_red.png"
                xpos 656 ypos 380
                hovered [ Play ("test_one", "type.wav")]
                action [Play ("test_one", "stroke.mp3"), Jump("kls_red")]
                focus_mask None
                mouse "search"
    imagebutton:
        idle "images/maps/kls/4.png"
        hover "images/maps/kls/4.png"
        xpos 277 yalign 1.0
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("world_map")]
        focus_mask None
        mouse "search"
    imagebutton:
        idle "images/maps/kls/1.png"
        hover "images/maps/kls/1.png"
        xpos 912 ypos 291
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("kelas_0")]
        focus_mask None
        mouse "search"
    imagebutton:
        idle "images/maps/kls/2.png"
        hover "images/maps/kls/2.png"
        xpos 1521 ypos 366
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("lorong_1")]
        focus_mask None
        mouse "search"
    imagebutton:
        idle "images/maps/kls/3.png"
        hover "images/maps/kls/3.png"
        xpos 1132 ypos 268
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("map_lorong")]
        focus_mask None
        mouse "search"
label kls_red:
    scene map_classes1 with dissolve
    hide screen lorong_map
    if "drained" in fia_events and "io0" not in my_events:
        show side_p m at pic
        mc "塞恩！"
        hide side_p
        show red sad sweat shock at center with dissolve:
            yoffset 330
        "在你能抓住他之前，塞恩跑掉了。"
        hide red with dissolve
        "你花了一整天试图抓住他，但都是徒劳。"
        #scene bg_black with w33
        play music "MUSIC/MusMus-BGM-082.mp3"
        scene lor_mlm with w33
        jump ur_room
    elif "vamp_visit" in red_events and "date_cekup" not in red_events:
        show red point sad at center with dissolve:
            yoffset 330
        jump red_cekup
    elif calendar.day == 23 and calendar.month == '/05':
        show red point sad at center with dissolve:
            yoffset 330
        red "我对今晚太紧张了，甚至无法正常思考，唉！"
    else:
        show red point cowo at center with dissolve:
            yoffset 330
        red "哦嘿，[povname]！"
        if "mc_bangkit" in my_events and "red_pisah" not in red_events:
            red "有空吗？我有些话想说。"
        else:
            if mrh.points > 20 and "gift1" not in red_events:
                red grin apa "嘿，[povname]，需要任何魔药材料吗？"
                red datar -apa "我从课上多带了一些魔法粉末，给你！"
                $ InvItem(*item_blue).pickup(1)
                show side_p se at pic
                $ red_events.append("gift1")
                mc "哦，谢谢，塞恩！"
                hide side_p
                red "别客气！话说，想一起出去玩吗？"
            elif mrh.points >= 50 and "gift2" not in red_events:
                red ew sweat apa "嘿，[povname]，你有没有想过我们的灰烬是从哪里来的？"
                show side_p f at pic
                mc "啊？"
                hide side_p
                $ InvItem(*item_ash).pickup(1)
                red perih sigh "灰烬。我是说，它们实际上是\'人类\'遗骸，所以一定是有人捐赠的，对吧。"
                red ngeles -sigh "除非他们真的活活烧死人..."
                red ew frusta "不，不，那又是我的侵入性思维在作祟了。"
                red wry -sweat -frusta "总之，给你，这是我从魔药课上多带的一些灰烬。你以后可能会需要？"
                show side_p he at pic
                mc "...谢谢？"
                show side_p s
                mc "（该死，这些灰烬到底是从哪里来的？）"
                hide side_p
                red datar "别客气！话说，想一起出去玩吗？"
                $ red_events.append("gift2")
            elif mrh.points >= 70 and "gift3" not in red_events:
                red cowo blush bunga "嘿，[povname]，猜猜怎么着？"
                red grin "看来我和菲亚一起学习终于有回报了！"
                $ InvItem(*item_boner).pickup(1)
                red amused cling "我自己制作了一些高质量的\'欲望消除剂\'！耶！"
                show side_p se at pic
                $ red_events.append("gift3")
                mc "那很棒，塞恩，但是等等。你怎么知道它是高质量的？"
                hide side_p
                red mock cling "我们当然测试过了！不是在我自己身上，因为我不是受虐狂，而是在...活体受试者身上。"
                show side_p he at pic
                mc "受试者？"
                hide side_p
                red awkward sweat sigh "你最好还是不要知道。"
                show side_p w at pic
                mc "明白了。"
                hide side_p
                red happy -sweat -sigh "总之，我多做了一些，给你。也许你想让某人欲求不满或什么的。"
                red datar "希望你玩得开心！话说，你有空吗？想一起出去玩吗？"
            else:
                red datar "想一起出去玩吗？"
        show pboy at horzappear
        menu:
            "和塞恩一起出去玩？":
                hide pboy
                red cowo blush "太好了！"
                if "mc_bangkit" in my_events and "red_pisah" not in red_events:
                    jump red_parting
                else:
                    $ datingplace = "Garden"
                    red datar -blush "我知道一个好地方！"
                    jump red_date_check
            "不去。":
                hide pboy
                show side_p f at pic
                mc "也许改天吧。"
                hide side_p
    scene map_classes1 with dissolve
    jump map_kelas  
label map_kelas:
    hide screen peta_all
    scene map_classes1
    hide screen lorong_map
    #play music "MUSIC/MusMus-BGM-049.mp3"
    call screen kelas_map
label kelas_0_up2:
    hide screen peta_all
    scene jualan with dissolve
    play sound "sound/effects/door.mp3"
    show priest evil at right with moveinright:
        yoffset 200
    $ market = [ "item_beet", "item_bones","item_blood",
    "item_siren","item_plasma", "item_root", "item_vicus", "item_weed","item_fire", "item_love",
    "item_blue","item_green","item_ash","item_ice", "item_ctulhu","item_gem", "item_fang", "item_mirror", "item_handcuffs"
    ]
    play sound "sfx/bell.mp3"
    queue sound "sfx/welcome_devil.mp3"
    call screen shop(market)
    show priest at center with move
    dog bleh "现在出去。"
    $ NPC = "???"
    if "bunga_bego" in buff_events:
        if "beku" in quil_events:
            scene map_infected_f with dissolve
        else:
            scene map_infected with dissolve
    else:
        if "beku" in quil_events:
            scene map_frozen with dissolve
        else:
            scene map_all with dissolve
    jump world_map

label kelas_0_up:
    if calendar.weekday == "Sat" or calendar.weekday == "Sun":
        hide screen peta_all
    else:
        hide screen lorong_map
    scene jualan with dissolve
    play sound "sound/effects/door.mp3"
    if "mc_bangkit" in my_events and "dog_bang" not in my_events:
        $ my_events.append("dog_bang")
        show priest chill at center with dissolve:
            yoffset 200
        dog charm "我听说你终于觉醒了，[povname]。"
        dog sly "干得好。想不到一个外来者会是将我们从巫师统治中解放出来的人。"
        dog cling "我只说这一次，所以你最好好好品味。"
        dog hister bunga "...谢谢你"
        show side_p se at pic
        mc "我能从你的商店里得到一件免费的东西吗？"
        hide side_p
        dog bleh frusta "当然不行。我很感激，但还没有感激到那种程度！"
        dog grin -frusta "你还给我留下了一大堆文书工作要处理，小鬼！"
        dog pissed "你知道莱纳尔需要多少清理工作吗？！"
        show side_p f at pic
        mc "有道理。"
        hide side_p
    elif "mey_kill" in my_events and "manja" not in fia_events:
        show side_p f at pic
        mc "嗯，真奇怪，迪特里希不在这里。"
        hide side_p
    elif "bite_day" in red_events and "dog_bite" not in my_events:
        $ my_events.append("dog_bite")
        show priest chill at center with dissolve:
            yoffset 200
        dog "我听说了塞恩的事。校长决定为了学生群体的安全将他隔离。"
        dog side "维尔科娃当然主动提出监督他的惩罚，如果你问我的话，这是个愚蠢的决定。"
        dog bleh "家庭关系常常会蒙蔽良好的判断力。"
        show side_p f at pic
        mc "对你的学生没有同情心吗？"
        hide side_p
        dog grin "我唯一的同情是他被抓住了。你无法与自己的本性抗争。"
        dog bleh "我只希望沃特克公司那些吸血鬼比看起来聪明一些。"
        dog kzl "赔偿受害者，让塞恩接受康复治疗。没必要采取什么极端措施。"
        dog charm "塞恩是我最好的卖血客户。"
        show side_p f at pic
        mc "当然，你只会担心这个，你这个无情的混蛋。"
        hide side_p
        dog grin cling "我为此感到自豪，宝贝。"
        dog evil -cling "那么，我能为你做些什么？"
        show priest at right with move
        $ market = [ "item_beet", "item_bones","item_blood",
        "item_siren","item_plasma", "item_root", "item_vicus", "item_weed","item_fire", "item_love",
        "item_blue","item_green","item_ash","item_ice", "item_ctulhu","item_gem", "item_fang", "item_mirror", "item_handcuffs"
        ]
        play sound "sfx/bell.mp3"
        queue sound "sfx/welcome_devil.mp3"
        call screen shop(market)
        dog bleh "现在出去。"
    elif "black" not in my_events:
        $ my_events.append("black")
        show priest chill at center with dissolve:
            yoffset 200
        dog "需要什么吗，冒牌[povname]？"
        if girl:
            show p_side f at pic
        else:
            show side_p f at pic
        mc "哦，呃...只是随便看看。"
        if girl:
            hide p_side
        else:
            hide side_p
        dog side "我的教室不是你想进就进、想出就出的地方。"
        dog bleh "要么买东西，要么滚蛋。"
        show priest evil at right with move
        $ market = [ "item_beet", "item_bones","item_blood",
        "item_siren","item_plasma", "item_root", "item_vicus", "item_weed","item_fire", "item_love",
        "item_blue","item_green","item_ash","item_ice", "item_ctulhu","item_gem", "item_fang", "item_mirror", "item_handcuffs"
        ]
        play sound "sfx/bell.mp3"
        queue sound "sfx/welcome_devil.mp3"
        call screen shop(market)
        show priest at center with move
        dog bleh"现在出去。"
        if girl:
            show p_side m at pic
        else:
            show side_p m at pic
        mc "天啊，你对所有顾客都这么粗鲁吗？"
        if girl:
            hide p_side
        else:
            hide side_p
        dog grin cling "只对那些小气的顾客。时间就是金钱。如果你想让我\'和蔼可亲\'，那就多从我的商店买点东西。"
        dog charm -cling "对忠实顾客，我可以\'充满爱意\'。"
        show side_p he at pic
        mc "...这家伙只在乎钱，是吧？"
        hide side_p

    else:
        if calendar.day == 17 and calendar.month == '/05':
            show side_p f at pic
            mc "嗯，真奇怪，迪特里希不在这里。"
            hide side_p
        else:
            show priest evil at right with moveinright:
                yoffset 200
            $ market = [ "item_beet", "item_bones","item_blood",
            "item_siren","item_plasma", "item_root", "item_vicus", "item_weed","item_fire", "item_love",
            "item_blue","item_green","item_ash","item_ice", "item_ctulhu","item_gem", "item_fang", "item_mirror", "item_handcuffs"
            ]
            play sound "sfx/bell.mp3"
            queue sound "sfx/welcome_devil.mp3"
            call screen shop(market)
            show priest at center with move
            dog bleh "现在出去。"
    if calendar.weekday == "Sat" or calendar.weekday == "Sun":
        $ NPC = "???"
        if "bunga_bego" in buff_events:
            if "beku" in quil_events:
                scene map_infected_f with dissolve
            else:
                scene map_infected with dissolve
        else:
            if "beku" in quil_events:
                scene map_frozen with dissolve
            else:
                scene map_all with dissolve
        jump world_map
    else:
        scene map_classes with dissolve
        jump map_lorong
label kelas_0:
    hide screen kelas_map
    scene papan with dissolve
    play sound "sound/effects/door.mp3"
    if "mc_bangkit" in my_events and "dog_bang" not in my_events:
        $ my_events.append("dog_bang")
        show priest chill at center with dissolve:
            yoffset 200
        dog charm "我听说你终于觉醒了，[povname]。"
        dog sly "干得好。想不到一个外来者会是将我们从巫师统治中解放出来的人。"
        dog cling "我只说这一次，所以你最好好好品味。"
        dog hister bunga "...谢谢你"
        show side_p se at pic
        mc "我能从你的商店里得到一件免费的东西吗？"
        hide side_p
        dog bleh frusta "当然不是，我很感激，但还没感激到那种程度！"
        dog grin -frusta "你还给我留下了一大堆文书工作要处理，小鬼！"
        dog pissed "你知道莱纳尔需要多少清理工作吗？！"
        show side_p f at pic
        mc "有道理。"
        hide side_p
    elif "bite_day" in red_events and "dog_bite" not in my_events:
        $ my_events.append("dog_bite")
        show priest chill at center with dissolve:
            yoffset 200
        dog "我听说了塞恩的事。校长决定为了学生群体的安全将他隔离。"
        dog "维尔科娃当然主动提出监督他的惩罚，如果你问我的话，这是个愚蠢的决定。"
        dog "家庭关系常常会蒙蔽良好的判断力。"
        mc "对你的学生没有同情心吗？"
        dog "我唯一的同情是他被抓住了。你无法与自己的本性抗争。"
        dog "我只希望沃特克公司那些吸血鬼比看起来聪明一些。"
        dog "赔偿受害者，让塞恩接受康复治疗。没必要采取什么极端措施。"
        dog "塞恩是我最好的卖血客户。"
        mc "当然，你只会担心这个，你这个无情的混蛋。"
        dog "我为此感到自豪，宝贝。"
        dog "那么，我能为你做些什么？"
        show priest evil at right with move:
            yoffset 200
        $ market = [ "item_beet", "item_bones","item_blood",
        "item_siren","item_plasma", "item_root", "item_vicus", "item_weed","item_fire", "item_love",
        "item_blue","item_green","item_ash","item_ice", "item_ctulhu","item_gem", "item_fang", "item_mirror", "item_handcuffs"
        ]
        play sound "sfx/bell.mp3"
        queue sound "sfx/welcome_devil.mp3"
        call screen shop(market)
        show priest at center with move
        dog bleh "现在出去。"
    elif "black" not in my_events:
        $ my_events.append("black")
        show priest chill at center with dissolve:
            yoffset 200
        dog "需要什么吗，冒牌[povname]？"
        if girl:
            show p_side f at pic
        else:
            show side_p f at pic
        mc "哦，呃...只是随便看看。"
        if girl:
            hide p_side
        else:
            hide side_p
        dog side "我的教室不是你想进就进、想出就出的地方。"
        dog bleh "要么买东西，要么滚蛋。"
        show priest evil at right with move
        $ market = [ "item_beet", "item_bones","item_blood",
        "item_siren","item_plasma", "item_root", "item_vicus", "item_weed","item_fire", "item_love",
        "item_blue","item_green","item_ash","item_ice", "item_ctulhu","item_gem", "item_fang", "item_mirror", "item_handcuffs"
        ]
        play sound "sfx/bell.mp3"
        queue sound "sfx/welcome_devil.mp3"
        call screen shop(market)
        show priest at center with move
        dog "现在出去。"
        if girl:
            show p_side m at pic
        else:
            show side_p m at pic
        mc "天啊，你对所有顾客都这么粗鲁吗？"
        if girl:
            hide p_side
        else:
            hide side_p
        dog grin cling "只对那些小气的顾客。时间就是金钱。如果你想让我\'和蔼可亲\'，那就多从我的商店买点东西。"
        dog charm -cling "对忠实顾客，我可以\'充满爱意\'。"
        show side_p f at pic
        mc "...这家伙只在乎钱，是吧？"
        hide side_p
    else:
        show priest evil at right with moveinright:
            yoffset 200
        $ market = [ "item_beet", "item_bones","item_blood",
        "item_siren","item_plasma", "item_root", "item_vicus", "item_weed","item_fire", "item_love",
        "item_blue","item_green","item_ash","item_ice", "item_ctulhu","item_gem", "item_fang", "item_mirror", "item_handcuffs"
        ]
        play sound "sfx/bell.mp3"
        queue sound "sfx/welcome_devil.mp3"
        call screen shop(market)
        show priest at center with move
        dog bleh "现在出去。"
    scene map_classes1 with dissolve
    jump map_kelas

screen lorong_map():
    tag menu
    imagebutton:
        idle "images/maps/kls/up_1.png"
        hover "images/maps/kls/up_1.png"
        xpos 1269 ypos 291
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("kelas_0_up")]
        focus_mask True
        mouse "search"
    imagebutton:
        idle "images/maps/kls/up_2.png"
        hover "images/maps/kls/up_2.png"
        xpos 1086 ypos 420
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("kelas_1")]
        focus_mask None
        mouse "search"
    imagebutton:
        idle "images/maps/kls/up_3.png"
        hover "images/maps/kls/up_3.png"
        xpos 733 ypos 408
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("kelas_2")]
        focus_mask None
        mouse "search"
    imagebutton:
        idle "images/maps/kls/up_5.png"
        hover "images/maps/kls/up_5.png"
        xpos 193 ypos 779
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("map_kelas")]
        focus_mask True
        mouse "search"
    imagebutton:
        idle "images/maps/kls/up_4.png"
        hover "images/maps/kls/up_4.png"
        xpos 267 ypos 234
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("kelas_3")]
        focus_mask True
        mouse "search"
label map_lorong:
    scene map_classes
    hide screen kelas_map
    #play music "MUSIC/MusMus-BGM-049.mp3"
    call screen lorong_map
label kelas_1:
    hide screen lorong_map
    scene map_classes
    "符文图形学\n治疗药剂\n时间表不定。"
    if girl:
        show girl at horzappear
    else:
        show pboy at horzappear
    menu:
        "进去吗？":
            hide girl
            hide pboy
            play sound "sound/effects/door.mp3"
            scene kelas2 with dissolve
            if "day3" not in quil_events:
                "看起来里面没有人。"
                scene map_classes with dissolve
                jump map_lorong
            else:
                jump map_mini
        "留在这里":
            hide girl
            hide pboy
            jump map_lorong
label map_mini:
    scene kelas2
    call screen mini_map
screen mini_map():
    tag menu
    if calendar.day == 17 and calendar.month == '/05':
        imagebutton:
            idle "images/maps/kls2/red2.png"
            hover "images/maps/kls2/red2.png"
            xpos 1375 ypos 291
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("mini_red")]
            focus_mask True
            mouse "search"
    imagebutton:
        idle "images/maps/kls2/pint1.png"
        hover "images/maps/kls2/pint1.png"
        xpos 654 ypos 126
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("map_lorong")]
        focus_mask True
        mouse "search"
    imagebutton:
        idle "images/maps/kls2/pint2.png"
        hover "images/maps/kls2/pint2.png"
        xpos 188 ypos 178
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("map_lorong")]
        focus_mask True
        mouse "search"
    imagebutton:
        idle "images/maps/kls2/teb21.png"
        hover "images/maps/kls2/teb2.png"
        xpos 304 ypos 435
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("mini_stoner")]
        focus_mask True
        mouse "search"
    imagebutton:
        idle "images/maps/kls2/du.png"
        hover "images/maps/kls2/du.png"
        xpos 905 ypos 445
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("kls2_doodle")]
        focus_mask True
        mouse "search"
    imagebutton:
        idle "images/maps/kls2/flirt1.png"
        hover "images/maps/kls2/flirt2.png"
        xpos 916 ypos 576
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("kls2_cupel")]
        focus_mask True
        mouse "search"
    imagebutton:
        idle "images/maps/kls2/bang1.png"
        hover "images/maps/kls2/bang2.png"
        xpos 987 ypos 209
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("kls2_bangku")]
        focus_mask True
        mouse "search"
label kls2_doodle:
    hide screen mini_map
    scene dudel with dissolve
    if "winston" in my_events:
        "温斯顿·希思。不知为何，你对他有种不好的感觉。"
    elif "map1" in active_quests:
        "这些涂鸦让你想起图书馆里的那个。地图上的那个。"
        "环顾四周的笔记本，你看到了温斯顿·希思的名字。不知道他对吸血鬼有什么意见？"
        "还有一个看起来像是塞恩的涂鸦，背面写着\"杀死吸血鬼\"之类的评论。这可能会惹麻烦。"
        if "winston" not in my_events:
            $ my_events.append("winston")
        "但你已经为凯普勒找到了足够的证据。你拿走了温斯顿的书，这应该足以满足他的要求。"
        if not check_inv_for(culp_items):
            $ InvItem(*item_culprit).pickup(1)
        
    else:
        "可爱的涂鸦。"
        if "monarchy" in topics:
            "不知为何，它们看起来有点眼熟。"
    scene kelas2 with dissolve
    jump map_mini
label mini_stoner:
    hide screen mini_map
    if "mc_bangkit" in my_events:
        npc "伙计，当他们宣布莱纳尔沉没时，我还以为我嗨过头了呢。"
        npc "天哪，是什么样的野兽把那个岛屿撕成碎片的？！"
    elif "beku" in quil_events:
        npc "新的溜冰场太酷了，伙计！在这个季节真的能让人凉快下来！"
    elif "io4" in my_events:
        if "ice_rune" in my_events:
            npc "你知道吗，底比斯曾经是我的学长。现在他从湖里复活后，反而成了我们的学弟。"
            npc "仔细想想真是疯狂。"
        else:
            npc "威廉走了我还有点高兴呢。再也没有规矩了，宝贝！"
    elif "vamp_visit" in red_events:
        npc "我他妈太想骑一匹邪血种了！"
        show side_p se at pic
        mc "你是说骑在他们变成龙形态的时候，还是——"
        hide side_p
        npc "没有。"
        show side_p se at pic
        mc "好吧。我不做评判。"
        show side_p s
        mc "（你这个该死的兽控。）"
        hide side_p
    elif "bite_day" in red_events:
        npc "你觉得塞恩会因为血液而兴奋吗？不知道为什么血液对吸血鬼来说这么美味。"
    elif "bunga_bego" in buff_events:
        npc "你觉得我们能把死亡地带的花和大麻杂交吗？那样我们就有无限供应了！"
    elif "ajax" in fia_events:
        npc "听说菲亚教训了阿贾克斯一顿。我一直喜欢那个小鬼。"
    else:
        pass
    if "ctul1" not in active_quests and "ctul1" not in completed_quests:
        npc "顺便说一句，海德温女士的课是最棒的，对吧伙计？"
        npc "你闻到空气中那神圣的大麻味了吗？伙计，他妈的简直是魔法。"
        show side_p f at pic
        mc "你还好吗？你吃了多少魔法蘑菇？"
        hide side_p
        npc "不够多，伙计，永远不够多。嘿，你想知道一个秘密吗？"
        show side_p f at pic
        mc "嗯？"
        hide side_p
        npc "其实有比蘑菇更强劲的东西能让你嗨翻天。"
        npc "你试过\'克苏鲁的呼唤\'吗？"
        show side_p f at pic
        mc "什么？"
        hide side_p
        npc "哦，伙计，那简直是最棒的。它不仅仅是一种毒品，它还能让你看到未来，伙计。"
        npc "因为那个，我知道我将来会怎么死。我已经看到了我的死亡，你能想象吗？"
        show side_p f at pic
        mc "让我猜猜，药物过量？"
        hide side_p
        npc "哇哦，伙计，你是有读心术还是怎么的？"
        show side_p f at pic
        mc "幸运的猜测。"
        hide side_p
        npc "好吧，就为这个我要告诉你怎么做。你只需要一些上好的大麻、一颗狼牙，还有一件克苏鲁圣物。"
        show side_p f at pic
        mc "这些东西看起来都不容易找到。"
        hide side_p
        npc "确实不容易，但绝对值得，老兄。你不想知道怎么避免搞砸事情吗？"
        $ known_recipes.append("item_vita2")
        play sound "audio/success.mp3"
        "学会了新配方，克苏鲁的呼唤！"
        npc "如果你真的做出来了，别忘了分我一些，兄弟。你是真爷们。"
        $ add_new_quest("ctul1")
        python:
            if len(new_quests) > 0: #if we have new quests
                for i in new_quests:
                    active_quests.insert(0, i) #add to top of the quest list
                new_quests = [] #now reset the new quest list, since they all got added
        show screen completedtask("新任务！")
    elif "ctul1" in active_quests:
        npc "回应克苏鲁的呼唤吧，老兄，它在等着你。"
        show side_p f at pic
        mc "（我希望我永远不会复发到变成这种人。）"
        hide side_p 
    else:
        npc "摇滚吧，兄弟，继续摇滚！"
    jump map_mini

label kls2_bangku:
    hide screen mini_map
    scene bangku with dissolve
    $ NPC = "???"
    if "mc_bangkit" in my_events:
        npc "我为莱纳尔的人们感到难过。教会会把他们迁到哪里去呢？"
    elif "beku" in quil_events:
        npc "我希望冰冻湖泊的人能把学校也冻住。"
    elif "io4" in my_events:
        if "ice_rune" in my_events:
            npc "看到湖里的人和现在的莱纳尔居民混在一起，感觉既甜蜜又苦涩。"
            npc "如果我妈妈死在这个湖里而不是在家里，那么也许..."
        else:
            npc "没有校长就应该意味着没有学校！天哪，我真希望萨温节假期快点到来。"
    elif "vamp_visit" in red_events:
        npc "邪血族来的时候，我躲在厕所隔间里。"
        npc "我的村子在赫瓦姆西亚内斯。现在那里到处都是吸血鬼。"
        npc "我们曾经和其他王国一样，直到阿列克谢和他父亲决定玩弄我们村子的思想。"
        npc "屈服于吸血鬼魅力的人开始互相吞噬。变成了食人族。"
        npc "那简直是一场噩梦。"
    elif "bite_day" in red_events:
        npc "我其实有个表亲是吸血鬼。以前是个咬人的，但在和他的伴侣结合后就改变了。"
        npc "也许塞恩应该找个伴侣来减轻他的渴望。"
        npc "当然，这会终结他的不朽，因为他只能从他的伴侣那里吸血，但是..."
    elif "ajax" in fia_events:
        npc "我简直不敢相信阿什姆和阿贾克斯在打架。他们以前关系那么好！"
    elif "bunga_bego" in buff_events:
        npc "神父和修女们告诉我们不要担心，要祈祷，但老实说，我不认为祈祷能除掉这些花。"
    

    else:
        npc "嘿[povname]，我只是在想。你觉得你是个被掉包的孩子吗？"
        show side_p f at pic
        mc "什么？"
        hide side_p
        npc "你知道的，被掉包的孩子。出生时被仙子换走的婴儿。"
        npc "我问这个是因为你和菲亚差别太大了。"
        npc "如果你是的话也不用担心。我就是个被掉包的孩子。事实上，凯普勒先生就是那个把我从父母那里抱走的仙子。"
        show side_p he at pic
        mc "他为什么要把你抱走？"
        hide side_p
        npc "显然我父母以前也在这所学校上学，经常弄乱他的书。所以他怀恨在心。"
        npc "我父母不得不进行整个换子仪式。你知道的，绕圈走100步，13滴蜂蜜，一次人祭。"
        show side_p he at pic
        mc "什么？"
        hide side_p
        npc "什么？"
        npc "咳咳，但是重点是那个恶魔之子被送回给了仙子，而我被送回给了我的父母。"
        npc "你有没有想过你或菲亚可能是恶魔之子？"
        show side_p he at pic
        mc "没有。"
        hide side_p
        npc "哦，好吧。"
    scene kelas2 with dissolve
    jump map_mini
label kls2_cupel:
    hide screen mini_map
    if "mc_bangkit" in my_events:
        npc "那么...现在还有巫师吗？"
        npc "我是说，虽然没有官方宣布，但我打赌在莱纳尔战斗的人一定是纯血巫师。"
        npc "问题是谁呢？"
    elif "beku" in quil_events:
        npc "湖边现在成了热门的约会地点。我不知道寒冷有什么性感的，但就是这样。"
    elif "io4" in my_events:
        if "ice_rune" in my_events:
            npc "真疯狂，想想有些湖里的居民已经超过40岁了，但看起来还是和我们一样年轻。"
            npc "更疯狂的是，我们的校服在过去二十年里都没有变过！"
        else:
            npc "校长不在了，你觉得他们会推迟我们的考试吗？"
    elif "vamp_visit" in red_events:
        npc "我知道它们很吓人，但骑邪血族听起来很有趣，就像在天空中飞翔？"
        npc "那听起来太棒了！"
    elif "bite_day" in red_events:
        npc "我希望他们不会因为最近发生的事而关闭学校。"
    elif "bunga_bego" in buff_events:
        npc "我试着用这些花瓣制作了一种药水。就一次。"
        npc "它在瓶子里很快就长满了，所以我把它们扔进了湖里。之后一切似乎都恢复正常了。"
    elif "ajax" in fia_events:
        npc "听说你宝贝妹妹不得不保护你免受阿贾克斯的伤害。你不觉得这很懦弱吗？"
    elif "dayting" not in my_events:
        $ NPC = "漂亮女孩"
        npc "那么，你打算带谁去水母节？"
        $ NPC = "可爱男孩"
        npc "嗯，我希望你能和我一起去。"
        $ NPC = "漂亮女孩"
        npc "诶？那要看情况，你打算穿什么？"
        $ NPC = "可爱男孩"
        npc "啊？"
        $ NPC = "漂亮女孩"
        npc "如果你指望我穿裙子戴花冠，那就免谈。"
        npc "这次我打算穿皮带和白衬衫。"
        $ NPC = "可爱男孩"
        npc "哦，所以你想当猎人，而我当花朵？嗯。好吧，我的腿确实很漂亮。"
        npc "当然，我会为你扮演少女的！"
        $ NPC = "漂亮女孩"
        $ my_events.append("dayting")
        npc "啊哈哈哈，那就这么定了！"
    else:
        $ NPC = "漂亮女孩"
        npc "你听说莱斯利的事了吗？"
        $ NPC = "可爱男孩"
        npc "他不是退学了吗？"
        $ NPC = "漂亮女孩"
        npc "是啊，他决定去当捕人鱼的。我一直不明白人鱼有什么用。"
        npc "至少塞壬的羽毛和声音还有治疗功效。"
        $ NPC = "可爱男孩"
        npc "不过，人鱼是个不错的谈资。我叔叔的水族馆里就有一条，就摆在门厅正中央。"
        $ NPC = "漂亮女孩"
        npc "呃，太俗气了。"
    $ NPC = "???"
    
    jump map_mini
label mini_red: #RABU W1
    hide screen mini_map
    scene bangku with dissolve
    if "date1_flag" in red_events:
        show red chin laugh at center with dissolve:
            yoffset 330
        red "今晚见。"
        scene kelas2 with dissolve
        jump map_mini
    elif "blood1" in completed_quests or "date_1" in red_events and not "mini_ketemu" in red_events:
        $ red_events.append("mini_ketemu")
        show red point datar at center with dissolve:
            yoffset 330
        red amused "顺便说一句[povname]，我还没有好好感谢你给的那瓶血。"
        red cowo "你今晚有空吗？我想给你看点东西。"
        show pboy at horzappear
        menu:
            "当然。":
                hide pboy
                $ red_events.append("date1_flag")
                red chin hister bunga "太好了，我八点来接你，好吗？记得换掉校服。"
                show side_p f at pic
                mc "等等，你要带我离开学校吗？"
                hide side_p
                red mock cling "哦，你到时候就知道了。"
                show red grin -cling

            "改天吧。":
                hide pboy
                red wry "哦，好吧。有空的时候给我发消息。"
        scene kelas2 with dissolve
        jump map_mini


    else:
        show red point datar at center with dissolve:
            yoffset 330
        red grin "嘿，[povname]，需要什么吗？"
        if "blood1" in active_quests and check_inv_for(blood_items):
            if check_inv_for(plas_items):
                $ InvItem(*item_plasma).toss(1)
            elif check_inv_for(sir_items):
                $ InvItem(*item_siren).toss(1)
            else:
                $ InvItem(*item_blood).toss(1)
            python:
                active_quests.remove("blood1")
                completed_quests.insert(0, "blood1")
                gold += 100
            show side_p se at pic
            mc "我给你弄到了一些血。"
            hide side_p
            $ red_events.append("mini_ketemu")
            red laugh blush bloom "真的吗？哦，还是温的。啊，太棒了！"
            red amused "非常感谢你，[povname]！"
            show screen completedtask("任务完成！")
            red sayang -blush "嘿，让我报答你吧。"
            red laugh "你今晚想出去玩吗？"
            show side_p f at pic
            mc "啊？"
            hide side_p
            red datar "有了这些血，我可以带你去一个特别的地方。怎么样？"
            show pboy at horzappear
            menu:
                "当然。":
                    hide pboy
                    $ red_events.append("date1_flag")
                    red hister bunga "太好了，我八点来接你，好吗？记得换掉校服。"
                    show side_p f at pic
                    mc "等等，你要带我离开学校吗？"
                    hide side_p
                    red mock cling "哦，你到时候就知道了。"
                    show red datar -cling

                "改天吧。":
                    hide pboy
                    red wry "哦，好吧。有空的时候给我发消息。"
            scene kelas2 with dissolve
            jump map_mini


        elif "blood1" in active_quests and not check_inv_for(blood_items):
            show red point datar at center with dissolve:
                yoffset 330
            red "你拿到那些血了吗？"
            show side_p s at pic
            mc "哦对不起，还没有。"
            hide side_p
            red sad sweat "哦..."
            red ngeles apa "你确实有一些，对吧？"
            show red amused
            show side_p w at pic
            mc "当然有！"
            hide side_p
            red wry sigh "好吧，如果你没有也没关系。我存了点钱，待会儿可以在戈莫拉买自己的。"
            scene kelas2 with dissolve
            jump map_mini
        else:
            show red point datar at center with dissolve:
                yoffset 330
            show side_p f at pic
            mc "不用了，我很好。"
            hide side_p
            red cowo "那好吧。"
            scene kelas2 with dissolve
            jump map_mini

label kelas_2:
    hide screen lorong_map
    scene map_classes
    if "rampage" in fia_events:
        mc "天文学与占卜 晚上9点 - 凌晨2点\n魔药学 上午10点 - 下午1点 教授：雷纳德·英格拉姆夫人。"
    else:
        mc "天文学与占卜 晚上9点 - 凌晨2点\n魔药学 上午10点 - 下午1点 教授：波比·埃德娜女士。"
    if girl:
        show girl at horzappear
    else:
        show pboy at horzappear
    menu:
        "进去吗？":
            hide girl
            hide pboy
            jump map_potion
        "留在这里":
            hide girl
            hide pboy
            jump map_lorong
label kelas_3:
    hide screen lorong_map
    if "mey_kill" in my_events and "manja" not in fia_events:
        $ fia_events.append("manja")
        stop music
        scene bangku_kls_empty with dissolve
        play music "MUSIC/MusMus-BGM-013.mp3"
        show priest sly at right with dissolve:
            yoffset 200
        show hedwin wry at left with dissolve:
            yoffset 250
            zoom 1.05
        dog "要再来一杯吗？"
        "你看到赫德温和迪特里希一起分享葡萄酒。"
        "迪特里希坐在教师的桌子上，双腿悬在赫德温身边，而她坐在他面前的椅子上，让迪特里希为她斟满纯金打造的酒杯。"
        hed talk apa "发生什么好事了吗？你平常可不这么慷慨。除非这又是你的\'先试后买\'把戏。"
        dog charm cling "不是的。我不能告诉你细节，但就说科尔赐予了我一笔横财吧。哦，多么美好的一天！"
        hed mad frusta "哦，我讨厌你用那种假声。"
        hed konsul sigh "感觉你想要什么。你是不是又想把我打晕然后偷我的金肢？"
        dog bleh -cling "拜托，你每天从我这里买的东西比你的四肢贵十倍。"
        dog grin "不，就当这是对我最喜欢的顾客的特殊服务吧。"
        dog hister bunga "在这附近，还有谁比伊格尼亚的瘾君子更能让我赚钱呢？"
        hed mad apa "这是在嘲笑我以前的称号吗？"
        dog side sigh "什么？我不再叫你伊格尼亚之剑了。你失去四肢的那天，这个称号就消失了。"
        dog -sigh "所有的流血和多年的痛苦回忆。值得吗，赫德温？"
        hed konsul sigh "不...不，一点也不值得。"
        "赫德温女士一口气喝完了饮料，随后从迪特里希手中抢过酒瓶。她一口气全喝光了。"
        dog pissed shock "赫德温，慢点！"
        play sound "sound/effects/crash.mp3"
        hide hedwin with vpunch
        "赫德温昏了过去，头重重地砸在迪特里希的大腿上。"
        dog side sigh "哼。"
        "迪特里希从桌子上下来，开始拉扯赫德温的四肢。"
        show side_p s at pic
        mc "（他真的想偷她的义肢吗？！）"
        hide side_p
        show pboy at horzappear
        menu:
            "阻止他":
                hide pboy
                if girl:
                    show palmierproxy chill grit at left with moveinleft:
                        yoffset 40
                else:
                    show palmierproxy chill grit at left with moveinleft:
                        yoffset 100
                mc sweat frusta "你在干什么？！"
                dog bleh sigh "哦，是你啊。"
                dog evil cling "不是很明显吗？我在偷她的义肢。伊格尼亚的黄金对卡斯特里来说很珍贵。"
                mc pissed shock "你——！"
                dog side sigh"我开玩笑的。"
                dog kzl -sigh "自从梅扎被打败后，我有足够的钱买下科普杰和奇奇亚。"
                dog bleh "你真以为我会卑鄙到为了几个钱就出卖赫德温的身体部件吗？"
                mc sad sigh "是的！"
                dog side "好吧，我不会。"
                dog kzl "如果你已经评判完我了，过来帮忙清理一下。"
                mc scratch apa tanya "清理？"
                show palmierproxy frown -sweat shock
                play sound "sound/effects/plate.mp3"
                "迪特里希把赫德温的假肢末端朝你倾斜。里面有相当多的腐烂花朵和干涸的血迹。"
                dog side "如果你会用符文，就把花烧掉，然后把假肢浸在水里。"
                dog "或者你可以梳理她的头发，解开所有的结，而我来清理她的义肢。"
                mc deject sweat -shock "哦，呃，好的，我可以梳理她的头发。"
                show palmierproxy chill frown 
                "迪特里希从侧口袋里掏出一把梳子和一小瓶玫瑰水。"
                dog kzl "护发油，能让她的头发保持健康和光泽。"
                mc apa "哦，嗯，好的。"
                dog bleh frusta "怎么了？别傻看了，开始梳头吧。"
                mc ew frusta "好-好的。只是，抱歉，我没想到你会是做这种事的类型。"
                show palmierproxy sad -frusta
                dog side sigh "我不是。这是我对一个朋友的承诺。她的灵魂伴侣，我的前辈和最好的朋友...毕肖普。"
                dog kzl -sigh "他现在\'死了\'，成了死亡地带里的十几朵花之一。"
                dog pissed frusta "他在疏散一群孤儿离开维胡尔切西亚时牺牲了自己。"
                dog bleh "愚蠢的傻瓜。应该先救富人再救穷人。至少那样赫兹还能因他的牺牲得到一笔抚恤金。"
                mc side sigh "有些事情比金钱更有价值，迪特里希。我相信赫德温女士会为她的灵魂伴侣是个英雄而感到高兴。"
                dog kzl sigh "如果人们叫她赫德温夫人，她会更高兴。从技术上讲，她仍然是。灵魂伴侣是永恒的。"
                dog -sigh "但很少有学生认识毕肖普，所以他们叫她赫德温女士。总比叫她瘾君子或疯子强吧。"
                dog side apa "你知道他们以前叫赫兹伊格尼亚之剑吗？"
                dog grin cling "战场上的死亡使者。毕肖普是盾牌，确保我们守住阵线。"
                mc apa tanya "你参加过战争吗？"
                dog evil cling "我们都参加过。但我把自己安排在富人中间。疏散富人是我的首要任务，显然。"
                mc rajuk sigh "显然。"
                dog pissed frusta "但赫兹在前线。不知道是出于责任感还是她就是疯了。可能是后者。"
                dog kzl sigh "那婊子在手脚开始开花时就把它们砍掉了。我想伊瓦尔留她一命只是为了看她受苦的乐趣。"
                dog side -sigh "花朵现在仍会时不时从她的伤口中冒出来，但还能控制。只要她清理它们并除掉杂草就行。"
                mc wry -sweat sigh "但她从不这么做，所以你代替她做。她知道吗？"
                dog bleh "我很怀疑，她每次都昏迷不醒。我不想费心闲聊。"
                dog sad sigh "我们俩都会记住毕晓普，歌颂他，然后可能会哭得死去活来。这简直是浪费时间和金钱。"
                mc smile -sigh "我打赌。"
                mc wry blush "（他虽然粗鲁，但其实是个心软的人，不是吗？）"
                show palmierproxy apa both shock
                dog bleh frusta "别对着我傻笑了，快把那些结解开！"
                mc ha sigh "是，先生。"
                dog pissed"等等，轻点！你以前从没给女人梳过头发吗？！从发梢开始，然后慢慢往发根梳！"
                dog "否则你会弄疼她，还会导致她掉头发！"
                show palmierproxy wry -both -sigh
                dog side -frusta "算了，还是让我来吧。你到底有什么用？出去！"
                play sound "sound/effects/door.mp3"
                
            "观察":
                hide pboy
                "你决定给迪特里希一个机会，看看他到底在做什么。"
                "他小心翼翼地一个接一个地取下她的假肢，然后摘下她的头饰。"
                "他从侧口袋里掏出一把梳子，开始梳理海德温打结的头发。"
                show priest kzl at center with move
                dog side frusta "啧。要花好几个小时才能解开所有这些结。"
                dog bleh "你的假肢里又有血和枯萎的花了。你知道吗，总有一天你会感染的。"
                dog sad sigh "不过你根本不在乎。你从来不照顾自己，是吧，海德？"
                hed "嗯嗯。"
                "海德温几乎没有回应。她挠了挠鼻子，伸了个懒腰，在桌子上舒服地躺着。"
                dog kzl frusta "不。你几乎没注意到我寄给你的钱，或者每次你买毒品时我都会把钱汇回去的事实。"
                dog side sigh "哈啊...我为什么要答应毕晓普在他死后照顾你呢？"
                dog bleh -sigh "这简直是在浪费钱。"
                hed "嗯。别想偷我的假肢，迪特里希。"
                dog kzl frusta "我没有，你闭嘴别动就是了！说真的。你还记得我为你做过这么多次吗？"
                dog sigh "伊格尼亚之剑，沦落成了一个瘾君子。这真是世界末日了。"
                "迪特里希专注于其中一个结，当他轻轻地梳开时，骄傲地笑了，然后亲吻了海德温的发梢。"
                dog sad frusta "你值得更好的，海德。"
        scene map_classes with dissolve
        play music "MUSIC/MusMus-BGM-049.mp3"
        jump map_lorong
   
    elif "day3" in quil_events and "rahasia" not in my_events:
        $ my_events.append("rahasia")
        scene map_classes with dissolve
        stop music
        py "你确定吗，海德温？"
        hed "毫无疑问，贝克家的孩子不像[kamu]表面看起来那样。"
        show side_p f at pic
        mc "什么？"
        hide side_p
        "你听到一些老师在门后谈论你。担心他们察觉到了，你..."
        show pboy at horzappear
        menu:
            "撬开门锁" if check_inv_for(loot_items):
                hide pboy 
                scene bangku_kls_empty with dissolve
                play sound "sound/effects/door.mp3"
                "你撬开了锁，偷偷往房间里瞥了一眼。"
                $ my_events.append("rahasia2")
                show hedwin konsul at left with dissolve:
                    yoffset 250
                    zoom 1.05
                hed "[povname]对塞恩的态度有所不同，而且[kamu]看起来比平时更慌乱。"
                hed sad "这与[dia]平常的样子很不一样。"
                show teach hoo apa at center with dissolve:
                    zoom 0.95
                    
                stag "你怎么看，迪特里希？"
                show teach datar -apa
                show priest pissed at right with dissolve:
                    yoffset 200
                dog "我觉得..."
                dog grin cling "我觉得我还是要把赌注押在[povname]和奎尔身上。"
                play music "MUSIC/MusMus-BGM-099.mp3"
                show hedwin sad with move:
                    xalign 0.3
                show nun proud shock at left with moveinleft:
                    yoffset 190
                    zoom 1.05
                nun "你怎么敢？！没文化的蠢猪。塞恩和[povname]才是最终的真爱！"
                hed mad "呃，维尔科娃？你在推我，啊啊啊！"
                play sound "sound/effects/bump.mp3"
                hide hedwin with vpunch
                stag frown sigh "你瞎了吗，老维尔科娃？阿什姆和[povname]才是最终的配对。"
                nun cross frusta "你叫谁老，你这棵枯树？"
                show teach horns -frusta
                hide priest with dissolve
                show hedwin wry at right with dissolve:
                    yoffset 250
                    zoom 1.05
                    xzoom -1.0
                hed "好了，好了。我以前也是支持阿什姆的，但我不得不同意维尔科娃的看法。"
                hed talk "我好不容易才忍住没尖叫，然后[kamu]居然吸了吸他的手指？！啊啊啊啊！"
                show nun -frusta
                stag hoo apa "所以海德温，这意味着你把赌注改押在塞恩和[povname]身上了，对吧？全部500金币？"
                scene orat-oret with dissolve
                "你看到凯普勒先生在黑板上写着什么。那是...一个赌池？一个关于你最终会和谁在一起的赌池？"
                show side_p s at pic
                mc "（说真的？这些老师到底有多无聊，居然对\'我的\'感情生活开了一个赌池？）"
                hide side_p
                show poppy hair sad at center with dissolve:
                    zoom 0.9
                py "我还是不明白你们为什么对这四个人如此感兴趣。"
                py "对我们的学生的感情生活下注，是不是有点不恰当？"
                hide poppy with dissolve
                show teach hoo cling at center with dissolve:
                    zoom 0.95
                stag "恰恰相反，年轻的波比。这对我们的理智至关重要，尤其是对我。否则我们在这所学校里怎么娱乐自己？"
                show teach datar -cling
                show nun cross at left with moveinleft:
                    yoffset 190
                    zoom 1.05
                nun "同意。在威廉给我们自己的休息室之前，我们还能做什么？"
                show priest bleh sigh at right with dissolve:
                    yoffset 200
                dog "我只是为了钱才来的。"
                show hedwin wry at right behind teach with dissolve:
                    yoffset 250
                    zoom 1.05
                    xzoom -1.0
                    xalign 0.9
                if girl:
                    
                    hed "我很好奇年轻的[povname]会选择谁。是青梅竹马，旧情人，还是那个狂野的种马？"
                    hed talk "哦，这简直就像我看的言情小说一样！"
                    show hedwin smile
                else:
                    hed wry "我对其他学生的爱情生活不感兴趣，但是那个小受四人组三部曲这个季节真是太火了。"
                    show side_p s at pic
                    mc "（这居然是个三部曲？？？）"
                    hide side_p
                    
                stag happy apa "波比，你确定不想加入吗？赌池现在已经很大了，几乎所有的教职员工都参与了。"
                show teach datar -apa
                scene orat-oret with dissolve
                show teach frown shock at right with moveinright:
                    zoom 0.95
                show nun cross shock at left with moveinleft:
                    yoffset 190
                    zoom 1.05
                show poppy hair cry at center with dissolve:
                    zoom 0.9
                py "嗯。不用了，谢谢。我还是觉得这很奇怪。我是说，如果我们开始对你和维尔科娃下注，你会怎么想，亲爱的？"
                show teach frown -shock
                show poppy wry 
                nun proud apa "波比，你是在暗示什么吗？"
                py laugh "哦，得了吧亲爱的，我知道你们两个有一腿。尽管你们俩都假装针锋相对。"
                py wry "这没什么好羞耻的，你知道吗？就算沃特克和塞维德处于冷战状态，也不意味着你们需要如此。"
                nun cross frusta "吸血鬼和仙子是不能结合的，波比。在我的国度里，这是一种罪恶的行为。"
                py sad "但你现在不在那些地方。"
                stag horns cling "你以为我会让这头野兽吸我纯正未稀释的仙子之血吗？我知道你们这些吸血鬼有多失控。"
                nun proud shock "再叫我吸血鬼，看看会发生什么，凯普勒。我曾经杀过数百个你们这种人。想加入你的同类吗？"
                scene orat-oret with dissolve
                show priest bleh sigh at right with dissolve:
                    yoffset 200
                dog "好了，够了，小精灵男孩，会走路的蚊子。把敌意留给那些巫师吧。"
                show hedwin wry at left with dissolve:
                    yoffset 250
                    zoom 1.05
                dog evil cling "或者学生们，对我来说都行。"
                show priest sly -cling
                hed sad "同意。我们别再争吵了，回去工作吧，好吗？"
                show poppy base cry at center with dissolve:
                    zoom 0.9
                py "..."
                play sound "sound/effects/walk.mp3"
                scene bangku_kls_empty with dissolve
                "老师们正朝你这边走来。"
                
                show pboy at horzappear
                menu:
                    "跑":
                        hide pboy
                        play sound "sound/effects/door.mp3"
                        play music "MUSIC/MusMus-BGM-049.mp3"
                        scene map_classes with dissolve
                        show priest side apa at center with dissolve:
                            yoffset 200
                        "你冲下楼梯，但在路上你看到迪特里希偷偷瞥了你一眼。"
                        show priest charm cling
                        "……脸上带着顽皮的微笑。"
                        $ my_events.append("die_deal")
                        $ NPC = "???"
                        scene bg_black with w20
                        if "bunga_bego" in buff_events:
                            if "beku" in quil_events:
                                scene map_infected_f with w20
                            else:
                                scene map_infected with w20
                        else:
                            if "beku" in quil_events:
                                scene map_frozen with w20
                            else:
                                scene map_all with w20
                        jump world_map

                    "躲藏":
                        hide pboy
                        stop music
                        play sound "sound/effects/door.mp3"
                        scene map_classes with dissolve
                        "你躲在门后，门猛地打开，差点撞到你的脸。"
                        "当老师们离开时，你注意到维尔科娃女士和凯普勒先生留在了房间里。"
                        scene orat-oret with dissolve
                        show teach frown frusta at right with moveinright:
                            zoom 0.95
                        show nun cross sigh at left with moveinleft:
                            yoffset 190
                            zoom 1.05
                        stag sigh "波比真是个爱管闲事的女人。"
                        play music "MUSIC/MusMus-BGM-092.mp3"
                        nun proud sigh "照照镜子看看自己吧，亲爱的。"
                        stag happy cling "至少我还有倒影可以看，亲爱的。"
                        nun bunga "呵呵。"
                        stag frown sigh "对不起，我不该叫你吸血鬼。一时口快。"
                        nun cross "别道歉。那是个不错的称呼。但如果你在我们约会时这么叫我，我真的会把你吸干的，我的爱。"
                        stag grin cling "真可怕啊，我的小吸血鬼。"
                        show teach happy with move:
                            xalign 0.6
                        show nun cross with move:
                            xalign 0.4
                        "凯普勒和维尔科娃相拥在一起，姿态浪漫。随后，凯普勒在维尔科娃的额头上轻轻一吻。"
                        stag frown -cling "你真的杀了数百个我的同类吗？"
                        nun proud -bunga "对不起，我的爱。那是50年前，在贝尔汉姆围城战期间。"
                        stag hoo sigh "哦，原来那是你干的。别担心，我不怪你。贝尔汉姆注定要陷落。"
                        nun cross frusta "然而，我仍然要为此负责。想到我曾经用你族人的鲜血将这身白袍染红，我感到非常痛苦。"
                        stag datar -sigh "你不想换掉那身制服吗？你已经不再是血骑士了。"
                        nun sigh "我知道我应该在这里穿修女服，但它们和邪血教徒的服装太相似了。"
                        nun frusta "和塞恩的母亲还有我……我做不到——"
                        stag frown sigh "嘘，别说了，我不该提起这个。我相信她会感谢你，感谢你所做的一切。"
                        stag datar -sigh "试着记住她作为你曾经服侍的血骑士的样子，而不是她后来变成的样子。"
                        if "blood_knight" not in topics:
                            $ topics.append("blood_knight")
                            play sound "audio/success.mp3"
                            "新话题：{color=#FF1500}血骑士。{/color}"
                        nun proud -frusta "……我渴望着吸血鬼君主制度倒台的那一天。那样我们就能在一起，结为一体了。"
                        stag happy "我也是，我的爱，我也是。"
            "继续偷听":
                hide pboy
                stag "你怎么看，迪特里希？"
                dog "我觉得[povname]表现得和[dia]平常一样。难道不是你需要被检查一下吗，赫德温？"
                hed "我知道我看到了什么！"
                nun "让我们看看情况如何发展吧。"
                show side_p f at pic
                mc "老师们是不是察觉到了什么？迪特里希似乎在为我打掩护。不过我还是得小心赫德温女士。"
                hide side_p
            "离开":
                hide pboy
                "你还有其他事情要担心。"
        scene map_classes with dissolve
        play music "MUSIC/MusMus-BGM-049.mp3"
        jump map_lorong
    else:
        "祝福与魔咒。你能听到里面传来老师的声音。现在最好不要进去。"
        jump map_lorong
label lorong_1:
    hide screen kelas_map
    scene map_classes1
    "校长办公室。"
    if "day3" in quil_events:
        if "io4" in my_events:
            "门上画着符文，已经锁上了。"
        else:
            "校长在里面。你没有理由进去。"
        jump map_kelas
    
    
    else:
        if girl:
            show girl at horzappear
        else:
            show pboy at horzappear
        menu:
            "进去吗？":
                hide girl
                hide pboy
                if "break_in" in my_events:
                    scene princip_map with dissolve
                    jump head_map
                else:
                    if check_inv_for(loot_items):
                        play sound "sound/effects/door.mp3"
                        "你用找到的发夹撬开了锁。"
                        scene princip_map with dissolve
                        jump head_map
                    else:
                        mc "门锁上了。如果有细发夹之类的东西，也许我能撬开。"
                        jump map_kelas
            "留在这里":
                hide girl
                hide pboy
                jump map_kelas
#principal_map
screen map_head():
    tag menu
    imagebutton:
        idle "images/maps/princip/5.png"
        hover "images/maps/princip/5.png"
        xpos 568 ypos 948
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("map_kelas")]
        focus_mask True
        mouse "search"
    imagebutton:
        idle "images/maps/princip/glob.png"
        hover "images/maps/princip/glob.png"
        xpos 757 ypos 48
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("globe_head")]
        focus_mask True
        mouse "search"
    imagebutton:
        idle "images/maps/princip/sur.png"
        hover "images/maps/princip/sur.png"
        xpos 793 ypos 775
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("surat")]
        focus_mask True
        mouse "search"
    imagebutton:
        idle "images/maps/princip/inv.png"
        hover "images/maps/princip/inv.png"
        xpos 1020 ypos 757
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("invite")]
        focus_mask True
        mouse "search"
    imagebutton:
        idle "images/maps/princip/kurs.png"
        hover "images/maps/princip/kurs.png"
        xpos 912 ypos 732
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("chair")]
        focus_mask True
        mouse "search"
    imagebutton:
        idle "images/maps/princip/kup.png"
        hover "images/maps/princip/kup.png"
        xpos 1405 ypos 577
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("books")]
        focus_mask True
        mouse "search"
label head_map:
    scene princip_map
    $ my_events.append("break_in")
    #play music "MUSIC/MusMus-BGM-101.mp3"
    call screen map_head
label globe_head:
    hide screen map_head
    if "shriek" not in topics:
        if girl:
            show p_side s at pic
        else:
            show side_p s at pic
        mc "这是什么？"
        if girl:
            hide p_side
        else:
            hide side_p
        play sound "sound/effects/awal_anxiety.mp3"
        "你触摸了地球仪，周围响起了不祥的耳语声。你立即退开，不想再深究下去。"
        $ topics.append("shriek")
        play sound "audio/success.mp3"
        "新话题：{color=#FF1500}耳语地球仪。{/color}"
    else:
        show side_p he at pic
        mc "最好不要再碰它了。"
        hide side_p
    jump head_map
label surat:
    hide screen map_head
    if "letter1" in active_quests and not check_inv_for(letter_items):
        $ InvItem(*item_letter).pickup(1)
        if girl:
            show p_side f at pic
        else:
            show side_p f at pic
        play sound "sound/effects/page.wav"
        mc "这一定是我要找的情书。"
        mc "太好了，现在我可以把它还给她了。"
    else:
        mc "一叠信件。"
    if girl:
        hide p_side
    else:
        hide side_p
    jump head_map

label invite:
    hide screen map_head
    "这家伙的记事本上到处都是涂鸦。"
    "你隐约看到了\"Meyza\"和\"需要邀请\"这几个字。"
    if calendar.day == 16 and calendar.month == '/05':
        if girl:
            show p_side f at pic
        else:
            show side_p f at pic
        mc "Meyza，就是伊瓦尔提到的那个名字？这位校长一定也在寻找她。"
        mc "也许他能帮助我。"
        if girl:
            hide p_side
        else:
            hide side_p
    else:
        show side_p he at pic
        mc "梅扎是谁？"
        hide side_p
    jump head_map
label chair:
    hide screen map_head
    if girl:
        show p_side m at pic
    else:
        show side_p m at pic
    mc "恶心，这把椅子为什么是湿的？是汗水吗？"
    if girl:
        hide p_side
    else:
        hide side_p
    jump head_map

label books:
    hide screen map_head
    "你环顾他的书架，发现有一本书不见了。"
    "它留下的空隙还很干净，说明有人最近才拿走了它。"
    "你打开旁边的书，看到了\"犹大之星\"这几个字。"
    if "shriek" in topics:
        if girl:
            show p_side f at pic
        else:
            show side_p f at pic
        mc "这不是主要的黑暗诅咒之一吗？"
        if girl:
            hide p_side
        else:
            hide side_p
        "你翻阅空隙旁边的书，发现它是关于塞勒姆之眼的。"
        if girl:
            show p_side f at pic
        else:
            show side_p f at pic
        mc "这意味着丢失的那本书一定是关于赫卡特之蔷薇的。"
        mc "不知道为什么它不在这里。"
        if girl:
            hide p_side
        else:
            hide side_p
    else:
        if girl:
            show p_side f at pic
        else:
            show side_p f at pic
        mc "听起来像是个俗气的摇滚乐队。"
        if girl:
            hide p_side
        else:
            hide side_p
    jump head_map




# Potion class
screen potion_map():
    tag menu
    imagebutton:
        idle "images/maps/potion/sper.png"
        hover "images/maps/potion/sper.png"
        xpos 783 ypos 379
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("sphere")]
        focus_mask None
        mouse "search"
    imagebutton:
        idle "images/maps/potion/globe.png"
        hover "images/maps/potion/globe.png"
        xpos 495 ypos 349
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("globe")]
        focus_mask None
        mouse "search"
    imagebutton:
        idle "images/maps/potion/tele.png"
        hover "images/maps/potion/tele.png"
        xpos 1183 ypos 265
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("teleskop")]
        focus_mask None
        mouse "search"
    imagebutton:
        idle "images/maps/potion/keraft.png"
        hover "images/maps/potion/keraft.png"
        xpos 1540 ypos 312
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("meja_craft")]
        focus_mask None
        mouse "search"
    imagebutton:
        idle "images/maps/potion/mej.png"
        hover "images/maps/potion/mej.png"
        xpos 373 ypos 844
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("meja")]
        focus_mask None
        mouse "search"
    if calendar.weekday == "Sat" or calendar.weekday == "Sun":
        imagebutton:
            idle "images/maps/potion/ex.png"
            hover "images/maps/potion/ex.png"
            xpos 871 ypos 898
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("world_map")]
            focus_mask None
            mouse "search"
    else:
        imagebutton:
            idle "images/maps/potion/ex.png"
            hover "images/maps/potion/ex.png"
            xpos 871 ypos 898
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("map_lorong")]
            focus_mask None
            mouse "search"
label map_potion:
    hide screen peta_all
    #play music "MUSIC/MusMus-BGM-049.mp3"
    if "poppy" not in my_events and calendar.weekday != "Sat" and calendar.weekday != "Sun":
        jump poppy_meet
    elif check_inv_for(cure_items) and "cure_me" not in red_events and "io4" not in my_events and "bond" not in fia_events:
        jump red_cure
    elif "date2_done" not in tom_events:
        if "bite_day" in red_events and "anak_hilang" not in fia_events:
            jump arshy_date2
        elif "date1_done" in tom_events and "tom_conf" in tom_events:
            if ibu.points >= 25 and "anak_hilang" not in fia_events:
                jump arshy_date2
            else:
                scene map_potion
                call screen potion_map    
        else:
            scene map_potion
            call screen potion_map    
    
    elif check_inv_for(ctul_items) and "ctulpot" not in fia_events:
        "克苏鲁的呼唤药剂在你手中歌唱。"
        "触摸时感觉温暖，粘稠的金色药剂中闪烁着奇异的光芒。"
        $ fia_events.append("ctulpot")
        if calendar.weekday == "Sat" or calendar.weekday == "Sun":
            show pboy at horzappear
        else:
            show pboy s at horzappear
        menu:
            "要喝吗？":
                hide pboy
                if "ctul1" in active_quests and check_inv_for(ctul_items):
                    python:
                        InvItem(*item_vita2).toss(1)
                        active_quests.remove("ctul1")
                        completed_quests.insert(0, "ctul1")
                    show screen completedtask("任务完成！")
                "你喝下了药剂，脑海中开始闪现各种景象，就像在放电影一样。"
                if "diari1" in completed_quests:
                    if girl:
                        scene hugf_end with flashbulb
                    else:
                        scene hugm_end with flashbulb
                    "你看到[povname]开心地拥抱着菲亚在[dia]怀里——[dia]的眼睛是引人注目的银色，瞳孔像猫一样细长。"
                    "所有朋友都在为你们庆祝。"
                elif "iv_curhat" in fia_events:
                    if girl:
                        scene ivar_fend with flashbulb:
                            truecenter zoom 0.7
                    else:
                        scene ivar_end with flashbulb:
                            truecenter zoom 0.5
                    "你看到自己的身影……在亲吻自己？似乎是在一片广阔的花园里。"
                else:
                    if girl:
                        scene seth_fend with flashbulb:
                            truecenter zoom 0.5
                    else:
                        scene seth_mend with flashbulb:
                            truecenter zoom 0.5
                    "你看到自己被你的分身压在身下，他们手中握着一颗发光的白色宝石。"
                if calendar.weekday == "Sat" or calendar.weekday == "Sun":
                    show side_p fr at pic
                else:
                    show side_p f at pic
                mc "嗯。这是怎么回事？"    
                hide side_p
                scene map_potion with flashbulb
                "你眨了眨眼，幻象从你的脑海中消失了。"
                call screen potion_map   
            "不喝。":
                hide pboy
                scene map_potion
                call screen potion_map    

    else:
        scene map_potion
        call screen potion_map
label sphere:
    hide screen potion_map
    scene potion with dissolve
    if calendar.weekday == "Sat" or calendar.weekday == "Sun":
        show side_p fr at pic
    else:
        show side_p f at pic
    
    mc "一个浑天仪？嗯，这里刻着些什么。"
    hide side_p
    "血月将一切联结，即使是那些本不该结合的罪恶。"
    if "bloodmoon" not in topics:
        $ topics.append("bloodmoon")
        play sound "audio/success.mp3"
        "新话题：{color=#FF1500}血月。{/color}"
    scene map_potion with dissolve
    jump map_potion
label globe:
    hide screen potion_map
    "上面有个标签。\"实验品，请勿触摸！\""
    if calendar.weekday == "Sat" or calendar.weekday == "Sun":
        show pboy s at horzappear
    else:
        show pboy at horzappear
    menu:
        "触摸":
            hide pboy
            $ curiosity += 15
            "什么也没发生。"
        "别管它":
            $ curiosity -= 15
            hide pboy
            pass
    jump map_potion
label teleskop:
    hide screen potion_map
    show teleskop with dissolve
    if calendar.weekday == "Sat" or calendar.weekday == "Sun":
        show side_p fr at pic
    else:
        show side_p f at pic
    mc "天啊。看看这东西有多大。"
    hide side_p
    hide teleskop with dissolve
    jump map_potion
label meja:
    hide screen potion_map
    if calendar.weekday == "Sat" or calendar.weekday == "Sun":
        show side_p fr at pic
    else:
        show side_p f at pic
    mc "桌子上有个铭牌，上面写着波比·埃德娜。真是个奇怪的名字。"
    hide side_p
    jump map_potion

label meja_craft:
    hide screen potion_map
    scene craft with dissolve
    if calendar.weekday == "Sat" or calendar.weekday == "Sun":
        show side_p ha at pic
    else:
        show side_p se at pic
    if "sucker3" in active_quests and "cat" in fia_events:
        mc "啊，找到了！"
        hide side_p
        if calendar.weekday == "Sat" or calendar.weekday == "Sun":
            show pboy s at horzappear
        else:
            show pboy at horzappear
        menu:
            "开始制作":
                hide pboy
                jump start_crafting
            "离开":
                hide pboy
                jump map_potion
    else:
        mc "看来我可以在这里制作东西。"
        hide side_p
        if calendar.weekday == "Sat" or calendar.weekday == "Sun":
            show pboy s at horzappear
        else:
            show pboy at horzappear
        menu:
            "开始制作":
                hide pboy
                jump start_crafting
            "离开":
                hide pboy
                jump map_potion
label craft_kelar:
    jump map_potion
label fort_a:
    scene fort with dissolve
    mc "这里暂时没什么可看的。"
    $ NPC = "???"
    if "bunga_bego" in buff_events:
        if "beku" in quil_events:
            scene map_infected_f with dissolve
        else:
            scene map_infected with dissolve    
    else:
        if "beku" in quil_events:
            scene map_frozen with dissolve
        else:
            scene map_all with dissolve
    jump world_map
label fort_b:
    scene fort_upper with dissolve
    $ NPC = "???"
    mc "这里暂时没什么可看的。"
    if "bunga_bego" in buff_events:
        if "beku" in quil_events:
            scene map_infected_f with dissolve
        else:
            scene map_infected with dissolve    
    else:
        if "beku" in quil_events:
            scene map_frozen with dissolve
        else:
            scene map_all with dissolve
    jump world_map
label poppy_meet:
    hide screen potion_map
    play sound "sound/effects/walk.mp3"
    scene kls_potion with dissolve
    if "poppy" not in my_events:
        $ my_events.append("poppy")
    show poppy hair laugh at center with dissolve
    py "亲爱的，有什么我能帮到你的吗？"
    show poppy fake
    if girl:
        show p_side f at pic
    else:
        show side_p f at pic
    mc "哦，呃...艾德娜女士？"
    if girl:
        hide p_side
    else:
        hide side_p
    py awkward "拜托，我告诉过你我们早就不用这么客气了。叫我波比就行。"
    show poppy wry
    if girl:
        show p_side f at pic
    else:
        show side_p f at pic
    mc "好的，波比。嗨，我能用一下房间吗？我需要呃，制作点东西。"
    if girl:
        hide p_side
    else:
        hide side_p
    py laugh "魔药？还是甜点？我记得你以前很喜欢做甜点。当然，那是直到最近为止。"
    py wry "不过没问题，亲爱的，随便用房间。只要记得打扫干净，并在7点前离开就行。"
    py laugh "我有天文学和占卜课要上到午夜。"
    if girl:
        show p_side s at pic
    else:
        show side_p s at pic
    mc "啊，是的，好的。哦，还有呃，波比？"
    if girl:
        hide p_side
    else:
        hide side_p
    py fake "怎么了？"
    if girl:
        show p_side s at pic
    else:
        show side_p s at pic
    mc "我该怎么制作魔药来着？"
    if girl:
        hide p_side
    else:
        hide side_p
    py base kaget"..."
    py cry "哦，亲爱的。我真希望你能戒掉毒品，你之前做得很好。我知道你和阿什姆分手对你打击很大，但是还是..."
    show poppy sad
    if girl:
        show p_side m at pic
    else:
        show side_p m at pic
    mc "（等等，什么？不是我甩了他吗？）"
    if girl:
        hide p_side
    else:
        hide side_p
    py fake "你需要的一切都在架子上。研钵、坩埚，所有东西都有。"
    py hair sad "哦，我知道这不该我说，但还是要照顾好自己。我不想看到你们年轻人浪费生命。"
    play sound "sound/effects/walk.mp3"
    scene map_potion with dissolve
    jump map_potion

## DORM
screen dorm_map():
    tag menu
    imagebutton:
        idle "images/maps/siang/end.png"
        hover "images/maps/siang/end.png"
        xpos 658 ypos 255
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("dorm_end")]
        focus_mask None
        mouse "search"
    imagebutton:
        idle "images/maps/siang/ex.png"
        hover "images/maps/siang/ex.png"
        xpos 1623 ypos 399
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("world_map")]
        focus_mask None
        mouse "search"
    if calendar.weekday == "Mon" or calendar.weekday == "Wed" or calendar.weekday == "Sat":
        imagebutton:
            idle "images/maps/siang/4.png"
            hover "images/maps/siang/4_hover.png"
            xpos 999 ypos 184
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("couch_4")]
            focus_mask None
            mouse "search"
        imagebutton:
            idle "images/maps/siang/2.png"
            hover "images/maps/siang/2_hover.png"
            xpos 1504 ypos 471
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("couch_2")]
            focus_mask None
            mouse "search"
        imagebutton:
            idle "images/maps/siang/duo.png"
            hover "images/maps/siang/duo_hover.png"
            xpos 756 ypos 566
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("couch_3")]
            focus_mask True
            mouse "search"
    else:
        imagebutton:
            idle "images/maps/siang/gal.png"
            hover "images/maps/siang/gal_hover.png"
            xpos 387 ypos 526
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("couch_4")]
            focus_mask None
            mouse "search"
    imagebutton:
        idle "images/maps/siang/quest.png"
        hover "images/maps/siang/quest_hover.png"
        xpos 907 ypos 539
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("couch_1")]
        focus_mask True
        mouse "search"


label map_dorm:
    hide screen peta_all
    if calendar.day == 30 and calendar.month == '/05': #Rabu W3
        jump curfew_day
    if calendar.day == 23 and calendar.month == '/05': #Selasa W2
        scene kmr_malam with fade
        "今晚是重要的夜晚。你立即换好衣服，前往阿什姆的房间。"
        show quil libur sulk at right with dissolve:
            yoffset 200
        show red bebas mls sweat at left with dissolve:
            yoffset 330
        show tom go frown at center with dissolve:
            yoffset 190
        "奎尔帮你画好了面对梅扎所需的符文。当阿什姆和塞恩向你点头示意时，每个人看起来都很紧张。"
        if "help_me" in my_events:
            tom blow "迪特里希已经先行一步。他说不要引起任何人的注意。"
            red kaget -sweat apa "他弄到邀请函了？"
            show red frown -apa
            tom ew sweat "也许吧。他说得很含糊，说这样做是为了以防发生任何...意外。"
            show tom frown -sweat
            quil ejek sigh "他是个做事周到的人。嗯，我猜这不是他第一次做这种见不得人的工作。"
            show quil datar
            tom capek blow "也不会是最后一次。"
        tom frown -blow "准备好了吗？"
        show side_p h at pic
        mc "我已经准备好了。"
        hide side_p
        play sound "sound/effects/woosh.mp3"
        "你们三个人手拉着手，梅扎邀请函上的火焰将你们整个吞没。"
        scene bg_black with w20
        jump meyza_fight
    elif calendar.weekday == "Sat" or calendar.weekday == "Sun":
        if "bunga_bego" in buff_events:
            if "beku" in quil_events:
                scene map_infected_f with dissolve
            else:
                scene map_infected with dissolve    
        else:
            if "beku" in quil_events:
                scene map_frozen with dissolve
            else:
                scene map_all with dissolve
        "宿舍。停止探索并结束这一天？"
        show pboy s at horzappear
        menu:
            "结束这一天":
                $ morning = False
                $ afternoon = False
                $ evening = False
                $ night = True
                hide pboy
                scene bg_black with w20
                if "io0" in my_events and "io4" not in my_events:
                    jump io_dream_check
                elif calendar.day == 30 and calendar.month == '/05': #Selasa W3
                    jump curfew_day
                elif calendar.day == 23 and calendar.month == '/05': #Selasa W2
                    scene kmr_malam with fade
                    "今晚是重要的夜晚。你立即换好衣服，前往阿什姆的房间。"
                    show quil libur sulk at right with dissolve:
                        yoffset 200
                    show red bebas mls sweat at left with dissolve:
                        yoffset 330
                    show tom go frown at center with dissolve:
                        yoffset 190
                    "奎尔帮你画好了面对梅扎所需的符文。当阿什姆和塞恩向你点头示意时，每个人看起来都很紧张。"
                    if "help_me" in my_events:
                        tom blow "迪特里希已经先行一步。他说不要引起任何人的注意。"
                        red kaget -sweat apa "他弄到邀请函了？"
                        show red frown -apa
                        tom ew sweat "也许吧。他说得很含糊，说这样做是为了以防发生任何...意外。"
                        show tom frown -sweat
                        quil ejek sigh "他是个做事周到的人。嗯，我猜这不是他第一次做这种见不得人的工作。"
                        show quil datar
                        tom capek blow "也不会是最后一次。"
                    tom frown -blow "准备好了吗？"
                    show side_p h at pic
                    mc "我已经准备好了。"
                    hide side_p
                    play sound "sound/effects/woosh.mp3"
                    "你们三个人手拉着手，梅扎邀请函上的火焰将你们整个吞没。"
                    scene bg_black with w20
                    jump meyza_fight
                elif calendar.day == 15 and calendar.month == '/05':
                    "当你进去时，莱尔已经睡着了。"
                    play sound "sound/effects/cloth.mp3"
                    "你尽量不发出声音，然后倒在床上睡觉。"    
                    scene bg_black with eye_shut
                    jump dreamscape
                elif calendar.day == 17 and calendar.month == '/05':
                    "当你走进去时，莱尔已经熟睡了。"
                    play sound "sound/effects/cloth.mp3"
                    "你尽量不发出声音，然后倒在床上睡觉。"    
                    scene bg_black with eye_shut
                    jump io_dream
                elif calendar.day == 26 and calendar.month == '/05': #Sabtu W2
                    jump buff_nyari_baju
                else:
                    play sound "sound/effects/cloth.mp3"
                    "你在床上辗转反侧了一会儿，最后终于睡着了。"    
                    scene bg_black with eye_shut
                    if "iv_dream2" not in my_events:
                        jump iv_second
                    else:
                        jump morning
            "算了":
                hide pboy
                $ NPC = "???"
                if "bunga_bego" in buff_events:
                    if "beku" in quil_events:
                        scene map_infected_f with dissolve
                    else:
                        scene map_infected with dissolve    
                else:
                    if "beku" in quil_events:
                        scene map_frozen with dissolve
                    else:
                        scene map_all with dissolve
                jump world_map

    else:    
        scene tgh_siang
        #play music "MUSIC/MusMus-BGM-082.mp3"
        call screen dorm_map
label dorm_end:
    hide screen dorm_map
    if calendar.day == 18 and calendar.month == '/05':
        mc "我还有课，现在还不能休息。实际上，我应该赶快去射箭场，不然就要迟到了。"
        "你跑到射箭场，准备上维尔科娃女士的课。"
        jump combat_kls
    elif calendar.day == 17 and calendar.month == '/05':
        if "q1" not in quil_events:
            show side_p f at pic
            mc "我还没找到奎尔，最好先和他把事情说清楚。"
            hide side_p
            jump map_dorm
        else:
            "宿舍。停止探索并结束这一天？"
            show pboy at horzappear
            menu:
                "结束这一天":
                    hide pboy
                    if calendar.day == 15 and calendar.month == '/05':
                        jump inky
                    elif calendar.day == 16 and calendar.month == '/05':
                        jump conclusion
                    else:
                        stop music
                        play music "MUSIC/MusMus-BGM-082.mp3"
                        scene bg_black with w20
                        scene lorong_night with w20
                        $ morning = False
                        $ afternoon = False
                        $ evening = False
                        $ night = True
                        jump mlm_map
                        #if "iv_dream2" not in my_events:
                        #    jump iv_second
                        #else:
                        #    jump morning
                            
                "算了":
                    hide pboy
                    jump map_dorm

    elif calendar.day == 15 and calendar.month == '/05':
        "宿舍。停止探索并与奎尔见面？"
    else:
        "宿舍。停止探索并结束这一天？"
        
    if girl:
        show girl at horzappear
    else:
        show pboy at horzappear
    menu:
        "结束这一天":
            hide girl
            hide pboy
            if calendar.day == 15 and calendar.month == '/05':
                jump inky
            elif calendar.day == 16 and calendar.month == '/05':
                jump conclusion
            else:
                stop music
                play music "MUSIC/MusMus-BGM-082.mp3"
                scene bg_black with w20
                scene lorong_night with w20
                $ morning = False
                $ afternoon = False
                $ evening = False
                $ night = True
                jump mlm_map
                #if "iv_dream2" not in my_events:
                #    jump iv_second
                #else:
                #    jump morning
                    
        "算了":
            hide girl
            hide pboy
            jump map_dorm
label couch_1:
    hide screen dorm_map
    if "mc_bangkit" in my_events:
        npc "我半夜醒来，看到莱纳尔被大火吞噬。"
        npc "那场景既可怕又美丽。当我打开窗户时，玫瑰花瓣随风飘舞。"
        npc "你觉得是美丽巫师干的吗..."
    elif "beku" in quil_events:
        npc "嘿[povname]，我知道我们关系不是很亲密，但你觉得我们可以一起在冰上滑冰吗？"
        show side_p f at pic
        mc "没有。"
        hide side_p
        npc "可以理解，祝你今天愉快。"
    elif "io4" in my_events:
        if "ice_rune" in my_events:
            npc "一直和冈尼在一起。他是那些跳进湖里的学生之一。"
            npc "是个很好的家伙，有时候分不清现实和幻想，但他是个很酷的人。"
        else:
            npc "我希望他们能为威廉校长举行一个正式的葬礼，他应得的。"
    elif "vamp_visit" in red_events:
        npc "所以你和塞恩建立了羁绊，是吗？嗯，我很高兴他找到了这么好的伴侣。"
        npc "...只是别再来性爱马拉松了，好吗？我不需要知道你的呻吟声是什么样的。"
        show side_p f at pic
        mc "啊，抱歉伙计。"
        hide side_p
        npc "没关系。至少这里有人能享受性生活。"
    elif "bite_day" in red_events:
        npc "我觉得应该对塞恩宽容一些，我是说，这是他第一次发火，对吧？"
        npc "我知道现在时机不太对，因为塔图姆和她的朋友们还在住院，而且我听说塞恩也把他们搞得很惨，但是塞恩毕竟是我们中的一员。"
    elif "bunga_bego" in buff_events:
        npc "我觉得睡在这些死亡地带的花朵旁边不太安全，但我想我别无选择。"
    elif "ajax" in fia_events and "festies" not in my_events:
        npc "阿什姆今晚最好睁一只眼睛睡觉。听说阿贾克斯和他的手下正在策划什么。"
    elif "coco1" in completed_quests:
        $ NPC = "???"
        npc "再次感谢你的热可可，伙计！"
    else:
        $ NPC = "学生A"
        npc "哈欠，天哪，我好累。"
        $ NPC = "学生B"
        npc "现在才中午呢。"
        $ NPC = "学生A"
        npc "我知道，只是最近我睡不好。真希望能喝点热可可，那通常能让我立刻入睡。"
        if "coco1" not in active_quests and "coco1" not in completed_quests:
            $ add_new_quest("coco1")
            python:
                if len(new_quests) > 0: #if we have new quests
                    for i in new_quests:
                        active_quests.insert(0, i) #add to top of the quest list
                    new_quests = [] #now reset the new quest list, since they all got added
            show screen completedtask("新任务！")
        elif "coco1" in active_quests:
            if check_inv_for(coco_items):
                python:
                    InvItem(*item_coco).toss(1)
                    active_quests.remove("coco1")
                    completed_quests.insert(0, "coco1")
                show screen completedtask("任务完成！")
                $ NPC = "学生A"
                npc "哦，谢谢！给，不用找了。"
                $ gold += 15
                play sound "ding.mp3"
                "得到15金币。"
                npc "对了，你喜欢蜂蜜吗？我女朋友告诉我它能帮助睡眠，但对我没用。"
                npc "给，也许你能用得上。"
                $ InvItem(*item_honey).pickup(1)
            else:
                npc "需要什么吗？"



        $ NPC = "???"
    jump map_dorm
label couch_4:
    hide screen dorm_map
    if "cd1" in active_quests and not check_inv_for(cd_items) and "cd1" not in completed_quests:
        if "item_cuffs" not in known_recipes:
            $ NPC = "丽莎"
            show side_p f at pic
            mc "打扰一下，你是丽莎吗？"
            hide side_p
            npc "嗯，怎么了？"
            show side_p he at pic
            mc "听着，这不关我的事，但是..."
            mc "你是不是有过一段风流韵事，而那个人把他的内裤落在你房间里了？"
            hide side_p
            npc "哦，是克里斯托夫派你来的吗？真是个该死的懦夫！"
            npc "他玩弄了我的感情。"
            show side_p f at pic
            mc "我知道，我也不想帮他。"
            hide side_p
            npc "那就别帮，或者，我不知道，你可以帮我。"
            show side_p m at pic
            mc "哦？"
            hide side_p
            npc "你听说过魔法手铐吗？它们只有名字刻在手铐上的人才能解开。"
            npc "我想也许会很有趣...哦，我不知道，诱惑他然后把他铐在那些手铐里，直到他吸取教训？"
            npc "因为你看，无论如何我都会告诉他的未婚妻。那个女孩值得更好的。但我还可以拍些他丢脸的照片，然后贴满整个学校。"
            npc "所以，给我一些魔法手铐，我们就来谈谈，好吗？"
            $ known_recipes.append("item_cuffs")
            play sound "audio/success.mp3"
            "学会了新配方，魔法手铐！"
        else:
            npc "拿到那些手铐了吗？"
            if check_inv_for(cuff_items):
                $ InvItem(*item_cuffs).toss(1)
                show side_p f at pic
                mc "给你！"
                hide side_p
                npc "太棒了，这是他的脏内裤。"
                $ InvItem(*item_cd).pickup(1)
                npc "那个混蛋终于要得到他应得的了！"
            else:
                show side_p f at pic
                mc "还没有。"
                hide side_p
    elif "mc_bangkit" in my_events:
        npc "你和莱尔跑到岛上去了，对吧？我看到你们两个偷偷溜出去了。"
        npc "我只是想让你知道，我已经向迪特里希报告了。他会查清你们背着大家做的一切！"
    elif "beku" in quil_events:
        npc "有时候晚上我能听到冰面裂开的声音，不知道是什么生物在那边滑冰。"
    elif "io4" in my_events:
        if "ice_rune" in my_events:
            npc "自从湖面结冰以来，教堂一直异常安静。不知道他们在忙些什么。"
        else:
            npc "他们真该在这个时候关闭学校。没有威廉大师，教堂很容易遭受巫师的攻击。"
    elif "vamp_visit" in red_events:
        npc "你应该和塞恩住在一起。我是说，你们现在已经结婚了，对吧？"
        npc "灵魂伴侣应该在一起！"
    elif "bite_day" in red_events:
        $ NPC = "丽莎"
        npc "皮尔斯是个爱出风头的人。我打赌他在撒谎，塞恩可能只是靠得太近了而已。"
        $ NPC = "???"
        npc "但是塔图姆和她的朋友们——"
        $ NPC = "丽莎"
        npc "需要我提醒你那个婊子有多讨厌菲亚吗？菲亚和塞恩很亲密。我敢肯定这只是她疯狂计划中的一部分。"
        $ NPC = "???"
    elif "bunga_bego" in buff_events:
        npc "我其实从花园里摘了一朵玫瑰。它没有繁殖，所以我猜是普通的花。"
    elif "ajax" in fia_events and "festies" in my_events:
        npc "听说阿贾克斯在舞会上被打了。不知道是不是阿什姆干的。"
    elif "day3" not in quil_events:
        $ NPC = "???"
        npc "这听起来可能有点疯狂，但我发誓我房间里的科尔雕像在午夜会流出墨水般的眼泪。"
    

    else:
        $ NPC = "丽莎"
        npc "有时候晚上我会听到奇怪的声音，可能是老鼠？"
    $ NPC = "???"
    jump map_dorm
label couch_2:
    hide screen dorm_map
    $ NPC = "???"
    if "mc_bangkit" in my_events:
        npc "[povname]？"
        show side_p se at pic
        mc "嗯？"
        hide side_p
        npc "我好像看到你和菲亚一起跑上楼梯了。"
        show side_p se at pic
        mc "哦，呃，你可能看错了。也许是普莉姆。"
        hide side_p
        npc "可能吧，这里金发的人不多。应该是别人。别在意。"
    elif "beku" in quil_events:
        npc "我喜欢我们的新溜冰场，这是个很好的消暑地方。"
    elif "io4" in my_events:
        if "ice_rune" in my_events:
            npc "宿舍现在有点挤，因为来了湖边的那些学生。"
            npc "我可不想和这些老家伙共用房间。"
        else:
            npc "现在校长走了...你觉得他的私人卧室有人要吗？"
    elif "vamp_visit" in red_events:
        npc "所以现在你们俩建立了联系，我就得忍受你和奎尔的呻吟声了？！"
        npc "科尔，这里谁还能睡得着啊？"
    elif "bite_day" in red_events:
        npc "嘿，你和塞恩有一腿吗？"
        mc "我不知道你在说什么。"
        npc "得了吧，我看透你了，贝克。"
    elif "bunga_bego" in buff_events:
        npc "我还是觉得那个新来的家伙和整个花的事有关。我告诉你，他不是好东西！"
    elif "ajax" in fia_events:
        npc "听说阿贾克斯狠狠教训了阿什姆一顿，是时候有人该给那个小精灵点颜色看看了。"
        play sound "sound/effects/slap.mp3"
        npc "哎哟——！"
        npc "你刚才打我了？！"
        mc "哦，抱歉，有只苍蝇。"

    else:
        npc "我知道不是所有的牧师都是猎巫人，反之亦然，但是...为什么有人会加入教会呢？"
        npc "我是说，牧师或修女怎么才能赚到足够的钱维持生计呢？"
    jump map_dorm
label couch_3:
    hide screen dorm_map
    $ NPC = "???"
    if "mc_bangkit" in my_events:
        npc "真是疯狂，居然要疏散莱纳尔的所有人！"
        npc "我想知道是哪个混蛋在背后搞这些鬼。"
    elif "beku" in quil_events:
        npc "我试着为了好玩而融化湖面，结果差点因为符文腐蚀失去一根手指。"
        npc "那个湖结冰得太厉害了！"
    elif "io4" in my_events:
        if "ice_rune" in my_events:
            npc "我前任是那些从湖里回来的人之一，我为之前没注意到他的问题感到很内疚。"
            npc "他现在在接受治疗，希望他能尽快好起来。"
        else:
            npc "我们打算偷偷溜进校长的旧卧室偷他的东西，你想来吗？"
            show side_p f at pic
            mc "那个人才刚去世！"
            hide side_p
            npc "所以呢？"
    elif "vamp_visit" in red_events:
        npc "嘿，[povname]。下次试着别那么大声，好吗？"
    elif "bite_day" in red_events:
        npc "一开始是奎尔的性爱噪音让我睡不着，现在又是塞恩的事。我只想好好睡个觉，伙计！"
    elif "bunga_bego" in buff_events:
        npc "阿嚏！阿嚏！我对花粉过敏，伙计！"
        npc "嘿，你能帮我弄点活死人药水吗？我听说它能帮助缓解过敏。"
        show side_p se at pic
        mc "怎么可能？"
        hide side_p
        npc "我是说，当你变成鬼魂的时候就不会过敏了，对吧？"
        show side_p f at pic
        mc "嗯。你说得有道理。"
        hide side_p
        if "ghost1" not in active_quests and "ghost1" not in completed_quests:
            $ add_new_quest("ghost1")
            python:
                if len(new_quests) > 0: #if we have new quests
                    for i in new_quests:
                        active_quests.insert(0, i) #add to top of the quest list
                    new_quests = [] #now reset the new quest list, since they all got added
            show screen completedtask("新任务！")

    elif "festies" in my_events and "bite_day" not in red_events:
        npc "节日那晚我听到的那些做爱声音简直了。难道人们不知道这里的墙有多薄吗？！"
    else:
        npc "嘿[nickname]，你能告诉奎尔在卧室里安静点吗？"
        npc "我们知道他很受欢迎，但他不需要把这些都摆在我们面前。"
    jump map_dorm
#ARROW
screen arrow_map():
    tag menu
    imagebutton:
        idle "images/maps/arrow/ex.png"
        hover "images/maps/arrow/ex.png"
        xpos 0 ypos 787
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("world_map")]
        focus_mask None
        mouse "search"
    if calendar.weekday == "Mon" or calendar.weekday == "Wed" or calendar.weekday == "Fri":
        if "q1" in quil_events:
            imagebutton:
                idle "images/maps/arrow/tomi.png"
                hover "images/maps/arrow/tomi.png"
                xpos 725 ypos 392
                hovered [ Play ("test_one", "type.wav")]
                action [Play ("test_one", "stroke.mp3"), Jump("tomi_arrow")]
                focus_mask None
                mouse "search"
        imagebutton:
            idle "images/maps/arrow/2.png"
            hover "images/maps/arrow/2_hover.png"
            xpos 443 ypos 414
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("arrow_2")]
            focus_mask None
            mouse "search"
        imagebutton:
            idle "images/maps/arrow/1.png"
            hover "images/maps/arrow/1_hover.png"
            xpos 971 ypos 378
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("arrow_1")]
            focus_mask None
            mouse "search"
    else:
        
        imagebutton:
            idle "images/maps/arrow/11.png"
            hover "images/maps/arrow/11_hover.png"
            xpos 829 ypos 374
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("arrow_1")]
            focus_mask None
            mouse "search"
        imagebutton:
            idle "images/maps/arrow/22.png"
            hover "images/maps/arrow/22_hover.png"
            xpos 561 ypos 432
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("arrow_2")]
            focus_mask None
            mouse "search"
    imagebutton:
        idle "images/maps/arrow/3.png"
        hover "images/maps/arrow/3_hover.png"
        xpos 1238 ypos 406
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("arrow_3")]
        focus_mask None
        mouse "search"
label map_arrow:
    hide screen peta_all
    if "mc_bangkit" in my_events and "tom_pisah" not in tom_events:
        jump tom_bye
    elif calendar.day == 18 and calendar.month == '/05':
        jump combat_kls
    else:
        scene map_arrow
        #play music "MUSIC/MusMus-BGM-062.mp3"
        call screen arrow_map
label tomi_arrow:
    scene archery_crowd with dissolve
    hide screen arrow_map
    show tom chill at center with dissolve:
        yoffset 190
    
    if "sulk" in tom_events:
        show side_p m at pic
        mc "阿什姆！"
        hide side_p
        tom hip capek frusta "...请别打扰我。"
        play sound "sound/effects/walk.mp3"
        hide tom with moveoutleft
        show side_p s at pic
        mc "等等！"
        hide side_p
        stop sound
        "阿什姆头也不回地离开了。显然，他还需要一些时间来远离你。"
    else:
        
        if "date3_done" in tom_events:
            if "date4_done" not in tom_events and ibu.points>= 75:
                jump arshy_date4
            else:
                pass
        
        if ibu.points > 0 and "gift1" not in tom_events:
            tom calm "哦，对了，我给你带了点东西。"
            $ InvItem(*item_cake).pickup(1)
            show side_p se at pic
            $ tom_events.append("gift1")
            mc "蛋糕？这是你自己烤的吗？"
            hide side_p
            tom pfft cling "当然！我觉得你可能需要点东西提振一下心情。"
            show side_p se at pic
            mc "谢谢你，阿什姆。"
            hide side_p
            tom smile -cling "随时效劳。现在，[povname]，你来这里是为了什么？"
        elif "necrosis" in my_events and "gift2" not in tom_events:
            tom calm "伸出你的手，闭上眼睛。"
            $ InvItem(*item_gem).pickup(1)
            $ tom_events.append("gift2")
            show side_p se at pic
            mc "啊？"
            hide side_p
            tom amused cling "相信我，这会很值得的。"
            show bg_black with eye_shut
            "你闭上眼睛，感觉到掌心有温暖的东西在跳动。"
            hide bg_black with eye_open
            show side_p he at pic
            mc "这是什么？"
            hide side_p
            tom pfft -cling "一颗火焰宝石，是很难找到的稀有材料之一。"
            tom calm "波比在我完美通过她的突击测验后给了我这个。它对制作药水很有用，但老实说，我只是想让你拥有它来保暖你的手指。"
            tom sad blow "你之前那次符文坏死真是吓坏我了。"
            show tom smile -blow
            show side_p se at pic
            mc "我会珍惜它的。谢谢你，阿什姆。"
            hide side_p
            tom smile -cling "随时效劳。现在，[povname]，你来这里是为了什么？"
        elif ibu.points >= 80 and "gift3" not in tom_events:
            $ tom_events.append("gift3")
            $ InvItem(*item_love).pickup(1)
            tom giggle "我又给你准备了一件礼物，虽然我担心这次的不如上次那么令人印象深刻。"
            show side_p se at pic
            mc "我相信无论是什么我都会喜欢的，是什么呢？"
            hide side_p
            tom pfft "爱情。"
            tom calm blow "我是说那种水果。"
            show side_p se at pic
            mc "等等，这是一个双关语礼物吗？"
            hide side_p
            tom amused -blow "也许是吧。也许我整晚都在咯咯笑，想象着你收到我的\'爱情\'时会有什么反应。"
            tom pfft blow "这可是我过去几周精心照料和培育的。"
            tom calm bunga "也许我只是多愁善感，有个传说说赠送爱情果会结下永恒的友谊。"
            tom smile "谁知道呢？总之，请享受我的\'爱情\'吧。"
            show side_p w at pic
            mc "噗。谢谢你，阿什姆。"
            hide side_p
            tom smile -bunga "随时效劳。现在，[povname]，你来这里是为了什么？"
        else:
            tom talk smile apa "[povname]，你来这里有什么事？"
        
        show pboy at horzappear
        menu:
            "和阿什姆一起闲逛":
                hide pboy
                show side_p f at pic
                mc "你有空吗？"
                hide side_p
                tom chill pfft -apa "当然。你有什么想法？"
                show side_p f at pic
                mc "我希望你来决定。"
                hide side_p
                #berubah
                $ datingplace = "Archery"
                #berubah    
                tom calm "我知道一个好地方。"
                jump tom_date_check
            "离开":
                hide pboy
                show side_p f at pic
                mc "只是想来打个招呼。"
                hide side_p
                tom calm -apa "哦，那么，你好。"
    scene map_arrow with dissolve
    jump map_arrow
label arrow_1:
    hide screen arrow_map
    if "mc_bangkit" in my_events:
        npc "我听说引发整个莱纳尔事件的巫师都是纯血统。"
        npc "我还听说贪婪巫师已经死了。这是不是意味着不再需要猎人了？"
    elif "beku" in quil_events:
        npc "我和伙计们一直在往冰冻的湖面上施放火焰符文。"
        npc "但那该死的东西根本融不化，搞什么鬼？！"
    elif "io4" in my_events:
        if "ice_rune" in my_events:
            npc "湖边有个家伙说他以前是队长，想要阿什姆的位置。"
            npc "阿什姆很快就把那家伙打得晕头转向。"
        else:
            npc "我在想我们会不会有新校长。伊格尼亚教会最近似乎很安静。"
    elif "vamp_visit" in red_events:
        npc "你知道，我原以为我的生活很复杂。但看看你。"
        if "date2_done" in quil_events:
            npc "与塞恩灵魂绑定，与奎尔订婚，还是阿什姆的前任。"
        else:
            npc "与塞恩灵魂绑定，还是阿什姆的前任。"
        mc "这是你说我是个荡妇的方式吗？"
        npc "啊？我想是的。你是个荡妇，[povname]。不过我尊重你的奋斗精神。"
    elif "bite_day" in red_events:
        npc "我还是觉得皮尔斯在说谎，关于塞恩的事。你知道男生们都嫉妒那四个小帅哥有多受欢迎。"
    elif "bunga_bego" in buff_events:
        npc "我担心那些花，但至少我们是在地图的另一边练习，对吧？"
    elif "festies" in my_events:
        $ NPC = "学生A"
        npc "我觉得阿贾克斯疯了，他一直说阿什姆和莱尔联手轮奸了他。"
        $ NPC = "学生B"
        npc "我想你是指他们联手欺负他。"
        $ NPC = "学生A"
        npc "差不多啦。"
        $ NPC = "学生B"
        npc "这完全不一样！"
        $ NPC = "???"
    elif "ajax" in fia_events:
        npc "那些家伙在食堂看到阿什姆那样子后，听起来对自己很是自豪。"
        npc "老实说，他们的阴茎嫉妒已经蠢到家了。"
    
    elif "letter1" in active_quests:
        if check_inv_for(letter_items):
            python:
                InvItem(*item_letter).toss(1)
                active_quests.remove("letter1")
                completed_quests.insert(0, "letter1")
            show screen completedtask("任务完成！")
            $ NPC = "女孩A"
            npc "你拿到了？哦，太感谢你了，真的谢谢！"
            npc "来，让我报答你！"
            $ gold += 20
            play sound "ding.mp3"
            "获得了20金币。"
            $ NPC = "???"
        else:
            $ NPC = "女孩A"
            npc "我怎样才能拿回那封信？"
            $ NPC = "???"
    elif "letter1" in completed_quests and calendar.day == 15 and calendar.month == '/05':
        $ NPC = "女孩A"
        npc "再次感谢你的帮助，我真的很感激！"
        $ NPC = "???"
    elif calendar.day == 16 and calendar.month == '/05':
        npc "我听说有个巫师在和贵族合作。这不可能是真的，对吧？"
    else:
        
        if "letter1" not in active_quests and "letter1" not in completed_quests:
            $ NPC = "女孩A"
            npc "哦科尔，哦科尔！"
            $ NPC = "女孩B"
            npc "怎么了？"
            $ NPC = "女孩A"
            npc "我昨天给威廉校长的办公室送了一封情书。"
            $ NPC = "女孩B"
            npc "你干什么？为什么要这么做？那个人都老得不行了！"
            $ NPC = "女孩A"
            npc "这是个恶作剧，好吗？你觉得他已经读过了吗？"
            $ NPC = "女孩B"
            npc "嗯，你可以偷偷溜进去看看。听说他这几天不在城里。"
            if "letter1" not in active_quests and "letter1" not in completed_quests:

                $ add_new_quest("letter1")
                python:
                    if len(new_quests) > 0: #if we have new quests
                        for i in new_quests:
                            active_quests.insert(0, i) #add to top of the quest list
                        new_quests = [] #now reset the new quest list, since they all got added
                show screen completedtask("新任务！")
            $ NPC = "???"
        else:
            npc "卡斯特里的贵族们因为突然的失踪事件变得不安。有人说这是邪教干的。"
            npc "也有人说只是一群富豪在某个热带岛上一起狂欢。谁知道呢？"

    jump map_arrow
label arrow_2:
    hide screen arrow_map
    if "mc_bangkit" in my_events:
        npc "阿什姆最近精神很好。不知道是什么让他心情这么好。"
        
    elif "beku" in quil_events:
        npc "真是疯狂，居然有人能把湖面完全冻住。"
    elif "io4" in my_events:
        if "ice_rune" in my_events:
            npc "自从湖面结冰的事情发生后，阿什姆似乎有点心不在焉。不知道他在想什么。"
            
        else:
            npc "希望他们能尽快找到校长的尸体。"
    elif "vamp_visit" in red_events:
        npc "从半精灵仙子到吸血鬼。"
        npc "看来你转移得挺快啊，[povname]？"
    elif "bite_day" in red_events:
        npc "一些俱乐部成员在考虑把阿什姆踢出去，因为他和塞恩是朋友。"
        npc "要我说，这帮人就是嫉妒！阿什姆真是倒霉透了。"
    elif "bunga_bego" in buff_events:
        npc "听说那个叫莱尔的半精灵要为花的事负责。"
        npc "不知道为什么修女们还没把他赶出去。"
    elif "ajax" in fia_events:
        npc "阿什姆在这里有很多事情要解释。现在有些人开始怀疑他在团队中的诚意。"
    elif calendar.day == 15 and calendar.month == '/05':
        $ NPC = "???"
        npc "嘿[nickname]，考虑加入射箭俱乐部吗？是时候有人该给阿什姆一点教训了。"
        if girl:
            show p_side f at pic
        else:
            show side_p f at pic
        mc "不，谢谢。"
        if girl:
            hide p_side
        else:
            hide side_p
    elif calendar.day == 16 and calendar.month == '/05' and not "met_pike" in my_events:
        $ NPC = "???"
        npc "你知道码头附近有个可怕的老头吗？我听说他来自莱纳尔，但还是很奇怪。"
    else:
        $ NPC = "???"
        npc "你有没有尝试过戈摩拉的提亚莫面包店？我知道他们严格来说是你家族的竞争对手，但他们的蛋糕真的很好吃。"
    jump map_arrow
label arrow_3:
    hide screen arrow_map
    if "mc_bangkit" in my_events:
        npc "最近发生的事情让俱乐部的气氛有点低落。"
        npc "希望莱纳尔的事情过后，一切终于能平静下来。"
    elif "beku" in quil_events:
        npc "我试着用冰冻的湖水做刨冰。"
        npc "味道还不错，虽然几乎不可能融化。"
    elif "io4" in my_events:
        if "ice_rune" in my_events:
            npc "我和一个湖边事件的幸存者聊过。可怜的家伙已经分不清什么是真实的，什么是虚假的了。"
        else:
            npc "我觉得阿什姆可能与威廉的死有关，这想法是不是有点过分？"
            npc "我是说，我知道他对那家伙恨之入骨。"
    elif "vamp_visit" in red_events:
        npc "我很惊讶阿什姆对你和塞恩走得近没有更加沮丧。"
        npc "看来你们都已经放下了。"
    elif "bite_day" in red_events:
        npc "我就知道塞恩没什么好东西，不然他怎么会和阿什姆这样的半精灵做朋友！"
    elif "bunga_bego" in buff_events:
        npc "我听说就连塞维德的仙子们也在试图帮忙解决这个花的问题。"
        npc "他们能有什么帮助。那些享乐主义者从来没为这个世界做过什么好事。"
    elif "ajax" in fia_events:
        npc "那个半精灵终于露出真面目了！打赌他的继父会把他和他妈妈赶到街上去，那才是他们应该待的地方！"
    elif "whore" not in topics:
        "一群男生似乎在谈论阿什姆。"
        $ NPC = "男孩A"
        npc "你看到有多少女孩围着阿什姆转了吗？"
        $ NPC = "男孩B"
        npc "是啊，那家伙到底有什么好的？"
        $ NPC = "男孩C"
        npc "我也不知道，他不过是个走运的私生子，因为他那个当妓女的仙子妈妈嫁给了有钱人。"
        $ NPC = "男孩A"
        npc "没错吧？我都不会惊讶如果他继父也上过他。"
        $ NPC = "???"
        $ topics.append("whore")
        play sound "audio/success.mp3"
        "学到了新话题：{color=#FF1500}阿什姆的母亲。{/color}"
    else:
        "学生们在聊天，你最好不要打扰他们。"
    jump map_arrow
#Courtyard
screen court_map():
    tag menu
    imagebutton:
        idle "images/maps/court/greja.png"
        hover "images/maps/court/greja.png"
        xpos 1147 ypos 160
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("music", "MUSIC/MusMus-BGM-117.mp3"),Play ("test_one", "walk.mp3"), Jump("map_church")]
        focus_mask None
        mouse "search"
    imagebutton:
        idle "images/maps/court/ex.png"
        hover "images/maps/court/ex.png"
        xpos 538 ypos 58
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("world_map")]
        focus_mask None
        mouse "search"
    if calendar.weekday == "Tues" or calendar.weekday == "Thurs" or calendar.weekday == "Sat":
        if "cat_meet" not in tom_events and not "day3" in quil_events:
            imagebutton:
                idle "images/maps/court/tomy.png"
                hover "images/maps/court/tomy.png"
                xpos 811 ypos 115
                hovered [ Play ("test_one", "type.wav")]
                action [Play ("test_one", "stroke.mp3"), Jump("thane_court")]
                focus_mask None
                mouse "search"
        elif "day4_end" in my_events:
            imagebutton:
                idle "images/maps/court/tomy.png"
                hover "images/maps/court/tomy.png"
                xpos 811 ypos 115
                hovered [ Play ("test_one", "type.wav")]
                action [Play ("test_one", "stroke.mp3"), Jump("tomi_court")]
                focus_mask None
                mouse "search"
        imagebutton:
            idle "images/maps/court/gal.png"
            hover "images/maps/court/gal_hover.png"
            xpos 976 ypos 276
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("court_1")]
            focus_mask None
            mouse "search"
        imagebutton:
            idle "images/maps/court/couple.png"
            hover "images/maps/court/couple_hover.png"
            xpos 1134 ypos 382
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("up_court1")]
            focus_mask None
            mouse "search"
        #imagebutton:
        #    idle "images/maps/court/solo.png"
        #    hover "images/maps/court/solo_hover.png"
        #    xpos 778 ypos 248
        #    hovered [ Play ("test_one", "type.wav")]
        #    action [Play ("test_one", "stroke.mp3"), Jump("court_1")]
        #    focus_mask None
        #    mouse "search"

    else:
        imagebutton:
            idle "images/maps/court/nun.png"
            hover "images/maps/court/nun_hover.png"
            xpos 1261 ypos 704
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("court_1")]
            focus_mask None
            mouse "search"
        imagebutton:
            idle "images/maps/court/ink.png"
            hover "images/maps/court/ink_hover.png"
            xpos 1549 ypos 37
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("up_court3")]
            focus_mask None
            mouse "search"
        imagebutton:
            idle "images/maps/court/pedo.png"
            hover "images/maps/court/pedo_hover.png"
            xpos 756 ypos 422
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("up_court2")]
            focus_mask None
            mouse "search"
    imagebutton:
        idle "images/maps/court/chad.png"
        hover "images/maps/court/chad_hover.png"
        xpos 865 ypos 558
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("court_2")]
        focus_mask None
        mouse "search"
    imagebutton:
        idle "images/maps/court/sit.png"
        hover "images/maps/court/sit_hover.png"
        xpos 693 ypos 333
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("court_3")]
        focus_mask None
        mouse "search"

label map_court:
    #play music "MUSIC/MusMus-BGM-037.mp3"
    scene map_court
    call screen court_map
label court_1:
    hide screen court_map
    if "mc_bangkit" in my_events:
        npc "现在情况看起来很糟，但我听说有纯血巫师失踪的传闻。"
        npc "也许他们都死在莱纳尔了。"
    elif "beku" in quil_events:
        npc "维克带我在结冰的湖面上约会，真的很浪漫！"
    elif "io4" in my_events:
        if "ice_rune" in my_events:
            npc "海德温小姐一直在试图让湖边的幸存者来参加她的布道。"
            npc "看来她说的我们学校下面有个领域是对的。"
        else:
            npc "希望他们能好好纪念校长的逝世。那家伙值得这样的待遇。"
    elif "bite_day" in red_events and "cure" not in red_events:
        scene court_tgh_crowd with dissolve
        npc "嘿，[povname]，我想我可以帮忙解决塞恩的咬人问题。"
        show side_p f at pic
        mc "啊？"
        hide side_p
        npc "我奶奶是个吸血鬼，但她说她可以用正确的药物来抑制饥饿感。"
        npc "如果你想要的话，我这里还有那个药剂的配方。"
        $ known_recipes.append("item_obat")
        npc "如果有他伴侣的血效果最好，但塞恩还没有伴侣，所以..."
        show side_p f at pic
        mc "那用他痴迷的人的血呢？"
        hide side_p
        npc "哦，那可能也行。不过我不能保证。"
        show side_p se at pic
        mc "谢谢，呃..."
        hide side_p
        $ red_events.append("cure")
        $ NPC = "莉娅"
        npc "莉娅，我们喝醉时亲热过一次？我们都醉了。别担心，你吻技很差，所以我也一直在试图忘记你。"
        $ NPC = "???"
        show side_p w at pic
        mc "哈哈。抱歉，莉娅。"
        show side_p se
        mc "（这可能是塞恩需要的解药。我应该趁现在赶紧去配制这个药剂！）"
        hide side_p
        scene map_court with dissolve
    elif "festies" in my_events:
        npc "你在节日里玩得开心吗？很不错，对吧？"
    elif "bunga_bego" in buff_events:
        npc "自从那件花的事情发生后，海德温女士一直在加强她的布道。"
        npc "我觉得那个景象触发了她的创伤后应激障碍。我很担心那个女人。"
    elif "ajax" in fia_events:
        npc "阿贾克斯用了月刃符文，对吧？糟糕的选择，那东西基本上就是个回旋镖。如果不是菲亚出手，可能会伤到更多人。"
    elif "day3" in quil_events:
        $ NPC = "???"
        npc "听说卡斯特里的更多贵族失踪了，不知道是怎么回事。"
        
    elif calendar.day == 16 and calendar.month == '/05':
        $ NPC = "???"
        scene court_bench_crowd with dissolve
        npc "先是让那个混血儿阿什姆进来，现在又来了那个巫师。"
        npc "这所学校真是每况愈下。"
        scene map_court with dissolve
    else:
        scene court_tgh_crowd with dissolve
        $ NPC = "修女"
        "一位修女缓缓转头看向你。"
        npc "要不要加入辩论俱乐部，年轻的[povname]？我相信你会发现我们的会议很...诱人。"
        if girl:
            show p_side f at pic
        else:
            show side_p f at pic
        mc "呃，谢谢，但不用了。"
        if girl:
            hide p_side
        else:
            hide side_p
        show side_p he at pic
        mc "（修女让我毛骨悚然。）"
        hide side_p
        $ NPC = "???"
        scene map_court with dissolve
    jump map_court
label court_2:
    hide screen court_map
    scene court_tgh_crowd with dissolve
    $ NPC = "???"
    if "mc_bangkit" in my_events:
        npc "塞恩在莱纳尔事件后似乎心情不错，奎尔也是。"
        npc "不知道他们为什么这么高兴。"
    elif "beku" in quil_events:
        npc "我试着舔了舔冰冻的湖面，差点把舌头扯下来。"
        npc "那东西真的完全冻住了！"
    elif "io4" in my_events:
        if "ice_rune" in my_events:
            npc "我想知道在这些关于湖的破事发生时，校长去哪里了。"
            npc "我感觉有更大的事情在发生，但我不知道是什么。"
        else:
            npc "我在想我们会不会有新校长。伊格尼亚教会最近似乎很安静。"
    elif "vamp_visit" in red_events:
        npc "在所有人中，你选择和塞恩建立联系？？？"
        npc "真是浪费！"
    elif "bite_day" in red_events:
        npc "我希望学校真的能对塞恩采取行动。对皮尔斯的攻击虽然算是小事。"
        npc "但如果他是塔图姆遇袭和其他事件的幕后黑手，那么..."
    elif "bunga_bego" in buff_events:
        if "candy1" not in active_quests and "candy1" not in completed_quests:
            npc "自从那件花的事情发生后，海德温女士一直很慌乱。"
            npc "奎尔和我想给她一些糖果来帮她平静下来。"
            npc "你想帮忙吗？我相信奎尔也会很感激的！"
            $ add_new_quest("candy1")
            python:
                if len(new_quests) > 0: #if we have new quests
                    for i in new_quests:
                        active_quests.insert(0, i) #add to top of the quest list
                    new_quests = [] #now reset the new quest list, since they all got added
            show screen completedtask("新任务！")
        else:
            npc "所有这些花的事情真让我紧张不安。"
    elif "festies" in my_events:
        $ NPC = "???"
        npc "我在舞会上玩得很开心。我试图抓住一只水母，但它飞走了。"
    elif "ajax" in fia_events:
        $ NPC = "???"
        npc "听说了早餐时阿什姆和阿贾克斯发生的事。"
        npc "如果早餐总是那么刺激，我就不会睡过头了！"
    elif "newbuk" in fia_events:
        npc "我读到巫师过去对人类是友善的。"
        npc "我爷爷说我们现在猎杀巫师的唯一原因是因为一个叫塞斯的特殊巫师。"
        npc "据说那家伙喜欢拿人类做实验，还偷人妻子和孩子。"
    else:
        npc "那么你毕业后有什么计划？"
        $ NPC = "男孩"
        npc "还能有什么？踢巫师的屁股，扬名立万！你呢？"
        $ NPC = "女孩"
        npc "我在考虑加入魔法部。"
        $ NPC = "男孩"
        npc "切，说真的吗？你知道只有那些来自维鲁德的自命不凡的学究才能进去。"
        npc "要么就是那些靠爹的钱进去的贵族！"
        $ NPC = "???"
    scene map_court with dissolve
    jump map_court
label court_3:
    hide screen court_map
    scene court_bench_crowd with dissolve
    $ NPC = "???"
    if "mc_bangkit" in my_events:
        npc "我很高兴我们没有人在莱纳尔事件中受伤。"
    elif "beku" in quil_events:
        npc "我简直不敢相信有人把湖面冻住了！我现在上哪儿去弄免费的鱼啊？！"
        
    elif "io4" in my_events:
        if "ice_rune" in my_events:
            npc "自从湖面事件以来，海德温女士的布道变得相当受欢迎。"
            npc "真不敢相信她关于学校地下有个房间的那套说辞居然是真的。"
        else:
            npc "你觉得校长现在是在地狱还是极乐世界？"
            npc "我知道他对我们还不错，但对于海妖来说，嗯……"
    elif "vamp_visit" in red_events:
        npc "你知道吗，[povname]，我很尊重你。"
        npc "不是所有朋友都愿意为了救一个人而结成契约。祝你婚姻幸福。"
        if "date2_done" in quil_events:
            npc "不过我猜你和奎尔的另一段婚约让事情变得复杂了，是吧？"
    elif "bite_day" in red_events:
        npc "你的朋友圈真是奇怪啊，[povname]？"
        npc "先是阿什姆，现在又是这样。天啊，奎尔是你朋友圈里唯一正常的人了。"
        npc "这么说还真是有点讽刺。"
    elif "bunga_bego" in buff_events:
        npc "说实话，在这种时候，我觉得海德温女士的布道很令人安心。那些花朵真的让人感觉像是世界末日。"
    elif "festies" in my_events:
        npc "舞会之后塔图姆和她的团队遭遇的事真是令人难过。"
        npc "希望他们能抓到罪魁祸首。"
    elif "ajax" in fia_events:
        npc "每个人都在说他们是阿什姆队还是阿贾克斯队。这太蠢了。"
        show side_p se at pic
        mc "是啊，但你是哪一队的？"
        hide side_p
        npc "当然是阿什姆队。他可能是个坏人，但他很帅。长相就是一切！"
    elif "sucker3" in active_quests:
        if girl:
            show p_side f at pic
        else:
            show side_p f at pic
        mc "嘿，你看见猫了吗？"
        if girl:
            hide p_side
        else:
            hide side_p
        npc "猫？嗯，我刚才确实看到有东西跑过去了。我想它是朝图书馆那边去了？"
        if girl:
            show p_side f at pic
        else:
            show side_p f at pic
        mc "谢谢。"
        if girl:
            hide p_side
        else:
            hide side_p
    else:
        if "leech" not in topics:
            npc "你知道沃特克帝国的修女都戴面具吗？"
            npc "我听说是为了阻挡血腥味，因为她们用血香来控制水蛭。"
            if girl:
                show p_side f at pic
            else:
                show side_p f at pic
            mc "水蛭？"
            if girl:
                hide p_side
            else:
                hide side_p
            npc "失去理智的吸血鬼，对血液着迷。听说他们发狂时和狼人一样疯狂。"
            $ topics.append("leech")
            play sound "audio/success.mp3"
            "新话题：{color=#FF1500}水蛭。{/color}"
        else:
            npc "如果你对校园周围的墓穴和秘密通道有疑问，直接问海德温就行了。"
            npc "她有点疯疯癫癫的，但她知道很多连凯普勒都不知道的事。"
            npc "不过你得对她的回答持保留态度，因为有些纯粹是疯话。"

    scene map_court with dissolve
    jump map_court
label tomi_court:
    hide screen court_map
    scene court_bench_crowd with dissolve
    show tom chill at center with dissolve:
        yoffset 190
    if "sulk" in tom_events:
        show side_p m at pic
        mc "阿什姆！"
        hide side_p
        tom hip capek frusta "...请别打扰我。"
        play sound "sound/effects/walk.mp3"
        hide tom with moveoutleft
        show side_p s at pic
        mc "等等！"
        hide side_p
        stop sound
        "阿什姆头也不回地离开了。显然，他还需要一些时间来远离你。"
    elif "mc_bangkit" in my_events and "tom_pisah" not in tom_events:
        tom calm "哦，你好[povname]，正是我想见的人。"
        tom amused "我想给你看点东西，来吧。"
        jump tom_bye
    elif calendar.day == 23 and calendar.month == '/05':
        show side_p f at pic
        mc "嘿阿什姆，你今天有空吗？"
        hide side_p
        tom sad frusta "我对你的淡定印象深刻。"
        tom frown "可惜我没有那样的勇气。恐怕我还有几个符文需要准备。"
        tom wry -frusta "也许下次吧。"
    else:
        if "date3_done" in tom_events:
            if "date4_done" not in tom_events and ibu.points>= 75:
                jump arshy_date4
            else:
                pass
        if ibu.points > 0 and "gift1" not in tom_events:
            tom calm "哦，对了，我有东西要给你。"
            $ InvItem(*item_cake).pickup(1)
            show side_p se at pic
            $ tom_events.append("gift1")
            mc "蛋糕？这是你自己烤的吗？"
            hide side_p
            tom pfft cling "当然！我觉得你可能需要点东西提振一下心情。"
            show side_p se at pic
            mc "谢谢你，阿什姆。"
            hide side_p
            tom smile -cling "随时效劳。现在，[povname]，你来这里是为了什么？"
        elif "necrosis" in my_events and "gift2" not in tom_events:
            tom calm "伸出你的手，闭上眼睛。"
            $ InvItem(*item_gem).pickup(1)
            $ tom_events.append("gift2")
            show side_p se at pic
            mc "啊？"
            hide side_p
            tom amused cling "相信我，这会很值得的。"
            show bg_black with eye_shut
            "你闭上眼睛，感觉到掌心有温暖的东西在跳动。"
            hide bg_black with eye_open
            show side_p he at pic
            mc "这是什么？"
            hide side_p
            tom pfft -cling "一颗火焰宝石，是很难找到的稀有材料之一。"
            tom calm "波比在我完美通过她的突击测验后给了我这个。它对制作药水很有用，但老实说，我只是想让你拥有它来保暖你的手指。"
            tom sad blow "你之前那次符文坏死真是吓坏我了。"
            show tom smile -blow
            show side_p se at pic
            mc "我会珍惜它的。谢谢你，阿什姆。"
            hide side_p
            tom smile "随时效劳。现在，[povname]，你来这里是为了什么？"
        elif ibu.points >= 80 and "gift3" not in tom_events:
            $ tom_events.append("gift3")
            $ InvItem(*item_love).pickup(1)
            tom giggle "我又给你准备了一件礼物，虽然我担心这次的不如上次那么令人印象深刻。"
            show side_p se at pic
            mc "我相信无论是什么我都会喜欢的，是什么呢？"
            hide side_p
            tom pfft "爱情。"
            tom calm blow "我是说那种水果。"
            show side_p se at pic
            mc "等等，这是一个双关语礼物吗？"
            hide side_p
            tom amused -blow "也许是吧。也许我整晚都在咯咯笑，想象着你收到我的\'爱情\'时会有什么反应。"
            tom pfft bunga "这可是我过去几周精心照料和培育的。"
            tom calm -bunga "也许我有点多愁善感，有个传说说赠送爱情果会让关系永恒。"
            tom smile cling "谁知道呢，真的？总之，请享受我的\'爱\'吧。"
            show side_p w at pic
            mc "噗。谢谢你，阿什姆。"
            hide side_p
            tom smile -cling "随时效劳。现在，[povname]，你来这里是为了什么？"
        else:
            tom talk smile apa "[povname]，你来这里有什么事？"
        show pboy at horzappear
        menu:
            "和阿什姆一起出去。":
                hide pboy
                show side_p f at pic
                mc "你有空吗？"
                hide side_p
                tom chill pfft -apa "当然。你有什么想法？"
                show side_p f at pic
                #berubah
                $ datingplace = "Court"
                #berubah
                mc "我希望你来决定。"
                hide side_p
                tom calm "我知道一个好地方。"
                jump tom_date_check
            "离开":
                hide pboy
                show side_p f at pic
                mc "只是想来打个招呼。"
                hide side_p
                tom calm -apa "哦，那么，你好。"
    scene map_court with dissolve
    jump map_court
    
label thane_court:
    hide screen court_map
    scene court_up_crowd with dissolve
    "你跟着阿什姆上了楼梯。在你走得太远之前，他注意到了你。"
    show tom chill frown at center with dissolve:
        yoffset 190
    tom apa "找到猫了吗？"
    show tom kzl hip frusta
    if girl:
        show p_side f at pic
    else:
        show side_p f at pic
    mc "和你一样没有进展。"
    hide p_side
    hide side_p
    show tom frown -frusta
    $ tom_events.append("cat_meet")
    if girl:
        show girl at horzappear
    else:
        show pboy at horzappear
    menu ars_talk:
        "{s}{color=#be6f1c}你的母亲{/color}{/s}" if "whore" not in topics:
            
            jump ars_talk
        "你的母亲" if "whore" in topics:
            hide girl
            hide pboy
            if girl:
                show p_side f at pic
            else:
                show side_p f at pic
            mc "嘿，阿什姆……"
            if girl:
                hide p_side
            else:
                hide side_p
            tom eh apa "嗯？"
            show tom frown -apa
            if girl:
                show p_side s at pic
            else:
                show side_p s at pic
            mc "射箭俱乐部的一些人在谈论你的母亲。"
            if girl:
                hide p_side
            else:
                hide side_p
            tom scold sigh blow "让我猜猜，他们说她是个妓女？"
            show tom ha -blow
            if girl:
                show p_side s at pic
            else:
                show side_p s at pic
            mc "..."
            if girl:
                hide p_side
            else:
                hide side_p
            tom hip ew frusta "我会处理的。这不是什么新鲜事。"
            tom scold capek -frusta "我知道我母亲在嫁给我继父之前，对她的职业相当坦率。"
            tom chill kzl "不过，我希望他们能停止提起这件事。"
            if girl:
                show girl at horzappear
            else:
                show pboy at horzappear
            menu:
                "他们是在嫉妒。":
                    hide girl
                    hide pboy
                    $ibu.points += 5
                    show side_p he at pic
                    mc "他们只是想打击你。"
                    hide side_p
                    tom ha "我知道。"
                    tom frown blow "但这并不能改变贵族们经常因为我母亲和我可疑的父母身份而嘲笑我的事实。"
                    tom talk -blow "你理解的，[nickname]。那些自命不凡的人也不太喜欢你的家族。"
                    if girl:
                        show p_side f at pic
                    else:
                        show side_p f at pic
                    mc "……没错。"
                    if girl:
                        hide p_side
                    else:
                        hide side_p
                    show side_p s at pic    
                    mc "（我对贵族或者那些东西一无所知。现在最好保持沉默。）"
                    hide side_p
                "无法改变过去。":
                    hide girl
                    hide pboy
                    tom kzl hip sweat frusta "..."
                    $ ibu.points -= 20
                    if ibu.points <0:
                        $ ibu.points = 0
                    show tom chill frown -sweat -frusta
        "我们的过去" if "suspicion" in fia_events:
            hide girl
            hide pboy
            if girl:
                show p_side f at pic
            else:
                show side_p f at pic
            mc "对了，我能和你聊聊德拉克马尔巫师的事吗？"
            if girl:
                hide p_side
            else:
                hide side_p
            tom scold kzl shock "……为什么？格拉夫人又骚扰你了吗？"
            tom hip ejek cling "要我去处理一下吗？"
            if girl:
                show p_side m at pic
            else:
                show side_p m at pic
            mc "不！我只是想聊聊而已。你能不能，我不知道，再给我讲讲那件事是怎么发生的？"
            if girl:
                hide p_side
            else:
                hide side_p
            tom pfft apa "你是想重温那段光辉岁月吗？"
            tom calm blow "好吧。我们当时在沙罗姆庄园。你、我和其他孩子们在花园里玩巫师和猎人的游戏。"
            tom frown -blow "蒂莫西、卡桑德拉、安德鲁和我是巫师。你是猎人。"
            tom giggle "我记得我嘲笑你把游戏当真了。一个小孩在指关节上画真正的符文。"
            tom wry "我让你擦掉，否则你可能会失去一两根手指，但你对我竖中指，让我们所有人快跑。"
            tom scold amused blow "回想起来，你真是个爱发号施令的孩子。你几乎是强迫我们玩的。"
            tom hip kzl frusta "总之，你把我们这些\'巫师\'逼到喷泉附近，就在那时，德拉克马尔巫师从水中冒出来抓住了我们所有人。"
            tom sad sweat blow "我记得我在溺水，但后来我看到你跳进水里，把我和蒂莫西拉了出来。"
            tom talk -sweat -blow "回到水面上，德拉克马尔巫师召唤出水鞭，抓住蒂莫西和我的脚踝想把我们拉回去。"
            tom lega "她说你只能带走一个，你选择了我。然后你朝她的眼睛扔了块石头，弄瞎了她。"
            tom chill wry "接着你激活了冰霜符文，召唤出一根冰锥刺穿了巫师的心脏。"
            tom calm bunga "从那一刻起，我决定将我的一生都奉献给你。只要你愿意，我就会一直陪在你身边。"
            show tom smile -bunga
            if girl:
                show p_side f at pic
            else:
                show side_p f at pic
            mc "我明白了。其他孩子怎么样了？"
            if girl:
                hide p_side
            else:
                hide side_p
            tom frown apa "你忘了吗？大多数人都获救了，除了蒂莫西和卡桑德拉。他们没能活下来。"
            tom sad blow "格拉夫人因为儿子的死责怪你，尽管你当时也只是个孩子。"
            tom kzl -blow "是她自己的无能和安保不力才导致那些孩子丧生的。"
            tom capek frusta "血债应该由她来偿还。如果她试图说服你相信其他说法，那我不介意半夜去找那个女人然后——"
            show tom kzl -frusta
            if girl:
                show p_side f at pic
            else:
                show side_p f at pic
            mc "哇，哇！别激动，我发誓没事的。我只是在填补一些记忆中的空白而已。"
            if girl:
                hide p_side
            else:
                hide side_p
            tom sad apa "记忆空白？是因为酒精吗？"
            if girl:
                show p_side f at pic
            else:
                show side_p f at pic
            mc "只是零星片段。但我保证一切都在掌控之中。"
            if girl:
                hide p_side
            else:
                hide side_p
            tom talk sigh blow "如果你这么说的话。"
            tom sad -blow "不过，如果情况变糟了，请一定要告诉我。你知道我有多担心你。"
            if girl:
                show p_side f at pic
            else:
                show side_p f at pic
            mc "我会的。"
            if girl:
                hide p_side
            else:
                hide side_p
            tom amused cling "好吧。那么，如果就这些的话，我得继续我的搜索了。我们还有只猫要找呢。"
            if girl:
                show p_side f at pic
            else:
                show side_p f at pic
            mc "我以为你不喜欢猫。"
            $ tom_events.append("our_past")
            if girl:
                hide p_side
            else:
                hide side_p
            tom pfft blow "我确实不喜欢。我只是讨厌输，尤其是输给你。"
            if girl:
                show p_side m at pic
            else:
                show side_p m at pic
            mc "..."
            if girl:
                hide p_side
            else:
                hide side_p
        "{s}{color=#be6f1c}我们的过去{/color}{/s}" if "suspicion" not in fia_events:
            jump ars_talk
        "没什么。":
            hide pboy
            hide girl
    scene map_court with dissolve
    jump map_court
label up_court1:
    hide screen court_map
    scene court_tgh_crowd with dissolve
    if "mc_bangkit" in my_events:
        npc "莱纳尔，墨水短缺，伊格尼亚这次恐怕挺不过去了，伙计。"
        npc "这学期唯一的好消息是我刚听说所有纯血巫师目前都下落不明。"
    elif "beku" in quil_events:
        npc "我听说奎尔一个人就把整个湖面冻住了。"
        npc "天哪，英克威尔家族确实很强大。"
    elif "io4" in my_events:
        if "ice_rune" in my_events:
            npc "教堂最近挤满了从湖里生还的人。也许他们是来寻求救赎的。"
        else:
            npc "我很惊讶海德温女士没有为威廉校长举办祈祷会。"
            npc "也许她对他有什么怨恨吧。"
    elif "vamp_visit" in red_events:
        npc "你在玩什么把戏？"
        show side_p f at pic
        mc "啊？"
        hide side_p
        if "date2_done" in quil_events:
            npc "先是和奎尔订婚，现在又和塞恩建立了灵魂联结。"
            npc "你对灵魂联结没有丝毫尊重吗？"
        show side_p m at pic
        mc "那是……等等，我不需要向你解释！"
        hide side_p
    elif "bite_day" in red_events:
        npc "听说沃特克的手下要来这里训斥塞恩。"
        npc "我不太确定让更多吸血鬼进入我们学校是个好主意。"
    elif "bunga_bego" in buff_events:
        npc "你似乎对这整个花的事情并不感到困扰。真希望我也能像你一样。"
    elif "festies" in my_events:
        npc "塔图姆受伤很严重。我听说她失去了意识。"
        npc "对她做那种事的吸血鬼一定是个虐待狂之类的。"
    elif "ajax" in fia_events:
        npc "这一切不就是自虐吗？等等，这个词用得对吗？"
        npc "重点是，这整个阿贾克斯和阿什姆的事情几乎不是我们的问题。就好像我们这一届的那些富有的、老钱家族的孩子们对待他们的对手时不也是这样吗。"
    elif "day3" in quil_events:
        $ NPC = "???"
        npc "你听说吉妮芙被卖给沃特克当血袋的事了吗？"
        npc "我以为她家境很好，但结果是她父亲破产了。"
        npc "当然，她不会不战而降。我了解我的吉妮芙，在任何人想把她送给那些吸血鬼之前，她会把整个学校都烧了。"
    else:
        $ NPC = "女孩A"
        npc "比阿特丽斯真的在和赫尔曼约会吗？赫尔曼不是，你知道的……"
        $ NPC = "女孩B"
        npc "一个无名小卒？是啊，如果他们结婚，比阿特丽斯就得放弃她的家族姓氏了。糟糕的决定。"
        $ NPC = "???"
    scene map_court with dissolve
    jump map_court
label up_court2:
    hide screen court_map
    if "mc_bangkit" in my_events:
        npc "我听说莱纳尔的公民将被送往某个精灵领地。"
        npc "希望他们能在那里活下来。"
    elif "beku" in quil_events:
        npc "我真想杀了那个觉得冻结整个湖泊很有趣的蠢货！"
        
    elif "io4" in my_events:
        if "ice_rune" in my_events:
            npc "一些以前的老师从湖里冒了出来。"
            npc "我告诉你，他们比海德温女士还疯狂。崇拜一个巫师？认真的吗？"
        else:
            npc "我希望新校长不会这么快就来。"
            npc "你知道，一些自由是很不错的。"
    elif "vamp_visit" in red_events:
        if "date2_done" in quil_events:
            npc "那么这是否意味着你和奎尔的婚约只是一个幌子？"
            npc "因为我希望你有足够的头脑不去侮辱英克威尔家族，[povname]。"
        else:
            npc "我听说你和塞恩建立了灵魂联结。我想可能还有更糟的，我猜那个人也有他的优点。"
    elif "bite_day" in red_events:
        npc "伊格尼亚是少数几个与沃特克签订和平条约的国家之一，这就是为什么塞恩的小小咬人事件引起了如此大的轰动。"
        npc "如果他也是塔图姆遇袭事件的幕后黑手，那么我不会感到惊讶如果血骑士直接杀了他，但他应该没那么蠢吧？"
    elif "bunga_bego" in buff_events:
        npc "从这里看花朵很漂亮。我是说，我知道它们可能会吞噬我们所有人，但是……"
    elif "festies" in my_events:
        npc "如果你问我，塔图姆活该。那个婊子真的很会说。"
        
    elif "ajax" in fia_events:
        npc "阿什姆到底在想什么？野心也是有限度的。"
    elif "day3" in quil_events:
        if "fire1" not in active_quests and "fire1" not in completed_quests:
            scene court_tgh_crowd with dissolve
            npc "[povname]！正是我想见的混蛋！"
            show side_p f at pic
            mc "啊？"
            hide side_p
            npc "你听说了吗？我父母破产了！"
            npc "而我父亲，上帝保佑他，决定把我送到沃特克，把我的身体按加仑卖给那些沃特克的吸血蚊子。"
            npc "好吧，我说去他的！如果那些血骑士要来抓我，那我不会不战而降！"
            npc "但我确实需要你的帮助。酿造魔药并不是我的强项。我有材料，嗯……至少有最重要的一个，一颗火焰宝石。"
            npc "但我相信你和你的人脉可以找到我们需要的其他东西。"
            show side_p f at pic
            mc "我们？"
            hide side_p
            npc "哦，得了吧，[povname]！在你变成一个控制狂之前，我们曾经是那么好的朋友。"
            npc "我真的不想被送去当一辈子的血袋。拜托了？"
            show side_p f at pic
            mc "等等。首先，你为什么破产了？发生了什么？"
            hide side_p
            npc "呃，我想我父亲加入了一个邪教。"
            npc "你知道梅扎的欲望之屋吗？显然他一直在把我们家的钱都投到那里。"
            show side_p f at pic
            mc "（梅扎……）"
            hide side_p
            npc "我父亲说那是一个慈善机构，但对我来说这一切都很可疑。"
            show side_p s at pic
            mc "我会帮你的，但是……也许可以推迟放火，好吗？"
            mc "在你把整个学校烧成灰烬之前，我也许能帮上忙。"
            $ InvItem(*item_gem).pickup(1)
            hide side_p
            npc "……好吧，但还是给我做一个吧。我发誓我不会烧掉整个学校，大概只烧桥！"
            $ add_new_quest("fire1")
            # BERUBAH VITAL
            if "item_starter" not in known_recipes:
                $ known_recipes.append("item_starter")
            # BERUBAH VITAL
            python:
                if len(new_quests) > 0: #if we have new quests
                    for i in new_quests:
                        active_quests.insert(0, i) #add to top of the quest list
                    new_quests = [] #now reset the new quest list, since they all got added
            show screen completedtask("新任务！")
            npc "就通过你的手机把魔药发给我，我不想你送来的时候把手烧伤！"
            scene map_court with dissolve
        elif "fire1" in completed_quests and "api3" not in fia_events:
            npc "嘿，[povname]。结果我妈妈设法和一个有钱的老头子达成了交易，让血骑士不再找我麻烦。"
            npc "所以幸运的是不需要地狱之火。给，你可以拿回去了！"
            mc "哦，谢谢。"
            $ fia_events.append("api3")
            $ InvItem(*item_starter).pickup(1)
        else:
            npc "不知道合唱团会不会在里斯演出。天啊，我真想念那个地方！"
    else:
        scene court_tgh_crowd with dissolve
        $ NPC = "学生A"
        npc "海德温女士又要举行布道会了吗？"
        $ NPC = "学生B"
        npc "是啊，她以为真的会有人来听她讲话吗？"
        $ NPC = "???"
        scene map_court with dissolve
    jump map_court
label up_court3:
    hide screen court_map
    scene court_hi with dissolve
    $ NPC = "???"
    if "q1" in quil_events:
        $ NPC = "莱斯利"
        if "angel2" not in active_quests and "octo3" in completed_quests and "angel2" not in completed_quests:
            npc "另外，章鱼墨水失败了，但我听说天使鱼有一些类似塞壬的魔法特性。"
            npc "你能帮我弄些天使鱼吗？这里有些鱼饵可以帮你，因为我知道它们比较稀有。"
            $ InvItem(*item_bait).pickup(5)
            $ add_new_quest("angel2")
            python:
                if len(new_quests) > 0: #if we have new quests
                    for i in new_quests:
                        active_quests.insert(0, i) #add to top of the quest list
                    new_quests = [] #now reset the new quest list, since they all got added
            show screen completedtask("新任务！")
            npc "再次提醒，只需用你的手机把材料发给我就行。"
        elif "angel2" in active_quests:
            npc "拿到天使鱼了吗？用你的手机发给我就行。"

        elif "angel2" in completed_quests and "item_ink" not in known_recipes:
            npc "好吧，墨水项目失败了，我开始觉得我们的符文墨水根本就不是墨水。"
            if "item_ink" not in known_recipes:
                $ known_recipes.append("item_ink")
                npc "嗯，不过话说回来，如果你把章鱼墨水、天使鱼鳞片和符文墨水混合在一起，它们会创造出更强大、更持久的符文。"
                npc "缺点是它们会更快坏死。我差点失去一根手指，但现在我可以毫无问题地召唤蓝色火焰和台风了。"
                play sound "audio/success.mp3"
                "学会了新配方，高质量墨水！"   
        elif "mc_bangkit" in my_events:
            if "stag1" in completed_quests:
                npc "我有了突破性进展！"
                show side_p m at pic
                mc "啊？"
                hide side_p
                npc "墨水替代品！你可以用精灵的头发和天使鱼的血液创造出类似的效果！"
                npc "你不明白吗，伊格尼亚得救了！我迫不及待要向全世界分享我的发现！"
            else:
                npc "我担心墨水短缺。我觉得这真的是我们符文魔法的终结了。"
        elif "beku" in quil_events:
            npc "我就知道墨水有问题！"
            npc "我和湖边的幸存者谈过了，他们告诉我关于科尔和墨水的事！"
            npc "我简直不敢相信教会会做出如此残忍的事！"
            npc "我试图向媒体讲述我的故事，但没人相信我。"
        elif "io4" in my_events:
            if "ice_rune" in my_events:
                npc "我和一些湖边的幸存者聊过，听起来他们真的很享受和那个巫师在一起的时光。"
                npc "我有点明白为什么他们对唤醒他们的人那么生气了。"
            else:
                npc "不知道我们的下一任校长会是谁。希望这次不要是个对塞壬有癖好的人。"
        elif "vamp_visit" in red_events:
            npc "我很惊讶教会还没有来拜访我们。"
            npc "在这样的混乱中，你会以为他们至少会派人来澄清事实。"
        elif "bite_day" in red_events:
            npc "我还是觉得皮尔斯在撒谎。我是说，他不是对塞恩有很大的迷恋吗？"
            npc "也许这是那种\'如果我不能拥有他，那么谁也不能\'的情况，你懂吗？"
        elif "bunga_bego" in buff_events:
            npc "别被那些花影响了。在这种时候最好保持坚强。"
        elif "festies" in my_events:
            npc "现在塔图姆退出了，我猜菲亚将会在卡斯特里演唱。"
            npc "菲亚一定很高兴吧，是吗，[povname]？"
            show side_p f at pic
            mc "我不知道你在暗示什么。"
            hide side_p
            npc "当然你不知道。"
        elif "ajax" in fia_events:
            npc "不过，菲亚才是真正的坏蛋。她像对待狗一样干掉了阿贾克斯和阿什姆。"
        else:
            npc "哦，嗨[povname]。"
        if "octo3" not in active_quests and "octo3" not in completed_quests:
            npc "顺便说一下，我在考虑制作一种墨水替代品来缓解墨水短缺的问题。"
            npc "愿意帮我吗？我听说你是个很棒的渔夫。"
            npc "你能给我弄三只章鱼吗？哦，一拿到就通过你的手机立即送给我，这样它们还是新鲜的。"
            npc "再次感谢。"
            $ add_new_quest("octo3")
            python:
                if len(new_quests) > 0: #if we have new quests
                    for i in new_quests:
                        active_quests.insert(0, i) #add to top of the quest list
                    new_quests = [] #now reset the new quest list, since they all got added
            show screen completedtask("新任务！")
        elif "octo3" in active_quests and "octo3" not in completed_quests:
            npc "我会等着那些章鱼的。拿到后就通过手机发给我。"
            npc "触摸它们有点...恶心。"
        else:
            npc "总之，我现在很忙。待会儿再聊！"
        $ NPC = "???"
        scene map_court with dissolve
        jump map_court
    else:
        npc "哦嘿，[povname]。"
        show side_p a at pic
        mc "啊，嗨...呃..."
        hide side_p
        $ NPC = "莱斯利"
        npc "莱斯利？我们实际上所有课都在一起。"
        show side_p se at pic
        mc "对-对，总之，怎么了，伙计？"
        hide side_p
        npc "只是在思考。你有没有注意到最近获得符文墨水变得更困难了？"
        npc "不知道库存出了什么问题。"
        $ NPC = "???"
        scene map_court with dissolve
        jump map_court

#church
screen church_map():
    tag menu
    imagebutton:
        idle "images/maps/church/ex.png"
        hover "images/maps/church/ex.png"
        xpos 853 ypos 391
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("music", "MUSIC/MusMus-BGM-037.mp3"),Play ("test_one", "walk.mp3"), Jump("map_court")]
        focus_mask None
        mouse "search"
    if calendar.weekday == "Mon" or calendar.weekday == "Wed" or calendar.weekday == "Fri":
        if "q1" in quil_events:
            imagebutton:
                idle "images/maps/church/ch_quil.png"
                hover "images/maps/church/ch_quil.png"
                xpos 266 ypos 182
                hovered [ Play ("test_one", "type.wav")]
                action [Play ("test_one", "stroke.mp3"), Jump("church_quil")]
                focus_mask None
                mouse "search"
        imagebutton:
            idle "images/maps/church/2.png"
            hover "images/maps/church/2_hover.png"
            xpos 1078 ypos 658
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("preach2")]
            focus_mask None
            mouse "search"
        imagebutton:
            idle "images/maps/church/stand.png"
            hover "images/maps/church/stand_hover.png"
            xpos 1117 ypos 777
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("preach5")]
            focus_mask None
            mouse "search"
        imagebutton:
            idle "images/maps/church/ce.png"
            hover "images/maps/church/ce_hover.png"
            xpos 1760 ypos 256
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("preach3")]
            focus_mask None
            mouse "search"
    else:
        imagebutton:
            idle "images/maps/church/walk.png"
            hover "images/maps/church/walk_hover.png"
            xpos 256 ypos 217
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("preach4")]
            focus_mask None
            mouse "search"
        imagebutton:
            idle "images/maps/church/pray.png"
            hover "images/maps/church/pray_hover.png"
            xpos 905 ypos 772
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("preach6")]
            focus_mask None
            mouse "search"
    imagebutton:
        idle "images/maps/church/1.png"
        hover "images/maps/church/1_hover.png"
        xpos 1124 ypos 482
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("preach")]
        focus_mask None
        mouse "search"
label map_church:
    hide screen peta_all
    if calendar.day == 17 and calendar.month == '/05' and "q1" not in quil_events:
        jump quill_event1
    elif calendar.day == 18 and calendar.month == '/05' and "fia_pentas" not in my_events:
        jump fia_choir
    else:
        scene map_greja
        #play music "MUSIC/MusMus-BGM-117.mp3"
        call screen church_map
label church_quil:
    hide screen church_map
    scene church_atas with fade
    show quil skul datar at center with dissolve:
        yoffset 200
    if "pantai_day" in fia_events and "mc_bangkit" not in my_events:
        if "tun_talk" in quil_events and "date3_done" not in quil_events :
            jump quil_date3
        elif "date2_done" in quil_events and "date3_done" not in quil_events and bff.points >= 50:
            jump quil_date3
        else:
            pass
    else:
        pass
    if "mc_bangkit" in my_events and "quil_pisah" not in quil_events:
        quil laugh apa "哎呀，这不是我们的救世主[povname]吗。亲爱的，能抽空陪我一会儿吗？"
        show side_p se at pic
        mc "怎么了，奎尔？"
        hide side_p
        quil amused sigh "不会是坏事，我保证。可以说是一次回忆之旅。"
        

    elif "companion" in my_events:
        if "companion" in quil_events:
            quil laugh "你歪着头的样子真是可爱。怎么了，我的[povname]？"
        elif "tun_talk" in quil_events and "jajam" not in quil_events:
            $ quil_events.append("jajam")
            if "companion" in red_events:
                quil amused apa "你知道吗，塞恩问我我们是不是背着他偷情。"
                show side_p m at pic
                mc "什么？"
                hide side_p
                quil wry sigh "别担心，我向他保证整个订婚的事只是个幌子。"
                quil talk -sigh "需要什么吗，[povname]？"
            else:
                quil amused apa "你确定要单独和我在一起吗，[povname]？你的爱人可能会误会。"
                show side_p f at pic
                mc "哦，所以你听说了？"
                hide side_p
                quil laugh -apa "当然。我还告诉他了我们假订婚的事。不想让他担心。"
            if "naksir" in quil_events:
                quil panik sweat "你知道，有那么一两秒我以为我们之间有点什么，但是..."
                quil smile -sweat "没什么。"
                quil talk "不管怎样，恭喜你。我为你感到非常高兴，[povname]。"
        else:
            quil smile "需要什么吗，[povname]？"

    elif "gift1" not in quil_events:
        $ quil_events.append("gift1")
        quil laugh bunga "哦亲爱的！伸出你的手，我有礼物要给你！"
        show side_p f at pic
        mc "礼物？"
        hide side_p
        $ gold += 50
        play sound "ding.mp3"
        "奎尔给了你50枚金币。"
        show side_p f at pic
        mc "钱？"
        hide side_p
        quil amused sigh "为了补偿你的麻烦，亲爱的。我知道和我做朋友挺麻烦的。"
        quil laugh -sigh "但说实话，我不擅长送人东西，而且钱更实用，你不觉得吗？"
        show side_p a at pic
        mc "我感觉你是在用钱买我的友谊。"
        hide side_p
        quil ejek cling "有用吗？"
        quil datar -cling "话说回来，你来这里是为了什么？"
    elif "gift2" not in quil_events and bff.points >= 30:
        $ quil_events.append("gift2")
        quil laugh bunga "[povname]，正是我想见的人。伸出你的手，亲爱的！"
        $ gold += 200
        play sound "ding.mp3"
        "奎尔给了你200枚金币。"
        show side_p a at pic
        mc "又是钱？"
        hide side_p
        quil amused -bunga "我告诉过你我是个实际的人，亲爱的。现在，你来这里是为了什么？"
    elif "gift3" not in quil_events and bff.points >= 60:
        $ quil_events.append("gift3")
        quil laugh spark "哦，亲爱的。"
        show side_p f at pic
        mc "让我猜猜，又是钱？"
        hide side_p
        quil sly cling "这次不是。伸出你的手。"
        "你照做了，惊讶地发现奎尔这次给你的是一件真正的礼物。一面镜子。"
        $ InvItem(*item_mirror).pickup(1)
        $ NPC = "镜子"
        npc "哦，你看起来棒极了，今天有人告诉过你吗？"
        show side_p s at pic
        mc "一面会说话的镜子？！"
        hide side_p
        quil laugh bloom "只是迪特里希商店里的一件奇物。我想你可能会喜欢我这次用心挑选的礼物。"
        show side_p f at pic
        mc "你觉得我会喜欢一面会说话的手持镜子？"
        hide side_p
        show quil err sweat shock
        npc "当然你会喜欢。得到赞美是一种快乐，不是吗？虽然你可以处理一下那根杂乱的下巴胡子。"
        npc "不过很不明显，别担心。哦，但是那些鱼尾纹可能会随着时间加重。你应该保湿。有人告诉过你茶包对眼睛有好处吗？"
        $ NPC = "???"
        show side_p a at pic
        mc "...我有一部分想把这东西从窗户扔出去摔得粉碎。但我确实感谢你的努力，奎尔。"
        hide side_p
        "奎尔耸了耸肩，然后随意地说道..."
        quil hister sigh "我告诉过你，送礼物的艺术不是我的强项，亲爱的。"
        quil datar -sweat -sigh "话说回来，今天我能帮你什么忙？"
        $ NPC = "???"

    else:
        quil "寻求赦免，亲爱的？"
        show side_p f at pic
        mc "不应该是你在做这件事吗？"
        hide side_p
        quil "我开玩笑的。那么，是什么把你带到这个自以为是的地方？"
    show pboy at horzappear
    menu:
        "想一起出去玩吗？":
            hide pboy
            if "mc_bangkit" in my_events:
                if "quil_pisah" not in quil_events:
                    quil laugh blush bloom "我还以为你永远不会问呢！"
                    jump quil_parting
                elif "date3_done" in quil_events and "date4_done" not in quil_events and "date3_fail" not in quil_events:
                    quil smile "我还以为你永远不会问呢。实际上，我有些事想告诉你。"
                    show side_p a at pic
                    mc "我应该担心吗？"
                    hide side_p
                    quil flashy wink "嗯。这要看情况，不过先去换件衣服，然后在湖边见我，我有个惊喜！"
                    stop music
                    scene bg_black with w20
                    "还没等你抗议，奎尔就把你推到宿舍去换衣服。"
                    "然后你们两个一起前往湖边，奎尔在那里打开了一个新的传送门，不知道通向哪里。"
                    jump quil_date4
                else:
                    #berubah
                    $ datingplace = "Church"
                    #berubah
                    jump quil_date_check    
            else:
                quil flashy wink cling "哦，小[povname]渴望沐浴在我的光辉之下吗？"
                show side_p f at pic
                mc "我改变主意了。"
                hide side_p
                quil skul sulk frusta "等等！"
                quil amused sigh "哦，别走啊，我只是在开玩笑。那么，你想做什么？"
                show side_p se at pic
                mc "你比我更了解这个地方。"
                hide side_p
                quil laugh -sigh "嗯。好吧，我们可以做点什么。"
                scene bg_black with w20
                #berubah
                $ datingplace = "Church"
                #berubah
                jump quil_date_check
            
        "只是路过而已。":
            hide pboy
            quil amused apa "哦？"
            quil tantrum sigh "我还以为你要请我吃顿大餐呢。"
            quil smile -sigh "你的损失。"
    scene map_greja with fade
    $ NPC = "???"
    jump map_church
label fia_choir: #Kamis
    hide screen church_map
    play music "MUSIC/agnus.mp3"
    scene holy2 with dissolve
    $ my_events.append("fia_pentas")
    "一进入教堂，响亮的合唱音乐就迎面而来。"
    show croissant laugh bloom at center with dissolve:
        yoffset 500
    "在合唱团员中，你看到菲亚悄悄地向你挥手，当她在人群中看到你时露出了微笑。"
    "在这种场合看到她很有趣，你的家庭从来就不是特别虔诚的类型。"
    "但菲亚是个合唱团迷，所以她在这个世界里依然以某种方式唱歌是很合理的。"
    hide croissant with dissolve
    $ NPC = "塔图姆"
    show npc2 at pic
    npc "..."
    hide npc2
    "环顾四周，你还看到塔图姆也在合唱团里。她的眼睛看起来疲惫不堪，眼下有很重的黑眼圈。"
    stop music fadeout 2.0
    play sound "sound/effects/clap.mp3"
    show hedwin talk at center with dissolve:
        yoffset 200
    hed sad apa "...好了。大家唱得很棒，但是...塔图姆小姐，你感觉还好吗？今天你的音调严重走调了。"
    $ NPC = "塔图姆"
    show npc2 at pic
    npc "哦，对不起。最近有点累。"
    hide npc2
    hed konsul -apa "是这样吗？如果是这样的话，你介意让菲亚成为你的替补吗？"
    show npc2_2 at pic
    npc "什么？但我不需要替补！"
    hide npc2_2
    hed talk "嗯，你永远不知道会发生什么。我们下个月要在卡斯特里演出，我需要你保持最佳状态。"
    hed wry "但是科尔可能有其他安排，所以最好我们做好准备，让菲亚学习这个角色，以防你不能出席。"
    show npc2 at pic
    npc "就算我得爬着上台我也会去的。我绝不会错过在卡斯特里的独唱机会，这是世界上最重要的事！"
    hide npc2
    show hedwin frown at left with move
    "塔图姆扭头看向菲亚，开始怒目而视。"
    show croissant flinch kzl at right with dissolve:
        yoffset 500
    show npc2_2 at pic
    npc "你是对她用了菲尔拉魔法，还是贿赂了她？"
    hide npc2_2
    fia jijik frusta "什么？别自作多情了，你根本不值得我花时间和精力。"
    fia mock cling "我不需要菲尔拉魔法就能超越一个没有才华的、被宠坏的富家千金，她能进这所学校只是因为她爸爸的钱。"
    show npc2_2 at pic
    npc "你说什么？！"
    hide npc2_2
    hed sad frusta "姑娘们，姑娘们，请冷静！塔图姆，这只是一个预防措施。冷静下来！"
    hed tantang sigh "塔图姆，退后一步，喝点热茶。菲亚，请到前排中间来。"
    fia def annoyed -cling"咳咳。"
    play music "MUSIC/rest.mp3"
    hide hedwin with dissolve
    show croissant laugh bunga at center with move
    "菲亚开始唱她的独唱部分。她柔和的歌声充满了整个房间。你已经三年没听她唱歌了。"
    show croissant flinch sweat mmh apa
    "不知为何，这一刻太过动人。你开始流泪，菲亚明显注意到了，用口型问\'你还好吗？\'。"
    show croissant pity -sweat shock
    "你立即擦干眼泪，强颜欢笑。"
    show side_p s at pic
    mc "（振作点，你才是这里年长的那个。你不应该让妹妹担心。）"
    hide side_p
    show croissant blush laugh bloom
    "你微笑着点头，菲亚继续她的歌曲。"
    scene map_greja with fade
    $ NPC = "???"
    jump map_church

label preach:
    hide screen church_map
    scene gereja_crowd with dissolve
    show hedwin talk at center with dissolve:
        yoffset 200
    if "mingle" in fia_events:
        if "mc_bangkit" in my_events:
            hed wry "你本可以告诉我的，你知道吗？"
            show side_p he at pic 
            mc "啊？"
            hide side_p
            hed talk "你不是真正的[povname]。我的[povname]告诉我一切了。"
            hed konsul "来这里是为了检查我，以防我药物过量。"
            hed wry "我一直以为我们很亲近，我很高兴这种感觉不是单方面的。"
            show side_p s at pic
            mc "哦-哦。哦...对不起，海德温女士。"
            hide side_p
            hed konsul "没关系，从大局来看，我理解你和其他人为什么要保守这个秘密。"
            if not girl2:
                hed talk "不过，[povname]是个好孩子。我很感激你设法救了[dia2]。"
            else:
                hed talk "不过，[povname]是个好孩子。我很感激你设法救了[dia]。"
            hed wry "谢谢你。"
            hed evil "但是，恕我直言，请回到你来的地方，永远不要再回来。"
            hed wry sigh "我不认为这个世界已经准备好接受两个你。"
            show side_p w at pic
            mc "我会的，海德温女士，我会的。"
            hide side_p

        elif "beku" in quil_events:
            hed sad frusta "我简直不敢相信一个学生竟然把湖面给冻住了。他们到底为什么要做这种事？"
        elif "rampage" in fia_events:
            hed evil apa "你是来忏悔的吗？"
            show side_p s at pic
            mc "啊？" 
            hide side_p
            hed sad sigh "为你对波比和她弟弟犯下的罪行。"
            show side_p s at pic
            mc "哦，呃，我其实不信教。忏悔真的有用吗？"
            hide side_p
            hed tantang -sigh "也许没用。"
            hed sad "祈祷似乎也没什么帮助。在这种艰难时期，我很庆幸自己提前储备了一些致幻食品。"
            hed konsul "没有它们我想我可能撑不下去，你要来一个吗？"
            show side_p s at pic
            mc "不要。海德温女士，请不要这样。"
            hide side_p
            hed talk "你的损失。"
        elif "ice_rune" in my_events:
            hed sad "校长接下来几周都不在。"
            show side_p m at pic
            mc "几周？"
            hide side_p
            hed konsul "是的，出了些棘手的事。我是说，除了那些从水里冒出来的大批人群之外。"
            hed "在他缺席期间，他把学校交给我负责。"
            hed tantang "我已经不确定这意味着什么了。幸运的是，我有一整袋致幻食品来帮我应对。"
            show side_p s at pic
            mc "海德温女士，请不要这样。"
            hide side_p
            hed talk "别担心，小[povname]。我向你保证，每天一剂致幻食品就能驱走恶魔！"
        else:
            hed konsul "我已经联系了教会，他们现在让我负责。至少在找到合适的替代者之前是这样。"
            hed sad sigh "可怜的威廉大师，想不到溺水会成为他的死因。"

    elif "bite_day" in red_events:
        hed sad frusta "我知道你在为塞恩打掩护。哈啊...现在沃特克帝国也卷进来了。"
        show side_p f at pic
        mc "你知道塞恩会怎么样吗？"
        hide side_p
        hed mad sigh "不知道，但维尔科娃女士宣布说她收到了帝国的一封信。他们很快就会来拜访我们。"
        hed sad -sigh "我只希望孩子们不要牵扯进来。"
        show side_p s at pic
        mc "如果你一直这样宣布的话，他们可能会牵扯进来。"
        hide side_p
        hed evil "哦，亲爱的，除了你和其他几个人，没人听我说话。这就是疯狂的好处。"
        show side_p f at pic
        mc "我不会说是疯狂，只是...嗑药过度。"
        hide side_p
        hed konsul "就像你，或者说你曾经那样。我们曾经玩得很开心，不是吗？"
        hed talk "但我很高兴你清醒了，我恐怕对我来说已经太晚了。"
        hed smile "你知道吗，我曾经把我的腿当成啤酒瓶。一个小小的迪特里希还试图从我这里偷走那条腿。"
        show side_p he at pic
        mc "...一个小小的迪特里希？"
        hide side_p
        hed talk "是的，像浣熊一样的东西。我想是他召唤出来的生物之一。我确信他现在正在策划偷走我的四肢，那个小偷。"
        hed smile "他一直对所有金光闪闪的东西都很痴迷。"
        show side_p f at pic
        mc "哈哈，是啊。呃...海德温女士，我有个问题。你现在嗨到什么程度了？"
        hide side_p 
        hed evil "非常高，亲爱的，非常高。"
        
    elif "bunga_bego" in buff_events:
        if "candy1" in completed_quests:
            hed wry sigh "谢谢你，[povname]。"
            show side_p f at pic
            mc "啊？"
            hide side_p
            hed talk"谢谢你的糖果。"
            hed "你怎么知道我喜欢它们的？"
            show side_p f at pic
            mc "哦，我不知道。我只是按照奎尔和他朋友要求我做的去做。"
            hide side_p
            hed talk "啊，我明白了。奎尔是个可爱的孩子，不是吗？"
            hed wry "我记得他第一年的时候，因为一些男孩取笑他的妆容而哭泣。"
            hed smile "佩纳用过类似的眼影，我想奎尔一直都很崇拜这个年长的男人。"
            hed "我记得你和阿什姆追着他到教堂，然后开始戴眼影来让他感到更舒服。"
            show side_p f at pic
            mc "我们这么做了吗？"
            hide side_p
            hed wry "是的。至少我知道阿什姆是这么做的。"
            hed smile "他的紫色眼影相当引人注目。你的是非常淡的棕色。"
            hed wry "不过我猜你现在不再戴了。"
            hed "我知道塞恩也开始戴红色眼线来支持奎尔和他更张扬的倾向。"
            hed smile bunga "我很高兴你们三个在这里互相照顾。"
            if "item_truth" not in known_recipes:
                hed wry sigh "我更高兴的是，这种善意也延伸到了我身上。"
                hed -sigh "让我回报这份情谊吧。你知道怎么酿造真言药水吗？"
                hed talk "当你想要接近某人时，它们非常有用。来，我教你配方。"
                "学会了新配方，真言药水！"
                $ known_recipes.append("item_truth")
            hed wry sigh "如今，同志情谊很难得。你知道吗，我曾经也有过一群和你现在一样的朋友。"
            hed sad -sigh "虽然不幸的是，我们的友谊在死亡地带战争后戛然而止。"
            show side_p f at pic
            mc "伊瓦尔？"
            hide side_p
            hed wry "是的。但我们也可以说是发生了自己的分歧。"
            hed sad "琴是一个漂亮的金发女子，似乎吸引了伊瓦尔的目光。他会在她的梦中诱惑她，我不知道他说了什么，但这让她..."
            hed mad "...同情他。第二天，她屠杀了她的帐篷伙伴，希望减少我们的人数。我不得不将她击倒。"
            show side_p s at pic
            mc "我很抱歉。"
            hide side_p
            hed wry "没关系。老实说，我有点庆幸她以那种方式离开，因为第二天，伊瓦尔开始从我们所有的孔洞里长出花来。"
            hed evil "我之所以能活下来，是因为我疯狂到自残，显然伊瓦尔非常享受这场表演，以至于他完全停止了我身上的植物生长。"
            hed tantang "但我想，我向你分享这些并没有什么用，对吧？"
            hed talk"我现在要继续祈祷了。你应该回去上课了，[povname]。"
            


        else:
            show side_p f at pic
            mc "海德温女士。"
            hide side_p
            hed talk apa "哦，亲爱的，怎么了？"
            show side_p f at pic
            mc "你还好吗？你看起来有点心不在焉。"
            hide side_p 
            hed evil sigh "哦，我没事。只是在想着一百万种可以尝试杀死那些花的方法。"
            hed tantang -sigh "它们让我想起了那时候...我看到我的修女同伴们从每个洞里爆发出花朵。"
            hed wry "嗯。我在想当我找到美丽巫师时，该如何惩罚他？把他撕成碎片似乎太仁慈了。"


    elif "io_dream" in my_events and "talk_hen" not in my_events:
        "你听到海德温在祈祷时喃喃自语。"
        hed sad "我们的父辈和先祖的罪过。愿科尔在众神之墓中宽恕他们所有人。"
        show side_p f at pic
        mc "等等，能再重复一遍那句话吗？"
        hide side_p
        hed smile shock "哦，[povname]。今天我能为你做些什么？"
        show side_p f at pic
        mc "刚才那个祷告...众神之墓？"
        hide side_p
        $ my_events.append("talk_hen")
        hed talk -shock "哦是的，很久以前有一个所有神明诞生的地方。或者说，是所有非恶意巫师聚集的地方。"
        hed "你看，我们历史上的神明大多是巫师。这是大多数历史学家都试图抹去的事实。"
        hed smile "然而，我知道真相，不管凯普勒先生如何争辩。"
        show side_p he at pic
        mc "你知道那个墓在哪里吗？"
        hide side_p
        hed sad sigh "不，恐怕不知道。即使我知道，我也怀疑我能说出来。学者们说，任何发现其所在地的人都会被施魔法保持沉默。"
        show side_p he at pic
        mc "你是说你确实知道它在哪里，但你不能说？"
        hide side_p
        hed tantang -sigh "不，亲爱的，但我是说你试图找到它会浪费时间。"
        hed sad "信不信由你，我曾失去几个学生，他们也在寻找这个墓穴。有人称之为科尔的密室。"
        hed konsul "他们是虔诚的信徒。像你一样好奇。"
        hed "大多数人的心灵比其他人状态更差，认为科尔能治愈他们，驱除他们内心的恶魔。"
        hed frown "许多人确信她的领域就在学校下面。我可以保证我们的地下室里什么都没有，只有更多的木头、砖块和混凝土。"
        show side_p se at pic
        mc "如果你这么说的话。谢谢你，海德温女士。"
        hide side_p
        hed talk "如果你想了解更多，我大约一小时后有一场关于科尔的布道——"
        show hedwin sad
        show side_p w at pic
        mc "啊，不用了海德温女士，谢谢。"
        hide side_p

    elif "fia_pentas" in my_events:
        hed "菲亚真的很有才华。如果她能管住自己的尖刻舌头，她在合唱团里会更受欢迎。"
        hed smile "[povname]，艺术一定流淌在你们家族的血液里。我还记得你在学校节日上的舞蹈。"
        hed talk "太美了！"
        hed wry "除了那些锁链和有争议的服装，哈哈！"
    else:
        hed "啊，这不是[povname]·贝克吗。你想听我的布道吗？"
        if girl:
            show p_side f at pic
        else:
            show side_p f at pic
        mc "哦，啊...不行，要上课。"
        if girl:
            hide p_side
        else:
            hide side_p
        hed wry "我明白了。好吧，随时来，我们欢迎所有人！"
    $ NPC = "???"
    scene map_greja with dissolve
    jump map_church
label preach2:
    hide screen church_map
    scene gereja_crowd with dissolve
    $ NPC = "???"
    if "mc_bangkit" in my_events:
        npc "我正在为莱纳尔的人民祈祷。"
        npc "我是说，我会帮助他们撤离，但那需要实际行动。"
    elif "beku" in quil_events:
        npc "我现在喜欢从湖里偷一些冰。不知为何它从不融化。"
    elif "io4" in my_events:
        if "ice_rune" in my_events:
            npc "海德温女士关于学校下面的秘密区域说得对。"
            npc "我想知道她还有什么说得对的。"
        else:
            npc "我正在祈祷教会能找到威廉校长的遗体。"
            npc "他的家人应该得到安慰。"
    elif "vamp_visit" in red_events:
        npc "你知道吸血鬼崇拜一位名叫莉莉丝的神祇吗？"
        npc "据说她是有史以来第一位吸血鬼。"
        npc "后来的研究发现，她其实是一位纯血巫师，拥有操控血液的能力。"
        npc "吸血鬼们在1540年杀死了自己的神，但他们仍然有自己的教堂之类的地方\'崇拜\'沃特克皇帝。"
        npc "很有意思，对吧？"
    elif "bite_day" in red_events:
        npc "我在为塞恩祈祷，也许这样他就能意识到自己的错误。"
    elif "bunga_bego" in buff_events:
        npc "奎尔最近经常来这里看望海德温女士。"
        npc "这挺甜蜜的。"
    elif "ajax" in fia_events:
        npc "听说阿什姆并不是我们以为的那样，真遗憾。"
    else:
        npc "海德温女士在死亡地带战争中因符文坏死失去了所有肢体。"
        npc "教会因为她的服役而支付了她所有的假肢费用。"
        npc "我听说她年轻时曾是一股不可阻挡的力量。真希望能看到她全盛时期的样子。"
    scene map_greja with dissolve
    jump map_church
label preach3:
    $ NPC = "???"
    hide screen church_map
    if "mc_bangkit" in my_events:
        npc "不知为何，我最近感觉想要更接近科尔。"
        npc "你知道她大部分的日记内容都被删除了吗？"
        npc "让人不禁想知道教会在试图隐藏什么。"
    elif "beku" in quil_events:
        npc "我在想祈祷能否让湖水融化。"
    elif "io4" in my_events:
        if "ice_rune" in my_events:
            npc "他们说学校下面的区域是神圣的。"
            npc "我希望能以某种方式进入那里。"
        else:
            npc "别忘了为威廉校长祈祷，那个人为伊格尼亚做了很多。"
    elif "vamp_visit" in red_events:
        npc "有人说吸血鬼是恶魔，但我认为他们和其他人一样。"
        npc "都是在努力生活的人。"  
    elif "bite_day" in red_events:
        npc "有些白痴认为由于最近发生的种种糟糕事情，世界末日就要来临了。"
        npc "这只是普通的集体歇斯底里而已。"
    elif "truth1" not in active_quests and "truth1" not in completed_quests and "truth1" not in my_events:
        npc "嘿，你觉得海德温女士的布道是真实的还是纯粹的谎言？"
        $ my_events.append("truth1")
        $ my_events.append("truth")
        show pboy at horzappear
        menu:
            "真实。":
                hide pboy
                npc "哼。天真的小鬼。"
            "谎言。":
                hide pboy
                npc "看来你也这么认为。"
                npc "你能弄到真言药剂并在她身上试试吗？我甚至可以给你预付款。"
                $ gold += 100
                play sound "ding.mp3"
                "获得100金币。"
                show side_p f at pic
                mc "哇，为什么？"
                hide side_p
                npc "就说我对她有些个人恩怨吧，因为她从死亡地带逃脱并存活了下来。"
                $ add_new_quest("truth1")
                python:
                    if len(new_quests) > 0: #if we have new quests
                        for i in new_quests:
                            active_quests.insert(0, i) #add to top of the quest list
                        new_quests = [] #now reset the new quest list, since they all got added
                show screen completedtask("新任务！")
                npc "如果你不知道如何制作真言药剂，可以在戈莫拉获得配方。"
                npc "问问尼娜，她会帮你搞定的。"
            "我不在乎。":
                hide pboy
                npc "哼。现在的孩子们。"
        
    else:
        npc "你知道科尔本人创立了这所学校，而她的住所就在湖底某处吗？"
        npc "我真希望能看到它。"

    jump map_church
label preach4:
    $ NPC = "???"
    hide screen church_map
    if "mc_bangkit" in my_events:
        npc "我在为伊格尼亚祈祷。我有种预感，莱纳尔发生的事情可能会在这里重演。"
        
    elif "beku" in quil_events:
        npc "我认为有人冻结了湖面是件好事，太多邪恶潜伏在湖底。"
    elif "io4" in my_events:
        if "ice_rune" in my_events:
            npc "我告诉你，教会在隐藏什么！"
            npc "你和那些从湖里逃生的人谈过吗？他们说教会把科尔和伊欧关在下面好几年。"
            npc "我...如果这是真的怎么办？"
        else:
            npc "威廉校长曾经救过我的命。他杀死了一个试图活剥我妈妈的巫师。"
            npc "我想我从未为此感谢过他。"
    elif "vamp_visit" in red_events:
        npc "邪血族来的时候我正在房间里。"
        npc "他们的身影挡住了我整个窗户，我还以为世界末日到了，哈哈！"
    elif "bite_day" in red_events:
        npc "有些人会咬他们的伴侣作为一种亲昵的表现。也许塞恩和皮尔斯也是这样。"
        npc "我就是无法把塞恩想象成暴力类型。"
    elif "bunga_bego" in buff_events:
        npc "这些花真让人感觉像是世界末日，不是吗？"
        npc "希望不是，但还是..."
    elif "festies" in my_events:
        npc "看来菲亚把塔图姆打倒了。"
        show side_p f at pic
        mc "不是她干的。"
        hide side_p
        npc "哦，不是直接动手，但她不是和某个吸血鬼很亲密吗？"
    elif "ajax" in fia_events:
        npc "所有关于阿什姆和阿贾克斯的谈论都让我感到无聊，但塔图姆对菲亚，现在这才有意思。"
        npc "等不及看他们决斗了。"
    else:
        npc "每年冬天我都会去死亡地带给那里的植物浇水。"
        npc "我知道它们已经不是人类了，我的行为也毫无意义，但还是..."
    jump map_church
label preach5:
    $ NPC = "???"
    hide screen church_map
    scene gereja_crowd with dissolve
    if "bite_day" in red_events:
        npc "吸血鬼在伊格尼亚根本没有立足之地。"
    elif "bunga_bego" in buff_events:
        npc "花儿来了。我简直不敢相信它们来了！"
    else:
        npc "狼人没有神。不过，我猜只有我们的土地和吸血鬼才有什么神明。" 
    
    scene map_greja with dissolve
    jump map_church

label preach6:
    hide screen church_map
    $ NPC = "???"
    scene gereja_crowd with dissolve
    
    if "cd1" in completed_quests:
        npc "...丽莎那个该死的婊子向我的未婚妻揭发了我！"
        npc "我一定要报复她！"
    elif "cd1" in active_quests:
        npc "你拿到了吗？"
        if check_inv_for(cd_items):
            python:
                InvItem(*item_cd).toss(1)
                active_quests.remove("cd1")
                completed_quests.insert(0, "cd1")
            show screen completedtask("任务完成！")
            npc "谢了兄弟，你真是救了我一命！"
            npc "按照约定，这里有一瓶真相药水给你，如果你需要审问某人或者怀疑你的伴侣出轨时可能会派上用场。我，呃——"
            npc "不过我猜我说这话有点讽刺，是吧？"
            $ InvItem(*item_truth).pickup(1)
        else:
            show side_p f at pic
            mc "还没有。"
            hide side_p
    elif "iv_dream2" in my_events and "cd1" not in active_quests and "cd1" not in completed_quests:
        if girl:
            npc "嘿，[povname]，你是个女孩，对吧？"
            if not girl2:
                npc "或者至少看起来像个女孩。"
                show side_p f at pic
                mc "有点冒犯，但行吧？"
                hide side_p
            npc "我有个请求。你能帮我从丽莎那里拿回我的内裤吗？她通常在宿舍附近晃悠。"    
            npc "长话短说，我们有过一段风流韵事，但我猜她认为那不止如此。我把内裤落在她房间里了，现在她把它当人质扣下了。"
            npc "如果我的未婚妻发现了，我就完蛋了。"
            npc "她一直威胁要告诉我未婚妻我们的事情。我真的，真的不能让这种事发生。你能帮帮忙吗？"
        else:
            if girl2:
                npc "嘿，[povname]，你是个女孩，对吧？"
            else:
                npc "嘿，你有个姐妹，对吧？"
            npc "我有个请求。你能帮我从丽莎那里拿回我的内裤吗？她通常在宿舍附近晃悠。"    
            npc "长话短说，我们有过一段风流韵事，但我猜她认为那不止如此。我把内裤落在她房间里了，现在她把它当人质扣下了。"
            npc "如果我的未婚妻发现了，我就完蛋了。"
            npc "她一直威胁要告诉我未婚妻我们的事情。我真的，真的不能让这种事发生。你能帮帮忙吗？"
        if girl2:
            npc "也许可以和她女人对女人地谈谈？"
        else:
            npc "只要让她冷静下来，把我的内裤拿回来就行。我一定会用真相药剂或无敌药水来报答你。你需要哪个都行。"
        $ add_new_quest("cd1")
        python:
            if len(new_quests) > 0: #if we have new quests
                for i in new_quests:
                    active_quests.insert(0, i) #add to top of the quest list
                new_quests = [] #now reset the new quest list, since they all got added
        show screen completedtask("新任务！")
    else:
        if "mc_bangkit" in my_events:
            npc "我很害怕。如果莱纳尔发生的事情在这里也发生了怎么办？"
            
        elif "beku" in quil_events:
            npc "我在想，冻结湖面的人能不能用同样的符文对付伊瓦尔的花？"
            npc "也许冻结能杀死它们。"
        elif "io4" in my_events:
            if "ice_rune" in my_events:
                npc "我是伊欧救的人之一...为什么，为什么我会醒来？"
            else:
                npc "威廉校长是个真汉子。"
                npc "你知道吗，他曾经一个人杀死了十个巫师？简直是个野兽。"
                npc "我会想念这个人的。"
        elif "vamp_visit" in red_events:
            npc "邪血者吓不到我！但是血骑士，天哪！"
            npc "他们本身就是杀戮机器！"
        elif "bite_day" in red_events:
            npc "哦，科尔女神，您抛弃我们了吗？"
        else:
            npc "哦，科尔女神，愿您洗清我的罪孽。"
    scene map_greja with dissolve
    jump map_church


#Garden
screen garden_map():
    tag menu
    imagebutton:
        idle "images/maps/garden/ex.png"
        hover "images/maps/garden/ex.png"
        xpos 1405 ypos 139
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("world_map")]
        focus_mask None
        mouse "search"
    if calendar.weekday == "Mon" or calendar.weekday == "Wed" or calendar.weekday == "Fri":
        if "q1" in quil_events and calendar.day != 19 and calendar.day != 31:
            imagebutton:
                idle "images/maps/garden/redo.png"
                hover "images/maps/garden/redo.png"
                xpos 378 ypos 679
                hovered [ Play ("test_one", "type.wav")]
                action [Play ("test_one", "stroke.mp3"), Jump("garden_red")]
                focus_mask None
                mouse "search"
                
        imagebutton:
            idle "images/maps/garden/1.png"
            hover "images/maps/garden/1_hover.png"
            xpos 218 ypos 538
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("garden_1")]
            focus_mask None
            mouse "search"
        imagebutton:
            idle "images/maps/garden/2.png"
            hover "images/maps/garden/2_hover.png"
            xpos 1237 ypos 368
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("garden_2")]
            focus_mask None
            mouse "search"
    else:
        
        imagebutton:
            idle "images/maps/garden/lonely.png"
            hover "images/maps/garden/lonely_hover.png"
            xpos 1101 ypos 851
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("garden_1")]
            focus_mask None
            mouse "search"
        imagebutton:
            idle "images/maps/garden/3.png"
            hover "images/maps/garden/3_hover.png"
            xpos 1344 ypos 572
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("garden_3")]
            focus_mask None
            mouse "search"
    imagebutton:
        idle "images/maps/garden/4.png"
        hover "images/maps/garden/4_hover.png"
        xpos 556 ypos 660
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("garden_4")]
        focus_mask None
        mouse "search"


label map_garden:
    hide screen peta_all
    if "bunga_bego" in buff_events:
        scene rose_no_panic with dissolve
        "学生们聚集在花园周围，拍摄花墙的照片。"
        $ NPC = "???"
        npc "你觉得这堵墙会枯萎吗？如果它蔓延开来怎么办？"
        npc "老师们不会让那种事发生的...对吧？"
        if "bunga_bego" in buff_events:
            if "beku" in quil_events:
                scene map_infected_f with dissolve
            else:
                scene map_infected with dissolve    
        else:
            if "beku" in quil_events:
                scene map_frozen with dissolve
            else:
                scene map_all with dissolve
        jump world_map
    else:
        scene map_garden
        #play music "MUSIC/MusMus-BGM-116.mp3"
        call screen garden_map
label garden_red:
    hide screen garden_map
    scene tmn_ujung with dissolve
    show red point cowo at center with dissolve:
        yoffset 330
    if "drained" in fia_events and "io0" not in my_events:
        show side_p m at pic
        mc "塞恩！"
        hide side_p
        show red sad sweat shock at center with dissolve:
            yoffset 330
        "在你能抓住他之前，塞恩跑掉了。"
        hide red with dissolve
        "你花了一整天试图抓住他，但都是徒劳。"
        #scene bg_black with w33
        play music "MUSIC/MusMus-BGM-082.mp3"
        scene lor_mlm with w33
        jump ur_room
    elif "vamp_visit" in red_events and "date_cekup" not in red_events:
        jump red_cekup
    red "哦嘿，[povname]！"
    if "mc_bangkit" in my_events and "red_pisah" not in red_events:
        red "有空吗？我有些话想说。"
    else:
        if mrh.points > 20 and "gift1" not in red_events:
            red grin apa "嘿，[povname]，需要任何魔药材料吗？"
            red datar -apa "我从课上多带了一些魔法粉末，给你！"
            $ InvItem(*item_blue).pickup(1)
            show side_p se at pic
            $ red_events.append("gift1")
            mc "哦，谢谢你，塞恩！"
            hide side_p
            red "别客气！话说，想一起出去玩吗？"
        elif mrh.points >= 50 and "gift2" not in red_events:
            red ew sweat apa "嘿，[povname]，你有没有想过我们的灰烬是从哪里来的？"
            show side_p f at pic
            mc "啊？"
            hide side_p
            $ InvItem(*item_ash).pickup(1)
            red perih sigh "骨灰。我是说，它们是真正的\'人类\'遗骸，所以一定是有人捐赠的，对吧？"
            red ngeles -sigh "除非他们真的活活烧死人..."
            red ew frusta "不，不，那又是我的侵入性思维在作祟了。"
            red wry -sweat -frusta "总之，给你，这是我从魔药课上多拿的一些骨灰。你以后可能会用到。"
            show side_p he at pic
            mc "...谢谢？"
            show side_p s
            mc "（该死，这些灰烬到底是从哪里来的？）"
            hide side_p
            red datar "别客气！话说，想一起出去玩吗？"
            $ red_events.append("gift2")
        elif mrh.points >= 70 and "gift3" not in red_events:
            red cowo blush bunga "嘿，[povname]，猜猜怎么着？"
            red grin "看来我和菲亚一起学习终于有回报了！"
            $ InvItem(*item_boner).pickup(1)
            red amused cling "我自己制作了一些高质量的\'欲望消除剂\'！耶！"
            show side_p se at pic
            $ red_events.append("gift3")
            mc "那很棒，塞恩，但是等等。你怎么知道它是高质量的？"
            hide side_p
            red mock cling "我们当然测试过了！不是在我自己身上，因为我可不是受虐狂，而是在...呃，受试者身上。"
            show side_p he at pic
            mc "受试者？"
            hide side_p
            red awkward sweat sigh "你最好还是不要知道。"
            show side_p w at pic
            mc "明白了。"
            hide side_p
            red happy -sweat -sigh "总之，我多做了一些，给你。也许你想让某人欲求不满或什么的。"
            red datar "希望你玩得开心！话说，你有空吗？想一起出去玩吗？"
        else:
            red datar "想一起出去玩吗？"
    show pboy at horzappear
    menu:
        "和塞恩一起出去玩？":
            hide pboy
            red cowo blush "太好了！"
            if "mc_bangkit" in my_events and "red_pisah" not in red_events:
                jump red_parting
            else:
                $ datingplace = "Garden"
                red datar -blush "我知道一个好地方！"
            jump red_date_check
        "不了。":
            hide pboy
            show side_p f at pic
            mc "也许改天吧。"
            hide side_p
            scene map_garden with dissolve
    jump map_garden    
label garden_1:
    hide screen garden_map
    scene tmn_ujung with dissolve
    $ NPC = "???"
    if "mc_bangkit" in my_events:
        npc "我知道这听起来很疯狂，但我发誓在莱纳尔爆炸后看到一群飞过的花。"
        npc "不知道那是什么。"
            
    elif "beku" in quil_events:
        npc "你应该在湖面上滑冰，现在那里真的很平滑。"
    elif "io4" in my_events:
        if "ice_rune" in my_events:
            npc "科尔啊，为什么我会醒来...伊欧...伊欧。"
        else:
            npc "我简直不敢相信校长死了……为什么？"
            
    elif "vamp_visit" in red_events:
        npc "那些该死的邪血族真的对花园造成了很大损害。"
        npc "他们的翅膀几乎把所有的花都毁了。"
    elif "bite_day" in red_events:
        npc "我讨厌他们新实施的宵禁。看来情况只会变得更糟了。唉。"
    elif "ajax" in fia_events:
        npc "不管阿什姆施加了什么诅咒，阿贾克斯都不应该那样报复。"
        npc "天啊，我只想安安静静地吃个早餐。"
    else:
        npc "哦，嘿。"
    if "day3" in quil_events:
        if "fish2" in active_quests:
            npc "顺便说一下，如果你抓到了那些小丑鱼，就通过你的手机发给我吧。这样不那么黏糊糊的。"
        elif "fish2" not in active_quests and "fish2" not in completed_quests:
            npc "嘿[povname]，你会钓鱼，对吧？"
            show side_p f at pic
            mc "当然，呃……"
            hide side_p
            $ NPC = "马丁"
            npc "我是马丁。魔药课上的那个？"
            npc "听着，你能帮我弄些魔药课的材料吗？"
            npc "我需要两条小丑鱼。它们超级难抓。我会给你5个鱼饵作为开始。"
            show side_p f at pic
            mc "好的，我会帮你的。"
            hide side_p
            npc "谢谢。完成后就通过你的手机发给我。"
            $ NPC = "???"
            $ InvItem(*item_bait).pickup(5)
            $ add_new_quest("fish2")
            python:
                if len(new_quests) > 0: #if we have new quests
                    for i in new_quests:
                        active_quests.insert(0, i) #add to top of the quest list
                    new_quests = [] #now reset the new quest list, since they all got added
            show screen completedtask("新任务！")
        else:
            npc "需要什么吗？"
    elif calendar.day == 15 and calendar.month == '/05':
        npc "我希望水母季节能快点开始。"
        if girl:
            show p_side f at pic
        else:
            show side_p f at pic
        mc "水母？"
        if girl:
            hide p_side
        else:
            hide side_p
        npc "我就是喜欢它们从海洋中飞出然后爆炸成星星的样子！"
        npc "有人说这是人鱼与他们心爱的水手联系的方式。也有人说这是海巫婆试图引诱受害者。"
        npc "谁知道呢？不管怎样，我觉得这很美。"
        if "jelly" not in topics:
            $ topics.append("jelly")
            play sound "audio/success.mp3"
            "新话题：{color=#FF1500}水母。{/color}"

    else:
        npc "我的家乡在死亡地带。我还记得伊瓦尔只是打了个响指就杀死了我整个镇子的人。"
        npc "我只是因为是个女孩，而且有像他一样的金发才幸运地活了下来。我知道那是他喜欢的类型，我是说金发。"
        npc "死亡地带现在只剩下无尽的花田。晚上，你能听到它们痛苦的哭喊声。"
    scene map_garden with dissolve
    jump map_garden
label garden_2:
    hide screen garden_map
    scene tmn_ujung with dissolve
    $ NPC = "???"
    if "mc_bangkit" in my_events:
        npc "你看到莱纳尔的爆炸了吗！？天哪，简直无法想象那座岛上的情况！"
        
            
    elif "beku" in quil_events:
        npc "我觉得我们可以向莱纳尔的孩子们收费，让他们在我们的湖上滑冰。"
        npc "还是说这太贪心了？"
    elif "io4" in my_events:
        if "ice_rune" in my_events:
            npc "你听说了吗？似乎莱顿神父曾经有过灵魂伴侣，但她多年前跳进湖里自杀了。"
            npc "现在她回来了，但莱顿无法原谅她\'试图提前结束他们的羁绊\'。"
            npc "更糟糕的是，那姑娘当时还怀着孕！说真的，这太疯狂了！"
        else:
            npc "校长不可能真的死了，对吧？我是说，以这么平凡的方式死去……"
            npc "这根本不可能！"
    elif "vamp_visit" in red_events:
        npc "我还是觉得应该开除塞恩。仅仅因为他有灵魂伴侣并不意味着他就安全！"
        
    elif "bite_day" in red_events:
        npc "如果塞恩真的是这些袭击事件的幕后黑手，那他不是早就该被开除了吗？"
        npc "如果到现在还没有足够的证据开除他，皮尔斯肯定是在撒谎。"
    elif "ajax" in fia_events:
        npc "阿贾克斯和阿什姆现在肯定没在说话。打赌阿贾克斯现在对他怒火中烧。"
    elif "day3" in quil_events:
        "如果你有太多不知道该怎么处理的鱼，就把它们给猫吧。"
        "戈莫拉的猫都喜欢鱼。"
        "如果你有乌龟，也可以给塞恩。我听说他喜欢喝它们的血。"
        
    elif calendar.day == 15 and calendar.month == '/05':
        "你看到一些学生在打量你，但他们很快就移开了视线。"
        show side_p se at pic
        mc "（在这个世界里我很受欢迎吗？那倒是个不错的变化。）"
        hide side_p
    elif "sucker3" in active_quests:
        npc "一只猫？我想我在购物区看到过一只，怎么了？"
    else:
        npc "真希望我们平日也能进入戈莫拉。"
    scene map_garden with dissolve
    jump map_garden
label garden_3:
    hide screen garden_map
    scene tmn_ujung with dissolve
    if "mc_bangkit" in my_events:
        npc "我刚刚还在考虑在莱纳尔开一家店呢。"
        npc "现在看来已经没有意义了。"
            
    elif "beku" in quil_events:
        npc "哈……我真的很想在湖上玩。滑冰太有趣了！"
    elif "io4" in my_events:
        if "ice_rune" in my_events:
            npc "为什么我要醒来，我在那里很快乐。伊欧……"
        else:
            npc "听我说，我觉得校长还活着，他只是在躲着我们！"
            npc "我是说，如果没有尸体，那他肯定还活着！"
    elif "vamp_visit" in red_events:
        npc "很抱歉你必须以这种方式建立联系，[povname]。"
        npc "我是说，如果是我的话，我会直接把塞恩交给帝国。但我猜你太善良了，做不到这一点。"
    elif "bite_day" in red_events:
        npc "我想知道血的味道是什么样的。"
    elif "day3" in quil_events and calendar.month == '/05':
        $ NPC = "???"
        npc "我听说血骑士正试图夺回西奥德。"
        npc "西奥德很像伊格尼亚，是一个主要由人类居住的中立领土。"
        npc "这让我担心吸血鬼也会试图占领我们的土地。"
        npc "我不知道为什么我生来是人类，而不是巫师或至少是狼人。似乎这两个种族没有太多天敌。"
    elif "sucker3" in active_quests:
        npc "嗯，一只猫？为什么这里会有猫？"
    else:
        npc "你认为外面有多少巫师，当她们都消失后会发生什么？"
        npc "我们会失业吗？"
    scene map_garden with dissolve
    jump map_garden
label garden_4:
    hide screen garden_map
    scene tmn_ujung with dissolve
    if "vamp_visit" in red_events:
        npc "你知道血骑士已经征服了多少个国家吗？"
        npc "伊格尼亚之所以能免于他们的掌控，唯一的原因是我们在不同的大陆上！"
    elif "bite_day" in red_events:
        npc "他们说灵魂联结能驯服内心的野兽。如果塞恩在寻找一个伴侣来抑制他的渴望，我很乐意效劳。"
        npc "我有一部分精灵血统，所以我知道我的血对大多数吸血鬼来说是一种美味。"
    elif "day3" in quil_events and calendar.month == '/05':
        $ NPC = "???"
        npc "你知道沃特克的吸血鬼正在尝试制造一种新型飞行器吗？不是靠符文墨水运行，而是靠血液？"
        npc "显然，一些吸血鬼喝了足够多的巫师血液，开始发展出自己的能力。"
        npc "如果你问我的话，这很不祥！"
    else:
        npc "他们说梅莉酒吧里有一个非常漂亮的女酒保。"
        npc "我迫不及待想在周末去拜访她，亲眼看看。"
    scene map_garden with dissolve
    jump map_garden

#Tempur
screen tempur_map():
    tag menu

    if calendar.weekday == "Mon" or calendar.weekday == "Wed" or calendar.weekday == "Fri":
        imagebutton:
            idle "images/maps/tempur/1.png"
            hover "images/maps/tempur/1_hover.png"
            xpos 1243 ypos 480
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("tempur_1")]
            focus_mask None
            mouse "search"
        imagebutton:
            idle "images/maps/tempur/2.png"
            hover "images/maps/tempur/2_hover.png"
            xpos 559 ypos 537
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("tempur_2")]
            focus_mask None
            mouse "search"
        imagebutton:
            idle "images/maps/tempur/3.png"
            hover "images/maps/tempur/3_hover.png"
            xpos 783 ypos 315
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("tempur_3")]
            focus_mask None
            mouse "search"
    else:
        if "q1" in quil_events:
            imagebutton:
                idle "images/maps/tempur/t_quil.png"
                hover "images/maps/tempur/t_quil.png"
                xpos 1324 ypos 324
                hovered [ Play ("test_one", "type.wav")]
                action [Play ("test_one", "stroke.mp3"), Jump("tempur_quil")]
                focus_mask None
                mouse "search"
        imagebutton:
            idle "images/maps/tempur/a.png"
            hover "images/maps/tempur/a_hover.png"
            xpos 1211 ypos 293
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("tempur_2")]
            focus_mask None
            mouse "search"
        imagebutton:
            idle "images/maps/tempur/b.png"
            hover "images/maps/tempur/b_hover.png"
            xpos 398 ypos 451
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("tempur_3")]
            focus_mask None
            mouse "search"
    imagebutton:
        idle "images/maps/tempur/ex.png"
        hover "images/maps/tempur/ex.png"
        xpos 1461 ypos 276
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("world_map")]
        focus_mask None
        mouse "search"

label map_tempur:
    hide screen peta_all
    scene map_tempur
    #play music "MUSIC/MusMus-BGM-007.mp3"
    call screen tempur_map
label tempur_quil:
    hide screen church_map
    scene practice with dissolve
    show quil skul datar at center with dissolve:
        yoffset 200
    if "pantai_day" in fia_events and "mc_bangkit" not in my_events:
        if "tun_talk" in quil_events and "date3_done" not in quil_events:
            jump quil_date3
        elif "date2_done" in quil_events and "date3_done" not in quil_events and bff.points >= 50:
            jump quil_date3
        else:
            pass
    else:
        pass
    if "mc_bangkit" in my_events and "quil_pisah" not in quil_events:
        quil laugh apa "哎呀，这不是我们的救世主[povname]吗。亲爱的，能抽空陪我一会儿吗？"
        show side_p se at pic
        mc "怎么了，奎尔？"
        hide side_p
        quil amused sigh "不会是坏事，我保证。可以说是一次回忆之旅。"
        

    elif "companion" in my_events:
        if "companion" in quil_events:
            quil laugh "你歪着头的样子真是可爱。怎么了，我的[povname]？"
        elif "tun_talk" in quil_events and "jajam" not in quil_events:
            $ quil_events.append("jajam")
            if "companion" in red_events:
                quil amused apa "你知道吗，塞恩问我我们是不是背着他偷情。"
                show side_p m at pic
                mc "什么？"
                hide side_p
                quil wry sigh "别担心，我向他保证整个订婚的事只是个幌子。"
                quil talk -sigh "需要什么吗，[povname]？"
            else:
                quil amused apa "你确定要单独和我在一起吗，[povname]？你的爱人可能会误会。"
                show side_p f at pic
                mc "哦，所以你听说了？"
                hide side_p
                quil laugh -apa "当然。我还告诉他了我们假订婚的事。不想让他担心。"
            if "naksir" in quil_events:
                quil panik sweat "你知道，有那么一两秒我以为我们之间有点什么，但是..."
                quil smile -sweat "没什么。"
                quil talk"不管怎样，恭喜你。我为你感到非常高兴，[povname]。"
        else:
            quil smile "需要什么吗，[povname]？"

    elif "gift1" not in quil_events:
        $ quil_events.append("gift1")
        quil laugh bunga "哦，亲爱的！伸出你的手，我有礼物要送给你！"
        show side_p f at pic
        mc "礼物？"
        hide side_p
        $ gold += 50
        play sound "ding.mp3"
        "奎尔给了你50枚金币。"
        show side_p f at pic
        mc "钱？"
        hide side_p
        quil amused sigh "为了补偿你的麻烦，亲爱的。我知道和我做朋友挺麻烦的。"
        quil laugh -sigh "但说实话，我不擅长送人东西，而且钱更实用，你不觉得吗？"
        show side_p a at pic
        mc "我感觉你是在用钱买我的友谊。"
        hide side_p
        quil ejek cling "有用吗？"
        quil datar -cling "话说回来，你来这里是为了什么？"
    elif "gift2" not in quil_events and bff.points >= 30:
        $ quil_events.append("gift2")
        quil laugh bunga "[povname]，正是我想见的人。伸出你的手，亲爱的！"
        $ gold += 200
        play sound "ding.mp3"
        "奎尔给了你200枚金币。"
        show side_p a at pic
        mc "又是钱？"
        hide side_p
        quil amused -bunga "我告诉过你我是个实际的人，亲爱的。现在，你来这里是为了什么？"
    elif "gift3" not in quil_events and bff.points >= 60:
        $ quil_events.append("gift3")
        quil laugh spark"哦，亲爱的。"
        show side_p f at pic
        mc "让我猜猜，又是钱？"
        hide side_p
        quil sly cling "这次不是。伸出你的手。"
        "你照做了，惊讶地发现奎尔这次给你的是一件真正的礼物。一面镜子。"
        $ InvItem(*item_mirror).pickup(1)
        $ NPC = "镜子"
        npc "哦，你看起来棒极了，今天有人告诉过你吗？"
        show side_p s at pic
        mc "一面会说话的镜子？！"
        hide side_p
        quil laugh bloom"只是迪特里希商店里的一件奇物。我想你可能会喜欢，这次我在选礼物时多花了点心思。"
        show side_p f at pic
        mc "你觉得我会喜欢一面会说话的手持镜子？"
        hide side_p
        show quil err sweat shock
        npc "当然你会喜欢。得到赞美是一种快乐，不是吗？虽然你可以处理一下那根杂乱的下巴胡子。"
        npc "不过很低调，别担心。哦，但那些鱼尾纹可能会随时间加重。你应该多保湿。有人告诉过你茶包对眼睛有好处吗？"
        $ NPC = "???"
        show side_p a at pic
        mc "...我有一部分想把这东西从窗户扔出去摔得粉碎。但我确实感谢你的努力，奎尔。"
        hide side_p
        "奎尔随意地耸了耸肩。"
        quil hister sigh "我告诉过你，送礼物的艺术不是我的强项，亲爱的。"
        quil datar -sweat -sigh "话说回来，今天我能帮你什么忙？"
        $ NPC = "???"
    else:
        quil amused cling "在偷看吗？"
        show quil datar -cling
        show side_p f at pic
        mc "你想得美。"
    hide side_p
    show pboy at horzappear
    menu:
        "想一起出去玩吗？":
            hide pboy
            if calendar.day == 23 and calendar.month == '/05':
                quil sulk sweat "今天不行，对今晚太紧张了。也许其他人更愿意。"

            elif calendar.day == 18 and calendar.month == '/05':

                quil frown sigh "已经开始逃课了？啧啧，这可不会在[povname]的记录上看起来很好，是吧？"
                quil datar -sigh "来吧，我们应该在维尔科娃女士开始扣分之前去上她的课。"
                "你们两个决定一起去上课。"
                jump combat_kls
            else:
                if "mc_bangkit" in my_events and "quil_pisah" not in quil_events:
                    
                    if "quil_pisah" not in quil_events:
                        quil laugh blush bloom "我还以为你永远不会问呢！"
                        jump quil_parting
                    elif "date3_done" in quil_events and "date4_done" not in quil_events and bff.points >= 80:
                        quil smile "我还以为你永远不会问呢。实际上，我有些事想告诉你。"
                        show side_p a at pic
                        mc "我应该担心吗？"
                        hide side_p
                        quil flashy wink cling "嗯。那要看情况，不过你先去换衣服，然后在湖边见我，我有个惊喜！"
                        scene bg_black with w20
                        "还没等你抗议，奎尔就把你推到宿舍去换衣服。"
                        "然后你们两个一起前往湖边，奎尔在那里打开了一个新的传送门，不知道通向哪里。"
                        jump quil_date4
                    else:
                        #berubah
                        $ datingplace = "Arena"
                        #berubah
                        jump quil_date_check   
                else:
                    quil flashy wink cling "哦，小[povname]渴望沐浴在我的光辉之下吗？"
                    show side_p f at pic
                    mc "我改变主意了。"
                    hide side_p
                    quil skul sulk frusta "等等！"
                    quil amused sigh"哦，别走啊，我只是在开玩笑。那么，你想做什么？"
                    show side_p se at pic
                    mc "你比我更了解这个地方。"
                    hide side_p
                    quil laugh -sigh "嗯。好吧，我们可以做点什么。"
                    scene bg_black with w20
                    #berubah
                    $ datingplace = "Arena"
                    #berubah
                    jump quil_date_check
            
        "只是路过而已。":
            hide pboy
            quil amused apa "哦？"
            quil tantrum sigh "我还以为你要请我吃顿大餐呢。"
            quil smile -sigh "你的损失。"
    $ NPC = "???"
    scene map_tempur with dissolve
    jump map_tempur
label tempur_1:
    hide screen tempur_map
    scene practice with dissolve
    $ NPC = "???"
    if "mc_bangkit" in my_events:
        npc "莱纳尔的破坏真的提醒我们，我们确实需要保持警惕。"
        npc "如果我们连就在眼皮底下的巫师都注意不到，我们怎么能从巫师手中拯救人们呢？"

    elif "beku" in quil_events:
        npc "我们的俱乐部现在在结冰的湖面上进行对抗赛。这让我们保持凉爽！"
    elif "io4" in my_events:
        if "ice_rune" in my_events:
            npc "你听说杰森和湖边的一个男孩上床了吗？"
            npc "他们是表兄弟！或者至少，我觉得他们是！"
        else:
            npc "不知道我们什么时候会有新校长。"
    elif "vamp_visit" in red_events:
        npc "希望塞恩的脸颊没有引发我们和吸血鬼之间的战争！"
    elif "bite_day" in red_events:
        npc "真不敢相信温斯顿的所有喃喃自语都是真的。看来我应该更多地关注那个人。"
    elif "bunga_bego" in buff_events:
        npc "这些花真的让人感觉像是世界末日，不是吗？"
        npc "希望不是，但还是..."
        
    elif "day3" in quil_events:
        
        if "map1" in completed_quests:
            npc "天啊，我生疏了。待会儿我应该喝点维他命。"
        else:
            $ NPC = "温斯顿"
            npc "去死吧，该死的吸血鬼！"
            if "ajax" in fia_events and "w_flag" in red_events:
                npc "你看到塞恩舔着手指上阿什姆的血了吧？"
                npc "该死的吸血鬼，我就知道他和其他吸血鬼没什么不同。"
                npc "在他露出真面目之前，必须把他开除！"
            elif "winston" in my_events and "w_flag" not in red_events:
                show side_p f at pic
                mc "对不起，请问你是...温斯顿吗？"
                $ red_events.append("w_flag")
                hide side_p
                $ NPC = "温斯顿"
                npc "关你什么事？哦等等，你是那个吸血鬼的朋友，[povname]。"
                npc "我没什么要对你说的。"
                show side_p f at pic
                mc "你对吸血鬼有什么意见，伙计？"
                hide side_p
                npc "除了他们把人类当成牲畜对待之外？他们和巫师没什么两样。"
                npc "一旦放松警惕，你就会被吸干。"
                show side_p s at pic
                mc "得了吧，别那么多疑。"
                hide side_p
                npc "我没有。我母亲是个血妓。我不得不看着她每晚满身伤痕和咬痕地回家。"
                npc "她死于失血过多。"
                npc "维尔科娃和你那个吸血鬼朋友也好不到哪去。如果我是你，我会在他们趁我睡觉时吸干我之前切断与他们的联系。"
                show side_p he at pic
                mc "哇哦。你听说过\'种族主义和偏见\'吗？"
                hide side_p
                npc "你听说过\'天真和无知\'吗？"
                npc "如果你愿意，可以举报我。但我知道真相。吸血鬼是只能靠他人之死而生存的邪恶生物。"
                npc "就像巫师一样，她们以痛苦和混乱为乐。"
                show side_p s at pic
                mc "也许你应该换个职业。"
                hide side_p
                npc "相信我，如果猎杀吸血鬼是合法的，我会毫不犹豫地杀光那些吸血鬼。在那之前，这就够了。"
                play sound "sound/effects/glass.wav"
                npc "嘿呀！" with vpunch
                "温斯顿继续用他的冰刃劈砍假人。你应该决定如何处置他。"
                "向凯普勒先生举报他似乎是最好的行动方案。"
                $ NPC = "???"
            else:
                "嗯，那个人确实有问题。你现在应该远离他。"
                $ NPC = "???"


    else:
        npc "我来这所学校是为了给我的家人报仇。"
        npc "在伊瓦尔搞砸一切之前，我的家人住在克罗汉姆。"
        npc "我们逃了出来，但是..."
        npc "...直到今天，我母亲的伤口上仍然长着花。"
    scene map_tempur with dissolve
    jump map_tempur
label tempur_2:
    hide screen tempur_map
    $ NPC = "???"
    if "mc_bangkit" in my_events:
        npc "我会想念去莱纳尔的日子。我知道现在去那里太危险了。"
        npc "但那里的人都很友善。"

    elif "beku" in quil_events:
        npc "我真想和冰冻湖泊的人打一架。好好教训他们一顿！"
    elif "io4" in my_events:
        if "ice_rune" in my_events:
            npc "你知道莱纳尔在这整个湖人事件之后变得一团糟。"
            npc "有些东西本该永远长眠。"
        else:
            npc "你知道吗，威廉校长是我来这所学校的原因。"
            npc "他是个传奇猎巫人。真不敢相信他竟然是因为摔倒而死的。"
    elif "vamp_visit" in red_events:
        npc "虽然很致命，但你现在不禁对那些邪血者有些着迷，不是吗？"
    elif "bite_day" in red_events:
        npc "希望我们还能专注于真正的敌人。是巫师，不是吸血鬼。"
        npc "或者说，先专注于巫师，然后再对付吸血鬼。周围的巫师并不多。"
        npc "你知道吗，吸血鬼占我们当前人口的22%%？"
        npc "人类只占20%%。25%%是人鱼，但我们看不出来，因为他们住在水下。"
        npc "剩下的是仙子、海妖和狼人。哦，还有只有两个活着的噬梦者，奥利凡德兄妹。"
        npc "听说他们和吸血鬼关系很好。据说他们总是出现在死亡最盛行的地方。"
    elif "bunga_bego" in buff_events:
        npc "每个人都在担心那些花。希望他们能尽快解决这个问题。"
        
    else:
        show side_p he at pic
        mc "（这些学生都在努力训练呢。）"
        hide side_p
    if calendar.day == 15 and calendar.month == '/05':
        npc "刺，刺！"
    elif "sucker3" in active_quests:
        npc "嘿，你刚才有看到一只猫走过吗？"
        npc "我想它朝大门那边去了。"
    else:
        if "vits1" not in active_quests and "vits1" not in completed_quests:
            npc "顺便问一下，[povname]，你有维他命吗？我需要提神。"
            npc "我要去奇奇亚参加一场大型比赛。不想让人失望。"
            show side_p f at pic
            mc "奇奇亚？"
            hide side_p
            npc "没错，就我一个人对抗东边那些凶猛的狼人。"
            npc "我喜欢那些大狗狗，他们对我们很友善。至少对我们是这样。对吸血鬼和巫师就不那么友好了。"
            npc "如果真的再次爆发对抗巫师的战争，他们是唯一一个我可以信任会帮助我们的种族。"
            npc "不过希望不会发展到那种地步。"
            npc "总之，如果你有多余的维他命，就给我一些吧。我一定会适当补偿你的。"
            npc "还有，我会在奇奇亚的战斗中高声赞美你，哈哈！"
            $ add_new_quest("vits1")
            python:
                if len(new_quests) > 0: #if we have new quests
                    for i in new_quests:
                        active_quests.insert(0, i) #add to top of the quest list
                    new_quests = [] #now reset the new quest list, since they all got added
            show screen completedtask("新任务！")
        elif "vits1" in active_quests:
            if check_inv_for(vit_items):
                python:
                    InvItem(*item_vita).toss(1)
                    active_quests.remove("vits1")
                    completed_quests.insert(0, "vits1")
                npc "哦，你给我带来了维他命饮料？谢谢！"
                show screen completedtask("任务完成！")
                npc "哦谢谢！给，这是我给你的额外奖励。"
                $ gold += 150
                play sound "ding.mp3"
                "得到了150金币和一些大麻。"
                $ InvItem(*item_weed).pickup(1)
                show side_p f at pic
                mc "大麻？"
                hide side_p
                npc "海德温说这能帮我在战斗前放松。我想她忘了大麻在奇奇亚还是非法的。"
                npc "你是那种喜欢狂欢的类型，对吧[povname]？我还记得你和阿什姆分手时我们胡闹的日子。"
                npc "你们俩怎么样了？我还是没机会吗？"
                show side_p s at pic
                mc "呃？"
                hide side_p
                npc "哦，忘了我说的吧。口误。"
                show side_p s at pic
                mc "等等，不，倒回去！我们约会过还是怎么的？"
                hide side_p
                npc "哎呀，哇。我对你来说真的那么容易被遗忘吗？是的，我们在二年级的冬天约会过。"
                npc "我想让关系正式化，但你说你唯一愿意嫁的人就是你自己，记得吗？"
                show side_p s at pic
                mc "啊是的...抱歉，呃..."
                hide side_p
                npc "哦，神圣的科尔啊，你真的把我忘了。好吧...也许这样最好。一个5分的人永远不可能配得上一个10分的人，我早该知道的。"
                show side_p s at pic
                mc "等等，我——"
                hide side_p
                npc "谢谢你的维他命饮料，[povname]。"
                "那个男人在进一步解释之前就离开了。"
                $ fia_events.append("mantan")
        elif "vits1" in completed_quests and "mantan" not in fia_events:
            npc "[povname]，再次感谢你的维他命饮料！给，这是我给你的额外奖励。"
            $ InvItem(*item_weed).pickup(1)
            show side_p f at pic
            mc "大麻？"
            hide side_p
            npc "海德温说这能帮我在战斗前放松。我想她忘了大麻在奇奇亚还是非法的。"
            npc "你是那种喜欢狂欢的类型，对吧[povname]？我还记得你和阿什姆分手时我们胡闹的日子。"
            npc "你们俩怎么样了？我还是没机会吗？"
            show side_p s at pic
            mc "呃？"
            hide side_p
            npc "哦，忘了我说的吧。口误。"
            show side_p he at pic
            mc "等等，不，倒回去！我们约会过还是怎么的？"
            hide side_p
            npc "哎呀，哇。我对你来说真的那么容易被遗忘吗？是的，我们在二年级的冬天约会过。"
            npc "我想让关系正式化，但你说你唯一愿意嫁的人就是你自己，记得吗？"
            show side_p s at pic
            mc "啊是的...抱歉，呃..."
            hide side_p
            npc "哦，神圣的科尔啊，你真的把我忘了。好吧，也许这样最好。一个5分的人永远不可能配得上一个100分的人，我早该知道的。"
            show side_p s at pic
            mc "等等，我——"
            hide side_p
            npc "谢谢你的维他命饮料，[povname]。"
            "那个男人在进一步解释之前就离开了。"
            $ fia_events.append("mantan")
        else:
            npc "需要什么吗？"

    jump map_tempur
label tempur_3:
    hide screen tempur_map
    $ NPC = "???"
    scene practice with dissolve
    if "mc_bangkit" in my_events:
        npc "我喜欢莱纳的火腿。现在我们可能再也尝不到了！"

    elif "beku" in quil_events:
        npc "我不知道湖面是怎么保持冰冻的。不知道用了什么符文。"
    elif "io4" in my_events:
        if "ice_rune" in my_events:
            npc "我为湖边的幸存者感到难过。"
            npc "看起来他们分不清东南西北。"
        else:
            npc "这么说可能很糟糕，但我有点高兴威廉死了。"
            npc "他以猎杀海妖为乐。那些美丽、无辜的生物不应该遭受如此残酷的对待。"
            npc "我告诉你，这就是报应。"
    elif "vamp_visit" in red_events:
        npc "我有点羡慕你和塞恩建立了联系。他是个不错的家伙，除了那对獠牙。"
    elif "bite_day" in red_events:
        npc "我希望塞恩不会失控。我喜欢他，他是校园里比较好的男生之一。"
    elif "bunga_bego" in buff_events:
        npc "如果再有人抱怨这些花，我发誓！"
        
    elif "ajax" in fia_events and "winston" in my_events:
        npc "你看到塞恩舔着沾有阿什姆血的手指了吗？"
        npc "我不愿相信温斯顿说的关于吸血鬼的话是真的，但是..."
    elif calendar.day == 15 and calendar.month == '/05':
        npc "[povname]，我的宿敌！"
        if girl:
            show p_side f at pic
        else:
            show side_p f at pic
        mc "呃，你是谁来着？"
        if girl:
            hide p_side
        else:
            hide side_p
        npc "别装傻。我哥哥去年夏天让我接受了特殊训练。"
        npc "我终于要重获荣誉了，你等着瞧吧。我会为我们下一节防御课做好准备的。"
        if girl:
            show p_side f at pic
        else:
            show side_p f at pic
        mc "好的，伙计。"
        if girl:
            hide p_side
        else:
            hide side_p
    elif "sucker3" in active_quests:
        npc "你刚才看到猫了吗？差点踩到那可怜东西的尾巴。"
    else:
        npc "得在秋天来临前好好锻炼一下。那时候外面太冷了，不适合战斗。"
    scene map_tempur with dissolve
    jump map_tempur

#Arena
screen arena_map():
    tag menu
    if "bunga_bego" in buff_events:
        
        if calendar.weekday == "Mon" or calendar.weekday == "Wed" or calendar.weekday == "Fri":
            imagebutton:
                idle "images/maps/arena/ar_red.png"
                hover "images/maps/arena/ar_red.png"
                xpos 405 ypos 106
                hovered [ Play ("test_one", "type.wav")]
                action [Play ("test_one", "stroke.mp3"), Jump("arena_red")]
                focus_mask None
                mouse "search"
            
        
    imagebutton:
        idle "images/maps/arena/ex.png"
        hover "images/maps/arena/ex.png"
        xpos 1674 ypos 0
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("world_map")]
        focus_mask None
        mouse "search"
    imagebutton:
        idle "images/maps/arena/4.png"
        hover "images/maps/arena/4_hover.png"
        xpos 881 ypos 154
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("arena_4")]
        focus_mask None
        mouse "search"
    imagebutton:
        idle "images/maps/arena/3.png"
        hover "images/maps/arena/3_hover.png"
        xpos 956 ypos 344
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("arena_3")]
        focus_mask None
        mouse "search"
    imagebutton:
        idle "images/maps/arena/2.png"
        hover "images/maps/arena/2_hover.png"
        xpos 369 ypos 399
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("arena_2")]
        focus_mask None
        mouse "search"
    imagebutton:
        idle "images/maps/arena/1.png"
        hover "images/maps/arena/1_hover.png"
        xpos 1405 ypos 298
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("arena_1")]
        focus_mask None
        mouse "search"

label map_arena:
    hide screen peta_all
    scene map_arena
    #play music "MUSIC/MusMus-BGM-136.mp3"
    if calendar.day == 15 and calendar.month == '/05' and "gelut" not in red_events:
        jump arena_0
    
    else:
        call screen arena_map

label arena_red:
    hide screen garden_map
    scene arena_crowd with dissolve
    show red point cowo at center with dissolve:
        yoffset 330
    if "drained" in fia_events and "io0" not in my_events:
        mc "塞恩！"
        show red sad sweat shock at center with dissolve:
            yoffset 330
        "在你能抓住他之前，塞恩跑掉了。"
        hide red with dissolve
        "你花了一整天试图抓住他，但都是徒劳。"
        #scene bg_black with w33
        play music "MUSIC/MusMus-BGM-082.mp3"
        scene lor_mlm with w33
        jump ur_room
    elif "vamp_visit" in red_events and "date_cekup" not in red_events:
        jump red_cekup
    red "哦嘿，[povname]！"
    if "mc_bangkit" in my_events and "red_pisah" not in red_events:
        red "有空吗？我有话想说。"
    else:
        if mrh.points > 20 and "gift1" not in red_events:
            red grin apa "嘿，[povname]，需要任何魔药材料吗？"
            red datar -apa "我从课上多带了一些魔法粉末，给你！"
            $ InvItem(*item_blue).pickup(1)
            show side_p se at pic
            $ red_events.append("gift1")
            mc "哦，谢谢，塞恩！"
            hide side_p
            red "别客气！话说，想一起出去玩吗？"
        elif mrh.points >= 50 and "gift2" not in red_events:
            red ew sweat apa "嘿，[povname]，你有没有想过我们的灰烬是从哪里来的？"
            show side_p f at pic
            mc "啊？"
            hide side_p
            $ InvItem(*item_ash).pickup(1)
            red perih sigh "骨灰。我是说，它们是真正的\'人类\'遗骸，所以一定是有人捐赠的，对吧？"
            red ngeles -sigh "除非他们真的活活烧死人..."
            red ew frusta "不，不，那又是我的侵入性思维在作祟了。"
            red wry -sweat -frusta "总之，给你，这是我从魔药课上多拿的一些骨灰。你以后可能会用到。"
            show side_p he at pic
            mc "...谢谢？"
            show side_p s
            mc "（该死，这些灰烬到底是从哪里来的？）"
            hide side_p
            red datar "别客气！话说，想一起出去玩吗？"
            $ red_events.append("gift2")
        elif mrh.points >= 70 and "gift3" not in red_events:
            red cowo blush bunga "嘿，[povname]，猜猜怎么着？"
            red grin "看来我和菲亚一起学习终于有回报了！"
            $ InvItem(*item_boner).pickup(1)
            red amused cling "我自己制作了一些高质量的\'欲望消除剂\'！耶！"
            show side_p se at pic
            $ red_events.append("gift3")
            mc "那很棒，塞恩，但是等等。你怎么知道它是高质量的？"
            hide side_p
            red mock cling "我们当然测试过了！不是在我自己身上，因为我不是受虐狂，而是在...嗯...受试者身上。"
            show side_p he at pic
            mc "受试者？"
            hide side_p
            red awkward sweat sigh "你最好还是不要知道。"
            show side_p w at pic
            mc "明白了。"
            hide side_p
            red happy -sweat -sigh "总之，我多做了一些，给你。也许你想让某人欲求不满或什么的。"
            red datar "希望你玩得开心！话说，你有空吗？想一起出去玩吗？"
        else:
            red datar "想一起出去玩吗？"
    show pboy at horzappear
    menu:
        "和塞恩一起出去玩？":
            hide pboy
            red cowo blush"太好了！"
            if "mc_bangkit" in my_events and "red_pisah" not in red_events:
                jump red_parting
            else:
                $ datingplace = "Arena"
                red datar -blush "我知道一个好地方！"
                jump red_date_check
        "不了。":
            hide pboy
            show side_p f at pic
            mc "也许改天吧。"
            hide side_p
            scene map_arena with dissolve
    jump map_arena   
label arena_0:
    hide screen arena_map
    if "gelut" in red_events:
        scene arena_crowd with dissolve
        "对练继续进行。你应该离开他们。"
    else:
        $ red_events.append("gelut")
        play sound "sound/effects/woosh.mp3"
        scene fight1 with flashbulb
        galleryunlock fight1
        pause 2.0
        "你看到塞恩在和另一个学生打斗。起初，你以为他会被揍得很惨。"
        play sound "sound/effects/freeze.mp3"
        scene fight2 with dissolve
        galleryunlock fight2
        "但结果证明他完全能应付自如。"
        $ renpy.pause()
        scene arena_crowd with dissolve
        show red cowo at center with dissolve:
            yoffset 330
        red shock "哦，[nickname]！来看我打架的？"
        if girl:
            show girl at horzappear
        else:
            show pboy at horzappear
        menu:
            "你打得不错。":
                hide girl
                hide pboy
                $ kindness += 5
                $ mrh.points += 5
                red datar blush bunga "不错吧？我这个夏天学了几个冰系符文。主要是为了在我被烤焦之前降温用的。"
                red amused -blush -bunga "不过它们在这种情况下也很有用，虽然我还远不如奎尔的水平。"
                red cowo "等不及要看你和他对练了，那场面一定很精彩！"
                show side_p a at pic
                mc "啊哈哈，是啊。"
                show side_p s 
                mc "（天啊，我会死在这所学校里吗？我怎么可能在这里和任何人打架还能活下来！）"
                hide side_p
            "我只是路过而已。":
                hide girl
                hide pboy
                red chin datar apa "哦……那么，你觉得我的战斗怎么样，伙计？"
                red laugh blush bunga "我这个夏天进步了。学会了几个冰系符文。"
                if girl:
                    show p_side se at pic
                else:
                    show side_p se at pic
                mc "你看起来很{i}酷{/i}。"
                if girl:
                    hide p_side
                else:
                    hide side_p
                red amused shock "嘿……不错！"
        red grin blush bunga "好吧，总之，回教室去了。再见，[nickname]！"
    scene map_arena with dissolve
    jump map_arena
label arena_1:
    hide screen arena_map
    scene arena_crowd with dissolve
    $ NPC = "???"
    if "mc_bangkit" in my_events:
        npc "塞恩说他要退出俱乐部。说他想多花些时间和朋友在一起。"
        npc "他不是几乎每时每刻都和你们在一起吗，怎么回事？"
    elif "beku" in quil_events:
        npc "俱乐部一直在试图抢占冰场。"
        npc "射箭和击剑俱乐部真的把它占为己有了。"
    elif "io4" in my_events:
        if "ice_rune" in my_events:
            npc "你知道吗，我和一个湖边幸存者对练过。"
            npc "他们真的比我们更强壮。更擅长使用符文。"
            npc "如果他们情绪不那么不稳定，他们会是很好的资产。"
        else:
            npc "我希望威廉校长能找到平静。"
    elif "vamp_visit" in red_events:
        npc "我很高兴你和塞恩建立了感情！"
        npc "谢谢你照顾他，[povname]！"
    elif "bite_day" in red_events:
        if "kado_bagi" not in red_events:
            npc "嘿，[povname]，你能把这个给塞恩吗？"
            show side_p f at pic
            mc "血？"
            hide side_p
            $ InvItem(*item_plasma).pickup(1)
            $ red_events.append("kado_bagi")
            npc "只是一小瓶，但我觉得会有帮助。塞恩是个好人。"
            npc "他攻击皮尔斯可能是因为太饿了。"
            npc "与普遍的看法相反，我怀疑他对塔图姆做了什么。他太怯懦了，做不出那种事。"
        else:
            npc "希望塞恩现在还好。"
    elif "festies" in my_events:
        npc "我们下一步该猎杀吸血鬼吗？我是说他们对塔图姆造成了相当大的伤害。"
    elif "bunga_bego" in buff_events:
        npc "这些花真让人感觉像是世界末日，是吧？"
        npc "希望不是，但还是..."
    elif "ajax" in fia_events:
        npc "大家还在谈论阿什姆和阿贾克斯？快点长大吧！"
    elif "sucker3" in active_quests:
        npc "嗯，一只猫？我想我看到一只往商店楼梯下走去，还是朝图书馆方向？"
    else:
        if "necrosis" in my_events:
            $ NPC = "男孩A"
            npc "听说你召唤出了蓝色火焰！那真是太厉害了，[povname]。你能找时间教教我吗？"
            show side_p s at pic
            mc "我差点失去了我的手！"
            hide side_p
            npc "嗯，熟能生巧！"
            $ NPC = "???"
        else:
            $ NPC = "男孩A"
            npc "你试过召唤蓝色火焰吗？"
            $ NPC = "男孩B"
            npc "不，伙计，阿什姆和奎尔都还做不到呢。如果他们都做不到，我为什么要尝试？"
            $ NPC = "???"
    scene map_arena with dissolve
    jump map_arena
label arena_2:
    hide screen arena_map
    scene arena_crowd with dissolve
    $ NPC = "???"
    if "mc_bangkit" in my_events:
        npc "莱纳尔的破坏真的提醒我们，我们真的需要保持警惕。"
        npc "如果我们连就在眼皮底下的巫师都注意不到，我们怎么能从巫师手中拯救人们呢？"

    elif "beku" in quil_events:
        npc "我们的俱乐部现在在结冰的湖面上进行对抗赛。这让我们保持凉爽！"
    elif "io4" in my_events:
        if "ice_rune" in my_events:
            npc "我……我曾经加入过这个俱乐部，在湖边事件之前……"
            npc "在我的梦里，我是队长，和我梦中的男人约会……"
            npc "为什么……为什么我要醒来？"
        else:
            npc "我希望新校长能尽快到任。"
    elif "vamp_visit" in red_events:
        npc "我很高兴塞恩现在能控制他的本能了，我不知道为什么我们之前没有想到要和他建立联系！"
    elif "bite_day" in red_events:
        npc "我正在召集决斗俱乐部的人，这样塞恩就能有充足的血液供应。"
        npc "轮流捐献应该会有帮助。我不知道为什么我们之前没想到这一点，毕竟他是学校里唯一的吸血鬼。"
        npc "塞恩是我们俱乐部的优秀成员。他只需要控制好自己的饥饿感。"
        if "kuya2" not in red_events:
            npc "给，我这里有一些乌龟，你可以从它们身上抽血。我相信塞恩会感激的！"
            $ InvItem(*item_turtle).pickup(3)
            $ red_events.append("kuya2")
    elif "festies" in my_events:
        npc "我曾经邀请过塔图姆加入我们的俱乐部。也许如果她加入了，现在就不会在医院里了。"
    elif "bunga_bego" in buff_events:
        npc "这些花一定是有人带来的，问题是谁。"
        
    elif "sharom" not in my_events:

        npc "[povname]！"
        if girl:
            show p_side s at pic
        else:
            show side_p s at pic
        mc "哦，呃，嗨……你是？"
        if girl:
            hide p_side
        else:
            hide side_p
        $ NPC = "戴安娜"
        npc "是戴安娜？戴安娜·沙龙？我从二年级就认识你了？"
        "仔细一看，你注意到她头发上有一些颜色不均匀的斑块。"
        if girl:
            show p_side se at pic
        else:
            show side_p se at pic
        mc "对了！呃，你染头发了。"
        if girl:
            hide p_side
        else:
            hide side_p
        npc "哦，你注意到了！我想换个新造型。"
        npc "话说，你的暑假过得怎么样？听说你现在已经和几个巫师战斗过了，对吧？感觉如何？"
        npc "你能找时间跟我分享一些故事吗？"
        $ my_events.append("sharom")
        if girl:
            show girl at horzappear
        else:
            show pboy at horzappear
        menu:
            "就这么定了。":
                hide girl
                hide pboy
                npc "什么——哦，不！我可不想那样。如果我这么做，阿什姆会杀了我的。更别提我妈妈格尔拉了。"
                if girl:
                    show p_side s at pic
                else:
                    show side_p s at pic
                mc "杀了你？"
                if girl:
                    hide p_side
                else:
                    hide side_p
                npc "听着，我知道他是什么样的。自从你从那个德拉克马尔巫师手中救了他，他就对你痴迷不已。"
                npc "我理解他的痴迷，你确实很有魅力，但还是……"
                if girl:
                    show p_side f at pic
                else:
                    show side_p f at pic
                mc "嗯。"
                if girl:
                    hide p_side
                else:
                    hide side_p
                if "drakmar" not in topics:
                    $ topics.append("drakmar")
                    play sound "audio/success.mp3"
                    "新话题：{color=#FF1500}德拉克马尔巫师。{/color}"

            "那是私事。":
                hide girl
                hide pboy
                npc "好吧-好吧。"
    elif "sucker3" in active_quests:
        npc "顺便说一下，我看到一只猫朝商店区跑去了。不知道是谁带来的。"
    else:
        npc "需要什么吗？如果你想加入决斗俱乐部，我们随时欢迎新成员。"
    $ NPC = "???"
    scene map_arena with dissolve

    jump map_arena
label arena_3:
    hide screen arena_map
    scene arena_crowd with dissolve
    $ NPC = "???"
    if "mc_bangkit" in my_events:
        npc "塞恩最近看起来很开心。我在想是不是发生了什么好事。"
    elif "beku" in quil_events:
        npc "湖里的冰从不融化，它就是一个永久的冰块！"
    elif "io4" in my_events:
        if "ice_rune" in my_events:
            npc "我希望从湖里获救的幸存者能得到他们需要的帮助。"
            npc "我分不清他们是高兴还是难过重新醒来。"
        else:
            npc "我给威廉的父母送了花，这是应该的。"
    elif "vamp_visit" in red_events:
        npc "我输掉了关于皮尔斯说谎的赌注，但我很高兴塞恩没有被开除，或者更糟。"
        npc "我喜欢和那家伙对练！"
    elif "bite_day" in red_events:
        $ NPC = "学生A"
        npc "我赌250金币皮尔斯在说谎，塞恩只是给了他一个爱的咬痕。"
        $ NPC = "学生B"
        npc "我不知道，伙计，老师说他的咬痕和塔图姆还有她的跟班身上的一样。"
        $ NPC = "学生A"
        npc "我说这是假新闻！老师们只是种族主义者。"
        $ NPC = "???"
    elif "ajax" in fia_events:
        npc "我本来愿意付钱看阿什姆被揍，可惜菲亚不得不出面阻止！"
    elif "bunga_bego" in buff_events:
        npc "这些花真是可怕，不是吗？如此美丽却又如此令人心生创伤。"
        npc "我被它的藤蔓缠住了，无法想象成为其中一员的感觉。"
    elif "sucker3" in active_quests:
        npc "嗯，哈！"
        "问这两个人关于猫的事没用。"
    else:
        pass
    if "tomb" in topics:
        if "no_sleep1" not in active_quests and "no_sleep1" not in completed_quests:
            npc "顺便问一下，你知道湖底下有一条秘密隧道吗？"
            show side_p f at pic
            mc "秘密隧道？"
            hide side_p
            npc "是啊，他们说学校下面有一个墓穴，但它只在每天凌晨两点左右开放。"
            npc "嘿，[povname]，你在制作魔药方面很在行。你能给我做些\'不眠之夜\'吗？我一定会分享我的发现！"
            $ add_new_quest("no_sleep1")
            python:
                if len(new_quests) > 0: #if we have new quests
                    for i in new_quests:
                        active_quests.insert(0, i) #add to top of the quest list
                    new_quests = [] #now reset the new quest list, since they all got added
            show screen completedtask("新任务！")
        else:
            npc "我在想我们还能在学校里找到什么其他隐藏区域。"
    else:
        $ NPC = "???"
        npc "来吧，就变成狼形态和我打一次？"
        $ NPC = "狼人"
        npc "不行！再说，我是狼人并不意味着我可以随心所欲地变形。"
        npc "这是本能的事，不是可以控制的！"
        $ NPC = "???"
    scene map_arena with dissolve
    jump map_arena
label arena_4:
    hide screen arena_map
    scene arena_crowd with dissolve
    $ NPC = "???"
    hide screen arena_map
    if "mc_bangkit" in my_events:
        npc "塞恩最近似乎真的很兴奋。"
        npc "比平常更甚。我很高兴他解决了困扰他的事情。"

    elif "io4" in my_events:
        if "ice_rune" in my_events:
            npc "我见到了桑扎，他曾经是这里的成员，在他……"
            npc "嗯，在他跳进湖里之前。我尽可能多地和他交谈。"
        else:
            npc "我不是威廉的粉丝，但我没想到他会死得这么年轻。"
            npc "他才刚50岁。"
    elif "vamp_visit" in red_events:
        npc "你是个真正的朋友，[povname]！"
        npc "如果你需要我们俱乐部的任何帮助，尽管说！再次感谢你帮助塞恩！"
    elif "bite_day" in red_events:
        npc "我希望塞恩不会变成邪血族。我无法想象比那更糟糕的命运了。"
    elif "mey_kill" in my_events and "festies" not in my_events and "ntr" not in red_events:
        npc "嘿，[povname]，我能请你帮个忙吗？"
        show side_p f at pic 
        mc "怎么了？"
        hide side_p
        npc "我知道你和塞恩是好朋友，你能帮我把这封信交给他吗？"
        npc "这是水母节的邀请函。我暗恋他很久了，如果你能帮我问问他，那对我来说意义重大！"
        show side_p f at pic 
        mc "哦，我..."
        hide side_p
        show pboy at horzappear
        menu:
            "接受":
                hide pboy
                show side_p se at pic
                mc "你知道吗？我现在就去办！"
                hide side_p
                scene bg_black with w20
                scene practice with w20
                show red chin huh at center with dissolve:
                    yoffset 330
                red apa "嗯？舞会的邀请？"
                red kaget shock "等等，这是不是意味着你——"
                show pboy at horzappear
                menu:
                    "不是我！":
                        hide pboy
                        $ mrh.points -= 5
                        show red frown -shock
                        show side_p f at pic
                        mc "是有个男孩邀请你。信上没写他的名字吗？"
                        hide side_p
                        red point amused sigh "哦对，是康奈尔。"
                        show side_p f at pic
                        mc "你认识他？"
                        hide side_p
                        red frown -sigh "有点印象。这家伙加入了决斗俱乐部，但通常只是在一旁观看。"
                        red awkward "现在我知道原因了。"
                        show side_p f at pic
                        mc "那你打算去吗？"
                        hide side_p
                        red chin sad sigh "我是说...这个人挺好的，但用奎尔的话说..."
                        red sayang frusta "这个人\'就像湿纸板一样单调\'。"
                        show side_p he at pic
                        mc "所以他很无聊？"
                        hide side_p
                        red point hister sigh "差不多吧。或者可能是我太习惯你、奎尔和阿尔希带来的混乱了。"
                    "你是在邀请我吗？":
                        hide pboy
                        show side_p he at pic
                        mc "我是说，这邀请是别人的，但如果你是在邀请我，那么..."
                        hide side_p
                        red point kzl frusta "啊等等，别曲解我的意思，伙计！"
                        red sayang sigh "况且如果我要邀请你，那我必须要全力以赴。"
                        red grin "比如放烟花或在地上点燃名字缩写之类的。"
                        show side_p f at pic
                        mc "什么？"
                        hide side_p
                        red laugh bunga "我是说，你救了我的命。我至少得给你一个盛大的浪漫惊喜。"
                        red amused sigh "除非你不喜欢这种。"
                        show pboy at horzappear
                        menu:
                            "我喜欢！":
                                hide pboy
                                $ red_events.append("lebay")
                                red wry -sigh "我就知道，另一个你也是这样。所以我想你们的一些喜好会是一样的。"
                                show side_p se at pic
                                mc "那我是不是该期待你在地上点燃一个大大的标志，邀请我出去？"
                                hide side_p
                                red laugh "哈哈，也许吧，但肯定不是现在，也不是我...至少现在还不是。"
                            "不太喜欢。":
                                hide pboy
                                if "lebay" in red_events:
                                    $ red_events.remove("lebay")
                                red kaget -sigh "啊，明白了。"
                        red sayang "不过，还是谢谢你当信使。我最好还是正式拒绝康奈尔。"
                        red datar "他是个帅哥，我相信其他女孩或男孩会很乐意和他在一起的。"
                red point mock cling "嗯，这让我想起来了。你试过水上舞蹈吗？"
                show side_p f at pic
                mc "水上舞蹈？"
                hide side_p
                red laugh bunga "你把鞋跟底部冻住，这样即使水面没结冰也能在上面滑行。"
                red happy "来，我给你演示！"
                show side_p he at pic
                mc "啊，等等！"
                hide side_p
                stop music
                play sound "sound/effects/cloth.mp3"
                scene bg_black with w20
                jump water_dance
                
            "拒绝":
                hide pboy
                if "ntr" in red_events:
                    $ red_events.remove("ntr")
    elif "bunga_bego" in buff_events:
        npc "我试过冻结花朵但没成功。嗯，也许用火？"
        show side_p s at pic
        mc "相信我，别从火开始。"
        hide side_p
    elif "ajax" in fia_events:
        npc "阿贾克斯用了月刃符文，对吧？糟糕的选择，那东西基本上就是个回旋镖。如果不是菲亚出手，可能会伤到更多人。"
    else:
        $ NPC = "学生A"
        npc "你见过校长战斗吗？"
        $ NPC = "学生B"
        npc "哦是的，我为任何要与他对战的人祈祷。"
        $ NPC = "学生A"
        npc "不知道他最近去哪了，好久没见到他了。"
        $ NPC = "学生B"
        npc "也许教会派他去执行任务了？"
    scene map_arena with dissolve
    $ NPC = "???"
    jump map_arena
#Lower
screen lower_map():
    tag menu

    imagebutton:
        idle "images/maps/lower/store.png"
        hover "images/maps/lower/store.png"
        xpos 531 ypos 424
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("map_store")]
        focus_mask None
        mouse "search"
    imagebutton:
        idle "images/maps/lower/ex.png"
        hover "images/maps/lower/ex.png"
        xpos 1504 ypos 399
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("world_map")]
        focus_mask None
        mouse "search"
    if calendar.weekday == "Tues" or calendar.weekday == "Fri" or calendar.weekday == "Sun":
        if "neko" not in my_events and "day3" not in quil_events:
            imagebutton:
                idle "images/maps/lower/neko.png"
                hover "images/maps/lower/neko_hover.png"
                xpos 715 ypos 636
                hovered [ Play ("test_one", "type.wav")]
                action [Play ("test_one", "stroke.mp3"), Jump("catto")]
                focus_mask None
                mouse "search"
        imagebutton:
            idle "images/maps/lower/2.png"
            hover "images/maps/lower/2_hover.png"
            xpos 971 ypos 301
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("lower_1")]
            focus_mask None
            mouse "search"
        imagebutton:
            idle "images/maps/lower/1.png"
            hover "images/maps/lower/1_hover.png"
            xpos 771 ypos 726
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("lower_2")]
            focus_mask None
            mouse "search"
    else:
        imagebutton:
            idle "images/maps/lower/olo.png"
            hover "images/maps/lower/olo_hover.png"
            xpos 846 ypos 124
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("lower_2")]
            focus_mask None
            mouse "search"
        imagebutton:
            idle "images/maps/lower/duo.png"
            hover "images/maps/lower/duo_hover.png"
            xpos 1004 ypos 589
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("lower_1")]
            focus_mask None
            mouse "search"
        imagebutton:
            idle "images/maps/lower/dur.png"
            hover "images/maps/lower/dur_hover.png"
            xpos 1235 ypos 673
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("lower_3")]
            focus_mask None
            mouse "search"
label map_lower:
    hide screen peta_all
    scene map_lower
    hide screen peta_all
    #play music "MUSIC/MusMus-BGM-124.mp3"
    call screen lower_map
label jmbtn:
    hide screen lower_map
    scene bridge with dissolve
    play sound "sound/effects/tile.mp3"
    "就在你想继续前进时，一位修女拦住了你。"
    $ NPC = "修女"
    play sound "sound/effects/bump.mp3"
    npc "你以为你要去哪？参观村庄是特权，不是权利！" with vpunch
    play sound "sound/effects/cloth.mp3"
    "修女把你拖回了校园。她一直在唠叨学生只有在周末才被允许进入村庄。"
    $ NPC = "???"
    scene map_shops with dissolve
    jump map_store
label catto:
    hide screen lower_map
    if girl:
        show p_side m at pic
    else:
        show side_p m at pic
    mc "你在那儿啊，等等！"
    if girl:
        hide p_side
    else:
        hide side_p
    "猫跑得更远了。"
    $ my_events.append("neko")
    scene map_lower with dissolve
    jump map_lower
label lower_1:
    hide screen lower_map
    scene outer with dissolve
    $ NPC = "???"
    if "mc_bangkit" in my_events:
        npc "你觉得现在搬到西奥德是不是太晚了？"
        npc "莱纳尔的悲剧真的显示了这里有多不安全。"

    elif "beku" in quil_events:
        npc "啊！我简直不敢相信有人把湖面冻住了，我本来想在那里找美人鱼的！"
    elif "io4" in my_events:
        if "ice_rune" in my_events:
            npc "嗯，我一直在想那些湖中幸存者。"
            npc "他们似乎过得不错，即使那一切只是一场梦。"
            npc "如果我是他们，我也会对把他们唤醒的人感到不快。"
        else:
            npc "你觉得我们的新校长这次会更帅吗？"
    elif "vamp_visit" in red_events:
        npc "哈啊...看来塞恩现在是你的丈夫了。那我最好再找个帅哥去勾搭了。"
    elif "bite_day" in red_events:
        npc "所有这些关于塞恩是塔图姆的袭击者的说法让我感到沮丧。"
        npc "为什么总是帅哥啊？！"
    elif "bunga_bego" in buff_events:
        npc "如果这里有花，那么巫师就不会远了。"
        npc "在末日来临之前我要离开这里！"
    elif calendar.day == 15 and calendar.month == '/05':
        $ NPC = "学生A"
        npc "你在西奥德的夏天过得怎么样？"
        $ NPC = "学生B"
        npc "不算坏，但也不算太好。周围的精灵太多了。"
        $ NPC = "学生A"
        npc "嗯，那毕竟是他们的领地，所以..."
    elif "ajax" in fia_events:
        npc "天哪，阿贾克斯和阿什姆的那件事闹得挺大的，不是吗？"
    elif "mey_kill" in my_events and "ntr_talk" not in buff_events:
        $ NPC = "???"
        npc "所以我在考虑邀请那个混血...我是说，那个新来的男孩莱尔，一起去参加节日活动。"
        npc "你疯了吗？他是个巫师？"
        npc "只是一半巫师血统。再说，你看到他的身材了吗？"
        npc "呃，所以这就是你的目的！你真是个荡妇，艾琳！"
        $ NPC = "艾琳"
        npc "我才不是！"
        npc "你怎么看，[povname]？"
        mc "你是问我怎么看你是个荡妇这件事吗？荡妇就是婊子，对吧？"
        npc "不是！我是说，好吧，荡妇确实是婊子，但那不是我在问的！"
        npc "我是说邀请你的室友去参加节日活动！"
        menu:
            "去吧，婊子！":
                $ kindness -= 10
                npc "啊！你知道吗，就为这个，我真的要去做了。谢谢！"
                npc "如果每个人都觉得我是个婊子，那我还不如真的成为一个！"
            "随你便吧。":
                mc "随你便吧。邀请他，或者不邀请他。这不是由我决定的，对吧？"
                npc "好吧，我想是这样。"
                $ honesty += 10
            "我不这么认为。":
                $ putri.points += 5
                mc "你差点叫他混血儿。我不认为像你这样的女孩应该和莱尔这样可爱的男孩在一起。"
                npc "什么，我从来没有！"
        $ NPC = "???"
        $ buff_events.append("ntr_talk")


    elif "day3" in quil_events and calendar.month == '/05':
        $ NPC = "学生A"
        npc "你应该多储备一些符文墨水，听我爸说要出现短缺了。"
        $ NPC = "学生B"
        npc "怎么会？嘿，说起来，符文墨水到底是怎么制作的？"
        $ NPC = "学生A"
        npc "我是说，它们不是由...等等，它们到底是由什么制成的？！"
    
    else:
        $ NPC = "学生A"
        npc "天哪！你看到斯泰西的爸爸了吗？简直是个超级辣爸。"
        $ NPC = "学生B"
        npc "我更喜欢她妈妈。"
    scene map_lower with dissolve
    $ NPC = "???"
    jump map_lower
label lower_3:
    hide screen lower_map
    scene outer with dissolve
    $ NPC = "???"
    if "mc_bangkit" in my_events:
        npc "我简直不敢相信这学期发生了这么多糟糕的事。"
        npc "接下来会怎样？巫师入侵我们的学校？"

    elif "io4" in my_events:
        if "ice_rune" in my_events:
            npc "我为湖边的幸存者感到难过。"
            npc "在天堂中沉睡了几十年后醒来。去他的！"
        else:
            npc "我希望海德温女士没事。我知道她因为这整个校长的事情而感到压力很大。"
    elif "vamp_visit" in red_events:
        npc "[povname]，我不确定你妈妈会赞同塞恩，但这是你的选择。"
        
    elif "bite_day" in red_events:
        npc "我是说，如果塞恩真的是个连环杀手，我还是会上他，只是说说而已。"
        show side_p s at pic
        mc "没有人死！"
        hide side_p
        npc "那就是连环袭击者吧。不过，无论如何，我还是会上他。也许会让他在我们做的时候吸干我。"
        show side_p f at pic
        mc "...你需要耶稣。"
        hide side_p
        npc "耶稣是谁？"
        show side_p s at pic
        mc "没什么。"
        hide side_p
    elif "bunga_bego" in buff_events:
        npc "有时我能听到花朵在哭泣。"
        npc "我几乎为此感到难过。"
    elif "ajax" in fia_events:
        npc "你知道，我一直觉得你配不上阿什姆。嘿[povname]，如果你单身而且有兴趣的话..."
        show side_p s at pic
        mc "现在不行，伙计。我甚至不认识你。"
        hide side_p
    elif "necrosis" in my_events:
        npc "听说你得了符文坏死症。那真糟糕。他们说我们永远无法完全从坏死中恢复，我们的神经会随着时间受损。"
        npc "啊，我不是想吓唬你或什么的！"
    else:
        npc "嘿[povname]，最近在戈莫拉附近接过狩猎任务吗？"
        npc "我在夏天杀了两个巫师，也许我终于可以赶上你的记录了。"
    scene map_lower with dissolve
    jump map_lower
label lower_2:
    hide screen lower_map
    $ NPC = "???"
    scene outer with dissolve
    if calendar.day == 15 and calendar.month == '/05':
        npc "我试图偷偷溜出大门，但没成功。真希望他们能让我们随意去村子里逛逛。"
        npc "我是说，我们这里都是成年人了。"
    else:
        if "mc_bangkit" in my_events:
            npc "我认为美丽巫师是莱纳尔事件的幕后黑手。"
            npc "爆炸发生时，我看到花朵在风中飘动。"
        elif "beku" in quil_events:
            npc "我觉得年轻学生们都很喜欢新的溜冰场。"
            npc "我不知道为什么老师们都对此如此紧张。"
        elif "io4" in my_events:
            if "ice_rune" in my_events:
                npc "我想知道莱纳尔的湖泊幸存者现在怎么样了。"
                npc "希望比这里好。"
            else:
                npc "我希望新校长能尽快到任。"
        elif "vamp_visit" in red_events:
            npc "我很高兴塞恩控制住了他的本能，希望你和他的生活也能顺利。"
        elif "bite_day" in red_events:
            npc "皮尔斯发生的事真是疯狂，但是...你觉得塞恩会想要我当他的血袋吗？"
            npc "我是说，我不介意偶尔被咬一口！"
        elif "bunga_bego" in buff_events:
            npc "我听说盐水可以减缓伊瓦尔花朵的快速生长。" 
            npc "不过不知道为什么。"
        elif "ajax" in fia_events:
            npc "你知道吗，阿贾克斯的父亲实际上已经找了一个破咒师来破解阿什姆设下的整个魔咒？"
            npc "他已经散布了关于阿什姆的消息。现在想找个像样的工作可就难了！"
        elif "q1" in quil_events:
            npc "阿贾克斯说他无意中听到你和奎尔在教堂里的对话。你们没做什么奇怪的事吧？"
            npc "别那样亵渎科尔的教堂！"
        else:
            npc "我听说有个一年级新生有伊瓦尔的眼睛。那真是超级诡异。"
    scene map_lower with dissolve
    jump map_lower
#Lake
screen lake_map():
    tag menu
    
    if "beku" not in quil_events:
        imagebutton:
            idle "images/maps/lake/ex.png"
            hover "images/maps/lake/ex.png"
            xpos 985 ypos 130
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("world_map")]
            focus_mask None
            mouse "search"
        imagebutton:
            idle "images/maps/lake/boat.png"
            hover "images/maps/lake/boat.png"
            xpos 96 ypos 388
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("boat")]
            focus_mask None
            mouse "search"
    else:
        imagebutton:
            idle "images/maps/lake/ex_es.png"
            hover "images/maps/lake/ex_es.png"
            xpos 985 ypos 130
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("world_map")]
            focus_mask None
            mouse "search"
        imagebutton:
            idle "images/maps/lake/boat_es.png"
            hover "images/maps/lake/boat_es.png"
            xpos 96 ypos 388
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("boat")]
            focus_mask None
            mouse "search"
    if "buff_kerja" in buff_events and "day4_end" in my_events:
        imagebutton:
            idle "images/maps/lake/lake_buff.png"
            hover "images/maps/lake/lake_buff.png"
            xpos 967 ypos 148
            hovered [ Play ("test_one", "type.wav")]
            action [Play ("test_one", "stroke.mp3"), Jump("lake_buff")]
            focus_mask None
            mouse "search"
    if "mc_bangkit" in my_events:
            if "beku" not in quil_events:
                imagebutton:
                    idle "images/maps/lake/pike.png"
                    hover "images/maps/lake/pike_hover.png"
                    xpos 797 ypos 201
                    hovered [ Play ("test_one", "type.wav")]
                    action [Play ("test_one", "stroke.mp3"), Jump("mancing_mania")]
                    focus_mask None
                    mouse "search"
    if "seth_hint" not in buff_events:    
        
        if "met_pike" in my_events:
            if "beku" not in quil_events and "mc_bangkit" not in my_events:
                imagebutton:
                    idle "images/maps/lake/pike.png"
                    hover "images/maps/lake/pike_hover.png"
                    xpos 797 ypos 201
                    hovered [ Play ("test_one", "type.wav")]
                    action [Play ("test_one", "stroke.mp3"), Jump("pike")]
                    focus_mask None
                    mouse "search"
        else:
            imagebutton:
                idle "images/maps/lake/pike.png"
                hover "images/maps/lake/pike_hover.png"
                xpos 797 ypos 201
                hovered [ Play ("test_one", "type.wav")]
                action [Play ("test_one", "stroke.mp3"), Jump("fisherman")]
                focus_mask None
                mouse "search"
label map_lake:
    if calendar.day == 8 and calendar.month == '/06':
        if "seth_hint" not in buff_events and "mc_bangkit" not in my_events:
            jump lyal_seth_hint
        else:
            if "beku" in quil_events:
                scene map_lakef
            else:
                scene map_lake
            hide screen peta_all
            #play music "MUSIC/MusMus-BGM-109.mp3"
            call screen lake_map
    elif "beku" in quil_events:
        if "seth_hint" not in buff_events and "mc_bangkit" not in my_events:
            jump lyal_seth_hint
        else:
            if "beku" in quil_events:
                scene map_lakef
            else:
                scene map_lake
            hide screen peta_all
            #play music "MUSIC/MusMus-BGM-109.mp3"
            call screen lake_map
    elif calendar.day == 24 and calendar.month == '/05' and "desa" not in buff_events:
        jump lyal_ker_bar
    elif "fish2" in active_quests and "fishdate" not in buff_events:
        if calendar.weekday == "Sat" or calendar.weekday == "Sun":
            if "bunga_bego" in buff_events:
                if "beku" in quil_events:
                    scene map_infected_f with dissolve
                else:
                    scene map_infected with dissolve
            else:
                if "beku" in quil_events:
                    scene map_frozen with dissolve
                else:
                    scene map_all with dissolve
            jump world_map
        else:
            jump buff_fish1
    else:
        if calendar.weekday == "Sat" or calendar.weekday == "Sun":
            if "bunga_bego" in buff_events:
                if "beku" in quil_events:
                    scene map_infected_f with dissolve
                else:
                    scene map_infected with dissolve
            else:
                if "beku" in quil_events:
                    scene map_frozen with dissolve
                else:
                    scene map_all with dissolve
            jump world_map
        else:
            scene map_lake
            hide screen peta_all
            #play music "MUSIC/MusMus-BGM-109.mp3"
            call screen lake_map
label lyal_seth_hint:
    hide screen lake_map
    $ buff_events.append("seth_hint")
    $ NPC = "派克"
    scene lake with dissolve
    show buff datar at center with dissolve:
        yoffset 770
    "你下楼时看到莱尔和派克在聊天。"
    if "beku" in quil_events:
        show side_pike_f at pic
        npc "好吧，我想我在这里的钓鱼生涯结束了！"
        hide side_pike_f
        buff sad sigh "抱歉，派克。"
        show side_pike_s at pic
        npc "别摆出那副愁眉苦脸的样子嘛？你还是会经常见到我的，小家伙！"
        npc "可能要去应付镇上那些吝啬的屠夫了。"
        npc "再说，玛格丽特一直让我退休。我已经老得干不动这活了。"
        npc "也许这就是生活告诉我该轻松点的方式。"
        npc "不过我想我不会在莱纳尔多待了。"
        hide side_pike_s
        buff frown -sigh "哦？为什么不呢？"
        show side_pike_f at pic
        npc "主要是难以接受。那些从湖里回来的人？"
        npc "我的儿子永远离开了，而一些混蛋却能让他们的儿子女儿回来。"
        npc "你知道卡莱尔以前经常把他老婆打得半死吗？她跳进水里是为了自救。"
        npc "然而不知怎的，他的老婆回来了，而我的儿子却还在水下某处腐烂。"
        npc "这不公平。这真他妈的不公平。"
        hide side_pike_f
        buff sad"哦，先生。我——"
    else:
        buff sad "等等，你要离开？你不再在我们的水域钓鱼了吗？"
        show side_pike_f at pic
        npc "教会的命令，一个穿着神父服的小鬼告诉我该走了，说我在\'污染犯罪现场\'还是什么意思。"
        npc "真抱歉，小家伙，但我得走了。"
        hide side_pike_f
        buff frusta "哦，那...那太糟糕了。"
        show side_pike_s at pic
        npc "哦，别担心。你随时欢迎来拜访，小家伙！你知道你会成为一个出色的渔夫，有没有考虑过在莱纳尔定居？"
        npc "我认识一些儿子和女儿，他们会很乐意和你这样优秀的年轻人建立关系。"
        hide side_pike_s
        buff wry sigh "啊，从您口中听到这话，我感到非常荣幸，先生。不过，我在这里还有职责。如果情况不同的话，我很乐意接受。"
        buff laugh bunga "莱纳已经成为我的家了。"
        show side_pike_s at pic
        npc "是吗？那我很高兴。我打赌是培根吸引了你，哈哈。我们的火腿可是传说级的！"
        hide side_pike_s
        buff datar -bunga "其实是您，先生。您和玛格丽特。我感觉你们两个就像我从未拥有过的父母。"
        show side_pike_s at pic
        npc "嗯。嗯，我很高兴你这么想。"
        npc "我相信如果我儿子还活着，你们两个也会相处得很好。"
        hide side_pike_s
        buff wry "我也这么认为。"
        buff datar "他是个什么样的人？"
        show side_pike_s at pic
        npc "吵闹。而且开朗，我发誓那孩子的笑容比太阳还要灿烂。"
        hide side_pike_s
        show buff sad
        show side_pike_f at pic
        npc "我一直不明白为什么这样的孩子要这么年轻就离开。"
        npc "这...这不公平。"
        hide side_pike_f
        buff sad "哦，对不起，我不是有意勾起不好的回忆。"
        show side_pike_f at pic
        npc "不，没关系。我其实很高兴有人问起。我已经不太记得米卡埃尔的样子了。"
        npc "可能是我老了，但...我害怕有一天我会忘记他。不是完全忘记，而是他的脸，他的笑容，他的笑声。"
        hide side_pike_s
    show side_pike_f at pic
    npc "你知道，有时我在想我是否能把他带回来。最近我...有些动摇。"
    npc "岛上有关于让死者复活的传言。"
    hide side_pike_f
    buff keluh apa "让死者复活？"
    show side_pike_f at pic
    npc "是的，我知道这听起来很荒谬，但有些人认为这就是最近很多孩子失踪的原因。"
    npc "他们被当作祭品。为了什么，被谁，嗯...我只能想象。我没想到我会..."
    hide side_pike_f
    buff sad -apa "你会什么？"
    show side_pike_s at pic
    npc "哦，别听一个老人的胡言乱语！我只是在胡思乱想。"
    npc "总之孩子，我该走了。别见外，好吗？"
    hide side_pike_s
    buff wry sigh"再见，派克。"
    if "beku" in quil_events:
        "派克滑着冰鞋，穿过平坦的冰冻湖面，回到他的岛上。"
        "远处，你可以看到其他孩子也在和父母或年长的兄弟姐妹一起滑冰。"
        show side_p he at pic
        mc "（嗯，至少莱纳的人们并不介意我们冻结这个湖面。）"
        hide side_p
        buff talk sigh "你说得对。"
        show buff at right with move
        if girl:
            show palmierproxy chill wry at left with moveinleft:
                yoffset 40
        else:
            show palmierproxy chill wry at left with moveinleft:
                yoffset 100
        mc apa sweat tanya "等等，我又大声说出来了吗？"
        buff wry -sigh "是啊。你经常这样，你知道吗？"
        mc confused -sweat -tanya "你知道我在这里多久了？"
    else:
        "派克划船回到莱纳，莱尔默默地挥手告别。"
        buff wry apa "...那么，你打算说点什么还是就这么尴尬地站在那里看着？"
        show buff at right with move
        if girl:
            show palmierproxy chill wry at left with moveinleft:
                yoffset 40
        else:
            show palmierproxy chill wry at left with moveinleft:
                yoffset 100
        mc confused "哦，你知道我在这里？"
    buff keluh sigh "就在最后。我没说什么是因为...嗯，我有点想要有人陪伴。"
    buff sad -sigh "我...我现在不想一个人。"
    show pboy at horzappear
    menu:
        "需要一个拥抱吗？":
            hide pboy
            show palmierproxy wry blush tanya
            buff eh sweat shock "哦，我——"
            show palmierproxy smile -tanya
            buff wry blush sigh "我非常想要，拜托了。"
            show palmierproxy at center with move
            show buff laugh blush bunga
            "你紧紧地抱住了莱尔。他的触碰很温柔，就像害怕一个错误的动作会伤到你。"
            "他的手指在颤抖，但心跳却缓慢而稳定。你上下抚摸着他的背，他深深地叹了口气。"
            "释然。"
            buff wry "我一生中没有拥抱过很多人。伊尔夫，我的兄弟，可能是唯一的一个。我...我需要这个。"
            mc kind sigh "我很高兴能帮上忙。"
            mc wry tanya "你知道，如果你想聊聊，我随时在这里。"
            buff talk sigh "嗯。你知道吗，你完全不是我想象中的样子。我们第一次见面时，我真的以为你是个冷酷无情的猎巫人。"
            show palmierproxy kind -tanya
            buff laugh -sigh "但你不是，你很温柔，很善良。你也很爱管闲事，但...我喜欢你这一点。"
            buff wry "这只是表明你在乎。"
            buff datar "在我的生命中，没有多少这样的人。你、伊尔夫和派克是我现在唯一拥抱过的人。"
            mc frown -blush "哦，派克拥抱过你？"
            buff hister sigh "是的，在我捕到一条大鱼后。他看起来很自豪，称我为他的儿子，但他后来纠正了这个说法。"
            buff keluh -blush -sigh "我倒是不介意，他现在是我最接近父亲的人，但...我想他不想这样来不尊重他的儿子。"
            buff sad "用另一个儿子替代另一个。"
        "你为什么这么难过？":
            hide pboy
            show palmierproxy sad 
            buff keluh sweat sigh "我...我不知道。也许是因为我把他当成了父亲般的人物？"
            buff sad -sigh "我知道他并不是我真正的父亲，而且他只是一帆之遥，但是——"
            buff "我...我和他在一起感到安全。受到保护。"
            buff scold frusta "在我的生命中，像这样的人并不多。而当我有一个这样的人时，他们通常都会遭遇可怕的死亡。"
            buff sad sigh "所以我至少是有些偏执。"
            mc wry "他会没事的。莱纳没有巫师，对吧？"
            buff kzl -sigh "我不敢确定。巫师可能在任何地方。也许这个巫师只是在等待时机，玩弄她的猎物。"

        "他看起来很烦恼。":
            hide pboy
            show palmierproxy confused
            buff keluh sweat apa "你也注意到了？"
            buff sad -apa "我想知道他在想什么。他最近有点不对劲。"
            buff kzl "他经常盯着孩子们看，有时钓鱼时会呆呆地盯着。"
            buff keluh "也许只是校园里的恐慌情绪影响了他。"
            buff sad "最近发生了很多事。"
    buff frown sigh "不管怎样，我该走了。我还有作业要做。"
    #berubah
    if "rampage" in fia_events:
        #berubah
        buff keluh frusta "新来的魔药学老师是个很严格的修女。我想念波比。她很温柔。"
        buff sad sigh "但我想每个人都有自己阴暗的一面。"
    buff wry -sigh "再见，[povname]。"
    mc kind sigh"再见"
    $ NPC = "???"
    if "bunga_bego" in buff_events:
        if "beku" in quil_events:
            scene map_infected_f with dissolve
        else:
            scene map_infected with dissolve
    else:
        if "beku" in quil_events:
            scene map_frozen with dissolve
        else:
            scene map_all with dissolve
    jump world_map


    
label lake_buff:
    hide screen lake_map
    scene lake with dissolve
    show buff frown at center with dissolve:
        yoffset 770
    if "culik" in fia_events and "date5_done" not in buff_events:
        buff "嗨，[povname]。你的伤怎么样了？"
        show side_p se at pic
        mc "好多了，你呢？"
        hide side_p
        buff "身体上我没事，情感上嘛，呃...你有时间吗？"
        show pboy at horzappear
        menu:
            "当然有！":
                hide pboy
                jump buff_date5 
            "也许待会儿？":
                hide pboy
                show side_p f at pic
                mc "我现在有点忙，也许待会儿吧，好吗？"
                buff "好-好吧..."
                hide side_p
                if "beku" in quil_events:
                    scene map_lakef with dissolve
                else:
                    scene map_lake with dissolve
                jump map_lake
        
    elif "culik" not in fia_events and "date3_done" in buff_events and "date4_done" not in buff_events:
        buff "[povname]，我们能谈谈吗？有些事...有些事我需要告诉你。"
        show side_p f at pic
        mc "哦？"
        hide side_p
        show pboy at horzappear
        menu:
            "当然可以！":
                hide pboy
                if putri.points>= 80:
                    jump buff_date4  
                else:
                    jump buff_date_check      
            "也许待会儿？":
                hide pboy
                show side_p f at pic
                mc "我现在有点忙，也许待会儿吧，好吗？"
                buff "好-好吧..."
                hide side_p
                if "beku" in quil_events:
                    scene map_lakef with dissolve
                else:
                    scene map_lake with dissolve
                jump map_lake
    else:
        show side_p se at pic
        mc "莱尔！"
        hide side_p
        buff "哦，嗨。"
        if putri.points > 10 and "gift1" not in buff_events:
            buff amused apa "哦对了，[povname]，我抓到了一条稀有的神仙鱼，如果你想要的话。你要吗？"
            $ InvItem(*item_angel).pickup(2)
            show side_p se at pic
            $ buff_events.append("gift1")
            mc "哦！我正需要那个！谢谢。"
            hide side_p
            buff datar -apa "不客气。"                
            buff "话说，你在这里做什么？"
        elif putri.points > 30 and "gift2" not in buff_events:
            buff amused apa "哦对了，[povname]，我抓到了几只章鱼，你要吗？"
            $ InvItem(*item_octo).pickup(3)
            $ buff_events.append("gift2")
            show side_p se at pic
            mc "我要！谢谢，莱尔！"
            hide side_p
            buff datar -apa "不客气。"                
            buff "话说，你在这里做什么？"
        else:
            buff "你在这里做什么？"

        show pboy at horzappear
        menu:
            "找你啊！":
                hide pboy
                buff keluh apa "我？"
                show buff eh shock
                show side_p f at pic
                mc "想一起出去玩吗？"
                hide side_p
                if "mc_bangkit" in my_events:
                    buff sigh "抱歉，但我现在不想一起玩。"
                    buff wry apa "你和其他人谈过了吗？在回到你的世界之前，你应该和每个人都谈谈。"
                    if "beku" in quil_events:
                        scene map_lakef with dissolve
                    else:
                        scene map_lake with dissolve
                    jump map_lake
                elif "rooted" not in buff_events:
                    buff wry -sigh "哦，好吧...好的。"
                else:
                    if "reject" in buff_events:
                        buff sad "啊，抱歉，也许从现在开始我们最好不要再一起玩了，[povname]。"
                        buff "我...我觉得这样对我们更健康。"
                        mc "哦，呃...好吧。"
                        hide side_p
                        if "beku" in quil_events:
                            scene map_lakef with dissolve
                        else:
                            scene map_lake with dissolve
                        jump map_lake
                    elif "desa" in buff_events or 'ketemu_buli' in buff_events:
                        buff wry -sigh "哦，好吧...好的。"

                    else:
                        buff sad frusta "我还是不要了。"
                        show side_p f at pic
                        mc "哦，呃...好吧。"
                        hide side_p
                        if "beku" in quil_events:
                            scene map_lakef with dissolve
                        else:
                            scene map_lake with dissolve
                        jump map_lake
                jump buff_date_check
            "哦，没什么。":
                hide pboy
                show side_p f at pic
                mc "只是路过。"
                hide side_p
                if "beku" in quil_events:
                    scene map_lakef with dissolve
                else:
                    scene map_lake with dissolve
                
        jump map_lake
    
label fisherman:
    hide screen lake_map
    scene fishing with dissolve
    $ NPC = "???"
    npc "需要什么吗，小子？"
    if girl:
        show p_side f at pic
    else:
        show side_p f at pic
    mc "你是谁啊？"
    if girl:
        hide p_side
    else:
        hide side_p
    $ NPC = "派克"
    show side_pike_s at pic
    npc "我叫派克。是来自莱纳尔的渔夫。"
    npc "那边鱼不上钩，所以我想来这里试试运气。"
    hide side_pike_s
    if girl:
        show p_side f at pic
    else:
        show side_p f at pic
    mc "莱纳尔？"
    if girl:
        hide p_side
    else:
        hide side_p
    show side_pike_s at pic
    npc "是南边的一个小岛。我看到你们这些小孩周末经常在那里晃悠。"
    npc "我们那里的火腿很不错，比其他地方都好！"
    hide side_pike_s
    if girl:
        show p_side f at pic
    else:
        show side_p f at pic
    mc "原来如此。那么，这里鱼上钩吗？"
    if girl:
        hide p_side
    else:
        hide side_p
    show side_pike_s at pic
    npc "还不错，比莱纳尔好。"
    npc "不过不知道为什么，通常这个季节鱼都很多的。也许是因为那个该死的木偶戏演员把连鱼都吓跑了。"
    hide side_pike_s
    if girl:
        show p_side f at pic
    else:
        show side_p f at pic
    mc "木偶戏演员？"
    if girl:
        hide p_side
    else:
        hide side_p
    show side_pike_s at pic
    npc "一个矮小阴郁的男人，孩子们喜欢他的表演，但我觉得那家伙有点不对劲。"
    npc "不过我猜你们这些孩子可能也会这么说我。"
    npc "你是这里第一个敢直视我眼睛的小鬼，哈哈！你会钓鱼吗，小子？"
    hide side_pike_s
    if girl:
        show p_side f at pic
    else:
        show side_p f at pic
    mc "会一点，我叔叔以前带我去钓过一两次鱼。"
    if girl:
        hide p_side
    else:
        hide side_p
    show side_pike_s at pic
    npc "是吗。想试试吗？"
    hide side_pike_s
    $ cepat = 0
    $ fable_minigame_bar = 90
    $ d6roll = 0
    $ d6roll = renpy.random.randint(1, 21)
    if d6roll <=3:
        $ cepat = 2
    elif d6roll >18:
        $ cepat = 1
    elif d6roll >3 and d6roll<=6:
        $ cepat = 4
    elif d6roll >6 and d6roll<=9:
        $ cepat = 3
    elif d6roll >9 and d6roll<=12:
        $ cepat = 5
    elif d6roll >12 and d6roll<= 15:
        $ cepat = 6
    else:
        $ cepat = 2
    jump start_minigame
label end_good:
    hide screen fable_2_minigame
    hide screen fable_timer_left
    hide screen fable_timer_right
    if calendar.weekday == "Sat" or calendar.weekday == "Sun":
        scene lake with dissolve
    else:
        scene fishing with dissolve
    #$ d6roll = 0
    #$ d6roll = renpy.random.randint(1, 11)
    if d6roll <=3:
        $ newitem = InvItem(*set_item("item_fish"))
    elif d6roll >18:
        $ newitem = InvItem(*set_item("item_turtle"))
    elif d6roll >3 and d6roll<=6:
        $ newitem = InvItem(*set_item("item_octo"))
    elif d6roll >6 and d6roll<=9:
        $ newitem = InvItem(*set_item("item_clown"))
    elif d6roll >9 and d6roll<=12:
        $ newitem = InvItem(*set_item("item_angel"))
    elif d6roll >12 and d6roll<= 15:
        $ newitem = InvItem(*set_item("item_jelly"))
    else:
        $ newitem = InvItem(*set_item("item_eel"))
    #$ newitem = InvItem(*item_fish)
    play sound "sfx/btn16.mp3"
    show screen reward(newitem.image)
    $ newitem.pickup()
    "获得了{color=#d48}[newitem.name!t]{/color}！"
    hide screen reward
    if "met_pike" in my_events:
        if check_inv_for(bait_items):
            if calendar.weekday == "Sat" or calendar.weekday == "Sun":
                if girl:
                    show pboy s at horzappear
                else:
                    show pboy s at horzappear
            else:
                if girl:
                    show pboy at horzappear
                else:
                    show pboy at horzappear
            menu:
                "再钓一次":
                    hide pboy
                    $ cepat = 0
                    $ fable_minigame_bar = 90
                    $ InvItem(*item_bait).toss(1)
                    $ d6roll = 0
                    $ d6roll = renpy.random.randint(1, 21)
                    if d6roll <=3:
                        $ cepat = 2
                    elif d6roll >18:
                        $ cepat = 1
                    elif d6roll >3 and d6roll<=6:
                        $ cepat = 4
                    elif d6roll >6 and d6roll<=9:
                        $ cepat = 3
                    elif d6roll >9 and d6roll<=12:
                        $ cepat = 5
                    elif d6roll >12 and d6roll<= 15:
                        $ cepat = 6
                    else:
                        $ cepat = 2
                    jump start_minigame
                "暂时结束":
                    hide pboy
                    $ NPC = "???"
                    jump map_lake
        else:
            if calendar.weekday == "Sat" or calendar.weekday == "Sun":
                scene lake with dissolve
            else:
                scene map_lake with dissolve
            jump map_lake
    else:
        show side_pike_s at pic
        npc "我去，不错嘛。"
        npc "告诉你吧小子，鱼竿留着。我还有备用的。"
        hide side_pike_s
        if girl:
            show p_side se at pic
        else:
            show side_p se at pic
        mc "你确定吗？"
        if girl:
            hide p_side
        else:
            hide side_p
        show side_pike_s at pic
        npc "是的，有了这么多新奇玩意和符文，这种钓鱼方式快要失传了。"
        npc "很高兴遇到一个同行。"
        npc "好了，我要继续钓鱼了。别见外啊，小子。"
        hide side_pike_s
        $ my_events.append("met_pike")
        scene map_lake with dissolve
        $ NPC = "???"
        jump map_lake
label end:
    hide screen fable_2_minigame
    hide screen fable_timer_left
    hide screen fable_timer_right
    if calendar.weekday == "Sat" or calendar.weekday == "Sun":
        scene lake with dissolve
    else:
        scene fishing with dissolve
    if girl:
        show p_side m at pic
    else:
        show side_p m at pic
    mc "该死！鱼跑了。"
    if girl:
        hide p_side
    else:
        hide side_p
    if "met_pike" in my_events:
        if check_inv_for(bait_items):
            if calendar.weekday == "Sat" or calendar.weekday == "Sun":
                if girl:
                    show pboy s at horzappear
                else:
                    show pboy s at horzappear
            else:
                if girl:
                    show pboy at horzappear
                else:
                    show pboy at horzappear
            menu:
                "再钓一次":
                    hide pboy
                    $ InvItem(*item_bait).toss(1)
                    $ cepat = 0
                    $ fable_minigame_bar = 90
                    $ d6roll = 0
                    $ d6roll = renpy.random.randint(1, 21)
                    if d6roll <=3:
                        $ cepat = 2
                    elif d6roll >18:
                        $ cepat = 1
                    elif d6roll >3 and d6roll<=6:
                        $ cepat = 4
                    elif d6roll >6 and d6roll<=9:
                        $ cepat = 3
                    elif d6roll >9 and d6roll<=12:
                        $ cepat = 5
                    elif d6roll >12 and d6roll<= 15:
                        $ cepat = 6
                    else:
                        $ cepat = 2
                    jump start_minigame
                "暂时结束":
                    hide pboy
                    $ NPC = "???"
                    if calendar.weekday == "Sat" or calendar.weekday == "Sun":
                        jump world_map
                    else:
                        jump map_lake
        else:
            if calendar.weekday == "Sat" or calendar.weekday == "Sun":
                scene lake with dissolve
            else:
                scene map_lake with dissolve
            jump map_lake
    else:
        $ NPC = "派克"
        show side_pike_s at pic
        npc "收线太快了。我儿子以前也总是这样。"
        hide side_pike_s
        if girl:
            show p_side f at pic
        else:
            show side_p f at pic
        mc "哦，你儿子也是渔夫吗？"
        if girl:
            hide p_side
        else:
            hide side_p
        show side_pike_f at pic
        npc "他本可能成为渔夫的。一个巫师在他10岁时杀了他。"
        hide side_pike_f
        if girl:
            show p_side s at pic
        else:
            show side_p s at pic
        mc "哦……"
        if girl:
            hide p_side
        else:
            hide side_p
        show side_pike_s at pic
        npc "别担心，这已经是15年前的事了，别摆出那副表情。"
        npc "总之，如果你想要的话可以留着鱼竿，我还有备用的。我也可以多个伴。"
        npc "有个伙伴可以炫耀我的渔获，钓鱼总是更有意思，哈哈！"
        hide side_pike_s
        if girl:
            show p_side se at pic
        else:
            show side_p se at pic
        mc "好的，谢谢。"
        if girl:
            hide p_side
        else:
            hide side_p
        $ NPC = "???"
        $ my_events.append("met_pike")
        scene map_lake with dissolve
        jump map_lake
label end_bad:
    hide screen fable_2_minigame
    hide screen fable_timer_left
    hide screen fable_timer_right
    if calendar.weekday == "Sat" or calendar.weekday == "Sun":
        scene lake with dissolve
    else:
        scene fishing with dissolve
    if girl:
        show p_side m at pic
    else:
        show side_p m at pic
    mc "该死！鱼跑了。"
    if girl:
        hide p_side
    else:
        hide side_p
    if "met_pike" in my_events:
        if check_inv_for(bait_items):
            if calendar.weekday == "Sat" or calendar.weekday == "Sun":
                if girl:
                    show pboy s at horzappear
                else:
                    show pboy s at horzappear
            else:
                if girl:
                    show pboy at horzappear
                else:
                    show pboy at horzappear
            menu:
                "再钓一次":
                    hide pboy
                    $ InvItem(*item_bait).toss(1)
                    $ cepat = 0
                    $ fable_minigame_bar = 90
                    $ d6roll = 0
                    $ d6roll = renpy.random.randint(1, 21)
                    if d6roll <=3:
                        $ cepat = 2
                    elif d6roll >18:
                        $ cepat = 1
                    elif d6roll >3 and d6roll<=6:
                        $ cepat = 4
                    elif d6roll >6 and d6roll<=9:
                        $ cepat = 3
                    elif d6roll >9 and d6roll<=12:
                        $ cepat = 5
                    elif d6roll >12 and d6roll<= 15:
                        $ cepat = 6
                    else:
                        $ cepat = 2
                    jump start_minigame
                "暂时结束":
                    hide pboy
                    $ NPC = "???"
                    jump map_lake
        else:
            if calendar.weekday == "Sat" or calendar.weekday == "Sun":
                scene lake with dissolve
            else:
                scene map_lake with dissolve
            jump map_lake
    else:
        $ NPC = "派克"
        show side_pike_s at pic
        npc "收线太快了。我儿子以前也总是这样。"
        hide side_pike_s
        if girl:
            show p_side f at pic
        else:
            show side_p f at pic
        mc "哦，你儿子也是渔夫吗？"
        if girl:
            hide p_side
        else:
            hide side_p
        show side_pike_f at pic
        npc "他本可能成为渔夫的。一个巫师在他10岁时杀了他。"
        hide side_pike_f
        if girl:
            show p_side s at pic
        else:
            show side_p s at pic
        mc "哦……"
        if girl:
            hide p_side
        else:
            hide side_p
        show side_pike_s at pic
        npc "别担心，这已经是15年前的事了，别摆出那副表情。"
        npc "总之，如果你想要的话可以留着鱼竿，我还有备用的。我也可以多个伴。"
        npc "有个伙伴可以炫耀我的渔获，钓鱼总是更有意思，哈哈！"
        hide side_pike_s
        if girl:
            show p_side se at pic
        else:
            show side_p se at pic
        mc "好的，谢谢。"
        if girl:
            hide p_side
        else:
            hide side_p
        $ my_events.append("met_pike")
        $ NPC = "???"
        scene map_lake with dissolve
        jump map_lake
label not_pike:
    hide screen lake_map
    scene map_lakef
    $ NPC = "???"
    npc "湖面结冰了，我不能在这里钓鱼了。我现在上哪儿去弄鱼呢？"
    $ NPC = "???"
    scene map_lake with dissolve
    jump map_lake
label mancingin:
    hide screen peta_all
    scene lake with dissolve
    show pboy s at horzappear
    menu:
        "钓鱼？":
            hide pboy
            if not check_inv_for(bait_items):
                "你需要鱼饵才能钓鱼。"

                $ NPC = "???"
                jump world_map
            else:
                $ InvItem(*item_bait).toss(1)
                $ d6roll = 0
                $ cepat = 0
                $ fable_minigame_bar = 90
                $ d6roll = renpy.random.randint(1, 21)
                if d6roll <=3:
                    $ cepat = 2
                elif d6roll >18:
                    $ cepat = 1
                elif d6roll >3 and d6roll<=6:
                    $ cepat = 4
                elif d6roll >6 and d6roll<=9:
                    $ cepat = 3
                elif d6roll >9 and d6roll<=12:
                    $ cepat = 5
                elif d6roll >12 and d6roll<= 15:
                    $ cepat = 6
                else:
                    $ cepat = 2
                jump start_minigame
        "现在不行。":
            hide girl
            hide pboy

            $ NPC = "???"
            jump world_map

label pike:
    hide screen lake_map
    scene fishing with dissolve
    $ NPC = "派克"
    npc "来和我一起钓鱼吗？"
    if girl:
        show girl at horzappear
    else:
        show pboy at horzappear
    menu:
        "和派克一起钓鱼？":
            hide girl
            hide pboy
            if not check_inv_for(bait_items):
                "你需要鱼饵才能钓鱼。"

                $ NPC = "???"
                jump map_lake
            else:
                $ InvItem(*item_bait).toss(1)
                $ d6roll = 0
                $ cepat = 0
                $ fable_minigame_bar = 90
                $ d6roll = renpy.random.randint(1, 21)
                if d6roll <=3:
                    $ cepat = 2
                elif d6roll >18:
                    $ cepat = 1
                elif d6roll >3 and d6roll<=6:
                    $ cepat = 4
                elif d6roll >6 and d6roll<=9:
                    $ cepat = 3
                elif d6roll >9 and d6roll<=12:
                    $ cepat = 5
                elif d6roll >12 and d6roll<= 15:
                    $ cepat = 6
                else:
                    $ cepat = 2
                jump start_minigame
        "现在不行。":
            hide girl
            hide pboy

            $ NPC = "???"
            jump map_lake

label mancing_mania:
    hide screen lake_map
    scene fishing with dissolve
    $ NPC = "凯姆"
    npc "哦嘿[povname]？现在那个来自莱纳尔的奇怪渔夫走了，我又开始在这里钓鱼了。"
    npc "想加入吗？"
    if girl:
        show girl at horzappear
    else:
        show pboy at horzappear
    menu:
        "钓鱼？":
            hide girl
            hide pboy
            if not check_inv_for(bait_items):
                "你需要鱼饵才能钓鱼。"

                $ NPC = "???"
                jump map_lake
            else:
                $ InvItem(*item_bait).toss(1)
                $ d6roll = 0
                $ cepat = 0
                $ fable_minigame_bar = 90
                $ d6roll = renpy.random.randint(1, 21)
                if d6roll <=3:
                    $ cepat = 2
                elif d6roll >18:
                    $ cepat = 1
                elif d6roll >3 and d6roll<=6:
                    $ cepat = 4
                elif d6roll >6 and d6roll<=9:
                    $ cepat = 3
                elif d6roll >9 and d6roll<=12:
                    $ cepat = 5
                elif d6roll >12 and d6roll<= 15:
                    $ cepat = 6
                else:
                    $ cepat = 2
                jump start_minigame
        "现在不行。":
            hide girl
            hide pboy

            $ NPC = "???"
            jump map_lake

label boat:
    hide screen lake_map
    if "met_pike" in my_events:
        "派克的船。你最好别碰它。"
    else:
        "某人的船。你最好别碰它。"

    jump map_lake

#Fountain
screen fountain_map():
    tag menu
    imagebutton:
        idle "images/maps/fountain/to.png"
        hover "images/maps/fountain/to_hover.png"
        xpos 1125 ypos 337
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("fountain_3")]
        focus_mask None
        mouse "search"
    imagebutton:
        idle "images/maps/fountain/lady.png"
        hover "images/maps/fountain/lady_hover.png"
        xpos 1748 ypos 605
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("fountain_0")]
        focus_mask None
        mouse "search"
    imagebutton:
        idle "images/maps/fountain/change.png"
        hover "images/maps/fountain/change_hover.png"
        xpos 650 ypos 346
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("fountain_4")]
        focus_mask None
        mouse "search"
    imagebutton:
        idle "images/maps/fountain/tung.png"
        hover "images/maps/fountain/tung_hover.png"
        xpos 543 ypos 688
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("fountain_5")]
        focus_mask None
        mouse "search"
    imagebutton:
        idle "images/maps/fountain/2.png"
        hover "images/maps/fountain/2_hover.png"
        xpos 782 ypos 493
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("fountain_2")]
        focus_mask None
        mouse "search"
    imagebutton:
        idle "images/maps/fountain/dan.png"
        hover "images/maps/fountain/dan.png"
        xpos 877 ypos 273
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("fountain_1")]
        focus_mask None
        mouse "search"
    imagebutton:
        idle "images/maps/fountain/dorm.png"
        hover "images/maps/fountain/dorm.png"
        xpos 1120 ypos 33
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("world_map")]
        focus_mask None
        mouse "search"
    imagebutton:
        idle "images/maps/fountain/curt.png"
        hover "images/maps/fountain/curt.png"
        xpos 1275 ypos 84
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("music", "MUSIC/MusMus-BGM-037.mp3"),Play ("test_one", "stroke.mp3"), Jump("map_court")]
        focus_mask None
        mouse "search"
    imagebutton:
        idle "images/maps/fountain/kl.png"
        hover "images/maps/fountain/kl.png"
        xpos 501 ypos 27
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("music", "MUSIC/MusMus-BGM-049.mp3"),Play ("test_one", "stroke.mp3"), Jump("map_kelas")]
        focus_mask None
        mouse "search"
    imagebutton:
        idle "images/maps/fountain/are.png"
        hover "images/maps/fountain/are.png"
        xpos 112 ypos 286
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("world_map")]
        focus_mask None
        mouse "search"
    imagebutton:
        idle "images/maps/fountain/tempu.png"
        hover "images/maps/fountain/tempu.png"
        xpos 1114 ypos 640
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("world_map")]
        focus_mask None
        mouse "search"
    imagebutton:
        idle "images/maps/fountain/baw.png"
        hover "images/maps/fountain/baw.png"
        xpos 0 ypos 843
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("world_map")]
        focus_mask None
        mouse "search"
label map_fountain:
    hide screen peta_all
    if "ink_sms" in quil_events and "date2_done" not in quil_events:
        jump quil_date2
    else:
        scene map_tengah
        #play music "MUSIC/MusMus-BGM-108.mp3"
        call screen fountain_map
label fountain_0:
    hide screen fountain_map
    scene tengah with dissolve
    $ NPC = "???"
    if "pin" not in my_events:
        $ my_events.append("pin")
        npc "嘿，你！你有没有看到一个金色的、翅膀形状的发夹？我在找它。"
    else:    
        if "rooted" in buff_events:
            if "ice1" in completed_quests:
                npc "还是没找到那些人鱼之泪。该死，难道我的实验要就此结束了吗？"
            elif "ice1" in active_quests and "ice1" not in completed_quests:
                python:
                    InvItem(*item_up).pickup(1)
                    active_quests.remove("ice1")
                    completed_quests.insert(0, "ice1")
                mc "这是你要的冰晶。"
                npc "哦，谢谢！跟我来，这种药水应该不需要太长时间就能熬好。"
                "熬制完药水后，你和英格丽德决定在那株生根的植物上试验一下。"
                "滴了几滴后，植物似乎毫无反应，在花瓣冻结后反而扩张并长出更多根系。"
                npc "天哪，看来这完全是个失败！"
                mc "也许你需要更冷的东西？"
                npc "更冷。嗯，也许我可以用人鱼之泪作为试剂？嗯，那可能会有效。"
                npc "不过，你还是留着这个吧。"
                mc "但我要它做什么呢？"
                npc "我不知道，也许你家里的冰箱坏了？想在浴缸里打造自己的冬日仙境？"
                npc "也许在战斗中会有帮助？重点是，暂时就把这个当作你的奖励吧！"
                show screen completedtask("任务完成！")
                npc "等我拿到人鱼之泪后，我一定会再次寻求你的帮助。不过可能要等一段时间。"
            elif "ice1" not in active_quests and "ice1" not in completed_quests:
                $ NPC = "英格丽德"
                npc "我看透你了，你知道吗？"
                show side_p f at pic
                mc "啊？"
                hide side_p
                npc "我看到你和那朵花在一起。伊瓦尔的花。"
                npc "你很幸运我还没有举报你。"
                show side_p f at pic
                mc "等等，你看到了？"
                hide side_p
                npc "是的。我之所以没有向校长汇报，是因为我对它有自己的计划。"
                show side_p f at pic
                mc "那是什么？"
                hide side_p
                npc "洛基之霜！"
                show side_p f at pic
                mc "啊？"
                hide side_p
                npc "我有个理论，伊瓦尔的花可以被冻死。既然切割和燃烧都没用，为什么不试试冻结呢？"
                npc "但不能是普通的冰冻咒语。必须是洛基的。冰雪精灵之王的霜冻。"
                npc "当然，他现在正躲在卡斯特里的那些享乐主义贵族中间。"
                npc "我怀疑那个臭名昭著的贪婪混蛋会不求回报就帮忙。"
                npc "但也许一剂强化过的药水就足够了。"
                npc "现在，你不如给我带来一块冰晶，我看看能做些什么。"
                show side_p he at pic
                mc "为什么是我？"
                hide side_p
                npc "你和伊瓦尔的地狱产物把那玩意带到这里来的！而且我会补偿你的，给。"
                play sound "ding.mp3"
                $ gold += 10
                show side_p m at pic
                mc "10金币？这远远不够！"
                hide side_p
                npc "等物品送到后我会付清余款。你只需通过手机发送，这样我就能快速开始工作。"
                npc "再说了，我告诉过你，你很幸运我还没有告诉老师们。"
                show side_p s at pic
                mc "有道理，但这有什么关系呢？为什么你不能就这样放任不管？"
                hide side_p
                npc "什么，所以你想让这整个地方被他的花蕾吞噬？你见过这里那些混蛋吗？"
                npc "他们会踩到你的花，然后它会分裂并扩散，如此反复，直到整个学校都被吞没。"
                npc "我自己只会试验一周。如果到下周我还不能让洛基之霜起作用，那我就会举报你。"
                npc "不过如果成功了，那我终于可以成名了，不是吗？世界著名的药剂大师英格丽德，我喜欢这个称号！"
                $ NPC = "???"
                $ add_new_quest("ice1")
                python:
                    if len(new_quests) > 0: #if we have new quests
                        for i in new_quests:
                            active_quests.insert(0, i) #add to top of the quest list
                        new_quests = [] #now reset the new quest list, since they all got added
                show screen completedtask("新任务！")
            elif "ice1" in completed_quests:
                $ NPC = "英格丽德"
                npc "这个药水还不完美。我还需要更多的材料作为催化剂。"
                npc "嗯，给我一些时间让我好好研究一下。"
                $ NPC = "???"
            else:
                npc "我迫不及待想要毕业并成名立万。"
        else:
            if "mc_bangkit" in my_events:
                npc "莱纳尔的破坏真的提醒我们，我们真的需要保持警惕。"
                npc "如果我们连就在眼皮底下的巫师都注意不到，我们怎么能从巫师手中拯救人们呢？"

            elif "beku" in quil_events:
                npc "我需要奎尔的那个符文。如果它能冻结整个湖泊，那它应该能冻结伊瓦尔的花。"
            elif "io4" in my_events:
                if "ice_rune" in my_events:
                    npc "嗯，谁能想到我们学校下面还困着人。"
                    npc "让人不禁想知道下面还有什么。"
                else:
                    npc "我希望新校长能尽快到任。"
            elif "vamp_visit" in red_events:
                if "date2_done" in quil_events:
                    npc "你不是刚和奎尔订婚吗？这里到底发生了什么？！"
                else:
                    npc "恭喜你们灵魂相连，[povname]！"
            elif "bite_day" in red_events:
                npc "你觉得如果我把塞恩交给血骑士，我会得到奖励吗？"
                npc "不会？我只是问问而已，该死。不用这样瞪着我。"
            elif "bunga_bego" in buff_events:
                npc "我试过在花上使用冰冻药水。没有效果。"
            else:
                npc "如果我能有人可以实验就好了..."
                show side_p f at pic
                mc "你在说什么？"
                hide side_p
                npc "哦，我一直在考虑制作自己的催眠符文。"
                npc "我希望它能帮我减肥，并且总体上抑制食欲。如果你有合适的实验对象，请告诉我！"
    scene map_tengah with dissolve
    jump map_fountain
label fountain_1:
    hide screen fountain_map
    scene tengah with dissolve
    
    if not check_inv_for(loot_items):
        "你可以看到喷泉底部有一些硬币。你还可以看到那里有一个锋利而昂贵的发夹。"
        if "pin" in my_events:
            if girl:
                show girl at horzappear
            else:
                show pboy at horzappear
            menu:
                "拿起发夹":
                    hide girl
                    hide pboy
                    $ curiosity += 10
                    $ InvItem(*item_pin).pickup(1)
                    play sound "sound/effects/splash.wav"
                    "你脱掉鞋子，卷起裤腿，拿起了发夹。仔细检查后，你发现它是塑料做的。"
                    "而且它的形状不像翅膀，更像一把剑。"
                    show side_p se at pic
                    mc "好吧，我相信我会找到一些用途的。"
                    hide side_p
                "不去管它":
                    hide girl
                    hide pboy
                    pass
    else:
        "尽管有很多硬币被扔进去，水还是很清澈。"
        mc "这个喷泉是不是应该是一个许愿井？"
    scene map_tengah with dissolve
    jump map_fountain
label fountain_2:
    hide screen fountain_map
    scene tengah with dissolve
    $ NPC = "???"
    if "mc_bangkit" in my_events:
        npc "真不敢相信莱纳尔不复存在了。这真的显示了这里的环境有多么不稳定。"
        npc "但至少这里不是死亡地带。"
    elif "beku" in quil_events:
        npc "我想知道冰冻湖泊的东西是否会冻结死亡地带的所有花朵。"
    elif "io4" in my_events:
        if "ice_rune" in my_events:
            npc "很多湖边的人仍然陷在自己的思绪中。"
            npc "我很惊讶教会没有在让他们重新融入社会之前，先送他们去接受心理治疗。"
        else:
            npc "对于校长的死，我有点无所谓。"
            npc "他是个优秀的猎人，但这适用于巫师和海妖。"
            npc "巫师我还能接受，但海妖..."
    elif "vamp_visit" in red_events:
        if "date2_done" in quil_events:
            npc "小心英克威尔家族，[povname]。我怀疑他们不会太高兴看到你同时与奎尔和塞恩订婚。"
        else:
            npc "我以为你会和阿什姆在一起，但我猜奎尔也不是个坏选择。"
    elif "bite_day" in red_events:
        npc "在我们自己的校园里都感到不安全，这个世界变成什么样了？！"
    elif "bunga_bego" in buff_events:
        npc "我简直不敢相信，尽管有这些花，我的父母还让我留在这里。"
        npc "他们是想让我死吗？！"
    elif "ajax" in fia_events:
        npc "我本想邀请阿什姆参加节日，但我改变主意了。"
        npc "我以为他是好人中的一个。"
    elif "day3" in quil_events:
        $ NPC = "学生B"
        npc "真不敢相信校长猎杀海妖。"
        npc "它们是庄严的生物，在非鸟形态下基本上就是人类。"
        npc "我知道社会认为它们只能作为宠物或装饰品，但仍然没有人应该终其一生被猎杀。"
        $ NPC = "学生A"
        npc "就像我们猎杀巫师一样？"
        $ NPC = "学生B"
        npc "那是不一样的。"
        $ NPC = "学生A"
        npc "怎么不一样？我是说，巫师以前对我们很友善，你知道吗？至少科尔在她的日记里是这么说的。"
        npc "什么日记？"
        $ NPC = "学生B"
        npc "图书馆里新收藏的。你也可以向凯普勒先生询问更多信息。他年纪很大了，几乎什么都知道。"

    elif calendar.day == 15 and calendar.month == '/05':
        $ NPC = "学生A"
        npc "你不应该赶紧换衣服吗？马上就要上课了。"
        $ NPC = "学生B"
        npc "等会儿吧，天气太热了，穿那件闷热的旧制服！"
    elif "sucker3" in active_quests:
        npc "猫？是的，我想我看到一只朝图书馆方向去了。"
    else:
        npc "你试过欣快剂吗？呃，我忘了我在和谁说话。当然你这样的人肯定试过，[nickname]。啊哈哈哈！"
    scene map_tengah with dissolve
    $ NPC = "???"
    jump map_fountain
label fountain_3:
    hide screen fountain_map
    scene tengah with dissolve
    $ NPC = "???"
    if "mc_bangkit" in my_events:
        npc "我希望沃特克的那些家伙不要卷入这整个莱纳尔的事件中。"
    elif "io4" in my_events:
        if "ice_rune" in my_events:
            npc "我记得我那个时代的这个喷泉。"
            npc "那时它会被墨水染成黑色。现在伊欧和科尔都不在了..."
            npc "哦，伊欧，你为什么要唤醒我？"
        else:
            npc "你觉得会找到校长的尸体吗？我觉得不会。"
    elif "vamp_visit" in red_events:
        if "date2_done" in quil_events:
            npc "所以你是不是和你朋友圈里的每个人都上床了？"
            npc "先是奎尔，现在又是塞恩？！"
        else:
            npc "我很惊讶阿什姆没有对你们的关系大惊小怪。不过我猜，如果他那样做的话，你可能会揍他一顿。"
    elif "bite_day" in red_events:
        npc "看来你是你那小圈子里最体面的人了。"
        npc "你需要更好的朋友，[povname]。"
    elif "bunga_bego" in buff_events:
        npc "我猜这意味着伊格尼亚的终结。"
        npc "不知道花朵蔓延需要多长时间。"
    elif "sucker3" in active_quests:
        npc "汤姆！汤姆！哦，科尔，那只猫会在哪里呢？"
    elif "sucker3" in completed_quests:
        npc "谢谢你把我的猫带回来。我真的很担心。"
    else:
        
        if "day3" in quil_events:
            npc "你听说过飞行水母的真正起源吗？"
            npc "我听说它们据说是一位未能保护儿子的母亲的眼泪。"
            npc "还有一些变体说，儿子会不断送给她腐烂的花朵作为报复。"
            npc "不过没人知道那位母亲做了什么，是什么罪过让她如此心痛。"
        else:
            npc "嘿[nickname]，你已经拿到猎巫执照了，对吧？你能找时间辅导我一下吗？"
            npc "我今年又没通过猎人考试，希望明年能有更好的运气。"
    scene map_tengah with dissolve
    jump map_fountain
label fountain_4:
    hide screen fountain_map
    scene tengah with dissolve
    $ NPC = "???"
    if "mc_bangkit" in my_events:
        npc "莱纳尔的破坏真的提醒我们，我们真的需要保持警惕。"
        npc "如果我们连就在眼皮底下的巫师都注意不到，我们怎么能从巫师手中拯救人们呢？"

    elif "beku" in quil_events:
        npc "我们的俱乐部现在在结冰的湖面上进行对抗赛。这让我们保持凉爽！"
    elif "io4" in my_events:
        if "ice_rune" in my_events:
            npc "我……我曾经加入过这个俱乐部，在湖边事件之前……"
            npc "在我的梦里，我是队长，和我梦中的男人约会……"
            npc "为什么……为什么我要醒来？"
        else:
            npc "我希望新校长能尽快到任。"
    elif "vamp_visit" in red_events:
        if "date2_done" in quil_events:
            npc "为什么是奎尔和塞恩两个人？你知道灵魂绑定是不能多配的！除非你是仙子。"
            npc "我希望你知道自己在做什么。[povname]！"
        else:
            npc "吸血鬼把我的假发吹飞了。我现在都不知道它在哪里了。"
    elif "bite_day" in red_events:
        npc "我父母要让我退学。我告诉他们不要这样，因为他们已经\'抓到\'塞恩了。"
        npc "但说实话，我不太确定他就是罪魁祸首。皮尔斯的遭遇可能只是巧合。"

    elif "festies" in my_events:
        npc "人们认为菲亚似乎与塔图姆住院有关。"
        npc "我觉得那可怜的女孩应该得到喘息的机会。"
    elif "ajax" in fia_events:
        npc "塞恩不是在阿贾克斯和阿什姆打架后舔了阿什姆手指上的血吗？"
        npc "要我说，这挺可疑的。"

    elif "bunga_bego" in buff_events:
        npc "为什么每个人都说得好像世界末日一样？不过是些花而已！"
        
    elif "day3" in quil_events:
        npc "你知道湖下据说有一个秘密地牢吗？"
        npc "他们说要进入只需要一个受折磨灵魂的光芒。不知道这是什么意思。"
    elif calendar.day == 15 and calendar.month == '/05':
        $ NPC = "女孩A"
        npc "你有考虑过这学期加入合唱团吗？"
        $ NPC = "女孩B"
        npc "算了吧。只要菲亚还在里面，我就不会加入。那女孩有问题。"
        $ NPC = "女孩A"
        npc "哦，我懂你的意思！"
        if "choir" not in topics:
            $ topics.append("choir")
            show side_p he at pic
            mc "（菲亚？他们在说什么？）"
            hide side_p
            play sound "audio/success.mp3"
            "新话题：{color=#FF1500}合唱团。{/color}"
    elif "sucker3" in active_quests:
        npc "你看到那个白色的东西经过吗？我觉得它朝图书馆那边去了。"
    else:
        $ NPC = "学生A"
        npc "听说晚上在大门顶上是个不错的亲热地点。"
        $ NPC = "学生B"
        npc "哼。好像你能上得去似的，通往那里的门都锁着呢！"
    scene map_tengah with dissolve
    $ NPC = "???"
    jump map_fountain
label fountain_5:
    hide screen fountain_map
    scene stairs with dissolve
    $ NPC = "???"
    if "mc_bangkit" in my_events:
        npc "伊格尼亚真的把莱纳尔搞砸了。我希望那里的居民至少能被安置到西奥德或三头政体。"
        npc "仙境可能有点过分，但总比吸血鬼和狼人的地盘好。"

    elif "beku" in quil_events:
        npc "我曾经看到罗纳德在湖面上做了个三周跳，太棒了！"
        npc "可惜滑冰不是竞技项目。"
    elif "io4" in my_events:
        if "ice_rune" in my_events:
            npc "我记得湖泊，伊欧，然后一片漆黑。"
            npc "和其他人不同，我似乎记不起任何梦境。"
            npc "几十年的时光仿佛只是几秒钟。"
        else:
            npc "为什么不让迪特里希接手呢？他是个很好的老师。"
            npc "我打赌他会是个了不起的校长！"
    elif "vamp_visit" in red_events:
        if "date2_done" in quil_events:
            npc "同时脚踏两条船？虽然令人不齿，但我也佩服你。"
            npc "奎尔很有钱，塞恩很帅。不过，灵魂绑定可能不是明智之举。"
        else:
            npc "所有的吸血鬼和邪血族都苍白得要命。"
            npc "话说回来，你也可以说我们都很苍白，但这里也没什么阳光。"
            npc "冬天来临时基本上一直是黑夜！"
    elif "bite_day" in red_events:
        npc "我再也不能偷偷溜到女朋友的宿舍了。该死的宵禁。"
    elif "ajax" in fia_events:
        npc "人们都在关注阿什姆和阿贾克斯，但我更担心塞恩。"
        npc "我绝对看到他舔了阿什姆手指上的血。"
    elif "bunga_bego" in buff_events:
        npc "也许杀虫剂能帮上忙？但是嗯，我猜那只会让花长得更多。"
        
    elif calendar.day == 15 and calendar.month == '/05':
        npc "我父亲给了我两个选择，要么来这里，要么去莫洛纳的绽放美人学校。"
        npc "我宁愿死也不去那个满是傲慢仙子和温顺海妖的学校。"
    elif "day3" not in quil_events:
        $ NPC = "学生A"
        npc "你有没有想过转学到其他学校？"
        $ NPC = "学生B"
        npc "我考虑过加入赫斯的莫尔斯学院，但那里又全是吸血鬼和狼人。"
        npc "我觉得我在那种充满敌意的环境里活不下去。"
        $ NPC = "学生A"
        npc "同意，但他们不是还有邪神恐怖吗？我听说他们还招收了一个克苏鲁。"
        npc "我想他们更喜欢被称为噬梦者，但没错。我听说他们是双胞胎，要我说的话，他们都是怪人。"
        if "ctulhu" not in topics:
            $ topics.append("ctulhu")
            play sound "audio/success.mp3"
            "新话题：{color=#FF1500}噬梦者。{/color}"
    else:
        npc "周末的时候学校变得很空。大多数人都涌向镇上，只有商店和下层花园值得一游。"
    scene map_tengah with dissolve
    $ NPC = "???"
    jump map_fountain
####malam_explore
screen explore_mlm():
    tag menu
    imagebutton:
        idle "images/maps/mlm/dah.png"
        hover "images/maps/mlm/dah.png"
        xpos 192 ypos 426
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("snore_3")]
        focus_mask None
        mouse "search"
    imagebutton:
        idle "images/maps/mlm/puk.png"
        hover "images/maps/mlm/puk.png"
        xpos 25 ypos 457
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("quil_hump")]
        focus_mask None
        mouse "search"
    imagebutton:
        idle "images/maps/mlm/low.png"
        hover "images/maps/mlm/low.png"
        xpos 1114 ypos 523
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("under_map")]
        focus_mask None
        mouse "search"
    imagebutton:
        idle "images/maps/mlm/up.png"
        hover "images/maps/mlm/up.png"
        xpos 811 ypos 304
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("map_kmr_ane")]
        focus_mask None
        mouse "search"
label mlm_map:
    $ afternoon = False
    $ morning = False
    $ night = True
    $ evening = False
    scene lorong_night
    call screen explore_mlm

label quil_hump:
    hide screen explore_mlm
    if "day3" in quil_events:
        "想看看奎尔是否有空吗？"
        show pboy at horzappear
        menu:
            "敲门":
                hide pboy
                if "mey_kill" not in my_events:
                    "..."
                    mc "看来他不在。也许他还在为我们拜访贪婪巫师做准备？"
                else:
                    show quil skul datar at center with dissolve:
                        yoffset 200
                    quil smile "[povname]，什么风把你吹到我的巢穴来了？"
                    show quil frown shock
                    show side_p f at pic
                    mc "我想你可能需要陪伴？"
                    hide side_p
                    quil err apa "在我的卧室里？"
                    show quil frown -apa
                    if "date2_done" not in quil_events:   
                        show side_p f at pic
                        mc "我是说，我们又不会做什么。"
                        hide side_p
                        quil talk "嗯。抱歉亲爱的，但我只让恋人进入我的房间。"
                        show quil smile
                        show side_p s at pic
                        mc "但你从来都没有恋人！"
                        hide side_p
                        quil flashy wink cling "我打算一直保持这样。"
                        
                    else:
                        show side_p f at pic
                        mc "但我们已经订婚了！"
                        hide side_p
                        quil kzl frusta "那只是名义上的！要有点礼仪！"
                        if "naksir" in quil_events:
                            show side_p f at pic
                            mc "我还以为你对我有好感呢。"
                            hide side_p
                            quil sulk blush sigh "我确实有，但好感比起爱情来说不值一提。"
                            show side_p f at pic
                            mc "假正经。"
                            hide side_p
                            quil flashy wink -blush cling "我称之为品位，亲爱的。"
                            quil hister -cling "等我们关系更亲密些再来吧。"
                            show side_p f at pic
                            mc "（嗯，我猜这并不是拒绝。）"
                            hide side_p
                    play sound "sound/effects/doorslam.mp3"
                    hide quil with dissolve
                    "奎尔砰地一声关上了门。"    
                jump mlm_map
            "不了。":
                hide pboy
                jump mlm_map
    else:
        play sound "sfx/bed.mp3"
        quil "啊，对！再用力点！用那根****掐住我的脖子，然后插进我的***然后****！"
        if girl:
            show p_side s at pic
        else:
            show side_p s at pic
        mc "不不不！天啊，我真希望自己是聋子！"
        if girl:
            hide p_side
        else:
            hide side_p
        $ quil_events.append("quil_hump")
        jump mlm_map

label snore_3:
    hide screen explore_mlm
    play sound "sound/effects/door.mp3"
    scene tgh_mlm with dissolve
    if "day3" in quil_events:
        if "date1_done" not in red_events: 
            show red point datar at center with dissolve:
                yoffset 330
            "你看到塞恩独自坐在客厅里。"
            show pboy at horzappear
            menu:
                "和塞恩一起出去玩？"
                "走近他":
                    hide pboy
                    $ datingplace = "Malam"
                    if "date1_done" not in red_events:
                        jump red_date1
                    else:
                        scene teras_mlm with dissolve
                        $ datingplace = "sklh"
                        hide screen cal
                        $ quick_menu = False
                        $ daterp = 30
                        $ turnsleft = 3
                        $ skinshiparea = ""
                        $ config.rollback_enabled = False
                        $ renpy.block_rollback()
                        $ datingname = "塞恩"
                        red "那么，你在想什么？"
                        jump startdate
                "返回":
                    hide pboy
                    scene lorong_night with dissolve
                    jump mlm_map
        else:
            if calendar.day == 12 and calendar.month == '/06':
                "客厅空无一人，所以你回到了里面。"
            else:
                show buff frown at center with dissolve:
                    yoffset 770
                show side_p se at pic
                mc "哦，嗨，莱尔。怎么了？"
                hide side_p
                buff "没什么，就是睡不着。"
                show pboy at horzappear
                menu:
                    "和莱尔一起消磨时间？"
                    "走近他":
                        #berubah
                        hide pboy
                        show side_p w at pic
                        mc "哦，那样的话，你想一起消磨一会儿时间吗？"
                        hide side_p
                        buff wry "哦……好啊。"
                        scene teras_mlm with dissolve
                        $ datingplace = "sklh"
                        hide screen cal
                        $ quick_menu = False
                        $ daterp = 40
                        $ turnsleft = 3
                        $ skinshiparea = ""
                        $ config.rollback_enabled = False
                        $ renpy.block_rollback()
                        $ datingname = "莱尔"
                        jump startdate
                        #berubah
                        #jump jaga_jaga
                    "返回":
                        hide pboy
                        scene lorong_night with dissolve
                        jump mlm_map
    else:
        "客厅空无一人，所以你回到了里面。"
    scene lorong_night with dissolve
    jump mlm_map
label jaga_jaga:
    $ night = True
    $ evening = False
    $ afternoon = False
    $ morning = False
    if calendar.day >= 12 and calendar.month == '/06' and "culik" not in fia_events: #Mon
        scene lor_mlm with fade
        "你听到一阵响声，看到莱尔正在偷偷溜出去。"
        show buff sad sweat at center with dissolve:
            yoffset 770
        "你听到他反复小声嘟囔着\"别显得可疑\"，几乎像是在念咒语。"
        show pboy at horzappear
        menu:
            "加入他":
                hide pboy
                $ putri.points -= 5
                show side_p f at pic
                mc "别显得可疑，别显得可疑。"
                hide side_p
                buff kzl "别显得可疑，别显得可疑~"
                if girl:
                    show palmierproxy chill frown at left with moveinleft:
                        yoffset 40
                else:
                    show palmierproxy chill frown at left with moveinleft:
                        yoffset 100
                play sound "sound/effects/bump.mp3"
                show buff sad shock with move:
                    xalign 0.3
                    easein 2.0 xalign 0.5
                "不知怎的，他没注意到你的存在，屁股先撞到了你。"
                "他猛地转过头，惊叫了一声。"
                buff keluh frusta "哈！我就觉得可疑！"
                mc flirt -sweat cling "你要去哪里，莱尔？我发誓我不会告诉别人。"
                
            "拍拍他的肩膀":
                hide pboy
                $ putri.points += 5
                if girl:
                    show palmierproxy chill kind at left with moveinleft:
                        yoffset 40
                else:
                    show palmierproxy chill kind at left with moveinleft:
                        yoffset 100
                mc mean cling "要去哪儿？"
                show palmierproxy wry -cling
                buff keluh sweat shock "啊啊！"
                buff sad sigh"哦，[povname]！"
                mc hister sigh "给你个小建议，莱尔。下次你想偷偷溜走的时候，别一边走一边唱\'别显得可疑\'。"
                mc malu -sigh "这样做只会让你看起来...嗯，更可疑。"
                show palmierproxy kind
                buff kzl frusta "我...记下了。"
                mc flirt tanya "你这么晚要去哪儿？"
        buff keluh sweat frusta "哦，[povname]，我...派克给我发了条短信，说他那边有紧急情况，让我过去。"
        show buff sad 
        mc scratch apa sweat tanya "紧急情况？他说明是什么事了吗？" 
        show palmierproxy sad -tanya
        buff keluh sigh "没有，不过可能和玛格丽特有关。她今天发短信说她感觉不舒服。"
        buff confused apa "也许派克需要帮忙送她去医院？"
        show buff sad -apa
        mc confused "为什么找你？他有一整个岛的人可以帮忙——"
        show buff eh shock
        show palmierproxy frown -sweat shock
        $ NPC = "普莉姆"
        show prim_ sad at pic
        stop music
        play sound "sound/effects/punch.mp3"
        npc "[povname]！" with vpunch
        hide prim_
        mc chill apa sweat shock "普莉姆？"
        play music "MUSIC/Action-Rhythm-4.mp3"
        hide side_p
        show prim_ sad at pic
        show buff eh sweat shock
        npc "你看见菲亚了吗？我哪儿都找不到她！"
        hide prim_
        mc side frusta "什么？！你是什么意思，找不到她？！"
        show prim_ sad at pic
        npc "我是说，我们一起去莱纳尔帮助乔安娜，后来她说自己太累了，就先回宿舍了。"
        npc "我还得继续帮乔安娜，所以我们就分开了，但现在快午夜了，她还没回来！"
        hide prim_
        buff scold apa "你最后一次看到她是在哪里？"
        show buff sad -apa
        show prim_ sad at pic
        npc "我看到她从山上走下来。我们是从乔安娜家出发的。"
        hide prim_
        show palmierproxy kzl shock
        buff keluh "她下山的时候受伤了吗？"
        show prim_ sad at pic
        npc "哦，科尔啊，希望没有！"
        hide prim_
        mc sad frusta "去告诉老师们，好吗？迪特里希可能还醒着。"
        mc kzl tanya "莱尔，你画了什么符文吗？"
        buff sad apa "我，呃，没有，不过为什么问这个？"
        mc deject frusta "那就画点你能想到的，我们待会儿可能用得上！"
        hide palmierproxy with moveoutleft
        hide buff with moveoutright
        show prim_ yell at pic
        play sound "sound/effects/tile.mp3"
        npc "等等，你们两个要去哪儿？！"
        hide prim_
        show side_p m at pic
        mc "去莱纳尔！"
        stop sound
        hide side_p
        jump seth_fight
    elif "io0" in my_events and "io4" not in my_events:
        scene bed_alter with dissolve
        play sound "sound/effects/door.mp3"
        jump io_dream_check
    elif calendar.day == 30 and calendar.month == '/05': #Rabu W3
        jump curfew_day
    elif calendar.day == 23 and calendar.month == '/05': #Selasa W2
        scene kmr_malam with fade
        "今晚是重要的夜晚。你立即换好衣服，前往阿什姆的房间。"
        show quil libur sulk at right with dissolve:
            yoffset 200
        show red bebas mls sweat at left with dissolve:
            yoffset 330
        show tom go frown at center with dissolve:
            yoffset 190
        "奎尔帮你画好了面对梅扎所需的符文。当阿什姆和塞恩向你点头示意时，每个人看起来都很紧张。"
        if "help_me" in my_events:
            tom blow "迪特里希已经先行一步。他说不要引起任何人的注意。"
            red kaget -sweat apa "他弄到邀请函了？"
            show red frown -apa
            tom ew sweat "也许吧。他说得很含糊，说这样做是为了以防发生任何...意外。"
            show tom frown -sweat
            quil ejek sigh "他是个做事周到的人。嗯，我猜这不是他第一次做这种见不得人的工作。"
            show quil datar
            tom capek blow "也不会是最后一次。"
        tom frown -blow "准备好了吗？"
        show side_p h at pic
        mc "我已经准备好了。"
        hide side_p
        play sound "sound/effects/woosh.mp3"
        "你们四个人手拉着手，梅扎的邀请产生的火焰将你们整个吞没。"
        scene bg_black with w20
        jump meyza_fight
    elif calendar.day == 15 and calendar.month == '/05':
        scene bed_alter with dissolve
        play sound "sound/effects/door.mp3"
        "当你进去时，莱尔已经睡着了。"
        play sound "sound/effects/cloth.mp3"
        "你尽量不发出声音，然后倒在床上睡觉。"    
        scene bg_black with eye_shut
        jump dreamscape
    elif calendar.day == 17 and calendar.month == '/05':
        scene bed_alter with dissolve
        play sound "sound/effects/door.mp3"
        "当你走进去时，莱尔已经熟睡了。"
        play sound "sound/effects/cloth.mp3"
        "你尽量不发出声音，然后倒在床上睡觉。"    
        scene bg_black with eye_shut
        jump io_dream
    elif calendar.day == 26 and calendar.month == '/05': #Sabtu W2
        jump buff_nyari_baju
    else:
        scene bed_alter with dissolve
        play sound "sound/effects/door.mp3"
        queue sound "sound/effects/cloth.mp3"
        "你在床上辗转反侧了一会儿，最后终于睡着了。"    
        scene bg_black with eye_shut
        if "iv_dream2" not in my_events:
            jump iv_second
        else:
            jump morning
screen vamp_map():
    tag menu
    imagebutton:
        idle "images/maps/mlm/then.png"
        hover "images/maps/mlm/then.png"
        xpos 111 ypos 346
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("ketemu_thane_malam")]
        focus_mask None
        mouse "search"
    imagebutton:
        idle "images/maps/mlm/coch.png"
        hover "images/maps/mlm/coch.png"
        xpos 594 ypos 466
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("vamp_1")]
        focus_mask None
        mouse "search"
    imagebutton:
        idle "images/maps/mlm/ats.png"
        hover "images/maps/mlm/ats.png"
        xpos 1104 ypos 202
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("mlm_map")]
        focus_mask None
        mouse "search"
label under_map:
    hide screen explore_mlm
    scene underground_night
    call screen vamp_map
label vamp_1:
    hide screen vamp_map
    "那是一张满是灰尘的沙发。有些座位看起来像是被老鼠或其他东西啃过。"
    jump under_map

screen kmr_lor():
    tag menu
    imagebutton:
        idle "images/maps/mlm/trs.png"
        hover "images/maps/mlm/trs.png"
        xpos 852 ypos 336
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("teras_luar")]
        focus_mask None
        mouse "search"
    imagebutton:
        idle "images/maps/mlm/2.png"
        hover "images/maps/mlm/2.png"
        xpos 1287 ypos 205
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("snore_2")]
        focus_mask None
        mouse "search"
    imagebutton:
        idle "images/maps/mlm/1.png"
        hover "images/maps/mlm/1.png"
        xpos 313 ypos 178
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("ur_room")]
        focus_mask None
        mouse "search"
    imagebutton:
        idle "images/maps/mlm/3.png"
        hover "images/maps/mlm/3.png"
        xpos 589 ypos 760
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("mlm_map")]
        focus_mask None
        mouse "search"
label map_kmr_ane:
    hide screen explore_mlm
    scene lor_mlm
    call screen kmr_lor
label teras_luar:
    hide screen kmr_lor
    scene teras_mlm with dissolve
    play sound "sound/effects/door.mp3"
    "今晚有点冷，所以你感受了一下夜晚的空气后就回到了里面。"
    play sound "sound/effects/door.mp3"
    scene lor_mlm with dissolve
    jump map_kmr_ane
label ur_room:
    hide screen kmr_lor
    $ night = True
    $ evening = False
    $ afternoon = False
    $ morning = False
    scene lor_mlm
    if calendar.day >= 12 and calendar.month == '/06' and "culik" not in fia_events: #Mon
        "就在你准备回房间的时候，你看到莱尔正在偷偷溜出去。"
        show buff sad sweat at center with dissolve:
            yoffset 770
        "你能听到他不停地小声嘀咕着\"别显得可疑\"，几乎像是在念咒语。"
        show pboy at horzappear
        menu:
            "加入他":
                hide pboy
                $ putri.points -= 5
                show side_p f at pic
                mc "别显得可疑，别显得可疑。"
                hide side_p
                buff kzl "别显得可疑，别显得可疑~"
                if girl:
                    show palmierproxy chill frown at left with moveinleft:
                        yoffset 40
                else:
                    show palmierproxy chill frown at left with moveinleft:
                        yoffset 100
                play sound "sound/effects/bump.mp3"
                show buff sad shock with move:
                    xalign 0.3
                    easein 2.0 xalign 0.5
                "不知怎的，他没注意到你的存在，屁股先撞到了你。"
                "他猛地转过头，惊叫了一声。"
                buff keluh frusta "哈！我就觉得可疑！"
                mc flirt -sweat cling "你要去哪里，莱尔？我发誓我不会告诉别人。"
                
            "拍拍他的肩膀":
                hide pboy
                $ putri.points += 5
                if girl:
                    show palmierproxy chill kind at left with moveinleft:
                        yoffset 40
                else:
                    show palmierproxy chill kind at left with moveinleft:
                        yoffset 100
                mc mean cling "要去哪儿？"
                show palmierproxy wry -cling
                buff keluh sweat shock "啊啊！"
                buff sad sigh "哦，[povname]！"
                mc flirt tanya "你这么晚要去哪儿？"
        buff keluh sweat frusta "我...派克给我发了条短信，说他那边有紧急情况，让我过去。"
        show buff sad 
        mc scratch apa sweat tanya "紧急情况？他说明是什么事了吗？" 
        show palmierproxy sad -tanya
        buff keluh sigh "没有，不过可能和玛格丽特有关。她今天发短信说她感觉不舒服。"
        buff confused apa "也许派克需要帮忙送她去医院？"
        show buff sad -apa
        mc confused "为什么找你？他有一整个岛的人可以帮忙——"
        show buff eh shock
        show palmierproxy frown -sweat shock
        $ NPC = "普莉姆"
        show prim_ sad at pic
        stop music
        play sound "sound/effects/punch.mp3"
        npc "[povname]！" with vpunch
        hide prim_
        mc chill apa sweat shock "普莉姆？"
        play music "MUSIC/Action-Rhythm-4.mp3"
        hide side_p
        show prim_ sad at pic
        show buff eh sweat shock
        npc "你看见菲亚了吗？我哪儿都找不到她！"
        hide prim_
        mc side frusta "什么？！你是什么意思，找不到她？！"
        show prim_ sad at pic
        npc "我是说，我们一起去莱纳尔帮助乔安娜，后来她说自己太累了，就先回宿舍了。"
        npc "我还得继续帮乔安娜，所以我们就分开了，但现在快午夜了，她还没回来！"
        hide prim_
        buff scold apa "你最后一次看到她是在哪里？"
        show buff sad -apa
        show prim_ sad at pic
        npc "我看到她从山上走下来。我们是从乔安娜家出发的。"
        hide prim_
        show palmierproxy kzl shock
        buff keluh "她下山的时候受伤了吗？"
        show prim_ sad at pic
        npc "哦，科尔啊，希望没有！"
        hide prim_
        mc sad frusta "去告诉老师们，好吗？迪特里希可能还醒着。"
        mc kzl tanya "莱尔，你画了什么符文吗？"
        buff sad apa "我，呃，没有，不过为什么问这个？"
        mc deject frusta "那就画点你能想到的，我们待会儿可能用得上！"
        hide palmierproxy with moveoutleft
        hide buff with moveoutright
        show prim_ yell at pic
        play sound "sound/effects/tile.mp3"
        npc "等等，你们两个要去哪儿？！"
        hide prim_
        show side_p m at pic
        mc "去莱纳尔！"
        stop sound
        hide side_p
        jump seth_fight
    else:
        "你的房间。今晚休息一下？"
        if girl:
            show girl at horzappear
        else:
            show pboy at horzappear
        menu dir_slep:
            "休息":
                hide girl
                hide boy
                hide pboy
                stop music
                
                if "io0" in my_events and "io4" not in my_events:
                    scene bed_alter with dissolve
                    play sound "sound/effects/door.mp3"
                    jump io_dream_check
                elif calendar.day == 30 and calendar.month == '/05': #Rabu W3
                    jump curfew_day
                elif calendar.day == 23 and calendar.month == '/05': #Selasa W2
                    scene kmr_malam with fade
                    "今晚是重要的夜晚。你立即换好衣服，前往阿什姆的房间。"
                    show quil libur sulk at right with dissolve:
                        yoffset 200
                    show red bebas mls sweat at left with dissolve:
                        yoffset 330
                    show tom go frown at center with dissolve:
                        yoffset 190
                    "奎尔帮你画好了面对梅扎所需的符文。当阿什姆和塞恩向你点头示意时，每个人看起来都很紧张。"
                    if "help_me" in my_events:
                        tom blow "迪特里希已经先行一步。他说不要引起任何人的注意。"
                        red kaget -sweat apa "他弄到邀请函了？"
                        show red frown -apa
                        tom ew sweat "也许吧。他说得很含糊，说这样做是为了以防发生任何...意外。"
                        show tom frown -sweat
                        quil ejek sigh "他是个做事周到的人。嗯，我猜这不是他第一次做这种见不得人的工作。"
                        show quil datar
                        tom capek blow "也不会是最后一次。"
                    tom frown -blow "准备好了吗？"
                    show side_p h at pic
                    mc "我已经准备好了。"
                    hide side_p
                    play sound "sound/effects/woosh.mp3"
                    "你们三个人手拉着手，梅扎邀请函上的火焰将你们整个吞没。"
                    scene bg_black with w20
                    jump meyza_fight
                elif calendar.day == 15 and calendar.month == '/05':
                    scene bed_alter with dissolve
                    play sound "sound/effects/door.mp3"
                    "当你进去时，莱尔已经睡着了。"
                    play sound "sound/effects/cloth.mp3"
                    "你尽量不发出声音，然后倒在床上睡觉。"    
                    scene bg_black with eye_shut
                    jump dreamscape
                elif calendar.day == 17 and calendar.month == '/05':
                    scene bed_alter with dissolve
                    play sound "sound/effects/door.mp3"
                    "当你走进去时，莱尔已经熟睡了。"
                    play sound "sound/effects/cloth.mp3"
                    "你尽量不发出声音，然后倒在床上睡觉。"    
                    scene bg_black with eye_shut
                    jump io_dream
                elif calendar.day == 26 and calendar.month == '/05': #Sabtu W2
                    jump buff_nyari_baju
                else:
                    scene bed_alter with dissolve
                    play sound "sound/effects/door.mp3"
                    "当你走进去时，莱尔已经熟睡了。"
                    play sound "sound/effects/cloth.mp3"
                    "你尽量不发出声音，然后倒在床上睡觉。"    
                    scene bg_black with eye_shut
                    if "iv_dream2" not in my_events:
                        jump iv_second
                    else:
                        jump morning
            "{s}查看日记{/s}" if "diari1" not in active_quests:
                
                jump dir_slep
            "查看日记" if "diari1" in active_quests:
                hide pboy
                stop music
                scene lor_mlm with dissolve
                $ password = ""
                "在进入房间之前，你决定翻翻手机，试图破解你的分身的日记。"
                "它需要一个密码。"
                if "password" in my_events:
                    play sound "sfx/btn16.mp3"
                    "你输入了\"Licorice\"，文件夹立即打开了，显示出三条日记记录。"
                    "每条记录都需要另一个密码才能阅读。"
                    if "diary_read_3" not in my_events and "diary_read_2" in my_events:
                        "你继续阅读你的分身的日记。只剩下一个锁定的条目了。"
                        "密码提示是\"Solaris...？\""
                        python:
                            password = renpy.input("密码是什么？（区分大小写）", length=16)
                            password = password.strip()
                        if password == "Aegna":
                            play music "MUSIC/MusMus-BGM-112.mp3"
                            $ NPC = "日记"
                            npc "巫师必死"
                            npc "人类必亡。"
                            npc "人类去死。"
                            npc "仙子去死。"
                            npc "狼人去死。"
                            npc "海妖和美人鱼去死，小精灵去死，还有我能想到的所有其他狗屁玩意儿都去死。"
                            npc "这该死的绝望人生到底有什么意义？"
                            npc "也许如果我能把一切都抹去，重新开始就好了。"
                            stop music fadeout 5
                            npc "..."
                            npc "该死。{w}听起来真是太矫情了。"
                            play music "MUSIC/MusMus-BGM-128.mp3" fadein 5
                            npc "难怪菲亚让我去看心理医生。偏偏是她，在所有人中！"
                            npc "我们这儿有心理治疗吗？负担得起的那种？"
                            npc "如果有朝一日我统治世界，我应该搞免费心理治疗。甚至一切都免费。"
                            npc "但我猜那可能会引发其他问题，比如模糊的所有权和无政府状态。"
                            npc "嗯。给自己留个备忘：学习经济学，避税。去他妈的税！"
                            npc "爸爸一直在问我毕业后要做什么？他可能想让我接管家族生意。"
                            npc "去他的。我毕业后不想工作，我想找个有钱人，被宠坏。"
                            npc "也许可以做这方面的生意。叫\'大宝宝\'什么的，因为你是成年人但可以过上被宠坏的婴儿生活。当然不用尿布。"
                            npc "不过嘛...我现在感觉好多了。可能是因为药物的缘故。"
                            npc "我感觉没那么想杀人了，如果这能算个词的话。"
                            npc "重写符文也起了作用。我在自己身上用了它们，显然这就是我需要的，彻底让科尔在我脑子里闭嘴。"
                            npc "我仍然保留着她的记忆，我的血有时还会变成墨水般的黑色，但在我看来这是一种胜利。"
                            npc "我现在感觉更平静了，更能掌控局面。我仍然认为创立自己的宗教会是件好事，但是..."
                            npc "也许不是以把每个人变成无脑奴隶的方式。而是以科尔想要的那种和平的方式。"
                            npc "也许吧。谁知道呢？不管怎样，我会和奎尔一起度过这个夏天。"
                            npc "那一定会很有趣。我希望菲亚能来。我很确定奎尔曾经暗恋她，至少在她的胸部发育之前是这样。"
                            npc "但我猜他喜欢平胸的。"
                            npc "如果不是菲亚，那么也许红可以来，我喜欢他。他很蠢，但我喜欢男人这一点。这是个特色。"
                            npc "还有阿什姆。我一生的挚爱，同时也是那个溜走的人。"
                            npc "我希望我们都能上床。该死，我现在很性奋。四人行听起来不错。"
                            npc "而且这玩意儿真棒。满分10分我给10分，一定会再试的。"
                            show side_p s at pic
                            mc "..."
                            show side_p m
                            mc "\'我\'是不是刚刚失去理智了？！"
                            hide side_p
                            "其他的日记条目还好。好吧，不是很好。很悲伤，但至少还能理解。"
                            "被绑定是不是永久性地搞坏了[povname]的脑子？"
                            show side_p s at pic
                            mc "但[kamu]确实说重写符文有帮助，所以也许只是药物的作用？"
                            if not girl2:
                                mc "哈...不管怎样，当我最终救出[dia2]时，我应该记住这一点。"
                            else:
                                mc "哈...不管怎样，当我最终救出[dia2]时，我应该记住这一点。"
                            show side_p he
                            mc "这个人可能已经不太正常了。不过，[kamu]听起来并不像个坏人。"
                            show side_p w 
                            mc "只是被搞砸了，但我们不都是这样吗？我发誓我会救你的，[povname]。"
                            show side_p he
                            mc "而且可能会让你接受心理治疗，至少一年。"
                            hide side_p
                            scene bed_alter with dissolve
                            "满意了，你关掉手机准备上床睡觉。"
                            if not girl2:
                                "你可能不完全理解你的分身，但至少你不再把[dia2]视为威胁了。"
                            else:
                                "你可能不完全理解你的分身，但至少你不再把[dia]视为威胁了。"
                            "只是另一个醉鬼失败者，就像你以前那样。"
                            show side_p w at pic
                            mc "我们会帮你重新站起来的，[povname]。我保证。"
                            hide side_p
                            python:
                                active_quests.remove("diari1")
                                completed_quests.insert(0, "diari1")
                            show screen completedtask("任务完成！")
                            
                            
                        else:
                            play sound "sound/effects/278160__sirrealist2__vibrate.mp3"
                            "你的手机震动着，删除了所有的日记条目。显然，一次已经是太多的错误了。"
                            stop sound
                            $ active_quests.remove("diari1")
                            show screen completedtask("任务失败")
                            show side_p s at pic
                            mc "该死！"
                            hide side_p
                    elif "diary_read_2" not in my_events and "diary_read_1" in my_events:
                        "你继续阅读你的分身的日记。"
                        $ my_events.append("diary_read_2")
                        "这个条目的密码提示是\'我们在？下绑定（小写，无空格）\'"
                        python:
                            password = renpy.input("密码是什么？", length=16)
                            password = password.strip()
                        if password == "bloodmoon":
                            play sound "sfx/btn16.mp3"
                            "日记上写着..."
                            $ NPC = "日记"
                            play music "MUSIC/MusMus-BGM-112.mp3"
                            npc "我们已经绑定了，这感觉...太可怕了。"
                            npc "就像有一百万个声音不断在我脑海中回响。"
                            npc "科尔的记忆无情地侵袭着。它们就像一场海啸，淹没了一切。"
                            npc "药物和酒精有助于麻痹这些记忆，但我知道我正在迷失自我。"
                            npc "我太蠢了。真的...太蠢了。我真以为我能帮到她。但现在我们只是一起被困在地狱里。"
                            npc "她想要挣脱，但我不确定那是否可能。"
                            npc "如果可以的话，我会这么做。但唯一的出路就是死亡。"
                            npc "我不想死。我还想折磨菲亚决定灵魂绑定的对象。"
                            npc "或者至少看着她在合唱表演中彻底击败塔图姆。无论如何，我都会为她感到骄傲。"
                            npc "也许阿什姆和我能和好如初...不，我已经把事情搞砸了。"
                            npc "这种绑定唯一的好处是我知道其他巫师的下落、弱点和过去。"
                            npc "如果我疯了的话，我可能还会坚持我的计划，与塞斯绑定。"
                            npc "但我还没疯...至少现在还没有，对吧？"
                            npc "不过，如果我能与塞斯绑定，那我最终会得到幸福美满的结局，不是吗？"
                            npc "一个没有隔离、没有种族主义的世界，一个只有一位神和一个恶魔的世界。而我就是那个恶魔。"
                            npc "哦，我在写什么啊？喝一口酒，安静下来吧，你这个疯子。"
                        else:
                            play sound "sound/effects/278160__sirrealist2__vibrate.mp3"
                            "你的手机震动着，删除了所有的日记条目。显然，一次已经是太多的错误了。"
                            stop sound
                            $ active_quests.remove("diari1")
                            show screen completedtask("任务失败")
                            show side_p s at pic
                            mc "该死！"
                            hide side_p
                    elif "diary_read_1" not in my_events:
                        $ my_events.append("diary_read_1")
                        "你决定先试着阅读最早的日记条目。密码提示是\'梅扎给你起的昵称，不带空格\'。"
                        show pboy at horzappear
                        menu:
                            "输入密码":
                                hide pboy
                                python:
                                    password = renpy.input("密码是什么？（区分大小写）", length=16)
                                    password = password.strip()
                                if password == "LittleDemon":
                                    play sound "sfx/btn16.mp3"
                                    "日记上写着..."
                                    play music "MUSIC/MusMus-BGM-112.mp3"
                                    $ NPC = "日记"
                                    npc "阿什姆昨天向我求婚了。他的时机再糟糕不过了。"
                                    npc "我们躺在床上，我像往常一样在做爱后抚摸他的头发，他选择在那一刻脱口而出说他想娶我。"
                                    npc "诚然，他承认这是个意外，但还是尴尬得要命。尤其是因为我早就知道他要这么做了。"
                                    npc "我在他的内裤抽屉里发现了刻有字的戒指。老实说，就连塞恩都能把这两件事联系起来。"
                                    npc "...我应该心存感激的。与我认识的大多数男人相比，阿什姆是最出色的。当然，他的混血基因在某些人看来可能有问题，但我从来不在乎这些。"
                                    npc "那么，为什么我不开心呢？相反，我感到...内疚。也许菲亚说得对，这些年来我终于长出了一颗心。"
                                    npc "我想即使我想接受他的求婚，现在也不能了。"
                                    npc "\'嗯，我差点杀了他，这样我就可以永远奴役他\'这种灵魂伴侣相遇的故事现在听起来一点也不浪漫，对吧？"
                                    npc "我为此责怪科尔。责怪她，还有那些善良和宽恕的点滴。这真的有点太过了。或者也许是我在她的墓穴里待得太久了。"
                                    npc "那里的每个人是不是都被施了魔法，变成了无私的殉道者？圣人科尔和她背负的所有罪孽。"
                                    npc "我有一部分希望她像梅扎一样。天真、痴迷、容易看透。但当然，她偏偏是完全相反的。"
                                    npc "说到梅扎，她一直让我去她的俱乐部。如果她不那么疯狂的话，我可能会去。但即使是我也能认出一个疯狂的跟踪狂。"
                                    npc "我的小恶魔，她曾经这样称呼我。我同意这个说法。我是个恶魔...但我想一个天使已经来帮助我忏悔了。"
                                    "日记到此结束。"
                                    show side_p f at pic
                                    if "io1" not in my_events:
                                        mc "为什么听起来[povname]好像见过科尔？这不可能，对吧？"
                                        mc "科尔是个神，或者至少被当作神来崇拜。而迪特里希说她已经死了一段时间了。那[povname]怎么可能和他们交谈呢？"
                                        mc "除非是在更精神层面上的\'交谈\'，但我觉得也不是这样。还有我一直听说的这个墓穴在哪里？"
                                    else:
                                        mc "我想知道[povname]还见过谁？一个俱乐部老板巫师和一个真正的神。"
                                        mc "要是这种效率用在别的地方就好了。"
                                    hide side_p

                                else:
                                    play sound "sound/effects/278160__sirrealist2__vibrate.mp3"
                                    "你的手机震动着，删除了所有的日记条目。显然，一次已经是太多的错误了。"
                                    stop sound
                                    $ active_quests.remove("diari1")
                                    show screen completedtask("任务失败")
                                    show side_p s at pic
                                    mc "该死！"
                                    hide side_p
                            "寻找密码":
                                hide pboy
                                show side_p f at pic
                                mc "我应该先四处寻找密码。"
                                mc "我确信某处一定有线索。"
                                hide side_p
                                scene bed_alter with dissolve
                        
                    else:
                        pass
                    

                else:
                    "你要猜吗？如果失败可能会被锁定。"
                    show pboy at horzappear
                    menu:
                        "猜测":
                            hide pboy
                            python:
                                password = renpy.input("密码是什么？（区分大小写）", length=8)
                                password = password.strip()
                                
                            if password == "Licorice":
                                $ my_events.append("password")
                                play sound "sfx/btn16.mp3"
                                "你输入了\"Licorice\"，文件夹立即打开了，显示出三条日记记录。"
                                "每条记录都需要另一个密码才能阅读。"
                                "你决定先试着阅读最早的日记条目。密码提示是\'梅扎给你起的昵称，不带空格\'。"
                                
                                python:
                                    password = renpy.input("密码是什么？（区分大小写）", length=16)
                                    password = password.strip()
                                if password == "LittleDemon":
                                    $ my_events.append("diary_read_1")
                                    play sound "sfx/btn16.mp3"
                                    "日记上写着..."
                                    $ NPC = "日记"
                                    npc "阿什姆昨天向我求婚了。他的时机再糟糕不过了。"
                                    npc "我们躺在床上，我像往常一样在做爱后抚摸他的头发，他选择在那一刻脱口而出说他想娶我。"
                                    npc "诚然，他承认这是个意外，但还是尴尬得要命。尤其是因为我早就知道他要这么做了。"
                                    npc "我在他的内裤抽屉里发现了刻有字的戒指。就连塞恩都能把这两件事联系起来。"
                                    npc "...我应该感到高兴的。与我认识的大多数男人相比，阿什姆是最出色的。当然，他的混血基因在某些人看来可能有问题，但我从来不在乎这些。"
                                    npc "那么，为什么我不开心呢？相反，我感到...内疚。也许菲亚说得对，这些年来我终于长出了一颗心。"
                                    npc "我想即使我想接受他的求婚，现在也不能了。"
                                    npc "\'嗯，我差点杀了他，这样我就可以永远奴役他\'这种灵魂伴侣相遇的故事现在听起来一点也不浪漫，对吧？"
                                    npc "我为此责怪科尔。责怪她，还有那些善良和宽恕的点滴。这真的有点太过了。或者也许是我在她的墓穴里待得太久了。"
                                    npc "那里的每个人是不是都被施了魔法，变成了无私的殉道者？圣人科尔和她背负的所有罪孽。"
                                    npc "我有一部分希望她像梅扎一样。天真、痴迷、容易看透。但当然，她偏偏是完全相反的。"
                                    npc "说到梅扎，她一直让我去她的俱乐部。如果她不那么疯狂的话，我可能会去。但即使是我也能认出一个疯狂的跟踪狂。"
                                    npc "我的小恶魔，她曾经这样称呼我。我同意这个说法。我是个恶魔...但我想一个天使已经来帮助我忏悔了。"
                                    "日记到此结束。"
                                    show side_p f at pic
                                    if "io1" not in my_events:
                                        mc "为什么听起来[povname]好像见过科尔？这不可能，对吧？"
                                        mc "科尔是个神，或者至少被当作神来崇拜。而迪特里希说她已经死了一段时间了。那[povname]怎么可能和他们交谈呢？"
                                        mc "除非是在更精神层面上的\'交谈\'，但我觉得也不是这样。还有我一直听说的这个墓穴在哪里？"
                                    else:
                                        mc "我想知道[povname]还见过谁？一个俱乐部老板巫师和一个真正的神。"
                                        mc "要是这种效率用在别的地方就好了。"
                                    hide side_p
                                    

                                    

                                else:
                                    play sound "sound/effects/278160__sirrealist2__vibrate.mp3"
                                    "你的手机震动着，删除了所有的日记条目。显然，一次已经是太多的错误了。"
                                    stop sound
                                    $ active_quests.remove("diari1")
                                    show screen completedtask("任务失败")
                                    show side_p s at pic
                                    mc "该死！"
                                    hide side_p
                                
                            else:
                                play sound "sound/effects/278160__sirrealist2__vibrate.mp3"
                                "你的手机震动着，删除了所有的日记条目。显然，一次已经是太多的错误了。"
                                stop sound
                                $ active_quests.remove("diari1")
                                show screen completedtask("任务失败")
                                show side_p s at pic
                                mc "该死！"
                                hide side_p
                        "算了":
                            hide pboy
                            scene bed_alter with dissolve
                            "你决定先试着找到密码，一定有人知道。"
                            "也许是个同学？"
                "带着比答案更多的问题，你决定今天休息一下。"
                if "io0" in my_events and "io4" not in my_events:
                    jump io_dream_check
                elif calendar.day == 30 and calendar.month == '/05': #Rabu W3
                    jump curfew_day
                elif calendar.day == 23 and calendar.month == '/05': #Selasa W2
                    scene kmr_malam with fade
                    "今晚是重要的夜晚。你立即换好衣服，前往阿什姆的房间。"
                    show quil libur sulk at right with dissolve:
                        yoffset 200
                    show red bebas mls sweat at left with dissolve:
                        yoffset 330
                    show tom go frown at center with dissolve:
                        yoffset 190
                    "奎尔帮你画好了面对梅扎所需的符文。当阿什姆和塞恩向你点头示意时，每个人看起来都很紧张。"
                    if "help_me" in my_events:
                        tom blow "迪特里希已经先行一步。他说不要引起任何人的注意。"
                        red kaget -sweat apa "他弄到邀请函了？"
                        show red frown -apa
                        tom ew sweat "也许吧。他说得很含糊，说这样做是为了以防发生任何...意外。"
                        show tom frown -sweat
                        quil ejek sigh "他是个做事周到的人。嗯，我猜这不是他第一次做这种见不得人的工作。"
                        show quil datar
                        tom capek blow "也不会是最后一次。"
                    tom frown -blow "准备好了吗？"
                    show side_p h at pic
                    mc "我已经准备好了。"
                    hide side_p
                    play sound "sound/effects/woosh.mp3"
                    "你们三个人手拉着手，梅扎邀请函上的火焰将你们整个吞没。"
                    scene bg_black with w20
                    jump meyza_fight
                elif calendar.day == 15 and calendar.month == '/05':
                    "当你进去时，莱尔已经睡着了。"
                    play sound "sound/effects/cloth.mp3"
                    "你尽量不发出声音，然后倒在床上睡觉。"    
                    scene bg_black with eye_shut
                    jump dreamscape
                elif calendar.day == 17 and calendar.month == '/05':
                    "当你走进去时，莱尔已经熟睡了。"
                    play sound "sound/effects/cloth.mp3"
                    "你尽量不发出声音，然后倒在床上睡觉。"    
                    scene bg_black with eye_shut
                    jump io_dream
                elif calendar.day == 26 and calendar.month == '/05': #Sabtu W2
                    jump buff_nyari_baju
                else:
                    play sound "sound/effects/cloth.mp3"
                    "你在床上辗转反侧了一会儿，最后终于睡着了。"    
                    scene bg_black with eye_shut
                    if "iv_dream2" not in my_events:
                        jump iv_second
                    else:
                        jump morning
            "先不去。":
                hide girl
                hide pboy
                jump map_kmr_ane
    
label snore_2:
    hide screen kmr_lor
    "太安静了，你什么也听不到。"
    jump map_kmr_ane
###MEYZA
label bar_explore:
    scene map_bar with dissolve
    show pboy s at horzappear
    menu:
        "去哪里？"
        "餐厅区":
            hide pboy
            jump prim_dad
        "酒吧":
            hide pboy
            jump red_barmey
        "洗手间":
            hide pboy
            jump pena_ink
        "休息室":
            hide pboy
            scene alley with dissolve
            "客人们在休息室里等候，有些人在高呼梅扎的名字。"
            "其他一些人似乎忙着玩手机。"
            $ NPC = "???"
            npc "你说卡斯特里不肯借钱给我是什么意思？他们怎么敢！"
            show side_p fr at pic
            mc "看来这里的每个人都深深地被梅扎迷住了。我不知道她经营这个生意多久了。"
            hide side_p
            jump bar_explore
        "入口":
            hide pboy
            scene mey_door with dissolve
            "你试图打开出口的门，但它纹丝不动。门上有一张纸条写着..."
            "...\'使用邀请函回家。\'"
            show side_p fr at pic
            mc "我猜他们这么做是为了不让任何人真正知道这个地方在世界上的位置。"
            hide side_p
            jump bar_explore
label red_barmey:
    scene bar with dissolve
    if "red_nemu_meyza" not in red_events:
        "你看到塞恩在酒吧，还有另外两位客人。"
        $ NPC = "性感女士"
        
        $ red_events.append("red_nemu_meyza")
        npc "请给我一瓶黑色深渊，送给梅扎，并代我向她问好。"
        $ NPC = "调酒师"
        npc "对不起，小姐，但您的卡被拒绝了。"
        $ NPC = "性感女士"
        npc "什么？哦，呃...这到底多少钱？"
        $ NPC = "调酒师"
        npc "10万金币。"
        $ NPC = "性感女士"
        npc "好吧，我现在身上没有那么多钱，但也许——"
        $ NPC = "???"
        npc "如果你愿意的话，我可以帮你。"
        $ NPC = "性感女士"
        npc "你说什么？"
        $ NPC = "吸血鬼"
        npc "你的血闻起来格外美味，我整晚都在注意你。"
        $ NPC = "性感女士"
        npc "啊，你是个吸血鬼。"
        $ NPC = "吸血鬼"
        npc "没错。我愿意介入并帮助解决你的小小财务问题...当然，是有代价的。"
        play sound "sound/effects/hiss.mp3"
        "那个男人开始露出牙齿，对着女士发出嘶嘶声。女孩后退了一步，显然对这个想法感到不舒服。"
        $ NPC = "性感女士"
        npc "我的血不卖，那太——！"
        $ NPC = "吸血鬼"
        npc "哦，得了吧，乞丐可不能挑三拣四！"
        "那个男人开始侵入女人的私人空间，抓住她的手腕，将她的腰拉近。"
        $ NPC = "性感女士"
        npc "不！放开我！"
        play sound "sound/effects/punch.mp3"
        queue sound "sound/effects/bump.mp3"
        "就在你打算介入干预时，你看到塞恩抢先一步——一拳打在那个男人的下巴上。"
        show red bebas kzl sigh at center with dissolve:
            yoffset 330
        play sound "sound/effects/punch.mp3"
        queue sound "sound/effects/crash.mp3"
        red lelah frusta "她说了不，混蛋！" with vpunch
        show red so sigh
        $ NPC = "吸血鬼"
        npc "他妈的什么？！一个人类怎么可能——哦，等等！"
        $ NPC = "吸血鬼"
        npc "我认得这个气味。塞恩。塞恩·维拉什科夫。你是那个邪血者的儿子。"
        red growl shock "你最好管住你的舌头，否则我会把它咬下来！"
        $ NPC = "吸血鬼"
        npc "哦，真有趣。"
        npc "流放的生活怎么样？你母亲在沃特克过得很好。上个月看到她啃食了一整个狼人的头。"
        npc "她已经变成了一头野兽。我猜这是家族遗传。"
        red kzl frusta "我警告你——！"
        show red kaget shock
        npc "否则怎样？你要对我发狂吗？如果是那样的话，你应该代替她接受邪血誓言。"
        show red sad sweat -shock
        npc "在你出现并毁掉一切之前，她是一位受人尊敬的血骑士。这值得吗？"
        npc "你的\'原则\'，换来了你母亲的牺牲？"
        red ngeles "..."
        show red sad
        npc "我就知道。"
        show red mls sigh -sweat
        npc "记住你的位置，塞恩。你之所以没有变成一只无意识的嗜血疯狗，只是因为我们王子的仁慈和你母亲愚蠢的牺牲。"
        play sound "sound/effects/crumple.mp3"
        queue sound "sound/effects/swosh.mp3"
        "那个男人拿出他的邀请函，然后消失了。"
        $ NPC = "性感女士"
        npc "呃，塞恩，是吧？谢谢你。"
        red hister both "哦，呃，是的，没问题。"
        npc "我以前从未在这里见过你，你是新来的吗？"
        red happy -both "是的。我也想给梅扎买一瓶酒，但有点超出我的预算，所以..."
        npc "也许你想分摊账单？你能负担多少？"
        red datar -sigh "嗯，大约..."
        show red kaget shock at left with move
        if girl:
            show palmierproxy jln pissed at right with moveinright:
                yoffset 40
        else:
            show palmierproxy jln pissed at right with moveinright:
                yoffset 100
        play sound "sound/effects/cloth.mp3"
        "你悠闲地走向塞恩，在他伸手掏口袋之前抓住了他的手臂。"
        show red sad sweat -shock
        mc rajuk sweat "塞恩，别这样，伙计，你知道你没有足够的钱支付这个。"
        red bingung apa "哦，[povname]！别担心我，我发誓我还有多余的金币！"
        mc ow frusta "说真的塞恩，我们该走了！"
        play sound "sound/effects/cloth.mp3"
        show red kzl -sweat frusta
        "塞恩甩开了你的手，显然对你粗暴地对待他感到恼火。"
        red lelah sigh "这是我的钱，[nickname]！别管我！"
        hide red with dissolve
        show palmierproxy sad at center with move
        mc side sigh "（看来塞恩还没有完全摆脱梅扎的催眠。也许我找奎尔会有更好的运气？"
        hide side_p
        $ NPC = "???"
    else:
        "你已经检查过这里了，塞恩还在酒吧里。"
    jump bar_explore


label prim_dad:
    scene tamu with dissolve
    if "prim_dad_meet" not in my_events:
        
        "你看到几个女侍正在艰难地应付一个特别闹腾的顾客。"
        $ NPC = "顾客"
        npc "请让我见梅扎，我已经把我所有的一切都给了这个地方！"
        $ NPC = "女侍"
        npc "对不起，费亚霍恩大人，但梅扎今晚正在招待其他人。"
        $ NPC = "费亚霍恩"
        npc "谁？我愿意付双倍，不，三倍的价钱！"
        $ NPC = "女侍"
        
        $ my_events.append("prim_dad_meet")
        npc "费亚霍恩先生，你没有那么多钱。请行为得体，否则我们将被迫请你离开。"
        if "prim_true" in my_events:
            show side_p h at pic
            mc "（等等，费亚霍恩？他是普莉姆的父亲吗？）"
            show side_p fr
            mc "打扰一下，先生，您认识普莉姆·费亚霍恩吗？"
            hide side_p
            $ NPC = "费亚霍恩"
            npc "普莉姆？普莉姆！哦是的，我可以卖掉普莉姆。"
            show side_p h at pic
            mc "呃，您说什么，先生？"
            hide side_p
            npc "她是个年轻漂亮的女人，我相信她能卖个好价钱，然后我就能见到梅扎了..."
            show side_p g at pic
            mc "（天哪，他真的神志不清了，是吗？我需要找到另一种方法来接近他。）"
            hide side_p
            

        else:
            show side_p g at pic
            mc "他被迷得不轻，是吧？可怜的家伙。"
            hide side_p
    else:
        "普莉姆的父亲仍然神志不清，再次检查他也没有用。"
        
    jump bar_explore


label pena_ink:
    scene bar_wc with dissolve
    "你听到奎尔的声音从某个角落传来，声音有些模糊。你寻声而去，发现奎尔的嘴被一个高大的黑影捂住了。"
    "你决定躲在角落里看看发生了什么。"
    show quil libur at center with dissolve:
        yoffset 200
    quil ejek "梅扎，我需要见她！梅扎！"
    play sound "sound/effects/cloth.mp3"
    quil groan sweat shock "唔唔！"
    show quil kzl frusta at left with move:
        yoffset 200
    show pena frown mrh at right with dissolve:
        yoffset 20
    pena "科尔，安静点。来，喝了这个。"
    quil sad apa "等等，这是什么？"
    pena grin -mrh "店里的特调。你想让梅扎叫你去贵宾室，不是吗？"
    quil laugh blush bunga "我想！我会的，我会——"
    play sound "sound/effects/cough.wav"
    quil grit sweat shock"呕！" with vpunch
    quil err frusta"哦！诸神在上，这是什么可恶的、污秽的玩意儿？！"
    show quil rajuk -sweat shock
    pena smile "呵。这才是我认识的奎尔。很高兴见到你，表弟。"
    quil bingung apa "佩纳？！"
    show quil frown -apa
    pena grin cling "哟。"
    $ quil_events.append("met_pena")
    quil ow frusta "你在这里做什么？还有呕，你让我喝的到底是什么鬼东西？"
    show quil bingung sweat -frusta
    pena smile mrh -cling "只是美人鱼之血、克苏鲁之尿和圣水的混合物。我称之为血腥科尔。"
    pena frown "味道很糟糕，但能立即让人从宿醉或催眠状态中清醒过来。"
    pena frown mrh sigh "至于你的第一个问题，我才是应该问这个的人。"
    pena -sigh "除非你是奉你父亲的命令来的。"
    quil kzl shock "什么？不是！我为什么要这样做？"
    show quil bingung -shock
    pena grin "哼，你对乌鸦家族还是一无所知，是吗？不过我也不能怪你。"
    pena -mrh "听着，奎尔，我不能在这里告诉你，但让我们这么说吧，我们家族的生意可能并不像表面上看起来那么正义。"
    quil sulk apa "啊？"
    pena smile "你有没有想过我们小时候父母给我们的药？"
    show quil -sweat shock
    quil kzl -shock "什么？那不是强化针吗？"
    pena "呵。保持你的天真吧，表弟。这是你唯一的优点了。"
    show quil bingung sigh
    pena grin mrh cling "哦，还有告诉你那个朋友，我能看到他们的屁股在偷偷露出来。"
    "哦，糟糕。"
    show pboy s at horzappear
    menu:
        "呃，嗨？":
            hide pboy
            if girl:
                show palmierproxy jln ha sweat at center with dissolve:
                    yoffset 40
            else:
                show palmierproxy jln ha sweat at center with dissolve:
                    yoffset 100
            "你从藏身处探出头来，露出一个尴尬的微笑。"
            mc malu sigh "呃，嗨？"
            show palmierproxy apa both shock
            if not girl2:
                pena -mrh "不错的蛋糕啊，贝克小子。你确实拥有这片土地上最好的面包店。"
            show palmierproxy frown -both -shock
            pena frown mrh sigh "你什么都没听见，什么都没看见，[povname]·贝克。"
            pena -sigh "这也适用于你，奎尔。别让自己卷入这堆烂事。"
            pena -mrh "还有别去招惹那些巫师。相信我，这样对你的良心更好。"
            quil bingung "什么？但你也是个猎人啊。"
            pena grin "我曾经是。你不是唯一一个试图逃离家族事业的人，奎尔。给。"
            show quil frown shock
            play sound "sound/effects/plate.mp3"
            "佩纳扔给奎尔两小瓶血腥科尔，它的颜色和名字让你想起了血腥玛丽。"
        "假装你没有听到":
            hide pboy
            "你继续躲着，紧缩着臀部，试图融入墙壁。"
            pena smile sigh "不出来，是吧？可惜的是，我在哪都能认出那个屁股，[povname]·贝克。"
            show side_p k at pic
            mc "该死。"
            show side_p g
            if not girl and not girl2:
                
                mc "（该死的我那光荣的翘臀。）"
            else:
                mc "（好吧，这一点也不诡异。）"
            hide side_p
            if girl:
                show palmierproxy jln ha sweat at center with dissolve:
                    yoffset 40
            else:
                show palmierproxy jln ha sweat at center with dissolve:
                    yoffset 100
            mc tanya "呃，嗨？"
            pena grin -sigh "哟。好久不见啊，[povname]。"
            show palmierproxy confused -tanya
            pena smile mrh "你这个夏天长高了不少。可惜你的脑子没跟着身高一起成长。"
            pena -mrh "你需要喝一口这个吗，还是你没事？"
            "佩纳在你面前晃了晃血腥科尔的瓶子，它的颜色和名字让你想起了血腥玛丽。"
            mc deject -sweat "不用了，我很好。"
            pena sigh "当然没事。"
            show palmierproxy frown 
            "出于某种原因，佩纳似乎对此并不感到惊讶。"
            pena grin -sigh"不过小心为上总是好的。"
            play sound "sound/effects/plate.mp3"
            "佩纳给了奎尔两个小玻璃瓶。"
    pena frown "用这个给任何受梅扎歌声影响的朋友。应该能让他们免疫。"
    pena mrh "我得走了，这里眼线太多。如果你爸问起，就说我从没来过。"
    pena grin "再见，表弟。"
    quil groan frusta "等等，佩纳！"
    hide pena with dissolve
    show quil sulk sigh
    show palmierproxy rajuk at right with move
    play sound "sound/effects/walk.mp3"
    "说完，佩纳就离开了。他拿出邀请函，传送到了别处。"
    stop sound
    mc apa tanya "那是怎么回事？"
    quil tantrum -sweat -sigh "我，我不知道。不过，这里太危险了。我们应该趁还清醒的时候离开。"
    quil sad "这种饮料似乎能清除梅扎的催眠效果。应该刚好够我们用的。给，你也应该喝一些，以防万一。"
    mc kzl sigh "好的。"
    mc ew frusta "哦，天哪，这味道简直像屁股！"
    quil ow sweat frusta "我知道，对吧？他至少可以加点真正的酒精让它更容易入口。"
    quil kzl -sweat sigh "我们应该找到塞恩和阿什姆，让他们也喝一口。"
    if "red_nemu_meyza" in red_events:
        mc confused -sweat sigh "塞恩在吧台那边和一个女孩在一起。你去找他，我去找阿什姆。"
        mc frown -sigh "我想他还没从贵宾室出来。"
        hide side_p

    else:
        mc confused -sweat sigh "我还没找到他们中的任何一个，不过我觉得阿什姆还在贵宾室里。"
        mc frown -sigh "我比你更有机会接近他。"
        hide side_p
    quil frown -sigh "那好吧，给你。"
    "奎尔递给你一小瓶血腥科尔。"
    $ InvItem(*item_kor).pickup(1)
    quil rajuk "那应该够喝一口的。我去找塞恩，之后我们在入口处汇合。"
    show quil frown 
    mc sad sigh"好的。小心点。"
    scene bar_wc with dissolve
    if "prim_dad_meet" in my_events and "prim_true" in my_events:
        show side_p sdh at pic
        mc "好，现在去找阿什姆。但是...我也可以用这个解药给普莉姆的爸爸。"
        mc "只够喝一口，我该怎么办？"
        hide side_p
        show pboy s at horzappear
        menu:
            "给普莉姆的爸爸":
                hide pboy
                show side_p fr at pic
                mc "阿什姆似乎能很好地抵抗梅扎歌声的影响。我更担心的是普莉姆的爸爸。"
                show side_p g
                mc "我只希望现在还不算太晚。"
                hide side_p
                $ NPC = "费亚霍恩"
                play sound "sound/effects/walk.mp3"
                scene tamu with dissolve
                npc "梅扎……我会给你一切。请用你的声音祝福我们。"
                stop sound
                show side_p mal at pic
                mc "嘿，费霍恩先生？"
                hide side_p
                npc "怎么了？"
                show side_p ha at pic
                mc "梅扎给你送来了这个。这是对你永恒忠诚的礼物。"
                hide side_p
                npc "哦，我就知道我的爱会结出果实的，梅扎！"
                play sound "sound/effects/plate.mp3"
                "费霍恩先生一口气喝完了饮料。"
                $ InvItem(*item_kor).toss(1)
                npc "亲爱的科尔，太可恶了！我——咦？"
                npc "什么？我在这里做什么？我做了什么。哦，科尔！"
                show side_p fr at pic
                mc "费霍恩先生，你知道你在哪里吗？"
                hide side_p
                npc "是的，是的！我全都记得。我抛弃了我的妻子，我的女儿。我的房子，我的生意，我的身体，哦，科尔！"
                npc "我签字同意把我的器官卖给吸血鬼。我不能——"
                npc "我不可能在手术中活下来，绝对不可能。普莉姆……我美丽的女儿，我都做了些什么？"
                show side_p sdh at pic
                mc "我是普莉姆的朋友。有什么我能帮上忙的吗？"
                hide side_p
                npc "不！不，孩子，你不该卷入其中。阿列克谢王子的手下是无情的，但是……但是……如果你能……"
                "费霍恩先生抓起一张餐巾纸，拿出一支笔。他写了一封长信，泪水顺着眼睛流下。"
                npc "给，把这个交给我的女儿，交给普莉姆。我今晚就得逃离这个国家，那是我唯一能逃脱阿列克谢的器官收割者的机会。"
                play sound "sound/effects/chair.mp3"
                npc "告诉我的……告诉普莉姆我爱她，我很抱歉。她的父亲是个傻瓜。"
                play sound "sound/effects/tile.mp3"
                "你刚把信收好，费霍恩先生就跑了。他朝门口跑去时还在哭泣。"
                $ InvItem(*item_slip).pickup(1)
                $ NPC = "???"
                "你希望自己做出了正确的选择。"
                stop sound
                "你满意地走向阿什姆，希望他没有受到梅扎歌声的影响。"
                scene alley with dissolve
                show tom go frown at right with moveinright:
                    yoffset 190
                if girl:
                    show palmierproxy jln grit at left with dissolve:
                        yoffset 40
                else:
                    show palmierproxy jln grit at left with dissolve:
                        yoffset 100

                mc "阿什姆！"
                show palmierproxy sad
                tom ha shock "[povname]。你还好吗？"
                show tom frown -shock
                mc apa tanya "我不是应该问你这个问题吗？你在里面待了很长时间。"
                tom kzl frusta "梅扎很执着。不过她似乎很高兴我拒绝了她的示好，真奇怪。"
                mc ew shock sweat "你说的示好是指……？"
                show palmierproxy frown -shock
                tom ew blow "别担心，她只是对我唱歌而已。我怎么可能会玷污自己去碰一个巫师。"
                tom sad sweat apa "你呢？她没对你做什么……不体面的事吧？"
                show tom lega blow
                mc wry sigh "我没事。"
                show tom frown -blow
                show palmierproxy sad -sigh
                stop music
                play music "MUSIC/MusMus-BGM-025.mp3"
                jump tom_interupt



            "把它给阿什姆":
                hide pboy
                $ tom_events.append("antidote")
                show side_p g at pic
                mc "阿什姆的安全现在更重要。最好赶快去看看他。"
                hide side_p
                play music "MUSIC/MusMus-BGM-025.mp3"
                jump tom_inter
    else:
        $ tom_events.append("antidote")
        play music "MUSIC/MusMus-BGM-025.mp3"
        jump tom_inter



label tom_inter:
    scene alley with dissolve
    show tom go frown at right with moveinright:
        yoffset 190
    
    "当你走向贵宾室时，你看到阿什姆站在门外。"
    $ InvItem(*item_kor).toss(1)
    if girl:
        show palmierproxy jln grit at left with dissolve:
            yoffset 40
    else:
        show palmierproxy jln grit at left with dissolve:
            yoffset 100
    mc "阿什姆！"
    show palmierproxy sad
    tom ha shock "[povname]。你还好吗？"
    show tom frown -shock
    mc apa tanya "我不是应该问你这个问题吗？你在里面待了很长时间。"
    tom kzl frusta "梅扎很执着。不过她似乎很高兴我拒绝了她的示好，真奇怪。"
    mc ew shock sweat "你说的示好是指……？"
    show palmierproxy frown -shock
    tom ew blow "别担心，她只是对我唱歌而已。我怎么可能会玷污自己去碰一个巫师。"
    tom sad sweat apa "你呢？她没对你做什么……不体面的事吧？"
    show tom lega blow
    mc wry -sweat sigh "我没事。"
    show tom frown -blow
    show palmierproxy sad -sigh
    mc sweat "（受到了创伤，困惑，但还好。）"
    tom whine sweat blow "当人说\'我很好\'的时候，他们从来都不是真的\'很好\'。"
    tom sad -sweat -blow "来吧，我们去找其他人然后离开这个地方。"
    mc kzl shock "等等！喝下这个。"
    tom ha apa "这是……人鱼尿吗？"
    mc sad "说来话长，但这能让你对梅扎的歌声免疫，而且我已经喝过了，所以……"
    show tom kzl shock
    "阿什姆一口气喝完了。"
    tom capek frusta "哈！太难喝了。但我想是必要的。"
    mc side tanya "你感觉有什么不同吗？"
    tom ha blow "没有。但我相信你不会让我喝这么恶心的东西只是为了恶作剧。"
    jump tom_interupt

label tom_interupt:
    mc confused -sweat -tanya "你是怎么抵抗梅扎的歌声的？"
    tom wry blush blow "我不确定，我想是因为我满脑子都是你。就这么简单。"
    show pboy s at horzappear
    menu:
        "痴迷的怪胎。":
            hide pboy
            tom amused cling "你的痴迷怪胎。是你让我变成这样的，[povname]。"
            show tom -blush calm -cling
            mc "哦阿什姆，你不知道这句话有多么真实。"
        "你真的很爱我，对吗？":
            hide pboy
            tom wry -blush blow "比任何事都爱，但现在不是歌颂你的时候。我们需要——"
        "有件事你应该知道。":
            hide pboy
            if "come_clean" not in tom_events:
                $ tom_events.append("come_clean")
            mc side sigh "关于那个。你和\'我\'的羁绊，阿什姆，那天和德拉克马巫师在一起的时候——"
    show tom kzl shock
    show red bebas ngeles at center with dissolve:
        yoffset 330
    red "阿什姆，[povname]！"
    show red sad
    hide palmierproxy with moveoutleft
    show quil libur sad at left with moveinleft:
        yoffset 200
    tom kzl "塞恩，奎尔。你们两个都没事吧？"
    red ow sweat frusta "是啊。真不敢相信我差点为这婊子花了10万金币。我连10万都没有！"
    quil kzl sigh "很明显我们根本没准备好应对这一切。来吧，我们赶紧离开这里！"
    scene alley with dissolve
    show mey talk at center with dissolve:
        yoffset 100
    if "sus_mey" in my_events:
        mey "这么快就要走了吗，[povname]？"
        mey crazy apa "我的表演让你如此反感吗？"
        show side_p g at pic
        mc "梅扎。啊，时间真的很晚了，而且我明天还有课，所以。"
        hide side_p
        mey talk cling "当然。请再来。我可不想不得不把你拖回这里。"
        
    else:
        mey "[povname]，你已经要走了吗？"
        show side_p g at pic
        mc "梅扎。对不起，我明天有课，所以..."
        hide side_p
        mey smile "我理解。请再来。我会等你的。"
    mey crazy cling "你和你的朋友们。"
    show side_p mal at pic
    mc "好的，我下个周末会再来——"
    hide side_p
    mey scowl frusta "星期二。"
    show side_p k at pic
    mc "什-什么？"
    hide side_p
    mey talk cling "你会在星期二回来。或者我随时可以去你那里。你选择。"
    show side_p sdh at pic
    mc "我，呃..."
    hide side_p
    show tom go smile at right with moveinright:
        yoffset 190
    show mey at left with move:
        yoffset 100
    tom cling "我们星期二会回来的，夫人。感谢您的款待。"
    mey talk -cling "当然。很快见。"
    stop music 
    play sound "sound/effects/woosh.mp3"
    scene bg_black with w20
    scene kmr_malam with w20
    "说完，你把信件的碎片重新拼在一起。"
    "转眼间，信件自己修复完整，你被传送回了宿舍。"
    show red bebas ew sweat frusta at left with moveinleft:
        yoffset 330
    red "好吧，那他妈的到底是怎么回事？"
    play music "MUSIC/MusMus-BGM-013.mp3"
    show red sad -frusta
    show tom go frown at right with dissolve:
        yoffset 190
    tom capek frusta "看来梅扎的歌曲对心灵有很大影响，很像一个强大的菲拉符文。"
    tom ew blow "我们应该做好相应的准备，找到另一种方法来对付她。"
    tom kzl -blow "奎尔，你不是曾经说过你能制作一种隐形的符文墨水吗？"
    tom frown -blow "不仅肉眼看不见，触摸也感觉不到的那种？"
    show quil libur groan frusta at center with dissolve:
        yoffset 190
    quil "嗯？嗯，是的，但它不能持久。最多只能维持一两个小时，然后就失去所有魔法属性了。"
    show quil kzl sigh
    red ngeles shock "等等，我们还要去对付这个巫师吗？她和我们以前遇到的任何对手都不一样！"
    red ow frusta "奎尔，到底是谁给你这个任务的？不管是谁，他们都是彻头彻尾的混蛋。我觉得梅扎可能是个纯血！"
    show red huh sigh
    quil panik sweat shock "什么？不...不！我绝不会让我们接受这样的任务。"
    show quil frown -sweat
    show red frown shock
    tom ew frusta "不管她是不是纯血，她正在扰乱太多无辜者的生活。"
    show tom kzl -frusta
    show quil sad sigh
    red lelah -sweat frusta "无辜者？那里的每个人都是一群富有的势利小人，他们显然应该以这样或那样的方式在那里！"
    show red kaget shock
    if "red_nemu_meyza" in red_events:
        show side_p g at pic
        mc "包括你帮助的那个女孩吗？"
        hide side_p
        red sweat perih frusta "那是...哈..."
        show red sad sigh
    elif "prim_true" in my_events:
        show side_p k at pic
        mc "普莉姆的父亲在那里。他可能应该在那里，但他的女儿不应该因此而受苦。"
        hide side_p
        red huh sweat apa "普莉姆？"
        tom sad blow "菲亚的朋友。那个费霍恩家的女孩。"
        red perih frusta "哦，好吧...我是说...哈..."
    red ow sigh "我们真的要这么做，是吗？"
    show red sad -sweat -sigh
    tom capek frusta "在看到这一切之后，我不能袖手旁观。贵族们失去理智，"
    tom ew -frusta "抛弃他们的财富，他们的家庭，他们自己的生活..."
    tom kzl blow "如果我的继父被那个巫师迷惑，为此抛弃我的母亲，那么...不，我甚至不想想象她会做什么。"
    red huh "是的，我明白了。那个巫师确实很坏，但是——"
    red ew frusta "我们不能让校长或者乌鸦们介入吗？"
    quil ow sweat frusta "不行！！！" with vpunch
    show red kaget shock
    show tom frown shock
    quil panik -frusta "我是说，不行。校长是个忙人，而乌鸦们，嗯...我觉得我们不能让他们介入。"
    show quil kzl
    red bingung apa "为什么不行？"
    show red sad -apa
    quil sulk sigh "我...我现在还不能回答这个问题，但是，我只需要先确认一些事情，好吗？"
    tom kzl cling "奎尔，如果有什么我们应该知道的——"
    show tom shock
    quil fluster frusta "就是，拜托！让我们自己处理这件事，拜托了。"
    tom sigh blow "哈...好吧。"
    show quil frown shock
    tom kzl -blow "我会尊重你的决定。不过，这确实让我们的选择变得非常有限。"
    if "sus_mey" in my_events:
        tom capek "特别是在梅扎的声明之后。"
        show tom ha 
        quil err sigh "听起来像是一种威胁，不是吗？"
        show quil sad -sigh
        show side_p g at pic
        mc "啊，那可能是我的错。我觉得她不太喜欢我。"
        hide side_p
        tom whine sweat apa "她威胁你了吗？你没事吧？"
        show tom sad 
        "阿什姆抚摸着你的脸颊，检查你的脖子。他脸上明显露出担忧的神色。"
        "这让你对你看到的记忆感觉更糟糕了。也许你应该告诉他这件事。"
        "关于你的分身的意图。"
        show tom frown -sweat
        show side_p sdh at pic
        mc "我没事，但如果我们能尽快解决这个问题，那就再好不过了。"
        hide side_p
        if "help_me" in my_events:
            show side_p h at pic
            mc "而且我想我知道有人可以帮忙。"
            hide side_p
            stop music
            jump gangbang_dietrich
        else:
            tom ha apa "同意。隐形符文墨水是我们最好的选择。奎尔，告诉我你需要什么。"

    else:
        if "help_me" in my_events:
            show side_p h at pic
            mc "也许不是。我想我知道有人可以帮忙。"
            hide side_p
            stop music
            jump gangbang_dietrich
        else:
            quil bingung -sweat sigh "隐形符文墨水是我们最好的选择。"
    quil frown -sweat cling "我需要一些普通的符文墨水、魔法粉末、海妖之血和一条天使鱼。哦，当然还有圣水，用来把所有东西绑定在一起。不过圣水很容易弄到。"
    quil rajuk -cling "天使鱼和海妖之血是最难弄到的部分。"
    $ add_new_quest("slep1")
    python:
        if len(new_quests) > 0: #if we have new quests
            for i in new_quests:
                active_quests.insert(0, i) #add to top of the quest list
                new_quests = [] #now reset the new quest list, since they all got added
    show screen completedtask("新任务！")
    tom frown "莱纳应该有一些，我明天上课前可以去讨价还价一下。"
    red frown -sweat "我想维尔科娃有一些海妖之血。"
    red ow sweat apa "但之后会发生什么？我们进去轮奸一个巫师？"
    tom capek blow "措辞可怕，但或多或少是这样，没错。"
    show tom smile -blow
    red so frusta "好吧，但你们三个最好在这之后好好奖励我！"
    show red kaget shock
    show tom amused shock
    quil wink cling "如果你们愿意的话，我会让你们三个轮奸我。"
    red ew both frusta "我说的是奖励我，不是惩罚我！"
    show red datar shock
    show quil rajuk -cling
    tom frown -shock "我会给你我的血，塞恩。你已经有一段时间没有好好进食了，对吧？你的眼睛比平常更苍白了。"
    red laugh blush bloom "哇，你真的愿意这么做？谢谢你，妈妈！"
    show tom kzl shock
    show quil laugh sigh
    tom capek sweat frusta "我告诉过你不要这么叫我。"
    quil wink cling "你更喜欢\'爸爸\'吗？"
    tom blush giggle blow "说实话，你们两个..."
    show red hister
    show quil laugh -cling
    "紧张的气氛似乎稍微缓解了一些。你还是得告诉阿什姆关于你的分身的真相，但是..."
    "...也许可以等一等，至少再等一会儿。"
    stop music
    scene bg_black with w20
    "你们都回到了各自的房间，阿什姆坚持要送你回去。在他离开之前，他吻了你的手，祝你晚安。"
    "这种关注给你带来了复杂的感觉，因为你知道如果阿什姆知道了德拉克马巫师的真相，他就不会像这样对\'你\'这么甜蜜了。"
    "（[povname]...你到底在想什么？）"
    jump morning
label gangbang_dietrich:
    scene bg_black with w20
    scene kmr_priest with w20
    play sound "sound/effects/door.mp3"
    play music "MUSIC/MusMus-BGM-049.mp3"
    show priest charm at center with dissolve:
        yoffset 200
    dog "哦，这真是个令人愉快的惊喜。我能为你们这些孩子做些什么呢？现在已经很晚了。"
    dog glad "也许太晚了。有没有可能我们明天早上再谈——"
    show priest evil shock
    show side_p g at pic
    mc "是啊，我已经告诉他们关于你的勒索和黑市的事了，所以，呃，你现在可以不用装了，迪特里希。"
    hide side_p
    play sound "sound/effects/doorslam.mp3"
    dog pissed frusta "操！好吧，在别人看到之前赶紧进来！"
    show priest side
    show red bebas mock at left with moveinleft:
        yoffset 330
    red "哇哦。没想到我会听到你骂人，迪特里希先生。"
    show red sayang 
    show tom go amused at right with moveinright:
        yoffset 190
    tom "我想奎尔和[povname]说的是真的了。你用非法文物和好处来勒索学生。"
    tom ejek cling "我尊重这一点。"
    show red datar
    dog bleh sigh "哦，别废话了，直接说重点！"
    dog side -sigh "你们想要什么？"
    show side_p fr at pic
    mc "我们需要你的帮助。嗯...准确地说，是她需要你的帮助。"
    hide side_p
    "你拿出了莱利给你的信。"
    show side_p fr at pic
    mc "你认识一个叫莱利的学生吗？"
    hide side_p
    show priest sad shock
    dog -shock "...不可能。"
    show priest kzl
    "迪特里希一把抢过你手中的信，专注地阅读着。他的眼睛来回扫视，震惊地坐在桌子上。"
    dog ramah sigh "莱利·詹森。她还活着。"
    show priest chill -sigh
    tom ha apa "詹森...？他们不是一个著名的酒店大亨家族吗？"
    show red frown
    show tom frown -apa
    dog side "他们曾经是。直到三年前破产。莱利，她...她曾是我的助手。"
    dog grin "她也帮助我处理一些更为可疑的活动。"
    red bingung apa "勒索还是黑市？"
    show red kaget shock
    show tom ha
    dog side"两者都有。她本应毕业后成为我的全职助理，但是..."
    dog sad sigh "但后来她的家人把她卖给了沃特克，当作血袋。"
    show red wry -shock
    show tom frown
    dog wry -sigh "或者说我是这么以为的。那个女孩，她...她还活着。"
    show side_p fr at pic
    mc "她还活着，而且需要你的帮助。"
    hide side_p
    red frown apa "话说回来，信上写了什么？"
    show red -apa
    dog side "关于她工作场所的详细信息。它的弱点，梅扎容易受影响的符文，以及她的处境。"
    dog "还有保险库的密码。梅扎把所有钱都存在那个保险库里。"
    dog evil bloom "...就是这个！我，我可以退休了！"
    show tom kzl sweat shock
    show red ew sweat shock
    show side_p k at pic
    mc "认真的吗？一个以前的学生请求你帮忙，你满脑子想的却只有钱？！"
    show red kzl -sweat -shock
    show tom capek -sweat -shock
    hide side_p
    dog grin cling "一心多用，[povname]，我可以同时为两件事高兴。钱，还有她。"
    dog hister bunga "我还是不敢相信你居然设法找到了这些混蛋中的一个，奎尔，你真是个绝对的——"
    show side_q bebas sad at pic
    quil "..."
    hide side_q
    "在塞恩和阿什姆身后，你可以看到奎尔在拼命摇头，暗示他不想让男孩们知道梅扎的真实身份。"
    dog grin cling "...我是说，谢谢你们，男孩们，接受了我的请求。我本以为没人能胜任这个任务。"
    show priest charm -cling
    red kaget shock "等等，所以你就是那个发布这个悬赏的混蛋？！"
    show red ew frusta
    dog grin cling "没错，就是我。"
    show priest -cling
    tom ha apa "你的目标是那个保险库吗？难怪你会悬赏这么高。"
    show tom kzl -apa
    dog laugh "正确。"
    red ngeles sigh "下次多加点细节，伙计。我们本该带些耳塞之类的东西！"
    show red sad -sigh
    dog sly "我就知道你们四个能搞定。现在，把一切都告诉我。"
    #transition
    scene bg_black with w20
    scene kmr_priest with w20
    "奎尔和你说了大部分内容，阿什姆在能补充的地方填补了一些。"
    "迪特里希听完后叹了口气。"
    show priest bleh at center with dissolve:
        yoffset 200
    dog "哈啊...听起来像是一个口袋维度。"
    show priest kzl
    show side_p fr at pic
    mc "口袋维度？"
    hide side_p
    dog side "一个只有巫师和她们的客人才能进入的空间。从物理上讲，它可能在这里，也可能在死亡地带，我们根本不知道。"
    dog "如果她够聪明，她可能会让那个空间在世界各地移动，这就是为什么没有她的邀请，没人能找到它。"
    dog "它存在于她想要它存在的任何地方。"
    if "prim_true" in my_events:
        dog "你说费亚霍恩勋爵是那个俱乐部的客人，我不会感到惊讶如果其他家族也收到了类似的邀请。"
    dog kzl "我会利用我的关系获得一个我可以使用的邀请。"
    dog "我用你的邀请进去太冒险了。"
    dog side "你们四个应该使用你们的隐形墨水想法，装作漫不经心。如果可能的话包围她，也许邀请她跳舞。"
    if "slep1" not in active_quests:
        $ add_new_quest("slep1")
        python:
            if len(new_quests) > 0: #if we have new quests
                for i in new_quests:
                    active_quests.insert(0, i) #add to top of the quest list
                    new_quests = [] #now reset the new quest list, since they all got added
        show screen completedtask("新任务！")
    dog "等到我隆重登场，然后我们一起出击。"
    show red bebas frown at left with moveinleft:
        yoffset 330
    show tom go frown at right with moveinright:
        yoffset 190
    tom "一个双管齐下的伏击。这可能会奏效。"
    dog grin cling"一定会的。"
    if not "sus_meyza" in my_events:
        dog bleh sigh "只要你们配合演戏，让她放松警惕，应该就没问题。"
        show priest side -sigh
        red ow frusta "所以，你确定她不是纯血巫师，对吧？因为她绝对与我遇到的所有巫师都不一样。"
        show red sad
        show side_q bebas smile at pic
        quil "哦，别担心，亲爱的。[povname]和我面对过更糟糕的，不是吗？"
        hide side_q
        tom ha apa "让我猜猜，就是在你放弃的那个悬赏上？"
        show tom kzl -apa
        show side_q bebas smile at pic
        quil "是的，但现在我们有五个人了。一切都会很棒的。"
        hide side_q
        dog sly "必须如此。我一定要进入那个保险库，不管付出什么代价！"
        dog laugh bloom "退休生活，我来了！"
        show side_p k at pic
        mc "（...老实说，这个人真是一点羞耻心都没有。）"
        hide side_p
    else:
        dog side sigh "我们别无选择，尤其是她已经对你产生怀疑了。"
        dog kzl -sigh "如果可能的话，我会带后援。"
    show side_q bebas smile at pic
    quil "好吧。我想我们在这里的事就结束了。谢谢你，迪特里希，感谢你的盛情款待。"
    hide side_q
    dog side sigh "别那么快，奎尔。我想和你说句话。你和[povname]。"
    dog bleh frusta "你们其他人可以滚蛋了！"
    tom ew blow "真粗鲁。"
    red so frusta "天啊，我还以为你曾经是个很酷的老师呢。真是太刻薄了！"
    dog kzl -frusta "出去！"
    show red kaget shock
    show tom capek -blow
    hide red with dissolve
    hide tom with dissolve
    play sound "sound/effects/door.mp3"
    show priest at right with move:
        yoffset 200
    show quil libur frown at left with moveinleft:
        yoffset 190
    dog side apa "...所以，你找到了贪婪巫师。我不得不说，你的行动比我预期的要快。"
    quil wink cling "你可以感谢[nickname]。"
    show quil datar -cling
    dog bleh sigh "有必要向那两个人透露我的真实本性吗？你知道，我以愚弄我的学生为荣。"
    show side_p g at pic
    mc "我再也无法保守任何秘密了，真的不行。我感觉自己快要爆炸了！"
    hide side_p
    quil grit frusta "好吧，你必须保守秘密！"
    show quil bingung
    dog laugh cling "如果你有什么要透露的，我洗耳恭听。尤其是关于贵族的事，那么——"
    show priest charm -cling
    show pboy s at horzappear
    menu jujur:
        "不是对你说的！":
            hide pboy
            $ kindness += 10
            show side_p k at pic
            mc "我不会给你更多用来勒索的把柄！"
            hide side_p
            dog kzl sigh "啧！"
            quil rajuk sigh "好吧，总之。我们该去睡觉了。我应该在两天内准备好墨水。"
            show quil datar -sigh
            show side_p fr at pic
            mc "这么快？"
            hide side_p
            quil bingung sigh "我们越快杀死那个巫师越好。"
            show quil frown shock
            dog bleh -sigh "你们越快离开我的视线越好，现在...滚出去。"

        "谈谈\'你的\'过去" if honesty>= 30:
            show quil frown -frusta
            stop music
            hide pboy
            $ honesty += 10
            show side_p fr at pic
            mc "嗯，确实有件事。"
            show side_p g
            play music "MUSIC/MusMus-BGM-112.mp3"
            mc "在贵宾室里，梅扎向我展示了一段记忆。"
            mc "一段关于她和[povname]如何成为\'朋友\'的记忆。他们..."
            show side_p sdh
            mc "...梅扎就是德拉克马尔巫师，[povname]，[kamu]... [kamu]要求她杀死蒂莫西。"
            hide side_p
            quil ow shock "什么？！"
            show quil sad -shock
            $ quil_events.append("past_mc")
            dog kzl "你不是在开玩笑吧？"
            show priest side
            show side_p k at pic
            mc "我为什么要拿这种事开玩笑？"
            hide side_p
            quil sad sweat "但这意味着...阿什姆。[povname]也想要阿什姆死吗？"
            show side_p g at pic
            if girl2:
                
                mc "不完全是，显然[povname]想让阿什姆欠[dia]的人情。"
            else:
                mc "不完全是，显然[povname]想让阿什姆欠[dia2]的人情。"
            hide side_p
            quil sulk "所以他们的友谊，他们的羁绊...都是谎言？"
            dog bleh "而[povname]是个骗子和杀人犯。好吧，我想大多数成功人士都是精神病患者，这倒是真的。"
            show priest side
            quil groan frusta "不。不，我拒绝相信这一切！"
            quil hister -frusta "也许梅扎注意到了你的天真，反而向你展示了一段虚假的记忆？"
            quil wink "你在这个世界上简直就像一个容易受骗的小婴儿，我不会感到惊讶如果她利用了这一点。"
            show quil datar -sweat
            show side_p sdh at pic
            mc "嗯，我想，也许..."
            hide side_p
            dog kzl sigh "奎尔，这是你认为发生的事，还是你希望发生的事？"
            show priest side -sigh
            quil ow sweat "我...我..."
            quil sulk frusta "我太累了。最好去睡个美容觉。晚安，[povname]。"
            quil kzl -sweat sigh "...迪特里希。"
            hide quil with dissolve
            play sound "sound/effects/door.mp3"
            show priest side at center with move
            dog sigh "说实话，他有时候真是太幼稚了。"
            show priest kzl -sigh
            show side_p fr at pic
            mc "他真的是这样吗？[povname]是他最好的朋友。你也不会愿意相信你最好的朋友能够犯下谋杀罪吧？"
            hide side_p
            dog bleh "我们生活在一个人类被当作血袋出售，妻子和女儿可以被拍卖成为奴隶的世界..."
            dog side "...无辜的海妖被像狗一样猎杀，巫师可以将我们的身体永远变成不朽的仆人。"
            dog kzl sigh "[povname]，外面是一个弱肉强食的世界。如果你的分身使用任何[kamu]能想到的方法在生活中取得成功，我也不会感到惊讶。"
            if kln:
                dog -sigh "仅仅因为你的心是金子做的，并不意味着[dia]的心也是。"
            elif girl2:
                dog -sigh "仅仅因为你的心是金子做的，并不意味着[dia2]的心也是。"
            else:
                dog -sigh "仅仅因为你的心是金子做的，并不意味着[dia]的心也是。"
            dog pissed frusta "现在离开我的房间。"
            


        "{s}谈谈\'你的\'过去{/s}" if honesty< 30:
            
            jump jujur
    show priest side -frusta
    show side_p g at pic
    mc "是，先生。"
    hide side_p
    stop music
    scene bg_black with w20
    "你回到自己的房间，准备就寝。"
    jump morning
#TOWN_MAP
label camp_return: 
    "返回校园？"
    show pboy s at horzappear
    menu:
        "返回。":
            hide pboy
            if "bunga_bego" in buff_events:
                if "beku" in quil_events:
                    scene map_infected_f with dissolve
                else:
                    scene map_infected with dissolve    
            else:
                if "beku" in quil_events:
                    scene map_frozen with dissolve
                else:
                    scene map_all with dissolve
            jump world_map
        "不返回。":
            hide pboy
            jump town_map


screen camp_sr():
    add "images/search.png" xpos 1180 ypos 942
screen shops_sr():
    add "images/search.png" xpos 102 ypos 713
screen buku_sr():
    add "images/search.png" xpos 227 ypos 399
screen center_sr():
    add "images/search.png" xpos 1200 ypos 598
screen florist_sr():
    add "images/search.png" xpos 527 ypos 461
screen cafe_sr():
    add "images/search.png" xpos 993 ypos 333
screen merry_sr():
    add "images/search.png" xpos 1165 ypos 403
screen river_sr():
    add "images/search.png" xpos 492 ypos 657

screen peta_town():
    tag menu
    imagebutton:
        idle "images/maps/town/campuy.png"
        hover "images/maps/town/campuy_hover.png"
        xpos 1504 ypos 164
        hovered [ Play ("test_one", "type.wav"), Show("camp_sr")]
        action [Play ("test_one", "walk.mp3"), Hide("camp_sr"), Jump("camp_return")]
        unhovered Hide("camp_sr")
        focus_mask None
        #mouse "search"
    imagebutton:
        idle "images/maps/town/shopi.png"
        hover "images/maps/town/shopi_hover.png"
        xpos 1504 ypos 694
        hovered [ Play ("test_one", "type.wav"), Show("shops_sr")]
        action [Play ("test_one", "walk.mp3"), Hide("shops_sr"),Jump("clothing_shops")]
        unhovered Hide("shops_sr")
        focus_mask None
        #mouse "search"
    imagebutton:
        idle "images/maps/town/centeri.png"
        hover "images/maps/town/centeri_hover.png"
        xpos 1504 ypos 622
        hovered [ Play ("test_one", "type.wav"), Show("center_sr")]
        action [Play ("test_one", "walk.mp3"), Hide("center_sr"),Jump("ctulu")]
        unhovered Hide("center_sr")
        focus_mask None
        #mouse "search"
    imagebutton:
        idle "images/maps/town/flori.png"
        hover "images/maps/town/flori_hover.png"
        xpos 1504 ypos 249
        hovered [ Play ("test_one", "type.wav"), Show("florist_sr")]
        action [Play ("test_one", "walk.mp3"), Hide("florist_sr"),Jump("florist")]
        unhovered Hide("florist_sr")
        focus_mask None
        #mouse "search"
    imagebutton:
        idle "images/maps/town/cafi.png"
        hover "images/maps/town/cafi_hover.png"
        xpos 1504 ypos 393
        hovered [ Play ("test_one", "type.wav"), Show("cafe_sr")]
        action [Play ("test_one", "walk.mp3"), Hide("cafe_sr"),Jump("cave")]
        unhovered Hide("cafe_sr")
        focus_mask None
        #mouse "search"
    imagebutton:
        idle "images/maps/town/merry.png"
        hover "images/maps/town/merry_hover.png"
        xpos 1504 ypos 465
        hovered [ Play ("test_one", "type.wav"), Show("merry_sr")]
        action [Play ("test_one", "walk.mp3"), Hide("merry_sr"),Jump("pubg")]
        unhovered Hide("merry_sr")
        focus_mask None
        #mouse "search"
    imagebutton:
        idle "images/maps/town/rivi.png"
        hover "images/maps/town/rivi_hover.png"
        xpos 1504 ypos 544
        hovered [ Play ("test_one", "type.wav"), Show("river_sr")]
        action [Play ("test_one", "walk.mp3"), Hide("river_sr"),Jump("sungai")]
        unhovered Hide("river_sr")
        focus_mask None
        #mouse "search"
    imagebutton:
        idle "images/maps/town/buku.png"
        hover "images/maps/town/buku_hover.png"
        xpos 1504 ypos 319
        hovered [ Play ("test_one", "type.wav"), Show("buku_sr")]
        action [Play ("test_one", "walk.mp3"), Hide("buku_sr"),Jump("bukunin")]
        unhovered Hide("buku_sr")
        focus_mask None
        #mouse "search"
label town_map:
    hide screen peta_all
    scene town_peta 
    $ NPC = "???"
    call screen peta_town
label ctulu:
    if "oli" not in my_events and not "met_mey" in my_events:
        scene pusat_kot with dissolve
        show ctul_han1 at center with dissolve
        "那是...一只断手吗？"
        play sound "sound/effects/grow.wav"
        show ctul_han at center with dissolve
        show side_p k at pic
        mc "哇！"
        hide side_p
        scene pusat_kot with dissolve
        
        "奇怪的生物从断手中钻出来，长成了一个同样可怕的细腰男人。"
        show o_welcome at center with dissolve:
            zoom 0.32
        npc "啊，抱歉。我只是想在不引起大规模恐慌的情况下探索这座神奇的城市。"
        npc "你还好吗？没有幻觉，没有突然想要砸烂某人头颅的冲动，也没有想要在水中溺死自己的欲望？"
        show side_p fr at pic
        mc "呃...没有？"
        hide side_p
        npc "真是有趣。我想知道是不是所有的伊格尼亚人都是这样。"
        hide o_welcome with dissolve
        "那个男人转头看向路过的行人。"
        play sound "sound/effects/panic.mp3"
        npc "啊啊啊啊啊！"
        "仅仅是看到这个男人，他和其他几个行人就开始歇斯底里地逃跑。"
        "尖叫的行人随后纷纷头朝下跳进喷泉，不断地用血淋淋的头撞击大理石砖，直到其他人跑来帮忙。"
        stop sound
        show o_ops at center with dissolve:
            zoom 0.32
        npc"哎呀。看来不行啊。似乎我得提前结束访问了，真可惜。"
        show side_p fr at pic
        mc "那是什么？！你是什么东西？"
        hide side_p
        hide o_ops
        show o_welcome at center:
            zoom 0.32
        npc "我是奥利凡德，一个噬梦者，也被称为克苏鲁的后裔。有什么东西召唤我来到这座城市，我决定来此回应它的呼唤。"
        npc "我感到被召唤的大多数城市都濒临死亡，但这座城市似乎很繁荣。真奇怪。"
        npc "你自己也确实很奇怪。你是人类吗？通常只有吸血鬼能在我面前保持理智。嗯。"
        npc "好吧，这是留待以后解开的谜题。我可不想再发生一次因斯代尔事件。"
        npc "再见啦！"
        hide o_welcome with dissolve
        "说完，那个男人就消失在一团烟雾中。低头看向脚边，你看到那个男人的手又像蜘蛛一样爬走了。"
        "你还注意到那个男人掉了什么东西，似乎是某种古老的遗物。你捡起来，决定以后再使用它。"
        $ InvItem(*item_ctulhu).pickup(1)
        $ my_events.append("oli")
    elif "pic5" in active_quests and tinder.points <6:
        scene pusat_kot with dissolve
        "你看到几只猫懒洋洋地躺在周围。"
        "就在你准备拍照时，它们开始夹着尾巴逃跑了。"
        if check_inv_for(clown_items) and "cow_cat" not in fia_events: 
            play sound "sound/effects/meow.mp3"
            show cow_cat with dissolve
            galleryunlock cow_cat
            $ tinder.points +=1
            $ fia_events.append("cow_cat")
            "然而，有一只猫似乎闻到了你的小丑鱼，还离得足够近让你拍到它的照片。"
            $ InvItem(*item_clown).toss(1)
            "你把小丑鱼给了它，作为它如此冷静和上镜的奖励。"
            $ InvItem(*item_picat).pickup(1)
        elif check_inv_for(angel_items) and "blek_cat" not in fia_events: 
            play sound "sound/effects/meow.mp3"
            show black_cat with dissolve
            galleryunlock black_cat
            $ tinder.points +=1
            $ fia_events.append("blek_cat")
            "然而，有一只猫似乎闻到了你的神仙鱼，从你口袋里偷走了它。"
            "它一口吞下所有的鱼后，开始愉快地咕噜咕噜叫，然后在附近的长凳上睡着了。"
            $ InvItem(*item_angel).toss(1)
            $ InvItem(*item_picat).pickup(1)
        elif check_inv_for(jelly_items) and "ship_cat" not in fia_events: 
            play sound "sound/effects/meow.mp3"
            show kapal_cat with dissolve
            galleryunlock kapal_cat
            $ tinder.points +=1
            $ fia_events.append("ship_cat")
            "然而，有一只猫似乎闻到了你的水母，你决定把它给它，这样你就可以拍到照片。"
            "不过这只猫还是很容易受惊，你最后不得不追着它跑到码头才拍到一张像样的照片。"
            $ InvItem(*item_jelly).toss(1)
            $ InvItem(*item_picat).pickup(1)
        elif check_inv_for(eel_items) and "belly_cat" not in fia_events: 
            $ tinder.points +=1
            $ fia_events.append("belly_cat")
            "你追着几只猫跑了一阵，最后完全放弃了，在一张长凳上休息，这是你急需的。"
            play sound "sound/effects/meow.mp3"
            show tabby_cat with dissolve
            galleryunlock tabby_cat
            "一只猫似乎同情你，坐在你身边，露出肚皮，好像在说\'别放弃！\'"
            "你揉了揉它的肚子，然后给了它一条鳗鱼，因为它表现得如此乖巧。"
            $ InvItem(*item_eel).toss(1)
            
            $ InvItem(*item_picat).pickup(1)
        elif check_inv_for(fish_items) and "meow_cat" not in fia_events: 
            $ tinder.points +=1
            $ fia_events.append("meow_cat")
            "你平静地把身上的鱼拿出来晾着，希望有一只猫会来找你。"
            play sound "sound/effects/meow.mp3"
            show meow_cat with dissolve
            galleryunlock meow_cat
            "没过多久，一只猫就开始对你喵喵叫。"
            "你拍了张照片，然后给了它应得的奖励。"
            $ InvItem(*item_fish).toss(1)
            "你把蓝鲱鱼给了它，作为它如此冷静和上镜的奖励。"
            $ InvItem(*item_picat).pickup(1)
        elif check_inv_for(octo_items) and "sassy_cat" not in fia_events: 
            $ tinder.points +=1
            $ fia_events.append("sassy_cat")
            "可能是闻到了你口袋里的章鱼，一只猫扑通一声坐在你面前。"
            play sound "sound/effects/meow.mp3"
            show sassy_cat with dissolve
            galleryunlock sassy_cat
            "摆出一个\'像画你的法国猫一样画我\'的姿势。"
            "你拍了张照片，然后给了她应得的奖励。"
            $ InvItem(*item_octo).toss(1)
            $ InvItem(*item_picat).pickup(1)
        else:
            "无论你怎么努力，似乎都无法引诱猫咪靠近你。"
            "也许如果你有些鱼的话？"
        scene town_peta  with dissolve
        jump town_map

    else:
        scene pusat_kot with dissolve
        "这里没什么别的可看的了。"
        scene town_peta with dissolve
    jump town_map
label pubg:
    if "met_merry" not in my_events:
        scene merry_bar with fade
        show caf smile at center with dissolve
        npc "你好。欢迎来到欢乐之夜，我是梅莉·奈特。"
        if "date1_done" not in tom_events and "mey_kill" not in my_events:
            caf talk "有什么我可以为你做的吗？一个人的桌子？还是你要加入那边的阿什姆？"
            show side_p fr at pic
            mc "你认识阿什姆？"
            hide side_p
            caf smile "那个在角落里闷闷不乐，周围堆满了上千个蜂蜜棒棒糖的半精灵？是的。"
            caf chill "可怜的孩子被拒绝了。如果他继续这样用食物来消愁的话，这孩子会变胖的。"
            show side_p g at pic
            mc "（哎呀。）"
            hide side_p
            caf talk "总之..."
        caf smile "一个人的桌子？我们今天有单身特餐，那就是..."
        play sound "sound/effects/meow.mp3"
        "她说话时，你看到一只猫从你的腿间走过。"
        caf talk "哦，你好啊，威格斯。"
        show side_p fr at pic
        mc "你们允许猫进来？"
        hide side_p
        caf chill "我喜欢猫，而且我的一位顾客，一个金发吸血鬼，非常喜欢它们。"
        show side_p h at pic
        mc "金发吸血鬼？她穿着白色的类似派克大衣的制服吗？"
        hide side_p
        caf smile "哦是的，沃特克的血骑士制服。当我第一次看到她穿那身衣服时，差点吓出心脏病来。"
        caf talk "精灵和吸血鬼之间的历史可不太友好。"
        caf chill "我本来想拒绝她进入，但她的男朋友原来是凯普勒先生。"
        show side_p fr at pic
        mc "你认识凯普勒先生吗？"
        hide side_p
        caf talk "凯普勒先生和我都来自贝利尔，我们曾经一起在德尔哈对抗血骑士。"
        caf chill "不过，那已经是30年前的事了。"
        caf talk "很高兴看到他能放下过去的恩怨。虽然我在大陆上的家人可能会不同意。"
        caf smile "毕竟他们还没从吸血鬼战争中缓过来。"
        caf talk "不过话说回来，就像我说的，那位女士喜欢猫。她甚至愿意付你一大笔金币来换取猫的照片。"
        caf smile "当然，这里的猫不会让随便什么人给它们拍照。你需要用特定种类的鱼来贿赂它们，才能拍到好照片。"
        caf chill "每只猫都有自己最喜欢的鱼。你为什么不去找找它们，拍些照片呢？我相信那位女士...维莉？维尔科娃？"
        caf smile "不管她是谁，我相信她会因为你的善意举动而给予你奖励的。"
        $ NPC = "客人"
        npc "服务员，打扰一下！"
        caf chill "哦，亲爱的请原谅，我还有其他客人要照顾。"
        hide caf with dissolve
        $ add_new_quest("pic5")
        python:
            if len(new_quests) > 0: #if we have new quests
                for i in new_quests:
                    active_quests.insert(0, i) #add to top of the quest list
                new_quests = [] #now reset the new quest list, since they all got added
        show screen completedtask("新任务！")
        $ my_events.append("met_merry")
        $ NPC = "???"
        scene town_peta with dissolve
        jump town_map
    else:
        if "pic5" not in active_quests and "pic5" not in completed_quests:
            scene merry_bar with fade
            show caf smile at center with dissolve
            play sound "sound/effects/meow.mp3"
            caf talk "哦，你好啊，威格斯。"
            show side_p fr at pic
            mc "你们允许猫进来？"
            hide side_p
            caf chill "我喜欢猫，而且我的一位顾客，一个金发吸血鬼，非常喜欢它们。"
            show side_p h at pic
            mc "金发吸血鬼？她穿着白色的类似派克大衣的制服吗？"
            hide side_p
            caf smile "哦是的，沃特克的血骑士制服。当我第一次看到她穿那身衣服时，差点吓出心脏病来。"
            caf talk "精灵和吸血鬼之间的历史可不太友好。"
            caf chill "我本来想拒绝她进入，但她的男朋友原来是凯普勒先生。"
            show side_p fr at pic
            mc "你认识凯普勒先生吗？"
            hide side_p
            caf talk "凯普勒先生和我都来自贝利尔，我们曾经一起在德尔哈对抗血骑士。"
            caf chill "不过，那已经是30年前的事了。"
            caf talk "很高兴看到他能放下过去的恩怨。虽然我在大陆上的家人可能会不同意。"
            caf smile "毕竟他们还没从吸血鬼战争中缓过来。"
            caf talk "不过话说回来，就像我说的，那位女士喜欢猫。她甚至愿意付你一大笔金币来换取猫的照片。"
            caf smile "当然，这里的猫不会让随便什么人给它们拍照。你需要用特定种类的鱼来贿赂它们，才能拍到好照片。"
            caf chill "每只猫都有自己最喜欢的鱼。你为什么不去找找它们，拍些照片呢？我相信那位女士...维莉？维尔科娃？"
            caf smile "不管她是谁，我相信她会因为你的善意举动而给予你奖励的。"
            $ NPC = "客人"
            npc "服务员，打扰一下！"
            caf chill "哦，亲爱的请原谅，我还有其他客人要照顾。"
            hide caf with dissolve
            $ add_new_quest("pic5")
            python:
                if len(new_quests) > 0: #if we have new quests
                    for i in new_quests:
                        active_quests.insert(0, i) #add to top of the quest list
                    new_quests = [] #now reset the new quest list, since they all got added
            show screen completedtask("新任务！")
            $ my_events.append("met_merry")
            $ NPC = "???"
            scene town_peta with dissolve
            jump town_map

        else:
            scene merry_bar with fade
            show caf smile at center with dissolve
            caf talk "一个人用餐吗？"
            if not calendar.day == 20 and not calendar.month == '/05':
                "梅莉说话时，你看到阿什姆独自坐在角落里。"
            elif "mey_kill" in my_events and "tom_conf" not in tom_events:
                mc "阿什姆！"
                tom "[povname]。"
                tom "对不起，我现在恐怕不能和你说话。"
                tom "失陪了。"
                "阿什姆走出了门。"
                "好吧，如果你之前还不觉得自己被回避了，现在显然是了。"
                npc "咳咳，那么...一个人用餐吗？"
            show pboy s at horzappear
            menu:
                "去找阿什姆" if "tom_conf" in tom_events:
                    hide pboy
                    scene merry_bar with dissolve
                    show tom go smile at center with dissolve:
                        yoffset 190
                    if "date3_done" in tom_events:
                        if "date4_done" not in tom_events and ibu.points>= 75:
                            jump arshy_date4
                        else:
                            pass
                    show side_p ha at pic
                    mc "嘿，阿什姆！"
                    hide side_p
                    tom amused "[povname]。你想和我一起度过今天吗？"
                    show pboy s at horzappear
                    menu:
                        "当然想！":
                            hide pboy
                            
                            if "date5_done" not in tom_events and "date4_done" in tom_events and ibu.points>=90:
                                jump arshy_date5
                            else:
                                tom pfft "很好。那我们出发吧？"
                                #berubah
                                tom smile "我本来打算去书店。听说今天那里有促销活动。"
                                scene buk_buk with dissolve
                                $ datingplace = "bebas"
                                hide screen cal
                                $ quick_menu = False
                                $ daterp = 40
                                $ turnsleft = 3
                                $ skinshiparea = ""
                                $ config.rollback_enabled = False
                                $ renpy.block_rollback()
                                $ datingname = "阿什姆"
                                jump startdate
                                #berubah
                                
                            

                        "只是来打个招呼。":
                            hide pboy
                            show side_p fr at pic
                            mc "我现在有点忙。"
                            hide side_p
                            tom smile "我明白了，如果你需要什么的话，我就在这里。"
                            $ NPC = "???"
                            scene town_peta with dissolve
                            jump town_map



                "在梅莉的酒馆度过一天（100金币）" if gold >= 100:
                    hide pboy
                    $ gold -= 100
                    $ NPC = "客人"
                    play sound "ding.mp3"
                    scene merry_bar with dissolve
                    "在梅莉的酒馆度过一天的时候，你听到梅莉和其他顾客闲聊。"
                    $ d6roll = 0
                    $ d6roll = renpy.random.randint(1, 6)
                    if d6roll == 1:
                        npc "阿什姆？哦是的，那孩子有点情绪化，但是..."
                        npc "嗯？不，他比起蜂蜜泡芙更喜欢葡萄酒，所以..."
                        "你听到顾客们谈论阿什姆，对他有了更多了解。"
                        "你觉得自己更理解他了。"
                        $ ibu.points += 20
                        $ ibu.likes = "触摸、葡萄酒、蜂蜜、蜂蜜泡芙、面包、悬疑小说。"
                        $ ibu.dislikes = "过去的谈话，关于他俱乐部的谈话。"
                        play sound "audio/success.mp3"
                        "你获得了阿什姆的爱情点数！"
                    elif d6roll == 2:
                        npc "奎尔？他有点戏剧女王，不是吗？"
                        npc "但他确实很善良。然而，他是个十足的胆小鬼，甚至不能..."
                        npc "啊，还有我觉得他喜欢羽毛笔和悬疑小说，我觉得这..."
                        "你听到顾客们谈论奎尔，对他有了更多了解。"
                        "你觉得自己更理解他了。"
                        $ bff.likes = "交谈、手铐、羽毛笔、洛基之霜、活死人"
                        $ bff.dislikes = "触摸、糖果或烘焙食品。"
                        $ bff.points += 20
                        play sound "audio/success.mp3"
                        "你获得了奎尔的爱情点数！"
                    elif d6roll == 3:
                        npc "莱尔？我看到他在给花园浇水，他看起来很可怕，但是..."
                        npc "嗯，他的眼神明显意味着他很麻烦，不过..."
                        npc "我觉得他有甜食癖，他喜欢所有甜点，除了那些用血做的。"
                        npc "我还看到他买了一些爱情小说，而且他似乎很喜欢鱼。"
                        "你听到顾客们在谈论莱尔的八卦，对他有了更多了解。"
                        "你觉得自己更理解他了。"
                        $ putri.likes = "全是甜点和烘焙食品，真感人。"
                        $ putri.dislikes = "无。"
                        $ putri.points += 20
                        play sound "audio/success.mp3"
                        "你获得了莱尔的爱情点数！"
                    elif d6roll == 4:
                        npc "塞恩？哦，他很可爱。曾经救过我的宠物鸟。"
                        npc "他有时反应有点慢，但nonetheless是个甜心..."
                        npc "除了血液，你知道他喜欢读讽刺小说吗？"
                        "你听到顾客们在谈论塞恩的八卦，对他有了更多了解。"
                        "你觉得自己更理解他了。"
                        $ mrh.likes = "血液、血棒糖、糖果、讽刺小说、维他命。"
                        $ mrh.points += 20
                        $ mrh.dislikes = "触摸头发、深入交谈、吸血鬼话题。"
                        play sound "audio/success.mp3"
                        "你获得了塞恩的爱情点数！"
                    else:
                        "今天是个平静的日子，顾客很少。也许下次你会有更好的运气。"
                    $ NPC = "???"
                    "经过一天有趣的外出后，你决定回到宿舍。"
                    stop music
                    scene bg_black with w20
                    play music "MUSIC/MusMus-BGM-082.mp3"
                    scene lor_mlm with w20
                    jump ur_room
                "离开":
                    hide pboy
                    show side_p ha at pic
                    mc "今天不行。"
                    hide side_p
                    caf chill "再来啊！"
                    $ NPC = "???"
                    scene town_peta with dissolve
                    jump town_map
label florist:
    if "nina3" in completed_quests and "io4" in my_events or "flag_nin2" in fia_events:
        scene city_wander with dissolve
        "商店暂时关闭，直到另行通知。"
        $ NPC = "???"
        scene town_peta with dissolve
        jump town_map
    else:
        scene florist with fade
    if "nina3" in completed_quests and "flag_nin2" not in fia_events and "io4" not in my_events:
        show poppy hair sad at center with dissolve:
            zoom 0.9
        py "哈。"
        $ fia_events.append("flag_nin2")
        show side_p fr at pic
        mc "波比女士？你在这里做什么？"
        hide side_p
        py awkward "哦，你好亲爱的。我只是...嗯，在生闷气。"
        py remi "我弟弟被人下了爱情魔药，现在他失去了理智，和那个疯女人私奔了。"
        py cry "他卖掉了这家店，切断了与我和其他家人的所有联系。"
        py "我..."
        py base blank "我要找到那个女孩和她的同伙。把他们撕成碎片，然后把他们的残骸拉出来。"
        py hee "他们会付出代价的！"
        show poppy fear
        show side_p sdh at pic
        mc "（糟糕。这是我行为的后果！）"
        show side_p g
        mc "呃，好吧，希望你能成功，波比女士。我还有事要做，呃所以...祝你的谋杀计划顺利！"
        hide side_p
        py tease "哦谢谢你，亲爱的。我保证我会报仇的。"
        "你装作若无其事地冲出商店，融入了镇广场的人群中。"
        scene town_peta with dissolve
        jump town_map
    $ NPC = "科夫"
    show cove_s at pic
    npc "嗨！我叫科夫，需要些花吗？我们还提供花束和唱歌送花服务！"
    hide cove_s
    if "nina1" in active_quests:
        python:
            active_quests.remove("nina1")
            completed_quests.insert(0, "nina1")
        show side_p fr at pic
        mc "事实上，我是来给你送东西的。"
        hide side_p
        show cove_f at pic
        npc "啊？"
        hide cove_f
        show side_p ha at pic
        mc "给你。"
        hide side_p
        $ InvItem(*item_letter).toss(1)
        show cove_f at pic
        npc "一封来自尼娜·福斯特的情书，她是书店老板的女儿？"
        hide cove_f
        show side_p fr at pic
        mc "实际上，现在是她在照看书店。"
        hide side_p
        show cove_s at pic
        npc "哦嗯...这很贴心，但我觉得她不是我的真命天女。"
        npc "如果她是我的伴侣，我应该能闻到她的气味。这封信闻起来很平淡，甚至有点酸。"
        npc "我不认为我们会是好搭档。"
        hide cove_s
        show side_p sdh at pic
        mc "哦。"
        hide side_p
        show screen completedtask("任务完成！")
        show cove_s at pic
        $ gold += 5
        npc "但是，我还是很感谢她的心意。也许我应该婉转地拒绝她。"
        npc "也许送一束花？"
        hide cove_s
        show side_p fr at pic
        mc "实际上，她对花粉过敏。"
        hide side_p
        show cove_f at pic
        npc "哦，我明白了。那么也许可以送蛋糕！不过我不擅长做蛋糕，也许我可以请波比做一个，但她很忙。"
        hide cove_f
        show side_p fr at pic
        mc "波比？"
        hide side_p
        show cove_s at pic
        npc "我的大姐，波比·埃德娜。你认识她吗？"
        hide cove_s
        show side_p fr at pic
        mc "她是我的魔药学教授。"
        hide side_p
        show cove_s at pic
        npc "哦对了，你一定是她的学生之一！"
        npc "嘿，我能请你帮个忙吗？你能帮我烤蛋糕吗？"
        hide cove_s
        show side_p fr at pic
        mc "你甚至不知道我会不会做饭。"
        hide side_p
        show cove_s at pic
        npc "你身上有饼干、果酱和新鲜面包的香味。你会做饭。"
        npc "即使你不会，我也宁愿相信一个陌生人的技术，也不相信我自己的。"
        hide cove_s
        $ add_new_quest("nina2")
        python:
            if len(new_quests) > 0: #if we have new quests
                for i in new_quests:
                    active_quests.insert(0, i) #add to top of the quest list
                new_quests = [] #now reset the new quest list, since they all got added
        show screen completedtask("新任务！")
        show side_p fr at pic
        mc "我看看能做些什么。"
        hide side_p
        $ NPC = "???"
        scene town_peta with dissolve
        jump town_map
    elif "nina2" in completed_quests and not 'calback' in my_events:
        show cove_s at pic
        npc "再次感谢你的帮助，伙计。现在，你需要什么吗？"
        hide cove_s
        show side_p fr at pic
        mc "没什么，只是好奇。妮娜对你的拒绝反应如何？"
        hide side_p
        show cove_f at pic
        npc "不好不坏。我又从她那里闻到了那种酸味，但我相信没什么大不了的。"
        hide cove_f
        show side_p ha at pic
        mc "好的，知道了。再见。"
        hide side_p
        show cove_s at pic
        npc "再见，欢迎再来。"
        hide cove_s
        $ my_events.append("calback")
        $ NPC = "???"
        scene town_peta with dissolve
        jump town_map




    elif "nina1" in completed_quests and "nina2" not in active_quests :
        if "nina2" not in completed_quests:
            show cove_f at pic
            npc "哦嘿，你就是帮我送妮娜那封信的人，对吧？你能帮我个忙吗？"
            npc "说实话，我觉得妮娜和我不太合适。"
            hide cove_f
            show side_p fr at pic
            mc "哦。"
            hide side_p
            show cove_s at pic
            npc "我想用一个道歉蛋糕来婉拒妮娜，唯一的问题是我烘焙技术很差。"
            npc "你能帮我烤个蛋糕吗？剩下的我来处理，我会和她谈谈的，别担心。"
            hide cove_s
            $ add_new_quest("nina2")
            python:
                if len(new_quests) > 0: #if we have new quests
                    for i in new_quests:
                        active_quests.insert(0, i) #add to top of the quest list
                    new_quests = [] #now reset the new quest list, since they all got added
            show screen completedtask("新任务！")
            show side_p fr at pic
            mc "我看看能做些什么。"
            hide side_p
            show cove_s at pic
            npc "谢谢你，伙计。"
            hide cove_s
            $ NPC = "???"
            scene town_peta with dissolve
            jump town_map
        else:
            show red bebas datar at center with dissolve:
                yoffset 330
            "当你环顾四周时，你看到塞恩正在给一些玫瑰浇水。"
            show side_p ha at pic
            mc "塞恩？"
            hide side_p
            red cowo shock "哦嘿，[povname]。"
            show side_p fr at pic
            mc "你在这里做什么？"
            hide side_p
            red amused apa "你说我在这里做什么是什么意思？"
            red datar -apa "你知道我周末在这里工作的。"
            show side_p ha at pic
            mc "哦，呃，对。"
            hide side_p
            red grin "那么...需要什么花吗？"
            show pboy s at horzappear
            menu:
                "不需要，但我需要你。":
                    hide pboy
                    red amused "我？"
                    show side_p ha at pic
                    mc "是啊，想一起出去玩吗？"
                    hide side_p
                    red cowo "我想！可以吗，科夫？"
                    if "mey_kill" not in my_events:
                        show cove_f at pic
                        npc "今天？我这边有个大订单要处理。"
                        hide cove_f
                        red amused "哦，好吧。那太遗憾了。下次吧，[povname]。"
                        hide cove_f
                        $ NPC = "???"
                        scene town_peta with dissolve
                        jump town_map
                    else:
                        show cove_s at pic
                        npc "别担心伙计，休个午餐时间吧。"
                        hide cove_s
                        red grin "太好了！你最棒了，科夫！"
                        scene shop_shop with  w33
                        "你决定和塞恩一起在商店附近逛逛。塞恩一个小时后就得回去，所以你应该好好利用这短暂的约会时间。"
                        hide screen cal
                        $ datingplace = "bebas"
                        $ quick_menu = False
                        $ daterp = 30
                        $ turnsleft = 3
                        $ skinshiparea = ""
                        $ config.rollback_enabled = False
                        $ renpy.block_rollback()
                        $ datingname = "塞恩"
                        show red bebas frown at charcenter
                        jump startdate
                "不了。":
                    hide pboy
                    red datar "哦好的，那回头见！"
                    $ NPC = "???"
                    scene town_peta with dissolve
                    jump town_map
        
    elif "nina2" not in completed_quests and "nina2" in active_quests:
        show side_p ha at pic
        mc "嘿，科夫。"
        hide side_p
        show cove_s at pic
        npc "哦，嗨！你有那个蛋糕吗？"
        hide cove_s 
        if check_inv_for(cake_items):
            python:
                InvItem(*item_cake).toss(1)
                active_quests.remove("nina2")
                completed_quests.insert(0, "nina2")
                gold += 16
            show side_p fr at pic
            mc "给你。"
            hide side_p
            show cove_s at pic
            npc "哦，太感谢了！我一定会亲自送过去，好好和她谈谈的。"
            npc "我相信我们可以成为朋友！"
            hide cove_s 
            show screen completedtask("任务完成！")
            show cove_s at pic
            npc "谢谢你，伙计。"
            hide cove_s
            $ NPC = "???"
            scene town_peta with dissolve
            jump town_map
        else:
            show side_p fr at pic
            mc "我还在做呢！"
            hide side_p
            show cove_s at pic
            npc "别担心。再次感谢，伙计。"
            hide cove_s
            $ NPC = "???"
            scene town_peta with dissolve
            jump town_map

    else:
        show red bebas datar at center with dissolve:
            yoffset 330
        "当你环顾四周时，你看到塞恩正在给一些玫瑰浇水。"
        show side_p ha at pic
        mc "塞恩？"
        hide side_p
        red cowo shock"哦嘿，[povname]。"
        show side_p fr at pic
        mc "你在这里做什么？"
        hide side_p
        red amused apa "你说我在这里做什么是什么意思？"
        red datar -apa "你知道我周末在这里工作的。"
        show side_p ha at pic
        mc "哦，呃，对。"
        hide side_p
        red grin "那么...需要什么花吗？"
        show pboy s at horzappear
        menu:
            "不需要，但我需要你。":
                hide pboy
                red amused "我？"
                show side_p ha at pic
                mc "是啊，想一起出去玩吗？"
                hide side_p
                red cowo"我想！可以吗，科夫？"
                if "mey_kill" not in my_events:
                    show cove_f at pic
                    npc "今天？我这边有个大订单要处理。"
                    hide cove_f
                    red amused "哦，好吧。那太遗憾了。下次吧，[povname]。"
                    hide cove_f
                    $ NPC = "???"
                    scene town_peta with dissolve
                    jump town_map
                else:
                    show cove_s at pic
                    npc "别担心伙计，休个午餐时间吧。"
                    hide cove_s
                    red grin "太好了！你最棒了，科夫！"
                    scene shop_shop with  w33
                    "你决定和塞恩在镇上广场闲逛。塞恩一个小时后就得回去，所以你应该好好利用这短暂的约会时间。"
                    hide screen cal
                    $ datingplace = "bebas"
                    $ quick_menu = False
                    $ daterp = 30
                    $ turnsleft = 3
                    $ skinshiparea = ""
                    $ config.rollback_enabled = False
                    $ renpy.block_rollback()
                    $ datingname = "塞恩"
                    show red bebas frown at charcenter
                    jump startdate
            "不了。":
                hide pboy
                red datar "哦好的，那回头见！"
                $ NPC = "???"
                scene town_peta with dissolve
                jump town_map

label cave:
    scene cofi with fade
    if calendar.day == 20 and calendar.month == '/05' and not "w1_q" in quil_events: #SAbtu W1
        show quil libur frown at center with dissolve:
            yoffset 200
        "你看到奎尔独自一人在角落里写笔记。"
        
        show side_p ha at pic
        mc "嘿。"
        hide side_p
        quil laugh shock "哦，是你啊。"
        show side_p ha at pic
        mc "你在做什么？"
        hide side_p
        quil amused -shock "为明天制定策略。我正在列出需要绘制的符文清单，还有其他一些事情。"
        quil tantrum "逃脱策略、分散注意力的清单，诸如此类的。"
        show side_p ha at pic
        mc "看起来很复杂。"
        hide side_p
        $ quil_events.append("w1_q")
        quil ow "我们要去一个纯血巫师的领地，当然很复杂！"
        quil wink "不过呢，只要有点运气和技巧，我们应该能安然无恙地逃出她的领地。"
        show side_p ha at pic
        mc "嗯。"
        show quil datar
        hide side_p
        show pboy s at horzappear
        menu:
            "你需要休息一下吗？":
                hide pboy
                quil panik blush "你是在邀请我约会吗？"
                show side_p ha at pic
                mc "我是在邀请你出去玩，不过如果你想把它当成约会，也行。"
                hide side_p
                quil sly -blush cling "嗯。"
                if "date1_done" not in quil_events:
                    quil talk -cling "有个地方我想去...不过我们得等到天黑。"
                    show side_p ha at pic
                    mc "我没问题。"
                    hide side_p
                    quil smile "那好吧。"
                    jump quil_date1
                else:
                    quil wry sigh "我觉得现在不是最好的时机。不过我确实有东西要给你。给。"
                    $ InvItem(*item_coco).pickup(1)
                    show side_p ha at pic
                    mc "热可可？"
                    hide side_p
                    quil smile -sigh "夏天快结束了，所以天气变冷了。"
                    quil datar "我记得[povname]不太耐寒，所以我想你也是一样。"
                    show side_p ha at pic
                    mc "哦，谢谢。冬天会有多冷呢？"
                    hide side_p
                    quil amused "冬天？嗯，平均温度是零下40度。"
                    show side_p sdh at pic
                    mc "我的天。"
                    hide side_p
                    quil smile "别担心，加热符文可以帮助调节学校的温度。"
                    show side_p h at pic
                    mc "符文，不是空调或暖气？"
                    hide side_p
                    quil talk apa"空调？暖气？我们有空气净化器，是类似的东西吗？"
                    show side_p ha at pic
                    mc "不完全是，但这不重要。回头见，奎尔。"
                    hide side_p
                    quil sly -apa "再见。"
                    $ NPC = "???"
                    scene town_peta with dissolve
                    jump town_map

            "那我就不打扰你了。":
                hide pboy
                quil wink spark "再见，亲爱的。"
                $ NPC = "???"
                scene town_peta with dissolve
                jump town_map
    else:
        # BERUBAH VITAL
        if "stag1" not in active_quests and "stag1" not in completed_quests:
            npc "精灵的头发...我需要精灵的头发。"
            "一个古怪的男人可以看到在自言自语。"
            npc "精灵的头发，如果我有一些精灵的头发，我就能解决墨水短缺的问题。"
            npc "鹿角乌鸦的毛发最合适，但我在哪里能找到呢？"
            $ add_new_quest("stag1")
            python:
                if len(new_quests) > 0: #if we have new quests
                    for i in new_quests:
                        active_quests.insert(0, i) #add to top of the quest list
                    new_quests = [] #now reset the new quest list, since they all got added
            show screen completedtask("新任务！")
            $ NPC = "???"
            scene town_peta with dissolve
            jump town_map
        elif "festies" in my_events and "date4_done" not in quil_events:
            show quil libur rajuk at center with dissolve:
                yoffset 200
            "你看到奎尔独自一人在角落里吃东西。"
            show side_p ha at pic
            mc "奎尔！"
            hide side_p
            quil datar "哦，这不是那个更让人能忍受的贝克吗。"
            quil smile "真高兴在这里见到你，亲爱的。"
            show pboy s at horzappear
            menu:
                "我能加入你吗？":
                    hide pboy
                    quil sly cling "我不知道，你能吗？对你来说，坐下似乎需要消耗过多的脑力。"
                    show side_p k at pic
                    mc "我要走了。"
                    hide side_p
                    quil err sweat frusta "等等，等等，我只是开个玩笑！"
                    quil smile blush bunga "来坐吧。"
                    #berubah
                    scene cofi with dissolve
                    $ datingplace = "bebas"
                    hide screen cal
                    $ quick_menu = False
                    $ daterp = 40
                    $ turnsleft = 3
                    $ skinshiparea = ""
                    $ config.rollback_enabled = False
                    $ renpy.block_rollback()
                    $ datingname = "奎尔"
                    jump startdate
                    #berubah
                    #stop music
                    #scene bg_black with w20
                    #play music "MUSIC/MusMus-BGM-082.mp3"
                    #scene lor_mlm with w20
                    #jump ur_room


                "我只是路过。":
                    hide pboy
                    quil "再见。"
                    $ NPC = "???"
                    scene town_peta with dissolve
                    jump town_map


        
        elif "stag1" in active_quests:
            npc "精灵的头发...我需要精灵的头发。"
            "那个奇怪的男人继续在座位上自言自语。你应该不去打扰他。"
            $ NPC = "???"
            scene town_peta with dissolve
            jump town_map
        else:
            "你不饿，所以决定离开，继续探索这个小镇。"
            $ NPC = "???"
            scene town_peta with dissolve
            jump town_map




label sungai:
    scene riv_riv with fade
    if "buff_rivi" not in buff_events:
        "你看到派克和莱尔在码头处理货物。"
        show buff bebas wry at center with dissolve:
            yoffset 770
        show side_p ha at pic
        mc "派克？莱尔？"
        hide side_p
        show buff frown shock
        $ NPC = "派克"
        $ buff_events.append("buff_rivi")
        show side_pike_s at pic
        npc "哦，嗨，孩子。我们正在把一些货物从这里运到莱纳尔。"
        hide side_pike_s
        if "buff_kerja" not in buff_events:
            $ buff_events.append("buff_kerja")
            show side_p fr at pic
            mc "和莱尔一起？"
            hide side_p
            buff wry sigh "派克给我提供了一份工作，在周末或我有空的时候帮他。"
            show buff frown shock
            show side_pike_s at pic
            npc "这孩子很有天赋！而且和孩子们相处得也很好！"
            hide side_pike_s
            show side_p fr at pic
            mc "孩子们？"
            hide side_p
            buff eh -shock "派克的大女儿玛格丽特在莱纳尔的孤儿院工作。"
            buff sad "那里有很多孩子，但资源很少。"
            buff wry "在这么小的岛上，孩子们没什么事可做，所以我去和他们玩。"
            buff laugh "我还帮忙喂养和清洁年幼的孩子。"
            show buff datar
            show side_p ha at pic
            mc "哇，看起来你已经完全融入了！"
            mc "（我很高兴看到他现在笑得更自在了。看来他终于找到了自己的位置。）"
            hide side_p
            buff laugh "是的。孩子们和村民们并不真正了解巫师或伊瓦尔。"
            buff sigh "他们让我感觉...很正常。"
            show side_pike_s at pic
            npc "你本来就很正常，小伙子。只是比大多数人高大一些，但这正是女士们喜欢的，对吧？"
            hide side_pike_s
            show side_pike_f at pic
            npc "现在我们回莱纳尔吧，好吗？"
            hide side_pike_f
            buff frown -sigh "好的。再见，[povname]。"
            hide buff with dissolve
            play sound "sound/effects/walk.mp3"
            show side_p ha at pic
            mc "（我很高兴他找到了归属感。）"
            hide side_p
        else:
            show side_p ha at pic
            mc "我明白了。"
        if check_inv_for(ylf_items):
            show side_p k at pic
            mc "啊等等，顺便说一句，莱尔！"
            hide side_p
            show buff bebas frown shock at center with dissolve:
                yoffset 770
            buff apa "什-什么事？"
            show side_p ha at pic
            mc "我给你带来了这个。是伊尔夫给的。"
            hide side_p
            buff eh sweat shock "伊尔夫的信，怎么可能？！"
            show side_p ha at pic
            mc "我在梦中又遇到了伊瓦尔，在伊瓦尔抓到我之前设法和伊尔夫说了话。"
            mc "他让我把这个交给你。"
            hide side_p
            buff laugh blush bloom "这...这太棒了！谢谢，真的谢谢！"
            "莱尔毫无预警地将你拉入一个紧紧的熊抱中。"
            if girl:
                "你的脸正好贴在他柔软却结实的胸膛上。"
            else:
                "他的头发拂过你的脸颊。你能闻到他身上松木香水的气味。"
            show side_p ha at pic
            mc "哇-哇哦，轻点，伙计！我喜欢背部按摩，但是——"
            hide side_p
            buff sad shock "哦，我非常抱歉！"
            $ putri.points += 30
            buff wry sigh "谢谢你，我是真心的。"
            show side_pike_f at pic
            npc "莱尔？不是要破坏气氛，但是..."
            hide side_pike_f
            buff laugh shock "哦，对了！抱歉，派克先生！"
            buff datar -shock "那么，我现在要走了。再次感谢你，[povname]。"
            buff wry "看来我误会你了。"
            buff hister "如果你有空的话，愿意和我一起在派克的村子里待一会儿吗？"
            buff datar "哦，当然只有在你愿意的情况下！"
            show side_p ha at pic
            mc "我很乐意。"
            hide side_p
            buff laugh bunga "太好了。"
            show buff frown shock
            show side_pike_f at pic
            npc "莱尔，快点，小伙子。我们可没有一整天的时间！"
            hide side_pike_f
            buff wry -shock "好-好的。再见[povname]！"
            $ buff_events.append("surat")
            "说完，他们就划船回湖里去了。看起来你终于赢得了莱尔的信任。这很好。"
            $ InvItem(*item_ylf).toss(1)
        else:
            show side_p ha at pic
            mc "再见，莱尔。"
            hide side_p
        $ NPC = "???"
        scene town_peta with dissolve
        jump town_map
    elif "mey_kill" in my_events:
        if "nina2" not in completed_quests:
            show red bebas datar at center with dissolve:
                yoffset 330
            show side_p fr at pic
            mc "塞恩？"
            hide side_p
            if "drained" in fia_events and "io0" not in my_events:
                show red sad sweat shock at center with dissolve:
                    yoffset 330
                "在你能抓住他之前，塞恩跑掉了。"
                hide red with dissolve
                "你花了一整天试图抓住他，但都是徒劳。"
                #scene bg_black with w33
                play music "MUSIC/MusMus-BGM-082.mp3"
                scene lor_mlm with w33
                jump ur_room
            elif "vamp_visit" in red_events and "date_cekup" not in red_events:
                jump red_cekup
            red amused "哦，嗨[povname]。只是在欣赏风景。"
            red hister sigh "不过比我想象的要无聊得多。"
            red datar -sigh "想一起出去玩吗？"
            show pboy s at horzappear
            menu:
                "当然可以！":
                    hide pboy
                    red grin "太好了！"
                    
                    #jump morning
                    $ quick_menu = False
                    $ datingname = "塞恩"
                    $ datingplace = "Square"
                    jump red_date_check
                "不用了，谢谢！":
                    hide pboy
                    red wry "哦，好吧，也许下次吧！"
                    scene town_peta with dissolve
                    jump town_map
        else:
            "美丽的地方，但除此之外，这里没什么有趣的。"    
    else:
        "美丽的地方，但除此之外，这里没什么有趣的。"
    $ NPC = "???"
    scene town_peta with dissolve
    jump town_map
label clothing_shops:
    
    if calendar.day == 20 and calendar.month == '/05' and "jelly" not in fia_events:
        galleryunlock dance
        scene dance with flashbulb:
            truecenter zoom 1.0
            easein 2.0 truecenter zoom 0.5
        "令你惊讶的是，你看到菲亚独自一人在街道中央跳舞。"
        show pboy s at horzappear
        menu:
            "向她喊话":
                hide pboy
                scene jem_jem with dissolve
                show croissant frown shock at center with dissolve:
                    yoffset 500
                show side_p fr at pic
                mc "菲亚！"
                hide side_p
                fia laugh bunga "哦，[povname]！"
                "菲亚停止跳舞，朝你跑来。"
            "把她举起来" if not girl:
                hide pboy
                scene jem_jem with dissolve
                show croissant flinch cringe sweat shock at center with dissolve:
                    yoffset 500
                fia "呀啊啊！" with vpunch
                play sound "sfx/umph.mp3"
                "在你能正确地将她举起来之前，菲亚用膝盖狠狠地顶了你的肚子。"
                show side_p sdh at pic 
                mc "哦天啊，该死！啊！"
                hide side_p
                fia err shock "[povname]！！！"
                fia sad frusta "非常抱歉，我以为有人想绑架我之类的！"
                show croissant sad -frusta
                show side_p ha at pic
                mc "不，不，这是应该的，我活该。"
                hide side_p
                fia cringe sigh "你确实有点活该，但是...我并不是故意打得那么重的。你还好吗？"
                show croissant def wry -sigh
                show side_p ha at pic
                mc "我能活下来。"
                hide side_p

            "旋转她" if girl:
                hide pboy
                scene jem_jem with dissolve
                show croissant flinch cringe sweat shock at center with dissolve:
                    yoffset 500
                fia "哇哦！"
                fia def pity -sweat bunga "哦[povname]，我们是在跳双人舞吗？"
                show side_p ha at pic
                mc "我想我从来没有在街道中央跳过双人舞，但是好啊。"
                hide side_p
        show croissant -blush wry def apa
        show side_p fr at pic
        mc "话说，你为什么一个人在这里跳舞，还穿着校服？"
        hide side_p
        fia err sigh "海德温女士让我去给她找些魔药材料，作为我的留堂惩罚，说来话长。和合唱团那些婊子们的戏剧一如往常。"
        fia pity -sigh "我发誓塔图姆那个女人就是针对我。不过算了，我想趁这次外出好好练习一下水母节的舞蹈。"
        fia laugh blush "我迫不及待想参加舞会和看水母了，当然！"
        fia gross sweat apa "你准备好节日要穿的衣服了吗？拜托别告诉我你又要穿那套可怕的哥特风套装！"
        show side_p ha at pic
        mc "我的什么？"
        hide side_p
        fia kzl frusta "唉，你到底买新衣服了没有，小闷骚？"
        show side_p sdh at pic
        mc "呃...没有？"
        hide side_p
        $ fia_events.append("jelly")
        fia hmph sigh "哼，看来什么事都得我来操心啊，是不是？来吧，海德温女士不会在意我迟到的，我们去给你买点好看的衣服。"
        show shop_shop behind croissant with dissolve 
        show croissant laugh blush bloom 
        "你和菲亚一起度过了购物的一天。在那里你发现这个世界的衣服相当...大胆，至少可以这么说。"
        "但你决定就让菲亚买她觉得适合你的衣服，随她去吧。"
        "不过，你很高兴能和她共度整天。你现在开始期待这个水母节了。"
        scene bg_black with w20
        stop music
        jump morning
    elif "desa" in buff_events:
        scene jem_jem with dissolve
        show buff bebas datar at center with dissolve:
            yoffset 770
        buff laugh"[povname]？"
        show side_p ha at pic
        mc "哦，嗨，莱尔，你今天上班吗？"
        hide side_p
        buff wry "实际上刚下班。"
        show pboy s at horzappear
        menu:
            "想一起出去玩吗？":
                hide pboy
                buff datar "哦，我...我很乐意。"
                #berubah
                scene red_cur_siang with dissolve
                $ datingplace = "cafe"
                hide screen cal
                $ quick_menu = False
                $ daterp = 40
                $ turnsleft = 3
                $ skinshiparea = ""
                $ config.rollback_enabled = False
                $ renpy.block_rollback()
                $ datingname = "莱尔"
                jump startdate
                #berubah
                #$ putri.points += 5
                #stop music
                #scene bg_black with w20
                #play music "MUSIC/MusMus-BGM-082.mp3"
                #scene lor_mlm with w20
                #jump ur_room
                
            "那么，再见！":
                hide pboy
                buff datar "回头见。"
                scene town_peta with dissolve
                jump town_map

    else:
        scene jem_jem with dissolve
        "你决定给自己一点时间，欣赏码头沿线的景色。"
        "天黑后你回到了宿舍。"
        stop music
        scene bg_black with eye_shut
        jump ur_room


label bukunin:
    if "flag_nin1" in fia_events:
        scene city_wander with dissolve
        "商店的招牌上写着\'暂停营业，恕不另行通知\'。"
        scene town_peta with dissolve
        jump town_map
    else:
        scene buk_buk with dissolve
    if "nina3" in completed_quests and "flag_nin1" not in fia_events:
        $ NPC = "???"
        npc "我们关门了。出去！"
        $ fia_events.append("flag_nin1")
        "迎接你的不是妮娜，而是一个脾气暴躁的大块头男人，留着长长的白胡子和蓬乱的浓密头发。"
        "他让你想起了一个非常强壮的圣诞老人版本，只不过肚子上是结实的腹肌而不是啤酒肚。"
        show side_p ha at pic
        mc "哦，你好，肌肉圣诞老人。妮娜呢，就是平常在这里工作的那个女孩？"
        hide side_p
        npc "她私奔了，那个该死的丫头。你能相信吗？私奔！还是和一个狼人！"
        show side_p h at pic
        mc "哦，看来有人是种族主义者啊。"
        hide side_p
        npc "我才不是种族主义者，你这个白痴！我女儿给一个男人下药然后和他私奔，我当然生气了！"
        show side_p g at pic
        mc "等等，你知道这事？"
        hide side_p
        npc "我发现妮娜在翻我的爱情魔药典籍，我当然知道！"
        npc "我只是没想到她会找到愿意帮她熬制那种魔药的人，因为我知道她买不起。所以肯定是有个破坏分子帮了她！"
        show side_p h at pic
        mc "破坏分子？"
        hide side_p
        npc "我知道有个姑娘喜欢那个叫科夫的小子，他也喜欢她。看他在她身边的反应，我敢说他们是好朋友。"
        npc "我为他们感到高兴，波比正准备撮合他们，看着她最小的弟弟成家。"
        npc "现在我女儿毁了这一切。听说科夫还断绝了和家人的联系。可怜的波比都崩溃了，一直担心他。"
        show side_p g at pic
        mc "...该死。我...我得走了。"
        hide side_p
        $ NPC = "???"
        scene town_peta with dissolve
        jump town_map
    else:
        $ NPC = "妮娜"
    show nina_s at pic
    npc "欢迎光临！"
    hide nina_s
    if "buk_met" not in my_events:
        show nina_s at pic
        npc "哦，是个新面孔！你是学生吗？"
        npc "我是妮娜。我爸爸去年夏天退休了，所以现在由我来照看这家店。"
        npc "很高兴认识你！"
        hide nina_s 
        $ my_events.append("buk_met")
        show side_p ha at pic
        mc "我也很高兴认识你。"
        hide side_p
        show nina_f at pic
        npc "..."
        hide nina_f 
        show side_p fr at pic
        mc "...有什么不对劲吗？"
        hide side_p
        show nina_s at pic
        npc "哦，没有，抱歉。我只是注意到你用的香水和科夫一样！"
        hide nina_s 
        show side_p fr at pic
        mc "科夫？"
        hide side_p
        show nina_s at pic
        npc "街上那家花店的老板。他是个非常温柔的狼人，如果不是因为他的尖牙，我都不会注意到他是狼人。"
        npc "呃...我知道这有点突然，但你介意帮我把这封信交给他吗？"
        hide nina_s
        show side_p ha at pic
        mc "情书？"
        hide side_p
        show nina_s at pic
        npc "是...是的。如果你能亲手把信交给他，我会非常感激的。"
        npc "但如果你太忙的话，也可以用手机发送信件。不过你能不能还是去他的店里，问问他的回复呢？"
        npc "说来讽刺，我其实对花粉过敏。我觉得我进他的店里可能会打喷嚏不停。"
        hide nina_s
        show side_p fr at pic
        mc "好的。"
        hide side_p
        $ InvItem(*item_letter).pickup(1)
        $ add_new_quest("nina1")
        python:
            if len(new_quests) > 0: #if we have new quests
                for i in new_quests:
                    active_quests.insert(0, i) #add to top of the quest list
                new_quests = [] #now reset the new quest list, since they all got added
        show screen completedtask("新任务！")
        "你应该尽快把这个交给科夫！"
        $ NPC = "???"
        scene town_peta with dissolve
        jump town_map



    else:
        show nina_s at pic
        npc "我能为你做些什么吗？"
        hide nina_s
        show pboy s at horzappear
        menu buk_rep:
            "购买书籍":
                show pboy s at horzappear
                menu:
                    "失眠之夜配方（75金币）"if gold >= 75 and "item_oren" not in known_recipes:
                        hide pboy
                        play sound "ding.mp3"
                        $ gold-= 75
                        $ known_recipes.append("item_oren")
                        show nina_s at pic
                        npc "感谢您的惠顾！"
                        npc "还有什么我可以帮忙的吗？"
                        hide nina_s
                        show pboy s at horzappear
                        jump buk_rep
                    "真相药剂配方（45金币）" if gold >= 45 and "item_truth" not in known_recipes:
                        hide pboy
                        $ gold-= 45
                        play sound "ding.mp3"
                        $ known_recipes.append("item_truth")
                        show nina_s at pic
                        npc "感谢您的惠顾！"
                        npc "还有什么我可以帮忙的吗？"
                        hide nina_s
                        show pboy s at horzappear
                        jump buk_rep
                    "活力提升配方（20金币）" if gold >= 20 and "item_vita" not in known_recipes:
                        hide pboy
                        $ gold-= 20
                        play sound "ding.mp3"
                        $ known_recipes.append("item_vita")
                        show nina_s at pic
                        npc "感谢您的惠顾！"
                        npc "还有什么我可以帮忙的吗？"
                        hide nina_s
                        show pboy s at horzappear
                        jump buk_rep
                    
                    "活死人配方（15金币）" if gold >= 15 and "item_ghost" not in known_recipes:
                        hide pboy
                        play sound "ding.mp3"
                        $ gold-= 15
                        $ known_recipes.append("item_ghost")
                        show nina_s at pic
                        npc "感谢您的惠顾！"
                        npc "还有什么我可以帮忙的吗？"
                        hide nina_s
                        show pboy s at horzappear
                        jump buk_rep
                    "没有钱" if gold < 15:
                        hide pboy
                        show nina_s at pic
                        "最便宜的书是15金币，你现在没有那么多钱。"
                        hide nina_s
                        show pboy s at horzappear
                        jump buk_rep
                    "不买了。":
                        hide pboy
                        show nina_s at pic
                        npc "没问题。还有什么我可以帮忙的吗？"
                        hide nina_s
                        show pboy s at horzappear
                        jump buk_rep

                
                
            "{i}你{/i}需要什么吗？":
                hide pboy
                if "nina1" in active_quests and "nina1" not in completed_quests:
                    show nina_s at pic
                    npc "我只希望你能尽快送达我的信。"
                    hide nina_s
                    show pboy s at horzappear
                    jump buk_rep
                elif "nina1" in completed_quests and "nina2" not in completed_quests:
                    show nina_s at pic
                    npc "我想知道科夫对我的看法。"
                    hide nina_s
                    show pboy s at horzappear
                    jump buk_rep
                elif "nina2" in completed_quests and "nina3" not in active_quests and "nina3" not in completed_quests:
                    show nina_f at pic
                    npc "关于科夫的回复...我不是很喜欢。"
                    npc "你在那个猎巫学校学习魔药，对吧？"
                    npc "你能给我制作一种爱情魔药吗？一种足够强大的，能让科夫喜欢上我的魔药？"
                    hide nina_f
                    show pboy s at horzappear
                    menu:
                        "你不能强迫爱情。":
                            hide pboy
                            show nina_f at pic
                            npc "嗯。我们意见不同。"
                            hide nina_f
                            show pboy s at horzappear
                            jump buk_rep
                        "我能得到什么好处？":
                            hide pboy
                            show nina_f at pic
                            npc "钱，如果你来帮我准备饮料给科夫喝，我就给你一本关于魔药的昂贵书籍。"
                            npc "这应该能为你开启许多新的配方。"
                            npc "我只是想让科夫和我在一起，这有什么错吗？"
                            hide nina_f
                            show side_p fr at pic
                            mc "我看看能做些什么。"
                            hide side_p
                            show nina_s at pic
                            npc "这是我找到的我想要的爱情魔药的配方。快点回来。"
                            hide nina_s
                            $ known_recipes.append("item_asmo")
                            $ add_new_quest("nina3")
                            python:
                                if len(new_quests) > 0: #if we have new quests
                                    for i in new_quests:
                                        active_quests.insert(0, i) #add to top of the quest list
                                    new_quests = [] #now reset the new quest list, since they all got added
                            show screen completedtask("新任务！")
                            show pboy s at horzappear
                            jump buk_rep
                elif "nina3" in active_quests:
                    show nina_f at pic
                    npc "你拿到魔药了吗？"
                    hide nina_f
                    if check_inv_for(luv_items):
                        python:
                            InvItem(*item_asmo).toss(1)
                            active_quests.remove("nina3")
                            completed_quests.insert(0, "nina3")
                            gold += 90
                        show side_p fr at pic
                        mc "给你。"
                        hide side_p
                        show nina_s at pic
                        npc "哦，你真的帮我拿到了，谢谢！谢谢！谢谢！"
                        npc "来，帮我准备一杯饮料，把这个加进去。"
                        hide nina_s
                        "你帮尼娜准备了一些柠檬水，然后送给了科夫。"
                        "喝了一口后，科夫的眼睛开始发光，他跑向尼娜的商店，丢下了自己的店铺。"
                        "当你追到书店时，你可以看到他们两个在书架之间亲热。"
                        "看起来事情进展得很顺利。你满意地决定回宿舍睡觉。"
                        show screen completedtask("任务完成！")
                        $ NPC = "???"
                        stop music
                        scene bg_black with w20
                        play music "MUSIC/MusMus-BGM-082.mp3"
                        scene lor_mlm with w20
                        jump ur_room

                    else:
                        show side_p fr at pic
                        mc "还没有。"
                        hide side_p
                        show nina_f at pic
                        npc "哦...那么，快点。"
                        hide nina_f
                        show pboy s at horzappear
                        jump buk_rep



                else:
                    show nina_s at pic
                    npc "我很好，谢谢关心。"
                    hide nina_s
                    show pboy s at horzappear
                    jump buk_rep

            "离开":
                hide pboy
                $ NPC = "???"
                scene town_peta with dissolve
                jump town_map
screen orphan_map():
    tag menu
    imagebutton:
        idle "images/maps/orphan/o_kit.png"
        hover "images/maps/orphan/o_kit2.png"
        xpos 1078 ypos 321
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("kitch_kids")]
        focus_mask None
        mouse "search"    
    imagebutton:
        idle "images/maps/orphan/o_mej.png"
        hover "images/maps/orphan/o_mej2.png"
        xpos 698 ypos 335
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("tab_kids")]
        focus_mask None
        mouse "search"    
    imagebutton:
        idle "images/maps/orphan/o_sof.png"
        hover "images/maps/orphan/o_sof2.png"
        xpos 57 ypos 447
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("sofa_kids")]
        focus_mask True
        mouse "search"    
    imagebutton:
        idle "images/maps/orphan/o_dur.png"
        hover "images/maps/orphan/o_dur.png"
        xpos 1488 ypos 133
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("hik_map")]
        focus_mask True
        mouse "search"    

label vil_map2:
    hide screen orphan_map
    scene orphanage_tamu
    call screen orphan_map

label sofa_kids:
    hide screen orphan_map
    $ NPC = "???"
    npc "你是谁？"
    show side_p se at pic
    mc "我叫[povname]，是莱尔的朋友。"
    hide side_p
    npc "哦！莱尔在哪里？他会帮我们找史蒂夫吗？"
    show side_p se at pic
    mc "他当然会。事实上，他现在正在寻找他。我们都在找，实际上。"
    mc "你记得最后一次看到他是什么时候吗？"
    hide side_p
    npc "我们在晚餐时看到他，宵禁时也看到了，但之后他就不见了。"
    npc "我们以为他想去洗手间，但他再也没有回来。"
    npc "他会回来的，对吧？不像其他孩子，史蒂夫总是会待在附近。"
    show side_p w at pic
    mc "我们会找到他的。别担心。"
    hide side_p
    npc "好吧..."
    jump vil_map2

label kitch_kids:
    hide screen orphan_map
    "可以看到两个年龄较大的孩子，可能十几岁出头，正在一起准备炖菜。"
    npc "玛格丽特夫人有说过关于史蒂夫的事吗？"
    npc "没有，还没有新消息。我开始担心了。"
    npc "如果我们在河里发现他漂浮着怎么办。"
    npc "我是说，他确实喜欢一个人去河边玩，但是...不，我们不应该这样想！"
    show side_p w at pic
    mc "她说得对，你们两个需要保持乐观。"
    hide side_p
    npc "什么——？你是谁？"
    show side_p se at pic
    mc "我是[povname]，我是莱尔的朋友。"
    mc "我也在找史蒂夫。嘿，在史蒂夫失踪之前，你们两个有没有注意到他有什么奇怪的地方？"
    hide side_p
    npc "奇怪？你说的奇怪是什么意思？"
    show side_p se at pic
    mc "我不知道，也许他们会自言自语之类的。"
    hide side_p
    npc "哼。那样的话，这里的每个孩子都有点奇怪。还是太沉迷于他们的想象朋友。"
    show side_p f at pic
    mc "想象朋友？"
    hide side_p
    npc "是啊，很多年纪小的孩子都有想象朋友。"
    show side_p f at pic
    mc "有没有哪个经常出现的？"
    hide side_p
    npc "呃……嗯，确实有一个。一个天使。"
    show side_p f at pic
    mc "天使？"
    hide side_p
    npc "一个露出胸膛的男性天使，全身白色。孩子们是这么说的。我觉得他们只是在捉弄我们。"
    npc "或者也许他们的想象角色似乎混在一起了，谁知道呢？你知道孩子们是什么样的。"
    show side_p m at pic
    mc "（或者那个想象角色并不像他们认为的那样是想象出来的。）"
    show side_p se
    mc "你确定他们是想象出来的吗？你自己从未见过这个人物？"
    hide side_p
    npc "没有？你到底想说什么？我们得在晚饭前做完饭。"
    show side_p se at pic
    mc "哦，抱歉。我需要问的就这些，谢谢你们。"
    hide side_p
    jump vil_map2

label tab_kids:
    hide screen orphan_map
    npc "1,2,3,4……嗯，我想我们需要少准备一个盘子，因为史蒂夫不在。"
    npc "你在哪里，你这个小捣蛋鬼？"
    show side_p se at pic
    mc "嗨，在摆桌子吗？"
    hide side_p
    npc "啊？！你是谁？"
    show side_p se at pic
    mc "别担心，我是莱尔的朋友，我也在找史蒂夫。"
    hide side_p
    npc "……是吗？我不想再被骗了。"
    show side_p f at pic
    mc "你说被骗是什么意思？"
    hide side_p
    npc "大人们……他们在隐瞒什么。我有时能听到他们互相交谈。"
    npc "他们表现得很和蔼可亲，然后又变得慌乱和哭泣。"
    npc "有时我感觉他们像是完全不同的人。"
    show side_p he at pic
    mc "这里所有的人都是这样吗？"
    hide side_p
    npc "嗯，不是，主要是年纪大的。但有时候……有时候玛格丽特夫人和派克先生会走神，呆呆地盯着。"
    npc "这很可怕，图书馆里的孩子们有时也会这样，那些比较安静的孩子。"
    npc "玛格丽特夫人说这只是因为有些人喜欢说话，有些人不喜欢，但我不这么认为。"
    show side_p he at pic
    mc "我是说，她说得有道理。而且年纪大的人也可能患有痴呆症，你知道吗？"
    hide side_p
    npc "别对我说教！我知道我看到了什么！如果你不相信我，那你为什么一开始要问我任何事情？！"
    "女孩撅起嘴，不理你了。"
    jump vil_map2

screen map_hik():
    tag menu
    imagebutton:
        idle "images/maps/orphan/o_chair.png"
        hover "images/maps/orphan/o_chair2.png"
        xpos 1165 ypos 466
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("kid_buk")]
        focus_mask None
        mouse "search" 
    imagebutton:
        idle "images/maps/orphan/o_coret.png"
        hover "images/maps/orphan/o_coret2.png"
        xpos 781 ypos 664
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("kid_coret")]
        focus_mask None
        mouse "search" 
    imagebutton:
        idle "images/maps/orphan/o_tin.png"
        hover "images/maps/orphan/o_tin2.png"
        xpos 75 ypos 485
        hovered [ Play ("test_one", "type.wav")]
        action [Play ("test_one", "stroke.mp3"), Jump("kid_teen")]
        focus_mask None
        mouse "search" 
label hik_map:
    hide screen orphan_map
    hide screen map_hik
    scene orphanage_baju
    if "kid_coret" in fia_events and "teen_cur" in fia_events:
        show side_p he at pic
        mc "（我想这就是我能从这些孩子那里了解到的全部了。）" 
        show side_p f
        mc "（也许其他人运气会更好。）"
        hide side_p
        jump vil_kelar
    else:
        call screen map_hik

label kid_coret:
    hide screen map_hik
    "可以看到两个不超过4或5岁的孩子在木地板上涂鸦。"
    "他们的涂鸦看起来像是粗糙的符文符号。"
    show side_p se at pic
    mc "嘿，你们两个，你们在画什么呢？"
    hide side_p
    npc "你看不出来吗？这是一丛玫瑰花！"
    show side_p w at pic
    mc "我明白了，那些符号是花丛的一部分吗？"
    hide side_p
    npc "……我不知道它们是什么。天鹅先生让我画的！"
    show side_p he at pic
    mc "天鹅先生？"
    hide side_p
    npc "他是一只会说话的天鹅！说这会保护村子！"
    show side_p f at pic
    mc "（天鹅先生是巫师吗？他可能就是欧文看到的白色身影。而且，巫师确实可以入侵人们的梦境。）"
    show side_p s
    mc "（伊瓦尔一直这么做，如果莱纳尔的人不害怕巫师，我怀疑他们是否会费心设置必要的保护符文。）"
    hide side_p
    "你仔细看了看那些符文，可惜没有认出任何一个。"
    "这可能是因为你对这个世界的了解有限，或者它们确实只是无害的儿童涂鸦。"
    "无论如何，你谨慎行事，画了奎尔教你的第一个符文，那个应该能阻挡任何巫师入侵孩子们梦境的梦境符文。"
    $ fia_events.append("kid_coret")
    jump hik_map
label kid_buk:
    hide screen map_hik
    "可以看到两个孩子，显然是兄妹，正在互相争吵。"
    $ NPC = "女孩"
    npc "但是德鲁，你为什么要去森林？那里不安全！"
    $ NPC = "德鲁"
    npc "对你和那些小孩子来说不安全！"
    npc "你到底想不想让我找到史蒂夫？让我和尤里尔去找他吧，我敢打赌他只是在树林里迷路了。"
    $ NPC = "女孩"
    npc "就让大人们处理吧！"
    $ NPC = "德鲁"
    npc "不行！那些笨蛋什么都做不好！"
    jump hik_map

label kid_teen:
    hide screen map_hik
    "可以看到两个大约15岁的男孩正盯着书架旁争吵的兄妹。"
    "他们让你想起了你的表兄弟詹姆斯和莱拉。那对16岁的势利小人总是表现得好像他们比你强似的。" 
    "这两个16岁的孩子似乎也没什么不同。鲁莽而又渴望有所作为。"
    $ NPC = "???"
    npc "德鲁到底来不来，尤里尔？"
    $ NPC = "尤里尔"
    npc "我看悬，南希像胶水一样黏着他。她不会让他走出那扇门的，我跟你说。"
    $ NPC = "???"
    npc "嗯，我们又不是要从门里走出去，对吧？"
    $ NPC = "尤里尔"
    npc "不管我们从哪里溜出去，德鲁都不会去任何地方的。"
    npc "我敢打赌南希会开始嚎啕大哭，然后德鲁又会开始低声下气只为让她闭嘴。"
    npc "德鲁对她太软弱了。一直都是这样。"
    show side_p a at pic
    mc "要去哪儿，小伙子们？"
    hide side_p
    $ NPC = "???"
    npc "嗯？哦，你是那些教会的人。伊格尼亚的学生。你想干什么？"
    show side_p c at pic
    mc "只是对你们的计划感到好奇。有什么想和大家分享的吗？"
    hide side_p
    $ NPC = "尤里尔"
    npc "切。好像你会帮忙似的，教会从来没给我们带来什么好处。管好你自己的事吧！"
    show side_p a at pic
    mc "你们越早告诉我些什么，我和我的朋友们就能越早离开。"
    hide side_p
    $ NPC = "???"
    npc "那你问错人了，伙计。你该盯着点欧文。"
    npc "以前也有孩子失踪过，但从没有这么快的速度，他用他那该死的表演催眠他们，我跟你说！"
    show side_p he at pic
    mc "（该死，死胡同。）"
    show side_p f
    mc "啊，好吧，不是欧文，这点我可以告诉你。况且，我们已经处理过他了。"
    hide side_p
    $ NPC = "尤里尔"
    npc "等等，什么？你们揍了他还是怎么的？"
    show side_p f at pic
    mc "不，但是...重点是他不会再在这里露面了。"
    mc "但说真的，除了欧文，你们还有其他线索吗？"
    hide side_p
    $ NPC = "???"
    npc "没有？如果不是他，还能是谁？"
    $ fia_events.append("teen_cur")
    jump hik_map
        






